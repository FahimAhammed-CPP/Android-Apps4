package androidx.appcompat.widget;

import android.content.Context;
import android.content.res.ColorStateList;
import android.graphics.drawable.Drawable;
import android.os.Parcel;
import android.os.Parcelable;
import android.text.TextUtils;
import android.util.AttributeSet;
import android.view.ContextThemeWrapper;
import android.view.Gravity;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.view.ViewParent;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.TextView;
import c.b.g.j;
import c.b.g.n.f0;
import c.b.g.n.l;
import c.b.g.n.o;
import c.b.g.n.y;
import c.b.h.a2;
import c.b.h.b1;
import c.b.h.j2;
import c.b.h.k2;
import c.b.h.m;
import c.b.h.n2;
import c.b.h.t2;
import c.b.h.u0;
import c.b.h.w;
import c.h.j.u;
import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.atomic.AtomicInteger;

public class Toolbar extends ViewGroup {
  public int A = 8388627;
  
  public CharSequence B;
  
  public CharSequence C;
  
  public ColorStateList D;
  
  public ColorStateList E;
  
  public boolean F;
  
  public boolean G;
  
  public final ArrayList<View> H = new ArrayList<View>();
  
  public final ArrayList<View> I = new ArrayList<View>();
  
  public final int[] J = new int[2];
  
  public f K;
  
  public final ActionMenuView.e L = new a(this);
  
  public n2 M;
  
  public m N;
  
  public d O;
  
  public y.a P;
  
  public l.a Q;
  
  public boolean R;
  
  public final Runnable S = new b(this);
  
  public ActionMenuView e;
  
  public TextView f;
  
  public TextView g;
  
  public ImageButton h;
  
  public ImageView i;
  
  public Drawable j;
  
  public CharSequence k;
  
  public ImageButton l;
  
  public View m;
  
  public Context n;
  
  public int o;
  
  public int p;
  
  public int q;
  
  public int r;
  
  public int s;
  
  public int t;
  
  public int u;
  
  public int v;
  
  public int w;
  
  public a2 x;
  
  public int y;
  
  public int z;
  
  public Toolbar(Context paramContext, AttributeSet paramAttributeSet) {
    this(paramContext, paramAttributeSet, 2130903883);
  }
  
  public Toolbar(Context paramContext, AttributeSet paramAttributeSet, int paramInt) {
    super(paramContext, paramAttributeSet, paramInt);
    Context context = getContext();
    int[] arrayOfInt = c.b.b.y;
    j2 j2 = j2.q(context, paramAttributeSet, arrayOfInt, paramInt, 0);
    u.m((View)this, paramContext, arrayOfInt, paramAttributeSet, j2.b, paramInt, 0);
    this.p = j2.l(28, 0);
    this.q = j2.l(19, 0);
    paramInt = this.A;
    this.A = j2.b.getInteger(0, paramInt);
    this.r = j2.b.getInteger(2, 48);
    int i = j2.e(22, 0);
    paramInt = i;
    if (j2.o(27))
      paramInt = j2.e(27, i); 
    this.w = paramInt;
    this.v = paramInt;
    this.u = paramInt;
    this.t = paramInt;
    paramInt = j2.e(25, -1);
    if (paramInt >= 0)
      this.t = paramInt; 
    paramInt = j2.e(24, -1);
    if (paramInt >= 0)
      this.u = paramInt; 
    paramInt = j2.e(26, -1);
    if (paramInt >= 0)
      this.v = paramInt; 
    paramInt = j2.e(23, -1);
    if (paramInt >= 0)
      this.w = paramInt; 
    this.s = j2.f(13, -1);
    paramInt = j2.e(9, -2147483648);
    i = j2.e(5, -2147483648);
    int j = j2.f(7, 0);
    int k = j2.f(8, 0);
    d();
    a2 a21 = this.x;
    a21.h = false;
    if (j != Integer.MIN_VALUE) {
      a21.e = j;
      a21.a = j;
    } 
    if (k != Integer.MIN_VALUE) {
      a21.f = k;
      a21.b = k;
    } 
    if (paramInt != Integer.MIN_VALUE || i != Integer.MIN_VALUE)
      a21.a(paramInt, i); 
    this.y = j2.e(10, -2147483648);
    this.z = j2.e(6, -2147483648);
    this.j = j2.g(4);
    this.k = j2.n(3);
    CharSequence charSequence3 = j2.n(21);
    if (!TextUtils.isEmpty(charSequence3))
      setTitle(charSequence3); 
    charSequence3 = j2.n(18);
    if (!TextUtils.isEmpty(charSequence3))
      setSubtitle(charSequence3); 
    this.n = getContext();
    setPopupTheme(j2.l(17, 0));
    Drawable drawable2 = j2.g(16);
    if (drawable2 != null)
      setNavigationIcon(drawable2); 
    CharSequence charSequence2 = j2.n(15);
    if (!TextUtils.isEmpty(charSequence2))
      setNavigationContentDescription(charSequence2); 
    Drawable drawable1 = j2.g(11);
    if (drawable1 != null)
      setLogo(drawable1); 
    CharSequence charSequence1 = j2.n(12);
    if (!TextUtils.isEmpty(charSequence1))
      setLogoDescription(charSequence1); 
    if (j2.o(29))
      setTitleTextColor(j2.c(29)); 
    if (j2.o(20))
      setSubtitleTextColor(j2.c(20)); 
    if (j2.o(14)) {
      paramInt = j2.l(14, 0);
      getMenuInflater().inflate(paramInt, getMenu());
    } 
    j2.b.recycle();
  }
  
  private MenuInflater getMenuInflater() {
    return (MenuInflater)new j(getContext());
  }
  
  public final void a(List<View> paramList, int paramInt) {
    AtomicInteger atomicInteger = u.a;
    int i = getLayoutDirection();
    boolean bool = false;
    if (i == 1) {
      i = 1;
    } else {
      i = 0;
    } 
    int k = getChildCount();
    int j = Gravity.getAbsoluteGravity(paramInt, getLayoutDirection());
    paramList.clear();
    paramInt = bool;
    if (i != 0) {
      for (paramInt = k - 1; paramInt >= 0; paramInt--) {
        View view = getChildAt(paramInt);
        e e1 = (e)view.getLayoutParams();
        if (e1.b == 0 && t(view) && j(e1.a) == j)
          paramList.add(view); 
      } 
    } else {
      while (paramInt < k) {
        View view = getChildAt(paramInt);
        e e1 = (e)view.getLayoutParams();
        if (e1.b == 0 && t(view) && j(e1.a) == j)
          paramList.add(view); 
        paramInt++;
      } 
    } 
  }
  
  public final void b(View paramView, boolean paramBoolean) {
    e e1;
    ViewGroup.LayoutParams layoutParams = paramView.getLayoutParams();
    if (layoutParams == null) {
      e1 = h();
    } else if (!checkLayoutParams((ViewGroup.LayoutParams)e1)) {
      e1 = i((ViewGroup.LayoutParams)e1);
    } else {
      e1 = e1;
    } 
    e1.b = 1;
    if (paramBoolean && this.m != null) {
      paramView.setLayoutParams((ViewGroup.LayoutParams)e1);
      this.I.add(paramView);
      return;
    } 
    addView(paramView, (ViewGroup.LayoutParams)e1);
  }
  
  public void c() {
    if (this.l == null) {
      w w = new w(getContext(), null, 2130903882);
      this.l = (ImageButton)w;
      w.setImageDrawable(this.j);
      this.l.setContentDescription(this.k);
      e e1 = h();
      e1.a = 0x800003 | this.r & 0x70;
      e1.b = 2;
      this.l.setLayoutParams((ViewGroup.LayoutParams)e1);
      this.l.setOnClickListener(new c(this));
    } 
  }
  
  public boolean checkLayoutParams(ViewGroup.LayoutParams paramLayoutParams) {
    return (super.checkLayoutParams(paramLayoutParams) && paramLayoutParams instanceof e);
  }
  
  public final void d() {
    if (this.x == null)
      this.x = new a2(); 
  }
  
  public final void e() {
    f();
    ActionMenuView actionMenuView = this.e;
    if (actionMenuView.t == null) {
      l l = (l)actionMenuView.getMenu();
      if (this.O == null)
        this.O = new d(this); 
      this.e.setExpandedActionViewsExclusive(true);
      l.b(this.O, this.n);
    } 
  }
  
  public final void f() {
    if (this.e == null) {
      ActionMenuView actionMenuView = new ActionMenuView(getContext(), null);
      this.e = actionMenuView;
      actionMenuView.setPopupTheme(this.o);
      this.e.setOnMenuItemClickListener(this.L);
      actionMenuView = this.e;
      y.a a1 = this.P;
      l.a a3 = this.Q;
      actionMenuView.y = a1;
      actionMenuView.z = a3;
      e e1 = h();
      e1.a = 0x800005 | this.r & 0x70;
      this.e.setLayoutParams((ViewGroup.LayoutParams)e1);
      b((View)this.e, false);
    } 
  }
  
  public final void g() {
    if (this.h == null) {
      this.h = (ImageButton)new w(getContext(), null, 2130903882);
      e e1 = h();
      e1.a = 0x800003 | this.r & 0x70;
      this.h.setLayoutParams((ViewGroup.LayoutParams)e1);
    } 
  }
  
  public ViewGroup.LayoutParams generateLayoutParams(AttributeSet paramAttributeSet) {
    return (ViewGroup.LayoutParams)new e(getContext(), paramAttributeSet);
  }
  
  public CharSequence getCollapseContentDescription() {
    ImageButton imageButton = this.l;
    return (imageButton != null) ? imageButton.getContentDescription() : null;
  }
  
  public Drawable getCollapseIcon() {
    ImageButton imageButton = this.l;
    return (imageButton != null) ? imageButton.getDrawable() : null;
  }
  
  public int getContentInsetEnd() {
    a2 a21 = this.x;
    return (a21 != null) ? (a21.g ? a21.a : a21.b) : 0;
  }
  
  public int getContentInsetEndWithActions() {
    int i = this.z;
    return (i != Integer.MIN_VALUE) ? i : getContentInsetEnd();
  }
  
  public int getContentInsetLeft() {
    a2 a21 = this.x;
    return (a21 != null) ? a21.a : 0;
  }
  
  public int getContentInsetRight() {
    a2 a21 = this.x;
    return (a21 != null) ? a21.b : 0;
  }
  
  public int getContentInsetStart() {
    a2 a21 = this.x;
    return (a21 != null) ? (a21.g ? a21.b : a21.a) : 0;
  }
  
  public int getContentInsetStartWithNavigation() {
    int i = this.y;
    return (i != Integer.MIN_VALUE) ? i : getContentInsetStart();
  }
  
  public int getCurrentContentInsetEnd() {
    // Byte code:
    //   0: aload_0
    //   1: getfield e : Landroidx/appcompat/widget/ActionMenuView;
    //   4: astore_2
    //   5: aload_2
    //   6: ifnull -> 30
    //   9: aload_2
    //   10: getfield t : Lc/b/g/n/l;
    //   13: astore_2
    //   14: aload_2
    //   15: ifnull -> 30
    //   18: aload_2
    //   19: invokevirtual hasVisibleItems : ()Z
    //   22: ifeq -> 30
    //   25: iconst_1
    //   26: istore_1
    //   27: goto -> 32
    //   30: iconst_0
    //   31: istore_1
    //   32: iload_1
    //   33: ifeq -> 52
    //   36: aload_0
    //   37: invokevirtual getContentInsetEnd : ()I
    //   40: aload_0
    //   41: getfield z : I
    //   44: iconst_0
    //   45: invokestatic max : (II)I
    //   48: invokestatic max : (II)I
    //   51: ireturn
    //   52: aload_0
    //   53: invokevirtual getContentInsetEnd : ()I
    //   56: ireturn
  }
  
  public int getCurrentContentInsetLeft() {
    AtomicInteger atomicInteger = u.a;
    return (getLayoutDirection() == 1) ? getCurrentContentInsetEnd() : getCurrentContentInsetStart();
  }
  
  public int getCurrentContentInsetRight() {
    AtomicInteger atomicInteger = u.a;
    return (getLayoutDirection() == 1) ? getCurrentContentInsetStart() : getCurrentContentInsetEnd();
  }
  
  public int getCurrentContentInsetStart() {
    return (getNavigationIcon() != null) ? Math.max(getContentInsetStart(), Math.max(this.y, 0)) : getContentInsetStart();
  }
  
  public Drawable getLogo() {
    ImageView imageView = this.i;
    return (imageView != null) ? imageView.getDrawable() : null;
  }
  
  public CharSequence getLogoDescription() {
    ImageView imageView = this.i;
    return (imageView != null) ? imageView.getContentDescription() : null;
  }
  
  public Menu getMenu() {
    e();
    return this.e.getMenu();
  }
  
  public CharSequence getNavigationContentDescription() {
    ImageButton imageButton = this.h;
    return (imageButton != null) ? imageButton.getContentDescription() : null;
  }
  
  public Drawable getNavigationIcon() {
    ImageButton imageButton = this.h;
    return (imageButton != null) ? imageButton.getDrawable() : null;
  }
  
  public m getOuterActionMenuPresenter() {
    return this.N;
  }
  
  public Drawable getOverflowIcon() {
    e();
    return this.e.getOverflowIcon();
  }
  
  public Context getPopupContext() {
    return this.n;
  }
  
  public int getPopupTheme() {
    return this.o;
  }
  
  public CharSequence getSubtitle() {
    return this.C;
  }
  
  public final TextView getSubtitleTextView() {
    return this.g;
  }
  
  public CharSequence getTitle() {
    return this.B;
  }
  
  public int getTitleMarginBottom() {
    return this.w;
  }
  
  public int getTitleMarginEnd() {
    return this.u;
  }
  
  public int getTitleMarginStart() {
    return this.t;
  }
  
  public int getTitleMarginTop() {
    return this.v;
  }
  
  public final TextView getTitleTextView() {
    return this.f;
  }
  
  public b1 getWrapper() {
    if (this.M == null)
      this.M = new n2(this, true); 
    return (b1)this.M;
  }
  
  public e h() {
    return new e(-2, -2);
  }
  
  public e i(ViewGroup.LayoutParams paramLayoutParams) {
    return (paramLayoutParams instanceof e) ? new e((e)paramLayoutParams) : ((paramLayoutParams instanceof c.b.c.a.a) ? new e((c.b.c.a.a)paramLayoutParams) : ((paramLayoutParams instanceof ViewGroup.MarginLayoutParams) ? new e((ViewGroup.MarginLayoutParams)paramLayoutParams) : new e(paramLayoutParams)));
  }
  
  public final int j(int paramInt) {
    AtomicInteger atomicInteger = u.a;
    int i = getLayoutDirection();
    int j = Gravity.getAbsoluteGravity(paramInt, i) & 0x7;
    if (j != 1) {
      paramInt = 3;
      if (j != 3 && j != 5) {
        if (i == 1)
          paramInt = 5; 
        return paramInt;
      } 
    } 
    return j;
  }
  
  public final int k(View paramView, int paramInt) {
    e e1 = (e)paramView.getLayoutParams();
    int k = paramView.getMeasuredHeight();
    if (paramInt > 0) {
      paramInt = (k - paramInt) / 2;
    } else {
      paramInt = 0;
    } 
    int j = e1.a & 0x70;
    int i = j;
    if (j != 16) {
      i = j;
      if (j != 48) {
        i = j;
        if (j != 80)
          i = this.A & 0x70; 
      } 
    } 
    if (i != 48) {
      if (i != 80) {
        j = getPaddingTop();
        int n = getPaddingBottom();
        int i1 = getHeight();
        i = (i1 - j - n - k) / 2;
        paramInt = ((ViewGroup.MarginLayoutParams)e1).topMargin;
        if (i >= paramInt) {
          k = i1 - n - k - i - j;
          n = ((ViewGroup.MarginLayoutParams)e1).bottomMargin;
          paramInt = i;
          if (k < n)
            paramInt = Math.max(0, i - n - k); 
        } 
        return j + paramInt;
      } 
      return getHeight() - getPaddingBottom() - k - ((ViewGroup.MarginLayoutParams)e1).bottomMargin - paramInt;
    } 
    return getPaddingTop() - paramInt;
  }
  
  public final int l(View paramView) {
    ViewGroup.MarginLayoutParams marginLayoutParams = (ViewGroup.MarginLayoutParams)paramView.getLayoutParams();
    return marginLayoutParams.getMarginStart() + marginLayoutParams.getMarginEnd();
  }
  
  public final int m(View paramView) {
    ViewGroup.MarginLayoutParams marginLayoutParams = (ViewGroup.MarginLayoutParams)paramView.getLayoutParams();
    return marginLayoutParams.topMargin + marginLayoutParams.bottomMargin;
  }
  
  public final boolean n(View paramView) {
    return (paramView.getParent() == this || this.I.contains(paramView));
  }
  
  public boolean o() {
    ActionMenuView actionMenuView = this.e;
    if (actionMenuView != null) {
      boolean bool;
      m m1 = actionMenuView.x;
      if (m1 != null && m1.o()) {
        bool = true;
      } else {
        bool = false;
      } 
      if (bool)
        return true; 
    } 
    return false;
  }
  
  public void onDetachedFromWindow() {
    super.onDetachedFromWindow();
    removeCallbacks(this.S);
  }
  
  public boolean onHoverEvent(MotionEvent paramMotionEvent) {
    int i = paramMotionEvent.getActionMasked();
    if (i == 9)
      this.G = false; 
    if (!this.G) {
      boolean bool = super.onHoverEvent(paramMotionEvent);
      if (i == 9 && !bool)
        this.G = true; 
    } 
    if (i == 10 || i == 3)
      this.G = false; 
    return true;
  }
  
  public void onLayout(boolean paramBoolean, int paramInt1, int paramInt2, int paramInt3, int paramInt4) {
    AtomicInteger atomicInteger = u.a;
    if (getLayoutDirection() == 1) {
      k = 1;
    } else {
      k = 0;
    } 
    int i1 = getWidth();
    int i4 = getHeight();
    paramInt3 = getPaddingLeft();
    int i2 = getPaddingRight();
    int i3 = getPaddingTop();
    int i5 = getPaddingBottom();
    int n = i1 - i2;
    int[] arrayOfInt = this.J;
    arrayOfInt[1] = 0;
    arrayOfInt[0] = 0;
    paramInt1 = getMinimumHeight();
    if (paramInt1 >= 0) {
      paramInt4 = Math.min(paramInt1, paramInt4 - paramInt2);
    } else {
      paramInt4 = 0;
    } 
    if (t((View)this.h)) {
      if (k) {
        j = q((View)this.h, n, arrayOfInt, paramInt4);
        i = paramInt3;
      } else {
        i = p((View)this.h, paramInt3, arrayOfInt, paramInt4);
        j = n;
      } 
    } else {
      i = paramInt3;
      j = n;
    } 
    paramInt1 = i;
    paramInt2 = j;
    if (t((View)this.l))
      if (k) {
        paramInt2 = q((View)this.l, j, arrayOfInt, paramInt4);
        paramInt1 = i;
      } else {
        paramInt1 = p((View)this.l, i, arrayOfInt, paramInt4);
        paramInt2 = j;
      }  
    int j = paramInt1;
    int i = paramInt2;
    if (t((View)this.e))
      if (k) {
        j = p((View)this.e, paramInt1, arrayOfInt, paramInt4);
        i = paramInt2;
      } else {
        i = q((View)this.e, paramInt2, arrayOfInt, paramInt4);
        j = paramInt1;
      }  
    paramInt2 = getCurrentContentInsetLeft();
    paramInt1 = getCurrentContentInsetRight();
    arrayOfInt[0] = Math.max(0, paramInt2 - j);
    arrayOfInt[1] = Math.max(0, paramInt1 - n - i);
    paramInt2 = Math.max(j, paramInt2);
    i = Math.min(i, n - paramInt1);
    paramInt1 = paramInt2;
    j = i;
    if (t(this.m))
      if (k) {
        j = q(this.m, i, arrayOfInt, paramInt4);
        paramInt1 = paramInt2;
      } else {
        paramInt1 = p(this.m, paramInt2, arrayOfInt, paramInt4);
        j = i;
      }  
    paramInt2 = paramInt1;
    i = j;
    if (t((View)this.i))
      if (k) {
        i = q((View)this.i, j, arrayOfInt, paramInt4);
        paramInt2 = paramInt1;
      } else {
        paramInt2 = p((View)this.i, paramInt1, arrayOfInt, paramInt4);
        i = j;
      }  
    paramBoolean = t((View)this.f);
    boolean bool = t((View)this.g);
    if (paramBoolean) {
      e e1 = (e)this.f.getLayoutParams();
      paramInt1 = ((ViewGroup.MarginLayoutParams)e1).topMargin;
      paramInt1 = this.f.getMeasuredHeight() + paramInt1 + ((ViewGroup.MarginLayoutParams)e1).bottomMargin + 0;
    } else {
      paramInt1 = 0;
    } 
    if (bool) {
      e e1 = (e)this.g.getLayoutParams();
      j = ((ViewGroup.MarginLayoutParams)e1).topMargin;
      paramInt1 += this.g.getMeasuredHeight() + j + ((ViewGroup.MarginLayoutParams)e1).bottomMargin;
    } 
    if (paramBoolean || bool) {
      TextView textView1;
      TextView textView2;
      if (paramBoolean) {
        textView1 = this.f;
      } else {
        textView1 = this.g;
      } 
      if (bool) {
        textView2 = this.g;
      } else {
        textView2 = this.f;
      } 
      e e1 = (e)textView1.getLayoutParams();
      e e2 = (e)textView2.getLayoutParams();
      if ((paramBoolean && this.f.getMeasuredWidth() > 0) || (bool && this.g.getMeasuredWidth() > 0)) {
        j = 1;
      } else {
        j = 0;
      } 
      n = this.A & 0x70;
      if (n != 48) {
        if (n != 80) {
          n = (i4 - i3 - i5 - paramInt1) / 2;
          int i6 = ((ViewGroup.MarginLayoutParams)e1).topMargin;
          int i7 = this.v;
          if (n < i6 + i7) {
            paramInt1 = i6 + i7;
          } else {
            i4 = i4 - i5 - paramInt1 - n - i3;
            i5 = ((ViewGroup.MarginLayoutParams)e1).bottomMargin;
            i6 = this.w;
            paramInt1 = n;
            if (i4 < i5 + i6)
              paramInt1 = Math.max(0, n - ((ViewGroup.MarginLayoutParams)e2).bottomMargin + i6 - i4); 
          } 
          paramInt1 = i3 + paramInt1;
        } else {
          paramInt1 = i4 - i5 - ((ViewGroup.MarginLayoutParams)e2).bottomMargin - this.w - paramInt1;
        } 
      } else {
        paramInt1 = getPaddingTop() + ((ViewGroup.MarginLayoutParams)e1).topMargin + this.v;
      } 
      n = paramInt2;
      if (k) {
        if (j != 0) {
          paramInt2 = this.t;
        } else {
          paramInt2 = 0;
        } 
        k = paramInt2 - arrayOfInt[1];
        paramInt2 = i - Math.max(0, k);
        arrayOfInt[1] = Math.max(0, -k);
        if (paramBoolean) {
          e1 = (e)this.f.getLayoutParams();
          k = paramInt2 - this.f.getMeasuredWidth();
          i = this.f.getMeasuredHeight() + paramInt1;
          this.f.layout(k, paramInt1, paramInt2, i);
          paramInt1 = k - this.u;
          k = i + ((ViewGroup.MarginLayoutParams)e1).bottomMargin;
        } else {
          i = paramInt2;
          k = paramInt1;
          paramInt1 = i;
        } 
        if (bool) {
          i = k + ((ViewGroup.MarginLayoutParams)this.g.getLayoutParams()).topMargin;
          k = this.g.getMeasuredWidth();
          i3 = this.g.getMeasuredHeight();
          this.g.layout(paramInt2 - k, i, paramInt2, i3 + i);
          i = paramInt2 - this.u;
        } else {
          i = paramInt2;
        } 
        if (j != 0)
          paramInt2 = Math.min(paramInt1, i); 
        paramInt1 = n;
        i = paramInt2;
      } else {
        if (j != 0) {
          paramInt2 = this.t;
        } else {
          paramInt2 = 0;
        } 
        k = paramInt2 - arrayOfInt[0];
        paramInt2 = Math.max(0, k) + n;
        arrayOfInt[0] = Math.max(0, -k);
        if (paramBoolean) {
          e1 = (e)this.f.getLayoutParams();
          n = this.f.getMeasuredWidth() + paramInt2;
          k = this.f.getMeasuredHeight() + paramInt1;
          this.f.layout(paramInt2, paramInt1, n, k);
          paramInt1 = n + this.u;
          n = k + ((ViewGroup.MarginLayoutParams)e1).bottomMargin;
        } else {
          k = paramInt2;
          n = paramInt1;
          paramInt1 = k;
        } 
        if (bool) {
          k = n + ((ViewGroup.MarginLayoutParams)this.g.getLayoutParams()).topMargin;
          n = this.g.getMeasuredWidth() + paramInt2;
          i3 = this.g.getMeasuredHeight();
          this.g.layout(paramInt2, k, n, i3 + k);
          k = n + this.u;
        } else {
          k = paramInt2;
        } 
        if (j != 0) {
          paramInt1 = Math.max(paramInt1, k);
        } else {
          paramInt1 = paramInt2;
        } 
      } 
    } else {
      paramInt1 = paramInt2;
    } 
    int k = paramInt4;
    n = paramInt3;
    a(this.H, 3);
    paramInt3 = this.H.size();
    for (paramInt2 = 0; paramInt2 < paramInt3; paramInt2++)
      paramInt1 = p(this.H.get(paramInt2), paramInt1, arrayOfInt, k); 
    a(this.H, 5);
    paramInt3 = this.H.size();
    for (paramInt2 = 0; paramInt2 < paramInt3; paramInt2++)
      i = q(this.H.get(paramInt2), i, arrayOfInt, k); 
    a(this.H, 1);
    ArrayList<View> arrayList = this.H;
    j = arrayOfInt[0];
    paramInt4 = arrayOfInt[1];
    i3 = arrayList.size();
    paramInt3 = 0;
    paramInt2 = 0;
    while (paramInt3 < i3) {
      View view = arrayList.get(paramInt3);
      e e1 = (e)view.getLayoutParams();
      j = ((ViewGroup.MarginLayoutParams)e1).leftMargin - j;
      paramInt4 = ((ViewGroup.MarginLayoutParams)e1).rightMargin - paramInt4;
      i4 = Math.max(0, j);
      i5 = Math.max(0, paramInt4);
      j = Math.max(0, -j);
      paramInt4 = Math.max(0, -paramInt4);
      paramInt2 += view.getMeasuredWidth() + i4 + i5;
      paramInt3++;
    } 
    paramInt3 = (i1 - n - i2) / 2 + n - paramInt2 / 2;
    paramInt2 += paramInt3;
    if (paramInt3 >= paramInt1)
      if (paramInt2 > i) {
        paramInt1 = paramInt3 - paramInt2 - i;
      } else {
        paramInt1 = paramInt3;
      }  
    paramInt4 = this.H.size();
    paramInt3 = 0;
    paramInt2 = paramInt1;
    for (paramInt1 = paramInt3; paramInt1 < paramInt4; paramInt1++)
      paramInt2 = p(this.H.get(paramInt1), paramInt2, arrayOfInt, k); 
    this.H.clear();
  }
  
  public void onMeasure(int paramInt1, int paramInt2) {
    int[] arrayOfInt = this.J;
    boolean bool = t2.b((View)this);
    boolean bool2 = true;
    boolean bool1 = false;
    if (bool) {
      i2 = 1;
      i1 = 0;
    } else {
      i1 = 1;
      i2 = 0;
    } 
    if (t((View)this.h)) {
      s((View)this.h, paramInt1, 0, paramInt2, 0, this.s);
      i = this.h.getMeasuredWidth();
      i = l((View)this.h) + i;
      int i5 = this.h.getMeasuredHeight();
      n = Math.max(0, m((View)this.h) + i5);
      k = View.combineMeasuredStates(0, this.h.getMeasuredState());
    } else {
      i = 0;
      n = i;
      k = n;
    } 
    int i3 = i;
    int j = n;
    int i = k;
    if (t((View)this.l)) {
      s((View)this.l, paramInt1, 0, paramInt2, 0, this.s);
      i = this.l.getMeasuredWidth();
      i3 = l((View)this.l) + i;
      i = this.l.getMeasuredHeight();
      j = Math.max(n, m((View)this.l) + i);
      i = View.combineMeasuredStates(k, this.l.getMeasuredState());
    } 
    int k = getCurrentContentInsetStart();
    int n = Math.max(k, i3) + 0;
    arrayOfInt[i2] = Math.max(0, k - i3);
    if (t((View)this.e)) {
      s((View)this.e, paramInt1, n, paramInt2, 0, this.s);
      k = this.e.getMeasuredWidth();
      k = l((View)this.e) + k;
      i2 = this.e.getMeasuredHeight();
      j = Math.max(j, m((View)this.e) + i2);
      i = View.combineMeasuredStates(i, this.e.getMeasuredState());
    } else {
      k = 0;
    } 
    int i2 = getCurrentContentInsetEnd();
    i3 = Math.max(i2, k) + n;
    arrayOfInt[i1] = Math.max(0, i2 - k);
    i2 = i3;
    n = j;
    k = i;
    if (t(this.m)) {
      i2 = i3 + r(this.m, paramInt1, i3, paramInt2, 0, arrayOfInt);
      k = this.m.getMeasuredHeight();
      n = Math.max(j, m(this.m) + k);
      k = View.combineMeasuredStates(i, this.m.getMeasuredState());
    } 
    j = i2;
    int i1 = n;
    i = k;
    if (t((View)this.i)) {
      j = i2 + r((View)this.i, paramInt1, i2, paramInt2, 0, arrayOfInt);
      i = this.i.getMeasuredHeight();
      i1 = Math.max(n, m((View)this.i) + i);
      i = View.combineMeasuredStates(k, this.i.getMeasuredState());
    } 
    int i4 = getChildCount();
    k = 0;
    n = j;
    while (k < i4) {
      View view = getChildAt(k);
      i3 = n;
      i2 = i1;
      j = i;
      if (((e)view.getLayoutParams()).b == 0)
        if (!t(view)) {
          i3 = n;
          i2 = i1;
          j = i;
        } else {
          i3 = n + r(view, paramInt1, n, paramInt2, 0, arrayOfInt);
          j = view.getMeasuredHeight();
          i2 = Math.max(i1, m(view) + j);
          j = View.combineMeasuredStates(i, view.getMeasuredState());
        }  
      k++;
      n = i3;
      i1 = i2;
      i = j;
    } 
    i2 = this.v + this.w;
    i3 = this.t + this.u;
    if (t((View)this.f)) {
      r((View)this.f, paramInt1, n + i3, paramInt2, i2, arrayOfInt);
      k = this.f.getMeasuredWidth();
      i4 = l((View)this.f);
      j = this.f.getMeasuredHeight();
      int i5 = m((View)this.f);
      i = View.combineMeasuredStates(i, this.f.getMeasuredState());
      j = i5 + j;
      k = i4 + k;
    } else {
      j = 0;
      k = j;
    } 
    if (t((View)this.g)) {
      k = Math.max(k, r((View)this.g, paramInt1, n + i3, paramInt2, j + i2, arrayOfInt));
      i2 = this.g.getMeasuredHeight();
      j = m((View)this.g) + i2 + j;
      i = View.combineMeasuredStates(i, this.g.getMeasuredState());
    } 
    i1 = Math.max(i1, j);
    j = getPaddingLeft();
    i4 = getPaddingRight();
    i2 = getPaddingTop();
    i3 = getPaddingBottom();
    j = View.resolveSizeAndState(Math.max(i4 + j + n + k, getSuggestedMinimumWidth()), paramInt1, 0xFF000000 & i);
    i = View.resolveSizeAndState(Math.max(i3 + i2 + i1, getSuggestedMinimumHeight()), paramInt2, i << 16);
    if (this.R) {
      k = getChildCount();
      paramInt1 = 0;
      while (true) {
        paramInt2 = bool2;
        if (paramInt1 < k) {
          View view = getChildAt(paramInt1);
          if (!t(view) || view.getMeasuredWidth() <= 0 || view.getMeasuredHeight() <= 0) {
            paramInt1++;
            continue;
          } 
        } else {
          break;
        } 
        paramInt2 = 0;
        break;
      } 
      if (paramInt2 != 0) {
        paramInt1 = bool1;
      } else {
        paramInt1 = i;
      } 
      setMeasuredDimension(j, paramInt1);
      return;
    } 
    paramInt2 = 0;
    break;
  }
  
  public void onRestoreInstanceState(Parcelable paramParcelable) {
    if (!(paramParcelable instanceof g)) {
      super.onRestoreInstanceState(paramParcelable);
      return;
    } 
    g g = (g)paramParcelable;
    super.onRestoreInstanceState(g.e);
    ActionMenuView actionMenuView = this.e;
    if (actionMenuView != null) {
      l l = actionMenuView.t;
    } else {
      actionMenuView = null;
    } 
    int i = g.g;
    if (i != 0 && this.O != null && actionMenuView != null) {
      MenuItem menuItem = actionMenuView.findItem(i);
      if (menuItem != null)
        menuItem.expandActionView(); 
    } 
    if (g.h) {
      removeCallbacks(this.S);
      post(this.S);
    } 
  }
  
  public void onRtlPropertiesChanged(int paramInt) {
    super.onRtlPropertiesChanged(paramInt);
    d();
    a2 a21 = this.x;
    boolean bool = true;
    if (paramInt != 1)
      bool = false; 
    if (bool == a21.g)
      return; 
    a21.g = bool;
    if (a21.h) {
      if (bool) {
        paramInt = a21.d;
        if (paramInt == Integer.MIN_VALUE)
          paramInt = a21.e; 
        a21.a = paramInt;
        paramInt = a21.c;
        if (paramInt == Integer.MIN_VALUE)
          paramInt = a21.f; 
        a21.b = paramInt;
        return;
      } 
      paramInt = a21.c;
      if (paramInt == Integer.MIN_VALUE)
        paramInt = a21.e; 
      a21.a = paramInt;
      paramInt = a21.d;
      if (paramInt == Integer.MIN_VALUE)
        paramInt = a21.f; 
      a21.b = paramInt;
      return;
    } 
    a21.a = a21.e;
    a21.b = a21.f;
  }
  
  public Parcelable onSaveInstanceState() {
    g g = new g(super.onSaveInstanceState());
    d d1 = this.O;
    if (d1 != null) {
      o o = d1.f;
      if (o != null)
        g.g = o.a; 
    } 
    g.h = o();
    return (Parcelable)g;
  }
  
  public boolean onTouchEvent(MotionEvent paramMotionEvent) {
    int i = paramMotionEvent.getActionMasked();
    if (i == 0)
      this.F = false; 
    if (!this.F) {
      boolean bool = super.onTouchEvent(paramMotionEvent);
      if (i == 0 && !bool)
        this.F = true; 
    } 
    if (i == 1 || i == 3)
      this.F = false; 
    return true;
  }
  
  public final int p(View paramView, int paramInt1, int[] paramArrayOfint, int paramInt2) {
    e e1 = (e)paramView.getLayoutParams();
    int i = ((ViewGroup.MarginLayoutParams)e1).leftMargin - paramArrayOfint[0];
    paramInt1 = Math.max(0, i) + paramInt1;
    paramArrayOfint[0] = Math.max(0, -i);
    paramInt2 = k(paramView, paramInt2);
    i = paramView.getMeasuredWidth();
    paramView.layout(paramInt1, paramInt2, paramInt1 + i, paramView.getMeasuredHeight() + paramInt2);
    return i + ((ViewGroup.MarginLayoutParams)e1).rightMargin + paramInt1;
  }
  
  public final int q(View paramView, int paramInt1, int[] paramArrayOfint, int paramInt2) {
    e e1 = (e)paramView.getLayoutParams();
    int i = ((ViewGroup.MarginLayoutParams)e1).rightMargin - paramArrayOfint[1];
    paramInt1 -= Math.max(0, i);
    paramArrayOfint[1] = Math.max(0, -i);
    paramInt2 = k(paramView, paramInt2);
    i = paramView.getMeasuredWidth();
    paramView.layout(paramInt1 - i, paramInt2, paramInt1, paramView.getMeasuredHeight() + paramInt2);
    return paramInt1 - i + ((ViewGroup.MarginLayoutParams)e1).leftMargin;
  }
  
  public final int r(View paramView, int paramInt1, int paramInt2, int paramInt3, int paramInt4, int[] paramArrayOfint) {
    ViewGroup.MarginLayoutParams marginLayoutParams = (ViewGroup.MarginLayoutParams)paramView.getLayoutParams();
    int j = marginLayoutParams.leftMargin - paramArrayOfint[0];
    int k = marginLayoutParams.rightMargin - paramArrayOfint[1];
    int i = Math.max(0, j);
    i = Math.max(0, k) + i;
    paramArrayOfint[0] = Math.max(0, -j);
    paramArrayOfint[1] = Math.max(0, -k);
    j = getPaddingLeft();
    paramInt1 = ViewGroup.getChildMeasureSpec(paramInt1, getPaddingRight() + j + i + paramInt2, marginLayoutParams.width);
    paramInt2 = getPaddingTop();
    paramView.measure(paramInt1, ViewGroup.getChildMeasureSpec(paramInt3, getPaddingBottom() + paramInt2 + marginLayoutParams.topMargin + marginLayoutParams.bottomMargin + paramInt4, marginLayoutParams.height));
    return paramView.getMeasuredWidth() + i;
  }
  
  public final void s(View paramView, int paramInt1, int paramInt2, int paramInt3, int paramInt4, int paramInt5) {
    ViewGroup.MarginLayoutParams marginLayoutParams = (ViewGroup.MarginLayoutParams)paramView.getLayoutParams();
    int i = getPaddingLeft();
    i = ViewGroup.getChildMeasureSpec(paramInt1, getPaddingRight() + i + marginLayoutParams.leftMargin + marginLayoutParams.rightMargin + paramInt2, marginLayoutParams.width);
    paramInt1 = getPaddingTop();
    paramInt2 = ViewGroup.getChildMeasureSpec(paramInt3, getPaddingBottom() + paramInt1 + marginLayoutParams.topMargin + marginLayoutParams.bottomMargin + paramInt4, marginLayoutParams.height);
    paramInt3 = View.MeasureSpec.getMode(paramInt2);
    paramInt1 = paramInt2;
    if (paramInt3 != 1073741824) {
      paramInt1 = paramInt2;
      if (paramInt5 >= 0) {
        paramInt1 = paramInt5;
        if (paramInt3 != 0)
          paramInt1 = Math.min(View.MeasureSpec.getSize(paramInt2), paramInt5); 
        paramInt1 = View.MeasureSpec.makeMeasureSpec(paramInt1, 1073741824);
      } 
    } 
    paramView.measure(i, paramInt1);
  }
  
  public void setCollapseContentDescription(int paramInt) {
    CharSequence charSequence;
    if (paramInt != 0) {
      charSequence = getContext().getText(paramInt);
    } else {
      charSequence = null;
    } 
    setCollapseContentDescription(charSequence);
  }
  
  public void setCollapseContentDescription(CharSequence paramCharSequence) {
    if (!TextUtils.isEmpty(paramCharSequence))
      c(); 
    ImageButton imageButton = this.l;
    if (imageButton != null)
      imageButton.setContentDescription(paramCharSequence); 
  }
  
  public void setCollapseIcon(int paramInt) {
    setCollapseIcon(c.b.d.a.a.a(getContext(), paramInt));
  }
  
  public void setCollapseIcon(Drawable paramDrawable) {
    if (paramDrawable != null) {
      c();
      this.l.setImageDrawable(paramDrawable);
      return;
    } 
    ImageButton imageButton = this.l;
    if (imageButton != null)
      imageButton.setImageDrawable(this.j); 
  }
  
  public void setCollapsible(boolean paramBoolean) {
    this.R = paramBoolean;
    requestLayout();
  }
  
  public void setContentInsetEndWithActions(int paramInt) {
    int i = paramInt;
    if (paramInt < 0)
      i = Integer.MIN_VALUE; 
    if (i != this.z) {
      this.z = i;
      if (getNavigationIcon() != null)
        requestLayout(); 
    } 
  }
  
  public void setContentInsetStartWithNavigation(int paramInt) {
    int i = paramInt;
    if (paramInt < 0)
      i = Integer.MIN_VALUE; 
    if (i != this.y) {
      this.y = i;
      if (getNavigationIcon() != null)
        requestLayout(); 
    } 
  }
  
  public void setLogo(int paramInt) {
    setLogo(c.b.d.a.a.a(getContext(), paramInt));
  }
  
  public void setLogo(Drawable paramDrawable) {
    if (paramDrawable != null) {
      if (this.i == null)
        this.i = new AppCompatImageView(getContext(), null); 
      if (!n((View)this.i))
        b((View)this.i, true); 
    } else {
      ImageView imageView1 = this.i;
      if (imageView1 != null && n((View)imageView1)) {
        removeView((View)this.i);
        this.I.remove(this.i);
      } 
    } 
    ImageView imageView = this.i;
    if (imageView != null)
      imageView.setImageDrawable(paramDrawable); 
  }
  
  public void setLogoDescription(int paramInt) {
    setLogoDescription(getContext().getText(paramInt));
  }
  
  public void setLogoDescription(CharSequence paramCharSequence) {
    if (!TextUtils.isEmpty(paramCharSequence) && this.i == null)
      this.i = new AppCompatImageView(getContext(), null); 
    ImageView imageView = this.i;
    if (imageView != null)
      imageView.setContentDescription(paramCharSequence); 
  }
  
  public void setNavigationContentDescription(int paramInt) {
    CharSequence charSequence;
    if (paramInt != 0) {
      charSequence = getContext().getText(paramInt);
    } else {
      charSequence = null;
    } 
    setNavigationContentDescription(charSequence);
  }
  
  public void setNavigationContentDescription(CharSequence paramCharSequence) {
    if (!TextUtils.isEmpty(paramCharSequence))
      g(); 
    ImageButton imageButton = this.h;
    if (imageButton != null)
      imageButton.setContentDescription(paramCharSequence); 
  }
  
  public void setNavigationIcon(int paramInt) {
    setNavigationIcon(c.b.d.a.a.a(getContext(), paramInt));
  }
  
  public void setNavigationIcon(Drawable paramDrawable) {
    if (paramDrawable != null) {
      g();
      if (!n((View)this.h))
        b((View)this.h, true); 
    } else {
      ImageButton imageButton1 = this.h;
      if (imageButton1 != null && n((View)imageButton1)) {
        removeView((View)this.h);
        this.I.remove(this.h);
      } 
    } 
    ImageButton imageButton = this.h;
    if (imageButton != null)
      imageButton.setImageDrawable(paramDrawable); 
  }
  
  public void setNavigationOnClickListener(View.OnClickListener paramOnClickListener) {
    g();
    this.h.setOnClickListener(paramOnClickListener);
  }
  
  public void setOnMenuItemClickListener(f paramf) {
    this.K = paramf;
  }
  
  public void setOverflowIcon(Drawable paramDrawable) {
    e();
    this.e.setOverflowIcon(paramDrawable);
  }
  
  public void setPopupTheme(int paramInt) {
    if (this.o != paramInt) {
      this.o = paramInt;
      if (paramInt == 0) {
        this.n = getContext();
        return;
      } 
      this.n = (Context)new ContextThemeWrapper(getContext(), paramInt);
    } 
  }
  
  public void setSubtitle(int paramInt) {
    setSubtitle(getContext().getText(paramInt));
  }
  
  public void setSubtitle(CharSequence paramCharSequence) {
    if (!TextUtils.isEmpty(paramCharSequence)) {
      if (this.g == null) {
        Context context = getContext();
        u0 u0 = new u0(context);
        this.g = (TextView)u0;
        u0.setSingleLine();
        this.g.setEllipsize(TextUtils.TruncateAt.END);
        int i = this.q;
        if (i != 0)
          this.g.setTextAppearance(context, i); 
        ColorStateList colorStateList = this.E;
        if (colorStateList != null)
          this.g.setTextColor(colorStateList); 
      } 
      if (!n((View)this.g))
        b((View)this.g, true); 
    } else {
      TextView textView1 = this.g;
      if (textView1 != null && n((View)textView1)) {
        removeView((View)this.g);
        this.I.remove(this.g);
      } 
    } 
    TextView textView = this.g;
    if (textView != null)
      textView.setText(paramCharSequence); 
    this.C = paramCharSequence;
  }
  
  public void setSubtitleTextColor(int paramInt) {
    setSubtitleTextColor(ColorStateList.valueOf(paramInt));
  }
  
  public void setSubtitleTextColor(ColorStateList paramColorStateList) {
    this.E = paramColorStateList;
    TextView textView = this.g;
    if (textView != null)
      textView.setTextColor(paramColorStateList); 
  }
  
  public void setTitle(int paramInt) {
    setTitle(getContext().getText(paramInt));
  }
  
  public void setTitle(CharSequence paramCharSequence) {
    if (!TextUtils.isEmpty(paramCharSequence)) {
      if (this.f == null) {
        Context context = getContext();
        u0 u0 = new u0(context);
        this.f = (TextView)u0;
        u0.setSingleLine();
        this.f.setEllipsize(TextUtils.TruncateAt.END);
        int i = this.p;
        if (i != 0)
          this.f.setTextAppearance(context, i); 
        ColorStateList colorStateList = this.D;
        if (colorStateList != null)
          this.f.setTextColor(colorStateList); 
      } 
      if (!n((View)this.f))
        b((View)this.f, true); 
    } else {
      TextView textView1 = this.f;
      if (textView1 != null && n((View)textView1)) {
        removeView((View)this.f);
        this.I.remove(this.f);
      } 
    } 
    TextView textView = this.f;
    if (textView != null)
      textView.setText(paramCharSequence); 
    this.B = paramCharSequence;
  }
  
  public void setTitleMarginBottom(int paramInt) {
    this.w = paramInt;
    requestLayout();
  }
  
  public void setTitleMarginEnd(int paramInt) {
    this.u = paramInt;
    requestLayout();
  }
  
  public void setTitleMarginStart(int paramInt) {
    this.t = paramInt;
    requestLayout();
  }
  
  public void setTitleMarginTop(int paramInt) {
    this.v = paramInt;
    requestLayout();
  }
  
  public void setTitleTextColor(int paramInt) {
    setTitleTextColor(ColorStateList.valueOf(paramInt));
  }
  
  public void setTitleTextColor(ColorStateList paramColorStateList) {
    this.D = paramColorStateList;
    TextView textView = this.f;
    if (textView != null)
      textView.setTextColor(paramColorStateList); 
  }
  
  public final boolean t(View paramView) {
    return (paramView != null && paramView.getParent() == this && paramView.getVisibility() != 8);
  }
  
  public boolean u() {
    ActionMenuView actionMenuView = this.e;
    if (actionMenuView != null) {
      boolean bool;
      m m1 = actionMenuView.x;
      if (m1 != null && m1.p()) {
        bool = true;
      } else {
        bool = false;
      } 
      if (bool)
        return true; 
    } 
    return false;
  }
  
  public class a implements ActionMenuView.e {
    public a(Toolbar this$0) {}
  }
  
  public class b implements Runnable {
    public b(Toolbar this$0) {}
    
    public void run() {
      this.e.u();
    }
  }
  
  public class c implements View.OnClickListener {
    public c(Toolbar this$0) {}
    
    public void onClick(View param1View) {
      o o;
      Toolbar.d d = this.e.O;
      if (d == null) {
        d = null;
      } else {
        o = d.f;
      } 
      if (o != null)
        o.collapseActionView(); 
    }
  }
  
  public class d implements y {
    public l e;
    
    public o f;
    
    public d(Toolbar this$0) {}
    
    public void a(l param1l, boolean param1Boolean) {}
    
    public void c(Context param1Context, l param1l) {
      l l1 = this.e;
      if (l1 != null) {
        o o1 = this.f;
        if (o1 != null)
          l1.d(o1); 
      } 
      this.e = param1l;
    }
    
    public void e(Parcelable param1Parcelable) {}
    
    public boolean f(f0 param1f0) {
      return false;
    }
    
    public int getId() {
      return 0;
    }
    
    public void h(boolean param1Boolean) {
      if (this.f != null) {
        l l1 = this.e;
        boolean bool2 = false;
        boolean bool1 = bool2;
        if (l1 != null) {
          int j = l1.size();
          int i = 0;
          while (true) {
            bool1 = bool2;
            if (i < j) {
              if (this.e.getItem(i) == this.f) {
                bool1 = true;
                break;
              } 
              i++;
              continue;
            } 
            break;
          } 
        } 
        if (!bool1)
          k(this.e, this.f); 
      } 
    }
    
    public boolean i() {
      return false;
    }
    
    public Parcelable j() {
      return null;
    }
    
    public boolean k(l param1l, o param1o) {
      View view = this.g.m;
      if (view instanceof c.b.g.c)
        ((c.b.g.c)view).d(); 
      Toolbar toolbar = this.g;
      toolbar.removeView(toolbar.m);
      toolbar = this.g;
      toolbar.removeView((View)toolbar.l);
      toolbar = this.g;
      toolbar.m = null;
      int i = toolbar.I.size();
      while (true) {
        if (--i >= 0) {
          toolbar.addView(toolbar.I.get(i));
          continue;
        } 
        toolbar.I.clear();
        this.f = null;
        this.g.requestLayout();
        param1o.C = false;
        param1o.n.q(false);
        return true;
      } 
    }
    
    public boolean l(l param1l, o param1o) {
      this.g.c();
      ViewParent viewParent = this.g.l.getParent();
      Toolbar toolbar2 = this.g;
      if (viewParent != toolbar2) {
        if (viewParent instanceof ViewGroup)
          ((ViewGroup)viewParent).removeView((View)toolbar2.l); 
        Toolbar toolbar = this.g;
        toolbar.addView((View)toolbar.l);
      } 
      this.g.m = param1o.getActionView();
      this.f = param1o;
      viewParent = this.g.m.getParent();
      toolbar2 = this.g;
      if (viewParent != toolbar2) {
        if (viewParent instanceof ViewGroup)
          ((ViewGroup)viewParent).removeView(toolbar2.m); 
        Toolbar.e e = this.g.h();
        toolbar2 = this.g;
        e.a = 0x800003 | toolbar2.r & 0x70;
        e.b = 2;
        toolbar2.m.setLayoutParams((ViewGroup.LayoutParams)e);
        Toolbar toolbar = this.g;
        toolbar.addView(toolbar.m);
      } 
      Toolbar toolbar1 = this.g;
      int i = toolbar1.getChildCount();
      while (true) {
        int j = i - 1;
        if (j >= 0) {
          View view1 = toolbar1.getChildAt(j);
          i = j;
          if (((Toolbar.e)view1.getLayoutParams()).b != 2) {
            i = j;
            if (view1 != toolbar1.e) {
              toolbar1.removeViewAt(j);
              toolbar1.I.add(view1);
              i = j;
            } 
          } 
          continue;
        } 
        this.g.requestLayout();
        param1o.C = true;
        param1o.n.q(false);
        View view = this.g.m;
        if (view instanceof c.b.g.c)
          ((c.b.g.c)view).c(); 
        return true;
      } 
    }
  }
  
  public static class e extends c.b.c.a.a {
    public int b = 0;
    
    public e(int param1Int1, int param1Int2) {
      super(param1Int1, param1Int2);
      this.a = 8388627;
    }
    
    public e(Context param1Context, AttributeSet param1AttributeSet) {
      super(param1Context, param1AttributeSet);
    }
    
    public e(ViewGroup.LayoutParams param1LayoutParams) {
      super(param1LayoutParams);
    }
    
    public e(ViewGroup.MarginLayoutParams param1MarginLayoutParams) {
      super((ViewGroup.LayoutParams)param1MarginLayoutParams);
      ((ViewGroup.MarginLayoutParams)this).leftMargin = param1MarginLayoutParams.leftMargin;
      ((ViewGroup.MarginLayoutParams)this).topMargin = param1MarginLayoutParams.topMargin;
      ((ViewGroup.MarginLayoutParams)this).rightMargin = param1MarginLayoutParams.rightMargin;
      ((ViewGroup.MarginLayoutParams)this).bottomMargin = param1MarginLayoutParams.bottomMargin;
    }
    
    public e(e param1e) {
      super(param1e);
      this.b = param1e.b;
    }
    
    public e(c.b.c.a.a param1a) {
      super(param1a);
    }
  }
  
  public static interface f {}
  
  public static class g extends c.j.a.c {
    public static final Parcelable.Creator<g> CREATOR = (Parcelable.Creator<g>)new k2();
    
    public int g;
    
    public boolean h;
    
    public g(Parcel param1Parcel, ClassLoader param1ClassLoader) {
      super(param1Parcel, param1ClassLoader);
      boolean bool;
      this.g = param1Parcel.readInt();
      if (param1Parcel.readInt() != 0) {
        bool = true;
      } else {
        bool = false;
      } 
      this.h = bool;
    }
    
    public g(Parcelable param1Parcelable) {
      super(param1Parcelable);
    }
    
    public void writeToParcel(Parcel param1Parcel, int param1Int) {
      throw new RuntimeException("d2j fail translate: java.lang.RuntimeException: can not merge I and Z\r\n\tat com.googlecode.dex2jar.ir.TypeClass.merge(TypeClass.java:100)\r\n\tat com.googlecode.dex2jar.ir.ts.TypeTransformer$TypeRef.updateTypeClass(TypeTransformer.java:174)\r\n\tat com.googlecode.dex2jar.ir.ts.TypeTransformer$TypeAnalyze.provideAs(TypeTransformer.java:780)\r\n\tat com.googlecode.dex2jar.ir.ts.TypeTransformer$TypeAnalyze.e1expr(TypeTransformer.java:496)\r\n\tat com.googlecode.dex2jar.ir.ts.TypeTransformer$TypeAnalyze.exExpr(TypeTransformer.java:713)\r\n\tat com.googlecode.dex2jar.ir.ts.TypeTransformer$TypeAnalyze.exExpr(TypeTransformer.java:703)\r\n\tat com.googlecode.dex2jar.ir.ts.TypeTransformer$TypeAnalyze.enexpr(TypeTransformer.java:698)\r\n\tat com.googlecode.dex2jar.ir.ts.TypeTransformer$TypeAnalyze.exExpr(TypeTransformer.java:719)\r\n\tat com.googlecode.dex2jar.ir.ts.TypeTransformer$TypeAnalyze.exExpr(TypeTransformer.java:703)\r\n\tat com.googlecode.dex2jar.ir.ts.TypeTransformer$TypeAnalyze.s1stmt(TypeTransformer.java:810)\r\n\tat com.googlecode.dex2jar.ir.ts.TypeTransformer$TypeAnalyze.sxStmt(TypeTransformer.java:840)\r\n\tat com.googlecode.dex2jar.ir.ts.TypeTransformer$TypeAnalyze.analyze(TypeTransformer.java:206)\r\n\tat com.googlecode.dex2jar.ir.ts.TypeTransformer.transform(TypeTransformer.java:44)\r\n\tat com.googlecode.d2j.dex.Dex2jar$2.optimize(Dex2jar.java:162)\r\n\tat com.googlecode.d2j.dex.Dex2Asm.convertCode(Dex2Asm.java:414)\r\n\tat com.googlecode.d2j.dex.ExDex2Asm.convertCode(ExDex2Asm.java:42)\r\n\tat com.googlecode.d2j.dex.Dex2jar$2.convertCode(Dex2jar.java:128)\r\n\tat com.googlecode.d2j.dex.Dex2Asm.convertMethod(Dex2Asm.java:509)\r\n\tat com.googlecode.d2j.dex.Dex2Asm.convertClass(Dex2Asm.java:406)\r\n\tat com.googlecode.d2j.dex.Dex2Asm.convertDex(Dex2Asm.java:422)\r\n\tat com.googlecode.d2j.dex.Dex2jar.doTranslate(Dex2jar.java:172)\r\n\tat com.googlecode.d2j.dex.Dex2jar.to(Dex2jar.java:272)\r\n\tat com.googlecode.dex2jar.tools.Dex2jarCmd.doCommandLine(Dex2jarCmd.java:108)\r\n\tat com.googlecode.dex2jar.tools.BaseCmd.doMain(BaseCmd.java:288)\r\n\tat com.googlecode.dex2jar.tools.Dex2jarCmd.main(Dex2jarCmd.java:32)\r\n");
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Https Traffic-dex2jar.jar!\androidx\appcompat\widget\Toolbar.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */