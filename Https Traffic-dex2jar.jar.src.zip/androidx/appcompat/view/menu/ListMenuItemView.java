package androidx.appcompat.view.menu;

import android.content.Context;
import android.content.res.Resources;
import android.content.res.TypedArray;
import android.graphics.Rect;
import android.graphics.drawable.Drawable;
import android.util.AttributeSet;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewConfiguration;
import android.view.ViewGroup;
import android.widget.AbsListView;
import android.widget.CheckBox;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.RadioButton;
import android.widget.TextView;
import c.b.b;
import c.b.g.n.o;
import c.b.g.n.z;
import c.b.h.j2;
import c.h.j.u;
import java.util.Objects;
import java.util.concurrent.atomic.AtomicInteger;

public class ListMenuItemView extends LinearLayout implements z.a, AbsListView.SelectionBoundsAdjuster {
  public o e;
  
  public ImageView f;
  
  public RadioButton g;
  
  public TextView h;
  
  public CheckBox i;
  
  public TextView j;
  
  public ImageView k;
  
  public ImageView l;
  
  public LinearLayout m;
  
  public Drawable n;
  
  public int o;
  
  public Context p;
  
  public boolean q;
  
  public Drawable r;
  
  public boolean s;
  
  public LayoutInflater t;
  
  public boolean u;
  
  public ListMenuItemView(Context paramContext, AttributeSet paramAttributeSet) {
    super(paramContext, paramAttributeSet);
    j2 j2 = j2.q(getContext(), paramAttributeSet, b.s, 2130903571, 0);
    this.n = j2.g(5);
    this.o = j2.l(1, -1);
    this.q = j2.a(7, false);
    this.p = paramContext;
    this.r = j2.g(8);
    TypedArray typedArray = paramContext.getTheme().obtainStyledAttributes(null, new int[] { 16843049 }, 2130903333, 0);
    this.s = typedArray.hasValue(0);
    j2.b.recycle();
    typedArray.recycle();
  }
  
  private LayoutInflater getInflater() {
    if (this.t == null)
      this.t = LayoutInflater.from(getContext()); 
    return this.t;
  }
  
  private void setSubMenuArrowVisible(boolean paramBoolean) {
    ImageView imageView = this.k;
    if (imageView != null) {
      byte b;
      if (paramBoolean) {
        b = 0;
      } else {
        b = 8;
      } 
      imageView.setVisibility(b);
    } 
  }
  
  public final void a() {
    CheckBox checkBox = (CheckBox)getInflater().inflate(2131427342, (ViewGroup)this, false);
    this.i = checkBox;
    LinearLayout linearLayout = this.m;
    if (linearLayout != null) {
      linearLayout.addView((View)checkBox, -1);
      return;
    } 
    addView((View)checkBox, -1);
  }
  
  public void adjustListItemSelectionBounds(Rect paramRect) {
    ImageView imageView = this.l;
    if (imageView != null && imageView.getVisibility() == 0) {
      LinearLayout.LayoutParams layoutParams = (LinearLayout.LayoutParams)this.l.getLayoutParams();
      int i = paramRect.top;
      paramRect.top = this.l.getHeight() + layoutParams.topMargin + layoutParams.bottomMargin + i;
    } 
  }
  
  public final void b() {
    RadioButton radioButton = (RadioButton)getInflater().inflate(2131427345, (ViewGroup)this, false);
    this.g = radioButton;
    LinearLayout linearLayout = this.m;
    if (linearLayout != null) {
      linearLayout.addView((View)radioButton, -1);
      return;
    } 
    addView((View)radioButton, -1);
  }
  
  public void c(boolean paramBoolean) {
    byte b;
    if (paramBoolean && this.e.n()) {
      b = 0;
    } else {
      b = 8;
    } 
    if (b == 0) {
      String str;
      TextView textView = this.j;
      o o1 = this.e;
      char c = o1.e();
      if (c == '\000') {
        str = "";
      } else {
        int i;
        Resources resources = ((o)str).n.a.getResources();
        StringBuilder stringBuilder = new StringBuilder();
        if (ViewConfiguration.get(((o)str).n.a).hasPermanentMenuKey())
          stringBuilder.append(resources.getString(2131755025)); 
        if (((o)str).n.n()) {
          i = ((o)str).k;
        } else {
          i = ((o)str).i;
        } 
        o.c(stringBuilder, i, 65536, resources.getString(2131755021));
        o.c(stringBuilder, i, 4096, resources.getString(2131755017));
        o.c(stringBuilder, i, 2, resources.getString(2131755016));
        o.c(stringBuilder, i, 1, resources.getString(2131755022));
        o.c(stringBuilder, i, 4, resources.getString(2131755024));
        o.c(stringBuilder, i, 8, resources.getString(2131755020));
        if (c != '\b') {
          if (c != '\n') {
            if (c != ' ') {
              stringBuilder.append(c);
            } else {
              stringBuilder.append(resources.getString(2131755023));
            } 
          } else {
            stringBuilder.append(resources.getString(2131755019));
          } 
        } else {
          stringBuilder.append(resources.getString(2131755018));
        } 
        str = stringBuilder.toString();
      } 
      textView.setText(str);
    } 
    if (this.j.getVisibility() != b)
      this.j.setVisibility(b); 
  }
  
  public void f(o paramo, int paramInt) {
    this.e = paramo;
    if (paramo.isVisible()) {
      paramInt = 0;
    } else {
      paramInt = 8;
    } 
    setVisibility(paramInt);
    setTitle(paramo.e);
    setCheckable(paramo.isCheckable());
    boolean bool = paramo.n();
    paramo.e();
    c(bool);
    setIcon(paramo.getIcon());
    setEnabled(paramo.isEnabled());
    setSubMenuArrowVisible(paramo.hasSubMenu());
    setContentDescription(paramo.q);
  }
  
  public o getItemData() {
    return this.e;
  }
  
  public void onFinishInflate() {
    super.onFinishInflate();
    Drawable drawable = this.n;
    AtomicInteger atomicInteger = u.a;
    setBackground(drawable);
    TextView textView = (TextView)findViewById(2131231145);
    this.h = textView;
    int i = this.o;
    if (i != -1)
      textView.setTextAppearance(this.p, i); 
    this.j = (TextView)findViewById(2131231077);
    ImageView imageView = (ImageView)findViewById(2131231108);
    this.k = imageView;
    if (imageView != null)
      imageView.setImageDrawable(this.r); 
    this.l = (ImageView)findViewById(2131230914);
    this.m = (LinearLayout)findViewById(2131230843);
  }
  
  public void onMeasure(int paramInt1, int paramInt2) {
    if (this.f != null && this.q) {
      ViewGroup.LayoutParams layoutParams = getLayoutParams();
      LinearLayout.LayoutParams layoutParams1 = (LinearLayout.LayoutParams)this.f.getLayoutParams();
      int i = layoutParams.height;
      if (i > 0 && layoutParams1.width <= 0)
        layoutParams1.width = i; 
    } 
    super.onMeasure(paramInt1, paramInt2);
  }
  
  public void setCheckable(boolean paramBoolean) {
    CheckBox checkBox;
    RadioButton radioButton;
    if (!paramBoolean && this.g == null && this.i == null)
      return; 
    if (this.e.h()) {
      if (this.g == null)
        b(); 
      RadioButton radioButton1 = this.g;
      CheckBox checkBox1 = this.i;
    } else {
      if (this.i == null)
        a(); 
      checkBox = this.i;
      radioButton = this.g;
    } 
    if (paramBoolean) {
      checkBox.setChecked(this.e.isChecked());
      if (checkBox.getVisibility() != 0)
        checkBox.setVisibility(0); 
      if (radioButton != null && radioButton.getVisibility() != 8) {
        radioButton.setVisibility(8);
        return;
      } 
    } else {
      checkBox = this.i;
      if (checkBox != null)
        checkBox.setVisibility(8); 
      RadioButton radioButton1 = this.g;
      if (radioButton1 != null)
        radioButton1.setVisibility(8); 
    } 
  }
  
  public void setChecked(boolean paramBoolean) {
    CheckBox checkBox;
    if (this.e.h()) {
      if (this.g == null)
        b(); 
      RadioButton radioButton = this.g;
    } else {
      if (this.i == null)
        a(); 
      checkBox = this.i;
    } 
    checkBox.setChecked(paramBoolean);
  }
  
  public void setForceShowIcon(boolean paramBoolean) {
    this.u = paramBoolean;
    this.q = paramBoolean;
  }
  
  public void setGroupDividerEnabled(boolean paramBoolean) {
    ImageView imageView = this.l;
    if (imageView != null) {
      byte b;
      if (!this.s && paramBoolean) {
        b = 0;
      } else {
        b = 8;
      } 
      imageView.setVisibility(b);
    } 
  }
  
  public void setIcon(Drawable paramDrawable) {
    boolean bool;
    Objects.requireNonNull(this.e.n);
    if (this.u) {
      bool = true;
    } else {
      bool = false;
    } 
    if (!bool && !this.q)
      return; 
    ImageView imageView = this.f;
    if (imageView == null && paramDrawable == null && !this.q)
      return; 
    if (imageView == null) {
      imageView = (ImageView)getInflater().inflate(2131427343, (ViewGroup)this, false);
      this.f = imageView;
      LinearLayout linearLayout = this.m;
      if (linearLayout != null) {
        linearLayout.addView((View)imageView, 0);
      } else {
        addView((View)imageView, 0);
      } 
    } 
    if (paramDrawable != null || this.q) {
      imageView = this.f;
      if (!bool)
        paramDrawable = null; 
      imageView.setImageDrawable(paramDrawable);
      if (this.f.getVisibility() != 0)
        this.f.setVisibility(0); 
      return;
    } 
    this.f.setVisibility(8);
  }
  
  public void setTitle(CharSequence paramCharSequence) {
    if (paramCharSequence != null) {
      this.h.setText(paramCharSequence);
      if (this.h.getVisibility() != 0) {
        this.h.setVisibility(0);
        return;
      } 
    } else if (this.h.getVisibility() != 8) {
      this.h.setVisibility(8);
    } 
  }
}


/* Location:              C:\soft\dex2jar-2.0\Https Traffic-dex2jar.jar!\androidx\appcompat\view\menu\ListMenuItemView.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */