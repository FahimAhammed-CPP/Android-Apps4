package androidx.work;

import c.b0.g;
import c.b0.j;
import java.util.Collections;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;

public final class OverwritingInputMerger extends j {
  public g a(List<g> paramList) {
    g.a a = new g.a();
    HashMap<Object, Object> hashMap = new HashMap<Object, Object>();
    Iterator<g> iterator = paramList.iterator();
    while (iterator.hasNext())
      hashMap.putAll(Collections.unmodifiableMap(((g)iterator.next()).a)); 
    a.b(hashMap);
    return a.a();
  }
}


/* Location:              C:\soft\dex2jar-2.0\Https Traffic-dex2jar.jar!\androidx\work\OverwritingInputMerger.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */