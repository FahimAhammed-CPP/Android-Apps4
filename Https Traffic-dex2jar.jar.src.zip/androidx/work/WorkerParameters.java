package androidx.work;

import android.net.Network;
import android.net.Uri;
import c.b0.e0;
import c.b0.g;
import c.b0.i;
import c.b0.y;
import java.util.Collection;
import java.util.Collections;
import java.util.HashSet;
import java.util.List;
import java.util.Set;
import java.util.UUID;
import java.util.concurrent.Executor;

public final class WorkerParameters {
  public UUID a;
  
  public g b;
  
  public Set<String> c;
  
  public a d;
  
  public int e;
  
  public Executor f;
  
  public c.b0.f0.c0.a0.a g;
  
  public e0 h;
  
  public y i;
  
  public i j;
  
  public WorkerParameters(UUID paramUUID, g paramg, Collection<String> paramCollection, a parama, int paramInt, Executor paramExecutor, c.b0.f0.c0.a0.a parama1, e0 parame0, y paramy, i parami) {
    this.a = paramUUID;
    this.b = paramg;
    this.c = new HashSet<String>(paramCollection);
    this.d = parama;
    this.e = paramInt;
    this.f = paramExecutor;
    this.g = parama1;
    this.h = parame0;
    this.i = paramy;
    this.j = parami;
  }
  
  public static class a {
    public List<String> a = Collections.emptyList();
    
    public List<Uri> b = Collections.emptyList();
    
    public Network c;
  }
}


/* Location:              C:\soft\dex2jar-2.0\Https Traffic-dex2jar.jar!\androidx\work\WorkerParameters.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */