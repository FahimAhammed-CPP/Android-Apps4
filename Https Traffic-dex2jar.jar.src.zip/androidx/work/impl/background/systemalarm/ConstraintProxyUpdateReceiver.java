package androidx.work.impl.background.systemalarm;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import c.b0.f0.c0.a0.c;
import c.b0.f0.c0.g;
import c.b0.f0.t;
import c.b0.o;

public class ConstraintProxyUpdateReceiver extends BroadcastReceiver {
  public static final String a = o.e("ConstrntProxyUpdtRecvr");
  
  public void onReceive(Context paramContext, Intent paramIntent) {
    if (paramIntent != null) {
      a1 = (c.b0.f0.c0.a0.a)paramIntent.getAction();
    } else {
      a1 = null;
    } 
    if (!"androidx.work.impl.background.systemalarm.UpdateProxies".equals(a1)) {
      o.c().a(a, String.format("Ignoring unknown action %s", new Object[] { a1 }), new Throwable[0]);
      return;
    } 
    BroadcastReceiver.PendingResult pendingResult = goAsync();
    c.b0.f0.c0.a0.a a1 = (t.b(paramContext)).d;
    a a = new a(this, paramIntent, paramContext, pendingResult);
    ((c)a1).a.execute(a);
  }
  
  public class a implements Runnable {
    public a(ConstraintProxyUpdateReceiver this$0, Intent param1Intent, Context param1Context, BroadcastReceiver.PendingResult param1PendingResult) {}
    
    public void run() {
      try {
        boolean bool1 = this.e.getBooleanExtra("KEY_BATTERY_NOT_LOW_PROXY_ENABLED", false);
        boolean bool2 = this.e.getBooleanExtra("KEY_BATTERY_CHARGING_PROXY_ENABLED", false);
        boolean bool3 = this.e.getBooleanExtra("KEY_STORAGE_NOT_LOW_PROXY_ENABLED", false);
        boolean bool4 = this.e.getBooleanExtra("KEY_NETWORK_STATE_PROXY_ENABLED", false);
        o.c().a(ConstraintProxyUpdateReceiver.a, String.format("Updating proxies: BatteryNotLowProxy enabled (%s), BatteryChargingProxy enabled (%s), StorageNotLowProxy (%s), NetworkStateProxy enabled (%s)", new Object[] { Boolean.valueOf(bool1), Boolean.valueOf(bool2), Boolean.valueOf(bool3), Boolean.valueOf(bool4) }), new Throwable[0]);
        g.a(this.f, ConstraintProxy.BatteryNotLowProxy.class, bool1);
        g.a(this.f, ConstraintProxy.BatteryChargingProxy.class, bool2);
        g.a(this.f, ConstraintProxy.StorageNotLowProxy.class, bool3);
        g.a(this.f, ConstraintProxy.NetworkStateProxy.class, bool4);
        return;
      } finally {
        this.g.finish();
      } 
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Https Traffic-dex2jar.jar!\androidx\work\impl\background\systemalarm\ConstraintProxyUpdateReceiver.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */