package androidx.work.impl.background.systemalarm;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import c.b0.f0.t;
import c.b0.o;

public class RescheduleReceiver extends BroadcastReceiver {
  public static final String a = o.e("RescheduleReceiver");
  
  public void onReceive(Context paramContext, Intent paramIntent) {
    o.c().a(a, String.format("Received intent %s", new Object[] { paramIntent }), new Throwable[0]);
    try {
      null = t.b(paramContext);
      BroadcastReceiver.PendingResult pendingResult = goAsync();
      synchronized (t.l) {
        null.i = pendingResult;
        if (null.h) {
          pendingResult.finish();
          null.i = null;
        } 
        return;
      } 
    } catch (IllegalStateException illegalStateException) {
      o.c().b(a, "Cannot reschedule jobs. WorkManager needs to be initialized via a ContentProvider#onCreate() or an Application#onCreate().", new Throwable[] { illegalStateException });
      return;
    } 
  }
}


/* Location:              C:\soft\dex2jar-2.0\Https Traffic-dex2jar.jar!\androidx\work\impl\background\systemalarm\RescheduleReceiver.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */