package androidx.work.impl.workers;

import android.content.Context;
import android.database.Cursor;
import android.text.TextUtils;
import androidx.work.ListenableWorker;
import androidx.work.Worker;
import androidx.work.WorkerParameters;
import androidx.work.impl.WorkDatabase;
import c.b0.d;
import c.b0.f0.b0.c0;
import c.b0.f0.b0.f0;
import c.b0.f0.b0.g;
import c.b0.f0.b0.j;
import c.b0.f0.b0.m;
import c.b0.f0.b0.t;
import c.b0.f0.t;
import c.b0.g;
import c.b0.n;
import c.b0.o;
import c.h.b.h;
import c.u.q;
import c.u.u.a;
import c.w.a.e;
import java.util.ArrayList;
import java.util.List;
import java.util.Objects;
import java.util.concurrent.TimeUnit;

public class DiagnosticsWorker extends Worker {
  public static final String k = o.e("DiagnosticsWrkr");
  
  public DiagnosticsWorker(Context paramContext, WorkerParameters paramWorkerParameters) {
    super(paramContext, paramWorkerParameters);
  }
  
  public static String a(m paramm, f0 paramf0, j paramj, List<t> paramList) {
    StringBuilder stringBuilder = new StringBuilder();
    stringBuilder.append(String.format("\n Id \t Class Name\t %s\t State\t Unique Name\t Tags\t", new Object[] { "Job Id" }));
    for (t t : paramList) {
      String str1;
      String str2;
      g g = paramj.a(t.a);
      if (g != null) {
        Integer integer = Integer.valueOf(g.b);
      } else {
        g = null;
      } 
      String str3 = t.a;
      Objects.requireNonNull(paramm);
      q q = q.d("SELECT name FROM workname WHERE work_spec_id=?", 1);
      if (str3 == null) {
        q.f(1);
      } else {
        q.g(1, str3);
      } 
      paramm.a.b();
      Cursor cursor = a.a(paramm.a, (e)q, false, null);
      try {
        ArrayList<String> arrayList = new ArrayList(cursor.getCount());
        while (cursor.moveToNext())
          arrayList.add(cursor.getString(0)); 
        cursor.close();
        q.h();
        List list = paramf0.a(t.a);
        str2 = TextUtils.join(",", arrayList);
      } finally {
        str2.close();
        str1.h();
      } 
    } 
    return stringBuilder.toString();
  }
  
  public ListenableWorker.a doWork() {
    List<t> list;
    String str;
    WorkDatabase workDatabase = (t.b(getApplicationContext())).c;
    c0 c0 = workDatabase.q();
    m m = workDatabase.o();
    f0 f0 = workDatabase.r();
    j j = workDatabase.n();
    long l1 = System.currentTimeMillis();
    long l2 = TimeUnit.DAYS.toMillis(1L);
    Objects.requireNonNull(c0);
    q q = q.d("SELECT `required_network_type`, `requires_charging`, `requires_device_idle`, `requires_battery_not_low`, `requires_storage_not_low`, `trigger_content_update_delay`, `trigger_max_content_delay`, `content_uri_triggers`, `WorkSpec`.`id` AS `id`, `WorkSpec`.`state` AS `state`, `WorkSpec`.`worker_class_name` AS `worker_class_name`, `WorkSpec`.`input_merger_class_name` AS `input_merger_class_name`, `WorkSpec`.`input` AS `input`, `WorkSpec`.`output` AS `output`, `WorkSpec`.`initial_delay` AS `initial_delay`, `WorkSpec`.`interval_duration` AS `interval_duration`, `WorkSpec`.`flex_duration` AS `flex_duration`, `WorkSpec`.`run_attempt_count` AS `run_attempt_count`, `WorkSpec`.`backoff_policy` AS `backoff_policy`, `WorkSpec`.`backoff_delay_duration` AS `backoff_delay_duration`, `WorkSpec`.`period_start_time` AS `period_start_time`, `WorkSpec`.`minimum_retention_duration` AS `minimum_retention_duration`, `WorkSpec`.`schedule_requested_at` AS `schedule_requested_at`, `WorkSpec`.`run_in_foreground` AS `run_in_foreground`, `WorkSpec`.`out_of_quota_policy` AS `out_of_quota_policy` FROM workspec WHERE period_start_time >= ? AND state IN (2, 3, 5) ORDER BY period_start_time DESC", 1);
    q.e(1, l1 - l2);
    c0.a.b();
    Cursor cursor = a.a(c0.a, (e)q, false, null);
    try {
      int i1 = h.x(cursor, "required_network_type");
      int i5 = h.x(cursor, "requires_charging");
      int i = h.x(cursor, "requires_device_idle");
      int i7 = h.x(cursor, "requires_battery_not_low");
      int i8 = h.x(cursor, "requires_storage_not_low");
      int i9 = h.x(cursor, "trigger_content_update_delay");
      int i10 = h.x(cursor, "trigger_max_content_delay");
      int i11 = h.x(cursor, "content_uri_triggers");
      int n = h.x(cursor, "id");
      int k = h.x(cursor, "state");
      int i3 = h.x(cursor, "worker_class_name");
      int i2 = h.x(cursor, "input_merger_class_name");
      int i4 = h.x(cursor, "input");
      int i6 = h.x(cursor, "output");
      try {
        int i19 = h.x(cursor, "initial_delay");
        int i18 = h.x(cursor, "interval_duration");
        int i22 = h.x(cursor, "flex_duration");
        int i17 = h.x(cursor, "run_attempt_count");
        int i12 = h.x(cursor, "backoff_policy");
        int i13 = h.x(cursor, "backoff_delay_duration");
        int i21 = h.x(cursor, "period_start_time");
        int i15 = h.x(cursor, "minimum_retention_duration");
        int i16 = h.x(cursor, "schedule_requested_at");
        int i14 = h.x(cursor, "run_in_foreground");
        int i20 = h.x(cursor, "out_of_quota_policy");
        ArrayList<t> arrayList = new ArrayList(cursor.getCount());
        while (true) {
          if (cursor.moveToNext()) {
            boolean bool;
            String str1 = cursor.getString(n);
            String str2 = cursor.getString(i3);
            d d = new d();
            d.a = h.N(cursor.getInt(i1));
            if (cursor.getInt(i5) != 0) {
              bool = true;
            } else {
              bool = false;
            } 
            d.b = bool;
            if (cursor.getInt(i) != 0) {
              bool = true;
            } else {
              bool = false;
            } 
            d.c = bool;
            if (cursor.getInt(i7) != 0) {
              bool = true;
            } else {
              bool = false;
            } 
            d.d = bool;
            if (cursor.getInt(i8) != 0) {
              bool = true;
            } else {
              bool = false;
            } 
            d.e = bool;
            d.f = cursor.getLong(i9);
            d.g = cursor.getLong(i10);
            d.h = h.d(cursor.getBlob(i11));
            t t = new t(str1, str2);
            t.b = h.P(cursor.getInt(k));
            t.d = cursor.getString(i2);
            t.e = g.a(cursor.getBlob(i4));
            t.f = g.a(cursor.getBlob(i6));
            t.g = cursor.getLong(i19);
            t.h = cursor.getLong(i18);
            t.i = cursor.getLong(i22);
            t.k = cursor.getInt(i17);
            t.l = h.M(cursor.getInt(i12));
            t.m = cursor.getLong(i13);
            t.n = cursor.getLong(i21);
            t.o = cursor.getLong(i15);
            t.p = cursor.getLong(i16);
            if (cursor.getInt(i14) != 0) {
              bool = true;
            } else {
              bool = false;
            } 
            t.q = bool;
            t.r = h.O(cursor.getInt(i20));
            t.j = d;
            arrayList.add(t);
            continue;
          } 
          cursor.close();
          q.h();
          List<t> list1 = c0.d();
          list = c0.b(200);
          if (!arrayList.isEmpty()) {
            o o = o.c();
            String str1 = k;
            o.d(str1, "Recently completed work:\n\n", new Throwable[0]);
            o.c().d(str1, a(m, f0, j, arrayList), new Throwable[0]);
          } 
          if (!((ArrayList)list1).isEmpty()) {
            o o = o.c();
            String str1 = k;
            o.d(str1, "Running work:\n\n", new Throwable[0]);
            o.c().d(str1, a(m, f0, j, list1), new Throwable[0]);
          } 
          if (!((ArrayList)list).isEmpty()) {
            o o = o.c();
            str = k;
            o.d(str, "Enqueued work:\n\n", new Throwable[0]);
            o.c().d(str, a(m, f0, j, list), new Throwable[0]);
          } 
          return (ListenableWorker.a)new n();
        } 
      } finally {}
    } finally {}
    str.close();
    list.h();
    throw m;
  }
}


/* Location:              C:\soft\dex2jar-2.0\Https Traffic-dex2jar.jar!\androidx\work\impl\workers\DiagnosticsWorker.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */