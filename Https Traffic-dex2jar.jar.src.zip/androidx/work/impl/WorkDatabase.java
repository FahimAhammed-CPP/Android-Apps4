package androidx.work.impl;

import c.b0.f0.b0.c;
import c.b0.f0.b0.c0;
import c.b0.f0.b0.f;
import c.b0.f0.b0.f0;
import c.b0.f0.b0.j;
import c.b0.f0.b0.m;
import c.b0.f0.b0.r;
import c.u.l;
import java.util.concurrent.TimeUnit;

public abstract class WorkDatabase extends l {
  public static final long j = TimeUnit.DAYS.toMillis(1L);
  
  public abstract c l();
  
  public abstract f m();
  
  public abstract j n();
  
  public abstract m o();
  
  public abstract r p();
  
  public abstract c0 q();
  
  public abstract f0 r();
}


/* Location:              C:\soft\dex2jar-2.0\Https Traffic-dex2jar.jar!\androidx\work\impl\WorkDatabase.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */