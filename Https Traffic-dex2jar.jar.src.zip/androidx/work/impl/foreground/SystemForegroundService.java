package androidx.work.impl.foreground;

import android.app.Notification;
import android.app.NotificationManager;
import android.content.Intent;
import android.os.Build;
import android.os.Handler;
import android.os.Looper;
import android.text.TextUtils;
import androidx.work.impl.WorkDatabase;
import c.b0.f0.a0.b;
import c.b0.f0.a0.c;
import c.b0.f0.c0.a0.c;
import c.b0.f0.t;
import c.b0.o;
import c.p.k;
import java.util.Objects;
import java.util.UUID;

public class SystemForegroundService extends k implements c.a {
  public static final String j = o.e("SystemFgService");
  
  public Handler f;
  
  public boolean g;
  
  public c h;
  
  public NotificationManager i;
  
  public final void c() {
    this.f = new Handler(Looper.getMainLooper());
    this.i = (NotificationManager)getApplicationContext().getSystemService("notification");
    c c1 = new c(getApplicationContext());
    this.h = c1;
    if (c1.n != null) {
      o.c().b(c.o, "A callback already exists.", new Throwable[0]);
      return;
    } 
    c1.n = this;
  }
  
  public void d(int paramInt1, int paramInt2, Notification paramNotification) {
    this.f.post(new a(this, paramInt1, paramNotification, paramInt2));
  }
  
  public void onCreate() {
    super.onCreate();
    c();
  }
  
  public void onDestroy() {
    super.onDestroy();
    this.h.g();
  }
  
  public int onStartCommand(Intent paramIntent, int paramInt1, int paramInt2) {
    super.onStartCommand(paramIntent, paramInt1, paramInt2);
    if (this.g) {
      o.c().d(j, "Re-initializing SystemForegroundService after a request to shut-down.", new Throwable[0]);
      this.h.g();
      c();
      this.g = false;
    } 
    if (paramIntent != null) {
      c.b0.f0.c0.a0.a a1;
      c c1 = this.h;
      Objects.requireNonNull(c1);
      String str = paramIntent.getAction();
      if ("ACTION_START_FOREGROUND".equals(str)) {
        o.c().d(c.o, String.format("Started foreground service %s", new Object[] { paramIntent }), new Throwable[0]);
        String str1 = paramIntent.getStringExtra("KEY_WORKSPEC_ID");
        WorkDatabase workDatabase = c1.f.c;
        a1 = c1.g;
        b b = new b(c1, workDatabase, str1);
        ((c)a1).a.execute((Runnable)b);
        c1.f(paramIntent);
      } else if ("ACTION_NOTIFY".equals(a1)) {
        c1.f(paramIntent);
      } else {
        c.b0.f0.c0.a a2;
        String str1;
        if ("ACTION_CANCEL_WORK".equals(a1)) {
          o.c().d(c.o, String.format("Stopping foreground work for %s", new Object[] { paramIntent }), new Throwable[0]);
          str1 = paramIntent.getStringExtra("KEY_WORKSPEC_ID");
          if (str1 != null && !TextUtils.isEmpty(str1)) {
            t t = c1.f;
            UUID uUID = UUID.fromString(str1);
            Objects.requireNonNull(t);
            a2 = new c.b0.f0.c0.a(t, uUID);
            ((c)t.d).a.execute((Runnable)a2);
          } 
        } else if ("ACTION_STOP_FOREGROUND".equals(str1)) {
          o.c().d(c.o, "Stopping foreground service", new Throwable[0]);
          c.a a3 = ((c)a2).n;
          if (a3 != null) {
            a3 = a3;
            ((SystemForegroundService)a3).g = true;
            o.c().a(j, "All commands completed.", new Throwable[0]);
            if (Build.VERSION.SDK_INT >= 26)
              a3.stopForeground(true); 
            a3.stopSelf();
          } 
        } 
      } 
    } 
    return 3;
  }
  
  public class a implements Runnable {
    public a(SystemForegroundService this$0, int param1Int1, Notification param1Notification, int param1Int2) {}
    
    public void run() {
      if (Build.VERSION.SDK_INT >= 29) {
        this.h.startForeground(this.e, this.f, this.g);
        return;
      } 
      this.h.startForeground(this.e, this.f);
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Https Traffic-dex2jar.jar!\androidx\work\impl\foreground\SystemForegroundService.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */