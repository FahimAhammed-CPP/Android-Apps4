package androidx.work.impl.diagnostics;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import androidx.work.impl.workers.DiagnosticsWorker;
import c.b0.f0.t;
import c.b0.o;
import c.b0.q;

public class DiagnosticsReceiver extends BroadcastReceiver {
  public static final String a = o.e("DiagnosticsRcvr");
  
  public void onReceive(Context paramContext, Intent paramIntent) {
    if (paramIntent == null)
      return; 
    o.c().a(a, "Requesting diagnostics", new Throwable[0]);
    try {
      t.b(paramContext).a((new q.a(DiagnosticsWorker.class)).a());
      return;
    } catch (IllegalStateException illegalStateException) {
      o.c().b(a, "WorkManager is not initialized", new Throwable[] { illegalStateException });
      return;
    } 
  }
}


/* Location:              C:\soft\dex2jar-2.0\Https Traffic-dex2jar.jar!\androidx\work\impl\diagnostics\DiagnosticsReceiver.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */