package androidx.constraintlayout.widget;

import android.content.Context;
import android.content.res.TypedArray;
import android.util.AttributeSet;
import c.f.b.l.a;
import c.f.b.l.g;
import c.f.c.c;
import c.f.c.n;

public class Barrier extends c {
  public int l;
  
  public int m;
  
  public a n;
  
  public Barrier(Context paramContext) {
    super(paramContext);
    setVisibility(8);
  }
  
  public Barrier(Context paramContext, AttributeSet paramAttributeSet) {
    super(paramContext, paramAttributeSet);
    setVisibility(8);
  }
  
  public void e(AttributeSet paramAttributeSet) {
    if (paramAttributeSet != null) {
      TypedArray typedArray = getContext().obtainStyledAttributes(paramAttributeSet, n.b);
      int j = typedArray.getIndexCount();
      for (int i = 0; i < j; i++) {
        int k = typedArray.getIndex(i);
        if (k == 19) {
          String str = typedArray.getString(k);
          this.i = str;
          setIds(str);
        } else if (k == 20) {
          String str = typedArray.getString(k);
          this.j = str;
          setReferenceTags(str);
        } 
      } 
      typedArray.recycle();
    } 
    this.n = new a();
    if (paramAttributeSet != null) {
      TypedArray typedArray = getContext().obtainStyledAttributes(paramAttributeSet, n.b);
      int j = typedArray.getIndexCount();
      for (int i = 0; i < j; i++) {
        int k = typedArray.getIndex(i);
        if (k == 15) {
          setType(typedArray.getInt(k, 0));
        } else if (k == 14) {
          this.n.n0 = typedArray.getBoolean(k, true);
        } else if (k == 16) {
          k = typedArray.getDimensionPixelSize(k, 0);
          this.n.o0 = k;
        } 
      } 
      typedArray.recycle();
    } 
    this.h = (g)this.n;
    i();
  }
  
  public int getMargin() {
    return this.n.o0;
  }
  
  public int getType() {
    return this.l;
  }
  
  public void setAllowsGoneWidget(boolean paramBoolean) {
    this.n.n0 = paramBoolean;
  }
  
  public void setDpMargin(int paramInt) {
    float f = (getResources().getDisplayMetrics()).density;
    paramInt = (int)(paramInt * f + 0.5F);
    this.n.o0 = paramInt;
  }
  
  public void setMargin(int paramInt) {
    this.n.o0 = paramInt;
  }
  
  public void setType(int paramInt) {
    this.l = paramInt;
  }
}


/* Location:              C:\soft\dex2jar-2.0\Https Traffic-dex2jar.jar!\androidx\constraintlayout\widget\Barrier.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */