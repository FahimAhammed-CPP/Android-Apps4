package androidx.activity;

import android.app.Activity;
import android.os.Build;
import android.os.Bundle;
import android.view.View;
import android.view.Window;
import c.a.b;
import c.a.c;
import c.a.f;
import c.h.b.i;
import c.p.e;
import c.p.f;
import c.p.g;
import c.p.h;
import c.p.j;
import c.p.r;
import c.p.w;
import c.p.x;
import c.v.a;
import c.v.c;
import c.v.d;

public abstract class ComponentActivity extends i implements h, x, d, f {
  public final j f;
  
  public final c g;
  
  public w h;
  
  public final OnBackPressedDispatcher i;
  
  public ComponentActivity() {
    j j1 = new j(this);
    this.f = j1;
    this.g = new c(this);
    this.i = new OnBackPressedDispatcher((Runnable)new b(this));
    int k = Build.VERSION.SDK_INT;
    j1.a((g)new f(this) {
          public void d(h param1h, e.a param1a) {
            if (param1a == e.a.ON_STOP) {
              Window window = this.e.getWindow();
              if (window != null) {
                View view = window.peekDecorView();
              } else {
                window = null;
              } 
              if (window != null)
                window.cancelPendingInputEvents(); 
            } 
          }
        });
    j1.a((g)new f(this) {
          public void d(h param1h, e.a param1a) {
            if (param1a == e.a.ON_DESTROY && !this.e.isChangingConfigurations())
              this.e.i().a(); 
          }
        });
    if (k <= 23)
      j1.a((g)new ImmLeaksCleaner((Activity)this)); 
  }
  
  public final OnBackPressedDispatcher a() {
    return this.i;
  }
  
  public final a b() {
    return this.g.b;
  }
  
  public w i() {
    if (getApplication() != null) {
      if (this.h == null) {
        c c1 = (c)getLastNonConfigurationInstance();
        if (c1 != null)
          this.h = c1.a; 
        if (this.h == null)
          this.h = new w(); 
      } 
      return this.h;
    } 
    throw new IllegalStateException("Your activity is not yet attached to the Application instance. You can't request ViewModel before onCreate call.");
  }
  
  public e l() {
    return (e)this.f;
  }
  
  public void onBackPressed() {
    this.i.b();
  }
  
  public void onCreate(Bundle paramBundle) {
    super.onCreate(paramBundle);
    this.g.a(paramBundle);
    r.b((Activity)this);
  }
  
  public final Object onRetainNonConfigurationInstance() {
    w w2 = this.h;
    w w1 = w2;
    if (w2 == null) {
      c c2 = (c)getLastNonConfigurationInstance();
      w1 = w2;
      if (c2 != null)
        w1 = c2.a; 
    } 
    if (w1 == null)
      return null; 
    c c1 = new c();
    c1.a = w1;
    return c1;
  }
  
  public void onSaveInstanceState(Bundle paramBundle) {
    j j1 = this.f;
    if (j1 instanceof j)
      j1.f(e.b.g); 
    super.onSaveInstanceState(paramBundle);
    this.g.b(paramBundle);
  }
}


/* Location:              C:\soft\dex2jar-2.0\Https Traffic-dex2jar.jar!\androidx\activity\ComponentActivity.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */