package androidx.recyclerview.widget;

import android.content.Context;
import android.graphics.Rect;
import android.util.AttributeSet;
import android.util.Log;
import android.util.SparseIntArray;
import android.view.View;
import android.view.ViewGroup;
import c.t.b.u;
import java.util.Arrays;
import java.util.Objects;

public class GridLayoutManager extends LinearLayoutManager {
  public boolean F = false;
  
  public int G = -1;
  
  public int[] H;
  
  public View[] I;
  
  public final SparseIntArray J = new SparseIntArray();
  
  public final SparseIntArray K = new SparseIntArray();
  
  public c L = new a();
  
  public final Rect M = new Rect();
  
  public GridLayoutManager(Context paramContext, AttributeSet paramAttributeSet, int paramInt1, int paramInt2) {
    super(paramContext, paramAttributeSet, paramInt1, paramInt2);
    paramInt1 = (RecyclerView.l.M(paramContext, paramAttributeSet, paramInt1, paramInt2)).b;
    if (paramInt1 == this.G)
      return; 
    this.F = true;
    if (paramInt1 >= 1) {
      this.G = paramInt1;
      this.L.a.clear();
      E0();
      return;
    } 
    throw new IllegalArgumentException(d.a.a.a.a.D("Span count should be at least 1. Provided ", paramInt1));
  }
  
  public final int A1(RecyclerView.r paramr, RecyclerView.v paramv, int paramInt) {
    if (!paramv.f) {
      Objects.requireNonNull(this.L);
      return 1;
    } 
    int i = this.J.get(paramInt, -1);
    if (i != -1)
      return i; 
    if (paramr.c(paramInt) == -1) {
      StringBuilder stringBuilder = new StringBuilder();
      stringBuilder.append("Cannot find span size for pre layout position. It is not cached, not in the adapter. Pos:");
      stringBuilder.append(paramInt);
      Log.w("GridLayoutManager", stringBuilder.toString());
      return 1;
    } 
    Objects.requireNonNull(this.L);
    return 1;
  }
  
  public final void B1(View paramView, int paramInt, boolean paramBoolean) {
    b b = (b)paramView.getLayoutParams();
    Rect rect = b.b;
    int j = rect.top + rect.bottom + b.topMargin + b.bottomMargin;
    int i = rect.left + rect.right + b.leftMargin + b.rightMargin;
    int k = x1(b.e, b.f);
    if (this.q == 1) {
      i = RecyclerView.l.y(k, paramInt, i, b.width, false);
      paramInt = RecyclerView.l.y(this.s.l(), this.n, j, b.height, true);
    } else {
      paramInt = RecyclerView.l.y(k, paramInt, j, b.height, false);
      i = RecyclerView.l.y(this.s.l(), this.m, i, b.width, true);
    } 
    C1(paramView, i, paramInt, paramBoolean);
  }
  
  public final void C1(View paramView, int paramInt1, int paramInt2, boolean paramBoolean) {
    RecyclerView.m m = (RecyclerView.m)paramView.getLayoutParams();
    if (paramBoolean) {
      paramBoolean = O0(paramView, paramInt1, paramInt2, m);
    } else {
      paramBoolean = M0(paramView, paramInt1, paramInt2, m);
    } 
    if (paramBoolean)
      paramView.measure(paramInt1, paramInt2); 
  }
  
  public final void D1() {
    int i;
    int j;
    if (this.q == 1) {
      i = this.o - J();
      j = I();
    } else {
      i = this.p - H();
      j = K();
    } 
    v1(i - j);
  }
  
  public int F0(int paramInt, RecyclerView.r paramr, RecyclerView.v paramv) {
    D1();
    w1();
    return (this.q == 1) ? 0 : p1(paramInt, paramr, paramv);
  }
  
  public int G0(int paramInt, RecyclerView.r paramr, RecyclerView.v paramv) {
    D1();
    w1();
    return (this.q == 0) ? 0 : p1(paramInt, paramr, paramv);
  }
  
  public void J0(Rect paramRect, int paramInt1, int paramInt2) {
    int[] arrayOfInt;
    if (this.H == null)
      super.J0(paramRect, paramInt1, paramInt2); 
    int i = I();
    i = J() + i;
    int j = K();
    j = H() + j;
    if (this.q == 1) {
      paramInt2 = RecyclerView.l.g(paramInt2, paramRect.height() + j, F());
      arrayOfInt = this.H;
      i = RecyclerView.l.g(paramInt1, arrayOfInt[arrayOfInt.length - 1] + i, G());
      paramInt1 = paramInt2;
      paramInt2 = i;
    } else {
      paramInt1 = RecyclerView.l.g(paramInt1, arrayOfInt.width() + i, G());
      arrayOfInt = this.H;
      i = RecyclerView.l.g(paramInt2, arrayOfInt[arrayOfInt.length - 1] + j, F());
      paramInt2 = paramInt1;
      paramInt1 = i;
    } 
    RecyclerView.e(this.b, paramInt2, paramInt1);
  }
  
  public int N(RecyclerView.r paramr, RecyclerView.v paramv) {
    return (this.q == 0) ? this.G : ((paramv.b() < 1) ? 0 : (y1(paramr, paramv, paramv.b() - 1) + 1));
  }
  
  public boolean P0() {
    return (this.A == null && !this.F);
  }
  
  public void Q0(RecyclerView.v paramv, LinearLayoutManager.c paramc, RecyclerView.l.a parama) {
    int j = this.G;
    int i;
    for (i = 0; i < this.G && paramc.b(paramv) && j > 0; i++) {
      int k = paramc.d;
      int m = Math.max(0, paramc.g);
      ((u.a)parama).a(k, m);
      Objects.requireNonNull(this.L);
      j--;
      paramc.d += paramc.e;
    } 
  }
  
  public View c0(View paramView, int paramInt, RecyclerView.r paramr, RecyclerView.v paramv) {
    // Byte code:
    //   0: aload_0
    //   1: aload_1
    //   2: invokevirtual r : (Landroid/view/View;)Landroid/view/View;
    //   5: astore #20
    //   7: aconst_null
    //   8: astore #21
    //   10: aload #20
    //   12: ifnonnull -> 17
    //   15: aconst_null
    //   16: areturn
    //   17: aload #20
    //   19: invokevirtual getLayoutParams : ()Landroid/view/ViewGroup$LayoutParams;
    //   22: checkcast androidx/recyclerview/widget/GridLayoutManager$b
    //   25: astore #22
    //   27: aload #22
    //   29: getfield e : I
    //   32: istore #14
    //   34: aload #22
    //   36: getfield f : I
    //   39: iload #14
    //   41: iadd
    //   42: istore #15
    //   44: aload_0
    //   45: aload_1
    //   46: iload_2
    //   47: aload_3
    //   48: aload #4
    //   50: invokespecial c0 : (Landroid/view/View;ILandroidx/recyclerview/widget/RecyclerView$r;Landroidx/recyclerview/widget/RecyclerView$v;)Landroid/view/View;
    //   53: ifnonnull -> 58
    //   56: aconst_null
    //   57: areturn
    //   58: aload_0
    //   59: iload_2
    //   60: invokevirtual U0 : (I)I
    //   63: iconst_1
    //   64: if_icmpne -> 73
    //   67: iconst_1
    //   68: istore #19
    //   70: goto -> 76
    //   73: iconst_0
    //   74: istore #19
    //   76: iload #19
    //   78: aload_0
    //   79: getfield v : Z
    //   82: if_icmpeq -> 90
    //   85: iconst_1
    //   86: istore_2
    //   87: goto -> 92
    //   90: iconst_0
    //   91: istore_2
    //   92: iload_2
    //   93: ifeq -> 112
    //   96: aload_0
    //   97: invokevirtual x : ()I
    //   100: iconst_1
    //   101: isub
    //   102: istore #5
    //   104: iconst_m1
    //   105: istore_2
    //   106: iload_2
    //   107: istore #6
    //   109: goto -> 123
    //   112: aload_0
    //   113: invokevirtual x : ()I
    //   116: istore_2
    //   117: iconst_1
    //   118: istore #6
    //   120: iconst_0
    //   121: istore #5
    //   123: aload_0
    //   124: getfield q : I
    //   127: iconst_1
    //   128: if_icmpne -> 144
    //   131: aload_0
    //   132: invokevirtual i1 : ()Z
    //   135: ifeq -> 144
    //   138: iconst_1
    //   139: istore #7
    //   141: goto -> 147
    //   144: iconst_0
    //   145: istore #7
    //   147: aload_0
    //   148: aload_3
    //   149: aload #4
    //   151: iload #5
    //   153: invokevirtual y1 : (Landroidx/recyclerview/widget/RecyclerView$r;Landroidx/recyclerview/widget/RecyclerView$v;I)I
    //   156: istore #16
    //   158: iconst_m1
    //   159: istore #12
    //   161: iload #12
    //   163: istore #10
    //   165: iconst_0
    //   166: istore #13
    //   168: iconst_0
    //   169: istore #11
    //   171: aconst_null
    //   172: astore_1
    //   173: iload_2
    //   174: istore #8
    //   176: iload #5
    //   178: istore #9
    //   180: iload #13
    //   182: istore_2
    //   183: iload #9
    //   185: iload #8
    //   187: if_icmpeq -> 551
    //   190: aload_0
    //   191: aload_3
    //   192: aload #4
    //   194: iload #9
    //   196: invokevirtual y1 : (Landroidx/recyclerview/widget/RecyclerView$r;Landroidx/recyclerview/widget/RecyclerView$v;I)I
    //   199: istore #5
    //   201: aload_0
    //   202: iload #9
    //   204: invokevirtual w : (I)Landroid/view/View;
    //   207: astore #22
    //   209: aload #22
    //   211: aload #20
    //   213: if_acmpne -> 219
    //   216: goto -> 551
    //   219: aload #22
    //   221: invokevirtual hasFocusable : ()Z
    //   224: ifeq -> 245
    //   227: iload #5
    //   229: iload #16
    //   231: if_icmpeq -> 245
    //   234: aload #21
    //   236: ifnull -> 242
    //   239: goto -> 551
    //   242: goto -> 541
    //   245: aload #22
    //   247: invokevirtual getLayoutParams : ()Landroid/view/ViewGroup$LayoutParams;
    //   250: checkcast androidx/recyclerview/widget/GridLayoutManager$b
    //   253: astore #23
    //   255: aload #23
    //   257: getfield e : I
    //   260: istore #17
    //   262: aload #23
    //   264: getfield f : I
    //   267: iload #17
    //   269: iadd
    //   270: istore #18
    //   272: aload #22
    //   274: invokevirtual hasFocusable : ()Z
    //   277: ifeq -> 297
    //   280: iload #17
    //   282: iload #14
    //   284: if_icmpne -> 297
    //   287: iload #18
    //   289: iload #15
    //   291: if_icmpne -> 297
    //   294: aload #22
    //   296: areturn
    //   297: aload #22
    //   299: invokevirtual hasFocusable : ()Z
    //   302: ifeq -> 310
    //   305: aload #21
    //   307: ifnull -> 322
    //   310: aload #22
    //   312: invokevirtual hasFocusable : ()Z
    //   315: ifne -> 325
    //   318: aload_1
    //   319: ifnonnull -> 325
    //   322: goto -> 392
    //   325: iload #17
    //   327: iload #14
    //   329: invokestatic max : (II)I
    //   332: istore #5
    //   334: iload #18
    //   336: iload #15
    //   338: invokestatic min : (II)I
    //   341: iload #5
    //   343: isub
    //   344: istore #5
    //   346: aload #22
    //   348: invokevirtual hasFocusable : ()Z
    //   351: ifeq -> 398
    //   354: iload #5
    //   356: iload_2
    //   357: if_icmple -> 363
    //   360: goto -> 392
    //   363: iload #5
    //   365: iload_2
    //   366: if_icmpne -> 459
    //   369: iload #17
    //   371: iload #10
    //   373: if_icmple -> 382
    //   376: iconst_1
    //   377: istore #5
    //   379: goto -> 385
    //   382: iconst_0
    //   383: istore #5
    //   385: iload #7
    //   387: iload #5
    //   389: if_icmpne -> 459
    //   392: iconst_1
    //   393: istore #5
    //   395: goto -> 462
    //   398: aload #21
    //   400: ifnonnull -> 459
    //   403: aload_0
    //   404: aload #22
    //   406: iconst_0
    //   407: invokevirtual T : (Landroid/view/View;Z)Z
    //   410: ifeq -> 459
    //   413: iload #5
    //   415: iload #11
    //   417: if_icmple -> 423
    //   420: goto -> 453
    //   423: iload #5
    //   425: iload #11
    //   427: if_icmpne -> 459
    //   430: iload #17
    //   432: iload #12
    //   434: if_icmple -> 443
    //   437: iconst_1
    //   438: istore #5
    //   440: goto -> 446
    //   443: iconst_0
    //   444: istore #5
    //   446: iload #7
    //   448: iload #5
    //   450: if_icmpne -> 459
    //   453: iconst_1
    //   454: istore #5
    //   456: goto -> 462
    //   459: iconst_0
    //   460: istore #5
    //   462: iload_2
    //   463: istore #13
    //   465: iload #5
    //   467: ifeq -> 541
    //   470: aload #22
    //   472: invokevirtual hasFocusable : ()Z
    //   475: ifeq -> 508
    //   478: aload #23
    //   480: getfield e : I
    //   483: istore #10
    //   485: iload #18
    //   487: iload #15
    //   489: invokestatic min : (II)I
    //   492: iload #17
    //   494: iload #14
    //   496: invokestatic max : (II)I
    //   499: isub
    //   500: istore_2
    //   501: aload #22
    //   503: astore #21
    //   505: goto -> 541
    //   508: aload #23
    //   510: getfield e : I
    //   513: istore #12
    //   515: iload #18
    //   517: iload #15
    //   519: invokestatic min : (II)I
    //   522: iload #17
    //   524: iload #14
    //   526: invokestatic max : (II)I
    //   529: isub
    //   530: istore #11
    //   532: aload #22
    //   534: astore_1
    //   535: iload #13
    //   537: istore_2
    //   538: goto -> 541
    //   541: iload #9
    //   543: iload #6
    //   545: iadd
    //   546: istore #9
    //   548: goto -> 183
    //   551: aload #21
    //   553: ifnull -> 559
    //   556: aload #21
    //   558: areturn
    //   559: aload_1
    //   560: areturn
  }
  
  public View d1(RecyclerView.r paramr, RecyclerView.v paramv, int paramInt1, int paramInt2, int paramInt3) {
    byte b;
    V0();
    int i = this.s.k();
    int j = this.s.g();
    if (paramInt2 > paramInt1) {
      b = 1;
    } else {
      b = -1;
    } 
    View view2 = null;
    View view1;
    for (view1 = null; paramInt1 != paramInt2; view1 = view4) {
      View view5 = w(paramInt1);
      int k = L(view5);
      View view3 = view2;
      View view4 = view1;
      if (k >= 0) {
        view3 = view2;
        view4 = view1;
        if (k < paramInt3)
          if (z1(paramr, paramv, k) != 0) {
            view3 = view2;
            view4 = view1;
          } else if (((RecyclerView.m)view5.getLayoutParams()).c()) {
            view3 = view2;
            view4 = view1;
            if (view1 == null) {
              view4 = view5;
              view3 = view2;
            } 
          } else if (this.s.e(view5) >= j || this.s.b(view5) < i) {
            view3 = view2;
            view4 = view1;
            if (view2 == null) {
              view3 = view5;
              view4 = view1;
            } 
          } else {
            return view5;
          }  
      } 
      paramInt1 += b;
      view2 = view3;
    } 
    return (view2 != null) ? view2 : view1;
  }
  
  public boolean f(RecyclerView.m paramm) {
    return paramm instanceof b;
  }
  
  public void g0(RecyclerView.r paramr, RecyclerView.v paramv, View paramView, c.h.j.m0.b paramb) {
    ViewGroup.LayoutParams layoutParams = paramView.getLayoutParams();
    if (!(layoutParams instanceof b)) {
      f0(paramView, paramb);
      return;
    } 
    b b1 = (b)layoutParams;
    int i = y1(paramr, paramv, b1.a());
    if (this.q == 0) {
      paramb.n(c.h.j.m0.b.c.a(b1.e, b1.f, i, 1, false, false));
      return;
    } 
    paramb.n(c.h.j.m0.b.c.a(i, 1, b1.e, b1.f, false, false));
  }
  
  public void i0(RecyclerView paramRecyclerView, int paramInt1, int paramInt2) {
    this.L.a.clear();
    this.L.b.clear();
  }
  
  public void j0(RecyclerView paramRecyclerView) {
    this.L.a.clear();
    this.L.b.clear();
  }
  
  public void j1(RecyclerView.r paramr, RecyclerView.v paramv, LinearLayoutManager.c paramc, LinearLayoutManager.b paramb) {
    StringBuilder stringBuilder;
    int m;
    int n;
    int i2;
    int i3;
    int i4 = this.s.j();
    if (i4 != 1073741824) {
      m = 1;
    } else {
      m = 0;
    } 
    if (x() > 0) {
      n = this.H[this.G];
    } else {
      n = 0;
    } 
    if (m)
      D1(); 
    if (paramc.e == 1) {
      i1 = 1;
    } else {
      i1 = 0;
    } 
    int i = this.G;
    if (!i1)
      i = z1(paramr, paramv, paramc.d) + A1(paramr, paramv, paramc.d); 
    int k = 0;
    while (k < this.G && paramc.b(paramv) && i > 0) {
      j = paramc.d;
      i2 = A1(paramr, paramv, j);
      if (i2 <= this.G) {
        i -= i2;
        if (i < 0)
          break; 
        View view = paramc.c(paramr);
        if (view == null)
          break; 
        this.I[k] = view;
        k++;
        continue;
      } 
      stringBuilder = new StringBuilder();
      stringBuilder.append("Item at position ");
      stringBuilder.append(j);
      stringBuilder.append(" requires ");
      stringBuilder.append(i2);
      stringBuilder.append(" spans but GridLayoutManager has only ");
      stringBuilder.append(this.G);
      stringBuilder.append(" spans.");
      throw new IllegalArgumentException(stringBuilder.toString());
    } 
    if (k == 0) {
      paramb.b = true;
      return;
    } 
    if (i1) {
      i = 0;
      j = i;
      i3 = 1;
      i2 = k;
    } else {
      i = k - 1;
      j = 0;
      i2 = -1;
      i3 = -1;
    } 
    while (i != i2) {
      View view = this.I[i];
      b b1 = (b)view.getLayoutParams();
      int i5 = A1((RecyclerView.r)stringBuilder, paramv, L(view));
      b1.f = i5;
      b1.e = j;
      j += i5;
      i += i3;
    } 
    float f = 0.0F;
    int j = 0;
    for (i = j; j < k; i = i2) {
      View view = this.I[j];
      if (paramc.k == null) {
        if (i1) {
          a(view);
        } else {
          b(view, 0, false);
        } 
      } else if (i1) {
        b(view, -1, true);
      } else {
        b(view, 0, true);
      } 
      Rect rect = this.M;
      RecyclerView recyclerView = this.b;
      if (recyclerView == null) {
        rect.set(0, 0, 0, 0);
      } else {
        rect.set(recyclerView.J(view));
      } 
      B1(view, i4, false);
      i3 = this.s.c(view);
      i2 = i;
      if (i3 > i)
        i2 = i3; 
      b b1 = (b)view.getLayoutParams();
      float f2 = this.s.d(view) * 1.0F / b1.f;
      float f1 = f;
      if (f2 > f)
        f1 = f2; 
      j++;
      f = f1;
    } 
    j = i;
    if (m) {
      v1(Math.max(Math.round(f * this.G), n));
      m = 0;
      i = m;
      while (true) {
        j = i;
        if (m < k) {
          View view = this.I[m];
          B1(view, 1073741824, true);
          n = this.s.c(view);
          j = i;
          if (n > i)
            j = n; 
          m++;
          i = j;
          continue;
        } 
        break;
      } 
    } 
    for (i = 0; i < k; i++) {
      View view = this.I[i];
      if (this.s.c(view) != j) {
        b b1 = (b)view.getLayoutParams();
        Rect rect = b1.b;
        n = rect.top + rect.bottom + b1.topMargin + b1.bottomMargin;
        m = rect.left + rect.right + b1.leftMargin + b1.rightMargin;
        i1 = x1(b1.e, b1.f);
        if (this.q == 1) {
          m = RecyclerView.l.y(i1, 1073741824, m, b1.width, false);
          n = View.MeasureSpec.makeMeasureSpec(j - n, 1073741824);
        } else {
          m = View.MeasureSpec.makeMeasureSpec(j - m, 1073741824);
          n = RecyclerView.l.y(i1, 1073741824, n, b1.height, false);
        } 
        C1(view, m, n, true);
      } 
    } 
    paramb.a = j;
    if (this.q == 1) {
      if (paramc.f == -1) {
        i = paramc.b;
        m = i - j;
        j = i;
        i = m;
      } else {
        i = paramc.b;
        j += i;
      } 
      m = 0;
      n = m;
    } else {
      if (paramc.f == -1) {
        i = paramc.b;
        j = i - j;
      } else {
        i = paramc.b;
        m = j + i;
        j = i;
        i = m;
      } 
      n = j;
      m = 0;
      i1 = i;
      j = m;
      i = m;
      m = i1;
    } 
    int i1 = 0;
    while (true) {
      View view;
      if (i1 < k) {
        view = this.I[i1];
        b b1 = (b)view.getLayoutParams();
        if (this.q == 1) {
          if (i1()) {
            m = I() + this.H[this.G - b1.e];
            n = m - this.s.d(view);
          } else {
            m = I() + this.H[b1.e];
            n = this.s.d(view);
            i2 = m;
            m = n + m;
            n = j;
            j = i;
            i = i2;
            U(view, i, j, m, n);
          } 
        } else {
          i = K();
          i = this.H[b1.e] + i;
          j = this.s.d(view) + i;
        } 
        i2 = j;
        j = i;
        i = n;
        n = i2;
      } else {
        break;
      } 
      U(view, i, j, m, n);
    } 
    Arrays.fill((Object[])this.I, (Object)null);
  }
  
  public int k(RecyclerView.v paramv) {
    return S0(paramv);
  }
  
  public void k0(RecyclerView paramRecyclerView, int paramInt1, int paramInt2, int paramInt3) {
    this.L.a.clear();
    this.L.b.clear();
  }
  
  public void k1(RecyclerView.r paramr, RecyclerView.v paramv, LinearLayoutManager.a parama, int paramInt) {
    D1();
    if (paramv.b() > 0 && !paramv.f) {
      if (paramInt == 1) {
        paramInt = 1;
      } else {
        paramInt = 0;
      } 
      int i = z1(paramr, paramv, parama.b);
      if (paramInt != 0) {
        while (i > 0) {
          paramInt = parama.b;
          if (paramInt > 0) {
            parama.b = --paramInt;
            i = z1(paramr, paramv, paramInt);
          } 
        } 
      } else {
        int j = paramv.b();
        paramInt = parama.b;
        while (paramInt < j - 1) {
          int m = paramInt + 1;
          int k = z1(paramr, paramv, m);
          if (k > i) {
            paramInt = m;
            i = k;
          } 
        } 
        parama.b = paramInt;
      } 
    } 
    w1();
  }
  
  public int l(RecyclerView.v paramv) {
    return T0(paramv);
  }
  
  public void l0(RecyclerView paramRecyclerView, int paramInt1, int paramInt2) {
    this.L.a.clear();
    this.L.b.clear();
  }
  
  public int n(RecyclerView.v paramv) {
    return S0(paramv);
  }
  
  public void n0(RecyclerView paramRecyclerView, int paramInt1, int paramInt2, Object paramObject) {
    this.L.a.clear();
    this.L.b.clear();
  }
  
  public int o(RecyclerView.v paramv) {
    return T0(paramv);
  }
  
  public void o0(RecyclerView.r paramr, RecyclerView.v paramv) {
    if (paramv.f) {
      int j = x();
      for (int i = 0; i < j; i++) {
        b b = (b)w(i).getLayoutParams();
        int k = b.a();
        this.J.put(k, b.f);
        this.K.put(k, b.e);
      } 
    } 
    super.o0(paramr, paramv);
    this.J.clear();
    this.K.clear();
  }
  
  public void p0(RecyclerView.v paramv) {
    this.A = null;
    this.y = -1;
    this.z = Integer.MIN_VALUE;
    this.B.d();
    this.F = false;
  }
  
  public void r1(boolean paramBoolean) {
    if (!paramBoolean) {
      c(null);
      if (!this.w)
        return; 
      this.w = false;
      E0();
      return;
    } 
    throw new UnsupportedOperationException("GridLayoutManager does not support stack from end. Consider using reverse layout");
  }
  
  public RecyclerView.m t() {
    return (this.q == 0) ? new b(-2, -1) : new b(-1, -2);
  }
  
  public RecyclerView.m u(Context paramContext, AttributeSet paramAttributeSet) {
    return new b(paramContext, paramAttributeSet);
  }
  
  public RecyclerView.m v(ViewGroup.LayoutParams paramLayoutParams) {
    return (paramLayoutParams instanceof ViewGroup.MarginLayoutParams) ? new b((ViewGroup.MarginLayoutParams)paramLayoutParams) : new b(paramLayoutParams);
  }
  
  public final void v1(int paramInt) {
    // Byte code:
    //   0: aload_0
    //   1: getfield H : [I
    //   4: astore #9
    //   6: aload_0
    //   7: getfield G : I
    //   10: istore #6
    //   12: iconst_1
    //   13: istore_3
    //   14: aload #9
    //   16: ifnull -> 45
    //   19: aload #9
    //   21: arraylength
    //   22: iload #6
    //   24: iconst_1
    //   25: iadd
    //   26: if_icmpne -> 45
    //   29: aload #9
    //   31: astore #8
    //   33: aload #9
    //   35: aload #9
    //   37: arraylength
    //   38: iconst_1
    //   39: isub
    //   40: iaload
    //   41: iload_1
    //   42: if_icmpeq -> 53
    //   45: iload #6
    //   47: iconst_1
    //   48: iadd
    //   49: newarray int
    //   51: astore #8
    //   53: iconst_0
    //   54: istore #4
    //   56: aload #8
    //   58: iconst_0
    //   59: iconst_0
    //   60: iastore
    //   61: iload_1
    //   62: iload #6
    //   64: idiv
    //   65: istore #5
    //   67: iload_1
    //   68: iload #6
    //   70: irem
    //   71: istore #7
    //   73: iconst_0
    //   74: istore_2
    //   75: iload #4
    //   77: istore_1
    //   78: iload_3
    //   79: iload #6
    //   81: if_icmpgt -> 137
    //   84: iload_1
    //   85: iload #7
    //   87: iadd
    //   88: istore_1
    //   89: iload_1
    //   90: ifle -> 116
    //   93: iload #6
    //   95: iload_1
    //   96: isub
    //   97: iload #7
    //   99: if_icmpge -> 116
    //   102: iload #5
    //   104: iconst_1
    //   105: iadd
    //   106: istore #4
    //   108: iload_1
    //   109: iload #6
    //   111: isub
    //   112: istore_1
    //   113: goto -> 120
    //   116: iload #5
    //   118: istore #4
    //   120: iload_2
    //   121: iload #4
    //   123: iadd
    //   124: istore_2
    //   125: aload #8
    //   127: iload_3
    //   128: iload_2
    //   129: iastore
    //   130: iload_3
    //   131: iconst_1
    //   132: iadd
    //   133: istore_3
    //   134: goto -> 78
    //   137: aload_0
    //   138: aload #8
    //   140: putfield H : [I
    //   143: return
  }
  
  public final void w1() {
    View[] arrayOfView = this.I;
    if (arrayOfView == null || arrayOfView.length != this.G)
      this.I = new View[this.G]; 
  }
  
  public int x1(int paramInt1, int paramInt2) {
    if (this.q == 1 && i1()) {
      int[] arrayOfInt1 = this.H;
      int i = this.G;
      return arrayOfInt1[i - paramInt1] - arrayOfInt1[i - paramInt1 - paramInt2];
    } 
    int[] arrayOfInt = this.H;
    return arrayOfInt[paramInt2 + paramInt1] - arrayOfInt[paramInt1];
  }
  
  public final int y1(RecyclerView.r paramr, RecyclerView.v paramv, int paramInt) {
    if (!paramv.f)
      return this.L.a(paramInt, this.G); 
    int i = paramr.c(paramInt);
    if (i == -1) {
      StringBuilder stringBuilder = new StringBuilder();
      stringBuilder.append("Cannot find span size for pre layout position. ");
      stringBuilder.append(paramInt);
      Log.w("GridLayoutManager", stringBuilder.toString());
      return 0;
    } 
    return this.L.a(i, this.G);
  }
  
  public int z(RecyclerView.r paramr, RecyclerView.v paramv) {
    return (this.q == 1) ? this.G : ((paramv.b() < 1) ? 0 : (y1(paramr, paramv, paramv.b() - 1) + 1));
  }
  
  public final int z1(RecyclerView.r paramr, RecyclerView.v paramv, int paramInt) {
    if (!paramv.f) {
      c1 = this.L;
      int j = this.G;
      Objects.requireNonNull(c1);
      return paramInt % j;
    } 
    int i = this.K.get(paramInt, -1);
    if (i != -1)
      return i; 
    i = c1.c(paramInt);
    if (i == -1) {
      StringBuilder stringBuilder = new StringBuilder();
      stringBuilder.append("Cannot find span size for pre layout position. It is not cached, not in the adapter. Pos:");
      stringBuilder.append(paramInt);
      Log.w("GridLayoutManager", stringBuilder.toString());
      return 0;
    } 
    c c1 = this.L;
    paramInt = this.G;
    Objects.requireNonNull(c1);
    return i % paramInt;
  }
  
  public static final class a extends c {}
  
  public static class b extends RecyclerView.m {
    public int e = -1;
    
    public int f = 0;
    
    public b(int param1Int1, int param1Int2) {
      super(param1Int1, param1Int2);
    }
    
    public b(Context param1Context, AttributeSet param1AttributeSet) {
      super(param1Context, param1AttributeSet);
    }
    
    public b(ViewGroup.LayoutParams param1LayoutParams) {
      super(param1LayoutParams);
    }
    
    public b(ViewGroup.MarginLayoutParams param1MarginLayoutParams) {
      super(param1MarginLayoutParams);
    }
  }
  
  public static abstract class c {
    public final SparseIntArray a = new SparseIntArray();
    
    public final SparseIntArray b = new SparseIntArray();
    
    public int a(int param1Int1, int param1Int2) {
      int k = 0;
      int i = k;
      int j;
      for (j = i; k < param1Int1; j = m) {
        int m;
        int n = i + 1;
        if (n == param1Int2) {
          m = j + 1;
          i = 0;
        } else {
          i = n;
          m = j;
          if (n > param1Int2) {
            m = j + 1;
            i = 1;
          } 
        } 
        k++;
      } 
      param1Int1 = j;
      if (i + 1 > param1Int2)
        param1Int1 = j + 1; 
      return param1Int1;
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Https Traffic-dex2jar.jar!\androidx\recyclerview\widget\GridLayoutManager.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */