package androidx.recyclerview.widget;

import android.content.Context;
import android.graphics.Rect;
import android.os.Parcel;
import android.os.Parcelable;
import android.util.AttributeSet;
import android.view.View;
import android.view.ViewGroup;
import android.view.accessibility.AccessibilityEvent;
import c.h.b.h;
import c.t.b.c0;
import c.t.b.u;
import c.t.b.x;
import java.util.List;
import java.util.Objects;

public class LinearLayoutManager extends RecyclerView.l {
  public d A = null;
  
  public final a B = new a();
  
  public final b C = new b();
  
  public int D = 2;
  
  public int[] E = new int[2];
  
  public int q = 1;
  
  public c r;
  
  public c0 s;
  
  public boolean t;
  
  public boolean u = false;
  
  public boolean v = false;
  
  public boolean w = false;
  
  public boolean x = true;
  
  public int y = -1;
  
  public int z = Integer.MIN_VALUE;
  
  public LinearLayoutManager(int paramInt, boolean paramBoolean) {
    q1(paramInt);
    c(null);
    if (paramBoolean == this.u)
      return; 
    this.u = paramBoolean;
    E0();
  }
  
  public LinearLayoutManager(Context paramContext, AttributeSet paramAttributeSet, int paramInt1, int paramInt2) {
    RecyclerView.l.b b1 = RecyclerView.l.M(paramContext, paramAttributeSet, paramInt1, paramInt2);
    q1(b1.a);
    boolean bool = b1.c;
    c(null);
    if (bool != this.u) {
      this.u = bool;
      E0();
    } 
    r1(b1.d);
  }
  
  public int F0(int paramInt, RecyclerView.r paramr, RecyclerView.v paramv) {
    return (this.q == 1) ? 0 : p1(paramInt, paramr, paramv);
  }
  
  public int G0(int paramInt, RecyclerView.r paramr, RecyclerView.v paramv) {
    return (this.q == 0) ? 0 : p1(paramInt, paramr, paramv);
  }
  
  public boolean N0() {
    int i = this.n;
    boolean bool2 = false;
    boolean bool1 = bool2;
    if (i != 1073741824) {
      bool1 = bool2;
      if (this.m != 1073741824) {
        int j = x();
        i = 0;
        while (true) {
          if (i < j) {
            ViewGroup.LayoutParams layoutParams = w(i).getLayoutParams();
            if (layoutParams.width < 0 && layoutParams.height < 0) {
              i = 1;
              break;
            } 
            i++;
            continue;
          } 
          i = 0;
          break;
        } 
        bool1 = bool2;
        if (i != 0)
          bool1 = true; 
      } 
    } 
    return bool1;
  }
  
  public boolean P0() {
    return (this.A == null && this.t == this.w);
  }
  
  public boolean Q() {
    return true;
  }
  
  public void Q0(RecyclerView.v paramv, c paramc, RecyclerView.l.a parama) {
    int i = paramc.d;
    if (i >= 0 && i < paramv.b()) {
      int j = Math.max(0, paramc.g);
      ((u.a)parama).a(i, j);
    } 
  }
  
  public final int R0(RecyclerView.v paramv) {
    if (x() == 0)
      return 0; 
    V0();
    return h.k(paramv, this.s, Z0(this.x ^ true, true), Y0(this.x ^ true, true), this, this.x);
  }
  
  public final int S0(RecyclerView.v paramv) {
    if (x() == 0)
      return 0; 
    V0();
    return h.l(paramv, this.s, Z0(this.x ^ true, true), Y0(this.x ^ true, true), this, this.x, this.v);
  }
  
  public final int T0(RecyclerView.v paramv) {
    if (x() == 0)
      return 0; 
    V0();
    return h.m(paramv, this.s, Z0(this.x ^ true, true), Y0(this.x ^ true, true), this, this.x);
  }
  
  public int U0(int paramInt) {
    return (paramInt != 1) ? ((paramInt != 2) ? ((paramInt != 17) ? ((paramInt != 33) ? ((paramInt != 66) ? ((paramInt != 130) ? Integer.MIN_VALUE : ((this.q == 1) ? 1 : Integer.MIN_VALUE)) : ((this.q == 0) ? 1 : Integer.MIN_VALUE)) : ((this.q == 1) ? -1 : Integer.MIN_VALUE)) : ((this.q == 0) ? -1 : Integer.MIN_VALUE)) : ((this.q == 1) ? 1 : (i1() ? -1 : 1))) : ((this.q == 1) ? -1 : (i1() ? 1 : -1));
  }
  
  public void V0() {
    if (this.r == null)
      this.r = new c(); 
  }
  
  public int W0(RecyclerView.r paramr, c paramc, RecyclerView.v paramv, boolean paramBoolean) {
    int k = paramc.c;
    int i = paramc.g;
    if (i != Integer.MIN_VALUE) {
      if (k < 0)
        paramc.g = i + k; 
      l1(paramr, paramc);
    } 
    int j = paramc.c + paramc.h;
    b b1 = this.C;
    while (true) {
      while (true)
        break; 
      if (paramBoolean) {
        j = i;
        if (b1.d)
          break; 
      } 
    } 
    return k - paramc.c;
  }
  
  public final View X0(RecyclerView.r paramr, RecyclerView.v paramv) {
    return d1(paramr, paramv, 0, x(), paramv.b());
  }
  
  public View Y0(boolean paramBoolean1, boolean paramBoolean2) {
    return this.v ? c1(0, x(), paramBoolean1, paramBoolean2) : c1(x() - 1, -1, paramBoolean1, paramBoolean2);
  }
  
  public View Z0(boolean paramBoolean1, boolean paramBoolean2) {
    return this.v ? c1(x() - 1, -1, paramBoolean1, paramBoolean2) : c1(0, x(), paramBoolean1, paramBoolean2);
  }
  
  public final View a1(RecyclerView.r paramr, RecyclerView.v paramv) {
    return d1(paramr, paramv, x() - 1, -1, paramv.b());
  }
  
  public void b0(RecyclerView paramRecyclerView, RecyclerView.r paramr) {
    a0();
  }
  
  public View b1(int paramInt1, int paramInt2) {
    char c1;
    char c2;
    V0();
    if (paramInt2 > paramInt1) {
      c1 = '\001';
    } else if (paramInt2 < paramInt1) {
      c1 = '￿';
    } else {
      c1 = Character.MIN_VALUE;
    } 
    if (!c1)
      return w(paramInt1); 
    if (this.s.e(w(paramInt1)) < this.s.k()) {
      c1 = '䄄';
      c2 = '䀄';
    } else {
      c1 = '၁';
      c2 = 'ခ';
    } 
    return (this.q == 0) ? this.e.a(paramInt1, paramInt2, c1, c2) : this.f.a(paramInt1, paramInt2, c1, c2);
  }
  
  public void c(String paramString) {
    if (this.A == null) {
      RecyclerView recyclerView = this.b;
      if (recyclerView != null)
        recyclerView.g(paramString); 
    } 
  }
  
  public View c0(View paramView, int paramInt, RecyclerView.r paramr, RecyclerView.v paramv) {
    View view1;
    View view2;
    o1();
    if (x() == 0)
      return null; 
    paramInt = U0(paramInt);
    if (paramInt == Integer.MIN_VALUE)
      return null; 
    V0();
    s1(paramInt, (int)(this.s.l() * 0.33333334F), false, paramv);
    c c1 = this.r;
    c1.g = Integer.MIN_VALUE;
    c1.a = false;
    W0(paramr, c1, paramv, true);
    if (paramInt == -1) {
      if (this.v) {
        view1 = b1(x() - 1, -1);
      } else {
        view1 = b1(0, x());
      } 
    } else if (this.v) {
      view1 = b1(0, x());
    } else {
      view1 = b1(x() - 1, -1);
    } 
    if (paramInt == -1) {
      view2 = h1();
    } else {
      view2 = g1();
    } 
    return view2.hasFocusable() ? ((view1 == null) ? null : view2) : view1;
  }
  
  public View c1(int paramInt1, int paramInt2, boolean paramBoolean1, boolean paramBoolean2) {
    char c1;
    V0();
    char c2 = 'ŀ';
    if (paramBoolean1) {
      c1 = '怃';
    } else {
      c1 = 'ŀ';
    } 
    if (!paramBoolean2)
      c2 = Character.MIN_VALUE; 
    return (this.q == 0) ? this.e.a(paramInt1, paramInt2, c1, c2) : this.f.a(paramInt1, paramInt2, c1, c2);
  }
  
  public boolean d() {
    return (this.q == 0);
  }
  
  public void d0(AccessibilityEvent paramAccessibilityEvent) {
    RecyclerView.r r = this.b.f;
    e0(paramAccessibilityEvent);
    if (x() > 0) {
      int i;
      View view = c1(0, x(), false, true);
      byte b1 = -1;
      if (view == null) {
        i = -1;
      } else {
        i = L(view);
      } 
      paramAccessibilityEvent.setFromIndex(i);
      view = c1(x() - 1, -1, false, true);
      if (view == null) {
        i = b1;
      } else {
        i = L(view);
      } 
      paramAccessibilityEvent.setToIndex(i);
    } 
  }
  
  public View d1(RecyclerView.r paramr, RecyclerView.v paramv, int paramInt1, int paramInt2, int paramInt3) {
    View view;
    byte b1;
    V0();
    int i = this.s.k();
    int j = this.s.g();
    if (paramInt2 > paramInt1) {
      b1 = 1;
    } else {
      b1 = -1;
    } 
    paramv = null;
    for (paramr = null; paramInt1 != paramInt2; paramr = r1) {
      View view1;
      View view2 = w(paramInt1);
      int k = L(view2);
      RecyclerView.v v1 = paramv;
      RecyclerView.r r1 = paramr;
      if (k >= 0) {
        v1 = paramv;
        r1 = paramr;
        if (k < paramInt3)
          if (((RecyclerView.m)view2.getLayoutParams()).c()) {
            v1 = paramv;
            r1 = paramr;
            if (paramr == null) {
              View view3 = view2;
              v1 = paramv;
            } 
          } else if (this.s.e(view2) >= j || this.s.b(view2) < i) {
            v1 = paramv;
            r1 = paramr;
            if (paramv == null) {
              view1 = view2;
              r1 = paramr;
            } 
          } else {
            return view2;
          }  
      } 
      paramInt1 += b1;
      view = view1;
    } 
    return (View)((view != null) ? view : paramr);
  }
  
  public boolean e() {
    return (this.q == 1);
  }
  
  public final int e1(int paramInt, RecyclerView.r paramr, RecyclerView.v paramv, boolean paramBoolean) {
    int i = this.s.g() - paramInt;
    if (i > 0) {
      i = -p1(-i, paramr, paramv);
      if (paramBoolean) {
        paramInt = this.s.g() - paramInt + i;
        if (paramInt > 0) {
          this.s.p(paramInt);
          return paramInt + i;
        } 
      } 
      return i;
    } 
    return 0;
  }
  
  public final int f1(int paramInt, RecyclerView.r paramr, RecyclerView.v paramv, boolean paramBoolean) {
    int i = paramInt - this.s.k();
    if (i > 0) {
      int j = -p1(i, paramr, paramv);
      i = j;
      if (paramBoolean) {
        paramInt = paramInt + j - this.s.k();
        i = j;
        if (paramInt > 0) {
          this.s.p(-paramInt);
          i = j - paramInt;
        } 
      } 
      return i;
    } 
    return 0;
  }
  
  public final View g1() {
    int i;
    if (this.v) {
      i = 0;
    } else {
      i = x() - 1;
    } 
    return w(i);
  }
  
  public void h(int paramInt1, int paramInt2, RecyclerView.v paramv, RecyclerView.l.a parama) {
    if (this.q != 0)
      paramInt1 = paramInt2; 
    if (x() != 0) {
      if (paramInt1 == 0)
        return; 
      V0();
      if (paramInt1 > 0) {
        paramInt2 = 1;
      } else {
        paramInt2 = -1;
      } 
      s1(paramInt2, Math.abs(paramInt1), true, paramv);
      Q0(paramv, this.r, parama);
    } 
  }
  
  public final View h1() {
    boolean bool;
    if (this.v) {
      bool = x() - 1;
    } else {
      bool = false;
    } 
    return w(bool);
  }
  
  public void i(int paramInt, RecyclerView.l.a parama) {
    int i;
    boolean bool;
    d d1 = this.A;
    byte b1 = -1;
    if (d1 != null && d1.a()) {
      d1 = this.A;
      bool = d1.g;
      i = d1.e;
    } else {
      o1();
      boolean bool1 = this.v;
      int k = this.y;
      i = k;
      bool = bool1;
      if (k == -1)
        if (bool1) {
          i = paramInt - 1;
          bool = bool1;
        } else {
          i = 0;
          bool = bool1;
        }  
    } 
    if (!bool)
      b1 = 1; 
    int j;
    for (j = 0; j < this.D && i >= 0 && i < paramInt; j++) {
      ((u.a)parama).a(i, 0);
      i += b1;
    } 
  }
  
  public boolean i1() {
    return (E() == 1);
  }
  
  public int j(RecyclerView.v paramv) {
    return R0(paramv);
  }
  
  public void j1(RecyclerView.r paramr, RecyclerView.v paramv, c paramc, b paramb) {
    View view = paramc.c(paramr);
    if (view == null) {
      paramb.b = true;
      return;
    } 
    RecyclerView.m m1 = (RecyclerView.m)view.getLayoutParams();
    if (paramc.k == null) {
      boolean bool1;
      boolean bool2 = this.v;
      if (paramc.f == -1) {
        bool1 = true;
      } else {
        bool1 = false;
      } 
      if (bool2 == bool1) {
        b(view, -1, false);
      } else {
        b(view, 0, false);
      } 
    } else {
      boolean bool1;
      boolean bool2 = this.v;
      if (paramc.f == -1) {
        bool1 = true;
      } else {
        bool1 = false;
      } 
      if (bool2 == bool1) {
        b(view, -1, true);
      } else {
        b(view, 0, true);
      } 
    } 
    RecyclerView.m m2 = (RecyclerView.m)view.getLayoutParams();
    Rect rect = this.b.J(view);
    int k = rect.left;
    int m = rect.right;
    int i = rect.top;
    int j = rect.bottom;
    int n = this.o;
    int i1 = this.m;
    int i2 = I();
    k = RecyclerView.l.y(n, i1, J() + i2 + m2.leftMargin + m2.rightMargin + k + m + 0, m2.width, d());
    m = this.p;
    n = this.n;
    i1 = K();
    i = RecyclerView.l.y(m, n, H() + i1 + m2.topMargin + m2.bottomMargin + i + j + 0, m2.height, e());
    if (M0(view, k, i, m2))
      view.measure(k, i); 
    paramb.a = this.s.c(view);
    if (this.q == 1) {
      if (i1()) {
        i = this.o - J();
        j = i - this.s.d(view);
      } else {
        j = I();
        i = this.s.d(view) + j;
      } 
      if (paramc.f == -1) {
        m = paramc.b;
        i1 = paramb.a;
        k = m;
        n = i;
        i = m - i1;
        m = j;
        j = n;
      } else {
        m = paramc.b;
        i1 = paramb.a;
        k = m;
        n = i;
        i1 += m;
        m = j;
        i = k;
        j = n;
        k = i1;
      } 
    } else {
      m = K();
      i = this.s.d(view) + m;
      if (paramc.f == -1) {
        i1 = paramc.b;
        i2 = paramb.a;
        j = i1;
        n = m;
        k = i;
        m = i1 - i2;
        i = n;
      } else {
        n = paramc.b;
        j = paramb.a;
        j += n;
        k = i;
        i = m;
        m = n;
      } 
    } 
    U(view, m, i, j, k);
    if (m1.c() || m1.b())
      paramb.c = true; 
    paramb.d = view.hasFocusable();
  }
  
  public int k(RecyclerView.v paramv) {
    return S0(paramv);
  }
  
  public void k1(RecyclerView.r paramr, RecyclerView.v paramv, a parama, int paramInt) {}
  
  public int l(RecyclerView.v paramv) {
    return T0(paramv);
  }
  
  public final void l1(RecyclerView.r paramr, c paramc) {
    if (paramc.a) {
      if (paramc.l)
        return; 
      int i = paramc.g;
      int j = paramc.i;
      if (paramc.f == -1) {
        int k = x();
        if (i < 0)
          return; 
        j = this.s.f() - i + j;
        if (this.v) {
          for (i = 0; i < k; i++) {
            View view = w(i);
            if (this.s.e(view) < j || this.s.o(view) < j) {
              m1(paramr, 0, i);
              return;
            } 
          } 
        } else {
          for (i = --k; i >= 0; i--) {
            View view = w(i);
            if (this.s.e(view) < j || this.s.o(view) < j) {
              m1(paramr, k, i);
              return;
            } 
          } 
        } 
      } else {
        if (i < 0)
          return; 
        j = i - j;
        int k = x();
        if (this.v) {
          for (i = --k; i >= 0; i--) {
            View view = w(i);
            if (this.s.b(view) > j || this.s.n(view) > j) {
              m1(paramr, k, i);
              return;
            } 
          } 
        } else {
          for (i = 0; i < k; i++) {
            View view = w(i);
            if (this.s.b(view) > j || this.s.n(view) > j) {
              m1(paramr, 0, i);
              break;
            } 
          } 
        } 
      } 
    } 
  }
  
  public int m(RecyclerView.v paramv) {
    return R0(paramv);
  }
  
  public final void m1(RecyclerView.r paramr, int paramInt1, int paramInt2) {
    if (paramInt1 == paramInt2)
      return; 
    int i = paramInt1;
    if (paramInt2 > paramInt1) {
      while (--paramInt2 >= paramInt1) {
        B0(paramInt2, paramr);
        paramInt2--;
      } 
    } else {
      while (i > paramInt2) {
        B0(i, paramr);
        i--;
      } 
    } 
  }
  
  public int n(RecyclerView.v paramv) {
    return S0(paramv);
  }
  
  public boolean n1() {
    return (this.s.i() == 0 && this.s.f() == 0);
  }
  
  public int o(RecyclerView.v paramv) {
    return T0(paramv);
  }
  
  public void o0(RecyclerView.r paramr, RecyclerView.v paramv) {
    // Byte code:
    //   0: aload_0
    //   1: getfield A : Landroidx/recyclerview/widget/LinearLayoutManager$d;
    //   4: ifnonnull -> 15
    //   7: aload_0
    //   8: getfield y : I
    //   11: iconst_m1
    //   12: if_icmpeq -> 28
    //   15: aload_2
    //   16: invokevirtual b : ()I
    //   19: ifne -> 28
    //   22: aload_0
    //   23: aload_1
    //   24: invokevirtual y0 : (Landroidx/recyclerview/widget/RecyclerView$r;)V
    //   27: return
    //   28: aload_0
    //   29: getfield A : Landroidx/recyclerview/widget/LinearLayoutManager$d;
    //   32: astore #12
    //   34: aload #12
    //   36: ifnull -> 58
    //   39: aload #12
    //   41: invokevirtual a : ()Z
    //   44: ifeq -> 58
    //   47: aload_0
    //   48: aload_0
    //   49: getfield A : Landroidx/recyclerview/widget/LinearLayoutManager$d;
    //   52: getfield e : I
    //   55: putfield y : I
    //   58: aload_0
    //   59: invokevirtual V0 : ()V
    //   62: aload_0
    //   63: getfield r : Landroidx/recyclerview/widget/LinearLayoutManager$c;
    //   66: iconst_0
    //   67: putfield a : Z
    //   70: aload_0
    //   71: invokevirtual o1 : ()V
    //   74: aload_0
    //   75: invokevirtual D : ()Landroid/view/View;
    //   78: astore #12
    //   80: aload_0
    //   81: getfield B : Landroidx/recyclerview/widget/LinearLayoutManager$a;
    //   84: astore #13
    //   86: aload #13
    //   88: getfield e : Z
    //   91: ifeq -> 173
    //   94: aload_0
    //   95: getfield y : I
    //   98: iconst_m1
    //   99: if_icmpne -> 173
    //   102: aload_0
    //   103: getfield A : Landroidx/recyclerview/widget/LinearLayoutManager$d;
    //   106: ifnull -> 112
    //   109: goto -> 173
    //   112: aload #12
    //   114: ifnull -> 990
    //   117: aload_0
    //   118: getfield s : Lc/t/b/c0;
    //   121: aload #12
    //   123: invokevirtual e : (Landroid/view/View;)I
    //   126: aload_0
    //   127: getfield s : Lc/t/b/c0;
    //   130: invokevirtual g : ()I
    //   133: if_icmpge -> 155
    //   136: aload_0
    //   137: getfield s : Lc/t/b/c0;
    //   140: aload #12
    //   142: invokevirtual b : (Landroid/view/View;)I
    //   145: aload_0
    //   146: getfield s : Lc/t/b/c0;
    //   149: invokevirtual k : ()I
    //   152: if_icmpgt -> 990
    //   155: aload_0
    //   156: getfield B : Landroidx/recyclerview/widget/LinearLayoutManager$a;
    //   159: aload #12
    //   161: aload_0
    //   162: aload #12
    //   164: invokevirtual L : (Landroid/view/View;)I
    //   167: invokevirtual c : (Landroid/view/View;I)V
    //   170: goto -> 990
    //   173: aload #13
    //   175: invokevirtual d : ()V
    //   178: aload_0
    //   179: getfield B : Landroidx/recyclerview/widget/LinearLayoutManager$a;
    //   182: astore #13
    //   184: aload #13
    //   186: aload_0
    //   187: getfield v : Z
    //   190: aload_0
    //   191: getfield w : Z
    //   194: ixor
    //   195: putfield d : Z
    //   198: aload_2
    //   199: getfield f : Z
    //   202: ifne -> 649
    //   205: aload_0
    //   206: getfield y : I
    //   209: istore_3
    //   210: iload_3
    //   211: iconst_m1
    //   212: if_icmpne -> 218
    //   215: goto -> 649
    //   218: iload_3
    //   219: iflt -> 638
    //   222: iload_3
    //   223: aload_2
    //   224: invokevirtual b : ()I
    //   227: if_icmplt -> 233
    //   230: goto -> 638
    //   233: aload #13
    //   235: aload_0
    //   236: getfield y : I
    //   239: putfield b : I
    //   242: aload_0
    //   243: getfield A : Landroidx/recyclerview/widget/LinearLayoutManager$d;
    //   246: astore #12
    //   248: aload #12
    //   250: ifnull -> 328
    //   253: aload #12
    //   255: invokevirtual a : ()Z
    //   258: ifeq -> 328
    //   261: aload_0
    //   262: getfield A : Landroidx/recyclerview/widget/LinearLayoutManager$d;
    //   265: getfield g : Z
    //   268: istore #11
    //   270: aload #13
    //   272: iload #11
    //   274: putfield d : Z
    //   277: iload #11
    //   279: ifeq -> 305
    //   282: aload #13
    //   284: aload_0
    //   285: getfield s : Lc/t/b/c0;
    //   288: invokevirtual g : ()I
    //   291: aload_0
    //   292: getfield A : Landroidx/recyclerview/widget/LinearLayoutManager$d;
    //   295: getfield f : I
    //   298: isub
    //   299: putfield c : I
    //   302: goto -> 633
    //   305: aload #13
    //   307: aload_0
    //   308: getfield s : Lc/t/b/c0;
    //   311: invokevirtual k : ()I
    //   314: aload_0
    //   315: getfield A : Landroidx/recyclerview/widget/LinearLayoutManager$d;
    //   318: getfield f : I
    //   321: iadd
    //   322: putfield c : I
    //   325: goto -> 633
    //   328: aload_0
    //   329: getfield z : I
    //   332: ldc -2147483648
    //   334: if_icmpne -> 578
    //   337: aload_0
    //   338: aload_0
    //   339: getfield y : I
    //   342: invokevirtual s : (I)Landroid/view/View;
    //   345: astore #12
    //   347: aload #12
    //   349: ifnull -> 511
    //   352: aload_0
    //   353: getfield s : Lc/t/b/c0;
    //   356: aload #12
    //   358: invokevirtual c : (Landroid/view/View;)I
    //   361: aload_0
    //   362: getfield s : Lc/t/b/c0;
    //   365: invokevirtual l : ()I
    //   368: if_icmple -> 379
    //   371: aload #13
    //   373: invokevirtual a : ()V
    //   376: goto -> 633
    //   379: aload_0
    //   380: getfield s : Lc/t/b/c0;
    //   383: aload #12
    //   385: invokevirtual e : (Landroid/view/View;)I
    //   388: aload_0
    //   389: getfield s : Lc/t/b/c0;
    //   392: invokevirtual k : ()I
    //   395: isub
    //   396: ifge -> 420
    //   399: aload #13
    //   401: aload_0
    //   402: getfield s : Lc/t/b/c0;
    //   405: invokevirtual k : ()I
    //   408: putfield c : I
    //   411: aload #13
    //   413: iconst_0
    //   414: putfield d : Z
    //   417: goto -> 633
    //   420: aload_0
    //   421: getfield s : Lc/t/b/c0;
    //   424: invokevirtual g : ()I
    //   427: aload_0
    //   428: getfield s : Lc/t/b/c0;
    //   431: aload #12
    //   433: invokevirtual b : (Landroid/view/View;)I
    //   436: isub
    //   437: ifge -> 461
    //   440: aload #13
    //   442: aload_0
    //   443: getfield s : Lc/t/b/c0;
    //   446: invokevirtual g : ()I
    //   449: putfield c : I
    //   452: aload #13
    //   454: iconst_1
    //   455: putfield d : Z
    //   458: goto -> 633
    //   461: aload #13
    //   463: getfield d : Z
    //   466: ifeq -> 492
    //   469: aload_0
    //   470: getfield s : Lc/t/b/c0;
    //   473: aload #12
    //   475: invokevirtual b : (Landroid/view/View;)I
    //   478: istore_3
    //   479: aload_0
    //   480: getfield s : Lc/t/b/c0;
    //   483: invokevirtual m : ()I
    //   486: iload_3
    //   487: iadd
    //   488: istore_3
    //   489: goto -> 502
    //   492: aload_0
    //   493: getfield s : Lc/t/b/c0;
    //   496: aload #12
    //   498: invokevirtual e : (Landroid/view/View;)I
    //   501: istore_3
    //   502: aload #13
    //   504: iload_3
    //   505: putfield c : I
    //   508: goto -> 633
    //   511: aload_0
    //   512: invokevirtual x : ()I
    //   515: ifle -> 570
    //   518: aload_0
    //   519: aload_0
    //   520: iconst_0
    //   521: invokevirtual w : (I)Landroid/view/View;
    //   524: invokevirtual L : (Landroid/view/View;)I
    //   527: istore_3
    //   528: aload_0
    //   529: getfield y : I
    //   532: iload_3
    //   533: if_icmpge -> 542
    //   536: iconst_1
    //   537: istore #11
    //   539: goto -> 545
    //   542: iconst_0
    //   543: istore #11
    //   545: iload #11
    //   547: aload_0
    //   548: getfield v : Z
    //   551: if_icmpne -> 560
    //   554: iconst_1
    //   555: istore #11
    //   557: goto -> 563
    //   560: iconst_0
    //   561: istore #11
    //   563: aload #13
    //   565: iload #11
    //   567: putfield d : Z
    //   570: aload #13
    //   572: invokevirtual a : ()V
    //   575: goto -> 633
    //   578: aload_0
    //   579: getfield v : Z
    //   582: istore #11
    //   584: aload #13
    //   586: iload #11
    //   588: putfield d : Z
    //   591: iload #11
    //   593: ifeq -> 616
    //   596: aload #13
    //   598: aload_0
    //   599: getfield s : Lc/t/b/c0;
    //   602: invokevirtual g : ()I
    //   605: aload_0
    //   606: getfield z : I
    //   609: isub
    //   610: putfield c : I
    //   613: goto -> 633
    //   616: aload #13
    //   618: aload_0
    //   619: getfield s : Lc/t/b/c0;
    //   622: invokevirtual k : ()I
    //   625: aload_0
    //   626: getfield z : I
    //   629: iadd
    //   630: putfield c : I
    //   633: iconst_1
    //   634: istore_3
    //   635: goto -> 651
    //   638: aload_0
    //   639: iconst_m1
    //   640: putfield y : I
    //   643: aload_0
    //   644: ldc -2147483648
    //   646: putfield z : I
    //   649: iconst_0
    //   650: istore_3
    //   651: iload_3
    //   652: ifeq -> 658
    //   655: goto -> 982
    //   658: aload_0
    //   659: invokevirtual x : ()I
    //   662: ifne -> 668
    //   665: goto -> 943
    //   668: aload_0
    //   669: invokevirtual D : ()Landroid/view/View;
    //   672: astore #12
    //   674: aload #12
    //   676: ifnull -> 744
    //   679: aload #12
    //   681: invokevirtual getLayoutParams : ()Landroid/view/ViewGroup$LayoutParams;
    //   684: checkcast androidx/recyclerview/widget/RecyclerView$m
    //   687: astore #14
    //   689: aload #14
    //   691: invokevirtual c : ()Z
    //   694: ifne -> 722
    //   697: aload #14
    //   699: invokevirtual a : ()I
    //   702: iflt -> 722
    //   705: aload #14
    //   707: invokevirtual a : ()I
    //   710: aload_2
    //   711: invokevirtual b : ()I
    //   714: if_icmpge -> 722
    //   717: iconst_1
    //   718: istore_3
    //   719: goto -> 724
    //   722: iconst_0
    //   723: istore_3
    //   724: iload_3
    //   725: ifeq -> 744
    //   728: aload #13
    //   730: aload #12
    //   732: aload_0
    //   733: aload #12
    //   735: invokevirtual L : (Landroid/view/View;)I
    //   738: invokevirtual c : (Landroid/view/View;I)V
    //   741: goto -> 938
    //   744: aload_0
    //   745: getfield t : Z
    //   748: aload_0
    //   749: getfield w : Z
    //   752: if_icmpeq -> 758
    //   755: goto -> 943
    //   758: aload #13
    //   760: getfield d : Z
    //   763: ifeq -> 795
    //   766: aload_0
    //   767: getfield v : Z
    //   770: ifeq -> 784
    //   773: aload_0
    //   774: aload_1
    //   775: aload_2
    //   776: invokevirtual X0 : (Landroidx/recyclerview/widget/RecyclerView$r;Landroidx/recyclerview/widget/RecyclerView$v;)Landroid/view/View;
    //   779: astore #12
    //   781: goto -> 821
    //   784: aload_0
    //   785: aload_1
    //   786: aload_2
    //   787: invokevirtual a1 : (Landroidx/recyclerview/widget/RecyclerView$r;Landroidx/recyclerview/widget/RecyclerView$v;)Landroid/view/View;
    //   790: astore #12
    //   792: goto -> 821
    //   795: aload_0
    //   796: getfield v : Z
    //   799: ifeq -> 813
    //   802: aload_0
    //   803: aload_1
    //   804: aload_2
    //   805: invokevirtual a1 : (Landroidx/recyclerview/widget/RecyclerView$r;Landroidx/recyclerview/widget/RecyclerView$v;)Landroid/view/View;
    //   808: astore #12
    //   810: goto -> 821
    //   813: aload_0
    //   814: aload_1
    //   815: aload_2
    //   816: invokevirtual X0 : (Landroidx/recyclerview/widget/RecyclerView$r;Landroidx/recyclerview/widget/RecyclerView$v;)Landroid/view/View;
    //   819: astore #12
    //   821: aload #12
    //   823: ifnull -> 943
    //   826: aload #13
    //   828: aload #12
    //   830: aload_0
    //   831: aload #12
    //   833: invokevirtual L : (Landroid/view/View;)I
    //   836: invokevirtual b : (Landroid/view/View;I)V
    //   839: aload_2
    //   840: getfield f : Z
    //   843: ifne -> 938
    //   846: aload_0
    //   847: invokevirtual P0 : ()Z
    //   850: ifeq -> 938
    //   853: aload_0
    //   854: getfield s : Lc/t/b/c0;
    //   857: aload #12
    //   859: invokevirtual e : (Landroid/view/View;)I
    //   862: aload_0
    //   863: getfield s : Lc/t/b/c0;
    //   866: invokevirtual g : ()I
    //   869: if_icmpge -> 899
    //   872: aload_0
    //   873: getfield s : Lc/t/b/c0;
    //   876: aload #12
    //   878: invokevirtual b : (Landroid/view/View;)I
    //   881: aload_0
    //   882: getfield s : Lc/t/b/c0;
    //   885: invokevirtual k : ()I
    //   888: if_icmpge -> 894
    //   891: goto -> 899
    //   894: iconst_0
    //   895: istore_3
    //   896: goto -> 901
    //   899: iconst_1
    //   900: istore_3
    //   901: iload_3
    //   902: ifeq -> 938
    //   905: aload #13
    //   907: getfield d : Z
    //   910: ifeq -> 924
    //   913: aload_0
    //   914: getfield s : Lc/t/b/c0;
    //   917: invokevirtual g : ()I
    //   920: istore_3
    //   921: goto -> 932
    //   924: aload_0
    //   925: getfield s : Lc/t/b/c0;
    //   928: invokevirtual k : ()I
    //   931: istore_3
    //   932: aload #13
    //   934: iload_3
    //   935: putfield c : I
    //   938: iconst_1
    //   939: istore_3
    //   940: goto -> 945
    //   943: iconst_0
    //   944: istore_3
    //   945: iload_3
    //   946: ifeq -> 952
    //   949: goto -> 982
    //   952: aload #13
    //   954: invokevirtual a : ()V
    //   957: aload_0
    //   958: getfield w : Z
    //   961: ifeq -> 974
    //   964: aload_2
    //   965: invokevirtual b : ()I
    //   968: iconst_1
    //   969: isub
    //   970: istore_3
    //   971: goto -> 976
    //   974: iconst_0
    //   975: istore_3
    //   976: aload #13
    //   978: iload_3
    //   979: putfield b : I
    //   982: aload_0
    //   983: getfield B : Landroidx/recyclerview/widget/LinearLayoutManager$a;
    //   986: iconst_1
    //   987: putfield e : Z
    //   990: aload_0
    //   991: getfield r : Landroidx/recyclerview/widget/LinearLayoutManager$c;
    //   994: astore #12
    //   996: aload #12
    //   998: getfield j : I
    //   1001: iflt -> 1009
    //   1004: iconst_1
    //   1005: istore_3
    //   1006: goto -> 1011
    //   1009: iconst_m1
    //   1010: istore_3
    //   1011: aload #12
    //   1013: iload_3
    //   1014: putfield f : I
    //   1017: aload_0
    //   1018: getfield E : [I
    //   1021: astore #12
    //   1023: aload #12
    //   1025: iconst_0
    //   1026: iconst_0
    //   1027: iastore
    //   1028: aload #12
    //   1030: iconst_1
    //   1031: iconst_0
    //   1032: iastore
    //   1033: aload_2
    //   1034: invokestatic requireNonNull : (Ljava/lang/Object;)Ljava/lang/Object;
    //   1037: pop
    //   1038: aload_0
    //   1039: getfield r : Landroidx/recyclerview/widget/LinearLayoutManager$c;
    //   1042: getfield f : I
    //   1045: istore_3
    //   1046: aload #12
    //   1048: iconst_0
    //   1049: iconst_0
    //   1050: iastore
    //   1051: aload #12
    //   1053: iconst_1
    //   1054: iconst_0
    //   1055: iastore
    //   1056: iconst_0
    //   1057: aload_0
    //   1058: getfield E : [I
    //   1061: iconst_0
    //   1062: iaload
    //   1063: invokestatic max : (II)I
    //   1066: istore_3
    //   1067: aload_0
    //   1068: getfield s : Lc/t/b/c0;
    //   1071: invokevirtual k : ()I
    //   1074: iload_3
    //   1075: iadd
    //   1076: istore #5
    //   1078: iconst_0
    //   1079: aload_0
    //   1080: getfield E : [I
    //   1083: iconst_1
    //   1084: iaload
    //   1085: invokestatic max : (II)I
    //   1088: istore_3
    //   1089: aload_0
    //   1090: getfield s : Lc/t/b/c0;
    //   1093: invokevirtual h : ()I
    //   1096: iload_3
    //   1097: iadd
    //   1098: istore #6
    //   1100: iload #5
    //   1102: istore_3
    //   1103: iload #6
    //   1105: istore #4
    //   1107: aload_2
    //   1108: getfield f : Z
    //   1111: ifeq -> 1257
    //   1114: aload_0
    //   1115: getfield y : I
    //   1118: istore #7
    //   1120: iload #5
    //   1122: istore_3
    //   1123: iload #6
    //   1125: istore #4
    //   1127: iload #7
    //   1129: iconst_m1
    //   1130: if_icmpeq -> 1257
    //   1133: iload #5
    //   1135: istore_3
    //   1136: iload #6
    //   1138: istore #4
    //   1140: aload_0
    //   1141: getfield z : I
    //   1144: ldc -2147483648
    //   1146: if_icmpeq -> 1257
    //   1149: aload_0
    //   1150: iload #7
    //   1152: invokevirtual s : (I)Landroid/view/View;
    //   1155: astore #12
    //   1157: iload #5
    //   1159: istore_3
    //   1160: iload #6
    //   1162: istore #4
    //   1164: aload #12
    //   1166: ifnull -> 1257
    //   1169: aload_0
    //   1170: getfield v : Z
    //   1173: ifeq -> 1203
    //   1176: aload_0
    //   1177: getfield s : Lc/t/b/c0;
    //   1180: invokevirtual g : ()I
    //   1183: aload_0
    //   1184: getfield s : Lc/t/b/c0;
    //   1187: aload #12
    //   1189: invokevirtual b : (Landroid/view/View;)I
    //   1192: isub
    //   1193: istore #4
    //   1195: aload_0
    //   1196: getfield z : I
    //   1199: istore_3
    //   1200: goto -> 1227
    //   1203: aload_0
    //   1204: getfield s : Lc/t/b/c0;
    //   1207: aload #12
    //   1209: invokevirtual e : (Landroid/view/View;)I
    //   1212: aload_0
    //   1213: getfield s : Lc/t/b/c0;
    //   1216: invokevirtual k : ()I
    //   1219: isub
    //   1220: istore_3
    //   1221: aload_0
    //   1222: getfield z : I
    //   1225: istore #4
    //   1227: iload #4
    //   1229: iload_3
    //   1230: isub
    //   1231: istore_3
    //   1232: iload_3
    //   1233: ifle -> 1248
    //   1236: iload #5
    //   1238: iload_3
    //   1239: iadd
    //   1240: istore_3
    //   1241: iload #6
    //   1243: istore #4
    //   1245: goto -> 1257
    //   1248: iload #6
    //   1250: iload_3
    //   1251: isub
    //   1252: istore #4
    //   1254: iload #5
    //   1256: istore_3
    //   1257: aload_0
    //   1258: getfield B : Landroidx/recyclerview/widget/LinearLayoutManager$a;
    //   1261: astore #12
    //   1263: aload #12
    //   1265: getfield d : Z
    //   1268: ifeq -> 1281
    //   1271: aload_0
    //   1272: getfield v : Z
    //   1275: ifeq -> 1288
    //   1278: goto -> 1294
    //   1281: aload_0
    //   1282: getfield v : Z
    //   1285: ifeq -> 1294
    //   1288: iconst_m1
    //   1289: istore #5
    //   1291: goto -> 1297
    //   1294: iconst_1
    //   1295: istore #5
    //   1297: aload_0
    //   1298: aload_1
    //   1299: aload_2
    //   1300: aload #12
    //   1302: iload #5
    //   1304: invokevirtual k1 : (Landroidx/recyclerview/widget/RecyclerView$r;Landroidx/recyclerview/widget/RecyclerView$v;Landroidx/recyclerview/widget/LinearLayoutManager$a;I)V
    //   1307: aload_0
    //   1308: aload_1
    //   1309: invokevirtual p : (Landroidx/recyclerview/widget/RecyclerView$r;)V
    //   1312: aload_0
    //   1313: getfield r : Landroidx/recyclerview/widget/LinearLayoutManager$c;
    //   1316: aload_0
    //   1317: invokevirtual n1 : ()Z
    //   1320: putfield l : Z
    //   1323: aload_0
    //   1324: getfield r : Landroidx/recyclerview/widget/LinearLayoutManager$c;
    //   1327: invokestatic requireNonNull : (Ljava/lang/Object;)Ljava/lang/Object;
    //   1330: pop
    //   1331: aload_0
    //   1332: getfield r : Landroidx/recyclerview/widget/LinearLayoutManager$c;
    //   1335: iconst_0
    //   1336: putfield i : I
    //   1339: aload_0
    //   1340: getfield B : Landroidx/recyclerview/widget/LinearLayoutManager$a;
    //   1343: astore #12
    //   1345: aload #12
    //   1347: getfield d : Z
    //   1350: ifeq -> 1566
    //   1353: aload_0
    //   1354: aload #12
    //   1356: getfield b : I
    //   1359: aload #12
    //   1361: getfield c : I
    //   1364: invokevirtual u1 : (II)V
    //   1367: aload_0
    //   1368: getfield r : Landroidx/recyclerview/widget/LinearLayoutManager$c;
    //   1371: astore #12
    //   1373: aload #12
    //   1375: iload_3
    //   1376: putfield h : I
    //   1379: aload_0
    //   1380: aload_1
    //   1381: aload #12
    //   1383: aload_2
    //   1384: iconst_0
    //   1385: invokevirtual W0 : (Landroidx/recyclerview/widget/RecyclerView$r;Landroidx/recyclerview/widget/LinearLayoutManager$c;Landroidx/recyclerview/widget/RecyclerView$v;Z)I
    //   1388: pop
    //   1389: aload_0
    //   1390: getfield r : Landroidx/recyclerview/widget/LinearLayoutManager$c;
    //   1393: astore #12
    //   1395: aload #12
    //   1397: getfield b : I
    //   1400: istore #5
    //   1402: aload #12
    //   1404: getfield d : I
    //   1407: istore #7
    //   1409: aload #12
    //   1411: getfield c : I
    //   1414: istore #6
    //   1416: iload #4
    //   1418: istore_3
    //   1419: iload #6
    //   1421: ifle -> 1430
    //   1424: iload #4
    //   1426: iload #6
    //   1428: iadd
    //   1429: istore_3
    //   1430: aload_0
    //   1431: getfield B : Landroidx/recyclerview/widget/LinearLayoutManager$a;
    //   1434: astore #12
    //   1436: aload_0
    //   1437: aload #12
    //   1439: getfield b : I
    //   1442: aload #12
    //   1444: getfield c : I
    //   1447: invokevirtual t1 : (II)V
    //   1450: aload_0
    //   1451: getfield r : Landroidx/recyclerview/widget/LinearLayoutManager$c;
    //   1454: astore #12
    //   1456: aload #12
    //   1458: iload_3
    //   1459: putfield h : I
    //   1462: aload #12
    //   1464: aload #12
    //   1466: getfield d : I
    //   1469: aload #12
    //   1471: getfield e : I
    //   1474: iadd
    //   1475: putfield d : I
    //   1478: aload_0
    //   1479: aload_1
    //   1480: aload #12
    //   1482: aload_2
    //   1483: iconst_0
    //   1484: invokevirtual W0 : (Landroidx/recyclerview/widget/RecyclerView$r;Landroidx/recyclerview/widget/LinearLayoutManager$c;Landroidx/recyclerview/widget/RecyclerView$v;Z)I
    //   1487: pop
    //   1488: aload_0
    //   1489: getfield r : Landroidx/recyclerview/widget/LinearLayoutManager$c;
    //   1492: astore #12
    //   1494: aload #12
    //   1496: getfield b : I
    //   1499: istore #6
    //   1501: aload #12
    //   1503: getfield c : I
    //   1506: istore #8
    //   1508: iload #5
    //   1510: istore #4
    //   1512: iload #6
    //   1514: istore_3
    //   1515: iload #8
    //   1517: ifle -> 1778
    //   1520: aload_0
    //   1521: iload #7
    //   1523: iload #5
    //   1525: invokevirtual u1 : (II)V
    //   1528: aload_0
    //   1529: getfield r : Landroidx/recyclerview/widget/LinearLayoutManager$c;
    //   1532: astore #12
    //   1534: aload #12
    //   1536: iload #8
    //   1538: putfield h : I
    //   1541: aload_0
    //   1542: aload_1
    //   1543: aload #12
    //   1545: aload_2
    //   1546: iconst_0
    //   1547: invokevirtual W0 : (Landroidx/recyclerview/widget/RecyclerView$r;Landroidx/recyclerview/widget/LinearLayoutManager$c;Landroidx/recyclerview/widget/RecyclerView$v;Z)I
    //   1550: pop
    //   1551: aload_0
    //   1552: getfield r : Landroidx/recyclerview/widget/LinearLayoutManager$c;
    //   1555: getfield b : I
    //   1558: istore #4
    //   1560: iload #6
    //   1562: istore_3
    //   1563: goto -> 1778
    //   1566: aload_0
    //   1567: aload #12
    //   1569: getfield b : I
    //   1572: aload #12
    //   1574: getfield c : I
    //   1577: invokevirtual t1 : (II)V
    //   1580: aload_0
    //   1581: getfield r : Landroidx/recyclerview/widget/LinearLayoutManager$c;
    //   1584: astore #12
    //   1586: aload #12
    //   1588: iload #4
    //   1590: putfield h : I
    //   1593: aload_0
    //   1594: aload_1
    //   1595: aload #12
    //   1597: aload_2
    //   1598: iconst_0
    //   1599: invokevirtual W0 : (Landroidx/recyclerview/widget/RecyclerView$r;Landroidx/recyclerview/widget/LinearLayoutManager$c;Landroidx/recyclerview/widget/RecyclerView$v;Z)I
    //   1602: pop
    //   1603: aload_0
    //   1604: getfield r : Landroidx/recyclerview/widget/LinearLayoutManager$c;
    //   1607: astore #12
    //   1609: aload #12
    //   1611: getfield b : I
    //   1614: istore #5
    //   1616: aload #12
    //   1618: getfield d : I
    //   1621: istore #7
    //   1623: aload #12
    //   1625: getfield c : I
    //   1628: istore #6
    //   1630: iload_3
    //   1631: istore #4
    //   1633: iload #6
    //   1635: ifle -> 1644
    //   1638: iload_3
    //   1639: iload #6
    //   1641: iadd
    //   1642: istore #4
    //   1644: aload_0
    //   1645: getfield B : Landroidx/recyclerview/widget/LinearLayoutManager$a;
    //   1648: astore #12
    //   1650: aload_0
    //   1651: aload #12
    //   1653: getfield b : I
    //   1656: aload #12
    //   1658: getfield c : I
    //   1661: invokevirtual u1 : (II)V
    //   1664: aload_0
    //   1665: getfield r : Landroidx/recyclerview/widget/LinearLayoutManager$c;
    //   1668: astore #12
    //   1670: aload #12
    //   1672: iload #4
    //   1674: putfield h : I
    //   1677: aload #12
    //   1679: aload #12
    //   1681: getfield d : I
    //   1684: aload #12
    //   1686: getfield e : I
    //   1689: iadd
    //   1690: putfield d : I
    //   1693: aload_0
    //   1694: aload_1
    //   1695: aload #12
    //   1697: aload_2
    //   1698: iconst_0
    //   1699: invokevirtual W0 : (Landroidx/recyclerview/widget/RecyclerView$r;Landroidx/recyclerview/widget/LinearLayoutManager$c;Landroidx/recyclerview/widget/RecyclerView$v;Z)I
    //   1702: pop
    //   1703: aload_0
    //   1704: getfield r : Landroidx/recyclerview/widget/LinearLayoutManager$c;
    //   1707: astore #12
    //   1709: aload #12
    //   1711: getfield b : I
    //   1714: istore #6
    //   1716: aload #12
    //   1718: getfield c : I
    //   1721: istore #8
    //   1723: iload #6
    //   1725: istore #4
    //   1727: iload #5
    //   1729: istore_3
    //   1730: iload #8
    //   1732: ifle -> 1778
    //   1735: aload_0
    //   1736: iload #7
    //   1738: iload #5
    //   1740: invokevirtual t1 : (II)V
    //   1743: aload_0
    //   1744: getfield r : Landroidx/recyclerview/widget/LinearLayoutManager$c;
    //   1747: astore #12
    //   1749: aload #12
    //   1751: iload #8
    //   1753: putfield h : I
    //   1756: aload_0
    //   1757: aload_1
    //   1758: aload #12
    //   1760: aload_2
    //   1761: iconst_0
    //   1762: invokevirtual W0 : (Landroidx/recyclerview/widget/RecyclerView$r;Landroidx/recyclerview/widget/LinearLayoutManager$c;Landroidx/recyclerview/widget/RecyclerView$v;Z)I
    //   1765: pop
    //   1766: aload_0
    //   1767: getfield r : Landroidx/recyclerview/widget/LinearLayoutManager$c;
    //   1770: getfield b : I
    //   1773: istore_3
    //   1774: iload #6
    //   1776: istore #4
    //   1778: iload #4
    //   1780: istore #6
    //   1782: iload_3
    //   1783: istore #5
    //   1785: aload_0
    //   1786: invokevirtual x : ()I
    //   1789: ifle -> 1886
    //   1792: aload_0
    //   1793: getfield v : Z
    //   1796: aload_0
    //   1797: getfield w : Z
    //   1800: ixor
    //   1801: ifeq -> 1840
    //   1804: aload_0
    //   1805: iload_3
    //   1806: aload_1
    //   1807: aload_2
    //   1808: iconst_1
    //   1809: invokevirtual e1 : (ILandroidx/recyclerview/widget/RecyclerView$r;Landroidx/recyclerview/widget/RecyclerView$v;Z)I
    //   1812: istore #6
    //   1814: iload #4
    //   1816: iload #6
    //   1818: iadd
    //   1819: istore #5
    //   1821: iload_3
    //   1822: iload #6
    //   1824: iadd
    //   1825: istore #4
    //   1827: aload_0
    //   1828: iload #5
    //   1830: aload_1
    //   1831: aload_2
    //   1832: iconst_0
    //   1833: invokevirtual f1 : (ILandroidx/recyclerview/widget/RecyclerView$r;Landroidx/recyclerview/widget/RecyclerView$v;Z)I
    //   1836: istore_3
    //   1837: goto -> 1874
    //   1840: aload_0
    //   1841: iload #4
    //   1843: aload_1
    //   1844: aload_2
    //   1845: iconst_1
    //   1846: invokevirtual f1 : (ILandroidx/recyclerview/widget/RecyclerView$r;Landroidx/recyclerview/widget/RecyclerView$v;Z)I
    //   1849: istore #6
    //   1851: iload #4
    //   1853: iload #6
    //   1855: iadd
    //   1856: istore #5
    //   1858: iload_3
    //   1859: iload #6
    //   1861: iadd
    //   1862: istore #4
    //   1864: aload_0
    //   1865: iload #4
    //   1867: aload_1
    //   1868: aload_2
    //   1869: iconst_0
    //   1870: invokevirtual e1 : (ILandroidx/recyclerview/widget/RecyclerView$r;Landroidx/recyclerview/widget/RecyclerView$v;Z)I
    //   1873: istore_3
    //   1874: iload #5
    //   1876: iload_3
    //   1877: iadd
    //   1878: istore #6
    //   1880: iload #4
    //   1882: iload_3
    //   1883: iadd
    //   1884: istore #5
    //   1886: aload_2
    //   1887: getfield j : Z
    //   1890: ifeq -> 2204
    //   1893: aload_0
    //   1894: invokevirtual x : ()I
    //   1897: ifeq -> 2204
    //   1900: aload_2
    //   1901: getfield f : Z
    //   1904: ifne -> 2204
    //   1907: aload_0
    //   1908: invokevirtual P0 : ()Z
    //   1911: ifne -> 1917
    //   1914: goto -> 2204
    //   1917: aload_1
    //   1918: getfield d : Ljava/util/List;
    //   1921: astore #12
    //   1923: aload #12
    //   1925: invokeinterface size : ()I
    //   1930: istore #9
    //   1932: aload_0
    //   1933: aload_0
    //   1934: iconst_0
    //   1935: invokevirtual w : (I)Landroid/view/View;
    //   1938: invokevirtual L : (Landroid/view/View;)I
    //   1941: istore #10
    //   1943: iconst_0
    //   1944: istore #8
    //   1946: iload #8
    //   1948: istore_3
    //   1949: iload_3
    //   1950: istore #4
    //   1952: iload_3
    //   1953: istore #7
    //   1955: iload #8
    //   1957: istore_3
    //   1958: iload_3
    //   1959: iload #9
    //   1961: if_icmpge -> 2075
    //   1964: aload #12
    //   1966: iload_3
    //   1967: invokeinterface get : (I)Ljava/lang/Object;
    //   1972: checkcast androidx/recyclerview/widget/RecyclerView$y
    //   1975: astore #13
    //   1977: aload #13
    //   1979: invokevirtual l : ()Z
    //   1982: ifeq -> 1988
    //   1985: goto -> 2068
    //   1988: aload #13
    //   1990: invokevirtual e : ()I
    //   1993: iload #10
    //   1995: if_icmpge -> 2004
    //   1998: iconst_1
    //   1999: istore #11
    //   2001: goto -> 2007
    //   2004: iconst_0
    //   2005: istore #11
    //   2007: iload #11
    //   2009: aload_0
    //   2010: getfield v : Z
    //   2013: if_icmpeq -> 2022
    //   2016: iconst_m1
    //   2017: istore #8
    //   2019: goto -> 2025
    //   2022: iconst_1
    //   2023: istore #8
    //   2025: iload #8
    //   2027: iconst_m1
    //   2028: if_icmpne -> 2051
    //   2031: iload #7
    //   2033: aload_0
    //   2034: getfield s : Lc/t/b/c0;
    //   2037: aload #13
    //   2039: getfield a : Landroid/view/View;
    //   2042: invokevirtual c : (Landroid/view/View;)I
    //   2045: iadd
    //   2046: istore #7
    //   2048: goto -> 2068
    //   2051: iload #4
    //   2053: aload_0
    //   2054: getfield s : Lc/t/b/c0;
    //   2057: aload #13
    //   2059: getfield a : Landroid/view/View;
    //   2062: invokevirtual c : (Landroid/view/View;)I
    //   2065: iadd
    //   2066: istore #4
    //   2068: iload_3
    //   2069: iconst_1
    //   2070: iadd
    //   2071: istore_3
    //   2072: goto -> 1958
    //   2075: aload_0
    //   2076: getfield r : Landroidx/recyclerview/widget/LinearLayoutManager$c;
    //   2079: aload #12
    //   2081: putfield k : Ljava/util/List;
    //   2084: iload #7
    //   2086: ifle -> 2140
    //   2089: aload_0
    //   2090: aload_0
    //   2091: aload_0
    //   2092: invokevirtual h1 : ()Landroid/view/View;
    //   2095: invokevirtual L : (Landroid/view/View;)I
    //   2098: iload #6
    //   2100: invokevirtual u1 : (II)V
    //   2103: aload_0
    //   2104: getfield r : Landroidx/recyclerview/widget/LinearLayoutManager$c;
    //   2107: astore #12
    //   2109: aload #12
    //   2111: iload #7
    //   2113: putfield h : I
    //   2116: aload #12
    //   2118: iconst_0
    //   2119: putfield c : I
    //   2122: aload #12
    //   2124: aconst_null
    //   2125: invokevirtual a : (Landroid/view/View;)V
    //   2128: aload_0
    //   2129: aload_1
    //   2130: aload_0
    //   2131: getfield r : Landroidx/recyclerview/widget/LinearLayoutManager$c;
    //   2134: aload_2
    //   2135: iconst_0
    //   2136: invokevirtual W0 : (Landroidx/recyclerview/widget/RecyclerView$r;Landroidx/recyclerview/widget/LinearLayoutManager$c;Landroidx/recyclerview/widget/RecyclerView$v;Z)I
    //   2139: pop
    //   2140: iload #4
    //   2142: ifle -> 2196
    //   2145: aload_0
    //   2146: aload_0
    //   2147: aload_0
    //   2148: invokevirtual g1 : ()Landroid/view/View;
    //   2151: invokevirtual L : (Landroid/view/View;)I
    //   2154: iload #5
    //   2156: invokevirtual t1 : (II)V
    //   2159: aload_0
    //   2160: getfield r : Landroidx/recyclerview/widget/LinearLayoutManager$c;
    //   2163: astore #12
    //   2165: aload #12
    //   2167: iload #4
    //   2169: putfield h : I
    //   2172: aload #12
    //   2174: iconst_0
    //   2175: putfield c : I
    //   2178: aload #12
    //   2180: aconst_null
    //   2181: invokevirtual a : (Landroid/view/View;)V
    //   2184: aload_0
    //   2185: aload_1
    //   2186: aload_0
    //   2187: getfield r : Landroidx/recyclerview/widget/LinearLayoutManager$c;
    //   2190: aload_2
    //   2191: iconst_0
    //   2192: invokevirtual W0 : (Landroidx/recyclerview/widget/RecyclerView$r;Landroidx/recyclerview/widget/LinearLayoutManager$c;Landroidx/recyclerview/widget/RecyclerView$v;Z)I
    //   2195: pop
    //   2196: aload_0
    //   2197: getfield r : Landroidx/recyclerview/widget/LinearLayoutManager$c;
    //   2200: aconst_null
    //   2201: putfield k : Ljava/util/List;
    //   2204: aload_2
    //   2205: getfield f : Z
    //   2208: ifne -> 2227
    //   2211: aload_0
    //   2212: getfield s : Lc/t/b/c0;
    //   2215: astore_1
    //   2216: aload_1
    //   2217: aload_1
    //   2218: invokevirtual l : ()I
    //   2221: putfield b : I
    //   2224: goto -> 2234
    //   2227: aload_0
    //   2228: getfield B : Landroidx/recyclerview/widget/LinearLayoutManager$a;
    //   2231: invokevirtual d : ()V
    //   2234: aload_0
    //   2235: aload_0
    //   2236: getfield w : Z
    //   2239: putfield t : Z
    //   2242: return
  }
  
  public final void o1() {
    if (this.q == 1 || !i1()) {
      this.v = this.u;
      return;
    } 
    this.v = this.u ^ true;
  }
  
  public void p0(RecyclerView.v paramv) {
    this.A = null;
    this.y = -1;
    this.z = Integer.MIN_VALUE;
    this.B.d();
  }
  
  public int p1(int paramInt, RecyclerView.r paramr, RecyclerView.v paramv) {
    if (x() != 0) {
      byte b1;
      if (paramInt == 0)
        return 0; 
      V0();
      this.r.a = true;
      if (paramInt > 0) {
        b1 = 1;
      } else {
        b1 = -1;
      } 
      int i = Math.abs(paramInt);
      s1(b1, i, true, paramv);
      c c1 = this.r;
      int j = c1.g;
      j = W0(paramr, c1, paramv, false) + j;
      if (j < 0)
        return 0; 
      if (i > j)
        paramInt = b1 * j; 
      this.s.p(-paramInt);
      this.r.j = paramInt;
      return paramInt;
    } 
    return 0;
  }
  
  public void q1(int paramInt) {
    if (paramInt == 0 || paramInt == 1) {
      c(null);
      if (paramInt != this.q || this.s == null) {
        c0 c01 = c0.a(this, paramInt);
        this.s = c01;
        this.B.a = c01;
        this.q = paramInt;
        E0();
      } 
      return;
    } 
    throw new IllegalArgumentException(d.a.a.a.a.D("invalid orientation:", paramInt));
  }
  
  public void r1(boolean paramBoolean) {
    c(null);
    if (this.w == paramBoolean)
      return; 
    this.w = paramBoolean;
    E0();
  }
  
  public View s(int paramInt) {
    int i = x();
    if (i == 0)
      return null; 
    int j = paramInt - L(w(0));
    if (j >= 0 && j < i) {
      View view = w(j);
      if (L(view) == paramInt)
        return view; 
    } 
    return super.s(paramInt);
  }
  
  public final void s1(int paramInt1, int paramInt2, boolean paramBoolean, RecyclerView.v paramv) {
    this.r.l = n1();
    this.r.f = paramInt1;
    int[] arrayOfInt = this.E;
    boolean bool1 = false;
    arrayOfInt[0] = 0;
    boolean bool2 = true;
    boolean bool3 = true;
    arrayOfInt[1] = 0;
    Objects.requireNonNull(paramv);
    int i = this.r.f;
    arrayOfInt[0] = 0;
    arrayOfInt[1] = 0;
    i = Math.max(0, this.E[0]);
    int j = Math.max(0, this.E[1]);
    if (paramInt1 == 1)
      bool1 = true; 
    c c1 = this.r;
    if (bool1) {
      paramInt1 = j;
    } else {
      paramInt1 = i;
    } 
    c1.h = paramInt1;
    if (!bool1)
      i = j; 
    c1.i = i;
    if (bool1) {
      c1.h = this.s.h() + paramInt1;
      View view = g1();
      c c2 = this.r;
      paramInt1 = bool3;
      if (this.v)
        paramInt1 = -1; 
      c2.e = paramInt1;
      paramInt1 = L(view);
      c c3 = this.r;
      c2.d = paramInt1 + c3.e;
      c3.b = this.s.b(view);
      paramInt1 = this.s.b(view) - this.s.g();
    } else {
      View view = h1();
      c c2 = this.r;
      paramInt1 = c2.h;
      c2.h = this.s.k() + paramInt1;
      c2 = this.r;
      if (this.v) {
        paramInt1 = bool2;
      } else {
        paramInt1 = -1;
      } 
      c2.e = paramInt1;
      paramInt1 = L(view);
      c c3 = this.r;
      c2.d = paramInt1 + c3.e;
      c3.b = this.s.e(view);
      paramInt1 = -this.s.e(view) + this.s.k();
    } 
    c1 = this.r;
    c1.c = paramInt2;
    if (paramBoolean)
      c1.c = paramInt2 - paramInt1; 
    c1.g = paramInt1;
  }
  
  public RecyclerView.m t() {
    return new RecyclerView.m(-2, -2);
  }
  
  public void t0(Parcelable paramParcelable) {
    if (paramParcelable instanceof d) {
      this.A = (d)paramParcelable;
      E0();
    } 
  }
  
  public final void t1(int paramInt1, int paramInt2) {
    boolean bool;
    this.r.c = this.s.g() - paramInt2;
    c c1 = this.r;
    if (this.v) {
      bool = true;
    } else {
      bool = true;
    } 
    c1.e = bool;
    c1.d = paramInt1;
    c1.f = 1;
    c1.b = paramInt2;
    c1.g = Integer.MIN_VALUE;
  }
  
  public Parcelable u0() {
    d d1 = this.A;
    if (d1 != null)
      return new d(d1); 
    d1 = new d();
    if (x() > 0) {
      V0();
      int i = this.t ^ this.v;
      d1.g = i;
      if (i != 0) {
        View view1 = g1();
        d1.f = this.s.g() - this.s.b(view1);
        d1.e = L(view1);
        return d1;
      } 
      View view = h1();
      d1.e = L(view);
      d1.f = this.s.e(view) - this.s.k();
      return d1;
    } 
    d1.e = -1;
    return d1;
  }
  
  public final void u1(int paramInt1, int paramInt2) {
    this.r.c = paramInt2 - this.s.k();
    c c1 = this.r;
    c1.d = paramInt1;
    if (this.v) {
      paramInt1 = 1;
    } else {
      paramInt1 = -1;
    } 
    c1.e = paramInt1;
    c1.f = -1;
    c1.b = paramInt2;
    c1.g = Integer.MIN_VALUE;
  }
  
  public static class a {
    public c0 a;
    
    public int b;
    
    public int c;
    
    public boolean d;
    
    public boolean e;
    
    public a() {
      d();
    }
    
    public void a() {
      int i;
      if (this.d) {
        i = this.a.g();
      } else {
        i = this.a.k();
      } 
      this.c = i;
    }
    
    public void b(View param1View, int param1Int) {
      if (this.d) {
        int i = this.a.b(param1View);
        this.c = this.a.m() + i;
      } else {
        this.c = this.a.e(param1View);
      } 
      this.b = param1Int;
    }
    
    public void c(View param1View, int param1Int) {
      int i = this.a.m();
      if (i >= 0) {
        b(param1View, param1Int);
        return;
      } 
      this.b = param1Int;
      if (this.d) {
        param1Int = this.a.g() - i - this.a.b(param1View);
        this.c = this.a.g() - param1Int;
        if (param1Int > 0) {
          i = this.a.c(param1View);
          int j = this.c;
          int k = this.a.k();
          i = j - i - Math.min(this.a.e(param1View) - k, 0) + k;
          if (i < 0) {
            j = this.c;
            this.c = Math.min(param1Int, -i) + j;
            return;
          } 
        } 
      } else {
        int j = this.a.e(param1View);
        param1Int = j - this.a.k();
        this.c = j;
        if (param1Int > 0) {
          int k = this.a.c(param1View);
          int m = this.a.g();
          int n = this.a.b(param1View);
          i = this.a.g() - Math.min(0, m - i - n) - k + j;
          if (i < 0)
            this.c -= Math.min(param1Int, -i); 
        } 
      } 
    }
    
    public void d() {
      this.b = -1;
      this.c = Integer.MIN_VALUE;
      this.d = false;
      this.e = false;
    }
    
    public String toString() {
      StringBuilder stringBuilder = d.a.a.a.a.p("AnchorInfo{mPosition=");
      stringBuilder.append(this.b);
      stringBuilder.append(", mCoordinate=");
      stringBuilder.append(this.c);
      stringBuilder.append(", mLayoutFromEnd=");
      stringBuilder.append(this.d);
      stringBuilder.append(", mValid=");
      stringBuilder.append(this.e);
      stringBuilder.append('}');
      return stringBuilder.toString();
    }
  }
  
  public static class b {
    public int a;
    
    public boolean b;
    
    public boolean c;
    
    public boolean d;
  }
  
  public static class c {
    public boolean a = true;
    
    public int b;
    
    public int c;
    
    public int d;
    
    public int e;
    
    public int f;
    
    public int g;
    
    public int h = 0;
    
    public int i = 0;
    
    public int j;
    
    public List<RecyclerView.y> k = null;
    
    public boolean l;
    
    public void a(View param1View) {
      View view2;
      int k = this.k.size();
      View view1 = null;
      int j = Integer.MAX_VALUE;
      int i = 0;
      while (true) {
        view2 = view1;
        if (i < k) {
          View view = ((RecyclerView.y)this.k.get(i)).a;
          RecyclerView.m m1 = (RecyclerView.m)view.getLayoutParams();
          view2 = view1;
          int m = j;
          if (view != param1View)
            if (m1.c()) {
              view2 = view1;
              m = j;
            } else {
              int n = (m1.a() - this.d) * this.e;
              if (n < 0) {
                view2 = view1;
                m = j;
              } else {
                view2 = view1;
                m = j;
                if (n < j) {
                  view1 = view;
                  if (n == 0) {
                    view2 = view1;
                    break;
                  } 
                  m = n;
                  view2 = view1;
                } 
              } 
            }  
          i++;
          view1 = view2;
          j = m;
          continue;
        } 
        break;
      } 
      if (view2 == null) {
        this.d = -1;
        return;
      } 
      this.d = ((RecyclerView.m)view2.getLayoutParams()).a();
    }
    
    public boolean b(RecyclerView.v param1v) {
      int i = this.d;
      return (i >= 0 && i < param1v.b());
    }
    
    public View c(RecyclerView.r param1r) {
      List<RecyclerView.y> list = this.k;
      int i = 0;
      if (list != null) {
        int j = list.size();
        while (i < j) {
          view = ((RecyclerView.y)this.k.get(i)).a;
          RecyclerView.m m = (RecyclerView.m)view.getLayoutParams();
          if (!m.c() && this.d == m.a()) {
            a(view);
            return view;
          } 
          i++;
        } 
        return null;
      } 
      View view = (view.j(this.d, false, Long.MAX_VALUE)).a;
      this.d += this.e;
      return view;
    }
  }
  
  public static class d implements Parcelable {
    public static final Parcelable.Creator<d> CREATOR = (Parcelable.Creator<d>)new x();
    
    public int e;
    
    public int f;
    
    public boolean g;
    
    public d() {}
    
    public d(Parcel param1Parcel) {
      this.e = param1Parcel.readInt();
      this.f = param1Parcel.readInt();
      int i = param1Parcel.readInt();
      boolean bool = true;
      if (i != 1)
        bool = false; 
      this.g = bool;
    }
    
    public d(d param1d) {
      this.e = param1d.e;
      this.f = param1d.f;
      this.g = param1d.g;
    }
    
    public boolean a() {
      return (this.e >= 0);
    }
    
    public int describeContents() {
      return 0;
    }
    
    public void writeToParcel(Parcel param1Parcel, int param1Int) {
      throw new RuntimeException("d2j fail translate: java.lang.RuntimeException: can not merge I and Z\r\n\tat com.googlecode.dex2jar.ir.TypeClass.merge(TypeClass.java:100)\r\n\tat com.googlecode.dex2jar.ir.ts.TypeTransformer$TypeRef.updateTypeClass(TypeTransformer.java:174)\r\n\tat com.googlecode.dex2jar.ir.ts.TypeTransformer$TypeAnalyze.provideAs(TypeTransformer.java:780)\r\n\tat com.googlecode.dex2jar.ir.ts.TypeTransformer$TypeAnalyze.e1expr(TypeTransformer.java:496)\r\n\tat com.googlecode.dex2jar.ir.ts.TypeTransformer$TypeAnalyze.exExpr(TypeTransformer.java:713)\r\n\tat com.googlecode.dex2jar.ir.ts.TypeTransformer$TypeAnalyze.exExpr(TypeTransformer.java:703)\r\n\tat com.googlecode.dex2jar.ir.ts.TypeTransformer$TypeAnalyze.enexpr(TypeTransformer.java:698)\r\n\tat com.googlecode.dex2jar.ir.ts.TypeTransformer$TypeAnalyze.exExpr(TypeTransformer.java:719)\r\n\tat com.googlecode.dex2jar.ir.ts.TypeTransformer$TypeAnalyze.exExpr(TypeTransformer.java:703)\r\n\tat com.googlecode.dex2jar.ir.ts.TypeTransformer$TypeAnalyze.s1stmt(TypeTransformer.java:810)\r\n\tat com.googlecode.dex2jar.ir.ts.TypeTransformer$TypeAnalyze.sxStmt(TypeTransformer.java:840)\r\n\tat com.googlecode.dex2jar.ir.ts.TypeTransformer$TypeAnalyze.analyze(TypeTransformer.java:206)\r\n\tat com.googlecode.dex2jar.ir.ts.TypeTransformer.transform(TypeTransformer.java:44)\r\n\tat com.googlecode.d2j.dex.Dex2jar$2.optimize(Dex2jar.java:162)\r\n\tat com.googlecode.d2j.dex.Dex2Asm.convertCode(Dex2Asm.java:414)\r\n\tat com.googlecode.d2j.dex.ExDex2Asm.convertCode(ExDex2Asm.java:42)\r\n\tat com.googlecode.d2j.dex.Dex2jar$2.convertCode(Dex2jar.java:128)\r\n\tat com.googlecode.d2j.dex.Dex2Asm.convertMethod(Dex2Asm.java:509)\r\n\tat com.googlecode.d2j.dex.Dex2Asm.convertClass(Dex2Asm.java:406)\r\n\tat com.googlecode.d2j.dex.Dex2Asm.convertDex(Dex2Asm.java:422)\r\n\tat com.googlecode.d2j.dex.Dex2jar.doTranslate(Dex2jar.java:172)\r\n\tat com.googlecode.d2j.dex.Dex2jar.to(Dex2jar.java:272)\r\n\tat com.googlecode.dex2jar.tools.Dex2jarCmd.doCommandLine(Dex2jarCmd.java:108)\r\n\tat com.googlecode.dex2jar.tools.BaseCmd.doMain(BaseCmd.java:288)\r\n\tat com.googlecode.dex2jar.tools.Dex2jarCmd.main(Dex2jarCmd.java:32)\r\n");
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Https Traffic-dex2jar.jar!\androidx\recyclerview\widget\LinearLayoutManager.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */