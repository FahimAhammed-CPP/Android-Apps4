package androidx.media;

import c.a0.a;
import java.util.Objects;

public final class AudioAttributesImplBaseParcelizer {
  public static AudioAttributesImplBase read(a parama) {
    AudioAttributesImplBase audioAttributesImplBase = new AudioAttributesImplBase();
    audioAttributesImplBase.a = parama.i(audioAttributesImplBase.a, 1);
    audioAttributesImplBase.b = parama.i(audioAttributesImplBase.b, 2);
    audioAttributesImplBase.c = parama.i(audioAttributesImplBase.c, 3);
    audioAttributesImplBase.d = parama.i(audioAttributesImplBase.d, 4);
    return audioAttributesImplBase;
  }
  
  public static void write(AudioAttributesImplBase paramAudioAttributesImplBase, a parama) {
    Objects.requireNonNull(parama);
    parama.m(paramAudioAttributesImplBase.a, 1);
    parama.m(paramAudioAttributesImplBase.b, 2);
    parama.m(paramAudioAttributesImplBase.c, 3);
    parama.m(paramAudioAttributesImplBase.d, 4);
  }
}


/* Location:              C:\soft\dex2jar-2.0\Https Traffic-dex2jar.jar!\androidx\media\AudioAttributesImplBaseParcelizer.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */