package androidx.savedstate;

import c.p.e;
import c.p.f;
import c.p.h;
import c.v.a;
import java.util.Objects;

public class SavedStateRegistry$1 implements f {
  public SavedStateRegistry$1(a parama) {}
  
  public void d(h paramh, e.a parama) {
    if (parama == e.a.ON_START) {
      Objects.requireNonNull(this.e);
      return;
    } 
    if (parama == e.a.ON_STOP)
      Objects.requireNonNull(this.e); 
  }
}


/* Location:              C:\soft\dex2jar-2.0\Https Traffic-dex2jar.jar!\androidx\savedstate\SavedStateRegistry$1.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */