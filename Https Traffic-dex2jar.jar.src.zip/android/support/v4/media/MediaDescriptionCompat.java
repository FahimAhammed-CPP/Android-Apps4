package android.support.v4.media;

import android.graphics.Bitmap;
import android.media.MediaDescription;
import android.net.Uri;
import android.os.Bundle;
import android.os.Parcel;
import android.os.Parcelable;
import android.support.v4.media.session.MediaSessionCompat;

public final class MediaDescriptionCompat implements Parcelable {
  public static final Parcelable.Creator<MediaDescriptionCompat> CREATOR = new a();
  
  public final String e;
  
  public final CharSequence f;
  
  public final CharSequence g;
  
  public final CharSequence h;
  
  public final Bitmap i;
  
  public final Uri j;
  
  public final Bundle k;
  
  public final Uri l;
  
  public Object m;
  
  public MediaDescriptionCompat(String paramString, CharSequence paramCharSequence1, CharSequence paramCharSequence2, CharSequence paramCharSequence3, Bitmap paramBitmap, Uri paramUri1, Bundle paramBundle, Uri paramUri2) {
    this.e = paramString;
    this.f = paramCharSequence1;
    this.g = paramCharSequence2;
    this.h = paramCharSequence3;
    this.i = paramBitmap;
    this.j = paramUri1;
    this.k = paramBundle;
    this.l = paramUri2;
  }
  
  public int describeContents() {
    return 0;
  }
  
  public String toString() {
    StringBuilder stringBuilder = new StringBuilder();
    stringBuilder.append(this.f);
    stringBuilder.append(", ");
    stringBuilder.append(this.g);
    stringBuilder.append(", ");
    stringBuilder.append(this.h);
    return stringBuilder.toString();
  }
  
  public void writeToParcel(Parcel paramParcel, int paramInt) {
    Object object2 = this.m;
    Object object1 = object2;
    if (object2 == null) {
      object1 = new MediaDescription.Builder();
      object1.setMediaId(this.e);
      object1.setTitle(this.f);
      object1.setSubtitle(this.g);
      object1.setDescription(this.h);
      object1.setIconBitmap(this.i);
      object1.setIconUri(this.j);
      object1.setExtras(this.k);
      object1.setMediaUri(this.l);
      object1 = object1.build();
      this.m = object1;
    } 
    ((MediaDescription)object1).writeToParcel(paramParcel, paramInt);
  }
  
  public static final class a implements Parcelable.Creator<MediaDescriptionCompat> {
    public Object createFromParcel(Parcel param1Parcel) {
      MediaDescriptionCompat mediaDescriptionCompat;
      Object object = MediaDescription.CREATOR.createFromParcel(param1Parcel);
      param1Parcel = null;
      if (object != null) {
        Uri uri1;
        MediaDescription mediaDescription = (MediaDescription)object;
        String str = mediaDescription.getMediaId();
        CharSequence charSequence1 = mediaDescription.getTitle();
        CharSequence charSequence2 = mediaDescription.getSubtitle();
        CharSequence charSequence3 = mediaDescription.getDescription();
        Bitmap bitmap = mediaDescription.getIconBitmap();
        Uri uri2 = mediaDescription.getIconUri();
        Bundle bundle = mediaDescription.getExtras();
        if (bundle != null) {
          MediaSessionCompat.a(bundle);
          uri1 = (Uri)bundle.getParcelable("android.support.v4.media.description.MEDIA_URI");
        } else {
          param1Parcel = null;
        } 
        if (param1Parcel != null)
          if (bundle.containsKey("android.support.v4.media.description.NULL_BUNDLE_FLAG") && bundle.size() == 2) {
            bundle = null;
          } else {
            bundle.remove("android.support.v4.media.description.MEDIA_URI");
            bundle.remove("android.support.v4.media.description.NULL_BUNDLE_FLAG");
          }  
        if (param1Parcel == null)
          uri1 = mediaDescription.getMediaUri(); 
        mediaDescriptionCompat = new MediaDescriptionCompat(str, charSequence1, charSequence2, charSequence3, bitmap, uri2, bundle, uri1);
        mediaDescriptionCompat.m = object;
      } 
      return mediaDescriptionCompat;
    }
    
    public Object[] newArray(int param1Int) {
      return (Object[])new MediaDescriptionCompat[param1Int];
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Https Traffic-dex2jar.jar!\android\support\v4\media\MediaDescriptionCompat.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */