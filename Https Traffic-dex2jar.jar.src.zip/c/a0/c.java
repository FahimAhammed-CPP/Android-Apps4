package c.a0;

public interface c {}


/* Location:              C:\soft\dex2jar-2.0\Https Traffic-dex2jar.jar!\c\a0\c.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */