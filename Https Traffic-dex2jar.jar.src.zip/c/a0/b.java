package c.a0;

import android.os.Parcel;
import android.util.SparseIntArray;
import d.a.a.a.a;
import java.lang.reflect.Method;

public class b extends a {
  public final SparseIntArray d = new SparseIntArray();
  
  public final Parcel e;
  
  public final int f;
  
  public final int g;
  
  public final String h;
  
  public int i = -1;
  
  public int j = 0;
  
  public int k = -1;
  
  public b(Parcel paramParcel) {
    this(paramParcel, paramParcel.dataPosition(), paramParcel.dataSize(), "", new c.e.b(), new c.e.b(), new c.e.b());
  }
  
  public b(Parcel paramParcel, int paramInt1, int paramInt2, String paramString, c.e.b<String, Method> paramb1, c.e.b<String, Method> paramb2, c.e.b<String, Class> paramb) {
    super(paramb1, paramb2, paramb);
    this.e = paramParcel;
    this.f = paramInt1;
    this.g = paramInt2;
    this.j = paramInt1;
    this.h = paramString;
  }
  
  public void a() {
    int i = this.i;
    if (i >= 0) {
      i = this.d.get(i);
      int j = this.e.dataPosition();
      this.e.setDataPosition(i);
      this.e.writeInt(j - i);
      this.e.setDataPosition(j);
    } 
  }
  
  public a b() {
    Parcel parcel = this.e;
    int k = parcel.dataPosition();
    int j = this.j;
    int i = j;
    if (j == this.f)
      i = this.g; 
    return new b(parcel, k, i, a.h(new StringBuilder(), this.h, "  "), this.a, this.b, this.c);
  }
  
  public boolean h(int paramInt) {
    while (this.j < this.g) {
      int i = this.k;
      if (i == paramInt)
        return true; 
      if (String.valueOf(i).compareTo(String.valueOf(paramInt)) > 0)
        return false; 
      this.e.setDataPosition(this.j);
      i = this.e.readInt();
      this.k = this.e.readInt();
      this.j += i;
    } 
    return (this.k == paramInt);
  }
  
  public void l(int paramInt) {
    a();
    this.i = paramInt;
    this.d.put(paramInt, this.e.dataPosition());
    this.e.writeInt(0);
    this.e.writeInt(paramInt);
  }
}


/* Location:              C:\soft\dex2jar-2.0\Https Traffic-dex2jar.jar!\c\a0\b.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */