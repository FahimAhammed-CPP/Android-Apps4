package c.a;

import androidx.activity.OnBackPressedDispatcher;

public class e implements a {
  public final d e;
  
  public e(OnBackPressedDispatcher paramOnBackPressedDispatcher, d paramd) {
    this.e = paramd;
  }
  
  public void cancel() {
    this.f.b.remove(this.e);
    this.e.b.remove(this);
  }
}


/* Location:              C:\soft\dex2jar-2.0\Https Traffic-dex2jar.jar!\c\a\e.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */