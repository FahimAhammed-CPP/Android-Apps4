package c.a;

import androidx.activity.OnBackPressedDispatcher;
import c.p.h;

public interface f extends h {
  OnBackPressedDispatcher a();
}


/* Location:              C:\soft\dex2jar-2.0\Https Traffic-dex2jar.jar!\c\a\f.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */