package c.b0;

import android.os.Build;

public final class d {
  public static final d i = (new a()).a();
  
  public p a = p.e;
  
  public boolean b;
  
  public boolean c;
  
  public boolean d;
  
  public boolean e;
  
  public long f = -1L;
  
  public long g = -1L;
  
  public f h = new f();
  
  public d() {}
  
  public d(a parama) {
    this.b = false;
    int i = Build.VERSION.SDK_INT;
    this.c = false;
    this.a = parama.a;
    this.d = false;
    this.e = false;
    if (i >= 24) {
      this.h = parama.b;
      this.f = -1L;
      this.g = -1L;
    } 
  }
  
  public d(d paramd) {
    this.b = paramd.b;
    this.c = paramd.c;
    this.a = paramd.a;
    this.d = paramd.d;
    this.e = paramd.e;
    this.h = paramd.h;
  }
  
  public boolean a() {
    return (this.h.a() > 0);
  }
  
  public boolean equals(Object paramObject) {
    if (this == paramObject)
      return true; 
    if (paramObject != null) {
      if (d.class != paramObject.getClass())
        return false; 
      paramObject = paramObject;
      return (this.b != ((d)paramObject).b) ? false : ((this.c != ((d)paramObject).c) ? false : ((this.d != ((d)paramObject).d) ? false : ((this.e != ((d)paramObject).e) ? false : ((this.f != ((d)paramObject).f) ? false : ((this.g != ((d)paramObject).g) ? false : ((this.a != ((d)paramObject).a) ? false : this.h.equals(((d)paramObject).h)))))));
    } 
    return false;
  }
  
  public int hashCode() {
    throw new RuntimeException("d2j fail translate: java.lang.RuntimeException: can not merge I and Z\r\n\tat com.googlecode.dex2jar.ir.TypeClass.merge(TypeClass.java:100)\r\n\tat com.googlecode.dex2jar.ir.ts.TypeTransformer$TypeRef.updateTypeClass(TypeTransformer.java:174)\r\n\tat com.googlecode.dex2jar.ir.ts.TypeTransformer$TypeAnalyze.copyTypes(TypeTransformer.java:311)\r\n\tat com.googlecode.dex2jar.ir.ts.TypeTransformer$TypeAnalyze.fixTypes(TypeTransformer.java:226)\r\n\tat com.googlecode.dex2jar.ir.ts.TypeTransformer$TypeAnalyze.analyze(TypeTransformer.java:207)\r\n\tat com.googlecode.dex2jar.ir.ts.TypeTransformer.transform(TypeTransformer.java:44)\r\n\tat com.googlecode.d2j.dex.Dex2jar$2.optimize(Dex2jar.java:162)\r\n\tat com.googlecode.d2j.dex.Dex2Asm.convertCode(Dex2Asm.java:414)\r\n\tat com.googlecode.d2j.dex.ExDex2Asm.convertCode(ExDex2Asm.java:42)\r\n\tat com.googlecode.d2j.dex.Dex2jar$2.convertCode(Dex2jar.java:128)\r\n\tat com.googlecode.d2j.dex.Dex2Asm.convertMethod(Dex2Asm.java:509)\r\n\tat com.googlecode.d2j.dex.Dex2Asm.convertClass(Dex2Asm.java:406)\r\n\tat com.googlecode.d2j.dex.Dex2Asm.convertDex(Dex2Asm.java:422)\r\n\tat com.googlecode.d2j.dex.Dex2jar.doTranslate(Dex2jar.java:172)\r\n\tat com.googlecode.d2j.dex.Dex2jar.to(Dex2jar.java:272)\r\n\tat com.googlecode.dex2jar.tools.Dex2jarCmd.doCommandLine(Dex2jarCmd.java:108)\r\n\tat com.googlecode.dex2jar.tools.BaseCmd.doMain(BaseCmd.java:288)\r\n\tat com.googlecode.dex2jar.tools.Dex2jarCmd.main(Dex2jarCmd.java:32)\r\n");
  }
  
  public static final class a {
    public p a = p.e;
    
    public f b = new f();
    
    public d a() {
      return new d(this);
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Https Traffic-dex2jar.jar!\c\b0\d.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */