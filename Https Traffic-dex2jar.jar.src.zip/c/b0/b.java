package c.b0;

import d.a.a.a.a;
import java.util.concurrent.ThreadFactory;
import java.util.concurrent.atomic.AtomicInteger;

public class b implements ThreadFactory {
  public final AtomicInteger a = new AtomicInteger(0);
  
  public b(c paramc, boolean paramBoolean) {}
  
  public Thread newThread(Runnable paramRunnable) {
    String str;
    if (this.b) {
      str = "WM.task-";
    } else {
      str = "androidx.work-";
    } 
    StringBuilder stringBuilder = a.p(str);
    stringBuilder.append(this.a.incrementAndGet());
    return new Thread(paramRunnable, stringBuilder.toString());
  }
}


/* Location:              C:\soft\dex2jar-2.0\Https Traffic-dex2jar.jar!\c\b0\b.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */