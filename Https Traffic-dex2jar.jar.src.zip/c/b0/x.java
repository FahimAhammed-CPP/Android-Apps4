package c.b0;

public enum x {
  e, f;
  
  static {
    x x1 = new x("RUN_AS_NON_EXPEDITED_WORK_REQUEST", 0);
    e = x1;
    x x2 = new x("DROP_WORK_REQUEST", 1);
    f = x2;
    g = new x[] { x1, x2 };
  }
}


/* Location:              C:\soft\dex2jar-2.0\Https Traffic-dex2jar.jar!\c\b0\x.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */