package c.b0;

import android.app.Notification;

public final class h {
  public final int a;
  
  public final int b;
  
  public final Notification c;
  
  public h(int paramInt1, Notification paramNotification, int paramInt2) {
    this.a = paramInt1;
    this.c = paramNotification;
    this.b = paramInt2;
  }
  
  public boolean equals(Object paramObject) {
    if (this == paramObject)
      return true; 
    if (paramObject != null) {
      if (h.class != paramObject.getClass())
        return false; 
      paramObject = paramObject;
      return (this.a != ((h)paramObject).a) ? false : ((this.b != ((h)paramObject).b) ? false : this.c.equals(((h)paramObject).c));
    } 
    return false;
  }
  
  public int hashCode() {
    int i = this.a;
    int j = this.b;
    return this.c.hashCode() + (i * 31 + j) * 31;
  }
  
  public String toString() {
    StringBuilder stringBuilder = new StringBuilder("ForegroundInfo{");
    stringBuilder.append("mNotificationId=");
    stringBuilder.append(this.a);
    stringBuilder.append(", mForegroundServiceType=");
    stringBuilder.append(this.b);
    stringBuilder.append(", mNotification=");
    stringBuilder.append(this.c);
    stringBuilder.append('}');
    return stringBuilder.toString();
  }
}


/* Location:              C:\soft\dex2jar-2.0\Https Traffic-dex2jar.jar!\c\b0\h.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */