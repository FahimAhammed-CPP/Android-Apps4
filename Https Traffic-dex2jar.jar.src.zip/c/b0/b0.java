package c.b0;

import android.text.TextUtils;
import c.b0.f0.c0.a0.c;
import c.b0.f0.c0.e;
import c.b0.f0.h;
import c.b0.f0.t;
import java.util.Collections;
import java.util.List;

public abstract class b0 {
  public final w a(c0 paramc0) {
    List<c0> list = Collections.singletonList(paramc0);
    t t = (t)this;
    if (!list.isEmpty()) {
      h h = new h(t, list);
      if (!h.e) {
        e e = new e(h);
        ((c)h.a.d).a.execute((Runnable)e);
        h.f = (w)e.f;
      } else {
        o.c().f(h.g, String.format("Already enqueued work ids (%s)", new Object[] { TextUtils.join(", ", h.c) }), new Throwable[0]);
      } 
      return h.f;
    } 
    throw new IllegalArgumentException("enqueue needs at least one WorkRequest.");
  }
}


/* Location:              C:\soft\dex2jar-2.0\Https Traffic-dex2jar.jar!\c\b0\b0.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */