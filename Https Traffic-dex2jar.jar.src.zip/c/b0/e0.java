package c.b0;

import android.content.Context;
import androidx.work.ListenableWorker;
import androidx.work.WorkerParameters;
import d.a.a.a.a;

public abstract class e0 {
  public static final String a = o.e("WorkerFactory");
  
  public final ListenableWorker a(Context paramContext, String paramString, WorkerParameters paramWorkerParameters) {
    Exception exception;
    ListenableWorker listenableWorker1;
    ListenableWorker listenableWorker2 = null;
    try {
      Class<? extends ListenableWorker> clazz = Class.forName(paramString).asSubclass(ListenableWorker.class);
    } finally {
      exception = null;
      o.c().b(a, a.f("Invalid class: ", paramString), new Throwable[] { exception });
    } 
    if (listenableWorker1 != null) {
      if (!listenableWorker1.isUsed())
        return listenableWorker1; 
      throw new IllegalStateException(String.format("WorkerFactory (%s) returned an instance of a ListenableWorker (%s) which has already been invoked. createWorker() must always return a new instance of a ListenableWorker.", new Object[] { getClass().getName(), paramString }));
    } 
    return listenableWorker1;
  }
}


/* Location:              C:\soft\dex2jar-2.0\Https Traffic-dex2jar.jar!\c\b0\e0.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */