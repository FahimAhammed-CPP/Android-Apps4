package c.b0;

public enum a {
  e, f;
  
  static {
    a a1 = new a("EXPONENTIAL", 0);
    e = a1;
    a a2 = new a("LINEAR", 1);
    f = a2;
    g = new a[] { a1, a2 };
  }
}


/* Location:              C:\soft\dex2jar-2.0\Https Traffic-dex2jar.jar!\c\b0\a.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */