package c.b0.f0;

import android.app.job.JobInfo;
import android.app.job.JobScheduler;
import android.content.BroadcastReceiver;
import android.content.Context;
import androidx.work.impl.WorkDatabase;
import c.b0.b0;
import c.b0.c;
import c.b0.f0.b0.c0;
import c.b0.f0.c0.a0.a;
import c.b0.f0.c0.a0.c;
import c.b0.f0.c0.h;
import c.b0.f0.c0.m;
import c.b0.f0.y.c.b;
import c.b0.o;
import c.u.s;
import c.w.a.f.i;
import java.util.Iterator;
import java.util.List;

public class t extends b0 {
  public static t j = null;
  
  public static t k = null;
  
  public static final Object l = new Object();
  
  public Context a;
  
  public c b;
  
  public WorkDatabase c;
  
  public a d;
  
  public List<f> e;
  
  public e f;
  
  public h g;
  
  public boolean h;
  
  public BroadcastReceiver.PendingResult i;
  
  public t(Context paramContext, c paramc, a parama) {
    // Byte code:
    //   0: aload_1
    //   1: invokevirtual getResources : ()Landroid/content/res/Resources;
    //   4: ldc 2130968583
    //   6: invokevirtual getBoolean : (I)Z
    //   9: istore #5
    //   11: aload_1
    //   12: invokevirtual getApplicationContext : ()Landroid/content/Context;
    //   15: astore #7
    //   17: aload_3
    //   18: checkcast c/b0/f0/c0/a0/c
    //   21: getfield a : Lc/b0/f0/c0/k;
    //   24: astore #8
    //   26: getstatic androidx/work/impl/WorkDatabase.k : I
    //   29: istore #4
    //   31: iload #5
    //   33: ifeq -> 59
    //   36: new c/u/l$a
    //   39: dup
    //   40: aload #7
    //   42: ldc androidx/work/impl/WorkDatabase
    //   44: aconst_null
    //   45: invokespecial <init> : (Landroid/content/Context;Ljava/lang/Class;Ljava/lang/String;)V
    //   48: astore #6
    //   50: aload #6
    //   52: iconst_1
    //   53: putfield h : Z
    //   56: goto -> 93
    //   59: getstatic c/b0/f0/s.a : Ljava/lang/String;
    //   62: astore #6
    //   64: new c/u/l$a
    //   67: dup
    //   68: aload #7
    //   70: ldc androidx/work/impl/WorkDatabase
    //   72: ldc 'androidx.work.workdb'
    //   74: invokespecial <init> : (Landroid/content/Context;Ljava/lang/Class;Ljava/lang/String;)V
    //   77: astore #6
    //   79: aload #6
    //   81: new c/b0/f0/i
    //   84: dup
    //   85: aload #7
    //   87: invokespecial <init> : (Landroid/content/Context;)V
    //   90: putfield g : Lc/w/a/c$c;
    //   93: aload #6
    //   95: aload #8
    //   97: putfield e : Ljava/util/concurrent/Executor;
    //   100: new c/b0/f0/j
    //   103: dup
    //   104: invokespecial <init> : ()V
    //   107: astore #8
    //   109: aload #6
    //   111: getfield d : Ljava/util/ArrayList;
    //   114: ifnonnull -> 129
    //   117: aload #6
    //   119: new java/util/ArrayList
    //   122: dup
    //   123: invokespecial <init> : ()V
    //   126: putfield d : Ljava/util/ArrayList;
    //   129: aload #6
    //   131: getfield d : Ljava/util/ArrayList;
    //   134: aload #8
    //   136: invokevirtual add : (Ljava/lang/Object;)Z
    //   139: pop
    //   140: aload #6
    //   142: iconst_1
    //   143: anewarray c/u/t/a
    //   146: dup
    //   147: iconst_0
    //   148: getstatic c/b0/f0/r.a : Lc/u/t/a;
    //   151: aastore
    //   152: invokevirtual a : ([Lc/u/t/a;)Lc/u/l$a;
    //   155: pop
    //   156: aload #6
    //   158: iconst_1
    //   159: anewarray c/u/t/a
    //   162: dup
    //   163: iconst_0
    //   164: new c/b0/f0/r$a
    //   167: dup
    //   168: aload #7
    //   170: iconst_2
    //   171: iconst_3
    //   172: invokespecial <init> : (Landroid/content/Context;II)V
    //   175: aastore
    //   176: invokevirtual a : ([Lc/u/t/a;)Lc/u/l$a;
    //   179: pop
    //   180: aload #6
    //   182: iconst_1
    //   183: anewarray c/u/t/a
    //   186: dup
    //   187: iconst_0
    //   188: getstatic c/b0/f0/r.b : Lc/u/t/a;
    //   191: aastore
    //   192: invokevirtual a : ([Lc/u/t/a;)Lc/u/l$a;
    //   195: pop
    //   196: aload #6
    //   198: iconst_1
    //   199: anewarray c/u/t/a
    //   202: dup
    //   203: iconst_0
    //   204: getstatic c/b0/f0/r.c : Lc/u/t/a;
    //   207: aastore
    //   208: invokevirtual a : ([Lc/u/t/a;)Lc/u/l$a;
    //   211: pop
    //   212: aload #6
    //   214: iconst_1
    //   215: anewarray c/u/t/a
    //   218: dup
    //   219: iconst_0
    //   220: new c/b0/f0/r$a
    //   223: dup
    //   224: aload #7
    //   226: iconst_5
    //   227: bipush #6
    //   229: invokespecial <init> : (Landroid/content/Context;II)V
    //   232: aastore
    //   233: invokevirtual a : ([Lc/u/t/a;)Lc/u/l$a;
    //   236: pop
    //   237: aload #6
    //   239: iconst_1
    //   240: anewarray c/u/t/a
    //   243: dup
    //   244: iconst_0
    //   245: getstatic c/b0/f0/r.d : Lc/u/t/a;
    //   248: aastore
    //   249: invokevirtual a : ([Lc/u/t/a;)Lc/u/l$a;
    //   252: pop
    //   253: aload #6
    //   255: iconst_1
    //   256: anewarray c/u/t/a
    //   259: dup
    //   260: iconst_0
    //   261: getstatic c/b0/f0/r.e : Lc/u/t/a;
    //   264: aastore
    //   265: invokevirtual a : ([Lc/u/t/a;)Lc/u/l$a;
    //   268: pop
    //   269: aload #6
    //   271: iconst_1
    //   272: anewarray c/u/t/a
    //   275: dup
    //   276: iconst_0
    //   277: getstatic c/b0/f0/r.f : Lc/u/t/a;
    //   280: aastore
    //   281: invokevirtual a : ([Lc/u/t/a;)Lc/u/l$a;
    //   284: pop
    //   285: aload #6
    //   287: iconst_1
    //   288: anewarray c/u/t/a
    //   291: dup
    //   292: iconst_0
    //   293: new c/b0/f0/r$b
    //   296: dup
    //   297: aload #7
    //   299: invokespecial <init> : (Landroid/content/Context;)V
    //   302: aastore
    //   303: invokevirtual a : ([Lc/u/t/a;)Lc/u/l$a;
    //   306: pop
    //   307: aload #6
    //   309: iconst_1
    //   310: anewarray c/u/t/a
    //   313: dup
    //   314: iconst_0
    //   315: new c/b0/f0/r$a
    //   318: dup
    //   319: aload #7
    //   321: bipush #10
    //   323: bipush #11
    //   325: invokespecial <init> : (Landroid/content/Context;II)V
    //   328: aastore
    //   329: invokevirtual a : ([Lc/u/t/a;)Lc/u/l$a;
    //   332: pop
    //   333: aload #6
    //   335: iconst_1
    //   336: anewarray c/u/t/a
    //   339: dup
    //   340: iconst_0
    //   341: getstatic c/b0/f0/r.g : Lc/u/t/a;
    //   344: aastore
    //   345: invokevirtual a : ([Lc/u/t/a;)Lc/u/l$a;
    //   348: pop
    //   349: aload #6
    //   351: iconst_0
    //   352: putfield i : Z
    //   355: aload #6
    //   357: iconst_1
    //   358: putfield j : Z
    //   361: getstatic c/u/m.g : Lc/u/m;
    //   364: astore #8
    //   366: aload #6
    //   368: getfield c : Landroid/content/Context;
    //   371: astore #9
    //   373: aload #9
    //   375: ifnull -> 1248
    //   378: aload #6
    //   380: getfield a : Ljava/lang/Class;
    //   383: ifnull -> 1237
    //   386: aload #6
    //   388: getfield e : Ljava/util/concurrent/Executor;
    //   391: astore #7
    //   393: aload #7
    //   395: ifnonnull -> 428
    //   398: aload #6
    //   400: getfield f : Ljava/util/concurrent/Executor;
    //   403: ifnonnull -> 428
    //   406: getstatic c/c/a/a/b.d : Ljava/util/concurrent/Executor;
    //   409: astore #7
    //   411: aload #6
    //   413: aload #7
    //   415: putfield f : Ljava/util/concurrent/Executor;
    //   418: aload #6
    //   420: aload #7
    //   422: putfield e : Ljava/util/concurrent/Executor;
    //   425: goto -> 475
    //   428: aload #7
    //   430: ifnull -> 451
    //   433: aload #6
    //   435: getfield f : Ljava/util/concurrent/Executor;
    //   438: ifnonnull -> 451
    //   441: aload #6
    //   443: aload #7
    //   445: putfield f : Ljava/util/concurrent/Executor;
    //   448: goto -> 475
    //   451: aload #7
    //   453: ifnonnull -> 475
    //   456: aload #6
    //   458: getfield f : Ljava/util/concurrent/Executor;
    //   461: astore #7
    //   463: aload #7
    //   465: ifnull -> 475
    //   468: aload #6
    //   470: aload #7
    //   472: putfield e : Ljava/util/concurrent/Executor;
    //   475: aload #6
    //   477: getfield g : Lc/w/a/c$c;
    //   480: ifnonnull -> 495
    //   483: aload #6
    //   485: new c/w/a/f/g
    //   488: dup
    //   489: invokespecial <init> : ()V
    //   492: putfield g : Lc/w/a/c$c;
    //   495: aload #6
    //   497: getfield b : Ljava/lang/String;
    //   500: astore #10
    //   502: aload #6
    //   504: getfield g : Lc/w/a/c$c;
    //   507: astore #11
    //   509: aload #6
    //   511: getfield k : Lc/u/n;
    //   514: astore #12
    //   516: aload #6
    //   518: getfield d : Ljava/util/ArrayList;
    //   521: astore #13
    //   523: aload #6
    //   525: getfield h : Z
    //   528: istore #5
    //   530: aload #9
    //   532: ldc 'activity'
    //   534: invokevirtual getSystemService : (Ljava/lang/String;)Ljava/lang/Object;
    //   537: checkcast android/app/ActivityManager
    //   540: astore #7
    //   542: aload #7
    //   544: ifnull -> 562
    //   547: aload #7
    //   549: invokevirtual isLowRamDevice : ()Z
    //   552: ifne -> 562
    //   555: aload #8
    //   557: astore #7
    //   559: goto -> 567
    //   562: getstatic c/u/m.f : Lc/u/m;
    //   565: astore #7
    //   567: new c/u/a
    //   570: dup
    //   571: aload #9
    //   573: aload #10
    //   575: aload #11
    //   577: aload #12
    //   579: aload #13
    //   581: iload #5
    //   583: aload #7
    //   585: aload #6
    //   587: getfield e : Ljava/util/concurrent/Executor;
    //   590: aload #6
    //   592: getfield f : Ljava/util/concurrent/Executor;
    //   595: iconst_0
    //   596: aload #6
    //   598: getfield i : Z
    //   601: aload #6
    //   603: getfield j : Z
    //   606: aconst_null
    //   607: aconst_null
    //   608: aconst_null
    //   609: invokespecial <init> : (Landroid/content/Context;Ljava/lang/String;Lc/w/a/c$c;Lc/u/n;Ljava/util/List;ZLc/u/m;Ljava/util/concurrent/Executor;Ljava/util/concurrent/Executor;ZZZLjava/util/Set;Ljava/lang/String;Ljava/io/File;)V
    //   612: astore #10
    //   614: aload #6
    //   616: getfield a : Ljava/lang/Class;
    //   619: astore #9
    //   621: aload #9
    //   623: invokevirtual getPackage : ()Ljava/lang/Package;
    //   626: invokevirtual getName : ()Ljava/lang/String;
    //   629: astore #11
    //   631: aload #9
    //   633: invokevirtual getCanonicalName : ()Ljava/lang/String;
    //   636: astore #6
    //   638: aload #11
    //   640: invokevirtual isEmpty : ()Z
    //   643: ifeq -> 649
    //   646: goto -> 663
    //   649: aload #6
    //   651: aload #11
    //   653: invokevirtual length : ()I
    //   656: iconst_1
    //   657: iadd
    //   658: invokevirtual substring : (I)Ljava/lang/String;
    //   661: astore #6
    //   663: new java/lang/StringBuilder
    //   666: dup
    //   667: invokespecial <init> : ()V
    //   670: astore #7
    //   672: aload #7
    //   674: aload #6
    //   676: bipush #46
    //   678: bipush #95
    //   680: invokevirtual replace : (CC)Ljava/lang/String;
    //   683: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   686: pop
    //   687: aload #7
    //   689: ldc '_Impl'
    //   691: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   694: pop
    //   695: aload #7
    //   697: invokevirtual toString : ()Ljava/lang/String;
    //   700: astore #7
    //   702: aload #11
    //   704: invokevirtual isEmpty : ()Z
    //   707: ifeq -> 717
    //   710: aload #7
    //   712: astore #6
    //   714: goto -> 757
    //   717: new java/lang/StringBuilder
    //   720: dup
    //   721: invokespecial <init> : ()V
    //   724: astore #6
    //   726: aload #6
    //   728: aload #11
    //   730: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   733: pop
    //   734: aload #6
    //   736: ldc '.'
    //   738: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   741: pop
    //   742: aload #6
    //   744: aload #7
    //   746: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   749: pop
    //   750: aload #6
    //   752: invokevirtual toString : ()Ljava/lang/String;
    //   755: astore #6
    //   757: aload #6
    //   759: invokestatic forName : (Ljava/lang/String;)Ljava/lang/Class;
    //   762: invokevirtual newInstance : ()Ljava/lang/Object;
    //   765: astore #6
    //   767: aload #6
    //   769: checkcast c/u/l
    //   772: astore #6
    //   774: aload #6
    //   776: aload #10
    //   778: invokevirtual f : (Lc/u/a;)Lc/w/a/c;
    //   781: astore #7
    //   783: aload #6
    //   785: aload #7
    //   787: putfield c : Lc/w/a/c;
    //   790: aload #7
    //   792: instanceof c/u/r
    //   795: ifeq -> 808
    //   798: aload #7
    //   800: checkcast c/u/r
    //   803: aload #10
    //   805: putfield e : Lc/u/a;
    //   808: aload #10
    //   810: getfield g : Lc/u/m;
    //   813: aload #8
    //   815: if_acmpne -> 824
    //   818: iconst_1
    //   819: istore #5
    //   821: goto -> 827
    //   824: iconst_0
    //   825: istore #5
    //   827: aload #7
    //   829: iload #5
    //   831: invokeinterface setWriteAheadLoggingEnabled : (Z)V
    //   836: aload #6
    //   838: aload #10
    //   840: getfield e : Ljava/util/List;
    //   843: putfield g : Ljava/util/List;
    //   846: aload #6
    //   848: aload #10
    //   850: getfield h : Ljava/util/concurrent/Executor;
    //   853: putfield b : Ljava/util/concurrent/Executor;
    //   856: new java/util/ArrayDeque
    //   859: dup
    //   860: invokespecial <init> : ()V
    //   863: pop
    //   864: aload #6
    //   866: aload #10
    //   868: getfield f : Z
    //   871: putfield e : Z
    //   874: aload #6
    //   876: iload #5
    //   878: putfield f : Z
    //   881: aload #6
    //   883: checkcast androidx/work/impl/WorkDatabase
    //   886: astore #6
    //   888: aload_0
    //   889: invokespecial <init> : ()V
    //   892: aload_1
    //   893: invokevirtual getApplicationContext : ()Landroid/content/Context;
    //   896: astore #7
    //   898: new c/b0/o
    //   901: dup
    //   902: aload_2
    //   903: getfield f : I
    //   906: invokespecial <init> : (I)V
    //   909: astore #8
    //   911: ldc c/b0/o
    //   913: monitorenter
    //   914: aload #8
    //   916: putstatic c/b0/o.b : Lc/b0/o;
    //   919: ldc c/b0/o
    //   921: monitorexit
    //   922: getstatic c/b0/f0/g.a : Ljava/lang/String;
    //   925: astore #8
    //   927: new c/b0/f0/y/c/b
    //   930: dup
    //   931: aload #7
    //   933: aload_0
    //   934: invokespecial <init> : (Landroid/content/Context;Lc/b0/f0/t;)V
    //   937: astore #8
    //   939: aload #7
    //   941: ldc_w androidx/work/impl/background/systemjob/SystemJobService
    //   944: iconst_1
    //   945: invokestatic a : (Landroid/content/Context;Ljava/lang/Class;Z)V
    //   948: invokestatic c : ()Lc/b0/o;
    //   951: getstatic c/b0/f0/g.a : Ljava/lang/String;
    //   954: ldc_w 'Created SystemJobScheduler and enabled SystemJobService'
    //   957: iconst_0
    //   958: anewarray java/lang/Throwable
    //   961: invokevirtual a : (Ljava/lang/String;Ljava/lang/String;[Ljava/lang/Throwable;)V
    //   964: iconst_2
    //   965: anewarray c/b0/f0/f
    //   968: dup
    //   969: iconst_0
    //   970: aload #8
    //   972: aastore
    //   973: dup
    //   974: iconst_1
    //   975: new c/b0/f0/y/a/c
    //   978: dup
    //   979: aload #7
    //   981: aload_2
    //   982: aload_3
    //   983: aload_0
    //   984: invokespecial <init> : (Landroid/content/Context;Lc/b0/c;Lc/b0/f0/c0/a0/a;Lc/b0/f0/t;)V
    //   987: aastore
    //   988: invokestatic asList : ([Ljava/lang/Object;)Ljava/util/List;
    //   991: astore #7
    //   993: new c/b0/f0/e
    //   996: dup
    //   997: aload_1
    //   998: aload_2
    //   999: aload_3
    //   1000: aload #6
    //   1002: aload #7
    //   1004: invokespecial <init> : (Landroid/content/Context;Lc/b0/c;Lc/b0/f0/c0/a0/a;Landroidx/work/impl/WorkDatabase;Ljava/util/List;)V
    //   1007: astore #8
    //   1009: aload_1
    //   1010: invokevirtual getApplicationContext : ()Landroid/content/Context;
    //   1013: astore_1
    //   1014: aload_0
    //   1015: aload_1
    //   1016: putfield a : Landroid/content/Context;
    //   1019: aload_0
    //   1020: aload_2
    //   1021: putfield b : Lc/b0/c;
    //   1024: aload_0
    //   1025: aload_3
    //   1026: putfield d : Lc/b0/f0/c0/a0/a;
    //   1029: aload_0
    //   1030: aload #6
    //   1032: putfield c : Landroidx/work/impl/WorkDatabase;
    //   1035: aload_0
    //   1036: aload #7
    //   1038: putfield e : Ljava/util/List;
    //   1041: aload_0
    //   1042: aload #8
    //   1044: putfield f : Lc/b0/f0/e;
    //   1047: aload_0
    //   1048: new c/b0/f0/c0/h
    //   1051: dup
    //   1052: aload #6
    //   1054: invokespecial <init> : (Landroidx/work/impl/WorkDatabase;)V
    //   1057: putfield g : Lc/b0/f0/c0/h;
    //   1060: aload_0
    //   1061: iconst_0
    //   1062: putfield h : Z
    //   1065: getstatic android/os/Build$VERSION.SDK_INT : I
    //   1068: bipush #24
    //   1070: if_icmplt -> 1094
    //   1073: aload_1
    //   1074: invokevirtual isDeviceProtectedStorage : ()Z
    //   1077: ifne -> 1083
    //   1080: goto -> 1094
    //   1083: new java/lang/IllegalStateException
    //   1086: dup
    //   1087: ldc_w 'Cannot initialize WorkManager in direct boot mode'
    //   1090: invokespecial <init> : (Ljava/lang/String;)V
    //   1093: athrow
    //   1094: aload_0
    //   1095: getfield d : Lc/b0/f0/c0/a0/a;
    //   1098: astore_2
    //   1099: new androidx/work/impl/utils/ForceStopRunnable
    //   1102: dup
    //   1103: aload_1
    //   1104: aload_0
    //   1105: invokespecial <init> : (Landroid/content/Context;Lc/b0/f0/t;)V
    //   1108: astore_1
    //   1109: aload_2
    //   1110: checkcast c/b0/f0/c0/a0/c
    //   1113: getfield a : Lc/b0/f0/c0/k;
    //   1116: aload_1
    //   1117: invokevirtual execute : (Ljava/lang/Runnable;)V
    //   1120: return
    //   1121: astore_1
    //   1122: ldc c/b0/o
    //   1124: monitorexit
    //   1125: aload_1
    //   1126: athrow
    //   1127: ldc_w 'Failed to create an instance of '
    //   1130: invokestatic p : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   1133: astore_1
    //   1134: aload_1
    //   1135: aload #9
    //   1137: invokevirtual getCanonicalName : ()Ljava/lang/String;
    //   1140: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   1143: pop
    //   1144: new java/lang/RuntimeException
    //   1147: dup
    //   1148: aload_1
    //   1149: invokevirtual toString : ()Ljava/lang/String;
    //   1152: invokespecial <init> : (Ljava/lang/String;)V
    //   1155: athrow
    //   1156: ldc_w 'Cannot access the constructor'
    //   1159: invokestatic p : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   1162: astore_1
    //   1163: aload_1
    //   1164: aload #9
    //   1166: invokevirtual getCanonicalName : ()Ljava/lang/String;
    //   1169: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   1172: pop
    //   1173: new java/lang/RuntimeException
    //   1176: dup
    //   1177: aload_1
    //   1178: invokevirtual toString : ()Ljava/lang/String;
    //   1181: invokespecial <init> : (Ljava/lang/String;)V
    //   1184: athrow
    //   1185: ldc_w 'cannot find implementation for '
    //   1188: invokestatic p : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   1191: astore_1
    //   1192: aload_1
    //   1193: aload #9
    //   1195: invokevirtual getCanonicalName : ()Ljava/lang/String;
    //   1198: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   1201: pop
    //   1202: aload_1
    //   1203: ldc_w '. '
    //   1206: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   1209: pop
    //   1210: aload_1
    //   1211: aload #7
    //   1213: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   1216: pop
    //   1217: aload_1
    //   1218: ldc_w ' does not exist'
    //   1221: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   1224: pop
    //   1225: new java/lang/RuntimeException
    //   1228: dup
    //   1229: aload_1
    //   1230: invokevirtual toString : ()Ljava/lang/String;
    //   1233: invokespecial <init> : (Ljava/lang/String;)V
    //   1236: athrow
    //   1237: new java/lang/IllegalArgumentException
    //   1240: dup
    //   1241: ldc_w 'Must provide an abstract class that extends RoomDatabase'
    //   1244: invokespecial <init> : (Ljava/lang/String;)V
    //   1247: athrow
    //   1248: new java/lang/IllegalArgumentException
    //   1251: dup
    //   1252: ldc_w 'Cannot provide null context for the database.'
    //   1255: invokespecial <init> : (Ljava/lang/String;)V
    //   1258: athrow
    //   1259: astore_1
    //   1260: goto -> 1185
    //   1263: astore_1
    //   1264: goto -> 1156
    //   1267: astore_1
    //   1268: goto -> 1127
    // Exception table:
    //   from	to	target	type
    //   702	710	1259	java/lang/ClassNotFoundException
    //   702	710	1263	java/lang/IllegalAccessException
    //   702	710	1267	java/lang/InstantiationException
    //   717	757	1259	java/lang/ClassNotFoundException
    //   717	757	1263	java/lang/IllegalAccessException
    //   717	757	1267	java/lang/InstantiationException
    //   757	767	1259	java/lang/ClassNotFoundException
    //   757	767	1263	java/lang/IllegalAccessException
    //   757	767	1267	java/lang/InstantiationException
    //   914	919	1121	finally
  }
  
  public static t b(Context paramContext) {
    // Byte code:
    //   0: getstatic c/b0/f0/t.l : Ljava/lang/Object;
    //   3: astore_2
    //   4: aload_2
    //   5: monitorenter
    //   6: aload_2
    //   7: monitorenter
    //   8: getstatic c/b0/f0/t.j : Lc/b0/f0/t;
    //   11: astore_1
    //   12: aload_1
    //   13: ifnull -> 21
    //   16: aload_2
    //   17: monitorexit
    //   18: goto -> 27
    //   21: getstatic c/b0/f0/t.k : Lc/b0/f0/t;
    //   24: astore_1
    //   25: aload_2
    //   26: monitorexit
    //   27: aload_1
    //   28: ifnonnull -> 47
    //   31: aload_0
    //   32: invokevirtual getApplicationContext : ()Landroid/content/Context;
    //   35: pop
    //   36: new java/lang/IllegalStateException
    //   39: dup
    //   40: ldc_w 'WorkManager is not initialized properly.  You have explicitly disabled WorkManagerInitializer in your manifest, have not manually called WorkManager#initialize at this point, and your Application does not implement Configuration.Provider.'
    //   43: invokespecial <init> : (Ljava/lang/String;)V
    //   46: athrow
    //   47: aload_2
    //   48: monitorexit
    //   49: aload_1
    //   50: areturn
    //   51: astore_0
    //   52: aload_2
    //   53: monitorexit
    //   54: aload_0
    //   55: athrow
    //   56: aload_2
    //   57: monitorexit
    //   58: aload_0
    //   59: athrow
    //   60: astore_0
    //   61: goto -> 56
    // Exception table:
    //   from	to	target	type
    //   6	8	60	finally
    //   8	12	51	finally
    //   16	18	51	finally
    //   21	27	51	finally
    //   31	47	60	finally
    //   47	49	60	finally
    //   52	54	51	finally
    //   54	56	60	finally
    //   56	58	60	finally
  }
  
  public static void c(Context paramContext, c paramc) {
    synchronized (l) {
      t t1 = j;
      if (t1 == null || k == null) {
        if (t1 == null) {
          paramContext = paramContext.getApplicationContext();
          if (k == null)
            k = new t(paramContext, paramc, (a)new c(paramc.b)); 
          j = k;
        } 
        return;
      } 
      throw new IllegalStateException("WorkManager is already initialized.  Did you try to initialize it manually without disabling WorkManagerInitializer? See WorkManager#initialize(Context, Configuration) or the class level Javadoc for more information.");
    } 
  }
  
  public void d() {
    synchronized (l) {
      this.h = true;
      BroadcastReceiver.PendingResult pendingResult = this.i;
      if (pendingResult != null) {
        pendingResult.finish();
        this.i = null;
      } 
      return;
    } 
  }
  
  public void e() {
    s s;
    Context context = this.a;
    String str = b.i;
    JobScheduler jobScheduler = (JobScheduler)context.getSystemService("jobscheduler");
    if (jobScheduler != null) {
      List list = b.e(context, jobScheduler);
      if (list != null && !list.isEmpty()) {
        Iterator<JobInfo> iterator = list.iterator();
        while (iterator.hasNext())
          b.a(jobScheduler, ((JobInfo)iterator.next()).getId()); 
      } 
    } 
    c0 c0 = this.c.q();
    c0.a.b();
    i i = c0.i.a();
    c0.a.c();
    try {
      i.a();
      c0.a.k();
      c0.a.g();
      s = c0.i;
      return;
    } finally {
      ((c0)s).a.g();
      ((c0)s).i.c(i);
    } 
  }
  
  public void f(String paramString) {
    a a1 = this.d;
    m m = new m(this, paramString, false);
    ((c)a1).a.execute((Runnable)m);
  }
  
  static {
    o.e("WorkManagerImpl");
  }
}


/* Location:              C:\soft\dex2jar-2.0\Https Traffic-dex2jar.jar!\c\b0\f0\t.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */