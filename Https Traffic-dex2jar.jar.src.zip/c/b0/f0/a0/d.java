package c.b0.f0.a0;

import android.app.Notification;
import androidx.work.impl.foreground.SystemForegroundService;

public class d implements Runnable {
  public d(SystemForegroundService paramSystemForegroundService, int paramInt, Notification paramNotification) {}
  
  public void run() {
    this.g.i.notify(this.e, this.f);
  }
}


/* Location:              C:\soft\dex2jar-2.0\Https Traffic-dex2jar.jar!\c\b0\f0\a0\d.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */