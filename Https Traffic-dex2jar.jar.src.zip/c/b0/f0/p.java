package c.b0.f0;

import c.u.t.a;
import c.w.a.b;
import c.w.a.f.c;

public class p extends a {
  public p(int paramInt1, int paramInt2) {
    super(paramInt1, paramInt2);
  }
  
  public void a(b paramb) {
    ((c)paramb).e.execSQL("ALTER TABLE workspec ADD COLUMN `run_in_foreground` INTEGER NOT NULL DEFAULT 0");
  }
}


/* Location:              C:\soft\dex2jar-2.0\Https Traffic-dex2jar.jar!\c\b0\f0\p.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */