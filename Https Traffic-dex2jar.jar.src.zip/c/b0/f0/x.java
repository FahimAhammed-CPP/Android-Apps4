package c.b0.f0;

import android.content.Context;
import androidx.work.ListenableWorker;
import androidx.work.WorkerParameters;
import androidx.work.impl.WorkDatabase;
import c.b0.a0;
import c.b0.c;
import c.b0.f0.a0.a;
import c.b0.f0.b0.c;
import c.b0.f0.b0.c0;
import c.b0.f0.b0.f0;
import c.b0.f0.b0.t;
import c.b0.f0.c0.a0.a;
import c.b0.f0.c0.z.m;
import c.b0.g;
import c.b0.l;
import c.b0.n;
import c.b0.o;
import d.c.c.d.a.a;
import java.util.Iterator;
import java.util.LinkedList;
import java.util.List;

public class x implements Runnable {
  public static final String x = o.e("WorkerWrapper");
  
  public Context e;
  
  public String f;
  
  public List<f> g;
  
  public WorkerParameters.a h;
  
  public t i;
  
  public ListenableWorker j;
  
  public a k;
  
  public ListenableWorker.a l = (ListenableWorker.a)new l();
  
  public c m;
  
  public a n;
  
  public WorkDatabase o;
  
  public c0 p;
  
  public c q;
  
  public f0 r;
  
  public List<String> s;
  
  public String t;
  
  public m<Boolean> u = new m();
  
  public a<ListenableWorker.a> v = null;
  
  public volatile boolean w;
  
  public x(w paramw) {
    this.e = paramw.a;
    this.k = paramw.c;
    this.n = paramw.b;
    this.f = paramw.f;
    this.g = paramw.g;
    this.h = paramw.h;
    this.j = null;
    this.m = paramw.d;
    WorkDatabase workDatabase = paramw.e;
    this.o = workDatabase;
    this.p = workDatabase.q();
    this.q = this.o.l();
    this.r = this.o.r();
  }
  
  public final void a(ListenableWorker.a parama) {
    if (parama instanceof n) {
      o.c().d(x, String.format("Worker result SUCCESS for %s", new Object[] { this.t }), new Throwable[0]);
      if (this.i.c()) {
        e();
        return;
      } 
      this.o.c();
      try {
        this.p.p(a0.g, new String[] { this.f });
        g g = ((n)this.l).a;
        this.p.n(this.f, g);
        long l = System.currentTimeMillis();
        for (String str : this.q.a(this.f)) {
          if (this.p.f(str) == a0.i && this.q.b(str)) {
            o.c().d(x, String.format("Setting status to enqueued for %s", new Object[] { str }), new Throwable[0]);
            this.p.p(a0.e, new String[] { str });
            this.p.o(str, l);
          } 
        } 
        this.o.k();
        return;
      } finally {
        this.o.g();
        f(false);
      } 
    } 
    if (parama instanceof c.b0.m) {
      o.c().d(x, String.format("Worker result RETRY for %s", new Object[] { this.t }), new Throwable[0]);
      d();
      return;
    } 
    o.c().d(x, String.format("Worker result FAILURE for %s", new Object[] { this.t }), new Throwable[0]);
    if (this.i.c()) {
      e();
      return;
    } 
    h();
  }
  
  public final void b(String paramString) {
    LinkedList<String> linkedList = new LinkedList();
    linkedList.add(paramString);
    while (!linkedList.isEmpty()) {
      paramString = linkedList.remove();
      if (this.p.f(paramString) != a0.j)
        this.p.p(a0.h, new String[] { paramString }); 
      linkedList.addAll(this.q.a(paramString));
    } 
  }
  
  public void c() {
    if (!i()) {
      this.o.c();
      try {
        a0 a0 = this.p.f(this.f);
        this.o.p().a(this.f);
        if (a0 == null) {
          f(false);
        } else if (a0 == a0.f) {
          a(this.l);
        } else if (!a0.a()) {
          d();
        } 
        this.o.k();
      } finally {
        this.o.g();
      } 
    } 
    List<f> list = this.g;
    if (list != null) {
      Iterator<f> iterator = list.iterator();
      while (iterator.hasNext())
        ((f)iterator.next()).b(this.f); 
      g.a(this.m, this.o, this.g);
    } 
  }
  
  public final void d() {
    this.o.c();
    try {
      this.p.p(a0.e, new String[] { this.f });
      this.p.o(this.f, System.currentTimeMillis());
      this.p.l(this.f, -1L);
      this.o.k();
      return;
    } finally {
      this.o.g();
      f(true);
    } 
  }
  
  public final void e() {
    this.o.c();
    try {
      this.p.o(this.f, System.currentTimeMillis());
      this.p.p(a0.e, new String[] { this.f });
      this.p.m(this.f);
      this.p.l(this.f, -1L);
      this.o.k();
      return;
    } finally {
      this.o.g();
      f(false);
    } 
  }
  
  public final void f(boolean paramBoolean) {
    // Byte code:
    //   0: aload_0
    //   1: getfield o : Landroidx/work/impl/WorkDatabase;
    //   4: invokevirtual c : ()V
    //   7: aload_0
    //   8: getfield o : Landroidx/work/impl/WorkDatabase;
    //   11: invokevirtual q : ()Lc/b0/f0/b0/c0;
    //   14: astore #4
    //   16: aload #4
    //   18: invokestatic requireNonNull : (Ljava/lang/Object;)Ljava/lang/Object;
    //   21: pop
    //   22: ldc_w 'SELECT COUNT(*) > 0 FROM workspec WHERE state NOT IN (2, 3, 5) LIMIT 1'
    //   25: iconst_0
    //   26: invokestatic d : (Ljava/lang/String;I)Lc/u/q;
    //   29: astore_3
    //   30: aload #4
    //   32: getfield a : Lc/u/l;
    //   35: invokevirtual b : ()V
    //   38: aload #4
    //   40: getfield a : Lc/u/l;
    //   43: aload_3
    //   44: iconst_0
    //   45: aconst_null
    //   46: invokestatic a : (Lc/u/l;Lc/w/a/e;ZLandroid/os/CancellationSignal;)Landroid/database/Cursor;
    //   49: astore #4
    //   51: aload #4
    //   53: invokeinterface moveToFirst : ()Z
    //   58: ifeq -> 79
    //   61: aload #4
    //   63: iconst_0
    //   64: invokeinterface getInt : (I)I
    //   69: istore_2
    //   70: iload_2
    //   71: ifeq -> 79
    //   74: iconst_1
    //   75: istore_2
    //   76: goto -> 81
    //   79: iconst_0
    //   80: istore_2
    //   81: aload #4
    //   83: invokeinterface close : ()V
    //   88: aload_3
    //   89: invokevirtual h : ()V
    //   92: iload_2
    //   93: ifne -> 107
    //   96: aload_0
    //   97: getfield e : Landroid/content/Context;
    //   100: ldc_w androidx/work/impl/background/systemalarm/RescheduleReceiver
    //   103: iconst_0
    //   104: invokestatic a : (Landroid/content/Context;Ljava/lang/Class;Z)V
    //   107: iload_1
    //   108: ifeq -> 148
    //   111: aload_0
    //   112: getfield p : Lc/b0/f0/b0/c0;
    //   115: getstatic c/b0/a0.e : Lc/b0/a0;
    //   118: iconst_1
    //   119: anewarray java/lang/String
    //   122: dup
    //   123: iconst_0
    //   124: aload_0
    //   125: getfield f : Ljava/lang/String;
    //   128: aastore
    //   129: invokevirtual p : (Lc/b0/a0;[Ljava/lang/String;)I
    //   132: pop
    //   133: aload_0
    //   134: getfield p : Lc/b0/f0/b0/c0;
    //   137: aload_0
    //   138: getfield f : Ljava/lang/String;
    //   141: ldc2_w -1
    //   144: invokevirtual l : (Ljava/lang/String;J)I
    //   147: pop
    //   148: aload_0
    //   149: getfield i : Lc/b0/f0/b0/t;
    //   152: ifnull -> 228
    //   155: aload_0
    //   156: getfield j : Landroidx/work/ListenableWorker;
    //   159: astore_3
    //   160: aload_3
    //   161: ifnull -> 228
    //   164: aload_3
    //   165: invokevirtual isRunInForeground : ()Z
    //   168: ifeq -> 228
    //   171: aload_0
    //   172: getfield n : Lc/b0/f0/a0/a;
    //   175: astore #4
    //   177: aload_0
    //   178: getfield f : Ljava/lang/String;
    //   181: astore_3
    //   182: aload #4
    //   184: checkcast c/b0/f0/e
    //   187: astore #5
    //   189: aload #5
    //   191: getfield o : Ljava/lang/Object;
    //   194: astore #4
    //   196: aload #4
    //   198: monitorenter
    //   199: aload #5
    //   201: getfield j : Ljava/util/Map;
    //   204: aload_3
    //   205: invokeinterface remove : (Ljava/lang/Object;)Ljava/lang/Object;
    //   210: pop
    //   211: aload #5
    //   213: invokevirtual h : ()V
    //   216: aload #4
    //   218: monitorexit
    //   219: goto -> 228
    //   222: astore_3
    //   223: aload #4
    //   225: monitorexit
    //   226: aload_3
    //   227: athrow
    //   228: aload_0
    //   229: getfield o : Landroidx/work/impl/WorkDatabase;
    //   232: invokevirtual k : ()V
    //   235: aload_0
    //   236: getfield o : Landroidx/work/impl/WorkDatabase;
    //   239: invokevirtual g : ()V
    //   242: aload_0
    //   243: getfield u : Lc/b0/f0/c0/z/m;
    //   246: iload_1
    //   247: invokestatic valueOf : (Z)Ljava/lang/Boolean;
    //   250: invokevirtual k : (Ljava/lang/Object;)Z
    //   253: pop
    //   254: return
    //   255: astore #5
    //   257: aload #4
    //   259: invokeinterface close : ()V
    //   264: aload_3
    //   265: invokevirtual h : ()V
    //   268: aload #5
    //   270: athrow
    //   271: astore_3
    //   272: aload_0
    //   273: getfield o : Landroidx/work/impl/WorkDatabase;
    //   276: invokevirtual g : ()V
    //   279: aload_3
    //   280: athrow
    // Exception table:
    //   from	to	target	type
    //   7	51	271	finally
    //   51	70	255	finally
    //   81	92	271	finally
    //   96	107	271	finally
    //   111	148	271	finally
    //   148	160	271	finally
    //   164	199	271	finally
    //   199	219	222	finally
    //   223	226	222	finally
    //   226	228	271	finally
    //   228	235	271	finally
    //   257	271	271	finally
  }
  
  public final void g() {
    a0 a0 = this.p.f(this.f);
    if (a0 == a0.f) {
      o.c().a(x, String.format("Status for %s is RUNNING;not doing any work and rescheduling for later execution", new Object[] { this.f }), new Throwable[0]);
      f(true);
      return;
    } 
    o.c().a(x, String.format("Status for %s is %s; not doing any work", new Object[] { this.f, a0 }), new Throwable[0]);
    f(false);
  }
  
  public void h() {
    this.o.c();
    try {
      b(this.f);
      g g = ((l)this.l).a;
      this.p.n(this.f, g);
      this.o.k();
      return;
    } finally {
      this.o.g();
      f(false);
    } 
  }
  
  public final boolean i() {
    if (this.w) {
      o.c().a(x, String.format("Work interrupted for %s", new Object[] { this.t }), new Throwable[0]);
      a0 a0 = this.p.f(this.f);
      if (a0 == null) {
        f(false);
        return true;
      } 
      f(a0.a() ^ true);
      return true;
    } 
    return false;
  }
  
  public void run() {
    // Byte code:
    //   0: aload_0
    //   1: getfield r : Lc/b0/f0/b0/f0;
    //   4: aload_0
    //   5: getfield f : Ljava/lang/String;
    //   8: invokevirtual a : (Ljava/lang/String;)Ljava/util/List;
    //   11: astore #5
    //   13: aload_0
    //   14: aload #5
    //   16: putfield s : Ljava/util/List;
    //   19: new java/lang/StringBuilder
    //   22: dup
    //   23: ldc_w 'Work [ id='
    //   26: invokespecial <init> : (Ljava/lang/String;)V
    //   29: astore #4
    //   31: aload #4
    //   33: aload_0
    //   34: getfield f : Ljava/lang/String;
    //   37: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   40: pop
    //   41: aload #4
    //   43: ldc_w ', tags={ '
    //   46: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   49: pop
    //   50: aload #5
    //   52: invokeinterface iterator : ()Ljava/util/Iterator;
    //   57: astore #5
    //   59: iconst_1
    //   60: istore_1
    //   61: aload #5
    //   63: invokeinterface hasNext : ()Z
    //   68: ifeq -> 112
    //   71: aload #5
    //   73: invokeinterface next : ()Ljava/lang/Object;
    //   78: checkcast java/lang/String
    //   81: astore #6
    //   83: iload_1
    //   84: ifeq -> 92
    //   87: iconst_0
    //   88: istore_1
    //   89: goto -> 101
    //   92: aload #4
    //   94: ldc_w ', '
    //   97: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   100: pop
    //   101: aload #4
    //   103: aload #6
    //   105: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   108: pop
    //   109: goto -> 61
    //   112: aload #4
    //   114: ldc_w ' } ]'
    //   117: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   120: pop
    //   121: aload_0
    //   122: aload #4
    //   124: invokevirtual toString : ()Ljava/lang/String;
    //   127: putfield t : Ljava/lang/String;
    //   130: getstatic c/b0/a0.e : Lc/b0/a0;
    //   133: astore #5
    //   135: aload_0
    //   136: invokevirtual i : ()Z
    //   139: ifeq -> 143
    //   142: return
    //   143: aload_0
    //   144: getfield o : Landroidx/work/impl/WorkDatabase;
    //   147: invokevirtual c : ()V
    //   150: aload_0
    //   151: getfield p : Lc/b0/f0/b0/c0;
    //   154: aload_0
    //   155: getfield f : Ljava/lang/String;
    //   158: invokevirtual i : (Ljava/lang/String;)Lc/b0/f0/b0/t;
    //   161: astore #4
    //   163: aload_0
    //   164: aload #4
    //   166: putfield i : Lc/b0/f0/b0/t;
    //   169: aload #4
    //   171: ifnonnull -> 219
    //   174: invokestatic c : ()Lc/b0/o;
    //   177: getstatic c/b0/f0/x.x : Ljava/lang/String;
    //   180: ldc_w 'Didn't find WorkSpec for id %s'
    //   183: iconst_1
    //   184: anewarray java/lang/Object
    //   187: dup
    //   188: iconst_0
    //   189: aload_0
    //   190: getfield f : Ljava/lang/String;
    //   193: aastore
    //   194: invokestatic format : (Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/String;
    //   197: iconst_0
    //   198: anewarray java/lang/Throwable
    //   201: invokevirtual b : (Ljava/lang/String;Ljava/lang/String;[Ljava/lang/Throwable;)V
    //   204: aload_0
    //   205: iconst_0
    //   206: invokevirtual f : (Z)V
    //   209: aload_0
    //   210: getfield o : Landroidx/work/impl/WorkDatabase;
    //   213: invokevirtual k : ()V
    //   216: goto -> 397
    //   219: aload #4
    //   221: getfield b : Lc/b0/a0;
    //   224: aload #5
    //   226: if_acmpeq -> 276
    //   229: aload_0
    //   230: invokevirtual g : ()V
    //   233: aload_0
    //   234: getfield o : Landroidx/work/impl/WorkDatabase;
    //   237: invokevirtual k : ()V
    //   240: invokestatic c : ()Lc/b0/o;
    //   243: getstatic c/b0/f0/x.x : Ljava/lang/String;
    //   246: ldc_w '%s is not in ENQUEUED state. Nothing more to do.'
    //   249: iconst_1
    //   250: anewarray java/lang/Object
    //   253: dup
    //   254: iconst_0
    //   255: aload_0
    //   256: getfield i : Lc/b0/f0/b0/t;
    //   259: getfield c : Ljava/lang/String;
    //   262: aastore
    //   263: invokestatic format : (Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/String;
    //   266: iconst_0
    //   267: anewarray java/lang/Throwable
    //   270: invokevirtual a : (Ljava/lang/String;Ljava/lang/String;[Ljava/lang/Throwable;)V
    //   273: goto -> 397
    //   276: aload #4
    //   278: invokevirtual c : ()Z
    //   281: ifne -> 313
    //   284: aload_0
    //   285: getfield i : Lc/b0/f0/b0/t;
    //   288: astore #4
    //   290: aload #4
    //   292: getfield b : Lc/b0/a0;
    //   295: aload #5
    //   297: if_acmpne -> 1230
    //   300: aload #4
    //   302: getfield k : I
    //   305: ifle -> 1230
    //   308: iconst_1
    //   309: istore_1
    //   310: goto -> 1232
    //   313: invokestatic currentTimeMillis : ()J
    //   316: lstore_2
    //   317: aload_0
    //   318: getfield i : Lc/b0/f0/b0/t;
    //   321: astore #4
    //   323: aload #4
    //   325: getfield n : J
    //   328: lconst_0
    //   329: lcmp
    //   330: ifne -> 1239
    //   333: iconst_1
    //   334: istore_1
    //   335: goto -> 338
    //   338: iload_1
    //   339: ifne -> 405
    //   342: lload_2
    //   343: aload #4
    //   345: invokevirtual a : ()J
    //   348: lcmp
    //   349: ifge -> 405
    //   352: invokestatic c : ()Lc/b0/o;
    //   355: getstatic c/b0/f0/x.x : Ljava/lang/String;
    //   358: ldc_w 'Delaying execution for %s because it is being executed before schedule.'
    //   361: iconst_1
    //   362: anewarray java/lang/Object
    //   365: dup
    //   366: iconst_0
    //   367: aload_0
    //   368: getfield i : Lc/b0/f0/b0/t;
    //   371: getfield c : Ljava/lang/String;
    //   374: aastore
    //   375: invokestatic format : (Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/String;
    //   378: iconst_0
    //   379: anewarray java/lang/Throwable
    //   382: invokevirtual a : (Ljava/lang/String;Ljava/lang/String;[Ljava/lang/Throwable;)V
    //   385: aload_0
    //   386: iconst_1
    //   387: invokevirtual f : (Z)V
    //   390: aload_0
    //   391: getfield o : Landroidx/work/impl/WorkDatabase;
    //   394: invokevirtual k : ()V
    //   397: aload_0
    //   398: getfield o : Landroidx/work/impl/WorkDatabase;
    //   401: invokevirtual g : ()V
    //   404: return
    //   405: aload_0
    //   406: getfield o : Landroidx/work/impl/WorkDatabase;
    //   409: invokevirtual k : ()V
    //   412: aload_0
    //   413: getfield o : Landroidx/work/impl/WorkDatabase;
    //   416: invokevirtual g : ()V
    //   419: aload_0
    //   420: getfield i : Lc/b0/f0/b0/t;
    //   423: invokevirtual c : ()Z
    //   426: ifeq -> 441
    //   429: aload_0
    //   430: getfield i : Lc/b0/f0/b0/t;
    //   433: getfield e : Lc/b0/g;
    //   436: astore #4
    //   438: goto -> 731
    //   441: aload_0
    //   442: getfield m : Lc/b0/c;
    //   445: getfield d : Lc/b0/k;
    //   448: astore #4
    //   450: aload_0
    //   451: getfield i : Lc/b0/f0/b0/t;
    //   454: getfield d : Ljava/lang/String;
    //   457: astore #6
    //   459: aload #4
    //   461: invokestatic requireNonNull : (Ljava/lang/Object;)Ljava/lang/Object;
    //   464: pop
    //   465: getstatic c/b0/j.a : Ljava/lang/String;
    //   468: astore #4
    //   470: aload #6
    //   472: invokestatic forName : (Ljava/lang/String;)Ljava/lang/Class;
    //   475: invokevirtual newInstance : ()Ljava/lang/Object;
    //   478: checkcast c/b0/j
    //   481: astore #4
    //   483: goto -> 517
    //   486: astore #4
    //   488: invokestatic c : ()Lc/b0/o;
    //   491: getstatic c/b0/j.a : Ljava/lang/String;
    //   494: ldc_w 'Trouble instantiating + '
    //   497: aload #6
    //   499: invokestatic f : (Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;
    //   502: iconst_1
    //   503: anewarray java/lang/Throwable
    //   506: dup
    //   507: iconst_0
    //   508: aload #4
    //   510: aastore
    //   511: invokevirtual b : (Ljava/lang/String;Ljava/lang/String;[Ljava/lang/Throwable;)V
    //   514: aconst_null
    //   515: astore #4
    //   517: aload #4
    //   519: ifnonnull -> 560
    //   522: invokestatic c : ()Lc/b0/o;
    //   525: getstatic c/b0/f0/x.x : Ljava/lang/String;
    //   528: ldc_w 'Could not create Input Merger %s'
    //   531: iconst_1
    //   532: anewarray java/lang/Object
    //   535: dup
    //   536: iconst_0
    //   537: aload_0
    //   538: getfield i : Lc/b0/f0/b0/t;
    //   541: getfield d : Ljava/lang/String;
    //   544: aastore
    //   545: invokestatic format : (Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/String;
    //   548: iconst_0
    //   549: anewarray java/lang/Throwable
    //   552: invokevirtual b : (Ljava/lang/String;Ljava/lang/String;[Ljava/lang/Throwable;)V
    //   555: aload_0
    //   556: invokevirtual h : ()V
    //   559: return
    //   560: new java/util/ArrayList
    //   563: dup
    //   564: invokespecial <init> : ()V
    //   567: astore #7
    //   569: aload #7
    //   571: aload_0
    //   572: getfield i : Lc/b0/f0/b0/t;
    //   575: getfield e : Lc/b0/g;
    //   578: invokevirtual add : (Ljava/lang/Object;)Z
    //   581: pop
    //   582: aload_0
    //   583: getfield p : Lc/b0/f0/b0/c0;
    //   586: astore #8
    //   588: aload_0
    //   589: getfield f : Ljava/lang/String;
    //   592: astore #9
    //   594: aload #8
    //   596: invokestatic requireNonNull : (Ljava/lang/Object;)Ljava/lang/Object;
    //   599: pop
    //   600: ldc_w 'SELECT output FROM workspec WHERE id IN (SELECT prerequisite_id FROM dependency WHERE work_spec_id=?)'
    //   603: iconst_1
    //   604: invokestatic d : (Ljava/lang/String;I)Lc/u/q;
    //   607: astore #6
    //   609: aload #9
    //   611: ifnonnull -> 623
    //   614: aload #6
    //   616: iconst_1
    //   617: invokevirtual f : (I)V
    //   620: goto -> 631
    //   623: aload #6
    //   625: iconst_1
    //   626: aload #9
    //   628: invokevirtual g : (ILjava/lang/String;)V
    //   631: aload #8
    //   633: getfield a : Lc/u/l;
    //   636: invokevirtual b : ()V
    //   639: aload #8
    //   641: getfield a : Lc/u/l;
    //   644: aload #6
    //   646: iconst_0
    //   647: aconst_null
    //   648: invokestatic a : (Lc/u/l;Lc/w/a/e;ZLandroid/os/CancellationSignal;)Landroid/database/Cursor;
    //   651: astore #8
    //   653: new java/util/ArrayList
    //   656: dup
    //   657: aload #8
    //   659: invokeinterface getCount : ()I
    //   664: invokespecial <init> : (I)V
    //   667: astore #9
    //   669: aload #8
    //   671: invokeinterface moveToNext : ()Z
    //   676: ifeq -> 699
    //   679: aload #9
    //   681: aload #8
    //   683: iconst_0
    //   684: invokeinterface getBlob : (I)[B
    //   689: invokestatic a : ([B)Lc/b0/g;
    //   692: invokevirtual add : (Ljava/lang/Object;)Z
    //   695: pop
    //   696: goto -> 669
    //   699: aload #8
    //   701: invokeinterface close : ()V
    //   706: aload #6
    //   708: invokevirtual h : ()V
    //   711: aload #7
    //   713: aload #9
    //   715: invokevirtual addAll : (Ljava/util/Collection;)Z
    //   718: pop
    //   719: aload #4
    //   721: aload #7
    //   723: invokevirtual a : (Ljava/util/List;)Lc/b0/g;
    //   726: astore #4
    //   728: goto -> 438
    //   731: aload_0
    //   732: getfield f : Ljava/lang/String;
    //   735: invokestatic fromString : (Ljava/lang/String;)Ljava/util/UUID;
    //   738: astore #6
    //   740: aload_0
    //   741: getfield s : Ljava/util/List;
    //   744: astore #7
    //   746: aload_0
    //   747: getfield h : Landroidx/work/WorkerParameters$a;
    //   750: astore #8
    //   752: aload_0
    //   753: getfield i : Lc/b0/f0/b0/t;
    //   756: getfield k : I
    //   759: istore_1
    //   760: aload_0
    //   761: getfield m : Lc/b0/c;
    //   764: astore #9
    //   766: new androidx/work/WorkerParameters
    //   769: dup
    //   770: aload #6
    //   772: aload #4
    //   774: aload #7
    //   776: aload #8
    //   778: iload_1
    //   779: aload #9
    //   781: getfield a : Ljava/util/concurrent/Executor;
    //   784: aload_0
    //   785: getfield k : Lc/b0/f0/c0/a0/a;
    //   788: aload #9
    //   790: getfield c : Lc/b0/e0;
    //   793: new c/b0/f0/c0/u
    //   796: dup
    //   797: aload_0
    //   798: getfield o : Landroidx/work/impl/WorkDatabase;
    //   801: aload_0
    //   802: getfield k : Lc/b0/f0/c0/a0/a;
    //   805: invokespecial <init> : (Landroidx/work/impl/WorkDatabase;Lc/b0/f0/c0/a0/a;)V
    //   808: new c/b0/f0/c0/s
    //   811: dup
    //   812: aload_0
    //   813: getfield o : Landroidx/work/impl/WorkDatabase;
    //   816: aload_0
    //   817: getfield n : Lc/b0/f0/a0/a;
    //   820: aload_0
    //   821: getfield k : Lc/b0/f0/c0/a0/a;
    //   824: invokespecial <init> : (Landroidx/work/impl/WorkDatabase;Lc/b0/f0/a0/a;Lc/b0/f0/c0/a0/a;)V
    //   827: invokespecial <init> : (Ljava/util/UUID;Lc/b0/g;Ljava/util/Collection;Landroidx/work/WorkerParameters$a;ILjava/util/concurrent/Executor;Lc/b0/f0/c0/a0/a;Lc/b0/e0;Lc/b0/y;Lc/b0/i;)V
    //   830: astore #4
    //   832: aload_0
    //   833: getfield j : Landroidx/work/ListenableWorker;
    //   836: ifnonnull -> 866
    //   839: aload_0
    //   840: aload_0
    //   841: getfield m : Lc/b0/c;
    //   844: getfield c : Lc/b0/e0;
    //   847: aload_0
    //   848: getfield e : Landroid/content/Context;
    //   851: aload_0
    //   852: getfield i : Lc/b0/f0/b0/t;
    //   855: getfield c : Ljava/lang/String;
    //   858: aload #4
    //   860: invokevirtual a : (Landroid/content/Context;Ljava/lang/String;Landroidx/work/WorkerParameters;)Landroidx/work/ListenableWorker;
    //   863: putfield j : Landroidx/work/ListenableWorker;
    //   866: aload_0
    //   867: getfield j : Landroidx/work/ListenableWorker;
    //   870: astore #6
    //   872: aload #6
    //   874: ifnonnull -> 915
    //   877: invokestatic c : ()Lc/b0/o;
    //   880: getstatic c/b0/f0/x.x : Ljava/lang/String;
    //   883: ldc_w 'Could not create Worker %s'
    //   886: iconst_1
    //   887: anewarray java/lang/Object
    //   890: dup
    //   891: iconst_0
    //   892: aload_0
    //   893: getfield i : Lc/b0/f0/b0/t;
    //   896: getfield c : Ljava/lang/String;
    //   899: aastore
    //   900: invokestatic format : (Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/String;
    //   903: iconst_0
    //   904: anewarray java/lang/Throwable
    //   907: invokevirtual b : (Ljava/lang/String;Ljava/lang/String;[Ljava/lang/Throwable;)V
    //   910: aload_0
    //   911: invokevirtual h : ()V
    //   914: return
    //   915: aload #6
    //   917: invokevirtual isUsed : ()Z
    //   920: ifeq -> 961
    //   923: invokestatic c : ()Lc/b0/o;
    //   926: getstatic c/b0/f0/x.x : Ljava/lang/String;
    //   929: ldc_w 'Received an already-used Worker %s; WorkerFactory should return new instances'
    //   932: iconst_1
    //   933: anewarray java/lang/Object
    //   936: dup
    //   937: iconst_0
    //   938: aload_0
    //   939: getfield i : Lc/b0/f0/b0/t;
    //   942: getfield c : Ljava/lang/String;
    //   945: aastore
    //   946: invokestatic format : (Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/String;
    //   949: iconst_0
    //   950: anewarray java/lang/Throwable
    //   953: invokevirtual b : (Ljava/lang/String;Ljava/lang/String;[Ljava/lang/Throwable;)V
    //   956: aload_0
    //   957: invokevirtual h : ()V
    //   960: return
    //   961: aload_0
    //   962: getfield j : Landroidx/work/ListenableWorker;
    //   965: invokevirtual setUsed : ()V
    //   968: aload_0
    //   969: getfield o : Landroidx/work/impl/WorkDatabase;
    //   972: invokevirtual c : ()V
    //   975: aload_0
    //   976: getfield p : Lc/b0/f0/b0/c0;
    //   979: aload_0
    //   980: getfield f : Ljava/lang/String;
    //   983: invokevirtual f : (Ljava/lang/String;)Lc/b0/a0;
    //   986: aload #5
    //   988: if_acmpne -> 1244
    //   991: aload_0
    //   992: getfield p : Lc/b0/f0/b0/c0;
    //   995: astore #5
    //   997: getstatic c/b0/a0.f : Lc/b0/a0;
    //   1000: astore #6
    //   1002: iconst_1
    //   1003: istore_1
    //   1004: aload #5
    //   1006: aload #6
    //   1008: iconst_1
    //   1009: anewarray java/lang/String
    //   1012: dup
    //   1013: iconst_0
    //   1014: aload_0
    //   1015: getfield f : Ljava/lang/String;
    //   1018: aastore
    //   1019: invokevirtual p : (Lc/b0/a0;[Ljava/lang/String;)I
    //   1022: pop
    //   1023: aload_0
    //   1024: getfield p : Lc/b0/f0/b0/c0;
    //   1027: aload_0
    //   1028: getfield f : Ljava/lang/String;
    //   1031: invokevirtual k : (Ljava/lang/String;)I
    //   1034: pop
    //   1035: goto -> 1038
    //   1038: aload_0
    //   1039: getfield o : Landroidx/work/impl/WorkDatabase;
    //   1042: invokevirtual k : ()V
    //   1045: aload_0
    //   1046: getfield o : Landroidx/work/impl/WorkDatabase;
    //   1049: invokevirtual g : ()V
    //   1052: iload_1
    //   1053: ifeq -> 1184
    //   1056: aload_0
    //   1057: invokevirtual i : ()Z
    //   1060: ifeq -> 1064
    //   1063: return
    //   1064: new c/b0/f0/c0/z/m
    //   1067: dup
    //   1068: invokespecial <init> : ()V
    //   1071: astore #5
    //   1073: new c/b0/f0/c0/q
    //   1076: dup
    //   1077: aload_0
    //   1078: getfield e : Landroid/content/Context;
    //   1081: aload_0
    //   1082: getfield i : Lc/b0/f0/b0/t;
    //   1085: aload_0
    //   1086: getfield j : Landroidx/work/ListenableWorker;
    //   1089: aload #4
    //   1091: getfield j : Lc/b0/i;
    //   1094: aload_0
    //   1095: getfield k : Lc/b0/f0/c0/a0/a;
    //   1098: invokespecial <init> : (Landroid/content/Context;Lc/b0/f0/b0/t;Landroidx/work/ListenableWorker;Lc/b0/i;Lc/b0/f0/c0/a0/a;)V
    //   1101: astore #4
    //   1103: aload_0
    //   1104: getfield k : Lc/b0/f0/c0/a0/a;
    //   1107: checkcast c/b0/f0/c0/a0/c
    //   1110: getfield c : Ljava/util/concurrent/Executor;
    //   1113: aload #4
    //   1115: invokeinterface execute : (Ljava/lang/Runnable;)V
    //   1120: aload #4
    //   1122: getfield e : Lc/b0/f0/c0/z/m;
    //   1125: astore #4
    //   1127: aload #4
    //   1129: new c/b0/f0/u
    //   1132: dup
    //   1133: aload_0
    //   1134: aload #4
    //   1136: aload #5
    //   1138: invokespecial <init> : (Lc/b0/f0/x;Ld/c/c/d/a/a;Lc/b0/f0/c0/z/m;)V
    //   1141: aload_0
    //   1142: getfield k : Lc/b0/f0/c0/a0/a;
    //   1145: checkcast c/b0/f0/c0/a0/c
    //   1148: getfield c : Ljava/util/concurrent/Executor;
    //   1151: invokevirtual c : (Ljava/lang/Runnable;Ljava/util/concurrent/Executor;)V
    //   1154: aload #5
    //   1156: new c/b0/f0/v
    //   1159: dup
    //   1160: aload_0
    //   1161: aload #5
    //   1163: aload_0
    //   1164: getfield t : Ljava/lang/String;
    //   1167: invokespecial <init> : (Lc/b0/f0/x;Lc/b0/f0/c0/z/m;Ljava/lang/String;)V
    //   1170: aload_0
    //   1171: getfield k : Lc/b0/f0/c0/a0/a;
    //   1174: checkcast c/b0/f0/c0/a0/c
    //   1177: getfield a : Lc/b0/f0/c0/k;
    //   1180: invokevirtual c : (Ljava/lang/Runnable;Ljava/util/concurrent/Executor;)V
    //   1183: return
    //   1184: aload_0
    //   1185: invokevirtual g : ()V
    //   1188: return
    //   1189: astore #4
    //   1191: aload_0
    //   1192: getfield o : Landroidx/work/impl/WorkDatabase;
    //   1195: invokevirtual g : ()V
    //   1198: aload #4
    //   1200: athrow
    //   1201: astore #4
    //   1203: aload #8
    //   1205: invokeinterface close : ()V
    //   1210: aload #6
    //   1212: invokevirtual h : ()V
    //   1215: aload #4
    //   1217: athrow
    //   1218: astore #4
    //   1220: aload_0
    //   1221: getfield o : Landroidx/work/impl/WorkDatabase;
    //   1224: invokevirtual g : ()V
    //   1227: aload #4
    //   1229: athrow
    //   1230: iconst_0
    //   1231: istore_1
    //   1232: iload_1
    //   1233: ifeq -> 405
    //   1236: goto -> 313
    //   1239: iconst_0
    //   1240: istore_1
    //   1241: goto -> 338
    //   1244: iconst_0
    //   1245: istore_1
    //   1246: goto -> 1038
    // Exception table:
    //   from	to	target	type
    //   150	169	1218	finally
    //   174	216	1218	finally
    //   219	273	1218	finally
    //   276	308	1218	finally
    //   313	333	1218	finally
    //   342	397	1218	finally
    //   405	412	1218	finally
    //   470	483	486	java/lang/Exception
    //   653	669	1201	finally
    //   669	696	1201	finally
    //   975	1002	1189	finally
    //   1004	1035	1189	finally
    //   1038	1045	1189	finally
  }
}


/* Location:              C:\soft\dex2jar-2.0\Https Traffic-dex2jar.jar!\c\b0\f0\x.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */