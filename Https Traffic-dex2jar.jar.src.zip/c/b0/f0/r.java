package c.b0.f0;

import android.content.Context;
import c.w.a.f.c;

public abstract class r {
  public static c.u.t.a a = new k(1, 2);
  
  public static c.u.t.a b = new l(3, 4);
  
  public static c.u.t.a c = new m(4, 5);
  
  public static c.u.t.a d = new n(6, 7);
  
  public static c.u.t.a e = new o(7, 8);
  
  public static c.u.t.a f = new p(8, 9);
  
  public static c.u.t.a g = new q(11, 12);
  
  public static class a extends c.u.t.a {
    public final Context c;
    
    public a(Context param1Context, int param1Int1, int param1Int2) {
      super(param1Int1, param1Int2);
      this.c = param1Context;
    }
    
    public void a(c.w.a.b param1b) {
      if (this.b >= 10) {
        ((c)param1b).e.execSQL("INSERT OR REPLACE INTO `Preference` (`key`, `long_value`) VALUES (@key, @long_value)", new Object[] { "reschedule_needed", Integer.valueOf(1) });
        return;
      } 
      this.c.getSharedPreferences("androidx.work.util.preferences", 0).edit().putBoolean("reschedule_needed", true).apply();
    }
  }
  
  public static class b extends c.u.t.a {
    public final Context c;
    
    public b(Context param1Context) {
      super(9, 10);
      this.c = param1Context;
    }
    
    public void a(c.w.a.b param1b) {
      // Byte code:
      //   0: aload_1
      //   1: checkcast c/w/a/f/c
      //   4: getfield e : Landroid/database/sqlite/SQLiteDatabase;
      //   7: ldc 'CREATE TABLE IF NOT EXISTS `Preference` (`key` TEXT NOT NULL, `long_value` INTEGER, PRIMARY KEY(`key`))'
      //   9: invokevirtual execSQL : (Ljava/lang/String;)V
      //   12: aload_0
      //   13: getfield c : Landroid/content/Context;
      //   16: ldc 'androidx.work.util.preferences'
      //   18: iconst_0
      //   19: invokevirtual getSharedPreferences : (Ljava/lang/String;I)Landroid/content/SharedPreferences;
      //   22: astore #9
      //   24: aload #9
      //   26: ldc 'reschedule_needed'
      //   28: invokeinterface contains : (Ljava/lang/String;)Z
      //   33: ifne -> 48
      //   36: aload #9
      //   38: ldc 'last_cancel_all_time_ms'
      //   40: invokeinterface contains : (Ljava/lang/String;)Z
      //   45: ifeq -> 186
      //   48: lconst_0
      //   49: lstore #4
      //   51: aload #9
      //   53: ldc 'last_cancel_all_time_ms'
      //   55: lconst_0
      //   56: invokeinterface getLong : (Ljava/lang/String;J)J
      //   61: lstore #6
      //   63: aload #9
      //   65: ldc 'reschedule_needed'
      //   67: iconst_0
      //   68: invokeinterface getBoolean : (Ljava/lang/String;Z)Z
      //   73: ifeq -> 79
      //   76: lconst_1
      //   77: lstore #4
      //   79: aload_1
      //   80: checkcast c/w/a/f/c
      //   83: astore #8
      //   85: aload #8
      //   87: getfield e : Landroid/database/sqlite/SQLiteDatabase;
      //   90: invokevirtual beginTransaction : ()V
      //   93: aload_1
      //   94: checkcast c/w/a/f/c
      //   97: getfield e : Landroid/database/sqlite/SQLiteDatabase;
      //   100: ldc 'INSERT OR REPLACE INTO `Preference` (`key`, `long_value`) VALUES (@key, @long_value)'
      //   102: iconst_2
      //   103: anewarray java/lang/Object
      //   106: dup
      //   107: iconst_0
      //   108: ldc 'last_cancel_all_time_ms'
      //   110: aastore
      //   111: dup
      //   112: iconst_1
      //   113: lload #6
      //   115: invokestatic valueOf : (J)Ljava/lang/Long;
      //   118: aastore
      //   119: invokevirtual execSQL : (Ljava/lang/String;[Ljava/lang/Object;)V
      //   122: aload_1
      //   123: checkcast c/w/a/f/c
      //   126: getfield e : Landroid/database/sqlite/SQLiteDatabase;
      //   129: ldc 'INSERT OR REPLACE INTO `Preference` (`key`, `long_value`) VALUES (@key, @long_value)'
      //   131: iconst_2
      //   132: anewarray java/lang/Object
      //   135: dup
      //   136: iconst_0
      //   137: ldc 'reschedule_needed'
      //   139: aastore
      //   140: dup
      //   141: iconst_1
      //   142: lload #4
      //   144: invokestatic valueOf : (J)Ljava/lang/Long;
      //   147: aastore
      //   148: invokevirtual execSQL : (Ljava/lang/String;[Ljava/lang/Object;)V
      //   151: aload #9
      //   153: invokeinterface edit : ()Landroid/content/SharedPreferences$Editor;
      //   158: invokeinterface clear : ()Landroid/content/SharedPreferences$Editor;
      //   163: invokeinterface apply : ()V
      //   168: aload_1
      //   169: checkcast c/w/a/f/c
      //   172: getfield e : Landroid/database/sqlite/SQLiteDatabase;
      //   175: invokevirtual setTransactionSuccessful : ()V
      //   178: aload #8
      //   180: getfield e : Landroid/database/sqlite/SQLiteDatabase;
      //   183: invokevirtual endTransaction : ()V
      //   186: aload_0
      //   187: getfield c : Landroid/content/Context;
      //   190: ldc 'androidx.work.util.id'
      //   192: iconst_0
      //   193: invokevirtual getSharedPreferences : (Ljava/lang/String;I)Landroid/content/SharedPreferences;
      //   196: astore #9
      //   198: aload #9
      //   200: ldc 'next_job_scheduler_id'
      //   202: invokeinterface contains : (Ljava/lang/String;)Z
      //   207: ifne -> 222
      //   210: aload #9
      //   212: ldc 'next_job_scheduler_id'
      //   214: invokeinterface contains : (Ljava/lang/String;)Z
      //   219: ifeq -> 349
      //   222: aload #9
      //   224: ldc 'next_job_scheduler_id'
      //   226: iconst_0
      //   227: invokeinterface getInt : (Ljava/lang/String;I)I
      //   232: istore_2
      //   233: aload #9
      //   235: ldc 'next_alarm_manager_id'
      //   237: iconst_0
      //   238: invokeinterface getInt : (Ljava/lang/String;I)I
      //   243: istore_3
      //   244: aload_1
      //   245: checkcast c/w/a/f/c
      //   248: astore #8
      //   250: aload #8
      //   252: getfield e : Landroid/database/sqlite/SQLiteDatabase;
      //   255: invokevirtual beginTransaction : ()V
      //   258: aload_1
      //   259: checkcast c/w/a/f/c
      //   262: getfield e : Landroid/database/sqlite/SQLiteDatabase;
      //   265: ldc 'INSERT OR REPLACE INTO `Preference` (`key`, `long_value`) VALUES (@key, @long_value)'
      //   267: iconst_2
      //   268: anewarray java/lang/Object
      //   271: dup
      //   272: iconst_0
      //   273: ldc 'next_job_scheduler_id'
      //   275: aastore
      //   276: dup
      //   277: iconst_1
      //   278: iload_2
      //   279: invokestatic valueOf : (I)Ljava/lang/Integer;
      //   282: aastore
      //   283: invokevirtual execSQL : (Ljava/lang/String;[Ljava/lang/Object;)V
      //   286: aload_1
      //   287: checkcast c/w/a/f/c
      //   290: getfield e : Landroid/database/sqlite/SQLiteDatabase;
      //   293: ldc 'INSERT OR REPLACE INTO `Preference` (`key`, `long_value`) VALUES (@key, @long_value)'
      //   295: iconst_2
      //   296: anewarray java/lang/Object
      //   299: dup
      //   300: iconst_0
      //   301: ldc 'next_alarm_manager_id'
      //   303: aastore
      //   304: dup
      //   305: iconst_1
      //   306: iload_3
      //   307: invokestatic valueOf : (I)Ljava/lang/Integer;
      //   310: aastore
      //   311: invokevirtual execSQL : (Ljava/lang/String;[Ljava/lang/Object;)V
      //   314: aload #9
      //   316: invokeinterface edit : ()Landroid/content/SharedPreferences$Editor;
      //   321: invokeinterface clear : ()Landroid/content/SharedPreferences$Editor;
      //   326: invokeinterface apply : ()V
      //   331: aload_1
      //   332: checkcast c/w/a/f/c
      //   335: getfield e : Landroid/database/sqlite/SQLiteDatabase;
      //   338: invokevirtual setTransactionSuccessful : ()V
      //   341: aload #8
      //   343: getfield e : Landroid/database/sqlite/SQLiteDatabase;
      //   346: invokevirtual endTransaction : ()V
      //   349: return
      //   350: astore_1
      //   351: aload #8
      //   353: getfield e : Landroid/database/sqlite/SQLiteDatabase;
      //   356: invokevirtual endTransaction : ()V
      //   359: aload_1
      //   360: athrow
      //   361: astore_1
      //   362: aload #8
      //   364: getfield e : Landroid/database/sqlite/SQLiteDatabase;
      //   367: invokevirtual endTransaction : ()V
      //   370: aload_1
      //   371: athrow
      // Exception table:
      //   from	to	target	type
      //   93	178	361	finally
      //   258	341	350	finally
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Https Traffic-dex2jar.jar!\c\b0\f0\r.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */