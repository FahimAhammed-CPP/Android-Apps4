package c.b0.f0;

import android.os.Build;
import android.os.Handler;
import android.os.Looper;
import android.util.Log;
import java.lang.reflect.InvocationTargetException;

public class a {
  public final Handler a;
  
  public a() {
    Throwable throwable;
    Looper looper = Looper.getMainLooper();
    if (Build.VERSION.SDK_INT >= 28) {
      Handler handler = Handler.createAsync(looper);
    } else {
      try {
        Handler handler = Handler.class.getDeclaredConstructor(new Class[] { Looper.class, Handler.Callback.class, boolean.class }).newInstance(new Object[] { looper, null, Boolean.TRUE });
      } catch (IllegalAccessException illegalAccessException) {
        Log.w("HandlerCompat", "Unable to invoke Handler(Looper, Callback, boolean) constructor", illegalAccessException);
        Handler handler = new Handler(looper);
      } catch (InstantiationException null) {
      
      } catch (NoSuchMethodException null) {
      
      } catch (InvocationTargetException invocationTargetException) {
        throwable = invocationTargetException.getCause();
        if (!(throwable instanceof RuntimeException)) {
          if (throwable instanceof Error)
            throw (Error)throwable; 
          throw new RuntimeException(throwable);
        } 
        throw (RuntimeException)throwable;
      } 
    } 
    this.a = (Handler)throwable;
  }
}


/* Location:              C:\soft\dex2jar-2.0\Https Traffic-dex2jar.jar!\c\b0\f0\a.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */