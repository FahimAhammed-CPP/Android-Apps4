package c.b0.f0;

import android.content.Context;
import androidx.work.WorkerParameters;
import androidx.work.impl.WorkDatabase;
import c.b0.c;
import c.b0.f0.a0.a;
import c.b0.f0.c0.a0.a;
import java.util.List;

public class w {
  public Context a;
  
  public a b;
  
  public a c;
  
  public c d;
  
  public WorkDatabase e;
  
  public String f;
  
  public List<f> g;
  
  public WorkerParameters.a h = new WorkerParameters.a();
  
  public w(Context paramContext, c paramc, a parama, a parama1, WorkDatabase paramWorkDatabase, String paramString) {
    this.a = paramContext.getApplicationContext();
    this.c = parama;
    this.b = parama1;
    this.d = paramc;
    this.e = paramWorkDatabase;
    this.f = paramString;
  }
}


/* Location:              C:\soft\dex2jar-2.0\Https Traffic-dex2jar.jar!\c\b0\f0\w.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */