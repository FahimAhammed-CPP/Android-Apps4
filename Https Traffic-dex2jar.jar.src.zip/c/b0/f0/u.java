package c.b0.f0;

import c.b0.f0.c0.z.k;
import c.b0.f0.c0.z.m;
import c.b0.o;
import d.c.c.d.a.a;

public class u implements Runnable {
  public u(x paramx, a parama, m paramm) {}
  
  public void run() {
    try {
      ((k)this.e).get();
      o.c().a(x.x, String.format("Starting work for %s", new Object[] { this.g.i.c }), new Throwable[0]);
      x x1 = this.g;
      return;
    } finally {
      Exception exception = null;
      this.f.l(exception);
    } 
  }
}


/* Location:              C:\soft\dex2jar-2.0\Https Traffic-dex2jar.jar!\c\b0\f\\u.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */