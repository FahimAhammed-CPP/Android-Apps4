package c.b0.f0;

import android.os.Build;
import androidx.work.impl.WorkDatabase;
import c.b0.c;
import c.b0.f0.b0.c0;
import c.b0.f0.b0.t;
import c.b0.o;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

public abstract class g {
  public static final String a = o.e("Schedulers");
  
  public static void a(c paramc, WorkDatabase paramWorkDatabase, List<f> paramList) {
    if (paramList != null) {
      if (paramList.size() == 0)
        return; 
      c0 c0 = paramWorkDatabase.q();
      paramWorkDatabase.c();
      try {
        int i;
        if (Build.VERSION.SDK_INT == 23) {
          i = paramc.h / 2;
        } else {
          i = paramc.h;
        } 
        List list2 = c0.c(i);
        List list1 = c0.b(200);
        if (((ArrayList)list2).size() > 0) {
          long l = System.currentTimeMillis();
          Iterator iterator = ((ArrayList)list2).iterator();
          while (iterator.hasNext())
            c0.l(((t)iterator.next()).a, l); 
        } 
        paramWorkDatabase.k();
        paramWorkDatabase.g();
        ArrayList arrayList = (ArrayList)list2;
        if (arrayList.size() > 0) {
          t[] arrayOfT = (t[])arrayList.toArray((Object[])new t[arrayList.size()]);
          for (f f : paramList) {
            if (f.f())
              f.c(arrayOfT); 
          } 
        } 
        list1 = list1;
        return;
      } finally {
        paramWorkDatabase.g();
      } 
    } 
  }
}


/* Location:              C:\soft\dex2jar-2.0\Https Traffic-dex2jar.jar!\c\b0\f0\g.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */