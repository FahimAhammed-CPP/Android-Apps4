package c.b0.f0;

import androidx.work.ListenableWorker;
import c.b0.f0.c0.z.m;
import c.b0.o;
import java.util.concurrent.CancellationException;
import java.util.concurrent.ExecutionException;

public class v implements Runnable {
  public v(x paramx, m paramm, String paramString) {}
  
  public void run() {
    try {
      ListenableWorker.a a = (ListenableWorker.a)this.e.get();
      if (a == null) {
        o.c().b(x.x, String.format("%s returned a null result. Treating it as a failure.", new Object[] { this.g.i.c }), new Throwable[0]);
      } else {
        o.c().a(x.x, String.format("%s returned a %s result.", new Object[] { this.g.i.c, a }), new Throwable[0]);
        this.g.l = a;
      } 
    } catch (CancellationException cancellationException) {
      o.c().d(x.x, String.format("%s was cancelled", new Object[] { this.f }), new Throwable[] { cancellationException });
    } catch (InterruptedException interruptedException) {
      o.c().b(x.x, String.format("%s failed because it threw an exception/error", new Object[] { this.f }), new Throwable[] { interruptedException });
    } catch (ExecutionException executionException) {
      o.c().b(x.x, String.format("%s failed because it threw an exception/error", new Object[] { this.f }), new Throwable[] { executionException });
    } finally {
      Exception exception;
    } 
    this.g.c();
  }
}


/* Location:              C:\soft\dex2jar-2.0\Https Traffic-dex2jar.jar!\c\b0\f0\v.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */