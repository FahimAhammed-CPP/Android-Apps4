package c.b0.f0.y.b;

import android.content.Context;
import c.b0.o;

public class c {
  public static final String e = o.e("ConstraintsCmdHandler");
  
  public final Context a;
  
  public final int b;
  
  public final g c;
  
  public final c.b0.f0.z.c d;
  
  public c(Context paramContext, int paramInt, g paramg) {
    this.a = paramContext;
    this.b = paramInt;
    this.c = paramg;
    this.d = new c.b0.f0.z.c(paramContext, paramg.f, null);
  }
}


/* Location:              C:\soft\dex2jar-2.0\Https Traffic-dex2jar.jar!\c\b0\f0\y\b\c.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */