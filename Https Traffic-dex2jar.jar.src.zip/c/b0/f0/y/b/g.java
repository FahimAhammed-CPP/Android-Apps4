package c.b0.f0.y.b;

import android.content.Context;
import android.content.Intent;
import android.os.Handler;
import android.os.Looper;
import android.os.PowerManager;
import androidx.work.impl.background.systemalarm.SystemAlarmService;
import c.b0.f0.b;
import c.b0.f0.c0.a0.c;
import c.b0.f0.c0.n;
import c.b0.f0.c0.y;
import c.b0.f0.e;
import c.b0.f0.t;
import c.b0.o;
import java.util.ArrayList;
import java.util.List;

public class g implements b {
  public static final String o = o.e("SystemAlarmDispatcher");
  
  public final Context e;
  
  public final c.b0.f0.c0.a0.a f;
  
  public final y g;
  
  public final e h;
  
  public final t i;
  
  public final b j;
  
  public final Handler k;
  
  public final List<Intent> l;
  
  public Intent m;
  
  public a n;
  
  public g(Context paramContext) {
    Context context = paramContext.getApplicationContext();
    this.e = context;
    this.j = new b(context);
    this.g = new y();
    t t1 = t.b(paramContext);
    this.i = t1;
    e e1 = t1.f;
    this.h = e1;
    this.f = t1.d;
    e1.b(this);
    this.l = new ArrayList<Intent>();
    this.m = null;
    this.k = new Handler(Looper.getMainLooper());
  }
  
  public void a(String paramString, boolean paramBoolean) {
    Context context = this.e;
    String str = b.h;
    Intent intent = new Intent(context, SystemAlarmService.class);
    intent.setAction("ACTION_EXECUTION_COMPLETED");
    intent.putExtra("KEY_WORKSPEC_ID", paramString);
    intent.putExtra("KEY_NEEDS_RESCHEDULE", paramBoolean);
    f f = new f(this, intent, 0);
    this.k.post(f);
  }
  
  public boolean b(Intent paramIntent, int paramInt) {
    // Byte code:
    //   0: invokestatic c : ()Lc/b0/o;
    //   3: astore #6
    //   5: getstatic c/b0/f0/y/b/g.o : Ljava/lang/String;
    //   8: astore #5
    //   10: iconst_0
    //   11: istore #4
    //   13: aload #6
    //   15: aload #5
    //   17: ldc 'Adding command %s (%s)'
    //   19: iconst_2
    //   20: anewarray java/lang/Object
    //   23: dup
    //   24: iconst_0
    //   25: aload_1
    //   26: aastore
    //   27: dup
    //   28: iconst_1
    //   29: iload_2
    //   30: invokestatic valueOf : (I)Ljava/lang/Integer;
    //   33: aastore
    //   34: invokestatic format : (Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/String;
    //   37: iconst_0
    //   38: anewarray java/lang/Throwable
    //   41: invokevirtual a : (Ljava/lang/String;Ljava/lang/String;[Ljava/lang/Throwable;)V
    //   44: aload_0
    //   45: invokevirtual c : ()V
    //   48: aload_1
    //   49: invokevirtual getAction : ()Ljava/lang/String;
    //   52: astore #6
    //   54: aload #6
    //   56: invokestatic isEmpty : (Ljava/lang/CharSequence;)Z
    //   59: ifeq -> 78
    //   62: invokestatic c : ()Lc/b0/o;
    //   65: aload #5
    //   67: ldc 'Unknown command. Ignoring'
    //   69: iconst_0
    //   70: anewarray java/lang/Throwable
    //   73: invokevirtual f : (Ljava/lang/String;Ljava/lang/String;[Ljava/lang/Throwable;)V
    //   76: iconst_0
    //   77: ireturn
    //   78: ldc 'ACTION_CONSTRAINTS_CHANGED'
    //   80: aload #6
    //   82: invokevirtual equals : (Ljava/lang/Object;)Z
    //   85: ifeq -> 165
    //   88: aload_0
    //   89: invokevirtual c : ()V
    //   92: aload_0
    //   93: getfield l : Ljava/util/List;
    //   96: astore #5
    //   98: aload #5
    //   100: monitorenter
    //   101: aload_0
    //   102: getfield l : Ljava/util/List;
    //   105: invokeinterface iterator : ()Ljava/util/Iterator;
    //   110: astore #6
    //   112: aload #6
    //   114: invokeinterface hasNext : ()Z
    //   119: ifeq -> 151
    //   122: ldc 'ACTION_CONSTRAINTS_CHANGED'
    //   124: aload #6
    //   126: invokeinterface next : ()Ljava/lang/Object;
    //   131: checkcast android/content/Intent
    //   134: invokevirtual getAction : ()Ljava/lang/String;
    //   137: invokevirtual equals : (Ljava/lang/Object;)Z
    //   140: ifeq -> 112
    //   143: aload #5
    //   145: monitorexit
    //   146: iconst_1
    //   147: istore_3
    //   148: goto -> 229
    //   151: aload #5
    //   153: monitorexit
    //   154: iconst_0
    //   155: istore_3
    //   156: goto -> 229
    //   159: astore_1
    //   160: aload #5
    //   162: monitorexit
    //   163: aload_1
    //   164: athrow
    //   165: aload_1
    //   166: ldc 'KEY_START_ID'
    //   168: iload_2
    //   169: invokevirtual putExtra : (Ljava/lang/String;I)Landroid/content/Intent;
    //   172: pop
    //   173: aload_0
    //   174: getfield l : Ljava/util/List;
    //   177: astore #5
    //   179: aload #5
    //   181: monitorenter
    //   182: iload #4
    //   184: istore_2
    //   185: aload_0
    //   186: getfield l : Ljava/util/List;
    //   189: invokeinterface isEmpty : ()Z
    //   194: ifne -> 199
    //   197: iconst_1
    //   198: istore_2
    //   199: aload_0
    //   200: getfield l : Ljava/util/List;
    //   203: aload_1
    //   204: invokeinterface add : (Ljava/lang/Object;)Z
    //   209: pop
    //   210: iload_2
    //   211: ifne -> 218
    //   214: aload_0
    //   215: invokevirtual e : ()V
    //   218: aload #5
    //   220: monitorexit
    //   221: iconst_1
    //   222: ireturn
    //   223: astore_1
    //   224: aload #5
    //   226: monitorexit
    //   227: aload_1
    //   228: athrow
    //   229: iload_3
    //   230: ifeq -> 165
    //   233: iconst_0
    //   234: ireturn
    // Exception table:
    //   from	to	target	type
    //   101	112	159	finally
    //   112	146	159	finally
    //   151	154	159	finally
    //   160	163	159	finally
    //   185	197	223	finally
    //   199	210	223	finally
    //   214	218	223	finally
    //   218	221	223	finally
    //   224	227	223	finally
  }
  
  public final void c() {
    if (this.k.getLooper().getThread() == Thread.currentThread())
      return; 
    throw new IllegalStateException("Needs to be invoked on the main thread.");
  }
  
  public void d() {
    o.c().a(o, "Destroying SystemAlarmDispatcher", new Throwable[0]);
    this.h.e(this);
    y y1 = this.g;
    if (!y1.b.isShutdown())
      y1.b.shutdownNow(); 
    this.n = null;
  }
  
  public final void e() {
    c();
    PowerManager.WakeLock wakeLock = n.a(this.e, "ProcessCommand");
    try {
      wakeLock.acquire();
      c.b0.f0.c0.a0.a a1 = this.i.d;
      e e1 = new e(this);
      ((c)a1).a.execute(e1);
      return;
    } finally {
      wakeLock.release();
    } 
  }
  
  public static interface a {}
}


/* Location:              C:\soft\dex2jar-2.0\Https Traffic-dex2jar.jar!\c\b0\f0\y\b\g.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */