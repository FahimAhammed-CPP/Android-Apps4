package c.b0.f0.y.b;

import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import androidx.work.impl.WorkDatabase;
import androidx.work.impl.background.systemalarm.ConstraintProxy;
import androidx.work.impl.background.systemalarm.ConstraintProxyUpdateReceiver;
import androidx.work.impl.background.systemalarm.SystemAlarmService;
import c.b0.d;
import c.b0.f0.b;
import c.b0.f0.b0.g;
import c.b0.f0.b0.j;
import c.b0.f0.b0.t;
import c.b0.f0.t;
import c.b0.o;
import c.b0.p;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

public class b implements b {
  public static final String h = o.e("CommandHandler");
  
  public final Context e;
  
  public final Map<String, b> f;
  
  public final Object g;
  
  public b(Context paramContext) {
    this.e = paramContext;
    this.f = new HashMap<String, b>();
    this.g = new Object();
  }
  
  public static Intent b(Context paramContext) {
    Intent intent = new Intent(paramContext, SystemAlarmService.class);
    intent.setAction("ACTION_CONSTRAINTS_CHANGED");
    return intent;
  }
  
  public static Intent c(Context paramContext, String paramString) {
    Intent intent = new Intent(paramContext, SystemAlarmService.class);
    intent.setAction("ACTION_DELAY_MET");
    intent.putExtra("KEY_WORKSPEC_ID", paramString);
    return intent;
  }
  
  public static Intent d(Context paramContext, String paramString) {
    Intent intent = new Intent(paramContext, SystemAlarmService.class);
    intent.setAction("ACTION_SCHEDULE_WORK");
    intent.putExtra("KEY_WORKSPEC_ID", paramString);
    return intent;
  }
  
  public void a(String paramString, boolean paramBoolean) {
    synchronized (this.g) {
      b b1 = this.f.remove(paramString);
      if (b1 != null)
        b1.a(paramString, paramBoolean); 
      return;
    } 
  }
  
  public void e(Intent paramIntent, int paramInt, g paramg) {
    c c;
    WorkDatabase workDatabase;
    String str1;
    Iterator<t> iterator;
    int i;
    f f;
    String str2;
    Context context;
    String str3 = paramIntent.getAction();
    if ("ACTION_CONSTRAINTS_CHANGED".equals(str3)) {
      int i1;
      int i2;
      int i3;
      int i4;
      o.c().a(h, String.format("Handling constraints changed %s", new Object[] { paramIntent }), new Throwable[0]);
      c = new c(this.e, paramInt, paramg);
      List<t> list = paramg.i.c.q().e();
      context = c.a;
      String str4 = ConstraintProxy.a;
      ArrayList arrayList = (ArrayList)list;
      Iterator iterator1 = arrayList.iterator();
      int n = 0;
      int m = n;
      int k = m;
      int j = k;
      while (true) {
        i1 = n;
        i3 = m;
        i4 = k;
        int i5 = j;
        if (iterator1.hasNext()) {
          d d = ((t)iterator1.next()).j;
          i1 = n | d.d;
          i3 = m | d.b;
          i4 = k | d.e;
          if (d.a != p.e) {
            paramInt = 1;
          } else {
            paramInt = 0;
          } 
          i2 = j | paramInt;
          int i9 = i1;
          int i8 = i3;
          int i7 = i4;
          int i6 = i2;
          if (i1 != 0) {
            int i12 = i1;
            int i11 = i3;
            int i10 = i4;
            i6 = i2;
            if (i3 != 0) {
              int i15 = i1;
              int i14 = i3;
              int i13 = i4;
              i6 = i2;
              if (i4 != 0) {
                int i18 = i1;
                int i17 = i3;
                int i16 = i4;
                i6 = i2;
                if (i2 != 0)
                  break; 
              } 
            } 
          } 
          continue;
        } 
        break;
      } 
      String str5 = ConstraintProxyUpdateReceiver.a;
      Intent intent = new Intent("androidx.work.impl.background.systemalarm.UpdateProxies");
      intent.setComponent(new ComponentName(context, ConstraintProxyUpdateReceiver.class));
      intent.putExtra("KEY_BATTERY_NOT_LOW_PROXY_ENABLED", i1).putExtra("KEY_BATTERY_CHARGING_PROXY_ENABLED", i3).putExtra("KEY_STORAGE_NOT_LOW_PROXY_ENABLED", i4).putExtra("KEY_NETWORK_STATE_PROXY_ENABLED", i2);
      context.sendBroadcast(intent);
      c.d.b(list);
      list = new ArrayList(arrayList.size());
      long l = System.currentTimeMillis();
      for (t t : arrayList) {
        String str = t.a;
        if (l >= t.a() && (!t.b() || c.d.a(str)))
          list.add(t); 
      } 
      iterator = list.iterator();
      while (iterator.hasNext()) {
        String str = ((t)iterator.next()).a;
        Intent intent1 = c(c.a, str);
        o.c().a(c.e, String.format("Creating a delay_met command for workSpec with id (%s)", new Object[] { str }), new Throwable[0]);
        g g1 = c.c;
        f = new f(g1, intent1, c.b);
        g1.k.post(f);
      } 
      c.d.c();
      return;
    } 
    if ("ACTION_RESCHEDULE".equals(f)) {
      o.c().a(h, String.format("Handling reschedule %s, %s", new Object[] { c, Integer.valueOf(paramInt) }), new Throwable[0]);
      ((g)iterator).i.e();
      return;
    } 
    Bundle bundle = c.getExtras();
    if (bundle == null || bundle.isEmpty()) {
      i = 0;
    } else {
      for (i = 0; i < 1; i++) {
        (new String[1])[0] = "KEY_WORKSPEC_ID";
        if (bundle.get((new String[1])[i]) == null)
          // Byte code: goto -> 695 
      } 
      i = 1;
    } 
    if (i == 0) {
      o.c().b(h, String.format("Invalid request for %s, requires %s.", new Object[] { f, "KEY_WORKSPEC_ID" }), new Throwable[0]);
      return;
    } 
    if ("ACTION_SCHEDULE_WORK".equals(f)) {
      str2 = c.getExtras().getString("KEY_WORKSPEC_ID");
      o o = o.c();
      String str = h;
      o.a(str, String.format("Handling schedule work for %s", new Object[] { str2 }), new Throwable[0]);
      workDatabase = ((g)iterator).i.c;
      workDatabase.c();
      try {
        StringBuilder stringBuilder;
        t t = workDatabase.q().i(str2);
        if (t == null) {
          o o1 = o.c();
          stringBuilder = new StringBuilder();
          stringBuilder.append("Skipping scheduling ");
          stringBuilder.append(str2);
          stringBuilder.append(" because it's no longer in the DB");
          o1.f(str, stringBuilder.toString(), new Throwable[0]);
        } else {
          o o1;
          if (((t)stringBuilder).b.a()) {
            o1 = o.c();
            stringBuilder = new StringBuilder();
            stringBuilder.append("Skipping scheduling ");
            stringBuilder.append(str2);
            stringBuilder.append("because it is finished.");
            o1.f(str, stringBuilder.toString(), new Throwable[0]);
          } else {
            long l = stringBuilder.a();
            if (!stringBuilder.b()) {
              o.c().a(str, String.format("Setting up Alarms for %s at %s", new Object[] { str2, Long.valueOf(l) }), new Throwable[0]);
              a.b(this.e, ((g)o1).i, str2, l);
            } else {
              o.c().a(str, String.format("Opportunistically setting an alarm for %s at %s", new Object[] { str2, Long.valueOf(l) }), new Throwable[0]);
              a.b(this.e, ((g)o1).i, str2, l);
              f = new f((g)o1, b(this.e), paramInt);
              ((g)o1).k.post(f);
            } 
            workDatabase.k();
          } 
        } 
        return;
      } finally {
        workDatabase.g();
      } 
    } 
    if ("ACTION_DELAY_MET".equals(f)) {
      Bundle bundle1 = workDatabase.getExtras();
      synchronized (this.g) {
        str2 = bundle1.getString("KEY_WORKSPEC_ID");
        o o = o.c();
        String str = h;
        o.a(str, String.format("Handing delay met for %s", new Object[] { str2 }), new Throwable[0]);
        if (!this.f.containsKey(str2)) {
          d d = new d(this.e, paramInt, str2, (g)iterator);
          this.f.put(str2, d);
          d.c();
        } else {
          o.c().a(str, String.format("WorkSpec %s is already being handled for ACTION_DELAY_MET", new Object[] { str2 }), new Throwable[0]);
        } 
        return;
      } 
    } 
    if ("ACTION_STOP_WORK".equals(str2)) {
      str1 = workDatabase.getExtras().getString("KEY_WORKSPEC_ID");
      o.c().a(h, String.format("Handing stopWork work for %s", new Object[] { str1 }), new Throwable[0]);
      ((g)iterator).i.f(str1);
      context = this.e;
      t t = ((g)iterator).i;
      String str = a.a;
      j j = t.c.n();
      g g1 = j.a(str1);
      if (g1 != null) {
        a.a(context, str1, g1.b);
        o.c().a(a.a, String.format("Removing SystemIdInfo for workSpecId (%s)", new Object[] { str1 }), new Throwable[0]);
        j.c(str1);
      } 
      iterator.a(str1, false);
      return;
    } 
    if ("ACTION_EXECUTION_COMPLETED".equals(context)) {
      Bundle bundle1 = str1.getExtras();
      String str = bundle1.getString("KEY_WORKSPEC_ID");
      boolean bool = bundle1.getBoolean("KEY_NEEDS_RESCHEDULE");
      o.c().a(h, String.format("Handling onExecutionCompleted %s, %s", new Object[] { str1, Integer.valueOf(paramInt) }), new Throwable[0]);
      a(str, bool);
      return;
    } 
    o.c().f(h, String.format("Ignoring intent %s", new Object[] { str1 }), new Throwable[0]);
  }
}


/* Location:              C:\soft\dex2jar-2.0\Https Traffic-dex2jar.jar!\c\b0\f0\y\b\b.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */