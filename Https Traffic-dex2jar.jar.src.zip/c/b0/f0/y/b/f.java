package c.b0.f0.y.b;

import android.content.Intent;

public class f implements Runnable {
  public final g e;
  
  public final Intent f;
  
  public final int g;
  
  public f(g paramg, Intent paramIntent, int paramInt) {
    this.e = paramg;
    this.f = paramIntent;
    this.g = paramInt;
  }
  
  public void run() {
    this.e.b(this.f, this.g);
  }
}


/* Location:              C:\soft\dex2jar-2.0\Https Traffic-dex2jar.jar!\c\b0\f0\y\b\f.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */