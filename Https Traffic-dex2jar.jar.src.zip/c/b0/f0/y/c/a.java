package c.b0.f0.y.c;

import android.content.ComponentName;
import android.content.Context;
import androidx.work.impl.background.systemjob.SystemJobService;
import c.b0.o;

public class a {
  public static final String b = o.e("SystemJobInfoConverter");
  
  public final ComponentName a;
  
  public a(Context paramContext) {
    this.a = new ComponentName(paramContext.getApplicationContext(), SystemJobService.class);
  }
}


/* Location:              C:\soft\dex2jar-2.0\Https Traffic-dex2jar.jar!\c\b0\f0\y\c\a.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */