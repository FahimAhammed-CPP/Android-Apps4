package c.b0.f0.y.a;

import c.b0.f0.a;
import c.b0.o;
import java.util.HashMap;
import java.util.Map;

public class b {
  public static final String d = o.e("DelayedWorkTracker");
  
  public final c a;
  
  public final a b;
  
  public final Map<String, Runnable> c;
  
  public b(c paramc, a parama) {
    this.a = paramc;
    this.b = parama;
    this.c = new HashMap<String, Runnable>();
  }
}


/* Location:              C:\soft\dex2jar-2.0\Https Traffic-dex2jar.jar!\c\b0\f0\y\a\b.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */