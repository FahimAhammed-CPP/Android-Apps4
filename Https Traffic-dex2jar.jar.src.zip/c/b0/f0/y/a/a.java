package c.b0.f0.y.a;

import c.b0.f0.b0.t;
import c.b0.o;

public class a implements Runnable {
  public a(b paramb, t paramt) {}
  
  public void run() {
    o.c().a(b.d, String.format("Scheduling work %s", new Object[] { this.e.a }), new Throwable[0]);
    this.f.a.c(new t[] { this.e });
  }
}


/* Location:              C:\soft\dex2jar-2.0\Https Traffic-dex2jar.jar!\c\b0\f0\y\a\a.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */