package c.b0.f0.c0;

import android.content.Context;
import c.b0.f0.c0.z.m;
import c.b0.h;
import c.b0.i;
import c.b0.o;

public class p implements Runnable {
  public p(q paramq, m paramm) {}
  
  public void run() {
    try {
      h h = (h)this.e.get();
      if (h != null) {
        o.c().a(q.k, String.format("Updating notification for %s", new Object[] { this.f.g.c }), new Throwable[0]);
        this.f.h.setRunInForeground(true);
        q q1 = this.f;
        m<Void> m1 = q1.e;
        i i = q1.i;
        Context context = q1.f;
        return;
      } 
      throw new IllegalStateException(String.format("Worker was marked important (%s) but did not provide ForegroundInfo", new Object[] { this.f.g.c }));
    } finally {
      Exception exception = null;
      this.f.e.l(exception);
    } 
  }
}


/* Location:              C:\soft\dex2jar-2.0\Https Traffic-dex2jar.jar!\c\b0\f0\c0\p.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */