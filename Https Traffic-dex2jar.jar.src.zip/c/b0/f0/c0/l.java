package c.b0.f0.c0;

import androidx.work.WorkerParameters;
import c.b0.f0.t;

public class l implements Runnable {
  public t e;
  
  public String f;
  
  public WorkerParameters.a g;
  
  public l(t paramt, String paramString, WorkerParameters.a parama) {
    this.e = paramt;
    this.f = paramString;
    this.g = parama;
  }
  
  public void run() {
    this.e.f.g(this.f, this.g);
  }
}


/* Location:              C:\soft\dex2jar-2.0\Https Traffic-dex2jar.jar!\c\b0\f0\c0\l.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */