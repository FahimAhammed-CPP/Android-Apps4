package c.b0.f0.c0;

import c.b0.f0.c0.z.m;
import c.b0.g;
import c.b0.o;
import java.util.UUID;

public class t implements Runnable {
  public t(u paramu, UUID paramUUID, g paramg, m paramm) {}
  
  public void run() {
    String str1 = this.e.toString();
    o o = o.c();
    String str2 = u.c;
    o.a(str2, String.format("Updating progress for %s (%s)", new Object[] { this.e, this.f }), new Throwable[0]);
    this.h.a.c();
    try {
      c.b0.f0.b0.t t1 = this.h.a.q().i(str1);
    } finally {
      str1 = null;
    } 
    this.h.a.g();
  }
}


/* Location:              C:\soft\dex2jar-2.0\Https Traffic-dex2jar.jar!\c\b0\f0\c0\t.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */