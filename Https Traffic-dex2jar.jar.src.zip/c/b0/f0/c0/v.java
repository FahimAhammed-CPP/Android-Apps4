package c.b0.f0.c0;

import d.a.a.a.a;
import java.util.concurrent.Executors;
import java.util.concurrent.ThreadFactory;

public class v implements ThreadFactory {
  public int a = 0;
  
  public v(y paramy) {}
  
  public Thread newThread(Runnable paramRunnable) {
    paramRunnable = Executors.defaultThreadFactory().newThread(paramRunnable);
    StringBuilder stringBuilder = a.p("WorkManager-WorkTimer-thread-");
    stringBuilder.append(this.a);
    paramRunnable.setName(stringBuilder.toString());
    this.a++;
    return (Thread)paramRunnable;
  }
}


/* Location:              C:\soft\dex2jar-2.0\Https Traffic-dex2jar.jar!\c\b0\f0\c0\v.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */