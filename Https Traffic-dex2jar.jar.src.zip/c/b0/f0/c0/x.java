package c.b0.f0.c0;

import c.b0.f0.y.b.d;
import c.b0.o;

public class x implements Runnable {
  public final y e;
  
  public final String f;
  
  public x(y paramy, String paramString) {
    this.e = paramy;
    this.f = paramString;
  }
  
  public void run() {
    synchronized (this.e.e) {
      if ((x)this.e.c.remove(this.f) != null) {
        w w = this.e.d.remove(this.f);
        if (w != null) {
          String str = this.f;
          d d = (d)w;
          o.c().a(d.n, String.format("Exceeded time limits on execution for %s", new Object[] { str }), new Throwable[0]);
          d.f();
        } 
      } else {
        o.c().a("WrkTimerRunnable", String.format("Timer with %s is already marked as complete.", new Object[] { this.f }), new Throwable[0]);
      } 
      return;
    } 
  }
}


/* Location:              C:\soft\dex2jar-2.0\Https Traffic-dex2jar.jar!\c\b0\f0\c0\x.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */