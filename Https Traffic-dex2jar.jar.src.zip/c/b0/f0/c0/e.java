package c.b0.f0.c0;

import androidx.work.impl.WorkDatabase;
import androidx.work.impl.workers.ConstraintTrackingWorker;
import c.b0.d;
import c.b0.f0.b0.t;
import c.b0.f0.c;
import c.b0.f0.h;
import c.b0.f0.t;
import c.b0.g;
import c.b0.o;
import c.b0.s;
import c.b0.v;
import java.util.HashSet;
import java.util.Objects;

public class e implements Runnable {
  public static final String g = o.e("EnqueueRunnable");
  
  public final h e;
  
  public final c f;
  
  public e(h paramh) {
    this.e = paramh;
    this.f = new c();
  }
  
  public static boolean a(h paramh) {
    // Byte code:
    //   0: aload_0
    //   1: invokestatic requireNonNull : (Ljava/lang/Object;)Ljava/lang/Object;
    //   4: pop
    //   5: aload_0
    //   6: invokestatic b : (Lc/b0/f0/h;)Ljava/util/Set;
    //   9: astore #12
    //   11: aload_0
    //   12: getfield a : Lc/b0/f0/t;
    //   15: astore #18
    //   17: aload_0
    //   18: getfield b : Ljava/util/List;
    //   21: astore #13
    //   23: aload #12
    //   25: iconst_0
    //   26: anewarray java/lang/String
    //   29: invokeinterface toArray : ([Ljava/lang/Object;)[Ljava/lang/Object;
    //   34: checkcast [Ljava/lang/String;
    //   37: astore #12
    //   39: getstatic c/b0/a0.e : Lc/b0/a0;
    //   42: astore #14
    //   44: getstatic c/b0/a0.g : Lc/b0/a0;
    //   47: astore #19
    //   49: getstatic c/b0/a0.j : Lc/b0/a0;
    //   52: astore #15
    //   54: getstatic c/b0/a0.h : Lc/b0/a0;
    //   57: astore #16
    //   59: invokestatic currentTimeMillis : ()J
    //   62: lstore #10
    //   64: aload #18
    //   66: getfield c : Landroidx/work/impl/WorkDatabase;
    //   69: astore #17
    //   71: aload #12
    //   73: ifnull -> 88
    //   76: aload #12
    //   78: arraylength
    //   79: ifle -> 88
    //   82: iconst_1
    //   83: istore #4
    //   85: goto -> 91
    //   88: iconst_0
    //   89: istore #4
    //   91: iload #4
    //   93: ifeq -> 249
    //   96: aload #12
    //   98: arraylength
    //   99: istore #9
    //   101: iconst_0
    //   102: istore #8
    //   104: iload #8
    //   106: istore_2
    //   107: iload_2
    //   108: istore_1
    //   109: iconst_1
    //   110: istore_3
    //   111: iload_3
    //   112: istore #7
    //   114: iload_2
    //   115: istore #6
    //   117: iload_1
    //   118: istore #5
    //   120: iload #8
    //   122: iload #9
    //   124: if_icmpge -> 258
    //   127: aload #12
    //   129: iload #8
    //   131: aaload
    //   132: astore #20
    //   134: aload #17
    //   136: invokevirtual q : ()Lc/b0/f0/b0/c0;
    //   139: aload #20
    //   141: invokevirtual i : (Ljava/lang/String;)Lc/b0/f0/b0/t;
    //   144: astore #21
    //   146: aload #21
    //   148: ifnonnull -> 181
    //   151: invokestatic c : ()Lc/b0/o;
    //   154: getstatic c/b0/f0/c0/e.g : Ljava/lang/String;
    //   157: ldc 'Prerequisite %s doesn't exist; not enqueuing'
    //   159: iconst_1
    //   160: anewarray java/lang/Object
    //   163: dup
    //   164: iconst_0
    //   165: aload #20
    //   167: aastore
    //   168: invokestatic format : (Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/String;
    //   171: iconst_0
    //   172: anewarray java/lang/Throwable
    //   175: invokevirtual b : (Ljava/lang/String;Ljava/lang/String;[Ljava/lang/Throwable;)V
    //   178: goto -> 362
    //   181: aload #21
    //   183: getfield b : Lc/b0/a0;
    //   186: astore #20
    //   188: aload #20
    //   190: aload #19
    //   192: if_acmpne -> 201
    //   195: iconst_1
    //   196: istore #5
    //   198: goto -> 204
    //   201: iconst_0
    //   202: istore #5
    //   204: iload_3
    //   205: iload #5
    //   207: iand
    //   208: istore_3
    //   209: aload #20
    //   211: aload #16
    //   213: if_acmpne -> 222
    //   216: iconst_1
    //   217: istore #5
    //   219: goto -> 237
    //   222: iload_1
    //   223: istore #5
    //   225: aload #20
    //   227: aload #15
    //   229: if_acmpne -> 237
    //   232: iconst_1
    //   233: istore_2
    //   234: iload_1
    //   235: istore #5
    //   237: iload #8
    //   239: iconst_1
    //   240: iadd
    //   241: istore #8
    //   243: iload #5
    //   245: istore_1
    //   246: goto -> 111
    //   249: iconst_1
    //   250: istore #7
    //   252: iconst_0
    //   253: istore #6
    //   255: iconst_0
    //   256: istore #5
    //   258: aconst_null
    //   259: invokestatic isEmpty : (Ljava/lang/CharSequence;)Z
    //   262: iconst_1
    //   263: ixor
    //   264: istore #8
    //   266: iload #8
    //   268: ifeq -> 281
    //   271: iload #4
    //   273: ifne -> 281
    //   276: iconst_1
    //   277: istore_1
    //   278: goto -> 283
    //   281: iconst_0
    //   282: istore_1
    //   283: iload_1
    //   284: ifeq -> 431
    //   287: aload #17
    //   289: invokevirtual q : ()Lc/b0/f0/b0/c0;
    //   292: aconst_null
    //   293: invokevirtual j : (Ljava/lang/String;)Ljava/util/List;
    //   296: checkcast java/util/ArrayList
    //   299: astore #19
    //   301: aload #19
    //   303: invokevirtual isEmpty : ()Z
    //   306: ifne -> 431
    //   309: aload #19
    //   311: invokevirtual iterator : ()Ljava/util/Iterator;
    //   314: astore #20
    //   316: aload #20
    //   318: invokeinterface hasNext : ()Z
    //   323: ifeq -> 367
    //   326: aload #20
    //   328: invokeinterface next : ()Ljava/lang/Object;
    //   333: checkcast c/b0/f0/b0/s
    //   336: getfield b : Lc/b0/a0;
    //   339: astore #21
    //   341: aload #21
    //   343: aload #14
    //   345: if_acmpeq -> 362
    //   348: aload #21
    //   350: getstatic c/b0/a0.f : Lc/b0/a0;
    //   353: if_acmpne -> 359
    //   356: goto -> 362
    //   359: goto -> 316
    //   362: iconst_0
    //   363: istore_1
    //   364: goto -> 955
    //   367: new c/b0/f0/c0/c
    //   370: dup
    //   371: aload #18
    //   373: aconst_null
    //   374: iconst_0
    //   375: invokespecial <init> : (Lc/b0/f0/t;Ljava/lang/String;Z)V
    //   378: invokevirtual run : ()V
    //   381: aload #17
    //   383: invokevirtual q : ()Lc/b0/f0/b0/c0;
    //   386: astore #18
    //   388: aload #19
    //   390: invokevirtual iterator : ()Ljava/util/Iterator;
    //   393: astore #19
    //   395: aload #19
    //   397: invokeinterface hasNext : ()Z
    //   402: ifeq -> 426
    //   405: aload #18
    //   407: aload #19
    //   409: invokeinterface next : ()Ljava/lang/Object;
    //   414: checkcast c/b0/f0/b0/s
    //   417: getfield a : Ljava/lang/String;
    //   420: invokevirtual a : (Ljava/lang/String;)V
    //   423: goto -> 395
    //   426: iconst_1
    //   427: istore_1
    //   428: goto -> 433
    //   431: iconst_0
    //   432: istore_1
    //   433: aload #13
    //   435: invokeinterface iterator : ()Ljava/util/Iterator;
    //   440: astore #18
    //   442: aload #18
    //   444: invokeinterface hasNext : ()Z
    //   449: ifeq -> 955
    //   452: aload #18
    //   454: invokeinterface next : ()Ljava/lang/Object;
    //   459: checkcast c/b0/c0
    //   462: astore #19
    //   464: aload #19
    //   466: getfield b : Lc/b0/f0/b0/t;
    //   469: astore #20
    //   471: iload #4
    //   473: ifeq -> 522
    //   476: iload #7
    //   478: ifne -> 522
    //   481: iload #5
    //   483: ifeq -> 496
    //   486: aload #20
    //   488: aload #16
    //   490: putfield b : Lc/b0/a0;
    //   493: goto -> 546
    //   496: iload #6
    //   498: ifeq -> 511
    //   501: aload #20
    //   503: aload #15
    //   505: putfield b : Lc/b0/a0;
    //   508: goto -> 546
    //   511: aload #20
    //   513: getstatic c/b0/a0.i : Lc/b0/a0;
    //   516: putfield b : Lc/b0/a0;
    //   519: goto -> 546
    //   522: aload #20
    //   524: invokevirtual c : ()Z
    //   527: ifne -> 540
    //   530: aload #20
    //   532: lload #10
    //   534: putfield n : J
    //   537: goto -> 546
    //   540: aload #20
    //   542: lconst_0
    //   543: putfield n : J
    //   546: getstatic android/os/Build$VERSION.SDK_INT : I
    //   549: bipush #25
    //   551: if_icmpgt -> 559
    //   554: aload #20
    //   556: invokestatic b : (Lc/b0/f0/b0/t;)V
    //   559: aload #20
    //   561: getfield b : Lc/b0/a0;
    //   564: aload #14
    //   566: if_acmpne -> 571
    //   569: iconst_1
    //   570: istore_1
    //   571: aload #17
    //   573: invokevirtual q : ()Lc/b0/f0/b0/c0;
    //   576: astore #13
    //   578: aload #13
    //   580: getfield a : Lc/u/l;
    //   583: invokevirtual b : ()V
    //   586: aload #13
    //   588: getfield a : Lc/u/l;
    //   591: invokevirtual c : ()V
    //   594: aload #13
    //   596: getfield b : Lc/u/b;
    //   599: aload #20
    //   601: invokevirtual e : (Ljava/lang/Object;)V
    //   604: aload #13
    //   606: getfield a : Lc/u/l;
    //   609: invokevirtual k : ()V
    //   612: aload #13
    //   614: getfield a : Lc/u/l;
    //   617: invokevirtual g : ()V
    //   620: aload #12
    //   622: astore #13
    //   624: iload_1
    //   625: istore_2
    //   626: iload #4
    //   628: ifeq -> 739
    //   631: aload #12
    //   633: arraylength
    //   634: istore #9
    //   636: iconst_0
    //   637: istore_3
    //   638: aload #12
    //   640: astore #13
    //   642: iload_1
    //   643: istore_2
    //   644: iload_3
    //   645: iload #9
    //   647: if_icmpge -> 739
    //   650: aload #12
    //   652: iload_3
    //   653: aaload
    //   654: astore #13
    //   656: new c/b0/f0/b0/a
    //   659: dup
    //   660: aload #19
    //   662: invokevirtual a : ()Ljava/lang/String;
    //   665: aload #13
    //   667: invokespecial <init> : (Ljava/lang/String;Ljava/lang/String;)V
    //   670: astore #20
    //   672: aload #17
    //   674: invokevirtual l : ()Lc/b0/f0/b0/c;
    //   677: astore #13
    //   679: aload #13
    //   681: getfield a : Lc/u/l;
    //   684: invokevirtual b : ()V
    //   687: aload #13
    //   689: getfield a : Lc/u/l;
    //   692: invokevirtual c : ()V
    //   695: aload #13
    //   697: getfield b : Lc/u/b;
    //   700: aload #20
    //   702: invokevirtual e : (Ljava/lang/Object;)V
    //   705: aload #13
    //   707: getfield a : Lc/u/l;
    //   710: invokevirtual k : ()V
    //   713: aload #13
    //   715: getfield a : Lc/u/l;
    //   718: invokevirtual g : ()V
    //   721: iload_3
    //   722: iconst_1
    //   723: iadd
    //   724: istore_3
    //   725: goto -> 638
    //   728: astore_0
    //   729: aload #13
    //   731: getfield a : Lc/u/l;
    //   734: invokevirtual g : ()V
    //   737: aload_0
    //   738: athrow
    //   739: aload #19
    //   741: getfield c : Ljava/util/Set;
    //   744: invokeinterface iterator : ()Ljava/util/Iterator;
    //   749: astore #20
    //   751: aload #20
    //   753: invokeinterface hasNext : ()Z
    //   758: ifeq -> 852
    //   761: aload #20
    //   763: invokeinterface next : ()Ljava/lang/Object;
    //   768: checkcast java/lang/String
    //   771: astore #21
    //   773: aload #17
    //   775: invokevirtual r : ()Lc/b0/f0/b0/f0;
    //   778: astore #12
    //   780: new c/b0/f0/b0/d0
    //   783: dup
    //   784: aload #21
    //   786: aload #19
    //   788: invokevirtual a : ()Ljava/lang/String;
    //   791: invokespecial <init> : (Ljava/lang/String;Ljava/lang/String;)V
    //   794: astore #21
    //   796: aload #12
    //   798: getfield a : Lc/u/l;
    //   801: invokevirtual b : ()V
    //   804: aload #12
    //   806: getfield a : Lc/u/l;
    //   809: invokevirtual c : ()V
    //   812: aload #12
    //   814: getfield b : Lc/u/b;
    //   817: aload #21
    //   819: invokevirtual e : (Ljava/lang/Object;)V
    //   822: aload #12
    //   824: getfield a : Lc/u/l;
    //   827: invokevirtual k : ()V
    //   830: aload #12
    //   832: getfield a : Lc/u/l;
    //   835: invokevirtual g : ()V
    //   838: goto -> 751
    //   841: astore_0
    //   842: aload #12
    //   844: getfield a : Lc/u/l;
    //   847: invokevirtual g : ()V
    //   850: aload_0
    //   851: athrow
    //   852: iload #8
    //   854: ifeq -> 935
    //   857: aload #17
    //   859: invokevirtual o : ()Lc/b0/f0/b0/m;
    //   862: astore #12
    //   864: new c/b0/f0/b0/k
    //   867: dup
    //   868: aconst_null
    //   869: aload #19
    //   871: invokevirtual a : ()Ljava/lang/String;
    //   874: invokespecial <init> : (Ljava/lang/String;Ljava/lang/String;)V
    //   877: astore #19
    //   879: aload #12
    //   881: getfield a : Lc/u/l;
    //   884: invokevirtual b : ()V
    //   887: aload #12
    //   889: getfield a : Lc/u/l;
    //   892: invokevirtual c : ()V
    //   895: aload #12
    //   897: getfield b : Lc/u/b;
    //   900: aload #19
    //   902: invokevirtual e : (Ljava/lang/Object;)V
    //   905: aload #12
    //   907: getfield a : Lc/u/l;
    //   910: invokevirtual k : ()V
    //   913: aload #12
    //   915: getfield a : Lc/u/l;
    //   918: invokevirtual g : ()V
    //   921: goto -> 935
    //   924: astore_0
    //   925: aload #12
    //   927: getfield a : Lc/u/l;
    //   930: invokevirtual g : ()V
    //   933: aload_0
    //   934: athrow
    //   935: aload #13
    //   937: astore #12
    //   939: iload_2
    //   940: istore_1
    //   941: goto -> 442
    //   944: astore_0
    //   945: aload #13
    //   947: getfield a : Lc/u/l;
    //   950: invokevirtual g : ()V
    //   953: aload_0
    //   954: athrow
    //   955: aload_0
    //   956: iconst_1
    //   957: putfield e : Z
    //   960: iconst_0
    //   961: iload_1
    //   962: ior
    //   963: ireturn
    // Exception table:
    //   from	to	target	type
    //   594	612	944	finally
    //   695	713	728	finally
    //   812	830	841	finally
    //   895	913	924	finally
  }
  
  public static void b(t paramt) {
    d d = paramt.j;
    String str = paramt.c;
    if (!str.equals(ConstraintTrackingWorker.class.getName()) && (d.d || d.e)) {
      g.a a = new g.a();
      a.b(paramt.e.a);
      a.a.put("androidx.work.impl.workers.ConstraintTrackingWorker.ARGUMENT_CLASS_NAME", str);
      paramt.c = ConstraintTrackingWorker.class.getName();
      paramt.e = a.a();
    } 
  }
  
  public void run() {
    try {
      h h1 = this.e;
      Objects.requireNonNull(h1);
      if (!h.a(h1, new HashSet())) {
        t t;
        WorkDatabase workDatabase = this.e.a.c;
        workDatabase.c();
        try {
          boolean bool = a(this.e);
          workDatabase.k();
          return;
        } finally {
          t.g();
        } 
      } 
      throw new IllegalStateException(String.format("WorkContinuation has cycles (%s)", new Object[] { this.e }));
    } finally {
      Exception exception = null;
      this.f.a((v)new s(exception));
    } 
  }
}


/* Location:              C:\soft\dex2jar-2.0\Https Traffic-dex2jar.jar!\c\b0\f0\c0\e.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */