package c.b0.f0.c0.z;

public abstract class b {
  public b(a parama) {}
  
  public abstract boolean a(k<?> paramk, f paramf1, f paramf2);
  
  public abstract boolean b(k<?> paramk, Object paramObject1, Object paramObject2);
  
  public abstract boolean c(k<?> paramk, j paramj1, j paramj2);
  
  public abstract void d(j paramj1, j paramj2);
  
  public abstract void e(j paramj, Thread paramThread);
}


/* Location:              C:\soft\dex2jar-2.0\Https Traffic-dex2jar.jar!\c\b0\f0\c0\z\b.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */