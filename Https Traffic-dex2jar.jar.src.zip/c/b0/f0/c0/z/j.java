package c.b0.f0.c0.z;

public final class j {
  public static final j c = new j(false);
  
  public volatile Thread a;
  
  public volatile j b;
  
  public j() {
    k.j.e(this, Thread.currentThread());
  }
  
  public j(boolean paramBoolean) {}
}


/* Location:              C:\soft\dex2jar-2.0\Https Traffic-dex2jar.jar!\c\b0\f0\c0\z\j.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */