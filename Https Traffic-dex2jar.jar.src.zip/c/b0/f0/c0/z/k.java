package c.b0.f0.c0.z;

import d.a.a.a.a;
import d.c.c.d.a.a;
import java.util.Locale;
import java.util.Objects;
import java.util.concurrent.CancellationException;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.Executor;
import java.util.concurrent.Future;
import java.util.concurrent.ScheduledFuture;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.TimeoutException;
import java.util.concurrent.atomic.AtomicReferenceFieldUpdater;
import java.util.concurrent.locks.LockSupport;
import java.util.logging.Level;
import java.util.logging.Logger;

public abstract class k<V> implements a<V> {
  public static final boolean h = Boolean.parseBoolean(System.getProperty("guava.concurrent.generate_cancellation_cause", "false"));
  
  public static final Logger i = Logger.getLogger(k.class.getName());
  
  public static final b j;
  
  public static final Object k = new Object();
  
  public volatile Object e;
  
  public volatile f f;
  
  public volatile j g;
  
  public static void d(k<?> paramk) {
    k k2 = null;
    k<?> k1 = paramk;
    paramk = k2;
    label34: while (true) {
      j j1 = k1.g;
      if (j.c(k1, j1, j.c)) {
        while (j1 != null) {
          Thread thread = j1.a;
          if (thread != null) {
            j1.a = null;
            LockSupport.unpark(thread);
          } 
          j1 = j1.b;
        } 
        while (true) {
          f f1 = k1.f;
          if (j.a(k1, f1, f.d)) {
            f f2 = f1;
            while (true) {
              f1 = f2;
              k<?> k3 = paramk;
              if (f1 != null) {
                f2 = f1.c;
                f1.c = (f)paramk;
                f f3 = f1;
                continue;
              } 
              break;
            } 
            while (f2 != null) {
              k<V> k3;
              f f3 = f2.c;
              Runnable runnable = f2.a;
              if (runnable instanceof h) {
                runnable = runnable;
                k3 = ((h)runnable).e;
                if (k3.e == runnable) {
                  Object object = g(((h)runnable).f);
                  if (j.b(k3, runnable, object))
                    continue label34; 
                } 
              } else {
                e(runnable, ((f)k3).b);
              } 
              f f4 = f3;
            } 
            return;
          } 
        } 
        continue;
      } 
    } 
  }
  
  public static void e(Runnable paramRunnable, Executor paramExecutor) {
    try {
      paramExecutor.execute(paramRunnable);
      return;
    } catch (RuntimeException runtimeException) {
      Logger logger = i;
      Level level = Level.SEVERE;
      StringBuilder stringBuilder = new StringBuilder();
      stringBuilder.append("RuntimeException while executing runnable ");
      stringBuilder.append(paramRunnable);
      stringBuilder.append(" with executor ");
      stringBuilder.append(paramExecutor);
      logger.log(level, stringBuilder.toString(), runtimeException);
      return;
    } 
  }
  
  public static Object g(a<?> parama) {
    if (parama instanceof k) {
      Object object1 = ((k)parama).e;
      object = object1;
      if (object1 instanceof c) {
        c c = (c)object1;
        object = object1;
        if (c.a) {
          if (c.b != null)
            return new c(false, c.b); 
          object = c.d;
        } 
      } 
      return object;
    } 
    boolean bool = ((k)object).e instanceof c;
    if (((h ^ true) & bool) != 0)
      return c.d; 
    try {
      Object object2 = h((Future<Object>)object);
      Object object1 = object2;
      return object1;
    } catch (ExecutionException object) {
      return new e(object.getCause());
    } catch (CancellationException cancellationException) {
      return new c(false, cancellationException);
    } finally {
      object = null;
    } 
  }
  
  public static <V> V h(Future<V> paramFuture) {
    boolean bool = false;
    while (true) {
      try {
        return (V)((k)paramFuture).get();
      } catch (InterruptedException interruptedException) {
      
      } finally {
        if (bool)
          Thread.currentThread().interrupt(); 
      } 
    } 
  }
  
  public final void b(StringBuilder paramStringBuilder) {
    try {
      String str;
      k k1 = (k)h((Future<Object>)this);
      paramStringBuilder.append("SUCCESS, result=[");
      if (k1 == this) {
        str = "this future";
      } else {
        str = String.valueOf(str);
      } 
      paramStringBuilder.append(str);
      paramStringBuilder.append("]");
      return;
    } catch (ExecutionException executionException) {
      paramStringBuilder.append("FAILURE, cause=[");
      paramStringBuilder.append(executionException.getCause());
      paramStringBuilder.append("]");
      return;
    } catch (CancellationException cancellationException) {
      paramStringBuilder.append("CANCELLED");
      return;
    } catch (RuntimeException runtimeException) {
      paramStringBuilder.append("UNKNOWN, cause=[");
      paramStringBuilder.append(runtimeException.getClass());
      paramStringBuilder.append(" thrown from get()]");
      return;
    } 
  }
  
  public final void c(Runnable paramRunnable, Executor paramExecutor) {
    Objects.requireNonNull(paramExecutor);
    f f1 = this.f;
    if (f1 != f.d) {
      f f2;
      f f3 = new f(paramRunnable, paramExecutor);
      do {
        f3.c = f1;
        if (j.a(this, f1, f3))
          return; 
        f2 = this.f;
        f1 = f2;
      } while (f2 != f.d);
    } 
    e(paramRunnable, paramExecutor);
  }
  
  public final boolean cancel(boolean paramBoolean) {
    boolean bool;
    boolean bool1;
    Object object = this.e;
    boolean bool2 = true;
    if (object == null) {
      bool = true;
    } else {
      bool = false;
    } 
    if (bool | object instanceof h) {
      c c;
      if (h) {
        c = new c(paramBoolean, new CancellationException("Future.cancel() was called."));
      } else if (paramBoolean) {
        c = c.c;
      } else {
        c = c.d;
      } 
      k<?> k1 = this;
      bool1 = false;
      while (true) {
        while (j.b(k1, object, c)) {
          d(k1);
          bool1 = bool2;
          if (object instanceof h) {
            object = ((h)object).f;
            if (object instanceof k) {
              k1 = (k)object;
              object = k1.e;
              if (object == null) {
                bool = true;
              } else {
                bool = false;
              } 
              bool1 = bool2;
              if (bool | object instanceof h) {
                bool1 = true;
                continue;
              } 
            } else {
              ((k)object).cancel(paramBoolean);
              return true;
            } 
          } 
          return bool1;
        } 
        Object object1 = k1.e;
        object = object1;
        if (!(object1 instanceof h))
          return bool1; 
      } 
    } else {
      bool1 = false;
    } 
    return bool1;
  }
  
  public final V f(Object paramObject) {
    if (!(paramObject instanceof c)) {
      if (!(paramObject instanceof e)) {
        Object object = paramObject;
        if (paramObject == k)
          object = null; 
        return (V)object;
      } 
      throw new ExecutionException(((e)paramObject).a);
    } 
    paramObject = ((c)paramObject).b;
    CancellationException cancellationException = new CancellationException("Task was cancelled.");
    cancellationException.initCause((Throwable)paramObject);
    throw cancellationException;
  }
  
  public final V get() {
    if (!Thread.interrupted()) {
      boolean bool;
      Object object = this.e;
      if (object != null) {
        bool = true;
      } else {
        bool = false;
      } 
      if ((bool & (object instanceof h ^ true)) != 0)
        return f(object); 
      object = this.g;
      if (object != j.c) {
        j j1;
        j j2 = new j();
        do {
          b b1 = j;
          b1.d(j2, (j)object);
          if (b1.c(this, (j)object, j2))
            while (true) {
              LockSupport.park(this);
              if (!Thread.interrupted()) {
                object = this.e;
                if (object != null) {
                  bool = true;
                } else {
                  bool = false;
                } 
                if ((bool & (object instanceof h ^ true)) != 0)
                  return f(object); 
                continue;
              } 
              j(j2);
              throw new InterruptedException();
            }  
          j1 = this.g;
          object = j1;
        } while (j1 != j.c);
      } 
      return f(this.e);
    } 
    throw new InterruptedException();
  }
  
  public final V get(long paramLong, TimeUnit paramTimeUnit) {
    long l = paramTimeUnit.toNanos(paramLong);
    if (!Thread.interrupted()) {
      boolean bool1;
      long l2;
      Object object = this.e;
      boolean bool2 = true;
      if (object != null) {
        bool1 = true;
      } else {
        bool1 = false;
      } 
      if ((bool1 & (object instanceof h ^ true)) != 0)
        return f(object); 
      if (l > 0L) {
        l2 = System.nanoTime() + l;
      } else {
        l2 = 0L;
      } 
      long l1 = l;
      if (l >= 1000L) {
        object = this.g;
        if (object != j.c) {
          j j1 = new j();
          label74: while (true) {
            b b1 = j;
            b1.d(j1, (j)object);
            if (b1.c(this, (j)object, j1))
              while (true) {
                LockSupport.parkNanos(this, l);
                if (!Thread.interrupted()) {
                  object = this.e;
                  if (object != null) {
                    bool1 = true;
                  } else {
                    bool1 = false;
                  } 
                  if ((bool1 & (object instanceof h ^ true)) != 0)
                    return f(object); 
                  l1 = l2 - System.nanoTime();
                  l = l1;
                  if (l1 < 1000L) {
                    j(j1);
                    break;
                  } 
                  continue;
                } 
                j(j1);
                throw new InterruptedException();
              }  
            j j2 = this.g;
            object = j2;
            if (j2 == j.c)
              break label74; 
          } 
        } else {
          return f(this.e);
        } 
      } 
      while (l1 > 0L) {
        object = this.e;
        if (object != null) {
          bool1 = true;
        } else {
          bool1 = false;
        } 
        if ((bool1 & (object instanceof h ^ true)) != 0)
          return f(object); 
        if (!Thread.interrupted()) {
          l1 = l2 - System.nanoTime();
          continue;
        } 
        throw new InterruptedException();
      } 
      String str3 = toString();
      String str2 = paramTimeUnit.toString();
      object = Locale.ROOT;
      String str4 = str2.toLowerCase((Locale)object);
      StringBuilder stringBuilder = new StringBuilder();
      stringBuilder.append("Waited ");
      stringBuilder.append(paramLong);
      stringBuilder.append(" ");
      stringBuilder.append(paramTimeUnit.toString().toLowerCase((Locale)object));
      String str1 = stringBuilder.toString();
      object = str1;
      if (l1 + 1000L < 0L) {
        object = a.f(str1, " (plus ");
        l1 = -l1;
        paramLong = paramTimeUnit.convert(l1, TimeUnit.NANOSECONDS);
        l1 -= paramTimeUnit.toNanos(paramLong);
        int i = paramLong cmp 0L;
        bool1 = bool2;
        if (i != 0)
          if (l1 > 1000L) {
            bool1 = bool2;
          } else {
            bool1 = false;
          }  
        Object object1 = object;
        if (i > 0) {
          object1 = new StringBuilder();
          object1.append((String)object);
          object1.append(paramLong);
          object1.append(" ");
          object1.append(str4);
          object = object1.toString();
          object1 = object;
          if (bool1)
            object1 = a.f((String)object, ","); 
          object1 = a.f((String)object1, " ");
        } 
        object = object1;
        if (bool1) {
          object = new StringBuilder();
          object.append((String)object1);
          object.append(l1);
          object.append(" nanoseconds ");
          object = object.toString();
        } 
        object = a.f((String)object, "delay)");
      } 
      if (isDone())
        throw new TimeoutException(a.f(object, " but future completed as timeout expired")); 
      throw new TimeoutException(a.g(object, " for ", str3));
    } 
    throw new InterruptedException();
  }
  
  public String i() {
    Object object = this.e;
    if (object instanceof h) {
      StringBuilder stringBuilder = a.p("setFuture=[");
      object = ((h)object).f;
      if (object == this) {
        object = "this future";
      } else {
        object = String.valueOf(object);
      } 
      return a.h(stringBuilder, (String)object, "]");
    } 
    if (this instanceof ScheduledFuture) {
      object = a.p("remaining delay=[");
      object.append(((ScheduledFuture)this).getDelay(TimeUnit.MILLISECONDS));
      object.append(" ms]");
      return object.toString();
    } 
    return null;
  }
  
  public final boolean isCancelled() {
    return this.e instanceof c;
  }
  
  public final boolean isDone() {
    boolean bool;
    Object object = this.e;
    if (object != null) {
      bool = true;
    } else {
      bool = false;
    } 
    return (object instanceof h ^ true) & bool;
  }
  
  public final void j(j paramj) {
    paramj.a = null;
    label24: while (true) {
      paramj = this.g;
      if (paramj == j.c)
        return; 
      for (Object object = null; paramj != null; object = object1) {
        Object object1;
        j j1 = paramj.b;
        if (paramj.a != null) {
          object1 = paramj;
        } else if (object != null) {
          ((j)object).b = j1;
          object1 = object;
          if (((j)object).a == null)
            continue label24; 
        } else {
          object1 = object;
          if (!j.c(this, paramj, j1))
            continue label24; 
        } 
        paramj = j1;
      } 
      break;
    } 
  }
  
  public String toString() {
    StringBuilder stringBuilder = new StringBuilder();
    stringBuilder.append(super.toString());
    stringBuilder.append("[status=");
    if (this.e instanceof c) {
      stringBuilder.append("CANCELLED");
    } else if (isDone()) {
      b(stringBuilder);
    } else {
      String str;
      try {
        str = i();
      } catch (RuntimeException runtimeException) {
        StringBuilder stringBuilder1 = a.p("Exception thrown from implementation: ");
        stringBuilder1.append(runtimeException.getClass());
        str = stringBuilder1.toString();
      } 
      if (str != null && !str.isEmpty()) {
        stringBuilder.append("PENDING, info=[");
        stringBuilder.append(str);
        stringBuilder.append("]");
      } else if (isDone()) {
        b(stringBuilder);
      } else {
        stringBuilder.append("PENDING");
      } 
    } 
    stringBuilder.append("]");
    return stringBuilder.toString();
  }
  
  static {
    Exception exception;
    i i;
  }
  
  static {
    try {
      g g = new g(AtomicReferenceFieldUpdater.newUpdater(j.class, Thread.class, "a"), AtomicReferenceFieldUpdater.newUpdater(j.class, j.class, "b"), AtomicReferenceFieldUpdater.newUpdater(k.class, j.class, "g"), AtomicReferenceFieldUpdater.newUpdater(k.class, f.class, "f"), AtomicReferenceFieldUpdater.newUpdater(k.class, Object.class, "e"));
    } finally {
      exception = null;
    } 
    j = i;
    if (exception != null)
      i.log(Level.SEVERE, "SafeAtomicHelper is broken!", exception); 
  }
}


/* Location:              C:\soft\dex2jar-2.0\Https Traffic-dex2jar.jar!\c\b0\f0\c0\z\k.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */