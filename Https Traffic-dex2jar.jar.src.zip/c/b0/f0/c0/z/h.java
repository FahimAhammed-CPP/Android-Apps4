package c.b0.f0.c0.z;

import d.c.c.d.a.a;

public final class h<V> implements Runnable {
  public final k<V> e;
  
  public final a<? extends V> f;
  
  public h(k<V> paramk, a<? extends V> parama) {
    this.e = paramk;
    this.f = parama;
  }
  
  public void run() {
    if (this.e.e != this)
      return; 
    Object object = k.g(this.f);
    if (k.j.b(this.e, this, object))
      k.d(this.e); 
  }
}


/* Location:              C:\soft\dex2jar-2.0\Https Traffic-dex2jar.jar!\c\b0\f0\c0\z\h.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */