package c.b0.f0.c0;

import androidx.work.impl.WorkDatabase;
import c.b0.f0.c0.a0.a;
import c.b0.o;
import c.b0.y;

public class u implements y {
  public static final String c = o.e("WorkProgressUpdater");
  
  public final WorkDatabase a;
  
  public final a b;
  
  public u(WorkDatabase paramWorkDatabase, a parama) {
    this.a = paramWorkDatabase;
    this.b = parama;
  }
}


/* Location:              C:\soft\dex2jar-2.0\Https Traffic-dex2jar.jar!\c\b0\f0\c\\u.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */