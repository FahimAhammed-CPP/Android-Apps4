package c.b0.f0.c0;

import android.content.Context;
import android.os.PowerManager;
import c.b0.o;
import d.a.a.a.a;
import java.util.WeakHashMap;

public abstract class n {
  public static final String a = o.e("WakeLocks");
  
  public static final WeakHashMap<PowerManager.WakeLock, String> b = new WeakHashMap<PowerManager.WakeLock, String>();
  
  public static PowerManager.WakeLock a(Context paramContext, String paramString) {
    PowerManager powerManager = (PowerManager)paramContext.getApplicationContext().getSystemService("power");
    null = a.f("WorkManager: ", paramString);
    PowerManager.WakeLock wakeLock = powerManager.newWakeLock(1, null);
    synchronized (b) {
      null.put(wakeLock, null);
      return wakeLock;
    } 
  }
}


/* Location:              C:\soft\dex2jar-2.0\Https Traffic-dex2jar.jar!\c\b0\f0\c0\n.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */