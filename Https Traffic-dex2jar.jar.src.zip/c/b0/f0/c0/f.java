package c.b0.f0.c0;

import androidx.work.impl.WorkDatabase;
import c.b0.f0.b0.d;

public class f {
  public final WorkDatabase a;
  
  public f(WorkDatabase paramWorkDatabase) {
    this.a = paramWorkDatabase;
  }
  
  public final int a(String paramString) {
    byte b;
    int i;
    this.a.c();
    try {
      Long long_ = this.a.m().a(paramString);
      i = 0;
    } finally {
      this.a.g();
    } 
    if (b != Integer.MAX_VALUE)
      i = b + 1; 
    this.a.m().b(new d(paramString, i));
    this.a.k();
    this.a.g();
    return b;
  }
  
  public int b(int paramInt1, int paramInt2) {
    // Byte code:
    //   0: ldc c/b0/f0/c0/f
    //   2: monitorenter
    //   3: aload_0
    //   4: ldc 'next_job_scheduler_id'
    //   6: invokevirtual a : (Ljava/lang/String;)I
    //   9: istore_3
    //   10: iload_3
    //   11: iload_1
    //   12: if_icmplt -> 23
    //   15: iload_3
    //   16: iload_2
    //   17: if_icmple -> 59
    //   20: goto -> 23
    //   23: aload_0
    //   24: getfield a : Landroidx/work/impl/WorkDatabase;
    //   27: invokevirtual m : ()Lc/b0/f0/b0/f;
    //   30: new c/b0/f0/b0/d
    //   33: dup
    //   34: ldc 'next_job_scheduler_id'
    //   36: iload_1
    //   37: iconst_1
    //   38: iadd
    //   39: i2l
    //   40: invokespecial <init> : (Ljava/lang/String;J)V
    //   43: invokevirtual b : (Lc/b0/f0/b0/d;)V
    //   46: ldc c/b0/f0/c0/f
    //   48: monitorexit
    //   49: iload_1
    //   50: ireturn
    //   51: astore #4
    //   53: ldc c/b0/f0/c0/f
    //   55: monitorexit
    //   56: aload #4
    //   58: athrow
    //   59: iload_3
    //   60: istore_1
    //   61: goto -> 46
    // Exception table:
    //   from	to	target	type
    //   3	10	51	finally
    //   23	46	51	finally
    //   46	49	51	finally
    //   53	56	51	finally
  }
}


/* Location:              C:\soft\dex2jar-2.0\Https Traffic-dex2jar.jar!\c\b0\f0\c0\f.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */