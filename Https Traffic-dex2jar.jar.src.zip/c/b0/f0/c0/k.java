package c.b0.f0.c0;

import java.util.ArrayDeque;
import java.util.concurrent.Executor;

public class k implements Executor {
  public final ArrayDeque<j> e;
  
  public final Executor f;
  
  public final Object g;
  
  public volatile Runnable h;
  
  public k(Executor paramExecutor) {
    this.f = paramExecutor;
    this.e = new ArrayDeque<j>();
    this.g = new Object();
  }
  
  public void a() {
    synchronized (this.g) {
      Runnable runnable = this.e.poll();
      this.h = runnable;
      if (runnable != null)
        this.f.execute(this.h); 
      return;
    } 
  }
  
  public void execute(Runnable paramRunnable) {
    synchronized (this.g) {
      this.e.add(new j(this, paramRunnable));
      if (this.h == null)
        a(); 
      return;
    } 
  }
}


/* Location:              C:\soft\dex2jar-2.0\Https Traffic-dex2jar.jar!\c\b0\f0\c0\k.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */