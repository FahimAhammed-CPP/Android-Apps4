package c.b0.f0.c0;

import androidx.work.impl.WorkDatabase;
import c.b0.f0.b0.c0;
import c.b0.f0.e;
import c.b0.f0.t;
import c.b0.o;

public class m implements Runnable {
  public static final String h = o.e("StopWorkRunnable");
  
  public final t e;
  
  public final String f;
  
  public final boolean g;
  
  public m(t paramt, String paramString, boolean paramBoolean) {
    this.e = paramt;
    this.f = paramString;
    this.g = paramBoolean;
  }
  
  public void run() {
    null = this.e;
    WorkDatabase workDatabase = null.c;
    e e = null.f;
    c0 c0 = workDatabase.q();
    workDatabase.c();
    try {
      String str = this.f;
    } finally {
      workDatabase.g();
    } 
  }
}


/* Location:              C:\soft\dex2jar-2.0\Https Traffic-dex2jar.jar!\c\b0\f0\c0\m.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */