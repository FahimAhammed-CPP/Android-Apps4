package c.b0.f0.c0;

import c.b0.f0.c;
import c.b0.f0.g;
import c.b0.f0.t;
import c.b0.s;
import c.b0.v;

public abstract class d implements Runnable {
  public final c e = new c();
  
  public void a(t paramt, String paramString) {
    // Byte code:
    //   0: aload_1
    //   1: getfield c : Landroidx/work/impl/WorkDatabase;
    //   4: astore #6
    //   6: aload #6
    //   8: invokevirtual q : ()Lc/b0/f0/b0/c0;
    //   11: astore #5
    //   13: aload #6
    //   15: invokevirtual l : ()Lc/b0/f0/b0/c;
    //   18: astore #6
    //   20: new java/util/LinkedList
    //   23: dup
    //   24: invokespecial <init> : ()V
    //   27: astore #7
    //   29: aload #7
    //   31: aload_2
    //   32: invokevirtual add : (Ljava/lang/Object;)Z
    //   35: pop
    //   36: aload #7
    //   38: invokevirtual isEmpty : ()Z
    //   41: istore #4
    //   43: iconst_0
    //   44: istore_3
    //   45: iload #4
    //   47: ifne -> 119
    //   50: aload #7
    //   52: invokevirtual remove : ()Ljava/lang/Object;
    //   55: checkcast java/lang/String
    //   58: astore #8
    //   60: aload #5
    //   62: aload #8
    //   64: invokevirtual f : (Ljava/lang/String;)Lc/b0/a0;
    //   67: astore #9
    //   69: aload #9
    //   71: getstatic c/b0/a0.g : Lc/b0/a0;
    //   74: if_acmpeq -> 103
    //   77: aload #9
    //   79: getstatic c/b0/a0.h : Lc/b0/a0;
    //   82: if_acmpeq -> 103
    //   85: aload #5
    //   87: getstatic c/b0/a0.j : Lc/b0/a0;
    //   90: iconst_1
    //   91: anewarray java/lang/String
    //   94: dup
    //   95: iconst_0
    //   96: aload #8
    //   98: aastore
    //   99: invokevirtual p : (Lc/b0/a0;[Ljava/lang/String;)I
    //   102: pop
    //   103: aload #7
    //   105: aload #6
    //   107: aload #8
    //   109: invokevirtual a : (Ljava/lang/String;)Ljava/util/List;
    //   112: invokevirtual addAll : (Ljava/util/Collection;)Z
    //   115: pop
    //   116: goto -> 36
    //   119: aload_1
    //   120: getfield f : Lc/b0/f0/e;
    //   123: astore #8
    //   125: aload #8
    //   127: getfield o : Ljava/lang/Object;
    //   130: astore #7
    //   132: aload #7
    //   134: monitorenter
    //   135: invokestatic c : ()Lc/b0/o;
    //   138: getstatic c/b0/f0/e.p : Ljava/lang/String;
    //   141: ldc 'Processor cancelling %s'
    //   143: iconst_1
    //   144: anewarray java/lang/Object
    //   147: dup
    //   148: iconst_0
    //   149: aload_2
    //   150: aastore
    //   151: invokestatic format : (Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/String;
    //   154: iconst_0
    //   155: anewarray java/lang/Throwable
    //   158: invokevirtual a : (Ljava/lang/String;Ljava/lang/String;[Ljava/lang/Throwable;)V
    //   161: aload #8
    //   163: getfield m : Ljava/util/Set;
    //   166: aload_2
    //   167: invokeinterface add : (Ljava/lang/Object;)Z
    //   172: pop
    //   173: aload #8
    //   175: getfield j : Ljava/util/Map;
    //   178: aload_2
    //   179: invokeinterface remove : (Ljava/lang/Object;)Ljava/lang/Object;
    //   184: checkcast c/b0/f0/x
    //   187: astore #6
    //   189: aload #6
    //   191: ifnull -> 196
    //   194: iconst_1
    //   195: istore_3
    //   196: aload #6
    //   198: astore #5
    //   200: aload #6
    //   202: ifnonnull -> 221
    //   205: aload #8
    //   207: getfield k : Ljava/util/Map;
    //   210: aload_2
    //   211: invokeinterface remove : (Ljava/lang/Object;)Ljava/lang/Object;
    //   216: checkcast c/b0/f0/x
    //   219: astore #5
    //   221: aload_2
    //   222: aload #5
    //   224: invokestatic c : (Ljava/lang/String;Lc/b0/f0/x;)Z
    //   227: pop
    //   228: iload_3
    //   229: ifeq -> 237
    //   232: aload #8
    //   234: invokevirtual h : ()V
    //   237: aload #7
    //   239: monitorexit
    //   240: aload_1
    //   241: getfield e : Ljava/util/List;
    //   244: invokeinterface iterator : ()Ljava/util/Iterator;
    //   249: astore_1
    //   250: aload_1
    //   251: invokeinterface hasNext : ()Z
    //   256: ifeq -> 277
    //   259: aload_1
    //   260: invokeinterface next : ()Ljava/lang/Object;
    //   265: checkcast c/b0/f0/f
    //   268: aload_2
    //   269: invokeinterface b : (Ljava/lang/String;)V
    //   274: goto -> 250
    //   277: return
    //   278: astore_1
    //   279: aload #7
    //   281: monitorexit
    //   282: aload_1
    //   283: athrow
    // Exception table:
    //   from	to	target	type
    //   135	189	278	finally
    //   205	221	278	finally
    //   221	228	278	finally
    //   232	237	278	finally
    //   237	240	278	finally
    //   279	282	278	finally
  }
  
  public void b(t paramt) {
    g.a(paramt.b, paramt.c, paramt.e);
  }
  
  public abstract void c();
  
  public void run() {
    try {
      return;
    } finally {
      Exception exception = null;
      this.e.a((v)new s(exception));
    } 
  }
}


/* Location:              C:\soft\dex2jar-2.0\Https Traffic-dex2jar.jar!\c\b0\f0\c0\d.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */