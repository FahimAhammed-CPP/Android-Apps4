package c.b0.f0.b0;

public class d0 {
  public final String a;
  
  public final String b;
  
  public d0(String paramString1, String paramString2) {
    this.a = paramString1;
    this.b = paramString2;
  }
}


/* Location:              C:\soft\dex2jar-2.0\Https Traffic-dex2jar.jar!\c\b0\f0\b0\d0.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */