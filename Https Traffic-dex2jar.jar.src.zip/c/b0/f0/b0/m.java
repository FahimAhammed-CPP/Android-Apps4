package c.b0.f0.b0;

import c.u.b;
import c.u.l;

public final class m {
  public final l a;
  
  public final b<k> b;
  
  public m(l paraml) {
    this.a = paraml;
    this.b = new l(this, paraml);
  }
}


/* Location:              C:\soft\dex2jar-2.0\Https Traffic-dex2jar.jar!\c\b0\f0\b0\m.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */