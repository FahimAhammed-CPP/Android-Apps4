package c.b0.f0.b0;

import c.u.l;
import c.u.s;

public class q extends s {
  public q(r paramr, l paraml) {
    super(paraml);
  }
  
  public String b() {
    return "DELETE FROM WorkProgress";
  }
}


/* Location:              C:\soft\dex2jar-2.0\Https Traffic-dex2jar.jar!\c\b0\f0\b0\q.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */