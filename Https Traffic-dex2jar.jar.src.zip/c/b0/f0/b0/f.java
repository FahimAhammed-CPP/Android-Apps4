package c.b0.f0.b0;

import android.database.Cursor;
import c.u.b;
import c.u.l;
import c.u.q;
import c.u.u.a;
import c.w.a.e;

public final class f {
  public final l a;
  
  public final b<d> b;
  
  public f(l paraml) {
    this.a = paraml;
    this.b = new e(this, paraml);
  }
  
  public Long a(String paramString) {
    q q = q.d("SELECT long_value FROM Preference where `key`=?", 1);
    if (paramString == null) {
      q.f(1);
    } else {
      q.g(1, paramString);
    } 
    this.a.b();
    null = this.a;
    l l1 = null;
    Cursor cursor = a.a(null, (e)q, false, null);
    null = l1;
    try {
      Long long_;
      if (cursor.moveToFirst())
        if (cursor.isNull(0)) {
          null = l1;
        } else {
          long_ = Long.valueOf(cursor.getLong(0));
        }  
      return long_;
    } finally {
      cursor.close();
      q.h();
    } 
  }
  
  public void b(d paramd) {
    this.a.b();
    this.a.c();
    try {
      this.b.e(paramd);
      this.a.k();
      return;
    } finally {
      this.a.g();
    } 
  }
}


/* Location:              C:\soft\dex2jar-2.0\Https Traffic-dex2jar.jar!\c\b0\f0\b0\f.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */