package c.b0.f0.b0;

import c.b0.g;
import c.u.b;
import c.u.l;
import c.w.a.f.h;
import c.w.a.f.i;

public class o extends b<n> {
  public o(r paramr, l paraml) {
    super(paraml);
  }
  
  public String b() {
    return "INSERT OR REPLACE INTO `WorkProgress` (`work_spec_id`,`progress`) VALUES (?,?)";
  }
  
  public void d(i parami, Object paramObject) {
    paramObject = paramObject;
    String str = ((n)paramObject).a;
    if (str == null) {
      ((h)parami).e.bindNull(1);
    } else {
      ((h)parami).e.bindString(1, str);
    } 
    paramObject = g.c(((n)paramObject).b);
    if (paramObject == null) {
      ((h)parami).e.bindNull(2);
      return;
    } 
    ((h)parami).e.bindBlob(2, (byte[])paramObject);
  }
}


/* Location:              C:\soft\dex2jar-2.0\Https Traffic-dex2jar.jar!\c\b0\f0\b0\o.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */