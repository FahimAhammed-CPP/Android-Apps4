package c.b0.f0.b0;

import android.database.Cursor;
import c.h.b.h;
import c.u.b;
import c.u.l;
import c.u.q;
import c.u.s;
import c.u.u.a;
import c.w.a.e;
import c.w.a.f.h;
import c.w.a.f.i;

public final class j {
  public final l a;
  
  public final b<g> b;
  
  public final s c;
  
  public j(l paraml) {
    this.a = paraml;
    this.b = new h(this, paraml);
    this.c = new i(this, paraml);
  }
  
  public g a(String paramString) {
    q q = q.d("SELECT `SystemIdInfo`.`work_spec_id` AS `work_spec_id`, `SystemIdInfo`.`system_id` AS `system_id` FROM SystemIdInfo WHERE work_spec_id=?", 1);
    if (paramString == null) {
      q.f(1);
    } else {
      q.g(1, paramString);
    } 
    this.a.b();
    l l1 = this.a;
    paramString = null;
    Cursor cursor = a.a(l1, (e)q, false, null);
    try {
      g g;
      int i = h.x(cursor, "work_spec_id");
      int k = h.x(cursor, "system_id");
      if (cursor.moveToFirst())
        g = new g(cursor.getString(i), cursor.getInt(k)); 
      return g;
    } finally {
      cursor.close();
      q.h();
    } 
  }
  
  public void b(g paramg) {
    this.a.b();
    this.a.c();
    try {
      this.b.e(paramg);
      this.a.k();
      return;
    } finally {
      this.a.g();
    } 
  }
  
  public void c(String paramString) {
    this.a.b();
    i i = this.c.a();
    if (paramString == null) {
      ((h)i).e.bindNull(1);
    } else {
      ((h)i).e.bindString(1, paramString);
    } 
    this.a.c();
    try {
      i.a();
      this.a.k();
      this.a.g();
      return;
    } finally {
      this.a.g();
      this.c.c(i);
    } 
  }
}


/* Location:              C:\soft\dex2jar-2.0\Https Traffic-dex2jar.jar!\c\b0\f0\b0\j.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */