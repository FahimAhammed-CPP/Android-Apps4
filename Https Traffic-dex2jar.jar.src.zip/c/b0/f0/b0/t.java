package c.b0.f0.b0;

import c.b0.a;
import c.b0.a0;
import c.b0.d;
import c.b0.g;
import c.b0.o;
import c.b0.x;
import d.a.a.a.a;

public final class t {
  public String a;
  
  public a0 b = a0.e;
  
  public String c;
  
  public String d;
  
  public g e;
  
  public g f;
  
  public long g;
  
  public long h;
  
  public long i;
  
  public d j;
  
  public int k;
  
  public a l;
  
  public long m;
  
  public long n;
  
  public long o;
  
  public long p;
  
  public boolean q;
  
  public x r;
  
  static {
    o.e("WorkSpec");
  }
  
  public t(t paramt) {
    g g1 = g.c;
    this.e = g1;
    this.f = g1;
    this.j = d.i;
    this.l = a.e;
    this.m = 30000L;
    this.p = -1L;
    this.r = x.e;
    this.a = paramt.a;
    this.c = paramt.c;
    this.b = paramt.b;
    this.d = paramt.d;
    this.e = new g(paramt.e);
    this.f = new g(paramt.f);
    this.g = paramt.g;
    this.h = paramt.h;
    this.i = paramt.i;
    this.j = new d(paramt.j);
    this.k = paramt.k;
    this.l = paramt.l;
    this.m = paramt.m;
    this.n = paramt.n;
    this.o = paramt.o;
    this.p = paramt.p;
    this.q = paramt.q;
    this.r = paramt.r;
  }
  
  public t(String paramString1, String paramString2) {
    g g1 = g.c;
    this.e = g1;
    this.f = g1;
    this.j = d.i;
    this.l = a.e;
    this.m = 30000L;
    this.p = -1L;
    this.r = x.e;
    this.a = paramString1;
    this.c = paramString2;
  }
  
  public long a() {
    int i;
    a0 a01 = this.b;
    a0 a02 = a0.e;
    boolean bool = false;
    int j = 0;
    if (a01 == a02 && this.k > 0) {
      i = 1;
    } else {
      i = 0;
    } 
    if (i) {
      i = j;
      if (this.l == a.f)
        i = 1; 
      if (i) {
        l3 = this.m * this.k;
      } else {
        l3 = (long)Math.scalb((float)this.m, this.k - 1);
      } 
      long l4 = this.n;
      long l3 = Math.min(18000000L, l3);
      return l3 + l4;
    } 
    boolean bool1 = c();
    long l2 = 0L;
    if (bool1) {
      long l4 = System.currentTimeMillis();
      long l3 = this.n;
      j = l3 cmp 0L;
      if (j == 0)
        l3 = this.g + l4; 
      long l5 = this.i;
      l4 = this.h;
      i = bool;
      if (l5 != l4)
        i = 1; 
      if (i != 0) {
        if (j == 0)
          l2 = l5 * -1L; 
        return l3 + l4 + l2;
      } 
      if (j != 0)
        l2 = l4; 
      return l3 + l2;
    } 
    l2 = this.n;
    long l1 = l2;
    if (l2 == 0L)
      l1 = System.currentTimeMillis(); 
    l2 = this.g;
    return l1 + l2;
  }
  
  public boolean b() {
    return d.i.equals(this.j) ^ true;
  }
  
  public boolean c() {
    return (this.h != 0L);
  }
  
  public boolean equals(Object paramObject) {
    if (this == paramObject)
      return true; 
    if (paramObject != null) {
      if (t.class != paramObject.getClass())
        return false; 
      paramObject = paramObject;
      if (this.g != ((t)paramObject).g)
        return false; 
      if (this.h != ((t)paramObject).h)
        return false; 
      if (this.i != ((t)paramObject).i)
        return false; 
      if (this.k != ((t)paramObject).k)
        return false; 
      if (this.m != ((t)paramObject).m)
        return false; 
      if (this.n != ((t)paramObject).n)
        return false; 
      if (this.o != ((t)paramObject).o)
        return false; 
      if (this.p != ((t)paramObject).p)
        return false; 
      if (this.q != ((t)paramObject).q)
        return false; 
      if (!this.a.equals(((t)paramObject).a))
        return false; 
      if (this.b != ((t)paramObject).b)
        return false; 
      if (!this.c.equals(((t)paramObject).c))
        return false; 
      String str = this.d;
      if (str != null) {
        if (!str.equals(((t)paramObject).d))
          return false; 
      } else if (((t)paramObject).d != null) {
        return false;
      } 
      return !this.e.equals(((t)paramObject).e) ? false : (!this.f.equals(((t)paramObject).f) ? false : (!this.j.equals(((t)paramObject).j) ? false : ((this.l != ((t)paramObject).l) ? false : ((this.r == ((t)paramObject).r)))));
    } 
    return false;
  }
  
  public int hashCode() {
    throw new RuntimeException("d2j fail translate: java.lang.RuntimeException: can not merge I and Z\r\n\tat com.googlecode.dex2jar.ir.TypeClass.merge(TypeClass.java:100)\r\n\tat com.googlecode.dex2jar.ir.ts.TypeTransformer$TypeRef.updateTypeClass(TypeTransformer.java:174)\r\n\tat com.googlecode.dex2jar.ir.ts.TypeTransformer$TypeAnalyze.copyTypes(TypeTransformer.java:311)\r\n\tat com.googlecode.dex2jar.ir.ts.TypeTransformer$TypeAnalyze.fixTypes(TypeTransformer.java:226)\r\n\tat com.googlecode.dex2jar.ir.ts.TypeTransformer$TypeAnalyze.analyze(TypeTransformer.java:207)\r\n\tat com.googlecode.dex2jar.ir.ts.TypeTransformer.transform(TypeTransformer.java:44)\r\n\tat com.googlecode.d2j.dex.Dex2jar$2.optimize(Dex2jar.java:162)\r\n\tat com.googlecode.d2j.dex.Dex2Asm.convertCode(Dex2Asm.java:414)\r\n\tat com.googlecode.d2j.dex.ExDex2Asm.convertCode(ExDex2Asm.java:42)\r\n\tat com.googlecode.d2j.dex.Dex2jar$2.convertCode(Dex2jar.java:128)\r\n\tat com.googlecode.d2j.dex.Dex2Asm.convertMethod(Dex2Asm.java:509)\r\n\tat com.googlecode.d2j.dex.Dex2Asm.convertClass(Dex2Asm.java:406)\r\n\tat com.googlecode.d2j.dex.Dex2Asm.convertDex(Dex2Asm.java:422)\r\n\tat com.googlecode.d2j.dex.Dex2jar.doTranslate(Dex2jar.java:172)\r\n\tat com.googlecode.d2j.dex.Dex2jar.to(Dex2jar.java:272)\r\n\tat com.googlecode.dex2jar.tools.Dex2jarCmd.doCommandLine(Dex2jarCmd.java:108)\r\n\tat com.googlecode.dex2jar.tools.BaseCmd.doMain(BaseCmd.java:288)\r\n\tat com.googlecode.dex2jar.tools.Dex2jarCmd.main(Dex2jarCmd.java:32)\r\n");
  }
  
  public String toString() {
    return a.h(a.p("{WorkSpec: "), this.a, "}");
  }
}


/* Location:              C:\soft\dex2jar-2.0\Https Traffic-dex2jar.jar!\c\b0\f0\b0\t.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */