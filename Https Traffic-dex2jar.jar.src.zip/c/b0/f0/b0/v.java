package c.b0.f0.b0;

import c.u.l;
import c.u.s;

public class v extends s {
  public v(c0 paramc0, l paraml) {
    super(paraml);
  }
  
  public String b() {
    return "DELETE FROM workspec WHERE id=?";
  }
}


/* Location:              C:\soft\dex2jar-2.0\Https Traffic-dex2jar.jar!\c\b0\f0\b0\v.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */