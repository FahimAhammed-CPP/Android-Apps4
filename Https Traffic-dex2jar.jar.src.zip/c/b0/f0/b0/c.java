package c.b0.f0.b0;

import android.database.Cursor;
import c.u.b;
import c.u.l;
import c.u.q;
import c.u.u.a;
import c.w.a.e;
import java.util.ArrayList;
import java.util.List;

public final class c {
  public final l a;
  
  public final b<a> b;
  
  public c(l paraml) {
    this.a = paraml;
    this.b = new b(this, paraml);
  }
  
  public List<String> a(String paramString) {
    q q = q.d("SELECT work_spec_id FROM dependency WHERE prerequisite_id=?", 1);
    if (paramString == null) {
      q.f(1);
    } else {
      q.g(1, paramString);
    } 
    this.a.b();
    Cursor cursor = a.a(this.a, (e)q, false, null);
    try {
      ArrayList<String> arrayList = new ArrayList(cursor.getCount());
      while (cursor.moveToNext())
        arrayList.add(cursor.getString(0)); 
      return arrayList;
    } finally {
      cursor.close();
      q.h();
    } 
  }
  
  public boolean b(String paramString) {
    boolean bool2 = true;
    q q = q.d("SELECT COUNT(*)=0 FROM dependency WHERE work_spec_id=? AND prerequisite_id IN (SELECT id FROM workspec WHERE state!=2)", 1);
    if (paramString == null) {
      q.f(1);
    } else {
      q.g(1, paramString);
    } 
    this.a.b();
    l l1 = this.a;
    boolean bool1 = false;
    Cursor cursor = a.a(l1, (e)q, false, null);
    try {
      if (cursor.moveToFirst()) {
        int i = cursor.getInt(0);
        if (i != 0) {
          bool1 = bool2;
        } else {
          bool1 = false;
        } 
      } 
      return bool1;
    } finally {
      cursor.close();
      q.h();
    } 
  }
}


/* Location:              C:\soft\dex2jar-2.0\Https Traffic-dex2jar.jar!\c\b0\f0\b0\c.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */