package c.b0.f0.b0;

import c.u.l;
import c.u.s;

public class w extends s {
  public w(c0 paramc0, l paraml) {
    super(paraml);
  }
  
  public String b() {
    return "UPDATE workspec SET output=? WHERE id=?";
  }
}


/* Location:              C:\soft\dex2jar-2.0\Https Traffic-dex2jar.jar!\c\b0\f0\b0\w.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */