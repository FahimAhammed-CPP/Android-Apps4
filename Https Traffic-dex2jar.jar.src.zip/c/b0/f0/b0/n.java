package c.b0.f0.b0;

import c.b0.g;

public class n {
  public final String a;
  
  public final g b;
  
  public n(String paramString, g paramg) {
    this.a = paramString;
    this.b = paramg;
  }
}


/* Location:              C:\soft\dex2jar-2.0\Https Traffic-dex2jar.jar!\c\b0\f0\b0\n.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */