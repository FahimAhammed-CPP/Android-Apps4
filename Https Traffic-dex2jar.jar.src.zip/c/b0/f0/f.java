package c.b0.f0;

import c.b0.f0.b0.t;

public interface f {
  void b(String paramString);
  
  void c(t... paramVarArgs);
  
  boolean f();
}


/* Location:              C:\soft\dex2jar-2.0\Https Traffic-dex2jar.jar!\c\b0\f0\f.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */