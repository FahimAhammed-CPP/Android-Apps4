package c.b0.f0.z.d;

import android.content.Context;
import android.os.Build;
import c.b0.f0.b0.t;
import c.b0.f0.c0.a0.a;
import c.b0.f0.z.a;
import c.b0.f0.z.e.f;
import c.b0.f0.z.e.i;
import c.b0.p;

public class h extends d<a> {
  public h(Context paramContext, a parama) {
    super((f<a>)(i.a(paramContext, parama)).c);
  }
  
  public boolean a(t paramt) {
    p p = paramt.j.a;
    return (p == p.g || (Build.VERSION.SDK_INT >= 30 && p == p.j));
  }
  
  public boolean b(Object paramObject) {
    paramObject = paramObject;
    return (!((a)paramObject).a || ((a)paramObject).c);
  }
}


/* Location:              C:\soft\dex2jar-2.0\Https Traffic-dex2jar.jar!\c\b0\f0\z\d\h.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */