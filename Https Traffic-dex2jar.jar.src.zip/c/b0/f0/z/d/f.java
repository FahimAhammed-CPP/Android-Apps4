package c.b0.f0.z.d;

import android.content.Context;
import android.os.Build;
import c.b0.f0.b0.t;
import c.b0.f0.c0.a0.a;
import c.b0.f0.z.a;
import c.b0.f0.z.e.i;
import c.b0.o;
import c.b0.p;

public class f extends d<a> {
  public static final String e = o.e("NetworkMeteredCtrlr");
  
  public f(Context paramContext, a parama) {
    super((c.b0.f0.z.e.f<a>)(i.a(paramContext, parama)).c);
  }
  
  public boolean a(t paramt) {
    return (paramt.j.a == p.i);
  }
  
  public boolean b(Object paramObject) {
    paramObject = paramObject;
    int i = Build.VERSION.SDK_INT;
    boolean bool2 = true;
    if (i < 26) {
      o.c().a(e, "Metered network constraint is not supported before API 26, only checking for connected state.", new Throwable[0]);
      return ((a)paramObject).a ^ true;
    } 
    boolean bool1 = bool2;
    if (((a)paramObject).a)
      if (!((a)paramObject).c) {
        bool1 = bool2;
      } else {
        bool1 = false;
      }  
    return bool1;
  }
}


/* Location:              C:\soft\dex2jar-2.0\Https Traffic-dex2jar.jar!\c\b0\f0\z\d\f.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */