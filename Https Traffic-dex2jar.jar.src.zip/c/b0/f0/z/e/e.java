package c.b0.f0.z.e;

import c.b0.f0.z.d.d;
import java.util.List;

public class e implements Runnable {
  public e(f paramf, List paramList) {}
  
  public void run() {
    for (d d : this.e) {
      T t = this.f.e;
      d.b = t;
      d.d(d.d, t);
    } 
  }
}


/* Location:              C:\soft\dex2jar-2.0\Https Traffic-dex2jar.jar!\c\b0\f0\z\e\e.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */