package c.b0.f0.z.e;

import android.content.Context;
import c.b0.f0.c0.a0.a;
import c.b0.f0.c0.a0.c;
import c.b0.f0.z.d.d;
import c.b0.o;
import java.util.ArrayList;
import java.util.LinkedHashSet;
import java.util.Set;

public abstract class f<T> {
  public static final String f = o.e("ConstraintTracker");
  
  public final a a;
  
  public final Context b;
  
  public final Object c = new Object();
  
  public final Set<d<T>> d = new LinkedHashSet<d<T>>();
  
  public T e;
  
  public f(Context paramContext, a parama) {
    this.b = paramContext.getApplicationContext();
    this.a = parama;
  }
  
  public abstract T a();
  
  public void b(d<T> paramd) {
    synchronized (this.c) {
      if (this.d.remove(paramd) && this.d.isEmpty())
        e(); 
      return;
    } 
  }
  
  public void c(T paramT) {
    synchronized (this.c) {
      T t = this.e;
      if (t == paramT || (t != null && t.equals(paramT)))
        return; 
      this.e = paramT;
      ArrayList<d<T>> arrayList = new ArrayList<d<T>>(this.d);
      ((c)this.a).c.execute(new e(this, arrayList));
      return;
    } 
  }
  
  public abstract void d();
  
  public abstract void e();
}


/* Location:              C:\soft\dex2jar-2.0\Https Traffic-dex2jar.jar!\c\b0\f0\z\e\f.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */