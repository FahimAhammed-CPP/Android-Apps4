package c.b0.f0.z.e;

import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import c.b0.f0.c0.a0.a;
import c.b0.o;

public class h extends d<Boolean> {
  public static final String i = o.e("StorageNotLowTracker");
  
  public h(Context paramContext, a parama) {
    super(paramContext, parama);
  }
  
  public Object a() {
    Context context = this.b;
    IntentFilter intentFilter = new IntentFilter();
    intentFilter.addAction("android.intent.action.DEVICE_STORAGE_OK");
    intentFilter.addAction("android.intent.action.DEVICE_STORAGE_LOW");
    Intent intent = context.registerReceiver(null, intentFilter);
    if (intent == null || intent.getAction() == null)
      return Boolean.TRUE; 
    String str = intent.getAction();
    str.hashCode();
    return !str.equals("android.intent.action.DEVICE_STORAGE_LOW") ? (!str.equals("android.intent.action.DEVICE_STORAGE_OK") ? null : Boolean.TRUE) : Boolean.FALSE;
  }
  
  public IntentFilter f() {
    IntentFilter intentFilter = new IntentFilter();
    intentFilter.addAction("android.intent.action.DEVICE_STORAGE_OK");
    intentFilter.addAction("android.intent.action.DEVICE_STORAGE_LOW");
    return intentFilter;
  }
  
  public void g(Context paramContext, Intent paramIntent) {
    if (paramIntent.getAction() == null)
      return; 
    o.c().a(i, String.format("Received %s", new Object[] { paramIntent.getAction() }), new Throwable[0]);
    String str = paramIntent.getAction();
    str.hashCode();
    if (!str.equals("android.intent.action.DEVICE_STORAGE_LOW")) {
      if (!str.equals("android.intent.action.DEVICE_STORAGE_OK"))
        return; 
      c((T)Boolean.TRUE);
      return;
    } 
    c((T)Boolean.FALSE);
  }
}


/* Location:              C:\soft\dex2jar-2.0\Https Traffic-dex2jar.jar!\c\b0\f0\z\e\h.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */