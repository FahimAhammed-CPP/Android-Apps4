package c.b0.f0.z.e;

import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import c.b0.f0.c0.a0.a;
import c.b0.o;

public class b extends d<Boolean> {
  public static final String i = o.e("BatteryNotLowTracker");
  
  public b(Context paramContext, a parama) {
    super(paramContext, parama);
  }
  
  public Object a() {
    IntentFilter intentFilter = new IntentFilter("android.intent.action.BATTERY_CHANGED");
    Intent intent = this.b.registerReceiver(null, intentFilter);
    boolean bool = false;
    if (intent == null) {
      o.c().b(i, "getInitialState - null intent received", new Throwable[0]);
      return null;
    } 
    int i = intent.getIntExtra("status", -1);
    int j = intent.getIntExtra("level", -1);
    int k = intent.getIntExtra("scale", -1);
    float f = j / k;
    if (i == 1 || f > 0.15F)
      bool = true; 
    return Boolean.valueOf(bool);
  }
  
  public IntentFilter f() {
    IntentFilter intentFilter = new IntentFilter();
    intentFilter.addAction("android.intent.action.BATTERY_OKAY");
    intentFilter.addAction("android.intent.action.BATTERY_LOW");
    return intentFilter;
  }
  
  public void g(Context paramContext, Intent paramIntent) {
    if (paramIntent.getAction() == null)
      return; 
    o.c().a(i, String.format("Received %s", new Object[] { paramIntent.getAction() }), new Throwable[0]);
    String str = paramIntent.getAction();
    str.hashCode();
    if (!str.equals("android.intent.action.BATTERY_OKAY")) {
      if (!str.equals("android.intent.action.BATTERY_LOW"))
        return; 
      c((T)Boolean.FALSE);
      return;
    } 
    c((T)Boolean.TRUE);
  }
}


/* Location:              C:\soft\dex2jar-2.0\Https Traffic-dex2jar.jar!\c\b0\f0\z\e\b.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */