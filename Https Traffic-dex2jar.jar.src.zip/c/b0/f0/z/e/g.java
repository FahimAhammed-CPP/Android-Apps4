package c.b0.f0.z.e;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.net.ConnectivityManager;
import android.net.Network;
import android.net.NetworkCapabilities;
import android.os.Build;
import c.b0.f0.z.a;
import c.b0.o;

public class g extends f<a> {
  public static final String j = o.e("NetworkStateTracker");
  
  public final ConnectivityManager g = (ConnectivityManager)this.b.getSystemService("connectivity");
  
  public b h;
  
  public a i;
  
  public g(Context paramContext, c.b0.f0.c0.a0.a parama) {
    super(paramContext, parama);
    if (g()) {
      this.h = new b(this);
      return;
    } 
    this.i = new a(this);
  }
  
  public static boolean g() {
    return (Build.VERSION.SDK_INT >= 24);
  }
  
  public Object a() {
    return f();
  }
  
  public void d() {
    if (g()) {
      try {
        o.c().a(j, "Registering network callback", new Throwable[0]);
        this.g.registerDefaultNetworkCallback(this.h);
        return;
      } catch (IllegalArgumentException illegalArgumentException) {
      
      } catch (SecurityException securityException) {}
      o.c().b(j, "Received exception while registering network callback", new Throwable[] { securityException });
      return;
    } 
    o.c().a(j, "Registering broadcast receiver", new Throwable[0]);
    this.b.registerReceiver(this.i, new IntentFilter("android.net.conn.CONNECTIVITY_CHANGE"));
  }
  
  public void e() {
    if (g()) {
      try {
        o.c().a(j, "Unregistering network callback", new Throwable[0]);
        this.g.unregisterNetworkCallback(this.h);
        return;
      } catch (IllegalArgumentException illegalArgumentException) {
      
      } catch (SecurityException securityException) {}
      o.c().b(j, "Received exception while unregistering network callback", new Throwable[] { securityException });
      return;
    } 
    o.c().a(j, "Unregistering broadcast receiver", new Throwable[0]);
    this.b.unregisterReceiver(this.i);
  }
  
  public a f() {
    // Byte code:
    //   0: aload_0
    //   1: getfield g : Landroid/net/ConnectivityManager;
    //   4: invokevirtual getActiveNetworkInfo : ()Landroid/net/NetworkInfo;
    //   7: astore #5
    //   9: iconst_1
    //   10: istore_3
    //   11: aload #5
    //   13: ifnull -> 29
    //   16: aload #5
    //   18: invokevirtual isConnected : ()Z
    //   21: ifeq -> 29
    //   24: iconst_1
    //   25: istore_1
    //   26: goto -> 31
    //   29: iconst_0
    //   30: istore_1
    //   31: aload_0
    //   32: getfield g : Landroid/net/ConnectivityManager;
    //   35: invokevirtual getActiveNetwork : ()Landroid/net/Network;
    //   38: astore #6
    //   40: aload_0
    //   41: getfield g : Landroid/net/ConnectivityManager;
    //   44: aload #6
    //   46: invokevirtual getNetworkCapabilities : (Landroid/net/Network;)Landroid/net/NetworkCapabilities;
    //   49: astore #6
    //   51: aload #6
    //   53: ifnull -> 73
    //   56: aload #6
    //   58: bipush #16
    //   60: invokevirtual hasCapability : (I)Z
    //   63: istore_2
    //   64: iload_2
    //   65: ifeq -> 73
    //   68: iconst_1
    //   69: istore_2
    //   70: goto -> 103
    //   73: iconst_0
    //   74: istore_2
    //   75: goto -> 103
    //   78: astore #6
    //   80: invokestatic c : ()Lc/b0/o;
    //   83: getstatic c/b0/f0/z/e/g.j : Ljava/lang/String;
    //   86: ldc 'Unable to validate active network'
    //   88: iconst_1
    //   89: anewarray java/lang/Throwable
    //   92: dup
    //   93: iconst_0
    //   94: aload #6
    //   96: aastore
    //   97: invokevirtual b : (Ljava/lang/String;Ljava/lang/String;[Ljava/lang/Throwable;)V
    //   100: goto -> 73
    //   103: aload_0
    //   104: getfield g : Landroid/net/ConnectivityManager;
    //   107: invokevirtual isActiveNetworkMetered : ()Z
    //   110: istore #4
    //   112: aload #5
    //   114: ifnull -> 128
    //   117: aload #5
    //   119: invokevirtual isRoaming : ()Z
    //   122: ifne -> 128
    //   125: goto -> 130
    //   128: iconst_0
    //   129: istore_3
    //   130: new c/b0/f0/z/a
    //   133: dup
    //   134: iload_1
    //   135: iload_2
    //   136: iload #4
    //   138: iload_3
    //   139: invokespecial <init> : (ZZZZ)V
    //   142: areturn
    // Exception table:
    //   from	to	target	type
    //   31	51	78	java/lang/SecurityException
    //   56	64	78	java/lang/SecurityException
  }
  
  public class a extends BroadcastReceiver {
    public a(g this$0) {}
    
    public void onReceive(Context param1Context, Intent param1Intent) {
      if (param1Intent != null) {
        if (param1Intent.getAction() == null)
          return; 
        if (param1Intent.getAction().equals("android.net.conn.CONNECTIVITY_CHANGE")) {
          o.c().a(g.j, "Network broadcast received", new Throwable[0]);
          g g1 = this.a;
          g1.c(g1.f());
        } 
      } 
    }
  }
  
  public class b extends ConnectivityManager.NetworkCallback {
    public b(g this$0) {}
    
    public void onCapabilitiesChanged(Network param1Network, NetworkCapabilities param1NetworkCapabilities) {
      o.c().a(g.j, String.format("Network capabilities changed: %s", new Object[] { param1NetworkCapabilities }), new Throwable[0]);
      g g1 = this.a;
      g1.c(g1.f());
    }
    
    public void onLost(Network param1Network) {
      o.c().a(g.j, "Network connection lost", new Throwable[0]);
      g g1 = this.a;
      g1.c(g1.f());
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Https Traffic-dex2jar.jar!\c\b0\f0\z\e\g.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */