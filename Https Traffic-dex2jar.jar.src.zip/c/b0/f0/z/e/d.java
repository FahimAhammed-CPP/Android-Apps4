package c.b0.f0.z.e;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import c.b0.f0.c0.a0.a;
import c.b0.o;

public abstract class d<T> extends f<T> {
  public static final String h = o.e("BrdcstRcvrCnstrntTrckr");
  
  public final BroadcastReceiver g = new c(this);
  
  public d(Context paramContext, a parama) {
    super(paramContext, parama);
  }
  
  public void d() {
    o.c().a(h, String.format("%s: registering receiver", new Object[] { getClass().getSimpleName() }), new Throwable[0]);
    this.b.registerReceiver(this.g, f());
  }
  
  public void e() {
    o.c().a(h, String.format("%s: unregistering receiver", new Object[] { getClass().getSimpleName() }), new Throwable[0]);
    this.b.unregisterReceiver(this.g);
  }
  
  public abstract IntentFilter f();
  
  public abstract void g(Context paramContext, Intent paramIntent);
}


/* Location:              C:\soft\dex2jar-2.0\Https Traffic-dex2jar.jar!\c\b0\f0\z\e\d.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */