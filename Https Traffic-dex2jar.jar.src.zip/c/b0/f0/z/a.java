package c.b0.f0.z;

public class a {
  public boolean a;
  
  public boolean b;
  
  public boolean c;
  
  public boolean d;
  
  public a(boolean paramBoolean1, boolean paramBoolean2, boolean paramBoolean3, boolean paramBoolean4) {
    this.a = paramBoolean1;
    this.b = paramBoolean2;
    this.c = paramBoolean3;
    this.d = paramBoolean4;
  }
  
  public boolean equals(Object paramObject) {
    if (this == paramObject)
      return true; 
    if (!(paramObject instanceof a))
      return false; 
    paramObject = paramObject;
    return (this.a == ((a)paramObject).a && this.b == ((a)paramObject).b && this.c == ((a)paramObject).c && this.d == ((a)paramObject).d);
  }
  
  public int hashCode() {
    if (this.a) {
      j = 1;
    } else {
      j = 0;
    } 
    int i = j;
    if (this.b)
      i = j + 16; 
    int j = i;
    if (this.c)
      j = i + 256; 
    i = j;
    if (this.d)
      i = j + 4096; 
    return i;
  }
  
  public String toString() {
    return String.format("[ Connected=%b Validated=%b Metered=%b NotRoaming=%b ]", new Object[] { Boolean.valueOf(this.a), Boolean.valueOf(this.b), Boolean.valueOf(this.c), Boolean.valueOf(this.d) });
  }
}


/* Location:              C:\soft\dex2jar-2.0\Https Traffic-dex2jar.jar!\c\b0\f0\z\a.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */