package c.b0.f0;

import c.b0.c0;
import c.b0.o;
import c.b0.w;
import c.b0.z;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Objects;
import java.util.Set;

public class h extends z {
  public static final String g = o.e("WorkContinuationImpl");
  
  public final t a;
  
  public final List<? extends c0> b;
  
  public final List<String> c;
  
  public final List<String> d;
  
  public boolean e;
  
  public w f;
  
  public h(t paramt, List<? extends c0> paramList) {
    this.a = paramt;
    this.b = paramList;
    this.c = new ArrayList<String>(paramList.size());
    this.d = new ArrayList<String>();
    for (int i = 0; i < paramList.size(); i++) {
      String str = ((c0)paramList.get(i)).a();
      this.c.add(str);
      this.d.add(str);
    } 
  }
  
  public static boolean a(h paramh, Set<String> paramSet) {
    paramSet.addAll(paramh.c);
    Set<String> set = b(paramh);
    for (String str : paramSet) {
      if (((HashSet)set).contains(str))
        return true; 
    } 
    paramSet.removeAll(paramh.c);
    return false;
  }
  
  public static Set<String> b(h paramh) {
    HashSet<String> hashSet = new HashSet();
    Objects.requireNonNull(paramh);
    return hashSet;
  }
}


/* Location:              C:\soft\dex2jar-2.0\Https Traffic-dex2jar.jar!\c\b0\f0\h.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */