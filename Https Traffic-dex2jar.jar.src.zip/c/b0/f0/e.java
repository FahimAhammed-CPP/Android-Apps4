package c.b0.f0;

import android.content.Context;
import android.content.Intent;
import android.os.Build;
import android.os.PowerManager;
import androidx.work.ListenableWorker;
import androidx.work.WorkerParameters;
import androidx.work.impl.WorkDatabase;
import androidx.work.impl.foreground.SystemForegroundService;
import c.b0.c;
import c.b0.f0.a0.a;
import c.b0.f0.a0.c;
import c.b0.f0.c0.a0.a;
import c.b0.f0.c0.a0.c;
import c.b0.f0.c0.n;
import c.b0.f0.c0.z.k;
import c.b0.f0.c0.z.m;
import c.b0.h;
import c.b0.o;
import c.h.b.b;
import d.c.c.d.a.a;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Set;

public class e implements b, a {
  public static final String p = o.e("Processor");
  
  public PowerManager.WakeLock e;
  
  public Context f;
  
  public c g;
  
  public a h;
  
  public WorkDatabase i;
  
  public Map<String, x> j;
  
  public Map<String, x> k;
  
  public List<f> l;
  
  public Set<String> m;
  
  public final List<b> n;
  
  public final Object o;
  
  public e(Context paramContext, c paramc, a parama, WorkDatabase paramWorkDatabase, List<f> paramList) {
    this.f = paramContext;
    this.g = paramc;
    this.h = parama;
    this.i = paramWorkDatabase;
    this.k = new HashMap<String, x>();
    this.j = new HashMap<String, x>();
    this.l = paramList;
    this.m = new HashSet<String>();
    this.n = new ArrayList<b>();
    this.e = null;
    this.o = new Object();
  }
  
  public static boolean c(String paramString, x paramx) {
    if (paramx != null) {
      boolean bool;
      paramx.w = true;
      paramx.i();
      a<ListenableWorker.a> a1 = paramx.v;
      if (a1 != null) {
        bool = ((k)a1).isDone();
        ((k)paramx.v).cancel(true);
      } else {
        bool = false;
      } 
      ListenableWorker listenableWorker = paramx.j;
      if (listenableWorker != null && !bool) {
        listenableWorker.stop();
      } else {
        String str = String.format("WorkSpec %s is already done. Not interrupting.", new Object[] { paramx.i });
        o.c().a(x.x, str, new Throwable[0]);
      } 
      o.c().a(p, String.format("WorkerWrapper interrupted for %s", new Object[] { paramString }), new Throwable[0]);
      return true;
    } 
    o.c().a(p, String.format("WorkerWrapper could not be found for %s", new Object[] { paramString }), new Throwable[0]);
    return false;
  }
  
  public void a(String paramString, boolean paramBoolean) {
    synchronized (this.o) {
      this.k.remove(paramString);
      o.c().a(p, String.format("%s %s executed; reschedule = %s", new Object[] { getClass().getSimpleName(), paramString, Boolean.valueOf(paramBoolean) }), new Throwable[0]);
      Iterator<b> iterator = this.n.iterator();
      while (iterator.hasNext())
        ((b)iterator.next()).a(paramString, paramBoolean); 
      return;
    } 
  }
  
  public void b(b paramb) {
    synchronized (this.o) {
      this.n.add(paramb);
      return;
    } 
  }
  
  public boolean d(String paramString) {
    synchronized (this.o) {
      if (this.k.containsKey(paramString) || this.j.containsKey(paramString))
        return true; 
    } 
    boolean bool = false;
    /* monitor exit ClassFileLocalVariableReferenceExpression{type=ObjectType{java/lang/Object}, name=SYNTHETIC_LOCAL_VARIABLE_3} */
    return bool;
  }
  
  public void e(b paramb) {
    synchronized (this.o) {
      this.n.remove(paramb);
      return;
    } 
  }
  
  public void f(String paramString, h paramh) {
    synchronized (this.o) {
      o.c().d(p, String.format("Moving WorkSpec (%s) to the foreground", new Object[] { paramString }), new Throwable[0]);
      x x = this.k.remove(paramString);
      if (x != null) {
        if (this.e == null) {
          PowerManager.WakeLock wakeLock = n.a(this.f, "ProcessorForegroundLck");
          this.e = wakeLock;
          wakeLock.acquire();
        } 
        this.j.put(paramString, x);
        Intent intent = c.c(this.f, paramString, paramh);
        Context context = this.f;
        Object object = b.a;
        if (Build.VERSION.SDK_INT >= 26) {
          c.h.c.e.a(context, intent);
        } else {
          context.startService(intent);
        } 
      } 
      return;
    } 
  }
  
  public boolean g(String paramString, WorkerParameters.a parama) {
    synchronized (this.o) {
      if (d(paramString)) {
        o.c().a(p, String.format("Work %s is already enqueued for processing", new Object[] { paramString }), new Throwable[0]);
        return false;
      } 
      w w = new w(this.f, this.g, this.h, this, this.i, paramString);
      w.g = this.l;
      if (parama != null)
        w.h = parama; 
      x x = new x(w);
      m<Boolean> m = x.u;
      m.c(new d(this, paramString, (a<Boolean>)m), ((c)this.h).c);
      this.k.put(paramString, x);
      ((c)this.h).a.execute(x);
      o.c().a(p, String.format("%s: processing %s", new Object[] { e.class.getSimpleName(), paramString }), new Throwable[0]);
      return true;
    } 
  }
  
  public final void h() {
    synchronized (this.o) {
      if ((this.j.isEmpty() ^ true) == 0) {
        PowerManager.WakeLock wakeLock;
        Context context = this.f;
        String str = c.o;
        Intent intent = new Intent(context, SystemForegroundService.class);
        intent.setAction("ACTION_STOP_FOREGROUND");
        try {
          this.f.startService(intent);
        } finally {
          intent = null;
        } 
        if (wakeLock != null) {
          wakeLock.release();
          this.e = null;
        } 
      } 
      return;
    } 
  }
  
  public boolean i(String paramString) {
    synchronized (this.o) {
      o.c().a(p, String.format("Processor stopping foreground work %s", new Object[] { paramString }), new Throwable[0]);
      return c(paramString, this.j.remove(paramString));
    } 
  }
  
  public boolean j(String paramString) {
    synchronized (this.o) {
      o.c().a(p, String.format("Processor stopping background work %s", new Object[] { paramString }), new Throwable[0]);
      return c(paramString, this.k.remove(paramString));
    } 
  }
}


/* Location:              C:\soft\dex2jar-2.0\Https Traffic-dex2jar.jar!\c\b0\f0\e.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */