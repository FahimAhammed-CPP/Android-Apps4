package c.b0;

import android.util.Log;
import d.a.a.a.a;

public class o {
  public static o b;
  
  public int a;
  
  public o(int paramInt) {
    this.a = paramInt;
  }
  
  public static o c() {
    // Byte code:
    //   0: ldc c/b0/o
    //   2: monitorenter
    //   3: getstatic c/b0/o.b : Lc/b0/o;
    //   6: ifnonnull -> 20
    //   9: new c/b0/o
    //   12: dup
    //   13: iconst_3
    //   14: invokespecial <init> : (I)V
    //   17: putstatic c/b0/o.b : Lc/b0/o;
    //   20: getstatic c/b0/o.b : Lc/b0/o;
    //   23: astore_0
    //   24: ldc c/b0/o
    //   26: monitorexit
    //   27: aload_0
    //   28: areturn
    //   29: astore_0
    //   30: ldc c/b0/o
    //   32: monitorexit
    //   33: aload_0
    //   34: athrow
    // Exception table:
    //   from	to	target	type
    //   3	20	29	finally
    //   20	24	29	finally
  }
  
  public static String e(String paramString) {
    int i = paramString.length();
    StringBuilder stringBuilder = a.l(23, "WM-");
    if (i >= 20) {
      stringBuilder.append(paramString.substring(0, 20));
    } else {
      stringBuilder.append(paramString);
    } 
    return stringBuilder.toString();
  }
  
  public void a(String paramString1, String paramString2, Throwable... paramVarArgs) {
    if (this.a <= 3) {
      if (paramVarArgs.length >= 1) {
        Log.d(paramString1, paramString2, paramVarArgs[0]);
        return;
      } 
      Log.d(paramString1, paramString2);
    } 
  }
  
  public void b(String paramString1, String paramString2, Throwable... paramVarArgs) {
    if (this.a <= 6) {
      if (paramVarArgs.length >= 1) {
        Log.e(paramString1, paramString2, paramVarArgs[0]);
        return;
      } 
      Log.e(paramString1, paramString2);
    } 
  }
  
  public void d(String paramString1, String paramString2, Throwable... paramVarArgs) {
    if (this.a <= 4) {
      if (paramVarArgs.length >= 1) {
        Log.i(paramString1, paramString2, paramVarArgs[0]);
        return;
      } 
      Log.i(paramString1, paramString2);
    } 
  }
  
  public void f(String paramString1, String paramString2, Throwable... paramVarArgs) {
    if (this.a <= 5) {
      if (paramVarArgs.length >= 1) {
        Log.w(paramString1, paramString2, paramVarArgs[0]);
        return;
      } 
      Log.w(paramString1, paramString2);
    } 
  }
}


/* Location:              C:\soft\dex2jar-2.0\Https Traffic-dex2jar.jar!\c\b0\o.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */