package c.b0;

import c.b0.f0.a;
import java.util.concurrent.Executor;
import java.util.concurrent.Executors;

public final class c {
  public final Executor a = a(false);
  
  public final Executor b = a(true);
  
  public final e0 c;
  
  public final k d;
  
  public final a e;
  
  public final int f;
  
  public final int g;
  
  public final int h;
  
  public c(a parama) {
    String str = e0.a;
    this.c = new d0();
    this.d = new k();
    this.e = new a();
    this.f = 4;
    this.g = Integer.MAX_VALUE;
    this.h = 20;
  }
  
  public final Executor a(boolean paramBoolean) {
    return Executors.newFixedThreadPool(Math.max(2, Math.min(Runtime.getRuntime().availableProcessors() - 1, 4)), new b(this, paramBoolean));
  }
  
  public static final class a {}
}


/* Location:              C:\soft\dex2jar-2.0\Https Traffic-dex2jar.jar!\c\b0\c.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */