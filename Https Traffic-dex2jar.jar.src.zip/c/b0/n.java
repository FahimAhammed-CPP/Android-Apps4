package c.b0;

import androidx.work.ListenableWorker;
import d.a.a.a.a;

public final class n extends ListenableWorker.a {
  public final g a;
  
  public n() {
    this.a = g1;
  }
  
  public n(g paramg) {
    this.a = paramg;
  }
  
  public boolean equals(Object paramObject) {
    if (this == paramObject)
      return true; 
    if (paramObject == null || n.class != paramObject.getClass())
      return false; 
    paramObject = paramObject;
    return this.a.equals(((n)paramObject).a);
  }
  
  public int hashCode() {
    int i = n.class.getName().hashCode();
    return this.a.hashCode() + i * 31;
  }
  
  public String toString() {
    StringBuilder stringBuilder = a.p("Success {mOutputData=");
    stringBuilder.append(this.a);
    stringBuilder.append('}');
    return stringBuilder.toString();
  }
}


/* Location:              C:\soft\dex2jar-2.0\Https Traffic-dex2jar.jar!\c\b0\n.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */