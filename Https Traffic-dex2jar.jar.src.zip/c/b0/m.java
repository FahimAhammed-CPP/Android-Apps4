package c.b0;

import androidx.work.ListenableWorker;

public final class m extends ListenableWorker.a {
  public boolean equals(Object paramObject) {
    return (this == paramObject) ? true : ((paramObject != null && m.class == paramObject.getClass()));
  }
  
  public int hashCode() {
    return m.class.getName().hashCode();
  }
  
  public String toString() {
    return "Retry";
  }
}


/* Location:              C:\soft\dex2jar-2.0\Https Traffic-dex2jar.jar!\c\b0\m.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */