package c.b.e.a;

import android.content.res.Resources;
import android.graphics.drawable.Drawable;

public abstract class o extends l {
  public n r;
  
  public boolean s;
  
  public o(n paramn) {}
  
  public void applyTheme(Resources.Theme paramTheme) {
    super.applyTheme(paramTheme);
    onStateChange(getState());
  }
  
  public Drawable mutate() {
    if (!this.s) {
      super.mutate();
      this.r.e();
      this.s = true;
    } 
    return this;
  }
  
  public abstract boolean onStateChange(int[] paramArrayOfint);
}


/* Location:              C:\soft\dex2jar-2.0\Https Traffic-dex2jar.jar!\c\b\e\a\o.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */