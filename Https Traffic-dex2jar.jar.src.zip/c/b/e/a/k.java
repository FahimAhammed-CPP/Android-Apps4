package c.b.e.a;

import android.content.res.ColorStateList;
import android.content.res.Resources;
import android.graphics.ColorFilter;
import android.graphics.PorterDuff;
import android.graphics.Rect;
import android.graphics.drawable.Drawable;
import android.util.SparseArray;

public abstract class k extends Drawable.ConstantState {
  public int A;
  
  public int B;
  
  public boolean C;
  
  public ColorFilter D;
  
  public boolean E;
  
  public ColorStateList F;
  
  public PorterDuff.Mode G;
  
  public boolean H;
  
  public boolean I;
  
  public final l a;
  
  public Resources b;
  
  public int c;
  
  public int d;
  
  public int e;
  
  public SparseArray<Drawable.ConstantState> f;
  
  public Drawable[] g;
  
  public int h;
  
  public boolean i;
  
  public boolean j;
  
  public Rect k;
  
  public boolean l;
  
  public boolean m;
  
  public int n;
  
  public int o;
  
  public int p;
  
  public int q;
  
  public boolean r;
  
  public int s;
  
  public boolean t;
  
  public boolean u;
  
  public boolean v;
  
  public boolean w;
  
  public boolean x;
  
  public boolean y;
  
  public int z;
  
  public k(k paramk, l paraml, Resources paramResources) {
    int i;
    int j = 160;
    this.c = 160;
    boolean bool = false;
    this.i = false;
    this.l = false;
    this.x = true;
    this.A = 0;
    this.B = 0;
    this.a = paraml;
    if (paramResources != null) {
      Resources resources = paramResources;
    } else if (paramk != null) {
      Resources resources = paramk.b;
    } else {
      paraml = null;
    } 
    this.b = (Resources)paraml;
    if (paramk != null) {
      i = paramk.c;
    } else {
      i = 0;
    } 
    int m = l.q;
    if (paramResources != null)
      i = (paramResources.getDisplayMetrics()).densityDpi; 
    if (i == 0)
      i = j; 
    this.c = i;
    if (paramk != null) {
      this.d = paramk.d;
      this.e = paramk.e;
      this.v = true;
      this.w = true;
      this.i = paramk.i;
      this.l = paramk.l;
      this.x = paramk.x;
      this.y = paramk.y;
      this.z = paramk.z;
      this.A = paramk.A;
      this.B = paramk.B;
      this.C = paramk.C;
      this.D = paramk.D;
      this.E = paramk.E;
      this.F = paramk.F;
      this.G = paramk.G;
      this.H = paramk.H;
      this.I = paramk.I;
      if (paramk.c == i) {
        if (paramk.j) {
          this.k = new Rect(paramk.k);
          this.j = true;
        } 
        if (paramk.m) {
          this.n = paramk.n;
          this.o = paramk.o;
          this.p = paramk.p;
          this.q = paramk.q;
          this.m = true;
        } 
      } 
      if (paramk.r) {
        this.s = paramk.s;
        this.r = true;
      } 
      if (paramk.t) {
        this.u = paramk.u;
        this.t = true;
      } 
      Drawable[] arrayOfDrawable = paramk.g;
      this.g = new Drawable[arrayOfDrawable.length];
      this.h = paramk.h;
      SparseArray<Drawable.ConstantState> sparseArray = paramk.f;
      if (sparseArray != null) {
        this.f = sparseArray.clone();
      } else {
        this.f = new SparseArray(this.h);
      } 
      j = this.h;
      for (i = bool; i < j; i++) {
        if (arrayOfDrawable[i] != null) {
          Drawable.ConstantState constantState = arrayOfDrawable[i].getConstantState();
          if (constantState != null) {
            this.f.put(i, constantState);
          } else {
            this.g[i] = arrayOfDrawable[i];
          } 
        } 
      } 
    } else {
      this.g = new Drawable[10];
      this.h = 0;
    } 
  }
  
  public final int a(Drawable paramDrawable) {
    int i = this.h;
    if (i >= this.g.length) {
      int m = i + 10;
      n n = (n)this;
      Drawable[] arrayOfDrawable = new Drawable[m];
      System.arraycopy(n.g, 0, arrayOfDrawable, 0, i);
      n.g = arrayOfDrawable;
      int[][] arrayOfInt = new int[m][];
      System.arraycopy(n.J, 0, arrayOfInt, 0, i);
      n.J = arrayOfInt;
    } 
    paramDrawable.mutate();
    paramDrawable.setVisible(false, true);
    paramDrawable.setCallback(this.a);
    this.g[i] = paramDrawable;
    this.h++;
    int j = this.e;
    this.e = paramDrawable.getChangingConfigurations() | j;
    this.r = false;
    this.t = false;
    this.k = null;
    this.j = false;
    this.m = false;
    this.v = false;
    return i;
  }
  
  public void b() {
    this.m = true;
    c();
    int j = this.h;
    Drawable[] arrayOfDrawable = this.g;
    this.o = -1;
    this.n = -1;
    int i = 0;
    this.q = 0;
    this.p = 0;
    while (i < j) {
      Drawable drawable = arrayOfDrawable[i];
      int m = drawable.getIntrinsicWidth();
      if (m > this.n)
        this.n = m; 
      m = drawable.getIntrinsicHeight();
      if (m > this.o)
        this.o = m; 
      m = drawable.getMinimumWidth();
      if (m > this.p)
        this.p = m; 
      m = drawable.getMinimumHeight();
      if (m > this.q)
        this.q = m; 
      i++;
    } 
  }
  
  public final void c() {
    SparseArray<Drawable.ConstantState> sparseArray = this.f;
    if (sparseArray != null) {
      int j = sparseArray.size();
      for (int i = 0; i < j; i++) {
        int m = this.f.keyAt(i);
        Drawable.ConstantState constantState = (Drawable.ConstantState)this.f.valueAt(i);
        Drawable[] arrayOfDrawable = this.g;
        Drawable drawable = constantState.newDrawable(this.b);
        drawable.setLayoutDirection(this.z);
        drawable = drawable.mutate();
        drawable.setCallback(this.a);
        arrayOfDrawable[m] = drawable;
      } 
      this.f = null;
    } 
  }
  
  public boolean canApplyTheme() {
    int j = this.h;
    Drawable[] arrayOfDrawable = this.g;
    for (int i = 0; i < j; i++) {
      Drawable drawable = arrayOfDrawable[i];
      if (drawable != null) {
        if (drawable.canApplyTheme())
          return true; 
      } else {
        Drawable.ConstantState constantState = (Drawable.ConstantState)this.f.get(i);
        if (constantState != null && constantState.canApplyTheme())
          return true; 
      } 
    } 
    return false;
  }
  
  public final Drawable d(int paramInt) {
    Drawable drawable = this.g[paramInt];
    if (drawable != null)
      return drawable; 
    SparseArray<Drawable.ConstantState> sparseArray = this.f;
    if (sparseArray != null) {
      int i = sparseArray.indexOfKey(paramInt);
      if (i >= 0) {
        Drawable drawable1 = ((Drawable.ConstantState)this.f.valueAt(i)).newDrawable(this.b);
        drawable1.setLayoutDirection(this.z);
        drawable1 = drawable1.mutate();
        drawable1.setCallback(this.a);
        this.g[paramInt] = drawable1;
        this.f.removeAt(i);
        if (this.f.size() == 0)
          this.f = null; 
        return drawable1;
      } 
    } 
    return null;
  }
  
  public abstract void e();
  
  public final void f(Resources paramResources) {
    if (paramResources != null) {
      this.b = paramResources;
      int i = l.q;
      int j = (paramResources.getDisplayMetrics()).densityDpi;
      i = j;
      if (j == 0)
        i = 160; 
      j = this.c;
      this.c = i;
      if (j != i) {
        this.m = false;
        this.j = false;
      } 
    } 
  }
  
  public int getChangingConfigurations() {
    return this.d | this.e;
  }
}


/* Location:              C:\soft\dex2jar-2.0\Https Traffic-dex2jar.jar!\c\b\e\a\k.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */