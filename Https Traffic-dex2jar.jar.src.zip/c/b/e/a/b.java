package c.b.e.a;

import android.graphics.drawable.Animatable;

public class b extends g {
  public final Animatable a;
  
  public b(Animatable paramAnimatable) {
    super(null);
    this.a = paramAnimatable;
  }
  
  public void c() {
    this.a.start();
  }
  
  public void d() {
    this.a.stop();
  }
}


/* Location:              C:\soft\dex2jar-2.0\Https Traffic-dex2jar.jar!\c\b\e\a\b.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */