package c.b.e.a;

import c.z.a.a.e;

public class d extends g {
  public final e a;
  
  public d(e parame) {
    super(null);
    this.a = parame;
  }
  
  public void c() {
    this.a.start();
  }
  
  public void d() {
    this.a.stop();
  }
}


/* Location:              C:\soft\dex2jar-2.0\Https Traffic-dex2jar.jar!\c\b\e\a\d.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */