package c.b.e.a;

public abstract class g {
  public g(a parama) {}
  
  public boolean a() {
    return false;
  }
  
  public void b() {}
  
  public abstract void c();
  
  public abstract void d();
}


/* Location:              C:\soft\dex2jar-2.0\Https Traffic-dex2jar.jar!\c\b\e\a\g.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */