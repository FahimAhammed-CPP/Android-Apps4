package c.b.e.a;

public class i implements Runnable {
  public i(l paraml) {}
  
  public void run() {
    this.e.a(true);
    this.e.invalidateSelf();
  }
}


/* Location:              C:\soft\dex2jar-2.0\Https Traffic-dex2jar.jar!\c\b\e\a\i.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */