package c.b.f;

public abstract class a {
  public static final int[] a = new int[] { 16843036, 16843156, 16843157, 16843158, 16843532, 16843533 };
  
  public static final int[] b = new int[] { 16842960, 16843161 };
  
  public static final int[] c = new int[] { 16843161, 16843849, 16843850, 16843851 };
}


/* Location:              C:\soft\dex2jar-2.0\Https Traffic-dex2jar.jar!\c\b\f\a.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */