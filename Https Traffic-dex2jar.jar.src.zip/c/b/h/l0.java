package c.b.h;

import android.view.ViewTreeObserver;
import android.widget.PopupWindow;

public class l0 implements PopupWindow.OnDismissListener {
  public l0(m0 paramm0, ViewTreeObserver.OnGlobalLayoutListener paramOnGlobalLayoutListener) {}
  
  public void onDismiss() {
    ViewTreeObserver viewTreeObserver = this.f.L.getViewTreeObserver();
    if (viewTreeObserver != null)
      viewTreeObserver.removeGlobalOnLayoutListener(this.e); 
  }
}


/* Location:              C:\soft\dex2jar-2.0\Https Traffic-dex2jar.jar!\c\b\h\l0.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */