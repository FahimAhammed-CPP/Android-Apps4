package c.b.h;

public class o2 implements Runnable {
  public o2(q2 paramq2) {}
  
  public void run() {
    this.e.d(false);
  }
}


/* Location:              C:\soft\dex2jar-2.0\Https Traffic-dex2jar.jar!\c\b\h\o2.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */