package c.b.h;

import android.graphics.drawable.Drawable;
import android.widget.ListAdapter;

public interface p0 {
  int a();
  
  boolean b();
  
  void dismiss();
  
  Drawable f();
  
  void h(CharSequence paramCharSequence);
  
  void i(Drawable paramDrawable);
  
  void j(int paramInt);
  
  void k(int paramInt);
  
  void l(int paramInt);
  
  void m(int paramInt1, int paramInt2);
  
  int n();
  
  CharSequence o();
  
  void p(ListAdapter paramListAdapter);
}


/* Location:              C:\soft\dex2jar-2.0\Https Traffic-dex2jar.jar!\c\b\h\p0.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */