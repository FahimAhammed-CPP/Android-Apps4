package c.b.h;

import android.content.Context;
import android.content.res.TypedArray;
import android.database.DataSetObserver;
import android.graphics.Rect;
import android.graphics.drawable.Drawable;
import android.os.Build;
import android.os.Handler;
import android.util.AttributeSet;
import android.util.Log;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ListAdapter;
import android.widget.ListView;
import android.widget.PopupWindow;
import c.b.b;
import c.b.g.n.b0;
import java.lang.reflect.Method;

public class q1 implements b0 {
  public static Method E;
  
  public static Method F;
  
  public static Method G;
  
  public final Rect A = new Rect();
  
  public Rect B;
  
  public boolean C;
  
  public PopupWindow D;
  
  public Context e;
  
  public ListAdapter f;
  
  public f1 g;
  
  public int h = -2;
  
  public int i = -2;
  
  public int j;
  
  public int k;
  
  public int l = 1002;
  
  public boolean m;
  
  public boolean n;
  
  public boolean o;
  
  public int p = 0;
  
  public int q = Integer.MAX_VALUE;
  
  public int r = 0;
  
  public DataSetObserver s;
  
  public View t;
  
  public AdapterView.OnItemClickListener u;
  
  public final p1 v = new p1(this);
  
  public final o1 w = new o1(this);
  
  public final n1 x = new n1(this);
  
  public final l1 y = new l1(this);
  
  public final Handler z;
  
  static {
    if (Build.VERSION.SDK_INT <= 28) {
      try {
        E = PopupWindow.class.getDeclaredMethod("setClipToScreenEnabled", new Class[] { boolean.class });
      } catch (NoSuchMethodException noSuchMethodException) {
        Log.i("ListPopupWindow", "Could not find method setClipToScreenEnabled() on PopupWindow. Oh well.");
      } 
      try {
        G = PopupWindow.class.getDeclaredMethod("setEpicenterBounds", new Class[] { Rect.class });
      } catch (NoSuchMethodException noSuchMethodException) {
        Log.i("ListPopupWindow", "Could not find method setEpicenterBounds(Rect) on PopupWindow. Oh well.");
      } 
    } 
    if (Build.VERSION.SDK_INT <= 23)
      try {
        F = PopupWindow.class.getDeclaredMethod("getMaxAvailableHeight", new Class[] { View.class, int.class, boolean.class });
        return;
      } catch (NoSuchMethodException noSuchMethodException) {
        Log.i("ListPopupWindow", "Could not find method getMaxAvailableHeight(View, int, boolean) on PopupWindow. Oh well.");
      }  
  }
  
  public q1(Context paramContext, AttributeSet paramAttributeSet, int paramInt1, int paramInt2) {
    this.e = paramContext;
    this.z = new Handler(paramContext.getMainLooper());
    TypedArray typedArray = paramContext.obtainStyledAttributes(paramAttributeSet, b.p, paramInt1, paramInt2);
    this.j = typedArray.getDimensionPixelOffset(0, 0);
    int i = typedArray.getDimensionPixelOffset(1, 0);
    this.k = i;
    if (i != 0)
      this.m = true; 
    typedArray.recycle();
    z z = new z(paramContext, paramAttributeSet, paramInt1, paramInt2);
    this.D = z;
    z.setInputMethodMode(1);
  }
  
  public int a() {
    return this.j;
  }
  
  public boolean b() {
    return this.D.isShowing();
  }
  
  public void d() {
    // Byte code:
    //   0: aload_0
    //   1: getfield g : Lc/b/h/f1;
    //   4: ifnonnull -> 109
    //   7: aload_0
    //   8: aload_0
    //   9: getfield e : Landroid/content/Context;
    //   12: aload_0
    //   13: getfield C : Z
    //   16: iconst_1
    //   17: ixor
    //   18: invokevirtual q : (Landroid/content/Context;Z)Lc/b/h/f1;
    //   21: astore #7
    //   23: aload_0
    //   24: aload #7
    //   26: putfield g : Lc/b/h/f1;
    //   29: aload #7
    //   31: aload_0
    //   32: getfield f : Landroid/widget/ListAdapter;
    //   35: invokevirtual setAdapter : (Landroid/widget/ListAdapter;)V
    //   38: aload_0
    //   39: getfield g : Lc/b/h/f1;
    //   42: aload_0
    //   43: getfield u : Landroid/widget/AdapterView$OnItemClickListener;
    //   46: invokevirtual setOnItemClickListener : (Landroid/widget/AdapterView$OnItemClickListener;)V
    //   49: aload_0
    //   50: getfield g : Lc/b/h/f1;
    //   53: iconst_1
    //   54: invokevirtual setFocusable : (Z)V
    //   57: aload_0
    //   58: getfield g : Lc/b/h/f1;
    //   61: iconst_1
    //   62: invokevirtual setFocusableInTouchMode : (Z)V
    //   65: aload_0
    //   66: getfield g : Lc/b/h/f1;
    //   69: new c/b/h/k1
    //   72: dup
    //   73: aload_0
    //   74: invokespecial <init> : (Lc/b/h/q1;)V
    //   77: invokevirtual setOnItemSelectedListener : (Landroid/widget/AdapterView$OnItemSelectedListener;)V
    //   80: aload_0
    //   81: getfield g : Lc/b/h/f1;
    //   84: aload_0
    //   85: getfield x : Lc/b/h/n1;
    //   88: invokevirtual setOnScrollListener : (Landroid/widget/AbsListView$OnScrollListener;)V
    //   91: aload_0
    //   92: getfield g : Lc/b/h/f1;
    //   95: astore #7
    //   97: aload_0
    //   98: getfield D : Landroid/widget/PopupWindow;
    //   101: aload #7
    //   103: invokevirtual setContentView : (Landroid/view/View;)V
    //   106: goto -> 121
    //   109: aload_0
    //   110: getfield D : Landroid/widget/PopupWindow;
    //   113: invokevirtual getContentView : ()Landroid/view/View;
    //   116: checkcast android/view/ViewGroup
    //   119: astore #7
    //   121: aload_0
    //   122: getfield D : Landroid/widget/PopupWindow;
    //   125: invokevirtual getBackground : ()Landroid/graphics/drawable/Drawable;
    //   128: astore #7
    //   130: iconst_0
    //   131: istore #4
    //   133: aload #7
    //   135: ifnull -> 188
    //   138: aload #7
    //   140: aload_0
    //   141: getfield A : Landroid/graphics/Rect;
    //   144: invokevirtual getPadding : (Landroid/graphics/Rect;)Z
    //   147: pop
    //   148: aload_0
    //   149: getfield A : Landroid/graphics/Rect;
    //   152: astore #7
    //   154: aload #7
    //   156: getfield top : I
    //   159: istore_2
    //   160: aload #7
    //   162: getfield bottom : I
    //   165: iload_2
    //   166: iadd
    //   167: istore_1
    //   168: iload_1
    //   169: istore_3
    //   170: aload_0
    //   171: getfield m : Z
    //   174: ifne -> 197
    //   177: aload_0
    //   178: iload_2
    //   179: ineg
    //   180: putfield k : I
    //   183: iload_1
    //   184: istore_3
    //   185: goto -> 197
    //   188: aload_0
    //   189: getfield A : Landroid/graphics/Rect;
    //   192: invokevirtual setEmpty : ()V
    //   195: iconst_0
    //   196: istore_3
    //   197: aload_0
    //   198: getfield D : Landroid/widget/PopupWindow;
    //   201: invokevirtual getInputMethodMode : ()I
    //   204: iconst_2
    //   205: if_icmpne -> 214
    //   208: iconst_1
    //   209: istore #6
    //   211: goto -> 217
    //   214: iconst_0
    //   215: istore #6
    //   217: aload_0
    //   218: getfield t : Landroid/view/View;
    //   221: astore #7
    //   223: aload_0
    //   224: getfield k : I
    //   227: istore_2
    //   228: getstatic android/os/Build$VERSION.SDK_INT : I
    //   231: bipush #23
    //   233: if_icmpgt -> 312
    //   236: getstatic c/b/h/q1.F : Ljava/lang/reflect/Method;
    //   239: astore #8
    //   241: aload #8
    //   243: ifnull -> 298
    //   246: aload #8
    //   248: aload_0
    //   249: getfield D : Landroid/widget/PopupWindow;
    //   252: iconst_3
    //   253: anewarray java/lang/Object
    //   256: dup
    //   257: iconst_0
    //   258: aload #7
    //   260: aastore
    //   261: dup
    //   262: iconst_1
    //   263: iload_2
    //   264: invokestatic valueOf : (I)Ljava/lang/Integer;
    //   267: aastore
    //   268: dup
    //   269: iconst_2
    //   270: iload #6
    //   272: invokestatic valueOf : (Z)Ljava/lang/Boolean;
    //   275: aastore
    //   276: invokevirtual invoke : (Ljava/lang/Object;[Ljava/lang/Object;)Ljava/lang/Object;
    //   279: checkcast java/lang/Integer
    //   282: invokevirtual intValue : ()I
    //   285: istore_1
    //   286: goto -> 325
    //   289: ldc 'ListPopupWindow'
    //   291: ldc_w 'Could not call getMaxAvailableHeightMethod(View, int, boolean) on PopupWindow. Using the public version.'
    //   294: invokestatic i : (Ljava/lang/String;Ljava/lang/String;)I
    //   297: pop
    //   298: aload_0
    //   299: getfield D : Landroid/widget/PopupWindow;
    //   302: aload #7
    //   304: iload_2
    //   305: invokevirtual getMaxAvailableHeight : (Landroid/view/View;I)I
    //   308: istore_1
    //   309: goto -> 325
    //   312: aload_0
    //   313: getfield D : Landroid/widget/PopupWindow;
    //   316: aload #7
    //   318: iload_2
    //   319: iload #6
    //   321: invokevirtual getMaxAvailableHeight : (Landroid/view/View;IZ)I
    //   324: istore_1
    //   325: aload_0
    //   326: getfield h : I
    //   329: iconst_m1
    //   330: if_icmpne -> 340
    //   333: iload_1
    //   334: iload_3
    //   335: iadd
    //   336: istore_1
    //   337: goto -> 498
    //   340: aload_0
    //   341: getfield i : I
    //   344: istore_2
    //   345: iload_2
    //   346: bipush #-2
    //   348: if_icmpeq -> 410
    //   351: iload_2
    //   352: iconst_m1
    //   353: if_icmpeq -> 367
    //   356: iload_2
    //   357: ldc_w 1073741824
    //   360: invokestatic makeMeasureSpec : (II)I
    //   363: istore_2
    //   364: goto -> 450
    //   367: aload_0
    //   368: getfield e : Landroid/content/Context;
    //   371: invokevirtual getResources : ()Landroid/content/res/Resources;
    //   374: invokevirtual getDisplayMetrics : ()Landroid/util/DisplayMetrics;
    //   377: getfield widthPixels : I
    //   380: istore_2
    //   381: aload_0
    //   382: getfield A : Landroid/graphics/Rect;
    //   385: astore #7
    //   387: iload_2
    //   388: aload #7
    //   390: getfield left : I
    //   393: aload #7
    //   395: getfield right : I
    //   398: iadd
    //   399: isub
    //   400: ldc_w 1073741824
    //   403: invokestatic makeMeasureSpec : (II)I
    //   406: istore_2
    //   407: goto -> 450
    //   410: aload_0
    //   411: getfield e : Landroid/content/Context;
    //   414: invokevirtual getResources : ()Landroid/content/res/Resources;
    //   417: invokevirtual getDisplayMetrics : ()Landroid/util/DisplayMetrics;
    //   420: getfield widthPixels : I
    //   423: istore_2
    //   424: aload_0
    //   425: getfield A : Landroid/graphics/Rect;
    //   428: astore #7
    //   430: iload_2
    //   431: aload #7
    //   433: getfield left : I
    //   436: aload #7
    //   438: getfield right : I
    //   441: iadd
    //   442: isub
    //   443: ldc_w -2147483648
    //   446: invokestatic makeMeasureSpec : (II)I
    //   449: istore_2
    //   450: aload_0
    //   451: getfield g : Lc/b/h/f1;
    //   454: iload_2
    //   455: iload_1
    //   456: iconst_0
    //   457: isub
    //   458: iconst_m1
    //   459: invokevirtual a : (III)I
    //   462: istore_2
    //   463: iload_2
    //   464: ifle -> 492
    //   467: aload_0
    //   468: getfield g : Lc/b/h/f1;
    //   471: invokevirtual getPaddingTop : ()I
    //   474: istore_1
    //   475: aload_0
    //   476: getfield g : Lc/b/h/f1;
    //   479: invokevirtual getPaddingBottom : ()I
    //   482: iload_1
    //   483: iadd
    //   484: iload_3
    //   485: iadd
    //   486: iconst_0
    //   487: iadd
    //   488: istore_1
    //   489: goto -> 494
    //   492: iconst_0
    //   493: istore_1
    //   494: iload_2
    //   495: iload_1
    //   496: iadd
    //   497: istore_1
    //   498: aload_0
    //   499: getfield D : Landroid/widget/PopupWindow;
    //   502: invokevirtual getInputMethodMode : ()I
    //   505: iconst_2
    //   506: if_icmpne -> 514
    //   509: iconst_1
    //   510: istore_3
    //   511: goto -> 516
    //   514: iconst_0
    //   515: istore_3
    //   516: aload_0
    //   517: getfield D : Landroid/widget/PopupWindow;
    //   520: aload_0
    //   521: getfield l : I
    //   524: invokevirtual setWindowLayoutType : (I)V
    //   527: aload_0
    //   528: getfield D : Landroid/widget/PopupWindow;
    //   531: invokevirtual isShowing : ()Z
    //   534: ifeq -> 766
    //   537: aload_0
    //   538: getfield t : Landroid/view/View;
    //   541: astore #7
    //   543: getstatic c/h/j/u.a : Ljava/util/concurrent/atomic/AtomicInteger;
    //   546: astore #8
    //   548: aload #7
    //   550: invokevirtual isAttachedToWindow : ()Z
    //   553: ifne -> 557
    //   556: return
    //   557: aload_0
    //   558: getfield i : I
    //   561: istore #5
    //   563: iload #5
    //   565: iconst_m1
    //   566: if_icmpne -> 574
    //   569: iconst_m1
    //   570: istore_2
    //   571: goto -> 592
    //   574: iload #5
    //   576: istore_2
    //   577: iload #5
    //   579: bipush #-2
    //   581: if_icmpne -> 592
    //   584: aload_0
    //   585: getfield t : Landroid/view/View;
    //   588: invokevirtual getWidth : ()I
    //   591: istore_2
    //   592: aload_0
    //   593: getfield h : I
    //   596: istore #5
    //   598: iload #5
    //   600: iconst_m1
    //   601: if_icmpne -> 691
    //   604: iload_3
    //   605: ifeq -> 611
    //   608: goto -> 613
    //   611: iconst_m1
    //   612: istore_1
    //   613: iload_3
    //   614: ifeq -> 655
    //   617: aload_0
    //   618: getfield D : Landroid/widget/PopupWindow;
    //   621: astore #7
    //   623: aload_0
    //   624: getfield i : I
    //   627: iconst_m1
    //   628: if_icmpne -> 636
    //   631: iconst_m1
    //   632: istore_3
    //   633: goto -> 638
    //   636: iconst_0
    //   637: istore_3
    //   638: aload #7
    //   640: iload_3
    //   641: invokevirtual setWidth : (I)V
    //   644: aload_0
    //   645: getfield D : Landroid/widget/PopupWindow;
    //   648: iconst_0
    //   649: invokevirtual setHeight : (I)V
    //   652: goto -> 704
    //   655: aload_0
    //   656: getfield D : Landroid/widget/PopupWindow;
    //   659: astore #7
    //   661: iload #4
    //   663: istore_3
    //   664: aload_0
    //   665: getfield i : I
    //   668: iconst_m1
    //   669: if_icmpne -> 674
    //   672: iconst_m1
    //   673: istore_3
    //   674: aload #7
    //   676: iload_3
    //   677: invokevirtual setWidth : (I)V
    //   680: aload_0
    //   681: getfield D : Landroid/widget/PopupWindow;
    //   684: iconst_m1
    //   685: invokevirtual setHeight : (I)V
    //   688: goto -> 704
    //   691: iload #5
    //   693: bipush #-2
    //   695: if_icmpne -> 701
    //   698: goto -> 704
    //   701: iload #5
    //   703: istore_1
    //   704: aload_0
    //   705: getfield D : Landroid/widget/PopupWindow;
    //   708: iconst_1
    //   709: invokevirtual setOutsideTouchable : (Z)V
    //   712: aload_0
    //   713: getfield D : Landroid/widget/PopupWindow;
    //   716: astore #7
    //   718: aload_0
    //   719: getfield t : Landroid/view/View;
    //   722: astore #8
    //   724: aload_0
    //   725: getfield j : I
    //   728: istore_3
    //   729: aload_0
    //   730: getfield k : I
    //   733: istore #4
    //   735: iload_2
    //   736: ifge -> 744
    //   739: iconst_m1
    //   740: istore_2
    //   741: goto -> 744
    //   744: iload_1
    //   745: ifge -> 753
    //   748: iconst_m1
    //   749: istore_1
    //   750: goto -> 753
    //   753: aload #7
    //   755: aload #8
    //   757: iload_3
    //   758: iload #4
    //   760: iload_2
    //   761: iload_1
    //   762: invokevirtual update : (Landroid/view/View;IIII)V
    //   765: return
    //   766: aload_0
    //   767: getfield i : I
    //   770: istore_3
    //   771: iload_3
    //   772: iconst_m1
    //   773: if_icmpne -> 781
    //   776: iconst_m1
    //   777: istore_2
    //   778: goto -> 797
    //   781: iload_3
    //   782: istore_2
    //   783: iload_3
    //   784: bipush #-2
    //   786: if_icmpne -> 797
    //   789: aload_0
    //   790: getfield t : Landroid/view/View;
    //   793: invokevirtual getWidth : ()I
    //   796: istore_2
    //   797: aload_0
    //   798: getfield h : I
    //   801: istore_3
    //   802: iload_3
    //   803: iconst_m1
    //   804: if_icmpne -> 812
    //   807: iconst_m1
    //   808: istore_1
    //   809: goto -> 823
    //   812: iload_3
    //   813: bipush #-2
    //   815: if_icmpne -> 821
    //   818: goto -> 823
    //   821: iload_3
    //   822: istore_1
    //   823: aload_0
    //   824: getfield D : Landroid/widget/PopupWindow;
    //   827: iload_2
    //   828: invokevirtual setWidth : (I)V
    //   831: aload_0
    //   832: getfield D : Landroid/widget/PopupWindow;
    //   835: iload_1
    //   836: invokevirtual setHeight : (I)V
    //   839: getstatic android/os/Build$VERSION.SDK_INT : I
    //   842: bipush #28
    //   844: if_icmpgt -> 892
    //   847: getstatic c/b/h/q1.E : Ljava/lang/reflect/Method;
    //   850: astore #7
    //   852: aload #7
    //   854: ifnull -> 900
    //   857: aload #7
    //   859: aload_0
    //   860: getfield D : Landroid/widget/PopupWindow;
    //   863: iconst_1
    //   864: anewarray java/lang/Object
    //   867: dup
    //   868: iconst_0
    //   869: getstatic java/lang/Boolean.TRUE : Ljava/lang/Boolean;
    //   872: aastore
    //   873: invokevirtual invoke : (Ljava/lang/Object;[Ljava/lang/Object;)Ljava/lang/Object;
    //   876: pop
    //   877: goto -> 900
    //   880: ldc 'ListPopupWindow'
    //   882: ldc_w 'Could not call setClipToScreenEnabled() on PopupWindow. Oh well.'
    //   885: invokestatic i : (Ljava/lang/String;Ljava/lang/String;)I
    //   888: pop
    //   889: goto -> 900
    //   892: aload_0
    //   893: getfield D : Landroid/widget/PopupWindow;
    //   896: iconst_1
    //   897: invokevirtual setIsClippedToScreen : (Z)V
    //   900: aload_0
    //   901: getfield D : Landroid/widget/PopupWindow;
    //   904: iconst_1
    //   905: invokevirtual setOutsideTouchable : (Z)V
    //   908: aload_0
    //   909: getfield D : Landroid/widget/PopupWindow;
    //   912: aload_0
    //   913: getfield w : Lc/b/h/o1;
    //   916: invokevirtual setTouchInterceptor : (Landroid/view/View$OnTouchListener;)V
    //   919: aload_0
    //   920: getfield o : Z
    //   923: ifeq -> 937
    //   926: aload_0
    //   927: getfield D : Landroid/widget/PopupWindow;
    //   930: aload_0
    //   931: getfield n : Z
    //   934: invokevirtual setOverlapAnchor : (Z)V
    //   937: getstatic android/os/Build$VERSION.SDK_INT : I
    //   940: bipush #28
    //   942: if_icmpgt -> 995
    //   945: getstatic c/b/h/q1.G : Ljava/lang/reflect/Method;
    //   948: astore #7
    //   950: aload #7
    //   952: ifnull -> 1006
    //   955: aload #7
    //   957: aload_0
    //   958: getfield D : Landroid/widget/PopupWindow;
    //   961: iconst_1
    //   962: anewarray java/lang/Object
    //   965: dup
    //   966: iconst_0
    //   967: aload_0
    //   968: getfield B : Landroid/graphics/Rect;
    //   971: aastore
    //   972: invokevirtual invoke : (Ljava/lang/Object;[Ljava/lang/Object;)Ljava/lang/Object;
    //   975: pop
    //   976: goto -> 1006
    //   979: astore #7
    //   981: ldc 'ListPopupWindow'
    //   983: ldc_w 'Could not invoke setEpicenterBounds on PopupWindow'
    //   986: aload #7
    //   988: invokestatic e : (Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)I
    //   991: pop
    //   992: goto -> 1006
    //   995: aload_0
    //   996: getfield D : Landroid/widget/PopupWindow;
    //   999: aload_0
    //   1000: getfield B : Landroid/graphics/Rect;
    //   1003: invokevirtual setEpicenterBounds : (Landroid/graphics/Rect;)V
    //   1006: aload_0
    //   1007: getfield D : Landroid/widget/PopupWindow;
    //   1010: aload_0
    //   1011: getfield t : Landroid/view/View;
    //   1014: aload_0
    //   1015: getfield j : I
    //   1018: aload_0
    //   1019: getfield k : I
    //   1022: aload_0
    //   1023: getfield p : I
    //   1026: invokevirtual showAsDropDown : (Landroid/view/View;III)V
    //   1029: aload_0
    //   1030: getfield g : Lc/b/h/f1;
    //   1033: iconst_m1
    //   1034: invokevirtual setSelection : (I)V
    //   1037: aload_0
    //   1038: getfield C : Z
    //   1041: ifeq -> 1054
    //   1044: aload_0
    //   1045: getfield g : Lc/b/h/f1;
    //   1048: invokevirtual isInTouchMode : ()Z
    //   1051: ifeq -> 1076
    //   1054: aload_0
    //   1055: getfield g : Lc/b/h/f1;
    //   1058: astore #7
    //   1060: aload #7
    //   1062: ifnull -> 1076
    //   1065: aload #7
    //   1067: iconst_1
    //   1068: invokevirtual setListSelectionHidden : (Z)V
    //   1071: aload #7
    //   1073: invokevirtual requestLayout : ()V
    //   1076: aload_0
    //   1077: getfield C : Z
    //   1080: ifne -> 1095
    //   1083: aload_0
    //   1084: getfield z : Landroid/os/Handler;
    //   1087: aload_0
    //   1088: getfield y : Lc/b/h/l1;
    //   1091: invokevirtual post : (Ljava/lang/Runnable;)Z
    //   1094: pop
    //   1095: return
    //   1096: astore #8
    //   1098: goto -> 289
    //   1101: astore #7
    //   1103: goto -> 880
    // Exception table:
    //   from	to	target	type
    //   246	286	1096	java/lang/Exception
    //   857	877	1101	java/lang/Exception
    //   955	976	979	java/lang/Exception
  }
  
  public void dismiss() {
    this.D.dismiss();
    this.D.setContentView(null);
    this.g = null;
    this.z.removeCallbacks(this.v);
  }
  
  public Drawable f() {
    return this.D.getBackground();
  }
  
  public ListView g() {
    return this.g;
  }
  
  public void i(Drawable paramDrawable) {
    this.D.setBackgroundDrawable(paramDrawable);
  }
  
  public void j(int paramInt) {
    this.k = paramInt;
    this.m = true;
  }
  
  public void l(int paramInt) {
    this.j = paramInt;
  }
  
  public int n() {
    return !this.m ? 0 : this.k;
  }
  
  public void p(ListAdapter paramListAdapter) {
    DataSetObserver dataSetObserver = this.s;
    if (dataSetObserver == null) {
      this.s = new m1(this);
    } else {
      ListAdapter listAdapter = this.f;
      if (listAdapter != null)
        listAdapter.unregisterDataSetObserver(dataSetObserver); 
    } 
    this.f = paramListAdapter;
    if (paramListAdapter != null)
      paramListAdapter.registerDataSetObserver(this.s); 
    f1 f11 = this.g;
    if (f11 != null)
      f11.setAdapter(this.f); 
  }
  
  public f1 q(Context paramContext, boolean paramBoolean) {
    return new f1(paramContext, paramBoolean);
  }
  
  public void r(int paramInt) {
    Drawable drawable = this.D.getBackground();
    if (drawable != null) {
      drawable.getPadding(this.A);
      Rect rect = this.A;
      this.i = rect.left + rect.right + paramInt;
      return;
    } 
    this.i = paramInt;
  }
  
  public void s(boolean paramBoolean) {
    this.C = paramBoolean;
    this.D.setFocusable(paramBoolean);
  }
}


/* Location:              C:\soft\dex2jar-2.0\Https Traffic-dex2jar.jar!\c\b\h\q1.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */