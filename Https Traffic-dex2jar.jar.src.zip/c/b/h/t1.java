package c.b.h;

import android.content.Context;
import android.os.Build;
import android.util.AttributeSet;
import android.util.Log;
import android.view.MenuItem;
import android.widget.PopupWindow;
import c.b.g.n.l;
import java.lang.reflect.Method;

public class t1 extends q1 implements r1 {
  public static Method I;
  
  public r1 H;
  
  static {
    try {
      if (Build.VERSION.SDK_INT <= 28) {
        I = PopupWindow.class.getDeclaredMethod("setTouchModal", new Class[] { boolean.class });
        return;
      } 
    } catch (NoSuchMethodException noSuchMethodException) {
      Log.i("MenuPopupWindow", "Could not find method setTouchModal() on PopupWindow. Oh well.");
    } 
  }
  
  public t1(Context paramContext, AttributeSet paramAttributeSet, int paramInt1, int paramInt2) {
    super(paramContext, null, paramInt1, paramInt2);
  }
  
  public void c(l paraml, MenuItem paramMenuItem) {
    r1 r11 = this.H;
    if (r11 != null)
      r11.c(paraml, paramMenuItem); 
  }
  
  public void e(l paraml, MenuItem paramMenuItem) {
    r1 r11 = this.H;
    if (r11 != null)
      r11.e(paraml, paramMenuItem); 
  }
  
  public f1 q(Context paramContext, boolean paramBoolean) {
    s1 s1 = new s1(paramContext, paramBoolean);
    s1.setHoverListener(this);
    return s1;
  }
}


/* Location:              C:\soft\dex2jar-2.0\Https Traffic-dex2jar.jar!\c\b\h\t1.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */