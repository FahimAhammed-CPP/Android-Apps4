package c.b.h;

import android.content.Context;
import android.graphics.Rect;
import android.view.LayoutInflater;
import android.view.View;
import android.view.WindowManager;
import android.widget.TextView;

public class r2 {
  public final Context a;
  
  public final View b;
  
  public final TextView c;
  
  public final WindowManager.LayoutParams d;
  
  public final Rect e;
  
  public final int[] f;
  
  public final int[] g;
  
  public r2(Context paramContext) {
    WindowManager.LayoutParams layoutParams = new WindowManager.LayoutParams();
    this.d = layoutParams;
    this.e = new Rect();
    this.f = new int[2];
    this.g = new int[2];
    this.a = paramContext;
    View view = LayoutInflater.from(paramContext).inflate(2131427355, null);
    this.b = view;
    this.c = (TextView)view.findViewById(2131230975);
    layoutParams.setTitle(r2.class.getSimpleName());
    layoutParams.packageName = paramContext.getPackageName();
    layoutParams.type = 1002;
    layoutParams.width = -2;
    layoutParams.height = -2;
    layoutParams.format = -3;
    layoutParams.windowAnimations = 2131820549;
    layoutParams.flags = 24;
  }
  
  public void a() {
    boolean bool;
    if (this.b.getParent() != null) {
      bool = true;
    } else {
      bool = false;
    } 
    if (!bool)
      return; 
    ((WindowManager)this.a.getSystemService("window")).removeView(this.b);
  }
}


/* Location:              C:\soft\dex2jar-2.0\Https Traffic-dex2jar.jar!\c\b\h\r2.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */