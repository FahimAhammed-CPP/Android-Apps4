package c.b.h;

import android.os.Parcel;
import android.os.Parcelable;
import androidx.appcompat.widget.SearchView;

public class c2 implements Parcelable.ClassLoaderCreator<SearchView.o> {
  public Object createFromParcel(Parcel paramParcel) {
    return new SearchView.o(paramParcel, null);
  }
  
  public Object createFromParcel(Parcel paramParcel, ClassLoader paramClassLoader) {
    return new SearchView.o(paramParcel, paramClassLoader);
  }
  
  public Object[] newArray(int paramInt) {
    return (Object[])new SearchView.o[paramInt];
  }
}


/* Location:              C:\soft\dex2jar-2.0\Https Traffic-dex2jar.jar!\c\b\h\c2.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */