package c.b.h;

import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;

public final class d2 {
  public final TextView a;
  
  public final TextView b;
  
  public final ImageView c;
  
  public final ImageView d;
  
  public final ImageView e;
  
  public d2(View paramView) {
    this.a = (TextView)paramView.findViewById(16908308);
    this.b = (TextView)paramView.findViewById(16908309);
    this.c = (ImageView)paramView.findViewById(16908295);
    this.d = (ImageView)paramView.findViewById(16908296);
    this.e = (ImageView)paramView.findViewById(2131230884);
  }
}


/* Location:              C:\soft\dex2jar-2.0\Https Traffic-dex2jar.jar!\c\b\h\d2.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */