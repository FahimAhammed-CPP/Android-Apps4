package c.b.h;

import android.view.View;
import c.b.g.n.l;

public class f implements Runnable {
  public i e;
  
  public f(m paramm, i parami) {
    this.e = parami;
  }
  
  public void run() {
    l l = this.f.g;
    if (l != null) {
      l.a a = l.e;
      if (a != null)
        a.b(l); 
    } 
    View view = (View)this.f.l;
    if (view != null && view.getWindowToken() != null && this.e.f())
      this.f.y = this.e; 
    this.f.A = null;
  }
}


/* Location:              C:\soft\dex2jar-2.0\Https Traffic-dex2jar.jar!\c\b\h\f.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */