package c.b.h;

import android.os.Parcel;
import android.os.Parcelable;

public class n0 implements Parcelable.Creator<o0> {
  public Object createFromParcel(Parcel paramParcel) {
    return new o0(paramParcel);
  }
  
  public Object[] newArray(int paramInt) {
    return (Object[])new o0[paramInt];
  }
}


/* Location:              C:\soft\dex2jar-2.0\Https Traffic-dex2jar.jar!\c\b\h\n0.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */