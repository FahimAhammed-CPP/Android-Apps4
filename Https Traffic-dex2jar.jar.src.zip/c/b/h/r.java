package c.b.h;

import android.content.Context;
import android.util.AttributeSet;
import android.view.ActionMode;
import android.view.View;
import android.view.inputmethod.EditorInfo;
import android.view.inputmethod.InputConnection;
import android.widget.CheckedTextView;
import android.widget.TextView;
import c.b.a;
import c.b.d.a.a;
import c.h.b.h;

public class r extends CheckedTextView {
  public static final int[] f = new int[] { 16843016 };
  
  public final t0 e;
  
  public r(Context paramContext, AttributeSet paramAttributeSet) {
    super(paramContext, paramAttributeSet, 16843720);
    f2.a((View)this, getContext());
    t0 t01 = new t0((TextView)this);
    this.e = t01;
    t01.e(paramAttributeSet, 16843720);
    t01.b();
    j2 j2 = j2.q(getContext(), paramAttributeSet, f, 16843720, 0);
    setCheckMarkDrawable(j2.g(0));
    j2.b.recycle();
  }
  
  public void drawableStateChanged() {
    super.drawableStateChanged();
    t0 t01 = this.e;
    if (t01 != null)
      t01.b(); 
  }
  
  public InputConnection onCreateInputConnection(EditorInfo paramEditorInfo) {
    InputConnection inputConnection = super.onCreateInputConnection(paramEditorInfo);
    a.e(inputConnection, paramEditorInfo, (View)this);
    return inputConnection;
  }
  
  public void setCheckMarkDrawable(int paramInt) {
    setCheckMarkDrawable(a.a(getContext(), paramInt));
  }
  
  public void setCustomSelectionActionModeCallback(ActionMode.Callback paramCallback) {
    super.setCustomSelectionActionModeCallback(h.n0((TextView)this, paramCallback));
  }
  
  public void setTextAppearance(Context paramContext, int paramInt) {
    super.setTextAppearance(paramContext, paramInt);
    t0 t01 = this.e;
    if (t01 != null)
      t01.f(paramContext, paramInt); 
  }
}


/* Location:              C:\soft\dex2jar-2.0\Https Traffic-dex2jar.jar!\c\b\h\r.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */