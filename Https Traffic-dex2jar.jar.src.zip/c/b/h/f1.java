package c.b.h;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Rect;
import android.graphics.drawable.Drawable;
import android.os.Build;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AbsListView;
import android.widget.ListAdapter;
import android.widget.ListView;
import c.h.k.d;
import java.lang.reflect.Field;

public class f1 extends ListView {
  public final Rect e = new Rect();
  
  public int f = 0;
  
  public int g = 0;
  
  public int h = 0;
  
  public int i = 0;
  
  public int j;
  
  public Field k;
  
  public d1 l;
  
  public boolean m;
  
  public boolean n;
  
  public boolean o;
  
  public d p;
  
  public e1 q;
  
  public f1(Context paramContext, boolean paramBoolean) {
    super(paramContext, null, 2130903333);
    this.n = paramBoolean;
    setCacheColorHint(0);
    try {
      Field field = AbsListView.class.getDeclaredField("mIsChildViewEnabled");
      this.k = field;
      field.setAccessible(true);
      return;
    } catch (NoSuchFieldException noSuchFieldException) {
      noSuchFieldException.printStackTrace();
      return;
    } 
  }
  
  public int a(int paramInt1, int paramInt2, int paramInt3) {
    int i = getListPaddingTop();
    int j = getListPaddingBottom();
    int k = getDividerHeight();
    Drawable drawable = getDivider();
    ListAdapter listAdapter = getAdapter();
    if (listAdapter == null)
      return i + j; 
    int n = i + j;
    if (k <= 0 || drawable == null)
      k = 0; 
    int i2 = listAdapter.getCount();
    int m = 0;
    j = m;
    i = j;
    drawable = null;
    int i1 = j;
    j = n;
    while (m < i2) {
      int i3 = listAdapter.getItemViewType(m);
      n = i1;
      if (i3 != i1) {
        drawable = null;
        n = i3;
      } 
      View view2 = listAdapter.getView(m, (View)drawable, (ViewGroup)this);
      ViewGroup.LayoutParams layoutParams2 = view2.getLayoutParams();
      ViewGroup.LayoutParams layoutParams1 = layoutParams2;
      if (layoutParams2 == null) {
        layoutParams1 = generateDefaultLayoutParams();
        view2.setLayoutParams(layoutParams1);
      } 
      i1 = layoutParams1.height;
      if (i1 > 0) {
        i1 = View.MeasureSpec.makeMeasureSpec(i1, 1073741824);
      } else {
        i1 = View.MeasureSpec.makeMeasureSpec(0, 0);
      } 
      view2.measure(paramInt1, i1);
      view2.forceLayout();
      i1 = j;
      if (m > 0)
        i1 = j + k; 
      j = i1 + view2.getMeasuredHeight();
      if (j >= paramInt2) {
        paramInt1 = paramInt2;
        if (paramInt3 >= 0) {
          paramInt1 = paramInt2;
          if (m > paramInt3) {
            paramInt1 = paramInt2;
            if (i > 0) {
              paramInt1 = paramInt2;
              if (j != paramInt2)
                paramInt1 = i; 
            } 
          } 
        } 
        return paramInt1;
      } 
      i3 = i;
      if (paramInt3 >= 0) {
        i3 = i;
        if (m >= paramInt3)
          i3 = j; 
      } 
      m++;
      i1 = n;
      View view1 = view2;
      i = i3;
    } 
    return j;
  }
  
  public boolean b(MotionEvent paramMotionEvent, int paramInt) {
    // Byte code:
    //   0: aload_1
    //   1: invokevirtual getActionMasked : ()I
    //   4: istore #7
    //   6: iconst_1
    //   7: istore #11
    //   9: iload #7
    //   11: iconst_1
    //   12: if_icmpeq -> 42
    //   15: iload #7
    //   17: iconst_2
    //   18: if_icmpeq -> 36
    //   21: iload #7
    //   23: iconst_3
    //   24: if_icmpeq -> 57
    //   27: iconst_1
    //   28: istore #10
    //   30: iconst_0
    //   31: istore #11
    //   33: goto -> 567
    //   36: iconst_1
    //   37: istore #10
    //   39: goto -> 45
    //   42: iconst_0
    //   43: istore #10
    //   45: aload_1
    //   46: iload_2
    //   47: invokevirtual findPointerIndex : (I)I
    //   50: istore #8
    //   52: iload #8
    //   54: ifge -> 67
    //   57: iconst_0
    //   58: istore #10
    //   60: iload #10
    //   62: istore #11
    //   64: goto -> 567
    //   67: aload_1
    //   68: iload #8
    //   70: invokevirtual getX : (I)F
    //   73: f2i
    //   74: istore_2
    //   75: aload_1
    //   76: iload #8
    //   78: invokevirtual getY : (I)F
    //   81: f2i
    //   82: istore #9
    //   84: aload_0
    //   85: iload_2
    //   86: iload #9
    //   88: invokevirtual pointToPosition : (II)I
    //   91: istore #8
    //   93: iload #8
    //   95: iconst_m1
    //   96: if_icmpne -> 102
    //   99: goto -> 567
    //   102: aload_0
    //   103: iload #8
    //   105: aload_0
    //   106: invokevirtual getFirstVisiblePosition : ()I
    //   109: isub
    //   110: invokevirtual getChildAt : (I)Landroid/view/View;
    //   113: astore #12
    //   115: iload_2
    //   116: i2f
    //   117: fstore_3
    //   118: iload #9
    //   120: i2f
    //   121: fstore #4
    //   123: aload_0
    //   124: iconst_1
    //   125: putfield o : Z
    //   128: aload_0
    //   129: fload_3
    //   130: fload #4
    //   132: invokevirtual drawableHotspotChanged : (FF)V
    //   135: aload_0
    //   136: invokevirtual isPressed : ()Z
    //   139: ifne -> 147
    //   142: aload_0
    //   143: iconst_1
    //   144: invokevirtual setPressed : (Z)V
    //   147: aload_0
    //   148: invokevirtual layoutChildren : ()V
    //   151: aload_0
    //   152: getfield j : I
    //   155: istore_2
    //   156: iload_2
    //   157: iconst_m1
    //   158: if_icmpeq -> 199
    //   161: aload_0
    //   162: iload_2
    //   163: aload_0
    //   164: invokevirtual getFirstVisiblePosition : ()I
    //   167: isub
    //   168: invokevirtual getChildAt : (I)Landroid/view/View;
    //   171: astore #13
    //   173: aload #13
    //   175: ifnull -> 199
    //   178: aload #13
    //   180: aload #12
    //   182: if_acmpeq -> 199
    //   185: aload #13
    //   187: invokevirtual isPressed : ()Z
    //   190: ifeq -> 199
    //   193: aload #13
    //   195: iconst_0
    //   196: invokevirtual setPressed : (Z)V
    //   199: aload_0
    //   200: iload #8
    //   202: putfield j : I
    //   205: aload #12
    //   207: fload_3
    //   208: aload #12
    //   210: invokevirtual getLeft : ()I
    //   213: i2f
    //   214: fsub
    //   215: fload #4
    //   217: aload #12
    //   219: invokevirtual getTop : ()I
    //   222: i2f
    //   223: fsub
    //   224: invokevirtual drawableHotspotChanged : (FF)V
    //   227: aload #12
    //   229: invokevirtual isPressed : ()Z
    //   232: ifne -> 241
    //   235: aload #12
    //   237: iconst_1
    //   238: invokevirtual setPressed : (Z)V
    //   241: aload_0
    //   242: invokevirtual getSelector : ()Landroid/graphics/drawable/Drawable;
    //   245: astore #13
    //   247: aload #13
    //   249: ifnull -> 263
    //   252: iload #8
    //   254: iconst_m1
    //   255: if_icmpeq -> 263
    //   258: iconst_1
    //   259: istore_2
    //   260: goto -> 265
    //   263: iconst_0
    //   264: istore_2
    //   265: iload_2
    //   266: ifeq -> 277
    //   269: aload #13
    //   271: iconst_0
    //   272: iconst_0
    //   273: invokevirtual setVisible : (ZZ)Z
    //   276: pop
    //   277: aload_0
    //   278: getfield e : Landroid/graphics/Rect;
    //   281: astore #14
    //   283: aload #14
    //   285: aload #12
    //   287: invokevirtual getLeft : ()I
    //   290: aload #12
    //   292: invokevirtual getTop : ()I
    //   295: aload #12
    //   297: invokevirtual getRight : ()I
    //   300: aload #12
    //   302: invokevirtual getBottom : ()I
    //   305: invokevirtual set : (IIII)V
    //   308: aload #14
    //   310: aload #14
    //   312: getfield left : I
    //   315: aload_0
    //   316: getfield f : I
    //   319: isub
    //   320: putfield left : I
    //   323: aload #14
    //   325: aload #14
    //   327: getfield top : I
    //   330: aload_0
    //   331: getfield g : I
    //   334: isub
    //   335: putfield top : I
    //   338: aload #14
    //   340: aload #14
    //   342: getfield right : I
    //   345: aload_0
    //   346: getfield h : I
    //   349: iadd
    //   350: putfield right : I
    //   353: aload #14
    //   355: aload #14
    //   357: getfield bottom : I
    //   360: aload_0
    //   361: getfield i : I
    //   364: iadd
    //   365: putfield bottom : I
    //   368: aload_0
    //   369: getfield k : Ljava/lang/reflect/Field;
    //   372: aload_0
    //   373: invokevirtual getBoolean : (Ljava/lang/Object;)Z
    //   376: istore #10
    //   378: aload #12
    //   380: invokevirtual isEnabled : ()Z
    //   383: iload #10
    //   385: if_icmpeq -> 436
    //   388: aload_0
    //   389: getfield k : Ljava/lang/reflect/Field;
    //   392: astore #14
    //   394: iload #10
    //   396: ifne -> 699
    //   399: iconst_1
    //   400: istore #10
    //   402: goto -> 405
    //   405: aload #14
    //   407: aload_0
    //   408: iload #10
    //   410: invokestatic valueOf : (Z)Ljava/lang/Boolean;
    //   413: invokevirtual set : (Ljava/lang/Object;Ljava/lang/Object;)V
    //   416: iload #8
    //   418: iconst_m1
    //   419: if_icmpeq -> 436
    //   422: aload_0
    //   423: invokevirtual refreshDrawableState : ()V
    //   426: goto -> 436
    //   429: astore #14
    //   431: aload #14
    //   433: invokevirtual printStackTrace : ()V
    //   436: iload_2
    //   437: ifeq -> 494
    //   440: aload_0
    //   441: getfield e : Landroid/graphics/Rect;
    //   444: astore #14
    //   446: aload #14
    //   448: invokevirtual exactCenterX : ()F
    //   451: fstore #5
    //   453: aload #14
    //   455: invokevirtual exactCenterY : ()F
    //   458: fstore #6
    //   460: aload_0
    //   461: invokevirtual getVisibility : ()I
    //   464: ifne -> 473
    //   467: iconst_1
    //   468: istore #10
    //   470: goto -> 476
    //   473: iconst_0
    //   474: istore #10
    //   476: aload #13
    //   478: iload #10
    //   480: iconst_0
    //   481: invokevirtual setVisible : (ZZ)Z
    //   484: pop
    //   485: aload #13
    //   487: fload #5
    //   489: fload #6
    //   491: invokevirtual setHotspot : (FF)V
    //   494: aload_0
    //   495: invokevirtual getSelector : ()Landroid/graphics/drawable/Drawable;
    //   498: astore #13
    //   500: aload #13
    //   502: ifnull -> 519
    //   505: iload #8
    //   507: iconst_m1
    //   508: if_icmpeq -> 519
    //   511: aload #13
    //   513: fload_3
    //   514: fload #4
    //   516: invokevirtual setHotspot : (FF)V
    //   519: aload_0
    //   520: getfield l : Lc/b/h/d1;
    //   523: astore #13
    //   525: aload #13
    //   527: ifnull -> 536
    //   530: aload #13
    //   532: iconst_0
    //   533: putfield f : Z
    //   536: aload_0
    //   537: invokevirtual refreshDrawableState : ()V
    //   540: iload #7
    //   542: iconst_1
    //   543: if_icmpne -> 561
    //   546: aload_0
    //   547: aload #12
    //   549: iload #8
    //   551: aload_0
    //   552: iload #8
    //   554: invokevirtual getItemIdAtPosition : (I)J
    //   557: invokevirtual performItemClick : (Landroid/view/View;IJ)Z
    //   560: pop
    //   561: iconst_0
    //   562: istore #11
    //   564: iconst_1
    //   565: istore #10
    //   567: iload #10
    //   569: ifeq -> 577
    //   572: iload #11
    //   574: ifeq -> 617
    //   577: aload_0
    //   578: iconst_0
    //   579: putfield o : Z
    //   582: aload_0
    //   583: iconst_0
    //   584: invokevirtual setPressed : (Z)V
    //   587: aload_0
    //   588: invokevirtual drawableStateChanged : ()V
    //   591: aload_0
    //   592: aload_0
    //   593: getfield j : I
    //   596: aload_0
    //   597: invokevirtual getFirstVisiblePosition : ()I
    //   600: isub
    //   601: invokevirtual getChildAt : (I)Landroid/view/View;
    //   604: astore #12
    //   606: aload #12
    //   608: ifnull -> 617
    //   611: aload #12
    //   613: iconst_0
    //   614: invokevirtual setPressed : (Z)V
    //   617: iload #10
    //   619: ifeq -> 671
    //   622: aload_0
    //   623: getfield p : Lc/h/k/d;
    //   626: ifnonnull -> 641
    //   629: aload_0
    //   630: new c/h/k/d
    //   633: dup
    //   634: aload_0
    //   635: invokespecial <init> : (Landroid/widget/ListView;)V
    //   638: putfield p : Lc/h/k/d;
    //   641: aload_0
    //   642: getfield p : Lc/h/k/d;
    //   645: astore #12
    //   647: aload #12
    //   649: getfield t : Z
    //   652: istore #11
    //   654: aload #12
    //   656: iconst_1
    //   657: putfield t : Z
    //   660: aload #12
    //   662: aload_0
    //   663: aload_1
    //   664: invokevirtual onTouch : (Landroid/view/View;Landroid/view/MotionEvent;)Z
    //   667: pop
    //   668: iload #10
    //   670: ireturn
    //   671: aload_0
    //   672: getfield p : Lc/h/k/d;
    //   675: astore_1
    //   676: aload_1
    //   677: ifnull -> 696
    //   680: aload_1
    //   681: getfield t : Z
    //   684: ifeq -> 691
    //   687: aload_1
    //   688: invokevirtual g : ()V
    //   691: aload_1
    //   692: iconst_0
    //   693: putfield t : Z
    //   696: iload #10
    //   698: ireturn
    //   699: iconst_0
    //   700: istore #10
    //   702: goto -> 405
    // Exception table:
    //   from	to	target	type
    //   368	394	429	java/lang/IllegalAccessException
    //   405	416	429	java/lang/IllegalAccessException
    //   422	426	429	java/lang/IllegalAccessException
  }
  
  public final void c() {
    Drawable drawable = getSelector();
    if (drawable != null && this.o && isPressed())
      drawable.setState(getDrawableState()); 
  }
  
  public void dispatchDraw(Canvas paramCanvas) {
    if (!this.e.isEmpty()) {
      Drawable drawable = getSelector();
      if (drawable != null) {
        drawable.setBounds(this.e);
        drawable.draw(paramCanvas);
      } 
    } 
    super.dispatchDraw(paramCanvas);
  }
  
  public void drawableStateChanged() {
    if (this.q != null)
      return; 
    super.drawableStateChanged();
    d1 d11 = this.l;
    if (d11 != null)
      d11.f = true; 
    c();
  }
  
  public boolean hasFocus() {
    return (this.n || super.hasFocus());
  }
  
  public boolean hasWindowFocus() {
    return (this.n || super.hasWindowFocus());
  }
  
  public boolean isFocused() {
    return (this.n || super.isFocused());
  }
  
  public boolean isInTouchMode() {
    return ((this.n && this.m) || super.isInTouchMode());
  }
  
  public void onDetachedFromWindow() {
    this.q = null;
    super.onDetachedFromWindow();
  }
  
  public boolean onHoverEvent(MotionEvent paramMotionEvent) {
    if (Build.VERSION.SDK_INT < 26)
      return super.onHoverEvent(paramMotionEvent); 
    int i = paramMotionEvent.getActionMasked();
    if (i == 10 && this.q == null) {
      e1 e11 = new e1(this);
      this.q = e11;
      post(e11);
    } 
    boolean bool = super.onHoverEvent(paramMotionEvent);
    if (i == 9 || i == 7) {
      i = pointToPosition((int)paramMotionEvent.getX(), (int)paramMotionEvent.getY());
      if (i != -1 && i != getSelectedItemPosition()) {
        View view = getChildAt(i - getFirstVisiblePosition());
        if (view.isEnabled())
          setSelectionFromTop(i, view.getTop() - getTop()); 
        c();
      } 
      return bool;
    } 
    setSelection(-1);
    return bool;
  }
  
  public boolean onTouchEvent(MotionEvent paramMotionEvent) {
    if (paramMotionEvent.getAction() == 0)
      this.j = pointToPosition((int)paramMotionEvent.getX(), (int)paramMotionEvent.getY()); 
    e1 e11 = this.q;
    if (e11 != null) {
      f1 f11 = e11.e;
      f11.q = null;
      f11.removeCallbacks(e11);
    } 
    return super.onTouchEvent(paramMotionEvent);
  }
  
  public void setListSelectionHidden(boolean paramBoolean) {
    this.m = paramBoolean;
  }
  
  public void setSelector(Drawable paramDrawable) {
    d1 d11;
    if (paramDrawable != null) {
      d11 = new d1(paramDrawable);
    } else {
      d11 = null;
    } 
    this.l = d11;
    super.setSelector(d11);
    Rect rect = new Rect();
    if (paramDrawable != null)
      paramDrawable.getPadding(rect); 
    this.f = rect.left;
    this.g = rect.top;
    this.h = rect.right;
    this.i = rect.bottom;
  }
}


/* Location:              C:\soft\dex2jar-2.0\Https Traffic-dex2jar.jar!\c\b\h\f1.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */