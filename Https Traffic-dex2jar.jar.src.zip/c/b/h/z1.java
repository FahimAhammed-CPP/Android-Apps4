package c.b.h;

import android.content.Context;
import android.content.res.ColorStateList;
import android.content.res.Resources;
import android.content.res.XmlResourceParser;
import android.graphics.PorterDuff;
import android.graphics.PorterDuffColorFilter;
import android.graphics.drawable.Drawable;
import android.graphics.drawable.LayerDrawable;
import android.util.AttributeSet;
import android.util.Log;
import android.util.TypedValue;
import android.util.Xml;
import c.e.f;
import c.e.i;
import c.e.j;
import java.lang.ref.WeakReference;
import java.util.Objects;
import java.util.WeakHashMap;
import org.xmlpull.v1.XmlPullParser;
import org.xmlpull.v1.XmlPullParserException;

public final class z1 {
  public static final PorterDuff.Mode h = PorterDuff.Mode.SRC_IN;
  
  public static z1 i;
  
  public static final w1 j = new w1(6);
  
  public WeakHashMap<Context, j<ColorStateList>> a;
  
  public i<String, x1> b;
  
  public j<String> c;
  
  public final WeakHashMap<Context, f<WeakReference<Drawable.ConstantState>>> d = new WeakHashMap<Context, f<WeakReference<Drawable.ConstantState>>>(0);
  
  public TypedValue e;
  
  public boolean f;
  
  public t g;
  
  public static z1 d() {
    // Byte code:
    //   0: ldc c/b/h/z1
    //   2: monitorenter
    //   3: getstatic c/b/h/z1.i : Lc/b/h/z1;
    //   6: ifnonnull -> 68
    //   9: new c/b/h/z1
    //   12: dup
    //   13: invokespecial <init> : ()V
    //   16: astore_0
    //   17: aload_0
    //   18: putstatic c/b/h/z1.i : Lc/b/h/z1;
    //   21: getstatic android/os/Build$VERSION.SDK_INT : I
    //   24: bipush #24
    //   26: if_icmpge -> 68
    //   29: aload_0
    //   30: ldc 'vector'
    //   32: new c/b/h/y1
    //   35: dup
    //   36: invokespecial <init> : ()V
    //   39: invokevirtual a : (Ljava/lang/String;Lc/b/h/x1;)V
    //   42: aload_0
    //   43: ldc 'animated-vector'
    //   45: new c/b/h/v1
    //   48: dup
    //   49: invokespecial <init> : ()V
    //   52: invokevirtual a : (Ljava/lang/String;Lc/b/h/x1;)V
    //   55: aload_0
    //   56: ldc 'animated-selector'
    //   58: new c/b/h/u1
    //   61: dup
    //   62: invokespecial <init> : ()V
    //   65: invokevirtual a : (Ljava/lang/String;Lc/b/h/x1;)V
    //   68: getstatic c/b/h/z1.i : Lc/b/h/z1;
    //   71: astore_0
    //   72: ldc c/b/h/z1
    //   74: monitorexit
    //   75: aload_0
    //   76: areturn
    //   77: astore_0
    //   78: ldc c/b/h/z1
    //   80: monitorexit
    //   81: aload_0
    //   82: athrow
    // Exception table:
    //   from	to	target	type
    //   3	68	77	finally
    //   68	72	77	finally
  }
  
  public static PorterDuffColorFilter h(int paramInt, PorterDuff.Mode paramMode) {
    // Byte code:
    //   0: ldc c/b/h/z1
    //   2: monitorenter
    //   3: getstatic c/b/h/z1.j : Lc/b/h/w1;
    //   6: astore #5
    //   8: aload #5
    //   10: invokestatic requireNonNull : (Ljava/lang/Object;)Ljava/lang/Object;
    //   13: pop
    //   14: iload_0
    //   15: bipush #31
    //   17: iadd
    //   18: bipush #31
    //   20: imul
    //   21: istore_2
    //   22: aload #5
    //   24: aload_1
    //   25: invokevirtual hashCode : ()I
    //   28: iload_2
    //   29: iadd
    //   30: invokestatic valueOf : (I)Ljava/lang/Integer;
    //   33: invokevirtual a : (Ljava/lang/Object;)Ljava/lang/Object;
    //   36: checkcast android/graphics/PorterDuffColorFilter
    //   39: astore #4
    //   41: aload #4
    //   43: astore_3
    //   44: aload #4
    //   46: ifnonnull -> 84
    //   49: new android/graphics/PorterDuffColorFilter
    //   52: dup
    //   53: iload_0
    //   54: aload_1
    //   55: invokespecial <init> : (ILandroid/graphics/PorterDuff$Mode;)V
    //   58: astore_3
    //   59: aload #5
    //   61: invokestatic requireNonNull : (Ljava/lang/Object;)Ljava/lang/Object;
    //   64: pop
    //   65: aload #5
    //   67: aload_1
    //   68: invokevirtual hashCode : ()I
    //   71: iload_2
    //   72: iadd
    //   73: invokestatic valueOf : (I)Ljava/lang/Integer;
    //   76: aload_3
    //   77: invokevirtual b : (Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    //   80: checkcast android/graphics/PorterDuffColorFilter
    //   83: astore_1
    //   84: ldc c/b/h/z1
    //   86: monitorexit
    //   87: aload_3
    //   88: areturn
    //   89: astore_1
    //   90: ldc c/b/h/z1
    //   92: monitorexit
    //   93: aload_1
    //   94: athrow
    // Exception table:
    //   from	to	target	type
    //   3	14	89	finally
    //   22	41	89	finally
    //   49	84	89	finally
  }
  
  public final void a(String paramString, x1 paramx1) {
    if (this.b == null)
      this.b = new i(); 
    this.b.put(paramString, paramx1);
  }
  
  public final boolean b(Context paramContext, long paramLong, Drawable paramDrawable) {
    // Byte code:
    //   0: aload_0
    //   1: monitorenter
    //   2: aload #4
    //   4: invokevirtual getConstantState : ()Landroid/graphics/drawable/Drawable$ConstantState;
    //   7: astore #6
    //   9: aload #6
    //   11: ifnull -> 75
    //   14: aload_0
    //   15: getfield d : Ljava/util/WeakHashMap;
    //   18: aload_1
    //   19: invokevirtual get : (Ljava/lang/Object;)Ljava/lang/Object;
    //   22: checkcast c/e/f
    //   25: astore #5
    //   27: aload #5
    //   29: astore #4
    //   31: aload #5
    //   33: ifnonnull -> 56
    //   36: new c/e/f
    //   39: dup
    //   40: invokespecial <init> : ()V
    //   43: astore #4
    //   45: aload_0
    //   46: getfield d : Ljava/util/WeakHashMap;
    //   49: aload_1
    //   50: aload #4
    //   52: invokevirtual put : (Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    //   55: pop
    //   56: aload #4
    //   58: lload_2
    //   59: new java/lang/ref/WeakReference
    //   62: dup
    //   63: aload #6
    //   65: invokespecial <init> : (Ljava/lang/Object;)V
    //   68: invokevirtual g : (JLjava/lang/Object;)V
    //   71: aload_0
    //   72: monitorexit
    //   73: iconst_1
    //   74: ireturn
    //   75: aload_0
    //   76: monitorexit
    //   77: iconst_0
    //   78: ireturn
    //   79: astore_1
    //   80: aload_0
    //   81: monitorexit
    //   82: aload_1
    //   83: athrow
    // Exception table:
    //   from	to	target	type
    //   2	9	79	finally
    //   14	27	79	finally
    //   36	56	79	finally
    //   56	71	79	finally
  }
  
  public final Drawable c(Context paramContext, int paramInt) {
    LayerDrawable layerDrawable;
    if (this.e == null)
      this.e = new TypedValue(); 
    TypedValue typedValue = this.e;
    paramContext.getResources().getValue(paramInt, typedValue, true);
    long l = typedValue.assetCookie << 32L | typedValue.data;
    Drawable drawable = e(paramContext, l);
    if (drawable != null)
      return drawable; 
    t t1 = this.g;
    drawable = null;
    if (t1 != null && paramInt == 2131165207)
      layerDrawable = new LayerDrawable(new Drawable[] { f(paramContext, 2131165206), f(paramContext, 2131165208) }); 
    if (layerDrawable != null) {
      layerDrawable.setChangingConfigurations(typedValue.changingConfigurations);
      b(paramContext, l, (Drawable)layerDrawable);
    } 
    return (Drawable)layerDrawable;
  }
  
  public final Drawable e(Context paramContext, long paramLong) {
    // Byte code:
    //   0: aload_0
    //   1: monitorenter
    //   2: aload_0
    //   3: getfield d : Ljava/util/WeakHashMap;
    //   6: aload_1
    //   7: invokevirtual get : (Ljava/lang/Object;)Ljava/lang/Object;
    //   10: checkcast c/e/f
    //   13: astore #5
    //   15: aload #5
    //   17: ifnonnull -> 24
    //   20: aload_0
    //   21: monitorexit
    //   22: aconst_null
    //   23: areturn
    //   24: aload #5
    //   26: lload_2
    //   27: aconst_null
    //   28: invokevirtual f : (JLjava/lang/Object;)Ljava/lang/Object;
    //   31: checkcast java/lang/ref/WeakReference
    //   34: astore #6
    //   36: aload #6
    //   38: ifnull -> 127
    //   41: aload #6
    //   43: invokevirtual get : ()Ljava/lang/Object;
    //   46: checkcast android/graphics/drawable/Drawable$ConstantState
    //   49: astore #6
    //   51: aload #6
    //   53: ifnull -> 70
    //   56: aload #6
    //   58: aload_1
    //   59: invokevirtual getResources : ()Landroid/content/res/Resources;
    //   62: invokevirtual newDrawable : (Landroid/content/res/Resources;)Landroid/graphics/drawable/Drawable;
    //   65: astore_1
    //   66: aload_0
    //   67: monitorexit
    //   68: aload_1
    //   69: areturn
    //   70: aload #5
    //   72: getfield f : [J
    //   75: aload #5
    //   77: getfield h : I
    //   80: lload_2
    //   81: invokestatic b : ([JIJ)I
    //   84: istore #4
    //   86: iload #4
    //   88: iflt -> 127
    //   91: aload #5
    //   93: getfield g : [Ljava/lang/Object;
    //   96: astore_1
    //   97: aload_1
    //   98: iload #4
    //   100: aaload
    //   101: astore #6
    //   103: getstatic c/e/f.i : Ljava/lang/Object;
    //   106: astore #7
    //   108: aload #6
    //   110: aload #7
    //   112: if_acmpeq -> 127
    //   115: aload_1
    //   116: iload #4
    //   118: aload #7
    //   120: aastore
    //   121: aload #5
    //   123: iconst_1
    //   124: putfield e : Z
    //   127: aload_0
    //   128: monitorexit
    //   129: aconst_null
    //   130: areturn
    //   131: astore_1
    //   132: aload_0
    //   133: monitorexit
    //   134: aload_1
    //   135: athrow
    // Exception table:
    //   from	to	target	type
    //   2	15	131	finally
    //   24	36	131	finally
    //   41	51	131	finally
    //   56	66	131	finally
    //   70	86	131	finally
    //   91	97	131	finally
    //   103	108	131	finally
    //   121	127	131	finally
  }
  
  public Drawable f(Context paramContext, int paramInt) {
    // Byte code:
    //   0: aload_0
    //   1: monitorenter
    //   2: aload_0
    //   3: aload_1
    //   4: iload_2
    //   5: iconst_0
    //   6: invokevirtual g : (Landroid/content/Context;IZ)Landroid/graphics/drawable/Drawable;
    //   9: astore_1
    //   10: aload_0
    //   11: monitorexit
    //   12: aload_1
    //   13: areturn
    //   14: astore_1
    //   15: aload_0
    //   16: monitorexit
    //   17: aload_1
    //   18: athrow
    // Exception table:
    //   from	to	target	type
    //   2	10	14	finally
  }
  
  public Drawable g(Context paramContext, int paramInt, boolean paramBoolean) {
    // Byte code:
    //   0: aload_0
    //   1: monitorenter
    //   2: aload_0
    //   3: getfield f : Z
    //   6: ifeq -> 12
    //   9: goto -> 69
    //   12: iconst_1
    //   13: istore #5
    //   15: aload_0
    //   16: iconst_1
    //   17: putfield f : Z
    //   20: aload_0
    //   21: aload_1
    //   22: ldc 2131165276
    //   24: invokevirtual f : (Landroid/content/Context;I)Landroid/graphics/drawable/Drawable;
    //   27: astore #6
    //   29: aload #6
    //   31: ifnull -> 153
    //   34: iload #5
    //   36: istore #4
    //   38: aload #6
    //   40: instanceof c/z/a/a/s
    //   43: ifne -> 176
    //   46: ldc 'android.graphics.drawable.VectorDrawable'
    //   48: aload #6
    //   50: invokevirtual getClass : ()Ljava/lang/Class;
    //   53: invokevirtual getName : ()Ljava/lang/String;
    //   56: invokevirtual equals : (Ljava/lang/Object;)Z
    //   59: ifeq -> 173
    //   62: iload #5
    //   64: istore #4
    //   66: goto -> 176
    //   69: aload_0
    //   70: aload_1
    //   71: iload_2
    //   72: invokevirtual j : (Landroid/content/Context;I)Landroid/graphics/drawable/Drawable;
    //   75: astore #7
    //   77: aload #7
    //   79: astore #6
    //   81: aload #7
    //   83: ifnonnull -> 94
    //   86: aload_0
    //   87: aload_1
    //   88: iload_2
    //   89: invokevirtual c : (Landroid/content/Context;I)Landroid/graphics/drawable/Drawable;
    //   92: astore #6
    //   94: aload #6
    //   96: astore #7
    //   98: aload #6
    //   100: ifnonnull -> 115
    //   103: getstatic c/h/b/b.a : Ljava/lang/Object;
    //   106: astore #6
    //   108: aload_1
    //   109: iload_2
    //   110: invokestatic b : (Landroid/content/Context;I)Landroid/graphics/drawable/Drawable;
    //   113: astore #7
    //   115: aload #7
    //   117: astore #6
    //   119: aload #7
    //   121: ifnull -> 135
    //   124: aload_0
    //   125: aload_1
    //   126: iload_2
    //   127: iload_3
    //   128: aload #7
    //   130: invokevirtual k : (Landroid/content/Context;IZLandroid/graphics/drawable/Drawable;)Landroid/graphics/drawable/Drawable;
    //   133: astore #6
    //   135: aload #6
    //   137: ifnull -> 144
    //   140: getstatic c/b/h/c1.a : [I
    //   143: astore_1
    //   144: aload_0
    //   145: monitorexit
    //   146: aload #6
    //   148: areturn
    //   149: astore_1
    //   150: goto -> 169
    //   153: aload_0
    //   154: iconst_0
    //   155: putfield f : Z
    //   158: new java/lang/IllegalStateException
    //   161: dup
    //   162: ldc_w 'This app has been built with an incorrect configuration. Please configure your build for VectorDrawableCompat.'
    //   165: invokespecial <init> : (Ljava/lang/String;)V
    //   168: athrow
    //   169: aload_0
    //   170: monitorexit
    //   171: aload_1
    //   172: athrow
    //   173: iconst_0
    //   174: istore #4
    //   176: iload #4
    //   178: ifeq -> 153
    //   181: goto -> 69
    // Exception table:
    //   from	to	target	type
    //   2	9	149	finally
    //   15	29	149	finally
    //   38	62	149	finally
    //   69	77	149	finally
    //   86	94	149	finally
    //   103	115	149	finally
    //   124	135	149	finally
    //   140	144	149	finally
    //   153	169	149	finally
  }
  
  public ColorStateList i(Context paramContext, int paramInt) {
    // Byte code:
    //   0: aload_0
    //   1: monitorenter
    //   2: aload_0
    //   3: getfield a : Ljava/util/WeakHashMap;
    //   6: astore_3
    //   7: aconst_null
    //   8: astore #5
    //   10: aload_3
    //   11: ifnull -> 161
    //   14: aload_3
    //   15: aload_1
    //   16: invokevirtual get : (Ljava/lang/Object;)Ljava/lang/Object;
    //   19: checkcast c/e/j
    //   22: astore_3
    //   23: aload_3
    //   24: ifnull -> 161
    //   27: aload_3
    //   28: iload_2
    //   29: aconst_null
    //   30: invokevirtual e : (ILjava/lang/Object;)Ljava/lang/Object;
    //   33: checkcast android/content/res/ColorStateList
    //   36: astore_3
    //   37: goto -> 40
    //   40: aload_3
    //   41: astore #4
    //   43: aload_3
    //   44: ifnonnull -> 152
    //   47: aload_0
    //   48: getfield g : Lc/b/h/t;
    //   51: astore_3
    //   52: aload_3
    //   53: ifnonnull -> 62
    //   56: aload #5
    //   58: astore_3
    //   59: goto -> 69
    //   62: aload_3
    //   63: aload_1
    //   64: iload_2
    //   65: invokevirtual c : (Landroid/content/Context;I)Landroid/content/res/ColorStateList;
    //   68: astore_3
    //   69: aload_3
    //   70: ifnull -> 142
    //   73: aload_0
    //   74: getfield a : Ljava/util/WeakHashMap;
    //   77: ifnonnull -> 91
    //   80: aload_0
    //   81: new java/util/WeakHashMap
    //   84: dup
    //   85: invokespecial <init> : ()V
    //   88: putfield a : Ljava/util/WeakHashMap;
    //   91: aload_0
    //   92: getfield a : Ljava/util/WeakHashMap;
    //   95: aload_1
    //   96: invokevirtual get : (Ljava/lang/Object;)Ljava/lang/Object;
    //   99: checkcast c/e/j
    //   102: astore #5
    //   104: aload #5
    //   106: astore #4
    //   108: aload #5
    //   110: ifnonnull -> 135
    //   113: new c/e/j
    //   116: dup
    //   117: bipush #10
    //   119: invokespecial <init> : (I)V
    //   122: astore #4
    //   124: aload_0
    //   125: getfield a : Ljava/util/WeakHashMap;
    //   128: aload_1
    //   129: aload #4
    //   131: invokevirtual put : (Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    //   134: pop
    //   135: aload #4
    //   137: iload_2
    //   138: aload_3
    //   139: invokevirtual a : (ILjava/lang/Object;)V
    //   142: aload_3
    //   143: astore #4
    //   145: goto -> 152
    //   148: astore_1
    //   149: goto -> 157
    //   152: aload_0
    //   153: monitorexit
    //   154: aload #4
    //   156: areturn
    //   157: aload_0
    //   158: monitorexit
    //   159: aload_1
    //   160: athrow
    //   161: aconst_null
    //   162: astore_3
    //   163: goto -> 40
    // Exception table:
    //   from	to	target	type
    //   2	7	148	finally
    //   14	23	148	finally
    //   27	37	148	finally
    //   47	52	148	finally
    //   62	69	148	finally
    //   73	91	148	finally
    //   91	104	148	finally
    //   113	135	148	finally
    //   135	142	148	finally
  }
  
  public final Drawable j(Context paramContext, int paramInt) {
    i<String, x1> i1 = this.b;
    if (i1 != null && !i1.isEmpty()) {
      j<String> j1 = this.c;
      if (j1 != null) {
        String str = (String)j1.e(paramInt, null);
        if ("appcompat_skip_skip".equals(str) || (str != null && this.b.getOrDefault(str, null) == null))
          return null; 
      } else {
        this.c = new j(10);
      } 
      if (this.e == null)
        this.e = new TypedValue(); 
      TypedValue typedValue = this.e;
      Resources resources = paramContext.getResources();
      resources.getValue(paramInt, typedValue, true);
      long l = typedValue.assetCookie << 32L | typedValue.data;
      Drawable drawable1 = e(paramContext, l);
      if (drawable1 != null)
        return drawable1; 
      CharSequence charSequence = typedValue.string;
      Drawable drawable2 = drawable1;
      if (charSequence != null) {
        drawable2 = drawable1;
        if (charSequence.toString().endsWith(".xml")) {
          drawable2 = drawable1;
          try {
            int k;
            XmlResourceParser xmlResourceParser = resources.getXml(paramInt);
            drawable2 = drawable1;
            AttributeSet attributeSet = Xml.asAttributeSet((XmlPullParser)xmlResourceParser);
            while (true) {
              drawable2 = drawable1;
              k = xmlResourceParser.next();
              if (k != 2 && k != 1)
                continue; 
              break;
            } 
            if (k == 2) {
              drawable2 = drawable1;
              String str = xmlResourceParser.getName();
              drawable2 = drawable1;
              this.c.a(paramInt, str);
              drawable2 = drawable1;
              x1 x1 = (x1)this.b.get(str);
              Drawable drawable = drawable1;
              if (x1 != null) {
                drawable2 = drawable1;
                drawable = x1.a(paramContext, (XmlPullParser)xmlResourceParser, attributeSet, paramContext.getTheme());
              } 
              drawable2 = drawable;
              if (drawable != null) {
                drawable2 = drawable;
                drawable.setChangingConfigurations(typedValue.changingConfigurations);
                drawable2 = drawable;
                b(paramContext, l, drawable);
                drawable2 = drawable;
              } 
            } else {
              drawable2 = drawable1;
              throw new XmlPullParserException("No start tag found");
            } 
          } catch (Exception exception) {
            Log.e("ResourceManagerInternal", "Exception while inflating drawable", exception);
          } 
        } 
      } 
      if (drawable2 == null)
        this.c.a(paramInt, "appcompat_skip_skip"); 
      return drawable2;
    } 
    return null;
  }
  
  public final Drawable k(Context paramContext, int paramInt, boolean paramBoolean, Drawable paramDrawable) {
    Drawable drawable1;
    PorterDuff.Mode mode1;
    PorterDuff.Mode mode2;
    ColorStateList colorStateList = i(paramContext, paramInt);
    Drawable drawable2 = null;
    if (colorStateList != null) {
      drawable1 = paramDrawable;
      if (c1.a(paramDrawable))
        drawable1 = paramDrawable.mutate(); 
      drawable1.setTintList(colorStateList);
      if (this.g == null) {
        paramDrawable = drawable2;
      } else {
        paramDrawable = drawable2;
        if (paramInt == 2131165260)
          mode1 = PorterDuff.Mode.MULTIPLY; 
      } 
      drawable2 = drawable1;
      if (mode1 != null) {
        drawable1.setTintMode(mode1);
        return drawable1;
      } 
    } else {
      t t1 = this.g;
      if (t1 != null) {
        Objects.requireNonNull(t1);
        boolean bool = true;
        if (paramInt == 2131165257) {
          LayerDrawable layerDrawable = (LayerDrawable)mode1;
          Drawable drawable = layerDrawable.findDrawableByLayerId(16908288);
          int k = f2.c((Context)drawable1, 2130903229);
          PorterDuff.Mode mode = u.b;
          t1.d(drawable, k, mode);
          t1.d(layerDrawable.findDrawableByLayerId(16908303), f2.c((Context)drawable1, 2130903229), mode);
          t1.d(layerDrawable.findDrawableByLayerId(16908301), f2.c((Context)drawable1, 2130903227), mode);
        } else if (paramInt == 2131165248 || paramInt == 2131165247 || paramInt == 2131165249) {
          LayerDrawable layerDrawable = (LayerDrawable)mode1;
          Drawable drawable = layerDrawable.findDrawableByLayerId(16908288);
          int k = f2.b((Context)drawable1, 2130903229);
          PorterDuff.Mode mode = u.b;
          t1.d(drawable, k, mode);
          t1.d(layerDrawable.findDrawableByLayerId(16908303), f2.c((Context)drawable1, 2130903227), mode);
          t1.d(layerDrawable.findDrawableByLayerId(16908301), f2.c((Context)drawable1, 2130903227), mode);
        } else {
          bool = false;
        } 
        if (bool)
          return (Drawable)mode1; 
      } 
      mode2 = mode1;
      if (!l((Context)drawable1, paramInt, (Drawable)mode1)) {
        mode2 = mode1;
        if (paramBoolean)
          mode2 = null; 
      } 
    } 
    return (Drawable)mode2;
  }
  
  public boolean l(Context paramContext, int paramInt, Drawable paramDrawable) {
    // Byte code:
    //   0: aload_0
    //   1: getfield g : Lc/b/h/t;
    //   4: astore #8
    //   6: aload #8
    //   8: ifnull -> 209
    //   11: aload #8
    //   13: invokestatic requireNonNull : (Ljava/lang/Object;)Ljava/lang/Object;
    //   16: pop
    //   17: getstatic c/b/h/u.b : Landroid/graphics/PorterDuff$Mode;
    //   20: astore #7
    //   22: aload #8
    //   24: aload #8
    //   26: getfield a : [I
    //   29: iload_2
    //   30: invokevirtual a : ([II)Z
    //   33: istore #6
    //   35: ldc_w 16842801
    //   38: istore #4
    //   40: iload #6
    //   42: ifeq -> 52
    //   45: ldc_w 2130903229
    //   48: istore_2
    //   49: goto -> 130
    //   52: aload #8
    //   54: aload #8
    //   56: getfield c : [I
    //   59: iload_2
    //   60: invokevirtual a : ([II)Z
    //   63: ifeq -> 73
    //   66: ldc_w 2130903227
    //   69: istore_2
    //   70: goto -> 130
    //   73: aload #8
    //   75: aload #8
    //   77: getfield d : [I
    //   80: iload_2
    //   81: invokevirtual a : ([II)Z
    //   84: ifeq -> 98
    //   87: getstatic android/graphics/PorterDuff$Mode.MULTIPLY : Landroid/graphics/PorterDuff$Mode;
    //   90: astore #7
    //   92: iload #4
    //   94: istore_2
    //   95: goto -> 130
    //   98: iload_2
    //   99: ldc_w 2131165234
    //   102: if_icmpne -> 120
    //   105: ldc_w 16842800
    //   108: istore_2
    //   109: ldc_w 40.8
    //   112: invokestatic round : (F)I
    //   115: istore #4
    //   117: goto -> 133
    //   120: iload_2
    //   121: ldc_w 2131165210
    //   124: if_icmpne -> 139
    //   127: iload #4
    //   129: istore_2
    //   130: iconst_m1
    //   131: istore #4
    //   133: iconst_1
    //   134: istore #5
    //   136: goto -> 147
    //   139: iconst_0
    //   140: istore_2
    //   141: iload_2
    //   142: istore #5
    //   144: iconst_m1
    //   145: istore #4
    //   147: iload #5
    //   149: ifeq -> 201
    //   152: aload_3
    //   153: astore #8
    //   155: aload_3
    //   156: invokestatic a : (Landroid/graphics/drawable/Drawable;)Z
    //   159: ifeq -> 168
    //   162: aload_3
    //   163: invokevirtual mutate : ()Landroid/graphics/drawable/Drawable;
    //   166: astore #8
    //   168: aload #8
    //   170: aload_1
    //   171: iload_2
    //   172: invokestatic c : (Landroid/content/Context;I)I
    //   175: aload #7
    //   177: invokestatic c : (ILandroid/graphics/PorterDuff$Mode;)Landroid/graphics/PorterDuffColorFilter;
    //   180: invokevirtual setColorFilter : (Landroid/graphics/ColorFilter;)V
    //   183: iload #4
    //   185: iconst_m1
    //   186: if_icmpeq -> 196
    //   189: aload #8
    //   191: iload #4
    //   193: invokevirtual setAlpha : (I)V
    //   196: iconst_1
    //   197: istore_2
    //   198: goto -> 203
    //   201: iconst_0
    //   202: istore_2
    //   203: iload_2
    //   204: ifeq -> 209
    //   207: iconst_1
    //   208: ireturn
    //   209: iconst_0
    //   210: ireturn
  }
}


/* Location:              C:\soft\dex2jar-2.0\Https Traffic-dex2jar.jar!\c\b\h\z1.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */