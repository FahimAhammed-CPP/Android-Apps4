package c.b.h;

import android.content.Context;
import android.content.res.ColorStateList;
import android.graphics.PorterDuff;
import android.graphics.drawable.Drawable;
import android.util.AttributeSet;
import android.view.View;
import android.widget.CompoundButton;
import android.widget.RadioButton;
import android.widget.TextView;
import c.b.d.a.a;

public class b0 extends RadioButton {
  public final s e;
  
  public final o f;
  
  public final t0 g;
  
  public b0(Context paramContext, AttributeSet paramAttributeSet, int paramInt) {
    super(paramContext, paramAttributeSet, paramInt);
    f2.a((View)this, getContext());
    s s1 = new s((CompoundButton)this);
    this.e = s1;
    s1.b(paramAttributeSet, paramInt);
    o o1 = new o((View)this);
    this.f = o1;
    o1.d(paramAttributeSet, paramInt);
    t0 t01 = new t0((TextView)this);
    this.g = t01;
    t01.e(paramAttributeSet, paramInt);
  }
  
  public void drawableStateChanged() {
    super.drawableStateChanged();
    o o1 = this.f;
    if (o1 != null)
      o1.a(); 
    t0 t01 = this.g;
    if (t01 != null)
      t01.b(); 
  }
  
  public int getCompoundPaddingLeft() {
    int i = super.getCompoundPaddingLeft();
    s s1 = this.e;
    return i;
  }
  
  public ColorStateList getSupportBackgroundTintList() {
    o o1 = this.f;
    return (o1 != null) ? o1.b() : null;
  }
  
  public PorterDuff.Mode getSupportBackgroundTintMode() {
    o o1 = this.f;
    return (o1 != null) ? o1.c() : null;
  }
  
  public ColorStateList getSupportButtonTintList() {
    s s1 = this.e;
    return (s1 != null) ? s1.b : null;
  }
  
  public PorterDuff.Mode getSupportButtonTintMode() {
    s s1 = this.e;
    return (s1 != null) ? s1.c : null;
  }
  
  public void setBackgroundDrawable(Drawable paramDrawable) {
    super.setBackgroundDrawable(paramDrawable);
    o o1 = this.f;
    if (o1 != null)
      o1.e(); 
  }
  
  public void setBackgroundResource(int paramInt) {
    super.setBackgroundResource(paramInt);
    o o1 = this.f;
    if (o1 != null)
      o1.f(paramInt); 
  }
  
  public void setButtonDrawable(int paramInt) {
    setButtonDrawable(a.a(getContext(), paramInt));
  }
  
  public void setButtonDrawable(Drawable paramDrawable) {
    super.setButtonDrawable(paramDrawable);
    s s1 = this.e;
    if (s1 != null) {
      if (s1.f) {
        s1.f = false;
        return;
      } 
      s1.f = true;
      s1.a();
    } 
  }
  
  public void setSupportBackgroundTintList(ColorStateList paramColorStateList) {
    o o1 = this.f;
    if (o1 != null)
      o1.h(paramColorStateList); 
  }
  
  public void setSupportBackgroundTintMode(PorterDuff.Mode paramMode) {
    o o1 = this.f;
    if (o1 != null)
      o1.i(paramMode); 
  }
  
  public void setSupportButtonTintList(ColorStateList paramColorStateList) {
    s s1 = this.e;
    if (s1 != null) {
      s1.b = paramColorStateList;
      s1.d = true;
      s1.a();
    } 
  }
  
  public void setSupportButtonTintMode(PorterDuff.Mode paramMode) {
    s s1 = this.e;
    if (s1 != null) {
      s1.c = paramMode;
      s1.e = true;
      s1.a();
    } 
  }
}


/* Location:              C:\soft\dex2jar-2.0\Https Traffic-dex2jar.jar!\c\b\h\b0.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */