package c.b.h;

import android.view.MenuItem;
import c.b.g.n.l;

public interface r1 {
  void c(l paraml, MenuItem paramMenuItem);
  
  void e(l paraml, MenuItem paramMenuItem);
}


/* Location:              C:\soft\dex2jar-2.0\Https Traffic-dex2jar.jar!\c\b\h\r1.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */