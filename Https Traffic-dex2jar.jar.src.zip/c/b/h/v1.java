package c.b.h;

import android.content.Context;
import android.content.res.Resources;
import android.graphics.drawable.Drawable;
import android.util.AttributeSet;
import android.util.Log;
import c.z.a.a.e;
import org.xmlpull.v1.XmlPullParser;

public class v1 implements x1 {
  public Drawable a(Context paramContext, XmlPullParser paramXmlPullParser, AttributeSet paramAttributeSet, Resources.Theme paramTheme) {
    try {
      Resources resources = paramContext.getResources();
      e e = new e(paramContext, null, null);
      e.inflate(resources, paramXmlPullParser, paramAttributeSet, paramTheme);
      return (Drawable)e;
    } catch (Exception exception) {
      Log.e("AvdcInflateDelegate", "Exception while inflating <animated-vector>", exception);
      return null;
    } 
  }
}


/* Location:              C:\soft\dex2jar-2.0\Https Traffic-dex2jar.jar!\c\b\h\v1.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */