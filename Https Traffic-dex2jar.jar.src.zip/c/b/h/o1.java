package c.b.h;

import android.view.MotionEvent;
import android.view.View;
import android.widget.PopupWindow;

public class o1 implements View.OnTouchListener {
  public o1(q1 paramq1) {}
  
  public boolean onTouch(View paramView, MotionEvent paramMotionEvent) {
    int i = paramMotionEvent.getAction();
    int j = (int)paramMotionEvent.getX();
    int k = (int)paramMotionEvent.getY();
    if (i == 0) {
      PopupWindow popupWindow = this.e.D;
      if (popupWindow != null && popupWindow.isShowing() && j >= 0 && j < this.e.D.getWidth() && k >= 0 && k < this.e.D.getHeight()) {
        q1 q11 = this.e;
        q11.z.postDelayed(q11.v, 250L);
        return false;
      } 
    } 
    if (i == 1) {
      q1 q11 = this.e;
      q11.z.removeCallbacks(q11.v);
    } 
    return false;
  }
}


/* Location:              C:\soft\dex2jar-2.0\Https Traffic-dex2jar.jar!\c\b\h\o1.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */