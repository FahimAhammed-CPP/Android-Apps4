package c.b.h;

import android.content.Context;
import android.content.res.Configuration;
import android.content.res.TypedArray;
import android.util.AttributeSet;
import android.util.TypedValue;
import android.view.ContextThemeWrapper;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import androidx.appcompat.widget.ActionMenuView;
import c.b.g.n.l;
import c.h.j.u;
import c.h.j.y;

public abstract class b extends ViewGroup {
  public final a e = new a(this);
  
  public final Context f;
  
  public ActionMenuView g;
  
  public m h;
  
  public int i;
  
  public y j;
  
  public boolean k;
  
  public boolean l;
  
  public b(Context paramContext, AttributeSet paramAttributeSet, int paramInt) {
    super(paramContext, paramAttributeSet, paramInt);
    TypedValue typedValue = new TypedValue();
    if (paramContext.getTheme().resolveAttribute(2130903042, typedValue, true) && typedValue.resourceId != 0) {
      this.f = (Context)new ContextThemeWrapper(paramContext, typedValue.resourceId);
      return;
    } 
    this.f = paramContext;
  }
  
  public int c(View paramView, int paramInt1, int paramInt2, int paramInt3) {
    paramView.measure(View.MeasureSpec.makeMeasureSpec(paramInt1, -2147483648), paramInt2);
    return Math.max(0, paramInt1 - paramView.getMeasuredWidth() - paramInt3);
  }
  
  public int d(View paramView, int paramInt1, int paramInt2, int paramInt3, boolean paramBoolean) {
    int i = paramView.getMeasuredWidth();
    int j = paramView.getMeasuredHeight();
    paramInt2 = (paramInt3 - j) / 2 + paramInt2;
    if (paramBoolean) {
      paramView.layout(paramInt1 - i, paramInt2, paramInt1, j + paramInt2);
    } else {
      paramView.layout(paramInt1, paramInt2, paramInt1 + i, j + paramInt2);
    } 
    paramInt1 = i;
    if (paramBoolean)
      paramInt1 = -i; 
    return paramInt1;
  }
  
  public y e(int paramInt, long paramLong) {
    y y1 = this.j;
    if (y1 != null)
      y1.b(); 
    if (paramInt == 0) {
      if (getVisibility() != 0)
        setAlpha(0.0F); 
      y1 = u.b((View)this);
      y1.a(1.0F);
      y1.c(paramLong);
      a a2 = this.e;
      a2.c.j = y1;
      a2.b = paramInt;
      View view1 = y1.a.get();
      if (view1 != null)
        y1.e(view1, a2); 
      return y1;
    } 
    y1 = u.b((View)this);
    y1.a(0.0F);
    y1.c(paramLong);
    a a1 = this.e;
    a1.c.j = y1;
    a1.b = paramInt;
    View view = y1.a.get();
    if (view != null)
      y1.e(view, a1); 
    return y1;
  }
  
  public void onConfigurationChanged(Configuration paramConfiguration) {
    super.onConfigurationChanged(paramConfiguration);
    TypedArray typedArray = getContext().obtainStyledAttributes(null, c.b.b.a, 2130903045, 0);
    setContentHeight(typedArray.getLayoutDimension(13, 0));
    typedArray.recycle();
    m m1 = this.h;
    if (m1 != null) {
      Configuration configuration = m1.f.getResources().getConfiguration();
      int i = configuration.screenWidthDp;
      int j = configuration.screenHeightDp;
      if (configuration.smallestScreenWidthDp > 600 || i > 600 || (i > 960 && j > 720) || (i > 720 && j > 960)) {
        i = 5;
      } else if (i >= 500 || (i > 640 && j > 480) || (i > 480 && j > 640)) {
        i = 4;
      } else if (i >= 360) {
        i = 3;
      } else {
        i = 2;
      } 
      m1.u = i;
      l l = m1.g;
      if (l != null)
        l.q(true); 
    } 
  }
  
  public boolean onHoverEvent(MotionEvent paramMotionEvent) {
    int i = paramMotionEvent.getActionMasked();
    if (i == 9)
      this.l = false; 
    if (!this.l) {
      boolean bool = super.onHoverEvent(paramMotionEvent);
      if (i == 9 && !bool)
        this.l = true; 
    } 
    if (i == 10 || i == 3)
      this.l = false; 
    return true;
  }
  
  public boolean onTouchEvent(MotionEvent paramMotionEvent) {
    int i = paramMotionEvent.getActionMasked();
    if (i == 0)
      this.k = false; 
    if (!this.k) {
      boolean bool = super.onTouchEvent(paramMotionEvent);
      if (i == 0 && !bool)
        this.k = true; 
    } 
    if (i == 1 || i == 3)
      this.k = false; 
    return true;
  }
  
  public abstract void setContentHeight(int paramInt);
  
  public void setVisibility(int paramInt) {
    if (paramInt != getVisibility()) {
      y y1 = this.j;
      if (y1 != null)
        y1.b(); 
      super.setVisibility(paramInt);
    } 
  }
}


/* Location:              C:\soft\dex2jar-2.0\Https Traffic-dex2jar.jar!\c\b\h\b.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */