package c.b.h;

import android.widget.AbsListView;

public class n1 implements AbsListView.OnScrollListener {
  public n1(q1 paramq1) {}
  
  public void onScroll(AbsListView paramAbsListView, int paramInt1, int paramInt2, int paramInt3) {}
  
  public void onScrollStateChanged(AbsListView paramAbsListView, int paramInt) {
    boolean bool = true;
    if (paramInt == 1) {
      if (this.a.D.getInputMethodMode() == 2) {
        paramInt = bool;
      } else {
        paramInt = 0;
      } 
      if (paramInt == 0 && this.a.D.getContentView() != null) {
        q1 q11 = this.a;
        q11.z.removeCallbacks(q11.v);
        this.a.v.run();
      } 
    } 
  }
}


/* Location:              C:\soft\dex2jar-2.0\Https Traffic-dex2jar.jar!\c\b\h\n1.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */