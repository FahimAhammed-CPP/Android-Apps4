package c.b.h;

import android.content.Context;
import android.content.res.ColorStateList;
import android.graphics.ColorFilter;
import android.graphics.PorterDuff;
import android.graphics.PorterDuffColorFilter;
import android.graphics.drawable.Drawable;
import android.os.Build;
import android.util.Log;

public final class u {
  public static final PorterDuff.Mode b = PorterDuff.Mode.SRC_IN;
  
  public static u c;
  
  public z1 a;
  
  public static u a() {
    // Byte code:
    //   0: ldc c/b/h/u
    //   2: monitorenter
    //   3: getstatic c/b/h/u.c : Lc/b/h/u;
    //   6: ifnonnull -> 12
    //   9: invokestatic e : ()V
    //   12: getstatic c/b/h/u.c : Lc/b/h/u;
    //   15: astore_0
    //   16: ldc c/b/h/u
    //   18: monitorexit
    //   19: aload_0
    //   20: areturn
    //   21: astore_0
    //   22: ldc c/b/h/u
    //   24: monitorexit
    //   25: aload_0
    //   26: athrow
    // Exception table:
    //   from	to	target	type
    //   3	12	21	finally
    //   12	16	21	finally
  }
  
  public static PorterDuffColorFilter c(int paramInt, PorterDuff.Mode paramMode) {
    // Byte code:
    //   0: ldc c/b/h/u
    //   2: monitorenter
    //   3: iload_0
    //   4: aload_1
    //   5: invokestatic h : (ILandroid/graphics/PorterDuff$Mode;)Landroid/graphics/PorterDuffColorFilter;
    //   8: astore_1
    //   9: ldc c/b/h/u
    //   11: monitorexit
    //   12: aload_1
    //   13: areturn
    //   14: astore_1
    //   15: ldc c/b/h/u
    //   17: monitorexit
    //   18: aload_1
    //   19: athrow
    // Exception table:
    //   from	to	target	type
    //   3	9	14	finally
  }
  
  public static void e() {
    // Byte code:
    //   0: ldc c/b/h/u
    //   2: monitorenter
    //   3: getstatic c/b/h/u.c : Lc/b/h/u;
    //   6: ifnonnull -> 60
    //   9: new c/b/h/u
    //   12: dup
    //   13: invokespecial <init> : ()V
    //   16: astore_0
    //   17: aload_0
    //   18: putstatic c/b/h/u.c : Lc/b/h/u;
    //   21: aload_0
    //   22: invokestatic d : ()Lc/b/h/z1;
    //   25: putfield a : Lc/b/h/z1;
    //   28: getstatic c/b/h/u.c : Lc/b/h/u;
    //   31: getfield a : Lc/b/h/z1;
    //   34: astore_0
    //   35: new c/b/h/t
    //   38: dup
    //   39: invokespecial <init> : ()V
    //   42: astore_1
    //   43: aload_0
    //   44: monitorenter
    //   45: aload_0
    //   46: aload_1
    //   47: putfield g : Lc/b/h/t;
    //   50: aload_0
    //   51: monitorexit
    //   52: goto -> 60
    //   55: astore_1
    //   56: aload_0
    //   57: monitorexit
    //   58: aload_1
    //   59: athrow
    //   60: ldc c/b/h/u
    //   62: monitorexit
    //   63: return
    //   64: astore_0
    //   65: ldc c/b/h/u
    //   67: monitorexit
    //   68: aload_0
    //   69: athrow
    // Exception table:
    //   from	to	target	type
    //   3	45	64	finally
    //   45	50	55	finally
    //   50	52	64	finally
    //   56	60	64	finally
  }
  
  public static void f(Drawable paramDrawable, h2 paramh2, int[] paramArrayOfint) {
    PorterDuff.Mode mode = z1.h;
    if (c1.a(paramDrawable) && paramDrawable.mutate() != paramDrawable) {
      Log.d("ResourceManagerInternal", "Mutated drawable is not the same instance as the input.");
      return;
    } 
    boolean bool = paramh2.d;
    if (bool || paramh2.c) {
      PorterDuff.Mode mode1;
      PorterDuffColorFilter porterDuffColorFilter2 = null;
      if (bool) {
        ColorStateList colorStateList = paramh2.a;
      } else {
        mode = null;
      } 
      if (paramh2.c) {
        mode1 = paramh2.b;
      } else {
        mode1 = z1.h;
      } 
      PorterDuffColorFilter porterDuffColorFilter1 = porterDuffColorFilter2;
      if (mode != null)
        if (mode1 == null) {
          porterDuffColorFilter1 = porterDuffColorFilter2;
        } else {
          porterDuffColorFilter1 = z1.h(mode.getColorForState(paramArrayOfint, 0), mode1);
        }  
      paramDrawable.setColorFilter((ColorFilter)porterDuffColorFilter1);
    } else {
      paramDrawable.clearColorFilter();
    } 
    if (Build.VERSION.SDK_INT <= 23)
      paramDrawable.invalidateSelf(); 
  }
  
  public Drawable b(Context paramContext, int paramInt) {
    // Byte code:
    //   0: aload_0
    //   1: monitorenter
    //   2: aload_0
    //   3: getfield a : Lc/b/h/z1;
    //   6: aload_1
    //   7: iload_2
    //   8: invokevirtual f : (Landroid/content/Context;I)Landroid/graphics/drawable/Drawable;
    //   11: astore_1
    //   12: aload_0
    //   13: monitorexit
    //   14: aload_1
    //   15: areturn
    //   16: astore_1
    //   17: aload_0
    //   18: monitorexit
    //   19: aload_1
    //   20: athrow
    // Exception table:
    //   from	to	target	type
    //   2	12	16	finally
  }
  
  public ColorStateList d(Context paramContext, int paramInt) {
    // Byte code:
    //   0: aload_0
    //   1: monitorenter
    //   2: aload_0
    //   3: getfield a : Lc/b/h/z1;
    //   6: aload_1
    //   7: iload_2
    //   8: invokevirtual i : (Landroid/content/Context;I)Landroid/content/res/ColorStateList;
    //   11: astore_1
    //   12: aload_0
    //   13: monitorexit
    //   14: aload_1
    //   15: areturn
    //   16: astore_1
    //   17: aload_0
    //   18: monitorexit
    //   19: aload_1
    //   20: athrow
    // Exception table:
    //   from	to	target	type
    //   2	12	16	finally
  }
}


/* Location:              C:\soft\dex2jar-2.0\Https Traffic-dex2jar.jar!\c\b\\\u.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */