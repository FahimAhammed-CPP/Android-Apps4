package c.b.h;

import android.content.Context;
import android.content.res.ColorStateList;
import android.graphics.PorterDuff;
import android.graphics.drawable.Drawable;
import android.util.AttributeSet;
import android.view.ActionMode;
import android.view.View;
import android.view.accessibility.AccessibilityEvent;
import android.view.accessibility.AccessibilityNodeInfo;
import android.widget.Button;
import android.widget.TextView;
import c.h.b.h;
import c.h.k.c;
import c.h.k.g;

public class p extends Button implements c, g {
  public final o e;
  
  public final t0 f;
  
  public p(Context paramContext, AttributeSet paramAttributeSet, int paramInt) {
    super(paramContext, paramAttributeSet, paramInt);
    f2.a((View)this, getContext());
    o o1 = new o((View)this);
    this.e = o1;
    o1.d(paramAttributeSet, paramInt);
    t0 t01 = new t0((TextView)this);
    this.f = t01;
    t01.e(paramAttributeSet, paramInt);
    t01.b();
  }
  
  public void drawableStateChanged() {
    super.drawableStateChanged();
    o o1 = this.e;
    if (o1 != null)
      o1.a(); 
    t0 t01 = this.f;
    if (t01 != null)
      t01.b(); 
  }
  
  public int getAutoSizeMaxTextSize() {
    if (c.a)
      return super.getAutoSizeMaxTextSize(); 
    t0 t01 = this.f;
    return (t01 != null) ? Math.round(t01.i.e) : -1;
  }
  
  public int getAutoSizeMinTextSize() {
    if (c.a)
      return super.getAutoSizeMinTextSize(); 
    t0 t01 = this.f;
    return (t01 != null) ? Math.round(t01.i.d) : -1;
  }
  
  public int getAutoSizeStepGranularity() {
    if (c.a)
      return super.getAutoSizeStepGranularity(); 
    t0 t01 = this.f;
    return (t01 != null) ? Math.round(t01.i.c) : -1;
  }
  
  public int[] getAutoSizeTextAvailableSizes() {
    if (c.a)
      return super.getAutoSizeTextAvailableSizes(); 
    t0 t01 = this.f;
    return (t01 != null) ? t01.i.f : new int[0];
  }
  
  public int getAutoSizeTextType() {
    boolean bool1 = c.a;
    boolean bool = false;
    if (bool1) {
      if (super.getAutoSizeTextType() == 1)
        bool = true; 
      return bool;
    } 
    t0 t01 = this.f;
    return (t01 != null) ? t01.i.a : 0;
  }
  
  public ColorStateList getSupportBackgroundTintList() {
    o o1 = this.e;
    return (o1 != null) ? o1.b() : null;
  }
  
  public PorterDuff.Mode getSupportBackgroundTintMode() {
    o o1 = this.e;
    return (o1 != null) ? o1.c() : null;
  }
  
  public ColorStateList getSupportCompoundDrawablesTintList() {
    h2 h2 = this.f.h;
    return (h2 != null) ? h2.a : null;
  }
  
  public PorterDuff.Mode getSupportCompoundDrawablesTintMode() {
    h2 h2 = this.f.h;
    return (h2 != null) ? h2.b : null;
  }
  
  public void onInitializeAccessibilityEvent(AccessibilityEvent paramAccessibilityEvent) {
    super.onInitializeAccessibilityEvent(paramAccessibilityEvent);
    paramAccessibilityEvent.setClassName(Button.class.getName());
  }
  
  public void onInitializeAccessibilityNodeInfo(AccessibilityNodeInfo paramAccessibilityNodeInfo) {
    super.onInitializeAccessibilityNodeInfo(paramAccessibilityNodeInfo);
    paramAccessibilityNodeInfo.setClassName(Button.class.getName());
  }
  
  public void onLayout(boolean paramBoolean, int paramInt1, int paramInt2, int paramInt3, int paramInt4) {
    super.onLayout(paramBoolean, paramInt1, paramInt2, paramInt3, paramInt4);
    t0 t01 = this.f;
    if (t01 != null && !c.a)
      t01.i.a(); 
  }
  
  public void onTextChanged(CharSequence paramCharSequence, int paramInt1, int paramInt2, int paramInt3) {
    super.onTextChanged(paramCharSequence, paramInt1, paramInt2, paramInt3);
    t0 t01 = this.f;
    if (t01 != null && !c.a && t01.d())
      this.f.i.a(); 
  }
  
  public void setAutoSizeTextTypeUniformWithConfiguration(int paramInt1, int paramInt2, int paramInt3, int paramInt4) {
    if (c.a) {
      super.setAutoSizeTextTypeUniformWithConfiguration(paramInt1, paramInt2, paramInt3, paramInt4);
      return;
    } 
    t0 t01 = this.f;
    if (t01 != null)
      t01.g(paramInt1, paramInt2, paramInt3, paramInt4); 
  }
  
  public void setAutoSizeTextTypeUniformWithPresetSizes(int[] paramArrayOfint, int paramInt) {
    if (c.a) {
      super.setAutoSizeTextTypeUniformWithPresetSizes(paramArrayOfint, paramInt);
      return;
    } 
    t0 t01 = this.f;
    if (t01 != null)
      t01.h(paramArrayOfint, paramInt); 
  }
  
  public void setAutoSizeTextTypeWithDefaults(int paramInt) {
    if (c.a) {
      super.setAutoSizeTextTypeWithDefaults(paramInt);
      return;
    } 
    t0 t01 = this.f;
    if (t01 != null)
      t01.i(paramInt); 
  }
  
  public void setBackgroundDrawable(Drawable paramDrawable) {
    super.setBackgroundDrawable(paramDrawable);
    o o1 = this.e;
    if (o1 != null)
      o1.e(); 
  }
  
  public void setBackgroundResource(int paramInt) {
    super.setBackgroundResource(paramInt);
    o o1 = this.e;
    if (o1 != null)
      o1.f(paramInt); 
  }
  
  public void setCustomSelectionActionModeCallback(ActionMode.Callback paramCallback) {
    super.setCustomSelectionActionModeCallback(h.n0((TextView)this, paramCallback));
  }
  
  public void setSupportAllCaps(boolean paramBoolean) {
    t0 t01 = this.f;
    if (t01 != null)
      t01.a.setAllCaps(paramBoolean); 
  }
  
  public void setSupportBackgroundTintList(ColorStateList paramColorStateList) {
    o o1 = this.e;
    if (o1 != null)
      o1.h(paramColorStateList); 
  }
  
  public void setSupportBackgroundTintMode(PorterDuff.Mode paramMode) {
    o o1 = this.e;
    if (o1 != null)
      o1.i(paramMode); 
  }
  
  public void setSupportCompoundDrawablesTintList(ColorStateList paramColorStateList) {
    this.f.j(paramColorStateList);
    this.f.b();
  }
  
  public void setSupportCompoundDrawablesTintMode(PorterDuff.Mode paramMode) {
    this.f.k(paramMode);
    this.f.b();
  }
  
  public void setTextAppearance(Context paramContext, int paramInt) {
    super.setTextAppearance(paramContext, paramInt);
    t0 t01 = this.f;
    if (t01 != null)
      t01.f(paramContext, paramInt); 
  }
  
  public void setTextSize(int paramInt, float paramFloat) {
    boolean bool = c.a;
    if (bool) {
      super.setTextSize(paramInt, paramFloat);
      return;
    } 
    t0 t01 = this.f;
    if (t01 != null && !bool && !t01.d())
      t01.i.f(paramInt, paramFloat); 
  }
}


/* Location:              C:\soft\dex2jar-2.0\Https Traffic-dex2jar.jar!\c\b\h\p.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */