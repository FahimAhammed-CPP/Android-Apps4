package c.b.h;

import android.view.View;
import android.widget.AdapterView;

public class j0 implements AdapterView.OnItemClickListener {
  public j0(m0 paramm0, q0 paramq0) {}
  
  public void onItemClick(AdapterView<?> paramAdapterView, View paramView, int paramInt, long paramLong) {
    this.e.L.setSelection(paramInt);
    if (this.e.L.getOnItemClickListener() != null) {
      m0 m01 = this.e;
      m01.L.performItemClick(paramView, paramInt, m01.I.getItemId(paramInt));
    } 
    this.e.dismiss();
  }
}


/* Location:              C:\soft\dex2jar-2.0\Https Traffic-dex2jar.jar!\c\b\h\j0.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */