package c.b.h;

import android.content.Context;
import android.view.View;
import c.b.g.n.l;
import c.b.g.n.x;

public class i extends x {
  public i(m paramm, Context paramContext, l paraml, View paramView, boolean paramBoolean) {
    super(paramContext, paraml, paramView, paramBoolean, 2130903070, 0);
    this.g = 8388613;
    d(paramm.C);
  }
  
  public void c() {
    l l = this.m.g;
    if (l != null)
      l.c(true); 
    this.m.y = null;
    super.c();
  }
}


/* Location:              C:\soft\dex2jar-2.0\Https Traffic-dex2jar.jar!\c\b\h\i.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */