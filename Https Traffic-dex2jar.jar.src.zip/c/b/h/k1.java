package c.b.h;

import android.view.View;
import android.widget.AdapterView;

public class k1 implements AdapterView.OnItemSelectedListener {
  public k1(q1 paramq1) {}
  
  public void onItemSelected(AdapterView<?> paramAdapterView, View paramView, int paramInt, long paramLong) {
    if (paramInt != -1) {
      f1 f1 = this.e.g;
      if (f1 != null)
        f1.setListSelectionHidden(false); 
    } 
  }
  
  public void onNothingSelected(AdapterView<?> paramAdapterView) {}
}


/* Location:              C:\soft\dex2jar-2.0\Https Traffic-dex2jar.jar!\c\b\h\k1.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */