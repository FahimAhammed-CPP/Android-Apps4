package c.b.h;

import android.content.res.ColorStateList;
import android.graphics.PorterDuff;

public class h2 {
  public ColorStateList a;
  
  public PorterDuff.Mode b;
  
  public boolean c;
  
  public boolean d;
}


/* Location:              C:\soft\dex2jar-2.0\Https Traffic-dex2jar.jar!\c\b\h\h2.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */