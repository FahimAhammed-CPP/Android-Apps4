package c.b.h;

import android.content.Context;
import android.content.res.ColorStateList;
import android.graphics.PorterDuff;
import android.graphics.Typeface;
import android.graphics.drawable.Drawable;
import android.os.Build;
import android.util.AttributeSet;
import android.util.DisplayMetrics;
import android.util.TypedValue;
import android.widget.TextView;
import c.b.b;
import d.a.a.a.a;
import java.lang.ref.WeakReference;
import java.util.Arrays;

public class t0 {
  public final TextView a;
  
  public h2 b;
  
  public h2 c;
  
  public h2 d;
  
  public h2 e;
  
  public h2 f;
  
  public h2 g;
  
  public h2 h;
  
  public final y0 i;
  
  public int j = 0;
  
  public int k = -1;
  
  public Typeface l;
  
  public boolean m;
  
  public t0(TextView paramTextView) {
    this.a = paramTextView;
    this.i = new y0(paramTextView);
  }
  
  public static h2 c(Context paramContext, u paramu, int paramInt) {
    ColorStateList colorStateList = paramu.d(paramContext, paramInt);
    if (colorStateList != null) {
      h2 h21 = new h2();
      h21.d = true;
      h21.a = colorStateList;
      return h21;
    } 
    return null;
  }
  
  public final void a(Drawable paramDrawable, h2 paramh2) {
    if (paramDrawable != null && paramh2 != null)
      u.f(paramDrawable, paramh2, this.a.getDrawableState()); 
  }
  
  public void b() {
    if (this.b != null || this.c != null || this.d != null || this.e != null) {
      Drawable[] arrayOfDrawable = this.a.getCompoundDrawables();
      a(arrayOfDrawable[0], this.b);
      a(arrayOfDrawable[1], this.c);
      a(arrayOfDrawable[2], this.d);
      a(arrayOfDrawable[3], this.e);
    } 
    if (this.f != null || this.g != null) {
      Drawable[] arrayOfDrawable = this.a.getCompoundDrawablesRelative();
      a(arrayOfDrawable[0], this.f);
      a(arrayOfDrawable[2], this.g);
    } 
  }
  
  public boolean d() {
    y0 y01 = this.i;
    return (y01.i() && y01.a != 0);
  }
  
  public void e(AttributeSet paramAttributeSet, int paramInt) {
    // Byte code:
    //   0: aload_0
    //   1: getfield a : Landroid/widget/TextView;
    //   4: invokevirtual getContext : ()Landroid/content/Context;
    //   7: astore #19
    //   9: invokestatic a : ()Lc/b/h/u;
    //   12: astore #17
    //   14: getstatic c/b/b.h : [I
    //   17: astore #14
    //   19: aload #19
    //   21: aload_1
    //   22: aload #14
    //   24: iload_2
    //   25: iconst_0
    //   26: invokestatic q : (Landroid/content/Context;Landroid/util/AttributeSet;[III)Lc/b/h/j2;
    //   29: astore #15
    //   31: aload_0
    //   32: getfield a : Landroid/widget/TextView;
    //   35: astore #16
    //   37: aload #16
    //   39: aload #16
    //   41: invokevirtual getContext : ()Landroid/content/Context;
    //   44: aload #14
    //   46: aload_1
    //   47: aload #15
    //   49: getfield b : Landroid/content/res/TypedArray;
    //   52: iload_2
    //   53: iconst_0
    //   54: invokestatic m : (Landroid/view/View;Landroid/content/Context;[ILandroid/util/AttributeSet;Landroid/content/res/TypedArray;II)V
    //   57: aload #15
    //   59: iconst_0
    //   60: iconst_m1
    //   61: invokevirtual l : (II)I
    //   64: istore #7
    //   66: aload #15
    //   68: iconst_3
    //   69: invokevirtual o : (I)Z
    //   72: ifeq -> 93
    //   75: aload_0
    //   76: aload #19
    //   78: aload #17
    //   80: aload #15
    //   82: iconst_3
    //   83: iconst_0
    //   84: invokevirtual l : (II)I
    //   87: invokestatic c : (Landroid/content/Context;Lc/b/h/u;I)Lc/b/h/h2;
    //   90: putfield b : Lc/b/h/h2;
    //   93: aload #15
    //   95: iconst_1
    //   96: invokevirtual o : (I)Z
    //   99: ifeq -> 120
    //   102: aload_0
    //   103: aload #19
    //   105: aload #17
    //   107: aload #15
    //   109: iconst_1
    //   110: iconst_0
    //   111: invokevirtual l : (II)I
    //   114: invokestatic c : (Landroid/content/Context;Lc/b/h/u;I)Lc/b/h/h2;
    //   117: putfield c : Lc/b/h/h2;
    //   120: aload #15
    //   122: iconst_4
    //   123: invokevirtual o : (I)Z
    //   126: ifeq -> 147
    //   129: aload_0
    //   130: aload #19
    //   132: aload #17
    //   134: aload #15
    //   136: iconst_4
    //   137: iconst_0
    //   138: invokevirtual l : (II)I
    //   141: invokestatic c : (Landroid/content/Context;Lc/b/h/u;I)Lc/b/h/h2;
    //   144: putfield d : Lc/b/h/h2;
    //   147: aload #15
    //   149: iconst_2
    //   150: invokevirtual o : (I)Z
    //   153: ifeq -> 174
    //   156: aload_0
    //   157: aload #19
    //   159: aload #17
    //   161: aload #15
    //   163: iconst_2
    //   164: iconst_0
    //   165: invokevirtual l : (II)I
    //   168: invokestatic c : (Landroid/content/Context;Lc/b/h/u;I)Lc/b/h/h2;
    //   171: putfield e : Lc/b/h/h2;
    //   174: getstatic android/os/Build$VERSION.SDK_INT : I
    //   177: istore #8
    //   179: aload #15
    //   181: iconst_5
    //   182: invokevirtual o : (I)Z
    //   185: ifeq -> 206
    //   188: aload_0
    //   189: aload #19
    //   191: aload #17
    //   193: aload #15
    //   195: iconst_5
    //   196: iconst_0
    //   197: invokevirtual l : (II)I
    //   200: invokestatic c : (Landroid/content/Context;Lc/b/h/u;I)Lc/b/h/h2;
    //   203: putfield f : Lc/b/h/h2;
    //   206: aload #15
    //   208: bipush #6
    //   210: invokevirtual o : (I)Z
    //   213: ifeq -> 235
    //   216: aload_0
    //   217: aload #19
    //   219: aload #17
    //   221: aload #15
    //   223: bipush #6
    //   225: iconst_0
    //   226: invokevirtual l : (II)I
    //   229: invokestatic c : (Landroid/content/Context;Lc/b/h/u;I)Lc/b/h/h2;
    //   232: putfield g : Lc/b/h/h2;
    //   235: aload #15
    //   237: getfield b : Landroid/content/res/TypedArray;
    //   240: invokevirtual recycle : ()V
    //   243: aload_0
    //   244: getfield a : Landroid/widget/TextView;
    //   247: invokevirtual getTransformationMethod : ()Landroid/text/method/TransformationMethod;
    //   250: instanceof android/text/method/PasswordTransformationMethod
    //   253: istore #13
    //   255: iload #7
    //   257: iconst_m1
    //   258: if_icmpeq -> 404
    //   261: new c/b/h/j2
    //   264: dup
    //   265: aload #19
    //   267: aload #19
    //   269: iload #7
    //   271: getstatic c/b/b.x : [I
    //   274: invokevirtual obtainStyledAttributes : (I[I)Landroid/content/res/TypedArray;
    //   277: invokespecial <init> : (Landroid/content/Context;Landroid/content/res/TypedArray;)V
    //   280: astore #16
    //   282: iload #13
    //   284: ifne -> 313
    //   287: aload #16
    //   289: bipush #14
    //   291: invokevirtual o : (I)Z
    //   294: ifeq -> 313
    //   297: aload #16
    //   299: bipush #14
    //   301: iconst_0
    //   302: invokevirtual a : (IZ)Z
    //   305: istore #9
    //   307: iconst_1
    //   308: istore #10
    //   310: goto -> 320
    //   313: iconst_0
    //   314: istore #9
    //   316: iload #9
    //   318: istore #10
    //   320: aload_0
    //   321: aload #19
    //   323: aload #16
    //   325: invokevirtual l : (Landroid/content/Context;Lc/b/h/j2;)V
    //   328: aload #16
    //   330: bipush #15
    //   332: invokevirtual o : (I)Z
    //   335: ifeq -> 350
    //   338: aload #16
    //   340: bipush #15
    //   342: invokevirtual m : (I)Ljava/lang/String;
    //   345: astore #14
    //   347: goto -> 353
    //   350: aconst_null
    //   351: astore #14
    //   353: iload #8
    //   355: bipush #26
    //   357: if_icmplt -> 382
    //   360: aload #16
    //   362: bipush #13
    //   364: invokevirtual o : (I)Z
    //   367: ifeq -> 382
    //   370: aload #16
    //   372: bipush #13
    //   374: invokevirtual m : (I)Ljava/lang/String;
    //   377: astore #15
    //   379: goto -> 385
    //   382: aconst_null
    //   383: astore #15
    //   385: aload #16
    //   387: getfield b : Landroid/content/res/TypedArray;
    //   390: invokevirtual recycle : ()V
    //   393: aload #14
    //   395: astore #16
    //   397: aload #15
    //   399: astore #14
    //   401: goto -> 417
    //   404: iconst_0
    //   405: istore #9
    //   407: iload #9
    //   409: istore #10
    //   411: aconst_null
    //   412: astore #16
    //   414: aconst_null
    //   415: astore #14
    //   417: new c/b/h/j2
    //   420: dup
    //   421: aload #19
    //   423: aload #19
    //   425: aload_1
    //   426: getstatic c/b/b.x : [I
    //   429: iload_2
    //   430: iconst_0
    //   431: invokevirtual obtainStyledAttributes : (Landroid/util/AttributeSet;[III)Landroid/content/res/TypedArray;
    //   434: invokespecial <init> : (Landroid/content/Context;Landroid/content/res/TypedArray;)V
    //   437: astore #15
    //   439: iload #9
    //   441: istore #12
    //   443: iload #10
    //   445: istore #11
    //   447: iload #13
    //   449: ifne -> 483
    //   452: iload #9
    //   454: istore #12
    //   456: iload #10
    //   458: istore #11
    //   460: aload #15
    //   462: bipush #14
    //   464: invokevirtual o : (I)Z
    //   467: ifeq -> 483
    //   470: aload #15
    //   472: bipush #14
    //   474: iconst_0
    //   475: invokevirtual a : (IZ)Z
    //   478: istore #12
    //   480: iconst_1
    //   481: istore #11
    //   483: aload #15
    //   485: bipush #15
    //   487: invokevirtual o : (I)Z
    //   490: ifeq -> 502
    //   493: aload #15
    //   495: bipush #15
    //   497: invokevirtual m : (I)Ljava/lang/String;
    //   500: astore #16
    //   502: iload #8
    //   504: bipush #26
    //   506: if_icmplt -> 531
    //   509: aload #15
    //   511: bipush #13
    //   513: invokevirtual o : (I)Z
    //   516: ifeq -> 531
    //   519: aload #15
    //   521: bipush #13
    //   523: invokevirtual m : (I)Ljava/lang/String;
    //   526: astore #14
    //   528: goto -> 531
    //   531: iload #8
    //   533: bipush #28
    //   535: if_icmplt -> 566
    //   538: aload #15
    //   540: iconst_0
    //   541: invokevirtual o : (I)Z
    //   544: ifeq -> 566
    //   547: aload #15
    //   549: iconst_0
    //   550: iconst_m1
    //   551: invokevirtual f : (II)I
    //   554: ifne -> 566
    //   557: aload_0
    //   558: getfield a : Landroid/widget/TextView;
    //   561: iconst_0
    //   562: fconst_0
    //   563: invokevirtual setTextSize : (IF)V
    //   566: aload_0
    //   567: aload #19
    //   569: aload #15
    //   571: invokevirtual l : (Landroid/content/Context;Lc/b/h/j2;)V
    //   574: aload #15
    //   576: getfield b : Landroid/content/res/TypedArray;
    //   579: invokevirtual recycle : ()V
    //   582: iload #13
    //   584: ifne -> 601
    //   587: iload #11
    //   589: ifeq -> 601
    //   592: aload_0
    //   593: getfield a : Landroid/widget/TextView;
    //   596: iload #12
    //   598: invokevirtual setAllCaps : (Z)V
    //   601: aload_0
    //   602: getfield l : Landroid/graphics/Typeface;
    //   605: astore #15
    //   607: aload #15
    //   609: ifnull -> 645
    //   612: aload_0
    //   613: getfield k : I
    //   616: iconst_m1
    //   617: if_icmpne -> 636
    //   620: aload_0
    //   621: getfield a : Landroid/widget/TextView;
    //   624: aload #15
    //   626: aload_0
    //   627: getfield j : I
    //   630: invokevirtual setTypeface : (Landroid/graphics/Typeface;I)V
    //   633: goto -> 645
    //   636: aload_0
    //   637: getfield a : Landroid/widget/TextView;
    //   640: aload #15
    //   642: invokevirtual setTypeface : (Landroid/graphics/Typeface;)V
    //   645: aload #14
    //   647: ifnull -> 660
    //   650: aload_0
    //   651: getfield a : Landroid/widget/TextView;
    //   654: aload #14
    //   656: invokevirtual setFontVariationSettings : (Ljava/lang/String;)Z
    //   659: pop
    //   660: aload #16
    //   662: ifnull -> 714
    //   665: iload #8
    //   667: bipush #24
    //   669: if_icmplt -> 687
    //   672: aload_0
    //   673: getfield a : Landroid/widget/TextView;
    //   676: aload #16
    //   678: invokestatic forLanguageTags : (Ljava/lang/String;)Landroid/os/LocaleList;
    //   681: invokevirtual setTextLocales : (Landroid/os/LocaleList;)V
    //   684: goto -> 714
    //   687: aload #16
    //   689: iconst_0
    //   690: aload #16
    //   692: bipush #44
    //   694: invokevirtual indexOf : (I)I
    //   697: invokevirtual substring : (II)Ljava/lang/String;
    //   700: astore #14
    //   702: aload_0
    //   703: getfield a : Landroid/widget/TextView;
    //   706: aload #14
    //   708: invokestatic forLanguageTag : (Ljava/lang/String;)Ljava/util/Locale;
    //   711: invokevirtual setTextLocale : (Ljava/util/Locale;)V
    //   714: aload_0
    //   715: getfield i : Lc/b/h/y0;
    //   718: astore #14
    //   720: aload #14
    //   722: getfield j : Landroid/content/Context;
    //   725: astore #15
    //   727: getstatic c/b/b.i : [I
    //   730: astore #16
    //   732: aload #15
    //   734: aload_1
    //   735: aload #16
    //   737: iload_2
    //   738: iconst_0
    //   739: invokevirtual obtainStyledAttributes : (Landroid/util/AttributeSet;[III)Landroid/content/res/TypedArray;
    //   742: astore #15
    //   744: aload #14
    //   746: getfield i : Landroid/widget/TextView;
    //   749: astore #18
    //   751: aload #18
    //   753: aload #18
    //   755: invokevirtual getContext : ()Landroid/content/Context;
    //   758: aload #16
    //   760: aload_1
    //   761: aload #15
    //   763: iload_2
    //   764: iconst_0
    //   765: invokestatic m : (Landroid/view/View;Landroid/content/Context;[ILandroid/util/AttributeSet;Landroid/content/res/TypedArray;II)V
    //   768: aload #15
    //   770: iconst_5
    //   771: invokevirtual hasValue : (I)Z
    //   774: ifeq -> 789
    //   777: aload #14
    //   779: aload #15
    //   781: iconst_5
    //   782: iconst_0
    //   783: invokevirtual getInt : (II)I
    //   786: putfield a : I
    //   789: aload #15
    //   791: iconst_4
    //   792: invokevirtual hasValue : (I)Z
    //   795: ifeq -> 810
    //   798: aload #15
    //   800: iconst_4
    //   801: ldc -1.0
    //   803: invokevirtual getDimension : (IF)F
    //   806: fstore_3
    //   807: goto -> 813
    //   810: ldc -1.0
    //   812: fstore_3
    //   813: aload #15
    //   815: iconst_2
    //   816: invokevirtual hasValue : (I)Z
    //   819: ifeq -> 835
    //   822: aload #15
    //   824: iconst_2
    //   825: ldc -1.0
    //   827: invokevirtual getDimension : (IF)F
    //   830: fstore #5
    //   832: goto -> 839
    //   835: ldc -1.0
    //   837: fstore #5
    //   839: aload #15
    //   841: iconst_1
    //   842: invokevirtual hasValue : (I)Z
    //   845: ifeq -> 861
    //   848: aload #15
    //   850: iconst_1
    //   851: ldc -1.0
    //   853: invokevirtual getDimension : (IF)F
    //   856: fstore #4
    //   858: goto -> 865
    //   861: ldc -1.0
    //   863: fstore #4
    //   865: aload #15
    //   867: iconst_3
    //   868: invokevirtual hasValue : (I)Z
    //   871: ifeq -> 964
    //   874: aload #15
    //   876: iconst_3
    //   877: iconst_0
    //   878: invokevirtual getResourceId : (II)I
    //   881: istore_2
    //   882: iload_2
    //   883: ifle -> 964
    //   886: aload #15
    //   888: invokevirtual getResources : ()Landroid/content/res/Resources;
    //   891: iload_2
    //   892: invokevirtual obtainTypedArray : (I)Landroid/content/res/TypedArray;
    //   895: astore #16
    //   897: aload #16
    //   899: invokevirtual length : ()I
    //   902: istore #7
    //   904: iload #7
    //   906: newarray int
    //   908: astore #18
    //   910: iload #7
    //   912: ifle -> 959
    //   915: iconst_0
    //   916: istore_2
    //   917: iload_2
    //   918: iload #7
    //   920: if_icmpge -> 941
    //   923: aload #18
    //   925: iload_2
    //   926: aload #16
    //   928: iload_2
    //   929: iconst_m1
    //   930: invokevirtual getDimensionPixelSize : (II)I
    //   933: iastore
    //   934: iload_2
    //   935: iconst_1
    //   936: iadd
    //   937: istore_2
    //   938: goto -> 917
    //   941: aload #14
    //   943: aload #14
    //   945: aload #18
    //   947: invokevirtual b : ([I)[I
    //   950: putfield f : [I
    //   953: aload #14
    //   955: invokevirtual h : ()Z
    //   958: pop
    //   959: aload #16
    //   961: invokevirtual recycle : ()V
    //   964: aload #15
    //   966: invokevirtual recycle : ()V
    //   969: aload #14
    //   971: invokevirtual i : ()Z
    //   974: ifeq -> 1085
    //   977: aload #14
    //   979: getfield a : I
    //   982: iconst_1
    //   983: if_icmpne -> 1091
    //   986: aload #14
    //   988: getfield g : Z
    //   991: ifne -> 1076
    //   994: aload #14
    //   996: getfield j : Landroid/content/Context;
    //   999: invokevirtual getResources : ()Landroid/content/res/Resources;
    //   1002: invokevirtual getDisplayMetrics : ()Landroid/util/DisplayMetrics;
    //   1005: astore #15
    //   1007: fload #5
    //   1009: ldc -1.0
    //   1011: fcmpl
    //   1012: ifne -> 1029
    //   1015: iconst_2
    //   1016: ldc_w 12.0
    //   1019: aload #15
    //   1021: invokestatic applyDimension : (IFLandroid/util/DisplayMetrics;)F
    //   1024: fstore #5
    //   1026: goto -> 1029
    //   1029: fload #4
    //   1031: fstore #6
    //   1033: fload #4
    //   1035: ldc -1.0
    //   1037: fcmpl
    //   1038: ifne -> 1052
    //   1041: iconst_2
    //   1042: ldc_w 112.0
    //   1045: aload #15
    //   1047: invokestatic applyDimension : (IFLandroid/util/DisplayMetrics;)F
    //   1050: fstore #6
    //   1052: fload_3
    //   1053: fstore #4
    //   1055: fload_3
    //   1056: ldc -1.0
    //   1058: fcmpl
    //   1059: ifne -> 1065
    //   1062: fconst_1
    //   1063: fstore #4
    //   1065: aload #14
    //   1067: fload #5
    //   1069: fload #6
    //   1071: fload #4
    //   1073: invokevirtual j : (FFF)V
    //   1076: aload #14
    //   1078: invokevirtual g : ()Z
    //   1081: pop
    //   1082: goto -> 1091
    //   1085: aload #14
    //   1087: iconst_0
    //   1088: putfield a : I
    //   1091: getstatic c/h/k/c.a : Z
    //   1094: ifeq -> 1189
    //   1097: aload_0
    //   1098: getfield i : Lc/b/h/y0;
    //   1101: astore #14
    //   1103: aload #14
    //   1105: getfield a : I
    //   1108: ifeq -> 1189
    //   1111: aload #14
    //   1113: getfield f : [I
    //   1116: astore #14
    //   1118: aload #14
    //   1120: arraylength
    //   1121: ifle -> 1189
    //   1124: aload_0
    //   1125: getfield a : Landroid/widget/TextView;
    //   1128: invokevirtual getAutoSizeStepGranularity : ()I
    //   1131: i2f
    //   1132: ldc -1.0
    //   1134: fcmpl
    //   1135: ifeq -> 1179
    //   1138: aload_0
    //   1139: getfield a : Landroid/widget/TextView;
    //   1142: aload_0
    //   1143: getfield i : Lc/b/h/y0;
    //   1146: getfield d : F
    //   1149: invokestatic round : (F)I
    //   1152: aload_0
    //   1153: getfield i : Lc/b/h/y0;
    //   1156: getfield e : F
    //   1159: invokestatic round : (F)I
    //   1162: aload_0
    //   1163: getfield i : Lc/b/h/y0;
    //   1166: getfield c : F
    //   1169: invokestatic round : (F)I
    //   1172: iconst_0
    //   1173: invokevirtual setAutoSizeTextTypeUniformWithConfiguration : (IIII)V
    //   1176: goto -> 1189
    //   1179: aload_0
    //   1180: getfield a : Landroid/widget/TextView;
    //   1183: aload #14
    //   1185: iconst_0
    //   1186: invokevirtual setAutoSizeTextTypeUniformWithPresetSizes : ([II)V
    //   1189: aload #19
    //   1191: aload_1
    //   1192: getstatic c/b/b.i : [I
    //   1195: invokevirtual obtainStyledAttributes : (Landroid/util/AttributeSet;[I)Landroid/content/res/TypedArray;
    //   1198: astore #20
    //   1200: aload #20
    //   1202: bipush #8
    //   1204: iconst_m1
    //   1205: invokevirtual getResourceId : (II)I
    //   1208: istore_2
    //   1209: iload_2
    //   1210: iconst_m1
    //   1211: if_icmpeq -> 1227
    //   1214: aload #17
    //   1216: aload #19
    //   1218: iload_2
    //   1219: invokevirtual b : (Landroid/content/Context;I)Landroid/graphics/drawable/Drawable;
    //   1222: astore #15
    //   1224: goto -> 1230
    //   1227: aconst_null
    //   1228: astore #15
    //   1230: aload #20
    //   1232: bipush #13
    //   1234: iconst_m1
    //   1235: invokevirtual getResourceId : (II)I
    //   1238: istore_2
    //   1239: iload_2
    //   1240: iconst_m1
    //   1241: if_icmpeq -> 1257
    //   1244: aload #17
    //   1246: aload #19
    //   1248: iload_2
    //   1249: invokevirtual b : (Landroid/content/Context;I)Landroid/graphics/drawable/Drawable;
    //   1252: astore #14
    //   1254: goto -> 1260
    //   1257: aconst_null
    //   1258: astore #14
    //   1260: aload #20
    //   1262: bipush #9
    //   1264: iconst_m1
    //   1265: invokevirtual getResourceId : (II)I
    //   1268: istore_2
    //   1269: iload_2
    //   1270: iconst_m1
    //   1271: if_icmpeq -> 1287
    //   1274: aload #17
    //   1276: aload #19
    //   1278: iload_2
    //   1279: invokevirtual b : (Landroid/content/Context;I)Landroid/graphics/drawable/Drawable;
    //   1282: astore #16
    //   1284: goto -> 1290
    //   1287: aconst_null
    //   1288: astore #16
    //   1290: aload #20
    //   1292: bipush #6
    //   1294: iconst_m1
    //   1295: invokevirtual getResourceId : (II)I
    //   1298: istore_2
    //   1299: iload_2
    //   1300: iconst_m1
    //   1301: if_icmpeq -> 1316
    //   1304: aload #17
    //   1306: aload #19
    //   1308: iload_2
    //   1309: invokevirtual b : (Landroid/content/Context;I)Landroid/graphics/drawable/Drawable;
    //   1312: astore_1
    //   1313: goto -> 1318
    //   1316: aconst_null
    //   1317: astore_1
    //   1318: aload #20
    //   1320: bipush #10
    //   1322: iconst_m1
    //   1323: invokevirtual getResourceId : (II)I
    //   1326: istore_2
    //   1327: iload_2
    //   1328: iconst_m1
    //   1329: if_icmpeq -> 1345
    //   1332: aload #17
    //   1334: aload #19
    //   1336: iload_2
    //   1337: invokevirtual b : (Landroid/content/Context;I)Landroid/graphics/drawable/Drawable;
    //   1340: astore #18
    //   1342: goto -> 1348
    //   1345: aconst_null
    //   1346: astore #18
    //   1348: aload #20
    //   1350: bipush #7
    //   1352: iconst_m1
    //   1353: invokevirtual getResourceId : (II)I
    //   1356: istore_2
    //   1357: iload_2
    //   1358: iconst_m1
    //   1359: if_icmpeq -> 1375
    //   1362: aload #17
    //   1364: aload #19
    //   1366: iload_2
    //   1367: invokevirtual b : (Landroid/content/Context;I)Landroid/graphics/drawable/Drawable;
    //   1370: astore #17
    //   1372: goto -> 1378
    //   1375: aconst_null
    //   1376: astore #17
    //   1378: aload #18
    //   1380: ifnonnull -> 1579
    //   1383: aload #17
    //   1385: ifnull -> 1391
    //   1388: goto -> 1579
    //   1391: aload #15
    //   1393: ifnonnull -> 1410
    //   1396: aload #14
    //   1398: ifnonnull -> 1410
    //   1401: aload #16
    //   1403: ifnonnull -> 1410
    //   1406: aload_1
    //   1407: ifnull -> 1660
    //   1410: aload_0
    //   1411: getfield a : Landroid/widget/TextView;
    //   1414: invokevirtual getCompoundDrawablesRelative : ()[Landroid/graphics/drawable/Drawable;
    //   1417: astore #17
    //   1419: aload #17
    //   1421: iconst_0
    //   1422: aaload
    //   1423: ifnonnull -> 1520
    //   1426: aload #17
    //   1428: iconst_2
    //   1429: aaload
    //   1430: ifnull -> 1436
    //   1433: goto -> 1520
    //   1436: aload_0
    //   1437: getfield a : Landroid/widget/TextView;
    //   1440: invokevirtual getCompoundDrawables : ()[Landroid/graphics/drawable/Drawable;
    //   1443: astore #18
    //   1445: aload_0
    //   1446: getfield a : Landroid/widget/TextView;
    //   1449: astore #17
    //   1451: aload #15
    //   1453: ifnull -> 1459
    //   1456: goto -> 1465
    //   1459: aload #18
    //   1461: iconst_0
    //   1462: aaload
    //   1463: astore #15
    //   1465: aload #14
    //   1467: ifnull -> 1473
    //   1470: goto -> 1479
    //   1473: aload #18
    //   1475: iconst_1
    //   1476: aaload
    //   1477: astore #14
    //   1479: aload #16
    //   1481: ifnull -> 1487
    //   1484: goto -> 1493
    //   1487: aload #18
    //   1489: iconst_2
    //   1490: aaload
    //   1491: astore #16
    //   1493: aload_1
    //   1494: ifnull -> 1500
    //   1497: goto -> 1505
    //   1500: aload #18
    //   1502: iconst_3
    //   1503: aaload
    //   1504: astore_1
    //   1505: aload #17
    //   1507: aload #15
    //   1509: aload #14
    //   1511: aload #16
    //   1513: aload_1
    //   1514: invokevirtual setCompoundDrawablesWithIntrinsicBounds : (Landroid/graphics/drawable/Drawable;Landroid/graphics/drawable/Drawable;Landroid/graphics/drawable/Drawable;Landroid/graphics/drawable/Drawable;)V
    //   1517: goto -> 1660
    //   1520: aload_0
    //   1521: getfield a : Landroid/widget/TextView;
    //   1524: astore #15
    //   1526: aload #17
    //   1528: iconst_0
    //   1529: aaload
    //   1530: astore #16
    //   1532: aload #14
    //   1534: ifnull -> 1540
    //   1537: goto -> 1546
    //   1540: aload #17
    //   1542: iconst_1
    //   1543: aaload
    //   1544: astore #14
    //   1546: aload #17
    //   1548: iconst_2
    //   1549: aaload
    //   1550: astore #18
    //   1552: aload_1
    //   1553: ifnull -> 1559
    //   1556: goto -> 1564
    //   1559: aload #17
    //   1561: iconst_3
    //   1562: aaload
    //   1563: astore_1
    //   1564: aload #15
    //   1566: aload #16
    //   1568: aload #14
    //   1570: aload #18
    //   1572: aload_1
    //   1573: invokevirtual setCompoundDrawablesRelativeWithIntrinsicBounds : (Landroid/graphics/drawable/Drawable;Landroid/graphics/drawable/Drawable;Landroid/graphics/drawable/Drawable;Landroid/graphics/drawable/Drawable;)V
    //   1576: goto -> 1660
    //   1579: aload_0
    //   1580: getfield a : Landroid/widget/TextView;
    //   1583: invokevirtual getCompoundDrawablesRelative : ()[Landroid/graphics/drawable/Drawable;
    //   1586: astore #16
    //   1588: aload_0
    //   1589: getfield a : Landroid/widget/TextView;
    //   1592: astore #15
    //   1594: aload #18
    //   1596: ifnull -> 1602
    //   1599: goto -> 1608
    //   1602: aload #16
    //   1604: iconst_0
    //   1605: aaload
    //   1606: astore #18
    //   1608: aload #14
    //   1610: ifnull -> 1616
    //   1613: goto -> 1622
    //   1616: aload #16
    //   1618: iconst_1
    //   1619: aaload
    //   1620: astore #14
    //   1622: aload #17
    //   1624: ifnull -> 1630
    //   1627: goto -> 1636
    //   1630: aload #16
    //   1632: iconst_2
    //   1633: aaload
    //   1634: astore #17
    //   1636: aload_1
    //   1637: ifnull -> 1643
    //   1640: goto -> 1648
    //   1643: aload #16
    //   1645: iconst_3
    //   1646: aaload
    //   1647: astore_1
    //   1648: aload #15
    //   1650: aload #18
    //   1652: aload #14
    //   1654: aload #17
    //   1656: aload_1
    //   1657: invokevirtual setCompoundDrawablesRelativeWithIntrinsicBounds : (Landroid/graphics/drawable/Drawable;Landroid/graphics/drawable/Drawable;Landroid/graphics/drawable/Drawable;Landroid/graphics/drawable/Drawable;)V
    //   1660: aload #20
    //   1662: bipush #11
    //   1664: invokevirtual hasValue : (I)Z
    //   1667: ifeq -> 1767
    //   1670: aload #20
    //   1672: bipush #11
    //   1674: invokevirtual hasValue : (I)Z
    //   1677: ifeq -> 1711
    //   1680: aload #20
    //   1682: bipush #11
    //   1684: iconst_0
    //   1685: invokevirtual getResourceId : (II)I
    //   1688: istore_2
    //   1689: iload_2
    //   1690: ifeq -> 1711
    //   1693: getstatic c/b/d/a/a.a : Ljava/lang/ThreadLocal;
    //   1696: astore_1
    //   1697: aload #19
    //   1699: iload_2
    //   1700: invokevirtual getColorStateList : (I)Landroid/content/res/ColorStateList;
    //   1703: astore_1
    //   1704: aload_1
    //   1705: ifnull -> 1711
    //   1708: goto -> 1719
    //   1711: aload #20
    //   1713: bipush #11
    //   1715: invokevirtual getColorStateList : (I)Landroid/content/res/ColorStateList;
    //   1718: astore_1
    //   1719: aload_0
    //   1720: getfield a : Landroid/widget/TextView;
    //   1723: astore #14
    //   1725: aload #14
    //   1727: invokestatic requireNonNull : (Ljava/lang/Object;)Ljava/lang/Object;
    //   1730: pop
    //   1731: getstatic android/os/Build$VERSION.SDK_INT : I
    //   1734: bipush #24
    //   1736: if_icmplt -> 1748
    //   1739: aload #14
    //   1741: aload_1
    //   1742: invokevirtual setCompoundDrawableTintList : (Landroid/content/res/ColorStateList;)V
    //   1745: goto -> 1767
    //   1748: aload #14
    //   1750: instanceof c/h/k/g
    //   1753: ifeq -> 1767
    //   1756: aload #14
    //   1758: checkcast c/h/k/g
    //   1761: aload_1
    //   1762: invokeinterface setSupportCompoundDrawablesTintList : (Landroid/content/res/ColorStateList;)V
    //   1767: aload #20
    //   1769: bipush #12
    //   1771: invokevirtual hasValue : (I)Z
    //   1774: ifeq -> 1838
    //   1777: aload #20
    //   1779: bipush #12
    //   1781: iconst_m1
    //   1782: invokevirtual getInt : (II)I
    //   1785: aconst_null
    //   1786: invokestatic b : (ILandroid/graphics/PorterDuff$Mode;)Landroid/graphics/PorterDuff$Mode;
    //   1789: astore_1
    //   1790: aload_0
    //   1791: getfield a : Landroid/widget/TextView;
    //   1794: astore #14
    //   1796: aload #14
    //   1798: invokestatic requireNonNull : (Ljava/lang/Object;)Ljava/lang/Object;
    //   1801: pop
    //   1802: getstatic android/os/Build$VERSION.SDK_INT : I
    //   1805: bipush #24
    //   1807: if_icmplt -> 1819
    //   1810: aload #14
    //   1812: aload_1
    //   1813: invokevirtual setCompoundDrawableTintMode : (Landroid/graphics/PorterDuff$Mode;)V
    //   1816: goto -> 1838
    //   1819: aload #14
    //   1821: instanceof c/h/k/g
    //   1824: ifeq -> 1838
    //   1827: aload #14
    //   1829: checkcast c/h/k/g
    //   1832: aload_1
    //   1833: invokeinterface setSupportCompoundDrawablesTintMode : (Landroid/graphics/PorterDuff$Mode;)V
    //   1838: aload #20
    //   1840: bipush #14
    //   1842: iconst_m1
    //   1843: invokevirtual getDimensionPixelSize : (II)I
    //   1846: istore_2
    //   1847: aload #20
    //   1849: bipush #17
    //   1851: iconst_m1
    //   1852: invokevirtual getDimensionPixelSize : (II)I
    //   1855: istore #7
    //   1857: aload #20
    //   1859: bipush #18
    //   1861: iconst_m1
    //   1862: invokevirtual getDimensionPixelSize : (II)I
    //   1865: istore #8
    //   1867: aload #20
    //   1869: invokevirtual recycle : ()V
    //   1872: iload_2
    //   1873: iconst_m1
    //   1874: if_icmpeq -> 1885
    //   1877: aload_0
    //   1878: getfield a : Landroid/widget/TextView;
    //   1881: iload_2
    //   1882: invokestatic e0 : (Landroid/widget/TextView;I)V
    //   1885: iload #7
    //   1887: iconst_m1
    //   1888: if_icmpeq -> 1900
    //   1891: aload_0
    //   1892: getfield a : Landroid/widget/TextView;
    //   1895: iload #7
    //   1897: invokestatic f0 : (Landroid/widget/TextView;I)V
    //   1900: iload #8
    //   1902: iconst_m1
    //   1903: if_icmpeq -> 1915
    //   1906: aload_0
    //   1907: getfield a : Landroid/widget/TextView;
    //   1910: iload #8
    //   1912: invokestatic g0 : (Landroid/widget/TextView;I)V
    //   1915: return
  }
  
  public void f(Context paramContext, int paramInt) {
    j2 j2 = new j2(paramContext, paramContext.obtainStyledAttributes(paramInt, b.x));
    if (j2.o(14)) {
      boolean bool = j2.a(14, false);
      this.a.setAllCaps(bool);
    } 
    paramInt = Build.VERSION.SDK_INT;
    if (j2.o(0) && j2.f(0, -1) == 0)
      this.a.setTextSize(0, 0.0F); 
    l(paramContext, j2);
    if (paramInt >= 26 && j2.o(13)) {
      String str = j2.m(13);
      if (str != null)
        this.a.setFontVariationSettings(str); 
    } 
    j2.b.recycle();
    Typeface typeface = this.l;
    if (typeface != null)
      this.a.setTypeface(typeface, this.j); 
  }
  
  public void g(int paramInt1, int paramInt2, int paramInt3, int paramInt4) {
    y0 y01 = this.i;
    if (y01.i()) {
      DisplayMetrics displayMetrics = y01.j.getResources().getDisplayMetrics();
      y01.j(TypedValue.applyDimension(paramInt4, paramInt1, displayMetrics), TypedValue.applyDimension(paramInt4, paramInt2, displayMetrics), TypedValue.applyDimension(paramInt4, paramInt3, displayMetrics));
      if (y01.g())
        y01.a(); 
    } 
  }
  
  public void h(int[] paramArrayOfint, int paramInt) {
    y0 y01 = this.i;
    if (y01.i()) {
      int j = paramArrayOfint.length;
      int i = 0;
      if (j > 0) {
        int[] arrayOfInt1;
        int[] arrayOfInt2 = new int[j];
        if (paramInt == 0) {
          arrayOfInt1 = Arrays.copyOf(paramArrayOfint, j);
        } else {
          DisplayMetrics displayMetrics = y01.j.getResources().getDisplayMetrics();
          while (true) {
            arrayOfInt1 = arrayOfInt2;
            if (i < j) {
              arrayOfInt2[i] = Math.round(TypedValue.applyDimension(paramInt, paramArrayOfint[i], displayMetrics));
              i++;
              continue;
            } 
            break;
          } 
        } 
        y01.f = y01.b(arrayOfInt1);
        if (!y01.h()) {
          StringBuilder stringBuilder = a.p("None of the preset sizes is valid: ");
          stringBuilder.append(Arrays.toString(paramArrayOfint));
          throw new IllegalArgumentException(stringBuilder.toString());
        } 
      } else {
        y01.g = false;
      } 
      if (y01.g())
        y01.a(); 
    } 
  }
  
  public void i(int paramInt) {
    y0 y01 = this.i;
    if (y01.i())
      if (paramInt != 0) {
        if (paramInt == 1) {
          DisplayMetrics displayMetrics = y01.j.getResources().getDisplayMetrics();
          y01.j(TypedValue.applyDimension(2, 12.0F, displayMetrics), TypedValue.applyDimension(2, 112.0F, displayMetrics), 1.0F);
          if (y01.g()) {
            y01.a();
            return;
          } 
        } else {
          throw new IllegalArgumentException(a.D("Unknown auto-size text type: ", paramInt));
        } 
      } else {
        y01.a = 0;
        y01.d = -1.0F;
        y01.e = -1.0F;
        y01.c = -1.0F;
        y01.f = new int[0];
        y01.b = false;
      }  
  }
  
  public void j(ColorStateList paramColorStateList) {
    boolean bool;
    if (this.h == null)
      this.h = new h2(); 
    h2 h21 = this.h;
    h21.a = paramColorStateList;
    if (paramColorStateList != null) {
      bool = true;
    } else {
      bool = false;
    } 
    h21.d = bool;
    this.b = h21;
    this.c = h21;
    this.d = h21;
    this.e = h21;
    this.f = h21;
    this.g = h21;
  }
  
  public void k(PorterDuff.Mode paramMode) {
    boolean bool;
    if (this.h == null)
      this.h = new h2(); 
    h2 h21 = this.h;
    h21.b = paramMode;
    if (paramMode != null) {
      bool = true;
    } else {
      bool = false;
    } 
    h21.c = bool;
    this.b = h21;
    this.c = h21;
    this.d = h21;
    this.e = h21;
    this.f = h21;
    this.g = h21;
  }
  
  public final void l(Context paramContext, j2 paramj2) {
    this.j = paramj2.j(2, this.j);
    int j = Build.VERSION.SDK_INT;
    boolean bool = false;
    if (j >= 28) {
      int k = paramj2.j(11, -1);
      this.k = k;
      if (k != -1)
        this.j = this.j & 0x2 | 0x0; 
    } 
    int i = 10;
    if (paramj2.o(10) || paramj2.o(12)) {
      this.l = null;
      if (paramj2.o(12))
        i = 12; 
      int k = this.k;
      int m = this.j;
      if (!paramContext.isRestricted()) {
        s0 s0 = new s0(this, k, m, new WeakReference<TextView>(this.a));
        try {
          boolean bool1;
          Typeface typeface = paramj2.i(i, this.j, s0);
          if (typeface != null)
            if (j >= 28 && this.k != -1) {
              typeface = Typeface.create(typeface, 0);
              j = this.k;
              if ((this.j & 0x2) != 0) {
                bool1 = true;
              } else {
                bool1 = false;
              } 
              this.l = Typeface.create(typeface, j, bool1);
            } else {
              this.l = typeface;
            }  
          if (this.l == null) {
            bool1 = true;
          } else {
            bool1 = false;
          } 
          this.m = bool1;
        } catch (UnsupportedOperationException|android.content.res.Resources.NotFoundException unsupportedOperationException) {}
      } 
      if (this.l == null) {
        String str = paramj2.m(i);
        if (str != null) {
          Typeface typeface;
          if (Build.VERSION.SDK_INT >= 28 && this.k != -1) {
            typeface = Typeface.create(str, 0);
            i = this.k;
            boolean bool1 = bool;
            if ((this.j & 0x2) != 0)
              bool1 = true; 
            this.l = Typeface.create(typeface, i, bool1);
            return;
          } 
          this.l = Typeface.create((String)typeface, this.j);
        } 
      } 
      return;
    } 
    if (paramj2.o(1)) {
      this.m = false;
      i = paramj2.j(1, 1);
      if (i != 1) {
        if (i != 2) {
          if (i != 3)
            return; 
          this.l = Typeface.MONOSPACE;
          return;
        } 
        this.l = Typeface.SERIF;
        return;
      } 
      this.l = Typeface.SANS_SERIF;
    } 
  }
}


/* Location:              C:\soft\dex2jar-2.0\Https Traffic-dex2jar.jar!\c\b\h\t0.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */