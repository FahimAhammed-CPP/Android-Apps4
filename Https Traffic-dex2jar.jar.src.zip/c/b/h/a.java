package c.b.h;

import android.view.View;
import c.h.j.z;

public class a implements z {
  public boolean a = false;
  
  public int b;
  
  public a(b paramb) {}
  
  public void a(View paramView) {
    this.a = true;
  }
  
  public void b(View paramView) {
    if (this.a)
      return; 
    b b1 = this.c;
    b1.j = null;
    b.b(b1, this.b);
  }
  
  public void c(View paramView) {
    b.a(this.c, 0);
    this.a = false;
  }
}


/* Location:              C:\soft\dex2jar-2.0\Https Traffic-dex2jar.jar!\c\b\h\a.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */