package c.b.h;

import android.app.Activity;
import android.content.Context;
import android.content.ContextWrapper;
import android.content.res.Resources;
import android.graphics.Rect;
import android.os.Build;
import android.util.DisplayMetrics;
import android.util.Log;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewConfiguration;
import android.view.ViewGroup;
import android.view.WindowManager;
import android.view.accessibility.AccessibilityManager;
import c.h.j.u;
import c.h.j.v;
import java.lang.reflect.Method;
import java.util.concurrent.atomic.AtomicInteger;

public class q2 implements View.OnLongClickListener, View.OnHoverListener, View.OnAttachStateChangeListener {
  public static q2 n;
  
  public static q2 o;
  
  public final View e;
  
  public final CharSequence f;
  
  public final int g;
  
  public final Runnable h;
  
  public final Runnable i;
  
  public int j;
  
  public int k;
  
  public r2 l;
  
  public boolean m;
  
  public q2(View paramView, CharSequence paramCharSequence) {
    int i;
    this.h = new o2(this);
    this.i = new p2(this);
    this.e = paramView;
    this.f = paramCharSequence;
    ViewConfiguration viewConfiguration = ViewConfiguration.get(paramView.getContext());
    Method method = v.a;
    if (Build.VERSION.SDK_INT >= 28) {
      i = viewConfiguration.getScaledHoverSlop();
    } else {
      i = viewConfiguration.getScaledTouchSlop() / 2;
    } 
    this.g = i;
    a();
    paramView.setOnLongClickListener(this);
    paramView.setOnHoverListener(this);
  }
  
  public static void c(q2 paramq2) {
    q2 q21 = n;
    if (q21 != null)
      q21.e.removeCallbacks(q21.h); 
    n = paramq2;
    if (paramq2 != null)
      paramq2.e.postDelayed(paramq2.h, ViewConfiguration.getLongPressTimeout()); 
  }
  
  public final void a() {
    this.j = Integer.MAX_VALUE;
    this.k = Integer.MAX_VALUE;
  }
  
  public void b() {
    if (o == this) {
      o = null;
      r2 r21 = this.l;
      if (r21 != null) {
        r21.a();
        this.l = null;
        a();
        this.e.removeOnAttachStateChangeListener(this);
      } else {
        Log.e("TooltipCompatHandler", "sActiveHandler.mPopup == null");
      } 
    } 
    if (n == this)
      c(null); 
    this.e.removeCallbacks(this.i);
  }
  
  public void d(boolean paramBoolean) {
    int i;
    long l;
    View view1;
    View view2 = this.e;
    AtomicInteger atomicInteger = u.a;
    if (!view2.isAttachedToWindow())
      return; 
    c(null);
    q2 q21 = o;
    if (q21 != null)
      q21.b(); 
    o = this;
    this.m = paramBoolean;
    r2 r21 = new r2(this.e.getContext());
    this.l = r21;
    View view4 = this.e;
    int j = this.j;
    int k = this.k;
    paramBoolean = this.m;
    CharSequence charSequence = this.f;
    if (r21.b.getParent() != null) {
      i = 1;
    } else {
      i = 0;
    } 
    if (i)
      r21.a(); 
    r21.c.setText(charSequence);
    WindowManager.LayoutParams layoutParams1 = r21.d;
    layoutParams1.token = view4.getApplicationWindowToken();
    int m = r21.a.getResources().getDimensionPixelOffset(2131100800);
    if (view4.getWidth() >= m) {
      i = j;
    } else {
      i = view4.getWidth() / 2;
    } 
    if (view4.getHeight() >= m) {
      m = r21.a.getResources().getDimensionPixelOffset(2131100799);
      j = k + m;
      k -= m;
    } else {
      j = view4.getHeight();
      k = 0;
    } 
    layoutParams1.gravity = 49;
    Resources resources = r21.a.getResources();
    if (paramBoolean) {
      m = 2131100803;
    } else {
      m = 2131100802;
    } 
    int n = resources.getDimensionPixelOffset(m);
    View view3 = view4.getRootView();
    ViewGroup.LayoutParams layoutParams = view3.getLayoutParams();
    if (layoutParams instanceof WindowManager.LayoutParams && ((WindowManager.LayoutParams)layoutParams).type == 2) {
      view1 = view3;
    } else {
      Context context = view4.getContext();
      while (true) {
        view1 = view3;
        if (context instanceof ContextWrapper) {
          if (context instanceof Activity) {
            view1 = ((Activity)context).getWindow().getDecorView();
            break;
          } 
          context = ((ContextWrapper)context).getBaseContext();
          continue;
        } 
        break;
      } 
    } 
    if (view1 == null) {
      Log.e("TooltipPopup", "Cannot find app view");
    } else {
      view1.getWindowVisibleDisplayFrame(r21.e);
      Rect rect = r21.e;
      if (rect.left < 0 && rect.top < 0) {
        Resources resources1 = r21.a.getResources();
        m = resources1.getIdentifier("status_bar_height", "dimen", "android");
        if (m != 0) {
          m = resources1.getDimensionPixelSize(m);
        } else {
          m = 0;
        } 
        DisplayMetrics displayMetrics = resources1.getDisplayMetrics();
        r21.e.set(0, m, displayMetrics.widthPixels, displayMetrics.heightPixels);
      } 
      view1.getLocationOnScreen(r21.g);
      view4.getLocationOnScreen(r21.f);
      int[] arrayOfInt2 = r21.f;
      m = arrayOfInt2[0];
      int[] arrayOfInt3 = r21.g;
      arrayOfInt2[0] = m - arrayOfInt3[0];
      arrayOfInt2[1] = arrayOfInt2[1] - arrayOfInt3[1];
      layoutParams1.x = arrayOfInt2[0] + i - view1.getWidth() / 2;
      i = View.MeasureSpec.makeMeasureSpec(0, 0);
      r21.b.measure(i, i);
      i = r21.b.getMeasuredHeight();
      int[] arrayOfInt1 = r21.f;
      k = arrayOfInt1[1] + k - n - i;
      j = arrayOfInt1[1] + j + n;
      if (paramBoolean) {
        if (k >= 0) {
          layoutParams1.y = k;
        } else {
          layoutParams1.y = j;
        } 
      } else if (i + j <= r21.e.height()) {
        layoutParams1.y = j;
      } else {
        layoutParams1.y = k;
      } 
    } 
    ((WindowManager)r21.a.getSystemService("window")).addView(r21.b, (ViewGroup.LayoutParams)r21.d);
    this.e.addOnAttachStateChangeListener(this);
    if (this.m) {
      l = 2500L;
    } else {
      if ((this.e.getWindowSystemUiVisibility() & 0x1) == 1) {
        l = 3000L;
        i = ViewConfiguration.getLongPressTimeout();
      } else {
        l = 15000L;
        i = ViewConfiguration.getLongPressTimeout();
      } 
      l -= i;
    } 
    this.e.removeCallbacks(this.i);
    this.e.postDelayed(this.i, l);
  }
  
  public boolean onHover(View paramView, MotionEvent paramMotionEvent) {
    if (this.l != null && this.m)
      return false; 
    AccessibilityManager accessibilityManager = (AccessibilityManager)this.e.getContext().getSystemService("accessibility");
    if (accessibilityManager.isEnabled() && accessibilityManager.isTouchExplorationEnabled())
      return false; 
    int i = paramMotionEvent.getAction();
    if (i != 7) {
      if (i != 10)
        return false; 
      a();
      b();
      return false;
    } 
    if (this.e.isEnabled() && this.l == null) {
      i = (int)paramMotionEvent.getX();
      int j = (int)paramMotionEvent.getY();
      if (Math.abs(i - this.j) <= this.g && Math.abs(j - this.k) <= this.g) {
        i = 0;
      } else {
        this.j = i;
        this.k = j;
        i = 1;
      } 
      if (i != 0)
        c(this); 
    } 
    return false;
  }
  
  public boolean onLongClick(View paramView) {
    this.j = paramView.getWidth() / 2;
    this.k = paramView.getHeight() / 2;
    d(true);
    return true;
  }
  
  public void onViewAttachedToWindow(View paramView) {}
  
  public void onViewDetachedFromWindow(View paramView) {
    b();
  }
}


/* Location:              C:\soft\dex2jar-2.0\Https Traffic-dex2jar.jar!\c\b\h\q2.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */