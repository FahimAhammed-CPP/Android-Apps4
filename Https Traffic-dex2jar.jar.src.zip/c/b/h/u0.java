package c.b.h;

import android.content.Context;
import android.content.res.ColorStateList;
import android.graphics.PorterDuff;
import android.graphics.Typeface;
import android.graphics.drawable.Drawable;
import android.os.Build;
import android.text.TextDirectionHeuristic;
import android.text.TextDirectionHeuristics;
import android.util.AttributeSet;
import android.view.ActionMode;
import android.view.View;
import android.view.inputmethod.EditorInfo;
import android.view.inputmethod.InputConnection;
import android.view.textclassifier.TextClassifier;
import android.widget.TextView;
import c.b.a;
import c.b.d.a.a;
import c.h.b.h;
import c.h.d.e;
import c.h.d.m;
import c.h.h.c;
import c.h.h.d;
import c.h.k.c;
import c.h.k.g;
import java.util.concurrent.Future;

public class u0 extends TextView implements g, c {
  public final o e;
  
  public final t0 f;
  
  public final r0 g;
  
  public Future<d> h;
  
  public u0(Context paramContext) {
    this(paramContext, null, 16842884);
  }
  
  public u0(Context paramContext, AttributeSet paramAttributeSet, int paramInt) {
    super(paramContext, paramAttributeSet, paramInt);
    f2.a((View)this, getContext());
    o o1 = new o((View)this);
    this.e = o1;
    o1.d(paramAttributeSet, paramInt);
    t0 t01 = new t0(this);
    this.f = t01;
    t01.e(paramAttributeSet, paramInt);
    t01.b();
    this.g = new r0(this);
  }
  
  public final void c() {
    Future<d> future = this.h;
    if (future != null)
      try {
        this.h = null;
        d d = future.get();
        if (Build.VERSION.SDK_INT >= 29)
          throw null; 
        h.H(this);
        throw null;
      } catch (InterruptedException|java.util.concurrent.ExecutionException interruptedException) {
        return;
      }  
  }
  
  public void drawableStateChanged() {
    super.drawableStateChanged();
    o o1 = this.e;
    if (o1 != null)
      o1.a(); 
    t0 t01 = this.f;
    if (t01 != null)
      t01.b(); 
  }
  
  public int getAutoSizeMaxTextSize() {
    if (c.a)
      return super.getAutoSizeMaxTextSize(); 
    t0 t01 = this.f;
    return (t01 != null) ? Math.round(t01.i.e) : -1;
  }
  
  public int getAutoSizeMinTextSize() {
    if (c.a)
      return super.getAutoSizeMinTextSize(); 
    t0 t01 = this.f;
    return (t01 != null) ? Math.round(t01.i.d) : -1;
  }
  
  public int getAutoSizeStepGranularity() {
    if (c.a)
      return super.getAutoSizeStepGranularity(); 
    t0 t01 = this.f;
    return (t01 != null) ? Math.round(t01.i.c) : -1;
  }
  
  public int[] getAutoSizeTextAvailableSizes() {
    if (c.a)
      return super.getAutoSizeTextAvailableSizes(); 
    t0 t01 = this.f;
    return (t01 != null) ? t01.i.f : new int[0];
  }
  
  public int getAutoSizeTextType() {
    boolean bool1 = c.a;
    boolean bool = false;
    if (bool1) {
      if (super.getAutoSizeTextType() == 1)
        bool = true; 
      return bool;
    } 
    t0 t01 = this.f;
    return (t01 != null) ? t01.i.a : 0;
  }
  
  public int getFirstBaselineToTopHeight() {
    return getPaddingTop() - (getPaint().getFontMetricsInt()).top;
  }
  
  public int getLastBaselineToBottomHeight() {
    return getPaddingBottom() + (getPaint().getFontMetricsInt()).bottom;
  }
  
  public ColorStateList getSupportBackgroundTintList() {
    o o1 = this.e;
    return (o1 != null) ? o1.b() : null;
  }
  
  public PorterDuff.Mode getSupportBackgroundTintMode() {
    o o1 = this.e;
    return (o1 != null) ? o1.c() : null;
  }
  
  public ColorStateList getSupportCompoundDrawablesTintList() {
    h2 h2 = this.f.h;
    return (h2 != null) ? h2.a : null;
  }
  
  public PorterDuff.Mode getSupportCompoundDrawablesTintMode() {
    h2 h2 = this.f.h;
    return (h2 != null) ? h2.b : null;
  }
  
  public CharSequence getText() {
    c();
    return super.getText();
  }
  
  public TextClassifier getTextClassifier() {
    if (Build.VERSION.SDK_INT < 28) {
      r0 r01 = this.g;
      if (r01 != null)
        return r01.a(); 
    } 
    return super.getTextClassifier();
  }
  
  public c getTextMetricsParamsCompat() {
    return h.H(this);
  }
  
  public InputConnection onCreateInputConnection(EditorInfo paramEditorInfo) {
    InputConnection inputConnection = super.onCreateInputConnection(paramEditorInfo);
    a.e(inputConnection, paramEditorInfo, (View)this);
    return inputConnection;
  }
  
  public void onLayout(boolean paramBoolean, int paramInt1, int paramInt2, int paramInt3, int paramInt4) {
    super.onLayout(paramBoolean, paramInt1, paramInt2, paramInt3, paramInt4);
    t0 t01 = this.f;
    if (t01 != null && !c.a)
      t01.i.a(); 
  }
  
  public void onMeasure(int paramInt1, int paramInt2) {
    c();
    super.onMeasure(paramInt1, paramInt2);
  }
  
  public void onTextChanged(CharSequence paramCharSequence, int paramInt1, int paramInt2, int paramInt3) {
    super.onTextChanged(paramCharSequence, paramInt1, paramInt2, paramInt3);
    t0 t01 = this.f;
    if (t01 != null && !c.a && t01.d())
      this.f.i.a(); 
  }
  
  public void setAutoSizeTextTypeUniformWithConfiguration(int paramInt1, int paramInt2, int paramInt3, int paramInt4) {
    if (c.a) {
      super.setAutoSizeTextTypeUniformWithConfiguration(paramInt1, paramInt2, paramInt3, paramInt4);
      return;
    } 
    t0 t01 = this.f;
    if (t01 != null)
      t01.g(paramInt1, paramInt2, paramInt3, paramInt4); 
  }
  
  public void setAutoSizeTextTypeUniformWithPresetSizes(int[] paramArrayOfint, int paramInt) {
    if (c.a) {
      super.setAutoSizeTextTypeUniformWithPresetSizes(paramArrayOfint, paramInt);
      return;
    } 
    t0 t01 = this.f;
    if (t01 != null)
      t01.h(paramArrayOfint, paramInt); 
  }
  
  public void setAutoSizeTextTypeWithDefaults(int paramInt) {
    if (c.a) {
      super.setAutoSizeTextTypeWithDefaults(paramInt);
      return;
    } 
    t0 t01 = this.f;
    if (t01 != null)
      t01.i(paramInt); 
  }
  
  public void setBackgroundDrawable(Drawable paramDrawable) {
    super.setBackgroundDrawable(paramDrawable);
    o o1 = this.e;
    if (o1 != null)
      o1.e(); 
  }
  
  public void setBackgroundResource(int paramInt) {
    super.setBackgroundResource(paramInt);
    o o1 = this.e;
    if (o1 != null)
      o1.f(paramInt); 
  }
  
  public void setCompoundDrawables(Drawable paramDrawable1, Drawable paramDrawable2, Drawable paramDrawable3, Drawable paramDrawable4) {
    super.setCompoundDrawables(paramDrawable1, paramDrawable2, paramDrawable3, paramDrawable4);
    t0 t01 = this.f;
    if (t01 != null)
      t01.b(); 
  }
  
  public void setCompoundDrawablesRelative(Drawable paramDrawable1, Drawable paramDrawable2, Drawable paramDrawable3, Drawable paramDrawable4) {
    super.setCompoundDrawablesRelative(paramDrawable1, paramDrawable2, paramDrawable3, paramDrawable4);
    t0 t01 = this.f;
    if (t01 != null)
      t01.b(); 
  }
  
  public void setCompoundDrawablesRelativeWithIntrinsicBounds(int paramInt1, int paramInt2, int paramInt3, int paramInt4) {
    Drawable drawable1;
    Drawable drawable2;
    Drawable drawable3;
    Context context = getContext();
    Drawable drawable4 = null;
    if (paramInt1 != 0) {
      drawable1 = a.a(context, paramInt1);
    } else {
      drawable1 = null;
    } 
    if (paramInt2 != 0) {
      drawable2 = a.a(context, paramInt2);
    } else {
      drawable2 = null;
    } 
    if (paramInt3 != 0) {
      drawable3 = a.a(context, paramInt3);
    } else {
      drawable3 = null;
    } 
    if (paramInt4 != 0)
      drawable4 = a.a(context, paramInt4); 
    setCompoundDrawablesRelativeWithIntrinsicBounds(drawable1, drawable2, drawable3, drawable4);
    t0 t01 = this.f;
    if (t01 != null)
      t01.b(); 
  }
  
  public void setCompoundDrawablesRelativeWithIntrinsicBounds(Drawable paramDrawable1, Drawable paramDrawable2, Drawable paramDrawable3, Drawable paramDrawable4) {
    super.setCompoundDrawablesRelativeWithIntrinsicBounds(paramDrawable1, paramDrawable2, paramDrawable3, paramDrawable4);
    t0 t01 = this.f;
    if (t01 != null)
      t01.b(); 
  }
  
  public void setCompoundDrawablesWithIntrinsicBounds(int paramInt1, int paramInt2, int paramInt3, int paramInt4) {
    Drawable drawable1;
    Drawable drawable2;
    Drawable drawable3;
    Context context = getContext();
    Drawable drawable4 = null;
    if (paramInt1 != 0) {
      drawable1 = a.a(context, paramInt1);
    } else {
      drawable1 = null;
    } 
    if (paramInt2 != 0) {
      drawable2 = a.a(context, paramInt2);
    } else {
      drawable2 = null;
    } 
    if (paramInt3 != 0) {
      drawable3 = a.a(context, paramInt3);
    } else {
      drawable3 = null;
    } 
    if (paramInt4 != 0)
      drawable4 = a.a(context, paramInt4); 
    setCompoundDrawablesWithIntrinsicBounds(drawable1, drawable2, drawable3, drawable4);
    t0 t01 = this.f;
    if (t01 != null)
      t01.b(); 
  }
  
  public void setCompoundDrawablesWithIntrinsicBounds(Drawable paramDrawable1, Drawable paramDrawable2, Drawable paramDrawable3, Drawable paramDrawable4) {
    super.setCompoundDrawablesWithIntrinsicBounds(paramDrawable1, paramDrawable2, paramDrawable3, paramDrawable4);
    t0 t01 = this.f;
    if (t01 != null)
      t01.b(); 
  }
  
  public void setCustomSelectionActionModeCallback(ActionMode.Callback paramCallback) {
    super.setCustomSelectionActionModeCallback(h.n0(this, paramCallback));
  }
  
  public void setFirstBaselineToTopHeight(int paramInt) {
    if (Build.VERSION.SDK_INT >= 28) {
      super.setFirstBaselineToTopHeight(paramInt);
      return;
    } 
    h.e0(this, paramInt);
  }
  
  public void setLastBaselineToBottomHeight(int paramInt) {
    if (Build.VERSION.SDK_INT >= 28) {
      super.setLastBaselineToBottomHeight(paramInt);
      return;
    } 
    h.f0(this, paramInt);
  }
  
  public void setLineHeight(int paramInt) {
    h.g0(this, paramInt);
  }
  
  public void setPrecomputedText(d paramd) {
    if (Build.VERSION.SDK_INT >= 29)
      throw null; 
    h.H(this);
    throw null;
  }
  
  public void setSupportBackgroundTintList(ColorStateList paramColorStateList) {
    o o1 = this.e;
    if (o1 != null)
      o1.h(paramColorStateList); 
  }
  
  public void setSupportBackgroundTintMode(PorterDuff.Mode paramMode) {
    o o1 = this.e;
    if (o1 != null)
      o1.i(paramMode); 
  }
  
  public void setSupportCompoundDrawablesTintList(ColorStateList paramColorStateList) {
    this.f.j(paramColorStateList);
    this.f.b();
  }
  
  public void setSupportCompoundDrawablesTintMode(PorterDuff.Mode paramMode) {
    this.f.k(paramMode);
    this.f.b();
  }
  
  public void setTextAppearance(Context paramContext, int paramInt) {
    super.setTextAppearance(paramContext, paramInt);
    t0 t01 = this.f;
    if (t01 != null)
      t01.f(paramContext, paramInt); 
  }
  
  public void setTextClassifier(TextClassifier paramTextClassifier) {
    if (Build.VERSION.SDK_INT < 28) {
      r0 r01 = this.g;
      if (r01 != null) {
        r01.b = paramTextClassifier;
        return;
      } 
    } 
    super.setTextClassifier(paramTextClassifier);
  }
  
  public void setTextFuture(Future<d> paramFuture) {
    this.h = paramFuture;
    if (paramFuture != null)
      requestLayout(); 
  }
  
  public void setTextMetricsParamsCompat(c paramc) {
    TextDirectionHeuristic textDirectionHeuristic1 = paramc.b;
    TextDirectionHeuristic textDirectionHeuristic2 = TextDirectionHeuristics.FIRSTSTRONG_RTL;
    byte b = 1;
    if (textDirectionHeuristic1 != textDirectionHeuristic2 && textDirectionHeuristic1 != TextDirectionHeuristics.FIRSTSTRONG_LTR)
      if (textDirectionHeuristic1 == TextDirectionHeuristics.ANYRTL_LTR) {
        b = 2;
      } else if (textDirectionHeuristic1 == TextDirectionHeuristics.LTR) {
        b = 3;
      } else if (textDirectionHeuristic1 == TextDirectionHeuristics.RTL) {
        b = 4;
      } else if (textDirectionHeuristic1 == TextDirectionHeuristics.LOCALE) {
        b = 5;
      } else if (textDirectionHeuristic1 == TextDirectionHeuristics.FIRSTSTRONG_LTR) {
        b = 6;
      } else if (textDirectionHeuristic1 == TextDirectionHeuristics.FIRSTSTRONG_RTL) {
        b = 7;
      }  
    setTextDirection(b);
    getPaint().set(paramc.a);
    setBreakStrategy(paramc.c);
    setHyphenationFrequency(paramc.d);
  }
  
  public void setTextSize(int paramInt, float paramFloat) {
    boolean bool = c.a;
    if (bool) {
      super.setTextSize(paramInt, paramFloat);
      return;
    } 
    t0 t01 = this.f;
    if (t01 != null && !bool && !t01.d())
      t01.i.f(paramInt, paramFloat); 
  }
  
  public void setTypeface(Typeface paramTypeface, int paramInt) {
    Typeface typeface;
    if (paramTypeface != null && paramInt > 0) {
      typeface = (Typeface)getContext();
      m m = e.a;
      if (typeface != null) {
        Typeface typeface1 = Typeface.create(paramTypeface, paramInt);
      } else {
        throw new IllegalArgumentException("Context cannot be null");
      } 
    } else {
      typeface = null;
    } 
    if (typeface != null)
      paramTypeface = typeface; 
    super.setTypeface(paramTypeface, paramInt);
  }
}


/* Location:              C:\soft\dex2jar-2.0\Https Traffic-dex2jar.jar!\c\b\\\u0.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */