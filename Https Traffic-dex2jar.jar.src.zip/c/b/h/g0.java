package c.b.h;

import android.view.ViewTreeObserver;

public class g0 implements ViewTreeObserver.OnGlobalLayoutListener {
  public g0(q0 paramq0) {}
  
  public void onGlobalLayout() {
    if (!this.e.getInternalPopup().b())
      this.e.b(); 
    ViewTreeObserver viewTreeObserver = this.e.getViewTreeObserver();
    if (viewTreeObserver != null)
      viewTreeObserver.removeOnGlobalLayoutListener(this); 
  }
}


/* Location:              C:\soft\dex2jar-2.0\Https Traffic-dex2jar.jar!\c\b\h\g0.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */