package c.b.h;

import android.content.res.Resources;

public abstract class s2 extends Resources {}


/* Location:              C:\soft\dex2jar-2.0\Https Traffic-dex2jar.jar!\c\b\h\s2.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */