package c.b.h;

import android.graphics.PorterDuffColorFilter;
import c.e.g;

public class w1 extends g<Integer, PorterDuffColorFilter> {
  public w1(int paramInt) {
    super(paramInt);
  }
}


/* Location:              C:\soft\dex2jar-2.0\Https Traffic-dex2jar.jar!\c\b\h\w1.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */