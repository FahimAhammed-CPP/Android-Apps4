package c.b.h;

import android.content.Context;
import android.content.res.ColorStateList;
import android.graphics.PorterDuff;
import android.graphics.drawable.Drawable;
import android.util.AttributeSet;
import android.view.View;
import android.widget.ImageView;
import c.b.b;
import c.b.d.a.a;
import c.h.j.u;

public class x {
  public final ImageView a;
  
  public h2 b;
  
  public x(ImageView paramImageView) {
    this.a = paramImageView;
  }
  
  public void a() {
    Drawable drawable = this.a.getDrawable();
    if (drawable != null)
      int[] arrayOfInt = c1.a; 
    if (drawable != null) {
      h2 h21 = this.b;
      if (h21 != null)
        u.f(drawable, h21, this.a.getDrawableState()); 
    } 
  }
  
  public void b(AttributeSet paramAttributeSet, int paramInt) {
    Context context = this.a.getContext();
    int[] arrayOfInt = b.f;
    j2 j2 = j2.q(context, paramAttributeSet, arrayOfInt, paramInt, 0);
    ImageView imageView = this.a;
    u.m((View)imageView, imageView.getContext(), arrayOfInt, paramAttributeSet, j2.b, paramInt, 0);
    try {
      Drawable drawable2 = this.a.getDrawable();
      Drawable drawable1 = drawable2;
      if (drawable2 == null) {
        paramInt = j2.l(1, -1);
        drawable1 = drawable2;
        if (paramInt != -1) {
          drawable2 = a.a(this.a.getContext(), paramInt);
          drawable1 = drawable2;
          if (drawable2 != null) {
            this.a.setImageDrawable(drawable2);
            drawable1 = drawable2;
          } 
        } 
      } 
      if (drawable1 != null)
        int[] arrayOfInt1 = c1.a; 
      if (j2.o(2))
        this.a.setImageTintList(j2.c(2)); 
      if (j2.o(3))
        this.a.setImageTintMode(c1.b(j2.j(3, -1), null)); 
      return;
    } finally {
      j2.b.recycle();
    } 
  }
  
  public void c(int paramInt) {
    if (paramInt != 0) {
      Drawable drawable = a.a(this.a.getContext(), paramInt);
      if (drawable != null)
        int[] arrayOfInt = c1.a; 
      this.a.setImageDrawable(drawable);
    } else {
      this.a.setImageDrawable(null);
    } 
    a();
  }
  
  public void d(ColorStateList paramColorStateList) {
    if (this.b == null)
      this.b = new h2(); 
    h2 h21 = this.b;
    h21.a = paramColorStateList;
    h21.d = true;
    a();
  }
  
  public void e(PorterDuff.Mode paramMode) {
    if (this.b == null)
      this.b = new h2(); 
    h2 h21 = this.b;
    h21.b = paramMode;
    h21.c = true;
    a();
  }
}


/* Location:              C:\soft\dex2jar-2.0\Https Traffic-dex2jar.jar!\c\b\h\x.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */