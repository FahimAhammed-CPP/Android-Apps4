package c.b.c;

import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import c.b.g.a;
import c.b.g.b;
import c.h.j.u;
import c.h.j.y;
import c.h.j.z;
import java.util.concurrent.atomic.AtomicInteger;

public class b0 implements a {
  public a a;
  
  public b0(k0 paramk0, a parama) {
    this.a = parama;
  }
  
  public boolean a(b paramb, Menu paramMenu) {
    ViewGroup viewGroup = this.b.x;
    AtomicInteger atomicInteger = u.a;
    viewGroup.requestApplyInsets();
    return this.a.a(paramb, paramMenu);
  }
  
  public void b(b paramb) {
    this.a.b(paramb);
    k0 k01 = this.b;
    if (k01.t != null)
      k01.i.getDecorView().removeCallbacks(this.b.u); 
    k01 = this.b;
    if (k01.s != null) {
      k01.w();
      k01 = this.b;
      y y2 = u.b((View)k01.s);
      y2.a(0.0F);
      k01.v = y2;
      y y1 = this.b.v;
      a0 a0 = new a0(this);
      View view = y1.a.get();
      if (view != null)
        y1.e(view, (z)a0); 
    } 
    k01 = this.b;
    q q = k01.k;
    if (q != null)
      q.g(k01.r); 
    k01 = this.b;
    k01.r = null;
    ViewGroup viewGroup = k01.x;
    AtomicInteger atomicInteger = u.a;
    viewGroup.requestApplyInsets();
  }
  
  public boolean c(b paramb, MenuItem paramMenuItem) {
    return this.a.c(paramb, paramMenuItem);
  }
  
  public boolean d(b paramb, Menu paramMenu) {
    return this.a.d(paramb, paramMenu);
  }
}


/* Location:              C:\soft\dex2jar-2.0\Https Traffic-dex2jar.jar!\c\b\c\b0.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */