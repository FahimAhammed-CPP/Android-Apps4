package c.b.c;

import android.content.Context;
import android.content.res.Configuration;
import android.graphics.drawable.Drawable;
import android.view.KeyCharacterMap;
import android.view.KeyEvent;
import android.view.Menu;
import android.view.Window;
import androidx.appcompat.widget.ActionMenuView;
import androidx.appcompat.widget.Toolbar;
import c.b.g.n.o;
import c.b.h.b1;
import c.b.h.n2;
import c.h.j.u;
import java.util.ArrayList;
import java.util.concurrent.atomic.AtomicInteger;

public class t0 extends a {
  public b1 a;
  
  public boolean b;
  
  public Window.Callback c;
  
  public boolean d;
  
  public boolean e;
  
  public ArrayList<b> f = new ArrayList<b>();
  
  public final Runnable g = new o0(this);
  
  public final Toolbar.f h;
  
  public t0(Toolbar paramToolbar, CharSequence paramCharSequence, Window.Callback paramCallback) {
    p0 p0 = new p0(this);
    this.h = p0;
    this.a = (b1)new n2(paramToolbar, false);
    s0 s0 = new s0(this, paramCallback);
    this.c = (Window.Callback)s0;
    ((n2)this.a).l = (Window.Callback)s0;
    paramToolbar.setOnMenuItemClickListener(p0);
    ((n2)this.a).f(paramCharSequence);
  }
  
  public boolean a() {
    return ((n2)this.a).b();
  }
  
  public boolean b() {
    boolean bool;
    Toolbar.d d = ((n2)this.a).a.O;
    if (d != null && d.f != null) {
      bool = true;
    } else {
      bool = false;
    } 
    if (bool) {
      o o;
      if (d == null) {
        d = null;
      } else {
        o = d.f;
      } 
      if (o != null)
        o.collapseActionView(); 
      return true;
    } 
    return false;
  }
  
  public void c(boolean paramBoolean) {
    if (paramBoolean == this.e)
      return; 
    this.e = paramBoolean;
    int j = this.f.size();
    for (int i = 0; i < j; i++)
      ((b)this.f.get(i)).a(paramBoolean); 
  }
  
  public int d() {
    return ((n2)this.a).b;
  }
  
  public Context e() {
    return ((n2)this.a).a();
  }
  
  public boolean f() {
    ((n2)this.a).a.removeCallbacks(this.g);
    Toolbar toolbar = ((n2)this.a).a;
    Runnable runnable = this.g;
    AtomicInteger atomicInteger = u.a;
    toolbar.postOnAnimation(runnable);
    return true;
  }
  
  public void g(Configuration paramConfiguration) {}
  
  public void h() {
    ((n2)this.a).a.removeCallbacks(this.g);
  }
  
  public boolean i(int paramInt, KeyEvent paramKeyEvent) {
    Menu menu = s();
    if (menu != null) {
      if (paramKeyEvent != null) {
        i = paramKeyEvent.getDeviceId();
      } else {
        i = -1;
      } 
      int i = KeyCharacterMap.load(i).getKeyboardType();
      boolean bool = true;
      if (i == 1)
        bool = false; 
      menu.setQwertyMode(bool);
      return menu.performShortcut(paramInt, paramKeyEvent, 0);
    } 
    return false;
  }
  
  public boolean j(KeyEvent paramKeyEvent) {
    if (paramKeyEvent.getAction() == 1)
      ((n2)this.a).a.u(); 
    return true;
  }
  
  public boolean k() {
    return ((n2)this.a).a.u();
  }
  
  public void l(boolean paramBoolean) {}
  
  public void m(int paramInt) {
    ((n2)this.a).d(paramInt);
  }
  
  public void n(Drawable paramDrawable) {
    n2 n2 = (n2)this.a;
    n2.g = paramDrawable;
    n2.i();
  }
  
  public void o(boolean paramBoolean) {}
  
  public void p(CharSequence paramCharSequence) {
    ((n2)this.a).e(paramCharSequence);
  }
  
  public void q(CharSequence paramCharSequence) {
    ((n2)this.a).f(paramCharSequence);
  }
  
  public final Menu s() {
    if (!this.d) {
      b1 b11 = this.a;
      q0 q0 = new q0(this);
      r0 r0 = new r0(this);
      Toolbar toolbar = ((n2)b11).a;
      toolbar.P = q0;
      toolbar.Q = r0;
      ActionMenuView actionMenuView = toolbar.e;
      if (actionMenuView != null) {
        actionMenuView.y = q0;
        actionMenuView.z = r0;
      } 
      this.d = true;
    } 
    return ((n2)this.a).a.getMenu();
  }
}


/* Location:              C:\soft\dex2jar-2.0\Https Traffic-dex2jar.jar!\c\b\c\t0.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */