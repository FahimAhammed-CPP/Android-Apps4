package c.b.c;

import android.content.Context;
import android.content.IntentFilter;
import android.os.PowerManager;

public class d0 extends f0 {
  public final PowerManager c;
  
  public d0(k0 paramk0, Context paramContext) {
    super(paramk0);
    this.c = (PowerManager)paramContext.getApplicationContext().getSystemService("power");
  }
  
  public IntentFilter b() {
    IntentFilter intentFilter = new IntentFilter();
    intentFilter.addAction("android.os.action.POWER_SAVE_MODE_CHANGED");
    return intentFilter;
  }
  
  public int c() {
    return this.c.isPowerSaveMode() ? 2 : 1;
  }
  
  public void d() {
    this.d.n();
  }
}


/* Location:              C:\soft\dex2jar-2.0\Https Traffic-dex2jar.jar!\c\b\c\d0.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */