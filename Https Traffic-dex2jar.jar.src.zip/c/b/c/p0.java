package c.b.c;

import androidx.appcompat.widget.Toolbar;

public class p0 implements Toolbar.f {
  public p0(t0 paramt0) {}
}


/* Location:              C:\soft\dex2jar-2.0\Https Traffic-dex2jar.jar!\c\b\c\p0.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */