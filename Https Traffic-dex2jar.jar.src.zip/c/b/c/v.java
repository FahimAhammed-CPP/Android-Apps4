package c.b.c;

import android.view.View;
import c.h.j.a0;

public class v extends a0 {
  public v(w paramw) {}
  
  public void b(View paramView) {
    this.a.e.s.setAlpha(1.0F);
    this.a.e.v.d(null);
    this.a.e.v = null;
  }
  
  public void c(View paramView) {
    this.a.e.s.setVisibility(0);
  }
}


/* Location:              C:\soft\dex2jar-2.0\Https Traffic-dex2jar.jar!\c\b\c\v.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */