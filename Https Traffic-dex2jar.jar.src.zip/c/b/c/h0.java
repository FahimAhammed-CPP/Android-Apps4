package c.b.c;

import android.content.Context;
import android.view.KeyEvent;
import android.view.MotionEvent;
import androidx.appcompat.widget.ContentFrameLayout;
import c.b.d.a.a;

public class h0 extends ContentFrameLayout {
  public h0(k0 paramk0, Context paramContext) {
    super(paramContext, null);
  }
  
  public boolean dispatchKeyEvent(KeyEvent paramKeyEvent) {
    return (this.m.u(paramKeyEvent) || super.dispatchKeyEvent(paramKeyEvent));
  }
  
  public boolean onInterceptTouchEvent(MotionEvent paramMotionEvent) {
    k0 k01;
    if (paramMotionEvent.getAction() == 0) {
      int i = (int)paramMotionEvent.getX();
      int j = (int)paramMotionEvent.getY();
      if (i < -5 || j < -5 || i > getWidth() + 5 || j > getHeight() + 5) {
        i = 1;
      } else {
        i = 0;
      } 
      if (i != 0) {
        k01 = this.m;
        k01.s(k01.C(0), true);
        return true;
      } 
    } 
    return super.onInterceptTouchEvent((MotionEvent)k01);
  }
  
  public void setBackgroundResource(int paramInt) {
    setBackgroundDrawable(a.a(getContext(), paramInt));
  }
}


/* Location:              C:\soft\dex2jar-2.0\Https Traffic-dex2jar.jar!\c\b\c\h0.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */