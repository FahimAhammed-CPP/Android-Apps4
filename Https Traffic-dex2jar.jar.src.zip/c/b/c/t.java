package c.b.c;

import android.os.Build;
import android.view.View;
import android.view.WindowInsets;
import c.h.d.b;
import c.h.j.b0;
import c.h.j.c0;
import c.h.j.d0;
import c.h.j.k;
import c.h.j.l0;
import c.h.j.u;
import java.util.concurrent.atomic.AtomicInteger;

public class t implements k {
  public t(k0 paramk0) {}
  
  public l0 a(View paramView, l0 paraml0) {
    int j = paraml0.e();
    int i = this.a.M(paraml0, null);
    l0 l02 = paraml0;
    if (j != i) {
      d0 d0;
      b0 b0;
      j = paraml0.c();
      int m = paraml0.d();
      int n = paraml0.b();
      int i1 = Build.VERSION.SDK_INT;
      if (i1 >= 30) {
        d0 = new d0(paraml0);
      } else {
        c0 c0;
        if (i1 >= 29) {
          c0 = new c0((l0)d0);
        } else {
          b0 = new b0((l0)c0);
        } 
      } 
      b0.c(b.a(j, i, m, n));
      l02 = b0.a();
    } 
    AtomicInteger atomicInteger = u.a;
    WindowInsets windowInsets = l02.g();
    l0 l01 = l02;
    if (windowInsets != null) {
      WindowInsets windowInsets1 = paramView.onApplyWindowInsets(windowInsets);
      l01 = l02;
      if (!windowInsets1.equals(windowInsets))
        l01 = l0.i(windowInsets1, paramView); 
    } 
    return l01;
  }
}


/* Location:              C:\soft\dex2jar-2.0\Https Traffic-dex2jar.jar!\c\b\c\t.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */