package c.b.c;

import c.b.g.a;
import c.b.g.b;

public interface q {
  void f(b paramb);
  
  void g(b paramb);
  
  b m(a parama);
}


/* Location:              C:\soft\dex2jar-2.0\Https Traffic-dex2jar.jar!\c\b\c\q.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */