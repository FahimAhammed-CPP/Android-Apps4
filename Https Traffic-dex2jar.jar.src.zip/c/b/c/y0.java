package c.b.c;

import android.view.View;
import c.h.j.a0;

public class y0 extends a0 {
  public y0(b1 paramb1) {}
  
  public void b(View paramView) {
    b1 b11 = this.a;
    b11.t = null;
    b11.d.requestLayout();
  }
}


/* Location:              C:\soft\dex2jar-2.0\Https Traffic-dex2jar.jar!\c\b\c\y0.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */