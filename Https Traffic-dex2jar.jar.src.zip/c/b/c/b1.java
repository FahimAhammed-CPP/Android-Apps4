package c.b.c;

import android.app.Activity;
import android.app.Dialog;
import android.content.Context;
import android.content.res.Configuration;
import android.content.res.TypedArray;
import android.graphics.drawable.Drawable;
import android.util.TypedValue;
import android.view.ContextThemeWrapper;
import android.view.KeyCharacterMap;
import android.view.KeyEvent;
import android.view.Menu;
import android.view.View;
import android.view.ViewParent;
import android.view.animation.AccelerateInterpolator;
import android.view.animation.DecelerateInterpolator;
import android.view.animation.Interpolator;
import androidx.appcompat.widget.ActionBarContainer;
import androidx.appcompat.widget.ActionBarContextView;
import androidx.appcompat.widget.ActionBarOverlayLayout;
import androidx.appcompat.widget.Toolbar;
import c.b.b;
import c.b.g.a;
import c.b.g.b;
import c.b.g.l;
import c.b.g.n.l;
import c.b.g.n.o;
import c.b.h.n2;
import c.h.j.u;
import c.h.j.y;
import c.h.j.z;
import d.a.a.a.a;
import java.util.ArrayList;
import java.util.Objects;
import java.util.concurrent.atomic.AtomicInteger;

public class b1 extends a implements ActionBarOverlayLayout.d {
  public static final Interpolator A;
  
  public static final Interpolator z = (Interpolator)new AccelerateInterpolator();
  
  public Context a;
  
  public Context b;
  
  public ActionBarOverlayLayout c;
  
  public ActionBarContainer d;
  
  public c.b.h.b1 e;
  
  public ActionBarContextView f;
  
  public View g;
  
  public boolean h;
  
  public a1 i;
  
  public b j;
  
  public a k;
  
  public boolean l;
  
  public ArrayList<b> m;
  
  public boolean n;
  
  public int o;
  
  public boolean p;
  
  public boolean q;
  
  public boolean r;
  
  public boolean s;
  
  public l t;
  
  public boolean u;
  
  public boolean v;
  
  public final z w;
  
  public final z x;
  
  public final z0 y;
  
  static {
    A = (Interpolator)new DecelerateInterpolator();
  }
  
  public b1(Activity paramActivity, boolean paramBoolean) {
    new ArrayList();
    this.m = new ArrayList<b>();
    this.o = 0;
    this.p = true;
    this.s = true;
    this.w = (z)new x0(this);
    this.x = (z)new y0(this);
    this.y = new z0(this);
    View view = paramActivity.getWindow().getDecorView();
    t(view);
    if (!paramBoolean)
      this.g = view.findViewById(16908290); 
  }
  
  public b1(Dialog paramDialog) {
    new ArrayList();
    this.m = new ArrayList<b>();
    this.o = 0;
    this.p = true;
    this.s = true;
    this.w = (z)new x0(this);
    this.x = (z)new y0(this);
    this.y = new z0(this);
    t(paramDialog.getWindow().getDecorView());
  }
  
  public boolean b() {
    c.b.h.b1 b11 = this.e;
    if (b11 != null) {
      boolean bool;
      Toolbar.d d1 = ((n2)b11).a.O;
      if (d1 != null && d1.f != null) {
        bool = true;
      } else {
        bool = false;
      } 
      if (bool) {
        o o;
        if (d1 == null) {
          d1 = null;
        } else {
          o = d1.f;
        } 
        if (o != null)
          o.collapseActionView(); 
        return true;
      } 
    } 
    return false;
  }
  
  public void c(boolean paramBoolean) {
    if (paramBoolean == this.l)
      return; 
    this.l = paramBoolean;
    int j = this.m.size();
    for (int i = 0; i < j; i++)
      ((b)this.m.get(i)).a(paramBoolean); 
  }
  
  public int d() {
    return ((n2)this.e).b;
  }
  
  public Context e() {
    if (this.b == null) {
      TypedValue typedValue = new TypedValue();
      this.a.getTheme().resolveAttribute(2130903050, typedValue, true);
      int i = typedValue.resourceId;
      if (i != 0) {
        this.b = (Context)new ContextThemeWrapper(this.a, i);
      } else {
        this.b = this.a;
      } 
    } 
    return this.b;
  }
  
  public void g(Configuration paramConfiguration) {
    u(this.a.getResources().getBoolean(2130968576));
  }
  
  public boolean i(int paramInt, KeyEvent paramKeyEvent) {
    a1 a11 = this.i;
    if (a11 == null)
      return false; 
    l l1 = a11.h;
    if (l1 != null) {
      if (paramKeyEvent != null) {
        i = paramKeyEvent.getDeviceId();
      } else {
        i = -1;
      } 
      int i = KeyCharacterMap.load(i).getKeyboardType();
      boolean bool = true;
      if (i == 1)
        bool = false; 
      l1.setQwertyMode(bool);
      return l1.performShortcut(paramInt, paramKeyEvent, 0);
    } 
    return false;
  }
  
  public void l(boolean paramBoolean) {
    if (!this.h) {
      boolean bool;
      if (paramBoolean) {
        bool = true;
      } else {
        bool = false;
      } 
      n2 n2 = (n2)this.e;
      int i = n2.b;
      this.h = true;
      n2.c(bool & 0x4 | i & 0xFFFFFFFB);
    } 
  }
  
  public void m(int paramInt) {
    ((n2)this.e).d(paramInt);
  }
  
  public void n(Drawable paramDrawable) {
    n2 n2 = (n2)this.e;
    n2.g = paramDrawable;
    n2.i();
  }
  
  public void o(boolean paramBoolean) {
    this.u = paramBoolean;
    if (!paramBoolean) {
      l l1 = this.t;
      if (l1 != null)
        l1.a(); 
    } 
  }
  
  public void p(CharSequence paramCharSequence) {
    ((n2)this.e).e(paramCharSequence);
  }
  
  public void q(CharSequence paramCharSequence) {
    ((n2)this.e).f(paramCharSequence);
  }
  
  public b r(a parama) {
    null = this.i;
    if (null != null)
      null.c(); 
    this.c.setHideOnContentScrollEnabled(false);
    this.f.h();
    a1 a11 = new a1(this, this.f.getContext(), parama);
    a11.h.z();
    try {
      boolean bool = a11.i.d(a11, (Menu)a11.h);
      a11.h.y();
      return null;
    } finally {
      a11.h.y();
    } 
  }
  
  public void s(boolean paramBoolean) {
    if (paramBoolean) {
      if (!this.r) {
        this.r = true;
        ActionBarOverlayLayout actionBarOverlayLayout = this.c;
        if (actionBarOverlayLayout != null)
          actionBarOverlayLayout.setShowingForActionMode(true); 
        v(false);
      } 
    } else if (this.r) {
      this.r = false;
      ActionBarOverlayLayout actionBarOverlayLayout = this.c;
      if (actionBarOverlayLayout != null)
        actionBarOverlayLayout.setShowingForActionMode(false); 
      v(false);
    } 
    ActionBarContainer actionBarContainer = this.d;
    AtomicInteger atomicInteger = u.a;
    if (actionBarContainer.isLaidOut()) {
      long l1;
      y y1;
      y y2;
      if (paramBoolean) {
        y2 = ((n2)this.e).g(4, 100L);
        y1 = this.f.e(0, 200L);
      } else {
        y1 = ((n2)this.e).g(0, 200L);
        y2 = this.f.e(8, 100L);
      } 
      l l2 = new l();
      l2.a.add(y2);
      View view = y2.a.get();
      if (view != null) {
        l1 = view.animate().getDuration();
      } else {
        l1 = 0L;
      } 
      view = y1.a.get();
      if (view != null)
        view.animate().setStartDelay(l1); 
      l2.a.add(y1);
      l2.b();
      return;
    } 
    if (paramBoolean) {
      ((n2)this.e).a.setVisibility(4);
      this.f.setVisibility(0);
      return;
    } 
    ((n2)this.e).a.setVisibility(0);
    this.f.setVisibility(8);
  }
  
  public final void t(View paramView) {
    String str;
    StringBuilder stringBuilder2;
    ActionBarOverlayLayout actionBarOverlayLayout = (ActionBarOverlayLayout)paramView.findViewById(2131230857);
    this.c = actionBarOverlayLayout;
    if (actionBarOverlayLayout != null)
      actionBarOverlayLayout.setActionBarVisibilityCallback(this); 
    View view = paramView.findViewById(2131230769);
    if (view instanceof c.b.h.b1) {
      c.b.h.b1 b12 = (c.b.h.b1)view;
    } else if (view instanceof Toolbar) {
      c.b.h.b1 b12 = ((Toolbar)view).getWrapper();
    } else {
      stringBuilder2 = a.p("Can't make a decor toolbar out of ");
      if (view != null) {
        str = view.getClass().getSimpleName();
      } else {
        str = "null";
      } 
      stringBuilder2.append(str);
      throw new IllegalStateException(stringBuilder2.toString());
    } 
    this.e = (c.b.h.b1)stringBuilder2;
    this.f = (ActionBarContextView)str.findViewById(2131230777);
    ActionBarContainer actionBarContainer = (ActionBarContainer)str.findViewById(2131230771);
    this.d = actionBarContainer;
    c.b.h.b1 b11 = this.e;
    if (b11 != null && this.f != null && actionBarContainer != null) {
      Context context = ((n2)b11).a();
      this.a = context;
      if ((((n2)this.e).b & 0x4) != 0) {
        i = 1;
      } else {
        i = 0;
      } 
      if (i)
        this.h = true; 
      int i = (context.getApplicationInfo()).targetSdkVersion;
      Objects.requireNonNull((n2)this.e);
      u(context.getResources().getBoolean(2130968576));
      TypedArray typedArray = this.a.obtainStyledAttributes(null, b.a, 2130903045, 0);
      if (typedArray.getBoolean(14, false)) {
        ActionBarOverlayLayout actionBarOverlayLayout1 = this.c;
        if (actionBarOverlayLayout1.l) {
          this.v = true;
          actionBarOverlayLayout1.setHideOnContentScrollEnabled(true);
        } else {
          throw new IllegalStateException("Action bar must be in overlay mode (Window.FEATURE_OVERLAY_ACTION_BAR) to enable hide on content scroll");
        } 
      } 
      i = typedArray.getDimensionPixelSize(12, 0);
      if (i != 0) {
        float f = i;
        ActionBarContainer actionBarContainer1 = this.d;
        AtomicInteger atomicInteger = u.a;
        actionBarContainer1.setElevation(f);
      } 
      typedArray.recycle();
      return;
    } 
    StringBuilder stringBuilder1 = new StringBuilder();
    stringBuilder1.append(b1.class.getSimpleName());
    stringBuilder1.append(" can only be used with a compatible window decor layout");
    throw new IllegalStateException(stringBuilder1.toString());
  }
  
  public final void u(boolean paramBoolean) {
    this.n = paramBoolean;
    if (!paramBoolean) {
      n2 n2 = (n2)this.e;
      View view = n2.c;
      if (view != null) {
        ViewParent viewParent = view.getParent();
        Toolbar toolbar = n2.a;
        if (viewParent == toolbar)
          toolbar.removeView(n2.c); 
      } 
      n2.c = null;
      this.d.setTabContainer(null);
    } else {
      this.d.setTabContainer(null);
      n2 n2 = (n2)this.e;
      View view = n2.c;
      if (view != null) {
        ViewParent viewParent = view.getParent();
        Toolbar toolbar = n2.a;
        if (viewParent == toolbar)
          toolbar.removeView(n2.c); 
      } 
      n2.c = null;
    } 
    Objects.requireNonNull(this.e);
    ((n2)this.e).a.setCollapsible(false);
    this.c.setHasNonEmbeddedTabs(false);
  }
  
  public final void v(boolean paramBoolean) {
    boolean bool;
    boolean bool1 = this.q;
    if (!this.r && bool1) {
      bool = false;
    } else {
      bool = true;
    } 
    if (bool) {
      if (!this.s) {
        this.s = true;
        l l1 = this.t;
        if (l1 != null)
          l1.a(); 
        this.d.setVisibility(0);
        if (this.o == 0 && (this.u || paramBoolean)) {
          this.d.setTranslationY(0.0F);
          float f2 = -this.d.getHeight();
          float f1 = f2;
          if (paramBoolean) {
            int[] arrayOfInt = new int[2];
            arrayOfInt[0] = 0;
            arrayOfInt[1] = 0;
            this.d.getLocationInWindow(arrayOfInt);
            f1 = f2 - arrayOfInt[1];
          } 
          this.d.setTranslationY(f1);
          l1 = new l();
          y y = u.b((View)this.d);
          y.g(0.0F);
          y.f(this.y);
          if (!l1.e)
            l1.a.add(y); 
          if (this.p) {
            View view = this.g;
            if (view != null) {
              view.setTranslationY(f1);
              y y1 = u.b(this.g);
              y1.g(0.0F);
              if (!l1.e)
                l1.a.add(y1); 
            } 
          } 
          Interpolator interpolator = A;
          paramBoolean = l1.e;
          if (!paramBoolean)
            l1.c = interpolator; 
          if (!paramBoolean)
            l1.b = 250L; 
          z z1 = this.x;
          if (!paramBoolean)
            l1.d = z1; 
          this.t = l1;
          l1.b();
        } else {
          this.d.setAlpha(1.0F);
          this.d.setTranslationY(0.0F);
          if (this.p) {
            View view = this.g;
            if (view != null)
              view.setTranslationY(0.0F); 
          } 
          this.x.b(null);
        } 
        ActionBarOverlayLayout actionBarOverlayLayout = this.c;
        if (actionBarOverlayLayout != null) {
          AtomicInteger atomicInteger = u.a;
          actionBarOverlayLayout.requestApplyInsets();
          return;
        } 
      } 
    } else if (this.s) {
      this.s = false;
      l l1 = this.t;
      if (l1 != null)
        l1.a(); 
      if (this.o == 0 && (this.u || paramBoolean)) {
        this.d.setAlpha(1.0F);
        this.d.setTransitioning(true);
        l1 = new l();
        float f2 = -this.d.getHeight();
        float f1 = f2;
        if (paramBoolean) {
          int[] arrayOfInt = new int[2];
          arrayOfInt[0] = 0;
          arrayOfInt[1] = 0;
          this.d.getLocationInWindow(arrayOfInt);
          f1 = f2 - arrayOfInt[1];
        } 
        y y = u.b((View)this.d);
        y.g(f1);
        y.f(this.y);
        if (!l1.e)
          l1.a.add(y); 
        if (this.p) {
          View view = this.g;
          if (view != null) {
            y y1 = u.b(view);
            y1.g(f1);
            if (!l1.e)
              l1.a.add(y1); 
          } 
        } 
        Interpolator interpolator = z;
        paramBoolean = l1.e;
        if (!paramBoolean)
          l1.c = interpolator; 
        if (!paramBoolean)
          l1.b = 250L; 
        z z1 = this.w;
        if (!paramBoolean)
          l1.d = z1; 
        this.t = l1;
        l1.b();
        return;
      } 
      this.w.b(null);
    } 
  }
}


/* Location:              C:\soft\dex2jar-2.0\Https Traffic-dex2jar.jar!\c\b\c\b1.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */