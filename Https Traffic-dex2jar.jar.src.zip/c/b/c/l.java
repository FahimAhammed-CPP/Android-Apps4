package c.b.c;

import android.content.DialogInterface;
import android.os.Handler;
import android.os.Message;
import java.lang.ref.WeakReference;

public final class l extends Handler {
  public WeakReference<DialogInterface> a;
  
  public l(DialogInterface paramDialogInterface) {
    this.a = new WeakReference<DialogInterface>(paramDialogInterface);
  }
  
  public void handleMessage(Message paramMessage) {
    int i = paramMessage.what;
    if (i != -3 && i != -2 && i != -1) {
      if (i != 1)
        return; 
      ((DialogInterface)paramMessage.obj).dismiss();
      return;
    } 
    ((DialogInterface.OnClickListener)paramMessage.obj).onClick(this.a.get(), paramMessage.what);
  }
}


/* Location:              C:\soft\dex2jar-2.0\Https Traffic-dex2jar.jar!\c\b\c\l.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */