package c.b.c;

import android.view.View;
import androidx.drawerlayout.widget.DrawerLayout;
import d.a.a.a.a;
import java.util.Objects;

public class c implements View.OnClickListener {
  public c(g paramg) {}
  
  public void onClick(View paramView) {
    boolean bool;
    g g1 = this.e;
    Objects.requireNonNull(g1);
    int i = g1.b.h(8388611);
    DrawerLayout drawerLayout = g1.b;
    View view = drawerLayout.e(8388611);
    if (view != null) {
      bool = drawerLayout.q(view);
    } else {
      bool = false;
    } 
    if (bool && i != 2) {
      g1.b.b(8388611);
      return;
    } 
    if (i != 1) {
      DrawerLayout drawerLayout1 = g1.b;
      View view1 = drawerLayout1.e(8388611);
      if (view1 != null) {
        drawerLayout1.s(view1, true);
        return;
      } 
      StringBuilder stringBuilder = a.p("No drawer view found with gravity ");
      stringBuilder.append(DrawerLayout.k(8388611));
      throw new IllegalArgumentException(stringBuilder.toString());
    } 
  }
}


/* Location:              C:\soft\dex2jar-2.0\Https Traffic-dex2jar.jar!\c\b\c\c.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */