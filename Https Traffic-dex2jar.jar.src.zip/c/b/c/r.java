package c.b.c;

import android.os.Bundle;
import android.view.View;
import android.view.ViewGroup;
import c.e.d;
import java.lang.ref.WeakReference;
import java.util.Iterator;

public abstract class r {
  public static final d<WeakReference<r>> e = new d(0);
  
  public static final Object f = new Object();
  
  public static void h(r paramr) {
    synchronized (f) {
      Iterator<WeakReference<r>> iterator = e.iterator();
      while (iterator.hasNext()) {
        r r1 = ((WeakReference<r>)iterator.next()).get();
        if (r1 == paramr || r1 == null)
          iterator.remove(); 
      } 
      return;
    } 
  }
  
  public abstract void c(View paramView, ViewGroup.LayoutParams paramLayoutParams);
  
  public abstract void d();
  
  public abstract void e();
  
  public abstract void f(Bundle paramBundle);
  
  public abstract void g();
  
  public abstract boolean i(int paramInt);
  
  public abstract void j(int paramInt);
  
  public abstract void k(View paramView);
  
  public abstract void l(View paramView, ViewGroup.LayoutParams paramLayoutParams);
  
  public abstract void m(CharSequence paramCharSequence);
}


/* Location:              C:\soft\dex2jar-2.0\Https Traffic-dex2jar.jar!\c\b\c\r.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */