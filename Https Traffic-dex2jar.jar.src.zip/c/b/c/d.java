package c.b.c;

import android.content.Context;
import android.graphics.drawable.Drawable;

public interface d {
  void a(Drawable paramDrawable, int paramInt);
  
  boolean b();
  
  Drawable c();
  
  void d(int paramInt);
  
  Context e();
}


/* Location:              C:\soft\dex2jar-2.0\Https Traffic-dex2jar.jar!\c\b\c\d.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */