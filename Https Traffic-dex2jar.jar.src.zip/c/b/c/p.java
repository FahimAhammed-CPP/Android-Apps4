package c.b.c;

import android.app.Activity;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.content.res.Configuration;
import android.content.res.Resources;
import android.os.Bundle;
import android.util.Log;
import android.view.KeyEvent;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import c.b.g.a;
import c.b.g.b;
import c.b.g.j;
import c.b.h.s2;
import c.b.h.u;
import c.b.h.z1;
import c.e.d;
import c.e.f;
import c.h.b.b;
import c.h.b.h;
import c.h.c.a;
import c.m.a.j;
import java.lang.ref.WeakReference;
import java.util.ArrayList;
import java.util.Objects;

public abstract class p extends j implements q, e {
  public r q;
  
  public void addContentView(View paramView, ViewGroup.LayoutParams paramLayoutParams) {
    t().c(paramView, paramLayoutParams);
  }
  
  public void attachBaseContext(Context paramContext) {
    // Byte code:
    //   0: aload_0
    //   1: invokevirtual t : ()Lc/b/c/r;
    //   4: checkcast c/b/c/k0
    //   7: astore #11
    //   9: aload #11
    //   11: iconst_1
    //   12: putfield L : Z
    //   15: aload #11
    //   17: getfield P : I
    //   20: istore #4
    //   22: iload #4
    //   24: bipush #-100
    //   26: if_icmpeq -> 32
    //   29: goto -> 36
    //   32: bipush #-100
    //   34: istore #4
    //   36: aload #11
    //   38: aload_1
    //   39: iload #4
    //   41: invokevirtual G : (Landroid/content/Context;I)I
    //   44: istore #4
    //   46: getstatic c/b/c/k0.f0 : Z
    //   49: ifeq -> 82
    //   52: aload_1
    //   53: instanceof android/view/ContextThemeWrapper
    //   56: ifeq -> 82
    //   59: aload #11
    //   61: aload_1
    //   62: iload #4
    //   64: aconst_null
    //   65: invokevirtual t : (Landroid/content/Context;ILandroid/content/res/Configuration;)Landroid/content/res/Configuration;
    //   68: astore #9
    //   70: aload_1
    //   71: checkcast android/view/ContextThemeWrapper
    //   74: aload #9
    //   76: invokevirtual applyOverrideConfiguration : (Landroid/content/res/Configuration;)V
    //   79: goto -> 1175
    //   82: aload_1
    //   83: instanceof c/b/g/d
    //   86: ifeq -> 112
    //   89: aload #11
    //   91: aload_1
    //   92: iload #4
    //   94: aconst_null
    //   95: invokevirtual t : (Landroid/content/Context;ILandroid/content/res/Configuration;)Landroid/content/res/Configuration;
    //   98: astore #9
    //   100: aload_1
    //   101: checkcast c/b/g/d
    //   104: aload #9
    //   106: invokevirtual a : (Landroid/content/res/Configuration;)V
    //   109: goto -> 1175
    //   112: getstatic c/b/c/k0.e0 : Z
    //   115: ifne -> 121
    //   118: goto -> 1175
    //   121: aload_1
    //   122: invokevirtual getPackageManager : ()Landroid/content/pm/PackageManager;
    //   125: aload_1
    //   126: invokevirtual getApplicationInfo : ()Landroid/content/pm/ApplicationInfo;
    //   129: invokevirtual getResourcesForApplication : (Landroid/content/pm/ApplicationInfo;)Landroid/content/res/Resources;
    //   132: invokevirtual getConfiguration : ()Landroid/content/res/Configuration;
    //   135: astore #12
    //   137: aload_1
    //   138: invokevirtual getResources : ()Landroid/content/res/Resources;
    //   141: invokevirtual getConfiguration : ()Landroid/content/res/Configuration;
    //   144: astore #13
    //   146: aload #12
    //   148: aload #13
    //   150: invokevirtual equals : (Landroid/content/res/Configuration;)Z
    //   153: ifne -> 979
    //   156: new android/content/res/Configuration
    //   159: dup
    //   160: invokespecial <init> : ()V
    //   163: astore #10
    //   165: aload #10
    //   167: fconst_0
    //   168: putfield fontScale : F
    //   171: aload #10
    //   173: astore #9
    //   175: aload #13
    //   177: ifnull -> 982
    //   180: aload #12
    //   182: aload #13
    //   184: invokevirtual diff : (Landroid/content/res/Configuration;)I
    //   187: ifne -> 197
    //   190: aload #10
    //   192: astore #9
    //   194: goto -> 982
    //   197: aload #12
    //   199: getfield fontScale : F
    //   202: fstore_2
    //   203: aload #13
    //   205: getfield fontScale : F
    //   208: fstore_3
    //   209: fload_2
    //   210: fload_3
    //   211: fcmpl
    //   212: ifeq -> 221
    //   215: aload #10
    //   217: fload_3
    //   218: putfield fontScale : F
    //   221: aload #12
    //   223: getfield mcc : I
    //   226: istore #5
    //   228: aload #13
    //   230: getfield mcc : I
    //   233: istore #6
    //   235: iload #5
    //   237: iload #6
    //   239: if_icmpeq -> 249
    //   242: aload #10
    //   244: iload #6
    //   246: putfield mcc : I
    //   249: aload #12
    //   251: getfield mnc : I
    //   254: istore #5
    //   256: aload #13
    //   258: getfield mnc : I
    //   261: istore #6
    //   263: iload #5
    //   265: iload #6
    //   267: if_icmpeq -> 277
    //   270: aload #10
    //   272: iload #6
    //   274: putfield mnc : I
    //   277: getstatic android/os/Build$VERSION.SDK_INT : I
    //   280: istore #5
    //   282: iload #5
    //   284: bipush #24
    //   286: if_icmplt -> 333
    //   289: aload #12
    //   291: invokevirtual getLocales : ()Landroid/os/LocaleList;
    //   294: astore #9
    //   296: aload #13
    //   298: invokevirtual getLocales : ()Landroid/os/LocaleList;
    //   301: astore #14
    //   303: aload #9
    //   305: aload #14
    //   307: invokevirtual equals : (Ljava/lang/Object;)Z
    //   310: ifne -> 359
    //   313: aload #10
    //   315: aload #14
    //   317: invokevirtual setLocales : (Landroid/os/LocaleList;)V
    //   320: aload #10
    //   322: aload #13
    //   324: getfield locale : Ljava/util/Locale;
    //   327: putfield locale : Ljava/util/Locale;
    //   330: goto -> 359
    //   333: aload #12
    //   335: getfield locale : Ljava/util/Locale;
    //   338: aload #13
    //   340: getfield locale : Ljava/util/Locale;
    //   343: invokestatic equals : (Ljava/lang/Object;Ljava/lang/Object;)Z
    //   346: ifne -> 359
    //   349: aload #10
    //   351: aload #13
    //   353: getfield locale : Ljava/util/Locale;
    //   356: putfield locale : Ljava/util/Locale;
    //   359: aload #12
    //   361: getfield touchscreen : I
    //   364: istore #6
    //   366: aload #13
    //   368: getfield touchscreen : I
    //   371: istore #7
    //   373: iload #6
    //   375: iload #7
    //   377: if_icmpeq -> 387
    //   380: aload #10
    //   382: iload #7
    //   384: putfield touchscreen : I
    //   387: aload #12
    //   389: getfield keyboard : I
    //   392: istore #6
    //   394: aload #13
    //   396: getfield keyboard : I
    //   399: istore #7
    //   401: iload #6
    //   403: iload #7
    //   405: if_icmpeq -> 415
    //   408: aload #10
    //   410: iload #7
    //   412: putfield keyboard : I
    //   415: aload #12
    //   417: getfield keyboardHidden : I
    //   420: istore #6
    //   422: aload #13
    //   424: getfield keyboardHidden : I
    //   427: istore #7
    //   429: iload #6
    //   431: iload #7
    //   433: if_icmpeq -> 443
    //   436: aload #10
    //   438: iload #7
    //   440: putfield keyboardHidden : I
    //   443: aload #12
    //   445: getfield navigation : I
    //   448: istore #6
    //   450: aload #13
    //   452: getfield navigation : I
    //   455: istore #7
    //   457: iload #6
    //   459: iload #7
    //   461: if_icmpeq -> 471
    //   464: aload #10
    //   466: iload #7
    //   468: putfield navigation : I
    //   471: aload #12
    //   473: getfield navigationHidden : I
    //   476: istore #6
    //   478: aload #13
    //   480: getfield navigationHidden : I
    //   483: istore #7
    //   485: iload #6
    //   487: iload #7
    //   489: if_icmpeq -> 499
    //   492: aload #10
    //   494: iload #7
    //   496: putfield navigationHidden : I
    //   499: aload #12
    //   501: getfield orientation : I
    //   504: istore #6
    //   506: aload #13
    //   508: getfield orientation : I
    //   511: istore #7
    //   513: iload #6
    //   515: iload #7
    //   517: if_icmpeq -> 527
    //   520: aload #10
    //   522: iload #7
    //   524: putfield orientation : I
    //   527: aload #12
    //   529: getfield screenLayout : I
    //   532: istore #6
    //   534: aload #13
    //   536: getfield screenLayout : I
    //   539: bipush #15
    //   541: iand
    //   542: istore #7
    //   544: iload #6
    //   546: bipush #15
    //   548: iand
    //   549: iload #7
    //   551: if_icmpeq -> 567
    //   554: aload #10
    //   556: aload #10
    //   558: getfield screenLayout : I
    //   561: iload #7
    //   563: ior
    //   564: putfield screenLayout : I
    //   567: aload #12
    //   569: getfield screenLayout : I
    //   572: istore #6
    //   574: aload #13
    //   576: getfield screenLayout : I
    //   579: sipush #192
    //   582: iand
    //   583: istore #7
    //   585: iload #6
    //   587: sipush #192
    //   590: iand
    //   591: iload #7
    //   593: if_icmpeq -> 609
    //   596: aload #10
    //   598: aload #10
    //   600: getfield screenLayout : I
    //   603: iload #7
    //   605: ior
    //   606: putfield screenLayout : I
    //   609: aload #12
    //   611: getfield screenLayout : I
    //   614: istore #6
    //   616: aload #13
    //   618: getfield screenLayout : I
    //   621: bipush #48
    //   623: iand
    //   624: istore #7
    //   626: iload #6
    //   628: bipush #48
    //   630: iand
    //   631: iload #7
    //   633: if_icmpeq -> 649
    //   636: aload #10
    //   638: aload #10
    //   640: getfield screenLayout : I
    //   643: iload #7
    //   645: ior
    //   646: putfield screenLayout : I
    //   649: aload #12
    //   651: getfield screenLayout : I
    //   654: istore #6
    //   656: aload #13
    //   658: getfield screenLayout : I
    //   661: sipush #768
    //   664: iand
    //   665: istore #7
    //   667: iload #6
    //   669: sipush #768
    //   672: iand
    //   673: iload #7
    //   675: if_icmpeq -> 691
    //   678: aload #10
    //   680: aload #10
    //   682: getfield screenLayout : I
    //   685: iload #7
    //   687: ior
    //   688: putfield screenLayout : I
    //   691: iload #5
    //   693: bipush #26
    //   695: if_icmplt -> 776
    //   698: aload #12
    //   700: getfield colorMode : I
    //   703: istore #5
    //   705: aload #13
    //   707: getfield colorMode : I
    //   710: iconst_3
    //   711: iand
    //   712: istore #6
    //   714: iload #5
    //   716: iconst_3
    //   717: iand
    //   718: iload #6
    //   720: if_icmpeq -> 736
    //   723: aload #10
    //   725: aload #10
    //   727: getfield colorMode : I
    //   730: iload #6
    //   732: ior
    //   733: putfield colorMode : I
    //   736: aload #12
    //   738: getfield colorMode : I
    //   741: istore #5
    //   743: aload #13
    //   745: getfield colorMode : I
    //   748: bipush #12
    //   750: iand
    //   751: istore #6
    //   753: iload #5
    //   755: bipush #12
    //   757: iand
    //   758: iload #6
    //   760: if_icmpeq -> 776
    //   763: aload #10
    //   765: aload #10
    //   767: getfield colorMode : I
    //   770: iload #6
    //   772: ior
    //   773: putfield colorMode : I
    //   776: aload #12
    //   778: getfield uiMode : I
    //   781: istore #5
    //   783: aload #13
    //   785: getfield uiMode : I
    //   788: bipush #15
    //   790: iand
    //   791: istore #6
    //   793: iload #5
    //   795: bipush #15
    //   797: iand
    //   798: iload #6
    //   800: if_icmpeq -> 816
    //   803: aload #10
    //   805: aload #10
    //   807: getfield uiMode : I
    //   810: iload #6
    //   812: ior
    //   813: putfield uiMode : I
    //   816: aload #12
    //   818: getfield uiMode : I
    //   821: istore #5
    //   823: aload #13
    //   825: getfield uiMode : I
    //   828: bipush #48
    //   830: iand
    //   831: istore #6
    //   833: iload #5
    //   835: bipush #48
    //   837: iand
    //   838: iload #6
    //   840: if_icmpeq -> 856
    //   843: aload #10
    //   845: aload #10
    //   847: getfield uiMode : I
    //   850: iload #6
    //   852: ior
    //   853: putfield uiMode : I
    //   856: aload #12
    //   858: getfield screenWidthDp : I
    //   861: istore #5
    //   863: aload #13
    //   865: getfield screenWidthDp : I
    //   868: istore #6
    //   870: iload #5
    //   872: iload #6
    //   874: if_icmpeq -> 884
    //   877: aload #10
    //   879: iload #6
    //   881: putfield screenWidthDp : I
    //   884: aload #12
    //   886: getfield screenHeightDp : I
    //   889: istore #5
    //   891: aload #13
    //   893: getfield screenHeightDp : I
    //   896: istore #6
    //   898: iload #5
    //   900: iload #6
    //   902: if_icmpeq -> 912
    //   905: aload #10
    //   907: iload #6
    //   909: putfield screenHeightDp : I
    //   912: aload #12
    //   914: getfield smallestScreenWidthDp : I
    //   917: istore #5
    //   919: aload #13
    //   921: getfield smallestScreenWidthDp : I
    //   924: istore #6
    //   926: iload #5
    //   928: iload #6
    //   930: if_icmpeq -> 940
    //   933: aload #10
    //   935: iload #6
    //   937: putfield smallestScreenWidthDp : I
    //   940: aload #12
    //   942: getfield densityDpi : I
    //   945: istore #5
    //   947: aload #13
    //   949: getfield densityDpi : I
    //   952: istore #6
    //   954: aload #10
    //   956: astore #9
    //   958: iload #5
    //   960: iload #6
    //   962: if_icmpeq -> 982
    //   965: aload #10
    //   967: iload #6
    //   969: putfield densityDpi : I
    //   972: aload #10
    //   974: astore #9
    //   976: goto -> 982
    //   979: aconst_null
    //   980: astore #9
    //   982: aload #11
    //   984: aload_1
    //   985: iload #4
    //   987: aload #9
    //   989: invokevirtual t : (Landroid/content/Context;ILandroid/content/res/Configuration;)Landroid/content/res/Configuration;
    //   992: astore #10
    //   994: new c/b/g/d
    //   997: dup
    //   998: aload_1
    //   999: ldc 2131820950
    //   1001: invokespecial <init> : (Landroid/content/Context;I)V
    //   1004: astore #9
    //   1006: aload #9
    //   1008: aload #10
    //   1010: invokevirtual a : (Landroid/content/res/Configuration;)V
    //   1013: aload_1
    //   1014: invokevirtual getTheme : ()Landroid/content/res/Resources$Theme;
    //   1017: astore_1
    //   1018: aload_1
    //   1019: ifnull -> 1028
    //   1022: iconst_1
    //   1023: istore #4
    //   1025: goto -> 1031
    //   1028: iconst_0
    //   1029: istore #4
    //   1031: iload #4
    //   1033: ifeq -> 1172
    //   1036: aload #9
    //   1038: invokevirtual getTheme : ()Landroid/content/res/Resources$Theme;
    //   1041: astore_1
    //   1042: getstatic android/os/Build$VERSION.SDK_INT : I
    //   1045: bipush #29
    //   1047: if_icmplt -> 1057
    //   1050: aload_1
    //   1051: invokevirtual rebase : ()V
    //   1054: goto -> 1172
    //   1057: getstatic c/h/c/f/k.a : Ljava/lang/Object;
    //   1060: astore #10
    //   1062: aload #10
    //   1064: monitorenter
    //   1065: getstatic c/h/c/f/k.c : Z
    //   1068: istore #8
    //   1070: iload #8
    //   1072: ifne -> 1118
    //   1075: ldc android/content/res/Resources$Theme
    //   1077: ldc 'rebase'
    //   1079: iconst_0
    //   1080: anewarray java/lang/Class
    //   1083: invokevirtual getDeclaredMethod : (Ljava/lang/String;[Ljava/lang/Class;)Ljava/lang/reflect/Method;
    //   1086: astore #11
    //   1088: aload #11
    //   1090: putstatic c/h/c/f/k.b : Ljava/lang/reflect/Method;
    //   1093: aload #11
    //   1095: iconst_1
    //   1096: invokevirtual setAccessible : (Z)V
    //   1099: goto -> 1114
    //   1102: astore #11
    //   1104: ldc 'ResourcesCompat'
    //   1106: ldc 'Failed to retrieve rebase() method'
    //   1108: aload #11
    //   1110: invokestatic i : (Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)I
    //   1113: pop
    //   1114: iconst_1
    //   1115: putstatic c/h/c/f/k.c : Z
    //   1118: getstatic c/h/c/f/k.b : Ljava/lang/reflect/Method;
    //   1121: astore #11
    //   1123: aload #11
    //   1125: ifnull -> 1160
    //   1128: aload #11
    //   1130: aload_1
    //   1131: iconst_0
    //   1132: anewarray java/lang/Object
    //   1135: invokevirtual invoke : (Ljava/lang/Object;[Ljava/lang/Object;)Ljava/lang/Object;
    //   1138: pop
    //   1139: goto -> 1160
    //   1142: astore_1
    //   1143: goto -> 1147
    //   1146: astore_1
    //   1147: ldc 'ResourcesCompat'
    //   1149: ldc 'Failed to invoke rebase() method via reflection'
    //   1151: aload_1
    //   1152: invokestatic i : (Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)I
    //   1155: pop
    //   1156: aconst_null
    //   1157: putstatic c/h/c/f/k.b : Ljava/lang/reflect/Method;
    //   1160: aload #10
    //   1162: monitorexit
    //   1163: goto -> 1172
    //   1166: astore_1
    //   1167: aload #10
    //   1169: monitorexit
    //   1170: aload_1
    //   1171: athrow
    //   1172: aload #9
    //   1174: astore_1
    //   1175: aload_0
    //   1176: aload_1
    //   1177: invokespecial attachBaseContext : (Landroid/content/Context;)V
    //   1180: return
    //   1181: astore_1
    //   1182: new java/lang/RuntimeException
    //   1185: dup
    //   1186: ldc 'Application failed to obtain resources from itself'
    //   1188: aload_1
    //   1189: invokespecial <init> : (Ljava/lang/String;Ljava/lang/Throwable;)V
    //   1192: athrow
    //   1193: astore #9
    //   1195: goto -> 82
    //   1198: astore #9
    //   1200: goto -> 112
    //   1203: astore_1
    //   1204: goto -> 1028
    // Exception table:
    //   from	to	target	type
    //   70	79	1193	java/lang/IllegalStateException
    //   100	109	1198	java/lang/IllegalStateException
    //   121	137	1181	android/content/pm/PackageManager$NameNotFoundException
    //   1013	1018	1203	java/lang/NullPointerException
    //   1065	1070	1166	finally
    //   1075	1099	1102	java/lang/NoSuchMethodException
    //   1075	1099	1166	finally
    //   1104	1114	1166	finally
    //   1114	1118	1166	finally
    //   1118	1123	1166	finally
    //   1128	1139	1146	java/lang/IllegalAccessException
    //   1128	1139	1142	java/lang/reflect/InvocationTargetException
    //   1128	1139	1166	finally
    //   1147	1160	1166	finally
    //   1160	1163	1166	finally
    //   1167	1170	1166	finally
  }
  
  public void closeOptionsMenu() {
    a a = u();
    if (getWindow().hasFeature(0) && (a == null || !a.a()))
      super.closeOptionsMenu(); 
  }
  
  public boolean dispatchKeyEvent(KeyEvent paramKeyEvent) {
    int i = paramKeyEvent.getKeyCode();
    a a = u();
    return (i == 82 && a != null && a.j(paramKeyEvent)) ? true : super.dispatchKeyEvent(paramKeyEvent);
  }
  
  public void f(b paramb) {}
  
  public <T extends View> T findViewById(int paramInt) {
    k0 k0 = (k0)t();
    k0.x();
    return (T)k0.i.findViewById(paramInt);
  }
  
  public void g(b paramb) {}
  
  public MenuInflater getMenuInflater() {
    k0 k0 = (k0)t();
    if (k0.m == null) {
      Context context;
      k0.E();
      a a = k0.l;
      if (a != null) {
        context = a.e();
      } else {
        context = k0.h;
      } 
      k0.m = (MenuInflater)new j(context);
    } 
    return k0.m;
  }
  
  public Resources getResources() {
    int i = s2.a;
    return super.getResources();
  }
  
  public void invalidateOptionsMenu() {
    t().e();
  }
  
  public b m(a parama) {
    return null;
  }
  
  public void onConfigurationChanged(Configuration paramConfiguration) {
    super.onConfigurationChanged(paramConfiguration);
    null = (k0)t();
    if (null.C && null.w) {
      null.E();
      a a = null.l;
      if (a != null)
        a.g(paramConfiguration); 
    } 
    u u = u.a();
    synchronized (null.h) {
      synchronized (u.a) {
        f f = (f)null.d.get(null);
        if (f != null)
          f.b(); 
        /* monitor exit ClassFileLocalVariableReferenceExpression{type=ObjectType{c/b/h/u}, name=null} */
        null.o(false);
        return;
      } 
    } 
  }
  
  public void onContentChanged() {}
  
  public void onCreate(Bundle paramBundle) {
    r r1 = t();
    r1.d();
    r1.f(paramBundle);
    super.onCreate(paramBundle);
  }
  
  public void onDestroy() {
    super.onDestroy();
    t().g();
  }
  
  public boolean onKeyDown(int paramInt, KeyEvent paramKeyEvent) {
    // Byte code:
    //   0: getstatic android/os/Build$VERSION.SDK_INT : I
    //   3: bipush #26
    //   5: if_icmpge -> 78
    //   8: aload_2
    //   9: invokevirtual isCtrlPressed : ()Z
    //   12: ifne -> 78
    //   15: aload_2
    //   16: invokevirtual getMetaState : ()I
    //   19: invokestatic metaStateHasNoModifiers : (I)Z
    //   22: ifne -> 78
    //   25: aload_2
    //   26: invokevirtual getRepeatCount : ()I
    //   29: ifne -> 78
    //   32: aload_2
    //   33: invokevirtual getKeyCode : ()I
    //   36: invokestatic isModifierKey : (I)Z
    //   39: ifne -> 78
    //   42: aload_0
    //   43: invokevirtual getWindow : ()Landroid/view/Window;
    //   46: astore #4
    //   48: aload #4
    //   50: ifnull -> 78
    //   53: aload #4
    //   55: invokevirtual getDecorView : ()Landroid/view/View;
    //   58: ifnull -> 78
    //   61: aload #4
    //   63: invokevirtual getDecorView : ()Landroid/view/View;
    //   66: aload_2
    //   67: invokevirtual dispatchKeyShortcutEvent : (Landroid/view/KeyEvent;)Z
    //   70: ifeq -> 78
    //   73: iconst_1
    //   74: istore_3
    //   75: goto -> 80
    //   78: iconst_0
    //   79: istore_3
    //   80: iload_3
    //   81: ifeq -> 86
    //   84: iconst_1
    //   85: ireturn
    //   86: aload_0
    //   87: iload_1
    //   88: aload_2
    //   89: invokespecial onKeyDown : (ILandroid/view/KeyEvent;)Z
    //   92: ireturn
  }
  
  public final boolean onMenuItemSelected(int paramInt, MenuItem paramMenuItem) {
    if (super.onMenuItemSelected(paramInt, paramMenuItem))
      return true; 
    a a = u();
    if (paramMenuItem.getItemId() == 16908332 && a != null && (a.d() & 0x4) != 0) {
      Intent intent = h.C((Activity)this);
      if (intent != null) {
        if (shouldUpRecreateTask(intent)) {
          ArrayList<Intent> arrayList = new ArrayList();
          Intent intent1 = h.C((Activity)this);
          intent = intent1;
          if (intent1 == null)
            intent = h.C((Activity)this); 
          if (intent != null) {
            ComponentName componentName2 = intent.getComponent();
            ComponentName componentName1 = componentName2;
            if (componentName2 == null)
              componentName1 = intent.resolveActivity(getPackageManager()); 
            paramInt = arrayList.size();
            try {
              for (Intent intent2 = h.D((Context)this, componentName1); intent2 != null; intent2 = h.D((Context)this, intent2.getComponent()))
                arrayList.add(paramInt, intent2); 
              arrayList.add(intent);
            } catch (android.content.pm.PackageManager.NameNotFoundException nameNotFoundException) {
              Log.e("TaskStackBuilder", "Bad ComponentName while traversing activity parent metadata");
              throw new IllegalArgumentException(nameNotFoundException);
            } 
          } 
          w();
          if (!arrayList.isEmpty()) {
            Intent[] arrayOfIntent = arrayList.<Intent>toArray(new Intent[arrayList.size()]);
            arrayOfIntent[0] = (new Intent(arrayOfIntent[0])).addFlags(268484608);
            Object object = b.a;
            a.a((Context)this, arrayOfIntent, null);
            try {
              finishAffinity();
              return true;
            } catch (IllegalStateException illegalStateException) {
              finish();
              return true;
            } 
          } 
          throw new IllegalStateException("No intents added to TaskStackBuilder; cannot startActivities");
        } 
        navigateUpTo((Intent)illegalStateException);
        return true;
      } 
      return false;
    } 
    return false;
  }
  
  public boolean onMenuOpened(int paramInt, Menu paramMenu) {
    return super.onMenuOpened(paramInt, paramMenu);
  }
  
  public void onPanelClosed(int paramInt, Menu paramMenu) {
    super.onPanelClosed(paramInt, paramMenu);
  }
  
  public void onPostCreate(Bundle paramBundle) {
    super.onPostCreate(paramBundle);
    ((k0)t()).x();
  }
  
  public void onPostResume() {
    super.onPostResume();
    k0 k0 = (k0)t();
    k0.E();
    a a = k0.l;
    if (a != null)
      a.o(true); 
  }
  
  public void onSaveInstanceState(Bundle paramBundle) {
    super.onSaveInstanceState(paramBundle);
    Objects.requireNonNull((k0)t());
  }
  
  public void onStart() {
    super.onStart();
    k0 k0 = (k0)t();
    k0.N = true;
    k0.n();
  }
  
  public void onStop() {
    super.onStop();
    k0 k0 = (k0)t();
    k0.N = false;
    k0.E();
    a a = k0.l;
    if (a != null)
      a.o(false); 
  }
  
  public void onTitleChanged(CharSequence paramCharSequence, int paramInt) {
    super.onTitleChanged(paramCharSequence, paramInt);
    t().m(paramCharSequence);
  }
  
  public void openOptionsMenu() {
    a a = u();
    if (getWindow().hasFeature(0) && (a == null || !a.k()))
      super.openOptionsMenu(); 
  }
  
  public void s() {
    t().e();
  }
  
  public void setContentView(int paramInt) {
    t().j(paramInt);
  }
  
  public void setContentView(View paramView) {
    t().k(paramView);
  }
  
  public void setContentView(View paramView, ViewGroup.LayoutParams paramLayoutParams) {
    t().l(paramView, paramLayoutParams);
  }
  
  public void setTheme(int paramInt) {
    super.setTheme(paramInt);
    ((k0)t()).Q = paramInt;
  }
  
  public r t() {
    if (this.q == null) {
      d<WeakReference<r>> d = r.e;
      this.q = new k0((Context)this, null, this, this);
    } 
    return this.q;
  }
  
  public a u() {
    k0 k0 = (k0)t();
    k0.E();
    return k0.l;
  }
  
  public void v() {}
  
  public void w() {}
}


/* Location:              C:\soft\dex2jar-2.0\Https Traffic-dex2jar.jar!\c\b\c\p.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */