package c.b.c;

import android.content.Context;
import android.graphics.drawable.Drawable;
import c.b.h.j2;

public class y implements d {
  public y(k0 paramk0) {}
  
  public void a(Drawable paramDrawable, int paramInt) {
    k0 k01 = this.a;
    k01.E();
    a a = k01.l;
    if (a != null) {
      a.n(paramDrawable);
      a.m(paramInt);
    } 
  }
  
  public boolean b() {
    k0 k01 = this.a;
    k01.E();
    a a = k01.l;
    return (a != null && (a.d() & 0x4) != 0);
  }
  
  public Drawable c() {
    j2 j2 = j2.p(this.a.A(), null, new int[] { 2130903436 });
    Drawable drawable = j2.g(0);
    j2.b.recycle();
    return drawable;
  }
  
  public void d(int paramInt) {
    k0 k01 = this.a;
    k01.E();
    a a = k01.l;
    if (a != null)
      a.m(paramInt); 
  }
  
  public Context e() {
    return this.a.A();
  }
}


/* Location:              C:\soft\dex2jar-2.0\Https Traffic-dex2jar.jar!\c\b\c\y.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */