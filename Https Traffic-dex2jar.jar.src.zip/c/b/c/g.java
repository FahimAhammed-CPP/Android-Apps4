package c.b.c;

import android.app.Activity;
import androidx.appcompat.widget.Toolbar;
import androidx.drawerlayout.widget.DrawerLayout;
import c.b.e.a.m;
import java.util.Objects;

public class g implements DrawerLayout.c {
  public final d a;
  
  public final DrawerLayout b;
  
  public m c;
  
  public final int d;
  
  public final int e;
  
  public boolean f = false;
  
  public g(Activity paramActivity, DrawerLayout paramDrawerLayout, Toolbar paramToolbar, int paramInt1, int paramInt2) {
    if (paramToolbar != null) {
      this.a = new f(paramToolbar);
      paramToolbar.setNavigationOnClickListener(new c(this));
    } else {
      k0 k0 = (k0)((p)paramActivity).t();
      Objects.requireNonNull(k0);
      this.a = new y(k0);
    } 
    this.b = paramDrawerLayout;
    this.d = paramInt1;
    this.e = paramInt2;
    this.c = new m(this.a.e());
    this.a.c();
  }
  
  public final void a(float paramFloat) {
    if (paramFloat == 1.0F) {
      m m2 = this.c;
      if (m2.i != true) {
        m2.i = true;
        m2.invalidateSelf();
      } 
    } else if (paramFloat == 0.0F) {
      m m2 = this.c;
      if (m2.i) {
        m2.i = false;
        m2.invalidateSelf();
      } 
    } 
    m m1 = this.c;
    if (m1.j != paramFloat) {
      m1.j = paramFloat;
      m1.invalidateSelf();
    } 
  }
}


/* Location:              C:\soft\dex2jar-2.0\Https Traffic-dex2jar.jar!\c\b\c\g.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */