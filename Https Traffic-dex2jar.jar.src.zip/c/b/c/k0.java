package c.b.c;

import android.app.Activity;
import android.app.Dialog;
import android.app.UiModeManager;
import android.content.Context;
import android.content.ContextWrapper;
import android.content.pm.PackageManager;
import android.content.res.Configuration;
import android.content.res.TypedArray;
import android.graphics.Rect;
import android.graphics.drawable.Drawable;
import android.location.LocationManager;
import android.os.Build;
import android.os.Bundle;
import android.text.TextUtils;
import android.util.AndroidRuntimeException;
import android.util.AttributeSet;
import android.util.Log;
import android.util.TypedValue;
import android.view.KeyEvent;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import android.view.WindowManager;
import android.widget.FrameLayout;
import android.widget.PopupWindow;
import android.widget.TextView;
import androidx.appcompat.widget.ActionBarContextView;
import androidx.appcompat.widget.ActionBarOverlayLayout;
import androidx.appcompat.widget.ActionMenuView;
import androidx.appcompat.widget.ContentFrameLayout;
import c.b.b;
import c.b.g.b;
import c.b.g.d;
import c.b.g.n.l;
import c.b.h.a1;
import c.b.h.j2;
import c.b.h.m;
import c.b.h.n2;
import c.b.h.t2;
import c.b.h.u;
import c.e.i;
import c.h.b.b;
import c.h.b.h;
import c.h.c.c;
import c.h.j.l0;
import c.h.j.u;
import c.h.j.y;
import d.a.a.a.a;
import java.lang.ref.WeakReference;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.util.concurrent.atomic.AtomicInteger;

public class k0 extends r implements l.a, LayoutInflater.Factory2 {
  public static final i<String, Integer> c0 = new i();
  
  public static final int[] d0 = new int[] { 16842836 };
  
  public static final boolean e0 = "robolectric".equals(Build.FINGERPRINT) ^ true;
  
  public static final boolean f0 = true;
  
  public boolean A;
  
  public boolean B;
  
  public boolean C;
  
  public boolean D;
  
  public boolean E;
  
  public boolean F;
  
  public boolean G;
  
  public boolean H;
  
  public i0[] I;
  
  public i0 J;
  
  public boolean K;
  
  public boolean L;
  
  public boolean M;
  
  public boolean N;
  
  public boolean O;
  
  public int P = -100;
  
  public int Q;
  
  public boolean R;
  
  public boolean S;
  
  public f0 T;
  
  public f0 U;
  
  public boolean V;
  
  public int W;
  
  public final Runnable X = new s(this);
  
  public boolean Y;
  
  public Rect Z;
  
  public Rect a0;
  
  public n0 b0;
  
  public final Object g;
  
  public final Context h;
  
  public Window i;
  
  public c0 j;
  
  public final q k;
  
  public a l;
  
  public MenuInflater m;
  
  public CharSequence n;
  
  public a1 o;
  
  public z p;
  
  public j0 q;
  
  public b r;
  
  public ActionBarContextView s;
  
  public PopupWindow t;
  
  public Runnable u;
  
  public y v = null;
  
  public boolean w;
  
  public ViewGroup x;
  
  public TextView y;
  
  public View z;
  
  public k0(Context paramContext, Window paramWindow, q paramq, Object paramObject) {
    this.h = paramContext;
    this.k = paramq;
    this.g = paramObject;
    if (paramObject instanceof Dialog) {
      while (true) {
        if (paramContext != null) {
          p p;
          if (paramContext instanceof p) {
            p = (p)paramContext;
            break;
          } 
          if (p instanceof ContextWrapper) {
            Context context = ((ContextWrapper)p).getBaseContext();
            continue;
          } 
        } 
        paramContext = null;
        break;
      } 
      if (paramContext != null)
        this.P = ((k0)paramContext.t()).P; 
    } 
    if (this.P == -100) {
      i<String, Integer> i1 = c0;
      Integer integer = (Integer)i1.getOrDefault(this.g.getClass().getName(), null);
      if (integer != null) {
        this.P = integer.intValue();
        i1.remove(this.g.getClass().getName());
      } 
    } 
    if (paramWindow != null)
      p(paramWindow); 
    u.e();
  }
  
  public final Context A() {
    Context context;
    E();
    a a2 = this.l;
    if (a2 != null) {
      Context context1 = a2.e();
    } else {
      a2 = null;
    } 
    a a3 = a2;
    if (a2 == null)
      context = this.h; 
    return context;
  }
  
  public final f0 B(Context paramContext) {
    if (this.T == null) {
      if (w0.d == null) {
        paramContext = paramContext.getApplicationContext();
        w0.d = new w0(paramContext, (LocationManager)paramContext.getSystemService("location"));
      } 
      this.T = new g0(this, w0.d);
    } 
    return this.T;
  }
  
  public i0 C(int paramInt) {
    // Byte code:
    //   0: aload_0
    //   1: getfield I : [Lc/b/c/i0;
    //   4: astore_3
    //   5: aload_3
    //   6: ifnull -> 17
    //   9: aload_3
    //   10: astore_2
    //   11: aload_3
    //   12: arraylength
    //   13: iload_1
    //   14: if_icmpgt -> 42
    //   17: iload_1
    //   18: iconst_1
    //   19: iadd
    //   20: anewarray c/b/c/i0
    //   23: astore_2
    //   24: aload_3
    //   25: ifnull -> 37
    //   28: aload_3
    //   29: iconst_0
    //   30: aload_2
    //   31: iconst_0
    //   32: aload_3
    //   33: arraylength
    //   34: invokestatic arraycopy : (Ljava/lang/Object;ILjava/lang/Object;II)V
    //   37: aload_0
    //   38: aload_2
    //   39: putfield I : [Lc/b/c/i0;
    //   42: aload_2
    //   43: iload_1
    //   44: aaload
    //   45: astore #4
    //   47: aload #4
    //   49: astore_3
    //   50: aload #4
    //   52: ifnonnull -> 68
    //   55: new c/b/c/i0
    //   58: dup
    //   59: iload_1
    //   60: invokespecial <init> : (I)V
    //   63: astore_3
    //   64: aload_2
    //   65: iload_1
    //   66: aload_3
    //   67: aastore
    //   68: aload_3
    //   69: areturn
  }
  
  public final Window.Callback D() {
    return this.i.getCallback();
  }
  
  public final void E() {
    x();
    if (this.C) {
      if (this.l != null)
        return; 
      Object object = this.g;
      if (object instanceof Activity) {
        this.l = new b1((Activity)this.g, this.D);
      } else if (object instanceof Dialog) {
        this.l = new b1((Dialog)this.g);
      } 
      object = this.l;
      if (object != null)
        object.l(this.Y); 
    } 
  }
  
  public final void F(int paramInt) {
    this.W = 1 << paramInt | this.W;
    if (!this.V) {
      View view = this.i.getDecorView();
      Runnable runnable = this.X;
      AtomicInteger atomicInteger = u.a;
      view.postOnAnimation(runnable);
      this.V = true;
    } 
  }
  
  public int G(Context paramContext, int paramInt) {
    if (paramInt != -100) {
      if (paramInt != -1)
        if (paramInt != 0) {
          if (paramInt != 1 && paramInt != 2) {
            if (paramInt == 3) {
              if (this.U == null)
                this.U = new d0(this, paramContext); 
              return this.U.c();
            } 
            throw new IllegalStateException("Unknown value set for night mode. Please use one of the MODE_NIGHT values from AppCompatDelegate.");
          } 
        } else {
          return (((UiModeManager)paramContext.getApplicationContext().getSystemService(UiModeManager.class)).getNightMode() == 0) ? -1 : B(paramContext).c();
        }  
      return paramInt;
    } 
    return -1;
  }
  
  public final void H(i0 parami0, KeyEvent paramKeyEvent) {
    // Byte code:
    //   0: aload_1
    //   1: getfield m : Z
    //   4: ifne -> 802
    //   7: aload_0
    //   8: getfield O : Z
    //   11: ifeq -> 15
    //   14: return
    //   15: aload_1
    //   16: getfield a : I
    //   19: ifne -> 54
    //   22: aload_0
    //   23: getfield h : Landroid/content/Context;
    //   26: invokevirtual getResources : ()Landroid/content/res/Resources;
    //   29: invokevirtual getConfiguration : ()Landroid/content/res/Configuration;
    //   32: getfield screenLayout : I
    //   35: bipush #15
    //   37: iand
    //   38: iconst_4
    //   39: if_icmpne -> 47
    //   42: iconst_1
    //   43: istore_3
    //   44: goto -> 49
    //   47: iconst_0
    //   48: istore_3
    //   49: iload_3
    //   50: ifeq -> 54
    //   53: return
    //   54: aload_0
    //   55: invokevirtual D : ()Landroid/view/Window$Callback;
    //   58: astore #4
    //   60: aload #4
    //   62: ifnull -> 90
    //   65: aload #4
    //   67: aload_1
    //   68: getfield a : I
    //   71: aload_1
    //   72: getfield h : Lc/b/g/n/l;
    //   75: invokeinterface onMenuOpened : (ILandroid/view/Menu;)Z
    //   80: ifne -> 90
    //   83: aload_0
    //   84: aload_1
    //   85: iconst_1
    //   86: invokevirtual s : (Lc/b/c/i0;Z)V
    //   89: return
    //   90: aload_0
    //   91: getfield h : Landroid/content/Context;
    //   94: ldc_w 'window'
    //   97: invokevirtual getSystemService : (Ljava/lang/String;)Ljava/lang/Object;
    //   100: checkcast android/view/WindowManager
    //   103: astore #5
    //   105: aload #5
    //   107: ifnonnull -> 111
    //   110: return
    //   111: aload_0
    //   112: aload_1
    //   113: aload_2
    //   114: invokevirtual J : (Lc/b/c/i0;Landroid/view/KeyEvent;)Z
    //   117: ifne -> 121
    //   120: return
    //   121: aload_1
    //   122: getfield e : Landroid/view/ViewGroup;
    //   125: astore_2
    //   126: aload_2
    //   127: ifnull -> 171
    //   130: aload_1
    //   131: getfield o : Z
    //   134: ifeq -> 140
    //   137: goto -> 171
    //   140: aload_1
    //   141: getfield g : Landroid/view/View;
    //   144: astore_2
    //   145: aload_2
    //   146: ifnull -> 734
    //   149: aload_2
    //   150: invokevirtual getLayoutParams : ()Landroid/view/ViewGroup$LayoutParams;
    //   153: astore_2
    //   154: aload_2
    //   155: ifnull -> 734
    //   158: aload_2
    //   159: getfield width : I
    //   162: iconst_m1
    //   163: if_icmpne -> 734
    //   166: iconst_m1
    //   167: istore_3
    //   168: goto -> 737
    //   171: aload_2
    //   172: ifnonnull -> 359
    //   175: aload_0
    //   176: invokevirtual A : ()Landroid/content/Context;
    //   179: astore #4
    //   181: new android/util/TypedValue
    //   184: dup
    //   185: invokespecial <init> : ()V
    //   188: astore #6
    //   190: aload #4
    //   192: invokevirtual getResources : ()Landroid/content/res/Resources;
    //   195: invokevirtual newTheme : ()Landroid/content/res/Resources$Theme;
    //   198: astore_2
    //   199: aload_2
    //   200: aload #4
    //   202: invokevirtual getTheme : ()Landroid/content/res/Resources$Theme;
    //   205: invokevirtual setTo : (Landroid/content/res/Resources$Theme;)V
    //   208: aload_2
    //   209: ldc_w 2130903042
    //   212: aload #6
    //   214: iconst_1
    //   215: invokevirtual resolveAttribute : (ILandroid/util/TypedValue;Z)Z
    //   218: pop
    //   219: aload #6
    //   221: getfield resourceId : I
    //   224: istore_3
    //   225: iload_3
    //   226: ifeq -> 235
    //   229: aload_2
    //   230: iload_3
    //   231: iconst_1
    //   232: invokevirtual applyStyle : (IZ)V
    //   235: aload_2
    //   236: ldc_w 2130903668
    //   239: aload #6
    //   241: iconst_1
    //   242: invokevirtual resolveAttribute : (ILandroid/util/TypedValue;Z)Z
    //   245: pop
    //   246: aload #6
    //   248: getfield resourceId : I
    //   251: istore_3
    //   252: iload_3
    //   253: ifeq -> 265
    //   256: aload_2
    //   257: iload_3
    //   258: iconst_1
    //   259: invokevirtual applyStyle : (IZ)V
    //   262: goto -> 273
    //   265: aload_2
    //   266: ldc_w 2131820938
    //   269: iconst_1
    //   270: invokevirtual applyStyle : (IZ)V
    //   273: new c/b/g/d
    //   276: dup
    //   277: aload #4
    //   279: iconst_0
    //   280: invokespecial <init> : (Landroid/content/Context;I)V
    //   283: astore #4
    //   285: aload #4
    //   287: invokevirtual getTheme : ()Landroid/content/res/Resources$Theme;
    //   290: aload_2
    //   291: invokevirtual setTo : (Landroid/content/res/Resources$Theme;)V
    //   294: aload_1
    //   295: aload #4
    //   297: putfield j : Landroid/content/Context;
    //   300: aload #4
    //   302: getstatic c/b/b.j : [I
    //   305: invokevirtual obtainStyledAttributes : ([I)Landroid/content/res/TypedArray;
    //   308: astore_2
    //   309: aload_1
    //   310: aload_2
    //   311: bipush #84
    //   313: iconst_0
    //   314: invokevirtual getResourceId : (II)I
    //   317: putfield b : I
    //   320: aload_1
    //   321: aload_2
    //   322: iconst_1
    //   323: iconst_0
    //   324: invokevirtual getResourceId : (II)I
    //   327: putfield d : I
    //   330: aload_2
    //   331: invokevirtual recycle : ()V
    //   334: aload_1
    //   335: new c/b/c/h0
    //   338: dup
    //   339: aload_0
    //   340: aload_1
    //   341: getfield j : Landroid/content/Context;
    //   344: invokespecial <init> : (Lc/b/c/k0;Landroid/content/Context;)V
    //   347: putfield e : Landroid/view/ViewGroup;
    //   350: aload_1
    //   351: bipush #81
    //   353: putfield c : I
    //   356: goto -> 380
    //   359: aload_1
    //   360: getfield o : Z
    //   363: ifeq -> 380
    //   366: aload_2
    //   367: invokevirtual getChildCount : ()I
    //   370: ifle -> 380
    //   373: aload_1
    //   374: getfield e : Landroid/view/ViewGroup;
    //   377: invokevirtual removeAllViews : ()V
    //   380: aload_1
    //   381: getfield g : Landroid/view/View;
    //   384: astore_2
    //   385: aload_2
    //   386: ifnull -> 397
    //   389: aload_1
    //   390: aload_2
    //   391: putfield f : Landroid/view/View;
    //   394: goto -> 572
    //   397: aload_1
    //   398: getfield h : Lc/b/g/n/l;
    //   401: ifnonnull -> 407
    //   404: goto -> 577
    //   407: aload_0
    //   408: getfield q : Lc/b/c/j0;
    //   411: ifnonnull -> 426
    //   414: aload_0
    //   415: new c/b/c/j0
    //   418: dup
    //   419: aload_0
    //   420: invokespecial <init> : (Lc/b/c/k0;)V
    //   423: putfield q : Lc/b/c/j0;
    //   426: aload_0
    //   427: getfield q : Lc/b/c/j0;
    //   430: astore #4
    //   432: aload_1
    //   433: getfield i : Lc/b/g/n/j;
    //   436: ifnonnull -> 482
    //   439: new c/b/g/n/j
    //   442: dup
    //   443: aload_1
    //   444: getfield j : Landroid/content/Context;
    //   447: ldc_w 2131427344
    //   450: invokespecial <init> : (Landroid/content/Context;I)V
    //   453: astore_2
    //   454: aload_1
    //   455: aload_2
    //   456: putfield i : Lc/b/g/n/j;
    //   459: aload_2
    //   460: aload #4
    //   462: putfield i : Lc/b/g/n/y$a;
    //   465: aload_1
    //   466: getfield h : Lc/b/g/n/l;
    //   469: astore #4
    //   471: aload #4
    //   473: aload_2
    //   474: aload #4
    //   476: getfield a : Landroid/content/Context;
    //   479: invokevirtual b : (Lc/b/g/n/y;Landroid/content/Context;)V
    //   482: aload_1
    //   483: getfield i : Lc/b/g/n/j;
    //   486: astore_2
    //   487: aload_1
    //   488: getfield e : Landroid/view/ViewGroup;
    //   491: astore #4
    //   493: aload_2
    //   494: getfield h : Landroidx/appcompat/view/menu/ExpandedMenuView;
    //   497: ifnonnull -> 558
    //   500: aload_2
    //   501: aload_2
    //   502: getfield f : Landroid/view/LayoutInflater;
    //   505: ldc_w 2131427341
    //   508: aload #4
    //   510: iconst_0
    //   511: invokevirtual inflate : (ILandroid/view/ViewGroup;Z)Landroid/view/View;
    //   514: checkcast androidx/appcompat/view/menu/ExpandedMenuView
    //   517: putfield h : Landroidx/appcompat/view/menu/ExpandedMenuView;
    //   520: aload_2
    //   521: getfield j : Lc/b/g/n/i;
    //   524: ifnonnull -> 539
    //   527: aload_2
    //   528: new c/b/g/n/i
    //   531: dup
    //   532: aload_2
    //   533: invokespecial <init> : (Lc/b/g/n/j;)V
    //   536: putfield j : Lc/b/g/n/i;
    //   539: aload_2
    //   540: getfield h : Landroidx/appcompat/view/menu/ExpandedMenuView;
    //   543: aload_2
    //   544: getfield j : Lc/b/g/n/i;
    //   547: invokevirtual setAdapter : (Landroid/widget/ListAdapter;)V
    //   550: aload_2
    //   551: getfield h : Landroidx/appcompat/view/menu/ExpandedMenuView;
    //   554: aload_2
    //   555: invokevirtual setOnItemClickListener : (Landroid/widget/AdapterView$OnItemClickListener;)V
    //   558: aload_2
    //   559: getfield h : Landroidx/appcompat/view/menu/ExpandedMenuView;
    //   562: astore_2
    //   563: aload_1
    //   564: aload_2
    //   565: putfield f : Landroid/view/View;
    //   568: aload_2
    //   569: ifnull -> 577
    //   572: iconst_1
    //   573: istore_3
    //   574: goto -> 579
    //   577: iconst_0
    //   578: istore_3
    //   579: iload_3
    //   580: ifeq -> 797
    //   583: aload_1
    //   584: getfield f : Landroid/view/View;
    //   587: ifnonnull -> 593
    //   590: goto -> 624
    //   593: aload_1
    //   594: getfield g : Landroid/view/View;
    //   597: ifnull -> 603
    //   600: goto -> 619
    //   603: aload_1
    //   604: getfield i : Lc/b/g/n/j;
    //   607: invokevirtual b : ()Landroid/widget/ListAdapter;
    //   610: checkcast c/b/g/n/i
    //   613: invokevirtual getCount : ()I
    //   616: ifle -> 624
    //   619: iconst_1
    //   620: istore_3
    //   621: goto -> 626
    //   624: iconst_0
    //   625: istore_3
    //   626: iload_3
    //   627: ifne -> 633
    //   630: goto -> 797
    //   633: aload_1
    //   634: getfield f : Landroid/view/View;
    //   637: invokevirtual getLayoutParams : ()Landroid/view/ViewGroup$LayoutParams;
    //   640: astore #4
    //   642: aload #4
    //   644: astore_2
    //   645: aload #4
    //   647: ifnonnull -> 662
    //   650: new android/view/ViewGroup$LayoutParams
    //   653: dup
    //   654: bipush #-2
    //   656: bipush #-2
    //   658: invokespecial <init> : (II)V
    //   661: astore_2
    //   662: aload_1
    //   663: getfield b : I
    //   666: istore_3
    //   667: aload_1
    //   668: getfield e : Landroid/view/ViewGroup;
    //   671: iload_3
    //   672: invokevirtual setBackgroundResource : (I)V
    //   675: aload_1
    //   676: getfield f : Landroid/view/View;
    //   679: invokevirtual getParent : ()Landroid/view/ViewParent;
    //   682: astore #4
    //   684: aload #4
    //   686: instanceof android/view/ViewGroup
    //   689: ifeq -> 704
    //   692: aload #4
    //   694: checkcast android/view/ViewGroup
    //   697: aload_1
    //   698: getfield f : Landroid/view/View;
    //   701: invokevirtual removeView : (Landroid/view/View;)V
    //   704: aload_1
    //   705: getfield e : Landroid/view/ViewGroup;
    //   708: aload_1
    //   709: getfield f : Landroid/view/View;
    //   712: aload_2
    //   713: invokevirtual addView : (Landroid/view/View;Landroid/view/ViewGroup$LayoutParams;)V
    //   716: aload_1
    //   717: getfield f : Landroid/view/View;
    //   720: invokevirtual hasFocus : ()Z
    //   723: ifne -> 734
    //   726: aload_1
    //   727: getfield f : Landroid/view/View;
    //   730: invokevirtual requestFocus : ()Z
    //   733: pop
    //   734: bipush #-2
    //   736: istore_3
    //   737: aload_1
    //   738: iconst_0
    //   739: putfield l : Z
    //   742: new android/view/WindowManager$LayoutParams
    //   745: dup
    //   746: iload_3
    //   747: bipush #-2
    //   749: iconst_0
    //   750: iconst_0
    //   751: sipush #1002
    //   754: ldc_w 8519680
    //   757: bipush #-3
    //   759: invokespecial <init> : (IIIIIII)V
    //   762: astore_2
    //   763: aload_2
    //   764: aload_1
    //   765: getfield c : I
    //   768: putfield gravity : I
    //   771: aload_2
    //   772: aload_1
    //   773: getfield d : I
    //   776: putfield windowAnimations : I
    //   779: aload #5
    //   781: aload_1
    //   782: getfield e : Landroid/view/ViewGroup;
    //   785: aload_2
    //   786: invokeinterface addView : (Landroid/view/View;Landroid/view/ViewGroup$LayoutParams;)V
    //   791: aload_1
    //   792: iconst_1
    //   793: putfield m : Z
    //   796: return
    //   797: aload_1
    //   798: iconst_1
    //   799: putfield o : Z
    //   802: return
  }
  
  public final boolean I(i0 parami0, int paramInt1, KeyEvent paramKeyEvent, int paramInt2) {
    // Byte code:
    //   0: aload_3
    //   1: invokevirtual isSystem : ()Z
    //   4: istore #5
    //   6: iconst_0
    //   7: istore #6
    //   9: iload #5
    //   11: ifeq -> 16
    //   14: iconst_0
    //   15: ireturn
    //   16: aload_1
    //   17: getfield k : Z
    //   20: ifne -> 36
    //   23: iload #6
    //   25: istore #5
    //   27: aload_0
    //   28: aload_1
    //   29: aload_3
    //   30: invokevirtual J : (Lc/b/c/i0;Landroid/view/KeyEvent;)Z
    //   33: ifeq -> 62
    //   36: aload_1
    //   37: getfield h : Lc/b/g/n/l;
    //   40: astore #7
    //   42: iload #6
    //   44: istore #5
    //   46: aload #7
    //   48: ifnull -> 62
    //   51: aload #7
    //   53: iload_2
    //   54: aload_3
    //   55: iload #4
    //   57: invokevirtual performShortcut : (ILandroid/view/KeyEvent;I)Z
    //   60: istore #5
    //   62: iload #5
    //   64: ifeq -> 87
    //   67: iload #4
    //   69: iconst_1
    //   70: iand
    //   71: ifne -> 87
    //   74: aload_0
    //   75: getfield o : Lc/b/h/a1;
    //   78: ifnonnull -> 87
    //   81: aload_0
    //   82: aload_1
    //   83: iconst_1
    //   84: invokevirtual s : (Lc/b/c/i0;Z)V
    //   87: iload #5
    //   89: ireturn
  }
  
  public final boolean J(i0 parami0, KeyEvent paramKeyEvent) {
    // Byte code:
    //   0: aload_0
    //   1: getfield O : Z
    //   4: ifeq -> 9
    //   7: iconst_0
    //   8: ireturn
    //   9: aload_1
    //   10: getfield k : Z
    //   13: ifeq -> 18
    //   16: iconst_1
    //   17: ireturn
    //   18: aload_0
    //   19: getfield J : Lc/b/c/i0;
    //   22: astore #6
    //   24: aload #6
    //   26: ifnull -> 42
    //   29: aload #6
    //   31: aload_1
    //   32: if_acmpeq -> 42
    //   35: aload_0
    //   36: aload #6
    //   38: iconst_0
    //   39: invokevirtual s : (Lc/b/c/i0;Z)V
    //   42: aload_0
    //   43: invokevirtual D : ()Landroid/view/Window$Callback;
    //   46: astore #9
    //   48: aload #9
    //   50: ifnull -> 68
    //   53: aload_1
    //   54: aload #9
    //   56: aload_1
    //   57: getfield a : I
    //   60: invokeinterface onCreatePanelView : (I)Landroid/view/View;
    //   65: putfield g : Landroid/view/View;
    //   68: aload_1
    //   69: getfield a : I
    //   72: istore_3
    //   73: iload_3
    //   74: ifeq -> 91
    //   77: iload_3
    //   78: bipush #108
    //   80: if_icmpne -> 86
    //   83: goto -> 91
    //   86: iconst_0
    //   87: istore_3
    //   88: goto -> 93
    //   91: iconst_1
    //   92: istore_3
    //   93: iload_3
    //   94: ifeq -> 132
    //   97: aload_0
    //   98: getfield o : Lc/b/h/a1;
    //   101: astore #6
    //   103: aload #6
    //   105: ifnull -> 132
    //   108: aload #6
    //   110: checkcast androidx/appcompat/widget/ActionBarOverlayLayout
    //   113: astore #6
    //   115: aload #6
    //   117: invokevirtual m : ()V
    //   120: aload #6
    //   122: getfield i : Lc/b/h/b1;
    //   125: checkcast c/b/h/n2
    //   128: iconst_1
    //   129: putfield m : Z
    //   132: aload_1
    //   133: getfield g : Landroid/view/View;
    //   136: ifnonnull -> 688
    //   139: iload_3
    //   140: ifeq -> 153
    //   143: aload_0
    //   144: getfield l : Lc/b/c/a;
    //   147: instanceof c/b/c/t0
    //   150: ifne -> 688
    //   153: aload_1
    //   154: getfield h : Lc/b/g/n/l;
    //   157: astore #6
    //   159: aload #6
    //   161: ifnull -> 171
    //   164: aload_1
    //   165: getfield p : Z
    //   168: ifeq -> 543
    //   171: aload #6
    //   173: ifnonnull -> 421
    //   176: aload_0
    //   177: getfield h : Landroid/content/Context;
    //   180: astore #8
    //   182: aload_1
    //   183: getfield a : I
    //   186: istore #4
    //   188: iload #4
    //   190: ifeq -> 204
    //   193: aload #8
    //   195: astore #6
    //   197: iload #4
    //   199: bipush #108
    //   201: if_icmpne -> 389
    //   204: aload #8
    //   206: astore #6
    //   208: aload_0
    //   209: getfield o : Lc/b/h/a1;
    //   212: ifnull -> 389
    //   215: new android/util/TypedValue
    //   218: dup
    //   219: invokespecial <init> : ()V
    //   222: astore #10
    //   224: aload #8
    //   226: invokevirtual getTheme : ()Landroid/content/res/Resources$Theme;
    //   229: astore #11
    //   231: aload #11
    //   233: ldc_w 2130903049
    //   236: aload #10
    //   238: iconst_1
    //   239: invokevirtual resolveAttribute : (ILandroid/util/TypedValue;Z)Z
    //   242: pop
    //   243: aload #10
    //   245: getfield resourceId : I
    //   248: ifeq -> 294
    //   251: aload #8
    //   253: invokevirtual getResources : ()Landroid/content/res/Resources;
    //   256: invokevirtual newTheme : ()Landroid/content/res/Resources$Theme;
    //   259: astore #6
    //   261: aload #6
    //   263: aload #11
    //   265: invokevirtual setTo : (Landroid/content/res/Resources$Theme;)V
    //   268: aload #6
    //   270: aload #10
    //   272: getfield resourceId : I
    //   275: iconst_1
    //   276: invokevirtual applyStyle : (IZ)V
    //   279: aload #6
    //   281: ldc_w 2130903050
    //   284: aload #10
    //   286: iconst_1
    //   287: invokevirtual resolveAttribute : (ILandroid/util/TypedValue;Z)Z
    //   290: pop
    //   291: goto -> 309
    //   294: aload #11
    //   296: ldc_w 2130903050
    //   299: aload #10
    //   301: iconst_1
    //   302: invokevirtual resolveAttribute : (ILandroid/util/TypedValue;Z)Z
    //   305: pop
    //   306: aconst_null
    //   307: astore #6
    //   309: aload #6
    //   311: astore #7
    //   313: aload #10
    //   315: getfield resourceId : I
    //   318: ifeq -> 358
    //   321: aload #6
    //   323: astore #7
    //   325: aload #6
    //   327: ifnonnull -> 347
    //   330: aload #8
    //   332: invokevirtual getResources : ()Landroid/content/res/Resources;
    //   335: invokevirtual newTheme : ()Landroid/content/res/Resources$Theme;
    //   338: astore #7
    //   340: aload #7
    //   342: aload #11
    //   344: invokevirtual setTo : (Landroid/content/res/Resources$Theme;)V
    //   347: aload #7
    //   349: aload #10
    //   351: getfield resourceId : I
    //   354: iconst_1
    //   355: invokevirtual applyStyle : (IZ)V
    //   358: aload #8
    //   360: astore #6
    //   362: aload #7
    //   364: ifnull -> 389
    //   367: new c/b/g/d
    //   370: dup
    //   371: aload #8
    //   373: iconst_0
    //   374: invokespecial <init> : (Landroid/content/Context;I)V
    //   377: astore #6
    //   379: aload #6
    //   381: invokevirtual getTheme : ()Landroid/content/res/Resources$Theme;
    //   384: aload #7
    //   386: invokevirtual setTo : (Landroid/content/res/Resources$Theme;)V
    //   389: new c/b/g/n/l
    //   392: dup
    //   393: aload #6
    //   395: invokespecial <init> : (Landroid/content/Context;)V
    //   398: astore #6
    //   400: aload #6
    //   402: aload_0
    //   403: putfield e : Lc/b/g/n/l$a;
    //   406: aload_1
    //   407: aload #6
    //   409: invokevirtual a : (Lc/b/g/n/l;)V
    //   412: aload_1
    //   413: getfield h : Lc/b/g/n/l;
    //   416: ifnonnull -> 421
    //   419: iconst_0
    //   420: ireturn
    //   421: iload_3
    //   422: ifeq -> 479
    //   425: aload_0
    //   426: getfield o : Lc/b/h/a1;
    //   429: astore #6
    //   431: aload #6
    //   433: ifnull -> 479
    //   436: aload_0
    //   437: getfield p : Lc/b/c/z;
    //   440: ifnonnull -> 455
    //   443: aload_0
    //   444: new c/b/c/z
    //   447: dup
    //   448: aload_0
    //   449: invokespecial <init> : (Lc/b/c/k0;)V
    //   452: putfield p : Lc/b/c/z;
    //   455: aload_1
    //   456: getfield h : Lc/b/g/n/l;
    //   459: astore #7
    //   461: aload_0
    //   462: getfield p : Lc/b/c/z;
    //   465: astore #8
    //   467: aload #6
    //   469: checkcast androidx/appcompat/widget/ActionBarOverlayLayout
    //   472: aload #7
    //   474: aload #8
    //   476: invokevirtual n : (Landroid/view/Menu;Lc/b/g/n/y$a;)V
    //   479: aload_1
    //   480: getfield h : Lc/b/g/n/l;
    //   483: invokevirtual z : ()V
    //   486: aload #9
    //   488: aload_1
    //   489: getfield a : I
    //   492: aload_1
    //   493: getfield h : Lc/b/g/n/l;
    //   496: invokeinterface onCreatePanelMenu : (ILandroid/view/Menu;)Z
    //   501: ifne -> 538
    //   504: aload_1
    //   505: aconst_null
    //   506: invokevirtual a : (Lc/b/g/n/l;)V
    //   509: iload_3
    //   510: ifeq -> 536
    //   513: aload_0
    //   514: getfield o : Lc/b/h/a1;
    //   517: astore_1
    //   518: aload_1
    //   519: ifnull -> 536
    //   522: aload_0
    //   523: getfield p : Lc/b/c/z;
    //   526: astore_2
    //   527: aload_1
    //   528: checkcast androidx/appcompat/widget/ActionBarOverlayLayout
    //   531: aconst_null
    //   532: aload_2
    //   533: invokevirtual n : (Landroid/view/Menu;Lc/b/g/n/y$a;)V
    //   536: iconst_0
    //   537: ireturn
    //   538: aload_1
    //   539: iconst_0
    //   540: putfield p : Z
    //   543: aload_1
    //   544: getfield h : Lc/b/g/n/l;
    //   547: invokevirtual z : ()V
    //   550: aload_1
    //   551: getfield q : Landroid/os/Bundle;
    //   554: astore #6
    //   556: aload #6
    //   558: ifnull -> 575
    //   561: aload_1
    //   562: getfield h : Lc/b/g/n/l;
    //   565: aload #6
    //   567: invokevirtual v : (Landroid/os/Bundle;)V
    //   570: aload_1
    //   571: aconst_null
    //   572: putfield q : Landroid/os/Bundle;
    //   575: aload #9
    //   577: iconst_0
    //   578: aload_1
    //   579: getfield g : Landroid/view/View;
    //   582: aload_1
    //   583: getfield h : Lc/b/g/n/l;
    //   586: invokeinterface onPreparePanel : (ILandroid/view/View;Landroid/view/Menu;)Z
    //   591: ifne -> 632
    //   594: iload_3
    //   595: ifeq -> 623
    //   598: aload_0
    //   599: getfield o : Lc/b/h/a1;
    //   602: astore_2
    //   603: aload_2
    //   604: ifnull -> 623
    //   607: aload_0
    //   608: getfield p : Lc/b/c/z;
    //   611: astore #6
    //   613: aload_2
    //   614: checkcast androidx/appcompat/widget/ActionBarOverlayLayout
    //   617: aconst_null
    //   618: aload #6
    //   620: invokevirtual n : (Landroid/view/Menu;Lc/b/g/n/y$a;)V
    //   623: aload_1
    //   624: getfield h : Lc/b/g/n/l;
    //   627: invokevirtual y : ()V
    //   630: iconst_0
    //   631: ireturn
    //   632: aload_2
    //   633: ifnull -> 644
    //   636: aload_2
    //   637: invokevirtual getDeviceId : ()I
    //   640: istore_3
    //   641: goto -> 646
    //   644: iconst_m1
    //   645: istore_3
    //   646: iload_3
    //   647: invokestatic load : (I)Landroid/view/KeyCharacterMap;
    //   650: invokevirtual getKeyboardType : ()I
    //   653: iconst_1
    //   654: if_icmpeq -> 663
    //   657: iconst_1
    //   658: istore #5
    //   660: goto -> 666
    //   663: iconst_0
    //   664: istore #5
    //   666: aload_1
    //   667: iload #5
    //   669: putfield n : Z
    //   672: aload_1
    //   673: getfield h : Lc/b/g/n/l;
    //   676: iload #5
    //   678: invokevirtual setQwertyMode : (Z)V
    //   681: aload_1
    //   682: getfield h : Lc/b/g/n/l;
    //   685: invokevirtual y : ()V
    //   688: aload_1
    //   689: iconst_1
    //   690: putfield k : Z
    //   693: aload_1
    //   694: iconst_0
    //   695: putfield l : Z
    //   698: aload_0
    //   699: aload_1
    //   700: putfield J : Lc/b/c/i0;
    //   703: iconst_1
    //   704: ireturn
  }
  
  public final boolean K() {
    if (this.w) {
      ViewGroup viewGroup = this.x;
      if (viewGroup != null) {
        AtomicInteger atomicInteger = u.a;
        if (viewGroup.isLaidOut())
          return true; 
      } 
    } 
    return false;
  }
  
  public final void L() {
    if (!this.w)
      return; 
    throw new AndroidRuntimeException("Window feature must be requested before adding content");
  }
  
  public final int M(l0 paraml0, Rect paramRect) {
    int k;
    boolean bool;
    int j = paraml0.e();
    ActionBarContextView actionBarContextView = this.s;
    byte b1 = 8;
    if (actionBarContextView != null && actionBarContextView.getLayoutParams() instanceof ViewGroup.MarginLayoutParams) {
      int m;
      ViewGroup.MarginLayoutParams marginLayoutParams = (ViewGroup.MarginLayoutParams)this.s.getLayoutParams();
      boolean bool1 = this.s.isShown();
      int n = 1;
      bool = true;
      if (bool1) {
        int i1;
        if (this.Z == null) {
          this.Z = new Rect();
          this.a0 = new Rect();
        } 
        Rect rect1 = this.Z;
        Rect rect2 = this.a0;
        rect1.set(paraml0.c(), paraml0.e(), paraml0.d(), paraml0.b());
        t2.a((View)this.x, rect1, rect2);
        int i2 = rect1.top;
        m = rect1.left;
        int i3 = rect1.right;
        paraml0 = u.i((View)this.x);
        if (paraml0 == null) {
          i1 = 0;
        } else {
          i1 = paraml0.c();
        } 
        if (paraml0 == null) {
          n = 0;
        } else {
          n = paraml0.d();
        } 
        if (marginLayoutParams.topMargin != i2 || marginLayoutParams.leftMargin != m || marginLayoutParams.rightMargin != i3) {
          marginLayoutParams.topMargin = i2;
          marginLayoutParams.leftMargin = m;
          marginLayoutParams.rightMargin = i3;
          m = 1;
        } else {
          m = 0;
        } 
        if (i2 > 0 && this.z == null) {
          View view2 = new View(this.h);
          this.z = view2;
          view2.setVisibility(8);
          FrameLayout.LayoutParams layoutParams = new FrameLayout.LayoutParams(-1, marginLayoutParams.topMargin, 51);
          layoutParams.leftMargin = i1;
          layoutParams.rightMargin = n;
          this.x.addView(this.z, -1, (ViewGroup.LayoutParams)layoutParams);
        } else {
          View view2 = this.z;
          if (view2 != null) {
            ViewGroup.MarginLayoutParams marginLayoutParams1 = (ViewGroup.MarginLayoutParams)view2.getLayoutParams();
            i2 = marginLayoutParams1.height;
            i3 = marginLayoutParams.topMargin;
            if (i2 != i3 || marginLayoutParams1.leftMargin != i1 || marginLayoutParams1.rightMargin != n) {
              marginLayoutParams1.height = i3;
              marginLayoutParams1.leftMargin = i1;
              marginLayoutParams1.rightMargin = n;
              this.z.setLayoutParams((ViewGroup.LayoutParams)marginLayoutParams1);
            } 
          } 
        } 
        View view1 = this.z;
        if (view1 != null) {
          i1 = 1;
        } else {
          i1 = 0;
        } 
        if (i1 != 0 && view1.getVisibility() != 0) {
          view1 = this.z;
          AtomicInteger atomicInteger = u.a;
          if ((view1.getWindowSystemUiVisibility() & 0x2000) != 0) {
            n = bool;
          } else {
            n = 0;
          } 
          if (n != 0) {
            Context context = this.h;
            Object object = b.a;
            n = c.a(context, 2131034118);
          } else {
            Context context = this.h;
            Object object = b.a;
            n = c.a(context, 2131034117);
          } 
          view1.setBackgroundColor(n);
        } 
        bool = j;
        if (!this.E) {
          bool = j;
          if (i1 != 0)
            bool = false; 
        } 
        n = m;
        m = i1;
        j = bool;
      } else if (marginLayoutParams.topMargin != 0) {
        marginLayoutParams.topMargin = 0;
        m = 0;
      } else {
        n = 0;
        m = n;
      } 
      bool = m;
      k = j;
      if (n != 0) {
        this.s.setLayoutParams((ViewGroup.LayoutParams)marginLayoutParams);
        bool = m;
        k = j;
      } 
    } else {
      bool = false;
      k = j;
    } 
    View view = this.z;
    if (view != null) {
      byte b2 = b1;
      if (bool)
        b2 = 0; 
      view.setVisibility(b2);
    } 
    return k;
  }
  
  public boolean a(l paraml, MenuItem paramMenuItem) {
    Window.Callback callback = D();
    if (callback != null && !this.O) {
      i0 i01 = z((Menu)paraml.k());
      if (i01 != null)
        return callback.onMenuItemSelected(i01.a, paramMenuItem); 
    } 
    return false;
  }
  
  public void b(l paraml) {
    // Byte code:
    //   0: aload_0
    //   1: getfield o : Lc/b/h/a1;
    //   4: astore_1
    //   5: aload_1
    //   6: ifnull -> 317
    //   9: aload_1
    //   10: checkcast androidx/appcompat/widget/ActionBarOverlayLayout
    //   13: invokevirtual h : ()Z
    //   16: ifeq -> 317
    //   19: aload_0
    //   20: getfield h : Landroid/content/Context;
    //   23: invokestatic get : (Landroid/content/Context;)Landroid/view/ViewConfiguration;
    //   26: invokevirtual hasPermanentMenuKey : ()Z
    //   29: ifeq -> 121
    //   32: aload_0
    //   33: getfield o : Lc/b/h/a1;
    //   36: checkcast androidx/appcompat/widget/ActionBarOverlayLayout
    //   39: astore_1
    //   40: aload_1
    //   41: invokevirtual m : ()V
    //   44: aload_1
    //   45: getfield i : Lc/b/h/b1;
    //   48: checkcast c/b/h/n2
    //   51: getfield a : Landroidx/appcompat/widget/Toolbar;
    //   54: getfield e : Landroidx/appcompat/widget/ActionMenuView;
    //   57: astore_1
    //   58: aload_1
    //   59: ifnull -> 115
    //   62: aload_1
    //   63: getfield x : Lc/b/h/m;
    //   66: astore_1
    //   67: aload_1
    //   68: ifnull -> 104
    //   71: aload_1
    //   72: getfield A : Lc/b/h/f;
    //   75: ifnonnull -> 93
    //   78: aload_1
    //   79: invokevirtual o : ()Z
    //   82: ifeq -> 88
    //   85: goto -> 93
    //   88: iconst_0
    //   89: istore_2
    //   90: goto -> 95
    //   93: iconst_1
    //   94: istore_2
    //   95: iload_2
    //   96: ifeq -> 104
    //   99: iconst_1
    //   100: istore_2
    //   101: goto -> 106
    //   104: iconst_0
    //   105: istore_2
    //   106: iload_2
    //   107: ifeq -> 115
    //   110: iconst_1
    //   111: istore_2
    //   112: goto -> 117
    //   115: iconst_0
    //   116: istore_2
    //   117: iload_2
    //   118: ifeq -> 317
    //   121: aload_0
    //   122: invokevirtual D : ()Landroid/view/Window$Callback;
    //   125: astore_1
    //   126: aload_0
    //   127: getfield o : Lc/b/h/a1;
    //   130: checkcast androidx/appcompat/widget/ActionBarOverlayLayout
    //   133: invokevirtual l : ()Z
    //   136: ifeq -> 186
    //   139: aload_0
    //   140: getfield o : Lc/b/h/a1;
    //   143: checkcast androidx/appcompat/widget/ActionBarOverlayLayout
    //   146: astore_3
    //   147: aload_3
    //   148: invokevirtual m : ()V
    //   151: aload_3
    //   152: getfield i : Lc/b/h/b1;
    //   155: checkcast c/b/h/n2
    //   158: invokevirtual b : ()Z
    //   161: pop
    //   162: aload_0
    //   163: getfield O : Z
    //   166: ifne -> 340
    //   169: aload_1
    //   170: bipush #108
    //   172: aload_0
    //   173: iconst_0
    //   174: invokevirtual C : (I)Lc/b/c/i0;
    //   177: getfield h : Lc/b/g/n/l;
    //   180: invokeinterface onPanelClosed : (ILandroid/view/Menu;)V
    //   185: return
    //   186: aload_1
    //   187: ifnull -> 340
    //   190: aload_0
    //   191: getfield O : Z
    //   194: ifne -> 340
    //   197: aload_0
    //   198: getfield V : Z
    //   201: ifeq -> 237
    //   204: iconst_1
    //   205: aload_0
    //   206: getfield W : I
    //   209: iand
    //   210: ifeq -> 237
    //   213: aload_0
    //   214: getfield i : Landroid/view/Window;
    //   217: invokevirtual getDecorView : ()Landroid/view/View;
    //   220: aload_0
    //   221: getfield X : Ljava/lang/Runnable;
    //   224: invokevirtual removeCallbacks : (Ljava/lang/Runnable;)Z
    //   227: pop
    //   228: aload_0
    //   229: getfield X : Ljava/lang/Runnable;
    //   232: invokeinterface run : ()V
    //   237: aload_0
    //   238: iconst_0
    //   239: invokevirtual C : (I)Lc/b/c/i0;
    //   242: astore_3
    //   243: aload_3
    //   244: getfield h : Lc/b/g/n/l;
    //   247: astore #4
    //   249: aload #4
    //   251: ifnull -> 340
    //   254: aload_3
    //   255: getfield p : Z
    //   258: ifne -> 340
    //   261: aload_1
    //   262: iconst_0
    //   263: aload_3
    //   264: getfield g : Landroid/view/View;
    //   267: aload #4
    //   269: invokeinterface onPreparePanel : (ILandroid/view/View;Landroid/view/Menu;)Z
    //   274: ifeq -> 340
    //   277: aload_1
    //   278: bipush #108
    //   280: aload_3
    //   281: getfield h : Lc/b/g/n/l;
    //   284: invokeinterface onMenuOpened : (ILandroid/view/Menu;)Z
    //   289: pop
    //   290: aload_0
    //   291: getfield o : Lc/b/h/a1;
    //   294: checkcast androidx/appcompat/widget/ActionBarOverlayLayout
    //   297: astore_1
    //   298: aload_1
    //   299: invokevirtual m : ()V
    //   302: aload_1
    //   303: getfield i : Lc/b/h/b1;
    //   306: checkcast c/b/h/n2
    //   309: getfield a : Landroidx/appcompat/widget/Toolbar;
    //   312: invokevirtual u : ()Z
    //   315: pop
    //   316: return
    //   317: aload_0
    //   318: iconst_0
    //   319: invokevirtual C : (I)Lc/b/c/i0;
    //   322: astore_1
    //   323: aload_1
    //   324: iconst_1
    //   325: putfield o : Z
    //   328: aload_0
    //   329: aload_1
    //   330: iconst_0
    //   331: invokevirtual s : (Lc/b/c/i0;Z)V
    //   334: aload_0
    //   335: aload_1
    //   336: aconst_null
    //   337: invokevirtual H : (Lc/b/c/i0;Landroid/view/KeyEvent;)V
    //   340: return
  }
  
  public void c(View paramView, ViewGroup.LayoutParams paramLayoutParams) {
    x();
    ((ViewGroup)this.x.findViewById(16908290)).addView(paramView, paramLayoutParams);
    this.j.e.onContentChanged();
  }
  
  public void d() {
    LayoutInflater layoutInflater = LayoutInflater.from(this.h);
    if (layoutInflater.getFactory() == null) {
      layoutInflater.setFactory2(this);
      return;
    } 
    if (!(layoutInflater.getFactory2() instanceof k0))
      Log.i("AppCompatDelegate", "The Activity's LayoutInflater already has a Factory installed so we can not install AppCompat's"); 
  }
  
  public void e() {
    E();
    a a2 = this.l;
    if (a2 != null && a2.f())
      return; 
    F(0);
  }
  
  public void f(Bundle paramBundle) {
    this.L = true;
    o(false);
    y();
    Object object = this.g;
    if (object instanceof Activity) {
      paramBundle = null;
      try {
        object = object;
        try {
          object = h.E((Context)object, object.getComponentName());
          null = object;
        } catch (android.content.pm.PackageManager.NameNotFoundException nameNotFoundException) {
          throw new IllegalArgumentException(nameNotFoundException);
        } 
      } catch (IllegalArgumentException illegalArgumentException) {}
      if (null != null) {
        null = this.l;
        if (null == null) {
          this.Y = true;
        } else {
          null.l(true);
        } 
      } 
      synchronized (r.f) {
        r.h(this);
        r.e.add(new WeakReference<k0>(this));
      } 
    } 
    this.M = true;
  }
  
  public void g() {
    // Byte code:
    //   0: aload_0
    //   1: getfield g : Ljava/lang/Object;
    //   4: instanceof android/app/Activity
    //   7: ifeq -> 30
    //   10: getstatic c/b/c/r.f : Ljava/lang/Object;
    //   13: astore_1
    //   14: aload_1
    //   15: monitorenter
    //   16: aload_0
    //   17: invokestatic h : (Lc/b/c/r;)V
    //   20: aload_1
    //   21: monitorexit
    //   22: goto -> 30
    //   25: astore_2
    //   26: aload_1
    //   27: monitorexit
    //   28: aload_2
    //   29: athrow
    //   30: aload_0
    //   31: getfield V : Z
    //   34: ifeq -> 52
    //   37: aload_0
    //   38: getfield i : Landroid/view/Window;
    //   41: invokevirtual getDecorView : ()Landroid/view/View;
    //   44: aload_0
    //   45: getfield X : Ljava/lang/Runnable;
    //   48: invokevirtual removeCallbacks : (Ljava/lang/Runnable;)Z
    //   51: pop
    //   52: aload_0
    //   53: iconst_0
    //   54: putfield N : Z
    //   57: aload_0
    //   58: iconst_1
    //   59: putfield O : Z
    //   62: aload_0
    //   63: getfield P : I
    //   66: bipush #-100
    //   68: if_icmpeq -> 120
    //   71: aload_0
    //   72: getfield g : Ljava/lang/Object;
    //   75: astore_1
    //   76: aload_1
    //   77: instanceof android/app/Activity
    //   80: ifeq -> 120
    //   83: aload_1
    //   84: checkcast android/app/Activity
    //   87: invokevirtual isChangingConfigurations : ()Z
    //   90: ifeq -> 120
    //   93: getstatic c/b/c/k0.c0 : Lc/e/i;
    //   96: aload_0
    //   97: getfield g : Ljava/lang/Object;
    //   100: invokevirtual getClass : ()Ljava/lang/Class;
    //   103: invokevirtual getName : ()Ljava/lang/String;
    //   106: aload_0
    //   107: getfield P : I
    //   110: invokestatic valueOf : (I)Ljava/lang/Integer;
    //   113: invokevirtual put : (Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    //   116: pop
    //   117: goto -> 137
    //   120: getstatic c/b/c/k0.c0 : Lc/e/i;
    //   123: aload_0
    //   124: getfield g : Ljava/lang/Object;
    //   127: invokevirtual getClass : ()Ljava/lang/Class;
    //   130: invokevirtual getName : ()Ljava/lang/String;
    //   133: invokevirtual remove : (Ljava/lang/Object;)Ljava/lang/Object;
    //   136: pop
    //   137: aload_0
    //   138: getfield l : Lc/b/c/a;
    //   141: astore_1
    //   142: aload_1
    //   143: ifnull -> 150
    //   146: aload_1
    //   147: invokevirtual h : ()V
    //   150: aload_0
    //   151: getfield T : Lc/b/c/f0;
    //   154: astore_1
    //   155: aload_1
    //   156: ifnull -> 163
    //   159: aload_1
    //   160: invokevirtual a : ()V
    //   163: aload_0
    //   164: getfield U : Lc/b/c/f0;
    //   167: astore_1
    //   168: aload_1
    //   169: ifnull -> 176
    //   172: aload_1
    //   173: invokevirtual a : ()V
    //   176: return
    // Exception table:
    //   from	to	target	type
    //   16	22	25	finally
    //   26	28	25	finally
  }
  
  public boolean i(int paramInt) {
    int j;
    if (paramInt == 8) {
      Log.i("AppCompatDelegate", "You should now use the AppCompatDelegate.FEATURE_SUPPORT_ACTION_BAR id when requesting this feature.");
      j = 108;
    } else {
      j = paramInt;
      if (paramInt == 9) {
        Log.i("AppCompatDelegate", "You should now use the AppCompatDelegate.FEATURE_SUPPORT_ACTION_BAR_OVERLAY id when requesting this feature.");
        j = 109;
      } 
    } 
    if (this.G && j == 108)
      return false; 
    if (this.C && j == 1)
      this.C = false; 
    if (j != 1) {
      if (j != 2) {
        if (j != 5) {
          if (j != 10) {
            if (j != 108) {
              if (j != 109)
                return this.i.requestFeature(j); 
              L();
              this.D = true;
              return true;
            } 
            L();
            this.C = true;
            return true;
          } 
          L();
          this.E = true;
          return true;
        } 
        L();
        this.B = true;
        return true;
      } 
      L();
      this.A = true;
      return true;
    } 
    L();
    this.G = true;
    return true;
  }
  
  public void j(int paramInt) {
    x();
    ViewGroup viewGroup = (ViewGroup)this.x.findViewById(16908290);
    viewGroup.removeAllViews();
    LayoutInflater.from(this.h).inflate(paramInt, viewGroup);
    this.j.e.onContentChanged();
  }
  
  public void k(View paramView) {
    x();
    ViewGroup viewGroup = (ViewGroup)this.x.findViewById(16908290);
    viewGroup.removeAllViews();
    viewGroup.addView(paramView);
    this.j.e.onContentChanged();
  }
  
  public void l(View paramView, ViewGroup.LayoutParams paramLayoutParams) {
    x();
    ViewGroup viewGroup = (ViewGroup)this.x.findViewById(16908290);
    viewGroup.removeAllViews();
    viewGroup.addView(paramView, paramLayoutParams);
    this.j.e.onContentChanged();
  }
  
  public final void m(CharSequence paramCharSequence) {
    this.n = paramCharSequence;
    a1 a11 = this.o;
    if (a11 != null) {
      a11.setWindowTitle(paramCharSequence);
      return;
    } 
    a a2 = this.l;
    if (a2 != null) {
      a2.q(paramCharSequence);
      return;
    } 
    TextView textView = this.y;
    if (textView != null)
      textView.setText(paramCharSequence); 
  }
  
  public boolean n() {
    return o(true);
  }
  
  public final boolean o(boolean paramBoolean) {
    // Byte code:
    //   0: aload_0
    //   1: getfield O : Z
    //   4: istore #7
    //   6: iconst_0
    //   7: istore #4
    //   9: iload #7
    //   11: ifeq -> 16
    //   14: iconst_0
    //   15: ireturn
    //   16: aload_0
    //   17: getfield P : I
    //   20: istore_3
    //   21: iload_3
    //   22: bipush #-100
    //   24: if_icmpeq -> 30
    //   27: goto -> 33
    //   30: bipush #-100
    //   32: istore_3
    //   33: aload_0
    //   34: aload_0
    //   35: getfield h : Landroid/content/Context;
    //   38: iload_3
    //   39: invokevirtual G : (Landroid/content/Context;I)I
    //   42: istore_2
    //   43: aload_0
    //   44: getfield h : Landroid/content/Context;
    //   47: astore #9
    //   49: aconst_null
    //   50: astore #10
    //   52: aconst_null
    //   53: astore #11
    //   55: aload_0
    //   56: aload #9
    //   58: iload_2
    //   59: aconst_null
    //   60: invokevirtual t : (Landroid/content/Context;ILandroid/content/res/Configuration;)Landroid/content/res/Configuration;
    //   63: astore #9
    //   65: aload_0
    //   66: getfield S : Z
    //   69: istore #7
    //   71: iconst_1
    //   72: istore #8
    //   74: iload #7
    //   76: ifne -> 203
    //   79: aload_0
    //   80: getfield g : Ljava/lang/Object;
    //   83: instanceof android/app/Activity
    //   86: ifeq -> 203
    //   89: aload_0
    //   90: getfield h : Landroid/content/Context;
    //   93: invokevirtual getPackageManager : ()Landroid/content/pm/PackageManager;
    //   96: astore #12
    //   98: aload #12
    //   100: ifnonnull -> 109
    //   103: iconst_0
    //   104: istore #7
    //   106: goto -> 214
    //   109: getstatic android/os/Build$VERSION.SDK_INT : I
    //   112: istore_2
    //   113: iload_2
    //   114: bipush #29
    //   116: if_icmplt -> 1052
    //   119: ldc_w 269221888
    //   122: istore_2
    //   123: goto -> 126
    //   126: aload #12
    //   128: new android/content/ComponentName
    //   131: dup
    //   132: aload_0
    //   133: getfield h : Landroid/content/Context;
    //   136: aload_0
    //   137: getfield g : Ljava/lang/Object;
    //   140: invokevirtual getClass : ()Ljava/lang/Class;
    //   143: invokespecial <init> : (Landroid/content/Context;Ljava/lang/Class;)V
    //   146: iload_2
    //   147: invokevirtual getActivityInfo : (Landroid/content/ComponentName;I)Landroid/content/pm/ActivityInfo;
    //   150: astore #12
    //   152: aload #12
    //   154: ifnull -> 1070
    //   157: aload #12
    //   159: getfield configChanges : I
    //   162: sipush #512
    //   165: iand
    //   166: ifeq -> 1070
    //   169: iconst_1
    //   170: istore #7
    //   172: goto -> 175
    //   175: aload_0
    //   176: iload #7
    //   178: putfield R : Z
    //   181: goto -> 203
    //   184: astore #12
    //   186: ldc_w 'AppCompatDelegate'
    //   189: ldc_w 'Exception while getting ActivityInfo'
    //   192: aload #12
    //   194: invokestatic d : (Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)I
    //   197: pop
    //   198: aload_0
    //   199: iconst_0
    //   200: putfield R : Z
    //   203: aload_0
    //   204: iconst_1
    //   205: putfield S : Z
    //   208: aload_0
    //   209: getfield R : Z
    //   212: istore #7
    //   214: aload_0
    //   215: getfield h : Landroid/content/Context;
    //   218: invokevirtual getResources : ()Landroid/content/res/Resources;
    //   221: invokevirtual getConfiguration : ()Landroid/content/res/Configuration;
    //   224: getfield uiMode : I
    //   227: bipush #48
    //   229: iand
    //   230: istore_2
    //   231: aload #9
    //   233: getfield uiMode : I
    //   236: bipush #48
    //   238: iand
    //   239: istore #5
    //   241: iload_2
    //   242: iload #5
    //   244: if_icmpeq -> 388
    //   247: iload_1
    //   248: ifeq -> 388
    //   251: iload #7
    //   253: ifne -> 388
    //   256: aload_0
    //   257: getfield L : Z
    //   260: ifeq -> 388
    //   263: getstatic c/b/c/k0.e0 : Z
    //   266: ifne -> 276
    //   269: aload_0
    //   270: getfield M : Z
    //   273: ifeq -> 388
    //   276: aload_0
    //   277: getfield g : Ljava/lang/Object;
    //   280: astore #9
    //   282: aload #9
    //   284: instanceof android/app/Activity
    //   287: ifeq -> 388
    //   290: aload #9
    //   292: checkcast android/app/Activity
    //   295: invokevirtual isChild : ()Z
    //   298: ifne -> 388
    //   301: aload_0
    //   302: getfield g : Ljava/lang/Object;
    //   305: checkcast android/app/Activity
    //   308: astore #9
    //   310: getstatic c/h/b/b.a : Ljava/lang/Object;
    //   313: astore #12
    //   315: getstatic android/os/Build$VERSION.SDK_INT : I
    //   318: istore #6
    //   320: iload #6
    //   322: bipush #28
    //   324: if_icmplt -> 335
    //   327: aload #9
    //   329: invokevirtual recreate : ()V
    //   332: goto -> 383
    //   335: iload #6
    //   337: bipush #23
    //   339: if_icmpgt -> 370
    //   342: new android/os/Handler
    //   345: dup
    //   346: aload #9
    //   348: invokevirtual getMainLooper : ()Landroid/os/Looper;
    //   351: invokespecial <init> : (Landroid/os/Looper;)V
    //   354: new c/h/b/a
    //   357: dup
    //   358: aload #9
    //   360: invokespecial <init> : (Landroid/app/Activity;)V
    //   363: invokevirtual post : (Ljava/lang/Runnable;)Z
    //   366: pop
    //   367: goto -> 383
    //   370: aload #9
    //   372: invokestatic b : (Landroid/app/Activity;)Z
    //   375: ifne -> 383
    //   378: aload #9
    //   380: invokevirtual recreate : ()V
    //   383: iconst_1
    //   384: istore_1
    //   385: goto -> 390
    //   388: iconst_0
    //   389: istore_1
    //   390: iload_1
    //   391: ifne -> 933
    //   394: iload_2
    //   395: iload #5
    //   397: if_icmpeq -> 933
    //   400: aload_0
    //   401: getfield h : Landroid/content/Context;
    //   404: invokevirtual getResources : ()Landroid/content/res/Resources;
    //   407: astore #13
    //   409: new android/content/res/Configuration
    //   412: dup
    //   413: aload #13
    //   415: invokevirtual getConfiguration : ()Landroid/content/res/Configuration;
    //   418: invokespecial <init> : (Landroid/content/res/Configuration;)V
    //   421: astore #12
    //   423: aload #12
    //   425: iload #5
    //   427: aload #13
    //   429: invokevirtual getConfiguration : ()Landroid/content/res/Configuration;
    //   432: getfield uiMode : I
    //   435: bipush #-49
    //   437: iand
    //   438: ior
    //   439: putfield uiMode : I
    //   442: aload #13
    //   444: aload #12
    //   446: aconst_null
    //   447: invokevirtual updateConfiguration : (Landroid/content/res/Configuration;Landroid/util/DisplayMetrics;)V
    //   450: getstatic android/os/Build$VERSION.SDK_INT : I
    //   453: istore_2
    //   454: iload_2
    //   455: bipush #26
    //   457: if_icmpge -> 788
    //   460: iload_2
    //   461: bipush #28
    //   463: if_icmplt -> 469
    //   466: goto -> 788
    //   469: iload_2
    //   470: bipush #24
    //   472: if_icmplt -> 682
    //   475: getstatic c/b/a.h : Z
    //   478: ifne -> 524
    //   481: ldc_w android/content/res/Resources
    //   484: ldc_w 'mResourcesImpl'
    //   487: invokevirtual getDeclaredField : (Ljava/lang/String;)Ljava/lang/reflect/Field;
    //   490: astore #9
    //   492: aload #9
    //   494: putstatic c/b/a.g : Ljava/lang/reflect/Field;
    //   497: aload #9
    //   499: iconst_1
    //   500: invokevirtual setAccessible : (Z)V
    //   503: goto -> 520
    //   506: astore #9
    //   508: ldc_w 'ResourcesFlusher'
    //   511: ldc_w 'Could not retrieve Resources#mResourcesImpl field'
    //   514: aload #9
    //   516: invokestatic e : (Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)I
    //   519: pop
    //   520: iconst_1
    //   521: putstatic c/b/a.h : Z
    //   524: getstatic c/b/a.g : Ljava/lang/reflect/Field;
    //   527: astore #9
    //   529: aload #9
    //   531: ifnonnull -> 537
    //   534: goto -> 788
    //   537: aload #9
    //   539: aload #13
    //   541: invokevirtual get : (Ljava/lang/Object;)Ljava/lang/Object;
    //   544: astore #9
    //   546: goto -> 566
    //   549: astore #9
    //   551: ldc_w 'ResourcesFlusher'
    //   554: ldc_w 'Could not retrieve value from Resources#mResourcesImpl'
    //   557: aload #9
    //   559: invokestatic e : (Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)I
    //   562: pop
    //   563: aconst_null
    //   564: astore #9
    //   566: aload #9
    //   568: ifnonnull -> 574
    //   571: goto -> 788
    //   574: getstatic c/b/a.b : Z
    //   577: ifne -> 625
    //   580: aload #9
    //   582: invokevirtual getClass : ()Ljava/lang/Class;
    //   585: ldc_w 'mDrawableCache'
    //   588: invokevirtual getDeclaredField : (Ljava/lang/String;)Ljava/lang/reflect/Field;
    //   591: astore #10
    //   593: aload #10
    //   595: putstatic c/b/a.a : Ljava/lang/reflect/Field;
    //   598: aload #10
    //   600: iconst_1
    //   601: invokevirtual setAccessible : (Z)V
    //   604: goto -> 621
    //   607: astore #10
    //   609: ldc_w 'ResourcesFlusher'
    //   612: ldc_w 'Could not retrieve ResourcesImpl#mDrawableCache field'
    //   615: aload #10
    //   617: invokestatic e : (Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)I
    //   620: pop
    //   621: iconst_1
    //   622: putstatic c/b/a.b : Z
    //   625: getstatic c/b/a.a : Ljava/lang/reflect/Field;
    //   628: astore #13
    //   630: aload #11
    //   632: astore #10
    //   634: aload #13
    //   636: ifnull -> 669
    //   639: aload #13
    //   641: aload #9
    //   643: invokevirtual get : (Ljava/lang/Object;)Ljava/lang/Object;
    //   646: astore #10
    //   648: goto -> 669
    //   651: astore #9
    //   653: ldc_w 'ResourcesFlusher'
    //   656: ldc_w 'Could not retrieve value from ResourcesImpl#mDrawableCache'
    //   659: aload #9
    //   661: invokestatic e : (Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)I
    //   664: pop
    //   665: aload #11
    //   667: astore #10
    //   669: aload #10
    //   671: ifnull -> 788
    //   674: aload #10
    //   676: invokestatic d : (Ljava/lang/Object;)V
    //   679: goto -> 788
    //   682: getstatic c/b/a.b : Z
    //   685: ifne -> 731
    //   688: ldc_w android/content/res/Resources
    //   691: ldc_w 'mDrawableCache'
    //   694: invokevirtual getDeclaredField : (Ljava/lang/String;)Ljava/lang/reflect/Field;
    //   697: astore #9
    //   699: aload #9
    //   701: putstatic c/b/a.a : Ljava/lang/reflect/Field;
    //   704: aload #9
    //   706: iconst_1
    //   707: invokevirtual setAccessible : (Z)V
    //   710: goto -> 727
    //   713: astore #9
    //   715: ldc_w 'ResourcesFlusher'
    //   718: ldc_w 'Could not retrieve Resources#mDrawableCache field'
    //   721: aload #9
    //   723: invokestatic e : (Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)I
    //   726: pop
    //   727: iconst_1
    //   728: putstatic c/b/a.b : Z
    //   731: getstatic c/b/a.a : Ljava/lang/reflect/Field;
    //   734: astore #11
    //   736: aload #10
    //   738: astore #9
    //   740: aload #11
    //   742: ifnull -> 775
    //   745: aload #11
    //   747: aload #13
    //   749: invokevirtual get : (Ljava/lang/Object;)Ljava/lang/Object;
    //   752: astore #9
    //   754: goto -> 775
    //   757: astore #9
    //   759: ldc_w 'ResourcesFlusher'
    //   762: ldc_w 'Could not retrieve value from Resources#mDrawableCache'
    //   765: aload #9
    //   767: invokestatic e : (Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)I
    //   770: pop
    //   771: aload #10
    //   773: astore #9
    //   775: aload #9
    //   777: ifnonnull -> 783
    //   780: goto -> 788
    //   783: aload #9
    //   785: invokestatic d : (Ljava/lang/Object;)V
    //   788: aload_0
    //   789: getfield Q : I
    //   792: istore_2
    //   793: iload_2
    //   794: ifeq -> 820
    //   797: aload_0
    //   798: getfield h : Landroid/content/Context;
    //   801: iload_2
    //   802: invokevirtual setTheme : (I)V
    //   805: aload_0
    //   806: getfield h : Landroid/content/Context;
    //   809: invokevirtual getTheme : ()Landroid/content/res/Resources$Theme;
    //   812: aload_0
    //   813: getfield Q : I
    //   816: iconst_1
    //   817: invokevirtual applyStyle : (IZ)V
    //   820: iload #8
    //   822: istore_1
    //   823: iload #7
    //   825: ifeq -> 933
    //   828: aload_0
    //   829: getfield g : Ljava/lang/Object;
    //   832: astore #9
    //   834: iload #8
    //   836: istore_1
    //   837: aload #9
    //   839: instanceof android/app/Activity
    //   842: ifeq -> 933
    //   845: aload #9
    //   847: checkcast android/app/Activity
    //   850: astore #9
    //   852: aload #9
    //   854: instanceof c/p/h
    //   857: ifeq -> 910
    //   860: iload #4
    //   862: istore_2
    //   863: aload #9
    //   865: checkcast c/p/h
    //   868: invokeinterface l : ()Lc/p/e;
    //   873: checkcast c/p/j
    //   876: getfield b : Lc/p/e$b;
    //   879: getstatic c/p/e$b.h : Lc/p/e$b;
    //   882: invokevirtual compareTo : (Ljava/lang/Enum;)I
    //   885: iflt -> 890
    //   888: iconst_1
    //   889: istore_2
    //   890: iload #8
    //   892: istore_1
    //   893: iload_2
    //   894: ifeq -> 933
    //   897: aload #9
    //   899: aload #12
    //   901: invokevirtual onConfigurationChanged : (Landroid/content/res/Configuration;)V
    //   904: iload #8
    //   906: istore_1
    //   907: goto -> 933
    //   910: iload #8
    //   912: istore_1
    //   913: aload_0
    //   914: getfield N : Z
    //   917: ifeq -> 933
    //   920: aload #9
    //   922: aload #12
    //   924: invokevirtual onConfigurationChanged : (Landroid/content/res/Configuration;)V
    //   927: iload #8
    //   929: istore_1
    //   930: goto -> 933
    //   933: iload_1
    //   934: ifeq -> 959
    //   937: aload_0
    //   938: getfield g : Ljava/lang/Object;
    //   941: astore #9
    //   943: aload #9
    //   945: instanceof c/b/c/p
    //   948: ifeq -> 959
    //   951: aload #9
    //   953: checkcast c/b/c/p
    //   956: invokevirtual v : ()V
    //   959: iload_3
    //   960: ifne -> 977
    //   963: aload_0
    //   964: aload_0
    //   965: getfield h : Landroid/content/Context;
    //   968: invokevirtual B : (Landroid/content/Context;)Lc/b/c/f0;
    //   971: invokevirtual e : ()V
    //   974: goto -> 993
    //   977: aload_0
    //   978: getfield T : Lc/b/c/f0;
    //   981: astore #9
    //   983: aload #9
    //   985: ifnull -> 993
    //   988: aload #9
    //   990: invokevirtual a : ()V
    //   993: iload_3
    //   994: iconst_3
    //   995: if_icmpne -> 1034
    //   998: aload_0
    //   999: getfield h : Landroid/content/Context;
    //   1002: astore #9
    //   1004: aload_0
    //   1005: getfield U : Lc/b/c/f0;
    //   1008: ifnonnull -> 1025
    //   1011: aload_0
    //   1012: new c/b/c/d0
    //   1015: dup
    //   1016: aload_0
    //   1017: aload #9
    //   1019: invokespecial <init> : (Lc/b/c/k0;Landroid/content/Context;)V
    //   1022: putfield U : Lc/b/c/f0;
    //   1025: aload_0
    //   1026: getfield U : Lc/b/c/f0;
    //   1029: invokevirtual e : ()V
    //   1032: iload_1
    //   1033: ireturn
    //   1034: aload_0
    //   1035: getfield U : Lc/b/c/f0;
    //   1038: astore #9
    //   1040: aload #9
    //   1042: ifnull -> 1050
    //   1045: aload #9
    //   1047: invokevirtual a : ()V
    //   1050: iload_1
    //   1051: ireturn
    //   1052: iload_2
    //   1053: bipush #24
    //   1055: if_icmplt -> 1065
    //   1058: ldc_w 786432
    //   1061: istore_2
    //   1062: goto -> 126
    //   1065: iconst_0
    //   1066: istore_2
    //   1067: goto -> 126
    //   1070: iconst_0
    //   1071: istore #7
    //   1073: goto -> 175
    // Exception table:
    //   from	to	target	type
    //   109	113	184	android/content/pm/PackageManager$NameNotFoundException
    //   126	152	184	android/content/pm/PackageManager$NameNotFoundException
    //   157	169	184	android/content/pm/PackageManager$NameNotFoundException
    //   175	181	184	android/content/pm/PackageManager$NameNotFoundException
    //   481	503	506	java/lang/NoSuchFieldException
    //   537	546	549	java/lang/IllegalAccessException
    //   580	604	607	java/lang/NoSuchFieldException
    //   639	648	651	java/lang/IllegalAccessException
    //   688	710	713	java/lang/NoSuchFieldException
    //   745	754	757	java/lang/IllegalAccessException
  }
  
  public final View onCreateView(View paramView, String paramString, Context paramContext, AttributeSet paramAttributeSet) {
    // Byte code:
    //   0: aload_0
    //   1: getfield b0 : Lc/b/c/n0;
    //   4: ifnonnull -> 130
    //   7: aload_0
    //   8: getfield h : Landroid/content/Context;
    //   11: getstatic c/b/b.j : [I
    //   14: invokevirtual obtainStyledAttributes : ([I)Landroid/content/res/TypedArray;
    //   17: bipush #114
    //   19: invokevirtual getString : (I)Ljava/lang/String;
    //   22: astore_1
    //   23: aload_1
    //   24: ifnonnull -> 41
    //   27: aload_0
    //   28: new c/b/c/n0
    //   31: dup
    //   32: invokespecial <init> : ()V
    //   35: putfield b0 : Lc/b/c/n0;
    //   38: goto -> 130
    //   41: aload_0
    //   42: aload_1
    //   43: invokestatic forName : (Ljava/lang/String;)Ljava/lang/Class;
    //   46: iconst_0
    //   47: anewarray java/lang/Class
    //   50: invokevirtual getDeclaredConstructor : ([Ljava/lang/Class;)Ljava/lang/reflect/Constructor;
    //   53: iconst_0
    //   54: anewarray java/lang/Object
    //   57: invokevirtual newInstance : ([Ljava/lang/Object;)Ljava/lang/Object;
    //   60: checkcast c/b/c/n0
    //   63: putfield b0 : Lc/b/c/n0;
    //   66: goto -> 130
    //   69: astore #8
    //   71: new java/lang/StringBuilder
    //   74: dup
    //   75: invokespecial <init> : ()V
    //   78: astore #9
    //   80: aload #9
    //   82: ldc_w 'Failed to instantiate custom view inflater '
    //   85: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   88: pop
    //   89: aload #9
    //   91: aload_1
    //   92: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   95: pop
    //   96: aload #9
    //   98: ldc_w '. Falling back to default.'
    //   101: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   104: pop
    //   105: ldc_w 'AppCompatDelegate'
    //   108: aload #9
    //   110: invokevirtual toString : ()Ljava/lang/String;
    //   113: aload #8
    //   115: invokestatic i : (Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)I
    //   118: pop
    //   119: aload_0
    //   120: new c/b/c/n0
    //   123: dup
    //   124: invokespecial <init> : ()V
    //   127: putfield b0 : Lc/b/c/n0;
    //   130: aload_0
    //   131: getfield b0 : Lc/b/c/n0;
    //   134: astore #10
    //   136: getstatic c/b/h/s2.a : I
    //   139: istore #5
    //   141: aload #10
    //   143: invokestatic requireNonNull : (Ljava/lang/Object;)Ljava/lang/Object;
    //   146: pop
    //   147: aload_3
    //   148: aload #4
    //   150: getstatic c/b/b.z : [I
    //   153: iconst_0
    //   154: iconst_0
    //   155: invokevirtual obtainStyledAttributes : (Landroid/util/AttributeSet;[III)Landroid/content/res/TypedArray;
    //   158: astore_1
    //   159: iconst_4
    //   160: istore #5
    //   162: aload_1
    //   163: iconst_4
    //   164: iconst_0
    //   165: invokevirtual getResourceId : (II)I
    //   168: istore #6
    //   170: iload #6
    //   172: ifeq -> 185
    //   175: ldc_w 'AppCompatViewInflater'
    //   178: ldc_w 'app:theme is now deprecated. Please move to using android:theme instead.'
    //   181: invokestatic i : (Ljava/lang/String;Ljava/lang/String;)I
    //   184: pop
    //   185: aload_1
    //   186: invokevirtual recycle : ()V
    //   189: iload #6
    //   191: ifeq -> 228
    //   194: aload_3
    //   195: instanceof c/b/g/d
    //   198: ifeq -> 213
    //   201: aload_3
    //   202: checkcast c/b/g/d
    //   205: getfield a : I
    //   208: iload #6
    //   210: if_icmpeq -> 228
    //   213: new c/b/g/d
    //   216: dup
    //   217: aload_3
    //   218: iload #6
    //   220: invokespecial <init> : (Landroid/content/Context;I)V
    //   223: astore #9
    //   225: goto -> 231
    //   228: aload_3
    //   229: astore #9
    //   231: aload_2
    //   232: invokevirtual hashCode : ()I
    //   235: pop
    //   236: aload_2
    //   237: invokevirtual hashCode : ()I
    //   240: lookupswitch default -> 364, -1946472170 -> 619, -1455429095 -> 600, -1346021293 -> 581, -938935918 -> 562, -937446323 -> 549, -658531749 -> 530, -339785223 -> 510, 776382189 -> 490, 799298502 -> 470, 1125864064 -> 450, 1413872058 -> 430, 1601505219 -> 410, 1666676343 -> 390, 2001146706 -> 370
    //   364: iconst_m1
    //   365: istore #5
    //   367: goto -> 635
    //   370: aload_2
    //   371: ldc_w 'Button'
    //   374: invokevirtual equals : (Ljava/lang/Object;)Z
    //   377: ifne -> 383
    //   380: goto -> 364
    //   383: bipush #13
    //   385: istore #5
    //   387: goto -> 635
    //   390: aload_2
    //   391: ldc_w 'EditText'
    //   394: invokevirtual equals : (Ljava/lang/Object;)Z
    //   397: ifne -> 403
    //   400: goto -> 364
    //   403: bipush #12
    //   405: istore #5
    //   407: goto -> 635
    //   410: aload_2
    //   411: ldc_w 'CheckBox'
    //   414: invokevirtual equals : (Ljava/lang/Object;)Z
    //   417: ifne -> 423
    //   420: goto -> 364
    //   423: bipush #11
    //   425: istore #5
    //   427: goto -> 635
    //   430: aload_2
    //   431: ldc_w 'AutoCompleteTextView'
    //   434: invokevirtual equals : (Ljava/lang/Object;)Z
    //   437: ifne -> 443
    //   440: goto -> 364
    //   443: bipush #10
    //   445: istore #5
    //   447: goto -> 635
    //   450: aload_2
    //   451: ldc_w 'ImageView'
    //   454: invokevirtual equals : (Ljava/lang/Object;)Z
    //   457: ifne -> 463
    //   460: goto -> 364
    //   463: bipush #9
    //   465: istore #5
    //   467: goto -> 635
    //   470: aload_2
    //   471: ldc_w 'ToggleButton'
    //   474: invokevirtual equals : (Ljava/lang/Object;)Z
    //   477: ifne -> 483
    //   480: goto -> 364
    //   483: bipush #8
    //   485: istore #5
    //   487: goto -> 635
    //   490: aload_2
    //   491: ldc_w 'RadioButton'
    //   494: invokevirtual equals : (Ljava/lang/Object;)Z
    //   497: ifne -> 503
    //   500: goto -> 364
    //   503: bipush #7
    //   505: istore #5
    //   507: goto -> 635
    //   510: aload_2
    //   511: ldc_w 'Spinner'
    //   514: invokevirtual equals : (Ljava/lang/Object;)Z
    //   517: ifne -> 523
    //   520: goto -> 364
    //   523: bipush #6
    //   525: istore #5
    //   527: goto -> 635
    //   530: aload_2
    //   531: ldc_w 'SeekBar'
    //   534: invokevirtual equals : (Ljava/lang/Object;)Z
    //   537: ifne -> 543
    //   540: goto -> 364
    //   543: iconst_5
    //   544: istore #5
    //   546: goto -> 635
    //   549: aload_2
    //   550: ldc_w 'ImageButton'
    //   553: invokevirtual equals : (Ljava/lang/Object;)Z
    //   556: ifne -> 635
    //   559: goto -> 364
    //   562: aload_2
    //   563: ldc_w 'TextView'
    //   566: invokevirtual equals : (Ljava/lang/Object;)Z
    //   569: ifne -> 575
    //   572: goto -> 364
    //   575: iconst_3
    //   576: istore #5
    //   578: goto -> 635
    //   581: aload_2
    //   582: ldc_w 'MultiAutoCompleteTextView'
    //   585: invokevirtual equals : (Ljava/lang/Object;)Z
    //   588: ifne -> 594
    //   591: goto -> 364
    //   594: iconst_2
    //   595: istore #5
    //   597: goto -> 635
    //   600: aload_2
    //   601: ldc_w 'CheckedTextView'
    //   604: invokevirtual equals : (Ljava/lang/Object;)Z
    //   607: ifne -> 613
    //   610: goto -> 364
    //   613: iconst_1
    //   614: istore #5
    //   616: goto -> 635
    //   619: aload_2
    //   620: ldc_w 'RatingBar'
    //   623: invokevirtual equals : (Ljava/lang/Object;)Z
    //   626: ifne -> 632
    //   629: goto -> 364
    //   632: iconst_0
    //   633: istore #5
    //   635: iload #5
    //   637: tableswitch default -> 708, 0 -> 999, 1 -> 977, 2 -> 955, 3 -> 935, 4 -> 910, 5 -> 888, 6 -> 866, 7 -> 846, 8 -> 824, 9 -> 802, 10 -> 782, 11 -> 762, 12 -> 737, 13 -> 717
    //   708: aload #10
    //   710: invokevirtual f : ()Landroid/view/View;
    //   713: astore_1
    //   714: goto -> 1018
    //   717: aload #10
    //   719: aload #9
    //   721: aload #4
    //   723: invokevirtual b : (Landroid/content/Context;Landroid/util/AttributeSet;)Lc/b/h/p;
    //   726: astore_1
    //   727: aload #10
    //   729: aload_1
    //   730: aload_2
    //   731: invokevirtual h : (Landroid/view/View;Ljava/lang/String;)V
    //   734: goto -> 1018
    //   737: new c/b/h/v
    //   740: dup
    //   741: aload #9
    //   743: aload #4
    //   745: ldc_w 2130903338
    //   748: invokespecial <init> : (Landroid/content/Context;Landroid/util/AttributeSet;I)V
    //   751: astore_1
    //   752: aload #10
    //   754: aload_1
    //   755: aload_2
    //   756: invokevirtual h : (Landroid/view/View;Ljava/lang/String;)V
    //   759: goto -> 1018
    //   762: aload #10
    //   764: aload #9
    //   766: aload #4
    //   768: invokevirtual c : (Landroid/content/Context;Landroid/util/AttributeSet;)Lc/b/h/q;
    //   771: astore_1
    //   772: aload #10
    //   774: aload_1
    //   775: aload_2
    //   776: invokevirtual h : (Landroid/view/View;Ljava/lang/String;)V
    //   779: goto -> 1018
    //   782: aload #10
    //   784: aload #9
    //   786: aload #4
    //   788: invokevirtual a : (Landroid/content/Context;Landroid/util/AttributeSet;)Lc/b/h/n;
    //   791: astore_1
    //   792: aload #10
    //   794: aload_1
    //   795: aload_2
    //   796: invokevirtual h : (Landroid/view/View;Ljava/lang/String;)V
    //   799: goto -> 1018
    //   802: new androidx/appcompat/widget/AppCompatImageView
    //   805: dup
    //   806: aload #9
    //   808: aload #4
    //   810: invokespecial <init> : (Landroid/content/Context;Landroid/util/AttributeSet;)V
    //   813: astore_1
    //   814: aload #10
    //   816: aload_1
    //   817: aload_2
    //   818: invokevirtual h : (Landroid/view/View;Ljava/lang/String;)V
    //   821: goto -> 1018
    //   824: new c/b/h/z0
    //   827: dup
    //   828: aload #9
    //   830: aload #4
    //   832: invokespecial <init> : (Landroid/content/Context;Landroid/util/AttributeSet;)V
    //   835: astore_1
    //   836: aload #10
    //   838: aload_1
    //   839: aload_2
    //   840: invokevirtual h : (Landroid/view/View;Ljava/lang/String;)V
    //   843: goto -> 1018
    //   846: aload #10
    //   848: aload #9
    //   850: aload #4
    //   852: invokevirtual d : (Landroid/content/Context;Landroid/util/AttributeSet;)Lc/b/h/b0;
    //   855: astore_1
    //   856: aload #10
    //   858: aload_1
    //   859: aload_2
    //   860: invokevirtual h : (Landroid/view/View;Ljava/lang/String;)V
    //   863: goto -> 1018
    //   866: new c/b/h/q0
    //   869: dup
    //   870: aload #9
    //   872: aload #4
    //   874: invokespecial <init> : (Landroid/content/Context;Landroid/util/AttributeSet;)V
    //   877: astore_1
    //   878: aload #10
    //   880: aload_1
    //   881: aload_2
    //   882: invokevirtual h : (Landroid/view/View;Ljava/lang/String;)V
    //   885: goto -> 1018
    //   888: new c/b/h/d0
    //   891: dup
    //   892: aload #9
    //   894: aload #4
    //   896: invokespecial <init> : (Landroid/content/Context;Landroid/util/AttributeSet;)V
    //   899: astore_1
    //   900: aload #10
    //   902: aload_1
    //   903: aload_2
    //   904: invokevirtual h : (Landroid/view/View;Ljava/lang/String;)V
    //   907: goto -> 1018
    //   910: new c/b/h/w
    //   913: dup
    //   914: aload #9
    //   916: aload #4
    //   918: ldc_w 2130903451
    //   921: invokespecial <init> : (Landroid/content/Context;Landroid/util/AttributeSet;I)V
    //   924: astore_1
    //   925: aload #10
    //   927: aload_1
    //   928: aload_2
    //   929: invokevirtual h : (Landroid/view/View;Ljava/lang/String;)V
    //   932: goto -> 1018
    //   935: aload #10
    //   937: aload #9
    //   939: aload #4
    //   941: invokevirtual e : (Landroid/content/Context;Landroid/util/AttributeSet;)Lc/b/h/u0;
    //   944: astore_1
    //   945: aload #10
    //   947: aload_1
    //   948: aload_2
    //   949: invokevirtual h : (Landroid/view/View;Ljava/lang/String;)V
    //   952: goto -> 1018
    //   955: new c/b/h/y
    //   958: dup
    //   959: aload #9
    //   961: aload #4
    //   963: invokespecial <init> : (Landroid/content/Context;Landroid/util/AttributeSet;)V
    //   966: astore_1
    //   967: aload #10
    //   969: aload_1
    //   970: aload_2
    //   971: invokevirtual h : (Landroid/view/View;Ljava/lang/String;)V
    //   974: goto -> 1018
    //   977: new c/b/h/r
    //   980: dup
    //   981: aload #9
    //   983: aload #4
    //   985: invokespecial <init> : (Landroid/content/Context;Landroid/util/AttributeSet;)V
    //   988: astore_1
    //   989: aload #10
    //   991: aload_1
    //   992: aload_2
    //   993: invokevirtual h : (Landroid/view/View;Ljava/lang/String;)V
    //   996: goto -> 1018
    //   999: new c/b/h/c0
    //   1002: dup
    //   1003: aload #9
    //   1005: aload #4
    //   1007: invokespecial <init> : (Landroid/content/Context;Landroid/util/AttributeSet;)V
    //   1010: astore_1
    //   1011: aload #10
    //   1013: aload_1
    //   1014: aload_2
    //   1015: invokevirtual h : (Landroid/view/View;Ljava/lang/String;)V
    //   1018: aload_1
    //   1019: astore #8
    //   1021: aload_1
    //   1022: ifnonnull -> 1227
    //   1025: aload_1
    //   1026: astore #8
    //   1028: aload_3
    //   1029: aload #9
    //   1031: if_acmpeq -> 1227
    //   1034: aload_2
    //   1035: ldc_w 'view'
    //   1038: invokevirtual equals : (Ljava/lang/Object;)Z
    //   1041: istore #7
    //   1043: aconst_null
    //   1044: astore #8
    //   1046: iload #7
    //   1048: ifeq -> 1063
    //   1051: aload #4
    //   1053: aconst_null
    //   1054: ldc_w 'class'
    //   1057: invokeinterface getAttributeValue : (Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;
    //   1062: astore_2
    //   1063: aload #10
    //   1065: getfield a : [Ljava/lang/Object;
    //   1068: astore_1
    //   1069: aload_1
    //   1070: iconst_0
    //   1071: aload #9
    //   1073: aastore
    //   1074: aload_1
    //   1075: iconst_1
    //   1076: aload #4
    //   1078: aastore
    //   1079: iconst_m1
    //   1080: aload_2
    //   1081: bipush #46
    //   1083: invokevirtual indexOf : (I)I
    //   1086: if_icmpne -> 1166
    //   1089: iconst_0
    //   1090: istore #5
    //   1092: getstatic c/b/c/n0.d : [Ljava/lang/String;
    //   1095: astore_1
    //   1096: iload #5
    //   1098: aload_1
    //   1099: arraylength
    //   1100: if_icmpge -> 1149
    //   1103: aload #10
    //   1105: aload #9
    //   1107: aload_2
    //   1108: aload_1
    //   1109: iload #5
    //   1111: aaload
    //   1112: invokevirtual g : (Landroid/content/Context;Ljava/lang/String;Ljava/lang/String;)Landroid/view/View;
    //   1115: astore_1
    //   1116: aload_1
    //   1117: ifnull -> 1140
    //   1120: aload #10
    //   1122: getfield a : [Ljava/lang/Object;
    //   1125: astore_2
    //   1126: aload_2
    //   1127: iconst_0
    //   1128: aconst_null
    //   1129: aastore
    //   1130: aload_2
    //   1131: iconst_1
    //   1132: aconst_null
    //   1133: aastore
    //   1134: aload_1
    //   1135: astore #8
    //   1137: goto -> 1227
    //   1140: iload #5
    //   1142: iconst_1
    //   1143: iadd
    //   1144: istore #5
    //   1146: goto -> 1092
    //   1149: aload #10
    //   1151: getfield a : [Ljava/lang/Object;
    //   1154: astore_1
    //   1155: aload_1
    //   1156: iconst_0
    //   1157: aconst_null
    //   1158: aastore
    //   1159: aload_1
    //   1160: iconst_1
    //   1161: aconst_null
    //   1162: aastore
    //   1163: goto -> 1227
    //   1166: aload #10
    //   1168: aload #9
    //   1170: aload_2
    //   1171: aconst_null
    //   1172: invokevirtual g : (Landroid/content/Context;Ljava/lang/String;Ljava/lang/String;)Landroid/view/View;
    //   1175: astore_1
    //   1176: aload #10
    //   1178: getfield a : [Ljava/lang/Object;
    //   1181: astore_2
    //   1182: aload_2
    //   1183: iconst_0
    //   1184: aconst_null
    //   1185: aastore
    //   1186: aload_2
    //   1187: iconst_1
    //   1188: aconst_null
    //   1189: aastore
    //   1190: aload_1
    //   1191: astore #8
    //   1193: goto -> 1227
    //   1196: astore_1
    //   1197: aload #10
    //   1199: getfield a : [Ljava/lang/Object;
    //   1202: astore_2
    //   1203: aload_2
    //   1204: iconst_0
    //   1205: aconst_null
    //   1206: aastore
    //   1207: aload_2
    //   1208: iconst_1
    //   1209: aconst_null
    //   1210: aastore
    //   1211: aload_1
    //   1212: athrow
    //   1213: aload #10
    //   1215: getfield a : [Ljava/lang/Object;
    //   1218: astore_1
    //   1219: aload_1
    //   1220: iconst_0
    //   1221: aconst_null
    //   1222: aastore
    //   1223: aload_1
    //   1224: iconst_1
    //   1225: aconst_null
    //   1226: aastore
    //   1227: aload #8
    //   1229: ifnull -> 1299
    //   1232: aload #8
    //   1234: invokevirtual getContext : ()Landroid/content/Context;
    //   1237: astore_1
    //   1238: aload_1
    //   1239: instanceof android/content/ContextWrapper
    //   1242: ifeq -> 1299
    //   1245: getstatic c/h/j/u.a : Ljava/util/concurrent/atomic/AtomicInteger;
    //   1248: astore_2
    //   1249: aload #8
    //   1251: invokevirtual hasOnClickListeners : ()Z
    //   1254: ifne -> 1260
    //   1257: aload #8
    //   1259: areturn
    //   1260: aload_1
    //   1261: aload #4
    //   1263: getstatic c/b/c/n0.c : [I
    //   1266: invokevirtual obtainStyledAttributes : (Landroid/util/AttributeSet;[I)Landroid/content/res/TypedArray;
    //   1269: astore_1
    //   1270: aload_1
    //   1271: iconst_0
    //   1272: invokevirtual getString : (I)Ljava/lang/String;
    //   1275: astore_2
    //   1276: aload_2
    //   1277: ifnull -> 1295
    //   1280: aload #8
    //   1282: new c/b/c/m0
    //   1285: dup
    //   1286: aload #8
    //   1288: aload_2
    //   1289: invokespecial <init> : (Landroid/view/View;Ljava/lang/String;)V
    //   1292: invokevirtual setOnClickListener : (Landroid/view/View$OnClickListener;)V
    //   1295: aload_1
    //   1296: invokevirtual recycle : ()V
    //   1299: aload #8
    //   1301: areturn
    //   1302: astore_1
    //   1303: goto -> 1213
    // Exception table:
    //   from	to	target	type
    //   41	66	69	finally
    //   1063	1069	1302	java/lang/Exception
    //   1063	1069	1196	finally
    //   1079	1089	1302	java/lang/Exception
    //   1079	1089	1196	finally
    //   1092	1116	1302	java/lang/Exception
    //   1092	1116	1196	finally
    //   1166	1176	1302	java/lang/Exception
    //   1166	1176	1196	finally
  }
  
  public View onCreateView(String paramString, Context paramContext, AttributeSet paramAttributeSet) {
    return onCreateView(null, paramString, paramContext, paramAttributeSet);
  }
  
  public final void p(Window paramWindow) {
    if (this.i == null) {
      Window.Callback callback = paramWindow.getCallback();
      if (!(callback instanceof c0)) {
        c0 c01 = new c0(this, callback);
        this.j = c01;
        paramWindow.setCallback((Window.Callback)c01);
        j2 j2 = j2.p(this.h, null, d0);
        Drawable drawable = j2.h(0);
        if (drawable != null)
          paramWindow.setBackgroundDrawable(drawable); 
        j2.b.recycle();
        this.i = paramWindow;
        return;
      } 
      throw new IllegalStateException("AppCompat has already installed itself into the Window");
    } 
    throw new IllegalStateException("AppCompat has already installed itself into the Window");
  }
  
  public void q(int paramInt, i0 parami0, Menu paramMenu) {
    l l;
    Menu menu = paramMenu;
    if (paramMenu == null) {
      menu = paramMenu;
      if (parami0 != null)
        l = parami0.h; 
    } 
    if (parami0 != null && !parami0.m)
      return; 
    if (!this.O)
      this.j.e.onPanelClosed(paramInt, (Menu)l); 
  }
  
  public void r(l paraml) {
    if (this.H)
      return; 
    this.H = true;
    ActionBarOverlayLayout actionBarOverlayLayout = (ActionBarOverlayLayout)this.o;
    actionBarOverlayLayout.m();
    ActionMenuView actionMenuView = ((n2)actionBarOverlayLayout.i).a.e;
    if (actionMenuView != null) {
      m m = actionMenuView.x;
      if (m != null)
        m.b(); 
    } 
    Window.Callback callback = D();
    if (callback != null && !this.O)
      callback.onPanelClosed(108, (Menu)paraml); 
    this.H = false;
  }
  
  public void s(i0 parami0, boolean paramBoolean) {
    if (paramBoolean && parami0.a == 0) {
      a1 a11 = this.o;
      if (a11 != null && ((ActionBarOverlayLayout)a11).l()) {
        r(parami0.h);
        return;
      } 
    } 
    WindowManager windowManager = (WindowManager)this.h.getSystemService("window");
    if (windowManager != null && parami0.m) {
      ViewGroup viewGroup = parami0.e;
      if (viewGroup != null) {
        windowManager.removeView((View)viewGroup);
        if (paramBoolean)
          q(parami0.a, parami0, null); 
      } 
    } 
    parami0.k = false;
    parami0.l = false;
    parami0.m = false;
    parami0.f = null;
    parami0.o = true;
    if (this.J == parami0)
      this.J = null; 
  }
  
  public final Configuration t(Context paramContext, int paramInt, Configuration paramConfiguration) {
    if (paramInt != 1) {
      if (paramInt != 2) {
        paramInt = (paramContext.getApplicationContext().getResources().getConfiguration()).uiMode & 0x30;
      } else {
        paramInt = 32;
      } 
    } else {
      paramInt = 16;
    } 
    Configuration configuration = new Configuration();
    configuration.fontScale = 0.0F;
    if (paramConfiguration != null)
      configuration.setTo(paramConfiguration); 
    configuration.uiMode = paramInt | configuration.uiMode & 0xFFFFFFCF;
    return configuration;
  }
  
  public boolean u(KeyEvent paramKeyEvent) {
    // Byte code:
    //   0: aload_0
    //   1: getfield g : Ljava/lang/Object;
    //   4: astore #6
    //   6: aload #6
    //   8: instanceof c/h/j/d
    //   11: istore #5
    //   13: iconst_1
    //   14: istore #4
    //   16: iload #5
    //   18: ifne -> 29
    //   21: aload #6
    //   23: instanceof c/b/c/o
    //   26: ifeq -> 54
    //   29: aload_0
    //   30: getfield i : Landroid/view/Window;
    //   33: invokevirtual getDecorView : ()Landroid/view/View;
    //   36: astore #6
    //   38: aload #6
    //   40: ifnull -> 54
    //   43: aload #6
    //   45: aload_1
    //   46: invokestatic a : (Landroid/view/View;Landroid/view/KeyEvent;)Z
    //   49: ifeq -> 54
    //   52: iconst_1
    //   53: ireturn
    //   54: aload_1
    //   55: invokevirtual getKeyCode : ()I
    //   58: bipush #82
    //   60: if_icmpne -> 81
    //   63: aload_0
    //   64: getfield j : Lc/b/c/c0;
    //   67: getfield e : Landroid/view/Window$Callback;
    //   70: aload_1
    //   71: invokeinterface dispatchKeyEvent : (Landroid/view/KeyEvent;)Z
    //   76: ifeq -> 81
    //   79: iconst_1
    //   80: ireturn
    //   81: aload_1
    //   82: invokevirtual getKeyCode : ()I
    //   85: istore_3
    //   86: aload_1
    //   87: invokevirtual getAction : ()I
    //   90: ifne -> 98
    //   93: iconst_1
    //   94: istore_2
    //   95: goto -> 100
    //   98: iconst_0
    //   99: istore_2
    //   100: iload_2
    //   101: ifeq -> 175
    //   104: iload_3
    //   105: iconst_4
    //   106: if_icmpeq -> 150
    //   109: iload_3
    //   110: bipush #82
    //   112: if_icmpeq -> 118
    //   115: goto -> 173
    //   118: aload_1
    //   119: invokevirtual getRepeatCount : ()I
    //   122: ifne -> 547
    //   125: aload_0
    //   126: iconst_0
    //   127: invokevirtual C : (I)Lc/b/c/i0;
    //   130: astore #6
    //   132: aload #6
    //   134: getfield m : Z
    //   137: ifne -> 547
    //   140: aload_0
    //   141: aload #6
    //   143: aload_1
    //   144: invokevirtual J : (Lc/b/c/i0;Landroid/view/KeyEvent;)Z
    //   147: pop
    //   148: iconst_1
    //   149: ireturn
    //   150: aload_1
    //   151: invokevirtual getFlags : ()I
    //   154: sipush #128
    //   157: iand
    //   158: ifeq -> 164
    //   161: goto -> 167
    //   164: iconst_0
    //   165: istore #4
    //   167: aload_0
    //   168: iload #4
    //   170: putfield K : Z
    //   173: iconst_0
    //   174: ireturn
    //   175: iload_3
    //   176: iconst_4
    //   177: if_icmpeq -> 463
    //   180: iload_3
    //   181: bipush #82
    //   183: if_icmpeq -> 189
    //   186: goto -> 173
    //   189: aload_0
    //   190: getfield r : Lc/b/g/b;
    //   193: ifnull -> 198
    //   196: iconst_1
    //   197: ireturn
    //   198: aload_0
    //   199: iconst_0
    //   200: invokevirtual C : (I)Lc/b/c/i0;
    //   203: astore #6
    //   205: aload_0
    //   206: getfield o : Lc/b/h/a1;
    //   209: astore #7
    //   211: aload #7
    //   213: ifnull -> 327
    //   216: aload #7
    //   218: checkcast androidx/appcompat/widget/ActionBarOverlayLayout
    //   221: invokevirtual h : ()Z
    //   224: ifeq -> 327
    //   227: aload_0
    //   228: getfield h : Landroid/content/Context;
    //   231: invokestatic get : (Landroid/content/Context;)Landroid/view/ViewConfiguration;
    //   234: invokevirtual hasPermanentMenuKey : ()Z
    //   237: ifne -> 327
    //   240: aload_0
    //   241: getfield o : Lc/b/h/a1;
    //   244: checkcast androidx/appcompat/widget/ActionBarOverlayLayout
    //   247: invokevirtual l : ()Z
    //   250: ifne -> 300
    //   253: aload_0
    //   254: getfield O : Z
    //   257: ifne -> 405
    //   260: aload_0
    //   261: aload #6
    //   263: aload_1
    //   264: invokevirtual J : (Lc/b/c/i0;Landroid/view/KeyEvent;)Z
    //   267: ifeq -> 405
    //   270: aload_0
    //   271: getfield o : Lc/b/h/a1;
    //   274: checkcast androidx/appcompat/widget/ActionBarOverlayLayout
    //   277: astore_1
    //   278: aload_1
    //   279: invokevirtual m : ()V
    //   282: aload_1
    //   283: getfield i : Lc/b/h/b1;
    //   286: checkcast c/b/h/n2
    //   289: getfield a : Landroidx/appcompat/widget/Toolbar;
    //   292: invokevirtual u : ()Z
    //   295: istore #4
    //   297: goto -> 418
    //   300: aload_0
    //   301: getfield o : Lc/b/h/a1;
    //   304: checkcast androidx/appcompat/widget/ActionBarOverlayLayout
    //   307: astore_1
    //   308: aload_1
    //   309: invokevirtual m : ()V
    //   312: aload_1
    //   313: getfield i : Lc/b/h/b1;
    //   316: checkcast c/b/h/n2
    //   319: invokevirtual b : ()Z
    //   322: istore #4
    //   324: goto -> 418
    //   327: aload #6
    //   329: getfield m : Z
    //   332: istore #4
    //   334: iload #4
    //   336: ifne -> 411
    //   339: aload #6
    //   341: getfield l : Z
    //   344: ifeq -> 350
    //   347: goto -> 411
    //   350: aload #6
    //   352: getfield k : Z
    //   355: ifeq -> 405
    //   358: aload #6
    //   360: getfield p : Z
    //   363: ifeq -> 384
    //   366: aload #6
    //   368: iconst_0
    //   369: putfield k : Z
    //   372: aload_0
    //   373: aload #6
    //   375: aload_1
    //   376: invokevirtual J : (Lc/b/c/i0;Landroid/view/KeyEvent;)Z
    //   379: istore #4
    //   381: goto -> 387
    //   384: iconst_1
    //   385: istore #4
    //   387: iload #4
    //   389: ifeq -> 405
    //   392: aload_0
    //   393: aload #6
    //   395: aload_1
    //   396: invokevirtual H : (Lc/b/c/i0;Landroid/view/KeyEvent;)V
    //   399: iconst_1
    //   400: istore #4
    //   402: goto -> 418
    //   405: iconst_0
    //   406: istore #4
    //   408: goto -> 418
    //   411: aload_0
    //   412: aload #6
    //   414: iconst_1
    //   415: invokevirtual s : (Lc/b/c/i0;Z)V
    //   418: iload #4
    //   420: ifeq -> 547
    //   423: aload_0
    //   424: getfield h : Landroid/content/Context;
    //   427: invokevirtual getApplicationContext : ()Landroid/content/Context;
    //   430: ldc_w 'audio'
    //   433: invokevirtual getSystemService : (Ljava/lang/String;)Ljava/lang/Object;
    //   436: checkcast android/media/AudioManager
    //   439: astore_1
    //   440: aload_1
    //   441: ifnull -> 451
    //   444: aload_1
    //   445: iconst_0
    //   446: invokevirtual playSoundEffect : (I)V
    //   449: iconst_1
    //   450: ireturn
    //   451: ldc_w 'AppCompatDelegate'
    //   454: ldc_w 'Couldn't get audio manager'
    //   457: invokestatic w : (Ljava/lang/String;Ljava/lang/String;)I
    //   460: pop
    //   461: iconst_1
    //   462: ireturn
    //   463: aload_0
    //   464: getfield K : Z
    //   467: istore #4
    //   469: aload_0
    //   470: iconst_0
    //   471: putfield K : Z
    //   474: aload_0
    //   475: iconst_0
    //   476: invokevirtual C : (I)Lc/b/c/i0;
    //   479: astore_1
    //   480: aload_1
    //   481: getfield m : Z
    //   484: ifeq -> 500
    //   487: iload #4
    //   489: ifne -> 547
    //   492: aload_0
    //   493: aload_1
    //   494: iconst_1
    //   495: invokevirtual s : (Lc/b/c/i0;Z)V
    //   498: iconst_1
    //   499: ireturn
    //   500: aload_0
    //   501: getfield r : Lc/b/g/b;
    //   504: astore_1
    //   505: aload_1
    //   506: ifnull -> 516
    //   509: aload_1
    //   510: invokevirtual c : ()V
    //   513: goto -> 536
    //   516: aload_0
    //   517: invokevirtual E : ()V
    //   520: aload_0
    //   521: getfield l : Lc/b/c/a;
    //   524: astore_1
    //   525: aload_1
    //   526: ifnull -> 541
    //   529: aload_1
    //   530: invokevirtual b : ()Z
    //   533: ifeq -> 541
    //   536: iconst_1
    //   537: istore_2
    //   538: goto -> 543
    //   541: iconst_0
    //   542: istore_2
    //   543: iload_2
    //   544: ifeq -> 173
    //   547: iconst_1
    //   548: ireturn
  }
  
  public void v(int paramInt) {
    i0 i01 = C(paramInt);
    if (i01.h != null) {
      Bundle bundle = new Bundle();
      i01.h.w(bundle);
      if (bundle.size() > 0)
        i01.q = bundle; 
      i01.h.z();
      i01.h.clear();
    } 
    i01.p = true;
    i01.o = true;
    if ((paramInt == 108 || paramInt == 0) && this.o != null) {
      i01 = C(0);
      i01.k = false;
      J(i01, null);
    } 
  }
  
  public void w() {
    y y1 = this.v;
    if (y1 != null)
      y1.b(); 
  }
  
  public final void x() {
    if (!this.w) {
      Object object;
      TypedArray typedArray = this.h.obtainStyledAttributes(b.j);
      if (typedArray.hasValue(115)) {
        ViewGroup viewGroup;
        if (typedArray.getBoolean(124, false)) {
          i(1);
        } else if (typedArray.getBoolean(115, false)) {
          i(108);
        } 
        if (typedArray.getBoolean(116, false))
          i(109); 
        if (typedArray.getBoolean(117, false))
          i(10); 
        this.F = typedArray.getBoolean(0, false);
        typedArray.recycle();
        y();
        this.i.getDecorView();
        LayoutInflater layoutInflater = LayoutInflater.from(this.h);
        if (!this.G) {
          if (this.F) {
            viewGroup = (ViewGroup)layoutInflater.inflate(2131427340, null);
            this.D = false;
            this.C = false;
          } else if (this.C) {
            Context context;
            TypedValue typedValue = new TypedValue();
            this.h.getTheme().resolveAttribute(2130903049, typedValue, true);
            if (typedValue.resourceId != 0) {
              d d = new d(this.h, typedValue.resourceId);
            } else {
              context = this.h;
            } 
            ViewGroup viewGroup1 = (ViewGroup)LayoutInflater.from(context).inflate(2131427351, null);
            a1 a11 = (a1)viewGroup1.findViewById(2131230857);
            this.o = a11;
            a11.setWindowCallback(D());
            if (this.D)
              ((ActionBarOverlayLayout)this.o).k(109); 
            if (this.A)
              ((ActionBarOverlayLayout)this.o).k(2); 
            viewGroup = viewGroup1;
            if (this.B) {
              ((ActionBarOverlayLayout)this.o).k(5);
              viewGroup = viewGroup1;
            } 
          } else {
            layoutInflater = null;
          } 
        } else if (this.E) {
          viewGroup = (ViewGroup)layoutInflater.inflate(2131427350, null);
        } else {
          viewGroup = (ViewGroup)viewGroup.inflate(2131427349, null);
        } 
        if (viewGroup != null) {
          u.o((View)viewGroup, new t(this));
          if (this.o == null)
            this.y = (TextView)viewGroup.findViewById(2131231145); 
          Method method = t2.a;
          try {
            method = viewGroup.getClass().getMethod("makeOptionalFitsSystemWindows", new Class[0]);
            if (!method.isAccessible())
              method.setAccessible(true); 
            method.invoke(viewGroup, new Object[0]);
          } catch (NoSuchMethodException noSuchMethodException) {
            Log.d("ViewUtils", "Could not find method makeOptionalFitsSystemWindows. Oh well...");
          } catch (InvocationTargetException invocationTargetException) {
            Log.d("ViewUtils", "Could not invoke makeOptionalFitsSystemWindows", invocationTargetException);
          } catch (IllegalAccessException illegalAccessException) {
            Log.d("ViewUtils", "Could not invoke makeOptionalFitsSystemWindows", illegalAccessException);
          } 
          ContentFrameLayout contentFrameLayout = (ContentFrameLayout)viewGroup.findViewById(2131230770);
          ViewGroup viewGroup1 = (ViewGroup)this.i.findViewById(16908290);
          if (viewGroup1 != null) {
            while (viewGroup1.getChildCount() > 0) {
              View view1 = viewGroup1.getChildAt(0);
              viewGroup1.removeViewAt(0);
              contentFrameLayout.addView(view1);
            } 
            viewGroup1.setId(-1);
            contentFrameLayout.setId(16908290);
            if (viewGroup1 instanceof FrameLayout)
              ((FrameLayout)viewGroup1).setForeground(null); 
          } 
          this.i.setContentView((View)viewGroup);
          contentFrameLayout.setAttachListener(new u(this));
          this.x = viewGroup;
          object = this.g;
          if (object instanceof Activity) {
            object = ((Activity)object).getTitle();
          } else {
            object = this.n;
          } 
          if (!TextUtils.isEmpty((CharSequence)object)) {
            a1 a11 = this.o;
            if (a11 != null) {
              a11.setWindowTitle((CharSequence)object);
            } else {
              a a2 = this.l;
              if (a2 != null) {
                a2.q((CharSequence)object);
              } else {
                TextView textView = this.y;
                if (textView != null)
                  textView.setText((CharSequence)object); 
              } 
            } 
          } 
          object = this.x.findViewById(16908290);
          View view = this.i.getDecorView();
          int j = view.getPaddingLeft();
          int k = view.getPaddingTop();
          int m = view.getPaddingRight();
          int n = view.getPaddingBottom();
          ((ContentFrameLayout)object).k.set(j, k, m, n);
          AtomicInteger atomicInteger = u.a;
          if (object.isLaidOut())
            object.requestLayout(); 
          TypedArray typedArray1 = this.h.obtainStyledAttributes(b.j);
          typedArray1.getValue(122, object.getMinWidthMajor());
          typedArray1.getValue(123, object.getMinWidthMinor());
          if (typedArray1.hasValue(120))
            typedArray1.getValue(120, object.getFixedWidthMajor()); 
          if (typedArray1.hasValue(121))
            typedArray1.getValue(121, object.getFixedWidthMinor()); 
          if (typedArray1.hasValue(118))
            typedArray1.getValue(118, object.getFixedHeightMajor()); 
          if (typedArray1.hasValue(119))
            typedArray1.getValue(119, object.getFixedHeightMinor()); 
          typedArray1.recycle();
          object.requestLayout();
          this.w = true;
          object = C(0);
          if (!this.O && ((i0)object).h == null) {
            F(108);
            return;
          } 
        } else {
          object = a.p("AppCompat does not support the current theme features: { windowActionBar: ");
          object.append(this.C);
          object.append(", windowActionBarOverlay: ");
          object.append(this.D);
          object.append(", android:windowIsFloating: ");
          object.append(this.F);
          object.append(", windowActionModeOverlay: ");
          object.append(this.E);
          object.append(", windowNoTitle: ");
          object.append(this.G);
          object.append(" }");
          throw new IllegalArgumentException(object.toString());
        } 
      } else {
        object.recycle();
        throw new IllegalStateException("You need to use a Theme.AppCompat theme (or descendant) with this activity.");
      } 
    } 
  }
  
  public final void y() {
    if (this.i == null) {
      Object object = this.g;
      if (object instanceof Activity)
        p(((Activity)object).getWindow()); 
    } 
    if (this.i != null)
      return; 
    throw new IllegalStateException("We have not been given a Window");
  }
  
  public i0 z(Menu paramMenu) {
    byte b1;
    i0[] arrayOfI0 = this.I;
    int j = 0;
    if (arrayOfI0 != null) {
      b1 = arrayOfI0.length;
    } else {
      b1 = 0;
    } 
    while (j < b1) {
      i0 i01 = arrayOfI0[j];
      if (i01 != null && i01.h == paramMenu)
        return i01; 
      j++;
    } 
    return null;
  }
}


/* Location:              C:\soft\dex2jar-2.0\Https Traffic-dex2jar.jar!\c\b\c\k0.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */