package c.b.c;

import android.content.Context;
import android.graphics.drawable.Drawable;
import androidx.appcompat.widget.Toolbar;

public class f implements d {
  public final Toolbar a;
  
  public final Drawable b;
  
  public final CharSequence c;
  
  public f(Toolbar paramToolbar) {
    this.a = paramToolbar;
    this.b = paramToolbar.getNavigationIcon();
    this.c = paramToolbar.getNavigationContentDescription();
  }
  
  public void a(Drawable paramDrawable, int paramInt) {
    this.a.setNavigationIcon(paramDrawable);
    if (paramInt == 0) {
      this.a.setNavigationContentDescription(this.c);
      return;
    } 
    this.a.setNavigationContentDescription(paramInt);
  }
  
  public boolean b() {
    return true;
  }
  
  public Drawable c() {
    return this.b;
  }
  
  public void d(int paramInt) {
    if (paramInt == 0) {
      this.a.setNavigationContentDescription(this.c);
      return;
    } 
    this.a.setNavigationContentDescription(paramInt);
  }
  
  public Context e() {
    return this.a.getContext();
  }
}


/* Location:              C:\soft\dex2jar-2.0\Https Traffic-dex2jar.jar!\c\b\c\f.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */