package c.b.c;

import android.content.Context;
import android.content.DialogInterface;
import android.graphics.drawable.Drawable;
import android.view.ContextThemeWrapper;
import android.view.View;
import android.widget.ImageView;
import android.widget.ListAdapter;
import android.widget.ListView;
import android.widget.TextView;
import androidx.appcompat.app.AlertController;
import java.util.Objects;

public class n {
  public final k a;
  
  public final int b;
  
  public n(Context paramContext) {
    this.a = new k((Context)new ContextThemeWrapper(paramContext, o.b(paramContext, i)));
    this.b = i;
  }
  
  public o a() {
    o o = new o(this.a.a, this.b);
    k k1 = this.a;
    AlertController alertController = o.g;
    View view = k1.e;
    if (view != null) {
      alertController.G = view;
    } else {
      CharSequence charSequence = k1.d;
      if (charSequence != null) {
        alertController.e = charSequence;
        TextView textView = alertController.E;
        if (textView != null)
          textView.setText(charSequence); 
      } 
      Drawable drawable = k1.c;
      if (drawable != null) {
        alertController.C = drawable;
        alertController.B = 0;
        ImageView imageView = alertController.D;
        if (imageView != null) {
          imageView.setVisibility(0);
          alertController.D.setImageDrawable(drawable);
        } 
      } 
    } 
    if (k1.g != null) {
      int i;
      m m;
      AlertController.RecycleListView recycleListView = (AlertController.RecycleListView)k1.b.inflate(alertController.L, null);
      if (k1.i) {
        i = alertController.N;
      } else {
        i = alertController.O;
      } 
      ListAdapter listAdapter = k1.g;
      if (listAdapter == null)
        m = new m(k1.a, i, 16908308, null); 
      alertController.H = (ListAdapter)m;
      alertController.I = k1.j;
      if (k1.h != null)
        recycleListView.setOnItemClickListener(new j(k1, alertController)); 
      if (k1.i)
        recycleListView.setChoiceMode(1); 
      alertController.g = (ListView)recycleListView;
    } 
    Objects.requireNonNull(this.a);
    o.setCancelable(true);
    Objects.requireNonNull(this.a);
    o.setCanceledOnTouchOutside(true);
    Objects.requireNonNull(this.a);
    o.setOnCancelListener(null);
    Objects.requireNonNull(this.a);
    o.setOnDismissListener(null);
    DialogInterface.OnKeyListener onKeyListener = this.a.f;
    if (onKeyListener != null)
      o.setOnKeyListener(onKeyListener); 
    return o;
  }
}


/* Location:              C:\soft\dex2jar-2.0\Https Traffic-dex2jar.jar!\c\b\c\n.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */