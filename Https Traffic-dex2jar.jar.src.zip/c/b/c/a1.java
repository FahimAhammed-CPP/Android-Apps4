package c.b.c;

import android.content.Context;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import androidx.appcompat.widget.ActionBarContextView;
import c.b.g.a;
import c.b.g.b;
import c.b.g.j;
import c.b.g.n.l;
import c.b.h.b;
import c.b.h.m;
import c.b.h.n2;
import java.lang.ref.WeakReference;

public class a1 extends b implements l.a {
  public final Context g;
  
  public final l h;
  
  public a i;
  
  public WeakReference<View> j;
  
  public a1(b1 paramb1, Context paramContext, a parama) {
    this.g = paramContext;
    this.i = parama;
    l l1 = new l(paramContext);
    l1.l = 1;
    this.h = l1;
    l1.e = this;
  }
  
  public boolean a(l paraml, MenuItem paramMenuItem) {
    a a2 = this.i;
    return (a2 != null) ? a2.c(this, paramMenuItem) : false;
  }
  
  public void b(l paraml) {
    if (this.i == null)
      return; 
    i();
    m m = ((b)this.k.f).h;
    if (m != null)
      m.p(); 
  }
  
  public void c() {
    b1 b12 = this.k;
    if (b12.i != this)
      return; 
    if ((b12.q ^ true) == 0) {
      b12.j = this;
      b12.k = this.i;
    } else {
      this.i.b(this);
    } 
    this.i = null;
    this.k.s(false);
    ActionBarContextView actionBarContextView = this.k.f;
    if (actionBarContextView.o == null)
      actionBarContextView.h(); 
    ((n2)this.k.e).a.sendAccessibilityEvent(32);
    b1 b11 = this.k;
    b11.c.setHideOnContentScrollEnabled(b11.v);
    this.k.i = null;
  }
  
  public View d() {
    WeakReference<View> weakReference = this.j;
    return (weakReference != null) ? weakReference.get() : null;
  }
  
  public Menu e() {
    return (Menu)this.h;
  }
  
  public MenuInflater f() {
    return (MenuInflater)new j(this.g);
  }
  
  public CharSequence g() {
    return this.k.f.getSubtitle();
  }
  
  public CharSequence h() {
    return this.k.f.getTitle();
  }
  
  public void i() {
    if (this.k.i != this)
      return; 
    this.h.z();
    try {
      this.i.a(this, (Menu)this.h);
      return;
    } finally {
      this.h.y();
    } 
  }
  
  public boolean j() {
    return this.k.f.v;
  }
  
  public void k(View paramView) {
    this.k.f.setCustomView(paramView);
    this.j = new WeakReference<View>(paramView);
  }
  
  public void l(int paramInt) {
    String str = this.k.a.getResources().getString(paramInt);
    this.k.f.setSubtitle(str);
  }
  
  public void m(CharSequence paramCharSequence) {
    this.k.f.setSubtitle(paramCharSequence);
  }
  
  public void n(int paramInt) {
    String str = this.k.a.getResources().getString(paramInt);
    this.k.f.setTitle(str);
  }
  
  public void o(CharSequence paramCharSequence) {
    this.k.f.setTitle(paramCharSequence);
  }
  
  public void p(boolean paramBoolean) {
    this.f = paramBoolean;
    this.k.f.setTitleOptional(paramBoolean);
  }
}


/* Location:              C:\soft\dex2jar-2.0\Https Traffic-dex2jar.jar!\c\b\c\a1.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */