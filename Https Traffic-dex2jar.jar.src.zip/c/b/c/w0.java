package c.b.c;

import android.content.Context;
import android.location.Location;
import android.location.LocationManager;
import android.util.Log;

public class w0 {
  public static w0 d;
  
  public final Context a;
  
  public final LocationManager b;
  
  public final v0 c = new v0();
  
  public w0(Context paramContext, LocationManager paramLocationManager) {
    this.a = paramContext;
    this.b = paramLocationManager;
  }
  
  public final Location a(String paramString) {
    try {
      if (this.b.isProviderEnabled(paramString))
        return this.b.getLastKnownLocation(paramString); 
    } catch (Exception exception) {
      Log.d("TwilightManager", "Failed to get last known location", exception);
    } 
    return null;
  }
}


/* Location:              C:\soft\dex2jar-2.0\Https Traffic-dex2jar.jar!\c\b\c\w0.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */