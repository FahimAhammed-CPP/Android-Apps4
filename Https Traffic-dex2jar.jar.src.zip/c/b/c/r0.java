package c.b.c;

import android.view.Menu;
import android.view.MenuItem;
import c.b.g.n.l;
import c.b.h.n2;

public final class r0 implements l.a {
  public r0(t0 paramt0) {}
  
  public boolean a(l paraml, MenuItem paramMenuItem) {
    return false;
  }
  
  public void b(l paraml) {
    t0 t01 = this.e;
    if (t01.c != null) {
      if (((n2)t01.a).a.o()) {
        this.e.c.onPanelClosed(108, (Menu)paraml);
        return;
      } 
      if (this.e.c.onPreparePanel(0, null, (Menu)paraml))
        this.e.c.onMenuOpened(108, (Menu)paraml); 
    } 
  }
}


/* Location:              C:\soft\dex2jar-2.0\Https Traffic-dex2jar.jar!\c\b\c\r0.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */