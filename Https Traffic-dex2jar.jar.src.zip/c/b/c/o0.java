package c.b.c;

import android.view.Menu;
import c.b.g.n.l;

public class o0 implements Runnable {
  public o0(t0 paramt0) {}
  
  public void run() {
    l l;
    null = this.e;
    Menu menu = null.s();
    if (menu instanceof l) {
      l = (l)menu;
    } else {
      l = null;
    } 
    if (l != null)
      l.z(); 
    try {
      menu.clear();
      if (!null.c.onCreatePanelMenu(0, menu) || !null.c.onPreparePanel(0, null, menu))
        menu.clear(); 
      return;
    } finally {
      if (l != null)
        l.y(); 
    } 
  }
}


/* Location:              C:\soft\dex2jar-2.0\Https Traffic-dex2jar.jar!\c\b\c\o0.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */