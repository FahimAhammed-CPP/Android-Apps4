package c.b.g;

import android.view.InflateException;
import android.view.MenuItem;
import java.lang.reflect.Method;

public class h implements MenuItem.OnMenuItemClickListener {
  public static final Class<?>[] c = new Class[] { MenuItem.class };
  
  public Object a;
  
  public Method b;
  
  public h(Object paramObject, String paramString) {
    this.a = paramObject;
    Class<?> clazz = paramObject.getClass();
    try {
      this.b = clazz.getMethod(paramString, c);
      return;
    } catch (Exception exception) {
      StringBuilder stringBuilder = new StringBuilder();
      stringBuilder.append("Couldn't resolve menu item onClick handler ");
      stringBuilder.append(paramString);
      stringBuilder.append(" in class ");
      stringBuilder.append(clazz.getName());
      InflateException inflateException = new InflateException(stringBuilder.toString());
      inflateException.initCause(exception);
      throw inflateException;
    } 
  }
  
  public boolean onMenuItemClick(MenuItem paramMenuItem) {
    try {
      if (this.b.getReturnType() == boolean.class)
        return ((Boolean)this.b.invoke(this.a, new Object[] { paramMenuItem })).booleanValue(); 
      this.b.invoke(this.a, new Object[] { paramMenuItem });
      return true;
    } catch (Exception exception) {
      throw new RuntimeException(exception);
    } 
  }
}


/* Location:              C:\soft\dex2jar-2.0\Https Traffic-dex2jar.jar!\c\b\g\h.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */