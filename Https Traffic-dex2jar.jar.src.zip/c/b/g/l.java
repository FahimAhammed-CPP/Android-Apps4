package c.b.g;

import android.animation.TimeInterpolator;
import android.view.View;
import android.view.animation.Interpolator;
import c.h.j.a0;
import c.h.j.y;
import c.h.j.z;
import java.util.ArrayList;
import java.util.Iterator;

public class l {
  public final ArrayList<y> a = new ArrayList<y>();
  
  public long b = -1L;
  
  public Interpolator c;
  
  public z d;
  
  public boolean e;
  
  public final a0 f = new k(this);
  
  public void a() {
    if (!this.e)
      return; 
    Iterator<y> iterator = this.a.iterator();
    while (iterator.hasNext())
      ((y)iterator.next()).b(); 
    this.e = false;
  }
  
  public void b() {
    if (this.e)
      return; 
    for (y y : this.a) {
      long l1 = this.b;
      if (l1 >= 0L)
        y.c(l1); 
      Interpolator interpolator = this.c;
      if (interpolator != null) {
        View view1 = y.a.get();
        if (view1 != null)
          view1.animate().setInterpolator((TimeInterpolator)interpolator); 
      } 
      if (this.d != null)
        y.d((z)this.f); 
      View view = y.a.get();
      if (view != null)
        view.animate().start(); 
    } 
    this.e = true;
  }
}


/* Location:              C:\soft\dex2jar-2.0\Https Traffic-dex2jar.jar!\c\b\g\l.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */