package c.b.g.n;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import androidx.appcompat.view.menu.ListMenuItemView;
import java.util.ArrayList;

public class k extends BaseAdapter {
  public l e;
  
  public int f = -1;
  
  public boolean g;
  
  public final boolean h;
  
  public final LayoutInflater i;
  
  public final int j;
  
  public k(l paraml, LayoutInflater paramLayoutInflater, boolean paramBoolean, int paramInt) {
    this.h = paramBoolean;
    this.i = paramLayoutInflater;
    this.e = paraml;
    this.j = paramInt;
    a();
  }
  
  public void a() {
    l l1 = this.e;
    o o = l1.v;
    if (o != null) {
      l1.i();
      ArrayList<o> arrayList = l1.j;
      int j = arrayList.size();
      for (int i = 0; i < j; i++) {
        if ((o)arrayList.get(i) == o) {
          this.f = i;
          return;
        } 
      } 
    } 
    this.f = -1;
  }
  
  public o b(int paramInt) {
    ArrayList<o> arrayList;
    if (this.h) {
      l l1 = this.e;
      l1.i();
      arrayList = l1.j;
    } else {
      arrayList = this.e.l();
    } 
    int j = this.f;
    int i = paramInt;
    if (j >= 0) {
      i = paramInt;
      if (paramInt >= j)
        i = paramInt + 1; 
    } 
    return arrayList.get(i);
  }
  
  public int getCount() {
    ArrayList<o> arrayList;
    if (this.h) {
      l l1 = this.e;
      l1.i();
      arrayList = l1.j;
    } else {
      arrayList = this.e.l();
    } 
    return (this.f < 0) ? arrayList.size() : (arrayList.size() - 1);
  }
  
  public long getItemId(int paramInt) {
    return paramInt;
  }
  
  public View getView(int paramInt, View paramView, ViewGroup paramViewGroup) {
    boolean bool;
    View view = paramView;
    if (paramView == null)
      view = this.i.inflate(this.j, paramViewGroup, false); 
    int j = (b(paramInt)).b;
    int i = paramInt - 1;
    if (i >= 0) {
      i = (b(i)).b;
    } else {
      i = j;
    } 
    ListMenuItemView listMenuItemView = (ListMenuItemView)view;
    if (this.e.m() && j != i) {
      bool = true;
    } else {
      bool = false;
    } 
    listMenuItemView.setGroupDividerEnabled(bool);
    z.a a = (z.a)view;
    if (this.g)
      listMenuItemView.setForceShowIcon(true); 
    a.f(b(paramInt), 0);
    return view;
  }
  
  public void notifyDataSetChanged() {
    a();
    super.notifyDataSetChanged();
  }
}


/* Location:              C:\soft\dex2jar-2.0\Https Traffic-dex2jar.jar!\c\b\g\n\k.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */