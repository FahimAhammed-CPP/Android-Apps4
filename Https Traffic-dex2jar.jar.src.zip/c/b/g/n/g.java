package c.b.g.n;

import c.b.h.t1;

public class g {
  public final t1 a;
  
  public final l b;
  
  public final int c;
  
  public g(t1 paramt1, l paraml, int paramInt) {
    this.a = paramt1;
    this.b = paraml;
    this.c = paramInt;
  }
}


/* Location:              C:\soft\dex2jar-2.0\Https Traffic-dex2jar.jar!\c\b\g\n\g.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */