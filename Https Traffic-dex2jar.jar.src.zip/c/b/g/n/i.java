package c.b.g.n;

import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import java.util.ArrayList;
import java.util.Objects;

public class i extends BaseAdapter {
  public int e = -1;
  
  public i(j paramj) {
    a();
  }
  
  public void a() {
    l l = this.f.g;
    o o = l.v;
    if (o != null) {
      l.i();
      ArrayList<o> arrayList = l.j;
      int m = arrayList.size();
      for (int k = 0; k < m; k++) {
        if ((o)arrayList.get(k) == o) {
          this.e = k;
          return;
        } 
      } 
    } 
    this.e = -1;
  }
  
  public o b(int paramInt) {
    l l = this.f.g;
    l.i();
    ArrayList<o> arrayList = l.j;
    Objects.requireNonNull(this.f);
    int k = paramInt + 0;
    int m = this.e;
    paramInt = k;
    if (m >= 0) {
      paramInt = k;
      if (k >= m)
        paramInt = k + 1; 
    } 
    return arrayList.get(paramInt);
  }
  
  public int getCount() {
    l l = this.f.g;
    l.i();
    int k = l.j.size();
    Objects.requireNonNull(this.f);
    k += 0;
    return (this.e < 0) ? k : (k - 1);
  }
  
  public long getItemId(int paramInt) {
    return paramInt;
  }
  
  public View getView(int paramInt, View paramView, ViewGroup paramViewGroup) {
    View view = paramView;
    if (paramView == null)
      view = this.f.f.inflate(2131427344, paramViewGroup, false); 
    ((z.a)view).f(b(paramInt), 0);
    return view;
  }
  
  public void notifyDataSetChanged() {
    a();
    super.notifyDataSetChanged();
  }
}


/* Location:              C:\soft\dex2jar-2.0\Https Traffic-dex2jar.jar!\c\b\g\n\i.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */