package c.b.g.n;

import android.view.MenuItem;

public class t implements MenuItem.OnMenuItemClickListener {
  public final MenuItem.OnMenuItemClickListener a;
  
  public t(u paramu, MenuItem.OnMenuItemClickListener paramOnMenuItemClickListener) {
    this.a = paramOnMenuItemClickListener;
  }
  
  public boolean onMenuItemClick(MenuItem paramMenuItem) {
    return this.a.onMenuItemClick(this.b.c(paramMenuItem));
  }
}


/* Location:              C:\soft\dex2jar-2.0\Https Traffic-dex2jar.jar!\c\b\g\n\t.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */