package c.b.g.n;

import android.view.View;
import android.view.ViewTreeObserver;

public class d implements View.OnAttachStateChangeListener {
  public d(h paramh) {}
  
  public void onViewAttachedToWindow(View paramView) {}
  
  public void onViewDetachedFromWindow(View paramView) {
    ViewTreeObserver viewTreeObserver = this.e.C;
    if (viewTreeObserver != null) {
      if (!viewTreeObserver.isAlive())
        this.e.C = paramView.getViewTreeObserver(); 
      h h1 = this.e;
      h1.C.removeGlobalOnLayoutListener(h1.n);
    } 
    paramView.removeOnAttachStateChangeListener(this);
  }
}


/* Location:              C:\soft\dex2jar-2.0\Https Traffic-dex2jar.jar!\c\b\g\n\d.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */