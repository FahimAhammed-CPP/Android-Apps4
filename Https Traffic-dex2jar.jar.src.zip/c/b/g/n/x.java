package c.b.g.n;

import android.content.Context;
import android.graphics.Point;
import android.graphics.Rect;
import android.view.Display;
import android.view.Gravity;
import android.view.View;
import android.view.WindowManager;
import android.widget.PopupWindow;
import c.h.j.u;
import java.util.concurrent.atomic.AtomicInteger;

public class x {
  public final Context a;
  
  public final l b;
  
  public final boolean c;
  
  public final int d;
  
  public final int e;
  
  public View f;
  
  public int g = 8388611;
  
  public boolean h;
  
  public y.a i;
  
  public v j;
  
  public PopupWindow.OnDismissListener k;
  
  public final PopupWindow.OnDismissListener l = new w(this);
  
  public x(Context paramContext, l paraml, View paramView, boolean paramBoolean, int paramInt1, int paramInt2) {
    this.a = paramContext;
    this.b = paraml;
    this.f = paramView;
    this.c = paramBoolean;
    this.d = paramInt1;
    this.e = paramInt2;
  }
  
  public v a() {
    if (this.j == null) {
      boolean bool;
      e0 e0;
      Display display = ((WindowManager)this.a.getSystemService("window")).getDefaultDisplay();
      Point point = new Point();
      display.getRealSize(point);
      if (Math.min(point.x, point.y) >= this.a.getResources().getDimensionPixelSize(2131100430)) {
        bool = true;
      } else {
        bool = false;
      } 
      if (bool) {
        h h = new h(this.a, this.f, this.d, this.e, this.c);
      } else {
        e0 = new e0(this.a, this.b, this.f, this.d, this.e, this.c);
      } 
      e0.n(this.b);
      e0.u(this.l);
      e0.q(this.f);
      e0.m(this.i);
      e0.r(this.h);
      e0.s(this.g);
      this.j = e0;
    } 
    return this.j;
  }
  
  public boolean b() {
    v v1 = this.j;
    return (v1 != null && v1.b());
  }
  
  public void c() {
    this.j = null;
    PopupWindow.OnDismissListener onDismissListener = this.k;
    if (onDismissListener != null)
      onDismissListener.onDismiss(); 
  }
  
  public void d(y.a parama) {
    this.i = parama;
    v v1 = this.j;
    if (v1 != null)
      v1.m(parama); 
  }
  
  public final void e(int paramInt1, int paramInt2, boolean paramBoolean1, boolean paramBoolean2) {
    v v1 = a();
    v1.v(paramBoolean2);
    if (paramBoolean1) {
      int j = this.g;
      View view = this.f;
      AtomicInteger atomicInteger = u.a;
      int i = paramInt1;
      if ((Gravity.getAbsoluteGravity(j, view.getLayoutDirection()) & 0x7) == 5)
        i = paramInt1 - this.f.getWidth(); 
      v1.t(i);
      v1.w(paramInt2);
      paramInt1 = (int)((this.a.getResources().getDisplayMetrics()).density * 48.0F / 2.0F);
      v1.e = new Rect(i - paramInt1, paramInt2 - paramInt1, i + paramInt1, paramInt2 + paramInt1);
    } 
    v1.d();
  }
  
  public boolean f() {
    if (b())
      return true; 
    if (this.f == null)
      return false; 
    e(0, 0, false, false);
    return true;
  }
}


/* Location:              C:\soft\dex2jar-2.0\Https Traffic-dex2jar.jar!\c\b\g\n\x.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */