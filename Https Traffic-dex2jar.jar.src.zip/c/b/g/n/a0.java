package c.b.g.n;

import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.view.KeyEvent;
import android.view.Menu;
import android.view.MenuItem;
import android.view.SubMenu;
import c.e.i;
import c.h.e.a.a;
import c.h.e.a.b;

public class a0 extends b implements Menu {
  public final a c;
  
  public a0(Context paramContext, a parama) {
    super(paramContext);
    if (parama != null) {
      this.c = parama;
      return;
    } 
    throw new IllegalArgumentException("Wrapped Object can not be null.");
  }
  
  public MenuItem add(int paramInt) {
    return c(((l)this.c).add(paramInt));
  }
  
  public MenuItem add(int paramInt1, int paramInt2, int paramInt3, int paramInt4) {
    return c(((l)this.c).add(paramInt1, paramInt2, paramInt3, paramInt4));
  }
  
  public MenuItem add(int paramInt1, int paramInt2, int paramInt3, CharSequence paramCharSequence) {
    return c(((l)this.c).add(paramInt1, paramInt2, paramInt3, paramCharSequence));
  }
  
  public MenuItem add(CharSequence paramCharSequence) {
    return c(((l)this.c).add(paramCharSequence));
  }
  
  public int addIntentOptions(int paramInt1, int paramInt2, int paramInt3, ComponentName paramComponentName, Intent[] paramArrayOfIntent, Intent paramIntent, int paramInt4, MenuItem[] paramArrayOfMenuItem) {
    MenuItem[] arrayOfMenuItem;
    if (paramArrayOfMenuItem != null) {
      arrayOfMenuItem = new MenuItem[paramArrayOfMenuItem.length];
    } else {
      arrayOfMenuItem = null;
    } 
    paramInt2 = ((l)this.c).addIntentOptions(paramInt1, paramInt2, paramInt3, paramComponentName, paramArrayOfIntent, paramIntent, paramInt4, arrayOfMenuItem);
    if (arrayOfMenuItem != null) {
      paramInt1 = 0;
      paramInt3 = arrayOfMenuItem.length;
      while (paramInt1 < paramInt3) {
        paramArrayOfMenuItem[paramInt1] = c(arrayOfMenuItem[paramInt1]);
        paramInt1++;
      } 
    } 
    return paramInt2;
  }
  
  public SubMenu addSubMenu(int paramInt) {
    return ((l)this.c).addSubMenu(paramInt);
  }
  
  public SubMenu addSubMenu(int paramInt1, int paramInt2, int paramInt3, int paramInt4) {
    return ((l)this.c).addSubMenu(paramInt1, paramInt2, paramInt3, paramInt4);
  }
  
  public SubMenu addSubMenu(int paramInt1, int paramInt2, int paramInt3, CharSequence paramCharSequence) {
    return this.c.addSubMenu(paramInt1, paramInt2, paramInt3, paramCharSequence);
  }
  
  public SubMenu addSubMenu(CharSequence paramCharSequence) {
    return ((l)this.c).addSubMenu(paramCharSequence);
  }
  
  public void clear() {
    i<b, MenuItem> i = this.b;
    if (i != null)
      i.clear(); 
    ((l)this.c).clear();
  }
  
  public void close() {
    ((l)this.c).close();
  }
  
  public MenuItem findItem(int paramInt) {
    return c(((l)this.c).findItem(paramInt));
  }
  
  public MenuItem getItem(int paramInt) {
    return c((MenuItem)((l)this.c).f.get(paramInt));
  }
  
  public boolean hasVisibleItems() {
    return ((l)this.c).hasVisibleItems();
  }
  
  public boolean isShortcutKey(int paramInt, KeyEvent paramKeyEvent) {
    return ((l)this.c).isShortcutKey(paramInt, paramKeyEvent);
  }
  
  public boolean performIdentifierAction(int paramInt1, int paramInt2) {
    return ((l)this.c).performIdentifierAction(paramInt1, paramInt2);
  }
  
  public boolean performShortcut(int paramInt1, KeyEvent paramKeyEvent, int paramInt2) {
    return ((l)this.c).performShortcut(paramInt1, paramKeyEvent, paramInt2);
  }
  
  public void removeGroup(int paramInt) {
    if (this.b != null) {
      int i = 0;
      while (true) {
        i<b, MenuItem> i1 = this.b;
        if (i < i1.g) {
          int j = i;
          if (((b)i1.h(i)).getGroupId() == paramInt) {
            this.b.j(i);
            j = i - 1;
          } 
          i = j + 1;
          continue;
        } 
        break;
      } 
    } 
    ((l)this.c).removeGroup(paramInt);
  }
  
  public void removeItem(int paramInt) {
    if (this.b != null) {
      int i = 0;
      while (true) {
        i<b, MenuItem> i1 = this.b;
        if (i < i1.g) {
          if (((b)i1.h(i)).getItemId() == paramInt) {
            this.b.j(i);
            break;
          } 
          i++;
          continue;
        } 
        break;
      } 
    } 
    ((l)this.c).removeItem(paramInt);
  }
  
  public void setGroupCheckable(int paramInt, boolean paramBoolean1, boolean paramBoolean2) {
    ((l)this.c).setGroupCheckable(paramInt, paramBoolean1, paramBoolean2);
  }
  
  public void setGroupEnabled(int paramInt, boolean paramBoolean) {
    ((l)this.c).setGroupEnabled(paramInt, paramBoolean);
  }
  
  public void setGroupVisible(int paramInt, boolean paramBoolean) {
    ((l)this.c).setGroupVisible(paramInt, paramBoolean);
  }
  
  public void setQwertyMode(boolean paramBoolean) {
    this.c.setQwertyMode(paramBoolean);
  }
  
  public int size() {
    return ((l)this.c).size();
  }
}


/* Location:              C:\soft\dex2jar-2.0\Https Traffic-dex2jar.jar!\c\b\g\n\a0.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */