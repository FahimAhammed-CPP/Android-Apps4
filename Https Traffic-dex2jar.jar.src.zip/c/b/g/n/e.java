package c.b.g.n;

import android.view.MenuItem;

public class e implements Runnable {
  public e(f paramf, g paramg, MenuItem paramMenuItem, l paraml) {}
  
  public void run() {
    g g1 = this.e;
    if (g1 != null) {
      this.h.e.E = true;
      g1.b.c(false);
      this.h.e.E = false;
    } 
    if (this.f.isEnabled() && this.f.hasSubMenu())
      this.g.r(this.f, 4); 
  }
}


/* Location:              C:\soft\dex2jar-2.0\Https Traffic-dex2jar.jar!\c\b\g\n\e.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */