package c.b.g.n;

import android.content.Context;
import android.view.MenuItem;
import c.e.i;

public abstract class b {
  public final Context a;
  
  public i<c.h.e.a.b, MenuItem> b;
  
  public b(Context paramContext) {
    this.a = paramContext;
  }
  
  public final MenuItem c(MenuItem paramMenuItem) {
    MenuItem menuItem = paramMenuItem;
    if (paramMenuItem instanceof c.h.e.a.b) {
      c.h.e.a.b b1 = (c.h.e.a.b)paramMenuItem;
      if (this.b == null)
        this.b = new i(); 
      paramMenuItem = (MenuItem)this.b.getOrDefault(paramMenuItem, null);
      menuItem = paramMenuItem;
      if (paramMenuItem == null) {
        menuItem = new u(this.a, b1);
        this.b.put(b1, menuItem);
      } 
    } 
    return menuItem;
  }
}


/* Location:              C:\soft\dex2jar-2.0\Https Traffic-dex2jar.jar!\c\b\g\n\b.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */