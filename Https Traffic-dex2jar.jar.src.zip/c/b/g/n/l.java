package c.b.g.n;

import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.content.pm.ActivityInfo;
import android.content.pm.PackageManager;
import android.content.pm.ResolveInfo;
import android.content.res.Resources;
import android.graphics.drawable.Drawable;
import android.os.Build;
import android.os.Bundle;
import android.util.SparseArray;
import android.view.KeyCharacterMap;
import android.view.KeyEvent;
import android.view.MenuItem;
import android.view.SubMenu;
import android.view.View;
import android.view.ViewConfiguration;
import c.h.e.a.a;
import c.h.j.v;
import java.lang.ref.WeakReference;
import java.lang.reflect.Method;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.concurrent.CopyOnWriteArrayList;

public class l implements a {
  public static final int[] y = new int[] { 1, 4, 5, 3, 2, 0 };
  
  public final Context a;
  
  public final Resources b;
  
  public boolean c;
  
  public boolean d;
  
  public a e;
  
  public ArrayList<o> f;
  
  public ArrayList<o> g;
  
  public boolean h;
  
  public ArrayList<o> i;
  
  public ArrayList<o> j;
  
  public boolean k;
  
  public int l;
  
  public CharSequence m;
  
  public Drawable n;
  
  public View o;
  
  public boolean p;
  
  public boolean q;
  
  public boolean r;
  
  public boolean s;
  
  public ArrayList<o> t;
  
  public CopyOnWriteArrayList<WeakReference<y>> u;
  
  public o v;
  
  public boolean w;
  
  public boolean x;
  
  public l(Context paramContext) {
    boolean bool2 = false;
    this.l = 0;
    this.p = false;
    this.q = false;
    this.r = false;
    this.s = false;
    this.t = new ArrayList<o>();
    this.u = new CopyOnWriteArrayList<WeakReference<y>>();
    this.w = false;
    this.a = paramContext;
    Resources resources = paramContext.getResources();
    this.b = resources;
    this.f = new ArrayList<o>();
    this.g = new ArrayList<o>();
    this.h = true;
    this.i = new ArrayList<o>();
    this.j = new ArrayList<o>();
    this.k = true;
    boolean bool1 = bool2;
    if ((resources.getConfiguration()).keyboard != 1) {
      boolean bool;
      ViewConfiguration viewConfiguration = ViewConfiguration.get(paramContext);
      Method method = v.a;
      if (Build.VERSION.SDK_INT >= 28) {
        bool = viewConfiguration.shouldShowMenuShortcutsWhenKeyboardPresent();
      } else {
        Resources resources1 = paramContext.getResources();
        int i = resources1.getIdentifier("config_showMenuShortcutsWhenKeyboardPresent", "bool", "android");
        if (i != 0 && resources1.getBoolean(i)) {
          bool = true;
        } else {
          bool = false;
        } 
      } 
      bool1 = bool2;
      if (bool)
        bool1 = true; 
    } 
    this.d = bool1;
  }
  
  public MenuItem a(int paramInt1, int paramInt2, int paramInt3, CharSequence paramCharSequence) {
    int i = (0xFFFF0000 & paramInt3) >> 16;
    if (i >= 0) {
      int[] arrayOfInt = y;
      if (i < arrayOfInt.length) {
        i = arrayOfInt[i] << 16 | 0xFFFF & paramInt3;
        o o1 = new o(this, paramInt1, paramInt2, paramInt3, i, paramCharSequence, this.l);
        ArrayList<o> arrayList = this.f;
        paramInt1 = arrayList.size();
        while (true) {
          paramInt2 = paramInt1 - 1;
          if (paramInt2 >= 0) {
            paramInt1 = paramInt2;
            if (((o)arrayList.get(paramInt2)).d <= i) {
              paramInt1 = paramInt2 + 1;
              arrayList.add(paramInt1, o1);
              q(true);
              return (MenuItem)o1;
            } 
            continue;
          } 
          paramInt1 = 0;
          arrayList.add(paramInt1, o1);
          q(true);
          return (MenuItem)o1;
        } 
      } 
    } 
    throw new IllegalArgumentException("order does not contain a valid category.");
  }
  
  public MenuItem add(int paramInt) {
    return a(0, 0, 0, this.b.getString(paramInt));
  }
  
  public MenuItem add(int paramInt1, int paramInt2, int paramInt3, int paramInt4) {
    return a(paramInt1, paramInt2, paramInt3, this.b.getString(paramInt4));
  }
  
  public MenuItem add(int paramInt1, int paramInt2, int paramInt3, CharSequence paramCharSequence) {
    return a(paramInt1, paramInt2, paramInt3, paramCharSequence);
  }
  
  public MenuItem add(CharSequence paramCharSequence) {
    return a(0, 0, 0, paramCharSequence);
  }
  
  public int addIntentOptions(int paramInt1, int paramInt2, int paramInt3, ComponentName paramComponentName, Intent[] paramArrayOfIntent, Intent paramIntent, int paramInt4, MenuItem[] paramArrayOfMenuItem) {
    byte b1;
    PackageManager packageManager = this.a.getPackageManager();
    byte b2 = 0;
    List<ResolveInfo> list = packageManager.queryIntentActivityOptions(paramComponentName, paramArrayOfIntent, paramIntent, 0);
    if (list != null) {
      b1 = list.size();
    } else {
      b1 = 0;
    } 
    int i = b2;
    if ((paramInt4 & 0x1) == 0) {
      removeGroup(paramInt1);
      i = b2;
    } 
    while (i < b1) {
      ResolveInfo resolveInfo = list.get(i);
      paramInt4 = resolveInfo.specificIndex;
      if (paramInt4 < 0) {
        intent = paramIntent;
      } else {
        intent = paramArrayOfIntent[paramInt4];
      } 
      Intent intent = new Intent(intent);
      ActivityInfo activityInfo = resolveInfo.activityInfo;
      intent.setComponent(new ComponentName(activityInfo.applicationInfo.packageName, activityInfo.name));
      MenuItem menuItem = a(paramInt1, paramInt2, paramInt3, resolveInfo.loadLabel(packageManager));
      Drawable drawable = resolveInfo.loadIcon(packageManager);
      o o1 = (o)menuItem;
      o1.setIcon(drawable);
      o1.setIntent(intent);
      if (paramArrayOfMenuItem != null) {
        paramInt4 = resolveInfo.specificIndex;
        if (paramInt4 >= 0)
          paramArrayOfMenuItem[paramInt4] = (MenuItem)o1; 
      } 
      i++;
    } 
    return b1;
  }
  
  public SubMenu addSubMenu(int paramInt) {
    return addSubMenu(0, 0, 0, this.b.getString(paramInt));
  }
  
  public SubMenu addSubMenu(int paramInt1, int paramInt2, int paramInt3, int paramInt4) {
    return addSubMenu(paramInt1, paramInt2, paramInt3, this.b.getString(paramInt4));
  }
  
  public SubMenu addSubMenu(int paramInt1, int paramInt2, int paramInt3, CharSequence paramCharSequence) {
    o o1 = (o)a(paramInt1, paramInt2, paramInt3, paramCharSequence);
    f0 f0 = new f0(this.a, this, o1);
    o1.o = f0;
    f0.setHeaderTitle(o1.e);
    return f0;
  }
  
  public SubMenu addSubMenu(CharSequence paramCharSequence) {
    return addSubMenu(0, 0, 0, paramCharSequence);
  }
  
  public void b(y paramy, Context paramContext) {
    this.u.add(new WeakReference<y>(paramy));
    paramy.c(paramContext, this);
    this.k = true;
  }
  
  public final void c(boolean paramBoolean) {
    if (this.s)
      return; 
    this.s = true;
    for (WeakReference<y> weakReference : this.u) {
      y y = weakReference.get();
      if (y == null) {
        this.u.remove(weakReference);
        continue;
      } 
      y.a(this, paramBoolean);
    } 
    this.s = false;
  }
  
  public void clear() {
    o o1 = this.v;
    if (o1 != null)
      d(o1); 
    this.f.clear();
    q(true);
  }
  
  public void clearHeader() {
    this.n = null;
    this.m = null;
    this.o = null;
    q(false);
  }
  
  public void close() {
    c(true);
  }
  
  public boolean d(o paramo) {
    boolean bool3 = this.u.isEmpty();
    boolean bool1 = false;
    boolean bool2 = false;
    if (!bool3) {
      if (this.v != paramo)
        return false; 
      z();
      Iterator<WeakReference<y>> iterator = this.u.iterator();
      bool1 = bool2;
      while (true) {
        bool2 = bool1;
        if (iterator.hasNext()) {
          WeakReference<y> weakReference = iterator.next();
          y y = weakReference.get();
          if (y == null) {
            this.u.remove(weakReference);
            continue;
          } 
          bool2 = y.k(this, paramo);
          bool1 = bool2;
          if (bool2)
            break; 
          continue;
        } 
        break;
      } 
      y();
      bool1 = bool2;
      if (bool2) {
        this.v = null;
        bool1 = bool2;
      } 
    } 
    return bool1;
  }
  
  public boolean e(l paraml, MenuItem paramMenuItem) {
    a a1 = this.e;
    return (a1 != null && a1.a(paraml, paramMenuItem));
  }
  
  public boolean f(o paramo) {
    boolean bool2 = this.u.isEmpty();
    boolean bool1 = false;
    if (bool2)
      return false; 
    z();
    Iterator<WeakReference<y>> iterator = this.u.iterator();
    while (true) {
      bool2 = bool1;
      if (iterator.hasNext()) {
        WeakReference<y> weakReference = iterator.next();
        y y = weakReference.get();
        if (y == null) {
          this.u.remove(weakReference);
          continue;
        } 
        bool2 = y.l(this, paramo);
        bool1 = bool2;
        if (bool2)
          break; 
        continue;
      } 
      break;
    } 
    y();
    if (bool2)
      this.v = paramo; 
    return bool2;
  }
  
  public MenuItem findItem(int paramInt) {
    int j = size();
    for (int i = 0; i < j; i++) {
      o o1 = this.f.get(i);
      if (o1.a == paramInt)
        return (MenuItem)o1; 
      if (o1.hasSubMenu()) {
        MenuItem menuItem = o1.o.findItem(paramInt);
        if (menuItem != null)
          return menuItem; 
      } 
    } 
    return null;
  }
  
  public o g(int paramInt, KeyEvent paramKeyEvent) {
    ArrayList<o> arrayList = this.t;
    arrayList.clear();
    h(arrayList, paramInt, paramKeyEvent);
    if (arrayList.isEmpty())
      return null; 
    int j = paramKeyEvent.getMetaState();
    KeyCharacterMap.KeyData keyData = new KeyCharacterMap.KeyData();
    paramKeyEvent.getKeyData(keyData);
    int k = arrayList.size();
    if (k == 1)
      return arrayList.get(0); 
    boolean bool = n();
    for (int i = 0; i < k; i++) {
      char c;
      o o1 = arrayList.get(i);
      if (bool) {
        c = o1.j;
      } else {
        c = o1.h;
      } 
      char[] arrayOfChar = keyData.meta;
      if ((c == arrayOfChar[0] && (j & 0x2) == 0) || (c == arrayOfChar[2] && (j & 0x2) != 0) || (bool && c == '\b' && paramInt == 67))
        return o1; 
    } 
    return null;
  }
  
  public MenuItem getItem(int paramInt) {
    return (MenuItem)this.f.get(paramInt);
  }
  
  public void h(List<o> paramList, int paramInt, KeyEvent paramKeyEvent) {
    boolean bool = n();
    int j = paramKeyEvent.getModifiers();
    KeyCharacterMap.KeyData keyData = new KeyCharacterMap.KeyData();
    if (!paramKeyEvent.getKeyData(keyData) && paramInt != 67)
      return; 
    int k = this.f.size();
    int i;
    for (i = 0; i < k; i++) {
      char c;
      int m;
      o o1 = this.f.get(i);
      if (o1.hasSubMenu())
        o1.o.h(paramList, paramInt, paramKeyEvent); 
      if (bool) {
        c = o1.j;
      } else {
        c = o1.h;
      } 
      if (bool) {
        m = o1.k;
      } else {
        m = o1.i;
      } 
      if ((j & 0x1100F) == (m & 0x1100F)) {
        m = 1;
      } else {
        m = 0;
      } 
      if (m != 0 && c != '\000') {
        char[] arrayOfChar = keyData.meta;
        if ((c == arrayOfChar[0] || c == arrayOfChar[2] || (bool && c == '\b' && paramInt == 67)) && o1.isEnabled())
          paramList.add(o1); 
      } 
    } 
  }
  
  public boolean hasVisibleItems() {
    if (this.x)
      return true; 
    int j = size();
    for (int i = 0; i < j; i++) {
      if (((o)this.f.get(i)).isVisible())
        return true; 
    } 
    return false;
  }
  
  public void i() {
    ArrayList<o> arrayList = l();
    if (!this.k)
      return; 
    Iterator<WeakReference<y>> iterator = this.u.iterator();
    boolean bool;
    for (bool = false; iterator.hasNext(); bool |= y.i()) {
      WeakReference<y> weakReference = iterator.next();
      y y = weakReference.get();
      if (y == null) {
        this.u.remove(weakReference);
        continue;
      } 
    } 
    if (bool) {
      this.i.clear();
      this.j.clear();
      int i = arrayList.size();
      bool = false;
      while (bool < i) {
        o o1 = arrayList.get(bool);
        if (o1.g()) {
          this.i.add(o1);
        } else {
          this.j.add(o1);
        } 
        int j = bool + 1;
      } 
    } else {
      this.i.clear();
      this.j.clear();
      this.j.addAll(l());
    } 
    this.k = false;
  }
  
  public boolean isShortcutKey(int paramInt, KeyEvent paramKeyEvent) {
    return (g(paramInt, paramKeyEvent) != null);
  }
  
  public String j() {
    return "android:menu:actionviewstates";
  }
  
  public l k() {
    return this;
  }
  
  public ArrayList<o> l() {
    if (!this.h)
      return this.g; 
    this.g.clear();
    int j = this.f.size();
    for (int i = 0; i < j; i++) {
      o o1 = this.f.get(i);
      if (o1.isVisible())
        this.g.add(o1); 
    } 
    this.h = false;
    this.k = true;
    return this.g;
  }
  
  public boolean m() {
    return this.w;
  }
  
  public boolean n() {
    return this.c;
  }
  
  public boolean o() {
    return this.d;
  }
  
  public void p() {
    this.k = true;
    q(true);
  }
  
  public boolean performIdentifierAction(int paramInt1, int paramInt2) {
    return r(findItem(paramInt1), paramInt2);
  }
  
  public boolean performShortcut(int paramInt1, KeyEvent paramKeyEvent, int paramInt2) {
    boolean bool;
    o o1 = g(paramInt1, paramKeyEvent);
    if (o1 != null) {
      bool = s((MenuItem)o1, null, paramInt2);
    } else {
      bool = false;
    } 
    if ((paramInt2 & 0x2) != 0)
      c(true); 
    return bool;
  }
  
  public void q(boolean paramBoolean) {
    if (!this.p) {
      if (paramBoolean) {
        this.h = true;
        this.k = true;
      } 
      if (this.u.isEmpty())
        return; 
      z();
      for (WeakReference<y> weakReference : this.u) {
        y y = weakReference.get();
        if (y == null) {
          this.u.remove(weakReference);
          continue;
        } 
        y.h(paramBoolean);
      } 
      y();
      return;
    } 
    this.q = true;
    if (paramBoolean)
      this.r = true; 
  }
  
  public boolean r(MenuItem paramMenuItem, int paramInt) {
    return s(paramMenuItem, null, paramInt);
  }
  
  public void removeGroup(int paramInt) {
    // Byte code:
    //   0: aload_0
    //   1: invokevirtual size : ()I
    //   4: istore_3
    //   5: iconst_0
    //   6: istore_2
    //   7: iload_2
    //   8: iload_3
    //   9: if_icmpge -> 40
    //   12: aload_0
    //   13: getfield f : Ljava/util/ArrayList;
    //   16: iload_2
    //   17: invokevirtual get : (I)Ljava/lang/Object;
    //   20: checkcast c/b/g/n/o
    //   23: getfield b : I
    //   26: iload_1
    //   27: if_icmpne -> 33
    //   30: goto -> 42
    //   33: iload_2
    //   34: iconst_1
    //   35: iadd
    //   36: istore_2
    //   37: goto -> 7
    //   40: iconst_m1
    //   41: istore_2
    //   42: iload_2
    //   43: iflt -> 101
    //   46: aload_0
    //   47: getfield f : Ljava/util/ArrayList;
    //   50: invokevirtual size : ()I
    //   53: istore #4
    //   55: iconst_0
    //   56: istore_3
    //   57: iload_3
    //   58: iload #4
    //   60: iload_2
    //   61: isub
    //   62: if_icmpge -> 96
    //   65: aload_0
    //   66: getfield f : Ljava/util/ArrayList;
    //   69: iload_2
    //   70: invokevirtual get : (I)Ljava/lang/Object;
    //   73: checkcast c/b/g/n/o
    //   76: getfield b : I
    //   79: iload_1
    //   80: if_icmpne -> 96
    //   83: aload_0
    //   84: iload_2
    //   85: iconst_0
    //   86: invokevirtual t : (IZ)V
    //   89: iload_3
    //   90: iconst_1
    //   91: iadd
    //   92: istore_3
    //   93: goto -> 57
    //   96: aload_0
    //   97: iconst_1
    //   98: invokevirtual q : (Z)V
    //   101: return
  }
  
  public void removeItem(int paramInt) {
    // Byte code:
    //   0: aload_0
    //   1: invokevirtual size : ()I
    //   4: istore_3
    //   5: iconst_0
    //   6: istore_2
    //   7: iload_2
    //   8: iload_3
    //   9: if_icmpge -> 40
    //   12: aload_0
    //   13: getfield f : Ljava/util/ArrayList;
    //   16: iload_2
    //   17: invokevirtual get : (I)Ljava/lang/Object;
    //   20: checkcast c/b/g/n/o
    //   23: getfield a : I
    //   26: iload_1
    //   27: if_icmpne -> 33
    //   30: goto -> 42
    //   33: iload_2
    //   34: iconst_1
    //   35: iadd
    //   36: istore_2
    //   37: goto -> 7
    //   40: iconst_m1
    //   41: istore_2
    //   42: aload_0
    //   43: iload_2
    //   44: iconst_1
    //   45: invokevirtual t : (IZ)V
    //   48: return
  }
  
  public boolean s(MenuItem paramMenuItem, y paramy, int paramInt) {
    // Byte code:
    //   0: aload_1
    //   1: checkcast c/b/g/n/o
    //   4: astore_1
    //   5: iconst_0
    //   6: istore #7
    //   8: iconst_0
    //   9: istore #6
    //   11: aload_1
    //   12: ifnull -> 450
    //   15: aload_1
    //   16: invokevirtual isEnabled : ()Z
    //   19: ifne -> 24
    //   22: iconst_0
    //   23: ireturn
    //   24: aload_1
    //   25: getfield p : Landroid/view/MenuItem$OnMenuItemClickListener;
    //   28: astore #8
    //   30: aload #8
    //   32: ifnull -> 49
    //   35: aload #8
    //   37: aload_1
    //   38: invokeinterface onMenuItemClick : (Landroid/view/MenuItem;)Z
    //   43: ifeq -> 49
    //   46: goto -> 131
    //   49: aload_1
    //   50: getfield n : Lc/b/g/n/l;
    //   53: astore #8
    //   55: aload #8
    //   57: aload #8
    //   59: aload_1
    //   60: invokevirtual e : (Lc/b/g/n/l;Landroid/view/MenuItem;)Z
    //   63: ifeq -> 69
    //   66: goto -> 131
    //   69: aload_1
    //   70: getfield g : Landroid/content/Intent;
    //   73: astore #8
    //   75: aload #8
    //   77: ifnull -> 109
    //   80: aload_1
    //   81: getfield n : Lc/b/g/n/l;
    //   84: getfield a : Landroid/content/Context;
    //   87: aload #8
    //   89: invokevirtual startActivity : (Landroid/content/Intent;)V
    //   92: goto -> 131
    //   95: astore #8
    //   97: ldc_w 'MenuItemImpl'
    //   100: ldc_w 'Can't find activity to handle intent; ignoring'
    //   103: aload #8
    //   105: invokestatic e : (Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)I
    //   108: pop
    //   109: aload_1
    //   110: getfield A : Lc/b/g/n/p;
    //   113: astore #8
    //   115: aload #8
    //   117: ifnull -> 137
    //   120: aload #8
    //   122: getfield b : Landroid/view/ActionProvider;
    //   125: invokevirtual onPerformDefaultAction : ()Z
    //   128: ifeq -> 137
    //   131: iconst_1
    //   132: istore #5
    //   134: goto -> 140
    //   137: iconst_0
    //   138: istore #5
    //   140: aload_1
    //   141: getfield A : Lc/b/g/n/p;
    //   144: astore #8
    //   146: aload #8
    //   148: ifnull -> 168
    //   151: aload #8
    //   153: getfield b : Landroid/view/ActionProvider;
    //   156: invokevirtual hasSubMenu : ()Z
    //   159: ifeq -> 168
    //   162: iconst_1
    //   163: istore #4
    //   165: goto -> 171
    //   168: iconst_0
    //   169: istore #4
    //   171: aload_1
    //   172: invokevirtual f : ()Z
    //   175: ifeq -> 204
    //   178: iload #5
    //   180: aload_1
    //   181: invokevirtual expandActionView : ()Z
    //   184: ior
    //   185: istore #5
    //   187: iload #5
    //   189: istore #6
    //   191: iload #5
    //   193: ifeq -> 447
    //   196: aload_0
    //   197: iconst_1
    //   198: invokevirtual c : (Z)V
    //   201: iload #5
    //   203: ireturn
    //   204: aload_1
    //   205: invokevirtual hasSubMenu : ()Z
    //   208: ifne -> 237
    //   211: iload #4
    //   213: ifeq -> 219
    //   216: goto -> 237
    //   219: iload #5
    //   221: istore #6
    //   223: iload_3
    //   224: iconst_1
    //   225: iand
    //   226: ifne -> 447
    //   229: aload_0
    //   230: iconst_1
    //   231: invokevirtual c : (Z)V
    //   234: iload #5
    //   236: ireturn
    //   237: iload_3
    //   238: iconst_4
    //   239: iand
    //   240: ifne -> 248
    //   243: aload_0
    //   244: iconst_0
    //   245: invokevirtual c : (Z)V
    //   248: aload_1
    //   249: invokevirtual hasSubMenu : ()Z
    //   252: ifne -> 286
    //   255: new c/b/g/n/f0
    //   258: dup
    //   259: aload_0
    //   260: getfield a : Landroid/content/Context;
    //   263: aload_0
    //   264: aload_1
    //   265: invokespecial <init> : (Landroid/content/Context;Lc/b/g/n/l;Lc/b/g/n/o;)V
    //   268: astore #9
    //   270: aload_1
    //   271: aload #9
    //   273: putfield o : Lc/b/g/n/f0;
    //   276: aload #9
    //   278: aload_1
    //   279: getfield e : Ljava/lang/CharSequence;
    //   282: invokevirtual setHeaderTitle : (Ljava/lang/CharSequence;)Landroid/view/SubMenu;
    //   285: pop
    //   286: aload_1
    //   287: getfield o : Lc/b/g/n/f0;
    //   290: astore_1
    //   291: iload #4
    //   293: ifeq -> 318
    //   296: aload #8
    //   298: getfield b : Landroid/view/ActionProvider;
    //   301: astore #9
    //   303: aload #8
    //   305: getfield c : Lc/b/g/n/u;
    //   308: invokestatic requireNonNull : (Ljava/lang/Object;)Ljava/lang/Object;
    //   311: pop
    //   312: aload #9
    //   314: aload_1
    //   315: invokevirtual onPrepareSubMenu : (Landroid/view/SubMenu;)V
    //   318: aload_0
    //   319: getfield u : Ljava/util/concurrent/CopyOnWriteArrayList;
    //   322: invokevirtual isEmpty : ()Z
    //   325: ifeq -> 331
    //   328: goto -> 422
    //   331: aload_2
    //   332: ifnull -> 344
    //   335: aload_2
    //   336: aload_1
    //   337: invokeinterface f : (Lc/b/g/n/f0;)Z
    //   342: istore #6
    //   344: aload_0
    //   345: getfield u : Ljava/util/concurrent/CopyOnWriteArrayList;
    //   348: invokevirtual iterator : ()Ljava/util/Iterator;
    //   351: astore_2
    //   352: iload #6
    //   354: istore #7
    //   356: aload_2
    //   357: invokeinterface hasNext : ()Z
    //   362: ifeq -> 422
    //   365: aload_2
    //   366: invokeinterface next : ()Ljava/lang/Object;
    //   371: checkcast java/lang/ref/WeakReference
    //   374: astore #8
    //   376: aload #8
    //   378: invokevirtual get : ()Ljava/lang/Object;
    //   381: checkcast c/b/g/n/y
    //   384: astore #9
    //   386: aload #9
    //   388: ifnonnull -> 404
    //   391: aload_0
    //   392: getfield u : Ljava/util/concurrent/CopyOnWriteArrayList;
    //   395: aload #8
    //   397: invokevirtual remove : (Ljava/lang/Object;)Z
    //   400: pop
    //   401: goto -> 352
    //   404: iload #6
    //   406: ifne -> 352
    //   409: aload #9
    //   411: aload_1
    //   412: invokeinterface f : (Lc/b/g/n/f0;)Z
    //   417: istore #6
    //   419: goto -> 352
    //   422: iload #5
    //   424: iload #7
    //   426: ior
    //   427: istore #5
    //   429: iload #5
    //   431: istore #6
    //   433: iload #5
    //   435: ifne -> 447
    //   438: aload_0
    //   439: iconst_1
    //   440: invokevirtual c : (Z)V
    //   443: iload #5
    //   445: istore #6
    //   447: iload #6
    //   449: ireturn
    //   450: iconst_0
    //   451: ireturn
    // Exception table:
    //   from	to	target	type
    //   80	92	95	android/content/ActivityNotFoundException
  }
  
  public void setGroupCheckable(int paramInt, boolean paramBoolean1, boolean paramBoolean2) {
    int j = this.f.size();
    int i;
    for (i = 0; i < j; i++) {
      o o1 = this.f.get(i);
      if (o1.b == paramInt) {
        o1.k(paramBoolean2);
        o1.setCheckable(paramBoolean1);
      } 
    } 
  }
  
  public void setGroupDividerEnabled(boolean paramBoolean) {
    this.w = paramBoolean;
  }
  
  public void setGroupEnabled(int paramInt, boolean paramBoolean) {
    int j = this.f.size();
    for (int i = 0; i < j; i++) {
      o o1 = this.f.get(i);
      if (o1.b == paramInt)
        o1.setEnabled(paramBoolean); 
    } 
  }
  
  public void setGroupVisible(int paramInt, boolean paramBoolean) {
    int j = this.f.size();
    int i = 0;
    boolean bool;
    for (bool = false; i < j; bool = bool1) {
      o o1 = this.f.get(i);
      boolean bool1 = bool;
      if (o1.b == paramInt) {
        bool1 = bool;
        if (o1.m(paramBoolean))
          bool1 = true; 
      } 
      i++;
    } 
    if (bool)
      q(true); 
  }
  
  public void setQwertyMode(boolean paramBoolean) {
    this.c = paramBoolean;
    q(false);
  }
  
  public int size() {
    return this.f.size();
  }
  
  public final void t(int paramInt, boolean paramBoolean) {
    if (paramInt >= 0) {
      if (paramInt >= this.f.size())
        return; 
      this.f.remove(paramInt);
      if (paramBoolean)
        q(true); 
    } 
  }
  
  public void u(y paramy) {
    for (WeakReference<y> weakReference : this.u) {
      y y1 = weakReference.get();
      if (y1 == null || y1 == paramy)
        this.u.remove(weakReference); 
    } 
  }
  
  public void v(Bundle paramBundle) {
    if (paramBundle == null)
      return; 
    SparseArray sparseArray = paramBundle.getSparseParcelableArray(j());
    int j = size();
    int i;
    for (i = 0; i < j; i++) {
      MenuItem menuItem = getItem(i);
      View view = menuItem.getActionView();
      if (view != null && view.getId() != -1)
        view.restoreHierarchyState(sparseArray); 
      if (menuItem.hasSubMenu())
        ((f0)menuItem.getSubMenu()).v(paramBundle); 
    } 
    i = paramBundle.getInt("android:menu:expandedactionview");
    if (i > 0) {
      MenuItem menuItem = findItem(i);
      if (menuItem != null)
        menuItem.expandActionView(); 
    } 
  }
  
  public void w(Bundle paramBundle) {
    int j = size();
    SparseArray sparseArray = null;
    int i = 0;
    while (i < j) {
      MenuItem menuItem = getItem(i);
      View view = menuItem.getActionView();
      SparseArray sparseArray1 = sparseArray;
      if (view != null) {
        sparseArray1 = sparseArray;
        if (view.getId() != -1) {
          SparseArray sparseArray2 = sparseArray;
          if (sparseArray == null)
            sparseArray2 = new SparseArray(); 
          view.saveHierarchyState(sparseArray2);
          sparseArray1 = sparseArray2;
          if (menuItem.isActionViewExpanded()) {
            paramBundle.putInt("android:menu:expandedactionview", menuItem.getItemId());
            sparseArray1 = sparseArray2;
          } 
        } 
      } 
      if (menuItem.hasSubMenu())
        ((f0)menuItem.getSubMenu()).w(paramBundle); 
      i++;
      sparseArray = sparseArray1;
    } 
    if (sparseArray != null)
      paramBundle.putSparseParcelableArray(j(), sparseArray); 
  }
  
  public final void x(int paramInt1, CharSequence paramCharSequence, int paramInt2, Drawable paramDrawable, View paramView) {
    Resources resources = this.b;
    if (paramView != null) {
      this.o = paramView;
      this.m = null;
      this.n = null;
    } else {
      Object object;
      if (paramInt1 > 0) {
        this.m = resources.getText(paramInt1);
      } else if (paramCharSequence != null) {
        this.m = paramCharSequence;
      } 
      if (paramInt2 > 0) {
        Context context = this.a;
        object = c.h.b.b.a;
        this.n = c.h.c.b.b(context, paramInt2);
      } else if (object != null) {
        this.n = (Drawable)object;
      } 
      this.o = null;
    } 
    q(false);
  }
  
  public void y() {
    this.p = false;
    if (this.q) {
      this.q = false;
      q(this.r);
    } 
  }
  
  public void z() {
    if (!this.p) {
      this.p = true;
      this.q = false;
      this.r = false;
    } 
  }
  
  public static interface a {
    boolean a(l param1l, MenuItem param1MenuItem);
    
    void b(l param1l);
  }
  
  public static interface b {
    boolean a(o param1o);
  }
}


/* Location:              C:\soft\dex2jar-2.0\Https Traffic-dex2jar.jar!\c\b\g\n\l.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */