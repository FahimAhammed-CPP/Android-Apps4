package c.b.g.n;

import android.view.MenuItem;
import c.b.h.r1;

public class f implements r1 {
  public f(h paramh) {}
  
  public void c(l paraml, MenuItem paramMenuItem) {
    // Byte code:
    //   0: aload_0
    //   1: getfield e : Lc/b/g/n/h;
    //   4: getfield k : Landroid/os/Handler;
    //   7: astore #8
    //   9: aconst_null
    //   10: astore #7
    //   12: aload #8
    //   14: aconst_null
    //   15: invokevirtual removeCallbacksAndMessages : (Ljava/lang/Object;)V
    //   18: aload_0
    //   19: getfield e : Lc/b/g/n/h;
    //   22: getfield m : Ljava/util/List;
    //   25: invokeinterface size : ()I
    //   30: istore #4
    //   32: iconst_0
    //   33: istore_3
    //   34: iload_3
    //   35: iload #4
    //   37: if_icmpge -> 73
    //   40: aload_1
    //   41: aload_0
    //   42: getfield e : Lc/b/g/n/h;
    //   45: getfield m : Ljava/util/List;
    //   48: iload_3
    //   49: invokeinterface get : (I)Ljava/lang/Object;
    //   54: checkcast c/b/g/n/g
    //   57: getfield b : Lc/b/g/n/l;
    //   60: if_acmpne -> 66
    //   63: goto -> 75
    //   66: iload_3
    //   67: iconst_1
    //   68: iadd
    //   69: istore_3
    //   70: goto -> 34
    //   73: iconst_m1
    //   74: istore_3
    //   75: iload_3
    //   76: iconst_m1
    //   77: if_icmpne -> 81
    //   80: return
    //   81: iload_3
    //   82: iconst_1
    //   83: iadd
    //   84: istore_3
    //   85: iload_3
    //   86: aload_0
    //   87: getfield e : Lc/b/g/n/h;
    //   90: getfield m : Ljava/util/List;
    //   93: invokeinterface size : ()I
    //   98: if_icmpge -> 119
    //   101: aload_0
    //   102: getfield e : Lc/b/g/n/h;
    //   105: getfield m : Ljava/util/List;
    //   108: iload_3
    //   109: invokeinterface get : (I)Ljava/lang/Object;
    //   114: checkcast c/b/g/n/g
    //   117: astore #7
    //   119: new c/b/g/n/e
    //   122: dup
    //   123: aload_0
    //   124: aload #7
    //   126: aload_2
    //   127: aload_1
    //   128: invokespecial <init> : (Lc/b/g/n/f;Lc/b/g/n/g;Landroid/view/MenuItem;Lc/b/g/n/l;)V
    //   131: astore_2
    //   132: invokestatic uptimeMillis : ()J
    //   135: lstore #5
    //   137: aload_0
    //   138: getfield e : Lc/b/g/n/h;
    //   141: getfield k : Landroid/os/Handler;
    //   144: aload_2
    //   145: aload_1
    //   146: lload #5
    //   148: ldc2_w 200
    //   151: ladd
    //   152: invokevirtual postAtTime : (Ljava/lang/Runnable;Ljava/lang/Object;J)Z
    //   155: pop
    //   156: return
  }
  
  public void e(l paraml, MenuItem paramMenuItem) {
    this.e.k.removeCallbacksAndMessages(paraml);
  }
}


/* Location:              C:\soft\dex2jar-2.0\Https Traffic-dex2jar.jar!\c\b\g\n\f.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */