package c.b.g.n;

import android.content.DialogInterface;
import android.view.KeyEvent;
import android.view.MenuItem;
import android.view.View;
import android.view.Window;
import c.b.c.o;

public class m implements DialogInterface.OnKeyListener, DialogInterface.OnClickListener, DialogInterface.OnDismissListener, y.a {
  public l e;
  
  public o f;
  
  public j g;
  
  public m(l paraml) {
    this.e = paraml;
  }
  
  public void a(l paraml, boolean paramBoolean) {
    if (paramBoolean || paraml == this.e) {
      o o1 = this.f;
      if (o1 != null)
        o1.dismiss(); 
    } 
  }
  
  public boolean b(l paraml) {
    return false;
  }
  
  public void onClick(DialogInterface paramDialogInterface, int paramInt) {
    this.e.r((MenuItem)((i)this.g.b()).b(paramInt), 0);
  }
  
  public void onDismiss(DialogInterface paramDialogInterface) {
    j j1 = this.g;
    l l1 = this.e;
    y.a a1 = j1.i;
    if (a1 != null)
      a1.a(l1, true); 
  }
  
  public boolean onKey(DialogInterface paramDialogInterface, int paramInt, KeyEvent paramKeyEvent) {
    if (paramInt == 82 || paramInt == 4) {
      KeyEvent.DispatcherState dispatcherState;
      if (paramKeyEvent.getAction() == 0 && paramKeyEvent.getRepeatCount() == 0) {
        Window window = this.f.getWindow();
        if (window != null) {
          View view = window.getDecorView();
          if (view != null) {
            dispatcherState = view.getKeyDispatcherState();
            if (dispatcherState != null) {
              dispatcherState.startTracking(paramKeyEvent, this);
              return true;
            } 
          } 
        } 
      } else if (paramKeyEvent.getAction() == 1 && !paramKeyEvent.isCanceled()) {
        Window window = this.f.getWindow();
        if (window != null) {
          View view = window.getDecorView();
          if (view != null) {
            KeyEvent.DispatcherState dispatcherState1 = view.getKeyDispatcherState();
            if (dispatcherState1 != null && dispatcherState1.isTracking(paramKeyEvent)) {
              this.e.c(true);
              dispatcherState.dismiss();
              return true;
            } 
          } 
        } 
      } 
    } 
    return this.e.performShortcut(paramInt, paramKeyEvent, 0);
  }
}


/* Location:              C:\soft\dex2jar-2.0\Https Traffic-dex2jar.jar!\c\b\g\n\m.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */