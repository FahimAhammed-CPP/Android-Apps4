package c.b.g.n;

import android.content.Context;
import android.os.Bundle;
import android.os.Parcelable;
import android.util.SparseArray;
import android.view.LayoutInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.WindowManager;
import android.widget.AdapterView;
import android.widget.ListAdapter;
import androidx.appcompat.view.menu.ExpandedMenuView;
import c.b.c.k;
import c.b.c.n;
import c.b.c.o;

public class j implements y, AdapterView.OnItemClickListener {
  public Context e;
  
  public LayoutInflater f;
  
  public l g;
  
  public ExpandedMenuView h;
  
  public y.a i;
  
  public i j;
  
  public j(Context paramContext, int paramInt) {
    this.e = paramContext;
    this.f = LayoutInflater.from(paramContext);
  }
  
  public void a(l paraml, boolean paramBoolean) {
    y.a a1 = this.i;
    if (a1 != null)
      a1.a(paraml, paramBoolean); 
  }
  
  public ListAdapter b() {
    if (this.j == null)
      this.j = new i(this); 
    return (ListAdapter)this.j;
  }
  
  public void c(Context paramContext, l paraml) {
    if (this.e != null) {
      this.e = paramContext;
      if (this.f == null)
        this.f = LayoutInflater.from(paramContext); 
    } 
    this.g = paraml;
    i i1 = this.j;
    if (i1 != null)
      i1.notifyDataSetChanged(); 
  }
  
  public void e(Parcelable paramParcelable) {
    SparseArray sparseArray = ((Bundle)paramParcelable).getSparseParcelableArray("android:menu:list");
    if (sparseArray != null)
      this.h.restoreHierarchyState(sparseArray); 
  }
  
  public boolean f(f0 paramf0) {
    if (!paramf0.hasVisibleItems())
      return false; 
    m m = new m(paramf0);
    n n = new n(paramf0.a);
    j j1 = new j(n.a.a, 2131427344);
    m.g = j1;
    j1.i = m;
    l l1 = m.e;
    l1.b(j1, l1.a);
    ListAdapter listAdapter = m.g.b();
    k k = n.a;
    k.g = listAdapter;
    k.h = m;
    View view = paramf0.o;
    if (view != null) {
      k.e = view;
    } else {
      k.c = paramf0.n;
      k.d = paramf0.m;
    } 
    k.f = m;
    o o = n.a();
    m.f = o;
    o.setOnDismissListener(m);
    WindowManager.LayoutParams layoutParams = m.f.getWindow().getAttributes();
    layoutParams.type = 1003;
    layoutParams.flags |= 0x20000;
    m.f.show();
    y.a a1 = this.i;
    if (a1 != null)
      a1.b(paramf0); 
    return true;
  }
  
  public int getId() {
    return 0;
  }
  
  public void h(boolean paramBoolean) {
    i i1 = this.j;
    if (i1 != null)
      i1.notifyDataSetChanged(); 
  }
  
  public boolean i() {
    return false;
  }
  
  public Parcelable j() {
    if (this.h == null)
      return null; 
    Bundle bundle = new Bundle();
    SparseArray sparseArray = new SparseArray();
    ExpandedMenuView expandedMenuView = this.h;
    if (expandedMenuView != null)
      expandedMenuView.saveHierarchyState(sparseArray); 
    bundle.putSparseParcelableArray("android:menu:list", sparseArray);
    return (Parcelable)bundle;
  }
  
  public boolean k(l paraml, o paramo) {
    return false;
  }
  
  public boolean l(l paraml, o paramo) {
    return false;
  }
  
  public void m(y.a parama) {
    this.i = parama;
  }
  
  public void onItemClick(AdapterView<?> paramAdapterView, View paramView, int paramInt, long paramLong) {
    this.g.s((MenuItem)this.j.b(paramInt), this, 0);
  }
}


/* Location:              C:\soft\dex2jar-2.0\Https Traffic-dex2jar.jar!\c\b\g\n\j.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */