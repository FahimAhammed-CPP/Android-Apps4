package c.b.g;

import android.content.Context;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import androidx.appcompat.widget.ActionBarContextView;
import c.b.g.n.l;
import c.b.h.b;
import c.b.h.m;
import java.lang.ref.WeakReference;

public class e extends b implements l.a {
  public Context g;
  
  public ActionBarContextView h;
  
  public a i;
  
  public WeakReference<View> j;
  
  public boolean k;
  
  public l l;
  
  public e(Context paramContext, ActionBarContextView paramActionBarContextView, a parama, boolean paramBoolean) {
    this.g = paramContext;
    this.h = paramActionBarContextView;
    this.i = parama;
    l l1 = new l(paramActionBarContextView.getContext());
    l1.l = 1;
    this.l = l1;
    l1.e = this;
  }
  
  public boolean a(l paraml, MenuItem paramMenuItem) {
    return this.i.c(this, paramMenuItem);
  }
  
  public void b(l paraml) {
    i();
    m m = ((b)this.h).h;
    if (m != null)
      m.p(); 
  }
  
  public void c() {
    if (this.k)
      return; 
    this.k = true;
    this.h.sendAccessibilityEvent(32);
    this.i.b(this);
  }
  
  public View d() {
    WeakReference<View> weakReference = this.j;
    return (weakReference != null) ? weakReference.get() : null;
  }
  
  public Menu e() {
    return (Menu)this.l;
  }
  
  public MenuInflater f() {
    return new j(this.h.getContext());
  }
  
  public CharSequence g() {
    return this.h.getSubtitle();
  }
  
  public CharSequence h() {
    return this.h.getTitle();
  }
  
  public void i() {
    this.i.a(this, (Menu)this.l);
  }
  
  public boolean j() {
    return this.h.v;
  }
  
  public void k(View paramView) {
    this.h.setCustomView(paramView);
    if (paramView != null) {
      WeakReference<View> weakReference = new WeakReference<View>(paramView);
    } else {
      paramView = null;
    } 
    this.j = (WeakReference<View>)paramView;
  }
  
  public void l(int paramInt) {
    String str = this.g.getString(paramInt);
    this.h.setSubtitle(str);
  }
  
  public void m(CharSequence paramCharSequence) {
    this.h.setSubtitle(paramCharSequence);
  }
  
  public void n(int paramInt) {
    String str = this.g.getString(paramInt);
    this.h.setTitle(str);
  }
  
  public void o(CharSequence paramCharSequence) {
    this.h.setTitle(paramCharSequence);
  }
  
  public void p(boolean paramBoolean) {
    this.f = paramBoolean;
    this.h.setTitleOptional(paramBoolean);
  }
}


/* Location:              C:\soft\dex2jar-2.0\Https Traffic-dex2jar.jar!\c\b\g\e.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */