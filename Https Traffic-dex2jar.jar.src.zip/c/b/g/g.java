package c.b.g;

import android.content.Context;
import android.view.ActionMode;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.View;
import c.b.g.n.a0;
import c.h.e.a.a;

public class g extends ActionMode {
  public final Context a;
  
  public final b b;
  
  public g(Context paramContext, b paramb) {
    this.a = paramContext;
    this.b = paramb;
  }
  
  public void finish() {
    this.b.c();
  }
  
  public View getCustomView() {
    return this.b.d();
  }
  
  public Menu getMenu() {
    return (Menu)new a0(this.a, (a)this.b.e());
  }
  
  public MenuInflater getMenuInflater() {
    return this.b.f();
  }
  
  public CharSequence getSubtitle() {
    return this.b.g();
  }
  
  public Object getTag() {
    return this.b.e;
  }
  
  public CharSequence getTitle() {
    return this.b.h();
  }
  
  public boolean getTitleOptionalHint() {
    return this.b.f;
  }
  
  public void invalidate() {
    this.b.i();
  }
  
  public boolean isTitleOptional() {
    return this.b.j();
  }
  
  public void setCustomView(View paramView) {
    this.b.k(paramView);
  }
  
  public void setSubtitle(int paramInt) {
    this.b.l(paramInt);
  }
  
  public void setSubtitle(CharSequence paramCharSequence) {
    this.b.m(paramCharSequence);
  }
  
  public void setTag(Object paramObject) {
    this.b.e = paramObject;
  }
  
  public void setTitle(int paramInt) {
    this.b.n(paramInt);
  }
  
  public void setTitle(CharSequence paramCharSequence) {
    this.b.o(paramCharSequence);
  }
  
  public void setTitleOptionalHint(boolean paramBoolean) {
    this.b.p(paramBoolean);
  }
}


/* Location:              C:\soft\dex2jar-2.0\Https Traffic-dex2jar.jar!\c\b\g\g.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */