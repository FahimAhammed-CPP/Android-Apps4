package b.a.b.a;

import android.os.Bundle;
import android.os.IBinder;
import android.os.IInterface;
import android.os.Parcel;
import android.os.Parcelable;

public class e implements Parcelable {
  public static final Parcelable.Creator<e> CREATOR = new c();
  
  public b e;
  
  public e(Parcel paramParcel) {
    b b1;
    IBinder iBinder = paramParcel.readStrongBinder();
    int i = d.f;
    if (iBinder == null) {
      iBinder = null;
    } else {
      IInterface iInterface = iBinder.queryLocalInterface("android.support.v4.os.IResultReceiver");
      if (iInterface != null && iInterface instanceof b) {
        b1 = (b)iInterface;
      } else {
        b1 = new a((IBinder)b1);
      } 
    } 
    this.e = b1;
  }
  
  public void a(int paramInt, Bundle paramBundle) {}
  
  public int describeContents() {
    return 0;
  }
  
  public void writeToParcel(Parcel paramParcel, int paramInt) {
    // Byte code:
    //   0: aload_0
    //   1: monitorenter
    //   2: aload_0
    //   3: getfield e : Lb/a/b/a/b;
    //   6: ifnonnull -> 21
    //   9: aload_0
    //   10: new b/a/b/a/d
    //   13: dup
    //   14: aload_0
    //   15: invokespecial <init> : (Lb/a/b/a/e;)V
    //   18: putfield e : Lb/a/b/a/b;
    //   21: aload_1
    //   22: aload_0
    //   23: getfield e : Lb/a/b/a/b;
    //   26: invokeinterface asBinder : ()Landroid/os/IBinder;
    //   31: invokevirtual writeStrongBinder : (Landroid/os/IBinder;)V
    //   34: aload_0
    //   35: monitorexit
    //   36: return
    //   37: astore_1
    //   38: aload_0
    //   39: monitorexit
    //   40: aload_1
    //   41: athrow
    // Exception table:
    //   from	to	target	type
    //   2	21	37	finally
    //   21	36	37	finally
    //   38	40	37	finally
  }
}


/* Location:              C:\soft\dex2jar-2.0\Https Traffic-dex2jar.jar!\b\a\b\a\e.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */