package b.a.b.a;

import android.os.IBinder;

public class a implements b {
  public IBinder e;
  
  public a(IBinder paramIBinder) {
    this.e = paramIBinder;
  }
  
  public IBinder asBinder() {
    return this.e;
  }
}


/* Location:              C:\soft\dex2jar-2.0\Https Traffic-dex2jar.jar!\b\a\b\a\a.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */