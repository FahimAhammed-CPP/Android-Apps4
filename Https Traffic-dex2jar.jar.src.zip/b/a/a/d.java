package b.a.a;

import android.os.IInterface;

public interface d extends IInterface {}


/* Location:              C:\soft\dex2jar-2.0\Https Traffic-dex2jar.jar!\b\a\a\d.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */