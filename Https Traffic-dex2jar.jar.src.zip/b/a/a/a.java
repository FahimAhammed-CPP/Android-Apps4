package b.a.a;

import android.os.IInterface;

public interface a extends IInterface {}


/* Location:              C:\soft\dex2jar-2.0\Https Traffic-dex2jar.jar!\b\a\a\a.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */