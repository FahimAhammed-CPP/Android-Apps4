package androidx.constraintlayout.widget;

public final class R {
  public static final class attr {
    public static final int barrierAllowsGoneWidgets = 2130837559;
    
    public static final int barrierDirection = 2130837560;
    
    public static final int chainUseRtl = 2130837574;
    
    public static final int constraintSet = 2130837593;
    
    public static final int constraint_referenced_ids = 2130837594;
    
    public static final int content = 2130837595;
    
    public static final int emptyVisibility = 2130837623;
    
    public static final int layout_constrainedHeight = 2130837658;
    
    public static final int layout_constrainedWidth = 2130837659;
    
    public static final int layout_constraintBaseline_creator = 2130837660;
    
    public static final int layout_constraintBaseline_toBaselineOf = 2130837661;
    
    public static final int layout_constraintBottom_creator = 2130837662;
    
    public static final int layout_constraintBottom_toBottomOf = 2130837663;
    
    public static final int layout_constraintBottom_toTopOf = 2130837664;
    
    public static final int layout_constraintCircle = 2130837665;
    
    public static final int layout_constraintCircleAngle = 2130837666;
    
    public static final int layout_constraintCircleRadius = 2130837667;
    
    public static final int layout_constraintDimensionRatio = 2130837668;
    
    public static final int layout_constraintEnd_toEndOf = 2130837669;
    
    public static final int layout_constraintEnd_toStartOf = 2130837670;
    
    public static final int layout_constraintGuide_begin = 2130837671;
    
    public static final int layout_constraintGuide_end = 2130837672;
    
    public static final int layout_constraintGuide_percent = 2130837673;
    
    public static final int layout_constraintHeight_default = 2130837674;
    
    public static final int layout_constraintHeight_max = 2130837675;
    
    public static final int layout_constraintHeight_min = 2130837676;
    
    public static final int layout_constraintHeight_percent = 2130837677;
    
    public static final int layout_constraintHorizontal_bias = 2130837678;
    
    public static final int layout_constraintHorizontal_chainStyle = 2130837679;
    
    public static final int layout_constraintHorizontal_weight = 2130837680;
    
    public static final int layout_constraintLeft_creator = 2130837681;
    
    public static final int layout_constraintLeft_toLeftOf = 2130837682;
    
    public static final int layout_constraintLeft_toRightOf = 2130837683;
    
    public static final int layout_constraintRight_creator = 2130837684;
    
    public static final int layout_constraintRight_toLeftOf = 2130837685;
    
    public static final int layout_constraintRight_toRightOf = 2130837686;
    
    public static final int layout_constraintStart_toEndOf = 2130837687;
    
    public static final int layout_constraintStart_toStartOf = 2130837688;
    
    public static final int layout_constraintTop_creator = 2130837689;
    
    public static final int layout_constraintTop_toBottomOf = 2130837690;
    
    public static final int layout_constraintTop_toTopOf = 2130837691;
    
    public static final int layout_constraintVertical_bias = 2130837692;
    
    public static final int layout_constraintVertical_chainStyle = 2130837693;
    
    public static final int layout_constraintVertical_weight = 2130837694;
    
    public static final int layout_constraintWidth_default = 2130837695;
    
    public static final int layout_constraintWidth_max = 2130837696;
    
    public static final int layout_constraintWidth_min = 2130837697;
    
    public static final int layout_constraintWidth_percent = 2130837698;
    
    public static final int layout_editor_absoluteX = 2130837700;
    
    public static final int layout_editor_absoluteY = 2130837701;
    
    public static final int layout_goneMarginBottom = 2130837702;
    
    public static final int layout_goneMarginEnd = 2130837703;
    
    public static final int layout_goneMarginLeft = 2130837704;
    
    public static final int layout_goneMarginRight = 2130837705;
    
    public static final int layout_goneMarginStart = 2130837706;
    
    public static final int layout_goneMarginTop = 2130837707;
    
    public static final int layout_optimizationLevel = 2130837710;
  }
  
  public static final class id {
    public static final int bottom = 2131165217;
    
    public static final int end = 2131165238;
    
    public static final int gone = 2131165245;
    
    public static final int invisible = 2131165255;
    
    public static final int left = 2131165257;
    
    public static final int packed = 2131165271;
    
    public static final int parent = 2131165272;
    
    public static final int percent = 2131165274;
    
    public static final int right = 2131165278;
    
    public static final int spread = 2131165302;
    
    public static final int spread_inside = 2131165303;
    
    public static final int start = 2131165308;
    
    public static final int top = 2131165323;
    
    public static final int wrap = 2131165329;
  }
  
  public static final class styleable {
    public static final int[] ConstraintLayout_Layout = new int[] { 
        16842948, 16843039, 16843040, 16843071, 16843072, 2130837559, 2130837560, 2130837574, 2130837593, 2130837594, 
        2130837658, 2130837659, 2130837660, 2130837661, 2130837662, 2130837663, 2130837664, 2130837665, 2130837666, 2130837667, 
        2130837668, 2130837669, 2130837670, 2130837671, 2130837672, 2130837673, 2130837674, 2130837675, 2130837676, 2130837677, 
        2130837678, 2130837679, 2130837680, 2130837681, 2130837682, 2130837683, 2130837684, 2130837685, 2130837686, 2130837687, 
        2130837688, 2130837689, 2130837690, 2130837691, 2130837692, 2130837693, 2130837694, 2130837695, 2130837696, 2130837697, 
        2130837698, 2130837700, 2130837701, 2130837702, 2130837703, 2130837704, 2130837705, 2130837706, 2130837707, 2130837710 };
    
    public static final int ConstraintLayout_Layout_android_maxHeight = 2;
    
    public static final int ConstraintLayout_Layout_android_maxWidth = 1;
    
    public static final int ConstraintLayout_Layout_android_minHeight = 4;
    
    public static final int ConstraintLayout_Layout_android_minWidth = 3;
    
    public static final int ConstraintLayout_Layout_android_orientation = 0;
    
    public static final int ConstraintLayout_Layout_barrierAllowsGoneWidgets = 5;
    
    public static final int ConstraintLayout_Layout_barrierDirection = 6;
    
    public static final int ConstraintLayout_Layout_chainUseRtl = 7;
    
    public static final int ConstraintLayout_Layout_constraintSet = 8;
    
    public static final int ConstraintLayout_Layout_constraint_referenced_ids = 9;
    
    public static final int ConstraintLayout_Layout_layout_constrainedHeight = 10;
    
    public static final int ConstraintLayout_Layout_layout_constrainedWidth = 11;
    
    public static final int ConstraintLayout_Layout_layout_constraintBaseline_creator = 12;
    
    public static final int ConstraintLayout_Layout_layout_constraintBaseline_toBaselineOf = 13;
    
    public static final int ConstraintLayout_Layout_layout_constraintBottom_creator = 14;
    
    public static final int ConstraintLayout_Layout_layout_constraintBottom_toBottomOf = 15;
    
    public static final int ConstraintLayout_Layout_layout_constraintBottom_toTopOf = 16;
    
    public static final int ConstraintLayout_Layout_layout_constraintCircle = 17;
    
    public static final int ConstraintLayout_Layout_layout_constraintCircleAngle = 18;
    
    public static final int ConstraintLayout_Layout_layout_constraintCircleRadius = 19;
    
    public static final int ConstraintLayout_Layout_layout_constraintDimensionRatio = 20;
    
    public static final int ConstraintLayout_Layout_layout_constraintEnd_toEndOf = 21;
    
    public static final int ConstraintLayout_Layout_layout_constraintEnd_toStartOf = 22;
    
    public static final int ConstraintLayout_Layout_layout_constraintGuide_begin = 23;
    
    public static final int ConstraintLayout_Layout_layout_constraintGuide_end = 24;
    
    public static final int ConstraintLayout_Layout_layout_constraintGuide_percent = 25;
    
    public static final int ConstraintLayout_Layout_layout_constraintHeight_default = 26;
    
    public static final int ConstraintLayout_Layout_layout_constraintHeight_max = 27;
    
    public static final int ConstraintLayout_Layout_layout_constraintHeight_min = 28;
    
    public static final int ConstraintLayout_Layout_layout_constraintHeight_percent = 29;
    
    public static final int ConstraintLayout_Layout_layout_constraintHorizontal_bias = 30;
    
    public static final int ConstraintLayout_Layout_layout_constraintHorizontal_chainStyle = 31;
    
    public static final int ConstraintLayout_Layout_layout_constraintHorizontal_weight = 32;
    
    public static final int ConstraintLayout_Layout_layout_constraintLeft_creator = 33;
    
    public static final int ConstraintLayout_Layout_layout_constraintLeft_toLeftOf = 34;
    
    public static final int ConstraintLayout_Layout_layout_constraintLeft_toRightOf = 35;
    
    public static final int ConstraintLayout_Layout_layout_constraintRight_creator = 36;
    
    public static final int ConstraintLayout_Layout_layout_constraintRight_toLeftOf = 37;
    
    public static final int ConstraintLayout_Layout_layout_constraintRight_toRightOf = 38;
    
    public static final int ConstraintLayout_Layout_layout_constraintStart_toEndOf = 39;
    
    public static final int ConstraintLayout_Layout_layout_constraintStart_toStartOf = 40;
    
    public static final int ConstraintLayout_Layout_layout_constraintTop_creator = 41;
    
    public static final int ConstraintLayout_Layout_layout_constraintTop_toBottomOf = 42;
    
    public static final int ConstraintLayout_Layout_layout_constraintTop_toTopOf = 43;
    
    public static final int ConstraintLayout_Layout_layout_constraintVertical_bias = 44;
    
    public static final int ConstraintLayout_Layout_layout_constraintVertical_chainStyle = 45;
    
    public static final int ConstraintLayout_Layout_layout_constraintVertical_weight = 46;
    
    public static final int ConstraintLayout_Layout_layout_constraintWidth_default = 47;
    
    public static final int ConstraintLayout_Layout_layout_constraintWidth_max = 48;
    
    public static final int ConstraintLayout_Layout_layout_constraintWidth_min = 49;
    
    public static final int ConstraintLayout_Layout_layout_constraintWidth_percent = 50;
    
    public static final int ConstraintLayout_Layout_layout_editor_absoluteX = 51;
    
    public static final int ConstraintLayout_Layout_layout_editor_absoluteY = 52;
    
    public static final int ConstraintLayout_Layout_layout_goneMarginBottom = 53;
    
    public static final int ConstraintLayout_Layout_layout_goneMarginEnd = 54;
    
    public static final int ConstraintLayout_Layout_layout_goneMarginLeft = 55;
    
    public static final int ConstraintLayout_Layout_layout_goneMarginRight = 56;
    
    public static final int ConstraintLayout_Layout_layout_goneMarginStart = 57;
    
    public static final int ConstraintLayout_Layout_layout_goneMarginTop = 58;
    
    public static final int ConstraintLayout_Layout_layout_optimizationLevel = 59;
    
    public static final int[] ConstraintLayout_placeholder = new int[] { 2130837595, 2130837623 };
    
    public static final int ConstraintLayout_placeholder_content = 0;
    
    public static final int ConstraintLayout_placeholder_emptyVisibility = 1;
    
    public static final int[] ConstraintSet = new int[] { 
        16842948, 16842960, 16842972, 16842996, 16842997, 16842999, 16843000, 16843001, 16843002, 16843039, 
        16843040, 16843071, 16843072, 16843551, 16843552, 16843553, 16843554, 16843555, 16843556, 16843557, 
        16843558, 16843559, 16843560, 16843701, 16843702, 16843770, 16843840, 2130837559, 2130837560, 2130837574, 
        2130837594, 2130837658, 2130837659, 2130837660, 2130837661, 2130837662, 2130837663, 2130837664, 2130837665, 2130837666, 
        2130837667, 2130837668, 2130837669, 2130837670, 2130837671, 2130837672, 2130837673, 2130837674, 2130837675, 2130837676, 
        2130837677, 2130837678, 2130837679, 2130837680, 2130837681, 2130837682, 2130837683, 2130837684, 2130837685, 2130837686, 
        2130837687, 2130837688, 2130837689, 2130837690, 2130837691, 2130837692, 2130837693, 2130837694, 2130837695, 2130837696, 
        2130837697, 2130837698, 2130837700, 2130837701, 2130837702, 2130837703, 2130837704, 2130837705, 2130837706, 2130837707 };
    
    public static final int ConstraintSet_android_alpha = 13;
    
    public static final int ConstraintSet_android_elevation = 26;
    
    public static final int ConstraintSet_android_id = 1;
    
    public static final int ConstraintSet_android_layout_height = 4;
    
    public static final int ConstraintSet_android_layout_marginBottom = 8;
    
    public static final int ConstraintSet_android_layout_marginEnd = 24;
    
    public static final int ConstraintSet_android_layout_marginLeft = 5;
    
    public static final int ConstraintSet_android_layout_marginRight = 7;
    
    public static final int ConstraintSet_android_layout_marginStart = 23;
    
    public static final int ConstraintSet_android_layout_marginTop = 6;
    
    public static final int ConstraintSet_android_layout_width = 3;
    
    public static final int ConstraintSet_android_maxHeight = 10;
    
    public static final int ConstraintSet_android_maxWidth = 9;
    
    public static final int ConstraintSet_android_minHeight = 12;
    
    public static final int ConstraintSet_android_minWidth = 11;
    
    public static final int ConstraintSet_android_orientation = 0;
    
    public static final int ConstraintSet_android_rotation = 20;
    
    public static final int ConstraintSet_android_rotationX = 21;
    
    public static final int ConstraintSet_android_rotationY = 22;
    
    public static final int ConstraintSet_android_scaleX = 18;
    
    public static final int ConstraintSet_android_scaleY = 19;
    
    public static final int ConstraintSet_android_transformPivotX = 14;
    
    public static final int ConstraintSet_android_transformPivotY = 15;
    
    public static final int ConstraintSet_android_translationX = 16;
    
    public static final int ConstraintSet_android_translationY = 17;
    
    public static final int ConstraintSet_android_translationZ = 25;
    
    public static final int ConstraintSet_android_visibility = 2;
    
    public static final int ConstraintSet_barrierAllowsGoneWidgets = 27;
    
    public static final int ConstraintSet_barrierDirection = 28;
    
    public static final int ConstraintSet_chainUseRtl = 29;
    
    public static final int ConstraintSet_constraint_referenced_ids = 30;
    
    public static final int ConstraintSet_layout_constrainedHeight = 31;
    
    public static final int ConstraintSet_layout_constrainedWidth = 32;
    
    public static final int ConstraintSet_layout_constraintBaseline_creator = 33;
    
    public static final int ConstraintSet_layout_constraintBaseline_toBaselineOf = 34;
    
    public static final int ConstraintSet_layout_constraintBottom_creator = 35;
    
    public static final int ConstraintSet_layout_constraintBottom_toBottomOf = 36;
    
    public static final int ConstraintSet_layout_constraintBottom_toTopOf = 37;
    
    public static final int ConstraintSet_layout_constraintCircle = 38;
    
    public static final int ConstraintSet_layout_constraintCircleAngle = 39;
    
    public static final int ConstraintSet_layout_constraintCircleRadius = 40;
    
    public static final int ConstraintSet_layout_constraintDimensionRatio = 41;
    
    public static final int ConstraintSet_layout_constraintEnd_toEndOf = 42;
    
    public static final int ConstraintSet_layout_constraintEnd_toStartOf = 43;
    
    public static final int ConstraintSet_layout_constraintGuide_begin = 44;
    
    public static final int ConstraintSet_layout_constraintGuide_end = 45;
    
    public static final int ConstraintSet_layout_constraintGuide_percent = 46;
    
    public static final int ConstraintSet_layout_constraintHeight_default = 47;
    
    public static final int ConstraintSet_layout_constraintHeight_max = 48;
    
    public static final int ConstraintSet_layout_constraintHeight_min = 49;
    
    public static final int ConstraintSet_layout_constraintHeight_percent = 50;
    
    public static final int ConstraintSet_layout_constraintHorizontal_bias = 51;
    
    public static final int ConstraintSet_layout_constraintHorizontal_chainStyle = 52;
    
    public static final int ConstraintSet_layout_constraintHorizontal_weight = 53;
    
    public static final int ConstraintSet_layout_constraintLeft_creator = 54;
    
    public static final int ConstraintSet_layout_constraintLeft_toLeftOf = 55;
    
    public static final int ConstraintSet_layout_constraintLeft_toRightOf = 56;
    
    public static final int ConstraintSet_layout_constraintRight_creator = 57;
    
    public static final int ConstraintSet_layout_constraintRight_toLeftOf = 58;
    
    public static final int ConstraintSet_layout_constraintRight_toRightOf = 59;
    
    public static final int ConstraintSet_layout_constraintStart_toEndOf = 60;
    
    public static final int ConstraintSet_layout_constraintStart_toStartOf = 61;
    
    public static final int ConstraintSet_layout_constraintTop_creator = 62;
    
    public static final int ConstraintSet_layout_constraintTop_toBottomOf = 63;
    
    public static final int ConstraintSet_layout_constraintTop_toTopOf = 64;
    
    public static final int ConstraintSet_layout_constraintVertical_bias = 65;
    
    public static final int ConstraintSet_layout_constraintVertical_chainStyle = 66;
    
    public static final int ConstraintSet_layout_constraintVertical_weight = 67;
    
    public static final int ConstraintSet_layout_constraintWidth_default = 68;
    
    public static final int ConstraintSet_layout_constraintWidth_max = 69;
    
    public static final int ConstraintSet_layout_constraintWidth_min = 70;
    
    public static final int ConstraintSet_layout_constraintWidth_percent = 71;
    
    public static final int ConstraintSet_layout_editor_absoluteX = 72;
    
    public static final int ConstraintSet_layout_editor_absoluteY = 73;
    
    public static final int ConstraintSet_layout_goneMarginBottom = 74;
    
    public static final int ConstraintSet_layout_goneMarginEnd = 75;
    
    public static final int ConstraintSet_layout_goneMarginLeft = 76;
    
    public static final int ConstraintSet_layout_goneMarginRight = 77;
    
    public static final int ConstraintSet_layout_goneMarginStart = 78;
    
    public static final int ConstraintSet_layout_goneMarginTop = 79;
    
    public static final int[] LinearConstraintLayout = new int[] { 16842948 };
    
    public static final int LinearConstraintLayout_android_orientation = 0;
  }
}


/* Location:              C:\soft\dex2jar-2.0\Silent Letters-dex2jar.jar!\androidx\constraintlayout\widget\R.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */