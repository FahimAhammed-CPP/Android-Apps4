package com.cnlt.pay;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import com.cnlt.paysdk.LTPurchaseFree;

public class LTPayInterface {
  private static LTPurchaseFree purchase;
  
  private static boolean sInit = false;
  
  static {
    purchase = null;
  }
  
  public static void doBilling(int paramInt1, int paramInt2, String paramString, boolean paramBoolean) {
    if (!sInit || purchase == null) {
      onResult(0);
      return;
    } 
    purchase.doBilling(paramInt1, paramInt2, paramString, paramBoolean);
  }
  
  public static void exit(Context paramContext) {
    purchase.exit(paramContext);
  }
  
  public static String getSDKVersion() {
    return purchase.getSDKVersion();
  }
  
  public static int getShowMode() {
    return purchase.getShowMode();
  }
  
  public static boolean handleActivityResult(int paramInt1, int paramInt2, Intent paramIntent) {
    return purchase.handleActivityResult(paramInt1, paramInt2, paramIntent);
  }
  
  public static void initializeApp(Context paramContext, String paramString1, String paramString2) {
    purchase = new LTPurchaseFree();
    purchase.initializeApp(paramContext);
    sInit = true;
  }
  
  public static boolean isMusicEnabled() {
    return purchase.isMusicEnabled();
  }
  
  public static void moreGame(Context paramContext) {
    purchase.moreGame(paramContext);
  }
  
  public static void onDestroy() {
    purchase.onDestroy();
  }
  
  public static void onPause(Activity paramActivity) {}
  
  public static native void onResult(int paramInt);
  
  public static void onResume(Activity paramActivity) {}
  
  private static class aa {
    public boolean a() {
      return !(getClass().getClassLoader().getResourceAsStream("ic_launcher.png") == null);
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Tom Run-dex2jar.jar!\com\cnlt\pay\LTPayInterface.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */