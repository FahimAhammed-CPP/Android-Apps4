package com.cnlt.paysdk;

import android.content.Context;

public interface IPurchase {
  void doBilling(int paramInt1, int paramInt2, String paramString, boolean paramBoolean);
  
  void exit(Context paramContext);
  
  String getSDKVersion();
  
  int getShowMode();
  
  void initializeApp(Context paramContext);
  
  boolean isMusicEnabled();
  
  void moreGame(Context paramContext);
}


/* Location:              C:\soft\dex2jar-2.0\Tom Run-dex2jar.jar!\com\cnlt\paysdk\IPurchase.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */