package com.cnlt.paysdk;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.os.Handler;
import android.os.Message;
import android.util.Log;
import com.android.vending.billing.IabBroadcastReceiver;
import com.android.vending.billing.IabHelper;
import com.android.vending.billing.IabResult;
import com.android.vending.billing.Inventory;
import com.android.vending.billing.Purchase;
import com.cnlt.pay.LTPayInterface;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

public class LTPurchaseFree implements IPurchase, IabBroadcastReceiver.IabBroadcastListener, IabHelper.OnIabPurchaseFinishedListener, IabHelper.QueryInventoryFinishedListener, IabHelper.OnConsumeFinishedListener {
  public static final Product[] PRODUCT = new Product[] { 
      new Product("null", Product.PurchaseType.PurchaseTypeConsume), new Product("hero1", Product.PurchaseType.PurchaseTypeNotConsume), new Product("hero2", Product.PurchaseType.PurchaseTypeNotConsume), new Product("pet1", Product.PurchaseType.PurchaseTypeNotConsume), new Product("pet2", Product.PurchaseType.PurchaseTypeNotConsume), new Product("pet3", Product.PurchaseType.PurchaseTypeNotConsume), new Product("mount1", Product.PurchaseType.PurchaseTypeNotConsume), new Product("mount2", Product.PurchaseType.PurchaseTypeNotConsume), new Product("mount3", Product.PurchaseType.PurchaseTypeNotConsume), new Product("speed", Product.PurchaseType.PurchaseTypeConsume), 
      new Product("revive", Product.PurchaseType.PurchaseTypeConsume), new Product("heart1", Product.PurchaseType.PurchaseTypeConsume), new Product("heart2", Product.PurchaseType.PurchaseTypeConsume), new Product("heart3", Product.PurchaseType.PurchaseTypeConsume), new Product("heart4", Product.PurchaseType.PurchaseTypeNotConsume), new Product("firstgift", Product.PurchaseType.PurchaseTypeNotConsume), new Product("perfectgift", Product.PurchaseType.PurchaseTypeNotConsume), new Product("happygift", Product.PurchaseType.PurchaseTypeNotConsume) };
  
  private boolean SETUP_SUCCESS = true;
  
  private final String TAG = "GooglePay-LOG";
  
  private Context mActivity;
  
  int mCurrentPayTag = 0;
  
  IabHelper mHelper;
  
  List<Purchase> mPurchaseList = null;
  
  public Handler uiHandler = new Handler() {
      public void handleMessage(Message param1Message) {
        int i = param1Message.arg1;
        try {
          if (!LTPurchaseFree.this.SETUP_SUCCESS || LTPurchaseFree.this.mHelper == null) {
            LTPayInterface.onResult(0);
            return;
          } 
          try {
            Log.e("GooglePay-LOGPRODUCT_ID:   ", (LTPurchaseFree.PRODUCT[i]).mName);
            LTPurchaseFree.this.mCurrentPayTag = i;
            LTPurchaseFree.this.mHelper.launchPurchaseFlow((Activity)LTPurchaseFree.this.mActivity, (LTPurchaseFree.PRODUCT[i]).mName, i, LTPurchaseFree.this, "dashisha");
            return;
          } catch (com.android.vending.billing.IabHelper.IabAsyncInProgressException iabAsyncInProgressException) {
            iabAsyncInProgressException.printStackTrace();
            LTPayInterface.onResult(0);
            return;
          } 
        } catch (Exception exception) {
          exception.printStackTrace();
          return;
        } 
      }
    };
  
  private void initService() {
    this.mHelper = new IabHelper(this.mActivity, "MIIBIjANBgkqhkiG9w0BAQEFAAOCAQ8AMIIBCgKCAQEAiltWtF8SQXACcnHKhZC9fUCovMkRZ7hPBc+TuDS6qjp58C6+ZBu9WAF6rQB6PNFzcVXZDMxq6xy48pmVcKTMJ1+se88BegFoGcDSs1YRd+svx8jPzASMq6LugHvjixRpcrrh/g6cCMsj6DUO1EDy7D1eyud2A9WnUxkAk9WNn39ckkc8O0Gin6TMioCWEzcSsPV9+tKzXv7zMdzZLcSM5a90qv0Ga2jCkeXOF/HaB1hwyiajFx0uw7yQIarda5vfj9IwkseldrGuMMEzi0YaAmfvKmyUIpitaUK2wLa1N3hW+6e6lvshN48UnDYeePtHHjSjbEabm0S9w5G5mBQWUwIDAQAB");
    this.mHelper.startSetup(new IabHelper.OnIabSetupFinishedListener() {
          public void onIabSetupFinished(IabResult param1IabResult) {
            if (!param1IabResult.isSuccess()) {
              Log.e("GooglePay-LOG", "Problem setting up In-app Billing: " + param1IabResult);
              LTPurchaseFree.this.SETUP_SUCCESS = true;
              return;
            } 
            LTPurchaseFree.this.SETUP_SUCCESS = true;
          }
        });
  }
  
  void addOnePurchaesToList(Purchase paramPurchase) {
    if (!this.mPurchaseList.contains(paramPurchase))
      this.mPurchaseList.add(paramPurchase); 
  }
  
  public void consumePurchase(Purchase paramPurchase) {
    if (this.mHelper == null) {
      LTPayInterface.onResult(0);
      return;
    } 
    try {
      this.mHelper.consumeAsync(paramPurchase, this);
      Log.e("GooglePay-LOG", "consumePurchase--" + paramPurchase.getSku());
      return;
    } catch (com.android.vending.billing.IabHelper.IabAsyncInProgressException iabAsyncInProgressException) {
      iabAsyncInProgressException.printStackTrace();
      LTPayInterface.onResult(0);
      removeOnePurchaseFromList(paramPurchase);
      return;
    } 
  }
  
  public void doBilling(int paramInt1, int paramInt2, String paramString, boolean paramBoolean) {
    Message message = this.uiHandler.obtainMessage();
    message.arg1 = paramInt1;
    message.sendToTarget();
  }
  
  public void exit(Context paramContext) {
    ((Activity)paramContext).finish();
    System.exit(0);
  }
  
  public String getSDKVersion() {
    return "free 1.0";
  }
  
  public int getShowMode() {
    return 0;
  }
  
  Purchase getUnProcessedPurchaseBySku(String paramString) {
    Iterator<Purchase> iterator = this.mPurchaseList.iterator();
    while (true) {
      if (!iterator.hasNext())
        return null; 
      Purchase purchase = iterator.next();
      if (purchase.getSku().compareTo(paramString) == 0)
        return purchase; 
    } 
  }
  
  public boolean handleActivityResult(int paramInt1, int paramInt2, Intent paramIntent) {
    Log.e("GooglePay-LOG", "onActivityResult(" + paramInt1 + "," + paramInt2 + "," + paramIntent);
    if (this.mHelper != null && this.mHelper.handleActivityResult(paramInt1, paramInt2, paramIntent)) {
      Log.e("GooglePay-LOG", "onActivityResult handled by IABUtil.");
      return true;
    } 
    return false;
  }
  
  public void initializeApp(Context paramContext) {
    this.mActivity = paramContext;
    this.mPurchaseList = new ArrayList<Purchase>();
    initService();
  }
  
  boolean isConsumeType(String paramString) {
    for (int i = 0;; i++) {
      if (i >= PRODUCT.length) {
        Log.e("GooglePay-LOG", "product id error");
        return false;
      } 
      if ((PRODUCT[i]).mName.equals(paramString))
        return ((PRODUCT[i]).mType == Product.PurchaseType.PurchaseTypeConsume); 
    } 
  }
  
  public boolean isMusicEnabled() {
    return true;
  }
  
  public void moreGame(Context paramContext) {}
  
  public void onConsumeFinished(Purchase paramPurchase, IabResult paramIabResult) {
    if (paramIabResult.isSuccess()) {
      LTPayInterface.onResult(1);
      Log.e("GooglePay-LOGUSE_CALLBACK", "SUCCESS");
      removeOnePurchaseFromList(paramPurchase);
      return;
    } 
    LTPayInterface.onResult(0);
    Log.e("GooglePay-LOGUSE_CALLBACK", "FAIL");
  }
  
  public void onDestroy() {
    if (this.mHelper != null)
      try {
        this.mHelper.dispose();
      } catch (com.android.vending.billing.IabHelper.IabAsyncInProgressException iabAsyncInProgressException) {
        iabAsyncInProgressException.printStackTrace();
      }  
    this.mHelper = null;
  }
  
  public void onIabPurchaseFinished(IabResult paramIabResult, Purchase paramPurchase) {
    if (paramIabResult.isFailure()) {
      Log.e("GooglePay-LOG-PAY_CALLBACK_MSG", paramIabResult.toString());
      Log.e("GooglePay-LOG-PAY_CALLBACK_RESPONE", (new StringBuilder(String.valueOf(paramIabResult.getResponse()))).toString());
      switch (paramIabResult.getResponse()) {
        default:
          LTPayInterface.onResult(0);
          return;
        case 7:
          break;
      } 
      LTPayInterface.onResult(1);
      return;
    } 
    if (isConsumeType(paramPurchase.getSku())) {
      consumePurchase(paramPurchase);
      return;
    } 
    LTPayInterface.onResult(1);
  }
  
  public void onQueryInventoryFinished(IabResult paramIabResult, Inventory paramInventory) {
    if (!paramIabResult.isFailure()) {
      this.mPurchaseList = paramInventory.getAllPurchases();
      Iterator<Purchase> iterator = this.mPurchaseList.iterator();
      while (true) {
        if (iterator.hasNext()) {
          Purchase purchase = iterator.next();
          if (purchase != null && isConsumeType(purchase.mSku))
            Log.e("GooglePay-LOGbuy---", "______" + purchase.mSku); 
          continue;
        } 
        return;
      } 
    } 
  }
  
  public void queryInventory() {
    if (this.mHelper == null)
      return; 
    try {
      this.mHelper.queryInventoryAsync(this);
      return;
    } catch (com.android.vending.billing.IabHelper.IabAsyncInProgressException iabAsyncInProgressException) {
      iabAsyncInProgressException.printStackTrace();
      return;
    } 
  }
  
  public void receivedBroadcast() {}
  
  void removeOnePurchaseFromList(Purchase paramPurchase) {
    this.mPurchaseList.remove(paramPurchase);
  }
}


/* Location:              C:\soft\dex2jar-2.0\Tom Run-dex2jar.jar!\com\cnlt\paysdk\LTPurchaseFree.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */