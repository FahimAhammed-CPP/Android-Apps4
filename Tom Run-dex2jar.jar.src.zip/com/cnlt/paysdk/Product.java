package com.cnlt.paysdk;

public class Product {
  public String mName;
  
  public PurchaseType mType;
  
  public Product(String paramString, PurchaseType paramPurchaseType) {
    this.mName = paramString;
    this.mType = paramPurchaseType;
  }
  
  enum PurchaseType {
    PurchaseTypeConsume, PurchaseTypeNotConsume;
    
    static {
    
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Tom Run-dex2jar.jar!\com\cnlt\paysdk\Product.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */