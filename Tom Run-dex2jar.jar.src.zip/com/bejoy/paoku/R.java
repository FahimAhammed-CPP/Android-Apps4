package com.bejoy.paoku;

public final class R {
  public static final class anim {
    public static final int toast_in = 2130968576;
  }
  
  public static final class attr {}
  
  public static final class drawable {
    public static final int icon = 2130837504;
    
    public static final int loading0001 = 2130837505;
    
    public static final int my_progress = 2130837506;
    
    public static final int toastbg = 2130837507;
  }
  
  public static final class id {
    public static final int oahprogressbar = 2131099648;
    
    public static final int oaprogresstitle = 2131099649;
    
    public static final int toast_tv = 2131099650;
  }
  
  public static final class layout {
    public static final int customprogress = 2130903040;
    
    public static final int toast_bg = 2130903041;
  }
  
  public static final class string {
    public static final int app_name = 2131034112;
    
    public static final int google_rsa = 2131034113;
  }
}


/* Location:              C:\soft\dex2jar-2.0\Tom Run-dex2jar.jar!\com\bejoy\paoku\R.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */