package com.android.vending.billing;

import org.json.JSONException;
import org.json.JSONObject;

public class Purchase {
  String mDeveloperPayload;
  
  boolean mIsAutoRenewing;
  
  String mItemType;
  
  String mOrderId;
  
  String mOriginalJson;
  
  String mPackageName;
  
  int mPurchaseState;
  
  long mPurchaseTime;
  
  String mSignature;
  
  public String mSku;
  
  String mToken;
  
  public Purchase(String paramString1, String paramString2, String paramString3) throws JSONException {
    this.mItemType = paramString1;
    this.mOriginalJson = paramString2;
    JSONObject jSONObject = new JSONObject(this.mOriginalJson);
    this.mOrderId = jSONObject.optString("orderId");
    this.mPackageName = jSONObject.optString("packageName");
    this.mSku = jSONObject.optString("productId");
    this.mPurchaseTime = jSONObject.optLong("purchaseTime");
    this.mPurchaseState = jSONObject.optInt("purchaseState");
    this.mDeveloperPayload = jSONObject.optString("developerPayload");
    this.mToken = jSONObject.optString("token", jSONObject.optString("purchaseToken"));
    this.mIsAutoRenewing = jSONObject.optBoolean("autoRenewing");
    this.mSignature = paramString3;
  }
  
  public String getDeveloperPayload() {
    return this.mDeveloperPayload;
  }
  
  public String getItemType() {
    return this.mItemType;
  }
  
  public String getOrderId() {
    return this.mOrderId;
  }
  
  public String getOriginalJson() {
    return this.mOriginalJson;
  }
  
  public String getPackageName() {
    return this.mPackageName;
  }
  
  public int getPurchaseState() {
    return this.mPurchaseState;
  }
  
  public long getPurchaseTime() {
    return this.mPurchaseTime;
  }
  
  public String getSignature() {
    return this.mSignature;
  }
  
  public String getSku() {
    return this.mSku;
  }
  
  public String getToken() {
    return this.mToken;
  }
  
  public boolean isAutoRenewing() {
    return this.mIsAutoRenewing;
  }
  
  public String toString() {
    return "PurchaseInfo(type:" + this.mItemType + "):" + this.mOriginalJson;
  }
}


/* Location:              C:\soft\dex2jar-2.0\Tom Run-dex2jar.jar!\com\android\vending\billing\Purchase.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */