package com.android.vending.billing;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;

public class IabBroadcastReceiver extends BroadcastReceiver {
  public static final String ACTION = "com.android.vending.billing.PURCHASES_UPDATED";
  
  private final IabBroadcastListener mListener;
  
  public IabBroadcastReceiver(IabBroadcastListener paramIabBroadcastListener) {
    this.mListener = paramIabBroadcastListener;
  }
  
  public void onReceive(Context paramContext, Intent paramIntent) {
    if (this.mListener != null)
      this.mListener.receivedBroadcast(); 
  }
  
  public static interface IabBroadcastListener {
    void receivedBroadcast();
  }
}


/* Location:              C:\soft\dex2jar-2.0\Tom Run-dex2jar.jar!\com\android\vending\billing\IabBroadcastReceiver.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */