package com.android.vending.billing;

import android.app.Activity;
import android.app.PendingIntent;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.content.IntentSender;
import android.content.ServiceConnection;
import android.os.Bundle;
import android.os.Handler;
import android.os.IBinder;
import android.os.RemoteException;
import android.text.TextUtils;
import android.util.Log;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import org.json.JSONException;

public class IabHelper {
  public static final int BILLING_RESPONSE_RESULT_BILLING_UNAVAILABLE = 3;
  
  public static final int BILLING_RESPONSE_RESULT_DEVELOPER_ERROR = 5;
  
  public static final int BILLING_RESPONSE_RESULT_ERROR = 6;
  
  public static final int BILLING_RESPONSE_RESULT_ITEM_ALREADY_OWNED = 7;
  
  public static final int BILLING_RESPONSE_RESULT_ITEM_NOT_OWNED = 8;
  
  public static final int BILLING_RESPONSE_RESULT_ITEM_UNAVAILABLE = 4;
  
  public static final int BILLING_RESPONSE_RESULT_OK = 0;
  
  public static final int BILLING_RESPONSE_RESULT_SERVICE_UNAVAILABLE = 2;
  
  public static final int BILLING_RESPONSE_RESULT_USER_CANCELED = 1;
  
  public static final String GET_SKU_DETAILS_ITEM_LIST = "ITEM_ID_LIST";
  
  public static final String GET_SKU_DETAILS_ITEM_TYPE_LIST = "ITEM_TYPE_LIST";
  
  public static final int IABHELPER_BAD_RESPONSE = -1002;
  
  public static final int IABHELPER_ERROR_BASE = -1000;
  
  public static final int IABHELPER_INVALID_CONSUMPTION = -1010;
  
  public static final int IABHELPER_MISSING_TOKEN = -1007;
  
  public static final int IABHELPER_REMOTE_EXCEPTION = -1001;
  
  public static final int IABHELPER_SEND_INTENT_FAILED = -1004;
  
  public static final int IABHELPER_SUBSCRIPTIONS_NOT_AVAILABLE = -1009;
  
  public static final int IABHELPER_SUBSCRIPTION_UPDATE_NOT_AVAILABLE = -1011;
  
  public static final int IABHELPER_UNKNOWN_ERROR = -1008;
  
  public static final int IABHELPER_UNKNOWN_PURCHASE_RESPONSE = -1006;
  
  public static final int IABHELPER_USER_CANCELLED = -1005;
  
  public static final int IABHELPER_VERIFICATION_FAILED = -1003;
  
  public static final String INAPP_CONTINUATION_TOKEN = "INAPP_CONTINUATION_TOKEN";
  
  public static final String ITEM_TYPE_INAPP = "inapp";
  
  public static final String ITEM_TYPE_SUBS = "subs";
  
  public static final String RESPONSE_BUY_INTENT = "BUY_INTENT";
  
  public static final String RESPONSE_CODE = "RESPONSE_CODE";
  
  public static final String RESPONSE_GET_SKU_DETAILS_LIST = "DETAILS_LIST";
  
  public static final String RESPONSE_INAPP_ITEM_LIST = "INAPP_PURCHASE_ITEM_LIST";
  
  public static final String RESPONSE_INAPP_PURCHASE_DATA = "INAPP_PURCHASE_DATA";
  
  public static final String RESPONSE_INAPP_PURCHASE_DATA_LIST = "INAPP_PURCHASE_DATA_LIST";
  
  public static final String RESPONSE_INAPP_SIGNATURE = "INAPP_DATA_SIGNATURE";
  
  public static final String RESPONSE_INAPP_SIGNATURE_LIST = "INAPP_DATA_SIGNATURE_LIST";
  
  boolean mAsyncInProgress = false;
  
  private final Object mAsyncInProgressLock = new Object();
  
  String mAsyncOperation = "";
  
  Context mContext;
  
  boolean mDebugLog = false;
  
  String mDebugTag = "IabHelper";
  
  boolean mDisposeAfterAsync = false;
  
  boolean mDisposed = false;
  
  OnIabPurchaseFinishedListener mPurchaseListener;
  
  String mPurchasingItemType;
  
  int mRequestCode;
  
  IInAppBillingService mService;
  
  ServiceConnection mServiceConn;
  
  boolean mSetupDone = false;
  
  String mSignatureBase64 = null;
  
  boolean mSubscriptionUpdateSupported = false;
  
  boolean mSubscriptionsSupported = false;
  
  public IabHelper(Context paramContext, String paramString) {
    this.mContext = paramContext.getApplicationContext();
    this.mSignatureBase64 = paramString;
    logDebug("IAB helper created.");
  }
  
  private void checkNotDisposed() {
    if (this.mDisposed)
      throw new IllegalStateException("IabHelper was disposed of, so it cannot be used."); 
  }
  
  public static String getResponseDesc(int paramInt) {
    String[] arrayOfString1 = "0:OK/1:User Canceled/2:Unknown/3:Billing Unavailable/4:Item unavailable/5:Developer Error/6:Error/7:Item Already Owned/8:Item not owned".split("/");
    String[] arrayOfString2 = "0:OK/-1001:Remote exception during initialization/-1002:Bad response received/-1003:Purchase signature verification failed/-1004:Send intent failed/-1005:User cancelled/-1006:Unknown purchase response/-1007:Missing token/-1008:Unknown error/-1009:Subscriptions not available/-1010:Invalid consumption attempt".split("/");
    if (paramInt <= -1000) {
      int i = -1000 - paramInt;
      return (i >= 0 && i < arrayOfString2.length) ? arrayOfString2[i] : (String.valueOf(String.valueOf(paramInt)) + ":Unknown IAB Helper Error");
    } 
    return (paramInt < 0 || paramInt >= arrayOfString1.length) ? (String.valueOf(String.valueOf(paramInt)) + ":Unknown") : arrayOfString1[paramInt];
  }
  
  void checkSetupDone(String paramString) {
    if (!this.mSetupDone) {
      logError("Illegal state for operation (" + paramString + "): IAB helper is not set up.");
      throw new IllegalStateException("IAB helper is not set up. Can't perform operation: " + paramString);
    } 
  }
  
  void consume(Purchase paramPurchase) throws IabException {
    String str;
    checkNotDisposed();
    checkSetupDone("consume");
    if (!paramPurchase.mItemType.equals("inapp"))
      throw new IabException(-1010, "Items of type '" + paramPurchase.mItemType + "' can't be consumed."); 
    try {
      String str1 = paramPurchase.getToken();
      str = paramPurchase.getSku();
      if (str1 == null || str1.equals("")) {
        logError("Can't consume " + str + ". No token.");
        throw new IabException(-1007, "PurchaseInfo is missing token for sku: " + str + " " + paramPurchase);
      } 
    } catch (RemoteException remoteException) {
      throw new IabException(-1001, "Remote exception while consuming. PurchaseInfo: " + paramPurchase, remoteException);
    } 
    logDebug("Consuming sku: " + str + ", token: " + remoteException);
    int i = this.mService.consumePurchase(3, this.mContext.getPackageName(), (String)remoteException);
    if (i == 0) {
      logDebug("Successfully consumed sku: " + str);
      return;
    } 
    logDebug("Error consuming consuming sku " + str + ". " + getResponseDesc(i));
    throw new IabException(i, "Error consuming sku " + str);
  }
  
  public void consumeAsync(Purchase paramPurchase, OnConsumeFinishedListener paramOnConsumeFinishedListener) throws IabAsyncInProgressException {
    checkNotDisposed();
    checkSetupDone("consume");
    ArrayList<Purchase> arrayList = new ArrayList();
    arrayList.add(paramPurchase);
    consumeAsyncInternal(arrayList, paramOnConsumeFinishedListener, null);
  }
  
  public void consumeAsync(List<Purchase> paramList, OnConsumeMultiFinishedListener paramOnConsumeMultiFinishedListener) throws IabAsyncInProgressException {
    checkNotDisposed();
    checkSetupDone("consume");
    consumeAsyncInternal(paramList, null, paramOnConsumeMultiFinishedListener);
  }
  
  void consumeAsyncInternal(final List<Purchase> purchases, final OnConsumeFinishedListener singleListener, final OnConsumeMultiFinishedListener multiListener) throws IabAsyncInProgressException {
    final Handler handler = new Handler();
    flagStartAsync("consume");
    (new Thread(new Runnable() {
          public void run() {
            final ArrayList<IabResult> results = new ArrayList();
            Iterator<Purchase> iterator = purchases.iterator();
            while (true) {
              if (!iterator.hasNext()) {
                IabHelper.this.flagEndAsync();
                if (!IabHelper.this.mDisposed && singleListener != null)
                  handler.post(new Runnable() {
                        public void run() {
                          singleListener.onConsumeFinished(purchases.get(0), results.get(0));
                        }
                      }); 
                if (!IabHelper.this.mDisposed && multiListener != null)
                  handler.post(new Runnable() {
                        public void run() {
                          multiListener.onConsumeMultiFinished(purchases, results);
                        }
                      }); 
                return;
              } 
              Purchase purchase = iterator.next();
              try {
                IabHelper.this.consume(purchase);
                arrayList.add(new IabResult(0, "Successful consume of sku " + purchase.getSku()));
              } catch (IabException iabException) {
                arrayList.add(iabException.getResult());
              } 
            } 
          }
        })).start();
  }
  
  public void dispose() throws IabAsyncInProgressException {
    synchronized (this.mAsyncInProgressLock) {
      if (this.mAsyncInProgress)
        throw new IabAsyncInProgressException("Can't dispose because an async operation (" + this.mAsyncOperation + ") is in progress."); 
    } 
    /* monitor exit ClassFileLocalVariableReferenceExpression{type=ObjectType{java/lang/Object}, name=SYNTHETIC_LOCAL_VARIABLE_1} */
    logDebug("Disposing.");
    this.mSetupDone = false;
    if (this.mServiceConn != null) {
      logDebug("Unbinding from service.");
      if (this.mContext != null)
        this.mContext.unbindService(this.mServiceConn); 
    } 
    this.mDisposed = true;
    this.mContext = null;
    this.mServiceConn = null;
    this.mService = null;
    this.mPurchaseListener = null;
  }
  
  public void disposeWhenFinished() {
    synchronized (this.mAsyncInProgressLock) {
      if (this.mAsyncInProgress) {
        logDebug("Will dispose after async operation finishes.");
        this.mDisposeAfterAsync = true;
      } else {
        try {
          dispose();
        } catch (IabAsyncInProgressException iabAsyncInProgressException) {}
      } 
      return;
    } 
  }
  
  public void enableDebugLogging(boolean paramBoolean) {
    checkNotDisposed();
    this.mDebugLog = paramBoolean;
  }
  
  public void enableDebugLogging(boolean paramBoolean, String paramString) {
    checkNotDisposed();
    this.mDebugLog = paramBoolean;
    this.mDebugTag = paramString;
  }
  
  void flagEndAsync() {
    synchronized (this.mAsyncInProgressLock) {
      logDebug("Ending async operation: " + this.mAsyncOperation);
      this.mAsyncOperation = "";
      this.mAsyncInProgress = false;
      boolean bool = this.mDisposeAfterAsync;
      if (bool)
        try {
          dispose();
        } catch (IabAsyncInProgressException iabAsyncInProgressException) {} 
      return;
    } 
  }
  
  void flagStartAsync(String paramString) throws IabAsyncInProgressException {
    synchronized (this.mAsyncInProgressLock) {
      if (this.mAsyncInProgress)
        throw new IabAsyncInProgressException("Can't start async operation (" + paramString + ") because another async operation (" + this.mAsyncOperation + ") is in progress."); 
    } 
    this.mAsyncOperation = paramString;
    this.mAsyncInProgress = true;
    logDebug("Starting async operation: " + paramString);
    /* monitor exit ClassFileLocalVariableReferenceExpression{type=ObjectType{java/lang/Object}, name=SYNTHETIC_LOCAL_VARIABLE_2} */
  }
  
  int getResponseCodeFromBundle(Bundle paramBundle) {
    Object object = paramBundle.get("RESPONSE_CODE");
    if (object == null) {
      logDebug("Bundle with null response code, assuming OK (known issue)");
      return 0;
    } 
    if (object instanceof Integer)
      return ((Integer)object).intValue(); 
    if (object instanceof Long)
      return (int)((Long)object).longValue(); 
    logError("Unexpected type for bundle response code.");
    logError(object.getClass().getName());
    throw new RuntimeException("Unexpected type for bundle response code: " + object.getClass().getName());
  }
  
  int getResponseCodeFromIntent(Intent paramIntent) {
    Object object = paramIntent.getExtras().get("RESPONSE_CODE");
    if (object == null) {
      logError("Intent with no response code, assuming OK (known issue)");
      return 0;
    } 
    if (object instanceof Integer)
      return ((Integer)object).intValue(); 
    if (object instanceof Long)
      return (int)((Long)object).longValue(); 
    logError("Unexpected type for intent response code.");
    logError(object.getClass().getName());
    throw new RuntimeException("Unexpected type for intent response code: " + object.getClass().getName());
  }
  
  public boolean handleActivityResult(int paramInt1, int paramInt2, Intent paramIntent) {
    if (paramInt1 != this.mRequestCode)
      return false; 
    checkNotDisposed();
    checkSetupDone("handleActivityResult");
    flagEndAsync();
    if (paramIntent == null) {
      logError("Null data in IAB activity result.");
      iabResult = new IabResult(-1002, "Null data in IAB result");
      if (this.mPurchaseListener != null)
        this.mPurchaseListener.onIabPurchaseFinished(iabResult, null); 
      return true;
    } 
    paramInt1 = getResponseCodeFromIntent((Intent)iabResult);
    String str1 = iabResult.getStringExtra("INAPP_PURCHASE_DATA");
    String str2 = iabResult.getStringExtra("INAPP_DATA_SIGNATURE");
    if (paramInt2 == -1 && paramInt1 == 0) {
      logDebug("Successful resultcode from purchase activity.");
      logDebug("Purchase data: " + str1);
      logDebug("Data signature: " + str2);
      logDebug("Extras: " + iabResult.getExtras());
      logDebug("Expected item type: " + this.mPurchasingItemType);
      if (str1 == null || str2 == null) {
        logError("BUG: either purchaseData or dataSignature is null.");
        logDebug("Extras: " + iabResult.getExtras().toString());
        iabResult = new IabResult(-1008, "IAB returned null purchaseData or dataSignature");
        if (this.mPurchaseListener != null)
          this.mPurchaseListener.onIabPurchaseFinished(iabResult, null); 
        return true;
      } 
      try {
        Purchase purchase = new Purchase(this.mPurchasingItemType, str1, str2);
        try {
          String str = purchase.getSku();
          if (!Security.verifyPurchase(this.mSignatureBase64, str1, str2)) {
            logError("Purchase signature verification FAILED for sku " + str);
            IabResult iabResult2 = new IabResult(-1003, "Signature verification failed for sku " + str);
            if (this.mPurchaseListener != null)
              this.mPurchaseListener.onIabPurchaseFinished(iabResult2, purchase); 
          } else {
            logDebug("Purchase signature successfully verified.");
            if (this.mPurchaseListener != null)
              this.mPurchaseListener.onIabPurchaseFinished(new IabResult(0, "Success"), purchase); 
            return true;
          } 
        } catch (JSONException null) {}
      } catch (JSONException jSONException) {}
      logError("Failed to parse purchase data.");
      jSONException.printStackTrace();
      IabResult iabResult1 = new IabResult(-1002, "Failed to parse purchase data.");
      if (this.mPurchaseListener != null)
        this.mPurchaseListener.onIabPurchaseFinished(iabResult1, null); 
      return true;
    } 
    if (paramInt2 == -1) {
      logDebug("Result code was OK but in-app billing response was not OK: " + getResponseDesc(paramInt1));
      if (this.mPurchaseListener != null) {
        iabResult = new IabResult(paramInt1, "Problem purchashing item.");
        this.mPurchaseListener.onIabPurchaseFinished(iabResult, null);
      } 
      return true;
    } 
    if (paramInt2 == 0) {
      logDebug("Purchase canceled - Response: " + getResponseDesc(paramInt1));
      iabResult = new IabResult(-1005, "User canceled.");
      if (this.mPurchaseListener != null)
        this.mPurchaseListener.onIabPurchaseFinished(iabResult, null); 
      return true;
    } 
    logError("Purchase failed. Result code: " + Integer.toString(paramInt2) + ". Response: " + getResponseDesc(paramInt1));
    IabResult iabResult = new IabResult(-1006, "Unknown purchase response.");
    if (this.mPurchaseListener != null)
      this.mPurchaseListener.onIabPurchaseFinished(iabResult, null); 
    return true;
  }
  
  public void launchPurchaseFlow(Activity paramActivity, String paramString, int paramInt, OnIabPurchaseFinishedListener paramOnIabPurchaseFinishedListener) throws IabAsyncInProgressException {
    launchPurchaseFlow(paramActivity, paramString, paramInt, paramOnIabPurchaseFinishedListener, "");
  }
  
  public void launchPurchaseFlow(Activity paramActivity, String paramString1, int paramInt, OnIabPurchaseFinishedListener paramOnIabPurchaseFinishedListener, String paramString2) throws IabAsyncInProgressException {
    launchPurchaseFlow(paramActivity, paramString1, "inapp", null, paramInt, paramOnIabPurchaseFinishedListener, paramString2);
  }
  
  public void launchPurchaseFlow(Activity paramActivity, String paramString1, String paramString2, List<String> paramList, int paramInt, OnIabPurchaseFinishedListener paramOnIabPurchaseFinishedListener, String paramString3) throws IabAsyncInProgressException {
    IabResult iabResult;
    Bundle bundle;
    checkNotDisposed();
    checkSetupDone("launchPurchaseFlow");
    flagStartAsync("launchPurchaseFlow");
    if (paramString2.equals("subs") && !this.mSubscriptionsSupported) {
      iabResult = new IabResult(-1009, "Subscriptions are not available.");
      flagEndAsync();
      if (paramOnIabPurchaseFinishedListener != null)
        paramOnIabPurchaseFinishedListener.onIabPurchaseFinished(iabResult, null); 
      return;
    } 
    try {
      logDebug("Constructing buy intent for " + paramString1 + ", item type: " + paramString2);
      if (paramList == null || paramList.isEmpty()) {
        bundle = this.mService.getBuyIntent(3, this.mContext.getPackageName(), paramString1, paramString2, paramString3);
      } else {
        if (!this.mSubscriptionUpdateSupported) {
          iabResult = new IabResult(-1011, "Subscription updates are not available.");
          flagEndAsync();
          if (paramOnIabPurchaseFinishedListener != null) {
            paramOnIabPurchaseFinishedListener.onIabPurchaseFinished(iabResult, null);
            return;
          } 
          return;
        } 
        bundle = this.mService.getBuyIntentToReplaceSkus(5, this.mContext.getPackageName(), (List<String>)bundle, paramString1, paramString2, paramString3);
      } 
      int i = getResponseCodeFromBundle(bundle);
      if (i != 0) {
        logError("Unable to buy item, Error response: " + getResponseDesc(i));
        flagEndAsync();
        iabResult = new IabResult(i, "Unable to buy item");
        if (paramOnIabPurchaseFinishedListener != null) {
          paramOnIabPurchaseFinishedListener.onIabPurchaseFinished(iabResult, null);
          return;
        } 
        return;
      } 
    } catch (android.content.IntentSender.SendIntentException sendIntentException) {
      logError("SendIntentException while launching purchase flow for sku " + paramString1);
      sendIntentException.printStackTrace();
      flagEndAsync();
      iabResult = new IabResult(-1004, "Failed to send intent.");
      if (paramOnIabPurchaseFinishedListener != null) {
        paramOnIabPurchaseFinishedListener.onIabPurchaseFinished(iabResult, null);
        return;
      } 
      return;
    } catch (RemoteException remoteException) {
      logError("RemoteException while launching purchase flow for sku " + paramString1);
      remoteException.printStackTrace();
      flagEndAsync();
      iabResult = new IabResult(-1001, "Remote exception while starting purchase flow");
      if (paramOnIabPurchaseFinishedListener != null) {
        paramOnIabPurchaseFinishedListener.onIabPurchaseFinished(iabResult, null);
        return;
      } 
      return;
    } 
    PendingIntent pendingIntent = (PendingIntent)bundle.getParcelable("BUY_INTENT");
    logDebug("Launching buy intent for " + paramString1 + ". Request code: " + paramInt);
    this.mRequestCode = paramInt;
    this.mPurchaseListener = paramOnIabPurchaseFinishedListener;
    this.mPurchasingItemType = paramString2;
    iabResult.startIntentSenderForResult(pendingIntent.getIntentSender(), paramInt, new Intent(), Integer.valueOf(0).intValue(), Integer.valueOf(0).intValue(), Integer.valueOf(0).intValue());
  }
  
  public void launchSubscriptionPurchaseFlow(Activity paramActivity, String paramString, int paramInt, OnIabPurchaseFinishedListener paramOnIabPurchaseFinishedListener) throws IabAsyncInProgressException {
    launchSubscriptionPurchaseFlow(paramActivity, paramString, paramInt, paramOnIabPurchaseFinishedListener, "");
  }
  
  public void launchSubscriptionPurchaseFlow(Activity paramActivity, String paramString1, int paramInt, OnIabPurchaseFinishedListener paramOnIabPurchaseFinishedListener, String paramString2) throws IabAsyncInProgressException {
    launchPurchaseFlow(paramActivity, paramString1, "subs", null, paramInt, paramOnIabPurchaseFinishedListener, paramString2);
  }
  
  void logDebug(String paramString) {
    if (this.mDebugLog)
      Log.d(this.mDebugTag, paramString); 
  }
  
  void logError(String paramString) {
    Log.e(this.mDebugTag, "In-app billing error: " + paramString);
  }
  
  void logWarn(String paramString) {
    Log.w(this.mDebugTag, "In-app billing warning: " + paramString);
  }
  
  public Inventory queryInventory() throws IabException {
    return queryInventory(false, null, null);
  }
  
  public Inventory queryInventory(boolean paramBoolean, List<String> paramList1, List<String> paramList2) throws IabException {
    Inventory inventory;
    checkNotDisposed();
    checkSetupDone("queryInventory");
    try {
      inventory = new Inventory();
      int i = queryPurchases(inventory, "inapp");
      if (i != 0)
        throw new IabException(i, "Error refreshing inventory (querying owned items)."); 
      if (paramBoolean) {
        i = querySkuDetails("inapp", inventory, paramList1);
        if (i != 0)
          throw new IabException(i, "Error refreshing inventory (querying prices of items)."); 
      } 
    } catch (RemoteException remoteException) {
      throw new IabException(-1001, "Remote exception while refreshing inventory.", remoteException);
    } catch (JSONException jSONException) {
      throw new IabException(-1002, "Error parsing JSON response while refreshing inventory.", jSONException);
    } 
    if (this.mSubscriptionsSupported) {
      int i = queryPurchases(inventory, "subs");
      if (i != 0)
        throw new IabException(i, "Error refreshing inventory (querying owned subscriptions)."); 
      if (paramBoolean) {
        i = querySkuDetails("subs", inventory, paramList2);
        if (i != 0)
          throw new IabException(i, "Error refreshing inventory (querying prices of subscriptions)."); 
      } 
    } 
    return inventory;
  }
  
  public void queryInventoryAsync(QueryInventoryFinishedListener paramQueryInventoryFinishedListener) throws IabAsyncInProgressException {
    queryInventoryAsync(false, null, null, paramQueryInventoryFinishedListener);
  }
  
  public void queryInventoryAsync(final boolean querySkuDetails, final List<String> moreItemSkus, final List<String> moreSubsSkus, final QueryInventoryFinishedListener listener) throws IabAsyncInProgressException {
    final Handler handler = new Handler();
    checkNotDisposed();
    checkSetupDone("queryInventory");
    flagStartAsync("refresh inventory");
    (new Thread(new Runnable() {
          public void run() {
            final IabResult result_f = new IabResult(0, "Inventory refresh successful.");
            final Inventory inv_f = null;
            try {
              Inventory inventory1 = IabHelper.this.queryInventory(querySkuDetails, moreItemSkus, moreSubsSkus);
              inventory = inventory1;
            } catch (IabException iabException) {
              iabResult = iabException.getResult();
            } 
            IabHelper.this.flagEndAsync();
            if (!IabHelper.this.mDisposed && listener != null)
              handler.post(new Runnable() {
                    public void run() {
                      listener.onQueryInventoryFinished(result_f, inv_f);
                    }
                  }); 
          }
        })).start();
  }
  
  int queryPurchases(Inventory paramInventory, String paramString) throws JSONException, RemoteException {
    logDebug("Querying owned items, item type: " + paramString);
    logDebug("Package name: " + this.mContext.getPackageName());
    int i = 0;
    String str = null;
    label30: while (true) {
      logDebug("Calling getPurchases with continuation token: " + str);
      Bundle bundle = this.mService.getPurchases(3, this.mContext.getPackageName(), paramString, str);
      int j = getResponseCodeFromBundle(bundle);
      logDebug("Owned items response: " + String.valueOf(j));
      if (j != 0) {
        logDebug("getPurchases() failed: " + getResponseDesc(j));
        return j;
      } 
      if (!bundle.containsKey("INAPP_PURCHASE_ITEM_LIST") || !bundle.containsKey("INAPP_PURCHASE_DATA_LIST") || !bundle.containsKey("INAPP_DATA_SIGNATURE_LIST")) {
        logError("Bundle returned from getPurchases() doesn't contain required fields.");
        return -1002;
      } 
      ArrayList arrayList = bundle.getStringArrayList("INAPP_PURCHASE_ITEM_LIST");
      ArrayList<String> arrayList1 = bundle.getStringArrayList("INAPP_PURCHASE_DATA_LIST");
      ArrayList<String> arrayList2 = bundle.getStringArrayList("INAPP_DATA_SIGNATURE_LIST");
      byte b = 0;
      j = i;
      for (i = b;; i++) {
        String str1;
        Purchase purchase;
        if (i >= arrayList1.size()) {
          str1 = bundle.getString("INAPP_CONTINUATION_TOKEN");
          logDebug("Continuation token: " + str1);
          String str5 = str1;
          i = j;
          if (TextUtils.isEmpty(str1))
            return (j != 0) ? -1003 : 0; 
          continue label30;
        } 
        String str2 = arrayList1.get(i);
        String str3 = arrayList2.get(i);
        String str4 = str1.get(i);
        if (Security.verifyPurchase(this.mSignatureBase64, str2, str3)) {
          logDebug("Sku is owned: " + str4);
          purchase = new Purchase(paramString, str2, str3);
          if (TextUtils.isEmpty(purchase.getToken())) {
            logWarn("BUG: empty/null token!");
            logDebug("Purchase data: " + str2);
          } 
          paramInventory.addPurchase(purchase);
        } else {
          logWarn("Purchase signature verification **FAILED**. Not adding item.");
          logDebug("   Purchase data: " + str2);
          logDebug("   Signature: " + purchase);
          j = 1;
        } 
      } 
      break;
    } 
  }
  
  int querySkuDetails(String paramString, Inventory paramInventory, List<String> paramList) throws RemoteException, JSONException {
    // Byte code:
    //   0: aload_0
    //   1: ldc_w 'Querying SKU details.'
    //   4: invokevirtual logDebug : (Ljava/lang/String;)V
    //   7: new java/util/ArrayList
    //   10: dup
    //   11: invokespecial <init> : ()V
    //   14: astore #7
    //   16: aload #7
    //   18: aload_2
    //   19: aload_1
    //   20: invokevirtual getAllOwnedSkus : (Ljava/lang/String;)Ljava/util/List;
    //   23: invokevirtual addAll : (Ljava/util/Collection;)Z
    //   26: pop
    //   27: aload_3
    //   28: ifnull -> 47
    //   31: aload_3
    //   32: invokeinterface iterator : ()Ljava/util/Iterator;
    //   37: astore_3
    //   38: aload_3
    //   39: invokeinterface hasNext : ()Z
    //   44: ifne -> 64
    //   47: aload #7
    //   49: invokevirtual size : ()I
    //   52: ifne -> 96
    //   55: aload_0
    //   56: ldc_w 'queryPrices: nothing to do because there are no SKUs.'
    //   59: invokevirtual logDebug : (Ljava/lang/String;)V
    //   62: iconst_0
    //   63: ireturn
    //   64: aload_3
    //   65: invokeinterface next : ()Ljava/lang/Object;
    //   70: checkcast java/lang/String
    //   73: astore #8
    //   75: aload #7
    //   77: aload #8
    //   79: invokevirtual contains : (Ljava/lang/Object;)Z
    //   82: ifne -> 38
    //   85: aload #7
    //   87: aload #8
    //   89: invokevirtual add : (Ljava/lang/Object;)Z
    //   92: pop
    //   93: goto -> 38
    //   96: new java/util/ArrayList
    //   99: dup
    //   100: invokespecial <init> : ()V
    //   103: astore_3
    //   104: aload #7
    //   106: invokevirtual size : ()I
    //   109: bipush #20
    //   111: idiv
    //   112: istore #5
    //   114: aload #7
    //   116: invokevirtual size : ()I
    //   119: bipush #20
    //   121: irem
    //   122: istore #6
    //   124: iconst_0
    //   125: istore #4
    //   127: iload #4
    //   129: iload #5
    //   131: if_icmplt -> 206
    //   134: iload #6
    //   136: ifeq -> 190
    //   139: new java/util/ArrayList
    //   142: dup
    //   143: invokespecial <init> : ()V
    //   146: astore #8
    //   148: aload #7
    //   150: iload #5
    //   152: bipush #20
    //   154: imul
    //   155: iload #5
    //   157: bipush #20
    //   159: imul
    //   160: iload #6
    //   162: iadd
    //   163: invokevirtual subList : (II)Ljava/util/List;
    //   166: invokeinterface iterator : ()Ljava/util/Iterator;
    //   171: astore #7
    //   173: aload #7
    //   175: invokeinterface hasNext : ()Z
    //   180: ifne -> 285
    //   183: aload_3
    //   184: aload #8
    //   186: invokevirtual add : (Ljava/lang/Object;)Z
    //   189: pop
    //   190: aload_3
    //   191: invokevirtual iterator : ()Ljava/util/Iterator;
    //   194: astore_3
    //   195: aload_3
    //   196: invokeinterface hasNext : ()Z
    //   201: ifne -> 304
    //   204: iconst_0
    //   205: ireturn
    //   206: new java/util/ArrayList
    //   209: dup
    //   210: invokespecial <init> : ()V
    //   213: astore #8
    //   215: aload #7
    //   217: iload #4
    //   219: bipush #20
    //   221: imul
    //   222: iload #4
    //   224: bipush #20
    //   226: imul
    //   227: bipush #20
    //   229: iadd
    //   230: invokevirtual subList : (II)Ljava/util/List;
    //   233: invokeinterface iterator : ()Ljava/util/Iterator;
    //   238: astore #9
    //   240: aload #9
    //   242: invokeinterface hasNext : ()Z
    //   247: ifne -> 266
    //   250: aload_3
    //   251: aload #8
    //   253: invokevirtual add : (Ljava/lang/Object;)Z
    //   256: pop
    //   257: iload #4
    //   259: iconst_1
    //   260: iadd
    //   261: istore #4
    //   263: goto -> 127
    //   266: aload #8
    //   268: aload #9
    //   270: invokeinterface next : ()Ljava/lang/Object;
    //   275: checkcast java/lang/String
    //   278: invokevirtual add : (Ljava/lang/Object;)Z
    //   281: pop
    //   282: goto -> 240
    //   285: aload #8
    //   287: aload #7
    //   289: invokeinterface next : ()Ljava/lang/Object;
    //   294: checkcast java/lang/String
    //   297: invokevirtual add : (Ljava/lang/Object;)Z
    //   300: pop
    //   301: goto -> 173
    //   304: aload_3
    //   305: invokeinterface next : ()Ljava/lang/Object;
    //   310: checkcast java/util/ArrayList
    //   313: astore #7
    //   315: new android/os/Bundle
    //   318: dup
    //   319: invokespecial <init> : ()V
    //   322: astore #8
    //   324: aload #8
    //   326: ldc 'ITEM_ID_LIST'
    //   328: aload #7
    //   330: invokevirtual putStringArrayList : (Ljava/lang/String;Ljava/util/ArrayList;)V
    //   333: aload_0
    //   334: getfield mService : Lcom/android/vending/billing/IInAppBillingService;
    //   337: iconst_3
    //   338: aload_0
    //   339: getfield mContext : Landroid/content/Context;
    //   342: invokevirtual getPackageName : ()Ljava/lang/String;
    //   345: aload_1
    //   346: aload #8
    //   348: invokeinterface getSkuDetails : (ILjava/lang/String;Ljava/lang/String;Landroid/os/Bundle;)Landroid/os/Bundle;
    //   353: astore #7
    //   355: aload #7
    //   357: ldc 'DETAILS_LIST'
    //   359: invokevirtual containsKey : (Ljava/lang/String;)Z
    //   362: ifne -> 417
    //   365: aload_0
    //   366: aload #7
    //   368: invokevirtual getResponseCodeFromBundle : (Landroid/os/Bundle;)I
    //   371: istore #4
    //   373: iload #4
    //   375: ifeq -> 406
    //   378: aload_0
    //   379: new java/lang/StringBuilder
    //   382: dup
    //   383: ldc_w 'getSkuDetails() failed: '
    //   386: invokespecial <init> : (Ljava/lang/String;)V
    //   389: iload #4
    //   391: invokestatic getResponseDesc : (I)Ljava/lang/String;
    //   394: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   397: invokevirtual toString : ()Ljava/lang/String;
    //   400: invokevirtual logDebug : (Ljava/lang/String;)V
    //   403: iload #4
    //   405: ireturn
    //   406: aload_0
    //   407: ldc_w 'getSkuDetails() returned a bundle with neither an error nor a detail list.'
    //   410: invokevirtual logError : (Ljava/lang/String;)V
    //   413: sipush #-1002
    //   416: ireturn
    //   417: aload #7
    //   419: ldc 'DETAILS_LIST'
    //   421: invokevirtual getStringArrayList : (Ljava/lang/String;)Ljava/util/ArrayList;
    //   424: invokevirtual iterator : ()Ljava/util/Iterator;
    //   427: astore #7
    //   429: aload #7
    //   431: invokeinterface hasNext : ()Z
    //   436: ifeq -> 195
    //   439: new com/android/vending/billing/SkuDetails
    //   442: dup
    //   443: aload_1
    //   444: aload #7
    //   446: invokeinterface next : ()Ljava/lang/Object;
    //   451: checkcast java/lang/String
    //   454: invokespecial <init> : (Ljava/lang/String;Ljava/lang/String;)V
    //   457: astore #8
    //   459: aload_0
    //   460: new java/lang/StringBuilder
    //   463: dup
    //   464: ldc_w 'Got sku details: '
    //   467: invokespecial <init> : (Ljava/lang/String;)V
    //   470: aload #8
    //   472: invokevirtual append : (Ljava/lang/Object;)Ljava/lang/StringBuilder;
    //   475: invokevirtual toString : ()Ljava/lang/String;
    //   478: invokevirtual logDebug : (Ljava/lang/String;)V
    //   481: aload_2
    //   482: aload #8
    //   484: invokevirtual addSkuDetails : (Lcom/android/vending/billing/SkuDetails;)V
    //   487: goto -> 429
  }
  
  public void startSetup(final OnIabSetupFinishedListener listener) {
    checkNotDisposed();
    if (this.mSetupDone)
      throw new IllegalStateException("IAB helper is already set up."); 
    logDebug("Starting in-app billing setup.");
    this.mServiceConn = new ServiceConnection() {
        public void onServiceConnected(ComponentName param1ComponentName, IBinder param1IBinder) {
          if (!IabHelper.this.mDisposed) {
            IabHelper.this.logDebug("Billing service connected.");
            IabHelper.this.mService = IInAppBillingService.Stub.asInterface(param1IBinder);
            String str = IabHelper.this.mContext.getPackageName();
            try {
              IabHelper.this.logDebug("Checking for in-app billing 3 support.");
              int i = IabHelper.this.mService.isBillingSupported(3, str, "inapp");
              if (i != 0) {
                if (listener != null)
                  listener.onIabSetupFinished(new IabResult(i, "Error checking for billing v3 support.")); 
                IabHelper.this.mSubscriptionsSupported = false;
                IabHelper.this.mSubscriptionUpdateSupported = false;
                return;
              } 
            } catch (RemoteException remoteException) {
              if (listener != null)
                listener.onIabSetupFinished(new IabResult(-1001, "RemoteException while setting up in-app billing.")); 
              remoteException.printStackTrace();
              return;
            } 
            IabHelper.this.logDebug("In-app billing version 3 supported for " + remoteException);
            if (IabHelper.this.mService.isBillingSupported(5, (String)remoteException, "subs") == 0) {
              IabHelper.this.logDebug("Subscription re-signup AVAILABLE.");
              IabHelper.this.mSubscriptionUpdateSupported = true;
            } else {
              IabHelper.this.logDebug("Subscription re-signup not available.");
              IabHelper.this.mSubscriptionUpdateSupported = false;
            } 
            if (IabHelper.this.mSubscriptionUpdateSupported) {
              IabHelper.this.mSubscriptionsSupported = true;
            } else {
              int i = IabHelper.this.mService.isBillingSupported(3, (String)remoteException, "subs");
              if (i == 0) {
                IabHelper.this.logDebug("Subscriptions AVAILABLE.");
                IabHelper.this.mSubscriptionsSupported = true;
              } else {
                IabHelper.this.logDebug("Subscriptions NOT AVAILABLE. Response: " + i);
                IabHelper.this.mSubscriptionsSupported = false;
                IabHelper.this.mSubscriptionUpdateSupported = false;
              } 
            } 
            IabHelper.this.mSetupDone = true;
            if (listener != null) {
              listener.onIabSetupFinished(new IabResult(0, "Setup successful."));
              return;
            } 
          } 
        }
        
        public void onServiceDisconnected(ComponentName param1ComponentName) {
          IabHelper.this.logDebug("Billing service disconnected.");
          IabHelper.this.mService = null;
        }
      };
    Intent intent = new Intent("com.android.vending.billing.InAppBillingService.BIND");
    intent.setPackage("com.android.vending");
    List list = this.mContext.getPackageManager().queryIntentServices(intent, 0);
    if (list != null && !list.isEmpty()) {
      this.mContext.bindService(intent, this.mServiceConn, 1);
      return;
    } 
    if (listener != null) {
      listener.onIabSetupFinished(new IabResult(3, "Billing service unavailable on device."));
      return;
    } 
  }
  
  public boolean subscriptionsSupported() {
    checkNotDisposed();
    return this.mSubscriptionsSupported;
  }
  
  public static class IabAsyncInProgressException extends Exception {
    public IabAsyncInProgressException(String param1String) {
      super(param1String);
    }
  }
  
  public static interface OnConsumeFinishedListener {
    void onConsumeFinished(Purchase param1Purchase, IabResult param1IabResult);
  }
  
  public static interface OnConsumeMultiFinishedListener {
    void onConsumeMultiFinished(List<Purchase> param1List, List<IabResult> param1List1);
  }
  
  public static interface OnIabPurchaseFinishedListener {
    void onIabPurchaseFinished(IabResult param1IabResult, Purchase param1Purchase);
  }
  
  public static interface OnIabSetupFinishedListener {
    void onIabSetupFinished(IabResult param1IabResult);
  }
  
  public static interface QueryInventoryFinishedListener {
    void onQueryInventoryFinished(IabResult param1IabResult, Inventory param1Inventory);
  }
}


/* Location:              C:\soft\dex2jar-2.0\Tom Run-dex2jar.jar!\com\android\vending\billing\IabHelper.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */