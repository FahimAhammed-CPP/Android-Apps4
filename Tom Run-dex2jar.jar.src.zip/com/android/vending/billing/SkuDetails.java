package com.android.vending.billing;

import org.json.JSONException;
import org.json.JSONObject;

public class SkuDetails {
  private final String mDescription;
  
  private final String mItemType;
  
  private final String mJson;
  
  private final String mPrice;
  
  private final long mPriceAmountMicros;
  
  private final String mPriceCurrencyCode;
  
  private final String mSku;
  
  private final String mTitle;
  
  private final String mType;
  
  public SkuDetails(String paramString) throws JSONException {
    this("inapp", paramString);
  }
  
  public SkuDetails(String paramString1, String paramString2) throws JSONException {
    this.mItemType = paramString1;
    this.mJson = paramString2;
    JSONObject jSONObject = new JSONObject(this.mJson);
    this.mSku = jSONObject.optString("productId");
    this.mType = jSONObject.optString("type");
    this.mPrice = jSONObject.optString("price");
    this.mPriceAmountMicros = jSONObject.optLong("price_amount_micros");
    this.mPriceCurrencyCode = jSONObject.optString("price_currency_code");
    this.mTitle = jSONObject.optString("title");
    this.mDescription = jSONObject.optString("description");
  }
  
  public String getDescription() {
    return this.mDescription;
  }
  
  public String getPrice() {
    return this.mPrice;
  }
  
  public long getPriceAmountMicros() {
    return this.mPriceAmountMicros;
  }
  
  public String getPriceCurrencyCode() {
    return this.mPriceCurrencyCode;
  }
  
  public String getSku() {
    return this.mSku;
  }
  
  public String getTitle() {
    return this.mTitle;
  }
  
  public String getType() {
    return this.mType;
  }
  
  public String toString() {
    return "SkuDetails:" + this.mJson;
  }
}


/* Location:              C:\soft\dex2jar-2.0\Tom Run-dex2jar.jar!\com\android\vending\billing\SkuDetails.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */