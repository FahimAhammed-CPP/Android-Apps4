package com.android.vending.billing;

public class IabResult {
  String mMessage;
  
  int mResponse;
  
  public IabResult(int paramInt, String paramString) {
    this.mResponse = paramInt;
    if (paramString == null || paramString.trim().length() == 0) {
      this.mMessage = IabHelper.getResponseDesc(paramInt);
      return;
    } 
    this.mMessage = String.valueOf(paramString) + " (response: " + IabHelper.getResponseDesc(paramInt) + ")";
  }
  
  public String getMessage() {
    return this.mMessage;
  }
  
  public int getResponse() {
    return this.mResponse;
  }
  
  public boolean isFailure() {
    return !isSuccess();
  }
  
  public boolean isSuccess() {
    return (this.mResponse == 0);
  }
  
  public String toString() {
    return "IabResult: " + getMessage();
  }
}


/* Location:              C:\soft\dex2jar-2.0\Tom Run-dex2jar.jar!\com\android\vending\billing\IabResult.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */