package com.lt.paokugogogo;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import com.cnlt.pay.LTPayInterface;
import com.nt.common.NTEventHandler;
import com.nt.common.NTJniHelper;
import org.cocos2dx.lib.Cocos2dxActivity;
import org.cocos2dx.lib.Cocos2dxGLSurfaceView;

public class HelloCpp extends Cocos2dxActivity {
  private static final String TAG = "flybird";
  
  private Activity mContext;
  
  private NTEventHandler msgHandler;
  
  static {
    System.loadLibrary("hellocpp");
  }
  
  protected void onActivityResult(int paramInt1, int paramInt2, Intent paramIntent) {
    if (!LTPayInterface.handleActivityResult(paramInt1, paramInt2, paramIntent))
      super.onActivityResult(paramInt1, paramInt2, paramIntent); 
  }
  
  protected void onCreate(Bundle paramBundle) {
    super.onCreate(paramBundle);
    this.mContext = (Activity)this;
    this.msgHandler = new NTEventHandler((Context)this.mContext);
    NTJniHelper.init(this.msgHandler);
    NTJniHelper.init((Context)this.mContext);
    LTPayInterface.initializeApp((Context)this, "", "");
  }
  
  public Cocos2dxGLSurfaceView onCreateView() {
    Cocos2dxGLSurfaceView cocos2dxGLSurfaceView = new Cocos2dxGLSurfaceView((Context)this);
    cocos2dxGLSurfaceView.setEGLConfigChooser(5, 6, 5, 0, 16, 8);
    return cocos2dxGLSurfaceView;
  }
  
  protected void onDestroy() {
    super.onDestroy();
    LTPayInterface.onDestroy();
  }
  
  protected void onPause() {
    super.onPause();
    LTPayInterface.onPause((Activity)this);
  }
  
  protected void onResume() {
    super.onResume();
    LTPayInterface.onResume((Activity)this);
  }
}


/* Location:              C:\soft\dex2jar-2.0\Tom Run-dex2jar.jar!\com\lt\paokugogogo\HelloCpp.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */