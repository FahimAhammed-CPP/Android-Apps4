package com.nt.common;

import android.app.AlertDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.os.Handler;
import android.os.Message;
import android.view.View;
import android.widget.EditText;
import android.widget.Toast;

public class NTJniHelper {
  public static final int DOWNLOAD = 8197;
  
  public static final int EXIT_APP = 4099;
  
  public static final int GAME_SCORE = 8195;
  
  public static final int PAY_BUY = 4098;
  
  public static final int SHARE_APP = 8194;
  
  public static final int SHOW_LOADING = 1;
  
  public static final int SHOW_TIPS = 8196;
  
  private static Context mContext;
  
  private static NTEventHandler mHandler;
  
  private static String myName = "";
  
  private static Handler payHandler;
  
  private static Handler toCHandler;
  
  static {
    mContext = null;
    toCHandler = new Handler() {
        public void handleMessage(Message param1Message) {
          NTJniHelper.toRegisterName(NTJniHelper.myName);
        }
      };
    payHandler = new Handler() {
        public void handleMessage(Message param1Message) {
          final EditText inputServer = new EditText(NTJniHelper.mContext);
          AlertDialog.Builder builder = new AlertDialog.Builder(NTJniHelper.mContext);
          builder.setTitle("�ף� ����������").setIcon(17301659).setView((View)editText).setNegativeButton("ȡ��", null);
          builder.setPositiveButton("�ύ", new DialogInterface.OnClickListener() {
                public void onClick(DialogInterface param2DialogInterface, int param2Int) {
                  String str = inputServer.getText().toString();
                  if (str.length() >= 2 && str.length() <= 8) {
                    Toast.makeText(NTJniHelper.mContext, "�����ɹ�����л���֧��!", 0).show();
                    NTJniHelper.myName = str;
                    NTJniHelper.toCHandler.sendEmptyMessage(0);
                    return;
                  } 
                  NTJniHelper.registerName();
                  Toast.makeText(NTJniHelper.mContext, "���ֳ��Ƚ�������2��8���ַ�", 0).show();
                }
              });
          builder.show();
        }
      };
  }
  
  public static void download(String paramString) {
    Message message = mHandler.obtainMessage(8197);
    message.obj = paramString;
    message.sendToTarget();
  }
  
  public static void init(Context paramContext) {
    mContext = paramContext;
  }
  
  public static void init(NTEventHandler paramNTEventHandler) {
    mHandler = paramNTEventHandler;
  }
  
  public static void jniRequest(int paramInt1, int paramInt2, int paramInt3) {
    Message message = mHandler.obtainMessage(paramInt1);
    message.arg1 = paramInt2;
    message.arg2 = paramInt3;
    message.sendToTarget();
  }
  
  public static void ktUpdate() {}
  
  public static void registerName() {
    payHandler.sendEmptyMessage(0);
  }
  
  public static void showTips(String paramString) {
    Message message = mHandler.obtainMessage(8196);
    message.obj = paramString;
    message.sendToTarget();
  }
  
  public static native void toRegisterName(String paramString);
}


/* Location:              C:\soft\dex2jar-2.0\Tom Run-dex2jar.jar!\com\nt\common\NTJniHelper.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */