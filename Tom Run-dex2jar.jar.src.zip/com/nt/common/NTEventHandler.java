package com.nt.common;

import android.app.ProgressDialog;
import android.content.Context;
import android.content.Intent;
import android.net.Uri;
import android.os.Handler;
import android.os.Message;
import android.view.LayoutInflater;
import android.view.View;
import android.view.animation.AnimationUtils;
import android.widget.TextView;
import android.widget.Toast;

public class NTEventHandler extends Handler {
  private long lastShowTipTime = 0L;
  
  private ProgressDialog loading;
  
  private Context mContext = null;
  
  public NTEventHandler(Context paramContext) {
    this.mContext = paramContext;
  }
  
  private void loading(int paramInt) {
    if (paramInt == 1) {
      if (this.loading == null) {
        this.loading = ProgressDialog.show(this.mContext, "", "���ݼ����У� ���Ժ�~", true);
        this.loading.setContentView(2130903040);
        return;
      } 
      return;
    } 
    if (this.loading != null) {
      this.loading.dismiss();
      this.loading = null;
      return;
    } 
  }
  
  public void downLoad(String paramString) {
    Intent intent = new Intent();
    intent.setData(Uri.parse(paramString));
    intent.setAction("android.intent.action.VIEW");
    intent.setFlags(268435456);
    try {
      this.mContext.startActivity(intent);
      return;
    } catch (Exception exception) {
      myToast("��������쳣", 0, 2130968576, true);
      return;
    } 
  }
  
  public void handleMessage(Message paramMessage) {
    super.handleMessage(paramMessage);
    switch (paramMessage.what) {
      default:
        return;
      case 1:
        loading(paramMessage.arg1);
        return;
      case 8196:
        myToast((String)paramMessage.obj, 0, 2130968576, true);
        return;
      case 8197:
        break;
    } 
    downLoad((String)paramMessage.obj);
  }
  
  public void myToast(String paramString, int paramInt1, int paramInt2, boolean paramBoolean) {
    this.lastShowTipTime = System.currentTimeMillis();
    View view = LayoutInflater.from(this.mContext).inflate(2130903041, null);
    Toast toast = new Toast(this.mContext.getApplicationContext());
    toast.setView(view);
    toast.setDuration(paramInt1);
    TextView textView = (TextView)view.findViewById(2131099650);
    textView.setText(paramString);
    if (paramBoolean)
      textView.startAnimation(AnimationUtils.loadAnimation(this.mContext, paramInt2)); 
    toast.show();
  }
}


/* Location:              C:\soft\dex2jar-2.0\Tom Run-dex2jar.jar!\com\nt\common\NTEventHandler.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */