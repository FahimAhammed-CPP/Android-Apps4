package org.cocos2dx.lib;

import android.content.Context;
import android.media.SoundPool;
import android.util.Log;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import java.util.concurrent.Semaphore;

public class Cocos2dxSound {
  private static final int INVALID_SOUND_ID = -1;
  
  private static final int INVALID_STREAM_ID = -1;
  
  private static final int MAX_SIMULTANEOUS_STREAMS_DEFAULT = 5;
  
  private static final int SOUND_PRIORITY = 1;
  
  private static final int SOUND_QUALITY = 5;
  
  private static final float SOUND_RATE = 1.0F;
  
  private static final String TAG = "Cocos2dxSound";
  
  private final Context mContext;
  
  private final ArrayList<SoundInfoForLoadedCompleted> mEffecToPlayWhenLoadedArray = new ArrayList<SoundInfoForLoadedCompleted>();
  
  private float mLeftVolume;
  
  private final HashMap<String, Integer> mPathSoundIDMap = new HashMap<String, Integer>();
  
  private final HashMap<String, ArrayList<Integer>> mPathStreamIDsMap = new HashMap<String, ArrayList<Integer>>();
  
  private float mRightVolume;
  
  private Semaphore mSemaphore;
  
  private SoundPool mSoundPool;
  
  private int mStreamIdSyn;
  
  public Cocos2dxSound(Context paramContext) {
    this.mContext = paramContext;
    initData();
  }
  
  private int doPlayEffect(String paramString, int paramInt, boolean paramBoolean) {
    boolean bool;
    SoundPool soundPool = this.mSoundPool;
    float f1 = this.mLeftVolume;
    float f2 = this.mRightVolume;
    if (paramBoolean) {
      bool = true;
    } else {
      bool = false;
    } 
    paramInt = soundPool.play(paramInt, f1, f2, 1, bool, 1.0F);
    ArrayList<Integer> arrayList2 = this.mPathStreamIDsMap.get(paramString);
    ArrayList<Integer> arrayList1 = arrayList2;
    if (arrayList2 == null) {
      arrayList1 = new ArrayList();
      this.mPathStreamIDsMap.put(paramString, arrayList1);
    } 
    arrayList1.add(Integer.valueOf(paramInt));
    return paramInt;
  }
  
  private void initData() {
    this.mSoundPool = new SoundPool(5, 3, 5);
    this.mSoundPool.setOnLoadCompleteListener(new OnLoadCompletedListener());
    this.mLeftVolume = 0.5F;
    this.mRightVolume = 0.5F;
    this.mSemaphore = new Semaphore(0, true);
  }
  
  public int createSoundIDFromAsset(String paramString) {
    byte b1;
    try {
      if (paramString.startsWith("/")) {
        b1 = this.mSoundPool.load(paramString, 0);
      } else {
        b1 = this.mSoundPool.load(this.mContext.getAssets().openFd(paramString), 0);
      } 
    } catch (Exception exception) {
      b1 = -1;
      Log.e("Cocos2dxSound", "error: " + exception.getMessage(), exception);
    } 
    byte b2 = b1;
    if (b1 == 0)
      b2 = -1; 
    return b2;
  }
  
  public void end() {
    this.mSoundPool.release();
    this.mPathStreamIDsMap.clear();
    this.mPathSoundIDMap.clear();
    this.mEffecToPlayWhenLoadedArray.clear();
    this.mLeftVolume = 0.5F;
    this.mRightVolume = 0.5F;
    initData();
  }
  
  public float getEffectsVolume() {
    return (this.mLeftVolume + this.mRightVolume) / 2.0F;
  }
  
  public void pauseAllEffects() {
    this.mSoundPool.autoPause();
  }
  
  public void pauseEffect(int paramInt) {
    this.mSoundPool.pause(paramInt);
  }
  
  public int playEffect(String paramString, boolean paramBoolean) {
    int i = -1;
    Integer integer1 = this.mPathSoundIDMap.get(paramString);
    if (integer1 != null)
      return doPlayEffect(paramString, integer1.intValue(), paramBoolean); 
    Integer integer2 = Integer.valueOf(preloadEffect(paramString));
    if (integer2.intValue() != -1)
      synchronized (this.mSoundPool) {
        this.mEffecToPlayWhenLoadedArray.add(new SoundInfoForLoadedCompleted(paramString, integer2.intValue(), paramBoolean));
        try {
          this.mSemaphore.acquire();
          i = this.mStreamIdSyn;
        } catch (Exception exception) {}
      }  
    return i;
  }
  
  public int preloadEffect(String paramString) {
    Integer integer2 = this.mPathSoundIDMap.get(paramString);
    Integer integer1 = integer2;
    if (integer2 == null) {
      integer2 = Integer.valueOf(createSoundIDFromAsset(paramString));
      integer1 = integer2;
      if (integer2.intValue() != -1) {
        this.mPathSoundIDMap.put(paramString, integer2);
        integer1 = integer2;
      } 
    } 
    return integer1.intValue();
  }
  
  public void resumeAllEffects() {
    if (!this.mPathStreamIDsMap.isEmpty()) {
      Iterator<Map.Entry> iterator = this.mPathStreamIDsMap.entrySet().iterator();
      while (true) {
        if (iterator.hasNext()) {
          Iterator<Integer> iterator1 = ((ArrayList)((Map.Entry)iterator.next()).getValue()).iterator();
          while (iterator1.hasNext()) {
            int i = ((Integer)iterator1.next()).intValue();
            this.mSoundPool.resume(i);
          } 
          continue;
        } 
        return;
      } 
    } 
  }
  
  public void resumeEffect(int paramInt) {
    this.mSoundPool.resume(paramInt);
  }
  
  public void setEffectsVolume(float paramFloat) {
    float f = paramFloat;
    if (paramFloat < 0.0F)
      f = 0.0F; 
    paramFloat = f;
    if (f > 1.0F)
      paramFloat = 1.0F; 
    this.mRightVolume = paramFloat;
    this.mLeftVolume = paramFloat;
    if (!this.mPathStreamIDsMap.isEmpty()) {
      Iterator<Map.Entry> iterator = this.mPathStreamIDsMap.entrySet().iterator();
      while (true) {
        if (iterator.hasNext()) {
          Iterator<Integer> iterator1 = ((ArrayList)((Map.Entry)iterator.next()).getValue()).iterator();
          while (iterator1.hasNext()) {
            int i = ((Integer)iterator1.next()).intValue();
            this.mSoundPool.setVolume(i, this.mLeftVolume, this.mRightVolume);
          } 
          continue;
        } 
        return;
      } 
    } 
  }
  
  public void stopAllEffects() {
    if (!this.mPathStreamIDsMap.isEmpty()) {
      Iterator<Map.Entry> iterator = this.mPathStreamIDsMap.entrySet().iterator();
      while (true) {
        if (iterator.hasNext()) {
          Iterator<Integer> iterator1 = ((ArrayList)((Map.Entry)iterator.next()).getValue()).iterator();
          while (iterator1.hasNext()) {
            int i = ((Integer)iterator1.next()).intValue();
            this.mSoundPool.stop(i);
          } 
          continue;
        } 
        this.mPathStreamIDsMap.clear();
        return;
      } 
    } 
    this.mPathStreamIDsMap.clear();
  }
  
  public void stopEffect(int paramInt) {
    this.mSoundPool.stop(paramInt);
    Iterator<String> iterator = this.mPathStreamIDsMap.keySet().iterator();
    while (true) {
      if (!iterator.hasNext())
        return; 
      String str = iterator.next();
      if (((ArrayList)this.mPathStreamIDsMap.get(str)).contains(Integer.valueOf(paramInt))) {
        ((ArrayList)this.mPathStreamIDsMap.get(str)).remove(((ArrayList)this.mPathStreamIDsMap.get(str)).indexOf(Integer.valueOf(paramInt)));
        return;
      } 
    } 
  }
  
  public void unloadEffect(String paramString) {
    // Byte code:
    //   0: aload_0
    //   1: getfield mPathStreamIDsMap : Ljava/util/HashMap;
    //   4: aload_1
    //   5: invokevirtual get : (Ljava/lang/Object;)Ljava/lang/Object;
    //   8: checkcast java/util/ArrayList
    //   11: astore_2
    //   12: aload_2
    //   13: ifnull -> 30
    //   16: aload_2
    //   17: invokevirtual iterator : ()Ljava/util/Iterator;
    //   20: astore_2
    //   21: aload_2
    //   22: invokeinterface hasNext : ()Z
    //   27: ifne -> 77
    //   30: aload_0
    //   31: getfield mPathStreamIDsMap : Ljava/util/HashMap;
    //   34: aload_1
    //   35: invokevirtual remove : (Ljava/lang/Object;)Ljava/lang/Object;
    //   38: pop
    //   39: aload_0
    //   40: getfield mPathSoundIDMap : Ljava/util/HashMap;
    //   43: aload_1
    //   44: invokevirtual get : (Ljava/lang/Object;)Ljava/lang/Object;
    //   47: checkcast java/lang/Integer
    //   50: astore_2
    //   51: aload_2
    //   52: ifnull -> 76
    //   55: aload_0
    //   56: getfield mSoundPool : Landroid/media/SoundPool;
    //   59: aload_2
    //   60: invokevirtual intValue : ()I
    //   63: invokevirtual unload : (I)Z
    //   66: pop
    //   67: aload_0
    //   68: getfield mPathSoundIDMap : Ljava/util/HashMap;
    //   71: aload_1
    //   72: invokevirtual remove : (Ljava/lang/Object;)Ljava/lang/Object;
    //   75: pop
    //   76: return
    //   77: aload_2
    //   78: invokeinterface next : ()Ljava/lang/Object;
    //   83: checkcast java/lang/Integer
    //   86: astore_3
    //   87: aload_0
    //   88: getfield mSoundPool : Landroid/media/SoundPool;
    //   91: aload_3
    //   92: invokevirtual intValue : ()I
    //   95: invokevirtual stop : (I)V
    //   98: goto -> 21
  }
  
  public class OnLoadCompletedListener implements SoundPool.OnLoadCompleteListener {
    public void onLoadComplete(SoundPool param1SoundPool, int param1Int1, int param1Int2) {
      if (param1Int2 == 0) {
        Iterator<Cocos2dxSound.SoundInfoForLoadedCompleted> iterator = Cocos2dxSound.this.mEffecToPlayWhenLoadedArray.iterator();
        while (true) {
          if (iterator.hasNext()) {
            Cocos2dxSound.SoundInfoForLoadedCompleted soundInfoForLoadedCompleted = iterator.next();
            if (param1Int1 == soundInfoForLoadedCompleted.soundID) {
              Cocos2dxSound.this.mStreamIdSyn = Cocos2dxSound.this.doPlayEffect(soundInfoForLoadedCompleted.path, soundInfoForLoadedCompleted.soundID, soundInfoForLoadedCompleted.isLoop);
              Cocos2dxSound.this.mEffecToPlayWhenLoadedArray.remove(soundInfoForLoadedCompleted);
            } else {
              continue;
            } 
          } 
          Cocos2dxSound.this.mSemaphore.release();
          return;
        } 
      } 
      Cocos2dxSound.this.mStreamIdSyn = -1;
      Cocos2dxSound.this.mSemaphore.release();
    }
  }
  
  public class SoundInfoForLoadedCompleted {
    public boolean isLoop;
    
    public String path;
    
    public int soundID;
    
    public SoundInfoForLoadedCompleted(String param1String, int param1Int, boolean param1Boolean) {
      this.path = param1String;
      this.soundID = param1Int;
      this.isLoop = param1Boolean;
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Tom Run-dex2jar.jar!\org\cocos2dx\lib\Cocos2dxSound.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */