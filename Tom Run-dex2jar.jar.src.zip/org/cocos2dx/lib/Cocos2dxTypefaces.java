package org.cocos2dx.lib;

import android.content.Context;
import android.graphics.Typeface;
import java.util.HashMap;

public class Cocos2dxTypefaces {
  private static final HashMap<String, Typeface> sTypefaceCache = new HashMap<String, Typeface>();
  
  public static Typeface get(Context paramContext, String paramString) {
    // Byte code:
    //   0: ldc org/cocos2dx/lib/Cocos2dxTypefaces
    //   2: monitorenter
    //   3: getstatic org/cocos2dx/lib/Cocos2dxTypefaces.sTypefaceCache : Ljava/util/HashMap;
    //   6: aload_1
    //   7: invokevirtual containsKey : (Ljava/lang/Object;)Z
    //   10: ifne -> 36
    //   13: aload_1
    //   14: ldc '/'
    //   16: invokevirtual startsWith : (Ljava/lang/String;)Z
    //   19: ifeq -> 52
    //   22: aload_1
    //   23: invokestatic createFromFile : (Ljava/lang/String;)Landroid/graphics/Typeface;
    //   26: astore_0
    //   27: getstatic org/cocos2dx/lib/Cocos2dxTypefaces.sTypefaceCache : Ljava/util/HashMap;
    //   30: aload_1
    //   31: aload_0
    //   32: invokevirtual put : (Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    //   35: pop
    //   36: getstatic org/cocos2dx/lib/Cocos2dxTypefaces.sTypefaceCache : Ljava/util/HashMap;
    //   39: aload_1
    //   40: invokevirtual get : (Ljava/lang/Object;)Ljava/lang/Object;
    //   43: checkcast android/graphics/Typeface
    //   46: astore_0
    //   47: ldc org/cocos2dx/lib/Cocos2dxTypefaces
    //   49: monitorexit
    //   50: aload_0
    //   51: areturn
    //   52: aload_0
    //   53: invokevirtual getAssets : ()Landroid/content/res/AssetManager;
    //   56: aload_1
    //   57: invokestatic createFromAsset : (Landroid/content/res/AssetManager;Ljava/lang/String;)Landroid/graphics/Typeface;
    //   60: astore_0
    //   61: goto -> 27
    //   64: astore_0
    //   65: ldc org/cocos2dx/lib/Cocos2dxTypefaces
    //   67: monitorexit
    //   68: aload_0
    //   69: athrow
    // Exception table:
    //   from	to	target	type
    //   3	27	64	finally
    //   27	36	64	finally
    //   36	47	64	finally
    //   52	61	64	finally
  }
}


/* Location:              C:\soft\dex2jar-2.0\Tom Run-dex2jar.jar!\org\cocos2dx\lib\Cocos2dxTypefaces.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */