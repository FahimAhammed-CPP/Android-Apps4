package org.cocos2dx.lib;

import android.content.Context;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.util.Log;

public class Cocos2dxLocalStorage {
  private static String DATABASE_NAME = "jsb.sqlite";
  
  private static final int DATABASE_VERSION = 1;
  
  private static String TABLE_NAME = "data";
  
  private static final String TAG = "Cocos2dxLocalStorage";
  
  private static SQLiteDatabase mDatabase;
  
  private static DBOpenHelper mDatabaseOpenHelper = null;
  
  static {
    mDatabase = null;
  }
  
  public static void destory() {
    if (mDatabase != null)
      mDatabase.close(); 
  }
  
  public static String getItem(String paramString) {
    // Byte code:
    //   0: aconst_null
    //   1: astore_3
    //   2: aconst_null
    //   3: astore_2
    //   4: aload_3
    //   5: astore_1
    //   6: new java/lang/StringBuilder
    //   9: dup
    //   10: ldc 'select value from '
    //   12: invokespecial <init> : (Ljava/lang/String;)V
    //   15: getstatic org/cocos2dx/lib/Cocos2dxLocalStorage.TABLE_NAME : Ljava/lang/String;
    //   18: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   21: ldc ' where key=?'
    //   23: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   26: invokevirtual toString : ()Ljava/lang/String;
    //   29: astore #4
    //   31: aload_3
    //   32: astore_1
    //   33: getstatic org/cocos2dx/lib/Cocos2dxLocalStorage.mDatabase : Landroid/database/sqlite/SQLiteDatabase;
    //   36: aload #4
    //   38: iconst_1
    //   39: anewarray java/lang/String
    //   42: dup
    //   43: iconst_0
    //   44: aload_0
    //   45: aastore
    //   46: invokevirtual rawQuery : (Ljava/lang/String;[Ljava/lang/String;)Landroid/database/Cursor;
    //   49: astore_3
    //   50: aload_2
    //   51: astore_0
    //   52: aload_0
    //   53: astore_1
    //   54: aload_3
    //   55: invokeinterface moveToNext : ()Z
    //   60: ifne -> 82
    //   63: aload_0
    //   64: astore_1
    //   65: aload_3
    //   66: invokeinterface close : ()V
    //   71: aload_0
    //   72: astore_1
    //   73: aload_0
    //   74: ifnonnull -> 80
    //   77: ldc ''
    //   79: astore_1
    //   80: aload_1
    //   81: areturn
    //   82: aload_0
    //   83: ifnull -> 109
    //   86: aload_0
    //   87: astore_1
    //   88: ldc 'Cocos2dxLocalStorage'
    //   90: ldc 'The key contains more than one value.'
    //   92: invokestatic e : (Ljava/lang/String;Ljava/lang/String;)I
    //   95: pop
    //   96: goto -> 63
    //   99: astore_0
    //   100: aload_0
    //   101: invokevirtual printStackTrace : ()V
    //   104: aload_1
    //   105: astore_0
    //   106: goto -> 71
    //   109: aload_0
    //   110: astore_1
    //   111: aload_3
    //   112: aload_3
    //   113: ldc 'value'
    //   115: invokeinterface getColumnIndex : (Ljava/lang/String;)I
    //   120: invokeinterface getString : (I)Ljava/lang/String;
    //   125: astore_0
    //   126: goto -> 52
    // Exception table:
    //   from	to	target	type
    //   6	31	99	java/lang/Exception
    //   33	50	99	java/lang/Exception
    //   54	63	99	java/lang/Exception
    //   65	71	99	java/lang/Exception
    //   88	96	99	java/lang/Exception
    //   111	126	99	java/lang/Exception
  }
  
  public static boolean init(String paramString1, String paramString2) {
    if (Cocos2dxActivity.getContext() != null) {
      DATABASE_NAME = paramString1;
      TABLE_NAME = paramString2;
      mDatabaseOpenHelper = new DBOpenHelper(Cocos2dxActivity.getContext());
      mDatabase = mDatabaseOpenHelper.getWritableDatabase();
      return true;
    } 
    return false;
  }
  
  public static void removeItem(String paramString) {
    try {
      String str = "delete from " + TABLE_NAME + " where key=?";
      mDatabase.execSQL(str, new Object[] { paramString });
      return;
    } catch (Exception exception) {
      exception.printStackTrace();
      return;
    } 
  }
  
  public static void setItem(String paramString1, String paramString2) {
    try {
      String str = "replace into " + TABLE_NAME + "(key,value)values(?,?)";
      mDatabase.execSQL(str, new Object[] { paramString1, paramString2 });
      return;
    } catch (Exception exception) {
      exception.printStackTrace();
      return;
    } 
  }
  
  private static class DBOpenHelper extends SQLiteOpenHelper {
    DBOpenHelper(Context param1Context) {
      super(param1Context, Cocos2dxLocalStorage.DATABASE_NAME, null, 1);
    }
    
    public void onCreate(SQLiteDatabase param1SQLiteDatabase) {
      param1SQLiteDatabase.execSQL("CREATE TABLE IF NOT EXISTS " + Cocos2dxLocalStorage.TABLE_NAME + "(key TEXT PRIMARY KEY,value TEXT);");
    }
    
    public void onUpgrade(SQLiteDatabase param1SQLiteDatabase, int param1Int1, int param1Int2) {
      Log.w("Cocos2dxLocalStorage", "Upgrading database from version " + param1Int1 + " to " + param1Int2 + ", which will destroy all old data");
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Tom Run-dex2jar.jar!\org\cocos2dx\lib\Cocos2dxLocalStorage.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */