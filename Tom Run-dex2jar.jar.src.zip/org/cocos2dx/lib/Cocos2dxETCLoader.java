package org.cocos2dx.lib;

import android.content.Context;
import android.opengl.ETC1Util;
import android.util.Log;
import java.io.FileInputStream;
import java.io.InputStream;
import java.nio.ByteBuffer;
import java.nio.ByteOrder;

public class Cocos2dxETCLoader {
  private static final String ASSETS_PATH = "assets/";
  
  private static Context context;
  
  public static boolean loadTexture(String paramString) {
    if (ETC1Util.isETC1Supported() && paramString.length() != 0) {
      ByteBuffer byteBuffer;
      String str = paramString;
      try {
        InputStream inputStream;
        if (paramString.charAt(0) == '/') {
          str = paramString;
          inputStream = new FileInputStream(paramString);
        } else {
          String str1 = paramString;
          str = paramString;
          if (paramString.startsWith("assets/")) {
            str = paramString;
            str1 = paramString.substring("assets/".length());
          } 
          str = str1;
          inputStream = context.getAssets().open(str1);
          paramString = str1;
        } 
        str = paramString;
        ETC1Util.ETC1Texture eTC1Texture2 = ETC1Util.createTexture(inputStream);
        str = paramString;
        inputStream.close();
        ETC1Util.ETC1Texture eTC1Texture1 = eTC1Texture2;
        if (eTC1Texture1 != null)
          try {
            int i = eTC1Texture1.getWidth();
            int j = eTC1Texture1.getHeight();
            int k = eTC1Texture1.getData().remaining();
            byte[] arrayOfByte = new byte[k];
            byteBuffer = ByteBuffer.wrap(arrayOfByte);
            byteBuffer.order(ByteOrder.nativeOrder());
            byteBuffer.put(eTC1Texture1.getData());
            nativeSetTextureInfo(i, j, arrayOfByte, k);
            return true;
          } catch (Exception exception) {
            Log.d("invoke native function error", exception.toString());
            return false;
          }  
      } catch (Exception exception) {
        Log.d("Cocos2dx", "Unable to create texture for " + byteBuffer);
        exception = null;
      } 
    } 
    return false;
  }
  
  private static native void nativeSetTextureInfo(int paramInt1, int paramInt2, byte[] paramArrayOfbyte, int paramInt3);
  
  public static void setContext(Context paramContext) {
    context = paramContext;
  }
}


/* Location:              C:\soft\dex2jar-2.0\Tom Run-dex2jar.jar!\org\cocos2dx\lib\Cocos2dxETCLoader.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */