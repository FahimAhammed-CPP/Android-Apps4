package org.cocos2dx.lib;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.Rect;
import android.graphics.Typeface;
import android.text.TextPaint;
import android.text.TextUtils;
import android.util.FloatMath;
import android.util.Log;
import java.nio.ByteBuffer;
import java.nio.ByteOrder;
import java.util.LinkedList;

public class Cocos2dxBitmap {
  private static final int HORIZONTALALIGN_CENTER = 3;
  
  private static final int HORIZONTALALIGN_LEFT = 1;
  
  private static final int HORIZONTALALIGN_RIGHT = 2;
  
  private static final int VERTICALALIGN_BOTTOM = 2;
  
  private static final int VERTICALALIGN_CENTER = 3;
  
  private static final int VERTICALALIGN_TOP = 1;
  
  private static Context sContext;
  
  private static TextProperty computeTextProperty(String paramString, int paramInt1, int paramInt2, Paint paramPaint) {
    Paint.FontMetricsInt fontMetricsInt = paramPaint.getFontMetricsInt();
    int j = (int)Math.ceil((fontMetricsInt.bottom - fontMetricsInt.top));
    int i = 0;
    String[] arrayOfString = splitString(paramString, paramInt1, paramInt2, paramPaint);
    if (paramInt1 != 0) {
      i = paramInt1;
      return new TextProperty(i, j, arrayOfString);
    } 
    int k = arrayOfString.length;
    paramInt2 = 0;
    paramInt1 = i;
    while (true) {
      i = paramInt1;
      if (paramInt2 < k) {
        String str = arrayOfString[paramInt2];
        int m = (int)FloatMath.ceil(paramPaint.measureText(str, 0, str.length()));
        i = paramInt1;
        if (m > paramInt1)
          i = m; 
        paramInt2++;
        paramInt1 = i;
        continue;
      } 
      return new TextProperty(i, j, arrayOfString);
    } 
  }
  
  private static int computeX(String paramString, int paramInt1, int paramInt2) {
    switch (paramInt2) {
      default:
        return 0;
      case 3:
        return paramInt1 / 2;
      case 2:
        break;
    } 
    return paramInt1;
  }
  
  private static int computeY(Paint.FontMetricsInt paramFontMetricsInt, int paramInt1, int paramInt2, int paramInt3) {
    int i = -paramFontMetricsInt.top;
    if (paramInt1 > paramInt2) {
      switch (paramInt3) {
        default:
          return i;
        case 1:
          return -paramFontMetricsInt.top;
        case 3:
          return -paramFontMetricsInt.top + (paramInt1 - paramInt2) / 2;
        case 2:
          break;
      } 
      return -paramFontMetricsInt.top + paramInt1 - paramInt2;
    } 
  }
  
  public static void createTextBitmap(String paramString1, String paramString2, int paramInt1, int paramInt2, int paramInt3, int paramInt4) {
    createTextBitmapShadowStroke(paramString1, paramString2, paramInt1, 1.0F, 1.0F, 1.0F, paramInt2, paramInt3, paramInt4, false, 0.0F, 0.0F, 0.0F, false, 1.0F, 1.0F, 1.0F, 1.0F);
  }
  
  public static void createTextBitmapShadowStroke(String paramString1, String paramString2, int paramInt1, float paramFloat1, float paramFloat2, float paramFloat3, int paramInt2, int paramInt3, int paramInt4, boolean paramBoolean1, float paramFloat4, float paramFloat5, float paramFloat6, boolean paramBoolean2, float paramFloat7, float paramFloat8, float paramFloat9, float paramFloat10) {
    int i = paramInt2 & 0xF;
    int j = paramInt2 >> 4 & 0xF;
    paramString1 = refactorString(paramString1);
    Paint paint = newPaint(paramString2, paramInt1, i);
    paint.setARGB(255, (int)(255.0D * paramFloat1), (int)(255.0D * paramFloat2), (int)(255.0D * paramFloat3));
    TextProperty textProperty = computeTextProperty(paramString1, paramInt3, paramInt4, paint);
    if (paramInt4 == 0) {
      paramInt2 = textProperty.mTotalHeight;
    } else {
      paramInt2 = paramInt4;
    } 
    paramFloat2 = 0.0F;
    float f1 = 0.0F;
    float f2 = 0.0F;
    paramFloat1 = 0.0F;
    float f4 = 0.0F;
    float f3 = f4;
    if (paramBoolean1) {
      paint.setShadowLayer(paramFloat6, paramFloat4, paramFloat5, -8553091);
      paramFloat3 = Math.abs(paramFloat4);
      paramFloat6 = Math.abs(paramFloat5);
      if (paramFloat4 < 0.0D)
        paramFloat1 = paramFloat3; 
      paramFloat2 = paramFloat3;
      f1 = paramFloat6;
      f2 = paramFloat1;
      f3 = f4;
      if (paramFloat5 < 0.0D) {
        f3 = paramFloat6;
        f2 = paramFloat1;
        f1 = paramFloat6;
        paramFloat2 = paramFloat3;
      } 
    } 
    Bitmap bitmap = Bitmap.createBitmap(textProperty.mMaxWidth + (int)paramFloat2, (int)f1 + paramInt2, Bitmap.Config.ARGB_8888);
    Canvas canvas = new Canvas(bitmap);
    Paint.FontMetricsInt fontMetricsInt = paint.getFontMetricsInt();
    paramInt3 = computeY(fontMetricsInt, paramInt4, textProperty.mTotalHeight, j);
    String[] arrayOfString = textProperty.mLines;
    int k = arrayOfString.length;
    for (paramInt2 = 0;; paramInt2++) {
      String[] arrayOfString1;
      if (paramInt2 >= k) {
        if (paramBoolean2) {
          Paint paint1 = newPaint(paramString2, paramInt1, i);
          paint1.setStyle(Paint.Style.STROKE);
          paint1.setStrokeWidth(0.5F * paramFloat10);
          paint1.setARGB(255, (int)paramFloat7 * 255, (int)paramFloat8 * 255, (int)paramFloat9 * 255);
          paramInt2 = computeY(fontMetricsInt, paramInt4, textProperty.mTotalHeight, j);
          arrayOfString1 = textProperty.mLines;
          paramInt3 = arrayOfString1.length;
          for (paramInt1 = 0;; paramInt1++) {
            if (paramInt1 >= paramInt3) {
              initNativeObject(bitmap);
              return;
            } 
            String str1 = arrayOfString1[paramInt1];
            canvas.drawText(str1, computeX(str1, textProperty.mMaxWidth, i) + f2, paramInt2 + f3, paint1);
            paramInt2 += textProperty.mHeightPerLine;
          } 
          break;
        } 
        continue;
      } 
      String str = arrayOfString[paramInt2];
      canvas.drawText(str, computeX(str, textProperty.mMaxWidth, i) + f2, paramInt3 + f3, (Paint)arrayOfString1);
      paramInt3 += textProperty.mHeightPerLine;
    } 
  }
  
  private static LinkedList<String> divideStringWithMaxWidth(String paramString, int paramInt, Paint paramPaint) {
    int k = paramString.length();
    int j = 0;
    LinkedList<String> linkedList = new LinkedList();
    int i = 1;
    label26: while (true) {
      if (i > k) {
        if (j < k)
          linkedList.add(paramString.substring(j)); 
        return linkedList;
      } 
      int i1 = (int)FloatMath.ceil(paramPaint.measureText(paramString, j, i));
      int n = i;
      int m = j;
      if (i1 >= paramInt) {
        m = paramString.substring(0, i).lastIndexOf(" ");
        if (m != -1 && m > j) {
          linkedList.add(paramString.substring(j, m));
          i = m + 1;
        } else if (i1 > paramInt) {
          linkedList.add(paramString.substring(j, i - 1));
          i--;
        } else {
          linkedList.add(paramString.substring(j, i));
        } 
        while (true) {
          if (i >= k || paramString.charAt(i) != ' ') {
            m = i;
            n = i;
            i = n + 1;
            j = m;
            continue label26;
          } 
          i++;
        } 
        break;
      } 
      continue;
    } 
  }
  
  private static int getFontSizeAccordingHeight(int paramInt) {
    Paint paint = new Paint();
    Rect rect = new Rect();
    paint.setTypeface(Typeface.DEFAULT);
    int i = 1;
    boolean bool = false;
    while (true) {
      if (bool)
        return i; 
      paint.setTextSize(i);
      paint.getTextBounds("SghMNy", 0, "SghMNy".length(), rect);
      i++;
      if (paramInt - rect.height() <= 2)
        bool = true; 
      Log.d("font size", "incr size:" + i);
    } 
  }
  
  private static byte[] getPixels(Bitmap paramBitmap) {
    if (paramBitmap != null) {
      byte[] arrayOfByte = new byte[paramBitmap.getWidth() * paramBitmap.getHeight() * 4];
      ByteBuffer byteBuffer = ByteBuffer.wrap(arrayOfByte);
      byteBuffer.order(ByteOrder.nativeOrder());
      paramBitmap.copyPixelsToBuffer(byteBuffer);
      return arrayOfByte;
    } 
    return null;
  }
  
  private static String getStringWithEllipsis(String paramString, float paramFloat1, float paramFloat2) {
    if (TextUtils.isEmpty(paramString))
      return ""; 
    TextPaint textPaint = new TextPaint();
    textPaint.setTypeface(Typeface.DEFAULT);
    textPaint.setTextSize(paramFloat2);
    return TextUtils.ellipsize(paramString, textPaint, paramFloat1, TextUtils.TruncateAt.END).toString();
  }
  
  private static void initNativeObject(Bitmap paramBitmap) {
    byte[] arrayOfByte = getPixels(paramBitmap);
    if (arrayOfByte == null)
      return; 
    nativeInitBitmapDC(paramBitmap.getWidth(), paramBitmap.getHeight(), arrayOfByte);
  }
  
  private static native void nativeInitBitmapDC(int paramInt1, int paramInt2, byte[] paramArrayOfbyte);
  
  private static Paint newPaint(String paramString, int paramInt1, int paramInt2) {
    Paint paint = new Paint();
    paint.setColor(-1);
    paint.setTextSize(paramInt1);
    paint.setAntiAlias(true);
    if (paramString.endsWith(".ttf")) {
      try {
        paint.setTypeface(Cocos2dxTypefaces.get(sContext, paramString));
        switch (paramInt2) {
          default:
            paint.setTextAlign(Paint.Align.LEFT);
            return paint;
          case 3:
            paint.setTextAlign(Paint.Align.CENTER);
            return paint;
          case 2:
            break;
        } 
      } catch (Exception exception) {
        Log.e("Cocos2dxBitmap", "error to create ttf type face: " + paramString);
        paint.setTypeface(Typeface.create(paramString, 0));
        switch (paramInt2) {
          default:
            paint.setTextAlign(Paint.Align.LEFT);
            return paint;
          case 3:
            paint.setTextAlign(Paint.Align.CENTER);
            return paint;
          case 2:
            break;
        } 
      } 
    } else {
      paint.setTypeface(Typeface.create(paramString, 0));
      switch (paramInt2) {
        default:
          paint.setTextAlign(Paint.Align.LEFT);
          return paint;
        case 3:
          paint.setTextAlign(Paint.Align.CENTER);
          return paint;
        case 2:
          break;
      } 
    } 
    paint.setTextAlign(Paint.Align.RIGHT);
    return paint;
  }
  
  private static String refactorString(String paramString) {
    if (paramString.compareTo("") == 0)
      return " "; 
    StringBuilder stringBuilder = new StringBuilder(paramString);
    int i = 0;
    int j = stringBuilder.indexOf("\n");
    while (true) {
      if (j != -1) {
        if (j == 0 || stringBuilder.charAt(j - 1) == '\n') {
          stringBuilder.insert(i, " ");
          i = j + 2;
        } else {
          i = j + 1;
        } 
        if (i <= stringBuilder.length() && j != stringBuilder.length()) {
          j = stringBuilder.indexOf("\n", i);
          continue;
        } 
      } 
      return stringBuilder.toString();
    } 
  }
  
  public static void setContext(Context paramContext) {
    sContext = paramContext;
  }
  
  private static String[] splitString(String paramString, int paramInt1, int paramInt2, Paint paramPaint) {
    String[] arrayOfString = paramString.split("\\n");
    Paint.FontMetricsInt fontMetricsInt = paramPaint.getFontMetricsInt();
    int i = paramInt2 / (int)Math.ceil((fontMetricsInt.bottom - fontMetricsInt.top));
    if (paramInt1 != 0) {
      LinkedList<String> linkedList = new LinkedList();
      int j = arrayOfString.length;
      paramInt2 = 0;
      while (true) {
        if (paramInt2 < j) {
          String str = arrayOfString[paramInt2];
          if ((int)FloatMath.ceil(paramPaint.measureText(str)) > paramInt1) {
            linkedList.addAll(divideStringWithMaxWidth(str, paramInt1, paramPaint));
          } else {
            linkedList.add(str);
          } 
          if (i <= 0 || linkedList.size() < i) {
            paramInt2++;
            continue;
          } 
        } 
        if (i > 0) {
          if (linkedList.size() > i) {
            while (true) {
              if (linkedList.size() <= i) {
                arrayOfString = new String[linkedList.size()];
                linkedList.toArray(arrayOfString);
                return arrayOfString;
              } 
              linkedList.removeLast();
            } 
            break;
          } 
          continue;
        } 
        continue;
      } 
    } 
    if (paramInt2 != 0 && arrayOfString.length > i) {
      LinkedList<String> linkedList = new LinkedList();
      for (paramInt1 = 0;; paramInt1++) {
        if (paramInt1 >= i) {
          arrayOfString = new String[linkedList.size()];
          linkedList.toArray((Object[])arrayOfString);
          return arrayOfString;
        } 
        linkedList.add(arrayOfString[paramInt1]);
      } 
    } 
    return arrayOfString;
  }
  
  private static class TextProperty {
    private final int mHeightPerLine;
    
    private final String[] mLines;
    
    private final int mMaxWidth;
    
    private final int mTotalHeight;
    
    TextProperty(int param1Int1, int param1Int2, String[] param1ArrayOfString) {
      this.mMaxWidth = param1Int1;
      this.mHeightPerLine = param1Int2;
      this.mTotalHeight = param1ArrayOfString.length * param1Int2;
      this.mLines = param1ArrayOfString;
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Tom Run-dex2jar.jar!\org\cocos2dx\lib\Cocos2dxBitmap.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */