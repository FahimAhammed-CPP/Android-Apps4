package org.cocos2dx.lib;

import android.app.Activity;
import android.content.Context;
import android.os.Build;
import android.os.Bundle;
import android.os.Message;
import android.util.Log;
import android.view.View;
import android.view.ViewGroup;
import android.widget.FrameLayout;

public abstract class Cocos2dxActivity extends Activity implements Cocos2dxHelper.Cocos2dxHelperListener {
  private static final String TAG = Cocos2dxActivity.class.getSimpleName();
  
  private static Context sContext = null;
  
  private Cocos2dxGLSurfaceView mGLSurfaceView;
  
  private Cocos2dxHandler mHandler;
  
  public static Context getContext() {
    return sContext;
  }
  
  private static final boolean isAndroidEmulator() {
    String str = Build.MODEL;
    Log.d(TAG, "model=" + str);
    str = Build.PRODUCT;
    Log.d(TAG, "product=" + str);
    boolean bool = false;
    if (str != null) {
      if (!str.equals("sdk") && !str.contains("_sdk") && !str.contains("sdk_")) {
        bool = false;
        Log.d(TAG, "isEmulator=" + bool);
        return bool;
      } 
    } else {
      Log.d(TAG, "isEmulator=" + bool);
      return bool;
    } 
    bool = true;
    Log.d(TAG, "isEmulator=" + bool);
    return bool;
  }
  
  public void init() {
    ViewGroup.LayoutParams layoutParams = new ViewGroup.LayoutParams(-1, -1);
    FrameLayout frameLayout = new FrameLayout((Context)this);
    frameLayout.setLayoutParams(layoutParams);
    layoutParams = new ViewGroup.LayoutParams(-1, -2);
    Cocos2dxEditText cocos2dxEditText = new Cocos2dxEditText((Context)this);
    cocos2dxEditText.setLayoutParams(layoutParams);
    frameLayout.addView((View)cocos2dxEditText);
    this.mGLSurfaceView = onCreateView();
    frameLayout.addView((View)this.mGLSurfaceView);
    if (isAndroidEmulator())
      this.mGLSurfaceView.setEGLConfigChooser(8, 8, 8, 8, 16, 0); 
    this.mGLSurfaceView.setCocos2dxRenderer(new Cocos2dxRenderer());
    this.mGLSurfaceView.setCocos2dxEditText(cocos2dxEditText);
    setContentView((View)frameLayout);
  }
  
  protected void onCreate(Bundle paramBundle) {
    super.onCreate(paramBundle);
    sContext = (Context)this;
    this.mHandler = new Cocos2dxHandler(this);
    init();
    Cocos2dxHelper.init((Context)this, this);
  }
  
  public Cocos2dxGLSurfaceView onCreateView() {
    return new Cocos2dxGLSurfaceView((Context)this);
  }
  
  protected void onPause() {
    super.onPause();
    Cocos2dxHelper.onPause();
    this.mGLSurfaceView.onPause();
  }
  
  protected void onResume() {
    super.onResume();
    Cocos2dxHelper.onResume();
    this.mGLSurfaceView.onResume();
  }
  
  public void runOnGLThread(Runnable paramRunnable) {
    this.mGLSurfaceView.queueEvent(paramRunnable);
  }
  
  public void showDialog(String paramString1, String paramString2) {
    Message message = new Message();
    message.what = 1;
    message.obj = new Cocos2dxHandler.DialogMessage(paramString1, paramString2);
    this.mHandler.sendMessage(message);
  }
  
  public void showEditTextDialog(String paramString1, String paramString2, int paramInt1, int paramInt2, int paramInt3, int paramInt4) {
    Message message = new Message();
    message.what = 2;
    message.obj = new Cocos2dxHandler.EditBoxMessage(paramString1, paramString2, paramInt1, paramInt2, paramInt3, paramInt4);
    this.mHandler.sendMessage(message);
  }
}


/* Location:              C:\soft\dex2jar-2.0\Tom Run-dex2jar.jar!\org\cocos2dx\lib\Cocos2dxActivity.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */