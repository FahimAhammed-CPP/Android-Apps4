package org.cocos2dx.lib;

import android.content.Context;
import android.content.res.AssetFileDescriptor;
import android.media.MediaPlayer;
import android.util.Log;
import java.io.FileInputStream;

public class Cocos2dxMusic {
  private static final String TAG = Cocos2dxMusic.class.getSimpleName();
  
  private MediaPlayer mBackgroundMediaPlayer;
  
  private final Context mContext;
  
  private String mCurrentPath;
  
  private float mLeftVolume;
  
  private boolean mPaused;
  
  private float mRightVolume;
  
  public Cocos2dxMusic(Context paramContext) {
    this.mContext = paramContext;
    initData();
  }
  
  private MediaPlayer createMediaplayer(String paramString) {
    MediaPlayer mediaPlayer = new MediaPlayer();
    try {
      FileInputStream fileInputStream;
      if (paramString.startsWith("/")) {
        fileInputStream = new FileInputStream(paramString);
        mediaPlayer.setDataSource(fileInputStream.getFD());
        fileInputStream.close();
        mediaPlayer.prepare();
        mediaPlayer.setVolume(this.mLeftVolume, this.mRightVolume);
        return mediaPlayer;
      } 
      AssetFileDescriptor assetFileDescriptor = this.mContext.getAssets().openFd((String)fileInputStream);
      mediaPlayer.setDataSource(assetFileDescriptor.getFileDescriptor(), assetFileDescriptor.getStartOffset(), assetFileDescriptor.getLength());
      mediaPlayer.prepare();
      mediaPlayer.setVolume(this.mLeftVolume, this.mRightVolume);
      return mediaPlayer;
    } catch (Exception exception) {
      Log.e(TAG, "error: " + exception.getMessage(), exception);
      return null;
    } 
  }
  
  private void initData() {
    this.mLeftVolume = 0.5F;
    this.mRightVolume = 0.5F;
    this.mBackgroundMediaPlayer = null;
    this.mPaused = false;
    this.mCurrentPath = null;
  }
  
  public void end() {
    if (this.mBackgroundMediaPlayer != null)
      this.mBackgroundMediaPlayer.release(); 
    initData();
  }
  
  public float getBackgroundVolume() {
    return (this.mBackgroundMediaPlayer != null) ? ((this.mLeftVolume + this.mRightVolume) / 2.0F) : 0.0F;
  }
  
  public boolean isBackgroundMusicPlaying() {
    return (this.mBackgroundMediaPlayer == null) ? false : this.mBackgroundMediaPlayer.isPlaying();
  }
  
  public void pauseBackgroundMusic() {
    if (this.mBackgroundMediaPlayer != null && this.mBackgroundMediaPlayer.isPlaying()) {
      this.mBackgroundMediaPlayer.pause();
      this.mPaused = true;
    } 
  }
  
  public void playBackgroundMusic(String paramString, boolean paramBoolean) {
    if (this.mCurrentPath == null) {
      this.mBackgroundMediaPlayer = createMediaplayer(paramString);
      this.mCurrentPath = paramString;
    } else if (!this.mCurrentPath.equals(paramString)) {
      if (this.mBackgroundMediaPlayer != null)
        this.mBackgroundMediaPlayer.release(); 
      this.mBackgroundMediaPlayer = createMediaplayer(paramString);
      this.mCurrentPath = paramString;
    } 
    if (this.mBackgroundMediaPlayer == null) {
      Log.e(TAG, "playBackgroundMusic: background media player is null");
      return;
    } 
    this.mBackgroundMediaPlayer.stop();
    this.mBackgroundMediaPlayer.setLooping(paramBoolean);
    try {
      this.mBackgroundMediaPlayer.prepare();
      this.mBackgroundMediaPlayer.seekTo(0);
      this.mBackgroundMediaPlayer.start();
      this.mPaused = false;
      return;
    } catch (Exception exception) {
      Log.e(TAG, "playBackgroundMusic: error state");
      return;
    } 
  }
  
  public void preloadBackgroundMusic(String paramString) {
    if (this.mCurrentPath == null || !this.mCurrentPath.equals(paramString)) {
      if (this.mBackgroundMediaPlayer != null)
        this.mBackgroundMediaPlayer.release(); 
      this.mBackgroundMediaPlayer = createMediaplayer(paramString);
      this.mCurrentPath = paramString;
    } 
  }
  
  public void resumeBackgroundMusic() {
    if (this.mBackgroundMediaPlayer != null && this.mPaused) {
      this.mBackgroundMediaPlayer.start();
      this.mPaused = false;
    } 
  }
  
  public void rewindBackgroundMusic() {
    if (this.mBackgroundMediaPlayer != null) {
      this.mBackgroundMediaPlayer.stop();
      try {
        this.mBackgroundMediaPlayer.prepare();
        this.mBackgroundMediaPlayer.seekTo(0);
        this.mBackgroundMediaPlayer.start();
        this.mPaused = false;
        return;
      } catch (Exception exception) {
        Log.e(TAG, "rewindBackgroundMusic: error state");
        return;
      } 
    } 
  }
  
  public void setBackgroundVolume(float paramFloat) {
    float f = paramFloat;
    if (paramFloat < 0.0F)
      f = 0.0F; 
    paramFloat = f;
    if (f > 1.0F)
      paramFloat = 1.0F; 
    this.mRightVolume = paramFloat;
    this.mLeftVolume = paramFloat;
    if (this.mBackgroundMediaPlayer != null)
      this.mBackgroundMediaPlayer.setVolume(this.mLeftVolume, this.mRightVolume); 
  }
  
  public void stopBackgroundMusic() {
    if (this.mBackgroundMediaPlayer != null) {
      this.mBackgroundMediaPlayer.stop();
      this.mPaused = false;
    } 
  }
}


/* Location:              C:\soft\dex2jar-2.0\Tom Run-dex2jar.jar!\org\cocos2dx\lib\Cocos2dxMusic.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */