package org.cocos2dx.lib;

import android.content.Context;
import android.opengl.GLSurfaceView;
import android.os.Handler;
import android.os.Message;
import android.util.AttributeSet;
import android.util.Log;
import android.view.KeyEvent;
import android.view.MotionEvent;
import android.view.View;
import android.view.inputmethod.InputMethodManager;

public class Cocos2dxGLSurfaceView extends GLSurfaceView {
  private static final int HANDLER_CLOSE_IME_KEYBOARD = 3;
  
  private static final int HANDLER_OPEN_IME_KEYBOARD = 2;
  
  private static final String TAG = Cocos2dxGLSurfaceView.class.getSimpleName();
  
  private static Cocos2dxGLSurfaceView mCocos2dxGLSurfaceView;
  
  private static Cocos2dxTextInputWraper sCocos2dxTextInputWraper;
  
  private static Handler sHandler;
  
  private Cocos2dxEditText mCocos2dxEditText;
  
  private Cocos2dxRenderer mCocos2dxRenderer;
  
  public Cocos2dxGLSurfaceView(Context paramContext) {
    super(paramContext);
    initView();
  }
  
  public Cocos2dxGLSurfaceView(Context paramContext, AttributeSet paramAttributeSet) {
    super(paramContext, paramAttributeSet);
    initView();
  }
  
  public static void closeIMEKeyboard() {
    Message message = new Message();
    message.what = 3;
    sHandler.sendMessage(message);
  }
  
  private static void dumpMotionEvent(MotionEvent paramMotionEvent) {
    StringBuilder stringBuilder = new StringBuilder();
    int i = paramMotionEvent.getAction();
    int j = i & 0xFF;
    (new String[10])[0] = "DOWN";
    (new String[10])[1] = "UP";
    (new String[10])[2] = "MOVE";
    (new String[10])[3] = "CANCEL";
    (new String[10])[4] = "OUTSIDE";
    (new String[10])[5] = "POINTER_DOWN";
    (new String[10])[6] = "POINTER_UP";
    (new String[10])[7] = "7?";
    (new String[10])[8] = "8?";
    (new String[10])[9] = "9?";
    stringBuilder.append("event ACTION_").append((new String[10])[j]);
    if (j == 5 || j == 6) {
      stringBuilder.append("(pid ").append(i >> 8);
      stringBuilder.append(")");
    } 
    stringBuilder.append("[");
    for (i = 0;; i++) {
      if (i >= paramMotionEvent.getPointerCount()) {
        stringBuilder.append("]");
        Log.d(TAG, stringBuilder.toString());
        return;
      } 
      stringBuilder.append("#").append(i);
      stringBuilder.append("(pid ").append(paramMotionEvent.getPointerId(i));
      stringBuilder.append(")=").append((int)paramMotionEvent.getX(i));
      stringBuilder.append(",").append((int)paramMotionEvent.getY(i));
      if (i + 1 < paramMotionEvent.getPointerCount())
        stringBuilder.append(";"); 
    } 
  }
  
  private String getContentText() {
    return this.mCocos2dxRenderer.getContentText();
  }
  
  public static Cocos2dxGLSurfaceView getInstance() {
    return mCocos2dxGLSurfaceView;
  }
  
  public static void openIMEKeyboard() {
    Message message = new Message();
    message.what = 2;
    message.obj = mCocos2dxGLSurfaceView.getContentText();
    sHandler.sendMessage(message);
  }
  
  public static void queueAccelerometer(final float x, final float y, final float z, final long timestamp) {
    mCocos2dxGLSurfaceView.queueEvent(new Runnable() {
          public void run() {
            Cocos2dxAccelerometer.onSensorChanged(x, y, z, timestamp);
          }
        });
  }
  
  public void deleteBackward() {
    queueEvent(new Runnable() {
          public void run() {
            Cocos2dxGLSurfaceView.this.mCocos2dxRenderer.handleDeleteBackward();
          }
        });
  }
  
  public Cocos2dxEditText getCocos2dxEditText() {
    return this.mCocos2dxEditText;
  }
  
  protected void initView() {
    setEGLContextClientVersion(2);
    setFocusableInTouchMode(true);
    mCocos2dxGLSurfaceView = this;
    sCocos2dxTextInputWraper = new Cocos2dxTextInputWraper(this);
    sHandler = new Handler() {
        public void handleMessage(Message param1Message) {
          switch (param1Message.what) {
            default:
              return;
            case 2:
              if (Cocos2dxGLSurfaceView.this.mCocos2dxEditText != null && Cocos2dxGLSurfaceView.this.mCocos2dxEditText.requestFocus()) {
                Cocos2dxGLSurfaceView.this.mCocos2dxEditText.removeTextChangedListener(Cocos2dxGLSurfaceView.sCocos2dxTextInputWraper);
                Cocos2dxGLSurfaceView.this.mCocos2dxEditText.setText("");
                String str = (String)param1Message.obj;
                Cocos2dxGLSurfaceView.this.mCocos2dxEditText.append(str);
                Cocos2dxGLSurfaceView.sCocos2dxTextInputWraper.setOriginText(str);
                Cocos2dxGLSurfaceView.this.mCocos2dxEditText.addTextChangedListener(Cocos2dxGLSurfaceView.sCocos2dxTextInputWraper);
                ((InputMethodManager)Cocos2dxGLSurfaceView.mCocos2dxGLSurfaceView.getContext().getSystemService("input_method")).showSoftInput((View)Cocos2dxGLSurfaceView.this.mCocos2dxEditText, 0);
                Log.d("GLSurfaceView", "showSoftInput");
                return;
              } 
            case 3:
              break;
          } 
          if (Cocos2dxGLSurfaceView.this.mCocos2dxEditText != null) {
            Cocos2dxGLSurfaceView.this.mCocos2dxEditText.removeTextChangedListener(Cocos2dxGLSurfaceView.sCocos2dxTextInputWraper);
            ((InputMethodManager)Cocos2dxGLSurfaceView.mCocos2dxGLSurfaceView.getContext().getSystemService("input_method")).hideSoftInputFromWindow(Cocos2dxGLSurfaceView.this.mCocos2dxEditText.getWindowToken(), 0);
            Cocos2dxGLSurfaceView.this.requestFocus();
            Log.d("GLSurfaceView", "HideSoftInput");
            return;
          } 
        }
      };
  }
  
  public void insertText(final String pText) {
    queueEvent(new Runnable() {
          public void run() {
            Cocos2dxGLSurfaceView.this.mCocos2dxRenderer.handleInsertText(pText);
          }
        });
  }
  
  public boolean onKeyDown(final int pKeyCode, KeyEvent paramKeyEvent) {
    switch (pKeyCode) {
      default:
        return super.onKeyDown(pKeyCode, paramKeyEvent);
      case 4:
      case 82:
        break;
    } 
    queueEvent(new Runnable() {
          public void run() {
            Cocos2dxGLSurfaceView.this.mCocos2dxRenderer.handleKeyDown(pKeyCode);
          }
        });
    return true;
  }
  
  public void onPause() {
    queueEvent(new Runnable() {
          public void run() {
            Cocos2dxGLSurfaceView.this.mCocos2dxRenderer.handleOnPause();
          }
        });
  }
  
  public void onResume() {
    super.onResume();
    queueEvent(new Runnable() {
          public void run() {
            Cocos2dxGLSurfaceView.this.mCocos2dxRenderer.handleOnResume();
          }
        });
  }
  
  protected void onSizeChanged(int paramInt1, int paramInt2, int paramInt3, int paramInt4) {
    if (!isInEditMode())
      this.mCocos2dxRenderer.setScreenWidthAndHeight(paramInt1, paramInt2); 
  }
  
  public boolean onTouchEvent(MotionEvent paramMotionEvent) {
    int j = paramMotionEvent.getPointerCount();
    final int[] ids = new int[j];
    final float[] xs = new float[j];
    final float[] ys = new float[j];
    int i = 0;
    while (true) {
      if (i >= j) {
        switch (paramMotionEvent.getAction() & 0xFF) {
          default:
            return true;
          case 5:
            i = paramMotionEvent.getAction() >> 8;
            queueEvent(new Runnable() {
                  public void run() {
                    Cocos2dxGLSurfaceView.this.mCocos2dxRenderer.handleActionDown(idPointerDown, xPointerDown, yPointerDown);
                  }
                });
          case 0:
            queueEvent(new Runnable() {
                  public void run() {
                    Cocos2dxGLSurfaceView.this.mCocos2dxRenderer.handleActionDown(idDown, xDown, yDown);
                  }
                });
          case 2:
            queueEvent(new Runnable() {
                  public void run() {
                    Cocos2dxGLSurfaceView.this.mCocos2dxRenderer.handleActionMove(ids, xs, ys);
                  }
                });
          case 6:
            i = paramMotionEvent.getAction() >> 8;
            queueEvent(new Runnable() {
                  public void run() {
                    Cocos2dxGLSurfaceView.this.mCocos2dxRenderer.handleActionUp(idPointerUp, xPointerUp, yPointerUp);
                  }
                });
          case 1:
            queueEvent(new Runnable() {
                  public void run() {
                    Cocos2dxGLSurfaceView.this.mCocos2dxRenderer.handleActionUp(idUp, xUp, yUp);
                  }
                });
          case 3:
            break;
        } 
      } else {
        arrayOfInt[i] = paramMotionEvent.getPointerId(i);
        arrayOfFloat1[i] = paramMotionEvent.getX(i);
        arrayOfFloat2[i] = paramMotionEvent.getY(i);
        i++;
        continue;
      } 
      queueEvent(new Runnable() {
            public void run() {
              Cocos2dxGLSurfaceView.this.mCocos2dxRenderer.handleActionCancel(ids, xs, ys);
            }
          });
    } 
  }
  
  public void setCocos2dxEditText(Cocos2dxEditText paramCocos2dxEditText) {
    this.mCocos2dxEditText = paramCocos2dxEditText;
    if (this.mCocos2dxEditText != null && sCocos2dxTextInputWraper != null) {
      this.mCocos2dxEditText.setOnEditorActionListener(sCocos2dxTextInputWraper);
      this.mCocos2dxEditText.setCocos2dxGLSurfaceView(this);
      requestFocus();
    } 
  }
  
  public void setCocos2dxRenderer(Cocos2dxRenderer paramCocos2dxRenderer) {
    this.mCocos2dxRenderer = paramCocos2dxRenderer;
    setRenderer(this.mCocos2dxRenderer);
  }
}


/* Location:              C:\soft\dex2jar-2.0\Tom Run-dex2jar.jar!\org\cocos2dx\lib\Cocos2dxGLSurfaceView.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */