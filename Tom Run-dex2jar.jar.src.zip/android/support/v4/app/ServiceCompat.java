package android.support.v4.app;

public class ServiceCompat {
  public static final int START_STICKY = 1;
}


/* Location:              C:\soft\dex2jar-2.0\Tom Run-dex2jar.jar!\android\support\v4\app\ServiceCompat.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */