package android.support.v4.app;

import android.text.Html;

class ShareCompatJB {
  public static String escapeHtml(CharSequence paramCharSequence) {
    return Html.escapeHtml(paramCharSequence);
  }
}


/* Location:              C:\soft\dex2jar-2.0\Tom Run-dex2jar.jar!\android\support\v4\app\ShareCompatJB.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */