package android.support.v4.widget;

import android.content.Context;
import android.os.Build;
import android.view.View;

public class SearchViewCompat {
  private static final SearchViewCompatImpl IMPL = new SearchViewCompatStubImpl();
  
  private SearchViewCompat(Context paramContext) {}
  
  public static View newSearchView(Context paramContext) {
    return IMPL.newSearchView(paramContext);
  }
  
  public static void setOnQueryTextListener(View paramView, OnQueryTextListenerCompat paramOnQueryTextListenerCompat) {
    IMPL.setOnQueryTextListener(paramView, paramOnQueryTextListenerCompat.mListener);
  }
  
  static {
    if (Build.VERSION.SDK_INT >= 11) {
      IMPL = new SearchViewCompatHoneycombImpl();
      return;
    } 
  }
  
  public static abstract class OnQueryTextListenerCompat {
    final Object mListener = SearchViewCompat.IMPL.newOnQueryTextListener(this);
    
    public boolean onQueryTextChange(String param1String) {
      return false;
    }
    
    public boolean onQueryTextSubmit(String param1String) {
      return false;
    }
  }
  
  static class SearchViewCompatHoneycombImpl extends SearchViewCompatStubImpl {
    public Object newOnQueryTextListener(final SearchViewCompat.OnQueryTextListenerCompat listener) {
      return SearchViewCompatHoneycomb.newOnQueryTextListener(new SearchViewCompatHoneycomb.OnQueryTextListenerCompatBridge() {
            public boolean onQueryTextChange(String param2String) {
              return listener.onQueryTextChange(param2String);
            }
            
            public boolean onQueryTextSubmit(String param2String) {
              return listener.onQueryTextSubmit(param2String);
            }
          });
    }
    
    public View newSearchView(Context param1Context) {
      return SearchViewCompatHoneycomb.newSearchView(param1Context);
    }
    
    public void setOnQueryTextListener(Object param1Object1, Object param1Object2) {
      SearchViewCompatHoneycomb.setOnQueryTextListener(param1Object1, param1Object2);
    }
  }
  
  class null implements SearchViewCompatHoneycomb.OnQueryTextListenerCompatBridge {
    public boolean onQueryTextChange(String param1String) {
      return listener.onQueryTextChange(param1String);
    }
    
    public boolean onQueryTextSubmit(String param1String) {
      return listener.onQueryTextSubmit(param1String);
    }
  }
  
  static interface SearchViewCompatImpl {
    Object newOnQueryTextListener(SearchViewCompat.OnQueryTextListenerCompat param1OnQueryTextListenerCompat);
    
    View newSearchView(Context param1Context);
    
    void setOnQueryTextListener(Object param1Object1, Object param1Object2);
  }
  
  static class SearchViewCompatStubImpl implements SearchViewCompatImpl {
    public Object newOnQueryTextListener(SearchViewCompat.OnQueryTextListenerCompat param1OnQueryTextListenerCompat) {
      return null;
    }
    
    public View newSearchView(Context param1Context) {
      return null;
    }
    
    public void setOnQueryTextListener(Object param1Object1, Object param1Object2) {}
  }
}


/* Location:              C:\soft\dex2jar-2.0\Tom Run-dex2jar.jar!\android\support\v4\widget\SearchViewCompat.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */