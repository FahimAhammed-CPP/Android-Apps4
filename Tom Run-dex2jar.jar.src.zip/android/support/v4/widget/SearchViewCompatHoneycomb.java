package android.support.v4.widget;

import android.content.Context;
import android.view.View;
import android.widget.SearchView;

class SearchViewCompatHoneycomb {
  public static Object newOnQueryTextListener(final OnQueryTextListenerCompatBridge listener) {
    return new SearchView.OnQueryTextListener() {
        public boolean onQueryTextChange(String param1String) {
          return listener.onQueryTextChange(param1String);
        }
        
        public boolean onQueryTextSubmit(String param1String) {
          return listener.onQueryTextSubmit(param1String);
        }
      };
  }
  
  public static View newSearchView(Context paramContext) {
    return (View)new SearchView(paramContext);
  }
  
  public static void setOnQueryTextListener(Object paramObject1, Object paramObject2) {
    ((SearchView)paramObject1).setOnQueryTextListener((SearchView.OnQueryTextListener)paramObject2);
  }
  
  static interface OnQueryTextListenerCompatBridge {
    boolean onQueryTextChange(String param1String);
    
    boolean onQueryTextSubmit(String param1String);
  }
}


/* Location:              C:\soft\dex2jar-2.0\Tom Run-dex2jar.jar!\android\support\v4\widget\SearchViewCompatHoneycomb.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */