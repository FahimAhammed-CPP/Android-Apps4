package android.support.v4.view;

import android.view.View;

public class ViewCompatJellybeanMr1 {
  public static int getLabelFor(View paramView) {
    return paramView.getLabelFor();
  }
  
  public static void setLabelFor(View paramView, int paramInt) {
    paramView.setLabelFor(paramInt);
  }
}


/* Location:              C:\soft\dex2jar-2.0\Tom Run-dex2jar.jar!\android\support\v4\view\ViewCompatJellybeanMr1.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */