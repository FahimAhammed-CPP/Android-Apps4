package android.support.v4.view;

import android.os.Build;
import android.view.MotionEvent;

public class MotionEventCompat {
  public static final int ACTION_HOVER_ENTER = 9;
  
  public static final int ACTION_HOVER_EXIT = 10;
  
  public static final int ACTION_HOVER_MOVE = 7;
  
  public static final int ACTION_MASK = 255;
  
  public static final int ACTION_POINTER_DOWN = 5;
  
  public static final int ACTION_POINTER_INDEX_MASK = 65280;
  
  public static final int ACTION_POINTER_INDEX_SHIFT = 8;
  
  public static final int ACTION_POINTER_UP = 6;
  
  public static final int ACTION_SCROLL = 8;
  
  static final MotionEventVersionImpl IMPL = new BaseMotionEventVersionImpl();
  
  public static int findPointerIndex(MotionEvent paramMotionEvent, int paramInt) {
    return IMPL.findPointerIndex(paramMotionEvent, paramInt);
  }
  
  public static int getActionIndex(MotionEvent paramMotionEvent) {
    return (paramMotionEvent.getAction() & 0xFF00) >> 8;
  }
  
  public static int getActionMasked(MotionEvent paramMotionEvent) {
    return paramMotionEvent.getAction() & 0xFF;
  }
  
  public static int getPointerCount(MotionEvent paramMotionEvent) {
    return IMPL.getPointerCount(paramMotionEvent);
  }
  
  public static int getPointerId(MotionEvent paramMotionEvent, int paramInt) {
    return IMPL.getPointerId(paramMotionEvent, paramInt);
  }
  
  public static float getX(MotionEvent paramMotionEvent, int paramInt) {
    return IMPL.getX(paramMotionEvent, paramInt);
  }
  
  public static float getY(MotionEvent paramMotionEvent, int paramInt) {
    return IMPL.getY(paramMotionEvent, paramInt);
  }
  
  static {
    if (Build.VERSION.SDK_INT >= 5) {
      IMPL = new EclairMotionEventVersionImpl();
      return;
    } 
  }
  
  static class BaseMotionEventVersionImpl implements MotionEventVersionImpl {
    public int findPointerIndex(MotionEvent param1MotionEvent, int param1Int) {
      return (param1Int == 0) ? 0 : -1;
    }
    
    public int getPointerCount(MotionEvent param1MotionEvent) {
      return 1;
    }
    
    public int getPointerId(MotionEvent param1MotionEvent, int param1Int) {
      if (param1Int == 0)
        return 0; 
      throw new IndexOutOfBoundsException("Pre-Eclair does not support multiple pointers");
    }
    
    public float getX(MotionEvent param1MotionEvent, int param1Int) {
      if (param1Int == 0)
        return param1MotionEvent.getX(); 
      throw new IndexOutOfBoundsException("Pre-Eclair does not support multiple pointers");
    }
    
    public float getY(MotionEvent param1MotionEvent, int param1Int) {
      if (param1Int == 0)
        return param1MotionEvent.getY(); 
      throw new IndexOutOfBoundsException("Pre-Eclair does not support multiple pointers");
    }
  }
  
  static class EclairMotionEventVersionImpl implements MotionEventVersionImpl {
    public int findPointerIndex(MotionEvent param1MotionEvent, int param1Int) {
      return MotionEventCompatEclair.findPointerIndex(param1MotionEvent, param1Int);
    }
    
    public int getPointerCount(MotionEvent param1MotionEvent) {
      return MotionEventCompatEclair.getPointerCount(param1MotionEvent);
    }
    
    public int getPointerId(MotionEvent param1MotionEvent, int param1Int) {
      return MotionEventCompatEclair.getPointerId(param1MotionEvent, param1Int);
    }
    
    public float getX(MotionEvent param1MotionEvent, int param1Int) {
      return MotionEventCompatEclair.getX(param1MotionEvent, param1Int);
    }
    
    public float getY(MotionEvent param1MotionEvent, int param1Int) {
      return MotionEventCompatEclair.getY(param1MotionEvent, param1Int);
    }
  }
  
  static interface MotionEventVersionImpl {
    int findPointerIndex(MotionEvent param1MotionEvent, int param1Int);
    
    int getPointerCount(MotionEvent param1MotionEvent);
    
    int getPointerId(MotionEvent param1MotionEvent, int param1Int);
    
    float getX(MotionEvent param1MotionEvent, int param1Int);
    
    float getY(MotionEvent param1MotionEvent, int param1Int);
  }
}


/* Location:              C:\soft\dex2jar-2.0\Tom Run-dex2jar.jar!\android\support\v4\view\MotionEventCompat.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */