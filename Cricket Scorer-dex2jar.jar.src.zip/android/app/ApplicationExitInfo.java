package android.app;

import android.annotation.NonNull;
import android.annotation.Nullable;
import android.os.Parcelable;
import java.io.IOException;
import java.io.InputStream;



/* Location:              C:\soft\dex2jar-2.0\Cricket Scorer-dex2jar.jar!\android\app\ApplicationExitInfo.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */