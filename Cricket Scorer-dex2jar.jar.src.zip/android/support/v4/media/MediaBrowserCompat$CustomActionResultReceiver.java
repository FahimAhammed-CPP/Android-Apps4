package android.support.v4.media;

import android.os.Bundle;
import android.support.v4.media.session.MediaSessionCompat;
import android.support.v4.os.b;
import android.util.Log;

class MediaBrowserCompat$CustomActionResultReceiver extends b {
  private final String d;
  
  private final Bundle e;
  
  private final a f;
  
  protected void a(int paramInt, Bundle paramBundle) {
    if (this.f == null)
      return; 
    MediaSessionCompat.a(paramBundle);
    if (paramInt != -1) {
      if (paramInt != 0) {
        if (paramInt != 1) {
          StringBuilder stringBuilder = new StringBuilder();
          stringBuilder.append("Unknown result code: ");
          stringBuilder.append(paramInt);
          stringBuilder.append(" (extras=");
          stringBuilder.append(this.e);
          stringBuilder.append(", resultData=");
          stringBuilder.append(paramBundle);
          stringBuilder.append(")");
          Log.w("MediaBrowserCompat", stringBuilder.toString());
          return;
        } 
        this.f.b(this.d, this.e, paramBundle);
        return;
      } 
      this.f.c(this.d, this.e, paramBundle);
      return;
    } 
    this.f.a(this.d, this.e, paramBundle);
  }
}


/* Location:              C:\soft\dex2jar-2.0\Cricket Scorer-dex2jar.jar!\android\support\v4\media\MediaBrowserCompat$CustomActionResultReceiver.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */