package android.support.v4.media;

import android.os.Build;
import android.os.Parcel;

public abstract class b {
  final Object a;
  
  public b() {
    if (Build.VERSION.SDK_INT >= 23) {
      this.a = d.a(new a(this));
      return;
    } 
    this.a = null;
  }
  
  public void a(String paramString) {}
  
  public void b(MediaBrowserCompat$MediaItem paramMediaBrowserCompat$MediaItem) {}
  
  private class a implements d.a {
    a(b this$0) {}
    
    public void a(Parcel param1Parcel) {
      if (param1Parcel == null) {
        this.a.b(null);
        return;
      } 
      param1Parcel.setDataPosition(0);
      MediaBrowserCompat$MediaItem mediaBrowserCompat$MediaItem = (MediaBrowserCompat$MediaItem)MediaBrowserCompat$MediaItem.CREATOR.createFromParcel(param1Parcel);
      param1Parcel.recycle();
      this.a.b(mediaBrowserCompat$MediaItem);
    }
    
    public void b(String param1String) {
      this.a.a(param1String);
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Cricket Scorer-dex2jar.jar!\android\support\v4\media\b.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */