package android.support.v4.media;

import android.os.Bundle;

public abstract class a {
  public void a(String paramString, Bundle paramBundle1, Bundle paramBundle2) {}
  
  public void b(String paramString, Bundle paramBundle1, Bundle paramBundle2) {}
  
  public void c(String paramString, Bundle paramBundle1, Bundle paramBundle2) {}
}


/* Location:              C:\soft\dex2jar-2.0\Cricket Scorer-dex2jar.jar!\android\support\v4\media\a.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */