package android.support.v4.media;

import android.media.MediaDescription;
import android.net.Uri;

class h {
  public static Uri a(Object paramObject) {
    return f.a((MediaDescription)paramObject);
  }
  
  static class a {
    public static void a(Object param1Object, Uri param1Uri) {
      g.a((MediaDescription.Builder)param1Object, param1Uri);
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Cricket Scorer-dex2jar.jar!\android\support\v4\media\h.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */