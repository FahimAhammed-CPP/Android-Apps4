package android.support.v4.media;

import android.os.Bundle;
import android.os.Parcelable;
import android.support.v4.media.session.MediaSessionCompat;
import android.support.v4.os.b;

class MediaBrowserCompat$ItemReceiver extends b {
  private final String d;
  
  private final b e;
  
  protected void a(int paramInt, Bundle paramBundle) {
    MediaSessionCompat.a(paramBundle);
    if (paramInt != 0 || paramBundle == null || !paramBundle.containsKey("media_item")) {
      this.e.a(this.d);
      return;
    } 
    Parcelable parcelable = paramBundle.getParcelable("media_item");
    if (parcelable == null || parcelable instanceof MediaBrowserCompat$MediaItem) {
      this.e.b((MediaBrowserCompat$MediaItem)parcelable);
      return;
    } 
    this.e.a(this.d);
  }
}


/* Location:              C:\soft\dex2jar-2.0\Cricket Scorer-dex2jar.jar!\android\support\v4\media\MediaBrowserCompat$ItemReceiver.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */