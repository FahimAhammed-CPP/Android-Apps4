package android.support.v4.media;

import android.media.browse.MediaBrowser;
import android.os.Parcel;

class d {
  public static Object a(a parama) {
    return new b<a>(parama);
  }
  
  static interface a {
    void a(Parcel param1Parcel);
    
    void b(String param1String);
  }
  
  static class b<T extends a> extends MediaBrowser.ItemCallback {
    protected final T a;
    
    public b(T param1T) {
      this.a = param1T;
    }
    
    public void onError(String param1String) {
      this.a.b(param1String);
    }
    
    public void onItemLoaded(MediaBrowser.MediaItem param1MediaItem) {
      if (param1MediaItem == null) {
        this.a.a(null);
        return;
      } 
      Parcel parcel = Parcel.obtain();
      param1MediaItem.writeToParcel(parcel, 0);
      this.a.a(parcel);
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Cricket Scorer-dex2jar.jar!\android\support\v4\media\d.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */