package android.support.v4.media;

import android.os.Bundle;
import java.util.List;

public abstract class c {
  public void a(String paramString, Bundle paramBundle) {}
  
  public void b(String paramString, Bundle paramBundle, List<MediaBrowserCompat$MediaItem> paramList) {}
}


/* Location:              C:\soft\dex2jar-2.0\Cricket Scorer-dex2jar.jar!\android\support\v4\media\c.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */