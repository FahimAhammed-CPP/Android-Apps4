package android.support.v4.media.session;

import android.app.PendingIntent;
import android.net.Uri;
import android.os.Binder;
import android.os.Bundle;
import android.os.IBinder;
import android.os.IInterface;
import android.os.Parcel;
import android.os.RemoteException;
import android.support.v4.media.MediaDescriptionCompat;
import android.support.v4.media.MediaMetadataCompat;
import android.support.v4.media.RatingCompat;
import android.view.KeyEvent;
import java.util.List;

public interface b extends IInterface {
  void A() throws RemoteException;
  
  void A0(int paramInt) throws RemoteException;
  
  void B0() throws RemoteException;
  
  CharSequence E() throws RemoteException;
  
  int E0() throws RemoteException;
  
  void F0(long paramLong) throws RemoteException;
  
  void G(String paramString, Bundle paramBundle) throws RemoteException;
  
  void G0(boolean paramBoolean) throws RemoteException;
  
  ParcelableVolumeInfo H0() throws RemoteException;
  
  void I(a parama) throws RemoteException;
  
  void L(String paramString, Bundle paramBundle) throws RemoteException;
  
  void M0(int paramInt) throws RemoteException;
  
  void O(String paramString, Bundle paramBundle) throws RemoteException;
  
  void P() throws RemoteException;
  
  void R(Uri paramUri, Bundle paramBundle) throws RemoteException;
  
  String R0() throws RemoteException;
  
  void S(long paramLong) throws RemoteException;
  
  boolean Z(KeyEvent paramKeyEvent) throws RemoteException;
  
  void b0(int paramInt1, int paramInt2, String paramString) throws RemoteException;
  
  String c() throws RemoteException;
  
  void c0(RatingCompat paramRatingCompat, Bundle paramBundle) throws RemoteException;
  
  void d0(MediaDescriptionCompat paramMediaDescriptionCompat, int paramInt) throws RemoteException;
  
  Bundle getExtras() throws RemoteException;
  
  MediaMetadataCompat getMetadata() throws RemoteException;
  
  long j() throws RemoteException;
  
  void k0(boolean paramBoolean) throws RemoteException;
  
  void l(String paramString, Bundle paramBundle) throws RemoteException;
  
  void m(a parama) throws RemoteException;
  
  PlaybackStateCompat m0() throws RemoteException;
  
  boolean n() throws RemoteException;
  
  void next() throws RemoteException;
  
  int o0() throws RemoteException;
  
  void p(RatingCompat paramRatingCompat) throws RemoteException;
  
  void pause() throws RemoteException;
  
  void previous() throws RemoteException;
  
  void q(int paramInt1, int paramInt2, String paramString) throws RemoteException;
  
  void q0(int paramInt) throws RemoteException;
  
  void r(Uri paramUri, Bundle paramBundle) throws RemoteException;
  
  boolean r0() throws RemoteException;
  
  void s(MediaDescriptionCompat paramMediaDescriptionCompat) throws RemoteException;
  
  void stop() throws RemoteException;
  
  boolean t() throws RemoteException;
  
  void u(MediaDescriptionCompat paramMediaDescriptionCompat) throws RemoteException;
  
  PendingIntent v() throws RemoteException;
  
  int w() throws RemoteException;
  
  void w0() throws RemoteException;
  
  void x0(String paramString, Bundle paramBundle, MediaSessionCompat.ResultReceiverWrapper paramResultReceiverWrapper) throws RemoteException;
  
  void y(String paramString, Bundle paramBundle) throws RemoteException;
  
  List<MediaSessionCompat.QueueItem> z0() throws RemoteException;
  
  public static abstract class a extends Binder implements b {
    public a() {
      attachInterface(this, "android.support.v4.media.session.IMediaSession");
    }
    
    public static b Y0(IBinder param1IBinder) {
      if (param1IBinder == null)
        return null; 
      IInterface iInterface = param1IBinder.queryLocalInterface("android.support.v4.media.session.IMediaSession");
      return (iInterface != null && iInterface instanceof b) ? (b)iInterface : new a(param1IBinder);
    }
    
    public IBinder asBinder() {
      return (IBinder)this;
    }
    
    public boolean onTransact(int param1Int1, Parcel param1Parcel1, Parcel param1Parcel2, int param1Int2) throws RemoteException {
      throw new RuntimeException("d2j fail translate: java.lang.RuntimeException: can not merge I and Z\r\n\tat com.googlecode.dex2jar.ir.TypeClass.merge(TypeClass.java:100)\r\n\tat com.googlecode.dex2jar.ir.ts.TypeTransformer$TypeRef.updateTypeClass(TypeTransformer.java:174)\r\n\tat com.googlecode.dex2jar.ir.ts.TypeTransformer$TypeAnalyze.copyTypes(TypeTransformer.java:311)\r\n\tat com.googlecode.dex2jar.ir.ts.TypeTransformer$TypeAnalyze.fixTypes(TypeTransformer.java:226)\r\n\tat com.googlecode.dex2jar.ir.ts.TypeTransformer$TypeAnalyze.analyze(TypeTransformer.java:207)\r\n\tat com.googlecode.dex2jar.ir.ts.TypeTransformer.transform(TypeTransformer.java:44)\r\n\tat com.googlecode.d2j.dex.Dex2jar$2.optimize(Dex2jar.java:162)\r\n\tat com.googlecode.d2j.dex.Dex2Asm.convertCode(Dex2Asm.java:414)\r\n\tat com.googlecode.d2j.dex.ExDex2Asm.convertCode(ExDex2Asm.java:42)\r\n\tat com.googlecode.d2j.dex.Dex2jar$2.convertCode(Dex2jar.java:128)\r\n\tat com.googlecode.d2j.dex.Dex2Asm.convertMethod(Dex2Asm.java:509)\r\n\tat com.googlecode.d2j.dex.Dex2Asm.convertClass(Dex2Asm.java:406)\r\n\tat com.googlecode.d2j.dex.Dex2Asm.convertDex(Dex2Asm.java:422)\r\n\tat com.googlecode.d2j.dex.Dex2jar.doTranslate(Dex2jar.java:172)\r\n\tat com.googlecode.d2j.dex.Dex2jar.to(Dex2jar.java:272)\r\n\tat com.googlecode.dex2jar.tools.Dex2jarCmd.doCommandLine(Dex2jarCmd.java:108)\r\n\tat com.googlecode.dex2jar.tools.BaseCmd.doMain(BaseCmd.java:288)\r\n\tat com.googlecode.dex2jar.tools.Dex2jarCmd.main(Dex2jarCmd.java:32)\r\n");
    }
    
    private static class a implements b {
      private IBinder a;
      
      a(IBinder param2IBinder) {
        this.a = param2IBinder;
      }
      
      public IBinder asBinder() {
        return this.a;
      }
      
      public void m(a param2a) throws RemoteException {
        Parcel parcel1 = Parcel.obtain();
        Parcel parcel2 = Parcel.obtain();
        try {
          parcel1.writeInterfaceToken("android.support.v4.media.session.IMediaSession");
          if (param2a != null) {
            IBinder iBinder = param2a.asBinder();
          } else {
            param2a = null;
          } 
          parcel1.writeStrongBinder((IBinder)param2a);
          this.a.transact(3, parcel1, parcel2, 0);
          parcel2.readException();
          return;
        } finally {
          parcel2.recycle();
          parcel1.recycle();
        } 
      }
    }
  }
  
  private static class a implements b {
    private IBinder a;
    
    a(IBinder param1IBinder) {
      this.a = param1IBinder;
    }
    
    public IBinder asBinder() {
      return this.a;
    }
    
    public void m(a param1a) throws RemoteException {
      Parcel parcel1 = Parcel.obtain();
      Parcel parcel2 = Parcel.obtain();
      try {
        parcel1.writeInterfaceToken("android.support.v4.media.session.IMediaSession");
        if (param1a != null) {
          IBinder iBinder = param1a.asBinder();
        } else {
          param1a = null;
        } 
        parcel1.writeStrongBinder((IBinder)param1a);
        this.a.transact(3, parcel1, parcel2, 0);
        parcel2.readException();
        return;
      } finally {
        parcel2.recycle();
        parcel1.recycle();
      } 
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Cricket Scorer-dex2jar.jar!\android\support\v4\media\session\b.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */