package android.support.v4.media.session;

import android.os.Build;
import android.os.Bundle;
import android.os.IBinder;
import android.os.RemoteException;
import android.support.v4.media.MediaMetadataCompat;
import java.lang.ref.WeakReference;
import java.util.List;

public abstract class c implements IBinder.DeathRecipient {
  final Object a = e.a(new a(this));
  
  a b;
  
  public void a(d paramd) {}
  
  public void b(Bundle paramBundle) {}
  
  public void binderDied() {
    i(8, null, null);
  }
  
  public void c(MediaMetadataCompat paramMediaMetadataCompat) {}
  
  public void d(PlaybackStateCompat paramPlaybackStateCompat) {}
  
  public void e(List<MediaSessionCompat.QueueItem> paramList) {}
  
  public void f(CharSequence paramCharSequence) {}
  
  public void g() {}
  
  public void h(String paramString, Bundle paramBundle) {}
  
  void i(int paramInt, Object paramObject, Bundle paramBundle) {}
  
  private static class a implements e.a {
    private final WeakReference<c> a;
    
    a(c param1c) {
      this.a = new WeakReference<c>(param1c);
    }
    
    public void a(Object param1Object) {
      c c = this.a.get();
      if (c != null)
        c.c(MediaMetadataCompat.a(param1Object)); 
    }
    
    public void b(int param1Int1, int param1Int2, int param1Int3, int param1Int4, int param1Int5) {
      c c = this.a.get();
      if (c != null)
        c.a(new d(param1Int1, param1Int2, param1Int3, param1Int4, param1Int5)); 
    }
    
    public void c(Object param1Object) {
      c c = this.a.get();
      if (c != null) {
        if (c.b != null)
          return; 
        c.d(PlaybackStateCompat.a(param1Object));
      } 
    }
    
    public void d(String param1String, Bundle param1Bundle) {
      c c = this.a.get();
      if (c != null) {
        if (c.b != null && Build.VERSION.SDK_INT < 23)
          return; 
        c.h(param1String, param1Bundle);
      } 
    }
    
    public void e(Bundle param1Bundle) {
      c c = this.a.get();
      if (c != null)
        c.b(param1Bundle); 
    }
    
    public void f(List<?> param1List) {
      c c = this.a.get();
      if (c != null)
        c.e(MediaSessionCompat.QueueItem.b(param1List)); 
    }
    
    public void h(CharSequence param1CharSequence) {
      c c = this.a.get();
      if (c != null)
        c.f(param1CharSequence); 
    }
    
    public void i() {
      c c = this.a.get();
      if (c != null)
        c.g(); 
    }
  }
  
  private static class b extends a.a {
    private final WeakReference<c> a;
    
    b(c param1c) {
      this.a = new WeakReference<c>(param1c);
    }
    
    public void B() throws RemoteException {
      c c = this.a.get();
      if (c != null)
        c.i(13, null, null); 
    }
    
    public void T(boolean param1Boolean) throws RemoteException {
      c c = this.a.get();
      if (c != null)
        c.i(11, Boolean.valueOf(param1Boolean), null); 
    }
    
    public void T0(PlaybackStateCompat param1PlaybackStateCompat) throws RemoteException {
      c c = this.a.get();
      if (c != null)
        c.i(2, param1PlaybackStateCompat, null); 
    }
    
    public void X0(ParcelableVolumeInfo param1ParcelableVolumeInfo) throws RemoteException {
      c c = this.a.get();
      if (c != null) {
        if (param1ParcelableVolumeInfo != null) {
          d d = new d(param1ParcelableVolumeInfo.a, param1ParcelableVolumeInfo.b, param1ParcelableVolumeInfo.c, param1ParcelableVolumeInfo.d, param1ParcelableVolumeInfo.e);
        } else {
          param1ParcelableVolumeInfo = null;
        } 
        c.i(4, param1ParcelableVolumeInfo, null);
      } 
    }
    
    public void a0(boolean param1Boolean) throws RemoteException {}
    
    public void e(Bundle param1Bundle) throws RemoteException {
      c c = this.a.get();
      if (c != null)
        c.i(7, param1Bundle, null); 
    }
    
    public void f(List<MediaSessionCompat.QueueItem> param1List) throws RemoteException {
      c c = this.a.get();
      if (c != null)
        c.i(5, param1List, null); 
    }
    
    public void g0(MediaMetadataCompat param1MediaMetadataCompat) throws RemoteException {
      c c = this.a.get();
      if (c != null)
        c.i(3, param1MediaMetadataCompat, null); 
    }
    
    public void h(CharSequence param1CharSequence) throws RemoteException {
      c c = this.a.get();
      if (c != null)
        c.i(6, param1CharSequence, null); 
    }
    
    public void i() throws RemoteException {
      c c = this.a.get();
      if (c != null)
        c.i(8, null, null); 
    }
    
    public void k(String param1String, Bundle param1Bundle) throws RemoteException {
      c c = this.a.get();
      if (c != null)
        c.i(1, param1String, param1Bundle); 
    }
    
    public void l0(int param1Int) throws RemoteException {
      c c = this.a.get();
      if (c != null)
        c.i(9, Integer.valueOf(param1Int), null); 
    }
    
    public void s0(int param1Int) throws RemoteException {
      c c = this.a.get();
      if (c != null)
        c.i(12, Integer.valueOf(param1Int), null); 
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Cricket Scorer-dex2jar.jar!\android\support\v4\media\session\c.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */