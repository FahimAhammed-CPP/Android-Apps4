package android.webkit;


/* Location:              C:\soft\dex2jar-2.0\Cricket Scorer-dex2jar.jar!\android\webkit\WebResourceError.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */