package a0;

public final class a {
  public static final int a = 2130837507;
  
  public static final int b = 2130837508;
  
  public static final int c = 2130837509;
  
  public static final int d = 2130837510;
  
  public static final int e = 2130837511;
  
  public static final int f = 2130837512;
}


/* Location:              C:\soft\dex2jar-2.0\Cricket Scorer-dex2jar.jar!\a0\a.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */