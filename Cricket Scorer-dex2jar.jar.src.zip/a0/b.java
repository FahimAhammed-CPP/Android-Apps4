package a0;

public final class b {
  public static final int a = 2131296596;
  
  public static final int b = 2131296927;
  
  public static final int c = 2131297220;
}


/* Location:              C:\soft\dex2jar-2.0\Cricket Scorer-dex2jar.jar!\a0\b.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */