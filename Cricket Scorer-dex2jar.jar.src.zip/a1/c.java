package a1;

import java.io.ByteArrayOutputStream;
import java.io.Closeable;
import java.io.EOFException;
import java.io.IOException;
import java.io.InputStream;
import java.io.UnsupportedEncodingException;
import java.nio.charset.Charset;

class c implements Closeable {
  private final InputStream a;
  
  private final Charset b;
  
  private byte[] c;
  
  private int d;
  
  private int e;
  
  public c(InputStream paramInputStream, int paramInt, Charset paramCharset) {
    if (paramInputStream != null && paramCharset != null) {
      if (paramInt >= 0) {
        if (paramCharset.equals(d.a)) {
          this.a = paramInputStream;
          this.b = paramCharset;
          this.c = new byte[paramInt];
          return;
        } 
        throw new IllegalArgumentException("Unsupported encoding");
      } 
      throw new IllegalArgumentException("capacity <= 0");
    } 
    throw null;
  }
  
  public c(InputStream paramInputStream, Charset paramCharset) {
    this(paramInputStream, 8192, paramCharset);
  }
  
  private void e() throws IOException {
    InputStream inputStream = this.a;
    byte[] arrayOfByte = this.c;
    int i = inputStream.read(arrayOfByte, 0, arrayOfByte.length);
    if (i != -1) {
      this.d = 0;
      this.e = i;
      return;
    } 
    throw new EOFException();
  }
  
  public void close() throws IOException {
    synchronized (this.a) {
      if (this.c != null) {
        this.c = null;
        this.a.close();
      } 
      return;
    } 
  }
  
  public boolean i() {
    return (this.e == -1);
  }
  
  public String o() throws IOException {
    synchronized (this.a) {
      if (this.c != null) {
        if (this.d >= this.e)
          e(); 
        for (int i = this.d;; i++) {
          if (i != this.e) {
            byte[] arrayOfByte = this.c;
            if (arrayOfByte[i] == 10) {
              int k = this.d;
              if (i != k) {
                int m = i - 1;
                if (arrayOfByte[m] == 13) {
                  str = new String(arrayOfByte, k, m - k, this.b.name());
                  this.d = i + 1;
                  return str;
                } 
              } 
              int j = i;
              String str = new String((byte[])str, k, j - k, this.b.name());
              this.d = i + 1;
              return str;
            } 
          } else {
            a a = new a(this, this.e - this.d + 80);
            while (true) {
              byte[] arrayOfByte = this.c;
              i = this.d;
              a.write(arrayOfByte, i, this.e - i);
              this.e = -1;
              e();
              for (i = this.d; i != this.e; i++) {
                arrayOfByte = this.c;
                if (arrayOfByte[i] == 10) {
                  int j = this.d;
                  if (i != j)
                    a.write(arrayOfByte, j, i - j); 
                  this.d = i + 1;
                  return a.toString();
                } 
              } 
            } 
            break;
          } 
        } 
      } 
      throw new IOException("LineReader is closed");
    } 
  }
  
  class a extends ByteArrayOutputStream {
    a(c this$0, int param1Int) {
      super(param1Int);
    }
    
    public String toString() {
      int j = this.count;
      int i = j;
      if (j > 0) {
        i = j;
        if (this.buf[j - 1] == 13)
          i = j - 1; 
      } 
      try {
        return new String(this.buf, 0, i, c.a(this.a).name());
      } catch (UnsupportedEncodingException unsupportedEncodingException) {
        throw new AssertionError(unsupportedEncodingException);
      } 
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Cricket Scorer-dex2jar.jar!\a1\c.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */