package a2;

import android.os.Build;
import android.util.Log;

public final class a {
  private static String a(String paramString1, String paramString2) {
    StringBuilder stringBuilder = new StringBuilder();
    stringBuilder.append(paramString1);
    stringBuilder.append(paramString2);
    paramString2 = stringBuilder.toString();
    paramString1 = paramString2;
    if (paramString2.length() > 23)
      paramString1 = paramString2.substring(0, 23); 
    return paramString1;
  }
  
  public static void b(String paramString1, String paramString2, Object paramObject) {
    paramString1 = e(paramString1);
    if (Log.isLoggable(paramString1, 3))
      Log.d(paramString1, String.format(paramString2, new Object[] { paramObject })); 
  }
  
  public static void c(String paramString1, String paramString2, Object... paramVarArgs) {
    paramString1 = e(paramString1);
    if (Log.isLoggable(paramString1, 3))
      Log.d(paramString1, String.format(paramString2, paramVarArgs)); 
  }
  
  public static void d(String paramString1, String paramString2, Throwable paramThrowable) {
    paramString1 = e(paramString1);
    if (Log.isLoggable(paramString1, 6))
      Log.e(paramString1, paramString2, paramThrowable); 
  }
  
  private static String e(String paramString) {
    if (Build.VERSION.SDK_INT < 26)
      return a("TRuntime.", paramString); 
    StringBuilder stringBuilder = new StringBuilder();
    stringBuilder.append("TRuntime.");
    stringBuilder.append(paramString);
    return stringBuilder.toString();
  }
  
  public static void f(String paramString1, String paramString2, Object paramObject) {
    paramString1 = e(paramString1);
    if (Log.isLoggable(paramString1, 4))
      Log.i(paramString1, String.format(paramString2, new Object[] { paramObject })); 
  }
  
  public static void g(String paramString1, String paramString2, Object paramObject) {
    paramString1 = e(paramString1);
    if (Log.isLoggable(paramString1, 5))
      Log.w(paramString1, String.format(paramString2, new Object[] { paramObject })); 
  }
}


/* Location:              C:\soft\dex2jar-2.0\Cricket Scorer-dex2jar.jar!\a2\a.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */