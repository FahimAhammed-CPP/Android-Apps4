package a4;

public interface b {
  void a(a parama);
}


/* Location:              C:\soft\dex2jar-2.0\Cricket Scorer-dex2jar.jar!\a4\b.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */