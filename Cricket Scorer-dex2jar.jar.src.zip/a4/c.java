package a4;

import y3.f;

public class c implements b {
  public void a(a parama) {
    f.f().b("Could not register handler for breadcrumbs events.");
  }
}


/* Location:              C:\soft\dex2jar-2.0\Cricket Scorer-dex2jar.jar!\a4\c.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */