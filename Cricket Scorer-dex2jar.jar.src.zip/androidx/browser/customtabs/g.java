package androidx.browser.customtabs;

import a.a;
import a.b;
import android.app.PendingIntent;
import android.content.ComponentName;
import android.os.IBinder;

public final class g {
  private final Object a = new Object();
  
  private final b b;
  
  private final a c;
  
  private final ComponentName d;
  
  private final PendingIntent e;
  
  g(b paramb, a parama, ComponentName paramComponentName, PendingIntent paramPendingIntent) {
    this.b = paramb;
    this.c = parama;
    this.d = paramComponentName;
    this.e = paramPendingIntent;
  }
  
  IBinder a() {
    return this.c.asBinder();
  }
  
  ComponentName b() {
    return this.d;
  }
  
  PendingIntent c() {
    return this.e;
  }
}


/* Location:              C:\soft\dex2jar-2.0\Cricket Scorer-dex2jar.jar!\androidx\browser\customtabs\g.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */