package androidx.browser.customtabs;

import android.app.PendingIntent;
import android.net.Uri;
import android.os.Bundle;
import android.os.IBinder;
import android.os.RemoteException;
import android.util.Log;

public class h {
  final a.a a;
  
  private final PendingIntent b;
  
  private final b c;
  
  h(a.a parama, PendingIntent paramPendingIntent) {
    if (parama != null || paramPendingIntent != null) {
      a a1;
      this.a = parama;
      this.b = paramPendingIntent;
      if (parama == null) {
        parama = null;
      } else {
        a1 = new a(this);
      } 
      this.c = a1;
      return;
    } 
    throw new IllegalStateException("CustomTabsSessionToken must have either a session id or a callback (or both).");
  }
  
  private IBinder b() {
    a.a a1 = this.a;
    if (a1 != null)
      return a1.asBinder(); 
    throw new IllegalStateException("CustomTabSessionToken must have valid binder or pending session");
  }
  
  IBinder a() {
    a.a a1 = this.a;
    return (a1 == null) ? null : a1.asBinder();
  }
  
  PendingIntent c() {
    return this.b;
  }
  
  public boolean equals(Object paramObject) {
    boolean bool1;
    if (!(paramObject instanceof h))
      return false; 
    paramObject = paramObject;
    PendingIntent pendingIntent1 = paramObject.c();
    PendingIntent pendingIntent2 = this.b;
    boolean bool2 = true;
    if (pendingIntent2 == null) {
      bool1 = true;
    } else {
      bool1 = false;
    } 
    if (pendingIntent1 != null)
      bool2 = false; 
    return (bool1 != bool2) ? false : ((pendingIntent2 != null) ? pendingIntent2.equals(pendingIntent1) : b().equals(paramObject.b()));
  }
  
  public int hashCode() {
    PendingIntent pendingIntent = this.b;
    return (pendingIntent != null) ? pendingIntent.hashCode() : b().hashCode();
  }
  
  class a extends b {
    a(h this$0) {}
    
    public void extraCallback(String param1String, Bundle param1Bundle) {
      try {
        this.b.a.n0(param1String, param1Bundle);
        return;
      } catch (RemoteException remoteException) {
        Log.e("CustomTabsSessionToken", "RemoteException during ICustomTabsCallback transaction");
        return;
      } 
    }
    
    public Bundle extraCallbackWithResult(String param1String, Bundle param1Bundle) {
      try {
        return this.b.a.F(param1String, param1Bundle);
      } catch (RemoteException remoteException) {
        Log.e("CustomTabsSessionToken", "RemoteException during ICustomTabsCallback transaction");
        return null;
      } 
    }
    
    public void onMessageChannelReady(Bundle param1Bundle) {
      try {
        this.b.a.O0(param1Bundle);
        return;
      } catch (RemoteException remoteException) {
        Log.e("CustomTabsSessionToken", "RemoteException during ICustomTabsCallback transaction");
        return;
      } 
    }
    
    public void onNavigationEvent(int param1Int, Bundle param1Bundle) {
      try {
        this.b.a.y0(param1Int, param1Bundle);
        return;
      } catch (RemoteException remoteException) {
        Log.e("CustomTabsSessionToken", "RemoteException during ICustomTabsCallback transaction");
        return;
      } 
    }
    
    public void onPostMessage(String param1String, Bundle param1Bundle) {
      try {
        this.b.a.J0(param1String, param1Bundle);
        return;
      } catch (RemoteException remoteException) {
        Log.e("CustomTabsSessionToken", "RemoteException during ICustomTabsCallback transaction");
        return;
      } 
    }
    
    public void onRelationshipValidationResult(int param1Int, Uri param1Uri, boolean param1Boolean, Bundle param1Bundle) {
      try {
        this.b.a.Q0(param1Int, param1Uri, param1Boolean, param1Bundle);
        return;
      } catch (RemoteException remoteException) {
        Log.e("CustomTabsSessionToken", "RemoteException during ICustomTabsCallback transaction");
        return;
      } 
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Cricket Scorer-dex2jar.jar!\androidx\browser\customtabs\h.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */