package androidx.browser.customtabs;

import android.os.Bundle;

public final class a {
  public final Integer a;
  
  public final Integer b;
  
  public final Integer c;
  
  public final Integer d;
  
  a(Integer paramInteger1, Integer paramInteger2, Integer paramInteger3, Integer paramInteger4) {
    this.a = paramInteger1;
    this.b = paramInteger2;
    this.c = paramInteger3;
    this.d = paramInteger4;
  }
  
  Bundle a() {
    Bundle bundle = new Bundle();
    Integer integer = this.a;
    if (integer != null)
      bundle.putInt("android.support.customtabs.extra.TOOLBAR_COLOR", integer.intValue()); 
    integer = this.b;
    if (integer != null)
      bundle.putInt("android.support.customtabs.extra.SECONDARY_TOOLBAR_COLOR", integer.intValue()); 
    integer = this.c;
    if (integer != null)
      bundle.putInt("androidx.browser.customtabs.extra.NAVIGATION_BAR_COLOR", integer.intValue()); 
    integer = this.d;
    if (integer != null)
      bundle.putInt("androidx.browser.customtabs.extra.NAVIGATION_BAR_DIVIDER_COLOR", integer.intValue()); 
    return bundle;
  }
  
  public static final class a {
    private Integer a;
    
    private Integer b;
    
    private Integer c;
    
    private Integer d;
    
    public a a() {
      return new a(this.a, this.b, this.c, this.d);
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Cricket Scorer-dex2jar.jar!\androidx\browser\customtabs\a.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */