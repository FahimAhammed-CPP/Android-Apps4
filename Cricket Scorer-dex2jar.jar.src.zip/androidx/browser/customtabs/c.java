package androidx.browser.customtabs;

import android.app.PendingIntent;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.os.Parcelable;
import android.os.RemoteException;
import android.text.TextUtils;

public class c {
  private final a.b a;
  
  private final ComponentName b;
  
  private final Context c;
  
  c(a.b paramb, ComponentName paramComponentName, Context paramContext) {
    this.a = paramb;
    this.b = paramComponentName;
    this.c = paramContext;
  }
  
  public static boolean a(Context paramContext, String paramString, f paramf) {
    paramf.setApplicationContext(paramContext.getApplicationContext());
    Intent intent = new Intent("android.support.customtabs.action.CustomTabsService");
    if (!TextUtils.isEmpty(paramString))
      intent.setPackage(paramString); 
    return paramContext.bindService(intent, paramf, 33);
  }
  
  private a.a.a b(b paramb) {
    return new a(this, paramb);
  }
  
  private g d(b paramb, PendingIntent paramPendingIntent) {
    a.a.a a = b(paramb);
    if (paramPendingIntent != null)
      try {
        Bundle bundle = new Bundle();
        bundle.putParcelable("android.support.customtabs.extra.SESSION_ID", (Parcelable)paramPendingIntent);
        boolean bool1 = this.a.Y((a.a)a, bundle);
        return !bool1 ? null : new g(this.a, (a.a)a, this.b, paramPendingIntent);
      } catch (RemoteException remoteException) {
        return null;
      }  
    boolean bool = this.a.J((a.a)remoteException);
    return !bool ? null : new g(this.a, (a.a)remoteException, this.b, paramPendingIntent);
  }
  
  public g c(b paramb) {
    return d(paramb, null);
  }
  
  class a extends a.a.a {
    private Handler a = new Handler(Looper.getMainLooper());
    
    a(c this$0, b param1b) {}
    
    public Bundle F(String param1String, Bundle param1Bundle) throws RemoteException {
      b b1 = this.b;
      return (b1 == null) ? null : b1.extraCallbackWithResult(param1String, param1Bundle);
    }
    
    public void J0(String param1String, Bundle param1Bundle) throws RemoteException {
      if (this.b == null)
        return; 
      this.a.post(new d(this, param1String, param1Bundle));
    }
    
    public void O0(Bundle param1Bundle) throws RemoteException {
      if (this.b == null)
        return; 
      this.a.post(new c(this, param1Bundle));
    }
    
    public void Q0(int param1Int, Uri param1Uri, boolean param1Boolean, Bundle param1Bundle) throws RemoteException {
      if (this.b == null)
        return; 
      this.a.post(new e(this, param1Int, param1Uri, param1Boolean, param1Bundle));
    }
    
    public void n0(String param1String, Bundle param1Bundle) throws RemoteException {
      if (this.b == null)
        return; 
      this.a.post(new b(this, param1String, param1Bundle));
    }
    
    public void y0(int param1Int, Bundle param1Bundle) {
      if (this.b == null)
        return; 
      this.a.post(new a(this, param1Int, param1Bundle));
    }
    
    class a implements Runnable {
      a(c.a this$0, int param2Int, Bundle param2Bundle) {}
      
      public void run() {
        this.c.b.onNavigationEvent(this.a, this.b);
      }
    }
    
    class b implements Runnable {
      b(c.a this$0, String param2String, Bundle param2Bundle) {}
      
      public void run() {
        this.c.b.extraCallback(this.a, this.b);
      }
    }
    
    class c implements Runnable {
      c(c.a this$0, Bundle param2Bundle) {}
      
      public void run() {
        this.b.b.onMessageChannelReady(this.a);
      }
    }
    
    class d implements Runnable {
      d(c.a this$0, String param2String, Bundle param2Bundle) {}
      
      public void run() {
        this.c.b.onPostMessage(this.a, this.b);
      }
    }
    
    class e implements Runnable {
      e(c.a this$0, int param2Int, Uri param2Uri, boolean param2Boolean, Bundle param2Bundle) {}
      
      public void run() {
        this.e.b.onRelationshipValidationResult(this.a, this.b, this.c, this.d);
      }
    }
  }
  
  class a implements Runnable {
    a(c this$0, int param1Int, Bundle param1Bundle) {}
    
    public void run() {
      this.c.b.onNavigationEvent(this.a, this.b);
    }
  }
  
  class b implements Runnable {
    b(c this$0, String param1String, Bundle param1Bundle) {}
    
    public void run() {
      this.c.b.extraCallback(this.a, this.b);
    }
  }
  
  class c implements Runnable {
    c(c this$0, Bundle param1Bundle) {}
    
    public void run() {
      this.b.b.onMessageChannelReady(this.a);
    }
  }
  
  class d implements Runnable {
    d(c this$0, String param1String, Bundle param1Bundle) {}
    
    public void run() {
      this.c.b.onPostMessage(this.a, this.b);
    }
  }
  
  class e implements Runnable {
    e(c this$0, int param1Int, Uri param1Uri, boolean param1Boolean, Bundle param1Bundle) {}
    
    public void run() {
      this.e.b.onRelationshipValidationResult(this.a, this.b, this.c, this.d);
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Cricket Scorer-dex2jar.jar!\androidx\browser\customtabs\c.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */