package androidx.browser.customtabs;

import a.b;
import android.app.PendingIntent;
import android.app.Service;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.os.IBinder;
import android.os.RemoteException;
import androidx.collection.g;
import java.util.List;
import java.util.NoSuchElementException;

public abstract class CustomTabsService extends Service {
  public static final String ACTION_CUSTOM_TABS_CONNECTION = "android.support.customtabs.action.CustomTabsService";
  
  public static final String CATEGORY_COLOR_SCHEME_CUSTOMIZATION = "androidx.browser.customtabs.category.ColorSchemeCustomization";
  
  public static final String CATEGORY_NAVBAR_COLOR_CUSTOMIZATION = "androidx.browser.customtabs.category.NavBarColorCustomization";
  
  public static final String CATEGORY_TRUSTED_WEB_ACTIVITY_IMMERSIVE_MODE = "androidx.browser.trusted.category.ImmersiveMode";
  
  public static final String CATEGORY_WEB_SHARE_TARGET_V2 = "androidx.browser.trusted.category.WebShareTargetV2";
  
  public static final int FILE_PURPOSE_TRUSTED_WEB_ACTIVITY_SPLASH_IMAGE = 1;
  
  public static final String KEY_SUCCESS = "androidx.browser.customtabs.SUCCESS";
  
  public static final String KEY_URL = "android.support.customtabs.otherurls.URL";
  
  public static final int RELATION_HANDLE_ALL_URLS = 2;
  
  public static final int RELATION_USE_AS_ORIGIN = 1;
  
  public static final int RESULT_FAILURE_DISALLOWED = -1;
  
  public static final int RESULT_FAILURE_MESSAGING_ERROR = -3;
  
  public static final int RESULT_FAILURE_REMOTE_ERROR = -2;
  
  public static final int RESULT_SUCCESS = 0;
  
  public static final String TRUSTED_WEB_ACTIVITY_CATEGORY = "androidx.browser.trusted.category.TrustedWebActivities";
  
  private b.a mBinder = new a(this);
  
  final g<IBinder, IBinder.DeathRecipient> mDeathRecipientMap = new g();
  
  protected boolean cleanUpSession(h paramh) {
    try {
      synchronized (this.mDeathRecipientMap) {
        IBinder iBinder = paramh.a();
        if (iBinder == null)
          return false; 
        iBinder.unlinkToDeath((IBinder.DeathRecipient)this.mDeathRecipientMap.get(iBinder), 0);
        this.mDeathRecipientMap.remove(iBinder);
        return true;
      } 
    } catch (NoSuchElementException noSuchElementException) {
      return false;
    } 
  }
  
  protected abstract Bundle extraCommand(String paramString, Bundle paramBundle);
  
  protected abstract boolean mayLaunchUrl(h paramh, Uri paramUri, Bundle paramBundle, List<Bundle> paramList);
  
  protected abstract boolean newSession(h paramh);
  
  public IBinder onBind(Intent paramIntent) {
    return (IBinder)this.mBinder;
  }
  
  protected abstract int postMessage(h paramh, String paramString, Bundle paramBundle);
  
  protected abstract boolean receiveFile(h paramh, Uri paramUri, int paramInt, Bundle paramBundle);
  
  protected abstract boolean requestPostMessageChannel(h paramh, Uri paramUri);
  
  protected abstract boolean updateVisuals(h paramh, Bundle paramBundle);
  
  protected abstract boolean validateRelationship(h paramh, int paramInt, Uri paramUri, Bundle paramBundle);
  
  protected abstract boolean warmup(long paramLong);
  
  class a extends b.a {
    a(CustomTabsService this$0) {}
    
    private PendingIntent b1(Bundle param1Bundle) {
      if (param1Bundle == null)
        return null; 
      PendingIntent pendingIntent = (PendingIntent)param1Bundle.getParcelable("android.support.customtabs.extra.SESSION_ID");
      param1Bundle.remove("android.support.customtabs.extra.SESSION_ID");
      return pendingIntent;
    }
    
    private boolean d1(a.a param1a, PendingIntent param1PendingIntent) {
      h h = new h(param1a, param1PendingIntent);
      try {
        e e = new e(this, h);
        synchronized (this.a.mDeathRecipientMap) {
          param1a.asBinder().linkToDeath(e, 0);
          this.a.mDeathRecipientMap.put(param1a.asBinder(), e);
          return this.a.newSession(h);
        } 
      } catch (RemoteException remoteException) {
        return false;
      } 
    }
    
    public int C0(a.a param1a, String param1String, Bundle param1Bundle) {
      return this.a.postMessage(new h(param1a, b1(param1Bundle)), param1String, param1Bundle);
    }
    
    public Bundle H(String param1String, Bundle param1Bundle) {
      return this.a.extraCommand(param1String, param1Bundle);
    }
    
    public boolean I0(a.a param1a, Uri param1Uri, Bundle param1Bundle) {
      return this.a.requestPostMessageChannel(new h(param1a, b1(param1Bundle)), param1Uri);
    }
    
    public boolean J(a.a param1a) {
      return d1(param1a, null);
    }
    
    public boolean K0(a.a param1a, Uri param1Uri, int param1Int, Bundle param1Bundle) {
      return this.a.receiveFile(new h(param1a, b1(param1Bundle)), param1Uri, param1Int, param1Bundle);
    }
    
    public boolean U(long param1Long) {
      return this.a.warmup(param1Long);
    }
    
    public boolean U0(a.a param1a, Bundle param1Bundle) {
      return this.a.updateVisuals(new h(param1a, b1(param1Bundle)), param1Bundle);
    }
    
    public boolean V0(a.a param1a, int param1Int, Uri param1Uri, Bundle param1Bundle) {
      return this.a.validateRelationship(new h(param1a, b1(param1Bundle)), param1Int, param1Uri, param1Bundle);
    }
    
    public boolean Y(a.a param1a, Bundle param1Bundle) {
      return d1(param1a, b1(param1Bundle));
    }
    
    public boolean o(a.a param1a, Uri param1Uri) {
      return this.a.requestPostMessageChannel(new h(param1a, null), param1Uri);
    }
    
    public boolean p0(a.a param1a, Uri param1Uri, Bundle param1Bundle, List<Bundle> param1List) {
      return this.a.mayLaunchUrl(new h(param1a, b1(param1Bundle)), param1Uri, param1Bundle, param1List);
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Cricket Scorer-dex2jar.jar!\androidx\browser\customtabs\CustomTabsService.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */