package androidx.browser.customtabs;

import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.os.IBinder;
import android.os.Parcelable;
import android.util.SparseArray;
import androidx.core.app.n;
import java.util.ArrayList;

public final class d {
  public final Intent a;
  
  public final Bundle b;
  
  d(Intent paramIntent, Bundle paramBundle) {
    this.a = paramIntent;
    this.b = paramBundle;
  }
  
  public void a(Context paramContext, Uri paramUri) {
    this.a.setData(paramUri);
    androidx.core.content.a.startActivity(paramContext, this.a, this.b);
  }
  
  public static final class a {
    private final Intent a = new Intent("android.intent.action.VIEW");
    
    private final a.a b = new a.a();
    
    private ArrayList<Bundle> c;
    
    private Bundle d;
    
    private ArrayList<Bundle> e;
    
    private SparseArray<Bundle> f;
    
    private Bundle g;
    
    private int h = 0;
    
    private boolean i = true;
    
    public a() {}
    
    public a(g param1g) {
      if (param1g != null)
        c(param1g); 
    }
    
    private void d(IBinder param1IBinder, PendingIntent param1PendingIntent) {
      Bundle bundle = new Bundle();
      n.b(bundle, "android.support.customtabs.extra.SESSION", param1IBinder);
      if (param1PendingIntent != null)
        bundle.putParcelable("android.support.customtabs.extra.SESSION_ID", (Parcelable)param1PendingIntent); 
      this.a.putExtras(bundle);
    }
    
    public d a() {
      if (!this.a.hasExtra("android.support.customtabs.extra.SESSION"))
        d(null, null); 
      ArrayList<Bundle> arrayList = this.c;
      if (arrayList != null)
        this.a.putParcelableArrayListExtra("android.support.customtabs.extra.MENU_ITEMS", arrayList); 
      arrayList = this.e;
      if (arrayList != null)
        this.a.putParcelableArrayListExtra("android.support.customtabs.extra.TOOLBAR_ITEMS", arrayList); 
      this.a.putExtra("android.support.customtabs.extra.EXTRA_ENABLE_INSTANT_APPS", this.i);
      this.a.putExtras(this.b.a().a());
      Bundle bundle = this.g;
      if (bundle != null)
        this.a.putExtras(bundle); 
      if (this.f != null) {
        bundle = new Bundle();
        bundle.putSparseParcelableArray("androidx.browser.customtabs.extra.COLOR_SCHEME_PARAMS", this.f);
        this.a.putExtras(bundle);
      } 
      this.a.putExtra("androidx.browser.customtabs.extra.SHARE_STATE", this.h);
      return new d(this.a, this.d);
    }
    
    @Deprecated
    public a b() {
      this.a.putExtra("android.support.customtabs.extra.ENABLE_URLBAR_HIDING", true);
      return this;
    }
    
    public a c(g param1g) {
      this.a.setPackage(param1g.b().getPackageName());
      d(param1g.a(), param1g.c());
      return this;
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Cricket Scorer-dex2jar.jar!\androidx\browser\customtabs\d.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */