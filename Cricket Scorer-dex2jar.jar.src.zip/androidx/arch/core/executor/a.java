package androidx.arch.core.executor;

import java.util.concurrent.Executor;

public class a extends d {
  private static volatile a c;
  
  private static final Executor d = new a();
  
  private static final Executor e = new b();
  
  private d a;
  
  private d b;
  
  private a() {
    c c = new c();
    this.b = c;
    this.a = c;
  }
  
  public static Executor d() {
    return e;
  }
  
  public static a e() {
    // Byte code:
    //   0: getstatic androidx/arch/core/executor/a.c : Landroidx/arch/core/executor/a;
    //   3: ifnull -> 10
    //   6: getstatic androidx/arch/core/executor/a.c : Landroidx/arch/core/executor/a;
    //   9: areturn
    //   10: ldc androidx/arch/core/executor/a
    //   12: monitorenter
    //   13: getstatic androidx/arch/core/executor/a.c : Landroidx/arch/core/executor/a;
    //   16: ifnonnull -> 29
    //   19: new androidx/arch/core/executor/a
    //   22: dup
    //   23: invokespecial <init> : ()V
    //   26: putstatic androidx/arch/core/executor/a.c : Landroidx/arch/core/executor/a;
    //   29: ldc androidx/arch/core/executor/a
    //   31: monitorexit
    //   32: getstatic androidx/arch/core/executor/a.c : Landroidx/arch/core/executor/a;
    //   35: areturn
    //   36: astore_0
    //   37: ldc androidx/arch/core/executor/a
    //   39: monitorexit
    //   40: aload_0
    //   41: athrow
    // Exception table:
    //   from	to	target	type
    //   13	29	36	finally
    //   29	32	36	finally
    //   37	40	36	finally
  }
  
  public void a(Runnable paramRunnable) {
    this.a.a(paramRunnable);
  }
  
  public boolean b() {
    return this.a.b();
  }
  
  public void c(Runnable paramRunnable) {
    this.a.c(paramRunnable);
  }
  
  static final class a implements Executor {
    public void execute(Runnable param1Runnable) {
      a.e().c(param1Runnable);
    }
  }
  
  static final class b implements Executor {
    public void execute(Runnable param1Runnable) {
      a.e().a(param1Runnable);
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Cricket Scorer-dex2jar.jar!\androidx\arch\core\executor\a.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */