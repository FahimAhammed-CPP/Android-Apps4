package androidx.appcompat.widget;

import android.content.Context;
import android.content.res.ColorStateList;
import android.graphics.PorterDuff;
import android.graphics.drawable.Drawable;
import android.os.Build;
import android.util.AttributeSet;
import android.view.View;
import android.widget.ImageView;
import androidx.core.view.o0;
import androidx.core.widget.i;
import e.j;
import f.a;

public class l {
  private final ImageView a;
  
  private a2 b;
  
  private a2 c;
  
  private a2 d;
  
  private int e = 0;
  
  public l(ImageView paramImageView) {
    this.a = paramImageView;
  }
  
  private boolean a(Drawable paramDrawable) {
    if (this.d == null)
      this.d = new a2(); 
    a2 a21 = this.d;
    a21.a();
    ColorStateList colorStateList = i.a(this.a);
    if (colorStateList != null) {
      a21.d = true;
      a21.a = colorStateList;
    } 
    PorterDuff.Mode mode = i.b(this.a);
    if (mode != null) {
      a21.c = true;
      a21.b = mode;
    } 
    if (a21.d || a21.c) {
      h.i(paramDrawable, a21, this.a.getDrawableState());
      return true;
    } 
    return false;
  }
  
  private boolean l() {
    int i = Build.VERSION.SDK_INT;
    return (i > 21) ? ((this.b != null)) : ((i == 21));
  }
  
  void b() {
    if (this.a.getDrawable() != null)
      this.a.getDrawable().setLevel(this.e); 
  }
  
  void c() {
    Drawable drawable = this.a.getDrawable();
    if (drawable != null)
      d1.b(drawable); 
    if (drawable != null) {
      if (l() && a(drawable))
        return; 
      a2 a21 = this.c;
      if (a21 != null) {
        h.i(drawable, a21, this.a.getDrawableState());
        return;
      } 
      a21 = this.b;
      if (a21 != null)
        h.i(drawable, a21, this.a.getDrawableState()); 
    } 
  }
  
  ColorStateList d() {
    a2 a21 = this.c;
    return (a21 != null) ? a21.a : null;
  }
  
  PorterDuff.Mode e() {
    a2 a21 = this.c;
    return (a21 != null) ? a21.b : null;
  }
  
  boolean f() {
    return !(this.a.getBackground() instanceof android.graphics.drawable.RippleDrawable);
  }
  
  public void g(AttributeSet paramAttributeSet, int paramInt) {
    Context context = this.a.getContext();
    int[] arrayOfInt = j.P;
    c2 c2 = c2.v(context, paramAttributeSet, arrayOfInt, paramInt, 0);
    ImageView imageView = this.a;
    o0.p0((View)imageView, imageView.getContext(), arrayOfInt, paramAttributeSet, c2.r(), paramInt, 0);
    try {
      Drawable drawable2 = this.a.getDrawable();
      Drawable drawable1 = drawable2;
      if (drawable2 == null) {
        paramInt = c2.n(j.Q, -1);
        drawable1 = drawable2;
        if (paramInt != -1) {
          drawable2 = a.b(this.a.getContext(), paramInt);
          drawable1 = drawable2;
          if (drawable2 != null) {
            this.a.setImageDrawable(drawable2);
            drawable1 = drawable2;
          } 
        } 
      } 
      if (drawable1 != null)
        d1.b(drawable1); 
      paramInt = j.R;
      if (c2.s(paramInt))
        i.c(this.a, c2.c(paramInt)); 
      paramInt = j.S;
      if (c2.s(paramInt))
        i.d(this.a, d1.e(c2.k(paramInt, -1), null)); 
      return;
    } finally {
      c2.w();
    } 
  }
  
  void h(Drawable paramDrawable) {
    this.e = paramDrawable.getLevel();
  }
  
  public void i(int paramInt) {
    if (paramInt != 0) {
      Drawable drawable = a.b(this.a.getContext(), paramInt);
      if (drawable != null)
        d1.b(drawable); 
      this.a.setImageDrawable(drawable);
    } else {
      this.a.setImageDrawable(null);
    } 
    c();
  }
  
  void j(ColorStateList paramColorStateList) {
    if (this.c == null)
      this.c = new a2(); 
    a2 a21 = this.c;
    a21.a = paramColorStateList;
    a21.d = true;
    c();
  }
  
  void k(PorterDuff.Mode paramMode) {
    if (this.c == null)
      this.c = new a2(); 
    a2 a21 = this.c;
    a21.b = paramMode;
    a21.c = true;
    c();
  }
}


/* Location:              C:\soft\dex2jar-2.0\Cricket Scorer-dex2jar.jar!\androidx\appcompat\widget\l.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */