package androidx.appcompat.widget;

import android.content.Context;
import android.content.res.ColorStateList;
import android.graphics.PorterDuff;
import android.graphics.Typeface;
import android.graphics.drawable.Drawable;
import android.os.Build;
import android.text.InputFilter;
import android.util.AttributeSet;
import android.view.ActionMode;
import android.view.View;
import android.view.inputmethod.EditorInfo;
import android.view.inputmethod.InputConnection;
import android.view.textclassifier.TextClassifier;
import android.widget.TextView;
import androidx.core.graphics.f;
import androidx.core.text.d;
import androidx.core.widget.b;
import androidx.core.widget.d0;
import androidx.core.widget.r;
import f.a;
import java.util.concurrent.Future;

public class AppCompatTextView extends TextView implements d0, b {
  private final d a;
  
  private final o0 b;
  
  private final n0 c;
  
  private j d;
  
  private boolean e = false;
  
  private Future<d> f;
  
  public AppCompatTextView(Context paramContext) {
    this(paramContext, null);
  }
  
  public AppCompatTextView(Context paramContext, AttributeSet paramAttributeSet) {
    this(paramContext, paramAttributeSet, 16842884);
  }
  
  public AppCompatTextView(Context paramContext, AttributeSet paramAttributeSet, int paramInt) {
    super(z1.b(paramContext), paramAttributeSet, paramInt);
    x1.a((View)this, getContext());
    d d1 = new d((View)this);
    this.a = d1;
    d1.e(paramAttributeSet, paramInt);
    o0 o01 = new o0(this);
    this.b = o01;
    o01.m(paramAttributeSet, paramInt);
    o01.b();
    this.c = new n0(this);
    getEmojiTextViewHelper().c(paramAttributeSet, paramInt);
  }
  
  private void e() {
    Future<d> future = this.f;
    if (future != null)
      try {
        this.f = null;
        r.n(this, future.get());
        return;
      } catch (InterruptedException|java.util.concurrent.ExecutionException interruptedException) {
        return;
      }  
  }
  
  private j getEmojiTextViewHelper() {
    if (this.d == null)
      this.d = new j(this); 
    return this.d;
  }
  
  protected void drawableStateChanged() {
    super.drawableStateChanged();
    d d1 = this.a;
    if (d1 != null)
      d1.b(); 
    o0 o01 = this.b;
    if (o01 != null)
      o01.b(); 
  }
  
  public int getAutoSizeMaxTextSize() {
    if (b.a0)
      return super.getAutoSizeMaxTextSize(); 
    o0 o01 = this.b;
    return (o01 != null) ? o01.e() : -1;
  }
  
  public int getAutoSizeMinTextSize() {
    if (b.a0)
      return super.getAutoSizeMinTextSize(); 
    o0 o01 = this.b;
    return (o01 != null) ? o01.f() : -1;
  }
  
  public int getAutoSizeStepGranularity() {
    if (b.a0)
      return super.getAutoSizeStepGranularity(); 
    o0 o01 = this.b;
    return (o01 != null) ? o01.g() : -1;
  }
  
  public int[] getAutoSizeTextAvailableSizes() {
    if (b.a0)
      return super.getAutoSizeTextAvailableSizes(); 
    o0 o01 = this.b;
    return (o01 != null) ? o01.h() : new int[0];
  }
  
  public int getAutoSizeTextType() {
    boolean bool1 = b.a0;
    boolean bool = false;
    if (bool1) {
      if (super.getAutoSizeTextType() == 1)
        bool = true; 
      return bool;
    } 
    o0 o01 = this.b;
    return (o01 != null) ? o01.i() : 0;
  }
  
  public ActionMode.Callback getCustomSelectionActionModeCallback() {
    return r.q(super.getCustomSelectionActionModeCallback());
  }
  
  public int getFirstBaselineToTopHeight() {
    return r.b(this);
  }
  
  public int getLastBaselineToBottomHeight() {
    return r.c(this);
  }
  
  public ColorStateList getSupportBackgroundTintList() {
    d d1 = this.a;
    return (d1 != null) ? d1.c() : null;
  }
  
  public PorterDuff.Mode getSupportBackgroundTintMode() {
    d d1 = this.a;
    return (d1 != null) ? d1.d() : null;
  }
  
  public ColorStateList getSupportCompoundDrawablesTintList() {
    return this.b.j();
  }
  
  public PorterDuff.Mode getSupportCompoundDrawablesTintMode() {
    return this.b.k();
  }
  
  public CharSequence getText() {
    e();
    return super.getText();
  }
  
  public TextClassifier getTextClassifier() {
    if (Build.VERSION.SDK_INT < 28) {
      n0 n01 = this.c;
      if (n01 != null)
        return n01.a(); 
    } 
    return super.getTextClassifier();
  }
  
  public d.a getTextMetricsParamsCompat() {
    return r.g(this);
  }
  
  public InputConnection onCreateInputConnection(EditorInfo paramEditorInfo) {
    InputConnection inputConnection = super.onCreateInputConnection(paramEditorInfo);
    this.b.r(this, inputConnection, paramEditorInfo);
    return k.a(inputConnection, paramEditorInfo, (View)this);
  }
  
  protected void onLayout(boolean paramBoolean, int paramInt1, int paramInt2, int paramInt3, int paramInt4) {
    super.onLayout(paramBoolean, paramInt1, paramInt2, paramInt3, paramInt4);
    o0 o01 = this.b;
    if (o01 != null)
      o01.o(paramBoolean, paramInt1, paramInt2, paramInt3, paramInt4); 
  }
  
  protected void onMeasure(int paramInt1, int paramInt2) {
    e();
    super.onMeasure(paramInt1, paramInt2);
  }
  
  protected void onTextChanged(CharSequence paramCharSequence, int paramInt1, int paramInt2, int paramInt3) {
    super.onTextChanged(paramCharSequence, paramInt1, paramInt2, paramInt3);
    o0 o01 = this.b;
    if (o01 != null && !b.a0 && o01.l())
      this.b.c(); 
  }
  
  public void setAllCaps(boolean paramBoolean) {
    super.setAllCaps(paramBoolean);
    getEmojiTextViewHelper().d(paramBoolean);
  }
  
  public void setAutoSizeTextTypeUniformWithConfiguration(int paramInt1, int paramInt2, int paramInt3, int paramInt4) throws IllegalArgumentException {
    if (b.a0) {
      super.setAutoSizeTextTypeUniformWithConfiguration(paramInt1, paramInt2, paramInt3, paramInt4);
      return;
    } 
    o0 o01 = this.b;
    if (o01 != null)
      o01.t(paramInt1, paramInt2, paramInt3, paramInt4); 
  }
  
  public void setAutoSizeTextTypeUniformWithPresetSizes(int[] paramArrayOfint, int paramInt) throws IllegalArgumentException {
    if (b.a0) {
      super.setAutoSizeTextTypeUniformWithPresetSizes(paramArrayOfint, paramInt);
      return;
    } 
    o0 o01 = this.b;
    if (o01 != null)
      o01.u(paramArrayOfint, paramInt); 
  }
  
  public void setAutoSizeTextTypeWithDefaults(int paramInt) {
    if (b.a0) {
      super.setAutoSizeTextTypeWithDefaults(paramInt);
      return;
    } 
    o0 o01 = this.b;
    if (o01 != null)
      o01.v(paramInt); 
  }
  
  public void setBackgroundDrawable(Drawable paramDrawable) {
    super.setBackgroundDrawable(paramDrawable);
    d d1 = this.a;
    if (d1 != null)
      d1.f(paramDrawable); 
  }
  
  public void setBackgroundResource(int paramInt) {
    super.setBackgroundResource(paramInt);
    d d1 = this.a;
    if (d1 != null)
      d1.g(paramInt); 
  }
  
  public void setCompoundDrawables(Drawable paramDrawable1, Drawable paramDrawable2, Drawable paramDrawable3, Drawable paramDrawable4) {
    super.setCompoundDrawables(paramDrawable1, paramDrawable2, paramDrawable3, paramDrawable4);
    o0 o01 = this.b;
    if (o01 != null)
      o01.p(); 
  }
  
  public void setCompoundDrawablesRelative(Drawable paramDrawable1, Drawable paramDrawable2, Drawable paramDrawable3, Drawable paramDrawable4) {
    super.setCompoundDrawablesRelative(paramDrawable1, paramDrawable2, paramDrawable3, paramDrawable4);
    o0 o01 = this.b;
    if (o01 != null)
      o01.p(); 
  }
  
  public void setCompoundDrawablesRelativeWithIntrinsicBounds(int paramInt1, int paramInt2, int paramInt3, int paramInt4) {
    Drawable drawable1;
    Drawable drawable2;
    Drawable drawable3;
    Context context = getContext();
    Drawable drawable4 = null;
    if (paramInt1 != 0) {
      drawable1 = a.b(context, paramInt1);
    } else {
      drawable1 = null;
    } 
    if (paramInt2 != 0) {
      drawable2 = a.b(context, paramInt2);
    } else {
      drawable2 = null;
    } 
    if (paramInt3 != 0) {
      drawable3 = a.b(context, paramInt3);
    } else {
      drawable3 = null;
    } 
    if (paramInt4 != 0)
      drawable4 = a.b(context, paramInt4); 
    setCompoundDrawablesRelativeWithIntrinsicBounds(drawable1, drawable2, drawable3, drawable4);
    o0 o01 = this.b;
    if (o01 != null)
      o01.p(); 
  }
  
  public void setCompoundDrawablesRelativeWithIntrinsicBounds(Drawable paramDrawable1, Drawable paramDrawable2, Drawable paramDrawable3, Drawable paramDrawable4) {
    super.setCompoundDrawablesRelativeWithIntrinsicBounds(paramDrawable1, paramDrawable2, paramDrawable3, paramDrawable4);
    o0 o01 = this.b;
    if (o01 != null)
      o01.p(); 
  }
  
  public void setCompoundDrawablesWithIntrinsicBounds(int paramInt1, int paramInt2, int paramInt3, int paramInt4) {
    Drawable drawable1;
    Drawable drawable2;
    Drawable drawable3;
    Context context = getContext();
    Drawable drawable4 = null;
    if (paramInt1 != 0) {
      drawable1 = a.b(context, paramInt1);
    } else {
      drawable1 = null;
    } 
    if (paramInt2 != 0) {
      drawable2 = a.b(context, paramInt2);
    } else {
      drawable2 = null;
    } 
    if (paramInt3 != 0) {
      drawable3 = a.b(context, paramInt3);
    } else {
      drawable3 = null;
    } 
    if (paramInt4 != 0)
      drawable4 = a.b(context, paramInt4); 
    setCompoundDrawablesWithIntrinsicBounds(drawable1, drawable2, drawable3, drawable4);
    o0 o01 = this.b;
    if (o01 != null)
      o01.p(); 
  }
  
  public void setCompoundDrawablesWithIntrinsicBounds(Drawable paramDrawable1, Drawable paramDrawable2, Drawable paramDrawable3, Drawable paramDrawable4) {
    super.setCompoundDrawablesWithIntrinsicBounds(paramDrawable1, paramDrawable2, paramDrawable3, paramDrawable4);
    o0 o01 = this.b;
    if (o01 != null)
      o01.p(); 
  }
  
  public void setCustomSelectionActionModeCallback(ActionMode.Callback paramCallback) {
    super.setCustomSelectionActionModeCallback(r.r(this, paramCallback));
  }
  
  public void setEmojiCompatEnabled(boolean paramBoolean) {
    getEmojiTextViewHelper().e(paramBoolean);
  }
  
  public void setFilters(InputFilter[] paramArrayOfInputFilter) {
    super.setFilters(getEmojiTextViewHelper().a(paramArrayOfInputFilter));
  }
  
  public void setFirstBaselineToTopHeight(int paramInt) {
    if (Build.VERSION.SDK_INT >= 28) {
      super.setFirstBaselineToTopHeight(paramInt);
      return;
    } 
    r.k(this, paramInt);
  }
  
  public void setLastBaselineToBottomHeight(int paramInt) {
    if (Build.VERSION.SDK_INT >= 28) {
      super.setLastBaselineToBottomHeight(paramInt);
      return;
    } 
    r.l(this, paramInt);
  }
  
  public void setLineHeight(int paramInt) {
    r.m(this, paramInt);
  }
  
  public void setPrecomputedText(d paramd) {
    r.n(this, paramd);
  }
  
  public void setSupportBackgroundTintList(ColorStateList paramColorStateList) {
    d d1 = this.a;
    if (d1 != null)
      d1.i(paramColorStateList); 
  }
  
  public void setSupportBackgroundTintMode(PorterDuff.Mode paramMode) {
    d d1 = this.a;
    if (d1 != null)
      d1.j(paramMode); 
  }
  
  public void setSupportCompoundDrawablesTintList(ColorStateList paramColorStateList) {
    this.b.w(paramColorStateList);
    this.b.b();
  }
  
  public void setSupportCompoundDrawablesTintMode(PorterDuff.Mode paramMode) {
    this.b.x(paramMode);
    this.b.b();
  }
  
  public void setTextAppearance(Context paramContext, int paramInt) {
    super.setTextAppearance(paramContext, paramInt);
    o0 o01 = this.b;
    if (o01 != null)
      o01.q(paramContext, paramInt); 
  }
  
  public void setTextClassifier(TextClassifier paramTextClassifier) {
    if (Build.VERSION.SDK_INT < 28) {
      n0 n01 = this.c;
      if (n01 != null) {
        n01.b(paramTextClassifier);
        return;
      } 
    } 
    super.setTextClassifier(paramTextClassifier);
  }
  
  public void setTextFuture(Future<d> paramFuture) {
    this.f = paramFuture;
    if (paramFuture != null)
      requestLayout(); 
  }
  
  public void setTextMetricsParamsCompat(d.a parama) {
    r.p(this, parama);
  }
  
  public void setTextSize(int paramInt, float paramFloat) {
    if (b.a0) {
      super.setTextSize(paramInt, paramFloat);
      return;
    } 
    o0 o01 = this.b;
    if (o01 != null)
      o01.A(paramInt, paramFloat); 
  }
  
  public void setTypeface(Typeface paramTypeface, int paramInt) {
    if (this.e)
      return; 
    Typeface typeface2 = null;
    Typeface typeface1 = typeface2;
    if (paramTypeface != null) {
      typeface1 = typeface2;
      if (paramInt > 0)
        typeface1 = f.a(getContext(), paramTypeface, paramInt); 
    } 
    this.e = true;
    if (typeface1 != null)
      paramTypeface = typeface1; 
    try {
      super.setTypeface(paramTypeface, paramInt);
      return;
    } finally {
      this.e = false;
    } 
  }
}


/* Location:              C:\soft\dex2jar-2.0\Cricket Scorer-dex2jar.jar!\androidx\appcompat\widget\AppCompatTextView.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */