package androidx.appcompat.widget;

import android.content.Context;
import android.content.res.ColorStateList;
import android.graphics.PorterDuff;
import android.graphics.drawable.Drawable;
import android.os.Build;
import android.util.AttributeSet;
import android.view.View;
import androidx.core.view.o0;
import e.j;

class d {
  private final View a;
  
  private final h b;
  
  private int c = -1;
  
  private a2 d;
  
  private a2 e;
  
  private a2 f;
  
  d(View paramView) {
    this.a = paramView;
    this.b = h.b();
  }
  
  private boolean a(Drawable paramDrawable) {
    if (this.f == null)
      this.f = new a2(); 
    a2 a21 = this.f;
    a21.a();
    ColorStateList colorStateList = o0.u(this.a);
    if (colorStateList != null) {
      a21.d = true;
      a21.a = colorStateList;
    } 
    PorterDuff.Mode mode = o0.v(this.a);
    if (mode != null) {
      a21.c = true;
      a21.b = mode;
    } 
    if (a21.d || a21.c) {
      h.i(paramDrawable, a21, this.a.getDrawableState());
      return true;
    } 
    return false;
  }
  
  private boolean k() {
    int i = Build.VERSION.SDK_INT;
    return (i > 21) ? ((this.d != null)) : ((i == 21));
  }
  
  void b() {
    Drawable drawable = this.a.getBackground();
    if (drawable != null) {
      if (k() && a(drawable))
        return; 
      a2 a21 = this.e;
      if (a21 != null) {
        h.i(drawable, a21, this.a.getDrawableState());
        return;
      } 
      a21 = this.d;
      if (a21 != null)
        h.i(drawable, a21, this.a.getDrawableState()); 
    } 
  }
  
  ColorStateList c() {
    a2 a21 = this.e;
    return (a21 != null) ? a21.a : null;
  }
  
  PorterDuff.Mode d() {
    a2 a21 = this.e;
    return (a21 != null) ? a21.b : null;
  }
  
  void e(AttributeSet paramAttributeSet, int paramInt) {
    Context context = this.a.getContext();
    int[] arrayOfInt = j.U3;
    c2 c2 = c2.v(context, paramAttributeSet, arrayOfInt, paramInt, 0);
    View view = this.a;
    o0.p0(view, view.getContext(), arrayOfInt, paramAttributeSet, c2.r(), paramInt, 0);
    try {
      paramInt = j.V3;
      if (c2.s(paramInt)) {
        this.c = c2.n(paramInt, -1);
        ColorStateList colorStateList = this.b.f(this.a.getContext(), this.c);
        if (colorStateList != null)
          h(colorStateList); 
      } 
      paramInt = j.W3;
      if (c2.s(paramInt))
        o0.w0(this.a, c2.c(paramInt)); 
      paramInt = j.X3;
      if (c2.s(paramInt))
        o0.x0(this.a, d1.e(c2.k(paramInt, -1), null)); 
      return;
    } finally {
      c2.w();
    } 
  }
  
  void f(Drawable paramDrawable) {
    this.c = -1;
    h(null);
    b();
  }
  
  void g(int paramInt) {
    this.c = paramInt;
    h h1 = this.b;
    if (h1 != null) {
      ColorStateList colorStateList = h1.f(this.a.getContext(), paramInt);
    } else {
      h1 = null;
    } 
    h((ColorStateList)h1);
    b();
  }
  
  void h(ColorStateList paramColorStateList) {
    if (paramColorStateList != null) {
      if (this.d == null)
        this.d = new a2(); 
      a2 a21 = this.d;
      a21.a = paramColorStateList;
      a21.d = true;
    } else {
      this.d = null;
    } 
    b();
  }
  
  void i(ColorStateList paramColorStateList) {
    if (this.e == null)
      this.e = new a2(); 
    a2 a21 = this.e;
    a21.a = paramColorStateList;
    a21.d = true;
    b();
  }
  
  void j(PorterDuff.Mode paramMode) {
    if (this.e == null)
      this.e = new a2(); 
    a2 a21 = this.e;
    a21.b = paramMode;
    a21.c = true;
    b();
  }
}


/* Location:              C:\soft\dex2jar-2.0\Cricket Scorer-dex2jar.jar!\androidx\appcompat\widget\d.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */