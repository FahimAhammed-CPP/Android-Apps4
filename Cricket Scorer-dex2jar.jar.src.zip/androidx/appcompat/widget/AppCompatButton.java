package androidx.appcompat.widget;

import android.content.Context;
import android.content.res.ColorStateList;
import android.graphics.PorterDuff;
import android.graphics.drawable.Drawable;
import android.text.InputFilter;
import android.util.AttributeSet;
import android.view.ActionMode;
import android.view.View;
import android.view.accessibility.AccessibilityEvent;
import android.view.accessibility.AccessibilityNodeInfo;
import android.widget.Button;
import android.widget.TextView;
import androidx.core.widget.b;
import androidx.core.widget.d0;
import androidx.core.widget.r;
import e.a;

public class AppCompatButton extends Button implements b, d0 {
  private final d a;
  
  private final o0 b;
  
  private j c;
  
  public AppCompatButton(Context paramContext, AttributeSet paramAttributeSet) {
    this(paramContext, paramAttributeSet, a.q);
  }
  
  public AppCompatButton(Context paramContext, AttributeSet paramAttributeSet, int paramInt) {
    super(z1.b(paramContext), paramAttributeSet, paramInt);
    x1.a((View)this, getContext());
    d d1 = new d((View)this);
    this.a = d1;
    d1.e(paramAttributeSet, paramInt);
    o0 o01 = new o0((TextView)this);
    this.b = o01;
    o01.m(paramAttributeSet, paramInt);
    o01.b();
    getEmojiTextViewHelper().c(paramAttributeSet, paramInt);
  }
  
  private j getEmojiTextViewHelper() {
    if (this.c == null)
      this.c = new j((TextView)this); 
    return this.c;
  }
  
  protected void drawableStateChanged() {
    super.drawableStateChanged();
    d d1 = this.a;
    if (d1 != null)
      d1.b(); 
    o0 o01 = this.b;
    if (o01 != null)
      o01.b(); 
  }
  
  public int getAutoSizeMaxTextSize() {
    if (b.a0)
      return super.getAutoSizeMaxTextSize(); 
    o0 o01 = this.b;
    return (o01 != null) ? o01.e() : -1;
  }
  
  public int getAutoSizeMinTextSize() {
    if (b.a0)
      return super.getAutoSizeMinTextSize(); 
    o0 o01 = this.b;
    return (o01 != null) ? o01.f() : -1;
  }
  
  public int getAutoSizeStepGranularity() {
    if (b.a0)
      return super.getAutoSizeStepGranularity(); 
    o0 o01 = this.b;
    return (o01 != null) ? o01.g() : -1;
  }
  
  public int[] getAutoSizeTextAvailableSizes() {
    if (b.a0)
      return super.getAutoSizeTextAvailableSizes(); 
    o0 o01 = this.b;
    return (o01 != null) ? o01.h() : new int[0];
  }
  
  public int getAutoSizeTextType() {
    boolean bool1 = b.a0;
    boolean bool = false;
    if (bool1) {
      if (super.getAutoSizeTextType() == 1)
        bool = true; 
      return bool;
    } 
    o0 o01 = this.b;
    return (o01 != null) ? o01.i() : 0;
  }
  
  public ActionMode.Callback getCustomSelectionActionModeCallback() {
    return r.q(super.getCustomSelectionActionModeCallback());
  }
  
  public ColorStateList getSupportBackgroundTintList() {
    d d1 = this.a;
    return (d1 != null) ? d1.c() : null;
  }
  
  public PorterDuff.Mode getSupportBackgroundTintMode() {
    d d1 = this.a;
    return (d1 != null) ? d1.d() : null;
  }
  
  public ColorStateList getSupportCompoundDrawablesTintList() {
    return this.b.j();
  }
  
  public PorterDuff.Mode getSupportCompoundDrawablesTintMode() {
    return this.b.k();
  }
  
  public void onInitializeAccessibilityEvent(AccessibilityEvent paramAccessibilityEvent) {
    super.onInitializeAccessibilityEvent(paramAccessibilityEvent);
    paramAccessibilityEvent.setClassName(Button.class.getName());
  }
  
  public void onInitializeAccessibilityNodeInfo(AccessibilityNodeInfo paramAccessibilityNodeInfo) {
    super.onInitializeAccessibilityNodeInfo(paramAccessibilityNodeInfo);
    paramAccessibilityNodeInfo.setClassName(Button.class.getName());
  }
  
  protected void onLayout(boolean paramBoolean, int paramInt1, int paramInt2, int paramInt3, int paramInt4) {
    super.onLayout(paramBoolean, paramInt1, paramInt2, paramInt3, paramInt4);
    o0 o01 = this.b;
    if (o01 != null)
      o01.o(paramBoolean, paramInt1, paramInt2, paramInt3, paramInt4); 
  }
  
  protected void onTextChanged(CharSequence paramCharSequence, int paramInt1, int paramInt2, int paramInt3) {
    super.onTextChanged(paramCharSequence, paramInt1, paramInt2, paramInt3);
    o0 o01 = this.b;
    if (o01 != null && !b.a0 && o01.l())
      this.b.c(); 
  }
  
  public void setAllCaps(boolean paramBoolean) {
    super.setAllCaps(paramBoolean);
    getEmojiTextViewHelper().d(paramBoolean);
  }
  
  public void setAutoSizeTextTypeUniformWithConfiguration(int paramInt1, int paramInt2, int paramInt3, int paramInt4) throws IllegalArgumentException {
    if (b.a0) {
      super.setAutoSizeTextTypeUniformWithConfiguration(paramInt1, paramInt2, paramInt3, paramInt4);
      return;
    } 
    o0 o01 = this.b;
    if (o01 != null)
      o01.t(paramInt1, paramInt2, paramInt3, paramInt4); 
  }
  
  public void setAutoSizeTextTypeUniformWithPresetSizes(int[] paramArrayOfint, int paramInt) throws IllegalArgumentException {
    if (b.a0) {
      super.setAutoSizeTextTypeUniformWithPresetSizes(paramArrayOfint, paramInt);
      return;
    } 
    o0 o01 = this.b;
    if (o01 != null)
      o01.u(paramArrayOfint, paramInt); 
  }
  
  public void setAutoSizeTextTypeWithDefaults(int paramInt) {
    if (b.a0) {
      super.setAutoSizeTextTypeWithDefaults(paramInt);
      return;
    } 
    o0 o01 = this.b;
    if (o01 != null)
      o01.v(paramInt); 
  }
  
  public void setBackgroundDrawable(Drawable paramDrawable) {
    super.setBackgroundDrawable(paramDrawable);
    d d1 = this.a;
    if (d1 != null)
      d1.f(paramDrawable); 
  }
  
  public void setBackgroundResource(int paramInt) {
    super.setBackgroundResource(paramInt);
    d d1 = this.a;
    if (d1 != null)
      d1.g(paramInt); 
  }
  
  public void setCustomSelectionActionModeCallback(ActionMode.Callback paramCallback) {
    super.setCustomSelectionActionModeCallback(r.r((TextView)this, paramCallback));
  }
  
  public void setEmojiCompatEnabled(boolean paramBoolean) {
    getEmojiTextViewHelper().e(paramBoolean);
  }
  
  public void setFilters(InputFilter[] paramArrayOfInputFilter) {
    super.setFilters(getEmojiTextViewHelper().a(paramArrayOfInputFilter));
  }
  
  public void setSupportAllCaps(boolean paramBoolean) {
    o0 o01 = this.b;
    if (o01 != null)
      o01.s(paramBoolean); 
  }
  
  public void setSupportBackgroundTintList(ColorStateList paramColorStateList) {
    d d1 = this.a;
    if (d1 != null)
      d1.i(paramColorStateList); 
  }
  
  public void setSupportBackgroundTintMode(PorterDuff.Mode paramMode) {
    d d1 = this.a;
    if (d1 != null)
      d1.j(paramMode); 
  }
  
  public void setSupportCompoundDrawablesTintList(ColorStateList paramColorStateList) {
    this.b.w(paramColorStateList);
    this.b.b();
  }
  
  public void setSupportCompoundDrawablesTintMode(PorterDuff.Mode paramMode) {
    this.b.x(paramMode);
    this.b.b();
  }
  
  public void setTextAppearance(Context paramContext, int paramInt) {
    super.setTextAppearance(paramContext, paramInt);
    o0 o01 = this.b;
    if (o01 != null)
      o01.q(paramContext, paramInt); 
  }
  
  public void setTextSize(int paramInt, float paramFloat) {
    if (b.a0) {
      super.setTextSize(paramInt, paramFloat);
      return;
    } 
    o0 o01 = this.b;
    if (o01 != null)
      o01.A(paramInt, paramFloat); 
  }
}


/* Location:              C:\soft\dex2jar-2.0\Cricket Scorer-dex2jar.jar!\androidx\appcompat\widget\AppCompatButton.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */