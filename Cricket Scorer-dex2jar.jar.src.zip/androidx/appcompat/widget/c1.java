package androidx.appcompat.widget;

import android.content.Context;
import android.graphics.drawable.Drawable;
import android.view.Menu;
import android.view.ViewGroup;
import android.view.Window;
import androidx.appcompat.view.menu.g;
import androidx.appcompat.view.menu.m;
import androidx.core.view.o2;

public interface c1 {
  void a(Menu paramMenu, m.a parama);
  
  boolean b();
  
  void c();
  
  void collapseActionView();
  
  boolean d();
  
  Context e();
  
  boolean f();
  
  boolean g();
  
  CharSequence getTitle();
  
  boolean h();
  
  void i();
  
  void j(u1 paramu1);
  
  boolean k();
  
  void l(int paramInt);
  
  Menu m();
  
  void n(int paramInt);
  
  int o();
  
  o2 p(int paramInt, long paramLong);
  
  void q(m.a parama, g.a parama1);
  
  void r(int paramInt);
  
  ViewGroup s();
  
  void setIcon(int paramInt);
  
  void setIcon(Drawable paramDrawable);
  
  void setTitle(CharSequence paramCharSequence);
  
  void setWindowCallback(Window.Callback paramCallback);
  
  void setWindowTitle(CharSequence paramCharSequence);
  
  void t(boolean paramBoolean);
  
  int u();
  
  void v(int paramInt);
  
  void w();
  
  void x();
  
  void y(Drawable paramDrawable);
  
  void z(boolean paramBoolean);
}


/* Location:              C:\soft\dex2jar-2.0\Cricket Scorer-dex2jar.jar!\androidx\appcompat\widget\c1.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */