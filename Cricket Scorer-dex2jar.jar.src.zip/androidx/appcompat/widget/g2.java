package androidx.appcompat.widget;

import android.os.Build;
import android.view.View;

public class g2 {
  public static void a(View paramView, CharSequence paramCharSequence) {
    if (Build.VERSION.SDK_INT >= 26) {
      a.a(paramView, paramCharSequence);
      return;
    } 
    j2.h(paramView, paramCharSequence);
  }
  
  static class a {
    static void a(View param1View, CharSequence param1CharSequence) {
      f2.a(param1View, param1CharSequence);
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Cricket Scorer-dex2jar.jar!\androidx\appcompat\widget\g2.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */