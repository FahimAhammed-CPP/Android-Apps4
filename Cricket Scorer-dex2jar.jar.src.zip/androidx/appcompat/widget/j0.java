package androidx.appcompat.widget;

import android.app.Activity;
import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.Context;
import android.content.ContextWrapper;
import android.os.Build;
import android.text.Selection;
import android.text.Spannable;
import android.util.Log;
import android.view.DragEvent;
import android.view.View;
import android.widget.TextView;
import androidx.core.view.c;
import androidx.core.view.o0;

final class j0 {
  static boolean a(View paramView, DragEvent paramDragEvent) {
    int i = Build.VERSION.SDK_INT;
    if (i < 31 && i >= 24 && paramDragEvent.getLocalState() == null) {
      StringBuilder stringBuilder;
      if (o0.H(paramView) == null)
        return false; 
      Activity activity = c(paramView);
      if (activity == null) {
        stringBuilder = new StringBuilder();
        stringBuilder.append("Can't handle drop: no activity: view=");
        stringBuilder.append(paramView);
        Log.i("ReceiveContent", stringBuilder.toString());
        return false;
      } 
      if (stringBuilder.getAction() == 1)
        return paramView instanceof TextView ^ true; 
      if (stringBuilder.getAction() == 3)
        return (paramView instanceof TextView) ? a.a((DragEvent)stringBuilder, (TextView)paramView, activity) : a.b((DragEvent)stringBuilder, paramView, activity); 
    } 
    return false;
  }
  
  static boolean b(TextView paramTextView, int paramInt) {
    int i = Build.VERSION.SDK_INT;
    boolean bool = false;
    if (i < 31 && o0.H((View)paramTextView) != null) {
      ClipData clipData;
      if (paramInt != 16908322 && paramInt != 16908337)
        return false; 
      ClipboardManager clipboardManager = (ClipboardManager)paramTextView.getContext().getSystemService("clipboard");
      if (clipboardManager == null) {
        clipboardManager = null;
      } else {
        clipData = clipboardManager.getPrimaryClip();
      } 
      if (clipData != null && clipData.getItemCount() > 0) {
        c.a a = new c.a(clipData, 1);
        if (paramInt == 16908322) {
          paramInt = bool;
        } else {
          paramInt = 1;
        } 
        o0.h0((View)paramTextView, a.c(paramInt).a());
      } 
      return true;
    } 
    return false;
  }
  
  static Activity c(View paramView) {
    for (Context context = paramView.getContext(); context instanceof ContextWrapper; context = ((ContextWrapper)context).getBaseContext()) {
      if (context instanceof Activity)
        return (Activity)context; 
    } 
    return null;
  }
  
  private static final class a {
    static boolean a(DragEvent param1DragEvent, TextView param1TextView, Activity param1Activity) {
      i0.a(param1Activity, param1DragEvent);
      int i = param1TextView.getOffsetForPosition(param1DragEvent.getX(), param1DragEvent.getY());
      param1TextView.beginBatchEdit();
      try {
        Selection.setSelection((Spannable)param1TextView.getText(), i);
        o0.h0((View)param1TextView, (new c.a(param1DragEvent.getClipData(), 3)).a());
        return true;
      } finally {
        param1TextView.endBatchEdit();
      } 
    }
    
    static boolean b(DragEvent param1DragEvent, View param1View, Activity param1Activity) {
      i0.a(param1Activity, param1DragEvent);
      o0.h0(param1View, (new c.a(param1DragEvent.getClipData(), 3)).a());
      return true;
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Cricket Scorer-dex2jar.jar!\androidx\appcompat\widget\j0.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */