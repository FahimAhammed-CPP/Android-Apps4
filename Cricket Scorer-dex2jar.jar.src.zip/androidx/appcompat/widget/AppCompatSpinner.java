package androidx.appcompat.widget;

import android.content.Context;
import android.content.DialogInterface;
import android.content.res.ColorStateList;
import android.content.res.Resources;
import android.database.DataSetObserver;
import android.graphics.PorterDuff;
import android.graphics.Rect;
import android.graphics.drawable.Drawable;
import android.os.Build;
import android.os.Parcel;
import android.os.Parcelable;
import android.util.AttributeSet;
import android.util.Log;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.view.ViewTreeObserver;
import android.widget.Adapter;
import android.widget.AdapterView;
import android.widget.ListAdapter;
import android.widget.ListView;
import android.widget.PopupWindow;
import android.widget.Spinner;
import android.widget.SpinnerAdapter;
import android.widget.ThemedSpinnerAdapter;
import androidx.appcompat.view.menu.p;
import androidx.core.view.o0;

public class AppCompatSpinner extends Spinner {
  private static final int[] i = new int[] { 16843505 };
  
  private final d a;
  
  private final Context b;
  
  private h1 c;
  
  private SpinnerAdapter d;
  
  private final boolean e;
  
  private j f;
  
  int g;
  
  final Rect h;
  
  public AppCompatSpinner(Context paramContext, AttributeSet paramAttributeSet) {
    this(paramContext, paramAttributeSet, e.a.M);
  }
  
  public AppCompatSpinner(Context paramContext, AttributeSet paramAttributeSet, int paramInt) {
    this(paramContext, paramAttributeSet, paramInt, -1);
  }
  
  public AppCompatSpinner(Context paramContext, AttributeSet paramAttributeSet, int paramInt1, int paramInt2) {
    this(paramContext, paramAttributeSet, paramInt1, paramInt2, null);
  }
  
  public AppCompatSpinner(Context paramContext, AttributeSet paramAttributeSet, int paramInt1, int paramInt2, Resources.Theme paramTheme) {
    // Byte code:
    //   0: aload_0
    //   1: aload_1
    //   2: aload_2
    //   3: iload_3
    //   4: invokespecial <init> : (Landroid/content/Context;Landroid/util/AttributeSet;I)V
    //   7: aload_0
    //   8: new android/graphics/Rect
    //   11: dup
    //   12: invokespecial <init> : ()V
    //   15: putfield h : Landroid/graphics/Rect;
    //   18: aload_0
    //   19: aload_0
    //   20: invokevirtual getContext : ()Landroid/content/Context;
    //   23: invokestatic a : (Landroid/view/View;Landroid/content/Context;)V
    //   26: aload_1
    //   27: aload_2
    //   28: getstatic e/j.F2 : [I
    //   31: iload_3
    //   32: iconst_0
    //   33: invokestatic v : (Landroid/content/Context;Landroid/util/AttributeSet;[III)Landroidx/appcompat/widget/c2;
    //   36: astore #9
    //   38: aload_0
    //   39: new androidx/appcompat/widget/d
    //   42: dup
    //   43: aload_0
    //   44: invokespecial <init> : (Landroid/view/View;)V
    //   47: putfield a : Landroidx/appcompat/widget/d;
    //   50: aload #5
    //   52: ifnull -> 72
    //   55: aload_0
    //   56: new androidx/appcompat/view/d
    //   59: dup
    //   60: aload_1
    //   61: aload #5
    //   63: invokespecial <init> : (Landroid/content/Context;Landroid/content/res/Resources$Theme;)V
    //   66: putfield b : Landroid/content/Context;
    //   69: goto -> 110
    //   72: aload #9
    //   74: getstatic e/j.K2 : I
    //   77: iconst_0
    //   78: invokevirtual n : (II)I
    //   81: istore #6
    //   83: iload #6
    //   85: ifeq -> 105
    //   88: aload_0
    //   89: new androidx/appcompat/view/d
    //   92: dup
    //   93: aload_1
    //   94: iload #6
    //   96: invokespecial <init> : (Landroid/content/Context;I)V
    //   99: putfield b : Landroid/content/Context;
    //   102: goto -> 110
    //   105: aload_0
    //   106: aload_1
    //   107: putfield b : Landroid/content/Context;
    //   110: aconst_null
    //   111: astore #7
    //   113: iload #4
    //   115: istore #6
    //   117: iload #4
    //   119: iconst_m1
    //   120: if_icmpne -> 242
    //   123: aload_1
    //   124: aload_2
    //   125: getstatic androidx/appcompat/widget/AppCompatSpinner.i : [I
    //   128: iload_3
    //   129: iconst_0
    //   130: invokevirtual obtainStyledAttributes : (Landroid/util/AttributeSet;[III)Landroid/content/res/TypedArray;
    //   133: astore #5
    //   135: iload #4
    //   137: istore #6
    //   139: aload #5
    //   141: astore #8
    //   143: aload #5
    //   145: astore #7
    //   147: aload #5
    //   149: iconst_0
    //   150: invokevirtual hasValue : (I)Z
    //   153: ifeq -> 173
    //   156: aload #5
    //   158: astore #7
    //   160: aload #5
    //   162: iconst_0
    //   163: iconst_0
    //   164: invokevirtual getInt : (II)I
    //   167: istore #6
    //   169: aload #5
    //   171: astore #8
    //   173: aload #8
    //   175: invokevirtual recycle : ()V
    //   178: goto -> 242
    //   181: astore #8
    //   183: goto -> 195
    //   186: astore_1
    //   187: goto -> 230
    //   190: astore #8
    //   192: aconst_null
    //   193: astore #5
    //   195: aload #5
    //   197: astore #7
    //   199: ldc 'AppCompatSpinner'
    //   201: ldc 'Could not read android:spinnerMode'
    //   203: aload #8
    //   205: invokestatic i : (Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)I
    //   208: pop
    //   209: iload #4
    //   211: istore #6
    //   213: aload #5
    //   215: ifnull -> 242
    //   218: iload #4
    //   220: istore #6
    //   222: aload #5
    //   224: astore #8
    //   226: goto -> 173
    //   229: astore_1
    //   230: aload #7
    //   232: ifnull -> 240
    //   235: aload #7
    //   237: invokevirtual recycle : ()V
    //   240: aload_1
    //   241: athrow
    //   242: iload #6
    //   244: ifeq -> 356
    //   247: iload #6
    //   249: iconst_1
    //   250: if_icmpeq -> 256
    //   253: goto -> 387
    //   256: new androidx/appcompat/widget/AppCompatSpinner$h
    //   259: dup
    //   260: aload_0
    //   261: aload_0
    //   262: getfield b : Landroid/content/Context;
    //   265: aload_2
    //   266: iload_3
    //   267: invokespecial <init> : (Landroidx/appcompat/widget/AppCompatSpinner;Landroid/content/Context;Landroid/util/AttributeSet;I)V
    //   270: astore #5
    //   272: aload_0
    //   273: getfield b : Landroid/content/Context;
    //   276: aload_2
    //   277: getstatic e/j.F2 : [I
    //   280: iload_3
    //   281: iconst_0
    //   282: invokestatic v : (Landroid/content/Context;Landroid/util/AttributeSet;[III)Landroidx/appcompat/widget/c2;
    //   285: astore #7
    //   287: aload_0
    //   288: aload #7
    //   290: getstatic e/j.J2 : I
    //   293: bipush #-2
    //   295: invokevirtual m : (II)I
    //   298: putfield g : I
    //   301: aload #5
    //   303: aload #7
    //   305: getstatic e/j.H2 : I
    //   308: invokevirtual g : (I)Landroid/graphics/drawable/Drawable;
    //   311: invokevirtual b : (Landroid/graphics/drawable/Drawable;)V
    //   314: aload #5
    //   316: aload #9
    //   318: getstatic e/j.I2 : I
    //   321: invokevirtual o : (I)Ljava/lang/String;
    //   324: invokevirtual i : (Ljava/lang/CharSequence;)V
    //   327: aload #7
    //   329: invokevirtual w : ()V
    //   332: aload_0
    //   333: aload #5
    //   335: putfield f : Landroidx/appcompat/widget/AppCompatSpinner$j;
    //   338: aload_0
    //   339: new androidx/appcompat/widget/AppCompatSpinner$a
    //   342: dup
    //   343: aload_0
    //   344: aload_0
    //   345: aload #5
    //   347: invokespecial <init> : (Landroidx/appcompat/widget/AppCompatSpinner;Landroid/view/View;Landroidx/appcompat/widget/AppCompatSpinner$h;)V
    //   350: putfield c : Landroidx/appcompat/widget/h1;
    //   353: goto -> 387
    //   356: new androidx/appcompat/widget/AppCompatSpinner$f
    //   359: dup
    //   360: aload_0
    //   361: invokespecial <init> : (Landroidx/appcompat/widget/AppCompatSpinner;)V
    //   364: astore #5
    //   366: aload_0
    //   367: aload #5
    //   369: putfield f : Landroidx/appcompat/widget/AppCompatSpinner$j;
    //   372: aload #5
    //   374: aload #9
    //   376: getstatic e/j.I2 : I
    //   379: invokevirtual o : (I)Ljava/lang/String;
    //   382: invokeinterface i : (Ljava/lang/CharSequence;)V
    //   387: aload #9
    //   389: getstatic e/j.G2 : I
    //   392: invokevirtual q : (I)[Ljava/lang/CharSequence;
    //   395: astore #5
    //   397: aload #5
    //   399: ifnull -> 427
    //   402: new android/widget/ArrayAdapter
    //   405: dup
    //   406: aload_1
    //   407: ldc 17367048
    //   409: aload #5
    //   411: invokespecial <init> : (Landroid/content/Context;I[Ljava/lang/Object;)V
    //   414: astore_1
    //   415: aload_1
    //   416: getstatic e/g.t : I
    //   419: invokevirtual setDropDownViewResource : (I)V
    //   422: aload_0
    //   423: aload_1
    //   424: invokevirtual setAdapter : (Landroid/widget/SpinnerAdapter;)V
    //   427: aload #9
    //   429: invokevirtual w : ()V
    //   432: aload_0
    //   433: iconst_1
    //   434: putfield e : Z
    //   437: aload_0
    //   438: getfield d : Landroid/widget/SpinnerAdapter;
    //   441: astore_1
    //   442: aload_1
    //   443: ifnull -> 456
    //   446: aload_0
    //   447: aload_1
    //   448: invokevirtual setAdapter : (Landroid/widget/SpinnerAdapter;)V
    //   451: aload_0
    //   452: aconst_null
    //   453: putfield d : Landroid/widget/SpinnerAdapter;
    //   456: aload_0
    //   457: getfield a : Landroidx/appcompat/widget/d;
    //   460: aload_2
    //   461: iload_3
    //   462: invokevirtual e : (Landroid/util/AttributeSet;I)V
    //   465: return
    // Exception table:
    //   from	to	target	type
    //   123	135	190	java/lang/Exception
    //   123	135	186	finally
    //   147	156	181	java/lang/Exception
    //   147	156	229	finally
    //   160	169	181	java/lang/Exception
    //   160	169	229	finally
    //   199	209	229	finally
  }
  
  int a(SpinnerAdapter paramSpinnerAdapter, Drawable paramDrawable) {
    int m = 0;
    if (paramSpinnerAdapter == null)
      return 0; 
    int n = View.MeasureSpec.makeMeasureSpec(getMeasuredWidth(), 0);
    int i1 = View.MeasureSpec.makeMeasureSpec(getMeasuredHeight(), 0);
    int i = Math.max(0, getSelectedItemPosition());
    int i2 = Math.min(paramSpinnerAdapter.getCount(), i + 15);
    int k = Math.max(0, i - 15 - i2 - i);
    View view = null;
    i = 0;
    while (k < i2) {
      int i4 = paramSpinnerAdapter.getItemViewType(k);
      int i3 = m;
      if (i4 != m) {
        view = null;
        i3 = i4;
      } 
      view = paramSpinnerAdapter.getView(k, view, (ViewGroup)this);
      if (view.getLayoutParams() == null)
        view.setLayoutParams(new ViewGroup.LayoutParams(-2, -2)); 
      view.measure(n, i1);
      i = Math.max(i, view.getMeasuredWidth());
      k++;
      m = i3;
    } 
    k = i;
    if (paramDrawable != null) {
      paramDrawable.getPadding(this.h);
      Rect rect = this.h;
      k = i + rect.left + rect.right;
    } 
    return k;
  }
  
  void b() {
    this.f.m(d.b((View)this), d.a((View)this));
  }
  
  protected void drawableStateChanged() {
    super.drawableStateChanged();
    d d1 = this.a;
    if (d1 != null)
      d1.b(); 
  }
  
  public int getDropDownHorizontalOffset() {
    j j1 = this.f;
    return (j1 != null) ? j1.c() : super.getDropDownHorizontalOffset();
  }
  
  public int getDropDownVerticalOffset() {
    j j1 = this.f;
    return (j1 != null) ? j1.n() : super.getDropDownVerticalOffset();
  }
  
  public int getDropDownWidth() {
    return (this.f != null) ? this.g : super.getDropDownWidth();
  }
  
  final j getInternalPopup() {
    return this.f;
  }
  
  public Drawable getPopupBackground() {
    j j1 = this.f;
    return (j1 != null) ? j1.h() : super.getPopupBackground();
  }
  
  public Context getPopupContext() {
    return this.b;
  }
  
  public CharSequence getPrompt() {
    j j1 = this.f;
    return (j1 != null) ? j1.f() : super.getPrompt();
  }
  
  public ColorStateList getSupportBackgroundTintList() {
    d d1 = this.a;
    return (d1 != null) ? d1.c() : null;
  }
  
  public PorterDuff.Mode getSupportBackgroundTintMode() {
    d d1 = this.a;
    return (d1 != null) ? d1.d() : null;
  }
  
  protected void onDetachedFromWindow() {
    super.onDetachedFromWindow();
    j j1 = this.f;
    if (j1 != null && j1.a())
      this.f.dismiss(); 
  }
  
  protected void onMeasure(int paramInt1, int paramInt2) {
    super.onMeasure(paramInt1, paramInt2);
    if (this.f != null && View.MeasureSpec.getMode(paramInt1) == Integer.MIN_VALUE)
      setMeasuredDimension(Math.min(Math.max(getMeasuredWidth(), a(getAdapter(), getBackground())), View.MeasureSpec.getSize(paramInt1)), getMeasuredHeight()); 
  }
  
  public void onRestoreInstanceState(Parcelable paramParcelable) {
    i i = (i)paramParcelable;
    super.onRestoreInstanceState(i.getSuperState());
    if (i.a) {
      ViewTreeObserver viewTreeObserver = getViewTreeObserver();
      if (viewTreeObserver != null)
        viewTreeObserver.addOnGlobalLayoutListener(new b(this)); 
    } 
  }
  
  public Parcelable onSaveInstanceState() {
    boolean bool;
    i i = new i(super.onSaveInstanceState());
    j j1 = this.f;
    if (j1 != null && j1.a()) {
      bool = true;
    } else {
      bool = false;
    } 
    i.a = bool;
    return (Parcelable)i;
  }
  
  public boolean onTouchEvent(MotionEvent paramMotionEvent) {
    h1 h11 = this.c;
    return (h11 != null && h11.onTouch((View)this, paramMotionEvent)) ? true : super.onTouchEvent(paramMotionEvent);
  }
  
  public boolean performClick() {
    j j1 = this.f;
    if (j1 != null) {
      if (!j1.a())
        b(); 
      return true;
    } 
    return super.performClick();
  }
  
  public void setAdapter(SpinnerAdapter paramSpinnerAdapter) {
    if (!this.e) {
      this.d = paramSpinnerAdapter;
      return;
    } 
    super.setAdapter(paramSpinnerAdapter);
    if (this.f != null) {
      Context context2 = this.b;
      Context context1 = context2;
      if (context2 == null)
        context1 = getContext(); 
      this.f.o(new g(paramSpinnerAdapter, context1.getTheme()));
    } 
  }
  
  public void setBackgroundDrawable(Drawable paramDrawable) {
    super.setBackgroundDrawable(paramDrawable);
    d d1 = this.a;
    if (d1 != null)
      d1.f(paramDrawable); 
  }
  
  public void setBackgroundResource(int paramInt) {
    super.setBackgroundResource(paramInt);
    d d1 = this.a;
    if (d1 != null)
      d1.g(paramInt); 
  }
  
  public void setDropDownHorizontalOffset(int paramInt) {
    j j1 = this.f;
    if (j1 != null) {
      j1.l(paramInt);
      this.f.e(paramInt);
      return;
    } 
    super.setDropDownHorizontalOffset(paramInt);
  }
  
  public void setDropDownVerticalOffset(int paramInt) {
    j j1 = this.f;
    if (j1 != null) {
      j1.k(paramInt);
      return;
    } 
    super.setDropDownVerticalOffset(paramInt);
  }
  
  public void setDropDownWidth(int paramInt) {
    if (this.f != null) {
      this.g = paramInt;
      return;
    } 
    super.setDropDownWidth(paramInt);
  }
  
  public void setPopupBackgroundDrawable(Drawable paramDrawable) {
    j j1 = this.f;
    if (j1 != null) {
      j1.b(paramDrawable);
      return;
    } 
    super.setPopupBackgroundDrawable(paramDrawable);
  }
  
  public void setPopupBackgroundResource(int paramInt) {
    setPopupBackgroundDrawable(f.a.b(getPopupContext(), paramInt));
  }
  
  public void setPrompt(CharSequence paramCharSequence) {
    j j1 = this.f;
    if (j1 != null) {
      j1.i(paramCharSequence);
      return;
    } 
    super.setPrompt(paramCharSequence);
  }
  
  public void setSupportBackgroundTintList(ColorStateList paramColorStateList) {
    d d1 = this.a;
    if (d1 != null)
      d1.i(paramColorStateList); 
  }
  
  public void setSupportBackgroundTintMode(PorterDuff.Mode paramMode) {
    d d1 = this.a;
    if (d1 != null)
      d1.j(paramMode); 
  }
  
  class a extends h1 {
    a(AppCompatSpinner this$0, View param1View, AppCompatSpinner.h param1h) {
      super(param1View);
    }
    
    public p b() {
      return this.j;
    }
    
    public boolean c() {
      if (!this.k.getInternalPopup().a())
        this.k.b(); 
      return true;
    }
  }
  
  class b implements ViewTreeObserver.OnGlobalLayoutListener {
    b(AppCompatSpinner this$0) {}
    
    public void onGlobalLayout() {
      if (!this.a.getInternalPopup().a())
        this.a.b(); 
      ViewTreeObserver viewTreeObserver = this.a.getViewTreeObserver();
      if (viewTreeObserver != null)
        AppCompatSpinner.c.a(viewTreeObserver, this); 
    }
  }
  
  private static final class c {
    static void a(ViewTreeObserver param1ViewTreeObserver, ViewTreeObserver.OnGlobalLayoutListener param1OnGlobalLayoutListener) {
      param1ViewTreeObserver.removeOnGlobalLayoutListener(param1OnGlobalLayoutListener);
    }
  }
  
  private static final class d {
    static int a(View param1View) {
      return param1View.getTextAlignment();
    }
    
    static int b(View param1View) {
      return param1View.getTextDirection();
    }
    
    static void c(View param1View, int param1Int) {
      param1View.setTextAlignment(param1Int);
    }
    
    static void d(View param1View, int param1Int) {
      param1View.setTextDirection(param1Int);
    }
  }
  
  private static final class e {
    static void a(ThemedSpinnerAdapter param1ThemedSpinnerAdapter, Resources.Theme param1Theme) {
      if (param1ThemedSpinnerAdapter.getDropDownViewTheme() != param1Theme)
        param1ThemedSpinnerAdapter.setDropDownViewTheme(param1Theme); 
    }
  }
  
  class f implements j, DialogInterface.OnClickListener {
    androidx.appcompat.app.c a;
    
    private ListAdapter b;
    
    private CharSequence c;
    
    f(AppCompatSpinner this$0) {}
    
    public boolean a() {
      androidx.appcompat.app.c c1 = this.a;
      return (c1 != null) ? c1.isShowing() : false;
    }
    
    public void b(Drawable param1Drawable) {
      Log.e("AppCompatSpinner", "Cannot set popup background for MODE_DIALOG, ignoring");
    }
    
    public int c() {
      return 0;
    }
    
    public void dismiss() {
      androidx.appcompat.app.c c1 = this.a;
      if (c1 != null) {
        c1.dismiss();
        this.a = null;
      } 
    }
    
    public void e(int param1Int) {
      Log.e("AppCompatSpinner", "Cannot set horizontal offset for MODE_DIALOG, ignoring");
    }
    
    public CharSequence f() {
      return this.c;
    }
    
    public Drawable h() {
      return null;
    }
    
    public void i(CharSequence param1CharSequence) {
      this.c = param1CharSequence;
    }
    
    public void k(int param1Int) {
      Log.e("AppCompatSpinner", "Cannot set vertical offset for MODE_DIALOG, ignoring");
    }
    
    public void l(int param1Int) {
      Log.e("AppCompatSpinner", "Cannot set horizontal (original) offset for MODE_DIALOG, ignoring");
    }
    
    public void m(int param1Int1, int param1Int2) {
      if (this.b == null)
        return; 
      androidx.appcompat.app.c.a a = new androidx.appcompat.app.c.a(this.d.getPopupContext());
      CharSequence charSequence = this.c;
      if (charSequence != null)
        a.p(charSequence); 
      androidx.appcompat.app.c c1 = a.o(this.b, this.d.getSelectedItemPosition(), this).a();
      this.a = c1;
      ListView listView = c1.j();
      AppCompatSpinner.d.d((View)listView, param1Int1);
      AppCompatSpinner.d.c((View)listView, param1Int2);
      this.a.show();
    }
    
    public int n() {
      return 0;
    }
    
    public void o(ListAdapter param1ListAdapter) {
      this.b = param1ListAdapter;
    }
    
    public void onClick(DialogInterface param1DialogInterface, int param1Int) {
      this.d.setSelection(param1Int);
      if (this.d.getOnItemClickListener() != null)
        this.d.performItemClick(null, param1Int, this.b.getItemId(param1Int)); 
      dismiss();
    }
  }
  
  private static class g implements ListAdapter, SpinnerAdapter {
    private SpinnerAdapter a;
    
    private ListAdapter b;
    
    public g(SpinnerAdapter param1SpinnerAdapter, Resources.Theme param1Theme) {
      this.a = param1SpinnerAdapter;
      if (param1SpinnerAdapter instanceof ListAdapter)
        this.b = (ListAdapter)param1SpinnerAdapter; 
      if (param1Theme != null) {
        if (Build.VERSION.SDK_INT >= 23 && param1SpinnerAdapter instanceof ThemedSpinnerAdapter) {
          AppCompatSpinner.e.a((ThemedSpinnerAdapter)param1SpinnerAdapter, param1Theme);
          return;
        } 
        if (param1SpinnerAdapter instanceof y1) {
          param1SpinnerAdapter = param1SpinnerAdapter;
          if (param1SpinnerAdapter.getDropDownViewTheme() == null)
            param1SpinnerAdapter.setDropDownViewTheme(param1Theme); 
        } 
      } 
    }
    
    public boolean areAllItemsEnabled() {
      ListAdapter listAdapter = this.b;
      return (listAdapter != null) ? listAdapter.areAllItemsEnabled() : true;
    }
    
    public int getCount() {
      SpinnerAdapter spinnerAdapter = this.a;
      return (spinnerAdapter == null) ? 0 : spinnerAdapter.getCount();
    }
    
    public View getDropDownView(int param1Int, View param1View, ViewGroup param1ViewGroup) {
      SpinnerAdapter spinnerAdapter = this.a;
      return (spinnerAdapter == null) ? null : spinnerAdapter.getDropDownView(param1Int, param1View, param1ViewGroup);
    }
    
    public Object getItem(int param1Int) {
      SpinnerAdapter spinnerAdapter = this.a;
      return (spinnerAdapter == null) ? null : spinnerAdapter.getItem(param1Int);
    }
    
    public long getItemId(int param1Int) {
      SpinnerAdapter spinnerAdapter = this.a;
      return (spinnerAdapter == null) ? -1L : spinnerAdapter.getItemId(param1Int);
    }
    
    public int getItemViewType(int param1Int) {
      return 0;
    }
    
    public View getView(int param1Int, View param1View, ViewGroup param1ViewGroup) {
      return getDropDownView(param1Int, param1View, param1ViewGroup);
    }
    
    public int getViewTypeCount() {
      return 1;
    }
    
    public boolean hasStableIds() {
      SpinnerAdapter spinnerAdapter = this.a;
      return (spinnerAdapter != null && spinnerAdapter.hasStableIds());
    }
    
    public boolean isEmpty() {
      return (getCount() == 0);
    }
    
    public boolean isEnabled(int param1Int) {
      ListAdapter listAdapter = this.b;
      return (listAdapter != null) ? listAdapter.isEnabled(param1Int) : true;
    }
    
    public void registerDataSetObserver(DataSetObserver param1DataSetObserver) {
      SpinnerAdapter spinnerAdapter = this.a;
      if (spinnerAdapter != null)
        spinnerAdapter.registerDataSetObserver(param1DataSetObserver); 
    }
    
    public void unregisterDataSetObserver(DataSetObserver param1DataSetObserver) {
      SpinnerAdapter spinnerAdapter = this.a;
      if (spinnerAdapter != null)
        spinnerAdapter.unregisterDataSetObserver(param1DataSetObserver); 
    }
  }
  
  class h extends i1 implements j {
    private CharSequence J;
    
    ListAdapter K;
    
    private final Rect L = new Rect();
    
    private int M;
    
    public h(AppCompatSpinner this$0, Context param1Context, AttributeSet param1AttributeSet, int param1Int) {
      super(param1Context, param1AttributeSet, param1Int);
      C((View)this$0);
      I(true);
      N(0);
      K(new a(this, this$0));
    }
    
    void R() {
      Drawable drawable = h();
      int i = 0;
      if (drawable != null) {
        drawable.getPadding(this.N.h);
        if (m2.b((View)this.N)) {
          i = this.N.h.right;
        } else {
          i = -this.N.h.left;
        } 
      } else {
        Rect rect = this.N.h;
        rect.right = 0;
        rect.left = 0;
      } 
      int m = this.N.getPaddingLeft();
      int n = this.N.getPaddingRight();
      int i2 = this.N.getWidth();
      AppCompatSpinner appCompatSpinner = this.N;
      int k = appCompatSpinner.g;
      if (k == -2) {
        int i3 = appCompatSpinner.a((SpinnerAdapter)this.K, h());
        k = (this.N.getContext().getResources().getDisplayMetrics()).widthPixels;
        Rect rect = this.N.h;
        int i4 = k - rect.left - rect.right;
        k = i3;
        if (i3 > i4)
          k = i4; 
        E(Math.max(k, i2 - m - n));
      } else if (k == -1) {
        E(i2 - m - n);
      } else {
        E(k);
      } 
      if (m2.b((View)this.N)) {
        i += i2 - n - y() - S();
      } else {
        i += m + S();
      } 
      e(i);
    }
    
    public int S() {
      return this.M;
    }
    
    boolean T(View param1View) {
      return (o0.U(param1View) && param1View.getGlobalVisibleRect(this.L));
    }
    
    public CharSequence f() {
      return this.J;
    }
    
    public void i(CharSequence param1CharSequence) {
      this.J = param1CharSequence;
    }
    
    public void l(int param1Int) {
      this.M = param1Int;
    }
    
    public void m(int param1Int1, int param1Int2) {
      boolean bool = a();
      R();
      H(2);
      show();
      ListView listView = j();
      listView.setChoiceMode(1);
      AppCompatSpinner.d.d((View)listView, param1Int1);
      AppCompatSpinner.d.c((View)listView, param1Int2);
      O(this.N.getSelectedItemPosition());
      if (bool)
        return; 
      ViewTreeObserver viewTreeObserver = this.N.getViewTreeObserver();
      if (viewTreeObserver != null) {
        b b = new b(this);
        viewTreeObserver.addOnGlobalLayoutListener(b);
        J(new c(this, b));
      } 
    }
    
    public void o(ListAdapter param1ListAdapter) {
      super.o(param1ListAdapter);
      this.K = param1ListAdapter;
    }
    
    class a implements AdapterView.OnItemClickListener {
      a(AppCompatSpinner.h this$0, AppCompatSpinner param2AppCompatSpinner) {}
      
      public void onItemClick(AdapterView<?> param2AdapterView, View param2View, int param2Int, long param2Long) {
        this.b.N.setSelection(param2Int);
        if (this.b.N.getOnItemClickListener() != null) {
          AppCompatSpinner.h h1 = this.b;
          h1.N.performItemClick(param2View, param2Int, h1.K.getItemId(param2Int));
        } 
        this.b.dismiss();
      }
    }
    
    class b implements ViewTreeObserver.OnGlobalLayoutListener {
      b(AppCompatSpinner.h this$0) {}
      
      public void onGlobalLayout() {
        AppCompatSpinner.h h1 = this.a;
        if (!h1.T((View)h1.N)) {
          this.a.dismiss();
          return;
        } 
        this.a.R();
        AppCompatSpinner.h.Q(this.a);
      }
    }
    
    class c implements PopupWindow.OnDismissListener {
      c(AppCompatSpinner.h this$0, ViewTreeObserver.OnGlobalLayoutListener param2OnGlobalLayoutListener) {}
      
      public void onDismiss() {
        ViewTreeObserver viewTreeObserver = this.b.N.getViewTreeObserver();
        if (viewTreeObserver != null)
          viewTreeObserver.removeGlobalOnLayoutListener(this.a); 
      }
    }
  }
  
  class a implements AdapterView.OnItemClickListener {
    a(AppCompatSpinner this$0, AppCompatSpinner param1AppCompatSpinner) {}
    
    public void onItemClick(AdapterView<?> param1AdapterView, View param1View, int param1Int, long param1Long) {
      this.b.N.setSelection(param1Int);
      if (this.b.N.getOnItemClickListener() != null) {
        AppCompatSpinner.h h1 = this.b;
        h1.N.performItemClick(param1View, param1Int, h1.K.getItemId(param1Int));
      } 
      this.b.dismiss();
    }
  }
  
  class b implements ViewTreeObserver.OnGlobalLayoutListener {
    b(AppCompatSpinner this$0) {}
    
    public void onGlobalLayout() {
      AppCompatSpinner.h h1 = this.a;
      if (!h1.T((View)h1.N)) {
        this.a.dismiss();
        return;
      } 
      this.a.R();
      AppCompatSpinner.h.Q(this.a);
    }
  }
  
  class c implements PopupWindow.OnDismissListener {
    c(AppCompatSpinner this$0, ViewTreeObserver.OnGlobalLayoutListener param1OnGlobalLayoutListener) {}
    
    public void onDismiss() {
      ViewTreeObserver viewTreeObserver = this.b.N.getViewTreeObserver();
      if (viewTreeObserver != null)
        viewTreeObserver.removeGlobalOnLayoutListener(this.a); 
    }
  }
  
  static class i extends View.BaseSavedState {
    public static final Parcelable.Creator<i> CREATOR = new a();
    
    boolean a;
    
    i(Parcel param1Parcel) {
      super(param1Parcel);
      boolean bool;
      if (param1Parcel.readByte() != 0) {
        bool = true;
      } else {
        bool = false;
      } 
      this.a = bool;
    }
    
    i(Parcelable param1Parcelable) {
      super(param1Parcelable);
    }
    
    public void writeToParcel(Parcel param1Parcel, int param1Int) {
      super.writeToParcel(param1Parcel, param1Int);
      param1Parcel.writeByte((byte)this.a);
    }
    
    class a implements Parcelable.Creator<i> {
      public AppCompatSpinner.i a(Parcel param2Parcel) {
        return new AppCompatSpinner.i(param2Parcel);
      }
      
      public AppCompatSpinner.i[] b(int param2Int) {
        return new AppCompatSpinner.i[param2Int];
      }
    }
  }
  
  class a implements Parcelable.Creator<i> {
    public AppCompatSpinner.i a(Parcel param1Parcel) {
      return new AppCompatSpinner.i(param1Parcel);
    }
    
    public AppCompatSpinner.i[] b(int param1Int) {
      return new AppCompatSpinner.i[param1Int];
    }
  }
  
  static interface j {
    boolean a();
    
    void b(Drawable param1Drawable);
    
    int c();
    
    void dismiss();
    
    void e(int param1Int);
    
    CharSequence f();
    
    Drawable h();
    
    void i(CharSequence param1CharSequence);
    
    void k(int param1Int);
    
    void l(int param1Int);
    
    void m(int param1Int1, int param1Int2);
    
    int n();
    
    void o(ListAdapter param1ListAdapter);
  }
}


/* Location:              C:\soft\dex2jar-2.0\Cricket Scorer-dex2jar.jar!\androidx\appcompat\widget\AppCompatSpinner.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */