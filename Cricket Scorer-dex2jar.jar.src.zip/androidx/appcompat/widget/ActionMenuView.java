package androidx.appcompat.widget;

import android.content.Context;
import android.content.res.Configuration;
import android.graphics.drawable.Drawable;
import android.util.AttributeSet;
import android.view.ContextThemeWrapper;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewDebug.ExportedProperty;
import android.view.ViewGroup;
import android.view.accessibility.AccessibilityEvent;
import androidx.appcompat.view.menu.ActionMenuItemView;
import androidx.appcompat.view.menu.g;
import androidx.appcompat.view.menu.i;
import androidx.appcompat.view.menu.m;
import androidx.appcompat.view.menu.n;

public class ActionMenuView extends LinearLayoutCompat implements g.b, n {
  e A;
  
  private g p;
  
  private Context q;
  
  private int r;
  
  private boolean s;
  
  private c t;
  
  private m.a u;
  
  g.a v;
  
  private boolean w;
  
  private int x;
  
  private int y;
  
  private int z;
  
  public ActionMenuView(Context paramContext) {
    this(paramContext, null);
  }
  
  public ActionMenuView(Context paramContext, AttributeSet paramAttributeSet) {
    super(paramContext, paramAttributeSet);
    setBaselineAligned(false);
    float f = (paramContext.getResources().getDisplayMetrics()).density;
    this.y = (int)(56.0F * f);
    this.z = (int)(f * 4.0F);
    this.q = paramContext;
    this.r = 0;
  }
  
  static int J(View paramView, int paramInt1, int paramInt2, int paramInt3, int paramInt4) {
    ActionMenuItemView actionMenuItemView;
    c c1 = (c)paramView.getLayoutParams();
    int i = View.MeasureSpec.makeMeasureSpec(View.MeasureSpec.getSize(paramInt3) - paramInt4, View.MeasureSpec.getMode(paramInt3));
    if (paramView instanceof ActionMenuItemView) {
      actionMenuItemView = (ActionMenuItemView)paramView;
    } else {
      actionMenuItemView = null;
    } 
    boolean bool = true;
    if (actionMenuItemView != null && actionMenuItemView.f()) {
      paramInt3 = 1;
    } else {
      paramInt3 = 0;
    } 
    paramInt4 = 2;
    if (paramInt2 > 0 && (paramInt3 == 0 || paramInt2 >= 2)) {
      paramView.measure(View.MeasureSpec.makeMeasureSpec(paramInt2 * paramInt1, -2147483648), i);
      int k = paramView.getMeasuredWidth();
      int j = k / paramInt1;
      paramInt2 = j;
      if (k % paramInt1 != 0)
        paramInt2 = j + 1; 
      if (paramInt3 != 0 && paramInt2 < 2)
        paramInt2 = paramInt4; 
    } else {
      paramInt2 = 0;
    } 
    if (c1.a || paramInt3 == 0)
      bool = false; 
    c1.d = bool;
    c1.b = paramInt2;
    paramView.measure(View.MeasureSpec.makeMeasureSpec(paramInt1 * paramInt2, 1073741824), i);
    return paramInt2;
  }
  
  private void K(int paramInt1, int paramInt2) {
    // Byte code:
    //   0: iload_2
    //   1: invokestatic getMode : (I)I
    //   4: istore #12
    //   6: iload_1
    //   7: invokestatic getSize : (I)I
    //   10: istore_1
    //   11: iload_2
    //   12: invokestatic getSize : (I)I
    //   15: istore #6
    //   17: aload_0
    //   18: invokevirtual getPaddingLeft : ()I
    //   21: istore #5
    //   23: aload_0
    //   24: invokevirtual getPaddingRight : ()I
    //   27: istore #7
    //   29: aload_0
    //   30: invokevirtual getPaddingTop : ()I
    //   33: aload_0
    //   34: invokevirtual getPaddingBottom : ()I
    //   37: iadd
    //   38: istore #13
    //   40: iload_2
    //   41: iload #13
    //   43: bipush #-2
    //   45: invokestatic getChildMeasureSpec : (III)I
    //   48: istore #20
    //   50: iload_1
    //   51: iload #5
    //   53: iload #7
    //   55: iadd
    //   56: isub
    //   57: istore #14
    //   59: aload_0
    //   60: getfield y : I
    //   63: istore_2
    //   64: iload #14
    //   66: iload_2
    //   67: idiv
    //   68: istore_1
    //   69: iload_1
    //   70: ifne -> 81
    //   73: aload_0
    //   74: iload #14
    //   76: iconst_0
    //   77: invokevirtual setMeasuredDimension : (II)V
    //   80: return
    //   81: iload_2
    //   82: iload #14
    //   84: iload_2
    //   85: irem
    //   86: iload_1
    //   87: idiv
    //   88: iadd
    //   89: istore #21
    //   91: aload_0
    //   92: invokevirtual getChildCount : ()I
    //   95: istore #22
    //   97: iconst_0
    //   98: istore #5
    //   100: iconst_0
    //   101: istore #9
    //   103: iconst_0
    //   104: istore #7
    //   106: iconst_0
    //   107: istore #11
    //   109: iconst_0
    //   110: istore #10
    //   112: iconst_0
    //   113: istore #8
    //   115: lconst_0
    //   116: lstore #23
    //   118: iload #9
    //   120: iload #22
    //   122: if_icmpge -> 375
    //   125: aload_0
    //   126: iload #9
    //   128: invokevirtual getChildAt : (I)Landroid/view/View;
    //   131: astore #32
    //   133: aload #32
    //   135: invokevirtual getVisibility : ()I
    //   138: bipush #8
    //   140: if_icmpne -> 149
    //   143: iload #8
    //   145: istore_2
    //   146: goto -> 363
    //   149: aload #32
    //   151: instanceof androidx/appcompat/view/menu/ActionMenuItemView
    //   154: istore #31
    //   156: iload #11
    //   158: iconst_1
    //   159: iadd
    //   160: istore #11
    //   162: iload #31
    //   164: ifeq -> 184
    //   167: aload_0
    //   168: getfield z : I
    //   171: istore_2
    //   172: aload #32
    //   174: iload_2
    //   175: iconst_0
    //   176: iload_2
    //   177: iconst_0
    //   178: invokevirtual setPadding : (IIII)V
    //   181: goto -> 184
    //   184: aload #32
    //   186: invokevirtual getLayoutParams : ()Landroid/view/ViewGroup$LayoutParams;
    //   189: checkcast androidx/appcompat/widget/ActionMenuView$c
    //   192: astore #33
    //   194: aload #33
    //   196: iconst_0
    //   197: putfield f : Z
    //   200: aload #33
    //   202: iconst_0
    //   203: putfield c : I
    //   206: aload #33
    //   208: iconst_0
    //   209: putfield b : I
    //   212: aload #33
    //   214: iconst_0
    //   215: putfield d : Z
    //   218: aload #33
    //   220: iconst_0
    //   221: putfield leftMargin : I
    //   224: aload #33
    //   226: iconst_0
    //   227: putfield rightMargin : I
    //   230: iload #31
    //   232: ifeq -> 252
    //   235: aload #32
    //   237: checkcast androidx/appcompat/view/menu/ActionMenuItemView
    //   240: invokevirtual f : ()Z
    //   243: ifeq -> 252
    //   246: iconst_1
    //   247: istore #31
    //   249: goto -> 255
    //   252: iconst_0
    //   253: istore #31
    //   255: aload #33
    //   257: iload #31
    //   259: putfield e : Z
    //   262: aload #33
    //   264: getfield a : Z
    //   267: ifeq -> 275
    //   270: iconst_1
    //   271: istore_2
    //   272: goto -> 277
    //   275: iload_1
    //   276: istore_2
    //   277: aload #32
    //   279: iload #21
    //   281: iload_2
    //   282: iload #20
    //   284: iload #13
    //   286: invokestatic J : (Landroid/view/View;IIII)I
    //   289: istore #15
    //   291: iload #10
    //   293: iload #15
    //   295: invokestatic max : (II)I
    //   298: istore #10
    //   300: iload #8
    //   302: istore_2
    //   303: aload #33
    //   305: getfield d : Z
    //   308: ifeq -> 316
    //   311: iload #8
    //   313: iconst_1
    //   314: iadd
    //   315: istore_2
    //   316: aload #33
    //   318: getfield a : Z
    //   321: ifeq -> 327
    //   324: iconst_1
    //   325: istore #7
    //   327: iload_1
    //   328: iload #15
    //   330: isub
    //   331: istore_1
    //   332: iload #5
    //   334: aload #32
    //   336: invokevirtual getMeasuredHeight : ()I
    //   339: invokestatic max : (II)I
    //   342: istore #5
    //   344: iload #15
    //   346: iconst_1
    //   347: if_icmpne -> 363
    //   350: lload #23
    //   352: iconst_1
    //   353: iload #9
    //   355: ishl
    //   356: i2l
    //   357: lor
    //   358: lstore #23
    //   360: goto -> 363
    //   363: iload #9
    //   365: iconst_1
    //   366: iadd
    //   367: istore #9
    //   369: iload_2
    //   370: istore #8
    //   372: goto -> 118
    //   375: iload #7
    //   377: ifeq -> 392
    //   380: iload #11
    //   382: iconst_2
    //   383: if_icmpne -> 392
    //   386: iconst_1
    //   387: istore #9
    //   389: goto -> 395
    //   392: iconst_0
    //   393: istore #9
    //   395: iconst_0
    //   396: istore_2
    //   397: iload_1
    //   398: istore #13
    //   400: iload #9
    //   402: istore #15
    //   404: iload #14
    //   406: istore #9
    //   408: iload #8
    //   410: ifle -> 733
    //   413: iload #13
    //   415: ifle -> 733
    //   418: iconst_0
    //   419: istore #17
    //   421: iconst_0
    //   422: istore #16
    //   424: ldc 2147483647
    //   426: istore #14
    //   428: lconst_0
    //   429: lstore #27
    //   431: iload #16
    //   433: iload #22
    //   435: if_icmpge -> 559
    //   438: aload_0
    //   439: iload #16
    //   441: invokevirtual getChildAt : (I)Landroid/view/View;
    //   444: invokevirtual getLayoutParams : ()Landroid/view/ViewGroup$LayoutParams;
    //   447: checkcast androidx/appcompat/widget/ActionMenuView$c
    //   450: astore #32
    //   452: aload #32
    //   454: getfield d : Z
    //   457: ifne -> 474
    //   460: iload #17
    //   462: istore_1
    //   463: iload #14
    //   465: istore #18
    //   467: lload #27
    //   469: lstore #25
    //   471: goto -> 539
    //   474: aload #32
    //   476: getfield b : I
    //   479: istore #19
    //   481: iload #19
    //   483: iload #14
    //   485: if_icmpge -> 503
    //   488: lconst_1
    //   489: iload #16
    //   491: lshl
    //   492: lstore #25
    //   494: iload #19
    //   496: istore #18
    //   498: iconst_1
    //   499: istore_1
    //   500: goto -> 539
    //   503: iload #17
    //   505: istore_1
    //   506: iload #14
    //   508: istore #18
    //   510: lload #27
    //   512: lstore #25
    //   514: iload #19
    //   516: iload #14
    //   518: if_icmpne -> 539
    //   521: iload #17
    //   523: iconst_1
    //   524: iadd
    //   525: istore_1
    //   526: lload #27
    //   528: lconst_1
    //   529: iload #16
    //   531: lshl
    //   532: lor
    //   533: lstore #25
    //   535: iload #14
    //   537: istore #18
    //   539: iload #16
    //   541: iconst_1
    //   542: iadd
    //   543: istore #16
    //   545: iload_1
    //   546: istore #17
    //   548: iload #18
    //   550: istore #14
    //   552: lload #25
    //   554: lstore #27
    //   556: goto -> 431
    //   559: iload_2
    //   560: istore_1
    //   561: iload #5
    //   563: istore_2
    //   564: lload #23
    //   566: lload #27
    //   568: lor
    //   569: lstore #23
    //   571: iload #17
    //   573: iload #13
    //   575: if_icmple -> 581
    //   578: goto -> 738
    //   581: iconst_0
    //   582: istore_1
    //   583: iload_1
    //   584: iload #22
    //   586: if_icmpge -> 725
    //   589: aload_0
    //   590: iload_1
    //   591: invokevirtual getChildAt : (I)Landroid/view/View;
    //   594: astore #32
    //   596: aload #32
    //   598: invokevirtual getLayoutParams : ()Landroid/view/ViewGroup$LayoutParams;
    //   601: checkcast androidx/appcompat/widget/ActionMenuView$c
    //   604: astore #33
    //   606: iconst_1
    //   607: iload_1
    //   608: ishl
    //   609: i2l
    //   610: lstore #29
    //   612: lload #27
    //   614: lload #29
    //   616: land
    //   617: lconst_0
    //   618: lcmp
    //   619: ifne -> 652
    //   622: lload #23
    //   624: lstore #25
    //   626: aload #33
    //   628: getfield b : I
    //   631: iload #14
    //   633: iconst_1
    //   634: iadd
    //   635: if_icmpne -> 645
    //   638: lload #23
    //   640: lload #29
    //   642: lor
    //   643: lstore #25
    //   645: lload #25
    //   647: lstore #23
    //   649: goto -> 718
    //   652: iload #15
    //   654: ifeq -> 694
    //   657: aload #33
    //   659: getfield e : Z
    //   662: ifeq -> 694
    //   665: iload #13
    //   667: iconst_1
    //   668: if_icmpne -> 694
    //   671: aload_0
    //   672: getfield z : I
    //   675: istore #5
    //   677: aload #32
    //   679: iload #5
    //   681: iload #21
    //   683: iadd
    //   684: iconst_0
    //   685: iload #5
    //   687: iconst_0
    //   688: invokevirtual setPadding : (IIII)V
    //   691: goto -> 694
    //   694: aload #33
    //   696: aload #33
    //   698: getfield b : I
    //   701: iconst_1
    //   702: iadd
    //   703: putfield b : I
    //   706: aload #33
    //   708: iconst_1
    //   709: putfield f : Z
    //   712: iload #13
    //   714: iconst_1
    //   715: isub
    //   716: istore #13
    //   718: iload_1
    //   719: iconst_1
    //   720: iadd
    //   721: istore_1
    //   722: goto -> 583
    //   725: iload_2
    //   726: istore #5
    //   728: iconst_1
    //   729: istore_2
    //   730: goto -> 408
    //   733: iload_2
    //   734: istore_1
    //   735: iload #5
    //   737: istore_2
    //   738: iload #7
    //   740: ifne -> 755
    //   743: iload #11
    //   745: iconst_1
    //   746: if_icmpne -> 755
    //   749: iconst_1
    //   750: istore #5
    //   752: goto -> 758
    //   755: iconst_0
    //   756: istore #5
    //   758: iload #13
    //   760: ifle -> 1105
    //   763: lload #23
    //   765: lconst_0
    //   766: lcmp
    //   767: ifeq -> 1105
    //   770: iload #13
    //   772: iload #11
    //   774: iconst_1
    //   775: isub
    //   776: if_icmplt -> 790
    //   779: iload #5
    //   781: ifne -> 790
    //   784: iload #10
    //   786: iconst_1
    //   787: if_icmple -> 1105
    //   790: lload #23
    //   792: invokestatic bitCount : (J)I
    //   795: i2f
    //   796: fstore #4
    //   798: iload #5
    //   800: ifne -> 893
    //   803: fload #4
    //   805: fstore_3
    //   806: lload #23
    //   808: lconst_1
    //   809: land
    //   810: lconst_0
    //   811: lcmp
    //   812: ifeq -> 841
    //   815: fload #4
    //   817: fstore_3
    //   818: aload_0
    //   819: iconst_0
    //   820: invokevirtual getChildAt : (I)Landroid/view/View;
    //   823: invokevirtual getLayoutParams : ()Landroid/view/ViewGroup$LayoutParams;
    //   826: checkcast androidx/appcompat/widget/ActionMenuView$c
    //   829: getfield e : Z
    //   832: ifne -> 841
    //   835: fload #4
    //   837: ldc 0.5
    //   839: fsub
    //   840: fstore_3
    //   841: iload #22
    //   843: iconst_1
    //   844: isub
    //   845: istore #5
    //   847: fload_3
    //   848: fstore #4
    //   850: lload #23
    //   852: iconst_1
    //   853: iload #5
    //   855: ishl
    //   856: i2l
    //   857: land
    //   858: lconst_0
    //   859: lcmp
    //   860: ifeq -> 893
    //   863: fload_3
    //   864: fstore #4
    //   866: aload_0
    //   867: iload #5
    //   869: invokevirtual getChildAt : (I)Landroid/view/View;
    //   872: invokevirtual getLayoutParams : ()Landroid/view/ViewGroup$LayoutParams;
    //   875: checkcast androidx/appcompat/widget/ActionMenuView$c
    //   878: getfield e : Z
    //   881: ifne -> 893
    //   884: fload_3
    //   885: ldc 0.5
    //   887: fsub
    //   888: fstore #4
    //   890: goto -> 893
    //   893: fload #4
    //   895: fconst_0
    //   896: fcmpl
    //   897: ifle -> 915
    //   900: iload #13
    //   902: iload #21
    //   904: imul
    //   905: i2f
    //   906: fload #4
    //   908: fdiv
    //   909: f2i
    //   910: istore #5
    //   912: goto -> 918
    //   915: iconst_0
    //   916: istore #5
    //   918: iconst_0
    //   919: istore #7
    //   921: iload_1
    //   922: istore #8
    //   924: iload #7
    //   926: iload #22
    //   928: if_icmpge -> 1108
    //   931: lload #23
    //   933: iconst_1
    //   934: iload #7
    //   936: ishl
    //   937: i2l
    //   938: land
    //   939: lconst_0
    //   940: lcmp
    //   941: ifne -> 950
    //   944: iload_1
    //   945: istore #8
    //   947: goto -> 1093
    //   950: aload_0
    //   951: iload #7
    //   953: invokevirtual getChildAt : (I)Landroid/view/View;
    //   956: astore #32
    //   958: aload #32
    //   960: invokevirtual getLayoutParams : ()Landroid/view/ViewGroup$LayoutParams;
    //   963: checkcast androidx/appcompat/widget/ActionMenuView$c
    //   966: astore #33
    //   968: aload #32
    //   970: instanceof androidx/appcompat/view/menu/ActionMenuItemView
    //   973: ifeq -> 1018
    //   976: aload #33
    //   978: iload #5
    //   980: putfield c : I
    //   983: aload #33
    //   985: iconst_1
    //   986: putfield f : Z
    //   989: iload #7
    //   991: ifne -> 1015
    //   994: aload #33
    //   996: getfield e : Z
    //   999: ifne -> 1015
    //   1002: aload #33
    //   1004: iload #5
    //   1006: ineg
    //   1007: iconst_2
    //   1008: idiv
    //   1009: putfield leftMargin : I
    //   1012: goto -> 1015
    //   1015: goto -> 1049
    //   1018: aload #33
    //   1020: getfield a : Z
    //   1023: ifeq -> 1055
    //   1026: aload #33
    //   1028: iload #5
    //   1030: putfield c : I
    //   1033: aload #33
    //   1035: iconst_1
    //   1036: putfield f : Z
    //   1039: aload #33
    //   1041: iload #5
    //   1043: ineg
    //   1044: iconst_2
    //   1045: idiv
    //   1046: putfield rightMargin : I
    //   1049: iconst_1
    //   1050: istore #8
    //   1052: goto -> 1093
    //   1055: iload #7
    //   1057: ifeq -> 1069
    //   1060: aload #33
    //   1062: iload #5
    //   1064: iconst_2
    //   1065: idiv
    //   1066: putfield leftMargin : I
    //   1069: iload_1
    //   1070: istore #8
    //   1072: iload #7
    //   1074: iload #22
    //   1076: iconst_1
    //   1077: isub
    //   1078: if_icmpeq -> 1093
    //   1081: aload #33
    //   1083: iload #5
    //   1085: iconst_2
    //   1086: idiv
    //   1087: putfield rightMargin : I
    //   1090: iload_1
    //   1091: istore #8
    //   1093: iload #7
    //   1095: iconst_1
    //   1096: iadd
    //   1097: istore #7
    //   1099: iload #8
    //   1101: istore_1
    //   1102: goto -> 921
    //   1105: iload_1
    //   1106: istore #8
    //   1108: iload #8
    //   1110: ifeq -> 1182
    //   1113: iconst_0
    //   1114: istore_1
    //   1115: iload_1
    //   1116: iload #22
    //   1118: if_icmpge -> 1182
    //   1121: aload_0
    //   1122: iload_1
    //   1123: invokevirtual getChildAt : (I)Landroid/view/View;
    //   1126: astore #32
    //   1128: aload #32
    //   1130: invokevirtual getLayoutParams : ()Landroid/view/ViewGroup$LayoutParams;
    //   1133: checkcast androidx/appcompat/widget/ActionMenuView$c
    //   1136: astore #33
    //   1138: aload #33
    //   1140: getfield f : Z
    //   1143: ifne -> 1149
    //   1146: goto -> 1175
    //   1149: aload #32
    //   1151: aload #33
    //   1153: getfield b : I
    //   1156: iload #21
    //   1158: imul
    //   1159: aload #33
    //   1161: getfield c : I
    //   1164: iadd
    //   1165: ldc 1073741824
    //   1167: invokestatic makeMeasureSpec : (II)I
    //   1170: iload #20
    //   1172: invokevirtual measure : (II)V
    //   1175: iload_1
    //   1176: iconst_1
    //   1177: iadd
    //   1178: istore_1
    //   1179: goto -> 1115
    //   1182: iload #12
    //   1184: ldc 1073741824
    //   1186: if_icmpeq -> 1192
    //   1189: goto -> 1195
    //   1192: iload #6
    //   1194: istore_2
    //   1195: aload_0
    //   1196: iload #9
    //   1198: iload_2
    //   1199: invokevirtual setMeasuredDimension : (II)V
    //   1202: return
  }
  
  protected c A() {
    c c1 = new c(-2, -2);
    c1.gravity = 16;
    return c1;
  }
  
  public c B(AttributeSet paramAttributeSet) {
    return new c(getContext(), paramAttributeSet);
  }
  
  protected c C(ViewGroup.LayoutParams paramLayoutParams) {
    if (paramLayoutParams != null) {
      c c1;
      if (paramLayoutParams instanceof c) {
        c1 = new c((c)paramLayoutParams);
      } else {
        c1 = new c((ViewGroup.LayoutParams)c1);
      } 
      if (c1.gravity <= 0)
        c1.gravity = 16; 
      return c1;
    } 
    return A();
  }
  
  public c D() {
    c c1 = A();
    c1.a = true;
    return c1;
  }
  
  protected boolean E(int paramInt) {
    boolean bool;
    int j = 0;
    if (paramInt == 0)
      return false; 
    View view1 = getChildAt(paramInt - 1);
    View view2 = getChildAt(paramInt);
    int i = j;
    if (paramInt < getChildCount()) {
      i = j;
      if (view1 instanceof a)
        i = false | ((a)view1).a(); 
    } 
    j = i;
    if (paramInt > 0) {
      j = i;
      if (view2 instanceof a)
        bool = i | ((a)view2).b(); 
    } 
    return bool;
  }
  
  public boolean F() {
    c c1 = this.t;
    return (c1 != null && c1.D());
  }
  
  public boolean G() {
    c c1 = this.t;
    return (c1 != null && c1.F());
  }
  
  public boolean H() {
    c c1 = this.t;
    return (c1 != null && c1.G());
  }
  
  public boolean I() {
    return this.s;
  }
  
  public g L() {
    return this.p;
  }
  
  public void M(m.a parama, g.a parama1) {
    this.u = parama;
    this.v = parama1;
  }
  
  public boolean N() {
    c c1 = this.t;
    return (c1 != null && c1.M());
  }
  
  public boolean a(i parami) {
    return this.p.N((MenuItem)parami, 0);
  }
  
  public void b(g paramg) {
    this.p = paramg;
  }
  
  protected boolean checkLayoutParams(ViewGroup.LayoutParams paramLayoutParams) {
    return paramLayoutParams instanceof c;
  }
  
  public boolean dispatchPopulateAccessibilityEvent(AccessibilityEvent paramAccessibilityEvent) {
    return false;
  }
  
  public Menu getMenu() {
    if (this.p == null) {
      Context context = getContext();
      g g1 = new g(context);
      this.p = g1;
      g1.V(new d(this));
      c c1 = new c(context);
      this.t = c1;
      c1.L(true);
      c c2 = this.t;
      m.a a1 = this.u;
      if (a1 == null)
        a1 = new b(); 
      c2.g(a1);
      this.p.c((m)this.t, this.q);
      this.t.J(this);
    } 
    return (Menu)this.p;
  }
  
  public Drawable getOverflowIcon() {
    getMenu();
    return this.t.C();
  }
  
  public int getPopupTheme() {
    return this.r;
  }
  
  public int getWindowAnimations() {
    return 0;
  }
  
  public void onConfigurationChanged(Configuration paramConfiguration) {
    super.onConfigurationChanged(paramConfiguration);
    c c1 = this.t;
    if (c1 != null) {
      c1.c(false);
      if (this.t.G()) {
        this.t.D();
        this.t.M();
      } 
    } 
  }
  
  public void onDetachedFromWindow() {
    super.onDetachedFromWindow();
    z();
  }
  
  protected void onLayout(boolean paramBoolean, int paramInt1, int paramInt2, int paramInt3, int paramInt4) {
    if (!this.w) {
      super.onLayout(paramBoolean, paramInt1, paramInt2, paramInt3, paramInt4);
      return;
    } 
    int j = getChildCount();
    int i = (paramInt4 - paramInt2) / 2;
    int k = getDividerWidth();
    int m = paramInt3 - paramInt1;
    paramInt1 = m - getPaddingRight() - getPaddingLeft();
    paramBoolean = m2.b((View)this);
    paramInt2 = 0;
    paramInt4 = 0;
    paramInt3 = 0;
    while (paramInt2 < j) {
      View view = getChildAt(paramInt2);
      if (view.getVisibility() != 8) {
        c c1 = (c)view.getLayoutParams();
        if (c1.a) {
          int i2;
          int i1 = view.getMeasuredWidth();
          paramInt4 = i1;
          if (E(paramInt2))
            paramInt4 = i1 + k; 
          int i3 = view.getMeasuredHeight();
          if (paramBoolean) {
            i2 = getPaddingLeft() + c1.leftMargin;
            i1 = i2 + paramInt4;
          } else {
            i1 = getWidth() - getPaddingRight() - c1.rightMargin;
            i2 = i1 - paramInt4;
          } 
          int i4 = i - i3 / 2;
          view.layout(i2, i4, i1, i3 + i4);
          paramInt1 -= paramInt4;
          paramInt4 = 1;
        } else {
          paramInt1 -= view.getMeasuredWidth() + c1.leftMargin + c1.rightMargin;
          E(paramInt2);
          paramInt3++;
        } 
      } 
      paramInt2++;
    } 
    if (j == 1 && paramInt4 == 0) {
      View view = getChildAt(0);
      paramInt1 = view.getMeasuredWidth();
      paramInt2 = view.getMeasuredHeight();
      paramInt3 = m / 2 - paramInt1 / 2;
      paramInt4 = i - paramInt2 / 2;
      view.layout(paramInt3, paramInt4, paramInt1 + paramInt3, paramInt2 + paramInt4);
      return;
    } 
    paramInt2 = paramInt3 - (paramInt4 ^ 0x1);
    if (paramInt2 > 0) {
      paramInt1 /= paramInt2;
    } else {
      paramInt1 = 0;
    } 
    paramInt4 = Math.max(0, paramInt1);
    if (paramBoolean) {
      paramInt2 = getWidth() - getPaddingRight();
      paramInt1 = 0;
      while (paramInt1 < j) {
        View view = getChildAt(paramInt1);
        c c1 = (c)view.getLayoutParams();
        paramInt3 = paramInt2;
        if (view.getVisibility() != 8)
          if (c1.a) {
            paramInt3 = paramInt2;
          } else {
            paramInt2 -= c1.rightMargin;
            paramInt3 = view.getMeasuredWidth();
            int i1 = view.getMeasuredHeight();
            int i2 = i - i1 / 2;
            view.layout(paramInt2 - paramInt3, i2, paramInt2, i1 + i2);
            paramInt3 = paramInt2 - paramInt3 + c1.leftMargin + paramInt4;
          }  
        paramInt1++;
        paramInt2 = paramInt3;
      } 
    } else {
      paramInt2 = getPaddingLeft();
      paramInt1 = 0;
      while (paramInt1 < j) {
        View view = getChildAt(paramInt1);
        c c1 = (c)view.getLayoutParams();
        paramInt3 = paramInt2;
        if (view.getVisibility() != 8)
          if (c1.a) {
            paramInt3 = paramInt2;
          } else {
            paramInt2 += c1.leftMargin;
            paramInt3 = view.getMeasuredWidth();
            int i1 = view.getMeasuredHeight();
            int i2 = i - i1 / 2;
            view.layout(paramInt2, i2, paramInt2 + paramInt3, i1 + i2);
            paramInt3 = paramInt2 + paramInt3 + c1.rightMargin + paramInt4;
          }  
        paramInt1++;
        paramInt2 = paramInt3;
      } 
    } 
  }
  
  protected void onMeasure(int paramInt1, int paramInt2) {
    boolean bool1;
    boolean bool2 = this.w;
    if (View.MeasureSpec.getMode(paramInt1) == 1073741824) {
      bool1 = true;
    } else {
      bool1 = false;
    } 
    this.w = bool1;
    if (bool2 != bool1)
      this.x = 0; 
    int i = View.MeasureSpec.getSize(paramInt1);
    if (this.w) {
      g g1 = this.p;
      if (g1 != null && i != this.x) {
        this.x = i;
        g1.M(true);
      } 
    } 
    int j = getChildCount();
    if (this.w && j > 0) {
      K(paramInt1, paramInt2);
      return;
    } 
    for (i = 0; i < j; i++) {
      c c1 = (c)getChildAt(i).getLayoutParams();
      c1.rightMargin = 0;
      c1.leftMargin = 0;
    } 
    super.onMeasure(paramInt1, paramInt2);
  }
  
  public void setExpandedActionViewsExclusive(boolean paramBoolean) {
    this.t.I(paramBoolean);
  }
  
  public void setOnMenuItemClickListener(e parame) {
    this.A = parame;
  }
  
  public void setOverflowIcon(Drawable paramDrawable) {
    getMenu();
    this.t.K(paramDrawable);
  }
  
  public void setOverflowReserved(boolean paramBoolean) {
    this.s = paramBoolean;
  }
  
  public void setPopupTheme(int paramInt) {
    if (this.r != paramInt) {
      this.r = paramInt;
      if (paramInt == 0) {
        this.q = getContext();
        return;
      } 
      this.q = (Context)new ContextThemeWrapper(getContext(), paramInt);
    } 
  }
  
  public void setPresenter(c paramc) {
    this.t = paramc;
    paramc.J(this);
  }
  
  public void z() {
    c c1 = this.t;
    if (c1 != null)
      c1.A(); 
  }
  
  public static interface a {
    boolean a();
    
    boolean b();
  }
  
  private static class b implements m.a {
    public void b(g param1g, boolean param1Boolean) {}
    
    public boolean c(g param1g) {
      return false;
    }
  }
  
  public static class c extends LinearLayoutCompat.a {
    @ExportedProperty
    public boolean a;
    
    @ExportedProperty
    public int b;
    
    @ExportedProperty
    public int c;
    
    @ExportedProperty
    public boolean d;
    
    @ExportedProperty
    public boolean e;
    
    boolean f;
    
    public c(int param1Int1, int param1Int2) {
      super(param1Int1, param1Int2);
      this.a = false;
    }
    
    public c(Context param1Context, AttributeSet param1AttributeSet) {
      super(param1Context, param1AttributeSet);
    }
    
    public c(ViewGroup.LayoutParams param1LayoutParams) {
      super(param1LayoutParams);
    }
    
    public c(c param1c) {
      super((ViewGroup.LayoutParams)param1c);
      this.a = param1c.a;
    }
  }
  
  private class d implements g.a {
    d(ActionMenuView this$0) {}
    
    public boolean a(g param1g, MenuItem param1MenuItem) {
      ActionMenuView.e e = this.a.A;
      return (e != null && e.onMenuItemClick(param1MenuItem));
    }
    
    public void b(g param1g) {
      g.a a1 = this.a.v;
      if (a1 != null)
        a1.b(param1g); 
    }
  }
  
  public static interface e {
    boolean onMenuItemClick(MenuItem param1MenuItem);
  }
}


/* Location:              C:\soft\dex2jar-2.0\Cricket Scorer-dex2jar.jar!\androidx\appcompat\widget\ActionMenuView.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */