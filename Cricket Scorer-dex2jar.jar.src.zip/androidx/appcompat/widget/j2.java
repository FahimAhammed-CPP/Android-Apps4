package androidx.appcompat.widget;

import android.text.TextUtils;
import android.util.Log;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewConfiguration;
import android.view.accessibility.AccessibilityManager;
import androidx.core.view.i2;
import androidx.core.view.o0;

class j2 implements View.OnLongClickListener, View.OnHoverListener, View.OnAttachStateChangeListener {
  private static j2 k;
  
  private static j2 l;
  
  private final View a;
  
  private final CharSequence b;
  
  private final int c;
  
  private final Runnable d = new h2(this);
  
  private final Runnable e = new i2(this);
  
  private int f;
  
  private int g;
  
  private k2 h;
  
  private boolean i;
  
  private boolean j;
  
  private j2(View paramView, CharSequence paramCharSequence) {
    this.a = paramView;
    this.b = paramCharSequence;
    this.c = i2.c(ViewConfiguration.get(paramView.getContext()));
    c();
    paramView.setOnLongClickListener(this);
    paramView.setOnHoverListener(this);
  }
  
  private void b() {
    this.a.removeCallbacks(this.d);
  }
  
  private void c() {
    this.j = true;
  }
  
  private void f() {
    this.a.postDelayed(this.d, ViewConfiguration.getLongPressTimeout());
  }
  
  private static void g(j2 paramj2) {
    j2 j21 = k;
    if (j21 != null)
      j21.b(); 
    k = paramj2;
    if (paramj2 != null)
      paramj2.f(); 
  }
  
  public static void h(View paramView, CharSequence paramCharSequence) {
    j2 j21;
    j2 j22 = k;
    if (j22 != null && j22.a == paramView)
      g(null); 
    if (TextUtils.isEmpty(paramCharSequence)) {
      j21 = l;
      if (j21 != null && j21.a == paramView)
        j21.d(); 
      paramView.setOnLongClickListener(null);
      paramView.setLongClickable(false);
      paramView.setOnHoverListener(null);
      return;
    } 
    new j2(paramView, (CharSequence)j21);
  }
  
  private boolean j(MotionEvent paramMotionEvent) {
    int i = (int)paramMotionEvent.getX();
    int j = (int)paramMotionEvent.getY();
    if (this.j || Math.abs(i - this.f) > this.c || Math.abs(j - this.g) > this.c) {
      this.f = i;
      this.g = j;
      this.j = false;
      return true;
    } 
    return false;
  }
  
  void d() {
    if (l == this) {
      l = null;
      k2 k21 = this.h;
      if (k21 != null) {
        k21.c();
        this.h = null;
        c();
        this.a.removeOnAttachStateChangeListener(this);
      } else {
        Log.e("TooltipCompatHandler", "sActiveHandler.mPopup == null");
      } 
    } 
    if (k == this)
      g(null); 
    this.a.removeCallbacks(this.e);
  }
  
  void i(boolean paramBoolean) {
    long l;
    if (!o0.U(this.a))
      return; 
    g(null);
    j2 j21 = l;
    if (j21 != null)
      j21.d(); 
    l = this;
    this.i = paramBoolean;
    k2 k21 = new k2(this.a.getContext());
    this.h = k21;
    k21.e(this.a, this.f, this.g, this.i, this.b);
    this.a.addOnAttachStateChangeListener(this);
    if (this.i) {
      l = 2500L;
    } else {
      int i;
      if ((o0.N(this.a) & 0x1) == 1) {
        l = 3000L;
        i = ViewConfiguration.getLongPressTimeout();
      } else {
        l = 15000L;
        i = ViewConfiguration.getLongPressTimeout();
      } 
      l -= i;
    } 
    this.a.removeCallbacks(this.e);
    this.a.postDelayed(this.e, l);
  }
  
  public boolean onHover(View paramView, MotionEvent paramMotionEvent) {
    if (this.h != null && this.i)
      return false; 
    AccessibilityManager accessibilityManager = (AccessibilityManager)this.a.getContext().getSystemService("accessibility");
    if (accessibilityManager.isEnabled() && accessibilityManager.isTouchExplorationEnabled())
      return false; 
    int i = paramMotionEvent.getAction();
    if (i != 7) {
      if (i != 10)
        return false; 
      c();
      d();
      return false;
    } 
    if (this.a.isEnabled() && this.h == null && j(paramMotionEvent))
      g(this); 
    return false;
  }
  
  public boolean onLongClick(View paramView) {
    this.f = paramView.getWidth() / 2;
    this.g = paramView.getHeight() / 2;
    i(true);
    return true;
  }
  
  public void onViewAttachedToWindow(View paramView) {}
  
  public void onViewDetachedFromWindow(View paramView) {
    d();
  }
}


/* Location:              C:\soft\dex2jar-2.0\Cricket Scorer-dex2jar.jar!\androidx\appcompat\widget\j2.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */