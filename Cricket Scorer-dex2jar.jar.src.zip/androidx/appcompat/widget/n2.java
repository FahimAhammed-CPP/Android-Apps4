package androidx.appcompat.widget;

public interface n2 {
  CharSequence a();
}


/* Location:              C:\soft\dex2jar-2.0\Cricket Scorer-dex2jar.jar!\androidx\appcompat\widget\n2.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */