package androidx.appcompat.widget;

import android.content.Context;
import android.content.res.ColorStateList;
import android.graphics.drawable.Drawable;
import android.os.Parcel;
import android.os.Parcelable;
import android.text.TextUtils;
import android.util.AttributeSet;
import android.view.ContextThemeWrapper;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.view.ViewParent;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.TextView;
import androidx.appcompat.view.menu.i;
import androidx.appcompat.view.menu.m;
import androidx.appcompat.view.menu.r;
import androidx.core.view.b0;
import androidx.core.view.i;
import androidx.core.view.j;
import androidx.core.view.m;
import androidx.core.view.o0;
import e.j;
import java.util.ArrayList;
import java.util.List;

public class Toolbar extends ViewGroup implements j {
  private ColorStateList A;
  
  private boolean B;
  
  private boolean C;
  
  private final ArrayList<View> D = new ArrayList<View>();
  
  private final ArrayList<View> E = new ArrayList<View>();
  
  private final int[] F = new int[2];
  
  final m G = new m(new d2(this));
  
  private ArrayList<MenuItem> H = new ArrayList<MenuItem>();
  
  f I;
  
  private final ActionMenuView.e J = new a(this);
  
  private e2 K;
  
  private c L;
  
  private d M;
  
  private m.a N;
  
  private androidx.appcompat.view.menu.g.a O;
  
  private boolean P;
  
  private final Runnable Q = new b(this);
  
  private ActionMenuView a;
  
  private TextView b;
  
  private TextView c;
  
  private ImageButton d;
  
  private ImageView e;
  
  private Drawable f;
  
  private CharSequence g;
  
  ImageButton h;
  
  View i;
  
  private Context j;
  
  private int k;
  
  private int l;
  
  private int m;
  
  int n;
  
  private int o;
  
  private int p;
  
  private int q;
  
  private int r;
  
  private int s;
  
  private t1 t;
  
  private int u;
  
  private int v;
  
  private int w = 8388627;
  
  private CharSequence x;
  
  private CharSequence y;
  
  private ColorStateList z;
  
  public Toolbar(Context paramContext, AttributeSet paramAttributeSet) {
    this(paramContext, paramAttributeSet, e.a.Q);
  }
  
  public Toolbar(Context paramContext, AttributeSet paramAttributeSet, int paramInt) {
    super(paramContext, paramAttributeSet, paramInt);
    Context context = getContext();
    int[] arrayOfInt = j.n3;
    c2 c2 = c2.v(context, paramAttributeSet, arrayOfInt, paramInt, 0);
    o0.p0((View)this, paramContext, arrayOfInt, paramAttributeSet, c2.r(), paramInt, 0);
    this.l = c2.n(j.P3, 0);
    this.m = c2.n(j.G3, 0);
    this.w = c2.l(j.o3, this.w);
    this.n = c2.l(j.p3, 48);
    int i = c2.e(j.J3, 0);
    int k = j.O3;
    paramInt = i;
    if (c2.s(k))
      paramInt = c2.e(k, i); 
    this.s = paramInt;
    this.r = paramInt;
    this.q = paramInt;
    this.p = paramInt;
    paramInt = c2.e(j.M3, -1);
    if (paramInt >= 0)
      this.p = paramInt; 
    paramInt = c2.e(j.L3, -1);
    if (paramInt >= 0)
      this.q = paramInt; 
    paramInt = c2.e(j.N3, -1);
    if (paramInt >= 0)
      this.r = paramInt; 
    paramInt = c2.e(j.K3, -1);
    if (paramInt >= 0)
      this.s = paramInt; 
    this.o = c2.f(j.A3, -1);
    paramInt = c2.e(j.w3, -2147483648);
    i = c2.e(j.s3, -2147483648);
    k = c2.f(j.u3, 0);
    int n = c2.f(j.v3, 0);
    h();
    this.t.e(k, n);
    if (paramInt != Integer.MIN_VALUE || i != Integer.MIN_VALUE)
      this.t.g(paramInt, i); 
    this.u = c2.e(j.x3, -2147483648);
    this.v = c2.e(j.t3, -2147483648);
    this.f = c2.g(j.r3);
    this.g = c2.p(j.q3);
    CharSequence charSequence3 = c2.p(j.I3);
    if (!TextUtils.isEmpty(charSequence3))
      setTitle(charSequence3); 
    charSequence3 = c2.p(j.F3);
    if (!TextUtils.isEmpty(charSequence3))
      setSubtitle(charSequence3); 
    this.j = getContext();
    setPopupTheme(c2.n(j.E3, 0));
    Drawable drawable2 = c2.g(j.D3);
    if (drawable2 != null)
      setNavigationIcon(drawable2); 
    CharSequence charSequence2 = c2.p(j.C3);
    if (!TextUtils.isEmpty(charSequence2))
      setNavigationContentDescription(charSequence2); 
    Drawable drawable1 = c2.g(j.y3);
    if (drawable1 != null)
      setLogo(drawable1); 
    CharSequence charSequence1 = c2.p(j.z3);
    if (!TextUtils.isEmpty(charSequence1))
      setLogoDescription(charSequence1); 
    paramInt = j.Q3;
    if (c2.s(paramInt))
      setTitleTextColor(c2.c(paramInt)); 
    paramInt = j.H3;
    if (c2.s(paramInt))
      setSubtitleTextColor(c2.c(paramInt)); 
    paramInt = j.B3;
    if (c2.s(paramInt))
      x(c2.n(paramInt, 0)); 
    c2.w();
  }
  
  private int C(View paramView, int paramInt1, int[] paramArrayOfint, int paramInt2) {
    e e1 = (e)paramView.getLayoutParams();
    int i = ((ViewGroup.MarginLayoutParams)e1).leftMargin - paramArrayOfint[0];
    paramInt1 += Math.max(0, i);
    paramArrayOfint[0] = Math.max(0, -i);
    paramInt2 = q(paramView, paramInt2);
    i = paramView.getMeasuredWidth();
    paramView.layout(paramInt1, paramInt2, paramInt1 + i, paramView.getMeasuredHeight() + paramInt2);
    return paramInt1 + i + ((ViewGroup.MarginLayoutParams)e1).rightMargin;
  }
  
  private int D(View paramView, int paramInt1, int[] paramArrayOfint, int paramInt2) {
    e e1 = (e)paramView.getLayoutParams();
    int i = ((ViewGroup.MarginLayoutParams)e1).rightMargin - paramArrayOfint[1];
    paramInt1 -= Math.max(0, i);
    paramArrayOfint[1] = Math.max(0, -i);
    paramInt2 = q(paramView, paramInt2);
    i = paramView.getMeasuredWidth();
    paramView.layout(paramInt1 - i, paramInt2, paramInt1, paramView.getMeasuredHeight() + paramInt2);
    return paramInt1 - i + ((ViewGroup.MarginLayoutParams)e1).leftMargin;
  }
  
  private int E(View paramView, int paramInt1, int paramInt2, int paramInt3, int paramInt4, int[] paramArrayOfint) {
    ViewGroup.MarginLayoutParams marginLayoutParams = (ViewGroup.MarginLayoutParams)paramView.getLayoutParams();
    int i = marginLayoutParams.leftMargin - paramArrayOfint[0];
    int k = marginLayoutParams.rightMargin - paramArrayOfint[1];
    int n = Math.max(0, i) + Math.max(0, k);
    paramArrayOfint[0] = Math.max(0, -i);
    paramArrayOfint[1] = Math.max(0, -k);
    paramView.measure(ViewGroup.getChildMeasureSpec(paramInt1, getPaddingLeft() + getPaddingRight() + n + paramInt2, marginLayoutParams.width), ViewGroup.getChildMeasureSpec(paramInt3, getPaddingTop() + getPaddingBottom() + marginLayoutParams.topMargin + marginLayoutParams.bottomMargin + paramInt4, marginLayoutParams.height));
    return paramView.getMeasuredWidth() + n;
  }
  
  private void F(View paramView, int paramInt1, int paramInt2, int paramInt3, int paramInt4, int paramInt5) {
    ViewGroup.MarginLayoutParams marginLayoutParams = (ViewGroup.MarginLayoutParams)paramView.getLayoutParams();
    int i = ViewGroup.getChildMeasureSpec(paramInt1, getPaddingLeft() + getPaddingRight() + marginLayoutParams.leftMargin + marginLayoutParams.rightMargin + paramInt2, marginLayoutParams.width);
    paramInt2 = ViewGroup.getChildMeasureSpec(paramInt3, getPaddingTop() + getPaddingBottom() + marginLayoutParams.topMargin + marginLayoutParams.bottomMargin + paramInt4, marginLayoutParams.height);
    paramInt3 = View.MeasureSpec.getMode(paramInt2);
    paramInt1 = paramInt2;
    if (paramInt3 != 1073741824) {
      paramInt1 = paramInt2;
      if (paramInt5 >= 0) {
        paramInt1 = paramInt5;
        if (paramInt3 != 0)
          paramInt1 = Math.min(View.MeasureSpec.getSize(paramInt2), paramInt5); 
        paramInt1 = View.MeasureSpec.makeMeasureSpec(paramInt1, 1073741824);
      } 
    } 
    paramView.measure(i, paramInt1);
  }
  
  private void G() {
    Menu menu = getMenu();
    ArrayList<MenuItem> arrayList1 = getCurrentMenuItems();
    this.G.h(menu, getMenuInflater());
    ArrayList<MenuItem> arrayList2 = getCurrentMenuItems();
    arrayList2.removeAll(arrayList1);
    this.H = arrayList2;
    this.G.k(menu);
  }
  
  private void H() {
    removeCallbacks(this.Q);
    post(this.Q);
  }
  
  private boolean O() {
    if (!this.P)
      return false; 
    int k = getChildCount();
    for (int i = 0; i < k; i++) {
      View view = getChildAt(i);
      if (P(view) && view.getMeasuredWidth() > 0 && view.getMeasuredHeight() > 0)
        return false; 
    } 
    return true;
  }
  
  private boolean P(View paramView) {
    return (paramView != null && paramView.getParent() == this && paramView.getVisibility() != 8);
  }
  
  private void b(List<View> paramList, int paramInt) {
    int i = o0.E((View)this);
    boolean bool = false;
    if (i == 1) {
      i = 1;
    } else {
      i = 0;
    } 
    int n = getChildCount();
    int k = androidx.core.view.f.b(paramInt, o0.E((View)this));
    paramList.clear();
    paramInt = bool;
    if (i != 0) {
      for (paramInt = n - 1; paramInt >= 0; paramInt--) {
        View view = getChildAt(paramInt);
        e e1 = (e)view.getLayoutParams();
        if (e1.b == 0 && P(view) && p(e1.a) == k)
          paramList.add(view); 
      } 
    } else {
      while (paramInt < n) {
        View view = getChildAt(paramInt);
        e e1 = (e)view.getLayoutParams();
        if (e1.b == 0 && P(view) && p(e1.a) == k)
          paramList.add(view); 
        paramInt++;
      } 
    } 
  }
  
  private void c(View paramView, boolean paramBoolean) {
    e e1;
    ViewGroup.LayoutParams layoutParams = paramView.getLayoutParams();
    if (layoutParams == null) {
      e1 = m();
    } else if (!checkLayoutParams((ViewGroup.LayoutParams)e1)) {
      e1 = o((ViewGroup.LayoutParams)e1);
    } else {
      e1 = e1;
    } 
    e1.b = 1;
    if (paramBoolean && this.i != null) {
      paramView.setLayoutParams((ViewGroup.LayoutParams)e1);
      this.E.add(paramView);
      return;
    } 
    addView(paramView, (ViewGroup.LayoutParams)e1);
  }
  
  private ArrayList<MenuItem> getCurrentMenuItems() {
    ArrayList<MenuItem> arrayList = new ArrayList();
    Menu menu = getMenu();
    for (int i = 0; i < menu.size(); i++)
      arrayList.add(menu.getItem(i)); 
    return arrayList;
  }
  
  private MenuInflater getMenuInflater() {
    return (MenuInflater)new androidx.appcompat.view.g(getContext());
  }
  
  private void h() {
    if (this.t == null)
      this.t = new t1(); 
  }
  
  private void i() {
    if (this.e == null)
      this.e = new AppCompatImageView(getContext()); 
  }
  
  private void j() {
    k();
    if (this.a.L() == null) {
      androidx.appcompat.view.menu.g g = (androidx.appcompat.view.menu.g)this.a.getMenu();
      if (this.M == null)
        this.M = new d(this); 
      this.a.setExpandedActionViewsExclusive(true);
      g.c(this.M, this.j);
    } 
  }
  
  private void k() {
    if (this.a == null) {
      ActionMenuView actionMenuView = new ActionMenuView(getContext());
      this.a = actionMenuView;
      actionMenuView.setPopupTheme(this.k);
      this.a.setOnMenuItemClickListener(this.J);
      this.a.M(this.N, this.O);
      e e1 = m();
      e1.a = 0x800005 | this.n & 0x70;
      this.a.setLayoutParams((ViewGroup.LayoutParams)e1);
      c((View)this.a, false);
    } 
  }
  
  private void l() {
    if (this.d == null) {
      this.d = new AppCompatImageButton(getContext(), null, e.a.P);
      e e1 = m();
      e1.a = 0x800003 | this.n & 0x70;
      this.d.setLayoutParams((ViewGroup.LayoutParams)e1);
    } 
  }
  
  private int p(int paramInt) {
    int i = o0.E((View)this);
    int k = androidx.core.view.f.b(paramInt, i) & 0x7;
    if (k != 1) {
      paramInt = 3;
      if (k != 3 && k != 5) {
        if (i == 1)
          paramInt = 5; 
        return paramInt;
      } 
    } 
    return k;
  }
  
  private int q(View paramView, int paramInt) {
    e e1 = (e)paramView.getLayoutParams();
    int k = paramView.getMeasuredHeight();
    if (paramInt > 0) {
      paramInt = (k - paramInt) / 2;
    } else {
      paramInt = 0;
    } 
    int i = r(e1.a);
    if (i != 48) {
      if (i != 80) {
        int n = getPaddingTop();
        int i1 = getPaddingBottom();
        int i2 = getHeight();
        i = (i2 - n - i1 - k) / 2;
        paramInt = ((ViewGroup.MarginLayoutParams)e1).topMargin;
        if (i >= paramInt) {
          k = i2 - i1 - k - i - n;
          i1 = ((ViewGroup.MarginLayoutParams)e1).bottomMargin;
          paramInt = i;
          if (k < i1)
            paramInt = Math.max(0, i - i1 - k); 
        } 
        return n + paramInt;
      } 
      return getHeight() - getPaddingBottom() - k - ((ViewGroup.MarginLayoutParams)e1).bottomMargin - paramInt;
    } 
    return getPaddingTop() - paramInt;
  }
  
  private int r(int paramInt) {
    int i = paramInt & 0x70;
    paramInt = i;
    if (i != 16) {
      paramInt = i;
      if (i != 48) {
        paramInt = i;
        if (i != 80)
          paramInt = this.w & 0x70; 
      } 
    } 
    return paramInt;
  }
  
  private int s(View paramView) {
    ViewGroup.MarginLayoutParams marginLayoutParams = (ViewGroup.MarginLayoutParams)paramView.getLayoutParams();
    return i.b(marginLayoutParams) + i.a(marginLayoutParams);
  }
  
  private int t(View paramView) {
    ViewGroup.MarginLayoutParams marginLayoutParams = (ViewGroup.MarginLayoutParams)paramView.getLayoutParams();
    return marginLayoutParams.topMargin + marginLayoutParams.bottomMargin;
  }
  
  private int u(List<View> paramList, int[] paramArrayOfint) {
    int i1 = paramArrayOfint[0];
    int n = paramArrayOfint[1];
    int i2 = paramList.size();
    int i = 0;
    int k = 0;
    while (i < i2) {
      View view = paramList.get(i);
      e e1 = (e)view.getLayoutParams();
      i1 = ((ViewGroup.MarginLayoutParams)e1).leftMargin - i1;
      n = ((ViewGroup.MarginLayoutParams)e1).rightMargin - n;
      int i3 = Math.max(0, i1);
      int i4 = Math.max(0, n);
      i1 = Math.max(0, -i1);
      n = Math.max(0, -n);
      k += i3 + view.getMeasuredWidth() + i4;
      i++;
    } 
    return k;
  }
  
  private boolean z(View paramView) {
    return (paramView.getParent() == this || this.E.contains(paramView));
  }
  
  public boolean A() {
    ActionMenuView actionMenuView = this.a;
    return (actionMenuView != null && actionMenuView.G());
  }
  
  public boolean B() {
    ActionMenuView actionMenuView = this.a;
    return (actionMenuView != null && actionMenuView.H());
  }
  
  void I() {
    for (int i = getChildCount() - 1; i >= 0; i--) {
      View view = getChildAt(i);
      if (((e)view.getLayoutParams()).b != 2 && view != this.a) {
        removeViewAt(i);
        this.E.add(view);
      } 
    } 
  }
  
  public void J(int paramInt1, int paramInt2) {
    h();
    this.t.g(paramInt1, paramInt2);
  }
  
  public void K(androidx.appcompat.view.menu.g paramg, c paramc) {
    if (paramg == null && this.a == null)
      return; 
    k();
    androidx.appcompat.view.menu.g g1 = this.a.L();
    if (g1 == paramg)
      return; 
    if (g1 != null) {
      g1.Q((m)this.L);
      g1.Q(this.M);
    } 
    if (this.M == null)
      this.M = new d(this); 
    paramc.I(true);
    if (paramg != null) {
      paramg.c((m)paramc, this.j);
      paramg.c(this.M, this.j);
    } else {
      paramc.h(this.j, null);
      this.M.h(this.j, null);
      paramc.c(true);
      this.M.c(true);
    } 
    this.a.setPopupTheme(this.k);
    this.a.setPresenter(paramc);
    this.L = paramc;
  }
  
  public void L(m.a parama, androidx.appcompat.view.menu.g.a parama1) {
    this.N = parama;
    this.O = parama1;
    ActionMenuView actionMenuView = this.a;
    if (actionMenuView != null)
      actionMenuView.M(parama, parama1); 
  }
  
  public void M(Context paramContext, int paramInt) {
    this.m = paramInt;
    TextView textView = this.c;
    if (textView != null)
      textView.setTextAppearance(paramContext, paramInt); 
  }
  
  public void N(Context paramContext, int paramInt) {
    this.l = paramInt;
    TextView textView = this.b;
    if (textView != null)
      textView.setTextAppearance(paramContext, paramInt); 
  }
  
  public boolean Q() {
    ActionMenuView actionMenuView = this.a;
    return (actionMenuView != null && actionMenuView.N());
  }
  
  void a() {
    for (int i = this.E.size() - 1; i >= 0; i--)
      addView(this.E.get(i)); 
    this.E.clear();
  }
  
  public void addMenuProvider(b0 paramb0) {
    this.G.c(paramb0);
  }
  
  protected boolean checkLayoutParams(ViewGroup.LayoutParams paramLayoutParams) {
    return (super.checkLayoutParams(paramLayoutParams) && paramLayoutParams instanceof e);
  }
  
  public boolean d() {
    if (getVisibility() == 0) {
      ActionMenuView actionMenuView = this.a;
      if (actionMenuView != null && actionMenuView.I())
        return true; 
    } 
    return false;
  }
  
  public void e() {
    i i;
    d d1 = this.M;
    if (d1 == null) {
      d1 = null;
    } else {
      i = d1.b;
    } 
    if (i != null)
      i.collapseActionView(); 
  }
  
  public void f() {
    ActionMenuView actionMenuView = this.a;
    if (actionMenuView != null)
      actionMenuView.z(); 
  }
  
  void g() {
    if (this.h == null) {
      AppCompatImageButton appCompatImageButton = new AppCompatImageButton(getContext(), null, e.a.P);
      this.h = appCompatImageButton;
      appCompatImageButton.setImageDrawable(this.f);
      this.h.setContentDescription(this.g);
      e e1 = m();
      e1.a = 0x800003 | this.n & 0x70;
      e1.b = 2;
      this.h.setLayoutParams((ViewGroup.LayoutParams)e1);
      this.h.setOnClickListener(new c(this));
    } 
  }
  
  public CharSequence getCollapseContentDescription() {
    ImageButton imageButton = this.h;
    return (imageButton != null) ? imageButton.getContentDescription() : null;
  }
  
  public Drawable getCollapseIcon() {
    ImageButton imageButton = this.h;
    return (imageButton != null) ? imageButton.getDrawable() : null;
  }
  
  public int getContentInsetEnd() {
    t1 t11 = this.t;
    return (t11 != null) ? t11.a() : 0;
  }
  
  public int getContentInsetEndWithActions() {
    int i = this.v;
    return (i != Integer.MIN_VALUE) ? i : getContentInsetEnd();
  }
  
  public int getContentInsetLeft() {
    t1 t11 = this.t;
    return (t11 != null) ? t11.b() : 0;
  }
  
  public int getContentInsetRight() {
    t1 t11 = this.t;
    return (t11 != null) ? t11.c() : 0;
  }
  
  public int getContentInsetStart() {
    t1 t11 = this.t;
    return (t11 != null) ? t11.d() : 0;
  }
  
  public int getContentInsetStartWithNavigation() {
    int i = this.u;
    return (i != Integer.MIN_VALUE) ? i : getContentInsetStart();
  }
  
  public int getCurrentContentInsetEnd() {
    // Byte code:
    //   0: aload_0
    //   1: getfield a : Landroidx/appcompat/widget/ActionMenuView;
    //   4: astore_2
    //   5: aload_2
    //   6: ifnull -> 30
    //   9: aload_2
    //   10: invokevirtual L : ()Landroidx/appcompat/view/menu/g;
    //   13: astore_2
    //   14: aload_2
    //   15: ifnull -> 30
    //   18: aload_2
    //   19: invokevirtual hasVisibleItems : ()Z
    //   22: ifeq -> 30
    //   25: iconst_1
    //   26: istore_1
    //   27: goto -> 32
    //   30: iconst_0
    //   31: istore_1
    //   32: iload_1
    //   33: ifeq -> 52
    //   36: aload_0
    //   37: invokevirtual getContentInsetEnd : ()I
    //   40: aload_0
    //   41: getfield v : I
    //   44: iconst_0
    //   45: invokestatic max : (II)I
    //   48: invokestatic max : (II)I
    //   51: ireturn
    //   52: aload_0
    //   53: invokevirtual getContentInsetEnd : ()I
    //   56: ireturn
  }
  
  public int getCurrentContentInsetLeft() {
    return (o0.E((View)this) == 1) ? getCurrentContentInsetEnd() : getCurrentContentInsetStart();
  }
  
  public int getCurrentContentInsetRight() {
    return (o0.E((View)this) == 1) ? getCurrentContentInsetStart() : getCurrentContentInsetEnd();
  }
  
  public int getCurrentContentInsetStart() {
    return (getNavigationIcon() != null) ? Math.max(getContentInsetStart(), Math.max(this.u, 0)) : getContentInsetStart();
  }
  
  public Drawable getLogo() {
    ImageView imageView = this.e;
    return (imageView != null) ? imageView.getDrawable() : null;
  }
  
  public CharSequence getLogoDescription() {
    ImageView imageView = this.e;
    return (imageView != null) ? imageView.getContentDescription() : null;
  }
  
  public Menu getMenu() {
    j();
    return this.a.getMenu();
  }
  
  View getNavButtonView() {
    return (View)this.d;
  }
  
  public CharSequence getNavigationContentDescription() {
    ImageButton imageButton = this.d;
    return (imageButton != null) ? imageButton.getContentDescription() : null;
  }
  
  public Drawable getNavigationIcon() {
    ImageButton imageButton = this.d;
    return (imageButton != null) ? imageButton.getDrawable() : null;
  }
  
  c getOuterActionMenuPresenter() {
    return this.L;
  }
  
  public Drawable getOverflowIcon() {
    j();
    return this.a.getOverflowIcon();
  }
  
  Context getPopupContext() {
    return this.j;
  }
  
  public int getPopupTheme() {
    return this.k;
  }
  
  public CharSequence getSubtitle() {
    return this.y;
  }
  
  final TextView getSubtitleTextView() {
    return this.c;
  }
  
  public CharSequence getTitle() {
    return this.x;
  }
  
  public int getTitleMarginBottom() {
    return this.s;
  }
  
  public int getTitleMarginEnd() {
    return this.q;
  }
  
  public int getTitleMarginStart() {
    return this.p;
  }
  
  public int getTitleMarginTop() {
    return this.r;
  }
  
  final TextView getTitleTextView() {
    return this.b;
  }
  
  public c1 getWrapper() {
    if (this.K == null)
      this.K = new e2(this, true); 
    return this.K;
  }
  
  protected e m() {
    return new e(-2, -2);
  }
  
  public e n(AttributeSet paramAttributeSet) {
    return new e(getContext(), paramAttributeSet);
  }
  
  protected e o(ViewGroup.LayoutParams paramLayoutParams) {
    return (paramLayoutParams instanceof e) ? new e((e)paramLayoutParams) : ((paramLayoutParams instanceof androidx.appcompat.app.a.a) ? new e((androidx.appcompat.app.a.a)paramLayoutParams) : ((paramLayoutParams instanceof ViewGroup.MarginLayoutParams) ? new e((ViewGroup.MarginLayoutParams)paramLayoutParams) : new e(paramLayoutParams)));
  }
  
  protected void onDetachedFromWindow() {
    super.onDetachedFromWindow();
    removeCallbacks(this.Q);
  }
  
  public boolean onHoverEvent(MotionEvent paramMotionEvent) {
    int i = paramMotionEvent.getActionMasked();
    if (i == 9)
      this.C = false; 
    if (!this.C) {
      boolean bool = super.onHoverEvent(paramMotionEvent);
      if (i == 9 && !bool)
        this.C = true; 
    } 
    if (i == 10 || i == 3)
      this.C = false; 
    return true;
  }
  
  protected void onLayout(boolean paramBoolean, int paramInt1, int paramInt2, int paramInt3, int paramInt4) {
    if (o0.E((View)this) == 1) {
      n = 1;
    } else {
      n = 0;
    } 
    int i2 = getWidth();
    int i5 = getHeight();
    int i = getPaddingLeft();
    int i3 = getPaddingRight();
    int i4 = getPaddingTop();
    int i6 = getPaddingBottom();
    int i1 = i2 - i3;
    int[] arrayOfInt = this.F;
    arrayOfInt[1] = 0;
    arrayOfInt[0] = 0;
    paramInt1 = o0.F((View)this);
    if (paramInt1 >= 0) {
      paramInt4 = Math.min(paramInt1, paramInt4 - paramInt2);
    } else {
      paramInt4 = 0;
    } 
    if (P((View)this.d)) {
      if (n) {
        k = D((View)this.d, i1, arrayOfInt, paramInt4);
        paramInt3 = i;
      } else {
        paramInt3 = C((View)this.d, i, arrayOfInt, paramInt4);
        k = i1;
      } 
    } else {
      paramInt3 = i;
      k = i1;
    } 
    paramInt1 = paramInt3;
    paramInt2 = k;
    if (P((View)this.h))
      if (n) {
        paramInt2 = D((View)this.h, k, arrayOfInt, paramInt4);
        paramInt1 = paramInt3;
      } else {
        paramInt1 = C((View)this.h, paramInt3, arrayOfInt, paramInt4);
        paramInt2 = k;
      }  
    int k = paramInt1;
    paramInt3 = paramInt2;
    if (P((View)this.a))
      if (n) {
        k = C((View)this.a, paramInt1, arrayOfInt, paramInt4);
        paramInt3 = paramInt2;
      } else {
        paramInt3 = D((View)this.a, paramInt2, arrayOfInt, paramInt4);
        k = paramInt1;
      }  
    paramInt2 = getCurrentContentInsetLeft();
    paramInt1 = getCurrentContentInsetRight();
    arrayOfInt[0] = Math.max(0, paramInt2 - k);
    arrayOfInt[1] = Math.max(0, paramInt1 - i1 - paramInt3);
    paramInt2 = Math.max(k, paramInt2);
    paramInt3 = Math.min(paramInt3, i1 - paramInt1);
    paramInt1 = paramInt2;
    k = paramInt3;
    if (P(this.i))
      if (n) {
        k = D(this.i, paramInt3, arrayOfInt, paramInt4);
        paramInt1 = paramInt2;
      } else {
        paramInt1 = C(this.i, paramInt2, arrayOfInt, paramInt4);
        k = paramInt3;
      }  
    paramInt3 = paramInt1;
    paramInt2 = k;
    if (P((View)this.e))
      if (n) {
        paramInt2 = D((View)this.e, k, arrayOfInt, paramInt4);
        paramInt3 = paramInt1;
      } else {
        paramInt3 = C((View)this.e, paramInt1, arrayOfInt, paramInt4);
        paramInt2 = k;
      }  
    paramBoolean = P((View)this.b);
    boolean bool = P((View)this.c);
    if (paramBoolean) {
      e e1 = (e)this.b.getLayoutParams();
      paramInt1 = ((ViewGroup.MarginLayoutParams)e1).topMargin + this.b.getMeasuredHeight() + ((ViewGroup.MarginLayoutParams)e1).bottomMargin + 0;
    } else {
      paramInt1 = 0;
    } 
    if (bool) {
      e e1 = (e)this.c.getLayoutParams();
      paramInt1 += ((ViewGroup.MarginLayoutParams)e1).topMargin + this.c.getMeasuredHeight() + ((ViewGroup.MarginLayoutParams)e1).bottomMargin;
    } 
    if (paramBoolean || bool) {
      TextView textView1;
      TextView textView2;
      if (paramBoolean) {
        textView1 = this.b;
      } else {
        textView1 = this.c;
      } 
      if (bool) {
        textView2 = this.c;
      } else {
        textView2 = this.b;
      } 
      e e1 = (e)textView1.getLayoutParams();
      e e3 = (e)textView2.getLayoutParams();
      if ((paramBoolean && this.b.getMeasuredWidth() > 0) || (bool && this.c.getMeasuredWidth() > 0)) {
        k = 1;
      } else {
        k = 0;
      } 
      i1 = this.w & 0x70;
      if (i1 != 48) {
        if (i1 != 80) {
          i1 = (i5 - i4 - i6 - paramInt1) / 2;
          int i7 = ((ViewGroup.MarginLayoutParams)e1).topMargin;
          int i8 = this.r;
          if (i1 < i7 + i8) {
            paramInt1 = i7 + i8;
          } else {
            i5 = i5 - i6 - paramInt1 - i1 - i4;
            i6 = ((ViewGroup.MarginLayoutParams)e1).bottomMargin;
            i7 = this.s;
            paramInt1 = i1;
            if (i5 < i6 + i7)
              paramInt1 = Math.max(0, i1 - ((ViewGroup.MarginLayoutParams)e3).bottomMargin + i7 - i5); 
          } 
          paramInt1 = i4 + paramInt1;
        } else {
          paramInt1 = i5 - i6 - ((ViewGroup.MarginLayoutParams)e3).bottomMargin - this.s - paramInt1;
        } 
      } else {
        paramInt1 = getPaddingTop() + ((ViewGroup.MarginLayoutParams)e1).topMargin + this.r;
      } 
      if (n) {
        if (k != 0) {
          n = this.p;
        } else {
          n = 0;
        } 
        n -= arrayOfInt[1];
        paramInt2 -= Math.max(0, n);
        arrayOfInt[1] = Math.max(0, -n);
        if (paramBoolean) {
          e1 = (e)this.b.getLayoutParams();
          i1 = paramInt2 - this.b.getMeasuredWidth();
          n = this.b.getMeasuredHeight() + paramInt1;
          this.b.layout(i1, paramInt1, paramInt2, n);
          paramInt1 = i1 - this.q;
          i1 = n + ((ViewGroup.MarginLayoutParams)e1).bottomMargin;
        } else {
          n = paramInt2;
          i1 = paramInt1;
          paramInt1 = n;
        } 
        if (bool) {
          n = i1 + ((ViewGroup.MarginLayoutParams)this.c.getLayoutParams()).topMargin;
          i1 = this.c.getMeasuredWidth();
          i4 = this.c.getMeasuredHeight();
          this.c.layout(paramInt2 - i1, n, paramInt2, i4 + n);
          n = paramInt2 - this.q;
        } else {
          n = paramInt2;
        } 
        if (k != 0)
          paramInt2 = Math.min(paramInt1, n); 
        paramInt1 = paramInt3;
      } else {
        if (k != 0) {
          n = this.p;
        } else {
          n = 0;
        } 
        n -= arrayOfInt[0];
        paramInt3 += Math.max(0, n);
        arrayOfInt[0] = Math.max(0, -n);
        if (paramBoolean) {
          e1 = (e)this.b.getLayoutParams();
          n = this.b.getMeasuredWidth() + paramInt3;
          i1 = this.b.getMeasuredHeight() + paramInt1;
          this.b.layout(paramInt3, paramInt1, n, i1);
          n += this.q;
          paramInt1 = i1 + ((ViewGroup.MarginLayoutParams)e1).bottomMargin;
        } else {
          n = paramInt3;
        } 
        if (bool) {
          paramInt1 += ((ViewGroup.MarginLayoutParams)this.c.getLayoutParams()).topMargin;
          i1 = this.c.getMeasuredWidth() + paramInt3;
          i4 = this.c.getMeasuredHeight();
          this.c.layout(paramInt3, paramInt1, i1, i4 + paramInt1);
          i1 += this.q;
        } else {
          i1 = paramInt3;
        } 
        paramInt1 = paramInt3;
        paramInt3 = paramInt2;
        if (k != 0) {
          paramInt1 = Math.max(n, i1);
          paramInt3 = paramInt2;
        } 
        k = i;
        i = 0;
        b(this.D, 3);
        n = this.D.size();
        paramInt2 = 0;
      } 
    } else {
      paramInt1 = paramInt3;
    } 
    paramInt3 = paramInt2;
    k = i;
    i = 0;
    b(this.D, 3);
    int n = this.D.size();
    paramInt2 = 0;
  }
  
  protected void onMeasure(int paramInt1, int paramInt2) {
    throw new RuntimeException("d2j fail translate: java.lang.RuntimeException: can not merge I and Z\r\n\tat com.googlecode.dex2jar.ir.TypeClass.merge(TypeClass.java:100)\r\n\tat com.googlecode.dex2jar.ir.ts.TypeTransformer$TypeRef.updateTypeClass(TypeTransformer.java:174)\r\n\tat com.googlecode.dex2jar.ir.ts.TypeTransformer$TypeAnalyze.copyTypes(TypeTransformer.java:311)\r\n\tat com.googlecode.dex2jar.ir.ts.TypeTransformer$TypeAnalyze.fixTypes(TypeTransformer.java:226)\r\n\tat com.googlecode.dex2jar.ir.ts.TypeTransformer$TypeAnalyze.analyze(TypeTransformer.java:207)\r\n\tat com.googlecode.dex2jar.ir.ts.TypeTransformer.transform(TypeTransformer.java:44)\r\n\tat com.googlecode.d2j.dex.Dex2jar$2.optimize(Dex2jar.java:162)\r\n\tat com.googlecode.d2j.dex.Dex2Asm.convertCode(Dex2Asm.java:414)\r\n\tat com.googlecode.d2j.dex.ExDex2Asm.convertCode(ExDex2Asm.java:42)\r\n\tat com.googlecode.d2j.dex.Dex2jar$2.convertCode(Dex2jar.java:128)\r\n\tat com.googlecode.d2j.dex.Dex2Asm.convertMethod(Dex2Asm.java:509)\r\n\tat com.googlecode.d2j.dex.Dex2Asm.convertClass(Dex2Asm.java:406)\r\n\tat com.googlecode.d2j.dex.Dex2Asm.convertDex(Dex2Asm.java:422)\r\n\tat com.googlecode.d2j.dex.Dex2jar.doTranslate(Dex2jar.java:172)\r\n\tat com.googlecode.d2j.dex.Dex2jar.to(Dex2jar.java:272)\r\n\tat com.googlecode.dex2jar.tools.Dex2jarCmd.doCommandLine(Dex2jarCmd.java:108)\r\n\tat com.googlecode.dex2jar.tools.BaseCmd.doMain(BaseCmd.java:288)\r\n\tat com.googlecode.dex2jar.tools.Dex2jarCmd.main(Dex2jarCmd.java:32)\r\n");
  }
  
  protected void onRestoreInstanceState(Parcelable paramParcelable) {
    if (!(paramParcelable instanceof g)) {
      super.onRestoreInstanceState(paramParcelable);
      return;
    } 
    g g = (g)paramParcelable;
    super.onRestoreInstanceState(g.a());
    ActionMenuView actionMenuView = this.a;
    if (actionMenuView != null) {
      androidx.appcompat.view.menu.g g1 = actionMenuView.L();
    } else {
      actionMenuView = null;
    } 
    int i = g.c;
    if (i != 0 && this.M != null && actionMenuView != null) {
      MenuItem menuItem = actionMenuView.findItem(i);
      if (menuItem != null)
        menuItem.expandActionView(); 
    } 
    if (g.d)
      H(); 
  }
  
  public void onRtlPropertiesChanged(int paramInt) {
    super.onRtlPropertiesChanged(paramInt);
    h();
    t1 t11 = this.t;
    boolean bool = true;
    if (paramInt != 1)
      bool = false; 
    t11.f(bool);
  }
  
  protected Parcelable onSaveInstanceState() {
    g g = new g(super.onSaveInstanceState());
    d d1 = this.M;
    if (d1 != null) {
      i i = d1.b;
      if (i != null)
        g.c = i.getItemId(); 
    } 
    g.d = B();
    return (Parcelable)g;
  }
  
  public boolean onTouchEvent(MotionEvent paramMotionEvent) {
    int i = paramMotionEvent.getActionMasked();
    if (i == 0)
      this.B = false; 
    if (!this.B) {
      boolean bool = super.onTouchEvent(paramMotionEvent);
      if (i == 0 && !bool)
        this.B = true; 
    } 
    if (i == 1 || i == 3)
      this.B = false; 
    return true;
  }
  
  public void removeMenuProvider(b0 paramb0) {
    this.G.l(paramb0);
  }
  
  public void setCollapseContentDescription(int paramInt) {
    CharSequence charSequence;
    if (paramInt != 0) {
      charSequence = getContext().getText(paramInt);
    } else {
      charSequence = null;
    } 
    setCollapseContentDescription(charSequence);
  }
  
  public void setCollapseContentDescription(CharSequence paramCharSequence) {
    if (!TextUtils.isEmpty(paramCharSequence))
      g(); 
    ImageButton imageButton = this.h;
    if (imageButton != null)
      imageButton.setContentDescription(paramCharSequence); 
  }
  
  public void setCollapseIcon(int paramInt) {
    setCollapseIcon(f.a.b(getContext(), paramInt));
  }
  
  public void setCollapseIcon(Drawable paramDrawable) {
    if (paramDrawable != null) {
      g();
      this.h.setImageDrawable(paramDrawable);
      return;
    } 
    ImageButton imageButton = this.h;
    if (imageButton != null)
      imageButton.setImageDrawable(this.f); 
  }
  
  public void setCollapsible(boolean paramBoolean) {
    this.P = paramBoolean;
    requestLayout();
  }
  
  public void setContentInsetEndWithActions(int paramInt) {
    int i = paramInt;
    if (paramInt < 0)
      i = Integer.MIN_VALUE; 
    if (i != this.v) {
      this.v = i;
      if (getNavigationIcon() != null)
        requestLayout(); 
    } 
  }
  
  public void setContentInsetStartWithNavigation(int paramInt) {
    int i = paramInt;
    if (paramInt < 0)
      i = Integer.MIN_VALUE; 
    if (i != this.u) {
      this.u = i;
      if (getNavigationIcon() != null)
        requestLayout(); 
    } 
  }
  
  public void setLogo(int paramInt) {
    setLogo(f.a.b(getContext(), paramInt));
  }
  
  public void setLogo(Drawable paramDrawable) {
    if (paramDrawable != null) {
      i();
      if (!z((View)this.e))
        c((View)this.e, true); 
    } else {
      ImageView imageView1 = this.e;
      if (imageView1 != null && z((View)imageView1)) {
        removeView((View)this.e);
        this.E.remove(this.e);
      } 
    } 
    ImageView imageView = this.e;
    if (imageView != null)
      imageView.setImageDrawable(paramDrawable); 
  }
  
  public void setLogoDescription(int paramInt) {
    setLogoDescription(getContext().getText(paramInt));
  }
  
  public void setLogoDescription(CharSequence paramCharSequence) {
    if (!TextUtils.isEmpty(paramCharSequence))
      i(); 
    ImageView imageView = this.e;
    if (imageView != null)
      imageView.setContentDescription(paramCharSequence); 
  }
  
  public void setNavigationContentDescription(int paramInt) {
    CharSequence charSequence;
    if (paramInt != 0) {
      charSequence = getContext().getText(paramInt);
    } else {
      charSequence = null;
    } 
    setNavigationContentDescription(charSequence);
  }
  
  public void setNavigationContentDescription(CharSequence paramCharSequence) {
    if (!TextUtils.isEmpty(paramCharSequence))
      l(); 
    ImageButton imageButton = this.d;
    if (imageButton != null) {
      imageButton.setContentDescription(paramCharSequence);
      g2.a((View)this.d, paramCharSequence);
    } 
  }
  
  public void setNavigationIcon(int paramInt) {
    setNavigationIcon(f.a.b(getContext(), paramInt));
  }
  
  public void setNavigationIcon(Drawable paramDrawable) {
    if (paramDrawable != null) {
      l();
      if (!z((View)this.d))
        c((View)this.d, true); 
    } else {
      ImageButton imageButton1 = this.d;
      if (imageButton1 != null && z((View)imageButton1)) {
        removeView((View)this.d);
        this.E.remove(this.d);
      } 
    } 
    ImageButton imageButton = this.d;
    if (imageButton != null)
      imageButton.setImageDrawable(paramDrawable); 
  }
  
  public void setNavigationOnClickListener(View.OnClickListener paramOnClickListener) {
    l();
    this.d.setOnClickListener(paramOnClickListener);
  }
  
  public void setOnMenuItemClickListener(f paramf) {
    this.I = paramf;
  }
  
  public void setOverflowIcon(Drawable paramDrawable) {
    j();
    this.a.setOverflowIcon(paramDrawable);
  }
  
  public void setPopupTheme(int paramInt) {
    if (this.k != paramInt) {
      this.k = paramInt;
      if (paramInt == 0) {
        this.j = getContext();
        return;
      } 
      this.j = (Context)new ContextThemeWrapper(getContext(), paramInt);
    } 
  }
  
  public void setSubtitle(int paramInt) {
    setSubtitle(getContext().getText(paramInt));
  }
  
  public void setSubtitle(CharSequence paramCharSequence) {
    if (!TextUtils.isEmpty(paramCharSequence)) {
      if (this.c == null) {
        Context context = getContext();
        AppCompatTextView appCompatTextView = new AppCompatTextView(context);
        this.c = appCompatTextView;
        appCompatTextView.setSingleLine();
        this.c.setEllipsize(TextUtils.TruncateAt.END);
        int i = this.m;
        if (i != 0)
          this.c.setTextAppearance(context, i); 
        ColorStateList colorStateList = this.A;
        if (colorStateList != null)
          this.c.setTextColor(colorStateList); 
      } 
      if (!z((View)this.c))
        c((View)this.c, true); 
    } else {
      TextView textView1 = this.c;
      if (textView1 != null && z((View)textView1)) {
        removeView((View)this.c);
        this.E.remove(this.c);
      } 
    } 
    TextView textView = this.c;
    if (textView != null)
      textView.setText(paramCharSequence); 
    this.y = paramCharSequence;
  }
  
  public void setSubtitleTextColor(int paramInt) {
    setSubtitleTextColor(ColorStateList.valueOf(paramInt));
  }
  
  public void setSubtitleTextColor(ColorStateList paramColorStateList) {
    this.A = paramColorStateList;
    TextView textView = this.c;
    if (textView != null)
      textView.setTextColor(paramColorStateList); 
  }
  
  public void setTitle(int paramInt) {
    setTitle(getContext().getText(paramInt));
  }
  
  public void setTitle(CharSequence paramCharSequence) {
    if (!TextUtils.isEmpty(paramCharSequence)) {
      if (this.b == null) {
        Context context = getContext();
        AppCompatTextView appCompatTextView = new AppCompatTextView(context);
        this.b = appCompatTextView;
        appCompatTextView.setSingleLine();
        this.b.setEllipsize(TextUtils.TruncateAt.END);
        int i = this.l;
        if (i != 0)
          this.b.setTextAppearance(context, i); 
        ColorStateList colorStateList = this.z;
        if (colorStateList != null)
          this.b.setTextColor(colorStateList); 
      } 
      if (!z((View)this.b))
        c((View)this.b, true); 
    } else {
      TextView textView1 = this.b;
      if (textView1 != null && z((View)textView1)) {
        removeView((View)this.b);
        this.E.remove(this.b);
      } 
    } 
    TextView textView = this.b;
    if (textView != null)
      textView.setText(paramCharSequence); 
    this.x = paramCharSequence;
  }
  
  public void setTitleMarginBottom(int paramInt) {
    this.s = paramInt;
    requestLayout();
  }
  
  public void setTitleMarginEnd(int paramInt) {
    this.q = paramInt;
    requestLayout();
  }
  
  public void setTitleMarginStart(int paramInt) {
    this.p = paramInt;
    requestLayout();
  }
  
  public void setTitleMarginTop(int paramInt) {
    this.r = paramInt;
    requestLayout();
  }
  
  public void setTitleTextColor(int paramInt) {
    setTitleTextColor(ColorStateList.valueOf(paramInt));
  }
  
  public void setTitleTextColor(ColorStateList paramColorStateList) {
    this.z = paramColorStateList;
    TextView textView = this.b;
    if (textView != null)
      textView.setTextColor(paramColorStateList); 
  }
  
  public boolean v() {
    d d1 = this.M;
    return (d1 != null && d1.b != null);
  }
  
  public boolean w() {
    ActionMenuView actionMenuView = this.a;
    return (actionMenuView != null && actionMenuView.F());
  }
  
  public void x(int paramInt) {
    getMenuInflater().inflate(paramInt, getMenu());
  }
  
  public void y() {
    for (MenuItem menuItem : this.H)
      getMenu().removeItem(menuItem.getItemId()); 
    G();
  }
  
  class a implements ActionMenuView.e {
    a(Toolbar this$0) {}
    
    public boolean onMenuItemClick(MenuItem param1MenuItem) {
      if (this.a.G.j(param1MenuItem))
        return true; 
      Toolbar.f f = this.a.I;
      return (f != null) ? f.onMenuItemClick(param1MenuItem) : false;
    }
  }
  
  class b implements Runnable {
    b(Toolbar this$0) {}
    
    public void run() {
      this.a.Q();
    }
  }
  
  class c implements View.OnClickListener {
    c(Toolbar this$0) {}
    
    public void onClick(View param1View) {
      this.a.e();
    }
  }
  
  private class d implements m {
    androidx.appcompat.view.menu.g a;
    
    i b;
    
    d(Toolbar this$0) {}
    
    public void b(androidx.appcompat.view.menu.g param1g, boolean param1Boolean) {}
    
    public void c(boolean param1Boolean) {
      if (this.b != null) {
        androidx.appcompat.view.menu.g g1 = this.a;
        boolean bool2 = false;
        boolean bool1 = bool2;
        if (g1 != null) {
          int k = g1.size();
          int j = 0;
          while (true) {
            bool1 = bool2;
            if (j < k) {
              if (this.a.getItem(j) == this.b) {
                bool1 = true;
                break;
              } 
              j++;
              continue;
            } 
            break;
          } 
        } 
        if (!bool1)
          e(this.a, this.b); 
      } 
    }
    
    public boolean d() {
      return false;
    }
    
    public boolean e(androidx.appcompat.view.menu.g param1g, i param1i) {
      View view = this.c.i;
      if (view instanceof androidx.appcompat.view.c)
        ((androidx.appcompat.view.c)view).onActionViewCollapsed(); 
      Toolbar toolbar = this.c;
      toolbar.removeView(toolbar.i);
      toolbar = this.c;
      toolbar.removeView((View)toolbar.h);
      toolbar = this.c;
      toolbar.i = null;
      toolbar.a();
      this.b = null;
      this.c.requestLayout();
      param1i.r(false);
      return true;
    }
    
    public boolean f(androidx.appcompat.view.menu.g param1g, i param1i) {
      this.c.g();
      ViewParent viewParent = this.c.h.getParent();
      Toolbar toolbar = this.c;
      if (viewParent != toolbar) {
        if (viewParent instanceof ViewGroup)
          ((ViewGroup)viewParent).removeView((View)toolbar.h); 
        Toolbar toolbar1 = this.c;
        toolbar1.addView((View)toolbar1.h);
      } 
      this.c.i = param1i.getActionView();
      this.b = param1i;
      viewParent = this.c.i.getParent();
      toolbar = this.c;
      if (viewParent != toolbar) {
        if (viewParent instanceof ViewGroup)
          ((ViewGroup)viewParent).removeView(toolbar.i); 
        Toolbar.e e = this.c.m();
        toolbar = this.c;
        e.a = 0x800003 | toolbar.n & 0x70;
        e.b = 2;
        toolbar.i.setLayoutParams((ViewGroup.LayoutParams)e);
        Toolbar toolbar1 = this.c;
        toolbar1.addView(toolbar1.i);
      } 
      this.c.I();
      this.c.requestLayout();
      param1i.r(true);
      View view = this.c.i;
      if (view instanceof androidx.appcompat.view.c)
        ((androidx.appcompat.view.c)view).onActionViewExpanded(); 
      return true;
    }
    
    public int getId() {
      return 0;
    }
    
    public void h(Context param1Context, androidx.appcompat.view.menu.g param1g) {
      androidx.appcompat.view.menu.g g1 = this.a;
      if (g1 != null) {
        i i1 = this.b;
        if (i1 != null)
          g1.f(i1); 
      } 
      this.a = param1g;
    }
    
    public void i(Parcelable param1Parcelable) {}
    
    public boolean k(r param1r) {
      return false;
    }
    
    public Parcelable l() {
      return null;
    }
  }
  
  public static class e extends androidx.appcompat.app.a.a {
    int b = 0;
    
    public e(int param1Int1, int param1Int2) {
      super(param1Int1, param1Int2);
      this.a = 8388627;
    }
    
    public e(Context param1Context, AttributeSet param1AttributeSet) {
      super(param1Context, param1AttributeSet);
    }
    
    public e(ViewGroup.LayoutParams param1LayoutParams) {
      super(param1LayoutParams);
    }
    
    public e(ViewGroup.MarginLayoutParams param1MarginLayoutParams) {
      super((ViewGroup.LayoutParams)param1MarginLayoutParams);
      a(param1MarginLayoutParams);
    }
    
    public e(androidx.appcompat.app.a.a param1a) {
      super(param1a);
    }
    
    public e(e param1e) {
      super(param1e);
      this.b = param1e.b;
    }
    
    void a(ViewGroup.MarginLayoutParams param1MarginLayoutParams) {
      ((ViewGroup.MarginLayoutParams)this).leftMargin = param1MarginLayoutParams.leftMargin;
      ((ViewGroup.MarginLayoutParams)this).topMargin = param1MarginLayoutParams.topMargin;
      ((ViewGroup.MarginLayoutParams)this).rightMargin = param1MarginLayoutParams.rightMargin;
      ((ViewGroup.MarginLayoutParams)this).bottomMargin = param1MarginLayoutParams.bottomMargin;
    }
  }
  
  public static interface f {
    boolean onMenuItemClick(MenuItem param1MenuItem);
  }
  
  public static class g extends androidx.customview.view.a {
    public static final Parcelable.Creator<g> CREATOR = (Parcelable.Creator<g>)new a();
    
    int c;
    
    boolean d;
    
    public g(Parcel param1Parcel, ClassLoader param1ClassLoader) {
      super(param1Parcel, param1ClassLoader);
      boolean bool;
      this.c = param1Parcel.readInt();
      if (param1Parcel.readInt() != 0) {
        bool = true;
      } else {
        bool = false;
      } 
      this.d = bool;
    }
    
    public g(Parcelable param1Parcelable) {
      super(param1Parcelable);
    }
    
    public void writeToParcel(Parcel param1Parcel, int param1Int) {
      throw new RuntimeException("d2j fail translate: java.lang.RuntimeException: can not merge I and Z\r\n\tat com.googlecode.dex2jar.ir.TypeClass.merge(TypeClass.java:100)\r\n\tat com.googlecode.dex2jar.ir.ts.TypeTransformer$TypeRef.updateTypeClass(TypeTransformer.java:174)\r\n\tat com.googlecode.dex2jar.ir.ts.TypeTransformer$TypeAnalyze.provideAs(TypeTransformer.java:780)\r\n\tat com.googlecode.dex2jar.ir.ts.TypeTransformer$TypeAnalyze.e1expr(TypeTransformer.java:496)\r\n\tat com.googlecode.dex2jar.ir.ts.TypeTransformer$TypeAnalyze.exExpr(TypeTransformer.java:713)\r\n\tat com.googlecode.dex2jar.ir.ts.TypeTransformer$TypeAnalyze.exExpr(TypeTransformer.java:703)\r\n\tat com.googlecode.dex2jar.ir.ts.TypeTransformer$TypeAnalyze.enexpr(TypeTransformer.java:698)\r\n\tat com.googlecode.dex2jar.ir.ts.TypeTransformer$TypeAnalyze.exExpr(TypeTransformer.java:719)\r\n\tat com.googlecode.dex2jar.ir.ts.TypeTransformer$TypeAnalyze.exExpr(TypeTransformer.java:703)\r\n\tat com.googlecode.dex2jar.ir.ts.TypeTransformer$TypeAnalyze.s1stmt(TypeTransformer.java:810)\r\n\tat com.googlecode.dex2jar.ir.ts.TypeTransformer$TypeAnalyze.sxStmt(TypeTransformer.java:840)\r\n\tat com.googlecode.dex2jar.ir.ts.TypeTransformer$TypeAnalyze.analyze(TypeTransformer.java:206)\r\n\tat com.googlecode.dex2jar.ir.ts.TypeTransformer.transform(TypeTransformer.java:44)\r\n\tat com.googlecode.d2j.dex.Dex2jar$2.optimize(Dex2jar.java:162)\r\n\tat com.googlecode.d2j.dex.Dex2Asm.convertCode(Dex2Asm.java:414)\r\n\tat com.googlecode.d2j.dex.ExDex2Asm.convertCode(ExDex2Asm.java:42)\r\n\tat com.googlecode.d2j.dex.Dex2jar$2.convertCode(Dex2jar.java:128)\r\n\tat com.googlecode.d2j.dex.Dex2Asm.convertMethod(Dex2Asm.java:509)\r\n\tat com.googlecode.d2j.dex.Dex2Asm.convertClass(Dex2Asm.java:406)\r\n\tat com.googlecode.d2j.dex.Dex2Asm.convertDex(Dex2Asm.java:422)\r\n\tat com.googlecode.d2j.dex.Dex2jar.doTranslate(Dex2jar.java:172)\r\n\tat com.googlecode.d2j.dex.Dex2jar.to(Dex2jar.java:272)\r\n\tat com.googlecode.dex2jar.tools.Dex2jarCmd.doCommandLine(Dex2jarCmd.java:108)\r\n\tat com.googlecode.dex2jar.tools.BaseCmd.doMain(BaseCmd.java:288)\r\n\tat com.googlecode.dex2jar.tools.Dex2jarCmd.main(Dex2jarCmd.java:32)\r\n");
    }
    
    class a implements Parcelable.ClassLoaderCreator<g> {
      public Toolbar.g a(Parcel param2Parcel) {
        return new Toolbar.g(param2Parcel, null);
      }
      
      public Toolbar.g b(Parcel param2Parcel, ClassLoader param2ClassLoader) {
        return new Toolbar.g(param2Parcel, param2ClassLoader);
      }
      
      public Toolbar.g[] c(int param2Int) {
        return new Toolbar.g[param2Int];
      }
    }
  }
  
  class a implements Parcelable.ClassLoaderCreator<g> {
    public Toolbar.g a(Parcel param1Parcel) {
      return new Toolbar.g(param1Parcel, null);
    }
    
    public Toolbar.g b(Parcel param1Parcel, ClassLoader param1ClassLoader) {
      return new Toolbar.g(param1Parcel, param1ClassLoader);
    }
    
    public Toolbar.g[] c(int param1Int) {
      return new Toolbar.g[param1Int];
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Cricket Scorer-dex2jar.jar!\androidx\appcompat\widget\Toolbar.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */