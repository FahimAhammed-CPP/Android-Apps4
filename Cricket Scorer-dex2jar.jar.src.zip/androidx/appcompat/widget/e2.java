package androidx.appcompat.widget;

import android.content.Context;
import android.graphics.drawable.Drawable;
import android.text.TextUtils;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.view.ViewParent;
import android.view.Window;
import androidx.appcompat.view.menu.g;
import androidx.appcompat.view.menu.m;
import androidx.core.view.o0;
import androidx.core.view.o2;
import androidx.core.view.p2;
import androidx.core.view.q2;
import e.e;
import e.f;
import e.h;
import e.j;

public class e2 implements c1 {
  Toolbar a;
  
  private int b;
  
  private View c;
  
  private View d;
  
  private Drawable e;
  
  private Drawable f;
  
  private Drawable g;
  
  private boolean h;
  
  CharSequence i;
  
  private CharSequence j;
  
  private CharSequence k;
  
  Window.Callback l;
  
  boolean m;
  
  private c n;
  
  private int o;
  
  private int p;
  
  private Drawable q;
  
  public e2(Toolbar paramToolbar, boolean paramBoolean) {
    this(paramToolbar, paramBoolean, h.a, e.n);
  }
  
  public e2(Toolbar paramToolbar, boolean paramBoolean, int paramInt1, int paramInt2) {
    boolean bool;
    this.o = 0;
    this.p = 0;
    this.a = paramToolbar;
    this.i = paramToolbar.getTitle();
    this.j = paramToolbar.getSubtitle();
    if (this.i != null) {
      bool = true;
    } else {
      bool = false;
    } 
    this.h = bool;
    this.g = paramToolbar.getNavigationIcon();
    c2 c2 = c2.v(paramToolbar.getContext(), null, j.a, e.a.c, 0);
    this.q = c2.g(j.l);
    if (paramBoolean) {
      CharSequence charSequence = c2.p(j.r);
      if (!TextUtils.isEmpty(charSequence))
        setTitle(charSequence); 
      charSequence = c2.p(j.p);
      if (!TextUtils.isEmpty(charSequence))
        F(charSequence); 
      Drawable drawable = c2.g(j.n);
      if (drawable != null)
        D(drawable); 
      drawable = c2.g(j.m);
      if (drawable != null)
        setIcon(drawable); 
      if (this.g == null) {
        drawable = this.q;
        if (drawable != null)
          y(drawable); 
      } 
      l(c2.k(j.h, 0));
      paramInt2 = c2.n(j.g, 0);
      if (paramInt2 != 0) {
        B(LayoutInflater.from(this.a.getContext()).inflate(paramInt2, this.a, false));
        l(this.b | 0x10);
      } 
      paramInt2 = c2.m(j.j, 0);
      if (paramInt2 > 0) {
        ViewGroup.LayoutParams layoutParams = this.a.getLayoutParams();
        layoutParams.height = paramInt2;
        this.a.setLayoutParams(layoutParams);
      } 
      paramInt2 = c2.e(j.f, -1);
      int i = c2.e(j.e, -1);
      if (paramInt2 >= 0 || i >= 0)
        this.a.J(Math.max(paramInt2, 0), Math.max(i, 0)); 
      paramInt2 = c2.n(j.s, 0);
      if (paramInt2 != 0) {
        Toolbar toolbar = this.a;
        toolbar.N(toolbar.getContext(), paramInt2);
      } 
      paramInt2 = c2.n(j.q, 0);
      if (paramInt2 != 0) {
        Toolbar toolbar = this.a;
        toolbar.M(toolbar.getContext(), paramInt2);
      } 
      paramInt2 = c2.n(j.o, 0);
      if (paramInt2 != 0)
        this.a.setPopupTheme(paramInt2); 
    } else {
      this.b = A();
    } 
    c2.w();
    C(paramInt1);
    this.k = this.a.getNavigationContentDescription();
    this.a.setNavigationOnClickListener(new a(this));
  }
  
  private int A() {
    if (this.a.getNavigationIcon() != null) {
      this.q = this.a.getNavigationIcon();
      return 15;
    } 
    return 11;
  }
  
  private void G(CharSequence paramCharSequence) {
    this.i = paramCharSequence;
    if ((this.b & 0x8) != 0) {
      this.a.setTitle(paramCharSequence);
      if (this.h)
        o0.u0(this.a.getRootView(), paramCharSequence); 
    } 
  }
  
  private void H() {
    if ((this.b & 0x4) != 0) {
      if (TextUtils.isEmpty(this.k)) {
        this.a.setNavigationContentDescription(this.p);
        return;
      } 
      this.a.setNavigationContentDescription(this.k);
    } 
  }
  
  private void I() {
    if ((this.b & 0x4) != 0) {
      Toolbar toolbar = this.a;
      Drawable drawable = this.g;
      if (drawable == null)
        drawable = this.q; 
      toolbar.setNavigationIcon(drawable);
      return;
    } 
    this.a.setNavigationIcon((Drawable)null);
  }
  
  private void J() {
    Drawable drawable;
    int i = this.b;
    if ((i & 0x2) != 0) {
      if ((i & 0x1) != 0) {
        drawable = this.f;
        if (drawable == null)
          drawable = this.e; 
      } else {
        drawable = this.e;
      } 
    } else {
      drawable = null;
    } 
    this.a.setLogo(drawable);
  }
  
  public void B(View paramView) {
    View view = this.d;
    if (view != null && (this.b & 0x10) != 0)
      this.a.removeView(view); 
    this.d = paramView;
    if (paramView != null && (this.b & 0x10) != 0)
      this.a.addView(paramView); 
  }
  
  public void C(int paramInt) {
    if (paramInt == this.p)
      return; 
    this.p = paramInt;
    if (TextUtils.isEmpty(this.a.getNavigationContentDescription()))
      v(this.p); 
  }
  
  public void D(Drawable paramDrawable) {
    this.f = paramDrawable;
    J();
  }
  
  public void E(CharSequence paramCharSequence) {
    this.k = paramCharSequence;
    H();
  }
  
  public void F(CharSequence paramCharSequence) {
    this.j = paramCharSequence;
    if ((this.b & 0x8) != 0)
      this.a.setSubtitle(paramCharSequence); 
  }
  
  public void a(Menu paramMenu, m.a parama) {
    if (this.n == null) {
      c c2 = new c(this.a.getContext());
      this.n = c2;
      c2.r(f.g);
    } 
    this.n.g(parama);
    this.a.K((g)paramMenu, this.n);
  }
  
  public boolean b() {
    return this.a.B();
  }
  
  public void c() {
    this.m = true;
  }
  
  public void collapseActionView() {
    this.a.e();
  }
  
  public boolean d() {
    return this.a.d();
  }
  
  public Context e() {
    return this.a.getContext();
  }
  
  public boolean f() {
    return this.a.A();
  }
  
  public boolean g() {
    return this.a.w();
  }
  
  public CharSequence getTitle() {
    return this.a.getTitle();
  }
  
  public boolean h() {
    return this.a.Q();
  }
  
  public void i() {
    this.a.f();
  }
  
  public void j(u1 paramu1) {
    View view = this.c;
    if (view != null) {
      ViewParent viewParent = view.getParent();
      Toolbar toolbar = this.a;
      if (viewParent == toolbar)
        toolbar.removeView(this.c); 
    } 
    this.c = (View)paramu1;
    if (paramu1 != null && this.o == 2) {
      this.a.addView((View)paramu1, 0);
      Toolbar.e e = (Toolbar.e)this.c.getLayoutParams();
      ((ViewGroup.MarginLayoutParams)e).width = -2;
      ((ViewGroup.MarginLayoutParams)e).height = -2;
      e.a = 8388691;
      paramu1.setAllowCollapse(true);
    } 
  }
  
  public boolean k() {
    return this.a.v();
  }
  
  public void l(int paramInt) {
    int i = this.b ^ paramInt;
    this.b = paramInt;
    if (i != 0) {
      if ((i & 0x4) != 0) {
        if ((paramInt & 0x4) != 0)
          H(); 
        I();
      } 
      if ((i & 0x3) != 0)
        J(); 
      if ((i & 0x8) != 0)
        if ((paramInt & 0x8) != 0) {
          this.a.setTitle(this.i);
          this.a.setSubtitle(this.j);
        } else {
          this.a.setTitle((CharSequence)null);
          this.a.setSubtitle((CharSequence)null);
        }  
      if ((i & 0x10) != 0) {
        View view = this.d;
        if (view != null) {
          if ((paramInt & 0x10) != 0) {
            this.a.addView(view);
            return;
          } 
          this.a.removeView(view);
        } 
      } 
    } 
  }
  
  public Menu m() {
    return this.a.getMenu();
  }
  
  public void n(int paramInt) {
    Drawable drawable;
    if (paramInt != 0) {
      drawable = f.a.b(e(), paramInt);
    } else {
      drawable = null;
    } 
    D(drawable);
  }
  
  public int o() {
    return this.o;
  }
  
  public o2 p(int paramInt, long paramLong) {
    float f;
    o2 o2 = o0.e((View)this.a);
    if (paramInt == 0) {
      f = 1.0F;
    } else {
      f = 0.0F;
    } 
    return o2.b(f).f(paramLong).h((p2)new b(this, paramInt));
  }
  
  public void q(m.a parama, g.a parama1) {
    this.a.L(parama, parama1);
  }
  
  public void r(int paramInt) {
    this.a.setVisibility(paramInt);
  }
  
  public ViewGroup s() {
    return this.a;
  }
  
  public void setIcon(int paramInt) {
    Drawable drawable;
    if (paramInt != 0) {
      drawable = f.a.b(e(), paramInt);
    } else {
      drawable = null;
    } 
    setIcon(drawable);
  }
  
  public void setIcon(Drawable paramDrawable) {
    this.e = paramDrawable;
    J();
  }
  
  public void setTitle(CharSequence paramCharSequence) {
    this.h = true;
    G(paramCharSequence);
  }
  
  public void setWindowCallback(Window.Callback paramCallback) {
    this.l = paramCallback;
  }
  
  public void setWindowTitle(CharSequence paramCharSequence) {
    if (!this.h)
      G(paramCharSequence); 
  }
  
  public void t(boolean paramBoolean) {}
  
  public int u() {
    return this.b;
  }
  
  public void v(int paramInt) {
    String str;
    if (paramInt == 0) {
      str = null;
    } else {
      str = e().getString(paramInt);
    } 
    E(str);
  }
  
  public void w() {
    Log.i("ToolbarWidgetWrapper", "Progress display unsupported");
  }
  
  public void x() {
    Log.i("ToolbarWidgetWrapper", "Progress display unsupported");
  }
  
  public void y(Drawable paramDrawable) {
    this.g = paramDrawable;
    I();
  }
  
  public void z(boolean paramBoolean) {
    this.a.setCollapsible(paramBoolean);
  }
  
  class a implements View.OnClickListener {
    final androidx.appcompat.view.menu.a a;
    
    a(e2 this$0) {
      this.a = new androidx.appcompat.view.menu.a(this$0.a.getContext(), 0, 16908332, 0, 0, this$0.i);
    }
    
    public void onClick(View param1View) {
      e2 e21 = this.b;
      Window.Callback callback = e21.l;
      if (callback != null && e21.m)
        callback.onMenuItemSelected(0, (MenuItem)this.a); 
    }
  }
  
  class b extends q2 {
    private boolean a = false;
    
    b(e2 this$0, int param1Int) {}
    
    public void a(View param1View) {
      this.a = true;
    }
    
    public void b(View param1View) {
      if (!this.a)
        this.c.a.setVisibility(this.b); 
    }
    
    public void c(View param1View) {
      this.c.a.setVisibility(0);
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Cricket Scorer-dex2jar.jar!\androidx\appcompat\widget\e2.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */