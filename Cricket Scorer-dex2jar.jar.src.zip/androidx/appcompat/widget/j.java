package androidx.appcompat.widget;

import android.content.res.TypedArray;
import android.text.InputFilter;
import android.text.method.TransformationMethod;
import android.util.AttributeSet;
import android.widget.TextView;
import androidx.emoji2.viewsintegration.f;

class j {
  private final TextView a;
  
  private final f b;
  
  j(TextView paramTextView) {
    this.a = paramTextView;
    this.b = new f(paramTextView, false);
  }
  
  InputFilter[] a(InputFilter[] paramArrayOfInputFilter) {
    return this.b.a(paramArrayOfInputFilter);
  }
  
  public boolean b() {
    return this.b.b();
  }
  
  void c(AttributeSet paramAttributeSet, int paramInt) {
    TypedArray typedArray = this.a.getContext().obtainStyledAttributes(paramAttributeSet, e.j.g0, paramInt, 0);
    try {
      paramInt = e.j.u0;
      boolean bool2 = typedArray.hasValue(paramInt);
      boolean bool1 = true;
      if (bool2)
        bool1 = typedArray.getBoolean(paramInt, true); 
      typedArray.recycle();
      return;
    } finally {
      typedArray.recycle();
    } 
  }
  
  void d(boolean paramBoolean) {
    this.b.c(paramBoolean);
  }
  
  void e(boolean paramBoolean) {
    this.b.d(paramBoolean);
  }
  
  public TransformationMethod f(TransformationMethod paramTransformationMethod) {
    return this.b.e(paramTransformationMethod);
  }
}


/* Location:              C:\soft\dex2jar-2.0\Cricket Scorer-dex2jar.jar!\androidx\appcompat\widget\j.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */