package androidx.appcompat.widget;

import android.content.Context;
import android.content.res.Configuration;
import android.graphics.drawable.Drawable;
import android.text.TextUtils;
import android.view.View;
import android.view.ViewGroup;
import android.view.ViewParent;
import android.view.accessibility.AccessibilityEvent;
import android.view.accessibility.AccessibilityNodeInfo;
import android.view.animation.DecelerateInterpolator;
import android.view.animation.Interpolator;
import android.widget.AbsListView;
import android.widget.AdapterView;
import android.widget.BaseAdapter;
import android.widget.HorizontalScrollView;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.Spinner;
import android.widget.SpinnerAdapter;
import android.widget.TextView;

public class u1 extends HorizontalScrollView implements AdapterView.OnItemSelectedListener {
  private static final Interpolator j = (Interpolator)new DecelerateInterpolator();
  
  Runnable a;
  
  private c b;
  
  LinearLayoutCompat c;
  
  private Spinner d;
  
  private boolean e;
  
  int f;
  
  int g;
  
  private int h;
  
  private int i;
  
  private Spinner b() {
    AppCompatSpinner appCompatSpinner = new AppCompatSpinner(getContext(), null, e.a.h);
    appCompatSpinner.setLayoutParams((ViewGroup.LayoutParams)new LinearLayoutCompat.a(-2, -1));
    appCompatSpinner.setOnItemSelectedListener(this);
    return appCompatSpinner;
  }
  
  private boolean d() {
    Spinner spinner = this.d;
    return (spinner != null && spinner.getParent() == this);
  }
  
  private void e() {
    if (d())
      return; 
    if (this.d == null)
      this.d = b(); 
    removeView((View)this.c);
    addView((View)this.d, new ViewGroup.LayoutParams(-2, -1));
    if (this.d.getAdapter() == null)
      this.d.setAdapter((SpinnerAdapter)new b(this)); 
    Runnable runnable = this.a;
    if (runnable != null) {
      removeCallbacks(runnable);
      this.a = null;
    } 
    this.d.setSelection(this.i);
  }
  
  private boolean f() {
    if (!d())
      return false; 
    removeView((View)this.d);
    addView((View)this.c, new ViewGroup.LayoutParams(-2, -1));
    setTabSelected(this.d.getSelectedItemPosition());
    return false;
  }
  
  public void a(int paramInt) {
    View view = this.c.getChildAt(paramInt);
    Runnable runnable = this.a;
    if (runnable != null)
      removeCallbacks(runnable); 
    a a = new a(this, view);
    this.a = a;
    post(a);
  }
  
  d c(androidx.appcompat.app.a.c paramc, boolean paramBoolean) {
    d d = new d(this, getContext(), paramc, paramBoolean);
    if (paramBoolean) {
      d.setBackgroundDrawable(null);
      d.setLayoutParams((ViewGroup.LayoutParams)new AbsListView.LayoutParams(-1, this.h));
      return d;
    } 
    d.setFocusable(true);
    if (this.b == null)
      this.b = new c(this); 
    d.setOnClickListener(this.b);
    return d;
  }
  
  public void onAttachedToWindow() {
    super.onAttachedToWindow();
    Runnable runnable = this.a;
    if (runnable != null)
      post(runnable); 
  }
  
  protected void onConfigurationChanged(Configuration paramConfiguration) {
    super.onConfigurationChanged(paramConfiguration);
    androidx.appcompat.view.a a = androidx.appcompat.view.a.b(getContext());
    setContentHeight(a.f());
    this.g = a.e();
  }
  
  public void onDetachedFromWindow() {
    super.onDetachedFromWindow();
    Runnable runnable = this.a;
    if (runnable != null)
      removeCallbacks(runnable); 
  }
  
  public void onItemSelected(AdapterView<?> paramAdapterView, View paramView, int paramInt, long paramLong) {
    ((d)paramView).b().e();
  }
  
  public void onMeasure(int paramInt1, int paramInt2) {
    boolean bool;
    int i = View.MeasureSpec.getMode(paramInt1);
    paramInt2 = 1;
    if (i == 1073741824) {
      bool = true;
    } else {
      bool = false;
    } 
    setFillViewport(bool);
    int j = this.c.getChildCount();
    if (j > 1 && (i == 1073741824 || i == Integer.MIN_VALUE)) {
      if (j > 2) {
        this.f = (int)(View.MeasureSpec.getSize(paramInt1) * 0.4F);
      } else {
        this.f = View.MeasureSpec.getSize(paramInt1) / 2;
      } 
      this.f = Math.min(this.f, this.g);
    } else {
      this.f = -1;
    } 
    i = View.MeasureSpec.makeMeasureSpec(this.h, 1073741824);
    if (bool || !this.e)
      paramInt2 = 0; 
    if (paramInt2 != 0) {
      this.c.measure(0, i);
      if (this.c.getMeasuredWidth() > View.MeasureSpec.getSize(paramInt1)) {
        e();
      } else {
        f();
      } 
    } else {
      f();
    } 
    paramInt2 = getMeasuredWidth();
    super.onMeasure(paramInt1, i);
    paramInt1 = getMeasuredWidth();
    if (bool && paramInt2 != paramInt1)
      setTabSelected(this.i); 
  }
  
  public void onNothingSelected(AdapterView<?> paramAdapterView) {}
  
  public void setAllowCollapse(boolean paramBoolean) {
    this.e = paramBoolean;
  }
  
  public void setContentHeight(int paramInt) {
    this.h = paramInt;
    requestLayout();
  }
  
  public void setTabSelected(int paramInt) {
    this.i = paramInt;
    int j = this.c.getChildCount();
    for (int i = 0; i < j; i++) {
      boolean bool;
      View view = this.c.getChildAt(i);
      if (i == paramInt) {
        bool = true;
      } else {
        bool = false;
      } 
      view.setSelected(bool);
      if (bool)
        a(paramInt); 
    } 
    Spinner spinner = this.d;
    if (spinner != null && paramInt >= 0)
      spinner.setSelection(paramInt); 
  }
  
  class a implements Runnable {
    a(u1 this$0, View param1View) {}
    
    public void run() {
      int i = this.a.getLeft();
      int j = (this.b.getWidth() - this.a.getWidth()) / 2;
      this.b.smoothScrollTo(i - j, 0);
      this.b.a = null;
    }
  }
  
  private class b extends BaseAdapter {
    b(u1 this$0) {}
    
    public int getCount() {
      return this.a.c.getChildCount();
    }
    
    public Object getItem(int param1Int) {
      return ((u1.d)this.a.c.getChildAt(param1Int)).b();
    }
    
    public long getItemId(int param1Int) {
      return param1Int;
    }
    
    public View getView(int param1Int, View param1View, ViewGroup param1ViewGroup) {
      if (param1View == null)
        return (View)this.a.c((androidx.appcompat.app.a.c)getItem(param1Int), true); 
      ((u1.d)param1View).a((androidx.appcompat.app.a.c)getItem(param1Int));
      return param1View;
    }
  }
  
  private class c implements View.OnClickListener {
    c(u1 this$0) {}
    
    public void onClick(View param1View) {
      ((u1.d)param1View).b().e();
      int j = this.a.c.getChildCount();
      for (int i = 0; i < j; i++) {
        boolean bool;
        View view = this.a.c.getChildAt(i);
        if (view == param1View) {
          bool = true;
        } else {
          bool = false;
        } 
        view.setSelected(bool);
      } 
    }
  }
  
  private class d extends LinearLayout {
    private final int[] a;
    
    private androidx.appcompat.app.a.c b;
    
    private TextView c;
    
    private ImageView d;
    
    private View e;
    
    public d(u1 this$0, Context param1Context, androidx.appcompat.app.a.c param1c, boolean param1Boolean) {
      super(param1Context, null, i);
      int[] arrayOfInt = new int[1];
      arrayOfInt[0] = 16842964;
      this.a = arrayOfInt;
      this.b = param1c;
      c2 c2 = c2.v(param1Context, null, arrayOfInt, i, 0);
      if (c2.s(0))
        setBackgroundDrawable(c2.g(0)); 
      c2.w();
      if (param1Boolean)
        setGravity(8388627); 
      c();
    }
    
    public void a(androidx.appcompat.app.a.c param1c) {
      this.b = param1c;
      c();
    }
    
    public androidx.appcompat.app.a.c b() {
      return this.b;
    }
    
    public void c() {
      androidx.appcompat.app.a.c c1 = this.b;
      View view = c1.b();
      ViewParent viewParent = null;
      if (view != null) {
        viewParent = view.getParent();
        if (viewParent != this) {
          if (viewParent != null)
            ((ViewGroup)viewParent).removeView(view); 
          addView(view);
        } 
        this.e = view;
        TextView textView = this.c;
        if (textView != null)
          textView.setVisibility(8); 
        ImageView imageView = this.d;
        if (imageView != null) {
          imageView.setVisibility(8);
          this.d.setImageDrawable(null);
          return;
        } 
      } else {
        CharSequence charSequence1;
        view = this.e;
        if (view != null) {
          removeView(view);
          this.e = null;
        } 
        Drawable drawable = c1.c();
        CharSequence charSequence2 = c1.d();
        if (drawable != null) {
          if (this.d == null) {
            AppCompatImageView appCompatImageView = new AppCompatImageView(getContext());
            LinearLayout.LayoutParams layoutParams = new LinearLayout.LayoutParams(-2, -2);
            layoutParams.gravity = 16;
            appCompatImageView.setLayoutParams((ViewGroup.LayoutParams)layoutParams);
            addView((View)appCompatImageView, 0);
            this.d = appCompatImageView;
          } 
          this.d.setImageDrawable(drawable);
          this.d.setVisibility(0);
        } else {
          ImageView imageView1 = this.d;
          if (imageView1 != null) {
            imageView1.setVisibility(8);
            this.d.setImageDrawable(null);
          } 
        } 
        int i = TextUtils.isEmpty(charSequence2) ^ true;
        if (i != 0) {
          if (this.c == null) {
            AppCompatTextView appCompatTextView = new AppCompatTextView(getContext(), null, e.a.e);
            appCompatTextView.setEllipsize(TextUtils.TruncateAt.END);
            LinearLayout.LayoutParams layoutParams = new LinearLayout.LayoutParams(-2, -2);
            layoutParams.gravity = 16;
            appCompatTextView.setLayoutParams((ViewGroup.LayoutParams)layoutParams);
            addView((View)appCompatTextView);
            this.c = appCompatTextView;
          } 
          this.c.setText(charSequence2);
          this.c.setVisibility(0);
        } else {
          TextView textView = this.c;
          if (textView != null) {
            textView.setVisibility(8);
            this.c.setText(null);
          } 
        } 
        ImageView imageView = this.d;
        if (imageView != null)
          imageView.setContentDescription(c1.a()); 
        if (i == 0)
          charSequence1 = c1.a(); 
        g2.a((View)this, charSequence1);
      } 
    }
    
    public void onInitializeAccessibilityEvent(AccessibilityEvent param1AccessibilityEvent) {
      super.onInitializeAccessibilityEvent(param1AccessibilityEvent);
      param1AccessibilityEvent.setClassName("androidx.appcompat.app.ActionBar$Tab");
    }
    
    public void onInitializeAccessibilityNodeInfo(AccessibilityNodeInfo param1AccessibilityNodeInfo) {
      super.onInitializeAccessibilityNodeInfo(param1AccessibilityNodeInfo);
      param1AccessibilityNodeInfo.setClassName("androidx.appcompat.app.ActionBar$Tab");
    }
    
    public void onMeasure(int param1Int1, int param1Int2) {
      super.onMeasure(param1Int1, param1Int2);
      if (this.f.f > 0) {
        param1Int1 = getMeasuredWidth();
        int i = this.f.f;
        if (param1Int1 > i)
          super.onMeasure(View.MeasureSpec.makeMeasureSpec(i, 1073741824), param1Int2); 
      } 
    }
    
    public void setSelected(boolean param1Boolean) {
      boolean bool;
      if (isSelected() != param1Boolean) {
        bool = true;
      } else {
        bool = false;
      } 
      super.setSelected(param1Boolean);
      if (bool && param1Boolean)
        sendAccessibilityEvent(4); 
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Cricket Scorer-dex2jar.jar!\androidx\appcompat\widge\\u1.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */