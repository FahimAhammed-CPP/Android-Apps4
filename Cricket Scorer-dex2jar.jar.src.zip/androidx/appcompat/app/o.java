package androidx.appcompat.app;

import android.content.Context;
import android.content.res.Configuration;
import android.graphics.drawable.Drawable;
import android.view.KeyCharacterMap;
import android.view.KeyEvent;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.view.Window;
import androidx.appcompat.view.menu.g;
import androidx.appcompat.view.menu.m;
import androidx.appcompat.widget.Toolbar;
import androidx.appcompat.widget.c1;
import androidx.appcompat.widget.e2;
import androidx.core.util.h;
import androidx.core.view.o0;
import java.util.ArrayList;

class o extends a {
  final c1 a;
  
  final Window.Callback b;
  
  final f.g c;
  
  boolean d;
  
  private boolean e;
  
  private boolean f;
  
  private ArrayList<a.b> g = new ArrayList<a.b>();
  
  private final Runnable h = new a(this);
  
  private final Toolbar.f i;
  
  o(Toolbar paramToolbar, CharSequence paramCharSequence, Window.Callback paramCallback) {
    b b = new b(this);
    this.i = b;
    h.g(paramToolbar);
    e2 e2 = new e2(paramToolbar, false);
    this.a = (c1)e2;
    this.b = (Window.Callback)h.g(paramCallback);
    e2.setWindowCallback(paramCallback);
    paramToolbar.setOnMenuItemClickListener(b);
    e2.setWindowTitle(paramCharSequence);
    this.c = new e(this);
  }
  
  private Menu B() {
    if (!this.e) {
      this.a.q(new c(this), new d(this));
      this.e = true;
    } 
    return this.a.m();
  }
  
  void C() {
    g g1;
    null = B();
    if (null instanceof g) {
      g1 = (g)null;
    } else {
      g1 = null;
    } 
    if (g1 != null)
      g1.h0(); 
    try {
      null.clear();
      if (!this.b.onCreatePanelMenu(0, null) || !this.b.onPreparePanel(0, null, null))
        null.clear(); 
      return;
    } finally {
      if (g1 != null)
        g1.g0(); 
    } 
  }
  
  public void D(int paramInt1, int paramInt2) {
    int i = this.a.u();
    this.a.l(paramInt1 & paramInt2 | paramInt2 & i);
  }
  
  public boolean g() {
    return this.a.g();
  }
  
  public boolean h() {
    if (this.a.k()) {
      this.a.collapseActionView();
      return true;
    } 
    return false;
  }
  
  public void i(boolean paramBoolean) {
    if (paramBoolean == this.f)
      return; 
    this.f = paramBoolean;
    int j = this.g.size();
    for (int i = 0; i < j; i++)
      ((a.b)this.g.get(i)).onMenuVisibilityChanged(paramBoolean); 
  }
  
  public int j() {
    return this.a.u();
  }
  
  public Context k() {
    return this.a.e();
  }
  
  public boolean l() {
    this.a.s().removeCallbacks(this.h);
    o0.j0((View)this.a.s(), this.h);
    return true;
  }
  
  public void m(Configuration paramConfiguration) {
    super.m(paramConfiguration);
  }
  
  void n() {
    this.a.s().removeCallbacks(this.h);
  }
  
  public boolean o(int paramInt, KeyEvent paramKeyEvent) {
    Menu menu = B();
    if (menu != null) {
      if (paramKeyEvent != null) {
        i = paramKeyEvent.getDeviceId();
      } else {
        i = -1;
      } 
      int i = KeyCharacterMap.load(i).getKeyboardType();
      boolean bool = true;
      if (i == 1)
        bool = false; 
      menu.setQwertyMode(bool);
      return menu.performShortcut(paramInt, paramKeyEvent, 0);
    } 
    return false;
  }
  
  public boolean p(KeyEvent paramKeyEvent) {
    if (paramKeyEvent.getAction() == 1)
      q(); 
    return true;
  }
  
  public boolean q() {
    return this.a.h();
  }
  
  public void r(boolean paramBoolean) {}
  
  public void s(boolean paramBoolean) {
    boolean bool;
    if (paramBoolean) {
      bool = true;
    } else {
      bool = false;
    } 
    D(bool, 4);
  }
  
  public void t(boolean paramBoolean) {
    boolean bool;
    if (paramBoolean) {
      bool = true;
    } else {
      bool = false;
    } 
    D(bool, 8);
  }
  
  public void u(int paramInt) {
    this.a.v(paramInt);
  }
  
  public void v(Drawable paramDrawable) {
    this.a.y(paramDrawable);
  }
  
  public void w(boolean paramBoolean) {}
  
  public void x(int paramInt) {
    CharSequence charSequence;
    c1 c11 = this.a;
    if (paramInt != 0) {
      charSequence = c11.e().getText(paramInt);
    } else {
      charSequence = null;
    } 
    c11.setTitle(charSequence);
  }
  
  public void y(CharSequence paramCharSequence) {
    this.a.setTitle(paramCharSequence);
  }
  
  public void z(CharSequence paramCharSequence) {
    this.a.setWindowTitle(paramCharSequence);
  }
  
  class a implements Runnable {
    a(o this$0) {}
    
    public void run() {
      this.a.C();
    }
  }
  
  class b implements Toolbar.f {
    b(o this$0) {}
    
    public boolean onMenuItemClick(MenuItem param1MenuItem) {
      return this.a.b.onMenuItemSelected(0, param1MenuItem);
    }
  }
  
  private final class c implements m.a {
    private boolean a;
    
    c(o this$0) {}
    
    public void b(g param1g, boolean param1Boolean) {
      if (this.a)
        return; 
      this.a = true;
      this.b.a.i();
      this.b.b.onPanelClosed(108, (Menu)param1g);
      this.a = false;
    }
    
    public boolean c(g param1g) {
      this.b.b.onMenuOpened(108, (Menu)param1g);
      return true;
    }
  }
  
  private final class d implements g.a {
    d(o this$0) {}
    
    public boolean a(g param1g, MenuItem param1MenuItem) {
      return false;
    }
    
    public void b(g param1g) {
      if (this.a.a.b()) {
        this.a.b.onPanelClosed(108, (Menu)param1g);
        return;
      } 
      if (this.a.b.onPreparePanel(0, null, (Menu)param1g))
        this.a.b.onMenuOpened(108, (Menu)param1g); 
    }
  }
  
  private class e implements f.g {
    e(o this$0) {}
    
    public boolean a(int param1Int) {
      if (param1Int == 0) {
        o o1 = this.a;
        if (!o1.d) {
          o1.a.c();
          this.a.d = true;
        } 
      } 
      return false;
    }
    
    public View onCreatePanelView(int param1Int) {
      return (param1Int == 0) ? new View(this.a.a.e()) : null;
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Cricket Scorer-dex2jar.jar!\androidx\appcompat\app\o.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */