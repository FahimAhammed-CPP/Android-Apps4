package androidx.appcompat.app;

import android.app.Dialog;
import android.content.Context;
import android.os.Bundle;
import android.util.TypedValue;
import android.view.KeyEvent;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import androidx.activity.f;
import androidx.appcompat.view.b;
import androidx.core.view.g;
import e.a;

public class j extends f implements d {
  private e c;
  
  private final g.a d = new i(this);
  
  public j(Context paramContext, int paramInt) {
    super(paramContext, f(paramContext, paramInt));
    e e1 = e();
    e1.G(f(paramContext, paramInt));
    e1.r(null);
  }
  
  private static int f(Context paramContext, int paramInt) {
    int i = paramInt;
    if (paramInt == 0) {
      TypedValue typedValue = new TypedValue();
      paramContext.getTheme().resolveAttribute(a.A, typedValue, true);
      i = typedValue.resourceId;
    } 
    return i;
  }
  
  public void addContentView(View paramView, ViewGroup.LayoutParams paramLayoutParams) {
    e().d(paramView, paramLayoutParams);
  }
  
  public void dismiss() {
    super.dismiss();
    e().s();
  }
  
  public boolean dispatchKeyEvent(KeyEvent paramKeyEvent) {
    View view = getWindow().getDecorView();
    return g.e(this.d, view, (Window.Callback)this, paramKeyEvent);
  }
  
  public e e() {
    if (this.c == null)
      this.c = e.h((Dialog)this, this); 
    return this.c;
  }
  
  public <T extends View> T findViewById(int paramInt) {
    return e().i(paramInt);
  }
  
  boolean g(KeyEvent paramKeyEvent) {
    return super.dispatchKeyEvent(paramKeyEvent);
  }
  
  public boolean h(int paramInt) {
    return e().A(paramInt);
  }
  
  public void invalidateOptionsMenu() {
    e().p();
  }
  
  protected void onCreate(Bundle paramBundle) {
    e().o();
    super.onCreate(paramBundle);
    e().r(paramBundle);
  }
  
  protected void onStop() {
    super.onStop();
    e().x();
  }
  
  public void onSupportActionModeFinished(b paramb) {}
  
  public void onSupportActionModeStarted(b paramb) {}
  
  public b onWindowStartingSupportActionMode(b.a parama) {
    return null;
  }
  
  public void setContentView(int paramInt) {
    e().C(paramInt);
  }
  
  public void setContentView(View paramView) {
    e().D(paramView);
  }
  
  public void setContentView(View paramView, ViewGroup.LayoutParams paramLayoutParams) {
    e().E(paramView, paramLayoutParams);
  }
  
  public void setTitle(int paramInt) {
    super.setTitle(paramInt);
    e().H(getContext().getString(paramInt));
  }
  
  public void setTitle(CharSequence paramCharSequence) {
    super.setTitle(paramCharSequence);
    e().H(paramCharSequence);
  }
}


/* Location:              C:\soft\dex2jar-2.0\Cricket Scorer-dex2jar.jar!\androidx\appcompat\app\j.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */