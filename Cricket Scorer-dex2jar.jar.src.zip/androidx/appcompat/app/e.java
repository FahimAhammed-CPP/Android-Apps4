package androidx.appcompat.app;

import android.app.Activity;
import android.app.Dialog;
import android.content.Context;
import android.content.res.Configuration;
import android.os.Bundle;
import android.view.MenuInflater;
import android.view.View;
import android.view.ViewGroup;
import androidx.appcompat.view.b;
import androidx.appcompat.widget.Toolbar;
import androidx.appcompat.widget.l2;
import androidx.collection.b;
import java.lang.ref.WeakReference;
import java.util.Iterator;

public abstract class e {
  private static int a = -100;
  
  private static final b<WeakReference<e>> b = new b();
  
  private static final Object c = new Object();
  
  public static void B(boolean paramBoolean) {
    l2.c(paramBoolean);
  }
  
  static void c(e parame) {
    synchronized (c) {
      z(parame);
      b.add(new WeakReference<e>(parame));
      return;
    } 
  }
  
  public static e g(Activity paramActivity, d paramd) {
    return new f(paramActivity, paramd);
  }
  
  public static e h(Dialog paramDialog, d paramd) {
    return new f(paramDialog, paramd);
  }
  
  public static int j() {
    return a;
  }
  
  static void y(e parame) {
    synchronized (c) {
      z(parame);
      return;
    } 
  }
  
  private static void z(e parame) {
    synchronized (c) {
      Iterator<WeakReference<e>> iterator = b.iterator();
      while (iterator.hasNext()) {
        e e1 = ((WeakReference<e>)iterator.next()).get();
        if (e1 == parame || e1 == null)
          iterator.remove(); 
      } 
      return;
    } 
  }
  
  public abstract boolean A(int paramInt);
  
  public abstract void C(int paramInt);
  
  public abstract void D(View paramView);
  
  public abstract void E(View paramView, ViewGroup.LayoutParams paramLayoutParams);
  
  public abstract void F(Toolbar paramToolbar);
  
  public void G(int paramInt) {}
  
  public abstract void H(CharSequence paramCharSequence);
  
  public abstract b I(b.a parama);
  
  public abstract void d(View paramView, ViewGroup.LayoutParams paramLayoutParams);
  
  @Deprecated
  public void e(Context paramContext) {}
  
  public Context f(Context paramContext) {
    e(paramContext);
    return paramContext;
  }
  
  public abstract <T extends View> T i(int paramInt);
  
  public abstract b k();
  
  public int l() {
    return -100;
  }
  
  public abstract MenuInflater m();
  
  public abstract a n();
  
  public abstract void o();
  
  public abstract void p();
  
  public abstract void q(Configuration paramConfiguration);
  
  public abstract void r(Bundle paramBundle);
  
  public abstract void s();
  
  public abstract void t(Bundle paramBundle);
  
  public abstract void u();
  
  public abstract void v(Bundle paramBundle);
  
  public abstract void w();
  
  public abstract void x();
}


/* Location:              C:\soft\dex2jar-2.0\Cricket Scorer-dex2jar.jar!\androidx\appcompat\app\e.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */