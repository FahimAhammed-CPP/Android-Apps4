package androidx.appcompat.app;

import android.app.Activity;
import android.app.Dialog;
import android.content.Context;
import android.content.res.Configuration;
import android.content.res.TypedArray;
import android.graphics.drawable.Drawable;
import android.util.TypedValue;
import android.view.ContextThemeWrapper;
import android.view.KeyCharacterMap;
import android.view.KeyEvent;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.animation.AccelerateInterpolator;
import android.view.animation.DecelerateInterpolator;
import android.view.animation.Interpolator;
import androidx.appcompat.view.g;
import androidx.appcompat.view.h;
import androidx.appcompat.view.menu.g;
import androidx.appcompat.widget.ActionBarContainer;
import androidx.appcompat.widget.ActionBarContextView;
import androidx.appcompat.widget.ActionBarOverlayLayout;
import androidx.appcompat.widget.Toolbar;
import androidx.appcompat.widget.c1;
import androidx.appcompat.widget.u1;
import androidx.core.view.o0;
import androidx.core.view.o2;
import androidx.core.view.p2;
import androidx.core.view.q2;
import androidx.core.view.r2;
import e.f;
import e.j;
import java.lang.ref.WeakReference;
import java.util.ArrayList;

public class r extends a implements ActionBarOverlayLayout.d {
  private static final Interpolator E = (Interpolator)new AccelerateInterpolator();
  
  private static final Interpolator F = (Interpolator)new DecelerateInterpolator();
  
  boolean A;
  
  final p2 B = (p2)new a(this);
  
  final p2 C = (p2)new b(this);
  
  final r2 D = new c(this);
  
  Context a;
  
  private Context b;
  
  private Activity c;
  
  ActionBarOverlayLayout d;
  
  ActionBarContainer e;
  
  c1 f;
  
  ActionBarContextView g;
  
  View h;
  
  u1 i;
  
  private ArrayList<Object> j = new ArrayList();
  
  private int k = -1;
  
  private boolean l;
  
  d m;
  
  androidx.appcompat.view.b n;
  
  androidx.appcompat.view.b.a o;
  
  private boolean p;
  
  private ArrayList<a.b> q = new ArrayList<a.b>();
  
  private boolean r;
  
  private int s = 0;
  
  boolean t = true;
  
  boolean u;
  
  boolean v;
  
  private boolean w;
  
  private boolean x = true;
  
  h y;
  
  private boolean z;
  
  public r(Activity paramActivity, boolean paramBoolean) {
    this.c = paramActivity;
    View view = paramActivity.getWindow().getDecorView();
    J(view);
    if (!paramBoolean)
      this.h = view.findViewById(16908290); 
  }
  
  public r(Dialog paramDialog) {
    J(paramDialog.getWindow().getDecorView());
  }
  
  static boolean C(boolean paramBoolean1, boolean paramBoolean2, boolean paramBoolean3) {
    return paramBoolean3 ? true : (!(paramBoolean1 || paramBoolean2));
  }
  
  private c1 G(View paramView) {
    String str;
    if (paramView instanceof c1)
      return (c1)paramView; 
    if (paramView instanceof Toolbar)
      return ((Toolbar)paramView).getWrapper(); 
    StringBuilder stringBuilder = new StringBuilder();
    stringBuilder.append("Can't make a decor toolbar out of ");
    if (paramView != null) {
      str = paramView.getClass().getSimpleName();
    } else {
      str = "null";
    } 
    stringBuilder.append(str);
    throw new IllegalStateException(stringBuilder.toString());
  }
  
  private void I() {
    if (this.w) {
      this.w = false;
      ActionBarOverlayLayout actionBarOverlayLayout = this.d;
      if (actionBarOverlayLayout != null)
        actionBarOverlayLayout.setShowingForActionMode(false); 
      R(false);
    } 
  }
  
  private void J(View paramView) {
    ActionBarOverlayLayout actionBarOverlayLayout = (ActionBarOverlayLayout)paramView.findViewById(f.p);
    this.d = actionBarOverlayLayout;
    if (actionBarOverlayLayout != null)
      actionBarOverlayLayout.setActionBarVisibilityCallback(this); 
    this.f = G(paramView.findViewById(f.a));
    this.g = (ActionBarContextView)paramView.findViewById(f.f);
    ActionBarContainer actionBarContainer = (ActionBarContainer)paramView.findViewById(f.c);
    this.e = actionBarContainer;
    c1 c11 = this.f;
    if (c11 != null && this.g != null && actionBarContainer != null) {
      boolean bool;
      this.a = c11.e();
      if ((this.f.u() & 0x4) != 0) {
        i = 1;
      } else {
        i = 0;
      } 
      if (i)
        this.l = true; 
      androidx.appcompat.view.a a1 = androidx.appcompat.view.a.b(this.a);
      if (a1.a() || i) {
        bool = true;
      } else {
        bool = false;
      } 
      O(bool);
      M(a1.g());
      TypedArray typedArray = this.a.obtainStyledAttributes(null, j.a, e.a.c, 0);
      if (typedArray.getBoolean(j.k, false))
        N(true); 
      int i = typedArray.getDimensionPixelSize(j.i, 0);
      if (i != 0)
        L(i); 
      typedArray.recycle();
      return;
    } 
    StringBuilder stringBuilder = new StringBuilder();
    stringBuilder.append(getClass().getSimpleName());
    stringBuilder.append(" can only be used with a compatible window decor layout");
    throw new IllegalStateException(stringBuilder.toString());
  }
  
  private void M(boolean paramBoolean) {
    this.r = paramBoolean;
    if (!paramBoolean) {
      this.f.j(null);
      this.e.setTabContainer(this.i);
    } else {
      this.e.setTabContainer(null);
      this.f.j(this.i);
    } 
    int i = H();
    boolean bool = true;
    if (i == 2) {
      i = 1;
    } else {
      i = 0;
    } 
    u1 u11 = this.i;
    if (u11 != null) {
      ActionBarOverlayLayout actionBarOverlayLayout1;
      if (i != 0) {
        u11.setVisibility(0);
        actionBarOverlayLayout1 = this.d;
        if (actionBarOverlayLayout1 != null)
          o0.o0((View)actionBarOverlayLayout1); 
      } else {
        actionBarOverlayLayout1.setVisibility(8);
      } 
    } 
    c1 c11 = this.f;
    if (!this.r && i != 0) {
      paramBoolean = true;
    } else {
      paramBoolean = false;
    } 
    c11.z(paramBoolean);
    ActionBarOverlayLayout actionBarOverlayLayout = this.d;
    if (!this.r && i != 0) {
      paramBoolean = bool;
    } else {
      paramBoolean = false;
    } 
    actionBarOverlayLayout.setHasNonEmbeddedTabs(paramBoolean);
  }
  
  private boolean P() {
    return o0.V((View)this.e);
  }
  
  private void Q() {
    if (!this.w) {
      this.w = true;
      ActionBarOverlayLayout actionBarOverlayLayout = this.d;
      if (actionBarOverlayLayout != null)
        actionBarOverlayLayout.setShowingForActionMode(true); 
      R(false);
    } 
  }
  
  private void R(boolean paramBoolean) {
    if (C(this.u, this.v, this.w)) {
      if (!this.x) {
        this.x = true;
        F(paramBoolean);
        return;
      } 
    } else if (this.x) {
      this.x = false;
      E(paramBoolean);
    } 
  }
  
  public androidx.appcompat.view.b A(androidx.appcompat.view.b.a parama) {
    d d2 = this.m;
    if (d2 != null)
      d2.c(); 
    this.d.setHideOnContentScrollEnabled(false);
    this.g.k();
    d d1 = new d(this, this.g.getContext(), parama);
    if (d1.t()) {
      this.m = d1;
      d1.k();
      this.g.h(d1);
      B(true);
      return d1;
    } 
    return null;
  }
  
  public void B(boolean paramBoolean) {
    if (paramBoolean) {
      Q();
    } else {
      I();
    } 
    if (P()) {
      o2 o21;
      o2 o22;
      if (paramBoolean) {
        o22 = this.f.p(4, 100L);
        o21 = this.g.f(0, 200L);
      } else {
        o21 = this.f.p(0, 200L);
        o22 = this.g.f(8, 100L);
      } 
      h h1 = new h();
      h1.d(o22, o21);
      h1.h();
      return;
    } 
    if (paramBoolean) {
      this.f.r(4);
      this.g.setVisibility(0);
      return;
    } 
    this.f.r(0);
    this.g.setVisibility(8);
  }
  
  void D() {
    androidx.appcompat.view.b.a a1 = this.o;
    if (a1 != null) {
      a1.a(this.n);
      this.n = null;
      this.o = null;
    } 
  }
  
  public void E(boolean paramBoolean) {
    h h1 = this.y;
    if (h1 != null)
      h1.a(); 
    if (this.s == 0 && (this.z || paramBoolean)) {
      this.e.setAlpha(1.0F);
      this.e.setTransitioning(true);
      h1 = new h();
      float f2 = -this.e.getHeight();
      float f1 = f2;
      if (paramBoolean) {
        int[] arrayOfInt = new int[2];
        arrayOfInt[0] = 0;
        arrayOfInt[1] = 0;
        this.e.getLocationInWindow(arrayOfInt);
        f1 = f2 - arrayOfInt[1];
      } 
      o2 o2 = o0.e((View)this.e).m(f1);
      o2.k(this.D);
      h1.c(o2);
      if (this.t) {
        View view = this.h;
        if (view != null)
          h1.c(o0.e(view).m(f1)); 
      } 
      h1.f(E);
      h1.e(250L);
      h1.g(this.B);
      this.y = h1;
      h1.h();
      return;
    } 
    this.B.b(null);
  }
  
  public void F(boolean paramBoolean) {
    h h1 = this.y;
    if (h1 != null)
      h1.a(); 
    this.e.setVisibility(0);
    if (this.s == 0 && (this.z || paramBoolean)) {
      this.e.setTranslationY(0.0F);
      float f2 = -this.e.getHeight();
      float f1 = f2;
      if (paramBoolean) {
        int[] arrayOfInt = new int[2];
        arrayOfInt[0] = 0;
        arrayOfInt[1] = 0;
        this.e.getLocationInWindow(arrayOfInt);
        f1 = f2 - arrayOfInt[1];
      } 
      this.e.setTranslationY(f1);
      h1 = new h();
      o2 o2 = o0.e((View)this.e).m(0.0F);
      o2.k(this.D);
      h1.c(o2);
      if (this.t) {
        View view = this.h;
        if (view != null) {
          view.setTranslationY(f1);
          h1.c(o0.e(this.h).m(0.0F));
        } 
      } 
      h1.f(F);
      h1.e(250L);
      h1.g(this.C);
      this.y = h1;
      h1.h();
    } else {
      this.e.setAlpha(1.0F);
      this.e.setTranslationY(0.0F);
      if (this.t) {
        View view = this.h;
        if (view != null)
          view.setTranslationY(0.0F); 
      } 
      this.C.b(null);
    } 
    ActionBarOverlayLayout actionBarOverlayLayout = this.d;
    if (actionBarOverlayLayout != null)
      o0.o0((View)actionBarOverlayLayout); 
  }
  
  public int H() {
    return this.f.o();
  }
  
  public void K(int paramInt1, int paramInt2) {
    int i = this.f.u();
    if ((paramInt2 & 0x4) != 0)
      this.l = true; 
    this.f.l(paramInt1 & paramInt2 | paramInt2 & i);
  }
  
  public void L(float paramFloat) {
    o0.z0((View)this.e, paramFloat);
  }
  
  public void N(boolean paramBoolean) {
    if (!paramBoolean || this.d.w()) {
      this.A = paramBoolean;
      this.d.setHideOnContentScrollEnabled(paramBoolean);
      return;
    } 
    throw new IllegalStateException("Action bar must be in overlay mode (Window.FEATURE_OVERLAY_ACTION_BAR) to enable hide on content scroll");
  }
  
  public void O(boolean paramBoolean) {
    this.f.t(paramBoolean);
  }
  
  public void a() {
    if (this.v) {
      this.v = false;
      R(true);
    } 
  }
  
  public void b() {}
  
  public void c(boolean paramBoolean) {
    this.t = paramBoolean;
  }
  
  public void d() {
    if (!this.v) {
      this.v = true;
      R(true);
    } 
  }
  
  public void e() {
    h h1 = this.y;
    if (h1 != null) {
      h1.a();
      this.y = null;
    } 
  }
  
  public void f(int paramInt) {
    this.s = paramInt;
  }
  
  public boolean h() {
    c1 c11 = this.f;
    if (c11 != null && c11.k()) {
      this.f.collapseActionView();
      return true;
    } 
    return false;
  }
  
  public void i(boolean paramBoolean) {
    if (paramBoolean == this.p)
      return; 
    this.p = paramBoolean;
    int j = this.q.size();
    for (int i = 0; i < j; i++)
      ((a.b)this.q.get(i)).onMenuVisibilityChanged(paramBoolean); 
  }
  
  public int j() {
    return this.f.u();
  }
  
  public Context k() {
    if (this.b == null) {
      TypedValue typedValue = new TypedValue();
      this.a.getTheme().resolveAttribute(e.a.g, typedValue, true);
      int i = typedValue.resourceId;
      if (i != 0) {
        this.b = (Context)new ContextThemeWrapper(this.a, i);
      } else {
        this.b = this.a;
      } 
    } 
    return this.b;
  }
  
  public void m(Configuration paramConfiguration) {
    M(androidx.appcompat.view.a.b(this.a).g());
  }
  
  public boolean o(int paramInt, KeyEvent paramKeyEvent) {
    d d1 = this.m;
    if (d1 == null)
      return false; 
    Menu menu = d1.e();
    if (menu != null) {
      if (paramKeyEvent != null) {
        i = paramKeyEvent.getDeviceId();
      } else {
        i = -1;
      } 
      int i = KeyCharacterMap.load(i).getKeyboardType();
      boolean bool = true;
      if (i == 1)
        bool = false; 
      menu.setQwertyMode(bool);
      return menu.performShortcut(paramInt, paramKeyEvent, 0);
    } 
    return false;
  }
  
  public void r(boolean paramBoolean) {
    if (!this.l)
      s(paramBoolean); 
  }
  
  public void s(boolean paramBoolean) {
    boolean bool;
    if (paramBoolean) {
      bool = true;
    } else {
      bool = false;
    } 
    K(bool, 4);
  }
  
  public void t(boolean paramBoolean) {
    boolean bool;
    if (paramBoolean) {
      bool = true;
    } else {
      bool = false;
    } 
    K(bool, 8);
  }
  
  public void u(int paramInt) {
    this.f.v(paramInt);
  }
  
  public void v(Drawable paramDrawable) {
    this.f.y(paramDrawable);
  }
  
  public void w(boolean paramBoolean) {
    this.z = paramBoolean;
    if (!paramBoolean) {
      h h1 = this.y;
      if (h1 != null)
        h1.a(); 
    } 
  }
  
  public void x(int paramInt) {
    y(this.a.getString(paramInt));
  }
  
  public void y(CharSequence paramCharSequence) {
    this.f.setTitle(paramCharSequence);
  }
  
  public void z(CharSequence paramCharSequence) {
    this.f.setWindowTitle(paramCharSequence);
  }
  
  class a extends q2 {
    a(r this$0) {}
    
    public void b(View param1View) {
      r r1 = this.a;
      if (r1.t) {
        View view = r1.h;
        if (view != null) {
          view.setTranslationY(0.0F);
          this.a.e.setTranslationY(0.0F);
        } 
      } 
      this.a.e.setVisibility(8);
      this.a.e.setTransitioning(false);
      r1 = this.a;
      r1.y = null;
      r1.D();
      ActionBarOverlayLayout actionBarOverlayLayout = this.a.d;
      if (actionBarOverlayLayout != null)
        o0.o0((View)actionBarOverlayLayout); 
    }
  }
  
  class b extends q2 {
    b(r this$0) {}
    
    public void b(View param1View) {
      r r1 = this.a;
      r1.y = null;
      r1.e.requestLayout();
    }
  }
  
  class c implements r2 {
    c(r this$0) {}
    
    public void a(View param1View) {
      ((View)this.a.e.getParent()).invalidate();
    }
  }
  
  public class d extends androidx.appcompat.view.b implements g.a {
    private final Context c;
    
    private final g d;
    
    private androidx.appcompat.view.b.a e;
    
    private WeakReference<View> f;
    
    public d(r this$0, Context param1Context, androidx.appcompat.view.b.a param1a) {
      this.c = param1Context;
      this.e = param1a;
      g g1 = (new g(param1Context)).W(1);
      this.d = g1;
      g1.V(this);
    }
    
    public boolean a(g param1g, MenuItem param1MenuItem) {
      androidx.appcompat.view.b.a a1 = this.e;
      return (a1 != null) ? a1.d(this, param1MenuItem) : false;
    }
    
    public void b(g param1g) {
      if (this.e == null)
        return; 
      k();
      this.g.g.l();
    }
    
    public void c() {
      r r1 = this.g;
      if (r1.m != this)
        return; 
      if (!r.C(r1.u, r1.v, false)) {
        r1 = this.g;
        r1.n = this;
        r1.o = this.e;
      } else {
        this.e.a(this);
      } 
      this.e = null;
      this.g.B(false);
      this.g.g.g();
      r1 = this.g;
      r1.d.setHideOnContentScrollEnabled(r1.A);
      this.g.m = null;
    }
    
    public View d() {
      WeakReference<View> weakReference = this.f;
      return (weakReference != null) ? weakReference.get() : null;
    }
    
    public Menu e() {
      return (Menu)this.d;
    }
    
    public MenuInflater f() {
      return (MenuInflater)new g(this.c);
    }
    
    public CharSequence g() {
      return this.g.g.getSubtitle();
    }
    
    public CharSequence i() {
      return this.g.g.getTitle();
    }
    
    public void k() {
      if (this.g.m != this)
        return; 
      this.d.h0();
      try {
        this.e.c(this, (Menu)this.d);
        return;
      } finally {
        this.d.g0();
      } 
    }
    
    public boolean l() {
      return this.g.g.j();
    }
    
    public void m(View param1View) {
      this.g.g.setCustomView(param1View);
      this.f = new WeakReference<View>(param1View);
    }
    
    public void n(int param1Int) {
      o(this.g.a.getResources().getString(param1Int));
    }
    
    public void o(CharSequence param1CharSequence) {
      this.g.g.setSubtitle(param1CharSequence);
    }
    
    public void q(int param1Int) {
      r(this.g.a.getResources().getString(param1Int));
    }
    
    public void r(CharSequence param1CharSequence) {
      this.g.g.setTitle(param1CharSequence);
    }
    
    public void s(boolean param1Boolean) {
      super.s(param1Boolean);
      this.g.g.setTitleOptional(param1Boolean);
    }
    
    public boolean t() {
      this.d.h0();
      try {
        return this.e.b(this, (Menu)this.d);
      } finally {
        this.d.g0();
      } 
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Cricket Scorer-dex2jar.jar!\androidx\appcompat\app\r.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */