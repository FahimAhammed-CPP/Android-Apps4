package androidx.appcompat.app;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.content.res.Configuration;
import android.content.res.Resources;
import android.os.Build;
import android.os.Bundle;
import android.util.DisplayMetrics;
import android.view.KeyEvent;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import androidx.appcompat.widget.Toolbar;
import androidx.appcompat.widget.l2;
import androidx.core.app.d1;
import androidx.core.app.t;
import androidx.fragment.app.j;
import androidx.lifecycle.a1;
import androidx.lifecycle.v;
import androidx.lifecycle.y0;
import androidx.lifecycle.z0;
import o0.c;
import o0.e;
import o0.f;

public class AppCompatActivity extends j implements d, d1.b {
  private static final String DELEGATE_TAG = "androidx:appcompat";
  
  private e mDelegate;
  
  private Resources mResources;
  
  public AppCompatActivity() {
    initDelegate();
  }
  
  public AppCompatActivity(int paramInt) {
    super(paramInt);
    initDelegate();
  }
  
  private void initDelegate() {
    getSavedStateRegistry().h("androidx:appcompat", new a(this));
    addOnContextAvailableListener(new b(this));
  }
  
  private void initViewTreeOwners() {
    z0.a(getWindow().getDecorView(), (v)this);
    a1.a(getWindow().getDecorView(), (y0)this);
    f.a(getWindow().getDecorView(), (e)this);
  }
  
  private boolean performMenuItemShortcut(KeyEvent paramKeyEvent) {
    if (Build.VERSION.SDK_INT < 26 && !paramKeyEvent.isCtrlPressed() && !KeyEvent.metaStateHasNoModifiers(paramKeyEvent.getMetaState()) && paramKeyEvent.getRepeatCount() == 0 && !KeyEvent.isModifierKey(paramKeyEvent.getKeyCode())) {
      Window window = getWindow();
      if (window != null && window.getDecorView() != null && window.getDecorView().dispatchKeyShortcutEvent(paramKeyEvent))
        return true; 
    } 
    return false;
  }
  
  public void addContentView(View paramView, ViewGroup.LayoutParams paramLayoutParams) {
    initViewTreeOwners();
    getDelegate().d(paramView, paramLayoutParams);
  }
  
  protected void attachBaseContext(Context paramContext) {
    super.attachBaseContext(getDelegate().f(paramContext));
  }
  
  public void closeOptionsMenu() {
    a a = getSupportActionBar();
    if (getWindow().hasFeature(0) && (a == null || !a.g()))
      super.closeOptionsMenu(); 
  }
  
  public boolean dispatchKeyEvent(KeyEvent paramKeyEvent) {
    int i = paramKeyEvent.getKeyCode();
    a a = getSupportActionBar();
    return (i == 82 && a != null && a.p(paramKeyEvent)) ? true : super.dispatchKeyEvent(paramKeyEvent);
  }
  
  public <T extends View> T findViewById(int paramInt) {
    return getDelegate().i(paramInt);
  }
  
  public e getDelegate() {
    if (this.mDelegate == null)
      this.mDelegate = e.g((Activity)this, this); 
    return this.mDelegate;
  }
  
  public b getDrawerToggleDelegate() {
    return getDelegate().k();
  }
  
  public MenuInflater getMenuInflater() {
    return getDelegate().m();
  }
  
  public Resources getResources() {
    if (this.mResources == null && l2.d())
      this.mResources = (Resources)new l2((Context)this, super.getResources()); 
    Resources resources2 = this.mResources;
    Resources resources1 = resources2;
    if (resources2 == null)
      resources1 = super.getResources(); 
    return resources1;
  }
  
  public a getSupportActionBar() {
    return getDelegate().n();
  }
  
  public Intent getSupportParentActivityIntent() {
    return t.a((Activity)this);
  }
  
  public void invalidateOptionsMenu() {
    getDelegate().p();
  }
  
  public void onConfigurationChanged(Configuration paramConfiguration) {
    super.onConfigurationChanged(paramConfiguration);
    getDelegate().q(paramConfiguration);
    if (this.mResources != null) {
      paramConfiguration = super.getResources().getConfiguration();
      DisplayMetrics displayMetrics = super.getResources().getDisplayMetrics();
      this.mResources.updateConfiguration(paramConfiguration, displayMetrics);
    } 
  }
  
  public void onContentChanged() {
    onSupportContentChanged();
  }
  
  public void onCreateSupportNavigateUpTaskStack(d1 paramd1) {
    paramd1.c((Activity)this);
  }
  
  protected void onDestroy() {
    super.onDestroy();
    getDelegate().s();
  }
  
  public boolean onKeyDown(int paramInt, KeyEvent paramKeyEvent) {
    return performMenuItemShortcut(paramKeyEvent) ? true : super.onKeyDown(paramInt, paramKeyEvent);
  }
  
  public final boolean onMenuItemSelected(int paramInt, MenuItem paramMenuItem) {
    if (super.onMenuItemSelected(paramInt, paramMenuItem))
      return true; 
    a a = getSupportActionBar();
    return (paramMenuItem.getItemId() == 16908332 && a != null && (a.j() & 0x4) != 0) ? onSupportNavigateUp() : false;
  }
  
  public boolean onMenuOpened(int paramInt, Menu paramMenu) {
    return super.onMenuOpened(paramInt, paramMenu);
  }
  
  protected void onNightModeChanged(int paramInt) {}
  
  public void onPanelClosed(int paramInt, Menu paramMenu) {
    super.onPanelClosed(paramInt, paramMenu);
  }
  
  protected void onPostCreate(Bundle paramBundle) {
    super.onPostCreate(paramBundle);
    getDelegate().t(paramBundle);
  }
  
  protected void onPostResume() {
    super.onPostResume();
    getDelegate().u();
  }
  
  public void onPrepareSupportNavigateUpTaskStack(d1 paramd1) {}
  
  protected void onStart() {
    super.onStart();
    getDelegate().w();
  }
  
  protected void onStop() {
    super.onStop();
    getDelegate().x();
  }
  
  public void onSupportActionModeFinished(androidx.appcompat.view.b paramb) {}
  
  public void onSupportActionModeStarted(androidx.appcompat.view.b paramb) {}
  
  @Deprecated
  public void onSupportContentChanged() {}
  
  public boolean onSupportNavigateUp() {
    Intent intent = getSupportParentActivityIntent();
    if (intent != null) {
      if (supportShouldUpRecreateTask(intent)) {
        d1 d1 = d1.f((Context)this);
        onCreateSupportNavigateUpTaskStack(d1);
        onPrepareSupportNavigateUpTaskStack(d1);
        d1.k();
        try {
          androidx.core.app.b.b((Activity)this);
        } catch (IllegalStateException illegalStateException) {
          finish();
        } 
      } else {
        supportNavigateUpTo((Intent)illegalStateException);
      } 
      return true;
    } 
    return false;
  }
  
  protected void onTitleChanged(CharSequence paramCharSequence, int paramInt) {
    super.onTitleChanged(paramCharSequence, paramInt);
    getDelegate().H(paramCharSequence);
  }
  
  public androidx.appcompat.view.b onWindowStartingSupportActionMode(androidx.appcompat.view.b.a parama) {
    return null;
  }
  
  public void openOptionsMenu() {
    a a = getSupportActionBar();
    if (getWindow().hasFeature(0) && (a == null || !a.q()))
      super.openOptionsMenu(); 
  }
  
  public void setContentView(int paramInt) {
    initViewTreeOwners();
    getDelegate().C(paramInt);
  }
  
  public void setContentView(View paramView) {
    initViewTreeOwners();
    getDelegate().D(paramView);
  }
  
  public void setContentView(View paramView, ViewGroup.LayoutParams paramLayoutParams) {
    initViewTreeOwners();
    getDelegate().E(paramView, paramLayoutParams);
  }
  
  public void setSupportActionBar(Toolbar paramToolbar) {
    getDelegate().F(paramToolbar);
  }
  
  @Deprecated
  public void setSupportProgress(int paramInt) {}
  
  @Deprecated
  public void setSupportProgressBarIndeterminate(boolean paramBoolean) {}
  
  @Deprecated
  public void setSupportProgressBarIndeterminateVisibility(boolean paramBoolean) {}
  
  @Deprecated
  public void setSupportProgressBarVisibility(boolean paramBoolean) {}
  
  public void setTheme(int paramInt) {
    super.setTheme(paramInt);
    getDelegate().G(paramInt);
  }
  
  public androidx.appcompat.view.b startSupportActionMode(androidx.appcompat.view.b.a parama) {
    return getDelegate().I(parama);
  }
  
  public void supportInvalidateOptionsMenu() {
    getDelegate().p();
  }
  
  public void supportNavigateUpTo(Intent paramIntent) {
    t.e((Activity)this, paramIntent);
  }
  
  public boolean supportRequestWindowFeature(int paramInt) {
    return getDelegate().A(paramInt);
  }
  
  public boolean supportShouldUpRecreateTask(Intent paramIntent) {
    return t.f((Activity)this, paramIntent);
  }
  
  class a implements c.c {
    a(AppCompatActivity this$0) {}
    
    public Bundle a() {
      Bundle bundle = new Bundle();
      this.a.getDelegate().v(bundle);
      return bundle;
    }
  }
  
  class b implements c.b {
    b(AppCompatActivity this$0) {}
    
    public void a(Context param1Context) {
      e e = this.a.getDelegate();
      e.o();
      e.r(this.a.getSavedStateRegistry().b("androidx:appcompat"));
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Cricket Scorer-dex2jar.jar!\androidx\appcompat\app\AppCompatActivity.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */