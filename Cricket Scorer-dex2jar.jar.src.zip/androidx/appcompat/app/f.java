package androidx.appcompat.app;

import android.app.Activity;
import android.app.Dialog;
import android.app.UiModeManager;
import android.content.BroadcastReceiver;
import android.content.ComponentName;
import android.content.Context;
import android.content.ContextWrapper;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.pm.ActivityInfo;
import android.content.pm.PackageManager;
import android.content.res.Configuration;
import android.content.res.Resources;
import android.content.res.TypedArray;
import android.graphics.Rect;
import android.graphics.drawable.Drawable;
import android.os.Build;
import android.os.Bundle;
import android.os.LocaleList;
import android.os.PowerManager;
import android.text.TextUtils;
import android.util.AndroidRuntimeException;
import android.util.AttributeSet;
import android.util.Log;
import android.util.TypedValue;
import android.view.ActionMode;
import android.view.ContextThemeWrapper;
import android.view.KeyCharacterMap;
import android.view.KeyEvent;
import android.view.KeyboardShortcutGroup;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewConfiguration;
import android.view.ViewGroup;
import android.view.ViewParent;
import android.view.Window;
import android.view.WindowManager;
import android.widget.FrameLayout;
import android.widget.PopupWindow;
import android.widget.TextView;
import androidx.appcompat.view.menu.g;
import androidx.appcompat.widget.ActionBarContextView;
import androidx.appcompat.widget.ContentFrameLayout;
import androidx.appcompat.widget.Toolbar;
import androidx.appcompat.widget.b1;
import androidx.appcompat.widget.c2;
import androidx.appcompat.widget.l2;
import androidx.appcompat.widget.m2;
import androidx.core.view.i0;
import androidx.core.view.o0;
import androidx.core.view.o2;
import androidx.core.view.p2;
import androidx.core.view.q2;
import androidx.core.view.u2;
import androidx.lifecycle.v;
import java.util.List;
import org.xmlpull.v1.XmlPullParser;

class f extends e implements g.a, LayoutInflater.Factory2 {
  private static final androidx.collection.g<String, Integer> f0 = new androidx.collection.g();
  
  private static final boolean g0 = false;
  
  private static final int[] h0 = new int[] { 16842836 };
  
  private static final boolean i0 = "robolectric".equals(Build.FINGERPRINT) ^ true;
  
  private static final boolean j0 = true;
  
  boolean A;
  
  boolean B;
  
  boolean C;
  
  boolean D;
  
  boolean E;
  
  private boolean F;
  
  private t[] G;
  
  private t H;
  
  private boolean I;
  
  private boolean J;
  
  private boolean K;
  
  boolean L;
  
  private Configuration M;
  
  private int N = -100;
  
  private int O;
  
  private boolean P;
  
  private boolean Q;
  
  private p R;
  
  private p S;
  
  boolean T;
  
  int U;
  
  private final Runnable V = new a(this);
  
  private boolean W;
  
  private Rect X;
  
  private Rect Y;
  
  private l Z;
  
  final Object d;
  
  final Context e;
  
  private m e0;
  
  Window f;
  
  private n g;
  
  final d h;
  
  a i;
  
  MenuInflater j;
  
  private CharSequence k;
  
  private b1 l;
  
  private h m;
  
  private u n;
  
  androidx.appcompat.view.b o;
  
  ActionBarContextView p;
  
  PopupWindow q;
  
  Runnable r;
  
  o2 s = null;
  
  private boolean t = true;
  
  private boolean u;
  
  ViewGroup v;
  
  private TextView w;
  
  private View x;
  
  private boolean y;
  
  private boolean z;
  
  f(Activity paramActivity, d paramd) {
    this((Context)paramActivity, null, paramd, paramActivity);
  }
  
  f(Dialog paramDialog, d paramd) {
    this(paramDialog.getContext(), paramDialog.getWindow(), paramd, paramDialog);
  }
  
  private f(Context paramContext, Window paramWindow, d paramd, Object paramObject) {
    this.e = paramContext;
    this.h = paramd;
    this.d = paramObject;
    if (this.N == -100 && paramObject instanceof Dialog) {
      AppCompatActivity appCompatActivity = L0();
      if (appCompatActivity != null)
        this.N = appCompatActivity.getDelegate().l(); 
    } 
    if (this.N == -100) {
      androidx.collection.g<String, Integer> g1 = f0;
      Integer integer = (Integer)g1.get(paramObject.getClass().getName());
      if (integer != null) {
        this.N = integer.intValue();
        g1.remove(paramObject.getClass().getName());
      } 
    } 
    if (paramWindow != null)
      M(paramWindow); 
    androidx.appcompat.widget.h.h();
  }
  
  private void B0(t paramt, KeyEvent paramKeyEvent) {
    // Byte code:
    //   0: aload_1
    //   1: getfield o : Z
    //   4: ifne -> 405
    //   7: aload_0
    //   8: getfield L : Z
    //   11: ifeq -> 15
    //   14: return
    //   15: aload_1
    //   16: getfield a : I
    //   19: ifne -> 54
    //   22: aload_0
    //   23: getfield e : Landroid/content/Context;
    //   26: invokevirtual getResources : ()Landroid/content/res/Resources;
    //   29: invokevirtual getConfiguration : ()Landroid/content/res/Configuration;
    //   32: getfield screenLayout : I
    //   35: bipush #15
    //   37: iand
    //   38: iconst_4
    //   39: if_icmpne -> 47
    //   42: iconst_1
    //   43: istore_3
    //   44: goto -> 49
    //   47: iconst_0
    //   48: istore_3
    //   49: iload_3
    //   50: ifeq -> 54
    //   53: return
    //   54: aload_0
    //   55: invokevirtual j0 : ()Landroid/view/Window$Callback;
    //   58: astore #4
    //   60: aload #4
    //   62: ifnull -> 90
    //   65: aload #4
    //   67: aload_1
    //   68: getfield a : I
    //   71: aload_1
    //   72: getfield j : Landroidx/appcompat/view/menu/g;
    //   75: invokeinterface onMenuOpened : (ILandroid/view/Menu;)Z
    //   80: ifne -> 90
    //   83: aload_0
    //   84: aload_1
    //   85: iconst_1
    //   86: invokevirtual S : (Landroidx/appcompat/app/f$t;Z)V
    //   89: return
    //   90: aload_0
    //   91: getfield e : Landroid/content/Context;
    //   94: ldc_w 'window'
    //   97: invokevirtual getSystemService : (Ljava/lang/String;)Ljava/lang/Object;
    //   100: checkcast android/view/WindowManager
    //   103: astore #5
    //   105: aload #5
    //   107: ifnonnull -> 111
    //   110: return
    //   111: aload_0
    //   112: aload_1
    //   113: aload_2
    //   114: invokespecial E0 : (Landroidx/appcompat/app/f$t;Landroid/view/KeyEvent;)Z
    //   117: ifne -> 121
    //   120: return
    //   121: aload_1
    //   122: getfield g : Landroid/view/ViewGroup;
    //   125: astore_2
    //   126: aload_2
    //   127: ifnull -> 171
    //   130: aload_1
    //   131: getfield q : Z
    //   134: ifeq -> 140
    //   137: goto -> 171
    //   140: aload_1
    //   141: getfield i : Landroid/view/View;
    //   144: astore_2
    //   145: aload_2
    //   146: ifnull -> 331
    //   149: aload_2
    //   150: invokevirtual getLayoutParams : ()Landroid/view/ViewGroup$LayoutParams;
    //   153: astore_2
    //   154: aload_2
    //   155: ifnull -> 331
    //   158: aload_2
    //   159: getfield width : I
    //   162: iconst_m1
    //   163: if_icmpne -> 331
    //   166: iconst_m1
    //   167: istore_3
    //   168: goto -> 334
    //   171: aload_2
    //   172: ifnonnull -> 191
    //   175: aload_0
    //   176: aload_1
    //   177: invokespecial m0 : (Landroidx/appcompat/app/f$t;)Z
    //   180: ifeq -> 190
    //   183: aload_1
    //   184: getfield g : Landroid/view/ViewGroup;
    //   187: ifnonnull -> 212
    //   190: return
    //   191: aload_1
    //   192: getfield q : Z
    //   195: ifeq -> 212
    //   198: aload_2
    //   199: invokevirtual getChildCount : ()I
    //   202: ifle -> 212
    //   205: aload_1
    //   206: getfield g : Landroid/view/ViewGroup;
    //   209: invokevirtual removeAllViews : ()V
    //   212: aload_0
    //   213: aload_1
    //   214: invokespecial l0 : (Landroidx/appcompat/app/f$t;)Z
    //   217: ifeq -> 400
    //   220: aload_1
    //   221: invokevirtual b : ()Z
    //   224: ifne -> 230
    //   227: goto -> 400
    //   230: aload_1
    //   231: getfield h : Landroid/view/View;
    //   234: invokevirtual getLayoutParams : ()Landroid/view/ViewGroup$LayoutParams;
    //   237: astore #4
    //   239: aload #4
    //   241: astore_2
    //   242: aload #4
    //   244: ifnonnull -> 259
    //   247: new android/view/ViewGroup$LayoutParams
    //   250: dup
    //   251: bipush #-2
    //   253: bipush #-2
    //   255: invokespecial <init> : (II)V
    //   258: astore_2
    //   259: aload_1
    //   260: getfield b : I
    //   263: istore_3
    //   264: aload_1
    //   265: getfield g : Landroid/view/ViewGroup;
    //   268: iload_3
    //   269: invokevirtual setBackgroundResource : (I)V
    //   272: aload_1
    //   273: getfield h : Landroid/view/View;
    //   276: invokevirtual getParent : ()Landroid/view/ViewParent;
    //   279: astore #4
    //   281: aload #4
    //   283: instanceof android/view/ViewGroup
    //   286: ifeq -> 301
    //   289: aload #4
    //   291: checkcast android/view/ViewGroup
    //   294: aload_1
    //   295: getfield h : Landroid/view/View;
    //   298: invokevirtual removeView : (Landroid/view/View;)V
    //   301: aload_1
    //   302: getfield g : Landroid/view/ViewGroup;
    //   305: aload_1
    //   306: getfield h : Landroid/view/View;
    //   309: aload_2
    //   310: invokevirtual addView : (Landroid/view/View;Landroid/view/ViewGroup$LayoutParams;)V
    //   313: aload_1
    //   314: getfield h : Landroid/view/View;
    //   317: invokevirtual hasFocus : ()Z
    //   320: ifne -> 331
    //   323: aload_1
    //   324: getfield h : Landroid/view/View;
    //   327: invokevirtual requestFocus : ()Z
    //   330: pop
    //   331: bipush #-2
    //   333: istore_3
    //   334: aload_1
    //   335: iconst_0
    //   336: putfield n : Z
    //   339: new android/view/WindowManager$LayoutParams
    //   342: dup
    //   343: iload_3
    //   344: bipush #-2
    //   346: aload_1
    //   347: getfield d : I
    //   350: aload_1
    //   351: getfield e : I
    //   354: sipush #1002
    //   357: ldc_w 8519680
    //   360: bipush #-3
    //   362: invokespecial <init> : (IIIIIII)V
    //   365: astore_2
    //   366: aload_2
    //   367: aload_1
    //   368: getfield c : I
    //   371: putfield gravity : I
    //   374: aload_2
    //   375: aload_1
    //   376: getfield f : I
    //   379: putfield windowAnimations : I
    //   382: aload #5
    //   384: aload_1
    //   385: getfield g : Landroid/view/ViewGroup;
    //   388: aload_2
    //   389: invokeinterface addView : (Landroid/view/View;Landroid/view/ViewGroup$LayoutParams;)V
    //   394: aload_1
    //   395: iconst_1
    //   396: putfield o : Z
    //   399: return
    //   400: aload_1
    //   401: iconst_1
    //   402: putfield q : Z
    //   405: return
  }
  
  private boolean D0(t paramt, int paramInt1, KeyEvent paramKeyEvent, int paramInt2) {
    // Byte code:
    //   0: aload_3
    //   1: invokevirtual isSystem : ()Z
    //   4: istore #5
    //   6: iconst_0
    //   7: istore #6
    //   9: iload #5
    //   11: ifeq -> 16
    //   14: iconst_0
    //   15: ireturn
    //   16: aload_1
    //   17: getfield m : Z
    //   20: ifne -> 36
    //   23: iload #6
    //   25: istore #5
    //   27: aload_0
    //   28: aload_1
    //   29: aload_3
    //   30: invokespecial E0 : (Landroidx/appcompat/app/f$t;Landroid/view/KeyEvent;)Z
    //   33: ifeq -> 62
    //   36: aload_1
    //   37: getfield j : Landroidx/appcompat/view/menu/g;
    //   40: astore #7
    //   42: iload #6
    //   44: istore #5
    //   46: aload #7
    //   48: ifnull -> 62
    //   51: aload #7
    //   53: iload_2
    //   54: aload_3
    //   55: iload #4
    //   57: invokevirtual performShortcut : (ILandroid/view/KeyEvent;I)Z
    //   60: istore #5
    //   62: iload #5
    //   64: ifeq -> 87
    //   67: iload #4
    //   69: iconst_1
    //   70: iand
    //   71: ifne -> 87
    //   74: aload_0
    //   75: getfield l : Landroidx/appcompat/widget/b1;
    //   78: ifnonnull -> 87
    //   81: aload_0
    //   82: aload_1
    //   83: iconst_1
    //   84: invokevirtual S : (Landroidx/appcompat/app/f$t;Z)V
    //   87: iload #5
    //   89: ireturn
  }
  
  private boolean E0(t paramt, KeyEvent paramKeyEvent) {
    b1 b11;
    if (this.L)
      return false; 
    if (paramt.m)
      return true; 
    t t1 = this.H;
    if (t1 != null && t1 != paramt)
      S(t1, false); 
    Window.Callback callback = j0();
    if (callback != null)
      paramt.i = callback.onCreatePanelView(paramt.a); 
    int i = paramt.a;
    if (i == 0 || i == 108) {
      i = 1;
    } else {
      i = 0;
    } 
    if (i != 0) {
      b1 b12 = this.l;
      if (b12 != null)
        b12.c(); 
    } 
    if (paramt.i == null && (i == 0 || !(C0() instanceof o))) {
      b1 b12;
      boolean bool;
      g g1 = paramt.j;
      if (g1 == null || paramt.r) {
        if (g1 == null && (!n0(paramt) || paramt.j == null))
          return false; 
        if (i != 0 && this.l != null) {
          if (this.m == null)
            this.m = new h(this); 
          this.l.a((Menu)paramt.j, this.m);
        } 
        paramt.j.h0();
        if (!callback.onCreatePanelMenu(paramt.a, (Menu)paramt.j)) {
          paramt.c(null);
          if (i != 0) {
            b11 = this.l;
            if (b11 != null)
              b11.a(null, this.m); 
          } 
          return false;
        } 
        ((t)b11).r = false;
      } 
      ((t)b11).j.h0();
      Bundle bundle = ((t)b11).s;
      if (bundle != null) {
        ((t)b11).j.R(bundle);
        ((t)b11).s = null;
      } 
      if (!callback.onPreparePanel(0, ((t)b11).i, (Menu)((t)b11).j)) {
        if (i != 0) {
          b12 = this.l;
          if (b12 != null)
            b12.a(null, this.m); 
        } 
        ((t)b11).j.g0();
        return false;
      } 
      if (b12 != null) {
        i = b12.getDeviceId();
      } else {
        i = -1;
      } 
      if (KeyCharacterMap.load(i).getKeyboardType() != 1) {
        bool = true;
      } else {
        bool = false;
      } 
      ((t)b11).p = bool;
      ((t)b11).j.setQwertyMode(bool);
      ((t)b11).j.g0();
    } 
    ((t)b11).m = true;
    ((t)b11).n = false;
    this.H = (t)b11;
    return true;
  }
  
  private void F0(boolean paramBoolean) {
    b1 b11 = this.l;
    if (b11 != null && b11.d() && (!ViewConfiguration.get(this.e).hasPermanentMenuKey() || this.l.f())) {
      Window.Callback callback = j0();
      if (!this.l.b() || !paramBoolean) {
        if (callback != null && !this.L) {
          if (this.T && (this.U & 0x1) != 0) {
            this.f.getDecorView().removeCallbacks(this.V);
            this.V.run();
          } 
          t t2 = h0(0, true);
          g g1 = t2.j;
          if (g1 != null && !t2.r && callback.onPreparePanel(0, t2.i, (Menu)g1)) {
            callback.onMenuOpened(108, (Menu)t2.j);
            this.l.h();
          } 
        } 
        return;
      } 
      this.l.g();
      if (!this.L) {
        callback.onPanelClosed(108, (Menu)(h0(0, true)).j);
        return;
      } 
      return;
    } 
    t t1 = h0(0, true);
    t1.q = true;
    S(t1, false);
    B0(t1, null);
  }
  
  private int G0(int paramInt) {
    if (paramInt == 8) {
      Log.i("AppCompatDelegate", "You should now use the AppCompatDelegate.FEATURE_SUPPORT_ACTION_BAR id when requesting this feature.");
      return 108;
    } 
    int i = paramInt;
    if (paramInt == 9) {
      Log.i("AppCompatDelegate", "You should now use the AppCompatDelegate.FEATURE_SUPPORT_ACTION_BAR_OVERLAY id when requesting this feature.");
      i = 109;
    } 
    return i;
  }
  
  private boolean I0(ViewParent paramViewParent) {
    if (paramViewParent == null)
      return false; 
    View view = this.f.getDecorView();
    while (true) {
      if (paramViewParent == null)
        return true; 
      if (paramViewParent != view && paramViewParent instanceof View) {
        if (o0.U((View)paramViewParent))
          return false; 
        paramViewParent = paramViewParent.getParent();
        continue;
      } 
      break;
    } 
    return false;
  }
  
  private boolean K(boolean paramBoolean) {
    if (this.L)
      return false; 
    int i = N();
    paramBoolean = M0(r0(this.e, i), paramBoolean);
    if (i == 0) {
      g0(this.e).e();
    } else {
      p p2 = this.R;
      if (p2 != null)
        p2.a(); 
    } 
    if (i == 3) {
      f0(this.e).e();
      return paramBoolean;
    } 
    p p1 = this.S;
    if (p1 != null)
      p1.a(); 
    return paramBoolean;
  }
  
  private void K0() {
    if (!this.u)
      return; 
    throw new AndroidRuntimeException("Window feature must be requested before adding content");
  }
  
  private void L() {
    ContentFrameLayout contentFrameLayout = (ContentFrameLayout)this.v.findViewById(16908290);
    View view = this.f.getDecorView();
    contentFrameLayout.a(view.getPaddingLeft(), view.getPaddingTop(), view.getPaddingRight(), view.getPaddingBottom());
    TypedArray typedArray = this.e.obtainStyledAttributes(e.j.y0);
    typedArray.getValue(e.j.K0, contentFrameLayout.getMinWidthMajor());
    typedArray.getValue(e.j.L0, contentFrameLayout.getMinWidthMinor());
    int i = e.j.I0;
    if (typedArray.hasValue(i))
      typedArray.getValue(i, contentFrameLayout.getFixedWidthMajor()); 
    i = e.j.J0;
    if (typedArray.hasValue(i))
      typedArray.getValue(i, contentFrameLayout.getFixedWidthMinor()); 
    i = e.j.G0;
    if (typedArray.hasValue(i))
      typedArray.getValue(i, contentFrameLayout.getFixedHeightMajor()); 
    i = e.j.H0;
    if (typedArray.hasValue(i))
      typedArray.getValue(i, contentFrameLayout.getFixedHeightMinor()); 
    typedArray.recycle();
    contentFrameLayout.requestLayout();
  }
  
  private AppCompatActivity L0() {
    Context context = this.e;
    while (context != null) {
      if (context instanceof AppCompatActivity)
        return (AppCompatActivity)context; 
      if (context instanceof ContextWrapper)
        context = ((ContextWrapper)context).getBaseContext(); 
    } 
    return null;
  }
  
  private void M(Window paramWindow) {
    if (this.f == null) {
      Window.Callback callback = paramWindow.getCallback();
      if (!(callback instanceof n)) {
        n n1 = new n(this, callback);
        this.g = n1;
        paramWindow.setCallback((Window.Callback)n1);
        c2 c2 = c2.u(this.e, null, h0);
        Drawable drawable = c2.h(0);
        if (drawable != null)
          paramWindow.setBackgroundDrawable(drawable); 
        c2.w();
        this.f = paramWindow;
        return;
      } 
      throw new IllegalStateException("AppCompat has already installed itself into the Window");
    } 
    throw new IllegalStateException("AppCompat has already installed itself into the Window");
  }
  
  private boolean M0(int paramInt, boolean paramBoolean) {
    // Byte code:
    //   0: aload_0
    //   1: getfield e : Landroid/content/Context;
    //   4: astore #9
    //   6: iconst_0
    //   7: istore #7
    //   9: aload_0
    //   10: aload #9
    //   12: iload_1
    //   13: aconst_null
    //   14: iconst_0
    //   15: invokespecial T : (Landroid/content/Context;ILandroid/content/res/Configuration;Z)Landroid/content/res/Configuration;
    //   18: astore #11
    //   20: aload_0
    //   21: aload_0
    //   22: getfield e : Landroid/content/Context;
    //   25: invokespecial p0 : (Landroid/content/Context;)Z
    //   28: istore #8
    //   30: aload_0
    //   31: getfield M : Landroid/content/res/Configuration;
    //   34: astore #10
    //   36: aload #10
    //   38: astore #9
    //   40: aload #10
    //   42: ifnonnull -> 57
    //   45: aload_0
    //   46: getfield e : Landroid/content/Context;
    //   49: invokevirtual getResources : ()Landroid/content/res/Resources;
    //   52: invokevirtual getConfiguration : ()Landroid/content/res/Configuration;
    //   55: astore #9
    //   57: aload #9
    //   59: getfield uiMode : I
    //   62: bipush #48
    //   64: iand
    //   65: istore_3
    //   66: aload #11
    //   68: getfield uiMode : I
    //   71: bipush #48
    //   73: iand
    //   74: istore #4
    //   76: iconst_1
    //   77: istore #6
    //   79: iload #7
    //   81: istore #5
    //   83: iload_3
    //   84: iload #4
    //   86: if_icmpeq -> 180
    //   89: iload #7
    //   91: istore #5
    //   93: iload_2
    //   94: ifeq -> 180
    //   97: iload #7
    //   99: istore #5
    //   101: iload #8
    //   103: ifne -> 180
    //   106: iload #7
    //   108: istore #5
    //   110: aload_0
    //   111: getfield J : Z
    //   114: ifeq -> 180
    //   117: getstatic androidx/appcompat/app/f.i0 : Z
    //   120: ifne -> 134
    //   123: iload #7
    //   125: istore #5
    //   127: aload_0
    //   128: getfield K : Z
    //   131: ifeq -> 180
    //   134: aload_0
    //   135: getfield d : Ljava/lang/Object;
    //   138: astore #9
    //   140: iload #7
    //   142: istore #5
    //   144: aload #9
    //   146: instanceof android/app/Activity
    //   149: ifeq -> 180
    //   152: iload #7
    //   154: istore #5
    //   156: aload #9
    //   158: checkcast android/app/Activity
    //   161: invokevirtual isChild : ()Z
    //   164: ifne -> 180
    //   167: aload_0
    //   168: getfield d : Ljava/lang/Object;
    //   171: checkcast android/app/Activity
    //   174: invokestatic f : (Landroid/app/Activity;)V
    //   177: iconst_1
    //   178: istore #5
    //   180: iload #5
    //   182: ifne -> 207
    //   185: iload_3
    //   186: iload #4
    //   188: if_icmpeq -> 207
    //   191: aload_0
    //   192: iload #4
    //   194: iload #8
    //   196: aconst_null
    //   197: invokespecial N0 : (IZLandroid/content/res/Configuration;)V
    //   200: iload #6
    //   202: istore #5
    //   204: goto -> 207
    //   207: iload #5
    //   209: ifeq -> 235
    //   212: aload_0
    //   213: getfield d : Ljava/lang/Object;
    //   216: astore #9
    //   218: aload #9
    //   220: instanceof androidx/appcompat/app/AppCompatActivity
    //   223: ifeq -> 235
    //   226: aload #9
    //   228: checkcast androidx/appcompat/app/AppCompatActivity
    //   231: iload_1
    //   232: invokevirtual onNightModeChanged : (I)V
    //   235: iload #5
    //   237: ireturn
  }
  
  private int N() {
    int i = this.N;
    return (i != -100) ? i : e.j();
  }
  
  private void N0(int paramInt, boolean paramBoolean, Configuration paramConfiguration) {
    Resources resources = this.e.getResources();
    Configuration configuration = new Configuration(resources.getConfiguration());
    if (paramConfiguration != null)
      configuration.updateFrom(paramConfiguration); 
    configuration.uiMode = paramInt | (resources.getConfiguration()).uiMode & 0xFFFFFFCF;
    resources.updateConfiguration(configuration, null);
    paramInt = Build.VERSION.SDK_INT;
    if (paramInt < 26)
      n.a(resources); 
    int i = this.O;
    if (i != 0) {
      this.e.setTheme(i);
      if (paramInt >= 23)
        this.e.getTheme().applyStyle(this.O, true); 
    } 
    if (paramBoolean) {
      Object object = this.d;
      if (object instanceof Activity) {
        object = object;
        if (object instanceof v) {
          if (((v)object).getLifecycle().b().a(androidx.lifecycle.m.c.c)) {
            object.onConfigurationChanged(configuration);
            return;
          } 
        } else if (this.K && !this.L) {
          object.onConfigurationChanged(configuration);
        } 
      } 
    } 
  }
  
  private void P0(View paramView) {
    int i;
    if ((o0.N(paramView) & 0x2000) != 0) {
      i = 1;
    } else {
      i = 0;
    } 
    if (i) {
      i = androidx.core.content.a.getColor(this.e, e.c.b);
    } else {
      i = androidx.core.content.a.getColor(this.e, e.c.a);
    } 
    paramView.setBackgroundColor(i);
  }
  
  private void Q() {
    p p1 = this.R;
    if (p1 != null)
      p1.a(); 
    p1 = this.S;
    if (p1 != null)
      p1.a(); 
  }
  
  private Configuration T(Context paramContext, int paramInt, Configuration paramConfiguration, boolean paramBoolean) {
    if (paramInt != 1) {
      if (paramInt != 2) {
        if (paramBoolean) {
          paramInt = 0;
        } else {
          paramInt = (paramContext.getApplicationContext().getResources().getConfiguration()).uiMode & 0x30;
        } 
      } else {
        paramInt = 32;
      } 
    } else {
      paramInt = 16;
    } 
    Configuration configuration = new Configuration();
    configuration.fontScale = 0.0F;
    if (paramConfiguration != null)
      configuration.setTo(paramConfiguration); 
    configuration.uiMode = paramInt | configuration.uiMode & 0xFFFFFFCF;
    return configuration;
  }
  
  private ViewGroup U() {
    StringBuilder stringBuilder;
    TypedArray typedArray = this.e.obtainStyledAttributes(e.j.y0);
    int i = e.j.D0;
    if (typedArray.hasValue(i)) {
      ViewGroup viewGroup;
      if (typedArray.getBoolean(e.j.M0, false)) {
        A(1);
      } else if (typedArray.getBoolean(i, false)) {
        A(108);
      } 
      if (typedArray.getBoolean(e.j.E0, false))
        A(109); 
      if (typedArray.getBoolean(e.j.F0, false))
        A(10); 
      this.D = typedArray.getBoolean(e.j.z0, false);
      typedArray.recycle();
      b0();
      this.f.getDecorView();
      LayoutInflater layoutInflater = LayoutInflater.from(this.e);
      if (!this.E) {
        if (this.D) {
          viewGroup = (ViewGroup)layoutInflater.inflate(e.g.f, null);
          this.B = false;
          this.A = false;
        } else if (this.A) {
          Context context;
          TypedValue typedValue = new TypedValue();
          this.e.getTheme().resolveAttribute(e.a.f, typedValue, true);
          if (typedValue.resourceId != 0) {
            androidx.appcompat.view.d d1 = new androidx.appcompat.view.d(this.e, typedValue.resourceId);
          } else {
            context = this.e;
          } 
          ViewGroup viewGroup1 = (ViewGroup)LayoutInflater.from(context).inflate(e.g.p, null);
          b1 b11 = (b1)viewGroup1.findViewById(e.f.p);
          this.l = b11;
          b11.setWindowCallback(j0());
          if (this.B)
            this.l.i(109); 
          if (this.y)
            this.l.i(2); 
          viewGroup = viewGroup1;
          if (this.z) {
            this.l.i(5);
            viewGroup = viewGroup1;
          } 
        } else {
          layoutInflater = null;
        } 
      } else if (this.C) {
        viewGroup = (ViewGroup)layoutInflater.inflate(e.g.o, null);
      } else {
        viewGroup = (ViewGroup)viewGroup.inflate(e.g.n, null);
      } 
      if (viewGroup != null) {
        o0.E0((View)viewGroup, new b(this));
        if (this.l == null)
          this.w = (TextView)viewGroup.findViewById(e.f.M); 
        m2.c((View)viewGroup);
        ContentFrameLayout contentFrameLayout = (ContentFrameLayout)viewGroup.findViewById(e.f.b);
        ViewGroup viewGroup1 = (ViewGroup)this.f.findViewById(16908290);
        if (viewGroup1 != null) {
          while (viewGroup1.getChildCount() > 0) {
            View view = viewGroup1.getChildAt(0);
            viewGroup1.removeViewAt(0);
            contentFrameLayout.addView(view);
          } 
          viewGroup1.setId(-1);
          contentFrameLayout.setId(16908290);
          if (viewGroup1 instanceof FrameLayout)
            ((FrameLayout)viewGroup1).setForeground(null); 
        } 
        this.f.setContentView((View)viewGroup);
        contentFrameLayout.setAttachListener(new c(this));
        return viewGroup;
      } 
      stringBuilder = new StringBuilder();
      stringBuilder.append("AppCompat does not support the current theme features: { windowActionBar: ");
      stringBuilder.append(this.A);
      stringBuilder.append(", windowActionBarOverlay: ");
      stringBuilder.append(this.B);
      stringBuilder.append(", android:windowIsFloating: ");
      stringBuilder.append(this.D);
      stringBuilder.append(", windowActionModeOverlay: ");
      stringBuilder.append(this.C);
      stringBuilder.append(", windowNoTitle: ");
      stringBuilder.append(this.E);
      stringBuilder.append(" }");
      throw new IllegalArgumentException(stringBuilder.toString());
    } 
    stringBuilder.recycle();
    throw new IllegalStateException("You need to use a Theme.AppCompat theme (or descendant) with this activity.");
  }
  
  private void a0() {
    if (!this.u) {
      this.v = U();
      CharSequence charSequence = i0();
      if (!TextUtils.isEmpty(charSequence)) {
        b1 b11 = this.l;
        if (b11 != null) {
          b11.setWindowTitle(charSequence);
        } else if (C0() != null) {
          C0().z(charSequence);
        } else {
          TextView textView = this.w;
          if (textView != null)
            textView.setText(charSequence); 
        } 
      } 
      L();
      A0(this.v);
      this.u = true;
      t t1 = h0(0, false);
      if (!this.L && (t1 == null || t1.j == null))
        o0(108); 
    } 
  }
  
  private void b0() {
    if (this.f == null) {
      Object object = this.d;
      if (object instanceof Activity)
        M(((Activity)object).getWindow()); 
    } 
    if (this.f != null)
      return; 
    throw new IllegalStateException("We have not been given a Window");
  }
  
  private static Configuration d0(Configuration paramConfiguration1, Configuration paramConfiguration2) {
    Configuration configuration = new Configuration();
    configuration.fontScale = 0.0F;
    if (paramConfiguration2 != null) {
      if (paramConfiguration1.diff(paramConfiguration2) == 0)
        return configuration; 
      float f1 = paramConfiguration1.fontScale;
      float f2 = paramConfiguration2.fontScale;
      if (f1 != f2)
        configuration.fontScale = f2; 
      int i = paramConfiguration1.mcc;
      int j = paramConfiguration2.mcc;
      if (i != j)
        configuration.mcc = j; 
      i = paramConfiguration1.mnc;
      j = paramConfiguration2.mnc;
      if (i != j)
        configuration.mnc = j; 
      i = Build.VERSION.SDK_INT;
      if (i >= 24) {
        l.a(paramConfiguration1, paramConfiguration2, configuration);
      } else if (!androidx.core.util.c.a(paramConfiguration1.locale, paramConfiguration2.locale)) {
        configuration.locale = paramConfiguration2.locale;
      } 
      j = paramConfiguration1.touchscreen;
      int k = paramConfiguration2.touchscreen;
      if (j != k)
        configuration.touchscreen = k; 
      j = paramConfiguration1.keyboard;
      k = paramConfiguration2.keyboard;
      if (j != k)
        configuration.keyboard = k; 
      j = paramConfiguration1.keyboardHidden;
      k = paramConfiguration2.keyboardHidden;
      if (j != k)
        configuration.keyboardHidden = k; 
      j = paramConfiguration1.navigation;
      k = paramConfiguration2.navigation;
      if (j != k)
        configuration.navigation = k; 
      j = paramConfiguration1.navigationHidden;
      k = paramConfiguration2.navigationHidden;
      if (j != k)
        configuration.navigationHidden = k; 
      j = paramConfiguration1.orientation;
      k = paramConfiguration2.orientation;
      if (j != k)
        configuration.orientation = k; 
      j = paramConfiguration1.screenLayout;
      k = paramConfiguration2.screenLayout;
      if ((j & 0xF) != (k & 0xF))
        configuration.screenLayout |= k & 0xF; 
      j = paramConfiguration1.screenLayout;
      k = paramConfiguration2.screenLayout;
      if ((j & 0xC0) != (k & 0xC0))
        configuration.screenLayout |= k & 0xC0; 
      j = paramConfiguration1.screenLayout;
      k = paramConfiguration2.screenLayout;
      if ((j & 0x30) != (k & 0x30))
        configuration.screenLayout |= k & 0x30; 
      j = paramConfiguration1.screenLayout;
      k = paramConfiguration2.screenLayout;
      if ((j & 0x300) != (k & 0x300))
        configuration.screenLayout |= k & 0x300; 
      if (i >= 26)
        m.a(paramConfiguration1, paramConfiguration2, configuration); 
      i = paramConfiguration1.uiMode;
      j = paramConfiguration2.uiMode;
      if ((i & 0xF) != (j & 0xF))
        configuration.uiMode |= j & 0xF; 
      i = paramConfiguration1.uiMode;
      j = paramConfiguration2.uiMode;
      if ((i & 0x30) != (j & 0x30))
        configuration.uiMode |= j & 0x30; 
      i = paramConfiguration1.screenWidthDp;
      j = paramConfiguration2.screenWidthDp;
      if (i != j)
        configuration.screenWidthDp = j; 
      i = paramConfiguration1.screenHeightDp;
      j = paramConfiguration2.screenHeightDp;
      if (i != j)
        configuration.screenHeightDp = j; 
      i = paramConfiguration1.smallestScreenWidthDp;
      j = paramConfiguration2.smallestScreenWidthDp;
      if (i != j)
        configuration.smallestScreenWidthDp = j; 
      j.b(paramConfiguration1, paramConfiguration2, configuration);
    } 
    return configuration;
  }
  
  private p f0(Context paramContext) {
    if (this.S == null)
      this.S = new o(this, paramContext); 
    return this.S;
  }
  
  private p g0(Context paramContext) {
    if (this.R == null)
      this.R = new q(this, q.a(paramContext)); 
    return this.R;
  }
  
  private void k0() {
    a0();
    if (this.A) {
      if (this.i != null)
        return; 
      Object object = this.d;
      if (object instanceof Activity) {
        this.i = new r((Activity)this.d, this.B);
      } else if (object instanceof Dialog) {
        this.i = new r((Dialog)this.d);
      } 
      object = this.i;
      if (object != null)
        object.r(this.W); 
    } 
  }
  
  private boolean l0(t paramt) {
    View view = paramt.i;
    if (view != null) {
      paramt.h = view;
      return true;
    } 
    if (paramt.j == null)
      return false; 
    if (this.n == null)
      this.n = new u(this); 
    view = (View)paramt.a(this.n);
    paramt.h = view;
    return (view != null);
  }
  
  private boolean m0(t paramt) {
    paramt.d(e0());
    paramt.g = (ViewGroup)new s(this, paramt.l);
    paramt.c = 81;
    return true;
  }
  
  private boolean n0(t paramt) {
    // Byte code:
    //   0: aload_0
    //   1: getfield e : Landroid/content/Context;
    //   4: astore #5
    //   6: aload_1
    //   7: getfield a : I
    //   10: istore_2
    //   11: iload_2
    //   12: ifeq -> 24
    //   15: aload #5
    //   17: astore_3
    //   18: iload_2
    //   19: bipush #108
    //   21: if_icmpne -> 197
    //   24: aload #5
    //   26: astore_3
    //   27: aload_0
    //   28: getfield l : Landroidx/appcompat/widget/b1;
    //   31: ifnull -> 197
    //   34: new android/util/TypedValue
    //   37: dup
    //   38: invokespecial <init> : ()V
    //   41: astore #6
    //   43: aload #5
    //   45: invokevirtual getTheme : ()Landroid/content/res/Resources$Theme;
    //   48: astore #7
    //   50: aload #7
    //   52: getstatic e/a.f : I
    //   55: aload #6
    //   57: iconst_1
    //   58: invokevirtual resolveAttribute : (ILandroid/util/TypedValue;Z)Z
    //   61: pop
    //   62: aconst_null
    //   63: astore_3
    //   64: aload #6
    //   66: getfield resourceId : I
    //   69: ifeq -> 111
    //   72: aload #5
    //   74: invokevirtual getResources : ()Landroid/content/res/Resources;
    //   77: invokevirtual newTheme : ()Landroid/content/res/Resources$Theme;
    //   80: astore_3
    //   81: aload_3
    //   82: aload #7
    //   84: invokevirtual setTo : (Landroid/content/res/Resources$Theme;)V
    //   87: aload_3
    //   88: aload #6
    //   90: getfield resourceId : I
    //   93: iconst_1
    //   94: invokevirtual applyStyle : (IZ)V
    //   97: aload_3
    //   98: getstatic e/a.g : I
    //   101: aload #6
    //   103: iconst_1
    //   104: invokevirtual resolveAttribute : (ILandroid/util/TypedValue;Z)Z
    //   107: pop
    //   108: goto -> 123
    //   111: aload #7
    //   113: getstatic e/a.g : I
    //   116: aload #6
    //   118: iconst_1
    //   119: invokevirtual resolveAttribute : (ILandroid/util/TypedValue;Z)Z
    //   122: pop
    //   123: aload_3
    //   124: astore #4
    //   126: aload #6
    //   128: getfield resourceId : I
    //   131: ifeq -> 169
    //   134: aload_3
    //   135: astore #4
    //   137: aload_3
    //   138: ifnonnull -> 158
    //   141: aload #5
    //   143: invokevirtual getResources : ()Landroid/content/res/Resources;
    //   146: invokevirtual newTheme : ()Landroid/content/res/Resources$Theme;
    //   149: astore #4
    //   151: aload #4
    //   153: aload #7
    //   155: invokevirtual setTo : (Landroid/content/res/Resources$Theme;)V
    //   158: aload #4
    //   160: aload #6
    //   162: getfield resourceId : I
    //   165: iconst_1
    //   166: invokevirtual applyStyle : (IZ)V
    //   169: aload #5
    //   171: astore_3
    //   172: aload #4
    //   174: ifnull -> 197
    //   177: new androidx/appcompat/view/d
    //   180: dup
    //   181: aload #5
    //   183: iconst_0
    //   184: invokespecial <init> : (Landroid/content/Context;I)V
    //   187: astore_3
    //   188: aload_3
    //   189: invokevirtual getTheme : ()Landroid/content/res/Resources$Theme;
    //   192: aload #4
    //   194: invokevirtual setTo : (Landroid/content/res/Resources$Theme;)V
    //   197: new androidx/appcompat/view/menu/g
    //   200: dup
    //   201: aload_3
    //   202: invokespecial <init> : (Landroid/content/Context;)V
    //   205: astore_3
    //   206: aload_3
    //   207: aload_0
    //   208: invokevirtual V : (Landroidx/appcompat/view/menu/g$a;)V
    //   211: aload_1
    //   212: aload_3
    //   213: invokevirtual c : (Landroidx/appcompat/view/menu/g;)V
    //   216: iconst_1
    //   217: ireturn
  }
  
  private void o0(int paramInt) {
    this.U = 1 << paramInt | this.U;
    if (!this.T) {
      o0.j0(this.f.getDecorView(), this.V);
      this.T = true;
    } 
  }
  
  private boolean p0(Context paramContext) {
    if (!this.Q && this.d instanceof Activity) {
      PackageManager packageManager = paramContext.getPackageManager();
      if (packageManager == null)
        return false; 
      try {
        boolean bool;
        int i = Build.VERSION.SDK_INT;
        if (i >= 29) {
          i = 269221888;
        } else if (i >= 24) {
          i = 786432;
        } else {
          i = 0;
        } 
        ActivityInfo activityInfo = packageManager.getActivityInfo(new ComponentName(paramContext, this.d.getClass()), i);
        if (activityInfo != null && (activityInfo.configChanges & 0x200) != 0) {
          bool = true;
        } else {
          bool = false;
        } 
        this.P = bool;
      } catch (android.content.pm.PackageManager.NameNotFoundException nameNotFoundException) {
        Log.d("AppCompatDelegate", "Exception while getting ActivityInfo", (Throwable)nameNotFoundException);
        this.P = false;
      } 
    } 
    this.Q = true;
    return this.P;
  }
  
  private boolean u0(int paramInt, KeyEvent paramKeyEvent) {
    if (paramKeyEvent.getRepeatCount() == 0) {
      t t1 = h0(paramInt, true);
      if (!t1.o)
        return E0(t1, paramKeyEvent); 
    } 
    return false;
  }
  
  private boolean x0(int paramInt, KeyEvent paramKeyEvent) {
    // Byte code:
    //   0: aload_0
    //   1: getfield o : Landroidx/appcompat/view/b;
    //   4: ifnull -> 9
    //   7: iconst_0
    //   8: ireturn
    //   9: iconst_1
    //   10: istore #4
    //   12: aload_0
    //   13: iload_1
    //   14: iconst_1
    //   15: invokevirtual h0 : (IZ)Landroidx/appcompat/app/f$t;
    //   18: astore #5
    //   20: iload_1
    //   21: ifne -> 113
    //   24: aload_0
    //   25: getfield l : Landroidx/appcompat/widget/b1;
    //   28: astore #6
    //   30: aload #6
    //   32: ifnull -> 113
    //   35: aload #6
    //   37: invokeinterface d : ()Z
    //   42: ifeq -> 113
    //   45: aload_0
    //   46: getfield e : Landroid/content/Context;
    //   49: invokestatic get : (Landroid/content/Context;)Landroid/view/ViewConfiguration;
    //   52: invokevirtual hasPermanentMenuKey : ()Z
    //   55: ifne -> 113
    //   58: aload_0
    //   59: getfield l : Landroidx/appcompat/widget/b1;
    //   62: invokeinterface b : ()Z
    //   67: ifne -> 100
    //   70: aload_0
    //   71: getfield L : Z
    //   74: ifne -> 186
    //   77: aload_0
    //   78: aload #5
    //   80: aload_2
    //   81: invokespecial E0 : (Landroidx/appcompat/app/f$t;Landroid/view/KeyEvent;)Z
    //   84: ifeq -> 186
    //   87: aload_0
    //   88: getfield l : Landroidx/appcompat/widget/b1;
    //   91: invokeinterface h : ()Z
    //   96: istore_3
    //   97: goto -> 198
    //   100: aload_0
    //   101: getfield l : Landroidx/appcompat/widget/b1;
    //   104: invokeinterface g : ()Z
    //   109: istore_3
    //   110: goto -> 198
    //   113: aload #5
    //   115: getfield o : Z
    //   118: istore_3
    //   119: iload_3
    //   120: ifne -> 191
    //   123: aload #5
    //   125: getfield n : Z
    //   128: ifeq -> 134
    //   131: goto -> 191
    //   134: aload #5
    //   136: getfield m : Z
    //   139: ifeq -> 186
    //   142: aload #5
    //   144: getfield r : Z
    //   147: ifeq -> 167
    //   150: aload #5
    //   152: iconst_0
    //   153: putfield m : Z
    //   156: aload_0
    //   157: aload #5
    //   159: aload_2
    //   160: invokespecial E0 : (Landroidx/appcompat/app/f$t;Landroid/view/KeyEvent;)Z
    //   163: istore_3
    //   164: goto -> 169
    //   167: iconst_1
    //   168: istore_3
    //   169: iload_3
    //   170: ifeq -> 186
    //   173: aload_0
    //   174: aload #5
    //   176: aload_2
    //   177: invokespecial B0 : (Landroidx/appcompat/app/f$t;Landroid/view/KeyEvent;)V
    //   180: iload #4
    //   182: istore_3
    //   183: goto -> 198
    //   186: iconst_0
    //   187: istore_3
    //   188: goto -> 198
    //   191: aload_0
    //   192: aload #5
    //   194: iconst_1
    //   195: invokevirtual S : (Landroidx/appcompat/app/f$t;Z)V
    //   198: iload_3
    //   199: ifeq -> 240
    //   202: aload_0
    //   203: getfield e : Landroid/content/Context;
    //   206: invokevirtual getApplicationContext : ()Landroid/content/Context;
    //   209: ldc_w 'audio'
    //   212: invokevirtual getSystemService : (Ljava/lang/String;)Ljava/lang/Object;
    //   215: checkcast android/media/AudioManager
    //   218: astore_2
    //   219: aload_2
    //   220: ifnull -> 230
    //   223: aload_2
    //   224: iconst_0
    //   225: invokevirtual playSoundEffect : (I)V
    //   228: iload_3
    //   229: ireturn
    //   230: ldc_w 'AppCompatDelegate'
    //   233: ldc_w 'Couldn't get audio manager'
    //   236: invokestatic w : (Ljava/lang/String;Ljava/lang/String;)I
    //   239: pop
    //   240: iload_3
    //   241: ireturn
  }
  
  public boolean A(int paramInt) {
    paramInt = G0(paramInt);
    if (this.E && paramInt == 108)
      return false; 
    if (this.A && paramInt == 1)
      this.A = false; 
    if (paramInt != 1) {
      if (paramInt != 2) {
        if (paramInt != 5) {
          if (paramInt != 10) {
            if (paramInt != 108) {
              if (paramInt != 109)
                return this.f.requestFeature(paramInt); 
              K0();
              this.B = true;
              return true;
            } 
            K0();
            this.A = true;
            return true;
          } 
          K0();
          this.C = true;
          return true;
        } 
        K0();
        this.z = true;
        return true;
      } 
      K0();
      this.y = true;
      return true;
    } 
    K0();
    this.E = true;
    return true;
  }
  
  void A0(ViewGroup paramViewGroup) {}
  
  public void C(int paramInt) {
    a0();
    ViewGroup viewGroup = (ViewGroup)this.v.findViewById(16908290);
    viewGroup.removeAllViews();
    LayoutInflater.from(this.e).inflate(paramInt, viewGroup);
    this.g.c(this.f.getCallback());
  }
  
  final a C0() {
    return this.i;
  }
  
  public void D(View paramView) {
    a0();
    ViewGroup viewGroup = (ViewGroup)this.v.findViewById(16908290);
    viewGroup.removeAllViews();
    viewGroup.addView(paramView);
    this.g.c(this.f.getCallback());
  }
  
  public void E(View paramView, ViewGroup.LayoutParams paramLayoutParams) {
    a0();
    ViewGroup viewGroup = (ViewGroup)this.v.findViewById(16908290);
    viewGroup.removeAllViews();
    viewGroup.addView(paramView, paramLayoutParams);
    this.g.c(this.f.getCallback());
  }
  
  public void F(Toolbar paramToolbar) {
    if (!(this.d instanceof Activity))
      return; 
    a a1 = n();
    if (!(a1 instanceof r)) {
      this.j = null;
      if (a1 != null)
        a1.n(); 
      this.i = null;
      if (paramToolbar != null) {
        o o = new o(paramToolbar, i0(), (Window.Callback)this.g);
        this.i = o;
        this.g.e(o.c);
      } else {
        this.g.e(null);
      } 
      p();
      return;
    } 
    throw new IllegalStateException("This Activity already has an action bar supplied by the window decor. Do not request Window.FEATURE_SUPPORT_ACTION_BAR and set windowActionBar to false in your theme to use a Toolbar instead.");
  }
  
  public void G(int paramInt) {
    this.O = paramInt;
  }
  
  public final void H(CharSequence paramCharSequence) {
    this.k = paramCharSequence;
    b1 b11 = this.l;
    if (b11 != null) {
      b11.setWindowTitle(paramCharSequence);
      return;
    } 
    if (C0() != null) {
      C0().z(paramCharSequence);
      return;
    } 
    TextView textView = this.w;
    if (textView != null)
      textView.setText(paramCharSequence); 
  }
  
  final boolean H0() {
    if (this.u) {
      ViewGroup viewGroup = this.v;
      if (viewGroup != null && o0.V((View)viewGroup))
        return true; 
    } 
    return false;
  }
  
  public androidx.appcompat.view.b I(androidx.appcompat.view.b.a parama) {
    if (parama != null) {
      androidx.appcompat.view.b b2 = this.o;
      if (b2 != null)
        b2.c(); 
      parama = new i(this, parama);
      a a1 = n();
      if (a1 != null) {
        androidx.appcompat.view.b b3 = a1.A(parama);
        this.o = b3;
        if (b3 != null) {
          d d1 = this.h;
          if (d1 != null)
            d1.onSupportActionModeStarted(b3); 
        } 
      } 
      if (this.o == null)
        this.o = J0(parama); 
      return this.o;
    } 
    throw new IllegalArgumentException("ActionMode callback can not be null.");
  }
  
  public boolean J() {
    return K(true);
  }
  
  androidx.appcompat.view.b J0(androidx.appcompat.view.b.a parama) {
    // Byte code:
    //   0: aload_0
    //   1: invokevirtual Z : ()V
    //   4: aload_0
    //   5: getfield o : Landroidx/appcompat/view/b;
    //   8: astore #4
    //   10: aload #4
    //   12: ifnull -> 20
    //   15: aload #4
    //   17: invokevirtual c : ()V
    //   20: aload_1
    //   21: astore #4
    //   23: aload_1
    //   24: instanceof androidx/appcompat/app/f$i
    //   27: ifne -> 41
    //   30: new androidx/appcompat/app/f$i
    //   33: dup
    //   34: aload_0
    //   35: aload_1
    //   36: invokespecial <init> : (Landroidx/appcompat/app/f;Landroidx/appcompat/view/b$a;)V
    //   39: astore #4
    //   41: aload_0
    //   42: getfield h : Landroidx/appcompat/app/d;
    //   45: astore_1
    //   46: aload_1
    //   47: ifnull -> 69
    //   50: aload_0
    //   51: getfield L : Z
    //   54: ifne -> 69
    //   57: aload_1
    //   58: aload #4
    //   60: invokeinterface onWindowStartingSupportActionMode : (Landroidx/appcompat/view/b$a;)Landroidx/appcompat/view/b;
    //   65: astore_1
    //   66: goto -> 71
    //   69: aconst_null
    //   70: astore_1
    //   71: aload_1
    //   72: ifnull -> 83
    //   75: aload_0
    //   76: aload_1
    //   77: putfield o : Landroidx/appcompat/view/b;
    //   80: goto -> 565
    //   83: aload_0
    //   84: getfield p : Landroidx/appcompat/widget/ActionBarContextView;
    //   87: astore_1
    //   88: iconst_1
    //   89: istore_3
    //   90: aload_1
    //   91: ifnonnull -> 355
    //   94: aload_0
    //   95: getfield D : Z
    //   98: ifeq -> 315
    //   101: new android/util/TypedValue
    //   104: dup
    //   105: invokespecial <init> : ()V
    //   108: astore #5
    //   110: aload_0
    //   111: getfield e : Landroid/content/Context;
    //   114: invokevirtual getTheme : ()Landroid/content/res/Resources$Theme;
    //   117: astore_1
    //   118: aload_1
    //   119: getstatic e/a.f : I
    //   122: aload #5
    //   124: iconst_1
    //   125: invokevirtual resolveAttribute : (ILandroid/util/TypedValue;Z)Z
    //   128: pop
    //   129: aload #5
    //   131: getfield resourceId : I
    //   134: ifeq -> 191
    //   137: aload_0
    //   138: getfield e : Landroid/content/Context;
    //   141: invokevirtual getResources : ()Landroid/content/res/Resources;
    //   144: invokevirtual newTheme : ()Landroid/content/res/Resources$Theme;
    //   147: astore #6
    //   149: aload #6
    //   151: aload_1
    //   152: invokevirtual setTo : (Landroid/content/res/Resources$Theme;)V
    //   155: aload #6
    //   157: aload #5
    //   159: getfield resourceId : I
    //   162: iconst_1
    //   163: invokevirtual applyStyle : (IZ)V
    //   166: new androidx/appcompat/view/d
    //   169: dup
    //   170: aload_0
    //   171: getfield e : Landroid/content/Context;
    //   174: iconst_0
    //   175: invokespecial <init> : (Landroid/content/Context;I)V
    //   178: astore_1
    //   179: aload_1
    //   180: invokevirtual getTheme : ()Landroid/content/res/Resources$Theme;
    //   183: aload #6
    //   185: invokevirtual setTo : (Landroid/content/res/Resources$Theme;)V
    //   188: goto -> 196
    //   191: aload_0
    //   192: getfield e : Landroid/content/Context;
    //   195: astore_1
    //   196: aload_0
    //   197: new androidx/appcompat/widget/ActionBarContextView
    //   200: dup
    //   201: aload_1
    //   202: invokespecial <init> : (Landroid/content/Context;)V
    //   205: putfield p : Landroidx/appcompat/widget/ActionBarContextView;
    //   208: new android/widget/PopupWindow
    //   211: dup
    //   212: aload_1
    //   213: aconst_null
    //   214: getstatic e/a.i : I
    //   217: invokespecial <init> : (Landroid/content/Context;Landroid/util/AttributeSet;I)V
    //   220: astore #6
    //   222: aload_0
    //   223: aload #6
    //   225: putfield q : Landroid/widget/PopupWindow;
    //   228: aload #6
    //   230: iconst_2
    //   231: invokestatic b : (Landroid/widget/PopupWindow;I)V
    //   234: aload_0
    //   235: getfield q : Landroid/widget/PopupWindow;
    //   238: aload_0
    //   239: getfield p : Landroidx/appcompat/widget/ActionBarContextView;
    //   242: invokevirtual setContentView : (Landroid/view/View;)V
    //   245: aload_0
    //   246: getfield q : Landroid/widget/PopupWindow;
    //   249: iconst_m1
    //   250: invokevirtual setWidth : (I)V
    //   253: aload_1
    //   254: invokevirtual getTheme : ()Landroid/content/res/Resources$Theme;
    //   257: getstatic e/a.b : I
    //   260: aload #5
    //   262: iconst_1
    //   263: invokevirtual resolveAttribute : (ILandroid/util/TypedValue;Z)Z
    //   266: pop
    //   267: aload #5
    //   269: getfield data : I
    //   272: aload_1
    //   273: invokevirtual getResources : ()Landroid/content/res/Resources;
    //   276: invokevirtual getDisplayMetrics : ()Landroid/util/DisplayMetrics;
    //   279: invokestatic complexToDimensionPixelSize : (ILandroid/util/DisplayMetrics;)I
    //   282: istore_2
    //   283: aload_0
    //   284: getfield p : Landroidx/appcompat/widget/ActionBarContextView;
    //   287: iload_2
    //   288: invokevirtual setContentHeight : (I)V
    //   291: aload_0
    //   292: getfield q : Landroid/widget/PopupWindow;
    //   295: bipush #-2
    //   297: invokevirtual setHeight : (I)V
    //   300: aload_0
    //   301: new androidx/appcompat/app/f$d
    //   304: dup
    //   305: aload_0
    //   306: invokespecial <init> : (Landroidx/appcompat/app/f;)V
    //   309: putfield r : Ljava/lang/Runnable;
    //   312: goto -> 355
    //   315: aload_0
    //   316: getfield v : Landroid/view/ViewGroup;
    //   319: getstatic e/f.h : I
    //   322: invokevirtual findViewById : (I)Landroid/view/View;
    //   325: checkcast androidx/appcompat/widget/ViewStubCompat
    //   328: astore_1
    //   329: aload_1
    //   330: ifnull -> 355
    //   333: aload_1
    //   334: aload_0
    //   335: invokevirtual e0 : ()Landroid/content/Context;
    //   338: invokestatic from : (Landroid/content/Context;)Landroid/view/LayoutInflater;
    //   341: invokevirtual setLayoutInflater : (Landroid/view/LayoutInflater;)V
    //   344: aload_0
    //   345: aload_1
    //   346: invokevirtual a : ()Landroid/view/View;
    //   349: checkcast androidx/appcompat/widget/ActionBarContextView
    //   352: putfield p : Landroidx/appcompat/widget/ActionBarContextView;
    //   355: aload_0
    //   356: getfield p : Landroidx/appcompat/widget/ActionBarContextView;
    //   359: ifnull -> 565
    //   362: aload_0
    //   363: invokevirtual Z : ()V
    //   366: aload_0
    //   367: getfield p : Landroidx/appcompat/widget/ActionBarContextView;
    //   370: invokevirtual k : ()V
    //   373: aload_0
    //   374: getfield p : Landroidx/appcompat/widget/ActionBarContextView;
    //   377: invokevirtual getContext : ()Landroid/content/Context;
    //   380: astore_1
    //   381: aload_0
    //   382: getfield p : Landroidx/appcompat/widget/ActionBarContextView;
    //   385: astore #5
    //   387: aload_0
    //   388: getfield q : Landroid/widget/PopupWindow;
    //   391: ifnonnull -> 397
    //   394: goto -> 399
    //   397: iconst_0
    //   398: istore_3
    //   399: new androidx/appcompat/view/e
    //   402: dup
    //   403: aload_1
    //   404: aload #5
    //   406: aload #4
    //   408: iload_3
    //   409: invokespecial <init> : (Landroid/content/Context;Landroidx/appcompat/widget/ActionBarContextView;Landroidx/appcompat/view/b$a;Z)V
    //   412: astore_1
    //   413: aload #4
    //   415: aload_1
    //   416: aload_1
    //   417: invokevirtual e : ()Landroid/view/Menu;
    //   420: invokeinterface b : (Landroidx/appcompat/view/b;Landroid/view/Menu;)Z
    //   425: ifeq -> 560
    //   428: aload_1
    //   429: invokevirtual k : ()V
    //   432: aload_0
    //   433: getfield p : Landroidx/appcompat/widget/ActionBarContextView;
    //   436: aload_1
    //   437: invokevirtual h : (Landroidx/appcompat/view/b;)V
    //   440: aload_0
    //   441: aload_1
    //   442: putfield o : Landroidx/appcompat/view/b;
    //   445: aload_0
    //   446: invokevirtual H0 : ()Z
    //   449: ifeq -> 493
    //   452: aload_0
    //   453: getfield p : Landroidx/appcompat/widget/ActionBarContextView;
    //   456: fconst_0
    //   457: invokevirtual setAlpha : (F)V
    //   460: aload_0
    //   461: getfield p : Landroidx/appcompat/widget/ActionBarContextView;
    //   464: invokestatic e : (Landroid/view/View;)Landroidx/core/view/o2;
    //   467: fconst_1
    //   468: invokevirtual b : (F)Landroidx/core/view/o2;
    //   471: astore_1
    //   472: aload_0
    //   473: aload_1
    //   474: putfield s : Landroidx/core/view/o2;
    //   477: aload_1
    //   478: new androidx/appcompat/app/f$e
    //   481: dup
    //   482: aload_0
    //   483: invokespecial <init> : (Landroidx/appcompat/app/f;)V
    //   486: invokevirtual h : (Landroidx/core/view/p2;)Landroidx/core/view/o2;
    //   489: pop
    //   490: goto -> 535
    //   493: aload_0
    //   494: getfield p : Landroidx/appcompat/widget/ActionBarContextView;
    //   497: fconst_1
    //   498: invokevirtual setAlpha : (F)V
    //   501: aload_0
    //   502: getfield p : Landroidx/appcompat/widget/ActionBarContextView;
    //   505: iconst_0
    //   506: invokevirtual setVisibility : (I)V
    //   509: aload_0
    //   510: getfield p : Landroidx/appcompat/widget/ActionBarContextView;
    //   513: invokevirtual getParent : ()Landroid/view/ViewParent;
    //   516: instanceof android/view/View
    //   519: ifeq -> 535
    //   522: aload_0
    //   523: getfield p : Landroidx/appcompat/widget/ActionBarContextView;
    //   526: invokevirtual getParent : ()Landroid/view/ViewParent;
    //   529: checkcast android/view/View
    //   532: invokestatic o0 : (Landroid/view/View;)V
    //   535: aload_0
    //   536: getfield q : Landroid/widget/PopupWindow;
    //   539: ifnull -> 565
    //   542: aload_0
    //   543: getfield f : Landroid/view/Window;
    //   546: invokevirtual getDecorView : ()Landroid/view/View;
    //   549: aload_0
    //   550: getfield r : Ljava/lang/Runnable;
    //   553: invokevirtual post : (Ljava/lang/Runnable;)Z
    //   556: pop
    //   557: goto -> 565
    //   560: aload_0
    //   561: aconst_null
    //   562: putfield o : Landroidx/appcompat/view/b;
    //   565: aload_0
    //   566: getfield o : Landroidx/appcompat/view/b;
    //   569: astore_1
    //   570: aload_1
    //   571: ifnull -> 593
    //   574: aload_0
    //   575: getfield h : Landroidx/appcompat/app/d;
    //   578: astore #4
    //   580: aload #4
    //   582: ifnull -> 593
    //   585: aload #4
    //   587: aload_1
    //   588: invokeinterface onSupportActionModeStarted : (Landroidx/appcompat/view/b;)V
    //   593: aload_0
    //   594: getfield o : Landroidx/appcompat/view/b;
    //   597: areturn
    //   598: astore_1
    //   599: goto -> 69
    // Exception table:
    //   from	to	target	type
    //   57	66	598	java/lang/AbstractMethodError
  }
  
  void O(int paramInt, t paramt, Menu paramMenu) {
    g g1;
    t t1 = paramt;
    Menu menu = paramMenu;
    if (paramMenu == null) {
      t t2 = paramt;
      if (paramt == null) {
        t2 = paramt;
        if (paramInt >= 0) {
          t[] arrayOfT = this.G;
          t2 = paramt;
          if (paramInt < arrayOfT.length)
            t2 = arrayOfT[paramInt]; 
        } 
      } 
      t1 = t2;
      menu = paramMenu;
      if (t2 != null) {
        g1 = t2.j;
        t1 = t2;
      } 
    } 
    if (t1 != null && !t1.o)
      return; 
    if (!this.L)
      this.g.d(this.f.getCallback(), paramInt, (Menu)g1); 
  }
  
  final int O0(u2 paramu2, Rect paramRect) {
    int i;
    int j;
    boolean bool1;
    boolean bool2 = false;
    if (paramu2 != null) {
      i = paramu2.k();
    } else if (paramRect != null) {
      i = paramRect.top;
    } else {
      i = 0;
    } 
    ActionBarContextView actionBarContextView = this.p;
    if (actionBarContextView != null && actionBarContextView.getLayoutParams() instanceof ViewGroup.MarginLayoutParams) {
      boolean bool;
      ViewGroup.MarginLayoutParams marginLayoutParams = (ViewGroup.MarginLayoutParams)this.p.getLayoutParams();
      boolean bool3 = this.p.isShown();
      int k = 1;
      bool1 = true;
      if (bool3) {
        int i1;
        if (this.X == null) {
          this.X = new Rect();
          this.Y = new Rect();
        } 
        Rect rect1 = this.X;
        Rect rect2 = this.Y;
        if (paramu2 == null) {
          rect1.set(paramRect);
        } else {
          rect1.set(paramu2.i(), paramu2.k(), paramu2.j(), paramu2.h());
        } 
        m2.a((View)this.v, rect1, rect2);
        int i2 = rect1.top;
        bool = rect1.left;
        int i3 = rect1.right;
        paramu2 = o0.K((View)this.v);
        if (paramu2 == null) {
          k = 0;
        } else {
          k = paramu2.i();
        } 
        if (paramu2 == null) {
          i1 = 0;
        } else {
          i1 = paramu2.j();
        } 
        if (marginLayoutParams.topMargin != i2 || marginLayoutParams.leftMargin != bool || marginLayoutParams.rightMargin != i3) {
          marginLayoutParams.topMargin = i2;
          marginLayoutParams.leftMargin = bool;
          marginLayoutParams.rightMargin = i3;
          bool = true;
        } else {
          bool = false;
        } 
        if (i2 > 0 && this.x == null) {
          View view2 = new View(this.e);
          this.x = view2;
          view2.setVisibility(8);
          FrameLayout.LayoutParams layoutParams = new FrameLayout.LayoutParams(-1, marginLayoutParams.topMargin, 51);
          layoutParams.leftMargin = k;
          layoutParams.rightMargin = i1;
          this.v.addView(this.x, -1, (ViewGroup.LayoutParams)layoutParams);
        } else {
          View view2 = this.x;
          if (view2 != null) {
            ViewGroup.MarginLayoutParams marginLayoutParams1 = (ViewGroup.MarginLayoutParams)view2.getLayoutParams();
            i2 = marginLayoutParams1.height;
            i3 = marginLayoutParams.topMargin;
            if (i2 != i3 || marginLayoutParams1.leftMargin != k || marginLayoutParams1.rightMargin != i1) {
              marginLayoutParams1.height = i3;
              marginLayoutParams1.leftMargin = k;
              marginLayoutParams1.rightMargin = i1;
              this.x.setLayoutParams((ViewGroup.LayoutParams)marginLayoutParams1);
            } 
          } 
        } 
        View view1 = this.x;
        if (view1 != null) {
          i1 = bool1;
        } else {
          i1 = 0;
        } 
        if (i1 != 0 && view1.getVisibility() != 0)
          P0(this.x); 
        k = i;
        if (!this.C) {
          k = i;
          if (i1 != 0)
            k = 0; 
        } 
        i = k;
        k = bool;
        bool = i1;
      } else if (marginLayoutParams.topMargin != 0) {
        marginLayoutParams.topMargin = 0;
        bool = false;
      } else {
        bool = false;
        k = 0;
      } 
      j = i;
      bool1 = bool;
      if (k != 0) {
        this.p.setLayoutParams((ViewGroup.LayoutParams)marginLayoutParams);
        j = i;
        bool1 = bool;
      } 
    } else {
      bool1 = false;
      j = i;
    } 
    View view = this.x;
    if (view != null) {
      if (bool1) {
        i = bool2;
      } else {
        i = 8;
      } 
      view.setVisibility(i);
    } 
    return j;
  }
  
  void P(g paramg) {
    if (this.F)
      return; 
    this.F = true;
    this.l.j();
    Window.Callback callback = j0();
    if (callback != null && !this.L)
      callback.onPanelClosed(108, (Menu)paramg); 
    this.F = false;
  }
  
  void R(int paramInt) {
    S(h0(paramInt, true), true);
  }
  
  void S(t paramt, boolean paramBoolean) {
    if (paramBoolean && paramt.a == 0) {
      b1 b11 = this.l;
      if (b11 != null && b11.b()) {
        P(paramt.j);
        return;
      } 
    } 
    WindowManager windowManager = (WindowManager)this.e.getSystemService("window");
    if (windowManager != null && paramt.o) {
      ViewGroup viewGroup = paramt.g;
      if (viewGroup != null) {
        windowManager.removeView((View)viewGroup);
        if (paramBoolean)
          O(paramt.a, paramt, null); 
      } 
    } 
    paramt.m = false;
    paramt.n = false;
    paramt.o = false;
    paramt.h = null;
    paramt.q = true;
    if (this.H == paramt)
      this.H = null; 
  }
  
  public View V(View paramView, String paramString, Context paramContext, AttributeSet paramAttributeSet) {
    l l1 = this.Z;
    boolean bool1 = false;
    if (l1 == null) {
      String str = this.e.obtainStyledAttributes(e.j.y0).getString(e.j.C0);
      if (str == null) {
        this.Z = new l();
      } else {
        try {
          this.Z = this.e.getClassLoader().loadClass(str).getDeclaredConstructor(new Class[0]).newInstance(new Object[0]);
        } finally {
          Exception exception = null;
          StringBuilder stringBuilder = new StringBuilder();
          stringBuilder.append("Failed to instantiate custom view inflater ");
          stringBuilder.append(str);
          stringBuilder.append(". Falling back to default.");
          Log.i("AppCompatDelegate", stringBuilder.toString(), exception);
        } 
      } 
    } 
    boolean bool2 = g0;
    if (bool2) {
      if (this.e0 == null)
        this.e0 = new m(); 
      if (this.e0.a(paramAttributeSet)) {
        bool1 = true;
      } else if (paramAttributeSet instanceof XmlPullParser) {
        if (((XmlPullParser)paramAttributeSet).getDepth() > 1)
          bool1 = true; 
      } else {
        bool1 = I0((ViewParent)paramView);
      } 
    } else {
      bool1 = false;
    } 
    return this.Z.r(paramView, paramString, paramContext, paramAttributeSet, bool1, bool2, true, l2.d());
  }
  
  void W() {
    b1 b11 = this.l;
    if (b11 != null)
      b11.j(); 
    if (this.q != null) {
      this.f.getDecorView().removeCallbacks(this.r);
      if (this.q.isShowing())
        try {
          this.q.dismiss();
        } catch (IllegalArgumentException illegalArgumentException) {} 
      this.q = null;
    } 
    Z();
    t t1 = h0(0, false);
    if (t1 != null) {
      g g1 = t1.j;
      if (g1 != null)
        g1.close(); 
    } 
  }
  
  boolean X(KeyEvent paramKeyEvent) {
    Object object = this.d;
    boolean bool1 = object instanceof androidx.core.view.g.a;
    boolean bool = true;
    if (bool1 || object instanceof j) {
      object = this.f.getDecorView();
      if (object != null && androidx.core.view.g.d((View)object, paramKeyEvent))
        return true; 
    } 
    if (paramKeyEvent.getKeyCode() == 82 && this.g.b(this.f.getCallback(), paramKeyEvent))
      return true; 
    int i = paramKeyEvent.getKeyCode();
    if (paramKeyEvent.getAction() != 0)
      bool = false; 
    return bool ? t0(i, paramKeyEvent) : w0(i, paramKeyEvent);
  }
  
  void Y(int paramInt) {
    t t1 = h0(paramInt, true);
    if (t1.j != null) {
      Bundle bundle = new Bundle();
      t1.j.T(bundle);
      if (bundle.size() > 0)
        t1.s = bundle; 
      t1.j.h0();
      t1.j.clear();
    } 
    t1.r = true;
    t1.q = true;
    if ((paramInt == 108 || paramInt == 0) && this.l != null) {
      t1 = h0(0, false);
      if (t1 != null) {
        t1.m = false;
        E0(t1, null);
      } 
    } 
  }
  
  void Z() {
    o2 o21 = this.s;
    if (o21 != null)
      o21.c(); 
  }
  
  public boolean a(g paramg, MenuItem paramMenuItem) {
    Window.Callback callback = j0();
    if (callback != null && !this.L) {
      t t1 = c0((Menu)paramg.F());
      if (t1 != null)
        return callback.onMenuItemSelected(t1.a, paramMenuItem); 
    } 
    return false;
  }
  
  public void b(g paramg) {
    F0(true);
  }
  
  t c0(Menu paramMenu) {
    byte b2;
    t[] arrayOfT = this.G;
    int i = 0;
    if (arrayOfT != null) {
      b2 = arrayOfT.length;
    } else {
      b2 = 0;
    } 
    while (i < b2) {
      t t1 = arrayOfT[i];
      if (t1 != null && t1.j == paramMenu)
        return t1; 
      i++;
    } 
    return null;
  }
  
  public void d(View paramView, ViewGroup.LayoutParams paramLayoutParams) {
    a0();
    ((ViewGroup)this.v.findViewById(16908290)).addView(paramView, paramLayoutParams);
    this.g.c(this.f.getCallback());
  }
  
  final Context e0() {
    Context context;
    a a1 = n();
    if (a1 != null) {
      Context context1 = a1.k();
    } else {
      a1 = null;
    } 
    a a2 = a1;
    if (a1 == null)
      context = this.e; 
    return context;
  }
  
  public Context f(Context paramContext) {
    boolean bool1 = true;
    this.J = true;
    int i = r0(paramContext, N());
    boolean bool = j0;
    Configuration configuration1 = null;
    boolean bool2 = false;
    if (bool && paramContext instanceof ContextThemeWrapper) {
      Configuration configuration = T(paramContext, i, null, false);
      try {
        r.a((ContextThemeWrapper)paramContext, configuration);
        return paramContext;
      } catch (IllegalStateException illegalStateException) {}
    } 
    if (paramContext instanceof androidx.appcompat.view.d) {
      Configuration configuration = T(paramContext, i, null, false);
      try {
        ((androidx.appcompat.view.d)paramContext).a(configuration);
        return paramContext;
      } catch (IllegalStateException illegalStateException) {}
    } 
    if (!i0)
      return super.f(paramContext); 
    Configuration configuration2 = new Configuration();
    configuration2.uiMode = -1;
    configuration2.fontScale = 0.0F;
    configuration2 = j.a(paramContext, configuration2).getResources().getConfiguration();
    Configuration configuration3 = paramContext.getResources().getConfiguration();
    configuration2.uiMode = configuration3.uiMode;
    if (!configuration2.equals(configuration3))
      configuration1 = d0(configuration2, configuration3); 
    configuration2 = T(paramContext, i, configuration1, true);
    androidx.appcompat.view.d d1 = new androidx.appcompat.view.d(paramContext, e.i.e);
    d1.a(configuration2);
    try {
      Resources.Theme theme = paramContext.getTheme();
      if (theme == null)
        bool1 = false; 
    } catch (NullPointerException nullPointerException) {
      bool1 = bool2;
    } 
    if (bool1)
      androidx.core.content.res.h.f.a(d1.getTheme()); 
    return super.f((Context)d1);
  }
  
  protected t h0(int paramInt, boolean paramBoolean) {
    // Byte code:
    //   0: aload_0
    //   1: getfield G : [Landroidx/appcompat/app/f$t;
    //   4: astore #4
    //   6: aload #4
    //   8: ifnull -> 21
    //   11: aload #4
    //   13: astore_3
    //   14: aload #4
    //   16: arraylength
    //   17: iload_1
    //   18: if_icmpgt -> 49
    //   21: iload_1
    //   22: iconst_1
    //   23: iadd
    //   24: anewarray androidx/appcompat/app/f$t
    //   27: astore_3
    //   28: aload #4
    //   30: ifnull -> 44
    //   33: aload #4
    //   35: iconst_0
    //   36: aload_3
    //   37: iconst_0
    //   38: aload #4
    //   40: arraylength
    //   41: invokestatic arraycopy : (Ljava/lang/Object;ILjava/lang/Object;II)V
    //   44: aload_0
    //   45: aload_3
    //   46: putfield G : [Landroidx/appcompat/app/f$t;
    //   49: aload_3
    //   50: iload_1
    //   51: aaload
    //   52: astore #5
    //   54: aload #5
    //   56: astore #4
    //   58: aload #5
    //   60: ifnonnull -> 78
    //   63: new androidx/appcompat/app/f$t
    //   66: dup
    //   67: iload_1
    //   68: invokespecial <init> : (I)V
    //   71: astore #4
    //   73: aload_3
    //   74: iload_1
    //   75: aload #4
    //   77: aastore
    //   78: aload #4
    //   80: areturn
  }
  
  public <T extends View> T i(int paramInt) {
    a0();
    return (T)this.f.findViewById(paramInt);
  }
  
  final CharSequence i0() {
    Object object = this.d;
    return (object instanceof Activity) ? ((Activity)object).getTitle() : this.k;
  }
  
  final Window.Callback j0() {
    return this.f.getCallback();
  }
  
  public final b k() {
    return new f(this);
  }
  
  public int l() {
    return this.N;
  }
  
  public MenuInflater m() {
    if (this.j == null) {
      Context context;
      k0();
      a a1 = this.i;
      if (a1 != null) {
        context = a1.k();
      } else {
        context = this.e;
      } 
      this.j = (MenuInflater)new androidx.appcompat.view.g(context);
    } 
    return this.j;
  }
  
  public a n() {
    k0();
    return this.i;
  }
  
  public void o() {
    LayoutInflater layoutInflater = LayoutInflater.from(this.e);
    if (layoutInflater.getFactory() == null) {
      androidx.core.view.h.a(layoutInflater, this);
      return;
    } 
    if (!(layoutInflater.getFactory2() instanceof f))
      Log.i("AppCompatDelegate", "The Activity's LayoutInflater already has a Factory installed so we can not install AppCompat's"); 
  }
  
  public final View onCreateView(View paramView, String paramString, Context paramContext, AttributeSet paramAttributeSet) {
    return V(paramView, paramString, paramContext, paramAttributeSet);
  }
  
  public View onCreateView(String paramString, Context paramContext, AttributeSet paramAttributeSet) {
    return onCreateView(null, paramString, paramContext, paramAttributeSet);
  }
  
  public void p() {
    if (C0() != null) {
      if (n().l())
        return; 
      o0(0);
    } 
  }
  
  public void q(Configuration paramConfiguration) {
    if (this.A && this.u) {
      a a1 = n();
      if (a1 != null)
        a1.m(paramConfiguration); 
    } 
    androidx.appcompat.widget.h.b().g(this.e);
    this.M = new Configuration(this.e.getResources().getConfiguration());
    K(false);
    paramConfiguration.updateFrom(this.e.getResources().getConfiguration());
  }
  
  public boolean q0() {
    return this.t;
  }
  
  public void r(Bundle paramBundle) {
    this.J = true;
    K(false);
    b0();
    Object object = this.d;
    if (object instanceof Activity) {
      Object object1;
      paramBundle = null;
      try {
        object = androidx.core.app.t.c((Activity)object);
        object1 = object;
      } catch (IllegalArgumentException illegalArgumentException) {}
      if (object1 != null) {
        object1 = C0();
        if (object1 == null) {
          this.W = true;
        } else {
          object1.r(true);
        } 
      } 
      e.c(this);
    } 
    this.M = new Configuration(this.e.getResources().getConfiguration());
    this.K = true;
  }
  
  int r0(Context paramContext, int paramInt) {
    if (paramInt != -100) {
      if (paramInt != -1)
        if (paramInt != 0) {
          if (paramInt != 1 && paramInt != 2) {
            if (paramInt == 3)
              return f0(paramContext).c(); 
            throw new IllegalStateException("Unknown value set for night mode. Please use one of the MODE_NIGHT values from AppCompatDelegate.");
          } 
        } else {
          return (Build.VERSION.SDK_INT >= 23 && ((UiModeManager)paramContext.getApplicationContext().getSystemService("uimode")).getNightMode() == 0) ? -1 : g0(paramContext).c();
        }  
      return paramInt;
    } 
    return -1;
  }
  
  public void s() {
    // Byte code:
    //   0: aload_0
    //   1: getfield d : Ljava/lang/Object;
    //   4: instanceof android/app/Activity
    //   7: ifeq -> 14
    //   10: aload_0
    //   11: invokestatic y : (Landroidx/appcompat/app/e;)V
    //   14: aload_0
    //   15: getfield T : Z
    //   18: ifeq -> 36
    //   21: aload_0
    //   22: getfield f : Landroid/view/Window;
    //   25: invokevirtual getDecorView : ()Landroid/view/View;
    //   28: aload_0
    //   29: getfield V : Ljava/lang/Runnable;
    //   32: invokevirtual removeCallbacks : (Ljava/lang/Runnable;)Z
    //   35: pop
    //   36: aload_0
    //   37: iconst_1
    //   38: putfield L : Z
    //   41: aload_0
    //   42: getfield N : I
    //   45: bipush #-100
    //   47: if_icmpeq -> 99
    //   50: aload_0
    //   51: getfield d : Ljava/lang/Object;
    //   54: astore_1
    //   55: aload_1
    //   56: instanceof android/app/Activity
    //   59: ifeq -> 99
    //   62: aload_1
    //   63: checkcast android/app/Activity
    //   66: invokevirtual isChangingConfigurations : ()Z
    //   69: ifeq -> 99
    //   72: getstatic androidx/appcompat/app/f.f0 : Landroidx/collection/g;
    //   75: aload_0
    //   76: getfield d : Ljava/lang/Object;
    //   79: invokevirtual getClass : ()Ljava/lang/Class;
    //   82: invokevirtual getName : ()Ljava/lang/String;
    //   85: aload_0
    //   86: getfield N : I
    //   89: invokestatic valueOf : (I)Ljava/lang/Integer;
    //   92: invokevirtual put : (Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    //   95: pop
    //   96: goto -> 116
    //   99: getstatic androidx/appcompat/app/f.f0 : Landroidx/collection/g;
    //   102: aload_0
    //   103: getfield d : Ljava/lang/Object;
    //   106: invokevirtual getClass : ()Ljava/lang/Class;
    //   109: invokevirtual getName : ()Ljava/lang/String;
    //   112: invokevirtual remove : (Ljava/lang/Object;)Ljava/lang/Object;
    //   115: pop
    //   116: aload_0
    //   117: getfield i : Landroidx/appcompat/app/a;
    //   120: astore_1
    //   121: aload_1
    //   122: ifnull -> 129
    //   125: aload_1
    //   126: invokevirtual n : ()V
    //   129: aload_0
    //   130: invokespecial Q : ()V
    //   133: return
  }
  
  boolean s0() {
    androidx.appcompat.view.b b2 = this.o;
    if (b2 != null) {
      b2.c();
      return true;
    } 
    a a1 = n();
    return (a1 != null && a1.h());
  }
  
  public void t(Bundle paramBundle) {
    a0();
  }
  
  boolean t0(int paramInt, KeyEvent paramKeyEvent) {
    boolean bool = true;
    if (paramInt != 4) {
      if (paramInt != 82)
        return false; 
      u0(0, paramKeyEvent);
      return true;
    } 
    if ((paramKeyEvent.getFlags() & 0x80) == 0)
      bool = false; 
    this.I = bool;
    return false;
  }
  
  public void u() {
    a a1 = n();
    if (a1 != null)
      a1.w(true); 
  }
  
  public void v(Bundle paramBundle) {}
  
  boolean v0(int paramInt, KeyEvent paramKeyEvent) {
    t t1;
    a a1 = n();
    if (a1 != null && a1.o(paramInt, paramKeyEvent))
      return true; 
    t t2 = this.H;
    if (t2 != null && D0(t2, paramKeyEvent.getKeyCode(), paramKeyEvent, 1)) {
      t1 = this.H;
      if (t1 != null)
        t1.n = true; 
      return true;
    } 
    if (this.H == null) {
      t2 = h0(0, true);
      E0(t2, (KeyEvent)t1);
      boolean bool = D0(t2, t1.getKeyCode(), (KeyEvent)t1, 1);
      t2.m = false;
      if (bool)
        return true; 
    } 
    return false;
  }
  
  public void w() {
    J();
  }
  
  boolean w0(int paramInt, KeyEvent paramKeyEvent) {
    if (paramInt != 4) {
      if (paramInt != 82)
        return false; 
      x0(0, paramKeyEvent);
      return true;
    } 
    boolean bool = this.I;
    this.I = false;
    t t1 = h0(0, false);
    if (t1 != null && t1.o) {
      if (!bool)
        S(t1, true); 
      return true;
    } 
    return s0();
  }
  
  public void x() {
    a a1 = n();
    if (a1 != null)
      a1.w(false); 
  }
  
  void y0(int paramInt) {
    if (paramInt == 108) {
      a a1 = n();
      if (a1 != null)
        a1.i(true); 
    } 
  }
  
  void z0(int paramInt) {
    if (paramInt == 108) {
      a a1 = n();
      if (a1 != null) {
        a1.i(false);
        return;
      } 
    } else if (paramInt == 0) {
      t t1 = h0(paramInt, true);
      if (t1.o)
        S(t1, false); 
    } 
  }
  
  class a implements Runnable {
    a(f this$0) {}
    
    public void run() {
      f f1 = this.a;
      if ((f1.U & 0x1) != 0)
        f1.Y(0); 
      f1 = this.a;
      if ((f1.U & 0x1000) != 0)
        f1.Y(108); 
      f1 = this.a;
      f1.T = false;
      f1.U = 0;
    }
  }
  
  class b implements i0 {
    b(f this$0) {}
    
    public u2 a(View param1View, u2 param1u2) {
      int i = param1u2.k();
      int j = this.a.O0(param1u2, null);
      u2 u21 = param1u2;
      if (i != j)
        u21 = param1u2.o(param1u2.i(), j, param1u2.j(), param1u2.h()); 
      return o0.d0(param1View, u21);
    }
  }
  
  class c implements ContentFrameLayout.a {
    c(f this$0) {}
    
    public void a() {}
    
    public void onDetachedFromWindow() {
      this.a.W();
    }
  }
  
  class d implements Runnable {
    d(f this$0) {}
    
    public void run() {
      f f1 = this.a;
      f1.q.showAtLocation((View)f1.p, 55, 0, 0);
      this.a.Z();
      if (this.a.H0()) {
        this.a.p.setAlpha(0.0F);
        f1 = this.a;
        f1.s = o0.e((View)f1.p).b(1.0F);
        this.a.s.h((p2)new a(this));
        return;
      } 
      this.a.p.setAlpha(1.0F);
      this.a.p.setVisibility(0);
    }
    
    class a extends q2 {
      a(f.d this$0) {}
      
      public void b(View param2View) {
        this.a.a.p.setAlpha(1.0F);
        this.a.a.s.h(null);
        this.a.a.s = null;
      }
      
      public void c(View param2View) {
        this.a.a.p.setVisibility(0);
      }
    }
  }
  
  class a extends q2 {
    a(f this$0) {}
    
    public void b(View param1View) {
      this.a.a.p.setAlpha(1.0F);
      this.a.a.s.h(null);
      this.a.a.s = null;
    }
    
    public void c(View param1View) {
      this.a.a.p.setVisibility(0);
    }
  }
  
  class e extends q2 {
    e(f this$0) {}
    
    public void b(View param1View) {
      this.a.p.setAlpha(1.0F);
      this.a.s.h(null);
      this.a.s = null;
    }
    
    public void c(View param1View) {
      this.a.p.setVisibility(0);
      if (this.a.p.getParent() instanceof View)
        o0.o0((View)this.a.p.getParent()); 
    }
  }
  
  private class f implements b {
    f(f this$0) {}
    
    public Context a() {
      return this.a.e0();
    }
    
    public void b(Drawable param1Drawable, int param1Int) {
      a a = this.a.n();
      if (a != null) {
        a.v(param1Drawable);
        a.u(param1Int);
      } 
    }
  }
  
  static interface g {
    boolean a(int param1Int);
    
    View onCreatePanelView(int param1Int);
  }
  
  private final class h implements androidx.appcompat.view.menu.m.a {
    h(f this$0) {}
    
    public void b(g param1g, boolean param1Boolean) {
      this.a.P(param1g);
    }
    
    public boolean c(g param1g) {
      Window.Callback callback = this.a.j0();
      if (callback != null)
        callback.onMenuOpened(108, (Menu)param1g); 
      return true;
    }
  }
  
  class i implements androidx.appcompat.view.b.a {
    private androidx.appcompat.view.b.a a;
    
    public i(f this$0, androidx.appcompat.view.b.a param1a) {
      this.a = param1a;
    }
    
    public void a(androidx.appcompat.view.b param1b) {
      this.a.a(param1b);
      f f1 = this.b;
      if (f1.q != null)
        f1.f.getDecorView().removeCallbacks(this.b.r); 
      f1 = this.b;
      if (f1.p != null) {
        f1.Z();
        f1 = this.b;
        f1.s = o0.e((View)f1.p).b(0.0F);
        this.b.s.h((p2)new a(this));
      } 
      f1 = this.b;
      d d = f1.h;
      if (d != null)
        d.onSupportActionModeFinished(f1.o); 
      f1 = this.b;
      f1.o = null;
      o0.o0((View)f1.v);
    }
    
    public boolean b(androidx.appcompat.view.b param1b, Menu param1Menu) {
      return this.a.b(param1b, param1Menu);
    }
    
    public boolean c(androidx.appcompat.view.b param1b, Menu param1Menu) {
      o0.o0((View)this.b.v);
      return this.a.c(param1b, param1Menu);
    }
    
    public boolean d(androidx.appcompat.view.b param1b, MenuItem param1MenuItem) {
      return this.a.d(param1b, param1MenuItem);
    }
    
    class a extends q2 {
      a(f.i this$0) {}
      
      public void b(View param2View) {
        this.a.b.p.setVisibility(8);
        f f = this.a.b;
        PopupWindow popupWindow = f.q;
        if (popupWindow != null) {
          popupWindow.dismiss();
        } else if (f.p.getParent() instanceof View) {
          o0.o0((View)this.a.b.p.getParent());
        } 
        this.a.b.p.k();
        this.a.b.s.h(null);
        f = this.a.b;
        f.s = null;
        o0.o0((View)f.v);
      }
    }
  }
  
  class a extends q2 {
    a(f this$0) {}
    
    public void b(View param1View) {
      this.a.b.p.setVisibility(8);
      f f = this.a.b;
      PopupWindow popupWindow = f.q;
      if (popupWindow != null) {
        popupWindow.dismiss();
      } else if (f.p.getParent() instanceof View) {
        o0.o0((View)this.a.b.p.getParent());
      } 
      this.a.b.p.k();
      this.a.b.s.h(null);
      f = this.a.b;
      f.s = null;
      o0.o0((View)f.v);
    }
  }
  
  static class j {
    static Context a(Context param1Context, Configuration param1Configuration) {
      return param1Context.createConfigurationContext(param1Configuration);
    }
    
    static void b(Configuration param1Configuration1, Configuration param1Configuration2, Configuration param1Configuration3) {
      int i = param1Configuration1.densityDpi;
      int k = param1Configuration2.densityDpi;
      if (i != k)
        param1Configuration3.densityDpi = k; 
    }
  }
  
  static class k {
    static boolean a(PowerManager param1PowerManager) {
      return param1PowerManager.isPowerSaveMode();
    }
  }
  
  static class l {
    static void a(Configuration param1Configuration1, Configuration param1Configuration2, Configuration param1Configuration3) {
      LocaleList localeList1 = g.a(param1Configuration1);
      LocaleList localeList2 = g.a(param1Configuration2);
      if (!localeList1.equals(localeList2)) {
        h.a(param1Configuration3, localeList2);
        param1Configuration3.locale = param1Configuration2.locale;
      } 
    }
  }
  
  static class m {
    static void a(Configuration param1Configuration1, Configuration param1Configuration2, Configuration param1Configuration3) {
      int i = param1Configuration1.colorMode;
      int j = param1Configuration2.colorMode;
      if ((i & 0x3) != (j & 0x3))
        param1Configuration3.colorMode |= j & 0x3; 
      i = param1Configuration1.colorMode;
      j = param1Configuration2.colorMode;
      if ((i & 0xC) != (j & 0xC))
        param1Configuration3.colorMode |= j & 0xC; 
    }
  }
  
  class n extends androidx.appcompat.view.k {
    private f.g b;
    
    private boolean c;
    
    private boolean d;
    
    private boolean e;
    
    n(f this$0, Window.Callback param1Callback) {
      super(param1Callback);
    }
    
    public boolean b(Window.Callback param1Callback, KeyEvent param1KeyEvent) {
      try {
        this.d = true;
        return param1Callback.dispatchKeyEvent(param1KeyEvent);
      } finally {
        this.d = false;
      } 
    }
    
    public void c(Window.Callback param1Callback) {
      try {
        this.c = true;
        param1Callback.onContentChanged();
        return;
      } finally {
        this.c = false;
      } 
    }
    
    public void d(Window.Callback param1Callback, int param1Int, Menu param1Menu) {
      try {
        this.e = true;
        param1Callback.onPanelClosed(param1Int, param1Menu);
        return;
      } finally {
        this.e = false;
      } 
    }
    
    public boolean dispatchKeyEvent(KeyEvent param1KeyEvent) {
      return this.d ? a().dispatchKeyEvent(param1KeyEvent) : ((this.f.X(param1KeyEvent) || super.dispatchKeyEvent(param1KeyEvent)));
    }
    
    public boolean dispatchKeyShortcutEvent(KeyEvent param1KeyEvent) {
      return (super.dispatchKeyShortcutEvent(param1KeyEvent) || this.f.v0(param1KeyEvent.getKeyCode(), param1KeyEvent));
    }
    
    void e(f.g param1g) {
      this.b = param1g;
    }
    
    final ActionMode f(ActionMode.Callback param1Callback) {
      androidx.appcompat.view.f.a a = new androidx.appcompat.view.f.a(this.f.e, param1Callback);
      androidx.appcompat.view.b b = this.f.I((androidx.appcompat.view.b.a)a);
      return (b != null) ? a.e(b) : null;
    }
    
    public void onContentChanged() {
      if (this.c)
        a().onContentChanged(); 
    }
    
    public boolean onCreatePanelMenu(int param1Int, Menu param1Menu) {
      return (param1Int == 0 && !(param1Menu instanceof g)) ? false : super.onCreatePanelMenu(param1Int, param1Menu);
    }
    
    public View onCreatePanelView(int param1Int) {
      f.g g1 = this.b;
      if (g1 != null) {
        View view = g1.onCreatePanelView(param1Int);
        if (view != null)
          return view; 
      } 
      return super.onCreatePanelView(param1Int);
    }
    
    public boolean onMenuOpened(int param1Int, Menu param1Menu) {
      super.onMenuOpened(param1Int, param1Menu);
      this.f.y0(param1Int);
      return true;
    }
    
    public void onPanelClosed(int param1Int, Menu param1Menu) {
      if (this.e) {
        a().onPanelClosed(param1Int, param1Menu);
        return;
      } 
      super.onPanelClosed(param1Int, param1Menu);
      this.f.z0(param1Int);
    }
    
    public boolean onPreparePanel(int param1Int, View param1View, Menu param1Menu) {
      g g1;
      if (param1Menu instanceof g) {
        g1 = (g)param1Menu;
      } else {
        g1 = null;
      } 
      if (param1Int == 0 && g1 == null)
        return false; 
      boolean bool1 = true;
      if (g1 != null)
        g1.e0(true); 
      f.g g2 = this.b;
      if (g2 == null || !g2.a(param1Int))
        bool1 = false; 
      boolean bool2 = bool1;
      if (!bool1)
        bool2 = super.onPreparePanel(param1Int, param1View, param1Menu); 
      if (g1 != null)
        g1.e0(false); 
      return bool2;
    }
    
    public void onProvideKeyboardShortcuts(List<KeyboardShortcutGroup> param1List, Menu param1Menu, int param1Int) {
      f.t t = this.f.h0(0, true);
      if (t != null) {
        g g1 = t.j;
        if (g1 != null) {
          super.onProvideKeyboardShortcuts(param1List, (Menu)g1, param1Int);
          return;
        } 
      } 
      super.onProvideKeyboardShortcuts(param1List, param1Menu, param1Int);
    }
    
    public ActionMode onWindowStartingActionMode(ActionMode.Callback param1Callback) {
      return (Build.VERSION.SDK_INT >= 23) ? null : (this.f.q0() ? f(param1Callback) : super.onWindowStartingActionMode(param1Callback));
    }
    
    public ActionMode onWindowStartingActionMode(ActionMode.Callback param1Callback, int param1Int) {
      return (!this.f.q0() || param1Int != 0) ? super.onWindowStartingActionMode(param1Callback, param1Int) : f(param1Callback);
    }
  }
  
  private class o extends p {
    private final PowerManager c;
    
    o(f this$0, Context param1Context) {
      super(this$0);
      this.c = (PowerManager)param1Context.getApplicationContext().getSystemService("power");
    }
    
    IntentFilter b() {
      IntentFilter intentFilter = new IntentFilter();
      intentFilter.addAction("android.os.action.POWER_SAVE_MODE_CHANGED");
      return intentFilter;
    }
    
    public int c() {
      return f.k.a(this.c) ? 2 : 1;
    }
    
    public void d() {
      this.d.J();
    }
  }
  
  abstract class p {
    private BroadcastReceiver a;
    
    p(f this$0) {}
    
    void a() {
      BroadcastReceiver broadcastReceiver = this.a;
      if (broadcastReceiver != null) {
        try {
          this.b.e.unregisterReceiver(broadcastReceiver);
        } catch (IllegalArgumentException illegalArgumentException) {}
        this.a = null;
      } 
    }
    
    abstract IntentFilter b();
    
    abstract int c();
    
    abstract void d();
    
    void e() {
      a();
      IntentFilter intentFilter = b();
      if (intentFilter != null) {
        if (intentFilter.countActions() == 0)
          return; 
        if (this.a == null)
          this.a = new a(this); 
        this.b.e.registerReceiver(this.a, intentFilter);
      } 
    }
    
    class a extends BroadcastReceiver {
      a(f.p this$0) {}
      
      public void onReceive(Context param2Context, Intent param2Intent) {
        this.a.d();
      }
    }
  }
  
  class a extends BroadcastReceiver {
    a(f this$0) {}
    
    public void onReceive(Context param1Context, Intent param1Intent) {
      this.a.d();
    }
  }
  
  private class q extends p {
    private final q c;
    
    q(f this$0, q param1q) {
      super(this$0);
      this.c = param1q;
    }
    
    IntentFilter b() {
      IntentFilter intentFilter = new IntentFilter();
      intentFilter.addAction("android.intent.action.TIME_SET");
      intentFilter.addAction("android.intent.action.TIMEZONE_CHANGED");
      intentFilter.addAction("android.intent.action.TIME_TICK");
      return intentFilter;
    }
    
    public int c() {
      return this.c.d() ? 2 : 1;
    }
    
    public void d() {
      this.d.J();
    }
  }
  
  private static class r {
    static void a(ContextThemeWrapper param1ContextThemeWrapper, Configuration param1Configuration) {
      param1ContextThemeWrapper.applyOverrideConfiguration(param1Configuration);
    }
  }
  
  private class s extends ContentFrameLayout {
    public s(f this$0, Context param1Context) {
      super(param1Context);
    }
    
    private boolean b(int param1Int1, int param1Int2) {
      return (param1Int1 < -5 || param1Int2 < -5 || param1Int1 > getWidth() + 5 || param1Int2 > getHeight() + 5);
    }
    
    public boolean dispatchKeyEvent(KeyEvent param1KeyEvent) {
      return (this.i.X(param1KeyEvent) || super.dispatchKeyEvent(param1KeyEvent));
    }
    
    public boolean onInterceptTouchEvent(MotionEvent param1MotionEvent) {
      if (param1MotionEvent.getAction() == 0 && b((int)param1MotionEvent.getX(), (int)param1MotionEvent.getY())) {
        this.i.R(0);
        return true;
      } 
      return super.onInterceptTouchEvent(param1MotionEvent);
    }
    
    public void setBackgroundResource(int param1Int) {
      setBackgroundDrawable(f.a.b(getContext(), param1Int));
    }
  }
  
  protected static final class t {
    int a;
    
    int b;
    
    int c;
    
    int d;
    
    int e;
    
    int f;
    
    ViewGroup g;
    
    View h;
    
    View i;
    
    g j;
    
    androidx.appcompat.view.menu.e k;
    
    Context l;
    
    boolean m;
    
    boolean n;
    
    boolean o;
    
    public boolean p;
    
    boolean q;
    
    boolean r;
    
    Bundle s;
    
    t(int param1Int) {
      this.a = param1Int;
      this.q = false;
    }
    
    androidx.appcompat.view.menu.n a(androidx.appcompat.view.menu.m.a param1a) {
      if (this.j == null)
        return null; 
      if (this.k == null) {
        androidx.appcompat.view.menu.e e1 = new androidx.appcompat.view.menu.e(this.l, e.g.j);
        this.k = e1;
        e1.g(param1a);
        this.j.b((androidx.appcompat.view.menu.m)this.k);
      } 
      return this.k.j(this.g);
    }
    
    public boolean b() {
      View view = this.h;
      boolean bool = false;
      if (view == null)
        return false; 
      if (this.i != null)
        return true; 
      if (this.k.a().getCount() > 0)
        bool = true; 
      return bool;
    }
    
    void c(g param1g) {
      g g1 = this.j;
      if (param1g == g1)
        return; 
      if (g1 != null)
        g1.Q((androidx.appcompat.view.menu.m)this.k); 
      this.j = param1g;
      if (param1g != null) {
        androidx.appcompat.view.menu.e e1 = this.k;
        if (e1 != null)
          param1g.b((androidx.appcompat.view.menu.m)e1); 
      } 
    }
    
    void d(Context param1Context) {
      TypedValue typedValue = new TypedValue();
      Resources.Theme theme = param1Context.getResources().newTheme();
      theme.setTo(param1Context.getTheme());
      theme.resolveAttribute(e.a.a, typedValue, true);
      int i = typedValue.resourceId;
      if (i != 0)
        theme.applyStyle(i, true); 
      theme.resolveAttribute(e.a.H, typedValue, true);
      i = typedValue.resourceId;
      if (i != 0) {
        theme.applyStyle(i, true);
      } else {
        theme.applyStyle(e.i.d, true);
      } 
      androidx.appcompat.view.d d = new androidx.appcompat.view.d(param1Context, 0);
      d.getTheme().setTo(theme);
      this.l = (Context)d;
      TypedArray typedArray = d.obtainStyledAttributes(e.j.y0);
      this.b = typedArray.getResourceId(e.j.B0, 0);
      this.f = typedArray.getResourceId(e.j.A0, 0);
      typedArray.recycle();
    }
  }
  
  private final class u implements androidx.appcompat.view.menu.m.a {
    u(f this$0) {}
    
    public void b(g param1g, boolean param1Boolean) {
      boolean bool;
      g g1 = param1g.F();
      if (g1 != param1g) {
        bool = true;
      } else {
        bool = false;
      } 
      f f1 = this.a;
      if (bool)
        param1g = g1; 
      f.t t = f1.c0((Menu)param1g);
      if (t != null) {
        if (bool) {
          this.a.O(t.a, t, (Menu)g1);
          this.a.S(t, true);
          return;
        } 
        this.a.S(t, param1Boolean);
      } 
    }
    
    public boolean c(g param1g) {
      if (param1g == param1g.F()) {
        f f1 = this.a;
        if (f1.A) {
          Window.Callback callback = f1.j0();
          if (callback != null && !this.a.L)
            callback.onMenuOpened(108, (Menu)param1g); 
        } 
      } 
      return true;
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Cricket Scorer-dex2jar.jar!\androidx\appcompat\app\f.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */