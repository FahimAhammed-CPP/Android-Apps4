package androidx.appcompat.view;

import android.content.Context;
import android.content.res.Configuration;
import android.content.res.Resources;
import android.content.res.TypedArray;
import e.b;
import e.d;
import e.j;

public class a {
  private Context a;
  
  private a(Context paramContext) {
    this.a = paramContext;
  }
  
  public static a b(Context paramContext) {
    return new a(paramContext);
  }
  
  public boolean a() {
    return ((this.a.getApplicationInfo()).targetSdkVersion < 14);
  }
  
  public int c() {
    return (this.a.getResources().getDisplayMetrics()).widthPixels / 2;
  }
  
  public int d() {
    Configuration configuration = this.a.getResources().getConfiguration();
    int i = configuration.screenWidthDp;
    int j = configuration.screenHeightDp;
    return (configuration.smallestScreenWidthDp > 600 || i > 600 || (i > 960 && j > 720) || (i > 720 && j > 960)) ? 5 : ((i >= 500 || (i > 640 && j > 480) || (i > 480 && j > 640)) ? 4 : ((i >= 360) ? 3 : 2));
  }
  
  public int e() {
    return this.a.getResources().getDimensionPixelSize(d.b);
  }
  
  public int f() {
    TypedArray typedArray = this.a.obtainStyledAttributes(null, j.a, e.a.c, 0);
    int j = typedArray.getLayoutDimension(j.j, 0);
    Resources resources = this.a.getResources();
    int i = j;
    if (!g())
      i = Math.min(j, resources.getDimensionPixelSize(d.a)); 
    typedArray.recycle();
    return i;
  }
  
  public boolean g() {
    return this.a.getResources().getBoolean(b.a);
  }
  
  public boolean h() {
    return true;
  }
}


/* Location:              C:\soft\dex2jar-2.0\Cricket Scorer-dex2jar.jar!\androidx\appcompat\view\a.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */