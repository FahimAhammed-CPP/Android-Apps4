package androidx.appcompat.view.menu;

import android.content.Context;
import android.os.Bundle;
import android.os.Parcelable;
import android.util.SparseArray;
import android.view.ContextThemeWrapper;
import android.view.LayoutInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.BaseAdapter;
import android.widget.ListAdapter;
import e.g;
import java.util.ArrayList;

public class e implements m, AdapterView.OnItemClickListener {
  Context a;
  
  LayoutInflater b;
  
  g c;
  
  ExpandedMenuView d;
  
  int e;
  
  int f;
  
  int g;
  
  private m.a h;
  
  a i;
  
  private int j;
  
  public e(int paramInt1, int paramInt2) {
    this.g = paramInt1;
    this.f = paramInt2;
  }
  
  public e(Context paramContext, int paramInt) {
    this(paramInt, 0);
    this.a = paramContext;
    this.b = LayoutInflater.from(paramContext);
  }
  
  public ListAdapter a() {
    if (this.i == null)
      this.i = new a(this); 
    return (ListAdapter)this.i;
  }
  
  public void b(g paramg, boolean paramBoolean) {
    m.a a1 = this.h;
    if (a1 != null)
      a1.b(paramg, paramBoolean); 
  }
  
  public void c(boolean paramBoolean) {
    a a1 = this.i;
    if (a1 != null)
      a1.notifyDataSetChanged(); 
  }
  
  public boolean d() {
    return false;
  }
  
  public boolean e(g paramg, i parami) {
    return false;
  }
  
  public boolean f(g paramg, i parami) {
    return false;
  }
  
  public void g(m.a parama) {
    this.h = parama;
  }
  
  public int getId() {
    return this.j;
  }
  
  public void h(Context paramContext, g paramg) {
    ContextThemeWrapper contextThemeWrapper;
    if (this.f != 0) {
      contextThemeWrapper = new ContextThemeWrapper(paramContext, this.f);
      this.a = (Context)contextThemeWrapper;
      this.b = LayoutInflater.from((Context)contextThemeWrapper);
    } else if (this.a != null) {
      this.a = (Context)contextThemeWrapper;
      if (this.b == null)
        this.b = LayoutInflater.from((Context)contextThemeWrapper); 
    } 
    this.c = paramg;
    a a1 = this.i;
    if (a1 != null)
      a1.notifyDataSetChanged(); 
  }
  
  public void i(Parcelable paramParcelable) {
    m((Bundle)paramParcelable);
  }
  
  public n j(ViewGroup paramViewGroup) {
    if (this.d == null) {
      this.d = (ExpandedMenuView)this.b.inflate(g.g, paramViewGroup, false);
      if (this.i == null)
        this.i = new a(this); 
      this.d.setAdapter((ListAdapter)this.i);
      this.d.setOnItemClickListener(this);
    } 
    return this.d;
  }
  
  public boolean k(r paramr) {
    if (!paramr.hasVisibleItems())
      return false; 
    (new h(paramr)).d(null);
    m.a a1 = this.h;
    if (a1 != null)
      a1.c(paramr); 
    return true;
  }
  
  public Parcelable l() {
    if (this.d == null)
      return null; 
    Bundle bundle = new Bundle();
    n(bundle);
    return (Parcelable)bundle;
  }
  
  public void m(Bundle paramBundle) {
    SparseArray sparseArray = paramBundle.getSparseParcelableArray("android:menu:list");
    if (sparseArray != null)
      this.d.restoreHierarchyState(sparseArray); 
  }
  
  public void n(Bundle paramBundle) {
    SparseArray sparseArray = new SparseArray();
    ExpandedMenuView expandedMenuView = this.d;
    if (expandedMenuView != null)
      expandedMenuView.saveHierarchyState(sparseArray); 
    paramBundle.putSparseParcelableArray("android:menu:list", sparseArray);
  }
  
  public void onItemClick(AdapterView<?> paramAdapterView, View paramView, int paramInt, long paramLong) {
    this.c.O((MenuItem)this.i.b(paramInt), this, 0);
  }
  
  private class a extends BaseAdapter {
    private int a = -1;
    
    public a(e this$0) {
      a();
    }
    
    void a() {
      i i = this.b.c.x();
      if (i != null) {
        ArrayList<i> arrayList = this.b.c.B();
        int k = arrayList.size();
        for (int j = 0; j < k; j++) {
          if ((i)arrayList.get(j) == i) {
            this.a = j;
            return;
          } 
        } 
      } 
      this.a = -1;
    }
    
    public i b(int param1Int) {
      ArrayList<i> arrayList = this.b.c.B();
      int i = param1Int + this.b.e;
      int j = this.a;
      param1Int = i;
      if (j >= 0) {
        param1Int = i;
        if (i >= j)
          param1Int = i + 1; 
      } 
      return arrayList.get(param1Int);
    }
    
    public int getCount() {
      int i = this.b.c.B().size() - this.b.e;
      return (this.a < 0) ? i : (i - 1);
    }
    
    public long getItemId(int param1Int) {
      return param1Int;
    }
    
    public View getView(int param1Int, View param1View, ViewGroup param1ViewGroup) {
      View view = param1View;
      if (param1View == null) {
        e e1 = this.b;
        view = e1.b.inflate(e1.g, param1ViewGroup, false);
      } 
      ((n.a)view).d(b(param1Int), 0);
      return view;
    }
    
    public void notifyDataSetChanged() {
      a();
      super.notifyDataSetChanged();
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Cricket Scorer-dex2jar.jar!\androidx\appcompat\view\menu\e.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */