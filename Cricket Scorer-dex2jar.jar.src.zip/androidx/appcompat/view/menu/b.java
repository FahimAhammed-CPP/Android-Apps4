package androidx.appcompat.view.menu;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import java.util.ArrayList;

public abstract class b implements m {
  protected Context a;
  
  protected Context b;
  
  protected g c;
  
  protected LayoutInflater d;
  
  protected LayoutInflater e;
  
  private m.a f;
  
  private int g;
  
  private int h;
  
  protected n i;
  
  private int j;
  
  public b(Context paramContext, int paramInt1, int paramInt2) {
    this.a = paramContext;
    this.d = LayoutInflater.from(paramContext);
    this.g = paramInt1;
    this.h = paramInt2;
  }
  
  protected void a(View paramView, int paramInt) {
    ViewGroup viewGroup = (ViewGroup)paramView.getParent();
    if (viewGroup != null)
      viewGroup.removeView(paramView); 
    ((ViewGroup)this.i).addView(paramView, paramInt);
  }
  
  public void b(g paramg, boolean paramBoolean) {
    m.a a1 = this.f;
    if (a1 != null)
      a1.b(paramg, paramBoolean); 
  }
  
  public void c(boolean paramBoolean) {
    ViewGroup viewGroup = (ViewGroup)this.i;
    if (viewGroup == null)
      return; 
    g g1 = this.c;
    int i = 0;
    if (g1 != null) {
      g1.t();
      ArrayList<i> arrayList = this.c.G();
      int k = arrayList.size();
      int j = 0;
      for (i = 0; j < k; i = i1) {
        i i2 = arrayList.get(j);
        int i1 = i;
        if (s(i, i2)) {
          View view1 = viewGroup.getChildAt(i);
          if (view1 instanceof n.a) {
            i i3 = ((n.a)view1).getItemData();
          } else {
            g1 = null;
          } 
          View view2 = p(i2, view1, viewGroup);
          if (i2 != g1) {
            view2.setPressed(false);
            view2.jumpDrawablesToCurrentState();
          } 
          if (view2 != view1)
            a(view2, i); 
          i1 = i + 1;
        } 
        j++;
      } 
    } 
    while (i < viewGroup.getChildCount()) {
      if (!n(viewGroup, i))
        i++; 
    } 
  }
  
  public boolean e(g paramg, i parami) {
    return false;
  }
  
  public boolean f(g paramg, i parami) {
    return false;
  }
  
  public void g(m.a parama) {
    this.f = parama;
  }
  
  public int getId() {
    return this.j;
  }
  
  public void h(Context paramContext, g paramg) {
    this.b = paramContext;
    this.e = LayoutInflater.from(paramContext);
    this.c = paramg;
  }
  
  public abstract void j(i parami, n.a parama);
  
  public boolean k(r paramr) {
    m.a a1 = this.f;
    if (a1 != null) {
      g g1;
      if (paramr == null)
        g1 = this.c; 
      return a1.c(g1);
    } 
    return false;
  }
  
  public n.a m(ViewGroup paramViewGroup) {
    return (n.a)this.d.inflate(this.h, paramViewGroup, false);
  }
  
  protected boolean n(ViewGroup paramViewGroup, int paramInt) {
    paramViewGroup.removeViewAt(paramInt);
    return true;
  }
  
  public m.a o() {
    return this.f;
  }
  
  public View p(i parami, View paramView, ViewGroup paramViewGroup) {
    n.a a1;
    if (paramView instanceof n.a) {
      a1 = (n.a)paramView;
    } else {
      a1 = m(paramViewGroup);
    } 
    j(parami, a1);
    return (View)a1;
  }
  
  public n q(ViewGroup paramViewGroup) {
    if (this.i == null) {
      n n1 = (n)this.d.inflate(this.g, paramViewGroup, false);
      this.i = n1;
      n1.b(this.c);
      c(true);
    } 
    return this.i;
  }
  
  public void r(int paramInt) {
    this.j = paramInt;
  }
  
  public abstract boolean s(int paramInt, i parami);
}


/* Location:              C:\soft\dex2jar-2.0\Cricket Scorer-dex2jar.jar!\androidx\appcompat\view\menu\b.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */