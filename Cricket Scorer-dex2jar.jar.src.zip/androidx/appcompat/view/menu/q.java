package androidx.appcompat.view.menu;

import android.content.Context;
import android.content.res.Resources;
import android.os.Parcelable;
import android.view.Gravity;
import android.view.KeyEvent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.ViewTreeObserver;
import android.widget.FrameLayout;
import android.widget.ListAdapter;
import android.widget.ListView;
import android.widget.PopupWindow;
import android.widget.TextView;
import androidx.appcompat.widget.p1;
import androidx.core.view.o0;
import e.d;
import e.g;

final class q extends k implements PopupWindow.OnDismissListener, View.OnKeyListener {
  private static final int v = g.m;
  
  private final Context b;
  
  private final g c;
  
  private final f d;
  
  private final boolean e;
  
  private final int f;
  
  private final int g;
  
  private final int h;
  
  final p1 i;
  
  final ViewTreeObserver.OnGlobalLayoutListener j = new a(this);
  
  private final View.OnAttachStateChangeListener k = new b(this);
  
  private PopupWindow.OnDismissListener l;
  
  private View m;
  
  View n;
  
  private m.a o;
  
  ViewTreeObserver p;
  
  private boolean q;
  
  private boolean r;
  
  private int s;
  
  private int t = 0;
  
  private boolean u;
  
  public q(Context paramContext, g paramg, View paramView, int paramInt1, int paramInt2, boolean paramBoolean) {
    this.b = paramContext;
    this.c = paramg;
    this.e = paramBoolean;
    this.d = new f(paramg, LayoutInflater.from(paramContext), paramBoolean, v);
    this.g = paramInt1;
    this.h = paramInt2;
    Resources resources = paramContext.getResources();
    this.f = Math.max((resources.getDisplayMetrics()).widthPixels / 2, resources.getDimensionPixelSize(d.d));
    this.m = paramView;
    this.i = new p1(paramContext, null, paramInt1, paramInt2);
    paramg.c(this, paramContext);
  }
  
  private boolean A() {
    if (a())
      return true; 
    if (!this.q) {
      boolean bool;
      View view = this.m;
      if (view == null)
        return false; 
      this.n = view;
      this.i.J(this);
      this.i.K(this);
      this.i.I(true);
      view = this.n;
      if (this.p == null) {
        bool = true;
      } else {
        bool = false;
      } 
      ViewTreeObserver viewTreeObserver = view.getViewTreeObserver();
      this.p = viewTreeObserver;
      if (bool)
        viewTreeObserver.addOnGlobalLayoutListener(this.j); 
      view.addOnAttachStateChangeListener(this.k);
      this.i.C(view);
      this.i.F(this.t);
      if (!this.r) {
        this.s = k.p((ListAdapter)this.d, null, this.b, this.f);
        this.r = true;
      } 
      this.i.E(this.s);
      this.i.H(2);
      this.i.G(o());
      this.i.show();
      ListView listView = this.i.j();
      listView.setOnKeyListener(this);
      if (this.u && this.c.z() != null) {
        FrameLayout frameLayout = (FrameLayout)LayoutInflater.from(this.b).inflate(g.l, (ViewGroup)listView, false);
        TextView textView = (TextView)frameLayout.findViewById(16908310);
        if (textView != null)
          textView.setText(this.c.z()); 
        frameLayout.setEnabled(false);
        listView.addHeaderView((View)frameLayout, null, false);
      } 
      this.i.o((ListAdapter)this.d);
      this.i.show();
      return true;
    } 
    return false;
  }
  
  public boolean a() {
    return (!this.q && this.i.a());
  }
  
  public void b(g paramg, boolean paramBoolean) {
    if (paramg != this.c)
      return; 
    dismiss();
    m.a a1 = this.o;
    if (a1 != null)
      a1.b(paramg, paramBoolean); 
  }
  
  public void c(boolean paramBoolean) {
    this.r = false;
    f f1 = this.d;
    if (f1 != null)
      f1.notifyDataSetChanged(); 
  }
  
  public boolean d() {
    return false;
  }
  
  public void dismiss() {
    if (a())
      this.i.dismiss(); 
  }
  
  public void g(m.a parama) {
    this.o = parama;
  }
  
  public void i(Parcelable paramParcelable) {}
  
  public ListView j() {
    return this.i.j();
  }
  
  public boolean k(r paramr) {
    if (paramr.hasVisibleItems()) {
      l l = new l(this.b, paramr, this.n, this.e, this.g, this.h);
      l.j(this.o);
      l.g(k.y(paramr));
      l.i(this.l);
      this.l = null;
      this.c.e(false);
      int j = this.i.c();
      int m = this.i.n();
      int i = j;
      if ((Gravity.getAbsoluteGravity(this.t, o0.E(this.m)) & 0x7) == 5)
        i = j + this.m.getWidth(); 
      if (l.n(i, m)) {
        m.a a1 = this.o;
        if (a1 != null)
          a1.c(paramr); 
        return true;
      } 
    } 
    return false;
  }
  
  public Parcelable l() {
    return null;
  }
  
  public void m(g paramg) {}
  
  public void onDismiss() {
    this.q = true;
    this.c.close();
    ViewTreeObserver viewTreeObserver = this.p;
    if (viewTreeObserver != null) {
      if (!viewTreeObserver.isAlive())
        this.p = this.n.getViewTreeObserver(); 
      this.p.removeGlobalOnLayoutListener(this.j);
      this.p = null;
    } 
    this.n.removeOnAttachStateChangeListener(this.k);
    PopupWindow.OnDismissListener onDismissListener = this.l;
    if (onDismissListener != null)
      onDismissListener.onDismiss(); 
  }
  
  public boolean onKey(View paramView, int paramInt, KeyEvent paramKeyEvent) {
    if (paramKeyEvent.getAction() == 1 && paramInt == 82) {
      dismiss();
      return true;
    } 
    return false;
  }
  
  public void q(View paramView) {
    this.m = paramView;
  }
  
  public void s(boolean paramBoolean) {
    this.d.d(paramBoolean);
  }
  
  public void show() {
    if (A())
      return; 
    throw new IllegalStateException("StandardMenuPopup cannot be used without an anchor");
  }
  
  public void t(int paramInt) {
    this.t = paramInt;
  }
  
  public void u(int paramInt) {
    this.i.e(paramInt);
  }
  
  public void v(PopupWindow.OnDismissListener paramOnDismissListener) {
    this.l = paramOnDismissListener;
  }
  
  public void w(boolean paramBoolean) {
    this.u = paramBoolean;
  }
  
  public void x(int paramInt) {
    this.i.k(paramInt);
  }
  
  class a implements ViewTreeObserver.OnGlobalLayoutListener {
    a(q this$0) {}
    
    public void onGlobalLayout() {
      if (this.a.a() && !this.a.i.A()) {
        View view = this.a.n;
        if (view == null || !view.isShown()) {
          this.a.dismiss();
          return;
        } 
        this.a.i.show();
        return;
      } 
    }
  }
  
  class b implements View.OnAttachStateChangeListener {
    b(q this$0) {}
    
    public void onViewAttachedToWindow(View param1View) {}
    
    public void onViewDetachedFromWindow(View param1View) {
      ViewTreeObserver viewTreeObserver = this.a.p;
      if (viewTreeObserver != null) {
        if (!viewTreeObserver.isAlive())
          this.a.p = param1View.getViewTreeObserver(); 
        q q1 = this.a;
        q1.p.removeGlobalOnLayoutListener(q1.j);
      } 
      param1View.removeOnAttachStateChangeListener(this);
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Cricket Scorer-dex2jar.jar!\androidx\appcompat\view\menu\q.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */