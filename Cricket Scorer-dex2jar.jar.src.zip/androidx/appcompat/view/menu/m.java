package androidx.appcompat.view.menu;

import android.content.Context;
import android.os.Parcelable;

public interface m {
  void b(g paramg, boolean paramBoolean);
  
  void c(boolean paramBoolean);
  
  boolean d();
  
  boolean e(g paramg, i parami);
  
  boolean f(g paramg, i parami);
  
  void g(a parama);
  
  int getId();
  
  void h(Context paramContext, g paramg);
  
  void i(Parcelable paramParcelable);
  
  boolean k(r paramr);
  
  Parcelable l();
  
  public static interface a {
    void b(g param1g, boolean param1Boolean);
    
    boolean c(g param1g);
  }
}


/* Location:              C:\soft\dex2jar-2.0\Cricket Scorer-dex2jar.jar!\androidx\appcompat\view\menu\m.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */