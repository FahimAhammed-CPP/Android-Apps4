package androidx.appcompat.view;

import android.content.Context;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import androidx.appcompat.view.menu.g;
import androidx.appcompat.widget.ActionBarContextView;
import java.lang.ref.WeakReference;

public class e extends b implements g.a {
  private Context c;
  
  private ActionBarContextView d;
  
  private b.a e;
  
  private WeakReference<View> f;
  
  private boolean g;
  
  private boolean h;
  
  private g i;
  
  public e(Context paramContext, ActionBarContextView paramActionBarContextView, b.a parama, boolean paramBoolean) {
    this.c = paramContext;
    this.d = paramActionBarContextView;
    this.e = parama;
    g g1 = (new g(paramActionBarContextView.getContext())).W(1);
    this.i = g1;
    g1.V(this);
    this.h = paramBoolean;
  }
  
  public boolean a(g paramg, MenuItem paramMenuItem) {
    return this.e.d(this, paramMenuItem);
  }
  
  public void b(g paramg) {
    k();
    this.d.l();
  }
  
  public void c() {
    if (this.g)
      return; 
    this.g = true;
    this.e.a(this);
  }
  
  public View d() {
    WeakReference<View> weakReference = this.f;
    return (weakReference != null) ? weakReference.get() : null;
  }
  
  public Menu e() {
    return (Menu)this.i;
  }
  
  public MenuInflater f() {
    return new g(this.d.getContext());
  }
  
  public CharSequence g() {
    return this.d.getSubtitle();
  }
  
  public CharSequence i() {
    return this.d.getTitle();
  }
  
  public void k() {
    this.e.c(this, (Menu)this.i);
  }
  
  public boolean l() {
    return this.d.j();
  }
  
  public void m(View paramView) {
    this.d.setCustomView(paramView);
    if (paramView != null) {
      WeakReference<View> weakReference = new WeakReference<View>(paramView);
    } else {
      paramView = null;
    } 
    this.f = (WeakReference<View>)paramView;
  }
  
  public void n(int paramInt) {
    o(this.c.getString(paramInt));
  }
  
  public void o(CharSequence paramCharSequence) {
    this.d.setSubtitle(paramCharSequence);
  }
  
  public void q(int paramInt) {
    r(this.c.getString(paramInt));
  }
  
  public void r(CharSequence paramCharSequence) {
    this.d.setTitle(paramCharSequence);
  }
  
  public void s(boolean paramBoolean) {
    super.s(paramBoolean);
    this.d.setTitleOptional(paramBoolean);
  }
}


/* Location:              C:\soft\dex2jar-2.0\Cricket Scorer-dex2jar.jar!\androidx\appcompat\view\e.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */