package androidx.appcompat.view;

import android.view.View;
import android.view.animation.Interpolator;
import androidx.core.view.o2;
import androidx.core.view.p2;
import androidx.core.view.q2;
import java.util.ArrayList;
import java.util.Iterator;

public class h {
  final ArrayList<o2> a = new ArrayList<o2>();
  
  private long b = -1L;
  
  private Interpolator c;
  
  p2 d;
  
  private boolean e;
  
  private final q2 f = new a(this);
  
  public void a() {
    if (!this.e)
      return; 
    Iterator<o2> iterator = this.a.iterator();
    while (iterator.hasNext())
      ((o2)iterator.next()).c(); 
    this.e = false;
  }
  
  void b() {
    this.e = false;
  }
  
  public h c(o2 paramo2) {
    if (!this.e)
      this.a.add(paramo2); 
    return this;
  }
  
  public h d(o2 paramo21, o2 paramo22) {
    this.a.add(paramo21);
    paramo22.j(paramo21.d());
    this.a.add(paramo22);
    return this;
  }
  
  public h e(long paramLong) {
    if (!this.e)
      this.b = paramLong; 
    return this;
  }
  
  public h f(Interpolator paramInterpolator) {
    if (!this.e)
      this.c = paramInterpolator; 
    return this;
  }
  
  public h g(p2 paramp2) {
    if (!this.e)
      this.d = paramp2; 
    return this;
  }
  
  public void h() {
    if (this.e)
      return; 
    for (o2 o2 : this.a) {
      long l = this.b;
      if (l >= 0L)
        o2.f(l); 
      Interpolator interpolator = this.c;
      if (interpolator != null)
        o2.g(interpolator); 
      if (this.d != null)
        o2.h((p2)this.f); 
      o2.l();
    } 
    this.e = true;
  }
  
  class a extends q2 {
    private boolean a = false;
    
    private int b = 0;
    
    a(h this$0) {}
    
    public void b(View param1View) {
      int i = this.b + 1;
      this.b = i;
      if (i == this.c.a.size()) {
        p2 p2 = this.c.d;
        if (p2 != null)
          p2.b(null); 
        d();
      } 
    }
    
    public void c(View param1View) {
      if (this.a)
        return; 
      this.a = true;
      p2 p2 = this.c.d;
      if (p2 != null)
        p2.c(null); 
    }
    
    void d() {
      this.b = 0;
      this.a = false;
      this.c.b();
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Cricket Scorer-dex2jar.jar!\androidx\appcompat\view\h.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */