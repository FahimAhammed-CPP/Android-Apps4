package androidx.cardview.widget;

import android.content.Context;
import android.content.res.ColorStateList;
import android.view.View;

class a implements c {
  private d o(b paramb) {
    return (d)paramb.e();
  }
  
  public void a(b paramb, Context paramContext, ColorStateList paramColorStateList, float paramFloat1, float paramFloat2, float paramFloat3) {
    paramb.b(new d(paramColorStateList, paramFloat1));
    View view = paramb.f();
    view.setClipToOutline(true);
    view.setElevation(paramFloat2);
    n(paramb, paramFloat3);
  }
  
  public void b(b paramb, float paramFloat) {
    o(paramb).h(paramFloat);
  }
  
  public float c(b paramb) {
    return paramb.f().getElevation();
  }
  
  public float d(b paramb) {
    return o(paramb).d();
  }
  
  public void e(b paramb) {
    n(paramb, g(paramb));
  }
  
  public void f(b paramb, float paramFloat) {
    paramb.f().setElevation(paramFloat);
  }
  
  public float g(b paramb) {
    return o(paramb).c();
  }
  
  public ColorStateList h(b paramb) {
    return o(paramb).b();
  }
  
  public void i() {}
  
  public float j(b paramb) {
    return d(paramb) * 2.0F;
  }
  
  public float k(b paramb) {
    return d(paramb) * 2.0F;
  }
  
  public void l(b paramb) {
    n(paramb, g(paramb));
  }
  
  public void m(b paramb, ColorStateList paramColorStateList) {
    o(paramb).f(paramColorStateList);
  }
  
  public void n(b paramb, float paramFloat) {
    o(paramb).g(paramFloat, paramb.d(), paramb.c());
    p(paramb);
  }
  
  public void p(b paramb) {
    if (!paramb.d()) {
      paramb.a(0, 0, 0, 0);
      return;
    } 
    float f1 = g(paramb);
    float f2 = d(paramb);
    int i = (int)Math.ceil(e.a(f1, f2, paramb.c()));
    int j = (int)Math.ceil(e.b(f1, f2, paramb.c()));
    paramb.a(i, j, i, j);
  }
}


/* Location:              C:\soft\dex2jar-2.0\Cricket Scorer-dex2jar.jar!\androidx\cardview\widget\a.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */