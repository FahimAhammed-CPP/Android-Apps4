package androidx.constraintlayout.motion.widget;

import android.content.Context;
import android.graphics.Canvas;
import android.os.Bundle;
import android.util.Log;
import android.view.Display;
import android.view.MotionEvent;
import android.view.View;
import android.view.animation.Interpolator;
import androidx.constraintlayout.widget.ConstraintLayout;
import androidx.core.view.g0;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.concurrent.CopyOnWriteArrayList;

public class j extends ConstraintLayout implements g0 {
  public static boolean B0;
  
  Interpolator A;
  
  ArrayList<Integer> A0;
  
  float B;
  
  private int C;
  
  int D;
  
  private int E;
  
  private boolean F;
  
  HashMap<View, g> G;
  
  private long H;
  
  private float I;
  
  float J;
  
  float K;
  
  private long L;
  
  float M;
  
  private boolean N;
  
  boolean O;
  
  private d P;
  
  int Q;
  
  private boolean R;
  
  private r.b S;
  
  private b T;
  
  boolean U;
  
  float V;
  
  float W;
  
  long e0;
  
  float f0;
  
  private boolean g0;
  
  private ArrayList<h> h0;
  
  private ArrayList<h> i0;
  
  private ArrayList<h> j0;
  
  private CopyOnWriteArrayList<d> k0;
  
  private int l0;
  
  private float m0;
  
  boolean n0;
  
  protected boolean o0;
  
  float p0;
  
  private n.c q0;
  
  private boolean r0;
  
  private c s0;
  
  private Runnable t0;
  
  private int[] u0;
  
  int v0;
  
  private int w0;
  
  private boolean x0;
  
  e y0;
  
  Interpolator z;
  
  private boolean z0;
  
  private void G() {
    // Byte code:
    //   0: aload_0
    //   1: getfield P : Landroidx/constraintlayout/motion/widget/j$d;
    //   4: ifnonnull -> 23
    //   7: aload_0
    //   8: getfield k0 : Ljava/util/concurrent/CopyOnWriteArrayList;
    //   11: astore_2
    //   12: aload_2
    //   13: ifnull -> 219
    //   16: aload_2
    //   17: invokevirtual isEmpty : ()Z
    //   20: ifne -> 219
    //   23: aload_0
    //   24: getfield m0 : F
    //   27: aload_0
    //   28: getfield J : F
    //   31: fcmpl
    //   32: ifeq -> 219
    //   35: aload_0
    //   36: getfield l0 : I
    //   39: iconst_m1
    //   40: if_icmpeq -> 121
    //   43: aload_0
    //   44: getfield P : Landroidx/constraintlayout/motion/widget/j$d;
    //   47: astore_2
    //   48: aload_2
    //   49: ifnull -> 67
    //   52: aload_2
    //   53: aload_0
    //   54: aload_0
    //   55: getfield C : I
    //   58: aload_0
    //   59: getfield E : I
    //   62: invokeinterface b : (Landroidx/constraintlayout/motion/widget/j;II)V
    //   67: aload_0
    //   68: getfield k0 : Ljava/util/concurrent/CopyOnWriteArrayList;
    //   71: astore_2
    //   72: aload_2
    //   73: ifnull -> 116
    //   76: aload_2
    //   77: invokevirtual iterator : ()Ljava/util/Iterator;
    //   80: astore_2
    //   81: aload_2
    //   82: invokeinterface hasNext : ()Z
    //   87: ifeq -> 116
    //   90: aload_2
    //   91: invokeinterface next : ()Ljava/lang/Object;
    //   96: checkcast androidx/constraintlayout/motion/widget/j$d
    //   99: aload_0
    //   100: aload_0
    //   101: getfield C : I
    //   104: aload_0
    //   105: getfield E : I
    //   108: invokeinterface b : (Landroidx/constraintlayout/motion/widget/j;II)V
    //   113: goto -> 81
    //   116: aload_0
    //   117: iconst_1
    //   118: putfield n0 : Z
    //   121: aload_0
    //   122: iconst_m1
    //   123: putfield l0 : I
    //   126: aload_0
    //   127: getfield J : F
    //   130: fstore_1
    //   131: aload_0
    //   132: fload_1
    //   133: putfield m0 : F
    //   136: aload_0
    //   137: getfield P : Landroidx/constraintlayout/motion/widget/j$d;
    //   140: astore_2
    //   141: aload_2
    //   142: ifnull -> 161
    //   145: aload_2
    //   146: aload_0
    //   147: aload_0
    //   148: getfield C : I
    //   151: aload_0
    //   152: getfield E : I
    //   155: fload_1
    //   156: invokeinterface a : (Landroidx/constraintlayout/motion/widget/j;IIF)V
    //   161: aload_0
    //   162: getfield k0 : Ljava/util/concurrent/CopyOnWriteArrayList;
    //   165: astore_2
    //   166: aload_2
    //   167: ifnull -> 214
    //   170: aload_2
    //   171: invokevirtual iterator : ()Ljava/util/Iterator;
    //   174: astore_2
    //   175: aload_2
    //   176: invokeinterface hasNext : ()Z
    //   181: ifeq -> 214
    //   184: aload_2
    //   185: invokeinterface next : ()Ljava/lang/Object;
    //   190: checkcast androidx/constraintlayout/motion/widget/j$d
    //   193: aload_0
    //   194: aload_0
    //   195: getfield C : I
    //   198: aload_0
    //   199: getfield E : I
    //   202: aload_0
    //   203: getfield J : F
    //   206: invokeinterface a : (Landroidx/constraintlayout/motion/widget/j;IIF)V
    //   211: goto -> 175
    //   214: aload_0
    //   215: iconst_1
    //   216: putfield n0 : Z
    //   219: return
  }
  
  private void K() {
    if (this.P == null) {
      CopyOnWriteArrayList<d> copyOnWriteArrayList = this.k0;
      if (copyOnWriteArrayList == null || copyOnWriteArrayList.isEmpty())
        return; 
    } 
    this.n0 = false;
    for (Integer integer : this.A0) {
      d d1 = this.P;
      if (d1 != null)
        d1.d(this, integer.intValue()); 
      CopyOnWriteArrayList<d> copyOnWriteArrayList = this.k0;
      if (copyOnWriteArrayList != null) {
        Iterator<d> iterator = copyOnWriteArrayList.iterator();
        while (iterator.hasNext())
          ((d)iterator.next()).d(this, integer.intValue()); 
      } 
    } 
    this.A0.clear();
  }
  
  void E(float paramFloat) {}
  
  void F(boolean paramBoolean) {
    // Byte code:
    //   0: aload_0
    //   1: getfield L : J
    //   4: ldc2_w -1
    //   7: lcmp
    //   8: ifne -> 19
    //   11: aload_0
    //   12: aload_0
    //   13: invokevirtual getNanoTime : ()J
    //   16: putfield L : J
    //   19: aload_0
    //   20: getfield K : F
    //   23: fstore_2
    //   24: fload_2
    //   25: fconst_0
    //   26: fcmpl
    //   27: ifle -> 41
    //   30: fload_2
    //   31: fconst_1
    //   32: fcmpg
    //   33: ifge -> 41
    //   36: aload_0
    //   37: iconst_m1
    //   38: putfield D : I
    //   41: aload_0
    //   42: getfield g0 : Z
    //   45: istore #13
    //   47: iconst_1
    //   48: istore #8
    //   50: iconst_1
    //   51: istore #9
    //   53: iconst_0
    //   54: istore #10
    //   56: iload #13
    //   58: ifne -> 81
    //   61: aload_0
    //   62: getfield O : Z
    //   65: ifeq -> 1059
    //   68: iload_1
    //   69: ifne -> 81
    //   72: aload_0
    //   73: getfield M : F
    //   76: fload_2
    //   77: fcmpl
    //   78: ifeq -> 1059
    //   81: aload_0
    //   82: getfield M : F
    //   85: fload_2
    //   86: fsub
    //   87: invokestatic signum : (F)F
    //   90: fstore #5
    //   92: aload_0
    //   93: invokevirtual getNanoTime : ()J
    //   96: lstore #14
    //   98: aload_0
    //   99: getfield z : Landroid/view/animation/Interpolator;
    //   102: astore #16
    //   104: aload #16
    //   106: instanceof androidx/constraintlayout/motion/widget/i
    //   109: ifne -> 135
    //   112: lload #14
    //   114: aload_0
    //   115: getfield L : J
    //   118: lsub
    //   119: l2f
    //   120: fload #5
    //   122: fmul
    //   123: ldc 1.0E-9
    //   125: fmul
    //   126: aload_0
    //   127: getfield I : F
    //   130: fdiv
    //   131: fstore_3
    //   132: goto -> 137
    //   135: fconst_0
    //   136: fstore_3
    //   137: aload_0
    //   138: getfield K : F
    //   141: fload_3
    //   142: fadd
    //   143: fstore_2
    //   144: aload_0
    //   145: getfield N : Z
    //   148: ifeq -> 156
    //   151: aload_0
    //   152: getfield M : F
    //   155: fstore_2
    //   156: fload #5
    //   158: fconst_0
    //   159: fcmpl
    //   160: istore #11
    //   162: iload #11
    //   164: ifle -> 176
    //   167: fload_2
    //   168: aload_0
    //   169: getfield M : F
    //   172: fcmpl
    //   173: ifge -> 192
    //   176: fload #5
    //   178: fconst_0
    //   179: fcmpg
    //   180: ifgt -> 208
    //   183: fload_2
    //   184: aload_0
    //   185: getfield M : F
    //   188: fcmpg
    //   189: ifgt -> 208
    //   192: aload_0
    //   193: getfield M : F
    //   196: fstore_2
    //   197: aload_0
    //   198: iconst_0
    //   199: putfield O : Z
    //   202: iconst_1
    //   203: istore #7
    //   205: goto -> 211
    //   208: iconst_0
    //   209: istore #7
    //   211: aload_0
    //   212: fload_2
    //   213: putfield K : F
    //   216: aload_0
    //   217: fload_2
    //   218: putfield J : F
    //   221: aload_0
    //   222: lload #14
    //   224: putfield L : J
    //   227: aload #16
    //   229: ifnull -> 514
    //   232: iload #7
    //   234: ifne -> 514
    //   237: aload_0
    //   238: getfield R : Z
    //   241: ifeq -> 447
    //   244: aload #16
    //   246: lload #14
    //   248: aload_0
    //   249: getfield H : J
    //   252: lsub
    //   253: l2f
    //   254: ldc 1.0E-9
    //   256: fmul
    //   257: invokeinterface getInterpolation : (F)F
    //   262: fstore #4
    //   264: aload_0
    //   265: getfield z : Landroid/view/animation/Interpolator;
    //   268: astore #16
    //   270: aload_0
    //   271: getfield S : Lr/b;
    //   274: astore #17
    //   276: aload #16
    //   278: aload #17
    //   280: if_acmpne -> 303
    //   283: aload #17
    //   285: invokevirtual b : ()Z
    //   288: ifeq -> 297
    //   291: iconst_2
    //   292: istore #7
    //   294: goto -> 306
    //   297: iconst_1
    //   298: istore #7
    //   300: goto -> 306
    //   303: iconst_0
    //   304: istore #7
    //   306: aload_0
    //   307: fload #4
    //   309: putfield K : F
    //   312: aload_0
    //   313: lload #14
    //   315: putfield L : J
    //   318: aload_0
    //   319: getfield z : Landroid/view/animation/Interpolator;
    //   322: astore #16
    //   324: fload #4
    //   326: fstore_3
    //   327: aload #16
    //   329: instanceof androidx/constraintlayout/motion/widget/i
    //   332: ifeq -> 442
    //   335: aload #16
    //   337: checkcast androidx/constraintlayout/motion/widget/i
    //   340: invokevirtual a : ()F
    //   343: fstore #6
    //   345: aload_0
    //   346: fload #6
    //   348: putfield B : F
    //   351: fload #6
    //   353: invokestatic abs : (F)F
    //   356: aload_0
    //   357: getfield I : F
    //   360: fmul
    //   361: ldc 1.0E-5
    //   363: fcmpg
    //   364: ifgt -> 378
    //   367: iload #7
    //   369: iconst_2
    //   370: if_icmpne -> 378
    //   373: aload_0
    //   374: iconst_0
    //   375: putfield O : Z
    //   378: fload #4
    //   380: fstore_2
    //   381: fload #6
    //   383: fconst_0
    //   384: fcmpl
    //   385: ifle -> 410
    //   388: fload #4
    //   390: fstore_2
    //   391: fload #4
    //   393: fconst_1
    //   394: fcmpl
    //   395: iflt -> 410
    //   398: aload_0
    //   399: fconst_1
    //   400: putfield K : F
    //   403: aload_0
    //   404: iconst_0
    //   405: putfield O : Z
    //   408: fconst_1
    //   409: fstore_2
    //   410: fload_2
    //   411: fstore_3
    //   412: fload #6
    //   414: fconst_0
    //   415: fcmpg
    //   416: ifge -> 442
    //   419: fload_2
    //   420: fstore_3
    //   421: fload_2
    //   422: fconst_0
    //   423: fcmpg
    //   424: ifgt -> 442
    //   427: aload_0
    //   428: fconst_0
    //   429: putfield K : F
    //   432: aload_0
    //   433: iconst_0
    //   434: putfield O : Z
    //   437: fconst_0
    //   438: fstore_2
    //   439: goto -> 522
    //   442: fload_3
    //   443: fstore_2
    //   444: goto -> 522
    //   447: aload #16
    //   449: fload_2
    //   450: invokeinterface getInterpolation : (F)F
    //   455: fstore #4
    //   457: aload_0
    //   458: getfield z : Landroid/view/animation/Interpolator;
    //   461: astore #16
    //   463: aload #16
    //   465: instanceof androidx/constraintlayout/motion/widget/i
    //   468: ifeq -> 486
    //   471: aload_0
    //   472: aload #16
    //   474: checkcast androidx/constraintlayout/motion/widget/i
    //   477: invokevirtual a : ()F
    //   480: putfield B : F
    //   483: goto -> 508
    //   486: aload_0
    //   487: aload #16
    //   489: fload_2
    //   490: fload_3
    //   491: fadd
    //   492: invokeinterface getInterpolation : (F)F
    //   497: fload #4
    //   499: fsub
    //   500: fload #5
    //   502: fmul
    //   503: fload_3
    //   504: fdiv
    //   505: putfield B : F
    //   508: fload #4
    //   510: fstore_2
    //   511: goto -> 519
    //   514: aload_0
    //   515: fload_3
    //   516: putfield B : F
    //   519: iconst_0
    //   520: istore #7
    //   522: aload_0
    //   523: getfield B : F
    //   526: invokestatic abs : (F)F
    //   529: ldc 1.0E-5
    //   531: fcmpl
    //   532: ifle -> 542
    //   535: aload_0
    //   536: getstatic androidx/constraintlayout/motion/widget/j$e.c : Landroidx/constraintlayout/motion/widget/j$e;
    //   539: invokevirtual setState : (Landroidx/constraintlayout/motion/widget/j$e;)V
    //   542: fload_2
    //   543: fstore_3
    //   544: iload #7
    //   546: iconst_1
    //   547: if_icmpeq -> 629
    //   550: iload #11
    //   552: ifle -> 564
    //   555: fload_2
    //   556: aload_0
    //   557: getfield M : F
    //   560: fcmpl
    //   561: ifge -> 586
    //   564: fload_2
    //   565: fstore #4
    //   567: fload #5
    //   569: fconst_0
    //   570: fcmpg
    //   571: ifgt -> 597
    //   574: fload_2
    //   575: fstore #4
    //   577: fload_2
    //   578: aload_0
    //   579: getfield M : F
    //   582: fcmpg
    //   583: ifgt -> 597
    //   586: aload_0
    //   587: getfield M : F
    //   590: fstore #4
    //   592: aload_0
    //   593: iconst_0
    //   594: putfield O : Z
    //   597: fload #4
    //   599: fconst_1
    //   600: fcmpl
    //   601: ifge -> 614
    //   604: fload #4
    //   606: fstore_3
    //   607: fload #4
    //   609: fconst_0
    //   610: fcmpg
    //   611: ifgt -> 629
    //   614: aload_0
    //   615: iconst_0
    //   616: putfield O : Z
    //   619: aload_0
    //   620: getstatic androidx/constraintlayout/motion/widget/j$e.d : Landroidx/constraintlayout/motion/widget/j$e;
    //   623: invokevirtual setState : (Landroidx/constraintlayout/motion/widget/j$e;)V
    //   626: fload #4
    //   628: fstore_3
    //   629: aload_0
    //   630: invokevirtual getChildCount : ()I
    //   633: istore #12
    //   635: aload_0
    //   636: iconst_0
    //   637: putfield g0 : Z
    //   640: aload_0
    //   641: invokevirtual getNanoTime : ()J
    //   644: lstore #14
    //   646: aload_0
    //   647: fload_3
    //   648: putfield p0 : F
    //   651: aload_0
    //   652: getfield A : Landroid/view/animation/Interpolator;
    //   655: astore #16
    //   657: aload #16
    //   659: ifnonnull -> 667
    //   662: fload_3
    //   663: fstore_2
    //   664: goto -> 676
    //   667: aload #16
    //   669: fload_3
    //   670: invokeinterface getInterpolation : (F)F
    //   675: fstore_2
    //   676: aload_0
    //   677: getfield A : Landroid/view/animation/Interpolator;
    //   680: astore #16
    //   682: aload #16
    //   684: ifnull -> 728
    //   687: aload #16
    //   689: fload #5
    //   691: aload_0
    //   692: getfield I : F
    //   695: fdiv
    //   696: fload_3
    //   697: fadd
    //   698: invokeinterface getInterpolation : (F)F
    //   703: fstore #4
    //   705: aload_0
    //   706: fload #4
    //   708: putfield B : F
    //   711: aload_0
    //   712: fload #4
    //   714: aload_0
    //   715: getfield A : Landroid/view/animation/Interpolator;
    //   718: fload_3
    //   719: invokeinterface getInterpolation : (F)F
    //   724: fsub
    //   725: putfield B : F
    //   728: iconst_0
    //   729: istore #7
    //   731: iload #7
    //   733: iload #12
    //   735: if_icmpge -> 799
    //   738: aload_0
    //   739: iload #7
    //   741: invokevirtual getChildAt : (I)Landroid/view/View;
    //   744: astore #16
    //   746: aload_0
    //   747: getfield G : Ljava/util/HashMap;
    //   750: aload #16
    //   752: invokevirtual get : (Ljava/lang/Object;)Ljava/lang/Object;
    //   755: checkcast androidx/constraintlayout/motion/widget/g
    //   758: astore #17
    //   760: aload #17
    //   762: ifnull -> 790
    //   765: aload_0
    //   766: getfield g0 : Z
    //   769: istore_1
    //   770: aload_0
    //   771: aload #17
    //   773: aload #16
    //   775: fload_2
    //   776: lload #14
    //   778: aload_0
    //   779: getfield q0 : Ln/c;
    //   782: invokevirtual c : (Landroid/view/View;FJLn/c;)Z
    //   785: iload_1
    //   786: ior
    //   787: putfield g0 : Z
    //   790: iload #7
    //   792: iconst_1
    //   793: iadd
    //   794: istore #7
    //   796: goto -> 731
    //   799: iload #11
    //   801: ifle -> 813
    //   804: fload_3
    //   805: aload_0
    //   806: getfield M : F
    //   809: fcmpl
    //   810: ifge -> 829
    //   813: fload #5
    //   815: fconst_0
    //   816: fcmpg
    //   817: ifgt -> 835
    //   820: fload_3
    //   821: aload_0
    //   822: getfield M : F
    //   825: fcmpg
    //   826: ifgt -> 835
    //   829: iconst_1
    //   830: istore #7
    //   832: goto -> 838
    //   835: iconst_0
    //   836: istore #7
    //   838: aload_0
    //   839: getfield g0 : Z
    //   842: ifne -> 864
    //   845: aload_0
    //   846: getfield O : Z
    //   849: ifne -> 864
    //   852: iload #7
    //   854: ifeq -> 864
    //   857: aload_0
    //   858: getstatic androidx/constraintlayout/motion/widget/j$e.d : Landroidx/constraintlayout/motion/widget/j$e;
    //   861: invokevirtual setState : (Landroidx/constraintlayout/motion/widget/j$e;)V
    //   864: aload_0
    //   865: getfield o0 : Z
    //   868: ifeq -> 875
    //   871: aload_0
    //   872: invokevirtual requestLayout : ()V
    //   875: iload #7
    //   877: iconst_1
    //   878: ixor
    //   879: aload_0
    //   880: getfield g0 : Z
    //   883: ior
    //   884: istore_1
    //   885: aload_0
    //   886: iload_1
    //   887: putfield g0 : Z
    //   890: fload_3
    //   891: fconst_0
    //   892: fcmpg
    //   893: ifgt -> 928
    //   896: aload_0
    //   897: getfield C : I
    //   900: istore #7
    //   902: iload #7
    //   904: iconst_m1
    //   905: if_icmpeq -> 928
    //   908: aload_0
    //   909: getfield D : I
    //   912: iload #7
    //   914: if_icmpne -> 920
    //   917: goto -> 928
    //   920: aload_0
    //   921: iload #7
    //   923: putfield D : I
    //   926: aconst_null
    //   927: athrow
    //   928: fload_3
    //   929: f2d
    //   930: dconst_1
    //   931: dcmpl
    //   932: iflt -> 965
    //   935: aload_0
    //   936: getfield D : I
    //   939: istore #7
    //   941: aload_0
    //   942: getfield E : I
    //   945: istore #12
    //   947: iload #7
    //   949: iload #12
    //   951: if_icmpne -> 957
    //   954: goto -> 965
    //   957: aload_0
    //   958: iload #12
    //   960: putfield D : I
    //   963: aconst_null
    //   964: athrow
    //   965: iload_1
    //   966: ifne -> 1013
    //   969: aload_0
    //   970: getfield O : Z
    //   973: ifeq -> 979
    //   976: goto -> 1013
    //   979: iload #11
    //   981: ifle -> 990
    //   984: fload_3
    //   985: fconst_1
    //   986: fcmpl
    //   987: ifeq -> 1003
    //   990: fload #5
    //   992: fconst_0
    //   993: fcmpg
    //   994: ifge -> 1017
    //   997: fload_3
    //   998: fconst_0
    //   999: fcmpl
    //   1000: ifne -> 1017
    //   1003: aload_0
    //   1004: getstatic androidx/constraintlayout/motion/widget/j$e.d : Landroidx/constraintlayout/motion/widget/j$e;
    //   1007: invokevirtual setState : (Landroidx/constraintlayout/motion/widget/j$e;)V
    //   1010: goto -> 1017
    //   1013: aload_0
    //   1014: invokevirtual invalidate : ()V
    //   1017: aload_0
    //   1018: getfield g0 : Z
    //   1021: ifne -> 1059
    //   1024: aload_0
    //   1025: getfield O : Z
    //   1028: ifne -> 1059
    //   1031: iload #11
    //   1033: ifle -> 1042
    //   1036: fload_3
    //   1037: fconst_1
    //   1038: fcmpl
    //   1039: ifeq -> 1055
    //   1042: fload #5
    //   1044: fconst_0
    //   1045: fcmpg
    //   1046: ifge -> 1059
    //   1049: fload_3
    //   1050: fconst_0
    //   1051: fcmpl
    //   1052: ifne -> 1059
    //   1055: aload_0
    //   1056: invokevirtual J : ()V
    //   1059: aload_0
    //   1060: getfield K : F
    //   1063: fstore_2
    //   1064: fload_2
    //   1065: fconst_1
    //   1066: fcmpl
    //   1067: iflt -> 1108
    //   1070: aload_0
    //   1071: getfield D : I
    //   1074: istore #7
    //   1076: aload_0
    //   1077: getfield E : I
    //   1080: istore #8
    //   1082: iload #7
    //   1084: iload #8
    //   1086: if_icmpeq -> 1096
    //   1089: iload #9
    //   1091: istore #7
    //   1093: goto -> 1099
    //   1096: iconst_0
    //   1097: istore #7
    //   1099: aload_0
    //   1100: iload #8
    //   1102: putfield D : I
    //   1105: goto -> 1156
    //   1108: iload #10
    //   1110: istore #7
    //   1112: fload_2
    //   1113: fconst_0
    //   1114: fcmpg
    //   1115: ifgt -> 1156
    //   1118: aload_0
    //   1119: getfield D : I
    //   1122: istore #7
    //   1124: aload_0
    //   1125: getfield C : I
    //   1128: istore #9
    //   1130: iload #7
    //   1132: iload #9
    //   1134: if_icmpeq -> 1144
    //   1137: iload #8
    //   1139: istore #7
    //   1141: goto -> 1147
    //   1144: iconst_0
    //   1145: istore #7
    //   1147: aload_0
    //   1148: iload #9
    //   1150: putfield D : I
    //   1153: goto -> 1105
    //   1156: aload_0
    //   1157: aload_0
    //   1158: getfield z0 : Z
    //   1161: iload #7
    //   1163: ior
    //   1164: putfield z0 : Z
    //   1167: iload #7
    //   1169: ifeq -> 1183
    //   1172: aload_0
    //   1173: getfield r0 : Z
    //   1176: ifne -> 1183
    //   1179: aload_0
    //   1180: invokevirtual requestLayout : ()V
    //   1183: aload_0
    //   1184: aload_0
    //   1185: getfield K : F
    //   1188: putfield J : F
    //   1191: return
  }
  
  protected void H() {
    // Byte code:
    //   0: aload_0
    //   1: getfield P : Landroidx/constraintlayout/motion/widget/j$d;
    //   4: ifnonnull -> 23
    //   7: aload_0
    //   8: getfield k0 : Ljava/util/concurrent/CopyOnWriteArrayList;
    //   11: astore_3
    //   12: aload_3
    //   13: ifnull -> 103
    //   16: aload_3
    //   17: invokevirtual isEmpty : ()Z
    //   20: ifne -> 103
    //   23: aload_0
    //   24: getfield l0 : I
    //   27: iconst_m1
    //   28: if_icmpne -> 103
    //   31: aload_0
    //   32: aload_0
    //   33: getfield D : I
    //   36: putfield l0 : I
    //   39: aload_0
    //   40: getfield A0 : Ljava/util/ArrayList;
    //   43: invokevirtual isEmpty : ()Z
    //   46: ifne -> 74
    //   49: aload_0
    //   50: getfield A0 : Ljava/util/ArrayList;
    //   53: astore_3
    //   54: aload_3
    //   55: aload_3
    //   56: invokevirtual size : ()I
    //   59: iconst_1
    //   60: isub
    //   61: invokevirtual get : (I)Ljava/lang/Object;
    //   64: checkcast java/lang/Integer
    //   67: invokevirtual intValue : ()I
    //   70: istore_1
    //   71: goto -> 76
    //   74: iconst_m1
    //   75: istore_1
    //   76: aload_0
    //   77: getfield D : I
    //   80: istore_2
    //   81: iload_1
    //   82: iload_2
    //   83: if_icmpeq -> 103
    //   86: iload_2
    //   87: iconst_m1
    //   88: if_icmpeq -> 103
    //   91: aload_0
    //   92: getfield A0 : Ljava/util/ArrayList;
    //   95: iload_2
    //   96: invokestatic valueOf : (I)Ljava/lang/Integer;
    //   99: invokevirtual add : (Ljava/lang/Object;)Z
    //   102: pop
    //   103: aload_0
    //   104: invokespecial K : ()V
    //   107: aload_0
    //   108: getfield t0 : Ljava/lang/Runnable;
    //   111: astore_3
    //   112: aload_3
    //   113: ifnull -> 122
    //   116: aload_3
    //   117: invokeinterface run : ()V
    //   122: aload_0
    //   123: getfield u0 : [I
    //   126: astore_3
    //   127: aload_3
    //   128: ifnull -> 171
    //   131: aload_0
    //   132: getfield v0 : I
    //   135: ifle -> 171
    //   138: aload_0
    //   139: aload_3
    //   140: iconst_0
    //   141: iaload
    //   142: invokevirtual P : (I)V
    //   145: aload_0
    //   146: getfield u0 : [I
    //   149: astore_3
    //   150: aload_3
    //   151: iconst_1
    //   152: aload_3
    //   153: iconst_0
    //   154: aload_3
    //   155: arraylength
    //   156: iconst_1
    //   157: isub
    //   158: invokestatic arraycopy : (Ljava/lang/Object;ILjava/lang/Object;II)V
    //   161: aload_0
    //   162: aload_0
    //   163: getfield v0 : I
    //   166: iconst_1
    //   167: isub
    //   168: putfield v0 : I
    //   171: return
  }
  
  public void I(int paramInt, boolean paramBoolean, float paramFloat) {
    d d1 = this.P;
    if (d1 != null)
      d1.c(this, paramInt, paramBoolean, paramFloat); 
    CopyOnWriteArrayList<d> copyOnWriteArrayList = this.k0;
    if (copyOnWriteArrayList != null) {
      Iterator<d> iterator = copyOnWriteArrayList.iterator();
      while (iterator.hasNext())
        ((d)iterator.next()).c(this, paramInt, paramBoolean, paramFloat); 
    } 
  }
  
  void J() {}
  
  public void L(float paramFloat1, float paramFloat2) {
    if (!isAttachedToWindow()) {
      if (this.s0 == null)
        this.s0 = new c(this); 
      this.s0.e(paramFloat1);
      this.s0.h(paramFloat2);
      return;
    } 
    setProgress(paramFloat1);
    setState(e.c);
    this.B = paramFloat2;
    float f = 1.0F;
    int i = paramFloat2 cmp 0.0F;
    if (i != 0) {
      if (i <= 0)
        f = 0.0F; 
      E(f);
      return;
    } 
    if (paramFloat1 != 0.0F && paramFloat1 != 1.0F) {
      if (paramFloat1 <= 0.5F)
        f = 0.0F; 
      E(f);
    } 
  }
  
  public void M(int paramInt1, int paramInt2, int paramInt3) {
    setState(e.b);
    this.D = paramInt1;
    this.C = -1;
    this.E = -1;
    androidx.constraintlayout.widget.c c1 = this.k;
    if (c1 != null)
      c1.d(paramInt1, paramInt2, paramInt3); 
  }
  
  public void N(int paramInt1, int paramInt2) {
    if (!isAttachedToWindow()) {
      if (this.s0 == null)
        this.s0 = new c(this); 
      this.s0.f(paramInt1);
      this.s0.d(paramInt2);
    } 
  }
  
  public void O() {
    E(1.0F);
    this.t0 = null;
  }
  
  public void P(int paramInt) {
    if (!isAttachedToWindow()) {
      if (this.s0 == null)
        this.s0 = new c(this); 
      this.s0.d(paramInt);
      return;
    } 
    Q(paramInt, -1, -1);
  }
  
  public void Q(int paramInt1, int paramInt2, int paramInt3) {
    R(paramInt1, paramInt2, paramInt3, -1);
  }
  
  public void R(int paramInt1, int paramInt2, int paramInt3, int paramInt4) {
    paramInt2 = this.D;
    if (paramInt2 == paramInt1)
      return; 
    if (this.C == paramInt1) {
      E(0.0F);
      if (paramInt4 > 0)
        this.I = paramInt4 / 1000.0F; 
      return;
    } 
    if (this.E == paramInt1) {
      E(1.0F);
      if (paramInt4 > 0)
        this.I = paramInt4 / 1000.0F; 
      return;
    } 
    this.E = paramInt1;
    if (paramInt2 != -1) {
      N(paramInt2, paramInt1);
      E(1.0F);
      this.K = 0.0F;
      O();
      if (paramInt4 > 0)
        this.I = paramInt4 / 1000.0F; 
      return;
    } 
    this.R = false;
    this.M = 1.0F;
    this.J = 0.0F;
    this.K = 0.0F;
    this.L = getNanoTime();
    this.H = getNanoTime();
    this.N = false;
    this.z = null;
    if (paramInt4 == -1)
      throw null; 
    this.C = -1;
    throw null;
  }
  
  public void S(int paramInt, View... paramVarArgs) {
    Log.e("MotionLayout", " no motionScene");
  }
  
  protected void dispatchDraw(Canvas paramCanvas) {
    ArrayList<h> arrayList = this.j0;
    if (arrayList != null) {
      Iterator<h> iterator = arrayList.iterator();
      while (iterator.hasNext())
        ((h)iterator.next()).x(paramCanvas); 
    } 
    F(false);
    super.dispatchDraw(paramCanvas);
  }
  
  public void e(View paramView, int paramInt1, int paramInt2, int paramInt3, int paramInt4, int paramInt5, int[] paramArrayOfint) {
    if (this.U || paramInt1 != 0 || paramInt2 != 0) {
      paramArrayOfint[0] = paramArrayOfint[0] + paramInt3;
      paramArrayOfint[1] = paramArrayOfint[1] + paramInt4;
    } 
    this.U = false;
  }
  
  public int[] getConstraintSetIds() {
    return null;
  }
  
  public int getCurrentState() {
    return this.D;
  }
  
  public ArrayList<l.a> getDefinedTransitions() {
    return null;
  }
  
  public b getDesignTool() {
    if (this.T == null)
      this.T = new b(this); 
    return this.T;
  }
  
  public int getEndState() {
    return this.E;
  }
  
  protected long getNanoTime() {
    return System.nanoTime();
  }
  
  public float getProgress() {
    return this.K;
  }
  
  public l getScene() {
    return null;
  }
  
  public int getStartState() {
    return this.C;
  }
  
  public float getTargetPosition() {
    return this.M;
  }
  
  public Bundle getTransitionState() {
    if (this.s0 == null)
      this.s0 = new c(this); 
    this.s0.c();
    return this.s0.b();
  }
  
  public long getTransitionTimeMs() {
    return (long)(this.I * 1000.0F);
  }
  
  public float getVelocity() {
    return this.B;
  }
  
  public boolean isAttachedToWindow() {
    return super.isAttachedToWindow();
  }
  
  public void k(View paramView, int paramInt1, int paramInt2, int paramInt3, int paramInt4, int paramInt5) {}
  
  public boolean l(View paramView1, View paramView2, int paramInt1, int paramInt2) {
    return false;
  }
  
  public void m(View paramView1, View paramView2, int paramInt1, int paramInt2) {
    this.e0 = getNanoTime();
    this.f0 = 0.0F;
    this.V = 0.0F;
    this.W = 0.0F;
  }
  
  public void n(View paramView, int paramInt) {}
  
  public void o(View paramView, int paramInt1, int paramInt2, int[] paramArrayOfint, int paramInt3) {}
  
  protected void onAttachedToWindow() {
    super.onAttachedToWindow();
    Display display = getDisplay();
    if (display != null)
      this.w0 = display.getRotation(); 
    J();
    c c1 = this.s0;
    if (c1 != null) {
      if (this.x0) {
        post(new a(this));
        return;
      } 
      c1.a();
    } 
  }
  
  public boolean onInterceptTouchEvent(MotionEvent paramMotionEvent) {
    return false;
  }
  
  protected void onLayout(boolean paramBoolean, int paramInt1, int paramInt2, int paramInt3, int paramInt4) {
    this.r0 = true;
    try {
      super.onLayout(paramBoolean, paramInt1, paramInt2, paramInt3, paramInt4);
      return;
    } finally {
      this.r0 = false;
    } 
  }
  
  protected void onMeasure(int paramInt1, int paramInt2) {
    super.onMeasure(paramInt1, paramInt2);
  }
  
  public boolean onNestedFling(View paramView, float paramFloat1, float paramFloat2, boolean paramBoolean) {
    return false;
  }
  
  public boolean onNestedPreFling(View paramView, float paramFloat1, float paramFloat2) {
    return false;
  }
  
  public void onRtlPropertiesChanged(int paramInt) {}
  
  public boolean onTouchEvent(MotionEvent paramMotionEvent) {
    return super.onTouchEvent(paramMotionEvent);
  }
  
  public void onViewAdded(View paramView) {
    super.onViewAdded(paramView);
    if (paramView instanceof h) {
      h h = (h)paramView;
      if (this.k0 == null)
        this.k0 = new CopyOnWriteArrayList<d>(); 
      this.k0.add(h);
      if (h.w()) {
        if (this.h0 == null)
          this.h0 = new ArrayList<h>(); 
        this.h0.add(h);
      } 
      if (h.v()) {
        if (this.i0 == null)
          this.i0 = new ArrayList<h>(); 
        this.i0.add(h);
      } 
      if (h.u()) {
        if (this.j0 == null)
          this.j0 = new ArrayList<h>(); 
        this.j0.add(h);
      } 
    } 
  }
  
  public void onViewRemoved(View paramView) {
    super.onViewRemoved(paramView);
    ArrayList<h> arrayList = this.h0;
    if (arrayList != null)
      arrayList.remove(paramView); 
    arrayList = this.i0;
    if (arrayList != null)
      arrayList.remove(paramView); 
  }
  
  public void requestLayout() {
    if (!this.o0)
      int i = this.D; 
    super.requestLayout();
  }
  
  public void setDebugMode(int paramInt) {
    this.Q = paramInt;
    invalidate();
  }
  
  public void setDelayedApplicationOfInitialState(boolean paramBoolean) {
    this.x0 = paramBoolean;
  }
  
  public void setInteractionEnabled(boolean paramBoolean) {
    this.F = paramBoolean;
  }
  
  public void setInterpolatedProgress(float paramFloat) {
    setProgress(paramFloat);
  }
  
  public void setOnHide(float paramFloat) {
    ArrayList<h> arrayList = this.i0;
    if (arrayList != null) {
      int k = arrayList.size();
      for (int i = 0; i < k; i++)
        ((h)this.i0.get(i)).setProgress(paramFloat); 
    } 
  }
  
  public void setOnShow(float paramFloat) {
    ArrayList<h> arrayList = this.h0;
    if (arrayList != null) {
      int k = arrayList.size();
      for (int i = 0; i < k; i++)
        ((h)this.h0.get(i)).setProgress(paramFloat); 
    } 
  }
  
  public void setProgress(float paramFloat) {
    int i = paramFloat cmp 0.0F;
    if (i < 0 || paramFloat > 1.0F)
      Log.w("MotionLayout", "Warning! Progress is defined for values between 0.0 and 1.0 inclusive"); 
    if (!isAttachedToWindow()) {
      if (this.s0 == null)
        this.s0 = new c(this); 
      this.s0.e(paramFloat);
      return;
    } 
    if (i <= 0) {
      if (this.K == 1.0F && this.D == this.E)
        setState(e.c); 
      this.D = this.C;
      if (this.K == 0.0F) {
        setState(e.d);
        return;
      } 
    } else if (paramFloat >= 1.0F) {
      if (this.K == 0.0F && this.D == this.C)
        setState(e.c); 
      this.D = this.E;
      if (this.K == 1.0F) {
        setState(e.d);
        return;
      } 
    } else {
      this.D = -1;
      setState(e.c);
    } 
  }
  
  public void setScene(l paraml) {
    r();
    throw null;
  }
  
  void setStartState(int paramInt) {
    if (!isAttachedToWindow()) {
      if (this.s0 == null)
        this.s0 = new c(this); 
      this.s0.f(paramInt);
      this.s0.d(paramInt);
      return;
    } 
    this.D = paramInt;
  }
  
  void setState(e parame) {
    e e1 = e.d;
    if (parame == e1 && this.D == -1)
      return; 
    e e2 = this.y0;
    this.y0 = parame;
    e e3 = e.c;
    if (e2 == e3 && parame == e3)
      G(); 
    int i = b.a[e2.ordinal()];
    if (i != 1 && i != 2) {
      if (i != 3)
        return; 
      if (parame == e1) {
        H();
        return;
      } 
    } else {
      if (parame == e3)
        G(); 
      if (parame == e1)
        H(); 
    } 
  }
  
  public void setTransition(int paramInt) {}
  
  protected void setTransition(l.a parama) {
    throw null;
  }
  
  public void setTransitionDuration(int paramInt) {
    Log.e("MotionLayout", "MotionScene not defined");
  }
  
  public void setTransitionListener(d paramd) {
    this.P = paramd;
  }
  
  public void setTransitionState(Bundle paramBundle) {
    if (this.s0 == null)
      this.s0 = new c(this); 
    this.s0.g(paramBundle);
    if (isAttachedToWindow())
      this.s0.a(); 
  }
  
  protected void t(int paramInt) {
    this.k = null;
  }
  
  public String toString() {
    Context context = getContext();
    StringBuilder stringBuilder = new StringBuilder();
    stringBuilder.append(a.a(context, this.C));
    stringBuilder.append("->");
    stringBuilder.append(a.a(context, this.E));
    stringBuilder.append(" (pos:");
    stringBuilder.append(this.K);
    stringBuilder.append(" Dpos/Dt:");
    stringBuilder.append(this.B);
    return stringBuilder.toString();
  }
  
  class a implements Runnable {
    a(j this$0) {}
    
    public void run() {
      j.B(this.a).a();
    }
  }
  
  class c {
    float a = Float.NaN;
    
    float b = Float.NaN;
    
    int c = -1;
    
    int d = -1;
    
    final String e = "motion.progress";
    
    final String f = "motion.velocity";
    
    final String g = "motion.StartState";
    
    final String h = "motion.EndState";
    
    c(j this$0) {}
    
    void a() {
      int i = this.c;
      if (i != -1 || this.d != -1) {
        if (i == -1) {
          this.i.P(this.d);
        } else {
          int k = this.d;
          if (k == -1) {
            this.i.M(i, -1, -1);
          } else {
            this.i.N(i, k);
          } 
        } 
        this.i.setState(j.e.b);
      } 
      if (Float.isNaN(this.b)) {
        if (Float.isNaN(this.a))
          return; 
        this.i.setProgress(this.a);
        return;
      } 
      this.i.L(this.a, this.b);
      this.a = Float.NaN;
      this.b = Float.NaN;
      this.c = -1;
      this.d = -1;
    }
    
    public Bundle b() {
      Bundle bundle = new Bundle();
      bundle.putFloat("motion.progress", this.a);
      bundle.putFloat("motion.velocity", this.b);
      bundle.putInt("motion.StartState", this.c);
      bundle.putInt("motion.EndState", this.d);
      return bundle;
    }
    
    public void c() {
      this.d = j.C(this.i);
      this.c = j.D(this.i);
      this.b = this.i.getVelocity();
      this.a = this.i.getProgress();
    }
    
    public void d(int param1Int) {
      this.d = param1Int;
    }
    
    public void e(float param1Float) {
      this.a = param1Float;
    }
    
    public void f(int param1Int) {
      this.c = param1Int;
    }
    
    public void g(Bundle param1Bundle) {
      this.a = param1Bundle.getFloat("motion.progress");
      this.b = param1Bundle.getFloat("motion.velocity");
      this.c = param1Bundle.getInt("motion.StartState");
      this.d = param1Bundle.getInt("motion.EndState");
    }
    
    public void h(float param1Float) {
      this.b = param1Float;
    }
  }
  
  public static interface d {
    void a(j param1j, int param1Int1, int param1Int2, float param1Float);
    
    void b(j param1j, int param1Int1, int param1Int2);
    
    void c(j param1j, int param1Int, boolean param1Boolean, float param1Float);
    
    void d(j param1j, int param1Int);
  }
  
  enum e {
    a, b, c, d;
  }
}


/* Location:              C:\soft\dex2jar-2.0\Cricket Scorer-dex2jar.jar!\androidx\constraintlayout\motion\widget\j.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */