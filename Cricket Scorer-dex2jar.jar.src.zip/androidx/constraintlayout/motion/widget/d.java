package androidx.constraintlayout.motion.widget;

import androidx.constraintlayout.widget.a;
import java.util.HashMap;

public abstract class d {
  public static int f = -1;
  
  int a;
  
  int b;
  
  String c;
  
  protected int d;
  
  HashMap<String, a> e;
  
  public d() {
    int i = f;
    this.a = i;
    this.b = i;
    this.c = null;
  }
  
  public abstract d a();
  
  public d b(d paramd) {
    this.a = paramd.a;
    this.b = paramd.b;
    this.c = paramd.c;
    this.d = paramd.d;
    this.e = paramd.e;
    return this;
  }
}


/* Location:              C:\soft\dex2jar-2.0\Cricket Scorer-dex2jar.jar!\androidx\constraintlayout\motion\widget\d.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */