package androidx.constraintlayout.motion.widget;

import androidx.constraintlayout.widget.a;
import java.util.LinkedHashMap;

class f implements Comparable<f> {
  static String[] y = new String[] { "position", "x", "y", "width", "height", "pathRotate" };
  
  private float a = 1.0F;
  
  int b = 0;
  
  int c;
  
  private boolean d = false;
  
  private float e = 0.0F;
  
  private float f = 0.0F;
  
  private float g = 0.0F;
  
  public float h = 0.0F;
  
  private float i = 1.0F;
  
  private float j = 1.0F;
  
  private float k = Float.NaN;
  
  private float l = Float.NaN;
  
  private float m = 0.0F;
  
  private float n = 0.0F;
  
  private float o = 0.0F;
  
  private int p = 0;
  
  private float q;
  
  private float r = Float.NaN;
  
  private float s = Float.NaN;
  
  private int t = -1;
  
  LinkedHashMap<String, a> u = new LinkedHashMap<String, a>();
  
  int v = 0;
  
  double[] w = new double[18];
  
  double[] x = new double[18];
  
  public int a(f paramf) {
    return Float.compare(this.q, paramf.q);
  }
}


/* Location:              C:\soft\dex2jar-2.0\Cricket Scorer-dex2jar.jar!\androidx\constraintlayout\motion\widget\f.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */