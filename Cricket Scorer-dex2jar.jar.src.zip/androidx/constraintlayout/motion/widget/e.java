package androidx.constraintlayout.motion.widget;

import android.graphics.RectF;
import android.view.View;
import androidx.constraintlayout.widget.a;
import java.lang.reflect.Method;
import java.util.HashMap;
import java.util.Locale;

public class e extends d {
  HashMap<String, Method> A;
  
  private int g = -1;
  
  private String h = null;
  
  private int i;
  
  private String j;
  
  private String k;
  
  private int l;
  
  private int m;
  
  private View n;
  
  float o;
  
  private boolean p;
  
  private boolean q;
  
  private boolean r;
  
  private float s;
  
  private float t;
  
  private boolean u;
  
  int v;
  
  int w;
  
  int x;
  
  RectF y;
  
  RectF z;
  
  public e() {
    int i = d.f;
    this.i = i;
    this.j = null;
    this.k = null;
    this.l = i;
    this.m = i;
    this.n = null;
    this.o = 0.1F;
    this.p = true;
    this.q = true;
    this.r = true;
    this.s = Float.NaN;
    this.u = false;
    this.v = i;
    this.w = i;
    this.x = i;
    this.y = new RectF();
    this.z = new RectF();
    this.A = new HashMap<String, Method>();
    this.d = 5;
    this.e = new HashMap<String, a>();
  }
  
  private void d(String paramString, View paramView) {
    // Byte code:
    //   0: aload_1
    //   1: ifnonnull -> 5
    //   4: return
    //   5: aload_1
    //   6: ldc '.'
    //   8: invokevirtual startsWith : (Ljava/lang/String;)Z
    //   11: ifeq -> 21
    //   14: aload_0
    //   15: aload_1
    //   16: aload_2
    //   17: invokespecial e : (Ljava/lang/String;Landroid/view/View;)V
    //   20: return
    //   21: aload_0
    //   22: getfield A : Ljava/util/HashMap;
    //   25: aload_1
    //   26: invokevirtual containsKey : (Ljava/lang/Object;)Z
    //   29: ifeq -> 54
    //   32: aload_0
    //   33: getfield A : Ljava/util/HashMap;
    //   36: aload_1
    //   37: invokevirtual get : (Ljava/lang/Object;)Ljava/lang/Object;
    //   40: checkcast java/lang/reflect/Method
    //   43: astore #4
    //   45: aload #4
    //   47: astore_3
    //   48: aload #4
    //   50: ifnonnull -> 56
    //   53: return
    //   54: aconst_null
    //   55: astore_3
    //   56: aload_3
    //   57: astore #4
    //   59: aload_3
    //   60: ifnonnull -> 168
    //   63: aload_2
    //   64: invokevirtual getClass : ()Ljava/lang/Class;
    //   67: aload_1
    //   68: iconst_0
    //   69: anewarray java/lang/Class
    //   72: invokevirtual getMethod : (Ljava/lang/String;[Ljava/lang/Class;)Ljava/lang/reflect/Method;
    //   75: astore #4
    //   77: aload_0
    //   78: getfield A : Ljava/util/HashMap;
    //   81: aload_1
    //   82: aload #4
    //   84: invokevirtual put : (Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    //   87: pop
    //   88: goto -> 168
    //   91: aload_0
    //   92: getfield A : Ljava/util/HashMap;
    //   95: aload_1
    //   96: aconst_null
    //   97: invokevirtual put : (Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    //   100: pop
    //   101: new java/lang/StringBuilder
    //   104: dup
    //   105: invokespecial <init> : ()V
    //   108: astore_3
    //   109: aload_3
    //   110: ldc 'Could not find method "'
    //   112: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   115: pop
    //   116: aload_3
    //   117: aload_1
    //   118: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   121: pop
    //   122: aload_3
    //   123: ldc '"on class '
    //   125: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   128: pop
    //   129: aload_3
    //   130: aload_2
    //   131: invokevirtual getClass : ()Ljava/lang/Class;
    //   134: invokevirtual getSimpleName : ()Ljava/lang/String;
    //   137: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   140: pop
    //   141: aload_3
    //   142: ldc ' '
    //   144: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   147: pop
    //   148: aload_3
    //   149: aload_2
    //   150: invokestatic b : (Landroid/view/View;)Ljava/lang/String;
    //   153: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   156: pop
    //   157: ldc 'KeyTrigger'
    //   159: aload_3
    //   160: invokevirtual toString : ()Ljava/lang/String;
    //   163: invokestatic e : (Ljava/lang/String;Ljava/lang/String;)I
    //   166: pop
    //   167: return
    //   168: aload #4
    //   170: aload_2
    //   171: iconst_0
    //   172: anewarray java/lang/Object
    //   175: invokevirtual invoke : (Ljava/lang/Object;[Ljava/lang/Object;)Ljava/lang/Object;
    //   178: pop
    //   179: return
    //   180: new java/lang/StringBuilder
    //   183: dup
    //   184: invokespecial <init> : ()V
    //   187: astore_1
    //   188: aload_1
    //   189: ldc 'Exception in call "'
    //   191: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   194: pop
    //   195: aload_1
    //   196: aload_0
    //   197: getfield h : Ljava/lang/String;
    //   200: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   203: pop
    //   204: aload_1
    //   205: ldc '"on class '
    //   207: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   210: pop
    //   211: aload_1
    //   212: aload_2
    //   213: invokevirtual getClass : ()Ljava/lang/Class;
    //   216: invokevirtual getSimpleName : ()Ljava/lang/String;
    //   219: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   222: pop
    //   223: aload_1
    //   224: ldc ' '
    //   226: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   229: pop
    //   230: aload_1
    //   231: aload_2
    //   232: invokestatic b : (Landroid/view/View;)Ljava/lang/String;
    //   235: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   238: pop
    //   239: ldc 'KeyTrigger'
    //   241: aload_1
    //   242: invokevirtual toString : ()Ljava/lang/String;
    //   245: invokestatic e : (Ljava/lang/String;Ljava/lang/String;)I
    //   248: pop
    //   249: return
    //   250: astore_3
    //   251: goto -> 91
    //   254: astore_1
    //   255: goto -> 180
    // Exception table:
    //   from	to	target	type
    //   63	88	250	java/lang/NoSuchMethodException
    //   168	179	254	java/lang/Exception
  }
  
  private void e(String paramString, View paramView) {
    boolean bool;
    if (paramString.length() == 1) {
      bool = true;
    } else {
      bool = false;
    } 
    String str = paramString;
    if (!bool)
      str = paramString.substring(1).toLowerCase(Locale.ROOT); 
    for (String str1 : this.e.keySet()) {
      String str2 = str1.toLowerCase(Locale.ROOT);
      if (bool || str2.matches(str)) {
        a a = this.e.get(str1);
        if (a != null)
          a.a(paramView); 
      } 
    } 
  }
  
  private void f(RectF paramRectF, View paramView, boolean paramBoolean) {
    paramRectF.top = paramView.getTop();
    paramRectF.bottom = paramView.getBottom();
    paramRectF.left = paramView.getLeft();
    paramRectF.right = paramView.getRight();
    if (paramBoolean)
      paramView.getMatrix().mapRect(paramRectF); 
  }
  
  public d a() {
    return (new e()).b(this);
  }
  
  public d b(d paramd) {
    super.b(paramd);
    paramd = paramd;
    this.g = ((e)paramd).g;
    this.h = ((e)paramd).h;
    this.i = ((e)paramd).i;
    this.j = ((e)paramd).j;
    this.k = ((e)paramd).k;
    this.l = ((e)paramd).l;
    this.m = ((e)paramd).m;
    this.n = ((e)paramd).n;
    this.o = ((e)paramd).o;
    this.p = ((e)paramd).p;
    this.q = ((e)paramd).q;
    this.r = ((e)paramd).r;
    this.s = ((e)paramd).s;
    this.t = ((e)paramd).t;
    this.u = ((e)paramd).u;
    this.y = ((e)paramd).y;
    this.z = ((e)paramd).z;
    this.A = ((e)paramd).A;
    return this;
  }
  
  public void c(float paramFloat, View paramView) {
    // Byte code:
    //   0: aload_0
    //   1: getfield m : I
    //   4: getstatic androidx/constraintlayout/motion/widget/d.f : I
    //   7: if_icmpeq -> 181
    //   10: aload_0
    //   11: getfield n : Landroid/view/View;
    //   14: ifnonnull -> 35
    //   17: aload_0
    //   18: aload_2
    //   19: invokevirtual getParent : ()Landroid/view/ViewParent;
    //   22: checkcast android/view/ViewGroup
    //   25: aload_0
    //   26: getfield m : I
    //   29: invokevirtual findViewById : (I)Landroid/view/View;
    //   32: putfield n : Landroid/view/View;
    //   35: aload_0
    //   36: aload_0
    //   37: getfield y : Landroid/graphics/RectF;
    //   40: aload_0
    //   41: getfield n : Landroid/view/View;
    //   44: aload_0
    //   45: getfield u : Z
    //   48: invokespecial f : (Landroid/graphics/RectF;Landroid/view/View;Z)V
    //   51: aload_0
    //   52: aload_0
    //   53: getfield z : Landroid/graphics/RectF;
    //   56: aload_2
    //   57: aload_0
    //   58: getfield u : Z
    //   61: invokespecial f : (Landroid/graphics/RectF;Landroid/view/View;Z)V
    //   64: aload_0
    //   65: getfield y : Landroid/graphics/RectF;
    //   68: aload_0
    //   69: getfield z : Landroid/graphics/RectF;
    //   72: invokevirtual intersect : (Landroid/graphics/RectF;)Z
    //   75: ifeq -> 131
    //   78: aload_0
    //   79: getfield p : Z
    //   82: ifeq -> 96
    //   85: aload_0
    //   86: iconst_0
    //   87: putfield p : Z
    //   90: iconst_1
    //   91: istore #5
    //   93: goto -> 99
    //   96: iconst_0
    //   97: istore #5
    //   99: aload_0
    //   100: getfield r : Z
    //   103: ifeq -> 117
    //   106: aload_0
    //   107: iconst_0
    //   108: putfield r : Z
    //   111: iconst_1
    //   112: istore #7
    //   114: goto -> 120
    //   117: iconst_0
    //   118: istore #7
    //   120: aload_0
    //   121: iconst_1
    //   122: putfield q : Z
    //   125: iconst_0
    //   126: istore #6
    //   128: goto -> 398
    //   131: aload_0
    //   132: getfield p : Z
    //   135: ifne -> 149
    //   138: aload_0
    //   139: iconst_1
    //   140: putfield p : Z
    //   143: iconst_1
    //   144: istore #5
    //   146: goto -> 152
    //   149: iconst_0
    //   150: istore #5
    //   152: aload_0
    //   153: getfield q : Z
    //   156: ifeq -> 170
    //   159: aload_0
    //   160: iconst_0
    //   161: putfield q : Z
    //   164: iconst_1
    //   165: istore #6
    //   167: goto -> 173
    //   170: iconst_0
    //   171: istore #6
    //   173: aload_0
    //   174: iconst_1
    //   175: putfield r : Z
    //   178: goto -> 395
    //   181: aload_0
    //   182: getfield p : Z
    //   185: ifeq -> 219
    //   188: aload_0
    //   189: getfield s : F
    //   192: fstore_3
    //   193: fload_1
    //   194: fload_3
    //   195: fsub
    //   196: aload_0
    //   197: getfield t : F
    //   200: fload_3
    //   201: fsub
    //   202: fmul
    //   203: fconst_0
    //   204: fcmpg
    //   205: ifge -> 241
    //   208: aload_0
    //   209: iconst_0
    //   210: putfield p : Z
    //   213: iconst_1
    //   214: istore #5
    //   216: goto -> 244
    //   219: fload_1
    //   220: aload_0
    //   221: getfield s : F
    //   224: fsub
    //   225: invokestatic abs : (F)F
    //   228: aload_0
    //   229: getfield o : F
    //   232: fcmpl
    //   233: ifle -> 241
    //   236: aload_0
    //   237: iconst_1
    //   238: putfield p : Z
    //   241: iconst_0
    //   242: istore #5
    //   244: aload_0
    //   245: getfield q : Z
    //   248: ifeq -> 293
    //   251: aload_0
    //   252: getfield s : F
    //   255: fstore_3
    //   256: fload_1
    //   257: fload_3
    //   258: fsub
    //   259: fstore #4
    //   261: aload_0
    //   262: getfield t : F
    //   265: fload_3
    //   266: fsub
    //   267: fload #4
    //   269: fmul
    //   270: fconst_0
    //   271: fcmpg
    //   272: ifge -> 315
    //   275: fload #4
    //   277: fconst_0
    //   278: fcmpg
    //   279: ifge -> 315
    //   282: aload_0
    //   283: iconst_0
    //   284: putfield q : Z
    //   287: iconst_1
    //   288: istore #6
    //   290: goto -> 318
    //   293: fload_1
    //   294: aload_0
    //   295: getfield s : F
    //   298: fsub
    //   299: invokestatic abs : (F)F
    //   302: aload_0
    //   303: getfield o : F
    //   306: fcmpl
    //   307: ifle -> 315
    //   310: aload_0
    //   311: iconst_1
    //   312: putfield q : Z
    //   315: iconst_0
    //   316: istore #6
    //   318: aload_0
    //   319: getfield r : Z
    //   322: ifeq -> 373
    //   325: aload_0
    //   326: getfield s : F
    //   329: fstore_3
    //   330: fload_1
    //   331: fload_3
    //   332: fsub
    //   333: fstore #4
    //   335: aload_0
    //   336: getfield t : F
    //   339: fload_3
    //   340: fsub
    //   341: fload #4
    //   343: fmul
    //   344: fconst_0
    //   345: fcmpg
    //   346: ifge -> 367
    //   349: fload #4
    //   351: fconst_0
    //   352: fcmpl
    //   353: ifle -> 367
    //   356: aload_0
    //   357: iconst_0
    //   358: putfield r : Z
    //   361: iconst_1
    //   362: istore #7
    //   364: goto -> 370
    //   367: iconst_0
    //   368: istore #7
    //   370: goto -> 398
    //   373: fload_1
    //   374: aload_0
    //   375: getfield s : F
    //   378: fsub
    //   379: invokestatic abs : (F)F
    //   382: aload_0
    //   383: getfield o : F
    //   386: fcmpl
    //   387: ifle -> 395
    //   390: aload_0
    //   391: iconst_1
    //   392: putfield r : Z
    //   395: iconst_0
    //   396: istore #7
    //   398: aload_0
    //   399: fload_1
    //   400: putfield t : F
    //   403: iload #6
    //   405: ifne -> 418
    //   408: iload #5
    //   410: ifne -> 418
    //   413: iload #7
    //   415: ifeq -> 435
    //   418: aload_2
    //   419: invokevirtual getParent : ()Landroid/view/ViewParent;
    //   422: checkcast androidx/constraintlayout/motion/widget/j
    //   425: aload_0
    //   426: getfield l : I
    //   429: iload #7
    //   431: fload_1
    //   432: invokevirtual I : (IZF)V
    //   435: aload_0
    //   436: getfield i : I
    //   439: getstatic androidx/constraintlayout/motion/widget/d.f : I
    //   442: if_icmpne -> 451
    //   445: aload_2
    //   446: astore #8
    //   448: goto -> 467
    //   451: aload_2
    //   452: invokevirtual getParent : ()Landroid/view/ViewParent;
    //   455: checkcast androidx/constraintlayout/motion/widget/j
    //   458: aload_0
    //   459: getfield i : I
    //   462: invokevirtual findViewById : (I)Landroid/view/View;
    //   465: astore #8
    //   467: iload #6
    //   469: ifeq -> 524
    //   472: aload_0
    //   473: getfield j : Ljava/lang/String;
    //   476: astore #9
    //   478: aload #9
    //   480: ifnull -> 491
    //   483: aload_0
    //   484: aload #9
    //   486: aload #8
    //   488: invokespecial d : (Ljava/lang/String;Landroid/view/View;)V
    //   491: aload_0
    //   492: getfield v : I
    //   495: getstatic androidx/constraintlayout/motion/widget/d.f : I
    //   498: if_icmpeq -> 524
    //   501: aload_2
    //   502: invokevirtual getParent : ()Landroid/view/ViewParent;
    //   505: checkcast androidx/constraintlayout/motion/widget/j
    //   508: aload_0
    //   509: getfield v : I
    //   512: iconst_1
    //   513: anewarray android/view/View
    //   516: dup
    //   517: iconst_0
    //   518: aload #8
    //   520: aastore
    //   521: invokevirtual S : (I[Landroid/view/View;)V
    //   524: iload #7
    //   526: ifeq -> 581
    //   529: aload_0
    //   530: getfield k : Ljava/lang/String;
    //   533: astore #9
    //   535: aload #9
    //   537: ifnull -> 548
    //   540: aload_0
    //   541: aload #9
    //   543: aload #8
    //   545: invokespecial d : (Ljava/lang/String;Landroid/view/View;)V
    //   548: aload_0
    //   549: getfield w : I
    //   552: getstatic androidx/constraintlayout/motion/widget/d.f : I
    //   555: if_icmpeq -> 581
    //   558: aload_2
    //   559: invokevirtual getParent : ()Landroid/view/ViewParent;
    //   562: checkcast androidx/constraintlayout/motion/widget/j
    //   565: aload_0
    //   566: getfield w : I
    //   569: iconst_1
    //   570: anewarray android/view/View
    //   573: dup
    //   574: iconst_0
    //   575: aload #8
    //   577: aastore
    //   578: invokevirtual S : (I[Landroid/view/View;)V
    //   581: iload #5
    //   583: ifeq -> 638
    //   586: aload_0
    //   587: getfield h : Ljava/lang/String;
    //   590: astore #9
    //   592: aload #9
    //   594: ifnull -> 605
    //   597: aload_0
    //   598: aload #9
    //   600: aload #8
    //   602: invokespecial d : (Ljava/lang/String;Landroid/view/View;)V
    //   605: aload_0
    //   606: getfield x : I
    //   609: getstatic androidx/constraintlayout/motion/widget/d.f : I
    //   612: if_icmpeq -> 638
    //   615: aload_2
    //   616: invokevirtual getParent : ()Landroid/view/ViewParent;
    //   619: checkcast androidx/constraintlayout/motion/widget/j
    //   622: aload_0
    //   623: getfield x : I
    //   626: iconst_1
    //   627: anewarray android/view/View
    //   630: dup
    //   631: iconst_0
    //   632: aload #8
    //   634: aastore
    //   635: invokevirtual S : (I[Landroid/view/View;)V
    //   638: return
  }
}


/* Location:              C:\soft\dex2jar-2.0\Cricket Scorer-dex2jar.jar!\androidx\constraintlayout\motion\widget\e.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */