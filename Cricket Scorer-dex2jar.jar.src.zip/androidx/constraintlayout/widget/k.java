package androidx.constraintlayout.widget;

import android.content.res.TypedArray;
import android.util.AttributeSet;
import android.view.View;
import android.view.ViewParent;
import p.l;

public abstract class k extends b {
  private boolean j;
  
  private boolean k;
  
  protected void j(ConstraintLayout paramConstraintLayout) {
    i(paramConstraintLayout);
  }
  
  protected void n(AttributeSet paramAttributeSet) {
    super.n(paramAttributeSet);
    if (paramAttributeSet != null) {
      TypedArray typedArray = getContext().obtainStyledAttributes(paramAttributeSet, i.n1);
      int j = typedArray.getIndexCount();
      for (int i = 0; i < j; i++) {
        int m = typedArray.getIndex(i);
        if (m == i.p1) {
          this.j = true;
        } else if (m == i.u1) {
          this.k = true;
        } 
      } 
      typedArray.recycle();
    } 
  }
  
  public void onAttachedToWindow() {
    super.onAttachedToWindow();
    if (this.j || this.k) {
      ViewParent viewParent = getParent();
      if (viewParent instanceof ConstraintLayout) {
        ConstraintLayout constraintLayout = (ConstraintLayout)viewParent;
        int j = getVisibility();
        float f = getElevation();
        for (int i = 0; i < this.b; i++) {
          View view = constraintLayout.j(this.a[i]);
          if (view != null) {
            if (this.j)
              view.setVisibility(j); 
            if (this.k && f > 0.0F)
              view.setTranslationZ(view.getTranslationZ() + f); 
          } 
        } 
      } 
    } 
  }
  
  public void setElevation(float paramFloat) {
    super.setElevation(paramFloat);
    h();
  }
  
  public void setVisibility(int paramInt) {
    super.setVisibility(paramInt);
    h();
  }
  
  public void u(l paraml, int paramInt1, int paramInt2) {}
}


/* Location:              C:\soft\dex2jar-2.0\Cricket Scorer-dex2jar.jar!\androidx\constraintlayout\widget\k.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */