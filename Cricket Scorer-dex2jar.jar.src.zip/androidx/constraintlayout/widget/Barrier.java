package androidx.constraintlayout.widget;

import android.content.Context;
import android.content.res.TypedArray;
import android.util.AttributeSet;
import p.a;
import p.e;
import p.i;

public class Barrier extends b {
  private int j;
  
  private int k;
  
  private a l;
  
  public Barrier(Context paramContext) {
    super(paramContext);
    setVisibility(8);
  }
  
  public Barrier(Context paramContext, AttributeSet paramAttributeSet) {
    super(paramContext, paramAttributeSet);
    setVisibility(8);
  }
  
  private void u(e parame, int paramInt, boolean paramBoolean) {
    this.k = paramInt;
    if (paramBoolean) {
      paramInt = this.j;
      if (paramInt == 5) {
        this.k = 1;
      } else if (paramInt == 6) {
        this.k = 0;
      } 
    } else {
      paramInt = this.j;
      if (paramInt == 5) {
        this.k = 0;
      } else if (paramInt == 6) {
        this.k = 1;
      } 
    } 
    if (parame instanceof a)
      ((a)parame).A1(this.k); 
  }
  
  public boolean getAllowsGoneWidget() {
    return this.l.u1();
  }
  
  public int getMargin() {
    return this.l.w1();
  }
  
  public int getType() {
    return this.j;
  }
  
  protected void n(AttributeSet paramAttributeSet) {
    super.n(paramAttributeSet);
    this.l = new a();
    if (paramAttributeSet != null) {
      TypedArray typedArray = getContext().obtainStyledAttributes(paramAttributeSet, i.n1);
      int j = typedArray.getIndexCount();
      for (int i = 0; i < j; i++) {
        int k = typedArray.getIndex(i);
        if (k == i.w1) {
          setType(typedArray.getInt(k, 0));
        } else if (k == i.v1) {
          this.l.z1(typedArray.getBoolean(k, true));
        } else if (k == i.x1) {
          k = typedArray.getDimensionPixelSize(k, 0);
          this.l.B1(k);
        } 
      } 
      typedArray.recycle();
    } 
    this.d = (i)this.l;
    t();
  }
  
  public void o(e parame, boolean paramBoolean) {
    u(parame, this.j, paramBoolean);
  }
  
  public void setAllowsGoneWidget(boolean paramBoolean) {
    this.l.z1(paramBoolean);
  }
  
  public void setDpMargin(int paramInt) {
    float f = (getResources().getDisplayMetrics()).density;
    paramInt = (int)(paramInt * f + 0.5F);
    this.l.B1(paramInt);
  }
  
  public void setMargin(int paramInt) {
    this.l.B1(paramInt);
  }
  
  public void setType(int paramInt) {
    this.j = paramInt;
  }
}


/* Location:              C:\soft\dex2jar-2.0\Cricket Scorer-dex2jar.jar!\androidx\constraintlayout\widget\Barrier.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */