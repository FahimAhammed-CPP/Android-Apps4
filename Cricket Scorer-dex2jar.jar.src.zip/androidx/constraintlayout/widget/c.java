package androidx.constraintlayout.widget;

import android.content.Context;
import android.content.res.TypedArray;
import android.content.res.XmlResourceParser;
import android.util.Log;
import android.util.SparseArray;
import android.util.Xml;
import java.io.IOException;
import java.util.ArrayList;
import org.xmlpull.v1.XmlPullParser;
import org.xmlpull.v1.XmlPullParserException;

public class c {
  private final ConstraintLayout a;
  
  d b;
  
  int c = -1;
  
  int d = -1;
  
  private SparseArray<a> e = new SparseArray();
  
  private SparseArray<d> f = new SparseArray();
  
  private f g = null;
  
  c(Context paramContext, ConstraintLayout paramConstraintLayout, int paramInt) {
    this.a = paramConstraintLayout;
    a(paramContext, paramInt);
  }
  
  private void a(Context paramContext, int paramInt) {
    XmlResourceParser xmlResourceParser = paramContext.getResources().getXml(paramInt);
    String str = null;
    try {
      paramInt = xmlResourceParser.getEventType();
    } catch (XmlPullParserException xmlPullParserException) {
      xmlPullParserException.printStackTrace();
      return;
    } catch (IOException iOException) {
      iOException.printStackTrace();
      return;
    } 
    while (true) {
      boolean bool = true;
      if (paramInt != 1) {
        String str1;
        if (paramInt != 0) {
          if (paramInt != 2) {
            str1 = str;
          } else {
            str1 = xmlResourceParser.getName();
            switch (str1.hashCode()) {
              case 1901439077:
                if (str1.equals("Variant")) {
                  paramInt = 3;
                  break;
                } 
              case 1657696882:
                if (str1.equals("layoutDescription")) {
                  paramInt = 0;
                  break;
                } 
              case 1382829617:
                if (str1.equals("StateSet")) {
                  paramInt = bool;
                  break;
                } 
              case 80204913:
                if (str1.equals("State")) {
                  paramInt = 2;
                  break;
                } 
              case -1349929691:
                if (str1.equals("ConstraintSet")) {
                  paramInt = 4;
                  break;
                } 
              default:
                paramInt = -1;
                break;
            } 
            if (paramInt != 2) {
              if (paramInt != 3) {
                if (paramInt != 4) {
                  str1 = str;
                } else {
                  b((Context)iOException, (XmlPullParser)xmlResourceParser);
                  str1 = str;
                } 
              } else {
                b b = new b((Context)iOException, (XmlPullParser)xmlResourceParser);
                str1 = str;
                if (str != null) {
                  str.a(b);
                  str1 = str;
                } 
              } 
            } else {
              a a = new a((Context)iOException, (XmlPullParser)xmlResourceParser);
              this.e.put(a.a, a);
            } 
          } 
        } else {
          xmlResourceParser.getName();
          str1 = str;
        } 
        paramInt = xmlResourceParser.next();
        str = str1;
        continue;
      } 
      return;
    } 
  }
  
  private void b(Context paramContext, XmlPullParser paramXmlPullParser) {
    d d1 = new d();
    int j = paramXmlPullParser.getAttributeCount();
    for (int i = 0; i < j; i++) {
      String str2 = paramXmlPullParser.getAttributeName(i);
      String str1 = paramXmlPullParser.getAttributeValue(i);
      if (str2 != null && str1 != null && "id".equals(str2)) {
        if (str1.contains("/")) {
          str2 = str1.substring(str1.indexOf('/') + 1);
          i = paramContext.getResources().getIdentifier(str2, "id", paramContext.getPackageName());
        } else {
          i = -1;
        } 
        j = i;
        if (i == -1)
          if (str1.length() > 1) {
            j = Integer.parseInt(str1.substring(1));
          } else {
            Log.e("ConstraintLayoutStates", "error in parsing id");
            j = i;
          }  
        d1.n(paramContext, paramXmlPullParser);
        this.f.put(j, d1);
        return;
      } 
    } 
  }
  
  public void c(f paramf) {
    this.g = paramf;
  }
  
  public void d(int paramInt, float paramFloat1, float paramFloat2) {
    int i = this.c;
    if (i == paramInt) {
      a a;
      d d1;
      if (paramInt == -1) {
        a = (a)this.e.valueAt(0);
      } else {
        a = (a)this.e.get(i);
      } 
      paramInt = this.d;
      if (paramInt != -1 && ((b)a.b.get(paramInt)).a(paramFloat1, paramFloat2))
        return; 
      i = a.b(paramFloat1, paramFloat2);
      if (this.d == i)
        return; 
      if (i == -1) {
        d1 = this.b;
      } else {
        d1 = ((b)a.b.get(i)).f;
      } 
      if (i == -1) {
        paramInt = a.c;
      } else {
        paramInt = ((b)a.b.get(i)).e;
      } 
      if (d1 == null)
        return; 
      this.d = i;
      f f1 = this.g;
      if (f1 != null)
        f1.b(-1, paramInt); 
      d1.c(this.a);
      f1 = this.g;
      if (f1 != null) {
        f1.a(-1, paramInt);
        return;
      } 
    } else {
      d d1;
      StringBuilder stringBuilder;
      this.c = paramInt;
      a a = (a)this.e.get(paramInt);
      int j = a.b(paramFloat1, paramFloat2);
      if (j == -1) {
        d1 = a.d;
      } else {
        d1 = ((b)a.b.get(j)).f;
      } 
      if (j == -1) {
        i = a.c;
      } else {
        i = ((b)a.b.get(j)).e;
      } 
      if (d1 == null) {
        stringBuilder = new StringBuilder();
        stringBuilder.append("NO Constraint set found ! id=");
        stringBuilder.append(paramInt);
        stringBuilder.append(", dim =");
        stringBuilder.append(paramFloat1);
        stringBuilder.append(", ");
        stringBuilder.append(paramFloat2);
        Log.v("ConstraintLayoutStates", stringBuilder.toString());
        return;
      } 
      this.d = j;
      f f2 = this.g;
      if (f2 != null)
        f2.b(paramInt, i); 
      stringBuilder.c(this.a);
      f f1 = this.g;
      if (f1 != null)
        f1.a(paramInt, i); 
    } 
  }
  
  static class a {
    int a;
    
    ArrayList<c.b> b = new ArrayList<c.b>();
    
    int c = -1;
    
    d d;
    
    public a(Context param1Context, XmlPullParser param1XmlPullParser) {
      TypedArray typedArray = param1Context.obtainStyledAttributes(Xml.asAttributeSet(param1XmlPullParser), i.U6);
      int j = typedArray.getIndexCount();
      for (int i = 0; i < j; i++) {
        int k = typedArray.getIndex(i);
        if (k == i.V6) {
          this.a = typedArray.getResourceId(k, this.a);
        } else if (k == i.W6) {
          this.c = typedArray.getResourceId(k, this.c);
          String str = param1Context.getResources().getResourceTypeName(this.c);
          param1Context.getResources().getResourceName(this.c);
          if ("layout".equals(str)) {
            d d1 = new d();
            this.d = d1;
            d1.f(param1Context, this.c);
          } 
        } 
      } 
      typedArray.recycle();
    }
    
    void a(c.b param1b) {
      this.b.add(param1b);
    }
    
    public int b(float param1Float1, float param1Float2) {
      for (int i = 0; i < this.b.size(); i++) {
        if (((c.b)this.b.get(i)).a(param1Float1, param1Float2))
          return i; 
      } 
      return -1;
    }
  }
  
  static class b {
    float a = Float.NaN;
    
    float b = Float.NaN;
    
    float c = Float.NaN;
    
    float d = Float.NaN;
    
    int e = -1;
    
    d f;
    
    public b(Context param1Context, XmlPullParser param1XmlPullParser) {
      TypedArray typedArray = param1Context.obtainStyledAttributes(Xml.asAttributeSet(param1XmlPullParser), i.s7);
      int j = typedArray.getIndexCount();
      for (int i = 0; i < j; i++) {
        int k = typedArray.getIndex(i);
        if (k == i.t7) {
          this.e = typedArray.getResourceId(k, this.e);
          String str = param1Context.getResources().getResourceTypeName(this.e);
          param1Context.getResources().getResourceName(this.e);
          if ("layout".equals(str)) {
            d d1 = new d();
            this.f = d1;
            d1.f(param1Context, this.e);
          } 
        } else if (k == i.u7) {
          this.d = typedArray.getDimension(k, this.d);
        } else if (k == i.v7) {
          this.b = typedArray.getDimension(k, this.b);
        } else if (k == i.w7) {
          this.c = typedArray.getDimension(k, this.c);
        } else if (k == i.x7) {
          this.a = typedArray.getDimension(k, this.a);
        } else {
          Log.v("ConstraintLayoutStates", "Unknown tag");
        } 
      } 
      typedArray.recycle();
    }
    
    boolean a(float param1Float1, float param1Float2) {
      return (!Float.isNaN(this.a) && param1Float1 < this.a) ? false : ((!Float.isNaN(this.b) && param1Float2 < this.b) ? false : ((!Float.isNaN(this.c) && param1Float1 > this.c) ? false : (!(!Float.isNaN(this.d) && param1Float2 > this.d))));
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Cricket Scorer-dex2jar.jar!\androidx\constraintlayout\widget\c.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */