package androidx.constraintlayout.widget;

import android.content.Context;
import android.content.res.Resources;
import android.content.res.TypedArray;
import android.graphics.Canvas;
import android.util.AttributeSet;
import android.util.Log;
import android.view.View;
import android.view.ViewGroup;
import android.view.ViewParent;
import java.util.Arrays;
import java.util.HashMap;
import p.e;
import p.i;

public abstract class b extends View {
  protected int[] a = new int[32];
  
  protected int b;
  
  protected Context c;
  
  protected i d;
  
  protected boolean e = false;
  
  protected String f;
  
  protected String g;
  
  private View[] h = null;
  
  protected HashMap<Integer, String> i = new HashMap<Integer, String>();
  
  public b(Context paramContext) {
    super(paramContext);
    this.c = paramContext;
    n(null);
  }
  
  public b(Context paramContext, AttributeSet paramAttributeSet) {
    super(paramContext, paramAttributeSet);
    this.c = paramContext;
    n(paramAttributeSet);
  }
  
  private void e(String paramString) {
    if (paramString != null) {
      if (paramString.length() == 0)
        return; 
      if (this.c == null)
        return; 
      paramString = paramString.trim();
      if (getParent() instanceof ConstraintLayout)
        ConstraintLayout constraintLayout = (ConstraintLayout)getParent(); 
      int j = l(paramString);
      if (j != 0) {
        this.i.put(Integer.valueOf(j), paramString);
        f(j);
        return;
      } 
      StringBuilder stringBuilder = new StringBuilder();
      stringBuilder.append("Could not find id of \"");
      stringBuilder.append(paramString);
      stringBuilder.append("\"");
      Log.w("ConstraintHelper", stringBuilder.toString());
    } 
  }
  
  private void f(int paramInt) {
    if (paramInt == getId())
      return; 
    int j = this.b;
    int[] arrayOfInt = this.a;
    if (j + 1 > arrayOfInt.length)
      this.a = Arrays.copyOf(arrayOfInt, arrayOfInt.length * 2); 
    arrayOfInt = this.a;
    j = this.b;
    arrayOfInt[j] = paramInt;
    this.b = j + 1;
  }
  
  private void g(String paramString) {
    if (paramString != null) {
      ConstraintLayout constraintLayout;
      if (paramString.length() == 0)
        return; 
      if (this.c == null)
        return; 
      String str = paramString.trim();
      paramString = null;
      if (getParent() instanceof ConstraintLayout)
        constraintLayout = (ConstraintLayout)getParent(); 
      if (constraintLayout == null) {
        Log.w("ConstraintHelper", "Parent not a ConstraintLayout");
        return;
      } 
      int k = constraintLayout.getChildCount();
      for (int j = 0; j < k; j++) {
        View view = constraintLayout.getChildAt(j);
        ViewGroup.LayoutParams layoutParams = view.getLayoutParams();
        if (layoutParams instanceof ConstraintLayout.b && str.equals(((ConstraintLayout.b)layoutParams).c0))
          if (view.getId() == -1) {
            StringBuilder stringBuilder = new StringBuilder();
            stringBuilder.append("to use ConstraintTag view ");
            stringBuilder.append(view.getClass().getSimpleName());
            stringBuilder.append(" must have an ID");
            Log.w("ConstraintHelper", stringBuilder.toString());
          } else {
            f(view.getId());
          }  
      } 
    } 
  }
  
  private int k(ConstraintLayout paramConstraintLayout, String paramString) {
    if (paramString != null) {
      if (paramConstraintLayout == null)
        return 0; 
      Resources resources = this.c.getResources();
      if (resources == null)
        return 0; 
      int k = paramConstraintLayout.getChildCount();
      int j = 0;
      while (true) {
        if (j < k) {
          View view = paramConstraintLayout.getChildAt(j);
          if (view.getId() != -1) {
            String str = null;
            try {
              String str1 = resources.getResourceEntryName(view.getId());
              str = str1;
            } catch (android.content.res.Resources.NotFoundException notFoundException) {}
            if (paramString.equals(str))
              return view.getId(); 
          } 
          j++;
          continue;
        } 
        return 0;
      } 
    } 
    return 0;
  }
  
  private int l(String paramString) {
    ConstraintLayout constraintLayout;
    if (getParent() instanceof ConstraintLayout) {
      constraintLayout = (ConstraintLayout)getParent();
    } else {
      constraintLayout = null;
    } 
    boolean bool = isInEditMode();
    int j = 0;
    int k = j;
    if (bool) {
      k = j;
      if (constraintLayout != null) {
        Object object = constraintLayout.h(0, paramString);
        k = j;
        if (object instanceof Integer)
          k = ((Integer)object).intValue(); 
      } 
    } 
    j = k;
    if (k == 0) {
      j = k;
      if (constraintLayout != null)
        j = k(constraintLayout, paramString); 
    } 
    k = j;
    if (j == 0)
      try {
        k = h.class.getField(paramString).getInt(null);
      } catch (Exception exception) {
        k = j;
      }  
    j = k;
    if (k == 0)
      j = this.c.getResources().getIdentifier(paramString, "id", this.c.getPackageName()); 
    return j;
  }
  
  public int[] getReferencedIds() {
    return Arrays.copyOf(this.a, this.b);
  }
  
  protected void h() {
    ViewParent viewParent = getParent();
    if (viewParent != null && viewParent instanceof ConstraintLayout)
      i((ConstraintLayout)viewParent); 
  }
  
  protected void i(ConstraintLayout paramConstraintLayout) {
    int k = getVisibility();
    float f = getElevation();
    for (int j = 0; j < this.b; j++) {
      View view = paramConstraintLayout.j(this.a[j]);
      if (view != null) {
        view.setVisibility(k);
        if (f > 0.0F)
          view.setTranslationZ(view.getTranslationZ() + f); 
      } 
    } 
  }
  
  protected void j(ConstraintLayout paramConstraintLayout) {}
  
  protected View[] m(ConstraintLayout paramConstraintLayout) {
    View[] arrayOfView = this.h;
    if (arrayOfView == null || arrayOfView.length != this.b)
      this.h = new View[this.b]; 
    for (int j = 0; j < this.b; j++) {
      int k = this.a[j];
      this.h[j] = paramConstraintLayout.j(k);
    } 
    return this.h;
  }
  
  protected void n(AttributeSet paramAttributeSet) {
    if (paramAttributeSet != null) {
      TypedArray typedArray = getContext().obtainStyledAttributes(paramAttributeSet, i.n1);
      int k = typedArray.getIndexCount();
      for (int j = 0; j < k; j++) {
        int m = typedArray.getIndex(j);
        if (m == i.z1) {
          String str = typedArray.getString(m);
          this.f = str;
          setIds(str);
        } else if (m == i.A1) {
          String str = typedArray.getString(m);
          this.g = str;
          setReferenceTags(str);
        } 
      } 
      typedArray.recycle();
    } 
  }
  
  public void o(e parame, boolean paramBoolean) {}
  
  protected void onAttachedToWindow() {
    super.onAttachedToWindow();
    String str = this.f;
    if (str != null)
      setIds(str); 
    str = this.g;
    if (str != null)
      setReferenceTags(str); 
  }
  
  public void onDraw(Canvas paramCanvas) {}
  
  protected void onMeasure(int paramInt1, int paramInt2) {
    if (this.e) {
      super.onMeasure(paramInt1, paramInt2);
      return;
    } 
    setMeasuredDimension(0, 0);
  }
  
  public void p(ConstraintLayout paramConstraintLayout) {}
  
  public void q(ConstraintLayout paramConstraintLayout) {}
  
  public void r(ConstraintLayout paramConstraintLayout) {}
  
  public void s(ConstraintLayout paramConstraintLayout) {
    if (isInEditMode())
      setIds(this.f); 
    i i1 = this.d;
    if (i1 == null)
      return; 
    i1.a();
    for (int j = 0; j < this.b; j++) {
      int k = this.a[j];
      View view2 = paramConstraintLayout.j(k);
      View view1 = view2;
      if (view2 == null) {
        String str = this.i.get(Integer.valueOf(k));
        k = k(paramConstraintLayout, str);
        view1 = view2;
        if (k != 0) {
          this.a[j] = k;
          this.i.put(Integer.valueOf(k), str);
          view1 = paramConstraintLayout.j(k);
        } 
      } 
      if (view1 != null)
        this.d.b(paramConstraintLayout.p(view1)); 
    } 
    this.d.c(paramConstraintLayout.c);
  }
  
  protected void setIds(String paramString) {
    this.f = paramString;
    if (paramString == null)
      return; 
    int j = 0;
    this.b = 0;
    while (true) {
      int k = paramString.indexOf(',', j);
      if (k == -1) {
        e(paramString.substring(j));
        return;
      } 
      e(paramString.substring(j, k));
      j = k + 1;
    } 
  }
  
  protected void setReferenceTags(String paramString) {
    this.g = paramString;
    if (paramString == null)
      return; 
    int j = 0;
    this.b = 0;
    while (true) {
      int k = paramString.indexOf(',', j);
      if (k == -1) {
        g(paramString.substring(j));
        return;
      } 
      g(paramString.substring(j, k));
      j = k + 1;
    } 
  }
  
  public void setReferencedIds(int[] paramArrayOfint) {
    this.f = null;
    int j = 0;
    this.b = 0;
    while (j < paramArrayOfint.length) {
      f(paramArrayOfint[j]);
      j++;
    } 
  }
  
  public void setTag(int paramInt, Object paramObject) {
    super.setTag(paramInt, paramObject);
    if (paramObject == null && this.f == null)
      f(paramInt); 
  }
  
  public void t() {
    if (this.d == null)
      return; 
    ViewGroup.LayoutParams layoutParams = getLayoutParams();
    if (layoutParams instanceof ConstraintLayout.b)
      ((ConstraintLayout.b)layoutParams).v0 = (e)this.d; 
  }
}


/* Location:              C:\soft\dex2jar-2.0\Cricket Scorer-dex2jar.jar!\androidx\constraintlayout\widget\b.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */