package androidx.constraintlayout.widget;

import android.content.Context;
import android.content.res.TypedArray;
import android.content.res.XmlResourceParser;
import android.util.AttributeSet;
import android.util.Log;
import android.util.SparseIntArray;
import android.util.Xml;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import androidx.constraintlayout.motion.widget.j;
import java.io.IOException;
import java.util.Arrays;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.Locale;
import org.xmlpull.v1.XmlPullParser;
import org.xmlpull.v1.XmlPullParserException;

public class d {
  private static final int[] f = new int[] { 0, 4, 8 };
  
  private static SparseIntArray g = new SparseIntArray();
  
  private static SparseIntArray h = new SparseIntArray();
  
  public String a = "";
  
  public int b = 0;
  
  private HashMap<String, a> c = new HashMap<String, a>();
  
  private boolean d = true;
  
  private HashMap<Integer, a> e = new HashMap<Integer, a>();
  
  static {
    g.append(i.A0, 25);
    g.append(i.B0, 26);
    g.append(i.D0, 29);
    g.append(i.E0, 30);
    g.append(i.K0, 36);
    g.append(i.J0, 35);
    g.append(i.h0, 4);
    g.append(i.g0, 3);
    g.append(i.c0, 1);
    g.append(i.e0, 91);
    g.append(i.d0, 92);
    g.append(i.T0, 6);
    g.append(i.U0, 7);
    g.append(i.o0, 17);
    g.append(i.p0, 18);
    g.append(i.q0, 19);
    g.append(i.Y, 99);
    g.append(i.u, 27);
    g.append(i.F0, 32);
    g.append(i.G0, 33);
    g.append(i.n0, 10);
    g.append(i.m0, 9);
    g.append(i.X0, 13);
    g.append(i.a1, 16);
    g.append(i.Y0, 14);
    g.append(i.V0, 11);
    g.append(i.Z0, 15);
    g.append(i.W0, 12);
    g.append(i.N0, 40);
    g.append(i.y0, 39);
    g.append(i.x0, 41);
    g.append(i.M0, 42);
    g.append(i.w0, 20);
    g.append(i.L0, 37);
    g.append(i.l0, 5);
    g.append(i.z0, 87);
    g.append(i.I0, 87);
    g.append(i.C0, 87);
    g.append(i.f0, 87);
    g.append(i.b0, 87);
    g.append(i.z, 24);
    g.append(i.B, 28);
    g.append(i.N, 31);
    g.append(i.O, 8);
    g.append(i.A, 34);
    g.append(i.C, 2);
    g.append(i.x, 23);
    g.append(i.y, 21);
    g.append(i.O0, 95);
    g.append(i.r0, 96);
    g.append(i.w, 22);
    g.append(i.D, 43);
    g.append(i.Q, 44);
    g.append(i.L, 45);
    g.append(i.M, 46);
    g.append(i.K, 60);
    g.append(i.I, 47);
    g.append(i.J, 48);
    g.append(i.E, 49);
    g.append(i.F, 50);
    g.append(i.G, 51);
    g.append(i.H, 52);
    g.append(i.P, 53);
    g.append(i.P0, 54);
    g.append(i.s0, 55);
    g.append(i.Q0, 56);
    g.append(i.t0, 57);
    g.append(i.R0, 58);
    g.append(i.u0, 59);
    g.append(i.i0, 61);
    g.append(i.k0, 62);
    g.append(i.j0, 63);
    g.append(i.R, 64);
    g.append(i.k1, 65);
    g.append(i.X, 66);
    g.append(i.l1, 67);
    g.append(i.d1, 79);
    g.append(i.v, 38);
    g.append(i.c1, 68);
    g.append(i.S0, 69);
    g.append(i.v0, 70);
    g.append(i.b1, 97);
    g.append(i.V, 71);
    g.append(i.T, 72);
    g.append(i.U, 73);
    g.append(i.W, 74);
    g.append(i.S, 75);
    g.append(i.e1, 76);
    g.append(i.H0, 77);
    g.append(i.m1, 78);
    g.append(i.a0, 80);
    g.append(i.Z, 81);
    g.append(i.f1, 82);
    g.append(i.j1, 83);
    g.append(i.i1, 84);
    g.append(i.h1, 85);
    g.append(i.g1, 86);
    SparseIntArray sparseIntArray = h;
    int i = i.R3;
    sparseIntArray.append(i, 6);
    h.append(i, 7);
    h.append(i.M2, 27);
    h.append(i.U3, 13);
    h.append(i.X3, 16);
    h.append(i.V3, 14);
    h.append(i.S3, 11);
    h.append(i.W3, 15);
    h.append(i.T3, 12);
    h.append(i.L3, 40);
    h.append(i.E3, 39);
    h.append(i.D3, 41);
    h.append(i.K3, 42);
    h.append(i.C3, 20);
    h.append(i.J3, 37);
    h.append(i.w3, 5);
    h.append(i.F3, 87);
    h.append(i.I3, 87);
    h.append(i.G3, 87);
    h.append(i.t3, 87);
    h.append(i.s3, 87);
    h.append(i.R2, 24);
    h.append(i.T2, 28);
    h.append(i.f3, 31);
    h.append(i.g3, 8);
    h.append(i.S2, 34);
    h.append(i.U2, 2);
    h.append(i.P2, 23);
    h.append(i.Q2, 21);
    h.append(i.M3, 95);
    h.append(i.x3, 96);
    h.append(i.O2, 22);
    h.append(i.V2, 43);
    h.append(i.i3, 44);
    h.append(i.d3, 45);
    h.append(i.e3, 46);
    h.append(i.c3, 60);
    h.append(i.a3, 47);
    h.append(i.b3, 48);
    h.append(i.W2, 49);
    h.append(i.X2, 50);
    h.append(i.Y2, 51);
    h.append(i.Z2, 52);
    h.append(i.h3, 53);
    h.append(i.N3, 54);
    h.append(i.y3, 55);
    h.append(i.O3, 56);
    h.append(i.z3, 57);
    h.append(i.P3, 58);
    h.append(i.A3, 59);
    h.append(i.v3, 62);
    h.append(i.u3, 63);
    h.append(i.j3, 64);
    h.append(i.i4, 65);
    h.append(i.p3, 66);
    h.append(i.j4, 67);
    h.append(i.a4, 79);
    h.append(i.N2, 38);
    h.append(i.b4, 98);
    h.append(i.Z3, 68);
    h.append(i.Q3, 69);
    h.append(i.B3, 70);
    h.append(i.n3, 71);
    h.append(i.l3, 72);
    h.append(i.m3, 73);
    h.append(i.o3, 74);
    h.append(i.k3, 75);
    h.append(i.c4, 76);
    h.append(i.H3, 77);
    h.append(i.k4, 78);
    h.append(i.r3, 80);
    h.append(i.q3, 81);
    h.append(i.d4, 82);
    h.append(i.h4, 83);
    h.append(i.g4, 84);
    h.append(i.f4, 85);
    h.append(i.e4, 86);
    h.append(i.Y3, 97);
  }
  
  private int[] j(View paramView, String paramString) {
    String[] arrayOfString = paramString.split(",");
    Context context = paramView.getContext();
    int[] arrayOfInt = new int[arrayOfString.length];
    int j = 0;
    int i = 0;
    while (true) {
      if (j < arrayOfString.length) {
        String str = arrayOfString[j].trim();
        try {
          m = h.class.getField(str).getInt(null);
        } catch (Exception exception) {
          m = 0;
        } 
        int k = m;
        if (!m)
          k = context.getResources().getIdentifier(str, "id", context.getPackageName()); 
        int m = k;
        if (k == 0) {
          m = k;
          if (paramView.isInEditMode()) {
            m = k;
            if (paramView.getParent() instanceof ConstraintLayout) {
              Object object = ((ConstraintLayout)paramView.getParent()).h(0, str);
              m = k;
              if (object != null) {
                m = k;
                if (object instanceof Integer)
                  m = ((Integer)object).intValue(); 
              } 
            } 
          } 
        } 
        arrayOfInt[i] = m;
        j++;
        i++;
        continue;
      } 
      int[] arrayOfInt1 = arrayOfInt;
      if (i != arrayOfString.length)
        arrayOfInt1 = Arrays.copyOf(arrayOfInt, i); 
      return arrayOfInt1;
    } 
  }
  
  private a k(Context paramContext, AttributeSet paramAttributeSet, boolean paramBoolean) {
    int[] arrayOfInt;
    a a = new a();
    if (paramBoolean) {
      arrayOfInt = i.L2;
    } else {
      arrayOfInt = i.t;
    } 
    TypedArray typedArray = paramContext.obtainStyledAttributes(paramAttributeSet, arrayOfInt);
    s(paramContext, a, typedArray, paramBoolean);
    typedArray.recycle();
    return a;
  }
  
  private a l(int paramInt) {
    if (!this.e.containsKey(Integer.valueOf(paramInt)))
      this.e.put(Integer.valueOf(paramInt), new a()); 
    return this.e.get(Integer.valueOf(paramInt));
  }
  
  private static int o(TypedArray paramTypedArray, int paramInt1, int paramInt2) {
    int i = paramTypedArray.getResourceId(paramInt1, paramInt2);
    paramInt2 = i;
    if (i == -1)
      paramInt2 = paramTypedArray.getInt(paramInt1, -1); 
    return paramInt2;
  }
  
  static void p(Object paramObject, TypedArray paramTypedArray, int paramInt1, int paramInt2) {
    if (paramObject == null)
      return; 
    int i = (paramTypedArray.peekValue(paramInt1)).type;
    if (i != 3) {
      byte b = -2;
      boolean bool = false;
      if (i != 5) {
        paramInt1 = paramTypedArray.getInt(paramInt1, 0);
        if (paramInt1 != -4) {
          if (paramInt1 == -3 || (paramInt1 != -2 && paramInt1 != -1))
            paramInt1 = 0; 
        } else {
          bool = true;
          paramInt1 = b;
        } 
      } else {
        paramInt1 = paramTypedArray.getDimensionPixelSize(paramInt1, 0);
      } 
      if (paramObject instanceof ConstraintLayout.b) {
        paramObject = paramObject;
        if (paramInt2 == 0) {
          ((ViewGroup.MarginLayoutParams)paramObject).width = paramInt1;
          ((ConstraintLayout.b)paramObject).a0 = bool;
          return;
        } 
        ((ViewGroup.MarginLayoutParams)paramObject).height = paramInt1;
        ((ConstraintLayout.b)paramObject).b0 = bool;
        return;
      } 
      if (paramObject instanceof b) {
        paramObject = paramObject;
        if (paramInt2 == 0) {
          ((b)paramObject).d = paramInt1;
          ((b)paramObject).n0 = bool;
          return;
        } 
        ((b)paramObject).e = paramInt1;
        ((b)paramObject).o0 = bool;
        return;
      } 
      if (paramObject instanceof a.a) {
        paramObject = paramObject;
        if (paramInt2 == 0) {
          paramObject.b(23, paramInt1);
          paramObject.d(80, bool);
          return;
        } 
        paramObject.b(21, paramInt1);
        paramObject.d(81, bool);
      } 
      return;
    } 
    q(paramObject, paramTypedArray.getString(paramInt1), paramInt2);
  }
  
  static void q(Object paramObject, String paramString, int paramInt) {
    if (paramString == null)
      return; 
    int i = paramString.indexOf('=');
    int j = paramString.length();
    if (i > 0 && i < j - 1) {
      String str = paramString.substring(0, i);
      paramString = paramString.substring(i + 1);
      if (paramString.length() > 0) {
        str = str.trim();
        paramString = paramString.trim();
        if ("ratio".equalsIgnoreCase(str)) {
          if (paramObject instanceof ConstraintLayout.b) {
            paramObject = paramObject;
            if (paramInt == 0) {
              ((ViewGroup.MarginLayoutParams)paramObject).width = 0;
            } else {
              ((ViewGroup.MarginLayoutParams)paramObject).height = 0;
            } 
            r((ConstraintLayout.b)paramObject, paramString);
            return;
          } 
          if (paramObject instanceof b) {
            ((b)paramObject).A = paramString;
            return;
          } 
          if (paramObject instanceof a.a) {
            ((a.a)paramObject).c(5, paramString);
            return;
          } 
        } else {
          if ("weight".equalsIgnoreCase(str))
            try {
              float f = Float.parseFloat(paramString);
              if (paramObject instanceof ConstraintLayout.b) {
                paramObject = paramObject;
                if (paramInt == 0) {
                  ((ViewGroup.MarginLayoutParams)paramObject).width = 0;
                  ((ConstraintLayout.b)paramObject).L = f;
                  return;
                } 
                ((ViewGroup.MarginLayoutParams)paramObject).height = 0;
                ((ConstraintLayout.b)paramObject).M = f;
                return;
              } 
              if (paramObject instanceof b) {
                paramObject = paramObject;
                if (paramInt == 0) {
                  ((b)paramObject).d = 0;
                  ((b)paramObject).W = f;
                  return;
                } 
                ((b)paramObject).e = 0;
                ((b)paramObject).V = f;
                return;
              } 
              if (paramObject instanceof a.a) {
                paramObject = paramObject;
                if (paramInt == 0) {
                  paramObject.b(23, 0);
                  paramObject.a(39, f);
                  return;
                } 
                paramObject.b(21, 0);
                paramObject.a(40, f);
                return;
              } 
              return;
            } catch (NumberFormatException numberFormatException) {
              return;
            }  
          if ("parent".equalsIgnoreCase(str)) {
            ConstraintLayout.b b1;
            b b;
            float f = Math.max(0.0F, Math.min(1.0F, Float.parseFloat(paramString)));
            if (numberFormatException instanceof ConstraintLayout.b) {
              b1 = (ConstraintLayout.b)numberFormatException;
              if (paramInt == 0) {
                b1.width = 0;
                b1.V = f;
                b1.P = 2;
                return;
              } 
              b1.height = 0;
              b1.W = f;
              b1.Q = 2;
              return;
            } 
            if (b1 instanceof b) {
              b = (b)b1;
              if (paramInt == 0) {
                b.d = 0;
                b.f0 = f;
                b.Z = 2;
                return;
              } 
              b.e = 0;
              b.g0 = f;
              b.a0 = 2;
              return;
            } 
            if (b instanceof a.a) {
              a.a a = (a.a)b;
              if (paramInt == 0) {
                a.b(23, 0);
                a.b(54, 2);
                return;
              } 
              a.b(21, 0);
              a.b(55, 2);
            } 
          } 
        } 
      } 
    } 
  }
  
  static void r(ConstraintLayout.b paramb, String paramString) {
    float f2 = Float.NaN;
    int i = -1;
    float f1 = f2;
    int j = i;
    if (paramString != null) {
      int m = paramString.length();
      int n = paramString.indexOf(',');
      byte b1 = 0;
      int k = i;
      j = b1;
      if (n > 0) {
        k = i;
        j = b1;
        if (n < m - 1) {
          String str = paramString.substring(0, n);
          if (str.equalsIgnoreCase("W")) {
            k = 0;
          } else {
            k = i;
            if (str.equalsIgnoreCase("H"))
              k = 1; 
          } 
          j = n + 1;
        } 
      } 
      i = paramString.indexOf(':');
      if (i >= 0 && i < m - 1) {
        String str1 = paramString.substring(j, i);
        String str2 = paramString.substring(i + 1);
        f1 = f2;
        j = k;
        if (str1.length() > 0) {
          f1 = f2;
          j = k;
          if (str2.length() > 0)
            try {
              float f3 = Float.parseFloat(str1);
              float f4 = Float.parseFloat(str2);
              f1 = f2;
              j = k;
              if (f3 > 0.0F) {
                f1 = f2;
                j = k;
                if (f4 > 0.0F)
                  if (k == 1) {
                    f1 = Math.abs(f4 / f3);
                    j = k;
                  } else {
                    f1 = Math.abs(f3 / f4);
                    j = k;
                  }  
              } 
            } catch (NumberFormatException numberFormatException) {
              f1 = f2;
              j = k;
            }  
        } 
      } else {
        String str = paramString.substring(j);
        f1 = f2;
        j = k;
        if (str.length() > 0) {
          f1 = Float.parseFloat(str);
          j = k;
        } 
      } 
    } 
    paramb.I = paramString;
    paramb.J = f1;
    paramb.K = j;
  }
  
  private void s(Context paramContext, a parama, TypedArray paramTypedArray, boolean paramBoolean) {
    if (paramBoolean) {
      t(paramContext, parama, paramTypedArray);
      return;
    } 
    int j = paramTypedArray.getIndexCount();
    int i;
    for (i = 0; i < j; i++) {
      StringBuilder stringBuilder2;
      b b7;
      StringBuilder stringBuilder1;
      c c5;
      e e3;
      c c4;
      b b6;
      c c3;
      d d4;
      c c2;
      b b5;
      d d3;
      c c1;
      b b4;
      e e2;
      b b3;
      e e1;
      d d2;
      b b2;
      d d1;
      b b1;
      int m;
      int k = paramTypedArray.getIndex(i);
      if (k != i.v && i.N != k && i.O != k) {
        parama.d.a = true;
        parama.e.b = true;
        parama.c.a = true;
        parama.f.a = true;
      } 
      switch (g.get(k)) {
        default:
          stringBuilder2 = new StringBuilder();
          stringBuilder2.append("Unknown attribute 0x");
          stringBuilder2.append(Integer.toHexString(k));
          stringBuilder2.append("   ");
          stringBuilder2.append(g.get(k));
          Log.w("ConstraintSet", stringBuilder2.toString());
          break;
        case 97:
          b7 = parama.e;
          b7.q0 = paramTypedArray.getInt(k, b7.q0);
          break;
        case 96:
          p(parama.e, paramTypedArray, k, 1);
          break;
        case 95:
          p(parama.e, paramTypedArray, k, 0);
          break;
        case 94:
          b7 = parama.e;
          b7.U = paramTypedArray.getDimensionPixelSize(k, b7.U);
          break;
        case 93:
          b7 = parama.e;
          b7.N = paramTypedArray.getDimensionPixelSize(k, b7.N);
          break;
        case 92:
          b7 = parama.e;
          b7.t = o(paramTypedArray, k, b7.t);
          break;
        case 91:
          b7 = parama.e;
          b7.s = o(paramTypedArray, k, b7.s);
          break;
        case 87:
          stringBuilder1 = new StringBuilder();
          stringBuilder1.append("unused attribute 0x");
          stringBuilder1.append(Integer.toHexString(k));
          stringBuilder1.append("   ");
          stringBuilder1.append(g.get(k));
          Log.w("ConstraintSet", stringBuilder1.toString());
          break;
        case 86:
          m = (paramTypedArray.peekValue(k)).type;
          if (m == 1) {
            parama.d.n = paramTypedArray.getResourceId(k, -1);
            c c = parama.d;
            if (c.n != -1)
              c.m = -2; 
            break;
          } 
          if (m == 3) {
            parama.d.l = paramTypedArray.getString(k);
            if (parama.d.l.indexOf("/") > 0) {
              parama.d.n = paramTypedArray.getResourceId(k, -1);
              parama.d.m = -2;
              break;
            } 
            parama.d.m = -1;
            break;
          } 
          c5 = parama.d;
          c5.m = paramTypedArray.getInteger(k, c5.n);
          break;
        case 85:
          c5 = parama.d;
          c5.j = paramTypedArray.getFloat(k, c5.j);
          break;
        case 84:
          c5 = parama.d;
          c5.k = paramTypedArray.getInteger(k, c5.k);
          break;
        case 83:
          e3 = parama.f;
          e3.i = o(paramTypedArray, k, e3.i);
          break;
        case 82:
          c4 = parama.d;
          c4.c = paramTypedArray.getInteger(k, c4.c);
          break;
        case 81:
          b6 = parama.e;
          b6.o0 = paramTypedArray.getBoolean(k, b6.o0);
          break;
        case 80:
          b6 = parama.e;
          b6.n0 = paramTypedArray.getBoolean(k, b6.n0);
          break;
        case 79:
          c3 = parama.d;
          c3.g = paramTypedArray.getFloat(k, c3.g);
          break;
        case 78:
          d4 = parama.c;
          d4.c = paramTypedArray.getInt(k, d4.c);
          break;
        case 77:
          parama.e.m0 = paramTypedArray.getString(k);
          break;
        case 76:
          c2 = parama.d;
          c2.e = paramTypedArray.getInt(k, c2.e);
          break;
        case 75:
          b5 = parama.e;
          b5.p0 = paramTypedArray.getBoolean(k, b5.p0);
          break;
        case 74:
          parama.e.l0 = paramTypedArray.getString(k);
          break;
        case 73:
          b5 = parama.e;
          b5.i0 = paramTypedArray.getDimensionPixelSize(k, b5.i0);
          break;
        case 72:
          b5 = parama.e;
          b5.h0 = paramTypedArray.getInt(k, b5.h0);
          break;
        case 71:
          Log.e("ConstraintSet", "CURRENTLY UNSUPPORTED");
          break;
        case 70:
          parama.e.g0 = paramTypedArray.getFloat(k, 1.0F);
          break;
        case 69:
          parama.e.f0 = paramTypedArray.getFloat(k, 1.0F);
          break;
        case 68:
          d3 = parama.c;
          d3.e = paramTypedArray.getFloat(k, d3.e);
          break;
        case 67:
          c1 = parama.d;
          c1.i = paramTypedArray.getFloat(k, c1.i);
          break;
        case 66:
          parama.d.f = paramTypedArray.getInt(k, 0);
          break;
        case 65:
          if ((paramTypedArray.peekValue(k)).type == 3) {
            parama.d.d = paramTypedArray.getString(k);
            break;
          } 
          parama.d.d = n.b.c[paramTypedArray.getInteger(k, 0)];
          break;
        case 64:
          c1 = parama.d;
          c1.b = o(paramTypedArray, k, c1.b);
          break;
        case 63:
          b4 = parama.e;
          b4.D = paramTypedArray.getFloat(k, b4.D);
          break;
        case 62:
          b4 = parama.e;
          b4.C = paramTypedArray.getDimensionPixelSize(k, b4.C);
          break;
        case 61:
          b4 = parama.e;
          b4.B = o(paramTypedArray, k, b4.B);
          break;
        case 60:
          e2 = parama.f;
          e2.b = paramTypedArray.getFloat(k, e2.b);
          break;
        case 59:
          b3 = parama.e;
          b3.e0 = paramTypedArray.getDimensionPixelSize(k, b3.e0);
          break;
        case 58:
          b3 = parama.e;
          b3.d0 = paramTypedArray.getDimensionPixelSize(k, b3.d0);
          break;
        case 57:
          b3 = parama.e;
          b3.c0 = paramTypedArray.getDimensionPixelSize(k, b3.c0);
          break;
        case 56:
          b3 = parama.e;
          b3.b0 = paramTypedArray.getDimensionPixelSize(k, b3.b0);
          break;
        case 55:
          b3 = parama.e;
          b3.a0 = paramTypedArray.getInt(k, b3.a0);
          break;
        case 54:
          b3 = parama.e;
          b3.Z = paramTypedArray.getInt(k, b3.Z);
          break;
        case 53:
          e1 = parama.f;
          e1.l = paramTypedArray.getDimension(k, e1.l);
          break;
        case 52:
          e1 = parama.f;
          e1.k = paramTypedArray.getDimension(k, e1.k);
          break;
        case 51:
          e1 = parama.f;
          e1.j = paramTypedArray.getDimension(k, e1.j);
          break;
        case 50:
          e1 = parama.f;
          e1.h = paramTypedArray.getDimension(k, e1.h);
          break;
        case 49:
          e1 = parama.f;
          e1.g = paramTypedArray.getDimension(k, e1.g);
          break;
        case 48:
          e1 = parama.f;
          e1.f = paramTypedArray.getFloat(k, e1.f);
          break;
        case 47:
          e1 = parama.f;
          e1.e = paramTypedArray.getFloat(k, e1.e);
          break;
        case 46:
          e1 = parama.f;
          e1.d = paramTypedArray.getFloat(k, e1.d);
          break;
        case 45:
          e1 = parama.f;
          e1.c = paramTypedArray.getFloat(k, e1.c);
          break;
        case 44:
          e1 = parama.f;
          e1.m = true;
          e1.n = paramTypedArray.getDimension(k, e1.n);
          break;
        case 43:
          d2 = parama.c;
          d2.d = paramTypedArray.getFloat(k, d2.d);
          break;
        case 42:
          b2 = parama.e;
          b2.Y = paramTypedArray.getInt(k, b2.Y);
          break;
        case 41:
          b2 = parama.e;
          b2.X = paramTypedArray.getInt(k, b2.X);
          break;
        case 40:
          b2 = parama.e;
          b2.V = paramTypedArray.getFloat(k, b2.V);
          break;
        case 39:
          b2 = parama.e;
          b2.W = paramTypedArray.getFloat(k, b2.W);
          break;
        case 38:
          parama.a = paramTypedArray.getResourceId(k, parama.a);
          break;
        case 37:
          b2 = parama.e;
          b2.z = paramTypedArray.getFloat(k, b2.z);
          break;
        case 36:
          b2 = parama.e;
          b2.n = o(paramTypedArray, k, b2.n);
          break;
        case 35:
          b2 = parama.e;
          b2.o = o(paramTypedArray, k, b2.o);
          break;
        case 34:
          b2 = parama.e;
          b2.J = paramTypedArray.getDimensionPixelSize(k, b2.J);
          break;
        case 33:
          b2 = parama.e;
          b2.v = o(paramTypedArray, k, b2.v);
          break;
        case 32:
          b2 = parama.e;
          b2.u = o(paramTypedArray, k, b2.u);
          break;
        case 31:
          b2 = parama.e;
          b2.M = paramTypedArray.getDimensionPixelSize(k, b2.M);
          break;
        case 30:
          b2 = parama.e;
          b2.m = o(paramTypedArray, k, b2.m);
          break;
        case 29:
          b2 = parama.e;
          b2.l = o(paramTypedArray, k, b2.l);
          break;
        case 28:
          b2 = parama.e;
          b2.I = paramTypedArray.getDimensionPixelSize(k, b2.I);
          break;
        case 27:
          b2 = parama.e;
          b2.G = paramTypedArray.getInt(k, b2.G);
          break;
        case 26:
          b2 = parama.e;
          b2.k = o(paramTypedArray, k, b2.k);
          break;
        case 25:
          b2 = parama.e;
          b2.j = o(paramTypedArray, k, b2.j);
          break;
        case 24:
          b2 = parama.e;
          b2.H = paramTypedArray.getDimensionPixelSize(k, b2.H);
          break;
        case 23:
          b2 = parama.e;
          b2.d = paramTypedArray.getLayoutDimension(k, b2.d);
          break;
        case 22:
          d1 = parama.c;
          d1.b = paramTypedArray.getInt(k, d1.b);
          d1 = parama.c;
          d1.b = f[d1.b];
          break;
        case 21:
          b1 = parama.e;
          b1.e = paramTypedArray.getLayoutDimension(k, b1.e);
          break;
        case 20:
          b1 = parama.e;
          b1.y = paramTypedArray.getFloat(k, b1.y);
          break;
        case 19:
          b1 = parama.e;
          b1.h = paramTypedArray.getFloat(k, b1.h);
          break;
        case 18:
          b1 = parama.e;
          b1.g = paramTypedArray.getDimensionPixelOffset(k, b1.g);
          break;
        case 17:
          b1 = parama.e;
          b1.f = paramTypedArray.getDimensionPixelOffset(k, b1.f);
          break;
        case 16:
          b1 = parama.e;
          b1.P = paramTypedArray.getDimensionPixelSize(k, b1.P);
          break;
        case 15:
          b1 = parama.e;
          b1.T = paramTypedArray.getDimensionPixelSize(k, b1.T);
          break;
        case 14:
          b1 = parama.e;
          b1.Q = paramTypedArray.getDimensionPixelSize(k, b1.Q);
          break;
        case 13:
          b1 = parama.e;
          b1.O = paramTypedArray.getDimensionPixelSize(k, b1.O);
          break;
        case 12:
          b1 = parama.e;
          b1.S = paramTypedArray.getDimensionPixelSize(k, b1.S);
          break;
        case 11:
          b1 = parama.e;
          b1.R = paramTypedArray.getDimensionPixelSize(k, b1.R);
          break;
        case 10:
          b1 = parama.e;
          b1.w = o(paramTypedArray, k, b1.w);
          break;
        case 9:
          b1 = parama.e;
          b1.x = o(paramTypedArray, k, b1.x);
          break;
        case 8:
          b1 = parama.e;
          b1.L = paramTypedArray.getDimensionPixelSize(k, b1.L);
          break;
        case 7:
          b1 = parama.e;
          b1.F = paramTypedArray.getDimensionPixelOffset(k, b1.F);
          break;
        case 6:
          b1 = parama.e;
          b1.E = paramTypedArray.getDimensionPixelOffset(k, b1.E);
          break;
        case 5:
          parama.e.A = paramTypedArray.getString(k);
          break;
        case 4:
          b1 = parama.e;
          b1.p = o(paramTypedArray, k, b1.p);
          break;
        case 3:
          b1 = parama.e;
          b1.q = o(paramTypedArray, k, b1.q);
          break;
        case 2:
          b1 = parama.e;
          b1.K = paramTypedArray.getDimensionPixelSize(k, b1.K);
          break;
        case 1:
          b1 = parama.e;
          b1.r = o(paramTypedArray, k, b1.r);
          break;
      } 
    } 
    b b = parama.e;
    if (b.l0 != null)
      b.k0 = null; 
  }
  
  private static void t(Context paramContext, a parama, TypedArray paramTypedArray) {
    int j = paramTypedArray.getIndexCount();
    a.a a1 = new a.a();
    parama.h = a1;
    parama.d.a = false;
    parama.e.b = false;
    parama.c.a = false;
    parama.f.a = false;
    for (int i = 0; i < j; i++) {
      int m;
      StringBuilder stringBuilder;
      c c;
      int k = paramTypedArray.getIndex(i);
      switch (h.get(k)) {
        default:
          stringBuilder = new StringBuilder();
          stringBuilder.append("Unknown attribute 0x");
          stringBuilder.append(Integer.toHexString(k));
          stringBuilder.append("   ");
          stringBuilder.append(g.get(k));
          Log.w("ConstraintSet", stringBuilder.toString());
          break;
        case 99:
          a1.d(99, paramTypedArray.getBoolean(k, parama.e.i));
          break;
        case 98:
          if (j.B0) {
            int n = paramTypedArray.getResourceId(k, parama.a);
            parama.a = n;
            if (n == -1)
              parama.b = paramTypedArray.getString(k); 
            break;
          } 
          if ((paramTypedArray.peekValue(k)).type == 3) {
            parama.b = paramTypedArray.getString(k);
            break;
          } 
          parama.a = paramTypedArray.getResourceId(k, parama.a);
          break;
        case 97:
          a1.b(97, paramTypedArray.getInt(k, parama.e.q0));
          break;
        case 96:
          p(a1, paramTypedArray, k, 1);
          break;
        case 95:
          p(a1, paramTypedArray, k, 0);
          break;
        case 94:
          a1.b(94, paramTypedArray.getDimensionPixelSize(k, parama.e.U));
          break;
        case 93:
          a1.b(93, paramTypedArray.getDimensionPixelSize(k, parama.e.N));
          break;
        case 87:
          stringBuilder = new StringBuilder();
          stringBuilder.append("unused attribute 0x");
          stringBuilder.append(Integer.toHexString(k));
          stringBuilder.append("   ");
          stringBuilder.append(g.get(k));
          Log.w("ConstraintSet", stringBuilder.toString());
          break;
        case 86:
          m = (paramTypedArray.peekValue(k)).type;
          if (m == 1) {
            parama.d.n = paramTypedArray.getResourceId(k, -1);
            a1.b(89, parama.d.n);
            c c1 = parama.d;
            if (c1.n != -1) {
              c1.m = -2;
              a1.b(88, -2);
            } 
            break;
          } 
          if (m == 3) {
            parama.d.l = paramTypedArray.getString(k);
            a1.c(90, parama.d.l);
            if (parama.d.l.indexOf("/") > 0) {
              parama.d.n = paramTypedArray.getResourceId(k, -1);
              a1.b(89, parama.d.n);
              parama.d.m = -2;
              a1.b(88, -2);
              break;
            } 
            parama.d.m = -1;
            a1.b(88, -1);
            break;
          } 
          c = parama.d;
          c.m = paramTypedArray.getInteger(k, c.n);
          a1.b(88, parama.d.m);
          break;
        case 85:
          a1.a(85, paramTypedArray.getFloat(k, parama.d.j));
          break;
        case 84:
          a1.b(84, paramTypedArray.getInteger(k, parama.d.k));
          break;
        case 83:
          a1.b(83, o(paramTypedArray, k, parama.f.i));
          break;
        case 82:
          a1.b(82, paramTypedArray.getInteger(k, parama.d.c));
          break;
        case 81:
          a1.d(81, paramTypedArray.getBoolean(k, parama.e.o0));
          break;
        case 80:
          a1.d(80, paramTypedArray.getBoolean(k, parama.e.n0));
          break;
        case 79:
          a1.a(79, paramTypedArray.getFloat(k, parama.d.g));
          break;
        case 78:
          a1.b(78, paramTypedArray.getInt(k, parama.c.c));
          break;
        case 77:
          a1.c(77, paramTypedArray.getString(k));
          break;
        case 76:
          a1.b(76, paramTypedArray.getInt(k, parama.d.e));
          break;
        case 75:
          a1.d(75, paramTypedArray.getBoolean(k, parama.e.p0));
          break;
        case 74:
          a1.c(74, paramTypedArray.getString(k));
          break;
        case 73:
          a1.b(73, paramTypedArray.getDimensionPixelSize(k, parama.e.i0));
          break;
        case 72:
          a1.b(72, paramTypedArray.getInt(k, parama.e.h0));
          break;
        case 71:
          Log.e("ConstraintSet", "CURRENTLY UNSUPPORTED");
          break;
        case 70:
          a1.a(70, paramTypedArray.getFloat(k, 1.0F));
          break;
        case 69:
          a1.a(69, paramTypedArray.getFloat(k, 1.0F));
          break;
        case 68:
          a1.a(68, paramTypedArray.getFloat(k, parama.c.e));
          break;
        case 67:
          a1.a(67, paramTypedArray.getFloat(k, parama.d.i));
          break;
        case 66:
          a1.b(66, paramTypedArray.getInt(k, 0));
          break;
        case 65:
          if ((paramTypedArray.peekValue(k)).type == 3) {
            a1.c(65, paramTypedArray.getString(k));
            break;
          } 
          a1.c(65, n.b.c[paramTypedArray.getInteger(k, 0)]);
          break;
        case 64:
          a1.b(64, o(paramTypedArray, k, parama.d.b));
          break;
        case 63:
          a1.a(63, paramTypedArray.getFloat(k, parama.e.D));
          break;
        case 62:
          a1.b(62, paramTypedArray.getDimensionPixelSize(k, parama.e.C));
          break;
        case 60:
          a1.a(60, paramTypedArray.getFloat(k, parama.f.b));
          break;
        case 59:
          a1.b(59, paramTypedArray.getDimensionPixelSize(k, parama.e.e0));
          break;
        case 58:
          a1.b(58, paramTypedArray.getDimensionPixelSize(k, parama.e.d0));
          break;
        case 57:
          a1.b(57, paramTypedArray.getDimensionPixelSize(k, parama.e.c0));
          break;
        case 56:
          a1.b(56, paramTypedArray.getDimensionPixelSize(k, parama.e.b0));
          break;
        case 55:
          a1.b(55, paramTypedArray.getInt(k, parama.e.a0));
          break;
        case 54:
          a1.b(54, paramTypedArray.getInt(k, parama.e.Z));
          break;
        case 53:
          a1.a(53, paramTypedArray.getDimension(k, parama.f.l));
          break;
        case 52:
          a1.a(52, paramTypedArray.getDimension(k, parama.f.k));
          break;
        case 51:
          a1.a(51, paramTypedArray.getDimension(k, parama.f.j));
          break;
        case 50:
          a1.a(50, paramTypedArray.getDimension(k, parama.f.h));
          break;
        case 49:
          a1.a(49, paramTypedArray.getDimension(k, parama.f.g));
          break;
        case 48:
          a1.a(48, paramTypedArray.getFloat(k, parama.f.f));
          break;
        case 47:
          a1.a(47, paramTypedArray.getFloat(k, parama.f.e));
          break;
        case 46:
          a1.a(46, paramTypedArray.getFloat(k, parama.f.d));
          break;
        case 45:
          a1.a(45, paramTypedArray.getFloat(k, parama.f.c));
          break;
        case 44:
          a1.d(44, true);
          a1.a(44, paramTypedArray.getDimension(k, parama.f.n));
          break;
        case 43:
          a1.a(43, paramTypedArray.getFloat(k, parama.c.d));
          break;
        case 42:
          a1.b(42, paramTypedArray.getInt(k, parama.e.Y));
          break;
        case 41:
          a1.b(41, paramTypedArray.getInt(k, parama.e.X));
          break;
        case 40:
          a1.a(40, paramTypedArray.getFloat(k, parama.e.V));
          break;
        case 39:
          a1.a(39, paramTypedArray.getFloat(k, parama.e.W));
          break;
        case 38:
          k = paramTypedArray.getResourceId(k, parama.a);
          parama.a = k;
          a1.b(38, k);
          break;
        case 37:
          a1.a(37, paramTypedArray.getFloat(k, parama.e.z));
          break;
        case 34:
          a1.b(34, paramTypedArray.getDimensionPixelSize(k, parama.e.J));
          break;
        case 31:
          a1.b(31, paramTypedArray.getDimensionPixelSize(k, parama.e.M));
          break;
        case 28:
          a1.b(28, paramTypedArray.getDimensionPixelSize(k, parama.e.I));
          break;
        case 27:
          a1.b(27, paramTypedArray.getInt(k, parama.e.G));
          break;
        case 24:
          a1.b(24, paramTypedArray.getDimensionPixelSize(k, parama.e.H));
          break;
        case 23:
          a1.b(23, paramTypedArray.getLayoutDimension(k, parama.e.d));
          break;
        case 22:
          a1.b(22, f[paramTypedArray.getInt(k, parama.c.b)]);
          break;
        case 21:
          a1.b(21, paramTypedArray.getLayoutDimension(k, parama.e.e));
          break;
        case 20:
          a1.a(20, paramTypedArray.getFloat(k, parama.e.y));
          break;
        case 19:
          a1.a(19, paramTypedArray.getFloat(k, parama.e.h));
          break;
        case 18:
          a1.b(18, paramTypedArray.getDimensionPixelOffset(k, parama.e.g));
          break;
        case 17:
          a1.b(17, paramTypedArray.getDimensionPixelOffset(k, parama.e.f));
          break;
        case 16:
          a1.b(16, paramTypedArray.getDimensionPixelSize(k, parama.e.P));
          break;
        case 15:
          a1.b(15, paramTypedArray.getDimensionPixelSize(k, parama.e.T));
          break;
        case 14:
          a1.b(14, paramTypedArray.getDimensionPixelSize(k, parama.e.Q));
          break;
        case 13:
          a1.b(13, paramTypedArray.getDimensionPixelSize(k, parama.e.O));
          break;
        case 12:
          a1.b(12, paramTypedArray.getDimensionPixelSize(k, parama.e.S));
          break;
        case 11:
          a1.b(11, paramTypedArray.getDimensionPixelSize(k, parama.e.R));
          break;
        case 8:
          a1.b(8, paramTypedArray.getDimensionPixelSize(k, parama.e.L));
          break;
        case 7:
          a1.b(7, paramTypedArray.getDimensionPixelOffset(k, parama.e.F));
          break;
        case 6:
          a1.b(6, paramTypedArray.getDimensionPixelOffset(k, parama.e.E));
          break;
        case 5:
          a1.c(5, paramTypedArray.getString(k));
          break;
        case 2:
          a1.b(2, paramTypedArray.getDimensionPixelSize(k, parama.e.K));
          break;
      } 
    } 
  }
  
  public void c(ConstraintLayout paramConstraintLayout) {
    d(paramConstraintLayout, true);
    paramConstraintLayout.setConstraintSet(null);
    paramConstraintLayout.requestLayout();
  }
  
  void d(ConstraintLayout paramConstraintLayout, boolean paramBoolean) {
    int j = paramConstraintLayout.getChildCount();
    HashSet hashSet = new HashSet(this.e.keySet());
    boolean bool = false;
    int i;
    for (i = 0; i < j; i++) {
      View view = paramConstraintLayout.getChildAt(i);
      int k = view.getId();
      if (!this.e.containsKey(Integer.valueOf(k))) {
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("id unknown ");
        stringBuilder.append(androidx.constraintlayout.motion.widget.a.b(view));
        Log.w("ConstraintSet", stringBuilder.toString());
      } else if (!this.d || k != -1) {
        if (k != -1)
          if (this.e.containsKey(Integer.valueOf(k))) {
            hashSet.remove(Integer.valueOf(k));
            a a = this.e.get(Integer.valueOf(k));
            if (a != null) {
              View view1;
              if (view instanceof Barrier) {
                a.e.j0 = 1;
                view1 = view;
                view1.setId(k);
                view1.setType(a.e.h0);
                view1.setMargin(a.e.i0);
                view1.setAllowsGoneWidget(a.e.p0);
                b b1 = a.e;
                int[] arrayOfInt = b1.k0;
                if (arrayOfInt != null) {
                  view1.setReferencedIds(arrayOfInt);
                } else {
                  String str = b1.l0;
                  if (str != null) {
                    b1.k0 = j(view1, str);
                    view1.setReferencedIds(a.e.k0);
                  } 
                } 
              } 
              ConstraintLayout.b b = (ConstraintLayout.b)view.getLayoutParams();
              b.a();
              a.d(b);
              if (paramBoolean)
                a.f(view, a.g); 
              view.setLayoutParams((ViewGroup.LayoutParams)b);
              d d1 = a.c;
              if (d1.c == 0)
                view.setVisibility(d1.b); 
              view.setAlpha(a.c.d);
              view.setRotation(a.f.b);
              view.setRotationX(a.f.c);
              view.setRotationY(a.f.d);
              view.setScaleX(a.f.e);
              view.setScaleY(a.f.f);
              e e2 = a.f;
              if (e2.i != -1) {
                view1 = ((View)view.getParent()).findViewById(a.f.i);
                if (view1 != null) {
                  float f1 = (view1.getTop() + view1.getBottom()) / 2.0F;
                  float f2 = (view1.getLeft() + view1.getRight()) / 2.0F;
                  if (view.getRight() - view.getLeft() > 0 && view.getBottom() - view.getTop() > 0) {
                    float f3 = view.getLeft();
                    float f4 = view.getTop();
                    view.setPivotX(f2 - f3);
                    view.setPivotY(f1 - f4);
                  } 
                } 
              } else {
                if (!Float.isNaN(((e)view1).g))
                  view.setPivotX(a.f.g); 
                if (!Float.isNaN(a.f.h))
                  view.setPivotY(a.f.h); 
              } 
              view.setTranslationX(a.f.j);
              view.setTranslationY(a.f.k);
              view.setTranslationZ(a.f.l);
              e e1 = a.f;
              if (e1.m)
                view.setElevation(e1.n); 
            } 
          } else {
            StringBuilder stringBuilder = new StringBuilder();
            stringBuilder.append("WARNING NO CONSTRAINTS for view ");
            stringBuilder.append(k);
            Log.v("ConstraintSet", stringBuilder.toString());
          }  
      } else {
        throw new RuntimeException("All children of ConstraintLayout must have ids to use ConstraintSet");
      } 
    } 
    Iterator<Integer> iterator = hashSet.iterator();
    while (true) {
      i = bool;
      if (iterator.hasNext()) {
        Integer integer = iterator.next();
        a a = this.e.get(integer);
        if (a == null)
          continue; 
        if (a.e.j0 == 1) {
          Barrier barrier = new Barrier(paramConstraintLayout.getContext());
          barrier.setId(integer.intValue());
          b b1 = a.e;
          int[] arrayOfInt = b1.k0;
          if (arrayOfInt != null) {
            barrier.setReferencedIds(arrayOfInt);
          } else {
            String str = b1.l0;
            if (str != null) {
              b1.k0 = j(barrier, str);
              barrier.setReferencedIds(a.e.k0);
            } 
          } 
          barrier.setType(a.e.h0);
          barrier.setMargin(a.e.i0);
          ConstraintLayout.b b = paramConstraintLayout.f();
          barrier.t();
          a.d(b);
          paramConstraintLayout.addView(barrier, (ViewGroup.LayoutParams)b);
        } 
        if (a.e.a) {
          Guideline guideline = new Guideline(paramConstraintLayout.getContext());
          guideline.setId(integer.intValue());
          ConstraintLayout.b b = paramConstraintLayout.f();
          a.d(b);
          paramConstraintLayout.addView(guideline, (ViewGroup.LayoutParams)b);
        } 
        continue;
      } 
      break;
    } 
    while (i < j) {
      View view = paramConstraintLayout.getChildAt(i);
      if (view instanceof b)
        ((b)view).j(paramConstraintLayout); 
      i++;
    } 
  }
  
  public void e(int paramInt1, int paramInt2) {
    if (this.e.containsKey(Integer.valueOf(paramInt1))) {
      a a = this.e.get(Integer.valueOf(paramInt1));
      if (a == null)
        return; 
      switch (paramInt2) {
        default:
          throw new IllegalArgumentException("unknown constraint");
        case 8:
          b = a.e;
          b.D = -1.0F;
          b.C = -1;
          b.B = -1;
          return;
        case 7:
          b = ((a)b).e;
          b.w = -1;
          b.x = -1;
          b.L = 0;
          b.S = Integer.MIN_VALUE;
          return;
        case 6:
          b = ((a)b).e;
          b.u = -1;
          b.v = -1;
          b.M = 0;
          b.T = Integer.MIN_VALUE;
          return;
        case 5:
          b = ((a)b).e;
          b.r = -1;
          b.s = -1;
          b.t = -1;
          b.N = 0;
          b.U = Integer.MIN_VALUE;
          return;
        case 4:
          b = ((a)b).e;
          b.p = -1;
          b.q = -1;
          b.K = 0;
          b.R = Integer.MIN_VALUE;
          return;
        case 3:
          b = ((a)b).e;
          b.o = -1;
          b.n = -1;
          b.J = 0;
          b.P = Integer.MIN_VALUE;
          return;
        case 2:
          b = ((a)b).e;
          b.m = -1;
          b.l = -1;
          b.I = -1;
          b.Q = Integer.MIN_VALUE;
          return;
        case 1:
          break;
      } 
      b b = ((a)b).e;
      b.k = -1;
      b.j = -1;
      b.H = -1;
      b.O = Integer.MIN_VALUE;
    } 
  }
  
  public void f(Context paramContext, int paramInt) {
    g((ConstraintLayout)LayoutInflater.from(paramContext).inflate(paramInt, null));
  }
  
  public void g(ConstraintLayout paramConstraintLayout) {
    int j = paramConstraintLayout.getChildCount();
    this.e.clear();
    int i = 0;
    while (i < j) {
      View view = paramConstraintLayout.getChildAt(i);
      ConstraintLayout.b b = (ConstraintLayout.b)view.getLayoutParams();
      int k = view.getId();
      if (!this.d || k != -1) {
        if (!this.e.containsKey(Integer.valueOf(k)))
          this.e.put(Integer.valueOf(k), new a()); 
        a a = this.e.get(Integer.valueOf(k));
        if (a != null) {
          a.g = a.b(this.c, view);
          a.a(a, k, b);
          a.c.b = view.getVisibility();
          a.c.d = view.getAlpha();
          a.f.b = view.getRotation();
          a.f.c = view.getRotationX();
          a.f.d = view.getRotationY();
          a.f.e = view.getScaleX();
          a.f.f = view.getScaleY();
          float f1 = view.getPivotX();
          float f2 = view.getPivotY();
          if (f1 != 0.0D || f2 != 0.0D) {
            e e1 = a.f;
            e1.g = f1;
            e1.h = f2;
          } 
          a.f.j = view.getTranslationX();
          a.f.k = view.getTranslationY();
          a.f.l = view.getTranslationZ();
          e e = a.f;
          if (e.m)
            e.n = view.getElevation(); 
          if (view instanceof Barrier) {
            view = view;
            a.e.p0 = view.getAllowsGoneWidget();
            a.e.k0 = view.getReferencedIds();
            a.e.h0 = view.getType();
            a.e.i0 = view.getMargin();
          } 
        } 
        i++;
        continue;
      } 
      throw new RuntimeException("All children of ConstraintLayout must have ids to use ConstraintSet");
    } 
  }
  
  public void h(e parame) {
    int j = parame.getChildCount();
    this.e.clear();
    int i = 0;
    while (i < j) {
      View view = parame.getChildAt(i);
      e.a a = (e.a)view.getLayoutParams();
      int k = view.getId();
      if (!this.d || k != -1) {
        if (!this.e.containsKey(Integer.valueOf(k)))
          this.e.put(Integer.valueOf(k), new a()); 
        a a1 = this.e.get(Integer.valueOf(k));
        if (a1 != null) {
          if (view instanceof b)
            a.b(a1, (b)view, k, a); 
          a.c(a1, k, a);
        } 
        i++;
        continue;
      } 
      throw new RuntimeException("All children of ConstraintLayout must have ids to use ConstraintSet");
    } 
  }
  
  public void i(int paramInt1, int paramInt2, int paramInt3, float paramFloat) {
    b b = (l(paramInt1)).e;
    b.B = paramInt2;
    b.C = paramInt3;
    b.D = paramFloat;
  }
  
  public void m(Context paramContext, int paramInt) {
    XmlResourceParser xmlResourceParser = paramContext.getResources().getXml(paramInt);
    try {
      paramInt = xmlResourceParser.getEventType();
    } catch (XmlPullParserException xmlPullParserException) {
      xmlPullParserException.printStackTrace();
      return;
    } catch (IOException iOException) {
      iOException.printStackTrace();
      return;
    } 
    while (true) {
      if (paramInt != 1) {
        if (paramInt != 0) {
          if (paramInt == 2) {
            String str = xmlResourceParser.getName();
            a a = k((Context)iOException, Xml.asAttributeSet((XmlPullParser)xmlResourceParser), false);
            if (str.equalsIgnoreCase("Guideline"))
              a.e.a = true; 
            this.e.put(Integer.valueOf(a.a), a);
          } 
        } else {
          xmlResourceParser.getName();
        } 
        paramInt = xmlResourceParser.next();
        continue;
      } 
      return;
    } 
  }
  
  public void n(Context paramContext, XmlPullParser paramXmlPullParser) {
    int i;
    a a;
    try {
      i = paramXmlPullParser.getEventType();
      a = null;
    } catch (XmlPullParserException xmlPullParserException) {
      xmlPullParserException.printStackTrace();
      return;
    } catch (IOException iOException) {
      iOException.printStackTrace();
      return;
    } 
    while (true) {
      if (i != 1) {
        if (i != 0) {
          byte b = -1;
          if (i != 2) {
            if (i == 3) {
              String str = paramXmlPullParser.getName().toLowerCase(Locale.ROOT);
              switch (str.hashCode()) {
                case 2146106725:
                  i = b;
                  if (str.equals("constraintset"))
                    i = 0; 
                  break;
                case 426575017:
                  i = b;
                  if (str.equals("constraintoverride"))
                    i = 2; 
                  break;
                case -190376483:
                  i = b;
                  if (str.equals("constraint"))
                    i = 1; 
                  break;
                case -2075718416:
                  i = b;
                  if (str.equals("guideline"))
                    i = 3; 
                  break;
                default:
                  i = b;
                  break;
              } 
              if (i != 0) {
                if (i == 1 || i == 2 || i == 3) {
                  this.e.put(Integer.valueOf(a.a), a);
                  a = null;
                } 
              } else {
                return;
              } 
            } 
          } else {
            StringBuilder stringBuilder;
            boolean bool;
            b b1;
            String str = paramXmlPullParser.getName();
            switch (str.hashCode()) {
              case 1803088381:
                i = b;
                if (str.equals("Constraint"))
                  i = 0; 
                switch (i) {
                  case 8:
                  case 9:
                    if (a != null) {
                      a.e((Context)iOException, paramXmlPullParser, a.g);
                      break;
                    } 
                    stringBuilder = new StringBuilder();
                    stringBuilder.append("XML parser error must be within a Constraint ");
                    stringBuilder.append(paramXmlPullParser.getLineNumber());
                    throw new RuntimeException(stringBuilder.toString());
                  case 7:
                    if (a != null) {
                      a.d.b((Context)stringBuilder, Xml.asAttributeSet(paramXmlPullParser));
                      break;
                    } 
                    stringBuilder = new StringBuilder();
                    stringBuilder.append("XML parser error must be within a Constraint ");
                    stringBuilder.append(paramXmlPullParser.getLineNumber());
                    throw new RuntimeException(stringBuilder.toString());
                  case 6:
                    if (a != null) {
                      a.e.b((Context)stringBuilder, Xml.asAttributeSet(paramXmlPullParser));
                      break;
                    } 
                    stringBuilder = new StringBuilder();
                    stringBuilder.append("XML parser error must be within a Constraint ");
                    stringBuilder.append(paramXmlPullParser.getLineNumber());
                    throw new RuntimeException(stringBuilder.toString());
                  case 5:
                    if (a != null) {
                      a.f.b((Context)stringBuilder, Xml.asAttributeSet(paramXmlPullParser));
                      break;
                    } 
                    stringBuilder = new StringBuilder();
                    stringBuilder.append("XML parser error must be within a Constraint ");
                    stringBuilder.append(paramXmlPullParser.getLineNumber());
                    throw new RuntimeException(stringBuilder.toString());
                  case 4:
                    if (a != null) {
                      a.c.b((Context)stringBuilder, Xml.asAttributeSet(paramXmlPullParser));
                      break;
                    } 
                    stringBuilder = new StringBuilder();
                    stringBuilder.append("XML parser error must be within a Constraint ");
                    stringBuilder.append(paramXmlPullParser.getLineNumber());
                    throw new RuntimeException(stringBuilder.toString());
                  case 3:
                    a = k((Context)stringBuilder, Xml.asAttributeSet(paramXmlPullParser), false);
                    a.e.j0 = 1;
                    break;
                  case 2:
                    a = k((Context)stringBuilder, Xml.asAttributeSet(paramXmlPullParser), false);
                    b1 = a.e;
                    b1.a = true;
                    b1.b = true;
                    break;
                  case 1:
                    a = k((Context)stringBuilder, Xml.asAttributeSet(paramXmlPullParser), true);
                    break;
                  case 0:
                    a = k((Context)stringBuilder, Xml.asAttributeSet(paramXmlPullParser), false);
                    break;
                } 
              case 1791837707:
                i = b;
                if (b1.equals("CustomAttribute"))
                  i = 8; 
                switch (i) {
                  case 8:
                  case 9:
                    if (a != null) {
                      a.e((Context)stringBuilder, paramXmlPullParser, a.g);
                      break;
                    } 
                    stringBuilder = new StringBuilder();
                    stringBuilder.append("XML parser error must be within a Constraint ");
                    stringBuilder.append(paramXmlPullParser.getLineNumber());
                    throw new RuntimeException(stringBuilder.toString());
                  case 7:
                    if (a != null) {
                      a.d.b((Context)stringBuilder, Xml.asAttributeSet(paramXmlPullParser));
                      break;
                    } 
                    stringBuilder = new StringBuilder();
                    stringBuilder.append("XML parser error must be within a Constraint ");
                    stringBuilder.append(paramXmlPullParser.getLineNumber());
                    throw new RuntimeException(stringBuilder.toString());
                  case 6:
                    if (a != null) {
                      a.e.b((Context)stringBuilder, Xml.asAttributeSet(paramXmlPullParser));
                      break;
                    } 
                    stringBuilder = new StringBuilder();
                    stringBuilder.append("XML parser error must be within a Constraint ");
                    stringBuilder.append(paramXmlPullParser.getLineNumber());
                    throw new RuntimeException(stringBuilder.toString());
                  case 5:
                    if (a != null) {
                      a.f.b((Context)stringBuilder, Xml.asAttributeSet(paramXmlPullParser));
                      break;
                    } 
                    stringBuilder = new StringBuilder();
                    stringBuilder.append("XML parser error must be within a Constraint ");
                    stringBuilder.append(paramXmlPullParser.getLineNumber());
                    throw new RuntimeException(stringBuilder.toString());
                  case 4:
                    if (a != null) {
                      a.c.b((Context)stringBuilder, Xml.asAttributeSet(paramXmlPullParser));
                      break;
                    } 
                    stringBuilder = new StringBuilder();
                    stringBuilder.append("XML parser error must be within a Constraint ");
                    stringBuilder.append(paramXmlPullParser.getLineNumber());
                    throw new RuntimeException(stringBuilder.toString());
                  case 3:
                    a = k((Context)stringBuilder, Xml.asAttributeSet(paramXmlPullParser), false);
                    a.e.j0 = 1;
                    break;
                  case 2:
                    a = k((Context)stringBuilder, Xml.asAttributeSet(paramXmlPullParser), false);
                    b1 = a.e;
                    b1.a = true;
                    b1.b = true;
                    break;
                  case 1:
                    a = k((Context)stringBuilder, Xml.asAttributeSet(paramXmlPullParser), true);
                    break;
                  case 0:
                    a = k((Context)stringBuilder, Xml.asAttributeSet(paramXmlPullParser), false);
                    break;
                } 
              case 1331510167:
                i = b;
                if (b1.equals("Barrier"))
                  i = 3; 
                switch (i) {
                  case 8:
                  case 9:
                    if (a != null) {
                      a.e((Context)stringBuilder, paramXmlPullParser, a.g);
                      break;
                    } 
                    stringBuilder = new StringBuilder();
                    stringBuilder.append("XML parser error must be within a Constraint ");
                    stringBuilder.append(paramXmlPullParser.getLineNumber());
                    throw new RuntimeException(stringBuilder.toString());
                  case 7:
                    if (a != null) {
                      a.d.b((Context)stringBuilder, Xml.asAttributeSet(paramXmlPullParser));
                      break;
                    } 
                    stringBuilder = new StringBuilder();
                    stringBuilder.append("XML parser error must be within a Constraint ");
                    stringBuilder.append(paramXmlPullParser.getLineNumber());
                    throw new RuntimeException(stringBuilder.toString());
                  case 6:
                    if (a != null) {
                      a.e.b((Context)stringBuilder, Xml.asAttributeSet(paramXmlPullParser));
                      break;
                    } 
                    stringBuilder = new StringBuilder();
                    stringBuilder.append("XML parser error must be within a Constraint ");
                    stringBuilder.append(paramXmlPullParser.getLineNumber());
                    throw new RuntimeException(stringBuilder.toString());
                  case 5:
                    if (a != null) {
                      a.f.b((Context)stringBuilder, Xml.asAttributeSet(paramXmlPullParser));
                      break;
                    } 
                    stringBuilder = new StringBuilder();
                    stringBuilder.append("XML parser error must be within a Constraint ");
                    stringBuilder.append(paramXmlPullParser.getLineNumber());
                    throw new RuntimeException(stringBuilder.toString());
                  case 4:
                    if (a != null) {
                      a.c.b((Context)stringBuilder, Xml.asAttributeSet(paramXmlPullParser));
                      break;
                    } 
                    stringBuilder = new StringBuilder();
                    stringBuilder.append("XML parser error must be within a Constraint ");
                    stringBuilder.append(paramXmlPullParser.getLineNumber());
                    throw new RuntimeException(stringBuilder.toString());
                  case 3:
                    a = k((Context)stringBuilder, Xml.asAttributeSet(paramXmlPullParser), false);
                    a.e.j0 = 1;
                    break;
                  case 2:
                    a = k((Context)stringBuilder, Xml.asAttributeSet(paramXmlPullParser), false);
                    b1 = a.e;
                    b1.a = true;
                    b1.b = true;
                    break;
                  case 1:
                    a = k((Context)stringBuilder, Xml.asAttributeSet(paramXmlPullParser), true);
                    break;
                  case 0:
                    a = k((Context)stringBuilder, Xml.asAttributeSet(paramXmlPullParser), false);
                    break;
                } 
              case 366511058:
                i = b;
                if (b1.equals("CustomMethod"))
                  i = 9; 
                switch (i) {
                  case 8:
                  case 9:
                    if (a != null) {
                      a.e((Context)stringBuilder, paramXmlPullParser, a.g);
                      break;
                    } 
                    stringBuilder = new StringBuilder();
                    stringBuilder.append("XML parser error must be within a Constraint ");
                    stringBuilder.append(paramXmlPullParser.getLineNumber());
                    throw new RuntimeException(stringBuilder.toString());
                  case 7:
                    if (a != null) {
                      a.d.b((Context)stringBuilder, Xml.asAttributeSet(paramXmlPullParser));
                      break;
                    } 
                    stringBuilder = new StringBuilder();
                    stringBuilder.append("XML parser error must be within a Constraint ");
                    stringBuilder.append(paramXmlPullParser.getLineNumber());
                    throw new RuntimeException(stringBuilder.toString());
                  case 6:
                    if (a != null) {
                      a.e.b((Context)stringBuilder, Xml.asAttributeSet(paramXmlPullParser));
                      break;
                    } 
                    stringBuilder = new StringBuilder();
                    stringBuilder.append("XML parser error must be within a Constraint ");
                    stringBuilder.append(paramXmlPullParser.getLineNumber());
                    throw new RuntimeException(stringBuilder.toString());
                  case 5:
                    if (a != null) {
                      a.f.b((Context)stringBuilder, Xml.asAttributeSet(paramXmlPullParser));
                      break;
                    } 
                    stringBuilder = new StringBuilder();
                    stringBuilder.append("XML parser error must be within a Constraint ");
                    stringBuilder.append(paramXmlPullParser.getLineNumber());
                    throw new RuntimeException(stringBuilder.toString());
                  case 4:
                    if (a != null) {
                      a.c.b((Context)stringBuilder, Xml.asAttributeSet(paramXmlPullParser));
                      break;
                    } 
                    stringBuilder = new StringBuilder();
                    stringBuilder.append("XML parser error must be within a Constraint ");
                    stringBuilder.append(paramXmlPullParser.getLineNumber());
                    throw new RuntimeException(stringBuilder.toString());
                  case 3:
                    a = k((Context)stringBuilder, Xml.asAttributeSet(paramXmlPullParser), false);
                    a.e.j0 = 1;
                    break;
                  case 2:
                    a = k((Context)stringBuilder, Xml.asAttributeSet(paramXmlPullParser), false);
                    b1 = a.e;
                    b1.a = true;
                    b1.b = true;
                    break;
                  case 1:
                    a = k((Context)stringBuilder, Xml.asAttributeSet(paramXmlPullParser), true);
                    break;
                  case 0:
                    a = k((Context)stringBuilder, Xml.asAttributeSet(paramXmlPullParser), false);
                    break;
                } 
              case -71750448:
                i = b;
                if (b1.equals("Guideline"))
                  i = 2; 
                switch (i) {
                  case 8:
                  case 9:
                    if (a != null) {
                      a.e((Context)stringBuilder, paramXmlPullParser, a.g);
                      break;
                    } 
                    stringBuilder = new StringBuilder();
                    stringBuilder.append("XML parser error must be within a Constraint ");
                    stringBuilder.append(paramXmlPullParser.getLineNumber());
                    throw new RuntimeException(stringBuilder.toString());
                  case 7:
                    if (a != null) {
                      a.d.b((Context)stringBuilder, Xml.asAttributeSet(paramXmlPullParser));
                      break;
                    } 
                    stringBuilder = new StringBuilder();
                    stringBuilder.append("XML parser error must be within a Constraint ");
                    stringBuilder.append(paramXmlPullParser.getLineNumber());
                    throw new RuntimeException(stringBuilder.toString());
                  case 6:
                    if (a != null) {
                      a.e.b((Context)stringBuilder, Xml.asAttributeSet(paramXmlPullParser));
                      break;
                    } 
                    stringBuilder = new StringBuilder();
                    stringBuilder.append("XML parser error must be within a Constraint ");
                    stringBuilder.append(paramXmlPullParser.getLineNumber());
                    throw new RuntimeException(stringBuilder.toString());
                  case 5:
                    if (a != null) {
                      a.f.b((Context)stringBuilder, Xml.asAttributeSet(paramXmlPullParser));
                      break;
                    } 
                    stringBuilder = new StringBuilder();
                    stringBuilder.append("XML parser error must be within a Constraint ");
                    stringBuilder.append(paramXmlPullParser.getLineNumber());
                    throw new RuntimeException(stringBuilder.toString());
                  case 4:
                    if (a != null) {
                      a.c.b((Context)stringBuilder, Xml.asAttributeSet(paramXmlPullParser));
                      break;
                    } 
                    stringBuilder = new StringBuilder();
                    stringBuilder.append("XML parser error must be within a Constraint ");
                    stringBuilder.append(paramXmlPullParser.getLineNumber());
                    throw new RuntimeException(stringBuilder.toString());
                  case 3:
                    a = k((Context)stringBuilder, Xml.asAttributeSet(paramXmlPullParser), false);
                    a.e.j0 = 1;
                    break;
                  case 2:
                    a = k((Context)stringBuilder, Xml.asAttributeSet(paramXmlPullParser), false);
                    b1 = a.e;
                    b1.a = true;
                    b1.b = true;
                    break;
                  case 1:
                    a = k((Context)stringBuilder, Xml.asAttributeSet(paramXmlPullParser), true);
                    break;
                  case 0:
                    a = k((Context)stringBuilder, Xml.asAttributeSet(paramXmlPullParser), false);
                    break;
                } 
              case -1238332596:
                i = b;
                if (b1.equals("Transform"))
                  i = 5; 
                switch (i) {
                  case 8:
                  case 9:
                    if (a != null) {
                      a.e((Context)stringBuilder, paramXmlPullParser, a.g);
                      break;
                    } 
                    stringBuilder = new StringBuilder();
                    stringBuilder.append("XML parser error must be within a Constraint ");
                    stringBuilder.append(paramXmlPullParser.getLineNumber());
                    throw new RuntimeException(stringBuilder.toString());
                  case 7:
                    if (a != null) {
                      a.d.b((Context)stringBuilder, Xml.asAttributeSet(paramXmlPullParser));
                      break;
                    } 
                    stringBuilder = new StringBuilder();
                    stringBuilder.append("XML parser error must be within a Constraint ");
                    stringBuilder.append(paramXmlPullParser.getLineNumber());
                    throw new RuntimeException(stringBuilder.toString());
                  case 6:
                    if (a != null) {
                      a.e.b((Context)stringBuilder, Xml.asAttributeSet(paramXmlPullParser));
                      break;
                    } 
                    stringBuilder = new StringBuilder();
                    stringBuilder.append("XML parser error must be within a Constraint ");
                    stringBuilder.append(paramXmlPullParser.getLineNumber());
                    throw new RuntimeException(stringBuilder.toString());
                  case 5:
                    if (a != null) {
                      a.f.b((Context)stringBuilder, Xml.asAttributeSet(paramXmlPullParser));
                      break;
                    } 
                    stringBuilder = new StringBuilder();
                    stringBuilder.append("XML parser error must be within a Constraint ");
                    stringBuilder.append(paramXmlPullParser.getLineNumber());
                    throw new RuntimeException(stringBuilder.toString());
                  case 4:
                    if (a != null) {
                      a.c.b((Context)stringBuilder, Xml.asAttributeSet(paramXmlPullParser));
                      break;
                    } 
                    stringBuilder = new StringBuilder();
                    stringBuilder.append("XML parser error must be within a Constraint ");
                    stringBuilder.append(paramXmlPullParser.getLineNumber());
                    throw new RuntimeException(stringBuilder.toString());
                  case 3:
                    a = k((Context)stringBuilder, Xml.asAttributeSet(paramXmlPullParser), false);
                    a.e.j0 = 1;
                    break;
                  case 2:
                    a = k((Context)stringBuilder, Xml.asAttributeSet(paramXmlPullParser), false);
                    b1 = a.e;
                    b1.a = true;
                    b1.b = true;
                    break;
                  case 1:
                    a = k((Context)stringBuilder, Xml.asAttributeSet(paramXmlPullParser), true);
                    break;
                  case 0:
                    a = k((Context)stringBuilder, Xml.asAttributeSet(paramXmlPullParser), false);
                    break;
                } 
              case -1269513683:
                i = b;
                if (b1.equals("PropertySet"))
                  i = 4; 
                switch (i) {
                  case 8:
                  case 9:
                    if (a != null) {
                      a.e((Context)stringBuilder, paramXmlPullParser, a.g);
                      break;
                    } 
                    stringBuilder = new StringBuilder();
                    stringBuilder.append("XML parser error must be within a Constraint ");
                    stringBuilder.append(paramXmlPullParser.getLineNumber());
                    throw new RuntimeException(stringBuilder.toString());
                  case 7:
                    if (a != null) {
                      a.d.b((Context)stringBuilder, Xml.asAttributeSet(paramXmlPullParser));
                      break;
                    } 
                    stringBuilder = new StringBuilder();
                    stringBuilder.append("XML parser error must be within a Constraint ");
                    stringBuilder.append(paramXmlPullParser.getLineNumber());
                    throw new RuntimeException(stringBuilder.toString());
                  case 6:
                    if (a != null) {
                      a.e.b((Context)stringBuilder, Xml.asAttributeSet(paramXmlPullParser));
                      break;
                    } 
                    stringBuilder = new StringBuilder();
                    stringBuilder.append("XML parser error must be within a Constraint ");
                    stringBuilder.append(paramXmlPullParser.getLineNumber());
                    throw new RuntimeException(stringBuilder.toString());
                  case 5:
                    if (a != null) {
                      a.f.b((Context)stringBuilder, Xml.asAttributeSet(paramXmlPullParser));
                      break;
                    } 
                    stringBuilder = new StringBuilder();
                    stringBuilder.append("XML parser error must be within a Constraint ");
                    stringBuilder.append(paramXmlPullParser.getLineNumber());
                    throw new RuntimeException(stringBuilder.toString());
                  case 4:
                    if (a != null) {
                      a.c.b((Context)stringBuilder, Xml.asAttributeSet(paramXmlPullParser));
                      break;
                    } 
                    stringBuilder = new StringBuilder();
                    stringBuilder.append("XML parser error must be within a Constraint ");
                    stringBuilder.append(paramXmlPullParser.getLineNumber());
                    throw new RuntimeException(stringBuilder.toString());
                  case 3:
                    a = k((Context)stringBuilder, Xml.asAttributeSet(paramXmlPullParser), false);
                    a.e.j0 = 1;
                    break;
                  case 2:
                    a = k((Context)stringBuilder, Xml.asAttributeSet(paramXmlPullParser), false);
                    b1 = a.e;
                    b1.a = true;
                    b1.b = true;
                    break;
                  case 1:
                    a = k((Context)stringBuilder, Xml.asAttributeSet(paramXmlPullParser), true);
                    break;
                  case 0:
                    a = k((Context)stringBuilder, Xml.asAttributeSet(paramXmlPullParser), false);
                    break;
                } 
              case -1962203927:
                i = b;
                if (b1.equals("ConstraintOverride"))
                  i = 1; 
                switch (i) {
                  case 8:
                  case 9:
                    if (a != null) {
                      a.e((Context)stringBuilder, paramXmlPullParser, a.g);
                      break;
                    } 
                    stringBuilder = new StringBuilder();
                    stringBuilder.append("XML parser error must be within a Constraint ");
                    stringBuilder.append(paramXmlPullParser.getLineNumber());
                    throw new RuntimeException(stringBuilder.toString());
                  case 7:
                    if (a != null) {
                      a.d.b((Context)stringBuilder, Xml.asAttributeSet(paramXmlPullParser));
                      break;
                    } 
                    stringBuilder = new StringBuilder();
                    stringBuilder.append("XML parser error must be within a Constraint ");
                    stringBuilder.append(paramXmlPullParser.getLineNumber());
                    throw new RuntimeException(stringBuilder.toString());
                  case 6:
                    if (a != null) {
                      a.e.b((Context)stringBuilder, Xml.asAttributeSet(paramXmlPullParser));
                      break;
                    } 
                    stringBuilder = new StringBuilder();
                    stringBuilder.append("XML parser error must be within a Constraint ");
                    stringBuilder.append(paramXmlPullParser.getLineNumber());
                    throw new RuntimeException(stringBuilder.toString());
                  case 5:
                    if (a != null) {
                      a.f.b((Context)stringBuilder, Xml.asAttributeSet(paramXmlPullParser));
                      break;
                    } 
                    stringBuilder = new StringBuilder();
                    stringBuilder.append("XML parser error must be within a Constraint ");
                    stringBuilder.append(paramXmlPullParser.getLineNumber());
                    throw new RuntimeException(stringBuilder.toString());
                  case 4:
                    if (a != null) {
                      a.c.b((Context)stringBuilder, Xml.asAttributeSet(paramXmlPullParser));
                      break;
                    } 
                    stringBuilder = new StringBuilder();
                    stringBuilder.append("XML parser error must be within a Constraint ");
                    stringBuilder.append(paramXmlPullParser.getLineNumber());
                    throw new RuntimeException(stringBuilder.toString());
                  case 3:
                    a = k((Context)stringBuilder, Xml.asAttributeSet(paramXmlPullParser), false);
                    a.e.j0 = 1;
                    break;
                  case 2:
                    a = k((Context)stringBuilder, Xml.asAttributeSet(paramXmlPullParser), false);
                    b1 = a.e;
                    b1.a = true;
                    b1.b = true;
                    break;
                  case 1:
                    a = k((Context)stringBuilder, Xml.asAttributeSet(paramXmlPullParser), true);
                    break;
                  case 0:
                    a = k((Context)stringBuilder, Xml.asAttributeSet(paramXmlPullParser), false);
                    break;
                } 
              case -1984451626:
                i = b;
                if (b1.equals("Motion"))
                  i = 7; 
                switch (i) {
                  case 8:
                  case 9:
                    if (a != null) {
                      a.e((Context)stringBuilder, paramXmlPullParser, a.g);
                      break;
                    } 
                    stringBuilder = new StringBuilder();
                    stringBuilder.append("XML parser error must be within a Constraint ");
                    stringBuilder.append(paramXmlPullParser.getLineNumber());
                    throw new RuntimeException(stringBuilder.toString());
                  case 7:
                    if (a != null) {
                      a.d.b((Context)stringBuilder, Xml.asAttributeSet(paramXmlPullParser));
                      break;
                    } 
                    stringBuilder = new StringBuilder();
                    stringBuilder.append("XML parser error must be within a Constraint ");
                    stringBuilder.append(paramXmlPullParser.getLineNumber());
                    throw new RuntimeException(stringBuilder.toString());
                  case 6:
                    if (a != null) {
                      a.e.b((Context)stringBuilder, Xml.asAttributeSet(paramXmlPullParser));
                      break;
                    } 
                    stringBuilder = new StringBuilder();
                    stringBuilder.append("XML parser error must be within a Constraint ");
                    stringBuilder.append(paramXmlPullParser.getLineNumber());
                    throw new RuntimeException(stringBuilder.toString());
                  case 5:
                    if (a != null) {
                      a.f.b((Context)stringBuilder, Xml.asAttributeSet(paramXmlPullParser));
                      break;
                    } 
                    stringBuilder = new StringBuilder();
                    stringBuilder.append("XML parser error must be within a Constraint ");
                    stringBuilder.append(paramXmlPullParser.getLineNumber());
                    throw new RuntimeException(stringBuilder.toString());
                  case 4:
                    if (a != null) {
                      a.c.b((Context)stringBuilder, Xml.asAttributeSet(paramXmlPullParser));
                      break;
                    } 
                    stringBuilder = new StringBuilder();
                    stringBuilder.append("XML parser error must be within a Constraint ");
                    stringBuilder.append(paramXmlPullParser.getLineNumber());
                    throw new RuntimeException(stringBuilder.toString());
                  case 3:
                    a = k((Context)stringBuilder, Xml.asAttributeSet(paramXmlPullParser), false);
                    a.e.j0 = 1;
                    break;
                  case 2:
                    a = k((Context)stringBuilder, Xml.asAttributeSet(paramXmlPullParser), false);
                    b1 = a.e;
                    b1.a = true;
                    b1.b = true;
                    break;
                  case 1:
                    a = k((Context)stringBuilder, Xml.asAttributeSet(paramXmlPullParser), true);
                    break;
                  case 0:
                    a = k((Context)stringBuilder, Xml.asAttributeSet(paramXmlPullParser), false);
                    break;
                } 
              case -2025855158:
                bool = b1.equals("Layout");
                i = b;
                if (bool)
                  i = 6; 
                switch (i) {
                  case 8:
                  case 9:
                    if (a != null) {
                      a.e((Context)stringBuilder, paramXmlPullParser, a.g);
                      break;
                    } 
                    stringBuilder = new StringBuilder();
                    stringBuilder.append("XML parser error must be within a Constraint ");
                    stringBuilder.append(paramXmlPullParser.getLineNumber());
                    throw new RuntimeException(stringBuilder.toString());
                  case 7:
                    if (a != null) {
                      a.d.b((Context)stringBuilder, Xml.asAttributeSet(paramXmlPullParser));
                      break;
                    } 
                    stringBuilder = new StringBuilder();
                    stringBuilder.append("XML parser error must be within a Constraint ");
                    stringBuilder.append(paramXmlPullParser.getLineNumber());
                    throw new RuntimeException(stringBuilder.toString());
                  case 6:
                    if (a != null) {
                      a.e.b((Context)stringBuilder, Xml.asAttributeSet(paramXmlPullParser));
                      break;
                    } 
                    stringBuilder = new StringBuilder();
                    stringBuilder.append("XML parser error must be within a Constraint ");
                    stringBuilder.append(paramXmlPullParser.getLineNumber());
                    throw new RuntimeException(stringBuilder.toString());
                  case 5:
                    if (a != null) {
                      a.f.b((Context)stringBuilder, Xml.asAttributeSet(paramXmlPullParser));
                      break;
                    } 
                    stringBuilder = new StringBuilder();
                    stringBuilder.append("XML parser error must be within a Constraint ");
                    stringBuilder.append(paramXmlPullParser.getLineNumber());
                    throw new RuntimeException(stringBuilder.toString());
                  case 4:
                    if (a != null) {
                      a.c.b((Context)stringBuilder, Xml.asAttributeSet(paramXmlPullParser));
                      break;
                    } 
                    stringBuilder = new StringBuilder();
                    stringBuilder.append("XML parser error must be within a Constraint ");
                    stringBuilder.append(paramXmlPullParser.getLineNumber());
                    throw new RuntimeException(stringBuilder.toString());
                  case 3:
                    a = k((Context)stringBuilder, Xml.asAttributeSet(paramXmlPullParser), false);
                    a.e.j0 = 1;
                    break;
                  case 2:
                    a = k((Context)stringBuilder, Xml.asAttributeSet(paramXmlPullParser), false);
                    b1 = a.e;
                    b1.a = true;
                    b1.b = true;
                    break;
                  case 1:
                    a = k((Context)stringBuilder, Xml.asAttributeSet(paramXmlPullParser), true);
                    break;
                  case 0:
                    a = k((Context)stringBuilder, Xml.asAttributeSet(paramXmlPullParser), false);
                    break;
                } 
            } 
            i = b;
            switch (i) {
              case 8:
              case 9:
                if (a != null) {
                  a.e((Context)stringBuilder, paramXmlPullParser, a.g);
                  break;
                } 
                stringBuilder = new StringBuilder();
                stringBuilder.append("XML parser error must be within a Constraint ");
                stringBuilder.append(paramXmlPullParser.getLineNumber());
                throw new RuntimeException(stringBuilder.toString());
              case 7:
                if (a != null) {
                  a.d.b((Context)stringBuilder, Xml.asAttributeSet(paramXmlPullParser));
                  break;
                } 
                stringBuilder = new StringBuilder();
                stringBuilder.append("XML parser error must be within a Constraint ");
                stringBuilder.append(paramXmlPullParser.getLineNumber());
                throw new RuntimeException(stringBuilder.toString());
              case 6:
                if (a != null) {
                  a.e.b((Context)stringBuilder, Xml.asAttributeSet(paramXmlPullParser));
                  break;
                } 
                stringBuilder = new StringBuilder();
                stringBuilder.append("XML parser error must be within a Constraint ");
                stringBuilder.append(paramXmlPullParser.getLineNumber());
                throw new RuntimeException(stringBuilder.toString());
              case 5:
                if (a != null) {
                  a.f.b((Context)stringBuilder, Xml.asAttributeSet(paramXmlPullParser));
                  break;
                } 
                stringBuilder = new StringBuilder();
                stringBuilder.append("XML parser error must be within a Constraint ");
                stringBuilder.append(paramXmlPullParser.getLineNumber());
                throw new RuntimeException(stringBuilder.toString());
              case 4:
                if (a != null) {
                  a.c.b((Context)stringBuilder, Xml.asAttributeSet(paramXmlPullParser));
                  break;
                } 
                stringBuilder = new StringBuilder();
                stringBuilder.append("XML parser error must be within a Constraint ");
                stringBuilder.append(paramXmlPullParser.getLineNumber());
                throw new RuntimeException(stringBuilder.toString());
              case 3:
                a = k((Context)stringBuilder, Xml.asAttributeSet(paramXmlPullParser), false);
                a.e.j0 = 1;
                break;
              case 2:
                a = k((Context)stringBuilder, Xml.asAttributeSet(paramXmlPullParser), false);
                b1 = a.e;
                b1.a = true;
                b1.b = true;
                break;
              case 1:
                a = k((Context)stringBuilder, Xml.asAttributeSet(paramXmlPullParser), true);
                break;
              case 0:
                a = k((Context)stringBuilder, Xml.asAttributeSet(paramXmlPullParser), false);
                break;
            } 
          } 
        } else {
          paramXmlPullParser.getName();
        } 
        i = paramXmlPullParser.next();
        continue;
      } 
      return;
    } 
  }
  
  public static class a {
    int a;
    
    String b;
    
    public final d.d c = new d.d();
    
    public final d.c d = new d.c();
    
    public final d.b e = new d.b();
    
    public final d.e f = new d.e();
    
    public HashMap<String, a> g = new HashMap<String, a>();
    
    a h;
    
    private void f(int param1Int, ConstraintLayout.b param1b) {
      this.a = param1Int;
      d.b b1 = this.e;
      b1.j = param1b.e;
      b1.k = param1b.f;
      b1.l = param1b.g;
      b1.m = param1b.h;
      b1.n = param1b.i;
      b1.o = param1b.j;
      b1.p = param1b.k;
      b1.q = param1b.l;
      b1.r = param1b.m;
      b1.s = param1b.n;
      b1.t = param1b.o;
      b1.u = param1b.s;
      b1.v = param1b.t;
      b1.w = param1b.u;
      b1.x = param1b.v;
      b1.y = param1b.G;
      b1.z = param1b.H;
      b1.A = param1b.I;
      b1.B = param1b.p;
      b1.C = param1b.q;
      b1.D = param1b.r;
      b1.E = param1b.X;
      b1.F = param1b.Y;
      b1.G = param1b.Z;
      b1.h = param1b.c;
      b1.f = param1b.a;
      b1.g = param1b.b;
      b1.d = param1b.width;
      b1.e = param1b.height;
      b1.H = param1b.leftMargin;
      b1.I = param1b.rightMargin;
      b1.J = param1b.topMargin;
      b1.K = param1b.bottomMargin;
      b1.N = param1b.D;
      b1.V = param1b.M;
      b1.W = param1b.L;
      b1.Y = param1b.O;
      b1.X = param1b.N;
      b1.n0 = param1b.a0;
      b1.o0 = param1b.b0;
      b1.Z = param1b.P;
      b1.a0 = param1b.Q;
      b1.b0 = param1b.T;
      b1.c0 = param1b.U;
      b1.d0 = param1b.R;
      b1.e0 = param1b.S;
      b1.f0 = param1b.V;
      b1.g0 = param1b.W;
      b1.m0 = param1b.c0;
      b1.P = param1b.x;
      b1.R = param1b.z;
      b1.O = param1b.w;
      b1.Q = param1b.y;
      b1.T = param1b.A;
      b1.S = param1b.B;
      b1.U = param1b.C;
      b1.q0 = param1b.d0;
      b1.L = param1b.getMarginEnd();
      this.e.M = param1b.getMarginStart();
    }
    
    private void g(int param1Int, e.a param1a) {
      f(param1Int, param1a);
      this.c.d = param1a.x0;
      d.e e1 = this.f;
      e1.b = param1a.A0;
      e1.c = param1a.B0;
      e1.d = param1a.C0;
      e1.e = param1a.D0;
      e1.f = param1a.E0;
      e1.g = param1a.F0;
      e1.h = param1a.G0;
      e1.j = param1a.H0;
      e1.k = param1a.I0;
      e1.l = param1a.J0;
      e1.n = param1a.z0;
      e1.m = param1a.y0;
    }
    
    private void h(b param1b, int param1Int, e.a param1a) {
      g(param1Int, param1a);
      if (param1b instanceof Barrier) {
        d.b b1 = this.e;
        b1.j0 = 1;
        param1b = param1b;
        b1.h0 = param1b.getType();
        this.e.k0 = param1b.getReferencedIds();
        this.e.i0 = param1b.getMargin();
      } 
    }
    
    public void d(ConstraintLayout.b param1b) {
      d.b b1 = this.e;
      param1b.e = b1.j;
      param1b.f = b1.k;
      param1b.g = b1.l;
      param1b.h = b1.m;
      param1b.i = b1.n;
      param1b.j = b1.o;
      param1b.k = b1.p;
      param1b.l = b1.q;
      param1b.m = b1.r;
      param1b.n = b1.s;
      param1b.o = b1.t;
      param1b.s = b1.u;
      param1b.t = b1.v;
      param1b.u = b1.w;
      param1b.v = b1.x;
      param1b.leftMargin = b1.H;
      param1b.rightMargin = b1.I;
      param1b.topMargin = b1.J;
      param1b.bottomMargin = b1.K;
      param1b.A = b1.T;
      param1b.B = b1.S;
      param1b.x = b1.P;
      param1b.z = b1.R;
      param1b.G = b1.y;
      param1b.H = b1.z;
      param1b.p = b1.B;
      param1b.q = b1.C;
      param1b.r = b1.D;
      param1b.I = b1.A;
      param1b.X = b1.E;
      param1b.Y = b1.F;
      param1b.M = b1.V;
      param1b.L = b1.W;
      param1b.O = b1.Y;
      param1b.N = b1.X;
      param1b.a0 = b1.n0;
      param1b.b0 = b1.o0;
      param1b.P = b1.Z;
      param1b.Q = b1.a0;
      param1b.T = b1.b0;
      param1b.U = b1.c0;
      param1b.R = b1.d0;
      param1b.S = b1.e0;
      param1b.V = b1.f0;
      param1b.W = b1.g0;
      param1b.Z = b1.G;
      param1b.c = b1.h;
      param1b.a = b1.f;
      param1b.b = b1.g;
      param1b.width = b1.d;
      param1b.height = b1.e;
      String str = b1.m0;
      if (str != null)
        param1b.c0 = str; 
      param1b.d0 = b1.q0;
      param1b.setMarginStart(b1.M);
      param1b.setMarginEnd(this.e.L);
      param1b.a();
    }
    
    public a e() {
      a a1 = new a();
      a1.e.a(this.e);
      a1.d.a(this.d);
      a1.c.a(this.c);
      a1.f.a(this.f);
      a1.a = this.a;
      a1.h = this.h;
      return a1;
    }
    
    static class a {
      int[] a = new int[10];
      
      int[] b = new int[10];
      
      int c = 0;
      
      int[] d = new int[10];
      
      float[] e = new float[10];
      
      int f = 0;
      
      int[] g = new int[5];
      
      String[] h = new String[5];
      
      int i = 0;
      
      int[] j = new int[4];
      
      boolean[] k = new boolean[4];
      
      int l = 0;
      
      void a(int param2Int, float param2Float) {
        int i = this.f;
        int[] arrayOfInt = this.d;
        if (i >= arrayOfInt.length) {
          this.d = Arrays.copyOf(arrayOfInt, arrayOfInt.length * 2);
          float[] arrayOfFloat1 = this.e;
          this.e = Arrays.copyOf(arrayOfFloat1, arrayOfFloat1.length * 2);
        } 
        arrayOfInt = this.d;
        i = this.f;
        arrayOfInt[i] = param2Int;
        float[] arrayOfFloat = this.e;
        this.f = i + 1;
        arrayOfFloat[i] = param2Float;
      }
      
      void b(int param2Int1, int param2Int2) {
        int i = this.c;
        int[] arrayOfInt = this.a;
        if (i >= arrayOfInt.length) {
          this.a = Arrays.copyOf(arrayOfInt, arrayOfInt.length * 2);
          arrayOfInt = this.b;
          this.b = Arrays.copyOf(arrayOfInt, arrayOfInt.length * 2);
        } 
        arrayOfInt = this.a;
        i = this.c;
        arrayOfInt[i] = param2Int1;
        arrayOfInt = this.b;
        this.c = i + 1;
        arrayOfInt[i] = param2Int2;
      }
      
      void c(int param2Int, String param2String) {
        int i = this.i;
        int[] arrayOfInt = this.g;
        if (i >= arrayOfInt.length) {
          this.g = Arrays.copyOf(arrayOfInt, arrayOfInt.length * 2);
          String[] arrayOfString1 = this.h;
          this.h = Arrays.<String>copyOf(arrayOfString1, arrayOfString1.length * 2);
        } 
        arrayOfInt = this.g;
        i = this.i;
        arrayOfInt[i] = param2Int;
        String[] arrayOfString = this.h;
        this.i = i + 1;
        arrayOfString[i] = param2String;
      }
      
      void d(int param2Int, boolean param2Boolean) {
        int i = this.l;
        int[] arrayOfInt = this.j;
        if (i >= arrayOfInt.length) {
          this.j = Arrays.copyOf(arrayOfInt, arrayOfInt.length * 2);
          boolean[] arrayOfBoolean1 = this.k;
          this.k = Arrays.copyOf(arrayOfBoolean1, arrayOfBoolean1.length * 2);
        } 
        arrayOfInt = this.j;
        i = this.l;
        arrayOfInt[i] = param2Int;
        boolean[] arrayOfBoolean = this.k;
        this.l = i + 1;
        arrayOfBoolean[i] = param2Boolean;
      }
    }
  }
  
  static class a {
    int[] a = new int[10];
    
    int[] b = new int[10];
    
    int c = 0;
    
    int[] d = new int[10];
    
    float[] e = new float[10];
    
    int f = 0;
    
    int[] g = new int[5];
    
    String[] h = new String[5];
    
    int i = 0;
    
    int[] j = new int[4];
    
    boolean[] k = new boolean[4];
    
    int l = 0;
    
    void a(int param1Int, float param1Float) {
      int i = this.f;
      int[] arrayOfInt = this.d;
      if (i >= arrayOfInt.length) {
        this.d = Arrays.copyOf(arrayOfInt, arrayOfInt.length * 2);
        float[] arrayOfFloat1 = this.e;
        this.e = Arrays.copyOf(arrayOfFloat1, arrayOfFloat1.length * 2);
      } 
      arrayOfInt = this.d;
      i = this.f;
      arrayOfInt[i] = param1Int;
      float[] arrayOfFloat = this.e;
      this.f = i + 1;
      arrayOfFloat[i] = param1Float;
    }
    
    void b(int param1Int1, int param1Int2) {
      int i = this.c;
      int[] arrayOfInt = this.a;
      if (i >= arrayOfInt.length) {
        this.a = Arrays.copyOf(arrayOfInt, arrayOfInt.length * 2);
        arrayOfInt = this.b;
        this.b = Arrays.copyOf(arrayOfInt, arrayOfInt.length * 2);
      } 
      arrayOfInt = this.a;
      i = this.c;
      arrayOfInt[i] = param1Int1;
      arrayOfInt = this.b;
      this.c = i + 1;
      arrayOfInt[i] = param1Int2;
    }
    
    void c(int param1Int, String param1String) {
      int i = this.i;
      int[] arrayOfInt = this.g;
      if (i >= arrayOfInt.length) {
        this.g = Arrays.copyOf(arrayOfInt, arrayOfInt.length * 2);
        String[] arrayOfString1 = this.h;
        this.h = Arrays.<String>copyOf(arrayOfString1, arrayOfString1.length * 2);
      } 
      arrayOfInt = this.g;
      i = this.i;
      arrayOfInt[i] = param1Int;
      String[] arrayOfString = this.h;
      this.i = i + 1;
      arrayOfString[i] = param1String;
    }
    
    void d(int param1Int, boolean param1Boolean) {
      int i = this.l;
      int[] arrayOfInt = this.j;
      if (i >= arrayOfInt.length) {
        this.j = Arrays.copyOf(arrayOfInt, arrayOfInt.length * 2);
        boolean[] arrayOfBoolean1 = this.k;
        this.k = Arrays.copyOf(arrayOfBoolean1, arrayOfBoolean1.length * 2);
      } 
      arrayOfInt = this.j;
      i = this.l;
      arrayOfInt[i] = param1Int;
      boolean[] arrayOfBoolean = this.k;
      this.l = i + 1;
      arrayOfBoolean[i] = param1Boolean;
    }
  }
  
  public static class b {
    private static SparseIntArray r0;
    
    public String A = null;
    
    public int B = -1;
    
    public int C = 0;
    
    public float D = 0.0F;
    
    public int E = -1;
    
    public int F = -1;
    
    public int G = -1;
    
    public int H = 0;
    
    public int I = 0;
    
    public int J = 0;
    
    public int K = 0;
    
    public int L = 0;
    
    public int M = 0;
    
    public int N = 0;
    
    public int O = Integer.MIN_VALUE;
    
    public int P = Integer.MIN_VALUE;
    
    public int Q = Integer.MIN_VALUE;
    
    public int R = Integer.MIN_VALUE;
    
    public int S = Integer.MIN_VALUE;
    
    public int T = Integer.MIN_VALUE;
    
    public int U = Integer.MIN_VALUE;
    
    public float V = -1.0F;
    
    public float W = -1.0F;
    
    public int X = 0;
    
    public int Y = 0;
    
    public int Z = 0;
    
    public boolean a = false;
    
    public int a0 = 0;
    
    public boolean b = false;
    
    public int b0 = 0;
    
    public boolean c = false;
    
    public int c0 = 0;
    
    public int d;
    
    public int d0 = 0;
    
    public int e;
    
    public int e0 = 0;
    
    public int f = -1;
    
    public float f0 = 1.0F;
    
    public int g = -1;
    
    public float g0 = 1.0F;
    
    public float h = -1.0F;
    
    public int h0 = -1;
    
    public boolean i = true;
    
    public int i0 = 0;
    
    public int j = -1;
    
    public int j0 = -1;
    
    public int k = -1;
    
    public int[] k0;
    
    public int l = -1;
    
    public String l0;
    
    public int m = -1;
    
    public String m0;
    
    public int n = -1;
    
    public boolean n0 = false;
    
    public int o = -1;
    
    public boolean o0 = false;
    
    public int p = -1;
    
    public boolean p0 = true;
    
    public int q = -1;
    
    public int q0 = 0;
    
    public int r = -1;
    
    public int s = -1;
    
    public int t = -1;
    
    public int u = -1;
    
    public int v = -1;
    
    public int w = -1;
    
    public int x = -1;
    
    public float y = 0.5F;
    
    public float z = 0.5F;
    
    static {
      SparseIntArray sparseIntArray = new SparseIntArray();
      r0 = sparseIntArray;
      sparseIntArray.append(i.K5, 24);
      r0.append(i.L5, 25);
      r0.append(i.N5, 28);
      r0.append(i.O5, 29);
      r0.append(i.T5, 35);
      r0.append(i.S5, 34);
      r0.append(i.u5, 4);
      r0.append(i.t5, 3);
      r0.append(i.r5, 1);
      r0.append(i.Z5, 6);
      r0.append(i.a6, 7);
      r0.append(i.B5, 17);
      r0.append(i.C5, 18);
      r0.append(i.D5, 19);
      r0.append(i.n5, 90);
      r0.append(i.Z4, 26);
      r0.append(i.P5, 31);
      r0.append(i.Q5, 32);
      r0.append(i.A5, 10);
      r0.append(i.z5, 9);
      r0.append(i.d6, 13);
      r0.append(i.g6, 16);
      r0.append(i.e6, 14);
      r0.append(i.b6, 11);
      r0.append(i.f6, 15);
      r0.append(i.c6, 12);
      r0.append(i.W5, 38);
      r0.append(i.I5, 37);
      r0.append(i.H5, 39);
      r0.append(i.V5, 40);
      r0.append(i.G5, 20);
      r0.append(i.U5, 36);
      r0.append(i.y5, 5);
      r0.append(i.J5, 91);
      r0.append(i.R5, 91);
      r0.append(i.M5, 91);
      r0.append(i.s5, 91);
      r0.append(i.q5, 91);
      r0.append(i.c5, 23);
      r0.append(i.e5, 27);
      r0.append(i.g5, 30);
      r0.append(i.h5, 8);
      r0.append(i.d5, 33);
      r0.append(i.f5, 2);
      r0.append(i.a5, 22);
      r0.append(i.b5, 21);
      r0.append(i.X5, 41);
      r0.append(i.E5, 42);
      r0.append(i.p5, 41);
      r0.append(i.o5, 42);
      r0.append(i.h6, 76);
      r0.append(i.v5, 61);
      r0.append(i.x5, 62);
      r0.append(i.w5, 63);
      r0.append(i.Y5, 69);
      r0.append(i.F5, 70);
      r0.append(i.l5, 71);
      r0.append(i.j5, 72);
      r0.append(i.k5, 73);
      r0.append(i.m5, 74);
      r0.append(i.i5, 75);
    }
    
    public void a(b param1b) {
      this.a = param1b.a;
      this.d = param1b.d;
      this.b = param1b.b;
      this.e = param1b.e;
      this.f = param1b.f;
      this.g = param1b.g;
      this.h = param1b.h;
      this.i = param1b.i;
      this.j = param1b.j;
      this.k = param1b.k;
      this.l = param1b.l;
      this.m = param1b.m;
      this.n = param1b.n;
      this.o = param1b.o;
      this.p = param1b.p;
      this.q = param1b.q;
      this.r = param1b.r;
      this.s = param1b.s;
      this.t = param1b.t;
      this.u = param1b.u;
      this.v = param1b.v;
      this.w = param1b.w;
      this.x = param1b.x;
      this.y = param1b.y;
      this.z = param1b.z;
      this.A = param1b.A;
      this.B = param1b.B;
      this.C = param1b.C;
      this.D = param1b.D;
      this.E = param1b.E;
      this.F = param1b.F;
      this.G = param1b.G;
      this.H = param1b.H;
      this.I = param1b.I;
      this.J = param1b.J;
      this.K = param1b.K;
      this.L = param1b.L;
      this.M = param1b.M;
      this.N = param1b.N;
      this.O = param1b.O;
      this.P = param1b.P;
      this.Q = param1b.Q;
      this.R = param1b.R;
      this.S = param1b.S;
      this.T = param1b.T;
      this.U = param1b.U;
      this.V = param1b.V;
      this.W = param1b.W;
      this.X = param1b.X;
      this.Y = param1b.Y;
      this.Z = param1b.Z;
      this.a0 = param1b.a0;
      this.b0 = param1b.b0;
      this.c0 = param1b.c0;
      this.d0 = param1b.d0;
      this.e0 = param1b.e0;
      this.f0 = param1b.f0;
      this.g0 = param1b.g0;
      this.h0 = param1b.h0;
      this.i0 = param1b.i0;
      this.j0 = param1b.j0;
      this.m0 = param1b.m0;
      int[] arrayOfInt = param1b.k0;
      if (arrayOfInt != null && param1b.l0 == null) {
        this.k0 = Arrays.copyOf(arrayOfInt, arrayOfInt.length);
      } else {
        this.k0 = null;
      } 
      this.l0 = param1b.l0;
      this.n0 = param1b.n0;
      this.o0 = param1b.o0;
      this.p0 = param1b.p0;
      this.q0 = param1b.q0;
    }
    
    void b(Context param1Context, AttributeSet param1AttributeSet) {
      TypedArray typedArray = param1Context.obtainStyledAttributes(param1AttributeSet, i.Y4);
      this.b = true;
      int j = typedArray.getIndexCount();
      for (int i = 0; i < j; i++) {
        StringBuilder stringBuilder;
        int k = typedArray.getIndex(i);
        int m = r0.get(k);
        switch (m) {
          default:
            switch (m) {
              default:
                switch (m) {
                  default:
                    stringBuilder = new StringBuilder();
                    stringBuilder.append("Unknown attribute 0x");
                    stringBuilder.append(Integer.toHexString(k));
                    stringBuilder.append("   ");
                    stringBuilder.append(r0.get(k));
                    Log.w("ConstraintSet", stringBuilder.toString());
                    break;
                  case 91:
                    stringBuilder = new StringBuilder();
                    stringBuilder.append("unused attribute 0x");
                    stringBuilder.append(Integer.toHexString(k));
                    stringBuilder.append("   ");
                    stringBuilder.append(r0.get(k));
                    Log.w("ConstraintSet", stringBuilder.toString());
                    break;
                  case 90:
                    this.i = typedArray.getBoolean(k, this.i);
                    break;
                  case 89:
                    this.m0 = typedArray.getString(k);
                    break;
                  case 88:
                    this.o0 = typedArray.getBoolean(k, this.o0);
                    break;
                  case 87:
                    this.n0 = typedArray.getBoolean(k, this.n0);
                    break;
                  case 86:
                    this.d0 = typedArray.getDimensionPixelSize(k, this.d0);
                    break;
                  case 85:
                    this.e0 = typedArray.getDimensionPixelSize(k, this.e0);
                    break;
                  case 84:
                    this.b0 = typedArray.getDimensionPixelSize(k, this.b0);
                    break;
                  case 83:
                    this.c0 = typedArray.getDimensionPixelSize(k, this.c0);
                    break;
                  case 82:
                    this.a0 = typedArray.getInt(k, this.a0);
                    break;
                  case 81:
                    this.Z = typedArray.getInt(k, this.Z);
                    break;
                  case 80:
                    this.N = typedArray.getDimensionPixelSize(k, this.N);
                    break;
                  case 79:
                    this.U = typedArray.getDimensionPixelSize(k, this.U);
                    break;
                  case 78:
                    this.t = d.a(typedArray, k, this.t);
                    break;
                  case 77:
                    this.s = d.a(typedArray, k, this.s);
                    break;
                  case 76:
                    this.q0 = typedArray.getInt(k, this.q0);
                    break;
                  case 75:
                    this.p0 = typedArray.getBoolean(k, this.p0);
                    break;
                  case 74:
                    this.l0 = typedArray.getString(k);
                    break;
                  case 73:
                    this.i0 = typedArray.getDimensionPixelSize(k, this.i0);
                    break;
                  case 72:
                    this.h0 = typedArray.getInt(k, this.h0);
                    break;
                  case 71:
                    Log.e("ConstraintSet", "CURRENTLY UNSUPPORTED");
                    break;
                  case 70:
                    this.g0 = typedArray.getFloat(k, 1.0F);
                    break;
                  case 69:
                    break;
                } 
                this.f0 = typedArray.getFloat(k, 1.0F);
                break;
              case 63:
                this.D = typedArray.getFloat(k, this.D);
                break;
              case 62:
                this.C = typedArray.getDimensionPixelSize(k, this.C);
                break;
              case 61:
                break;
            } 
            this.B = d.a(typedArray, k, this.B);
            break;
          case 42:
            d.p(this, typedArray, k, 1);
            break;
          case 41:
            d.p(this, typedArray, k, 0);
            break;
          case 40:
            this.Y = typedArray.getInt(k, this.Y);
            break;
          case 39:
            this.X = typedArray.getInt(k, this.X);
            break;
          case 38:
            this.V = typedArray.getFloat(k, this.V);
            break;
          case 37:
            this.W = typedArray.getFloat(k, this.W);
            break;
          case 36:
            this.z = typedArray.getFloat(k, this.z);
            break;
          case 35:
            this.n = d.a(typedArray, k, this.n);
            break;
          case 34:
            this.o = d.a(typedArray, k, this.o);
            break;
          case 33:
            this.J = typedArray.getDimensionPixelSize(k, this.J);
            break;
          case 32:
            this.v = d.a(typedArray, k, this.v);
            break;
          case 31:
            this.u = d.a(typedArray, k, this.u);
            break;
          case 30:
            this.M = typedArray.getDimensionPixelSize(k, this.M);
            break;
          case 29:
            this.m = d.a(typedArray, k, this.m);
            break;
          case 28:
            this.l = d.a(typedArray, k, this.l);
            break;
          case 27:
            this.I = typedArray.getDimensionPixelSize(k, this.I);
            break;
          case 26:
            this.G = typedArray.getInt(k, this.G);
            break;
          case 25:
            this.k = d.a(typedArray, k, this.k);
            break;
          case 24:
            this.j = d.a(typedArray, k, this.j);
            break;
          case 23:
            this.H = typedArray.getDimensionPixelSize(k, this.H);
            break;
          case 22:
            this.d = typedArray.getLayoutDimension(k, this.d);
            break;
          case 21:
            this.e = typedArray.getLayoutDimension(k, this.e);
            break;
          case 20:
            this.y = typedArray.getFloat(k, this.y);
            break;
          case 19:
            this.h = typedArray.getFloat(k, this.h);
            break;
          case 18:
            this.g = typedArray.getDimensionPixelOffset(k, this.g);
            break;
          case 17:
            this.f = typedArray.getDimensionPixelOffset(k, this.f);
            break;
          case 16:
            this.P = typedArray.getDimensionPixelSize(k, this.P);
            break;
          case 15:
            this.T = typedArray.getDimensionPixelSize(k, this.T);
            break;
          case 14:
            this.Q = typedArray.getDimensionPixelSize(k, this.Q);
            break;
          case 13:
            this.O = typedArray.getDimensionPixelSize(k, this.O);
            break;
          case 12:
            this.S = typedArray.getDimensionPixelSize(k, this.S);
            break;
          case 11:
            this.R = typedArray.getDimensionPixelSize(k, this.R);
            break;
          case 10:
            this.w = d.a(typedArray, k, this.w);
            break;
          case 9:
            this.x = d.a(typedArray, k, this.x);
            break;
          case 8:
            this.L = typedArray.getDimensionPixelSize(k, this.L);
            break;
          case 7:
            this.F = typedArray.getDimensionPixelOffset(k, this.F);
            break;
          case 6:
            this.E = typedArray.getDimensionPixelOffset(k, this.E);
            break;
          case 5:
            this.A = typedArray.getString(k);
            break;
          case 4:
            this.p = d.a(typedArray, k, this.p);
            break;
          case 3:
            this.q = d.a(typedArray, k, this.q);
            break;
          case 2:
            this.K = typedArray.getDimensionPixelSize(k, this.K);
            break;
          case 1:
            this.r = d.a(typedArray, k, this.r);
            break;
        } 
      } 
      typedArray.recycle();
    }
  }
  
  public static class c {
    private static SparseIntArray o;
    
    public boolean a = false;
    
    public int b = -1;
    
    public int c = 0;
    
    public String d = null;
    
    public int e = -1;
    
    public int f = 0;
    
    public float g = Float.NaN;
    
    public int h = -1;
    
    public float i = Float.NaN;
    
    public float j = Float.NaN;
    
    public int k = -1;
    
    public String l = null;
    
    public int m = -3;
    
    public int n = -1;
    
    static {
      SparseIntArray sparseIntArray = new SparseIntArray();
      o = sparseIntArray;
      sparseIntArray.append(i.t6, 1);
      o.append(i.v6, 2);
      o.append(i.z6, 3);
      o.append(i.s6, 4);
      o.append(i.r6, 5);
      o.append(i.q6, 6);
      o.append(i.u6, 7);
      o.append(i.y6, 8);
      o.append(i.x6, 9);
      o.append(i.w6, 10);
    }
    
    public void a(c param1c) {
      this.a = param1c.a;
      this.b = param1c.b;
      this.d = param1c.d;
      this.e = param1c.e;
      this.f = param1c.f;
      this.i = param1c.i;
      this.g = param1c.g;
      this.h = param1c.h;
    }
    
    void b(Context param1Context, AttributeSet param1AttributeSet) {
      TypedArray typedArray = param1Context.obtainStyledAttributes(param1AttributeSet, i.p6);
      this.a = true;
      int j = typedArray.getIndexCount();
      for (int i = 0; i < j; i++) {
        int m;
        int k = typedArray.getIndex(i);
        switch (o.get(k)) {
          case 10:
            m = (typedArray.peekValue(k)).type;
            if (m == 1) {
              k = typedArray.getResourceId(k, -1);
              this.n = k;
              if (k != -1)
                this.m = -2; 
              break;
            } 
            if (m == 3) {
              String str = typedArray.getString(k);
              this.l = str;
              if (str.indexOf("/") > 0) {
                this.n = typedArray.getResourceId(k, -1);
                this.m = -2;
                break;
              } 
              this.m = -1;
              break;
            } 
            this.m = typedArray.getInteger(k, this.n);
            break;
          case 9:
            this.j = typedArray.getFloat(k, this.j);
            break;
          case 8:
            this.k = typedArray.getInteger(k, this.k);
            break;
          case 7:
            this.g = typedArray.getFloat(k, this.g);
            break;
          case 6:
            this.c = typedArray.getInteger(k, this.c);
            break;
          case 5:
            this.b = d.a(typedArray, k, this.b);
            break;
          case 4:
            this.f = typedArray.getInt(k, 0);
            break;
          case 3:
            if ((typedArray.peekValue(k)).type == 3) {
              this.d = typedArray.getString(k);
              break;
            } 
            this.d = n.b.c[typedArray.getInteger(k, 0)];
            break;
          case 2:
            this.e = typedArray.getInt(k, this.e);
            break;
          case 1:
            this.i = typedArray.getFloat(k, this.i);
            break;
        } 
      } 
      typedArray.recycle();
    }
  }
  
  public static class d {
    public boolean a = false;
    
    public int b = 0;
    
    public int c = 0;
    
    public float d = 1.0F;
    
    public float e = Float.NaN;
    
    public void a(d param1d) {
      this.a = param1d.a;
      this.b = param1d.b;
      this.d = param1d.d;
      this.e = param1d.e;
      this.c = param1d.c;
    }
    
    void b(Context param1Context, AttributeSet param1AttributeSet) {
      TypedArray typedArray = param1Context.obtainStyledAttributes(param1AttributeSet, i.M6);
      this.a = true;
      int j = typedArray.getIndexCount();
      for (int i = 0; i < j; i++) {
        int k = typedArray.getIndex(i);
        if (k == i.O6) {
          this.d = typedArray.getFloat(k, this.d);
        } else if (k == i.N6) {
          this.b = typedArray.getInt(k, this.b);
          this.b = d.b()[this.b];
        } else if (k == i.Q6) {
          this.c = typedArray.getInt(k, this.c);
        } else if (k == i.P6) {
          this.e = typedArray.getFloat(k, this.e);
        } 
      } 
      typedArray.recycle();
    }
  }
  
  public static class e {
    private static SparseIntArray o;
    
    public boolean a = false;
    
    public float b = 0.0F;
    
    public float c = 0.0F;
    
    public float d = 0.0F;
    
    public float e = 1.0F;
    
    public float f = 1.0F;
    
    public float g = Float.NaN;
    
    public float h = Float.NaN;
    
    public int i = -1;
    
    public float j = 0.0F;
    
    public float k = 0.0F;
    
    public float l = 0.0F;
    
    public boolean m = false;
    
    public float n = 0.0F;
    
    static {
      SparseIntArray sparseIntArray = new SparseIntArray();
      o = sparseIntArray;
      sparseIntArray.append(i.l7, 1);
      o.append(i.m7, 2);
      o.append(i.n7, 3);
      o.append(i.j7, 4);
      o.append(i.k7, 5);
      o.append(i.f7, 6);
      o.append(i.g7, 7);
      o.append(i.h7, 8);
      o.append(i.i7, 9);
      o.append(i.o7, 10);
      o.append(i.p7, 11);
      o.append(i.q7, 12);
    }
    
    public void a(e param1e) {
      this.a = param1e.a;
      this.b = param1e.b;
      this.c = param1e.c;
      this.d = param1e.d;
      this.e = param1e.e;
      this.f = param1e.f;
      this.g = param1e.g;
      this.h = param1e.h;
      this.i = param1e.i;
      this.j = param1e.j;
      this.k = param1e.k;
      this.l = param1e.l;
      this.m = param1e.m;
      this.n = param1e.n;
    }
    
    void b(Context param1Context, AttributeSet param1AttributeSet) {
      TypedArray typedArray = param1Context.obtainStyledAttributes(param1AttributeSet, i.e7);
      this.a = true;
      int j = typedArray.getIndexCount();
      for (int i = 0; i < j; i++) {
        int k = typedArray.getIndex(i);
        switch (o.get(k)) {
          case 12:
            this.i = d.a(typedArray, k, this.i);
            break;
          case 11:
            this.m = true;
            this.n = typedArray.getDimension(k, this.n);
            break;
          case 10:
            this.l = typedArray.getDimension(k, this.l);
            break;
          case 9:
            this.k = typedArray.getDimension(k, this.k);
            break;
          case 8:
            this.j = typedArray.getDimension(k, this.j);
            break;
          case 7:
            this.h = typedArray.getDimension(k, this.h);
            break;
          case 6:
            this.g = typedArray.getDimension(k, this.g);
            break;
          case 5:
            this.f = typedArray.getFloat(k, this.f);
            break;
          case 4:
            this.e = typedArray.getFloat(k, this.e);
            break;
          case 3:
            this.d = typedArray.getFloat(k, this.d);
            break;
          case 2:
            this.c = typedArray.getFloat(k, this.c);
            break;
          case 1:
            this.b = typedArray.getFloat(k, this.b);
            break;
        } 
      } 
      typedArray.recycle();
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Cricket Scorer-dex2jar.jar!\androidx\constraintlayout\widget\d.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */