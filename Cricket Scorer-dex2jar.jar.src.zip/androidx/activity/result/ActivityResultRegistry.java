package androidx.activity.result;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import androidx.core.app.g;
import androidx.lifecycle.m;
import androidx.lifecycle.r;
import androidx.lifecycle.u;
import androidx.lifecycle.v;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;
import java.util.Random;

public abstract class ActivityResultRegistry {
  private Random a = new Random();
  
  private final Map<Integer, String> b = new HashMap<Integer, String>();
  
  final Map<String, Integer> c = new HashMap<String, Integer>();
  
  private final Map<String, d> d = new HashMap<String, d>();
  
  ArrayList<String> e = new ArrayList<String>();
  
  final transient Map<String, c<?>> f = new HashMap<String, c<?>>();
  
  final Map<String, Object> g = new HashMap<String, Object>();
  
  final Bundle h = new Bundle();
  
  private void a(int paramInt, String paramString) {
    this.b.put(Integer.valueOf(paramInt), paramString);
    this.c.put(paramString, Integer.valueOf(paramInt));
  }
  
  private <O> void d(String paramString, int paramInt, Intent paramIntent, c<O> paramc) {
    if (paramc != null && paramc.a != null && this.e.contains(paramString)) {
      paramc.a.a((O)paramc.b.c(paramInt, paramIntent));
      this.e.remove(paramString);
      return;
    } 
    this.g.remove(paramString);
    this.h.putParcelable(paramString, new a(paramInt, paramIntent));
  }
  
  private int e() {
    int i = this.a.nextInt(2147418112);
    while (true) {
      i += 65536;
      if (this.b.containsKey(Integer.valueOf(i))) {
        i = this.a.nextInt(2147418112);
        continue;
      } 
      return i;
    } 
  }
  
  private void k(String paramString) {
    if ((Integer)this.c.get(paramString) != null)
      return; 
    a(e(), paramString);
  }
  
  public final boolean b(int paramInt1, int paramInt2, Intent paramIntent) {
    String str = this.b.get(Integer.valueOf(paramInt1));
    if (str == null)
      return false; 
    d(str, paramInt2, paramIntent, this.f.get(str));
    return true;
  }
  
  public final <O> boolean c(int paramInt, O paramO) {
    String str = this.b.get(Integer.valueOf(paramInt));
    if (str == null)
      return false; 
    c c = this.f.get(str);
    if (c != null) {
      b<O> b = c.a;
      if (b == null) {
        this.h.remove(str);
        this.g.put(str, paramO);
        return true;
      } 
      if (this.e.remove(str))
        b.a(paramO); 
      return true;
    } 
    this.h.remove(str);
    this.g.put(str, paramO);
    return true;
  }
  
  public abstract <I, O> void f(int paramInt, d.a<I, O> parama, I paramI, g paramg);
  
  public final void g(Bundle paramBundle) {
    if (paramBundle == null)
      return; 
    ArrayList<Integer> arrayList = paramBundle.getIntegerArrayList("KEY_COMPONENT_ACTIVITY_REGISTERED_RCS");
    ArrayList<String> arrayList1 = paramBundle.getStringArrayList("KEY_COMPONENT_ACTIVITY_REGISTERED_KEYS");
    if (arrayList1 != null) {
      if (arrayList == null)
        return; 
      this.e = paramBundle.getStringArrayList("KEY_COMPONENT_ACTIVITY_LAUNCHED_KEYS");
      this.a = (Random)paramBundle.getSerializable("KEY_COMPONENT_ACTIVITY_RANDOM_OBJECT");
      this.h.putAll(paramBundle.getBundle("KEY_COMPONENT_ACTIVITY_PENDING_RESULT"));
      for (int i = 0; i < arrayList1.size(); i++) {
        String str = arrayList1.get(i);
        if (this.c.containsKey(str)) {
          Integer integer = this.c.remove(str);
          if (!this.h.containsKey(str))
            this.b.remove(integer); 
        } 
        a(((Integer)arrayList.get(i)).intValue(), arrayList1.get(i));
      } 
    } 
  }
  
  public final void h(Bundle paramBundle) {
    paramBundle.putIntegerArrayList("KEY_COMPONENT_ACTIVITY_REGISTERED_RCS", new ArrayList(this.c.values()));
    paramBundle.putStringArrayList("KEY_COMPONENT_ACTIVITY_REGISTERED_KEYS", new ArrayList(this.c.keySet()));
    paramBundle.putStringArrayList("KEY_COMPONENT_ACTIVITY_LAUNCHED_KEYS", new ArrayList<String>(this.e));
    paramBundle.putBundle("KEY_COMPONENT_ACTIVITY_PENDING_RESULT", (Bundle)this.h.clone());
    paramBundle.putSerializable("KEY_COMPONENT_ACTIVITY_RANDOM_OBJECT", this.a);
  }
  
  public final <I, O> c<I> i(String paramString, v paramv, d.a<I, O> parama, b<O> paramb) {
    d d;
    m m = paramv.getLifecycle();
    if (!m.b().a(m.c.d)) {
      k(paramString);
      d d1 = this.d.get(paramString);
      d = d1;
      if (d1 == null)
        d = new d(m); 
      d.a(new r(this, paramString, paramb, parama) {
            public void c(v param1v, m.b param1b) {
              if (m.b.ON_START.equals(param1b)) {
                this.d.f.put(this.a, new ActivityResultRegistry.c(this.b, this.c));
                if (this.d.g.containsKey(this.a)) {
                  param1v = (v)this.d.g.get(this.a);
                  this.d.g.remove(this.a);
                  this.b.a(param1v);
                } 
                a a1 = (a)this.d.h.getParcelable(this.a);
                if (a1 != null) {
                  this.d.h.remove(this.a);
                  this.b.a(this.c.c(a1.b(), a1.a()));
                  return;
                } 
              } else {
                if (m.b.ON_STOP.equals(param1b)) {
                  this.d.f.remove(this.a);
                  return;
                } 
                if (m.b.ON_DESTROY.equals(param1b))
                  this.d.l(this.a); 
              } 
            }
          });
      this.d.put(paramString, d);
      return new a(this, paramString, parama);
    } 
    StringBuilder stringBuilder = new StringBuilder();
    stringBuilder.append("LifecycleOwner ");
    stringBuilder.append(d);
    stringBuilder.append(" is attempting to register while current state is ");
    stringBuilder.append(m.b());
    stringBuilder.append(". LifecycleOwners must call register before they are STARTED.");
    throw new IllegalStateException(stringBuilder.toString());
  }
  
  public final <I, O> c<I> j(String paramString, d.a<I, O> parama, b<O> paramb) {
    k(paramString);
    this.f.put(paramString, new c(paramb, parama));
    if (this.g.containsKey(paramString)) {
      Object object = this.g.get(paramString);
      this.g.remove(paramString);
      paramb.a((O)object);
    } 
    a a1 = (a)this.h.getParcelable(paramString);
    if (a1 != null) {
      this.h.remove(paramString);
      paramb.a((O)parama.c(a1.b(), a1.a()));
    } 
    return new b(this, paramString, parama);
  }
  
  final void l(String paramString) {
    if (!this.e.contains(paramString)) {
      Integer integer = this.c.remove(paramString);
      if (integer != null)
        this.b.remove(integer); 
    } 
    this.f.remove(paramString);
    if (this.g.containsKey(paramString)) {
      StringBuilder stringBuilder = new StringBuilder();
      stringBuilder.append("Dropping pending result for request ");
      stringBuilder.append(paramString);
      stringBuilder.append(": ");
      stringBuilder.append(this.g.get(paramString));
      Log.w("ActivityResultRegistry", stringBuilder.toString());
      this.g.remove(paramString);
    } 
    if (this.h.containsKey(paramString)) {
      StringBuilder stringBuilder = new StringBuilder();
      stringBuilder.append("Dropping pending result for request ");
      stringBuilder.append(paramString);
      stringBuilder.append(": ");
      stringBuilder.append(this.h.getParcelable(paramString));
      Log.w("ActivityResultRegistry", stringBuilder.toString());
      this.h.remove(paramString);
    } 
    d d = this.d.get(paramString);
    if (d != null) {
      d.b();
      this.d.remove(paramString);
    } 
  }
  
  class a extends c<I> {
    a(ActivityResultRegistry this$0, String param1String, d.a param1a) {}
    
    public void b(I param1I, g param1g) {
      Integer integer = this.c.c.get(this.a);
      if (integer != null) {
        this.c.e.add(this.a);
        try {
          this.c.f(integer.intValue(), this.b, param1I, param1g);
          return;
        } catch (Exception exception) {
          this.c.e.remove(this.a);
          throw exception;
        } 
      } 
      StringBuilder stringBuilder = new StringBuilder();
      stringBuilder.append("Attempting to launch an unregistered ActivityResultLauncher with contract ");
      stringBuilder.append(this.b);
      stringBuilder.append(" and input ");
      stringBuilder.append(exception);
      stringBuilder.append(". You must ensure the ActivityResultLauncher is registered before calling launch().");
      throw new IllegalStateException(stringBuilder.toString());
    }
    
    public void c() {
      this.c.l(this.a);
    }
  }
  
  class b extends c<I> {
    b(ActivityResultRegistry this$0, String param1String, d.a param1a) {}
    
    public void b(I param1I, g param1g) {
      Integer integer = this.c.c.get(this.a);
      if (integer != null) {
        this.c.e.add(this.a);
        try {
          this.c.f(integer.intValue(), this.b, param1I, param1g);
          return;
        } catch (Exception exception) {
          this.c.e.remove(this.a);
          throw exception;
        } 
      } 
      StringBuilder stringBuilder = new StringBuilder();
      stringBuilder.append("Attempting to launch an unregistered ActivityResultLauncher with contract ");
      stringBuilder.append(this.b);
      stringBuilder.append(" and input ");
      stringBuilder.append(exception);
      stringBuilder.append(". You must ensure the ActivityResultLauncher is registered before calling launch().");
      throw new IllegalStateException(stringBuilder.toString());
    }
    
    public void c() {
      this.c.l(this.a);
    }
  }
  
  private static class c<O> {
    final b<O> a;
    
    final d.a<?, O> b;
    
    c(b<O> param1b, d.a<?, O> param1a) {
      this.a = param1b;
      this.b = param1a;
    }
  }
  
  private static class d {
    final m a;
    
    private final ArrayList<r> b;
    
    d(m param1m) {
      this.a = param1m;
      this.b = new ArrayList<r>();
    }
    
    void a(r param1r) {
      this.a.a((u)param1r);
      this.b.add(param1r);
    }
    
    void b() {
      for (r r : this.b)
        this.a.c((u)r); 
      this.b.clear();
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Cricket Scorer-dex2jar.jar!\androidx\activity\result\ActivityResultRegistry.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */