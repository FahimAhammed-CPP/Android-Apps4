package androidx.activity.result;

import android.content.Intent;
import android.os.Parcel;
import android.os.Parcelable;

public final class a implements Parcelable {
  public static final Parcelable.Creator<a> CREATOR = new a();
  
  private final int a;
  
  private final Intent b;
  
  public a(int paramInt, Intent paramIntent) {
    this.a = paramInt;
    this.b = paramIntent;
  }
  
  a(Parcel paramParcel) {
    Intent intent;
    this.a = paramParcel.readInt();
    if (paramParcel.readInt() == 0) {
      paramParcel = null;
    } else {
      intent = (Intent)Intent.CREATOR.createFromParcel(paramParcel);
    } 
    this.b = intent;
  }
  
  public static String c(int paramInt) {
    return (paramInt != -1) ? ((paramInt != 0) ? String.valueOf(paramInt) : "RESULT_CANCELED") : "RESULT_OK";
  }
  
  public Intent a() {
    return this.b;
  }
  
  public int b() {
    return this.a;
  }
  
  public int describeContents() {
    return 0;
  }
  
  public String toString() {
    StringBuilder stringBuilder = new StringBuilder();
    stringBuilder.append("ActivityResult{resultCode=");
    stringBuilder.append(c(this.a));
    stringBuilder.append(", data=");
    stringBuilder.append(this.b);
    stringBuilder.append('}');
    return stringBuilder.toString();
  }
  
  public void writeToParcel(Parcel paramParcel, int paramInt) {
    boolean bool;
    paramParcel.writeInt(this.a);
    if (this.b == null) {
      bool = false;
    } else {
      bool = true;
    } 
    paramParcel.writeInt(bool);
    Intent intent = this.b;
    if (intent != null)
      intent.writeToParcel(paramParcel, paramInt); 
  }
  
  class a implements Parcelable.Creator<a> {
    public a a(Parcel param1Parcel) {
      return new a(param1Parcel);
    }
    
    public a[] b(int param1Int) {
      return new a[param1Int];
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Cricket Scorer-dex2jar.jar!\androidx\activity\result\a.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */