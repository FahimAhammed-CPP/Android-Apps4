package androidx.activity.result;

import android.content.Intent;
import android.content.IntentSender;
import android.os.Parcel;
import android.os.Parcelable;

public final class e implements Parcelable {
  public static final Parcelable.Creator<e> CREATOR = new a();
  
  private final IntentSender a;
  
  private final Intent b;
  
  private final int c;
  
  private final int d;
  
  e(IntentSender paramIntentSender, Intent paramIntent, int paramInt1, int paramInt2) {
    this.a = paramIntentSender;
    this.b = paramIntent;
    this.c = paramInt1;
    this.d = paramInt2;
  }
  
  e(Parcel paramParcel) {
    this.a = (IntentSender)paramParcel.readParcelable(IntentSender.class.getClassLoader());
    this.b = (Intent)paramParcel.readParcelable(Intent.class.getClassLoader());
    this.c = paramParcel.readInt();
    this.d = paramParcel.readInt();
  }
  
  public Intent a() {
    return this.b;
  }
  
  public int b() {
    return this.c;
  }
  
  public int c() {
    return this.d;
  }
  
  public IntentSender d() {
    return this.a;
  }
  
  public int describeContents() {
    return 0;
  }
  
  public void writeToParcel(Parcel paramParcel, int paramInt) {
    paramParcel.writeParcelable((Parcelable)this.a, paramInt);
    paramParcel.writeParcelable((Parcelable)this.b, paramInt);
    paramParcel.writeInt(this.c);
    paramParcel.writeInt(this.d);
  }
  
  class a implements Parcelable.Creator<e> {
    public e a(Parcel param1Parcel) {
      return new e(param1Parcel);
    }
    
    public e[] b(int param1Int) {
      return new e[param1Int];
    }
  }
  
  public static final class b {
    private IntentSender a;
    
    private Intent b;
    
    private int c;
    
    private int d;
    
    public b(IntentSender param1IntentSender) {
      this.a = param1IntentSender;
    }
    
    public e a() {
      return new e(this.a, this.b, this.c, this.d);
    }
    
    public b b(Intent param1Intent) {
      this.b = param1Intent;
      return this;
    }
    
    public b c(int param1Int1, int param1Int2) {
      this.d = param1Int1;
      this.c = param1Int2;
      return this;
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Cricket Scorer-dex2jar.jar!\androidx\activity\result\e.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */