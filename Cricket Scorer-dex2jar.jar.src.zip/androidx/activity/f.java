package androidx.activity;

import android.app.Dialog;
import android.content.Context;
import android.os.Bundle;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import androidx.lifecycle.m;
import androidx.lifecycle.v;
import androidx.lifecycle.x;
import androidx.lifecycle.z0;
import m8.k;

public class f extends Dialog implements v, h {
  private x a;
  
  private final OnBackPressedDispatcher b = new OnBackPressedDispatcher(new e(this));
  
  public f(Context paramContext, int paramInt) {
    super(paramContext, paramInt);
  }
  
  private final x b() {
    x x2 = this.a;
    x x1 = x2;
    if (x2 == null) {
      x1 = new x(this);
      this.a = x1;
    } 
    return x1;
  }
  
  private final void c() {
    Window window = getWindow();
    k.c(window);
    z0.a(window.getDecorView(), this);
    window = getWindow();
    k.c(window);
    View view = window.getDecorView();
    k.e(view, "window!!.decorView");
    j.a(view, this);
  }
  
  private static final void d(f paramf) {
    k.f(paramf, "this$0");
    paramf.onBackPressed();
  }
  
  public void addContentView(View paramView, ViewGroup.LayoutParams paramLayoutParams) {
    k.f(paramView, "view");
    c();
    super.addContentView(paramView, paramLayoutParams);
  }
  
  public final m getLifecycle() {
    return (m)b();
  }
  
  public final OnBackPressedDispatcher getOnBackPressedDispatcher() {
    return this.b;
  }
  
  public void onBackPressed() {
    this.b.c();
  }
  
  protected void onCreate(Bundle paramBundle) {
    super.onCreate(paramBundle);
    b().h(m.b.ON_CREATE);
  }
  
  protected void onStart() {
    super.onStart();
    b().h(m.b.ON_RESUME);
  }
  
  protected void onStop() {
    b().h(m.b.ON_DESTROY);
    this.a = null;
    super.onStop();
  }
  
  public void setContentView(int paramInt) {
    c();
    super.setContentView(paramInt);
  }
  
  public void setContentView(View paramView) {
    k.f(paramView, "view");
    c();
    super.setContentView(paramView);
  }
  
  public void setContentView(View paramView, ViewGroup.LayoutParams paramLayoutParams) {
    k.f(paramView, "view");
    c();
    super.setContentView(paramView, paramLayoutParams);
  }
}


/* Location:              C:\soft\dex2jar-2.0\Cricket Scorer-dex2jar.jar!\androidx\activity\f.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */