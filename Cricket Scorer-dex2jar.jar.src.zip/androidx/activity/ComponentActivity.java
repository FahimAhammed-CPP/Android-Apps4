package androidx.activity;

import android.app.Activity;
import android.app.Application;
import android.content.Context;
import android.content.Intent;
import android.content.IntentSender;
import android.content.res.Configuration;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.text.TextUtils;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import androidx.activity.result.ActivityResultRegistry;
import androidx.activity.result.b;
import androidx.activity.result.c;
import androidx.activity.result.d;
import androidx.activity.result.e;
import androidx.core.app.a1;
import androidx.core.app.g;
import androidx.core.app.o;
import androidx.core.app.s;
import androidx.core.app.x0;
import androidx.core.app.y0;
import androidx.core.content.k;
import androidx.core.content.l;
import androidx.core.view.b0;
import androidx.core.view.j;
import androidx.core.view.m;
import androidx.lifecycle.a1;
import androidx.lifecycle.j0;
import androidx.lifecycle.l;
import androidx.lifecycle.m;
import androidx.lifecycle.m0;
import androidx.lifecycle.p0;
import androidx.lifecycle.r;
import androidx.lifecycle.u;
import androidx.lifecycle.u0;
import androidx.lifecycle.v;
import androidx.lifecycle.x;
import androidx.lifecycle.x0;
import androidx.lifecycle.y0;
import androidx.lifecycle.z0;
import java.io.Serializable;
import java.util.Iterator;
import java.util.concurrent.CopyOnWriteArrayList;
import java.util.concurrent.atomic.AtomicInteger;
import o0.e;
import o0.f;

public class ComponentActivity extends o implements y0, l, e, h, d, k, l, x0, y0, j {
  private static final String ACTIVITY_RESULT_TAG = "android:support:activity-result";
  
  private final ActivityResultRegistry mActivityResultRegistry;
  
  private int mContentLayoutId;
  
  final c.a mContextAwareHelper = new c.a();
  
  private u0.b mDefaultFactory;
  
  private final x mLifecycleRegistry = new x(this);
  
  private final m mMenuHostHelper = new m(new b(this));
  
  private final AtomicInteger mNextLocalRequestCode;
  
  private final OnBackPressedDispatcher mOnBackPressedDispatcher;
  
  private final CopyOnWriteArrayList<androidx.core.util.a<Configuration>> mOnConfigurationChangedListeners;
  
  private final CopyOnWriteArrayList<androidx.core.util.a<s>> mOnMultiWindowModeChangedListeners;
  
  private final CopyOnWriteArrayList<androidx.core.util.a<Intent>> mOnNewIntentListeners;
  
  private final CopyOnWriteArrayList<androidx.core.util.a<a1>> mOnPictureInPictureModeChangedListeners;
  
  private final CopyOnWriteArrayList<androidx.core.util.a<Integer>> mOnTrimMemoryListeners;
  
  final o0.d mSavedStateRegistryController;
  
  private x0 mViewModelStore;
  
  public ComponentActivity() {
    o0.d d1 = o0.d.a(this);
    this.mSavedStateRegistryController = d1;
    this.mOnBackPressedDispatcher = new OnBackPressedDispatcher(new a(this));
    this.mNextLocalRequestCode = new AtomicInteger();
    this.mActivityResultRegistry = new b(this);
    this.mOnConfigurationChangedListeners = new CopyOnWriteArrayList<androidx.core.util.a<Configuration>>();
    this.mOnTrimMemoryListeners = new CopyOnWriteArrayList<androidx.core.util.a<Integer>>();
    this.mOnNewIntentListeners = new CopyOnWriteArrayList<androidx.core.util.a<Intent>>();
    this.mOnMultiWindowModeChangedListeners = new CopyOnWriteArrayList<androidx.core.util.a<s>>();
    this.mOnPictureInPictureModeChangedListeners = new CopyOnWriteArrayList<androidx.core.util.a<a1>>();
    if (getLifecycle() != null) {
      int i = Build.VERSION.SDK_INT;
      getLifecycle().a((u)new r(this) {
            public void c(v param1v, m.b param1b) {
              if (param1b == m.b.ON_STOP) {
                Window window = this.a.getWindow();
                if (window != null) {
                  View view = window.peekDecorView();
                } else {
                  window = null;
                } 
                if (window != null)
                  ComponentActivity.c.a((View)window); 
              } 
            }
          });
      getLifecycle().a((u)new r(this) {
            public void c(v param1v, m.b param1b) {
              if (param1b == m.b.ON_DESTROY) {
                this.a.mContextAwareHelper.b();
                if (!this.a.isChangingConfigurations())
                  this.a.getViewModelStore().a(); 
              } 
            }
          });
      getLifecycle().a((u)new r(this) {
            public void c(v param1v, m.b param1b) {
              this.a.ensureViewModelStore();
              this.a.getLifecycle().c((u)this);
            }
          });
      d1.c();
      m0.c(this);
      if (i <= 23)
        getLifecycle().a((u)new ImmLeaksCleaner((Activity)this)); 
      getSavedStateRegistry().h("android:support:activity-result", new c(this));
      addOnContextAvailableListener(new d(this));
      return;
    } 
    throw new IllegalStateException("getLifecycle() returned null in ComponentActivity's constructor. Please make sure you are lazily constructing your Lifecycle in the first call to getLifecycle() rather than relying on field initialization.");
  }
  
  public ComponentActivity(int paramInt) {
    this();
    this.mContentLayoutId = paramInt;
  }
  
  private void initViewTreeOwners() {
    z0.a(getWindow().getDecorView(), this);
    a1.a(getWindow().getDecorView(), this);
    f.a(getWindow().getDecorView(), this);
    j.a(getWindow().getDecorView(), this);
  }
  
  public void addContentView(View paramView, ViewGroup.LayoutParams paramLayoutParams) {
    initViewTreeOwners();
    super.addContentView(paramView, paramLayoutParams);
  }
  
  public void addMenuProvider(b0 paramb0) {
    this.mMenuHostHelper.c(paramb0);
  }
  
  public void addMenuProvider(b0 paramb0, v paramv) {
    this.mMenuHostHelper.d(paramb0, paramv);
  }
  
  public void addMenuProvider(b0 paramb0, v paramv, m.c paramc) {
    this.mMenuHostHelper.e(paramb0, paramv, paramc);
  }
  
  public final void addOnConfigurationChangedListener(androidx.core.util.a<Configuration> parama) {
    this.mOnConfigurationChangedListeners.add(parama);
  }
  
  public final void addOnContextAvailableListener(c.b paramb) {
    this.mContextAwareHelper.a(paramb);
  }
  
  public final void addOnMultiWindowModeChangedListener(androidx.core.util.a<s> parama) {
    this.mOnMultiWindowModeChangedListeners.add(parama);
  }
  
  public final void addOnNewIntentListener(androidx.core.util.a<Intent> parama) {
    this.mOnNewIntentListeners.add(parama);
  }
  
  public final void addOnPictureInPictureModeChangedListener(androidx.core.util.a<a1> parama) {
    this.mOnPictureInPictureModeChangedListeners.add(parama);
  }
  
  public final void addOnTrimMemoryListener(androidx.core.util.a<Integer> parama) {
    this.mOnTrimMemoryListeners.add(parama);
  }
  
  void ensureViewModelStore() {
    if (this.mViewModelStore == null) {
      d d1 = (d)getLastNonConfigurationInstance();
      if (d1 != null)
        this.mViewModelStore = d1.b; 
      if (this.mViewModelStore == null)
        this.mViewModelStore = new x0(); 
    } 
  }
  
  public final ActivityResultRegistry getActivityResultRegistry() {
    return this.mActivityResultRegistry;
  }
  
  public f0.a getDefaultViewModelCreationExtras() {
    f0.d d1 = new f0.d();
    if (getApplication() != null)
      d1.c(u0.a.g, getApplication()); 
    d1.c(m0.a, this);
    d1.c(m0.b, this);
    if (getIntent() != null && getIntent().getExtras() != null)
      d1.c(m0.c, getIntent().getExtras()); 
    return (f0.a)d1;
  }
  
  public u0.b getDefaultViewModelProviderFactory() {
    if (this.mDefaultFactory == null) {
      Bundle bundle;
      Application application = getApplication();
      if (getIntent() != null) {
        bundle = getIntent().getExtras();
      } else {
        bundle = null;
      } 
      this.mDefaultFactory = (u0.b)new p0(application, this, bundle);
    } 
    return this.mDefaultFactory;
  }
  
  @Deprecated
  public Object getLastCustomNonConfigurationInstance() {
    d d1 = (d)getLastNonConfigurationInstance();
    return (d1 != null) ? d1.a : null;
  }
  
  public m getLifecycle() {
    return (m)this.mLifecycleRegistry;
  }
  
  public final OnBackPressedDispatcher getOnBackPressedDispatcher() {
    return this.mOnBackPressedDispatcher;
  }
  
  public final o0.c getSavedStateRegistry() {
    return this.mSavedStateRegistryController.b();
  }
  
  public x0 getViewModelStore() {
    if (getApplication() != null) {
      ensureViewModelStore();
      return this.mViewModelStore;
    } 
    throw new IllegalStateException("Your activity is not yet attached to the Application instance. You can't request ViewModel before onCreate call.");
  }
  
  public void invalidateMenu() {
    invalidateOptionsMenu();
  }
  
  @Deprecated
  protected void onActivityResult(int paramInt1, int paramInt2, Intent paramIntent) {
    if (!this.mActivityResultRegistry.b(paramInt1, paramInt2, paramIntent))
      super.onActivityResult(paramInt1, paramInt2, paramIntent); 
  }
  
  public void onBackPressed() {
    this.mOnBackPressedDispatcher.c();
  }
  
  public void onConfigurationChanged(Configuration paramConfiguration) {
    super.onConfigurationChanged(paramConfiguration);
    Iterator<androidx.core.util.a<Configuration>> iterator = this.mOnConfigurationChangedListeners.iterator();
    while (iterator.hasNext())
      ((androidx.core.util.a)iterator.next()).accept(paramConfiguration); 
  }
  
  protected void onCreate(Bundle paramBundle) {
    this.mSavedStateRegistryController.d(paramBundle);
    this.mContextAwareHelper.c((Context)this);
    super.onCreate(paramBundle);
    j0.g((Activity)this);
    int i = this.mContentLayoutId;
    if (i != 0)
      setContentView(i); 
  }
  
  public boolean onCreatePanelMenu(int paramInt, Menu paramMenu) {
    if (paramInt == 0) {
      super.onCreatePanelMenu(paramInt, paramMenu);
      this.mMenuHostHelper.h(paramMenu, getMenuInflater());
    } 
    return true;
  }
  
  public boolean onMenuItemSelected(int paramInt, MenuItem paramMenuItem) {
    return super.onMenuItemSelected(paramInt, paramMenuItem) ? true : ((paramInt == 0) ? this.mMenuHostHelper.j(paramMenuItem) : false);
  }
  
  public void onMultiWindowModeChanged(boolean paramBoolean) {
    Iterator<androidx.core.util.a<s>> iterator = this.mOnMultiWindowModeChangedListeners.iterator();
    while (iterator.hasNext())
      ((androidx.core.util.a)iterator.next()).accept(new s(paramBoolean)); 
  }
  
  public void onMultiWindowModeChanged(boolean paramBoolean, Configuration paramConfiguration) {
    Iterator<androidx.core.util.a<s>> iterator = this.mOnMultiWindowModeChangedListeners.iterator();
    while (iterator.hasNext())
      ((androidx.core.util.a)iterator.next()).accept(new s(paramBoolean, paramConfiguration)); 
  }
  
  protected void onNewIntent(Intent paramIntent) {
    super.onNewIntent(paramIntent);
    Iterator<androidx.core.util.a<Intent>> iterator = this.mOnNewIntentListeners.iterator();
    while (iterator.hasNext())
      ((androidx.core.util.a)iterator.next()).accept(paramIntent); 
  }
  
  public void onPanelClosed(int paramInt, Menu paramMenu) {
    this.mMenuHostHelper.i(paramMenu);
    super.onPanelClosed(paramInt, paramMenu);
  }
  
  public void onPictureInPictureModeChanged(boolean paramBoolean) {
    Iterator<androidx.core.util.a<a1>> iterator = this.mOnPictureInPictureModeChangedListeners.iterator();
    while (iterator.hasNext())
      ((androidx.core.util.a)iterator.next()).accept(new a1(paramBoolean)); 
  }
  
  public void onPictureInPictureModeChanged(boolean paramBoolean, Configuration paramConfiguration) {
    Iterator<androidx.core.util.a<a1>> iterator = this.mOnPictureInPictureModeChangedListeners.iterator();
    while (iterator.hasNext())
      ((androidx.core.util.a)iterator.next()).accept(new a1(paramBoolean, paramConfiguration)); 
  }
  
  public boolean onPreparePanel(int paramInt, View paramView, Menu paramMenu) {
    if (paramInt == 0) {
      super.onPreparePanel(paramInt, paramView, paramMenu);
      this.mMenuHostHelper.k(paramMenu);
    } 
    return true;
  }
  
  @Deprecated
  public void onRequestPermissionsResult(int paramInt, String[] paramArrayOfString, int[] paramArrayOfint) {
    if (!this.mActivityResultRegistry.b(paramInt, -1, (new Intent()).putExtra("androidx.activity.result.contract.extra.PERMISSIONS", paramArrayOfString).putExtra("androidx.activity.result.contract.extra.PERMISSION_GRANT_RESULTS", paramArrayOfint)) && Build.VERSION.SDK_INT >= 23)
      super.onRequestPermissionsResult(paramInt, paramArrayOfString, paramArrayOfint); 
  }
  
  @Deprecated
  public Object onRetainCustomNonConfigurationInstance() {
    return null;
  }
  
  public final Object onRetainNonConfigurationInstance() {
    Object object = onRetainCustomNonConfigurationInstance();
    x0 x02 = this.mViewModelStore;
    x0 x01 = x02;
    if (x02 == null) {
      d d2 = (d)getLastNonConfigurationInstance();
      x01 = x02;
      if (d2 != null)
        x01 = d2.b; 
    } 
    if (x01 == null && object == null)
      return null; 
    d d1 = new d();
    d1.a = object;
    d1.b = x01;
    return d1;
  }
  
  protected void onSaveInstanceState(Bundle paramBundle) {
    m m1 = getLifecycle();
    if (m1 instanceof x)
      ((x)m1).o(m.c.c); 
    super.onSaveInstanceState(paramBundle);
    this.mSavedStateRegistryController.e(paramBundle);
  }
  
  public void onTrimMemory(int paramInt) {
    super.onTrimMemory(paramInt);
    Iterator<androidx.core.util.a<Integer>> iterator = this.mOnTrimMemoryListeners.iterator();
    while (iterator.hasNext())
      ((androidx.core.util.a)iterator.next()).accept(Integer.valueOf(paramInt)); 
  }
  
  public Context peekAvailableContext() {
    return this.mContextAwareHelper.d();
  }
  
  public final <I, O> c<I> registerForActivityResult(d.a<I, O> parama, ActivityResultRegistry paramActivityResultRegistry, b<O> paramb) {
    StringBuilder stringBuilder = new StringBuilder();
    stringBuilder.append("activity_rq#");
    stringBuilder.append(this.mNextLocalRequestCode.getAndIncrement());
    return paramActivityResultRegistry.i(stringBuilder.toString(), this, parama, paramb);
  }
  
  public final <I, O> c<I> registerForActivityResult(d.a<I, O> parama, b<O> paramb) {
    return registerForActivityResult(parama, this.mActivityResultRegistry, paramb);
  }
  
  public void removeMenuProvider(b0 paramb0) {
    this.mMenuHostHelper.l(paramb0);
  }
  
  public final void removeOnConfigurationChangedListener(androidx.core.util.a<Configuration> parama) {
    this.mOnConfigurationChangedListeners.remove(parama);
  }
  
  public final void removeOnContextAvailableListener(c.b paramb) {
    this.mContextAwareHelper.e(paramb);
  }
  
  public final void removeOnMultiWindowModeChangedListener(androidx.core.util.a<s> parama) {
    this.mOnMultiWindowModeChangedListeners.remove(parama);
  }
  
  public final void removeOnNewIntentListener(androidx.core.util.a<Intent> parama) {
    this.mOnNewIntentListeners.remove(parama);
  }
  
  public final void removeOnPictureInPictureModeChangedListener(androidx.core.util.a<a1> parama) {
    this.mOnPictureInPictureModeChangedListeners.remove(parama);
  }
  
  public final void removeOnTrimMemoryListener(androidx.core.util.a<Integer> parama) {
    this.mOnTrimMemoryListeners.remove(parama);
  }
  
  public void reportFullyDrawn() {
    try {
      if (t0.b.d())
        t0.b.a("reportFullyDrawn() for ComponentActivity"); 
      super.reportFullyDrawn();
      return;
    } finally {
      t0.b.b();
    } 
  }
  
  public void setContentView(int paramInt) {
    initViewTreeOwners();
    super.setContentView(paramInt);
  }
  
  public void setContentView(View paramView) {
    initViewTreeOwners();
    super.setContentView(paramView);
  }
  
  public void setContentView(View paramView, ViewGroup.LayoutParams paramLayoutParams) {
    initViewTreeOwners();
    super.setContentView(paramView, paramLayoutParams);
  }
  
  @Deprecated
  public void startActivityForResult(Intent paramIntent, int paramInt) {
    super.startActivityForResult(paramIntent, paramInt);
  }
  
  @Deprecated
  public void startActivityForResult(Intent paramIntent, int paramInt, Bundle paramBundle) {
    super.startActivityForResult(paramIntent, paramInt, paramBundle);
  }
  
  @Deprecated
  public void startIntentSenderForResult(IntentSender paramIntentSender, int paramInt1, Intent paramIntent, int paramInt2, int paramInt3, int paramInt4) throws IntentSender.SendIntentException {
    super.startIntentSenderForResult(paramIntentSender, paramInt1, paramIntent, paramInt2, paramInt3, paramInt4);
  }
  
  @Deprecated
  public void startIntentSenderForResult(IntentSender paramIntentSender, int paramInt1, Intent paramIntent, int paramInt2, int paramInt3, int paramInt4, Bundle paramBundle) throws IntentSender.SendIntentException {
    super.startIntentSenderForResult(paramIntentSender, paramInt1, paramIntent, paramInt2, paramInt3, paramInt4, paramBundle);
  }
  
  class a implements Runnable {
    a(ComponentActivity this$0) {}
    
    public void run() {
      try {
        this.a.onBackPressed();
        return;
      } catch (IllegalStateException illegalStateException) {
        if (TextUtils.equals(illegalStateException.getMessage(), "Can not perform this action after onSaveInstanceState"))
          return; 
        throw illegalStateException;
      } 
    }
  }
  
  class b extends ActivityResultRegistry {
    b(ComponentActivity this$0) {}
    
    public <I, O> void f(int param1Int, d.a<I, O> param1a, I param1I, g param1g) {
      String[] arrayOfString1;
      String[] arrayOfString2;
      e e;
      ComponentActivity componentActivity = this.i;
      d.a.a a1 = param1a.b((Context)componentActivity, param1I);
      if (a1 != null) {
        (new Handler(Looper.getMainLooper())).post(new a(this, param1Int, a1));
        return;
      } 
      Intent intent = param1a.a((Context)componentActivity, param1I);
      param1a = null;
      if (intent.getExtras() != null && intent.getExtras().getClassLoader() == null)
        intent.setExtrasClassLoader(componentActivity.getClassLoader()); 
      if (intent.hasExtra("androidx.activity.result.contract.extra.ACTIVITY_OPTIONS_BUNDLE")) {
        Bundle bundle = intent.getBundleExtra("androidx.activity.result.contract.extra.ACTIVITY_OPTIONS_BUNDLE");
        intent.removeExtra("androidx.activity.result.contract.extra.ACTIVITY_OPTIONS_BUNDLE");
      } else if (param1g != null) {
        Bundle bundle = param1g.a();
      } 
      if ("androidx.activity.result.contract.action.REQUEST_PERMISSIONS".equals(intent.getAction())) {
        arrayOfString2 = intent.getStringArrayExtra("androidx.activity.result.contract.extra.PERMISSIONS");
        arrayOfString1 = arrayOfString2;
        if (arrayOfString2 == null)
          arrayOfString1 = new String[0]; 
        androidx.core.app.b.g((Activity)componentActivity, arrayOfString1, param1Int);
        return;
      } 
      if ("androidx.activity.result.contract.action.INTENT_SENDER_REQUEST".equals(arrayOfString2.getAction())) {
        e = (e)arrayOfString2.getParcelableExtra("androidx.activity.result.contract.extra.INTENT_SENDER_REQUEST");
        try {
          androidx.core.app.b.m((Activity)componentActivity, e.d(), param1Int, e.a(), e.b(), e.c(), 0, (Bundle)arrayOfString1);
          return;
        } catch (android.content.IntentSender.SendIntentException sendIntentException) {
          (new Handler(Looper.getMainLooper())).post(new b(this, param1Int, sendIntentException));
          return;
        } 
      } 
      androidx.core.app.b.l((Activity)componentActivity, (Intent)e, param1Int, (Bundle)sendIntentException);
    }
    
    class a implements Runnable {
      a(ComponentActivity.b this$0, int param2Int, d.a.a param2a) {}
      
      public void run() {
        this.c.c(this.a, this.b.a());
      }
    }
    
    class b implements Runnable {
      b(ComponentActivity.b this$0, int param2Int, IntentSender.SendIntentException param2SendIntentException) {}
      
      public void run() {
        this.c.b(this.a, 0, (new Intent()).setAction("androidx.activity.result.contract.action.INTENT_SENDER_REQUEST").putExtra("androidx.activity.result.contract.extra.SEND_INTENT_EXCEPTION", (Serializable)this.b));
      }
    }
  }
  
  class a implements Runnable {
    a(ComponentActivity this$0, int param1Int, d.a.a param1a) {}
    
    public void run() {
      this.c.c(this.a, this.b.a());
    }
  }
  
  class b implements Runnable {
    b(ComponentActivity this$0, int param1Int, IntentSender.SendIntentException param1SendIntentException) {}
    
    public void run() {
      this.c.b(this.a, 0, (new Intent()).setAction("androidx.activity.result.contract.action.INTENT_SENDER_REQUEST").putExtra("androidx.activity.result.contract.extra.SEND_INTENT_EXCEPTION", (Serializable)this.b));
    }
  }
  
  static class c {
    static void a(View param1View) {
      param1View.cancelPendingInputEvents();
    }
  }
  
  static final class d {
    Object a;
    
    x0 b;
  }
}


/* Location:              C:\soft\dex2jar-2.0\Cricket Scorer-dex2jar.jar!\androidx\activity\ComponentActivity.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */