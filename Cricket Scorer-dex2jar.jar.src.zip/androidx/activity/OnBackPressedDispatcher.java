package androidx.activity;

import androidx.lifecycle.m;
import androidx.lifecycle.r;
import androidx.lifecycle.u;
import androidx.lifecycle.v;
import java.util.ArrayDeque;
import java.util.Iterator;

public final class OnBackPressedDispatcher {
  private final Runnable a;
  
  final ArrayDeque<g> b = new ArrayDeque<g>();
  
  public OnBackPressedDispatcher() {
    this(null);
  }
  
  public OnBackPressedDispatcher(Runnable paramRunnable) {
    this.a = paramRunnable;
  }
  
  public void a(v paramv, g paramg) {
    m m = paramv.getLifecycle();
    if (m.b() == m.c.a)
      return; 
    paramg.a(new LifecycleOnBackPressedCancellable(this, m, paramg));
  }
  
  a b(g paramg) {
    this.b.add(paramg);
    a a = new a(this, paramg);
    paramg.a(a);
    return a;
  }
  
  public void c() {
    Iterator<g> iterator = this.b.descendingIterator();
    while (iterator.hasNext()) {
      g g = iterator.next();
      if (g.c()) {
        g.b();
        return;
      } 
    } 
    Runnable runnable = this.a;
    if (runnable != null)
      runnable.run(); 
  }
  
  private class LifecycleOnBackPressedCancellable implements r, a {
    private final m a;
    
    private final g b;
    
    private a c;
    
    LifecycleOnBackPressedCancellable(OnBackPressedDispatcher this$0, m param1m, g param1g) {
      this.a = param1m;
      this.b = param1g;
      param1m.a((u)this);
    }
    
    public void c(v param1v, m.b param1b) {
      if (param1b == m.b.ON_START) {
        this.c = this.d.b(this.b);
        return;
      } 
      if (param1b == m.b.ON_STOP) {
        a a1 = this.c;
        if (a1 != null) {
          a1.cancel();
          return;
        } 
      } else if (param1b == m.b.ON_DESTROY) {
        cancel();
      } 
    }
    
    public void cancel() {
      this.a.c((u)this);
      this.b.e(this);
      a a1 = this.c;
      if (a1 != null) {
        a1.cancel();
        this.c = null;
      } 
    }
  }
  
  private class a implements a {
    private final g a;
    
    a(OnBackPressedDispatcher this$0, g param1g) {
      this.a = param1g;
    }
    
    public void cancel() {
      this.b.b.remove(this.a);
      this.a.e(this);
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Cricket Scorer-dex2jar.jar!\androidx\activity\OnBackPressedDispatcher.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */