package androidx.coordinatorlayout.widget;

import android.content.Context;
import android.content.res.Resources;
import android.content.res.TypedArray;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.Rect;
import android.graphics.Region;
import android.graphics.drawable.ColorDrawable;
import android.graphics.drawable.Drawable;
import android.os.Build;
import android.os.Parcel;
import android.os.Parcelable;
import android.os.SystemClock;
import android.text.TextUtils;
import android.util.AttributeSet;
import android.util.Log;
import android.util.SparseArray;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.view.ViewParent;
import android.view.ViewTreeObserver;
import androidx.core.view.f0;
import androidx.core.view.g0;
import androidx.core.view.h0;
import androidx.core.view.i0;
import androidx.core.view.o0;
import androidx.core.view.u2;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.lang.reflect.Constructor;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class CoordinatorLayout extends ViewGroup implements f0, g0 {
  static final String u;
  
  static final Class<?>[] v;
  
  static final ThreadLocal<Map<String, Constructor<c>>> w;
  
  static final Comparator<View> x = new i();
  
  private static final androidx.core.util.e<Rect> y;
  
  private final List<View> a;
  
  private final a<View> b;
  
  private final List<View> c;
  
  private final List<View> d;
  
  private Paint e;
  
  private final int[] f;
  
  private final int[] g;
  
  private boolean h;
  
  private boolean i;
  
  private int[] j;
  
  private View k;
  
  private View l;
  
  private g m;
  
  private boolean n;
  
  private u2 o;
  
  private boolean p;
  
  private Drawable q;
  
  ViewGroup.OnHierarchyChangeListener r;
  
  private i0 s;
  
  private final h0 t;
  
  static {
    v = new Class[] { Context.class, AttributeSet.class };
    w = new ThreadLocal<Map<String, Constructor<c>>>();
    y = (androidx.core.util.e<Rect>)new androidx.core.util.g(12);
  }
  
  public CoordinatorLayout(Context paramContext, AttributeSet paramAttributeSet) {
    this(paramContext, paramAttributeSet, s.a.a);
  }
  
  public CoordinatorLayout(Context paramContext, AttributeSet paramAttributeSet, int paramInt) {
    super(paramContext, paramAttributeSet, paramInt);
    TypedArray typedArray;
    this.a = new ArrayList<View>();
    this.b = new a<View>();
    this.c = new ArrayList<View>();
    this.d = new ArrayList<View>();
    this.f = new int[2];
    this.g = new int[2];
    this.t = new h0(this);
    boolean bool = false;
    if (paramInt == 0) {
      typedArray = paramContext.obtainStyledAttributes(paramAttributeSet, s.c.b, 0, s.b.a);
    } else {
      typedArray = paramContext.obtainStyledAttributes(paramAttributeSet, s.c.b, paramInt, 0);
    } 
    if (Build.VERSION.SDK_INT >= 29)
      if (paramInt == 0) {
        saveAttributeDataForStyleable(paramContext, s.c.b, paramAttributeSet, typedArray, 0, s.b.a);
      } else {
        saveAttributeDataForStyleable(paramContext, s.c.b, paramAttributeSet, typedArray, paramInt, 0);
      }  
    paramInt = typedArray.getResourceId(s.c.c, 0);
    if (paramInt != 0) {
      Resources resources = paramContext.getResources();
      this.j = resources.getIntArray(paramInt);
      float f = (resources.getDisplayMetrics()).density;
      int i = this.j.length;
      for (paramInt = bool; paramInt < i; paramInt++) {
        int[] arrayOfInt = this.j;
        arrayOfInt[paramInt] = (int)(arrayOfInt[paramInt] * f);
      } 
    } 
    this.q = typedArray.getDrawable(s.c.d);
    typedArray.recycle();
    X();
    super.setOnHierarchyChangeListener(new e(this));
    if (o0.C((View)this) == 0)
      o0.C0((View)this, 1); 
  }
  
  private boolean A(View paramView) {
    return this.b.j(paramView);
  }
  
  private void C(View paramView, int paramInt) {
    f f = (f)paramView.getLayoutParams();
    Rect rect1 = a();
    rect1.set(getPaddingLeft() + f.leftMargin, getPaddingTop() + f.topMargin, getWidth() - getPaddingRight() - f.rightMargin, getHeight() - getPaddingBottom() - f.bottomMargin);
    if (this.o != null && o0.B((View)this) && !o0.B(paramView)) {
      rect1.left += this.o.i();
      rect1.top += this.o.k();
      rect1.right -= this.o.j();
      rect1.bottom -= this.o.h();
    } 
    Rect rect2 = a();
    androidx.core.view.f.a(S(f.c), paramView.getMeasuredWidth(), paramView.getMeasuredHeight(), rect1, rect2, paramInt);
    paramView.layout(rect2.left, rect2.top, rect2.right, rect2.bottom);
    O(rect1);
    O(rect2);
  }
  
  private void D(View paramView1, View paramView2, int paramInt) {
    Rect rect1 = a();
    Rect rect2 = a();
    try {
      t(paramView2, rect1);
      u(paramView1, paramInt, rect1, rect2);
      paramView1.layout(rect2.left, rect2.top, rect2.right, rect2.bottom);
      return;
    } finally {
      O(rect1);
      O(rect2);
    } 
  }
  
  private void E(View paramView, int paramInt1, int paramInt2) {
    f f = (f)paramView.getLayoutParams();
    int i = androidx.core.view.f.b(T(f.c), paramInt2);
    int i2 = i & 0x7;
    int i1 = i & 0x70;
    int n = getWidth();
    int m = getHeight();
    int j = paramView.getMeasuredWidth();
    int k = paramView.getMeasuredHeight();
    i = paramInt1;
    if (paramInt2 == 1)
      i = n - paramInt1; 
    paramInt1 = w(i) - j;
    paramInt2 = 0;
    if (i2 != 1) {
      if (i2 == 5)
        paramInt1 += j; 
    } else {
      paramInt1 += j / 2;
    } 
    if (i1 != 16) {
      if (i1 == 80)
        paramInt2 = k + 0; 
    } else {
      paramInt2 = 0 + k / 2;
    } 
    paramInt1 = Math.max(getPaddingLeft() + f.leftMargin, Math.min(paramInt1, n - getPaddingRight() - j - f.rightMargin));
    paramInt2 = Math.max(getPaddingTop() + f.topMargin, Math.min(paramInt2, m - getPaddingBottom() - k - f.bottomMargin));
    paramView.layout(paramInt1, paramInt2, j + paramInt1, k + paramInt2);
  }
  
  private void F(View paramView, Rect paramRect, int paramInt) {
    // Byte code:
    //   0: aload_1
    //   1: invokestatic V : (Landroid/view/View;)Z
    //   4: ifne -> 8
    //   7: return
    //   8: aload_1
    //   9: invokevirtual getWidth : ()I
    //   12: ifle -> 459
    //   15: aload_1
    //   16: invokevirtual getHeight : ()I
    //   19: ifgt -> 23
    //   22: return
    //   23: aload_1
    //   24: invokevirtual getLayoutParams : ()Landroid/view/ViewGroup$LayoutParams;
    //   27: checkcast androidx/coordinatorlayout/widget/CoordinatorLayout$f
    //   30: astore #11
    //   32: aload #11
    //   34: invokevirtual f : ()Landroidx/coordinatorlayout/widget/CoordinatorLayout$c;
    //   37: astore #12
    //   39: invokestatic a : ()Landroid/graphics/Rect;
    //   42: astore #9
    //   44: invokestatic a : ()Landroid/graphics/Rect;
    //   47: astore #10
    //   49: aload #10
    //   51: aload_1
    //   52: invokevirtual getLeft : ()I
    //   55: aload_1
    //   56: invokevirtual getTop : ()I
    //   59: aload_1
    //   60: invokevirtual getRight : ()I
    //   63: aload_1
    //   64: invokevirtual getBottom : ()I
    //   67: invokevirtual set : (IIII)V
    //   70: aload #12
    //   72: ifnull -> 156
    //   75: aload #12
    //   77: aload_0
    //   78: aload_1
    //   79: aload #9
    //   81: invokevirtual b : (Landroidx/coordinatorlayout/widget/CoordinatorLayout;Landroid/view/View;Landroid/graphics/Rect;)Z
    //   84: ifeq -> 156
    //   87: aload #10
    //   89: aload #9
    //   91: invokevirtual contains : (Landroid/graphics/Rect;)Z
    //   94: ifeq -> 100
    //   97: goto -> 163
    //   100: new java/lang/StringBuilder
    //   103: dup
    //   104: invokespecial <init> : ()V
    //   107: astore_1
    //   108: aload_1
    //   109: ldc_w 'Rect should be within the child's bounds. Rect:'
    //   112: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   115: pop
    //   116: aload_1
    //   117: aload #9
    //   119: invokevirtual toShortString : ()Ljava/lang/String;
    //   122: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   125: pop
    //   126: aload_1
    //   127: ldc_w ' | Bounds:'
    //   130: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   133: pop
    //   134: aload_1
    //   135: aload #10
    //   137: invokevirtual toShortString : ()Ljava/lang/String;
    //   140: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   143: pop
    //   144: new java/lang/IllegalArgumentException
    //   147: dup
    //   148: aload_1
    //   149: invokevirtual toString : ()Ljava/lang/String;
    //   152: invokespecial <init> : (Ljava/lang/String;)V
    //   155: athrow
    //   156: aload #9
    //   158: aload #10
    //   160: invokevirtual set : (Landroid/graphics/Rect;)V
    //   163: aload #10
    //   165: invokestatic O : (Landroid/graphics/Rect;)V
    //   168: aload #9
    //   170: invokevirtual isEmpty : ()Z
    //   173: ifeq -> 182
    //   176: aload #9
    //   178: invokestatic O : (Landroid/graphics/Rect;)V
    //   181: return
    //   182: aload #11
    //   184: getfield h : I
    //   187: iload_3
    //   188: invokestatic b : (II)I
    //   191: istore #6
    //   193: iconst_1
    //   194: istore #5
    //   196: iload #6
    //   198: bipush #48
    //   200: iand
    //   201: bipush #48
    //   203: if_icmpne -> 250
    //   206: aload #9
    //   208: getfield top : I
    //   211: aload #11
    //   213: getfield topMargin : I
    //   216: isub
    //   217: aload #11
    //   219: getfield j : I
    //   222: isub
    //   223: istore_3
    //   224: aload_2
    //   225: getfield top : I
    //   228: istore #4
    //   230: iload_3
    //   231: iload #4
    //   233: if_icmpge -> 250
    //   236: aload_0
    //   237: aload_1
    //   238: iload #4
    //   240: iload_3
    //   241: isub
    //   242: invokespecial V : (Landroid/view/View;I)V
    //   245: iconst_1
    //   246: istore_3
    //   247: goto -> 252
    //   250: iconst_0
    //   251: istore_3
    //   252: iload_3
    //   253: istore #4
    //   255: iload #6
    //   257: bipush #80
    //   259: iand
    //   260: bipush #80
    //   262: if_icmpne -> 318
    //   265: aload_0
    //   266: invokevirtual getHeight : ()I
    //   269: aload #9
    //   271: getfield bottom : I
    //   274: isub
    //   275: aload #11
    //   277: getfield bottomMargin : I
    //   280: isub
    //   281: aload #11
    //   283: getfield j : I
    //   286: iadd
    //   287: istore #7
    //   289: aload_2
    //   290: getfield bottom : I
    //   293: istore #8
    //   295: iload_3
    //   296: istore #4
    //   298: iload #7
    //   300: iload #8
    //   302: if_icmpge -> 318
    //   305: aload_0
    //   306: aload_1
    //   307: iload #7
    //   309: iload #8
    //   311: isub
    //   312: invokespecial V : (Landroid/view/View;I)V
    //   315: iconst_1
    //   316: istore #4
    //   318: iload #4
    //   320: ifne -> 329
    //   323: aload_0
    //   324: aload_1
    //   325: iconst_0
    //   326: invokespecial V : (Landroid/view/View;I)V
    //   329: iload #6
    //   331: iconst_3
    //   332: iand
    //   333: iconst_3
    //   334: if_icmpne -> 381
    //   337: aload #9
    //   339: getfield left : I
    //   342: aload #11
    //   344: getfield leftMargin : I
    //   347: isub
    //   348: aload #11
    //   350: getfield i : I
    //   353: isub
    //   354: istore_3
    //   355: aload_2
    //   356: getfield left : I
    //   359: istore #4
    //   361: iload_3
    //   362: iload #4
    //   364: if_icmpge -> 381
    //   367: aload_0
    //   368: aload_1
    //   369: iload #4
    //   371: iload_3
    //   372: isub
    //   373: invokespecial U : (Landroid/view/View;I)V
    //   376: iconst_1
    //   377: istore_3
    //   378: goto -> 383
    //   381: iconst_0
    //   382: istore_3
    //   383: iload #6
    //   385: iconst_5
    //   386: iand
    //   387: iconst_5
    //   388: if_icmpne -> 444
    //   391: aload_0
    //   392: invokevirtual getWidth : ()I
    //   395: aload #9
    //   397: getfield right : I
    //   400: isub
    //   401: aload #11
    //   403: getfield rightMargin : I
    //   406: isub
    //   407: aload #11
    //   409: getfield i : I
    //   412: iadd
    //   413: istore #4
    //   415: aload_2
    //   416: getfield right : I
    //   419: istore #6
    //   421: iload #4
    //   423: iload #6
    //   425: if_icmpge -> 444
    //   428: aload_0
    //   429: aload_1
    //   430: iload #4
    //   432: iload #6
    //   434: isub
    //   435: invokespecial U : (Landroid/view/View;I)V
    //   438: iload #5
    //   440: istore_3
    //   441: goto -> 444
    //   444: iload_3
    //   445: ifne -> 454
    //   448: aload_0
    //   449: aload_1
    //   450: iconst_0
    //   451: invokespecial U : (Landroid/view/View;I)V
    //   454: aload #9
    //   456: invokestatic O : (Landroid/graphics/Rect;)V
    //   459: return
  }
  
  static c K(Context paramContext, AttributeSet paramAttributeSet, String paramString) {
    String str;
    if (TextUtils.isEmpty(paramString))
      return null; 
    if (paramString.startsWith(".")) {
      StringBuilder stringBuilder = new StringBuilder();
      stringBuilder.append(paramContext.getPackageName());
      stringBuilder.append(paramString);
      str = stringBuilder.toString();
    } else if (paramString.indexOf('.') >= 0) {
      str = paramString;
    } else {
      String str1 = u;
      str = paramString;
      if (!TextUtils.isEmpty(str1)) {
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append(str1);
        stringBuilder.append('.');
        stringBuilder.append(paramString);
        str = stringBuilder.toString();
      } 
    } 
    try {
      ThreadLocal<Map<String, Constructor<c>>> threadLocal = w;
      Map<Object, Object> map2 = (Map)threadLocal.get();
      Map<Object, Object> map1 = map2;
      if (map2 == null) {
        map1 = new HashMap<Object, Object>();
        threadLocal.set(map1);
      } 
      Constructor<?> constructor2 = (Constructor)map1.get(str);
      Constructor<?> constructor1 = constructor2;
      if (constructor2 == null) {
        constructor1 = Class.forName(str, false, paramContext.getClassLoader()).getConstructor(v);
        constructor1.setAccessible(true);
        map1.put(str, constructor1);
      } 
      return (c)constructor1.newInstance(new Object[] { paramContext, paramAttributeSet });
    } catch (Exception exception) {
      StringBuilder stringBuilder = new StringBuilder();
      stringBuilder.append("Could not inflate Behavior subclass ");
      stringBuilder.append(str);
      throw new RuntimeException(stringBuilder.toString(), exception);
    } 
  }
  
  private boolean L(MotionEvent paramMotionEvent, int paramInt) {
    boolean bool2;
    int j = paramMotionEvent.getActionMasked();
    List<View> list = this.c;
    z(list);
    int k = list.size();
    f f = null;
    int i = 0;
    boolean bool1 = false;
    boolean bool = false;
    while (true) {
      bool2 = bool1;
      if (i < k) {
        boolean bool3;
        boolean bool4;
        MotionEvent motionEvent;
        f f1;
        View view = list.get(i);
        f f2 = (f)view.getLayoutParams();
        c<View> c = f2.f();
        if ((bool1 || bool) && j != 0) {
          f2 = f;
          bool4 = bool1;
          bool3 = bool;
          if (c != null) {
            f2 = f;
            if (f == null) {
              long l = SystemClock.uptimeMillis();
              motionEvent = MotionEvent.obtain(l, l, 3, 0.0F, 0.0F, 0);
            } 
            if (paramInt != 0) {
              if (paramInt != 1) {
                bool4 = bool1;
                bool3 = bool;
              } else {
                c.D(this, view, motionEvent);
                bool4 = bool1;
                bool3 = bool;
              } 
            } else {
              c.k(this, view, motionEvent);
              bool4 = bool1;
              bool3 = bool;
            } 
          } 
        } else {
          bool2 = bool1;
          if (!bool1) {
            bool2 = bool1;
            if (c != null) {
              if (paramInt != 0) {
                if (paramInt == 1)
                  bool1 = c.D(this, view, paramMotionEvent); 
              } else {
                bool1 = c.k(this, view, paramMotionEvent);
              } 
              bool2 = bool1;
              if (bool1) {
                this.k = view;
                bool2 = bool1;
              } 
            } 
          } 
          bool4 = motionEvent.c();
          bool1 = motionEvent.i(this, view);
          if (bool1 && !bool4) {
            bool = true;
          } else {
            bool = false;
          } 
          f1 = f;
          bool4 = bool2;
          bool3 = bool;
          if (bool1) {
            f1 = f;
            bool4 = bool2;
            bool3 = bool;
            if (!bool)
              break; 
          } 
        } 
        i++;
        f = f1;
        bool1 = bool4;
        bool = bool3;
        continue;
      } 
      break;
    } 
    list.clear();
    return bool2;
  }
  
  private void M() {
    this.a.clear();
    this.b.c();
    int j = getChildCount();
    for (int i = 0; i < j; i++) {
      View view = getChildAt(i);
      f f = y(view);
      f.d(this, view);
      this.b.b(view);
      for (int k = 0; k < j; k++) {
        if (k != i) {
          View view1 = getChildAt(k);
          if (f.b(this, view, view1)) {
            if (!this.b.d(view1))
              this.b.b(view1); 
            this.b.a(view1, view);
          } 
        } 
      } 
    } 
    this.a.addAll(this.b.i());
    Collections.reverse(this.a);
  }
  
  private static void O(Rect paramRect) {
    paramRect.setEmpty();
    y.a(paramRect);
  }
  
  private void Q(boolean paramBoolean) {
    int j = getChildCount();
    int i;
    for (i = 0; i < j; i++) {
      View view = getChildAt(i);
      c<View> c = ((f)view.getLayoutParams()).f();
      if (c != null) {
        long l = SystemClock.uptimeMillis();
        MotionEvent motionEvent = MotionEvent.obtain(l, l, 3, 0.0F, 0.0F, 0);
        if (paramBoolean) {
          c.k(this, view, motionEvent);
        } else {
          c.D(this, view, motionEvent);
        } 
        motionEvent.recycle();
      } 
    } 
    for (i = 0; i < j; i++)
      ((f)getChildAt(i).getLayoutParams()).m(); 
    this.k = null;
    this.h = false;
  }
  
  private static int R(int paramInt) {
    int i = paramInt;
    if (paramInt == 0)
      i = 17; 
    return i;
  }
  
  private static int S(int paramInt) {
    int i = paramInt;
    if ((paramInt & 0x7) == 0)
      i = paramInt | 0x800003; 
    paramInt = i;
    if ((i & 0x70) == 0)
      paramInt = i | 0x30; 
    return paramInt;
  }
  
  private static int T(int paramInt) {
    int i = paramInt;
    if (paramInt == 0)
      i = 8388661; 
    return i;
  }
  
  private void U(View paramView, int paramInt) {
    f f = (f)paramView.getLayoutParams();
    int i = f.i;
    if (i != paramInt) {
      o0.b0(paramView, paramInt - i);
      f.i = paramInt;
    } 
  }
  
  private void V(View paramView, int paramInt) {
    f f = (f)paramView.getLayoutParams();
    int i = f.j;
    if (i != paramInt) {
      o0.c0(paramView, paramInt - i);
      f.j = paramInt;
    } 
  }
  
  private void X() {
    if (o0.B((View)this)) {
      if (this.s == null)
        this.s = new a(this); 
      o0.E0((View)this, this.s);
      setSystemUiVisibility(1280);
      return;
    } 
    o0.E0((View)this, null);
  }
  
  private static Rect a() {
    Rect rect2 = (Rect)y.b();
    Rect rect1 = rect2;
    if (rect2 == null)
      rect1 = new Rect(); 
    return rect1;
  }
  
  private static int c(int paramInt1, int paramInt2, int paramInt3) {
    return (paramInt1 < paramInt2) ? paramInt2 : ((paramInt1 > paramInt3) ? paramInt3 : paramInt1);
  }
  
  private void d(f paramf, Rect paramRect, int paramInt1, int paramInt2) {
    int j = getWidth();
    int i = getHeight();
    j = Math.max(getPaddingLeft() + paramf.leftMargin, Math.min(paramRect.left, j - getPaddingRight() - paramInt1 - paramf.rightMargin));
    i = Math.max(getPaddingTop() + paramf.topMargin, Math.min(paramRect.top, i - getPaddingBottom() - paramInt2 - paramf.bottomMargin));
    paramRect.set(j, i, paramInt1 + j, paramInt2 + i);
  }
  
  private u2 f(u2 paramu2) {
    if (paramu2.n())
      return paramu2; 
    int i = 0;
    int j = getChildCount();
    u2 u21;
    for (u21 = paramu2; i < j; u21 = paramu2) {
      View view = getChildAt(i);
      paramu2 = u21;
      if (o0.B(view)) {
        c<View> c = ((f)view.getLayoutParams()).f();
        paramu2 = u21;
        if (c != null) {
          u21 = c.f(this, view, u21);
          paramu2 = u21;
          if (u21.n())
            return u21; 
        } 
      } 
      i++;
    } 
    return u21;
  }
  
  private void v(View paramView, int paramInt1, Rect paramRect1, Rect paramRect2, f paramf, int paramInt2, int paramInt3) {
    int i = androidx.core.view.f.b(R(paramf.c), paramInt1);
    paramInt1 = androidx.core.view.f.b(S(paramf.d), paramInt1);
    int m = i & 0x7;
    int k = i & 0x70;
    int j = paramInt1 & 0x7;
    i = paramInt1 & 0x70;
    if (j != 1) {
      if (j != 5) {
        paramInt1 = paramRect1.left;
      } else {
        paramInt1 = paramRect1.right;
      } 
    } else {
      paramInt1 = paramRect1.left + paramRect1.width() / 2;
    } 
    if (i != 16) {
      if (i != 80) {
        i = paramRect1.top;
      } else {
        i = paramRect1.bottom;
      } 
    } else {
      i = paramRect1.top + paramRect1.height() / 2;
    } 
    if (m != 1) {
      j = paramInt1;
      if (m != 5)
        j = paramInt1 - paramInt2; 
    } else {
      j = paramInt1 - paramInt2 / 2;
    } 
    if (k != 16) {
      paramInt1 = i;
      if (k != 80)
        paramInt1 = i - paramInt3; 
    } else {
      paramInt1 = i - paramInt3 / 2;
    } 
    paramRect2.set(j, paramInt1, paramInt2 + j, paramInt3 + paramInt1);
  }
  
  private int w(int paramInt) {
    StringBuilder stringBuilder;
    int[] arrayOfInt = this.j;
    if (arrayOfInt == null) {
      stringBuilder = new StringBuilder();
      stringBuilder.append("No keylines defined for ");
      stringBuilder.append(this);
      stringBuilder.append(" - attempted index lookup ");
      stringBuilder.append(paramInt);
      Log.e("CoordinatorLayout", stringBuilder.toString());
      return 0;
    } 
    if (paramInt < 0 || paramInt >= stringBuilder.length) {
      stringBuilder = new StringBuilder();
      stringBuilder.append("Keyline index ");
      stringBuilder.append(paramInt);
      stringBuilder.append(" out of range for ");
      stringBuilder.append(this);
      Log.e("CoordinatorLayout", stringBuilder.toString());
      return 0;
    } 
    return stringBuilder[paramInt];
  }
  
  private void z(List<View> paramList) {
    paramList.clear();
    boolean bool = isChildrenDrawingOrderEnabled();
    int j = getChildCount();
    for (int i = j - 1; i >= 0; i--) {
      int k;
      if (bool) {
        k = getChildDrawingOrder(j, i);
      } else {
        k = i;
      } 
      paramList.add(getChildAt(k));
    } 
    Comparator<View> comparator = x;
    if (comparator != null)
      Collections.sort(paramList, comparator); 
  }
  
  public boolean B(View paramView, int paramInt1, int paramInt2) {
    Rect rect = a();
    t(paramView, rect);
    try {
      return rect.contains(paramInt1, paramInt2);
    } finally {
      O(rect);
    } 
  }
  
  void G(View paramView, int paramInt) {
    // Byte code:
    //   0: aload_1
    //   1: invokevirtual getLayoutParams : ()Landroid/view/ViewGroup$LayoutParams;
    //   4: checkcast androidx/coordinatorlayout/widget/CoordinatorLayout$f
    //   7: astore #6
    //   9: aload #6
    //   11: getfield k : Landroid/view/View;
    //   14: ifnull -> 212
    //   17: invokestatic a : ()Landroid/graphics/Rect;
    //   20: astore #7
    //   22: invokestatic a : ()Landroid/graphics/Rect;
    //   25: astore #8
    //   27: invokestatic a : ()Landroid/graphics/Rect;
    //   30: astore #9
    //   32: aload_0
    //   33: aload #6
    //   35: getfield k : Landroid/view/View;
    //   38: aload #7
    //   40: invokevirtual t : (Landroid/view/View;Landroid/graphics/Rect;)V
    //   43: iconst_0
    //   44: istore_3
    //   45: aload_0
    //   46: aload_1
    //   47: iconst_0
    //   48: aload #8
    //   50: invokevirtual q : (Landroid/view/View;ZLandroid/graphics/Rect;)V
    //   53: aload_1
    //   54: invokevirtual getMeasuredWidth : ()I
    //   57: istore #4
    //   59: aload_1
    //   60: invokevirtual getMeasuredHeight : ()I
    //   63: istore #5
    //   65: aload_0
    //   66: aload_1
    //   67: iload_2
    //   68: aload #7
    //   70: aload #9
    //   72: aload #6
    //   74: iload #4
    //   76: iload #5
    //   78: invokespecial v : (Landroid/view/View;ILandroid/graphics/Rect;Landroid/graphics/Rect;Landroidx/coordinatorlayout/widget/CoordinatorLayout$f;II)V
    //   81: aload #9
    //   83: getfield left : I
    //   86: aload #8
    //   88: getfield left : I
    //   91: if_icmpne -> 109
    //   94: iload_3
    //   95: istore_2
    //   96: aload #9
    //   98: getfield top : I
    //   101: aload #8
    //   103: getfield top : I
    //   106: if_icmpeq -> 111
    //   109: iconst_1
    //   110: istore_2
    //   111: aload_0
    //   112: aload #6
    //   114: aload #9
    //   116: iload #4
    //   118: iload #5
    //   120: invokespecial d : (Landroidx/coordinatorlayout/widget/CoordinatorLayout$f;Landroid/graphics/Rect;II)V
    //   123: aload #9
    //   125: getfield left : I
    //   128: aload #8
    //   130: getfield left : I
    //   133: isub
    //   134: istore_3
    //   135: aload #9
    //   137: getfield top : I
    //   140: aload #8
    //   142: getfield top : I
    //   145: isub
    //   146: istore #4
    //   148: iload_3
    //   149: ifeq -> 157
    //   152: aload_1
    //   153: iload_3
    //   154: invokestatic b0 : (Landroid/view/View;I)V
    //   157: iload #4
    //   159: ifeq -> 168
    //   162: aload_1
    //   163: iload #4
    //   165: invokestatic c0 : (Landroid/view/View;I)V
    //   168: iload_2
    //   169: ifeq -> 197
    //   172: aload #6
    //   174: invokevirtual f : ()Landroidx/coordinatorlayout/widget/CoordinatorLayout$c;
    //   177: astore #10
    //   179: aload #10
    //   181: ifnull -> 197
    //   184: aload #10
    //   186: aload_0
    //   187: aload_1
    //   188: aload #6
    //   190: getfield k : Landroid/view/View;
    //   193: invokevirtual h : (Landroidx/coordinatorlayout/widget/CoordinatorLayout;Landroid/view/View;Landroid/view/View;)Z
    //   196: pop
    //   197: aload #7
    //   199: invokestatic O : (Landroid/graphics/Rect;)V
    //   202: aload #8
    //   204: invokestatic O : (Landroid/graphics/Rect;)V
    //   207: aload #9
    //   209: invokestatic O : (Landroid/graphics/Rect;)V
    //   212: return
  }
  
  final void H(int paramInt) {
    int j = o0.E((View)this);
    int k = this.a.size();
    Rect rect1 = a();
    Rect rect2 = a();
    Rect rect3 = a();
    for (int i = 0; i < k; i++) {
      View view = this.a.get(i);
      f f = (f)view.getLayoutParams();
      if (paramInt == 0 && view.getVisibility() == 8)
        continue; 
      int m;
      for (m = 0; m < i; m++) {
        View view1 = this.a.get(m);
        if (f.l == view1)
          G(view, j); 
      } 
      q(view, true, rect2);
      if (f.g != 0 && !rect2.isEmpty()) {
        m = androidx.core.view.f.b(f.g, j);
        int n = m & 0x70;
        if (n != 48) {
          if (n == 80)
            rect1.bottom = Math.max(rect1.bottom, getHeight() - rect2.top); 
        } else {
          rect1.top = Math.max(rect1.top, rect2.bottom);
        } 
        m &= 0x7;
        if (m != 3) {
          if (m == 5)
            rect1.right = Math.max(rect1.right, getWidth() - rect2.left); 
        } else {
          rect1.left = Math.max(rect1.left, rect2.right);
        } 
      } 
      if (f.h != 0 && view.getVisibility() == 0)
        F(view, rect1, j); 
      if (paramInt != 2) {
        x(view, rect3);
        if (rect3.equals(rect2))
          continue; 
        N(view, rect2);
      } 
      for (m = i + 1; m < k; m++) {
        View view1 = this.a.get(m);
        f f1 = (f)view1.getLayoutParams();
        c<View> c = f1.f();
        if (c != null && c.e(this, view1, view))
          if (paramInt == 0 && f1.g()) {
            f1.k();
          } else {
            boolean bool;
            if (paramInt != 2) {
              bool = c.h(this, view1, view);
            } else {
              c.i(this, view1, view);
              bool = true;
            } 
            if (paramInt == 1)
              f1.p(bool); 
          }  
      } 
      continue;
    } 
    O(rect1);
    O(rect2);
    O(rect3);
  }
  
  public void I(View paramView, int paramInt) {
    f f = (f)paramView.getLayoutParams();
    if (!f.a()) {
      View view = f.k;
      if (view != null) {
        D(paramView, view, paramInt);
        return;
      } 
      int i = f.e;
      if (i >= 0) {
        E(paramView, i, paramInt);
        return;
      } 
      C(paramView, paramInt);
      return;
    } 
    throw new IllegalStateException("An anchor may not be changed after CoordinatorLayout measurement begins before layout is complete.");
  }
  
  public void J(View paramView, int paramInt1, int paramInt2, int paramInt3, int paramInt4) {
    measureChildWithMargins(paramView, paramInt1, paramInt2, paramInt3, paramInt4);
  }
  
  void N(View paramView, Rect paramRect) {
    ((f)paramView.getLayoutParams()).q(paramRect);
  }
  
  void P() {
    if (this.i && this.m != null)
      getViewTreeObserver().removeOnPreDrawListener(this.m); 
    this.n = false;
  }
  
  final u2 W(u2 paramu2) {
    u2 u21 = paramu2;
    if (!androidx.core.util.c.a(this.o, paramu2)) {
      boolean bool1;
      this.o = paramu2;
      boolean bool2 = true;
      if (paramu2 != null && paramu2.k() > 0) {
        bool1 = true;
      } else {
        bool1 = false;
      } 
      this.p = bool1;
      if (!bool1 && getBackground() == null) {
        bool1 = bool2;
      } else {
        bool1 = false;
      } 
      setWillNotDraw(bool1);
      u21 = f(paramu2);
      requestLayout();
    } 
    return u21;
  }
  
  void b() {
    if (this.i) {
      if (this.m == null)
        this.m = new g(this); 
      getViewTreeObserver().addOnPreDrawListener(this.m);
    } 
    this.n = true;
  }
  
  protected boolean checkLayoutParams(ViewGroup.LayoutParams paramLayoutParams) {
    return (paramLayoutParams instanceof f && super.checkLayoutParams(paramLayoutParams));
  }
  
  protected boolean drawChild(Canvas paramCanvas, View paramView, long paramLong) {
    f f = (f)paramView.getLayoutParams();
    c<View> c = f.a;
    if (c != null) {
      float f1 = c.d(this, paramView);
      if (f1 > 0.0F) {
        if (this.e == null)
          this.e = new Paint(); 
        this.e.setColor(f.a.c(this, paramView));
        this.e.setAlpha(c(Math.round(f1 * 255.0F), 0, 255));
        int i = paramCanvas.save();
        if (paramView.isOpaque())
          paramCanvas.clipRect(paramView.getLeft(), paramView.getTop(), paramView.getRight(), paramView.getBottom(), Region.Op.DIFFERENCE); 
        paramCanvas.drawRect(getPaddingLeft(), getPaddingTop(), (getWidth() - getPaddingRight()), (getHeight() - getPaddingBottom()), this.e);
        paramCanvas.restoreToCount(i);
      } 
    } 
    return super.drawChild(paramCanvas, paramView, paramLong);
  }
  
  protected void drawableStateChanged() {
    super.drawableStateChanged();
    int[] arrayOfInt = getDrawableState();
    Drawable drawable = this.q;
    byte b = 0;
    int i = b;
    if (drawable != null) {
      i = b;
      if (drawable.isStateful())
        i = false | drawable.setState(arrayOfInt); 
    } 
    if (i != 0)
      invalidate(); 
  }
  
  public void e(View paramView, int paramInt1, int paramInt2, int paramInt3, int paramInt4, int paramInt5, int[] paramArrayOfint) {
    int m = getChildCount();
    boolean bool = false;
    int i = 0;
    int k = 0;
    int j;
    for (j = 0; i < m; j = n) {
      int n;
      int i1;
      View view = getChildAt(i);
      if (view.getVisibility() == 8) {
        i1 = k;
        n = j;
      } else {
        f f = (f)view.getLayoutParams();
        if (!f.j(paramInt5)) {
          i1 = k;
          n = j;
        } else {
          c<View> c = f.f();
          i1 = k;
          n = j;
          if (c != null) {
            int[] arrayOfInt2 = this.f;
            arrayOfInt2[0] = 0;
            arrayOfInt2[1] = 0;
            c.t(this, view, paramView, paramInt1, paramInt2, paramInt3, paramInt4, paramInt5, arrayOfInt2);
            int[] arrayOfInt1 = this.f;
            if (paramInt3 > 0) {
              n = Math.max(k, arrayOfInt1[0]);
            } else {
              n = Math.min(k, arrayOfInt1[0]);
            } 
            k = n;
            if (paramInt4 > 0) {
              n = Math.max(j, this.f[1]);
            } else {
              n = Math.min(j, this.f[1]);
            } 
            bool = true;
            i1 = k;
          } 
        } 
      } 
      i++;
      k = i1;
    } 
    paramArrayOfint[0] = paramArrayOfint[0] + k;
    paramArrayOfint[1] = paramArrayOfint[1] + j;
    if (bool)
      H(1); 
  }
  
  public void g(View paramView) {
    List<View> list = this.b.g(paramView);
    if (list != null && !list.isEmpty())
      for (int i = 0; i < list.size(); i++) {
        View view = list.get(i);
        c<View> c = ((f)view.getLayoutParams()).f();
        if (c != null)
          c.h(this, view, paramView); 
      }  
  }
  
  final List<View> getDependencySortedChildren() {
    M();
    return Collections.unmodifiableList(this.a);
  }
  
  public final u2 getLastWindowInsets() {
    return this.o;
  }
  
  public int getNestedScrollAxes() {
    return this.t.a();
  }
  
  public Drawable getStatusBarBackground() {
    return this.q;
  }
  
  protected int getSuggestedMinimumHeight() {
    return Math.max(super.getSuggestedMinimumHeight(), getPaddingTop() + getPaddingBottom());
  }
  
  protected int getSuggestedMinimumWidth() {
    return Math.max(super.getSuggestedMinimumWidth(), getPaddingLeft() + getPaddingRight());
  }
  
  void h() {
    boolean bool1;
    int j = getChildCount();
    boolean bool2 = false;
    int i = 0;
    while (true) {
      bool1 = bool2;
      if (i < j) {
        if (A(getChildAt(i))) {
          bool1 = true;
          break;
        } 
        i++;
        continue;
      } 
      break;
    } 
    if (bool1 != this.n) {
      if (bool1) {
        b();
        return;
      } 
      P();
    } 
  }
  
  protected f i() {
    return new f(-2, -2);
  }
  
  public f j(AttributeSet paramAttributeSet) {
    return new f(getContext(), paramAttributeSet);
  }
  
  public void k(View paramView, int paramInt1, int paramInt2, int paramInt3, int paramInt4, int paramInt5) {
    e(paramView, paramInt1, paramInt2, paramInt3, paramInt4, 0, this.g);
  }
  
  public boolean l(View paramView1, View paramView2, int paramInt1, int paramInt2) {
    int j = getChildCount();
    int i = 0;
    boolean bool = false;
    while (i < j) {
      View view = getChildAt(i);
      if (view.getVisibility() != 8) {
        f f = (f)view.getLayoutParams();
        c<View> c = f.f();
        if (c != null) {
          boolean bool1 = c.A(this, view, paramView1, paramView2, paramInt1, paramInt2);
          bool |= bool1;
          f.r(paramInt2, bool1);
        } else {
          f.r(paramInt2, false);
        } 
      } 
      i++;
    } 
    return bool;
  }
  
  public void m(View paramView1, View paramView2, int paramInt1, int paramInt2) {
    this.t.c(paramView1, paramView2, paramInt1, paramInt2);
    this.l = paramView2;
    int j = getChildCount();
    int i;
    for (i = 0; i < j; i++) {
      View view = getChildAt(i);
      f f = (f)view.getLayoutParams();
      if (f.j(paramInt2)) {
        c<View> c = f.f();
        if (c != null)
          c.v(this, view, paramView1, paramView2, paramInt1, paramInt2); 
      } 
    } 
  }
  
  public void n(View paramView, int paramInt) {
    this.t.e(paramView, paramInt);
    int j = getChildCount();
    for (int i = 0; i < j; i++) {
      View view = getChildAt(i);
      f f = (f)view.getLayoutParams();
      if (f.j(paramInt)) {
        c<View> c = f.f();
        if (c != null)
          c.C(this, view, paramView, paramInt); 
        f.l(paramInt);
        f.k();
      } 
    } 
    this.l = null;
  }
  
  public void o(View paramView, int paramInt1, int paramInt2, int[] paramArrayOfint, int paramInt3) {
    int m = getChildCount();
    boolean bool = false;
    int i = 0;
    int k = 0;
    int j;
    for (j = 0; i < m; j = n) {
      int n;
      int i1;
      View view = getChildAt(i);
      if (view.getVisibility() == 8) {
        i1 = k;
        n = j;
      } else {
        f f = (f)view.getLayoutParams();
        if (!f.j(paramInt3)) {
          i1 = k;
          n = j;
        } else {
          c<View> c = f.f();
          i1 = k;
          n = j;
          if (c != null) {
            int[] arrayOfInt2 = this.f;
            arrayOfInt2[0] = 0;
            arrayOfInt2[1] = 0;
            c.q(this, view, paramView, paramInt1, paramInt2, arrayOfInt2, paramInt3);
            int[] arrayOfInt1 = this.f;
            if (paramInt1 > 0) {
              n = Math.max(k, arrayOfInt1[0]);
            } else {
              n = Math.min(k, arrayOfInt1[0]);
            } 
            k = n;
            arrayOfInt1 = this.f;
            if (paramInt2 > 0) {
              n = Math.max(j, arrayOfInt1[1]);
            } else {
              n = Math.min(j, arrayOfInt1[1]);
            } 
            bool = true;
            i1 = k;
          } 
        } 
      } 
      i++;
      k = i1;
    } 
    paramArrayOfint[0] = k;
    paramArrayOfint[1] = j;
    if (bool)
      H(1); 
  }
  
  public void onAttachedToWindow() {
    super.onAttachedToWindow();
    Q(false);
    if (this.n) {
      if (this.m == null)
        this.m = new g(this); 
      getViewTreeObserver().addOnPreDrawListener(this.m);
    } 
    if (this.o == null && o0.B((View)this))
      o0.o0((View)this); 
    this.i = true;
  }
  
  public void onDetachedFromWindow() {
    super.onDetachedFromWindow();
    Q(false);
    if (this.n && this.m != null)
      getViewTreeObserver().removeOnPreDrawListener(this.m); 
    View view = this.l;
    if (view != null)
      onStopNestedScroll(view); 
    this.i = false;
  }
  
  public void onDraw(Canvas paramCanvas) {
    super.onDraw(paramCanvas);
    if (this.p && this.q != null) {
      boolean bool;
      u2 u21 = this.o;
      if (u21 != null) {
        bool = u21.k();
      } else {
        bool = false;
      } 
      if (bool) {
        this.q.setBounds(0, 0, getWidth(), bool);
        this.q.draw(paramCanvas);
      } 
    } 
  }
  
  public boolean onInterceptTouchEvent(MotionEvent paramMotionEvent) {
    int i = paramMotionEvent.getActionMasked();
    if (i == 0)
      Q(true); 
    boolean bool = L(paramMotionEvent, 0);
    if (i == 1 || i == 3)
      Q(true); 
    return bool;
  }
  
  protected void onLayout(boolean paramBoolean, int paramInt1, int paramInt2, int paramInt3, int paramInt4) {
    paramInt2 = o0.E((View)this);
    paramInt3 = this.a.size();
    for (paramInt1 = 0; paramInt1 < paramInt3; paramInt1++) {
      View view = this.a.get(paramInt1);
      if (view.getVisibility() != 8) {
        c<View> c = ((f)view.getLayoutParams()).f();
        if (c == null || !c.l(this, view, paramInt2))
          I(view, paramInt2); 
      } 
    } 
  }
  
  protected void onMeasure(int paramInt1, int paramInt2) {
    // Byte code:
    //   0: aload_0
    //   1: invokespecial M : ()V
    //   4: aload_0
    //   5: invokevirtual h : ()V
    //   8: aload_0
    //   9: invokevirtual getPaddingLeft : ()I
    //   12: istore #13
    //   14: aload_0
    //   15: invokevirtual getPaddingTop : ()I
    //   18: istore #15
    //   20: aload_0
    //   21: invokevirtual getPaddingRight : ()I
    //   24: istore #16
    //   26: aload_0
    //   27: invokevirtual getPaddingBottom : ()I
    //   30: istore #17
    //   32: aload_0
    //   33: invokestatic E : (Landroid/view/View;)I
    //   36: istore #18
    //   38: iload #18
    //   40: iconst_1
    //   41: if_icmpne -> 50
    //   44: iconst_1
    //   45: istore #5
    //   47: goto -> 53
    //   50: iconst_0
    //   51: istore #5
    //   53: iload_1
    //   54: invokestatic getMode : (I)I
    //   57: istore #19
    //   59: iload_1
    //   60: invokestatic getSize : (I)I
    //   63: istore #20
    //   65: iload_2
    //   66: invokestatic getMode : (I)I
    //   69: istore #21
    //   71: iload_2
    //   72: invokestatic getSize : (I)I
    //   75: istore #22
    //   77: aload_0
    //   78: invokevirtual getSuggestedMinimumWidth : ()I
    //   81: istore #11
    //   83: aload_0
    //   84: invokevirtual getSuggestedMinimumHeight : ()I
    //   87: istore #10
    //   89: aload_0
    //   90: getfield o : Landroidx/core/view/u2;
    //   93: ifnull -> 109
    //   96: aload_0
    //   97: invokestatic B : (Landroid/view/View;)Z
    //   100: ifeq -> 109
    //   103: iconst_1
    //   104: istore #6
    //   106: goto -> 112
    //   109: iconst_0
    //   110: istore #6
    //   112: aload_0
    //   113: getfield a : Ljava/util/List;
    //   116: invokeinterface size : ()I
    //   121: istore #7
    //   123: iconst_0
    //   124: istore #4
    //   126: iconst_0
    //   127: istore #8
    //   129: iload #13
    //   131: istore_3
    //   132: iload_3
    //   133: istore #9
    //   135: iload #8
    //   137: iload #7
    //   139: if_icmpge -> 513
    //   142: aload_0
    //   143: getfield a : Ljava/util/List;
    //   146: iload #8
    //   148: invokeinterface get : (I)Ljava/lang/Object;
    //   153: checkcast android/view/View
    //   156: astore #26
    //   158: aload #26
    //   160: invokevirtual getVisibility : ()I
    //   163: bipush #8
    //   165: if_icmpne -> 171
    //   168: goto -> 501
    //   171: aload #26
    //   173: invokevirtual getLayoutParams : ()Landroid/view/ViewGroup$LayoutParams;
    //   176: checkcast androidx/coordinatorlayout/widget/CoordinatorLayout$f
    //   179: astore #25
    //   181: aload #25
    //   183: getfield e : I
    //   186: istore_3
    //   187: iload_3
    //   188: iflt -> 291
    //   191: iload #19
    //   193: ifeq -> 291
    //   196: aload_0
    //   197: iload_3
    //   198: invokespecial w : (I)I
    //   201: istore_3
    //   202: aload #25
    //   204: getfield c : I
    //   207: invokestatic T : (I)I
    //   210: iload #18
    //   212: invokestatic b : (II)I
    //   215: bipush #7
    //   217: iand
    //   218: istore #12
    //   220: iload #12
    //   222: iconst_3
    //   223: if_icmpne -> 231
    //   226: iload #5
    //   228: ifeq -> 242
    //   231: iload #12
    //   233: iconst_5
    //   234: if_icmpne -> 257
    //   237: iload #5
    //   239: ifeq -> 257
    //   242: iconst_0
    //   243: iload #20
    //   245: iload #16
    //   247: isub
    //   248: iload_3
    //   249: isub
    //   250: invokestatic max : (II)I
    //   253: istore_3
    //   254: goto -> 293
    //   257: iload #12
    //   259: iconst_5
    //   260: if_icmpne -> 268
    //   263: iload #5
    //   265: ifeq -> 279
    //   268: iload #12
    //   270: iconst_3
    //   271: if_icmpne -> 291
    //   274: iload #5
    //   276: ifeq -> 291
    //   279: iconst_0
    //   280: iload_3
    //   281: iload #9
    //   283: isub
    //   284: invokestatic max : (II)I
    //   287: istore_3
    //   288: goto -> 293
    //   291: iconst_0
    //   292: istore_3
    //   293: iload #4
    //   295: istore #14
    //   297: iload #6
    //   299: ifeq -> 379
    //   302: aload #26
    //   304: invokestatic B : (Landroid/view/View;)Z
    //   307: ifne -> 379
    //   310: aload_0
    //   311: getfield o : Landroidx/core/view/u2;
    //   314: invokevirtual i : ()I
    //   317: istore #4
    //   319: aload_0
    //   320: getfield o : Landroidx/core/view/u2;
    //   323: invokevirtual j : ()I
    //   326: istore #24
    //   328: aload_0
    //   329: getfield o : Landroidx/core/view/u2;
    //   332: invokevirtual k : ()I
    //   335: istore #12
    //   337: aload_0
    //   338: getfield o : Landroidx/core/view/u2;
    //   341: invokevirtual h : ()I
    //   344: istore #23
    //   346: iload #20
    //   348: iload #4
    //   350: iload #24
    //   352: iadd
    //   353: isub
    //   354: iload #19
    //   356: invokestatic makeMeasureSpec : (II)I
    //   359: istore #4
    //   361: iload #22
    //   363: iload #12
    //   365: iload #23
    //   367: iadd
    //   368: isub
    //   369: iload #21
    //   371: invokestatic makeMeasureSpec : (II)I
    //   374: istore #12
    //   376: goto -> 385
    //   379: iload_1
    //   380: istore #4
    //   382: iload_2
    //   383: istore #12
    //   385: aload #25
    //   387: invokevirtual f : ()Landroidx/coordinatorlayout/widget/CoordinatorLayout$c;
    //   390: astore #27
    //   392: aload #27
    //   394: ifnull -> 417
    //   397: aload #27
    //   399: aload_0
    //   400: aload #26
    //   402: iload #4
    //   404: iload_3
    //   405: iload #12
    //   407: iconst_0
    //   408: invokevirtual m : (Landroidx/coordinatorlayout/widget/CoordinatorLayout;Landroid/view/View;IIII)Z
    //   411: ifne -> 429
    //   414: goto -> 417
    //   417: aload_0
    //   418: aload #26
    //   420: iload #4
    //   422: iload_3
    //   423: iload #12
    //   425: iconst_0
    //   426: invokevirtual J : (Landroid/view/View;IIII)V
    //   429: iload #11
    //   431: iload #13
    //   433: iload #16
    //   435: iadd
    //   436: aload #26
    //   438: invokevirtual getMeasuredWidth : ()I
    //   441: iadd
    //   442: aload #25
    //   444: getfield leftMargin : I
    //   447: iadd
    //   448: aload #25
    //   450: getfield rightMargin : I
    //   453: iadd
    //   454: invokestatic max : (II)I
    //   457: istore #11
    //   459: iload #10
    //   461: iload #15
    //   463: iload #17
    //   465: iadd
    //   466: aload #26
    //   468: invokevirtual getMeasuredHeight : ()I
    //   471: iadd
    //   472: aload #25
    //   474: getfield topMargin : I
    //   477: iadd
    //   478: aload #25
    //   480: getfield bottomMargin : I
    //   483: iadd
    //   484: invokestatic max : (II)I
    //   487: istore #10
    //   489: iload #14
    //   491: aload #26
    //   493: invokevirtual getMeasuredState : ()I
    //   496: invokestatic combineMeasuredStates : (II)I
    //   499: istore #4
    //   501: iload #8
    //   503: iconst_1
    //   504: iadd
    //   505: istore #8
    //   507: iload #9
    //   509: istore_3
    //   510: goto -> 132
    //   513: aload_0
    //   514: iload #11
    //   516: iload_1
    //   517: ldc_w -16777216
    //   520: iload #4
    //   522: iand
    //   523: invokestatic resolveSizeAndState : (III)I
    //   526: iload #10
    //   528: iload_2
    //   529: iload #4
    //   531: bipush #16
    //   533: ishl
    //   534: invokestatic resolveSizeAndState : (III)I
    //   537: invokevirtual setMeasuredDimension : (II)V
    //   540: return
  }
  
  public boolean onNestedFling(View paramView, float paramFloat1, float paramFloat2, boolean paramBoolean) {
    int j = getChildCount();
    int i = 0;
    boolean bool;
    for (bool = false; i < j; bool = bool1) {
      boolean bool1;
      View view = getChildAt(i);
      if (view.getVisibility() == 8) {
        bool1 = bool;
      } else {
        f f = (f)view.getLayoutParams();
        if (!f.j(0)) {
          bool1 = bool;
        } else {
          c<View> c = f.f();
          bool1 = bool;
          if (c != null)
            bool1 = bool | c.n(this, view, paramView, paramFloat1, paramFloat2, paramBoolean); 
        } 
      } 
      i++;
    } 
    if (bool)
      H(1); 
    return bool;
  }
  
  public boolean onNestedPreFling(View paramView, float paramFloat1, float paramFloat2) {
    int j = getChildCount();
    int i = 0;
    boolean bool;
    for (bool = false; i < j; bool = bool1) {
      boolean bool1;
      View view = getChildAt(i);
      if (view.getVisibility() == 8) {
        bool1 = bool;
      } else {
        f f = (f)view.getLayoutParams();
        if (!f.j(0)) {
          bool1 = bool;
        } else {
          c<View> c = f.f();
          bool1 = bool;
          if (c != null)
            bool1 = bool | c.o(this, view, paramView, paramFloat1, paramFloat2); 
        } 
      } 
      i++;
    } 
    return bool;
  }
  
  public void onNestedPreScroll(View paramView, int paramInt1, int paramInt2, int[] paramArrayOfint) {
    o(paramView, paramInt1, paramInt2, paramArrayOfint, 0);
  }
  
  public void onNestedScroll(View paramView, int paramInt1, int paramInt2, int paramInt3, int paramInt4) {
    k(paramView, paramInt1, paramInt2, paramInt3, paramInt4, 0);
  }
  
  public void onNestedScrollAccepted(View paramView1, View paramView2, int paramInt) {
    m(paramView1, paramView2, paramInt, 0);
  }
  
  protected void onRestoreInstanceState(Parcelable paramParcelable) {
    if (!(paramParcelable instanceof h)) {
      super.onRestoreInstanceState(paramParcelable);
      return;
    } 
    h h = (h)paramParcelable;
    super.onRestoreInstanceState(h.a());
    SparseArray<Parcelable> sparseArray = h.c;
    int i = 0;
    int j = getChildCount();
    while (i < j) {
      View view = getChildAt(i);
      int k = view.getId();
      c<View> c = y(view).f();
      if (k != -1 && c != null) {
        Parcelable parcelable = (Parcelable)sparseArray.get(k);
        if (parcelable != null)
          c.x(this, view, parcelable); 
      } 
      i++;
    } 
  }
  
  protected Parcelable onSaveInstanceState() {
    h h = new h(super.onSaveInstanceState());
    SparseArray<Parcelable> sparseArray = new SparseArray();
    int j = getChildCount();
    for (int i = 0; i < j; i++) {
      View view = getChildAt(i);
      int k = view.getId();
      c<View> c = ((f)view.getLayoutParams()).f();
      if (k != -1 && c != null) {
        Parcelable parcelable = c.y(this, view);
        if (parcelable != null)
          sparseArray.append(k, parcelable); 
      } 
    } 
    h.c = sparseArray;
    return (Parcelable)h;
  }
  
  public boolean onStartNestedScroll(View paramView1, View paramView2, int paramInt) {
    return l(paramView1, paramView2, paramInt, 0);
  }
  
  public void onStopNestedScroll(View paramView) {
    n(paramView, 0);
  }
  
  public boolean onTouchEvent(MotionEvent paramMotionEvent) {
    // Byte code:
    //   0: aload_1
    //   1: invokevirtual getActionMasked : ()I
    //   4: istore_2
    //   5: aload_0
    //   6: getfield k : Landroid/view/View;
    //   9: ifnonnull -> 29
    //   12: aload_0
    //   13: aload_1
    //   14: iconst_1
    //   15: invokespecial L : (Landroid/view/MotionEvent;I)Z
    //   18: istore_3
    //   19: iload_3
    //   20: istore #4
    //   22: iload_3
    //   23: ifeq -> 76
    //   26: goto -> 31
    //   29: iconst_0
    //   30: istore_3
    //   31: aload_0
    //   32: getfield k : Landroid/view/View;
    //   35: invokevirtual getLayoutParams : ()Landroid/view/ViewGroup$LayoutParams;
    //   38: checkcast androidx/coordinatorlayout/widget/CoordinatorLayout$f
    //   41: invokevirtual f : ()Landroidx/coordinatorlayout/widget/CoordinatorLayout$c;
    //   44: astore #8
    //   46: iload_3
    //   47: istore #4
    //   49: aload #8
    //   51: ifnull -> 76
    //   54: aload #8
    //   56: aload_0
    //   57: aload_0
    //   58: getfield k : Landroid/view/View;
    //   61: aload_1
    //   62: invokevirtual D : (Landroidx/coordinatorlayout/widget/CoordinatorLayout;Landroid/view/View;Landroid/view/MotionEvent;)Z
    //   65: istore #5
    //   67: iload_3
    //   68: istore #4
    //   70: iload #5
    //   72: istore_3
    //   73: goto -> 78
    //   76: iconst_0
    //   77: istore_3
    //   78: aload_0
    //   79: getfield k : Landroid/view/View;
    //   82: astore #9
    //   84: aconst_null
    //   85: astore #8
    //   87: aload #9
    //   89: ifnonnull -> 107
    //   92: iload_3
    //   93: aload_0
    //   94: aload_1
    //   95: invokespecial onTouchEvent : (Landroid/view/MotionEvent;)Z
    //   98: ior
    //   99: istore #5
    //   101: aload #8
    //   103: astore_1
    //   104: goto -> 144
    //   107: iload_3
    //   108: istore #5
    //   110: aload #8
    //   112: astore_1
    //   113: iload #4
    //   115: ifeq -> 144
    //   118: invokestatic uptimeMillis : ()J
    //   121: lstore #6
    //   123: lload #6
    //   125: lload #6
    //   127: iconst_3
    //   128: fconst_0
    //   129: fconst_0
    //   130: iconst_0
    //   131: invokestatic obtain : (JJIFFI)Landroid/view/MotionEvent;
    //   134: astore_1
    //   135: aload_0
    //   136: aload_1
    //   137: invokespecial onTouchEvent : (Landroid/view/MotionEvent;)Z
    //   140: pop
    //   141: iload_3
    //   142: istore #5
    //   144: aload_1
    //   145: ifnull -> 152
    //   148: aload_1
    //   149: invokevirtual recycle : ()V
    //   152: iload_2
    //   153: iconst_1
    //   154: if_icmpeq -> 162
    //   157: iload_2
    //   158: iconst_3
    //   159: if_icmpne -> 167
    //   162: aload_0
    //   163: iconst_0
    //   164: invokespecial Q : (Z)V
    //   167: iload #5
    //   169: ireturn
  }
  
  protected f p(ViewGroup.LayoutParams paramLayoutParams) {
    return (paramLayoutParams instanceof f) ? new f((f)paramLayoutParams) : ((paramLayoutParams instanceof ViewGroup.MarginLayoutParams) ? new f((ViewGroup.MarginLayoutParams)paramLayoutParams) : new f(paramLayoutParams));
  }
  
  void q(View paramView, boolean paramBoolean, Rect paramRect) {
    if (paramView.isLayoutRequested() || paramView.getVisibility() == 8) {
      paramRect.setEmpty();
      return;
    } 
    if (paramBoolean) {
      t(paramView, paramRect);
      return;
    } 
    paramRect.set(paramView.getLeft(), paramView.getTop(), paramView.getRight(), paramView.getBottom());
  }
  
  public List<View> r(View paramView) {
    List<View> list = this.b.h(paramView);
    this.d.clear();
    if (list != null)
      this.d.addAll(list); 
    return this.d;
  }
  
  public boolean requestChildRectangleOnScreen(View paramView, Rect paramRect, boolean paramBoolean) {
    c<View> c = ((f)paramView.getLayoutParams()).f();
    return (c != null && c.w(this, paramView, paramRect, paramBoolean)) ? true : super.requestChildRectangleOnScreen(paramView, paramRect, paramBoolean);
  }
  
  public void requestDisallowInterceptTouchEvent(boolean paramBoolean) {
    super.requestDisallowInterceptTouchEvent(paramBoolean);
    if (paramBoolean && !this.h) {
      Q(false);
      this.h = true;
    } 
  }
  
  public List<View> s(View paramView) {
    List<? extends View> list = this.b.g(paramView);
    this.d.clear();
    if (list != null)
      this.d.addAll(list); 
    return this.d;
  }
  
  public void setFitsSystemWindows(boolean paramBoolean) {
    super.setFitsSystemWindows(paramBoolean);
    X();
  }
  
  public void setOnHierarchyChangeListener(ViewGroup.OnHierarchyChangeListener paramOnHierarchyChangeListener) {
    this.r = paramOnHierarchyChangeListener;
  }
  
  public void setStatusBarBackground(Drawable paramDrawable) {
    Drawable drawable = this.q;
    if (drawable != paramDrawable) {
      Drawable drawable1 = null;
      if (drawable != null)
        drawable.setCallback(null); 
      if (paramDrawable != null)
        drawable1 = paramDrawable.mutate(); 
      this.q = drawable1;
      if (drawable1 != null) {
        boolean bool;
        if (drawable1.isStateful())
          this.q.setState(getDrawableState()); 
        androidx.core.graphics.drawable.a.m(this.q, o0.E((View)this));
        paramDrawable = this.q;
        if (getVisibility() == 0) {
          bool = true;
        } else {
          bool = false;
        } 
        paramDrawable.setVisible(bool, false);
        this.q.setCallback((Drawable.Callback)this);
      } 
      o0.i0((View)this);
    } 
  }
  
  public void setStatusBarBackgroundColor(int paramInt) {
    setStatusBarBackground((Drawable)new ColorDrawable(paramInt));
  }
  
  public void setStatusBarBackgroundResource(int paramInt) {
    Drawable drawable;
    if (paramInt != 0) {
      drawable = androidx.core.content.a.getDrawable(getContext(), paramInt);
    } else {
      drawable = null;
    } 
    setStatusBarBackground(drawable);
  }
  
  public void setVisibility(int paramInt) {
    boolean bool;
    super.setVisibility(paramInt);
    if (paramInt == 0) {
      bool = true;
    } else {
      bool = false;
    } 
    Drawable drawable = this.q;
    if (drawable != null && drawable.isVisible() != bool)
      this.q.setVisible(bool, false); 
  }
  
  void t(View paramView, Rect paramRect) {
    b.a(this, paramView, paramRect);
  }
  
  void u(View paramView, int paramInt, Rect paramRect1, Rect paramRect2) {
    f f = (f)paramView.getLayoutParams();
    int i = paramView.getMeasuredWidth();
    int j = paramView.getMeasuredHeight();
    v(paramView, paramInt, paramRect1, paramRect2, f, i, j);
    d(f, paramRect2, i, j);
  }
  
  protected boolean verifyDrawable(Drawable paramDrawable) {
    return (super.verifyDrawable(paramDrawable) || paramDrawable == this.q);
  }
  
  void x(View paramView, Rect paramRect) {
    paramRect.set(((f)paramView.getLayoutParams()).h());
  }
  
  f y(View paramView) {
    f f = (f)paramView.getLayoutParams();
    if (!f.b) {
      d d;
      if (paramView instanceof b) {
        c = ((b)paramView).getBehavior();
        if (c == null)
          Log.e("CoordinatorLayout", "Attached behavior class is null"); 
        f.o(c);
        f.b = true;
        return f;
      } 
      Class<?> clazz = c.getClass();
      c c = null;
      while (clazz != null) {
        d d1 = clazz.<d>getAnnotation(d.class);
        d = d1;
        if (d1 == null) {
          clazz = clazz.getSuperclass();
          d = d1;
        } 
      } 
      if (d != null)
        try {
          f.o(d.value().getDeclaredConstructor(new Class[0]).newInstance(new Object[0]));
        } catch (Exception exception) {
          StringBuilder stringBuilder = new StringBuilder();
          stringBuilder.append("Default behavior class ");
          stringBuilder.append(d.value().getName());
          stringBuilder.append(" could not be instantiated. Did you forget a default constructor?");
          Log.e("CoordinatorLayout", stringBuilder.toString(), exception);
        }  
      f.b = true;
    } 
    return f;
  }
  
  static {
    Package package_ = CoordinatorLayout.class.getPackage();
    if (package_ != null) {
      String str = package_.getName();
    } else {
      package_ = null;
    } 
    u = (String)package_;
  }
  
  class a implements i0 {
    a(CoordinatorLayout this$0) {}
    
    public u2 a(View param1View, u2 param1u2) {
      return this.a.W(param1u2);
    }
  }
  
  public static interface b {
    CoordinatorLayout.c getBehavior();
  }
  
  public static abstract class c<V extends View> {
    public c() {}
    
    public c(Context param1Context, AttributeSet param1AttributeSet) {}
    
    public boolean A(CoordinatorLayout param1CoordinatorLayout, V param1V, View param1View1, View param1View2, int param1Int1, int param1Int2) {
      return (param1Int2 == 0) ? z(param1CoordinatorLayout, param1V, param1View1, param1View2, param1Int1) : false;
    }
    
    @Deprecated
    public void B(CoordinatorLayout param1CoordinatorLayout, V param1V, View param1View) {}
    
    public void C(CoordinatorLayout param1CoordinatorLayout, V param1V, View param1View, int param1Int) {
      if (param1Int == 0)
        B(param1CoordinatorLayout, param1V, param1View); 
    }
    
    public boolean D(CoordinatorLayout param1CoordinatorLayout, V param1V, MotionEvent param1MotionEvent) {
      return false;
    }
    
    public boolean a(CoordinatorLayout param1CoordinatorLayout, V param1V) {
      return (d(param1CoordinatorLayout, param1V) > 0.0F);
    }
    
    public boolean b(CoordinatorLayout param1CoordinatorLayout, V param1V, Rect param1Rect) {
      return false;
    }
    
    public int c(CoordinatorLayout param1CoordinatorLayout, V param1V) {
      return -16777216;
    }
    
    public float d(CoordinatorLayout param1CoordinatorLayout, V param1V) {
      return 0.0F;
    }
    
    public boolean e(CoordinatorLayout param1CoordinatorLayout, V param1V, View param1View) {
      return false;
    }
    
    public u2 f(CoordinatorLayout param1CoordinatorLayout, V param1V, u2 param1u2) {
      return param1u2;
    }
    
    public void g(CoordinatorLayout.f param1f) {}
    
    public boolean h(CoordinatorLayout param1CoordinatorLayout, V param1V, View param1View) {
      return false;
    }
    
    public void i(CoordinatorLayout param1CoordinatorLayout, V param1V, View param1View) {}
    
    public void j() {}
    
    public boolean k(CoordinatorLayout param1CoordinatorLayout, V param1V, MotionEvent param1MotionEvent) {
      return false;
    }
    
    public boolean l(CoordinatorLayout param1CoordinatorLayout, V param1V, int param1Int) {
      return false;
    }
    
    public boolean m(CoordinatorLayout param1CoordinatorLayout, V param1V, int param1Int1, int param1Int2, int param1Int3, int param1Int4) {
      return false;
    }
    
    public boolean n(CoordinatorLayout param1CoordinatorLayout, V param1V, View param1View, float param1Float1, float param1Float2, boolean param1Boolean) {
      return false;
    }
    
    public boolean o(CoordinatorLayout param1CoordinatorLayout, V param1V, View param1View, float param1Float1, float param1Float2) {
      return false;
    }
    
    @Deprecated
    public void p(CoordinatorLayout param1CoordinatorLayout, V param1V, View param1View, int param1Int1, int param1Int2, int[] param1ArrayOfint) {}
    
    public void q(CoordinatorLayout param1CoordinatorLayout, V param1V, View param1View, int param1Int1, int param1Int2, int[] param1ArrayOfint, int param1Int3) {
      if (param1Int3 == 0)
        p(param1CoordinatorLayout, param1V, param1View, param1Int1, param1Int2, param1ArrayOfint); 
    }
    
    @Deprecated
    public void r(CoordinatorLayout param1CoordinatorLayout, V param1V, View param1View, int param1Int1, int param1Int2, int param1Int3, int param1Int4) {}
    
    @Deprecated
    public void s(CoordinatorLayout param1CoordinatorLayout, V param1V, View param1View, int param1Int1, int param1Int2, int param1Int3, int param1Int4, int param1Int5) {
      if (param1Int5 == 0)
        r(param1CoordinatorLayout, param1V, param1View, param1Int1, param1Int2, param1Int3, param1Int4); 
    }
    
    public void t(CoordinatorLayout param1CoordinatorLayout, V param1V, View param1View, int param1Int1, int param1Int2, int param1Int3, int param1Int4, int param1Int5, int[] param1ArrayOfint) {
      param1ArrayOfint[0] = param1ArrayOfint[0] + param1Int3;
      param1ArrayOfint[1] = param1ArrayOfint[1] + param1Int4;
      s(param1CoordinatorLayout, param1V, param1View, param1Int1, param1Int2, param1Int3, param1Int4, param1Int5);
    }
    
    @Deprecated
    public void u(CoordinatorLayout param1CoordinatorLayout, V param1V, View param1View1, View param1View2, int param1Int) {}
    
    public void v(CoordinatorLayout param1CoordinatorLayout, V param1V, View param1View1, View param1View2, int param1Int1, int param1Int2) {
      if (param1Int2 == 0)
        u(param1CoordinatorLayout, param1V, param1View1, param1View2, param1Int1); 
    }
    
    public boolean w(CoordinatorLayout param1CoordinatorLayout, V param1V, Rect param1Rect, boolean param1Boolean) {
      return false;
    }
    
    public void x(CoordinatorLayout param1CoordinatorLayout, V param1V, Parcelable param1Parcelable) {}
    
    public Parcelable y(CoordinatorLayout param1CoordinatorLayout, V param1V) {
      return (Parcelable)View.BaseSavedState.EMPTY_STATE;
    }
    
    @Deprecated
    public boolean z(CoordinatorLayout param1CoordinatorLayout, V param1V, View param1View1, View param1View2, int param1Int) {
      return false;
    }
  }
  
  @Deprecated
  @Retention(RetentionPolicy.RUNTIME)
  public static @interface d {
    Class<? extends CoordinatorLayout.c> value();
  }
  
  private class e implements ViewGroup.OnHierarchyChangeListener {
    e(CoordinatorLayout this$0) {}
    
    public void onChildViewAdded(View param1View1, View param1View2) {
      ViewGroup.OnHierarchyChangeListener onHierarchyChangeListener = this.a.r;
      if (onHierarchyChangeListener != null)
        onHierarchyChangeListener.onChildViewAdded(param1View1, param1View2); 
    }
    
    public void onChildViewRemoved(View param1View1, View param1View2) {
      this.a.H(2);
      ViewGroup.OnHierarchyChangeListener onHierarchyChangeListener = this.a.r;
      if (onHierarchyChangeListener != null)
        onHierarchyChangeListener.onChildViewRemoved(param1View1, param1View2); 
    }
  }
  
  public static class f extends ViewGroup.MarginLayoutParams {
    CoordinatorLayout.c a;
    
    boolean b = false;
    
    public int c = 0;
    
    public int d = 0;
    
    public int e = -1;
    
    int f = -1;
    
    public int g = 0;
    
    public int h = 0;
    
    int i;
    
    int j;
    
    View k;
    
    View l;
    
    private boolean m;
    
    private boolean n;
    
    private boolean o;
    
    private boolean p;
    
    final Rect q = new Rect();
    
    Object r;
    
    public f(int param1Int1, int param1Int2) {
      super(param1Int1, param1Int2);
    }
    
    f(Context param1Context, AttributeSet param1AttributeSet) {
      super(param1Context, param1AttributeSet);
      TypedArray typedArray = param1Context.obtainStyledAttributes(param1AttributeSet, s.c.e);
      this.c = typedArray.getInteger(s.c.f, 0);
      this.f = typedArray.getResourceId(s.c.g, -1);
      this.d = typedArray.getInteger(s.c.h, 0);
      this.e = typedArray.getInteger(s.c.l, -1);
      this.g = typedArray.getInt(s.c.k, 0);
      this.h = typedArray.getInt(s.c.j, 0);
      int i = s.c.i;
      boolean bool = typedArray.hasValue(i);
      this.b = bool;
      if (bool)
        this.a = CoordinatorLayout.K(param1Context, param1AttributeSet, typedArray.getString(i)); 
      typedArray.recycle();
      CoordinatorLayout.c c1 = this.a;
      if (c1 != null)
        c1.g(this); 
    }
    
    public f(ViewGroup.LayoutParams param1LayoutParams) {
      super(param1LayoutParams);
    }
    
    public f(ViewGroup.MarginLayoutParams param1MarginLayoutParams) {
      super(param1MarginLayoutParams);
    }
    
    public f(f param1f) {
      super(param1f);
    }
    
    private void n(View param1View, CoordinatorLayout param1CoordinatorLayout) {
      View view = param1CoordinatorLayout.findViewById(this.f);
      this.k = view;
      if (view != null) {
        if (view == param1CoordinatorLayout) {
          if (param1CoordinatorLayout.isInEditMode()) {
            this.l = null;
            this.k = null;
            return;
          } 
          throw new IllegalStateException("View can not be anchored to the the parent CoordinatorLayout");
        } 
        for (ViewParent viewParent = view.getParent(); viewParent != param1CoordinatorLayout && viewParent != null; viewParent = viewParent.getParent()) {
          if (viewParent == param1View) {
            if (param1CoordinatorLayout.isInEditMode()) {
              this.l = null;
              this.k = null;
              return;
            } 
            throw new IllegalStateException("Anchor must not be a descendant of the anchored view");
          } 
          if (viewParent instanceof View)
            view = (View)viewParent; 
        } 
        this.l = view;
        return;
      } 
      if (param1CoordinatorLayout.isInEditMode()) {
        this.l = null;
        this.k = null;
        return;
      } 
      StringBuilder stringBuilder = new StringBuilder();
      stringBuilder.append("Could not find CoordinatorLayout descendant view with id ");
      stringBuilder.append(param1CoordinatorLayout.getResources().getResourceName(this.f));
      stringBuilder.append(" to anchor view ");
      stringBuilder.append(param1View);
      throw new IllegalStateException(stringBuilder.toString());
    }
    
    private boolean s(View param1View, int param1Int) {
      int i = androidx.core.view.f.b(((f)param1View.getLayoutParams()).g, param1Int);
      return (i != 0 && (androidx.core.view.f.b(this.h, param1Int) & i) == i);
    }
    
    private boolean t(View param1View, CoordinatorLayout param1CoordinatorLayout) {
      if (this.k.getId() != this.f)
        return false; 
      View view = this.k;
      for (ViewParent viewParent = view.getParent(); viewParent != param1CoordinatorLayout; viewParent = viewParent.getParent()) {
        if (viewParent == null || viewParent == param1View) {
          this.l = null;
          this.k = null;
          return false;
        } 
        if (viewParent instanceof View)
          view = (View)viewParent; 
      } 
      this.l = view;
      return true;
    }
    
    boolean a() {
      return (this.k == null && this.f != -1);
    }
    
    boolean b(CoordinatorLayout param1CoordinatorLayout, View param1View1, View param1View2) {
      if (param1View2 != this.l && !s(param1View2, o0.E((View)param1CoordinatorLayout))) {
        CoordinatorLayout.c<View> c1 = this.a;
        if (c1 == null || !c1.e(param1CoordinatorLayout, param1View1, param1View2))
          return false; 
      } 
      return true;
    }
    
    boolean c() {
      if (this.a == null)
        this.m = false; 
      return this.m;
    }
    
    View d(CoordinatorLayout param1CoordinatorLayout, View param1View) {
      if (this.f == -1) {
        this.l = null;
        this.k = null;
        return null;
      } 
      if (this.k == null || !t(param1View, param1CoordinatorLayout))
        n(param1View, param1CoordinatorLayout); 
      return this.k;
    }
    
    public int e() {
      return this.f;
    }
    
    public CoordinatorLayout.c f() {
      return this.a;
    }
    
    boolean g() {
      return this.p;
    }
    
    Rect h() {
      return this.q;
    }
    
    boolean i(CoordinatorLayout param1CoordinatorLayout, View param1View) {
      boolean bool1;
      boolean bool2 = this.m;
      if (bool2)
        return true; 
      CoordinatorLayout.c<View> c1 = this.a;
      if (c1 != null) {
        bool1 = c1.a(param1CoordinatorLayout, param1View);
      } else {
        bool1 = false;
      } 
      bool1 |= bool2;
      this.m = bool1;
      return bool1;
    }
    
    boolean j(int param1Int) {
      return (param1Int != 0) ? ((param1Int != 1) ? false : this.o) : this.n;
    }
    
    void k() {
      this.p = false;
    }
    
    void l(int param1Int) {
      r(param1Int, false);
    }
    
    void m() {
      this.m = false;
    }
    
    public void o(CoordinatorLayout.c param1c) {
      CoordinatorLayout.c c1 = this.a;
      if (c1 != param1c) {
        if (c1 != null)
          c1.j(); 
        this.a = param1c;
        this.r = null;
        this.b = true;
        if (param1c != null)
          param1c.g(this); 
      } 
    }
    
    void p(boolean param1Boolean) {
      this.p = param1Boolean;
    }
    
    void q(Rect param1Rect) {
      this.q.set(param1Rect);
    }
    
    void r(int param1Int, boolean param1Boolean) {
      if (param1Int != 0) {
        if (param1Int != 1)
          return; 
        this.o = param1Boolean;
        return;
      } 
      this.n = param1Boolean;
    }
  }
  
  class g implements ViewTreeObserver.OnPreDrawListener {
    g(CoordinatorLayout this$0) {}
    
    public boolean onPreDraw() {
      this.a.H(0);
      return true;
    }
  }
  
  protected static class h extends androidx.customview.view.a {
    public static final Parcelable.Creator<h> CREATOR = (Parcelable.Creator<h>)new a();
    
    SparseArray<Parcelable> c;
    
    public h(Parcel param1Parcel, ClassLoader param1ClassLoader) {
      super(param1Parcel, param1ClassLoader);
      int j = param1Parcel.readInt();
      int[] arrayOfInt = new int[j];
      param1Parcel.readIntArray(arrayOfInt);
      Parcelable[] arrayOfParcelable = param1Parcel.readParcelableArray(param1ClassLoader);
      this.c = new SparseArray(j);
      for (int i = 0; i < j; i++)
        this.c.append(arrayOfInt[i], arrayOfParcelable[i]); 
    }
    
    public h(Parcelable param1Parcelable) {
      super(param1Parcelable);
    }
    
    public void writeToParcel(Parcel param1Parcel, int param1Int) {
      byte b;
      super.writeToParcel(param1Parcel, param1Int);
      SparseArray<Parcelable> sparseArray = this.c;
      int i = 0;
      if (sparseArray != null) {
        b = sparseArray.size();
      } else {
        b = 0;
      } 
      param1Parcel.writeInt(b);
      int[] arrayOfInt = new int[b];
      Parcelable[] arrayOfParcelable = new Parcelable[b];
      while (i < b) {
        arrayOfInt[i] = this.c.keyAt(i);
        arrayOfParcelable[i] = (Parcelable)this.c.valueAt(i);
        i++;
      } 
      param1Parcel.writeIntArray(arrayOfInt);
      param1Parcel.writeParcelableArray(arrayOfParcelable, param1Int);
    }
    
    static final class a implements Parcelable.ClassLoaderCreator<h> {
      public CoordinatorLayout.h a(Parcel param2Parcel) {
        return new CoordinatorLayout.h(param2Parcel, null);
      }
      
      public CoordinatorLayout.h b(Parcel param2Parcel, ClassLoader param2ClassLoader) {
        return new CoordinatorLayout.h(param2Parcel, param2ClassLoader);
      }
      
      public CoordinatorLayout.h[] c(int param2Int) {
        return new CoordinatorLayout.h[param2Int];
      }
    }
  }
  
  static final class a implements Parcelable.ClassLoaderCreator<h> {
    public CoordinatorLayout.h a(Parcel param1Parcel) {
      return new CoordinatorLayout.h(param1Parcel, null);
    }
    
    public CoordinatorLayout.h b(Parcel param1Parcel, ClassLoader param1ClassLoader) {
      return new CoordinatorLayout.h(param1Parcel, param1ClassLoader);
    }
    
    public CoordinatorLayout.h[] c(int param1Int) {
      return new CoordinatorLayout.h[param1Int];
    }
  }
  
  static class i implements Comparator<View> {
    public int a(View param1View1, View param1View2) {
      float f1 = o0.O(param1View1);
      float f2 = o0.O(param1View2);
      return (f1 > f2) ? -1 : ((f1 < f2) ? 1 : 0);
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Cricket Scorer-dex2jar.jar!\androidx\coordinatorlayout\widget\CoordinatorLayout.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */