package androidx.core.graphics.drawable;

import android.content.res.ColorStateList;
import android.os.Parcelable;
import androidx.versionedparcelable.VersionedParcel;

public class IconCompatParcelizer {
  public static IconCompat read(VersionedParcel paramVersionedParcel) {
    IconCompat iconCompat = new IconCompat();
    iconCompat.a = paramVersionedParcel.p(iconCompat.a, 1);
    iconCompat.c = paramVersionedParcel.j(iconCompat.c, 2);
    iconCompat.d = paramVersionedParcel.r(iconCompat.d, 3);
    iconCompat.e = paramVersionedParcel.p(iconCompat.e, 4);
    iconCompat.f = paramVersionedParcel.p(iconCompat.f, 5);
    iconCompat.g = (ColorStateList)paramVersionedParcel.r((Parcelable)iconCompat.g, 6);
    iconCompat.i = paramVersionedParcel.t(iconCompat.i, 7);
    iconCompat.j = paramVersionedParcel.t(iconCompat.j, 8);
    iconCompat.o();
    return iconCompat;
  }
  
  public static void write(IconCompat paramIconCompat, VersionedParcel paramVersionedParcel) {
    paramVersionedParcel.x(true, true);
    paramIconCompat.p(paramVersionedParcel.f());
    int i = paramIconCompat.a;
    if (-1 != i)
      paramVersionedParcel.F(i, 1); 
    byte[] arrayOfByte = paramIconCompat.c;
    if (arrayOfByte != null)
      paramVersionedParcel.B(arrayOfByte, 2); 
    Parcelable parcelable = paramIconCompat.d;
    if (parcelable != null)
      paramVersionedParcel.H(parcelable, 3); 
    i = paramIconCompat.e;
    if (i != 0)
      paramVersionedParcel.F(i, 4); 
    i = paramIconCompat.f;
    if (i != 0)
      paramVersionedParcel.F(i, 5); 
    ColorStateList colorStateList = paramIconCompat.g;
    if (colorStateList != null)
      paramVersionedParcel.H((Parcelable)colorStateList, 6); 
    String str2 = paramIconCompat.i;
    if (str2 != null)
      paramVersionedParcel.J(str2, 7); 
    String str1 = paramIconCompat.j;
    if (str1 != null)
      paramVersionedParcel.J(str1, 8); 
  }
}


/* Location:              C:\soft\dex2jar-2.0\Cricket Scorer-dex2jar.jar!\androidx\core\graphics\drawable\IconCompatParcelizer.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */