package androidx.core.graphics.drawable;

import android.content.res.ColorStateList;
import android.content.res.Resources;
import android.graphics.PorterDuff;
import android.graphics.drawable.Drawable;

final class n extends Drawable.ConstantState {
  int a;
  
  Drawable.ConstantState b;
  
  ColorStateList c = null;
  
  PorterDuff.Mode d = l.g;
  
  n(n paramn) {
    if (paramn != null) {
      this.a = paramn.a;
      this.b = paramn.b;
      this.c = paramn.c;
      this.d = paramn.d;
    } 
  }
  
  boolean a() {
    return (this.b != null);
  }
  
  public int getChangingConfigurations() {
    byte b;
    int i = this.a;
    Drawable.ConstantState constantState = this.b;
    if (constantState != null) {
      b = constantState.getChangingConfigurations();
    } else {
      b = 0;
    } 
    return i | b;
  }
  
  public Drawable newDrawable() {
    return newDrawable(null);
  }
  
  public Drawable newDrawable(Resources paramResources) {
    return new m(this, paramResources);
  }
}


/* Location:              C:\soft\dex2jar-2.0\Cricket Scorer-dex2jar.jar!\androidx\core\graphics\drawable\n.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */