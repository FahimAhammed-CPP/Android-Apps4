package androidx.core.graphics;

import android.graphics.Paint;
import android.graphics.Rect;
import android.os.Build;

public final class d {
  private static final ThreadLocal<androidx.core.util.d<Rect, Rect>> a = new ThreadLocal<androidx.core.util.d<Rect, Rect>>();
  
  public static boolean a(Paint paramPaint, String paramString) {
    if (Build.VERSION.SDK_INT >= 23)
      return a.a(paramPaint, paramString); 
    int i = paramString.length();
    if (i == 1 && Character.isWhitespace(paramString.charAt(0)))
      return true; 
    float f2 = paramPaint.measureText("󟿽");
    float f4 = paramPaint.measureText("m");
    float f3 = paramPaint.measureText(paramString);
    float f1 = 0.0F;
    if (f3 == 0.0F)
      return false; 
    if (paramString.codePointCount(0, paramString.length()) > 1) {
      if (f3 > f4 * 2.0F)
        return false; 
      int j;
      for (j = 0; j < i; j = k) {
        int k = Character.charCount(paramString.codePointAt(j)) + j;
        f1 += paramPaint.measureText(paramString, j, k);
      } 
      if (f3 >= f1)
        return false; 
    } 
    if (f3 != f2)
      return true; 
    androidx.core.util.d<Rect, Rect> d1 = b();
    paramPaint.getTextBounds("󟿽", 0, 2, (Rect)d1.a);
    paramPaint.getTextBounds(paramString, 0, i, (Rect)d1.b);
    return ((Rect)d1.a).equals(d1.b) ^ true;
  }
  
  private static androidx.core.util.d<Rect, Rect> b() {
    ThreadLocal<androidx.core.util.d<Rect, Rect>> threadLocal = a;
    androidx.core.util.d<Rect, Rect> d1 = threadLocal.get();
    if (d1 == null) {
      d1 = new androidx.core.util.d(new Rect(), new Rect());
      threadLocal.set(d1);
      return d1;
    } 
    ((Rect)d1.a).setEmpty();
    ((Rect)d1.b).setEmpty();
    return d1;
  }
  
  static class a {
    static boolean a(Paint param1Paint, String param1String) {
      return c.a(param1Paint, param1String);
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Cricket Scorer-dex2jar.jar!\androidx\core\graphics\d.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */