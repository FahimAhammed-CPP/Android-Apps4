package androidx.core.graphics;

import android.content.Context;
import android.content.res.Resources;
import android.graphics.Typeface;
import android.os.CancellationSignal;
import android.util.Log;
import androidx.core.content.res.e;
import androidx.core.provider.g;
import java.io.Closeable;
import java.io.File;
import java.io.IOException;
import java.io.InputStream;
import java.lang.reflect.Field;
import java.util.concurrent.ConcurrentHashMap;

class l {
  private ConcurrentHashMap<Long, e.c> a = new ConcurrentHashMap<Long, e.c>();
  
  private void a(Typeface paramTypeface, e.c paramc) {
    long l1 = j(paramTypeface);
    if (l1 != 0L)
      this.a.put(Long.valueOf(l1), paramc); 
  }
  
  private e.d f(e.c paramc, int paramInt) {
    return g(paramc.a(), paramInt, new b(this));
  }
  
  private static <T> T g(T[] paramArrayOfT, int paramInt, c<T> paramc) {
    char c1;
    boolean bool;
    if ((paramInt & 0x1) == 0) {
      c1 = 'Ɛ';
    } else {
      c1 = 'ʼ';
    } 
    if ((paramInt & 0x2) != 0) {
      bool = true;
    } else {
      bool = false;
    } 
    return h(paramArrayOfT, c1, bool, paramc);
  }
  
  private static <T> T h(T[] paramArrayOfT, int paramInt, boolean paramBoolean, c<T> paramc) {
    // Byte code:
    //   0: aload_0
    //   1: arraylength
    //   2: istore #8
    //   4: aconst_null
    //   5: astore #9
    //   7: ldc 2147483647
    //   9: istore #5
    //   11: iconst_0
    //   12: istore #4
    //   14: iload #4
    //   16: iload #8
    //   18: if_icmpge -> 109
    //   21: aload_0
    //   22: iload #4
    //   24: aaload
    //   25: astore #10
    //   27: aload_3
    //   28: aload #10
    //   30: invokeinterface a : (Ljava/lang/Object;)I
    //   35: iload_1
    //   36: isub
    //   37: invokestatic abs : (I)I
    //   40: istore #7
    //   42: aload_3
    //   43: aload #10
    //   45: invokeinterface b : (Ljava/lang/Object;)Z
    //   50: iload_2
    //   51: if_icmpne -> 60
    //   54: iconst_0
    //   55: istore #6
    //   57: goto -> 63
    //   60: iconst_1
    //   61: istore #6
    //   63: iload #7
    //   65: iconst_2
    //   66: imul
    //   67: iload #6
    //   69: iadd
    //   70: istore #7
    //   72: aload #9
    //   74: ifnull -> 88
    //   77: iload #5
    //   79: istore #6
    //   81: iload #5
    //   83: iload #7
    //   85: if_icmple -> 96
    //   88: aload #10
    //   90: astore #9
    //   92: iload #7
    //   94: istore #6
    //   96: iload #4
    //   98: iconst_1
    //   99: iadd
    //   100: istore #4
    //   102: iload #6
    //   104: istore #5
    //   106: goto -> 14
    //   109: aload #9
    //   111: areturn
  }
  
  private static long j(Typeface paramTypeface) {
    if (paramTypeface == null)
      return 0L; 
    try {
      Field field = Typeface.class.getDeclaredField("native_instance");
      field.setAccessible(true);
      return ((Number)field.get(paramTypeface)).longValue();
    } catch (NoSuchFieldException noSuchFieldException) {
      Log.e("TypefaceCompatBaseImpl", "Could not retrieve font from family.", noSuchFieldException);
      return 0L;
    } catch (IllegalAccessException illegalAccessException) {
      Log.e("TypefaceCompatBaseImpl", "Could not retrieve font from family.", illegalAccessException);
      return 0L;
    } 
  }
  
  public Typeface b(Context paramContext, e.c paramc, Resources paramResources, int paramInt) {
    e.d d = f(paramc, paramInt);
    if (d == null)
      return null; 
    Typeface typeface = f.d(paramContext, paramResources, d.b(), d.a(), 0, paramInt);
    a(typeface, paramc);
    return typeface;
  }
  
  public Typeface c(Context paramContext, CancellationSignal paramCancellationSignal, g.b[] paramArrayOfb, int paramInt) {
    int i = paramArrayOfb.length;
    Context context = null;
    if (i < 1)
      return null; 
    null = i(paramArrayOfb, paramInt);
    try {
      InputStream inputStream1;
      g.b[] arrayOfB;
      InputStream inputStream2 = paramContext.getContentResolver().openInputStream(null.d());
      try {
        return typeface;
      } catch (IOException iOException) {
      
      } finally {
        paramArrayOfb = null;
        inputStream1 = inputStream2;
      } 
      m.a(inputStream1);
      throw arrayOfB;
    } catch (IOException iOException) {
    
    } finally {
      paramContext = context;
      m.a((Closeable)paramContext);
    } 
    m.a((Closeable)paramCancellationSignal);
    return null;
  }
  
  protected Typeface d(Context paramContext, InputStream paramInputStream) {
    File file = m.e(paramContext);
    if (file == null)
      return null; 
    try {
      boolean bool = m.d(file, paramInputStream);
      if (!bool)
        return null; 
      return Typeface.createFromFile(file.getPath());
    } catch (RuntimeException runtimeException) {
      return null;
    } finally {
      file.delete();
    } 
  }
  
  public Typeface e(Context paramContext, Resources paramResources, int paramInt1, String paramString, int paramInt2) {
    File file = m.e(paramContext);
    if (file == null)
      return null; 
    try {
      boolean bool = m.c(file, paramResources, paramInt1);
      if (!bool)
        return null; 
      return Typeface.createFromFile(file.getPath());
    } catch (RuntimeException runtimeException) {
      return null;
    } finally {
      file.delete();
    } 
  }
  
  protected g.b i(g.b[] paramArrayOfb, int paramInt) {
    return g(paramArrayOfb, paramInt, new a(this));
  }
  
  class a implements c<g.b> {
    a(l this$0) {}
    
    public int c(g.b param1b) {
      return param1b.e();
    }
    
    public boolean d(g.b param1b) {
      return param1b.f();
    }
  }
  
  class b implements c<e.d> {
    b(l this$0) {}
    
    public int c(e.d param1d) {
      return param1d.e();
    }
    
    public boolean d(e.d param1d) {
      return param1d.f();
    }
  }
  
  private static interface c<T> {
    int a(T param1T);
    
    boolean b(T param1T);
  }
}


/* Location:              C:\soft\dex2jar-2.0\Cricket Scorer-dex2jar.jar!\androidx\core\graphics\l.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */