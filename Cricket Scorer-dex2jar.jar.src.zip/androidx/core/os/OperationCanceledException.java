package androidx.core.os;

import androidx.core.util.c;

public class OperationCanceledException extends RuntimeException {
  public OperationCanceledException() {
    this(null);
  }
  
  public OperationCanceledException(String paramString) {
    super(c.e(paramString, "The operation has been canceled."));
  }
}


/* Location:              C:\soft\dex2jar-2.0\Cricket Scorer-dex2jar.jar!\androidx\core\os\OperationCanceledException.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */