package androidx.core.content.res;

import android.content.res.ColorStateList;
import android.content.res.Resources;
import android.content.res.TypedArray;
import android.graphics.Color;
import android.util.AttributeSet;
import android.util.Log;
import android.util.TypedValue;
import android.util.Xml;
import java.io.IOException;
import org.xmlpull.v1.XmlPullParser;
import org.xmlpull.v1.XmlPullParserException;
import v.a;

public final class c {
  private static final ThreadLocal<TypedValue> a = new ThreadLocal<TypedValue>();
  
  public static ColorStateList a(Resources paramResources, XmlPullParser paramXmlPullParser, Resources.Theme paramTheme) throws XmlPullParserException, IOException {
    int i;
    AttributeSet attributeSet = Xml.asAttributeSet(paramXmlPullParser);
    while (true) {
      i = paramXmlPullParser.next();
      if (i != 2 && i != 1)
        continue; 
      break;
    } 
    if (i == 2)
      return b(paramResources, paramXmlPullParser, attributeSet, paramTheme); 
    throw new XmlPullParserException("No start tag found");
  }
  
  public static ColorStateList b(Resources paramResources, XmlPullParser paramXmlPullParser, AttributeSet paramAttributeSet, Resources.Theme paramTheme) throws XmlPullParserException, IOException {
    String str = paramXmlPullParser.getName();
    if (str.equals("selector"))
      return e(paramResources, paramXmlPullParser, paramAttributeSet, paramTheme); 
    StringBuilder stringBuilder = new StringBuilder();
    stringBuilder.append(paramXmlPullParser.getPositionDescription());
    stringBuilder.append(": invalid color state list tag ");
    stringBuilder.append(str);
    throw new XmlPullParserException(stringBuilder.toString());
  }
  
  private static TypedValue c() {
    ThreadLocal<TypedValue> threadLocal = a;
    TypedValue typedValue2 = threadLocal.get();
    TypedValue typedValue1 = typedValue2;
    if (typedValue2 == null) {
      typedValue1 = new TypedValue();
      threadLocal.set(typedValue1);
    } 
    return typedValue1;
  }
  
  public static ColorStateList d(Resources paramResources, int paramInt, Resources.Theme paramTheme) {
    try {
      return a(paramResources, (XmlPullParser)paramResources.getXml(paramInt), paramTheme);
    } catch (Exception exception) {
      Log.e("CSLCompat", "Failed to inflate ColorStateList.", exception);
      return null;
    } 
  }
  
  private static ColorStateList e(Resources paramResources, XmlPullParser paramXmlPullParser, AttributeSet paramAttributeSet, Resources.Theme paramTheme) throws XmlPullParserException, IOException {
    // Byte code:
    //   0: aload_1
    //   1: invokeinterface getDepth : ()I
    //   6: iconst_1
    //   7: iadd
    //   8: istore #12
    //   10: bipush #20
    //   12: anewarray [I
    //   15: astore #14
    //   17: bipush #20
    //   19: newarray int
    //   21: astore #15
    //   23: iconst_0
    //   24: istore #7
    //   26: aload_0
    //   27: astore #18
    //   29: aload_1
    //   30: invokeinterface next : ()I
    //   35: istore #8
    //   37: iload #8
    //   39: iconst_1
    //   40: if_icmpeq -> 525
    //   43: aload_1
    //   44: invokeinterface getDepth : ()I
    //   49: istore #9
    //   51: iload #9
    //   53: iload #12
    //   55: if_icmpge -> 64
    //   58: iload #8
    //   60: iconst_3
    //   61: if_icmpeq -> 525
    //   64: aload #15
    //   66: astore #17
    //   68: aload #14
    //   70: astore #16
    //   72: iload #7
    //   74: istore #6
    //   76: iload #8
    //   78: iconst_2
    //   79: if_icmpne -> 510
    //   82: aload #15
    //   84: astore #17
    //   86: aload #14
    //   88: astore #16
    //   90: iload #7
    //   92: istore #6
    //   94: iload #9
    //   96: iload #12
    //   98: if_icmpgt -> 510
    //   101: aload_1
    //   102: invokeinterface getName : ()Ljava/lang/String;
    //   107: ldc 'item'
    //   109: invokevirtual equals : (Ljava/lang/Object;)Z
    //   112: ifne -> 130
    //   115: aload #15
    //   117: astore #17
    //   119: aload #14
    //   121: astore #16
    //   123: iload #7
    //   125: istore #6
    //   127: goto -> 510
    //   130: aload #18
    //   132: aload_3
    //   133: aload_2
    //   134: getstatic t/d.b : [I
    //   137: invokestatic h : (Landroid/content/res/Resources;Landroid/content/res/Resources$Theme;Landroid/util/AttributeSet;[I)Landroid/content/res/TypedArray;
    //   140: astore #16
    //   142: getstatic t/d.c : I
    //   145: istore #6
    //   147: aload #16
    //   149: iload #6
    //   151: iconst_m1
    //   152: invokevirtual getResourceId : (II)I
    //   155: istore #8
    //   157: iload #8
    //   159: iconst_m1
    //   160: if_icmpeq -> 209
    //   163: aload #18
    //   165: iload #8
    //   167: invokestatic f : (Landroid/content/res/Resources;I)Z
    //   170: ifne -> 209
    //   173: aload #18
    //   175: aload #18
    //   177: iload #8
    //   179: invokevirtual getXml : (I)Landroid/content/res/XmlResourceParser;
    //   182: aload_3
    //   183: invokestatic a : (Landroid/content/res/Resources;Lorg/xmlpull/v1/XmlPullParser;Landroid/content/res/Resources$Theme;)Landroid/content/res/ColorStateList;
    //   186: invokevirtual getDefaultColor : ()I
    //   189: istore #6
    //   191: goto -> 220
    //   194: aload #16
    //   196: getstatic t/d.c : I
    //   199: ldc -65281
    //   201: invokevirtual getColor : (II)I
    //   204: istore #6
    //   206: goto -> 220
    //   209: aload #16
    //   211: iload #6
    //   213: ldc -65281
    //   215: invokevirtual getColor : (II)I
    //   218: istore #6
    //   220: fconst_1
    //   221: fstore #4
    //   223: getstatic t/d.d : I
    //   226: istore #8
    //   228: aload #16
    //   230: iload #8
    //   232: invokevirtual hasValue : (I)Z
    //   235: ifeq -> 251
    //   238: aload #16
    //   240: iload #8
    //   242: fconst_1
    //   243: invokevirtual getFloat : (IF)F
    //   246: fstore #4
    //   248: goto -> 276
    //   251: getstatic t/d.f : I
    //   254: istore #8
    //   256: aload #16
    //   258: iload #8
    //   260: invokevirtual hasValue : (I)Z
    //   263: ifeq -> 276
    //   266: aload #16
    //   268: iload #8
    //   270: fconst_1
    //   271: invokevirtual getFloat : (IF)F
    //   274: fstore #4
    //   276: getstatic android/os/Build$VERSION.SDK_INT : I
    //   279: bipush #31
    //   281: if_icmplt -> 313
    //   284: getstatic t/d.e : I
    //   287: istore #8
    //   289: aload #16
    //   291: iload #8
    //   293: invokevirtual hasValue : (I)Z
    //   296: ifeq -> 313
    //   299: aload #16
    //   301: iload #8
    //   303: ldc -1.0
    //   305: invokevirtual getFloat : (IF)F
    //   308: fstore #5
    //   310: goto -> 325
    //   313: aload #16
    //   315: getstatic t/d.g : I
    //   318: ldc -1.0
    //   320: invokevirtual getFloat : (IF)F
    //   323: fstore #5
    //   325: aload #16
    //   327: invokevirtual recycle : ()V
    //   330: aload_2
    //   331: invokeinterface getAttributeCount : ()I
    //   336: istore #13
    //   338: iload #13
    //   340: newarray int
    //   342: astore #16
    //   344: iconst_0
    //   345: istore #8
    //   347: iconst_0
    //   348: istore #9
    //   350: iload #8
    //   352: iload #13
    //   354: if_icmpge -> 463
    //   357: aload_2
    //   358: iload #8
    //   360: invokeinterface getAttributeNameResource : (I)I
    //   365: istore #11
    //   367: iload #9
    //   369: istore #10
    //   371: iload #11
    //   373: ldc 16843173
    //   375: if_icmpeq -> 450
    //   378: iload #9
    //   380: istore #10
    //   382: iload #11
    //   384: ldc 16843551
    //   386: if_icmpeq -> 450
    //   389: iload #9
    //   391: istore #10
    //   393: iload #11
    //   395: getstatic t/a.a : I
    //   398: if_icmpeq -> 450
    //   401: iload #9
    //   403: istore #10
    //   405: iload #11
    //   407: getstatic t/a.b : I
    //   410: if_icmpeq -> 450
    //   413: aload_2
    //   414: iload #8
    //   416: iconst_0
    //   417: invokeinterface getAttributeBooleanValue : (IZ)Z
    //   422: ifeq -> 432
    //   425: iload #11
    //   427: istore #10
    //   429: goto -> 437
    //   432: iload #11
    //   434: ineg
    //   435: istore #10
    //   437: aload #16
    //   439: iload #9
    //   441: iload #10
    //   443: iastore
    //   444: iload #9
    //   446: iconst_1
    //   447: iadd
    //   448: istore #10
    //   450: iload #8
    //   452: iconst_1
    //   453: iadd
    //   454: istore #8
    //   456: iload #10
    //   458: istore #9
    //   460: goto -> 350
    //   463: aload #16
    //   465: iload #9
    //   467: invokestatic trimStateSet : ([II)[I
    //   470: astore #16
    //   472: aload #15
    //   474: iload #7
    //   476: iload #6
    //   478: fload #4
    //   480: fload #5
    //   482: invokestatic g : (IFF)I
    //   485: invokestatic a : ([III)[I
    //   488: astore #17
    //   490: aload #14
    //   492: iload #7
    //   494: aload #16
    //   496: invokestatic b : ([Ljava/lang/Object;ILjava/lang/Object;)[Ljava/lang/Object;
    //   499: checkcast [[I
    //   502: astore #16
    //   504: iload #7
    //   506: iconst_1
    //   507: iadd
    //   508: istore #6
    //   510: aload #17
    //   512: astore #15
    //   514: aload #16
    //   516: astore #14
    //   518: iload #6
    //   520: istore #7
    //   522: goto -> 26
    //   525: iload #7
    //   527: newarray int
    //   529: astore_0
    //   530: iload #7
    //   532: anewarray [I
    //   535: astore_1
    //   536: aload #15
    //   538: iconst_0
    //   539: aload_0
    //   540: iconst_0
    //   541: iload #7
    //   543: invokestatic arraycopy : (Ljava/lang/Object;ILjava/lang/Object;II)V
    //   546: aload #14
    //   548: iconst_0
    //   549: aload_1
    //   550: iconst_0
    //   551: iload #7
    //   553: invokestatic arraycopy : (Ljava/lang/Object;ILjava/lang/Object;II)V
    //   556: new android/content/res/ColorStateList
    //   559: dup
    //   560: aload_1
    //   561: aload_0
    //   562: invokespecial <init> : ([[I[I)V
    //   565: areturn
    //   566: astore #17
    //   568: goto -> 194
    // Exception table:
    //   from	to	target	type
    //   173	191	566	java/lang/Exception
  }
  
  private static boolean f(Resources paramResources, int paramInt) {
    TypedValue typedValue = c();
    paramResources.getValue(paramInt, typedValue, true);
    paramInt = typedValue.type;
    return (paramInt >= 28 && paramInt <= 31);
  }
  
  private static int g(int paramInt, float paramFloat1, float paramFloat2) {
    boolean bool;
    if (paramFloat2 >= 0.0F && paramFloat2 <= 100.0F) {
      bool = true;
    } else {
      bool = false;
    } 
    if (paramFloat1 == 1.0F && !bool)
      return paramInt; 
    int j = a.b((int)(Color.alpha(paramInt) * paramFloat1 + 0.5F), 0, 255);
    int i = paramInt;
    if (bool) {
      a a = a.c(paramInt);
      i = a.m(a.j(), a.i(), paramFloat2);
    } 
    return i & 0xFFFFFF | j << 24;
  }
  
  private static TypedArray h(Resources paramResources, Resources.Theme paramTheme, AttributeSet paramAttributeSet, int[] paramArrayOfint) {
    return (paramTheme == null) ? paramResources.obtainAttributes(paramAttributeSet, paramArrayOfint) : paramTheme.obtainStyledAttributes(paramAttributeSet, paramArrayOfint, 0, 0);
  }
}


/* Location:              C:\soft\dex2jar-2.0\Cricket Scorer-dex2jar.jar!\androidx\core\content\res\c.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */