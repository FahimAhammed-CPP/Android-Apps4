package androidx.core.content.res;

final class o {
  static final o k = k(b.c, (float)(b.h(50.0F) * 63.66197723675813D / 100.0D), 50.0F, 2.0F, false);
  
  private final float a;
  
  private final float b;
  
  private final float c;
  
  private final float d;
  
  private final float e;
  
  private final float f;
  
  private final float[] g;
  
  private final float h;
  
  private final float i;
  
  private final float j;
  
  private o(float paramFloat1, float paramFloat2, float paramFloat3, float paramFloat4, float paramFloat5, float paramFloat6, float[] paramArrayOffloat, float paramFloat7, float paramFloat8, float paramFloat9) {
    this.f = paramFloat1;
    this.a = paramFloat2;
    this.b = paramFloat3;
    this.c = paramFloat4;
    this.d = paramFloat5;
    this.e = paramFloat6;
    this.g = paramArrayOffloat;
    this.h = paramFloat7;
    this.i = paramFloat8;
    this.j = paramFloat9;
  }
  
  static o k(float[] paramArrayOffloat, float paramFloat1, float paramFloat2, float paramFloat3, boolean paramBoolean) {
    float[][] arrayOfFloat = b.a;
    float f1 = paramArrayOffloat[0];
    float[] arrayOfFloat2 = arrayOfFloat[0];
    float f2 = arrayOfFloat2[0];
    float f4 = paramArrayOffloat[1];
    float f3 = arrayOfFloat2[1];
    float f5 = paramArrayOffloat[2];
    f2 = f2 * f1 + f3 * f4 + arrayOfFloat2[2] * f5;
    arrayOfFloat2 = arrayOfFloat[1];
    f3 = arrayOfFloat2[0] * f1 + arrayOfFloat2[1] * f4 + arrayOfFloat2[2] * f5;
    float[] arrayOfFloat1 = arrayOfFloat[2];
    f5 = f1 * arrayOfFloat1[0] + f4 * arrayOfFloat1[1] + f5 * arrayOfFloat1[2];
    f4 = paramFloat3 / 10.0F + 0.8F;
    if (f4 >= 0.9D) {
      f1 = b.d(0.59F, 0.69F, (f4 - 0.9F) * 10.0F);
    } else {
      f1 = b.d(0.525F, 0.59F, (f4 - 0.8F) * 10.0F);
    } 
    if (paramBoolean) {
      paramFloat3 = 1.0F;
    } else {
      paramFloat3 = (1.0F - (float)Math.exp(((-paramFloat1 - 42.0F) / 92.0F)) * 0.2777778F) * f4;
    } 
    double d = paramFloat3;
    if (d > 1.0D) {
      paramFloat3 = 1.0F;
    } else if (d < 0.0D) {
      paramFloat3 = 0.0F;
    } 
    arrayOfFloat1 = new float[3];
    arrayOfFloat1[0] = 100.0F / f2 * paramFloat3 + 1.0F - paramFloat3;
    arrayOfFloat1[1] = 100.0F / f3 * paramFloat3 + 1.0F - paramFloat3;
    arrayOfFloat1[2] = 100.0F / f5 * paramFloat3 + 1.0F - paramFloat3;
    paramFloat3 = 1.0F / (5.0F * paramFloat1 + 1.0F);
    paramFloat3 = paramFloat3 * paramFloat3 * paramFloat3 * paramFloat3;
    float f6 = 1.0F - paramFloat3;
    paramFloat1 = paramFloat3 * paramFloat1 + 0.1F * f6 * f6 * (float)Math.cbrt(paramFloat1 * 5.0D);
    paramFloat2 = b.h(paramFloat2) / paramArrayOffloat[1];
    d = paramFloat2;
    paramFloat3 = (float)Math.sqrt(d);
    f6 = 0.725F / (float)Math.pow(d, 0.2D);
    paramArrayOffloat = new float[3];
    paramArrayOffloat[0] = (float)Math.pow((arrayOfFloat1[0] * paramFloat1 * f2) / 100.0D, 0.42D);
    paramArrayOffloat[1] = (float)Math.pow((arrayOfFloat1[1] * paramFloat1 * f3) / 100.0D, 0.42D);
    f2 = (float)Math.pow((arrayOfFloat1[2] * paramFloat1 * f5) / 100.0D, 0.42D);
    paramArrayOffloat[2] = f2;
    f3 = paramArrayOffloat[0];
    f3 = f3 * 400.0F / (f3 + 27.13F);
    f5 = paramArrayOffloat[1];
    return new o(paramFloat2, (f3 * 2.0F + f5 * 400.0F / (f5 + 27.13F) + 400.0F * f2 / (f2 + 27.13F) * 0.05F) * f6, f6, f6, f1, f4, arrayOfFloat1, paramFloat1, (float)Math.pow(paramFloat1, 0.25D), paramFloat3 + 1.48F);
  }
  
  float a() {
    return this.a;
  }
  
  float b() {
    return this.d;
  }
  
  float c() {
    return this.h;
  }
  
  float d() {
    return this.i;
  }
  
  float e() {
    return this.f;
  }
  
  float f() {
    return this.b;
  }
  
  float g() {
    return this.e;
  }
  
  float h() {
    return this.c;
  }
  
  float[] i() {
    return this.g;
  }
  
  float j() {
    return this.j;
  }
}


/* Location:              C:\soft\dex2jar-2.0\Cricket Scorer-dex2jar.jar!\androidx\core\content\res\o.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */