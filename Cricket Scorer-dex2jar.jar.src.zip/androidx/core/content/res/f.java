package androidx.core.content.res;

import android.content.res.Resources;
import android.content.res.TypedArray;
import android.graphics.LinearGradient;
import android.graphics.RadialGradient;
import android.graphics.Shader;
import android.graphics.SweepGradient;
import android.util.AttributeSet;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import org.xmlpull.v1.XmlPullParser;
import org.xmlpull.v1.XmlPullParserException;
import t.d;

final class f {
  private static a a(a parama, int paramInt1, int paramInt2, boolean paramBoolean, int paramInt3) {
    return (parama != null) ? parama : (paramBoolean ? new a(paramInt1, paramInt3, paramInt2) : new a(paramInt1, paramInt2));
  }
  
  static Shader b(Resources paramResources, XmlPullParser paramXmlPullParser, AttributeSet paramAttributeSet, Resources.Theme paramTheme) throws IOException, XmlPullParserException {
    TypedArray typedArray;
    String str = paramXmlPullParser.getName();
    if (str.equals("gradient")) {
      typedArray = n.s(paramResources, paramTheme, paramAttributeSet, d.A);
      float f1 = n.j(typedArray, paramXmlPullParser, "startX", d.J, 0.0F);
      float f2 = n.j(typedArray, paramXmlPullParser, "startY", d.K, 0.0F);
      float f3 = n.j(typedArray, paramXmlPullParser, "endX", d.L, 0.0F);
      float f4 = n.j(typedArray, paramXmlPullParser, "endY", d.M, 0.0F);
      float f5 = n.j(typedArray, paramXmlPullParser, "centerX", d.E, 0.0F);
      float f6 = n.j(typedArray, paramXmlPullParser, "centerY", d.F, 0.0F);
      int i = n.k(typedArray, paramXmlPullParser, "type", d.D, 0);
      int j = n.f(typedArray, paramXmlPullParser, "startColor", d.B, 0);
      boolean bool = n.r(paramXmlPullParser, "centerColor");
      int k = n.f(typedArray, paramXmlPullParser, "centerColor", d.I, 0);
      int m = n.f(typedArray, paramXmlPullParser, "endColor", d.C, 0);
      int n = n.k(typedArray, paramXmlPullParser, "tileMode", d.H, 0);
      float f7 = n.j(typedArray, paramXmlPullParser, "gradientRadius", d.G, 0.0F);
      typedArray.recycle();
      a a = a(c(paramResources, paramXmlPullParser, paramAttributeSet, paramTheme), j, m, bool, k);
      if (i != 1)
        return (Shader)((i != 2) ? new LinearGradient(f1, f2, f3, f4, a.a, a.b, d(n)) : new SweepGradient(f5, f6, a.a, a.b)); 
      if (f7 > 0.0F)
        return (Shader)new RadialGradient(f5, f6, f7, a.a, a.b, d(n)); 
      throw new XmlPullParserException("<gradient> tag requires 'gradientRadius' attribute with radial type");
    } 
    StringBuilder stringBuilder = new StringBuilder();
    stringBuilder.append(paramXmlPullParser.getPositionDescription());
    stringBuilder.append(": invalid gradient color tag ");
    stringBuilder.append((String)typedArray);
    throw new XmlPullParserException(stringBuilder.toString());
  }
  
  private static a c(Resources paramResources, XmlPullParser paramXmlPullParser, AttributeSet paramAttributeSet, Resources.Theme paramTheme) throws XmlPullParserException, IOException {
    int i = paramXmlPullParser.getDepth() + 1;
    ArrayList<Float> arrayList = new ArrayList(20);
    ArrayList<Integer> arrayList1 = new ArrayList(20);
    while (true) {
      int j = paramXmlPullParser.next();
      if (j != 1) {
        int k = paramXmlPullParser.getDepth();
        if (k >= i || j != 3) {
          if (j != 2 || k > i || !paramXmlPullParser.getName().equals("item"))
            continue; 
          TypedArray typedArray = n.s(paramResources, paramTheme, paramAttributeSet, d.N);
          k = d.O;
          boolean bool1 = typedArray.hasValue(k);
          j = d.P;
          boolean bool2 = typedArray.hasValue(j);
          if (bool1 && bool2) {
            k = typedArray.getColor(k, 0);
            float f1 = typedArray.getFloat(j, 0.0F);
            typedArray.recycle();
            arrayList1.add(Integer.valueOf(k));
            arrayList.add(Float.valueOf(f1));
            continue;
          } 
          StringBuilder stringBuilder = new StringBuilder();
          stringBuilder.append(paramXmlPullParser.getPositionDescription());
          stringBuilder.append(": <item> tag requires a 'color' attribute and a 'offset' attribute!");
          throw new XmlPullParserException(stringBuilder.toString());
        } 
      } 
      break;
    } 
    return (arrayList1.size() > 0) ? new a(arrayList1, arrayList) : null;
  }
  
  private static Shader.TileMode d(int paramInt) {
    return (paramInt != 1) ? ((paramInt != 2) ? Shader.TileMode.CLAMP : Shader.TileMode.MIRROR) : Shader.TileMode.REPEAT;
  }
  
  static final class a {
    final int[] a;
    
    final float[] b;
    
    a(int param1Int1, int param1Int2) {
      this.a = new int[] { param1Int1, param1Int2 };
      this.b = new float[] { 0.0F, 1.0F };
    }
    
    a(int param1Int1, int param1Int2, int param1Int3) {
      this.a = new int[] { param1Int1, param1Int2, param1Int3 };
      this.b = new float[] { 0.0F, 0.5F, 1.0F };
    }
    
    a(List<Integer> param1List, List<Float> param1List1) {
      int j = param1List.size();
      this.a = new int[j];
      this.b = new float[j];
      for (int i = 0; i < j; i++) {
        this.a[i] = ((Integer)param1List.get(i)).intValue();
        this.b[i] = ((Float)param1List1.get(i)).floatValue();
      } 
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Cricket Scorer-dex2jar.jar!\androidx\core\content\res\f.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */