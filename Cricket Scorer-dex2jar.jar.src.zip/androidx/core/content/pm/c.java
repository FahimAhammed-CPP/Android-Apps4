package androidx.core.content.pm;

import android.content.pm.PackageInfo;
import android.content.pm.PackageManager;
import android.content.pm.Signature;
import android.content.pm.SigningInfo;
import android.os.Build;

public final class c {
  public static long a(PackageInfo paramPackageInfo) {
    return (Build.VERSION.SDK_INT >= 28) ? a.b(paramPackageInfo) : paramPackageInfo.versionCode;
  }
  
  private static class a {
    static Signature[] a(SigningInfo param1SigningInfo) {
      return param1SigningInfo.getApkContentsSigners();
    }
    
    static long b(PackageInfo param1PackageInfo) {
      return b.a(param1PackageInfo);
    }
    
    static Signature[] c(SigningInfo param1SigningInfo) {
      return param1SigningInfo.getSigningCertificateHistory();
    }
    
    static boolean d(SigningInfo param1SigningInfo) {
      return param1SigningInfo.hasMultipleSigners();
    }
    
    static boolean e(PackageManager param1PackageManager, String param1String, byte[] param1ArrayOfbyte, int param1Int) {
      return a.a(param1PackageManager, param1String, param1ArrayOfbyte, param1Int);
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Cricket Scorer-dex2jar.jar!\androidx\core\content\pm\c.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */