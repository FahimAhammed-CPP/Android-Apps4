package androidx.core.content;

import android.content.res.Configuration;
import androidx.core.util.a;

public interface k {
  void addOnConfigurationChangedListener(a<Configuration> parama);
  
  void removeOnConfigurationChangedListener(a<Configuration> parama);
}


/* Location:              C:\soft\dex2jar-2.0\Cricket Scorer-dex2jar.jar!\androidx\core\content\k.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */