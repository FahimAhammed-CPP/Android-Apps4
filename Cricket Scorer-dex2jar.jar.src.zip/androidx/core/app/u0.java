package androidx.core.app;

import android.os.Bundle;
import android.os.Parcelable;
import androidx.core.graphics.drawable.IconCompat;

class u0 {
  private static final Object a = new Object();
  
  private static final Object b = new Object();
  
  static Bundle a(v.a parama) {
    boolean bool;
    Bundle bundle1;
    Bundle bundle2 = new Bundle();
    IconCompat iconCompat = parama.d();
    if (iconCompat != null) {
      bool = iconCompat.j();
    } else {
      bool = false;
    } 
    bundle2.putInt("icon", bool);
    bundle2.putCharSequence("title", parama.h());
    bundle2.putParcelable("actionIntent", (Parcelable)parama.a());
    if (parama.c() != null) {
      bundle1 = new Bundle(parama.c());
    } else {
      bundle1 = new Bundle();
    } 
    bundle1.putBoolean("android.support.allowGeneratedReplies", parama.b());
    bundle2.putBundle("extras", bundle1);
    bundle2.putParcelableArray("remoteInputs", (Parcelable[])c(parama.e()));
    bundle2.putBoolean("showsUserInterface", parama.g());
    bundle2.putInt("semanticAction", parama.f());
    return bundle2;
  }
  
  private static Bundle b(b1 paramb1) {
    new Bundle();
    throw null;
  }
  
  private static Bundle[] c(b1[] paramArrayOfb1) {
    if (paramArrayOfb1 == null)
      return null; 
    Bundle[] arrayOfBundle = new Bundle[paramArrayOfb1.length];
    for (int i = 0; i < paramArrayOfb1.length; i++) {
      b1 b11 = paramArrayOfb1[i];
      arrayOfBundle[i] = b(null);
    } 
    return arrayOfBundle;
  }
}


/* Location:              C:\soft\dex2jar-2.0\Cricket Scorer-dex2jar.jar!\androidx\core\ap\\u0.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */