package androidx.core.app;

import android.app.AppOpsManager;
import android.app.Notification;
import android.app.NotificationManager;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.content.ServiceConnection;
import android.content.pm.ApplicationInfo;
import android.content.pm.ResolveInfo;
import android.content.pm.ServiceInfo;
import android.os.Build;
import android.os.Bundle;
import android.os.DeadObjectException;
import android.os.Handler;
import android.os.HandlerThread;
import android.os.IBinder;
import android.os.Message;
import android.os.RemoteException;
import android.util.Log;
import java.util.ArrayDeque;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Set;

public final class w0 {
  private static final Object c = new Object();
  
  private static String d;
  
  private static Set<String> e = new HashSet<String>();
  
  private static final Object f = new Object();
  
  private static c g;
  
  private final Context a;
  
  private final NotificationManager b;
  
  private w0(Context paramContext) {
    this.a = paramContext;
    this.b = (NotificationManager)paramContext.getSystemService("notification");
  }
  
  public static w0 b(Context paramContext) {
    return new w0(paramContext);
  }
  
  public static Set<String> c(Context paramContext) {
    // Byte code:
    //   0: aload_0
    //   1: invokevirtual getContentResolver : ()Landroid/content/ContentResolver;
    //   4: ldc 'enabled_notification_listeners'
    //   6: invokestatic getString : (Landroid/content/ContentResolver;Ljava/lang/String;)Ljava/lang/String;
    //   9: astore_3
    //   10: getstatic androidx/core/app/w0.c : Ljava/lang/Object;
    //   13: astore_0
    //   14: aload_0
    //   15: monitorenter
    //   16: aload_3
    //   17: ifnull -> 101
    //   20: aload_3
    //   21: getstatic androidx/core/app/w0.d : Ljava/lang/String;
    //   24: invokevirtual equals : (Ljava/lang/Object;)Z
    //   27: ifne -> 101
    //   30: aload_3
    //   31: ldc ':'
    //   33: iconst_m1
    //   34: invokevirtual split : (Ljava/lang/String;I)[Ljava/lang/String;
    //   37: astore #4
    //   39: new java/util/HashSet
    //   42: dup
    //   43: aload #4
    //   45: arraylength
    //   46: invokespecial <init> : (I)V
    //   49: astore #5
    //   51: aload #4
    //   53: arraylength
    //   54: istore_2
    //   55: iconst_0
    //   56: istore_1
    //   57: iload_1
    //   58: iload_2
    //   59: if_icmpge -> 92
    //   62: aload #4
    //   64: iload_1
    //   65: aaload
    //   66: invokestatic unflattenFromString : (Ljava/lang/String;)Landroid/content/ComponentName;
    //   69: astore #6
    //   71: aload #6
    //   73: ifnull -> 114
    //   76: aload #5
    //   78: aload #6
    //   80: invokevirtual getPackageName : ()Ljava/lang/String;
    //   83: invokeinterface add : (Ljava/lang/Object;)Z
    //   88: pop
    //   89: goto -> 114
    //   92: aload #5
    //   94: putstatic androidx/core/app/w0.e : Ljava/util/Set;
    //   97: aload_3
    //   98: putstatic androidx/core/app/w0.d : Ljava/lang/String;
    //   101: getstatic androidx/core/app/w0.e : Ljava/util/Set;
    //   104: astore_3
    //   105: aload_0
    //   106: monitorexit
    //   107: aload_3
    //   108: areturn
    //   109: astore_3
    //   110: aload_0
    //   111: monitorexit
    //   112: aload_3
    //   113: athrow
    //   114: iload_1
    //   115: iconst_1
    //   116: iadd
    //   117: istore_1
    //   118: goto -> 57
    // Exception table:
    //   from	to	target	type
    //   20	55	109	finally
    //   62	71	109	finally
    //   76	89	109	finally
    //   92	101	109	finally
    //   101	107	109	finally
    //   110	112	109	finally
  }
  
  private void f(d paramd) {
    synchronized (f) {
      if (g == null)
        g = new c(this.a.getApplicationContext()); 
      g.h(paramd);
      return;
    } 
  }
  
  private static boolean g(Notification paramNotification) {
    Bundle bundle = v.a(paramNotification);
    return (bundle != null && bundle.getBoolean("android.support.useSideChannel"));
  }
  
  public boolean a() {
    if (Build.VERSION.SDK_INT >= 24)
      return v0.a(this.b); 
    AppOpsManager appOpsManager = (AppOpsManager)this.a.getSystemService("appops");
    ApplicationInfo applicationInfo = this.a.getApplicationInfo();
    String str = this.a.getApplicationContext().getPackageName();
    int i = applicationInfo.uid;
    try {
      Class<?> clazz = Class.forName(AppOpsManager.class.getName());
      Class<int> clazz1 = int.class;
      i = ((Integer)clazz.getMethod("checkOpNoThrow", new Class[] { clazz1, clazz1, String.class }).invoke(appOpsManager, new Object[] { Integer.valueOf(((Integer)clazz.getDeclaredField("OP_POST_NOTIFICATION").get(Integer.class)).intValue()), Integer.valueOf(i), str })).intValue();
      return (i == 0);
    } catch (ClassNotFoundException|NoSuchMethodException|NoSuchFieldException|java.lang.reflect.InvocationTargetException|IllegalAccessException|RuntimeException classNotFoundException) {
      return true;
    } 
  }
  
  public void d(int paramInt, Notification paramNotification) {
    e(null, paramInt, paramNotification);
  }
  
  public void e(String paramString, int paramInt, Notification paramNotification) {
    if (g(paramNotification)) {
      f(new a(this.a.getPackageName(), paramInt, paramString, paramNotification));
      this.b.cancel(paramString, paramInt);
      return;
    } 
    this.b.notify(paramString, paramInt, paramNotification);
  }
  
  private static class a implements d {
    final String a;
    
    final int b;
    
    final String c;
    
    final Notification d;
    
    a(String param1String1, int param1Int, String param1String2, Notification param1Notification) {
      this.a = param1String1;
      this.b = param1Int;
      this.c = param1String2;
      this.d = param1Notification;
    }
    
    public void a(b.a param1a) throws RemoteException {
      param1a.P0(this.a, this.b, this.c, this.d);
    }
    
    public String toString() {
      StringBuilder stringBuilder = new StringBuilder("NotifyTask[");
      stringBuilder.append("packageName:");
      stringBuilder.append(this.a);
      stringBuilder.append(", id:");
      stringBuilder.append(this.b);
      stringBuilder.append(", tag:");
      stringBuilder.append(this.c);
      stringBuilder.append("]");
      return stringBuilder.toString();
    }
  }
  
  private static class b {
    final ComponentName a;
    
    final IBinder b;
    
    b(ComponentName param1ComponentName, IBinder param1IBinder) {
      this.a = param1ComponentName;
      this.b = param1IBinder;
    }
  }
  
  private static class c implements Handler.Callback, ServiceConnection {
    private final Context a;
    
    private final HandlerThread b;
    
    private final Handler c;
    
    private final Map<ComponentName, a> d = new HashMap<ComponentName, a>();
    
    private Set<String> e = new HashSet<String>();
    
    c(Context param1Context) {
      this.a = param1Context;
      HandlerThread handlerThread = new HandlerThread("NotificationManagerCompat");
      this.b = handlerThread;
      handlerThread.start();
      this.c = new Handler(handlerThread.getLooper(), this);
    }
    
    private boolean a(a param1a) {
      if (param1a.b)
        return true; 
      Intent intent = (new Intent("android.support.BIND_NOTIFICATION_SIDE_CHANNEL")).setComponent(param1a.a);
      boolean bool = this.a.bindService(intent, this, 33);
      param1a.b = bool;
      if (bool) {
        param1a.e = 0;
      } else {
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("Unable to bind to listener ");
        stringBuilder.append(param1a.a);
        Log.w("NotifManCompat", stringBuilder.toString());
        this.a.unbindService(this);
      } 
      return param1a.b;
    }
    
    private void b(a param1a) {
      if (param1a.b) {
        this.a.unbindService(this);
        param1a.b = false;
      } 
      param1a.c = null;
    }
    
    private void c(w0.d param1d) {
      j();
      for (a a : this.d.values()) {
        a.d.add(param1d);
        g(a);
      } 
    }
    
    private void d(ComponentName param1ComponentName) {
      a a = this.d.get(param1ComponentName);
      if (a != null)
        g(a); 
    }
    
    private void e(ComponentName param1ComponentName, IBinder param1IBinder) {
      a a = this.d.get(param1ComponentName);
      if (a != null) {
        a.c = b.a.a.Y0(param1IBinder);
        a.e = 0;
        g(a);
      } 
    }
    
    private void f(ComponentName param1ComponentName) {
      a a = this.d.get(param1ComponentName);
      if (a != null)
        b(a); 
    }
    
    private void g(a param1a) {
      if (Log.isLoggable("NotifManCompat", 3)) {
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("Processing component ");
        stringBuilder.append(param1a.a);
        stringBuilder.append(", ");
        stringBuilder.append(param1a.d.size());
        stringBuilder.append(" queued tasks");
        Log.d("NotifManCompat", stringBuilder.toString());
      } 
      if (param1a.d.isEmpty())
        return; 
      if (!a(param1a) || param1a.c == null) {
        i(param1a);
        return;
      } 
      while (true) {
        w0.d d = param1a.d.peek();
        if (d != null)
          try {
            if (Log.isLoggable("NotifManCompat", 3)) {
              StringBuilder stringBuilder = new StringBuilder();
              stringBuilder.append("Sending task ");
              stringBuilder.append(d);
              Log.d("NotifManCompat", stringBuilder.toString());
            } 
            d.a(param1a.c);
            param1a.d.remove();
            continue;
          } catch (DeadObjectException deadObjectException) {
            if (Log.isLoggable("NotifManCompat", 3)) {
              StringBuilder stringBuilder = new StringBuilder();
              stringBuilder.append("Remote service has died: ");
              stringBuilder.append(param1a.a);
              Log.d("NotifManCompat", stringBuilder.toString());
            } 
          } catch (RemoteException remoteException) {
            StringBuilder stringBuilder = new StringBuilder();
            stringBuilder.append("RemoteException communicating with ");
            stringBuilder.append(param1a.a);
            Log.w("NotifManCompat", stringBuilder.toString(), (Throwable)remoteException);
          }  
        if (!param1a.d.isEmpty())
          i(param1a); 
        return;
      } 
    }
    
    private void i(a param1a) {
      if (this.c.hasMessages(3, param1a.a))
        return; 
      int i = param1a.e + 1;
      param1a.e = i;
      if (i > 6) {
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("Giving up on delivering ");
        stringBuilder.append(param1a.d.size());
        stringBuilder.append(" tasks to ");
        stringBuilder.append(param1a.a);
        stringBuilder.append(" after ");
        stringBuilder.append(param1a.e);
        stringBuilder.append(" retries");
        Log.w("NotifManCompat", stringBuilder.toString());
        param1a.d.clear();
        return;
      } 
      i = (1 << i - 1) * 1000;
      if (Log.isLoggable("NotifManCompat", 3)) {
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("Scheduling retry for ");
        stringBuilder.append(i);
        stringBuilder.append(" ms");
        Log.d("NotifManCompat", stringBuilder.toString());
      } 
      Message message = this.c.obtainMessage(3, param1a.a);
      this.c.sendMessageDelayed(message, i);
    }
    
    private void j() {
      Set<String> set = w0.c(this.a);
      if (set.equals(this.e))
        return; 
      this.e = set;
      List list = this.a.getPackageManager().queryIntentServices((new Intent()).setAction("android.support.BIND_NOTIFICATION_SIDE_CHANNEL"), 0);
      HashSet<ComponentName> hashSet = new HashSet();
      for (ResolveInfo resolveInfo : list) {
        if (!set.contains(resolveInfo.serviceInfo.packageName))
          continue; 
        ServiceInfo serviceInfo = resolveInfo.serviceInfo;
        ComponentName componentName = new ComponentName(serviceInfo.packageName, serviceInfo.name);
        if (resolveInfo.serviceInfo.permission != null) {
          StringBuilder stringBuilder = new StringBuilder();
          stringBuilder.append("Permission present on component ");
          stringBuilder.append(componentName);
          stringBuilder.append(", not adding listener record.");
          Log.w("NotifManCompat", stringBuilder.toString());
          continue;
        } 
        hashSet.add(componentName);
      } 
      for (ComponentName componentName : hashSet) {
        if (!this.d.containsKey(componentName)) {
          if (Log.isLoggable("NotifManCompat", 3)) {
            StringBuilder stringBuilder = new StringBuilder();
            stringBuilder.append("Adding listener record for ");
            stringBuilder.append(componentName);
            Log.d("NotifManCompat", stringBuilder.toString());
          } 
          this.d.put(componentName, new a(componentName));
        } 
      } 
      Iterator<Map.Entry> iterator = this.d.entrySet().iterator();
      while (iterator.hasNext()) {
        Map.Entry entry = iterator.next();
        if (!hashSet.contains(entry.getKey())) {
          if (Log.isLoggable("NotifManCompat", 3)) {
            StringBuilder stringBuilder = new StringBuilder();
            stringBuilder.append("Removing listener record for ");
            stringBuilder.append(entry.getKey());
            Log.d("NotifManCompat", stringBuilder.toString());
          } 
          b((a)entry.getValue());
          iterator.remove();
        } 
      } 
    }
    
    public void h(w0.d param1d) {
      this.c.obtainMessage(0, param1d).sendToTarget();
    }
    
    public boolean handleMessage(Message param1Message) {
      w0.b b;
      int i = param1Message.what;
      if (i != 0) {
        if (i != 1) {
          if (i != 2) {
            if (i != 3)
              return false; 
            d((ComponentName)param1Message.obj);
            return true;
          } 
          f((ComponentName)param1Message.obj);
          return true;
        } 
        b = (w0.b)param1Message.obj;
        e(b.a, b.b);
        return true;
      } 
      c((w0.d)((Message)b).obj);
      return true;
    }
    
    public void onServiceConnected(ComponentName param1ComponentName, IBinder param1IBinder) {
      if (Log.isLoggable("NotifManCompat", 3)) {
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("Connected to service ");
        stringBuilder.append(param1ComponentName);
        Log.d("NotifManCompat", stringBuilder.toString());
      } 
      this.c.obtainMessage(1, new w0.b(param1ComponentName, param1IBinder)).sendToTarget();
    }
    
    public void onServiceDisconnected(ComponentName param1ComponentName) {
      if (Log.isLoggable("NotifManCompat", 3)) {
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("Disconnected from service ");
        stringBuilder.append(param1ComponentName);
        Log.d("NotifManCompat", stringBuilder.toString());
      } 
      this.c.obtainMessage(2, param1ComponentName).sendToTarget();
    }
    
    private static class a {
      final ComponentName a;
      
      boolean b = false;
      
      b.a c;
      
      ArrayDeque<w0.d> d = new ArrayDeque<w0.d>();
      
      int e = 0;
      
      a(ComponentName param2ComponentName) {
        this.a = param2ComponentName;
      }
    }
  }
  
  private static class a {
    final ComponentName a;
    
    boolean b = false;
    
    b.a c;
    
    ArrayDeque<w0.d> d = new ArrayDeque<w0.d>();
    
    int e = 0;
    
    a(ComponentName param1ComponentName) {
      this.a = param1ComponentName;
    }
  }
  
  private static interface d {
    void a(b.a param1a) throws RemoteException;
  }
}


/* Location:              C:\soft\dex2jar-2.0\Cricket Scorer-dex2jar.jar!\androidx\core\app\w0.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */