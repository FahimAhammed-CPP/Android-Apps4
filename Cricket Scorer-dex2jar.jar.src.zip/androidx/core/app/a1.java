package androidx.core.app;

import android.content.res.Configuration;

public final class a1 {
  private final boolean a;
  
  private final Configuration b;
  
  public a1(boolean paramBoolean) {
    this.a = paramBoolean;
    this.b = null;
  }
  
  public a1(boolean paramBoolean, Configuration paramConfiguration) {
    this.a = paramBoolean;
    this.b = paramConfiguration;
  }
  
  public boolean a() {
    return this.a;
  }
}


/* Location:              C:\soft\dex2jar-2.0\Cricket Scorer-dex2jar.jar!\androidx\core\app\a1.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */