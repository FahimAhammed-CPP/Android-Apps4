package androidx.core.app;

import android.app.Activity;
import android.app.PendingIntent;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.os.Bundle;
import android.util.Log;
import java.util.ArrayList;
import java.util.Iterator;

public final class d1 implements Iterable<Intent> {
  private final ArrayList<Intent> a = new ArrayList<Intent>();
  
  private final Context b;
  
  private d1(Context paramContext) {
    this.b = paramContext;
  }
  
  public static d1 f(Context paramContext) {
    return new d1(paramContext);
  }
  
  public d1 a(Intent paramIntent) {
    this.a.add(paramIntent);
    return this;
  }
  
  public d1 b(Intent paramIntent) {
    ComponentName componentName2 = paramIntent.getComponent();
    ComponentName componentName1 = componentName2;
    if (componentName2 == null)
      componentName1 = paramIntent.resolveActivity(this.b.getPackageManager()); 
    if (componentName1 != null)
      d(componentName1); 
    a(paramIntent);
    return this;
  }
  
  public d1 c(Activity paramActivity) {
    Intent intent1;
    if (paramActivity instanceof b) {
      intent1 = ((b)paramActivity).getSupportParentActivityIntent();
    } else {
      intent1 = null;
    } 
    Intent intent2 = intent1;
    if (intent1 == null)
      intent2 = t.a(paramActivity); 
    if (intent2 != null) {
      ComponentName componentName2 = intent2.getComponent();
      ComponentName componentName1 = componentName2;
      if (componentName2 == null)
        componentName1 = intent2.resolveActivity(this.b.getPackageManager()); 
      d(componentName1);
      a(intent2);
    } 
    return this;
  }
  
  public d1 d(ComponentName paramComponentName) {
    int i = this.a.size();
    try {
      for (Intent intent = t.b(this.b, paramComponentName); intent != null; intent = t.b(this.b, intent.getComponent()))
        this.a.add(i, intent); 
      return this;
    } catch (android.content.pm.PackageManager.NameNotFoundException nameNotFoundException) {
      Log.e("TaskStackBuilder", "Bad ComponentName while traversing activity parent metadata");
      throw new IllegalArgumentException(nameNotFoundException);
    } 
  }
  
  public Intent g(int paramInt) {
    return this.a.get(paramInt);
  }
  
  public int h() {
    return this.a.size();
  }
  
  public PendingIntent i(int paramInt1, int paramInt2) {
    return j(paramInt1, paramInt2, null);
  }
  
  @Deprecated
  public Iterator<Intent> iterator() {
    return this.a.iterator();
  }
  
  public PendingIntent j(int paramInt1, int paramInt2, Bundle paramBundle) {
    if (!this.a.isEmpty()) {
      Intent[] arrayOfIntent = this.a.<Intent>toArray(new Intent[0]);
      arrayOfIntent[0] = (new Intent(arrayOfIntent[0])).addFlags(268484608);
      return a.a(this.b, paramInt1, arrayOfIntent, paramInt2, paramBundle);
    } 
    throw new IllegalStateException("No intents added to TaskStackBuilder; cannot getPendingIntent");
  }
  
  public void k() {
    l(null);
  }
  
  public void l(Bundle paramBundle) {
    if (!this.a.isEmpty()) {
      Intent[] arrayOfIntent = this.a.<Intent>toArray(new Intent[0]);
      arrayOfIntent[0] = (new Intent(arrayOfIntent[0])).addFlags(268484608);
      if (!androidx.core.content.a.startActivities(this.b, arrayOfIntent, paramBundle)) {
        Intent intent = new Intent(arrayOfIntent[arrayOfIntent.length - 1]);
        intent.addFlags(268435456);
        this.b.startActivity(intent);
      } 
      return;
    } 
    throw new IllegalStateException("No intents added to TaskStackBuilder; cannot startActivities");
  }
  
  static class a {
    static PendingIntent a(Context param1Context, int param1Int1, Intent[] param1ArrayOfIntent, int param1Int2, Bundle param1Bundle) {
      return PendingIntent.getActivities(param1Context, param1Int1, param1ArrayOfIntent, param1Int2, param1Bundle);
    }
  }
  
  public static interface b {
    Intent getSupportParentActivityIntent();
  }
}


/* Location:              C:\soft\dex2jar-2.0\Cricket Scorer-dex2jar.jar!\androidx\core\app\d1.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */