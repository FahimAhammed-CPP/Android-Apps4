package androidx.core.app;

import androidx.core.util.a;

public interface y0 {
  void addOnPictureInPictureModeChangedListener(a<a1> parama);
  
  void removeOnPictureInPictureModeChangedListener(a<a1> parama);
}


/* Location:              C:\soft\dex2jar-2.0\Cricket Scorer-dex2jar.jar!\androidx\core\app\y0.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */