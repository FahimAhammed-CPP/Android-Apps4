package androidx.core.app;

import androidx.core.util.a;

public interface x0 {
  void addOnMultiWindowModeChangedListener(a<s> parama);
  
  void removeOnMultiWindowModeChangedListener(a<s> parama);
}


/* Location:              C:\soft\dex2jar-2.0\Cricket Scorer-dex2jar.jar!\androidx\core\app\x0.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */