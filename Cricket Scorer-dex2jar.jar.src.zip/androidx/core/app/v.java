package androidx.core.app;

import android.app.Notification;
import android.app.PendingIntent;
import android.content.Context;
import android.content.res.Resources;
import android.graphics.Bitmap;
import android.graphics.drawable.Icon;
import android.media.AudioAttributes;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.widget.RemoteViews;
import androidx.core.graphics.drawable.IconCompat;
import java.util.ArrayList;

public class v {
  public static Bundle a(Notification paramNotification) {
    return paramNotification.extras;
  }
  
  public static class a {
    final Bundle a;
    
    private IconCompat b;
    
    private final b1[] c;
    
    private final b1[] d;
    
    private boolean e;
    
    boolean f = true;
    
    private final int g;
    
    private final boolean h;
    
    @Deprecated
    public int i;
    
    public CharSequence j;
    
    public PendingIntent k;
    
    private boolean l;
    
    public a(int param1Int, CharSequence param1CharSequence, PendingIntent param1PendingIntent) {
      this(iconCompat, param1CharSequence, param1PendingIntent);
    }
    
    public a(IconCompat param1IconCompat, CharSequence param1CharSequence, PendingIntent param1PendingIntent) {
      this(param1IconCompat, param1CharSequence, param1PendingIntent, new Bundle(), null, null, true, 0, true, false, false);
    }
    
    a(IconCompat param1IconCompat, CharSequence param1CharSequence, PendingIntent param1PendingIntent, Bundle param1Bundle, b1[] param1ArrayOfb11, b1[] param1ArrayOfb12, boolean param1Boolean1, int param1Int, boolean param1Boolean2, boolean param1Boolean3, boolean param1Boolean4) {
      this.b = param1IconCompat;
      if (param1IconCompat != null && param1IconCompat.l() == 2)
        this.i = param1IconCompat.j(); 
      this.j = v.e.e(param1CharSequence);
      this.k = param1PendingIntent;
      if (param1Bundle == null)
        param1Bundle = new Bundle(); 
      this.a = param1Bundle;
      this.c = param1ArrayOfb11;
      this.d = param1ArrayOfb12;
      this.e = param1Boolean1;
      this.g = param1Int;
      this.f = param1Boolean2;
      this.h = param1Boolean3;
      this.l = param1Boolean4;
    }
    
    public PendingIntent a() {
      return this.k;
    }
    
    public boolean b() {
      return this.e;
    }
    
    public Bundle c() {
      return this.a;
    }
    
    public IconCompat d() {
      if (this.b == null) {
        int i = this.i;
        if (i != 0)
          this.b = IconCompat.h(null, "", i); 
      } 
      return this.b;
    }
    
    public b1[] e() {
      return this.c;
    }
    
    public int f() {
      return this.g;
    }
    
    public boolean g() {
      return this.f;
    }
    
    public CharSequence h() {
      return this.j;
    }
    
    public boolean i() {
      return this.l;
    }
    
    public boolean j() {
      return this.h;
    }
  }
  
  public static class b extends f {
    private IconCompat e;
    
    private IconCompat f;
    
    private boolean g;
    
    private CharSequence h;
    
    private boolean i;
    
    public void b(u param1u) {
      int i = Build.VERSION.SDK_INT;
      Notification.BigPictureStyle bigPictureStyle2 = (new Notification.BigPictureStyle(param1u.a())).setBigContentTitle(this.b);
      IconCompat iconCompat = this.e;
      Context context = null;
      Notification.BigPictureStyle bigPictureStyle1 = bigPictureStyle2;
      if (iconCompat != null)
        if (i >= 31) {
          if (param1u instanceof t0) {
            Context context1 = ((t0)param1u).f();
          } else {
            bigPictureStyle1 = null;
          } 
          c.a(bigPictureStyle2, this.e.r((Context)bigPictureStyle1));
          bigPictureStyle1 = bigPictureStyle2;
        } else {
          bigPictureStyle1 = bigPictureStyle2;
          if (iconCompat.l() == 1)
            bigPictureStyle1 = bigPictureStyle2.bigPicture(this.e.i()); 
        }  
      if (this.g) {
        IconCompat iconCompat1 = this.f;
        if (iconCompat1 == null) {
          a.a(bigPictureStyle1, null);
        } else if (i >= 23) {
          if (param1u instanceof t0)
            context = ((t0)param1u).f(); 
          b.a(bigPictureStyle1, this.f.r(context));
        } else if (iconCompat1.l() == 1) {
          a.a(bigPictureStyle1, this.f.i());
        } else {
          a.a(bigPictureStyle1, null);
        } 
      } 
      if (this.d)
        a.b(bigPictureStyle1, this.c); 
      if (i >= 31) {
        c.c(bigPictureStyle1, this.i);
        c.b(bigPictureStyle1, this.h);
      } 
    }
    
    protected String c() {
      return "androidx.core.app.NotificationCompat$BigPictureStyle";
    }
    
    public b h(Bitmap param1Bitmap) {
      IconCompat iconCompat;
      if (param1Bitmap == null) {
        param1Bitmap = null;
      } else {
        iconCompat = IconCompat.e(param1Bitmap);
      } 
      this.f = iconCompat;
      this.g = true;
      return this;
    }
    
    public b i(Bitmap param1Bitmap) {
      IconCompat iconCompat;
      if (param1Bitmap == null) {
        param1Bitmap = null;
      } else {
        iconCompat = IconCompat.e(param1Bitmap);
      } 
      this.e = iconCompat;
      return this;
    }
    
    private static class a {
      static void a(Notification.BigPictureStyle param2BigPictureStyle, Bitmap param2Bitmap) {
        param2BigPictureStyle.bigLargeIcon(param2Bitmap);
      }
      
      static void b(Notification.BigPictureStyle param2BigPictureStyle, CharSequence param2CharSequence) {
        param2BigPictureStyle.setSummaryText(param2CharSequence);
      }
    }
    
    private static class b {
      static void a(Notification.BigPictureStyle param2BigPictureStyle, Icon param2Icon) {
        w.a(param2BigPictureStyle, param2Icon);
      }
    }
    
    private static class c {
      static void a(Notification.BigPictureStyle param2BigPictureStyle, Icon param2Icon) {
        y.a(param2BigPictureStyle, param2Icon);
      }
      
      static void b(Notification.BigPictureStyle param2BigPictureStyle, CharSequence param2CharSequence) {
        z.a(param2BigPictureStyle, param2CharSequence);
      }
      
      static void c(Notification.BigPictureStyle param2BigPictureStyle, boolean param2Boolean) {
        x.a(param2BigPictureStyle, param2Boolean);
      }
    }
  }
  
  private static class a {
    static void a(Notification.BigPictureStyle param1BigPictureStyle, Bitmap param1Bitmap) {
      param1BigPictureStyle.bigLargeIcon(param1Bitmap);
    }
    
    static void b(Notification.BigPictureStyle param1BigPictureStyle, CharSequence param1CharSequence) {
      param1BigPictureStyle.setSummaryText(param1CharSequence);
    }
  }
  
  private static class b {
    static void a(Notification.BigPictureStyle param1BigPictureStyle, Icon param1Icon) {
      w.a(param1BigPictureStyle, param1Icon);
    }
  }
  
  private static class c {
    static void a(Notification.BigPictureStyle param1BigPictureStyle, Icon param1Icon) {
      y.a(param1BigPictureStyle, param1Icon);
    }
    
    static void b(Notification.BigPictureStyle param1BigPictureStyle, CharSequence param1CharSequence) {
      z.a(param1BigPictureStyle, param1CharSequence);
    }
    
    static void c(Notification.BigPictureStyle param1BigPictureStyle, boolean param1Boolean) {
      x.a(param1BigPictureStyle, param1Boolean);
    }
  }
  
  public static class c extends f {
    private CharSequence e;
    
    public void a(Bundle param1Bundle) {
      super.a(param1Bundle);
    }
    
    public void b(u param1u) {
      Notification.BigTextStyle bigTextStyle = (new Notification.BigTextStyle(param1u.a())).setBigContentTitle(this.b).bigText(this.e);
      if (this.d)
        bigTextStyle.setSummaryText(this.c); 
    }
    
    protected String c() {
      return "androidx.core.app.NotificationCompat$BigTextStyle";
    }
    
    public c h(CharSequence param1CharSequence) {
      this.e = v.e.e(param1CharSequence);
      return this;
    }
  }
  
  public static final class d {
    public static Notification.BubbleMetadata a(d param1d) {
      return null;
    }
  }
  
  public static class e {
    boolean A;
    
    boolean B;
    
    String C;
    
    Bundle D;
    
    int E = 0;
    
    int F = 0;
    
    Notification G;
    
    RemoteViews H;
    
    RemoteViews I;
    
    RemoteViews J;
    
    String K;
    
    int L = 0;
    
    String M;
    
    long N;
    
    int O = 0;
    
    int P = 0;
    
    boolean Q;
    
    Notification R;
    
    boolean S;
    
    Icon T;
    
    @Deprecated
    public ArrayList<String> U;
    
    public Context a;
    
    public ArrayList<v.a> b = new ArrayList<v.a>();
    
    public ArrayList<z0> c = new ArrayList<z0>();
    
    ArrayList<v.a> d = new ArrayList<v.a>();
    
    CharSequence e;
    
    CharSequence f;
    
    PendingIntent g;
    
    PendingIntent h;
    
    RemoteViews i;
    
    Bitmap j;
    
    CharSequence k;
    
    int l;
    
    int m;
    
    boolean n = true;
    
    boolean o;
    
    v.f p;
    
    CharSequence q;
    
    CharSequence r;
    
    CharSequence[] s;
    
    int t;
    
    int u;
    
    boolean v;
    
    String w;
    
    boolean x;
    
    String y;
    
    boolean z = false;
    
    @Deprecated
    public e(Context param1Context) {
      this(param1Context, null);
    }
    
    public e(Context param1Context, String param1String) {
      Notification notification = new Notification();
      this.R = notification;
      this.a = param1Context;
      this.K = param1String;
      notification.when = System.currentTimeMillis();
      this.R.audioStreamType = -1;
      this.m = 0;
      this.U = new ArrayList<String>();
      this.Q = true;
    }
    
    protected static CharSequence e(CharSequence param1CharSequence) {
      if (param1CharSequence == null)
        return param1CharSequence; 
      CharSequence charSequence = param1CharSequence;
      if (param1CharSequence.length() > 5120)
        charSequence = param1CharSequence.subSequence(0, 5120); 
      return charSequence;
    }
    
    private Bitmap f(Bitmap param1Bitmap) {
      Bitmap bitmap = param1Bitmap;
      if (param1Bitmap != null) {
        if (Build.VERSION.SDK_INT >= 27)
          return param1Bitmap; 
        Resources resources = this.a.getResources();
        int i = resources.getDimensionPixelSize(t.b.b);
        int j = resources.getDimensionPixelSize(t.b.a);
        if (param1Bitmap.getWidth() <= i && param1Bitmap.getHeight() <= j)
          return param1Bitmap; 
        double d = Math.min(i / Math.max(1, param1Bitmap.getWidth()), j / Math.max(1, param1Bitmap.getHeight()));
        bitmap = Bitmap.createScaledBitmap(param1Bitmap, (int)Math.ceil(param1Bitmap.getWidth() * d), (int)Math.ceil(param1Bitmap.getHeight() * d), true);
      } 
      return bitmap;
    }
    
    private void o(int param1Int, boolean param1Boolean) {
      if (param1Boolean) {
        Notification notification1 = this.R;
        notification1.flags = param1Int | notification1.flags;
        return;
      } 
      Notification notification = this.R;
      notification.flags = param1Int & notification.flags;
    }
    
    public e A(CharSequence param1CharSequence) {
      this.R.tickerText = e(param1CharSequence);
      return this;
    }
    
    public e B(long[] param1ArrayOflong) {
      this.R.vibrate = param1ArrayOflong;
      return this;
    }
    
    public e C(int param1Int) {
      this.F = param1Int;
      return this;
    }
    
    public e D(long param1Long) {
      this.R.when = param1Long;
      return this;
    }
    
    public e a(int param1Int, CharSequence param1CharSequence, PendingIntent param1PendingIntent) {
      this.b.add(new v.a(param1Int, param1CharSequence, param1PendingIntent));
      return this;
    }
    
    public e b(v.a param1a) {
      if (param1a != null)
        this.b.add(param1a); 
      return this;
    }
    
    public Notification c() {
      return (new t0(this)).c();
    }
    
    public Bundle d() {
      if (this.D == null)
        this.D = new Bundle(); 
      return this.D;
    }
    
    public e g(boolean param1Boolean) {
      o(16, param1Boolean);
      return this;
    }
    
    public e h(String param1String) {
      this.K = param1String;
      return this;
    }
    
    public e i(int param1Int) {
      this.E = param1Int;
      return this;
    }
    
    public e j(PendingIntent param1PendingIntent) {
      this.g = param1PendingIntent;
      return this;
    }
    
    public e k(CharSequence param1CharSequence) {
      this.f = e(param1CharSequence);
      return this;
    }
    
    public e l(CharSequence param1CharSequence) {
      this.e = e(param1CharSequence);
      return this;
    }
    
    public e m(int param1Int) {
      Notification notification = this.R;
      notification.defaults = param1Int;
      if ((param1Int & 0x4) != 0)
        notification.flags |= 0x1; 
      return this;
    }
    
    public e n(PendingIntent param1PendingIntent) {
      this.R.deleteIntent = param1PendingIntent;
      return this;
    }
    
    public e p(Bitmap param1Bitmap) {
      this.j = f(param1Bitmap);
      return this;
    }
    
    public e q(int param1Int1, int param1Int2, int param1Int3) {
      Notification notification = this.R;
      notification.ledARGB = param1Int1;
      notification.ledOnMS = param1Int2;
      notification.ledOffMS = param1Int3;
      if (param1Int2 != 0 && param1Int3 != 0) {
        param1Int1 = 1;
      } else {
        param1Int1 = 0;
      } 
      notification.flags = param1Int1 | notification.flags & 0xFFFFFFFE;
      return this;
    }
    
    public e r(boolean param1Boolean) {
      this.z = param1Boolean;
      return this;
    }
    
    public e s(int param1Int) {
      this.l = param1Int;
      return this;
    }
    
    public e t(boolean param1Boolean) {
      o(2, param1Boolean);
      return this;
    }
    
    public e u(int param1Int) {
      this.m = param1Int;
      return this;
    }
    
    public e v(int param1Int1, int param1Int2, boolean param1Boolean) {
      this.t = param1Int1;
      this.u = param1Int2;
      this.v = param1Boolean;
      return this;
    }
    
    public e w(boolean param1Boolean) {
      this.n = param1Boolean;
      return this;
    }
    
    public e x(int param1Int) {
      this.R.icon = param1Int;
      return this;
    }
    
    public e y(Uri param1Uri) {
      Notification notification = this.R;
      notification.sound = param1Uri;
      notification.audioStreamType = -1;
      notification.audioAttributes = (new AudioAttributes.Builder()).setContentType(4).setUsage(5).build();
      return this;
    }
    
    public e z(v.f param1f) {
      if (this.p != param1f) {
        this.p = param1f;
        if (param1f != null)
          param1f.g(this); 
      } 
      return this;
    }
  }
  
  public static abstract class f {
    protected v.e a;
    
    CharSequence b;
    
    CharSequence c;
    
    boolean d = false;
    
    public void a(Bundle param1Bundle) {
      if (this.d)
        param1Bundle.putCharSequence("android.summaryText", this.c); 
      CharSequence charSequence = this.b;
      if (charSequence != null)
        param1Bundle.putCharSequence("android.title.big", charSequence); 
      charSequence = c();
      if (charSequence != null)
        param1Bundle.putString("androidx.core.app.extra.COMPAT_TEMPLATE", (String)charSequence); 
    }
    
    public void b(u param1u) {}
    
    protected String c() {
      return null;
    }
    
    public RemoteViews d(u param1u) {
      return null;
    }
    
    public RemoteViews e(u param1u) {
      return null;
    }
    
    public RemoteViews f(u param1u) {
      return null;
    }
    
    public void g(v.e param1e) {
      if (this.a != param1e) {
        this.a = param1e;
        if (param1e != null)
          param1e.z(this); 
      } 
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Cricket Scorer-dex2jar.jar!\androidx\core\app\v.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */