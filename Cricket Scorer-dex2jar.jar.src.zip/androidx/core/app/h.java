package androidx.core.app;

import android.app.Activity;
import android.app.Application;
import android.content.res.Configuration;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.IBinder;
import android.os.Looper;
import android.util.Log;
import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.util.List;

final class h {
  protected static final Class<?> a;
  
  protected static final Field b;
  
  protected static final Field c;
  
  protected static final Method d;
  
  protected static final Method e;
  
  protected static final Method f;
  
  private static final Handler g = new Handler(Looper.getMainLooper());
  
  static {
    Class<?> clazz = a();
    a = clazz;
    b = b();
    c = f();
    d = d(clazz);
    e = c(clazz);
    f = e(clazz);
  }
  
  private static Class<?> a() {
    try {
      return Class.forName("android.app.ActivityThread");
    } finally {
      Exception exception = null;
    } 
  }
  
  private static Field b() {
    try {
      Field field = Activity.class.getDeclaredField("mMainThread");
      return field;
    } finally {
      Exception exception = null;
    } 
  }
  
  private static Method c(Class<?> paramClass) {
    if (paramClass == null)
      return null; 
    try {
      Method method = paramClass.getDeclaredMethod("performStopActivity", new Class[] { IBinder.class, boolean.class });
      return method;
    } finally {
      paramClass = null;
    } 
  }
  
  private static Method d(Class<?> paramClass) {
    if (paramClass == null)
      return null; 
    try {
      Method method = paramClass.getDeclaredMethod("performStopActivity", new Class[] { IBinder.class, boolean.class, String.class });
      return method;
    } finally {
      paramClass = null;
    } 
  }
  
  private static Method e(Class<?> paramClass) {
    if (g()) {
      if (paramClass == null)
        return null; 
      try {
        Class<int> clazz = int.class;
        Class<boolean> clazz1 = boolean.class;
        Method method = paramClass.getDeclaredMethod("requestRelaunchActivity", new Class[] { IBinder.class, List.class, List.class, clazz, clazz1, Configuration.class, Configuration.class, clazz1, clazz1 });
        return method;
      } finally {
        paramClass = null;
      } 
    } 
    return null;
  }
  
  private static Field f() {
    try {
      Field field = Activity.class.getDeclaredField("mToken");
      return field;
    } finally {
      Exception exception = null;
    } 
  }
  
  private static boolean g() {
    int i = Build.VERSION.SDK_INT;
    return (i == 26 || i == 27);
  }
  
  protected static boolean h(Object paramObject, int paramInt, Activity paramActivity) {
    try {
      return false;
    } finally {
      paramObject = null;
      Log.e("ActivityRecreator", "Exception while fetching field values", (Throwable)paramObject);
    } 
  }
  
  static boolean i(Activity paramActivity) {
    if (Build.VERSION.SDK_INT >= 28) {
      paramActivity.recreate();
      return true;
    } 
    if (g() && f == null)
      return false; 
    if (e == null && d == null)
      return false; 
    try {
      Object object1 = c.get(paramActivity);
      if (object1 == null)
        return false; 
      Object object2 = b.get(paramActivity);
      if (object2 == null)
        return false; 
      Application application = paramActivity.getApplication();
      d d = new d(paramActivity);
      application.registerActivityLifecycleCallbacks(d);
      Handler handler = g;
      handler.post(new a(d, object1));
    } finally {
      paramActivity = null;
    } 
  }
  
  class a implements Runnable {
    a(h this$0, Object param1Object) {}
    
    public void run() {
      this.a.a = this.b;
    }
  }
  
  class b implements Runnable {
    b(h this$0, h.d param1d) {}
    
    public void run() {
      this.a.unregisterActivityLifecycleCallbacks(this.b);
    }
  }
  
  class c implements Runnable {
    c(h this$0, Object param1Object1) {}
    
    public void run() {
      try {
        Method method = h.d;
        return;
      } catch (RuntimeException runtimeException) {
        return;
      } finally {
        Exception exception = null;
        Log.e("ActivityRecreator", "Exception while invoking performStopActivity", exception);
      } 
    }
  }
  
  private static final class d implements Application.ActivityLifecycleCallbacks {
    Object a;
    
    private Activity b;
    
    private final int c;
    
    private boolean d = false;
    
    private boolean e = false;
    
    private boolean f = false;
    
    d(Activity param1Activity) {
      this.b = param1Activity;
      this.c = param1Activity.hashCode();
    }
    
    public void onActivityCreated(Activity param1Activity, Bundle param1Bundle) {}
    
    public void onActivityDestroyed(Activity param1Activity) {
      if (this.b == param1Activity) {
        this.b = null;
        this.e = true;
      } 
    }
    
    public void onActivityPaused(Activity param1Activity) {
      if (this.e && !this.f && !this.d && h.h(this.a, this.c, param1Activity)) {
        this.f = true;
        this.a = null;
      } 
    }
    
    public void onActivityResumed(Activity param1Activity) {}
    
    public void onActivitySaveInstanceState(Activity param1Activity, Bundle param1Bundle) {}
    
    public void onActivityStarted(Activity param1Activity) {
      if (this.b == param1Activity)
        this.d = true; 
    }
    
    public void onActivityStopped(Activity param1Activity) {}
  }
}


/* Location:              C:\soft\dex2jar-2.0\Cricket Scorer-dex2jar.jar!\androidx\core\app\h.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */