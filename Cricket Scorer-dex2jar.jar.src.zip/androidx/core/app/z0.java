package androidx.core.app;

import android.app.Person;
import android.graphics.drawable.Icon;
import androidx.core.graphics.drawable.IconCompat;

public class z0 {
  CharSequence a;
  
  IconCompat b;
  
  String c;
  
  String d;
  
  boolean e;
  
  boolean f;
  
  z0(b paramb) {
    this.a = paramb.a;
    this.b = paramb.b;
    this.c = paramb.c;
    this.d = paramb.d;
    this.e = paramb.e;
    this.f = paramb.f;
  }
  
  public IconCompat a() {
    return this.b;
  }
  
  public String b() {
    return this.d;
  }
  
  public CharSequence c() {
    return this.a;
  }
  
  public String d() {
    return this.c;
  }
  
  public boolean e() {
    return this.e;
  }
  
  public boolean f() {
    return this.f;
  }
  
  public String g() {
    String str = this.c;
    if (str != null)
      return str; 
    if (this.a != null) {
      StringBuilder stringBuilder = new StringBuilder();
      stringBuilder.append("name:");
      stringBuilder.append(this.a);
      return stringBuilder.toString();
    } 
    return "";
  }
  
  public Person h() {
    return a.b(this);
  }
  
  static class a {
    static z0 a(Person param1Person) {
      IconCompat iconCompat;
      z0.b b = (new z0.b()).f(param1Person.getName());
      if (param1Person.getIcon() != null) {
        iconCompat = IconCompat.a(param1Person.getIcon());
      } else {
        iconCompat = null;
      } 
      return b.c(iconCompat).g(param1Person.getUri()).e(param1Person.getKey()).b(param1Person.isBot()).d(param1Person.isImportant()).a();
    }
    
    static Person b(z0 param1z0) {
      Icon icon;
      Person.Builder builder = (new Person.Builder()).setName(param1z0.c());
      if (param1z0.a() != null) {
        icon = param1z0.a().q();
      } else {
        icon = null;
      } 
      return builder.setIcon(icon).setUri(param1z0.d()).setKey(param1z0.b()).setBot(param1z0.e()).setImportant(param1z0.f()).build();
    }
  }
  
  public static class b {
    CharSequence a;
    
    IconCompat b;
    
    String c;
    
    String d;
    
    boolean e;
    
    boolean f;
    
    public z0 a() {
      return new z0(this);
    }
    
    public b b(boolean param1Boolean) {
      this.e = param1Boolean;
      return this;
    }
    
    public b c(IconCompat param1IconCompat) {
      this.b = param1IconCompat;
      return this;
    }
    
    public b d(boolean param1Boolean) {
      this.f = param1Boolean;
      return this;
    }
    
    public b e(String param1String) {
      this.d = param1String;
      return this;
    }
    
    public b f(CharSequence param1CharSequence) {
      this.a = param1CharSequence;
      return this;
    }
    
    public b g(String param1String) {
      this.c = param1String;
      return this;
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Cricket Scorer-dex2jar.jar!\androidx\core\app\z0.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */