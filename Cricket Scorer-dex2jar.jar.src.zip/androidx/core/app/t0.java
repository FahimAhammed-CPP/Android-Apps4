package androidx.core.app;

import android.app.Notification;
import android.app.PendingIntent;
import android.app.RemoteInput;
import android.content.Context;
import android.graphics.drawable.Icon;
import android.os.Build;
import android.os.Bundle;
import android.text.TextUtils;
import android.widget.RemoteViews;
import androidx.collection.b;
import androidx.core.graphics.drawable.IconCompat;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Iterator;
import java.util.List;

class t0 implements u {
  private final Context a;
  
  private final Notification.Builder b;
  
  private final v.e c;
  
  private RemoteViews d;
  
  private RemoteViews e;
  
  private final List<Bundle> f;
  
  private final Bundle g;
  
  private int h;
  
  private RemoteViews i;
  
  t0(v.e parame) {
    boolean bool;
    List<String> list;
    this.f = new ArrayList<Bundle>();
    this.g = new Bundle();
    this.c = parame;
    this.a = parame.a;
    if (Build.VERSION.SDK_INT >= 26) {
      this.b = new Notification.Builder(parame.a, parame.K);
    } else {
      this.b = new Notification.Builder(parame.a);
    } 
    Notification notification = parame.R;
    Notification.Builder builder = this.b.setWhen(notification.when).setSmallIcon(notification.icon, notification.iconLevel).setContent(notification.contentView).setTicker(notification.tickerText, parame.i).setVibrate(notification.vibrate).setLights(notification.ledARGB, notification.ledOnMS, notification.ledOffMS);
    if ((notification.flags & 0x2) != 0) {
      bool = true;
    } else {
      bool = false;
    } 
    builder = builder.setOngoing(bool);
    if ((notification.flags & 0x8) != 0) {
      bool = true;
    } else {
      bool = false;
    } 
    builder = builder.setOnlyAlertOnce(bool);
    if ((notification.flags & 0x10) != 0) {
      bool = true;
    } else {
      bool = false;
    } 
    builder = builder.setAutoCancel(bool).setDefaults(notification.defaults).setContentTitle(parame.e).setContentText(parame.f).setContentInfo(parame.k).setContentIntent(parame.g).setDeleteIntent(notification.deleteIntent);
    PendingIntent pendingIntent = parame.h;
    if ((notification.flags & 0x80) != 0) {
      bool = true;
    } else {
      bool = false;
    } 
    builder.setFullScreenIntent(pendingIntent, bool).setLargeIcon(parame.j).setNumber(parame.l).setProgress(parame.t, parame.u, parame.v);
    this.b.setSubText(parame.q).setUsesChronometer(parame.o).setPriority(parame.m);
    Iterator<v.a> iterator = parame.b.iterator();
    while (iterator.hasNext())
      b(iterator.next()); 
    Bundle bundle = parame.D;
    if (bundle != null)
      this.g.putAll(bundle); 
    int i = Build.VERSION.SDK_INT;
    this.d = parame.H;
    this.e = parame.I;
    this.b.setShowWhen(parame.n);
    this.b.setLocalOnly(parame.z).setGroup(parame.w).setGroupSummary(parame.x).setSortKey(parame.y);
    this.h = parame.O;
    this.b.setCategory(parame.C).setColor(parame.E).setVisibility(parame.F).setPublicVersion(parame.G).setSound(notification.sound, notification.audioAttributes);
    if (i < 28) {
      list = e(g(parame.c), parame.U);
    } else {
      list = parame.U;
    } 
    if (list != null && !list.isEmpty())
      for (String str : list)
        this.b.addPerson(str);  
    this.i = parame.J;
    if (parame.d.size() > 0) {
      Bundle bundle2 = parame.d().getBundle("android.car.EXTENSIONS");
      Bundle bundle1 = bundle2;
      if (bundle2 == null)
        bundle1 = new Bundle(); 
      bundle2 = new Bundle(bundle1);
      Bundle bundle3 = new Bundle();
      for (i = 0; i < parame.d.size(); i++)
        bundle3.putBundle(Integer.toString(i), u0.a(parame.d.get(i))); 
      bundle1.putBundle("invisible_actions", bundle3);
      bundle2.putBundle("invisible_actions", bundle3);
      parame.d().putBundle("android.car.EXTENSIONS", bundle1);
      this.g.putBundle("android.car.EXTENSIONS", bundle2);
    } 
    i = Build.VERSION.SDK_INT;
    if (i >= 23) {
      Icon icon = parame.T;
      if (icon != null)
        a0.a(this.b, icon); 
    } 
    if (i >= 24) {
      q0.a(this.b.setExtras(parame.D), parame.s);
      RemoteViews remoteViews = parame.H;
      if (remoteViews != null)
        r0.a(this.b, remoteViews); 
      remoteViews = parame.I;
      if (remoteViews != null)
        s0.a(this.b, remoteViews); 
      remoteViews = parame.J;
      if (remoteViews != null)
        b0.a(this.b, remoteViews); 
    } 
    if (i >= 26) {
      p0.a(f0.a(e0.a(d0.a(c0.a(this.b, parame.L), parame.r), parame.M), parame.N), parame.O);
      if (parame.B)
        k0.a(this.b, parame.A); 
      if (!TextUtils.isEmpty(parame.K))
        this.b.setSound(null).setDefaults(0).setLights(0, 0, 0).setVibrate(null); 
    } 
    if (i >= 28)
      for (z0 z0 : parame.c)
        l0.a(this.b, z0.h());  
    i = Build.VERSION.SDK_INT;
    if (i >= 29) {
      m0.a(this.b, parame.Q);
      n0.a(this.b, v.d.a(null));
    } 
    if (i >= 31) {
      int j = parame.P;
      if (j != 0)
        o0.a(this.b, j); 
    } 
    if (parame.S) {
      if (this.c.x) {
        this.h = 2;
      } else {
        this.h = 1;
      } 
      this.b.setVibrate(null);
      this.b.setSound(null);
      int j = notification.defaults & 0xFFFFFFFE & 0xFFFFFFFD;
      notification.defaults = j;
      this.b.setDefaults(j);
      if (i >= 26) {
        if (TextUtils.isEmpty(this.c.w))
          this.b.setGroup("silent"); 
        p0.a(this.b, this.h);
      } 
    } 
  }
  
  private void b(v.a parama) {
    Notification.Action.Builder builder;
    Bundle bundle;
    int i = Build.VERSION.SDK_INT;
    IconCompat iconCompat = parama.d();
    boolean bool = false;
    if (i >= 23) {
      if (iconCompat != null) {
        Icon icon = iconCompat.q();
      } else {
        iconCompat = null;
      } 
      builder = new Notification.Action.Builder((Icon)iconCompat, parama.h(), parama.a());
    } else {
      if (builder != null) {
        i = builder.j();
      } else {
        i = 0;
      } 
      builder = new Notification.Action.Builder(i, parama.h(), parama.a());
    } 
    if (parama.e() != null) {
      RemoteInput[] arrayOfRemoteInput = b1.b(parama.e());
      int j = arrayOfRemoteInput.length;
      for (i = bool; i < j; i++)
        builder.addRemoteInput(arrayOfRemoteInput[i]); 
    } 
    if (parama.c() != null) {
      bundle = new Bundle(parama.c());
    } else {
      bundle = new Bundle();
    } 
    bundle.putBoolean("android.support.allowGeneratedReplies", parama.b());
    i = Build.VERSION.SDK_INT;
    if (i >= 24)
      g0.a(builder, parama.b()); 
    bundle.putInt("android.support.action.semanticAction", parama.f());
    if (i >= 28)
      h0.a(builder, parama.f()); 
    if (i >= 29)
      i0.a(builder, parama.j()); 
    if (i >= 31)
      j0.a(builder, parama.i()); 
    bundle.putBoolean("android.support.action.showsUserInterface", parama.g());
    builder.addExtras(bundle);
    this.b.addAction(builder.build());
  }
  
  private static List<String> e(List<String> paramList1, List<String> paramList2) {
    if (paramList1 == null)
      return paramList2; 
    if (paramList2 == null)
      return paramList1; 
    b b = new b(paramList1.size() + paramList2.size());
    b.addAll(paramList1);
    b.addAll(paramList2);
    return new ArrayList<String>((Collection<? extends String>)b);
  }
  
  private static List<String> g(List<z0> paramList) {
    if (paramList == null)
      return null; 
    ArrayList<String> arrayList = new ArrayList(paramList.size());
    Iterator<z0> iterator = paramList.iterator();
    while (iterator.hasNext())
      arrayList.add(((z0)iterator.next()).g()); 
    return arrayList;
  }
  
  private void h(Notification paramNotification) {
    paramNotification.sound = null;
    paramNotification.vibrate = null;
    paramNotification.defaults = paramNotification.defaults & 0xFFFFFFFE & 0xFFFFFFFD;
  }
  
  public Notification.Builder a() {
    return this.b;
  }
  
  public Notification c() {
    RemoteViews remoteViews;
    v.f f = this.c.p;
    if (f != null)
      f.b(this); 
    if (f != null) {
      remoteViews = f.e(this);
    } else {
      remoteViews = null;
    } 
    Notification notification = d();
    if (remoteViews != null) {
      notification.contentView = remoteViews;
    } else {
      remoteViews = this.c.H;
      if (remoteViews != null)
        notification.contentView = remoteViews; 
    } 
    if (f != null) {
      remoteViews = f.d(this);
      if (remoteViews != null)
        notification.bigContentView = remoteViews; 
    } 
    if (f != null) {
      remoteViews = this.c.p.f(this);
      if (remoteViews != null)
        notification.headsUpContentView = remoteViews; 
    } 
    if (f != null) {
      Bundle bundle = v.a(notification);
      if (bundle != null)
        f.a(bundle); 
    } 
    return notification;
  }
  
  protected Notification d() {
    int i = Build.VERSION.SDK_INT;
    if (i >= 26)
      return this.b.build(); 
    if (i >= 24) {
      Notification notification1 = this.b.build();
      if (this.h != 0) {
        if (notification1.getGroup() != null && (notification1.flags & 0x200) != 0 && this.h == 2)
          h(notification1); 
        if (notification1.getGroup() != null && (notification1.flags & 0x200) == 0 && this.h == 1)
          h(notification1); 
      } 
      return notification1;
    } 
    this.b.setExtras(this.g);
    Notification notification = this.b.build();
    RemoteViews remoteViews = this.d;
    if (remoteViews != null)
      notification.contentView = remoteViews; 
    remoteViews = this.e;
    if (remoteViews != null)
      notification.bigContentView = remoteViews; 
    remoteViews = this.i;
    if (remoteViews != null)
      notification.headsUpContentView = remoteViews; 
    if (this.h != 0) {
      if (notification.getGroup() != null && (notification.flags & 0x200) != 0 && this.h == 2)
        h(notification); 
      if (notification.getGroup() != null && (notification.flags & 0x200) == 0 && this.h == 1)
        h(notification); 
    } 
    return notification;
  }
  
  Context f() {
    return this.a;
  }
}


/* Location:              C:\soft\dex2jar-2.0\Cricket Scorer-dex2jar.jar!\androidx\core\app\t0.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */