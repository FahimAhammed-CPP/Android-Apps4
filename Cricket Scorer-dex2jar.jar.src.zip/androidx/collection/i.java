package androidx.collection;

import java.util.Iterator;
import m8.k;

public final class i {
  public static final <T> Iterator<T> a(h<T> paramh) {
    k.g(paramh, "receiver$0");
    return new a(paramh);
  }
  
  public static final class a implements Iterator<T>, n8.a {
    private int a;
    
    a(h<T> param1h) {}
    
    public boolean hasNext() {
      return (this.a < this.b.q());
    }
    
    public T next() {
      h<T> h1 = this.b;
      int i = this.a;
      this.a = i + 1;
      return h1.r(i);
    }
    
    public void remove() {
      throw new UnsupportedOperationException("Operation is not supported for read-only collection");
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Cricket Scorer-dex2jar.jar!\androidx\collection\i.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */