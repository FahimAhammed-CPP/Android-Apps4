package com.adjust.sdk;

import android.content.Context;
import android.os.Handler;
import android.os.HandlerThread;
import android.os.Looper;
import android.os.Message;
import java.io.BufferedInputStream;
import java.io.BufferedOutputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.NotSerializableException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.io.OptionalDataException;
import java.lang.ref.WeakReference;
import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.atomic.AtomicBoolean;
import org.json.JSONObject;

public class PackageHandler extends HandlerThread implements IPackageHandler {
  private static final String PACKAGE_QUEUE_FILENAME = "AdjustIoPackageQueue";
  
  private ActivityHandler activityHandler;
  
  private Context context;
  
  private boolean dropOfflineActivities;
  
  private final InternalHandler internalHandler;
  
  private AtomicBoolean isSending;
  
  private Logger logger;
  
  private List<ActivityPackage> packageQueue;
  
  private boolean paused;
  
  private IRequestHandler requestHandler;
  
  public PackageHandler(ActivityHandler paramActivityHandler, Context paramContext, boolean paramBoolean) {
    super("Adjust", 1);
    setDaemon(true);
    start();
    this.internalHandler = new InternalHandler(getLooper(), this);
    this.logger = AdjustFactory.getLogger();
    this.activityHandler = paramActivityHandler;
    this.context = paramContext;
    this.dropOfflineActivities = paramBoolean;
    Message message = Message.obtain();
    message.arg1 = 1;
    this.internalHandler.sendMessage(message);
  }
  
  private void addInternal(ActivityPackage paramActivityPackage) {
    this.packageQueue.add(paramActivityPackage);
    this.logger.debug("Added package %d (%s)", new Object[] { Integer.valueOf(this.packageQueue.size()), paramActivityPackage });
    this.logger.verbose(paramActivityPackage.getExtendedString(), new Object[0]);
    writePackageQueue();
  }
  
  public static Boolean deletePackageQueue(Context paramContext) {
    return Boolean.valueOf(paramContext.deleteFile("AdjustIoPackageQueue"));
  }
  
  private void initInternal() {
    this.requestHandler = AdjustFactory.getRequestHandler(this);
    this.isSending = new AtomicBoolean();
    readPackageQueue();
  }
  
  private void readPackageQueue() {
    Exception exception2;
    if (this.dropOfflineActivities) {
      this.packageQueue = new ArrayList<ActivityPackage>();
      return;
    } 
    try {
      ObjectInputStream objectInputStream = new ObjectInputStream(new BufferedInputStream(this.context.openFileInput("AdjustIoPackageQueue")));
      try {
        List<ActivityPackage> list = (List)objectInputStream.readObject();
        this.logger.debug("Package handler read %d packages", new Object[] { Integer.valueOf(list.size()) });
        this.packageQueue = list;
        objectInputStream.close();
        return;
      } catch (ClassNotFoundException null) {
        this.logger.error("Failed to find package queue class", new Object[0]);
        objectInputStream.close();
        this.packageQueue = new ArrayList<ActivityPackage>();
        return;
      } catch (OptionalDataException null) {
        objectInputStream.close();
        this.packageQueue = new ArrayList<ActivityPackage>();
        return;
      } catch (IOException null) {
        this.logger.error("Failed to read package queue object", new Object[0]);
        objectInputStream.close();
        this.packageQueue = new ArrayList<ActivityPackage>();
        return;
      } catch (ClassCastException null) {
        this.logger.error("Failed to cast package queue object", new Object[0]);
        objectInputStream.close();
        this.packageQueue = new ArrayList<ActivityPackage>();
        return;
      } finally {}
    } catch (FileNotFoundException null) {
      this.logger.verbose("Package queue file not found", new Object[0]);
      this.packageQueue = new ArrayList<ActivityPackage>();
      return;
    } catch (Exception exception1) {
      this.logger.error("Failed to read package queue file", new Object[0]);
      this.packageQueue = new ArrayList<ActivityPackage>();
      return;
    } 
    exception1.close();
    throw exception2;
  }
  
  private void sendFirstInternal() {
    if (this.packageQueue.isEmpty())
      return; 
    if (this.paused) {
      this.logger.debug("Package handler is paused", new Object[0]);
      return;
    } 
    if (this.isSending.getAndSet(true)) {
      this.logger.verbose("Package handler is already sending", new Object[0]);
      return;
    } 
    ActivityPackage activityPackage = this.packageQueue.get(0);
    this.requestHandler.sendPackage(activityPackage);
  }
  
  private void sendNextInternal() {
    this.packageQueue.remove(0);
    writePackageQueue();
    this.isSending.set(false);
    sendFirstInternal();
  }
  
  private void writePackageQueue() {
    Exception exception2;
    if (this.dropOfflineActivities)
      return; 
    try {
      ObjectOutputStream objectOutputStream = new ObjectOutputStream(new BufferedOutputStream(this.context.openFileOutput("AdjustIoPackageQueue", 0)));
      try {
        objectOutputStream.writeObject(this.packageQueue);
        this.logger.debug("Package handler wrote %d packages", new Object[] { Integer.valueOf(this.packageQueue.size()) });
        objectOutputStream.close();
        return;
      } catch (NotSerializableException null) {
        this.logger.error("Failed to serialize packages", new Object[0]);
        objectOutputStream.close();
        return;
      } finally {}
    } catch (Exception exception1) {
      this.logger.error("Failed to write packages (%s)", new Object[] { exception1.getLocalizedMessage() });
      exception1.printStackTrace();
      return;
    } 
    exception1.close();
    throw exception2;
  }
  
  public void addPackage(ActivityPackage paramActivityPackage) {
    Message message = Message.obtain();
    message.arg1 = 2;
    message.obj = paramActivityPackage;
    this.internalHandler.sendMessage(message);
  }
  
  public void closeFirstPackage() {
    if (this.dropOfflineActivities) {
      sendNextPackage();
      return;
    } 
    this.isSending.set(false);
  }
  
  public boolean dropsOfflineActivities() {
    return this.dropOfflineActivities;
  }
  
  public void finishedTrackingActivity(ActivityPackage paramActivityPackage, ResponseData paramResponseData, JSONObject paramJSONObject) {
    String str;
    paramResponseData.setActivityKind(paramActivityPackage.getActivityKind());
    paramActivityPackage = null;
    if (paramJSONObject != null)
      str = paramJSONObject.optString("deeplink", null); 
    this.activityHandler.finishedTrackingActivity(paramResponseData, str);
  }
  
  public String getFailureMessage() {
    return this.dropOfflineActivities ? "Dropping offline activity." : "Will retry later.";
  }
  
  public void pauseSending() {
    this.paused = true;
  }
  
  public void resumeSending() {
    this.paused = false;
  }
  
  public void sendFirstPackage() {
    Message message = Message.obtain();
    message.arg1 = 4;
    this.internalHandler.sendMessage(message);
  }
  
  public void sendNextPackage() {
    Message message = Message.obtain();
    message.arg1 = 3;
    this.internalHandler.sendMessage(message);
  }
  
  private static final class InternalHandler extends Handler {
    private static final int ADD = 2;
    
    private static final int INIT = 1;
    
    private static final int SEND_FIRST = 4;
    
    private static final int SEND_NEXT = 3;
    
    private final WeakReference<PackageHandler> packageHandlerReference;
    
    protected InternalHandler(Looper param1Looper, PackageHandler param1PackageHandler) {
      super(param1Looper);
      this.packageHandlerReference = new WeakReference<PackageHandler>(param1PackageHandler);
    }
    
    public void handleMessage(Message param1Message) {
      super.handleMessage(param1Message);
      PackageHandler packageHandler = this.packageHandlerReference.get();
      if (packageHandler == null)
        return; 
      switch (param1Message.arg1) {
        default:
          return;
        case 1:
          packageHandler.initInternal();
          return;
        case 2:
          packageHandler.addInternal((ActivityPackage)param1Message.obj);
          return;
        case 4:
          packageHandler.sendFirstInternal();
          return;
        case 3:
          break;
      } 
      packageHandler.sendNextInternal();
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Smash Cricket-dex2jar.jar!\com\adjust\sdk\PackageHandler.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */