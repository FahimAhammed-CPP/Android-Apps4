package com.adjust.sdk;

import java.io.Serializable;
import java.util.Map;

public class ActivityPackage implements Serializable {
  private static final long serialVersionUID = -35935556512024097L;
  
  private ActivityKind activityKind;
  
  private String clientSdk;
  
  private Map<String, String> parameters;
  
  private String path;
  
  private String suffix;
  
  private String userAgent;
  
  public ActivityKind getActivityKind() {
    return this.activityKind;
  }
  
  public String getClientSdk() {
    return this.clientSdk;
  }
  
  public String getExtendedString() {
    StringBuilder stringBuilder = new StringBuilder();
    stringBuilder.append(String.format("Path:      %s\n", new Object[] { this.path }));
    stringBuilder.append(String.format("UserAgent: %s\n", new Object[] { this.userAgent }));
    stringBuilder.append(String.format("ClientSdk: %s\n", new Object[] { this.clientSdk }));
    if (this.parameters != null) {
      stringBuilder.append("Parameters:");
      for (Map.Entry<String, String> entry : this.parameters.entrySet()) {
        stringBuilder.append(String.format("\n\t%-16s %s", new Object[] { entry.getKey(), entry.getValue() }));
      } 
    } 
    return stringBuilder.toString();
  }
  
  protected String getFailureMessage() {
    try {
      return String.format("Failed to track %s%s", new Object[] { this.activityKind.toString(), this.suffix });
    } catch (NullPointerException nullPointerException) {
      return "Failed to track ???";
    } 
  }
  
  public Map<String, String> getParameters() {
    return this.parameters;
  }
  
  public String getPath() {
    return this.path;
  }
  
  protected String getSuccessMessage() {
    try {
      return String.format("Tracked %s%s", new Object[] { this.activityKind.toString(), this.suffix });
    } catch (NullPointerException nullPointerException) {
      return "Tracked ???";
    } 
  }
  
  public String getSuffix() {
    return this.suffix;
  }
  
  public String getUserAgent() {
    return this.userAgent;
  }
  
  public void setActivityKind(ActivityKind paramActivityKind) {
    this.activityKind = paramActivityKind;
  }
  
  public void setClientSdk(String paramString) {
    this.clientSdk = paramString;
  }
  
  public void setParameters(Map<String, String> paramMap) {
    this.parameters = paramMap;
  }
  
  public void setPath(String paramString) {
    this.path = paramString;
  }
  
  public void setSuffix(String paramString) {
    this.suffix = paramString;
  }
  
  public void setUserAgent(String paramString) {
    this.userAgent = paramString;
  }
  
  public String toString() {
    return String.format("%s%s", new Object[] { this.activityKind.toString(), this.suffix });
  }
}


/* Location:              C:\soft\dex2jar-2.0\Smash Cricket-dex2jar.jar!\com\adjust\sdk\ActivityPackage.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */