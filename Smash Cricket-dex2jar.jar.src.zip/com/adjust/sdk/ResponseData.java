package com.adjust.sdk;

import android.text.TextUtils;
import java.util.HashMap;
import java.util.Locale;
import java.util.Map;
import org.json.JSONObject;

public class ResponseData {
  private ActivityKind activityKind = ActivityKind.UNKNOWN;
  
  private String adgroup;
  
  private String campaign;
  
  private String creative;
  
  private String error;
  
  private String network;
  
  private boolean success;
  
  private String trackerName;
  
  private String trackerToken;
  
  private boolean willRetry;
  
  public static ResponseData fromError(String paramString) {
    ResponseData responseData = new ResponseData();
    responseData.error = paramString;
    return responseData;
  }
  
  public static ResponseData fromJson(JSONObject paramJSONObject, String paramString) {
    if (paramJSONObject == null)
      return fromError(String.format("Failed to parse json response: %s", new Object[] { paramString.trim() })); 
    ResponseData responseData = new ResponseData();
    responseData.error = paramJSONObject.optString("error", null);
    responseData.trackerToken = paramJSONObject.optString("tracker_token", null);
    responseData.trackerName = paramJSONObject.optString("tracker_name", null);
    responseData.network = paramJSONObject.optString("network", null);
    responseData.campaign = paramJSONObject.optString("campaign", null);
    responseData.adgroup = paramJSONObject.optString("adgroup", null);
    responseData.creative = paramJSONObject.optString("creative", null);
    return responseData;
  }
  
  public ActivityKind getActivityKind() {
    return this.activityKind;
  }
  
  public String getActivityKindString() {
    return this.activityKind.toString();
  }
  
  public String getAdgroup() {
    return this.adgroup;
  }
  
  public String getCampaign() {
    return this.campaign;
  }
  
  public String getCreative() {
    return this.creative;
  }
  
  public String getError() {
    return this.error;
  }
  
  public String getNetwork() {
    return this.network;
  }
  
  public String getTrackerName() {
    return this.trackerName;
  }
  
  public String getTrackerToken() {
    return this.trackerToken;
  }
  
  public void setActivityKind(ActivityKind paramActivityKind) {
    this.activityKind = paramActivityKind;
  }
  
  public void setWasSuccess(boolean paramBoolean) {
    this.success = paramBoolean;
  }
  
  public void setWillRetry(boolean paramBoolean) {
    this.willRetry = paramBoolean;
  }
  
  public Map<String, String> toDic() {
    String str;
    HashMap<Object, Object> hashMap = new HashMap<Object, Object>();
    hashMap.put("activityKind", this.activityKind.toString());
    if (this.success) {
      str = "true";
    } else {
      str = "false";
    } 
    hashMap.put("success", str);
    if (this.willRetry) {
      str = "true";
    } else {
      str = "false";
    } 
    hashMap.put("willRetry", str);
    if (!TextUtils.isEmpty(this.error))
      hashMap.put("error", this.error); 
    if (!TextUtils.isEmpty(this.trackerToken))
      hashMap.put("trackerToken", this.trackerToken); 
    if (!TextUtils.isEmpty(this.trackerName))
      hashMap.put("trackerName", this.trackerName); 
    if (!TextUtils.isEmpty(this.network))
      hashMap.put("network", this.network); 
    if (!TextUtils.isEmpty(this.campaign))
      hashMap.put("campaign", this.campaign); 
    if (!TextUtils.isEmpty(this.adgroup))
      hashMap.put("adgroup", this.adgroup); 
    if (!TextUtils.isEmpty(this.creative))
      hashMap.put("creative", this.creative); 
    return (Map)hashMap;
  }
  
  public String toString() {
    return String.format(Locale.US, "[kind:%s success:%b willRetry:%b error:%s trackerToken:%s trackerName:%s network:%s campaign:%s adgroup:%s creative:%s]", new Object[] { getActivityKindString(), Boolean.valueOf(this.success), Boolean.valueOf(this.willRetry), Util.quote(this.error), this.trackerToken, Util.quote(this.trackerName), Util.quote(this.network), Util.quote(this.campaign), Util.quote(this.adgroup), Util.quote(this.creative) });
  }
  
  public boolean wasSuccess() {
    return this.success;
  }
  
  public boolean willRetry() {
    return this.willRetry;
  }
}


/* Location:              C:\soft\dex2jar-2.0\Smash Cricket-dex2jar.jar!\com\adjust\sdk\ResponseData.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */