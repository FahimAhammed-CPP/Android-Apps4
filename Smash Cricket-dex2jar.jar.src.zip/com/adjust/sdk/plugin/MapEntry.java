package com.adjust.sdk.plugin;

import java.util.Map;

public class MapEntry<K, V> implements Map.Entry<K, V> {
  private K key;
  
  private V value;
  
  public MapEntry(K paramK, V paramV) {
    this.key = paramK;
    this.value = paramV;
  }
  
  public K getKey() {
    return this.key;
  }
  
  public V getValue() {
    return this.value;
  }
  
  public V setValue(V paramV) {
    this.value = paramV;
    return this.value;
  }
}


/* Location:              C:\soft\dex2jar-2.0\Smash Cricket-dex2jar.jar!\com\adjust\sdk\plugin\MapEntry.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */