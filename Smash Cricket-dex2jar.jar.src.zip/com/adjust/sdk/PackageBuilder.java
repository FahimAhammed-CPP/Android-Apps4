package com.adjust.sdk;

import android.content.Context;
import android.text.TextUtils;
import android.util.Base64;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Locale;
import java.util.Map;
import org.json.JSONObject;

public class PackageBuilder {
  private double amountInCents;
  
  private String androidId;
  
  private String appToken;
  
  private Map<String, String> callbackParameters;
  
  private String clientSdk;
  
  private Context context;
  
  private long createdAt;
  
  private Map<String, String> deepLinkParameters;
  
  private String defaultTracker;
  
  private String environment;
  
  private int eventCount;
  
  private String eventToken;
  
  private String fbAttributionId;
  
  private long lastInterval;
  
  private String macSha1;
  
  private String macShortMd5;
  
  private Map<String, String> pluginsKeys;
  
  private String referrer;
  
  private int sessionCount;
  
  private long sessionLength;
  
  private int subsessionCount;
  
  private long timeSpent;
  
  private String userAgent;
  
  private String uuid;
  
  public PackageBuilder(Context paramContext) {
    this.context = paramContext;
  }
  
  private void addBoolean(Map<String, String> paramMap, String paramString, Boolean paramBoolean) {
    boolean bool;
    if (paramBoolean == null)
      return; 
    if (paramBoolean.booleanValue()) {
      bool = true;
    } else {
      bool = false;
    } 
    addInt(paramMap, paramString, bool);
  }
  
  private void addDate(Map<String, String> paramMap, String paramString, long paramLong) {
    if (paramLong < 0L)
      return; 
    addString(paramMap, paramString, Util.dateFormat(paramLong));
  }
  
  private void addDuration(Map<String, String> paramMap, String paramString, long paramLong) {
    if (paramLong < 0L)
      return; 
    addInt(paramMap, paramString, (500L + paramLong) / 1000L);
  }
  
  private void addInt(Map<String, String> paramMap, String paramString, long paramLong) {
    if (paramLong < 0L)
      return; 
    addString(paramMap, paramString, Long.toString(paramLong));
  }
  
  private void addMapBase64(Map<String, String> paramMap1, String paramString, Map<String, String> paramMap2) {
    if (paramMap2 == null)
      return; 
    addString(paramMap1, paramString, Base64.encodeToString((new JSONObject(paramMap2)).toString().getBytes(), 2));
  }
  
  private void addMapJson(Map<String, String> paramMap1, String paramString, Map<String, String> paramMap2) {
    if (paramMap2 == null)
      return; 
    addString(paramMap1, paramString, (new JSONObject(paramMap2)).toString());
  }
  
  private void addString(Map<String, String> paramMap, String paramString1, String paramString2) {
    if (TextUtils.isEmpty(paramString2))
      return; 
    paramMap.put(paramString1, paramString2);
  }
  
  private void checkDeviceIds(Map<String, String> paramMap) {
    if (!paramMap.containsKey("mac_sha1") && !paramMap.containsKey("mac_md5") && !paramMap.containsKey("android_id") && !paramMap.containsKey("gps_adid"))
      AdjustFactory.getLogger().error("Missing device id's. Please check if Proguard is correctly set with Adjust SDK", new Object[0]); 
  }
  
  private void fillPluginKeys(Map<String, String> paramMap) {
    if (this.pluginsKeys != null) {
      Iterator<Map.Entry> iterator = this.pluginsKeys.entrySet().iterator();
      while (true) {
        if (iterator.hasNext()) {
          Map.Entry entry = iterator.next();
          addString(paramMap, (String)entry.getKey(), (String)entry.getValue());
          continue;
        } 
        return;
      } 
    } 
  }
  
  private String getAmountString() {
    long l = Math.round(this.amountInCents * 10.0D);
    this.amountInCents = l / 10.0D;
    return Long.toString(l);
  }
  
  private ActivityPackage getDefaultActivityPackage() {
    ActivityPackage activityPackage = new ActivityPackage();
    activityPackage.setUserAgent(this.userAgent);
    activityPackage.setClientSdk(this.clientSdk);
    return activityPackage;
  }
  
  private Map<String, String> getDefaultParameters() {
    HashMap<Object, Object> hashMap = new HashMap<Object, Object>();
    addDate((Map)hashMap, "created_at", this.createdAt);
    addString((Map)hashMap, "app_token", this.appToken);
    addString((Map)hashMap, "mac_sha1", this.macSha1);
    addString((Map)hashMap, "mac_md5", this.macShortMd5);
    addString((Map)hashMap, "android_id", this.androidId);
    addString((Map)hashMap, "android_uuid", this.uuid);
    addString((Map)hashMap, "fb_id", this.fbAttributionId);
    addString((Map)hashMap, "environment", this.environment);
    addString((Map)hashMap, "gps_adid", Util.getPlayAdId(this.context));
    addBoolean((Map)hashMap, "tracking_enabled", Util.isPlayTrackingEnabled(this.context));
    fillPluginKeys((Map)hashMap);
    checkDeviceIds((Map)hashMap);
    addInt((Map)hashMap, "session_count", this.sessionCount);
    addInt((Map)hashMap, "subsession_count", this.subsessionCount);
    addDuration((Map)hashMap, "session_length", this.sessionLength);
    addDuration((Map)hashMap, "time_spent", this.timeSpent);
    return (Map)hashMap;
  }
  
  private String getEventSuffix() {
    return String.format(" '%s'", new Object[] { this.eventToken });
  }
  
  private String getRevenueSuffix() {
    return (this.eventToken != null) ? String.format(Locale.US, " (%.1f cent, '%s')", new Object[] { Double.valueOf(this.amountInCents), this.eventToken }) : String.format(Locale.US, " (%.1f cent)", new Object[] { Double.valueOf(this.amountInCents) });
  }
  
  private void injectEventParameters(Map<String, String> paramMap) {
    addInt(paramMap, "event_count", this.eventCount);
    addString(paramMap, "event_token", this.eventToken);
    addMapBase64(paramMap, "params", this.callbackParameters);
  }
  
  private boolean isEventTokenValid() {
    if (6 != this.eventToken.length()) {
      AdjustFactory.getLogger().error("Malformed Event Token '%s'", new Object[] { this.eventToken });
      return false;
    } 
    return true;
  }
  
  public ActivityPackage buildEventPackage() {
    Map<String, String> map = getDefaultParameters();
    injectEventParameters(map);
    ActivityPackage activityPackage = getDefaultActivityPackage();
    activityPackage.setPath("/event");
    activityPackage.setActivityKind(ActivityKind.EVENT);
    activityPackage.setSuffix(getEventSuffix());
    activityPackage.setParameters(map);
    return activityPackage;
  }
  
  public ActivityPackage buildReattributionPackage() {
    Map<String, String> map = getDefaultParameters();
    addMapJson(map, "deeplink_parameters", this.deepLinkParameters);
    ActivityPackage activityPackage = getDefaultActivityPackage();
    activityPackage.setPath("/reattribute");
    activityPackage.setActivityKind(ActivityKind.REATTRIBUTION);
    activityPackage.setSuffix("");
    activityPackage.setParameters(map);
    return activityPackage;
  }
  
  public ActivityPackage buildRevenuePackage() {
    Map<String, String> map = getDefaultParameters();
    injectEventParameters(map);
    addString(map, "amount", getAmountString());
    ActivityPackage activityPackage = getDefaultActivityPackage();
    activityPackage.setPath("/revenue");
    activityPackage.setActivityKind(ActivityKind.REVENUE);
    activityPackage.setSuffix(getRevenueSuffix());
    activityPackage.setParameters(map);
    return activityPackage;
  }
  
  public ActivityPackage buildSessionPackage() {
    Map<String, String> map = getDefaultParameters();
    addDuration(map, "last_interval", this.lastInterval);
    addString(map, "default_tracker", this.defaultTracker);
    addString(map, "referrer", this.referrer);
    ActivityPackage activityPackage = getDefaultActivityPackage();
    activityPackage.setPath("/startup");
    activityPackage.setActivityKind(ActivityKind.SESSION);
    activityPackage.setSuffix("");
    activityPackage.setParameters(map);
    return activityPackage;
  }
  
  public double getAmountInCents() {
    return this.amountInCents;
  }
  
  public String getEventToken() {
    return this.eventToken;
  }
  
  public boolean isValidForEvent() {
    if (this.eventToken == null) {
      AdjustFactory.getLogger().error("Missing Event Token", new Object[0]);
      return false;
    } 
    return isEventTokenValid();
  }
  
  public boolean isValidForRevenue() {
    if (this.amountInCents < 0.0D) {
      AdjustFactory.getLogger().error("Invalid amount %f", new Object[] { Double.valueOf(this.amountInCents) });
      return false;
    } 
    return (this.eventToken == null) ? true : isEventTokenValid();
  }
  
  public void setAmountInCents(double paramDouble) {
    this.amountInCents = paramDouble;
  }
  
  public void setAndroidId(String paramString) {
    this.androidId = paramString;
  }
  
  public void setAppToken(String paramString) {
    this.appToken = paramString;
  }
  
  public void setCallbackParameters(Map<String, String> paramMap) {
    this.callbackParameters = paramMap;
  }
  
  public void setClientSdk(String paramString) {
    this.clientSdk = paramString;
  }
  
  public void setCreatedAt(long paramLong) {
    this.createdAt = paramLong;
  }
  
  public void setDeepLinkParameters(Map<String, String> paramMap) {
    this.deepLinkParameters = paramMap;
  }
  
  public void setDefaultTracker(String paramString) {
    this.defaultTracker = paramString;
  }
  
  public void setEnvironment(String paramString) {
    this.environment = paramString;
  }
  
  public void setEventCount(int paramInt) {
    this.eventCount = paramInt;
  }
  
  public void setEventToken(String paramString) {
    this.eventToken = paramString;
  }
  
  public void setFbAttributionId(String paramString) {
    this.fbAttributionId = paramString;
  }
  
  public void setLastInterval(long paramLong) {
    this.lastInterval = paramLong;
  }
  
  public void setMacSha1(String paramString) {
    this.macSha1 = paramString;
  }
  
  public void setMacShortMd5(String paramString) {
    this.macShortMd5 = paramString;
  }
  
  public void setPluginKeys(Map<String, String> paramMap) {
    this.pluginsKeys = paramMap;
  }
  
  public void setReferrer(String paramString) {
    this.referrer = paramString;
  }
  
  public void setSessionCount(int paramInt) {
    this.sessionCount = paramInt;
  }
  
  public void setSessionLength(long paramLong) {
    this.sessionLength = paramLong;
  }
  
  public void setSubsessionCount(int paramInt) {
    this.subsessionCount = paramInt;
  }
  
  public void setTimeSpent(long paramLong) {
    this.timeSpent = paramLong;
  }
  
  public void setUserAgent(String paramString) {
    this.userAgent = paramString;
  }
  
  public void setUuid(String paramString) {
    this.uuid = paramString;
  }
}


/* Location:              C:\soft\dex2jar-2.0\Smash Cricket-dex2jar.jar!\com\adjust\sdk\PackageBuilder.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */