package com.adjust.sdk;

public interface IRequestHandler {
  void sendPackage(ActivityPackage paramActivityPackage);
}


/* Location:              C:\soft\dex2jar-2.0\Smash Cricket-dex2jar.jar!\com\adjust\sdk\IRequestHandler.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */