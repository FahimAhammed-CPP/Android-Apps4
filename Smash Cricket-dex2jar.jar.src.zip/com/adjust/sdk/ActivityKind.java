package com.adjust.sdk;

public enum ActivityKind {
  EVENT, REATTRIBUTION, REVENUE, SESSION, UNKNOWN;
  
  static {
    SESSION = new ActivityKind("SESSION", 1);
    EVENT = new ActivityKind("EVENT", 2);
    REVENUE = new ActivityKind("REVENUE", 3);
    REATTRIBUTION = new ActivityKind("REATTRIBUTION", 4);
    $VALUES = new ActivityKind[] { UNKNOWN, SESSION, EVENT, REVENUE, REATTRIBUTION };
  }
  
  public static ActivityKind fromString(String paramString) {
    return "session".equals(paramString) ? SESSION : ("event".equals(paramString) ? EVENT : ("revenue".equals(paramString) ? REVENUE : ("reattribution".equals(paramString) ? REATTRIBUTION : UNKNOWN)));
  }
  
  public String toString() {
    switch (this) {
      default:
        return "unknown";
      case SESSION:
        return "session";
      case EVENT:
        return "event";
      case REVENUE:
        return "revenue";
      case REATTRIBUTION:
        break;
    } 
    return "reattribution";
  }
}


/* Location:              C:\soft\dex2jar-2.0\Smash Cricket-dex2jar.jar!\com\adjust\sdk\ActivityKind.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */