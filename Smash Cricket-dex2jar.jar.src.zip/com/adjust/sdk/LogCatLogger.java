package com.adjust.sdk;

import android.util.Log;
import java.util.Locale;

public class LogCatLogger implements Logger {
  private Logger.LogLevel logLevel;
  
  public LogCatLogger() {
    setLogLevel(Logger.LogLevel.INFO);
  }
  
  public void Assert(String paramString, Object... paramVarArgs) {
    Log.println(7, "Adjust", String.format(paramString, paramVarArgs));
  }
  
  public void debug(String paramString, Object... paramVarArgs) {
    if (this.logLevel.androidLogLevel <= 3)
      Log.d("Adjust", String.format(paramString, paramVarArgs)); 
  }
  
  public void error(String paramString, Object... paramVarArgs) {
    if (this.logLevel.androidLogLevel <= 6)
      Log.e("Adjust", String.format(paramString, paramVarArgs)); 
  }
  
  public void info(String paramString, Object... paramVarArgs) {
    if (this.logLevel.androidLogLevel <= 4)
      Log.i("Adjust", String.format(paramString, paramVarArgs)); 
  }
  
  public void setLogLevel(Logger.LogLevel paramLogLevel) {
    this.logLevel = paramLogLevel;
  }
  
  public void setLogLevelString(String paramString) {
    if (paramString != null)
      try {
        setLogLevel(Logger.LogLevel.valueOf(paramString.toUpperCase(Locale.US)));
        return;
      } catch (IllegalArgumentException illegalArgumentException) {
        error("Malformed logLevel '%s', falling back to 'info'", new Object[] { paramString });
        return;
      }  
  }
  
  public void verbose(String paramString, Object... paramVarArgs) {
    if (this.logLevel.androidLogLevel <= 2)
      Log.v("Adjust", String.format(paramString, paramVarArgs)); 
  }
  
  public void warn(String paramString, Object... paramVarArgs) {
    if (this.logLevel.androidLogLevel <= 5)
      Log.w("Adjust", String.format(paramString, paramVarArgs)); 
  }
}


/* Location:              C:\soft\dex2jar-2.0\Smash Cricket-dex2jar.jar!\com\adjust\sdk\LogCatLogger.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */