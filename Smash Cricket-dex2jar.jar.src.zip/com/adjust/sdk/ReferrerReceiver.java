package com.adjust.sdk;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.preference.PreferenceManager;
import java.io.UnsupportedEncodingException;
import java.net.URLDecoder;

public class ReferrerReceiver extends BroadcastReceiver {
  protected static final String REFERRER_KEY = "AdjustInstallReferrer";
  
  public void onReceive(Context paramContext, Intent paramIntent) {
    String str = paramIntent.getStringExtra("referrer");
    if (str == null)
      return; 
    try {
      str = URLDecoder.decode(str, "UTF-8");
    } catch (UnsupportedEncodingException unsupportedEncodingException) {
      str = "malformed";
    } 
    PreferenceManager.getDefaultSharedPreferences(paramContext).edit().putString("AdjustInstallReferrer", str).commit();
  }
}


/* Location:              C:\soft\dex2jar-2.0\Smash Cricket-dex2jar.jar!\com\adjust\sdk\ReferrerReceiver.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */