package com.adjust.sdk;

import android.util.Log;
import java.io.IOException;
import java.io.NotActiveException;
import java.io.ObjectInputStream;
import java.io.Serializable;
import java.util.Date;
import java.util.Locale;

public class ActivityState implements Serializable {
  private static final long serialVersionUID = 9039439291143138148L;
  
  protected long createdAt = -1L;
  
  protected Boolean enabled = Boolean.valueOf(true);
  
  protected int eventCount = 0;
  
  protected long lastActivity = -1L;
  
  protected long lastInterval = -1L;
  
  protected int sessionCount = 0;
  
  protected long sessionLength = -1L;
  
  protected int subsessionCount = -1;
  
  protected long timeSpent = -1L;
  
  protected String uuid = Util.createUuid();
  
  private void injectGeneralAttributes(PackageBuilder paramPackageBuilder) {
    paramPackageBuilder.setSessionCount(this.sessionCount);
    paramPackageBuilder.setSubsessionCount(this.subsessionCount);
    paramPackageBuilder.setSessionLength(this.sessionLength);
    paramPackageBuilder.setTimeSpent(this.timeSpent);
    paramPackageBuilder.setCreatedAt(this.createdAt);
    paramPackageBuilder.setUuid(this.uuid);
  }
  
  private void readObject(ObjectInputStream paramObjectInputStream) throws NotActiveException, IOException, ClassNotFoundException {
    ObjectInputStream.GetField getField = paramObjectInputStream.readFields();
    this.eventCount = getField.get("eventCount", 0);
    this.sessionCount = getField.get("sessionCount", 0);
    this.subsessionCount = getField.get("subsessionCount", -1);
    this.sessionLength = getField.get("sessionLength", -1L);
    this.timeSpent = getField.get("timeSpent", -1L);
    this.lastActivity = getField.get("lastActivity", -1L);
    this.createdAt = getField.get("createdAt", -1L);
    this.lastInterval = getField.get("lastInterval", -1L);
    this.uuid = null;
    this.enabled = Boolean.valueOf(true);
    try {
      this.uuid = (String)getField.get("uuid", (Object)null);
      this.enabled = Boolean.valueOf(getField.get("enabled", true));
    } catch (Exception exception) {
      AdjustFactory.getLogger().debug("Unable to read new field in migration device with error (%s)", new Object[] { exception.getMessage() });
    } 
    if (this.uuid == null) {
      this.uuid = Util.createUuid();
      Log.d("XXX", "migrate " + this.uuid);
    } 
  }
  
  private static String stamp(long paramLong) {
    Date date = new Date(paramLong);
    return String.format(Locale.US, "%02d:%02d:%02d", new Object[] { Integer.valueOf(date.getHours()), Integer.valueOf(date.getMinutes()), Integer.valueOf(date.getSeconds()) });
  }
  
  protected void injectEventAttributes(PackageBuilder paramPackageBuilder) {
    injectGeneralAttributes(paramPackageBuilder);
    paramPackageBuilder.setEventCount(this.eventCount);
  }
  
  protected void injectSessionAttributes(PackageBuilder paramPackageBuilder) {
    injectGeneralAttributes(paramPackageBuilder);
    paramPackageBuilder.setLastInterval(this.lastInterval);
  }
  
  protected void resetSessionAttributes(long paramLong) {
    this.subsessionCount = 1;
    this.sessionLength = 0L;
    this.timeSpent = 0L;
    this.lastActivity = paramLong;
    this.createdAt = -1L;
    this.lastInterval = -1L;
  }
  
  public String toString() {
    return String.format(Locale.US, "ec:%d sc:%d ssc:%d sl:%.1f ts:%.1f la:%s", new Object[] { Integer.valueOf(this.eventCount), Integer.valueOf(this.sessionCount), Integer.valueOf(this.subsessionCount), Double.valueOf(this.sessionLength / 1000.0D), Double.valueOf(this.timeSpent / 1000.0D), stamp(this.lastActivity) });
  }
}


/* Location:              C:\soft\dex2jar-2.0\Smash Cricket-dex2jar.jar!\com\adjust\sdk\ActivityState.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */