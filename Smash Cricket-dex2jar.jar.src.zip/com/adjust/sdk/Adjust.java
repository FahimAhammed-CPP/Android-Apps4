package com.adjust.sdk;

import android.app.Activity;
import android.net.Uri;
import java.util.Map;

public class Adjust {
  private static ActivityHandler activityHandler;
  
  private static Logger logger;
  
  public static void appDidLaunch(Activity paramActivity, String paramString1, String paramString2, String paramString3, boolean paramBoolean) {
    activityHandler = new ActivityHandler(paramActivity, paramString1, paramString2, paramString3, paramBoolean);
  }
  
  public static void appWillOpenUrl(Uri paramUri) {
    try {
      activityHandler.readOpenUrl(paramUri);
    } catch (NullPointerException nullPointerException) {}
  }
  
  public static Boolean isEnabled() {
    try {
      return activityHandler.isEnabled();
    } catch (NullPointerException nullPointerException) {
      if (logger != null)
        logger.error("No activity handler found", new Object[0]); 
      return Boolean.valueOf(false);
    } 
  }
  
  public static void onPause() {
    try {
      logger.debug("onPause", new Object[0]);
      activityHandler.trackSubsessionEnd();
    } catch (NullPointerException nullPointerException) {}
  }
  
  public static void onResume(Activity paramActivity) {
    if (activityHandler == null)
      activityHandler = new ActivityHandler(paramActivity); 
    logger = AdjustFactory.getLogger();
    activityHandler.trackSubsessionStart();
  }
  
  public static void setEnabled(Boolean paramBoolean) {
    try {
      activityHandler.setEnabled(paramBoolean);
    } catch (NullPointerException nullPointerException) {}
  }
  
  public static void setOnFinishedListener(OnFinishedListener paramOnFinishedListener) {
    try {
      activityHandler.setOnFinishedListener(paramOnFinishedListener);
    } catch (NullPointerException nullPointerException) {}
  }
  
  public static void setSdkPrefix(String paramString) {
    activityHandler.setSdkPrefix(paramString);
  }
  
  public static void trackEvent(String paramString) {
    trackEvent(paramString, null);
  }
  
  public static void trackEvent(String paramString, Map<String, String> paramMap) {
    try {
      activityHandler.trackEvent(paramString, paramMap);
    } catch (NullPointerException nullPointerException) {}
  }
  
  public static void trackRevenue(double paramDouble) {
    trackRevenue(paramDouble, null);
  }
  
  public static void trackRevenue(double paramDouble, String paramString) {
    trackRevenue(paramDouble, paramString, null);
  }
  
  public static void trackRevenue(double paramDouble, String paramString, Map<String, String> paramMap) {
    try {
      activityHandler.trackRevenue(paramDouble, paramString, paramMap);
    } catch (NullPointerException nullPointerException) {}
  }
}


/* Location:              C:\soft\dex2jar-2.0\Smash Cricket-dex2jar.jar!\com\adjust\sdk\Adjust.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */