package com.adjust.sdk;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.os.Handler;
import android.os.HandlerThread;
import android.os.Looper;
import android.os.Message;
import android.preference.PreferenceManager;
import java.io.BufferedInputStream;
import java.io.BufferedOutputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.NotSerializableException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.io.OptionalDataException;
import java.lang.ref.WeakReference;
import java.util.HashMap;
import java.util.Map;
import java.util.concurrent.Executors;
import java.util.concurrent.ScheduledExecutorService;
import java.util.concurrent.TimeUnit;

public class ActivityHandler extends HandlerThread {
  private static final String ADJUST_PREFIX = "adjust_";
  
  private static long SESSION_INTERVAL = 0L;
  
  private static long SUBSESSION_INTERVAL = 0L;
  
  private static long TIMER_INTERVAL = 0L;
  
  private static final String TIME_TRAVEL = "Time travel!";
  
  private static ScheduledExecutorService timer;
  
  private ActivityState activityState;
  
  private String androidId;
  
  private String appToken;
  
  private String clientSdk;
  
  private Context context;
  
  private String defaultTracker;
  
  private boolean dropOfflineActivities;
  
  private boolean enabled;
  
  private String environment;
  
  private boolean eventBuffering;
  
  private String fbAttributionId;
  
  private Logger logger;
  
  private String macSha1;
  
  private String macShortMd5;
  
  private OnFinishedListener onFinishedListener;
  
  private IPackageHandler packageHandler;
  
  private Map<String, String> pluginKeys;
  
  private SessionHandler sessionHandler;
  
  private String userAgent;
  
  public ActivityHandler(Activity paramActivity) {
    super("Adjust", 1);
    initActivityHandler(paramActivity);
    Message message = Message.obtain();
    message.arg1 = 72630;
    this.sessionHandler.sendMessage(message);
  }
  
  public ActivityHandler(Activity paramActivity, String paramString1, String paramString2, String paramString3, boolean paramBoolean) {
    super("Adjust", 1);
    initActivityHandler(paramActivity);
    this.environment = paramString2;
    this.eventBuffering = paramBoolean;
    this.logger.setLogLevelString(paramString3);
    Message message = Message.obtain();
    message.arg1 = 72633;
    message.obj = paramString1;
    this.sessionHandler.sendMessage(message);
  }
  
  private boolean canInit(String paramString) {
    return (checkAppTokenNotNull(paramString) && checkAppTokenLength(paramString) && checkContext(this.context) && checkPermissions(this.context));
  }
  
  private boolean canTrackEvent(PackageBuilder paramPackageBuilder) {
    return (checkAppTokenNotNull(this.appToken) && checkActivityState(this.activityState) && paramPackageBuilder.isValidForEvent());
  }
  
  private boolean canTrackRevenue(PackageBuilder paramPackageBuilder) {
    return (checkAppTokenNotNull(this.appToken) && checkActivityState(this.activityState) && paramPackageBuilder.isValidForRevenue());
  }
  
  private boolean checkActivityState(ActivityState paramActivityState) {
    if (paramActivityState == null) {
      this.logger.error("Missing activity state.", new Object[0]);
      return false;
    } 
    return true;
  }
  
  private boolean checkAppTokenLength(String paramString) {
    if (12 != paramString.length()) {
      this.logger.error("Malformed App Token '%s'", new Object[] { paramString });
      return false;
    } 
    return true;
  }
  
  private boolean checkAppTokenNotNull(String paramString) {
    if (paramString == null) {
      this.logger.error("Missing App Token.", new Object[0]);
      return false;
    } 
    return true;
  }
  
  private boolean checkContext(Context paramContext) {
    if (paramContext == null) {
      this.logger.error("Missing context", new Object[0]);
      return false;
    } 
    return true;
  }
  
  private static boolean checkPermission(Context paramContext, String paramString) {
    return (paramContext.checkCallingOrSelfPermission(paramString) == 0);
  }
  
  private boolean checkPermissions(Context paramContext) {
    boolean bool = true;
    if (!checkPermission(paramContext, "android.permission.INTERNET")) {
      this.logger.error("Missing permission: INTERNET", new Object[0]);
      bool = false;
    } 
    if (!checkPermission(paramContext, "android.permission.ACCESS_WIFI_STATE"))
      this.logger.warn("Missing permission: ACCESS_WIFI_STATE", new Object[0]); 
    return bool;
  }
  
  public static Boolean deleteActivityState(Context paramContext) {
    return Boolean.valueOf(paramContext.deleteFile("AdjustIoActivityState"));
  }
  
  private void endInternal() {
    if (!checkAppTokenNotNull(this.appToken))
      return; 
    this.packageHandler.pauseSending();
    stopTimer();
    updateActivityState(System.currentTimeMillis());
    writeActivityState();
  }
  
  private void initActivityHandler(Activity paramActivity) {
    setDaemon(true);
    start();
    TIMER_INTERVAL = AdjustFactory.getTimerInterval();
    SESSION_INTERVAL = AdjustFactory.getSessionInterval();
    SUBSESSION_INTERVAL = AdjustFactory.getSubsessionInterval();
    this.sessionHandler = new SessionHandler(getLooper(), this);
    this.context = paramActivity.getApplicationContext();
    this.clientSdk = "android3.6.0";
    this.pluginKeys = Util.getPluginKeys(this.context);
    this.enabled = true;
    this.logger = AdjustFactory.getLogger();
  }
  
  private void initInternal(boolean paramBoolean, String paramString) {
    if (paramBoolean) {
      paramString = processApplicationBundle();
    } else {
      setEnvironment(this.environment);
      setEventBuffering(this.eventBuffering);
    } 
    if (!canInit(paramString))
      return; 
    this.appToken = paramString;
    this.androidId = Util.getAndroidId(this.context);
    this.fbAttributionId = Util.getAttributionId(this.context);
    this.userAgent = Util.getUserAgent(this.context);
    if (Util.getPlayAdId(this.context) == null)
      this.logger.info("Unable to get Google Play Services Advertising ID at start time", new Object[0]); 
    if (!Util.isGooglePlayServicesAvailable(this.context)) {
      paramString = Util.getMacAddress(this.context);
      this.macSha1 = Util.getMacSha1(paramString);
      this.macShortMd5 = Util.getMacShortMd5(paramString);
    } 
    this.packageHandler = AdjustFactory.getPackageHandler(this, this.context, this.dropOfflineActivities);
    readActivityState();
  }
  
  private void injectGeneralAttributes(PackageBuilder paramPackageBuilder) {
    paramPackageBuilder.setAppToken(this.appToken);
    paramPackageBuilder.setMacShortMd5(this.macShortMd5);
    paramPackageBuilder.setMacSha1(this.macSha1);
    paramPackageBuilder.setAndroidId(this.androidId);
    paramPackageBuilder.setFbAttributionId(this.fbAttributionId);
    paramPackageBuilder.setUserAgent(this.userAgent);
    paramPackageBuilder.setClientSdk(this.clientSdk);
    paramPackageBuilder.setEnvironment(this.environment);
    paramPackageBuilder.setDefaultTracker(this.defaultTracker);
    paramPackageBuilder.setPluginKeys(this.pluginKeys);
  }
  
  private void injectReferrer(PackageBuilder paramPackageBuilder) {
    try {
      paramPackageBuilder.setReferrer(PreferenceManager.getDefaultSharedPreferences(this.context).getString("AdjustInstallReferrer", null));
      return;
    } catch (Exception exception) {
      this.logger.error("Failed to inject referrer (%s)", new Object[] { exception });
      return;
    } 
  }
  
  private void launchDeepLinkMain(String paramString) {
    boolean bool;
    if (paramString == null)
      return; 
    Intent intent = new Intent("android.intent.action.VIEW", Uri.parse(paramString));
    intent.setFlags(268435456);
    if (this.context.getPackageManager().queryIntentActivities(intent, 0).size() > 0) {
      bool = true;
    } else {
      bool = false;
    } 
    if (!bool) {
      this.logger.error("Unable to open deep link (%s)", new Object[] { paramString });
      return;
    } 
    this.logger.info("Open deep link (%s)", new Object[] { paramString });
    this.context.startActivity(intent);
  }
  
  private String processApplicationBundle() {
    Bundle bundle = Util.getApplicationBundle(this.context, this.logger);
    if (bundle == null)
      return null; 
    String str = bundle.getString("AdjustAppToken");
    setEnvironment(bundle.getString("AdjustEnvironment"));
    setDefaultTracker(bundle.getString("AdjustDefaultTracker"));
    setEventBuffering(bundle.getBoolean("AdjustEventBuffering"));
    this.logger.setLogLevelString(bundle.getString("AdjustLogLevel"));
    setDropOfflineActivities(bundle.getBoolean("AdjustDropOfflineActivities"));
    return str;
  }
  
  private void readActivityState() {
    Exception exception2;
    try {
      ObjectInputStream objectInputStream = new ObjectInputStream(new BufferedInputStream(this.context.openFileInput("AdjustIoActivityState")));
      try {
        this.activityState = (ActivityState)objectInputStream.readObject();
        this.logger.debug("Read activity state: %s uuid:%s", new Object[] { this.activityState, this.activityState.uuid });
        objectInputStream.close();
        return;
      } catch (ClassNotFoundException null) {
        this.logger.error("Failed to find activity state class", new Object[0]);
        objectInputStream.close();
        this.activityState = null;
        return;
      } catch (OptionalDataException null) {
        objectInputStream.close();
        this.activityState = null;
        return;
      } catch (IOException null) {
        this.logger.error("Failed to read activity states object", new Object[0]);
        objectInputStream.close();
        this.activityState = null;
        return;
      } catch (ClassCastException null) {
        this.logger.error("Failed to cast activity state object", new Object[0]);
        objectInputStream.close();
        this.activityState = null;
        return;
      } finally {}
    } catch (FileNotFoundException null) {
      this.logger.verbose("Activity state file not found", new Object[0]);
      this.activityState = null;
      return;
    } catch (Exception exception1) {
      this.logger.error("Failed to open activity state file for reading (%s)", new Object[] { exception1 });
      this.activityState = null;
      return;
    } 
    exception1.close();
    throw exception2;
  }
  
  private void readOpenUrlInternal(Uri paramUri) {
    if (paramUri != null) {
      String str = paramUri.getQuery();
      if (str != null) {
        HashMap<Object, Object> hashMap = new HashMap<Object, Object>();
        String[] arrayOfString = str.split("&");
        int j = arrayOfString.length;
        for (int i = 0; i < j; i++) {
          String[] arrayOfString1 = arrayOfString[i].split("=");
          if (arrayOfString1.length == 2) {
            String str1 = arrayOfString1[0];
            if (str1.startsWith("adjust_")) {
              String str2 = arrayOfString1[1];
              if (str2.length() != 0) {
                str1 = str1.substring("adjust_".length());
                if (str1.length() != 0)
                  hashMap.put(str1, str2); 
              } 
            } 
          } 
        } 
        if (hashMap.size() != 0) {
          PackageBuilder packageBuilder = new PackageBuilder(this.context);
          packageBuilder.setDeepLinkParameters((Map)hashMap);
          injectGeneralAttributes(packageBuilder);
          ActivityPackage activityPackage = packageBuilder.buildReattributionPackage();
          this.packageHandler.addPackage(activityPackage);
          this.packageHandler.sendFirstPackage();
          this.logger.debug("Reattribution %s", new Object[] { hashMap.toString() });
          return;
        } 
      } 
    } 
  }
  
  private void runDelegateMain(ResponseData paramResponseData) {
    if (this.onFinishedListener != null && paramResponseData != null) {
      this.onFinishedListener.onFinishedTracking(paramResponseData);
      return;
    } 
  }
  
  private void setDefaultTracker(String paramString) {
    this.defaultTracker = paramString;
    if (this.defaultTracker != null)
      this.logger.info("Default tracker: '%s'", new Object[] { this.defaultTracker }); 
  }
  
  private void setDropOfflineActivities(boolean paramBoolean) {
    this.dropOfflineActivities = paramBoolean;
    if (this.dropOfflineActivities)
      this.logger.info("Offline activities will get dropped", new Object[0]); 
  }
  
  private void setEnvironment(String paramString) {
    this.environment = paramString;
    if (this.environment == null) {
      this.logger.Assert("Missing environment", new Object[0]);
      this.logger.setLogLevel(Logger.LogLevel.ASSERT);
      this.environment = "unknown";
      return;
    } 
    if ("sandbox".equalsIgnoreCase(this.environment)) {
      this.logger.Assert("SANDBOX: Adjust is running in Sandbox mode. Use this setting for testing. Don't forget to set the environment to `production` before publishing!", new Object[0]);
      return;
    } 
    if ("production".equalsIgnoreCase(this.environment)) {
      this.logger.Assert("PRODUCTION: Adjust is running in Production mode. Use this setting only for the build that you want to publish. Set the environment to `sandbox` if you want to test your app!", new Object[0]);
      this.logger.setLogLevel(Logger.LogLevel.ASSERT);
      return;
    } 
    this.logger.Assert("Malformed environment '%s'", new Object[] { this.environment });
    this.logger.setLogLevel(Logger.LogLevel.ASSERT);
    this.environment = "malformed";
  }
  
  private void setEventBuffering(boolean paramBoolean) {
    this.eventBuffering = paramBoolean;
    if (this.eventBuffering)
      this.logger.info("Event buffering is enabled", new Object[0]); 
  }
  
  private void startInternal() {
    if (checkAppTokenNotNull(this.appToken) && (this.activityState == null || this.activityState.enabled.booleanValue())) {
      this.packageHandler.resumeSending();
      startTimer();
      long l1 = System.currentTimeMillis();
      if (this.activityState == null) {
        this.activityState = new ActivityState();
        this.activityState.sessionCount = 1;
        this.activityState.createdAt = l1;
        transferSessionPackage();
        this.activityState.resetSessionAttributes(l1);
        this.activityState.enabled = Boolean.valueOf(this.enabled);
        writeActivityState();
        this.logger.info("First session", new Object[0]);
        return;
      } 
      long l2 = l1 - this.activityState.lastActivity;
      if (l2 < 0L) {
        this.logger.error("Time travel!", new Object[0]);
        this.activityState.lastActivity = l1;
        writeActivityState();
        return;
      } 
      if (l2 > SESSION_INTERVAL) {
        ActivityState activityState1 = this.activityState;
        activityState1.sessionCount++;
        this.activityState.createdAt = l1;
        this.activityState.lastInterval = l2;
        transferSessionPackage();
        this.activityState.resetSessionAttributes(l1);
        writeActivityState();
        this.logger.debug("Session %d", new Object[] { Integer.valueOf(this.activityState.sessionCount) });
        return;
      } 
      if (l2 > SUBSESSION_INTERVAL) {
        ActivityState activityState1 = this.activityState;
        activityState1.subsessionCount++;
        this.logger.info("Started subsession %d of session %d", new Object[] { Integer.valueOf(this.activityState.subsessionCount), Integer.valueOf(this.activityState.sessionCount) });
      } 
      ActivityState activityState = this.activityState;
      activityState.sessionLength += l2;
      this.activityState.lastActivity = l1;
      writeActivityState();
      return;
    } 
  }
  
  private void startTimer() {
    if (timer != null)
      stopTimer(); 
    timer = Executors.newSingleThreadScheduledExecutor();
    timer.scheduleWithFixedDelay(new Runnable() {
          public void run() {
            ActivityHandler.this.timerFired();
          }
        },  1000L, TIMER_INTERVAL, TimeUnit.MILLISECONDS);
  }
  
  private void stopTimer() {
    try {
      timer.shutdown();
      return;
    } catch (NullPointerException nullPointerException) {
      this.logger.error("No timer found", new Object[0]);
      return;
    } 
  }
  
  private void timerFired() {
    if (this.activityState != null && !this.activityState.enabled.booleanValue())
      return; 
    this.packageHandler.sendFirstPackage();
    updateActivityState(System.currentTimeMillis());
    writeActivityState();
  }
  
  private void trackEventInternal(PackageBuilder paramPackageBuilder) {
    if (canTrackEvent(paramPackageBuilder) && this.activityState.enabled.booleanValue()) {
      long l = System.currentTimeMillis();
      this.activityState.createdAt = l;
      ActivityState activityState = this.activityState;
      activityState.eventCount++;
      updateActivityState(l);
      injectGeneralAttributes(paramPackageBuilder);
      this.activityState.injectEventAttributes(paramPackageBuilder);
      ActivityPackage activityPackage = paramPackageBuilder.buildEventPackage();
      this.packageHandler.addPackage(activityPackage);
      if (this.eventBuffering) {
        this.logger.info("Buffered event %s", new Object[] { activityPackage.getSuffix() });
      } else {
        this.packageHandler.sendFirstPackage();
      } 
      writeActivityState();
      this.logger.debug("Event %d", new Object[] { Integer.valueOf(this.activityState.eventCount) });
      return;
    } 
  }
  
  private void trackRevenueInternal(PackageBuilder paramPackageBuilder) {
    if (canTrackRevenue(paramPackageBuilder) && this.activityState.enabled.booleanValue()) {
      long l = System.currentTimeMillis();
      this.activityState.createdAt = l;
      ActivityState activityState = this.activityState;
      activityState.eventCount++;
      updateActivityState(l);
      injectGeneralAttributes(paramPackageBuilder);
      this.activityState.injectEventAttributes(paramPackageBuilder);
      ActivityPackage activityPackage = paramPackageBuilder.buildRevenuePackage();
      this.packageHandler.addPackage(activityPackage);
      if (this.eventBuffering) {
        this.logger.info("Buffered revenue %s", new Object[] { activityPackage.getSuffix() });
      } else {
        this.packageHandler.sendFirstPackage();
      } 
      writeActivityState();
      this.logger.debug("Event %d (revenue)", new Object[] { Integer.valueOf(this.activityState.eventCount) });
      return;
    } 
  }
  
  private void transferSessionPackage() {
    PackageBuilder packageBuilder = new PackageBuilder(this.context);
    injectGeneralAttributes(packageBuilder);
    injectReferrer(packageBuilder);
    this.activityState.injectSessionAttributes(packageBuilder);
    ActivityPackage activityPackage = packageBuilder.buildSessionPackage();
    this.packageHandler.addPackage(activityPackage);
    this.packageHandler.sendFirstPackage();
  }
  
  private void updateActivityState(long paramLong) {
    if (checkActivityState(this.activityState)) {
      long l = paramLong - this.activityState.lastActivity;
      if (l < 0L) {
        this.logger.error("Time travel!", new Object[0]);
        this.activityState.lastActivity = paramLong;
        return;
      } 
      if (l <= SESSION_INTERVAL) {
        ActivityState activityState = this.activityState;
        activityState.sessionLength += l;
        activityState = this.activityState;
        activityState.timeSpent += l;
        this.activityState.lastActivity = paramLong;
        return;
      } 
    } 
  }
  
  private void writeActivityState() {
    Exception exception2;
    try {
      ObjectOutputStream objectOutputStream = new ObjectOutputStream(new BufferedOutputStream(this.context.openFileOutput("AdjustIoActivityState", 0)));
      try {
        objectOutputStream.writeObject(this.activityState);
        this.logger.debug("Wrote activity state: %s", new Object[] { this.activityState });
        objectOutputStream.close();
        return;
      } catch (NotSerializableException null) {
        this.logger.error("Failed to serialize activity state", new Object[0]);
        objectOutputStream.close();
        return;
      } finally {}
    } catch (Exception exception1) {
      this.logger.error("Failed to open activity state for writing (%s)", new Object[] { exception1 });
      return;
    } 
    exception1.close();
    throw exception2;
  }
  
  public void finishedTrackingActivity(final ResponseData responseData, final String deepLink) {
    if (this.onFinishedListener == null && deepLink == null)
      return; 
    (new Handler(this.context.getMainLooper())).post(new Runnable() {
          public void run() {
            try {
              ActivityHandler.this.runDelegateMain(responseData);
              ActivityHandler.this.launchDeepLinkMain(deepLink);
              return;
            } catch (NullPointerException nullPointerException) {
              return;
            } 
          }
        });
  }
  
  public Boolean isEnabled() {
    return checkActivityState(this.activityState) ? this.activityState.enabled : Boolean.valueOf(this.enabled);
  }
  
  public void readOpenUrl(Uri paramUri) {
    Message message = Message.obtain();
    message.arg1 = 72680;
    message.obj = paramUri;
    this.sessionHandler.sendMessage(message);
  }
  
  public void setEnabled(Boolean paramBoolean) {
    this.enabled = paramBoolean.booleanValue();
    if (checkActivityState(this.activityState))
      this.activityState.enabled = paramBoolean; 
    if (paramBoolean.booleanValue()) {
      trackSubsessionStart();
      return;
    } 
    trackSubsessionEnd();
  }
  
  public void setOnFinishedListener(OnFinishedListener paramOnFinishedListener) {
    this.onFinishedListener = paramOnFinishedListener;
  }
  
  public void setSdkPrefix(String paramString) {
    this.clientSdk = String.format("%s@%s", new Object[] { paramString, this.clientSdk });
  }
  
  public void trackEvent(String paramString, Map<String, String> paramMap) {
    PackageBuilder packageBuilder = new PackageBuilder(this.context);
    packageBuilder.setEventToken(paramString);
    packageBuilder.setCallbackParameters(paramMap);
    Message message = Message.obtain();
    message.arg1 = 72660;
    message.obj = packageBuilder;
    this.sessionHandler.sendMessage(message);
  }
  
  public void trackRevenue(double paramDouble, String paramString, Map<String, String> paramMap) {
    PackageBuilder packageBuilder = new PackageBuilder(this.context);
    packageBuilder.setAmountInCents(paramDouble);
    packageBuilder.setEventToken(paramString);
    packageBuilder.setCallbackParameters(paramMap);
    Message message = Message.obtain();
    message.arg1 = 72670;
    message.obj = packageBuilder;
    this.sessionHandler.sendMessage(message);
  }
  
  public void trackSubsessionEnd() {
    Message message = Message.obtain();
    message.arg1 = 72650;
    this.sessionHandler.sendMessage(message);
  }
  
  public void trackSubsessionStart() {
    Message message = Message.obtain();
    message.arg1 = 72640;
    this.sessionHandler.sendMessage(message);
  }
  
  private static final class SessionHandler extends Handler {
    private static final int DEEP_LINK = 72680;
    
    private static final int END = 72650;
    
    private static final int EVENT = 72660;
    
    private static final int INIT_BUNDLE = 72630;
    
    private static final int INIT_PRESET = 72633;
    
    private static final int REVENUE = 72670;
    
    private static final int START = 72640;
    
    private final WeakReference<ActivityHandler> sessionHandlerReference;
    
    protected SessionHandler(Looper param1Looper, ActivityHandler param1ActivityHandler) {
      super(param1Looper);
      this.sessionHandlerReference = new WeakReference<ActivityHandler>(param1ActivityHandler);
    }
    
    public void handleMessage(Message param1Message) {
      super.handleMessage(param1Message);
      ActivityHandler activityHandler = this.sessionHandlerReference.get();
      if (activityHandler == null)
        return; 
      switch (param1Message.arg1) {
        default:
          return;
        case 72630:
          activityHandler.initInternal(true, (String)null);
          return;
        case 72633:
          activityHandler.initInternal(false, (String)param1Message.obj);
          return;
        case 72640:
          activityHandler.startInternal();
          return;
        case 72650:
          activityHandler.endInternal();
          return;
        case 72660:
          activityHandler.trackEventInternal((PackageBuilder)param1Message.obj);
          return;
        case 72670:
          activityHandler.trackRevenueInternal((PackageBuilder)param1Message.obj);
          return;
        case 72680:
          break;
      } 
      activityHandler.readOpenUrlInternal((Uri)param1Message.obj);
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Smash Cricket-dex2jar.jar!\com\adjust\sdk\ActivityHandler.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */