package com.adjust.sdk;

import android.os.Handler;
import android.os.HandlerThread;
import android.os.Looper;
import android.os.Message;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.UnsupportedEncodingException;
import java.lang.ref.WeakReference;
import java.net.SocketTimeoutException;
import java.util.ArrayList;
import java.util.Locale;
import java.util.Map;
import org.apache.http.HttpEntity;
import org.apache.http.HttpResponse;
import org.apache.http.client.ClientProtocolException;
import org.apache.http.client.HttpClient;
import org.apache.http.client.entity.UrlEncodedFormEntity;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.client.methods.HttpUriRequest;
import org.apache.http.message.BasicNameValuePair;
import org.apache.http.params.BasicHttpParams;
import org.apache.http.params.HttpConnectionParams;
import org.apache.http.params.HttpParams;
import org.json.JSONObject;

public class RequestHandler extends HandlerThread implements IRequestHandler {
  private static final int CONNECTION_TIMEOUT = 60000;
  
  private static final int SOCKET_TIMEOUT = 60000;
  
  private HttpClient httpClient;
  
  private InternalHandler internalHandler;
  
  private Logger logger;
  
  private IPackageHandler packageHandler;
  
  public RequestHandler(IPackageHandler paramIPackageHandler) {
    super("Adjust", 1);
    setDaemon(true);
    start();
    this.logger = AdjustFactory.getLogger();
    this.internalHandler = new InternalHandler(getLooper(), this);
    this.packageHandler = paramIPackageHandler;
    Message message = Message.obtain();
    message.arg1 = 72401;
    this.internalHandler.sendMessage(message);
  }
  
  private void closePackage(ActivityPackage paramActivityPackage, String paramString, Throwable paramThrowable) {
    boolean bool = true;
    String str1 = paramActivityPackage.getFailureMessage();
    String str2 = this.packageHandler.getFailureMessage();
    paramString = getReasonString(paramString, paramThrowable);
    this.logger.error("%s. (%s) %s", new Object[] { str1, paramString, str2 });
    ResponseData responseData = ResponseData.fromError(paramString);
    if (this.packageHandler.dropsOfflineActivities())
      bool = false; 
    responseData.setWillRetry(bool);
    this.packageHandler.finishedTrackingActivity(paramActivityPackage, responseData, null);
    this.packageHandler.closeFirstPackage();
  }
  
  private String getReasonString(String paramString, Throwable paramThrowable) {
    return (paramThrowable != null) ? String.format("%s: %s", new Object[] { paramString, paramThrowable }) : String.format("%s", new Object[] { paramString });
  }
  
  private HttpUriRequest getRequest(ActivityPackage paramActivityPackage) throws UnsupportedEncodingException {
    HttpPost httpPost = new HttpPost("https://app.adjust.io" + paramActivityPackage.getPath());
    String str = Locale.getDefault().getLanguage();
    httpPost.addHeader("User-Agent", paramActivityPackage.getUserAgent());
    httpPost.addHeader("Client-SDK", paramActivityPackage.getClientSdk());
    httpPost.addHeader("Accept-Language", str);
    ArrayList<BasicNameValuePair> arrayList = new ArrayList();
    for (Map.Entry<String, String> entry : paramActivityPackage.getParameters().entrySet())
      arrayList.add(new BasicNameValuePair((String)entry.getKey(), (String)entry.getValue())); 
    arrayList.add(new BasicNameValuePair("sent_at", Util.dateFormat(System.currentTimeMillis())));
    UrlEncodedFormEntity urlEncodedFormEntity = new UrlEncodedFormEntity(arrayList);
    urlEncodedFormEntity.setContentType("application/x-www-form-urlencoded");
    httpPost.setEntity((HttpEntity)urlEncodedFormEntity);
    return (HttpUriRequest)httpPost;
  }
  
  private void initInternal() {
    BasicHttpParams basicHttpParams = new BasicHttpParams();
    HttpConnectionParams.setConnectionTimeout((HttpParams)basicHttpParams, 60000);
    HttpConnectionParams.setSoTimeout((HttpParams)basicHttpParams, 60000);
    this.httpClient = AdjustFactory.getHttpClient((HttpParams)basicHttpParams);
  }
  
  private String parseResponse(HttpResponse paramHttpResponse) {
    try {
      ByteArrayOutputStream byteArrayOutputStream = new ByteArrayOutputStream();
      paramHttpResponse.getEntity().writeTo(byteArrayOutputStream);
      byteArrayOutputStream.close();
      return byteArrayOutputStream.toString().trim();
    } catch (Exception exception) {
      this.logger.error("Failed to parse response (%s)", new Object[] { exception });
      return "Failed to parse response";
    } 
  }
  
  private void requestFinished(HttpResponse paramHttpResponse, ActivityPackage paramActivityPackage) {
    int i = paramHttpResponse.getStatusLine().getStatusCode();
    String str = parseResponse(paramHttpResponse);
    JSONObject jSONObject = Util.buildJsonObject(str);
    ResponseData responseData = ResponseData.fromJson(jSONObject, str);
    if (200 == i) {
      responseData.setWasSuccess(true);
      this.logger.info(paramActivityPackage.getSuccessMessage(), new Object[0]);
    } else {
      this.logger.error("%s. (%s)", new Object[] { paramActivityPackage.getFailureMessage(), responseData.getError() });
    } 
    this.packageHandler.finishedTrackingActivity(paramActivityPackage, responseData, jSONObject);
    this.packageHandler.sendNextPackage();
  }
  
  private void sendInternal(ActivityPackage paramActivityPackage) {
    try {
      HttpUriRequest httpUriRequest = getRequest(paramActivityPackage);
      requestFinished(this.httpClient.execute(httpUriRequest), paramActivityPackage);
      return;
    } catch (UnsupportedEncodingException unsupportedEncodingException) {
      sendNextPackage(paramActivityPackage, "Failed to encode parameters", unsupportedEncodingException);
      return;
    } catch (ClientProtocolException clientProtocolException) {
      closePackage(paramActivityPackage, "Client protocol error", (Throwable)clientProtocolException);
      return;
    } catch (SocketTimeoutException socketTimeoutException) {
      closePackage(paramActivityPackage, "Request timed out", socketTimeoutException);
      return;
    } catch (IOException iOException) {
      closePackage(paramActivityPackage, "Request failed", iOException);
      return;
    } catch (Throwable throwable) {
      sendNextPackage(paramActivityPackage, "Runtime exception", throwable);
      return;
    } 
  }
  
  private void sendNextPackage(ActivityPackage paramActivityPackage, String paramString, Throwable paramThrowable) {
    String str = paramActivityPackage.getFailureMessage();
    paramString = getReasonString(paramString, paramThrowable);
    this.logger.error("%s. (%s)", new Object[] { str, paramString });
    ResponseData responseData = ResponseData.fromError(paramString);
    this.packageHandler.finishedTrackingActivity(paramActivityPackage, responseData, null);
    this.packageHandler.sendNextPackage();
  }
  
  public void sendPackage(ActivityPackage paramActivityPackage) {
    Message message = Message.obtain();
    message.arg1 = 72400;
    message.obj = paramActivityPackage;
    this.internalHandler.sendMessage(message);
  }
  
  private static final class InternalHandler extends Handler {
    private static final int INIT = 72401;
    
    private static final int SEND = 72400;
    
    private final WeakReference<RequestHandler> requestHandlerReference;
    
    protected InternalHandler(Looper param1Looper, RequestHandler param1RequestHandler) {
      super(param1Looper);
      this.requestHandlerReference = new WeakReference<RequestHandler>(param1RequestHandler);
    }
    
    public void handleMessage(Message param1Message) {
      super.handleMessage(param1Message);
      RequestHandler requestHandler = this.requestHandlerReference.get();
      if (requestHandler == null)
        return; 
      switch (param1Message.arg1) {
        default:
          return;
        case 72400:
          requestHandler.sendInternal((ActivityPackage)param1Message.obj);
          return;
        case 72401:
          break;
      } 
      requestHandler.initInternal();
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Smash Cricket-dex2jar.jar!\com\adjust\sdk\RequestHandler.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */