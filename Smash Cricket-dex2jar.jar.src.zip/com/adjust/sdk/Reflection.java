package com.adjust.sdk;

import android.content.Context;

public class Reflection {
  public static Object createDefaultInstance(Class<Class<?>> paramClass) {
    try {
      return paramClass.newInstance();
    } catch (Throwable throwable) {
      return null;
    } 
  }
  
  public static Object createDefaultInstance(String paramString) {
    return createDefaultInstance(forName(paramString));
  }
  
  public static Object createInstance(String paramString, Class[] paramArrayOfClass, Object... paramVarArgs) {
    try {
      return Class.forName(paramString).getConstructor(paramArrayOfClass).newInstance(paramVarArgs);
    } catch (Throwable throwable) {
      return null;
    } 
  }
  
  public static Class forName(String paramString) {
    try {
      return Class.forName(paramString);
    } catch (Throwable throwable) {
      return null;
    } 
  }
  
  private static Object getAdvertisingInfoObject(Context paramContext) throws Exception {
    return invokeStaticMethod("com.google.android.gms.ads.identifier.AdvertisingIdClient", "getAdvertisingIdInfo", new Class[] { Context.class }, new Object[] { paramContext });
  }
  
  public static String getAndroidId(Context paramContext) {
    try {
      return (String)invokeStaticMethod("com.adjust.sdk.plugin.AndroidIdUtil", "getAndroidId", new Class[] { Context.class }, new Object[] { paramContext });
    } catch (Throwable throwable) {
      return null;
    } 
  }
  
  public static String getMacAddress(Context paramContext) {
    try {
      return (String)invokeStaticMethod("com.adjust.sdk.plugin.MacAddressUtil", "getMacAddress", new Class[] { Context.class }, new Object[] { paramContext });
    } catch (Throwable throwable) {
      return null;
    } 
  }
  
  public static String getPlayAdId(Context paramContext) {
    try {
      return (String)invokeInstanceMethod(getAdvertisingInfoObject(paramContext), "getId", null, new Object[0]);
    } catch (Throwable throwable) {
      return null;
    } 
  }
  
  public static String getSha1EmailAddress(Context paramContext, String paramString) {
    try {
      return (String)invokeStaticMethod("com.adjust.sdk.plugin.EmailUtil", "getSha1EmailAddress", new Class[] { Context.class, String.class }, new Object[] { paramContext, paramString });
    } catch (Throwable throwable) {
      return null;
    } 
  }
  
  public static Object invokeInstanceMethod(Object paramObject, String paramString, Class[] paramArrayOfClass, Object... paramVarArgs) throws Exception {
    return invokeMethod(paramObject.getClass(), paramString, paramObject, paramArrayOfClass, paramVarArgs);
  }
  
  public static Object invokeMethod(Class paramClass, String paramString, Object paramObject, Class[] paramArrayOfClass, Object... paramVarArgs) throws Exception {
    return paramClass.getMethod(paramString, paramArrayOfClass).invoke(paramObject, paramVarArgs);
  }
  
  public static Object invokeStaticMethod(String paramString1, String paramString2, Class[] paramArrayOfClass, Object... paramVarArgs) throws Exception {
    return invokeMethod(Class.forName(paramString1), paramString2, null, paramArrayOfClass, paramVarArgs);
  }
  
  private static boolean isConnectionResultSuccess(Integer paramInteger) {
    if (paramInteger != null)
      try {
        int i = Class.forName("com.google.android.gms.common.ConnectionResult").getField("SUCCESS").getInt(null);
        int j = paramInteger.intValue();
        return (i == j);
      } catch (Throwable throwable) {
        return false;
      }  
    return false;
  }
  
  public static boolean isGooglePlayServicesAvailable(Context paramContext) {
    try {
      return Boolean.valueOf(isConnectionResultSuccess((Integer)invokeStaticMethod("com.google.android.gms.common.GooglePlayServicesUtil", "isGooglePlayServicesAvailable", new Class[] { Context.class }, new Object[] { paramContext }))).booleanValue();
    } catch (Throwable throwable) {
      return false;
    } 
  }
  
  public static boolean isPlayTrackingEnabled(Context paramContext) {
    boolean bool = false;
    try {
      boolean bool1 = ((Boolean)invokeInstanceMethod(getAdvertisingInfoObject(paramContext), "isLimitAdTrackingEnabled", null, new Object[0])).booleanValue();
      if (!bool1)
        bool = true; 
      return bool;
    } catch (Throwable throwable) {
      return false;
    } 
  }
}


/* Location:              C:\soft\dex2jar-2.0\Smash Cricket-dex2jar.jar!\com\adjust\sdk\Reflection.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */