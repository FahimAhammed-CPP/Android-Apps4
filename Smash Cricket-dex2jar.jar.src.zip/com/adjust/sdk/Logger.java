package com.adjust.sdk;

public interface Logger {
  void Assert(String paramString, Object... paramVarArgs);
  
  void debug(String paramString, Object... paramVarArgs);
  
  void error(String paramString, Object... paramVarArgs);
  
  void info(String paramString, Object... paramVarArgs);
  
  void setLogLevel(LogLevel paramLogLevel);
  
  void setLogLevelString(String paramString);
  
  void verbose(String paramString, Object... paramVarArgs);
  
  void warn(String paramString, Object... paramVarArgs);
  
  public enum LogLevel {
    ASSERT,
    DEBUG,
    ERROR,
    INFO,
    VERBOSE(2),
    WARN(2);
    
    final int androidLogLevel;
    
    static {
      ERROR = new LogLevel("ERROR", 4, 6);
      ASSERT = new LogLevel("ASSERT", 5, 7);
      $VALUES = new LogLevel[] { VERBOSE, DEBUG, INFO, WARN, ERROR, ASSERT };
    }
    
    LogLevel(int param1Int1) {
      this.androidLogLevel = param1Int1;
    }
    
    public int getAndroidLogLevel() {
      return this.androidLogLevel;
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Smash Cricket-dex2jar.jar!\com\adjust\sdk\Logger.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */