package com.adjust.sdk;

import android.content.Context;
import android.content.pm.PackageManager;
import android.content.res.Configuration;
import android.content.res.Resources;
import android.database.Cursor;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.text.TextUtils;
import android.util.DisplayMetrics;
import com.adjust.sdk.plugin.Plugin;
import java.math.BigInteger;
import java.security.MessageDigest;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.UUID;
import java.util.regex.Pattern;
import org.json.JSONException;
import org.json.JSONObject;

public class Util {
  private static final String DATE_FORMAT = "yyyy-MM-dd'T'HH:mm:ss'Z'Z";
  
  private static SimpleDateFormat dateFormat;
  
  public static JSONObject buildJsonObject(String paramString) {
    try {
      return new JSONObject(paramString);
    } catch (JSONException jSONException) {
      return null;
    } 
  }
  
  private static String convertToHex(byte[] paramArrayOfbyte) {
    BigInteger bigInteger = new BigInteger(1, paramArrayOfbyte);
    return String.format("%0" + (paramArrayOfbyte.length << 1) + "x", new Object[] { bigInteger });
  }
  
  protected static String createUuid() {
    return UUID.randomUUID().toString();
  }
  
  public static String dateFormat(long paramLong) {
    if (dateFormat == null)
      dateFormat = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss'Z'Z", Locale.US); 
    return dateFormat.format(Long.valueOf(paramLong));
  }
  
  public static String getAndroidId(Context paramContext) {
    return Reflection.getAndroidId(paramContext);
  }
  
  private static String getAppVersion(Context paramContext) {
    try {
      return sanitizeString((paramContext.getPackageManager().getPackageInfo(paramContext.getPackageName(), 0)).versionName);
    } catch (android.content.pm.PackageManager.NameNotFoundException nameNotFoundException) {
      return "unknown";
    } 
  }
  
  public static Bundle getApplicationBundle(Context paramContext, Logger paramLogger) {
    try {
      String str = paramContext.getPackageName();
      return (paramContext.getPackageManager().getApplicationInfo(str, 128)).metaData;
    } catch (android.content.pm.PackageManager.NameNotFoundException nameNotFoundException) {
      paramLogger.error("ApplicationInfo not found", new Object[0]);
    } catch (Exception exception) {
      paramLogger.error("Failed to get ApplicationBundle (%s)", new Object[] { exception });
    } 
    return null;
  }
  
  protected static String getAttributionId(Context paramContext) {
    try {
      Cursor cursor = paramContext.getContentResolver().query(Uri.parse("content://com.facebook.katana.provider.AttributionIdProvider"), new String[] { "aid" }, null, null, null);
      if (cursor == null)
        return null; 
      if (!cursor.moveToFirst()) {
        cursor.close();
        return null;
      } 
      String str = cursor.getString(cursor.getColumnIndex("aid"));
      cursor.close();
      return str;
    } catch (Exception exception) {
      return null;
    } 
  }
  
  private static String getCountry(Locale paramLocale) {
    return sanitizeStringShort(paramLocale.getCountry());
  }
  
  private static String getDeviceName() {
    return sanitizeString(Build.MODEL);
  }
  
  private static String getDeviceType(int paramInt) {
    switch (paramInt & 0xF) {
      default:
        return "unknown";
      case 1:
      case 2:
        return "phone";
      case 3:
      case 4:
        break;
    } 
    return "tablet";
  }
  
  private static String getDisplayHeight(DisplayMetrics paramDisplayMetrics) {
    return sanitizeString(String.valueOf(paramDisplayMetrics.heightPixels));
  }
  
  private static String getDisplayWidth(DisplayMetrics paramDisplayMetrics) {
    return sanitizeString(String.valueOf(paramDisplayMetrics.widthPixels));
  }
  
  private static String getLanguage(Locale paramLocale) {
    return sanitizeStringShort(paramLocale.getLanguage());
  }
  
  public static String getMacAddress(Context paramContext) {
    return Reflection.getMacAddress(paramContext);
  }
  
  public static String getMacSha1(String paramString) {
    return (paramString == null) ? null : sha1(paramString);
  }
  
  public static String getMacShortMd5(String paramString) {
    return (paramString == null) ? null : md5(paramString.replaceAll(":", ""));
  }
  
  private static String getOsName() {
    return "android";
  }
  
  private static String getOsVersion() {
    return sanitizeString("" + Build.VERSION.SDK_INT);
  }
  
  private static String getPackageName(Context paramContext) {
    return sanitizeString(paramContext.getPackageName());
  }
  
  public static String getPlayAdId(Context paramContext) {
    return Reflection.getPlayAdId(paramContext);
  }
  
  public static Map<String, String> getPluginKeys(Context paramContext) {
    HashMap<Object, Object> hashMap2 = new HashMap<Object, Object>();
    Iterator<Plugin> iterator = getPlugins().iterator();
    while (iterator.hasNext()) {
      Map.Entry entry = ((Plugin)iterator.next()).getParameter(paramContext);
      if (entry != null)
        hashMap2.put(entry.getKey(), entry.getValue()); 
    } 
    HashMap<Object, Object> hashMap1 = hashMap2;
    if (hashMap2.size() == 0)
      hashMap1 = null; 
    return (Map)hashMap1;
  }
  
  private static List<Plugin> getPlugins() {
    ArrayList<Plugin> arrayList = new ArrayList(Constants.PLUGINS.size());
    Iterator<String> iterator = Constants.PLUGINS.iterator();
    while (iterator.hasNext()) {
      Object object = Reflection.createDefaultInstance(iterator.next());
      if (object != null && object instanceof Plugin)
        arrayList.add((Plugin)object); 
    } 
    return arrayList;
  }
  
  private static String getScreenDensity(DisplayMetrics paramDisplayMetrics) {
    int i = paramDisplayMetrics.densityDpi;
    return (i == 0) ? "unknown" : ((i < 140) ? "low" : ((i > 200) ? "high" : "medium"));
  }
  
  private static String getScreenFormat(int paramInt) {
    switch (paramInt & 0x30) {
      default:
        return "unknown";
      case 32:
        return "long";
      case 16:
        break;
    } 
    return "normal";
  }
  
  private static String getScreenSize(int paramInt) {
    switch (paramInt & 0xF) {
      default:
        return "unknown";
      case 1:
        return "small";
      case 2:
        return "normal";
      case 3:
        return "large";
      case 4:
        break;
    } 
    return "xlarge";
  }
  
  protected static String getUserAgent(Context paramContext) {
    Resources resources = paramContext.getResources();
    DisplayMetrics displayMetrics = resources.getDisplayMetrics();
    Configuration configuration = resources.getConfiguration();
    Locale locale = configuration.locale;
    int i = configuration.screenLayout;
    return TextUtils.join(" ", (Object[])new String[] { 
          getPackageName(paramContext), getAppVersion(paramContext), getDeviceType(i), getDeviceName(), getOsName(), getOsVersion(), getLanguage(locale), getCountry(locale), getScreenSize(i), getScreenFormat(i), 
          getScreenDensity(displayMetrics), getDisplayWidth(displayMetrics), getDisplayHeight(displayMetrics) });
  }
  
  private static String hash(String paramString1, String paramString2) {
    try {
      byte[] arrayOfByte = paramString1.getBytes("UTF-8");
      MessageDigest messageDigest = MessageDigest.getInstance(paramString2);
      messageDigest.update(arrayOfByte, 0, arrayOfByte.length);
      return convertToHex(messageDigest.digest());
    } catch (Exception exception) {
      return null;
    } 
  }
  
  public static boolean isGooglePlayServicesAvailable(Context paramContext) {
    return Reflection.isGooglePlayServicesAvailable(paramContext);
  }
  
  public static Boolean isPlayTrackingEnabled(Context paramContext) {
    return Boolean.valueOf(Reflection.isPlayTrackingEnabled(paramContext));
  }
  
  private static String md5(String paramString) {
    return hash(paramString, "MD5");
  }
  
  public static String quote(String paramString) {
    if (paramString == null)
      return null; 
    String str = paramString;
    return Pattern.compile("\\s").matcher(paramString).find() ? String.format("'%s'", new Object[] { paramString }) : str;
  }
  
  private static String sanitizeString(String paramString) {
    return sanitizeString(paramString, "unknown");
  }
  
  private static String sanitizeString(String paramString1, String paramString2) {
    String str = paramString1;
    if (TextUtils.isEmpty(paramString1))
      str = paramString2; 
    str = str.replaceAll("\\s", "");
    paramString1 = str;
    if (TextUtils.isEmpty(str))
      paramString1 = paramString2; 
    return paramString1;
  }
  
  private static String sanitizeStringShort(String paramString) {
    return sanitizeString(paramString, "zz");
  }
  
  public static String sha1(String paramString) {
    return hash(paramString, "SHA-1");
  }
}


/* Location:              C:\soft\dex2jar-2.0\Smash Cricket-dex2jar.jar!\com\adjust\sdk\Util.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */