package com.adjust.sdk;

import org.json.JSONObject;

public interface IPackageHandler {
  void addPackage(ActivityPackage paramActivityPackage);
  
  void closeFirstPackage();
  
  boolean dropsOfflineActivities();
  
  void finishedTrackingActivity(ActivityPackage paramActivityPackage, ResponseData paramResponseData, JSONObject paramJSONObject);
  
  String getFailureMessage();
  
  void pauseSending();
  
  void resumeSending();
  
  void sendFirstPackage();
  
  void sendNextPackage();
}


/* Location:              C:\soft\dex2jar-2.0\Smash Cricket-dex2jar.jar!\com\adjust\sdk\IPackageHandler.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */