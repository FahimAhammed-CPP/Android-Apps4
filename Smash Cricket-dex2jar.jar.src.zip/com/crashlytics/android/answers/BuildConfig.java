package com.crashlytics.android.answers;

public final class BuildConfig {
  public static final String APPLICATION_ID = "com.crashlytics.android.answers";
  
  public static final String ARTIFACT_ID = "answers";
  
  public static final String BUILD_NUMBER = "42";
  
  public static final String BUILD_TYPE = "release";
  
  public static final boolean DEBUG = false;
  
  public static final String FLAVOR = "";
  
  public static final String GROUP = "com.crashlytics.sdk.android";
  
  public static final int VERSION_CODE = 1;
  
  public static final String VERSION_NAME = "1.2.0";
}


/* Location:              C:\soft\dex2jar-2.0\Smash Cricket-dex2jar.jar!\com\crashlytics\android\answers\BuildConfig.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */