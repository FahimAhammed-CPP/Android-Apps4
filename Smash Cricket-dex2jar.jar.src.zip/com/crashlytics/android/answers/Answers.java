package com.crashlytics.android.answers;

import android.annotation.SuppressLint;
import android.annotation.TargetApi;
import android.app.Application;
import android.content.Context;
import android.content.pm.PackageInfo;
import android.os.Build;
import io.fabric.sdk.android.Fabric;
import io.fabric.sdk.android.Kit;
import io.fabric.sdk.android.services.common.CommonUtils;
import io.fabric.sdk.android.services.common.Crash;
import io.fabric.sdk.android.services.common.CurrentTimeProvider;
import io.fabric.sdk.android.services.common.IdManager;
import io.fabric.sdk.android.services.common.SystemCurrentTimeProvider;
import io.fabric.sdk.android.services.events.EventsStorage;
import io.fabric.sdk.android.services.events.GZIPQueueFileEventStorage;
import io.fabric.sdk.android.services.network.DefaultHttpRequestFactory;
import io.fabric.sdk.android.services.network.HttpRequestFactory;
import io.fabric.sdk.android.services.persistence.FileStoreImpl;
import io.fabric.sdk.android.services.persistence.PreferenceStore;
import io.fabric.sdk.android.services.persistence.PreferenceStoreImpl;
import io.fabric.sdk.android.services.settings.Settings;
import io.fabric.sdk.android.services.settings.SettingsData;
import java.io.File;
import java.util.Map;
import java.util.UUID;

public class Answers extends Kit<Boolean> {
  static final String CRASHLYTICS_API_ENDPOINT = "com.crashlytics.ApiEndpoint";
  
  static final long FIRST_LAUNCH_INTERVAL_IN_MS = 3600000L;
  
  static final String PREFKEY_ANALYTICS_LAUNCHED = "analytics_launched";
  
  static final String SESSION_ANALYTICS_FILE_EXTENSION = ".tap";
  
  static final String SESSION_ANALYTICS_FILE_NAME = "session_analytics.tap";
  
  private static final String SESSION_ANALYTICS_TO_SEND_DIR = "session_analytics_to_send";
  
  public static final String TAG = "Answers";
  
  private long installedAt;
  
  private PreferenceStore preferenceStore;
  
  SessionAnalyticsManager sessionAnalyticsManager;
  
  private String versionCode;
  
  private String versionName;
  
  public static Answers getInstance() {
    return (Answers)Fabric.getKit(Answers.class);
  }
  
  @SuppressLint({"CommitPrefEdits"})
  @TargetApi(14)
  private void initializeSessionAnalytics(Context paramContext) {
    try {
      SessionAnalyticsFilesManager sessionAnalyticsFilesManager = new SessionAnalyticsFilesManager(paramContext, new SessionEventTransform(), (CurrentTimeProvider)new SystemCurrentTimeProvider(), (EventsStorage)new GZIPQueueFileEventStorage(getContext(), getSdkDirectory(), "session_analytics.tap", "session_analytics_to_send"));
      IdManager idManager = getIdManager();
      Map map = idManager.getDeviceIdentifiers();
      String str1 = paramContext.getPackageName();
      String str2 = idManager.getAppInstallIdentifier();
      String str3 = (String)map.get(IdManager.DeviceIdentifierType.ANDROID_ID);
      String str4 = (String)map.get(IdManager.DeviceIdentifierType.ANDROID_ADVERTISING_ID);
      String str6 = (String)map.get(IdManager.DeviceIdentifierType.FONT_TOKEN);
      String str7 = CommonUtils.resolveBuildId(paramContext);
      String str8 = idManager.getOsVersionString();
      String str5 = idManager.getModelName();
      SessionEventMetadata sessionEventMetadata = new SessionEventMetadata(str1, UUID.randomUUID().toString(), str2, str3, str4, str6, str7, str8, str5, this.versionCode, this.versionName);
      Application application = (Application)getContext().getApplicationContext();
      if (application != null && Build.VERSION.SDK_INT >= 14) {
        this.sessionAnalyticsManager = AutoSessionAnalyticsManager.build(application, sessionEventMetadata, sessionAnalyticsFilesManager, (HttpRequestFactory)new DefaultHttpRequestFactory(Fabric.getLogger()));
      } else {
        this.sessionAnalyticsManager = SessionAnalyticsManager.build(paramContext, sessionEventMetadata, sessionAnalyticsFilesManager, (HttpRequestFactory)new DefaultHttpRequestFactory(Fabric.getLogger()));
      } 
      if (isFirstLaunch(this.installedAt)) {
        Fabric.getLogger().d("Answers", "First launch");
        this.sessionAnalyticsManager.onInstall();
        this.preferenceStore.save(this.preferenceStore.edit().putBoolean("analytics_launched", true));
        return;
      } 
    } catch (Exception exception) {
      CommonUtils.logControlledError(paramContext, "Crashlytics failed to initialize session analytics.", exception);
    } 
  }
  
  protected Boolean doInBackground() {
    Context context = getContext();
    initializeSessionAnalytics(context);
    try {
      SettingsData settingsData = Settings.getInstance().awaitSettingsData();
      if (settingsData == null)
        return Boolean.valueOf(false); 
      if (settingsData.featuresData.collectAnalytics) {
        this.sessionAnalyticsManager.setAnalyticsSettingsData(settingsData.analyticsSettingsData, getOverridenSpiEndpoint());
        return Boolean.valueOf(true);
      } 
      CommonUtils.logControlled(context, "Disabling analytics collection based on settings flag value.");
      this.sessionAnalyticsManager.disable();
      return Boolean.valueOf(false);
    } catch (Exception exception) {
      Fabric.getLogger().e("Answers", "Error dealing with settings", exception);
      return Boolean.valueOf(false);
    } 
  }
  
  boolean getAnalyticsLaunched() {
    return this.preferenceStore.get().getBoolean("analytics_launched", false);
  }
  
  public String getIdentifier() {
    return "com.crashlytics.sdk.android:answers";
  }
  
  String getOverridenSpiEndpoint() {
    return CommonUtils.getStringsFileValue(getContext(), "com.crashlytics.ApiEndpoint");
  }
  
  File getSdkDirectory() {
    return (new FileStoreImpl(this)).getFilesDir();
  }
  
  public String getVersion() {
    return "1.2.0.42";
  }
  
  boolean installedRecently(long paramLong) {
    return (System.currentTimeMillis() - paramLong < 3600000L);
  }
  
  boolean isFirstLaunch(long paramLong) {
    return (!getAnalyticsLaunched() && installedRecently(paramLong));
  }
  
  public void logEvent(String paramString) {
    logEvent(paramString, new EventAttributes());
  }
  
  public void logEvent(String paramString, EventAttributes paramEventAttributes) {
    if (paramString == null)
      throw new NullPointerException("eventName must not be null"); 
    if (paramEventAttributes == null)
      throw new NullPointerException("attributes must not be null"); 
    if (this.sessionAnalyticsManager != null)
      this.sessionAnalyticsManager.onCustom(paramString, paramEventAttributes.attributes); 
  }
  
  public void onException(Crash.FatalException paramFatalException) {
    if (this.sessionAnalyticsManager != null)
      this.sessionAnalyticsManager.onCrash(paramFatalException.getSessionId()); 
  }
  
  public void onException(Crash.LoggedException paramLoggedException) {
    if (this.sessionAnalyticsManager != null)
      this.sessionAnalyticsManager.onError(paramLoggedException.getSessionId()); 
  }
  
  @SuppressLint({"NewApi"})
  protected boolean onPreExecute() {
    try {
      String str;
      this.preferenceStore = (PreferenceStore)new PreferenceStoreImpl(this);
      Context context = getContext();
      PackageInfo packageInfo = context.getPackageManager().getPackageInfo(context.getPackageName(), 0);
      this.versionCode = Integer.toString(packageInfo.versionCode);
      if (packageInfo.versionName == null) {
        str = "0.0";
      } else {
        str = packageInfo.versionName;
      } 
      this.versionName = str;
      if (Build.VERSION.SDK_INT >= 9) {
        this.installedAt = packageInfo.firstInstallTime;
      } else {
        this.installedAt = (new File((context.getPackageManager().getApplicationInfo(context.getPackageName(), 0)).sourceDir)).lastModified();
      } 
    } catch (Exception exception) {
      Fabric.getLogger().e("Answers", "Error setting up app properties", exception);
      return false;
    } 
    return true;
  }
}


/* Location:              C:\soft\dex2jar-2.0\Smash Cricket-dex2jar.jar!\com\crashlytics\android\answers\Answers.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */