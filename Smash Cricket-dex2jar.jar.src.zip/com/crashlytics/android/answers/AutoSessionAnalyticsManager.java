package com.crashlytics.android.answers;

import android.annotation.TargetApi;
import android.app.Activity;
import android.app.Application;
import android.content.Context;
import android.os.Bundle;
import io.fabric.sdk.android.services.common.CommonUtils;
import io.fabric.sdk.android.services.common.ExecutorUtils;
import io.fabric.sdk.android.services.network.HttpRequestFactory;
import java.util.concurrent.ScheduledExecutorService;

@TargetApi(14)
class AutoSessionAnalyticsManager extends SessionAnalyticsManager {
  private static final String EXECUTOR_SERVICE = "Crashlytics Trace Manager";
  
  private final Application.ActivityLifecycleCallbacks activityLifecycleCallbacks = new Application.ActivityLifecycleCallbacks() {
      public void onActivityCreated(Activity param1Activity, Bundle param1Bundle) {
        AutoSessionAnalyticsManager.this.onCreate(param1Activity);
      }
      
      public void onActivityDestroyed(Activity param1Activity) {
        AutoSessionAnalyticsManager.this.onDestroy(param1Activity);
      }
      
      public void onActivityPaused(Activity param1Activity) {
        AutoSessionAnalyticsManager.this.onPause(param1Activity);
      }
      
      public void onActivityResumed(Activity param1Activity) {
        AutoSessionAnalyticsManager.this.onResume(param1Activity);
      }
      
      public void onActivitySaveInstanceState(Activity param1Activity, Bundle param1Bundle) {
        AutoSessionAnalyticsManager.this.onSaveInstanceState(param1Activity);
      }
      
      public void onActivityStarted(Activity param1Activity) {
        AutoSessionAnalyticsManager.this.onStart(param1Activity);
      }
      
      public void onActivityStopped(Activity param1Activity) {
        AutoSessionAnalyticsManager.this.onStop(param1Activity);
      }
    };
  
  private final Application application;
  
  AutoSessionAnalyticsManager(SessionEventMetadata paramSessionEventMetadata, SessionEventsHandler paramSessionEventsHandler, Application paramApplication) {
    super(paramSessionEventMetadata, paramSessionEventsHandler);
    this.application = paramApplication;
    CommonUtils.logControlled(Answers.getInstance().getContext(), "Registering activity lifecycle callbacks for session analytics.");
    paramApplication.registerActivityLifecycleCallbacks(this.activityLifecycleCallbacks);
  }
  
  public static AutoSessionAnalyticsManager build(Application paramApplication, SessionEventMetadata paramSessionEventMetadata, SessionAnalyticsFilesManager paramSessionAnalyticsFilesManager, HttpRequestFactory paramHttpRequestFactory) {
    ScheduledExecutorService scheduledExecutorService = ExecutorUtils.buildSingleThreadScheduledExecutorService("Crashlytics Trace Manager");
    return new AutoSessionAnalyticsManager(paramSessionEventMetadata, new SessionEventsHandler((Context)paramApplication, new EnabledSessionAnalyticsManagerStrategy((Context)paramApplication, scheduledExecutorService, paramSessionAnalyticsFilesManager, paramHttpRequestFactory), paramSessionAnalyticsFilesManager, scheduledExecutorService), paramApplication);
  }
  
  public void disable() {
    CommonUtils.logControlled(Answers.getInstance().getContext(), "Unregistering activity lifecycle callbacks for session analytics");
    this.application.unregisterActivityLifecycleCallbacks(this.activityLifecycleCallbacks);
    super.disable();
  }
}


/* Location:              C:\soft\dex2jar-2.0\Smash Cricket-dex2jar.jar!\com\crashlytics\android\answers\AutoSessionAnalyticsManager.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */