package com.crashlytics.android.answers;

import java.util.HashMap;
import java.util.Map;

public final class EventAttributes {
  public static final int MAX_NUM_ATTRIBUTES = 20;
  
  public static final int MAX_STRING_LENGTH = 100;
  
  final Map<String, Object> attributes = new HashMap<String, Object>();
  
  static void validateStringLength(String paramString) {
    if (paramString.length() > 100)
      throw new IllegalArgumentException(String.format("String cannot be longer than %d characters", new Object[] { Integer.valueOf(100) })); 
  }
  
  public EventAttributes put(String paramString, Number paramNumber) {
    if (paramString == null)
      throw new NullPointerException("key must not be null"); 
    if (paramNumber == null)
      throw new NullPointerException("value must not be null"); 
    validateStringLength(paramString);
    putAttribute(paramString, paramNumber);
    return this;
  }
  
  public EventAttributes put(String paramString1, String paramString2) {
    if (paramString1 == null)
      throw new NullPointerException("key must not be null"); 
    if (paramString2 == null)
      throw new NullPointerException("value must not be null"); 
    validateStringLength(paramString1);
    validateStringLength(paramString2);
    putAttribute(paramString1, paramString2);
    return this;
  }
  
  void putAttribute(String paramString, Object paramObject) {
    if (this.attributes.size() >= 20 && !this.attributes.containsKey(paramString))
      throw new IllegalStateException(String.format("Event cannot have more than %d attributes", new Object[] { Integer.valueOf(20) })); 
    this.attributes.put(paramString, paramObject);
  }
}


/* Location:              C:\soft\dex2jar-2.0\Smash Cricket-dex2jar.jar!\com\crashlytics\android\answers\EventAttributes.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */