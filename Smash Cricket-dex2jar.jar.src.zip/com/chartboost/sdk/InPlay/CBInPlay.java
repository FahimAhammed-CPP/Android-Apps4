package com.chartboost.sdk.InPlay;

import android.graphics.Bitmap;
import android.text.TextUtils;
import com.chartboost.sdk.Libraries.CBLogging;
import com.chartboost.sdk.Libraries.e;
import com.chartboost.sdk.Model.CBError;
import com.chartboost.sdk.b;

public final class CBInPlay {
  private static final String a = CBInPlay.class.getSimpleName();
  
  private static a f = null;
  
  private String b;
  
  private Bitmap c;
  
  private String d;
  
  private e.a e;
  
  public static void cacheInPlay(String paramString) {
    if (b.p()) {
      if (TextUtils.isEmpty(paramString)) {
        CBLogging.b(a, "Inplay location cannot be empty");
        if (b.f() != null) {
          b.f().didFailToLoadInPlay(paramString, CBError.CBImpressionError.INVALID_LOCATION);
          return;
        } 
        return;
      } 
      if (f == null)
        f = a.a(); 
      f.a(paramString);
      return;
    } 
  }
  
  public static CBInPlay getInPlay(String paramString) {
    if (b.p()) {
      if (TextUtils.isEmpty(paramString)) {
        CBLogging.b(a, "Inplay location cannot be empty");
        if (b.f() != null) {
          b.f().didFailToLoadInPlay(paramString, CBError.CBImpressionError.INVALID_LOCATION);
          return null;
        } 
        return null;
      } 
      if (f == null)
        f = a.a(); 
      return f.c(paramString);
    } 
    return null;
  }
  
  public static boolean hasInPlay(String paramString) {
    if (b.p()) {
      if (TextUtils.isEmpty(paramString)) {
        CBLogging.b(a, "Inplay location cannot be empty");
        if (b.f() != null) {
          b.f().didFailToLoadInPlay(paramString, CBError.CBImpressionError.INVALID_LOCATION);
          return false;
        } 
        return false;
      } 
      if (f == null)
        f = a.a(); 
      return f.b(paramString);
    } 
    return false;
  }
  
  protected e.a a() {
    return this.e;
  }
  
  protected void a(Bitmap paramBitmap) {
    this.c = paramBitmap;
  }
  
  protected void a(e.a parama) {
    this.e = parama;
  }
  
  protected void a(String paramString) {
    this.b = paramString;
  }
  
  protected void b(String paramString) {
    this.d = paramString;
  }
  
  public void click() {
    a.a().b(this);
  }
  
  public Bitmap getAppIcon() {
    return this.c;
  }
  
  public String getAppName() {
    return this.d;
  }
  
  public String getLocation() {
    return this.b;
  }
  
  public void show() {
    a.a().a(this);
  }
}


/* Location:              C:\soft\dex2jar-2.0\Smash Cricket-dex2jar.jar!\com\chartboost\sdk\InPlay\CBInPlay.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */