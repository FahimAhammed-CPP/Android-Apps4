package com.chartboost.sdk.InPlay;

import android.graphics.Bitmap;
import android.text.TextUtils;
import com.chartboost.sdk.Libraries.CBLogging;
import com.chartboost.sdk.Libraries.e;
import com.chartboost.sdk.Model.CBError;
import com.chartboost.sdk.c;
import com.chartboost.sdk.impl.ab;
import com.chartboost.sdk.impl.az;
import com.chartboost.sdk.impl.ba;
import com.chartboost.sdk.impl.l;
import com.chartboost.sdk.impl.n;
import com.chartboost.sdk.impl.s;
import java.util.ArrayList;
import java.util.LinkedHashMap;

public final class a {
  private static final String a = a.class.getSimpleName();
  
  private static ArrayList<CBInPlay> b;
  
  private static int c = 4;
  
  private static a d;
  
  private static LinkedHashMap<String, Bitmap> e;
  
  private static volatile boolean f = false;
  
  private a() {
    b = new ArrayList<CBInPlay>();
    e = new LinkedHashMap<String, Bitmap>(c);
  }
  
  public static a a() {
    // Byte code:
    //   0: getstatic com/chartboost/sdk/InPlay/a.d : Lcom/chartboost/sdk/InPlay/a;
    //   3: ifnonnull -> 28
    //   6: ldc com/chartboost/sdk/InPlay/a
    //   8: monitorenter
    //   9: getstatic com/chartboost/sdk/InPlay/a.d : Lcom/chartboost/sdk/InPlay/a;
    //   12: ifnonnull -> 25
    //   15: new com/chartboost/sdk/InPlay/a
    //   18: dup
    //   19: invokespecial <init> : ()V
    //   22: putstatic com/chartboost/sdk/InPlay/a.d : Lcom/chartboost/sdk/InPlay/a;
    //   25: ldc com/chartboost/sdk/InPlay/a
    //   27: monitorexit
    //   28: getstatic com/chartboost/sdk/InPlay/a.d : Lcom/chartboost/sdk/InPlay/a;
    //   31: areturn
    //   32: astore_0
    //   33: ldc com/chartboost/sdk/InPlay/a
    //   35: monitorexit
    //   36: aload_0
    //   37: athrow
    // Exception table:
    //   from	to	target	type
    //   9	25	32	finally
    //   25	28	32	finally
    //   33	36	32	finally
  }
  
  private void a(CBInPlay paramCBInPlay, String paramString, boolean paramBoolean) {
    // Byte code:
    //   0: aload_0
    //   1: monitorenter
    //   2: aload_1
    //   3: getstatic com/chartboost/sdk/InPlay/a.e : Ljava/util/LinkedHashMap;
    //   6: aload_2
    //   7: invokevirtual get : (Ljava/lang/Object;)Ljava/lang/Object;
    //   10: checkcast android/graphics/Bitmap
    //   13: invokevirtual a : (Landroid/graphics/Bitmap;)V
    //   16: getstatic com/chartboost/sdk/InPlay/a.b : Ljava/util/ArrayList;
    //   19: aload_1
    //   20: invokevirtual add : (Ljava/lang/Object;)Z
    //   23: pop
    //   24: invokestatic f : ()Lcom/chartboost/sdk/a;
    //   27: astore_2
    //   28: aload_2
    //   29: ifnull -> 46
    //   32: iload_3
    //   33: ifeq -> 46
    //   36: aload_2
    //   37: aload_1
    //   38: invokevirtual getLocation : ()Ljava/lang/String;
    //   41: invokeinterface didCacheInPlay : (Ljava/lang/String;)V
    //   46: invokestatic e : ()Z
    //   49: ifne -> 67
    //   52: getstatic com/chartboost/sdk/InPlay/a.f : Z
    //   55: ifne -> 67
    //   58: aload_0
    //   59: aload_1
    //   60: invokevirtual getLocation : ()Ljava/lang/String;
    //   63: iconst_0
    //   64: invokespecial a : (Ljava/lang/String;Z)V
    //   67: aload_0
    //   68: monitorexit
    //   69: return
    //   70: astore_1
    //   71: aload_0
    //   72: monitorexit
    //   73: aload_1
    //   74: athrow
    // Exception table:
    //   from	to	target	type
    //   2	28	70	finally
    //   36	46	70	finally
    //   46	67	70	finally
  }
  
  private void a(String paramString, boolean paramBoolean) {
    f = true;
    az az = new az("/inplay/get");
    az.a("raw", Boolean.valueOf(true));
    az.a("cache", Boolean.valueOf(true));
    az.a(l.a.c);
    az.b(true);
    az.a("location", paramString);
    az.a(com.chartboost.sdk.Model.b.d);
    az.a(new az.c(this, paramString, paramBoolean) {
          public void a(e.a param1a, az param1az) {
            ab ab;
            CBInPlay cBInPlay;
            a.a(false);
            if (param1a.c()) {
              cBInPlay = new CBInPlay();
              cBInPlay.a(param1a);
              cBInPlay.b(param1a.e("name"));
              if (!TextUtils.isEmpty(this.a))
                cBInPlay.a(this.a); 
              param1a = param1a.a("icons");
              if (param1a.c() && !TextUtils.isEmpty(param1a.e("lg"))) {
                String str = param1a.e("lg");
                if (a.c().get(str) == null) {
                  a.b b = new a.b();
                  a.a a1 = new a.a();
                  b.c = cBInPlay;
                  b.b = str;
                  b.a = this.b;
                  ab = new ab(str, b, 0, 0, null, a1);
                  ba.a(com.chartboost.sdk.b.x()).a().a((l)ab);
                  return;
                } 
              } else {
                return;
              } 
            } else {
              return;
            } 
            a.a(this.c, cBInPlay, (String)ab, true);
          }
          
          public void a(e.a param1a, az param1az, CBError param1CBError) {
            CBLogging.b(a.d(), "InPlay cache call failed" + param1CBError);
            a.a(false);
            if (com.chartboost.sdk.b.f() != null) {
              com.chartboost.sdk.a a1 = com.chartboost.sdk.b.f();
              String str = this.a;
              if (param1CBError != null) {
                CBError.CBImpressionError cBImpressionError = param1CBError.c();
              } else {
                param1a = null;
              } 
              a1.didFailToLoadInPlay(str, (CBError.CBImpressionError)param1a);
            } 
          }
        });
  }
  
  public static void b() {
    if (e != null)
      e.clear(); 
    if (b != null)
      b.clear(); 
  }
  
  private static boolean e() {
    return (b.size() == c);
  }
  
  protected void a(CBInPlay paramCBInPlay) {
    String str;
    e.a a1 = paramCBInPlay.a();
    az az = new az("/inplay/show");
    az.a("inplay-dictionary", a1);
    az.a("location", paramCBInPlay.getLocation());
    az.a(true);
    az.s();
    az = null;
    if (paramCBInPlay.a().c())
      str = a1.e("ad_id"); 
    com.chartboost.sdk.Tracking.a.a("in-play", paramCBInPlay.getLocation(), str);
  }
  
  public void a(String paramString) {
    // Byte code:
    //   0: aload_0
    //   1: monitorenter
    //   2: invokestatic e : ()Z
    //   5: ifne -> 16
    //   8: getstatic com/chartboost/sdk/InPlay/a.f : Z
    //   11: istore_2
    //   12: iload_2
    //   13: ifeq -> 19
    //   16: aload_0
    //   17: monitorexit
    //   18: return
    //   19: aload_0
    //   20: aload_1
    //   21: iconst_1
    //   22: invokespecial a : (Ljava/lang/String;Z)V
    //   25: goto -> 16
    //   28: astore_1
    //   29: aload_0
    //   30: monitorexit
    //   31: aload_1
    //   32: athrow
    // Exception table:
    //   from	to	target	type
    //   2	12	28	finally
    //   19	25	28	finally
  }
  
  protected void b(CBInPlay paramCBInPlay) {
    // Byte code:
    //   0: aload_1
    //   1: invokevirtual a : ()Lcom/chartboost/sdk/Libraries/e$a;
    //   4: astore #5
    //   6: aload #5
    //   8: ifnull -> 116
    //   11: aload #5
    //   13: ldc 'link'
    //   15: invokevirtual e : (Ljava/lang/String;)Ljava/lang/String;
    //   18: astore_3
    //   19: aload #5
    //   21: ldc 'deep-link'
    //   23: invokevirtual e : (Ljava/lang/String;)Ljava/lang/String;
    //   26: astore #4
    //   28: aload #4
    //   30: invokestatic isEmpty : (Ljava/lang/CharSequence;)Z
    //   33: ifne -> 92
    //   36: aload #4
    //   38: invokestatic a : (Ljava/lang/String;)Z
    //   41: istore_2
    //   42: iload_2
    //   43: ifeq -> 113
    //   46: aload #4
    //   48: astore_3
    //   49: new com/chartboost/sdk/InPlay/a$2
    //   52: dup
    //   53: aload_0
    //   54: aload_1
    //   55: aload #5
    //   57: invokespecial <init> : (Lcom/chartboost/sdk/InPlay/a;Lcom/chartboost/sdk/InPlay/CBInPlay;Lcom/chartboost/sdk/Libraries/e$a;)V
    //   60: astore_1
    //   61: invokestatic a : ()Lcom/chartboost/sdk/c;
    //   64: astore #4
    //   66: aload_3
    //   67: invokestatic isEmpty : (Ljava/lang/CharSequence;)Z
    //   70: ifne -> 95
    //   73: aload #4
    //   75: aconst_null
    //   76: aload_3
    //   77: aload_1
    //   78: invokevirtual b : (Lcom/chartboost/sdk/Model/a;Ljava/lang/String;Lcom/chartboost/sdk/c$b;)V
    //   81: return
    //   82: astore #4
    //   84: getstatic com/chartboost/sdk/InPlay/a.a : Ljava/lang/String;
    //   87: ldc 'Cannot open a url'
    //   89: invokestatic b : (Ljava/lang/Object;Ljava/lang/String;)V
    //   92: goto -> 49
    //   95: aload #4
    //   97: getfield b : Lcom/chartboost/sdk/impl/bb$a;
    //   100: aconst_null
    //   101: iconst_0
    //   102: aload_3
    //   103: getstatic com/chartboost/sdk/Model/CBError$CBClickError.URI_INVALID : Lcom/chartboost/sdk/Model/CBError$CBClickError;
    //   106: aload_1
    //   107: invokeinterface a : (Lcom/chartboost/sdk/Model/a;ZLjava/lang/String;Lcom/chartboost/sdk/Model/CBError$CBClickError;Lcom/chartboost/sdk/c$b;)V
    //   112: return
    //   113: goto -> 49
    //   116: aconst_null
    //   117: astore_3
    //   118: goto -> 49
    // Exception table:
    //   from	to	target	type
    //   36	42	82	java/lang/Exception
  }
  
  public boolean b(String paramString) {
    // Byte code:
    //   0: iconst_1
    //   1: istore_2
    //   2: aload_0
    //   3: monitorenter
    //   4: getstatic com/chartboost/sdk/InPlay/a.b : Ljava/util/ArrayList;
    //   7: invokevirtual size : ()I
    //   10: ifle -> 24
    //   13: ldc 'in-play'
    //   15: aload_1
    //   16: iconst_1
    //   17: invokestatic b : (Ljava/lang/String;Ljava/lang/String;Z)V
    //   20: aload_0
    //   21: monitorexit
    //   22: iload_2
    //   23: ireturn
    //   24: iconst_0
    //   25: istore_2
    //   26: goto -> 20
    //   29: astore_1
    //   30: aload_0
    //   31: monitorexit
    //   32: aload_1
    //   33: athrow
    // Exception table:
    //   from	to	target	type
    //   4	20	29	finally
  }
  
  public CBInPlay c(String paramString) {
    // Byte code:
    //   0: aload_0
    //   1: monitorenter
    //   2: aconst_null
    //   3: astore_2
    //   4: getstatic com/chartboost/sdk/InPlay/a.b : Ljava/util/ArrayList;
    //   7: invokevirtual size : ()I
    //   10: ifle -> 32
    //   13: getstatic com/chartboost/sdk/InPlay/a.b : Ljava/util/ArrayList;
    //   16: iconst_0
    //   17: invokevirtual get : (I)Ljava/lang/Object;
    //   20: checkcast com/chartboost/sdk/InPlay/CBInPlay
    //   23: astore_2
    //   24: getstatic com/chartboost/sdk/InPlay/a.b : Ljava/util/ArrayList;
    //   27: iconst_0
    //   28: invokevirtual remove : (I)Ljava/lang/Object;
    //   31: pop
    //   32: invokestatic e : ()Z
    //   35: ifne -> 50
    //   38: getstatic com/chartboost/sdk/InPlay/a.f : Z
    //   41: ifne -> 50
    //   44: aload_0
    //   45: aload_1
    //   46: iconst_1
    //   47: invokespecial a : (Ljava/lang/String;Z)V
    //   50: aload_2
    //   51: ifnonnull -> 62
    //   54: getstatic com/chartboost/sdk/InPlay/a.a : Ljava/lang/String;
    //   57: ldc 'InPlay Object not available returning null :('
    //   59: invokestatic a : (Ljava/lang/Object;Ljava/lang/String;)V
    //   62: aload_0
    //   63: monitorexit
    //   64: aload_2
    //   65: areturn
    //   66: astore_1
    //   67: aload_0
    //   68: monitorexit
    //   69: aload_1
    //   70: athrow
    // Exception table:
    //   from	to	target	type
    //   4	32	66	finally
    //   32	50	66	finally
    //   54	62	66	finally
  }
  
  private class a implements n.a {
    private a(a this$0) {}
    
    public void a(s param1s) {
      CBLogging.b(a.d(), "Bitmap download failed " + param1s.getMessage());
    }
  }
  
  private class b implements n.b<Bitmap> {
    protected boolean a;
    
    protected String b;
    
    protected CBInPlay c;
    
    private b(a this$0) {}
    
    public void a(Bitmap param1Bitmap) {
      a.c().put(this.b, param1Bitmap);
      a.a(this.d, this.c, this.b, this.a);
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Smash Cricket-dex2jar.jar!\com\chartboost\sdk\InPlay\a.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */