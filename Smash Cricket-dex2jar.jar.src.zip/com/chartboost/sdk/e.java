package com.chartboost.sdk;

import android.app.Activity;
import android.content.Context;
import android.view.View;
import android.view.ViewGroup;
import android.widget.FrameLayout;
import com.chartboost.sdk.Libraries.CBLogging;
import com.chartboost.sdk.Libraries.CBUtility;
import com.chartboost.sdk.Model.CBError;
import com.chartboost.sdk.Model.a;
import com.chartboost.sdk.impl.bh;
import com.chartboost.sdk.impl.bp;

public final class e {
  private static e c;
  
  private bp a = null;
  
  private a b;
  
  public static e a() {
    if (c == null)
      c = new e(); 
    return c;
  }
  
  private void e() {
    CBLogging.b("CBViewController", " Closing impression activity");
    Activity activity = Chartboost.f();
    if (activity != null && activity instanceof CBImpressionActivity) {
      CBLogging.b("CBViewController", " Closing impression activity #######");
      Chartboost.g();
      activity.finish();
    } 
  }
  
  private void e(a parama) {
    boolean bool;
    CBError.CBImpressionError cBImpressionError1;
    if (this.a != null && this.a.h() != parama) {
      CBLogging.b("CBViewController", "Impression already visible");
      parama.a(CBError.CBImpressionError.IMPRESSION_ALREADY_VISIBLE);
      return;
    } 
    if (parama.b != a.b.c) {
      bool = true;
    } else {
      bool = false;
    } 
    parama.b = a.b.c;
    Activity activity = Chartboost.f();
    if (activity == null) {
      cBImpressionError1 = CBError.CBImpressionError.NO_HOST_ACTIVITY;
    } else {
      cBImpressionError1 = null;
    } 
    CBError.CBImpressionError cBImpressionError2 = cBImpressionError1;
    if (cBImpressionError1 == null)
      cBImpressionError2 = parama.k(); 
    if (cBImpressionError2 != null) {
      CBLogging.b("CBViewController", "Cannot able to create the view while trying th display the impression");
      parama.a(cBImpressionError2);
      return;
    } 
    if (this.a == null) {
      this.a = new bp((Context)activity, parama);
      activity.addContentView((View)this.a, (ViewGroup.LayoutParams)new FrameLayout.LayoutParams(-1, -1));
    } 
    this.a.a();
    CBLogging.b("CBViewController", "Displaying the impression");
    parama.h = this.a;
    if (bool) {
      this.a.e().a();
      bh.b b1 = bh.b.a;
      if (parama.c == a.c.b)
        b1 = bh.b.c; 
      bh.b b2 = bh.b.a(parama.w().f("animation"));
      if (b2 != null)
        b1 = b2; 
      if (b.h())
        b1 = bh.b.g; 
      parama.n();
      bh.a(b1, parama, new bh.a(this) {
            public void a(a param1a) {
              param1a.o();
            }
          });
      if (b.f() != null && (parama.e == a.d.b || parama.e == a.d.c))
        b.f().willDisplayVideo(parama.d); 
      if (parama.q().b() != null) {
        parama.q().b().e(parama);
        return;
      } 
    } 
  }
  
  private void f(a parama) {
    Activity activity = Chartboost.f();
    if (activity == null) {
      CBLogging.d(this, "No host activity to display loading view");
      return;
    } 
    if (this.a == null) {
      this.a = new bp((Context)activity, parama);
      activity.addContentView((View)this.a, (ViewGroup.LayoutParams)new FrameLayout.LayoutParams(-1, -1));
    } 
    this.a.b();
    this.b = parama;
  }
  
  protected void a(a parama) {
    switch (null.a[parama.b.ordinal()]) {
      default:
        e(parama);
        return;
      case 1:
        break;
    } 
    if (parama.i && b.v()) {
      f(parama);
      return;
    } 
  }
  
  public void a(a parama, boolean paramBoolean) {
    if (parama != null && (parama == this.b || parama == c.a().c())) {
      this.b = null;
      CBLogging.b("CBViewController", "Dismissing loading view");
      if (b()) {
        this.a.c();
        if (paramBoolean && this.a != null && this.a.h() != null) {
          d(this.a.h());
          return;
        } 
      } 
    } 
  }
  
  public void b(a parama) {
    CBLogging.b("CBViewController", "Dismissing impression");
    Runnable runnable = new Runnable(this, parama) {
        public void run() {
          this.a.b = a.b.e;
          bh.b b1 = bh.b.a;
          if (this.a.c == a.c.b)
            b1 = bh.b.c; 
          bh.b b2 = bh.b.a(this.a.w().f("animation"));
          if (b2 != null)
            b1 = b2; 
          if (b.h())
            b1 = bh.b.g; 
          bh.b(b1, this.a, new bh.a(this) {
                public void a(a param2a) {
                  CBUtility.e().post(new Runnable(this, param2a) {
                        public void run() {
                          this.b.a.b.d(this.a);
                        }
                      });
                  param2a.m();
                }
              });
        }
      };
    if (parama.k) {
      parama.a(runnable);
      return;
    } 
    runnable.run();
  }
  
  public boolean b() {
    return (this.a != null && this.a.g());
  }
  
  public void c(a parama) {
    CBLogging.b("CBViewController", "Removing impression silently");
    if (b())
      a(parama, false); 
    parama.j();
    try {
      ((ViewGroup)this.a.getParent()).removeView((View)this.a);
    } catch (Exception exception) {
      CBLogging.b("CBViewController", "Exception removing impression silently", exception);
    } 
    this.a = null;
  }
  
  public boolean c() {
    return (this.a != null);
  }
  
  public bp d() {
    return this.a;
  }
  
  public void d(a parama) {
    CBLogging.b("CBViewController", "Removing impression");
    parama.b = a.b.f;
    if (this.a == null) {
      if (b.g())
        e(); 
      return;
    } 
    try {
      ((ViewGroup)this.a.getParent()).removeView((View)this.a);
    } catch (Exception exception) {
      CBLogging.b("CBViewController", "Exception removing impression ", exception);
    } 
    parama.i();
    this.a = null;
    if (b.g())
      e(); 
    parama.q().b().c(parama);
    if (parama.y()) {
      parama.q().b().b(parama);
      return;
    } 
  }
}


/* Location:              C:\soft\dex2jar-2.0\Smash Cricket-dex2jar.jar!\com\chartboost\sdk\e.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */