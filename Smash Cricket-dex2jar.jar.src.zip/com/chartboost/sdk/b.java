package com.chartboost.sdk;

import android.app.Activity;
import android.app.Application;
import android.content.Context;
import android.content.SharedPreferences;
import android.text.TextUtils;
import com.chartboost.sdk.Libraries.CBLogging;
import com.chartboost.sdk.Libraries.CBUtility;
import com.chartboost.sdk.Libraries.a;
import com.chartboost.sdk.Libraries.e;
import com.chartboost.sdk.Libraries.g;
import com.chartboost.sdk.Model.CBError;
import com.chartboost.sdk.impl.az;
import com.chartboost.sdk.impl.l;
import java.util.Map;
import org.json.JSONObject;

public final class b {
  public static c.a a;
  
  private static final String b = b.class.getSimpleName();
  
  private static String c;
  
  private static String d;
  
  private static a e;
  
  private static boolean f = false;
  
  private static boolean g = false;
  
  private static boolean h = false;
  
  private static Chartboost.CBFramework i = null;
  
  private static String j = null;
  
  private static String k = null;
  
  private static String l = null;
  
  private static SharedPreferences m = null;
  
  private static boolean n = true;
  
  private static volatile boolean o = false;
  
  private static Context p = null;
  
  private static Application q = null;
  
  private static boolean r = false;
  
  private static boolean s = true;
  
  private static boolean t = false;
  
  private static boolean u = true;
  
  public static Chartboost.CBFramework a() {
    s();
    return (i == null) ? null : i;
  }
  
  public static void a(Application paramApplication) {
    q = paramApplication;
  }
  
  public static void a(Context paramContext) {
    p = paramContext;
  }
  
  public static void a(Chartboost.CBFramework paramCBFramework) {
    if (!s())
      return; 
    if (paramCBFramework == null) {
      CBLogging.b(b, "Pass a valid CBFramework enum value");
      return;
    } 
    i = paramCBFramework;
  }
  
  public static void a(Chartboost.CBFramework paramCBFramework, String paramString) {
    a(paramCBFramework);
    j = paramString;
  }
  
  public static void a(CBLogging.Level paramLevel) {
    s();
    CBLogging.a = paramLevel;
  }
  
  public static void a(e.a parama) {
    if (parama != null) {
      Map map = parama.f();
      if (map != null) {
        SharedPreferences.Editor editor = z().edit();
        for (String str : map.keySet()) {
          Object object = map.get(str);
          if (object instanceof String) {
            editor.putString(str, (String)object);
            continue;
          } 
          if (object instanceof Integer) {
            editor.putInt(str, ((Integer)object).intValue());
            continue;
          } 
          if (object instanceof Float) {
            editor.putFloat(str, ((Float)object).floatValue());
            continue;
          } 
          if (object instanceof Long) {
            editor.putLong(str, ((Long)object).longValue());
            continue;
          } 
          if (object instanceof Boolean) {
            editor.putBoolean(str, ((Boolean)object).booleanValue());
            continue;
          } 
          if (object != null)
            editor.putString(str, object.toString()); 
        } 
        editor.commit();
      } 
    } 
  }
  
  public static void a(a parama) {
    if (!s())
      return; 
    e = parama;
  }
  
  public static void a(a parama) {
    az az = new az("/api/config");
    az.a(false);
    az.b(false);
    az.a(l.a.c);
    az.a(g.a(new g.k[] { g.a("status", a.a) }));
    az.a(new az.c(parama) {
          public void a(e.a param1a, az param1az) {
            if (param1a != null)
              b.a(param1a.a("response")); 
            if (this.a != null)
              this.a.a(); 
          }
          
          public void a(e.a param1a, az param1az, CBError param1CBError) {
            if (this.a != null)
              this.a.a(); 
          }
        });
  }
  
  public static void a(String paramString) {
    if (!s())
      return; 
    if (i == null) {
      CBLogging.b(b, "Set a valid CBFramework first");
      return;
    } 
    if (TextUtils.isEmpty(paramString)) {
      CBLogging.b(b, "Invalid Version String");
      return;
    } 
    k = paramString;
  }
  
  public static void a(boolean paramBoolean) {
    if (!s())
      return; 
    f = paramBoolean;
  }
  
  public static boolean a(Activity paramActivity) {
    if (paramActivity == null)
      try {
        throw new Exception("Invalid activity context: Host Activity object is null, Please send a valid activity object");
      } catch (Exception exception) {
        exception.printStackTrace();
        return false;
      }  
    return true;
  }
  
  public static String b() {
    return String.format("%s %s", new Object[] { i, j });
  }
  
  public static void b(String paramString) {
    c = paramString;
    z().edit().putString("appId", paramString).commit();
  }
  
  public static void b(boolean paramBoolean) {
    n = paramBoolean;
  }
  
  public static boolean b(Context paramContext) {
    if (paramContext == null)
      try {
        throw new RuntimeException("Invalid activity context passed during intitalization");
      } catch (Exception exception) {
        exception.printStackTrace();
        return false;
      }  
    int i = exception.checkCallingOrSelfPermission("android.permission.WRITE_EXTERNAL_STORAGE");
    int j = exception.checkCallingOrSelfPermission("android.permission.ACCESS_NETWORK_STATE");
    int k = exception.checkCallingOrSelfPermission("android.permission.INTERNET");
    if (i != 0)
      throw new RuntimeException("Please add the permission : android.permission.WRITE_EXTERNAL_STORAGE in your android manifest.xml"); 
    if (k != 0)
      throw new RuntimeException("Please add the permission : android.permission.INTERNET in your android manifest.xml"); 
    if (j != 0)
      throw new RuntimeException("Please add the permission :  android.permission.ACCESS_NETWORK_STATE in your android manifest.xml"); 
    return true;
  }
  
  public static String c() {
    s();
    return k;
  }
  
  public static void c(String paramString) {
    d = paramString;
    z().edit().putString("appSignature", paramString).commit();
  }
  
  protected static void c(boolean paramBoolean) {
    o = paramBoolean;
  }
  
  public static String d() {
    if (!s())
      return ""; 
    c = z().getString("appId", c);
    return c;
  }
  
  public static void d(String paramString) {
    if (!s())
      return; 
    l = paramString;
  }
  
  public static void d(boolean paramBoolean) {
    if (a != null)
      a.a(paramBoolean); 
  }
  
  public static String e() {
    if (!s())
      return ""; 
    d = z().getString("appSignature", d);
    return d;
  }
  
  protected static void e(boolean paramBoolean) {
    r = paramBoolean;
  }
  
  public static a f() {
    return !s() ? null : e;
  }
  
  public static void f(boolean paramBoolean) {
    s = paramBoolean;
  }
  
  public static void g(boolean paramBoolean) {
    t = paramBoolean;
  }
  
  public static boolean g() {
    return !s() ? false : f;
  }
  
  public static void h(boolean paramBoolean) {
    u = paramBoolean;
  }
  
  public static boolean h() {
    return !s() ? false : h;
  }
  
  public static boolean i() {
    return n;
  }
  
  public static JSONObject j() {
    if (s()) {
      String str = z().getString("trackingLevels", "");
      if (!TextUtils.isEmpty(str)) {
        e.a a1 = e.a.j(str);
        if (a1.c())
          return a1.e(); 
      } 
    } 
    return null;
  }
  
  public static boolean k() {
    s();
    return z().getBoolean("retriesEnabled", true);
  }
  
  public static boolean l() {
    if (s()) {
      JSONObject jSONObject = j();
      if (jSONObject != null && (jSONObject.optBoolean("debug") || jSONObject.optBoolean("session") || jSONObject.optBoolean("system") || jSONObject.optBoolean("user")))
        return true; 
    } 
    return false;
  }
  
  public static CBLogging.Level m() {
    s();
    return CBLogging.a;
  }
  
  public static String n() {
    return !s() ? "" : l;
  }
  
  public static boolean o() {
    return o;
  }
  
  public static boolean p() {
    return (s() && r() && q());
  }
  
  public static boolean q() {
    if (!o())
      try {
        throw new Exception("Session not started: Check if Chartboost.onStart() is called, if not the session won't be invoked");
      } catch (Exception exception) {
        exception.printStackTrace();
        return false;
      }  
    return true;
  }
  
  public static boolean r() {
    if (Chartboost.b == null)
      try {
        throw new Exception("Chartboost Weak Activity reference is null");
      } catch (Exception exception) {
        exception.printStackTrace();
        return false;
      }  
    return true;
  }
  
  public static boolean s() {
    if (y() == null || TextUtils.isEmpty(c) || TextUtils.isEmpty(d))
      try {
        throw new Exception("Chartboost Initialization error. Activity or appId or appSignature is invalid");
      } catch (Exception exception) {
        exception.printStackTrace();
        return false;
      }  
    return true;
  }
  
  public static boolean t() {
    return r;
  }
  
  public static boolean u() {
    return s;
  }
  
  public static boolean v() {
    return t;
  }
  
  public static boolean w() {
    return u;
  }
  
  public static Context x() {
    return p;
  }
  
  public static Application y() {
    return q;
  }
  
  private static SharedPreferences z() {
    if (m == null)
      m = CBUtility.a(); 
    return m;
  }
  
  public static interface a {
    void a();
  }
}


/* Location:              C:\soft\dex2jar-2.0\Smash Cricket-dex2jar.jar!\com\chartboost\sdk\b.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */