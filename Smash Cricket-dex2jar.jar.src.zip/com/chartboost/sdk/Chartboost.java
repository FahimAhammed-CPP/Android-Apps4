package com.chartboost.sdk;

import android.app.Activity;
import android.content.ActivityNotFoundException;
import android.content.Context;
import android.content.Intent;
import android.os.Handler;
import android.os.Looper;
import android.text.TextUtils;
import android.util.SparseBooleanArray;
import android.view.SurfaceView;
import android.view.View;
import android.view.ViewGroup;
import com.chartboost.sdk.InPlay.a;
import com.chartboost.sdk.Libraries.CBLogging;
import com.chartboost.sdk.Libraries.CBUtility;
import com.chartboost.sdk.Libraries.a;
import com.chartboost.sdk.Libraries.c;
import com.chartboost.sdk.Libraries.e;
import com.chartboost.sdk.Libraries.g;
import com.chartboost.sdk.Libraries.k;
import com.chartboost.sdk.Model.CBError;
import com.chartboost.sdk.Model.a;
import com.chartboost.sdk.Tracking.a;
import com.chartboost.sdk.impl.ae;
import com.chartboost.sdk.impl.af;
import com.chartboost.sdk.impl.av;
import com.chartboost.sdk.impl.ay;
import com.chartboost.sdk.impl.az;
import com.chartboost.sdk.impl.ba;
import com.chartboost.sdk.impl.bc;
import com.chartboost.sdk.impl.bd;
import com.chartboost.sdk.impl.bg;
import com.chartboost.sdk.impl.m;
import java.util.Locale;

public final class Chartboost {
  protected static volatile Handler a;
  
  protected static k b;
  
  private static volatile Chartboost c = null;
  
  private static CBImpressionActivity d = null;
  
  private static a e = null;
  
  private static ay f = null;
  
  private static ba g = null;
  
  private static m h = null;
  
  private static a i = null;
  
  private static boolean j = false;
  
  private static SparseBooleanArray k = new SparseBooleanArray();
  
  private static e l = null;
  
  private static c m = null;
  
  private static boolean n = false;
  
  private static Runnable o;
  
  private static boolean p;
  
  private static boolean q;
  
  private static Runnable r;
  
  static {
    a = new Handler(Looper.getMainLooper());
    b = null;
    p = false;
    q = false;
    r = new Runnable() {
        public void run() {
          if (!Chartboost.n())
            Chartboost.c(); 
          Chartboost.a(false);
        }
      };
  }
  
  private Chartboost(Activity paramActivity, String paramString1, String paramString2) {
    c = this;
    CBUtility.a(a);
    b.a(paramActivity.getApplication());
    b.a(paramActivity.getApplicationContext());
    b.b(paramString1);
    b.c(paramString2);
    f = ay.a();
    l = e.a();
    g = ba.a(b.x());
    h = g.a();
    m = c.a();
    i = a.a();
    f.a(b.x());
    bd.a();
    o = new a();
    c.a();
    CBUtility.h();
  }
  
  protected static void a() {
    if (b.x() == null) {
      CBLogging.b("Chartboost", "The context must be set through the Chartboost method onCreate() before calling startSession().");
      return;
    } 
    if (b.g() && b.o()) {
      if (!p) {
        q = false;
        p();
        return;
      } 
      q = true;
      return;
    } 
    p();
  }
  
  private static void a(int paramInt, boolean paramBoolean) {
    k.put(paramInt, paramBoolean);
  }
  
  protected static void a(Activity paramActivity) {
    boolean bool;
    b.a(paramActivity.getApplicationContext());
    if (!(paramActivity instanceof CBImpressionActivity)) {
      b = k.a(paramActivity);
      c(b, true);
    } else {
      a((CBImpressionActivity)paramActivity);
    } 
    a.removeCallbacks(o);
    if (b.a() != null && b.a().doesWrapperUseCustomBackgroundingBehavior()) {
      bool = true;
    } else {
      bool = false;
    } 
    if (paramActivity != null && (bool || f(paramActivity))) {
      b(k.a(paramActivity), true);
      if (paramActivity instanceof CBImpressionActivity)
        n = false; 
      if (m.a(paramActivity, e))
        e = null; 
      a a1 = m.c();
      if (a1 != null) {
        a1.u();
        return;
      } 
    } 
  }
  
  protected static void a(CBImpressionActivity paramCBImpressionActivity) {
    if (!j) {
      b.a(paramCBImpressionActivity.getApplicationContext());
      d = paramCBImpressionActivity;
      j = true;
    } 
    a.removeCallbacks(o);
  }
  
  protected static void a(k paramk) {
    a a1 = c.a().c();
    if (b.a() != null && b.a().ordinal() == CBFramework.CBFrameworkUnity.ordinal())
      a(); 
    if (a1 != null)
      a1.t(); 
  }
  
  protected static void a(a parama) {
    boolean bool = true;
    e e1 = h();
    if (e1 != null && e1.c() && e1.d().h() != parama) {
      parama.a(CBError.CBImpressionError.IMPRESSION_ALREADY_VISIBLE);
      return;
    } 
    if (b.g()) {
      boolean bool1;
      boolean bool2;
      if (j) {
        if (f() != null && e1 != null) {
          e1.a(parama);
          return;
        } 
        if (f() == null) {
          CBLogging.b("Chartboost", "Activity not found to display the view");
          parama.a(CBError.CBImpressionError.NO_HOST_ACTIVITY);
        } else {
          CBLogging.b("Chartboost", "Missing view controller to manage the open impression activity");
        } 
        parama.a(CBError.CBImpressionError.ERROR_DISPLAYING_VIEW);
        return;
      } 
      if (!q()) {
        parama.a(CBError.CBImpressionError.NO_HOST_ACTIVITY);
        return;
      } 
      Activity activity = getHostActivity();
      if (activity == null) {
        CBLogging.b("Chartboost", "Failed to display impression as the host activity reference has been lost!");
        parama.a(CBError.CBImpressionError.NO_HOST_ACTIVITY);
        return;
      } 
      if (e != null && e != parama) {
        parama.a(CBError.CBImpressionError.IMPRESSION_ALREADY_VISIBLE);
        return;
      } 
      e = parama;
      Intent intent = new Intent((Context)activity, CBImpressionActivity.class);
      if (((activity.getWindow().getAttributes()).flags & 0x400) != 0) {
        bool1 = true;
      } else {
        bool1 = false;
      } 
      if (((activity.getWindow().getAttributes()).flags & 0x800) != 0) {
        bool2 = true;
      } else {
        bool2 = false;
      } 
      if (!bool1 || bool2)
        bool = false; 
      intent.putExtra("paramFullscreen", bool);
      try {
        activity.startActivity(intent);
        n = true;
        return;
      } catch (ActivityNotFoundException activityNotFoundException) {
        CBLogging.b("Chartboost", "Chartboost impression activity not declared in manifest. Please add the following inside your manifest's <application> tag: \n<activity android:name=\"com.chartboost.sdk.CBImpressionActivity\" android:theme=\"@android:style/Theme.Translucent.NoTitleBar\" android:excludeFromRecents=\"true\" />");
        return;
      } 
    } 
    e1 = h();
    if (e1 != null && q()) {
      e1.a((a)activityNotFoundException);
      return;
    } 
    activityNotFoundException.a(CBError.CBImpressionError.NO_HOST_ACTIVITY);
  }
  
  protected static void a(Runnable paramRunnable) {
    if (!CBUtility.b()) {
      a.post(paramRunnable);
      return;
    } 
    paramRunnable.run();
  }
  
  protected static void b() {
    if (b.g()) {
      a.postDelayed(r, 500L);
      return;
    } 
    c();
  }
  
  protected static void b(Activity paramActivity) {
    b(k.a(paramActivity), false);
    e = null;
  }
  
  private static void b(Activity paramActivity, boolean paramBoolean) {
    if (paramActivity == null)
      return; 
    a(paramActivity.hashCode(), paramBoolean);
  }
  
  protected static void b(k paramk) {
    a a1 = c.a().c();
    if (a1 != null)
      a1.v(); 
  }
  
  private static void b(k paramk, boolean paramBoolean) {}
  
  protected static void c() {
    p = false;
    if (i == null)
      i = a.a(); 
    i.c();
  }
  
  protected static void c(Activity paramActivity) {
    if (bg.a(paramActivity))
      return; 
    a.post(new Runnable(paramActivity) {
          public void run() {
            CBLogging.e("VideoInit", "preparing activity for video surface");
            SurfaceView surfaceView = new SurfaceView((Context)this.a);
            this.a.addContentView((View)surfaceView, new ViewGroup.LayoutParams(0, 0));
          }
        });
  }
  
  protected static void c(k paramk) {
    e e1 = h();
    if (g(paramk) && e1 != null) {
      a a1 = c.a().c();
      if (a1 != null) {
        e1.c(a1);
        e = a1;
      } 
      b(paramk, false);
      if (paramk.get() instanceof CBImpressionActivity)
        g(); 
    } 
    if (!(paramk.get() instanceof CBImpressionActivity))
      c(paramk, false); 
  }
  
  private static void c(k paramk, boolean paramBoolean) {
    if (paramk == null)
      return; 
    a(paramk.a(), paramBoolean);
  }
  
  public static void cacheInterstitial(String paramString) {
    a(new Runnable(paramString) {
          public void run() {
            if (b.p()) {
              if (TextUtils.isEmpty(this.a)) {
                CBLogging.b("Chartboost", "cacheInterstitial location cannot be empty");
                if (b.f() != null) {
                  b.f().didFailToLoadInterstitial(this.a, CBError.CBImpressionError.INVALID_LOCATION);
                  return;
                } 
                return;
              } 
              ae.f().b(this.a);
              return;
            } 
          }
        });
  }
  
  public static void cacheMoreApps(String paramString) {
    a(new Runnable(paramString) {
          public void run() {
            if (b.p()) {
              if (TextUtils.isEmpty(this.a)) {
                CBLogging.b("Chartboost", "cacheMoreApps location cannot be empty");
                if (b.f() != null) {
                  b.f().didFailToLoadMoreApps(this.a, CBError.CBImpressionError.INVALID_LOCATION);
                  return;
                } 
                return;
              } 
              av.f().b(this.a);
              return;
            } 
          }
        });
  }
  
  public static void cacheRewardedVideo(String paramString) {
    a(new Runnable(paramString) {
          public void run() {
            if (b.p()) {
              if (TextUtils.isEmpty(this.a)) {
                CBLogging.b("Chartboost", "cacheRewardedVideo location cannot be empty");
                if (b.f() != null) {
                  b.f().didFailToLoadRewardedVideo(this.a, CBError.CBImpressionError.INVALID_LOCATION);
                  return;
                } 
                return;
              } 
              af.h().b(this.a);
              return;
            } 
          }
        });
  }
  
  public static void clearCache() {
    if (!b.p())
      return; 
    bc.a().b();
    af.h().a();
    ae.f().a();
    av.f().a();
    a.b();
  }
  
  public static void closeImpression() {
    a(new Runnable() {
          public void run() {
            if (!b.p())
              return; 
            Chartboost.e();
          }
        });
  }
  
  protected static boolean d() {
    return e();
  }
  
  protected static boolean d(k paramk) {
    if (paramk != null) {
      Boolean bool = Boolean.valueOf(k.get(paramk.a()));
      if (bool != null)
        return bool.booleanValue(); 
    } 
    return false;
  }
  
  public static void didPassAgeGate(boolean paramBoolean) {
    b.d(paramBoolean);
  }
  
  private static void e(Activity paramActivity) {
    if (b != null && !b.b(paramActivity) && q()) {
      f(b);
      c(b, false);
    } 
    a.removeCallbacks(o);
    b = k.a(paramActivity);
    if (!getImpressionsUseActivities())
      c(paramActivity); 
    ba.d();
  }
  
  protected static boolean e() {
    c c1 = c.a();
    a a1 = c1.c();
    if (a1 != null && a1.b == a.b.c) {
      if (a1.s())
        return true; 
      a(new Runnable(c1) {
            public void run() {
              this.a.b();
            }
          });
      return true;
    } 
    e e1 = h();
    if (e1 != null && e1.b()) {
      a(new Runnable(e1, c1) {
            public void run() {
              this.a.a(this.b.c(), true);
            }
          });
      return true;
    } 
    return false;
  }
  
  protected static Activity f() {
    return b.g() ? d : getHostActivity();
  }
  
  private static void f(k paramk) {
    if (!b.g())
      c(paramk); 
    if (!(paramk.get() instanceof CBImpressionActivity))
      c(paramk, false); 
    f.c(b.x());
    if (!b.g())
      h.b(); 
    g.g();
    b();
  }
  
  private static boolean f(Activity paramActivity) {
    return b.g() ? (!(d != paramActivity)) : ((b == null) ? (!(paramActivity != null)) : b.b(paramActivity));
  }
  
  protected static void g() {
    if (j) {
      d = null;
      j = false;
    } 
  }
  
  private static boolean g(k paramk) {
    return b.g() ? ((paramk == null) ? (!(d != null)) : paramk.b(d)) : ((b == null) ? (!(paramk != null)) : b.a(paramk));
  }
  
  public static boolean getAutoCacheAds() {
    return b.i();
  }
  
  public static String getCustomId() {
    return b.n();
  }
  
  public static a getDelegate() {
    return b.f();
  }
  
  protected static Activity getHostActivity() {
    return (b != null) ? (Activity)b.get() : null;
  }
  
  public static boolean getImpressionsUseActivities() {
    return b.g();
  }
  
  public static CBLogging.Level getLoggingLevel() {
    return b.m();
  }
  
  protected static Context getValidContext() {
    return (b != null) ? b.b() : b.x();
  }
  
  protected static e h() {
    return (f() == null) ? null : l;
  }
  
  public static boolean hasInterstitial(String paramString) {
    return !b.p() ? false : ae.f().c(paramString);
  }
  
  public static boolean hasMoreApps(String paramString) {
    return !b.p() ? false : av.f().c(paramString);
  }
  
  public static boolean hasRewardedVideo(String paramString) {
    return !b.p() ? false : af.h().c(paramString);
  }
  
  public static boolean isAnyViewVisible() {
    e e1 = h();
    return (e1 == null) ? false : e1.c();
  }
  
  public static boolean onBackPressed() {
    if (b.s()) {
      if (b == null) {
        CBLogging.b("Chartboost", "The Chartboost methods onCreate(), onStart(), onStop(), and onDestroy() must be called in the corresponding methods of your activity in order for Chartboost to function properly.");
        return false;
      } 
      if (b.g()) {
        if (n) {
          n = false;
          d();
          return true;
        } 
        return false;
      } 
      return d();
    } 
    return false;
  }
  
  public static void onCreate(Activity paramActivity) {
    if (!b.s() || !b.a(paramActivity))
      return; 
    a(new Runnable(paramActivity) {
          public void run() {
            Chartboost.d(this.a);
          }
        });
  }
  
  public static void onDestroy(Activity paramActivity) {
    if (!b.s() || !b.a(paramActivity))
      return; 
    a(new Runnable(paramActivity) {
          public void run() {
            if (Chartboost.b == null || Chartboost.b.b(this.a)) {
              Chartboost.a.removeCallbacks(Chartboost.i());
              Chartboost.b(new Chartboost.a());
              Chartboost.a.postDelayed(Chartboost.i(), 10000L);
            } 
            Chartboost.b(this.a);
          }
        });
  }
  
  public static void onPause(Activity paramActivity) {
    if (!b.s() || !b.a(paramActivity))
      return; 
    a(new Runnable(paramActivity) {
          public void run() {
            k k = k.a(this.a);
            if (Chartboost.d(k))
              Chartboost.b(k); 
          }
        });
  }
  
  public static void onResume(Activity paramActivity) {
    if (!b.s() || !b.a(paramActivity))
      return; 
    a(new Runnable(paramActivity) {
          public void run() {
            k k = k.a(this.a);
            if (Chartboost.d(k)) {
              Chartboost.a(k);
              return;
            } 
            if (b.a() != null && b.a().ordinal() == Chartboost.CBFramework.CBFrameworkUnity.ordinal()) {
              Chartboost.a();
              return;
            } 
          }
        });
  }
  
  public static void onStart(Activity paramActivity) {
    if (!b.s() || !b.a(paramActivity))
      return; 
    a(new Runnable(paramActivity) {
          public void run() {
            Chartboost.a.removeCallbacks(Chartboost.i());
            if (Chartboost.b != null && !Chartboost.b.b(this.a) && Chartboost.j()) {
              Chartboost.e(Chartboost.b);
              Chartboost.a(Chartboost.b, false);
            } 
            Chartboost.a(this.a, true);
            Chartboost.b = k.a(this.a);
            Chartboost.a();
            Chartboost.a(this.a);
            Chartboost.k().b(b.x());
            if (!b.g())
              Chartboost.l().a(); 
            Chartboost.m().f();
          }
        });
  }
  
  public static void onStop(Activity paramActivity) {
    if (!b.s() || !b.a(paramActivity))
      return; 
    a(new Runnable(paramActivity) {
          public void run() {
            k k = k.a(this.a);
            if (Chartboost.d(k))
              Chartboost.e(k); 
          }
        });
  }
  
  private static void p() {
    p = true;
    b.c(true);
    i.h();
    a.b();
    b.a(new b.a() {
          public void a() {
            bd.b();
            az az = new az("api/install");
            az.b(Chartboost.getValidContext());
            az.a(true);
            az.a(new g.k[] { g.a("status", a.a) });
            az.a((az.c)new az.d(this) {
                  public void a(e.a param2a, az param2az) {
                    if (CBUtility.a(b.x())) {
                      String str = param2a.e("latest-sdk-version");
                      if (!TextUtils.isEmpty(str) && !str.equals("5.4.1"))
                        CBLogging.a(String.format(Locale.US, "Chartboost SDK is not up to date. (Current: %s, Latest: %s)\n Download latest SDK at:\n\thttps://www.chartboost.com/support/sdk_download/?os=ios", new Object[] { "5.4.1", str })); 
                    } 
                  }
                });
          }
        });
  }
  
  private static boolean q() {
    return d(b);
  }
  
  public static void setAutoCacheAds(boolean paramBoolean) {
    a(new Runnable(paramBoolean) {
          public void run() {
            b.b(this.a);
          }
        });
  }
  
  public static void setCustomId(String paramString) {
    a(new Runnable(paramString) {
          public void run() {
            b.d(this.a);
          }
        });
  }
  
  public static void setDelegate(ChartboostDelegate paramChartboostDelegate) {
    a(new Runnable(paramChartboostDelegate) {
          public void run() {
            b.a(this.a);
          }
        });
  }
  
  public static void setFramework(CBFramework paramCBFramework) {
    a(new Runnable(paramCBFramework) {
          public void run() {
            b.a(this.a);
          }
        });
  }
  
  public static void setFramework(CBFramework paramCBFramework, String paramString) {
    a(new Runnable(paramCBFramework, paramString) {
          public void run() {
            b.a(this.a, this.b);
          }
        });
  }
  
  public static void setFrameworkVersion(String paramString) {
    a(new Runnable(paramString) {
          public void run() {
            b.a(this.a);
          }
        });
  }
  
  public static void setImpressionsUseActivities(boolean paramBoolean) {
    a(new Runnable(paramBoolean) {
          public void run() {
            b.a(this.a);
          }
        });
  }
  
  public static void setLoggingLevel(CBLogging.Level paramLevel) {
    a(new Runnable(paramLevel) {
          public void run() {
            b.a(this.a);
          }
        });
  }
  
  public static void setShouldDisplayLoadingViewForMoreApps(boolean paramBoolean) {
    a(new Runnable(paramBoolean) {
          public void run() {
            b.g(this.a);
          }
        });
  }
  
  public static void setShouldPauseClickForConfirmation(boolean paramBoolean) {
    b.e(paramBoolean);
  }
  
  public static void setShouldPrefetchVideoContent(boolean paramBoolean) {
    a(new Runnable(paramBoolean) {
          public void run() {
            b.h(this.a);
            if (this.a) {
              bd.b();
              return;
            } 
            bd.d();
          }
        });
  }
  
  public static void setShouldRequestInterstitialsInFirstSession(boolean paramBoolean) {
    a(new Runnable(paramBoolean) {
          public void run() {
            b.f(this.a);
          }
        });
  }
  
  public static void showInterstitial(String paramString) {
    a(new Runnable(paramString) {
          public void run() {
            if (b.p()) {
              if (TextUtils.isEmpty(this.a)) {
                CBLogging.b("Chartboost", "showInterstitial location cannot be empty");
                if (b.f() != null) {
                  b.f().didFailToLoadInterstitial(this.a, CBError.CBImpressionError.INVALID_LOCATION);
                  return;
                } 
                return;
              } 
              ae.f().a(this.a);
              return;
            } 
          }
        });
  }
  
  private static void showInterstitialAIR(String paramString, boolean paramBoolean) {
    a(new Runnable(paramString, paramBoolean) {
          public void run() {
            ae.f().b(this.a, this.b);
          }
        });
  }
  
  public static void showMoreApps(String paramString) {
    a(new Runnable(paramString) {
          public void run() {
            if (b.p()) {
              if (TextUtils.isEmpty(this.a)) {
                CBLogging.b("Chartboost", "showMoreApps location cannot be empty");
                if (b.f() != null) {
                  b.f().didFailToLoadMoreApps(this.a, CBError.CBImpressionError.INVALID_LOCATION);
                  return;
                } 
                return;
              } 
              av.f().a(this.a);
              return;
            } 
          }
        });
  }
  
  private static void showMoreAppsAIR(String paramString, boolean paramBoolean) {
    a(new Runnable(paramString, paramBoolean) {
          public void run() {
            av.f().b(this.a, this.b);
          }
        });
  }
  
  public static void showRewardedVideo(String paramString) {
    a(new Runnable(paramString) {
          public void run() {
            if (b.p()) {
              if (TextUtils.isEmpty(this.a)) {
                CBLogging.b("Chartboost", "showRewardedVideo location cannot be empty");
                if (b.f() != null) {
                  b.f().didFailToLoadRewardedVideo(this.a, CBError.CBImpressionError.INVALID_LOCATION);
                  return;
                } 
                return;
              } 
              af.h().a(this.a);
              return;
            } 
          }
        });
  }
  
  private static void showRewardedVideoAIR(String paramString, boolean paramBoolean) {
    a(new Runnable(paramString, paramBoolean) {
          public void run() {
            af.h().b(this.a, this.b);
          }
        });
  }
  
  public static void startWithAppId(Activity paramActivity, String paramString1, String paramString2) {
    // Byte code:
    //   0: getstatic com/chartboost/sdk/Chartboost.c : Lcom/chartboost/sdk/Chartboost;
    //   3: ifnonnull -> 105
    //   6: ldc com/chartboost/sdk/Chartboost
    //   8: monitorenter
    //   9: getstatic com/chartboost/sdk/Chartboost.c : Lcom/chartboost/sdk/Chartboost;
    //   12: ifnonnull -> 102
    //   15: aload_0
    //   16: ifnonnull -> 38
    //   19: aload_0
    //   20: instanceof android/app/Activity
    //   23: ifne -> 38
    //   26: ldc 'Chartboost'
    //   28: ldc_w 'Activity object is null. Please pass a valid activity object'
    //   31: invokestatic b : (Ljava/lang/Object;Ljava/lang/String;)V
    //   34: ldc com/chartboost/sdk/Chartboost
    //   36: monitorexit
    //   37: return
    //   38: aload_0
    //   39: invokestatic b : (Landroid/content/Context;)Z
    //   42: ifne -> 63
    //   45: ldc 'Chartboost'
    //   47: ldc_w 'Permissions not set correctly'
    //   50: invokestatic b : (Ljava/lang/Object;Ljava/lang/String;)V
    //   53: ldc com/chartboost/sdk/Chartboost
    //   55: monitorexit
    //   56: return
    //   57: astore_0
    //   58: ldc com/chartboost/sdk/Chartboost
    //   60: monitorexit
    //   61: aload_0
    //   62: athrow
    //   63: aload_1
    //   64: invokestatic isEmpty : (Ljava/lang/CharSequence;)Z
    //   67: ifne -> 77
    //   70: aload_2
    //   71: invokestatic isEmpty : (Ljava/lang/CharSequence;)Z
    //   74: ifeq -> 89
    //   77: ldc 'Chartboost'
    //   79: ldc_w 'AppId or AppSignature is null. Please pass a valid id's'
    //   82: invokestatic b : (Ljava/lang/Object;Ljava/lang/String;)V
    //   85: ldc com/chartboost/sdk/Chartboost
    //   87: monitorexit
    //   88: return
    //   89: new com/chartboost/sdk/Chartboost$1
    //   92: dup
    //   93: aload_0
    //   94: aload_1
    //   95: aload_2
    //   96: invokespecial <init> : (Landroid/app/Activity;Ljava/lang/String;Ljava/lang/String;)V
    //   99: invokestatic a : (Ljava/lang/Runnable;)V
    //   102: ldc com/chartboost/sdk/Chartboost
    //   104: monitorexit
    //   105: return
    // Exception table:
    //   from	to	target	type
    //   9	15	57	finally
    //   19	37	57	finally
    //   38	56	57	finally
    //   58	61	57	finally
    //   63	77	57	finally
    //   77	88	57	finally
    //   89	102	57	finally
    //   102	105	57	finally
  }
  
  public enum CBFramework {
    CBFrameworkAir,
    CBFrameworkCocoonJS,
    CBFrameworkCocos2dx,
    CBFrameworkCordova,
    CBFrameworkCorona,
    CBFrameworkFyber,
    CBFrameworkGameSalad,
    CBFrameworkMoPub,
    CBFrameworkPrime31Unreal,
    CBFrameworkUnity("Unity"),
    CBFrameworkWeeby("Unity");
    
    private final String a;
    
    static {
      CBFrameworkAir = new CBFramework("CBFrameworkAir", 2, "AIR");
      CBFrameworkGameSalad = new CBFramework("CBFrameworkGameSalad", 3, "GameSalad");
      CBFrameworkCordova = new CBFramework("CBFrameworkCordova", 4, "Cordova");
      CBFrameworkCocoonJS = new CBFramework("CBFrameworkCocoonJS", 5, "CocoonJS");
      CBFrameworkCocos2dx = new CBFramework("CBFrameworkCocos2dx", 6, "Cocos2dx");
      CBFrameworkMoPub = new CBFramework("CBFrameworkMoPub", 7, "MoPub");
      CBFrameworkFyber = new CBFramework("CBFrameworkFyber", 8, "Fyber");
      CBFrameworkPrime31Unreal = new CBFramework("CBFrameworkPrime31Unreal", 9, "Prime31Unreal");
      CBFrameworkWeeby = new CBFramework("CBFrameworkWeeby", 10, "Weeby");
      b = new CBFramework[] { 
          CBFrameworkUnity, CBFrameworkCorona, CBFrameworkAir, CBFrameworkGameSalad, CBFrameworkCordova, CBFrameworkCocoonJS, CBFrameworkCocos2dx, CBFrameworkMoPub, CBFrameworkFyber, CBFrameworkPrime31Unreal, 
          CBFrameworkWeeby };
    }
    
    CBFramework(String param1String1) {
      this.a = param1String1;
    }
    
    public boolean doesWrapperUseCustomBackgroundingBehavior() {
      return (this == CBFrameworkAir);
    }
    
    public boolean doesWrapperUseCustomShouldDisplayBehavior() {
      return (this == CBFrameworkAir || this == CBFrameworkCocos2dx);
    }
    
    public String toString() {
      return this.a;
    }
  }
  
  private static class a implements Runnable {
    private int a;
    
    private int b;
    
    private int c;
    
    private a() {
      int i;
      a a1 = a();
      if (Chartboost.o() == null) {
        i = -1;
      } else {
        i = Chartboost.o().hashCode();
      } 
      this.a = i;
      if (Chartboost.b == null) {
        i = -1;
      } else {
        i = Chartboost.b.hashCode();
      } 
      this.b = i;
      if (a1 == null) {
        i = b;
      } else {
        i = a1.hashCode();
      } 
      this.c = i;
    }
    
    private a a() {
      return b.f();
    }
    
    public void run() {
      a a1 = a();
      if (b.x() != null)
        Chartboost.clearCache(); 
      if (Chartboost.b != null && Chartboost.b.hashCode() == this.b)
        Chartboost.b = null; 
      if (Chartboost.o() != null && Chartboost.o().hashCode() == this.a)
        Chartboost.b((CBImpressionActivity)null); 
      if (a1 != null && a1.hashCode() == this.c)
        b.a((a)null); 
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Smash Cricket-dex2jar.jar!\com\chartboost\sdk\Chartboost.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */