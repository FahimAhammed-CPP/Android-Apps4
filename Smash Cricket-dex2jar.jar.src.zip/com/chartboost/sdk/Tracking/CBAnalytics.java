package com.chartboost.sdk.Tracking;

import com.chartboost.sdk.Libraries.CBLogging;
import com.chartboost.sdk.Libraries.e;
import com.chartboost.sdk.Libraries.h;
import com.chartboost.sdk.Model.CBError;
import com.chartboost.sdk.b;
import com.chartboost.sdk.impl.az;
import com.chartboost.sdk.impl.ba;
import java.io.File;
import java.util.EnumMap;
import java.util.concurrent.ConcurrentHashMap;

public class CBAnalytics {
  private static void a(e.a parama, String paramString) {
    // Byte code:
    //   0: ldc com/chartboost/sdk/Tracking/CBAnalytics
    //   2: monitorenter
    //   3: new com/chartboost/sdk/impl/az
    //   6: dup
    //   7: ldc '/post-install-event/'
    //   9: ldc 'tracking'
    //   11: invokevirtual concat : (Ljava/lang/String;)Ljava/lang/String;
    //   14: invokespecial <init> : (Ljava/lang/String;)V
    //   17: astore_2
    //   18: aload_2
    //   19: ldc 'track_info'
    //   21: aload_0
    //   22: invokevirtual a : (Ljava/lang/String;Ljava/lang/Object;)V
    //   25: aload_2
    //   26: iconst_1
    //   27: anewarray com/chartboost/sdk/Libraries/g$k
    //   30: dup
    //   31: iconst_0
    //   32: ldc 'status'
    //   34: getstatic com/chartboost/sdk/Libraries/a.a : Lcom/chartboost/sdk/Libraries/g$a;
    //   37: invokestatic a : (Ljava/lang/String;Lcom/chartboost/sdk/Libraries/g$a;)Lcom/chartboost/sdk/Libraries/g$k;
    //   40: aastore
    //   41: invokestatic a : ([Lcom/chartboost/sdk/Libraries/g$k;)Lcom/chartboost/sdk/Libraries/g$a;
    //   44: invokevirtual a : (Lcom/chartboost/sdk/Libraries/g$a;)V
    //   47: aload_2
    //   48: aload_1
    //   49: invokevirtual b : (Ljava/lang/String;)V
    //   52: aload_2
    //   53: iconst_1
    //   54: invokevirtual a : (Z)V
    //   57: aload_2
    //   58: invokevirtual s : ()V
    //   61: ldc com/chartboost/sdk/Tracking/CBAnalytics
    //   63: monitorexit
    //   64: return
    //   65: astore_0
    //   66: ldc com/chartboost/sdk/Tracking/CBAnalytics
    //   68: monitorexit
    //   69: aload_0
    //   70: athrow
    // Exception table:
    //   from	to	target	type
    //   3	61	65	finally
  }
  
  private static void a(e.a parama, String paramString, CBIAPType paramCBIAPType) {
    // Byte code:
    //   0: ldc com/chartboost/sdk/Tracking/CBAnalytics
    //   2: monitorenter
    //   3: new com/chartboost/sdk/impl/az
    //   6: dup
    //   7: getstatic java/util/Locale.US : Ljava/util/Locale;
    //   10: ldc '%s%s'
    //   12: iconst_2
    //   13: anewarray java/lang/Object
    //   16: dup
    //   17: iconst_0
    //   18: ldc '/post-install-event/'
    //   20: aastore
    //   21: dup
    //   22: iconst_1
    //   23: aload_1
    //   24: aastore
    //   25: invokestatic format : (Ljava/util/Locale;Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/String;
    //   28: invokespecial <init> : (Ljava/lang/String;)V
    //   31: astore_3
    //   32: aload_3
    //   33: aload_1
    //   34: aload_0
    //   35: invokevirtual a : (Ljava/lang/String;Ljava/lang/Object;)V
    //   38: aload_3
    //   39: iconst_1
    //   40: anewarray com/chartboost/sdk/Libraries/g$k
    //   43: dup
    //   44: iconst_0
    //   45: ldc 'status'
    //   47: getstatic com/chartboost/sdk/Libraries/a.a : Lcom/chartboost/sdk/Libraries/g$a;
    //   50: invokestatic a : (Ljava/lang/String;Lcom/chartboost/sdk/Libraries/g$a;)Lcom/chartboost/sdk/Libraries/g$k;
    //   53: aastore
    //   54: invokestatic a : ([Lcom/chartboost/sdk/Libraries/g$k;)Lcom/chartboost/sdk/Libraries/g$a;
    //   57: invokevirtual a : (Lcom/chartboost/sdk/Libraries/g$a;)V
    //   60: aload_3
    //   61: aload_1
    //   62: invokevirtual b : (Ljava/lang/String;)V
    //   65: aload_3
    //   66: iconst_1
    //   67: invokevirtual a : (Z)V
    //   70: aload_3
    //   71: new com/chartboost/sdk/Tracking/CBAnalytics$1
    //   74: dup
    //   75: aload_1
    //   76: aload_2
    //   77: invokespecial <init> : (Ljava/lang/String;Lcom/chartboost/sdk/Tracking/CBAnalytics$CBIAPType;)V
    //   80: invokevirtual a : (Lcom/chartboost/sdk/impl/az$c;)V
    //   83: ldc com/chartboost/sdk/Tracking/CBAnalytics
    //   85: monitorexit
    //   86: return
    //   87: astore_0
    //   88: ldc com/chartboost/sdk/Tracking/CBAnalytics
    //   90: monitorexit
    //   91: aload_0
    //   92: athrow
    // Exception table:
    //   from	to	target	type
    //   3	83	87	finally
  }
  
  private static void a(String paramString1, String paramString2, String paramString3, String paramString4, String paramString5, String paramString6, String paramString7, String paramString8, String paramString9, CBIAPType paramCBIAPType) {
    // Byte code:
    //   0: ldc com/chartboost/sdk/Tracking/CBAnalytics
    //   2: monitorenter
    //   3: invokestatic x : ()Landroid/content/Context;
    //   6: ifnonnull -> 20
    //   9: ldc 'CBPostInstallTracker'
    //   11: ldc 'You need call Chartboost.init() before calling any public API's'
    //   13: invokestatic b : (Ljava/lang/Object;Ljava/lang/String;)V
    //   16: ldc com/chartboost/sdk/Tracking/CBAnalytics
    //   18: monitorexit
    //   19: return
    //   20: invokestatic o : ()Z
    //   23: ifne -> 42
    //   26: ldc 'CBPostInstallTracker'
    //   28: ldc 'You need call Chartboost.OnStart() before tracking in-app purchases'
    //   30: invokestatic b : (Ljava/lang/Object;Ljava/lang/String;)V
    //   33: goto -> 16
    //   36: astore_0
    //   37: ldc com/chartboost/sdk/Tracking/CBAnalytics
    //   39: monitorexit
    //   40: aload_0
    //   41: athrow
    //   42: aload_0
    //   43: invokestatic isEmpty : (Ljava/lang/CharSequence;)Z
    //   46: ifne -> 78
    //   49: aload_1
    //   50: invokestatic isEmpty : (Ljava/lang/CharSequence;)Z
    //   53: ifne -> 78
    //   56: aload_2
    //   57: invokestatic isEmpty : (Ljava/lang/CharSequence;)Z
    //   60: ifne -> 78
    //   63: aload_3
    //   64: invokestatic isEmpty : (Ljava/lang/CharSequence;)Z
    //   67: ifne -> 78
    //   70: aload #4
    //   72: invokestatic isEmpty : (Ljava/lang/CharSequence;)Z
    //   75: ifeq -> 88
    //   78: ldc 'CBPostInstallTracker'
    //   80: ldc 'Null object is passed. Please pass a valid value object'
    //   82: invokestatic b : (Ljava/lang/Object;Ljava/lang/String;)V
    //   85: goto -> 16
    //   88: ldc '(\d+\.\d+)|(\d+)'
    //   90: invokestatic compile : (Ljava/lang/String;)Ljava/util/regex/Pattern;
    //   93: aload_3
    //   94: invokevirtual matcher : (Ljava/lang/CharSequence;)Ljava/util/regex/Matcher;
    //   97: astore_3
    //   98: aload_3
    //   99: invokevirtual find : ()Z
    //   102: pop
    //   103: aload_3
    //   104: invokevirtual group : ()Ljava/lang/String;
    //   107: astore_3
    //   108: aload_3
    //   109: invokestatic isEmpty : (Ljava/lang/CharSequence;)Z
    //   112: ifeq -> 136
    //   115: ldc 'CBPostInstallTracker'
    //   117: ldc 'Invalid price object'
    //   119: invokestatic b : (Ljava/lang/Object;Ljava/lang/String;)V
    //   122: goto -> 16
    //   125: astore_0
    //   126: ldc 'CBPostInstallTracker'
    //   128: ldc 'Invalid price object'
    //   130: invokestatic b : (Ljava/lang/Object;Ljava/lang/String;)V
    //   133: goto -> 16
    //   136: aload_3
    //   137: invokestatic parseFloat : (Ljava/lang/String;)F
    //   140: fstore #10
    //   142: aconst_null
    //   143: astore_3
    //   144: aload #9
    //   146: getstatic com/chartboost/sdk/Tracking/CBAnalytics$CBIAPType.GOOGLE_PLAY : Lcom/chartboost/sdk/Tracking/CBAnalytics$CBIAPType;
    //   149: if_acmpne -> 237
    //   152: aload #5
    //   154: invokestatic isEmpty : (Ljava/lang/CharSequence;)Z
    //   157: ifne -> 168
    //   160: aload #6
    //   162: invokestatic isEmpty : (Ljava/lang/CharSequence;)Z
    //   165: ifeq -> 178
    //   168: ldc 'CBPostInstallTracker'
    //   170: ldc 'Null object is passed for for purchase data or purchase signature'
    //   172: invokestatic b : (Ljava/lang/Object;Ljava/lang/String;)V
    //   175: goto -> 16
    //   178: iconst_3
    //   179: anewarray com/chartboost/sdk/Libraries/e$b
    //   182: dup
    //   183: iconst_0
    //   184: ldc 'purchaseData'
    //   186: aload #5
    //   188: invokestatic a : (Ljava/lang/String;Ljava/lang/Object;)Lcom/chartboost/sdk/Libraries/e$b;
    //   191: aastore
    //   192: dup
    //   193: iconst_1
    //   194: ldc 'purchaseSignature'
    //   196: aload #6
    //   198: invokestatic a : (Ljava/lang/String;Ljava/lang/Object;)Lcom/chartboost/sdk/Libraries/e$b;
    //   201: aastore
    //   202: dup
    //   203: iconst_2
    //   204: ldc 'type'
    //   206: getstatic com/chartboost/sdk/Tracking/CBAnalytics$CBIAPType.GOOGLE_PLAY : Lcom/chartboost/sdk/Tracking/CBAnalytics$CBIAPType;
    //   209: invokevirtual ordinal : ()I
    //   212: invokestatic valueOf : (I)Ljava/lang/Integer;
    //   215: invokestatic a : (Ljava/lang/String;Ljava/lang/Object;)Lcom/chartboost/sdk/Libraries/e$b;
    //   218: aastore
    //   219: invokestatic a : ([Lcom/chartboost/sdk/Libraries/e$b;)Lcom/chartboost/sdk/Libraries/e$a;
    //   222: astore_3
    //   223: aload_3
    //   224: ifnonnull -> 319
    //   227: ldc 'CBPostInstallTracker'
    //   229: ldc 'Error while parsing the receipt to a JSON Object, '
    //   231: invokestatic b : (Ljava/lang/Object;Ljava/lang/String;)V
    //   234: goto -> 16
    //   237: aload #9
    //   239: getstatic com/chartboost/sdk/Tracking/CBAnalytics$CBIAPType.AMAZON : Lcom/chartboost/sdk/Tracking/CBAnalytics$CBIAPType;
    //   242: if_acmpne -> 223
    //   245: aload #7
    //   247: invokestatic isEmpty : (Ljava/lang/CharSequence;)Z
    //   250: ifne -> 261
    //   253: aload #8
    //   255: invokestatic isEmpty : (Ljava/lang/CharSequence;)Z
    //   258: ifeq -> 271
    //   261: ldc 'CBPostInstallTracker'
    //   263: ldc 'Null object is passed for for amazon user id or amazon purchase token'
    //   265: invokestatic b : (Ljava/lang/Object;Ljava/lang/String;)V
    //   268: goto -> 16
    //   271: iconst_3
    //   272: anewarray com/chartboost/sdk/Libraries/e$b
    //   275: dup
    //   276: iconst_0
    //   277: ldc 'userID'
    //   279: aload #7
    //   281: invokestatic a : (Ljava/lang/String;Ljava/lang/Object;)Lcom/chartboost/sdk/Libraries/e$b;
    //   284: aastore
    //   285: dup
    //   286: iconst_1
    //   287: ldc 'purchaseToken'
    //   289: aload #8
    //   291: invokestatic a : (Ljava/lang/String;Ljava/lang/Object;)Lcom/chartboost/sdk/Libraries/e$b;
    //   294: aastore
    //   295: dup
    //   296: iconst_2
    //   297: ldc 'type'
    //   299: getstatic com/chartboost/sdk/Tracking/CBAnalytics$CBIAPType.AMAZON : Lcom/chartboost/sdk/Tracking/CBAnalytics$CBIAPType;
    //   302: invokevirtual ordinal : ()I
    //   305: invokestatic valueOf : (I)Ljava/lang/Integer;
    //   308: invokestatic a : (Ljava/lang/String;Ljava/lang/Object;)Lcom/chartboost/sdk/Libraries/e$b;
    //   311: aastore
    //   312: invokestatic a : ([Lcom/chartboost/sdk/Libraries/e$b;)Lcom/chartboost/sdk/Libraries/e$a;
    //   315: astore_3
    //   316: goto -> 223
    //   319: aload_3
    //   320: invokevirtual toString : ()Ljava/lang/String;
    //   323: invokevirtual getBytes : ()[B
    //   326: iconst_2
    //   327: invokestatic encodeToString : ([BI)Ljava/lang/String;
    //   330: astore_3
    //   331: bipush #6
    //   333: anewarray com/chartboost/sdk/Libraries/e$b
    //   336: dup
    //   337: iconst_0
    //   338: ldc 'localized-title'
    //   340: aload_1
    //   341: invokestatic a : (Ljava/lang/String;Ljava/lang/Object;)Lcom/chartboost/sdk/Libraries/e$b;
    //   344: aastore
    //   345: dup
    //   346: iconst_1
    //   347: ldc 'localized-description'
    //   349: aload_2
    //   350: invokestatic a : (Ljava/lang/String;Ljava/lang/Object;)Lcom/chartboost/sdk/Libraries/e$b;
    //   353: aastore
    //   354: dup
    //   355: iconst_2
    //   356: ldc 'price'
    //   358: fload #10
    //   360: invokestatic valueOf : (F)Ljava/lang/Float;
    //   363: invokestatic a : (Ljava/lang/String;Ljava/lang/Object;)Lcom/chartboost/sdk/Libraries/e$b;
    //   366: aastore
    //   367: dup
    //   368: iconst_3
    //   369: ldc 'currency'
    //   371: aload #4
    //   373: invokestatic a : (Ljava/lang/String;Ljava/lang/Object;)Lcom/chartboost/sdk/Libraries/e$b;
    //   376: aastore
    //   377: dup
    //   378: iconst_4
    //   379: ldc 'productID'
    //   381: aload_0
    //   382: invokestatic a : (Ljava/lang/String;Ljava/lang/Object;)Lcom/chartboost/sdk/Libraries/e$b;
    //   385: aastore
    //   386: dup
    //   387: iconst_5
    //   388: ldc 'receipt'
    //   390: aload_3
    //   391: invokestatic a : (Ljava/lang/String;Ljava/lang/Object;)Lcom/chartboost/sdk/Libraries/e$b;
    //   394: aastore
    //   395: invokestatic a : ([Lcom/chartboost/sdk/Libraries/e$b;)Lcom/chartboost/sdk/Libraries/e$a;
    //   398: ldc 'iap'
    //   400: aload #9
    //   402: invokestatic a : (Lcom/chartboost/sdk/Libraries/e$a;Ljava/lang/String;Lcom/chartboost/sdk/Tracking/CBAnalytics$CBIAPType;)V
    //   405: goto -> 16
    // Exception table:
    //   from	to	target	type
    //   3	16	36	finally
    //   20	33	36	finally
    //   42	78	36	finally
    //   78	85	36	finally
    //   88	122	125	java/lang/IllegalStateException
    //   88	122	36	finally
    //   126	133	36	finally
    //   136	142	125	java/lang/IllegalStateException
    //   136	142	36	finally
    //   144	168	36	finally
    //   168	175	36	finally
    //   178	223	36	finally
    //   227	234	36	finally
    //   237	261	36	finally
    //   261	268	36	finally
    //   271	316	36	finally
    //   319	405	36	finally
  }
  
  public static void trackInAppAmazonStorePurchaseEvent(String paramString1, String paramString2, String paramString3, String paramString4, String paramString5, String paramString6, String paramString7) {
    // Byte code:
    //   0: ldc com/chartboost/sdk/Tracking/CBAnalytics
    //   2: monitorenter
    //   3: aload #4
    //   5: aload_0
    //   6: aload_1
    //   7: aload_2
    //   8: aload_3
    //   9: aconst_null
    //   10: aconst_null
    //   11: aload #5
    //   13: aload #6
    //   15: getstatic com/chartboost/sdk/Tracking/CBAnalytics$CBIAPType.AMAZON : Lcom/chartboost/sdk/Tracking/CBAnalytics$CBIAPType;
    //   18: invokestatic a : (Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Lcom/chartboost/sdk/Tracking/CBAnalytics$CBIAPType;)V
    //   21: ldc com/chartboost/sdk/Tracking/CBAnalytics
    //   23: monitorexit
    //   24: return
    //   25: astore_0
    //   26: ldc com/chartboost/sdk/Tracking/CBAnalytics
    //   28: monitorexit
    //   29: aload_0
    //   30: athrow
    // Exception table:
    //   from	to	target	type
    //   3	21	25	finally
  }
  
  public static void trackInAppGooglePlayPurchaseEvent(String paramString1, String paramString2, String paramString3, String paramString4, String paramString5, String paramString6, String paramString7) {
    // Byte code:
    //   0: ldc com/chartboost/sdk/Tracking/CBAnalytics
    //   2: monitorenter
    //   3: aload #4
    //   5: aload_0
    //   6: aload_1
    //   7: aload_2
    //   8: aload_3
    //   9: aload #5
    //   11: aload #6
    //   13: aconst_null
    //   14: aconst_null
    //   15: getstatic com/chartboost/sdk/Tracking/CBAnalytics$CBIAPType.GOOGLE_PLAY : Lcom/chartboost/sdk/Tracking/CBAnalytics$CBIAPType;
    //   18: invokestatic a : (Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Lcom/chartboost/sdk/Tracking/CBAnalytics$CBIAPType;)V
    //   21: ldc com/chartboost/sdk/Tracking/CBAnalytics
    //   23: monitorexit
    //   24: return
    //   25: astore_0
    //   26: ldc com/chartboost/sdk/Tracking/CBAnalytics
    //   28: monitorexit
    //   29: aload_0
    //   30: athrow
    // Exception table:
    //   from	to	target	type
    //   3	21	25	finally
  }
  
  public static void trackLevelInfo(String paramString1, CBLevelType paramCBLevelType, int paramInt1, int paramInt2, String paramString2) {
    // Byte code:
    //   0: ldc com/chartboost/sdk/Tracking/CBAnalytics
    //   2: monitorenter
    //   3: aload_0
    //   4: invokestatic isEmpty : (Ljava/lang/CharSequence;)Z
    //   7: ifeq -> 21
    //   10: ldc 'CBPostInstallTracker'
    //   12: ldc 'Invalid value: event label cannot be empty or null'
    //   14: invokestatic b : (Ljava/lang/Object;Ljava/lang/String;)V
    //   17: ldc com/chartboost/sdk/Tracking/CBAnalytics
    //   19: monitorexit
    //   20: return
    //   21: aload_1
    //   22: ifnull -> 32
    //   25: aload_1
    //   26: instanceof com/chartboost/sdk/Tracking/CBAnalytics$CBLevelType
    //   29: ifne -> 48
    //   32: ldc 'CBPostInstallTracker'
    //   34: ldc 'Invalid value: level type cannot be empty or null, please choose from one of the CBLevelType enum values'
    //   36: invokestatic b : (Ljava/lang/Object;Ljava/lang/String;)V
    //   39: goto -> 17
    //   42: astore_0
    //   43: ldc com/chartboost/sdk/Tracking/CBAnalytics
    //   45: monitorexit
    //   46: aload_0
    //   47: athrow
    //   48: iload_2
    //   49: iflt -> 56
    //   52: iload_3
    //   53: ifge -> 66
    //   56: ldc 'CBPostInstallTracker'
    //   58: ldc 'Invalid value: Level number should be > 0'
    //   60: invokestatic b : (Ljava/lang/Object;Ljava/lang/String;)V
    //   63: goto -> 17
    //   66: aload #4
    //   68: invokevirtual isEmpty : ()Z
    //   71: ifeq -> 84
    //   74: ldc 'CBPostInstallTracker'
    //   76: ldc 'Invalid value: description cannot be empty or null'
    //   78: invokestatic b : (Ljava/lang/Object;Ljava/lang/String;)V
    //   81: goto -> 17
    //   84: bipush #7
    //   86: anewarray com/chartboost/sdk/Libraries/e$b
    //   89: dup
    //   90: iconst_0
    //   91: ldc 'event_label'
    //   93: aload_0
    //   94: invokestatic a : (Ljava/lang/String;Ljava/lang/Object;)Lcom/chartboost/sdk/Libraries/e$b;
    //   97: aastore
    //   98: dup
    //   99: iconst_1
    //   100: ldc 'event_field'
    //   102: aload_1
    //   103: invokevirtual getLevelType : ()I
    //   106: invokestatic valueOf : (I)Ljava/lang/Integer;
    //   109: invokestatic a : (Ljava/lang/String;Ljava/lang/Object;)Lcom/chartboost/sdk/Libraries/e$b;
    //   112: aastore
    //   113: dup
    //   114: iconst_2
    //   115: ldc 'main_level'
    //   117: iload_2
    //   118: invokestatic valueOf : (I)Ljava/lang/Integer;
    //   121: invokestatic a : (Ljava/lang/String;Ljava/lang/Object;)Lcom/chartboost/sdk/Libraries/e$b;
    //   124: aastore
    //   125: dup
    //   126: iconst_3
    //   127: ldc_w 'sub_level'
    //   130: iload_3
    //   131: invokestatic valueOf : (I)Ljava/lang/Integer;
    //   134: invokestatic a : (Ljava/lang/String;Ljava/lang/Object;)Lcom/chartboost/sdk/Libraries/e$b;
    //   137: aastore
    //   138: dup
    //   139: iconst_4
    //   140: ldc_w 'description'
    //   143: aload #4
    //   145: invokestatic a : (Ljava/lang/String;Ljava/lang/Object;)Lcom/chartboost/sdk/Libraries/e$b;
    //   148: aastore
    //   149: dup
    //   150: iconst_5
    //   151: ldc_w 'timestamp'
    //   154: invokestatic currentTimeMillis : ()J
    //   157: invokestatic valueOf : (J)Ljava/lang/Long;
    //   160: invokestatic a : (Ljava/lang/String;Ljava/lang/Object;)Lcom/chartboost/sdk/Libraries/e$b;
    //   163: aastore
    //   164: dup
    //   165: bipush #6
    //   167: ldc_w 'data_type'
    //   170: ldc_w 'level_info'
    //   173: invokestatic a : (Ljava/lang/String;Ljava/lang/Object;)Lcom/chartboost/sdk/Libraries/e$b;
    //   176: aastore
    //   177: invokestatic a : ([Lcom/chartboost/sdk/Libraries/e$b;)Lcom/chartboost/sdk/Libraries/e$a;
    //   180: ldc 'tracking'
    //   182: invokestatic a : (Lcom/chartboost/sdk/Libraries/e$a;Ljava/lang/String;)V
    //   185: goto -> 17
    // Exception table:
    //   from	to	target	type
    //   3	17	42	finally
    //   25	32	42	finally
    //   32	39	42	finally
    //   56	63	42	finally
    //   66	81	42	finally
    //   84	185	42	finally
  }
  
  public static void trackLevelInfo(String paramString1, CBLevelType paramCBLevelType, int paramInt, String paramString2) {
    // Byte code:
    //   0: ldc com/chartboost/sdk/Tracking/CBAnalytics
    //   2: monitorenter
    //   3: aload_0
    //   4: aload_1
    //   5: iload_2
    //   6: iconst_0
    //   7: aload_3
    //   8: invokestatic trackLevelInfo : (Ljava/lang/String;Lcom/chartboost/sdk/Tracking/CBAnalytics$CBLevelType;IILjava/lang/String;)V
    //   11: ldc com/chartboost/sdk/Tracking/CBAnalytics
    //   13: monitorexit
    //   14: return
    //   15: astore_0
    //   16: ldc com/chartboost/sdk/Tracking/CBAnalytics
    //   18: monitorexit
    //   19: aload_0
    //   20: athrow
    // Exception table:
    //   from	to	target	type
    //   3	11	15	finally
  }
  
  public void trackInAppPurchaseEvent(EnumMap<CBIAPPurchaseInfo, String> paramEnumMap, CBIAPType paramCBIAPType) {
    // Byte code:
    //   0: aload_0
    //   1: monitorenter
    //   2: aload_1
    //   3: ifnull -> 90
    //   6: aload_2
    //   7: ifnull -> 90
    //   10: aload_1
    //   11: getstatic com/chartboost/sdk/Tracking/CBAnalytics$CBIAPPurchaseInfo.PRODUCT_ID : Lcom/chartboost/sdk/Tracking/CBAnalytics$CBIAPPurchaseInfo;
    //   14: invokevirtual get : (Ljava/lang/Object;)Ljava/lang/Object;
    //   17: checkcast java/lang/CharSequence
    //   20: invokestatic isEmpty : (Ljava/lang/CharSequence;)Z
    //   23: ifne -> 90
    //   26: aload_1
    //   27: getstatic com/chartboost/sdk/Tracking/CBAnalytics$CBIAPPurchaseInfo.PRODUCT_TITLE : Lcom/chartboost/sdk/Tracking/CBAnalytics$CBIAPPurchaseInfo;
    //   30: invokevirtual get : (Ljava/lang/Object;)Ljava/lang/Object;
    //   33: checkcast java/lang/CharSequence
    //   36: invokestatic isEmpty : (Ljava/lang/CharSequence;)Z
    //   39: ifne -> 90
    //   42: aload_1
    //   43: getstatic com/chartboost/sdk/Tracking/CBAnalytics$CBIAPPurchaseInfo.PRODUCT_DESCRIPTION : Lcom/chartboost/sdk/Tracking/CBAnalytics$CBIAPPurchaseInfo;
    //   46: invokevirtual get : (Ljava/lang/Object;)Ljava/lang/Object;
    //   49: checkcast java/lang/CharSequence
    //   52: invokestatic isEmpty : (Ljava/lang/CharSequence;)Z
    //   55: ifne -> 90
    //   58: aload_1
    //   59: getstatic com/chartboost/sdk/Tracking/CBAnalytics$CBIAPPurchaseInfo.PRODUCT_PRICE : Lcom/chartboost/sdk/Tracking/CBAnalytics$CBIAPPurchaseInfo;
    //   62: invokevirtual get : (Ljava/lang/Object;)Ljava/lang/Object;
    //   65: checkcast java/lang/CharSequence
    //   68: invokestatic isEmpty : (Ljava/lang/CharSequence;)Z
    //   71: ifne -> 90
    //   74: aload_1
    //   75: getstatic com/chartboost/sdk/Tracking/CBAnalytics$CBIAPPurchaseInfo.PRODUCT_CURRENCY_CODE : Lcom/chartboost/sdk/Tracking/CBAnalytics$CBIAPPurchaseInfo;
    //   78: invokevirtual get : (Ljava/lang/Object;)Ljava/lang/Object;
    //   81: checkcast java/lang/CharSequence
    //   84: invokestatic isEmpty : (Ljava/lang/CharSequence;)Z
    //   87: ifeq -> 100
    //   90: ldc 'CBPostInstallTracker'
    //   92: ldc 'Null object is passed. Please pass a valid value object'
    //   94: invokestatic b : (Ljava/lang/Object;Ljava/lang/String;)V
    //   97: aload_0
    //   98: monitorexit
    //   99: return
    //   100: aload_1
    //   101: getstatic com/chartboost/sdk/Tracking/CBAnalytics$CBIAPPurchaseInfo.GOOGLE_PURCHASE_DATA : Lcom/chartboost/sdk/Tracking/CBAnalytics$CBIAPPurchaseInfo;
    //   104: invokevirtual get : (Ljava/lang/Object;)Ljava/lang/Object;
    //   107: checkcast java/lang/String
    //   110: astore_3
    //   111: aload_1
    //   112: getstatic com/chartboost/sdk/Tracking/CBAnalytics$CBIAPPurchaseInfo.GOOGLE_PURCHASE_SIGNATURE : Lcom/chartboost/sdk/Tracking/CBAnalytics$CBIAPPurchaseInfo;
    //   115: invokevirtual get : (Ljava/lang/Object;)Ljava/lang/Object;
    //   118: checkcast java/lang/String
    //   121: astore #4
    //   123: aload_1
    //   124: getstatic com/chartboost/sdk/Tracking/CBAnalytics$CBIAPPurchaseInfo.AMAZON_USER_ID : Lcom/chartboost/sdk/Tracking/CBAnalytics$CBIAPPurchaseInfo;
    //   127: invokevirtual get : (Ljava/lang/Object;)Ljava/lang/Object;
    //   130: checkcast java/lang/String
    //   133: astore #5
    //   135: aload_1
    //   136: getstatic com/chartboost/sdk/Tracking/CBAnalytics$CBIAPPurchaseInfo.AMAZON_PURCHASE_TOKEN : Lcom/chartboost/sdk/Tracking/CBAnalytics$CBIAPPurchaseInfo;
    //   139: invokevirtual get : (Ljava/lang/Object;)Ljava/lang/Object;
    //   142: checkcast java/lang/String
    //   145: astore #6
    //   147: aload_1
    //   148: getstatic com/chartboost/sdk/Tracking/CBAnalytics$CBIAPPurchaseInfo.PRODUCT_ID : Lcom/chartboost/sdk/Tracking/CBAnalytics$CBIAPPurchaseInfo;
    //   151: invokevirtual get : (Ljava/lang/Object;)Ljava/lang/Object;
    //   154: checkcast java/lang/String
    //   157: aload_1
    //   158: getstatic com/chartboost/sdk/Tracking/CBAnalytics$CBIAPPurchaseInfo.PRODUCT_TITLE : Lcom/chartboost/sdk/Tracking/CBAnalytics$CBIAPPurchaseInfo;
    //   161: invokevirtual get : (Ljava/lang/Object;)Ljava/lang/Object;
    //   164: checkcast java/lang/String
    //   167: aload_1
    //   168: getstatic com/chartboost/sdk/Tracking/CBAnalytics$CBIAPPurchaseInfo.PRODUCT_DESCRIPTION : Lcom/chartboost/sdk/Tracking/CBAnalytics$CBIAPPurchaseInfo;
    //   171: invokevirtual get : (Ljava/lang/Object;)Ljava/lang/Object;
    //   174: checkcast java/lang/String
    //   177: aload_1
    //   178: getstatic com/chartboost/sdk/Tracking/CBAnalytics$CBIAPPurchaseInfo.PRODUCT_PRICE : Lcom/chartboost/sdk/Tracking/CBAnalytics$CBIAPPurchaseInfo;
    //   181: invokevirtual get : (Ljava/lang/Object;)Ljava/lang/Object;
    //   184: checkcast java/lang/String
    //   187: aload_1
    //   188: getstatic com/chartboost/sdk/Tracking/CBAnalytics$CBIAPPurchaseInfo.PRODUCT_CURRENCY_CODE : Lcom/chartboost/sdk/Tracking/CBAnalytics$CBIAPPurchaseInfo;
    //   191: invokevirtual get : (Ljava/lang/Object;)Ljava/lang/Object;
    //   194: checkcast java/lang/String
    //   197: aload_3
    //   198: aload #4
    //   200: aload #5
    //   202: aload #6
    //   204: aload_2
    //   205: invokestatic a : (Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Lcom/chartboost/sdk/Tracking/CBAnalytics$CBIAPType;)V
    //   208: goto -> 97
    //   211: astore_1
    //   212: aload_0
    //   213: monitorexit
    //   214: aload_1
    //   215: athrow
    // Exception table:
    //   from	to	target	type
    //   10	90	211	finally
    //   90	97	211	finally
    //   100	208	211	finally
  }
  
  public enum CBIAPPurchaseInfo {
    AMAZON_PURCHASE_TOKEN, AMAZON_USER_ID, GOOGLE_PURCHASE_DATA, GOOGLE_PURCHASE_SIGNATURE, PRODUCT_CURRENCY_CODE, PRODUCT_DESCRIPTION, PRODUCT_ID, PRODUCT_PRICE, PRODUCT_TITLE;
    
    static {
      PRODUCT_CURRENCY_CODE = new CBIAPPurchaseInfo("PRODUCT_CURRENCY_CODE", 4);
      GOOGLE_PURCHASE_DATA = new CBIAPPurchaseInfo("GOOGLE_PURCHASE_DATA", 5);
      GOOGLE_PURCHASE_SIGNATURE = new CBIAPPurchaseInfo("GOOGLE_PURCHASE_SIGNATURE", 6);
      AMAZON_PURCHASE_TOKEN = new CBIAPPurchaseInfo("AMAZON_PURCHASE_TOKEN", 7);
      AMAZON_USER_ID = new CBIAPPurchaseInfo("AMAZON_USER_ID", 8);
      a = new CBIAPPurchaseInfo[] { PRODUCT_ID, PRODUCT_TITLE, PRODUCT_DESCRIPTION, PRODUCT_PRICE, PRODUCT_CURRENCY_CODE, GOOGLE_PURCHASE_DATA, GOOGLE_PURCHASE_SIGNATURE, AMAZON_PURCHASE_TOKEN, AMAZON_USER_ID };
    }
  }
  
  public enum CBIAPType {
    GOOGLE_PLAY, AMAZON;
    
    static {
    
    }
  }
  
  public enum CBLevelType {
    CHARACTER_LEVEL,
    CURRENT_AREA,
    HIGHEST_LEVEL_REACHED(1),
    OTHER_NONSEQUENTIAL(1),
    OTHER_SEQUENTIAL(1);
    
    private int a;
    
    static {
      CHARACTER_LEVEL = new CBLevelType("CHARACTER_LEVEL", 2, 3);
      OTHER_SEQUENTIAL = new CBLevelType("OTHER_SEQUENTIAL", 3, 4);
      OTHER_NONSEQUENTIAL = new CBLevelType("OTHER_NONSEQUENTIAL", 4, 5);
      b = new CBLevelType[] { HIGHEST_LEVEL_REACHED, CURRENT_AREA, CHARACTER_LEVEL, OTHER_SEQUENTIAL, OTHER_NONSEQUENTIAL };
    }
    
    CBLevelType(int param1Int1) {
      this.a = param1Int1;
    }
    
    public int getLevelType() {
      return this.a;
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Smash Cricket-dex2jar.jar!\com\chartboost\sdk\Tracking\CBAnalytics.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */