package com.chartboost.sdk.Tracking;

import android.content.SharedPreferences;
import android.text.TextUtils;
import com.chartboost.sdk.Libraries.CBUtility;
import com.chartboost.sdk.Libraries.a;
import com.chartboost.sdk.Libraries.b;
import com.chartboost.sdk.Libraries.c;
import com.chartboost.sdk.Libraries.e;
import com.chartboost.sdk.Libraries.g;
import com.chartboost.sdk.Libraries.h;
import com.chartboost.sdk.Model.CBError;
import com.chartboost.sdk.impl.az;
import com.chartboost.sdk.impl.l;
import org.json.JSONArray;
import org.json.JSONObject;

public class a implements a {
  private static final String b = a.class.getSimpleName();
  
  private static a k;
  
  private static boolean l = false;
  
  private String c;
  
  private String d = o();
  
  private JSONArray e = new JSONArray();
  
  private long f;
  
  private long g;
  
  private long h = System.currentTimeMillis();
  
  private h i = new h("CBTrackingDirectory", false);
  
  private h j = new h("CBSessionDirectory", false);
  
  public static a a() {
    // Byte code:
    //   0: getstatic com/chartboost/sdk/Tracking/a.k : Lcom/chartboost/sdk/Tracking/a;
    //   3: ifnonnull -> 28
    //   6: ldc com/chartboost/sdk/Chartboost
    //   8: monitorenter
    //   9: getstatic com/chartboost/sdk/Tracking/a.k : Lcom/chartboost/sdk/Tracking/a;
    //   12: ifnonnull -> 25
    //   15: new com/chartboost/sdk/Tracking/a
    //   18: dup
    //   19: invokespecial <init> : ()V
    //   22: putstatic com/chartboost/sdk/Tracking/a.k : Lcom/chartboost/sdk/Tracking/a;
    //   25: ldc com/chartboost/sdk/Chartboost
    //   27: monitorexit
    //   28: getstatic com/chartboost/sdk/Tracking/a.k : Lcom/chartboost/sdk/Tracking/a;
    //   31: areturn
    //   32: astore_0
    //   33: ldc com/chartboost/sdk/Chartboost
    //   35: monitorexit
    //   36: aload_0
    //   37: athrow
    // Exception table:
    //   from	to	target	type
    //   9	25	32	finally
    //   25	28	32	finally
    //   33	36	32	finally
  }
  
  private static Object a(Object paramObject) {
    return (paramObject != null) ? paramObject : "";
  }
  
  public static String a(int paramInt) {
    return (new Integer(paramInt)).toString();
  }
  
  public static void a(String paramString) {
    k.a("session", paramString, (String)null, (String)null, (String)null, (String)null, "session");
  }
  
  public static void a(String paramString1, String paramString2) {
    k.a("start", paramString1, paramString2, (String)null, (String)null, (String)null, "system");
  }
  
  public static void a(String paramString1, String paramString2, int paramInt) {
    k.a("playback-start", paramString1, paramString2, a(paramInt), (String)null, (String)null, "system");
  }
  
  public static void a(String paramString1, String paramString2, CBError.CBImpressionError paramCBImpressionError) {
    String str;
    a a1 = k;
    if (paramCBImpressionError != null) {
      str = paramCBImpressionError.toString();
    } else {
      str = "";
    } 
    a1.a("ad-error", paramString1, paramString2, str, (String)null, (String)null, "system");
  }
  
  public static void a(String paramString1, String paramString2, String paramString3) {
    k.a("ad-show", paramString1, paramString2, paramString3, (String)null, (String)null, "system");
  }
  
  public static void a(String paramString1, String paramString2, String paramString3, int paramInt) {
    k.a("ad-click", paramString1, paramString2, paramString3, a(paramInt), (String)null, "system");
  }
  
  public static void a(String paramString1, String paramString2, String paramString3, int paramInt1, int paramInt2) {
    k.a("install-click", paramString1, paramString3, paramString2, a(paramInt1), a(paramInt2), "system");
  }
  
  public static void a(String paramString1, String paramString2, String paramString3, String paramString4) {
    k.a("failure", paramString1, paramString2, paramString3, paramString4, (String)null, "system");
  }
  
  public static void a(String paramString1, String paramString2, String paramString3, String paramString4, String paramString5, String paramString6, JSONObject paramJSONObject) {
    k.a(paramString1, paramString2, paramString3, paramString4, paramString5, paramString6, paramJSONObject, "system");
  }
  
  public static void a(String paramString1, String paramString2, boolean paramBoolean) {
    k.a("ad-get", paramString1, paramString2, b(paramBoolean), "single", (String)null, "system");
  }
  
  public static String b(boolean paramBoolean) {
    return paramBoolean ? "1" : "0";
  }
  
  public static void b() {
    a("start");
    a("did-become-active");
  }
  
  public static void b(String paramString1, String paramString2) {
    k.a("confirmation-show", paramString1, paramString2, (String)null, (String)null, (String)null, "system");
  }
  
  public static void b(String paramString1, String paramString2, int paramInt) {
    k.a("close-show", paramString1, paramString2, a(paramInt), (String)null, (String)null, "system");
  }
  
  public static void b(String paramString1, String paramString2, String paramString3) {
    k.a("ad-click", paramString1, paramString2, paramString3, (String)null, (String)null, "system");
  }
  
  public static void b(String paramString1, String paramString2, boolean paramBoolean) {
    k.a("ad-has", paramString1, paramString2, b(paramBoolean), (String)null, (String)null, "system");
  }
  
  public static void c(String paramString1, String paramString2) {
    k.a("replay", paramString1, paramString2, (String)null, (String)null, (String)null, "system");
  }
  
  public static void c(String paramString1, String paramString2, String paramString3) {
    k.a("ad-close", paramString1, paramString2, paramString3, (String)null, (String)null, "system");
  }
  
  public static void c(String paramString1, String paramString2, boolean paramBoolean) {
    k.a("ad-loaded", paramString1, paramString2, b(paramBoolean), (String)null, (String)null, "system");
  }
  
  public static void d() {
    k.a("video-prefetcher", "begin", (String)null, (String)null, (String)null, (String)null, "system");
  }
  
  public static void d(String paramString1, String paramString2) {
    k.a("playback-stop", paramString1, paramString2, (String)null, (String)null, (String)null, "system");
  }
  
  public static void d(String paramString1, String paramString2, String paramString3) {
    k.a("success", paramString1, paramString2, paramString3, (String)null, (String)null, "system");
  }
  
  public static void d(String paramString1, String paramString2, boolean paramBoolean) {
    k.a("confirmation-dismiss", paramString1, paramString2, b(paramBoolean), (String)null, (String)null, "system");
  }
  
  public static void e() {
    k.a("video-prefetcher", (String)null, (String)null, (String)null, (String)null, (String)null, "system");
  }
  
  public static void e(String paramString1, String paramString2, String paramString3) {
    k.a(paramString1, paramString2, paramString3, (String)null, (String)null, (String)null, "system");
  }
  
  public static void e(String paramString1, String paramString2, boolean paramBoolean) {
    k.a("controls-toggle", paramString1, paramString2, b(paramBoolean), (String)null, (String)null, "system");
  }
  
  public az a(e.a parama) {
    az az = new az("/api/track");
    az.a("track", parama);
    az.a(g.a(new g.k[] { g.a("status", a.a) }));
    az.a(l.a.a);
    return az;
  }
  
  public void a(long paramLong1, long paramLong2) {
    e.a a1 = e.a.a();
    a1.a("start_timestamp", Long.valueOf(paramLong1));
    a1.a("timestamp", Long.valueOf(paramLong2));
    a1.a("session_id", this.c);
    this.j.a("cb_previous_session_info", a1);
  }
  
  public void a(String paramString1, String paramString2, String paramString3, String paramString4, String paramString5, String paramString6, String paramString7) {
    k.a(paramString1, paramString2, paramString3, paramString4, paramString5, paramString6, new JSONObject(), paramString7);
  }
  
  public void a(String paramString1, String paramString2, String paramString3, String paramString4, String paramString5, String paramString6, JSONObject paramJSONObject, String paramString7) {
    // Byte code:
    //   0: ldc com/chartboost/sdk/b
    //   2: ldc 'j'
    //   4: iconst_0
    //   5: anewarray java/lang/Class
    //   8: invokevirtual getDeclaredMethod : (Ljava/lang/String;[Ljava/lang/Class;)Ljava/lang/reflect/Method;
    //   11: astore #15
    //   13: aload #15
    //   15: iconst_1
    //   16: invokevirtual setAccessible : (Z)V
    //   19: aload #15
    //   21: aconst_null
    //   22: iconst_0
    //   23: anewarray java/lang/Object
    //   26: invokevirtual invoke : (Ljava/lang/Object;[Ljava/lang/Object;)Ljava/lang/Object;
    //   29: checkcast org/json/JSONObject
    //   32: astore #15
    //   34: invokestatic a : ()Lcom/chartboost/sdk/Libraries/e$a;
    //   37: astore #16
    //   39: aload #15
    //   41: ifnull -> 344
    //   44: aload #15
    //   46: aload #8
    //   48: invokevirtual optBoolean : (Ljava/lang/String;)Z
    //   51: ifeq -> 344
    //   54: invokestatic currentTimeMillis : ()J
    //   57: lstore #9
    //   59: aload_0
    //   60: getfield f : J
    //   63: lstore #11
    //   65: aload_0
    //   66: getfield h : J
    //   69: lstore #13
    //   71: aload #16
    //   73: ldc_w 'event'
    //   76: aload_1
    //   77: invokestatic a : (Ljava/lang/Object;)Ljava/lang/Object;
    //   80: invokevirtual a : (Ljava/lang/String;Ljava/lang/Object;)V
    //   83: aload #16
    //   85: ldc_w 'kingdom'
    //   88: aload_2
    //   89: invokestatic a : (Ljava/lang/Object;)Ljava/lang/Object;
    //   92: invokevirtual a : (Ljava/lang/String;Ljava/lang/Object;)V
    //   95: aload #16
    //   97: ldc_w 'phylum'
    //   100: aload_3
    //   101: invokestatic a : (Ljava/lang/Object;)Ljava/lang/Object;
    //   104: invokevirtual a : (Ljava/lang/String;Ljava/lang/Object;)V
    //   107: aload #16
    //   109: ldc_w 'class'
    //   112: aload #4
    //   114: invokestatic a : (Ljava/lang/Object;)Ljava/lang/Object;
    //   117: invokevirtual a : (Ljava/lang/String;Ljava/lang/Object;)V
    //   120: aload #16
    //   122: ldc_w 'family'
    //   125: aload #5
    //   127: invokestatic a : (Ljava/lang/Object;)Ljava/lang/Object;
    //   130: invokevirtual a : (Ljava/lang/String;Ljava/lang/Object;)V
    //   133: aload #16
    //   135: ldc_w 'genus'
    //   138: aload #6
    //   140: invokestatic a : (Ljava/lang/Object;)Ljava/lang/Object;
    //   143: invokevirtual a : (Ljava/lang/String;Ljava/lang/Object;)V
    //   146: aload #7
    //   148: astore_2
    //   149: aload #7
    //   151: ifnonnull -> 162
    //   154: new org/json/JSONObject
    //   157: dup
    //   158: invokespecial <init> : ()V
    //   161: astore_2
    //   162: aload #16
    //   164: ldc_w 'meta'
    //   167: aload_2
    //   168: invokevirtual a : (Ljava/lang/String;Ljava/lang/Object;)V
    //   171: aload #16
    //   173: ldc_w 'clientTimestamp'
    //   176: invokestatic currentTimeMillis : ()J
    //   179: ldc2_w 1000
    //   182: ldiv
    //   183: invokestatic valueOf : (J)Ljava/lang/Long;
    //   186: invokevirtual a : (Ljava/lang/String;Ljava/lang/Object;)V
    //   189: aload #16
    //   191: ldc 'session_id'
    //   193: aload_0
    //   194: invokevirtual k : ()Ljava/lang/String;
    //   197: invokevirtual a : (Ljava/lang/String;Ljava/lang/Object;)V
    //   200: aload #16
    //   202: ldc_w 'totalSessionTime'
    //   205: lload #9
    //   207: lload #11
    //   209: lsub
    //   210: ldc2_w 1000
    //   213: ldiv
    //   214: invokestatic valueOf : (J)Ljava/lang/Long;
    //   217: invokevirtual a : (Ljava/lang/String;Ljava/lang/Object;)V
    //   220: aload #16
    //   222: ldc_w 'currentSessionTime'
    //   225: lload #9
    //   227: lload #13
    //   229: lsub
    //   230: ldc2_w 1000
    //   233: ldiv
    //   234: invokestatic valueOf : (J)Ljava/lang/Long;
    //   237: invokevirtual a : (Ljava/lang/String;Ljava/lang/Object;)V
    //   240: aload_0
    //   241: monitorenter
    //   242: invokestatic h : ()Z
    //   245: ifne -> 255
    //   248: aload_0
    //   249: invokevirtual f : ()Z
    //   252: ifeq -> 259
    //   255: aload_0
    //   256: invokevirtual p : ()V
    //   259: aload_0
    //   260: getfield e : Lorg/json/JSONArray;
    //   263: aload #16
    //   265: invokevirtual e : ()Lorg/json/JSONObject;
    //   268: invokevirtual put : (Ljava/lang/Object;)Lorg/json/JSONArray;
    //   271: pop
    //   272: invokestatic a : ()Lcom/chartboost/sdk/Libraries/e$a;
    //   275: astore_2
    //   276: aload_2
    //   277: ldc_w 'events'
    //   280: aload_0
    //   281: getfield e : Lorg/json/JSONArray;
    //   284: invokevirtual a : (Ljava/lang/String;Ljava/lang/Object;)V
    //   287: getstatic com/chartboost/sdk/Tracking/a.b : Ljava/lang/String;
    //   290: new java/lang/StringBuilder
    //   293: dup
    //   294: invokespecial <init> : ()V
    //   297: ldc_w '###Writing'
    //   300: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   303: aload_1
    //   304: invokestatic a : (Ljava/lang/Object;)Ljava/lang/Object;
    //   307: invokevirtual append : (Ljava/lang/Object;)Ljava/lang/StringBuilder;
    //   310: ldc_w 'to tracking cache dir'
    //   313: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   316: invokevirtual toString : ()Ljava/lang/String;
    //   319: invokestatic a : (Ljava/lang/Object;Ljava/lang/String;)V
    //   322: aload_0
    //   323: getfield i : Lcom/chartboost/sdk/Libraries/h;
    //   326: aload_0
    //   327: getfield d : Ljava/lang/String;
    //   330: aload_2
    //   331: invokestatic a : (Ljava/lang/Object;)Lcom/chartboost/sdk/Libraries/e$a;
    //   334: invokevirtual a : (Ljava/lang/String;Lcom/chartboost/sdk/Libraries/e$a;)Ljava/io/File;
    //   337: pop
    //   338: aload_0
    //   339: invokevirtual j : ()V
    //   342: aload_0
    //   343: monitorexit
    //   344: return
    //   345: astore #15
    //   347: aload_0
    //   348: ldc_w 'Error encountered getting tracking levels'
    //   351: aload #15
    //   353: invokestatic b : (Ljava/lang/Object;Ljava/lang/String;Ljava/lang/Throwable;)V
    //   356: aload #15
    //   358: invokestatic throwProguardError : (Ljava/lang/Exception;)V
    //   361: aconst_null
    //   362: astore #15
    //   364: goto -> 34
    //   367: astore_1
    //   368: aload_0
    //   369: monitorexit
    //   370: aload_1
    //   371: athrow
    // Exception table:
    //   from	to	target	type
    //   0	34	345	java/lang/Exception
    //   242	255	367	finally
    //   255	259	367	finally
    //   259	344	367	finally
    //   368	370	367	finally
  }
  
  public void a(boolean paramBoolean) {
    e.a a1 = e.a.a();
    a1.a("complete", Boolean.valueOf(paramBoolean));
    k.a("session", "end", null, null, null, null, a1.e(), "session");
    a("did-become-active");
  }
  
  public boolean b(String paramString) {
    return TextUtils.isEmpty(paramString) ? true : paramString.equals("cb_previous_session_info");
  }
  
  public void c() {
    a(false);
  }
  
  public boolean f() {
    boolean bool2 = false;
    boolean bool1 = bool2;
    if (this.e != null) {
      bool1 = bool2;
      if (this.e.length() >= 50)
        bool1 = true; 
    } 
    return bool1;
  }
  
  public String g() {
    e.a a1 = e.a.a();
    a1.a("startTime", Long.valueOf(System.currentTimeMillis()));
    a1.a("deviceID", c.e());
    this.c = b.b(a1.toString().getBytes());
    return this.c;
  }
  
  public void h() {
    e.a a1 = this.j.a("cb_previous_session_info");
    if (a1 != null) {
      this.g = a1.h("timestamp");
      this.f = a1.h("start_timestamp");
      this.c = a1.e("session_id");
      if (System.currentTimeMillis() - this.g <= 180000L) {
        if (!TextUtils.isEmpty(this.c)) {
          j();
          l = false;
          return;
        } 
      } else {
        a(true);
      } 
    } 
    i();
    l = true;
  }
  
  public void i() {
    long l = System.currentTimeMillis();
    this.f = l;
    this.g = l;
    this.c = g();
    a(l, l);
    SharedPreferences sharedPreferences = CBUtility.a();
    int i = sharedPreferences.getInt("cbPrefSessionCount", 0);
    SharedPreferences.Editor editor = sharedPreferences.edit();
    editor.putInt("cbPrefSessionCount", i + 1);
    editor.commit();
  }
  
  public void j() {
    long l = System.currentTimeMillis();
    a(this.f, l);
  }
  
  public String k() {
    return this.c;
  }
  
  public h l() {
    return this.i;
  }
  
  public JSONArray m() {
    return this.e;
  }
  
  public long n() {
    return this.f;
  }
  
  public String o() {
    return (new Long(System.nanoTime())).toString();
  }
  
  public void p() {
    this.e = new JSONArray();
    this.d = o();
  }
  
  public String toString() {
    return "Session [ startTime: " + n() + " sessionEvents: " + m() + " ]";
  }
}


/* Location:              C:\soft\dex2jar-2.0\Smash Cricket-dex2jar.jar!\com\chartboost\sdk\Tracking\a.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */