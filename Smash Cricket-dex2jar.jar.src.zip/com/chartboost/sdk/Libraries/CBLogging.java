package com.chartboost.sdk.Libraries;

import android.util.Log;
import com.chartboost.sdk.b;

public final class CBLogging {
  public static Level a = Level.INTEGRATION;
  
  private static String b = "Chartboost SDK";
  
  private static String a(Object paramObject) {
    if (paramObject != null && !(paramObject instanceof String))
      paramObject = paramObject.getClass().getName(); 
    return (String)paramObject;
  }
  
  public static void a(Object paramObject, String paramString) {
    if (a == Level.ALL)
      Log.d(a(paramObject), paramString); 
  }
  
  public static void a(Object paramObject, String paramString, Throwable paramThrowable) {
    if (a == Level.ALL)
      Log.d(a(paramObject), paramString, paramThrowable); 
  }
  
  public static void a(String paramString) {
    if (a())
      Log.e(b, paramString); 
  }
  
  private static boolean a() {
    return (a == Level.ALL || (a == Level.INTEGRATION && CBUtility.a(b.x())));
  }
  
  public static void b(Object paramObject, String paramString) {
    if (a == Level.ALL)
      Log.e(a(paramObject), paramString); 
  }
  
  public static void b(Object paramObject, String paramString, Throwable paramThrowable) {
    if (a == Level.ALL)
      Log.e(a(paramObject), paramString, paramThrowable); 
  }
  
  public static void c(Object paramObject, String paramString) {
    if (a == Level.ALL)
      Log.v(a(paramObject), paramString); 
  }
  
  public static void c(Object paramObject, String paramString, Throwable paramThrowable) {
    if (a == Level.ALL)
      Log.v(a(paramObject), paramString, paramThrowable); 
  }
  
  public static void d(Object paramObject, String paramString) {
    if (a == Level.ALL)
      Log.w(a(paramObject), paramString); 
  }
  
  public static void d(Object paramObject, String paramString, Throwable paramThrowable) {
    if (a == Level.ALL)
      Log.w(a(paramObject), paramString, paramThrowable); 
  }
  
  public static void e(Object paramObject, String paramString) {
    if (a == Level.ALL)
      Log.i(a(paramObject), paramString); 
  }
  
  public enum Level {
    ALL, INTEGRATION, NONE;
    
    static {
      ALL = new Level("ALL", 2);
      a = new Level[] { NONE, INTEGRATION, ALL };
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Smash Cricket-dex2jar.jar!\com\chartboost\sdk\Libraries\CBLogging.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */