package com.chartboost.sdk.Libraries;

import java.math.BigInteger;
import java.util.HashSet;
import java.util.Map;
import java.util.Set;
import org.json.JSONException;
import org.json.JSONObject;

public final class g {
  private static final String a = g.class.getSimpleName();
  
  private static o b = new o();
  
  private static n c = new n();
  
  private static j d = new j();
  
  private static d e = new d();
  
  private static l f = new l();
  
  public static a a() {
    return b;
  }
  
  public static a a(a parama) {
    return new m(parama);
  }
  
  public static a a(Class<?> paramClass) {
    return new i(paramClass);
  }
  
  public static a a(a... paramVarArgs) {
    return new p(paramVarArgs);
  }
  
  public static a a(k... paramVarArgs) {
    return new f(paramVarArgs);
  }
  
  public static a a(Object... paramVarArgs) {
    return new h(paramVarArgs);
  }
  
  public static k a(String paramString, a parama) {
    return new k(paramString, parama);
  }
  
  public static a b() {
    return c;
  }
  
  public static a b(a parama) {
    return new c(parama);
  }
  
  public static a b(k... paramVarArgs) {
    return new g(new f(paramVarArgs));
  }
  
  public static a c() {
    return e;
  }
  
  public static boolean c(a parama) {
    return (parama instanceof f || parama instanceof g);
  }
  
  public static abstract class a {
    private String a = null;
    
    public abstract String a();
    
    public abstract boolean a(Object param1Object);
    
    public boolean a(Object param1Object, StringBuilder param1StringBuilder) {
      Object object = param1Object;
      if (param1Object instanceof e.a)
        object = ((e.a)param1Object).n(); 
      boolean bool = a(object);
      if (!bool) {
        if (this.a != null) {
          param1Object = this.a;
        } else {
          param1Object = a();
        } 
        param1StringBuilder.append((String)param1Object);
      } 
      return bool;
    }
  }
  
  private static class b extends a {
    private b() {}
    
    public String a() {
      return "object must be an array.";
    }
    
    public boolean a(Object param1Object) {
      return (param1Object instanceof java.util.List || param1Object instanceof org.json.JSONArray);
    }
  }
  
  private static class c extends b {
    private g.a a;
    
    public c(g.a param1a) {
      this.a = param1a;
    }
    
    public String a() {
      return "object must be an array of objects matching: <" + this.a.a() + ">";
    }
    
    public boolean a(Object param1Object) {
      if (param1Object instanceof java.util.List) {
        param1Object = param1Object;
        int i = 0;
        while (i < param1Object.size()) {
          if (this.a.a(param1Object.get(i))) {
            i++;
            continue;
          } 
          return false;
        } 
        return true;
      } 
      if (param1Object instanceof org.json.JSONArray) {
        param1Object = param1Object;
        int i = 0;
        while (i < param1Object.length()) {
          if (this.a.a(param1Object.opt(i))) {
            i++;
            continue;
          } 
          return false;
        } 
        return true;
      } 
      return false;
    }
  }
  
  private static class d extends a {
    private d() {}
    
    public String a() {
      return "object must be a boolean.";
    }
    
    public boolean a(Object param1Object) {
      return (Boolean.class.isInstance(param1Object) || boolean.class.isInstance(param1Object));
    }
  }
  
  public static abstract class e extends a {}
  
  private static class f extends a {
    protected g.k[] a;
    
    protected String b = null;
    
    public f(g.k[] param1ArrayOfk) {
      this.a = param1ArrayOfk;
    }
    
    public String a() {
      if (this.b != null)
        return this.b; 
      StringBuilder stringBuilder = new StringBuilder();
      stringBuilder.append("object must contain the following key-value schema: {\n");
      for (int i = 0; i < this.a.length; i++) {
        stringBuilder.append("<");
        stringBuilder.append(g.k.a(this.a[i]));
        stringBuilder.append(": [");
        stringBuilder.append(g.k.b(this.a[i]).a());
        stringBuilder.append("]>");
        if (i < this.a.length - 1)
          stringBuilder.append(",\n"); 
      } 
      stringBuilder.append("}");
      return stringBuilder.toString();
    }
    
    public boolean a(Object param1Object) {
      if (param1Object instanceof Map) {
        param1Object = param1Object;
        for (Map.Entry entry : param1Object.entrySet()) {
          if (!(entry.getKey() instanceof String)) {
            this.b = "key '" + entry.getKey().toString() + "' is not a string";
            return false;
          } 
        } 
        if (this.a != null && this.a.length >= 1)
          for (int i = 0; i < this.a.length; i++) {
            String str = g.k.a(this.a[i]);
            g.a a1 = g.k.b(this.a[i]);
            if (!param1Object.containsKey(str)) {
              if (!a1.a(null)) {
                this.b = "no key for required mapping '" + str + "' : <" + a1.a() + ">";
                return false;
              } 
            } else if (!a1.a(param1Object.get(str))) {
              this.b = "key '" + str + "' fails to match: <" + a1.a() + ">";
              return false;
            } 
          }  
        return true;
      } 
      if (param1Object instanceof JSONObject) {
        param1Object = param1Object;
        if (this.a != null && this.a.length >= 1)
          for (int i = 0; i < this.a.length; i++) {
            String str = g.k.a(this.a[i]);
            g.a a1 = g.k.b(this.a[i]);
            try {
              if (!a1.a(param1Object.get(str))) {
                this.b = "key '" + str + "' fails to match: <" + a1.a() + ">";
                return false;
              } 
            } catch (JSONException jSONException) {
              if (!a1.a(null)) {
                this.b = "no key for required mapping '" + str + "' : <" + a1.a() + ">";
                return false;
              } 
            } 
          }  
        return true;
      } 
      return false;
    }
  }
  
  private static class g extends a {
    private Set<String> a;
    
    private g.f b;
    
    private String c = null;
    
    public g(g.f param1f) {
      this.b = param1f;
      this.a = new HashSet<String>();
      for (int i = 0; i < this.b.a.length; i++) {
        String str = g.k.a(this.b.a[i]);
        this.a.add(str);
      } 
    }
    
    public String a() {
      if (this.c != null)
        return this.c; 
      StringBuilder stringBuilder = new StringBuilder();
      stringBuilder.append("object must EXACTLY MATCH the following key-value schema: {\n");
      for (int i = 0; i < this.b.a.length; i++) {
        stringBuilder.append("<");
        stringBuilder.append(g.k.a(this.b.a[i]));
        stringBuilder.append(": [");
        stringBuilder.append(g.k.b(this.b.a[i]).a());
        stringBuilder.append("]>");
        if (i < this.b.a.length - 1)
          stringBuilder.append(",\n"); 
      } 
      stringBuilder.append("}");
      return stringBuilder.toString();
    }
    
    public boolean a(Object param1Object) {
      if (!this.b.a(param1Object)) {
        this.c = this.b.b;
        return false;
      } 
      if (param1Object instanceof Map) {
        param1Object = ((Map)param1Object).keySet().iterator();
        while (param1Object.hasNext()) {
          String str = (String)param1Object.next();
          if (!this.a.contains(str)) {
            this.c = "key '" + str + "' is not allowed in this dictionary";
            return false;
          } 
        } 
        return true;
      } 
      if (param1Object instanceof JSONObject) {
        param1Object = ((JSONObject)param1Object).keys();
        while (param1Object.hasNext()) {
          String str = param1Object.next();
          if (!this.a.contains(str)) {
            this.c = "key '" + str + "' is not allowed in this dictionary";
            return false;
          } 
        } 
        return true;
      } 
      this.c = "object must be a dictionary";
      return false;
    }
  }
  
  private static class h extends a {
    private Object[] a;
    
    public h(Object[] param1ArrayOfObject) {
      this.a = param1ArrayOfObject;
    }
    
    public String a() {
      StringBuilder stringBuilder = new StringBuilder();
      stringBuilder.append("object must equal one of the following: ");
      for (int i = 0; i < this.a.length; i++) {
        stringBuilder.append("<");
        stringBuilder.append(this.a[i].toString());
        stringBuilder.append(">");
        if (i < this.a.length - 1)
          stringBuilder.append(", "); 
      } 
      return stringBuilder.toString();
    }
    
    public boolean a(Object param1Object) {
      boolean bool = false;
      for (int i = 0;; i++) {
        boolean bool1 = bool;
        if (i < this.a.length) {
          Object object = this.a[i];
          if (param1Object == null) {
            if (object == null)
              return true; 
          } else if (param1Object.equals(object)) {
            return true;
          } 
        } else {
          return bool1;
        } 
      } 
    }
  }
  
  private static class i extends a {
    private Class<?> a;
    
    public i(Class<?> param1Class) {
      this.a = param1Class;
    }
    
    public String a() {
      return "object must be an instance of " + this.a.getName() + ".";
    }
    
    public boolean a(Object param1Object) {
      return this.a.isInstance(param1Object);
    }
  }
  
  private static class j extends a {
    private j() {}
    
    public String a() {
      return "object must be a number w/o decimals (int, long, short, or byte).";
    }
    
    public boolean a(Object param1Object) {
      return (Integer.class.isInstance(param1Object) || Long.class.isInstance(param1Object) || Short.class.isInstance(param1Object) || Byte.class.isInstance(param1Object) || BigInteger.class.isInstance(param1Object) || int.class.isInstance(param1Object) || long.class.isInstance(param1Object) || short.class.isInstance(param1Object) || byte.class.isInstance(param1Object));
    }
  }
  
  public static class k {
    private String a;
    
    private g.a b;
    
    public k(String param1String, g.a param1a) {
      this.a = param1String;
      this.b = param1a;
    }
  }
  
  private static class l extends a {
    private l() {}
    
    public String a() {
      return "object must be null.";
    }
    
    public boolean a(Object param1Object) {
      return (param1Object == null || param1Object == JSONObject.NULL);
    }
  }
  
  private static class m extends l {
    private g.a a;
    
    public m(g.a param1a) {
      this.a = param1a;
    }
    
    public String a() {
      return "object must be either null or " + this.a.a();
    }
    
    public boolean a(Object param1Object) {
      return super.a(param1Object) ? true : this.a.a(param1Object);
    }
  }
  
  private static class n extends a {
    private n() {}
    
    public String a() {
      return "object must be a number (primitive type or derived from Number).";
    }
    
    public boolean a(Object param1Object) {
      return (param1Object instanceof Number || int.class.isInstance(param1Object) || long.class.isInstance(param1Object) || short.class.isInstance(param1Object) || float.class.isInstance(param1Object) || double.class.isInstance(param1Object) || byte.class.isInstance(param1Object));
    }
  }
  
  private static class o extends i {
    public o() {
      super(String.class);
    }
  }
  
  private static class p extends a {
    protected String a = null;
    
    private g.a[] b;
    
    public p(g.a[] param1ArrayOfa) {
      this.b = param1ArrayOfa;
    }
    
    public String a() {
      if (this.a != null)
        return this.a; 
      StringBuilder stringBuilder = new StringBuilder();
      stringBuilder.append("object must match ALL of the following: ");
      for (int i = 0; i < this.b.length; i++) {
        stringBuilder.append("<");
        stringBuilder.append(this.b[i].a());
        stringBuilder.append(">");
        if (i < this.b.length - 1)
          stringBuilder.append(", "); 
      } 
      return stringBuilder.toString();
    }
    
    public boolean a(Object param1Object) {
      for (int i = 0; i < this.b.length; i++) {
        if (!this.b[i].a(param1Object)) {
          this.a = "object failed to match: <" + this.b[i].a() + ">";
          return false;
        } 
      } 
      return true;
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Smash Cricket-dex2jar.jar!\com\chartboost\sdk\Libraries\g.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */