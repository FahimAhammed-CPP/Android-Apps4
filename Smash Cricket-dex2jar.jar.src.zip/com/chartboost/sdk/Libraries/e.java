package com.chartboost.sdk.Libraries;

import android.text.TextUtils;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

public class e {
  private static Map<Integer, a> a = Collections.synchronizedMap(new HashMap<Integer, a>());
  
  private static Runnable b = new Runnable() {
      public void run() {
        e.a().clear();
      }
    };
  
  public static a a(b... paramVarArgs) {
    a a = a.a();
    for (int i = 0; i < paramVarArgs.length; i++)
      a.a(b.a(paramVarArgs[i]), b.b(paramVarArgs[i])); 
    return a;
  }
  
  public static b a(String paramString, Object paramObject) {
    return new b(paramString, paramObject);
  }
  
  public static List<?> a(JSONArray paramJSONArray) {
    if (paramJSONArray == null)
      return null; 
    ArrayList<Object<String, Object>> arrayList = new ArrayList();
    for (int i = 0;; i++) {
      if (i < paramJSONArray.length()) {
        try {
          Object<String, Object> object = (Object<String, Object>)paramJSONArray.get(i);
          if (object instanceof JSONObject) {
            object = (Object<String, Object>)a((JSONObject)object);
          } else if (object instanceof JSONArray) {
            object = (Object)a((JSONArray)object);
          } else {
            boolean bool = object.equals(JSONObject.NULL);
            if (bool)
              object = null; 
          } 
          arrayList.add(object);
        } catch (Exception exception) {
          CBLogging.b("CBJSON", "error converting json", exception);
        } 
      } else {
        return arrayList;
      } 
    } 
  }
  
  public static Map<String, Object> a(JSONObject paramJSONObject) {
    if (paramJSONObject == null)
      return null; 
    HashMap<Object, Object> hashMap = new HashMap<Object, Object>();
    Iterator<String> iterator = paramJSONObject.keys();
    while (iterator.hasNext()) {
      try {
        String str = iterator.next();
        Object<String, Object> object = (Object<String, Object>)paramJSONObject.get(str);
        if (object instanceof JSONObject) {
          object = (Object<String, Object>)a((JSONObject)object);
        } else if (object instanceof JSONArray) {
          object = (Object)a((JSONArray)object);
        } else {
          boolean bool = object.equals(JSONObject.NULL);
          if (bool)
            object = null; 
        } 
        hashMap.put(str, object);
      } catch (Exception exception) {
        CBLogging.b("CBJSON", "error converting json", exception);
      } 
    } 
    return (Map)hashMap;
  }
  
  public static JSONArray a(List<?> paramList) {
    if (paramList == null)
      return null; 
    JSONArray jSONArray = new JSONArray();
    for (int i = 0;; i++) {
      if (i < paramList.size()) {
        try {
          Object object1;
          Object object2 = paramList.get(i);
          if (object2 instanceof Map) {
            object1 = a((Map<?, ?>)object2);
          } else if (object2 instanceof List) {
            object1 = a((List)object2);
          } else {
            object1 = object2;
            if (object2 == null)
              object1 = JSONObject.NULL; 
          } 
          jSONArray.put(object1);
        } catch (Exception exception) {
          CBLogging.b("CBJSON", "error converting json", exception);
        } 
      } else {
        return jSONArray;
      } 
    } 
  }
  
  public static JSONObject a(Map<?, ?> paramMap) {
    if (paramMap == null)
      return null; 
    JSONObject jSONObject = new JSONObject();
    for (Map.Entry<?, ?> entry : paramMap.entrySet()) {
      String str = entry.getKey().toString();
      Object object = entry.getValue();
      try {
        Object object1;
        if (object instanceof Map) {
          object1 = a((Map<?, ?>)object);
        } else if (object instanceof List) {
          object1 = a((List)object);
        } else {
          object1 = object;
          if (object == null)
            object1 = JSONObject.NULL; 
        } 
        jSONObject.put(str, object1);
      } catch (Exception exception) {
        CBLogging.b("CBJSON", "error converting json", exception);
      } 
    } 
    return jSONObject;
  }
  
  public static class a {
    public static a a = new a(null);
    
    private static JSONObject c = null;
    
    private static Map<String, Object> d = null;
    
    private static JSONArray e = null;
    
    private static List<?> f = null;
    
    private Object b;
    
    private a(Object param1Object) {
      this.b = param1Object;
    }
    
    public static a a() {
      return a(new JSONObject());
    }
    
    public static a a(Object param1Object) {
      if (param1Object instanceof a)
        return (a)param1Object; 
      if (param1Object == null || param1Object == JSONObject.NULL)
        return a; 
      a a1 = (a)e.a().get(Integer.valueOf(param1Object.hashCode()));
      if (a1 != null)
        return a1; 
      CBUtility.e().removeCallbacks(e.b());
      CBUtility.e().postDelayed(e.b(), 1000L);
      a1 = new a(param1Object);
      e.a().put(Integer.valueOf(param1Object.hashCode()), a1);
      return a1;
    }
    
    public static a j(String param1String) {
      if (param1String == null) {
        CBLogging.d("CBJSON", "null passed when creating new JSON object");
        return a;
      } 
      if (param1String != null)
        try {
          return param1String.trim().startsWith("[") ? a(new JSONArray(param1String)) : a(new JSONObject(param1String));
        } catch (JSONException jSONException) {
          CBLogging.b("CBJSON", "error creating new json object", (Throwable)jSONException);
          return a;
        }  
      return a(new JSONObject((String)jSONException));
    }
    
    public double a(double param1Double) {
      if (this.b instanceof String)
        try {
          return Double.parseDouble((String)this.b);
        } catch (NumberFormatException numberFormatException) {
          return param1Double;
        }  
      return (this.b instanceof Number) ? ((Number)this.b).doubleValue() : param1Double;
    }
    
    public float a(float param1Float) {
      if (this.b instanceof String)
        try {
          return Float.parseFloat((String)this.b);
        } catch (NumberFormatException numberFormatException) {
          return param1Float;
        }  
      return (this.b instanceof Number) ? ((Number)this.b).floatValue() : param1Float;
    }
    
    public int a(int param1Int) {
      if (this.b instanceof String)
        try {
          return Integer.parseInt((String)this.b);
        } catch (NumberFormatException numberFormatException) {
          return param1Int;
        }  
      return (this.b instanceof Number) ? ((Number)this.b).intValue() : param1Int;
    }
    
    public a a(String param1String) {
      return (this.b instanceof JSONObject) ? a(((JSONObject)this.b).opt(param1String)) : ((this.b instanceof Map) ? a(((Map)this.b).get(param1String)) : a);
    }
    
    public void a(String param1String, Object param1Object) {
      c = null;
      e = null;
      d = null;
      f = null;
      Object object = param1Object;
      if (param1Object instanceof a)
        object = ((a)param1Object).n(); 
      if (this.b instanceof JSONObject)
        try {
          ((JSONObject)this.b).put(param1String, object);
          return;
        } catch (JSONException jSONException) {
          CBLogging.b(this, "Error updating balances dictionary.", (Throwable)jSONException);
          return;
        }  
      if (this.b instanceof Map)
        try {
          ((Map<JSONException, Object>)this.b).put(jSONException, object);
          return;
        } catch (Exception exception) {
          CBLogging.b(this, "Error updating balances dictionary.", exception);
          return;
        }  
    }
    
    public boolean a(boolean param1Boolean) {
      if (this.b instanceof Boolean)
        param1Boolean = ((Boolean)this.b).booleanValue(); 
      return param1Boolean;
    }
    
    public long b(int param1Int) {
      if (this.b instanceof String)
        try {
          return Long.parseLong((String)this.b);
        } catch (NumberFormatException numberFormatException) {
          return param1Int;
        }  
      return (this.b instanceof Number) ? ((Number)this.b).longValue() : param1Int;
    }
    
    public boolean b() {
      return (this.b == null || this.b == JSONObject.NULL);
    }
    
    public boolean b(String param1String) {
      return a(param1String).b();
    }
    
    public a c(int param1Int) {
      if (this.b instanceof JSONArray)
        return a(((JSONArray)this.b).opt(param1Int)); 
      if (this.b instanceof List)
        try {
          return a(((List)this.b).get(param1Int));
        } catch (IndexOutOfBoundsException indexOutOfBoundsException) {
          return a;
        }  
      a a1 = this;
      return (param1Int != 0) ? a : a1;
    }
    
    public boolean c() {
      return !b();
    }
    
    public boolean c(String param1String) {
      return a(param1String).c();
    }
    
    public String d(String param1String) {
      return (this.b instanceof String) ? (String)this.b : param1String;
    }
    
    public boolean d() {
      return !TextUtils.isEmpty(h());
    }
    
    public String e(String param1String) {
      return a(param1String).h();
    }
    
    public JSONObject e() {
      if (this.b instanceof JSONObject)
        return (JSONObject)this.b; 
      if (this.b instanceof Map) {
        if (c == null)
          c = e.a((Map<?, ?>)this.b); 
        return c;
      } 
      return null;
    }
    
    public boolean equals(Object param1Object) {
      param1Object = a(param1Object);
      return b() ? param1Object.b() : ((e() != null && param1Object.e() != null) ? i.a(e(), param1Object.e()) : ((g() != null && param1Object.g() != null) ? i.a(g(), param1Object.g()) : ((this.b instanceof String) ? this.b.equals(param1Object.h()) : ((((a)param1Object).b instanceof String) ? ((a)param1Object).b.equals(h()) : n().equals(param1Object.n())))));
    }
    
    public int f(String param1String) {
      return a(param1String).k();
    }
    
    public Map<String, Object> f() {
      if (this.b instanceof JSONObject) {
        if (d == null)
          d = e.a((JSONObject)this.b); 
        return d;
      } 
      return (this.b instanceof Map) ? (Map<String, Object>)this.b : null;
    }
    
    public double g(String param1String) {
      return a(param1String).i();
    }
    
    public JSONArray g() {
      if (this.b instanceof JSONArray)
        return (JSONArray)this.b; 
      if (this.b instanceof List) {
        if (e == null)
          e = e.a((List)this.b); 
        return e;
      } 
      return null;
    }
    
    public long h(String param1String) {
      return a(param1String).l();
    }
    
    public String h() {
      return b() ? null : ((this.b instanceof String) ? (String)this.b : this.b.toString());
    }
    
    public double i() {
      return a(0.0D);
    }
    
    public boolean i(String param1String) {
      return a(param1String).m();
    }
    
    public float j() {
      return a(0.0F);
    }
    
    public int k() {
      return a(0);
    }
    
    public long l() {
      return b(0);
    }
    
    public boolean m() {
      return a(false);
    }
    
    public Object n() {
      return this.b;
    }
    
    public int o() {
      return (this.b instanceof JSONArray) ? ((JSONArray)this.b).length() : ((this.b instanceof List) ? ((List)this.b).size() : 1);
    }
    
    public String toString() {
      return (e() != null) ? e().toString() : ((g() != null) ? g().toString() : ((this.b != null) ? this.b.toString() : "null"));
    }
  }
  
  public static class b {
    private String a;
    
    private Object b;
    
    public b(String param1String, Object param1Object) {
      this.a = param1String;
      if (param1Object instanceof e.a) {
        this.b = ((e.a)param1Object).n();
        return;
      } 
      this.b = param1Object;
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Smash Cricket-dex2jar.jar!\com\chartboost\sdk\Libraries\e.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */