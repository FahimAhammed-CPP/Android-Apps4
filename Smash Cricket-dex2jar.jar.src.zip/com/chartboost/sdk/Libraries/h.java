package com.chartboost.sdk.Libraries;

import android.content.Context;
import android.os.Environment;
import android.text.TextUtils;
import com.chartboost.sdk.b;
import java.io.File;

public class h {
  private static h e;
  
  public Context a = b.x();
  
  private File b;
  
  private File c;
  
  private File d;
  
  public h(String paramString, boolean paramBoolean) {
    if (this.a == null) {
      CBLogging.b("CBFileCache", "RunTime error: Cannot find context object");
      return;
    } 
    if (!TextUtils.isEmpty(paramString)) {
      this.b = a(paramString, paramBoolean);
      return;
    } 
    this.b = a("CBCommonCacheFolder", paramBoolean);
  }
  
  private File a(String paramString, boolean paramBoolean) {
    File file1;
    if (this.b != null)
      return this.b; 
    if (!paramBoolean || !d()) {
      file1 = new File(new File(this.a.getCacheDir(), "__chartboost"), paramString);
      this.c = file1;
    } else {
      file1 = new File(new File(Environment.getExternalStorageDirectory(), "__chartboost"), (String)file1);
      this.d = file1;
    } 
    File file2 = file1;
    if (!file1.exists()) {
      file1.mkdirs();
      return file1;
    } 
    return file2;
  }
  
  public static h c() {
    // Byte code:
    //   0: ldc com/chartboost/sdk/Libraries/h
    //   2: monitorenter
    //   3: getstatic com/chartboost/sdk/Libraries/h.e : Lcom/chartboost/sdk/Libraries/h;
    //   6: ifnonnull -> 22
    //   9: new com/chartboost/sdk/Libraries/h
    //   12: dup
    //   13: ldc 'CBVideoCompletion'
    //   15: iconst_0
    //   16: invokespecial <init> : (Ljava/lang/String;Z)V
    //   19: putstatic com/chartboost/sdk/Libraries/h.e : Lcom/chartboost/sdk/Libraries/h;
    //   22: getstatic com/chartboost/sdk/Libraries/h.e : Lcom/chartboost/sdk/Libraries/h;
    //   25: astore_0
    //   26: ldc com/chartboost/sdk/Libraries/h
    //   28: monitorexit
    //   29: aload_0
    //   30: areturn
    //   31: astore_0
    //   32: ldc com/chartboost/sdk/Libraries/h
    //   34: monitorexit
    //   35: aload_0
    //   36: athrow
    // Exception table:
    //   from	to	target	type
    //   3	22	31	finally
    //   22	26	31	finally
  }
  
  private boolean d() {
    if (Environment.getExternalStorageState().equals("mounted"))
      return true; 
    CBLogging.e("CBFileCache", "External Storage unavailable");
    return false;
  }
  
  public e.a a(File paramFile) {
    // Byte code:
    //   0: aload_0
    //   1: monitorenter
    //   2: aload_0
    //   3: getfield d : Ljava/io/File;
    //   6: ifnull -> 31
    //   9: aload_0
    //   10: invokespecial d : ()Z
    //   13: ifne -> 31
    //   16: ldc 'CBFileCache'
    //   18: ldc 'External Storage unavailable cannot read from the disk'
    //   20: invokestatic b : (Ljava/lang/Object;Ljava/lang/String;)V
    //   23: getstatic com/chartboost/sdk/Libraries/e$a.a : Lcom/chartboost/sdk/Libraries/e$a;
    //   26: astore_1
    //   27: aload_0
    //   28: monitorexit
    //   29: aload_1
    //   30: areturn
    //   31: aload_0
    //   32: getfield b : Ljava/io/File;
    //   35: ifnonnull -> 45
    //   38: getstatic com/chartboost/sdk/Libraries/e$a.a : Lcom/chartboost/sdk/Libraries/e$a;
    //   41: astore_1
    //   42: goto -> 27
    //   45: new java/lang/String
    //   48: dup
    //   49: aload_1
    //   50: invokestatic b : (Ljava/io/File;)[B
    //   53: invokespecial <init> : ([B)V
    //   56: astore_1
    //   57: aload_1
    //   58: invokestatic j : (Ljava/lang/String;)Lcom/chartboost/sdk/Libraries/e$a;
    //   61: astore_1
    //   62: goto -> 27
    //   65: astore_1
    //   66: ldc 'CBFileCache'
    //   68: ldc 'Error loading cache from disk'
    //   70: aload_1
    //   71: invokestatic b : (Ljava/lang/Object;Ljava/lang/String;Ljava/lang/Throwable;)V
    //   74: aconst_null
    //   75: astore_1
    //   76: goto -> 57
    //   79: astore_1
    //   80: aload_0
    //   81: monitorexit
    //   82: aload_1
    //   83: athrow
    // Exception table:
    //   from	to	target	type
    //   2	27	79	finally
    //   31	42	79	finally
    //   45	57	65	java/lang/Exception
    //   45	57	79	finally
    //   57	62	79	finally
    //   66	74	79	finally
  }
  
  public e.a a(String paramString) {
    // Byte code:
    //   0: aload_0
    //   1: monitorenter
    //   2: aload_0
    //   3: getfield d : Ljava/io/File;
    //   6: ifnull -> 31
    //   9: aload_0
    //   10: invokespecial d : ()Z
    //   13: ifne -> 31
    //   16: ldc 'CBFileCache'
    //   18: ldc 'External Storage unavailable cannot read from the disk'
    //   20: invokestatic b : (Ljava/lang/Object;Ljava/lang/String;)V
    //   23: getstatic com/chartboost/sdk/Libraries/e$a.a : Lcom/chartboost/sdk/Libraries/e$a;
    //   26: astore_1
    //   27: aload_0
    //   28: monitorexit
    //   29: aload_1
    //   30: areturn
    //   31: aload_0
    //   32: getfield b : Ljava/io/File;
    //   35: ifnull -> 42
    //   38: aload_1
    //   39: ifnonnull -> 49
    //   42: getstatic com/chartboost/sdk/Libraries/e$a.a : Lcom/chartboost/sdk/Libraries/e$a;
    //   45: astore_1
    //   46: goto -> 27
    //   49: new java/io/File
    //   52: dup
    //   53: aload_0
    //   54: getfield b : Ljava/io/File;
    //   57: aload_1
    //   58: invokespecial <init> : (Ljava/io/File;Ljava/lang/String;)V
    //   61: astore_1
    //   62: aload_1
    //   63: invokevirtual exists : ()Z
    //   66: ifne -> 76
    //   69: getstatic com/chartboost/sdk/Libraries/e$a.a : Lcom/chartboost/sdk/Libraries/e$a;
    //   72: astore_1
    //   73: goto -> 27
    //   76: aload_0
    //   77: aload_1
    //   78: invokevirtual a : (Ljava/io/File;)Lcom/chartboost/sdk/Libraries/e$a;
    //   81: astore_1
    //   82: goto -> 27
    //   85: astore_1
    //   86: aload_0
    //   87: monitorexit
    //   88: aload_1
    //   89: athrow
    // Exception table:
    //   from	to	target	type
    //   2	27	85	finally
    //   31	38	85	finally
    //   42	46	85	finally
    //   49	73	85	finally
    //   76	82	85	finally
  }
  
  public File a(File paramFile, e.a parama) {
    // Byte code:
    //   0: aconst_null
    //   1: astore_3
    //   2: aload_0
    //   3: monitorenter
    //   4: aload_0
    //   5: getfield d : Ljava/io/File;
    //   8: ifnull -> 29
    //   11: aload_0
    //   12: invokespecial d : ()Z
    //   15: ifne -> 29
    //   18: ldc 'CBFileCache'
    //   20: ldc 'External Storage unavailable cannot write to the disk'
    //   22: invokestatic b : (Ljava/lang/Object;Ljava/lang/String;)V
    //   25: aload_0
    //   26: monitorexit
    //   27: aload_3
    //   28: areturn
    //   29: aload_0
    //   30: getfield b : Ljava/io/File;
    //   33: ifnull -> 25
    //   36: aload_1
    //   37: ifnonnull -> 96
    //   40: new java/io/File
    //   43: dup
    //   44: aload_0
    //   45: getfield b : Ljava/io/File;
    //   48: invokevirtual getPath : ()Ljava/lang/String;
    //   51: invokestatic nanoTime : ()J
    //   54: invokestatic toString : (J)Ljava/lang/String;
    //   57: invokespecial <init> : (Ljava/lang/String;Ljava/lang/String;)V
    //   60: astore_1
    //   61: aload_1
    //   62: aload_2
    //   63: invokevirtual toString : ()Ljava/lang/String;
    //   66: invokevirtual getBytes : ()[B
    //   69: invokestatic a : (Ljava/io/File;[B)V
    //   72: aload_1
    //   73: astore_3
    //   74: goto -> 25
    //   77: astore_2
    //   78: ldc 'CBFileCache'
    //   80: ldc 'IOException attempting to write cache to disk'
    //   82: aload_2
    //   83: invokestatic b : (Ljava/lang/Object;Ljava/lang/String;Ljava/lang/Throwable;)V
    //   86: aload_1
    //   87: astore_3
    //   88: goto -> 25
    //   91: astore_1
    //   92: aload_0
    //   93: monitorexit
    //   94: aload_1
    //   95: athrow
    //   96: goto -> 61
    // Exception table:
    //   from	to	target	type
    //   4	25	91	finally
    //   29	36	91	finally
    //   40	61	91	finally
    //   61	72	77	java/io/IOException
    //   61	72	91	finally
    //   78	86	91	finally
  }
  
  public File a(String paramString, e.a parama) {
    // Byte code:
    //   0: aconst_null
    //   1: astore #4
    //   3: aconst_null
    //   4: astore_3
    //   5: aload_0
    //   6: monitorenter
    //   7: aload_0
    //   8: getfield d : Ljava/io/File;
    //   11: ifnull -> 32
    //   14: aload_0
    //   15: invokespecial d : ()Z
    //   18: ifne -> 32
    //   21: ldc 'CBFileCache'
    //   23: ldc 'External Storage unavailable cannot write to the disk'
    //   25: invokestatic b : (Ljava/lang/Object;Ljava/lang/String;)V
    //   28: aload_0
    //   29: monitorexit
    //   30: aload_3
    //   31: areturn
    //   32: aload_0
    //   33: getfield b : Ljava/io/File;
    //   36: ifnull -> 28
    //   39: aload #4
    //   41: astore_3
    //   42: aload_1
    //   43: invokestatic isEmpty : (Ljava/lang/CharSequence;)Z
    //   46: ifne -> 65
    //   49: new java/io/File
    //   52: dup
    //   53: aload_0
    //   54: getfield b : Ljava/io/File;
    //   57: invokevirtual getPath : ()Ljava/lang/String;
    //   60: aload_1
    //   61: invokespecial <init> : (Ljava/lang/String;Ljava/lang/String;)V
    //   64: astore_3
    //   65: aload_0
    //   66: aload_3
    //   67: aload_2
    //   68: invokevirtual a : (Ljava/io/File;Lcom/chartboost/sdk/Libraries/e$a;)Ljava/io/File;
    //   71: astore_3
    //   72: goto -> 28
    //   75: astore_1
    //   76: aload_0
    //   77: monitorexit
    //   78: aload_1
    //   79: athrow
    // Exception table:
    //   from	to	target	type
    //   7	28	75	finally
    //   32	39	75	finally
    //   42	65	75	finally
    //   65	72	75	finally
  }
  
  public void a(File paramFile, byte[] paramArrayOfbyte) {
    // Byte code:
    //   0: aload_0
    //   1: monitorenter
    //   2: aload_0
    //   3: getfield d : Ljava/io/File;
    //   6: ifnull -> 26
    //   9: aload_0
    //   10: invokespecial d : ()Z
    //   13: ifne -> 26
    //   16: ldc 'CBFileCache'
    //   18: ldc 'External Storage unavailable cannot write to the disk'
    //   20: invokestatic b : (Ljava/lang/Object;Ljava/lang/String;)V
    //   23: aload_0
    //   24: monitorexit
    //   25: return
    //   26: aload_0
    //   27: getfield b : Ljava/io/File;
    //   30: ifnull -> 23
    //   33: aload_2
    //   34: ifnull -> 23
    //   37: aload_1
    //   38: astore_3
    //   39: aload_1
    //   40: ifnonnull -> 64
    //   43: new java/io/File
    //   46: dup
    //   47: aload_0
    //   48: getfield b : Ljava/io/File;
    //   51: invokevirtual getPath : ()Ljava/lang/String;
    //   54: invokestatic nanoTime : ()J
    //   57: invokestatic toString : (J)Ljava/lang/String;
    //   60: invokespecial <init> : (Ljava/lang/String;Ljava/lang/String;)V
    //   63: astore_3
    //   64: aload_3
    //   65: aload_2
    //   66: invokestatic a : (Ljava/io/File;[B)V
    //   69: goto -> 23
    //   72: astore_1
    //   73: ldc 'CBFileCache'
    //   75: ldc 'IOException attempting to write cache to disk'
    //   77: aload_1
    //   78: invokestatic b : (Ljava/lang/Object;Ljava/lang/String;Ljava/lang/Throwable;)V
    //   81: goto -> 23
    //   84: astore_1
    //   85: aload_0
    //   86: monitorexit
    //   87: aload_1
    //   88: athrow
    // Exception table:
    //   from	to	target	type
    //   2	23	84	finally
    //   26	33	84	finally
    //   43	64	84	finally
    //   64	69	72	java/io/IOException
    //   64	69	84	finally
    //   73	81	84	finally
  }
  
  public void a(String paramString, byte[] paramArrayOfbyte) {
    // Byte code:
    //   0: aload_0
    //   1: monitorenter
    //   2: aload_0
    //   3: getfield d : Ljava/io/File;
    //   6: ifnull -> 26
    //   9: aload_0
    //   10: invokespecial d : ()Z
    //   13: ifne -> 26
    //   16: ldc 'CBFileCache'
    //   18: ldc 'External Storage unavailable cannot write to the disk'
    //   20: invokestatic b : (Ljava/lang/Object;Ljava/lang/String;)V
    //   23: aload_0
    //   24: monitorexit
    //   25: return
    //   26: aload_0
    //   27: getfield b : Ljava/io/File;
    //   30: ifnull -> 23
    //   33: aconst_null
    //   34: astore_3
    //   35: aload_1
    //   36: invokestatic isEmpty : (Ljava/lang/CharSequence;)Z
    //   39: ifne -> 58
    //   42: new java/io/File
    //   45: dup
    //   46: aload_0
    //   47: getfield b : Ljava/io/File;
    //   50: invokevirtual getPath : ()Ljava/lang/String;
    //   53: aload_1
    //   54: invokespecial <init> : (Ljava/lang/String;Ljava/lang/String;)V
    //   57: astore_3
    //   58: aload_0
    //   59: aload_3
    //   60: aload_2
    //   61: invokevirtual a : (Ljava/io/File;[B)V
    //   64: goto -> 23
    //   67: astore_1
    //   68: aload_0
    //   69: monitorexit
    //   70: aload_1
    //   71: athrow
    // Exception table:
    //   from	to	target	type
    //   2	23	67	finally
    //   26	33	67	finally
    //   35	58	67	finally
    //   58	64	67	finally
  }
  
  public String[] a() {
    // Byte code:
    //   0: aconst_null
    //   1: astore_1
    //   2: aload_0
    //   3: monitorenter
    //   4: aload_0
    //   5: getfield d : Ljava/io/File;
    //   8: ifnull -> 29
    //   11: aload_0
    //   12: invokespecial d : ()Z
    //   15: ifne -> 29
    //   18: ldc 'CBFileCache'
    //   20: ldc 'External Storage unavailable cannot read from the disk'
    //   22: invokestatic b : (Ljava/lang/Object;Ljava/lang/String;)V
    //   25: aload_0
    //   26: monitorexit
    //   27: aload_1
    //   28: areturn
    //   29: aload_0
    //   30: getfield b : Ljava/io/File;
    //   33: ifnull -> 25
    //   36: aload_0
    //   37: getfield b : Ljava/io/File;
    //   40: invokevirtual list : ()[Ljava/lang/String;
    //   43: astore_1
    //   44: goto -> 25
    //   47: astore_1
    //   48: aload_0
    //   49: monitorexit
    //   50: aload_1
    //   51: athrow
    // Exception table:
    //   from	to	target	type
    //   4	25	47	finally
    //   29	44	47	finally
  }
  
  public void b() {
    // Byte code:
    //   0: iconst_0
    //   1: istore_2
    //   2: aload_0
    //   3: monitorenter
    //   4: aload_0
    //   5: getfield d : Ljava/io/File;
    //   8: ifnull -> 28
    //   11: aload_0
    //   12: invokespecial d : ()Z
    //   15: ifne -> 28
    //   18: ldc 'CBFileCache'
    //   20: ldc 'External Storage unavailable cannot delete from the disk'
    //   22: invokestatic b : (Ljava/lang/Object;Ljava/lang/String;)V
    //   25: aload_0
    //   26: monitorexit
    //   27: return
    //   28: aload_0
    //   29: getfield b : Ljava/io/File;
    //   32: astore #4
    //   34: aload #4
    //   36: ifnull -> 25
    //   39: aload_0
    //   40: getfield d : Ljava/io/File;
    //   43: ifnull -> 86
    //   46: aload_0
    //   47: getfield d : Ljava/io/File;
    //   50: invokevirtual listFiles : ()[Ljava/io/File;
    //   53: astore #4
    //   55: aload #4
    //   57: ifnull -> 86
    //   60: aload #4
    //   62: arraylength
    //   63: istore_3
    //   64: iconst_0
    //   65: istore_1
    //   66: iload_1
    //   67: iload_3
    //   68: if_icmpge -> 86
    //   71: aload #4
    //   73: iload_1
    //   74: aaload
    //   75: invokevirtual delete : ()Z
    //   78: pop
    //   79: iload_1
    //   80: iconst_1
    //   81: iadd
    //   82: istore_1
    //   83: goto -> 66
    //   86: aload_0
    //   87: getfield c : Ljava/io/File;
    //   90: ifnull -> 25
    //   93: aload_0
    //   94: getfield c : Ljava/io/File;
    //   97: invokevirtual listFiles : ()[Ljava/io/File;
    //   100: astore #4
    //   102: aload #4
    //   104: ifnull -> 25
    //   107: aload #4
    //   109: arraylength
    //   110: istore_3
    //   111: iload_2
    //   112: istore_1
    //   113: iload_1
    //   114: iload_3
    //   115: if_icmpge -> 25
    //   118: aload #4
    //   120: iload_1
    //   121: aaload
    //   122: invokevirtual delete : ()Z
    //   125: pop
    //   126: iload_1
    //   127: iconst_1
    //   128: iadd
    //   129: istore_1
    //   130: goto -> 113
    //   133: astore #4
    //   135: ldc 'CBFileCache'
    //   137: ldc 'Error while clearing the file cache'
    //   139: invokestatic b : (Ljava/lang/Object;Ljava/lang/String;)V
    //   142: goto -> 25
    //   145: astore #4
    //   147: aload_0
    //   148: monitorexit
    //   149: aload #4
    //   151: athrow
    // Exception table:
    //   from	to	target	type
    //   4	25	145	finally
    //   28	34	145	finally
    //   39	55	133	java/lang/Exception
    //   39	55	145	finally
    //   60	64	133	java/lang/Exception
    //   60	64	145	finally
    //   71	79	133	java/lang/Exception
    //   71	79	145	finally
    //   86	102	133	java/lang/Exception
    //   86	102	145	finally
    //   107	111	133	java/lang/Exception
    //   107	111	145	finally
    //   118	126	133	java/lang/Exception
    //   118	126	145	finally
    //   135	142	145	finally
  }
  
  public void b(String paramString) {
    // Byte code:
    //   0: aload_0
    //   1: monitorenter
    //   2: aload_1
    //   3: invokestatic isEmpty : (Ljava/lang/CharSequence;)Z
    //   6: ifne -> 18
    //   9: aload_0
    //   10: aload_0
    //   11: aload_1
    //   12: invokevirtual d : (Ljava/lang/String;)Ljava/io/File;
    //   15: invokevirtual c : (Ljava/io/File;)V
    //   18: aload_0
    //   19: monitorexit
    //   20: return
    //   21: astore_1
    //   22: aload_0
    //   23: monitorexit
    //   24: aload_1
    //   25: athrow
    // Exception table:
    //   from	to	target	type
    //   2	18	21	finally
  }
  
  public byte[] b(File paramFile) {
    // Byte code:
    //   0: aconst_null
    //   1: astore_3
    //   2: aload_0
    //   3: monitorenter
    //   4: aload_0
    //   5: getfield d : Ljava/io/File;
    //   8: ifnull -> 31
    //   11: aload_0
    //   12: invokespecial d : ()Z
    //   15: ifne -> 31
    //   18: ldc 'CBFileCache'
    //   20: ldc 'External Storage unavailable cannot read from the disk'
    //   22: invokestatic b : (Ljava/lang/Object;Ljava/lang/String;)V
    //   25: aload_3
    //   26: astore_2
    //   27: aload_0
    //   28: monitorexit
    //   29: aload_2
    //   30: areturn
    //   31: aload_0
    //   32: getfield b : Ljava/io/File;
    //   35: astore #4
    //   37: aload_3
    //   38: astore_2
    //   39: aload #4
    //   41: ifnull -> 27
    //   44: aload_1
    //   45: invokestatic b : (Ljava/io/File;)[B
    //   48: astore_2
    //   49: goto -> 27
    //   52: astore_1
    //   53: ldc 'CBFileCache'
    //   55: ldc 'Error loading cache from disk'
    //   57: aload_1
    //   58: invokestatic b : (Ljava/lang/Object;Ljava/lang/String;Ljava/lang/Throwable;)V
    //   61: aload_3
    //   62: astore_2
    //   63: goto -> 27
    //   66: astore_1
    //   67: aload_0
    //   68: monitorexit
    //   69: aload_1
    //   70: athrow
    // Exception table:
    //   from	to	target	type
    //   4	25	66	finally
    //   31	37	66	finally
    //   44	49	52	java/lang/Exception
    //   44	49	66	finally
    //   53	61	66	finally
  }
  
  public void c(File paramFile) {
    // Byte code:
    //   0: aload_0
    //   1: monitorenter
    //   2: aload_1
    //   3: ifnull -> 18
    //   6: aload_1
    //   7: invokevirtual exists : ()Z
    //   10: ifeq -> 18
    //   13: aload_1
    //   14: invokevirtual delete : ()Z
    //   17: pop
    //   18: aload_0
    //   19: monitorexit
    //   20: return
    //   21: astore_1
    //   22: aload_0
    //   23: monitorexit
    //   24: aload_1
    //   25: athrow
    // Exception table:
    //   from	to	target	type
    //   6	18	21	finally
  }
  
  public boolean c(String paramString) {
    return ((this.d == null || d()) && this.b != null && paramString != null) ? (new File(this.b.getPath(), paramString)).exists() : false;
  }
  
  public File d(String paramString) {
    if (this.d != null && !d()) {
      CBLogging.b("CBFileCache", "External Storage unavailable cannot read from the disk");
      return null;
    } 
    return (this.b != null) ? new File(this.b.getPath(), paramString) : null;
  }
}


/* Location:              C:\soft\dex2jar-2.0\Smash Cricket-dex2jar.jar!\com\chartboost\sdk\Libraries\h.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */