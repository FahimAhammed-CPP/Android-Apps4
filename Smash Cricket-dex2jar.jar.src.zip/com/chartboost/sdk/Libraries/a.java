package com.chartboost.sdk.Libraries;

public interface a {
  public static final g.a a = g.a(new g.a[] { g.b(), new g.e() {
          public String a() {
            return "Must be a valid status code (>=200 && <300)";
          }
          
          public boolean a(Object param1Object) {
            int i = ((Number)param1Object).intValue();
            return (i >= 200 && i < 300);
          }
        } });
}


/* Location:              C:\soft\dex2jar-2.0\Smash Cricket-dex2jar.jar!\com\chartboost\sdk\Libraries\a.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */