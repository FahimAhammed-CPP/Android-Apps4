package com.chartboost.sdk.Libraries;

public enum f {
  a, b, c, d;
  
  public static final f e;
  
  public static final f f;
  
  public static final f g;
  
  public static final f h;
  
  static {
    e = c;
    f = a;
    g = b;
    h = d;
  }
  
  public f a() {
    switch (null.a[ordinal()]) {
      default:
        return g;
      case 1:
        return e;
      case 2:
        return h;
      case 3:
        break;
    } 
    return f;
  }
  
  public boolean b() {
    return (this == a || this == c);
  }
  
  public boolean c() {
    return (this == b || this == d);
  }
}


/* Location:              C:\soft\dex2jar-2.0\Smash Cricket-dex2jar.jar!\com\chartboost\sdk\Libraries\f.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */