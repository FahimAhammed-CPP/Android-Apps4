package com.chartboost.sdk.Libraries;

import java.math.BigInteger;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.util.Locale;

public final class b {
  public static byte[] a(byte[] paramArrayOfbyte) {
    MessageDigest messageDigest = null;
    if (paramArrayOfbyte != null)
      try {
        messageDigest = MessageDigest.getInstance("SHA-1");
        messageDigest.update(paramArrayOfbyte);
        return messageDigest.digest();
      } catch (NoSuchAlgorithmException noSuchAlgorithmException) {
        return null;
      }  
    return (byte[])messageDigest;
  }
  
  public static String b(byte[] paramArrayOfbyte) {
    if (paramArrayOfbyte == null)
      return null; 
    BigInteger bigInteger = new BigInteger(1, paramArrayOfbyte);
    return String.format(Locale.US, "%0" + (paramArrayOfbyte.length << 1) + "x", new Object[] { bigInteger });
  }
}


/* Location:              C:\soft\dex2jar-2.0\Smash Cricket-dex2jar.jar!\com\chartboost\sdk\Libraries\b.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */