package com.chartboost.sdk.Libraries;

import java.math.BigDecimal;
import java.math.BigInteger;
import org.json.JSONArray;
import org.json.JSONObject;

public final class i {
  private static final String a = i.class.getSimpleName();
  
  private static BigDecimal a(Number paramNumber) {
    if (paramNumber instanceof BigDecimal)
      return (BigDecimal)paramNumber; 
    if (paramNumber instanceof BigInteger)
      return new BigDecimal((BigInteger)paramNumber); 
    if (paramNumber instanceof Byte || paramNumber instanceof Short || paramNumber instanceof Integer || paramNumber instanceof Long)
      return new BigDecimal(paramNumber.longValue()); 
    if (paramNumber instanceof Float || paramNumber instanceof Double)
      return new BigDecimal(paramNumber.doubleValue()); 
    try {
      return new BigDecimal(paramNumber.toString());
    } catch (NumberFormatException numberFormatException) {
      CBLogging.b(a, "The given number (\"" + paramNumber + "\" of class " + paramNumber.getClass().getName() + ") does not have a parsable string representation", numberFormatException);
      return null;
    } 
  }
  
  private static boolean a(Object paramObject) {
    return (paramObject != null && paramObject != JSONObject.NULL);
  }
  
  public static boolean a(Object paramObject1, Object paramObject2) {
    return (paramObject1 == paramObject2);
  }
  
  public static boolean a(JSONArray paramJSONArray1, JSONArray paramJSONArray2) {
    if (paramJSONArray1.length() == paramJSONArray2.length() || b(paramJSONArray1.toString(), paramJSONArray2.toString())) {
      for (int j = 0; j < paramJSONArray1.length(); j++) {
        Object object1 = paramJSONArray1.opt(j);
        Object object2 = paramJSONArray2.opt(j);
        if (a(object1.getClass(), object2.getClass()) || (Number.class.isInstance(object1) && Number.class.isInstance(object2))) {
          if (object1 instanceof JSONObject) {
            if (a((JSONObject)object1, (JSONObject)object2))
              continue; 
            return false;
          } 
          if (object1 instanceof JSONArray) {
            if (!a((JSONArray)object1, (JSONArray)object2))
              return false; 
          } else if (!b(object1, object2)) {
            return false;
          } 
          continue;
        } 
        return false;
      } 
      return true;
    } 
    return false;
  }
  
  public static boolean a(JSONObject paramJSONObject1, JSONObject paramJSONObject2) {
    // Byte code:
    //   0: aload_0
    //   1: invokevirtual length : ()I
    //   4: aload_1
    //   5: invokevirtual length : ()I
    //   8: if_icmpeq -> 31
    //   11: aload_0
    //   12: iconst_2
    //   13: invokevirtual toString : (I)Ljava/lang/String;
    //   16: aload_1
    //   17: iconst_2
    //   18: invokevirtual toString : (I)Ljava/lang/String;
    //   21: invokestatic b : (Ljava/lang/Object;Ljava/lang/Object;)Z
    //   24: istore_3
    //   25: iload_3
    //   26: ifne -> 31
    //   29: iconst_0
    //   30: ireturn
    //   31: aload_0
    //   32: invokevirtual names : ()Lorg/json/JSONArray;
    //   35: astore #4
    //   37: aload #4
    //   39: ifnonnull -> 51
    //   42: aload_1
    //   43: invokevirtual names : ()Lorg/json/JSONArray;
    //   46: ifnonnull -> 51
    //   49: iconst_1
    //   50: ireturn
    //   51: iconst_0
    //   52: istore_2
    //   53: iload_2
    //   54: aload #4
    //   56: invokevirtual length : ()I
    //   59: if_icmpge -> 207
    //   62: aload #4
    //   64: iload_2
    //   65: invokevirtual optString : (I)Ljava/lang/String;
    //   68: astore #6
    //   70: aload_0
    //   71: aload #6
    //   73: invokevirtual opt : (Ljava/lang/String;)Ljava/lang/Object;
    //   76: astore #5
    //   78: aload_1
    //   79: aload #6
    //   81: invokevirtual opt : (Ljava/lang/String;)Ljava/lang/Object;
    //   84: astore #6
    //   86: aload #5
    //   88: invokestatic a : (Ljava/lang/Object;)Z
    //   91: ifeq -> 102
    //   94: aload #6
    //   96: invokestatic a : (Ljava/lang/Object;)Z
    //   99: ifeq -> 29
    //   102: aload #5
    //   104: invokevirtual getClass : ()Ljava/lang/Class;
    //   107: aload #6
    //   109: invokevirtual getClass : ()Ljava/lang/Class;
    //   112: invokestatic a : (Ljava/lang/Object;Ljava/lang/Object;)Z
    //   115: ifne -> 138
    //   118: ldc java/lang/Number
    //   120: aload #5
    //   122: invokevirtual isInstance : (Ljava/lang/Object;)Z
    //   125: ifeq -> 29
    //   128: ldc java/lang/Number
    //   130: aload #6
    //   132: invokevirtual isInstance : (Ljava/lang/Object;)Z
    //   135: ifeq -> 29
    //   138: aload #5
    //   140: instanceof org/json/JSONObject
    //   143: ifeq -> 169
    //   146: aload #5
    //   148: checkcast org/json/JSONObject
    //   151: aload #6
    //   153: checkcast org/json/JSONObject
    //   156: invokestatic a : (Lorg/json/JSONObject;Lorg/json/JSONObject;)Z
    //   159: ifeq -> 29
    //   162: iload_2
    //   163: iconst_1
    //   164: iadd
    //   165: istore_2
    //   166: goto -> 53
    //   169: aload #5
    //   171: instanceof org/json/JSONArray
    //   174: ifeq -> 195
    //   177: aload #5
    //   179: checkcast org/json/JSONArray
    //   182: aload #6
    //   184: checkcast org/json/JSONArray
    //   187: invokestatic a : (Lorg/json/JSONArray;Lorg/json/JSONArray;)Z
    //   190: ifne -> 162
    //   193: iconst_0
    //   194: ireturn
    //   195: aload #5
    //   197: aload #6
    //   199: invokestatic b : (Ljava/lang/Object;Ljava/lang/Object;)Z
    //   202: ifne -> 162
    //   205: iconst_0
    //   206: ireturn
    //   207: iconst_1
    //   208: ireturn
    //   209: astore_0
    //   210: iconst_0
    //   211: ireturn
    // Exception table:
    //   from	to	target	type
    //   11	25	209	org/json/JSONException
  }
  
  public static boolean b(Object paramObject1, Object paramObject2) {
    boolean bool = true;
    if (paramObject1 == null || paramObject1 == JSONObject.NULL)
      return (paramObject2 == null || paramObject2 == JSONObject.NULL); 
    if (Number.class.isInstance(paramObject1) && Number.class.isInstance(paramObject2)) {
      try {
        int j = a((Number)paramObject1).compareTo(a((Number)paramObject2));
        if (j != 0)
          return false; 
      } catch (RuntimeException runtimeException) {
        CBLogging.b(a, "Error comparing big decimal values");
      } 
      return bool;
    } 
    return paramObject1.equals(paramObject2);
  }
}


/* Location:              C:\soft\dex2jar-2.0\Smash Cricket-dex2jar.jar!\com\chartboost\sdk\Libraries\i.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */