package com.chartboost.sdk.Libraries;

import android.content.Context;
import android.content.SharedPreferences;
import android.os.Build;
import android.os.Environment;
import android.os.Handler;
import android.os.Looper;
import com.chartboost.sdk.Chartboost;
import com.chartboost.sdk.b;
import java.io.File;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Map;
import java.util.TimeZone;
import javax.security.auth.x500.X500Principal;
import org.apache.http.HttpEntity;
import org.apache.http.HttpResponse;

public final class CBUtility {
  private static Boolean a = null;
  
  private static final X500Principal b = new X500Principal("CN=Android Debug,O=Android,C=US");
  
  private static Handler c;
  
  public static float a(float paramFloat, Context paramContext) {
    return b(paramContext) * paramFloat;
  }
  
  public static int a(int paramInt, Context paramContext) {
    return Math.round(paramInt * b(paramContext));
  }
  
  public static SharedPreferences a() {
    if (b.x() == null) {
      CBLogging.b("CBUtility", "The context must be set through the Chartboost method onCreate() before modifying or accessing preferences.");
      return null;
    } 
    return b.x().getSharedPreferences("cbPrefs", 0);
  }
  
  public static String a(Map<String, Object> paramMap) {
    // Byte code:
    //   0: aload_0
    //   1: ifnonnull -> 7
    //   4: ldc ''
    //   6: areturn
    //   7: new java/lang/StringBuilder
    //   10: dup
    //   11: invokespecial <init> : ()V
    //   14: astore_2
    //   15: aload_0
    //   16: invokeinterface keySet : ()Ljava/util/Set;
    //   21: invokeinterface isEmpty : ()Z
    //   26: ifne -> 36
    //   29: aload_2
    //   30: ldc '?'
    //   32: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   35: pop
    //   36: aload_0
    //   37: invokeinterface keySet : ()Ljava/util/Set;
    //   42: invokeinterface iterator : ()Ljava/util/Iterator;
    //   47: astore_3
    //   48: aload_3
    //   49: invokeinterface hasNext : ()Z
    //   54: ifeq -> 163
    //   57: aload_3
    //   58: invokeinterface next : ()Ljava/lang/Object;
    //   63: checkcast java/lang/String
    //   66: astore_1
    //   67: aload_2
    //   68: invokevirtual length : ()I
    //   71: iconst_1
    //   72: if_icmple -> 82
    //   75: aload_2
    //   76: ldc '&'
    //   78: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   81: pop
    //   82: aload_0
    //   83: aload_1
    //   84: invokeinterface get : (Ljava/lang/Object;)Ljava/lang/Object;
    //   89: invokevirtual toString : ()Ljava/lang/String;
    //   92: astore #4
    //   94: aload_1
    //   95: ifnull -> 151
    //   98: aload_1
    //   99: ldc 'UTF-8'
    //   101: invokestatic encode : (Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;
    //   104: astore_1
    //   105: aload_2
    //   106: aload_1
    //   107: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   110: pop
    //   111: aload_2
    //   112: ldc '='
    //   114: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   117: pop
    //   118: aload #4
    //   120: ifnull -> 157
    //   123: aload #4
    //   125: ldc 'UTF-8'
    //   127: invokestatic encode : (Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;
    //   130: astore_1
    //   131: aload_2
    //   132: aload_1
    //   133: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   136: pop
    //   137: goto -> 48
    //   140: astore_0
    //   141: ldc 'CBUtility'
    //   143: ldc 'This method requires UTF-8 encoding support'
    //   145: aload_0
    //   146: invokestatic b : (Ljava/lang/Object;Ljava/lang/String;Ljava/lang/Throwable;)V
    //   149: aconst_null
    //   150: areturn
    //   151: ldc ''
    //   153: astore_1
    //   154: goto -> 105
    //   157: ldc ''
    //   159: astore_1
    //   160: goto -> 131
    //   163: aload_2
    //   164: invokevirtual toString : ()Ljava/lang/String;
    //   167: areturn
    // Exception table:
    //   from	to	target	type
    //   98	105	140	java/io/UnsupportedEncodingException
    //   105	118	140	java/io/UnsupportedEncodingException
    //   123	131	140	java/io/UnsupportedEncodingException
    //   131	137	140	java/io/UnsupportedEncodingException
  }
  
  public static void a(Handler paramHandler) {
    c = paramHandler;
  }
  
  private static void a(File paramFile) {
    if (!paramFile.exists())
      paramFile.mkdirs(); 
    paramFile = new File(paramFile, ".nomedia");
    if (!paramFile.exists())
      try {
        paramFile.createNewFile();
        return;
      } catch (IOException iOException) {
        iOException.printStackTrace();
        return;
      }  
  }
  
  public static void a(HttpEntity paramHttpEntity) {
    try {
      paramHttpEntity.consumeContent();
      return;
    } catch (Exception exception) {
      CBLogging.b("CBUtility", "Exception raised calling entity.consumeContent()", exception);
      return;
    } 
  }
  
  public static void a(HttpResponse paramHttpResponse) {
    if (paramHttpResponse != null)
      try {
        if (paramHttpResponse.getEntity() != null)
          a(paramHttpResponse.getEntity()); 
        return;
      } catch (Exception exception) {
        CBLogging.b("CBUtility", "Exception raised calling consumeQuietly over http response", exception);
        return;
      }  
  }
  
  public static boolean a(Context paramContext) {
    // Byte code:
    //   0: getstatic com/chartboost/sdk/Libraries/CBUtility.a : Ljava/lang/Boolean;
    //   3: ifnonnull -> 99
    //   6: aload_0
    //   7: invokevirtual getPackageManager : ()Landroid/content/pm/PackageManager;
    //   10: aload_0
    //   11: invokevirtual getPackageName : ()Ljava/lang/String;
    //   14: bipush #64
    //   16: invokevirtual getPackageInfo : (Ljava/lang/String;I)Landroid/content/pm/PackageInfo;
    //   19: getfield signatures : [Landroid/content/pm/Signature;
    //   22: astore #4
    //   24: iconst_0
    //   25: istore_1
    //   26: iconst_0
    //   27: istore_2
    //   28: iload_1
    //   29: aload #4
    //   31: arraylength
    //   32: if_icmpge -> 130
    //   35: ldc 'X.509'
    //   37: invokestatic getInstance : (Ljava/lang/String;)Ljava/security/cert/CertificateFactory;
    //   40: new java/io/ByteArrayInputStream
    //   43: dup
    //   44: aload #4
    //   46: iload_1
    //   47: aaload
    //   48: invokevirtual toByteArray : ()[B
    //   51: invokespecial <init> : ([B)V
    //   54: invokevirtual generateCertificate : (Ljava/io/InputStream;)Ljava/security/cert/Certificate;
    //   57: checkcast java/security/cert/X509Certificate
    //   60: invokevirtual getSubjectX500Principal : ()Ljavax/security/auth/x500/X500Principal;
    //   63: getstatic com/chartboost/sdk/Libraries/CBUtility.b : Ljavax/security/auth/x500/X500Principal;
    //   66: invokevirtual equals : (Ljava/lang/Object;)Z
    //   69: istore_3
    //   70: iload_3
    //   71: istore_2
    //   72: iload_2
    //   73: ifeq -> 106
    //   76: aload_0
    //   77: invokevirtual getApplicationInfo : ()Landroid/content/pm/ApplicationInfo;
    //   80: getfield flags : I
    //   83: iconst_2
    //   84: iand
    //   85: ifeq -> 113
    //   88: iconst_1
    //   89: istore_1
    //   90: iload_2
    //   91: iload_1
    //   92: ior
    //   93: invokestatic valueOf : (Z)Ljava/lang/Boolean;
    //   96: putstatic com/chartboost/sdk/Libraries/CBUtility.a : Ljava/lang/Boolean;
    //   99: getstatic com/chartboost/sdk/Libraries/CBUtility.a : Ljava/lang/Boolean;
    //   102: invokevirtual booleanValue : ()Z
    //   105: ireturn
    //   106: iload_1
    //   107: iconst_1
    //   108: iadd
    //   109: istore_1
    //   110: goto -> 28
    //   113: iconst_0
    //   114: istore_1
    //   115: goto -> 90
    //   118: astore #4
    //   120: iconst_0
    //   121: istore_2
    //   122: goto -> 76
    //   125: astore #4
    //   127: goto -> 76
    //   130: goto -> 76
    // Exception table:
    //   from	to	target	type
    //   6	24	118	java/lang/Exception
    //   28	70	125	java/lang/Exception
  }
  
  public static float b(Context paramContext) {
    return (paramContext.getResources().getDisplayMetrics()).density;
  }
  
  public static boolean b() {
    return (Looper.myLooper() == Looper.getMainLooper());
  }
  
  public static f c() {
    // Byte code:
    //   0: invokestatic x : ()Landroid/content/Context;
    //   3: astore_3
    //   4: aload_3
    //   5: ldc_w 'window'
    //   8: invokevirtual getSystemService : (Ljava/lang/String;)Ljava/lang/Object;
    //   11: checkcast android/view/WindowManager
    //   14: invokeinterface getDefaultDisplay : ()Landroid/view/Display;
    //   19: astore #4
    //   21: aload_3
    //   22: invokevirtual getResources : ()Landroid/content/res/Resources;
    //   25: invokevirtual getConfiguration : ()Landroid/content/res/Configuration;
    //   28: getfield orientation : I
    //   31: istore_1
    //   32: aload #4
    //   34: invokevirtual getRotation : ()I
    //   37: istore_2
    //   38: aload #4
    //   40: invokevirtual getWidth : ()I
    //   43: aload #4
    //   45: invokevirtual getHeight : ()I
    //   48: if_icmpne -> 108
    //   51: iconst_3
    //   52: istore_0
    //   53: iload_0
    //   54: iconst_1
    //   55: if_icmpne -> 131
    //   58: iconst_1
    //   59: istore_0
    //   60: iload_0
    //   61: istore_1
    //   62: iload_2
    //   63: ifeq -> 73
    //   66: iload_2
    //   67: iconst_2
    //   68: if_icmpne -> 166
    //   71: iload_0
    //   72: istore_1
    //   73: iload_1
    //   74: ifeq -> 192
    //   77: iload_2
    //   78: tableswitch default -> 104, 1 -> 180, 2 -> 184, 3 -> 188
    //   104: getstatic com/chartboost/sdk/Libraries/f.a : Lcom/chartboost/sdk/Libraries/f;
    //   107: areturn
    //   108: aload #4
    //   110: invokevirtual getWidth : ()I
    //   113: aload #4
    //   115: invokevirtual getHeight : ()I
    //   118: if_icmpge -> 126
    //   121: iconst_1
    //   122: istore_0
    //   123: goto -> 53
    //   126: iconst_2
    //   127: istore_0
    //   128: goto -> 53
    //   131: iload_0
    //   132: iconst_2
    //   133: if_icmpne -> 141
    //   136: iconst_0
    //   137: istore_0
    //   138: goto -> 60
    //   141: iload_0
    //   142: iconst_3
    //   143: if_icmpne -> 236
    //   146: iload_1
    //   147: iconst_1
    //   148: if_icmpne -> 156
    //   151: iconst_1
    //   152: istore_0
    //   153: goto -> 60
    //   156: iload_1
    //   157: iconst_2
    //   158: if_icmpne -> 236
    //   161: iconst_0
    //   162: istore_0
    //   163: goto -> 60
    //   166: iload_0
    //   167: ifne -> 175
    //   170: iconst_1
    //   171: istore_1
    //   172: goto -> 73
    //   175: iconst_0
    //   176: istore_1
    //   177: goto -> 73
    //   180: getstatic com/chartboost/sdk/Libraries/f.g : Lcom/chartboost/sdk/Libraries/f;
    //   183: areturn
    //   184: getstatic com/chartboost/sdk/Libraries/f.c : Lcom/chartboost/sdk/Libraries/f;
    //   187: areturn
    //   188: getstatic com/chartboost/sdk/Libraries/f.h : Lcom/chartboost/sdk/Libraries/f;
    //   191: areturn
    //   192: iload_2
    //   193: tableswitch default -> 220, 1 -> 224, 2 -> 228, 3 -> 232
    //   220: getstatic com/chartboost/sdk/Libraries/f.b : Lcom/chartboost/sdk/Libraries/f;
    //   223: areturn
    //   224: getstatic com/chartboost/sdk/Libraries/f.e : Lcom/chartboost/sdk/Libraries/f;
    //   227: areturn
    //   228: getstatic com/chartboost/sdk/Libraries/f.d : Lcom/chartboost/sdk/Libraries/f;
    //   231: areturn
    //   232: getstatic com/chartboost/sdk/Libraries/f.f : Lcom/chartboost/sdk/Libraries/f;
    //   235: areturn
    //   236: iconst_1
    //   237: istore_0
    //   238: goto -> 60
  }
  
  public static String d() {
    if (b.a() == null) {
      String str = "";
      return String.format("%s %s %s", new Object[] { "Chartboost-Android-SDK", str, "5.4.1" });
    } 
    Chartboost.CBFramework cBFramework = b.a();
    return String.format("%s %s %s", new Object[] { "Chartboost-Android-SDK", cBFramework, "5.4.1" });
  }
  
  public static Handler e() {
    return c;
  }
  
  public static boolean f() {
    return (i() || j() || k());
  }
  
  public static String g() {
    SimpleDateFormat simpleDateFormat = new SimpleDateFormat("ZZZZ");
    simpleDateFormat.setTimeZone(TimeZone.getDefault());
    return simpleDateFormat.format(new Date());
  }
  
  public static void h() {
    if (!Environment.getExternalStorageState().equals("mounted"))
      return; 
    File file2 = new File(Environment.getExternalStorageDirectory(), "__chartboost");
    File file1 = new File(file2, "CBImagesDirectory");
    file2 = new File(file2, "CBVideoDirectory");
    a(file1);
    a(file2);
  }
  
  private static boolean i() {
    String str = Build.TAGS;
    return (str != null && str.contains("test-keys"));
  }
  
  private static boolean j() {
    return (new File("/system/app/Superuser.apk")).exists();
  }
  
  private static boolean k() {
    String[] arrayOfString = new String[8];
    arrayOfString[0] = "/sbin/su";
    arrayOfString[1] = "/system/bin/su";
    arrayOfString[2] = "/system/xbin/su";
    arrayOfString[3] = "/data/local/xbin/su";
    arrayOfString[4] = "/data/local/bin/su";
    arrayOfString[5] = "/system/sd/xbin/su";
    arrayOfString[6] = "/system/bin/failsafe/su";
    arrayOfString[7] = "/data/local/su";
    int j = arrayOfString.length;
    for (int i = 0; i < j; i++) {
      if ((new File(arrayOfString[i])).exists())
        return true; 
    } 
    return false;
  }
  
  public static void throwProguardError(Exception paramException) {
    if (paramException instanceof NoSuchMethodException) {
      CBLogging.b("CBUtility", "Chartboost library error! Have you used proguard on your application? Make sure to add the line '-keep class com.chartboost.sdk.** { *; }' to your proguard config file.");
      return;
    } 
    if (paramException != null && paramException.getMessage() != null) {
      CBLogging.b("CBUtility", paramException.getMessage());
      return;
    } 
    CBLogging.b("CBUtility", "Unknown Proguard error");
  }
}


/* Location:              C:\soft\dex2jar-2.0\Smash Cricket-dex2jar.jar!\com\chartboost\sdk\Libraries\CBUtility.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */