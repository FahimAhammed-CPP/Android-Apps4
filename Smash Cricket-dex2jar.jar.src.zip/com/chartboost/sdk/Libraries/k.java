package com.chartboost.sdk.Libraries;

import android.app.Activity;
import android.content.Context;
import com.chartboost.sdk.b;
import java.lang.ref.WeakReference;

public final class k extends WeakReference<Activity> {
  private static k b;
  
  private int a;
  
  private k(Activity paramActivity) {
    super(paramActivity);
    this.a = paramActivity.hashCode();
  }
  
  public static k a(Activity paramActivity) {
    if (b == null || b.a != paramActivity.hashCode())
      b = new k(paramActivity); 
    return b;
  }
  
  public int a() {
    return this.a;
  }
  
  public boolean a(k paramk) {
    return (paramk != null && paramk.a() == this.a);
  }
  
  public Context b() {
    Context context2 = (Context)get();
    Context context1 = context2;
    if (context2 == null)
      context1 = b.x(); 
    return context1;
  }
  
  public boolean b(Activity paramActivity) {
    return (paramActivity != null && paramActivity.hashCode() == this.a);
  }
  
  public int hashCode() {
    return a();
  }
}


/* Location:              C:\soft\dex2jar-2.0\Smash Cricket-dex2jar.jar!\com\chartboost\sdk\Libraries\k.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */