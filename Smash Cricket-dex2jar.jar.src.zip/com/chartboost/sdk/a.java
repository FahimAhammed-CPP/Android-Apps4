package com.chartboost.sdk;

import com.chartboost.sdk.Model.CBError;

public interface a {
  void didCacheInPlay(String paramString);
  
  void didCacheInterstitial(String paramString);
  
  void didCacheMoreApps(String paramString);
  
  void didCacheRewardedVideo(String paramString);
  
  void didClickInterstitial(String paramString);
  
  void didClickMoreApps(String paramString);
  
  void didClickRewardedVideo(String paramString);
  
  void didCloseInterstitial(String paramString);
  
  void didCloseMoreApps(String paramString);
  
  void didCloseRewardedVideo(String paramString);
  
  void didCompleteRewardedVideo(String paramString, int paramInt);
  
  void didDismissInterstitial(String paramString);
  
  void didDismissMoreApps(String paramString);
  
  void didDismissRewardedVideo(String paramString);
  
  void didDisplayInterstitial(String paramString);
  
  void didDisplayMoreApps(String paramString);
  
  void didDisplayRewardedVideo(String paramString);
  
  void didFailToLoadInPlay(String paramString, CBError.CBImpressionError paramCBImpressionError);
  
  void didFailToLoadInterstitial(String paramString, CBError.CBImpressionError paramCBImpressionError);
  
  void didFailToLoadMoreApps(String paramString, CBError.CBImpressionError paramCBImpressionError);
  
  void didFailToLoadRewardedVideo(String paramString, CBError.CBImpressionError paramCBImpressionError);
  
  void didFailToRecordClick(String paramString, CBError.CBClickError paramCBClickError);
  
  void didPauseClickForConfirmation();
  
  boolean shouldDisplayInterstitial(String paramString);
  
  boolean shouldDisplayMoreApps(String paramString);
  
  boolean shouldDisplayRewardedVideo(String paramString);
  
  boolean shouldRequestInterstitial(String paramString);
  
  boolean shouldRequestMoreApps(String paramString);
  
  void willDisplayVideo(String paramString);
}


/* Location:              C:\soft\dex2jar-2.0\Smash Cricket-dex2jar.jar!\com\chartboost\sdk\a.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */