package com.chartboost.sdk;

import android.app.Activity;
import android.content.Context;
import android.text.TextUtils;
import com.chartboost.sdk.Libraries.CBLogging;
import com.chartboost.sdk.Libraries.e;
import com.chartboost.sdk.Model.CBError;
import com.chartboost.sdk.Model.a;
import com.chartboost.sdk.Tracking.a;
import com.chartboost.sdk.impl.az;
import com.chartboost.sdk.impl.bb;
import com.chartboost.sdk.impl.bp;

public final class c {
  private static final String c = c.class.getSimpleName();
  
  private static c d;
  
  public a.a a = new a.a(this) {
      public void a(a param1a) {
        synchronized (this.a) {
          boolean bool = param1a.f;
          if (param1a.b == a.b.a) {
            param1a.b = a.b.b;
            if (bool) {
              param1a.q().a(param1a);
            } else {
              param1a.q().q(param1a);
            } 
          } 
          if (!bool || param1a.b == a.b.c)
            param1a.q().g(param1a); 
          param1a.q().o(param1a);
          return;
        } 
      }
      
      public void a(a param1a, CBError.CBImpressionError param1CBImpressionError) {
        param1a.q().a(param1a, param1CBImpressionError);
      }
      
      public void a(a param1a, String param1String, e.a param1a1) {
        boolean bool;
        param1a.q().b().a(param1a);
        if (param1a.a() && param1a.b == a.b.c) {
          e e = Chartboost.h();
          if (e != null)
            e.b(param1a); 
        } 
        if (!TextUtils.isEmpty(param1String)) {
          bool = true;
        } else {
          bool = false;
        } 
        if (bool) {
          e.a a1 = param1a.w();
          az az = this.a.d();
          az.a("ad_id", a1);
          az.a("to", a1);
          az.a("cgn", a1);
          az.a("creative", a1);
          az.a("cgn", param1a1);
          az.a("creative", param1a1);
          az.a("type", param1a1);
          az.a("more_type", param1a1);
          az.a("location", param1a.d);
          if (param1a.d())
            az.a("retarget_reinstall", Boolean.valueOf(param1a.e())); 
          param1a.n = az;
          this.a.b(param1a, param1String, null);
        } else {
          this.a.b.a(param1a, false, param1String, CBError.CBClickError.URI_INVALID, null);
        } 
        a.b(param1a.q().e(), param1a.d, param1a.p());
      }
      
      public void b(a param1a) {
        if (param1a.b == a.b.c) {
          e e = Chartboost.h();
          if (e != null)
            e.b(param1a); 
        } 
        a.c(param1a.q().e(), param1a.d, param1a.p());
      }
      
      public void c(a param1a) {
        param1a.l = true;
        if (param1a.c == a.c.c && b.f() != null)
          b.f().didCompleteRewardedVideo(param1a.d, param1a.w().f("reward")); 
        c.a(param1a);
      }
      
      public void d(a param1a) {
        param1a.m = true;
      }
    };
  
  public bb.a b = new bb.a(this) {
      public void a(a param1a, boolean param1Boolean, String param1String, CBError.CBClickError param1CBClickError, c.b param1b) {
        if (param1a != null) {
          param1a.o = false;
          if (param1a.a())
            param1a.b = a.b.e; 
        } 
        if (!param1Boolean) {
          if (b.f() != null)
            b.f().didFailToRecordClick(param1String, param1CBClickError); 
          return;
        } 
        if (param1a != null && param1a.n != null) {
          param1a.n.a(true);
          param1a.n.s();
          return;
        } 
        if (param1b != null) {
          param1b.a();
          return;
        } 
      }
    };
  
  private bb e = bb.a(this.b);
  
  public static c a() {
    if (d == null)
      d = new c(); 
    return d;
  }
  
  private static void b(a parama) {
    // Byte code:
    //   0: ldc com/chartboost/sdk/c
    //   2: monitorenter
    //   3: aconst_null
    //   4: astore_3
    //   5: aload_0
    //   6: invokevirtual l : ()Lcom/chartboost/sdk/f$a;
    //   9: ifnull -> 20
    //   12: aload_0
    //   13: invokevirtual x : ()Lcom/chartboost/sdk/f;
    //   16: checkcast com/chartboost/sdk/impl/ai
    //   19: astore_3
    //   20: new com/chartboost/sdk/impl/az
    //   23: dup
    //   24: ldc '/api/video-complete'
    //   26: invokespecial <init> : (Ljava/lang/String;)V
    //   29: astore #4
    //   31: aload #4
    //   33: ldc 'location'
    //   35: aload_0
    //   36: getfield d : Ljava/lang/String;
    //   39: invokevirtual a : (Ljava/lang/String;Ljava/lang/Object;)V
    //   42: aload #4
    //   44: ldc 'reward'
    //   46: aload_0
    //   47: invokevirtual w : ()Lcom/chartboost/sdk/Libraries/e$a;
    //   50: ldc 'reward'
    //   52: invokevirtual e : (Ljava/lang/String;)Ljava/lang/String;
    //   55: invokevirtual a : (Ljava/lang/String;Ljava/lang/Object;)V
    //   58: aload #4
    //   60: ldc 'currency-name'
    //   62: aload_0
    //   63: invokevirtual w : ()Lcom/chartboost/sdk/Libraries/e$a;
    //   66: ldc 'currency-name'
    //   68: invokevirtual e : (Ljava/lang/String;)Ljava/lang/String;
    //   71: invokevirtual a : (Ljava/lang/String;Ljava/lang/Object;)V
    //   74: aload #4
    //   76: ldc 'ad_id'
    //   78: aload_0
    //   79: invokevirtual p : ()Ljava/lang/String;
    //   82: invokevirtual a : (Ljava/lang/String;Ljava/lang/Object;)V
    //   85: aload #4
    //   87: ldc 'force_close'
    //   89: iconst_0
    //   90: invokestatic valueOf : (Z)Ljava/lang/Boolean;
    //   93: invokevirtual a : (Ljava/lang/String;Ljava/lang/Object;)V
    //   96: aload_3
    //   97: ifnull -> 182
    //   100: aload_3
    //   101: invokevirtual v : ()I
    //   104: i2f
    //   105: fstore_1
    //   106: aload_3
    //   107: invokevirtual u : ()I
    //   110: i2f
    //   111: fstore_2
    //   112: aload_0
    //   113: invokevirtual q : ()Lcom/chartboost/sdk/d;
    //   116: invokevirtual getClass : ()Ljava/lang/Class;
    //   119: invokevirtual getSimpleName : ()Ljava/lang/String;
    //   122: ldc 'TotalDuration: %f PlaybackTime: %f'
    //   124: iconst_2
    //   125: anewarray java/lang/Object
    //   128: dup
    //   129: iconst_0
    //   130: fload_2
    //   131: invokestatic valueOf : (F)Ljava/lang/Float;
    //   134: aastore
    //   135: dup
    //   136: iconst_1
    //   137: fload_1
    //   138: invokestatic valueOf : (F)Ljava/lang/Float;
    //   141: aastore
    //   142: invokestatic format : (Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/String;
    //   145: invokestatic a : (Ljava/lang/Object;Ljava/lang/String;)V
    //   148: aload #4
    //   150: ldc 'total_time'
    //   152: fload_2
    //   153: ldc 1000.0
    //   155: fdiv
    //   156: invokestatic valueOf : (F)Ljava/lang/Float;
    //   159: invokevirtual a : (Ljava/lang/String;Ljava/lang/Object;)V
    //   162: fload_1
    //   163: fconst_0
    //   164: fcmpg
    //   165: ifge -> 197
    //   168: aload #4
    //   170: ldc 'playback_time'
    //   172: fload_2
    //   173: ldc 1000.0
    //   175: fdiv
    //   176: invokestatic valueOf : (F)Ljava/lang/Float;
    //   179: invokevirtual a : (Ljava/lang/String;Ljava/lang/Object;)V
    //   182: aload #4
    //   184: iconst_1
    //   185: invokevirtual a : (Z)V
    //   188: aload #4
    //   190: invokevirtual s : ()V
    //   193: ldc com/chartboost/sdk/c
    //   195: monitorexit
    //   196: return
    //   197: aload #4
    //   199: ldc 'playback_time'
    //   201: fload_1
    //   202: ldc 1000.0
    //   204: fdiv
    //   205: invokestatic valueOf : (F)Ljava/lang/Float;
    //   208: invokevirtual a : (Ljava/lang/String;Ljava/lang/Object;)V
    //   211: goto -> 182
    //   214: astore_0
    //   215: ldc com/chartboost/sdk/c
    //   217: monitorexit
    //   218: aload_0
    //   219: athrow
    // Exception table:
    //   from	to	target	type
    //   5	20	214	finally
    //   20	96	214	finally
    //   100	162	214	finally
    //   168	182	214	finally
    //   182	193	214	finally
    //   197	211	214	finally
  }
  
  public final void a(a parama, String paramString, b paramb) {
    this.e.a(parama, paramString, Chartboost.getHostActivity(), paramb);
  }
  
  public final boolean a(Activity paramActivity, a parama) {
    if (parama != null) {
      switch (null.a[parama.b.ordinal()]) {
        default:
          return true;
        case 1:
          if (parama.i)
            Chartboost.a(parama); 
        case 2:
        case 3:
          Chartboost.a(parama);
        case 4:
          break;
      } 
      if (!parama.h()) {
        if (b.a() != null && b.a().doesWrapperUseCustomBackgroundingBehavior() && !(paramActivity instanceof CBImpressionActivity))
          return false; 
        e e = Chartboost.h();
        if (e != null) {
          CBLogging.b(c, "Error onActivityStart " + parama.b.name());
          e.d(parama);
        } 
      } 
    } 
  }
  
  public final void b(a parama, String paramString, b paramb) {
    b.a = new a(this, parama, paramString, paramb) {
        public void a(boolean param1Boolean) {
          Chartboost.a(new Runnable(this, param1Boolean) {
                public void run() {
                  if (this.a) {
                    this.b.d.a(this.b.a, this.b.b, this.b.c);
                    return;
                  } 
                  this.b.d.b.a(this.b.a, false, this.b.b, CBError.CBClickError.AGE_GATE_FAILURE, this.b.c);
                }
              });
        }
      };
    if (!b.t()) {
      a(parama, paramString, paramb);
      return;
    } 
    if (b.f() != null) {
      b.f().didPauseClickForConfirmation();
      if (parama != null) {
        parama.o = false;
        return;
      } 
    } 
  }
  
  protected final boolean b() {
    a a1 = c();
    if (a1 == null)
      return false; 
    a1.p = true;
    this.a.b(a1);
    return true;
  }
  
  protected final a c() {
    bp bp;
    e e = Chartboost.h();
    if (e == null) {
      e = null;
    } else {
      bp = e.d();
    } 
    return (bp == null) ? null : bp.h();
  }
  
  public az d() {
    Context context;
    az az = new az("/api/click");
    Activity activity2 = Chartboost.f();
    Activity activity1 = activity2;
    if (activity2 == null)
      context = Chartboost.getValidContext(); 
    az.b(context);
    return az;
  }
  
  public static interface a {
    void a(boolean param1Boolean);
  }
  
  public static interface b {
    void a();
  }
}


/* Location:              C:\soft\dex2jar-2.0\Smash Cricket-dex2jar.jar!\com\chartboost\sdk\c.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */