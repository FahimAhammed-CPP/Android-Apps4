package com.chartboost.sdk.Model;

public final class CBError {
  private a a;
  
  private String b;
  
  private boolean c;
  
  public CBError(a parama, String paramString) {
    this.a = parama;
    this.b = paramString;
    this.c = true;
  }
  
  public a a() {
    return this.a;
  }
  
  public String b() {
    return this.b;
  }
  
  public CBImpressionError c() {
    switch (null.a[this.a.ordinal()]) {
      default:
        return CBImpressionError.NETWORK_FAILURE;
      case 1:
      case 2:
      case 3:
        return CBImpressionError.INTERNAL;
      case 4:
        return CBImpressionError.INTERNET_UNAVAILABLE;
      case 5:
        break;
    } 
    return CBImpressionError.NO_AD_FOUND;
  }
  
  public enum CBClickError {
    AGE_GATE_FAILURE, INTERNAL, NO_HOST_ACTIVITY, URI_INVALID, URI_UNRECOGNIZED;
    
    static {
      INTERNAL = new CBClickError("INTERNAL", 4);
      a = new CBClickError[] { URI_INVALID, URI_UNRECOGNIZED, AGE_GATE_FAILURE, NO_HOST_ACTIVITY, INTERNAL };
    }
  }
  
  public enum CBImpressionError {
    INTERNAL, ASSETS_DOWNLOAD_FAILURE, ERROR_CREATING_VIEW, ERROR_DISPLAYING_VIEW, ERROR_PLAYING_VIDEO, FIRST_SESSION_INTERSTITIALS_DISABLED, IMPRESSION_ALREADY_VISIBLE, INCOMPATIBLE_API_VERSION, INTERNET_UNAVAILABLE, INVALID_LOCATION, INVALID_RESPONSE, NETWORK_FAILURE, NO_AD_FOUND, NO_HOST_ACTIVITY, SESSION_NOT_STARTED, TOO_MANY_CONNECTIONS, USER_CANCELLATION, VIDEO_ID_MISSING, VIDEO_UNAVAILABLE, WRONG_ORIENTATION;
    
    static {
      IMPRESSION_ALREADY_VISIBLE = new CBImpressionError("IMPRESSION_ALREADY_VISIBLE", 8);
      NO_HOST_ACTIVITY = new CBImpressionError("NO_HOST_ACTIVITY", 9);
      USER_CANCELLATION = new CBImpressionError("USER_CANCELLATION", 10);
      INVALID_LOCATION = new CBImpressionError("INVALID_LOCATION", 11);
      VIDEO_UNAVAILABLE = new CBImpressionError("VIDEO_UNAVAILABLE", 12);
      VIDEO_ID_MISSING = new CBImpressionError("VIDEO_ID_MISSING", 13);
      ERROR_PLAYING_VIDEO = new CBImpressionError("ERROR_PLAYING_VIDEO", 14);
      INVALID_RESPONSE = new CBImpressionError("INVALID_RESPONSE", 15);
      ASSETS_DOWNLOAD_FAILURE = new CBImpressionError("ASSETS_DOWNLOAD_FAILURE", 16);
      ERROR_CREATING_VIEW = new CBImpressionError("ERROR_CREATING_VIEW", 17);
      ERROR_DISPLAYING_VIEW = new CBImpressionError("ERROR_DISPLAYING_VIEW", 18);
      INCOMPATIBLE_API_VERSION = new CBImpressionError("INCOMPATIBLE_API_VERSION", 19);
      a = new CBImpressionError[] { 
          INTERNAL, INTERNET_UNAVAILABLE, TOO_MANY_CONNECTIONS, WRONG_ORIENTATION, FIRST_SESSION_INTERSTITIALS_DISABLED, NETWORK_FAILURE, NO_AD_FOUND, SESSION_NOT_STARTED, IMPRESSION_ALREADY_VISIBLE, NO_HOST_ACTIVITY, 
          USER_CANCELLATION, INVALID_LOCATION, VIDEO_UNAVAILABLE, VIDEO_ID_MISSING, ERROR_PLAYING_VIDEO, INVALID_RESPONSE, ASSETS_DOWNLOAD_FAILURE, ERROR_CREATING_VIEW, ERROR_DISPLAYING_VIEW, INCOMPATIBLE_API_VERSION };
    }
  }
  
  public enum a {
    a, b, c, d, e, f, g;
  }
}


/* Location:              C:\soft\dex2jar-2.0\Smash Cricket-dex2jar.jar!\com\chartboost\sdk\Model\CBError.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */