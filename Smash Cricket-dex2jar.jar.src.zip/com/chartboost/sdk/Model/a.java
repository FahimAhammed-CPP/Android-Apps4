package com.chartboost.sdk.Model;

import android.text.TextUtils;
import android.view.View;
import com.chartboost.sdk.Libraries.CBLogging;
import com.chartboost.sdk.Libraries.e;
import com.chartboost.sdk.f;
import com.chartboost.sdk.impl.ae;
import com.chartboost.sdk.impl.af;
import com.chartboost.sdk.impl.ah;
import com.chartboost.sdk.impl.ai;
import com.chartboost.sdk.impl.av;
import com.chartboost.sdk.impl.aw;
import com.chartboost.sdk.impl.az;
import com.chartboost.sdk.impl.bb;
import com.chartboost.sdk.impl.bp;
import com.chartboost.sdk.impl.br;
import java.util.Date;

public final class a {
  public Date a;
  
  public b b = b.a;
  
  public c c;
  
  public String d;
  
  public d e;
  
  public boolean f;
  
  public boolean g;
  
  public bp h;
  
  public boolean i;
  
  public boolean j = false;
  
  public boolean k = false;
  
  public boolean l = false;
  
  public boolean m = false;
  
  public az n;
  
  public boolean o;
  
  public boolean p = false;
  
  public boolean q = false;
  
  private e.a r;
  
  private boolean s;
  
  private Boolean t = null;
  
  private f u;
  
  private a v;
  
  private Runnable w;
  
  public a(c paramc, boolean paramBoolean1, String paramString, boolean paramBoolean2) {
    this.f = paramBoolean1;
    this.g = false;
    this.o = false;
    this.p = true;
    this.c = paramc;
    this.i = paramBoolean2;
    this.r = e.a.a;
    this.e = d.d;
    this.d = paramString;
    this.s = true;
    if (this.d == null)
      this.d = "Default"; 
  }
  
  public void a(e.a parama) {
    e.a a1 = parama;
    if (parama == null)
      a1 = e.a.a; 
    this.r = a1;
  }
  
  public void a(e.a parama, a parama1) {
    e.a a1 = parama;
    if (parama == null)
      a1 = e.a.a(); 
    this.r = a1;
    this.a = new Date();
    this.b = b.a;
    this.v = parama1;
    if (a1.a("type").equals("native")) {
      switch (null.a[this.c.ordinal()]) {
        default:
          this.u.a(a1);
          return;
        case 1:
          if (a1.a("media-type").equals("video")) {
            this.e = d.b;
            this.u = (f)new ai(this);
            this.s = false;
          } else {
            this.e = d.a;
            this.u = (f)new ah(this);
          } 
        case 2:
          this.e = d.c;
          this.u = (f)new ai(this);
          this.s = false;
        case 3:
          break;
      } 
      this.u = (f)new aw(this);
      this.s = false;
    } 
    this.u = (f)new br(this);
  }
  
  public void a(CBError.CBImpressionError paramCBImpressionError) {
    if (this.v != null)
      this.v.a(this, paramCBImpressionError); 
  }
  
  public void a(Runnable paramRunnable) {
    this.w = paramRunnable;
  }
  
  public boolean a() {
    return this.s;
  }
  
  public boolean a(String paramString, e.a parama) {
    if (this.b != b.c || this.k)
      return false; 
    if (paramString == null)
      paramString = this.r.e("link"); 
    String str2 = this.r.e("deep-link");
    String str1 = paramString;
    if (!TextUtils.isEmpty(str2)) {
      try {
        boolean bool = bb.a(str2);
        if (bool) {
          try {
            this.t = new Boolean(true);
            str1 = str2;
          } catch (Exception exception1) {
            str1 = str2;
          } 
        } else {
          this.t = new Boolean(false);
          exception2 = exception1;
        } 
        if (this.o)
          return false; 
      } catch (Exception exception2) {
        exception2 = exception1;
        if (this.o)
          return false; 
      } 
      this.o = true;
      this.p = false;
      this.v.a(this, (String)exception2, parama);
      return true;
    } 
    if (this.o)
      return false; 
  }
  
  public void b() {
    if (this.v != null) {
      this.p = true;
      this.v.b(this);
    } 
  }
  
  public void c() {
    if (this.v != null)
      this.v.a(this); 
  }
  
  public boolean d() {
    return (this.t != null);
  }
  
  public boolean e() {
    return this.t.booleanValue();
  }
  
  public void f() {
    if (this.v != null)
      this.v.c(this); 
  }
  
  public void g() {
    if (this.v != null)
      this.v.d(this); 
  }
  
  public boolean h() {
    if (this.u != null) {
      this.u.b();
      if (this.u.e() != null)
        return true; 
    } else {
      CBLogging.b("CBImpression", "reinitializing -- no view protocol exists!!");
    } 
    CBLogging.e("CBImpression", "reinitializing -- view not yet created");
    return false;
  }
  
  public void i() {
    j();
    if (!this.g)
      return; 
    if (this.u != null)
      this.u.d(); 
    this.u = null;
    CBLogging.b("CBImpression", "Destroying the view and view data");
  }
  
  public void j() {
    if (this.h != null) {
      this.h.d();
      try {
        if (this.u != null && this.u.e() != null && this.u.e().getParent() != null)
          this.h.removeView((View)this.u.e()); 
      } catch (Exception exception) {
        CBLogging.b("CBImpression", "Exception raised while cleaning up views", exception);
      } 
      this.h = null;
    } 
    if (this.u != null)
      this.u.f(); 
    CBLogging.b("CBImpression", "Destroying the view");
  }
  
  public CBError.CBImpressionError k() {
    return (this.u != null) ? this.u.c() : null;
  }
  
  public f.a l() {
    return (this.u != null) ? this.u.e() : null;
  }
  
  public void m() {
    if (this.u != null && this.u.e() != null)
      this.u.e().setVisibility(8); 
  }
  
  public void n() {
    this.k = true;
  }
  
  public void o() {
    if (this.w != null) {
      this.w.run();
      this.w = null;
    } 
    this.k = false;
    this.j = false;
  }
  
  public String p() {
    return this.r.e("ad_id");
  }
  
  public com.chartboost.sdk.d q() {
    switch (null.a[this.c.ordinal()]) {
      default:
        return (com.chartboost.sdk.d)ae.f();
      case 3:
        return (com.chartboost.sdk.d)av.f();
      case 2:
        break;
    } 
    return (com.chartboost.sdk.d)af.h();
  }
  
  public void r() {
    q().j(this);
  }
  
  public boolean s() {
    return (this.u != null) ? this.u.j() : false;
  }
  
  public void t() {
    this.o = false;
    if (this.u != null)
      this.u.k(); 
  }
  
  public void u() {
    this.o = false;
  }
  
  public void v() {
    if (this.u != null)
      this.u.l(); 
  }
  
  public e.a w() {
    return (this.r == null) ? e.a.a : this.r;
  }
  
  public f x() {
    return this.u;
  }
  
  public boolean y() {
    return this.p;
  }
  
  public static interface a {
    void a(a param1a);
    
    void a(a param1a, CBError.CBImpressionError param1CBImpressionError);
    
    void a(a param1a, String param1String, e.a param1a1);
    
    void b(a param1a);
    
    void c(a param1a);
    
    void d(a param1a);
  }
  
  public enum b {
    a, b, c, d, e, f;
  }
  
  public enum c {
    a, b, c, d;
  }
  
  public enum d {
    a, b, c, d;
  }
}


/* Location:              C:\soft\dex2jar-2.0\Smash Cricket-dex2jar.jar!\com\chartboost\sdk\Model\a.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */