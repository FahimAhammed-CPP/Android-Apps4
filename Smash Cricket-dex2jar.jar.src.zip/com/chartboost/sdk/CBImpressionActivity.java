package com.chartboost.sdk;

import android.app.Activity;
import android.content.Context;
import android.os.Bundle;
import android.view.View;
import android.widget.RelativeLayout;
import com.chartboost.sdk.Libraries.k;
import com.chartboost.sdk.impl.ba;
import com.chartboost.sdk.impl.bg;

public final class CBImpressionActivity extends Activity {
  public void onBackPressed() {
    if (Chartboost.d())
      return; 
    super.onBackPressed();
  }
  
  protected void onCreate(Bundle paramBundle) {
    super.onCreate(paramBundle);
    if (bg.c())
      getWindow().setFlags(16777216, 16777216); 
    requestWindowFeature(1);
    if (getIntent().getBooleanExtra("paramFullscreen", false))
      getWindow().addFlags(1024); 
    getWindow().setWindowAnimations(0);
    setContentView((View)new RelativeLayout((Context)this));
    Chartboost.a(this);
    Chartboost.c(this);
    ba.d();
  }
  
  protected void onDestroy() {
    super.onDestroy();
    Chartboost.b(this);
  }
  
  protected void onPause() {
    super.onPause();
    Chartboost.b(k.a(this));
  }
  
  protected void onResume() {
    super.onResume();
    Chartboost.a(k.a(this));
  }
  
  protected void onStart() {
    super.onStart();
    Chartboost.a();
    Chartboost.a(this);
  }
  
  protected void onStop() {
    super.onStop();
    Chartboost.c(k.a(this));
  }
}


/* Location:              C:\soft\dex2jar-2.0\Smash Cricket-dex2jar.jar!\com\chartboost\sdk\CBImpressionActivity.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */