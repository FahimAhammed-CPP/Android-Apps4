package com.chartboost.sdk.impl;

import android.graphics.drawable.BitmapDrawable;
import android.graphics.drawable.Drawable;
import android.os.Bundle;
import android.widget.ImageView;
import com.chartboost.sdk.Libraries.CBUtility;
import com.chartboost.sdk.Libraries.h;
import com.chartboost.sdk.Libraries.j;
import java.lang.ref.WeakReference;
import java.util.HashMap;
import java.util.Map;

public final class bc {
  private static volatile bc c = null;
  
  private h a = new h("CBImagesDirectory", true);
  
  private Map<String, j.a> b = new HashMap<String, j.a>();
  
  private j.a a(String paramString) {
    if (b(paramString)) {
      if (this.b.containsKey(paramString))
        return this.b.get(paramString); 
      j.a a = new j.a(paramString, this.a.d(String.format("%s%s", new Object[] { paramString, ".png" })), this.a);
      this.b.put(paramString, a);
      return a;
    } 
    if (this.b.containsKey(paramString))
      this.b.remove(paramString); 
    return null;
  }
  
  public static bc a() {
    // Byte code:
    //   0: getstatic com/chartboost/sdk/impl/bc.c : Lcom/chartboost/sdk/impl/bc;
    //   3: ifnonnull -> 28
    //   6: ldc com/chartboost/sdk/impl/bc
    //   8: monitorenter
    //   9: getstatic com/chartboost/sdk/impl/bc.c : Lcom/chartboost/sdk/impl/bc;
    //   12: ifnonnull -> 25
    //   15: new com/chartboost/sdk/impl/bc
    //   18: dup
    //   19: invokespecial <init> : ()V
    //   22: putstatic com/chartboost/sdk/impl/bc.c : Lcom/chartboost/sdk/impl/bc;
    //   25: ldc com/chartboost/sdk/impl/bc
    //   27: monitorexit
    //   28: getstatic com/chartboost/sdk/impl/bc.c : Lcom/chartboost/sdk/impl/bc;
    //   31: areturn
    //   32: astore_0
    //   33: ldc com/chartboost/sdk/impl/bc
    //   35: monitorexit
    //   36: aload_0
    //   37: athrow
    // Exception table:
    //   from	to	target	type
    //   9	25	32	finally
    //   25	28	32	finally
    //   33	36	32	finally
  }
  
  private static a b(ImageView paramImageView) {
    if (paramImageView != null) {
      Drawable drawable = paramImageView.getDrawable();
      if (drawable instanceof c)
        return ((c)drawable).a(); 
    } 
    return null;
  }
  
  private boolean b(String paramString) {
    return this.a.c(String.format("%s%s", new Object[] { paramString, ".png" }));
  }
  
  public void a(String paramString1, String paramString2, b paramb, ImageView paramImageView, Bundle paramBundle) {
    j.a a1 = a(paramString2);
    if (a1 != null) {
      if (paramImageView != null)
        paramImageView.setImageBitmap(a1.a()); 
      if (paramb != null)
        paramb.a(a1, paramBundle); 
      return;
    } 
    if (paramString1 == null && paramb != null)
      paramb.a(null, paramBundle); 
    a a = new a(this, paramImageView, paramb, paramString2, paramBundle, paramString1);
    ax.a().execute(a);
  }
  
  public void b() {
    this.a.b();
    this.b.clear();
  }
  
  private class a implements Runnable {
    private String b;
    
    private final WeakReference<ImageView> c;
    
    private bc.b d;
    
    private String e;
    
    private Bundle f;
    
    public a(bc this$0, ImageView param1ImageView, bc.b param1b, String param1String1, Bundle param1Bundle, String param1String2) {
      this.c = new WeakReference<ImageView>(param1ImageView);
      bc.c c = new bc.c(this);
      if (param1ImageView != null)
        param1ImageView.setImageDrawable((Drawable)c); 
      this.e = param1String1;
      this.d = param1b;
      this.f = param1Bundle;
      this.b = param1String2;
    }
    
    private j.a b() {
      return (j.a)bc.b(this.a).get(this.e);
    }
    
    public void a() {
      j.a a1 = b();
      if (a1 != null && this.c != null && this.c.get() != null && this == bc.a(this.c.get()))
        a1.b(); 
      CBUtility.e().post(new Runnable(this, a1) {
            public void run() {
              if (bc.a.a(this.b) != null) {
                ImageView imageView = bc.a.a(this.b).get();
                bc.a a1 = bc.a(imageView);
                if (this.a != null && this.b == a1)
                  imageView.setImageBitmap(this.a.a()); 
              } 
              if (bc.a.b(this.b) != null)
                bc.a.b(this.b).a(this.a, bc.a.c(this.b)); 
            }
          });
    }
    
    public void run() {
      // Byte code:
      //   0: aconst_null
      //   1: astore #4
      //   3: aconst_null
      //   4: astore_3
      //   5: aload_0
      //   6: getfield a : Lcom/chartboost/sdk/impl/bc;
      //   9: aload_0
      //   10: getfield e : Ljava/lang/String;
      //   13: invokestatic a : (Lcom/chartboost/sdk/impl/bc;Ljava/lang/String;)Z
      //   16: ifeq -> 24
      //   19: aload_0
      //   20: invokevirtual a : ()V
      //   23: return
      //   24: invokestatic b : ()Lorg/apache/http/client/HttpClient;
      //   27: astore_2
      //   28: new org/apache/http/client/methods/HttpGet
      //   31: dup
      //   32: aload_0
      //   33: getfield b : Ljava/lang/String;
      //   36: invokespecial <init> : (Ljava/lang/String;)V
      //   39: astore #5
      //   41: ldc 'CBWebImageCache'
      //   43: new java/lang/StringBuilder
      //   46: dup
      //   47: invokespecial <init> : ()V
      //   50: ldc 'downloading image to cache... '
      //   52: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
      //   55: aload_0
      //   56: getfield b : Ljava/lang/String;
      //   59: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
      //   62: invokevirtual toString : ()Ljava/lang/String;
      //   65: invokestatic a : (Ljava/lang/Object;Ljava/lang/String;)V
      //   68: aload_2
      //   69: aload #5
      //   71: invokeinterface execute : (Lorg/apache/http/client/methods/HttpUriRequest;)Lorg/apache/http/HttpResponse;
      //   76: astore_2
      //   77: aload_2
      //   78: invokeinterface getStatusLine : ()Lorg/apache/http/StatusLine;
      //   83: invokeinterface getStatusCode : ()I
      //   88: istore_1
      //   89: iload_1
      //   90: sipush #200
      //   93: if_icmpeq -> 190
      //   96: ldc 'CBWebImageCache:ImageDownloader'
      //   98: new java/lang/StringBuilder
      //   101: dup
      //   102: invokespecial <init> : ()V
      //   105: ldc 'Error '
      //   107: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
      //   110: iload_1
      //   111: invokevirtual append : (I)Ljava/lang/StringBuilder;
      //   114: ldc ' while retrieving bitmap from '
      //   116: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
      //   119: aload_0
      //   120: getfield b : Ljava/lang/String;
      //   123: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
      //   126: invokevirtual toString : ()Ljava/lang/String;
      //   129: invokestatic d : (Ljava/lang/Object;Ljava/lang/String;)V
      //   132: aload_2
      //   133: invokestatic a : (Lorg/apache/http/HttpResponse;)V
      //   136: aload_0
      //   137: invokevirtual a : ()V
      //   140: return
      //   141: astore #4
      //   143: aload_2
      //   144: astore_3
      //   145: aload #4
      //   147: astore_2
      //   148: aload #5
      //   150: invokevirtual abort : ()V
      //   153: aload_3
      //   154: invokestatic a : (Lorg/apache/http/HttpResponse;)V
      //   157: ldc 'CBWebImageCache'
      //   159: new java/lang/StringBuilder
      //   162: dup
      //   163: invokespecial <init> : ()V
      //   166: ldc 'I/O error while retrieving bitmap from '
      //   168: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
      //   171: aload_0
      //   172: getfield b : Ljava/lang/String;
      //   175: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
      //   178: invokevirtual toString : ()Ljava/lang/String;
      //   181: aload_2
      //   182: invokestatic d : (Ljava/lang/Object;Ljava/lang/String;Ljava/lang/Throwable;)V
      //   185: aload_0
      //   186: invokevirtual a : ()V
      //   189: return
      //   190: aload_2
      //   191: invokeinterface getEntity : ()Lorg/apache/http/HttpEntity;
      //   196: astore #6
      //   198: aload #6
      //   200: ifnull -> 185
      //   203: aload #4
      //   205: astore_3
      //   206: aload #6
      //   208: invokeinterface getContent : ()Ljava/io/InputStream;
      //   213: astore #4
      //   215: aload #4
      //   217: astore_3
      //   218: aload #4
      //   220: invokestatic b : (Ljava/io/InputStream;)[B
      //   223: astore #7
      //   225: aload #4
      //   227: astore_3
      //   228: aload #7
      //   230: invokestatic a : ([B)[B
      //   233: invokestatic b : ([B)Ljava/lang/String;
      //   236: astore #8
      //   238: aload #4
      //   240: astore_3
      //   241: aload #8
      //   243: aload_0
      //   244: getfield e : Ljava/lang/String;
      //   247: invokevirtual equals : (Ljava/lang/Object;)Z
      //   250: ifne -> 292
      //   253: aload #4
      //   255: astore_3
      //   256: aload_0
      //   257: aload #8
      //   259: putfield e : Ljava/lang/String;
      //   262: aload #4
      //   264: astore_3
      //   265: ldc 'CBWebImageCache:ImageDownloader'
      //   267: new java/lang/StringBuilder
      //   270: dup
      //   271: invokespecial <init> : ()V
      //   274: ldc 'Error: checksum did not match while downloading from '
      //   276: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
      //   279: aload_0
      //   280: getfield b : Ljava/lang/String;
      //   283: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
      //   286: invokevirtual toString : ()Ljava/lang/String;
      //   289: invokestatic b : (Ljava/lang/Object;Ljava/lang/String;)V
      //   292: aload #4
      //   294: astore_3
      //   295: aload_0
      //   296: getfield a : Lcom/chartboost/sdk/impl/bc;
      //   299: invokestatic a : (Lcom/chartboost/sdk/impl/bc;)Lcom/chartboost/sdk/Libraries/h;
      //   302: ldc '%s%s'
      //   304: iconst_2
      //   305: anewarray java/lang/Object
      //   308: dup
      //   309: iconst_0
      //   310: aload_0
      //   311: getfield e : Ljava/lang/String;
      //   314: aastore
      //   315: dup
      //   316: iconst_1
      //   317: ldc '.png'
      //   319: aastore
      //   320: invokestatic format : (Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/String;
      //   323: aload #7
      //   325: invokevirtual a : (Ljava/lang/String;[B)V
      //   328: aload #4
      //   330: astore_3
      //   331: aload_0
      //   332: getfield a : Lcom/chartboost/sdk/impl/bc;
      //   335: aload_0
      //   336: getfield e : Ljava/lang/String;
      //   339: invokestatic b : (Lcom/chartboost/sdk/impl/bc;Ljava/lang/String;)Lcom/chartboost/sdk/Libraries/j$a;
      //   342: pop
      //   343: aload #4
      //   345: ifnull -> 403
      //   348: aload #4
      //   350: invokevirtual close : ()V
      //   353: goto -> 185
      //   356: astore #4
      //   358: aload_2
      //   359: astore_3
      //   360: aload #4
      //   362: astore_2
      //   363: aload #5
      //   365: invokevirtual abort : ()V
      //   368: aload_3
      //   369: invokestatic a : (Lorg/apache/http/HttpResponse;)V
      //   372: ldc 'CBWebImageCache'
      //   374: new java/lang/StringBuilder
      //   377: dup
      //   378: invokespecial <init> : ()V
      //   381: ldc 'Incorrect URL: '
      //   383: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
      //   386: aload_0
      //   387: getfield b : Ljava/lang/String;
      //   390: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
      //   393: invokevirtual toString : ()Ljava/lang/String;
      //   396: aload_2
      //   397: invokestatic d : (Ljava/lang/Object;Ljava/lang/String;Ljava/lang/Throwable;)V
      //   400: goto -> 185
      //   403: aload #6
      //   405: invokestatic a : (Lorg/apache/http/HttpEntity;)V
      //   408: goto -> 185
      //   411: astore #4
      //   413: aload_2
      //   414: astore_3
      //   415: aload #4
      //   417: astore_2
      //   418: aload #5
      //   420: invokevirtual abort : ()V
      //   423: aload_3
      //   424: invokestatic a : (Lorg/apache/http/HttpResponse;)V
      //   427: ldc 'CBWebImageCache'
      //   429: new java/lang/StringBuilder
      //   432: dup
      //   433: invokespecial <init> : ()V
      //   436: ldc 'Error while retrieving bitmap from '
      //   438: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
      //   441: aload_0
      //   442: getfield b : Ljava/lang/String;
      //   445: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
      //   448: invokevirtual toString : ()Ljava/lang/String;
      //   451: aload_2
      //   452: invokestatic d : (Ljava/lang/Object;Ljava/lang/String;Ljava/lang/Throwable;)V
      //   455: goto -> 185
      //   458: astore #4
      //   460: aload_3
      //   461: ifnull -> 471
      //   464: aload_3
      //   465: invokevirtual close : ()V
      //   468: aload #4
      //   470: athrow
      //   471: aload #6
      //   473: invokestatic a : (Lorg/apache/http/HttpEntity;)V
      //   476: goto -> 468
      //   479: astore_2
      //   480: aconst_null
      //   481: astore_3
      //   482: goto -> 418
      //   485: astore_2
      //   486: aconst_null
      //   487: astore_3
      //   488: goto -> 363
      //   491: astore_2
      //   492: goto -> 148
      // Exception table:
      //   from	to	target	type
      //   68	77	491	java/io/IOException
      //   68	77	485	java/lang/IllegalStateException
      //   68	77	479	java/lang/Throwable
      //   77	89	141	java/io/IOException
      //   77	89	356	java/lang/IllegalStateException
      //   77	89	411	java/lang/Throwable
      //   96	140	141	java/io/IOException
      //   96	140	356	java/lang/IllegalStateException
      //   96	140	411	java/lang/Throwable
      //   190	198	141	java/io/IOException
      //   190	198	356	java/lang/IllegalStateException
      //   190	198	411	java/lang/Throwable
      //   206	215	458	finally
      //   218	225	458	finally
      //   228	238	458	finally
      //   241	253	458	finally
      //   256	262	458	finally
      //   265	292	458	finally
      //   295	328	458	finally
      //   331	343	458	finally
      //   348	353	141	java/io/IOException
      //   348	353	356	java/lang/IllegalStateException
      //   348	353	411	java/lang/Throwable
      //   403	408	141	java/io/IOException
      //   403	408	356	java/lang/IllegalStateException
      //   403	408	411	java/lang/Throwable
      //   464	468	141	java/io/IOException
      //   464	468	356	java/lang/IllegalStateException
      //   464	468	411	java/lang/Throwable
      //   468	471	141	java/io/IOException
      //   468	471	356	java/lang/IllegalStateException
      //   468	471	411	java/lang/Throwable
      //   471	476	141	java/io/IOException
      //   471	476	356	java/lang/IllegalStateException
      //   471	476	411	java/lang/Throwable
    }
  }
  
  class null implements Runnable {
    null(bc this$0, j.a param1a) {}
    
    public void run() {
      if (bc.a.a(this.b) != null) {
        ImageView imageView = bc.a.a(this.b).get();
        bc.a a1 = bc.a(imageView);
        if (this.a != null && this.b == a1)
          imageView.setImageBitmap(this.a.a()); 
      } 
      if (bc.a.b(this.b) != null)
        bc.a.b(this.b).a(this.a, bc.a.c(this.b)); 
    }
  }
  
  public static interface b {
    void a(j.a param1a, Bundle param1Bundle);
  }
  
  static class c extends BitmapDrawable {
    private final WeakReference<bc.a> a;
    
    public c(bc.a param1a) {
      this.a = new WeakReference<bc.a>(param1a);
    }
    
    public bc.a a() {
      return this.a.get();
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Smash Cricket-dex2jar.jar!\com\chartboost\sdk\impl\bc.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */