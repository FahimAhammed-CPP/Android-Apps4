package com.chartboost.sdk.impl;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.BitmapShader;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.RectF;
import android.graphics.Shader;
import android.graphics.drawable.BitmapDrawable;
import android.graphics.drawable.Drawable;
import com.chartboost.sdk.Libraries.CBUtility;

public final class au extends bj {
  private RectF b;
  
  private Paint c;
  
  private Paint d;
  
  private BitmapShader e;
  
  private float f = 0.0F;
  
  public au(Context paramContext) {
    super(paramContext);
    a(paramContext);
  }
  
  private void a(Context paramContext) {
    float f = (getContext().getResources().getDisplayMetrics()).density;
    this.b = new RectF();
    this.c = new Paint();
    this.c.setStyle(Paint.Style.STROKE);
    this.c.setStrokeWidth(Math.max(1.0F, f * 1.0F));
    this.c.setAntiAlias(true);
  }
  
  public void a(float paramFloat) {
    this.f = paramFloat;
    invalidate();
  }
  
  public void a(int paramInt) {
    this.c.setColor(paramInt);
    invalidate();
  }
  
  protected void onDraw(Canvas paramCanvas) {
    float f = CBUtility.a(1.0F, getContext());
    Drawable drawable = getDrawable();
    if (drawable instanceof BitmapDrawable) {
      Bitmap bitmap = ((BitmapDrawable)drawable).getBitmap();
      if (this.e == null)
        if (bitmap != null) {
          this.e = new BitmapShader(bitmap, Shader.TileMode.CLAMP, Shader.TileMode.CLAMP);
          this.d = new Paint();
          this.d.setAntiAlias(true);
          this.d.setShader((Shader)this.e);
        } else {
          postInvalidate();
          return;
        }  
      float f1 = Math.max(getWidth() / bitmap.getWidth(), getHeight() / bitmap.getHeight());
      paramCanvas.save();
      paramCanvas.scale(f1, f1);
      this.b.set(0.0F, 0.0F, getWidth() / f1, getHeight() / f1);
      this.b.inset(f / f1 * 2.0F, f / f1 * 2.0F);
      paramCanvas.drawRoundRect(this.b, this.b.width() * this.f, this.b.height() * this.f, this.d);
      paramCanvas.restore();
    } else {
      super.onDraw(paramCanvas);
    } 
    this.b.set(0.0F, 0.0F, getWidth(), getHeight());
    this.b.inset(f / 2.0F, f / 2.0F);
    paramCanvas.drawRoundRect(this.b, this.b.width() * this.f, this.b.height() * this.f, this.c);
  }
}


/* Location:              C:\soft\dex2jar-2.0\Smash Cricket-dex2jar.jar!\com\chartboost\sdk\impl\au.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */