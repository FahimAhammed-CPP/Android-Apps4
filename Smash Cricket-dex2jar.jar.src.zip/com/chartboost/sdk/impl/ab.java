package com.chartboost.sdk.impl;

import android.graphics.Bitmap;
import android.graphics.BitmapFactory;

public class ab extends l<Bitmap> {
  private static final Object e = new Object();
  
  private final n.b<Bitmap> a;
  
  private final Bitmap.Config b;
  
  private final int c;
  
  private final int d;
  
  public ab(String paramString, n.b<Bitmap> paramb, int paramInt1, int paramInt2, Bitmap.Config paramConfig, n.a parama) {
    super(0, paramString, parama);
    a(new d(1000, 2, 2.0F));
    this.a = paramb;
    this.b = paramConfig;
    this.c = paramInt1;
    this.d = paramInt2;
  }
  
  static int a(int paramInt1, int paramInt2, int paramInt3, int paramInt4) {
    double d = Math.min(paramInt1 / paramInt3, paramInt2 / paramInt4);
    float f;
    for (f = 1.0F;; f *= 2.0F) {
      if ((f * 2.0F) > d)
        return (int)f; 
    } 
  }
  
  private static int b(int paramInt1, int paramInt2, int paramInt3, int paramInt4) {
    if (paramInt1 == 0 && paramInt2 == 0)
      return paramInt3; 
    if (paramInt1 == 0)
      return (int)(paramInt2 / paramInt4 * paramInt3); 
    int i = paramInt1;
    if (paramInt2 != 0) {
      double d = paramInt4 / paramInt3;
      i = paramInt1;
      if (paramInt1 * d > paramInt2)
        return (int)(paramInt2 / d); 
    } 
    return i;
  }
  
  private n<Bitmap> b(i parami) {
    Bitmap bitmap;
    byte[] arrayOfByte = parami.b;
    BitmapFactory.Options options = new BitmapFactory.Options();
    if (this.c == 0 && this.d == 0) {
      options.inPreferredConfig = this.b;
      bitmap = BitmapFactory.decodeByteArray(arrayOfByte, 0, arrayOfByte.length, options);
    } else {
      options.inJustDecodeBounds = true;
      BitmapFactory.decodeByteArray((byte[])bitmap, 0, bitmap.length, options);
      int j = options.outWidth;
      int k = options.outHeight;
      int m = b(this.c, this.d, j, k);
      int n = b(this.d, this.c, k, j);
      options.inJustDecodeBounds = false;
      options.inSampleSize = a(j, k, m, n);
      bitmap = BitmapFactory.decodeByteArray((byte[])bitmap, 0, bitmap.length, options);
      if (bitmap != null && (bitmap.getWidth() > m || bitmap.getHeight() > n)) {
        Bitmap bitmap1 = Bitmap.createScaledBitmap(bitmap, m, n, true);
        bitmap.recycle();
        bitmap = bitmap1;
      } 
    } 
    return (bitmap == null) ? n.a(new k(parami)) : n.a(bitmap, y.a(parami));
  }
  
  protected n<Bitmap> a(i parami) {
    synchronized (e) {
      return b(parami);
    } 
  }
  
  protected void a(Bitmap paramBitmap) {
    this.a.a(paramBitmap);
  }
  
  public l.a s() {
    return l.a.a;
  }
}


/* Location:              C:\soft\dex2jar-2.0\Smash Cricket-dex2jar.jar!\com\chartboost\sdk\impl\ab.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */