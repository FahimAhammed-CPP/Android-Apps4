package com.chartboost.sdk.impl;

import android.content.Context;
import android.graphics.Point;
import android.text.TextUtils;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.widget.RelativeLayout;
import com.chartboost.sdk.Libraries.CBLogging;
import com.chartboost.sdk.Libraries.CBUtility;
import com.chartboost.sdk.Libraries.e;
import com.chartboost.sdk.Libraries.h;
import com.chartboost.sdk.Libraries.j;
import com.chartboost.sdk.Model.CBError;
import com.chartboost.sdk.f;

public class ai extends ah {
  protected int A = 0;
  
  protected j B;
  
  protected j C;
  
  protected j D;
  
  protected j E;
  
  protected j F;
  
  protected j G;
  
  protected j H;
  
  protected j I;
  
  protected boolean J = false;
  
  protected boolean K = false;
  
  protected boolean L = false;
  
  private boolean M = true;
  
  private boolean N = false;
  
  private boolean O = false;
  
  private boolean P = false;
  
  private boolean Q = false;
  
  protected b p = b.a;
  
  protected int q;
  
  protected String r;
  
  protected String s;
  
  protected int t = 0;
  
  protected int u = 0;
  
  protected boolean v;
  
  protected boolean w;
  
  protected boolean x;
  
  protected boolean y;
  
  protected boolean z = false;
  
  public ai(com.chartboost.sdk.Model.a parama) {
    super(parama);
    this.p = b.a;
    this.B = new j(this);
    this.C = new j(this);
    this.D = new j(this);
    this.E = new j(this);
    this.F = new j(this);
    this.G = new j(this);
    this.H = new j(this);
    this.I = new j(this);
    this.q = 0;
  }
  
  private void w() {
    h.c().b(Integer.toString(this.f.hashCode()));
  }
  
  private void x() {
    float f1 = this.t;
    float f2 = this.u;
    az az = new az("/api/video-complete");
    az.b((az.c)null);
    az.a("location", this.f.d);
    az.a("reward", this.f.w().e("reward"));
    az.a("currency-name", this.f.w().e("currency-name"));
    az.a("ad_id", this.f.p());
    az.a("total_time", Float.valueOf(f2 / 1000.0F));
    az.a("playback_time", Float.valueOf(f1 / 1000.0F));
    az.a("force_close", Boolean.valueOf(true));
    h.c().a(Integer.toString(this.f.hashCode()), az.t());
  }
  
  public void a(boolean paramBoolean) {
    this.P = paramBoolean;
  }
  
  public boolean a(e.a parama) {
    boolean bool;
    boolean bool1 = false;
    if (!super.a(parama))
      return false; 
    if (this.e.b("video-landscape") || this.e.b("replay-landscape"))
      this.j = false; 
    this.B.a("replay-landscape");
    this.C.a("replay-portrait");
    this.F.a("video-click-button");
    this.G.a("post-video-reward-icon");
    this.H.a("post-video-button");
    this.D.a("video-confirmation-button");
    this.E.a("video-confirmation-icon");
    this.I.a("post-video-reward-icon");
    this.v = parama.a("ux").i("video-controls-togglable");
    if (parama.a("fullscreen").b()) {
      bool = false;
    } else {
      bool = parama.a("fullscreen").m();
    } 
    this.K = bool;
    if (parama.a("preroll_popup_fullscreen").b()) {
      bool = bool1;
    } else {
      bool = parama.a("preroll_popup_fullscreen").m();
    } 
    this.L = bool;
    if (this.f.e == com.chartboost.sdk.Model.a.d.c && this.m.a("post-video-toaster").c("title") && this.m.a("post-video-toaster").c("tagline"))
      this.x = true; 
    if (this.f.e == com.chartboost.sdk.Model.a.d.c && this.m.a("confirmation").c("text") && this.m.a("confirmation").c("color"))
      this.w = true; 
    if (this.f.e == com.chartboost.sdk.Model.a.d.c && this.m.c("post-video-reward-toaster"))
      this.y = true; 
    return true;
  }
  
  protected f.a b(Context paramContext) {
    return new a(paramContext);
  }
  
  public void d() {
    super.d();
    this.B.d();
    this.C.d();
    this.F.d();
    this.G.d();
    this.H.d();
    this.D.d();
    this.E.d();
    this.I.d();
    this.B = null;
    this.C = null;
    this.F = null;
    this.G = null;
    this.H = null;
    this.D = null;
    this.E = null;
    this.I = null;
  }
  
  protected void i() {
    if (this.w && (!this.D.e() || !this.E.e()))
      this.w = false; 
    if (this.M) {
      super.i();
      return;
    } 
    a(CBError.CBImpressionError.ERROR_DISPLAYING_VIEW);
  }
  
  public boolean j() {
    if (p().b(true).getVisibility() == 4 || p().b(true).getVisibility() == 8)
      return true; 
    p().e();
    return true;
  }
  
  public void k() {
    super.k();
    if (this.p == b.b && this.N) {
      a.b(p()).b().a(this.t);
      if (!this.O)
        a.b(p()).e(); 
    } 
    this.O = false;
    this.N = false;
  }
  
  public void l() {
    super.l();
    if (this.p == b.b && !this.N) {
      if (!a.b(p()).i())
        this.O = true; 
      this.N = true;
      a.b(p()).g();
      if (this.q < 1 && this.P)
        x(); 
    } 
  }
  
  public boolean m() {
    return (this.f.e == com.chartboost.sdk.Model.a.d.b);
  }
  
  public void n() {
    bl.a a = new bl.a();
    a.a(this.m.a("cancel-popup").e("title")).b(this.m.a("cancel-popup").e("text")).d(this.m.a("cancel-popup").e("confirm")).c(this.m.a("cancel-popup").e("cancel"));
    a.a(p().getContext(), new bl.b(this) {
          public void a(bl param1bl) {
            ai.a a = this.a.p();
            if (a != null)
              ai.a.b(a).e(); 
          }
          
          public void a(bl param1bl, int param1Int) {
            ai.a a = this.a.p();
            if (param1Int == 1) {
              if (a != null)
                ai.a.b(a).e(); 
              return;
            } 
            if (a != null) {
              ai.a.a(a, false);
              ai.a.b(a).h();
            } 
            ai.w(this.a);
          }
        });
  }
  
  public boolean o() {
    return (this.p == b.b);
  }
  
  public a p() {
    return (a)super.e();
  }
  
  protected void q() {
    this.f.r();
  }
  
  protected boolean r() {
    boolean bool = true;
    if (this.p != b.c) {
      boolean bool1 = CBUtility.c().b();
      if (this.p == b.a)
        return (this.L || bool1); 
      if (this.p == b.b)
        return (this.K || bool1); 
      if (!bool1 || this.p == b.c)
        bool = false; 
      return bool;
    } 
    return false;
  }
  
  public boolean s() {
    return this.P;
  }
  
  public void t() {
    this.Q = true;
    bd.b(this.s);
    a(CBError.CBImpressionError.ERROR_PLAYING_VIDEO);
  }
  
  public int u() {
    return this.u;
  }
  
  public int v() {
    return this.t;
  }
  
  public class a extends ah.a {
    private bk h;
    
    private ao i;
    
    private al j;
    
    private View k;
    
    private ag l;
    
    private aj m;
    
    private bk n;
    
    private a(ai this$0, Context param1Context) {
      super(param1Context);
      String str;
      if (ai.this.K) {
        this.k = new View(param1Context);
        this.k.setBackgroundColor(-16777216);
        this.k.setVisibility(8);
        addView(this.k);
      } 
      if ((ai.a(ai.this)).e == com.chartboost.sdk.Model.a.d.c) {
        this.j = new al(param1Context, ai.this);
        this.j.setVisibility(8);
        addView((View)this.j);
      } 
      this.i = new ao(param1Context, ai.this);
      this.i.setVisibility(8);
      addView((View)this.i);
      this.l = new ag(param1Context, ai.this);
      this.l.setVisibility(8);
      addView((View)this.l);
      if ((ai.b(ai.this)).e == com.chartboost.sdk.Model.a.d.c) {
        this.m = new aj(param1Context, ai.this);
        this.m.setVisibility(8);
        addView((View)this.m);
      } 
      this.h = new bk(this, getContext(), ai.this) {
          protected void a(MotionEvent param2MotionEvent) {
            if ((ai.c(this.b.g)).e == com.chartboost.sdk.Model.a.d.c)
              ai.a.a(this.b).a(false); 
            if (this.b.g.p == ai.b.b)
              ai.a.a(this.b, false); 
            com.chartboost.sdk.Tracking.a.c(this.b.g.s, ai.d(this.b.g).p());
            ai.a.b(this.b, true);
          }
        };
      this.h.setVisibility(8);
      addView((View)this.h);
      this.n = new bk(this, getContext(), ai.this) {
          protected void a(MotionEvent param2MotionEvent) {
            this.b.e();
          }
        };
      this.n.setVisibility(8);
      addView((View)this.n);
      if (ai.this.m.a("progress").c("background-color") && ai.this.m.a("progress").c("border-color") && ai.this.m.a("progress").c("progress-color") && ai.this.m.a("progress").c("radius")) {
        ai.this.J = true;
        ak ak = this.i.c();
        ak.a(f.a(ai.this.m.a("progress").e("background-color")));
        ak.b(f.a(ai.this.m.a("progress").e("border-color")));
        ak.c(f.a(ai.this.m.a("progress").e("progress-color")));
        ak.b(ai.this.m.a("progress").a("radius").j());
      } 
      if (ai.this.m.a("video-controls-background").c("color"))
        this.i.a(f.a(ai.this.m.a("video-controls-background").e("color"))); 
      if ((ai.e(ai.this)).e == com.chartboost.sdk.Model.a.d.c && ai.this.x)
        this.l.a(ai.this.m.a("post-video-toaster").e("title"), ai.this.m.a("post-video-toaster").e("tagline")); 
      if ((ai.f(ai.this)).e == com.chartboost.sdk.Model.a.d.c && ai.this.w)
        this.j.a(ai.this.m.a("confirmation").e("text"), f.a(ai.this.m.a("confirmation").e("color"))); 
      if ((ai.g(ai.this)).e == com.chartboost.sdk.Model.a.d.c && ai.this.y) {
        am.a a2;
        if (ai.this.m.a("post-video-reward-toaster").a("position").equals("inside-top")) {
          a2 = am.a.a;
        } else {
          a2 = am.a.b;
        } 
        this.m.a(a2);
        this.m.a(ai.this.m.a("post-video-reward-toaster").e("text"));
        if (ai.this.G.e())
          this.m.a(ai.this.I); 
      } 
      if (ai.h(ai.this).a("video-click-button").b())
        this.i.d(); 
      this.i.c(ai.this.m.i("video-progress-timer-enabled"));
      if (ai.this.L || ai.this.K)
        this.e.setVisibility(4); 
      boolean bool = ai.this.a().b();
      e.a a1 = ai.i(ai.this);
      if (bool) {
        str = "video-portrait";
      } else {
        str = "video-landscape";
      } 
      ai.this.s = a1.a(str).e("id");
      if (TextUtils.isEmpty(ai.this.s)) {
        ai.a(ai.this, CBError.CBImpressionError.VIDEO_ID_MISSING);
        return;
      } 
      if (ai.this.r == null)
        ai.this.r = bd.a(ai.this.s); 
      if (ai.this.r == null) {
        ai.b(ai.this, CBError.CBImpressionError.VIDEO_UNAVAILABLE);
        return;
      } 
      this.i.a(ai.this.r);
    }
    
    private void a(ai.b param1b, boolean param1Boolean) {
      boolean bool;
      bk bk1;
      ai ai1;
      boolean bool1 = true;
      this.g.p = param1b;
      switch (ai.null.a[param1b.ordinal()]) {
        default:
          bool = g();
          bk1 = b(true);
          bk1.setEnabled(bool);
          this.g.a(bool, (View)bk1, param1Boolean);
          bk1 = b(false);
          bk1.setEnabled(false);
          this.g.a(false, (View)bk1, param1Boolean);
          if (this.g.L || this.g.K) {
            ai ai2 = this.g;
            if (!this.g.r()) {
              bool = true;
            } else {
              bool = false;
            } 
            ai2.a(bool, (View)this.e, param1Boolean);
          } 
          ai1 = this.g;
          if (!this.g.r()) {
            bool = true;
          } else {
            bool = false;
          } 
          ai1.a(bool, (View)this.b, param1Boolean);
          if (param1b != ai.b.a) {
            param1Boolean = bool1;
          } else {
            break;
          } 
          a(param1Boolean);
          return;
        case 1:
          ai1 = this.g;
          if (!this.g.r()) {
            bool = true;
          } else {
            bool = false;
          } 
          ai1.a(bool, (View)this.d, param1Boolean);
          if ((ai.p(this.g)).e == com.chartboost.sdk.Model.a.d.c)
            this.g.a(true, (View)this.j, param1Boolean); 
          if (this.g.K)
            this.g.a(false, this.k, param1Boolean); 
          this.g.a(false, (View)this.i, param1Boolean);
          this.g.a(false, (View)this.h, param1Boolean);
          this.g.a(false, (View)this.l, param1Boolean);
          this.d.setEnabled(false);
          this.h.setEnabled(false);
          this.i.setEnabled(false);
        case 2:
          this.g.a(false, (View)this.d, param1Boolean);
          if ((ai.q(this.g)).e == com.chartboost.sdk.Model.a.d.c)
            this.g.a(false, (View)this.j, param1Boolean); 
          if (this.g.K)
            this.g.a(true, this.k, param1Boolean); 
          this.g.a(true, (View)this.i, param1Boolean);
          this.g.a(false, (View)this.h, param1Boolean);
          this.g.a(false, (View)this.l, param1Boolean);
          this.d.setEnabled(true);
          this.h.setEnabled(false);
          this.i.setEnabled(true);
        case 3:
          this.g.a(true, (View)this.d, param1Boolean);
          if ((ai.r(this.g)).e == com.chartboost.sdk.Model.a.d.c)
            this.g.a(false, (View)this.j, param1Boolean); 
          if (this.g.K)
            this.g.a(false, this.k, param1Boolean); 
          this.g.a(false, (View)this.i, param1Boolean);
          this.g.a(true, (View)this.h, param1Boolean);
          if (this.g.H.e() && this.g.G.e() && this.g.x) {
            bool = true;
          } else {
            bool = false;
          } 
          this.g.a(bool, (View)this.l, param1Boolean);
          this.h.setEnabled(true);
          this.d.setEnabled(true);
          this.i.setEnabled(false);
          if (this.g.z)
            e(false); 
      } 
      param1Boolean = false;
      a(param1Boolean);
    }
    
    private void c(boolean param1Boolean) {
      if (this.g.p != ai.b.b) {
        if (this.g.w) {
          com.chartboost.sdk.Tracking.a.b("integrated", this.g.n);
          a(ai.b.a, param1Boolean);
          return;
        } 
        a(ai.b.b, param1Boolean);
        if (this.g.q < 1 && this.g.m.a("timer").c("delay")) {
          String str;
          if (this.g.v) {
            str = "visible";
          } else {
            str = "hidden";
          } 
          CBLogging.c("InterstitialVideoViewProtocol", String.format("controls starting %s, setting timer", new Object[] { str }));
          this.i.a(this.g.v);
          long l = Math.round(1000.0D * this.g.m.a("timer").g("delay"));
          ai.a(this.g, (View)this.i, new Runnable(this) {
                public void run() {
                  boolean bool;
                  String str;
                  if (this.a.g.v) {
                    str = "hidden";
                  } else {
                    str = "shown";
                  } 
                  CBLogging.c("InterstitialVideoViewProtocol", String.format("controls %s automatically from timer", new Object[] { str }));
                  ao ao = ai.a.b(this.a);
                  if (!this.a.g.v) {
                    bool = true;
                  } else {
                    bool = false;
                  } 
                  ao.a(bool, true);
                  this.a.g.h.remove(Integer.valueOf(ai.a.b(this.a).hashCode()));
                }
              }l);
        } else {
          ao ao1 = this.i;
          if (!this.g.v) {
            param1Boolean = true;
          } else {
            param1Boolean = false;
          } 
          ao1.a(param1Boolean);
        } 
        com.chartboost.sdk.Tracking.a.a(this.g.s, this.g.n, this.g.q);
        this.i.e();
        if (this.g.q <= 1) {
          ai.o(this.g).g();
          return;
        } 
      } 
    }
    
    private void d(boolean param1Boolean) {
      this.i.f();
      com.chartboost.sdk.Tracking.a.d(this.g.s, this.g.n);
      if (this.g.p == ai.b.b && param1Boolean) {
        if (this.g.q < 1 && this.g.m.c("post-video-reward-toaster") && this.g.y && this.g.G.e() && this.g.H.e())
          e(true); 
        a(ai.b.c, true);
        if (CBUtility.c().b()) {
          requestLayout();
          return;
        } 
      } 
    }
    
    private void e(boolean param1Boolean) {
      if (param1Boolean) {
        this.m.a(true);
      } else {
        this.m.setVisibility(0);
      } 
      f.a.postDelayed(new Runnable(this) {
            public void run() {
              ai.a.a(this.a).a(false);
            }
          },  2500L);
    }
    
    protected void a(float param1Float1, float param1Float2) {
      if ((this.g.v && this.g.p == ai.b.b) || this.g.p == ai.b.a)
        return; 
      h();
      com.chartboost.sdk.Tracking.a.a("insterstitial", this.g.s, ai.v(this.g).p(), (int)param1Float1, (int)param1Float2);
    }
    
    protected void a(int param1Int1, int param1Int2) {
      j j1;
      String str;
      super.a(param1Int1, param1Int2);
      a(this.g.p, false);
      boolean bool = this.g.a().b();
      RelativeLayout.LayoutParams layoutParams1 = new RelativeLayout.LayoutParams(-1, -1);
      RelativeLayout.LayoutParams layoutParams2 = new RelativeLayout.LayoutParams(-2, -2);
      RelativeLayout.LayoutParams layoutParams3 = new RelativeLayout.LayoutParams(-1, -1);
      RelativeLayout.LayoutParams layoutParams4 = new RelativeLayout.LayoutParams(-1, -1);
      RelativeLayout.LayoutParams layoutParams5 = new RelativeLayout.LayoutParams(-1, -1);
      RelativeLayout.LayoutParams layoutParams6 = (RelativeLayout.LayoutParams)this.b.getLayoutParams();
      ai ai1 = this.g;
      if (bool) {
        j1 = this.g.C;
      } else {
        j1 = this.g.B;
      } 
      ai1.a((ViewGroup.LayoutParams)layoutParams2, j1, 1.0F);
      ai1 = this.g;
      if (bool) {
        str = "replay-portrait";
      } else {
        str = "replay-landscape";
      } 
      Point point = ai1.b(str);
      int i = Math.round(layoutParams6.leftMargin + layoutParams6.width / 2.0F + point.x - layoutParams2.width / 2.0F);
      float f = layoutParams6.topMargin;
      int j = Math.round(layoutParams6.height / 2.0F + f + point.y - layoutParams2.height / 2.0F);
      layoutParams2.leftMargin = Math.min(Math.max(0, i), param1Int1 - layoutParams2.width);
      layoutParams2.topMargin = Math.min(Math.max(0, j), param1Int2 - layoutParams2.height);
      this.h.bringToFront();
      if (bool) {
        this.h.a(this.g.C);
      } else {
        this.h.a(this.g.B);
      } 
      layoutParams6 = (RelativeLayout.LayoutParams)this.d.getLayoutParams();
      if (!this.g.r()) {
        layoutParams3.width = layoutParams6.width;
        layoutParams3.height = layoutParams6.height;
        layoutParams3.leftMargin = layoutParams6.leftMargin;
        layoutParams3.topMargin = layoutParams6.topMargin;
        layoutParams4.width = layoutParams6.width;
        layoutParams4.height = layoutParams6.height;
        layoutParams4.leftMargin = layoutParams6.leftMargin;
        layoutParams4.topMargin = layoutParams6.topMargin;
      } else {
        j j2;
        RelativeLayout.LayoutParams layoutParams = new RelativeLayout.LayoutParams(-2, -2);
        if (bool) {
          j2 = this.g.k;
        } else {
          j2 = this.g.l;
        } 
        this.g.a((ViewGroup.LayoutParams)layoutParams, j2, 1.0F);
        layoutParams.leftMargin = 0;
        layoutParams.topMargin = 0;
        layoutParams.addRule(11);
        this.n.setLayoutParams((ViewGroup.LayoutParams)layoutParams);
        this.n.a(j2);
      } 
      layoutParams5.width = layoutParams6.width;
      layoutParams5.height = 72;
      layoutParams5.leftMargin = layoutParams6.leftMargin;
      param1Int1 = layoutParams6.topMargin;
      layoutParams5.topMargin = layoutParams6.height + param1Int1 - 72;
      if (this.g.K)
        this.k.setLayoutParams((ViewGroup.LayoutParams)layoutParams1); 
      if ((ai.m(this.g)).e == com.chartboost.sdk.Model.a.d.c)
        this.j.setLayoutParams((ViewGroup.LayoutParams)layoutParams3); 
      this.i.setLayoutParams((ViewGroup.LayoutParams)layoutParams4);
      this.l.setLayoutParams((ViewGroup.LayoutParams)layoutParams5);
      this.h.setLayoutParams((ViewGroup.LayoutParams)layoutParams2);
      if ((ai.n(this.g)).e == com.chartboost.sdk.Model.a.d.c)
        this.j.a(); 
      this.i.a();
    }
    
    public bk b(boolean param1Boolean) {
      return ((this.g.r() && param1Boolean) || (!this.g.r() && !param1Boolean)) ? this.n : this.c;
    }
    
    public void b() {
      this.g.l();
      super.b();
    }
    
    protected void d() {
      super.d();
      if (this.g.p == ai.b.a && (!this.g.w || this.g.m())) {
        c(false);
        return;
      } 
      a(this.g.p, false);
    }
    
    protected void e() {
      if (this.g.p == ai.b.b && this.g.m.a("cancel-popup").c("title") && this.g.m.a("cancel-popup").c("text") && this.g.m.a("cancel-popup").c("cancel") && this.g.m.a("cancel-popup").c("confirm")) {
        this.i.g();
        if (this.g.q < 1) {
          this.g.n();
          return;
        } 
      } 
      if (this.g.p == ai.b.b) {
        d(false);
        this.i.h();
        if (this.g.q < 1) {
          ai ai1 = this.g;
          ai1.q++;
          ai.k(this.g);
          ai.t(this.g).f();
        } 
      } 
      f.a.post(new Runnable(this) {
            public void run() {
              ai.u(this.a.g);
            }
          });
      com.chartboost.sdk.Tracking.a.b(this.g.s, this.g.n, this.g.A);
    }
    
    public void f() {
      d(true);
      this.i.h();
      ai ai1 = this.g;
      ai1.q++;
      if (this.g.q <= 1 && !ai.j(this.g)) {
        ai.k(this.g);
        if (this.g.t >= 1)
          ai.l(this.g).f(); 
      } 
    }
    
    protected boolean g() {
      if (this.g.p == ai.b.b && this.g.q < 1) {
        byte b;
        String str;
        e.a a1 = ai.s(this.g);
        StringBuilder stringBuilder = (new StringBuilder()).append("close-");
        if (this.g.a().b()) {
          str = "portrait";
        } else {
          str = "landscape";
        } 
        float f = a1.a(stringBuilder.append(str).toString()).a("delay").a(-1.0F);
        if (f >= 0.0F) {
          b = Math.round(f * 1000.0F);
        } else {
          b = -1;
        } 
        this.g.A = b;
        if (b >= 0) {
          if (b > this.i.b().d())
            return false; 
        } else {
          return false;
        } 
      } 
      return true;
    }
    
    protected void h() {
      if (this.g.p == ai.b.b)
        d(false); 
      this.g.a((String)null, (e.a)null);
    }
    
    protected void i() {
      com.chartboost.sdk.Tracking.a.d("integrated", this.g.n, true);
      this.g.w = false;
      c(true);
    }
  }
  
  class null extends bk {
    null(ai this$0, Context param1Context, ai param1ai) {
      super(param1Context);
    }
    
    protected void a(MotionEvent param1MotionEvent) {
      if ((ai.c(this.b.g)).e == com.chartboost.sdk.Model.a.d.c)
        ai.a.a(this.b).a(false); 
      if (this.b.g.p == ai.b.b)
        ai.a.a(this.b, false); 
      com.chartboost.sdk.Tracking.a.c(this.b.g.s, ai.d(this.b.g).p());
      ai.a.b(this.b, true);
    }
  }
  
  class null extends bk {
    null(ai this$0, Context param1Context, ai param1ai) {
      super(param1Context);
    }
    
    protected void a(MotionEvent param1MotionEvent) {
      this.b.e();
    }
  }
  
  class null implements Runnable {
    null(ai this$0) {}
    
    public void run() {
      boolean bool;
      String str;
      if (this.a.g.v) {
        str = "hidden";
      } else {
        str = "shown";
      } 
      CBLogging.c("InterstitialVideoViewProtocol", String.format("controls %s automatically from timer", new Object[] { str }));
      ao ao = ai.a.b(this.a);
      if (!this.a.g.v) {
        bool = true;
      } else {
        bool = false;
      } 
      ao.a(bool, true);
      this.a.g.h.remove(Integer.valueOf(ai.a.b(this.a).hashCode()));
    }
  }
  
  class null implements Runnable {
    null(ai this$0) {}
    
    public void run() {
      ai.a.a(this.a).a(false);
    }
  }
  
  class null implements Runnable {
    null(ai this$0) {}
    
    public void run() {
      ai.u(this.a.g);
    }
  }
  
  protected enum b {
    a, b, c;
  }
}


/* Location:              C:\soft\dex2jar-2.0\Smash Cricket-dex2jar.jar!\com\chartboost\sdk\impl\ai.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */