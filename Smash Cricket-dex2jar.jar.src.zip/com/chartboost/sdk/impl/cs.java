package com.chartboost.sdk.impl;

import java.io.Serializable;
import java.util.Date;

public class cs implements Serializable, Comparable<cs> {
  static final boolean a = Boolean.getBoolean("DEBUG.DBTIMESTAMP");
  
  final int b = 0;
  
  final Date c = null;
  
  public int a() {
    return (this.c == null) ? 0 : (int)(this.c.getTime() / 1000L);
  }
  
  public int a(cs paramcs) {
    return (a() != paramcs.a()) ? (a() - paramcs.a()) : (b() - paramcs.b());
  }
  
  public int b() {
    return this.b;
  }
  
  public boolean equals(Object paramObject) {
    if (paramObject != this) {
      if (paramObject instanceof cs) {
        paramObject = paramObject;
        return !(a() != paramObject.a() || b() != paramObject.b());
      } 
      return false;
    } 
    return true;
  }
  
  public int hashCode() {
    return (this.b + 31) * 31 + a();
  }
  
  public String toString() {
    return "TS time:" + this.c + " inc:" + this.b;
  }
}


/* Location:              C:\soft\dex2jar-2.0\Smash Cricket-dex2jar.jar!\com\chartboost\sdk\impl\cs.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */