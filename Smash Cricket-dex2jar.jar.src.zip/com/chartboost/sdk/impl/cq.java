package com.chartboost.sdk.impl;

import java.io.IOException;
import java.io.OutputStream;
import java.util.ArrayList;
import java.util.List;

public class cq extends cp {
  private static dh<byte[]> g = new dh<byte[]>(640) {
      protected byte[] a() {
        return new byte[16384];
      }
    };
  
  final byte[] a = new byte[16384];
  
  final char[] b = new char[16384];
  
  final List<byte[]> c = (List)new ArrayList<byte>();
  
  final cr d = new cr();
  
  private final a e = new a();
  
  private final a f = new a();
  
  public cq() {
    d();
  }
  
  public int a() {
    return this.e.b();
  }
  
  public int a(OutputStream paramOutputStream) throws IOException {
    if (paramOutputStream == null)
      throw new NullPointerException("out is null"); 
    int i = -1;
    int j = 0;
    while (i < this.c.size()) {
      byte[] arrayOfByte = b(i);
      int k = this.f.c(i);
      paramOutputStream.write(arrayOfByte, 0, k);
      j += k;
      i++;
    } 
    return j;
  }
  
  public void a(int paramInt) {
    this.e.a(paramInt);
  }
  
  public int b() {
    return this.f.b();
  }
  
  byte[] b(int paramInt) {
    return (paramInt < 0) ? this.a : this.c.get(paramInt);
  }
  
  public void d() {
    this.e.a();
    this.f.a();
    for (int i = 0; i < this.c.size(); i++)
      g.b(this.c.get(i)); 
    this.c.clear();
  }
  
  void e() {
    if (this.e.b() < this.f.b()) {
      if (this.e.b == 16384)
        this.e.d(); 
      return;
    } 
    this.f.a(this.e);
    if (this.f.b >= 16384) {
      this.c.add(g.c());
      this.f.d();
      this.e.a(this.f);
      return;
    } 
  }
  
  byte[] f() {
    return b(this.e.a);
  }
  
  public void write(int paramInt) {
    f()[this.e.c()] = (byte)(paramInt & 0xFF);
    e();
  }
  
  public void write(byte[] paramArrayOfbyte) {
    write(paramArrayOfbyte, 0, paramArrayOfbyte.length);
  }
  
  public void write(byte[] paramArrayOfbyte, int paramInt1, int paramInt2) {
    while (paramInt2 > 0) {
      byte[] arrayOfByte = f();
      int i = Math.min(arrayOfByte.length - this.e.b, paramInt2);
      System.arraycopy(paramArrayOfbyte, paramInt1, arrayOfByte, this.e.b, i);
      this.e.b(i);
      paramInt2 -= i;
      paramInt1 += i;
      e();
    } 
  }
  
  static class a {
    int a;
    
    int b;
    
    a() {
      a();
    }
    
    void a() {
      this.a = -1;
      this.b = 0;
    }
    
    void a(int param1Int) {
      this.a = param1Int / 16384 - 1;
      this.b = param1Int % 16384;
    }
    
    void a(a param1a) {
      this.a = param1a.a;
      this.b = param1a.b;
    }
    
    int b() {
      return (this.a + 1) * 16384 + this.b;
    }
    
    void b(int param1Int) {
      this.b += param1Int;
      if (this.b > 16384)
        throw new IllegalArgumentException("something is wrong"); 
    }
    
    int c() {
      int i = this.b;
      this.b = i + 1;
      return i;
    }
    
    int c(int param1Int) {
      return (param1Int < this.a) ? 16384 : this.b;
    }
    
    void d() {
      if (this.b != 16384)
        throw new IllegalArgumentException("broken"); 
      this.a++;
      this.b = 0;
    }
    
    public String toString() {
      return this.a + "," + this.b;
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Smash Cricket-dex2jar.jar!\com\chartboost\sdk\impl\cq.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */