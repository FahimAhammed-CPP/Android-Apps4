package com.chartboost.sdk.impl;

import java.io.Closeable;
import java.io.File;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.io.PrintWriter;

public class cd {
  public static final char a = File.separatorChar;
  
  public static final String b;
  
  static {
    cf cf = new cf(4);
    PrintWriter printWriter = new PrintWriter(cf);
    printWriter.println();
    b = cf.toString();
    printWriter.close();
  }
  
  public static int a(InputStream paramInputStream, OutputStream paramOutputStream) throws IOException {
    long l = b(paramInputStream, paramOutputStream);
    return (l > 2147483647L) ? -1 : (int)l;
  }
  
  public static long a(InputStream paramInputStream, OutputStream paramOutputStream, byte[] paramArrayOfbyte) throws IOException {
    long l = 0L;
    while (true) {
      int i = paramInputStream.read(paramArrayOfbyte);
      if (-1 != i) {
        paramOutputStream.write(paramArrayOfbyte, 0, i);
        l += i;
        continue;
      } 
      return l;
    } 
  }
  
  public static void a(Closeable paramCloseable) {
    if (paramCloseable != null)
      try {
        paramCloseable.close();
        return;
      } catch (IOException iOException) {
        return;
      }  
  }
  
  public static void a(InputStream paramInputStream) {
    a(paramInputStream);
  }
  
  public static void a(OutputStream paramOutputStream) {
    a(paramOutputStream);
  }
  
  public static byte[] a(InputStream paramInputStream, int paramInt) throws IOException {
    int i = 0;
    if (paramInt < 0)
      throw new IllegalArgumentException("Size must be equal or greater than zero: " + paramInt); 
    if (paramInt == 0)
      return new byte[0]; 
    byte[] arrayOfByte2 = new byte[paramInt];
    while (i < paramInt) {
      int j = paramInputStream.read(arrayOfByte2, i, paramInt - i);
      if (j != -1)
        i += j; 
    } 
    byte[] arrayOfByte1 = arrayOfByte2;
    if (i != paramInt)
      throw new IOException("Unexpected readed size. current: " + i + ", excepted: " + paramInt); 
    return arrayOfByte1;
  }
  
  public static byte[] a(InputStream paramInputStream, long paramLong) throws IOException {
    if (paramLong > 2147483647L)
      throw new IllegalArgumentException("Size cannot be greater than Integer max value: " + paramLong); 
    return a(paramInputStream, (int)paramLong);
  }
  
  public static long b(InputStream paramInputStream, OutputStream paramOutputStream) throws IOException {
    return a(paramInputStream, paramOutputStream, new byte[4096]);
  }
  
  public static byte[] b(InputStream paramInputStream) throws IOException {
    ce ce = new ce();
    a(paramInputStream, ce);
    return ce.a();
  }
}


/* Location:              C:\soft\dex2jar-2.0\Smash Cricket-dex2jar.jar!\com\chartboost\sdk\impl\cd.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */