package com.chartboost.sdk.impl;

import android.content.Context;
import android.graphics.Typeface;
import android.os.Bundle;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.ImageView;
import android.widget.ListAdapter;
import android.widget.ListView;
import android.widget.RelativeLayout;
import android.widget.TextView;
import com.chartboost.sdk.Libraries.CBUtility;
import com.chartboost.sdk.Libraries.e;
import com.chartboost.sdk.Libraries.f;
import com.chartboost.sdk.Libraries.j;
import com.chartboost.sdk.Model.CBError;
import com.chartboost.sdk.f;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Set;

public class aw extends f {
  protected j k = new j(this);
  
  protected j l = new j(this);
  
  private List<e.a> m = new ArrayList<e.a>();
  
  private j n = new j(this);
  
  private j o = new j(this);
  
  private j p = new j(this);
  
  private j q = new j(this);
  
  private j r = new j(this);
  
  private j s = new j(this);
  
  private j t = new j(this);
  
  private Set<j> u;
  
  private int v;
  
  private e.a w;
  
  private int x;
  
  private int y;
  
  private String z;
  
  public aw(com.chartboost.sdk.Model.a parama) {
    super(parama);
  }
  
  private void a(e.a parama, String paramString) {
    if (parama.b(paramString))
      return; 
    j j1 = new j(this);
    this.u.add(j1);
    j1.a(parama, paramString, new Bundle());
  }
  
  public boolean a(e.a parama) {
    String str;
    int i = 0;
    if (!super.a(parama))
      return false; 
    parama = parama.a("cells");
    if (parama.b()) {
      a(CBError.CBImpressionError.INVALID_RESPONSE);
      return false;
    } 
    this.u = new HashSet<j>();
    while (i < parama.o()) {
      e.a a1 = parama.c(i);
      this.m.add(a1);
      e.a a2 = a1.a("type");
      if (a2.equals("regular")) {
        a1 = a1.a("assets");
        if (a1.c())
          a(a1, "icon"); 
      } else if (a2.equals("featured")) {
        a1 = a1.a("assets");
        if (a1.c()) {
          a(a1, "portrait");
          a(a1, "landscape");
        } 
      } else if (a2.equals("webview")) {
      
      } 
      i++;
    } 
    this.n.a("close");
    this.p.a("close-landscape");
    this.o.a("close-portrait");
    this.t.a("header-center");
    this.q.a("header-portrait");
    this.r.a("header-landscape");
    this.s.a("header-tile");
    this.l.a("play-button");
    this.k.a("install-button");
    this.w = this.e.a("header-height");
    if (this.w.c()) {
      this.v = this.w.k();
    } else {
      if (a(com.chartboost.sdk.b.x())) {
        i = 80;
      } else {
        i = 40;
      } 
      this.v = i;
    } 
    if (this.e.c("background-color")) {
      i = a(this.e.e("background-color"));
    } else {
      i = -14571545;
    } 
    this.x = i;
    if (this.e.c("header-text")) {
      str = this.e.e("header-text");
    } else {
      str = "More Free Games";
    } 
    this.z = str;
    if (this.e.c("text-color")) {
      i = a(this.e.e("text-color"));
      this.y = i;
      return true;
    } 
    i = -1;
    this.y = i;
    return true;
  }
  
  protected f.a b(Context paramContext) {
    return new a(paramContext);
  }
  
  public void d() {
    super.d();
    this.m = null;
    Iterator<j> iterator = this.u.iterator();
    while (iterator.hasNext())
      ((j)iterator.next()).d(); 
    this.u.clear();
    this.n.d();
    this.p.d();
    this.o.d();
    this.t.d();
    this.s.d();
    this.q.d();
    this.r.d();
    this.l.d();
    this.k.d();
  }
  
  public class a extends f.a {
    private bk c;
    
    private bj d;
    
    private TextView e;
    
    private RelativeLayout f;
    
    private ListView g;
    
    private a h;
    
    private a(aw this$0, Context param1Context) {
      super(aw.this, param1Context);
      float f;
      setBackgroundColor(-1);
      this.d = new bj(param1Context);
      this.c = new bk(this, param1Context, aw.this) {
          protected void a(MotionEvent param2MotionEvent) {
            aw.a(this.b.b);
          }
        };
      this.e = new TextView(param1Context);
      this.e.setBackgroundColor(aw.b(aw.this));
      this.e.setText(aw.c(aw.this));
      this.e.setTextColor(aw.d(aw.this));
      TextView textView = this.e;
      if (c()) {
        f = 30.0F;
      } else {
        f = 18.0F;
      } 
      textView.setTextSize(2, f);
      this.e.setGravity(17);
      this.g = new ListView(param1Context);
      this.g.setBackgroundColor(-1);
      this.g.setDividerHeight(0);
      a((View)this.g);
      addView((View)this.g);
      this.d.setFocusable(false);
      this.c.setFocusable(false);
      this.c.setClickable(true);
      this.d.setScaleType(ImageView.ScaleType.CENTER_CROP);
      this.c.a(ImageView.ScaleType.FIT_CENTER);
      this.f = new RelativeLayout(param1Context);
      this.f.addView((View)this.d, (ViewGroup.LayoutParams)new RelativeLayout.LayoutParams(-1, -1));
      this.f.addView((View)this.e, (ViewGroup.LayoutParams)new RelativeLayout.LayoutParams(-1, -1));
      addView((View)this.f, (ViewGroup.LayoutParams)new RelativeLayout.LayoutParams(-1, -1));
      addView((View)this.c, (ViewGroup.LayoutParams)new RelativeLayout.LayoutParams(-1, -1));
      a((View)this.f);
      this.h = new a(this, param1Context);
    }
    
    protected void a(int param1Int1, int param1Int2) {
      j j;
      Context context = getContext();
      f f = CBUtility.c();
      if (f.b() && aw.e(this.b).e()) {
        j = aw.e(this.b);
      } else if (f.c() && aw.f(this.b).e()) {
        j = aw.f(this.b);
      } else if (aw.g(this.b).e()) {
        j = aw.g(this.b);
      } else {
        j = null;
      } 
      if (j != null) {
        aw.a(this.b, j.i());
        if (j.h() < param1Int1)
          aw.a(this.b, Math.round(aw.h(this.b) * param1Int1 / j.h())); 
        this.e.setVisibility(8);
        this.d.a(j);
      } else {
        aw aw1 = this.b;
        if (c()) {
          param1Int1 = 80;
        } else {
          param1Int1 = 40;
        } 
        aw.a(aw1, CBUtility.a(param1Int1, context));
        this.e.setVisibility(0);
      } 
      if (aw.i(this.b).c())
        aw.a(this.b, CBUtility.a(aw.i(this.b).k(), context)); 
      RelativeLayout.LayoutParams layoutParams1 = new RelativeLayout.LayoutParams(-2, -2);
      RelativeLayout.LayoutParams layoutParams2 = new RelativeLayout.LayoutParams(-2, -2);
      RelativeLayout.LayoutParams layoutParams3 = new RelativeLayout.LayoutParams(-1, aw.h(this.b));
      if (aw.j(this.b).e() && f.b()) {
        j = aw.j(this.b);
      } else if (aw.k(this.b).e() && f.c()) {
        j = aw.k(this.b);
      } else if (aw.l(this.b).e()) {
        j = aw.l(this.b);
      } else {
        j = null;
      } 
      if (j != null) {
        this.c.a(j, layoutParams2);
        if (c()) {
          param1Int1 = 14;
        } else {
          param1Int1 = 7;
        } 
        param1Int1 = CBUtility.a(param1Int1, context);
      } else {
        float f1;
        this.c.a("X");
        TextView textView = this.c.a();
        if (c()) {
          f1 = 26.0F;
        } else {
          f1 = 16.0F;
        } 
        textView.setTextSize(2, f1);
        this.c.a().setTextColor(aw.d(this.b));
        this.c.a().setTypeface(Typeface.SANS_SERIF, 1);
        layoutParams2.width = aw.h(this.b) / 2;
        layoutParams2.height = aw.h(this.b) / 3;
        if (c()) {
          param1Int1 = 30;
        } else {
          param1Int1 = 20;
        } 
        param1Int1 = CBUtility.a(param1Int1, context);
      } 
      param1Int2 = Math.round((aw.h(this.b) - layoutParams2.height) / 2.0F);
      layoutParams2.rightMargin = param1Int1;
      layoutParams2.topMargin = param1Int2;
      layoutParams2.addRule(11);
      layoutParams1.width = -1;
      layoutParams1.height = -1;
      layoutParams1.addRule(3, this.f.getId());
      this.g.setAdapter((ListAdapter)this.h);
      this.g.setLayoutParams((ViewGroup.LayoutParams)layoutParams1);
      this.c.setLayoutParams((ViewGroup.LayoutParams)layoutParams2);
      this.f.setLayoutParams((ViewGroup.LayoutParams)layoutParams3);
    }
    
    public void b() {
      super.b();
      this.c = null;
      this.d = null;
      this.g = null;
    }
    
    public class a extends ArrayAdapter<e.a> {
      private Context b;
      
      public a(aw.a this$0, Context param2Context) {
        super(param2Context, 0, aw.m(this$0.b));
        this.b = param2Context;
      }
      
      public e.a a(int param2Int) {
        return aw.m(this.a.b).get(param2Int);
      }
      
      public int getCount() {
        return aw.m(this.a.b).size();
      }
      
      public int getItemViewType(int param2Int) {
        e.a a1 = a(param2Int).a("type");
        aw.b[] arrayOfB = aw.b.values();
        for (param2Int = 0; param2Int < arrayOfB.length; param2Int++) {
          if (a1.equals(aw.b.a(arrayOfB[param2Int])))
            return param2Int; 
        } 
        return 0;
      }
      
      public View getView(int param2Int, View param2View, ViewGroup param2ViewGroup) {
        // Byte code:
        //   0: iconst_0
        //   1: istore #4
        //   3: aload_0
        //   4: iload_1
        //   5: invokevirtual a : (I)Lcom/chartboost/sdk/Libraries/e$a;
        //   8: astore #5
        //   10: aload #5
        //   12: ldc 'type'
        //   14: invokevirtual a : (Ljava/lang/String;)Lcom/chartboost/sdk/Libraries/e$a;
        //   17: astore_3
        //   18: aload_2
        //   19: ifnonnull -> 139
        //   22: invokestatic values : ()[Lcom/chartboost/sdk/impl/aw$b;
        //   25: astore_2
        //   26: iload #4
        //   28: aload_2
        //   29: arraylength
        //   30: if_icmpge -> 235
        //   33: aload_3
        //   34: aload_2
        //   35: iload #4
        //   37: aaload
        //   38: invokestatic a : (Lcom/chartboost/sdk/impl/aw$b;)Ljava/lang/String;
        //   41: invokevirtual equals : (Ljava/lang/Object;)Z
        //   44: ifeq -> 130
        //   47: aload_2
        //   48: iload #4
        //   50: aaload
        //   51: invokestatic b : (Lcom/chartboost/sdk/impl/aw$b;)Ljava/lang/Class;
        //   54: iconst_2
        //   55: anewarray java/lang/Class
        //   58: dup
        //   59: iconst_0
        //   60: ldc com/chartboost/sdk/impl/aw
        //   62: aastore
        //   63: dup
        //   64: iconst_1
        //   65: ldc android/content/Context
        //   67: aastore
        //   68: invokevirtual getConstructor : ([Ljava/lang/Class;)Ljava/lang/reflect/Constructor;
        //   71: iconst_2
        //   72: anewarray java/lang/Object
        //   75: dup
        //   76: iconst_0
        //   77: aload_0
        //   78: getfield a : Lcom/chartboost/sdk/impl/aw$a;
        //   81: getfield b : Lcom/chartboost/sdk/impl/aw;
        //   84: aastore
        //   85: dup
        //   86: iconst_1
        //   87: aload_0
        //   88: getfield b : Landroid/content/Context;
        //   91: aastore
        //   92: invokevirtual newInstance : ([Ljava/lang/Object;)Ljava/lang/Object;
        //   95: checkcast com/chartboost/sdk/impl/ap
        //   98: astore_2
        //   99: aload_2
        //   100: ifnonnull -> 156
        //   103: new android/view/View
        //   106: dup
        //   107: aload_0
        //   108: invokevirtual getContext : ()Landroid/content/Context;
        //   111: invokespecial <init> : (Landroid/content/Context;)V
        //   114: astore_3
        //   115: aload_3
        //   116: areturn
        //   117: astore_2
        //   118: aload_0
        //   119: ldc 'error in more apps list'
        //   121: aload_2
        //   122: invokestatic b : (Ljava/lang/Object;Ljava/lang/String;Ljava/lang/Throwable;)V
        //   125: aconst_null
        //   126: astore_2
        //   127: goto -> 99
        //   130: iload #4
        //   132: iconst_1
        //   133: iadd
        //   134: istore #4
        //   136: goto -> 26
        //   139: aload_2
        //   140: astore_3
        //   141: aload_2
        //   142: instanceof com/chartboost/sdk/impl/ap
        //   145: ifeq -> 115
        //   148: aload_2
        //   149: checkcast com/chartboost/sdk/impl/ap
        //   152: astore_2
        //   153: goto -> 99
        //   156: aload_2
        //   157: aload #5
        //   159: iload_1
        //   160: invokevirtual a : (Lcom/chartboost/sdk/Libraries/e$a;I)V
        //   163: aload_2
        //   164: invokevirtual getLayoutParams : ()Landroid/view/ViewGroup$LayoutParams;
        //   167: astore_3
        //   168: aload_3
        //   169: ifnull -> 219
        //   172: aload_3
        //   173: instanceof android/widget/AbsListView$LayoutParams
        //   176: ifeq -> 219
        //   179: aload_3
        //   180: checkcast android/widget/AbsListView$LayoutParams
        //   183: astore_3
        //   184: aload_3
        //   185: iconst_m1
        //   186: putfield width : I
        //   189: aload_3
        //   190: aload_2
        //   191: invokevirtual a : ()I
        //   194: putfield height : I
        //   197: aload_2
        //   198: aload_3
        //   199: invokevirtual setLayoutParams : (Landroid/view/ViewGroup$LayoutParams;)V
        //   202: aload_2
        //   203: new com/chartboost/sdk/impl/aw$a$a$1
        //   206: dup
        //   207: aload_0
        //   208: aload #5
        //   210: iload_1
        //   211: invokespecial <init> : (Lcom/chartboost/sdk/impl/aw$a$a;Lcom/chartboost/sdk/Libraries/e$a;I)V
        //   214: invokevirtual setOnClickListener : (Landroid/view/View$OnClickListener;)V
        //   217: aload_2
        //   218: areturn
        //   219: new android/widget/AbsListView$LayoutParams
        //   222: dup
        //   223: iconst_m1
        //   224: aload_2
        //   225: invokevirtual a : ()I
        //   228: invokespecial <init> : (II)V
        //   231: astore_3
        //   232: goto -> 197
        //   235: aconst_null
        //   236: astore_2
        //   237: goto -> 99
        // Exception table:
        //   from	to	target	type
        //   47	99	117	java/lang/Exception
      }
      
      public int getViewTypeCount() {
        return (aw.b.values()).length;
      }
    }
    
    class null implements View.OnClickListener {
      null(aw.a this$0, e.a param2a, int param2Int) {}
      
      public void onClick(View param2View) {
        // Byte code:
        //   0: aload_0
        //   1: getfield a : Lcom/chartboost/sdk/Libraries/e$a;
        //   4: ldc 'deep-link'
        //   6: invokevirtual e : (Ljava/lang/String;)Ljava/lang/String;
        //   9: astore_2
        //   10: aload_2
        //   11: invokestatic isEmpty : (Ljava/lang/CharSequence;)Z
        //   14: ifne -> 26
        //   17: aload_2
        //   18: astore_1
        //   19: aload_2
        //   20: invokestatic a : (Ljava/lang/String;)Z
        //   23: ifne -> 36
        //   26: aload_0
        //   27: getfield a : Lcom/chartboost/sdk/Libraries/e$a;
        //   30: ldc 'link'
        //   32: invokevirtual e : (Ljava/lang/String;)Ljava/lang/String;
        //   35: astore_1
        //   36: aload_0
        //   37: getfield c : Lcom/chartboost/sdk/impl/aw$a$a;
        //   40: getfield a : Lcom/chartboost/sdk/impl/aw$a;
        //   43: getfield b : Lcom/chartboost/sdk/impl/aw;
        //   46: aload_1
        //   47: aload_0
        //   48: getfield a : Lcom/chartboost/sdk/Libraries/e$a;
        //   51: invokevirtual a : (Ljava/lang/String;Lcom/chartboost/sdk/Libraries/e$a;)Z
        //   54: ifeq -> 101
        //   57: aload_0
        //   58: getfield c : Lcom/chartboost/sdk/impl/aw$a$a;
        //   61: getfield a : Lcom/chartboost/sdk/impl/aw$a;
        //   64: getfield b : Lcom/chartboost/sdk/impl/aw;
        //   67: invokestatic n : (Lcom/chartboost/sdk/impl/aw;)Lcom/chartboost/sdk/Model/a;
        //   70: invokevirtual q : ()Lcom/chartboost/sdk/d;
        //   73: invokevirtual e : ()Ljava/lang/String;
        //   76: aload_0
        //   77: getfield a : Lcom/chartboost/sdk/Libraries/e$a;
        //   80: ldc 'location'
        //   82: invokevirtual e : (Ljava/lang/String;)Ljava/lang/String;
        //   85: aload_0
        //   86: getfield a : Lcom/chartboost/sdk/Libraries/e$a;
        //   89: ldc 'ad_id'
        //   91: invokevirtual e : (Ljava/lang/String;)Ljava/lang/String;
        //   94: aload_0
        //   95: getfield b : I
        //   98: invokestatic a : (Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;I)V
        //   101: return
      }
    }
  }
  
  class null extends bk {
    null(aw this$0, Context param1Context, aw param1aw) {
      super(param1Context);
    }
    
    protected void a(MotionEvent param1MotionEvent) {
      aw.a(this.b.b);
    }
  }
  
  public class a extends ArrayAdapter<e.a> {
    private Context b;
    
    public a(aw this$0, Context param1Context) {
      super(param1Context, 0, aw.m(((aw.a)this$0).b));
      this.b = param1Context;
    }
    
    public e.a a(int param1Int) {
      return aw.m(this.a.b).get(param1Int);
    }
    
    public int getCount() {
      return aw.m(this.a.b).size();
    }
    
    public int getItemViewType(int param1Int) {
      e.a a1 = a(param1Int).a("type");
      aw.b[] arrayOfB = aw.b.values();
      for (param1Int = 0; param1Int < arrayOfB.length; param1Int++) {
        if (a1.equals(aw.b.a(arrayOfB[param1Int])))
          return param1Int; 
      } 
      return 0;
    }
    
    public View getView(int param1Int, View param1View, ViewGroup param1ViewGroup) {
      // Byte code:
      //   0: iconst_0
      //   1: istore #4
      //   3: aload_0
      //   4: iload_1
      //   5: invokevirtual a : (I)Lcom/chartboost/sdk/Libraries/e$a;
      //   8: astore #5
      //   10: aload #5
      //   12: ldc 'type'
      //   14: invokevirtual a : (Ljava/lang/String;)Lcom/chartboost/sdk/Libraries/e$a;
      //   17: astore_3
      //   18: aload_2
      //   19: ifnonnull -> 139
      //   22: invokestatic values : ()[Lcom/chartboost/sdk/impl/aw$b;
      //   25: astore_2
      //   26: iload #4
      //   28: aload_2
      //   29: arraylength
      //   30: if_icmpge -> 235
      //   33: aload_3
      //   34: aload_2
      //   35: iload #4
      //   37: aaload
      //   38: invokestatic a : (Lcom/chartboost/sdk/impl/aw$b;)Ljava/lang/String;
      //   41: invokevirtual equals : (Ljava/lang/Object;)Z
      //   44: ifeq -> 130
      //   47: aload_2
      //   48: iload #4
      //   50: aaload
      //   51: invokestatic b : (Lcom/chartboost/sdk/impl/aw$b;)Ljava/lang/Class;
      //   54: iconst_2
      //   55: anewarray java/lang/Class
      //   58: dup
      //   59: iconst_0
      //   60: ldc com/chartboost/sdk/impl/aw
      //   62: aastore
      //   63: dup
      //   64: iconst_1
      //   65: ldc android/content/Context
      //   67: aastore
      //   68: invokevirtual getConstructor : ([Ljava/lang/Class;)Ljava/lang/reflect/Constructor;
      //   71: iconst_2
      //   72: anewarray java/lang/Object
      //   75: dup
      //   76: iconst_0
      //   77: aload_0
      //   78: getfield a : Lcom/chartboost/sdk/impl/aw$a;
      //   81: getfield b : Lcom/chartboost/sdk/impl/aw;
      //   84: aastore
      //   85: dup
      //   86: iconst_1
      //   87: aload_0
      //   88: getfield b : Landroid/content/Context;
      //   91: aastore
      //   92: invokevirtual newInstance : ([Ljava/lang/Object;)Ljava/lang/Object;
      //   95: checkcast com/chartboost/sdk/impl/ap
      //   98: astore_2
      //   99: aload_2
      //   100: ifnonnull -> 156
      //   103: new android/view/View
      //   106: dup
      //   107: aload_0
      //   108: invokevirtual getContext : ()Landroid/content/Context;
      //   111: invokespecial <init> : (Landroid/content/Context;)V
      //   114: astore_3
      //   115: aload_3
      //   116: areturn
      //   117: astore_2
      //   118: aload_0
      //   119: ldc 'error in more apps list'
      //   121: aload_2
      //   122: invokestatic b : (Ljava/lang/Object;Ljava/lang/String;Ljava/lang/Throwable;)V
      //   125: aconst_null
      //   126: astore_2
      //   127: goto -> 99
      //   130: iload #4
      //   132: iconst_1
      //   133: iadd
      //   134: istore #4
      //   136: goto -> 26
      //   139: aload_2
      //   140: astore_3
      //   141: aload_2
      //   142: instanceof com/chartboost/sdk/impl/ap
      //   145: ifeq -> 115
      //   148: aload_2
      //   149: checkcast com/chartboost/sdk/impl/ap
      //   152: astore_2
      //   153: goto -> 99
      //   156: aload_2
      //   157: aload #5
      //   159: iload_1
      //   160: invokevirtual a : (Lcom/chartboost/sdk/Libraries/e$a;I)V
      //   163: aload_2
      //   164: invokevirtual getLayoutParams : ()Landroid/view/ViewGroup$LayoutParams;
      //   167: astore_3
      //   168: aload_3
      //   169: ifnull -> 219
      //   172: aload_3
      //   173: instanceof android/widget/AbsListView$LayoutParams
      //   176: ifeq -> 219
      //   179: aload_3
      //   180: checkcast android/widget/AbsListView$LayoutParams
      //   183: astore_3
      //   184: aload_3
      //   185: iconst_m1
      //   186: putfield width : I
      //   189: aload_3
      //   190: aload_2
      //   191: invokevirtual a : ()I
      //   194: putfield height : I
      //   197: aload_2
      //   198: aload_3
      //   199: invokevirtual setLayoutParams : (Landroid/view/ViewGroup$LayoutParams;)V
      //   202: aload_2
      //   203: new com/chartboost/sdk/impl/aw$a$a$1
      //   206: dup
      //   207: aload_0
      //   208: aload #5
      //   210: iload_1
      //   211: invokespecial <init> : (Lcom/chartboost/sdk/impl/aw$a$a;Lcom/chartboost/sdk/Libraries/e$a;I)V
      //   214: invokevirtual setOnClickListener : (Landroid/view/View$OnClickListener;)V
      //   217: aload_2
      //   218: areturn
      //   219: new android/widget/AbsListView$LayoutParams
      //   222: dup
      //   223: iconst_m1
      //   224: aload_2
      //   225: invokevirtual a : ()I
      //   228: invokespecial <init> : (II)V
      //   231: astore_3
      //   232: goto -> 197
      //   235: aconst_null
      //   236: astore_2
      //   237: goto -> 99
      // Exception table:
      //   from	to	target	type
      //   47	99	117	java/lang/Exception
    }
    
    public int getViewTypeCount() {
      return (aw.b.values()).length;
    }
  }
  
  class null implements View.OnClickListener {
    null(aw this$0, e.a param1a, int param1Int) {}
    
    public void onClick(View param1View) {
      // Byte code:
      //   0: aload_0
      //   1: getfield a : Lcom/chartboost/sdk/Libraries/e$a;
      //   4: ldc 'deep-link'
      //   6: invokevirtual e : (Ljava/lang/String;)Ljava/lang/String;
      //   9: astore_2
      //   10: aload_2
      //   11: invokestatic isEmpty : (Ljava/lang/CharSequence;)Z
      //   14: ifne -> 26
      //   17: aload_2
      //   18: astore_1
      //   19: aload_2
      //   20: invokestatic a : (Ljava/lang/String;)Z
      //   23: ifne -> 36
      //   26: aload_0
      //   27: getfield a : Lcom/chartboost/sdk/Libraries/e$a;
      //   30: ldc 'link'
      //   32: invokevirtual e : (Ljava/lang/String;)Ljava/lang/String;
      //   35: astore_1
      //   36: aload_0
      //   37: getfield c : Lcom/chartboost/sdk/impl/aw$a$a;
      //   40: getfield a : Lcom/chartboost/sdk/impl/aw$a;
      //   43: getfield b : Lcom/chartboost/sdk/impl/aw;
      //   46: aload_1
      //   47: aload_0
      //   48: getfield a : Lcom/chartboost/sdk/Libraries/e$a;
      //   51: invokevirtual a : (Ljava/lang/String;Lcom/chartboost/sdk/Libraries/e$a;)Z
      //   54: ifeq -> 101
      //   57: aload_0
      //   58: getfield c : Lcom/chartboost/sdk/impl/aw$a$a;
      //   61: getfield a : Lcom/chartboost/sdk/impl/aw$a;
      //   64: getfield b : Lcom/chartboost/sdk/impl/aw;
      //   67: invokestatic n : (Lcom/chartboost/sdk/impl/aw;)Lcom/chartboost/sdk/Model/a;
      //   70: invokevirtual q : ()Lcom/chartboost/sdk/d;
      //   73: invokevirtual e : ()Ljava/lang/String;
      //   76: aload_0
      //   77: getfield a : Lcom/chartboost/sdk/Libraries/e$a;
      //   80: ldc 'location'
      //   82: invokevirtual e : (Ljava/lang/String;)Ljava/lang/String;
      //   85: aload_0
      //   86: getfield a : Lcom/chartboost/sdk/Libraries/e$a;
      //   89: ldc 'ad_id'
      //   91: invokevirtual e : (Ljava/lang/String;)Ljava/lang/String;
      //   94: aload_0
      //   95: getfield b : I
      //   98: invokestatic a : (Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;I)V
      //   101: return
    }
  }
  
  private enum b {
    a("featured", aq.class),
    b("regular", ar.class),
    c("webview", at.class),
    d("video", as.class);
    
    private String e;
    
    private Class<? extends ap> f;
    
    b(String param1String1, Class<? extends ap> param1Class) {
      this.e = param1String1;
      this.f = param1Class;
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Smash Cricket-dex2jar.jar!\com\chartboost\sdk\impl\aw.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */