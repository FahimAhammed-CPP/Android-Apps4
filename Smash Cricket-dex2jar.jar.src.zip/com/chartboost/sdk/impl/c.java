package com.chartboost.sdk.impl;

import android.os.Process;
import java.util.concurrent.BlockingQueue;

public class c extends Thread {
  private static final boolean a = t.b;
  
  private final BlockingQueue<l<?>> b;
  
  private final BlockingQueue<l<?>> c;
  
  private final b d;
  
  private final o e;
  
  private volatile boolean f = false;
  
  public c(BlockingQueue<l<?>> paramBlockingQueue1, BlockingQueue<l<?>> paramBlockingQueue2, b paramb, o paramo) {
    this.b = paramBlockingQueue1;
    this.c = paramBlockingQueue2;
    this.d = paramb;
    this.e = paramo;
  }
  
  public void a() {
    this.f = true;
    interrupt();
  }
  
  public void run() {
    if (a)
      t.a("start new dispatcher", new Object[0]); 
    Process.setThreadPriority(10);
    this.d.a();
    while (true) {
      try {
        l l = this.b.take();
        l.a("cache-queue-take");
        if (l.h()) {
          l.b("cache-discard-canceled");
          continue;
        } 
      } catch (InterruptedException interruptedException) {
        if (this.f)
          return; 
        continue;
      } 
      b.a a = this.d.a(interruptedException.e());
      if (a == null) {
        interruptedException.a("cache-miss");
        this.c.put(interruptedException);
        continue;
      } 
      if (a.a()) {
        interruptedException.a("cache-hit-expired");
        interruptedException.a(a);
        this.c.put(interruptedException);
        continue;
      } 
      interruptedException.a("cache-hit");
      n<?> n = interruptedException.a(new i(a.a, a.f));
      interruptedException.a("cache-hit-parsed");
      if (!a.b()) {
        this.e.a((l<?>)interruptedException, n);
        continue;
      } 
      interruptedException.a("cache-hit-refresh-needed");
      interruptedException.a(a);
      n.d = true;
      this.e.a((l<?>)interruptedException, n, new Runnable(this, (l)interruptedException) {
            public void run() {
              try {
                c.a(this.a).put(this.b);
                return;
              } catch (InterruptedException interruptedException) {
                return;
              } 
            }
          });
    } 
  }
}


/* Location:              C:\soft\dex2jar-2.0\Smash Cricket-dex2jar.jar!\com\chartboost\sdk\impl\c.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */