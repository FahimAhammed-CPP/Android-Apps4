package com.chartboost.sdk.impl;

import android.content.Context;
import com.chartboost.sdk.Libraries.CBLogging;
import com.chartboost.sdk.Libraries.e;
import com.chartboost.sdk.Model.CBError;
import com.chartboost.sdk.Model.a;
import com.chartboost.sdk.Model.b;
import com.chartboost.sdk.b;
import com.chartboost.sdk.d;

public class af extends ae {
  private static af b;
  
  private static String c = "CBRewardedVideo";
  
  public static af h() {
    if (b == null)
      b = new af(); 
    return b;
  }
  
  protected a a(String paramString, boolean paramBoolean) {
    return new a(a.c.c, paramBoolean, paramString, false);
  }
  
  protected boolean b(a parama, e.a parama1) {
    return true;
  }
  
  public d.a c() {
    return new d.a(this) {
        public void a(a param1a) {
          if (b.f() != null)
            b.f().didClickRewardedVideo(param1a.d); 
        }
        
        public void a(a param1a, CBError.CBImpressionError param1CBImpressionError) {
          if (b.f() != null)
            b.f().didFailToLoadRewardedVideo(param1a.d, param1CBImpressionError); 
        }
        
        public void b(a param1a) {
          if (b.f() != null)
            b.f().didCloseRewardedVideo(param1a.d); 
        }
        
        public void c(a param1a) {
          this.a.r(param1a);
          if (b.f() != null)
            b.f().didDismissRewardedVideo(param1a.d); 
        }
        
        public void d(a param1a) {
          if (b.f() != null)
            b.f().didCacheRewardedVideo(param1a.d); 
        }
        
        public void e(a param1a) {
          if (b.f() != null)
            b.f().didDisplayRewardedVideo(param1a.d); 
        }
        
        public boolean f(a param1a) {
          return (b.f() != null) ? b.f().shouldDisplayRewardedVideo(param1a.d) : true;
        }
        
        public boolean g(a param1a) {
          return true;
        }
        
        public boolean h(a param1a) {
          return (b.f() != null) ? b.u() : true;
        }
      };
  }
  
  protected az e(a parama) {
    az az = new az("/reward/get");
    az.a(l.a.c);
    az.a(b.b);
    az.a("local-videos", h().g());
    return az;
  }
  
  public String e() {
    return "rewarded-video";
  }
  
  protected void h(a parama) {
    e.a a1 = parama.w().a("ux").a("pre-popup");
    if (a1.c() && a1.a("title").d() && a1.a("text").d() && a1.a("confirm").d() && a1.a("cancel").d() && d() != null) {
      a.post(new Runnable(this, a1, parama) {
            public void run() {
              bl.a a1 = new bl.a();
              a1.a(this.a.e("title")).b(this.a.e("text")).d(this.a.e("confirm")).c(this.a.e("cancel"));
              a1.a(af.a(this.c), new bl.b(this) {
                    public void a(bl param2bl) {
                      af.a(this.a.c, this.a.b, CBError.CBImpressionError.USER_CANCELLATION);
                    }
                    
                    public void a(bl param2bl, int param2Int) {
                      if (param2Int == 1) {
                        af.a(this.a.c, this.a.b);
                        return;
                      } 
                      af.b(this.a.c, this.a.b, CBError.CBImpressionError.USER_CANCELLATION);
                    }
                  });
            }
          });
      return;
    } 
    super.h(parama);
  }
  
  protected void i(a parama) {}
  
  public az l(a parama) {
    az az = super.l(parama);
    az.a("/reward/show");
    return az;
  }
  
  protected void r(a parama) {
    e.a a1 = parama.w().a("ux").a("post-popup");
    if (a1.c() && a1.a("title").d() && a1.a("text").d() && a1.a("confirm").d() && d() != null && parama.l)
      a.post(new Runnable(this, a1) {
            public void run() {
              bl.a a1 = new bl.a();
              a1.a(this.a.e("title")).b(this.a.e("text")).c(this.a.e("confirm"));
              a1.a(af.b(this.b), new bl.b(this) {
                    public void a(bl param2bl, int param2Int) {
                      CBLogging.c(af.i(), "post-popup dismissed");
                    }
                  });
            }
          }); 
  }
}


/* Location:              C:\soft\dex2jar-2.0\Smash Cricket-dex2jar.jar!\com\chartboost\sdk\impl\af.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */