package com.chartboost.sdk.impl;

import java.io.DataOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import javax.net.ssl.HttpsURLConnection;
import javax.net.ssl.SSLSocketFactory;
import org.apache.http.Header;
import org.apache.http.HttpEntity;
import org.apache.http.HttpResponse;
import org.apache.http.ProtocolVersion;
import org.apache.http.StatusLine;
import org.apache.http.entity.BasicHttpEntity;
import org.apache.http.message.BasicHeader;
import org.apache.http.message.BasicHttpResponse;
import org.apache.http.message.BasicStatusLine;

public class aa implements z {
  private final a a;
  
  private final SSLSocketFactory b;
  
  public aa() {
    this(null);
  }
  
  public aa(a parama) {
    this(parama, null);
  }
  
  public aa(a parama, SSLSocketFactory paramSSLSocketFactory) {
    this.a = parama;
    this.b = paramSSLSocketFactory;
  }
  
  private HttpURLConnection a(URL paramURL, l<?> paraml) throws IOException {
    HttpURLConnection httpURLConnection = a(paramURL);
    int i = paraml.t();
    httpURLConnection.setConnectTimeout(i);
    httpURLConnection.setReadTimeout(i);
    httpURLConnection.setUseCaches(false);
    httpURLConnection.setDoInput(true);
    if ("https".equals(paramURL.getProtocol()) && this.b != null)
      ((HttpsURLConnection)httpURLConnection).setSSLSocketFactory(this.b); 
    return httpURLConnection;
  }
  
  private static HttpEntity a(HttpURLConnection paramHttpURLConnection) {
    InputStream inputStream;
    BasicHttpEntity basicHttpEntity = new BasicHttpEntity();
    try {
      inputStream = paramHttpURLConnection.getInputStream();
    } catch (IOException iOException) {
      inputStream = paramHttpURLConnection.getErrorStream();
    } 
    basicHttpEntity.setContent(inputStream);
    basicHttpEntity.setContentLength(paramHttpURLConnection.getContentLength());
    basicHttpEntity.setContentEncoding(paramHttpURLConnection.getContentEncoding());
    basicHttpEntity.setContentType(paramHttpURLConnection.getContentType());
    return (HttpEntity)basicHttpEntity;
  }
  
  static void a(HttpURLConnection paramHttpURLConnection, l<?> paraml) throws IOException, a {
    DataOutputStream dataOutputStream;
    byte[] arrayOfByte;
    switch (paraml.a()) {
      default:
        throw new IllegalStateException("Unknown method type.");
      case -1:
        arrayOfByte = paraml.m();
        if (arrayOfByte != null) {
          paramHttpURLConnection.setDoOutput(true);
          paramHttpURLConnection.setRequestMethod("POST");
          paramHttpURLConnection.addRequestProperty("Content-Type", paraml.l());
          dataOutputStream = new DataOutputStream(paramHttpURLConnection.getOutputStream());
          dataOutputStream.write(arrayOfByte);
          dataOutputStream.close();
        } 
        return;
      case 0:
        dataOutputStream.setRequestMethod("GET");
        return;
      case 3:
        dataOutputStream.setRequestMethod("DELETE");
        return;
      case 1:
        dataOutputStream.setRequestMethod("POST");
        b((HttpURLConnection)dataOutputStream, paraml);
        return;
      case 2:
        dataOutputStream.setRequestMethod("PUT");
        b((HttpURLConnection)dataOutputStream, paraml);
        return;
      case 4:
        dataOutputStream.setRequestMethod("HEAD");
        return;
      case 5:
        dataOutputStream.setRequestMethod("OPTIONS");
        return;
      case 6:
        dataOutputStream.setRequestMethod("TRACE");
        return;
      case 7:
        break;
    } 
    dataOutputStream.setRequestMethod("PATCH");
    b((HttpURLConnection)dataOutputStream, paraml);
  }
  
  private static void b(HttpURLConnection paramHttpURLConnection, l<?> paraml) throws IOException, a {
    byte[] arrayOfByte = paraml.q();
    if (arrayOfByte != null) {
      paramHttpURLConnection.setDoOutput(true);
      paramHttpURLConnection.addRequestProperty("Content-Type", paraml.p());
      DataOutputStream dataOutputStream = new DataOutputStream(paramHttpURLConnection.getOutputStream());
      dataOutputStream.write(arrayOfByte);
      dataOutputStream.close();
    } 
  }
  
  protected HttpURLConnection a(URL paramURL) throws IOException {
    return (HttpURLConnection)paramURL.openConnection();
  }
  
  public HttpResponse a(l<?> paraml, Map<String, String> paramMap) throws IOException, a {
    String str1;
    String str2 = paraml.d();
    HashMap<Object, Object> hashMap = new HashMap<Object, Object>();
    hashMap.putAll(paraml.i());
    hashMap.putAll(paramMap);
    if (this.a != null) {
      String str = this.a.a(str2);
      str1 = str;
      if (str == null)
        throw new IOException("URL blocked by rewriter: " + str2); 
    } else {
      str1 = str2;
    } 
    HttpURLConnection httpURLConnection = a(new URL(str1), paraml);
    Iterator<String> iterator = hashMap.keySet().iterator();
    while (true) {
      ProtocolVersion protocolVersion;
      if (!iterator.hasNext()) {
        a(httpURLConnection, paraml);
        protocolVersion = new ProtocolVersion("HTTP", 1, 1);
        if (httpURLConnection.getResponseCode() == -1)
          throw new IOException("Could not retrieve response code from HttpUrlConnection."); 
      } else {
        String str = iterator.next();
        httpURLConnection.addRequestProperty(str, (String)hashMap.get(str));
        continue;
      } 
      BasicHttpResponse basicHttpResponse = new BasicHttpResponse((StatusLine)new BasicStatusLine(protocolVersion, httpURLConnection.getResponseCode(), httpURLConnection.getResponseMessage()));
      basicHttpResponse.setEntity(a(httpURLConnection));
      Iterator<Map.Entry> iterator1 = httpURLConnection.getHeaderFields().entrySet().iterator();
      while (true) {
        if (!iterator1.hasNext())
          return (HttpResponse)basicHttpResponse; 
        Map.Entry entry = iterator1.next();
        if (entry.getKey() != null)
          basicHttpResponse.addHeader((Header)new BasicHeader((String)entry.getKey(), ((List<String>)entry.getValue()).get(0))); 
      } 
      break;
    } 
  }
  
  public static interface a {
    String a(String param1String);
  }
}


/* Location:              C:\soft\dex2jar-2.0\Smash Cricket-dex2jar.jar!\com\chartboost\sdk\impl\aa.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */