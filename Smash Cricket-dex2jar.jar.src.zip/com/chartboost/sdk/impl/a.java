package com.chartboost.sdk.impl;

import android.content.Intent;

public class a extends s {
  private Intent b;
  
  public a() {}
  
  public a(i parami) {
    super(parami);
  }
  
  public String getMessage() {
    return (this.b != null) ? "User needs to (re)enter credentials." : super.getMessage();
  }
}


/* Location:              C:\soft\dex2jar-2.0\Smash Cricket-dex2jar.jar!\com\chartboost\sdk\impl\a.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */