package com.chartboost.sdk.impl;

import java.io.IOException;
import java.util.Map;
import org.apache.http.HttpResponse;

public interface z {
  HttpResponse a(l<?> paraml, Map<String, String> paramMap) throws IOException, a;
}


/* Location:              C:\soft\dex2jar-2.0\Smash Cricket-dex2jar.jar!\com\chartboost\sdk\impl\z.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */