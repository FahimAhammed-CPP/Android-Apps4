package com.chartboost.sdk.impl;

import android.content.Context;
import android.os.CountDownTimer;
import android.text.TextUtils;
import com.chartboost.sdk.Libraries.CBLogging;
import com.chartboost.sdk.Libraries.h;
import com.chartboost.sdk.Model.CBError;
import java.io.File;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Observable;
import java.util.Observer;
import java.util.concurrent.ConcurrentHashMap;
import org.json.JSONArray;

public class ba implements Observer {
  private static ba b;
  
  private static ConcurrentHashMap<az, File> e;
  
  private static ConcurrentHashMap<az, File> f;
  
  private static List<Runnable> h = new ArrayList<Runnable>();
  
  private ay a = null;
  
  private m c;
  
  private h d;
  
  private ConcurrentHashMap<String, b> g;
  
  private CountDownTimer i;
  
  private ba(Context paramContext) {
    this.c = ad.a(paramContext.getApplicationContext());
    this.a = ay.a();
    this.d = new h("CBRequestManager", false);
    e = new ConcurrentHashMap<az, File>();
    f = new ConcurrentHashMap<az, File>();
    this.g = new ConcurrentHashMap<String, b>();
    m();
    this.a.addObserver(this);
  }
  
  private az a(String paramString) {
    az az2 = null;
    az az1 = az2;
    if (!TextUtils.isEmpty(paramString)) {
      com.chartboost.sdk.Libraries.e.a a = this.d.a(paramString);
      az1 = az2;
      if (a != null)
        az1 = az.a(a); 
    } 
    return az1;
  }
  
  public static ba a(Context paramContext) {
    // Byte code:
    //   0: getstatic com/chartboost/sdk/impl/ba.b : Lcom/chartboost/sdk/impl/ba;
    //   3: ifnonnull -> 29
    //   6: ldc com/chartboost/sdk/impl/ba
    //   8: monitorenter
    //   9: getstatic com/chartboost/sdk/impl/ba.b : Lcom/chartboost/sdk/impl/ba;
    //   12: ifnonnull -> 26
    //   15: new com/chartboost/sdk/impl/ba
    //   18: dup
    //   19: aload_0
    //   20: invokespecial <init> : (Landroid/content/Context;)V
    //   23: putstatic com/chartboost/sdk/impl/ba.b : Lcom/chartboost/sdk/impl/ba;
    //   26: ldc com/chartboost/sdk/impl/ba
    //   28: monitorexit
    //   29: getstatic com/chartboost/sdk/impl/ba.b : Lcom/chartboost/sdk/impl/ba;
    //   32: areturn
    //   33: astore_0
    //   34: ldc com/chartboost/sdk/impl/ba
    //   36: monitorexit
    //   37: aload_0
    //   38: athrow
    // Exception table:
    //   from	to	target	type
    //   9	26	33	finally
    //   26	29	33	finally
    //   34	37	33	finally
  }
  
  private void a(az paramaz) {
    if (paramaz != null) {
      File file;
      if (paramaz.k()) {
        file = (File)this.g.get(paramaz.g());
        if (file != null && !TextUtils.isEmpty(file.b()) && file.c()) {
          paramaz = file.a(paramaz);
          String str = file.a();
          File file1 = this.d.a(str, paramaz.t());
        } else {
          File file1 = this.d.a(null, paramaz.t());
        } 
      } else {
        file = null;
      } 
      if ((paramaz.k() || paramaz.m()) && file != null)
        e.put(paramaz, file); 
    } 
  }
  
  private void a(az paramaz, i parami, CBError paramCBError, boolean paramBoolean) {
    String str1;
    String str3;
    Integer integer;
    CBError.a a1;
    String str2;
    if (paramaz == null)
      return; 
    com.chartboost.sdk.Libraries.e.b b1 = com.chartboost.sdk.Libraries.e.a("endpoint", paramaz.g());
    if (parami == null) {
      str3 = "None";
    } else {
      integer = Integer.valueOf(((i)str3).a);
    } 
    com.chartboost.sdk.Libraries.e.b b2 = com.chartboost.sdk.Libraries.e.a("statuscode", integer);
    if (paramCBError == null) {
      str2 = "None";
    } else {
      a1 = paramCBError.a();
    } 
    com.chartboost.sdk.Libraries.e.b b3 = com.chartboost.sdk.Libraries.e.a("error", a1);
    if (paramCBError == null) {
      str2 = "None";
    } else {
      str2 = paramCBError.b();
    } 
    com.chartboost.sdk.Libraries.e.a a = com.chartboost.sdk.Libraries.e.a(new com.chartboost.sdk.Libraries.e.b[] { b1, b2, b3, com.chartboost.sdk.Libraries.e.a("errorDescription", str2), com.chartboost.sdk.Libraries.e.a("retryCount", Integer.valueOf(paramaz.o())) });
    if (paramBoolean) {
      str1 = "success";
    } else {
      str1 = "failure";
    } 
    com.chartboost.sdk.Tracking.a.a("request_manager", "request", str1, null, null, null, a.e());
  }
  
  public static void b() {
    // Byte code:
    //   0: new java/util/ArrayList
    //   3: dup
    //   4: invokespecial <init> : ()V
    //   7: astore_0
    //   8: ldc com/chartboost/sdk/Libraries/c
    //   10: monitorenter
    //   11: aload_0
    //   12: getstatic com/chartboost/sdk/impl/ba.h : Ljava/util/List;
    //   15: invokeinterface addAll : (Ljava/util/Collection;)Z
    //   20: pop
    //   21: getstatic com/chartboost/sdk/impl/ba.h : Ljava/util/List;
    //   24: invokeinterface clear : ()V
    //   29: ldc com/chartboost/sdk/Libraries/c
    //   31: monitorexit
    //   32: aload_0
    //   33: invokeinterface iterator : ()Ljava/util/Iterator;
    //   38: astore_0
    //   39: aload_0
    //   40: invokeinterface hasNext : ()Z
    //   45: ifeq -> 76
    //   48: aload_0
    //   49: invokeinterface next : ()Ljava/lang/Object;
    //   54: checkcast java/lang/Runnable
    //   57: astore_1
    //   58: invokestatic a : ()Ljava/util/concurrent/ExecutorService;
    //   61: aload_1
    //   62: invokeinterface execute : (Ljava/lang/Runnable;)V
    //   67: goto -> 39
    //   70: astore_0
    //   71: ldc com/chartboost/sdk/Libraries/c
    //   73: monitorexit
    //   74: aload_0
    //   75: athrow
    //   76: return
    // Exception table:
    //   from	to	target	type
    //   11	32	70	finally
    //   71	74	70	finally
  }
  
  public static void d() {
    // Byte code:
    //   0: ldc com/chartboost/sdk/impl/ba
    //   2: monitorenter
    //   3: invokestatic c : ()Lcom/chartboost/sdk/Libraries/h;
    //   6: astore_3
    //   7: aload_3
    //   8: ifnull -> 119
    //   11: aload_3
    //   12: invokevirtual a : ()[Ljava/lang/String;
    //   15: astore_2
    //   16: aload_2
    //   17: ifnull -> 109
    //   20: aload_2
    //   21: arraylength
    //   22: ifle -> 109
    //   25: aload_2
    //   26: arraylength
    //   27: istore_1
    //   28: iconst_0
    //   29: istore_0
    //   30: iload_0
    //   31: iload_1
    //   32: if_icmpge -> 109
    //   35: aload_2
    //   36: iload_0
    //   37: aaload
    //   38: astore #4
    //   40: aload_3
    //   41: aload #4
    //   43: invokevirtual a : (Ljava/lang/String;)Lcom/chartboost/sdk/Libraries/e$a;
    //   46: astore #5
    //   48: aload #5
    //   50: invokevirtual c : ()Z
    //   53: ifeq -> 124
    //   56: aload_3
    //   57: aload #4
    //   59: invokevirtual b : (Ljava/lang/String;)V
    //   62: aload #5
    //   64: invokestatic a : (Lcom/chartboost/sdk/Libraries/e$a;)Lcom/chartboost/sdk/impl/az;
    //   67: astore #4
    //   69: aload #4
    //   71: ifnull -> 88
    //   74: aload #4
    //   76: iconst_1
    //   77: invokevirtual a : (Z)V
    //   80: aload #4
    //   82: invokevirtual s : ()V
    //   85: goto -> 124
    //   88: ldc 'CBRequestManager'
    //   90: ldc_w 'Error processing video completeion event'
    //   93: invokestatic b : (Ljava/lang/Object;Ljava/lang/String;)V
    //   96: goto -> 124
    //   99: astore_2
    //   100: ldc 'CBRequestManager'
    //   102: ldc_w 'Error executing saved requests'
    //   105: aload_2
    //   106: invokestatic b : (Ljava/lang/Object;Ljava/lang/String;Ljava/lang/Throwable;)V
    //   109: ldc com/chartboost/sdk/impl/ba
    //   111: monitorexit
    //   112: return
    //   113: astore_2
    //   114: ldc com/chartboost/sdk/impl/ba
    //   116: monitorexit
    //   117: aload_2
    //   118: athrow
    //   119: aconst_null
    //   120: astore_2
    //   121: goto -> 16
    //   124: iload_0
    //   125: iconst_1
    //   126: iadd
    //   127: istore_0
    //   128: goto -> 30
    // Exception table:
    //   from	to	target	type
    //   3	7	99	java/lang/Exception
    //   3	7	113	finally
    //   11	16	99	java/lang/Exception
    //   11	16	113	finally
    //   20	28	99	java/lang/Exception
    //   20	28	113	finally
    //   40	69	99	java/lang/Exception
    //   40	69	113	finally
    //   74	85	99	java/lang/Exception
    //   74	85	113	finally
    //   88	96	99	java/lang/Exception
    //   88	96	113	finally
    //   100	109	113	finally
  }
  
  public static boolean h() {
    // Byte code:
    //   0: ldc com/chartboost/sdk/impl/ba
    //   2: monitorenter
    //   3: getstatic com/chartboost/sdk/impl/ba.f : Ljava/util/concurrent/ConcurrentHashMap;
    //   6: ifnull -> 27
    //   9: getstatic com/chartboost/sdk/impl/ba.f : Ljava/util/concurrent/ConcurrentHashMap;
    //   12: invokevirtual isEmpty : ()Z
    //   15: istore_0
    //   16: iload_0
    //   17: ifne -> 27
    //   20: iconst_1
    //   21: istore_0
    //   22: ldc com/chartboost/sdk/impl/ba
    //   24: monitorexit
    //   25: iload_0
    //   26: ireturn
    //   27: iconst_0
    //   28: istore_0
    //   29: goto -> 22
    //   32: astore_1
    //   33: ldc com/chartboost/sdk/impl/ba
    //   35: monitorexit
    //   36: aload_1
    //   37: athrow
    // Exception table:
    //   from	to	target	type
    //   3	16	32	finally
  }
  
  private void m() {
    b b = new b(this);
    b.a("track_info");
    b.a(true);
    this.g.put("/post-install-event/".concat("tracking"), b);
  }
  
  public m a() {
    return this.c;
  }
  
  protected void a(az paramaz, az.c paramc) {
    if (paramaz != null) {
      if (!this.a.c()) {
        CBError cBError = new CBError(CBError.a.b, "Internet Unavailable");
        paramaz.d(false);
        if (!paramaz.h()) {
          if (paramaz.p()) {
            paramaz.c(false);
            a(paramaz);
          } 
          a(paramaz, null, cBError, false);
          if (paramc != null)
            CBLogging.b("Network failure", String.format("request %s failed with error : %s", new Object[] { paramaz.g(), cBError.b() })); 
          paramc.a(null, paramaz, cBError);
          return;
        } 
        return;
      } 
      if (!paramaz.h() && paramaz.p()) {
        paramaz.c(false);
        a(paramaz);
      } 
      a(new e(this, paramaz));
      return;
    } 
  }
  
  public void a(Runnable paramRunnable) {
    // Byte code:
    //   0: iconst_0
    //   1: istore_2
    //   2: ldc com/chartboost/sdk/Libraries/c
    //   4: monitorenter
    //   5: invokestatic c : ()Lcom/chartboost/sdk/Libraries/c$a;
    //   8: astore_3
    //   9: aload_3
    //   10: getstatic com/chartboost/sdk/Libraries/c$a.a : Lcom/chartboost/sdk/Libraries/c$a;
    //   13: if_acmpeq -> 23
    //   16: aload_3
    //   17: getstatic com/chartboost/sdk/Libraries/c$a.b : Lcom/chartboost/sdk/Libraries/c$a;
    //   20: if_acmpne -> 50
    //   23: getstatic com/chartboost/sdk/impl/ba.h : Ljava/util/List;
    //   26: aload_1
    //   27: invokeinterface add : (Ljava/lang/Object;)Z
    //   32: pop
    //   33: ldc com/chartboost/sdk/Libraries/c
    //   35: monitorexit
    //   36: iload_2
    //   37: ifeq -> 49
    //   40: invokestatic a : ()Ljava/util/concurrent/ExecutorService;
    //   43: aload_1
    //   44: invokeinterface execute : (Ljava/lang/Runnable;)V
    //   49: return
    //   50: iconst_1
    //   51: istore_2
    //   52: goto -> 33
    //   55: astore_1
    //   56: ldc com/chartboost/sdk/Libraries/c
    //   58: monitorexit
    //   59: aload_1
    //   60: athrow
    // Exception table:
    //   from	to	target	type
    //   5	23	55	finally
    //   23	33	55	finally
    //   33	36	55	finally
    //   56	59	55	finally
  }
  
  public void c() {
    // Byte code:
    //   0: iconst_0
    //   1: istore_1
    //   2: aload_0
    //   3: monitorenter
    //   4: getstatic com/chartboost/sdk/impl/ba.e : Ljava/util/concurrent/ConcurrentHashMap;
    //   7: ifnull -> 94
    //   10: getstatic com/chartboost/sdk/impl/ba.e : Ljava/util/concurrent/ConcurrentHashMap;
    //   13: invokevirtual isEmpty : ()Z
    //   16: ifne -> 94
    //   19: getstatic com/chartboost/sdk/impl/ba.e : Ljava/util/concurrent/ConcurrentHashMap;
    //   22: invokevirtual keySet : ()Ljava/util/Set;
    //   25: invokeinterface iterator : ()Ljava/util/Iterator;
    //   30: astore_3
    //   31: aload_3
    //   32: invokeinterface hasNext : ()Z
    //   37: ifeq -> 181
    //   40: aload_3
    //   41: invokeinterface next : ()Ljava/lang/Object;
    //   46: checkcast com/chartboost/sdk/impl/az
    //   49: astore #4
    //   51: aload #4
    //   53: ifnull -> 31
    //   56: aload #4
    //   58: invokevirtual q : ()Z
    //   61: ifne -> 31
    //   64: aload #4
    //   66: aload #4
    //   68: invokevirtual o : ()I
    //   71: iconst_1
    //   72: iadd
    //   73: invokevirtual a : (I)V
    //   76: aload #4
    //   78: aload #4
    //   80: invokevirtual r : ()Lcom/chartboost/sdk/impl/az$c;
    //   83: invokevirtual a : (Lcom/chartboost/sdk/impl/az$c;)V
    //   86: goto -> 31
    //   89: astore_3
    //   90: aload_0
    //   91: monitorexit
    //   92: aload_3
    //   93: athrow
    //   94: aload_0
    //   95: getfield d : Lcom/chartboost/sdk/Libraries/h;
    //   98: invokevirtual a : ()[Ljava/lang/String;
    //   101: astore_3
    //   102: aload_3
    //   103: ifnull -> 181
    //   106: aload_3
    //   107: arraylength
    //   108: istore_2
    //   109: iload_1
    //   110: iload_2
    //   111: if_icmpge -> 181
    //   114: aload_3
    //   115: iload_1
    //   116: aaload
    //   117: astore #4
    //   119: aload_0
    //   120: aload #4
    //   122: invokespecial a : (Ljava/lang/String;)Lcom/chartboost/sdk/impl/az;
    //   125: astore #5
    //   127: aload #5
    //   129: ifnull -> 192
    //   132: getstatic com/chartboost/sdk/impl/ba.e : Ljava/util/concurrent/ConcurrentHashMap;
    //   135: aload #5
    //   137: aload_0
    //   138: getfield d : Lcom/chartboost/sdk/Libraries/h;
    //   141: aload #4
    //   143: invokevirtual d : (Ljava/lang/String;)Ljava/io/File;
    //   146: invokevirtual put : (Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    //   149: pop
    //   150: aload #5
    //   152: iconst_0
    //   153: invokevirtual c : (Z)V
    //   156: aload #5
    //   158: aload #5
    //   160: invokevirtual o : ()I
    //   163: iconst_1
    //   164: iadd
    //   165: invokevirtual a : (I)V
    //   168: aload #5
    //   170: aload #5
    //   172: invokevirtual r : ()Lcom/chartboost/sdk/impl/az$c;
    //   175: invokevirtual a : (Lcom/chartboost/sdk/impl/az$c;)V
    //   178: goto -> 192
    //   181: aload_0
    //   182: invokevirtual e : ()V
    //   185: aload_0
    //   186: invokevirtual f : ()V
    //   189: aload_0
    //   190: monitorexit
    //   191: return
    //   192: iload_1
    //   193: iconst_1
    //   194: iadd
    //   195: istore_1
    //   196: goto -> 109
    // Exception table:
    //   from	to	target	type
    //   4	31	89	finally
    //   31	51	89	finally
    //   56	86	89	finally
    //   94	102	89	finally
    //   106	109	89	finally
    //   119	127	89	finally
    //   132	178	89	finally
    //   181	189	89	finally
  }
  
  public void e() {
    // Byte code:
    //   0: invokestatic a : ()Lcom/chartboost/sdk/Tracking/a;
    //   3: astore #5
    //   5: invokestatic l : ()Z
    //   8: ifne -> 41
    //   11: getstatic com/chartboost/sdk/impl/ba.f : Ljava/util/concurrent/ConcurrentHashMap;
    //   14: ifnull -> 32
    //   17: getstatic com/chartboost/sdk/impl/ba.f : Ljava/util/concurrent/ConcurrentHashMap;
    //   20: invokevirtual isEmpty : ()Z
    //   23: ifne -> 32
    //   26: getstatic com/chartboost/sdk/impl/ba.f : Ljava/util/concurrent/ConcurrentHashMap;
    //   29: invokevirtual clear : ()V
    //   32: aload #5
    //   34: invokevirtual l : ()Lcom/chartboost/sdk/Libraries/h;
    //   37: invokevirtual b : ()V
    //   40: return
    //   41: aload_0
    //   42: monitorenter
    //   43: getstatic com/chartboost/sdk/impl/ba.f : Ljava/util/concurrent/ConcurrentHashMap;
    //   46: invokevirtual isEmpty : ()Z
    //   49: istore_3
    //   50: iload_3
    //   51: ifeq -> 213
    //   54: aload #5
    //   56: invokevirtual l : ()Lcom/chartboost/sdk/Libraries/h;
    //   59: astore #6
    //   61: aload #6
    //   63: ifnull -> 286
    //   66: aload #6
    //   68: invokevirtual a : ()[Ljava/lang/String;
    //   71: astore #4
    //   73: aload #4
    //   75: ifnull -> 203
    //   78: aload #4
    //   80: arraylength
    //   81: istore_2
    //   82: iconst_0
    //   83: istore_1
    //   84: iload_1
    //   85: iload_2
    //   86: if_icmpge -> 203
    //   89: aload #4
    //   91: iload_1
    //   92: aaload
    //   93: astore #7
    //   95: aload #5
    //   97: aload #7
    //   99: invokevirtual b : (Ljava/lang/String;)Z
    //   102: ifne -> 184
    //   105: aload #6
    //   107: aload #7
    //   109: invokevirtual a : (Ljava/lang/String;)Lcom/chartboost/sdk/Libraries/e$a;
    //   112: astore #8
    //   114: aload #8
    //   116: invokevirtual c : ()Z
    //   119: ifeq -> 184
    //   122: ldc 'CBRequestManager'
    //   124: new java/lang/StringBuilder
    //   127: dup
    //   128: invokespecial <init> : ()V
    //   131: ldc_w '### Flushing out '
    //   134: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   137: aload #7
    //   139: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   142: ldc_w 'track events from cache to server...'
    //   145: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   148: invokevirtual toString : ()Ljava/lang/String;
    //   151: invokestatic a : (Ljava/lang/Object;Ljava/lang/String;)V
    //   154: aload #5
    //   156: aload #8
    //   158: invokevirtual a : (Lcom/chartboost/sdk/Libraries/e$a;)Lcom/chartboost/sdk/impl/az;
    //   161: astore #8
    //   163: getstatic com/chartboost/sdk/impl/ba.f : Ljava/util/concurrent/ConcurrentHashMap;
    //   166: aload #8
    //   168: aload #6
    //   170: aload #7
    //   172: invokevirtual d : (Ljava/lang/String;)Ljava/io/File;
    //   175: invokevirtual put : (Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    //   178: pop
    //   179: aload #8
    //   181: invokevirtual s : ()V
    //   184: iload_1
    //   185: iconst_1
    //   186: iadd
    //   187: istore_1
    //   188: goto -> 84
    //   191: astore #4
    //   193: ldc 'CBRequestManager'
    //   195: ldc_w 'Error executing saved requests'
    //   198: aload #4
    //   200: invokestatic b : (Ljava/lang/Object;Ljava/lang/String;Ljava/lang/Throwable;)V
    //   203: aload_0
    //   204: monitorexit
    //   205: return
    //   206: astore #4
    //   208: aload_0
    //   209: monitorexit
    //   210: aload #4
    //   212: athrow
    //   213: getstatic com/chartboost/sdk/impl/ba.f : Ljava/util/concurrent/ConcurrentHashMap;
    //   216: invokevirtual keySet : ()Ljava/util/Set;
    //   219: invokeinterface iterator : ()Ljava/util/Iterator;
    //   224: astore #4
    //   226: aload #4
    //   228: invokeinterface hasNext : ()Z
    //   233: ifeq -> 203
    //   236: aload #4
    //   238: invokeinterface next : ()Ljava/lang/Object;
    //   243: checkcast com/chartboost/sdk/impl/az
    //   246: astore #5
    //   248: aload #5
    //   250: ifnull -> 226
    //   253: aload #5
    //   255: invokevirtual q : ()Z
    //   258: ifne -> 226
    //   261: aload #5
    //   263: aload #5
    //   265: invokevirtual o : ()I
    //   268: iconst_1
    //   269: iadd
    //   270: invokevirtual a : (I)V
    //   273: aload #5
    //   275: aload #5
    //   277: invokevirtual r : ()Lcom/chartboost/sdk/impl/az$c;
    //   280: invokevirtual a : (Lcom/chartboost/sdk/impl/az$c;)V
    //   283: goto -> 226
    //   286: aconst_null
    //   287: astore #4
    //   289: goto -> 73
    // Exception table:
    //   from	to	target	type
    //   43	50	206	finally
    //   54	61	191	java/lang/Exception
    //   54	61	206	finally
    //   66	73	191	java/lang/Exception
    //   66	73	206	finally
    //   78	82	191	java/lang/Exception
    //   78	82	206	finally
    //   95	184	191	java/lang/Exception
    //   95	184	206	finally
    //   193	203	206	finally
    //   203	205	206	finally
    //   208	210	206	finally
    //   213	226	206	finally
    //   226	248	206	finally
    //   253	283	206	finally
  }
  
  public void f() {
    if (this.i == null)
      this.i = (new CountDownTimer(this, 240000L, 1000L) {
          public void onFinish() {
            this.a.c();
          }
          
          public void onTick(long param1Long) {}
        }).start(); 
  }
  
  public void g() {
    CBLogging.a("CBRequestManager", "Timer stopped:");
    if (this.i != null) {
      this.i.cancel();
      this.i = null;
    } 
  }
  
  public ConcurrentHashMap<az, File> i() {
    return e;
  }
  
  public h j() {
    return this.d;
  }
  
  public void update(Observable paramObservable, Object paramObject) {
    if (this.i != null)
      g(); 
    c();
  }
  
  public enum a {
    a;
  }
  
  private class b {
    private String b = null;
    
    private int c = 50;
    
    private String d = Long.toString(System.nanoTime());
    
    private ba.a e = ba.a.a;
    
    private boolean f = false;
    
    private JSONArray g = null;
    
    private az h;
    
    public b(ba this$0) {
      this.g = new JSONArray();
    }
    
    public az a(az param1az) {
      // Byte code:
      //   0: aload_0
      //   1: monitorenter
      //   2: aload_1
      //   3: invokevirtual i : ()Lcom/chartboost/sdk/Libraries/e$a;
      //   6: astore #4
      //   8: aload_1
      //   9: astore_3
      //   10: aload #4
      //   12: invokevirtual c : ()Z
      //   15: ifeq -> 41
      //   18: aload #4
      //   20: aload_0
      //   21: getfield b : Ljava/lang/String;
      //   24: invokevirtual a : (Ljava/lang/String;)Lcom/chartboost/sdk/Libraries/e$a;
      //   27: astore #4
      //   29: aload #4
      //   31: invokevirtual b : ()Z
      //   34: istore_2
      //   35: iload_2
      //   36: ifeq -> 45
      //   39: aload_1
      //   40: astore_3
      //   41: aload_0
      //   42: monitorexit
      //   43: aload_3
      //   44: areturn
      //   45: aload_1
      //   46: astore_3
      //   47: aload_0
      //   48: getfield e : Lcom/chartboost/sdk/impl/ba$a;
      //   51: getstatic com/chartboost/sdk/impl/ba$a.a : Lcom/chartboost/sdk/impl/ba$a;
      //   54: if_acmpne -> 41
      //   57: aload_0
      //   58: getfield a : Lcom/chartboost/sdk/impl/ba;
      //   61: invokestatic d : (Lcom/chartboost/sdk/impl/ba;)Lcom/chartboost/sdk/impl/ay;
      //   64: invokevirtual c : ()Z
      //   67: ifne -> 87
      //   70: aload_0
      //   71: getfield h : Lcom/chartboost/sdk/impl/az;
      //   74: ifnull -> 130
      //   77: aload_0
      //   78: getfield h : Lcom/chartboost/sdk/impl/az;
      //   81: invokevirtual q : ()Z
      //   84: ifeq -> 130
      //   87: aload_0
      //   88: invokestatic nanoTime : ()J
      //   91: invokestatic toString : (J)Ljava/lang/String;
      //   94: putfield d : Ljava/lang/String;
      //   97: aload_1
      //   98: aload_0
      //   99: getfield b : Ljava/lang/String;
      //   102: new org/json/JSONArray
      //   105: dup
      //   106: invokespecial <init> : ()V
      //   109: aload #4
      //   111: invokevirtual e : ()Lorg/json/JSONObject;
      //   114: invokevirtual put : (Ljava/lang/Object;)Lorg/json/JSONArray;
      //   117: invokevirtual a : (Ljava/lang/String;Ljava/lang/Object;)V
      //   120: aload_1
      //   121: astore_3
      //   122: goto -> 41
      //   125: astore_1
      //   126: aload_0
      //   127: monitorexit
      //   128: aload_1
      //   129: athrow
      //   130: aload_0
      //   131: getfield g : Lorg/json/JSONArray;
      //   134: invokevirtual length : ()I
      //   137: aload_0
      //   138: getfield c : I
      //   141: if_icmpne -> 165
      //   144: aload_0
      //   145: invokestatic nanoTime : ()J
      //   148: invokestatic toString : (J)Ljava/lang/String;
      //   151: putfield d : Ljava/lang/String;
      //   154: aload_0
      //   155: new org/json/JSONArray
      //   158: dup
      //   159: invokespecial <init> : ()V
      //   162: putfield g : Lorg/json/JSONArray;
      //   165: aload_0
      //   166: getfield g : Lorg/json/JSONArray;
      //   169: aload #4
      //   171: invokevirtual e : ()Lorg/json/JSONObject;
      //   174: invokevirtual put : (Ljava/lang/Object;)Lorg/json/JSONArray;
      //   177: pop
      //   178: aload_0
      //   179: getfield h : Lcom/chartboost/sdk/impl/az;
      //   182: ifnull -> 196
      //   185: invokestatic k : ()Ljava/util/concurrent/ConcurrentHashMap;
      //   188: aload_0
      //   189: getfield h : Lcom/chartboost/sdk/impl/az;
      //   192: invokevirtual remove : (Ljava/lang/Object;)Ljava/lang/Object;
      //   195: pop
      //   196: aload_1
      //   197: aload_0
      //   198: getfield b : Ljava/lang/String;
      //   201: aload_0
      //   202: getfield g : Lorg/json/JSONArray;
      //   205: invokevirtual a : (Ljava/lang/String;Ljava/lang/Object;)V
      //   208: aload_0
      //   209: aload_1
      //   210: putfield h : Lcom/chartboost/sdk/impl/az;
      //   213: aload_0
      //   214: getfield h : Lcom/chartboost/sdk/impl/az;
      //   217: astore_3
      //   218: goto -> 41
      // Exception table:
      //   from	to	target	type
      //   2	8	125	finally
      //   10	35	125	finally
      //   47	87	125	finally
      //   87	120	125	finally
      //   130	165	125	finally
      //   165	196	125	finally
      //   196	218	125	finally
    }
    
    public String a() {
      return this.d;
    }
    
    public void a(String param1String) {
      this.b = param1String;
    }
    
    public void a(boolean param1Boolean) {
      this.f = param1Boolean;
    }
    
    public String b() {
      return this.b;
    }
    
    public void b(az param1az) {
      this.h = param1az;
    }
    
    public boolean c() {
      return this.f;
    }
    
    public void d() {
      this.g = new JSONArray();
    }
  }
  
  public static class c extends s {
    private CBError b;
    
    public c(CBError param1CBError) {
      this.b = param1CBError;
    }
  }
  
  public static class d {
    private com.chartboost.sdk.Libraries.e.a a;
    
    private i b;
    
    public d(com.chartboost.sdk.Libraries.e.a param1a, i param1i) {
      this.a = param1a;
      this.b = param1i;
    }
  }
  
  private class e implements Runnable {
    private az b;
    
    public e(ba this$0, az param1az) {
      this.b = param1az;
    }
    
    public void run() {
      this.b.a(com.chartboost.sdk.b.x());
      this.b.c();
      String str = String.format("%s%s", new Object[] { "https://live.chartboost.com", this.b.e() });
      this.b.d();
      this.b.a();
      a a = new a(this, 1, str, this.b);
      a.a(new d(30000, 0, 0.0F));
      ba.a(this.a).a(a);
    }
    
    private class a extends l<ba.d> {
      private az b;
      
      public a(ba.e this$0, int param2Int, String param2String, az param2az) {
        super(param2Int, param2String, null);
        this.b = param2az;
      }
      
      protected n<ba.d> a(i param2i) {
        // Byte code:
        //   0: aload_1
        //   1: getfield a : I
        //   4: istore_2
        //   5: iload_2
        //   6: sipush #300
        //   9: if_icmple -> 122
        //   12: iload_2
        //   13: sipush #200
        //   16: if_icmpge -> 122
        //   19: ldc 'CBRequestManager'
        //   21: new java/lang/StringBuilder
        //   24: dup
        //   25: invokespecial <init> : ()V
        //   28: ldc 'Request '
        //   30: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
        //   33: aload_0
        //   34: getfield b : Lcom/chartboost/sdk/impl/az;
        //   37: invokevirtual g : ()Ljava/lang/String;
        //   40: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
        //   43: ldc ' failed. Response code: '
        //   45: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
        //   48: iload_2
        //   49: invokevirtual append : (I)Ljava/lang/StringBuilder;
        //   52: invokevirtual toString : ()Ljava/lang/String;
        //   55: invokestatic d : (Ljava/lang/Object;Ljava/lang/String;)V
        //   58: new com/chartboost/sdk/Model/CBError
        //   61: dup
        //   62: getstatic com/chartboost/sdk/Model/CBError$a.e : Lcom/chartboost/sdk/Model/CBError$a;
        //   65: new java/lang/StringBuilder
        //   68: dup
        //   69: invokespecial <init> : ()V
        //   72: ldc 'Request failed. Response code: '
        //   74: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
        //   77: iload_2
        //   78: invokevirtual append : (I)Ljava/lang/StringBuilder;
        //   81: ldc ' is not valid '
        //   83: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
        //   86: invokevirtual toString : ()Ljava/lang/String;
        //   89: invokespecial <init> : (Lcom/chartboost/sdk/Model/CBError$a;Ljava/lang/String;)V
        //   92: astore #4
        //   94: aconst_null
        //   95: astore_3
        //   96: aload_3
        //   97: ifnull -> 366
        //   100: aload #4
        //   102: ifnonnull -> 366
        //   105: new com/chartboost/sdk/impl/ba$d
        //   108: dup
        //   109: aload_3
        //   110: invokestatic a : (Ljava/lang/Object;)Lcom/chartboost/sdk/Libraries/e$a;
        //   113: aload_1
        //   114: invokespecial <init> : (Lcom/chartboost/sdk/Libraries/e$a;Lcom/chartboost/sdk/impl/i;)V
        //   117: aconst_null
        //   118: invokestatic a : (Ljava/lang/Object;Lcom/chartboost/sdk/impl/b$a;)Lcom/chartboost/sdk/impl/n;
        //   121: areturn
        //   122: aload_1
        //   123: getfield b : [B
        //   126: astore_3
        //   127: aload_3
        //   128: ifnull -> 391
        //   131: new java/lang/String
        //   134: dup
        //   135: aload_3
        //   136: invokespecial <init> : ([B)V
        //   139: astore_3
        //   140: aload_3
        //   141: ifnull -> 347
        //   144: new org/json/JSONObject
        //   147: dup
        //   148: new org/json/JSONTokener
        //   151: dup
        //   152: aload_3
        //   153: invokespecial <init> : (Ljava/lang/String;)V
        //   156: invokespecial <init> : (Lorg/json/JSONTokener;)V
        //   159: invokestatic a : (Ljava/lang/Object;)Lcom/chartboost/sdk/Libraries/e$a;
        //   162: astore #4
        //   164: aload_0
        //   165: getfield b : Lcom/chartboost/sdk/impl/az;
        //   168: invokevirtual l : ()Lcom/chartboost/sdk/Libraries/g$a;
        //   171: astore #5
        //   173: ldc 'CBRequestManager'
        //   175: new java/lang/StringBuilder
        //   178: dup
        //   179: invokespecial <init> : ()V
        //   182: ldc 'Request '
        //   184: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
        //   187: aload_0
        //   188: getfield b : Lcom/chartboost/sdk/impl/az;
        //   191: invokevirtual g : ()Ljava/lang/String;
        //   194: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
        //   197: ldc ' succeeded. Response code: '
        //   199: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
        //   202: iload_2
        //   203: invokevirtual append : (I)Ljava/lang/StringBuilder;
        //   206: ldc ', body: '
        //   208: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
        //   211: aload_3
        //   212: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
        //   215: invokevirtual toString : ()Ljava/lang/String;
        //   218: invokestatic c : (Ljava/lang/Object;Ljava/lang/String;)V
        //   221: aload #4
        //   223: ldc 'status'
        //   225: invokevirtual f : (Ljava/lang/String;)I
        //   228: sipush #404
        //   231: if_icmpne -> 250
        //   234: new com/chartboost/sdk/Model/CBError
        //   237: dup
        //   238: getstatic com/chartboost/sdk/Model/CBError$a.g : Lcom/chartboost/sdk/Model/CBError$a;
        //   241: ldc '404 error from server'
        //   243: invokespecial <init> : (Lcom/chartboost/sdk/Model/CBError$a;Ljava/lang/String;)V
        //   246: astore_3
        //   247: goto -> 396
        //   250: new java/lang/StringBuilder
        //   253: dup
        //   254: invokespecial <init> : ()V
        //   257: astore #6
        //   259: aload #5
        //   261: ifnull -> 386
        //   264: aload #5
        //   266: aload #4
        //   268: aload #6
        //   270: invokevirtual a : (Ljava/lang/Object;Ljava/lang/StringBuilder;)Z
        //   273: ifne -> 386
        //   276: new com/chartboost/sdk/Model/CBError
        //   279: dup
        //   280: getstatic com/chartboost/sdk/Model/CBError$a.d : Lcom/chartboost/sdk/Model/CBError$a;
        //   283: ldc 'Json response failed validation'
        //   285: invokespecial <init> : (Lcom/chartboost/sdk/Model/CBError$a;Ljava/lang/String;)V
        //   288: astore_3
        //   289: ldc 'CBRequestManager'
        //   291: new java/lang/StringBuilder
        //   294: dup
        //   295: invokespecial <init> : ()V
        //   298: ldc 'Json response failed validation: '
        //   300: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
        //   303: aload #6
        //   305: invokevirtual toString : ()Ljava/lang/String;
        //   308: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
        //   311: invokevirtual toString : ()Ljava/lang/String;
        //   314: invokestatic b : (Ljava/lang/Object;Ljava/lang/String;)V
        //   317: goto -> 396
        //   320: astore_3
        //   321: new com/chartboost/sdk/Model/CBError
        //   324: dup
        //   325: getstatic com/chartboost/sdk/Model/CBError$a.a : Lcom/chartboost/sdk/Model/CBError$a;
        //   328: aload_3
        //   329: invokevirtual getLocalizedMessage : ()Ljava/lang/String;
        //   332: invokespecial <init> : (Lcom/chartboost/sdk/Model/CBError$a;Ljava/lang/String;)V
        //   335: astore #5
        //   337: aload #4
        //   339: astore_3
        //   340: aload #5
        //   342: astore #4
        //   344: goto -> 96
        //   347: new com/chartboost/sdk/Model/CBError
        //   350: dup
        //   351: getstatic com/chartboost/sdk/Model/CBError$a.c : Lcom/chartboost/sdk/Model/CBError$a;
        //   354: ldc 'Response is not a valid json object'
        //   356: invokespecial <init> : (Lcom/chartboost/sdk/Model/CBError$a;Ljava/lang/String;)V
        //   359: astore #4
        //   361: aconst_null
        //   362: astore_3
        //   363: goto -> 96
        //   366: new com/chartboost/sdk/impl/ba$c
        //   369: dup
        //   370: aload #4
        //   372: invokespecial <init> : (Lcom/chartboost/sdk/Model/CBError;)V
        //   375: invokestatic a : (Lcom/chartboost/sdk/impl/s;)Lcom/chartboost/sdk/impl/n;
        //   378: areturn
        //   379: astore_3
        //   380: aconst_null
        //   381: astore #4
        //   383: goto -> 321
        //   386: aconst_null
        //   387: astore_3
        //   388: goto -> 396
        //   391: aconst_null
        //   392: astore_3
        //   393: goto -> 140
        //   396: aload_3
        //   397: astore #5
        //   399: aload #4
        //   401: astore_3
        //   402: aload #5
        //   404: astore #4
        //   406: goto -> 96
        // Exception table:
        //   from	to	target	type
        //   122	127	379	java/lang/Exception
        //   131	140	379	java/lang/Exception
        //   144	164	379	java/lang/Exception
        //   164	247	320	java/lang/Exception
        //   250	259	320	java/lang/Exception
        //   264	317	320	java/lang/Exception
        //   347	361	379	java/lang/Exception
      }
      
      protected void a(ba.d param2d) {
        if (ba.e.a(this.a).r() != null && param2d != null)
          ba.e.a(this.a).r().a(ba.d.a(param2d), ba.e.a(this.a)); 
        if (!ba.e.a(this.a).h()) {
          ba.b(this.a.a).c((File)ba.k().get(ba.e.a(this.a)));
          ba.k().remove(ba.e.a(this.a));
          ba.b b = (ba.b)ba.c(this.a.a).get(ba.e.a(this.a).g());
          if (b != null && !TextUtils.isEmpty(b.b()) && b.c() && ba.b.a(b) == ba.e.a(this.a)) {
            b.d();
            b.b(null);
          } 
          ba.e.a(this.a).d(false);
          ba.a(this.a.a, ba.e.a(this.a), ba.d.b(param2d), null, true);
          return;
        } 
        com.chartboost.sdk.Tracking.a.a().l().c((File)ba.l().get(ba.e.a(this.a)));
        com.chartboost.sdk.Tracking.a.a().p();
        CBLogging.a("CBRequestManager", "### Removing track events sent to server...");
        ba.l().remove(ba.e.a(this.a));
      }
      
      public void b(s param2s) {
        // Byte code:
        //   0: aload_0
        //   1: getfield a : Lcom/chartboost/sdk/impl/ba$e;
        //   4: invokestatic a : (Lcom/chartboost/sdk/impl/ba$e;)Lcom/chartboost/sdk/impl/az;
        //   7: ifnull -> 88
        //   10: invokestatic k : ()Z
        //   13: ifne -> 88
        //   16: aload_0
        //   17: getfield a : Lcom/chartboost/sdk/impl/ba$e;
        //   20: invokestatic a : (Lcom/chartboost/sdk/impl/ba$e;)Lcom/chartboost/sdk/impl/az;
        //   23: invokevirtual h : ()Z
        //   26: ifne -> 93
        //   29: invokestatic k : ()Ljava/util/concurrent/ConcurrentHashMap;
        //   32: aload_0
        //   33: getfield a : Lcom/chartboost/sdk/impl/ba$e;
        //   36: invokestatic a : (Lcom/chartboost/sdk/impl/ba$e;)Lcom/chartboost/sdk/impl/az;
        //   39: invokevirtual containsKey : (Ljava/lang/Object;)Z
        //   42: ifeq -> 93
        //   45: aload_0
        //   46: getfield a : Lcom/chartboost/sdk/impl/ba$e;
        //   49: getfield a : Lcom/chartboost/sdk/impl/ba;
        //   52: invokestatic b : (Lcom/chartboost/sdk/impl/ba;)Lcom/chartboost/sdk/Libraries/h;
        //   55: invokestatic k : ()Ljava/util/concurrent/ConcurrentHashMap;
        //   58: aload_0
        //   59: getfield a : Lcom/chartboost/sdk/impl/ba$e;
        //   62: invokestatic a : (Lcom/chartboost/sdk/impl/ba$e;)Lcom/chartboost/sdk/impl/az;
        //   65: invokevirtual get : (Ljava/lang/Object;)Ljava/lang/Object;
        //   68: checkcast java/io/File
        //   71: invokevirtual c : (Ljava/io/File;)V
        //   74: invokestatic k : ()Ljava/util/concurrent/ConcurrentHashMap;
        //   77: aload_0
        //   78: getfield a : Lcom/chartboost/sdk/impl/ba$e;
        //   81: invokestatic a : (Lcom/chartboost/sdk/impl/ba$e;)Lcom/chartboost/sdk/impl/az;
        //   84: invokevirtual remove : (Ljava/lang/Object;)Ljava/lang/Object;
        //   87: pop
        //   88: aload_1
        //   89: ifnonnull -> 160
        //   92: return
        //   93: invokestatic l : ()Ljava/util/concurrent/ConcurrentHashMap;
        //   96: invokevirtual isEmpty : ()Z
        //   99: ifne -> 88
        //   102: invokestatic l : ()Ljava/util/concurrent/ConcurrentHashMap;
        //   105: aload_0
        //   106: getfield a : Lcom/chartboost/sdk/impl/ba$e;
        //   109: invokestatic a : (Lcom/chartboost/sdk/impl/ba$e;)Lcom/chartboost/sdk/impl/az;
        //   112: invokevirtual containsKey : (Ljava/lang/Object;)Z
        //   115: ifeq -> 88
        //   118: invokestatic a : ()Lcom/chartboost/sdk/Tracking/a;
        //   121: invokevirtual l : ()Lcom/chartboost/sdk/Libraries/h;
        //   124: invokestatic l : ()Ljava/util/concurrent/ConcurrentHashMap;
        //   127: aload_0
        //   128: getfield a : Lcom/chartboost/sdk/impl/ba$e;
        //   131: invokestatic a : (Lcom/chartboost/sdk/impl/ba$e;)Lcom/chartboost/sdk/impl/az;
        //   134: invokevirtual get : (Ljava/lang/Object;)Ljava/lang/Object;
        //   137: checkcast java/io/File
        //   140: invokevirtual c : (Ljava/io/File;)V
        //   143: invokestatic l : ()Ljava/util/concurrent/ConcurrentHashMap;
        //   146: aload_0
        //   147: getfield a : Lcom/chartboost/sdk/impl/ba$e;
        //   150: invokestatic a : (Lcom/chartboost/sdk/impl/ba$e;)Lcom/chartboost/sdk/impl/az;
        //   153: invokevirtual remove : (Ljava/lang/Object;)Ljava/lang/Object;
        //   156: pop
        //   157: goto -> 88
        //   160: aload_1
        //   161: instanceof com/chartboost/sdk/impl/ba$c
        //   164: ifeq -> 279
        //   167: aload_1
        //   168: checkcast com/chartboost/sdk/impl/ba$c
        //   171: invokestatic a : (Lcom/chartboost/sdk/impl/ba$c;)Lcom/chartboost/sdk/Model/CBError;
        //   174: astore_2
        //   175: getstatic com/chartboost/sdk/Libraries/e$a.a : Lcom/chartboost/sdk/Libraries/e$a;
        //   178: astore #4
        //   180: aload #4
        //   182: astore_3
        //   183: aload_1
        //   184: ifnull -> 242
        //   187: aload #4
        //   189: astore_3
        //   190: aload_1
        //   191: getfield a : Lcom/chartboost/sdk/impl/i;
        //   194: ifnull -> 242
        //   197: aload #4
        //   199: astore_3
        //   200: aload_1
        //   201: getfield a : Lcom/chartboost/sdk/impl/i;
        //   204: getfield b : [B
        //   207: ifnull -> 242
        //   210: aload #4
        //   212: astore_3
        //   213: aload_1
        //   214: getfield a : Lcom/chartboost/sdk/impl/i;
        //   217: getfield b : [B
        //   220: arraylength
        //   221: ifle -> 242
        //   224: new java/lang/String
        //   227: dup
        //   228: aload_1
        //   229: getfield a : Lcom/chartboost/sdk/impl/i;
        //   232: getfield b : [B
        //   235: invokespecial <init> : ([B)V
        //   238: invokestatic j : (Ljava/lang/String;)Lcom/chartboost/sdk/Libraries/e$a;
        //   241: astore_3
        //   242: aload_1
        //   243: getfield a : Lcom/chartboost/sdk/impl/i;
        //   246: ifnull -> 313
        //   249: aload_1
        //   250: getfield a : Lcom/chartboost/sdk/impl/i;
        //   253: getfield a : I
        //   256: sipush #200
        //   259: if_icmpne -> 313
        //   262: aload_0
        //   263: new com/chartboost/sdk/impl/ba$d
        //   266: dup
        //   267: aload_3
        //   268: aload_1
        //   269: getfield a : Lcom/chartboost/sdk/impl/i;
        //   272: invokespecial <init> : (Lcom/chartboost/sdk/Libraries/e$a;Lcom/chartboost/sdk/impl/i;)V
        //   275: invokevirtual a : (Lcom/chartboost/sdk/impl/ba$d;)V
        //   278: return
        //   279: new com/chartboost/sdk/Model/CBError
        //   282: dup
        //   283: getstatic com/chartboost/sdk/Model/CBError$a.e : Lcom/chartboost/sdk/Model/CBError$a;
        //   286: aload_1
        //   287: invokevirtual getMessage : ()Ljava/lang/String;
        //   290: invokespecial <init> : (Lcom/chartboost/sdk/Model/CBError$a;Ljava/lang/String;)V
        //   293: astore_2
        //   294: goto -> 175
        //   297: astore_3
        //   298: ldc 'CBRequestManager'
        //   300: ldc_w 'unable to read error json'
        //   303: aload_3
        //   304: invokestatic d : (Ljava/lang/Object;Ljava/lang/String;Ljava/lang/Throwable;)V
        //   307: aload #4
        //   309: astore_3
        //   310: goto -> 242
        //   313: aload_0
        //   314: getfield a : Lcom/chartboost/sdk/impl/ba$e;
        //   317: invokestatic a : (Lcom/chartboost/sdk/impl/ba$e;)Lcom/chartboost/sdk/impl/az;
        //   320: invokevirtual r : ()Lcom/chartboost/sdk/impl/az$c;
        //   323: ifnull -> 350
        //   326: aload_0
        //   327: getfield a : Lcom/chartboost/sdk/impl/ba$e;
        //   330: invokestatic a : (Lcom/chartboost/sdk/impl/ba$e;)Lcom/chartboost/sdk/impl/az;
        //   333: invokevirtual r : ()Lcom/chartboost/sdk/impl/az$c;
        //   336: aload_3
        //   337: aload_0
        //   338: getfield a : Lcom/chartboost/sdk/impl/ba$e;
        //   341: invokestatic a : (Lcom/chartboost/sdk/impl/ba$e;)Lcom/chartboost/sdk/impl/az;
        //   344: aload_2
        //   345: invokeinterface a : (Lcom/chartboost/sdk/Libraries/e$a;Lcom/chartboost/sdk/impl/az;Lcom/chartboost/sdk/Model/CBError;)V
        //   350: aload_0
        //   351: getfield a : Lcom/chartboost/sdk/impl/ba$e;
        //   354: invokestatic a : (Lcom/chartboost/sdk/impl/ba$e;)Lcom/chartboost/sdk/impl/az;
        //   357: invokevirtual h : ()Z
        //   360: ifne -> 398
        //   363: aload_0
        //   364: getfield a : Lcom/chartboost/sdk/impl/ba$e;
        //   367: invokestatic a : (Lcom/chartboost/sdk/impl/ba$e;)Lcom/chartboost/sdk/impl/az;
        //   370: iconst_0
        //   371: invokevirtual d : (Z)V
        //   374: aload_0
        //   375: getfield a : Lcom/chartboost/sdk/impl/ba$e;
        //   378: getfield a : Lcom/chartboost/sdk/impl/ba;
        //   381: aload_0
        //   382: getfield a : Lcom/chartboost/sdk/impl/ba$e;
        //   385: invokestatic a : (Lcom/chartboost/sdk/impl/ba$e;)Lcom/chartboost/sdk/impl/az;
        //   388: aload_1
        //   389: getfield a : Lcom/chartboost/sdk/impl/i;
        //   392: aload_2
        //   393: iconst_0
        //   394: invokestatic a : (Lcom/chartboost/sdk/impl/ba;Lcom/chartboost/sdk/impl/az;Lcom/chartboost/sdk/impl/i;Lcom/chartboost/sdk/Model/CBError;Z)V
        //   397: return
        //   398: invokestatic l : ()Ljava/util/concurrent/ConcurrentHashMap;
        //   401: aload_0
        //   402: getfield a : Lcom/chartboost/sdk/impl/ba$e;
        //   405: invokestatic a : (Lcom/chartboost/sdk/impl/ba$e;)Lcom/chartboost/sdk/impl/az;
        //   408: invokevirtual remove : (Ljava/lang/Object;)Ljava/lang/Object;
        //   411: pop
        //   412: return
        // Exception table:
        //   from	to	target	type
        //   190	197	297	java/lang/Exception
        //   200	210	297	java/lang/Exception
        //   213	242	297	java/lang/Exception
      }
      
      public Map<String, String> i() throws a {
        HashMap<Object, Object> hashMap = new HashMap<Object, Object>();
        for (Map.Entry<String, Object> entry : this.b.j().entrySet()) {
          Object object = entry.getKey();
          if (entry.getValue() != null) {
            String str = entry.getValue().toString();
          } else {
            entry = null;
          } 
          hashMap.put(object, entry);
        } 
        return (Map)hashMap;
      }
      
      public String p() {
        String str2 = this.b.b();
        String str1 = str2;
        if (str2 == null)
          str1 = "application/json; charset=utf-8"; 
        return str1;
      }
      
      public byte[] q() {
        if (this.b.i() == null) {
          String str1 = "";
          return str1.getBytes();
        } 
        String str = this.b.i().toString();
        return str.getBytes();
      }
      
      public l.a s() {
        return this.b.n();
      }
    }
  }
  
  private class a extends l<d> {
    private az b;
    
    public a(ba this$0, int param1Int, String param1String, az param1az) {
      super(param1Int, param1String, null);
      this.b = param1az;
    }
    
    protected n<ba.d> a(i param1i) {
      // Byte code:
      //   0: aload_1
      //   1: getfield a : I
      //   4: istore_2
      //   5: iload_2
      //   6: sipush #300
      //   9: if_icmple -> 122
      //   12: iload_2
      //   13: sipush #200
      //   16: if_icmpge -> 122
      //   19: ldc 'CBRequestManager'
      //   21: new java/lang/StringBuilder
      //   24: dup
      //   25: invokespecial <init> : ()V
      //   28: ldc 'Request '
      //   30: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
      //   33: aload_0
      //   34: getfield b : Lcom/chartboost/sdk/impl/az;
      //   37: invokevirtual g : ()Ljava/lang/String;
      //   40: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
      //   43: ldc ' failed. Response code: '
      //   45: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
      //   48: iload_2
      //   49: invokevirtual append : (I)Ljava/lang/StringBuilder;
      //   52: invokevirtual toString : ()Ljava/lang/String;
      //   55: invokestatic d : (Ljava/lang/Object;Ljava/lang/String;)V
      //   58: new com/chartboost/sdk/Model/CBError
      //   61: dup
      //   62: getstatic com/chartboost/sdk/Model/CBError$a.e : Lcom/chartboost/sdk/Model/CBError$a;
      //   65: new java/lang/StringBuilder
      //   68: dup
      //   69: invokespecial <init> : ()V
      //   72: ldc 'Request failed. Response code: '
      //   74: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
      //   77: iload_2
      //   78: invokevirtual append : (I)Ljava/lang/StringBuilder;
      //   81: ldc ' is not valid '
      //   83: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
      //   86: invokevirtual toString : ()Ljava/lang/String;
      //   89: invokespecial <init> : (Lcom/chartboost/sdk/Model/CBError$a;Ljava/lang/String;)V
      //   92: astore #4
      //   94: aconst_null
      //   95: astore_3
      //   96: aload_3
      //   97: ifnull -> 366
      //   100: aload #4
      //   102: ifnonnull -> 366
      //   105: new com/chartboost/sdk/impl/ba$d
      //   108: dup
      //   109: aload_3
      //   110: invokestatic a : (Ljava/lang/Object;)Lcom/chartboost/sdk/Libraries/e$a;
      //   113: aload_1
      //   114: invokespecial <init> : (Lcom/chartboost/sdk/Libraries/e$a;Lcom/chartboost/sdk/impl/i;)V
      //   117: aconst_null
      //   118: invokestatic a : (Ljava/lang/Object;Lcom/chartboost/sdk/impl/b$a;)Lcom/chartboost/sdk/impl/n;
      //   121: areturn
      //   122: aload_1
      //   123: getfield b : [B
      //   126: astore_3
      //   127: aload_3
      //   128: ifnull -> 391
      //   131: new java/lang/String
      //   134: dup
      //   135: aload_3
      //   136: invokespecial <init> : ([B)V
      //   139: astore_3
      //   140: aload_3
      //   141: ifnull -> 347
      //   144: new org/json/JSONObject
      //   147: dup
      //   148: new org/json/JSONTokener
      //   151: dup
      //   152: aload_3
      //   153: invokespecial <init> : (Ljava/lang/String;)V
      //   156: invokespecial <init> : (Lorg/json/JSONTokener;)V
      //   159: invokestatic a : (Ljava/lang/Object;)Lcom/chartboost/sdk/Libraries/e$a;
      //   162: astore #4
      //   164: aload_0
      //   165: getfield b : Lcom/chartboost/sdk/impl/az;
      //   168: invokevirtual l : ()Lcom/chartboost/sdk/Libraries/g$a;
      //   171: astore #5
      //   173: ldc 'CBRequestManager'
      //   175: new java/lang/StringBuilder
      //   178: dup
      //   179: invokespecial <init> : ()V
      //   182: ldc 'Request '
      //   184: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
      //   187: aload_0
      //   188: getfield b : Lcom/chartboost/sdk/impl/az;
      //   191: invokevirtual g : ()Ljava/lang/String;
      //   194: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
      //   197: ldc ' succeeded. Response code: '
      //   199: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
      //   202: iload_2
      //   203: invokevirtual append : (I)Ljava/lang/StringBuilder;
      //   206: ldc ', body: '
      //   208: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
      //   211: aload_3
      //   212: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
      //   215: invokevirtual toString : ()Ljava/lang/String;
      //   218: invokestatic c : (Ljava/lang/Object;Ljava/lang/String;)V
      //   221: aload #4
      //   223: ldc 'status'
      //   225: invokevirtual f : (Ljava/lang/String;)I
      //   228: sipush #404
      //   231: if_icmpne -> 250
      //   234: new com/chartboost/sdk/Model/CBError
      //   237: dup
      //   238: getstatic com/chartboost/sdk/Model/CBError$a.g : Lcom/chartboost/sdk/Model/CBError$a;
      //   241: ldc '404 error from server'
      //   243: invokespecial <init> : (Lcom/chartboost/sdk/Model/CBError$a;Ljava/lang/String;)V
      //   246: astore_3
      //   247: goto -> 396
      //   250: new java/lang/StringBuilder
      //   253: dup
      //   254: invokespecial <init> : ()V
      //   257: astore #6
      //   259: aload #5
      //   261: ifnull -> 386
      //   264: aload #5
      //   266: aload #4
      //   268: aload #6
      //   270: invokevirtual a : (Ljava/lang/Object;Ljava/lang/StringBuilder;)Z
      //   273: ifne -> 386
      //   276: new com/chartboost/sdk/Model/CBError
      //   279: dup
      //   280: getstatic com/chartboost/sdk/Model/CBError$a.d : Lcom/chartboost/sdk/Model/CBError$a;
      //   283: ldc 'Json response failed validation'
      //   285: invokespecial <init> : (Lcom/chartboost/sdk/Model/CBError$a;Ljava/lang/String;)V
      //   288: astore_3
      //   289: ldc 'CBRequestManager'
      //   291: new java/lang/StringBuilder
      //   294: dup
      //   295: invokespecial <init> : ()V
      //   298: ldc 'Json response failed validation: '
      //   300: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
      //   303: aload #6
      //   305: invokevirtual toString : ()Ljava/lang/String;
      //   308: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
      //   311: invokevirtual toString : ()Ljava/lang/String;
      //   314: invokestatic b : (Ljava/lang/Object;Ljava/lang/String;)V
      //   317: goto -> 396
      //   320: astore_3
      //   321: new com/chartboost/sdk/Model/CBError
      //   324: dup
      //   325: getstatic com/chartboost/sdk/Model/CBError$a.a : Lcom/chartboost/sdk/Model/CBError$a;
      //   328: aload_3
      //   329: invokevirtual getLocalizedMessage : ()Ljava/lang/String;
      //   332: invokespecial <init> : (Lcom/chartboost/sdk/Model/CBError$a;Ljava/lang/String;)V
      //   335: astore #5
      //   337: aload #4
      //   339: astore_3
      //   340: aload #5
      //   342: astore #4
      //   344: goto -> 96
      //   347: new com/chartboost/sdk/Model/CBError
      //   350: dup
      //   351: getstatic com/chartboost/sdk/Model/CBError$a.c : Lcom/chartboost/sdk/Model/CBError$a;
      //   354: ldc 'Response is not a valid json object'
      //   356: invokespecial <init> : (Lcom/chartboost/sdk/Model/CBError$a;Ljava/lang/String;)V
      //   359: astore #4
      //   361: aconst_null
      //   362: astore_3
      //   363: goto -> 96
      //   366: new com/chartboost/sdk/impl/ba$c
      //   369: dup
      //   370: aload #4
      //   372: invokespecial <init> : (Lcom/chartboost/sdk/Model/CBError;)V
      //   375: invokestatic a : (Lcom/chartboost/sdk/impl/s;)Lcom/chartboost/sdk/impl/n;
      //   378: areturn
      //   379: astore_3
      //   380: aconst_null
      //   381: astore #4
      //   383: goto -> 321
      //   386: aconst_null
      //   387: astore_3
      //   388: goto -> 396
      //   391: aconst_null
      //   392: astore_3
      //   393: goto -> 140
      //   396: aload_3
      //   397: astore #5
      //   399: aload #4
      //   401: astore_3
      //   402: aload #5
      //   404: astore #4
      //   406: goto -> 96
      // Exception table:
      //   from	to	target	type
      //   122	127	379	java/lang/Exception
      //   131	140	379	java/lang/Exception
      //   144	164	379	java/lang/Exception
      //   164	247	320	java/lang/Exception
      //   250	259	320	java/lang/Exception
      //   264	317	320	java/lang/Exception
      //   347	361	379	java/lang/Exception
    }
    
    protected void a(ba.d param1d) {
      if (ba.e.a(this.a).r() != null && param1d != null)
        ba.e.a(this.a).r().a(ba.d.a(param1d), ba.e.a(this.a)); 
      if (!ba.e.a(this.a).h()) {
        ba.b(this.a.a).c((File)ba.k().get(ba.e.a(this.a)));
        ba.k().remove(ba.e.a(this.a));
        ba.b b = (ba.b)ba.c(this.a.a).get(ba.e.a(this.a).g());
        if (b != null && !TextUtils.isEmpty(b.b()) && b.c() && ba.b.a(b) == ba.e.a(this.a)) {
          b.d();
          b.b(null);
        } 
        ba.e.a(this.a).d(false);
        ba.a(this.a.a, ba.e.a(this.a), ba.d.b(param1d), null, true);
        return;
      } 
      com.chartboost.sdk.Tracking.a.a().l().c((File)ba.l().get(ba.e.a(this.a)));
      com.chartboost.sdk.Tracking.a.a().p();
      CBLogging.a("CBRequestManager", "### Removing track events sent to server...");
      ba.l().remove(ba.e.a(this.a));
    }
    
    public void b(s param1s) {
      // Byte code:
      //   0: aload_0
      //   1: getfield a : Lcom/chartboost/sdk/impl/ba$e;
      //   4: invokestatic a : (Lcom/chartboost/sdk/impl/ba$e;)Lcom/chartboost/sdk/impl/az;
      //   7: ifnull -> 88
      //   10: invokestatic k : ()Z
      //   13: ifne -> 88
      //   16: aload_0
      //   17: getfield a : Lcom/chartboost/sdk/impl/ba$e;
      //   20: invokestatic a : (Lcom/chartboost/sdk/impl/ba$e;)Lcom/chartboost/sdk/impl/az;
      //   23: invokevirtual h : ()Z
      //   26: ifne -> 93
      //   29: invokestatic k : ()Ljava/util/concurrent/ConcurrentHashMap;
      //   32: aload_0
      //   33: getfield a : Lcom/chartboost/sdk/impl/ba$e;
      //   36: invokestatic a : (Lcom/chartboost/sdk/impl/ba$e;)Lcom/chartboost/sdk/impl/az;
      //   39: invokevirtual containsKey : (Ljava/lang/Object;)Z
      //   42: ifeq -> 93
      //   45: aload_0
      //   46: getfield a : Lcom/chartboost/sdk/impl/ba$e;
      //   49: getfield a : Lcom/chartboost/sdk/impl/ba;
      //   52: invokestatic b : (Lcom/chartboost/sdk/impl/ba;)Lcom/chartboost/sdk/Libraries/h;
      //   55: invokestatic k : ()Ljava/util/concurrent/ConcurrentHashMap;
      //   58: aload_0
      //   59: getfield a : Lcom/chartboost/sdk/impl/ba$e;
      //   62: invokestatic a : (Lcom/chartboost/sdk/impl/ba$e;)Lcom/chartboost/sdk/impl/az;
      //   65: invokevirtual get : (Ljava/lang/Object;)Ljava/lang/Object;
      //   68: checkcast java/io/File
      //   71: invokevirtual c : (Ljava/io/File;)V
      //   74: invokestatic k : ()Ljava/util/concurrent/ConcurrentHashMap;
      //   77: aload_0
      //   78: getfield a : Lcom/chartboost/sdk/impl/ba$e;
      //   81: invokestatic a : (Lcom/chartboost/sdk/impl/ba$e;)Lcom/chartboost/sdk/impl/az;
      //   84: invokevirtual remove : (Ljava/lang/Object;)Ljava/lang/Object;
      //   87: pop
      //   88: aload_1
      //   89: ifnonnull -> 160
      //   92: return
      //   93: invokestatic l : ()Ljava/util/concurrent/ConcurrentHashMap;
      //   96: invokevirtual isEmpty : ()Z
      //   99: ifne -> 88
      //   102: invokestatic l : ()Ljava/util/concurrent/ConcurrentHashMap;
      //   105: aload_0
      //   106: getfield a : Lcom/chartboost/sdk/impl/ba$e;
      //   109: invokestatic a : (Lcom/chartboost/sdk/impl/ba$e;)Lcom/chartboost/sdk/impl/az;
      //   112: invokevirtual containsKey : (Ljava/lang/Object;)Z
      //   115: ifeq -> 88
      //   118: invokestatic a : ()Lcom/chartboost/sdk/Tracking/a;
      //   121: invokevirtual l : ()Lcom/chartboost/sdk/Libraries/h;
      //   124: invokestatic l : ()Ljava/util/concurrent/ConcurrentHashMap;
      //   127: aload_0
      //   128: getfield a : Lcom/chartboost/sdk/impl/ba$e;
      //   131: invokestatic a : (Lcom/chartboost/sdk/impl/ba$e;)Lcom/chartboost/sdk/impl/az;
      //   134: invokevirtual get : (Ljava/lang/Object;)Ljava/lang/Object;
      //   137: checkcast java/io/File
      //   140: invokevirtual c : (Ljava/io/File;)V
      //   143: invokestatic l : ()Ljava/util/concurrent/ConcurrentHashMap;
      //   146: aload_0
      //   147: getfield a : Lcom/chartboost/sdk/impl/ba$e;
      //   150: invokestatic a : (Lcom/chartboost/sdk/impl/ba$e;)Lcom/chartboost/sdk/impl/az;
      //   153: invokevirtual remove : (Ljava/lang/Object;)Ljava/lang/Object;
      //   156: pop
      //   157: goto -> 88
      //   160: aload_1
      //   161: instanceof com/chartboost/sdk/impl/ba$c
      //   164: ifeq -> 279
      //   167: aload_1
      //   168: checkcast com/chartboost/sdk/impl/ba$c
      //   171: invokestatic a : (Lcom/chartboost/sdk/impl/ba$c;)Lcom/chartboost/sdk/Model/CBError;
      //   174: astore_2
      //   175: getstatic com/chartboost/sdk/Libraries/e$a.a : Lcom/chartboost/sdk/Libraries/e$a;
      //   178: astore #4
      //   180: aload #4
      //   182: astore_3
      //   183: aload_1
      //   184: ifnull -> 242
      //   187: aload #4
      //   189: astore_3
      //   190: aload_1
      //   191: getfield a : Lcom/chartboost/sdk/impl/i;
      //   194: ifnull -> 242
      //   197: aload #4
      //   199: astore_3
      //   200: aload_1
      //   201: getfield a : Lcom/chartboost/sdk/impl/i;
      //   204: getfield b : [B
      //   207: ifnull -> 242
      //   210: aload #4
      //   212: astore_3
      //   213: aload_1
      //   214: getfield a : Lcom/chartboost/sdk/impl/i;
      //   217: getfield b : [B
      //   220: arraylength
      //   221: ifle -> 242
      //   224: new java/lang/String
      //   227: dup
      //   228: aload_1
      //   229: getfield a : Lcom/chartboost/sdk/impl/i;
      //   232: getfield b : [B
      //   235: invokespecial <init> : ([B)V
      //   238: invokestatic j : (Ljava/lang/String;)Lcom/chartboost/sdk/Libraries/e$a;
      //   241: astore_3
      //   242: aload_1
      //   243: getfield a : Lcom/chartboost/sdk/impl/i;
      //   246: ifnull -> 313
      //   249: aload_1
      //   250: getfield a : Lcom/chartboost/sdk/impl/i;
      //   253: getfield a : I
      //   256: sipush #200
      //   259: if_icmpne -> 313
      //   262: aload_0
      //   263: new com/chartboost/sdk/impl/ba$d
      //   266: dup
      //   267: aload_3
      //   268: aload_1
      //   269: getfield a : Lcom/chartboost/sdk/impl/i;
      //   272: invokespecial <init> : (Lcom/chartboost/sdk/Libraries/e$a;Lcom/chartboost/sdk/impl/i;)V
      //   275: invokevirtual a : (Lcom/chartboost/sdk/impl/ba$d;)V
      //   278: return
      //   279: new com/chartboost/sdk/Model/CBError
      //   282: dup
      //   283: getstatic com/chartboost/sdk/Model/CBError$a.e : Lcom/chartboost/sdk/Model/CBError$a;
      //   286: aload_1
      //   287: invokevirtual getMessage : ()Ljava/lang/String;
      //   290: invokespecial <init> : (Lcom/chartboost/sdk/Model/CBError$a;Ljava/lang/String;)V
      //   293: astore_2
      //   294: goto -> 175
      //   297: astore_3
      //   298: ldc 'CBRequestManager'
      //   300: ldc_w 'unable to read error json'
      //   303: aload_3
      //   304: invokestatic d : (Ljava/lang/Object;Ljava/lang/String;Ljava/lang/Throwable;)V
      //   307: aload #4
      //   309: astore_3
      //   310: goto -> 242
      //   313: aload_0
      //   314: getfield a : Lcom/chartboost/sdk/impl/ba$e;
      //   317: invokestatic a : (Lcom/chartboost/sdk/impl/ba$e;)Lcom/chartboost/sdk/impl/az;
      //   320: invokevirtual r : ()Lcom/chartboost/sdk/impl/az$c;
      //   323: ifnull -> 350
      //   326: aload_0
      //   327: getfield a : Lcom/chartboost/sdk/impl/ba$e;
      //   330: invokestatic a : (Lcom/chartboost/sdk/impl/ba$e;)Lcom/chartboost/sdk/impl/az;
      //   333: invokevirtual r : ()Lcom/chartboost/sdk/impl/az$c;
      //   336: aload_3
      //   337: aload_0
      //   338: getfield a : Lcom/chartboost/sdk/impl/ba$e;
      //   341: invokestatic a : (Lcom/chartboost/sdk/impl/ba$e;)Lcom/chartboost/sdk/impl/az;
      //   344: aload_2
      //   345: invokeinterface a : (Lcom/chartboost/sdk/Libraries/e$a;Lcom/chartboost/sdk/impl/az;Lcom/chartboost/sdk/Model/CBError;)V
      //   350: aload_0
      //   351: getfield a : Lcom/chartboost/sdk/impl/ba$e;
      //   354: invokestatic a : (Lcom/chartboost/sdk/impl/ba$e;)Lcom/chartboost/sdk/impl/az;
      //   357: invokevirtual h : ()Z
      //   360: ifne -> 398
      //   363: aload_0
      //   364: getfield a : Lcom/chartboost/sdk/impl/ba$e;
      //   367: invokestatic a : (Lcom/chartboost/sdk/impl/ba$e;)Lcom/chartboost/sdk/impl/az;
      //   370: iconst_0
      //   371: invokevirtual d : (Z)V
      //   374: aload_0
      //   375: getfield a : Lcom/chartboost/sdk/impl/ba$e;
      //   378: getfield a : Lcom/chartboost/sdk/impl/ba;
      //   381: aload_0
      //   382: getfield a : Lcom/chartboost/sdk/impl/ba$e;
      //   385: invokestatic a : (Lcom/chartboost/sdk/impl/ba$e;)Lcom/chartboost/sdk/impl/az;
      //   388: aload_1
      //   389: getfield a : Lcom/chartboost/sdk/impl/i;
      //   392: aload_2
      //   393: iconst_0
      //   394: invokestatic a : (Lcom/chartboost/sdk/impl/ba;Lcom/chartboost/sdk/impl/az;Lcom/chartboost/sdk/impl/i;Lcom/chartboost/sdk/Model/CBError;Z)V
      //   397: return
      //   398: invokestatic l : ()Ljava/util/concurrent/ConcurrentHashMap;
      //   401: aload_0
      //   402: getfield a : Lcom/chartboost/sdk/impl/ba$e;
      //   405: invokestatic a : (Lcom/chartboost/sdk/impl/ba$e;)Lcom/chartboost/sdk/impl/az;
      //   408: invokevirtual remove : (Ljava/lang/Object;)Ljava/lang/Object;
      //   411: pop
      //   412: return
      // Exception table:
      //   from	to	target	type
      //   190	197	297	java/lang/Exception
      //   200	210	297	java/lang/Exception
      //   213	242	297	java/lang/Exception
    }
    
    public Map<String, String> i() throws a {
      HashMap<Object, Object> hashMap = new HashMap<Object, Object>();
      for (Map.Entry<String, Object> entry : this.b.j().entrySet()) {
        Object object = entry.getKey();
        if (entry.getValue() != null) {
          String str = entry.getValue().toString();
        } else {
          entry = null;
        } 
        hashMap.put(object, entry);
      } 
      return (Map)hashMap;
    }
    
    public String p() {
      String str2 = this.b.b();
      String str1 = str2;
      if (str2 == null)
        str1 = "application/json; charset=utf-8"; 
      return str1;
    }
    
    public byte[] q() {
      if (this.b.i() == null) {
        String str1 = "";
        return str1.getBytes();
      } 
      String str = this.b.i().toString();
      return str.getBytes();
    }
    
    public l.a s() {
      return this.b.n();
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Smash Cricket-dex2jar.jar!\com\chartboost\sdk\impl\ba.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */