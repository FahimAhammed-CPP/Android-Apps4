package com.chartboost.sdk.impl;

import android.os.SystemClock;
import java.io.IOException;
import java.io.InputStream;
import java.net.MalformedURLException;
import java.net.SocketTimeoutException;
import java.util.Date;
import java.util.HashMap;
import java.util.Map;
import org.apache.http.Header;
import org.apache.http.HttpEntity;
import org.apache.http.HttpResponse;
import org.apache.http.StatusLine;
import org.apache.http.conn.ConnectTimeoutException;
import org.apache.http.impl.cookie.DateUtils;

public class u implements f {
  protected static final boolean a = t.b;
  
  private static int d = 3000;
  
  private static int e = 4096;
  
  protected final z b;
  
  protected final v c;
  
  public u(z paramz) {
    this(paramz, new v(e));
  }
  
  public u(z paramz, v paramv) {
    this.b = paramz;
    this.c = paramv;
  }
  
  private static Map<String, String> a(Header[] paramArrayOfHeader) {
    HashMap<Object, Object> hashMap = new HashMap<Object, Object>();
    for (int i = 0;; i++) {
      if (i >= paramArrayOfHeader.length)
        return (Map)hashMap; 
      hashMap.put(paramArrayOfHeader[i].getName(), paramArrayOfHeader[i].getValue());
    } 
  }
  
  private void a(long paramLong, l<?> paraml, byte[] paramArrayOfbyte, StatusLine paramStatusLine) {
    if (a || paramLong > d) {
      String str;
      if (paramArrayOfbyte != null) {
        Integer integer = Integer.valueOf(paramArrayOfbyte.length);
      } else {
        str = "null";
      } 
      t.b("HTTP response for request=<%s> [lifetime=%d], [size=%s], [rc=%d], [retryCount=%s]", new Object[] { paraml, Long.valueOf(paramLong), str, Integer.valueOf(paramStatusLine.getStatusCode()), Integer.valueOf(paraml.u().b()) });
    } 
  }
  
  private static void a(String paramString, l<?> paraml, s params) throws s {
    p p = paraml.u();
    int i = paraml.t();
    try {
      p.a(params);
      paraml.a(String.format("%s-retry [timeout=%s]", new Object[] { paramString, Integer.valueOf(i) }));
      return;
    } catch (s s1) {
      paraml.a(String.format("%s-timeout-giveup [timeout=%s]", new Object[] { paramString, Integer.valueOf(i) }));
      throw s1;
    } 
  }
  
  private void a(Map<String, String> paramMap, b.a parama) {
    if (parama != null) {
      if (parama.b != null)
        paramMap.put("If-None-Match", parama.b); 
      if (parama.c > 0L) {
        paramMap.put("If-Modified-Since", DateUtils.formatDate(new Date(parama.c)));
        return;
      } 
    } 
  }
  
  private byte[] a(HttpEntity paramHttpEntity) throws IOException, q {
    InputStream inputStream;
    ac ac = new ac(this.c, (int)paramHttpEntity.getContentLength());
    null = null;
    Exception exception = null;
    try {
    
    } finally {
      try {
        paramHttpEntity.consumeContent();
      } catch (IOException iOException) {
        t.a("Error occured when calling consumingContent", new Object[0]);
      } 
      this.c.a((byte[])exception);
      ac.close();
    } 
    Object object = SYNTHETIC_LOCAL_VARIABLE_4;
    byte[] arrayOfByte = this.c.a(1024);
    while (true) {
      object = arrayOfByte;
      int i = inputStream.read(arrayOfByte);
      if (i == -1) {
        object = arrayOfByte;
        byte[] arrayOfByte1 = ac.toByteArray();
        try {
          iOException.consumeContent();
        } catch (IOException iOException1) {
          t.a("Error occured when calling consumingContent", new Object[0]);
        } 
        this.c.a(arrayOfByte);
        ac.close();
        return arrayOfByte1;
      } 
      object = arrayOfByte;
      ac.write(arrayOfByte, 0, i);
    } 
  }
  
  public i a(l<?> paraml) throws s {
    long l1 = SystemClock.elapsedRealtime();
    while (true) {
      i i;
      IOException iOException2;
      HashMap<Object, Object> hashMap1;
      byte[] arrayOfByte2 = null;
      byte[] arrayOfByte3 = null;
      byte[] arrayOfByte1 = null;
      HashMap<Object, Object> hashMap2 = new HashMap<Object, Object>();
      try {
        HashMap<Object, Object> hashMap = new HashMap<Object, Object>();
        a((Map)hashMap, paraml.f());
        HttpResponse httpResponse = this.b.a(paraml, (Map)hashMap);
        try {
          StatusLine statusLine = httpResponse.getStatusLine();
          int j = statusLine.getStatusCode();
          Map<String, String> map = a(httpResponse.getAllHeaders());
          if (j == 304) {
            arrayOfByte1 = arrayOfByte3;
            try {
              if (paraml.f() == null) {
                arrayOfByte2 = null;
              } else {
                arrayOfByte1 = arrayOfByte3;
                arrayOfByte2 = (paraml.f()).a;
              } 
              arrayOfByte1 = arrayOfByte3;
              return new i(304, arrayOfByte2, map, true);
            } catch (IOException null) {}
          } else {
            arrayOfByte1 = arrayOfByte3;
            if (httpResponse.getEntity() != null) {
              arrayOfByte1 = arrayOfByte3;
              arrayOfByte2 = a(httpResponse.getEntity());
            } else {
              arrayOfByte1 = arrayOfByte3;
              arrayOfByte2 = new byte[0];
            } 
            arrayOfByte1 = arrayOfByte2;
            a(SystemClock.elapsedRealtime() - l1, paraml, arrayOfByte2, statusLine);
            if (j < 200 || j > 299) {
              arrayOfByte1 = arrayOfByte2;
              throw new IOException();
            } 
            arrayOfByte1 = arrayOfByte2;
            return new i(j, arrayOfByte2, map, false);
          } 
        } catch (IOException iOException1) {
          hashMap1 = hashMap2;
        } 
      } catch (SocketTimeoutException socketTimeoutException) {
        a("socket", paraml, new r());
        continue;
      } catch (ConnectTimeoutException connectTimeoutException) {
        a("connection", paraml, new r());
        continue;
      } catch (MalformedURLException malformedURLException) {
        throw new RuntimeException("Bad URL " + paraml.d(), malformedURLException);
      } catch (IOException iOException) {
        iOException2 = iOException1;
        hashMap1 = hashMap2;
        iOException1 = iOException;
      } 
      if (iOException2 != null) {
        int j = iOException2.getStatusLine().getStatusCode();
        t.c("Unexpected response code %d for %s", new Object[] { Integer.valueOf(j), paraml.d() });
        i = new i(j, (byte[])malformedURLException, (Map)hashMap1, false);
        if (malformedURLException != null) {
          if (j == 401 || j == 403) {
            a("auth", paraml, new a(i));
            continue;
          } 
          throw new q(i);
        } 
      } else {
        throw new j(i);
      } 
      throw new h(i);
    } 
  }
}


/* Location:              C:\soft\dex2jar-2.0\Smash Cricket-dex2jar.jar!\com\chartboost\sdk\imp\\u.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */