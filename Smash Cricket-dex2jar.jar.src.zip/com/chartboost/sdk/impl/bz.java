package com.chartboost.sdk.impl;

import java.lang.reflect.Array;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.GregorianCalendar;
import java.util.Iterator;
import java.util.Map;
import java.util.SimpleTimeZone;
import java.util.UUID;
import java.util.regex.Pattern;

public class bz {
  public static cb a() {
    bx bx = b();
    bx.a(Date.class, new i(bx));
    bx.a(cs.class, new g(bx));
    bx.a(ct.class, new h());
    bx.a(byte[].class, new h());
    return bx;
  }
  
  static bx b() {
    bx bx = new bx();
    bx.a(Object[].class, new m(bx));
    bx.a(Boolean.class, new q());
    bx.a(cu.class, new a(bx));
    bx.a(cv.class, new b(bx));
    bx.a(bu.class, new d(bx));
    bx.a(bv.class, new e(bx));
    bx.a(Iterable.class, new f(bx));
    bx.a(Map.class, new j(bx));
    bx.a(cw.class, new k(bx));
    bx.a(cx.class, new l(bx));
    bx.a(Number.class, new q());
    bx.a(cy.class, new n(bx));
    bx.a(Pattern.class, new o(bx));
    bx.a(String.class, new p());
    bx.a(UUID.class, new r(bx));
    return bx;
  }
  
  private static class a extends c {
    a(cb param1cb) {
      super(param1cb);
    }
    
    public void a(Object param1Object, StringBuilder param1StringBuilder) {
      param1Object = param1Object;
      bs bs = new bs();
      bs.a("$code", param1Object.a());
      this.a.a(bs, param1StringBuilder);
    }
  }
  
  private static class b extends c {
    b(cb param1cb) {
      super(param1cb);
    }
    
    public void a(Object param1Object, StringBuilder param1StringBuilder) {
      param1Object = param1Object;
      bs bs = new bs();
      bs.a("$code", param1Object.a());
      bs.a("$scope", param1Object.b());
      this.a.a(bs, param1StringBuilder);
    }
  }
  
  private static abstract class c extends bw {
    protected final cb a;
    
    c(cb param1cb) {
      this.a = param1cb;
    }
  }
  
  private static class d extends c {
    d(cb param1cb) {
      super(param1cb);
    }
    
    public void a(Object param1Object, StringBuilder param1StringBuilder) {
      param1StringBuilder.append("{ ");
      param1Object = param1Object;
      Iterator<String> iterator = param1Object.keySet().iterator();
      boolean bool = true;
      while (iterator.hasNext()) {
        String str = iterator.next();
        if (bool) {
          bool = false;
        } else {
          param1StringBuilder.append(" , ");
        } 
        by.a(param1StringBuilder, str);
        param1StringBuilder.append(" : ");
        this.a.a(param1Object.a(str), param1StringBuilder);
      } 
      param1StringBuilder.append("}");
    }
  }
  
  private static class e extends c {
    e(cb param1cb) {
      super(param1cb);
    }
    
    public void a(Object param1Object, StringBuilder param1StringBuilder) {
      param1Object = param1Object;
      bs bs = new bs();
      bs.a("$ref", param1Object.b());
      bs.a("$id", param1Object.a());
      this.a.a(bs, param1StringBuilder);
    }
  }
  
  private static class f extends c {
    f(cb param1cb) {
      super(param1cb);
    }
    
    public void a(Object param1Object, StringBuilder param1StringBuilder) {
      boolean bool = true;
      param1StringBuilder.append("[ ");
      param1Object = ((Iterable)param1Object).iterator();
      while (param1Object.hasNext()) {
        Object object = param1Object.next();
        if (bool) {
          bool = false;
        } else {
          param1StringBuilder.append(" , ");
        } 
        this.a.a(object, param1StringBuilder);
      } 
      param1StringBuilder.append("]");
    }
  }
  
  private static class g extends c {
    g(cb param1cb) {
      super(param1cb);
    }
    
    public void a(Object param1Object, StringBuilder param1StringBuilder) {
      param1Object = param1Object;
      bs bs = new bs();
      bs.a("$ts", Integer.valueOf(param1Object.a()));
      bs.a("$inc", Integer.valueOf(param1Object.b()));
      this.a.a(bs, param1StringBuilder);
    }
  }
  
  private static class h extends bw {
    private h() {}
    
    public void a(Object param1Object, StringBuilder param1StringBuilder) {
      param1StringBuilder.append("<Binary Data>");
    }
  }
  
  private static class i extends c {
    i(cb param1cb) {
      super(param1cb);
    }
    
    public void a(Object param1Object, StringBuilder param1StringBuilder) {
      param1Object = param1Object;
      SimpleDateFormat simpleDateFormat = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss.SSS'Z'");
      simpleDateFormat.setCalendar(new GregorianCalendar(new SimpleTimeZone(0, "GMT")));
      this.a.a(new bs("$date", simpleDateFormat.format((Date)param1Object)), param1StringBuilder);
    }
  }
  
  private static class j extends c {
    j(cb param1cb) {
      super(param1cb);
    }
    
    public void a(Object param1Object, StringBuilder param1StringBuilder) {
      param1StringBuilder.append("{ ");
      param1Object = ((Map)param1Object).entrySet().iterator();
      boolean bool = true;
      while (param1Object.hasNext()) {
        Map.Entry entry = param1Object.next();
        if (bool) {
          bool = false;
        } else {
          param1StringBuilder.append(" , ");
        } 
        by.a(param1StringBuilder, entry.getKey().toString());
        param1StringBuilder.append(" : ");
        this.a.a(entry.getValue(), param1StringBuilder);
      } 
      param1StringBuilder.append("}");
    }
  }
  
  private static class k extends c {
    k(cb param1cb) {
      super(param1cb);
    }
    
    public void a(Object param1Object, StringBuilder param1StringBuilder) {
      this.a.a(new bs("$maxKey", Integer.valueOf(1)), param1StringBuilder);
    }
  }
  
  private static class l extends c {
    l(cb param1cb) {
      super(param1cb);
    }
    
    public void a(Object param1Object, StringBuilder param1StringBuilder) {
      this.a.a(new bs("$minKey", Integer.valueOf(1)), param1StringBuilder);
    }
  }
  
  private static class m extends c {
    m(cb param1cb) {
      super(param1cb);
    }
    
    public void a(Object param1Object, StringBuilder param1StringBuilder) {
      param1StringBuilder.append("[ ");
      for (int i = 0; i < Array.getLength(param1Object); i++) {
        if (i > 0)
          param1StringBuilder.append(" , "); 
        this.a.a(Array.get(param1Object, i), param1StringBuilder);
      } 
      param1StringBuilder.append("]");
    }
  }
  
  private static class n extends c {
    n(cb param1cb) {
      super(param1cb);
    }
    
    public void a(Object param1Object, StringBuilder param1StringBuilder) {
      this.a.a(new bs("$oid", param1Object.toString()), param1StringBuilder);
    }
  }
  
  private static class o extends c {
    o(cb param1cb) {
      super(param1cb);
    }
    
    public void a(Object param1Object, StringBuilder param1StringBuilder) {
      bs bs = new bs();
      bs.a("$regex", param1Object.toString());
      if (((Pattern)param1Object).flags() != 0)
        bs.a("$options", bt.a(((Pattern)param1Object).flags())); 
      this.a.a(bs, param1StringBuilder);
    }
  }
  
  private static class p extends bw {
    private p() {}
    
    public void a(Object param1Object, StringBuilder param1StringBuilder) {
      by.a(param1StringBuilder, (String)param1Object);
    }
  }
  
  private static class q extends bw {
    private q() {}
    
    public void a(Object param1Object, StringBuilder param1StringBuilder) {
      param1StringBuilder.append(param1Object.toString());
    }
  }
  
  private static class r extends c {
    r(cb param1cb) {
      super(param1cb);
    }
    
    public void a(Object param1Object, StringBuilder param1StringBuilder) {
      param1Object = param1Object;
      bs bs = new bs();
      bs.a("$uuid", param1Object.toString());
      this.a.a(bs, param1StringBuilder);
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Smash Cricket-dex2jar.jar!\com\chartboost\sdk\impl\bz.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */