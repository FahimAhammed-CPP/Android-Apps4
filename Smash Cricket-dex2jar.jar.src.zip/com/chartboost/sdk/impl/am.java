package com.chartboost.sdk.impl;

import android.content.Context;
import android.view.View;
import android.view.ViewGroup;
import android.widget.RelativeLayout;
import com.chartboost.sdk.Libraries.CBLogging;
import com.chartboost.sdk.Libraries.CBUtility;

public abstract class am extends RelativeLayout {
  private static final String b = am.class.getSimpleName();
  
  protected ai a;
  
  private an c;
  
  private a d;
  
  public am(Context paramContext, ai paramai) {
    super(paramContext);
    this.a = paramai;
    this.d = a.b;
    a(paramContext);
  }
  
  private void a(Context paramContext) {
    paramContext = getContext();
    setGravity(17);
    this.c = new an(paramContext);
    this.c.a(-1);
    this.c.setBackgroundColor(-855638017);
    addView((View)this.c, (ViewGroup.LayoutParams)new RelativeLayout.LayoutParams(-1, -1));
    addView(a(), (ViewGroup.LayoutParams)new RelativeLayout.LayoutParams(-1, -1));
  }
  
  private void a(boolean paramBoolean, long paramLong) {
    // Byte code:
    //   0: aload_0
    //   1: getfield a : Lcom/chartboost/sdk/impl/ai;
    //   4: iload_1
    //   5: putfield z : Z
    //   8: iload_1
    //   9: ifeq -> 19
    //   12: aload_0
    //   13: invokevirtual getVisibility : ()I
    //   16: ifeq -> 32
    //   19: iload_1
    //   20: ifne -> 33
    //   23: aload_0
    //   24: invokevirtual getVisibility : ()I
    //   27: bipush #8
    //   29: if_icmpne -> 33
    //   32: return
    //   33: new com/chartboost/sdk/impl/am$1
    //   36: dup
    //   37: aload_0
    //   38: iload_1
    //   39: invokespecial <init> : (Lcom/chartboost/sdk/impl/am;Z)V
    //   42: astore #7
    //   44: iload_1
    //   45: ifeq -> 53
    //   48: aload_0
    //   49: iconst_0
    //   50: invokevirtual setVisibility : (I)V
    //   53: aload_0
    //   54: invokevirtual b : ()I
    //   57: i2f
    //   58: aload_0
    //   59: invokevirtual getContext : ()Landroid/content/Context;
    //   62: invokestatic a : (FLandroid/content/Context;)F
    //   65: fstore #4
    //   67: getstatic com/chartboost/sdk/impl/am$2.a : [I
    //   70: aload_0
    //   71: getfield d : Lcom/chartboost/sdk/impl/am$a;
    //   74: invokevirtual ordinal : ()I
    //   77: iaload
    //   78: tableswitch default -> 108, 1 -> 168, 2 -> 216, 3 -> 255, 4 -> 303
    //   108: aconst_null
    //   109: astore #6
    //   111: aload #6
    //   113: lload_2
    //   114: invokevirtual setDuration : (J)V
    //   117: iload_1
    //   118: ifeq -> 342
    //   121: iconst_0
    //   122: istore_1
    //   123: aload #6
    //   125: iload_1
    //   126: invokevirtual setFillAfter : (Z)V
    //   129: aload_0
    //   130: aload #6
    //   132: invokevirtual startAnimation : (Landroid/view/animation/Animation;)V
    //   135: aload_0
    //   136: getfield a : Lcom/chartboost/sdk/impl/ai;
    //   139: getfield h : Ljava/util/Map;
    //   142: aload_0
    //   143: invokevirtual hashCode : ()I
    //   146: invokestatic valueOf : (I)Ljava/lang/Integer;
    //   149: aload #7
    //   151: invokeinterface put : (Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    //   156: pop
    //   157: getstatic com/chartboost/sdk/f.a : Landroid/os/Handler;
    //   160: aload #7
    //   162: lload_2
    //   163: invokevirtual postDelayed : (Ljava/lang/Runnable;J)Z
    //   166: pop
    //   167: return
    //   168: iload_1
    //   169: ifeq -> 202
    //   172: fload #4
    //   174: fneg
    //   175: fstore #5
    //   177: iload_1
    //   178: ifeq -> 208
    //   181: fconst_0
    //   182: fstore #4
    //   184: new android/view/animation/TranslateAnimation
    //   187: dup
    //   188: fconst_0
    //   189: fconst_0
    //   190: fload #5
    //   192: fload #4
    //   194: invokespecial <init> : (FFFF)V
    //   197: astore #6
    //   199: goto -> 111
    //   202: fconst_0
    //   203: fstore #5
    //   205: goto -> 177
    //   208: fload #4
    //   210: fneg
    //   211: fstore #4
    //   213: goto -> 184
    //   216: iload_1
    //   217: ifeq -> 249
    //   220: fload #4
    //   222: fstore #5
    //   224: iload_1
    //   225: ifeq -> 231
    //   228: fconst_0
    //   229: fstore #4
    //   231: new android/view/animation/TranslateAnimation
    //   234: dup
    //   235: fconst_0
    //   236: fconst_0
    //   237: fload #5
    //   239: fload #4
    //   241: invokespecial <init> : (FFFF)V
    //   244: astore #6
    //   246: goto -> 111
    //   249: fconst_0
    //   250: fstore #5
    //   252: goto -> 224
    //   255: iload_1
    //   256: ifeq -> 289
    //   259: fload #4
    //   261: fneg
    //   262: fstore #5
    //   264: iload_1
    //   265: ifeq -> 295
    //   268: fconst_0
    //   269: fstore #4
    //   271: new android/view/animation/TranslateAnimation
    //   274: dup
    //   275: fload #5
    //   277: fload #4
    //   279: fconst_0
    //   280: fconst_0
    //   281: invokespecial <init> : (FFFF)V
    //   284: astore #6
    //   286: goto -> 111
    //   289: fconst_0
    //   290: fstore #5
    //   292: goto -> 264
    //   295: fload #4
    //   297: fneg
    //   298: fstore #4
    //   300: goto -> 271
    //   303: iload_1
    //   304: ifeq -> 336
    //   307: fload #4
    //   309: fstore #5
    //   311: iload_1
    //   312: ifeq -> 318
    //   315: fconst_0
    //   316: fstore #4
    //   318: new android/view/animation/TranslateAnimation
    //   321: dup
    //   322: fload #5
    //   324: fload #4
    //   326: fconst_0
    //   327: fconst_0
    //   328: invokespecial <init> : (FFFF)V
    //   331: astore #6
    //   333: goto -> 111
    //   336: fconst_0
    //   337: fstore #5
    //   339: goto -> 311
    //   342: iconst_1
    //   343: istore_1
    //   344: goto -> 123
  }
  
  protected abstract View a();
  
  public void a(a parama) {
    if (parama == null) {
      CBLogging.b(b, "Side object cannot be null");
      return;
    } 
    this.d = parama;
    parama = null;
    setClickable(false);
    int i = b();
    switch (null.a[this.d.ordinal()]) {
      default:
        setLayoutParams((ViewGroup.LayoutParams)parama);
        return;
      case 1:
        layoutParams = new RelativeLayout.LayoutParams(-1, CBUtility.a(i, getContext()));
        layoutParams.addRule(10);
        this.c.b(1);
      case 2:
        layoutParams = new RelativeLayout.LayoutParams(-1, CBUtility.a(i, getContext()));
        layoutParams.addRule(12);
        this.c.b(4);
      case 3:
        layoutParams = new RelativeLayout.LayoutParams(CBUtility.a(i, getContext()), -1);
        layoutParams.addRule(9);
        this.c.b(8);
      case 4:
        break;
    } 
    RelativeLayout.LayoutParams layoutParams = new RelativeLayout.LayoutParams(CBUtility.a(i, getContext()), -1);
    layoutParams.addRule(11);
    this.c.b(2);
  }
  
  public void a(boolean paramBoolean) {
    a(paramBoolean, 250L);
  }
  
  protected abstract int b();
  
  public enum a {
    a, b, c, d;
  }
}


/* Location:              C:\soft\dex2jar-2.0\Smash Cricket-dex2jar.jar!\com\chartboost\sdk\impl\am.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */