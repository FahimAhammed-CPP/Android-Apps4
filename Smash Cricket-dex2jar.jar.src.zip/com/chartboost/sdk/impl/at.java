package com.chartboost.sdk.impl;

import android.content.Context;
import android.view.View;
import android.view.ViewGroup;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.LinearLayout;
import com.chartboost.sdk.Libraries.CBLogging;
import com.chartboost.sdk.Libraries.CBUtility;
import com.chartboost.sdk.Libraries.e;

public class at extends ap {
  private WebView a;
  
  private View.OnClickListener b = null;
  
  public at(aw paramaw, Context paramContext) {
    super(paramContext);
    this.a = new WebView(paramContext);
    addView((View)this.a, (ViewGroup.LayoutParams)new LinearLayout.LayoutParams(-1, -1));
    this.a.setBackgroundColor(0);
    this.a.setWebViewClient(new WebViewClient(this) {
          public boolean shouldOverrideUrlLoading(WebView param1WebView, String param1String) {
            if (param1String == null)
              return false; 
            if (param1String.contains("chartboost") && param1String.contains("click") && at.a(this.a) != null)
              at.a(this.a).onClick((View)this.a); 
            return true;
          }
        });
  }
  
  public int a() {
    return CBUtility.a(100, getContext());
  }
  
  public void a(e.a parama, int paramInt) {
    String str = parama.e("html");
    if (str != null)
      try {
        this.a.loadDataWithBaseURL("file:///android_res/", str, "text/html", "UTF-8", null);
        return;
      } catch (Exception exception) {
        CBLogging.b("AppCellWebView", "Exception raised loading data into webview", exception);
        return;
      }  
  }
  
  public void setOnClickListener(View.OnClickListener paramOnClickListener) {
    super.setOnClickListener(paramOnClickListener);
    this.b = paramOnClickListener;
  }
}


/* Location:              C:\soft\dex2jar-2.0\Smash Cricket-dex2jar.jar!\com\chartboost\sdk\impl\at.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */