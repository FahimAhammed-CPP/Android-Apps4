package com.chartboost.sdk.impl;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.drawable.BitmapDrawable;
import android.graphics.drawable.Drawable;
import android.widget.ImageView;
import android.widget.TextView;
import com.chartboost.sdk.Libraries.j;

public class bj extends ImageView {
  protected TextView a = null;
  
  private j b = null;
  
  public bj(Context paramContext) {
    super(paramContext);
  }
  
  protected void a(Canvas paramCanvas) {
    if (this.a != null) {
      this.a.layout(0, 0, paramCanvas.getWidth(), paramCanvas.getHeight());
      this.a.setEnabled(isEnabled());
      this.a.setSelected(isSelected());
      if (isFocused()) {
        this.a.requestFocus();
      } else {
        this.a.clearFocus();
      } 
      this.a.setPressed(isPressed());
      this.a.draw(paramCanvas);
    } 
  }
  
  public void a(j paramj) {
    if (this.b == paramj)
      return; 
    this.b = paramj;
    setImageDrawable((Drawable)new BitmapDrawable(paramj.f()));
  }
  
  protected void onDraw(Canvas paramCanvas) {
    super.onDraw(paramCanvas);
    a(paramCanvas);
  }
  
  public void setImageBitmap(Bitmap paramBitmap) {
    this.b = null;
    setImageDrawable((Drawable)new BitmapDrawable(paramBitmap));
  }
}


/* Location:              C:\soft\dex2jar-2.0\Smash Cricket-dex2jar.jar!\com\chartboost\sdk\impl\bj.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */