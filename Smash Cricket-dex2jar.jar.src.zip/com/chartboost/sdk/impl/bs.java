package com.chartboost.sdk.impl;

public class bs extends cm implements bu {
  public bs() {}
  
  public bs(String paramString, Object paramObject) {
    super(paramString, paramObject);
  }
  
  public String toString() {
    return by.a(this);
  }
}


/* Location:              C:\soft\dex2jar-2.0\Smash Cricket-dex2jar.jar!\com\chartboost\sdk\impl\bs.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */