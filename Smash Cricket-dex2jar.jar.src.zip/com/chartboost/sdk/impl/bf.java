package com.chartboost.sdk.impl;

import android.content.Context;
import android.content.Intent;
import android.graphics.Matrix;
import android.graphics.SurfaceTexture;
import android.media.MediaMetadataRetriever;
import android.media.MediaPlayer;
import android.net.Uri;
import android.view.Surface;
import android.view.TextureView;
import com.chartboost.sdk.Libraries.CBLogging;
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.util.Map;

public class bf extends TextureView implements TextureView.SurfaceTextureListener, bg.a {
  MediaPlayer.OnVideoSizeChangedListener a = new MediaPlayer.OnVideoSizeChangedListener(this) {
      public void onVideoSizeChanged(MediaPlayer param1MediaPlayer, int param1Int1, int param1Int2) {
        bf.a(this.a, param1MediaPlayer.getVideoWidth());
        bf.b(this.a, param1MediaPlayer.getVideoHeight());
        if (bf.a(this.a) != 0 && bf.b(this.a) != 0)
          this.a.a(this.a.getWidth(), this.a.getHeight()); 
      }
    };
  
  MediaPlayer.OnPreparedListener b = new MediaPlayer.OnPreparedListener(this) {
      public void onPrepared(MediaPlayer param1MediaPlayer) {
        bf.c(this.a, 2);
        bf.a(this.a, param1MediaPlayer.getVideoWidth());
        bf.b(this.a, param1MediaPlayer.getVideoHeight());
        if (bf.c(this.a) != null)
          bf.c(this.a).onPrepared(bf.d(this.a)); 
        int i = bf.e(this.a);
        if (i != 0)
          this.a.a(i); 
        if (bf.f(this.a) == 3)
          this.a.a(); 
      }
    };
  
  private String c = "VideoTextureView";
  
  private Uri d;
  
  private Map<String, String> e;
  
  private int f;
  
  private int g = 0;
  
  private int h = 0;
  
  private Surface i = null;
  
  private MediaPlayer j = null;
  
  private int k;
  
  private int l;
  
  private MediaPlayer.OnCompletionListener m;
  
  private MediaPlayer.OnPreparedListener n;
  
  private int o;
  
  private MediaPlayer.OnErrorListener p;
  
  private int q;
  
  private MediaPlayer.OnCompletionListener r = new MediaPlayer.OnCompletionListener(this) {
      public void onCompletion(MediaPlayer param1MediaPlayer) {
        bf.d(this.a, 5);
        if (bf.g(this.a) != 5) {
          bf.c(this.a, 5);
          if (bf.h(this.a) != null)
            bf.h(this.a).onCompletion(bf.d(this.a)); 
        } 
      }
    };
  
  private MediaPlayer.OnErrorListener s = new MediaPlayer.OnErrorListener(this) {
      public boolean onError(MediaPlayer param1MediaPlayer, int param1Int1, int param1Int2) {
        CBLogging.a(bf.i(this.a), "Error: " + param1Int1 + "," + param1Int2);
        if (param1Int1 == 100) {
          bf.j(this.a);
          return true;
        } 
        bf.c(this.a, -1);
        bf.d(this.a, -1);
        return (bf.k(this.a) != null && bf.k(this.a).onError(bf.d(this.a), param1Int1, param1Int2)) ? true : true;
      }
    };
  
  private MediaPlayer.OnBufferingUpdateListener t = new MediaPlayer.OnBufferingUpdateListener(this) {
      public void onBufferingUpdate(MediaPlayer param1MediaPlayer, int param1Int) {
        bf.e(this.a, param1Int);
      }
    };
  
  public bf(Context paramContext) {
    super(paramContext);
    f();
  }
  
  private void a(boolean paramBoolean) {
    if (this.j != null) {
      this.j.reset();
      this.j.release();
      this.j = null;
      this.g = 0;
      if (paramBoolean)
        this.h = 0; 
    } 
  }
  
  private void f() {
    this.k = 0;
    this.l = 0;
    setSurfaceTextureListener(this);
    setFocusable(true);
    setFocusableInTouchMode(true);
    requestFocus();
    this.g = 0;
    this.h = 0;
  }
  
  private void g() {
    if (this.d == null || this.i == null)
      return; 
    Intent intent = new Intent("com.android.music.musicservicecommand");
    intent.putExtra("command", "pause");
    getContext().sendBroadcast(intent);
    a(false);
    try {
      MediaMetadataRetriever mediaMetadataRetriever = new MediaMetadataRetriever();
      mediaMetadataRetriever.setDataSource(this.d.toString());
      String str1 = mediaMetadataRetriever.extractMetadata(19);
      String str2 = mediaMetadataRetriever.extractMetadata(18);
      this.l = (int)Float.parseFloat(str1);
      this.k = (int)Float.parseFloat(str2);
      try {
        this.j = new MediaPlayer();
        this.j.setOnPreparedListener(this.b);
        this.j.setOnVideoSizeChangedListener(this.a);
        this.f = -1;
        this.j.setOnCompletionListener(this.r);
        this.j.setOnErrorListener(this.s);
        this.j.setOnBufferingUpdateListener(this.t);
        this.o = 0;
        FileInputStream fileInputStream = new FileInputStream(new File(this.d.toString()));
        this.j.setDataSource(fileInputStream.getFD());
        fileInputStream.close();
        this.j.setSurface(this.i);
        this.j.setAudioStreamType(3);
        this.j.setScreenOnWhilePlaying(true);
        this.j.prepareAsync();
        this.g = 1;
        return;
      } catch (IOException iOException) {
        CBLogging.d(this.c, "Unable to open content: " + this.d, iOException);
        this.g = -1;
        this.h = -1;
        this.s.onError(this.j, 1, 0);
        return;
      } catch (IllegalArgumentException illegalArgumentException) {
        CBLogging.d(this.c, "Unable to open content: " + this.d, illegalArgumentException);
        this.g = -1;
        this.h = -1;
        this.s.onError(this.j, 1, 0);
      } 
    } catch (Exception exception) {
      CBLogging.d("play video", "read size error", exception);
      try {
        this.j = new MediaPlayer();
        this.j.setOnPreparedListener(this.b);
        this.j.setOnVideoSizeChangedListener(this.a);
        this.f = -1;
        this.j.setOnCompletionListener(this.r);
        this.j.setOnErrorListener(this.s);
        this.j.setOnBufferingUpdateListener(this.t);
        this.o = 0;
        FileInputStream fileInputStream = new FileInputStream(new File(this.d.toString()));
        this.j.setDataSource(fileInputStream.getFD());
        fileInputStream.close();
        this.j.setSurface(this.i);
        this.j.setAudioStreamType(3);
        this.j.setScreenOnWhilePlaying(true);
        this.j.prepareAsync();
        this.g = 1;
        return;
      } catch (IOException iOException) {
        CBLogging.d(this.c, "Unable to open content: " + this.d, iOException);
        this.g = -1;
        this.h = -1;
        this.s.onError(this.j, 1, 0);
        return;
      } catch (IllegalArgumentException illegalArgumentException) {
        CBLogging.d(this.c, "Unable to open content: " + this.d, illegalArgumentException);
        this.g = -1;
        this.h = -1;
        this.s.onError(this.j, 1, 0);
      } 
    } 
  }
  
  private boolean h() {
    return (this.j != null && this.g != -1 && this.g != 0 && this.g != 1);
  }
  
  public void a() {
    if (h()) {
      this.j.start();
      this.g = 3;
    } 
    this.h = 3;
  }
  
  public void a(int paramInt) {
    if (h()) {
      this.j.seekTo(paramInt);
      this.q = 0;
      return;
    } 
    this.q = paramInt;
  }
  
  public void a(int paramInt1, int paramInt2) {
    if (this.k == 0 || this.l == 0 || paramInt1 == 0 || paramInt2 == 0)
      return; 
    float f1 = Math.min(paramInt1 / this.k, paramInt2 / this.l);
    float f2 = this.k;
    float f3 = this.l;
    Matrix matrix = new Matrix();
    matrix.setScale(f2 * f1 / paramInt1, f1 * f3 / paramInt2, paramInt1 / 2.0F, paramInt2 / 2.0F);
    setTransform(matrix);
  }
  
  public void a(MediaPlayer.OnCompletionListener paramOnCompletionListener) {
    this.m = paramOnCompletionListener;
  }
  
  public void a(MediaPlayer.OnErrorListener paramOnErrorListener) {
    this.p = paramOnErrorListener;
  }
  
  public void a(MediaPlayer.OnPreparedListener paramOnPreparedListener) {
    this.n = paramOnPreparedListener;
  }
  
  public void a(Uri paramUri) {
    a(paramUri, (Map<String, String>)null);
  }
  
  public void a(Uri paramUri, Map<String, String> paramMap) {
    this.d = paramUri;
    this.e = paramMap;
    this.q = 0;
    g();
    requestLayout();
    invalidate();
  }
  
  public void b() {
    if (h() && this.j.isPlaying()) {
      this.j.pause();
      this.g = 4;
    } 
    this.h = 4;
  }
  
  public int c() {
    if (h()) {
      if (this.f > 0)
        return this.f; 
      this.f = this.j.getDuration();
      return this.f;
    } 
    this.f = -1;
    return this.f;
  }
  
  public int d() {
    return h() ? this.j.getCurrentPosition() : 0;
  }
  
  public boolean e() {
    return (h() && this.j.isPlaying());
  }
  
  public void onSurfaceTextureAvailable(SurfaceTexture paramSurfaceTexture, int paramInt1, int paramInt2) {
    this.i = new Surface(paramSurfaceTexture);
    g();
  }
  
  public boolean onSurfaceTextureDestroyed(SurfaceTexture paramSurfaceTexture) {
    this.i = null;
    a(true);
    return true;
  }
  
  public void onSurfaceTextureSizeChanged(SurfaceTexture paramSurfaceTexture, int paramInt1, int paramInt2) {
    if (this.h == 3) {
      paramInt1 = 1;
    } else {
      paramInt1 = 0;
    } 
    if (this.j != null && paramInt1 != 0) {
      if (this.q != 0)
        a(this.q); 
      a();
    } 
  }
  
  public void onSurfaceTextureUpdated(SurfaceTexture paramSurfaceTexture) {}
}


/* Location:              C:\soft\dex2jar-2.0\Smash Cricket-dex2jar.jar!\com\chartboost\sdk\impl\bf.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */