package com.chartboost.sdk.impl;

import java.util.Map;

public class i {
  public final int a;
  
  public final byte[] b;
  
  public final Map<String, String> c;
  
  public final boolean d;
  
  public i(int paramInt, byte[] paramArrayOfbyte, Map<String, String> paramMap, boolean paramBoolean) {
    this.a = paramInt;
    this.b = paramArrayOfbyte;
    this.c = paramMap;
    this.d = paramBoolean;
  }
  
  public i(byte[] paramArrayOfbyte, Map<String, String> paramMap) {
    this(200, paramArrayOfbyte, paramMap, false);
  }
}


/* Location:              C:\soft\dex2jar-2.0\Smash Cricket-dex2jar.jar!\com\chartboost\sdk\impl\i.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */