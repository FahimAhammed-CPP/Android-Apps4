package com.chartboost.sdk.impl;

import android.os.SystemClock;
import java.io.EOFException;
import java.io.File;
import java.io.FilterInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.util.Collections;
import java.util.HashMap;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.Map;

public class w implements b {
  private final Map<String, a> a = new LinkedHashMap<String, a>(16, 0.75F, true);
  
  private long b = 0L;
  
  private final File c;
  
  private final int d;
  
  public w(File paramFile) {
    this(paramFile, 5242880);
  }
  
  public w(File paramFile, int paramInt) {
    this.c = paramFile;
    this.d = paramInt;
  }
  
  static int a(InputStream paramInputStream) throws IOException {
    return 0x0 | e(paramInputStream) << 0 | e(paramInputStream) << 8 | e(paramInputStream) << 16 | e(paramInputStream) << 24;
  }
  
  private void a(int paramInt) {
    if (this.b + paramInt >= this.d) {
      if (t.b)
        t.a("Pruning old cache entries.", new Object[0]); 
      long l1 = this.b;
      long l2 = SystemClock.elapsedRealtime();
      Iterator<Map.Entry> iterator = this.a.entrySet().iterator();
      int i = 0;
      while (true) {
        if (iterator.hasNext()) {
          a a = (a)((Map.Entry)iterator.next()).getValue();
          if (c(a.b).delete()) {
            this.b -= a.a;
          } else {
            t.b("Could not delete cache entry for key=%s, filename=%s", new Object[] { a.b, d(a.b) });
          } 
          iterator.remove();
          int j = i + 1;
          i = j;
          if ((float)(this.b + paramInt) >= this.d * 0.9F) {
            i = j;
            continue;
          } 
        } 
        if (t.b) {
          t.a("pruned %d files, %d bytes, %d ms", new Object[] { Integer.valueOf(i), Long.valueOf(this.b - l1), Long.valueOf(SystemClock.elapsedRealtime() - l2) });
          return;
        } 
        return;
      } 
    } 
  }
  
  static void a(OutputStream paramOutputStream, int paramInt) throws IOException {
    paramOutputStream.write(paramInt >> 0 & 0xFF);
    paramOutputStream.write(paramInt >> 8 & 0xFF);
    paramOutputStream.write(paramInt >> 16 & 0xFF);
    paramOutputStream.write(paramInt >> 24 & 0xFF);
  }
  
  static void a(OutputStream paramOutputStream, long paramLong) throws IOException {
    paramOutputStream.write((byte)(int)(paramLong >>> 0L));
    paramOutputStream.write((byte)(int)(paramLong >>> 8L));
    paramOutputStream.write((byte)(int)(paramLong >>> 16L));
    paramOutputStream.write((byte)(int)(paramLong >>> 24L));
    paramOutputStream.write((byte)(int)(paramLong >>> 32L));
    paramOutputStream.write((byte)(int)(paramLong >>> 40L));
    paramOutputStream.write((byte)(int)(paramLong >>> 48L));
    paramOutputStream.write((byte)(int)(paramLong >>> 56L));
  }
  
  static void a(OutputStream paramOutputStream, String paramString) throws IOException {
    byte[] arrayOfByte = paramString.getBytes("UTF-8");
    a(paramOutputStream, arrayOfByte.length);
    paramOutputStream.write(arrayOfByte, 0, arrayOfByte.length);
  }
  
  private void a(String paramString, a parama) {
    if (!this.a.containsKey(paramString)) {
      this.b += parama.a;
    } else {
      a a1 = this.a.get(paramString);
      long l = this.b;
      this.b = parama.a - a1.a + l;
    } 
    this.a.put(paramString, parama);
  }
  
  static void a(Map<String, String> paramMap, OutputStream paramOutputStream) throws IOException {
    if (paramMap != null) {
      a(paramOutputStream, paramMap.size());
      Iterator<Map.Entry> iterator = paramMap.entrySet().iterator();
      while (true) {
        if (!iterator.hasNext())
          return; 
        Map.Entry entry = iterator.next();
        a(paramOutputStream, (String)entry.getKey());
        a(paramOutputStream, (String)entry.getValue());
      } 
    } 
    a(paramOutputStream, 0);
  }
  
  private static byte[] a(InputStream paramInputStream, int paramInt) throws IOException {
    byte[] arrayOfByte = new byte[paramInt];
    int i = 0;
    while (true) {
      if (i < paramInt) {
        int j = paramInputStream.read(arrayOfByte, i, paramInt - i);
        if (j != -1) {
          i += j;
          continue;
        } 
      } 
      if (i != paramInt)
        throw new IOException("Expected " + paramInt + " bytes, read " + i + " bytes"); 
      return arrayOfByte;
    } 
  }
  
  static long b(InputStream paramInputStream) throws IOException {
    return 0x0L | (e(paramInputStream) & 0xFFL) << 0L | (e(paramInputStream) & 0xFFL) << 8L | (e(paramInputStream) & 0xFFL) << 16L | (e(paramInputStream) & 0xFFL) << 24L | (e(paramInputStream) & 0xFFL) << 32L | (e(paramInputStream) & 0xFFL) << 40L | (e(paramInputStream) & 0xFFL) << 48L | (e(paramInputStream) & 0xFFL) << 56L;
  }
  
  static String c(InputStream paramInputStream) throws IOException {
    return new String(a(paramInputStream, (int)b(paramInputStream)), "UTF-8");
  }
  
  private String d(String paramString) {
    int i = paramString.length() / 2;
    return String.valueOf(String.valueOf(paramString.substring(0, i).hashCode())) + String.valueOf(paramString.substring(i).hashCode());
  }
  
  static Map<String, String> d(InputStream paramInputStream) throws IOException {
    Map<?, ?> map;
    int j = a(paramInputStream);
    if (j == 0) {
      map = Collections.emptyMap();
    } else {
      map = new HashMap<Object, Object>(j);
    } 
    for (int i = 0;; i++) {
      if (i >= j)
        return (Map)map; 
      map.put(c(paramInputStream).intern(), c(paramInputStream).intern());
    } 
  }
  
  private static int e(InputStream paramInputStream) throws IOException {
    int i = paramInputStream.read();
    if (i == -1)
      throw new EOFException(); 
    return i;
  }
  
  private void e(String paramString) {
    a a = this.a.get(paramString);
    if (a != null) {
      this.b -= a.a;
      this.a.remove(paramString);
    } 
  }
  
  public b.a a(String paramString) {
    // Byte code:
    //   0: aload_0
    //   1: monitorenter
    //   2: aload_0
    //   3: getfield a : Ljava/util/Map;
    //   6: aload_1
    //   7: invokeinterface get : (Ljava/lang/Object;)Ljava/lang/Object;
    //   12: checkcast com/chartboost/sdk/impl/w$a
    //   15: astore #4
    //   17: aload #4
    //   19: ifnonnull -> 28
    //   22: aconst_null
    //   23: astore_1
    //   24: aload_0
    //   25: monitorexit
    //   26: aload_1
    //   27: areturn
    //   28: aload_0
    //   29: aload_1
    //   30: invokevirtual c : (Ljava/lang/String;)Ljava/io/File;
    //   33: astore #5
    //   35: new com/chartboost/sdk/impl/w$b
    //   38: dup
    //   39: new java/io/FileInputStream
    //   42: dup
    //   43: aload #5
    //   45: invokespecial <init> : (Ljava/io/File;)V
    //   48: aconst_null
    //   49: invokespecial <init> : (Ljava/io/InputStream;Lcom/chartboost/sdk/impl/w$b;)V
    //   52: astore_3
    //   53: aload_3
    //   54: astore_2
    //   55: aload_3
    //   56: invokestatic a : (Ljava/io/InputStream;)Lcom/chartboost/sdk/impl/w$a;
    //   59: pop
    //   60: aload_3
    //   61: astore_2
    //   62: aload #4
    //   64: aload_3
    //   65: aload #5
    //   67: invokevirtual length : ()J
    //   70: aload_3
    //   71: invokestatic a : (Lcom/chartboost/sdk/impl/w$b;)I
    //   74: i2l
    //   75: lsub
    //   76: l2i
    //   77: invokestatic a : (Ljava/io/InputStream;I)[B
    //   80: invokevirtual a : ([B)Lcom/chartboost/sdk/impl/b$a;
    //   83: astore #4
    //   85: aload #4
    //   87: astore_2
    //   88: aload_2
    //   89: astore_1
    //   90: aload_3
    //   91: ifnull -> 24
    //   94: aload_3
    //   95: invokevirtual close : ()V
    //   98: aload_2
    //   99: astore_1
    //   100: goto -> 24
    //   103: astore_1
    //   104: aconst_null
    //   105: astore_1
    //   106: goto -> 24
    //   109: astore #4
    //   111: aconst_null
    //   112: astore_3
    //   113: aload_3
    //   114: astore_2
    //   115: ldc_w '%s: %s'
    //   118: iconst_2
    //   119: anewarray java/lang/Object
    //   122: dup
    //   123: iconst_0
    //   124: aload #5
    //   126: invokevirtual getAbsolutePath : ()Ljava/lang/String;
    //   129: aastore
    //   130: dup
    //   131: iconst_1
    //   132: aload #4
    //   134: invokevirtual toString : ()Ljava/lang/String;
    //   137: aastore
    //   138: invokestatic b : (Ljava/lang/String;[Ljava/lang/Object;)V
    //   141: aload_3
    //   142: astore_2
    //   143: aload_0
    //   144: aload_1
    //   145: invokevirtual b : (Ljava/lang/String;)V
    //   148: aload_3
    //   149: ifnull -> 156
    //   152: aload_3
    //   153: invokevirtual close : ()V
    //   156: aconst_null
    //   157: astore_1
    //   158: goto -> 24
    //   161: astore_1
    //   162: aconst_null
    //   163: astore_1
    //   164: goto -> 24
    //   167: astore_1
    //   168: aconst_null
    //   169: astore_2
    //   170: aload_2
    //   171: ifnull -> 178
    //   174: aload_2
    //   175: invokevirtual close : ()V
    //   178: aload_1
    //   179: athrow
    //   180: astore_1
    //   181: aload_0
    //   182: monitorexit
    //   183: aload_1
    //   184: athrow
    //   185: astore_1
    //   186: aconst_null
    //   187: astore_1
    //   188: goto -> 24
    //   191: astore_1
    //   192: goto -> 170
    //   195: astore #4
    //   197: goto -> 113
    // Exception table:
    //   from	to	target	type
    //   2	17	180	finally
    //   28	35	180	finally
    //   35	53	109	java/io/IOException
    //   35	53	167	finally
    //   55	60	195	java/io/IOException
    //   55	60	191	finally
    //   62	85	195	java/io/IOException
    //   62	85	191	finally
    //   94	98	103	java/io/IOException
    //   94	98	180	finally
    //   115	141	191	finally
    //   143	148	191	finally
    //   152	156	161	java/io/IOException
    //   152	156	180	finally
    //   174	178	185	java/io/IOException
    //   174	178	180	finally
    //   178	180	180	finally
  }
  
  public void a() {
    // Byte code:
    //   0: aload_0
    //   1: monitorenter
    //   2: aload_0
    //   3: getfield c : Ljava/io/File;
    //   6: invokevirtual exists : ()Z
    //   9: ifne -> 45
    //   12: aload_0
    //   13: getfield c : Ljava/io/File;
    //   16: invokevirtual mkdirs : ()Z
    //   19: ifne -> 42
    //   22: ldc_w 'Unable to create cache dir %s'
    //   25: iconst_1
    //   26: anewarray java/lang/Object
    //   29: dup
    //   30: iconst_0
    //   31: aload_0
    //   32: getfield c : Ljava/io/File;
    //   35: invokevirtual getAbsolutePath : ()Ljava/lang/String;
    //   38: aastore
    //   39: invokestatic c : (Ljava/lang/String;[Ljava/lang/Object;)V
    //   42: aload_0
    //   43: monitorexit
    //   44: return
    //   45: aload_0
    //   46: getfield c : Ljava/io/File;
    //   49: invokevirtual listFiles : ()[Ljava/io/File;
    //   52: astore #5
    //   54: aload #5
    //   56: ifnull -> 42
    //   59: aload #5
    //   61: arraylength
    //   62: istore_2
    //   63: iconst_0
    //   64: istore_1
    //   65: iload_1
    //   66: iload_2
    //   67: if_icmpge -> 42
    //   70: aload #5
    //   72: iload_1
    //   73: aaload
    //   74: astore #6
    //   76: aconst_null
    //   77: astore_3
    //   78: new java/io/FileInputStream
    //   81: dup
    //   82: aload #6
    //   84: invokespecial <init> : (Ljava/io/File;)V
    //   87: astore #4
    //   89: aload #4
    //   91: astore_3
    //   92: aload #4
    //   94: invokestatic a : (Ljava/io/InputStream;)Lcom/chartboost/sdk/impl/w$a;
    //   97: astore #7
    //   99: aload #4
    //   101: astore_3
    //   102: aload #7
    //   104: aload #6
    //   106: invokevirtual length : ()J
    //   109: putfield a : J
    //   112: aload #4
    //   114: astore_3
    //   115: aload_0
    //   116: aload #7
    //   118: getfield b : Ljava/lang/String;
    //   121: aload #7
    //   123: invokespecial a : (Ljava/lang/String;Lcom/chartboost/sdk/impl/w$a;)V
    //   126: aload #4
    //   128: ifnull -> 136
    //   131: aload #4
    //   133: invokevirtual close : ()V
    //   136: iload_1
    //   137: iconst_1
    //   138: iadd
    //   139: istore_1
    //   140: goto -> 65
    //   143: astore_3
    //   144: aconst_null
    //   145: astore #4
    //   147: aload #6
    //   149: ifnull -> 161
    //   152: aload #4
    //   154: astore_3
    //   155: aload #6
    //   157: invokevirtual delete : ()Z
    //   160: pop
    //   161: aload #4
    //   163: ifnull -> 136
    //   166: aload #4
    //   168: invokevirtual close : ()V
    //   171: goto -> 136
    //   174: astore_3
    //   175: goto -> 136
    //   178: astore #5
    //   180: aload_3
    //   181: astore #4
    //   183: aload #5
    //   185: astore_3
    //   186: aload #4
    //   188: ifnull -> 196
    //   191: aload #4
    //   193: invokevirtual close : ()V
    //   196: aload_3
    //   197: athrow
    //   198: astore_3
    //   199: aload_0
    //   200: monitorexit
    //   201: aload_3
    //   202: athrow
    //   203: astore #4
    //   205: goto -> 196
    //   208: astore_3
    //   209: goto -> 136
    //   212: astore #5
    //   214: aload_3
    //   215: astore #4
    //   217: aload #5
    //   219: astore_3
    //   220: goto -> 186
    //   223: astore_3
    //   224: goto -> 147
    // Exception table:
    //   from	to	target	type
    //   2	42	198	finally
    //   45	54	198	finally
    //   59	63	198	finally
    //   78	89	143	java/io/IOException
    //   78	89	178	finally
    //   92	99	223	java/io/IOException
    //   92	99	212	finally
    //   102	112	223	java/io/IOException
    //   102	112	212	finally
    //   115	126	223	java/io/IOException
    //   115	126	212	finally
    //   131	136	208	java/io/IOException
    //   131	136	198	finally
    //   155	161	212	finally
    //   166	171	174	java/io/IOException
    //   166	171	198	finally
    //   191	196	203	java/io/IOException
    //   191	196	198	finally
    //   196	198	198	finally
  }
  
  public void a(String paramString, b.a parama) {
    // Byte code:
    //   0: aload_0
    //   1: monitorenter
    //   2: aload_0
    //   3: aload_2
    //   4: getfield a : [B
    //   7: arraylength
    //   8: invokespecial a : (I)V
    //   11: aload_0
    //   12: aload_1
    //   13: invokevirtual c : (Ljava/lang/String;)Ljava/io/File;
    //   16: astore_3
    //   17: new java/io/FileOutputStream
    //   20: dup
    //   21: aload_3
    //   22: invokespecial <init> : (Ljava/io/File;)V
    //   25: astore #4
    //   27: new com/chartboost/sdk/impl/w$a
    //   30: dup
    //   31: aload_1
    //   32: aload_2
    //   33: invokespecial <init> : (Ljava/lang/String;Lcom/chartboost/sdk/impl/b$a;)V
    //   36: astore #5
    //   38: aload #5
    //   40: aload #4
    //   42: invokevirtual a : (Ljava/io/OutputStream;)Z
    //   45: ifne -> 106
    //   48: aload #4
    //   50: invokevirtual close : ()V
    //   53: ldc_w 'Failed to write header for %s'
    //   56: iconst_1
    //   57: anewarray java/lang/Object
    //   60: dup
    //   61: iconst_0
    //   62: aload_3
    //   63: invokevirtual getAbsolutePath : ()Ljava/lang/String;
    //   66: aastore
    //   67: invokestatic b : (Ljava/lang/String;[Ljava/lang/Object;)V
    //   70: new java/io/IOException
    //   73: dup
    //   74: invokespecial <init> : ()V
    //   77: athrow
    //   78: astore_1
    //   79: aload_3
    //   80: invokevirtual delete : ()Z
    //   83: ifne -> 103
    //   86: ldc_w 'Could not clean up file %s'
    //   89: iconst_1
    //   90: anewarray java/lang/Object
    //   93: dup
    //   94: iconst_0
    //   95: aload_3
    //   96: invokevirtual getAbsolutePath : ()Ljava/lang/String;
    //   99: aastore
    //   100: invokestatic b : (Ljava/lang/String;[Ljava/lang/Object;)V
    //   103: aload_0
    //   104: monitorexit
    //   105: return
    //   106: aload #4
    //   108: aload_2
    //   109: getfield a : [B
    //   112: invokevirtual write : ([B)V
    //   115: aload #4
    //   117: invokevirtual close : ()V
    //   120: aload_0
    //   121: aload_1
    //   122: aload #5
    //   124: invokespecial a : (Ljava/lang/String;Lcom/chartboost/sdk/impl/w$a;)V
    //   127: goto -> 103
    //   130: astore_1
    //   131: aload_0
    //   132: monitorexit
    //   133: aload_1
    //   134: athrow
    // Exception table:
    //   from	to	target	type
    //   2	17	130	finally
    //   17	78	78	java/io/IOException
    //   17	78	130	finally
    //   79	103	130	finally
    //   106	127	78	java/io/IOException
    //   106	127	130	finally
  }
  
  public void b(String paramString) {
    // Byte code:
    //   0: aload_0
    //   1: monitorenter
    //   2: aload_0
    //   3: aload_1
    //   4: invokevirtual c : (Ljava/lang/String;)Ljava/io/File;
    //   7: invokevirtual delete : ()Z
    //   10: istore_2
    //   11: aload_0
    //   12: aload_1
    //   13: invokespecial e : (Ljava/lang/String;)V
    //   16: iload_2
    //   17: ifne -> 41
    //   20: ldc 'Could not delete cache entry for key=%s, filename=%s'
    //   22: iconst_2
    //   23: anewarray java/lang/Object
    //   26: dup
    //   27: iconst_0
    //   28: aload_1
    //   29: aastore
    //   30: dup
    //   31: iconst_1
    //   32: aload_0
    //   33: aload_1
    //   34: invokespecial d : (Ljava/lang/String;)Ljava/lang/String;
    //   37: aastore
    //   38: invokestatic b : (Ljava/lang/String;[Ljava/lang/Object;)V
    //   41: aload_0
    //   42: monitorexit
    //   43: return
    //   44: astore_1
    //   45: aload_0
    //   46: monitorexit
    //   47: aload_1
    //   48: athrow
    // Exception table:
    //   from	to	target	type
    //   2	16	44	finally
    //   20	41	44	finally
  }
  
  public File c(String paramString) {
    return new File(this.c, d(paramString));
  }
  
  static class a {
    public long a;
    
    public String b;
    
    public String c;
    
    public long d;
    
    public long e;
    
    public long f;
    
    public Map<String, String> g;
    
    private a() {}
    
    public a(String param1String, b.a param1a) {
      this.b = param1String;
      this.a = param1a.a.length;
      this.c = param1a.b;
      this.d = param1a.c;
      this.e = param1a.d;
      this.f = param1a.e;
      this.g = param1a.f;
    }
    
    public static a a(InputStream param1InputStream) throws IOException {
      a a1 = new a();
      if (w.a(param1InputStream) != 538183203)
        throw new IOException(); 
      a1.b = w.c(param1InputStream);
      a1.c = w.c(param1InputStream);
      if (a1.c.equals(""))
        a1.c = null; 
      a1.d = w.b(param1InputStream);
      a1.e = w.b(param1InputStream);
      a1.f = w.b(param1InputStream);
      a1.g = w.d(param1InputStream);
      return a1;
    }
    
    public b.a a(byte[] param1ArrayOfbyte) {
      b.a a1 = new b.a();
      a1.a = param1ArrayOfbyte;
      a1.b = this.c;
      a1.c = this.d;
      a1.d = this.e;
      a1.e = this.f;
      a1.f = this.g;
      return a1;
    }
    
    public boolean a(OutputStream param1OutputStream) {
      try {
        w.a(param1OutputStream, 538183203);
        w.a(param1OutputStream, this.b);
        if (this.c == null) {
          String str1 = "";
          w.a(param1OutputStream, str1);
          w.a(param1OutputStream, this.d);
          w.a(param1OutputStream, this.e);
          w.a(param1OutputStream, this.f);
          w.a(this.g, param1OutputStream);
          param1OutputStream.flush();
          return true;
        } 
        String str = this.c;
        w.a(param1OutputStream, str);
        w.a(param1OutputStream, this.d);
        w.a(param1OutputStream, this.e);
        w.a(param1OutputStream, this.f);
        w.a(this.g, param1OutputStream);
        param1OutputStream.flush();
        return true;
      } catch (IOException iOException) {
        t.b("%s", new Object[] { iOException.toString() });
        return false;
      } 
    }
  }
  
  private static class b extends FilterInputStream {
    private int a = 0;
    
    private b(InputStream param1InputStream) {
      super(param1InputStream);
    }
    
    public int read() throws IOException {
      int i = super.read();
      if (i != -1)
        this.a++; 
      return i;
    }
    
    public int read(byte[] param1ArrayOfbyte, int param1Int1, int param1Int2) throws IOException {
      param1Int1 = super.read(param1ArrayOfbyte, param1Int1, param1Int2);
      if (param1Int1 != -1)
        this.a += param1Int1; 
      return param1Int1;
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Smash Cricket-dex2jar.jar!\com\chartboost\sdk\impl\w.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */