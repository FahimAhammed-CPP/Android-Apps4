package com.chartboost.sdk.impl;

import android.os.Handler;
import java.util.concurrent.Executor;

public class e implements o {
  private final Executor a;
  
  public e(Handler paramHandler) {
    this.a = new Executor(this, paramHandler) {
        public void execute(Runnable param1Runnable) {
          this.b.post(param1Runnable);
        }
      };
  }
  
  public void a(l<?> paraml, n<?> paramn) {
    a(paraml, paramn, null);
  }
  
  public void a(l<?> paraml, n<?> paramn, Runnable paramRunnable) {
    paraml.v();
    paraml.a("post-response");
    this.a.execute(new a(this, paraml, paramn, paramRunnable));
  }
  
  public void a(l<?> paraml, s params) {
    paraml.a("post-error");
    n<?> n = n.a(params);
    this.a.execute(new a(this, paraml, n, null));
  }
  
  private class a implements Runnable {
    private final l b;
    
    private final n c;
    
    private final Runnable d;
    
    public a(e this$0, l param1l, n param1n, Runnable param1Runnable) {
      this.b = param1l;
      this.c = param1n;
      this.d = param1Runnable;
    }
    
    public void run() {
      if (this.b.h()) {
        this.b.b("canceled-at-delivery");
        return;
      } 
      if (this.c.a()) {
        this.b.b(this.c.a);
      } else {
        this.b.b(this.c.c);
      } 
      if (this.c.d) {
        this.b.a("intermediate-response");
      } else {
        this.b.b("done");
      } 
      if (this.d != null) {
        this.d.run();
        return;
      } 
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Smash Cricket-dex2jar.jar!\com\chartboost\sdk\impl\e.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */