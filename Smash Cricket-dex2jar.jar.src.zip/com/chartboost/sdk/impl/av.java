package com.chartboost.sdk.impl;

import com.chartboost.sdk.Libraries.e;
import com.chartboost.sdk.Model.CBError;
import com.chartboost.sdk.Model.a;
import com.chartboost.sdk.Model.b;
import com.chartboost.sdk.b;
import com.chartboost.sdk.d;

public class av extends d {
  private static final String c = av.class.getSimpleName();
  
  private static av d;
  
  protected int b;
  
  private a e = null;
  
  private boolean f;
  
  private boolean g;
  
  public static av f() {
    // Byte code:
    //   0: getstatic com/chartboost/sdk/impl/av.d : Lcom/chartboost/sdk/impl/av;
    //   3: ifnonnull -> 28
    //   6: ldc com/chartboost/sdk/impl/av
    //   8: monitorenter
    //   9: getstatic com/chartboost/sdk/impl/av.d : Lcom/chartboost/sdk/impl/av;
    //   12: ifnonnull -> 25
    //   15: new com/chartboost/sdk/impl/av
    //   18: dup
    //   19: invokespecial <init> : ()V
    //   22: putstatic com/chartboost/sdk/impl/av.d : Lcom/chartboost/sdk/impl/av;
    //   25: ldc com/chartboost/sdk/impl/av
    //   27: monitorexit
    //   28: getstatic com/chartboost/sdk/impl/av.d : Lcom/chartboost/sdk/impl/av;
    //   31: areturn
    //   32: astore_0
    //   33: ldc com/chartboost/sdk/impl/av
    //   35: monitorexit
    //   36: aload_0
    //   37: athrow
    // Exception table:
    //   from	to	target	type
    //   9	25	32	finally
    //   25	28	32	finally
    //   33	36	32	finally
  }
  
  protected a a(String paramString, boolean paramBoolean) {
    return new a(a.c.b, paramBoolean, paramString, false);
  }
  
  public void a() {
    this.e = null;
  }
  
  protected void a(a parama, e.a parama1) {
    if (!this.f && this.g) {
      this.g = false;
      this.b = parama1.a("cells").o();
    } 
    super.a(parama, parama1);
  }
  
  public void a(String paramString) {
    this.b = 0;
    g();
    super.a(paramString);
  }
  
  protected d.a c() {
    return new d.a(this) {
        public void a(a param1a) {
          if (b.f() != null)
            b.f().didClickMoreApps(param1a.d); 
        }
        
        public void a(a param1a, CBError.CBImpressionError param1CBImpressionError) {
          if (b.f() != null)
            b.f().didFailToLoadMoreApps(param1a.d, param1CBImpressionError); 
        }
        
        public void b(a param1a) {
          if (b.f() != null)
            b.f().didCloseMoreApps(param1a.d); 
        }
        
        public void c(a param1a) {
          if (b.f() != null)
            b.f().didDismissMoreApps(param1a.d); 
        }
        
        public void d(a param1a) {
          if (b.f() != null)
            b.f().didCacheMoreApps(param1a.d); 
        }
        
        public void e(a param1a) {
          this.a.b = 0;
          this.a.g();
          if (b.f() != null)
            b.f().didDisplayMoreApps(param1a.d); 
        }
        
        public boolean f(a param1a) {
          return (b.f() != null) ? b.f().shouldDisplayMoreApps(param1a.d) : true;
        }
        
        public boolean g(a param1a) {
          return (b.f() != null) ? b.f().shouldRequestMoreApps(param1a.d) : true;
        }
        
        public boolean h(a param1a) {
          return true;
        }
      };
  }
  
  protected a d(String paramString) {
    return this.e;
  }
  
  protected az e(a parama) {
    az az = new az("/more/get");
    az.a(l.a.c);
    az.a(b.c);
    return az;
  }
  
  public String e() {
    return "more-apps";
  }
  
  protected void e(String paramString) {
    this.e = null;
  }
  
  protected void g() {}
  
  protected az l(a parama) {
    az az = new az("/more/show");
    if (parama.d != null)
      az.a("location", parama.d); 
    if (parama.w().c("cells"))
      az.a("cells", parama.w().a("cells")); 
    return az;
  }
  
  protected void q(a parama) {
    this.e = parama;
  }
}


/* Location:              C:\soft\dex2jar-2.0\Smash Cricket-dex2jar.jar!\com\chartboost\sdk\impl\av.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */