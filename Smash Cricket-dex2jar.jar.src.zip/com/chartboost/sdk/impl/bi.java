package com.chartboost.sdk.impl;

import android.content.Context;
import android.view.View;

public final class bi extends View {
  private boolean a = false;
  
  public bi(Context paramContext) {
    super(paramContext);
    setFocusable(false);
    setBackgroundColor(-1442840576);
  }
  
  public void a() {
    if (!this.a) {
      bh.a(true, this);
      this.a = true;
    } 
  }
}


/* Location:              C:\soft\dex2jar-2.0\Smash Cricket-dex2jar.jar!\com\chartboost\sdk\impl\bi.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */