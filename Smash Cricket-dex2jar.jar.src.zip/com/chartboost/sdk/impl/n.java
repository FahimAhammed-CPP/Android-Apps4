package com.chartboost.sdk.impl;

public class n<T> {
  public final T a = null;
  
  public final b.a b = null;
  
  public final s c;
  
  public boolean d = false;
  
  private n(s params) {
    this.c = params;
  }
  
  private n(T paramT, b.a parama) {
    this.c = null;
  }
  
  public static <T> n<T> a(s params) {
    return new n<T>(params);
  }
  
  public static <T> n<T> a(T paramT, b.a parama) {
    return new n<T>(paramT, parama);
  }
  
  public boolean a() {
    return (this.c == null);
  }
  
  public static interface a {
    void a(s param1s);
  }
  
  public static interface b<T> {
    void a(T param1T);
  }
}


/* Location:              C:\soft\dex2jar-2.0\Smash Cricket-dex2jar.jar!\com\chartboost\sdk\impl\n.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */