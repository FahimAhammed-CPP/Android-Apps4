package com.chartboost.sdk.impl;

import android.app.AlertDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import java.util.ArrayList;

public class bl {
  private static final String[] a = new String[] { "arg:left", "arg:center", "arg:right" };
  
  private b b;
  
  public bl(Context paramContext, Bundle paramBundle, b paramb) {
    AlertDialog alertDialog;
    this.b = paramb;
    String str1 = paramBundle.getString("arg:title");
    String str2 = paramBundle.getString("arg:message");
    int j = paramBundle.getInt("arg:default", -1);
    ArrayList<String> arrayList = new ArrayList();
    int i;
    for (i = 0; i < 3; i++) {
      String str = paramBundle.getString(a[i]);
      if (!TextUtils.isEmpty(str))
        arrayList.add(str); 
    } 
    AlertDialog.Builder builder = (new AlertDialog.Builder(paramContext)).setTitle(str1).setMessage(str2);
    i = arrayList.size();
    switch (i) {
      default:
        alertDialog = builder.create();
        alertDialog.setOnShowListener(new DialogInterface.OnShowListener(this, alertDialog, i, arrayList, j) {
              public void onShow(DialogInterface param1DialogInterface) {
                Button[] arrayOfButton = bl.a(this.a);
                for (int i = 0; i < this.b; i++) {
                  CharSequence charSequence = this.c.get(i);
                  Button button = arrayOfButton[i];
                  if (this.d == i)
                    button.setTypeface(null, 1); 
                  button.setText(charSequence);
                  button.setOnClickListener(new View.OnClickListener(this, i) {
                        public void onClick(View param2View) {
                          if (bl.a(this.b.e) != null)
                            bl.a(this.b.e).a(this.b.e, this.a); 
                          this.b.a.dismiss();
                        }
                      });
                } 
              }
            });
        alertDialog.setOnCancelListener(new DialogInterface.OnCancelListener(this) {
              public void onCancel(DialogInterface param1DialogInterface) {
                bl.a(this.a).a(this.a);
              }
            });
        alertDialog.show();
        return;
      case 3:
        alertDialog.setNegativeButton(arrayList.get(2), null);
      case 2:
        alertDialog.setNeutralButton(arrayList.get(1), null);
        break;
      case 1:
        break;
    } 
    alertDialog.setPositiveButton(arrayList.get(0), null);
  }
  
  private static final Button[] b(AlertDialog paramAlertDialog) {
    ViewGroup viewGroup = (ViewGroup)paramAlertDialog.getButton(-1).getParent();
    int j = viewGroup.getChildCount();
    ArrayList<Button> arrayList = new ArrayList();
    for (int i = 0; i < j; i++) {
      View view = viewGroup.getChildAt(i);
      if (view.getVisibility() == 0 && view instanceof Button)
        arrayList.add((Button)view); 
    } 
    Button[] arrayOfButton = new Button[arrayList.size()];
    arrayList.toArray(arrayOfButton);
    return arrayOfButton;
  }
  
  public static class a {
    private final Bundle a = new Bundle();
    
    public a a(String param1String) {
      this.a.putString("arg:title", param1String);
      return this;
    }
    
    public bl a(Context param1Context, bl.b param1b) {
      return new bl(param1Context, this.a, param1b);
    }
    
    public a b(String param1String) {
      this.a.putString("arg:message", param1String);
      return this;
    }
    
    public a c(String param1String) {
      this.a.putString("arg:left", param1String);
      return this;
    }
    
    public a d(String param1String) {
      this.a.putString("arg:right", param1String);
      return this;
    }
  }
  
  public static abstract class b {
    public void a(bl param1bl) {}
    
    public abstract void a(bl param1bl, int param1Int);
  }
}


/* Location:              C:\soft\dex2jar-2.0\Smash Cricket-dex2jar.jar!\com\chartboost\sdk\impl\bl.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */