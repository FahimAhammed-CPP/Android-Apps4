package com.chartboost.sdk.impl;

import android.annotation.SuppressLint;
import android.content.Context;
import android.graphics.Point;
import android.media.MediaPlayer;
import android.net.Uri;
import android.os.Handler;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.view.animation.AlphaAnimation;
import android.view.animation.Animation;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;
import android.widget.TextView;
import com.chartboost.sdk.Libraries.CBUtility;
import com.chartboost.sdk.Libraries.e;
import com.chartboost.sdk.Libraries.j;
import com.chartboost.sdk.Tracking.a;

public final class ao extends RelativeLayout implements MediaPlayer.OnCompletionListener, MediaPlayer.OnErrorListener, MediaPlayer.OnPreparedListener {
  private static final CharSequence a = "00:00";
  
  private static Handler l = CBUtility.e();
  
  private RelativeLayout b;
  
  private an c;
  
  private an d;
  
  private bk e;
  
  private TextView f;
  
  private ak g;
  
  private bg h;
  
  private ai i;
  
  private boolean j = false;
  
  private boolean k = false;
  
  private Runnable m = new Runnable(this) {
      public void run() {
        ao.a(this.a, false);
      }
    };
  
  private Runnable n = new Runnable(this) {
      public void run() {
        if (ao.b(this.a) != null)
          ao.b(this.a).setVisibility(8); 
        if ((ao.a(this.a)).J)
          ao.c(this.a).setVisibility(8); 
        ao.d(this.a).setVisibility(8);
        if (ao.e(this.a) != null)
          ao.e(this.a).setEnabled(false); 
      }
    };
  
  private Runnable o = new Runnable(this) {
      private int b = 0;
      
      public void run() {
        if (ao.f(this.a).b().e()) {
          int i = ao.f(this.a).b().d();
          if (i > 0) {
            (ao.a(this.a)).t = i;
            float f1 = (ao.a(this.a)).t;
            if (ao.f(this.a).b().e() && f1 / 1000.0F > 0.0F && !ao.a(this.a).s()) {
              ao.a(this.a).q();
              ao.a(this.a).a(true);
            } 
          } 
          float f = i / ao.f(this.a).b().c();
          if ((ao.a(this.a)).J)
            ao.c(this.a).a(f); 
          i /= 1000;
          if (this.b != i) {
            this.b = i;
            int j = i / 60;
            ao.g(this.a).setText(String.format("%02d:%02d", new Object[] { Integer.valueOf(j), Integer.valueOf(i % 60) }));
          } 
        } 
        ai.a a = ao.a(this.a).p();
        if (a.g()) {
          bk bk = a.b(true);
          if (bk.getVisibility() == 8) {
            ao.a(this.a).a(true, (View)bk);
            bk.setEnabled(true);
          } 
        } 
        ao.j().removeCallbacks(ao.h(this.a));
        ao.j().postDelayed(ao.h(this.a), 16L);
      }
    };
  
  public ao(Context paramContext, ai paramai) {
    super(paramContext);
    this.i = paramai;
    a(paramContext);
  }
  
  private void a(Context paramContext) {
    paramContext = getContext();
    e.a a = this.i.g();
    float f = (getContext().getResources().getDisplayMetrics()).density;
    int i = Math.round(f * 10.0F);
    this.h = new bg(paramContext);
    this.i.p().a((View)this.h);
    RelativeLayout.LayoutParams layoutParams5 = new RelativeLayout.LayoutParams(-1, -2);
    layoutParams5.addRule(13);
    addView((View)this.h, (ViewGroup.LayoutParams)layoutParams5);
    this.b = new RelativeLayout(paramContext);
    if (a.c() && a.a("video-click-button").c()) {
      this.c = new an(paramContext);
      this.c.setVisibility(8);
      this.e = new bk(this, paramContext) {
          protected void a(MotionEvent param1MotionEvent) {
            e.a a = e.a(new e.b[] { e.a("paused", Integer.valueOf(1)) });
            ao.a(this.a).a((String)null, a);
            a.a("install-button", (ao.a(this.a)).s, (ao.a(this.a)).n, Math.round(param1MotionEvent.getX()), Math.round(param1MotionEvent.getY()));
          }
        };
      this.e.a(ImageView.ScaleType.FIT_CENTER);
      j j = this.i.F;
      Point point = this.i.b("video-click-button");
      LinearLayout.LayoutParams layoutParams6 = new LinearLayout.LayoutParams(-2, -2);
      layoutParams6.leftMargin = Math.round(point.x / j.g());
      layoutParams6.topMargin = Math.round(point.y / j.g());
      this.i.a((ViewGroup.LayoutParams)layoutParams6, j, 1.0F);
      this.e.a(j);
      this.c.addView((View)this.e, (ViewGroup.LayoutParams)layoutParams6);
      RelativeLayout.LayoutParams layoutParams = new RelativeLayout.LayoutParams(-1, Math.round(layoutParams6.height + 10.0F * f));
      layoutParams.addRule(10);
      this.b.addView((View)this.c, (ViewGroup.LayoutParams)layoutParams);
    } 
    this.d = new an(paramContext);
    this.d.setVisibility(8);
    RelativeLayout.LayoutParams layoutParams4 = new RelativeLayout.LayoutParams(-1, Math.round(32.5F * f));
    layoutParams4.addRule(12);
    this.b.addView((View)this.d, (ViewGroup.LayoutParams)layoutParams4);
    this.d.setGravity(16);
    this.d.setPadding(i, i, i, i);
    this.f = new TextView(paramContext);
    this.f.setTextColor(-1);
    this.f.setTextSize(2, 11.0F);
    this.f.setText(a);
    this.f.setPadding(0, 0, i, 0);
    this.f.setSingleLine();
    this.f.measure(0, 0);
    i = this.f.getMeasuredWidth();
    this.f.setGravity(17);
    LinearLayout.LayoutParams layoutParams3 = new LinearLayout.LayoutParams(i, -1);
    this.d.addView((View)this.f, (ViewGroup.LayoutParams)layoutParams3);
    this.g = new ak(paramContext);
    this.g.setVisibility(8);
    LinearLayout.LayoutParams layoutParams2 = new LinearLayout.LayoutParams(-1, Math.round(10.0F * f));
    layoutParams2.setMargins(0, CBUtility.a(1, getContext()), 0, 0);
    this.d.addView(this.g, (ViewGroup.LayoutParams)layoutParams2);
    RelativeLayout.LayoutParams layoutParams1 = new RelativeLayout.LayoutParams(-1, -1);
    layoutParams1.addRule(6, this.h.getId());
    layoutParams1.addRule(8, this.h.getId());
    layoutParams1.addRule(5, this.h.getId());
    layoutParams1.addRule(7, this.h.getId());
    addView((View)this.b, (ViewGroup.LayoutParams)layoutParams1);
    a();
  }
  
  private void d(boolean paramBoolean) {
    boolean bool;
    if (!this.j) {
      bool = true;
    } else {
      bool = false;
    } 
    a(bool, paramBoolean);
  }
  
  public void a() {
    b(CBUtility.c().b());
  }
  
  public void a(int paramInt) {
    if (this.c != null)
      this.c.setBackgroundColor(paramInt); 
    this.d.setBackgroundColor(paramInt);
  }
  
  public void a(String paramString) {
    this.h.b().a(this);
    this.h.b().a(this);
    this.h.b().a(this);
    this.h.b().a(Uri.parse(paramString));
  }
  
  public void a(boolean paramBoolean) {
    l.removeCallbacks(this.m);
    l.removeCallbacks(this.n);
    if (paramBoolean) {
      if (!this.k && this.c != null)
        this.c.setVisibility(0); 
      if (this.i.J)
        this.g.setVisibility(0); 
      this.d.setVisibility(0);
      if (this.e != null)
        this.e.setEnabled(true); 
    } else {
      if (this.c != null) {
        this.c.clearAnimation();
        this.c.setVisibility(8);
      } 
      this.d.clearAnimation();
      if (this.i.J)
        this.g.setVisibility(8); 
      this.d.setVisibility(8);
      if (this.e != null)
        this.e.setEnabled(false); 
    } 
    this.j = paramBoolean;
  }
  
  protected void a(boolean paramBoolean1, boolean paramBoolean2) {
    l.removeCallbacks(this.m);
    l.removeCallbacks(this.n);
    if (this.i.v && this.i.o() && paramBoolean1 != this.j) {
      long l;
      AlphaAnimation alphaAnimation;
      this.j = paramBoolean1;
      if (this.j) {
        alphaAnimation = new AlphaAnimation(0.0F, 1.0F);
      } else {
        alphaAnimation = new AlphaAnimation(1.0F, 0.0F);
      } 
      if (paramBoolean2) {
        l = 100L;
      } else {
        l = 200L;
      } 
      alphaAnimation.setDuration(l);
      alphaAnimation.setFillAfter(true);
      if (!this.k && this.c != null) {
        this.c.setVisibility(0);
        this.c.startAnimation((Animation)alphaAnimation);
        if (this.e != null)
          this.e.setEnabled(true); 
      } 
      if (this.i.J)
        this.g.setVisibility(0); 
      this.d.setVisibility(0);
      this.d.startAnimation((Animation)alphaAnimation);
      if (this.j) {
        l.postDelayed(this.m, 3000L);
        return;
      } 
      l.postDelayed(this.n, alphaAnimation.getDuration());
      return;
    } 
  }
  
  public bg.a b() {
    return this.h.b();
  }
  
  public void b(boolean paramBoolean) {
    boolean bool;
    if (paramBoolean) {
      bool = true;
    } else {
      bool = false;
    } 
    setBackgroundColor(bool);
    RelativeLayout.LayoutParams layoutParams = new RelativeLayout.LayoutParams(-1, -1);
    if (!paramBoolean) {
      layoutParams.addRule(6, this.h.getId());
      layoutParams.addRule(8, this.h.getId());
      layoutParams.addRule(5, this.h.getId());
      layoutParams.addRule(7, this.h.getId());
    } 
    this.b.setLayoutParams((ViewGroup.LayoutParams)layoutParams);
    if (this.c != null) {
      this.c.setGravity(19);
      this.c.requestLayout();
    } 
  }
  
  public ak c() {
    return this.g;
  }
  
  public void c(boolean paramBoolean) {
    byte b;
    TextView textView = this.f;
    if (paramBoolean) {
      b = 0;
    } else {
      b = 8;
    } 
    textView.setVisibility(b);
  }
  
  public void d() {
    if (this.c != null)
      this.c.setVisibility(8); 
    this.k = true;
    if (this.e != null)
      this.e.setEnabled(false); 
  }
  
  public void e() {
    if (!this.h.a())
      l.postDelayed(new Runnable(this) {
            public void run() {
              ao.f(this.a).setVisibility(0);
            }
          },  250L); 
    this.h.b().a();
    l.removeCallbacks(this.o);
    l.postDelayed(this.o, 16L);
  }
  
  public void f() {
    if (this.h.b().e()) {
      this.i.t = this.h.b().d();
      this.h.b().b();
    } 
    if ((this.i.p()).d.getVisibility() == 0)
      (this.i.p()).d.postInvalidate(); 
    l.removeCallbacks(this.o);
  }
  
  public void g() {
    if (this.h.b().e())
      this.i.t = this.h.b().d(); 
    this.h.b().b();
    l.removeCallbacks(this.o);
  }
  
  public void h() {
    if (!this.h.a()) {
      this.h.setVisibility(8);
      invalidate();
    } 
  }
  
  public boolean i() {
    return this.h.b().e();
  }
  
  public void onCompletion(MediaPlayer paramMediaPlayer) {
    this.i.t = this.h.b().c();
    if (this.i.p() != null)
      this.i.p().f(); 
  }
  
  public void onDetachedFromWindow() {
    super.onDetachedFromWindow();
    l.removeCallbacks(this.o);
  }
  
  public boolean onError(MediaPlayer paramMediaPlayer, int paramInt1, int paramInt2) {
    this.i.t();
    return false;
  }
  
  public void onPrepared(MediaPlayer paramMediaPlayer) {
    this.i.u = this.h.b().c();
    this.i.p().a(true);
  }
  
  @SuppressLint({"ClickableViewAccessibility"})
  public boolean onTouchEvent(MotionEvent paramMotionEvent) {
    if (this.h.b().e() && paramMotionEvent.getActionMasked() == 0) {
      if (this.i != null)
        a.e(this.i.s, this.i.n, this.j); 
      d(true);
      return true;
    } 
    return false;
  }
  
  public void setEnabled(boolean paramBoolean) {
    super.setEnabled(paramBoolean);
    if (this.e != null)
      this.e.setEnabled(paramBoolean); 
    if (paramBoolean)
      a(false); 
  }
}


/* Location:              C:\soft\dex2jar-2.0\Smash Cricket-dex2jar.jar!\com\chartboost\sdk\impl\ao.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */