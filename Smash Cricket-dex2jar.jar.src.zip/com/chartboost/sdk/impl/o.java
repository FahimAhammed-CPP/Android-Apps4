package com.chartboost.sdk.impl;

public interface o {
  void a(l<?> paraml, n<?> paramn);
  
  void a(l<?> paraml, n<?> paramn, Runnable paramRunnable);
  
  void a(l<?> paraml, s params);
}


/* Location:              C:\soft\dex2jar-2.0\Smash Cricket-dex2jar.jar!\com\chartboost\sdk\impl\o.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */