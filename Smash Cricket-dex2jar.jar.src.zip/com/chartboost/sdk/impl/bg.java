package com.chartboost.sdk.impl;

import android.app.Activity;
import android.content.Context;
import android.media.MediaPlayer;
import android.net.Uri;
import android.os.Build;
import android.view.SurfaceView;
import android.view.View;
import android.view.ViewGroup;
import android.widget.FrameLayout;
import com.chartboost.sdk.Chartboost;
import com.chartboost.sdk.Libraries.CBLogging;

public class bg extends FrameLayout {
  private View a;
  
  private boolean b;
  
  public bg(Context paramContext) {
    super(paramContext);
    d();
  }
  
  public static boolean a(Activity paramActivity) {
    if (c()) {
      if (Chartboost.getImpressionsUseActivities())
        return true; 
      try {
        return paramActivity.getWindow().getDecorView().isHardwareAccelerated();
      } catch (Exception exception) {}
    } 
    return false;
  }
  
  public static boolean c() {
    return (Build.VERSION.SDK_INT >= 14);
  }
  
  private void d() {
    String str;
    this.b = c();
    if (!Chartboost.getImpressionsUseActivities() && getContext() instanceof Activity)
      this.b = a((Activity)getContext()); 
    StringBuilder stringBuilder = (new StringBuilder()).append("Choosing ");
    if (this.b) {
      str = "texture";
    } else {
      str = "surface";
    } 
    CBLogging.e("VideoInit", stringBuilder.append(str).append(" solution for video playback").toString());
    if (this.b) {
      this.a = (View)new bf(getContext());
    } else {
      this.a = (View)new be(getContext());
    } 
    addView(this.a, (ViewGroup.LayoutParams)new FrameLayout.LayoutParams(-1, -1));
    if (!this.b)
      ((SurfaceView)this.a).setZOrderMediaOverlay(true); 
  }
  
  public boolean a() {
    return this.b;
  }
  
  public a b() {
    return (a)this.a;
  }
  
  public void onSizeChanged(int paramInt1, int paramInt2, int paramInt3, int paramInt4) {
    super.onSizeChanged(paramInt1, paramInt2, paramInt3, paramInt4);
    b().a(paramInt1, paramInt2);
  }
  
  public static interface a {
    void a();
    
    void a(int param1Int);
    
    void a(int param1Int1, int param1Int2);
    
    void a(MediaPlayer.OnCompletionListener param1OnCompletionListener);
    
    void a(MediaPlayer.OnErrorListener param1OnErrorListener);
    
    void a(MediaPlayer.OnPreparedListener param1OnPreparedListener);
    
    void a(Uri param1Uri);
    
    void b();
    
    int c();
    
    int d();
    
    boolean e();
  }
}


/* Location:              C:\soft\dex2jar-2.0\Smash Cricket-dex2jar.jar!\com\chartboost\sdk\impl\bg.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */