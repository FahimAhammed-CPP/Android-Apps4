package com.chartboost.sdk.impl;

import org.apache.http.impl.cookie.DateParseException;
import org.apache.http.impl.cookie.DateUtils;

public class y {
  public static long a(String paramString) {
    try {
      return DateUtils.parseDate(paramString).getTime();
    } catch (DateParseException dateParseException) {
      return 0L;
    } 
  }
  
  public static b.a a(i parami) {
    // Byte code:
    //   0: iconst_0
    //   1: istore_1
    //   2: lconst_0
    //   3: lstore #8
    //   5: invokestatic currentTimeMillis : ()J
    //   8: lstore #10
    //   10: aload_0
    //   11: getfield c : Ljava/util/Map;
    //   14: astore #12
    //   16: aload #12
    //   18: ldc 'Date'
    //   20: invokeinterface get : (Ljava/lang/Object;)Ljava/lang/Object;
    //   25: checkcast java/lang/String
    //   28: astore #13
    //   30: aload #13
    //   32: ifnull -> 331
    //   35: aload #13
    //   37: invokestatic a : (Ljava/lang/String;)J
    //   40: lstore #4
    //   42: aload #12
    //   44: ldc 'Cache-Control'
    //   46: invokeinterface get : (Ljava/lang/Object;)Ljava/lang/Object;
    //   51: checkcast java/lang/String
    //   54: astore #13
    //   56: aload #13
    //   58: ifnull -> 326
    //   61: aload #13
    //   63: ldc ','
    //   65: invokevirtual split : (Ljava/lang/String;)[Ljava/lang/String;
    //   68: astore #13
    //   70: iconst_0
    //   71: istore_1
    //   72: lconst_0
    //   73: lstore_2
    //   74: iload_1
    //   75: aload #13
    //   77: arraylength
    //   78: if_icmplt -> 194
    //   81: iconst_1
    //   82: istore_1
    //   83: aload #12
    //   85: ldc 'Expires'
    //   87: invokeinterface get : (Ljava/lang/Object;)Ljava/lang/Object;
    //   92: checkcast java/lang/String
    //   95: astore #13
    //   97: aload #13
    //   99: ifnull -> 320
    //   102: aload #13
    //   104: invokestatic a : (Ljava/lang/String;)J
    //   107: lstore #6
    //   109: aload #12
    //   111: ldc 'ETag'
    //   113: invokeinterface get : (Ljava/lang/Object;)Ljava/lang/Object;
    //   118: checkcast java/lang/String
    //   121: astore #13
    //   123: iload_1
    //   124: ifeq -> 282
    //   127: ldc2_w 1000
    //   130: lload_2
    //   131: lmul
    //   132: lload #10
    //   134: ladd
    //   135: lstore_2
    //   136: new com/chartboost/sdk/impl/b$a
    //   139: dup
    //   140: invokespecial <init> : ()V
    //   143: astore #14
    //   145: aload #14
    //   147: aload_0
    //   148: getfield b : [B
    //   151: putfield a : [B
    //   154: aload #14
    //   156: aload #13
    //   158: putfield b : Ljava/lang/String;
    //   161: aload #14
    //   163: lload_2
    //   164: putfield e : J
    //   167: aload #14
    //   169: aload #14
    //   171: getfield e : J
    //   174: putfield d : J
    //   177: aload #14
    //   179: lload #4
    //   181: putfield c : J
    //   184: aload #14
    //   186: aload #12
    //   188: putfield f : Ljava/util/Map;
    //   191: aload #14
    //   193: areturn
    //   194: aload #13
    //   196: iload_1
    //   197: aaload
    //   198: invokevirtual trim : ()Ljava/lang/String;
    //   201: astore #14
    //   203: aload #14
    //   205: ldc 'no-cache'
    //   207: invokevirtual equals : (Ljava/lang/Object;)Z
    //   210: ifne -> 223
    //   213: aload #14
    //   215: ldc 'no-store'
    //   217: invokevirtual equals : (Ljava/lang/Object;)Z
    //   220: ifeq -> 225
    //   223: aconst_null
    //   224: areturn
    //   225: aload #14
    //   227: ldc 'max-age='
    //   229: invokevirtual startsWith : (Ljava/lang/String;)Z
    //   232: ifeq -> 257
    //   235: aload #14
    //   237: bipush #8
    //   239: invokevirtual substring : (I)Ljava/lang/String;
    //   242: invokestatic parseLong : (Ljava/lang/String;)J
    //   245: lstore #6
    //   247: lload #6
    //   249: lstore_2
    //   250: iload_1
    //   251: iconst_1
    //   252: iadd
    //   253: istore_1
    //   254: goto -> 74
    //   257: aload #14
    //   259: ldc 'must-revalidate'
    //   261: invokevirtual equals : (Ljava/lang/Object;)Z
    //   264: ifne -> 277
    //   267: aload #14
    //   269: ldc 'proxy-revalidate'
    //   271: invokevirtual equals : (Ljava/lang/Object;)Z
    //   274: ifeq -> 250
    //   277: lconst_0
    //   278: lstore_2
    //   279: goto -> 250
    //   282: lload #8
    //   284: lstore_2
    //   285: lload #4
    //   287: lconst_0
    //   288: lcmp
    //   289: ifle -> 136
    //   292: lload #8
    //   294: lstore_2
    //   295: lload #6
    //   297: lload #4
    //   299: lcmp
    //   300: iflt -> 136
    //   303: lload #6
    //   305: lload #4
    //   307: lsub
    //   308: lload #10
    //   310: ladd
    //   311: lstore_2
    //   312: goto -> 136
    //   315: astore #14
    //   317: goto -> 250
    //   320: lconst_0
    //   321: lstore #6
    //   323: goto -> 109
    //   326: lconst_0
    //   327: lstore_2
    //   328: goto -> 83
    //   331: lconst_0
    //   332: lstore #4
    //   334: goto -> 42
    // Exception table:
    //   from	to	target	type
    //   235	247	315	java/lang/Exception
  }
}


/* Location:              C:\soft\dex2jar-2.0\Smash Cricket-dex2jar.jar!\com\chartboost\sdk\impl\y.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */