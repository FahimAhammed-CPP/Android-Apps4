package com.chartboost.sdk.impl;

import android.annotation.SuppressLint;
import android.content.Context;
import android.view.KeyEvent;
import android.view.View;
import android.view.ViewGroup;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.RelativeLayout;
import com.chartboost.sdk.Libraries.CBLogging;
import com.chartboost.sdk.Libraries.e;
import com.chartboost.sdk.Model.CBError;
import com.chartboost.sdk.f;
import java.net.URI;
import java.net.URLDecoder;
import org.json.JSONObject;
import org.json.JSONTokener;

public final class br extends f {
  private String k = null;
  
  public br(com.chartboost.sdk.Model.a parama) {
    super(parama);
  }
  
  public boolean a(e.a parama) {
    String str = parama.e("html");
    if (str == null) {
      a(CBError.CBImpressionError.INTERNAL);
      return false;
    } 
    this.k = str;
    b();
    return true;
  }
  
  protected f.a b(Context paramContext) {
    return new a(this, paramContext, this.k);
  }
  
  public class a extends f.a {
    public WebView b;
    
    public a(br this$0, Context param1Context, String param1String) {
      super(this$0, param1Context);
      setFocusable(false);
      this.b = new br.b(this$0, param1Context);
      this.b.setWebViewClient(new br.c());
      addView((View)this.b);
      this.b.loadDataWithBaseURL("file:///android_asset/", param1String, "text/html", "utf-8", null);
    }
    
    protected void a(int param1Int1, int param1Int2) {}
  }
  
  @SuppressLint({"SetJavaScriptEnabled"})
  private class b extends WebView {
    public b(br this$0, Context param1Context) {
      super(param1Context);
      setLayoutParams((ViewGroup.LayoutParams)new RelativeLayout.LayoutParams(-1, -1));
      setBackgroundColor(0);
      getSettings().setJavaScriptEnabled(true);
    }
    
    public boolean onKeyDown(int param1Int, KeyEvent param1KeyEvent) {
      if (param1Int == 4 || param1Int == 3)
        br.a(this.a); 
      return super.onKeyDown(param1Int, param1KeyEvent);
    }
  }
  
  private class c extends WebViewClient {
    private c(br this$0) {}
    
    public void onPageFinished(WebView param1WebView, String param1String) {
      super.onPageFinished(param1WebView, param1String);
      br.b(this.a);
    }
    
    public void onReceivedError(WebView param1WebView, int param1Int, String param1String1, String param1String2) {
      br.a(this.a, CBError.CBImpressionError.INTERNAL);
    }
    
    public boolean shouldOverrideUrlLoading(WebView param1WebView, String param1String) {
      Integer integer;
      Exception exception2 = null;
      CBLogging.e("CBWebViewProtocol", "loading url: " + param1String);
      try {
        String str = (new URI(param1String)).getScheme();
        if (str.equals("chartboost")) {
          String[] arrayOfString = param1String.split("/");
          integer = Integer.valueOf(arrayOfString.length);
          if (integer.intValue() < 3) {
            br.d(this.a);
            return false;
          } 
          param1String = arrayOfString[2];
          if (param1String.equals("close")) {
            br.e(this.a);
            return true;
          } 
        } else {
          return true;
        } 
      } catch (Exception exception1) {
        br.c(this.a);
        return false;
      } 
      if (param1String.equals("link")) {
        if (integer.intValue() < 4) {
          br.f(this.a);
          return false;
        } 
        try {
          param1String = URLDecoder.decode((String)exception1[3], "UTF-8");
          try {
            if (integer.intValue() > 4) {
              JSONObject jSONObject = new JSONObject(new JSONTokener(URLDecoder.decode((String)exception1[4], "UTF-8")));
            } else {
              exception1 = null;
            } 
            exception2 = exception1;
            String str = param1String;
            this.a.a(str, e.a.a(exception2));
          } catch (Exception exception4) {
            String str = param1String;
            Exception exception3 = exception4;
          } 
        } catch (Exception exception) {
          exception1 = null;
        } 
      } else {
        return true;
      } 
      this.a.a((String)exception1, e.a.a(exception2));
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Smash Cricket-dex2jar.jar!\com\chartboost\sdk\impl\br.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */