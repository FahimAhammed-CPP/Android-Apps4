package com.chartboost.sdk.impl;

public class h extends s {
  public h() {}
  
  public h(i parami) {
    super(parami);
  }
  
  public h(Throwable paramThrowable) {
    super(paramThrowable);
  }
}


/* Location:              C:\soft\dex2jar-2.0\Smash Cricket-dex2jar.jar!\com\chartboost\sdk\impl\h.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */