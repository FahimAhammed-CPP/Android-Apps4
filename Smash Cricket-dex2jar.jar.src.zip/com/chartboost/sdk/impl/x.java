package com.chartboost.sdk.impl;

import java.io.IOException;
import java.net.URI;
import java.util.Iterator;
import java.util.Map;
import org.apache.http.HttpEntity;
import org.apache.http.HttpResponse;
import org.apache.http.client.HttpClient;
import org.apache.http.client.methods.HttpDelete;
import org.apache.http.client.methods.HttpEntityEnclosingRequestBase;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.client.methods.HttpHead;
import org.apache.http.client.methods.HttpOptions;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.client.methods.HttpPut;
import org.apache.http.client.methods.HttpTrace;
import org.apache.http.client.methods.HttpUriRequest;
import org.apache.http.entity.ByteArrayEntity;
import org.apache.http.params.HttpConnectionParams;
import org.apache.http.params.HttpParams;

public class x implements z {
  protected final HttpClient a;
  
  public x(HttpClient paramHttpClient) {
    this.a = paramHttpClient;
  }
  
  private static void a(HttpEntityEnclosingRequestBase paramHttpEntityEnclosingRequestBase, l<?> paraml) throws a {
    byte[] arrayOfByte = paraml.q();
    if (arrayOfByte != null)
      paramHttpEntityEnclosingRequestBase.setEntity((HttpEntity)new ByteArrayEntity(arrayOfByte)); 
  }
  
  private static void a(HttpUriRequest paramHttpUriRequest, Map<String, String> paramMap) {
    Iterator<String> iterator = paramMap.keySet().iterator();
    while (true) {
      if (!iterator.hasNext())
        return; 
      String str = iterator.next();
      paramHttpUriRequest.setHeader(str, paramMap.get(str));
    } 
  }
  
  static HttpUriRequest b(l<?> paraml, Map<String, String> paramMap) throws a {
    byte[] arrayOfByte;
    HttpPost httpPost;
    HttpPut httpPut;
    switch (paraml.a()) {
      default:
        throw new IllegalStateException("Unknown request method.");
      case -1:
        arrayOfByte = paraml.m();
        if (arrayOfByte != null) {
          HttpPost httpPost1 = new HttpPost(paraml.d());
          httpPost1.addHeader("Content-Type", paraml.l());
          httpPost1.setEntity((HttpEntity)new ByteArrayEntity(arrayOfByte));
          return (HttpUriRequest)httpPost1;
        } 
        return (HttpUriRequest)new HttpGet(paraml.d());
      case 0:
        return (HttpUriRequest)new HttpGet(paraml.d());
      case 3:
        return (HttpUriRequest)new HttpDelete(paraml.d());
      case 1:
        httpPost = new HttpPost(paraml.d());
        httpPost.addHeader("Content-Type", paraml.p());
        a((HttpEntityEnclosingRequestBase)httpPost, paraml);
        return (HttpUriRequest)httpPost;
      case 2:
        httpPut = new HttpPut(paraml.d());
        httpPut.addHeader("Content-Type", paraml.p());
        a((HttpEntityEnclosingRequestBase)httpPut, paraml);
        return (HttpUriRequest)httpPut;
      case 4:
        return (HttpUriRequest)new HttpHead(paraml.d());
      case 5:
        return (HttpUriRequest)new HttpOptions(paraml.d());
      case 6:
        return (HttpUriRequest)new HttpTrace(paraml.d());
      case 7:
        break;
    } 
    a a = new a(paraml.d());
    a.addHeader("Content-Type", paraml.p());
    a(a, paraml);
    return (HttpUriRequest)a;
  }
  
  public HttpResponse a(l<?> paraml, Map<String, String> paramMap) throws IOException, a {
    HttpUriRequest httpUriRequest = b(paraml, paramMap);
    a(httpUriRequest, paramMap);
    a(httpUriRequest, paraml.i());
    a(httpUriRequest);
    HttpParams httpParams = httpUriRequest.getParams();
    int i = paraml.t();
    HttpConnectionParams.setConnectionTimeout(httpParams, 5000);
    HttpConnectionParams.setSoTimeout(httpParams, i);
    return this.a.execute(httpUriRequest);
  }
  
  protected void a(HttpUriRequest paramHttpUriRequest) throws IOException {}
  
  public static final class a extends HttpEntityEnclosingRequestBase {
    public a() {}
    
    public a(String param1String) {
      setURI(URI.create(param1String));
    }
    
    public String getMethod() {
      return "PATCH";
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Smash Cricket-dex2jar.jar!\com\chartboost\sdk\impl\x.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */