package com.chartboost.sdk.impl;

class bx extends bw {
  private dd<cb> a = new dd<cb>();
  
  void a(Class<?> paramClass, cb paramcb) {
    this.a.a(paramClass, paramcb);
  }
  
  public void a(Class<?> paramObject, StringBuilder paramStringBuilder) {
    cb cb;
    Object object = bt.a(paramObject);
    if (object == null) {
      paramStringBuilder.append(" null ");
      return;
    } 
    paramObject = null;
    for (Class<?> paramObject : dd.a(object.getClass())) {
      cb = this.a.a(paramObject);
      paramObject = (Class<?>)cb;
      if (cb != null) {
        paramObject = (Class<?>)cb;
        break;
      } 
    } 
    Class<?> clazz = paramObject;
    if (paramObject == null) {
      clazz = paramObject;
      if (object.getClass().isArray())
        cb = this.a.a(Object[].class); 
    } 
    if (cb == null)
      throw new RuntimeException("json can't serialize type : " + object.getClass()); 
    cb.a(object, paramStringBuilder);
  }
}


/* Location:              C:\soft\dex2jar-2.0\Smash Cricket-dex2jar.jar!\com\chartboost\sdk\impl\bx.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */