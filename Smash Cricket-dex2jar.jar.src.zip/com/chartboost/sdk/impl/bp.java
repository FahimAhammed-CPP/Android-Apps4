package com.chartboost.sdk.impl;

import android.content.Context;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.widget.RelativeLayout;
import com.chartboost.sdk.Model.a;
import com.chartboost.sdk.f;

public final class bp extends RelativeLayout {
  private f.a a;
  
  private bi b;
  
  private bi c;
  
  private bo d;
  
  private a e = null;
  
  public bp(Context paramContext, a parama) {
    super(paramContext);
    this.e = parama;
    this.b = new bi(paramContext);
    addView(this.b, (ViewGroup.LayoutParams)new RelativeLayout.LayoutParams(-1, -1));
    this.c = new bi(paramContext);
    addView(this.c, (ViewGroup.LayoutParams)new RelativeLayout.LayoutParams(-1, -1));
    this.c.setVisibility(8);
  }
  
  public void a() {
    if (this.a == null) {
      this.a = this.e.l();
      if (this.a != null) {
        addView((View)this.a, (ViewGroup.LayoutParams)new RelativeLayout.LayoutParams(-1, -1));
        this.a.a();
      } 
    } 
    c();
  }
  
  public void b() {
    boolean bool;
    if (!this.e.j) {
      bool = true;
    } else {
      bool = false;
    } 
    this.e.j = true;
    if (this.d == null) {
      this.d = new bo(getContext());
      this.d.setVisibility(8);
      addView((View)this.d, (ViewGroup.LayoutParams)new RelativeLayout.LayoutParams(-1, -1));
    } else {
      this.c.bringToFront();
      this.c.setVisibility(0);
      this.c.a();
      bh.a(false, this.b);
      this.d.bringToFront();
      this.d.a();
    } 
    if (!g()) {
      this.d.setVisibility(0);
      if (bool) {
        e().a();
        bh.a(true, (View)this.d);
      } 
    } 
  }
  
  public void c() {
    if (this.d != null) {
      this.d.clearAnimation();
      this.d.setVisibility(8);
    } 
  }
  
  public void d() {}
  
  public bi e() {
    return this.b;
  }
  
  public View f() {
    return (View)this.a;
  }
  
  public boolean g() {
    return (this.d != null && this.d.getVisibility() == 0);
  }
  
  public a h() {
    return this.e;
  }
  
  public boolean onTouchEvent(MotionEvent paramMotionEvent) {
    return true;
  }
}


/* Location:              C:\soft\dex2jar-2.0\Smash Cricket-dex2jar.jar!\com\chartboost\sdk\impl\bp.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */