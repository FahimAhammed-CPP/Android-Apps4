package com.chartboost.sdk.impl;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.telephony.TelephonyManager;
import com.chartboost.sdk.Libraries.CBLogging;
import java.util.Observable;

public class ay extends Observable {
  private static ay c = null;
  
  private static b d = b.a;
  
  private boolean a = true;
  
  private boolean b = false;
  
  private a e = null;
  
  private ay() {
    this.e = new a(this);
  }
  
  public static ay a() {
    if (c == null)
      c = new ay(); 
    return c;
  }
  
  public static Integer d() {
    try {
      int i;
      NetworkInfo networkInfo = ((ConnectivityManager)com.chartboost.sdk.b.x().getSystemService("connectivity")).getActiveNetworkInfo();
      if (networkInfo != null && networkInfo.isConnectedOrConnecting()) {
        i = 1;
      } else {
        i = 0;
      } 
      if (i) {
        TelephonyManager telephonyManager = (TelephonyManager)com.chartboost.sdk.b.x().getSystemService("phone");
        if (telephonyManager != null) {
          i = telephonyManager.getNetworkType();
          return Integer.valueOf(i);
        } 
      } 
    } catch (SecurityException securityException) {
      CBLogging.b("CBReachability", "Chartboost SDK requires 'android.permission.ACCESS_NETWORK_STATE' permission set in your AndroidManifest.xml");
    } 
    return null;
  }
  
  public void a(Context paramContext) {
    try {
      NetworkInfo networkInfo = ((ConnectivityManager)paramContext.getSystemService("connectivity")).getActiveNetworkInfo();
      if (networkInfo != null && networkInfo.isConnectedOrConnecting()) {
        a(true);
        if (networkInfo.getType() == 1) {
          d = b.c;
          CBLogging.a("CBReachability", "NETWORK TYPE: TYPE_WIFI");
          return;
        } 
        if (networkInfo.getType() == 0) {
          d = b.d;
          CBLogging.a("CBReachability", "NETWORK TYPE: TYPE_MOBILE");
          return;
        } 
      } else {
        a(false);
        d = b.b;
        CBLogging.a("CBReachability", "NETWORK TYPE: NO Network");
      } 
    } catch (SecurityException securityException) {
      d = b.a;
      CBLogging.b("CBReachability", "Chartboost SDK requires 'android.permission.ACCESS_NETWORK_STATE' permission set in your AndroidManifest.xml");
      return;
    } 
  }
  
  public void a(boolean paramBoolean) {
    this.a = paramBoolean;
  }
  
  public int b() {
    return d.a();
  }
  
  public Intent b(Context paramContext) {
    if (paramContext != null && !this.b) {
      b(true);
      CBLogging.a("CBReachability", "Network broadcast successfully registered");
      return paramContext.registerReceiver(this.e, new IntentFilter("android.net.conn.CONNECTIVITY_CHANGE"));
    } 
    return null;
  }
  
  public void b(boolean paramBoolean) {
    this.b = paramBoolean;
  }
  
  public void c(Context paramContext) {
    if (paramContext != null && this.b) {
      paramContext.unregisterReceiver(this.e);
      b(false);
      CBLogging.a("CBReachability", "Network broadcast successfully unregistered");
    } 
  }
  
  public boolean c() {
    return this.a;
  }
  
  public void notifyObservers() {
    if (this.a) {
      setChanged();
      notifyObservers(this);
    } 
  }
  
  private class a extends BroadcastReceiver {
    public a(ay this$0) {}
    
    public void onReceive(Context param1Context, Intent param1Intent) {
      ay ay1 = ay.a();
      ay1.a(param1Context);
      ay1.notifyObservers();
    }
  }
  
  public enum b {
    a(-1),
    b(0),
    c(1),
    d(2);
    
    private int e;
    
    b(int param1Int1) {
      this.e = param1Int1;
    }
    
    public int a() {
      return this.e;
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Smash Cricket-dex2jar.jar!\com\chartboost\sdk\impl\ay.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */