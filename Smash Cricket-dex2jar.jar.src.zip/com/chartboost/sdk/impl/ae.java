package com.chartboost.sdk.impl;

import com.chartboost.sdk.Libraries.CBLogging;
import com.chartboost.sdk.Libraries.e;
import com.chartboost.sdk.Model.CBError;
import com.chartboost.sdk.Model.a;
import com.chartboost.sdk.Model.b;
import com.chartboost.sdk.b;
import com.chartboost.sdk.d;
import org.json.JSONArray;

public class ae extends d {
  private static final String b = ae.class.getSimpleName();
  
  private static ae c;
  
  public static ae f() {
    if (c == null)
      c = new ae(); 
    return c;
  }
  
  protected a a(String paramString, boolean paramBoolean) {
    return new a(a.c.a, paramBoolean, paramString, false);
  }
  
  protected void a(a parama, e.a parama1) {
    if (b(parama, parama1) && !bd.c(parama1)) {
      CBLogging.b(b, "Video is unavailable for the cached impression");
      a(parama, CBError.CBImpressionError.VIDEO_UNAVAILABLE);
      if (parama.f) {
        parama.a(parama1);
        bd.a(parama);
      } 
      bd.b();
      return;
    } 
    if (parama1.c() && parama1.a("videos").c())
      bd.a(parama1.a("videos")); 
    super.a(parama, parama1);
  }
  
  public void a(a parama, boolean paramBoolean) {
    if (paramBoolean)
      super.a(parama, parama.w()); 
  }
  
  protected boolean b(a parama, e.a parama1) {
    return parama1.a("media-type").equals("video");
  }
  
  protected d.a c() {
    return new d.a(this) {
        public void a(a param1a) {
          if (b.f() != null)
            b.f().didClickInterstitial(param1a.d); 
        }
        
        public void a(a param1a, CBError.CBImpressionError param1CBImpressionError) {
          if (b.f() != null)
            b.f().didFailToLoadInterstitial(param1a.d, param1CBImpressionError); 
        }
        
        public void b(a param1a) {
          if (b.f() != null)
            b.f().didCloseInterstitial(param1a.d); 
        }
        
        public void c(a param1a) {
          if (b.f() != null)
            b.f().didDismissInterstitial(param1a.d); 
        }
        
        public void d(a param1a) {
          if (b.f() != null)
            b.f().didCacheInterstitial(param1a.d); 
        }
        
        public void e(a param1a) {
          if (b.f() != null)
            b.f().didDisplayInterstitial(param1a.d); 
        }
        
        public boolean f(a param1a) {
          return (b.f() != null) ? b.f().shouldDisplayInterstitial(param1a.d) : true;
        }
        
        public boolean g(a param1a) {
          return (b.f() != null) ? b.f().shouldRequestInterstitial(param1a.d) : true;
        }
        
        public boolean h(a param1a) {
          return (b.f() != null) ? b.u() : true;
        }
      };
  }
  
  public boolean c(String paramString) {
    a a = d(paramString);
    if (a != null && a.w() != null) {
      if (b(a, a.w())) {
        if (!bd.c(a.w())) {
          CBLogging.b(b, "hasCached check status: Video not available in the cache for impression");
          o(a);
          e(paramString);
          b(paramString);
          return false;
        } 
        return true;
      } 
    } else {
      return false;
    } 
    return super.c(paramString);
  }
  
  protected az e(a parama) {
    az az = new az("/interstitial/get");
    az.a(l.a.c);
    az.a(b.b);
    az.a("local-videos", g());
    return az;
  }
  
  public String e() {
    return "interstitial";
  }
  
  public JSONArray g() {
    JSONArray jSONArray = new JSONArray();
    String[] arrayOfString = bd.c();
    if (arrayOfString != null) {
      int j = arrayOfString.length;
      for (int i = 0; i < j; i++)
        jSONArray.put(arrayOfString[i]); 
    } 
    return jSONArray;
  }
  
  protected void g(a parama) {
    if (b(parama, parama.w()) && !bd.c(parama.w())) {
      CBLogging.b(b, "doShow() status: Video not available in the cache for the impression");
      a(parama, CBError.CBImpressionError.VIDEO_UNAVAILABLE);
      e(parama.d);
      b(parama.d);
      return;
    } 
    super.g(parama);
  }
  
  protected void i(a parama) {
    if (parama.e == a.d.b)
      return; 
    super.i(parama);
  }
  
  protected az l(a parama) {
    return new az("/interstitial/show");
  }
}


/* Location:              C:\soft\dex2jar-2.0\Smash Cricket-dex2jar.jar!\com\chartboost\sdk\impl\ae.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */