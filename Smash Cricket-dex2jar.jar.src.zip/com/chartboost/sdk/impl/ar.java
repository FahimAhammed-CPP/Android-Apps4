package com.chartboost.sdk.impl;

import android.content.Context;
import android.graphics.Point;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import com.chartboost.sdk.Libraries.CBUtility;
import com.chartboost.sdk.Libraries.e;
import com.chartboost.sdk.Libraries.j;
import com.chartboost.sdk.f;

public class ar extends ap {
  private aw a;
  
  private TextView b;
  
  private TextView c;
  
  private TextView d;
  
  private LinearLayout e;
  
  private au f;
  
  private bk g;
  
  private int h;
  
  private Point i;
  
  private j j;
  
  private View.OnClickListener k;
  
  public ar(aw paramaw, Context paramContext) {
    super(paramContext);
    float f;
    this.a = paramaw;
    this.e = new LinearLayout(paramContext);
    this.e.setOrientation(1);
    setGravity(16);
    boolean bool = f.a(paramContext);
    this.b = new TextView(paramContext);
    this.b.setTypeface(null, 1);
    TextView textView = this.b;
    if (bool) {
      f = 21.0F;
    } else {
      f = 16.0F;
    } 
    textView.setTextSize(2, f);
    this.b.setTextColor(-16777216);
    this.b.setSingleLine();
    this.b.setEllipsize(TextUtils.TruncateAt.END);
    this.c = new TextView(paramContext);
    textView = this.c;
    if (bool) {
      f = 16.0F;
    } else {
      f = 10.0F;
    } 
    textView.setTextSize(2, f);
    this.c.setTextColor(-16777216);
    this.c.setSingleLine();
    this.c.setEllipsize(TextUtils.TruncateAt.END);
    this.d = new TextView(paramContext);
    textView = this.d;
    if (bool) {
      f = 18.0F;
    } else {
      f = 11.0F;
    } 
    textView.setTextSize(2, f);
    this.d.setTextColor(-16777216);
    this.d.setMaxLines(2);
    this.d.setEllipsize(TextUtils.TruncateAt.END);
    this.g = new bk(this, paramContext) {
        protected void a(MotionEvent param1MotionEvent) {
          ar.b(this.a).onClick((View)ar.a(this.a));
        }
      };
    this.g.a(ImageView.ScaleType.FIT_CENTER);
    this.f = new au(paramContext);
    setFocusable(false);
    setGravity(16);
    addView((View)this.f);
    addView((View)this.e, (ViewGroup.LayoutParams)new LinearLayout.LayoutParams(0, -2, 1.0F));
    addView((View)this.g);
    setBackgroundColor(0);
    this.e.addView((View)this.b, (ViewGroup.LayoutParams)new LinearLayout.LayoutParams(-1, -2));
    this.e.addView((View)this.c, (ViewGroup.LayoutParams)new LinearLayout.LayoutParams(-1, -2));
    this.e.addView((View)this.d, (ViewGroup.LayoutParams)new LinearLayout.LayoutParams(-1, -1));
  }
  
  private void a(bj parambj, int paramInt, e.a parama) {
    if (parama.b())
      return; 
    Bundle bundle = new Bundle();
    bundle.putInt("index", paramInt);
    String str2 = "";
    String str1 = str2;
    if (parama.e("checksum") != null) {
      str1 = str2;
      if (!parama.e("checksum").isEmpty())
        str1 = parama.e("checksum"); 
    } 
    bc.a().a(parama.e("url"), str1, null, parambj, bundle);
  }
  
  private int c() {
    byte b = 74;
    if (CBUtility.c().c()) {
      if (!f.a(getContext()))
        b = 41; 
      return CBUtility.a(b, getContext());
    } 
    if (!f.a(getContext()))
      b = 41; 
    return CBUtility.a(b, getContext());
  }
  
  public int a() {
    char c = '';
    if (CBUtility.c().c()) {
      if (!f.a(getContext()))
        c = 'K'; 
      return CBUtility.a(c, getContext());
    } 
    if (!f.a(getContext()))
      c = 'M'; 
    return CBUtility.a(c, getContext());
  }
  
  public void a(e.a parama, int paramInt) {
    this.b.setText(parama.a("name").d("Unknown App"));
    if (TextUtils.isEmpty(parama.e("publisher"))) {
      this.c.setVisibility(8);
    } else {
      this.c.setText(parama.e("publisher"));
    } 
    if (TextUtils.isEmpty(parama.e("description"))) {
      this.d.setVisibility(8);
    } else {
      this.d.setText(parama.e("description"));
    } 
    if (parama.b("border-color")) {
      i = -4802890;
    } else {
      i = f.a(parama.e("border-color"));
    } 
    this.h = i;
    if (parama.c("offset")) {
      this.i = new Point(parama.a("offset").f("x"), parama.a("offset").f("y"));
    } else {
      this.i = new Point(0, 0);
    } 
    this.j = null;
    if (parama.c("deep-link") && bb.a(parama.e("deep-link"))) {
      if (this.a.l.e()) {
        this.j = this.a.l;
      } else {
        this.g.a("Play");
      } 
    } else if (this.a.k.e()) {
      this.j = this.a.k;
    } else {
      this.g.a("Install");
    } 
    if (f.a(getContext())) {
      i = 14;
    } else {
      i = 7;
    } 
    int i = CBUtility.a(i, getContext());
    if (this.j != null) {
      this.g.a(this.j);
      i = i * 2 + Math.round(this.j.b() * c() / this.j.c());
    } else {
      this.g.a().setTextColor(-14571545);
      i = CBUtility.a(8, getContext());
      this.g.a().setPadding(i, i, i, i);
      i = CBUtility.a(100, getContext());
    } 
    LinearLayout.LayoutParams layoutParams = new LinearLayout.LayoutParams(i, c());
    this.g.setLayoutParams((ViewGroup.LayoutParams)layoutParams);
    removeView((View)this.f);
    this.f = new au(getContext());
    addView((View)this.f, 0);
    a(this.f, paramInt, parama.a("assets").a("icon"));
    this.f.a(this.h);
    this.f.a(0.16666667F);
    b();
  }
  
  protected void b() {
    if (f.a(getContext())) {
      i = 14;
    } else {
      i = 7;
    } 
    int i = CBUtility.a(i, getContext());
    LinearLayout.LayoutParams layoutParams = new LinearLayout.LayoutParams(a() - i * 2, a() - i * 2);
    layoutParams.setMargins(i, i, i, i);
    this.e.setPadding(0, i, 0, i);
    this.g.setPadding(this.i.x * 2 + i, this.i.y * 2, i, 0);
    this.f.setLayoutParams((ViewGroup.LayoutParams)layoutParams);
    this.f.setScaleType(ImageView.ScaleType.FIT_CENTER);
  }
  
  public void setOnClickListener(View.OnClickListener paramOnClickListener) {
    super.setOnClickListener(paramOnClickListener);
    this.k = paramOnClickListener;
  }
}


/* Location:              C:\soft\dex2jar-2.0\Smash Cricket-dex2jar.jar!\com\chartboost\sdk\impl\ar.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */