package com.chartboost.sdk.impl;

import java.nio.ByteOrder;
import java.util.logging.Level;
import java.util.logging.Logger;

public class bt extends cg {
  static final Logger a = Logger.getLogger("com.mongodb");
  
  static final boolean b = Boolean.getBoolean("DEBUG.MONGO");
  
  public static final ByteOrder c = ByteOrder.LITTLE_ENDIAN;
  
  static final int d = Integer.parseInt(System.getProperty("MONGO.POOLSIZE", "10"));
  
  static final cy e = new cy(-1, -1, -1);
  
  static {
    if (a.getLevel() == null)
      if (b) {
        a.setLevel(Level.ALL);
      } else {
        a.setLevel(Level.WARNING);
      }  
  }
}


/* Location:              C:\soft\dex2jar-2.0\Smash Cricket-dex2jar.jar!\com\chartboost\sdk\impl\bt.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */