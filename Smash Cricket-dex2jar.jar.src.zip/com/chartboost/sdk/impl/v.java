package com.chartboost.sdk.impl;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.LinkedList;
import java.util.List;

public class v {
  protected static final Comparator<byte[]> a = new Comparator<byte[]>() {
      public int a(byte[] param1ArrayOfbyte1, byte[] param1ArrayOfbyte2) {
        return param1ArrayOfbyte1.length - param1ArrayOfbyte2.length;
      }
    };
  
  private List<byte[]> b = (List)new LinkedList<byte>();
  
  private List<byte[]> c = (List)new ArrayList<byte>(64);
  
  private int d = 0;
  
  private final int e;
  
  public v(int paramInt) {
    this.e = paramInt;
  }
  
  private void a() {
    // Byte code:
    //   0: aload_0
    //   1: monitorenter
    //   2: aload_0
    //   3: getfield d : I
    //   6: istore_1
    //   7: aload_0
    //   8: getfield e : I
    //   11: istore_2
    //   12: iload_1
    //   13: iload_2
    //   14: if_icmpgt -> 20
    //   17: aload_0
    //   18: monitorexit
    //   19: return
    //   20: aload_0
    //   21: getfield b : Ljava/util/List;
    //   24: iconst_0
    //   25: invokeinterface remove : (I)Ljava/lang/Object;
    //   30: checkcast [B
    //   33: astore_3
    //   34: aload_0
    //   35: getfield c : Ljava/util/List;
    //   38: aload_3
    //   39: invokeinterface remove : (Ljava/lang/Object;)Z
    //   44: pop
    //   45: aload_0
    //   46: aload_0
    //   47: getfield d : I
    //   50: aload_3
    //   51: arraylength
    //   52: isub
    //   53: putfield d : I
    //   56: goto -> 2
    //   59: astore_3
    //   60: aload_0
    //   61: monitorexit
    //   62: aload_3
    //   63: athrow
    // Exception table:
    //   from	to	target	type
    //   2	12	59	finally
    //   20	56	59	finally
  }
  
  public void a(byte[] paramArrayOfbyte) {
    // Byte code:
    //   0: aload_0
    //   1: monitorenter
    //   2: aload_1
    //   3: ifnull -> 19
    //   6: aload_1
    //   7: arraylength
    //   8: istore_2
    //   9: aload_0
    //   10: getfield e : I
    //   13: istore_3
    //   14: iload_2
    //   15: iload_3
    //   16: if_icmple -> 22
    //   19: aload_0
    //   20: monitorexit
    //   21: return
    //   22: aload_0
    //   23: getfield b : Ljava/util/List;
    //   26: aload_1
    //   27: invokeinterface add : (Ljava/lang/Object;)Z
    //   32: pop
    //   33: aload_0
    //   34: getfield c : Ljava/util/List;
    //   37: aload_1
    //   38: getstatic com/chartboost/sdk/impl/v.a : Ljava/util/Comparator;
    //   41: invokestatic binarySearch : (Ljava/util/List;Ljava/lang/Object;Ljava/util/Comparator;)I
    //   44: istore_3
    //   45: iload_3
    //   46: istore_2
    //   47: iload_3
    //   48: ifge -> 56
    //   51: iload_3
    //   52: ineg
    //   53: iconst_1
    //   54: isub
    //   55: istore_2
    //   56: aload_0
    //   57: getfield c : Ljava/util/List;
    //   60: iload_2
    //   61: aload_1
    //   62: invokeinterface add : (ILjava/lang/Object;)V
    //   67: aload_0
    //   68: aload_0
    //   69: getfield d : I
    //   72: aload_1
    //   73: arraylength
    //   74: iadd
    //   75: putfield d : I
    //   78: aload_0
    //   79: invokespecial a : ()V
    //   82: goto -> 19
    //   85: astore_1
    //   86: aload_0
    //   87: monitorexit
    //   88: aload_1
    //   89: athrow
    // Exception table:
    //   from	to	target	type
    //   6	14	85	finally
    //   22	45	85	finally
    //   56	82	85	finally
  }
  
  public byte[] a(int paramInt) {
    // Byte code:
    //   0: aload_0
    //   1: monitorenter
    //   2: iconst_0
    //   3: istore_2
    //   4: iload_2
    //   5: aload_0
    //   6: getfield c : Ljava/util/List;
    //   9: invokeinterface size : ()I
    //   14: if_icmplt -> 25
    //   17: iload_1
    //   18: newarray byte
    //   20: astore_3
    //   21: aload_0
    //   22: monitorexit
    //   23: aload_3
    //   24: areturn
    //   25: aload_0
    //   26: getfield c : Ljava/util/List;
    //   29: iload_2
    //   30: invokeinterface get : (I)Ljava/lang/Object;
    //   35: checkcast [B
    //   38: astore_3
    //   39: aload_3
    //   40: arraylength
    //   41: iload_1
    //   42: if_icmplt -> 86
    //   45: aload_0
    //   46: aload_0
    //   47: getfield d : I
    //   50: aload_3
    //   51: arraylength
    //   52: isub
    //   53: putfield d : I
    //   56: aload_0
    //   57: getfield c : Ljava/util/List;
    //   60: iload_2
    //   61: invokeinterface remove : (I)Ljava/lang/Object;
    //   66: pop
    //   67: aload_0
    //   68: getfield b : Ljava/util/List;
    //   71: aload_3
    //   72: invokeinterface remove : (Ljava/lang/Object;)Z
    //   77: pop
    //   78: goto -> 21
    //   81: astore_3
    //   82: aload_0
    //   83: monitorexit
    //   84: aload_3
    //   85: athrow
    //   86: iload_2
    //   87: iconst_1
    //   88: iadd
    //   89: istore_2
    //   90: goto -> 4
    // Exception table:
    //   from	to	target	type
    //   4	21	81	finally
    //   25	78	81	finally
  }
}


/* Location:              C:\soft\dex2jar-2.0\Smash Cricket-dex2jar.jar!\com\chartboost\sdk\impl\v.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */