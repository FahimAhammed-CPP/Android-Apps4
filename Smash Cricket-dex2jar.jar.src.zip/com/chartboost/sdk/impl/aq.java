package com.chartboost.sdk.impl;

import android.content.Context;
import android.os.Bundle;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.LinearLayout;
import com.chartboost.sdk.Libraries.CBUtility;
import com.chartboost.sdk.Libraries.e;

public class aq extends ap {
  private ImageView a;
  
  public aq(aw paramaw, Context paramContext) {
    super(paramContext);
    this.a = new ImageView(paramContext);
    addView((View)this.a, (ViewGroup.LayoutParams)new LinearLayout.LayoutParams(-1, -1));
  }
  
  public int a() {
    return CBUtility.a(110, getContext());
  }
  
  public void a(e.a parama, int paramInt) {
    String str;
    boolean bool = CBUtility.c().b();
    e.a a1 = parama.a("assets");
    if (bool) {
      str = "portrait";
    } else {
      str = "landscape";
    } 
    e.a a2 = a1.a(str);
    if (a2.c()) {
      Bundle bundle = new Bundle();
      bundle.putInt("index", paramInt);
      String str1 = "";
      str = str1;
      if (a2.e("checksum") != null) {
        str = str1;
        if (!a2.e("checksum").isEmpty())
          str = a2.e("checksum"); 
      } 
      bc.a().a(a2.e("url"), str, null, this.a, bundle);
    } 
  }
}


/* Location:              C:\soft\dex2jar-2.0\Smash Cricket-dex2jar.jar!\com\chartboost\sdk\impl\aq.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */