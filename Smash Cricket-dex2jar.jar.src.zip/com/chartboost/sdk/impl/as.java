package com.chartboost.sdk.impl;

import android.content.Context;
import android.media.MediaPlayer;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.RelativeLayout;
import com.chartboost.sdk.Libraries.CBLogging;
import com.chartboost.sdk.Libraries.e;

public class as extends ar {
  private aw a;
  
  private Button b;
  
  private bg c;
  
  private e.a d;
  
  public as(aw paramaw, Context paramContext) {
    super(paramaw, paramContext);
    this.a = paramaw;
    this.b = new Button(paramContext);
    this.b.setTextColor(-14571545);
    this.b.setText("Preview");
    this.b.setOnClickListener(new View.OnClickListener(this) {
          public void onClick(View param1View) {
            as.a(this.a);
          }
        });
    addView((View)this.b, 2);
  }
  
  private void c() {
    CBLogging.c(this, "play the video");
    if (this.c == null) {
      this.c = new bg(getContext());
      this.a.e().addView((View)this.c, (ViewGroup.LayoutParams)new RelativeLayout.LayoutParams(-1, -1));
      this.c.setVisibility(8);
    } 
    this.c.b().a(new MediaPlayer.OnCompletionListener(this) {
          public void onCompletion(MediaPlayer param1MediaPlayer) {
            bh.a(false, (View)as.b(this.a));
          }
        });
    bh.a(true, (View)this.c);
    this.c.b().a();
  }
  
  public void a(e.a parama, int paramInt) {
    super.a(parama, paramInt);
    this.d = parama;
  }
}


/* Location:              C:\soft\dex2jar-2.0\Smash Cricket-dex2jar.jar!\com\chartboost\sdk\impl\as.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */