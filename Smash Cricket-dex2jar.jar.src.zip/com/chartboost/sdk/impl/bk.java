package com.chartboost.sdk.impl;

import android.content.Context;
import android.graphics.PorterDuff;
import android.graphics.Rect;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.RelativeLayout;
import android.widget.TextView;
import com.chartboost.sdk.Libraries.j;

public abstract class bk extends RelativeLayout {
  private static Rect b = new Rect();
  
  private a a;
  
  protected boolean c = false;
  
  protected Button d = null;
  
  private boolean e = true;
  
  public bk(Context paramContext) {
    super(paramContext);
    b();
  }
  
  private void b() {
    this.a = new a(this, getContext());
    this.a.setOnTouchListener(new View.OnTouchListener(this) {
          public boolean onTouch(View param1View, MotionEvent param1MotionEvent) {
            boolean bool = bk.a(param1View, param1MotionEvent);
            switch (param1MotionEvent.getActionMasked()) {
              default:
                return true;
              case 0:
                bk.a(this.a).a(bool);
                return bool;
              case 2:
                bk.a(this.a).a(bool);
              case 1:
                if (this.a.getVisibility() == 0 && this.a.isEnabled() && bool)
                  this.a.a(param1MotionEvent); 
                bk.a(this.a).a(false);
              case 3:
              case 4:
                break;
            } 
            bk.a(this.a).a(false);
          }
        });
    addView((View)this.a, (ViewGroup.LayoutParams)new RelativeLayout.LayoutParams(-1, -1));
  }
  
  private static boolean b(View paramView, MotionEvent paramMotionEvent) {
    paramView.getLocalVisibleRect(b);
    Rect rect = b;
    rect.left += paramView.getPaddingLeft();
    rect = b;
    rect.top += paramView.getPaddingTop();
    rect = b;
    rect.right -= paramView.getPaddingRight();
    rect = b;
    rect.bottom -= paramView.getPaddingBottom();
    return b.contains(Math.round(paramMotionEvent.getX()), Math.round(paramMotionEvent.getY()));
  }
  
  public TextView a() {
    if (this.d == null) {
      this.d = new Button(getContext());
      this.d.setGravity(17);
    } 
    this.d.postInvalidate();
    return (TextView)this.d;
  }
  
  protected abstract void a(MotionEvent paramMotionEvent);
  
  public void a(ImageView.ScaleType paramScaleType) {
    this.a.setScaleType(paramScaleType);
  }
  
  public void a(j paramj) {
    this.a.a(paramj);
    a((String)null);
  }
  
  public void a(j paramj, RelativeLayout.LayoutParams paramLayoutParams) {
    this.a.a(paramj, (ViewGroup.LayoutParams)paramLayoutParams);
    a((String)null);
  }
  
  public void a(String paramString) {
    if (paramString != null) {
      a().setText(paramString);
      addView((View)a(), (ViewGroup.LayoutParams)new RelativeLayout.LayoutParams(-1, -1));
      this.a.setVisibility(8);
      a(false);
      this.d.setOnClickListener(new View.OnClickListener(this) {
            public void onClick(View param1View) {
              this.a.a((MotionEvent)null);
            }
          });
      return;
    } 
    if (this.d != null) {
      removeView((View)a());
      this.d = null;
      this.a.setVisibility(0);
      a(true);
      return;
    } 
  }
  
  public void a(boolean paramBoolean) {
    this.e = paramBoolean;
  }
  
  public class a extends bj {
    public a(bk this$0, Context param1Context) {
      super(param1Context);
      this$0.c = false;
    }
    
    public void a(j param1j, ViewGroup.LayoutParams param1LayoutParams) {
      a(param1j);
      param1LayoutParams.width = param1j.h();
      param1LayoutParams.height = param1j.i();
    }
    
    protected void a(boolean param1Boolean) {
      if (bk.b(this.b) && param1Boolean) {
        if (!this.b.c) {
          if (getDrawable() != null) {
            getDrawable().setColorFilter(1996488704, PorterDuff.Mode.SRC_ATOP);
          } else if (getBackground() != null) {
            getBackground().setColorFilter(1996488704, PorterDuff.Mode.SRC_ATOP);
          } 
          invalidate();
          this.b.c = true;
        } 
        return;
      } 
      if (this.b.c) {
        if (getDrawable() != null) {
          getDrawable().clearColorFilter();
        } else if (getBackground() != null) {
          getBackground().clearColorFilter();
        } 
        invalidate();
        this.b.c = false;
        return;
      } 
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Smash Cricket-dex2jar.jar!\com\chartboost\sdk\impl\bk.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */