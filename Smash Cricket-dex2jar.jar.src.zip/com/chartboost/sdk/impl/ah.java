package com.chartboost.sdk.impl;

import android.content.Context;
import android.graphics.Point;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.RelativeLayout;
import com.chartboost.sdk.Libraries.e;
import com.chartboost.sdk.Libraries.j;
import com.chartboost.sdk.f;

public class ah extends f {
  protected j k = new j(this);
  
  protected j l = new j(this);
  
  protected e.a m;
  
  protected String n;
  
  protected float o = 1.0F;
  
  private j p = new j(this);
  
  private j q = new j(this);
  
  private j r = new j(this);
  
  private j s = new j(this);
  
  public ah(com.chartboost.sdk.Model.a parama) {
    super(parama);
  }
  
  public void a(ViewGroup.LayoutParams paramLayoutParams, j paramj, float paramFloat) {
    paramLayoutParams.width = (int)(paramj.b() / paramj.g() * paramFloat);
    paramLayoutParams.height = (int)(paramj.c() / paramj.g() * paramFloat);
  }
  
  public boolean a(e.a parama) {
    if (!super.a(parama))
      return false; 
    this.n = parama.e("ad_id");
    this.m = parama.a("ux");
    if (this.e.b("frame-portrait") || this.e.b("close-portrait"))
      this.i = false; 
    if (this.e.b("frame-landscape") || this.e.b("close-landscape"))
      this.j = false; 
    this.q.a("frame-landscape");
    this.p.a("frame-portrait");
    this.l.a("close-landscape");
    this.k.a("close-portrait");
    if (this.e.b("ad-portrait"))
      this.i = false; 
    if (this.e.b("ad-landscape"))
      this.j = false; 
    this.s.a("ad-landscape");
    this.r.a("ad-portrait");
    return true;
  }
  
  protected Point b(String paramString) {
    e.a a1 = this.e.a(paramString).a("offset");
    return a1.c() ? new Point(a1.f("x"), a1.f("y")) : new Point(0, 0);
  }
  
  protected f.a b(Context paramContext) {
    return new a(this, paramContext);
  }
  
  public void d() {
    super.d();
    this.q.d();
    this.p.d();
    this.l.d();
    this.k.d();
    this.s.d();
    this.r.d();
    this.q = null;
    this.p = null;
    this.l = null;
    this.k = null;
    this.s = null;
    this.r = null;
  }
  
  public class a extends f.a {
    protected bj b;
    
    protected bk c;
    
    protected bk d;
    
    protected ImageView e;
    
    private boolean g = false;
    
    protected a(ah this$0, Context param1Context) {
      super(this$0, param1Context);
      setBackgroundColor(0);
      setLayoutParams((ViewGroup.LayoutParams)new RelativeLayout.LayoutParams(-1, -1));
      this.b = new bj(param1Context);
      addView((View)this.b, (ViewGroup.LayoutParams)new RelativeLayout.LayoutParams(-1, -1));
      this.d = new bk(this, param1Context, this$0) {
          protected void a(MotionEvent param2MotionEvent) {
            this.b.a(param2MotionEvent.getX(), param2MotionEvent.getY());
          }
        };
      a((View)this.d);
      this.e = new ImageView(param1Context);
      this.e.setBackgroundColor(-16777216);
      addView((View)this.e);
      addView((View)this.d);
    }
    
    protected void a(float param1Float1, float param1Float2) {
      this.f.a(null, null);
    }
    
    protected void a(int param1Int1, int param1Int2) {
      int i;
      int j;
      j j1;
      j j2;
      String str1;
      String str3;
      String str2;
      if (!this.g) {
        d();
        this.g = true;
      } 
      boolean bool = this.f.a().b();
      if (bool) {
        j1 = ah.a(this.f);
      } else {
        j1 = ah.b(this.f);
      } 
      if (bool) {
        j2 = this.f.k;
      } else {
        j2 = this.f.l;
      } 
      RelativeLayout.LayoutParams layoutParams2 = new RelativeLayout.LayoutParams(-2, -2);
      RelativeLayout.LayoutParams layoutParams3 = new RelativeLayout.LayoutParams(-2, -2);
      this.f.a((ViewGroup.LayoutParams)layoutParams2, j1, 1.0F);
      float f = Math.min(param1Int1 / layoutParams2.width, param1Int2 / layoutParams2.height);
      this.f.o = Math.min(f, 1.0F);
      layoutParams2.width = (int)(layoutParams2.width * this.f.o);
      layoutParams2.height = (int)(layoutParams2.height * this.f.o);
      ah ah2 = this.f;
      if (bool) {
        str3 = "frame-portrait";
      } else {
        str3 = "frame-landscape";
      } 
      Point point3 = ah2.b(str3);
      layoutParams2.leftMargin = Math.round((param1Int1 - layoutParams2.width) / 2.0F + point3.x / j1.g() * this.f.o);
      f = (param1Int2 - layoutParams2.height) / 2.0F;
      layoutParams2.topMargin = Math.round(point3.y / j1.g() * this.f.o + f);
      this.f.a((ViewGroup.LayoutParams)layoutParams3, j2, 1.0F);
      ah2 = this.f;
      if (bool) {
        str2 = "close-portrait";
      } else {
        str2 = "close-landscape";
      } 
      Point point2 = ah2.b(str2);
      if (point2.x == 0 && point2.y == 0) {
        i = layoutParams2.leftMargin;
        j = layoutParams2.width;
        j = Math.round(-layoutParams3.width / 2.0F) + i + j;
        i = layoutParams2.topMargin + Math.round(-layoutParams3.height / 2.0F);
      } else {
        j = Math.round(layoutParams2.leftMargin + layoutParams2.width / 2.0F + point2.x - layoutParams3.width / 2.0F);
        f = layoutParams2.topMargin;
        float f1 = layoutParams2.height / 2.0F;
        i = Math.round(point2.y + f + f1 - layoutParams3.height / 2.0F);
      } 
      layoutParams3.leftMargin = Math.min(Math.max(0, j), param1Int1 - layoutParams3.width);
      layoutParams3.topMargin = Math.min(Math.max(0, i), param1Int2 - layoutParams3.height);
      this.b.setLayoutParams((ViewGroup.LayoutParams)layoutParams2);
      this.c.setLayoutParams((ViewGroup.LayoutParams)layoutParams3);
      this.b.setScaleType(ImageView.ScaleType.FIT_CENTER);
      this.b.a(j1);
      this.c.a(j2);
      if (bool) {
        j1 = ah.c(this.f);
      } else {
        j1 = ah.d(this.f);
      } 
      RelativeLayout.LayoutParams layoutParams1 = new RelativeLayout.LayoutParams(-2, -2);
      this.f.a((ViewGroup.LayoutParams)layoutParams1, j1, this.f.o);
      ah ah1 = this.f;
      if (bool) {
        str1 = "ad-portrait";
      } else {
        str1 = "ad-landscape";
      } 
      Point point1 = ah1.b(str1);
      layoutParams1.leftMargin = Math.round((param1Int1 - layoutParams1.width) / 2.0F + point1.x / j1.g() * this.f.o);
      f = (param1Int2 - layoutParams1.height) / 2.0F;
      layoutParams1.topMargin = Math.round(point1.y / j1.g() * this.f.o + f);
      this.e.setLayoutParams((ViewGroup.LayoutParams)layoutParams1);
      this.d.setLayoutParams((ViewGroup.LayoutParams)layoutParams1);
      this.d.a(ImageView.ScaleType.FIT_CENTER);
      this.d.a(j1);
    }
    
    public void b() {
      super.b();
      this.b = null;
      this.c = null;
      this.d = null;
      this.e = null;
    }
    
    protected void d() {
      this.c = new bk(this, getContext()) {
          protected void a(MotionEvent param2MotionEvent) {
            this.a.e();
          }
        };
      addView((View)this.c);
    }
    
    protected void e() {
      ah.e(this.f);
    }
  }
  
  class null extends bk {
    null(ah this$0, Context param1Context, ah param1ah) {
      super(param1Context);
    }
    
    protected void a(MotionEvent param1MotionEvent) {
      this.b.a(param1MotionEvent.getX(), param1MotionEvent.getY());
    }
  }
  
  class null extends bk {
    null(ah this$0, Context param1Context) {
      super(param1Context);
    }
    
    protected void a(MotionEvent param1MotionEvent) {
      this.a.e();
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Smash Cricket-dex2jar.jar!\com\chartboost\sdk\impl\ah.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */