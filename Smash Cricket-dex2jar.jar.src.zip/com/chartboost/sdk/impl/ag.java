package com.chartboost.sdk.impl;

import android.content.Context;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.widget.LinearLayout;
import android.widget.TextView;
import com.chartboost.sdk.Tracking.a;

public final class ag extends am {
  private LinearLayout b;
  
  private LinearLayout c;
  
  private bj d;
  
  private bk e;
  
  private TextView f;
  
  private TextView g;
  
  public ag(Context paramContext, ai paramai) {
    super(paramContext, paramai);
  }
  
  protected View a() {
    Context context = getContext();
    int i = Math.round((getContext().getResources().getDisplayMetrics()).density * 6.0F);
    this.b = new LinearLayout(context);
    this.b.setOrientation(0);
    this.b.setGravity(17);
    this.c = new LinearLayout(context);
    this.c.setOrientation(1);
    this.c.setGravity(19);
    this.d = new bj(context);
    this.d.setPadding(i, i, i, i);
    if (this.a.G.e())
      this.d.a(this.a.G); 
    this.e = new bk(this, context) {
        protected void a(MotionEvent param1MotionEvent) {
          this.a.a.p().h();
          a.a("install-click", this.a.a.s, this.a.a.n, Math.round(param1MotionEvent.getX()), Math.round(param1MotionEvent.getY()));
        }
      };
    this.e.setPadding(i, i, i, i);
    if (this.a.H.e())
      this.e.a(this.a.H); 
    this.f = new TextView(getContext());
    this.f.setTextColor(-15264491);
    this.f.setTypeface(null, 1);
    this.f.setGravity(3);
    this.f.setPadding(i, i, i, i / 2);
    this.g = new TextView(getContext());
    this.g.setTextColor(-15264491);
    this.g.setTypeface(null, 1);
    this.g.setGravity(3);
    this.g.setPadding(i, 0, i, i);
    this.f.setTextSize(2, 14.0F);
    this.g.setTextSize(2, 11.0F);
    this.c.addView((View)this.f);
    this.c.addView((View)this.g);
    this.b.addView((View)this.d);
    this.b.addView((View)this.c, (ViewGroup.LayoutParams)new LinearLayout.LayoutParams(0, -2, 1.0F));
    this.b.addView((View)this.e);
    return (View)this.b;
  }
  
  public void a(String paramString1, String paramString2) {
    this.f.setText(paramString1);
    this.g.setText(paramString2);
  }
  
  protected int b() {
    return 72;
  }
}


/* Location:              C:\soft\dex2jar-2.0\Smash Cricket-dex2jar.jar!\com\chartboost\sdk\impl\ag.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */