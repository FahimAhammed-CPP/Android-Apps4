package com.chartboost.sdk.impl;

public interface f {
  i a(l<?> paraml) throws s;
}


/* Location:              C:\soft\dex2jar-2.0\Smash Cricket-dex2jar.jar!\com\chartboost\sdk\impl\f.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */