package com.chartboost.sdk.impl;

import java.util.Collections;
import java.util.Map;

public interface b {
  a a(String paramString);
  
  void a();
  
  void a(String paramString, a parama);
  
  public static class a {
    public byte[] a;
    
    public String b;
    
    public long c;
    
    public long d;
    
    public long e;
    
    public Map<String, String> f = Collections.emptyMap();
    
    public boolean a() {
      return (this.d < System.currentTimeMillis());
    }
    
    public boolean b() {
      return (this.e < System.currentTimeMillis());
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Smash Cricket-dex2jar.jar!\com\chartboost\sdk\impl\b.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */