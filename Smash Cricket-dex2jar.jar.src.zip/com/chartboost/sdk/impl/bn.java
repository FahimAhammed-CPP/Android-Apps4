package com.chartboost.sdk.impl;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.view.View;

public abstract class bn extends View {
  private Bitmap a = null;
  
  private Canvas b = null;
  
  public bn(Context paramContext) {
    super(paramContext);
    a(paramContext);
  }
  
  private void a(Context paramContext) {
    try {
      getClass().getMethod("setLayerType", new Class[] { int.class, Paint.class }).invoke(this, new Object[] { Integer.valueOf(1), null });
      return;
    } catch (Exception exception) {
      return;
    } 
  }
  
  private boolean b(Canvas paramCanvas) {
    try {
      return ((Boolean)Canvas.class.getMethod("isHardwareAccelerated", new Class[0]).invoke(paramCanvas, new Object[0])).booleanValue();
    } catch (Exception exception) {
      return false;
    } 
  }
  
  protected abstract void a(Canvas paramCanvas);
  
  protected void onDetachedFromWindow() {
    super.onDetachedFromWindow();
    if (this.a != null && !this.a.isRecycled())
      this.a.recycle(); 
    this.a = null;
  }
  
  protected final void onDraw(Canvas paramCanvas) {
    // Byte code:
    //   0: aload_0
    //   1: aload_1
    //   2: invokespecial b : (Landroid/graphics/Canvas;)Z
    //   5: istore_2
    //   6: iload_2
    //   7: ifeq -> 146
    //   10: aload_0
    //   11: getfield a : Landroid/graphics/Bitmap;
    //   14: ifnull -> 45
    //   17: aload_0
    //   18: getfield a : Landroid/graphics/Bitmap;
    //   21: invokevirtual getWidth : ()I
    //   24: aload_1
    //   25: invokevirtual getWidth : ()I
    //   28: if_icmpne -> 45
    //   31: aload_0
    //   32: getfield a : Landroid/graphics/Bitmap;
    //   35: invokevirtual getHeight : ()I
    //   38: aload_1
    //   39: invokevirtual getHeight : ()I
    //   42: if_icmpeq -> 102
    //   45: aload_0
    //   46: getfield a : Landroid/graphics/Bitmap;
    //   49: ifnull -> 69
    //   52: aload_0
    //   53: getfield a : Landroid/graphics/Bitmap;
    //   56: invokevirtual isRecycled : ()Z
    //   59: ifne -> 69
    //   62: aload_0
    //   63: getfield a : Landroid/graphics/Bitmap;
    //   66: invokevirtual recycle : ()V
    //   69: aload_0
    //   70: aload_1
    //   71: invokevirtual getWidth : ()I
    //   74: aload_1
    //   75: invokevirtual getHeight : ()I
    //   78: getstatic android/graphics/Bitmap$Config.ARGB_8888 : Landroid/graphics/Bitmap$Config;
    //   81: invokestatic createBitmap : (IILandroid/graphics/Bitmap$Config;)Landroid/graphics/Bitmap;
    //   84: putfield a : Landroid/graphics/Bitmap;
    //   87: aload_0
    //   88: new android/graphics/Canvas
    //   91: dup
    //   92: aload_0
    //   93: getfield a : Landroid/graphics/Bitmap;
    //   96: invokespecial <init> : (Landroid/graphics/Bitmap;)V
    //   99: putfield b : Landroid/graphics/Canvas;
    //   102: aload_0
    //   103: getfield a : Landroid/graphics/Bitmap;
    //   106: iconst_0
    //   107: invokevirtual eraseColor : (I)V
    //   110: aload_0
    //   111: getfield b : Landroid/graphics/Canvas;
    //   114: astore #4
    //   116: aload_1
    //   117: astore_3
    //   118: aload_0
    //   119: aload #4
    //   121: invokevirtual a : (Landroid/graphics/Canvas;)V
    //   124: iload_2
    //   125: ifeq -> 143
    //   128: aload_3
    //   129: ifnull -> 143
    //   132: aload_3
    //   133: aload_0
    //   134: getfield a : Landroid/graphics/Bitmap;
    //   137: fconst_0
    //   138: fconst_0
    //   139: aconst_null
    //   140: invokevirtual drawBitmap : (Landroid/graphics/Bitmap;FFLandroid/graphics/Paint;)V
    //   143: return
    //   144: astore_1
    //   145: return
    //   146: aconst_null
    //   147: astore_3
    //   148: aload_1
    //   149: astore #4
    //   151: goto -> 118
    // Exception table:
    //   from	to	target	type
    //   69	102	144	java/lang/Throwable
  }
}


/* Location:              C:\soft\dex2jar-2.0\Smash Cricket-dex2jar.jar!\com\chartboost\sdk\impl\bn.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */