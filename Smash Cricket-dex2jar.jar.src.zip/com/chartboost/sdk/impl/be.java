package com.chartboost.sdk.impl;

import android.content.Context;
import android.content.Intent;
import android.media.MediaPlayer;
import android.net.Uri;
import android.view.SurfaceHolder;
import android.view.SurfaceView;
import com.chartboost.sdk.Libraries.CBLogging;
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.util.Map;

public class be extends SurfaceView implements bg.a {
  MediaPlayer.OnVideoSizeChangedListener a = new MediaPlayer.OnVideoSizeChangedListener(this) {
      public void onVideoSizeChanged(MediaPlayer param1MediaPlayer, int param1Int1, int param1Int2) {
        be.a(this.a, param1MediaPlayer.getVideoWidth());
        be.b(this.a, param1MediaPlayer.getVideoHeight());
        if (be.a(this.a) != 0 && be.b(this.a) != 0)
          this.a.getHolder().setFixedSize(be.a(this.a), be.b(this.a)); 
      }
    };
  
  MediaPlayer.OnPreparedListener b = new MediaPlayer.OnPreparedListener(this) {
      public void onPrepared(MediaPlayer param1MediaPlayer) {
        be.c(this.a, 2);
        be.a(this.a, param1MediaPlayer.getVideoWidth());
        be.b(this.a, param1MediaPlayer.getVideoHeight());
        if (be.c(this.a) != null)
          be.c(this.a).onPrepared(be.d(this.a)); 
        int i = be.e(this.a);
        if (i != 0)
          this.a.a(i); 
        if (be.a(this.a) != 0 && be.b(this.a) != 0) {
          this.a.getHolder().setFixedSize(be.a(this.a), be.b(this.a));
          if (be.f(this.a) == be.a(this.a) && be.g(this.a) == be.b(this.a) && be.h(this.a) == 3)
            this.a.a(); 
          return;
        } 
        if (be.h(this.a) == 3) {
          this.a.a();
          return;
        } 
      }
    };
  
  SurfaceHolder.Callback c = new SurfaceHolder.Callback(this) {
      public void surfaceChanged(SurfaceHolder param1SurfaceHolder, int param1Int1, int param1Int2, int param1Int3) {
        boolean bool = true;
        be.f(this.a, param1Int2);
        be.g(this.a, param1Int3);
        if (be.h(this.a) == 3) {
          param1Int1 = 1;
        } else {
          param1Int1 = 0;
        } 
        if (be.a(this.a) == param1Int2 && be.b(this.a) == param1Int3) {
          param1Int2 = bool;
        } else {
          param1Int2 = 0;
        } 
        if (be.d(this.a) != null && param1Int1 != 0 && param1Int2 != 0) {
          if (be.e(this.a) != 0)
            this.a.a(be.e(this.a)); 
          this.a.a();
        } 
      }
      
      public void surfaceCreated(SurfaceHolder param1SurfaceHolder) {
        be.a(this.a, param1SurfaceHolder);
        be.m(this.a);
      }
      
      public void surfaceDestroyed(SurfaceHolder param1SurfaceHolder) {
        be.a(this.a, (SurfaceHolder)null);
        be.a(this.a, true);
      }
    };
  
  private String d = "VideoSurfaceView";
  
  private Uri e;
  
  private Map<String, String> f;
  
  private int g;
  
  private int h = 0;
  
  private int i = 0;
  
  private SurfaceHolder j = null;
  
  private MediaPlayer k = null;
  
  private int l;
  
  private int m;
  
  private int n;
  
  private int o;
  
  private MediaPlayer.OnCompletionListener p;
  
  private MediaPlayer.OnPreparedListener q;
  
  private int r;
  
  private MediaPlayer.OnErrorListener s;
  
  private int t;
  
  private MediaPlayer.OnCompletionListener u = new MediaPlayer.OnCompletionListener(this) {
      public void onCompletion(MediaPlayer param1MediaPlayer) {
        be.d(this.a, 5);
        if (be.i(this.a) != 5) {
          be.c(this.a, 5);
          if (be.j(this.a) != null)
            be.j(this.a).onCompletion(be.d(this.a)); 
        } 
      }
    };
  
  private MediaPlayer.OnErrorListener v = new MediaPlayer.OnErrorListener(this) {
      public boolean onError(MediaPlayer param1MediaPlayer, int param1Int1, int param1Int2) {
        CBLogging.a(be.k(this.a), "Error: " + param1Int1 + "," + param1Int2);
        be.c(this.a, -1);
        be.d(this.a, -1);
        if (be.l(this.a) == null || be.l(this.a).onError(be.d(this.a), param1Int1, param1Int2));
        return true;
      }
    };
  
  private MediaPlayer.OnBufferingUpdateListener w = new MediaPlayer.OnBufferingUpdateListener(this) {
      public void onBufferingUpdate(MediaPlayer param1MediaPlayer, int param1Int) {
        be.e(this.a, param1Int);
      }
    };
  
  public be(Context paramContext) {
    super(paramContext);
    f();
  }
  
  private void a(boolean paramBoolean) {
    if (this.k != null) {
      this.k.reset();
      this.k.release();
      this.k = null;
      this.h = 0;
      if (paramBoolean)
        this.i = 0; 
    } 
  }
  
  private void f() {
    this.l = 0;
    this.m = 0;
    getHolder().addCallback(this.c);
    getHolder().setType(3);
    setFocusable(true);
    setFocusableInTouchMode(true);
    requestFocus();
    this.h = 0;
    this.i = 0;
  }
  
  private void g() {
    if (this.e == null || this.j == null)
      return; 
    Intent intent = new Intent("com.android.music.musicservicecommand");
    intent.putExtra("command", "pause");
    getContext().sendBroadcast(intent);
    a(false);
    try {
      this.k = new MediaPlayer();
      this.k.setOnPreparedListener(this.b);
      this.k.setOnVideoSizeChangedListener(this.a);
      this.g = -1;
      this.k.setOnCompletionListener(this.u);
      this.k.setOnErrorListener(this.v);
      this.k.setOnBufferingUpdateListener(this.w);
      this.r = 0;
      this.k.setDisplay(this.j);
      this.k.setAudioStreamType(3);
      this.k.setScreenOnWhilePlaying(true);
      FileInputStream fileInputStream = new FileInputStream(new File(this.e.toString()));
      this.k.setDataSource(fileInputStream.getFD());
      fileInputStream.close();
      this.k.prepareAsync();
      this.h = 1;
      return;
    } catch (IOException iOException) {
      CBLogging.d(this.d, "Unable to open content: " + this.e, iOException);
      this.h = -1;
      this.i = -1;
      this.v.onError(this.k, 1, 0);
      return;
    } catch (IllegalArgumentException illegalArgumentException) {
      CBLogging.d(this.d, "Unable to open content: " + this.e, illegalArgumentException);
      this.h = -1;
      this.i = -1;
      this.v.onError(this.k, 1, 0);
      return;
    } 
  }
  
  private boolean h() {
    return (this.k != null && this.h != -1 && this.h != 0 && this.h != 1);
  }
  
  public void a() {
    if (h()) {
      this.k.start();
      this.h = 3;
    } 
    this.i = 3;
  }
  
  public void a(int paramInt) {
    if (h()) {
      this.k.seekTo(paramInt);
      this.t = 0;
      return;
    } 
    this.t = paramInt;
  }
  
  public void a(int paramInt1, int paramInt2) {}
  
  public void a(MediaPlayer.OnCompletionListener paramOnCompletionListener) {
    this.p = paramOnCompletionListener;
  }
  
  public void a(MediaPlayer.OnErrorListener paramOnErrorListener) {
    this.s = paramOnErrorListener;
  }
  
  public void a(MediaPlayer.OnPreparedListener paramOnPreparedListener) {
    this.q = paramOnPreparedListener;
  }
  
  public void a(Uri paramUri) {
    a(paramUri, (Map<String, String>)null);
  }
  
  public void a(Uri paramUri, Map<String, String> paramMap) {
    this.e = paramUri;
    this.f = paramMap;
    this.t = 0;
    g();
    requestLayout();
    invalidate();
  }
  
  public void b() {
    if (h() && this.k.isPlaying()) {
      this.k.pause();
      this.h = 4;
    } 
    this.i = 4;
  }
  
  public int c() {
    if (h()) {
      if (this.g > 0)
        return this.g; 
      this.g = this.k.getDuration();
      return this.g;
    } 
    this.g = -1;
    return this.g;
  }
  
  public int d() {
    return h() ? this.k.getCurrentPosition() : 0;
  }
  
  public boolean e() {
    return (h() && this.k.isPlaying());
  }
  
  protected void onMeasure(int paramInt1, int paramInt2) {
    int i = getDefaultSize(0, paramInt1);
    paramInt2 = getDefaultSize(0, paramInt2);
    if (this.l > 0 && this.m > 0) {
      paramInt1 = Math.min(paramInt2, Math.round(this.m / this.l * i));
      float f = this.l / this.m;
      paramInt2 = Math.min(i, Math.round(paramInt2 * f));
    } else {
      paramInt1 = paramInt2;
      paramInt2 = i;
    } 
    setMeasuredDimension(paramInt2, paramInt1);
  }
}


/* Location:              C:\soft\dex2jar-2.0\Smash Cricket-dex2jar.jar!\com\chartboost\sdk\impl\be.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */