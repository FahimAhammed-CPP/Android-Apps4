package com.chartboost.sdk.impl;

import android.content.Context;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import com.chartboost.sdk.Libraries.CBUtility;
import com.chartboost.sdk.Libraries.j;

public final class aj extends am {
  private LinearLayout b;
  
  private bj c;
  
  private TextView d;
  
  public aj(Context paramContext, ai paramai) {
    super(paramContext, paramai);
  }
  
  protected View a() {
    Context context = getContext();
    int i = Math.round((getContext().getResources().getDisplayMetrics()).density * 8.0F);
    this.b = new LinearLayout(context);
    this.b.setOrientation(0);
    this.b.setGravity(17);
    int j = CBUtility.a(36, context);
    this.c = new bj(context);
    this.c.setPadding(i, i, i, i);
    LinearLayout.LayoutParams layoutParams = new LinearLayout.LayoutParams(j, j);
    this.c.setScaleType(ImageView.ScaleType.FIT_CENTER);
    this.d = new TextView(context);
    this.d.setPadding(i / 2, i, i, i);
    this.d.setTextColor(-15264491);
    this.d.setTextSize(2, 16.0F);
    this.d.setTypeface(null, 1);
    this.d.setGravity(17);
    this.b.addView((View)this.c, (ViewGroup.LayoutParams)layoutParams);
    this.b.addView((View)this.d, (ViewGroup.LayoutParams)new LinearLayout.LayoutParams(-2, -1));
    return (View)this.b;
  }
  
  public void a(j paramj) {
    this.c.a(paramj);
    this.c.setScaleType(ImageView.ScaleType.FIT_CENTER);
  }
  
  public void a(String paramString) {
    this.d.setText(paramString);
  }
  
  protected int b() {
    return 48;
  }
}


/* Location:              C:\soft\dex2jar-2.0\Smash Cricket-dex2jar.jar!\com\chartboost\sdk\impl\aj.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */