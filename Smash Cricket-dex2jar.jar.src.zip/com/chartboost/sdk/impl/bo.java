package com.chartboost.sdk.impl;

import android.content.Context;
import android.view.View;
import android.view.ViewGroup;
import android.widget.LinearLayout;
import android.widget.TextView;

public final class bo extends LinearLayout {
  private TextView a;
  
  private bq b;
  
  public bo(Context paramContext) {
    super(paramContext);
    a(paramContext);
  }
  
  private void a(Context paramContext) {
    setGravity(17);
    this.a = new TextView(getContext());
    this.a.setTextColor(-1);
    this.a.setTextSize(2, 16.0F);
    this.a.setTypeface(null, 1);
    this.a.setText("Loading...");
    this.a.setGravity(17);
    this.b = new bq(getContext());
    addView((View)this.a);
    addView(this.b);
    a();
  }
  
  public void a() {
    removeView((View)this.a);
    removeView(this.b);
    float f = (getContext().getResources().getDisplayMetrics()).density;
    int i = Math.round(20.0F * f);
    setOrientation(1);
    LinearLayout.LayoutParams layoutParams = new LinearLayout.LayoutParams(-1, -2);
    layoutParams.setMargins(i, i, i, 0);
    addView((View)this.a, (ViewGroup.LayoutParams)layoutParams);
    layoutParams = new LinearLayout.LayoutParams(-1, Math.round(f * 32.0F));
    layoutParams.setMargins(i, i, i, i);
    addView(this.b, (ViewGroup.LayoutParams)layoutParams);
  }
}


/* Location:              C:\soft\dex2jar-2.0\Smash Cricket-dex2jar.jar!\com\chartboost\sdk\impl\bo.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */