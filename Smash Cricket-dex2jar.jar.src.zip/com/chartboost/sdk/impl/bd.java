package com.chartboost.sdk.impl;

import android.text.TextUtils;
import com.chartboost.sdk.Libraries.CBLogging;
import com.chartboost.sdk.Libraries.CBUtility;
import com.chartboost.sdk.Libraries.e;
import com.chartboost.sdk.Libraries.h;
import com.chartboost.sdk.Model.CBError;
import java.util.HashMap;
import java.util.Observable;
import java.util.Observer;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.atomic.AtomicInteger;

public class bd {
  public static bd a;
  
  private static final String b = bd.class.getSimpleName();
  
  private static h c;
  
  private static m d;
  
  private static ConcurrentHashMap<Integer, b> e;
  
  private static a f;
  
  private static a g;
  
  private static AtomicInteger h = new AtomicInteger();
  
  private static AtomicInteger i = new AtomicInteger();
  
  private static boolean j = true;
  
  private static volatile com.chartboost.sdk.Model.a k;
  
  private static boolean l = false;
  
  private static Observer m = new Observer() {
      public void update(Observable param1Observable, Object param1Object) {
        bd.e();
      }
    };
  
  private static az.c n = new az.c() {
      public void a(e.a param1a, az param1az) {
        // Byte code:
        //   0: ldc com/chartboost/sdk/impl/bd
        //   2: monitorenter
        //   3: getstatic com/chartboost/sdk/impl/bd$a.a : Lcom/chartboost/sdk/impl/bd$a;
        //   6: invokestatic a : (Lcom/chartboost/sdk/impl/bd$a;)Lcom/chartboost/sdk/impl/bd$a;
        //   9: pop
        //   10: aload_1
        //   11: ifnull -> 48
        //   14: invokestatic f : ()Ljava/lang/String;
        //   17: new java/lang/StringBuilder
        //   20: dup
        //   21: invokespecial <init> : ()V
        //   24: ldc 'Got Video list from server :)'
        //   26: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
        //   29: aload_1
        //   30: invokevirtual append : (Ljava/lang/Object;)Ljava/lang/StringBuilder;
        //   33: invokevirtual toString : ()Ljava/lang/String;
        //   36: invokestatic a : (Ljava/lang/Object;Ljava/lang/String;)V
        //   39: aload_1
        //   40: ldc 'videos'
        //   42: invokevirtual a : (Ljava/lang/String;)Lcom/chartboost/sdk/Libraries/e$a;
        //   45: invokestatic a : (Lcom/chartboost/sdk/Libraries/e$a;)V
        //   48: ldc com/chartboost/sdk/impl/bd
        //   50: monitorexit
        //   51: return
        //   52: astore_1
        //   53: ldc com/chartboost/sdk/impl/bd
        //   55: monitorexit
        //   56: aload_1
        //   57: athrow
        // Exception table:
        //   from	to	target	type
        //   3	10	52	finally
        //   14	48	52	finally
        //   48	51	52	finally
        //   53	56	52	finally
      }
      
      public void a(e.a param1a, az param1az, CBError param1CBError) {
        bd.a(bd.a.a);
      }
    };
  
  public static bd a() {
    // Byte code:
    //   0: ldc com/chartboost/sdk/impl/bd
    //   2: monitorenter
    //   3: getstatic com/chartboost/sdk/impl/bd.a : Lcom/chartboost/sdk/impl/bd;
    //   6: ifnonnull -> 22
    //   9: new com/chartboost/sdk/impl/bd
    //   12: dup
    //   13: invokespecial <init> : ()V
    //   16: putstatic com/chartboost/sdk/impl/bd.a : Lcom/chartboost/sdk/impl/bd;
    //   19: invokestatic m : ()V
    //   22: getstatic com/chartboost/sdk/impl/bd.a : Lcom/chartboost/sdk/impl/bd;
    //   25: astore_0
    //   26: ldc com/chartboost/sdk/impl/bd
    //   28: monitorexit
    //   29: aload_0
    //   30: areturn
    //   31: astore_0
    //   32: ldc com/chartboost/sdk/impl/bd
    //   34: monitorexit
    //   35: aload_0
    //   36: athrow
    // Exception table:
    //   from	to	target	type
    //   3	22	31	finally
    //   22	26	31	finally
  }
  
  public static String a(String paramString) {
    return c.c(paramString) ? c.d(paramString).getPath() : null;
  }
  
  public static void a(e.a parama) {
    // Byte code:
    //   0: iconst_0
    //   1: istore_1
    //   2: ldc com/chartboost/sdk/impl/bd
    //   4: monitorenter
    //   5: invokestatic e : ()V
    //   8: aload_0
    //   9: ifnull -> 200
    //   12: new java/util/HashMap
    //   15: dup
    //   16: invokespecial <init> : ()V
    //   19: astore_2
    //   20: new java/util/HashMap
    //   23: dup
    //   24: invokespecial <init> : ()V
    //   27: astore_3
    //   28: invokestatic c : ()[Ljava/lang/String;
    //   31: astore #4
    //   33: iload_1
    //   34: aload_0
    //   35: invokevirtual o : ()I
    //   38: if_icmpge -> 159
    //   41: aload_0
    //   42: iload_1
    //   43: invokevirtual c : (I)Lcom/chartboost/sdk/Libraries/e$a;
    //   46: astore #6
    //   48: aload #6
    //   50: ldc 'id'
    //   52: invokevirtual b : (Ljava/lang/String;)Z
    //   55: ifne -> 229
    //   58: aload #6
    //   60: ldc 'video'
    //   62: invokevirtual b : (Ljava/lang/String;)Z
    //   65: ifeq -> 71
    //   68: goto -> 229
    //   71: aload #6
    //   73: ldc 'id'
    //   75: invokevirtual e : (Ljava/lang/String;)Ljava/lang/String;
    //   78: astore #5
    //   80: aload #6
    //   82: ldc 'video'
    //   84: invokevirtual e : (Ljava/lang/String;)Ljava/lang/String;
    //   87: astore #6
    //   89: getstatic com/chartboost/sdk/impl/bd.c : Lcom/chartboost/sdk/Libraries/h;
    //   92: aload #5
    //   94: invokevirtual c : (Ljava/lang/String;)Z
    //   97: ifne -> 141
    //   100: aload #5
    //   102: invokestatic isEmpty : (Ljava/lang/CharSequence;)Z
    //   105: ifne -> 141
    //   108: aload #6
    //   110: invokestatic isEmpty : (Ljava/lang/CharSequence;)Z
    //   113: ifne -> 141
    //   116: aload_3
    //   117: aload #5
    //   119: invokevirtual get : (Ljava/lang/Object;)Ljava/lang/Object;
    //   122: ifnonnull -> 141
    //   125: aload_3
    //   126: aload #5
    //   128: aload #6
    //   130: invokevirtual put : (Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    //   133: pop
    //   134: getstatic com/chartboost/sdk/impl/bd.i : Ljava/util/concurrent/atomic/AtomicInteger;
    //   137: invokevirtual incrementAndGet : ()I
    //   140: pop
    //   141: aload_2
    //   142: aload #5
    //   144: aload #6
    //   146: invokevirtual put : (Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    //   149: pop
    //   150: goto -> 229
    //   153: astore_0
    //   154: ldc com/chartboost/sdk/impl/bd
    //   156: monitorexit
    //   157: aload_0
    //   158: athrow
    //   159: getstatic com/chartboost/sdk/impl/bd.j : Z
    //   162: ifeq -> 169
    //   165: iconst_0
    //   166: putstatic com/chartboost/sdk/impl/bd.j : Z
    //   169: getstatic com/chartboost/sdk/impl/bd.b : Ljava/lang/String;
    //   172: ldc 'Synchronizing videos with the list got from the server'
    //   174: invokestatic a : (Ljava/lang/Object;Ljava/lang/String;)V
    //   177: aload_2
    //   178: aload #4
    //   180: invokestatic a : (Ljava/util/HashMap;[Ljava/lang/String;)V
    //   183: aload_3
    //   184: invokevirtual isEmpty : ()Z
    //   187: ifne -> 204
    //   190: aload_3
    //   191: invokestatic a : (Ljava/util/HashMap;)V
    //   194: getstatic com/chartboost/sdk/impl/bd$a.b : Lcom/chartboost/sdk/impl/bd$a;
    //   197: putstatic com/chartboost/sdk/impl/bd.g : Lcom/chartboost/sdk/impl/bd$a;
    //   200: ldc com/chartboost/sdk/impl/bd
    //   202: monitorexit
    //   203: return
    //   204: getstatic com/chartboost/sdk/impl/bd.k : Lcom/chartboost/sdk/Model/a;
    //   207: ifnull -> 200
    //   210: invokestatic a : ()Lcom/chartboost/sdk/impl/bd;
    //   213: astore_0
    //   214: aload_0
    //   215: monitorenter
    //   216: invokestatic o : ()V
    //   219: aload_0
    //   220: monitorexit
    //   221: goto -> 200
    //   224: astore_2
    //   225: aload_0
    //   226: monitorexit
    //   227: aload_2
    //   228: athrow
    //   229: iload_1
    //   230: iconst_1
    //   231: iadd
    //   232: istore_1
    //   233: goto -> 33
    // Exception table:
    //   from	to	target	type
    //   5	8	153	finally
    //   12	33	153	finally
    //   33	68	153	finally
    //   71	141	153	finally
    //   141	150	153	finally
    //   159	169	153	finally
    //   169	200	153	finally
    //   204	216	153	finally
    //   216	221	224	finally
    //   225	227	224	finally
    //   227	229	153	finally
  }
  
  public static void a(com.chartboost.sdk.Model.a parama) {
    // Byte code:
    //   0: ldc com/chartboost/sdk/impl/bd
    //   2: monitorenter
    //   3: aload_0
    //   4: putstatic com/chartboost/sdk/impl/bd.k : Lcom/chartboost/sdk/Model/a;
    //   7: ldc com/chartboost/sdk/impl/bd
    //   9: monitorexit
    //   10: return
    //   11: astore_0
    //   12: ldc com/chartboost/sdk/impl/bd
    //   14: monitorexit
    //   15: aload_0
    //   16: athrow
    // Exception table:
    //   from	to	target	type
    //   3	7	11	finally
  }
  
  private static void a(HashMap<String, String> paramHashMap) {
    // Byte code:
    //   0: ldc com/chartboost/sdk/impl/bd
    //   2: monitorenter
    //   3: aload_0
    //   4: invokevirtual keySet : ()Ljava/util/Set;
    //   7: invokeinterface iterator : ()Ljava/util/Iterator;
    //   12: astore_1
    //   13: aload_1
    //   14: invokeinterface hasNext : ()Z
    //   19: ifeq -> 163
    //   22: aload_1
    //   23: invokeinterface next : ()Ljava/lang/Object;
    //   28: checkcast java/lang/String
    //   31: astore_2
    //   32: new com/chartboost/sdk/impl/bd$c
    //   35: dup
    //   36: aconst_null
    //   37: invokespecial <init> : (Lcom/chartboost/sdk/impl/bd$1;)V
    //   40: astore_3
    //   41: new com/chartboost/sdk/impl/bd$b
    //   44: dup
    //   45: iconst_0
    //   46: aload_0
    //   47: aload_2
    //   48: invokevirtual get : (Ljava/lang/Object;)Ljava/lang/Object;
    //   51: checkcast java/lang/String
    //   54: aload_3
    //   55: aload_2
    //   56: invokespecial <init> : (ILjava/lang/String;Lcom/chartboost/sdk/impl/bd$c;Ljava/lang/String;)V
    //   59: astore #4
    //   61: aload #4
    //   63: new com/chartboost/sdk/impl/d
    //   66: dup
    //   67: sipush #30000
    //   70: iconst_0
    //   71: fconst_0
    //   72: invokespecial <init> : (IIF)V
    //   75: invokevirtual a : (Lcom/chartboost/sdk/impl/p;)Lcom/chartboost/sdk/impl/l;
    //   78: pop
    //   79: aload_3
    //   80: aload #4
    //   82: invokestatic a : (Lcom/chartboost/sdk/impl/bd$c;Lcom/chartboost/sdk/impl/bd$b;)Lcom/chartboost/sdk/impl/bd$b;
    //   85: pop
    //   86: aload #4
    //   88: getstatic com/chartboost/sdk/impl/bd.m : Ljava/util/Observer;
    //   91: invokevirtual hashCode : ()I
    //   94: invokestatic valueOf : (I)Ljava/lang/Integer;
    //   97: invokevirtual a : (Ljava/lang/Object;)Lcom/chartboost/sdk/impl/l;
    //   100: pop
    //   101: aload_0
    //   102: aload_2
    //   103: invokevirtual get : (Ljava/lang/Object;)Ljava/lang/Object;
    //   106: checkcast java/lang/String
    //   109: aload_2
    //   110: invokestatic a : (Ljava/lang/String;Ljava/lang/String;)V
    //   113: getstatic com/chartboost/sdk/impl/bd.d : Lcom/chartboost/sdk/impl/m;
    //   116: aload #4
    //   118: invokevirtual a : (Lcom/chartboost/sdk/impl/l;)Lcom/chartboost/sdk/impl/l;
    //   121: pop
    //   122: getstatic com/chartboost/sdk/impl/bd.b : Ljava/lang/String;
    //   125: new java/lang/StringBuilder
    //   128: dup
    //   129: invokespecial <init> : ()V
    //   132: ldc 'Downloading video:'
    //   134: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   137: aload_0
    //   138: aload_2
    //   139: invokevirtual get : (Ljava/lang/Object;)Ljava/lang/Object;
    //   142: checkcast java/lang/String
    //   145: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   148: invokevirtual toString : ()Ljava/lang/String;
    //   151: invokestatic a : (Ljava/lang/Object;Ljava/lang/String;)V
    //   154: goto -> 13
    //   157: astore_0
    //   158: ldc com/chartboost/sdk/impl/bd
    //   160: monitorexit
    //   161: aload_0
    //   162: athrow
    //   163: ldc com/chartboost/sdk/impl/bd
    //   165: monitorexit
    //   166: return
    // Exception table:
    //   from	to	target	type
    //   3	13	157	finally
    //   13	154	157	finally
  }
  
  private static void a(HashMap<String, String> paramHashMap, String[] paramArrayOfString) {
    // Byte code:
    //   0: ldc com/chartboost/sdk/impl/bd
    //   2: monitorenter
    //   3: aload_0
    //   4: ifnull -> 104
    //   7: aload_1
    //   8: ifnull -> 104
    //   11: aload_1
    //   12: arraylength
    //   13: istore_3
    //   14: iconst_0
    //   15: istore_2
    //   16: iload_2
    //   17: iload_3
    //   18: if_icmpge -> 104
    //   21: aload_1
    //   22: iload_2
    //   23: aaload
    //   24: astore #4
    //   26: aload_0
    //   27: aload #4
    //   29: invokevirtual containsKey : (Ljava/lang/Object;)Z
    //   32: ifne -> 97
    //   35: getstatic com/chartboost/sdk/impl/bd.c : Lcom/chartboost/sdk/Libraries/h;
    //   38: aload #4
    //   40: invokevirtual d : (Ljava/lang/String;)Ljava/io/File;
    //   43: astore #5
    //   45: aload #5
    //   47: ifnull -> 97
    //   50: aload #4
    //   52: ldc '.nomedia'
    //   54: invokevirtual equals : (Ljava/lang/Object;)Z
    //   57: ifne -> 97
    //   60: getstatic com/chartboost/sdk/impl/bd.b : Ljava/lang/String;
    //   63: new java/lang/StringBuilder
    //   66: dup
    //   67: invokespecial <init> : ()V
    //   70: ldc 'Deleting video: '
    //   72: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   75: aload #5
    //   77: invokevirtual getAbsolutePath : ()Ljava/lang/String;
    //   80: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   83: invokevirtual toString : ()Ljava/lang/String;
    //   86: invokestatic e : (Ljava/lang/Object;Ljava/lang/String;)V
    //   89: getstatic com/chartboost/sdk/impl/bd.c : Lcom/chartboost/sdk/Libraries/h;
    //   92: aload #5
    //   94: invokevirtual c : (Ljava/io/File;)V
    //   97: iload_2
    //   98: iconst_1
    //   99: iadd
    //   100: istore_2
    //   101: goto -> 16
    //   104: ldc com/chartboost/sdk/impl/bd
    //   106: monitorexit
    //   107: return
    //   108: astore_0
    //   109: ldc com/chartboost/sdk/impl/bd
    //   111: monitorexit
    //   112: aload_0
    //   113: athrow
    // Exception table:
    //   from	to	target	type
    //   11	14	108	finally
    //   26	45	108	finally
    //   50	97	108	finally
  }
  
  public static String b(e.a parama) {
    String str2;
    if (parama == null)
      return null; 
    e.a a2 = parama.a("assets");
    if (a2.b())
      return null; 
    if (CBUtility.c().b()) {
      str2 = "video-portrait";
    } else {
      str2 = "video-landscape";
    } 
    e.a a1 = a2.a(str2);
    if (a1.b())
      return null; 
    String str1 = a1.e("id");
    return TextUtils.isEmpty(str1) ? null : a(str1);
  }
  
  public static void b() {
    // Byte code:
    //   0: iconst_0
    //   1: istore_0
    //   2: ldc com/chartboost/sdk/impl/bd
    //   4: monitorenter
    //   5: getstatic com/chartboost/sdk/impl/bd.l : Z
    //   8: ifne -> 14
    //   11: invokestatic m : ()V
    //   14: invokestatic w : ()Z
    //   17: istore_2
    //   18: iload_2
    //   19: ifne -> 26
    //   22: ldc com/chartboost/sdk/impl/bd
    //   24: monitorexit
    //   25: return
    //   26: getstatic com/chartboost/sdk/impl/bd.b : Ljava/lang/String;
    //   29: ldc_w 'Prefetching the Video list'
    //   32: invokestatic a : (Ljava/lang/Object;Ljava/lang/String;)V
    //   35: getstatic com/chartboost/sdk/impl/bd$a.b : Lcom/chartboost/sdk/impl/bd$a;
    //   38: getstatic com/chartboost/sdk/impl/bd.f : Lcom/chartboost/sdk/impl/bd$a;
    //   41: if_acmpeq -> 22
    //   44: getstatic com/chartboost/sdk/impl/bd$a.b : Lcom/chartboost/sdk/impl/bd$a;
    //   47: getstatic com/chartboost/sdk/impl/bd.g : Lcom/chartboost/sdk/impl/bd$a;
    //   50: if_acmpeq -> 22
    //   53: getstatic com/chartboost/sdk/impl/bd.e : Ljava/util/concurrent/ConcurrentHashMap;
    //   56: ifnull -> 104
    //   59: getstatic com/chartboost/sdk/impl/bd.e : Ljava/util/concurrent/ConcurrentHashMap;
    //   62: invokevirtual isEmpty : ()Z
    //   65: ifne -> 104
    //   68: getstatic com/chartboost/sdk/impl/bd.e : Ljava/util/concurrent/ConcurrentHashMap;
    //   71: invokevirtual clear : ()V
    //   74: getstatic com/chartboost/sdk/impl/bd.d : Lcom/chartboost/sdk/impl/m;
    //   77: getstatic com/chartboost/sdk/impl/bd.m : Ljava/util/Observer;
    //   80: invokevirtual hashCode : ()I
    //   83: invokestatic valueOf : (I)Ljava/lang/Integer;
    //   86: invokevirtual a : (Ljava/lang/Object;)V
    //   89: getstatic com/chartboost/sdk/impl/bd$a.a : Lcom/chartboost/sdk/impl/bd$a;
    //   92: putstatic com/chartboost/sdk/impl/bd.g : Lcom/chartboost/sdk/impl/bd$a;
    //   95: getstatic com/chartboost/sdk/impl/bd.b : Ljava/lang/String;
    //   98: ldc_w 'prefetchVideo: Clearing all volley request for new start'
    //   101: invokestatic a : (Ljava/lang/Object;Ljava/lang/String;)V
    //   104: getstatic com/chartboost/sdk/impl/bd$a.b : Lcom/chartboost/sdk/impl/bd$a;
    //   107: putstatic com/chartboost/sdk/impl/bd.f : Lcom/chartboost/sdk/impl/bd$a;
    //   110: new org/json/JSONArray
    //   113: dup
    //   114: invokespecial <init> : ()V
    //   117: astore_3
    //   118: invokestatic c : ()[Ljava/lang/String;
    //   121: ifnull -> 154
    //   124: invokestatic c : ()[Ljava/lang/String;
    //   127: astore #4
    //   129: aload #4
    //   131: arraylength
    //   132: istore_1
    //   133: iload_0
    //   134: iload_1
    //   135: if_icmpge -> 154
    //   138: aload_3
    //   139: aload #4
    //   141: iload_0
    //   142: aaload
    //   143: invokevirtual put : (Ljava/lang/Object;)Lorg/json/JSONArray;
    //   146: pop
    //   147: iload_0
    //   148: iconst_1
    //   149: iadd
    //   150: istore_0
    //   151: goto -> 133
    //   154: invokestatic d : ()V
    //   157: getstatic com/chartboost/sdk/impl/bd.i : Ljava/util/concurrent/atomic/AtomicInteger;
    //   160: iconst_0
    //   161: invokevirtual set : (I)V
    //   164: getstatic com/chartboost/sdk/impl/bd.h : Ljava/util/concurrent/atomic/AtomicInteger;
    //   167: iconst_0
    //   168: invokevirtual set : (I)V
    //   171: new com/chartboost/sdk/impl/az
    //   174: dup
    //   175: ldc_w '/api/video-prefetch'
    //   178: invokespecial <init> : (Ljava/lang/String;)V
    //   181: astore #4
    //   183: aload #4
    //   185: ldc_w 'local-videos'
    //   188: aload_3
    //   189: invokevirtual a : (Ljava/lang/String;Ljava/lang/Object;)V
    //   192: aload #4
    //   194: iconst_2
    //   195: anewarray com/chartboost/sdk/Libraries/g$k
    //   198: dup
    //   199: iconst_0
    //   200: ldc_w 'status'
    //   203: getstatic com/chartboost/sdk/Libraries/a.a : Lcom/chartboost/sdk/Libraries/g$a;
    //   206: invokestatic a : (Ljava/lang/String;Lcom/chartboost/sdk/Libraries/g$a;)Lcom/chartboost/sdk/Libraries/g$k;
    //   209: aastore
    //   210: dup
    //   211: iconst_1
    //   212: ldc_w 'videos'
    //   215: iconst_2
    //   216: anewarray com/chartboost/sdk/Libraries/g$k
    //   219: dup
    //   220: iconst_0
    //   221: ldc 'video'
    //   223: invokestatic a : ()Lcom/chartboost/sdk/Libraries/g$a;
    //   226: invokestatic a : (Lcom/chartboost/sdk/Libraries/g$a;)Lcom/chartboost/sdk/Libraries/g$a;
    //   229: invokestatic a : (Ljava/lang/String;Lcom/chartboost/sdk/Libraries/g$a;)Lcom/chartboost/sdk/Libraries/g$k;
    //   232: aastore
    //   233: dup
    //   234: iconst_1
    //   235: ldc 'id'
    //   237: invokestatic a : ()Lcom/chartboost/sdk/Libraries/g$a;
    //   240: invokestatic a : (Ljava/lang/String;Lcom/chartboost/sdk/Libraries/g$a;)Lcom/chartboost/sdk/Libraries/g$k;
    //   243: aastore
    //   244: invokestatic a : ([Lcom/chartboost/sdk/Libraries/g$k;)Lcom/chartboost/sdk/Libraries/g$a;
    //   247: invokestatic b : (Lcom/chartboost/sdk/Libraries/g$a;)Lcom/chartboost/sdk/Libraries/g$a;
    //   250: invokestatic a : (Ljava/lang/String;Lcom/chartboost/sdk/Libraries/g$a;)Lcom/chartboost/sdk/Libraries/g$k;
    //   253: aastore
    //   254: invokestatic a : ([Lcom/chartboost/sdk/Libraries/g$k;)Lcom/chartboost/sdk/Libraries/g$a;
    //   257: invokevirtual a : (Lcom/chartboost/sdk/Libraries/g$a;)V
    //   260: aload #4
    //   262: iconst_1
    //   263: invokevirtual b : (Z)V
    //   266: aload #4
    //   268: getstatic com/chartboost/sdk/impl/bd.n : Lcom/chartboost/sdk/impl/az$c;
    //   271: invokevirtual a : (Lcom/chartboost/sdk/impl/az$c;)V
    //   274: goto -> 22
    //   277: astore_3
    //   278: ldc com/chartboost/sdk/impl/bd
    //   280: monitorexit
    //   281: aload_3
    //   282: athrow
    // Exception table:
    //   from	to	target	type
    //   5	14	277	finally
    //   14	18	277	finally
    //   26	104	277	finally
    //   104	133	277	finally
    //   138	147	277	finally
    //   154	274	277	finally
  }
  
  public static void b(String paramString) {
    if (c.c(paramString))
      c.b(paramString); 
  }
  
  public static boolean c(e.a parama) {
    return !TextUtils.isEmpty(b(parama));
  }
  
  public static String[] c() {
    return (c == null) ? null : c.a();
  }
  
  public static void d() {
    // Byte code:
    //   0: ldc com/chartboost/sdk/impl/bd
    //   2: monitorenter
    //   3: getstatic com/chartboost/sdk/impl/bd.d : Lcom/chartboost/sdk/impl/m;
    //   6: getstatic com/chartboost/sdk/impl/bd.m : Ljava/util/Observer;
    //   9: invokevirtual hashCode : ()I
    //   12: invokestatic valueOf : (I)Ljava/lang/Integer;
    //   15: invokevirtual a : (Ljava/lang/Object;)V
    //   18: ldc com/chartboost/sdk/impl/bd
    //   20: monitorexit
    //   21: return
    //   22: astore_0
    //   23: ldc com/chartboost/sdk/impl/bd
    //   25: monitorexit
    //   26: aload_0
    //   27: athrow
    // Exception table:
    //   from	to	target	type
    //   3	18	22	finally
  }
  
  private static void m() {
    // Byte code:
    //   0: ldc com/chartboost/sdk/impl/bd
    //   2: monitorenter
    //   3: getstatic com/chartboost/sdk/impl/bd.l : Z
    //   6: istore_0
    //   7: iload_0
    //   8: ifeq -> 15
    //   11: ldc com/chartboost/sdk/impl/bd
    //   13: monitorexit
    //   14: return
    //   15: iconst_1
    //   16: putstatic com/chartboost/sdk/impl/bd.l : Z
    //   19: new com/chartboost/sdk/Libraries/h
    //   22: dup
    //   23: ldc_w 'CBVideoDirectory'
    //   26: iconst_1
    //   27: invokespecial <init> : (Ljava/lang/String;Z)V
    //   30: putstatic com/chartboost/sdk/impl/bd.c : Lcom/chartboost/sdk/Libraries/h;
    //   33: new java/util/concurrent/ConcurrentHashMap
    //   36: dup
    //   37: invokespecial <init> : ()V
    //   40: putstatic com/chartboost/sdk/impl/bd.e : Ljava/util/concurrent/ConcurrentHashMap;
    //   43: getstatic com/chartboost/sdk/impl/bd$a.a : Lcom/chartboost/sdk/impl/bd$a;
    //   46: putstatic com/chartboost/sdk/impl/bd.f : Lcom/chartboost/sdk/impl/bd$a;
    //   49: getstatic com/chartboost/sdk/impl/bd$a.a : Lcom/chartboost/sdk/impl/bd$a;
    //   52: putstatic com/chartboost/sdk/impl/bd.g : Lcom/chartboost/sdk/impl/bd$a;
    //   55: invokestatic x : ()Landroid/content/Context;
    //   58: invokestatic a : (Landroid/content/Context;)Lcom/chartboost/sdk/impl/ba;
    //   61: invokevirtual a : ()Lcom/chartboost/sdk/impl/m;
    //   64: putstatic com/chartboost/sdk/impl/bd.d : Lcom/chartboost/sdk/impl/m;
    //   67: invokestatic a : ()Lcom/chartboost/sdk/impl/ay;
    //   70: getstatic com/chartboost/sdk/impl/bd.m : Ljava/util/Observer;
    //   73: invokevirtual addObserver : (Ljava/util/Observer;)V
    //   76: goto -> 11
    //   79: astore_1
    //   80: ldc com/chartboost/sdk/impl/bd
    //   82: monitorexit
    //   83: aload_1
    //   84: athrow
    // Exception table:
    //   from	to	target	type
    //   3	7	79	finally
    //   15	76	79	finally
  }
  
  private static void n() {
    // Byte code:
    //   0: ldc com/chartboost/sdk/impl/bd
    //   2: monitorenter
    //   3: getstatic com/chartboost/sdk/impl/bd.b : Ljava/lang/String;
    //   6: ldc_w 'Process Request called'
    //   9: invokestatic a : (Ljava/lang/Object;Ljava/lang/String;)V
    //   12: getstatic com/chartboost/sdk/impl/bd.f : Lcom/chartboost/sdk/impl/bd$a;
    //   15: getstatic com/chartboost/sdk/impl/bd$a.b : Lcom/chartboost/sdk/impl/bd$a;
    //   18: if_acmpeq -> 34
    //   21: getstatic com/chartboost/sdk/impl/bd.g : Lcom/chartboost/sdk/impl/bd$a;
    //   24: astore_0
    //   25: getstatic com/chartboost/sdk/impl/bd$a.b : Lcom/chartboost/sdk/impl/bd$a;
    //   28: astore_1
    //   29: aload_0
    //   30: aload_1
    //   31: if_acmpne -> 38
    //   34: ldc com/chartboost/sdk/impl/bd
    //   36: monitorexit
    //   37: return
    //   38: getstatic com/chartboost/sdk/impl/bd.g : Lcom/chartboost/sdk/impl/bd$a;
    //   41: getstatic com/chartboost/sdk/impl/bd$a.a : Lcom/chartboost/sdk/impl/bd$a;
    //   44: if_acmpne -> 53
    //   47: getstatic com/chartboost/sdk/impl/bd.e : Ljava/util/concurrent/ConcurrentHashMap;
    //   50: ifnonnull -> 62
    //   53: getstatic com/chartboost/sdk/impl/bd.e : Ljava/util/concurrent/ConcurrentHashMap;
    //   56: invokevirtual size : ()I
    //   59: ifle -> 34
    //   62: getstatic com/chartboost/sdk/impl/bd.e : Ljava/util/concurrent/ConcurrentHashMap;
    //   65: invokevirtual keySet : ()Ljava/util/Set;
    //   68: invokeinterface iterator : ()Ljava/util/Iterator;
    //   73: astore_0
    //   74: aload_0
    //   75: invokeinterface hasNext : ()Z
    //   80: ifeq -> 34
    //   83: aload_0
    //   84: invokeinterface next : ()Ljava/lang/Object;
    //   89: checkcast java/lang/Integer
    //   92: astore_1
    //   93: getstatic com/chartboost/sdk/impl/bd$a.b : Lcom/chartboost/sdk/impl/bd$a;
    //   96: putstatic com/chartboost/sdk/impl/bd.g : Lcom/chartboost/sdk/impl/bd$a;
    //   99: getstatic com/chartboost/sdk/impl/bd.d : Lcom/chartboost/sdk/impl/m;
    //   102: getstatic com/chartboost/sdk/impl/bd.e : Ljava/util/concurrent/ConcurrentHashMap;
    //   105: aload_1
    //   106: invokevirtual get : (Ljava/lang/Object;)Ljava/lang/Object;
    //   109: checkcast com/chartboost/sdk/impl/l
    //   112: invokevirtual a : (Lcom/chartboost/sdk/impl/l;)Lcom/chartboost/sdk/impl/l;
    //   115: pop
    //   116: getstatic com/chartboost/sdk/impl/bd.e : Ljava/util/concurrent/ConcurrentHashMap;
    //   119: aload_1
    //   120: invokevirtual remove : (Ljava/lang/Object;)Ljava/lang/Object;
    //   123: pop
    //   124: goto -> 74
    //   127: astore_0
    //   128: ldc com/chartboost/sdk/impl/bd
    //   130: monitorexit
    //   131: aload_0
    //   132: athrow
    // Exception table:
    //   from	to	target	type
    //   3	29	127	finally
    //   38	53	127	finally
    //   53	62	127	finally
    //   62	74	127	finally
    //   74	124	127	finally
  }
  
  private static void o() {
    CBUtility.e().post(new Runnable() {
          public void run() {
            if (bd.c(bd.h().w())) {
              bd.h().q().a(bd.h(), true);
            } else {
              bd.h().q().a(bd.h(), false);
            } 
            bd.b((com.chartboost.sdk.Model.a)null);
          }
        });
  }
  
  public enum a {
    a, b;
  }
  
  private static class b extends l<Object> {
    private String a;
    
    private long b;
    
    private String c;
    
    public b(int param1Int, String param1String1, bd.c param1c, String param1String2) {
      super(param1Int, param1String1, param1c);
      this.a = param1String2;
      this.c = param1String1;
      this.b = System.currentTimeMillis();
    }
    
    protected n<Object> a(i param1i) {
      if (param1i != null) {
        long l1 = (System.currentTimeMillis() - this.b) / 1000L;
        com.chartboost.sdk.Tracking.a.d(this.a, Long.valueOf(l1).toString(), this.c);
        CBLogging.a(bd.f(), "Video download Success. Storing video in cache" + this.a);
        bd.g().a(this.a, param1i.b);
        com.chartboost.sdk.Tracking.a.e("cache", "hit", this.a);
      } 
      synchronized (bd.a()) {
        if (bd.h() != null)
          bd.i(); 
        if (bd.j().get() == bd.k().get()) {
          bd.j().set(0);
          bd.k().set(0);
          bd.b(bd.a.a);
          bd.l().clear();
          if (bd.h() != null)
            bd.i(); 
        } 
        return n.a(null, null);
      } 
    }
    
    protected void b(Object param1Object) {}
    
    public l.a s() {
      return l.a.a;
    }
  }
  
  private static class c implements n.a {
    private bd.b a;
    
    private c() {}
    
    public void a(s param1s) {
      if (param1s instanceof r || param1s instanceof q || param1s instanceof h) {
        if (this.a != null) {
          long l = (System.currentTimeMillis() - bd.b.a(this.a)) / 1000L;
          com.chartboost.sdk.Tracking.a.a(bd.b.b(this.a), Long.valueOf(l).toString(), bd.b.c(this.a), param1s.getMessage());
          com.chartboost.sdk.Tracking.a.e("cache", "miss", bd.b.b(this.a));
        } 
        bd.l().put(Integer.valueOf(this.a.hashCode()), this.a);
        CBLogging.b(bd.f(), "Error downloading video " + param1s.getMessage() + bd.b.b(this.a));
      } 
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Smash Cricket-dex2jar.jar!\com\chartboost\sdk\impl\bd.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */