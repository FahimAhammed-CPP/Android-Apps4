package com.chartboost.sdk.impl;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.net.Uri;
import com.chartboost.sdk.Libraries.CBLogging;
import com.chartboost.sdk.Libraries.CBUtility;
import com.chartboost.sdk.Model.CBError;
import com.chartboost.sdk.b;
import com.chartboost.sdk.c;
import java.net.URI;
import java.net.URISyntaxException;

public final class bb {
  private static bb c;
  
  private a a;
  
  private com.chartboost.sdk.Model.a b;
  
  private bb(a parama) {
    this.a = parama;
  }
  
  public static bb a(a parama) {
    if (c == null)
      c = new bb(parama); 
    return c;
  }
  
  private void a(String paramString, Context paramContext, c.b paramb) {
    if (this.b != null && this.b.a())
      this.b.b = com.chartboost.sdk.Model.a.b.f; 
    Context context = paramContext;
    if (paramContext == null)
      context = b.x(); 
    if (context == null) {
      if (this.a != null)
        this.a.a(this.b, false, paramString, CBError.CBClickError.NO_HOST_ACTIVITY, paramb); 
      return;
    } 
    try {
      Intent intent = new Intent("android.intent.action.VIEW");
      if (!(context instanceof Activity))
        intent.addFlags(268435456); 
      intent.setData(Uri.parse(paramString));
      context.startActivity(intent);
    } catch (Exception exception) {}
    if (this.a != null) {
      this.a.a(this.b, true, paramString, null, paramb);
      return;
    } 
  }
  
  public static boolean a(String paramString) {
    boolean bool = false;
    try {
      Context context = b.x();
      Intent intent = new Intent("android.intent.action.VIEW");
      if (!(context instanceof Activity))
        intent.addFlags(268435456); 
      intent.setData(Uri.parse(paramString));
      int i = context.getPackageManager().queryIntentActivities(intent, 65536).size();
      if (i > 0)
        bool = true; 
      return bool;
    } catch (Exception exception) {
      CBLogging.b("CBURLOpener", "Cannot open URL", exception);
      return false;
    } 
  }
  
  public void a(com.chartboost.sdk.Model.a parama, String paramString, Activity paramActivity, c.b paramb) {
    String str;
    this.b = parama;
    try {
      URI uRI = new URI(paramString);
      str = uRI.getScheme();
      if (str == null) {
        if (this.a != null)
          this.a.a(parama, false, paramString, CBError.CBClickError.URI_INVALID, paramb); 
        return;
      } 
    } catch (URISyntaxException uRISyntaxException) {
      if (this.a != null) {
        this.a.a(parama, false, paramString, CBError.CBClickError.URI_INVALID, paramb);
        return;
      } 
      return;
    } 
    if (!str.equals("http") && !str.equals("https")) {
      a(paramString, (Context)uRISyntaxException, paramb);
      return;
    } 
    Runnable runnable = new Runnable(this, paramString, (Activity)uRISyntaxException, paramb) {
        public void a(String param1String) {
          Runnable runnable = new Runnable(this, param1String) {
              public void run() {
                bb.a(this.b.d, this.a, (Context)this.b.b, this.b.c);
              }
            };
          if (this.b != null) {
            this.b.runOnUiThread(runnable);
            return;
          } 
          CBUtility.e().post(runnable);
        }
        
        public void run() {
          // Byte code:
          //   0: aload_0
          //   1: getfield a : Ljava/lang/String;
          //   4: astore_1
          //   5: aload_1
          //   6: astore_2
          //   7: invokestatic a : ()Lcom/chartboost/sdk/impl/ay;
          //   10: invokevirtual c : ()Z
          //   13: ifeq -> 140
          //   16: aconst_null
          //   17: astore_2
          //   18: aconst_null
          //   19: astore #4
          //   21: new java/net/URL
          //   24: dup
          //   25: aload_0
          //   26: getfield a : Ljava/lang/String;
          //   29: invokespecial <init> : (Ljava/lang/String;)V
          //   32: invokevirtual openConnection : ()Ljava/net/URLConnection;
          //   35: checkcast java/net/HttpURLConnection
          //   38: astore_3
          //   39: aload_3
          //   40: iconst_0
          //   41: invokevirtual setInstanceFollowRedirects : (Z)V
          //   44: aload_3
          //   45: sipush #30000
          //   48: invokevirtual setConnectTimeout : (I)V
          //   51: aload_3
          //   52: sipush #30000
          //   55: invokevirtual setReadTimeout : (I)V
          //   58: aload_3
          //   59: ldc 'Location'
          //   61: invokevirtual getHeaderField : (Ljava/lang/String;)Ljava/lang/String;
          //   64: astore_2
          //   65: aload_2
          //   66: ifnull -> 71
          //   69: aload_2
          //   70: astore_1
          //   71: aload_1
          //   72: astore_2
          //   73: aload_3
          //   74: ifnull -> 140
          //   77: aload_3
          //   78: invokevirtual disconnect : ()V
          //   81: aload_0
          //   82: aload_1
          //   83: invokevirtual a : (Ljava/lang/String;)V
          //   86: return
          //   87: astore_2
          //   88: aload #4
          //   90: astore_3
          //   91: aload_2
          //   92: astore #4
          //   94: aload_3
          //   95: astore_2
          //   96: ldc 'CBURLOpener'
          //   98: ldc 'Exception raised while opening a HTTP Conection'
          //   100: aload #4
          //   102: invokestatic b : (Ljava/lang/Object;Ljava/lang/String;Ljava/lang/Throwable;)V
          //   105: aload_1
          //   106: astore_2
          //   107: aload_3
          //   108: ifnull -> 140
          //   111: aload_3
          //   112: invokevirtual disconnect : ()V
          //   115: goto -> 81
          //   118: astore_1
          //   119: aload_2
          //   120: ifnull -> 127
          //   123: aload_2
          //   124: invokevirtual disconnect : ()V
          //   127: aload_1
          //   128: athrow
          //   129: astore_1
          //   130: aload_3
          //   131: astore_2
          //   132: goto -> 119
          //   135: astore #4
          //   137: goto -> 94
          //   140: aload_2
          //   141: astore_1
          //   142: goto -> 81
          // Exception table:
          //   from	to	target	type
          //   21	39	87	java/lang/Exception
          //   21	39	118	finally
          //   39	65	135	java/lang/Exception
          //   39	65	129	finally
          //   96	105	118	finally
        }
      };
    ax.a().execute(runnable);
  }
  
  public static interface a {
    void a(com.chartboost.sdk.Model.a param1a, boolean param1Boolean, String param1String, CBError.CBClickError param1CBClickError, c.b param1b);
  }
}


/* Location:              C:\soft\dex2jar-2.0\Smash Cricket-dex2jar.jar!\com\chartboost\sdk\impl\bb.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */