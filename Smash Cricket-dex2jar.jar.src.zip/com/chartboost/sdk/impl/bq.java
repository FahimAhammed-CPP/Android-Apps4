package com.chartboost.sdk.impl;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.RectF;
import android.os.Handler;
import com.chartboost.sdk.Libraries.CBUtility;

public final class bq extends bn {
  private static Handler a = CBUtility.e();
  
  private float b;
  
  private long c;
  
  private Paint d;
  
  private Paint e;
  
  private Path f;
  
  private Path g;
  
  private RectF h;
  
  private RectF i;
  
  private Runnable j = new Runnable(this) {
      public void run() {
        float f = (this.a.getContext().getResources().getDisplayMetrics()).density;
        bq.a(this.a, 60.0F * f * 0.016666668F);
        f = this.a.getHeight() - f * 9.0F;
        if (bq.a(this.a) > f)
          bq.b(this.a, f * 2.0F); 
        if (this.a.getWindowVisibility() == 0)
          this.a.invalidate(); 
      }
    };
  
  public bq(Context paramContext) {
    super(paramContext);
    a(paramContext);
  }
  
  private void a(Context paramContext) {
    float f = (paramContext.getResources().getDisplayMetrics()).density;
    this.b = 0.0F;
    this.c = (long)(System.nanoTime() / 1000000.0D);
    this.d = new Paint();
    this.d.setColor(-1);
    this.d.setStyle(Paint.Style.STROKE);
    this.d.setStrokeWidth(f * 3.0F);
    this.d.setAntiAlias(true);
    this.e = new Paint();
    this.e.setColor(-1);
    this.e.setStyle(Paint.Style.FILL);
    this.e.setAntiAlias(true);
    this.f = new Path();
    this.g = new Path();
    this.i = new RectF();
    this.h = new RectF();
  }
  
  protected void a(Canvas paramCanvas) {
    // Byte code:
    //   0: aload_0
    //   1: invokevirtual getContext : ()Landroid/content/Context;
    //   4: invokevirtual getResources : ()Landroid/content/res/Resources;
    //   7: invokevirtual getDisplayMetrics : ()Landroid/util/DisplayMetrics;
    //   10: getfield density : F
    //   13: fstore_2
    //   14: aload_0
    //   15: getfield h : Landroid/graphics/RectF;
    //   18: fconst_0
    //   19: fconst_0
    //   20: aload_0
    //   21: invokevirtual getWidth : ()I
    //   24: i2f
    //   25: aload_0
    //   26: invokevirtual getHeight : ()I
    //   29: i2f
    //   30: invokevirtual set : (FFFF)V
    //   33: aload_0
    //   34: getfield h : Landroid/graphics/RectF;
    //   37: ldc 1.5
    //   39: fload_2
    //   40: fmul
    //   41: ldc 1.5
    //   43: fload_2
    //   44: fmul
    //   45: invokevirtual inset : (FF)V
    //   48: aload_0
    //   49: invokevirtual getHeight : ()I
    //   52: i2f
    //   53: fconst_2
    //   54: fdiv
    //   55: fstore_3
    //   56: aload_1
    //   57: aload_0
    //   58: getfield h : Landroid/graphics/RectF;
    //   61: fload_3
    //   62: fload_3
    //   63: aload_0
    //   64: getfield d : Landroid/graphics/Paint;
    //   67: invokevirtual drawRoundRect : (Landroid/graphics/RectF;FFLandroid/graphics/Paint;)V
    //   70: aload_0
    //   71: getfield i : Landroid/graphics/RectF;
    //   74: aload_0
    //   75: getfield h : Landroid/graphics/RectF;
    //   78: invokevirtual set : (Landroid/graphics/RectF;)V
    //   81: aload_0
    //   82: getfield i : Landroid/graphics/RectF;
    //   85: ldc 3.0
    //   87: fload_2
    //   88: fmul
    //   89: fload_2
    //   90: ldc 3.0
    //   92: fmul
    //   93: invokevirtual inset : (FF)V
    //   96: aload_0
    //   97: getfield i : Landroid/graphics/RectF;
    //   100: invokevirtual height : ()F
    //   103: fconst_2
    //   104: fdiv
    //   105: fstore_2
    //   106: aload_0
    //   107: getfield f : Landroid/graphics/Path;
    //   110: invokevirtual reset : ()V
    //   113: aload_0
    //   114: getfield f : Landroid/graphics/Path;
    //   117: aload_0
    //   118: getfield i : Landroid/graphics/RectF;
    //   121: fload_2
    //   122: fload_2
    //   123: getstatic android/graphics/Path$Direction.CW : Landroid/graphics/Path$Direction;
    //   126: invokevirtual addRoundRect : (Landroid/graphics/RectF;FFLandroid/graphics/Path$Direction;)V
    //   129: aload_0
    //   130: getfield i : Landroid/graphics/RectF;
    //   133: invokevirtual height : ()F
    //   136: fstore_3
    //   137: aload_0
    //   138: getfield g : Landroid/graphics/Path;
    //   141: invokevirtual reset : ()V
    //   144: aload_0
    //   145: getfield g : Landroid/graphics/Path;
    //   148: fconst_0
    //   149: fload_3
    //   150: invokevirtual moveTo : (FF)V
    //   153: aload_0
    //   154: getfield g : Landroid/graphics/Path;
    //   157: fload_3
    //   158: fload_3
    //   159: invokevirtual lineTo : (FF)V
    //   162: aload_0
    //   163: getfield g : Landroid/graphics/Path;
    //   166: fload_3
    //   167: fconst_2
    //   168: fmul
    //   169: fconst_0
    //   170: invokevirtual lineTo : (FF)V
    //   173: aload_0
    //   174: getfield g : Landroid/graphics/Path;
    //   177: fload_3
    //   178: fconst_0
    //   179: invokevirtual lineTo : (FF)V
    //   182: aload_0
    //   183: getfield g : Landroid/graphics/Path;
    //   186: invokevirtual close : ()V
    //   189: aload_1
    //   190: invokevirtual save : ()I
    //   193: pop
    //   194: iconst_1
    //   195: istore #5
    //   197: aload_1
    //   198: aload_0
    //   199: getfield f : Landroid/graphics/Path;
    //   202: invokevirtual clipPath : (Landroid/graphics/Path;)Z
    //   205: pop
    //   206: iload #5
    //   208: ifeq -> 295
    //   211: fload_3
    //   212: fneg
    //   213: aload_0
    //   214: getfield b : F
    //   217: fadd
    //   218: fstore_2
    //   219: fload_2
    //   220: aload_0
    //   221: getfield i : Landroid/graphics/RectF;
    //   224: invokevirtual width : ()F
    //   227: fload_3
    //   228: fadd
    //   229: fcmpg
    //   230: ifge -> 295
    //   233: aload_0
    //   234: getfield i : Landroid/graphics/RectF;
    //   237: getfield left : F
    //   240: fstore #4
    //   242: aload_1
    //   243: invokevirtual save : ()I
    //   246: pop
    //   247: aload_1
    //   248: fload #4
    //   250: fload_2
    //   251: fadd
    //   252: aload_0
    //   253: getfield i : Landroid/graphics/RectF;
    //   256: getfield top : F
    //   259: invokevirtual translate : (FF)V
    //   262: aload_1
    //   263: aload_0
    //   264: getfield g : Landroid/graphics/Path;
    //   267: aload_0
    //   268: getfield e : Landroid/graphics/Paint;
    //   271: invokevirtual drawPath : (Landroid/graphics/Path;Landroid/graphics/Paint;)V
    //   274: aload_1
    //   275: invokevirtual restore : ()V
    //   278: fload_2
    //   279: fconst_2
    //   280: fload_3
    //   281: fmul
    //   282: fadd
    //   283: fstore_2
    //   284: goto -> 219
    //   287: astore #8
    //   289: iconst_0
    //   290: istore #5
    //   292: goto -> 206
    //   295: aload_1
    //   296: invokevirtual restore : ()V
    //   299: lconst_0
    //   300: ldc2_w 16
    //   303: invokestatic nanoTime : ()J
    //   306: l2d
    //   307: ldc2_w 1000000.0
    //   310: ddiv
    //   311: d2l
    //   312: aload_0
    //   313: getfield c : J
    //   316: lsub
    //   317: lsub
    //   318: invokestatic max : (JJ)J
    //   321: lstore #6
    //   323: getstatic com/chartboost/sdk/impl/bq.a : Landroid/os/Handler;
    //   326: aload_0
    //   327: getfield j : Ljava/lang/Runnable;
    //   330: invokevirtual removeCallbacks : (Ljava/lang/Runnable;)V
    //   333: getstatic com/chartboost/sdk/impl/bq.a : Landroid/os/Handler;
    //   336: aload_0
    //   337: getfield j : Ljava/lang/Runnable;
    //   340: lload #6
    //   342: invokevirtual postDelayed : (Ljava/lang/Runnable;J)Z
    //   345: pop
    //   346: return
    // Exception table:
    //   from	to	target	type
    //   197	206	287	java/lang/UnsupportedOperationException
  }
  
  protected void onAttachedToWindow() {
    super.onAttachedToWindow();
    a.removeCallbacks(this.j);
    a.post(this.j);
  }
  
  protected void onDetachedFromWindow() {
    a.removeCallbacks(this.j);
    super.onDetachedFromWindow();
  }
  
  protected void onWindowVisibilityChanged(int paramInt) {
    super.onWindowVisibilityChanged(paramInt);
    a.removeCallbacks(this.j);
    if (paramInt == 0)
      a.post(this.j); 
  }
}


/* Location:              C:\soft\dex2jar-2.0\Smash Cricket-dex2jar.jar!\com\chartboost\sdk\impl\bq.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */