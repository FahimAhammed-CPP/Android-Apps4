package com.chartboost.sdk.impl;

import java.util.HashMap;
import java.util.Map;

abstract class df<K, V> extends da<K, V, Map<K, V>> {
  protected df(Map<? extends K, ? extends V> paramMap, da.h.a parama) {
    super(paramMap, parama);
  }
  
  public static <K, V> a<K, V> b() {
    return new a<K, V>();
  }
  
  public static <K, V> df<K, V> c() {
    return b().a();
  }
  
  public static class a<K, V> {
    private da.h.a a = da.h.a.a;
    
    private final Map<K, V> b = new HashMap<K, V>();
    
    public df<K, V> a() {
      return new df.b<K, V>(this.b, this.a);
    }
  }
  
  static class b<K, V> extends df<K, V> {
    b(Map<? extends K, ? extends V> param1Map, da.h.a param1a) {
      super(param1Map, param1a);
    }
    
    public <N extends Map<? extends K, ? extends V>> Map<K, V> a(N param1N) {
      return new HashMap<K, V>((Map<? extends K, ? extends V>)param1N);
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Smash Cricket-dex2jar.jar!\com\chartboost\sdk\impl\df.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */