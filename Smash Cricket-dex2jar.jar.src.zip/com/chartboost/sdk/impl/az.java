package com.chartboost.sdk.impl;

import android.app.Activity;
import android.content.Context;
import android.graphics.Rect;
import android.os.Build;
import android.telephony.TelephonyManager;
import android.text.TextUtils;
import android.util.DisplayMetrics;
import com.chartboost.sdk.Libraries.CBLogging;
import com.chartboost.sdk.Libraries.CBUtility;
import com.chartboost.sdk.Libraries.e;
import com.chartboost.sdk.Libraries.g;
import com.chartboost.sdk.Model.CBError;
import java.util.Date;
import java.util.HashMap;
import java.util.Locale;
import java.util.Map;

public final class az {
  private static e.a g = null;
  
  private String a;
  
  private String b;
  
  private e.a c;
  
  private Map<String, Object> d;
  
  private Map<String, Object> e;
  
  private String f;
  
  private c h = null;
  
  private boolean i = false;
  
  private boolean j = false;
  
  private g.a k = null;
  
  private ba l;
  
  private int m;
  
  private boolean n = false;
  
  private boolean o = true;
  
  private l.a p = l.a.b;
  
  public az(String paramString) {
    this.a = paramString;
    this.f = "POST";
    this.l = ba.a(com.chartboost.sdk.b.x());
    a(0);
  }
  
  public static az a(e.a parama) {
    try {
      az az1 = new az(parama.e("path"));
      az1.f = parama.e("method");
      az1.d = parama.a("query").f();
      az1.c = parama.a("body");
      az1.e = parama.a("headers").f();
      az1.j = parama.i("ensureDelivery");
      az1.b = parama.e("eventType");
      az1.a = parama.e("path");
      az1.m = parama.f("retryCount");
      if (parama.a("callback") instanceof c)
        az1.h = (c)parama.a("callback"); 
      return az1;
    } catch (Exception exception) {
      CBLogging.d("CBRequest", "Unable to deserialize failed request", exception);
      return null;
    } 
  }
  
  protected void a() {
    if (this.e == null)
      this.e = new HashMap<String, Object>(); 
    this.e.put("Accept", "application/json");
    this.e.put("X-Chartboost-Client", CBUtility.d());
    this.e.put("X-Chartboost-API", "5.4.1");
    this.e.put("X-Chartboost-Client", CBUtility.d());
  }
  
  public void a(int paramInt) {
    this.m = paramInt;
  }
  
  protected void a(Context paramContext) {
    boolean bool;
    String str = null;
    a("app", com.chartboost.sdk.b.d());
    if ("sdk".equals(Build.PRODUCT)) {
      a("model", "Android Simulator");
    } else {
      a("model", Build.MODEL);
    } 
    a("device_type", Build.MANUFACTURER + " " + Build.MODEL);
    a("os", "Android " + Build.VERSION.RELEASE);
    a("country", Locale.getDefault().getCountry());
    a("language", Locale.getDefault().getLanguage());
    a("sdk", "5.4.1");
    a("timestamp", String.valueOf(Long.valueOf((new Date()).getTime() / 1000L).intValue()));
    a("session", Integer.valueOf(CBUtility.a().getInt("cbPrefSessionCount", 0)));
    a("reachability", Integer.valueOf(ay.a().b()));
    b(paramContext);
    a("scale", "" + (paramContext.getResources().getDisplayMetrics()).density);
    if (CBUtility.c().b()) {
      bool = true;
    } else {
      bool = false;
    } 
    a("is_portrait", Integer.valueOf(bool));
    try {
      String str1 = paramContext.getPackageName();
      a("bundle", (paramContext.getPackageManager().getPackageInfo(str1, 128)).versionName);
      a("bundle_id", str1);
    } catch (Exception exception) {
      CBLogging.b("CBRequest", "Exception raised getting package mager object", exception);
    } 
    if (g == null) {
      TelephonyManager telephonyManager = (TelephonyManager)paramContext.getSystemService("phone");
      if (telephonyManager != null && telephonyManager.getPhoneType() != 0) {
        String str1 = telephonyManager.getSimOperator();
        if (!TextUtils.isEmpty(str1)) {
          str = str1.substring(0, 3);
          str1 = str1.substring(3);
        } else {
          String str2 = null;
          str1 = str;
          str = str2;
        } 
        g = e.a(new e.b[] { e.a("carrier-name", telephonyManager.getNetworkOperatorName()), e.a("mobile-country-code", str), e.a("mobile-network-code", str1), e.a("iso-country-code", telephonyManager.getNetworkCountryIso()), e.a("phone-type", Integer.valueOf(telephonyManager.getPhoneType())) });
      } else {
        g = e.a.a();
      } 
    } 
    a("carrier", g);
    a("custom_id", com.chartboost.sdk.b.n());
    if (com.chartboost.sdk.b.a() != null) {
      String str1 = com.chartboost.sdk.b.c();
      if (!TextUtils.isEmpty(str1))
        a("framework_version", str1); 
      str1 = com.chartboost.sdk.b.b();
      if (!TextUtils.isEmpty(str1))
        a("wrapper_version", str1); 
    } 
    a("rooted_device", Boolean.valueOf(CBUtility.f()));
    a("timezone", CBUtility.g());
    a("mobile_network", ay.d());
  }
  
  public void a(g.a parama) {
    if (!g.c(parama))
      CBLogging.b("CBRequest", "Validation predicate must be a dictionary style -- either VDictionary, VDictionaryExact, VDictionaryWithValues, or just a list of KV pairs."); 
    this.k = parama;
  }
  
  public void a(c paramc) {
    if (!com.chartboost.sdk.b.k()) {
      this.j = false;
      this.n = false;
    } 
    this.h = paramc;
    d(true);
    this.l.a(this, paramc);
  }
  
  public void a(d paramd, b paramb) {
    if (!com.chartboost.sdk.b.k()) {
      this.j = false;
      this.n = false;
    } 
    d(true);
    this.h = new a(paramd, paramb);
    this.l.a(this, this.h);
  }
  
  public void a(l.a parama) {
    this.p = parama;
  }
  
  public void a(String paramString) {
    this.a = paramString;
  }
  
  public void a(String paramString, e.a parama) {
    if (parama != null && parama.c(paramString))
      a(paramString, parama.e(paramString)); 
  }
  
  public void a(String paramString, Object paramObject) {
    if (this.c == null)
      this.c = e.a.a(); 
    this.c.a(paramString, paramObject);
  }
  
  public void a(String paramString1, String paramString2) {
    if (this.e == null)
      this.e = new HashMap<String, Object>(); 
    this.e.put(paramString1, paramString2);
  }
  
  public void a(boolean paramBoolean) {
    this.j = paramBoolean;
  }
  
  public void a(g.k... paramVarArgs) {
    this.k = g.a(paramVarArgs);
  }
  
  protected String b() {
    return "application/json";
  }
  
  public void b(Context paramContext) {
    int i = 0;
    if (this.c != null && this.c.a("w").c() && this.c.a("h").c())
      return; 
    try {
      if (paramContext instanceof Activity) {
        Activity activity = (Activity)paramContext;
        Rect rect = new Rect();
        activity.getWindow().getDecorView().getWindowVisibleDisplayFrame(rect);
        i = rect.width();
        try {
          bool = rect.height();
          displayMetrics = paramContext.getResources().getDisplayMetrics();
          int n = displayMetrics.widthPixels;
          int m = displayMetrics.heightPixels;
          a("dw", "" + n);
          a("dh", "" + m);
          a("dpi", "" + displayMetrics.densityDpi);
        } catch (Exception null) {
          bool = i;
        } 
      } else {
        bool = false;
        displayMetrics = displayMetrics.getResources().getDisplayMetrics();
        int n = displayMetrics.widthPixels;
        int m = displayMetrics.heightPixels;
        a("dw", "" + n);
        a("dh", "" + m);
        a("dpi", "" + displayMetrics.densityDpi);
      } 
    } catch (Exception exception) {
      bool = false;
    } 
    CBLogging.c("CBRequest", "Exception getting activity size", exception);
    i = bool;
    boolean bool = false;
    DisplayMetrics displayMetrics = displayMetrics.getResources().getDisplayMetrics();
    int k = displayMetrics.widthPixels;
    int j = displayMetrics.heightPixels;
    a("dw", "" + k);
    a("dh", "" + j);
    a("dpi", "" + displayMetrics.densityDpi);
  }
  
  public void b(c paramc) {
    if (paramc != null)
      this.h = paramc; 
  }
  
  public void b(String paramString) {
    this.b = paramString;
  }
  
  public void b(boolean paramBoolean) {
    this.n = paramBoolean;
  }
  
  public void c() {
    a("identity", com.chartboost.sdk.Libraries.c.b());
    com.chartboost.sdk.Libraries.c.a a1 = com.chartboost.sdk.Libraries.c.c();
    if (a1.b())
      a("tracking", Integer.valueOf(a1.a())); 
  }
  
  public void c(boolean paramBoolean) {
    this.o = paramBoolean;
  }
  
  public void d() {
    String str1 = com.chartboost.sdk.b.d();
    String str2 = com.chartboost.sdk.b.e();
    str2 = com.chartboost.sdk.Libraries.b.b(com.chartboost.sdk.Libraries.b.a(String.format(Locale.US, "%s %s\n%s\n%s", new Object[] { this.f, e(), str2, f() }).getBytes()));
    a("X-Chartboost-App", str1);
    a("X-Chartboost-Signature", str2);
  }
  
  public void d(boolean paramBoolean) {
    this.i = paramBoolean;
  }
  
  public String e() {
    return g() + CBUtility.a(this.d);
  }
  
  public String f() {
    return this.c.toString();
  }
  
  public String g() {
    if (this.a == null)
      return "/"; 
    StringBuilder stringBuilder = new StringBuilder();
    if (this.a.startsWith("/")) {
      String str1 = "";
      return stringBuilder.append(str1).append(this.a).toString();
    } 
    String str = "/";
    return stringBuilder.append(str).append(this.a).toString();
  }
  
  public boolean h() {
    return g().equals("/api/track");
  }
  
  public e.a i() {
    return this.c;
  }
  
  public Map<String, Object> j() {
    return this.e;
  }
  
  public boolean k() {
    return this.j;
  }
  
  public g.a l() {
    return this.k;
  }
  
  public boolean m() {
    return this.n;
  }
  
  public l.a n() {
    return this.p;
  }
  
  public int o() {
    return this.m;
  }
  
  public boolean p() {
    return this.o;
  }
  
  public boolean q() {
    return this.i;
  }
  
  public c r() {
    return this.h;
  }
  
  public void s() {
    a((d)null, (b)null);
  }
  
  public e.a t() {
    return e.a(new e.b[] { e.a("path", this.a), e.a("method", this.f), e.a("query", e.a(this.d)), e.a("body", this.c), e.a("eventType", this.b), e.a("headers", e.a(this.e)), e.a("ensureDelivery", Boolean.valueOf(this.j)), e.a("retryCount", Integer.valueOf(this.m)), e.a("callback", this.h) });
  }
  
  private static class a implements c {
    private az.d a;
    
    private az.b b;
    
    public a(az.d param1d, az.b param1b) {
      this.a = param1d;
      this.b = param1b;
    }
    
    public void a(e.a param1a, az param1az) {
      if (this.a != null)
        this.a.a(param1a, param1az); 
    }
    
    public void a(e.a param1a, az param1az, CBError param1CBError) {
      if (this.b != null)
        this.b.a(param1a, param1az, param1CBError); 
    }
  }
  
  public static abstract class b implements c {}
  
  public static interface c {
    void a(e.a param1a, az param1az);
    
    void a(e.a param1a, az param1az, CBError param1CBError);
  }
  
  public static abstract class d implements c {
    public void a(e.a param1a, az param1az, CBError param1CBError) {}
  }
}


/* Location:              C:\soft\dex2jar-2.0\Smash Cricket-dex2jar.jar!\com\chartboost\sdk\impl\az.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */