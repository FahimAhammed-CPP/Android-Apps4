package com.chartboost.sdk.impl;

public class s extends Exception {
  public final i a = null;
  
  public s() {}
  
  public s(i parami) {}
  
  public s(Throwable paramThrowable) {
    super(paramThrowable);
  }
}


/* Location:              C:\soft\dex2jar-2.0\Smash Cricket-dex2jar.jar!\com\chartboost\sdk\impl\s.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */