package com.chartboost.sdk.impl;

import android.content.Context;
import android.content.pm.PackageInfo;
import android.content.pm.PackageManager;
import android.net.http.AndroidHttpClient;
import android.os.Build;
import java.io.File;
import org.apache.http.client.HttpClient;

public class ad {
  public static m a(Context paramContext) {
    return a(paramContext, null);
  }
  
  public static m a(Context paramContext, z paramz) {
    m m2;
    File file = new File(paramContext.getCacheDir(), "volley");
    String str = "volley/0";
    try {
      String str2 = paramContext.getPackageName();
      PackageInfo packageInfo = paramContext.getPackageManager().getPackageInfo(str2, 0);
      String str1 = String.valueOf(str2) + "/" + packageInfo.versionCode;
      str = str1;
    } catch (android.content.pm.PackageManager.NameNotFoundException nameNotFoundException) {}
    z z1 = paramz;
    if (paramz == null) {
      if (Build.VERSION.SDK_INT >= 9) {
        z1 = new aa();
        u u1 = new u(z1);
        m2 = new m(new w(file), u1);
        m2.a();
        return m2;
      } 
    } else {
      u u1 = new u((z)m2);
      m m = new m(new w(file), u1);
      m.a();
      return m;
    } 
    x x = new x((HttpClient)AndroidHttpClient.newInstance(str));
    u u = new u(x);
    m m1 = new m(new w(file), u);
    m1.a();
    return m1;
  }
}


/* Location:              C:\soft\dex2jar-2.0\Smash Cricket-dex2jar.jar!\com\chartboost\sdk\impl\ad.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */