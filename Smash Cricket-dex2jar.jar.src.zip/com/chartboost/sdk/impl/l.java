package com.chartboost.sdk.impl;

import android.net.Uri;
import android.os.Handler;
import android.os.Looper;
import android.os.SystemClock;
import android.text.TextUtils;
import java.io.UnsupportedEncodingException;
import java.net.URLEncoder;
import java.util.Collections;
import java.util.Iterator;
import java.util.Map;

public abstract class l<T> implements Comparable<l<T>> {
  private final t.a a;
  
  private final int b;
  
  private final String c;
  
  private final int d;
  
  private final n.a e;
  
  private Integer f;
  
  private m g;
  
  private boolean h;
  
  private boolean i;
  
  private boolean j;
  
  private long k;
  
  private p l;
  
  private b.a m;
  
  private Object n;
  
  public l(int paramInt, String paramString, n.a parama) {
    t.a a1;
    if (t.a.a) {
      a1 = new t.a();
    } else {
      a1 = null;
    } 
    this.a = a1;
    this.h = true;
    this.i = false;
    this.j = false;
    this.k = 0L;
    this.m = null;
    this.b = paramInt;
    this.c = paramString;
    this.e = parama;
    a(new d());
    this.d = c(paramString);
  }
  
  private byte[] a(Map<String, String> paramMap, String paramString) {
    StringBuilder stringBuilder = new StringBuilder();
    try {
      Iterator<Map.Entry> iterator = paramMap.entrySet().iterator();
      while (true) {
        if (!iterator.hasNext())
          return stringBuilder.toString().getBytes(paramString); 
        Map.Entry entry = iterator.next();
        stringBuilder.append(URLEncoder.encode((String)entry.getKey(), paramString));
        stringBuilder.append('=');
        stringBuilder.append(URLEncoder.encode((String)entry.getValue(), paramString));
        stringBuilder.append('&');
      } 
    } catch (UnsupportedEncodingException unsupportedEncodingException) {
      throw new RuntimeException("Encoding not supported: " + paramString, unsupportedEncodingException);
    } 
  }
  
  private static int c(String paramString) {
    if (!TextUtils.isEmpty(paramString)) {
      Uri uri = Uri.parse(paramString);
      if (uri != null) {
        String str = uri.getHost();
        if (str != null)
          return str.hashCode(); 
      } 
    } 
    return 0;
  }
  
  public int a() {
    return this.b;
  }
  
  public int a(l<T> paraml) {
    a a1 = s();
    a a2 = paraml.s();
    return (a1 == a2) ? (this.f.intValue() - paraml.f.intValue()) : (a2.ordinal() - a1.ordinal());
  }
  
  public final l<?> a(int paramInt) {
    this.f = Integer.valueOf(paramInt);
    return this;
  }
  
  public l<?> a(b.a parama) {
    this.m = parama;
    return this;
  }
  
  public l<?> a(m paramm) {
    this.g = paramm;
    return this;
  }
  
  public l<?> a(p paramp) {
    this.l = paramp;
    return this;
  }
  
  public l<?> a(Object paramObject) {
    this.n = paramObject;
    return this;
  }
  
  protected abstract n<T> a(i parami);
  
  protected s a(s params) {
    return params;
  }
  
  public void a(String paramString) {
    if (t.a.a) {
      this.a.a(paramString, Thread.currentThread().getId());
      return;
    } 
    if (this.k == 0L) {
      this.k = SystemClock.elapsedRealtime();
      return;
    } 
  }
  
  public Object b() {
    return this.n;
  }
  
  public void b(s params) {
    if (this.e != null)
      this.e.a(params); 
  }
  
  protected abstract void b(T paramT);
  
  void b(String paramString) {
    if (this.g != null)
      this.g.b(this); 
    if (t.a.a) {
      long l2 = Thread.currentThread().getId();
      if (Looper.myLooper() != Looper.getMainLooper()) {
        (new Handler(Looper.getMainLooper())).post(new Runnable(this, paramString, l2) {
              public void run() {
                l.b(this.a).a(this.b, this.c);
                l.b(this.a).a(toString());
              }
            });
        return;
      } 
      this.a.a(paramString, l2);
      this.a.a(toString());
      return;
    } 
    long l1 = SystemClock.elapsedRealtime() - this.k;
    if (l1 >= 3000L) {
      t.b("%d ms: %s", new Object[] { Long.valueOf(l1), toString() });
      return;
    } 
  }
  
  public int c() {
    return this.d;
  }
  
  public String d() {
    return this.c;
  }
  
  public String e() {
    return d();
  }
  
  public b.a f() {
    return this.m;
  }
  
  public void g() {
    this.i = true;
  }
  
  public boolean h() {
    return this.i;
  }
  
  public Map<String, String> i() throws a {
    return Collections.emptyMap();
  }
  
  @Deprecated
  protected Map<String, String> j() throws a {
    return n();
  }
  
  @Deprecated
  protected String k() {
    return o();
  }
  
  @Deprecated
  public String l() {
    return p();
  }
  
  @Deprecated
  public byte[] m() throws a {
    Map<String, String> map = j();
    return (map != null && map.size() > 0) ? a(map, k()) : null;
  }
  
  protected Map<String, String> n() throws a {
    return null;
  }
  
  protected String o() {
    return "UTF-8";
  }
  
  public String p() {
    return "application/x-www-form-urlencoded; charset=" + o();
  }
  
  public byte[] q() throws a {
    Map<String, String> map = n();
    return (map != null && map.size() > 0) ? a(map, o()) : null;
  }
  
  public final boolean r() {
    return this.h;
  }
  
  public a s() {
    return a.b;
  }
  
  public final int t() {
    return this.l.a();
  }
  
  public String toString() {
    String str2 = "0x" + Integer.toHexString(c());
    if (this.i) {
      String str = "[X] ";
      return String.valueOf(str) + d() + " " + str2 + " " + s() + " " + this.f;
    } 
    String str1 = "[ ] ";
    return String.valueOf(str1) + d() + " " + str2 + " " + s() + " " + this.f;
  }
  
  public p u() {
    return this.l;
  }
  
  public void v() {
    this.j = true;
  }
  
  public boolean w() {
    return this.j;
  }
  
  public enum a {
    a, b, c, d;
  }
}


/* Location:              C:\soft\dex2jar-2.0\Smash Cricket-dex2jar.jar!\com\chartboost\sdk\impl\l.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */