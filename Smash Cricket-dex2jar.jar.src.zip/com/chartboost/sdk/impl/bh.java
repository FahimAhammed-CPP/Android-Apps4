package com.chartboost.sdk.impl;

import android.view.View;
import android.view.ViewTreeObserver;
import android.view.animation.AlphaAnimation;
import android.view.animation.Animation;
import android.view.animation.AnimationSet;
import android.view.animation.ScaleAnimation;
import android.view.animation.TranslateAnimation;
import com.chartboost.sdk.Libraries.CBLogging;
import com.chartboost.sdk.Libraries.CBUtility;
import com.chartboost.sdk.e;

public final class bh {
  public static void a(b paramb, com.chartboost.sdk.Model.a parama, a parama1) {
    b(paramb, parama, parama1, true);
  }
  
  public static void a(boolean paramBoolean, View paramView) {
    a(paramBoolean, paramView, 250L);
  }
  
  public static void a(boolean paramBoolean, View paramView, long paramLong) {
    float f1;
    float f2 = 1.0F;
    paramView.clearAnimation();
    if (paramBoolean)
      paramView.setVisibility(0); 
    if (paramBoolean) {
      f1 = 0.0F;
    } else {
      f1 = 1.0F;
    } 
    if (!paramBoolean)
      f2 = 0.0F; 
    AlphaAnimation alphaAnimation = new AlphaAnimation(f1, f2);
    alphaAnimation.setDuration(250L);
    alphaAnimation.setFillBefore(true);
    paramView.startAnimation((Animation)alphaAnimation);
  }
  
  public static void b(b paramb, com.chartboost.sdk.Model.a parama, a parama1) {
    c(paramb, parama, parama1, false);
  }
  
  private static void b(b paramb, com.chartboost.sdk.Model.a parama, a parama1, boolean paramBoolean) {
    if (paramb == b.g) {
      if (parama1 != null)
        parama1.a(parama); 
      return;
    } 
    if (parama == null || parama.h == null) {
      CBLogging.a("AnimationManager", "Transition of impression canceled due to lack of container");
      return;
    } 
    View view = parama.h.f();
    if (view == null) {
      e.a().d(parama);
      CBLogging.a("AnimationManager", "Transition of impression canceled due to lack of view");
      return;
    } 
    ViewTreeObserver viewTreeObserver = view.getViewTreeObserver();
    if (viewTreeObserver.isAlive()) {
      viewTreeObserver.addOnGlobalLayoutListener(new ViewTreeObserver.OnGlobalLayoutListener(view, paramb, parama, parama1, paramBoolean) {
            public void onGlobalLayout() {
              this.a.getViewTreeObserver().removeGlobalOnLayoutListener(this);
              bh.a(this.b, this.c, this.d, this.e);
            }
          });
      return;
    } 
  }
  
  private static void c(b paramb, com.chartboost.sdk.Model.a parama, a parama1, boolean paramBoolean) {
    AlphaAnimation alphaAnimation;
    AnimationSet animationSet1;
    bp bp;
    AnimationSet animationSet3;
    bm bm2;
    ScaleAnimation scaleAnimation2;
    TranslateAnimation translateAnimation2;
    bm bm1;
    ScaleAnimation scaleAnimation1;
    TranslateAnimation translateAnimation1;
    AnimationSet animationSet2 = new AnimationSet(true);
    animationSet2.addAnimation((Animation)new AlphaAnimation(1.0F, 1.0F));
    if (parama == null || parama.h == null) {
      CBLogging.a("AnimationManager", "Transition of impression canceled due to lack of container");
      return;
    } 
    View view = parama.h.f();
    if (view == null) {
      CBLogging.a("AnimationManager", "Transition of impression canceled due to lack of view");
      return;
    } 
    if (parama.e == com.chartboost.sdk.Model.a.d.c || parama.e == com.chartboost.sdk.Model.a.d.b)
      bp = parama.h; 
    float f1 = bp.getWidth();
    float f2 = bp.getHeight();
    float f3 = (1.0F - 0.4F) / 2.0F;
    switch (null.a[paramb.ordinal()]) {
      default:
        if (paramb == b.g) {
          if (parama1 != null) {
            parama1.a(parama);
            return;
          } 
          return;
        } 
        break;
      case 1:
        if (paramBoolean) {
          alphaAnimation = new AlphaAnimation(0.0F, 1.0F);
        } else {
          alphaAnimation = new AlphaAnimation(1.0F, 0.0F);
        } 
        alphaAnimation.setDuration(250L);
        alphaAnimation.setFillAfter(true);
        animationSet3 = new AnimationSet(true);
        animationSet3.addAnimation((Animation)alphaAnimation);
        animationSet1 = animationSet3;
      case 2:
        if (paramBoolean) {
          bm2 = new bm(-60.0F, 0.0F, f1 / 2.0F, f2 / 2.0F, false);
        } else {
          bm2 = new bm(0.0F, 60.0F, f1 / 2.0F, f2 / 2.0F, false);
        } 
        bm2.setDuration(250L);
        bm2.setFillAfter(true);
        animationSet1.addAnimation(bm2);
        if (paramBoolean) {
          scaleAnimation2 = new ScaleAnimation(0.4F, 1.0F, 0.4F, 1.0F);
        } else {
          scaleAnimation2 = new ScaleAnimation(1.0F, 0.4F, 1.0F, 0.4F);
        } 
        scaleAnimation2.setDuration(250L);
        scaleAnimation2.setFillAfter(true);
        animationSet1.addAnimation((Animation)scaleAnimation2);
        if (paramBoolean) {
          translateAnimation2 = new TranslateAnimation(f1 * f3, 0.0F, -f2 * 0.4F, 0.0F);
        } else {
          translateAnimation2 = new TranslateAnimation(0.0F, f1 * f3, 0.0F, f2);
        } 
        translateAnimation2.setDuration(250L);
        translateAnimation2.setFillAfter(true);
        animationSet1.addAnimation((Animation)translateAnimation2);
      case 3:
        if (paramBoolean) {
          bm1 = new bm(-60.0F, 0.0F, f1 / 2.0F, f2 / 2.0F, true);
        } else {
          bm1 = new bm(0.0F, 60.0F, f1 / 2.0F, f2 / 2.0F, true);
        } 
        bm1.setDuration(250L);
        bm1.setFillAfter(true);
        animationSet1.addAnimation(bm1);
        if (paramBoolean) {
          scaleAnimation1 = new ScaleAnimation(0.4F, 1.0F, 0.4F, 1.0F);
        } else {
          scaleAnimation1 = new ScaleAnimation(1.0F, 0.4F, 1.0F, 0.4F);
        } 
        scaleAnimation1.setDuration(250L);
        scaleAnimation1.setFillAfter(true);
        animationSet1.addAnimation((Animation)scaleAnimation1);
        if (paramBoolean) {
          translateAnimation1 = new TranslateAnimation(-f1 * 0.4F, 0.0F, f2 * f3, 0.0F);
        } else {
          translateAnimation1 = new TranslateAnimation(0.0F, f1, 0.0F, f2 * f3);
        } 
        translateAnimation1.setDuration(250L);
        translateAnimation1.setFillAfter(true);
        animationSet1.addAnimation((Animation)translateAnimation1);
      case 4:
        if (paramBoolean) {
          f1 = f2;
        } else {
          f1 = 0.0F;
        } 
        if (paramBoolean)
          f2 = 0.0F; 
        translateAnimation1 = new TranslateAnimation(0.0F, 0.0F, f1, f2);
        translateAnimation1.setDuration(250L);
        translateAnimation1.setFillAfter(true);
        animationSet1.addAnimation((Animation)translateAnimation1);
      case 5:
        if (paramBoolean) {
          f1 = -f2;
        } else {
          f1 = 0.0F;
        } 
        if (paramBoolean) {
          f2 = 0.0F;
        } else {
          f2 = -f2;
        } 
        translateAnimation1 = new TranslateAnimation(0.0F, 0.0F, f1, f2);
        translateAnimation1.setDuration(250L);
        translateAnimation1.setFillAfter(true);
        animationSet1.addAnimation((Animation)translateAnimation1);
      case 6:
        if (paramBoolean) {
          f2 = f1;
        } else {
          f2 = 0.0F;
        } 
        if (paramBoolean)
          f1 = 0.0F; 
        translateAnimation1 = new TranslateAnimation(f2, f1, 0.0F, 0.0F);
        translateAnimation1.setDuration(250L);
        translateAnimation1.setFillAfter(true);
        animationSet1.addAnimation((Animation)translateAnimation1);
      case 7:
        if (paramBoolean) {
          f2 = -f1;
        } else {
          f2 = 0.0F;
        } 
        if (paramBoolean) {
          f1 = 0.0F;
        } else {
          f1 = -f1;
        } 
        translateAnimation1 = new TranslateAnimation(f2, f1, 0.0F, 0.0F);
        translateAnimation1.setDuration(250L);
        translateAnimation1.setFillAfter(true);
        animationSet1.addAnimation((Animation)translateAnimation1);
      case 8:
        if (paramBoolean) {
          ScaleAnimation scaleAnimation = new ScaleAnimation(0.6F, 1.1F, 0.6F, 1.1F, 1, 0.5F, 1, 0.5F);
          scaleAnimation.setDuration(Math.round(150.0F));
          scaleAnimation.setStartOffset(0L);
          scaleAnimation.setFillAfter(true);
          animationSet1.addAnimation((Animation)scaleAnimation);
          scaleAnimation = new ScaleAnimation(1.0F, 0.81818175F, 1.0F, 0.81818175F, 1, 0.5F, 1, 0.5F);
          scaleAnimation.setDuration(Math.round(49.999996F));
          scaleAnimation.setStartOffset(Math.round(150.0F));
          scaleAnimation.setFillAfter(true);
          animationSet1.addAnimation((Animation)scaleAnimation);
          scaleAnimation = new ScaleAnimation(1.0F, 1.1111112F, 1.0F, 1.1111112F, 1, 0.5F, 1, 0.5F);
          scaleAnimation.setDuration(Math.round(24.99999F));
          scaleAnimation.setStartOffset(Math.round(200.0F));
          scaleAnimation.setFillAfter(true);
          animationSet1.addAnimation((Animation)scaleAnimation);
        } else {
          ScaleAnimation scaleAnimation = new ScaleAnimation(1.0F, 0.0F, 1.0F, 0.0F, 1, 0.5F, 1, 0.5F);
          scaleAnimation.setDuration(250L);
          scaleAnimation.setStartOffset(0L);
          scaleAnimation.setFillAfter(true);
          animationSet1.addAnimation((Animation)scaleAnimation);
        } 
    } 
    if (parama1 != null)
      CBUtility.e().postDelayed(new Runnable(parama1, parama) {
            public void run() {
              this.a.a(this.b);
            }
          }250L); 
    bp.startAnimation((Animation)animationSet1);
  }
  
  public static interface a {
    void a(com.chartboost.sdk.Model.a param1a);
  }
  
  public enum b {
    a, b, c, d, e, f, g, h, i;
    
    public static b a(int param1Int) {
      return (param1Int != 0 && param1Int > 0 && param1Int <= (values()).length) ? values()[param1Int - 1] : null;
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Smash Cricket-dex2jar.jar!\com\chartboost\sdk\impl\bh.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */