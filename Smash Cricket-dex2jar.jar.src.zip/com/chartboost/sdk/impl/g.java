package com.chartboost.sdk.impl;

import android.annotation.TargetApi;
import android.net.TrafficStats;
import android.os.Build;
import android.os.Process;
import java.util.concurrent.BlockingQueue;

public class g extends Thread {
  private final BlockingQueue<l<?>> a;
  
  private final f b;
  
  private final b c;
  
  private final o d;
  
  private volatile boolean e = false;
  
  public g(BlockingQueue<l<?>> paramBlockingQueue, f paramf, b paramb, o paramo) {
    this.a = paramBlockingQueue;
    this.b = paramf;
    this.c = paramb;
    this.d = paramo;
  }
  
  @TargetApi(14)
  private void a(l<?> paraml) {
    if (Build.VERSION.SDK_INT >= 14)
      TrafficStats.setThreadStatsTag(paraml.c()); 
  }
  
  private void a(l<?> paraml, s params) {
    params = paraml.a(params);
    this.d.a(paraml, params);
  }
  
  public void a() {
    this.e = true;
    interrupt();
  }
  
  public void run() {
    Process.setThreadPriority(10);
    while (true) {
      try {
        l<?> l = this.a.take();
        try {
          l.a("network-queue-take");
          if (l.h()) {
            l.b("network-discard-cancelled");
            continue;
          } 
          a(l);
          i i = this.b.a(l);
          l.a("network-http-complete");
          if (i.d && l.w())
            l.b("not-modified"); 
        } catch (s s) {
          a(l, s);
        } catch (Exception exception) {
          t.a(exception, "Unhandled exception %s", new Object[] { exception.toString() });
          this.d.a(l, new s(exception));
        } 
      } catch (InterruptedException interruptedException) {
        if (this.e)
          return; 
      } 
    } 
  }
}


/* Location:              C:\soft\dex2jar-2.0\Smash Cricket-dex2jar.jar!\com\chartboost\sdk\impl\g.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */