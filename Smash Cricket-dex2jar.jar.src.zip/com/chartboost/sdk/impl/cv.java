package com.chartboost.sdk.impl;

public class cv extends cu {
  final cj b;
  
  public cj b() {
    return this.b;
  }
  
  public boolean equals(Object paramObject) {
    if (paramObject instanceof cv) {
      paramObject = paramObject;
      if (this.a.equals(((cv)paramObject).a) && this.b.equals(((cv)paramObject).b))
        return true; 
    } 
    return false;
  }
  
  public int hashCode() {
    return this.a.hashCode() ^ this.b.hashCode();
  }
}


/* Location:              C:\soft\dex2jar-2.0\Smash Cricket-dex2jar.jar!\com\chartboost\sdk\impl\cv.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */