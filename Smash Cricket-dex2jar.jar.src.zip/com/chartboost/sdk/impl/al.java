package com.chartboost.sdk.impl;

import android.content.Context;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import com.chartboost.sdk.f;

public final class al extends LinearLayout {
  private ai a;
  
  private LinearLayout b;
  
  private bj c;
  
  private TextView d;
  
  private bk e;
  
  private int f = Integer.MIN_VALUE;
  
  public al(Context paramContext, ai paramai) {
    super(paramContext);
    this.a = paramai;
    a(paramContext);
  }
  
  private void a(Context paramContext) {
    float f;
    Context context = getContext();
    int i = Math.round((getContext().getResources().getDisplayMetrics()).density * 8.0F);
    setOrientation(1);
    setGravity(17);
    this.b = new LinearLayout(context);
    this.b.setGravity(17);
    this.b.setOrientation(0);
    this.b.setPadding(i, i, i, i);
    this.c = new bj(context);
    this.c.setScaleType(ImageView.ScaleType.FIT_CENTER);
    this.c.setPadding(0, 0, i, 0);
    LinearLayout.LayoutParams layoutParams2 = new LinearLayout.LayoutParams(-2, -2);
    this.a.a((ViewGroup.LayoutParams)layoutParams2, this.a.E, 1.0F);
    this.d = new TextView(getContext());
    this.d.setTextColor(-1);
    this.d.setTypeface(null, 1);
    this.d.setGravity(17);
    TextView textView = this.d;
    if (f.a(paramContext)) {
      f = 26.0F;
    } else {
      f = 16.0F;
    } 
    textView.setTextSize(2, f);
    this.b.addView((View)this.c, (ViewGroup.LayoutParams)layoutParams2);
    this.b.addView((View)this.d, (ViewGroup.LayoutParams)new LinearLayout.LayoutParams(-2, -2));
    this.e = new bk(this, getContext()) {
        protected void a(MotionEvent param1MotionEvent) {
          al.a(this.a).setEnabled(false);
          al.b(this.a).p().i();
        }
      };
    this.e.setPadding(0, 0, 0, i);
    this.e.a(ImageView.ScaleType.FIT_CENTER);
    this.e.setPadding(i, i, i, i);
    LinearLayout.LayoutParams layoutParams1 = new LinearLayout.LayoutParams(-2, -2);
    this.a.a((ViewGroup.LayoutParams)layoutParams1, this.a.D, 1.0F);
    if (this.a.E.e())
      this.c.a(this.a.E); 
    if (this.a.D.e())
      this.e.a(this.a.D); 
    addView((View)this.b, (ViewGroup.LayoutParams)new LinearLayout.LayoutParams(-2, -2));
    addView((View)this.e, (ViewGroup.LayoutParams)layoutParams1);
    a();
  }
  
  public void a() {
    a(this.a.r());
  }
  
  public void a(String paramString, int paramInt) {
    this.d.setText(paramString);
    this.f = paramInt;
    a(this.a.r());
  }
  
  public void a(boolean paramBoolean) {
    int i;
    if (paramBoolean) {
      i = -16777216;
    } else {
      i = this.f;
    } 
    setBackgroundColor(i);
  }
}


/* Location:              C:\soft\dex2jar-2.0\Smash Cricket-dex2jar.jar!\com\chartboost\sdk\impl\al.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */