package com.chartboost.sdk;

import android.content.Context;
import android.os.Handler;
import com.chartboost.sdk.Libraries.CBLogging;
import com.chartboost.sdk.Libraries.CBUtility;
import com.chartboost.sdk.Libraries.e;
import com.chartboost.sdk.Model.CBError;
import com.chartboost.sdk.Model.a;
import com.chartboost.sdk.Tracking.a;
import com.chartboost.sdk.impl.ay;
import com.chartboost.sdk.impl.az;
import java.lang.reflect.Method;
import java.util.Date;
import java.util.HashMap;
import java.util.Map;
import java.util.concurrent.TimeUnit;

public abstract class d {
  protected static Handler a = CBUtility.e();
  
  private Map<String, a> b = new HashMap<String, a>();
  
  private Map<String, a> c = new HashMap<String, a>();
  
  private Map<String, a> d = new HashMap<String, a>();
  
  private a e = null;
  
  private void b(a parama, boolean paramBoolean) {
    boolean bool;
    if (parama.b == a.b.d) {
      bool = true;
    } else {
      bool = false;
    } 
    i(parama);
    e e = Chartboost.h();
    if (e != null)
      if (e.b()) {
        e.a(parama, false);
      } else if (parama.i && !bool && parama.b != a.b.c) {
        return;
      }  
    if (paramBoolean) {
      h(parama);
      return;
    } 
    Chartboost.a(parama);
  }
  
  private final boolean r(a parama) {
    // Byte code:
    //   0: iconst_1
    //   1: istore_2
    //   2: aload_0
    //   3: monitorenter
    //   4: aload_0
    //   5: aload_1
    //   6: invokevirtual n : (Lcom/chartboost/sdk/Model/a;)Lcom/chartboost/sdk/Model/a;
    //   9: ifnull -> 47
    //   12: aload_0
    //   13: invokevirtual getClass : ()Ljava/lang/Class;
    //   16: invokevirtual getSimpleName : ()Ljava/lang/String;
    //   19: ldc '%s %s'
    //   21: iconst_2
    //   22: anewarray java/lang/Object
    //   25: dup
    //   26: iconst_0
    //   27: ldc 'Request already in process for impression with location'
    //   29: aastore
    //   30: dup
    //   31: iconst_1
    //   32: aload_1
    //   33: getfield d : Ljava/lang/String;
    //   36: aastore
    //   37: invokestatic format : (Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/String;
    //   40: invokestatic b : (Ljava/lang/Object;Ljava/lang/String;)V
    //   43: aload_0
    //   44: monitorexit
    //   45: iload_2
    //   46: ireturn
    //   47: aload_0
    //   48: aload_1
    //   49: invokevirtual p : (Lcom/chartboost/sdk/Model/a;)V
    //   52: iconst_0
    //   53: istore_2
    //   54: goto -> 43
    //   57: astore_1
    //   58: aload_0
    //   59: monitorexit
    //   60: aload_1
    //   61: athrow
    // Exception table:
    //   from	to	target	type
    //   4	43	57	finally
    //   47	52	57	finally
  }
  
  protected abstract a a(String paramString, boolean paramBoolean);
  
  protected void a() {
    this.c.clear();
  }
  
  protected void a(a parama) {
    q(parama);
    b().d(parama);
    parama.b = a.b.d;
  }
  
  protected void a(a parama, e.a parama1) {
    if (parama1.f("status") == 404) {
      CBLogging.b(parama.c, "Invalid status code" + parama1.a("status"));
      a(parama, CBError.CBImpressionError.NO_AD_FOUND);
      return;
    } 
    if (parama1.f("status") != 200) {
      CBLogging.b(parama.c, "Invalid status code" + parama1.a("status"));
      a(parama, CBError.CBImpressionError.INVALID_RESPONSE);
      return;
    } 
    a.c(e(), parama.p(), parama.f);
    parama.a(parama1, (c.a()).a);
  }
  
  protected void a(a parama, CBError.CBImpressionError paramCBImpressionError) {
    o(parama);
    e e = Chartboost.h();
    if (e != null && e.b()) {
      e.a(parama, true);
    } else if (e != null && e.c()) {
      e.b(parama);
    } 
    a.a(e(), parama.d, paramCBImpressionError);
    b().a(parama, paramCBImpressionError);
  }
  
  public void a(a parama, boolean paramBoolean) {}
  
  protected final void a(az paramaz, a parama) {
    paramaz.a("location", parama.d);
    if (parama.f) {
      paramaz.a("cache", "1");
      paramaz.b(true);
    } 
    paramaz.b(Chartboost.getValidContext());
    parama.q = true;
    paramaz.a(new az.c(this, parama) {
          public void a(e.a param1a, az param1az) {
            this.a.q = false;
            if (param1a.b() || (!param1a.a("assets").b() && !param1a.a("interstitials").b())) {
              this.b.a(this.a, CBError.CBImpressionError.NO_AD_FOUND);
              return;
            } 
            this.b.a(this.a, param1a);
          }
          
          public void a(e.a param1a, az param1az, CBError param1CBError) {
            String str1;
            this.a.q = false;
            String str2 = param1az.g();
            String str3 = param1CBError.a().name();
            if (param1CBError.b() != null) {
              str1 = param1CBError.b();
            } else {
              str1 = "";
            } 
            CBLogging.d("network failure", String.format("request %s failed with error %s: %s", new Object[] { str2, str3, str1 }));
            this.b.a(this.a, param1CBError.c());
          }
        });
  }
  
  public void a(String paramString) {
    a a1 = a(paramString, false);
    e e = Chartboost.h();
    if (e != null && e.c()) {
      a(a1, CBError.CBImpressionError.IMPRESSION_ALREADY_VISIBLE);
      return;
    } 
    if (!b(a1)) {
      a.post(new Runnable(this, paramString, a1) {
            public void run() {
              if (this.c.c(this.a)) {
                a a1 = this.c.d(this.a);
                if (a1.b == a.b.f)
                  a1.b = a.b.d; 
                this.c.g(a1);
                return;
              } 
              this.c.c(this.b);
            }
          });
      return;
    } 
  }
  
  protected final a b() {
    if (this.e == null)
      this.e = c(); 
    return this.e;
  }
  
  public void b(String paramString) {
    if (c(paramString)) {
      a1 = d(paramString);
      if (a1 != null)
        b().d(a1); 
      return;
    } 
    a a1 = a((String)a1, true);
    if (!b(a1)) {
      c(a1);
      return;
    } 
  }
  
  protected void b(String paramString, boolean paramBoolean) {
    String str = paramString;
    if (paramString == null)
      str = ""; 
    a a1 = this.d.get(str);
    if (a1 != null) {
      this.d.remove(str);
      if (paramBoolean)
        b(a1, true); 
    } 
  }
  
  protected final boolean b(a parama) {
    if (!b().h(parama) && CBUtility.a().getInt("cbPrefSessionCount", 0) == 1) {
      a(parama, CBError.CBImpressionError.FIRST_SESSION_INTERSTITIALS_DISABLED);
      return true;
    } 
    return false;
  }
  
  protected abstract a c();
  
  protected void c(a parama) {
    if (f(parama) && b().g(parama) && !r(parama)) {
      if (!parama.f && parama.c == a.c.b && b.v()) {
        parama.i = true;
        Chartboost.a(parama);
      } 
      if (!d(parama)) {
        o(parama);
        return;
      } 
      az az = e(parama);
      if (az != null) {
        a(az, parama);
        a.a(e(), parama.d, parama.f);
        return;
      } 
    } 
  }
  
  public boolean c(String paramString) {
    return (d(paramString) != null);
  }
  
  protected Context d() {
    try {
      Method method = Chartboost.class.getDeclaredMethod("getValidContext", new Class[0]);
      method.setAccessible(true);
      return (Context)method.invoke(null, new Object[0]);
    } catch (Exception exception) {
      CBLogging.b(this, "Error encountered getting valid context", exception);
      CBUtility.throwProguardError(exception);
      return b.x();
    } 
  }
  
  protected a d(String paramString) {
    a a1 = this.c.get(paramString);
    return (a1 != null && !m(a1)) ? a1 : null;
  }
  
  protected boolean d(a parama) {
    return true;
  }
  
  protected abstract az e(a parama);
  
  public abstract String e();
  
  protected void e(String paramString) {
    this.c.remove(paramString);
  }
  
  protected final boolean f(a parama) {
    if (!b.o()) {
      a(parama, CBError.CBImpressionError.SESSION_NOT_STARTED);
      return false;
    } 
    e e = Chartboost.h();
    if (!parama.f && e != null && e.c()) {
      a(parama, CBError.CBImpressionError.IMPRESSION_ALREADY_VISIBLE);
      return false;
    } 
    if (!ay.a().c()) {
      a(parama, CBError.CBImpressionError.INTERNET_UNAVAILABLE);
      return false;
    } 
    return true;
  }
  
  protected void g(a parama) {
    boolean bool;
    o(parama);
    if (parama.b != a.b.c) {
      bool = true;
    } else {
      bool = false;
    } 
    if (bool) {
      if (b.a() != null && b.a().doesWrapperUseCustomShouldDisplayBehavior()) {
        String str;
        if (parama.d == null) {
          str = "";
        } else {
          str = parama.d;
        } 
        this.d.put(str, parama);
      } 
      if (!b().f(parama))
        return; 
    } 
    b(parama, bool);
  }
  
  protected void h(a parama) {
    Chartboost.a(parama);
  }
  
  protected void i(a parama) {
    j(parama);
  }
  
  public void j(a parama) {
    if (!parama.g) {
      parama.g = true;
      parama.f = false;
      k(parama);
      if (d(parama.d) == parama) {
        e(parama.d);
        return;
      } 
    } 
  }
  
  protected void k(a parama) {
    az az = l(parama);
    az.a(true);
    az.b(d());
    if (parama.f) {
      az.a("cached", "1");
    } else {
      az.a("cached", "0");
    } 
    String str = parama.w().e("ad_id");
    if (str != null)
      az.a("ad_id", str); 
    az.a("location", parama.d);
    az.a((az.c)new az.d(this, parama) {
          public void a(e.a param1a, az param1az) {
            if (b.i() && !this.b.c(this.a.d))
              this.b.b(this.a.d); 
          }
        });
    a.a(e(), parama.d, parama.p());
  }
  
  protected abstract az l(a parama);
  
  protected final boolean m(a parama) {
    return (TimeUnit.MILLISECONDS.toSeconds((new Date()).getTime() - parama.a.getTime()) >= 86400L);
  }
  
  protected a n(a parama) {
    // Byte code:
    //   0: aload_0
    //   1: monitorenter
    //   2: aload_1
    //   3: ifnull -> 27
    //   6: aload_0
    //   7: getfield b : Ljava/util/Map;
    //   10: aload_1
    //   11: getfield d : Ljava/lang/String;
    //   14: invokeinterface get : (Ljava/lang/Object;)Ljava/lang/Object;
    //   19: checkcast com/chartboost/sdk/Model/a
    //   22: astore_1
    //   23: aload_0
    //   24: monitorexit
    //   25: aload_1
    //   26: areturn
    //   27: aconst_null
    //   28: astore_1
    //   29: goto -> 23
    //   32: astore_1
    //   33: aload_0
    //   34: monitorexit
    //   35: aload_1
    //   36: athrow
    // Exception table:
    //   from	to	target	type
    //   6	23	32	finally
  }
  
  protected void o(a parama) {
    // Byte code:
    //   0: aload_0
    //   1: monitorenter
    //   2: aload_1
    //   3: ifnull -> 20
    //   6: aload_0
    //   7: getfield b : Ljava/util/Map;
    //   10: aload_1
    //   11: getfield d : Ljava/lang/String;
    //   14: invokeinterface remove : (Ljava/lang/Object;)Ljava/lang/Object;
    //   19: pop
    //   20: aload_0
    //   21: monitorexit
    //   22: return
    //   23: astore_1
    //   24: aload_0
    //   25: monitorexit
    //   26: aload_1
    //   27: athrow
    // Exception table:
    //   from	to	target	type
    //   6	20	23	finally
  }
  
  protected void p(a parama) {
    // Byte code:
    //   0: aload_0
    //   1: monitorenter
    //   2: aload_1
    //   3: ifnull -> 21
    //   6: aload_0
    //   7: getfield b : Ljava/util/Map;
    //   10: aload_1
    //   11: getfield d : Ljava/lang/String;
    //   14: aload_1
    //   15: invokeinterface put : (Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    //   20: pop
    //   21: aload_0
    //   22: monitorexit
    //   23: return
    //   24: astore_1
    //   25: aload_0
    //   26: monitorexit
    //   27: aload_1
    //   28: athrow
    // Exception table:
    //   from	to	target	type
    //   6	21	24	finally
  }
  
  protected void q(a parama) {
    this.c.put(parama.d, parama);
  }
  
  protected static interface a {
    void a(a param1a);
    
    void a(a param1a, CBError.CBImpressionError param1CBImpressionError);
    
    void b(a param1a);
    
    void c(a param1a);
    
    void d(a param1a);
    
    void e(a param1a);
    
    boolean f(a param1a);
    
    boolean g(a param1a);
    
    boolean h(a param1a);
  }
}


/* Location:              C:\soft\dex2jar-2.0\Smash Cricket-dex2jar.jar!\com\chartboost\sdk\d.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */