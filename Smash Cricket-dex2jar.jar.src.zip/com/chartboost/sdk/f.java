package com.chartboost.sdk;

import android.app.Activity;
import android.content.Context;
import android.os.Handler;
import android.view.View;
import android.widget.RelativeLayout;
import com.chartboost.sdk.Libraries.CBLogging;
import com.chartboost.sdk.Libraries.CBUtility;
import com.chartboost.sdk.Libraries.e;
import com.chartboost.sdk.Libraries.f;
import com.chartboost.sdk.Model.CBError;
import com.chartboost.sdk.Model.a;
import com.chartboost.sdk.impl.bh;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public abstract class f {
  public static Handler a = CBUtility.e();
  
  public boolean b = false;
  
  protected List<b> c = new ArrayList<b>();
  
  protected List<b> d = new ArrayList<b>();
  
  protected e.a e;
  
  protected a f;
  
  protected f g;
  
  public Map<Integer, Runnable> h = Collections.synchronizedMap(new HashMap<Integer, Runnable>());
  
  protected boolean i = true;
  
  protected boolean j = true;
  
  private boolean k;
  
  private a l;
  
  public f(a parama) {
    this.f = parama;
    this.l = null;
    this.g = CBUtility.c();
    this.k = false;
  }
  
  public static int a(String paramString) {
    // Byte code:
    //   0: iconst_0
    //   1: istore_1
    //   2: aload_0
    //   3: ifnull -> 22
    //   6: aload_0
    //   7: astore_2
    //   8: aload_0
    //   9: ldc '#'
    //   11: invokevirtual startsWith : (Ljava/lang/String;)Z
    //   14: ifne -> 45
    //   17: aload_0
    //   18: invokestatic parseColor : (Ljava/lang/String;)I
    //   21: istore_1
    //   22: iload_1
    //   23: ireturn
    //   24: astore_2
    //   25: new java/lang/StringBuilder
    //   28: dup
    //   29: invokespecial <init> : ()V
    //   32: ldc '#'
    //   34: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   37: aload_0
    //   38: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   41: invokevirtual toString : ()Ljava/lang/String;
    //   44: astore_2
    //   45: aload_2
    //   46: invokevirtual length : ()I
    //   49: iconst_4
    //   50: if_icmpeq -> 63
    //   53: aload_2
    //   54: astore_0
    //   55: aload_2
    //   56: invokevirtual length : ()I
    //   59: iconst_5
    //   60: if_icmpne -> 134
    //   63: new java/lang/StringBuilder
    //   66: dup
    //   67: aload_2
    //   68: invokevirtual length : ()I
    //   71: iconst_2
    //   72: imul
    //   73: iconst_1
    //   74: iadd
    //   75: invokespecial <init> : (I)V
    //   78: astore_0
    //   79: aload_0
    //   80: ldc '#'
    //   82: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   85: pop
    //   86: iconst_0
    //   87: istore_1
    //   88: iload_1
    //   89: aload_2
    //   90: invokevirtual length : ()I
    //   93: iconst_1
    //   94: isub
    //   95: if_icmpge -> 129
    //   98: aload_0
    //   99: aload_2
    //   100: iload_1
    //   101: iconst_1
    //   102: iadd
    //   103: invokevirtual charAt : (I)C
    //   106: invokevirtual append : (C)Ljava/lang/StringBuilder;
    //   109: pop
    //   110: aload_0
    //   111: aload_2
    //   112: iload_1
    //   113: iconst_1
    //   114: iadd
    //   115: invokevirtual charAt : (I)C
    //   118: invokevirtual append : (C)Ljava/lang/StringBuilder;
    //   121: pop
    //   122: iload_1
    //   123: iconst_1
    //   124: iadd
    //   125: istore_1
    //   126: goto -> 88
    //   129: aload_0
    //   130: invokevirtual toString : ()Ljava/lang/String;
    //   133: astore_0
    //   134: aload_0
    //   135: invokestatic parseColor : (Ljava/lang/String;)I
    //   138: istore_1
    //   139: iload_1
    //   140: ireturn
    //   141: astore_2
    //   142: ldc 'CBViewProtocol'
    //   144: new java/lang/StringBuilder
    //   147: dup
    //   148: invokespecial <init> : ()V
    //   151: ldc 'error parsing color '
    //   153: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   156: aload_0
    //   157: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   160: invokevirtual toString : ()Ljava/lang/String;
    //   163: aload_2
    //   164: invokestatic d : (Ljava/lang/Object;Ljava/lang/String;Ljava/lang/Throwable;)V
    //   167: iconst_0
    //   168: ireturn
    // Exception table:
    //   from	to	target	type
    //   17	22	24	java/lang/IllegalArgumentException
    //   134	139	141	java/lang/IllegalArgumentException
  }
  
  public static boolean a(Context paramContext) {
    return (((paramContext.getResources().getConfiguration()).screenLayout & 0xF) >= 4);
  }
  
  public f a() {
    return this.g;
  }
  
  protected void a(View paramView, Runnable paramRunnable, long paramLong) {
    Runnable runnable = this.h.get(Integer.valueOf(paramView.hashCode()));
    if (runnable != null)
      a.removeCallbacks(runnable); 
    this.h.put(Integer.valueOf(paramView.hashCode()), paramRunnable);
    a.postDelayed(paramRunnable, paramLong);
  }
  
  protected void a(CBError.CBImpressionError paramCBImpressionError) {
    this.f.a(paramCBImpressionError);
  }
  
  public void a(b paramb) {
    if (paramb.a())
      this.d.remove(paramb); 
    this.c.remove(paramb);
    if (!this.c.isEmpty() || b())
      return; 
    CBLogging.b("CBViewProtocol", "Error while downloading the assets");
    a(CBError.CBImpressionError.ASSETS_DOWNLOAD_FAILURE);
  }
  
  public void a(boolean paramBoolean, View paramView) {
    a(paramBoolean, paramView, true);
  }
  
  public void a(boolean paramBoolean1, View paramView, boolean paramBoolean2) {
    byte b = 8;
    if (((paramBoolean1 && paramView.getVisibility() == 0) || (!paramBoolean1 && paramView.getVisibility() == 8)) && this.h.get(Integer.valueOf(paramView.hashCode())) == null)
      return; 
    if (!paramBoolean2) {
      if (paramBoolean1)
        b = 0; 
      paramView.setVisibility(b);
      paramView.setClickable(paramBoolean1);
      return;
    } 
    Runnable runnable = new Runnable(this, paramBoolean1, paramView) {
        public void run() {
          if (!this.a) {
            this.b.setVisibility(8);
            this.b.setClickable(false);
          } 
          this.c.h.remove(Integer.valueOf(this.b.hashCode()));
        }
      };
    bh.a(paramBoolean1, paramView, 250L);
    a(paramView, runnable, 250L);
  }
  
  public boolean a(e.a parama) {
    this.e = parama.a("assets");
    if (this.e.b()) {
      CBLogging.b("CBViewProtocol", "Assets got from the response is null or empty");
      a(CBError.CBImpressionError.INVALID_RESPONSE);
      return false;
    } 
    return true;
  }
  
  public boolean a(String paramString, e.a parama) {
    return this.f.a(paramString, parama);
  }
  
  protected abstract a b(Context paramContext);
  
  public void b(b paramb) {
    this.c.add(paramb);
    this.d.add(paramb);
  }
  
  public boolean b() {
    if (!this.d.isEmpty()) {
      CBLogging.d("CBViewProtocol", "not completed loading assets for impression");
      return false;
    } 
    i();
    return true;
  }
  
  public CBError.CBImpressionError c() {
    CBError.CBImpressionError cBImpressionError = null;
    Activity activity = Chartboost.f();
    if (activity == null) {
      this.l = null;
      return CBError.CBImpressionError.NO_HOST_ACTIVITY;
    } 
    if (!this.j && !this.i)
      return CBError.CBImpressionError.WRONG_ORIENTATION; 
    this.g = CBUtility.c();
    if ((this.g.c() && !this.j) || (this.g.b() && !this.i))
      this.g = this.g.a(); 
    if (this.l == null)
      this.l = b((Context)activity); 
    if (!this.l.a(activity)) {
      this.l = null;
      return CBError.CBImpressionError.ERROR_CREATING_VIEW;
    } 
    return cBImpressionError;
  }
  
  public void d() {
    f();
    for (int i = 0; i < this.h.size(); i++)
      a.removeCallbacks(this.h.get(Integer.valueOf(i))); 
    this.h.clear();
  }
  
  public a e() {
    return this.l;
  }
  
  public void f() {
    if (this.l != null)
      this.l.b(); 
    this.l = null;
  }
  
  public e.a g() {
    return this.e;
  }
  
  protected void h() {
    if (this.k)
      return; 
    this.k = true;
    this.f.b();
  }
  
  protected void i() {
    this.f.c();
  }
  
  public boolean j() {
    return false;
  }
  
  public void k() {
    if (this.b)
      this.b = false; 
    if (e() != null && CBUtility.c() != a.a(e()))
      e().a(false); 
  }
  
  public void l() {
    this.b = true;
  }
  
  public abstract class a extends RelativeLayout {
    private boolean b = false;
    
    private int c = -1;
    
    private int d = -1;
    
    private int e = -1;
    
    private int f = -1;
    
    private f g = null;
    
    public a(f this$0, Context param1Context) {
      super(param1Context);
      f.a(this$0, this);
      f.a(this$0, false);
      setFocusableInTouchMode(true);
      requestFocus();
    }
    
    private boolean b(int param1Int1, int param1Int2) {
      boolean bool2 = true;
      boolean bool1 = true;
      if (this.b)
        return false; 
      f f1 = CBUtility.c();
      if (this.c != param1Int1 || this.d != param1Int2 || this.g != f1) {
        this.b = true;
        try {
          if (this.a.i && f1.b()) {
            this.a.g = f1;
          } else if (this.a.j && f1.c()) {
            this.a.g = f1;
          } 
          a(param1Int1, param1Int2);
          post(new Runnable(this) {
                public void run() {
                  this.a.requestLayout();
                }
              });
          this.c = param1Int1;
          this.d = param1Int2;
          this.g = f1;
          bool1 = bool2;
        } catch (Exception exception) {
          CBLogging.b("CBViewProtocol", "Exception raised while layouting Subviews", exception);
          bool1 = false;
        } 
        this.b = false;
        return bool1;
      } 
      return bool1;
    }
    
    public final void a() {
      a(false);
    }
    
    protected abstract void a(int param1Int1, int param1Int2);
    
    public final void a(View param1View) {
      int i = 200;
      if (200 == getId())
        i = 201; 
      for (View view = findViewById(i); view != null; view = findViewById(++i));
      param1View.setId(i);
      param1View.setSaveEnabled(false);
    }
    
    public final void a(boolean param1Boolean) {
      if (param1Boolean)
        this.g = null; 
      a((Activity)getContext());
    }
    
    public boolean a(Activity param1Activity) {
      // Byte code:
      //   0: aload_0
      //   1: getfield e : I
      //   4: iconst_m1
      //   5: if_icmpeq -> 16
      //   8: aload_0
      //   9: getfield f : I
      //   12: iconst_m1
      //   13: if_icmpne -> 138
      //   16: aload_0
      //   17: invokevirtual getWidth : ()I
      //   20: istore_3
      //   21: aload_0
      //   22: invokevirtual getHeight : ()I
      //   25: istore #4
      //   27: iload_3
      //   28: ifeq -> 39
      //   31: iload #4
      //   33: istore_2
      //   34: iload #4
      //   36: ifne -> 80
      //   39: aload_1
      //   40: invokevirtual getWindow : ()Landroid/view/Window;
      //   43: ldc 16908290
      //   45: invokevirtual findViewById : (I)Landroid/view/View;
      //   48: astore #6
      //   50: aload #6
      //   52: astore #5
      //   54: aload #6
      //   56: ifnonnull -> 68
      //   59: aload_1
      //   60: invokevirtual getWindow : ()Landroid/view/Window;
      //   63: invokevirtual getDecorView : ()Landroid/view/View;
      //   66: astore #5
      //   68: aload #5
      //   70: invokevirtual getWidth : ()I
      //   73: istore_3
      //   74: aload #5
      //   76: invokevirtual getHeight : ()I
      //   79: istore_2
      //   80: iload_3
      //   81: ifeq -> 91
      //   84: iload_2
      //   85: istore #4
      //   87: iload_2
      //   88: ifne -> 127
      //   91: new android/util/DisplayMetrics
      //   94: dup
      //   95: invokespecial <init> : ()V
      //   98: astore #5
      //   100: aload_1
      //   101: invokevirtual getWindowManager : ()Landroid/view/WindowManager;
      //   104: invokeinterface getDefaultDisplay : ()Landroid/view/Display;
      //   109: aload #5
      //   111: invokevirtual getMetrics : (Landroid/util/DisplayMetrics;)V
      //   114: aload #5
      //   116: getfield widthPixels : I
      //   119: istore_3
      //   120: aload #5
      //   122: getfield heightPixels : I
      //   125: istore #4
      //   127: aload_0
      //   128: iload_3
      //   129: putfield e : I
      //   132: aload_0
      //   133: iload #4
      //   135: putfield f : I
      //   138: aload_0
      //   139: aload_0
      //   140: getfield e : I
      //   143: aload_0
      //   144: getfield f : I
      //   147: invokespecial b : (II)Z
      //   150: ireturn
      //   151: astore #5
      //   153: iconst_0
      //   154: istore_2
      //   155: iconst_0
      //   156: istore_3
      //   157: goto -> 80
      // Exception table:
      //   from	to	target	type
      //   16	27	151	java/lang/Exception
      //   39	50	151	java/lang/Exception
      //   59	68	151	java/lang/Exception
      //   68	80	151	java/lang/Exception
    }
    
    public void b() {}
    
    protected boolean c() {
      return f.a(getContext());
    }
    
    public void onDetachedFromWindow() {
      super.onDetachedFromWindow();
      for (int i = 0; i < this.a.h.size(); i++)
        f.a.removeCallbacks(this.a.h.get(Integer.valueOf(i))); 
      this.a.h.clear();
    }
    
    protected void onSizeChanged(int param1Int1, int param1Int2, int param1Int3, int param1Int4) {
      super.onSizeChanged(param1Int1, param1Int2, param1Int3, param1Int4);
      this.e = param1Int1;
      this.f = param1Int2;
      if (this.c != -1 && this.d != -1)
        a(); 
    }
  }
  
  class null implements Runnable {
    null(f this$0) {}
    
    public void run() {
      this.a.requestLayout();
    }
  }
  
  public static interface b {
    boolean a();
  }
}


/* Location:              C:\soft\dex2jar-2.0\Smash Cricket-dex2jar.jar!\com\chartboost\sdk\f.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */