package com.amazon.inapp.purchasing;

class SandboxException extends RuntimeException {
  private static final long serialVersionUID = 1L;
  
  public SandboxException() {}
  
  public SandboxException(String paramString) {
    super(paramString);
  }
  
  public SandboxException(String paramString, Throwable paramThrowable) {
    super(paramString, paramThrowable);
  }
  
  public SandboxException(Throwable paramThrowable) {
    super(paramThrowable);
  }
}


/* Location:              C:\soft\dex2jar-2.0\Smash Cricket-dex2jar.jar!\com\amazon\inapp\purchasing\SandboxException.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */