package com.amazon.inapp.purchasing;

final class ContentDownloadResponse {
  private final ContentDownloadRequestStatus _contentDownloadRequestStatus;
  
  private final int _percentComplete;
  
  private final String _requestId;
  
  ContentDownloadResponse(String paramString, int paramInt, ContentDownloadRequestStatus paramContentDownloadRequestStatus) {
    Validator.validateNotNull(paramString, "requestId");
    Validator.validateNotNull(paramContentDownloadRequestStatus, "contentDownloadRequestStatus");
    this._requestId = paramString;
    this._percentComplete = paramInt;
    this._contentDownloadRequestStatus = paramContentDownloadRequestStatus;
  }
  
  public ContentDownloadRequestStatus getContentDownloadRequestStatus() {
    return this._contentDownloadRequestStatus;
  }
  
  public int getPercentComplete() {
    return this._percentComplete;
  }
  
  public String getRequestId() {
    return this._requestId;
  }
  
  public enum ContentDownloadRequestStatus {
    COMPLETE, FAILED, INVALID_LOCATION, INVALID_SKU, IN_PROGRESS;
    
    static {
      $VALUES = new ContentDownloadRequestStatus[] { IN_PROGRESS, COMPLETE, FAILED, INVALID_LOCATION, INVALID_SKU };
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Smash Cricket-dex2jar.jar!\com\amazon\inapp\purchasing\ContentDownloadResponse.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */