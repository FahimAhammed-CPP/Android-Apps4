package com.amazon.inapp.purchasing;

class PurchaseRequest extends Request {
  private final String _sku;
  
  PurchaseRequest(String paramString) {
    Validator.validateNotNull(paramString, "sku");
    this._sku = paramString;
  }
  
  Runnable getRunnable() {
    return new Runnable() {
        public void run() {
          ImplementationFactory.getRequestHandler().sendPurchaseRequest(PurchaseRequest.this._sku, PurchaseRequest.this.getRequestId());
        }
      };
  }
}


/* Location:              C:\soft\dex2jar-2.0\Smash Cricket-dex2jar.jar!\com\amazon\inapp\purchasing\PurchaseRequest.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */