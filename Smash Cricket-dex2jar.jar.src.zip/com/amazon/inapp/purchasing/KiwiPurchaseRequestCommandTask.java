package com.amazon.inapp.purchasing;

import android.app.Activity;
import android.content.Intent;
import android.os.RemoteException;
import com.amazon.android.framework.context.ContextManager;
import com.amazon.android.framework.exception.KiwiException;
import com.amazon.android.framework.resource.Resource;
import com.amazon.android.framework.task.Task;
import com.amazon.android.framework.task.TaskManager;
import com.amazon.android.framework.task.pipeline.TaskPipelineId;
import com.amazon.venezia.command.SuccessResult;
import java.util.Map;

final class KiwiPurchaseRequestCommandTask extends KiwiBaseCommandTask {
  private static final String COMMAND_NAME = "purchase_item";
  
  private static final String COMMAND_VERSION = "1.0";
  
  private static final String TAG = "KiwiPurchaseRequestCommandTask";
  
  private final String _sku;
  
  @Resource
  private ContextManager contextMgr;
  
  @Resource
  private TaskManager taskManager;
  
  KiwiPurchaseRequestCommandTask(String paramString1, String paramString2) {
    super("purchase_item", "1.0", paramString2);
    this._sku = paramString1;
    addCommandData("sku", this._sku);
  }
  
  protected void onSuccess(SuccessResult paramSuccessResult) throws RemoteException, KiwiException {
    if (Logger.isTraceOn())
      Logger.trace("KiwiPurchaseRequestCommandTask", "onSuccess"); 
    Map map = paramSuccessResult.getData();
    if (Logger.isTraceOn())
      Logger.trace("KiwiPurchaseRequestCommandTask", "data: " + map); 
    if (map.containsKey("purchaseItemIntent")) {
      if (Logger.isTraceOn())
        Logger.trace("KiwiPurchaseRequestCommandTask", "found intent"); 
      final Intent intent = (Intent)map.remove("purchaseItemIntent");
      this.taskManager.enqueueAtFront(TaskPipelineId.FOREGROUND, new Task() {
            public void execute() {
              try {
                Activity activity2 = KiwiPurchaseRequestCommandTask.this.contextMgr.getVisible();
                Activity activity1 = activity2;
                if (activity2 == null)
                  activity1 = KiwiPurchaseRequestCommandTask.this.contextMgr.getRoot(); 
                if (Logger.isTraceOn())
                  Logger.trace("KiwiPurchaseRequestCommandTask", "About to fire intent with activity " + activity1); 
                activity1.startActivity(intent);
              } catch (Exception exception) {}
            }
          });
      return;
    } 
    if (Logger.isTraceOn()) {
      Logger.trace("KiwiPurchaseRequestCommandTask", "did not find intent");
      return;
    } 
  }
  
  protected void sendFailedResponse() {
    postRunnableToMainLooper(new Runnable() {
          public void run() {
            PurchasingObserver purchasingObserver = PurchasingManager.getPurchasingObserver();
            PurchaseResponse purchaseResponse = new PurchaseResponse(KiwiPurchaseRequestCommandTask.this.getRequestId(), null, null, PurchaseResponse.PurchaseRequestStatus.FAILED);
            if (purchasingObserver != null) {
              if (Logger.isTraceOn())
                Logger.trace("KiwiPurchaseRequestCommandTask", "Invoking onPurchaseResponse with " + purchaseResponse); 
              purchasingObserver.onPurchaseResponse(purchaseResponse);
            } 
          }
        });
  }
}


/* Location:              C:\soft\dex2jar-2.0\Smash Cricket-dex2jar.jar!\com\amazon\inapp\purchasing\KiwiPurchaseRequestCommandTask.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */