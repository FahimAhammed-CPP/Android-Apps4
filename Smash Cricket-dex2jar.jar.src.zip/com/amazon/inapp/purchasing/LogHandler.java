package com.amazon.inapp.purchasing;

interface LogHandler {
  void error(String paramString1, String paramString2);
  
  boolean isErrorOn();
  
  boolean isTestOn();
  
  boolean isTraceOn();
  
  void test(String paramString1, String paramString2);
  
  void trace(String paramString1, String paramString2);
}


/* Location:              C:\soft\dex2jar-2.0\Smash Cricket-dex2jar.jar!\com\amazon\inapp\purchasing\LogHandler.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */