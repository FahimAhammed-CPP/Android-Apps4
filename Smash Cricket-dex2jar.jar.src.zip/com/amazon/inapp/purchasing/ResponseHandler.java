package com.amazon.inapp.purchasing;

import android.content.Context;
import android.content.Intent;

interface ResponseHandler {
  void handleResponse(Context paramContext, Intent paramIntent);
}


/* Location:              C:\soft\dex2jar-2.0\Smash Cricket-dex2jar.jar!\com\amazon\inapp\purchasing\ResponseHandler.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */