package com.amazon.inapp.purchasing;

import android.os.RemoteException;
import com.amazon.android.Kiwi;
import com.amazon.android.framework.exception.KiwiException;
import com.amazon.android.framework.prompt.Prompt;
import com.amazon.android.framework.prompt.PromptContent;
import com.amazon.android.framework.prompt.PromptManager;
import com.amazon.android.framework.task.command.AbstractCommandTask;
import com.amazon.android.licensing.LicenseFailurePromptContentMapper;
import com.amazon.venezia.command.FailureResult;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.HashMap;
import java.util.Map;
import org.json.JSONException;
import org.json.JSONObject;

abstract class KiwiBaseCommandTask extends AbstractCommandTask {
  private static final String DATE_FORMAT = "MM/dd/yyyy HH:mm:ss";
  
  protected static final String FALSE = "false";
  
  protected static final String KEY_CURSOR = "cursor";
  
  protected static final String KEY_DESCRIPTION = "description";
  
  protected static final String KEY_ERROR_MESSAGE = "errorMessage";
  
  protected static final String KEY_HAS_CONTENT = "hasContent";
  
  protected static final String KEY_HAS_MORE = "hasMore";
  
  protected static final String KEY_ICON_URL = "iconUrl";
  
  protected static final String KEY_ITEM_TYPE = "itemType";
  
  protected static final String KEY_ORDER_STATUS = "orderStatus";
  
  protected static final String KEY_PERIOD_DATE_END = "endDate";
  
  protected static final String KEY_PERIOD_DATE_START = "startDate";
  
  protected static final String KEY_PRICE = "price";
  
  protected static final String KEY_PURCHASE_ITEM_INTENT = "purchaseItemIntent";
  
  protected static final String KEY_RECEIPT = "receipt";
  
  protected static final String KEY_RECEIPTS = "receipts";
  
  protected static final String KEY_REQUEST_ID = "requestId";
  
  protected static final String KEY_REVOCATIONS = "revocations";
  
  protected static final String KEY_SDK_VERSION = "sdkVersion";
  
  protected static final String KEY_SIGNATURE = "signature";
  
  protected static final String KEY_SKU = "sku";
  
  protected static final String KEY_SKUS = "skus";
  
  protected static final String KEY_TITLE = "title";
  
  protected static final String KEY_TOKEN = "token";
  
  protected static final String KEY_USER_ID = "userId";
  
  protected static final String SDK_VERSION = "1.0";
  
  private static final String TAG = "KiwiBaseCommandTask";
  
  protected static final String TRUE = "true";
  
  private final Map<String, Object> _commandData;
  
  private final String _commandName;
  
  private final String _commandVersion;
  
  private final String _requestId;
  
  private LicenseFailurePromptContentMapper mapper = new LicenseFailurePromptContentMapper();
  
  KiwiBaseCommandTask(String paramString1, String paramString2, String paramString3) {
    this._requestId = paramString3;
    this._commandName = paramString1;
    this._commandVersion = paramString2;
    this._commandData = new HashMap<String, Object>();
    this._commandData.put("requestId", this._requestId);
    this._commandData.put("sdkVersion", "1.0");
  }
  
  protected void addCommandData(String paramString, Object paramObject) {
    this._commandData.put(paramString, paramObject);
  }
  
  protected Map<String, Object> getCommandData() {
    return this._commandData;
  }
  
  protected String getCommandName() {
    return this._commandName;
  }
  
  protected String getCommandVersion() {
    return this._commandVersion;
  }
  
  protected Date getDateFromString(String paramString) throws JSONException {
    SimpleDateFormat simpleDateFormat = new SimpleDateFormat("MM/dd/yyyy HH:mm:ss");
    try {
      Date date = simpleDateFormat.parse(paramString);
      long l = date.getTime();
      if (0L == l)
        date = null; 
      return date;
    } catch (ParseException parseException) {
      throw new JSONException(parseException.getMessage());
    } 
  }
  
  protected Receipt getReceiptFromReceiptJson(JSONObject paramJSONObject) throws JSONException {
    String str1 = paramJSONObject.getString("sku");
    Item.ItemType itemType = Item.ItemType.valueOf(paramJSONObject.getString("itemType"));
    String str2 = paramJSONObject.getString("token");
    if (Item.ItemType.SUBSCRIPTION == itemType) {
      SubscriptionPeriod subscriptionPeriod = getSubscriptionPeriodFromReceiptJson(paramJSONObject);
      return new Receipt(str1, itemType, false, subscriptionPeriod, str2);
    } 
    paramJSONObject = null;
    return new Receipt(str1, itemType, false, (SubscriptionPeriod)paramJSONObject, str2);
  }
  
  protected String getRequestId() {
    return this._requestId;
  }
  
  protected SubscriptionPeriod getSubscriptionPeriodFromReceiptJson(JSONObject paramJSONObject) throws JSONException {
    String str2 = null;
    if (!paramJSONObject.has("startDate"))
      return null; 
    Date date2 = getDateFromString(paramJSONObject.getString("startDate"));
    String str1 = paramJSONObject.optString("endDate");
    if (isNullOrEmpty(str1)) {
      str1 = str2;
      return new SubscriptionPeriod(date2, (Date)str1);
    } 
    Date date1 = getDateFromString(str1);
    return new SubscriptionPeriod(date2, date1);
  }
  
  protected boolean isExecutionNeeded() {
    return true;
  }
  
  protected boolean isNullOrEmpty(String paramString) {
    return (paramString == null || paramString.trim().length() == 0);
  }
  
  protected void onException(KiwiException paramKiwiException) {
    if (Logger.isTraceOn())
      Logger.trace("KiwiBaseCommandTask", "onException, result: " + paramKiwiException.getMessage()); 
    PromptManager promptManager = Kiwi.getPromptManager();
    PromptContent promptContent = this.mapper.map(paramKiwiException);
    if (promptContent != null)
      promptManager.present((Prompt)new FailurePrompt(promptContent)); 
    sendFailedResponse();
  }
  
  protected void onFailure(FailureResult paramFailureResult) throws RemoteException, KiwiException {
    if (paramFailureResult == null) {
      if (Logger.isTraceOn())
        Logger.trace("KiwiBaseCommandTask", "onFailure: null result"); 
      return;
    } 
    if (Logger.isTraceOn())
      Logger.trace("KiwiBaseCommandTask", "onFailure: result message: " + paramFailureResult.getDisplayableMessage()); 
    FailurePrompt failurePrompt = new FailurePrompt(new PromptContent(paramFailureResult.getDisplayableName(), paramFailureResult.getDisplayableMessage(), paramFailureResult.getButtonLabel(), paramFailureResult.show()));
    Kiwi.getPromptManager().present((Prompt)failurePrompt);
    sendFailedResponse();
  }
  
  protected void postRunnableToMainLooper(Runnable paramRunnable) {
    HandlerManager.getMainHandlerAdapter().post(paramRunnable);
  }
  
  protected abstract void sendFailedResponse();
  
  protected boolean verifyReceipt(String paramString, Receipt paramReceipt, JSONObject paramJSONObject) {
    if (Logger.isTraceOn())
      Logger.trace("KiwiBaseCommandTask", "Validating receipt: " + paramReceipt); 
    String str = paramJSONObject.optString("signature");
    boolean bool = false;
    if (!isNullOrEmpty(str)) {
      bool = verifySignature(paramString, paramReceipt.getPurchaseToken(), str);
      if (Logger.isTraceOn()) {
        StringBuilder stringBuilder = (new StringBuilder()).append("signature verification ");
        if (bool) {
          paramString = "succeeded";
        } else {
          paramString = "failed";
        } 
        Logger.error("KiwiBaseCommandTask", stringBuilder.append(paramString).append(" for request ID ").append(getRequestId()).toString());
        return bool;
      } 
    } else {
      if (Logger.isTraceOn()) {
        Logger.error("KiwiBaseCommandTask", "a signature was not found in the receipt for request ID " + getRequestId());
        return false;
      } 
      return bool;
    } 
    return bool;
  }
  
  protected boolean verifySignature(String paramString1, String paramString2, String paramString3) {
    return Kiwi.isSignedByKiwi(paramString1 + "-" + paramString2, paramString3);
  }
}


/* Location:              C:\soft\dex2jar-2.0\Smash Cricket-dex2jar.jar!\com\amazon\inapp\purchasing\KiwiBaseCommandTask.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */