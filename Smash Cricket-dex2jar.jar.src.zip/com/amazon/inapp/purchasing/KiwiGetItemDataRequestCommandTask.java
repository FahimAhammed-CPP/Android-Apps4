package com.amazon.inapp.purchasing;

import android.os.RemoteException;
import com.amazon.android.framework.exception.KiwiException;
import com.amazon.venezia.command.SuccessResult;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;
import java.util.Set;
import org.json.JSONException;
import org.json.JSONObject;

final class KiwiGetItemDataRequestCommandTask extends KiwiBaseCommandTask {
  private static final String COMMAND_NAME = "getItem_data";
  
  private static final String COMMAND_VERSION = "1.0";
  
  private static final String TAG = "KiwiGetItemDataRequestCommandTask";
  
  private final Set<String> _skus;
  
  KiwiGetItemDataRequestCommandTask(Set<String> paramSet, String paramString) {
    super("getItem_data", "1.0", paramString);
    this._skus = paramSet;
    addCommandData("skus", this._skus);
  }
  
  private ItemDataResponse getFailedResponse() {
    return new ItemDataResponse(getRequestId(), null, ItemDataResponse.ItemDataRequestStatus.FAILED, null);
  }
  
  private void notifyObserver(final ItemDataResponse itemDataResponse) {
    postRunnableToMainLooper(new Runnable() {
          public void run() {
            PurchasingObserver purchasingObserver = PurchasingManager.getPurchasingObserver();
            if (purchasingObserver != null) {
              if (Logger.isTraceOn())
                Logger.trace("KiwiGetItemDataRequestCommandTask", "Invoking onItemDataResponse with " + itemDataResponse); 
              purchasingObserver.onItemDataResponse(itemDataResponse);
            } 
          }
        });
  }
  
  protected void onSuccess(SuccessResult paramSuccessResult) throws RemoteException, KiwiException {
    HashSet<String> hashSet;
    if (Logger.isTraceOn())
      Logger.trace("KiwiGetItemDataRequestCommandTask", "onSuccess"); 
    Map map = paramSuccessResult.getData();
    if (Logger.isTraceOn())
      Logger.trace("KiwiGetItemDataRequestCommandTask", "data: " + map); 
    String str = (String)map.get("errorMessage");
    if (Logger.isTraceOn())
      Logger.trace("KiwiGetItemDataRequestCommandTask", "onSuccess: errorMessage: \"" + str + "\""); 
    if (isNullOrEmpty(str)) {
      ItemDataResponse.ItemDataRequestStatus itemDataRequestStatus;
      hashSet = new HashSet();
      HashMap<Object, Object> hashMap = new HashMap<Object, Object>();
      for (String str1 : this._skus) {
        if (!map.containsKey(str1)) {
          hashSet.add(str1);
          continue;
        } 
        try {
          JSONObject jSONObject = new JSONObject((String)map.get(str1));
          String str2 = jSONObject.getString("title");
          String str3 = jSONObject.getString("description");
          String str4 = jSONObject.getString("iconUrl");
          hashMap.put(str1, new Item(str1, jSONObject.optString("price"), Item.ItemType.valueOf(jSONObject.getString("itemType")), str2, str3, str4));
        } catch (JSONException jSONException) {
          hashSet.add(str1);
          if (Logger.isErrorOn())
            Logger.error("KiwiGetItemDataRequestCommandTask", "Error parsing JSON for SKU " + str1 + ": " + jSONException.getMessage()); 
        } 
      } 
      if (hashSet.isEmpty()) {
        itemDataRequestStatus = ItemDataResponse.ItemDataRequestStatus.SUCCESSFUL;
      } else {
        itemDataRequestStatus = ItemDataResponse.ItemDataRequestStatus.SUCCESSFUL_WITH_UNAVAILABLE_SKUS;
      } 
      notifyObserver(new ItemDataResponse(getRequestId(), hashSet, itemDataRequestStatus, (Map)hashMap));
      return;
    } 
    if (Logger.isTraceOn())
      Logger.trace("KiwiGetItemDataRequestCommandTask", "found error message: " + hashSet); 
    sendFailedResponse();
  }
  
  protected void sendFailedResponse() {
    notifyObserver(getFailedResponse());
  }
}


/* Location:              C:\soft\dex2jar-2.0\Smash Cricket-dex2jar.jar!\com\amazon\inapp\purchasing\KiwiGetItemDataRequestCommandTask.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */