package com.amazon.inapp.purchasing;

import java.util.HashMap;
import java.util.Map;

final class SandboxImplementationRegistry implements ImplementationRegistry {
  private static final Map<Class, Class> classMap = (Map)new HashMap<Class<?>, Class<?>>();
  
  static {
    classMap.put(RequestHandler.class, SandboxRequestHandler.class);
    classMap.put(ResponseHandler.class, SandboxResponseHandler.class);
    classMap.put(LogHandler.class, SandboxLogHandler.class);
  }
  
  public <T> Class<T> getImplementation(Class<T> paramClass) {
    return classMap.get(paramClass);
  }
}


/* Location:              C:\soft\dex2jar-2.0\Smash Cricket-dex2jar.jar!\com\amazon\inapp\purchasing\SandboxImplementationRegistry.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */