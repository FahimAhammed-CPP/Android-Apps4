package com.amazon.inapp.purchasing;

import android.content.Context;
import android.os.Handler;
import android.util.Log;
import java.util.HashSet;
import java.util.Set;

public final class PurchasingManager {
  public static final String BUILD_ID = "1.0.3";
  
  private static final HandlerAdapter HANDLER = HandlerManager.getHandlerAdapter("PurchasingManagerHandlerThread");
  
  static final String HANDLER_THREAD_NAME = "PurchasingManagerHandlerThread";
  
  public static final int ITEM_DATA_REQUEST_MAX_SKUS = 100;
  
  private static final String TAG = "PurchasingManager";
  
  private static PurchasingObserver registeredPurchasingObserver;
  
  static {
    Runnable runnable = new Runnable() {
        public void run() {
          Log.i("PurchasingManager", "Purchasing Framework initialization complete. Build ID 1.0.3");
        }
      };
    HANDLER.post(runnable);
  }
  
  private static void checkObserverRegistered() {
    if (registeredPurchasingObserver == null)
      throw new IllegalStateException("You must register a PurchasingObserver before invoking this operation"); 
  }
  
  static Context getObserverContext() {
    return (registeredPurchasingObserver == null) ? null : registeredPurchasingObserver.getContext();
  }
  
  static PurchasingObserver getPurchasingObserver() {
    return registeredPurchasingObserver;
  }
  
  public static String initiateGetUserIdRequest() {
    checkObserverRegistered();
    return initiateRequest(new GetUserIdRequest());
  }
  
  public static String initiateItemDataRequest(Set<String> paramSet) {
    checkObserverRegistered();
    return initiateRequest(new ItemDataRequest(new HashSet<String>(paramSet)));
  }
  
  public static String initiatePurchaseRequest(String paramString) {
    checkObserverRegistered();
    return initiateRequest(new PurchaseRequest(paramString));
  }
  
  public static String initiatePurchaseUpdatesRequest(Offset paramOffset) {
    checkObserverRegistered();
    return initiateRequest(new PurchaseUpdatesRequest(paramOffset));
  }
  
  private static String initiateRequest(Request paramRequest) {
    HANDLER.post(paramRequest.getRunnable());
    return paramRequest.getRequestId();
  }
  
  public static void registerObserver(final PurchasingObserver purchasingObserver) {
    if (Logger.isTraceOn())
      Logger.trace("PurchasingManager", "PurchasingObserver registered: " + purchasingObserver); 
    if (purchasingObserver == null)
      throw new IllegalArgumentException("Provided PurchasingObserver must not be null"); 
    registeredPurchasingObserver = purchasingObserver;
    Runnable runnable = new Runnable() {
        public void run() {
          Runnable runnable = new Runnable() {
              public void run() {
                purchasingObserver.onSdkAvailable(ImplementationFactory.isSandboxMode());
              }
            };
          (new Handler(PurchasingManager.getObserverContext().getMainLooper())).post(runnable);
        }
      };
    HANDLER.post(runnable);
  }
}


/* Location:              C:\soft\dex2jar-2.0\Smash Cricket-dex2jar.jar!\com\amazon\inapp\purchasing\PurchasingManager.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */