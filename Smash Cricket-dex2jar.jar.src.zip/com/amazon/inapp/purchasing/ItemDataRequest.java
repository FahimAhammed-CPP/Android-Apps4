package com.amazon.inapp.purchasing;

import java.util.Collection;
import java.util.Iterator;
import java.util.Set;

final class ItemDataRequest extends Request {
  private final Set<String> _skus;
  
  ItemDataRequest(Set<String> paramSet) {
    Validator.validateNotNull(paramSet, "skus");
    Validator.validateNotEmpty((Collection)paramSet, "skus");
    Iterator<String> iterator = paramSet.iterator();
    while (iterator.hasNext()) {
      if (((String)iterator.next()).trim().length() == 0)
        throw new IllegalArgumentException("Empty SKU values are not allowed"); 
    } 
    if (paramSet.size() > 100)
      throw new IllegalArgumentException(paramSet.size() + " SKUs were provided, but no more than " + 'd' + " SKUs are allowed"); 
    this._skus = paramSet;
  }
  
  Runnable getRunnable() {
    return new Runnable() {
        public void run() {
          ImplementationFactory.getRequestHandler().sendItemDataRequest(ItemDataRequest.this._skus, ItemDataRequest.this.getRequestId());
        }
      };
  }
}


/* Location:              C:\soft\dex2jar-2.0\Smash Cricket-dex2jar.jar!\com\amazon\inapp\purchasing\ItemDataRequest.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */