package com.amazon.inapp.purchasing;

final class ContentDownloadRequest extends Request {
  private final String _location;
  
  private final String _sku;
  
  ContentDownloadRequest(String paramString1, String paramString2) {
    Validator.validateNotNull(paramString1, "sku");
    Validator.validateNotNull(paramString2, "location");
    this._sku = paramString1;
    this._location = paramString2;
  }
  
  Runnable getRunnable() {
    return new Runnable() {
        public void run() {
          ImplementationFactory.getRequestHandler().sendContentDownloadRequest(ContentDownloadRequest.this._sku, ContentDownloadRequest.this._location, ContentDownloadRequest.this.getRequestId());
        }
      };
  }
}


/* Location:              C:\soft\dex2jar-2.0\Smash Cricket-dex2jar.jar!\com\amazon\inapp\purchasing\ContentDownloadRequest.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */