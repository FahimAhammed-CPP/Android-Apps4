package com.amazon.inapp.purchasing;

public final class GetUserIdResponse {
  private static final String TO_STRING_FORMAT = "(%s, requestId: \"%s\", getUserIdRequestStatus: \"%s\", userId: \"%s\")";
  
  private final GetUserIdRequestStatus _getUserIdRequestStatus;
  
  private final String _requestId;
  
  private final String _userId;
  
  GetUserIdResponse(String paramString1, GetUserIdRequestStatus paramGetUserIdRequestStatus, String paramString2) {
    Validator.validateNotNull(paramString1, "requestId");
    Validator.validateNotNull(paramGetUserIdRequestStatus, "getUserIdRequestStatus");
    if (GetUserIdRequestStatus.SUCCESSFUL == paramGetUserIdRequestStatus)
      Validator.validateNotNull(paramString2, "userId"); 
    this._requestId = paramString1;
    this._userId = paramString2;
    this._getUserIdRequestStatus = paramGetUserIdRequestStatus;
  }
  
  public String getRequestId() {
    return this._requestId;
  }
  
  public String getUserId() {
    return this._userId;
  }
  
  public GetUserIdRequestStatus getUserIdRequestStatus() {
    return this._getUserIdRequestStatus;
  }
  
  public String toString() {
    return String.format("(%s, requestId: \"%s\", getUserIdRequestStatus: \"%s\", userId: \"%s\")", new Object[] { super.toString(), this._requestId, this._getUserIdRequestStatus, this._userId });
  }
  
  public enum GetUserIdRequestStatus {
    FAILED, SUCCESSFUL;
    
    static {
      $VALUES = new GetUserIdRequestStatus[] { SUCCESSFUL, FAILED };
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Smash Cricket-dex2jar.jar!\com\amazon\inapp\purchasing\GetUserIdResponse.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */