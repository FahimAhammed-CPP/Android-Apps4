package com.amazon.inapp.purchasing;

final class ImplementationFactory {
  private static volatile ImplementationRegistry IMPLEMENTATION_REGISTRY;
  
  private static volatile boolean IS_SANDBOX_MODE;
  
  private static volatile boolean IS_SANDBOX_MODE_CHECKED;
  
  private static volatile LogHandler LOG_HANDLER_INSTANCE;
  
  private static volatile RequestHandler REQUEST_HANDLER_INSTANCE;
  
  private static volatile ResponseHandler RESPONSE_HANDLER_INSTANCE;
  
  private static ImplementationRegistry getImplementationRegistry() {
    // Byte code:
    //   0: getstatic com/amazon/inapp/purchasing/ImplementationFactory.IMPLEMENTATION_REGISTRY : Lcom/amazon/inapp/purchasing/ImplementationRegistry;
    //   3: ifnonnull -> 34
    //   6: ldc com/amazon/inapp/purchasing/ImplementationFactory
    //   8: monitorenter
    //   9: getstatic com/amazon/inapp/purchasing/ImplementationFactory.IMPLEMENTATION_REGISTRY : Lcom/amazon/inapp/purchasing/ImplementationRegistry;
    //   12: ifnonnull -> 31
    //   15: invokestatic isSandboxMode : ()Z
    //   18: ifeq -> 38
    //   21: new com/amazon/inapp/purchasing/SandboxImplementationRegistry
    //   24: dup
    //   25: invokespecial <init> : ()V
    //   28: putstatic com/amazon/inapp/purchasing/ImplementationFactory.IMPLEMENTATION_REGISTRY : Lcom/amazon/inapp/purchasing/ImplementationRegistry;
    //   31: ldc com/amazon/inapp/purchasing/ImplementationFactory
    //   33: monitorexit
    //   34: getstatic com/amazon/inapp/purchasing/ImplementationFactory.IMPLEMENTATION_REGISTRY : Lcom/amazon/inapp/purchasing/ImplementationRegistry;
    //   37: areturn
    //   38: new com/amazon/inapp/purchasing/KiwiImplementationRegistry
    //   41: dup
    //   42: invokespecial <init> : ()V
    //   45: putstatic com/amazon/inapp/purchasing/ImplementationFactory.IMPLEMENTATION_REGISTRY : Lcom/amazon/inapp/purchasing/ImplementationRegistry;
    //   48: goto -> 31
    //   51: astore_0
    //   52: ldc com/amazon/inapp/purchasing/ImplementationFactory
    //   54: monitorexit
    //   55: aload_0
    //   56: athrow
    // Exception table:
    //   from	to	target	type
    //   9	31	51	finally
    //   31	34	51	finally
    //   38	48	51	finally
    //   52	55	51	finally
  }
  
  private static <T> T getInstance(Class<T> paramClass, T paramT) {
    // Byte code:
    //   0: aload_1
    //   1: ifnonnull -> 43
    //   4: ldc com/amazon/inapp/purchasing/ImplementationFactory
    //   6: monitorenter
    //   7: aload_1
    //   8: astore_2
    //   9: aload_1
    //   10: ifnonnull -> 26
    //   13: invokestatic getImplementationRegistry : ()Lcom/amazon/inapp/purchasing/ImplementationRegistry;
    //   16: aload_0
    //   17: invokeinterface getImplementation : (Ljava/lang/Class;)Ljava/lang/Class;
    //   22: invokevirtual newInstance : ()Ljava/lang/Object;
    //   25: astore_2
    //   26: ldc com/amazon/inapp/purchasing/ImplementationFactory
    //   28: monitorexit
    //   29: aload_2
    //   30: areturn
    //   31: astore_0
    //   32: ldc com/amazon/inapp/purchasing/ImplementationFactory
    //   34: monitorexit
    //   35: aload_0
    //   36: athrow
    //   37: astore_0
    //   38: aload_1
    //   39: astore_2
    //   40: goto -> 26
    //   43: aload_1
    //   44: areturn
    // Exception table:
    //   from	to	target	type
    //   13	26	37	java/lang/Exception
    //   13	26	31	finally
    //   26	29	31	finally
    //   32	35	31	finally
  }
  
  static LogHandler getLogHandler() {
    return (LOG_HANDLER_INSTANCE != null) ? LOG_HANDLER_INSTANCE : getInstance(LogHandler.class, LOG_HANDLER_INSTANCE);
  }
  
  static RequestHandler getRequestHandler() {
    return (REQUEST_HANDLER_INSTANCE != null) ? REQUEST_HANDLER_INSTANCE : getInstance(RequestHandler.class, REQUEST_HANDLER_INSTANCE);
  }
  
  static ResponseHandler getResponseHandler() {
    return (RESPONSE_HANDLER_INSTANCE != null) ? RESPONSE_HANDLER_INSTANCE : getInstance(ResponseHandler.class, RESPONSE_HANDLER_INSTANCE);
  }
  
  static boolean isSandboxMode() {
    // Byte code:
    //   0: getstatic com/amazon/inapp/purchasing/ImplementationFactory.IS_SANDBOX_MODE_CHECKED : Z
    //   3: ifeq -> 10
    //   6: getstatic com/amazon/inapp/purchasing/ImplementationFactory.IS_SANDBOX_MODE : Z
    //   9: ireturn
    //   10: ldc com/amazon/inapp/purchasing/ImplementationFactory
    //   12: monitorenter
    //   13: getstatic com/amazon/inapp/purchasing/ImplementationFactory.IS_SANDBOX_MODE_CHECKED : Z
    //   16: ifeq -> 34
    //   19: getstatic com/amazon/inapp/purchasing/ImplementationFactory.IS_SANDBOX_MODE : Z
    //   22: istore_0
    //   23: ldc com/amazon/inapp/purchasing/ImplementationFactory
    //   25: monitorexit
    //   26: iload_0
    //   27: ireturn
    //   28: astore_1
    //   29: ldc com/amazon/inapp/purchasing/ImplementationFactory
    //   31: monitorexit
    //   32: aload_1
    //   33: athrow
    //   34: ldc com/amazon/inapp/purchasing/ImplementationFactory
    //   36: invokevirtual getClassLoader : ()Ljava/lang/ClassLoader;
    //   39: ldc 'com.amazon.android.Kiwi'
    //   41: invokevirtual loadClass : (Ljava/lang/String;)Ljava/lang/Class;
    //   44: pop
    //   45: iconst_0
    //   46: putstatic com/amazon/inapp/purchasing/ImplementationFactory.IS_SANDBOX_MODE : Z
    //   49: iconst_1
    //   50: putstatic com/amazon/inapp/purchasing/ImplementationFactory.IS_SANDBOX_MODE_CHECKED : Z
    //   53: ldc com/amazon/inapp/purchasing/ImplementationFactory
    //   55: monitorexit
    //   56: getstatic com/amazon/inapp/purchasing/ImplementationFactory.IS_SANDBOX_MODE : Z
    //   59: ireturn
    //   60: astore_1
    //   61: iconst_1
    //   62: putstatic com/amazon/inapp/purchasing/ImplementationFactory.IS_SANDBOX_MODE : Z
    //   65: goto -> 49
    // Exception table:
    //   from	to	target	type
    //   13	26	28	finally
    //   29	32	28	finally
    //   34	49	60	java/lang/Throwable
    //   34	49	28	finally
    //   49	56	28	finally
    //   61	65	28	finally
  }
}


/* Location:              C:\soft\dex2jar-2.0\Smash Cricket-dex2jar.jar!\com\amazon\inapp\purchasing\ImplementationFactory.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */