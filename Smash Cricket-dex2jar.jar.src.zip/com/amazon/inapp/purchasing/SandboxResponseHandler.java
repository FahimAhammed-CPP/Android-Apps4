package com.amazon.inapp.purchasing;

import android.content.Context;
import android.content.Intent;
import android.util.Log;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.Map;
import java.util.Set;
import org.json.JSONArray;
import org.json.JSONObject;

final class SandboxResponseHandler implements ResponseHandler {
  private static final String TAG = "SandboxResponseHandler";
  
  private final HandlerAdapter _handler = HandlerManager.getMainHandlerAdapter();
  
  private Item getItem(String paramString, JSONObject paramJSONObject) {
    Item.ItemType itemType = Item.ItemType.valueOf(paramJSONObject.optString("itemType"));
    return new Item(paramString, paramJSONObject.optString("price"), itemType, paramJSONObject.optString("title"), paramJSONObject.optString("description"), paramJSONObject.optString("smallIconUrl"));
  }
  
  private ItemDataResponse getItemDataResponse(Intent paramIntent) {
    Exception exception1;
    Exception exception2;
    Exception exception3;
    ItemDataResponse.ItemDataRequestStatus itemDataRequestStatus3;
    ItemDataResponse.ItemDataRequestStatus itemDataRequestStatus4;
    Iterator<String> iterator = null;
    String str = null;
    ItemDataResponse.ItemDataRequestStatus itemDataRequestStatus2 = ItemDataResponse.ItemDataRequestStatus.FAILED;
    try {
      JSONObject jSONObject = new JSONObject(paramIntent.getStringExtra("itemDataOutput"));
      String str1 = jSONObject.optString("requestId");
      try {
        ItemDataResponse.ItemDataRequestStatus itemDataRequestStatus5;
        String str2;
        ItemDataResponse.ItemDataRequestStatus itemDataRequestStatus6 = ItemDataResponse.ItemDataRequestStatus.valueOf(jSONObject.optString("status"));
        itemDataRequestStatus2 = itemDataRequestStatus6;
        if (itemDataRequestStatus6 != ItemDataResponse.ItemDataRequestStatus.FAILED) {
          String str3;
          ItemDataResponse.ItemDataRequestStatus itemDataRequestStatus;
          itemDataRequestStatus2 = itemDataRequestStatus6;
          HashSet<String> hashSet = new HashSet();
          try {
            HashMap<Object, Object> hashMap2 = new HashMap<Object, Object>();
            try {
              JSONArray jSONArray = jSONObject.optJSONArray("unavailableSkus");
              if (jSONArray != null)
                for (int i = 0; i < jSONArray.length(); i++)
                  hashSet.add(jSONArray.getString(i));  
              JSONObject jSONObject1 = jSONObject.optJSONObject("items");
              if (jSONObject1 != null) {
                iterator = jSONObject1.keys();
                while (iterator.hasNext()) {
                  str = iterator.next();
                  hashMap2.put(str, getItem(str, jSONObject1.optJSONObject(str)));
                } 
              } 
            } catch (Exception exception) {
              itemDataRequestStatus4 = itemDataRequestStatus6;
              str2 = str1;
              HashSet<String> hashSet2 = hashSet;
              itemDataRequestStatus5 = itemDataRequestStatus4;
              Log.e("SandboxResponseHandler", "Error parsing item data output", exception);
              HashSet<String> hashSet3 = hashSet2;
              HashMap<Object, Object> hashMap = hashMap2;
              return new ItemDataResponse(str2, hashSet3, itemDataRequestStatus5, (Map)hashMap);
            } 
            HashMap<Object, Object> hashMap1 = hashMap2;
            HashSet<String> hashSet1 = hashSet;
            String str4 = str2;
            itemDataRequestStatus = itemDataRequestStatus5;
            str3 = str4;
          } catch (Exception null) {
            itemDataRequestStatus2 = itemDataRequestStatus;
            str2 = str3;
            itemDataRequestStatus3 = itemDataRequestStatus4;
            itemDataRequestStatus5 = itemDataRequestStatus2;
            HashSet<String> hashSet1 = hashSet;
          } 
        } else {
          Exception exception = null;
          exception3 = exception4;
          exception4 = exception;
          String str3 = str2;
          ItemDataResponse.ItemDataRequestStatus itemDataRequestStatus = itemDataRequestStatus5;
          str1 = str3;
        } 
      } catch (Exception null) {
        Exception exception = null;
        String str2 = str1;
        exception1 = exception3;
        itemDataRequestStatus3 = itemDataRequestStatus4;
        exception3 = exception;
      } 
    } catch (Exception exception4) {
      exception2 = null;
      exception1 = exception3;
      Exception exception = null;
      itemDataRequestStatus3 = itemDataRequestStatus4;
      exception3 = exception2;
      exception2 = exception;
    } 
    Log.e("SandboxResponseHandler", "Error parsing item data output", exception4);
    exception4 = exception3;
    ItemDataResponse.ItemDataRequestStatus itemDataRequestStatus1 = itemDataRequestStatus3;
    return new ItemDataResponse((String)exception2, (Set<String>)exception4, (ItemDataResponse.ItemDataRequestStatus)exception1, (Map<String, Item>)itemDataRequestStatus1);
  }
  
  private PurchaseResponse getPurchaseResponse(Intent paramIntent) {
    Exception exception1;
    String str1;
    Exception exception3;
    JSONObject jSONObject2 = null;
    PurchaseResponse.PurchaseRequestStatus purchaseRequestStatus = PurchaseResponse.PurchaseRequestStatus.FAILED;
    try {
      JSONObject jSONObject = new JSONObject(paramIntent.getStringExtra("purchaseOutput"));
      String str = jSONObject.optString("requestId");
      try {
        String str3;
        str1 = jSONObject.optString("userId");
        try {
          PurchaseResponse.PurchaseRequestStatus purchaseRequestStatus1 = PurchaseResponse.PurchaseRequestStatus.valueOf(jSONObject.optString("purchaseStatus"));
          try {
            Receipt receipt;
            JSONObject jSONObject3 = jSONObject.optJSONObject("receipt");
            jSONObject = jSONObject2;
            PurchaseResponse.PurchaseRequestStatus purchaseRequestStatus2 = purchaseRequestStatus1;
            String str4 = str1;
            str3 = str;
            if (jSONObject3 != null) {
              receipt = getReceipt(jSONObject3);
              str3 = str;
              str4 = str1;
              purchaseRequestStatus2 = purchaseRequestStatus1;
            } 
            return new PurchaseResponse(str3, str4, receipt, purchaseRequestStatus2);
          } catch (Exception exception) {
            str3 = str;
            exception2 = exception;
          } 
        } catch (Exception exception) {
          String str4 = str3;
          exception3 = exception2;
          exception2 = exception;
        } 
      } catch (Exception exception) {
        str1 = null;
        exception1 = exception3;
        exception3 = exception2;
        exception2 = exception;
      } 
    } catch (Exception exception2) {
      str1 = null;
      Exception exception = null;
      exception1 = exception3;
      exception3 = exception;
    } 
    Log.e("SandboxResponseHandler", "Error parsing purchase output", exception2);
    JSONObject jSONObject1 = jSONObject2;
    Exception exception4 = exception1;
    String str2 = str1;
    return new PurchaseResponse((String)exception3, str2, (Receipt)jSONObject1, (PurchaseResponse.PurchaseRequestStatus)exception4);
  }
  
  private PurchaseUpdatesResponse getPurchaseUpdatesResponse(Intent paramIntent) {
    boolean bool;
    String str3;
    Set set1;
    Set set2;
    byte b = 0;
    String str2 = null;
    JSONArray jSONArray = null;
    PurchaseUpdatesResponse.PurchaseUpdatesRequestStatus purchaseUpdatesRequestStatus = PurchaseUpdatesResponse.PurchaseUpdatesRequestStatus.FAILED;
    try {
      JSONObject jSONObject = new JSONObject(paramIntent.getStringExtra("purchaseUpdatesOutput"));
      String str = jSONObject.optString("requestId");
      set1 = (Set)purchaseUpdatesRequestStatus;
      try {
        purchaseUpdatesRequestStatus = PurchaseUpdatesResponse.PurchaseUpdatesRequestStatus.valueOf(jSONObject.optString("status"));
        set1 = (Set)purchaseUpdatesRequestStatus;
        str2 = jSONObject.optString("offset");
        try {
          bool = jSONObject.optBoolean("isMore");
          try {
            str3 = jSONObject.optString("userId");
            try {
              if (purchaseUpdatesRequestStatus == PurchaseUpdatesResponse.PurchaseUpdatesRequestStatus.SUCCESSFUL) {
                HashSet<Receipt> hashSet = new HashSet();
                try {
                  set2 = new HashSet();
                  try {
                    jSONArray = jSONObject.optJSONArray("receipts");
                    if (jSONArray != null)
                      for (int i = 0; i < jSONArray.length(); i++)
                        hashSet.add(getReceipt(jSONArray.optJSONObject(i)));  
                    jSONArray = jSONObject.optJSONArray("revokedSkus");
                    if (jSONArray != null)
                      for (int i = b; i < jSONArray.length(); i++)
                        set2.add(jSONArray.getString(i));  
                    return new PurchaseUpdatesResponse(str, str3, purchaseUpdatesRequestStatus, hashSet, set2, Offset.fromString(str2), bool);
                  } catch (Exception null) {
                    String str4 = str;
                    str = str2;
                    str2 = str4;
                  } 
                } catch (Exception null) {
                  jSONObject = null;
                  String str4 = str;
                  str = str2;
                  str2 = str4;
                  set2 = (Set)jSONObject;
                } 
              } else {
                set2 = null;
                Exception exception1 = exception;
                return new PurchaseUpdatesResponse(str, str3, purchaseUpdatesRequestStatus, (Set<Receipt>)exception1, set2, Offset.fromString(str2), bool);
              } 
            } catch (Exception null) {
              set2 = null;
              String str4 = str;
              str = str2;
              jSONObject = null;
              str2 = str4;
              JSONObject jSONObject1 = jSONObject;
            } 
          } catch (Exception null) {
            set2 = null;
            set1 = null;
            String str4 = str;
            str = str2;
            jSONObject = null;
            str2 = str4;
            str3 = (String)set1;
            JSONObject jSONObject1 = jSONObject;
          } 
        } catch (Exception null) {
          set2 = null;
          bool = false;
          jSONObject = null;
          set1 = null;
          String str4 = str;
          str = str2;
          str2 = str4;
          str3 = (String)jSONObject;
        } 
      } catch (Exception null) {
        set2 = null;
        jSONObject = null;
        bool = false;
        str3 = null;
        str2 = str;
        str = null;
        purchaseUpdatesRequestStatus = (PurchaseUpdatesResponse.PurchaseUpdatesRequestStatus)set1;
        JSONObject jSONObject1 = jSONObject;
      } 
    } catch (Exception exception) {
      set2 = null;
      set1 = null;
      bool = false;
      str3 = null;
      paramIntent = null;
    } 
    Log.e("SandboxResponseHandler", "Error parsing purchase updates output", exception);
    Intent intent2 = paramIntent;
    String str1 = str2;
    Intent intent1 = intent2;
    return new PurchaseUpdatesResponse(str1, str3, purchaseUpdatesRequestStatus, set1, set2, Offset.fromString((String)intent1), bool);
  }
  
  private Receipt getReceipt(JSONObject paramJSONObject) throws ParseException {
    JSONObject jSONObject2 = null;
    String str = paramJSONObject.optString("sku");
    Item.ItemType itemType = Item.ItemType.valueOf(paramJSONObject.optString("itemType"));
    JSONObject jSONObject1 = paramJSONObject.optJSONObject("subscripionPeriod");
    if (itemType == Item.ItemType.SUBSCRIPTION) {
      Date date1;
      SimpleDateFormat simpleDateFormat = new SimpleDateFormat("MM/dd/yyyy HH:mm:ss");
      Date date2 = simpleDateFormat.parse(jSONObject1.optString("startTime"));
      String str1 = jSONObject1.optString("endTime");
      jSONObject1 = jSONObject2;
      if (str1 != null)
        if (str1.length() == 0) {
          jSONObject1 = jSONObject2;
        } else {
          date1 = simpleDateFormat.parse(str1);
        }  
      SubscriptionPeriod subscriptionPeriod = new SubscriptionPeriod(date2, date1);
      return new Receipt(str, itemType, false, subscriptionPeriod, paramJSONObject.optString("token"));
    } 
    jSONObject1 = null;
    return new Receipt(str, itemType, false, (SubscriptionPeriod)jSONObject1, paramJSONObject.optString("token"));
  }
  
  private GetUserIdResponse getUserIdResponse(Intent paramIntent) {
    Exception exception1;
    GetUserIdResponse.GetUserIdRequestStatus getUserIdRequestStatus1;
    GetUserIdResponse.GetUserIdRequestStatus getUserIdRequestStatus3 = null;
    GetUserIdResponse.GetUserIdRequestStatus getUserIdRequestStatus2 = GetUserIdResponse.GetUserIdRequestStatus.FAILED;
    try {
      JSONObject jSONObject = new JSONObject(paramIntent.getStringExtra("userOutput"));
      String str = jSONObject.optString("requestId");
      try {
        GetUserIdResponse.GetUserIdRequestStatus getUserIdRequestStatus = GetUserIdResponse.GetUserIdRequestStatus.valueOf(jSONObject.optString("status"));
        getUserIdRequestStatus2 = getUserIdRequestStatus3;
        try {
          String str1;
          if (getUserIdRequestStatus == GetUserIdResponse.GetUserIdRequestStatus.SUCCESSFUL)
            str1 = jSONObject.optString("userId"); 
          return new GetUserIdResponse(str, getUserIdRequestStatus, str1);
        } catch (Exception exception2) {}
      } catch (Exception exception) {
        exception1 = exception2;
        exception2 = exception;
      } 
    } catch (Exception exception) {
      getUserIdRequestStatus3 = null;
      exception1 = exception2;
      exception2 = exception;
      getUserIdRequestStatus1 = getUserIdRequestStatus3;
    } 
    Log.e("SandboxResponseHandler", "Error parsing userid output", exception2);
    exception2 = null;
    return new GetUserIdResponse((String)getUserIdRequestStatus1, (GetUserIdResponse.GetUserIdRequestStatus)exception1, (String)exception2);
  }
  
  private void handleItemDataResponse(Intent paramIntent) {
    Runnable runnable = new Runnable() {
        public void run() {
          if (Logger.isTraceOn())
            Logger.trace("SandboxResponseHandler", "Running Runnable for itemDataResponse with requestId: " + response.getRequestId()); 
          PurchasingObserver purchasingObserver = PurchasingManager.getPurchasingObserver();
          if (purchasingObserver != null)
            purchasingObserver.onItemDataResponse(response); 
        }
      };
    this._handler.post(runnable);
  }
  
  private void handlePurchaseResponse(Intent paramIntent) {
    Runnable runnable = new Runnable() {
        public void run() {
          if (Logger.isTraceOn())
            Logger.trace("SandboxResponseHandler", "Running Runnable for purchaseResponse with requestId: " + response.getRequestId()); 
          PurchasingObserver purchasingObserver = PurchasingManager.getPurchasingObserver();
          if (purchasingObserver != null)
            purchasingObserver.onPurchaseResponse(response); 
        }
      };
    this._handler.post(runnable);
  }
  
  private void handlePurchaseUpdatesResponse(Intent paramIntent) {
    Runnable runnable = new Runnable() {
        public void run() {
          if (Logger.isTraceOn())
            Logger.trace("SandboxResponseHandler", "Running Runnable for purchaseUpdatesResponse with requestId: " + response.getRequestId()); 
          PurchasingObserver purchasingObserver = PurchasingManager.getPurchasingObserver();
          if (purchasingObserver != null)
            purchasingObserver.onPurchaseUpdatesResponse(response); 
        }
      };
    this._handler.post(runnable);
  }
  
  private void handleUserIdResponse(Intent paramIntent) {
    Runnable runnable = new Runnable() {
        public void run() {
          if (Logger.isTraceOn())
            Logger.trace("SandboxResponseHandler", "Running Runnable for userIdResponse with requestId: " + response.getRequestId()); 
          PurchasingObserver purchasingObserver = PurchasingManager.getPurchasingObserver();
          if (purchasingObserver != null)
            purchasingObserver.onGetUserIdResponse(response); 
        }
      };
    this._handler.post(runnable);
  }
  
  public void handleResponse(Context paramContext, Intent paramIntent) {
    if (Logger.isTraceOn())
      Logger.trace("SandboxResponseHandler", "handleResponse"); 
    try {
      String str = paramIntent.getExtras().getString("responseType");
      if (str.equalsIgnoreCase("com.amazon.testclient.iap.purchase")) {
        handlePurchaseResponse(paramIntent);
        return;
      } 
      if (str.equalsIgnoreCase("com.amazon.testclient.iap.appUserId")) {
        handleUserIdResponse(paramIntent);
        return;
      } 
    } catch (Exception exception) {
      Log.e("SandboxResponseHandler", "Error handling response.", exception);
      return;
    } 
    if (exception.equalsIgnoreCase("com.amazon.testclient.iap.itemData")) {
      handleItemDataResponse(paramIntent);
      return;
    } 
    if (exception.equalsIgnoreCase("com.amazon.testclient.iap.purchaseUpdates"))
      handlePurchaseUpdatesResponse(paramIntent); 
  }
}


/* Location:              C:\soft\dex2jar-2.0\Smash Cricket-dex2jar.jar!\com\amazon\inapp\purchasing\SandboxResponseHandler.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */