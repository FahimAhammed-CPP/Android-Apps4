package com.amazon.inapp.purchasing;

import android.content.Context;
import android.content.Intent;
import com.amazon.android.Kiwi;

final class KiwiResponseHandler implements ResponseHandler {
  static final String HANDLER_THREAD_NAME = "KiwiResponseHandlerHandlerThread";
  
  private static final String KEY_REQUEST_ID = "requestId";
  
  private static final String KEY_RESPONSE_TYPE = "response_type";
  
  private static final String TAG = "KiwiResponseHandler";
  
  private final HandlerAdapter _handler = HandlerManager.getHandlerAdapter("KiwiResponseHandlerHandlerThread");
  
  public void handleResponse(Context paramContext, Intent paramIntent) {
    if (Logger.isTraceOn())
      Logger.trace("KiwiResponseHandler", "handleResponse"); 
    String str = paramIntent.getExtras().getString("response_type");
    if (str == null) {
      if (Logger.isTraceOn())
        Logger.trace("KiwiResponseHandler", "Invalid response type: null"); 
      return;
    } 
    try {
      String str1;
      ResponseType responseType = ResponseType.valueOf(str);
      if (Logger.isTraceOn())
        Logger.trace("KiwiResponseHandler", "Found response type: " + responseType); 
      str = null;
      switch (responseType) {
        default:
          str1 = str;
          if (str1 != null) {
            this._handler.post((Runnable)str1);
            return;
          } 
          return;
        case purchase_response:
          break;
      } 
    } catch (IllegalArgumentException illegalArgumentException) {
      if (Logger.isTraceOn()) {
        Logger.trace("KiwiResponseHandler", "Invlid response type: " + str);
        return;
      } 
      return;
    } 
    PurchaseResponseHandlerRunnable purchaseResponseHandlerRunnable = new PurchaseResponseHandlerRunnable((Context)illegalArgumentException, paramIntent);
    if (purchaseResponseHandlerRunnable != null) {
      this._handler.post(purchaseResponseHandlerRunnable);
      return;
    } 
  }
  
  private class PurchaseResponseHandlerRunnable extends ResponseHandlerRunnable {
    public PurchaseResponseHandlerRunnable(Context param1Context, Intent param1Intent) {
      super(param1Context, param1Intent);
    }
    
    public void run() {
      if (Logger.isTraceOn())
        Logger.trace("KiwiResponseHandler", "PurchaseResponseHandlerRunnable.run()"); 
      String str = getIntent().getExtras().getString("requestId");
      if (Logger.isTraceOn())
        Logger.trace("KiwiResponseHandler", "PurchaseResponseHandlerRunnable.run: requestId: " + str); 
      if (str != null && str.trim().length() > 0)
        Kiwi.addCommandToCommandTaskPipeline(new KiwiPurchaseResponseCommandTask(str)); 
    }
  }
  
  private abstract class ResponseHandlerRunnable implements Runnable {
    private final Context _context;
    
    private final Intent _intent;
    
    public ResponseHandlerRunnable(Context param1Context, Intent param1Intent) {
      this._context = param1Context;
      this._intent = param1Intent;
    }
    
    protected final Context getContext() {
      return this._context;
    }
    
    protected final Intent getIntent() {
      return this._intent;
    }
  }
  
  enum ResponseType {
    item_response, purchase_response, updates_response;
    
    static {
      $VALUES = new ResponseType[] { purchase_response, item_response, updates_response };
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Smash Cricket-dex2jar.jar!\com\amazon\inapp\purchasing\KiwiResponseHandler.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */