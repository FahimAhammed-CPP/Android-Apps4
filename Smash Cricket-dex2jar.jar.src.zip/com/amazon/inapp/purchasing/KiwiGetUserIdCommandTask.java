package com.amazon.inapp.purchasing;

import android.os.RemoteException;
import com.amazon.android.framework.exception.KiwiException;
import com.amazon.venezia.command.SuccessResult;
import java.util.Map;

final class KiwiGetUserIdCommandTask extends KiwiBaseCommandTask {
  private static final String COMMAND_NAME = "get_userId";
  
  private static final String COMMAND_VERSION = "1.0";
  
  private static final String TAG = "KiwiGetUserIdCommandTask";
  
  KiwiGetUserIdCommandTask(String paramString) {
    super("get_userId", "1.0", paramString);
  }
  
  private void notifyObserver(final GetUserIdResponse getUserIdResponse) {
    postRunnableToMainLooper(new Runnable() {
          public void run() {
            PurchasingObserver purchasingObserver = PurchasingManager.getPurchasingObserver();
            if (purchasingObserver != null) {
              if (Logger.isTraceOn())
                Logger.trace("KiwiGetUserIdCommandTask", "Invoking onGetUserIdResponse with " + getUserIdResponse); 
              purchasingObserver.onGetUserIdResponse(getUserIdResponse);
            } 
          }
        });
  }
  
  protected void onSuccess(SuccessResult paramSuccessResult) throws RemoteException, KiwiException {
    GetUserIdResponse.GetUserIdRequestStatus getUserIdRequestStatus;
    if (Logger.isTraceOn())
      Logger.trace("KiwiGetUserIdCommandTask", "onSuccess"); 
    Map map = paramSuccessResult.getData();
    if (Logger.isTraceOn())
      Logger.trace("KiwiGetUserIdCommandTask", "data: " + map); 
    String str = (String)map.get("userId");
    if (!isNullOrEmpty(str)) {
      getUserIdRequestStatus = GetUserIdResponse.GetUserIdRequestStatus.SUCCESSFUL;
    } else {
      if (Logger.isTraceOn())
        Logger.trace("KiwiGetUserIdCommandTask", "found null or empty user ID"); 
      str = null;
      getUserIdRequestStatus = GetUserIdResponse.GetUserIdRequestStatus.FAILED;
    } 
    notifyObserver(new GetUserIdResponse(getRequestId(), getUserIdRequestStatus, str));
  }
  
  protected void sendFailedResponse() {
    notifyObserver(new GetUserIdResponse(getRequestId(), GetUserIdResponse.GetUserIdRequestStatus.FAILED, null));
  }
}


/* Location:              C:\soft\dex2jar-2.0\Smash Cricket-dex2jar.jar!\com\amazon\inapp\purchasing\KiwiGetUserIdCommandTask.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */