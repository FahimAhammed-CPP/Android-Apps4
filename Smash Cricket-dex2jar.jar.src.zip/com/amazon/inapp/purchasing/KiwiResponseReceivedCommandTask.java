package com.amazon.inapp.purchasing;

import android.os.RemoteException;
import com.amazon.android.framework.exception.KiwiException;
import com.amazon.venezia.command.SuccessResult;

final class KiwiResponseReceivedCommandTask extends KiwiBaseCommandTask {
  private static final String COMMAND_NAME = "response_received";
  
  private static final String COMMAND_VERSION = "1.0";
  
  private static final String TAG = "KiwiResponseReceivedCommandTask";
  
  KiwiResponseReceivedCommandTask(String paramString) {
    super("response_received", "1.0", paramString);
  }
  
  protected void onSuccess(SuccessResult paramSuccessResult) throws RemoteException, KiwiException {
    if (Logger.isTraceOn())
      Logger.trace("KiwiResponseReceivedCommandTask", "onSuccess"); 
  }
  
  protected void sendFailedResponse() {}
}


/* Location:              C:\soft\dex2jar-2.0\Smash Cricket-dex2jar.jar!\com\amazon\inapp\purchasing\KiwiResponseReceivedCommandTask.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */