package com.amazon.inapp.purchasing;

interface ImplementationRegistry {
  <T> Class<T> getImplementation(Class<T> paramClass);
}


/* Location:              C:\soft\dex2jar-2.0\Smash Cricket-dex2jar.jar!\com\amazon\inapp\purchasing\ImplementationRegistry.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */