package com.amazon.inapp.purchasing;

import java.util.Collection;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;
import java.util.Set;

public final class ItemDataResponse {
  private static final String TO_STRING_FORMAT = "(%s, requestId: \"%s\", itemDataRequestStatus: \"%s\", unavailableSkus: %s, itemData: %s)";
  
  private final Map<String, Item> _itemData;
  
  private final ItemDataRequestStatus _itemDataRequestStatus;
  
  private final String _requestId;
  
  private final Set<String> _unavailableSkus;
  
  ItemDataResponse(String paramString, Set<String> paramSet, ItemDataRequestStatus paramItemDataRequestStatus, Map<String, Item> paramMap) {
    Validator.validateNotNull(paramString, "requestId");
    Validator.validateNotNull(paramItemDataRequestStatus, "itemDataRequestStatus");
    if (ItemDataRequestStatus.SUCCESSFUL_WITH_UNAVAILABLE_SKUS == paramItemDataRequestStatus) {
      Validator.validateNotNull(paramSet, "unavailableSkus");
      Validator.validateNotEmpty((Collection)paramSet, "unavailableSkus");
    } 
    if (ItemDataRequestStatus.SUCCESSFUL == paramItemDataRequestStatus) {
      Validator.validateNotNull(paramMap, "itemData");
      Validator.validateNotEmpty((Collection)paramMap.entrySet(), "itemData");
    } 
    this._requestId = paramString;
    this._itemDataRequestStatus = paramItemDataRequestStatus;
    if (paramSet == null)
      paramSet = new HashSet<String>(); 
    this._unavailableSkus = paramSet;
    if (paramMap == null)
      paramMap = new HashMap<String, Item>(); 
    this._itemData = paramMap;
  }
  
  public Map<String, Item> getItemData() {
    return this._itemData;
  }
  
  public ItemDataRequestStatus getItemDataRequestStatus() {
    return this._itemDataRequestStatus;
  }
  
  public String getRequestId() {
    return this._requestId;
  }
  
  public Set<String> getUnavailableSkus() {
    return this._unavailableSkus;
  }
  
  public String toString() {
    return String.format("(%s, requestId: \"%s\", itemDataRequestStatus: \"%s\", unavailableSkus: %s, itemData: %s)", new Object[] { super.toString(), this._requestId, this._itemDataRequestStatus, this._unavailableSkus, this._itemData });
  }
  
  public enum ItemDataRequestStatus {
    FAILED, SUCCESSFUL, SUCCESSFUL_WITH_UNAVAILABLE_SKUS;
    
    static {
      $VALUES = new ItemDataRequestStatus[] { SUCCESSFUL, FAILED, SUCCESSFUL_WITH_UNAVAILABLE_SKUS };
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Smash Cricket-dex2jar.jar!\com\amazon\inapp\purchasing\ItemDataResponse.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */