package com.amazon.inapp.purchasing;

import android.content.Intent;
import android.os.Bundle;
import java.util.Set;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

final class SandboxRequestHandler implements RequestHandler {
  private static final String TAG = "SandboxRequestHandler";
  
  public void sendContentDownloadRequest(String paramString1, String paramString2, String paramString3) {}
  
  public void sendGetUserIdRequest(String paramString) {
    if (Logger.isTraceOn())
      Logger.trace("SandboxRequestHandler", "sendGetUserIdRequest"); 
    try {
      Bundle bundle = new Bundle();
      JSONObject jSONObject = new JSONObject();
      jSONObject.put("requestId", paramString);
      jSONObject.put("packageName", PurchasingManager.getObserverContext().getPackageName());
      bundle.putString("userInput", jSONObject.toString());
      Intent intent = new Intent("com.amazon.testclient.iap.appUserId");
      intent.addFlags(268435456);
      intent.putExtras(bundle);
      PurchasingManager.getObserverContext().startService(intent);
      return;
    } catch (JSONException jSONException) {
      Logger.error("SandboxRequestHandler", "Error in sendGetUserIdRequest.");
      return;
    } 
  }
  
  public void sendItemDataRequest(Set<String> paramSet, String paramString) {
    if (Logger.isTraceOn())
      Logger.trace("SandboxRequestHandler", "sendItemDataRequest"); 
    try {
      Bundle bundle = new Bundle();
      JSONObject jSONObject = new JSONObject();
      JSONArray jSONArray = new JSONArray(paramSet);
      jSONObject.put("requestId", paramString);
      jSONObject.put("packageName", PurchasingManager.getObserverContext().getPackageName());
      jSONObject.put("skus", jSONArray);
      bundle.putString("itemDataInput", jSONObject.toString());
      Intent intent = new Intent("com.amazon.testclient.iap.itemData");
      intent.addFlags(268435456);
      intent.putExtras(bundle);
      PurchasingManager.getObserverContext().startService(intent);
      return;
    } catch (JSONException jSONException) {
      Logger.error("SandboxRequestHandler", "Error in sendItemDataRequest.");
      return;
    } 
  }
  
  public void sendPurchaseRequest(String paramString1, String paramString2) {
    if (Logger.isTraceOn())
      Logger.trace("SandboxRequestHandler", "sendPurchaseRequest"); 
    try {
      Bundle bundle = new Bundle();
      JSONObject jSONObject = new JSONObject();
      jSONObject.put("sku", paramString1);
      jSONObject.put("requestId", paramString2);
      jSONObject.put("packageName", PurchasingManager.getObserverContext().getPackageName());
      bundle.putString("purchaseInput", jSONObject.toString());
      Intent intent = new Intent("com.amazon.testclient.iap.purchase");
      intent.addFlags(268435456);
      intent.putExtras(bundle);
      PurchasingManager.getObserverContext().startService(intent);
      return;
    } catch (JSONException jSONException) {
      Logger.error("SandboxRequestHandler", "Error in sendPurchaseRequest.");
      return;
    } 
  }
  
  public void sendPurchaseResponseReceivedRequest(String paramString) {}
  
  public void sendPurchaseUpdatesRequest(Offset paramOffset, String paramString) {
    if (Logger.isTraceOn())
      Logger.trace("SandboxRequestHandler", "sendPurchaseUpdatesRequest"); 
    try {
      Bundle bundle = new Bundle();
      JSONObject jSONObject = new JSONObject();
      jSONObject.put("requestId", paramString);
      jSONObject.put("packageName", PurchasingManager.getObserverContext().getPackageName());
      jSONObject.put("offset", paramOffset.toString());
      bundle.putString("purchaseUpdatesInput", jSONObject.toString());
      Intent intent = new Intent("com.amazon.testclient.iap.purchaseUpdates");
      intent.addFlags(268435456);
      intent.putExtras(bundle);
      PurchasingManager.getObserverContext().startService(intent);
      return;
    } catch (JSONException jSONException) {
      Logger.error("SandboxRequestHandler", "Error in sendPurchaseUpdatesRequest.");
      return;
    } 
  }
}


/* Location:              C:\soft\dex2jar-2.0\Smash Cricket-dex2jar.jar!\com\amazon\inapp\purchasing\SandboxRequestHandler.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */