package com.amazon.inapp.purchasing;

import java.util.HashMap;
import java.util.Map;

class HandlerManager {
  private static volatile Map<String, HandlerAdapter> HANDLER_ADAPTERS = new HashMap<String, HandlerAdapter>();
  
  private static volatile HandlerAdapter MAIN_HANDLER_ADAPTER = null;
  
  static HandlerAdapter getHandlerAdapter(String paramString) {
    // Byte code:
    //   0: getstatic com/amazon/inapp/purchasing/HandlerManager.HANDLER_ADAPTERS : Ljava/util/Map;
    //   3: aload_0
    //   4: invokeinterface containsKey : (Ljava/lang/Object;)Z
    //   9: ifne -> 73
    //   12: ldc com/amazon/inapp/purchasing/HandlerManager
    //   14: monitorenter
    //   15: getstatic com/amazon/inapp/purchasing/HandlerManager.HANDLER_ADAPTERS : Ljava/util/Map;
    //   18: aload_0
    //   19: invokeinterface containsKey : (Ljava/lang/Object;)Z
    //   24: ifne -> 70
    //   27: new android/os/HandlerThread
    //   30: dup
    //   31: aload_0
    //   32: invokespecial <init> : (Ljava/lang/String;)V
    //   35: astore_1
    //   36: aload_1
    //   37: invokevirtual start : ()V
    //   40: new com/amazon/inapp/purchasing/HandlerAdapter
    //   43: dup
    //   44: new android/os/Handler
    //   47: dup
    //   48: aload_1
    //   49: invokevirtual getLooper : ()Landroid/os/Looper;
    //   52: invokespecial <init> : (Landroid/os/Looper;)V
    //   55: invokespecial <init> : (Landroid/os/Handler;)V
    //   58: astore_1
    //   59: getstatic com/amazon/inapp/purchasing/HandlerManager.HANDLER_ADAPTERS : Ljava/util/Map;
    //   62: aload_0
    //   63: aload_1
    //   64: invokeinterface put : (Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    //   69: pop
    //   70: ldc com/amazon/inapp/purchasing/HandlerManager
    //   72: monitorexit
    //   73: getstatic com/amazon/inapp/purchasing/HandlerManager.HANDLER_ADAPTERS : Ljava/util/Map;
    //   76: aload_0
    //   77: invokeinterface get : (Ljava/lang/Object;)Ljava/lang/Object;
    //   82: checkcast com/amazon/inapp/purchasing/HandlerAdapter
    //   85: areturn
    //   86: astore_0
    //   87: ldc com/amazon/inapp/purchasing/HandlerManager
    //   89: monitorexit
    //   90: aload_0
    //   91: athrow
    // Exception table:
    //   from	to	target	type
    //   15	70	86	finally
    //   70	73	86	finally
    //   87	90	86	finally
  }
  
  static HandlerAdapter getMainHandlerAdapter() {
    // Byte code:
    //   0: getstatic com/amazon/inapp/purchasing/HandlerManager.MAIN_HANDLER_ADAPTER : Lcom/amazon/inapp/purchasing/HandlerAdapter;
    //   3: ifnonnull -> 41
    //   6: ldc com/amazon/inapp/purchasing/HandlerManager
    //   8: monitorenter
    //   9: getstatic com/amazon/inapp/purchasing/HandlerManager.MAIN_HANDLER_ADAPTER : Lcom/amazon/inapp/purchasing/HandlerAdapter;
    //   12: ifnonnull -> 38
    //   15: new com/amazon/inapp/purchasing/HandlerAdapter
    //   18: dup
    //   19: new android/os/Handler
    //   22: dup
    //   23: invokestatic getObserverContext : ()Landroid/content/Context;
    //   26: invokevirtual getMainLooper : ()Landroid/os/Looper;
    //   29: invokespecial <init> : (Landroid/os/Looper;)V
    //   32: invokespecial <init> : (Landroid/os/Handler;)V
    //   35: putstatic com/amazon/inapp/purchasing/HandlerManager.MAIN_HANDLER_ADAPTER : Lcom/amazon/inapp/purchasing/HandlerAdapter;
    //   38: ldc com/amazon/inapp/purchasing/HandlerManager
    //   40: monitorexit
    //   41: getstatic com/amazon/inapp/purchasing/HandlerManager.MAIN_HANDLER_ADAPTER : Lcom/amazon/inapp/purchasing/HandlerAdapter;
    //   44: areturn
    //   45: astore_0
    //   46: ldc com/amazon/inapp/purchasing/HandlerManager
    //   48: monitorexit
    //   49: aload_0
    //   50: athrow
    // Exception table:
    //   from	to	target	type
    //   9	38	45	finally
    //   38	41	45	finally
    //   46	49	45	finally
  }
  
  static void setHandlerAdapter(String paramString, HandlerAdapter paramHandlerAdapter) {
    HANDLER_ADAPTERS.put(paramString, paramHandlerAdapter);
  }
  
  static void setMainHandlerAdapter(HandlerAdapter paramHandlerAdapter) {
    MAIN_HANDLER_ADAPTER = paramHandlerAdapter;
  }
}


/* Location:              C:\soft\dex2jar-2.0\Smash Cricket-dex2jar.jar!\com\amazon\inapp\purchasing\HandlerManager.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */