package com.amazon.inapp.purchasing;

import java.util.Set;

interface RequestHandler {
  void sendContentDownloadRequest(String paramString1, String paramString2, String paramString3);
  
  void sendGetUserIdRequest(String paramString);
  
  void sendItemDataRequest(Set<String> paramSet, String paramString);
  
  void sendPurchaseRequest(String paramString1, String paramString2);
  
  void sendPurchaseResponseReceivedRequest(String paramString);
  
  void sendPurchaseUpdatesRequest(Offset paramOffset, String paramString);
}


/* Location:              C:\soft\dex2jar-2.0\Smash Cricket-dex2jar.jar!\com\amazon\inapp\purchasing\RequestHandler.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */