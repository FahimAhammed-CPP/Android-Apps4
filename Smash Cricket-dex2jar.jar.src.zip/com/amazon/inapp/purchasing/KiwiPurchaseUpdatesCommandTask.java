package com.amazon.inapp.purchasing;

import android.os.RemoteException;
import com.amazon.android.framework.exception.KiwiException;
import com.amazon.venezia.command.SuccessResult;
import java.util.HashSet;
import java.util.Map;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

final class KiwiPurchaseUpdatesCommandTask extends KiwiBaseCommandTask {
  private static final String COMMAND_NAME = "purchase_updates";
  
  private static final String COMMAND_VERSION = "1.0";
  
  private static final String TAG = "KiwiPurchaseUpdatesCommandTask";
  
  private final Offset _offset;
  
  KiwiPurchaseUpdatesCommandTask(Offset paramOffset, String paramString) {
    super("purchase_updates", "1.0", paramString);
    String str;
    this._offset = paramOffset;
    if (Offset.BEGINNING.equals(this._offset)) {
      paramOffset = null;
    } else {
      str = this._offset.toString();
    } 
    addCommandData("cursor", str);
  }
  
  private PurchaseUpdatesResponse getFailedResponse() {
    return new PurchaseUpdatesResponse(getRequestId(), null, PurchaseUpdatesResponse.PurchaseUpdatesRequestStatus.FAILED, null, null, this._offset, false);
  }
  
  private void notifyObserver(final PurchaseUpdatesResponse purchaseUpdatesResponse) {
    postRunnableToMainLooper(new Runnable() {
          public void run() {
            PurchasingObserver purchasingObserver = PurchasingManager.getPurchasingObserver();
            if (purchasingObserver != null) {
              if (Logger.isTraceOn())
                Logger.trace("KiwiPurchaseUpdatesCommandTask", "Invoking onPurchaseUpdatesResponse with " + purchaseUpdatesResponse); 
              purchasingObserver.onPurchaseUpdatesResponse(purchaseUpdatesResponse);
            } 
          }
        });
  }
  
  protected void onSuccess(SuccessResult paramSuccessResult) throws RemoteException, KiwiException {
    if (Logger.isTraceOn())
      Logger.trace("KiwiPurchaseUpdatesCommandTask", "onSuccess"); 
    Map map = paramSuccessResult.getData();
    if (Logger.isTraceOn())
      Logger.trace("KiwiPurchaseUpdatesCommandTask", "data: " + map); 
    String str2 = (String)map.get("errorMessage");
    String str1 = (String)map.get("userId");
    if (Logger.isTraceOn())
      Logger.trace("KiwiPurchaseUpdatesCommandTask", "onSuccess: errorMessage: \"" + str2 + "\""); 
    if (isNullOrEmpty(str2))
      try {
        HashSet<Receipt> hashSet = new HashSet();
        HashSet<String> hashSet1 = new HashSet();
        JSONArray jSONArray = new JSONArray((String)map.get("receipts"));
        for (int i = 0;; i++) {
          if (i < jSONArray.length()) {
            JSONObject jSONObject = jSONArray.getJSONObject(i);
            Receipt receipt = getReceiptFromReceiptJson(jSONObject);
            if (verifyReceipt(str1, receipt, jSONObject))
              hashSet.add(receipt); 
          } else {
            Offset offset;
            jSONArray = new JSONArray((String)map.get("revocations"));
            for (i = 0; i < jSONArray.length(); i++)
              hashSet1.add(jSONArray.getString(i)); 
            String str = (String)map.get("cursor");
            boolean bool = "true".equalsIgnoreCase((String)map.get("hasMore"));
            if (isNullOrEmpty(str)) {
              offset = Offset.BEGINNING;
            } else {
              offset = Offset.fromString(str);
            } 
            PurchaseUpdatesResponse.PurchaseUpdatesRequestStatus purchaseUpdatesRequestStatus = PurchaseUpdatesResponse.PurchaseUpdatesRequestStatus.SUCCESSFUL;
            notifyObserver(new PurchaseUpdatesResponse(getRequestId(), str1, purchaseUpdatesRequestStatus, hashSet, hashSet1, offset, bool));
            return;
          } 
        } 
      } catch (JSONException jSONException) {
        if (Logger.isErrorOn())
          Logger.error("KiwiPurchaseUpdatesCommandTask", "Error parsing purchase updates JSON: " + jSONException.getMessage()); 
        sendFailedResponse();
        return;
      }  
  }
  
  protected void sendFailedResponse() {
    notifyObserver(getFailedResponse());
  }
}


/* Location:              C:\soft\dex2jar-2.0\Smash Cricket-dex2jar.jar!\com\amazon\inapp\purchasing\KiwiPurchaseUpdatesCommandTask.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */