package com.amazon.inapp.purchasing;

import com.amazon.android.Kiwi;
import java.util.Set;

final class KiwiRequestHandler implements RequestHandler {
  static final String HANDLER_THREAD_NAME = "KiwiRequestHandlerHandlerThread";
  
  private static final String TAG = "KiwiRequestHandler";
  
  private final HandlerAdapter _handler = HandlerManager.getHandlerAdapter("KiwiRequestHandlerHandlerThread");
  
  public void sendContentDownloadRequest(String paramString1, String paramString2, String paramString3) {}
  
  public void sendGetUserIdRequest(final String requestId) {
    if (Logger.isTraceOn())
      Logger.trace("KiwiRequestHandler", "sendGetUserIdRequest"); 
    Runnable runnable = new Runnable() {
        public void run() {
          Kiwi.addCommandToCommandTaskPipeline(new KiwiGetUserIdCommandTask(requestId));
        }
      };
    this._handler.post(runnable);
  }
  
  public void sendItemDataRequest(final Set<String> skus, final String requestId) {
    if (Logger.isTraceOn())
      Logger.trace("KiwiRequestHandler", "sendItemDataRequest"); 
    Runnable runnable = new Runnable() {
        public void run() {
          Kiwi.addCommandToCommandTaskPipeline(new KiwiGetItemDataRequestCommandTask(skus, requestId));
        }
      };
    this._handler.post(runnable);
  }
  
  public void sendPurchaseRequest(final String sku, final String requestId) {
    if (Logger.isTraceOn())
      Logger.trace("KiwiRequestHandler", "sendPurchaseRequest"); 
    Runnable runnable = new Runnable() {
        public void run() {
          Kiwi.addCommandToCommandTaskPipeline(new KiwiPurchaseRequestCommandTask(sku, requestId));
        }
      };
    this._handler.post(runnable);
  }
  
  public void sendPurchaseResponseReceivedRequest(final String requestId) {
    if (Logger.isTraceOn())
      Logger.trace("KiwiRequestHandler", "sendPurchaseResponseReceivedRequest"); 
    Runnable runnable = new Runnable() {
        public void run() {
          Kiwi.addCommandToCommandTaskPipeline(new KiwiResponseReceivedCommandTask(requestId));
        }
      };
    this._handler.post(runnable);
  }
  
  public void sendPurchaseUpdatesRequest(final Offset offset, final String requestId) {
    if (Logger.isTraceOn())
      Logger.trace("KiwiRequestHandler", "sendPurchaseUpdatesRequest"); 
    Runnable runnable = new Runnable() {
        public void run() {
          Kiwi.addCommandToCommandTaskPipeline(new KiwiPurchaseUpdatesCommandTask(offset, requestId));
        }
      };
    this._handler.post(runnable);
  }
}


/* Location:              C:\soft\dex2jar-2.0\Smash Cricket-dex2jar.jar!\com\amazon\inapp\purchasing\KiwiRequestHandler.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */