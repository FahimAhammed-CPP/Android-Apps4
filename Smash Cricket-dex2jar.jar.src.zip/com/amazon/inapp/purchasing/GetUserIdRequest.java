package com.amazon.inapp.purchasing;

final class GetUserIdRequest extends Request {
  Runnable getRunnable() {
    return new Runnable() {
        public void run() {
          ImplementationFactory.getRequestHandler().sendGetUserIdRequest(GetUserIdRequest.this.getRequestId());
        }
      };
  }
}


/* Location:              C:\soft\dex2jar-2.0\Smash Cricket-dex2jar.jar!\com\amazon\inapp\purchasing\GetUserIdRequest.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */