package com.amazon.inapp.purchasing;

import java.util.UUID;

abstract class Request {
  private final String _requestId = UUID.randomUUID().toString();
  
  String getRequestId() {
    return this._requestId;
  }
  
  abstract Runnable getRunnable();
}


/* Location:              C:\soft\dex2jar-2.0\Smash Cricket-dex2jar.jar!\com\amazon\inapp\purchasing\Request.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */