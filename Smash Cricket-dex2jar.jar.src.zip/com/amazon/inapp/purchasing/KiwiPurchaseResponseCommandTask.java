package com.amazon.inapp.purchasing;

import android.os.RemoteException;
import com.amazon.android.framework.exception.KiwiException;
import com.amazon.venezia.command.SuccessResult;
import java.util.Map;
import org.json.JSONException;
import org.json.JSONObject;

final class KiwiPurchaseResponseCommandTask extends KiwiBaseCommandTask {
  private static final String COMMAND_NAME = "purchase_response";
  
  private static final String COMMAND_VERSION = "1.0";
  
  private static final String TAG = "KiwiPurchaseResponseCommandTask";
  
  KiwiPurchaseResponseCommandTask(String paramString) {
    super("purchase_response", "1.0", paramString);
  }
  
  protected void onSuccess(SuccessResult paramSuccessResult) throws RemoteException, KiwiException {
    String str2 = null;
    if (Logger.isTraceOn())
      Logger.trace("KiwiPurchaseResponseCommandTask", "onSuccess"); 
    Map map = paramSuccessResult.getData();
    if (Logger.isTraceOn())
      Logger.trace("KiwiPurchaseResponseCommandTask", "data: " + map); 
    String str1 = (String)map.get("errorMessage");
    String str4 = (String)map.get("userId");
    String str3 = (String)map.get("receipt");
    if (Logger.isTraceOn())
      Logger.trace("KiwiPurchaseResponseCommandTask", "onSuccess: errorMessage: \"" + str1 + "\" receipt: \"" + str3 + "\""); 
    PurchaseResponse.PurchaseRequestStatus purchaseRequestStatus = PurchaseResponse.PurchaseRequestStatus.FAILED;
    if (isNullOrEmpty(str1) && !isNullOrEmpty(str3)) {
      try {
        JSONObject jSONObject = new JSONObject(str3);
        str1 = jSONObject.getString("orderStatus");
        try {
          purchaseRequestStatus = PurchaseResponse.PurchaseRequestStatus.valueOf(str1);
        } catch (Exception exception) {}
        if (PurchaseResponse.PurchaseRequestStatus.SUCCESSFUL == exception) {
          Receipt receipt2 = getReceiptFromReceiptJson(jSONObject);
          Receipt receipt1 = receipt2;
          if (!verifyReceipt(str4, receipt2, jSONObject)) {
            purchaseRequestStatus = PurchaseResponse.PurchaseRequestStatus.FAILED;
            receipt1 = null;
          } 
        } else {
          str1 = null;
        } 
      } catch (JSONException jSONException) {}
    } else {
      str1 = str2;
    } 
    postRunnableToMainLooper(new Runnable() {
          public void run() {
            PurchasingObserver purchasingObserver = PurchasingManager.getPurchasingObserver();
            if (Logger.isTraceOn())
              Logger.trace("KiwiPurchaseResponseCommandTask", "About to invoke onPurchaseResponse with PurchasingObserver: " + purchasingObserver); 
            if (purchasingObserver != null) {
              if (Logger.isTraceOn())
                Logger.trace("KiwiPurchaseResponseCommandTask", "Invoking onPurchaseResponse with " + purchaseResponse); 
              purchasingObserver.onPurchaseResponse(purchaseResponse);
              if (Logger.isTraceOn())
                Logger.trace("KiwiPurchaseResponseCommandTask", "No exceptions were thrown when invoking onPurchaseResponse"); 
              ImplementationFactory.getRequestHandler().sendPurchaseResponseReceivedRequest(KiwiPurchaseResponseCommandTask.this.getRequestId());
            } 
          }
        });
  }
  
  protected void sendFailedResponse() {
    postRunnableToMainLooper(new Runnable() {
          public void run() {
            PurchasingObserver purchasingObserver = PurchasingManager.getPurchasingObserver();
            PurchaseResponse purchaseResponse = new PurchaseResponse(KiwiPurchaseResponseCommandTask.this.getRequestId(), null, null, PurchaseResponse.PurchaseRequestStatus.FAILED);
            if (purchasingObserver != null) {
              if (Logger.isTraceOn())
                Logger.trace("KiwiPurchaseResponseCommandTask", "Invoking onPurchaseResponse with " + purchaseResponse); 
              purchasingObserver.onPurchaseResponse(purchaseResponse);
            } 
          }
        });
  }
}


/* Location:              C:\soft\dex2jar-2.0\Smash Cricket-dex2jar.jar!\com\amazon\inapp\purchasing\KiwiPurchaseResponseCommandTask.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */