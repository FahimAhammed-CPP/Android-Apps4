package com.amazon.inapp.purchasing;

import android.os.Handler;

class HandlerAdapter {
  private Handler _handler;
  
  HandlerAdapter(Handler paramHandler) {
    this._handler = paramHandler;
  }
  
  boolean post(Runnable paramRunnable) {
    return this._handler.post(paramRunnable);
  }
}


/* Location:              C:\soft\dex2jar-2.0\Smash Cricket-dex2jar.jar!\com\amazon\inapp\purchasing\HandlerAdapter.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */