package com.amazon.inapp.purchasing;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;

public final class ResponseReceiver extends BroadcastReceiver {
  public void onReceive(Context paramContext, Intent paramIntent) {
    ImplementationFactory.getResponseHandler().handleResponse(paramContext, paramIntent);
  }
}


/* Location:              C:\soft\dex2jar-2.0\Smash Cricket-dex2jar.jar!\com\amazon\inapp\purchasing\ResponseReceiver.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */