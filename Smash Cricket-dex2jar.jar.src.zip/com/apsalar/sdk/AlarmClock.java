package com.apsalar.sdk;

import android.os.SystemClock;
import java.util.concurrent.locks.Condition;
import java.util.concurrent.locks.ReentrantLock;

class AlarmClock {
  static final ReentrantLock lock = new ReentrantLock();
  
  private static volatile Thread timer;
  
  static final Condition wakeUp = lock.newCondition();
  
  static {
    timer = null;
  }
  
  public static void interrupt() {
    lock.lock();
    wakeUp.signal();
    lock.unlock();
  }
  
  private static void setTimer(final int ttl) {
    if (timer != null && timer.isAlive())
      return; 
    timer = new Thread(new Runnable() {
          public void run() {
            SystemClock.sleep(ttl);
            AlarmClock.lock.lock();
            AlarmClock.wakeUp.signal();
            AlarmClock.lock.unlock();
          }
        });
    timer.start();
  }
  
  public static void start(int paramInt) {
    setTimer(paramInt);
    lock.lock();
    try {
      wakeUp.await();
      return;
    } catch (InterruptedException interruptedException) {
      return;
    } finally {
      lock.unlock();
    } 
  }
}


/* Location:              C:\soft\dex2jar-2.0\Smash Cricket-dex2jar.jar!\com\apsalar\sdk\AlarmClock.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */