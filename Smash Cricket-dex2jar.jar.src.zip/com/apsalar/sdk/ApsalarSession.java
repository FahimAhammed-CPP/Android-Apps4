package com.apsalar.sdk;

import android.content.Context;
import java.io.UnsupportedEncodingException;
import java.net.URLEncoder;
import org.json.JSONException;
import org.json.JSONObject;

class ApsalarSession extends ApsalarEvent implements ApsalarAPI, ApsalarJSON {
  static final String TAG = "Apsalar SDK/Session";
  
  protected ApsalarSession(Context paramContext, ApsalarSessionInfo paramApsalarSessionInfo) {
    super(paramContext, paramApsalarSessionInfo);
  }
  
  protected ApsalarSession(Context paramContext, ApsalarSessionInfo paramApsalarSessionInfo, long paramLong) {
    super(paramContext, paramApsalarSessionInfo, "", paramLong, "");
  }
  
  static int handleRedirect(JSONObject paramJSONObject) {
    String str;
    ApSingleton apSingleton = ApSingleton.getInstance(ApSingleton.getContext());
    try {
      str = paramJSONObject.getString("k");
      String str1 = paramJSONObject.getString("u");
      if (str.equals(apSingleton.canonicalKeyspace) && str1.equals(apSingleton.canonicalDeviceId))
        return 1; 
    } catch (JSONException jSONException) {
      apSingleton.incrExceptionCount();
      apSingleton.getClass();
      return 1;
    } 
    apSingleton.canonicalKeyspace = str;
    apSingleton.canonicalDeviceId = (String)jSONException;
    if (str.equals("ANDI")) {
      apSingleton.ANDI = (String)jSONException;
      apSingleton.getClass();
      return -1;
    } 
    if (str.equals("AIFA"))
      apSingleton.AIFA = (String)jSONException; 
    apSingleton.getClass();
    return -1;
  }
  
  public int REST() {
    ApSingleton.getInstance(this.ctx).getClass();
    return REST(Boolean.valueOf(true));
  }
  
  protected void init(Context paramContext) {
    this.ctx = paramContext;
    this.urlbase = "http://e.apsalar.com/api/v1/start";
    this.eventType = 1;
  }
  
  protected boolean makeURL() {
    ApSingleton apSingleton = ApSingleton.getInstance(this.ctx);
    apSingleton.getClass();
    try {
      String str2 = Apsalar.getDeviceId(apSingleton.canonicalKeyspace);
      String str3 = apSingleton.canonicalKeyspace;
      apSingleton.getClass();
      constructDK();
      apSingleton.getClass();
      StringBuilder stringBuilder = (new StringBuilder()).append("?a=").append(URLEncoder.encode(this.info.apiKey, "UTF-8")).append("&ab=").append(URLEncoder.encode(this.info.abi, "UTF-8")).append("&av=").append(URLEncoder.encode(this.info.appVersion, "UTF-8")).append("&br=").append(URLEncoder.encode(this.info.brand, "UTF-8")).append("&c=").append(URLEncoder.encode(this.info.connType, "UTF-8")).append("&de=").append(URLEncoder.encode(this.info.device, "UTF-8")).append("&i=").append(URLEncoder.encode(this.info.clsPackage, "UTF-8")).append("&ma=").append(URLEncoder.encode(this.info.manufacturer, "UTF-8")).append("&mo=").append(URLEncoder.encode(this.info.model, "UTF-8")).append("&n=").append(URLEncoder.encode(this.info.appName, "UTF-8")).append("&p=").append(URLEncoder.encode(this.info.platform, "UTF-8")).append("&pr=").append(URLEncoder.encode(this.info.product, "UTF-8")).append("&rt=").append(URLEncoder.encode(this.info.retType, "UTF-8")).append("&s=").append(URLEncoder.encode(this.info.sessionId, "UTF-8")).append("&sdk=").append(URLEncoder.encode("Apsalar/" + this.info.sdkVersion, "UTF-8")).append("&u=").append(URLEncoder.encode(str2, "UTF-8")).append("&k=").append(URLEncoder.encode(str3, "UTF-8")).append("&dk=").append(URLEncoder.encode(apSingleton.dk, "UTF-8")).append("&aifa=").append(URLEncoder.encode(apSingleton.AIFA, "UTF-8")).append("&dnt=");
      if (apSingleton.playStoreAvailable) {
        if (apSingleton.isLAT) {
          str1 = "1";
        } else {
          str1 = "0";
        } 
      } else {
        str1 = "-1";
      } 
      String str1 = stringBuilder.append(URLEncoder.encode(str1, "UTF-8")).append("&v=").append(URLEncoder.encode(this.info.osVersion, "UTF-8")).toString();
      apSingleton.dk = null;
      this.old_k = str3;
      this.old_u = str2;
      this.url = str1;
      if (this.url.length() >= 1999) {
        apSingleton.getClass();
        return false;
      } 
    } catch (UnsupportedEncodingException unsupportedEncodingException) {
      apSingleton.incrExceptionCount();
      apSingleton.getClass();
      return false;
    } 
    return true;
  }
}


/* Location:              C:\soft\dex2jar-2.0\Smash Cricket-dex2jar.jar!\com\apsalar\sdk\ApsalarSession.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */