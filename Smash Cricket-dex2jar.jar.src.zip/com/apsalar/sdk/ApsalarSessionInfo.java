package com.apsalar.sdk;

import android.content.Context;
import android.content.pm.PackageManager;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.os.Build;
import java.util.UUID;
import org.json.JSONException;
import org.json.JSONObject;

class ApsalarSessionInfo implements ApsalarJSON {
  static final String TAG = "Apsalar SDK/SessionInfo";
  
  protected String abi;
  
  protected String apiKey;
  
  protected String appName;
  
  protected String appVersion;
  
  protected String brand;
  
  protected String clsPackage;
  
  protected String connType;
  
  protected String device;
  
  protected String deviceId;
  
  protected JSONObject known_items;
  
  protected String manufacturer;
  
  protected String model;
  
  protected String osVersion;
  
  protected String platform;
  
  protected String product;
  
  protected String retType;
  
  protected String sdkVersion;
  
  protected String secret;
  
  protected String sessionId;
  
  protected long sessionStart;
  
  protected ApsalarSessionInfo(Context paramContext, String paramString1, String paramString2) {
    String str;
    this.sessionStart = 0L;
    this.sdkVersion = "6.1.5";
    ApSingleton apSingleton = ApSingleton.getInstance(paramContext);
    this.sessionId = UUID.randomUUID().toString();
    apSingleton.getClass();
    this.apiKey = paramString1;
    this.secret = paramString2;
    PackageManager packageManager = paramContext.getPackageManager();
    this.platform = "Android";
    this.clsPackage = paramContext.getPackageName();
    try {
      this.appVersion = (packageManager.getPackageInfo(this.clsPackage, 0)).versionName;
    } catch (android.content.pm.PackageManager.NameNotFoundException nameNotFoundException) {
      this.appVersion = "unknown";
    } 
    if (this.deviceId == null)
      this.deviceId = "None"; 
    this.retType = "json";
    this.connType = "wifi";
    try {
      NetworkInfo networkInfo = ((ConnectivityManager)paramContext.getSystemService("connectivity")).getNetworkInfo(0);
      if (networkInfo != null && networkInfo.isConnected())
        this.connType = "wwan"; 
    } catch (SecurityException securityException) {
      apSingleton.getClass();
    } catch (Exception exception) {
      apSingleton.getClass();
    } 
    this.appName = "unknown";
    try {
      this.appName = packageManager.getApplicationLabel(packageManager.getApplicationInfo(this.clsPackage, 128)).toString();
    } catch (android.content.pm.PackageManager.NameNotFoundException nameNotFoundException) {
      apSingleton.getClass();
    } catch (NullPointerException nullPointerException) {
      apSingleton.getClass();
    } 
    this.osVersion = Build.VERSION.RELEASE;
    this.brand = Build.BRAND;
    this.device = Build.DEVICE;
    this.abi = "unknown";
    this.manufacturer = "unknown";
    try {
      this.abi = (String)Build.class.getDeclaredField("CPU_ABI").get(Build.class);
    } catch (Throwable throwable) {
      apSingleton.getClass();
    } 
    try {
      this.manufacturer = (String)Build.class.getDeclaredField("MANUFACTURER").get(Build.class);
    } catch (Throwable throwable) {
      apSingleton.getClass();
    } 
    this.model = Build.MODEL;
    this.product = Build.PRODUCT;
    if (this.abi != null) {
      str = this.abi;
    } else {
      str = "unknown";
    } 
    this.abi = str;
    if (this.platform != null) {
      str = this.platform;
    } else {
      str = "Android";
    } 
    this.platform = str;
    if (this.clsPackage != null) {
      str = this.clsPackage;
    } else {
      str = "unknown";
    } 
    this.clsPackage = str;
    if (this.appVersion != null) {
      str = this.appVersion;
    } else {
      str = "unknown";
    } 
    this.appVersion = str;
    if (this.deviceId != null) {
      str = this.deviceId;
    } else {
      str = "unspecified";
    } 
    this.deviceId = str;
    if (this.sessionId != null) {
      str = this.sessionId;
    } else {
      str = "unspecified";
    } 
    this.sessionId = str;
    if (this.retType != null) {
      str = this.retType;
    } else {
      str = "json";
    } 
    this.retType = str;
    if (this.connType != null) {
      str = this.connType;
    } else {
      str = "wifi";
    } 
    this.connType = str;
    if (this.appName != null) {
      str = this.appName;
    } else {
      str = "unknown";
    } 
    this.appName = str;
    if (this.osVersion != null) {
      str = this.osVersion;
    } else {
      str = "unknown";
    } 
    this.osVersion = str;
    if (this.brand != null) {
      str = this.brand;
    } else {
      str = "unknown";
    } 
    this.brand = str;
    if (this.device != null) {
      str = this.device;
    } else {
      str = "unknown";
    } 
    this.device = str;
    if (this.manufacturer != null) {
      str = this.manufacturer;
    } else {
      str = "unknown";
    } 
    this.manufacturer = str;
    if (this.model != null) {
      str = this.model;
    } else {
      str = "unknown";
    } 
    this.model = str;
    if (this.product != null) {
      str = this.product;
    } else {
      str = "unknown";
    } 
    this.product = str;
    if (this.sdkVersion != null) {
      str = this.sdkVersion;
    } else {
      str = "unspecified";
    } 
    this.sdkVersion = str;
  }
  
  protected ApsalarSessionInfo(JSONObject paramJSONObject, String paramString1, String paramString2) {
    this.sessionStart = 0L;
    this.sdkVersion = "6.1.5";
    ApSingleton apSingleton = ApSingleton.getInstance(ApSingleton.getContext());
    try {
      this.apiKey = paramString1;
      this.secret = paramString2;
      if (paramJSONObject.has("abi")) {
        paramString1 = paramJSONObject.getString("abi");
      } else {
        paramString1 = "unknown";
      } 
      this.abi = paramString1;
      if (paramJSONObject.has("platform")) {
        paramString1 = paramJSONObject.getString("platform");
      } else {
        paramString1 = "Android";
      } 
      this.platform = paramString1;
      if (paramJSONObject.has("clsPackage")) {
        paramString1 = paramJSONObject.getString("clsPackage");
      } else {
        paramString1 = "unknown";
      } 
      this.clsPackage = paramString1;
      if (paramJSONObject.has("appVersion")) {
        paramString1 = paramJSONObject.getString("appVersion");
      } else {
        paramString1 = "unknown";
      } 
      this.appVersion = paramString1;
      if (paramJSONObject.has("deviceId")) {
        paramString1 = paramJSONObject.getString("deviceId");
      } else {
        paramString1 = "unspecified";
      } 
      this.deviceId = paramString1;
      if (paramJSONObject.has("sessionId")) {
        paramString1 = paramJSONObject.getString("sessionId");
      } else {
        paramString1 = "unspecified";
      } 
      this.sessionId = paramString1;
      if (paramJSONObject.has("retType")) {
        paramString1 = paramJSONObject.getString("retType");
      } else {
        paramString1 = "json";
      } 
      this.retType = paramString1;
      if (paramJSONObject.has("connType")) {
        paramString1 = paramJSONObject.getString("connType");
      } else {
        paramString1 = "wifi";
      } 
      this.connType = paramString1;
      if (paramJSONObject.has("appName")) {
        paramString1 = paramJSONObject.getString("appName");
      } else {
        paramString1 = "unknown";
      } 
      this.appName = paramString1;
      if (paramJSONObject.has("osVersion")) {
        paramString1 = paramJSONObject.getString("osVersion");
      } else {
        paramString1 = "unknown";
      } 
      this.osVersion = paramString1;
      if (paramJSONObject.has("brand")) {
        paramString1 = paramJSONObject.getString("brand");
      } else {
        paramString1 = "unknown";
      } 
      this.brand = paramString1;
      if (paramJSONObject.has("device")) {
        paramString1 = paramJSONObject.getString("device");
      } else {
        paramString1 = "unknown";
      } 
      this.device = paramString1;
      if (paramJSONObject.has("manufacturer")) {
        paramString1 = paramJSONObject.getString("manufacturer");
      } else {
        paramString1 = "unknown";
      } 
      this.manufacturer = paramString1;
      if (paramJSONObject.has("model")) {
        paramString1 = paramJSONObject.getString("model");
      } else {
        paramString1 = "unknown";
      } 
      this.model = paramString1;
      if (paramJSONObject.has("product")) {
        paramString1 = paramJSONObject.getString("product");
      } else {
        paramString1 = "unknown";
      } 
      this.product = paramString1;
      if (paramJSONObject.has("sdkVersion")) {
        paramString1 = paramJSONObject.getString("sdkVersion");
      } else {
        paramString1 = "unspecified";
      } 
      this.sdkVersion = paramString1;
      this.sessionStart = paramJSONObject.getLong("sessionStart");
    } catch (JSONException jSONException) {
      apSingleton.getClass();
    } 
    apSingleton.getClass();
  }
  
  public JSONObject toJSON() {
    ApSingleton apSingleton = ApSingleton.getInstance(ApSingleton.getContext());
    JSONObject jSONObject = new JSONObject();
    try {
      jSONObject.put("sessionStart", apSingleton.info.sessionStart);
      jSONObject.put("apiKey", apSingleton.info.apiKey);
      jSONObject.put("secret", apSingleton.info.secret);
      jSONObject.put("abi", this.abi);
      jSONObject.put("platform", this.platform);
      jSONObject.put("clsPackage", this.clsPackage);
      jSONObject.put("appVersion", this.appVersion);
      jSONObject.put("deviceId", this.deviceId);
      jSONObject.put("sessionId", this.sessionId);
      jSONObject.put("retType", this.retType);
      jSONObject.put("connType", this.connType);
      jSONObject.put("appName", this.appName);
      jSONObject.put("osVersion", this.osVersion);
      jSONObject.put("brand", this.brand);
      jSONObject.put("device", this.device);
      jSONObject.put("manufacturer", this.manufacturer);
      jSONObject.put("model", this.model);
      jSONObject.put("product", this.product);
      jSONObject.put("sdkVersion", this.sdkVersion);
      return jSONObject;
    } catch (JSONException jSONException) {
      apSingleton.getClass();
      return jSONObject;
    } catch (Exception exception) {
      apSingleton.getClass();
      return jSONObject;
    } 
  }
}


/* Location:              C:\soft\dex2jar-2.0\Smash Cricket-dex2jar.jar!\com\apsalar\sdk\ApsalarSessionInfo.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */