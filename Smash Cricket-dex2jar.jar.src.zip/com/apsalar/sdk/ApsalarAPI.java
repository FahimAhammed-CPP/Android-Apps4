package com.apsalar.sdk;

interface ApsalarAPI {
  public static final String BASEURL = "http://e.apsalar.com/api/v1";
  
  int REST();
  
  String getEventData();
  
  String getEventName();
  
  long getEventTime();
  
  int getEventType();
  
  public static class Status {
    static final int INVALID = -1;
    
    static final int POSTPONE = 0;
    
    static final int SUCCESS = 1;
  }
  
  public static class Type {
    static final int CANONICAL = 6;
    
    static final int EVENT = 3;
    
    static final int HEARTBEAT = 2;
    
    static final int NONE = 0;
    
    static final int RESOLVE = 5;
    
    static final int RETRY = -1;
    
    static final int SESSION = 1;
  }
}


/* Location:              C:\soft\dex2jar-2.0\Smash Cricket-dex2jar.jar!\com\apsalar\sdk\ApsalarAPI.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */