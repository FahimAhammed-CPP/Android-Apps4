package com.apsalar.sdk;

import android.database.Cursor;

public class EventMonitor {
  static String TAG = "Apsalar EventMonitor";
  
  static long anyEvent;
  
  static long endEvent;
  
  static long eventQ_count = 0L;
  
  static long eventsFileQ_count;
  
  static long facebookEvent;
  
  static long installEvent;
  
  static long sqliteQ_count = 0L;
  
  static long startEvent;
  
  static {
    eventsFileQ_count = 0L;
    startEvent = 0L;
    facebookEvent = 0L;
    installEvent = 0L;
    anyEvent = 0L;
    endEvent = 0L;
  }
  
  public static long countEventQ() {
    ApSingleton.getInstance(ApSingleton.getContext());
    if (ApSingleton.apsalar_thread != null) {
      eventQ_count = ApSingleton.eventConsumerThread.eventQueue.size();
      return eventQ_count;
    } 
    eventQ_count = 0L;
    return eventQ_count;
  }
  
  public static long countSQLiteQ() {
    ApSingleton apSingleton = ApSingleton.getInstance(ApSingleton.getContext());
    Cursor cursor3 = null;
    Cursor cursor4 = null;
    Cursor cursor2 = null;
    if (apSingleton.hash == null) {
      apSingleton.getClass();
      sqliteQ_count = 0L;
      return sqliteQ_count;
    } 
    null = cursor3;
    Cursor cursor1 = cursor4;
    try {
      if (apSingleton.database != null) {
        null = cursor3;
        cursor1 = cursor4;
        cursor2 = apSingleton.database.rawQuery("select count(*) from events;", null);
        if (cursor2 != null) {
          null = cursor2;
          cursor1 = cursor2;
          cursor2.moveToFirst();
          null = cursor2;
          cursor1 = cursor2;
          sqliteQ_count = cursor2.getLong(0);
        } else {
          null = cursor2;
          cursor1 = cursor2;
          sqliteQ_count = 0L;
        } 
      } else {
        null = cursor3;
        cursor1 = cursor4;
        apSingleton.getClass();
        null = cursor3;
        cursor1 = cursor4;
        sqliteQ_count = 0L;
      } 
      return sqliteQ_count;
    } catch (Exception exception) {
      cursor1 = null;
      apSingleton.getClass();
      cursor1 = null;
      apSingleton.incrExceptionCount();
      return sqliteQ_count;
    } finally {
      if (cursor1 != null)
        cursor1.close(); 
    } 
  }
  
  public static long getBootstrap_count() {
    return ApSingleton.getInstance(ApSingleton.getContext()).getBootstrapCount();
  }
  
  public static long getDropEvent_count() {
    return ApSingleton.getInstance(ApSingleton.getContext()).getDropEventsCount();
  }
  
  public static long getException_count() {
    return ApSingleton.getInstance(ApSingleton.getContext()).getExceptionCount();
  }
  
  public static long getLastEndEvent() {
    return endEvent;
  }
  
  public static long getLastEvent() {
    return anyEvent;
  }
  
  public static long getLastEventQ_count() {
    return eventQ_count;
  }
  
  public static long getLastEventsFile_count() {
    return eventsFileQ_count;
  }
  
  public static long getLastFacebookInstall() {
    return facebookEvent;
  }
  
  public static long getLastInstall() {
    return installEvent;
  }
  
  public static long getLastSqliteQ_count() {
    return sqliteQ_count;
  }
  
  public static long getLastStartEvent() {
    return startEvent;
  }
  
  public static long getNetworkError_count() {
    return ApSingleton.getInstance(ApSingleton.getContext()).getNetworkErrorCount();
  }
  
  public static long getSentEvents_count() {
    return ApSingleton.getInstance(ApSingleton.getContext()).getSentEventsCount();
  }
  
  public static void markEnd() {
    endEvent = System.currentTimeMillis();
  }
  
  public static void markEvent() {
    anyEvent = System.currentTimeMillis();
  }
  
  public static void markFacebook() {
    facebookEvent = System.currentTimeMillis();
  }
  
  public static void markINSTALL_REFERRER() {
    installEvent = System.currentTimeMillis();
  }
  
  public static void markStart() {
    startEvent = System.currentTimeMillis();
  }
}


/* Location:              C:\soft\dex2jar-2.0\Smash Cricket-dex2jar.jar!\com\apsalar\sdk\EventMonitor.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */