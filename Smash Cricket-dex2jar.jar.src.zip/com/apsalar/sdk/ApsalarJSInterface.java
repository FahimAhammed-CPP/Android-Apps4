package com.apsalar.sdk;

import android.content.Context;
import android.webkit.JavascriptInterface;
import org.json.JSONException;
import org.json.JSONObject;

public class ApsalarJSInterface {
  final String TAG = "ApsalarJSInterface";
  
  Context mContext;
  
  int webViewId;
  
  public ApsalarJSInterface(Context paramContext) {
    ApSingleton.getInstance(paramContext).getClass();
    this.mContext = paramContext;
  }
  
  @JavascriptInterface
  public void endSession() {
    ApSingleton.getInstance(ApSingleton.getContext()).getClass();
    Apsalar.endSession();
  }
  
  @JavascriptInterface
  public void event(String paramString) {
    ApSingleton.getInstance(ApSingleton.getContext()).getClass();
    Apsalar.event(paramString);
  }
  
  @JavascriptInterface
  public void event(String paramString1, String paramString2) throws JSONException {
    ApSingleton.getInstance(ApSingleton.getContext()).getClass();
    Apsalar.event(paramString1, new JSONObject(paramString2));
  }
  
  @JavascriptInterface
  public void setWebViewId(int paramInt) {
    ApSingleton.getInstance(ApSingleton.getContext()).getClass();
    this.webViewId = paramInt;
  }
}


/* Location:              C:\soft\dex2jar-2.0\Smash Cricket-dex2jar.jar!\com\apsalar\sdk\ApsalarJSInterface.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */