package com.apsalar.sdk;

import org.json.JSONObject;

interface ApsalarJSON {
  JSONObject toJSON();
}


/* Location:              C:\soft\dex2jar-2.0\Smash Cricket-dex2jar.jar!\com\apsalar\sdk\ApsalarJSON.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */