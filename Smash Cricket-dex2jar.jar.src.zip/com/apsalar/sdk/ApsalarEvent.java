package com.apsalar.sdk;

import android.content.Context;
import java.io.IOException;
import java.io.UnsupportedEncodingException;
import java.net.ProtocolException;
import java.net.SocketTimeoutException;
import java.net.URLEncoder;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import org.json.JSONException;
import org.json.JSONObject;

class ApsalarEvent implements ApsalarAPI, ApsalarJSON {
  static final String TAG = "Apsalar SDK/Event";
  
  Context ctx = null;
  
  protected String eventData = "";
  
  protected String eventName = "";
  
  protected long eventTime = System.currentTimeMillis();
  
  protected int eventType = 0;
  
  protected ApsalarSessionInfo info = null;
  
  protected String old_k;
  
  protected String old_u;
  
  protected String returnData = null;
  
  protected JSONObject returnDataJSON = null;
  
  protected String url = "";
  
  protected String urlbase = "http://e.apsalar.com/api/v1/event";
  
  protected ApsalarEvent(Context paramContext) {
    init(paramContext);
  }
  
  protected ApsalarEvent(Context paramContext, ApsalarSessionInfo paramApsalarSessionInfo) {
    ApSingleton apSingleton = ApSingleton.getInstance(paramContext);
    init(paramContext);
    this.info = paramApsalarSessionInfo;
    if (this.info == null)
      apSingleton.getClass(); 
  }
  
  protected ApsalarEvent(Context paramContext, ApsalarSessionInfo paramApsalarSessionInfo, String paramString) {
    ApSingleton apSingleton = ApSingleton.getInstance(paramContext);
    init(paramContext);
    this.info = paramApsalarSessionInfo;
    this.eventName = paramString;
    if (this.info == null)
      apSingleton.getClass(); 
  }
  
  protected ApsalarEvent(Context paramContext, ApsalarSessionInfo paramApsalarSessionInfo, String paramString1, long paramLong, String paramString2) {
    ApSingleton apSingleton = ApSingleton.getInstance(paramContext);
    init(paramContext);
    this.info = paramApsalarSessionInfo;
    this.eventName = paramString1;
    this.eventData = paramString2;
    if (this.info == null)
      apSingleton.getClass(); 
    if (paramLong != 0L)
      this.eventTime = paramLong; 
  }
  
  protected ApsalarEvent(Context paramContext, ApsalarSessionInfo paramApsalarSessionInfo, String paramString1, String paramString2) {
    ApSingleton apSingleton = ApSingleton.getInstance(paramContext);
    init(paramContext);
    this.info = paramApsalarSessionInfo;
    this.eventName = paramString1;
    this.eventData = paramString2;
    if (this.info == null)
      apSingleton.getClass(); 
  }
  
  protected ApsalarEvent(Context paramContext, ApsalarSessionInfo paramApsalarSessionInfo, JSONObject paramJSONObject) {
    ApSingleton apSingleton = ApSingleton.getInstance(paramContext);
    init(paramContext);
    this.info = paramApsalarSessionInfo;
    if (this.info == null)
      apSingleton.getClass(); 
    try {
      this.eventType = paramJSONObject.getInt("eventType");
      this.eventTime = paramJSONObject.getLong("eventTime");
      this.eventName = paramJSONObject.getString("eventName");
      this.eventData = paramJSONObject.getString("eventData");
      return;
    } catch (JSONException jSONException) {
      apSingleton.getClass();
      apSingleton.incrExceptionCount();
      return;
    } 
  }
  
  public int REST() {
    return REST(Boolean.valueOf(true));
  }
  
  public int REST(Boolean paramBoolean) {
    ApSingleton apSingleton = ApSingleton.getInstance(this.ctx);
    apSingleton.getClass();
    if (!makeURL()) {
      apSingleton.getClass();
      return -1;
    } 
    String str1 = this.url + "&lag=" + lagSeconds();
    String str2 = makeHash(this.info.secret, str1);
    if (str2 != null) {
      str1 = this.urlbase + str1 + "&h=" + str2;
      try {
        this.returnData = ApsalarHttpClient.get(str1);
        if (this.returnData == null)
          return 1; 
      } catch (ProtocolException null) {
        apSingleton.getClass();
        apSingleton.incrExceptionCount();
        return 0;
      } catch (SocketTimeoutException null) {
        apSingleton.getClass();
        apSingleton.incrNetworkErrorCount();
        apSingleton.incrExceptionCount();
        return 0;
      } catch (IOException iOException) {
        apSingleton.getClass();
        apSingleton.incrNetworkErrorCount();
        apSingleton.incrExceptionCount();
        return 0;
      } 
      apSingleton.incrSentEventsCount();
      if (!iOException.booleanValue())
        return 1; 
      try {
        this.returnDataJSON = new JSONObject(this.returnData);
        try {
          String str = this.returnDataJSON.getString("status").toLowerCase();
          if (!str.equals("ok")) {
            apSingleton.getClass();
            return 0;
          } 
        } catch (JSONException jSONException) {
          apSingleton.incrExceptionCount();
        } 
      } catch (JSONException jSONException) {
        apSingleton.incrExceptionCount();
        apSingleton.getClass();
        return 0;
      } 
      if (this.eventType == 1)
        return ApsalarSession.handleRedirect(this.returnDataJSON); 
      apSingleton.getClass();
      return 0;
    } 
    return -1;
  }
  
  public boolean changeDeviceKeys(String paramString1, String paramString2, String paramString3, String paramString4, boolean paramBoolean) {
    boolean bool2;
    ApSingleton apSingleton = ApSingleton.getInstance(this.ctx);
    apSingleton.getClass();
    boolean bool1 = false;
    if (!paramString3.equals(paramString1)) {
      apSingleton.getClass();
      bool1 = true;
    } 
    if (!paramString4.equals(paramString2)) {
      apSingleton.getClass();
      bool2 = true;
    } else {
      bool2 = bool1;
      if (bool1) {
        apSingleton.getClass();
        bool2 = false;
      } 
    } 
    if (bool2) {
      apSingleton.getClass();
      if (paramString1.equals("ANDI")) {
        apSingleton.resolved_ANDI = true;
        apSingleton.ANDI = paramString2;
        apSingleton.getClass();
      } else if (paramString1.equals("AIFA")) {
        apSingleton.resolved_AIFA = true;
        apSingleton.old_AIFA = apSingleton.AIFA;
        apSingleton.AIFA = paramString2;
        apSingleton.AIFA_changed = true;
        apSingleton.getClass();
      } 
      if ((!paramBoolean && !apSingleton.canonicalKeyspace.equals(paramString1)) || !apSingleton.canonicalDeviceId.equals(paramString2)) {
        apSingleton.canonicalKeyspace = paramString1;
        apSingleton.canonicalDeviceId = paramString2;
        apSingleton.getClass();
      } 
    } 
    return bool2;
  }
  
  void constructDK() {
    // Byte code:
    //   0: aload_0
    //   1: getfield ctx : Landroid/content/Context;
    //   4: invokestatic getInstance : (Landroid/content/Context;)Lcom/apsalar/sdk/ApSingleton;
    //   7: astore #27
    //   9: aload #27
    //   11: invokevirtual getClass : ()Ljava/lang/Class;
    //   14: pop
    //   15: iconst_0
    //   16: istore #10
    //   18: aload #27
    //   20: getfield desired : Lorg/json/JSONArray;
    //   23: ifnull -> 36
    //   26: aload #27
    //   28: getfield desired : Lorg/json/JSONArray;
    //   31: invokevirtual length : ()I
    //   34: istore #10
    //   36: ldc ''
    //   38: astore #21
    //   40: aconst_null
    //   41: astore #25
    //   43: aconst_null
    //   44: astore #23
    //   46: iconst_0
    //   47: istore_1
    //   48: aload #21
    //   50: astore #24
    //   52: iload_1
    //   53: istore #11
    //   55: aload #25
    //   57: astore #22
    //   59: aload #27
    //   61: getfield AIFA_changed : Z
    //   64: ifeq -> 146
    //   67: aload #21
    //   69: astore #24
    //   71: iload_1
    //   72: istore #11
    //   74: aload #25
    //   76: astore #22
    //   78: aload #27
    //   80: getfield old_AIFA : Ljava/lang/String;
    //   83: aload #27
    //   85: getfield AIFA : Ljava/lang/String;
    //   88: invokevirtual equals : (Ljava/lang/Object;)Z
    //   91: ifne -> 146
    //   94: aload #27
    //   96: invokevirtual getClass : ()Ljava/lang/Class;
    //   99: pop
    //   100: aload #27
    //   102: getfield canonicalKeyspace : Ljava/lang/String;
    //   105: ldc 'AIFA'
    //   107: invokevirtual equals : (Ljava/lang/Object;)Z
    //   110: ifeq -> 264
    //   113: aload #27
    //   115: getfield AIFA : Ljava/lang/String;
    //   118: aload #27
    //   120: getfield canonicalDeviceId : Ljava/lang/String;
    //   123: invokevirtual equals : (Ljava/lang/Object;)Z
    //   126: ifeq -> 264
    //   129: aload #27
    //   131: invokevirtual getClass : ()Ljava/lang/Class;
    //   134: pop
    //   135: aload #23
    //   137: astore #22
    //   139: iconst_1
    //   140: istore #11
    //   142: aload #21
    //   144: astore #24
    //   146: aload #27
    //   148: invokevirtual getClass : ()Ljava/lang/Class;
    //   151: pop
    //   152: aload #27
    //   154: getfield RESOLVE_ALL_AVAILABLE : Z
    //   157: ifeq -> 320
    //   160: iconst_4
    //   161: istore #6
    //   163: iconst_0
    //   164: istore #5
    //   166: iconst_0
    //   167: istore #4
    //   169: iconst_0
    //   170: istore_2
    //   171: iconst_0
    //   172: istore_1
    //   173: iconst_0
    //   174: istore_3
    //   175: iconst_0
    //   176: istore #12
    //   178: iload #6
    //   180: istore #13
    //   182: iload #12
    //   184: iload #10
    //   186: iload #13
    //   188: iadd
    //   189: if_icmpgt -> 806
    //   192: iload #12
    //   194: iload #10
    //   196: iconst_4
    //   197: iadd
    //   198: if_icmpne -> 548
    //   201: iload_3
    //   202: ifeq -> 326
    //   205: iload_1
    //   206: istore #19
    //   208: iload_2
    //   209: istore #18
    //   211: iload_3
    //   212: istore #17
    //   214: iload #4
    //   216: istore #16
    //   218: iload #5
    //   220: istore #15
    //   222: iload #13
    //   224: istore #14
    //   226: aload #22
    //   228: astore #25
    //   230: iload #12
    //   232: iconst_1
    //   233: iadd
    //   234: istore #12
    //   236: aload #25
    //   238: astore #22
    //   240: iload #14
    //   242: istore #13
    //   244: iload #15
    //   246: istore #5
    //   248: iload #16
    //   250: istore #4
    //   252: iload #17
    //   254: istore_3
    //   255: iload #18
    //   257: istore_2
    //   258: iload #19
    //   260: istore_1
    //   261: goto -> 182
    //   264: new java/lang/StringBuilder
    //   267: dup
    //   268: invokespecial <init> : ()V
    //   271: ldc '[{"k":"'
    //   273: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   276: ldc 'AIFA'
    //   278: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   281: ldc '", "v":"'
    //   283: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   286: aload #27
    //   288: getfield old_AIFA : Ljava/lang/String;
    //   291: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   294: ldc '"},'
    //   296: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   299: invokevirtual toString : ()Ljava/lang/String;
    //   302: astore #22
    //   304: aload #27
    //   306: invokevirtual getClass : ()Ljava/lang/Class;
    //   309: pop
    //   310: aload #27
    //   312: getfield old_AIFA : Ljava/lang/String;
    //   315: astore #21
    //   317: goto -> 139
    //   320: iconst_0
    //   321: istore #6
    //   323: goto -> 163
    //   326: ldc 'BMAC'
    //   328: astore #21
    //   330: iload_1
    //   331: istore #9
    //   333: iload_2
    //   334: istore #8
    //   336: iload_3
    //   337: istore #7
    //   339: iload #4
    //   341: istore #6
    //   343: aload #21
    //   345: invokestatic getDeviceId : (Ljava/lang/String;)Ljava/lang/String;
    //   348: astore #25
    //   350: aload #27
    //   352: getfield canonicalKeyspace : Ljava/lang/String;
    //   355: astore #26
    //   357: aload #21
    //   359: ldc 'AIFA'
    //   361: invokevirtual equals : (Ljava/lang/Object;)Z
    //   364: ifeq -> 982
    //   367: aload #27
    //   369: getfield AIFA : Ljava/lang/String;
    //   372: ifnull -> 974
    //   375: aload #27
    //   377: getfield AIFA : Ljava/lang/String;
    //   380: astore #23
    //   382: ldc 'AIFA'
    //   384: astore #26
    //   386: aload #27
    //   388: invokevirtual getClass : ()Ljava/lang/Class;
    //   391: pop
    //   392: aload #22
    //   394: astore #25
    //   396: iload #13
    //   398: istore #14
    //   400: iload #5
    //   402: istore #15
    //   404: iload #6
    //   406: istore #16
    //   408: iload #7
    //   410: istore #17
    //   412: iload #8
    //   414: istore #18
    //   416: iload #9
    //   418: istore #19
    //   420: aload #23
    //   422: invokevirtual length : ()I
    //   425: ifeq -> 230
    //   428: aload #22
    //   430: astore #25
    //   432: iload #13
    //   434: istore #14
    //   436: iload #5
    //   438: istore #15
    //   440: iload #6
    //   442: istore #16
    //   444: iload #7
    //   446: istore #17
    //   448: iload #8
    //   450: istore #18
    //   452: iload #9
    //   454: istore #19
    //   456: aload #23
    //   458: ldc 'None'
    //   460: invokevirtual equals : (Ljava/lang/Object;)Z
    //   463: ifne -> 230
    //   466: iload #11
    //   468: ifeq -> 497
    //   471: aload #23
    //   473: aload #27
    //   475: getfield AIFA : Ljava/lang/String;
    //   478: invokevirtual equals : (Ljava/lang/Object;)Z
    //   481: ifeq -> 497
    //   484: aload #23
    //   486: aload #27
    //   488: getfield canonicalDeviceId : Ljava/lang/String;
    //   491: invokevirtual equals : (Ljava/lang/Object;)Z
    //   494: ifne -> 511
    //   497: aload #23
    //   499: astore #25
    //   501: aload #24
    //   503: aload #23
    //   505: invokevirtual equals : (Ljava/lang/Object;)Z
    //   508: ifeq -> 982
    //   511: aload #27
    //   513: invokevirtual getClass : ()Ljava/lang/Class;
    //   516: pop
    //   517: aload #22
    //   519: astore #25
    //   521: iload #13
    //   523: istore #14
    //   525: iload #5
    //   527: istore #15
    //   529: iload #6
    //   531: istore #16
    //   533: iload #7
    //   535: istore #17
    //   537: iload #8
    //   539: istore #18
    //   541: iload #9
    //   543: istore #19
    //   545: goto -> 230
    //   548: iload #12
    //   550: iload #10
    //   552: iconst_3
    //   553: iadd
    //   554: if_icmpne -> 1386
    //   557: aload #22
    //   559: astore #25
    //   561: iload #13
    //   563: istore #14
    //   565: iload #5
    //   567: istore #15
    //   569: iload #4
    //   571: istore #16
    //   573: iload_3
    //   574: istore #17
    //   576: iload_2
    //   577: istore #18
    //   579: iload_1
    //   580: istore #19
    //   582: iload_1
    //   583: ifne -> 230
    //   586: ldc 'MAC1'
    //   588: astore #21
    //   590: iload #4
    //   592: istore #6
    //   594: iload_3
    //   595: istore #7
    //   597: iload_2
    //   598: istore #8
    //   600: iload_1
    //   601: istore #9
    //   603: goto -> 343
    //   606: aload #27
    //   608: getfield desired : Lorg/json/JSONArray;
    //   611: iload #12
    //   613: invokevirtual getString : (I)Ljava/lang/String;
    //   616: astore #23
    //   618: aload #23
    //   620: ldc 'BMAC'
    //   622: invokevirtual equals : (Ljava/lang/Object;)Z
    //   625: ifeq -> 648
    //   628: iconst_1
    //   629: istore #7
    //   631: iload #4
    //   633: istore #6
    //   635: iload_2
    //   636: istore #8
    //   638: iload_1
    //   639: istore #9
    //   641: aload #23
    //   643: astore #21
    //   645: goto -> 343
    //   648: aload #23
    //   650: ldc 'MAC1'
    //   652: invokevirtual equals : (Ljava/lang/Object;)Z
    //   655: ifeq -> 678
    //   658: iconst_1
    //   659: istore #9
    //   661: iload #4
    //   663: istore #6
    //   665: iload_3
    //   666: istore #7
    //   668: iload_2
    //   669: istore #8
    //   671: aload #23
    //   673: astore #21
    //   675: goto -> 343
    //   678: aload #23
    //   680: ldc_w 'IMEI'
    //   683: invokevirtual equals : (Ljava/lang/Object;)Z
    //   686: ifeq -> 709
    //   689: iconst_1
    //   690: istore #8
    //   692: iload #4
    //   694: istore #6
    //   696: iload_3
    //   697: istore #7
    //   699: iload_1
    //   700: istore #9
    //   702: aload #23
    //   704: astore #21
    //   706: goto -> 343
    //   709: aload #23
    //   711: ldc 'ANDI'
    //   713: invokevirtual equals : (Ljava/lang/Object;)Z
    //   716: ifeq -> 738
    //   719: iconst_1
    //   720: istore #6
    //   722: iload_3
    //   723: istore #7
    //   725: iload_2
    //   726: istore #8
    //   728: iload_1
    //   729: istore #9
    //   731: aload #23
    //   733: astore #21
    //   735: goto -> 343
    //   738: aload #23
    //   740: ldc 'AIFA'
    //   742: invokevirtual equals : (Ljava/lang/Object;)Z
    //   745: istore #20
    //   747: iload #4
    //   749: istore #6
    //   751: iload_3
    //   752: istore #7
    //   754: iload_2
    //   755: istore #8
    //   757: iload_1
    //   758: istore #9
    //   760: aload #23
    //   762: astore #21
    //   764: iload #20
    //   766: ifeq -> 343
    //   769: iconst_1
    //   770: istore #5
    //   772: iload #4
    //   774: istore #6
    //   776: iload_3
    //   777: istore #7
    //   779: iload_2
    //   780: istore #8
    //   782: iload_1
    //   783: istore #9
    //   785: aload #23
    //   787: astore #21
    //   789: goto -> 343
    //   792: astore #21
    //   794: aload #27
    //   796: invokevirtual incrExceptionCount : ()I
    //   799: pop
    //   800: aload #27
    //   802: invokevirtual getClass : ()Ljava/lang/Class;
    //   805: pop
    //   806: aload #27
    //   808: invokevirtual getClass : ()Ljava/lang/Class;
    //   811: pop
    //   812: aload #22
    //   814: astore #21
    //   816: aload #22
    //   818: ifnull -> 892
    //   821: aload #22
    //   823: astore #21
    //   825: aload #22
    //   827: invokevirtual length : ()I
    //   830: ifeq -> 892
    //   833: aload #22
    //   835: astore #21
    //   837: aload #22
    //   839: aload #22
    //   841: invokevirtual length : ()I
    //   844: iconst_1
    //   845: isub
    //   846: invokevirtual charAt : (I)C
    //   849: bipush #44
    //   851: if_icmpne -> 869
    //   854: aload #22
    //   856: iconst_0
    //   857: aload #22
    //   859: invokevirtual length : ()I
    //   862: iconst_1
    //   863: isub
    //   864: invokevirtual substring : (II)Ljava/lang/String;
    //   867: astore #21
    //   869: new java/lang/StringBuilder
    //   872: dup
    //   873: invokespecial <init> : ()V
    //   876: aload #21
    //   878: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   881: ldc_w ']'
    //   884: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   887: invokevirtual toString : ()Ljava/lang/String;
    //   890: astore #21
    //   892: aload #21
    //   894: astore #22
    //   896: aload #21
    //   898: ifnonnull -> 906
    //   901: ldc_w '[]'
    //   904: astore #22
    //   906: aload #27
    //   908: aload #22
    //   910: putfield dk : Ljava/lang/String;
    //   913: aload #27
    //   915: invokevirtual getClass : ()Ljava/lang/Class;
    //   918: pop
    //   919: aload #27
    //   921: getfield canonicalKeyspace : Ljava/lang/String;
    //   924: ifnull -> 1347
    //   927: aload #27
    //   929: invokevirtual getClass : ()Ljava/lang/Class;
    //   932: pop
    //   933: aload #27
    //   935: aload #27
    //   937: getfield canonicalKeyspace : Ljava/lang/String;
    //   940: invokestatic getDeviceId : (Ljava/lang/String;)Ljava/lang/String;
    //   943: putfield canonicalDeviceId : Ljava/lang/String;
    //   946: aload #27
    //   948: invokevirtual getClass : ()Ljava/lang/Class;
    //   951: pop
    //   952: aload_0
    //   953: getfield info : Lcom/apsalar/sdk/ApsalarSessionInfo;
    //   956: aload #27
    //   958: getfield canonicalDeviceId : Ljava/lang/String;
    //   961: putfield deviceId : Ljava/lang/String;
    //   964: aload #27
    //   966: getfield canonicalKeyspace : Ljava/lang/String;
    //   969: invokestatic setKeySpace : (Ljava/lang/String;)Ljava/lang/String;
    //   972: pop
    //   973: return
    //   974: invokestatic getAIFA : ()Ljava/lang/String;
    //   977: astore #23
    //   979: goto -> 382
    //   982: aload #27
    //   984: invokevirtual getClass : ()Ljava/lang/Class;
    //   987: pop
    //   988: aload #21
    //   990: aload #27
    //   992: getfield canonicalKeyspace : Ljava/lang/String;
    //   995: invokevirtual equals : (Ljava/lang/Object;)Z
    //   998: ifeq -> 1051
    //   1001: aload #25
    //   1003: aload #27
    //   1005: getfield canonicalDeviceId : Ljava/lang/String;
    //   1008: invokevirtual equals : (Ljava/lang/Object;)Z
    //   1011: ifeq -> 1051
    //   1014: aload #27
    //   1016: invokevirtual getClass : ()Ljava/lang/Class;
    //   1019: pop
    //   1020: aload #22
    //   1022: astore #25
    //   1024: iload #13
    //   1026: istore #14
    //   1028: iload #5
    //   1030: istore #15
    //   1032: iload #6
    //   1034: istore #16
    //   1036: iload #7
    //   1038: istore #17
    //   1040: iload #8
    //   1042: istore #18
    //   1044: iload #9
    //   1046: istore #19
    //   1048: goto -> 230
    //   1051: aload #21
    //   1053: aload #26
    //   1055: invokevirtual equals : (Ljava/lang/Object;)Z
    //   1058: ifeq -> 1240
    //   1061: aload #25
    //   1063: ldc 'None'
    //   1065: invokevirtual equals : (Ljava/lang/Object;)Z
    //   1068: ifne -> 1240
    //   1071: aload #27
    //   1073: invokevirtual getClass : ()Ljava/lang/Class;
    //   1076: pop
    //   1077: aload #26
    //   1079: ldc 'AIFA'
    //   1081: invokevirtual equals : (Ljava/lang/Object;)Z
    //   1084: ifeq -> 1150
    //   1087: aload #27
    //   1089: getfield canonicalKeyspace : Ljava/lang/String;
    //   1092: ldc 'AIFA'
    //   1094: invokevirtual equals : (Ljava/lang/Object;)Z
    //   1097: ifeq -> 1150
    //   1100: aload #25
    //   1102: aload #27
    //   1104: getfield canonicalDeviceId : Ljava/lang/String;
    //   1107: invokevirtual equals : (Ljava/lang/Object;)Z
    //   1110: ifeq -> 1150
    //   1113: aload #27
    //   1115: invokevirtual getClass : ()Ljava/lang/Class;
    //   1118: pop
    //   1119: aload #22
    //   1121: astore #25
    //   1123: iload #13
    //   1125: istore #14
    //   1127: iload #5
    //   1129: istore #15
    //   1131: iload #6
    //   1133: istore #16
    //   1135: iload #7
    //   1137: istore #17
    //   1139: iload #8
    //   1141: istore #18
    //   1143: iload #9
    //   1145: istore #19
    //   1147: goto -> 230
    //   1150: aload #22
    //   1152: astore #21
    //   1154: aload #22
    //   1156: ifnonnull -> 1164
    //   1159: ldc_w '['
    //   1162: astore #21
    //   1164: new java/lang/StringBuilder
    //   1167: dup
    //   1168: invokespecial <init> : ()V
    //   1171: aload #21
    //   1173: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   1176: ldc_w '{"k":"'
    //   1179: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   1182: aload #26
    //   1184: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   1187: ldc '", "v":"'
    //   1189: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   1192: aload #25
    //   1194: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   1197: ldc '"},'
    //   1199: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   1202: invokevirtual toString : ()Ljava/lang/String;
    //   1205: astore #25
    //   1207: aload #27
    //   1209: invokevirtual getClass : ()Ljava/lang/Class;
    //   1212: pop
    //   1213: iload #13
    //   1215: istore #14
    //   1217: iload #5
    //   1219: istore #15
    //   1221: iload #6
    //   1223: istore #16
    //   1225: iload #7
    //   1227: istore #17
    //   1229: iload #8
    //   1231: istore #18
    //   1233: iload #9
    //   1235: istore #19
    //   1237: goto -> 230
    //   1240: aload #27
    //   1242: invokevirtual getClass : ()Ljava/lang/Class;
    //   1245: pop
    //   1246: aload #22
    //   1248: astore #25
    //   1250: iload #13
    //   1252: istore #14
    //   1254: iload #5
    //   1256: istore #15
    //   1258: iload #6
    //   1260: istore #16
    //   1262: iload #7
    //   1264: istore #17
    //   1266: iload #8
    //   1268: istore #18
    //   1270: iload #9
    //   1272: istore #19
    //   1274: aload #21
    //   1276: ldc 'AIFA'
    //   1278: invokevirtual equals : (Ljava/lang/Object;)Z
    //   1281: ifeq -> 230
    //   1284: aload #22
    //   1286: astore #25
    //   1288: iload #13
    //   1290: istore #14
    //   1292: iload #5
    //   1294: istore #15
    //   1296: iload #6
    //   1298: istore #16
    //   1300: iload #7
    //   1302: istore #17
    //   1304: iload #8
    //   1306: istore #18
    //   1308: iload #9
    //   1310: istore #19
    //   1312: iload #13
    //   1314: ifne -> 230
    //   1317: iconst_1
    //   1318: istore #14
    //   1320: aload #22
    //   1322: astore #25
    //   1324: iload #5
    //   1326: istore #15
    //   1328: iload #6
    //   1330: istore #16
    //   1332: iload #7
    //   1334: istore #17
    //   1336: iload #8
    //   1338: istore #18
    //   1340: iload #9
    //   1342: istore #19
    //   1344: goto -> 230
    //   1347: aload #27
    //   1349: ldc 'ANDI'
    //   1351: invokestatic getDeviceId : (Ljava/lang/String;)Ljava/lang/String;
    //   1354: putfield canonicalDeviceId : Ljava/lang/String;
    //   1357: aload #27
    //   1359: ldc 'ANDI'
    //   1361: putfield canonicalKeyspace : Ljava/lang/String;
    //   1364: aload #27
    //   1366: getfield info : Lcom/apsalar/sdk/ApsalarSessionInfo;
    //   1369: aload #27
    //   1371: getfield canonicalDeviceId : Ljava/lang/String;
    //   1374: putfield deviceId : Ljava/lang/String;
    //   1377: aload #27
    //   1379: invokevirtual getClass : ()Ljava/lang/Class;
    //   1382: pop
    //   1383: goto -> 946
    //   1386: iload #12
    //   1388: iload #10
    //   1390: iconst_2
    //   1391: iadd
    //   1392: if_icmpne -> 1445
    //   1395: aload #22
    //   1397: astore #25
    //   1399: iload #13
    //   1401: istore #14
    //   1403: iload #5
    //   1405: istore #15
    //   1407: iload #4
    //   1409: istore #16
    //   1411: iload_3
    //   1412: istore #17
    //   1414: iload_2
    //   1415: istore #18
    //   1417: iload_1
    //   1418: istore #19
    //   1420: iload_2
    //   1421: ifne -> 230
    //   1424: ldc_w 'IMEI'
    //   1427: astore #21
    //   1429: iload #4
    //   1431: istore #6
    //   1433: iload_3
    //   1434: istore #7
    //   1436: iload_2
    //   1437: istore #8
    //   1439: iload_1
    //   1440: istore #9
    //   1442: goto -> 343
    //   1445: iload #12
    //   1447: iload #10
    //   1449: iconst_1
    //   1450: iadd
    //   1451: if_icmpne -> 1504
    //   1454: aload #22
    //   1456: astore #25
    //   1458: iload #13
    //   1460: istore #14
    //   1462: iload #5
    //   1464: istore #15
    //   1466: iload #4
    //   1468: istore #16
    //   1470: iload_3
    //   1471: istore #17
    //   1473: iload_2
    //   1474: istore #18
    //   1476: iload_1
    //   1477: istore #19
    //   1479: iload #4
    //   1481: ifne -> 230
    //   1484: ldc 'ANDI'
    //   1486: astore #21
    //   1488: iload #4
    //   1490: istore #6
    //   1492: iload_3
    //   1493: istore #7
    //   1495: iload_2
    //   1496: istore #8
    //   1498: iload_1
    //   1499: istore #9
    //   1501: goto -> 343
    //   1504: iload #12
    //   1506: iload #10
    //   1508: if_icmpne -> 606
    //   1511: aload #22
    //   1513: astore #25
    //   1515: iload #13
    //   1517: istore #14
    //   1519: iload #5
    //   1521: istore #15
    //   1523: iload #4
    //   1525: istore #16
    //   1527: iload_3
    //   1528: istore #17
    //   1530: iload_2
    //   1531: istore #18
    //   1533: iload_1
    //   1534: istore #19
    //   1536: iload #5
    //   1538: ifne -> 230
    //   1541: ldc 'AIFA'
    //   1543: astore #21
    //   1545: iload #4
    //   1547: istore #6
    //   1549: iload_3
    //   1550: istore #7
    //   1552: iload_2
    //   1553: istore #8
    //   1555: iload_1
    //   1556: istore #9
    //   1558: goto -> 343
    // Exception table:
    //   from	to	target	type
    //   606	628	792	org/json/JSONException
    //   648	658	792	org/json/JSONException
    //   678	689	792	org/json/JSONException
    //   709	719	792	org/json/JSONException
    //   738	747	792	org/json/JSONException
  }
  
  public String getEventData() {
    return this.eventData;
  }
  
  public String getEventName() {
    return this.eventName;
  }
  
  public long getEventTime() {
    return this.eventTime;
  }
  
  public int getEventType() {
    return this.eventType;
  }
  
  public ApsalarSessionInfo getInfo() {
    return this.info;
  }
  
  protected void init(Context paramContext) {
    this.ctx = paramContext;
    this.eventType = 3;
    this.eventTime = System.currentTimeMillis();
  }
  
  protected double lagSeconds() {
    return (System.currentTimeMillis() - this.eventTime) * 0.001D;
  }
  
  protected String makeHash(String paramString1, String paramString2) {
    ApSingleton apSingleton = ApSingleton.getInstance(this.ctx);
    try {
      MessageDigest messageDigest = MessageDigest.getInstance("SHA-1");
      messageDigest.update(paramString1.getBytes("UTF-8"));
      messageDigest.update(paramString2.getBytes("UTF-8"));
      return Apsalar.hexDigest(messageDigest.digest());
    } catch (NoSuchAlgorithmException noSuchAlgorithmException) {
      apSingleton.getClass();
      apSingleton.incrExceptionCount();
      return null;
    } catch (UnsupportedEncodingException unsupportedEncodingException) {
      apSingleton.getClass();
      apSingleton.incrExceptionCount();
      return null;
    } 
  }
  
  protected String makeQueryString() {
    ApSingleton apSingleton = ApSingleton.getInstance(this.ctx);
    String str2 = "";
    String str1 = str2;
    try {
      String str3 = Apsalar.getDeviceId(apSingleton.canonicalKeyspace);
      str1 = str2;
      String str4 = apSingleton.canonicalKeyspace;
      str1 = str2;
      str2 = "?a=" + URLEncoder.encode(this.info.apiKey, "UTF-8") + "&av=" + URLEncoder.encode(this.info.appVersion, "UTF-8") + "&e=" + URLEncoder.encode(this.eventData, "UTF-8") + "&i=" + URLEncoder.encode(this.info.clsPackage, "UTF-8") + "&n=" + URLEncoder.encode(this.eventName, "UTF-8") + "&p=" + URLEncoder.encode(this.info.platform, "UTF-8") + "&rt=" + URLEncoder.encode(this.info.retType, "UTF-8") + "&s=" + URLEncoder.encode(this.info.sessionId, "UTF-8") + "&sdk=" + URLEncoder.encode("Apsalar/" + this.info.sdkVersion, "UTF-8") + "&t=" + ((this.eventTime - this.info.sessionStart) * 0.001D) + "&u=" + URLEncoder.encode(str3, "UTF-8") + "&k=" + URLEncoder.encode(str4, "UTF-8");
      str1 = str2;
      this.old_k = str4;
      str1 = str2;
      this.old_u = str3;
      return str2;
    } catch (UnsupportedEncodingException unsupportedEncodingException) {
      apSingleton.getClass();
      apSingleton.incrExceptionCount();
      return str1;
    } 
  }
  
  protected boolean makeURL() {
    ApSingleton apSingleton = ApSingleton.getInstance(this.ctx);
    this.url = makeQueryString();
    if (this.url.length() >= 1999) {
      apSingleton.getClass();
      return false;
    } 
    return true;
  }
  
  boolean resolveHelper() {
    // Byte code:
    //   0: aload_0
    //   1: getfield ctx : Landroid/content/Context;
    //   4: invokestatic getInstance : (Landroid/content/Context;)Lcom/apsalar/sdk/ApSingleton;
    //   7: astore #13
    //   9: aload #13
    //   11: invokevirtual getClass : ()Ljava/lang/Class;
    //   14: pop
    //   15: aload #13
    //   17: getfield already_did_SQL : Z
    //   20: ifeq -> 48
    //   23: aload #13
    //   25: invokevirtual getClass : ()Ljava/lang/Class;
    //   28: pop
    //   29: aload_0
    //   30: invokevirtual constructDK : ()V
    //   33: aload #13
    //   35: getfield canonicalDeviceId : Ljava/lang/String;
    //   38: ldc 'None'
    //   40: invokevirtual equals : (Ljava/lang/Object;)Z
    //   43: ifne -> 1091
    //   46: iconst_1
    //   47: ireturn
    //   48: iconst_0
    //   49: istore_1
    //   50: aconst_null
    //   51: astore #12
    //   53: aconst_null
    //   54: astore #8
    //   56: aconst_null
    //   57: astore #11
    //   59: aload #12
    //   61: astore #9
    //   63: aload #8
    //   65: astore #10
    //   67: aload #13
    //   69: invokevirtual getClass : ()Ljava/lang/Class;
    //   72: pop
    //   73: aload #12
    //   75: astore #9
    //   77: aload #8
    //   79: astore #10
    //   81: aload #13
    //   83: aload #13
    //   85: getfield ctx : Landroid/content/Context;
    //   88: invokestatic getSQLWritableDatabase : (Landroid/content/Context;)Landroid/database/sqlite/SQLiteDatabase;
    //   91: putfield database : Landroid/database/sqlite/SQLiteDatabase;
    //   94: aload #12
    //   96: astore #9
    //   98: aload #8
    //   100: astore #10
    //   102: aload #13
    //   104: getfield database : Landroid/database/sqlite/SQLiteDatabase;
    //   107: ifnonnull -> 153
    //   110: aload #12
    //   112: astore #9
    //   114: aload #8
    //   116: astore #10
    //   118: aload #13
    //   120: invokevirtual getClass : ()Ljava/lang/Class;
    //   123: pop
    //   124: aload #12
    //   126: astore #9
    //   128: aload #8
    //   130: astore #10
    //   132: aload_0
    //   133: invokevirtual constructDK : ()V
    //   136: iconst_0
    //   137: ifeq -> 148
    //   140: new java/lang/NullPointerException
    //   143: dup
    //   144: invokespecial <init> : ()V
    //   147: athrow
    //   148: invokestatic closeDatabase : ()V
    //   151: iconst_0
    //   152: ireturn
    //   153: iconst_0
    //   154: istore_2
    //   155: iconst_1
    //   156: istore #5
    //   158: iload #5
    //   160: bipush #6
    //   162: if_icmpgt -> 1015
    //   165: iload_2
    //   166: ifne -> 1015
    //   169: ldc ''
    //   171: astore #8
    //   173: iload #5
    //   175: tableswitch default -> 1093, 1 -> 490, 2 -> 508, 3 -> 1114, 4 -> 1121, 5 -> 1129, 6 -> 1136
    //   212: aload #11
    //   214: astore #9
    //   216: aload #11
    //   218: astore #10
    //   220: new android/content/ContentValues
    //   223: dup
    //   224: invokespecial <init> : ()V
    //   227: astore #12
    //   229: aload #11
    //   231: astore #9
    //   233: aload #11
    //   235: astore #10
    //   237: aload #13
    //   239: getfield database : Landroid/database/sqlite/SQLiteDatabase;
    //   242: ldc_w 'device_keys'
    //   245: aconst_null
    //   246: new java/lang/StringBuilder
    //   249: dup
    //   250: invokespecial <init> : ()V
    //   253: ldc_w 'keyspace=''
    //   256: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   259: aload #8
    //   261: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   264: ldc_w '''
    //   267: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   270: invokevirtual toString : ()Ljava/lang/String;
    //   273: aconst_null
    //   274: aconst_null
    //   275: aconst_null
    //   276: aconst_null
    //   277: aconst_null
    //   278: invokevirtual query : (Ljava/lang/String;[Ljava/lang/String;Ljava/lang/String;[Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)Landroid/database/Cursor;
    //   281: astore #11
    //   283: aload #11
    //   285: astore #9
    //   287: aload #11
    //   289: astore #10
    //   291: aload #11
    //   293: invokeinterface getCount : ()I
    //   298: iconst_1
    //   299: if_icmpge -> 724
    //   302: iconst_0
    //   303: istore #7
    //   305: aload #11
    //   307: astore #9
    //   309: aload #11
    //   311: astore #10
    //   313: aload #8
    //   315: invokestatic getDeviceId : (Ljava/lang/String;)Ljava/lang/String;
    //   318: astore #14
    //   320: iload #7
    //   322: istore #6
    //   324: iload_2
    //   325: istore #4
    //   327: iload_1
    //   328: istore_3
    //   329: aload #14
    //   331: ifnull -> 395
    //   334: iload #7
    //   336: istore #6
    //   338: iload_2
    //   339: istore #4
    //   341: iload_1
    //   342: istore_3
    //   343: aload #11
    //   345: astore #9
    //   347: aload #11
    //   349: astore #10
    //   351: aload #13
    //   353: getfield canonicalKeyspace : Ljava/lang/String;
    //   356: aload #13
    //   358: getfield canonicalKeyspace : Ljava/lang/String;
    //   361: invokevirtual equals : (Ljava/lang/Object;)Z
    //   364: ifeq -> 395
    //   367: iconst_1
    //   368: istore #6
    //   370: iconst_1
    //   371: istore_3
    //   372: aload #11
    //   374: astore #9
    //   376: aload #11
    //   378: astore #10
    //   380: aload #13
    //   382: aload_0
    //   383: getfield info : Lcom/apsalar/sdk/ApsalarSessionInfo;
    //   386: getfield deviceId : Ljava/lang/String;
    //   389: putfield canonicalDeviceId : Ljava/lang/String;
    //   392: iconst_1
    //   393: istore #4
    //   395: aload #11
    //   397: astore #9
    //   399: aload #11
    //   401: astore #10
    //   403: aload #13
    //   405: getfield canonicalKeyspace : Ljava/lang/String;
    //   408: ldc_w 'NONE'
    //   411: invokevirtual equals : (Ljava/lang/Object;)Z
    //   414: ifeq -> 540
    //   417: iload #4
    //   419: istore_2
    //   420: iload_3
    //   421: istore_1
    //   422: aload #11
    //   424: astore #9
    //   426: aload #11
    //   428: astore #10
    //   430: aload #8
    //   432: ldc_w 'NONE'
    //   435: invokevirtual equals : (Ljava/lang/Object;)Z
    //   438: ifne -> 464
    //   441: aload #11
    //   443: astore #9
    //   445: aload #11
    //   447: astore #10
    //   449: aload #14
    //   451: ldc 'None'
    //   453: invokevirtual equals : (Ljava/lang/Object;)Z
    //   456: ifeq -> 558
    //   459: iload_3
    //   460: istore_1
    //   461: iload #4
    //   463: istore_2
    //   464: aload #11
    //   466: astore #9
    //   468: aload #11
    //   470: astore #10
    //   472: aload #11
    //   474: invokeinterface close : ()V
    //   479: aconst_null
    //   480: astore #8
    //   482: iload_2
    //   483: istore_3
    //   484: iload_1
    //   485: istore #4
    //   487: goto -> 1096
    //   490: aload #11
    //   492: astore #9
    //   494: aload #11
    //   496: astore #10
    //   498: aload #13
    //   500: getfield canonicalKeyspace : Ljava/lang/String;
    //   503: astore #8
    //   505: goto -> 212
    //   508: aload #11
    //   510: astore #9
    //   512: aload #11
    //   514: astore #10
    //   516: aload #11
    //   518: astore #8
    //   520: iload_2
    //   521: istore_3
    //   522: iload_1
    //   523: istore #4
    //   525: aload #13
    //   527: getfield playStoreAvailable : Z
    //   530: ifeq -> 1096
    //   533: ldc 'AIFA'
    //   535: astore #8
    //   537: goto -> 212
    //   540: aload #11
    //   542: astore #9
    //   544: aload #11
    //   546: astore #10
    //   548: aload #13
    //   550: getfield canonicalKeyspace : Ljava/lang/String;
    //   553: astore #8
    //   555: goto -> 417
    //   558: aload #11
    //   560: astore #9
    //   562: aload #11
    //   564: astore #10
    //   566: aload #12
    //   568: ldc_w 'keyspace'
    //   571: aload #8
    //   573: invokevirtual put : (Ljava/lang/String;Ljava/lang/String;)V
    //   576: aload #11
    //   578: astore #9
    //   580: aload #11
    //   582: astore #10
    //   584: aload #12
    //   586: ldc_w 'val'
    //   589: aload #14
    //   591: invokevirtual put : (Ljava/lang/String;Ljava/lang/String;)V
    //   594: aload #11
    //   596: astore #9
    //   598: aload #11
    //   600: astore #10
    //   602: aload #12
    //   604: ldc_w 'canonical'
    //   607: iload #6
    //   609: invokestatic valueOf : (I)Ljava/lang/Integer;
    //   612: invokevirtual put : (Ljava/lang/String;Ljava/lang/Integer;)V
    //   615: aload #11
    //   617: astore #9
    //   619: aload #11
    //   621: astore #10
    //   623: aload #13
    //   625: getfield database : Landroid/database/sqlite/SQLiteDatabase;
    //   628: ldc_w 'device_keys'
    //   631: aconst_null
    //   632: aload #12
    //   634: invokevirtual insert : (Ljava/lang/String;Ljava/lang/String;Landroid/content/ContentValues;)J
    //   637: pop2
    //   638: aload #11
    //   640: astore #9
    //   642: aload #11
    //   644: astore #10
    //   646: aload_0
    //   647: getfield info : Lcom/apsalar/sdk/ApsalarSessionInfo;
    //   650: aload #14
    //   652: putfield deviceId : Ljava/lang/String;
    //   655: aload #11
    //   657: astore #9
    //   659: aload #11
    //   661: astore #10
    //   663: aload #13
    //   665: invokevirtual getClass : ()Ljava/lang/Class;
    //   668: pop
    //   669: iload #4
    //   671: istore_2
    //   672: iload_3
    //   673: istore_1
    //   674: goto -> 464
    //   677: astore #8
    //   679: aload #9
    //   681: astore #10
    //   683: aload #13
    //   685: invokevirtual incrExceptionCount : ()I
    //   688: pop
    //   689: aload #9
    //   691: astore #10
    //   693: aload #13
    //   695: invokevirtual getClass : ()Ljava/lang/Class;
    //   698: pop
    //   699: aload #9
    //   701: astore #10
    //   703: aload_0
    //   704: invokevirtual constructDK : ()V
    //   707: aload #9
    //   709: ifnull -> 719
    //   712: aload #9
    //   714: invokeinterface close : ()V
    //   719: invokestatic closeDatabase : ()V
    //   722: iconst_0
    //   723: ireturn
    //   724: aload #11
    //   726: astore #9
    //   728: aload #11
    //   730: astore #10
    //   732: aload #13
    //   734: invokevirtual getClass : ()Ljava/lang/Class;
    //   737: pop
    //   738: aload #11
    //   740: astore #9
    //   742: aload #11
    //   744: astore #10
    //   746: aload #11
    //   748: invokeinterface moveToFirst : ()Z
    //   753: pop
    //   754: iload_1
    //   755: istore_3
    //   756: iload_2
    //   757: istore #4
    //   759: iload #4
    //   761: istore_2
    //   762: iload_3
    //   763: istore_1
    //   764: aload #11
    //   766: astore #9
    //   768: aload #11
    //   770: astore #10
    //   772: aload #11
    //   774: invokeinterface isAfterLast : ()Z
    //   779: ifne -> 464
    //   782: aload #11
    //   784: astore #9
    //   786: aload #11
    //   788: astore #10
    //   790: aload #11
    //   792: iconst_0
    //   793: invokeinterface getString : (I)Ljava/lang/String;
    //   798: astore #8
    //   800: aload #11
    //   802: astore #9
    //   804: aload #11
    //   806: astore #10
    //   808: aload_0
    //   809: getfield info : Lcom/apsalar/sdk/ApsalarSessionInfo;
    //   812: aload #11
    //   814: iconst_1
    //   815: invokeinterface getString : (I)Ljava/lang/String;
    //   820: putfield deviceId : Ljava/lang/String;
    //   823: aload #11
    //   825: astore #9
    //   827: aload #11
    //   829: astore #10
    //   831: aload #8
    //   833: invokestatic setKeySpace : (Ljava/lang/String;)Ljava/lang/String;
    //   836: pop
    //   837: aload #11
    //   839: astore #9
    //   841: aload #11
    //   843: astore #10
    //   845: aload #8
    //   847: ldc 'ANDI'
    //   849: invokevirtual equals : (Ljava/lang/Object;)Z
    //   852: ifeq -> 974
    //   855: aload #11
    //   857: astore #9
    //   859: aload #11
    //   861: astore #10
    //   863: aload #13
    //   865: aload_0
    //   866: getfield info : Lcom/apsalar/sdk/ApsalarSessionInfo;
    //   869: getfield deviceId : Ljava/lang/String;
    //   872: putfield ANDI : Ljava/lang/String;
    //   875: aload #11
    //   877: astore #9
    //   879: aload #11
    //   881: astore #10
    //   883: aload #11
    //   885: iconst_2
    //   886: invokeinterface getShort : (I)S
    //   891: iconst_1
    //   892: if_icmpne -> 921
    //   895: iconst_1
    //   896: istore_3
    //   897: aload #11
    //   899: astore #9
    //   901: aload #11
    //   903: astore #10
    //   905: aload #13
    //   907: aload #13
    //   909: getfield canonicalKeyspace : Ljava/lang/String;
    //   912: invokestatic getDeviceId : (Ljava/lang/String;)Ljava/lang/String;
    //   915: putfield canonicalDeviceId : Ljava/lang/String;
    //   918: iconst_1
    //   919: istore #4
    //   921: aload #11
    //   923: astore #9
    //   925: aload #11
    //   927: astore #10
    //   929: aload #13
    //   931: invokevirtual getClass : ()Ljava/lang/Class;
    //   934: pop
    //   935: aload #11
    //   937: astore #9
    //   939: aload #11
    //   941: astore #10
    //   943: aload #11
    //   945: invokeinterface moveToNext : ()Z
    //   950: pop
    //   951: goto -> 759
    //   954: astore #8
    //   956: aload #10
    //   958: ifnull -> 968
    //   961: aload #10
    //   963: invokeinterface close : ()V
    //   968: invokestatic closeDatabase : ()V
    //   971: aload #8
    //   973: athrow
    //   974: aload #11
    //   976: astore #9
    //   978: aload #11
    //   980: astore #10
    //   982: aload #8
    //   984: ldc 'AIFA'
    //   986: invokevirtual equals : (Ljava/lang/Object;)Z
    //   989: ifeq -> 875
    //   992: aload #11
    //   994: astore #9
    //   996: aload #11
    //   998: astore #10
    //   1000: aload #13
    //   1002: aload_0
    //   1003: getfield info : Lcom/apsalar/sdk/ApsalarSessionInfo;
    //   1006: getfield deviceId : Ljava/lang/String;
    //   1009: putfield AIFA : Ljava/lang/String;
    //   1012: goto -> 875
    //   1015: aload #11
    //   1017: astore #9
    //   1019: aload #11
    //   1021: astore #10
    //   1023: aload #13
    //   1025: iconst_1
    //   1026: putfield already_did_SQL : Z
    //   1029: aload #11
    //   1031: ifnull -> 1041
    //   1034: aload #11
    //   1036: invokeinterface close : ()V
    //   1041: invokestatic closeDatabase : ()V
    //   1044: iload_1
    //   1045: ifeq -> 29
    //   1048: aload #13
    //   1050: invokevirtual getClass : ()Ljava/lang/Class;
    //   1053: pop
    //   1054: aload #13
    //   1056: getfield canonicalKeyspace : Ljava/lang/String;
    //   1059: invokestatic setKeySpace : (Ljava/lang/String;)Ljava/lang/String;
    //   1062: pop
    //   1063: aload #13
    //   1065: aload #13
    //   1067: getfield canonicalKeyspace : Ljava/lang/String;
    //   1070: invokestatic getDeviceId : (Ljava/lang/String;)Ljava/lang/String;
    //   1073: putfield canonicalDeviceId : Ljava/lang/String;
    //   1076: aload_0
    //   1077: getfield info : Lcom/apsalar/sdk/ApsalarSessionInfo;
    //   1080: aload #13
    //   1082: getfield canonicalDeviceId : Ljava/lang/String;
    //   1085: putfield deviceId : Ljava/lang/String;
    //   1088: goto -> 29
    //   1091: iconst_0
    //   1092: ireturn
    //   1093: goto -> 212
    //   1096: iload #5
    //   1098: iconst_1
    //   1099: iadd
    //   1100: istore #5
    //   1102: aload #8
    //   1104: astore #11
    //   1106: iload_3
    //   1107: istore_2
    //   1108: iload #4
    //   1110: istore_1
    //   1111: goto -> 158
    //   1114: ldc 'ANDI'
    //   1116: astore #8
    //   1118: goto -> 212
    //   1121: ldc_w 'IMEI'
    //   1124: astore #8
    //   1126: goto -> 212
    //   1129: ldc 'MAC1'
    //   1131: astore #8
    //   1133: goto -> 212
    //   1136: ldc 'BMAC'
    //   1138: astore #8
    //   1140: goto -> 212
    // Exception table:
    //   from	to	target	type
    //   67	73	677	java/lang/Exception
    //   67	73	954	finally
    //   81	94	677	java/lang/Exception
    //   81	94	954	finally
    //   102	110	677	java/lang/Exception
    //   102	110	954	finally
    //   118	124	677	java/lang/Exception
    //   118	124	954	finally
    //   132	136	677	java/lang/Exception
    //   132	136	954	finally
    //   220	229	677	java/lang/Exception
    //   220	229	954	finally
    //   237	283	677	java/lang/Exception
    //   237	283	954	finally
    //   291	302	677	java/lang/Exception
    //   291	302	954	finally
    //   313	320	677	java/lang/Exception
    //   313	320	954	finally
    //   351	367	677	java/lang/Exception
    //   351	367	954	finally
    //   380	392	677	java/lang/Exception
    //   380	392	954	finally
    //   403	417	677	java/lang/Exception
    //   403	417	954	finally
    //   430	441	677	java/lang/Exception
    //   430	441	954	finally
    //   449	459	677	java/lang/Exception
    //   449	459	954	finally
    //   472	479	677	java/lang/Exception
    //   472	479	954	finally
    //   498	505	677	java/lang/Exception
    //   498	505	954	finally
    //   525	533	677	java/lang/Exception
    //   525	533	954	finally
    //   548	555	677	java/lang/Exception
    //   548	555	954	finally
    //   566	576	677	java/lang/Exception
    //   566	576	954	finally
    //   584	594	677	java/lang/Exception
    //   584	594	954	finally
    //   602	615	677	java/lang/Exception
    //   602	615	954	finally
    //   623	638	677	java/lang/Exception
    //   623	638	954	finally
    //   646	655	677	java/lang/Exception
    //   646	655	954	finally
    //   663	669	677	java/lang/Exception
    //   663	669	954	finally
    //   683	689	954	finally
    //   693	699	954	finally
    //   703	707	954	finally
    //   732	738	677	java/lang/Exception
    //   732	738	954	finally
    //   746	754	677	java/lang/Exception
    //   746	754	954	finally
    //   772	782	677	java/lang/Exception
    //   772	782	954	finally
    //   790	800	677	java/lang/Exception
    //   790	800	954	finally
    //   808	823	677	java/lang/Exception
    //   808	823	954	finally
    //   831	837	677	java/lang/Exception
    //   831	837	954	finally
    //   845	855	677	java/lang/Exception
    //   845	855	954	finally
    //   863	875	677	java/lang/Exception
    //   863	875	954	finally
    //   883	895	677	java/lang/Exception
    //   883	895	954	finally
    //   905	918	677	java/lang/Exception
    //   905	918	954	finally
    //   929	935	677	java/lang/Exception
    //   929	935	954	finally
    //   943	951	677	java/lang/Exception
    //   943	951	954	finally
    //   982	992	677	java/lang/Exception
    //   982	992	954	finally
    //   1000	1012	677	java/lang/Exception
    //   1000	1012	954	finally
    //   1023	1029	677	java/lang/Exception
    //   1023	1029	954	finally
  }
  
  public JSONObject toJSON() {
    ApSingleton apSingleton = ApSingleton.getInstance(this.ctx);
    JSONObject jSONObject = new JSONObject();
    try {
      jSONObject.put("eventType", this.eventType);
      jSONObject.put("eventTime", this.eventTime);
      jSONObject.put("eventName", this.eventName);
      jSONObject.put("eventData", this.eventData);
      return jSONObject;
    } catch (JSONException jSONException) {
      apSingleton.incrExceptionCount();
      apSingleton.getClass();
      return jSONObject;
    } 
  }
}


/* Location:              C:\soft\dex2jar-2.0\Smash Cricket-dex2jar.jar!\com\apsalar\sdk\ApsalarEvent.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */