package com.apsalar.sdk;

import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.provider.Settings;
import java.util.Vector;
import java.util.concurrent.locks.Condition;
import java.util.concurrent.locks.ReentrantLock;
import org.json.JSONException;
import org.json.JSONObject;

class ApsalarThread extends Thread {
  static final String TAG = "Apsalar SDK/ApsalarThread";
  
  private static String apikey;
  
  private static String secret;
  
  private int currentBackoff;
  
  final Condition incomingEvent = this.incomingEventLock.newCondition();
  
  final ReentrantLock incomingEventLock = new ReentrantLock();
  
  private int backoff() {
    ApSingleton.getInstance(ApSingleton.getContext()).getClass();
    this.currentBackoff = networkBackoff(this.currentBackoff);
    return 2;
  }
  
  private ApsalarAPI createApsalarEvent(Cursor paramCursor) {
    Context context = ApSingleton.getContext();
    ApSingleton apSingleton = ApSingleton.getInstance(context);
    int i = paramCursor.getInt(0);
    String str3 = paramCursor.getString(1);
    String str1 = paramCursor.getString(2);
    String str2 = paramCursor.getString(3);
    long l = paramCursor.getLong(4);
    try {
      JSONObject jSONObject = new JSONObject(str3);
      ApsalarSessionInfo apsalarSessionInfo = new ApsalarSessionInfo(jSONObject, apSingleton.info.apiKey, apSingleton.info.secret);
      apSingleton.getClass();
      switch (i) {
        default:
          apSingleton.getClass();
          return null;
        case 1:
          return new ApsalarSession(context, apsalarSessionInfo, l);
        case 3:
          return new ApsalarEvent(context, apsalarSessionInfo, str1, l, str2);
        case 2:
          break;
      } 
    } catch (JSONException jSONException) {
      apSingleton.incrExceptionCount();
      apSingleton.getClass();
      return null;
    } 
    return new ApsalarHeartbeat(context, (ApsalarSessionInfo)jSONException, l);
  }
  
  private void deleteEventIds(Vector<String> paramVector) {
    ApSingleton apSingleton = ApSingleton.getInstance(ApSingleton.getContext());
    for (int i = 0; i < paramVector.size(); i++) {
      String str = paramVector.elementAt(i);
      apSingleton.database.delete("events", "id=" + str, null);
      apSingleton.getClass();
    } 
  }
  
  private Cursor getOldestEventsFromDatabase() {
    ApSingleton apSingleton = ApSingleton.getInstance(ApSingleton.getContext());
    apSingleton.database = ApsalarSQLiteHelper.getSQLWritableDatabase(apSingleton.ctx);
    if (apSingleton.database == null)
      return null; 
    SQLiteDatabase sQLiteDatabase = apSingleton.database;
    apSingleton.getClass();
    return sQLiteDatabase.rawQuery("SELECT type, session_json, name, args, unix_t, id FROM events ORDER BY id ASC LIMIT 1", null);
  }
  
  protected static ApsalarThread getThreadInstance(String paramString1, String paramString2) {
    ApSingleton apSingleton = ApSingleton.getInstance(ApSingleton.getContext());
    apikey = paramString1;
    secret = paramString2;
    if (ApSingleton.apsalar_thread == null) {
      apSingleton.getClass();
      ApSingleton.apsalar_thread = new ApsalarThread();
      ApSingleton.apsalar_thread.setDaemon(true);
      ApSingleton.apsalar_thread.setName("ApsalarHTTPThread");
    } 
    if (!ApSingleton.apsalar_thread.isAlive()) {
      apSingleton.getClass();
      ApSingleton.apsalar_thread.start();
    } 
    return ApSingleton.apsalar_thread;
  }
  
  private boolean handleCanonical(ApsalarEvent paramApsalarEvent) {
    Context context = ApSingleton.getContext();
    ApSingleton apSingleton = ApSingleton.getInstance(context);
    switch (paramApsalarEvent.REST()) {
      default:
        return true;
      case 0:
        return false;
      case 1:
        break;
    } 
    Apsalar.saveSharedPrefs(context);
    Apsalar.setInfo(context, apSingleton.info.apiKey, apSingleton.info.secret, true);
    return true;
  }
  
  private boolean handleEvent(ApsalarEvent paramApsalarEvent) {
    ApSingleton.getInstance(ApSingleton.getContext());
    switch (paramApsalarEvent.REST()) {
      default:
        return true;
      case 0:
        break;
    } 
    return false;
  }
  
  private boolean handleResolve(ApsalarEvent paramApsalarEvent) {
    Context context = ApSingleton.getContext();
    ApSingleton apSingleton = ApSingleton.getInstance(context);
    switch (paramApsalarEvent.REST()) {
      default:
        return true;
      case 0:
        return false;
      case 1:
        break;
    } 
    apSingleton.getClass();
    Apsalar.saveSharedPrefs(context);
    Apsalar.setInfo(context, apSingleton.info.apiKey, apSingleton.info.secret, true);
    return true;
  }
  
  private boolean handleSession(ApsalarEvent paramApsalarEvent) {
    Context context = ApSingleton.getContext();
    ApSingleton.getInstance(context);
    switch (paramApsalarEvent.REST()) {
      default:
        return true;
      case 0:
        return false;
      case 1:
        break;
    } 
    JSONObject jSONObject = paramApsalarEvent.returnDataJSON;
    if (jSONObject != null && jSONObject.has("first_time")) {
      Apsalar.sendFBInstall(context);
      Apsalar.sendReferrerInstall(context);
      return true;
    } 
  }
  
  private boolean isActiveThread() {
    boolean bool1;
    boolean bool2;
    boolean bool3 = false;
    ApSingleton.getInstance(ApSingleton.getContext());
    if (ApSingleton.apsalar_thread != null && ApSingleton.apsalar_thread == this) {
      bool1 = true;
    } else {
      bool1 = false;
    } 
    if (ApSingleton.apsalar_thread == null) {
      bool2 = true;
    } else {
      bool2 = false;
    } 
    if (bool1 || bool2)
      bool3 = true; 
    return bool3;
  }
  
  private int networkBackoff(int paramInt) {
    ApSingleton apSingleton = ApSingleton.getInstance(ApSingleton.getContext());
    apSingleton.getClass();
    AlarmClock.start(paramInt);
    int i = paramInt * apSingleton.RETRY_INTERVAL_BACKOFF;
    paramInt = i;
    if (i > apSingleton.RETRY_INTERVAL_MAX)
      paramInt = apSingleton.RETRY_INTERVAL_MAX; 
    return paramInt;
  }
  
  private int nominal() {
    // Byte code:
    //   0: invokestatic getContext : ()Landroid/content/Context;
    //   3: invokestatic getInstance : (Landroid/content/Context;)Lcom/apsalar/sdk/ApSingleton;
    //   6: astore #7
    //   8: aload #7
    //   10: invokevirtual getClass : ()Ljava/lang/Class;
    //   13: pop
    //   14: aload_0
    //   15: invokespecial getOldestEventsFromDatabase : ()Landroid/database/Cursor;
    //   18: astore #6
    //   20: aload #6
    //   22: ifnonnull -> 39
    //   25: aload #7
    //   27: invokevirtual getClass : ()Ljava/lang/Class;
    //   30: pop
    //   31: ldc2_w 5000
    //   34: invokestatic sleep : (J)V
    //   37: iconst_2
    //   38: ireturn
    //   39: aload #6
    //   41: invokeinterface getCount : ()I
    //   46: ifne -> 62
    //   49: aload_0
    //   50: invokespecial waitForIncomingEvent : ()V
    //   53: aload #6
    //   55: invokeinterface close : ()V
    //   60: iconst_2
    //   61: ireturn
    //   62: new java/util/Vector
    //   65: dup
    //   66: aload #6
    //   68: invokeinterface getCount : ()I
    //   73: invokespecial <init> : (I)V
    //   76: astore #8
    //   78: iconst_0
    //   79: istore #4
    //   81: aload #6
    //   83: invokeinterface moveToFirst : ()Z
    //   88: pop
    //   89: aload #6
    //   91: iconst_0
    //   92: invokeinterface getInt : (I)I
    //   97: istore_1
    //   98: aload #6
    //   100: iconst_5
    //   101: invokeinterface getInt : (I)I
    //   106: istore_2
    //   107: aload_0
    //   108: aload #6
    //   110: invokespecial createApsalarEvent : (Landroid/database/Cursor;)Lcom/apsalar/sdk/ApsalarAPI;
    //   113: checkcast com/apsalar/sdk/ApsalarEvent
    //   116: astore #9
    //   118: iload_1
    //   119: tableswitch default -> 235, 1 -> 203, 2 -> 213, 3 -> 213
    //   144: aload #7
    //   146: invokevirtual getClass : ()Ljava/lang/Class;
    //   149: pop
    //   150: iload #4
    //   152: istore_3
    //   153: iload_3
    //   154: ifeq -> 184
    //   157: aload #8
    //   159: iload_2
    //   160: invokestatic valueOf : (I)Ljava/lang/String;
    //   163: invokevirtual add : (Ljava/lang/Object;)Z
    //   166: pop
    //   167: aload #6
    //   169: invokeinterface moveToNext : ()Z
    //   174: istore #5
    //   176: iload_3
    //   177: istore #4
    //   179: iload #5
    //   181: ifne -> 89
    //   184: aload #6
    //   186: invokeinterface close : ()V
    //   191: aload_0
    //   192: aload #8
    //   194: invokespecial deleteEventIds : (Ljava/util/Vector;)V
    //   197: iload_3
    //   198: ifne -> 37
    //   201: iconst_4
    //   202: ireturn
    //   203: aload_0
    //   204: aload #9
    //   206: invokespecial handleSession : (Lcom/apsalar/sdk/ApsalarEvent;)Z
    //   209: istore_3
    //   210: goto -> 153
    //   213: aload_0
    //   214: aload #9
    //   216: invokespecial handleEvent : (Lcom/apsalar/sdk/ApsalarEvent;)Z
    //   219: istore_3
    //   220: goto -> 153
    //   223: astore #7
    //   225: aload #6
    //   227: invokeinterface close : ()V
    //   232: aload #7
    //   234: athrow
    //   235: goto -> 144
    // Exception table:
    //   from	to	target	type
    //   81	89	223	finally
    //   89	118	223	finally
    //   144	150	223	finally
    //   157	176	223	finally
    //   203	210	223	finally
    //   213	220	223	finally
  }
  
  private void processEventsForever() {
    ApSingleton apSingleton = ApSingleton.getInstance(ApSingleton.getContext());
    this.currentBackoff = apSingleton.BACKOFF_INTERVAL;
    while (true) {
      if (!isActiveThread()) {
        apSingleton.getClass();
        return;
      } 
      ApSingleton apSingleton1 = ApSingleton.getInstance(ApSingleton.getContext());
      switch (apSingleton1.state) {
        case 2:
          apSingleton1.state = nominal();
          apSingleton = apSingleton1;
          if (apSingleton1.state == 2) {
            this.currentBackoff = apSingleton1.BACKOFF_INTERVAL;
            apSingleton = apSingleton1;
          } 
          break;
        case 4:
          apSingleton1.state = backoff();
          apSingleton = apSingleton1;
          break;
      } 
    } 
  }
  
  private boolean syncAIFA() {
    ApSingleton apSingleton = ApSingleton.getInstance(ApSingleton.getContext());
    String str = apSingleton.AIFA;
    apSingleton.AIFA = AIFA_Helper.getAIFA();
    return (apSingleton.AIFA != str);
  }
  
  private void waitForIncomingEvent() {
    null = ApSingleton.getInstance(ApSingleton.getContext());
    null.getClass();
    this.incomingEventLock.lock();
    try {
      this.incomingEvent.await();
      null.getClass();
      return;
    } catch (InterruptedException interruptedException) {
      return;
    } finally {
      this.incomingEventLock.unlock();
    } 
  }
  
  public void run() {
    Context context = ApSingleton.getContext();
    ApSingleton apSingleton = ApSingleton.getInstance(context);
    if (!isActiveThread()) {
      apSingleton.getClass();
      return;
    } 
    if (!ApsalarSQLiteHelper.createApsalarTables()) {
      apSingleton.getClass();
      return;
    } 
    if (Apsalar.setInfo(context, apikey, secret, false))
      Apsalar.loadConfig(context); 
    Apsalar.loadSharedPrefs(context);
    apSingleton.getClass();
    if (ApSingleton.eventConsumerThread != null && !ApSingleton.eventConsumerThread.isAlive()) {
      apSingleton.getClass();
      ApSingleton.eventConsumerThread.start();
    } 
    if (apSingleton.ANDI == null) {
      apSingleton.getClass();
      apSingleton.ANDI = Settings.Secure.getString(apSingleton.ctx.getContentResolver(), "android_id");
    } 
    if (syncAIFA())
      Apsalar.updateConfigTable(context, "aifa", apSingleton.AIFA); 
    ApsalarCanonical apsalarCanonical = new ApsalarCanonical(context, apSingleton.info);
    int i;
    for (i = apSingleton.BACKOFF_INTERVAL; !handleCanonical(apsalarCanonical); i = networkBackoff(i));
    if (isActiveThread()) {
      ApsalarResolve apsalarResolve = new ApsalarResolve(context, apSingleton.info, apSingleton.playStoreAvailable);
      for (i = apSingleton.BACKOFF_INTERVAL; !handleResolve(apsalarResolve); i = networkBackoff(i));
      processEventsForever();
      return;
    } 
  }
}


/* Location:              C:\soft\dex2jar-2.0\Smash Cricket-dex2jar.jar!\com\apsalar\sdk\ApsalarThread.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */