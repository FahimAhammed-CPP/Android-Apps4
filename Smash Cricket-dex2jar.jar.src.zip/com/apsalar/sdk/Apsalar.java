package com.apsalar.sdk;

import android.content.BroadcastReceiver;
import android.content.ContentValues;
import android.content.Context;
import android.content.IntentFilter;
import android.content.SharedPreferences;
import android.database.Cursor;
import android.database.SQLException;
import android.database.sqlite.SQLiteException;
import android.net.Uri;
import android.util.Log;
import java.util.HashMap;
import java.util.Locale;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

public class Apsalar {
  private static final String FACEBOOK_ATTRIBUTION_ID_URL = "content://com.facebook.katana.provider.AttributionIdProvider";
  
  static final String TAG = "Apsalar SDK";
  
  private static final char[] hexDigits = new char[] { 
      '0', '1', '2', '3', '4', '5', '6', '7', '8', '9', 
      'a', 'b', 'c', 'd', 'e', 'f' };
  
  private static JSONObject build_JSON(Object... paramVarArgs) {
    JSONObject jSONObject1;
    ApSingleton apSingleton = ApSingleton.getInstance(ApSingleton.getContext());
    JSONObject jSONObject2 = new JSONObject();
    int i = 0;
    while (true) {
      jSONObject1 = jSONObject2;
      try {
        if (i < paramVarArgs.length) {
          jSONObject2.put((String)paramVarArgs[i], paramVarArgs[i + 1]);
          i += 2;
          continue;
        } 
      } catch (JSONException jSONException) {
        apSingleton.incrExceptionCount();
        apSingleton.getClass();
        jSONObject1 = null;
      } 
      break;
    } 
    return jSONObject1;
  }
  
  public static boolean enableHeartbeat(boolean paramBoolean) {
    (ApSingleton.getInstance(ApSingleton.getContext())).doHeartbeat = paramBoolean;
    return paramBoolean;
  }
  
  public static void endSession() {
    ApSingleton.getInstance(ApSingleton.getContext());
    queueEvent(3, "end_session", "");
  }
  
  public static void event(String paramString) {
    ApSingleton.getInstance(ApSingleton.getContext()).getClass();
    queueEvent(3, paramString, "");
  }
  
  public static void event(String paramString, JSONObject paramJSONObject) {
    ApSingleton.getInstance(ApSingleton.getContext()).getClass();
    eventJSON(paramString, paramJSONObject);
  }
  
  public static void event(String paramString, Object... paramVarArgs) {
    boolean bool1;
    ApSingleton apSingleton = ApSingleton.getInstance(ApSingleton.getContext());
    apSingleton.getClass();
    if (paramVarArgs.length % 2 != 0) {
      apSingleton.getClass();
      apSingleton.incrDropEventsCount();
      return;
    } 
    boolean bool2 = false;
    JSONObject jSONObject = new JSONObject();
    int i = 0;
    while (true) {
      bool1 = bool2;
      try {
        if (i < paramVarArgs.length) {
          jSONObject.put((String)paramVarArgs[i], paramVarArgs[i + 1]);
          i += 2;
          continue;
        } 
      } catch (JSONException jSONException) {
        apSingleton.incrExceptionCount();
        apSingleton.getClass();
        bool1 = true;
      } 
      break;
    } 
    if (bool1)
      apSingleton.getClass(); 
    queueEvent(3, paramString, jSONObject.toString());
  }
  
  public static void eventJSON(String paramString, JSONObject paramJSONObject) {
    ApSingleton.getInstance(ApSingleton.getContext()).getClass();
    queueEvent(3, paramString, paramJSONObject.toString());
  }
  
  protected static boolean filterBroadcastIntents(Context paramContext, String paramString) {
    ApSingleton apSingleton = ApSingleton.getInstance(paramContext);
    IntentFilter intentFilter = new IntentFilter();
    intentFilter.addAction("android.net.conn.CONNECTIVITY_CHANGE");
    intentFilter.addAction("com.apsalar.sdk.SOFT_RESET");
    try {
      if (paramString.equals("com.apsalar.sdk.ApsalarReceiver")) {
        if (apSingleton.apsalar_receiver == null)
          apSingleton.apsalar_receiver = (BroadcastReceiver)Class.forName(paramString).newInstance(); 
        paramContext.registerReceiver(apSingleton.apsalar_receiver, intentFilter);
        apSingleton.getClass();
        return true;
      } 
      if (apSingleton.apsalar_safe_receiver == null)
        apSingleton.apsalar_safe_receiver = (BroadcastReceiver)Class.forName(paramString).newInstance(); 
      paramContext.registerReceiver(apSingleton.apsalar_safe_receiver, intentFilter);
      apSingleton.getClass();
      return true;
    } catch (ClassNotFoundException classNotFoundException) {
      apSingleton.incrExceptionCount();
      apSingleton.getClass();
    } catch (InstantiationException instantiationException) {
      apSingleton.incrExceptionCount();
      apSingleton.getClass();
    } catch (IllegalAccessException illegalAccessException) {
      apSingleton.incrExceptionCount();
      apSingleton.getClass();
    } 
    return false;
  }
  
  protected static String getDeviceId() {
    return getDeviceId((ApSingleton.getInstance(ApSingleton.getContext())).canonicalKeyspace);
  }
  
  protected static String getDeviceId(String paramString) {
    String str;
    ApSingleton apSingleton = ApSingleton.getInstance(ApSingleton.getContext());
    apSingleton.getClass();
    if (paramString == null)
      return "None"; 
    if (paramString.equals("ANDI") && apSingleton.ANDI != null) {
      str = apSingleton.ANDI;
      paramString = str;
      return str.equals("9774d56d682e549c") ? "None" : paramString;
    } 
    return (paramString.equals("AIFA") && ((ApSingleton)str).AIFA != null) ? ((ApSingleton)str).AIFA : "None";
  }
  
  public static String getFacebookAttributionId() {
    Context context1 = ApSingleton.getContext();
    ApSingleton apSingleton = ApSingleton.getInstance(context1);
    apSingleton.getClass();
    if (context1 == null) {
      apSingleton.getClass();
      return null;
    } 
    Context context2 = null;
    context1 = context2;
    try {
      Cursor cursor = apSingleton.ctx.getContentResolver().query(Uri.parse("content://com.facebook.katana.provider.AttributionIdProvider"), new String[] { "aid" }, null, null, null);
      if (cursor == null)
        return null; 
    } catch (Exception exception) {
      apSingleton.incrExceptionCount();
      apSingleton.getClass();
      return null;
    } finally {
      apSingleton.getClass();
    } 
  }
  
  public static String getSessionId() {
    ApSingleton apSingleton = ApSingleton.getInstance(ApSingleton.getContext());
    return (apSingleton.info != null && apSingleton.info.sessionId != null) ? apSingleton.info.sessionId : "None";
  }
  
  protected static String hexDigest(byte[] paramArrayOfbyte) {
    StringBuffer stringBuffer = new StringBuffer();
    for (int i = 0; i < paramArrayOfbyte.length; i++) {
      stringBuffer.append(hexDigits[(paramArrayOfbyte[i] & 0xF0) >>> 4]);
      stringBuffer.append(hexDigits[paramArrayOfbyte[i] & 0xF]);
    } 
    return stringBuffer.toString();
  }
  
  public static boolean isHeartbeatEnabled() {
    return (ApSingleton.getInstance(ApSingleton.getContext())).doHeartbeat;
  }
  
  protected static boolean loadConfig(Context paramContext) {
    ApSingleton apSingleton = ApSingleton.getInstance(paramContext);
    apSingleton.getClass();
    Cursor cursor4 = null;
    Cursor cursor3 = null;
    Cursor cursor2 = cursor3;
    Cursor cursor1 = cursor4;
    try {
      apSingleton.database = ApsalarSQLiteHelper.getSQLWritableDatabase(paramContext);
      cursor2 = cursor3;
      cursor1 = cursor4;
      if (apSingleton.database == null) {
        cursor2 = cursor3;
        cursor1 = cursor4;
        apSingleton.getClass();
        return false;
      } 
      cursor2 = cursor3;
      cursor1 = cursor4;
      cursor3 = apSingleton.database.query("config", null, null, null, null, null, null, null);
      cursor2 = cursor3;
    } catch (Exception exception) {
      cursor1 = cursor2;
      apSingleton.incrExceptionCount();
      cursor1 = cursor2;
      apSingleton.getClass();
      return false;
    } finally {
      if (cursor1 != null)
        cursor1.close(); 
      ApsalarSQLiteHelper.closeDatabase();
    } 
    cursor2 = cursor3;
    cursor1 = cursor3;
    cursor3.close();
    if (false)
      throw new NullPointerException(); 
    ApsalarSQLiteHelper.closeDatabase();
    return true;
  }
  
  protected static boolean loadSharedPrefs(Context paramContext) {
    ApSingleton apSingleton = ApSingleton.getInstance(paramContext);
    SharedPreferences sharedPreferences = paramContext.getApplicationContext().getSharedPreferences("ApsalarAppPrefs", 0);
    try {
      apSingleton.configTableCreated = sharedPreferences.getBoolean("SQL_config", false);
      apSingleton.backlogTableCreated = sharedPreferences.getBoolean("SQL_backlog", false);
      apSingleton.devicekeysTableCreated = sharedPreferences.getBoolean("SQL_devicekeys", false);
      apSingleton.expires = sharedPreferences.getInt("EXPIRES", 0);
      apSingleton.hash = sharedPreferences.getString("HASH", "");
      apSingleton.devicesAlreadyResolved = sharedPreferences.getBoolean("DEVICES", false);
      apSingleton.RESOLVE_ALL_AVAILABLE = sharedPreferences.getBoolean("resolveall", false);
      apSingleton.ALWAYS_REQUEST_CANONICAL = sharedPreferences.getBoolean("alwayscanon", false);
      apSingleton.NUM_EVENTS_B4_SLEEP = sharedPreferences.getInt("evb4sleep", 25);
      apSingleton.QUEUE_SIZE_MAX = sharedPreferences.getInt("qsizemax", 2000);
      apSingleton.BUFFER_SIZE_MAX = sharedPreferences.getInt("bsizemax", 1000);
      apSingleton.HEARTBEAT_INTERVAL_BACKOFF = sharedPreferences.getInt("hrtbackoff", 2);
      apSingleton.HEARTBEAT_INTERVAL_MAX = sharedPreferences.getInt("hrtintmax", 21600000);
      apSingleton.HEARTBEAT_INTERVAL_MIN = sharedPreferences.getInt("hrtintmin", 300000);
      apSingleton.RETRY_INTERVAL_BACKOFF = sharedPreferences.getInt("retbackoff", 2);
      apSingleton.RETRY_INTERVAL_MAX = sharedPreferences.getInt("retintmax", 300000);
      apSingleton.RETRY_INTERVAL_MIN = sharedPreferences.getInt("retintmin", 15000);
      apSingleton.BATCHES_MAX = sharedPreferences.getInt("batmax", 3000);
      apSingleton.BATCHES_INTERVAL = sharedPreferences.getInt("batint", 30);
      apSingleton.RESOLVER_MAX = sharedPreferences.getInt("resmax", 3);
      apSingleton.SHORTSLEEP = sharedPreferences.getInt("shtsleep", 1000);
      apSingleton.MEDIUMSLEEP = sharedPreferences.getInt("medsleep", 3000);
      apSingleton.LONGSLEEP = sharedPreferences.getInt("lngsleep", 60000);
      apSingleton.VERYLONGSLEEP = sharedPreferences.getInt("xlnsleep", 900000);
      return true;
    } catch (Exception exception) {
      apSingleton.incrExceptionCount();
      apSingleton.getClass();
      apSingleton.getClass();
      return false;
    } 
  }
  
  protected static void queueEvent(int paramInt) {
    if (paramInt == 3) {
      Log.w("Apsalar SDK", "this should only be called for events that are not ApsalarAPI.Type.EVENT");
      return;
    } 
    queueEvent(paramInt, "", "");
  }
  
  protected static void queueEvent(int paramInt, String paramString1, String paramString2) {
    ApSingleton apSingleton = ApSingleton.getInstance(ApSingleton.getContext());
    if (paramInt == 3 && paramString1 == null) {
      apSingleton.getClass();
      apSingleton.incrDropEventsCount();
      return;
    } 
    if (apSingleton.info == null) {
      apSingleton.getClass();
      apSingleton.incrDropEventsCount();
      return;
    } 
    if (ApSingleton.eventConsumerThread != null) {
      if (!ApSingleton.eventConsumerThread.put(new RawEvent(paramInt, paramString1, paramString2))) {
        apSingleton.getClass();
        apSingleton.incrDropEventsCount();
        return;
      } 
      return;
    } 
    apSingleton.getClass();
  }
  
  public static boolean registerReceiver(Context paramContext) {
    ApSingleton apSingleton = ApSingleton.getInstance(paramContext);
    if (apSingleton.registeredReceiver) {
      apSingleton.getClass();
      return true;
    } 
    apSingleton.getClass();
    return filterBroadcastIntents(paramContext, "com.apsalar.sdk.ApsalarReceiver");
  }
  
  public static void restartSession() {
    Context context = ApSingleton.getContext();
    ApSingleton apSingleton = ApSingleton.getInstance(context);
    apSingleton.getClass();
    if (context == null) {
      apSingleton.getClass();
      return;
    } 
    if (apSingleton.info != null && apSingleton.ctx != null) {
      restartSession(apSingleton.ctx, apSingleton.info.apiKey, apSingleton.info.secret);
      return;
    } 
    apSingleton.getClass();
  }
  
  public static void restartSession(Context paramContext, String paramString1, String paramString2) {
    ApSingleton apSingleton = ApSingleton.getInstance(paramContext);
    apSingleton.getClass();
    if (apSingleton.info != null) {
      apSingleton.info = new ApsalarSessionInfo(paramContext, paramString1, paramString2);
      apSingleton.info.sessionStart = System.currentTimeMillis();
      queueEvent(1);
    } 
    startSession(paramContext, paramString1, paramString2);
  }
  
  protected static boolean saveSharedPrefs(Context paramContext) {
    ApSingleton apSingleton = ApSingleton.getInstance(paramContext);
    SharedPreferences.Editor editor = apSingleton.ctx.getApplicationContext().getSharedPreferences("ApsalarAppPrefs", 0).edit();
    editor.putBoolean("SQL_config", apSingleton.configTableCreated);
    editor.putBoolean("SQL_backlog", apSingleton.backlogTableCreated);
    editor.putBoolean("SQL_devicekeys", apSingleton.devicekeysTableCreated);
    editor.putInt("EXPIRES", apSingleton.expires);
    editor.putString("HASH", apSingleton.hash);
    editor.putBoolean("DEVICES", apSingleton.devicesAlreadyResolved);
    editor.putBoolean("resolveall", apSingleton.RESOLVE_ALL_AVAILABLE);
    editor.putBoolean("alwayscanon", apSingleton.ALWAYS_REQUEST_CANONICAL);
    editor.putInt("evb4sleep", apSingleton.NUM_EVENTS_B4_SLEEP);
    editor.putInt("qsizemax", apSingleton.QUEUE_SIZE_MAX);
    editor.putInt("bsizemax", apSingleton.BUFFER_SIZE_MAX);
    editor.putInt("hrtbackoff", apSingleton.HEARTBEAT_INTERVAL_BACKOFF);
    editor.putInt("hrtintmax", apSingleton.HEARTBEAT_INTERVAL_MAX);
    editor.putInt("hrtintmin", apSingleton.HEARTBEAT_INTERVAL_MIN);
    editor.putInt("retbackoff", apSingleton.RETRY_INTERVAL_BACKOFF);
    editor.putInt("retintmax", apSingleton.RETRY_INTERVAL_MAX);
    editor.putInt("retintmin", apSingleton.RETRY_INTERVAL_MIN);
    editor.putInt("batmax", apSingleton.BATCHES_MAX);
    editor.putInt("batint", apSingleton.BATCHES_INTERVAL);
    editor.putInt("resmax", apSingleton.RESOLVER_MAX);
    editor.putInt("shtsleep", apSingleton.SHORTSLEEP);
    editor.putInt("medsleep", apSingleton.MEDIUMSLEEP);
    editor.putInt("lngsleep", apSingleton.LONGSLEEP);
    editor.putInt("xlnsleep", apSingleton.VERYLONGSLEEP);
    editor.commit();
    apSingleton.getClass();
    return true;
  }
  
  protected static boolean saveSharedPrefs(Context paramContext, String paramString1, String paramString2) {
    ApSingleton apSingleton = ApSingleton.getInstance(paramContext);
    SharedPreferences.Editor editor = apSingleton.ctx.getApplicationContext().getSharedPreferences("ApsalarAppPrefs", 0).edit();
    editor.putString(paramString1, paramString2);
    editor.commit();
    apSingleton.getClass();
    return true;
  }
  
  protected static void sendFBInstall(Context paramContext) {
    ApSingleton apSingleton = ApSingleton.getInstance(paramContext);
    apSingleton.getClass();
    if (apSingleton.FBAppId == null) {
      Log.w("Apsalar SDK", "Facebook App ID is null. Was Apsalar.setFBAppId() called?");
      return;
    } 
    apSingleton.getClass();
    String str = getFacebookAttributionId();
    if (str == null) {
      apSingleton.getClass();
      return;
    } 
    apSingleton.getClass();
    JSONObject jSONObject = new JSONObject();
    JSONArray jSONArray = new JSONArray();
    jSONArray.put(apSingleton.FBAppId);
    try {
      jSONObject.put("fb_app_attribution", str);
      jSONObject.put("fb_app_ids", jSONArray);
    } catch (JSONException jSONException) {
      apSingleton.incrExceptionCount();
      apSingleton.getClass();
      jSONException.printStackTrace();
    } 
    event("__FBInstall", jSONObject);
  }
  
  static void sendReferrerInstall(Context paramContext) {
    ApSingleton apSingleton = ApSingleton.getInstance(paramContext);
    apSingleton.getClass();
    HashMap hashMap = (HashMap)ApsalarReceiver.retrieveCSIReferrer(apSingleton.ctx);
    apSingleton.getClass();
    JSONObject jSONObject = new JSONObject();
    for (String str : hashMap.keySet()) {
      if (str.equals("referrer"))
        try {
          jSONObject.put("referrer", hashMap.get(str));
        } catch (JSONException jSONException) {
          apSingleton.incrExceptionCount();
          apSingleton.getClass();
        }  
    } 
    if (jSONObject.length() > 0) {
      apSingleton.getClass();
      event("__InstallReferrer", jSONObject);
    } 
  }
  
  public static void setAge(int paramInt) {
    ApSingleton apSingleton = ApSingleton.getInstance(ApSingleton.getContext());
    apSingleton.getClass();
    if (paramInt > 0 && paramInt < 110) {
      queueEvent(3, "__age__", build_JSON(new Object[] { "age", String.valueOf(paramInt) }).toString());
      return;
    } 
    apSingleton.getClass();
    apSingleton.incrDropEventsCount();
  }
  
  public static void setFBAppId(String paramString) {
    ApSingleton apSingleton = ApSingleton.getInstance(ApSingleton.getContext());
    apSingleton.getClass();
    if (paramString != null)
      apSingleton.FBAppId = paramString; 
  }
  
  public static void setGender(String paramString) {
    ApSingleton apSingleton = ApSingleton.getInstance(ApSingleton.getContext());
    apSingleton.getClass();
    Locale locale = (apSingleton.ctx.getResources().getConfiguration()).locale;
    if (paramString.toLowerCase(locale).equals("f") || paramString.toLowerCase(locale).equals("m")) {
      queueEvent(3, "__gender__", build_JSON(new Object[] { "gender", paramString }).toString());
      return;
    } 
    apSingleton.getClass();
    apSingleton.incrDropEventsCount();
  }
  
  protected static boolean setInfo(Context paramContext, String paramString1, String paramString2, boolean paramBoolean) {
    ApSingleton apSingleton = ApSingleton.getInstance(paramContext);
    if (apSingleton.info == null) {
      apSingleton.getClass();
      return false;
    } 
    apSingleton.getClass();
    if (paramContext == null || paramString1 == null || paramString2 == null) {
      apSingleton.getClass();
      return false;
    } 
    if (paramBoolean)
      try {
        ApsalarSQLiteHelper.clearConfigTables();
      } catch (Exception exception) {
      
      } catch (SecurityException securityException) {
        apSingleton.incrExceptionCount();
        apSingleton.getClass();
        return false;
      }  
    try {
      ContentValues contentValues = new ContentValues();
      Cursor cursor4 = null;
      Cursor cursor3 = null;
      Cursor cursor1 = cursor3;
      Cursor cursor2 = cursor4;
      try {
        if (apSingleton.database == null) {
          cursor1 = cursor3;
          cursor2 = cursor4;
          apSingleton.database = ApsalarSQLiteHelper.getSQLWritableDatabase((Context)securityException);
        } 
        cursor1 = cursor3;
        cursor2 = cursor4;
        Cursor cursor = apSingleton.database.rawQuery("SELECT * FROM config LIMIT 1", null);
        cursor1 = cursor;
        cursor2 = cursor;
        int i = cursor.getCount();
        if (cursor != null)
          cursor.close(); 
        if (i < 1) {
          String str;
          contentValues.put("apiKey", paramString1);
          contentValues.put("secret", paramString2);
          contentValues.put("isLAT", Boolean.valueOf(apSingleton.isLAT));
          contentValues.put("doHeartbeat", Boolean.valueOf(apSingleton.doHeartbeat));
          contentValues.put("playStoreAvailable", Boolean.valueOf(apSingleton.playStoreAvailable));
          contentValues.put("andi", apSingleton.ANDI);
          contentValues.put("aifa", apSingleton.AIFA);
          contentValues.put("canonicalKeyspace", apSingleton.canonicalKeyspace);
          contentValues.put("canonicalDeviceId", apSingleton.canonicalDeviceId);
          if (apSingleton.desired == null) {
            str = "[]";
          } else {
            str = apSingleton.desired.toString();
          } 
          contentValues.put("desired", str);
          try {
            apSingleton.database.insertOrThrow("config", null, contentValues);
            apSingleton.getClass();
            return false;
          } catch (SQLException sQLException) {
            apSingleton.incrExceptionCount();
            apSingleton.getClass();
            return false;
          } 
        } 
      } catch (SQLiteException sQLiteException) {
        cursor2 = cursor1;
        apSingleton.incrExceptionCount();
        cursor2 = cursor1;
        apSingleton.getClass();
        if (cursor1 != null) {
          cursor1.close();
          return false;
        } 
        return false;
      } finally {}
    } catch (Exception exception) {
      apSingleton.incrExceptionCount();
      apSingleton.getClass();
      return false;
    } 
  }
  
  protected static String setKeySpace(String paramString) {
    return (ApSingleton.getInstance(ApSingleton.getContext())).canonicalKeyspace;
  }
  
  public static void startSession(Context paramContext, String paramString1, String paramString2) {
    ApSingleton apSingleton = ApSingleton.getInstance(paramContext);
    apSingleton.getClass();
    apSingleton.registeredReceiver = registerReceiver(paramContext);
    if (paramContext == null) {
      apSingleton.getClass();
      return;
    } 
    ApsalarEventConsumerThread.getThreadInstance();
    if (apSingleton.info == null) {
      apSingleton.info = new ApsalarSessionInfo(paramContext, paramString1, paramString2);
      apSingleton.info.sessionStart = System.currentTimeMillis();
      queueEvent(1);
    } 
    ApsalarThread.getThreadInstance(paramString1, paramString2);
  }
  
  public static void unregisterApsalarReceiver() {
    unregisterApsalarReceiver(ApSingleton.getContext());
  }
  
  public static void unregisterApsalarReceiver(Context paramContext) {
    // Byte code:
    //   0: aload_0
    //   1: invokestatic getInstance : (Landroid/content/Context;)Lcom/apsalar/sdk/ApSingleton;
    //   4: astore_2
    //   5: aload_2
    //   6: invokevirtual getClass : ()Ljava/lang/Class;
    //   9: pop
    //   10: aload_2
    //   11: getfield apsalar_receiver : Landroid/content/BroadcastReceiver;
    //   14: ifnull -> 47
    //   17: aload_2
    //   18: getfield registeredReceiver : Z
    //   21: ifeq -> 47
    //   24: aload_2
    //   25: invokevirtual getClass : ()Ljava/lang/Class;
    //   28: pop
    //   29: aload_0
    //   30: aload_2
    //   31: getfield apsalar_receiver : Landroid/content/BroadcastReceiver;
    //   34: invokevirtual unregisterReceiver : (Landroid/content/BroadcastReceiver;)V
    //   37: aload_2
    //   38: aconst_null
    //   39: putfield apsalar_receiver : Landroid/content/BroadcastReceiver;
    //   42: aload_2
    //   43: iconst_0
    //   44: putfield registeredReceiver : Z
    //   47: aload_2
    //   48: getfield apsalar_safe_receiver : Landroid/content/BroadcastReceiver;
    //   51: ifnull -> 128
    //   54: aload_2
    //   55: getfield registeredSafeReceiver : Z
    //   58: ifeq -> 128
    //   61: aload_2
    //   62: invokevirtual getClass : ()Ljava/lang/Class;
    //   65: pop
    //   66: ldc_w 'com.apsalar.sdk'
    //   69: astore_1
    //   70: aload_0
    //   71: ifnull -> 79
    //   74: aload_0
    //   75: invokevirtual getPackageName : ()Ljava/lang/String;
    //   78: astore_1
    //   79: new java/lang/StringBuilder
    //   82: dup
    //   83: invokespecial <init> : ()V
    //   86: aload_1
    //   87: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   90: ldc_w '.SafeApsalarReceiver'
    //   93: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   96: invokevirtual toString : ()Ljava/lang/String;
    //   99: astore_1
    //   100: aload_0
    //   101: aload_1
    //   102: invokestatic forName : (Ljava/lang/String;)Ljava/lang/Class;
    //   105: aload_2
    //   106: getfield apsalar_safe_receiver : Landroid/content/BroadcastReceiver;
    //   109: invokevirtual cast : (Ljava/lang/Object;)Ljava/lang/Object;
    //   112: checkcast android/content/BroadcastReceiver
    //   115: invokevirtual unregisterReceiver : (Landroid/content/BroadcastReceiver;)V
    //   118: aload_2
    //   119: aconst_null
    //   120: putfield apsalar_safe_receiver : Landroid/content/BroadcastReceiver;
    //   123: aload_2
    //   124: iconst_0
    //   125: putfield registeredSafeReceiver : Z
    //   128: return
    //   129: astore_1
    //   130: aload_2
    //   131: invokevirtual incrExceptionCount : ()I
    //   134: pop
    //   135: aload_2
    //   136: invokevirtual getClass : ()Ljava/lang/Class;
    //   139: pop
    //   140: aload_2
    //   141: aconst_null
    //   142: putfield apsalar_receiver : Landroid/content/BroadcastReceiver;
    //   145: aload_2
    //   146: iconst_0
    //   147: putfield registeredReceiver : Z
    //   150: goto -> 47
    //   153: astore_0
    //   154: aload_2
    //   155: aconst_null
    //   156: putfield apsalar_receiver : Landroid/content/BroadcastReceiver;
    //   159: aload_2
    //   160: iconst_0
    //   161: putfield registeredReceiver : Z
    //   164: aload_0
    //   165: athrow
    //   166: astore_0
    //   167: aload_2
    //   168: invokevirtual incrExceptionCount : ()I
    //   171: pop
    //   172: aload_2
    //   173: invokevirtual getClass : ()Ljava/lang/Class;
    //   176: pop
    //   177: aload_2
    //   178: aconst_null
    //   179: putfield apsalar_safe_receiver : Landroid/content/BroadcastReceiver;
    //   182: aload_2
    //   183: iconst_0
    //   184: putfield registeredSafeReceiver : Z
    //   187: return
    //   188: astore_0
    //   189: aload_2
    //   190: aconst_null
    //   191: putfield apsalar_safe_receiver : Landroid/content/BroadcastReceiver;
    //   194: aload_2
    //   195: iconst_0
    //   196: putfield registeredSafeReceiver : Z
    //   199: aload_0
    //   200: athrow
    //   201: astore_0
    //   202: goto -> 118
    // Exception table:
    //   from	to	target	type
    //   24	37	129	java/lang/IllegalArgumentException
    //   24	37	153	finally
    //   61	66	166	java/lang/IllegalArgumentException
    //   61	66	188	finally
    //   74	79	166	java/lang/IllegalArgumentException
    //   74	79	188	finally
    //   79	100	166	java/lang/IllegalArgumentException
    //   79	100	188	finally
    //   100	118	201	java/lang/ClassNotFoundException
    //   100	118	166	java/lang/IllegalArgumentException
    //   100	118	188	finally
    //   130	140	153	finally
    //   167	177	188	finally
  }
  
  protected static boolean updateConfigTable(Context paramContext, String paramString1, String paramString2) {
    ApSingleton apSingleton = ApSingleton.getInstance(paramContext);
    if (apSingleton.database == null) {
      apSingleton.getClass();
      return false;
    } 
    ContentValues contentValues = new ContentValues();
    contentValues.put(paramString1, paramString2);
    if (apSingleton.database.update("config", contentValues, null, null) != 1)
      apSingleton.getClass(); 
    apSingleton.getClass();
    return true;
  }
}


/* Location:              C:\soft\dex2jar-2.0\Smash Cricket-dex2jar.jar!\com\apsalar\sdk\Apsalar.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */