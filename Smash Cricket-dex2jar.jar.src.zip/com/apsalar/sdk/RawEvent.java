package com.apsalar.sdk;

import org.json.JSONException;
import org.json.JSONObject;

class RawEvent {
  String eventData = "";
  
  String eventName = "";
  
  long eventTime = 0L;
  
  int eventType = 0;
  
  String sessionJson = "";
  
  JSONObject sessionJsonObj = null;
  
  RawEvent(int paramInt) {
    ApSingleton apSingleton = ApSingleton.getInstance(ApSingleton.getContext());
    this.eventType = paramInt;
    this.eventName = null;
    if (paramInt == 2)
      this.eventName = "heartbeat"; 
    this.eventData = null;
    this.eventTime = System.currentTimeMillis();
    this.sessionJson = apSingleton.info.toJSON().toString();
    this.sessionJsonObj = apSingleton.info.toJSON();
  }
  
  RawEvent(int paramInt, String paramString1, String paramString2) {
    ApSingleton apSingleton = ApSingleton.getInstance(ApSingleton.getContext());
    String str = paramString1;
    if (paramString1 == null)
      str = ""; 
    paramString1 = paramString2;
    if (paramString2 == null)
      paramString1 = ""; 
    this.eventType = paramInt;
    this.eventName = str.replace("\\n", "");
    this.eventData = paramString1.replace("\\n", "");
    this.eventTime = System.currentTimeMillis();
    this.sessionJson = apSingleton.info.toJSON().toString();
    this.sessionJsonObj = apSingleton.info.toJSON();
  }
  
  public String toString() {
    String str;
    try {
      str = this.sessionJsonObj.getString("sessionId");
    } catch (JSONException jSONException) {
      str = jSONException.toString();
    } 
    return "eventType=" + String.valueOf(this.eventType) + ", eventName=" + this.eventName + ", eventTime=" + this.eventTime + ", eventData=" + this.eventData + ", sessionId=" + str;
  }
}


/* Location:              C:\soft\dex2jar-2.0\Smash Cricket-dex2jar.jar!\com\apsalar\sdk\RawEvent.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */