package com.apsalar.sdk;

import android.os.Build;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.UnsupportedEncodingException;
import java.net.HttpURLConnection;
import java.net.ProtocolException;
import java.net.SocketTimeoutException;
import java.net.URL;

class ApsalarHttpClient {
  static final String TAG = "Apsalar SDK/HttpClient";
  
  static int responseSize = 1024;
  
  private static void disableConnectionReuseIfNecessary() {
    if (Build.VERSION.SDK_INT < 8)
      System.setProperty("http.keepAlive", "false"); 
  }
  
  static String get(String paramString) throws IOException, SocketTimeoutException {
    HttpURLConnection httpURLConnection;
    ApSingleton apSingleton = ApSingleton.getInstance(ApSingleton.getContext());
    apSingleton.getClass();
    null = new URL(paramString);
    paramString = null;
    try {
      HttpURLConnection httpURLConnection1 = (HttpURLConnection)null.openConnection();
      httpURLConnection = httpURLConnection1;
      setHttpURLConnectionDefaults(httpURLConnection1);
      httpURLConnection = httpURLConnection1;
      httpURLConnection1.connect();
      httpURLConnection = httpURLConnection1;
      String str = readAsString(httpURLConnection1.getInputStream());
      if (httpURLConnection1 != null)
        httpURLConnection1.disconnect(); 
      return str;
    } finally {
      if (httpURLConnection != null)
        httpURLConnection.disconnect(); 
    } 
  }
  
  private static String readAsString(InputStream paramInputStream) throws IOException, UnsupportedEncodingException {
    InputStreamReader inputStreamReader = new InputStreamReader(paramInputStream, "UTF-8");
    char[] arrayOfChar = new char[responseSize];
    inputStreamReader.read(arrayOfChar);
    int i;
    for (i = 0; i < responseSize && arrayOfChar[i] != '\000'; i++);
    return new String(arrayOfChar, 0, i);
  }
  
  private static void setHttpURLConnectionDefaults(HttpURLConnection paramHttpURLConnection) throws ProtocolException {
    paramHttpURLConnection.setConnectTimeout(3000);
    paramHttpURLConnection.setReadTimeout(3000);
    paramHttpURLConnection.setRequestMethod("GET");
    paramHttpURLConnection.setDoInput(true);
    disableConnectionReuseIfNecessary();
  }
}


/* Location:              C:\soft\dex2jar-2.0\Smash Cricket-dex2jar.jar!\com\apsalar\sdk\ApsalarHttpClient.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */