package com.apsalar.sdk;

import android.content.ContentValues;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import java.util.concurrent.ArrayBlockingQueue;
import org.json.JSONException;
import org.json.JSONObject;

class ApsalarEventConsumerThread extends Thread {
  static final String TAG = "Apsalar SDK/EventConsumerThread";
  
  protected ArrayBlockingQueue<RawEvent> eventQueue = new ArrayBlockingQueue<RawEvent>(5);
  
  static ApsalarEventConsumerThread getThreadInstance() {
    ApSingleton apSingleton = ApSingleton.getInstance(ApSingleton.getContext());
    if (ApSingleton.eventConsumerThread == null) {
      apSingleton.getClass();
      ApSingleton.eventConsumerThread = new ApsalarEventConsumerThread();
      ApSingleton.eventConsumerThread.setDaemon(true);
      ApSingleton.eventConsumerThread.setName("Event Consumer Thread");
    } 
    return ApSingleton.eventConsumerThread;
  }
  
  private void handleHeartbeat(ContentValues paramContentValues) {
    ApSingleton apSingleton = ApSingleton.getInstance(ApSingleton.getContext());
    int i = sessionHeartbeatEvent();
    if (i != -1) {
      apSingleton.getClass();
      apSingleton.database.delete("events", "id=?", new String[] { String.valueOf(i) });
    } 
    apSingleton.database.insert("events", null, paramContentValues);
  }
  
  private RawEvent heartbeatEvent() {
    ApSingleton apSingleton = ApSingleton.getInstance(ApSingleton.getContext());
    apSingleton.heartbeatInterval = nextHeartbeatInterval();
    if (!apSingleton.doHeartbeat)
      return null; 
    apSingleton.getClass();
    return new RawEvent(2);
  }
  
  private boolean isActiveThread() {
    boolean bool1;
    boolean bool2;
    boolean bool3 = false;
    ApSingleton.getInstance(ApSingleton.getContext());
    if (ApSingleton.eventConsumerThread != null && ApSingleton.eventConsumerThread == this) {
      bool1 = true;
    } else {
      bool1 = false;
    } 
    if (ApSingleton.eventConsumerThread == null) {
      bool2 = true;
    } else {
      bool2 = false;
    } 
    if (bool1 || bool2)
      bool3 = true; 
    return bool3;
  }
  
  private int nextHeartbeatInterval() {
    ApSingleton apSingleton = ApSingleton.getInstance(ApSingleton.getContext());
    int j = apSingleton.heartbeatInterval * apSingleton.HEARTBEAT_INTERVAL_BACKOFF;
    int i = j;
    if (j > apSingleton.HEARTBEAT_INTERVAL_MAX)
      i = apSingleton.HEARTBEAT_INTERVAL_MAX; 
    return i;
  }
  
  private int sessionHeartbeatEvent() {
    ApSingleton apSingleton = ApSingleton.getInstance(ApSingleton.getContext());
    SQLiteDatabase sQLiteDatabase = apSingleton.database;
    apSingleton.getClass();
    Cursor cursor = sQLiteDatabase.rawQuery("SELECT id, session_json FROM events WHERE type=? ORDER BY id DESC LIMIT 1", new String[] { String.valueOf(2) });
    if (cursor == null) {
      apSingleton.getClass();
      return -1;
    } 
    if (cursor.getCount() > 0) {
      cursor.moveToFirst();
      int i = cursor.getInt(0);
      String str = cursor.getString(1);
      if (str == null) {
        apSingleton.getClass();
        cursor.close();
        return -1;
      } 
      try {
        str = (new JSONObject(str)).getString("sessionId");
        apSingleton.getClass();
        if (str.equals(apSingleton.info.sessionId)) {
          cursor.close();
          return i;
        } 
      } catch (JSONException jSONException) {
        apSingleton.getClass();
        cursor.close();
        return -1;
      } 
    } 
    cursor.close();
    return -1;
  }
  
  private void signalIncomingEvent() {
    ApSingleton.getInstance(ApSingleton.getContext());
    ApsalarThread apsalarThread = ApSingleton.apsalar_thread;
    apsalarThread.incomingEventLock.lock();
    apsalarThread.incomingEvent.signal();
    apsalarThread.incomingEventLock.unlock();
  }
  
  public boolean put(RawEvent paramRawEvent) {
    return this.eventQueue.offer(paramRawEvent);
  }
  
  public void run() {
    // Byte code:
    //   0: invokestatic getContext : ()Landroid/content/Context;
    //   3: invokestatic getInstance : (Landroid/content/Context;)Lcom/apsalar/sdk/ApSingleton;
    //   6: astore_2
    //   7: aload_0
    //   8: invokespecial isActiveThread : ()Z
    //   11: ifeq -> 248
    //   14: aload_0
    //   15: getfield eventQueue : Ljava/util/concurrent/ArrayBlockingQueue;
    //   18: aload_2
    //   19: getfield heartbeatInterval : I
    //   22: i2l
    //   23: getstatic java/util/concurrent/TimeUnit.MILLISECONDS : Ljava/util/concurrent/TimeUnit;
    //   26: invokevirtual poll : (JLjava/util/concurrent/TimeUnit;)Ljava/lang/Object;
    //   29: checkcast com/apsalar/sdk/RawEvent
    //   32: astore_1
    //   33: aload_1
    //   34: ifnonnull -> 147
    //   37: aload_0
    //   38: invokespecial heartbeatEvent : ()Lcom/apsalar/sdk/RawEvent;
    //   41: astore_1
    //   42: aload_1
    //   43: ifnull -> 7
    //   46: aload_2
    //   47: invokevirtual getClass : ()Ljava/lang/Class;
    //   50: pop
    //   51: new android/content/ContentValues
    //   54: dup
    //   55: invokespecial <init> : ()V
    //   58: astore_3
    //   59: aload_3
    //   60: ldc 'type'
    //   62: aload_1
    //   63: getfield eventType : I
    //   66: invokestatic valueOf : (I)Ljava/lang/Integer;
    //   69: invokevirtual put : (Ljava/lang/String;Ljava/lang/Integer;)V
    //   72: aload_3
    //   73: ldc 'unix_t'
    //   75: aload_1
    //   76: getfield eventTime : J
    //   79: invokestatic valueOf : (J)Ljava/lang/Long;
    //   82: invokevirtual put : (Ljava/lang/String;Ljava/lang/Long;)V
    //   85: aload_3
    //   86: ldc 'session_json'
    //   88: aload_2
    //   89: getfield info : Lcom/apsalar/sdk/ApsalarSessionInfo;
    //   92: invokevirtual toJSON : ()Lorg/json/JSONObject;
    //   95: invokevirtual toString : ()Ljava/lang/String;
    //   98: invokevirtual put : (Ljava/lang/String;Ljava/lang/String;)V
    //   101: aload_1
    //   102: getfield eventType : I
    //   105: tableswitch default -> 132, 1 -> 180, 2 -> 180, 3 -> 158
    //   132: ldc 'Apsalar SDK/EventConsumerThread'
    //   134: ldc 'Invalid event received on queue.'
    //   136: invokestatic wtf : (Ljava/lang/String;Ljava/lang/String;)I
    //   139: pop
    //   140: goto -> 7
    //   143: astore_1
    //   144: goto -> 7
    //   147: aload_2
    //   148: aload_2
    //   149: getfield HEARTBEAT_INTERVAL_MIN : I
    //   152: putfield heartbeatInterval : I
    //   155: goto -> 46
    //   158: aload_3
    //   159: ldc_w 'name'
    //   162: aload_1
    //   163: getfield eventName : Ljava/lang/String;
    //   166: invokevirtual put : (Ljava/lang/String;Ljava/lang/String;)V
    //   169: aload_3
    //   170: ldc_w 'args'
    //   173: aload_1
    //   174: getfield eventData : Ljava/lang/String;
    //   177: invokevirtual put : (Ljava/lang/String;Ljava/lang/String;)V
    //   180: aload_2
    //   181: getfield database : Landroid/database/sqlite/SQLiteDatabase;
    //   184: ifnull -> 240
    //   187: aload_1
    //   188: getfield eventType : I
    //   191: tableswitch default -> 208, 2 -> 232
    //   208: aload_2
    //   209: getfield database : Landroid/database/sqlite/SQLiteDatabase;
    //   212: ldc 'events'
    //   214: aconst_null
    //   215: aload_3
    //   216: invokevirtual insert : (Ljava/lang/String;Ljava/lang/String;Landroid/content/ContentValues;)J
    //   219: pop2
    //   220: aload_2
    //   221: invokevirtual getClass : ()Ljava/lang/Class;
    //   224: pop
    //   225: aload_0
    //   226: invokespecial signalIncomingEvent : ()V
    //   229: goto -> 7
    //   232: aload_0
    //   233: aload_3
    //   234: invokespecial handleHeartbeat : (Landroid/content/ContentValues;)V
    //   237: goto -> 225
    //   240: aload_2
    //   241: invokevirtual getClass : ()Ljava/lang/Class;
    //   244: pop
    //   245: goto -> 7
    //   248: aload_2
    //   249: invokevirtual getClass : ()Ljava/lang/Class;
    //   252: pop
    //   253: return
    // Exception table:
    //   from	to	target	type
    //   14	33	143	java/lang/InterruptedException
  }
}


/* Location:              C:\soft\dex2jar-2.0\Smash Cricket-dex2jar.jar!\com\apsalar\sdk\ApsalarEventConsumerThread.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */