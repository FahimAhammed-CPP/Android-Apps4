package com.apsalar.sdk;

import android.content.Context;

class ApsalarHeartbeat extends ApsalarEvent implements ApsalarAPI {
  protected ApsalarHeartbeat(Context paramContext, ApsalarSessionInfo paramApsalarSessionInfo, long paramLong) {
    super(paramContext, paramApsalarSessionInfo, "heartbeat", paramLong, "");
  }
  
  protected void init(Context paramContext) {
    this.ctx = paramContext;
    this.eventType = 2;
    this.eventTime = System.currentTimeMillis();
  }
}


/* Location:              C:\soft\dex2jar-2.0\Smash Cricket-dex2jar.jar!\com\apsalar\sdk\ApsalarHeartbeat.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */