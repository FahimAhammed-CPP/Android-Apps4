package com.apsalar.sdk;

import android.content.Context;
import java.io.UnsupportedEncodingException;
import java.net.URLEncoder;
import org.json.JSONObject;

class ApsalarCanonical extends ApsalarEvent implements ApsalarAPI, ApsalarJSON {
  static final String TAG = "Apsalar SDK/Canonical";
  
  static final String supportedDeviceIds = "[ \"AIFA\", \"ANDI\" ]";
  
  protected ApsalarCanonical(Context paramContext, ApsalarSessionInfo paramApsalarSessionInfo) {
    super(paramContext, paramApsalarSessionInfo);
  }
  
  protected ApsalarCanonical(Context paramContext, ApsalarSessionInfo paramApsalarSessionInfo, JSONObject paramJSONObject) {
    super(paramContext, paramApsalarSessionInfo, paramJSONObject);
  }
  
  public int REST(Boolean paramBoolean) {
    // Byte code:
    //   0: aload_0
    //   1: getfield ctx : Landroid/content/Context;
    //   4: invokestatic getInstance : (Landroid/content/Context;)Lcom/apsalar/sdk/ApSingleton;
    //   7: astore #5
    //   9: aload #5
    //   11: invokevirtual getClass : ()Ljava/lang/Class;
    //   14: pop
    //   15: aload_0
    //   16: iconst_1
    //   17: invokevirtual makeURL : (Z)Z
    //   20: ifne -> 33
    //   23: aload #5
    //   25: invokevirtual getClass : ()Ljava/lang/Class;
    //   28: pop
    //   29: iconst_m1
    //   30: istore_2
    //   31: iload_2
    //   32: ireturn
    //   33: iconst_1
    //   34: istore_3
    //   35: new java/lang/StringBuilder
    //   38: dup
    //   39: invokespecial <init> : ()V
    //   42: aload_0
    //   43: getfield urlbase : Ljava/lang/String;
    //   46: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   49: aload_0
    //   50: getfield url : Ljava/lang/String;
    //   53: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   56: invokevirtual toString : ()Ljava/lang/String;
    //   59: astore #6
    //   61: aload #6
    //   63: invokevirtual length : ()I
    //   66: sipush #1999
    //   69: if_icmple -> 80
    //   72: aload #5
    //   74: invokevirtual getClass : ()Ljava/lang/Class;
    //   77: pop
    //   78: iconst_m1
    //   79: istore_3
    //   80: aload_0
    //   81: aconst_null
    //   82: putfield returnData : Ljava/lang/String;
    //   85: iload_3
    //   86: istore_2
    //   87: iload_3
    //   88: iconst_1
    //   89: if_icmpne -> 103
    //   92: aload_0
    //   93: aload #6
    //   95: invokestatic get : (Ljava/lang/String;)Ljava/lang/String;
    //   98: putfield returnData : Ljava/lang/String;
    //   101: iload_3
    //   102: istore_2
    //   103: aload #5
    //   105: getfield canonicalKeyspace : Ljava/lang/String;
    //   108: astore #6
    //   110: aload #5
    //   112: getfield canonicalDeviceId : Ljava/lang/String;
    //   115: astore #7
    //   117: iload_2
    //   118: istore_3
    //   119: iload_2
    //   120: iconst_1
    //   121: if_icmpne -> 188
    //   124: iload_2
    //   125: istore_3
    //   126: aload_0
    //   127: getfield returnData : Ljava/lang/String;
    //   130: ifnull -> 188
    //   133: aload #5
    //   135: invokevirtual incrSentEventsCount : ()I
    //   138: pop
    //   139: iload_2
    //   140: istore_3
    //   141: aload_1
    //   142: invokevirtual booleanValue : ()Z
    //   145: ifeq -> 188
    //   148: aload_0
    //   149: new org/json/JSONObject
    //   152: dup
    //   153: aload_0
    //   154: getfield returnData : Ljava/lang/String;
    //   157: invokespecial <init> : (Ljava/lang/String;)V
    //   160: putfield returnDataJSON : Lorg/json/JSONObject;
    //   163: aload_0
    //   164: getfield returnDataJSON : Lorg/json/JSONObject;
    //   167: ldc 'canonical'
    //   169: invokevirtual getString : (Ljava/lang/String;)Ljava/lang/String;
    //   172: invokevirtual toUpperCase : ()Ljava/lang/String;
    //   175: astore_1
    //   176: aload_1
    //   177: ifnonnull -> 391
    //   180: aload #5
    //   182: invokevirtual getClass : ()Ljava/lang/Class;
    //   185: pop
    //   186: iconst_0
    //   187: istore_3
    //   188: iload_3
    //   189: istore_2
    //   190: iload_3
    //   191: iconst_1
    //   192: if_icmpne -> 31
    //   195: aload #5
    //   197: invokevirtual getClass : ()Ljava/lang/Class;
    //   200: pop
    //   201: aload #5
    //   203: getfield playStoreAvailable : Z
    //   206: ifne -> 235
    //   209: aload #5
    //   211: getfield canonicalKeyspace : Ljava/lang/String;
    //   214: ldc 'AIFA'
    //   216: invokevirtual equals : (Ljava/lang/Object;)Z
    //   219: ifeq -> 235
    //   222: aload #5
    //   224: invokevirtual getClass : ()Ljava/lang/Class;
    //   227: pop
    //   228: aload #5
    //   230: ldc 'ANDI'
    //   232: putfield canonicalKeyspace : Ljava/lang/String;
    //   235: iload_3
    //   236: istore_2
    //   237: aload #6
    //   239: ifnull -> 31
    //   242: iload_3
    //   243: istore_2
    //   244: aload #7
    //   246: ifnull -> 31
    //   249: iload_3
    //   250: istore_2
    //   251: aload #6
    //   253: invokevirtual length : ()I
    //   256: ifle -> 31
    //   259: iload_3
    //   260: istore_2
    //   261: aload #7
    //   263: invokevirtual length : ()I
    //   266: ifle -> 31
    //   269: iload_3
    //   270: istore_2
    //   271: aload #6
    //   273: aload #5
    //   275: getfield canonicalKeyspace : Ljava/lang/String;
    //   278: invokevirtual equals : (Ljava/lang/Object;)Z
    //   281: ifne -> 31
    //   284: iload_3
    //   285: istore_2
    //   286: aload #7
    //   288: aload #5
    //   290: getfield canonicalDeviceId : Ljava/lang/String;
    //   293: invokevirtual equals : (Ljava/lang/Object;)Z
    //   296: ifne -> 31
    //   299: aload #5
    //   301: invokevirtual getClass : ()Ljava/lang/Class;
    //   304: pop
    //   305: aload #5
    //   307: iconst_0
    //   308: putfield already_did_SQL : Z
    //   311: invokestatic closeDatabase : ()V
    //   314: aload #5
    //   316: iconst_0
    //   317: putfield expires : I
    //   320: iload_3
    //   321: ireturn
    //   322: astore #6
    //   324: aload #5
    //   326: invokevirtual incrExceptionCount : ()I
    //   329: pop
    //   330: aload #5
    //   332: invokevirtual getClass : ()Ljava/lang/Class;
    //   335: pop
    //   336: iconst_0
    //   337: istore_2
    //   338: goto -> 103
    //   341: astore #6
    //   343: aload #5
    //   345: invokevirtual incrExceptionCount : ()I
    //   348: pop
    //   349: aload #5
    //   351: invokevirtual getClass : ()Ljava/lang/Class;
    //   354: pop
    //   355: iconst_0
    //   356: istore_2
    //   357: aload #5
    //   359: invokevirtual incrNetworkErrorCount : ()I
    //   362: pop
    //   363: goto -> 103
    //   366: astore #6
    //   368: aload #5
    //   370: invokevirtual incrExceptionCount : ()I
    //   373: pop
    //   374: aload #5
    //   376: invokevirtual getClass : ()Ljava/lang/Class;
    //   379: pop
    //   380: iconst_0
    //   381: istore_2
    //   382: aload #5
    //   384: invokevirtual incrNetworkErrorCount : ()I
    //   387: pop
    //   388: goto -> 103
    //   391: aload #5
    //   393: getfield playStoreAvailable : Z
    //   396: ifne -> 1477
    //   399: aload #5
    //   401: getfield canonicalKeyspace : Ljava/lang/String;
    //   404: ldc 'AIFA'
    //   406: invokevirtual equals : (Ljava/lang/Object;)Z
    //   409: ifeq -> 1477
    //   412: aload #5
    //   414: invokevirtual getClass : ()Ljava/lang/Class;
    //   417: pop
    //   418: aload #5
    //   420: ldc 'ANDI'
    //   422: putfield canonicalKeyspace : Ljava/lang/String;
    //   425: aload #5
    //   427: aload #5
    //   429: getfield canonicalKeyspace : Ljava/lang/String;
    //   432: invokestatic getDeviceId : (Ljava/lang/String;)Ljava/lang/String;
    //   435: putfield canonicalDeviceId : Ljava/lang/String;
    //   438: aload #5
    //   440: invokevirtual getClass : ()Ljava/lang/Class;
    //   443: pop
    //   444: aload #5
    //   446: aload_0
    //   447: getfield returnDataJSON : Lorg/json/JSONObject;
    //   450: ldc 'expires'
    //   452: invokevirtual getString : (Ljava/lang/String;)Ljava/lang/String;
    //   455: invokestatic valueOf : (Ljava/lang/String;)Ljava/lang/Integer;
    //   458: invokevirtual intValue : ()I
    //   461: putfield expires : I
    //   464: aload #5
    //   466: getfield expires : I
    //   469: ifge -> 478
    //   472: aload #5
    //   474: iconst_0
    //   475: putfield expires : I
    //   478: aload #5
    //   480: getfield expires : I
    //   483: sipush #300
    //   486: if_icmple -> 497
    //   489: aload #5
    //   491: sipush #300
    //   494: putfield expires : I
    //   497: aload #5
    //   499: aload_0
    //   500: getfield returnDataJSON : Lorg/json/JSONObject;
    //   503: ldc 'shtsleep'
    //   505: invokevirtual getString : (Ljava/lang/String;)Ljava/lang/String;
    //   508: invokestatic valueOf : (Ljava/lang/String;)Ljava/lang/Integer;
    //   511: invokevirtual intValue : ()I
    //   514: putfield SHORTSLEEP : I
    //   517: aload #5
    //   519: getfield SHORTSLEEP : I
    //   522: iconst_1
    //   523: if_icmpge -> 532
    //   526: aload #5
    //   528: iconst_1
    //   529: putfield SHORTSLEEP : I
    //   532: aload #5
    //   534: getfield SHORTSLEEP : I
    //   537: sipush #10000
    //   540: if_icmple -> 551
    //   543: aload #5
    //   545: sipush #10000
    //   548: putfield SHORTSLEEP : I
    //   551: aload #5
    //   553: aload_0
    //   554: getfield returnDataJSON : Lorg/json/JSONObject;
    //   557: ldc 'medsleep'
    //   559: invokevirtual getString : (Ljava/lang/String;)Ljava/lang/String;
    //   562: invokestatic valueOf : (Ljava/lang/String;)Ljava/lang/Integer;
    //   565: invokevirtual intValue : ()I
    //   568: putfield MEDIUMSLEEP : I
    //   571: aload #5
    //   573: getfield MEDIUMSLEEP : I
    //   576: iconst_1
    //   577: if_icmpge -> 586
    //   580: aload #5
    //   582: iconst_1
    //   583: putfield MEDIUMSLEEP : I
    //   586: aload #5
    //   588: getfield MEDIUMSLEEP : I
    //   591: ldc 60000
    //   593: if_icmple -> 603
    //   596: aload #5
    //   598: ldc 60000
    //   600: putfield MEDIUMSLEEP : I
    //   603: aload #5
    //   605: aload_0
    //   606: getfield returnDataJSON : Lorg/json/JSONObject;
    //   609: ldc 'lngsleep'
    //   611: invokevirtual getString : (Ljava/lang/String;)Ljava/lang/String;
    //   614: invokestatic valueOf : (Ljava/lang/String;)Ljava/lang/Integer;
    //   617: invokevirtual intValue : ()I
    //   620: putfield LONGSLEEP : I
    //   623: aload #5
    //   625: getfield LONGSLEEP : I
    //   628: iconst_1
    //   629: if_icmpge -> 638
    //   632: aload #5
    //   634: iconst_1
    //   635: putfield LONGSLEEP : I
    //   638: aload #5
    //   640: getfield LONGSLEEP : I
    //   643: ldc 900000
    //   645: if_icmple -> 655
    //   648: aload #5
    //   650: ldc 900000
    //   652: putfield LONGSLEEP : I
    //   655: aload #5
    //   657: aload_0
    //   658: getfield returnDataJSON : Lorg/json/JSONObject;
    //   661: ldc 'xlnsleep'
    //   663: invokevirtual getString : (Ljava/lang/String;)Ljava/lang/String;
    //   666: invokestatic valueOf : (Ljava/lang/String;)Ljava/lang/Integer;
    //   669: invokevirtual intValue : ()I
    //   672: putfield VERYLONGSLEEP : I
    //   675: aload #5
    //   677: getfield LONGSLEEP : I
    //   680: iconst_1
    //   681: if_icmpge -> 690
    //   684: aload #5
    //   686: iconst_1
    //   687: putfield LONGSLEEP : I
    //   690: aload #5
    //   692: getfield LONGSLEEP : I
    //   695: ldc 2700000
    //   697: if_icmple -> 707
    //   700: aload #5
    //   702: ldc 2700000
    //   704: putfield LONGSLEEP : I
    //   707: aload_0
    //   708: getfield returnDataJSON : Lorg/json/JSONObject;
    //   711: ldc 'resolveall'
    //   713: invokevirtual getString : (Ljava/lang/String;)Ljava/lang/String;
    //   716: invokestatic valueOf : (Ljava/lang/String;)Ljava/lang/Integer;
    //   719: invokevirtual intValue : ()I
    //   722: ifeq -> 1522
    //   725: iconst_1
    //   726: istore #4
    //   728: aload #5
    //   730: iload #4
    //   732: putfield RESOLVE_ALL_AVAILABLE : Z
    //   735: aload_0
    //   736: getfield returnDataJSON : Lorg/json/JSONObject;
    //   739: ldc 'alwayscanon'
    //   741: invokevirtual getString : (Ljava/lang/String;)Ljava/lang/String;
    //   744: invokestatic valueOf : (Ljava/lang/String;)Ljava/lang/Integer;
    //   747: invokevirtual intValue : ()I
    //   750: ifeq -> 1528
    //   753: iconst_1
    //   754: istore #4
    //   756: aload #5
    //   758: iload #4
    //   760: putfield ALWAYS_REQUEST_CANONICAL : Z
    //   763: aload #5
    //   765: aload_0
    //   766: getfield returnDataJSON : Lorg/json/JSONObject;
    //   769: ldc 'evb4sleep'
    //   771: invokevirtual getString : (Ljava/lang/String;)Ljava/lang/String;
    //   774: invokestatic valueOf : (Ljava/lang/String;)Ljava/lang/Integer;
    //   777: invokevirtual intValue : ()I
    //   780: putfield NUM_EVENTS_B4_SLEEP : I
    //   783: aload #5
    //   785: getfield NUM_EVENTS_B4_SLEEP : I
    //   788: iconst_1
    //   789: if_icmpge -> 798
    //   792: aload #5
    //   794: iconst_1
    //   795: putfield NUM_EVENTS_B4_SLEEP : I
    //   798: aload #5
    //   800: getfield NUM_EVENTS_B4_SLEEP : I
    //   803: sipush #1000
    //   806: if_icmple -> 817
    //   809: aload #5
    //   811: sipush #1000
    //   814: putfield NUM_EVENTS_B4_SLEEP : I
    //   817: aload #5
    //   819: aload_0
    //   820: getfield returnDataJSON : Lorg/json/JSONObject;
    //   823: ldc 'qsizemax'
    //   825: invokevirtual getString : (Ljava/lang/String;)Ljava/lang/String;
    //   828: invokestatic valueOf : (Ljava/lang/String;)Ljava/lang/Integer;
    //   831: invokevirtual intValue : ()I
    //   834: putfield QUEUE_SIZE_MAX : I
    //   837: aload #5
    //   839: getfield QUEUE_SIZE_MAX : I
    //   842: iconst_1
    //   843: if_icmpge -> 852
    //   846: aload #5
    //   848: iconst_1
    //   849: putfield QUEUE_SIZE_MAX : I
    //   852: aload #5
    //   854: getfield QUEUE_SIZE_MAX : I
    //   857: sipush #10000
    //   860: if_icmple -> 871
    //   863: aload #5
    //   865: sipush #10000
    //   868: putfield QUEUE_SIZE_MAX : I
    //   871: aload #5
    //   873: aload_0
    //   874: getfield returnDataJSON : Lorg/json/JSONObject;
    //   877: ldc 'bsizemax'
    //   879: invokevirtual getString : (Ljava/lang/String;)Ljava/lang/String;
    //   882: invokestatic valueOf : (Ljava/lang/String;)Ljava/lang/Integer;
    //   885: invokevirtual intValue : ()I
    //   888: putfield BUFFER_SIZE_MAX : I
    //   891: aload #5
    //   893: getfield BUFFER_SIZE_MAX : I
    //   896: iconst_1
    //   897: if_icmpge -> 906
    //   900: aload #5
    //   902: iconst_1
    //   903: putfield BUFFER_SIZE_MAX : I
    //   906: aload #5
    //   908: getfield BUFFER_SIZE_MAX : I
    //   911: sipush #10000
    //   914: if_icmple -> 925
    //   917: aload #5
    //   919: sipush #10000
    //   922: putfield BUFFER_SIZE_MAX : I
    //   925: aload #5
    //   927: aload_0
    //   928: getfield returnDataJSON : Lorg/json/JSONObject;
    //   931: ldc 'hrtbackoff'
    //   933: invokevirtual getString : (Ljava/lang/String;)Ljava/lang/String;
    //   936: invokestatic valueOf : (Ljava/lang/String;)Ljava/lang/Integer;
    //   939: invokevirtual intValue : ()I
    //   942: putfield HEARTBEAT_INTERVAL_BACKOFF : I
    //   945: aload #5
    //   947: getfield HEARTBEAT_INTERVAL_BACKOFF : I
    //   950: iconst_1
    //   951: if_icmpge -> 960
    //   954: aload #5
    //   956: iconst_1
    //   957: putfield HEARTBEAT_INTERVAL_BACKOFF : I
    //   960: aload #5
    //   962: getfield HEARTBEAT_INTERVAL_BACKOFF : I
    //   965: sipush #1000
    //   968: if_icmple -> 979
    //   971: aload #5
    //   973: sipush #1000
    //   976: putfield HEARTBEAT_INTERVAL_BACKOFF : I
    //   979: aload #5
    //   981: aload_0
    //   982: getfield returnDataJSON : Lorg/json/JSONObject;
    //   985: ldc 'hrtintmax'
    //   987: invokevirtual getString : (Ljava/lang/String;)Ljava/lang/String;
    //   990: invokestatic valueOf : (Ljava/lang/String;)Ljava/lang/Integer;
    //   993: invokevirtual intValue : ()I
    //   996: putfield HEARTBEAT_INTERVAL_MAX : I
    //   999: aload #5
    //   1001: getfield HEARTBEAT_INTERVAL_MAX : I
    //   1004: iconst_1
    //   1005: if_icmpge -> 1014
    //   1008: aload #5
    //   1010: iconst_1
    //   1011: putfield HEARTBEAT_INTERVAL_MAX : I
    //   1014: aload #5
    //   1016: getfield HEARTBEAT_INTERVAL_MAX : I
    //   1019: ldc 100000000
    //   1021: if_icmple -> 1031
    //   1024: aload #5
    //   1026: ldc 100000000
    //   1028: putfield HEARTBEAT_INTERVAL_MAX : I
    //   1031: aload #5
    //   1033: aload_0
    //   1034: getfield returnDataJSON : Lorg/json/JSONObject;
    //   1037: ldc 'hrtintmin'
    //   1039: invokevirtual getString : (Ljava/lang/String;)Ljava/lang/String;
    //   1042: invokestatic valueOf : (Ljava/lang/String;)Ljava/lang/Integer;
    //   1045: invokevirtual intValue : ()I
    //   1048: putfield HEARTBEAT_INTERVAL_MIN : I
    //   1051: aload #5
    //   1053: getfield HEARTBEAT_INTERVAL_MIN : I
    //   1056: ldc 10000000
    //   1058: if_icmple -> 1068
    //   1061: aload #5
    //   1063: ldc 10000000
    //   1065: putfield HEARTBEAT_INTERVAL_MIN : I
    //   1068: aload #5
    //   1070: getfield HEARTBEAT_INTERVAL_MIN : I
    //   1073: aload #5
    //   1075: getfield HEARTBEAT_INTERVAL_MAX : I
    //   1078: if_icmple -> 1093
    //   1081: aload #5
    //   1083: aload #5
    //   1085: getfield HEARTBEAT_INTERVAL_MAX : I
    //   1088: iconst_1
    //   1089: isub
    //   1090: putfield HEARTBEAT_INTERVAL_MIN : I
    //   1093: aload #5
    //   1095: getfield HEARTBEAT_INTERVAL_MIN : I
    //   1098: iconst_1
    //   1099: if_icmpge -> 1108
    //   1102: aload #5
    //   1104: iconst_1
    //   1105: putfield HEARTBEAT_INTERVAL_MIN : I
    //   1108: aload #5
    //   1110: aload_0
    //   1111: getfield returnDataJSON : Lorg/json/JSONObject;
    //   1114: ldc 'retbackoff'
    //   1116: invokevirtual getString : (Ljava/lang/String;)Ljava/lang/String;
    //   1119: invokestatic valueOf : (Ljava/lang/String;)Ljava/lang/Integer;
    //   1122: invokevirtual intValue : ()I
    //   1125: putfield RETRY_INTERVAL_BACKOFF : I
    //   1128: aload #5
    //   1130: getfield RETRY_INTERVAL_BACKOFF : I
    //   1133: iconst_1
    //   1134: if_icmpge -> 1143
    //   1137: aload #5
    //   1139: iconst_1
    //   1140: putfield RETRY_INTERVAL_BACKOFF : I
    //   1143: aload #5
    //   1145: getfield RETRY_INTERVAL_BACKOFF : I
    //   1148: sipush #1000
    //   1151: if_icmple -> 1162
    //   1154: aload #5
    //   1156: sipush #1000
    //   1159: putfield RETRY_INTERVAL_BACKOFF : I
    //   1162: aload #5
    //   1164: aload_0
    //   1165: getfield returnDataJSON : Lorg/json/JSONObject;
    //   1168: ldc 'retintmax'
    //   1170: invokevirtual getString : (Ljava/lang/String;)Ljava/lang/String;
    //   1173: invokestatic valueOf : (Ljava/lang/String;)Ljava/lang/Integer;
    //   1176: invokevirtual intValue : ()I
    //   1179: putfield RETRY_INTERVAL_MAX : I
    //   1182: aload #5
    //   1184: getfield RETRY_INTERVAL_MAX : I
    //   1187: iconst_1
    //   1188: if_icmpge -> 1197
    //   1191: aload #5
    //   1193: iconst_1
    //   1194: putfield RETRY_INTERVAL_MAX : I
    //   1197: aload #5
    //   1199: getfield RETRY_INTERVAL_MAX : I
    //   1202: ldc 100000000
    //   1204: if_icmple -> 1214
    //   1207: aload #5
    //   1209: ldc 100000000
    //   1211: putfield RETRY_INTERVAL_MAX : I
    //   1214: aload #5
    //   1216: aload_0
    //   1217: getfield returnDataJSON : Lorg/json/JSONObject;
    //   1220: ldc 'retintmin'
    //   1222: invokevirtual getString : (Ljava/lang/String;)Ljava/lang/String;
    //   1225: invokestatic valueOf : (Ljava/lang/String;)Ljava/lang/Integer;
    //   1228: invokevirtual intValue : ()I
    //   1231: putfield RETRY_INTERVAL_MIN : I
    //   1234: aload #5
    //   1236: getfield RETRY_INTERVAL_MIN : I
    //   1239: ldc 10000000
    //   1241: if_icmple -> 1251
    //   1244: aload #5
    //   1246: ldc 10000000
    //   1248: putfield RETRY_INTERVAL_MIN : I
    //   1251: aload #5
    //   1253: getfield RETRY_INTERVAL_MIN : I
    //   1256: aload #5
    //   1258: getfield RETRY_INTERVAL_MAX : I
    //   1261: if_icmple -> 1276
    //   1264: aload #5
    //   1266: aload #5
    //   1268: getfield RETRY_INTERVAL_MAX : I
    //   1271: iconst_1
    //   1272: isub
    //   1273: putfield RETRY_INTERVAL_MIN : I
    //   1276: aload #5
    //   1278: getfield RETRY_INTERVAL_MIN : I
    //   1281: iconst_1
    //   1282: if_icmpge -> 1291
    //   1285: aload #5
    //   1287: iconst_1
    //   1288: putfield RETRY_INTERVAL_MIN : I
    //   1291: aload #5
    //   1293: aload_0
    //   1294: getfield returnDataJSON : Lorg/json/JSONObject;
    //   1297: ldc 'batmax'
    //   1299: invokevirtual getString : (Ljava/lang/String;)Ljava/lang/String;
    //   1302: invokestatic valueOf : (Ljava/lang/String;)Ljava/lang/Integer;
    //   1305: invokevirtual intValue : ()I
    //   1308: putfield BATCHES_MAX : I
    //   1311: aload #5
    //   1313: getfield BATCHES_MAX : I
    //   1316: iconst_1
    //   1317: if_icmpge -> 1326
    //   1320: aload #5
    //   1322: iconst_1
    //   1323: putfield BATCHES_MAX : I
    //   1326: aload #5
    //   1328: getfield BATCHES_MAX : I
    //   1331: sipush #10000
    //   1334: if_icmple -> 1345
    //   1337: aload #5
    //   1339: sipush #10000
    //   1342: putfield BATCHES_MAX : I
    //   1345: aload #5
    //   1347: aload_0
    //   1348: getfield returnDataJSON : Lorg/json/JSONObject;
    //   1351: ldc_w 'batint'
    //   1354: invokevirtual getString : (Ljava/lang/String;)Ljava/lang/String;
    //   1357: invokestatic valueOf : (Ljava/lang/String;)Ljava/lang/Integer;
    //   1360: invokevirtual intValue : ()I
    //   1363: putfield BATCHES_INTERVAL : I
    //   1366: aload #5
    //   1368: getfield BATCHES_INTERVAL : I
    //   1371: ifge -> 1380
    //   1374: aload #5
    //   1376: iconst_0
    //   1377: putfield BATCHES_INTERVAL : I
    //   1380: aload #5
    //   1382: getfield BATCHES_INTERVAL : I
    //   1385: sipush #3600
    //   1388: if_icmple -> 1399
    //   1391: aload #5
    //   1393: sipush #3600
    //   1396: putfield BATCHES_INTERVAL : I
    //   1399: aload #5
    //   1401: aload_0
    //   1402: getfield returnDataJSON : Lorg/json/JSONObject;
    //   1405: ldc_w 'resmax'
    //   1408: invokevirtual getString : (Ljava/lang/String;)Ljava/lang/String;
    //   1411: invokestatic valueOf : (Ljava/lang/String;)Ljava/lang/Integer;
    //   1414: invokevirtual intValue : ()I
    //   1417: putfield RESOLVER_MAX : I
    //   1420: aload #5
    //   1422: getfield RESOLVER_MAX : I
    //   1425: iconst_1
    //   1426: if_icmpge -> 1435
    //   1429: aload #5
    //   1431: iconst_1
    //   1432: putfield RESOLVER_MAX : I
    //   1435: iload_2
    //   1436: istore_3
    //   1437: aload #5
    //   1439: getfield RESOLVER_MAX : I
    //   1442: bipush #100
    //   1444: if_icmple -> 188
    //   1447: aload #5
    //   1449: bipush #100
    //   1451: putfield RESOLVER_MAX : I
    //   1454: iload_2
    //   1455: istore_3
    //   1456: goto -> 188
    //   1459: astore_1
    //   1460: aload #5
    //   1462: invokevirtual incrExceptionCount : ()I
    //   1465: pop
    //   1466: aload #5
    //   1468: invokevirtual getClass : ()Ljava/lang/Class;
    //   1471: pop
    //   1472: iconst_1
    //   1473: istore_3
    //   1474: goto -> 188
    //   1477: aload #5
    //   1479: aload_1
    //   1480: putfield canonicalKeyspace : Ljava/lang/String;
    //   1483: goto -> 425
    //   1486: astore_1
    //   1487: aload #5
    //   1489: invokevirtual incrExceptionCount : ()I
    //   1492: pop
    //   1493: aload #5
    //   1495: invokevirtual getClass : ()Ljava/lang/Class;
    //   1498: pop
    //   1499: iload_2
    //   1500: istore_3
    //   1501: goto -> 188
    //   1504: astore_1
    //   1505: aload #5
    //   1507: invokevirtual incrExceptionCount : ()I
    //   1510: pop
    //   1511: aload #5
    //   1513: invokevirtual getClass : ()Ljava/lang/Class;
    //   1516: pop
    //   1517: iconst_0
    //   1518: istore_3
    //   1519: goto -> 188
    //   1522: iconst_0
    //   1523: istore #4
    //   1525: goto -> 728
    //   1528: iconst_0
    //   1529: istore #4
    //   1531: goto -> 756
    //   1534: astore_1
    //   1535: aload #5
    //   1537: invokevirtual incrExceptionCount : ()I
    //   1540: pop
    //   1541: aload #5
    //   1543: invokevirtual getClass : ()Ljava/lang/Class;
    //   1546: pop
    //   1547: invokestatic closeDatabase : ()V
    //   1550: goto -> 314
    //   1553: astore_1
    //   1554: invokestatic closeDatabase : ()V
    //   1557: aload_1
    //   1558: athrow
    // Exception table:
    //   from	to	target	type
    //   92	101	322	java/net/ProtocolException
    //   92	101	341	java/net/SocketTimeoutException
    //   92	101	366	java/io/IOException
    //   148	163	1504	java/lang/Throwable
    //   163	176	1459	org/json/JSONException
    //   163	176	1486	java/lang/NumberFormatException
    //   163	176	1504	java/lang/Throwable
    //   180	186	1459	org/json/JSONException
    //   180	186	1486	java/lang/NumberFormatException
    //   180	186	1504	java/lang/Throwable
    //   299	311	1534	java/lang/Exception
    //   299	311	1553	finally
    //   391	425	1459	org/json/JSONException
    //   391	425	1486	java/lang/NumberFormatException
    //   391	425	1504	java/lang/Throwable
    //   425	478	1459	org/json/JSONException
    //   425	478	1486	java/lang/NumberFormatException
    //   425	478	1504	java/lang/Throwable
    //   478	497	1459	org/json/JSONException
    //   478	497	1486	java/lang/NumberFormatException
    //   478	497	1504	java/lang/Throwable
    //   497	532	1459	org/json/JSONException
    //   497	532	1486	java/lang/NumberFormatException
    //   497	532	1504	java/lang/Throwable
    //   532	551	1459	org/json/JSONException
    //   532	551	1486	java/lang/NumberFormatException
    //   532	551	1504	java/lang/Throwable
    //   551	586	1459	org/json/JSONException
    //   551	586	1486	java/lang/NumberFormatException
    //   551	586	1504	java/lang/Throwable
    //   586	603	1459	org/json/JSONException
    //   586	603	1486	java/lang/NumberFormatException
    //   586	603	1504	java/lang/Throwable
    //   603	638	1459	org/json/JSONException
    //   603	638	1486	java/lang/NumberFormatException
    //   603	638	1504	java/lang/Throwable
    //   638	655	1459	org/json/JSONException
    //   638	655	1486	java/lang/NumberFormatException
    //   638	655	1504	java/lang/Throwable
    //   655	690	1459	org/json/JSONException
    //   655	690	1486	java/lang/NumberFormatException
    //   655	690	1504	java/lang/Throwable
    //   690	707	1459	org/json/JSONException
    //   690	707	1486	java/lang/NumberFormatException
    //   690	707	1504	java/lang/Throwable
    //   707	725	1459	org/json/JSONException
    //   707	725	1486	java/lang/NumberFormatException
    //   707	725	1504	java/lang/Throwable
    //   728	753	1459	org/json/JSONException
    //   728	753	1486	java/lang/NumberFormatException
    //   728	753	1504	java/lang/Throwable
    //   756	798	1459	org/json/JSONException
    //   756	798	1486	java/lang/NumberFormatException
    //   756	798	1504	java/lang/Throwable
    //   798	817	1459	org/json/JSONException
    //   798	817	1486	java/lang/NumberFormatException
    //   798	817	1504	java/lang/Throwable
    //   817	852	1459	org/json/JSONException
    //   817	852	1486	java/lang/NumberFormatException
    //   817	852	1504	java/lang/Throwable
    //   852	871	1459	org/json/JSONException
    //   852	871	1486	java/lang/NumberFormatException
    //   852	871	1504	java/lang/Throwable
    //   871	906	1459	org/json/JSONException
    //   871	906	1486	java/lang/NumberFormatException
    //   871	906	1504	java/lang/Throwable
    //   906	925	1459	org/json/JSONException
    //   906	925	1486	java/lang/NumberFormatException
    //   906	925	1504	java/lang/Throwable
    //   925	960	1459	org/json/JSONException
    //   925	960	1486	java/lang/NumberFormatException
    //   925	960	1504	java/lang/Throwable
    //   960	979	1459	org/json/JSONException
    //   960	979	1486	java/lang/NumberFormatException
    //   960	979	1504	java/lang/Throwable
    //   979	1014	1459	org/json/JSONException
    //   979	1014	1486	java/lang/NumberFormatException
    //   979	1014	1504	java/lang/Throwable
    //   1014	1031	1459	org/json/JSONException
    //   1014	1031	1486	java/lang/NumberFormatException
    //   1014	1031	1504	java/lang/Throwable
    //   1031	1068	1459	org/json/JSONException
    //   1031	1068	1486	java/lang/NumberFormatException
    //   1031	1068	1504	java/lang/Throwable
    //   1068	1093	1459	org/json/JSONException
    //   1068	1093	1486	java/lang/NumberFormatException
    //   1068	1093	1504	java/lang/Throwable
    //   1093	1108	1459	org/json/JSONException
    //   1093	1108	1486	java/lang/NumberFormatException
    //   1093	1108	1504	java/lang/Throwable
    //   1108	1143	1459	org/json/JSONException
    //   1108	1143	1486	java/lang/NumberFormatException
    //   1108	1143	1504	java/lang/Throwable
    //   1143	1162	1459	org/json/JSONException
    //   1143	1162	1486	java/lang/NumberFormatException
    //   1143	1162	1504	java/lang/Throwable
    //   1162	1197	1459	org/json/JSONException
    //   1162	1197	1486	java/lang/NumberFormatException
    //   1162	1197	1504	java/lang/Throwable
    //   1197	1214	1459	org/json/JSONException
    //   1197	1214	1486	java/lang/NumberFormatException
    //   1197	1214	1504	java/lang/Throwable
    //   1214	1251	1459	org/json/JSONException
    //   1214	1251	1486	java/lang/NumberFormatException
    //   1214	1251	1504	java/lang/Throwable
    //   1251	1276	1459	org/json/JSONException
    //   1251	1276	1486	java/lang/NumberFormatException
    //   1251	1276	1504	java/lang/Throwable
    //   1276	1291	1459	org/json/JSONException
    //   1276	1291	1486	java/lang/NumberFormatException
    //   1276	1291	1504	java/lang/Throwable
    //   1291	1326	1459	org/json/JSONException
    //   1291	1326	1486	java/lang/NumberFormatException
    //   1291	1326	1504	java/lang/Throwable
    //   1326	1345	1459	org/json/JSONException
    //   1326	1345	1486	java/lang/NumberFormatException
    //   1326	1345	1504	java/lang/Throwable
    //   1345	1380	1459	org/json/JSONException
    //   1345	1380	1486	java/lang/NumberFormatException
    //   1345	1380	1504	java/lang/Throwable
    //   1380	1399	1459	org/json/JSONException
    //   1380	1399	1486	java/lang/NumberFormatException
    //   1380	1399	1504	java/lang/Throwable
    //   1399	1435	1459	org/json/JSONException
    //   1399	1435	1486	java/lang/NumberFormatException
    //   1399	1435	1504	java/lang/Throwable
    //   1437	1454	1459	org/json/JSONException
    //   1437	1454	1486	java/lang/NumberFormatException
    //   1437	1454	1504	java/lang/Throwable
    //   1460	1472	1504	java/lang/Throwable
    //   1477	1483	1459	org/json/JSONException
    //   1477	1483	1486	java/lang/NumberFormatException
    //   1477	1483	1504	java/lang/Throwable
    //   1487	1499	1504	java/lang/Throwable
    //   1535	1547	1553	finally
  }
  
  protected void init(Context paramContext) {
    this.ctx = paramContext;
    this.urlbase = "http://e.apsalar.com/api/v1/canonical";
    this.eventType = 6;
  }
  
  protected boolean makeURL(boolean paramBoolean) {
    ApSingleton apSingleton = ApSingleton.getInstance(this.ctx);
    apSingleton.getClass();
    try {
      String str = "?a=" + URLEncoder.encode(this.info.apiKey, "UTF-8") + "&br=" + URLEncoder.encode(this.info.brand, "UTF-8") + "&c=" + URLEncoder.encode(this.info.connType, "UTF-8") + "&de=" + URLEncoder.encode(this.info.device, "UTF-8") + "&ma=" + URLEncoder.encode(this.info.manufacturer, "UTF-8") + "&mo=" + URLEncoder.encode(this.info.model, "UTF-8") + "&n=" + URLEncoder.encode(this.info.appName, "UTF-8") + "&p=" + URLEncoder.encode(this.info.platform, "UTF-8") + "&pr=" + URLEncoder.encode(this.info.product, "UTF-8") + "&sdk=" + URLEncoder.encode("Apsalar/" + this.info.sdkVersion, "UTF-8") + "&v=" + URLEncoder.encode(this.info.osVersion, "UTF-8") + "&sup=" + URLEncoder.encode("[ \"AIFA\", \"ANDI\" ]", "UTF-8") + "&ps=" + URLEncoder.encode(String.valueOf(apSingleton.playStoreAvailable), "UTF-8");
      this.url = str;
      if (this.url.length() >= 1999) {
        apSingleton.getClass();
        return false;
      } 
    } catch (UnsupportedEncodingException unsupportedEncodingException) {
      apSingleton.incrExceptionCount();
      apSingleton.getClass();
      return false;
    } 
    return true;
  }
}


/* Location:              C:\soft\dex2jar-2.0\Smash Cricket-dex2jar.jar!\com\apsalar\sdk\ApsalarCanonical.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */