package com.apsalar.sdk;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.ActivityInfo;
import android.content.pm.ResolveInfo;
import java.io.UnsupportedEncodingException;
import java.net.URLDecoder;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;

public class ApsalarReceiver extends BroadcastReceiver {
  static final String TAG = "Apsalar SDK/Receiver";
  
  private boolean invokeStartSession(Context paramContext) {
    paramContext = paramContext.getApplicationContext();
    ApSingleton apSingleton = ApSingleton.getInstance(paramContext);
    apSingleton.ctx = paramContext;
    apSingleton.apsalar_receiver = this;
    return false;
  }
  
  public static Map<String, String> retrieveCSIReferrer(Context paramContext) {
    HashMap<Object, Object> hashMap = new HashMap<Object, Object>();
    if (paramContext != null) {
      String str = paramContext.getPackageName();
      SharedPreferences sharedPreferences = paramContext.getSharedPreferences("apsalar_csi_" + str, 0);
      for (String str1 : sharedPreferences.getAll().keySet()) {
        String str2 = sharedPreferences.getString(str1, null);
        if (str2 != null)
          hashMap.put(str1, str2); 
      } 
    } 
    return (Map)hashMap;
  }
  
  public static void saveCSIReferrer(Context paramContext, String paramString) {
    if (paramContext != null) {
      String str = paramContext.getPackageName();
      SharedPreferences.Editor editor = paramContext.getSharedPreferences("apsalar_csi_" + str, 0).edit();
      editor.putString("referrer", paramString);
      editor.commit();
    } 
  }
  
  public void onReceive(Context paramContext, Intent paramIntent) {
    String str = paramIntent.getAction();
    if (str.equals("android.net.conn.CONNECTIVITY_CHANGE")) {
      paramIntent.getStringExtra("extraInfo");
      AlarmClock.interrupt();
    } 
    paramIntent.setComponent(null);
    Iterator iterator = paramContext.getPackageManager().queryBroadcastReceivers(paramIntent, 0).iterator();
    while (true) {
      if (iterator.hasNext()) {
        ActivityInfo activityInfo = ((ResolveInfo)iterator.next()).activityInfo;
        if (activityInfo.enabled && activityInfo.exported && activityInfo.packageName.equals(paramContext.getPackageName())) {
          String str1 = activityInfo.name;
          if (activityInfo.name.equals(getClass().getName())) {
            if (str.equals("com.android.vending.INSTALL_REFERRER")) {
              str1 = paramIntent.getStringExtra("referrer");
              if (str1 != null && str1.length() != 0) {
                try {
                  str1 = URLDecoder.decode(str1, "UTF-8");
                  saveCSIReferrer(paramContext, str1);
                } catch (UnsupportedEncodingException unsupportedEncodingException) {
                  return;
                } 
                continue;
              } 
              return;
            } 
            continue;
          } 
          try {
            BroadcastReceiver broadcastReceiver = (BroadcastReceiver)Class.forName(str1).newInstance();
            paramIntent.setClassName((Context)unsupportedEncodingException, str1);
            broadcastReceiver.onReceive((Context)unsupportedEncodingException, paramIntent);
          } catch (Throwable throwable) {}
        } 
        continue;
      } 
      return;
    } 
  }
}


/* Location:              C:\soft\dex2jar-2.0\Smash Cricket-dex2jar.jar!\com\apsalar\sdk\ApsalarReceiver.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */