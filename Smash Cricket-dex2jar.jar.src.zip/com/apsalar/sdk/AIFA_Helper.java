package com.apsalar.sdk;

import android.content.Context;
import android.content.ReceiverCallNotAllowedException;
import com.google.android.gms.ads.identifier.AdvertisingIdClient;
import com.google.android.gms.common.GooglePlayServicesNotAvailableException;
import com.google.android.gms.common.GooglePlayServicesRepairableException;
import java.io.IOException;

class AIFA_Helper {
  static final String TAG = "Apsalar SDK/AIFA_Helper";
  
  public static String getAIFA() {
    Context context = ApSingleton.getContext();
    ApSingleton apSingleton = ApSingleton.getInstance(context);
    apSingleton.playStoreAvailable = googleServicesOk(context);
    if (!apSingleton.playStoreAvailable)
      return ""; 
    try {
      AdvertisingIdClient.Info info = AdvertisingIdClient.getAdvertisingIdInfo(context);
      apSingleton.isLAT = info.isLimitAdTrackingEnabled();
      return info.getId();
    } catch (IOException iOException) {
      apSingleton.incrExceptionCount();
      apSingleton.getClass();
      return "";
    } catch (GooglePlayServicesNotAvailableException googlePlayServicesNotAvailableException) {
      apSingleton.incrExceptionCount();
      apSingleton.getClass();
      return "";
    } catch (GooglePlayServicesRepairableException googlePlayServicesRepairableException) {
      apSingleton.incrExceptionCount();
      apSingleton.getClass();
      return "";
    } catch (ReceiverCallNotAllowedException receiverCallNotAllowedException) {
      apSingleton.incrExceptionCount();
      apSingleton.getClass();
      return (apSingleton.AIFA != null) ? apSingleton.AIFA : "";
    } catch (Exception exception) {
      apSingleton.incrExceptionCount();
      apSingleton.getClass();
      return (apSingleton.AIFA != null) ? apSingleton.AIFA : "";
    } 
  }
  
  public static boolean googleServicesOk(Context paramContext) {
    boolean bool1;
    boolean bool2 = true;
    ApSingleton apSingleton = ApSingleton.getInstance(paramContext);
    apSingleton.getClass();
    try {
      Class.forName("com.google.android.gms.ads.identifier.AdvertisingIdClient");
      apSingleton.getClass();
      bool1 = true;
    } catch (ClassNotFoundException classNotFoundException) {
      apSingleton.getClass();
      bool1 = false;
    } catch (Exception exception) {
      apSingleton.getClass();
      bool1 = false;
    } 
    apSingleton.ctx = paramContext;
    if (bool1 != true)
      bool2 = false; 
    apSingleton.playStoreAvailable = bool2;
    apSingleton.getClass();
    if (!apSingleton.playStoreAvailable && apSingleton.canonicalKeyspace.equals("AIFA")) {
      apSingleton.getClass();
      apSingleton.canonicalKeyspace = "ANDI";
    } 
    return apSingleton.playStoreAvailable;
  }
}


/* Location:              C:\soft\dex2jar-2.0\Smash Cricket-dex2jar.jar!\com\apsalar\sdk\AIFA_Helper.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */