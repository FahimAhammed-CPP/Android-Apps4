package com.apsalar.sdk;

import android.content.Context;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteException;
import android.database.sqlite.SQLiteOpenHelper;
import java.io.UnsupportedEncodingException;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;

class ApsalarSQLiteHelper extends SQLiteOpenHelper {
  static final String TAG = "Apsalar SDK/SQLiteHelper";
  
  public ApsalarSQLiteHelper(Context paramContext, String paramString) {
    super(paramContext, paramString, null, 1);
    ApSingleton.getInstance(paramContext).getClass();
  }
  
  public static boolean clearConfigTables() {
    ApSingleton.getInstance(ApSingleton.getContext());
    boolean bool = true;
    if (!truncateTable("config"))
      bool = false; 
    if (!truncateTable("device_keys"))
      bool = false; 
    return bool;
  }
  
  public static void closeDatabase() {}
  
  public static boolean createApsalarTables() {
    ApSingleton.getInstance(ApSingleton.getContext()).getClass();
    boolean bool = true;
    if (!createConfigTable())
      bool = false; 
    if (!createDevicekeysTable())
      bool = false; 
    if (!createEventsTable())
      bool = false; 
    return bool;
  }
  
  private static boolean createConfigTable() {
    ApSingleton apSingleton = ApSingleton.getInstance(ApSingleton.getContext());
    boolean bool = true;
    if (!apSingleton.configTableCreated)
      try {
        apSingleton.database = getSQLWritableDatabase(apSingleton.ctx);
        if (apSingleton.database == null) {
          apSingleton.getClass();
          bool = false;
          return bool;
        } 
        apSingleton.getClass();
        SQLiteDatabase sQLiteDatabase = apSingleton.database;
        apSingleton.getClass();
        sQLiteDatabase.execSQL("CREATE TABLE IF NOT EXISTS config ( apiKey TEXT primary key, secret TEXT, isLAT BOOLEAN, doHeartbeat BOOLEAN, playStoreAvailable BOOLEAN, andi TEXT NULL, aifa TEXT NULL, imei TEXT NULL, mac1 TEXT NULL, bmac TEXT NULL, apid TEXT NULL, canonicalKeyspace TEXT NULL, canonicalDeviceId TEXT NULL, desired TEXT NULL)");
        apSingleton.configTableCreated = true;
        return bool;
      } catch (SQLiteException sQLiteException) {
        apSingleton.getClass();
        return false;
      } catch (IllegalStateException illegalStateException) {
        apSingleton.getClass();
        return false;
      } catch (Exception exception) {
        apSingleton.getClass();
        return false;
      } finally {
        closeDatabase();
      }  
    apSingleton.getClass();
    return true;
  }
  
  private static boolean createDevicekeysTable() {
    ApSingleton apSingleton = ApSingleton.getInstance(ApSingleton.getContext());
    boolean bool = true;
    if (!apSingleton.devicekeysTableCreated)
      try {
        apSingleton.database = getSQLWritableDatabase(apSingleton.ctx);
        if (apSingleton.database == null) {
          apSingleton.getClass();
          bool = false;
          return bool;
        } 
        apSingleton.getClass();
        SQLiteDatabase sQLiteDatabase = apSingleton.database;
        apSingleton.getClass();
        sQLiteDatabase.execSQL("CREATE TABLE IF NOT EXISTS device_keys ( keyspace CHAR(4), val TEXT, canonical BOOLEAN NULL, PRIMARY KEY (keyspace))");
        apSingleton.devicekeysTableCreated = true;
        return bool;
      } catch (SQLiteException sQLiteException) {
        apSingleton.getClass();
        return false;
      } catch (IllegalStateException illegalStateException) {
        apSingleton.getClass();
        return false;
      } catch (Exception exception) {
        apSingleton.getClass();
        return false;
      } finally {
        closeDatabase();
      }  
    apSingleton.getClass();
    return true;
  }
  
  private static boolean createEventsTable() {
    ApSingleton apSingleton = ApSingleton.getInstance(ApSingleton.getContext());
    boolean bool = true;
    if (!apSingleton.eventsTableCreated)
      try {
        apSingleton.database = getSQLWritableDatabase(apSingleton.ctx);
        SQLiteDatabase sQLiteDatabase = apSingleton.database;
        if (sQLiteDatabase == null) {
          bool = false;
          return bool;
        } 
        apSingleton.getClass();
        sQLiteDatabase = apSingleton.database;
        apSingleton.getClass();
        sQLiteDatabase.execSQL("CREATE TABLE IF NOT EXISTS events ( id INTEGER PRIMARY KEY, unix_t INTEGER NOT NULL, session_json TEXT, type INTEGER NOT NULL, name VARCHAR(32), args TEXT)");
        apSingleton.eventsTableCreated = true;
        return bool;
      } catch (SQLiteException sQLiteException) {
        apSingleton.getClass();
        return false;
      } catch (IllegalStateException illegalStateException) {
        apSingleton.getClass();
        return false;
      } catch (Exception exception) {
        apSingleton.getClass();
        return false;
      } finally {
        closeDatabase();
      }  
    apSingleton.getClass();
    return true;
  }
  
  public static SQLiteDatabase getSQLWritableDatabase(Context paramContext) {
    ApSingleton apSingleton = ApSingleton.getInstance(paramContext);
    apSingleton.getClass();
    if (paramContext == null) {
      apSingleton.getClass();
      return null;
    } 
    if (apSingleton.database != null)
      return apSingleton.database; 
    if (apSingleton.hash == null || apSingleton.hash.length() == 0) {
      String str = paramContext.getPackageName();
      apSingleton.hash = "";
      try {
        if (apSingleton.info != null && apSingleton.info.secret != null) {
          String str1 = apSingleton.info.secret;
          MessageDigest messageDigest = MessageDigest.getInstance("SHA-1");
          messageDigest.update(str1.getBytes("UTF-8"));
          messageDigest.update(str.getBytes("UTF-8"));
          apSingleton.hash = Apsalar.hexDigest(messageDigest.digest());
          Apsalar.saveSharedPrefs(paramContext, "HASH", apSingleton.hash);
        } else {
          Apsalar.loadSharedPrefs(paramContext);
        } 
        if (apSingleton.hash == null || apSingleton.hash.length() == 0) {
          apSingleton.getClass();
          return null;
        } 
        if (apSingleton.info == null)
          Apsalar.loadConfig(paramContext); 
      } catch (NoSuchAlgorithmException noSuchAlgorithmException) {
        apSingleton.getClass();
        return null;
      } catch (UnsupportedEncodingException unsupportedEncodingException) {
        apSingleton.getClass();
        return null;
      } catch (IndexOutOfBoundsException indexOutOfBoundsException) {
        apSingleton.getClass();
        return null;
      } catch (Exception exception) {
        apSingleton.getClass();
      } 
    } 
    if (apSingleton.dbOpener == null)
      apSingleton.dbOpener = new ApsalarSQLiteHelper((Context)indexOutOfBoundsException, "Apsalar.sqlite_" + apSingleton.hash); 
    if (apSingleton.database == null)
      try {
        apSingleton.database = apSingleton.dbOpener.getWritableDatabase();
        apSingleton.openCount++;
      } catch (SQLiteException sQLiteException) {
        apSingleton.getClass();
      } catch (IllegalStateException illegalStateException) {
        apSingleton.getClass();
      } catch (Exception exception) {
        apSingleton.getClass();
      }  
    return apSingleton.database;
  }
  
  private static boolean truncateTable(String paramString) {
    ApSingleton apSingleton = ApSingleton.getInstance(ApSingleton.getContext());
    if (paramString.length() == 0) {
      apSingleton.getClass();
      return false;
    } 
    if (apSingleton.database == null)
      apSingleton.database = getSQLWritableDatabase(apSingleton.ctx); 
    try {
      apSingleton.getClass();
      apSingleton.database.execSQL("DELETE FROM " + paramString);
      return true;
    } catch (Exception exception) {
      apSingleton.getClass();
      return false;
    } 
  }
  
  public void onCreate(SQLiteDatabase paramSQLiteDatabase) {}
  
  public void onUpgrade(SQLiteDatabase paramSQLiteDatabase, int paramInt1, int paramInt2) {}
}


/* Location:              C:\soft\dex2jar-2.0\Smash Cricket-dex2jar.jar!\com\apsalar\sdk\ApsalarSQLiteHelper.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */