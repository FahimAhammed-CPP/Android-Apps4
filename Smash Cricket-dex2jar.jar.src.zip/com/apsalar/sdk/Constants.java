package com.apsalar.sdk;

public class Constants {
  public static final String API_PREFIX = "e";
  
  public static final String API_PROTOCOL = "http";
  
  public static final boolean DEBUG_FLAG = false;
  
  public static final boolean ERROR_FLAG = false;
  
  public static final String SDK_VER = "6.1.5";
  
  public static final boolean WITH_EVENT_MONITOR = false;
}


/* Location:              C:\soft\dex2jar-2.0\Smash Cricket-dex2jar.jar!\com\apsalar\sdk\Constants.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */