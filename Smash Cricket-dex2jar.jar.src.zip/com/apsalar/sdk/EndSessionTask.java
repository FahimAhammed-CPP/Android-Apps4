package com.apsalar.sdk;

import android.os.AsyncTask;

class EndSessionTask extends AsyncTask<ApsalarEvent, Void, Integer> {
  static final String TAG = "Apsalar SDK/EndSessionTask";
  
  Integer status = Integer.valueOf(-1);
  
  protected Integer doInBackground(ApsalarEvent... paramVarArgs) {
    ApSingleton apSingleton = ApSingleton.getInstance(ApSingleton.getContext());
    this.status = Integer.valueOf(paramVarArgs[0].REST());
    apSingleton.getClass();
    return this.status;
  }
  
  protected void onPostExcute(Integer paramInteger) {
    ApSingleton.getInstance(ApSingleton.getContext()).getClass();
  }
}


/* Location:              C:\soft\dex2jar-2.0\Smash Cricket-dex2jar.jar!\com\apsalar\sdk\EndSessionTask.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */