package com.apsalar.sdk;

import android.content.Context;
import android.util.Log;
import java.io.IOException;
import java.io.UnsupportedEncodingException;
import java.net.ProtocolException;
import java.net.SocketTimeoutException;
import java.net.URLEncoder;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import org.json.JSONException;
import org.json.JSONObject;

class ApsalarResolve extends ApsalarEvent {
  static final String TAG = "Apsalar SDK/Resolve";
  
  String clsPackage = null;
  
  String hash = null;
  
  boolean playStoreAvailable = false;
  
  ApsalarResolve(Context paramContext, ApsalarSessionInfo paramApsalarSessionInfo, boolean paramBoolean) {
    super(paramContext, paramApsalarSessionInfo);
    this.clsPackage = paramContext.getPackageName();
    this.playStoreAvailable = paramBoolean;
  }
  
  private boolean alreadyResolved(String paramString) {
    ApSingleton apSingleton = ApSingleton.getInstance(this.ctx);
    boolean bool2 = false;
    if (apSingleton.resolved_ANDI && paramString.equals("ANDI")) {
      boolean bool = true;
      apSingleton.getClass();
      return bool;
    } 
    boolean bool1 = bool2;
    if (apSingleton.resolved_AIFA) {
      bool1 = bool2;
      if (paramString.equals("AIFA"))
        bool1 = true; 
    } 
    apSingleton.getClass();
    return bool1;
  }
  
  private void trackResolve(String paramString) {
    ApSingleton apSingleton = ApSingleton.getInstance(this.ctx);
    apSingleton.getClass();
    if (paramString.equals("ANDI")) {
      apSingleton.resolved_ANDI = true;
      return;
    } 
    if (paramString.equals("AIFA")) {
      apSingleton.resolved_AIFA = true;
      return;
    } 
  }
  
  public int REST() {
    return REST(true);
  }
  
  public int REST(boolean paramBoolean) {
    // Byte code:
    //   0: aload_0
    //   1: getfield ctx : Landroid/content/Context;
    //   4: invokestatic getInstance : (Landroid/content/Context;)Lcom/apsalar/sdk/ApSingleton;
    //   7: astore #4
    //   9: aload_0
    //   10: iconst_1
    //   11: invokevirtual doGet : (Z)I
    //   14: istore_2
    //   15: iload_2
    //   16: iconst_1
    //   17: if_icmpeq -> 28
    //   20: aload #4
    //   22: invokevirtual getClass : ()Ljava/lang/Class;
    //   25: pop
    //   26: iload_2
    //   27: ireturn
    //   28: iconst_0
    //   29: istore_2
    //   30: aload_0
    //   31: getfield returnData : Ljava/lang/String;
    //   34: ifnonnull -> 53
    //   37: aload #4
    //   39: invokevirtual getClass : ()Ljava/lang/Class;
    //   42: pop
    //   43: iconst_1
    //   44: istore_2
    //   45: aload #4
    //   47: invokevirtual getClass : ()Ljava/lang/Class;
    //   50: pop
    //   51: iload_2
    //   52: ireturn
    //   53: iload_1
    //   54: ifeq -> 247
    //   57: aload_0
    //   58: new org/json/JSONObject
    //   61: dup
    //   62: aload_0
    //   63: getfield returnData : Ljava/lang/String;
    //   66: invokespecial <init> : (Ljava/lang/String;)V
    //   69: putfield returnDataJSON : Lorg/json/JSONObject;
    //   72: aload_0
    //   73: getfield returnDataJSON : Lorg/json/JSONObject;
    //   76: ldc 'status'
    //   78: invokevirtual getString : (Ljava/lang/String;)Ljava/lang/String;
    //   81: invokevirtual toLowerCase : ()Ljava/lang/String;
    //   84: ldc 'ok'
    //   86: invokevirtual equals : (Ljava/lang/Object;)Z
    //   89: ifeq -> 98
    //   92: aload #4
    //   94: invokevirtual getClass : ()Ljava/lang/Class;
    //   97: pop
    //   98: aload #4
    //   100: getfield desired : Lorg/json/JSONArray;
    //   103: astore #5
    //   105: aload_0
    //   106: getfield returnDataJSON : Lorg/json/JSONObject;
    //   109: ldc 'desired'
    //   111: invokevirtual getJSONArray : (Ljava/lang/String;)Lorg/json/JSONArray;
    //   114: astore #6
    //   116: aload #4
    //   118: aload #6
    //   120: putfield desired : Lorg/json/JSONArray;
    //   123: aload #6
    //   125: ifnonnull -> 160
    //   128: aload #4
    //   130: invokevirtual getClass : ()Ljava/lang/Class;
    //   133: pop
    //   134: iconst_0
    //   135: istore_3
    //   136: iload_3
    //   137: istore_2
    //   138: aload #4
    //   140: getfield devicesAlreadyResolved : Z
    //   143: ifne -> 45
    //   146: iload_3
    //   147: istore_2
    //   148: aload_0
    //   149: invokevirtual do_resolve : ()Z
    //   152: ifne -> 45
    //   155: iconst_0
    //   156: istore_2
    //   157: goto -> 45
    //   160: aload_0
    //   161: aload #4
    //   163: getfield canonicalKeyspace : Ljava/lang/String;
    //   166: invokespecial trackResolve : (Ljava/lang/String;)V
    //   169: aload #5
    //   171: ifnull -> 217
    //   174: aload #4
    //   176: getfield desired : Lorg/json/JSONArray;
    //   179: aload #5
    //   181: invokevirtual equals : (Ljava/lang/Object;)Z
    //   184: ifne -> 217
    //   187: aload #4
    //   189: invokevirtual getClass : ()Ljava/lang/Class;
    //   192: pop
    //   193: invokestatic clearConfigTables : ()Z
    //   196: pop
    //   197: aload_0
    //   198: getfield ctx : Landroid/content/Context;
    //   201: invokestatic loadConfig : (Landroid/content/Context;)Z
    //   204: pop
    //   205: aload #4
    //   207: iconst_0
    //   208: putfield devicesAlreadyResolved : Z
    //   211: aload #4
    //   213: iconst_0
    //   214: putfield already_did_SQL : Z
    //   217: aload #4
    //   219: invokevirtual getClass : ()Ljava/lang/Class;
    //   222: pop
    //   223: iconst_1
    //   224: istore_3
    //   225: goto -> 136
    //   228: astore #5
    //   230: aload #4
    //   232: invokevirtual incrExceptionCount : ()I
    //   235: pop
    //   236: aload #4
    //   238: invokevirtual getClass : ()Ljava/lang/Class;
    //   241: pop
    //   242: iconst_0
    //   243: istore_3
    //   244: goto -> 136
    //   247: aload #4
    //   249: invokevirtual getClass : ()Ljava/lang/Class;
    //   252: pop
    //   253: goto -> 45
    //   256: astore #5
    //   258: goto -> 98
    // Exception table:
    //   from	to	target	type
    //   57	72	228	java/lang/Throwable
    //   72	98	256	org/json/JSONException
    //   72	98	228	java/lang/Throwable
    //   98	123	228	java/lang/Throwable
    //   128	134	228	java/lang/Throwable
    //   160	169	228	java/lang/Throwable
    //   174	217	228	java/lang/Throwable
    //   217	223	228	java/lang/Throwable
  }
  
  public int doGet(boolean paramBoolean) {
    ApSingleton apSingleton = ApSingleton.getInstance(this.ctx);
    Apsalar.getDeviceId(apSingleton.canonicalKeyspace);
    apSingleton.getClass();
    byte b2 = 1;
    if (!makeURL(paramBoolean)) {
      if (alreadyResolved(apSingleton.canonicalKeyspace)) {
        apSingleton.getClass();
        return 1;
      } 
      apSingleton.getClass();
      b2 = -1;
    } 
    byte b1 = b2;
    if (b2 == 1) {
      String str2 = this.url;
      String str1 = "";
      try {
        MessageDigest messageDigest = MessageDigest.getInstance("SHA-1");
        messageDigest.reset();
        messageDigest.update(this.info.secret.getBytes("UTF-8"));
        messageDigest.update(str2.getBytes("UTF-8"));
        String str = Apsalar.hexDigest(messageDigest.digest());
        str1 = str;
      } catch (NoSuchAlgorithmException noSuchAlgorithmException) {
        apSingleton.incrExceptionCount();
        apSingleton.getClass();
        b2 = -1;
      } catch (UnsupportedEncodingException unsupportedEncodingException) {
        apSingleton.incrExceptionCount();
        apSingleton.getClass();
        b2 = -1;
      } catch (IndexOutOfBoundsException indexOutOfBoundsException) {
        apSingleton.incrExceptionCount();
        apSingleton.getClass();
        b2 = -1;
      } 
      str1 = this.urlbase + str2 + "&h=" + str1;
      apSingleton.getClass();
      b1 = b2;
      if (b2 == 1) {
        this.returnData = null;
        b1 = b2;
        if (b2 == 1)
          try {
            this.returnData = ApsalarHttpClient.get(str1);
            try {
              if (this.returnData != null)
                apSingleton.incrSentEventsCount(); 
              this.returnDataJSON = new JSONObject(this.returnData);
              str1 = this.returnDataJSON.getString("k");
              String str = this.returnDataJSON.getString("u");
              apSingleton.getClass();
              b1 = b2;
              if (this.old_k.equals(apSingleton.canonicalKeyspace)) {
                b1 = b2;
                if (this.old_u.equals(apSingleton.canonicalDeviceId)) {
                  changeDeviceKeys(str1, str, this.old_k, this.old_u, false);
                  b1 = b2;
                } 
              } 
            } catch (JSONException jSONException) {}
          } catch (ProtocolException protocolException) {
            apSingleton.incrExceptionCount();
            apSingleton.getClass();
            b1 = -1;
          } catch (SocketTimeoutException socketTimeoutException) {
            apSingleton.incrExceptionCount();
            apSingleton.incrNetworkErrorCount();
            apSingleton.getClass();
            b1 = 0;
          } catch (IOException iOException) {
            apSingleton.incrExceptionCount();
            apSingleton.incrNetworkErrorCount();
            apSingleton.getClass();
            b1 = 0;
          }  
      } 
    } 
    return b1;
  }
  
  boolean do_resolve() {
    boolean bool2;
    ApSingleton apSingleton = ApSingleton.getInstance(this.ctx);
    apSingleton.getClass();
    boolean bool1 = false;
    int i = 0;
    while (true) {
      if (i < apSingleton.desired.length()) {
        try {
          String str = apSingleton.desired.getString(i);
          if (alreadyResolved(str)) {
            apSingleton.getClass();
          } else {
            String str1 = Apsalar.getDeviceId(str);
            String str2 = apSingleton.canonicalKeyspace;
            if (str.equals(apSingleton.canonicalKeyspace) && str1.equals(apSingleton.canonicalDeviceId)) {
              apSingleton.getClass();
              trackResolve(str);
              bool1 = true;
            } else if (str.equals(str2) && !str.equals(apSingleton.canonicalKeyspace)) {
              if (alreadyResolved(str)) {
                bool1 = true;
              } else {
                Log.d("Apsalar SDK/Resolve", "ApsalarResolve: found - RESOLVING... keySpace=" + str + ", deviceId=" + str1);
                Apsalar.getDeviceId(str);
                this.info.deviceId = apSingleton.info.deviceId;
                switch (doGet(false)) {
                  case -1:
                  case 0:
                    apSingleton.getClass();
                    i++;
                    break;
                  case 1:
                    apSingleton.getClass();
                    bool1 = true;
                    trackResolve(str);
                    i++;
                    break;
                } 
                continue;
              } 
            } else {
              apSingleton.getClass();
            } 
          } 
        } catch (JSONException jSONException) {
          apSingleton.incrExceptionCount();
          apSingleton.getClass();
        } 
      } else {
        break;
      } 
      i++;
      break;
    } 
    if (bool1 || apSingleton.resolved_ANDI || apSingleton.resolved_AIFA) {
      bool2 = true;
    } else {
      bool2 = false;
    } 
    if (bool2)
      apSingleton.devicesAlreadyResolved = true; 
    return bool2;
  }
  
  protected void init(Context paramContext) {
    this.ctx = paramContext;
    this.urlbase = "http://e.apsalar.com/api/v1/resolve";
  }
  
  protected boolean makeURL(boolean paramBoolean) {
    ApSingleton apSingleton = ApSingleton.getInstance(this.ctx);
    apSingleton.getClass();
    try {
      String str3 = Apsalar.getDeviceId(apSingleton.canonicalKeyspace);
      String str4 = apSingleton.canonicalKeyspace;
      String str2 = str4;
      String str1 = str3;
      if (paramBoolean) {
        str2 = str4;
        str1 = str3;
        if (resolveHelper()) {
          str1 = this.info.deviceId;
          str2 = apSingleton.canonicalKeyspace;
        } 
      } 
      if (alreadyResolved(str2)) {
        apSingleton.getClass();
        return false;
      } 
      this.info.retType = "json";
      str3 = "?a=" + URLEncoder.encode(this.info.apiKey, "UTF-8") + "&k=" + URLEncoder.encode(str2, "UTF-8") + "&u=" + URLEncoder.encode(str1, "UTF-8") + "&p=" + URLEncoder.encode(this.info.platform, "UTF-8") + "&v=" + URLEncoder.encode(this.info.osVersion, "UTF-8") + "&rt=" + URLEncoder.encode(this.info.retType, "UTF-8");
      apSingleton.dk = null;
      this.old_k = str2;
      this.old_u = str1;
      this.url = str3;
      if (this.url.length() >= 1999) {
        apSingleton.getClass();
        return false;
      } 
    } catch (UnsupportedEncodingException unsupportedEncodingException) {
      apSingleton.incrExceptionCount();
      apSingleton.getClass();
      return false;
    } 
    return true;
  }
  
  public String toString() {
    return this.returnData;
  }
}


/* Location:              C:\soft\dex2jar-2.0\Smash Cricket-dex2jar.jar!\com\apsalar\sdk\ApsalarResolve.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */