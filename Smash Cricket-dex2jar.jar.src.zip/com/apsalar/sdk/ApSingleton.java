package com.apsalar.sdk;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.util.Log;
import java.util.concurrent.ArrayBlockingQueue;
import org.json.JSONArray;

public class ApSingleton {
  static final String TAG = "Apsalar SDK/ApSingleton";
  
  public static volatile ApsalarThread apsalar_thread;
  
  public static volatile ApsalarEventConsumerThread eventConsumerThread;
  
  public static volatile ArrayBlockingQueue<RawEvent> eventQueue;
  
  private static volatile ApSingleton instance = null;
  
  public static final int maxUrlSize = 1999;
  
  public volatile String AIFA;
  
  public boolean AIFA_changed;
  
  public boolean ALWAYS_REQUEST_CANONICAL;
  
  public volatile String ANDI;
  
  public int BACKOFF_INTERVAL;
  
  public int BATCHES_INTERVAL;
  
  public int BATCHES_MAX;
  
  public int BUFFER_SIZE_MAX;
  
  public final boolean DEBUG = false;
  
  public final boolean ERROR = false;
  
  public volatile String FBAppId;
  
  public int HEARTBEAT_INTERVAL_BACKOFF;
  
  public int HEARTBEAT_INTERVAL_MAX;
  
  public int HEARTBEAT_INTERVAL_MIN;
  
  public int LONGSLEEP;
  
  public int MEDIUMSLEEP;
  
  public int NUM_EVENTS_B4_SLEEP;
  
  public int QUEUE_SIZE_MAX;
  
  public int RESOLVER_MAX;
  
  public boolean RESOLVE_ALL_AVAILABLE;
  
  public int RETRY_INTERVAL_BACKOFF;
  
  public int RETRY_INTERVAL_MAX;
  
  public int RETRY_INTERVAL_MIN;
  
  public int SHORTSLEEP;
  
  public int VERYLONGSLEEP;
  
  public boolean already_did_SQL;
  
  public volatile BroadcastReceiver apsalar_receiver;
  
  public BroadcastReceiver apsalar_safe_receiver;
  
  public boolean backlogTableCreated;
  
  private volatile int bootstrapCount;
  
  public volatile String canonicalDeviceId;
  
  public volatile String canonicalKeyspace;
  
  public boolean configTableCreated;
  
  public Context ctx;
  
  public volatile SQLiteDatabase database;
  
  public volatile SQLiteOpenHelper dbOpener;
  
  public volatile JSONArray desired;
  
  public boolean devicekeysTableCreated;
  
  public boolean devicesAlreadyResolved;
  
  public volatile String dk;
  
  public boolean doHeartbeat;
  
  private volatile int dropEventsCount;
  
  public boolean eventsTableCreated;
  
  private volatile int exceptionCount;
  
  public int expires;
  
  public volatile String hash;
  
  public int heartbeatInterval;
  
  public volatile ApsalarSessionInfo info;
  
  public boolean isLAT;
  
  private volatile int networkErrorCount;
  
  public volatile String old_AIFA;
  
  public int openCount;
  
  public boolean playStoreAvailable;
  
  public volatile boolean registeredReceiver;
  
  public boolean registeredSafeReceiver;
  
  public boolean resolved_AIFA;
  
  public boolean resolved_ANDI;
  
  public final String selectMostRecentEventByTypeSQL = "SELECT id, session_json FROM events WHERE type=? ORDER BY id DESC LIMIT 1";
  
  public final String selectOldestEventSQL = "SELECT type, session_json, name, args, unix_t, id FROM events ORDER BY id ASC LIMIT 1";
  
  private volatile int sentEventsCount;
  
  public int state;
  
  public final String tableConfigSQL = "CREATE TABLE IF NOT EXISTS config ( apiKey TEXT primary key, secret TEXT, isLAT BOOLEAN, doHeartbeat BOOLEAN, playStoreAvailable BOOLEAN, andi TEXT NULL, aifa TEXT NULL, imei TEXT NULL, mac1 TEXT NULL, bmac TEXT NULL, apid TEXT NULL, canonicalKeyspace TEXT NULL, canonicalDeviceId TEXT NULL, desired TEXT NULL)";
  
  public final String tableDeviceKeysSQL = "CREATE TABLE IF NOT EXISTS device_keys ( keyspace CHAR(4), val TEXT, canonical BOOLEAN NULL, PRIMARY KEY (keyspace))";
  
  public final String tableEventsSQL = "CREATE TABLE IF NOT EXISTS events ( id INTEGER PRIMARY KEY, unix_t INTEGER NOT NULL, session_json TEXT, type INTEGER NOT NULL, name VARCHAR(32), args TEXT)";
  
  static {
    eventConsumerThread = null;
    eventQueue = null;
  }
  
  public static void destroyInstance() {
    instance = null;
  }
  
  public static Context getContext() {
    return (instance != null) ? instance.ctx : null;
  }
  
  public static ApSingleton getInstance(Context paramContext) {
    if (instance == null)
      instance = reinitializeInstance(paramContext); 
    if (paramContext != null)
      instance.ctx = paramContext; 
    return instance;
  }
  
  public static int getQueueSize() {
    if (instance == null)
      instance = getInstance(null); 
    return instance.QUEUE_SIZE_MAX;
  }
  
  public static void log() {
    Log.d("Apsalar SDK/ApSingleton", "Current state of `instance`:");
    if (instance == null) {
      Log.w("Apsalar SDK/ApSingleton", "> instance is null");
      return;
    } 
    Log.d("Apsalar SDK/ApSingleton", "> instance.configTableCreated=" + instance.configTableCreated);
    Log.d("Apsalar SDK/ApSingleton", "> instance.backlogTableCreated=" + instance.backlogTableCreated);
    Log.d("Apsalar SDK/ApSingleton", "> instance.devicekeysTableCreated=" + instance.devicekeysTableCreated);
    Log.d("Apsalar SDK/ApSingleton", "> instance.expires=" + instance.expires);
    Log.d("Apsalar SDK/ApSingleton", "> instance.hash=" + instance.hash);
    Log.d("Apsalar SDK/ApSingleton", "> instance.devicesAlreadyResolved=" + instance.devicesAlreadyResolved);
    Log.d("Apsalar SDK/ApSingleton", "> instance.RESOLVE_ALL_AVAILABLE=" + instance.RESOLVE_ALL_AVAILABLE);
    Log.d("Apsalar SDK/ApSingleton", "> instance.ALWAYS_REQUEST_CANONICAL=" + instance.ALWAYS_REQUEST_CANONICAL);
    Log.d("Apsalar SDK/ApSingleton", "> instance.NUM_EVENTS_B4_SLEEP=" + instance.NUM_EVENTS_B4_SLEEP);
    Log.d("Apsalar SDK/ApSingleton", "> instance.QUEUE_SIZE_MAX=" + instance.QUEUE_SIZE_MAX);
    Log.d("Apsalar SDK/ApSingleton", "> instance.BUFFER_SIZE_MAX=" + instance.BUFFER_SIZE_MAX);
    Log.d("Apsalar SDK/ApSingleton", "> instance.HEARTBEAT_INTERVAL_BACKOFF=" + instance.HEARTBEAT_INTERVAL_BACKOFF);
    Log.d("Apsalar SDK/ApSingleton", "> instance.HEARTBEAT_INTERVAL_MAX=" + instance.HEARTBEAT_INTERVAL_MAX);
    Log.d("Apsalar SDK/ApSingleton", "> instance.HEARTBEAT_INTERVAL_MIN=" + instance.HEARTBEAT_INTERVAL_MIN);
    Log.d("Apsalar SDK/ApSingleton", "> instance.RETRY_INTERVAL_BACKOFF=" + instance.RETRY_INTERVAL_BACKOFF);
    Log.d("Apsalar SDK/ApSingleton", "> instance.RETRY_INTERVAL_MAX=" + instance.RETRY_INTERVAL_MAX);
    Log.d("Apsalar SDK/ApSingleton", "> instance.RETRY_INTERVAL_MIN=" + instance.RETRY_INTERVAL_MIN);
    Log.d("Apsalar SDK/ApSingleton", "> instance.BATCHES_MAX=" + instance.BATCHES_MAX);
    Log.d("Apsalar SDK/ApSingleton", "> instance.BATCHES_INTERVAL=" + instance.BATCHES_INTERVAL);
    Log.d("Apsalar SDK/ApSingleton", "> instance.RESOLVER_MAX=" + instance.RESOLVER_MAX);
    Log.d("Apsalar SDK/ApSingleton", "> instance.SHORTSLEEP=" + instance.SHORTSLEEP);
    Log.d("Apsalar SDK/ApSingleton", "> instance.MEDIUMSLEEP=" + instance.MEDIUMSLEEP);
    Log.d("Apsalar SDK/ApSingleton", "> instance.LONGSLEEP=" + instance.LONGSLEEP);
    Log.d("Apsalar SDK/ApSingleton", "> instance.VERYLONGSLEEP=" + instance.VERYLONGSLEEP);
  }
  
  private static ApSingleton reinitializeInstance(Context paramContext) {
    if (instance != null)
      return instance; 
    instance = new ApSingleton();
    instance.getClass();
    instance.RESOLVE_ALL_AVAILABLE = false;
    instance.ALWAYS_REQUEST_CANONICAL = false;
    instance.NUM_EVENTS_B4_SLEEP = 25;
    instance.QUEUE_SIZE_MAX = 2000;
    instance.BUFFER_SIZE_MAX = 1000;
    instance.HEARTBEAT_INTERVAL_BACKOFF = 2;
    instance.HEARTBEAT_INTERVAL_MAX = 21600000;
    instance.HEARTBEAT_INTERVAL_MIN = 300000;
    instance.RETRY_INTERVAL_BACKOFF = 2;
    instance.RETRY_INTERVAL_MAX = 300000;
    instance.RETRY_INTERVAL_MIN = 15000;
    instance.BACKOFF_INTERVAL = 3000;
    instance.BATCHES_MAX = 3000;
    instance.BATCHES_INTERVAL = 0;
    instance.RESOLVER_MAX = 9;
    instance.SHORTSLEEP = 1000;
    instance.MEDIUMSLEEP = 3000;
    instance.LONGSLEEP = 60000;
    instance.VERYLONGSLEEP = 900000;
    instance.ctx = paramContext;
    instance.apsalar_receiver = null;
    ApSingleton apSingleton = instance;
    apsalar_thread = null;
    instance.isLAT = false;
    instance.doHeartbeat = true;
    instance.registeredReceiver = false;
    instance.devicesAlreadyResolved = false;
    instance.playStoreAvailable = false;
    instance.configTableCreated = false;
    instance.backlogTableCreated = false;
    instance.devicekeysTableCreated = false;
    instance.eventsTableCreated = false;
    instance.AIFA_changed = false;
    instance.resolved_ANDI = false;
    instance.resolved_AIFA = false;
    instance.FBAppId = "";
    instance.old_AIFA = "None";
    instance.ANDI = null;
    instance.AIFA = null;
    instance.desired = new JSONArray();
    instance.dk = null;
    instance.openCount = 0;
    instance.already_did_SQL = false;
    instance.expires = 0;
    instance.canonicalKeyspace = "AIFA";
    instance.canonicalDeviceId = "None";
    instance.database = null;
    instance.dbOpener = null;
    instance.hash = null;
    instance.sentEventsCount = 0;
    instance.dropEventsCount = 0;
    instance.networkErrorCount = 0;
    instance.exceptionCount = 0;
    instance.bootstrapCount = 0;
    instance.state = 2;
    instance.heartbeatInterval = instance.HEARTBEAT_INTERVAL_MIN;
    instance.info = null;
    if (instance.ctx != null) {
      instance.getClass();
      Intent intent = new Intent();
      intent.setAction("com.apsalar.sdk.INITIALIZE");
      intent.setPackage("com.apsalar.sdk");
      intent.putExtra("Apsalar", "initialize");
      instance.ctx.sendBroadcast(intent);
      return instance;
    } 
    instance.getClass();
    return instance;
  }
  
  public static boolean testInstance() {
    return (instance != null);
  }
  
  public int getBootstrapCount() {
    return this.bootstrapCount;
  }
  
  public int getDropEventsCount() {
    return this.dropEventsCount;
  }
  
  public int getExceptionCount() {
    return this.exceptionCount;
  }
  
  public int getNetworkErrorCount() {
    return this.networkErrorCount;
  }
  
  public int getSentEventsCount() {
    return this.sentEventsCount;
  }
  
  public int incrBootstrapCount() {
    /* monitor enter ThisExpression{ObjectType{com/apsalar/sdk/ApSingleton}} */
    /* monitor exit ThisExpression{ObjectType{com/apsalar/sdk/ApSingleton}} */
    return 0;
  }
  
  public int incrDropEventsCount() {
    /* monitor enter ThisExpression{ObjectType{com/apsalar/sdk/ApSingleton}} */
    /* monitor exit ThisExpression{ObjectType{com/apsalar/sdk/ApSingleton}} */
    return 0;
  }
  
  public int incrExceptionCount() {
    /* monitor enter ThisExpression{ObjectType{com/apsalar/sdk/ApSingleton}} */
    /* monitor exit ThisExpression{ObjectType{com/apsalar/sdk/ApSingleton}} */
    return 0;
  }
  
  public int incrNetworkErrorCount() {
    /* monitor enter ThisExpression{ObjectType{com/apsalar/sdk/ApSingleton}} */
    /* monitor exit ThisExpression{ObjectType{com/apsalar/sdk/ApSingleton}} */
    return 0;
  }
  
  public int incrSentEventsCount() {
    /* monitor enter ThisExpression{ObjectType{com/apsalar/sdk/ApSingleton}} */
    /* monitor exit ThisExpression{ObjectType{com/apsalar/sdk/ApSingleton}} */
    return 0;
  }
  
  public static class State {
    static final int BACKOFF = 4;
    
    static final int BUFFERING = 3;
    
    static final int NOMINAL = 2;
    
    static final int RECOVERY = 1;
  }
}


/* Location:              C:\soft\dex2jar-2.0\Smash Cricket-dex2jar.jar!\com\apsalar\sdk\ApSingleton.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */