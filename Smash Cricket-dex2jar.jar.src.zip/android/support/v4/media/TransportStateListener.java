package android.support.v4.media;

public class TransportStateListener {
  public void onPlayingChanged(TransportController paramTransportController) {}
  
  public void onTransportControlsChanged(TransportController paramTransportController) {}
}


/* Location:              C:\soft\dex2jar-2.0\Smash Cricket-dex2jar.jar!\android\support\v4\media\TransportStateListener.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */