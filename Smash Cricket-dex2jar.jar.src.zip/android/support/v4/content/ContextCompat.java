package android.support.v4.content;

import android.content.Context;
import android.content.Intent;
import android.os.Build;
import android.os.Bundle;
import android.os.Environment;
import java.io.File;

public class ContextCompat {
  private static final String DIR_ANDROID = "Android";
  
  private static final String DIR_CACHE = "cache";
  
  private static final String DIR_DATA = "data";
  
  private static final String DIR_FILES = "files";
  
  private static final String DIR_OBB = "obb";
  
  private static File buildPath(File paramFile, String... paramVarArgs) {
    int j = paramVarArgs.length;
    for (int i = 0; i < j; i++) {
      String str = paramVarArgs[i];
      if (paramFile == null) {
        paramFile = new File(str);
      } else if (str != null) {
        paramFile = new File(paramFile, str);
      } 
    } 
    return paramFile;
  }
  
  public static File[] getExternalCacheDirs(Context paramContext) {
    int i = Build.VERSION.SDK_INT;
    if (i >= 19)
      return ContextCompatKitKat.getExternalCacheDirs(paramContext); 
    if (i >= 8) {
      file = ContextCompatFroyo.getExternalCacheDir(paramContext);
      return new File[] { file };
    } 
    File file = buildPath(Environment.getExternalStorageDirectory(), new String[] { "Android", "data", file.getPackageName(), "cache" });
    return new File[] { file };
  }
  
  public static File[] getExternalFilesDirs(Context paramContext, String paramString) {
    int i = Build.VERSION.SDK_INT;
    if (i >= 19)
      return ContextCompatKitKat.getExternalFilesDirs(paramContext, paramString); 
    if (i >= 8) {
      file = ContextCompatFroyo.getExternalFilesDir(paramContext, paramString);
      return new File[] { file };
    } 
    File file = buildPath(Environment.getExternalStorageDirectory(), new String[] { "Android", "data", file.getPackageName(), "files", paramString });
    return new File[] { file };
  }
  
  public static File[] getObbDirs(Context paramContext) {
    int i = Build.VERSION.SDK_INT;
    if (i >= 19)
      return ContextCompatKitKat.getObbDirs(paramContext); 
    if (i >= 11) {
      file = ContextCompatHoneycomb.getObbDir(paramContext);
      return new File[] { file };
    } 
    File file = buildPath(Environment.getExternalStorageDirectory(), new String[] { "Android", "obb", file.getPackageName() });
    return new File[] { file };
  }
  
  public static boolean startActivities(Context paramContext, Intent[] paramArrayOfIntent) {
    return startActivities(paramContext, paramArrayOfIntent, null);
  }
  
  public static boolean startActivities(Context paramContext, Intent[] paramArrayOfIntent, Bundle paramBundle) {
    int i = Build.VERSION.SDK_INT;
    if (i >= 16) {
      ContextCompatJellybean.startActivities(paramContext, paramArrayOfIntent, paramBundle);
      return true;
    } 
    if (i >= 11) {
      ContextCompatHoneycomb.startActivities(paramContext, paramArrayOfIntent);
      return true;
    } 
    return false;
  }
}


/* Location:              C:\soft\dex2jar-2.0\Smash Cricket-dex2jar.jar!\android\support\v4\content\ContextCompat.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */