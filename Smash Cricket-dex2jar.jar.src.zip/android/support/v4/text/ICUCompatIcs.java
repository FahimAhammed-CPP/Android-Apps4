package android.support.v4.text;

import android.util.Log;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;

class ICUCompatIcs {
  private static final String TAG = "ICUCompatIcs";
  
  private static Method sAddLikelySubtagsMethod;
  
  private static Method sGetScriptMethod;
  
  static {
    try {
      Class<?> clazz = Class.forName("libcore.icu.ICU");
      if (clazz != null) {
        sGetScriptMethod = clazz.getMethod("getScript", new Class[] { String.class });
        sAddLikelySubtagsMethod = clazz.getMethod("addLikelySubtags", new Class[] { String.class });
      } 
      return;
    } catch (Exception exception) {
      Log.w("ICUCompatIcs", exception);
      return;
    } 
  }
  
  public static String addLikelySubtags(String paramString) {
    try {
      if (sAddLikelySubtagsMethod != null)
        return (String)sAddLikelySubtagsMethod.invoke(null, new Object[] { paramString }); 
    } catch (IllegalAccessException illegalAccessException) {
      Log.w("ICUCompatIcs", illegalAccessException);
    } catch (InvocationTargetException invocationTargetException) {
      Log.w("ICUCompatIcs", invocationTargetException);
    } 
    return paramString;
  }
  
  public static String getScript(String paramString) {
    try {
      if (sGetScriptMethod != null)
        return (String)sGetScriptMethod.invoke(null, new Object[] { paramString }); 
    } catch (IllegalAccessException illegalAccessException) {
      Log.w("ICUCompatIcs", illegalAccessException);
    } catch (InvocationTargetException invocationTargetException) {
      Log.w("ICUCompatIcs", invocationTargetException);
    } 
    return null;
  }
}


/* Location:              C:\soft\dex2jar-2.0\Smash Cricket-dex2jar.jar!\android\support\v4\text\ICUCompatIcs.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */