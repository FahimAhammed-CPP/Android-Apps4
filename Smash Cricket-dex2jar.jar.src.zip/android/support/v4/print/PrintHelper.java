package android.support.v4.print;

import android.content.Context;
import android.graphics.Bitmap;
import android.net.Uri;
import android.os.Build;
import java.io.FileNotFoundException;

public final class PrintHelper {
  public static final int COLOR_MODE_COLOR = 2;
  
  public static final int COLOR_MODE_MONOCHROME = 1;
  
  public static final int ORIENTATION_LANDSCAPE = 1;
  
  public static final int ORIENTATION_PORTRAIT = 2;
  
  public static final int SCALE_MODE_FILL = 2;
  
  public static final int SCALE_MODE_FIT = 1;
  
  PrintHelperVersionImpl mImpl;
  
  public PrintHelper(Context paramContext) {
    if (systemSupportsPrint()) {
      this.mImpl = new PrintHelperKitkatImpl(paramContext);
      return;
    } 
    this.mImpl = new PrintHelperStubImpl();
  }
  
  public static boolean systemSupportsPrint() {
    return (Build.VERSION.SDK_INT >= 19);
  }
  
  public int getColorMode() {
    return this.mImpl.getColorMode();
  }
  
  public int getOrientation() {
    return this.mImpl.getOrientation();
  }
  
  public int getScaleMode() {
    return this.mImpl.getScaleMode();
  }
  
  public void printBitmap(String paramString, Bitmap paramBitmap) {
    this.mImpl.printBitmap(paramString, paramBitmap);
  }
  
  public void printBitmap(String paramString, Uri paramUri) throws FileNotFoundException {
    this.mImpl.printBitmap(paramString, paramUri);
  }
  
  public void setColorMode(int paramInt) {
    this.mImpl.setColorMode(paramInt);
  }
  
  public void setOrientation(int paramInt) {
    this.mImpl.setOrientation(paramInt);
  }
  
  public void setScaleMode(int paramInt) {
    this.mImpl.setScaleMode(paramInt);
  }
  
  private static final class PrintHelperKitkatImpl implements PrintHelperVersionImpl {
    private final PrintHelperKitkat mPrintHelper;
    
    PrintHelperKitkatImpl(Context param1Context) {
      this.mPrintHelper = new PrintHelperKitkat(param1Context);
    }
    
    public int getColorMode() {
      return this.mPrintHelper.getColorMode();
    }
    
    public int getOrientation() {
      return this.mPrintHelper.getOrientation();
    }
    
    public int getScaleMode() {
      return this.mPrintHelper.getScaleMode();
    }
    
    public void printBitmap(String param1String, Bitmap param1Bitmap) {
      this.mPrintHelper.printBitmap(param1String, param1Bitmap);
    }
    
    public void printBitmap(String param1String, Uri param1Uri) throws FileNotFoundException {
      this.mPrintHelper.printBitmap(param1String, param1Uri);
    }
    
    public void setColorMode(int param1Int) {
      this.mPrintHelper.setColorMode(param1Int);
    }
    
    public void setOrientation(int param1Int) {
      this.mPrintHelper.setOrientation(param1Int);
    }
    
    public void setScaleMode(int param1Int) {
      this.mPrintHelper.setScaleMode(param1Int);
    }
  }
  
  private static final class PrintHelperStubImpl implements PrintHelperVersionImpl {
    int mColorMode = 2;
    
    int mOrientation = 1;
    
    int mScaleMode = 2;
    
    private PrintHelperStubImpl() {}
    
    public int getColorMode() {
      return this.mColorMode;
    }
    
    public int getOrientation() {
      return this.mOrientation;
    }
    
    public int getScaleMode() {
      return this.mScaleMode;
    }
    
    public void printBitmap(String param1String, Bitmap param1Bitmap) {}
    
    public void printBitmap(String param1String, Uri param1Uri) {}
    
    public void setColorMode(int param1Int) {
      this.mColorMode = param1Int;
    }
    
    public void setOrientation(int param1Int) {
      this.mOrientation = param1Int;
    }
    
    public void setScaleMode(int param1Int) {
      this.mScaleMode = param1Int;
    }
  }
  
  static interface PrintHelperVersionImpl {
    int getColorMode();
    
    int getOrientation();
    
    int getScaleMode();
    
    void printBitmap(String param1String, Bitmap param1Bitmap);
    
    void printBitmap(String param1String, Uri param1Uri) throws FileNotFoundException;
    
    void setColorMode(int param1Int);
    
    void setOrientation(int param1Int);
    
    void setScaleMode(int param1Int);
  }
}


/* Location:              C:\soft\dex2jar-2.0\Smash Cricket-dex2jar.jar!\android\support\v4\print\PrintHelper.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */