package android.support.v4.widget;

import android.content.Context;
import android.content.res.Resources;
import android.content.res.TypedArray;
import android.graphics.Canvas;
import android.os.Build;
import android.support.v4.view.MotionEventCompat;
import android.support.v4.view.ViewCompat;
import android.util.AttributeSet;
import android.util.DisplayMetrics;
import android.util.Log;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewConfiguration;
import android.view.ViewGroup;
import android.view.animation.AccelerateInterpolator;
import android.view.animation.Animation;
import android.view.animation.DecelerateInterpolator;
import android.view.animation.Interpolator;
import android.view.animation.Transformation;
import android.widget.AbsListView;

public class SwipeRefreshLayout extends ViewGroup {
  private static final float ACCELERATE_INTERPOLATION_FACTOR = 1.5F;
  
  private static final float DECELERATE_INTERPOLATION_FACTOR = 2.0F;
  
  private static final int INVALID_POINTER = -1;
  
  private static final int[] LAYOUT_ATTRS;
  
  private static final String LOG_TAG = SwipeRefreshLayout.class.getSimpleName();
  
  private static final float MAX_SWIPE_DISTANCE_FACTOR = 0.6F;
  
  private static final float PROGRESS_BAR_HEIGHT = 4.0F;
  
  private static final int REFRESH_TRIGGER_DISTANCE = 120;
  
  private static final long RETURN_TO_ORIGINAL_POSITION_TIMEOUT = 300L;
  
  private final AccelerateInterpolator mAccelerateInterpolator;
  
  private int mActivePointerId = -1;
  
  private final Animation mAnimateToStartPosition = new Animation() {
      public void applyTransformation(float param1Float, Transformation param1Transformation) {
        int i = 0;
        if (SwipeRefreshLayout.this.mFrom != SwipeRefreshLayout.this.mOriginalOffsetTop)
          i = SwipeRefreshLayout.this.mFrom + (int)((SwipeRefreshLayout.this.mOriginalOffsetTop - SwipeRefreshLayout.this.mFrom) * param1Float); 
        int j = i - SwipeRefreshLayout.this.mTarget.getTop();
        int k = SwipeRefreshLayout.this.mTarget.getTop();
        i = j;
        if (j + k < 0)
          i = 0 - k; 
        SwipeRefreshLayout.this.setTargetOffsetTopAndBottom(i);
      }
    };
  
  private final Runnable mCancel = new Runnable() {
      public void run() {
        SwipeRefreshLayout.access$902(SwipeRefreshLayout.this, true);
        if (SwipeRefreshLayout.this.mProgressBar != null) {
          SwipeRefreshLayout.access$402(SwipeRefreshLayout.this, SwipeRefreshLayout.this.mCurrPercentage);
          SwipeRefreshLayout.this.mShrinkTrigger.setDuration(SwipeRefreshLayout.this.mMediumAnimationDuration);
          SwipeRefreshLayout.this.mShrinkTrigger.setAnimationListener(SwipeRefreshLayout.this.mShrinkAnimationListener);
          SwipeRefreshLayout.this.mShrinkTrigger.reset();
          SwipeRefreshLayout.this.mShrinkTrigger.setInterpolator((Interpolator)SwipeRefreshLayout.this.mDecelerateInterpolator);
          SwipeRefreshLayout.this.startAnimation(SwipeRefreshLayout.this.mShrinkTrigger);
        } 
        SwipeRefreshLayout.this.animateOffsetToStartPosition(SwipeRefreshLayout.this.mCurrentTargetOffsetTop + SwipeRefreshLayout.this.getPaddingTop(), SwipeRefreshLayout.this.mReturnToStartPositionListener);
      }
    };
  
  private float mCurrPercentage = 0.0F;
  
  private int mCurrentTargetOffsetTop;
  
  private final DecelerateInterpolator mDecelerateInterpolator;
  
  private float mDistanceToTriggerSync = -1.0F;
  
  private int mFrom;
  
  private float mFromPercentage = 0.0F;
  
  private float mInitialMotionY;
  
  private boolean mIsBeingDragged;
  
  private float mLastMotionY;
  
  private OnRefreshListener mListener;
  
  private int mMediumAnimationDuration;
  
  private int mOriginalOffsetTop;
  
  private SwipeProgressBar mProgressBar;
  
  private int mProgressBarHeight;
  
  private boolean mRefreshing = false;
  
  private final Runnable mReturnToStartPosition = new Runnable() {
      public void run() {
        SwipeRefreshLayout.access$902(SwipeRefreshLayout.this, true);
        SwipeRefreshLayout.this.animateOffsetToStartPosition(SwipeRefreshLayout.this.mCurrentTargetOffsetTop + SwipeRefreshLayout.this.getPaddingTop(), SwipeRefreshLayout.this.mReturnToStartPositionListener);
      }
    };
  
  private final Animation.AnimationListener mReturnToStartPositionListener = new BaseAnimationListener() {
      public void onAnimationEnd(Animation param1Animation) {
        SwipeRefreshLayout.access$702(SwipeRefreshLayout.this, 0);
      }
    };
  
  private boolean mReturningToStart;
  
  private final Animation.AnimationListener mShrinkAnimationListener = new BaseAnimationListener() {
      public void onAnimationEnd(Animation param1Animation) {
        SwipeRefreshLayout.access$802(SwipeRefreshLayout.this, 0.0F);
      }
    };
  
  private Animation mShrinkTrigger = new Animation() {
      public void applyTransformation(float param1Float, Transformation param1Transformation) {
        float f1 = SwipeRefreshLayout.this.mFromPercentage;
        float f2 = SwipeRefreshLayout.this.mFromPercentage;
        SwipeRefreshLayout.this.mProgressBar.setTriggerPercentage(f1 + (0.0F - f2) * param1Float);
      }
    };
  
  private View mTarget;
  
  private int mTouchSlop;
  
  static {
    LAYOUT_ATTRS = new int[] { 16842766 };
  }
  
  public SwipeRefreshLayout(Context paramContext) {
    this(paramContext, (AttributeSet)null);
  }
  
  public SwipeRefreshLayout(Context paramContext, AttributeSet paramAttributeSet) {
    super(paramContext, paramAttributeSet);
    this.mTouchSlop = ViewConfiguration.get(paramContext).getScaledTouchSlop();
    this.mMediumAnimationDuration = getResources().getInteger(17694721);
    setWillNotDraw(false);
    this.mProgressBar = new SwipeProgressBar((View)this);
    this.mProgressBarHeight = (int)((getResources().getDisplayMetrics()).density * 4.0F);
    this.mDecelerateInterpolator = new DecelerateInterpolator(2.0F);
    this.mAccelerateInterpolator = new AccelerateInterpolator(1.5F);
    TypedArray typedArray = paramContext.obtainStyledAttributes(paramAttributeSet, LAYOUT_ATTRS);
    setEnabled(typedArray.getBoolean(0, true));
    typedArray.recycle();
  }
  
  private void animateOffsetToStartPosition(int paramInt, Animation.AnimationListener paramAnimationListener) {
    this.mFrom = paramInt;
    this.mAnimateToStartPosition.reset();
    this.mAnimateToStartPosition.setDuration(this.mMediumAnimationDuration);
    this.mAnimateToStartPosition.setAnimationListener(paramAnimationListener);
    this.mAnimateToStartPosition.setInterpolator((Interpolator)this.mDecelerateInterpolator);
    this.mTarget.startAnimation(this.mAnimateToStartPosition);
  }
  
  private void ensureTarget() {
    if (this.mTarget == null) {
      if (getChildCount() > 1 && !isInEditMode())
        throw new IllegalStateException("SwipeRefreshLayout can host only one direct child"); 
      this.mTarget = getChildAt(0);
      this.mOriginalOffsetTop = this.mTarget.getTop() + getPaddingTop();
    } 
    if (this.mDistanceToTriggerSync == -1.0F && getParent() != null && ((View)getParent()).getHeight() > 0) {
      DisplayMetrics displayMetrics = getResources().getDisplayMetrics();
      this.mDistanceToTriggerSync = (int)Math.min(((View)getParent()).getHeight() * 0.6F, 120.0F * displayMetrics.density);
    } 
  }
  
  private void onSecondaryPointerUp(MotionEvent paramMotionEvent) {
    int i = MotionEventCompat.getActionIndex(paramMotionEvent);
    if (MotionEventCompat.getPointerId(paramMotionEvent, i) == this.mActivePointerId) {
      if (i == 0) {
        i = 1;
      } else {
        i = 0;
      } 
      this.mLastMotionY = MotionEventCompat.getY(paramMotionEvent, i);
      this.mActivePointerId = MotionEventCompat.getPointerId(paramMotionEvent, i);
    } 
  }
  
  private void setTargetOffsetTopAndBottom(int paramInt) {
    this.mTarget.offsetTopAndBottom(paramInt);
    this.mCurrentTargetOffsetTop = this.mTarget.getTop();
  }
  
  private void setTriggerPercentage(float paramFloat) {
    if (paramFloat == 0.0F) {
      this.mCurrPercentage = 0.0F;
      return;
    } 
    this.mCurrPercentage = paramFloat;
    this.mProgressBar.setTriggerPercentage(paramFloat);
  }
  
  private void startRefresh() {
    removeCallbacks(this.mCancel);
    this.mReturnToStartPosition.run();
    setRefreshing(true);
    this.mListener.onRefresh();
  }
  
  private void updateContentOffsetTop(int paramInt) {
    int i;
    int j = this.mTarget.getTop();
    if (paramInt > this.mDistanceToTriggerSync) {
      i = (int)this.mDistanceToTriggerSync;
    } else {
      i = paramInt;
      if (paramInt < 0)
        i = 0; 
    } 
    setTargetOffsetTopAndBottom(i - j);
  }
  
  private void updatePositionTimeout() {
    removeCallbacks(this.mCancel);
    postDelayed(this.mCancel, 300L);
  }
  
  public boolean canChildScrollUp() {
    if (Build.VERSION.SDK_INT < 14) {
      if (this.mTarget instanceof AbsListView) {
        AbsListView absListView = (AbsListView)this.mTarget;
        return !(absListView.getChildCount() <= 0 || (absListView.getFirstVisiblePosition() <= 0 && absListView.getChildAt(0).getTop() >= absListView.getPaddingTop()));
      } 
      return !(this.mTarget.getScrollY() <= 0);
    } 
    return ViewCompat.canScrollVertically(this.mTarget, -1);
  }
  
  public void draw(Canvas paramCanvas) {
    super.draw(paramCanvas);
    this.mProgressBar.draw(paramCanvas);
  }
  
  public boolean isRefreshing() {
    return this.mRefreshing;
  }
  
  public void onAttachedToWindow() {
    super.onAttachedToWindow();
    removeCallbacks(this.mCancel);
    removeCallbacks(this.mReturnToStartPosition);
  }
  
  public void onDetachedFromWindow() {
    super.onDetachedFromWindow();
    removeCallbacks(this.mReturnToStartPosition);
    removeCallbacks(this.mCancel);
  }
  
  public boolean onInterceptTouchEvent(MotionEvent paramMotionEvent) {
    float f;
    ensureTarget();
    int i = MotionEventCompat.getActionMasked(paramMotionEvent);
    if (this.mReturningToStart && i == 0)
      this.mReturningToStart = false; 
    if (!isEnabled() || this.mReturningToStart || canChildScrollUp())
      return false; 
    switch (i) {
      default:
        return this.mIsBeingDragged;
      case 0:
        f = paramMotionEvent.getY();
        this.mInitialMotionY = f;
        this.mLastMotionY = f;
        this.mActivePointerId = MotionEventCompat.getPointerId(paramMotionEvent, 0);
        this.mIsBeingDragged = false;
        this.mCurrPercentage = 0.0F;
      case 2:
        if (this.mActivePointerId == -1) {
          Log.e(LOG_TAG, "Got ACTION_MOVE event but don't have an active pointer id.");
          return false;
        } 
        i = MotionEventCompat.findPointerIndex(paramMotionEvent, this.mActivePointerId);
        if (i < 0) {
          Log.e(LOG_TAG, "Got ACTION_MOVE event but have an invalid active pointer id.");
          return false;
        } 
        f = MotionEventCompat.getY(paramMotionEvent, i);
        if (f - this.mInitialMotionY > this.mTouchSlop) {
          this.mLastMotionY = f;
          this.mIsBeingDragged = true;
        } 
      case 6:
        onSecondaryPointerUp(paramMotionEvent);
      case 1:
      case 3:
        break;
    } 
    this.mIsBeingDragged = false;
    this.mCurrPercentage = 0.0F;
    this.mActivePointerId = -1;
  }
  
  protected void onLayout(boolean paramBoolean, int paramInt1, int paramInt2, int paramInt3, int paramInt4) {
    paramInt1 = getMeasuredWidth();
    paramInt2 = getMeasuredHeight();
    this.mProgressBar.setBounds(0, 0, paramInt1, this.mProgressBarHeight);
    if (getChildCount() == 0)
      return; 
    View view = getChildAt(0);
    paramInt3 = getPaddingLeft();
    paramInt4 = this.mCurrentTargetOffsetTop + getPaddingTop();
    view.layout(paramInt3, paramInt4, paramInt3 + paramInt1 - getPaddingLeft() - getPaddingRight(), paramInt4 + paramInt2 - getPaddingTop() - getPaddingBottom());
  }
  
  public void onMeasure(int paramInt1, int paramInt2) {
    super.onMeasure(paramInt1, paramInt2);
    if (getChildCount() > 1 && !isInEditMode())
      throw new IllegalStateException("SwipeRefreshLayout can host only one direct child"); 
    if (getChildCount() > 0)
      getChildAt(0).measure(View.MeasureSpec.makeMeasureSpec(getMeasuredWidth() - getPaddingLeft() - getPaddingRight(), 1073741824), View.MeasureSpec.makeMeasureSpec(getMeasuredHeight() - getPaddingTop() - getPaddingBottom(), 1073741824)); 
  }
  
  public boolean onTouchEvent(MotionEvent paramMotionEvent) {
    float f1;
    float f2;
    int i = MotionEventCompat.getActionMasked(paramMotionEvent);
    if (this.mReturningToStart && i == 0)
      this.mReturningToStart = false; 
    if (!isEnabled() || this.mReturningToStart || canChildScrollUp())
      return false; 
    switch (i) {
      default:
        return true;
      case 0:
        f1 = paramMotionEvent.getY();
        this.mInitialMotionY = f1;
        this.mLastMotionY = f1;
        this.mActivePointerId = MotionEventCompat.getPointerId(paramMotionEvent, 0);
        this.mIsBeingDragged = false;
        this.mCurrPercentage = 0.0F;
      case 2:
        i = MotionEventCompat.findPointerIndex(paramMotionEvent, this.mActivePointerId);
        if (i < 0) {
          Log.e(LOG_TAG, "Got ACTION_MOVE event but have an invalid active pointer id.");
          return false;
        } 
        f1 = MotionEventCompat.getY(paramMotionEvent, i);
        f2 = f1 - this.mInitialMotionY;
        if (!this.mIsBeingDragged && f2 > this.mTouchSlop)
          this.mIsBeingDragged = true; 
        if (this.mIsBeingDragged) {
          if (f2 > this.mDistanceToTriggerSync) {
            startRefresh();
          } else {
            setTriggerPercentage(this.mAccelerateInterpolator.getInterpolation(f2 / this.mDistanceToTriggerSync));
            updateContentOffsetTop((int)f2);
            if (this.mLastMotionY > f1 && this.mTarget.getTop() == getPaddingTop()) {
              removeCallbacks(this.mCancel);
            } else {
              updatePositionTimeout();
            } 
          } 
          this.mLastMotionY = f1;
        } 
      case 5:
        i = MotionEventCompat.getActionIndex(paramMotionEvent);
        this.mLastMotionY = MotionEventCompat.getY(paramMotionEvent, i);
        this.mActivePointerId = MotionEventCompat.getPointerId(paramMotionEvent, i);
      case 6:
        onSecondaryPointerUp(paramMotionEvent);
      case 1:
      case 3:
        break;
    } 
    this.mIsBeingDragged = false;
    this.mCurrPercentage = 0.0F;
    this.mActivePointerId = -1;
    return false;
  }
  
  public void requestDisallowInterceptTouchEvent(boolean paramBoolean) {}
  
  @Deprecated
  public void setColorScheme(int paramInt1, int paramInt2, int paramInt3, int paramInt4) {
    setColorSchemeResources(paramInt1, paramInt2, paramInt3, paramInt4);
  }
  
  public void setColorSchemeColors(int paramInt1, int paramInt2, int paramInt3, int paramInt4) {
    ensureTarget();
    this.mProgressBar.setColorScheme(paramInt1, paramInt2, paramInt3, paramInt4);
  }
  
  public void setColorSchemeResources(int paramInt1, int paramInt2, int paramInt3, int paramInt4) {
    Resources resources = getResources();
    setColorSchemeColors(resources.getColor(paramInt1), resources.getColor(paramInt2), resources.getColor(paramInt3), resources.getColor(paramInt4));
  }
  
  public void setOnRefreshListener(OnRefreshListener paramOnRefreshListener) {
    this.mListener = paramOnRefreshListener;
  }
  
  public void setRefreshing(boolean paramBoolean) {
    if (this.mRefreshing != paramBoolean) {
      ensureTarget();
      this.mCurrPercentage = 0.0F;
      this.mRefreshing = paramBoolean;
      if (this.mRefreshing) {
        this.mProgressBar.start();
        return;
      } 
    } else {
      return;
    } 
    this.mProgressBar.stop();
  }
  
  private class BaseAnimationListener implements Animation.AnimationListener {
    private BaseAnimationListener() {}
    
    public void onAnimationEnd(Animation param1Animation) {}
    
    public void onAnimationRepeat(Animation param1Animation) {}
    
    public void onAnimationStart(Animation param1Animation) {}
  }
  
  public static interface OnRefreshListener {
    void onRefresh();
  }
}


/* Location:              C:\soft\dex2jar-2.0\Smash Cricket-dex2jar.jar!\android\support\v4\widget\SwipeRefreshLayout.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */