package bolts;

import android.content.Context;
import android.content.Intent;
import android.content.pm.ApplicationInfo;
import android.net.Uri;
import android.os.Bundle;
import android.util.SparseArray;
import java.net.URL;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

public class AppLinkNavigation {
  private static final String KEY_NAME_REFERER_APP_LINK = "referer_app_link";
  
  private static final String KEY_NAME_REFERER_APP_LINK_APP_NAME = "app_name";
  
  private static final String KEY_NAME_REFERER_APP_LINK_PACKAGE = "package";
  
  private static final String KEY_NAME_USER_AGENT = "user_agent";
  
  private static final String KEY_NAME_VERSION = "version";
  
  private static final String VERSION = "1.0";
  
  private static AppLinkResolver defaultResolver;
  
  private final AppLink appLink;
  
  private final Bundle appLinkData;
  
  private final Bundle extras;
  
  public AppLinkNavigation(AppLink paramAppLink, Bundle paramBundle1, Bundle paramBundle2) {
    if (paramAppLink == null)
      throw new IllegalArgumentException("appLink must not be null."); 
    Bundle bundle = paramBundle1;
    if (paramBundle1 == null)
      bundle = new Bundle(); 
    paramBundle1 = paramBundle2;
    if (paramBundle2 == null)
      paramBundle1 = new Bundle(); 
    this.appLink = paramAppLink;
    this.extras = bundle;
    this.appLinkData = paramBundle1;
  }
  
  private Bundle buildAppLinkDataForNavigation(Context paramContext) {
    Bundle bundle1 = new Bundle();
    Bundle bundle2 = new Bundle();
    if (paramContext != null) {
      String str = paramContext.getPackageName();
      if (str != null)
        bundle2.putString("package", str); 
      ApplicationInfo applicationInfo = paramContext.getApplicationInfo();
      if (applicationInfo != null) {
        String str1 = paramContext.getString(applicationInfo.labelRes);
        if (str1 != null)
          bundle2.putString("app_name", str1); 
      } 
    } 
    bundle1.putAll(getAppLinkData());
    bundle1.putString("target_url", getAppLink().getSourceUrl().toString());
    bundle1.putString("version", "1.0");
    bundle1.putString("user_agent", "Bolts Android 1.1.2");
    bundle1.putBundle("referer_app_link", bundle2);
    bundle1.putBundle("extras", getExtras());
    return bundle1;
  }
  
  public static AppLinkResolver getDefaultResolver() {
    return defaultResolver;
  }
  
  private JSONObject getJSONForBundle(Bundle paramBundle) throws JSONException {
    JSONObject jSONObject = new JSONObject();
    for (String str : paramBundle.keySet())
      jSONObject.put(str, getJSONValue(paramBundle.get(str))); 
    return jSONObject;
  }
  
  private Object getJSONValue(Object paramObject) throws JSONException {
    if (paramObject instanceof Bundle)
      return getJSONForBundle((Bundle)paramObject); 
    if (paramObject instanceof CharSequence)
      return paramObject.toString(); 
    if (paramObject instanceof List) {
      JSONArray jSONArray = new JSONArray();
      Iterator iterator = ((List)paramObject).iterator();
      while (true) {
        paramObject = jSONArray;
        if (iterator.hasNext()) {
          jSONArray.put(getJSONValue(iterator.next()));
          continue;
        } 
        return paramObject;
      } 
    } 
    if (paramObject instanceof SparseArray) {
      JSONArray jSONArray = new JSONArray();
      SparseArray sparseArray = (SparseArray)paramObject;
      int i = 0;
      while (true) {
        paramObject = jSONArray;
        if (i < sparseArray.size()) {
          jSONArray.put(sparseArray.keyAt(i), getJSONValue(sparseArray.valueAt(i)));
          i++;
          continue;
        } 
        return paramObject;
      } 
    } 
    if (paramObject instanceof Character)
      return paramObject.toString(); 
    if (paramObject instanceof Boolean)
      return paramObject; 
    if (paramObject instanceof Number)
      return (paramObject instanceof Double || paramObject instanceof Float) ? Double.valueOf(((Number)paramObject).doubleValue()) : Long.valueOf(((Number)paramObject).longValue()); 
    if (paramObject instanceof boolean[]) {
      JSONArray jSONArray = new JSONArray();
      boolean[] arrayOfBoolean = (boolean[])paramObject;
      int j = arrayOfBoolean.length;
      int i = 0;
      while (true) {
        paramObject = jSONArray;
        if (i < j) {
          jSONArray.put(getJSONValue(Boolean.valueOf(arrayOfBoolean[i])));
          i++;
          continue;
        } 
        return paramObject;
      } 
    } 
    if (paramObject instanceof char[]) {
      JSONArray jSONArray = new JSONArray();
      char[] arrayOfChar = (char[])paramObject;
      int j = arrayOfChar.length;
      int i = 0;
      while (true) {
        paramObject = jSONArray;
        if (i < j) {
          jSONArray.put(getJSONValue(Character.valueOf(arrayOfChar[i])));
          i++;
          continue;
        } 
        return paramObject;
      } 
    } 
    if (paramObject instanceof CharSequence[]) {
      JSONArray jSONArray = new JSONArray();
      CharSequence[] arrayOfCharSequence = (CharSequence[])paramObject;
      int j = arrayOfCharSequence.length;
      int i = 0;
      while (true) {
        paramObject = jSONArray;
        if (i < j) {
          jSONArray.put(getJSONValue(arrayOfCharSequence[i]));
          i++;
          continue;
        } 
        return paramObject;
      } 
    } 
    if (paramObject instanceof double[]) {
      JSONArray jSONArray = new JSONArray();
      double[] arrayOfDouble = (double[])paramObject;
      int j = arrayOfDouble.length;
      int i = 0;
      while (true) {
        paramObject = jSONArray;
        if (i < j) {
          jSONArray.put(getJSONValue(Double.valueOf(arrayOfDouble[i])));
          i++;
          continue;
        } 
        return paramObject;
      } 
    } 
    if (paramObject instanceof float[]) {
      JSONArray jSONArray = new JSONArray();
      float[] arrayOfFloat = (float[])paramObject;
      int j = arrayOfFloat.length;
      int i = 0;
      while (true) {
        paramObject = jSONArray;
        if (i < j) {
          jSONArray.put(getJSONValue(Float.valueOf(arrayOfFloat[i])));
          i++;
          continue;
        } 
        return paramObject;
      } 
    } 
    if (paramObject instanceof int[]) {
      JSONArray jSONArray = new JSONArray();
      int[] arrayOfInt = (int[])paramObject;
      int j = arrayOfInt.length;
      int i = 0;
      while (true) {
        paramObject = jSONArray;
        if (i < j) {
          jSONArray.put(getJSONValue(Integer.valueOf(arrayOfInt[i])));
          i++;
          continue;
        } 
        return paramObject;
      } 
    } 
    if (paramObject instanceof long[]) {
      JSONArray jSONArray = new JSONArray();
      long[] arrayOfLong = (long[])paramObject;
      int j = arrayOfLong.length;
      int i = 0;
      while (true) {
        paramObject = jSONArray;
        if (i < j) {
          jSONArray.put(getJSONValue(Long.valueOf(arrayOfLong[i])));
          i++;
          continue;
        } 
        return paramObject;
      } 
    } 
    if (paramObject instanceof short[]) {
      JSONArray jSONArray = new JSONArray();
      short[] arrayOfShort = (short[])paramObject;
      int j = arrayOfShort.length;
      int i = 0;
      while (true) {
        paramObject = jSONArray;
        if (i < j) {
          jSONArray.put(getJSONValue(Short.valueOf(arrayOfShort[i])));
          i++;
          continue;
        } 
        return paramObject;
      } 
    } 
    if (paramObject instanceof String[]) {
      JSONArray jSONArray = new JSONArray();
      String[] arrayOfString = (String[])paramObject;
      int j = arrayOfString.length;
      int i = 0;
      while (true) {
        paramObject = jSONArray;
        if (i < j) {
          jSONArray.put(getJSONValue(arrayOfString[i]));
          i++;
          continue;
        } 
        return paramObject;
      } 
    } 
    return null;
  }
  
  private static AppLinkResolver getResolver(Context paramContext) {
    return (getDefaultResolver() != null) ? getDefaultResolver() : new WebViewAppLinkResolver(paramContext);
  }
  
  public static NavigationResult navigate(Context paramContext, AppLink paramAppLink) {
    return (new AppLinkNavigation(paramAppLink, null, null)).navigate(paramContext);
  }
  
  public static Task<NavigationResult> navigateInBackground(Context paramContext, Uri paramUri) {
    return navigateInBackground(paramContext, paramUri, getResolver(paramContext));
  }
  
  public static Task<NavigationResult> navigateInBackground(final Context context, Uri paramUri, AppLinkResolver paramAppLinkResolver) {
    return paramAppLinkResolver.getAppLinkFromUrlInBackground(paramUri).onSuccess(new Continuation<AppLink, NavigationResult>() {
          public AppLinkNavigation.NavigationResult then(Task<AppLink> param1Task) throws Exception {
            return AppLinkNavigation.navigate(context, param1Task.getResult());
          }
        }Task.UI_THREAD_EXECUTOR);
  }
  
  public static Task<NavigationResult> navigateInBackground(Context paramContext, String paramString) {
    return navigateInBackground(paramContext, paramString, getResolver(paramContext));
  }
  
  public static Task<NavigationResult> navigateInBackground(Context paramContext, String paramString, AppLinkResolver paramAppLinkResolver) {
    return navigateInBackground(paramContext, Uri.parse(paramString), paramAppLinkResolver);
  }
  
  public static Task<NavigationResult> navigateInBackground(Context paramContext, URL paramURL) {
    return navigateInBackground(paramContext, paramURL, getResolver(paramContext));
  }
  
  public static Task<NavigationResult> navigateInBackground(Context paramContext, URL paramURL, AppLinkResolver paramAppLinkResolver) {
    return navigateInBackground(paramContext, Uri.parse(paramURL.toString()), paramAppLinkResolver);
  }
  
  private void sendAppLinkNavigateEventBroadcast(Context paramContext, Intent paramIntent, NavigationResult paramNavigationResult, JSONException paramJSONException) {
    String str;
    HashMap<Object, Object> hashMap = new HashMap<Object, Object>();
    if (paramJSONException != null)
      hashMap.put("error", paramJSONException.getLocalizedMessage()); 
    if (paramNavigationResult.isSucceeded()) {
      str = "1";
    } else {
      str = "0";
    } 
    hashMap.put("success", str);
    hashMap.put("type", paramNavigationResult.getCode());
    MeasurementEvent.sendBroadcastEvent(paramContext, "al_nav_out", paramIntent, (Map)hashMap);
  }
  
  public static void setDefaultResolver(AppLinkResolver paramAppLinkResolver) {
    defaultResolver = paramAppLinkResolver;
  }
  
  public AppLink getAppLink() {
    return this.appLink;
  }
  
  public Bundle getAppLinkData() {
    return this.appLinkData;
  }
  
  public Bundle getExtras() {
    return this.extras;
  }
  
  public NavigationResult navigate(Context paramContext) {
    // Byte code:
    //   0: aload_1
    //   1: invokevirtual getPackageManager : ()Landroid/content/pm/PackageManager;
    //   4: astore #4
    //   6: aload_0
    //   7: aload_1
    //   8: invokespecial buildAppLinkDataForNavigation : (Landroid/content/Context;)Landroid/os/Bundle;
    //   11: astore #5
    //   13: aconst_null
    //   14: astore_3
    //   15: aload_0
    //   16: invokevirtual getAppLink : ()Lbolts/AppLink;
    //   19: invokevirtual getTargets : ()Ljava/util/List;
    //   22: invokeinterface iterator : ()Ljava/util/Iterator;
    //   27: astore #6
    //   29: aload_3
    //   30: astore_2
    //   31: aload #6
    //   33: invokeinterface hasNext : ()Z
    //   38: ifeq -> 137
    //   41: aload #6
    //   43: invokeinterface next : ()Ljava/lang/Object;
    //   48: checkcast bolts/AppLink$Target
    //   51: astore #7
    //   53: new android/content/Intent
    //   56: dup
    //   57: ldc_w 'android.intent.action.VIEW'
    //   60: invokespecial <init> : (Ljava/lang/String;)V
    //   63: astore_2
    //   64: aload #7
    //   66: invokevirtual getUrl : ()Landroid/net/Uri;
    //   69: ifnull -> 176
    //   72: aload_2
    //   73: aload #7
    //   75: invokevirtual getUrl : ()Landroid/net/Uri;
    //   78: invokevirtual setData : (Landroid/net/Uri;)Landroid/content/Intent;
    //   81: pop
    //   82: aload_2
    //   83: aload #7
    //   85: invokevirtual getPackageName : ()Ljava/lang/String;
    //   88: invokevirtual setPackage : (Ljava/lang/String;)Landroid/content/Intent;
    //   91: pop
    //   92: aload #7
    //   94: invokevirtual getClassName : ()Ljava/lang/String;
    //   97: ifnull -> 115
    //   100: aload_2
    //   101: aload #7
    //   103: invokevirtual getPackageName : ()Ljava/lang/String;
    //   106: aload #7
    //   108: invokevirtual getClassName : ()Ljava/lang/String;
    //   111: invokevirtual setClassName : (Ljava/lang/String;Ljava/lang/String;)Landroid/content/Intent;
    //   114: pop
    //   115: aload_2
    //   116: ldc_w 'al_applink_data'
    //   119: aload #5
    //   121: invokevirtual putExtra : (Ljava/lang/String;Landroid/os/Bundle;)Landroid/content/Intent;
    //   124: pop
    //   125: aload #4
    //   127: aload_2
    //   128: ldc_w 65536
    //   131: invokevirtual resolveActivity : (Landroid/content/Intent;I)Landroid/content/pm/ResolveInfo;
    //   134: ifnull -> 29
    //   137: aconst_null
    //   138: astore_3
    //   139: getstatic bolts/AppLinkNavigation$NavigationResult.FAILED : Lbolts/AppLinkNavigation$NavigationResult;
    //   142: astore #4
    //   144: aload_2
    //   145: ifnull -> 191
    //   148: getstatic bolts/AppLinkNavigation$NavigationResult.APP : Lbolts/AppLinkNavigation$NavigationResult;
    //   151: astore #4
    //   153: aload_2
    //   154: astore_3
    //   155: aload_0
    //   156: aload_1
    //   157: aload_3
    //   158: aload #4
    //   160: aconst_null
    //   161: invokespecial sendAppLinkNavigateEventBroadcast : (Landroid/content/Context;Landroid/content/Intent;Lbolts/AppLinkNavigation$NavigationResult;Lorg/json/JSONException;)V
    //   164: aload_3
    //   165: ifnull -> 173
    //   168: aload_1
    //   169: aload_3
    //   170: invokevirtual startActivity : (Landroid/content/Intent;)V
    //   173: aload #4
    //   175: areturn
    //   176: aload_2
    //   177: aload_0
    //   178: getfield appLink : Lbolts/AppLink;
    //   181: invokevirtual getSourceUrl : ()Landroid/net/Uri;
    //   184: invokevirtual setData : (Landroid/net/Uri;)Landroid/content/Intent;
    //   187: pop
    //   188: goto -> 82
    //   191: aload_0
    //   192: invokevirtual getAppLink : ()Lbolts/AppLink;
    //   195: invokevirtual getWebUrl : ()Landroid/net/Uri;
    //   198: astore #6
    //   200: aload #6
    //   202: ifnull -> 155
    //   205: aload_0
    //   206: aload #5
    //   208: invokespecial getJSONForBundle : (Landroid/os/Bundle;)Lorg/json/JSONObject;
    //   211: astore_3
    //   212: new android/content/Intent
    //   215: dup
    //   216: ldc_w 'android.intent.action.VIEW'
    //   219: aload #6
    //   221: invokevirtual buildUpon : ()Landroid/net/Uri$Builder;
    //   224: ldc_w 'al_applink_data'
    //   227: aload_3
    //   228: invokevirtual toString : ()Ljava/lang/String;
    //   231: invokevirtual appendQueryParameter : (Ljava/lang/String;Ljava/lang/String;)Landroid/net/Uri$Builder;
    //   234: invokevirtual build : ()Landroid/net/Uri;
    //   237: invokespecial <init> : (Ljava/lang/String;Landroid/net/Uri;)V
    //   240: astore_3
    //   241: getstatic bolts/AppLinkNavigation$NavigationResult.WEB : Lbolts/AppLinkNavigation$NavigationResult;
    //   244: astore #4
    //   246: goto -> 155
    //   249: astore_3
    //   250: aload_0
    //   251: aload_1
    //   252: aload_2
    //   253: getstatic bolts/AppLinkNavigation$NavigationResult.FAILED : Lbolts/AppLinkNavigation$NavigationResult;
    //   256: aload_3
    //   257: invokespecial sendAppLinkNavigateEventBroadcast : (Landroid/content/Context;Landroid/content/Intent;Lbolts/AppLinkNavigation$NavigationResult;Lorg/json/JSONException;)V
    //   260: new java/lang/RuntimeException
    //   263: dup
    //   264: aload_3
    //   265: invokespecial <init> : (Ljava/lang/Throwable;)V
    //   268: athrow
    // Exception table:
    //   from	to	target	type
    //   205	212	249	org/json/JSONException
  }
  
  public enum NavigationResult {
    APP,
    FAILED("failed", false),
    WEB("web", true);
    
    private String code;
    
    private boolean succeeded;
    
    static {
      $VALUES = new NavigationResult[] { FAILED, WEB, APP };
    }
    
    NavigationResult(String param1String1, boolean param1Boolean) {
      this.code = param1String1;
      this.succeeded = param1Boolean;
    }
    
    public String getCode() {
      return this.code;
    }
    
    public boolean isSucceeded() {
      return this.succeeded;
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Smash Cricket-dex2jar.jar!\bolts\AppLinkNavigation.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */