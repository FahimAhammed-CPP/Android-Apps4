package bolts;

import android.content.Context;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;

public final class AppLinks {
  static final String KEY_NAME_APPLINK_DATA = "al_applink_data";
  
  static final String KEY_NAME_EXTRAS = "extras";
  
  static final String KEY_NAME_TARGET = "target_url";
  
  public static Bundle getAppLinkData(Intent paramIntent) {
    return paramIntent.getBundleExtra("al_applink_data");
  }
  
  public static Bundle getAppLinkExtras(Intent paramIntent) {
    Bundle bundle = getAppLinkData(paramIntent);
    return (bundle == null) ? null : bundle.getBundle("extras");
  }
  
  public static Uri getTargetUrl(Intent paramIntent) {
    Bundle bundle = getAppLinkData(paramIntent);
    if (bundle != null) {
      String str = bundle.getString("target_url");
      if (str != null)
        return Uri.parse(str); 
    } 
    return paramIntent.getData();
  }
  
  public static Uri getTargetUrlFromInboundIntent(Context paramContext, Intent paramIntent) {
    Uri uri2 = null;
    Bundle bundle = getAppLinkData(paramIntent);
    Uri uri1 = uri2;
    if (bundle != null) {
      String str = bundle.getString("target_url");
      uri1 = uri2;
      if (str != null) {
        MeasurementEvent.sendBroadcastEvent(paramContext, "al_nav_in", paramIntent, null);
        uri1 = Uri.parse(str);
      } 
    } 
    return uri1;
  }
}


/* Location:              C:\soft\dex2jar-2.0\Smash Cricket-dex2jar.jar!\bolts\AppLinks.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */