package bolts;

import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.util.Log;
import java.lang.reflect.Method;
import java.util.Collection;
import java.util.Map;
import org.json.JSONArray;
import org.json.JSONObject;

public class MeasurementEvent {
  public static final String APP_LINK_NAVIGATE_IN_EVENT_NAME = "al_nav_in";
  
  public static final String APP_LINK_NAVIGATE_OUT_EVENT_NAME = "al_nav_out";
  
  public static final String MEASUREMENT_EVENT_ARGS_KEY = "event_args";
  
  public static final String MEASUREMENT_EVENT_NAME_KEY = "event_name";
  
  public static final String MEASUREMENT_EVENT_NOTIFICATION_NAME = "com.parse.bolts.measurement_event";
  
  private Context appContext;
  
  private Bundle args;
  
  private String name;
  
  private MeasurementEvent(Context paramContext, String paramString, Bundle paramBundle) {
    this.appContext = paramContext.getApplicationContext();
    this.name = paramString;
    this.args = paramBundle;
  }
  
  private static Bundle getApplinkLogData(Context paramContext, String paramString, Bundle paramBundle, Intent paramIntent) {
    Bundle bundle = new Bundle();
    ComponentName componentName = paramIntent.resolveActivity(paramContext.getPackageManager());
    if (componentName != null)
      bundle.putString("class", componentName.getShortClassName()); 
    if ("al_nav_out".equals(paramString)) {
      if (componentName != null)
        bundle.putString("package", componentName.getPackageName()); 
      if (paramIntent.getData() != null)
        bundle.putString("outputURL", paramIntent.getData().toString()); 
      if (paramIntent.getScheme() != null)
        bundle.putString("outputURLScheme", paramIntent.getScheme()); 
    } else if ("al_nav_in".equals(paramString)) {
      if (paramIntent.getData() != null)
        bundle.putString("inputURL", paramIntent.getData().toString()); 
      if (paramIntent.getScheme() != null)
        bundle.putString("inputURLScheme", paramIntent.getScheme()); 
    } 
    for (String paramString : paramBundle.keySet()) {
      Uri uri;
      Object object = paramBundle.get(paramString);
      if (object instanceof Bundle) {
        for (String str1 : ((Bundle)object).keySet()) {
          String str2 = objectToJSONString(((Bundle)object).get(str1));
          if (paramString.equals("referer_app_link")) {
            if (str1.equalsIgnoreCase("url")) {
              bundle.putString("refererURL", str2);
              continue;
            } 
            if (str1.equalsIgnoreCase("app_name")) {
              bundle.putString("refererAppName", str2);
              continue;
            } 
            if (str1.equalsIgnoreCase("package")) {
              bundle.putString("sourceApplication", str2);
              continue;
            } 
          } 
          bundle.putString(paramString + "/" + str1, str2);
        } 
        continue;
      } 
      object = objectToJSONString(object);
      if (paramString.equals("target_url")) {
        uri = Uri.parse((String)object);
        bundle.putString("targetURL", uri.toString());
        bundle.putString("targetURLHost", uri.getHost());
        continue;
      } 
      bundle.putString((String)uri, (String)object);
    } 
    return bundle;
  }
  
  private static String objectToJSONString(Object paramObject) {
    if (paramObject == null)
      return null; 
    if (paramObject instanceof JSONArray || paramObject instanceof JSONObject)
      return paramObject.toString(); 
    try {
      return (paramObject instanceof Collection) ? (new JSONArray((Collection)paramObject)).toString() : ((paramObject instanceof Map) ? (new JSONObject((Map)paramObject)).toString() : paramObject.toString());
    } catch (Exception exception) {
      return null;
    } 
  }
  
  private void sendBroadcast() {
    if (this.name == null)
      Log.d(getClass().getName(), "Event name is required"); 
    try {
      Class<?> clazz = Class.forName("android.support.v4.content.LocalBroadcastManager");
      Method method2 = clazz.getMethod("getInstance", new Class[] { Context.class });
      Method method1 = clazz.getMethod("sendBroadcast", new Class[] { Intent.class });
      Object object = method2.invoke(null, new Object[] { this.appContext });
      Intent intent = new Intent("com.parse.bolts.measurement_event");
      intent.putExtra("event_name", this.name);
      intent.putExtra("event_args", this.args);
      method1.invoke(object, new Object[] { intent });
      return;
    } catch (Exception exception) {
      Log.d(getClass().getName(), "LocalBroadcastManager in android support library is required to raise bolts event.");
      return;
    } 
  }
  
  static void sendBroadcastEvent(Context paramContext, String paramString, Intent paramIntent, Map<String, String> paramMap) {
    // Byte code:
    //   0: new android/os/Bundle
    //   3: dup
    //   4: invokespecial <init> : ()V
    //   7: astore #5
    //   9: aload #5
    //   11: astore #4
    //   13: aload_2
    //   14: ifnull -> 38
    //   17: aload_2
    //   18: invokestatic getAppLinkData : (Landroid/content/Intent;)Landroid/os/Bundle;
    //   21: astore #4
    //   23: aload #4
    //   25: ifnull -> 95
    //   28: aload_0
    //   29: aload_1
    //   30: aload #4
    //   32: aload_2
    //   33: invokestatic getApplinkLogData : (Landroid/content/Context;Ljava/lang/String;Landroid/os/Bundle;Landroid/content/Intent;)Landroid/os/Bundle;
    //   36: astore #4
    //   38: aload_3
    //   39: ifnull -> 187
    //   42: aload_3
    //   43: invokeinterface keySet : ()Ljava/util/Set;
    //   48: invokeinterface iterator : ()Ljava/util/Iterator;
    //   53: astore_2
    //   54: aload_2
    //   55: invokeinterface hasNext : ()Z
    //   60: ifeq -> 187
    //   63: aload_2
    //   64: invokeinterface next : ()Ljava/lang/Object;
    //   69: checkcast java/lang/String
    //   72: astore #5
    //   74: aload #4
    //   76: aload #5
    //   78: aload_3
    //   79: aload #5
    //   81: invokeinterface get : (Ljava/lang/Object;)Ljava/lang/Object;
    //   86: checkcast java/lang/String
    //   89: invokevirtual putString : (Ljava/lang/String;Ljava/lang/String;)V
    //   92: goto -> 54
    //   95: aload_2
    //   96: invokevirtual getData : ()Landroid/net/Uri;
    //   99: astore #4
    //   101: aload #4
    //   103: ifnull -> 118
    //   106: aload #5
    //   108: ldc 'intentData'
    //   110: aload #4
    //   112: invokevirtual toString : ()Ljava/lang/String;
    //   115: invokevirtual putString : (Ljava/lang/String;Ljava/lang/String;)V
    //   118: aload_2
    //   119: invokevirtual getExtras : ()Landroid/os/Bundle;
    //   122: astore_2
    //   123: aload #5
    //   125: astore #4
    //   127: aload_2
    //   128: ifnull -> 38
    //   131: aload_2
    //   132: invokevirtual keySet : ()Ljava/util/Set;
    //   135: invokeinterface iterator : ()Ljava/util/Iterator;
    //   140: astore #6
    //   142: aload #5
    //   144: astore #4
    //   146: aload #6
    //   148: invokeinterface hasNext : ()Z
    //   153: ifeq -> 38
    //   156: aload #6
    //   158: invokeinterface next : ()Ljava/lang/Object;
    //   163: checkcast java/lang/String
    //   166: astore #4
    //   168: aload #5
    //   170: aload #4
    //   172: aload_2
    //   173: aload #4
    //   175: invokevirtual get : (Ljava/lang/String;)Ljava/lang/Object;
    //   178: invokestatic objectToJSONString : (Ljava/lang/Object;)Ljava/lang/String;
    //   181: invokevirtual putString : (Ljava/lang/String;Ljava/lang/String;)V
    //   184: goto -> 142
    //   187: new bolts/MeasurementEvent
    //   190: dup
    //   191: aload_0
    //   192: aload_1
    //   193: aload #4
    //   195: invokespecial <init> : (Landroid/content/Context;Ljava/lang/String;Landroid/os/Bundle;)V
    //   198: invokespecial sendBroadcast : ()V
    //   201: return
  }
}


/* Location:              C:\soft\dex2jar-2.0\Smash Cricket-dex2jar.jar!\bolts\MeasurementEvent.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */