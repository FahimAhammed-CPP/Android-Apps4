package bolts;

import java.util.ArrayList;
import java.util.Collection;
import java.util.Iterator;
import java.util.List;
import java.util.concurrent.Callable;
import java.util.concurrent.Executor;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.atomic.AtomicBoolean;
import java.util.concurrent.atomic.AtomicInteger;

public class Task<TResult> {
  public static final ExecutorService BACKGROUND_EXECUTOR = BoltsExecutors.background();
  
  private static final Executor IMMEDIATE_EXECUTOR = BoltsExecutors.immediate();
  
  public static final Executor UI_THREAD_EXECUTOR = AndroidExecutors.uiThread();
  
  private boolean cancelled;
  
  private boolean complete;
  
  private List<Continuation<TResult, Void>> continuations = new ArrayList<Continuation<TResult, Void>>();
  
  private Exception error;
  
  private final Object lock = new Object();
  
  private TResult result;
  
  public static <TResult> Task<TResult> call(Callable<TResult> paramCallable) {
    return call(paramCallable, IMMEDIATE_EXECUTOR);
  }
  
  public static <TResult> Task<TResult> call(final Callable<TResult> callable, Executor paramExecutor) {
    final TaskCompletionSource tcs = create();
    paramExecutor.execute(new Runnable() {
          public void run() {
            try {
              tcs.setResult(callable.call());
              return;
            } catch (Exception exception) {
              tcs.setError(exception);
              return;
            } 
          }
        });
    return taskCompletionSource.getTask();
  }
  
  public static <TResult> Task<TResult> callInBackground(Callable<TResult> paramCallable) {
    return call(paramCallable, BACKGROUND_EXECUTOR);
  }
  
  public static <TResult> Task<TResult> cancelled() {
    TaskCompletionSource taskCompletionSource = create();
    taskCompletionSource.setCancelled();
    return taskCompletionSource.getTask();
  }
  
  private static <TContinuationResult, TResult> void completeAfterTask(final TaskCompletionSource tcs, final Continuation<TResult, Task<TContinuationResult>> continuation, final Task<TResult> task, Executor paramExecutor) {
    paramExecutor.execute(new Runnable() {
          public void run() {
            try {
              Task task = (Task)continuation.then(task);
              if (task == null) {
                tcs.setResult(null);
                return;
              } 
              task.continueWith(new Continuation<Void, Void>() {
                    public Void then(Task<TContinuationResult> param2Task) {
                      if (param2Task.isCancelled()) {
                        tcs.setCancelled();
                        return null;
                      } 
                      if (param2Task.isFaulted()) {
                        tcs.setError(param2Task.getError());
                        return null;
                      } 
                      tcs.setResult((TResult)param2Task.getResult());
                      return null;
                    }
                  });
              return;
            } catch (Exception exception) {
              tcs.setError(exception);
              return;
            } 
          }
        });
  }
  
  private static <TContinuationResult, TResult> void completeImmediately(final TaskCompletionSource tcs, final Continuation<TResult, TContinuationResult> continuation, final Task<TResult> task, Executor paramExecutor) {
    paramExecutor.execute(new Runnable() {
          public void run() {
            try {
              Object object = continuation.then(task);
              tcs.setResult((TResult)object);
              return;
            } catch (Exception exception) {
              tcs.setError(exception);
              return;
            } 
          }
        });
  }
  
  public static <TResult> TaskCompletionSource create() {
    Task task = new Task();
    task.getClass();
    return new TaskCompletionSource();
  }
  
  public static <TResult> Task<TResult> forError(Exception paramException) {
    TaskCompletionSource taskCompletionSource = create();
    taskCompletionSource.setError(paramException);
    return taskCompletionSource.getTask();
  }
  
  public static <TResult> Task<TResult> forResult(TResult paramTResult) {
    TaskCompletionSource taskCompletionSource = create();
    taskCompletionSource.setResult(paramTResult);
    return taskCompletionSource.getTask();
  }
  
  private void runContinuations() {
    synchronized (this.lock) {
      Iterator<Continuation<TResult, Void>> iterator = this.continuations.iterator();
      while (iterator.hasNext()) {
        Continuation continuation = iterator.next();
        try {
          continuation.then(this);
        } catch (RuntimeException runtimeException) {
          throw runtimeException;
        } catch (Exception exception) {
          throw new RuntimeException(exception);
        } 
      } 
    } 
    this.continuations = null;
    /* monitor exit ClassFileLocalVariableReferenceExpression{type=ObjectType{java/lang/Object}, name=SYNTHETIC_LOCAL_VARIABLE_1} */
  }
  
  public static Task<Void> whenAll(Collection<? extends Task<?>> paramCollection) {
    if (paramCollection.size() == 0)
      return forResult(null); 
    final TaskCompletionSource allFinished = create();
    final ArrayList errors = new ArrayList();
    final Object errorLock = new Object();
    final AtomicInteger count = new AtomicInteger(paramCollection.size());
    final AtomicBoolean isCancelled = new AtomicBoolean(false);
    Iterator<? extends Task<?>> iterator = paramCollection.iterator();
    while (iterator.hasNext()) {
      ((Task)iterator.next()).continueWith(new Continuation<Object, Void>() {
            public Void then(Task<Object> param1Task) {
              // Byte code:
              //   0: aload_1
              //   1: invokevirtual isFaulted : ()Z
              //   4: ifeq -> 28
              //   7: aload_0
              //   8: getfield val$errorLock : Ljava/lang/Object;
              //   11: astore_2
              //   12: aload_2
              //   13: monitorenter
              //   14: aload_0
              //   15: getfield val$errors : Ljava/util/ArrayList;
              //   18: aload_1
              //   19: invokevirtual getError : ()Ljava/lang/Exception;
              //   22: invokevirtual add : (Ljava/lang/Object;)Z
              //   25: pop
              //   26: aload_2
              //   27: monitorexit
              //   28: aload_1
              //   29: invokevirtual isCancelled : ()Z
              //   32: ifeq -> 43
              //   35: aload_0
              //   36: getfield val$isCancelled : Ljava/util/concurrent/atomic/AtomicBoolean;
              //   39: iconst_1
              //   40: invokevirtual set : (Z)V
              //   43: aload_0
              //   44: getfield val$count : Ljava/util/concurrent/atomic/AtomicInteger;
              //   47: invokevirtual decrementAndGet : ()I
              //   50: ifne -> 92
              //   53: aload_0
              //   54: getfield val$errors : Ljava/util/ArrayList;
              //   57: invokevirtual size : ()I
              //   60: ifeq -> 119
              //   63: aload_0
              //   64: getfield val$errors : Ljava/util/ArrayList;
              //   67: invokevirtual size : ()I
              //   70: iconst_1
              //   71: if_icmpne -> 99
              //   74: aload_0
              //   75: getfield val$allFinished : Lbolts/Task$TaskCompletionSource;
              //   78: aload_0
              //   79: getfield val$errors : Ljava/util/ArrayList;
              //   82: iconst_0
              //   83: invokevirtual get : (I)Ljava/lang/Object;
              //   86: checkcast java/lang/Exception
              //   89: invokevirtual setError : (Ljava/lang/Exception;)V
              //   92: aconst_null
              //   93: areturn
              //   94: astore_1
              //   95: aload_2
              //   96: monitorexit
              //   97: aload_1
              //   98: athrow
              //   99: aload_0
              //   100: getfield val$allFinished : Lbolts/Task$TaskCompletionSource;
              //   103: new bolts/AggregateException
              //   106: dup
              //   107: aload_0
              //   108: getfield val$errors : Ljava/util/ArrayList;
              //   111: invokespecial <init> : (Ljava/util/List;)V
              //   114: invokevirtual setError : (Ljava/lang/Exception;)V
              //   117: aconst_null
              //   118: areturn
              //   119: aload_0
              //   120: getfield val$isCancelled : Ljava/util/concurrent/atomic/AtomicBoolean;
              //   123: invokevirtual get : ()Z
              //   126: ifeq -> 138
              //   129: aload_0
              //   130: getfield val$allFinished : Lbolts/Task$TaskCompletionSource;
              //   133: invokevirtual setCancelled : ()V
              //   136: aconst_null
              //   137: areturn
              //   138: aload_0
              //   139: getfield val$allFinished : Lbolts/Task$TaskCompletionSource;
              //   142: aconst_null
              //   143: invokevirtual setResult : (Ljava/lang/Object;)V
              //   146: aconst_null
              //   147: areturn
              // Exception table:
              //   from	to	target	type
              //   14	28	94	finally
              //   95	97	94	finally
            }
          });
    } 
    return (Task)taskCompletionSource.getTask();
  }
  
  public <TOut> Task<TOut> cast() {
    return this;
  }
  
  public Task<Void> continueWhile(Callable<Boolean> paramCallable, Continuation<Void, Task<Void>> paramContinuation) {
    return continueWhile(paramCallable, paramContinuation, IMMEDIATE_EXECUTOR);
  }
  
  public Task<Void> continueWhile(final Callable<Boolean> predicate, final Continuation<Void, Task<Void>> continuation, final Executor executor) {
    final Capture<Continuation<Void, Task<Void>>> predicateContinuation = new Capture();
    capture.set(new Continuation<Void, Task<Void>>() {
          public Task<Void> then(Task<Void> param1Task) throws Exception {
            return ((Boolean)predicate.call()).booleanValue() ? Task.forResult(null).onSuccessTask(continuation, executor).onSuccessTask(predicateContinuation.get(), executor) : Task.forResult(null);
          }
        });
    return makeVoid().continueWithTask(capture.get(), executor);
  }
  
  public <TContinuationResult> Task<TContinuationResult> continueWith(Continuation<TResult, TContinuationResult> paramContinuation) {
    return continueWith(paramContinuation, IMMEDIATE_EXECUTOR);
  }
  
  public <TContinuationResult> Task<TContinuationResult> continueWith(final Continuation<TResult, TContinuationResult> continuation, final Executor executor) {
    final TaskCompletionSource tcs = create();
    synchronized (this.lock) {
      boolean bool = isCompleted();
      if (!bool)
        this.continuations.add(new Continuation<TResult, Void>() {
              public Void then(Task<TResult> param1Task) {
                Task.completeImmediately(tcs, continuation, param1Task, executor);
                return null;
              }
            }); 
      if (bool)
        completeImmediately(taskCompletionSource, continuation, this, executor); 
      return taskCompletionSource.getTask();
    } 
  }
  
  public <TContinuationResult> Task<TContinuationResult> continueWithTask(Continuation<TResult, Task<TContinuationResult>> paramContinuation) {
    return continueWithTask(paramContinuation, IMMEDIATE_EXECUTOR);
  }
  
  public <TContinuationResult> Task<TContinuationResult> continueWithTask(final Continuation<TResult, Task<TContinuationResult>> continuation, final Executor executor) {
    final TaskCompletionSource tcs = create();
    synchronized (this.lock) {
      boolean bool = isCompleted();
      if (!bool)
        this.continuations.add(new Continuation<TResult, Void>() {
              public Void then(Task<TResult> param1Task) {
                Task.completeAfterTask(tcs, continuation, param1Task, executor);
                return null;
              }
            }); 
      if (bool)
        completeAfterTask(taskCompletionSource, continuation, this, executor); 
      return taskCompletionSource.getTask();
    } 
  }
  
  public Exception getError() {
    synchronized (this.lock) {
      return this.error;
    } 
  }
  
  public TResult getResult() {
    synchronized (this.lock) {
      return this.result;
    } 
  }
  
  public boolean isCancelled() {
    synchronized (this.lock) {
      return this.cancelled;
    } 
  }
  
  public boolean isCompleted() {
    synchronized (this.lock) {
      return this.complete;
    } 
  }
  
  public boolean isFaulted() {
    synchronized (this.lock) {
      if (this.error != null)
        return true; 
    } 
    boolean bool = false;
    /* monitor exit ClassFileLocalVariableReferenceExpression{type=ObjectType{java/lang/Object}, name=SYNTHETIC_LOCAL_VARIABLE_2} */
    return bool;
  }
  
  public Task<Void> makeVoid() {
    return continueWithTask(new Continuation<TResult, Task<Void>>() {
          public Task<Void> then(Task<TResult> param1Task) throws Exception {
            return param1Task.isCancelled() ? Task.cancelled() : (param1Task.isFaulted() ? Task.forError(param1Task.getError()) : Task.forResult(null));
          }
        });
  }
  
  public <TContinuationResult> Task<TContinuationResult> onSuccess(Continuation<TResult, TContinuationResult> paramContinuation) {
    return onSuccess(paramContinuation, IMMEDIATE_EXECUTOR);
  }
  
  public <TContinuationResult> Task<TContinuationResult> onSuccess(final Continuation<TResult, TContinuationResult> continuation, Executor paramExecutor) {
    return continueWithTask((Continuation)new Continuation<TResult, Task<Task<TContinuationResult>>>() {
          public Task<TContinuationResult> then(Task<TResult> param1Task) {
            return param1Task.isFaulted() ? Task.forError(param1Task.getError()) : (param1Task.isCancelled() ? Task.cancelled() : param1Task.continueWith(continuation));
          }
        },  paramExecutor);
  }
  
  public <TContinuationResult> Task<TContinuationResult> onSuccessTask(Continuation<TResult, Task<TContinuationResult>> paramContinuation) {
    return onSuccessTask(paramContinuation, IMMEDIATE_EXECUTOR);
  }
  
  public <TContinuationResult> Task<TContinuationResult> onSuccessTask(final Continuation<TResult, Task<TContinuationResult>> continuation, Executor paramExecutor) {
    return continueWithTask((Continuation)new Continuation<TResult, Task<Task<TContinuationResult>>>() {
          public Task<TContinuationResult> then(Task<TResult> param1Task) {
            return param1Task.isFaulted() ? Task.forError(param1Task.getError()) : (param1Task.isCancelled() ? Task.cancelled() : param1Task.continueWithTask(continuation));
          }
        },  paramExecutor);
  }
  
  public void waitForCompletion() throws InterruptedException {
    synchronized (this.lock) {
      if (!isCompleted())
        this.lock.wait(); 
      return;
    } 
  }
  
  public class TaskCompletionSource {
    private TaskCompletionSource() {}
    
    public Task<TResult> getTask() {
      return Task.this;
    }
    
    public void setCancelled() {
      if (!trySetCancelled())
        throw new IllegalStateException("Cannot cancel a completed task."); 
    }
    
    public void setError(Exception param1Exception) {
      if (!trySetError(param1Exception))
        throw new IllegalStateException("Cannot set the error on a completed task."); 
    }
    
    public void setResult(TResult param1TResult) {
      if (!trySetResult(param1TResult))
        throw new IllegalStateException("Cannot set the result of a completed task."); 
    }
    
    public boolean trySetCancelled() {
      synchronized (Task.this.lock) {
        if (Task.this.complete)
          return false; 
        Task.access$402(Task.this, true);
        Task.access$502(Task.this, true);
        Task.this.lock.notifyAll();
        Task.this.runContinuations();
        return true;
      } 
    }
    
    public boolean trySetError(Exception param1Exception) {
      synchronized (Task.this.lock) {
        if (Task.this.complete)
          return false; 
        Task.access$402(Task.this, true);
        Task.access$802(Task.this, param1Exception);
        Task.this.lock.notifyAll();
        Task.this.runContinuations();
        return true;
      } 
    }
    
    public boolean trySetResult(TResult param1TResult) {
      synchronized (Task.this.lock) {
        if (Task.this.complete)
          return false; 
        Task.access$402(Task.this, true);
        Task.access$702(Task.this, param1TResult);
        Task.this.lock.notifyAll();
        Task.this.runContinuations();
        return true;
      } 
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Smash Cricket-dex2jar.jar!\bolts\Task.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */