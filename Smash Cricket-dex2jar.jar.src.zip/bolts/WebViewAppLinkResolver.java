package bolts;

import android.content.Context;
import android.net.Uri;
import android.webkit.JavascriptInterface;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.net.URLConnection;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.concurrent.Callable;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

public class WebViewAppLinkResolver implements AppLinkResolver {
  private static final String KEY_AL_VALUE = "value";
  
  private static final String KEY_ANDROID = "android";
  
  private static final String KEY_APP_NAME = "app_name";
  
  private static final String KEY_CLASS = "class";
  
  private static final String KEY_PACKAGE = "package";
  
  private static final String KEY_SHOULD_FALLBACK = "should_fallback";
  
  private static final String KEY_URL = "url";
  
  private static final String KEY_WEB = "web";
  
  private static final String KEY_WEB_URL = "url";
  
  private static final String META_TAG_PREFIX = "al";
  
  private static final String PREFER_HEADER = "Prefer-Html-Meta-Tags";
  
  private static final String TAG_EXTRACTION_JAVASCRIPT = "javascript:boltsWebViewAppLinkResolverResult.setValue((function() {  var metaTags = document.getElementsByTagName('meta');  var results = [];  for (var i = 0; i < metaTags.length; i++) {    var property = metaTags[i].getAttribute('property');    if (property && property.substring(0, 'al:'.length) === 'al:') {      var tag = { \"property\": metaTags[i].getAttribute('property') };      if (metaTags[i].hasAttribute('content')) {        tag['content'] = metaTags[i].getAttribute('content');      }      results.push(tag);    }  }  return JSON.stringify(results);})())";
  
  private final Context context;
  
  public WebViewAppLinkResolver(Context paramContext) {
    this.context = paramContext;
  }
  
  private static List<Map<String, Object>> getAlList(Map<String, Object> paramMap, String paramString) {
    List<?> list2 = (List)paramMap.get(paramString);
    List<?> list1 = list2;
    if (list2 == null)
      list1 = Collections.emptyList(); 
    return (List)list1;
  }
  
  private static AppLink makeAppLinkFromAlData(Map<String, Object> paramMap, Uri paramUri) {
    ArrayList<AppLink.Target> arrayList = new ArrayList();
    List<?> list2 = (List)paramMap.get("android");
    List<?> list1 = list2;
    if (list2 == null)
      list1 = Collections.emptyList(); 
    for (Map<String, Object> map : list1) {
      List<Map<String, Object>> list3 = getAlList(map, "url");
      List<Map<String, Object>> list4 = getAlList(map, "package");
      List<Map<String, Object>> list5 = getAlList(map, "class");
      List<Map<String, Object>> list6 = getAlList(map, "app_name");
      int j = Math.max(list3.size(), Math.max(list4.size(), Math.max(list5.size(), list6.size())));
      for (int i = 0; i < j; i++) {
        if (list3.size() > i) {
          map = (Map<String, Object>)((Map)list3.get(i)).get("value");
        } else {
          map = null;
        } 
        Uri uri = tryCreateUrl((String)map);
        if (list4.size() > i) {
          map = (Map<String, Object>)((Map)list4.get(i)).get("value");
        } else {
          map = null;
        } 
        String str1 = (String)map;
        if (list5.size() > i) {
          map = (Map<String, Object>)((Map)list5.get(i)).get("value");
        } else {
          map = null;
        } 
        String str2 = (String)map;
        if (list6.size() > i) {
          map = (Map<String, Object>)((Map)list6.get(i)).get("value");
        } else {
          map = null;
        } 
        arrayList.add(new AppLink.Target(str1, str2, uri, (String)map));
      } 
    } 
    Uri uri1 = paramUri;
    List<Map> list = (List)paramMap.get("web");
    Uri uri2 = uri1;
    if (list != null) {
      uri2 = uri1;
      if (list.size() > 0) {
        Map map = list.get(0);
        List<Map> list4 = (List)map.get("url");
        List<Map> list3 = (List)map.get("should_fallback");
        Uri uri = uri1;
        if (list3 != null) {
          uri = uri1;
          String str = (String)((Map)list3.get(0)).get("value");
          uri = uri1;
          if (list3.size() > 0 && Arrays.<String>asList(new String[] { "no", "false", "0" }).contains(str.toLowerCase()))
            uri = null; 
        } 
        uri2 = uri;
        if (uri != null) {
          uri2 = uri;
          if (list4 != null) {
            uri2 = uri;
            if (list4.size() > 0)
              uri2 = tryCreateUrl((String)((Map)list4.get(0)).get("value")); 
          } 
        } 
      } 
    } 
    return new AppLink(paramUri, arrayList, uri2);
  }
  
  private static Map<String, Object> parseAlData(JSONArray paramJSONArray) throws JSONException {
    HashMap<Object, Object> hashMap = new HashMap<Object, Object>();
    for (int i = 0; i < paramJSONArray.length(); i++) {
      JSONObject jSONObject = paramJSONArray.getJSONObject(i);
      String[] arrayOfString = jSONObject.getString("property").split(":");
      if (arrayOfString[0].equals("al")) {
        HashMap<Object, Object> hashMap1 = hashMap;
        for (int j = 1; j < arrayOfString.length; j++) {
          List<Map> list2 = (List)hashMap1.get(arrayOfString[j]);
          List<Map> list1 = list2;
          if (list2 == null) {
            list1 = new ArrayList();
            hashMap1.put(arrayOfString[j], list1);
          } 
          if (list1.size() > 0) {
            Map map = list1.get(list1.size() - 1);
          } else {
            hashMap1 = null;
          } 
          if (hashMap1 == null || j == arrayOfString.length - 1) {
            hashMap1 = new HashMap<Object, Object>();
            list1.add(hashMap1);
          } 
        } 
        if (jSONObject.has("content"))
          if (jSONObject.isNull("content")) {
            hashMap1.put("value", null);
          } else {
            hashMap1.put("value", jSONObject.getString("content"));
          }  
      } 
    } 
    return (Map)hashMap;
  }
  
  private static String readFromConnection(URLConnection paramURLConnection) throws IOException {
    InputStream inputStream;
    if (paramURLConnection instanceof HttpURLConnection) {
      HttpURLConnection httpURLConnection = (HttpURLConnection)paramURLConnection;
      try {
        inputStream = paramURLConnection.getInputStream();
      } catch (Exception exception) {
        inputStream = httpURLConnection.getErrorStream();
      } 
    } else {
      inputStream = paramURLConnection.getInputStream();
    } 
    try {
      ByteArrayOutputStream byteArrayOutputStream = new ByteArrayOutputStream();
      byte[] arrayOfByte = new byte[1024];
      while (true) {
        String[] arrayOfString;
        int i = inputStream.read(arrayOfByte);
        if (i != -1) {
          byteArrayOutputStream.write(arrayOfByte, 0, i);
          continue;
        } 
        String str4 = paramURLConnection.getContentEncoding();
        String str3 = str4;
        if (str4 == null) {
          arrayOfString = paramURLConnection.getContentType().split(";");
          int j = arrayOfString.length;
          i = 0;
          while (true) {
            str1 = str4;
            if (i < j) {
              str1 = arrayOfString[i].trim();
              if (str1.startsWith("charset=")) {
                str1 = str1.substring("charset=".length());
                break;
              } 
              i++;
              continue;
            } 
            break;
          } 
        } else {
          str1 = new String(byteArrayOutputStream.toByteArray(), (String)arrayOfString);
          return str1;
        } 
        String str2 = str1;
        if (str1 == null)
          str2 = "UTF-8"; 
        String str1 = new String(byteArrayOutputStream.toByteArray(), str2);
        return str1;
      } 
    } finally {
      inputStream.close();
    } 
  }
  
  private static Uri tryCreateUrl(String paramString) {
    return (paramString == null) ? null : Uri.parse(paramString);
  }
  
  public Task<AppLink> getAppLinkFromUrlInBackground(final Uri url) {
    final Capture content = new Capture();
    final Capture contentType = new Capture();
    return Task.callInBackground(new Callable<Void>() {
          public Void call() throws Exception {
            null = new URL(url.toString());
            URLConnection uRLConnection = null;
            while (null != null) {
              uRLConnection = null.openConnection();
              if (uRLConnection instanceof HttpURLConnection)
                ((HttpURLConnection)uRLConnection).setInstanceFollowRedirects(true); 
              uRLConnection.setRequestProperty("Prefer-Html-Meta-Tags", "al");
              uRLConnection.connect();
              if (uRLConnection instanceof HttpURLConnection) {
                HttpURLConnection httpURLConnection = (HttpURLConnection)uRLConnection;
                if (httpURLConnection.getResponseCode() >= 300 && httpURLConnection.getResponseCode() < 400) {
                  null = new URL(httpURLConnection.getHeaderField("Location"));
                  httpURLConnection.disconnect();
                  continue;
                } 
                null = null;
                continue;
              } 
              null = null;
            } 
            try {
              content.set(WebViewAppLinkResolver.readFromConnection(uRLConnection));
              contentType.set(uRLConnection.getContentType());
              return null;
            } finally {
              if (uRLConnection instanceof HttpURLConnection)
                ((HttpURLConnection)uRLConnection).disconnect(); 
            } 
          }
        }).onSuccessTask(new Continuation<Void, Task<JSONArray>>() {
          public Task<JSONArray> then(Task<Void> param1Task) throws Exception {
            String str;
            final Task<TResult>.TaskCompletionSource tcs = Task.create();
            WebView webView = new WebView(WebViewAppLinkResolver.this.context);
            webView.getSettings().setJavaScriptEnabled(true);
            webView.setNetworkAvailable(false);
            webView.setWebViewClient(new WebViewClient() {
                  private boolean loaded = false;
                  
                  private void runJavaScript(WebView param2WebView) {
                    if (!this.loaded) {
                      this.loaded = true;
                      param2WebView.loadUrl("javascript:boltsWebViewAppLinkResolverResult.setValue((function() {  var metaTags = document.getElementsByTagName('meta');  var results = [];  for (var i = 0; i < metaTags.length; i++) {    var property = metaTags[i].getAttribute('property');    if (property && property.substring(0, 'al:'.length) === 'al:') {      var tag = { \"property\": metaTags[i].getAttribute('property') };      if (metaTags[i].hasAttribute('content')) {        tag['content'] = metaTags[i].getAttribute('content');      }      results.push(tag);    }  }  return JSON.stringify(results);})())");
                    } 
                  }
                  
                  public void onLoadResource(WebView param2WebView, String param2String) {
                    super.onLoadResource(param2WebView, param2String);
                    runJavaScript(param2WebView);
                  }
                  
                  public void onPageFinished(WebView param2WebView, String param2String) {
                    super.onPageFinished(param2WebView, param2String);
                    runJavaScript(param2WebView);
                  }
                });
            webView.addJavascriptInterface(new Object() {
                  @JavascriptInterface
                  public void setValue(String param2String) {
                    try {
                      tcs.trySetResult((TResult)new JSONArray(param2String));
                      return;
                    } catch (JSONException jSONException) {
                      tcs.trySetError((Exception)jSONException);
                      return;
                    } 
                  }
                },  "boltsWebViewAppLinkResolverResult");
            param1Task = null;
            if (contentType.get() != null)
              str = ((String)contentType.get()).split(";")[0]; 
            webView.loadDataWithBaseURL(url.toString(), content.get(), str, null, null);
            return (Task)taskCompletionSource.getTask();
          }
        }Task.UI_THREAD_EXECUTOR).onSuccess(new Continuation<JSONArray, AppLink>() {
          public AppLink then(Task<JSONArray> param1Task) throws Exception {
            return WebViewAppLinkResolver.makeAppLinkFromAlData(WebViewAppLinkResolver.parseAlData(param1Task.getResult()), url);
          }
        });
  }
}


/* Location:              C:\soft\dex2jar-2.0\Smash Cricket-dex2jar.jar!\bolts\WebViewAppLinkResolver.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */