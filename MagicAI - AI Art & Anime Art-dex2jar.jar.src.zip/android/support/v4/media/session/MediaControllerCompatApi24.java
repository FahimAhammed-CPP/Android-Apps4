package android.support.v4.media.session;

import android.media.session.MediaController;
import android.net.Uri;
import android.os.Bundle;
import androidx.annotation.RequiresApi;

@RequiresApi(24)
class MediaControllerCompatApi24 {
  public static class TransportControls {
    public static void prepare(Object param1Object) {
      MediaControllerCompatApi24$TransportControls$.ExternalSyntheticApiModelOutline1.m((MediaController.TransportControls)param1Object);
    }
    
    public static void prepareFromMediaId(Object param1Object, String param1String, Bundle param1Bundle) {
      MediaControllerCompatApi24$TransportControls$.ExternalSyntheticApiModelOutline2.m((MediaController.TransportControls)param1Object, param1String, param1Bundle);
    }
    
    public static void prepareFromSearch(Object param1Object, String param1String, Bundle param1Bundle) {
      MediaControllerCompatApi24$TransportControls$.ExternalSyntheticApiModelOutline0.m((MediaController.TransportControls)param1Object, param1String, param1Bundle);
    }
    
    public static void prepareFromUri(Object param1Object, Uri param1Uri, Bundle param1Bundle) {
      MediaControllerCompatApi24$TransportControls$.ExternalSyntheticApiModelOutline3.m((MediaController.TransportControls)param1Object, param1Uri, param1Bundle);
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\MagicAI - AI Art & Anime Art-dex2jar.jar!\android\support\v4\media\session\MediaControllerCompatApi24.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */