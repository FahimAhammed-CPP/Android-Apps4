package ch.qos.logback.core.pattern.util;

public interface IEscapeUtil {
  void escape(String paramString, StringBuffer paramStringBuffer, char paramChar, int paramInt);
}


/* Location:              C:\soft\dex2jar-2.0\MagicAI - AI Art & Anime Art-dex2jar.jar!\ch\qos\logback\core\patter\\util\IEscapeUtil.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */