package ch.qos.logback.core.pattern.color;

public class BoldYellowCompositeConverter<E> extends ForegroundCompositeConverterBase<E> {
  protected String getForegroundColorCode(E paramE) {
    return "1;33";
  }
}


/* Location:              C:\soft\dex2jar-2.0\MagicAI - AI Art & Anime Art-dex2jar.jar!\ch\qos\logback\core\pattern\color\BoldYellowCompositeConverter.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */