package ch.qos.logback.core.pattern;

public abstract class CompositeConverter<E> extends DynamicConverter<E> {
  Converter<E> childConverter;
  
  public String convert(E paramE) {
    StringBuilder stringBuilder = new StringBuilder();
    for (Converter<E> converter = this.childConverter; converter != null; converter = converter.next)
      converter.write(stringBuilder, paramE); 
    return transform(paramE, stringBuilder.toString());
  }
  
  public Converter<E> getChildConverter() {
    return this.childConverter;
  }
  
  public void setChildConverter(Converter<E> paramConverter) {
    this.childConverter = paramConverter;
  }
  
  public String toString() {
    StringBuilder stringBuilder = new StringBuilder();
    stringBuilder.append("CompositeConverter<");
    FormatInfo formatInfo = ((FormattingConverter)this).formattingInfo;
    if (formatInfo != null)
      stringBuilder.append(formatInfo); 
    if (this.childConverter != null) {
      stringBuilder.append(", children: ");
      stringBuilder.append(this.childConverter);
    } 
    stringBuilder.append(">");
    return stringBuilder.toString();
  }
  
  protected abstract String transform(E paramE, String paramString);
}


/* Location:              C:\soft\dex2jar-2.0\MagicAI - AI Art & Anime Art-dex2jar.jar!\ch\qos\logback\core\pattern\CompositeConverter.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */