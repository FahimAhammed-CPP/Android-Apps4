package ch.qos.logback.core.util;

import ch.qos.logback.core.Context;
import ch.qos.logback.core.spi.ContextAware;
import ch.qos.logback.core.spi.PropertyContainer;
import ch.qos.logback.core.spi.ScanException;
import ch.qos.logback.core.subst.NodeToStringTransformer;
import java.util.Properties;

public class OptionHelper {
  public static String[] extractDefaultReplacement(String paramString) {
    String[] arrayOfString = new String[2];
    if (paramString == null)
      return arrayOfString; 
    arrayOfString[0] = paramString;
    int i = paramString.indexOf(":-");
    if (i != -1) {
      arrayOfString[0] = paramString.substring(0, i);
      arrayOfString[1] = paramString.substring(i + 2);
    } 
    return arrayOfString;
  }
  
  public static String getEnv(String paramString) {
    try {
      return System.getenv(paramString);
    } catch (SecurityException securityException) {
      return null;
    } 
  }
  
  public static String getSystemProperty(String paramString) {
    try {
      return System.getProperty(paramString);
    } catch (SecurityException securityException) {
      return null;
    } 
  }
  
  public static String getSystemProperty(String paramString1, String paramString2) {
    try {
      return System.getProperty(paramString1, paramString2);
    } catch (SecurityException securityException) {
      return paramString2;
    } 
  }
  
  public static Object instantiateByClassName(String paramString, Class<?> paramClass, Context paramContext) throws IncompatibleClassException, DynamicClassLoadingException {
    return instantiateByClassName(paramString, paramClass, Loader.getClassLoaderOfObject(paramContext));
  }
  
  public static Object instantiateByClassName(String paramString, Class<?> paramClass, ClassLoader paramClassLoader) throws IncompatibleClassException, DynamicClassLoadingException {
    return instantiateByClassNameAndParameter(paramString, paramClass, paramClassLoader, null, null);
  }
  
  public static Object instantiateByClassNameAndParameter(String paramString, Class<?> paramClass1, ClassLoader paramClassLoader, Class<?> paramClass2, Object paramObject) throws IncompatibleClassException, DynamicClassLoadingException {
    paramString.getClass();
    try {
      Class<?> clazz = paramClassLoader.loadClass(paramString);
      if (paramClass1.isAssignableFrom(clazz))
        return (paramClass2 == null) ? clazz.getConstructor(new Class[0]).newInstance(new Object[0]) : clazz.getConstructor(new Class[] { paramClass2 }).newInstance(new Object[] { paramObject }); 
      throw new IncompatibleClassException(paramClass1, clazz);
    } catch (IncompatibleClassException incompatibleClassException) {
      throw incompatibleClassException;
    } finally {
      paramClass1 = null;
      StringBuilder stringBuilder = new StringBuilder();
      stringBuilder.append("Failed to instantiate type ");
      stringBuilder.append((String)incompatibleClassException);
    } 
  }
  
  public static final boolean isNotEmtpy(Object[] paramArrayOfObject) {
    return isNullOrEmpty(paramArrayOfObject) ^ true;
  }
  
  public static boolean isNullOrEmpty(String paramString) {
    return (paramString == null || paramString.trim().length() == 0);
  }
  
  public static final boolean isNullOrEmpty(Object[] paramArrayOfObject) {
    return (paramArrayOfObject == null || paramArrayOfObject.length == 0);
  }
  
  public static void setSystemProperties(ContextAware paramContextAware, Properties paramProperties) {
    for (String str : paramProperties.keySet())
      setSystemProperty(paramContextAware, str, paramProperties.getProperty(str)); 
  }
  
  public static void setSystemProperty(ContextAware paramContextAware, String paramString1, String paramString2) {
    try {
      System.setProperty(paramString1, paramString2);
      return;
    } catch (SecurityException securityException) {
      StringBuilder stringBuilder = new StringBuilder();
      stringBuilder.append("Failed to set system property [");
      stringBuilder.append(paramString1);
      stringBuilder.append("]");
      paramContextAware.addError(stringBuilder.toString(), securityException);
      return;
    } 
  }
  
  public static String substVars(String paramString, PropertyContainer paramPropertyContainer1, PropertyContainer paramPropertyContainer2) throws ScanException {
    return NodeToStringTransformer.substituteVariable(paramString, paramPropertyContainer1, paramPropertyContainer2);
  }
  
  public static boolean toBoolean(String paramString, boolean paramBoolean) {
    if (paramString == null)
      return paramBoolean; 
    paramString = paramString.trim();
    return "true".equalsIgnoreCase(paramString) ? true : ("false".equalsIgnoreCase(paramString) ? false : paramBoolean);
  }
}


/* Location:              C:\soft\dex2jar-2.0\MagicAI - AI Art & Anime Art-dex2jar.jar!\ch\qos\logback\cor\\util\OptionHelper.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */