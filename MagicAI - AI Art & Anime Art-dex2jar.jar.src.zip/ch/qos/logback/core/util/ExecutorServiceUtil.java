package ch.qos.logback.core.util;

import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.ScheduledExecutorService;
import java.util.concurrent.ScheduledThreadPoolExecutor;
import java.util.concurrent.SynchronousQueue;
import java.util.concurrent.ThreadFactory;
import java.util.concurrent.ThreadPoolExecutor;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.atomic.AtomicInteger;

public class ExecutorServiceUtil {
  private static final ThreadFactory THREAD_FACTORY = new ThreadFactory() {
      private final ThreadFactory defaultFactory = Executors.defaultThreadFactory();
      
      private final AtomicInteger threadNumber = new AtomicInteger(1);
      
      public Thread newThread(Runnable param1Runnable) {
        param1Runnable = this.defaultFactory.newThread(param1Runnable);
        if (!param1Runnable.isDaemon())
          param1Runnable.setDaemon(true); 
        int i = this.threadNumber.getAndIncrement();
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("logback-");
        stringBuilder.append(i);
        param1Runnable.setName(stringBuilder.toString());
        return (Thread)param1Runnable;
      }
    };
  
  public static ScheduledExecutorService newScheduledExecutorService() {
    return new ScheduledThreadPoolExecutor(2, THREAD_FACTORY);
  }
  
  public static ThreadPoolExecutor newThreadPoolExecutor() {
    return new ThreadPoolExecutor(0, 32, 0L, TimeUnit.MILLISECONDS, new SynchronousQueue<Runnable>(), THREAD_FACTORY);
  }
  
  public static void shutdown(ExecutorService paramExecutorService) {
    if (paramExecutorService != null)
      paramExecutorService.shutdownNow(); 
  }
}


/* Location:              C:\soft\dex2jar-2.0\MagicAI - AI Art & Anime Art-dex2jar.jar!\ch\qos\logback\cor\\util\ExecutorServiceUtil.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */