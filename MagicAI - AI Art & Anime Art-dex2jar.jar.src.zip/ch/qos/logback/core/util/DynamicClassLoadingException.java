package ch.qos.logback.core.util;

public class DynamicClassLoadingException extends Exception {
  private static final long serialVersionUID = 4962278449162476114L;
  
  public DynamicClassLoadingException(String paramString, Throwable paramThrowable) {
    super(paramString, paramThrowable);
  }
}


/* Location:              C:\soft\dex2jar-2.0\MagicAI - AI Art & Anime Art-dex2jar.jar!\ch\qos\logback\cor\\util\DynamicClassLoadingException.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */