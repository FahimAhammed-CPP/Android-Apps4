package ch.qos.logback.core;

import ch.qos.logback.core.spi.ContextAwareBase;
import ch.qos.logback.core.spi.FilterAttachableImpl;
import ch.qos.logback.core.spi.FilterReply;

public abstract class AppenderBase<E> extends ContextAwareBase implements Appender<E> {
  private int exceptionCount = 0;
  
  private FilterAttachableImpl<E> fai = new FilterAttachableImpl();
  
  private boolean guard = false;
  
  protected String name;
  
  protected volatile boolean started = false;
  
  private int statusRepeatCount = 0;
  
  protected abstract void append(E paramE);
  
  public void doAppend(E paramE) {
    // Byte code:
    //   0: aload_0
    //   1: monitorenter
    //   2: aload_0
    //   3: getfield guard : Z
    //   6: istore_3
    //   7: iload_3
    //   8: ifeq -> 14
    //   11: aload_0
    //   12: monitorexit
    //   13: return
    //   14: aload_0
    //   15: iconst_1
    //   16: putfield guard : Z
    //   19: aload_0
    //   20: getfield started : Z
    //   23: ifne -> 105
    //   26: aload_0
    //   27: getfield statusRepeatCount : I
    //   30: istore_2
    //   31: aload_0
    //   32: iload_2
    //   33: iconst_1
    //   34: iadd
    //   35: putfield statusRepeatCount : I
    //   38: iload_2
    //   39: iconst_5
    //   40: if_icmpge -> 97
    //   43: aload_0
    //   44: getfield name : Ljava/lang/String;
    //   47: astore_1
    //   48: new java/lang/StringBuilder
    //   51: dup
    //   52: invokespecial <init> : ()V
    //   55: astore #4
    //   57: aload #4
    //   59: ldc 'Attempted to append to non started appender ['
    //   61: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   64: pop
    //   65: aload #4
    //   67: aload_1
    //   68: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   71: pop
    //   72: aload #4
    //   74: ldc '].'
    //   76: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   79: pop
    //   80: aload_0
    //   81: new ch/qos/logback/core/status/WarnStatus
    //   84: dup
    //   85: aload #4
    //   87: invokevirtual toString : ()Ljava/lang/String;
    //   90: aload_0
    //   91: invokespecial <init> : (Ljava/lang/String;Ljava/lang/Object;)V
    //   94: invokevirtual addStatus : (Lch/qos/logback/core/status/Status;)V
    //   97: aload_0
    //   98: iconst_0
    //   99: putfield guard : Z
    //   102: aload_0
    //   103: monitorexit
    //   104: return
    //   105: aload_0
    //   106: aload_1
    //   107: invokevirtual getFilterChainDecision : (Ljava/lang/Object;)Lch/qos/logback/core/spi/FilterReply;
    //   110: astore #4
    //   112: getstatic ch/qos/logback/core/spi/FilterReply.DENY : Lch/qos/logback/core/spi/FilterReply;
    //   115: astore #5
    //   117: aload #4
    //   119: aload #5
    //   121: if_acmpne -> 132
    //   124: aload_0
    //   125: iconst_0
    //   126: putfield guard : Z
    //   129: aload_0
    //   130: monitorexit
    //   131: return
    //   132: aload_0
    //   133: aload_1
    //   134: invokevirtual append : (Ljava/lang/Object;)V
    //   137: aload_0
    //   138: iconst_0
    //   139: putfield guard : Z
    //   142: goto -> 219
    //   145: astore_1
    //   146: goto -> 222
    //   149: astore_1
    //   150: aload_0
    //   151: getfield exceptionCount : I
    //   154: istore_2
    //   155: aload_0
    //   156: iload_2
    //   157: iconst_1
    //   158: iadd
    //   159: putfield exceptionCount : I
    //   162: iload_2
    //   163: iconst_5
    //   164: if_icmpge -> 137
    //   167: aload_0
    //   168: getfield name : Ljava/lang/String;
    //   171: astore #4
    //   173: new java/lang/StringBuilder
    //   176: dup
    //   177: invokespecial <init> : ()V
    //   180: astore #5
    //   182: aload #5
    //   184: ldc 'Appender ['
    //   186: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   189: pop
    //   190: aload #5
    //   192: aload #4
    //   194: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   197: pop
    //   198: aload #5
    //   200: ldc '] failed to append.'
    //   202: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   205: pop
    //   206: aload_0
    //   207: aload #5
    //   209: invokevirtual toString : ()Ljava/lang/String;
    //   212: aload_1
    //   213: invokevirtual addError : (Ljava/lang/String;Ljava/lang/Throwable;)V
    //   216: goto -> 137
    //   219: aload_0
    //   220: monitorexit
    //   221: return
    //   222: aload_0
    //   223: iconst_0
    //   224: putfield guard : Z
    //   227: aload_1
    //   228: athrow
    //   229: astore_1
    //   230: aload_0
    //   231: monitorexit
    //   232: aload_1
    //   233: athrow
    // Exception table:
    //   from	to	target	type
    //   2	7	229	finally
    //   14	38	149	java/lang/Exception
    //   14	38	145	finally
    //   43	97	149	java/lang/Exception
    //   43	97	145	finally
    //   97	102	229	finally
    //   105	117	149	java/lang/Exception
    //   105	117	145	finally
    //   124	129	229	finally
    //   132	137	149	java/lang/Exception
    //   132	137	145	finally
    //   137	142	229	finally
    //   150	162	145	finally
    //   167	216	145	finally
    //   222	229	229	finally
  }
  
  public FilterReply getFilterChainDecision(E paramE) {
    return this.fai.getFilterChainDecision(paramE);
  }
  
  public String getName() {
    return this.name;
  }
  
  public boolean isStarted() {
    return this.started;
  }
  
  public void setName(String paramString) {
    this.name = paramString;
  }
  
  public void start() {
    this.started = true;
  }
  
  public void stop() {
    this.started = false;
  }
  
  public String toString() {
    String str1 = getClass().getName();
    String str2 = this.name;
    StringBuilder stringBuilder = new StringBuilder();
    stringBuilder.append(str1);
    stringBuilder.append("[");
    stringBuilder.append(str2);
    stringBuilder.append("]");
    return stringBuilder.toString();
  }
}


/* Location:              C:\soft\dex2jar-2.0\MagicAI - AI Art & Anime Art-dex2jar.jar!\ch\qos\logback\core\AppenderBase.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */