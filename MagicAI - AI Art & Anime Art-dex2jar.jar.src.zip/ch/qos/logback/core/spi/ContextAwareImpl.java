package ch.qos.logback.core.spi;

import ch.qos.logback.core.Context;
import ch.qos.logback.core.status.ErrorStatus;
import ch.qos.logback.core.status.Status;
import ch.qos.logback.core.status.StatusManager;
import ch.qos.logback.core.status.WarnStatus;
import java.io.PrintStream;

public class ContextAwareImpl implements ContextAware {
  protected Context context;
  
  private int noContextWarning = 0;
  
  final Object origin;
  
  public ContextAwareImpl(Context paramContext, Object paramObject) {
    this.context = paramContext;
    this.origin = paramObject;
  }
  
  public void addError(String paramString) {
    addStatus((Status)new ErrorStatus(paramString, getOrigin()));
  }
  
  public void addError(String paramString, Throwable paramThrowable) {
    addStatus((Status)new ErrorStatus(paramString, getOrigin(), paramThrowable));
  }
  
  public void addStatus(Status paramStatus) {
    PrintStream printStream;
    String str;
    Context context = this.context;
    if (context == null) {
      int i = this.noContextWarning;
      this.noContextWarning = i + 1;
      if (i == 0) {
        printStream = System.out;
        str = String.valueOf(this);
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("LOGBACK: No context given for ");
        stringBuilder.append(str);
        printStream.println(stringBuilder.toString());
      } 
      return;
    } 
    StatusManager statusManager = str.getStatusManager();
    if (statusManager != null)
      statusManager.add((Status)printStream); 
  }
  
  public void addWarn(String paramString, Throwable paramThrowable) {
    addStatus((Status)new WarnStatus(paramString, getOrigin(), paramThrowable));
  }
  
  public Context getContext() {
    return this.context;
  }
  
  protected Object getOrigin() {
    return this.origin;
  }
  
  public void setContext(Context paramContext) {
    Context context = this.context;
    if (context == null) {
      this.context = paramContext;
      return;
    } 
    if (context == paramContext)
      return; 
    throw new IllegalStateException("Context has been already set");
  }
}


/* Location:              C:\soft\dex2jar-2.0\MagicAI - AI Art & Anime Art-dex2jar.jar!\ch\qos\logback\core\spi\ContextAwareImpl.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */