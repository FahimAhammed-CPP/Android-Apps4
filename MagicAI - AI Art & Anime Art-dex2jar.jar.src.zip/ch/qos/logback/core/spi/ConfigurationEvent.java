package ch.qos.logback.core.spi;

public class ConfigurationEvent {
  final Object data;
  
  final EventType eventType;
  
  private ConfigurationEvent(EventType paramEventType, Object paramObject) {
    this.eventType = paramEventType;
    this.data = paramObject;
  }
  
  public static ConfigurationEvent newConfigurationChangeDetectedEvent(Object paramObject) {
    return new ConfigurationEvent(EventType.CHANGE_DETECTED, paramObject);
  }
  
  public static ConfigurationEvent newConfigurationChangeDetectorRegisteredEvent(Object paramObject) {
    return new ConfigurationEvent(EventType.CHANGE_DETECTOR_REGISTERED, paramObject);
  }
  
  public static ConfigurationEvent newConfigurationChangeDetectorRunningEvent(Object paramObject) {
    return new ConfigurationEvent(EventType.CHANGE_DETECTOR_RUNNING, paramObject);
  }
  
  public static ConfigurationEvent newConfigurationEndedEvent(Object paramObject) {
    return new ConfigurationEvent(EventType.CONFIGURATION_ENDED, paramObject);
  }
  
  public static ConfigurationEvent newConfigurationStartedEvent(Object paramObject) {
    return new ConfigurationEvent(EventType.CONFIGURATION_STARTED, paramObject);
  }
  
  public String toString() {
    String str1 = String.valueOf(this.eventType);
    String str2 = String.valueOf(this.data);
    StringBuilder stringBuilder = new StringBuilder();
    stringBuilder.append("ConfigurationEvent{eventType=");
    stringBuilder.append(str1);
    stringBuilder.append(", data=");
    stringBuilder.append(str2);
    stringBuilder.append("}");
    return stringBuilder.toString();
  }
  
  public enum EventType {
    CHANGE_DETECTED, CHANGE_DETECTOR_REGISTERED, CHANGE_DETECTOR_RUNNING, CONFIGURATION_ENDED, CONFIGURATION_STARTED;
    
    static {
      CONFIGURATION_ENDED = new EventType("CONFIGURATION_ENDED", 4);
      $VALUES = $values();
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\MagicAI - AI Art & Anime Art-dex2jar.jar!\ch\qos\logback\core\spi\ConfigurationEvent.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */