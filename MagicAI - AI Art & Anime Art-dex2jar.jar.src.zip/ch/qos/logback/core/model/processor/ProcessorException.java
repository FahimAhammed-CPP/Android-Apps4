package ch.qos.logback.core.model.processor;

public class ProcessorException extends Exception {
  private static final long serialVersionUID = 2245242609539650480L;
  
  public ProcessorException() {}
  
  public ProcessorException(Throwable paramThrowable) {
    super(paramThrowable);
  }
}


/* Location:              C:\soft\dex2jar-2.0\MagicAI - AI Art & Anime Art-dex2jar.jar!\ch\qos\logback\core\model\processor\ProcessorException.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */