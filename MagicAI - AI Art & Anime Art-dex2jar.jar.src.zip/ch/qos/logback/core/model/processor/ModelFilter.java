package ch.qos.logback.core.model.processor;

import ch.qos.logback.core.model.Model;
import ch.qos.logback.core.spi.FilterReply;

public interface ModelFilter {
  FilterReply decide(Model paramModel);
}


/* Location:              C:\soft\dex2jar-2.0\MagicAI - AI Art & Anime Art-dex2jar.jar!\ch\qos\logback\core\model\processor\ModelFilter.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */