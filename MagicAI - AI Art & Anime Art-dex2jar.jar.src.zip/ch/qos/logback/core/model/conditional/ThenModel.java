package ch.qos.logback.core.model.conditional;

import ch.qos.logback.core.model.Model;

public class ThenModel extends Model {
  private static final long serialVersionUID = -3264631638136701741L;
  
  protected ThenModel makeNewInstance() {
    return new ThenModel();
  }
}


/* Location:              C:\soft\dex2jar-2.0\MagicAI - AI Art & Anime Art-dex2jar.jar!\ch\qos\logback\core\model\conditional\ThenModel.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */