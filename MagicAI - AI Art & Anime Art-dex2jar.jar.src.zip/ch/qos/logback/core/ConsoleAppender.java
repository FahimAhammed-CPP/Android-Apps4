package ch.qos.logback.core;

import ch.qos.logback.core.joran.spi.ConsoleTarget;
import ch.qos.logback.core.spi.ContextAwareBase;
import ch.qos.logback.core.util.Loader;
import j$.util.DesugarArrays;
import j$.util.Optional;
import java.io.OutputStream;
import java.io.PrintStream;
import java.lang.reflect.Method;
import java.lang.reflect.Modifier;
import java.util.NoSuchElementException;
import java.util.function.Predicate;
import java.util.function.Supplier;

public class ConsoleAppender<E> extends OutputStreamAppender<E> {
  private static final Class<?>[] ARGUMENT_TYPES = new Class[] { PrintStream.class };
  
  protected ConsoleTarget target = ConsoleTarget.SystemOut;
  
  protected boolean withJansi = false;
  
  private OutputStream wrapWithJansi(OutputStream paramOutputStream) {
    Class<?> clazz;
    try {
      String str1;
      addInfo("Enabling JANSI AnsiPrintStream for the console.");
      clazz = Loader.getClassLoaderOfObject(((ContextAwareBase)this).context).loadClass("org.fusesource.jansi.AnsiConsole");
      ConsoleTarget consoleTarget1 = this.target;
      ConsoleTarget consoleTarget2 = ConsoleTarget.SystemOut;
      if (consoleTarget1 == consoleTarget2) {
        str1 = "out";
      } else {
        str1 = "err";
      } 
      Optional optional = DesugarArrays.stream((Object[])clazz.getMethods()).filter((Predicate)new ConsoleAppender$.ExternalSyntheticLambda1(str1)).filter((Predicate)new ConsoleAppender$.ExternalSyntheticLambda2()).filter((Predicate)new ConsoleAppender$.ExternalSyntheticLambda3()).filter((Predicate)new ConsoleAppender$.ExternalSyntheticLambda4()).findAny();
      if (optional.isPresent())
        return (PrintStream)((Method)optional.orElseThrow((Supplier)new ConsoleAppender$.ExternalSyntheticLambda5())).invoke(null, new Object[0]); 
      if (this.target == consoleTarget2) {
        String str2 = "wrapSystemOut";
        return (OutputStream)clazz.getMethod(str2, ARGUMENT_TYPES).invoke(null, new Object[] { new PrintStream(paramOutputStream) });
      } 
    } catch (Exception exception) {
      addWarn("Failed to create AnsiPrintStream. Falling back on the default stream.", exception);
      return paramOutputStream;
    } 
    String str = "wrapSystemErr";
    return (OutputStream)clazz.getMethod(str, ARGUMENT_TYPES).invoke(null, new Object[] { new PrintStream(paramOutputStream) });
  }
  
  public void start() {
    OutputStream outputStream2 = this.target.getStream();
    OutputStream outputStream1 = outputStream2;
    if (this.withJansi)
      outputStream1 = wrapWithJansi(outputStream2); 
    setOutputStream(outputStream1);
    super.start();
  }
}


/* Location:              C:\soft\dex2jar-2.0\MagicAI - AI Art & Anime Art-dex2jar.jar!\ch\qos\logback\core\ConsoleAppender.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */