package ch.qos.logback.core.subst;

import ch.qos.logback.core.spi.PropertyContainer;
import ch.qos.logback.core.spi.ScanException;
import ch.qos.logback.core.util.OptionHelper;
import java.util.Iterator;
import java.util.Stack;

public class NodeToStringTransformer {
  final Node node;
  
  final PropertyContainer propertyContainer0;
  
  final PropertyContainer propertyContainer1;
  
  public NodeToStringTransformer(Node paramNode, PropertyContainer paramPropertyContainer1, PropertyContainer paramPropertyContainer2) {
    this.node = paramNode;
    this.propertyContainer0 = paramPropertyContainer1;
    this.propertyContainer1 = paramPropertyContainer2;
  }
  
  private void compileNode(Node paramNode, StringBuilder paramStringBuilder, Stack<Node> paramStack) throws ScanException {
    while (paramNode != null) {
      int i = null.$SwitchMap$ch$qos$logback$core$subst$Node$Type[paramNode.type.ordinal()];
      if (i != 1) {
        if (i == 2)
          handleVariable(paramNode, paramStringBuilder, paramStack); 
      } else {
        handleLiteral(paramNode, paramStringBuilder);
      } 
      paramNode = paramNode.next;
    } 
  }
  
  private String constructRecursionErrorMessage(Stack<Node> paramStack) {
    StringBuilder stringBuilder = new StringBuilder("Circular variable reference detected while parsing input [");
    for (Node node : paramStack) {
      stringBuilder.append("${");
      stringBuilder.append(variableNodeValue(node));
      stringBuilder.append("}");
      if (paramStack.lastElement() != node)
        stringBuilder.append(" --> "); 
    } 
    stringBuilder.append("]");
    return stringBuilder.toString();
  }
  
  private boolean equalNodes(Node paramNode1, Node paramNode2) {
    Node.Type type = paramNode1.type;
    if (type != null && !type.equals(paramNode2.type))
      return false; 
    Object object2 = paramNode1.payload;
    if (object2 != null && !object2.equals(paramNode2.payload))
      return false; 
    Object object1 = paramNode1.defaultPart;
    return !(object1 != null && !object1.equals(paramNode2.defaultPart));
  }
  
  private void handleLiteral(Node paramNode, StringBuilder paramStringBuilder) {
    paramStringBuilder.append((String)paramNode.payload);
  }
  
  private void handleVariable(Node paramNode, StringBuilder paramStringBuilder, Stack<Node> paramStack) throws ScanException {
    Object object;
    if (!haveVisitedNodeAlready(paramNode, paramStack)) {
      paramStack.push(paramNode);
      StringBuilder stringBuilder2 = new StringBuilder();
      compileNode((Node)paramNode.payload, stringBuilder2, paramStack);
      String str1 = stringBuilder2.toString();
      String str2 = lookupKey(str1);
      if (str2 != null) {
        compileNode(tokenizeAndParseString(str2), paramStringBuilder, paramStack);
        paramStack.pop();
        return;
      } 
      object = paramNode.defaultPart;
      if (object == null) {
        object = new StringBuilder();
        object.append(str1);
        object.append("_IS_UNDEFINED");
        paramStringBuilder.append(object.toString());
        paramStack.pop();
        return;
      } 
      object = object;
      StringBuilder stringBuilder1 = new StringBuilder();
      compileNode((Node)object, stringBuilder1, paramStack);
      paramStack.pop();
      paramStringBuilder.append(stringBuilder1.toString());
      return;
    } 
    paramStack.push(object);
    throw new IllegalArgumentException(constructRecursionErrorMessage(paramStack));
  }
  
  private boolean haveVisitedNodeAlready(Node paramNode, Stack<Node> paramStack) {
    Iterator<Node> iterator = paramStack.iterator();
    while (iterator.hasNext()) {
      if (equalNodes(paramNode, iterator.next()))
        return true; 
    } 
    return false;
  }
  
  private String lookupKey(String paramString) {
    String str2 = this.propertyContainer0.getProperty(paramString);
    if (str2 != null)
      return str2; 
    PropertyContainer propertyContainer = this.propertyContainer1;
    if (propertyContainer != null) {
      String str = propertyContainer.getProperty(paramString);
      if (str != null)
        return str; 
    } 
    String str1 = OptionHelper.getSystemProperty(paramString, null);
    if (str1 != null)
      return str1; 
    paramString = OptionHelper.getEnv(paramString);
    return (paramString != null) ? paramString : null;
  }
  
  public static String substituteVariable(String paramString, PropertyContainer paramPropertyContainer1, PropertyContainer paramPropertyContainer2) throws ScanException {
    return (new NodeToStringTransformer(tokenizeAndParseString(paramString), paramPropertyContainer1, paramPropertyContainer2)).transform();
  }
  
  private static Node tokenizeAndParseString(String paramString) throws ScanException {
    return (new Parser((new Tokenizer(paramString)).tokenize())).parse();
  }
  
  private String variableNodeValue(Node paramNode) {
    paramNode = (Node)paramNode.payload;
    if (paramNode == null)
      return ""; 
    Node.Type type = paramNode.type;
    if (type == Node.Type.LITERAL)
      return (String)paramNode.payload; 
    if (type == Node.Type.VARIABLE) {
      String str = variableNodeValue(paramNode);
      StringBuilder stringBuilder = new StringBuilder();
      stringBuilder.append(" ? ");
      stringBuilder.append(str);
      return stringBuilder.toString();
    } 
    throw new IllegalStateException("unreachable code");
  }
  
  public String transform() throws ScanException {
    StringBuilder stringBuilder = new StringBuilder();
    compileNode(this.node, stringBuilder, new Stack<Node>());
    return stringBuilder.toString();
  }
}


/* Location:              C:\soft\dex2jar-2.0\MagicAI - AI Art & Anime Art-dex2jar.jar!\ch\qos\logback\core\subst\NodeToStringTransformer.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */