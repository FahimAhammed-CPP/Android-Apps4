package ch.qos.logback.core.joran;

import ch.qos.logback.core.joran.sanity.AppenderWithinAppenderSanityChecker;
import ch.qos.logback.core.joran.sanity.SanityChecker;
import ch.qos.logback.core.joran.spi.ElementSelector;
import ch.qos.logback.core.joran.spi.RuleStore;
import ch.qos.logback.core.joran.spi.SaxEventInterpreter;
import ch.qos.logback.core.model.DefineModel;
import ch.qos.logback.core.model.EventEvaluatorModel;
import ch.qos.logback.core.model.ImplicitModel;
import ch.qos.logback.core.model.ImportModel;
import ch.qos.logback.core.model.IncludeModel;
import ch.qos.logback.core.model.Model;
import ch.qos.logback.core.model.ModelHandlerFactoryMethod;
import ch.qos.logback.core.model.ParamModel;
import ch.qos.logback.core.model.PropertyModel;
import ch.qos.logback.core.model.SequenceNumberGeneratorModel;
import ch.qos.logback.core.model.ShutdownHookModel;
import ch.qos.logback.core.model.SiftModel;
import ch.qos.logback.core.model.StatusListenerModel;
import ch.qos.logback.core.model.TimestampModel;
import ch.qos.logback.core.model.conditional.ElseModel;
import ch.qos.logback.core.model.conditional.IfModel;
import ch.qos.logback.core.model.conditional.ThenModel;
import ch.qos.logback.core.model.processor.DefaultProcessor;
import ch.qos.logback.core.spi.ContextAware;
import ch.qos.logback.core.spi.ContextAwareBase;
import java.util.function.Supplier;

public abstract class JoranConfiguratorBase<E> extends GenericXMLConfigurator {
  protected void addElementSelectorAndActionAssociations(RuleStore paramRuleStore) {
    paramRuleStore.addRule(new ElementSelector("*/variable"), (Supplier)new JoranConfiguratorBase$.ExternalSyntheticLambda16());
    paramRuleStore.addRule(new ElementSelector("*/property"), (Supplier)new JoranConfiguratorBase$.ExternalSyntheticLambda16());
    paramRuleStore.addRule(new ElementSelector("*/substitutionProperty"), (Supplier)new JoranConfiguratorBase$.ExternalSyntheticLambda16());
    paramRuleStore.addRule(new ElementSelector("configuration/import"), (Supplier)new JoranConfiguratorBase$.ExternalSyntheticLambda27());
    paramRuleStore.addRule(new ElementSelector("configuration/timestamp"), (Supplier)new JoranConfiguratorBase$.ExternalSyntheticLambda28());
    paramRuleStore.addRule(new ElementSelector("configuration/shutdownHook"), (Supplier)new JoranConfiguratorBase$.ExternalSyntheticLambda29());
    paramRuleStore.addRule(new ElementSelector("configuration/sequenceNumberGenerator"), (Supplier)new JoranConfiguratorBase$.ExternalSyntheticLambda30());
    paramRuleStore.addRule(new ElementSelector("configuration/define"), (Supplier)new JoranConfiguratorBase$.ExternalSyntheticLambda31());
    paramRuleStore.addRule(new ElementSelector("configuration/evaluator"), (Supplier)new JoranConfiguratorBase$.ExternalSyntheticLambda32());
    paramRuleStore.addRule(new ElementSelector("configuration/contextProperty"), (Supplier)new JoranConfiguratorBase$.ExternalSyntheticLambda33());
    paramRuleStore.addRule(new ElementSelector("configuration/conversionRule"), (Supplier)new JoranConfiguratorBase$.ExternalSyntheticLambda17());
    paramRuleStore.addRule(new ElementSelector("configuration/statusListener"), (Supplier)new JoranConfiguratorBase$.ExternalSyntheticLambda18());
    paramRuleStore.addRule(new ElementSelector("*/appender"), (Supplier)new JoranConfiguratorBase$.ExternalSyntheticLambda19());
    paramRuleStore.addRule(new ElementSelector("configuration/appender/appender-ref"), (Supplier)new JoranConfiguratorBase$.ExternalSyntheticLambda20());
    paramRuleStore.addRule(new ElementSelector("configuration/newRule"), (Supplier)new JoranConfiguratorBase$.ExternalSyntheticLambda21());
    paramRuleStore.addRule(new ElementSelector("*/param"), (Supplier)new JoranConfiguratorBase$.ExternalSyntheticLambda22());
    paramRuleStore.addRule(new ElementSelector("*/if"), (Supplier)new JoranConfiguratorBase$.ExternalSyntheticLambda23());
    paramRuleStore.addTransparentPathPart("if");
    paramRuleStore.addRule(new ElementSelector("*/if/then"), (Supplier)new JoranConfiguratorBase$.ExternalSyntheticLambda24());
    paramRuleStore.addTransparentPathPart("then");
    paramRuleStore.addRule(new ElementSelector("*/if/else"), (Supplier)new JoranConfiguratorBase$.ExternalSyntheticLambda25());
    paramRuleStore.addTransparentPathPart("else");
    paramRuleStore.addRule(new ElementSelector("*/appender/sift"), (Supplier)new JoranConfiguratorBase$.ExternalSyntheticLambda26());
    paramRuleStore.addTransparentPathPart("sift");
  }
  
  protected void addModelHandlerAssociations(DefaultProcessor paramDefaultProcessor) {
    paramDefaultProcessor.addHandler(ImportModel.class, (ModelHandlerFactoryMethod)new JoranConfiguratorBase$.ExternalSyntheticLambda0());
    paramDefaultProcessor.addHandler(ShutdownHookModel.class, (ModelHandlerFactoryMethod)new JoranConfiguratorBase$.ExternalSyntheticLambda6());
    paramDefaultProcessor.addHandler(SequenceNumberGeneratorModel.class, (ModelHandlerFactoryMethod)new JoranConfiguratorBase$.ExternalSyntheticLambda7());
    paramDefaultProcessor.addHandler(EventEvaluatorModel.class, (ModelHandlerFactoryMethod)new JoranConfiguratorBase$.ExternalSyntheticLambda8());
    paramDefaultProcessor.addHandler(DefineModel.class, (ModelHandlerFactoryMethod)new JoranConfiguratorBase$.ExternalSyntheticLambda9());
    paramDefaultProcessor.addHandler(IncludeModel.class, (ModelHandlerFactoryMethod)new JoranConfiguratorBase$.ExternalSyntheticLambda10());
    paramDefaultProcessor.addHandler(ParamModel.class, (ModelHandlerFactoryMethod)new JoranConfiguratorBase$.ExternalSyntheticLambda11());
    paramDefaultProcessor.addHandler(PropertyModel.class, (ModelHandlerFactoryMethod)new JoranConfiguratorBase$.ExternalSyntheticLambda12());
    paramDefaultProcessor.addHandler(TimestampModel.class, (ModelHandlerFactoryMethod)new JoranConfiguratorBase$.ExternalSyntheticLambda13());
    paramDefaultProcessor.addHandler(StatusListenerModel.class, (ModelHandlerFactoryMethod)new JoranConfiguratorBase$.ExternalSyntheticLambda14());
    paramDefaultProcessor.addHandler(ImplicitModel.class, (ModelHandlerFactoryMethod)new JoranConfiguratorBase$.ExternalSyntheticLambda1());
    paramDefaultProcessor.addHandler(IfModel.class, (ModelHandlerFactoryMethod)new JoranConfiguratorBase$.ExternalSyntheticLambda2());
    paramDefaultProcessor.addHandler(ThenModel.class, (ModelHandlerFactoryMethod)new JoranConfiguratorBase$.ExternalSyntheticLambda3());
    paramDefaultProcessor.addHandler(ElseModel.class, (ModelHandlerFactoryMethod)new JoranConfiguratorBase$.ExternalSyntheticLambda4());
    paramDefaultProcessor.addHandler(SiftModel.class, (ModelHandlerFactoryMethod)new JoranConfiguratorBase$.ExternalSyntheticLambda5());
  }
  
  public void buildModelInterpretationContext() {
    super.buildModelInterpretationContext();
    this.modelInterpretationContext.createAppenderBags();
  }
  
  protected void performCheck(SanityChecker paramSanityChecker, Model paramModel) {
    if (paramSanityChecker instanceof ContextAware)
      ((ContextAware)paramSanityChecker).setContext(((ContextAwareBase)this).context); 
    paramSanityChecker.check(paramModel);
  }
  
  protected void sanityCheck(Model paramModel) {
    performCheck((SanityChecker)new AppenderWithinAppenderSanityChecker(), paramModel);
  }
  
  protected void setImplicitRuleSupplier(SaxEventInterpreter paramSaxEventInterpreter) {
    paramSaxEventInterpreter.setImplicitActionSupplier((Supplier)new JoranConfiguratorBase$.ExternalSyntheticLambda15());
  }
}


/* Location:              C:\soft\dex2jar-2.0\MagicAI - AI Art & Anime Art-dex2jar.jar!\ch\qos\logback\core\joran\JoranConfiguratorBase.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */