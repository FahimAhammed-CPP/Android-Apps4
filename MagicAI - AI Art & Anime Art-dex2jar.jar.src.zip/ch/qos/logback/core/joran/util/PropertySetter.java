package ch.qos.logback.core.joran.util;

import ch.qos.logback.core.joran.spi.DefaultClass;
import ch.qos.logback.core.joran.spi.DefaultNestedComponentRegistry;
import ch.qos.logback.core.joran.util.beans.BeanDescription;
import ch.qos.logback.core.joran.util.beans.BeanDescriptionCache;
import ch.qos.logback.core.joran.util.beans.BeanUtil;
import ch.qos.logback.core.spi.ContextAware;
import ch.qos.logback.core.spi.ContextAwareBase;
import ch.qos.logback.core.util.AggregationType;
import ch.qos.logback.core.util.PropertySetterException;
import java.lang.reflect.Method;

public class PropertySetter extends ContextAwareBase {
  protected final BeanDescription beanDescription;
  
  protected final Object obj;
  
  protected final Class<?> objClass;
  
  public PropertySetter(BeanDescriptionCache paramBeanDescriptionCache, Object<?> paramObject) {
    this.obj = paramObject;
    paramObject = (Object<?>)paramObject.getClass();
    this.objClass = (Class<?>)paramObject;
    this.beanDescription = paramBeanDescriptionCache.getBeanDescription((Class)paramObject);
  }
  
  private String capitalizeFirstLetter(String paramString) {
    String str = paramString.substring(0, 1).toUpperCase();
    paramString = paramString.substring(1);
    StringBuilder stringBuilder = new StringBuilder();
    stringBuilder.append(str);
    stringBuilder.append(paramString);
    return stringBuilder.toString();
  }
  
  private AggregationType computeRawAggregationType(Method paramMethod) {
    Class<?> clazz = getParameterClassForMethod(paramMethod);
    return (clazz == null) ? AggregationType.NOT_FOUND : (StringToObjectConverter.canBeBuiltFromSimpleString(clazz) ? AggregationType.AS_BASIC_PROPERTY : AggregationType.AS_COMPLEX_PROPERTY);
  }
  
  private Method findAdderMethod(String paramString) {
    paramString = BeanUtil.toLowerCamelCase(paramString);
    return this.beanDescription.getAdder(paramString);
  }
  
  private Method findSetterMethod(String paramString) {
    paramString = BeanUtil.toLowerCamelCase(paramString);
    return this.beanDescription.getSetter(paramString);
  }
  
  private Class<?> getParameterClassForMethod(Method paramMethod) {
    if (paramMethod == null)
      return null; 
    Class[] arrayOfClass = paramMethod.getParameterTypes();
    return (arrayOfClass.length != 1) ? null : arrayOfClass[0];
  }
  
  private boolean isSanityCheckSuccessful(String paramString, Method paramMethod, Class<?>[] paramArrayOfClass, Object paramObject) {
    String str;
    StringBuilder stringBuilder;
    Class<?> clazz = paramObject.getClass();
    if (paramArrayOfClass.length != 1) {
      str = this.obj.getClass().getName();
      stringBuilder = new StringBuilder();
      stringBuilder.append("Wrong number of parameters in setter method for property [");
      stringBuilder.append(paramString);
      stringBuilder.append("] in ");
      stringBuilder.append(str);
      addError(stringBuilder.toString());
      return false;
    } 
    if (!stringBuilder[0].isAssignableFrom(paramObject.getClass())) {
      paramString = str.getName();
      paramObject = stringBuilder[0].getName();
      StringBuilder stringBuilder1 = new StringBuilder();
      stringBuilder1.append("A \"");
      stringBuilder1.append(paramString);
      stringBuilder1.append("\" object is not assignable to a \"");
      stringBuilder1.append((String)paramObject);
      stringBuilder1.append("\" variable.");
      addError(stringBuilder1.toString());
      paramString = stringBuilder[0].getName();
      paramObject = new StringBuilder();
      paramObject.append("The class \"");
      paramObject.append(paramString);
      paramObject.append("\" was loaded by ");
      addError(paramObject.toString());
      paramString = String.valueOf(stringBuilder[0].getClassLoader());
      stringBuilder = new StringBuilder();
      stringBuilder.append("[");
      stringBuilder.append(paramString);
      stringBuilder.append("] whereas object of type ");
      addError(stringBuilder.toString());
      paramString = str.getName();
      str = String.valueOf(str.getClassLoader());
      stringBuilder = new StringBuilder();
      stringBuilder.append("\"");
      stringBuilder.append(paramString);
      stringBuilder.append("\" was loaded by [");
      stringBuilder.append(str);
      stringBuilder.append("].");
      addError(stringBuilder.toString());
      return false;
    } 
    return true;
  }
  
  private boolean isUnequivocallyInstantiable(Class<?> paramClass) {
    if (paramClass.isInterface())
      return false; 
    try {
      paramClass = paramClass.getDeclaredConstructor(new Class[0]).newInstance(new Object[0]);
      return (paramClass != null);
    } catch (InstantiationException|IllegalAccessException|java.lang.reflect.InvocationTargetException|NoSuchMethodException instantiationException) {
      return false;
    } 
  }
  
  private void setProperty(Method paramMethod, String paramString1, String paramString2) throws PropertySetterException {
    StringBuilder stringBuilder;
    Class[] arrayOfClass = paramMethod.getParameterTypes();
    try {
      Object object = StringToObjectConverter.convertArg((ContextAware)this, paramString2, arrayOfClass[0]);
      if (object != null)
        try {
          return;
        } catch (Exception exception) {
          throw new PropertySetterException(exception);
        }  
      String str = String.valueOf(arrayOfClass[0]);
      stringBuilder = new StringBuilder();
      stringBuilder.append("Conversion to type [");
      stringBuilder.append(str);
      stringBuilder.append("] failed.");
      throw new PropertySetterException(stringBuilder.toString());
    } finally {
      paramMethod = null;
      String str = String.valueOf(stringBuilder[0]);
      StringBuilder stringBuilder1 = new StringBuilder();
      stringBuilder1.append("Conversion to type [");
      stringBuilder1.append(str);
      stringBuilder1.append("] failed. ");
    } 
  }
  
  public void addBasicProperty(String paramString1, String paramString2) {
    if (paramString2 == null)
      return; 
    String str = capitalizeFirstLetter(paramString1);
    Method method = findAdderMethod(str);
    if (method == null) {
      StringBuilder stringBuilder = new StringBuilder();
      stringBuilder.append("No adder for property [");
      stringBuilder.append(str);
      stringBuilder.append("].");
      addError(stringBuilder.toString());
      return;
    } 
    Class[] arrayOfClass = method.getParameterTypes();
    isSanityCheckSuccessful(str, method, arrayOfClass, paramString2);
    try {
      return;
    } finally {
      paramString2 = null;
      String str1 = String.valueOf(arrayOfClass[0]);
      StringBuilder stringBuilder = new StringBuilder();
      stringBuilder.append("Conversion to type [");
      stringBuilder.append(str1);
      stringBuilder.append("] failed. ");
      addError(stringBuilder.toString(), (Throwable)paramString2);
    } 
  }
  
  public void addComplexProperty(String paramString, Object paramObject) {
    Method method = findAdderMethod(paramString);
    if (method != null) {
      if (!isSanityCheckSuccessful(paramString, method, method.getParameterTypes(), paramObject))
        return; 
      invokeMethodWithSingleParameterOnThisObject(method, paramObject);
      return;
    } 
    paramObject = this.objClass.getName();
    StringBuilder stringBuilder = new StringBuilder();
    stringBuilder.append("Could not find method [add");
    stringBuilder.append(paramString);
    stringBuilder.append("] in class [");
    stringBuilder.append((String)paramObject);
    stringBuilder.append("].");
    addError(stringBuilder.toString());
  }
  
  public AggregationType computeAggregationType(String paramString) {
    Method method2 = findAdderMethod(capitalizeFirstLetter(paramString));
    if (method2 != null) {
      AggregationType aggregationType = computeRawAggregationType(method2);
      int i = null.$SwitchMap$ch$qos$logback$core$util$AggregationType[aggregationType.ordinal()];
      if (i != 1) {
        if (i != 2) {
          if (i != 3) {
            if (i == 4 || i == 5) {
              String str = String.valueOf(aggregationType);
              StringBuilder stringBuilder = new StringBuilder();
              stringBuilder.append("Unexpected AggregationType ");
              stringBuilder.append(str);
              addError(stringBuilder.toString());
            } 
          } else {
            return AggregationType.AS_COMPLEX_PROPERTY_COLLECTION;
          } 
        } else {
          return AggregationType.AS_BASIC_PROPERTY_COLLECTION;
        } 
      } else {
        return AggregationType.NOT_FOUND;
      } 
    } 
    Method method1 = findSetterMethod(paramString);
    return (method1 != null) ? computeRawAggregationType(method1) : AggregationType.NOT_FOUND;
  }
  
  <T extends java.lang.annotation.Annotation> T getAnnotation(String paramString, Class<T> paramClass, Method paramMethod) {
    return (paramMethod != null) ? paramMethod.getAnnotation(paramClass) : null;
  }
  
  Class<?> getByConcreteType(String paramString, Method paramMethod) {
    Class<?> clazz = getParameterClassForMethod(paramMethod);
    return (clazz == null) ? null : (isUnequivocallyInstantiable(clazz) ? clazz : null);
  }
  
  public Class<?> getClassNameViaImplicitRules(String paramString, AggregationType paramAggregationType, DefaultNestedComponentRegistry paramDefaultNestedComponentRegistry) {
    Class<?> clazz = paramDefaultNestedComponentRegistry.findDefaultComponentType(this.obj.getClass(), paramString);
    if (clazz != null)
      return clazz; 
    Method method = getRelevantMethod(paramString, paramAggregationType);
    if (method == null)
      return null; 
    clazz = getDefaultClassNameByAnnonation(paramString, method);
    return (clazz != null) ? clazz : getByConcreteType(paramString, method);
  }
  
  Class<?> getDefaultClassNameByAnnonation(String paramString, Method paramMethod) {
    DefaultClass defaultClass = getAnnotation(paramString, DefaultClass.class, paramMethod);
    return (defaultClass != null) ? defaultClass.value() : null;
  }
  
  public Object getObj() {
    return this.obj;
  }
  
  Method getRelevantMethod(String paramString, AggregationType paramAggregationType) {
    if (paramAggregationType == AggregationType.AS_COMPLEX_PROPERTY_COLLECTION)
      return findAdderMethod(paramString); 
    if (paramAggregationType == AggregationType.AS_COMPLEX_PROPERTY)
      return findSetterMethod(paramString); 
    paramString = String.valueOf(paramAggregationType);
    StringBuilder stringBuilder = new StringBuilder();
    stringBuilder.append(paramString);
    stringBuilder.append(" not allowed here");
    throw new IllegalStateException(stringBuilder.toString());
  }
  
  void invokeMethodWithSingleParameterOnThisObject(Method paramMethod, Object paramObject) {
    Class<?> clazz = paramObject.getClass();
    try {
      paramMethod.invoke(this.obj, new Object[] { paramObject });
      return;
    } catch (Exception exception) {
      String str1 = paramMethod.getName();
      String str3 = this.obj.getClass().getName();
      String str2 = clazz.getName();
      StringBuilder stringBuilder = new StringBuilder();
      stringBuilder.append("Could not invoke method ");
      stringBuilder.append(str1);
      stringBuilder.append(" in class ");
      stringBuilder.append(str3);
      stringBuilder.append(" with parameter of type ");
      stringBuilder.append(str2);
      addError(stringBuilder.toString(), exception);
      return;
    } 
  }
  
  public void setComplexProperty(String paramString, Object paramObject) {
    StringBuilder stringBuilder;
    Method method = findSetterMethod(paramString);
    if (method == null) {
      paramObject = this.obj.getClass().getName();
      stringBuilder = new StringBuilder();
      stringBuilder.append("Not setter method for property [");
      stringBuilder.append(paramString);
      stringBuilder.append("] in ");
      stringBuilder.append((String)paramObject);
      addWarn(stringBuilder.toString());
      return;
    } 
    if (!isSanityCheckSuccessful(paramString, (Method)stringBuilder, stringBuilder.getParameterTypes(), paramObject))
      return; 
    try {
      invokeMethodWithSingleParameterOnThisObject((Method)stringBuilder, paramObject);
      return;
    } catch (Exception exception) {
      paramObject = String.valueOf(this.obj);
      String str = String.valueOf(this.obj);
      StringBuilder stringBuilder1 = new StringBuilder();
      stringBuilder1.append("Could not set component ");
      stringBuilder1.append((String)paramObject);
      stringBuilder1.append(" for parent component ");
      stringBuilder1.append(str);
      addError(stringBuilder1.toString(), exception);
      return;
    } 
  }
  
  public void setProperty(String paramString1, String paramString2) {
    StringBuilder stringBuilder;
    if (paramString2 == null)
      return; 
    Method method = findSetterMethod(paramString1);
    if (method == null) {
      paramString2 = this.objClass.getName();
      stringBuilder = new StringBuilder();
      stringBuilder.append("No setter for property [");
      stringBuilder.append(paramString1);
      stringBuilder.append("] in ");
      stringBuilder.append(paramString2);
      stringBuilder.append(".");
      addWarn(stringBuilder.toString());
      return;
    } 
    try {
      setProperty((Method)stringBuilder, paramString1, paramString2);
      return;
    } catch (PropertySetterException propertySetterException) {
      StringBuilder stringBuilder1 = new StringBuilder();
      stringBuilder1.append("Failed to set property [");
      stringBuilder1.append(paramString1);
      stringBuilder1.append("] to value \"");
      stringBuilder1.append(paramString2);
      stringBuilder1.append("\". ");
      addWarn(stringBuilder1.toString(), (Throwable)propertySetterException);
      return;
    } 
  }
}


/* Location:              C:\soft\dex2jar-2.0\MagicAI - AI Art & Anime Art-dex2jar.jar!\ch\qos\logback\core\jora\\util\PropertySetter.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */