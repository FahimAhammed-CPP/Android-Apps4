package ch.qos.logback.core.joran.action;

import ch.qos.logback.core.model.processor.ModelInterpretationContext;
import ch.qos.logback.core.spi.ContextAware;
import ch.qos.logback.core.util.OptionHelper;

public class ActionUtil {
  public static void setProperty(ModelInterpretationContext paramModelInterpretationContext, String paramString1, String paramString2, Scope paramScope) {
    int i = null.$SwitchMap$ch$qos$logback$core$joran$action$ActionUtil$Scope[paramScope.ordinal()];
    if (i != 1) {
      if (i != 2) {
        if (i != 3)
          return; 
        OptionHelper.setSystemProperty((ContextAware)paramModelInterpretationContext, paramString1, paramString2);
        return;
      } 
      paramModelInterpretationContext.getContext().putProperty(paramString1, paramString2);
      return;
    } 
    paramModelInterpretationContext.addSubstitutionProperty(paramString1, paramString2);
  }
  
  public static Scope stringToScope(String paramString) {
    Scope scope = Scope.SYSTEM;
    if (scope.toString().equalsIgnoreCase(paramString))
      return scope; 
    scope = Scope.CONTEXT;
    return scope.toString().equalsIgnoreCase(paramString) ? scope : Scope.LOCAL;
  }
  
  public enum Scope {
    CONTEXT, LOCAL, SYSTEM;
    
    static {
      $VALUES = $values();
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\MagicAI - AI Art & Anime Art-dex2jar.jar!\ch\qos\logback\core\joran\action\ActionUtil.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */