package ch.qos.logback.core.joran.conditional;

import ch.qos.logback.core.joran.action.BaseModelAction;
import ch.qos.logback.core.joran.action.PreconditionValidator;
import ch.qos.logback.core.joran.spi.SaxEventInterpretationContext;
import ch.qos.logback.core.model.Model;
import ch.qos.logback.core.model.conditional.ThenModel;
import ch.qos.logback.core.spi.ContextAware;
import org.xml.sax.Attributes;

public class ThenAction extends BaseModelAction {
  protected Model buildCurrentModel(SaxEventInterpretationContext paramSaxEventInterpretationContext, String paramString, Attributes paramAttributes) {
    return (Model)new ThenModel();
  }
  
  protected boolean validPreconditions(SaxEventInterpretationContext paramSaxEventInterpretationContext, String paramString, Attributes paramAttributes) {
    PreconditionValidator preconditionValidator = new PreconditionValidator((ContextAware)this, paramSaxEventInterpretationContext, paramString, paramAttributes);
    preconditionValidator.validateZeroAttributes();
    return preconditionValidator.isValid();
  }
}


/* Location:              C:\soft\dex2jar-2.0\MagicAI - AI Art & Anime Art-dex2jar.jar!\ch\qos\logback\core\joran\conditional\ThenAction.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */