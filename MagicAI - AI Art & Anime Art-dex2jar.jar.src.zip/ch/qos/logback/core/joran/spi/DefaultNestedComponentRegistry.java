package ch.qos.logback.core.joran.spi;

import java.util.HashMap;
import java.util.Map;

public class DefaultNestedComponentRegistry {
  Map<HostClassAndPropertyDouble, Class<?>> defaultComponentMap = new HashMap<HostClassAndPropertyDouble, Class<?>>();
  
  Map<String, Class<?>> tagToClassMap = new HashMap<String, Class<?>>();
  
  private Class<?> oneShotFind(Class<?> paramClass, String paramString) {
    HostClassAndPropertyDouble hostClassAndPropertyDouble = new HostClassAndPropertyDouble(paramClass, paramString);
    return this.defaultComponentMap.get(hostClassAndPropertyDouble);
  }
  
  public void add(Class<?> paramClass1, String paramString, Class<?> paramClass2) {
    HostClassAndPropertyDouble hostClassAndPropertyDouble = new HostClassAndPropertyDouble(paramClass1, paramString.toLowerCase());
    this.defaultComponentMap.put(hostClassAndPropertyDouble, paramClass2);
    this.tagToClassMap.put(paramString, paramClass2);
  }
  
  public Class<?> findDefaultComponentType(Class<?> paramClass, String paramString) {
    paramString = paramString.toLowerCase();
    while (paramClass != null) {
      Class<?> clazz = oneShotFind(paramClass, paramString);
      if (clazz != null)
        return clazz; 
      paramClass = paramClass.getSuperclass();
    } 
    return null;
  }
  
  public String findDefaultComponentTypeByTag(String paramString) {
    Class clazz = this.tagToClassMap.get(paramString);
    return (clazz == null) ? null : clazz.getCanonicalName();
  }
}


/* Location:              C:\soft\dex2jar-2.0\MagicAI - AI Art & Anime Art-dex2jar.jar!\ch\qos\logback\core\joran\spi\DefaultNestedComponentRegistry.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */