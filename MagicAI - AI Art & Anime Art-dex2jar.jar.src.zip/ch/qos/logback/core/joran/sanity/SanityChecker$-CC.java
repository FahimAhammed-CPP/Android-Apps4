package ch.qos.logback.core.joran.sanity;

import ch.qos.logback.core.model.Model;
import j$.lang.Iterable;
import j$.util.Collection;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.function.Consumer;



/* Location:              C:\soft\dex2jar-2.0\MagicAI - AI Art & Anime Art-dex2jar.jar!\ch\qos\logback\core\joran\sanity\SanityChecker$-CC.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */