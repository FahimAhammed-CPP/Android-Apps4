package ch.qos.logback.classic.spi;

import j$.time.Instant;
import java.util.List;
import org.slf4j.Marker;



/* Location:              C:\soft\dex2jar-2.0\MagicAI - AI Art & Anime Art-dex2jar.jar!\ch\qos\logback\classic\spi\ILoggingEvent$-CC.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */