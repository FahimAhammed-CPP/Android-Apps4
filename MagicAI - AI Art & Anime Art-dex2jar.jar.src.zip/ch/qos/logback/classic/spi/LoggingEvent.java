package ch.qos.logback.classic.spi;

import ch.qos.logback.classic.Level;
import ch.qos.logback.classic.Logger;
import ch.qos.logback.classic.LoggerContext;
import ch.qos.logback.classic.util.LogbackMDCAdapter;
import ch.qos.logback.core.spi.SequenceNumberGenerator;
import j$.time.Clock;
import j$.time.Instant;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Map;
import org.slf4j.Marker;
import org.slf4j.event.KeyValuePair;
import org.slf4j.helpers.MessageFormatter;

public class LoggingEvent implements ILoggingEvent {
  private transient Object[] argumentArray;
  
  private StackTraceElement[] callerDataArray;
  
  transient String formattedMessage;
  
  transient String fqnOfLoggerClass;
  
  private Instant instant;
  
  List<KeyValuePair> keyValuePairs;
  
  private transient Level level;
  
  private LoggerContext loggerContext;
  
  private LoggerContextVO loggerContextVO;
  
  private String loggerName;
  
  private List<Marker> markerList;
  
  private Map<String, String> mdcPropertyMap;
  
  private String message;
  
  private int nanoseconds;
  
  private long sequenceNumber;
  
  private String threadName;
  
  private ThrowableProxy throwableProxy;
  
  private long timeStamp;
  
  public LoggingEvent(String paramString1, Logger paramLogger, Level paramLevel, String paramString2, Throwable paramThrowable, Object[] paramArrayOfObject) {
    this.fqnOfLoggerClass = paramString1;
    this.loggerName = paramLogger.getName();
    LoggerContext loggerContext = paramLogger.getLoggerContext();
    this.loggerContext = loggerContext;
    this.loggerContextVO = loggerContext.getLoggerContextRemoteView();
    this.level = paramLevel;
    this.message = paramString2;
    this.argumentArray = paramArrayOfObject;
    initTmestampFields(Clock.systemUTC().instant());
    loggerContext = this.loggerContext;
    if (loggerContext != null) {
      SequenceNumberGenerator sequenceNumberGenerator = loggerContext.getSequenceNumberGenerator();
      if (sequenceNumberGenerator != null)
        this.sequenceNumber = sequenceNumberGenerator.nextSequenceNumber(); 
    } 
    Throwable throwable = paramThrowable;
    if (paramThrowable == null)
      throwable = extractThrowableAnRearrangeArguments(paramArrayOfObject); 
    if (throwable != null) {
      this.throwableProxy = new ThrowableProxy(throwable);
      LoggerContext loggerContext1 = this.loggerContext;
      if (loggerContext1 != null && loggerContext1.isPackagingDataEnabled())
        this.throwableProxy.calculatePackagingData(); 
    } 
  }
  
  private Throwable extractThrowableAnRearrangeArguments(Object[] paramArrayOfObject) {
    Throwable throwable = EventArgUtil.extractThrowable(paramArrayOfObject);
    if (EventArgUtil.successfulExtraction(throwable))
      this.argumentArray = EventArgUtil.trimmedCopy(paramArrayOfObject); 
    return throwable;
  }
  
  public void addMarker(Marker paramMarker) {
    if (paramMarker == null)
      return; 
    if (this.markerList == null)
      this.markerList = new ArrayList<Marker>(4); 
    this.markerList.add(paramMarker);
  }
  
  public Object[] getArgumentArray() {
    return this.argumentArray;
  }
  
  public StackTraceElement[] getCallerData() {
    if (this.callerDataArray == null)
      this.callerDataArray = CallerData.extract(new Throwable(), this.fqnOfLoggerClass, this.loggerContext.getMaxCallerDataDepth(), this.loggerContext.getFrameworkPackages()); 
    return this.callerDataArray;
  }
  
  public String getFormattedMessage() {
    String str = this.formattedMessage;
    if (str != null)
      return str; 
    Object[] arrayOfObject = this.argumentArray;
    if (arrayOfObject != null) {
      this.formattedMessage = MessageFormatter.arrayFormat(this.message, arrayOfObject).getMessage();
    } else {
      this.formattedMessage = this.message;
    } 
    return this.formattedMessage;
  }
  
  public List<KeyValuePair> getKeyValuePairs() {
    return this.keyValuePairs;
  }
  
  public Level getLevel() {
    return this.level;
  }
  
  public LoggerContextVO getLoggerContextVO() {
    return this.loggerContextVO;
  }
  
  public String getLoggerName() {
    return this.loggerName;
  }
  
  public Map<String, String> getMDCPropertyMap() {
    if (this.mdcPropertyMap == null) {
      LogbackMDCAdapter logbackMDCAdapter = this.loggerContext.getMDCAdapter();
      if (logbackMDCAdapter instanceof LogbackMDCAdapter) {
        this.mdcPropertyMap = logbackMDCAdapter.getPropertyMap();
      } else {
        this.mdcPropertyMap = logbackMDCAdapter.getCopyOfContextMap();
      } 
    } 
    if (this.mdcPropertyMap == null)
      this.mdcPropertyMap = Collections.emptyMap(); 
    return this.mdcPropertyMap;
  }
  
  public List<Marker> getMarkerList() {
    return this.markerList;
  }
  
  public String getMessage() {
    return this.message;
  }
  
  public int getNanoseconds() {
    return this.nanoseconds;
  }
  
  public long getSequenceNumber() {
    return this.sequenceNumber;
  }
  
  public String getThreadName() {
    if (this.threadName == null)
      this.threadName = Thread.currentThread().getName(); 
    return this.threadName;
  }
  
  public IThrowableProxy getThrowableProxy() {
    return (IThrowableProxy)this.throwableProxy;
  }
  
  public long getTimeStamp() {
    return this.timeStamp;
  }
  
  public boolean hasCallerData() {
    return (this.callerDataArray != null);
  }
  
  void initTmestampFields(Instant paramInstant) {
    this.instant = paramInstant;
    long l = paramInstant.getEpochSecond();
    int i = paramInstant.getNano();
    this.nanoseconds = i;
    this.timeStamp = l * 1000L + (i / 1000000);
  }
  
  public void prepareForDeferredProcessing() {
    getFormattedMessage();
    getThreadName();
    getMDCPropertyMap();
  }
  
  public void setKeyValuePairs(List<KeyValuePair> paramList) {
    this.keyValuePairs = paramList;
  }
  
  public String toString() {
    StringBuilder stringBuilder = new StringBuilder();
    stringBuilder.append('[');
    stringBuilder.append(this.level);
    stringBuilder.append("] ");
    stringBuilder.append(getFormattedMessage());
    return stringBuilder.toString();
  }
}


/* Location:              C:\soft\dex2jar-2.0\MagicAI - AI Art & Anime Art-dex2jar.jar!\ch\qos\logback\classic\spi\LoggingEvent.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */