package ch.qos.logback.classic.boolex;

import ch.qos.logback.classic.Level;
import ch.qos.logback.classic.spi.ILoggingEvent;
import ch.qos.logback.classic.spi.IThrowableProxy;
import ch.qos.logback.classic.spi.LoggerContextVO;
import ch.qos.logback.classic.spi.ThrowableProxy;
import ch.qos.logback.core.CoreConstants;
import ch.qos.logback.core.boolex.JaninoEventEvaluatorBase;
import ch.qos.logback.core.boolex.Matcher;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

public class JaninoEventEvaluator extends JaninoEventEvaluatorBase<ILoggingEvent> {
  public static final List<String> DEFAULT_PARAM_NAME_LIST;
  
  public static final List<Class<?>> DEFAULT_PARAM_TYPE_LIST;
  
  static {
    ArrayList<String> arrayList1 = new ArrayList();
    DEFAULT_PARAM_NAME_LIST = arrayList1;
    ArrayList<Class<?>> arrayList = new ArrayList();
    DEFAULT_PARAM_TYPE_LIST = arrayList;
    arrayList1.add("DEBUG");
    arrayList1.add("INFO");
    arrayList1.add("WARN");
    arrayList1.add("ERROR");
    arrayList1.add("event");
    arrayList1.add("message");
    arrayList1.add("formattedMessage");
    arrayList1.add("logger");
    arrayList1.add("loggerContext");
    arrayList1.add("level");
    arrayList1.add("timeStamp");
    arrayList1.add("mdc");
    arrayList1.add("throwableProxy");
    arrayList1.add("throwable");
    Class<int> clazz = int.class;
    arrayList.add(clazz);
    arrayList.add(clazz);
    arrayList.add(clazz);
    arrayList.add(clazz);
    arrayList.add(ILoggingEvent.class);
    arrayList.add(String.class);
    arrayList.add(String.class);
    arrayList.add(String.class);
    arrayList.add(LoggerContextVO.class);
    arrayList.add(clazz);
    arrayList.add(long.class);
    arrayList.add(Map.class);
    arrayList.add(IThrowableProxy.class);
    arrayList.add(Throwable.class);
  }
  
  protected String getDecoratedExpression() {
    String str2 = getExpression();
    String str1 = str2;
    if (!str2.contains("return")) {
      StringBuilder stringBuilder1 = new StringBuilder();
      stringBuilder1.append("return ");
      stringBuilder1.append(str2);
      stringBuilder1.append(";");
      str1 = stringBuilder1.toString();
      StringBuilder stringBuilder2 = new StringBuilder();
      stringBuilder2.append("Adding [return] prefix and a semicolon suffix. Expression becomes [");
      stringBuilder2.append(str1);
      stringBuilder2.append("]");
      addInfo(stringBuilder2.toString());
      addInfo("See also http://logback.qos.ch/codes.html#block");
    } 
    StringBuilder stringBuilder = new StringBuilder();
    stringBuilder.append("import ch.qos.logback.classic.Level;\r\n");
    stringBuilder.append(str1);
    return stringBuilder.toString();
  }
  
  protected String[] getParameterNames() {
    ArrayList<String> arrayList = new ArrayList();
    arrayList.addAll(DEFAULT_PARAM_NAME_LIST);
    for (int i = 0; i < this.matcherList.size(); i++)
      arrayList.add(((Matcher)this.matcherList.get(i)).getName()); 
    return arrayList.<String>toArray(CoreConstants.EMPTY_STRING_ARRAY);
  }
  
  protected Class<?>[] getParameterTypes() {
    ArrayList<Class<?>> arrayList = new ArrayList();
    arrayList.addAll(DEFAULT_PARAM_TYPE_LIST);
    for (int i = 0; i < this.matcherList.size(); i++)
      arrayList.add(Matcher.class); 
    return (Class[])arrayList.<Class<?>[]>toArray((Class<?>[][])CoreConstants.EMPTY_CLASS_ARRAY);
  }
  
  protected Object[] getParameterValues(ILoggingEvent paramILoggingEvent) {
    int k = this.matcherList.size();
    Object[] arrayOfObject = new Object[DEFAULT_PARAM_NAME_LIST.size() + k];
    Integer integer = Level.DEBUG_INTEGER;
    int j = 0;
    arrayOfObject[0] = integer;
    arrayOfObject[1] = Level.INFO_INTEGER;
    arrayOfObject[2] = Level.WARN_INTEGER;
    arrayOfObject[3] = Level.ERROR_INTEGER;
    arrayOfObject[4] = paramILoggingEvent;
    arrayOfObject[5] = paramILoggingEvent.getMessage();
    arrayOfObject[6] = paramILoggingEvent.getFormattedMessage();
    arrayOfObject[7] = paramILoggingEvent.getLoggerName();
    arrayOfObject[8] = paramILoggingEvent.getLoggerContextVO();
    arrayOfObject[9] = paramILoggingEvent.getLevel().toInteger();
    arrayOfObject[10] = Long.valueOf(paramILoggingEvent.getTimeStamp());
    arrayOfObject[11] = paramILoggingEvent.getMDCPropertyMap();
    IThrowableProxy iThrowableProxy = paramILoggingEvent.getThrowableProxy();
    if (iThrowableProxy != null) {
      arrayOfObject[12] = iThrowableProxy;
      if (iThrowableProxy instanceof ThrowableProxy) {
        arrayOfObject[13] = ((ThrowableProxy)iThrowableProxy).getThrowable();
      } else {
        arrayOfObject[13] = null;
      } 
    } else {
      arrayOfObject[12] = null;
      arrayOfObject[13] = null;
    } 
    for (int i = 14; j < k; i++) {
      arrayOfObject[i] = this.matcherList.get(j);
      j++;
    } 
    return arrayOfObject;
  }
}


/* Location:              C:\soft\dex2jar-2.0\MagicAI - AI Art & Anime Art-dex2jar.jar!\ch\qos\logback\classic\boolex\JaninoEventEvaluator.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */