package ch.qos.logback.classic.pattern;

public class ClassNameOnlyAbbreviator implements Abbreviator {
  public String abbreviate(String paramString) {
    int i = paramString.lastIndexOf('.');
    String str = paramString;
    if (i != -1)
      str = paramString.substring(i + 1, paramString.length()); 
    return str;
  }
}


/* Location:              C:\soft\dex2jar-2.0\MagicAI - AI Art & Anime Art-dex2jar.jar!\ch\qos\logback\classic\pattern\ClassNameOnlyAbbreviator.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */