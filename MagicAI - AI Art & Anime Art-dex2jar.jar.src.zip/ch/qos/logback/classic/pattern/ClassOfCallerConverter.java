package ch.qos.logback.classic.pattern;

import ch.qos.logback.classic.spi.ILoggingEvent;

public class ClassOfCallerConverter extends NamedConverter {
  protected String getFullyQualifiedName(ILoggingEvent paramILoggingEvent) {
    StackTraceElement[] arrayOfStackTraceElement = paramILoggingEvent.getCallerData();
    return (arrayOfStackTraceElement != null && arrayOfStackTraceElement.length > 0) ? arrayOfStackTraceElement[0].getClassName() : "?";
  }
}


/* Location:              C:\soft\dex2jar-2.0\MagicAI - AI Art & Anime Art-dex2jar.jar!\ch\qos\logback\classic\pattern\ClassOfCallerConverter.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */