package ch.qos.logback.classic.net;

import ch.qos.logback.classic.spi.ILoggingEvent;
import ch.qos.logback.core.net.AbstractSocketAppender;
import ch.qos.logback.core.spi.PreSerializationTransformer;

public class SocketAppender extends AbstractSocketAppender<ILoggingEvent> {
  private static final PreSerializationTransformer<ILoggingEvent> pst = (PreSerializationTransformer<ILoggingEvent>)new LoggingEventPreSerializationTransformer();
  
  private boolean includeCallerData = false;
  
  public PreSerializationTransformer<ILoggingEvent> getPST() {
    return pst;
  }
  
  protected void postProcessEvent(ILoggingEvent paramILoggingEvent) {
    if (this.includeCallerData)
      paramILoggingEvent.getCallerData(); 
  }
  
  public void setIncludeCallerData(boolean paramBoolean) {
    this.includeCallerData = paramBoolean;
  }
}


/* Location:              C:\soft\dex2jar-2.0\MagicAI - AI Art & Anime Art-dex2jar.jar!\ch\qos\logback\classic\net\SocketAppender.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */