package cn.jzvd;

import android.content.Context;
import android.util.AttributeSet;
import android.view.TextureView;

public class JZTextureView extends TextureView {
  public int currentVideoHeight = 0;
  
  public int currentVideoWidth = 0;
  
  public JZTextureView(Context paramContext) {
    super(paramContext);
  }
  
  public JZTextureView(Context paramContext, AttributeSet paramAttributeSet) {
    super(paramContext, paramAttributeSet);
  }
  
  protected void onMeasure(int paramInt1, int paramInt2) {
    // Byte code:
    //   0: new java/lang/StringBuilder
    //   3: dup
    //   4: invokespecial <init> : ()V
    //   7: astore #21
    //   9: aload #21
    //   11: ldc 'onMeasure  ['
    //   13: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   16: pop
    //   17: aload #21
    //   19: aload_0
    //   20: invokevirtual hashCode : ()I
    //   23: invokevirtual append : (I)Ljava/lang/StringBuilder;
    //   26: pop
    //   27: aload #21
    //   29: ldc '] '
    //   31: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   34: pop
    //   35: ldc 'JZResizeTextureView'
    //   37: aload #21
    //   39: invokevirtual toString : ()Ljava/lang/String;
    //   42: invokestatic i : (Ljava/lang/String;Ljava/lang/String;)I
    //   45: pop
    //   46: aload_0
    //   47: invokevirtual getRotation : ()F
    //   50: f2i
    //   51: istore #19
    //   53: aload_0
    //   54: getfield currentVideoWidth : I
    //   57: istore #16
    //   59: aload_0
    //   60: getfield currentVideoHeight : I
    //   63: istore #17
    //   65: aload_0
    //   66: invokevirtual getParent : ()Landroid/view/ViewParent;
    //   69: checkcast android/view/View
    //   72: invokevirtual getMeasuredHeight : ()I
    //   75: istore #15
    //   77: aload_0
    //   78: invokevirtual getParent : ()Landroid/view/ViewParent;
    //   81: checkcast android/view/View
    //   84: invokevirtual getMeasuredWidth : ()I
    //   87: istore #14
    //   89: iload #17
    //   91: istore #11
    //   93: iload #15
    //   95: istore #13
    //   97: iload #14
    //   99: istore #12
    //   101: iload #14
    //   103: ifeq -> 217
    //   106: iload #17
    //   108: istore #11
    //   110: iload #15
    //   112: istore #13
    //   114: iload #14
    //   116: istore #12
    //   118: iload #15
    //   120: ifeq -> 217
    //   123: iload #17
    //   125: istore #11
    //   127: iload #15
    //   129: istore #13
    //   131: iload #14
    //   133: istore #12
    //   135: iload #16
    //   137: ifeq -> 217
    //   140: iload #17
    //   142: istore #11
    //   144: iload #15
    //   146: istore #13
    //   148: iload #14
    //   150: istore #12
    //   152: iload #17
    //   154: ifeq -> 217
    //   157: iload #17
    //   159: istore #11
    //   161: iload #15
    //   163: istore #13
    //   165: iload #14
    //   167: istore #12
    //   169: getstatic cn/jzvd/Jzvd.VIDEO_IMAGE_DISPLAY_TYPE : I
    //   172: iconst_1
    //   173: if_icmpne -> 217
    //   176: iload #19
    //   178: bipush #90
    //   180: if_icmpeq -> 199
    //   183: iload #15
    //   185: istore #13
    //   187: iload #14
    //   189: istore #12
    //   191: iload #19
    //   193: sipush #270
    //   196: if_icmpne -> 207
    //   199: iload #15
    //   201: istore #12
    //   203: iload #14
    //   205: istore #13
    //   207: iload #16
    //   209: iload #13
    //   211: imul
    //   212: iload #12
    //   214: idiv
    //   215: istore #11
    //   217: iload #19
    //   219: bipush #90
    //   221: if_icmpeq -> 244
    //   224: iload #19
    //   226: sipush #270
    //   229: if_icmpne -> 235
    //   232: goto -> 244
    //   235: iload_1
    //   236: istore #14
    //   238: iload_2
    //   239: istore #15
    //   241: goto -> 250
    //   244: iload_1
    //   245: istore #15
    //   247: iload_2
    //   248: istore #14
    //   250: iload #16
    //   252: iload #14
    //   254: invokestatic getDefaultSize : (II)I
    //   257: istore #17
    //   259: iload #11
    //   261: iload #15
    //   263: invokestatic getDefaultSize : (II)I
    //   266: istore #18
    //   268: iload #17
    //   270: istore_1
    //   271: iload #18
    //   273: istore_2
    //   274: iload #16
    //   276: ifle -> 659
    //   279: iload #17
    //   281: istore_1
    //   282: iload #18
    //   284: istore_2
    //   285: iload #11
    //   287: ifle -> 659
    //   290: iload #14
    //   292: invokestatic getMode : (I)I
    //   295: istore #18
    //   297: iload #14
    //   299: invokestatic getSize : (I)I
    //   302: istore #17
    //   304: iload #15
    //   306: invokestatic getMode : (I)I
    //   309: istore #20
    //   311: iload #15
    //   313: invokestatic getSize : (I)I
    //   316: istore_2
    //   317: new java/lang/StringBuilder
    //   320: dup
    //   321: invokespecial <init> : ()V
    //   324: astore #21
    //   326: aload #21
    //   328: ldc 'widthMeasureSpec  ['
    //   330: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   333: pop
    //   334: aload #21
    //   336: iload #14
    //   338: invokestatic toString : (I)Ljava/lang/String;
    //   341: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   344: pop
    //   345: aload #21
    //   347: ldc ']'
    //   349: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   352: pop
    //   353: ldc 'JZResizeTextureView'
    //   355: aload #21
    //   357: invokevirtual toString : ()Ljava/lang/String;
    //   360: invokestatic i : (Ljava/lang/String;Ljava/lang/String;)I
    //   363: pop
    //   364: new java/lang/StringBuilder
    //   367: dup
    //   368: invokespecial <init> : ()V
    //   371: astore #21
    //   373: aload #21
    //   375: ldc 'heightMeasureSpec ['
    //   377: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   380: pop
    //   381: aload #21
    //   383: iload #15
    //   385: invokestatic toString : (I)Ljava/lang/String;
    //   388: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   391: pop
    //   392: aload #21
    //   394: ldc ']'
    //   396: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   399: pop
    //   400: ldc 'JZResizeTextureView'
    //   402: aload #21
    //   404: invokevirtual toString : ()Ljava/lang/String;
    //   407: invokestatic i : (Ljava/lang/String;Ljava/lang/String;)I
    //   410: pop
    //   411: iload #18
    //   413: ldc 1073741824
    //   415: if_icmpne -> 472
    //   418: iload #20
    //   420: ldc 1073741824
    //   422: if_icmpne -> 472
    //   425: iload #16
    //   427: iload_2
    //   428: imul
    //   429: istore_1
    //   430: iload #17
    //   432: iload #11
    //   434: imul
    //   435: istore #14
    //   437: iload_1
    //   438: iload #14
    //   440: if_icmpge -> 451
    //   443: iload_1
    //   444: iload #11
    //   446: idiv
    //   447: istore_1
    //   448: goto -> 586
    //   451: iload_1
    //   452: iload #14
    //   454: if_icmple -> 466
    //   457: iload #14
    //   459: iload #16
    //   461: idiv
    //   462: istore_1
    //   463: goto -> 519
    //   466: iload #17
    //   468: istore_1
    //   469: goto -> 586
    //   472: iload #18
    //   474: ldc 1073741824
    //   476: if_icmpne -> 527
    //   479: iload #17
    //   481: iload #11
    //   483: imul
    //   484: iload #16
    //   486: idiv
    //   487: istore #14
    //   489: iload #14
    //   491: istore_1
    //   492: iload #20
    //   494: ldc -2147483648
    //   496: if_icmpne -> 519
    //   499: iload #14
    //   501: istore_1
    //   502: iload #14
    //   504: iload_2
    //   505: if_icmple -> 519
    //   508: iload_2
    //   509: iload #16
    //   511: imul
    //   512: iload #11
    //   514: idiv
    //   515: istore_1
    //   516: goto -> 586
    //   519: iload_1
    //   520: istore_2
    //   521: iload #17
    //   523: istore_1
    //   524: goto -> 659
    //   527: iload #20
    //   529: ldc 1073741824
    //   531: if_icmpne -> 589
    //   534: iload_2
    //   535: iload #16
    //   537: imul
    //   538: iload #11
    //   540: idiv
    //   541: istore #15
    //   543: iload #15
    //   545: istore #14
    //   547: iload_2
    //   548: istore_1
    //   549: iload #18
    //   551: ldc -2147483648
    //   553: if_icmpne -> 581
    //   556: iload #15
    //   558: istore #14
    //   560: iload_2
    //   561: istore_1
    //   562: iload #15
    //   564: iload #17
    //   566: if_icmple -> 581
    //   569: iload #17
    //   571: iload #11
    //   573: imul
    //   574: iload #16
    //   576: idiv
    //   577: istore_1
    //   578: goto -> 519
    //   581: iload_1
    //   582: istore_2
    //   583: iload #14
    //   585: istore_1
    //   586: goto -> 659
    //   589: iload #20
    //   591: ldc -2147483648
    //   593: if_icmpne -> 614
    //   596: iload #11
    //   598: iload_2
    //   599: if_icmple -> 614
    //   602: iload_2
    //   603: iload #16
    //   605: imul
    //   606: iload #11
    //   608: idiv
    //   609: istore #15
    //   611: goto -> 621
    //   614: iload #16
    //   616: istore #15
    //   618: iload #11
    //   620: istore_2
    //   621: iload #15
    //   623: istore #14
    //   625: iload_2
    //   626: istore_1
    //   627: iload #18
    //   629: ldc -2147483648
    //   631: if_icmpne -> 581
    //   634: iload #15
    //   636: istore #14
    //   638: iload_2
    //   639: istore_1
    //   640: iload #15
    //   642: iload #17
    //   644: if_icmple -> 581
    //   647: iload #17
    //   649: iload #11
    //   651: imul
    //   652: iload #16
    //   654: idiv
    //   655: istore_1
    //   656: goto -> 519
    //   659: iload #12
    //   661: ifeq -> 806
    //   664: iload #13
    //   666: ifeq -> 806
    //   669: iload #16
    //   671: ifeq -> 806
    //   674: iload #11
    //   676: ifeq -> 806
    //   679: getstatic cn/jzvd/Jzvd.VIDEO_IMAGE_DISPLAY_TYPE : I
    //   682: istore #14
    //   684: iload #14
    //   686: iconst_3
    //   687: if_icmpne -> 696
    //   690: iload #16
    //   692: istore_1
    //   693: goto -> 809
    //   696: iload #14
    //   698: iconst_2
    //   699: if_icmpne -> 806
    //   702: iload #19
    //   704: bipush #90
    //   706: if_icmpeq -> 725
    //   709: iload #13
    //   711: istore #15
    //   713: iload #12
    //   715: istore #14
    //   717: iload #19
    //   719: sipush #270
    //   722: if_icmpne -> 733
    //   725: iload #13
    //   727: istore #14
    //   729: iload #12
    //   731: istore #15
    //   733: iload #11
    //   735: i2d
    //   736: iload #16
    //   738: i2d
    //   739: ddiv
    //   740: dstore_3
    //   741: iload #15
    //   743: i2d
    //   744: dstore #5
    //   746: iload #14
    //   748: i2d
    //   749: dstore #7
    //   751: dload #5
    //   753: dload #7
    //   755: ddiv
    //   756: dstore #9
    //   758: dload_3
    //   759: dload #9
    //   761: dcmpl
    //   762: ifle -> 782
    //   765: dload #7
    //   767: iload_1
    //   768: i2d
    //   769: ddiv
    //   770: iload_2
    //   771: i2d
    //   772: dmul
    //   773: d2i
    //   774: istore #11
    //   776: iload #14
    //   778: istore_1
    //   779: goto -> 809
    //   782: dload_3
    //   783: dload #9
    //   785: dcmpg
    //   786: ifge -> 806
    //   789: dload #5
    //   791: iload_2
    //   792: i2d
    //   793: ddiv
    //   794: iload_1
    //   795: i2d
    //   796: dmul
    //   797: d2i
    //   798: istore_1
    //   799: iload #15
    //   801: istore #11
    //   803: goto -> 809
    //   806: iload_2
    //   807: istore #11
    //   809: aload_0
    //   810: iload_1
    //   811: iload #11
    //   813: invokevirtual setMeasuredDimension : (II)V
    //   816: return
  }
  
  public void setRotation(float paramFloat) {
    if (paramFloat != getRotation()) {
      super.setRotation(paramFloat);
      requestLayout();
    } 
  }
  
  public void setVideoSize(int paramInt1, int paramInt2) {
    if (this.currentVideoWidth != paramInt1 || this.currentVideoHeight != paramInt2) {
      this.currentVideoWidth = paramInt1;
      this.currentVideoHeight = paramInt2;
      requestLayout();
    } 
  }
}


/* Location:              C:\soft\dex2jar-2.0\MagicAI - AI Art & Anime Art-dex2jar.jar!\cn\jzvd\JZTextureView.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */