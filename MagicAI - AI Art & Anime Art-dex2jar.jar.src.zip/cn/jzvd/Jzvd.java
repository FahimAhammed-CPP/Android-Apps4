package cn.jzvd;

import android.content.Context;
import android.media.AudioManager;
import android.provider.Settings;
import android.util.AttributeSet;
import android.util.Log;
import android.view.MotionEvent;
import android.view.TextureView;
import android.view.View;
import android.view.ViewGroup;
import android.view.ViewParent;
import android.view.WindowManager;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;
import android.widget.SeekBar;
import android.widget.TextView;
import android.widget.Toast;
import java.lang.reflect.InvocationTargetException;
import java.util.LinkedList;
import java.util.Timer;
import java.util.TimerTask;

public abstract class Jzvd extends FrameLayout implements View.OnClickListener, SeekBar.OnSeekBarChangeListener, View.OnTouchListener {
  public static LinkedList<ViewGroup> CONTAINER_LIST = new LinkedList<ViewGroup>();
  
  public static Jzvd CURRENT_JZVD;
  
  public static int FULLSCREEN_ORIENTATION;
  
  public static int NORMAL_ORIENTATION;
  
  public static int ON_PLAY_PAUSE_TMP_STATE;
  
  public static float PROGRESS_DRAG_RATE;
  
  public static boolean SAVE_PROGRESS;
  
  public static boolean TOOL_BAR_EXIST = true;
  
  public static int VIDEO_IMAGE_DISPLAY_TYPE;
  
  public static boolean WIFI_TIP_DIALOG_SHOWED;
  
  public static int backUpBufferState;
  
  public static long lastAutoFullscreenTime;
  
  public static AudioManager.OnAudioFocusChangeListener onAudioFocusChangeListener;
  
  protected Timer UPDATE_PROGRESS_TIMER;
  
  protected int blockHeight;
  
  protected int blockIndex;
  
  protected ViewGroup.LayoutParams blockLayoutParams;
  
  protected int blockWidth;
  
  public ViewGroup bottomContainer;
  
  public TextView currentTimeTextView;
  
  public ImageView fullscreenButton;
  
  protected long gobakFullscreenTime = 0L;
  
  protected long gotoFullscreenTime = 0L;
  
  public int heightRatio = 0;
  
  public JZDataSource jzDataSource;
  
  protected Context jzvdContext;
  
  protected AudioManager mAudioManager;
  
  protected boolean mChangeBrightness;
  
  protected boolean mChangePosition;
  
  protected boolean mChangeVolume;
  
  protected long mCurrentPosition;
  
  protected float mDownX;
  
  protected float mDownY;
  
  protected float mGestureDownBrightness;
  
  protected long mGestureDownPosition;
  
  protected int mGestureDownVolume;
  
  protected ProgressTimerTask mProgressTimerTask;
  
  protected int mScreenHeight;
  
  protected int mScreenWidth;
  
  protected long mSeekTimePosition;
  
  protected boolean mTouchingProgressBar;
  
  public JZMediaInterface mediaInterface;
  
  public Class mediaInterfaceClass;
  
  public int positionInList = -1;
  
  public boolean preloading = false;
  
  public SeekBar progressBar;
  
  public int screen = -1;
  
  public long seekToInAdvance = 0L;
  
  public int seekToManulPosition = -1;
  
  public ImageView startButton;
  
  public int state = -1;
  
  public JZTextureView textureView;
  
  public ViewGroup textureViewContainer;
  
  public ViewGroup topContainer;
  
  public TextView totalTimeTextView;
  
  public int videoRotation = 0;
  
  public int widthRatio = 0;
  
  static {
    FULLSCREEN_ORIENTATION = 6;
    NORMAL_ORIENTATION = 1;
    SAVE_PROGRESS = true;
    WIFI_TIP_DIALOG_SHOWED = false;
    VIDEO_IMAGE_DISPLAY_TYPE = 0;
    lastAutoFullscreenTime = 0L;
    ON_PLAY_PAUSE_TMP_STATE = 0;
    backUpBufferState = -1;
    PROGRESS_DRAG_RATE = 1.0F;
    onAudioFocusChangeListener = new AudioManager.OnAudioFocusChangeListener() {
        public void onAudioFocusChange(int param1Int) {
          if (param1Int != -2) {
            if (param1Int != -1)
              return; 
            Jzvd.releaseAllVideos();
            StringBuilder stringBuilder1 = new StringBuilder();
            stringBuilder1.append("AUDIOFOCUS_LOSS [");
            stringBuilder1.append(hashCode());
            stringBuilder1.append("]");
            Log.d("JZVD", stringBuilder1.toString());
            return;
          } 
          try {
            Jzvd jzvd = Jzvd.CURRENT_JZVD;
            if (jzvd != null && jzvd.state == 5)
              jzvd.startButton.performClick(); 
          } catch (IllegalStateException illegalStateException) {
            illegalStateException.printStackTrace();
          } 
          StringBuilder stringBuilder = new StringBuilder();
          stringBuilder.append("AUDIOFOCUS_LOSS_TRANSIENT [");
          stringBuilder.append(hashCode());
          stringBuilder.append("]");
          Log.d("JZVD", stringBuilder.toString());
        }
      };
  }
  
  public Jzvd(Context paramContext) {
    super(paramContext);
    init(paramContext);
  }
  
  public Jzvd(Context paramContext, AttributeSet paramAttributeSet) {
    super(paramContext, paramAttributeSet);
    init(paramContext);
  }
  
  public static boolean backPress() {
    Log.i("JZVD", "backPress");
    if (CONTAINER_LIST.size() != 0) {
      Jzvd jzvd = CURRENT_JZVD;
      if (jzvd != null) {
        jzvd.gotoNormalScreen();
        return true;
      } 
    } 
    if (CONTAINER_LIST.size() == 0) {
      Jzvd jzvd = CURRENT_JZVD;
      if (jzvd != null && jzvd.screen != 0) {
        jzvd.clearFloatScreen();
        return true;
      } 
    } 
    return false;
  }
  
  public static void releaseAllVideos() {
    Log.d("JZVD", "releaseAllVideos");
    Jzvd jzvd = CURRENT_JZVD;
    if (jzvd != null) {
      jzvd.reset();
      CURRENT_JZVD = null;
    } 
    CONTAINER_LIST.clear();
  }
  
  public static void setCurrentJzvd(Jzvd paramJzvd) {
    Jzvd jzvd = CURRENT_JZVD;
    if (jzvd != null)
      jzvd.reset(); 
    CURRENT_JZVD = paramJzvd;
  }
  
  public static void setTextureViewRotation(int paramInt) {
    Jzvd jzvd = CURRENT_JZVD;
    if (jzvd != null) {
      JZTextureView jZTextureView = jzvd.textureView;
      if (jZTextureView != null)
        jZTextureView.setRotation(paramInt); 
    } 
  }
  
  public static void setVideoImageDisplayType(int paramInt) {
    VIDEO_IMAGE_DISPLAY_TYPE = paramInt;
    Jzvd jzvd = CURRENT_JZVD;
    if (jzvd != null) {
      JZTextureView jZTextureView = jzvd.textureView;
      if (jZTextureView != null)
        jZTextureView.requestLayout(); 
    } 
  }
  
  public void addTextureView() {
    StringBuilder stringBuilder = new StringBuilder();
    stringBuilder.append("addTextureView [");
    stringBuilder.append(hashCode());
    stringBuilder.append("] ");
    Log.d("JZVD", stringBuilder.toString());
    JZTextureView jZTextureView = this.textureView;
    if (jZTextureView != null)
      this.textureViewContainer.removeView((View)jZTextureView); 
    jZTextureView = new JZTextureView(getContext().getApplicationContext());
    this.textureView = jZTextureView;
    jZTextureView.setSurfaceTextureListener((TextureView.SurfaceTextureListener)this.mediaInterface);
    FrameLayout.LayoutParams layoutParams = new FrameLayout.LayoutParams(-1, -1, 17);
    this.textureViewContainer.addView((View)this.textureView, (ViewGroup.LayoutParams)layoutParams);
  }
  
  public void cancelProgressTimer() {
    Timer timer = this.UPDATE_PROGRESS_TIMER;
    if (timer != null)
      timer.cancel(); 
    ProgressTimerTask progressTimerTask = this.mProgressTimerTask;
    if (progressTimerTask != null)
      progressTimerTask.cancel(); 
  }
  
  public void changeUrl(JZDataSource paramJZDataSource, long paramLong) {
    this.jzDataSource = paramJZDataSource;
    this.seekToInAdvance = paramLong;
    onStatePreparingChangeUrl();
  }
  
  public void clearFloatScreen() {
    JZUtils.showStatusBar(getContext());
    JZUtils.setRequestedOrientation(getContext(), NORMAL_ORIENTATION);
    JZUtils.showSystemUI(getContext());
    ((ViewGroup)JZUtils.scanForActivity(getContext()).getWindow().getDecorView()).removeView((View)this);
    JZMediaInterface jZMediaInterface = this.mediaInterface;
    if (jZMediaInterface != null)
      jZMediaInterface.release(); 
    CURRENT_JZVD = null;
  }
  
  protected void clickFullscreen() {
    StringBuilder stringBuilder = new StringBuilder();
    stringBuilder.append("onClick fullscreen [");
    stringBuilder.append(hashCode());
    stringBuilder.append("] ");
    Log.i("JZVD", stringBuilder.toString());
    if (this.state == 7)
      return; 
    if (this.screen == 1) {
      backPress();
      return;
    } 
    stringBuilder = new StringBuilder();
    stringBuilder.append("toFullscreenActivity [");
    stringBuilder.append(hashCode());
    stringBuilder.append("] ");
    Log.d("JZVD", stringBuilder.toString());
    gotoFullscreen();
  }
  
  protected void clickStart() {
    StringBuilder stringBuilder = new StringBuilder();
    stringBuilder.append("onClick start [");
    stringBuilder.append(hashCode());
    stringBuilder.append("] ");
    Log.i("JZVD", stringBuilder.toString());
    JZDataSource jZDataSource = this.jzDataSource;
    if (jZDataSource == null || jZDataSource.urlsMap.isEmpty() || this.jzDataSource.getCurrentUrl() == null) {
      Toast.makeText(getContext(), getResources().getString(R.string.no_url), 0).show();
      return;
    } 
    int i = this.state;
    if (i == 0) {
      if (!this.jzDataSource.getCurrentUrl().toString().startsWith("file") && !this.jzDataSource.getCurrentUrl().toString().startsWith("/") && !JZUtils.isWifiConnected(getContext()) && !WIFI_TIP_DIALOG_SHOWED) {
        showWifiDialog();
        return;
      } 
      startVideo();
      return;
    } 
    if (i == 5) {
      StringBuilder stringBuilder1 = new StringBuilder();
      stringBuilder1.append("pauseVideo [");
      stringBuilder1.append(hashCode());
      stringBuilder1.append("] ");
      Log.d("JZVD", stringBuilder1.toString());
      this.mediaInterface.pause();
      onStatePause();
      return;
    } 
    if (i == 6) {
      this.mediaInterface.start();
      onStatePlaying();
      return;
    } 
    if (i == 7)
      startVideo(); 
  }
  
  public void cloneAJzvd(ViewGroup paramViewGroup) {
    try {
      Jzvd jzvd = getClass().getConstructor(new Class[] { Context.class }).newInstance(new Object[] { getContext() });
      jzvd.setId(getId());
      jzvd.setMinimumWidth(this.blockWidth);
      jzvd.setMinimumHeight(this.blockHeight);
      paramViewGroup.addView((View)jzvd, this.blockIndex, this.blockLayoutParams);
      jzvd.setUp(this.jzDataSource.cloneMe(), 0, this.mediaInterfaceClass);
      return;
    } catch (IllegalAccessException illegalAccessException) {
      illegalAccessException.printStackTrace();
      return;
    } catch (InstantiationException instantiationException) {
      instantiationException.printStackTrace();
      return;
    } catch (InvocationTargetException invocationTargetException) {
      invocationTargetException.printStackTrace();
      return;
    } catch (NoSuchMethodException noSuchMethodException) {
      noSuchMethodException.printStackTrace();
      return;
    } 
  }
  
  public void dismissBrightnessDialog() {}
  
  public void dismissProgressDialog() {}
  
  public void dismissVolumeDialog() {}
  
  public Context getApplicationContext() {
    Context context = getContext();
    if (context != null) {
      Context context1 = context.getApplicationContext();
      if (context1 != null)
        return context1; 
    } 
    return context;
  }
  
  public long getCurrentPositionWhenPlaying() {
    int i = this.state;
    long l = 0L;
    if (i == 5 || i == 6 || i == 3)
      try {
        return this.mediaInterface.getCurrentPosition();
      } catch (IllegalStateException illegalStateException) {
        illegalStateException.printStackTrace();
        return 0L;
      }  
    return l;
  }
  
  public long getDuration() {
    try {
      return this.mediaInterface.getDuration();
    } catch (Exception exception) {
      exception.printStackTrace();
      return 0L;
    } 
  }
  
  public abstract int getLayoutId();
  
  public void gotoFullscreen() {
    this.gotoFullscreenTime = System.currentTimeMillis();
    ViewGroup viewGroup = (ViewGroup)getParent();
    this.jzvdContext = viewGroup.getContext();
    this.blockLayoutParams = getLayoutParams();
    this.blockIndex = viewGroup.indexOfChild((View)this);
    this.blockWidth = getWidth();
    this.blockHeight = getHeight();
    viewGroup.removeView((View)this);
    cloneAJzvd(viewGroup);
    CONTAINER_LIST.add(viewGroup);
    ((ViewGroup)JZUtils.scanForActivity(this.jzvdContext).getWindow().getDecorView()).addView((View)this, (ViewGroup.LayoutParams)new FrameLayout.LayoutParams(-1, -1));
    setScreenFullscreen();
    JZUtils.hideStatusBar(this.jzvdContext);
    JZUtils.setRequestedOrientation(this.jzvdContext, FULLSCREEN_ORIENTATION);
    JZUtils.hideSystemUI(this.jzvdContext);
  }
  
  public void gotoNormalCompletion() {
    this.gobakFullscreenTime = System.currentTimeMillis();
    ((ViewGroup)JZUtils.scanForActivity(this.jzvdContext).getWindow().getDecorView()).removeView((View)this);
    this.textureViewContainer.removeView((View)this.textureView);
    ((ViewGroup)CONTAINER_LIST.getLast()).removeViewAt(this.blockIndex);
    ((ViewGroup)CONTAINER_LIST.getLast()).addView((View)this, this.blockIndex, this.blockLayoutParams);
    CONTAINER_LIST.pop();
    setScreenNormal();
    JZUtils.showStatusBar(this.jzvdContext);
    JZUtils.setRequestedOrientation(this.jzvdContext, NORMAL_ORIENTATION);
    JZUtils.showSystemUI(this.jzvdContext);
  }
  
  public void gotoNormalScreen() {
    this.gobakFullscreenTime = System.currentTimeMillis();
    ((ViewGroup)JZUtils.scanForActivity(this.jzvdContext).getWindow().getDecorView()).removeView((View)this);
    ((ViewGroup)CONTAINER_LIST.getLast()).removeViewAt(this.blockIndex);
    ((ViewGroup)CONTAINER_LIST.getLast()).addView((View)this, this.blockIndex, this.blockLayoutParams);
    CONTAINER_LIST.pop();
    setScreenNormal();
    JZUtils.showStatusBar(this.jzvdContext);
    JZUtils.setRequestedOrientation(this.jzvdContext, NORMAL_ORIENTATION);
    JZUtils.showSystemUI(this.jzvdContext);
  }
  
  public void init(Context paramContext) {
    View.inflate(paramContext, getLayoutId(), (ViewGroup)this);
    this.jzvdContext = paramContext;
    this.startButton = (ImageView)findViewById(R.id.start);
    this.fullscreenButton = (ImageView)findViewById(R.id.fullscreen);
    this.progressBar = (SeekBar)findViewById(R.id.bottom_seek_progress);
    this.currentTimeTextView = (TextView)findViewById(R.id.current);
    this.totalTimeTextView = (TextView)findViewById(R.id.total);
    this.bottomContainer = (ViewGroup)findViewById(R.id.layout_bottom);
    this.textureViewContainer = (ViewGroup)findViewById(R.id.surface_container);
    this.topContainer = (ViewGroup)findViewById(R.id.layout_top);
    if (this.startButton == null)
      this.startButton = new ImageView(paramContext); 
    if (this.fullscreenButton == null)
      this.fullscreenButton = new ImageView(paramContext); 
    if (this.progressBar == null)
      this.progressBar = new SeekBar(paramContext); 
    if (this.currentTimeTextView == null)
      this.currentTimeTextView = new TextView(paramContext); 
    if (this.totalTimeTextView == null)
      this.totalTimeTextView = new TextView(paramContext); 
    if (this.bottomContainer == null)
      this.bottomContainer = (ViewGroup)new LinearLayout(paramContext); 
    if (this.textureViewContainer == null)
      this.textureViewContainer = (ViewGroup)new FrameLayout(paramContext); 
    if (this.topContainer == null)
      this.topContainer = (ViewGroup)new RelativeLayout(paramContext); 
    this.startButton.setOnClickListener(this);
    this.fullscreenButton.setOnClickListener(this);
    this.progressBar.setOnSeekBarChangeListener(this);
    this.bottomContainer.setOnClickListener(this);
    this.textureViewContainer.setOnClickListener(this);
    this.textureViewContainer.setOnTouchListener(this);
    this.mScreenWidth = (getContext().getResources().getDisplayMetrics()).widthPixels;
    this.mScreenHeight = (getContext().getResources().getDisplayMetrics()).heightPixels;
    this.state = -1;
  }
  
  public void onClick(View paramView) {
    int i = paramView.getId();
    if (i == R.id.start) {
      clickStart();
      return;
    } 
    if (i == R.id.fullscreen)
      clickFullscreen(); 
  }
  
  public void onCompletion() {
    Runtime.getRuntime().gc();
    StringBuilder stringBuilder = new StringBuilder();
    stringBuilder.append("onAutoCompletion  [");
    stringBuilder.append(hashCode());
    stringBuilder.append("] ");
    Log.i("JZVD", stringBuilder.toString());
    cancelProgressTimer();
    dismissBrightnessDialog();
    dismissProgressDialog();
    dismissVolumeDialog();
    onStateAutoComplete();
    this.mediaInterface.release();
    JZUtils.scanForActivity(getContext()).getWindow().clearFlags(128);
    JZUtils.saveProgress(getContext(), this.jzDataSource.getCurrentUrl(), 0L);
    if (this.screen == 1) {
      if (CONTAINER_LIST.size() == 0) {
        clearFloatScreen();
        return;
      } 
      gotoNormalCompletion();
    } 
  }
  
  public void onError(int paramInt1, int paramInt2) {
    StringBuilder stringBuilder = new StringBuilder();
    stringBuilder.append("onError ");
    stringBuilder.append(paramInt1);
    stringBuilder.append(" - ");
    stringBuilder.append(paramInt2);
    stringBuilder.append(" [");
    stringBuilder.append(hashCode());
    stringBuilder.append("] ");
    Log.e("JZVD", stringBuilder.toString());
    if (paramInt1 != 38 && paramInt2 != -38 && paramInt1 != -38 && paramInt2 != 38 && paramInt2 != -19) {
      onStateError();
      this.mediaInterface.release();
    } 
  }
  
  public void onInfo(int paramInt1, int paramInt2) {
    StringBuilder stringBuilder = new StringBuilder();
    stringBuilder.append("onInfo what - ");
    stringBuilder.append(paramInt1);
    stringBuilder.append(" extra - ");
    stringBuilder.append(paramInt2);
    Log.d("JZVD", stringBuilder.toString());
    if (paramInt1 == 3) {
      Log.d("JZVD", "MEDIA_INFO_VIDEO_RENDERING_START");
      paramInt1 = this.state;
      if (paramInt1 == 4 || paramInt1 == 2 || paramInt1 == 3) {
        onStatePlaying();
        return;
      } 
    } else {
      if (paramInt1 == 701) {
        Log.d("JZVD", "MEDIA_INFO_BUFFERING_START");
        backUpBufferState = this.state;
        setState(3);
        return;
      } 
      if (paramInt1 == 702) {
        Log.d("JZVD", "MEDIA_INFO_BUFFERING_END");
        paramInt1 = backUpBufferState;
        if (paramInt1 != -1) {
          setState(paramInt1);
          backUpBufferState = -1;
        } 
      } 
    } 
  }
  
  protected void onMeasure(int paramInt1, int paramInt2) {
    int i = this.screen;
    if (i == 1 || i == 2) {
      super.onMeasure(paramInt1, paramInt2);
      return;
    } 
    if (this.widthRatio != 0 && this.heightRatio != 0) {
      paramInt2 = View.MeasureSpec.getSize(paramInt1);
      paramInt1 = (int)(paramInt2 * this.heightRatio / this.widthRatio);
      setMeasuredDimension(paramInt2, paramInt1);
      paramInt2 = View.MeasureSpec.makeMeasureSpec(paramInt2, 1073741824);
      paramInt1 = View.MeasureSpec.makeMeasureSpec(paramInt1, 1073741824);
      getChildAt(0).measure(paramInt2, paramInt1);
      return;
    } 
    super.onMeasure(paramInt1, paramInt2);
  }
  
  public void onPrepared() {
    StringBuilder stringBuilder = new StringBuilder();
    stringBuilder.append("onPrepared  [");
    stringBuilder.append(hashCode());
    stringBuilder.append("] ");
    Log.i("JZVD", stringBuilder.toString());
    this.state = 4;
    if (!this.preloading) {
      this.mediaInterface.start();
      this.preloading = false;
    } 
    if (this.jzDataSource.getCurrentUrl().toString().toLowerCase().contains("mp3") || this.jzDataSource.getCurrentUrl().toString().toLowerCase().contains("wma") || this.jzDataSource.getCurrentUrl().toString().toLowerCase().contains("aac") || this.jzDataSource.getCurrentUrl().toString().toLowerCase().contains("m4a") || this.jzDataSource.getCurrentUrl().toString().toLowerCase().contains("wav"))
      onStatePlaying(); 
  }
  
  public void onProgress(int paramInt, long paramLong1, long paramLong2) {
    this.mCurrentPosition = paramLong1;
    if (!this.mTouchingProgressBar) {
      int i = this.seekToManulPosition;
      if (i != -1) {
        if (i > paramInt)
          return; 
        this.seekToManulPosition = -1;
      } else {
        this.progressBar.setProgress(paramInt);
      } 
    } 
    if (paramLong1 != 0L)
      this.currentTimeTextView.setText(JZUtils.stringForTime(paramLong1)); 
    this.totalTimeTextView.setText(JZUtils.stringForTime(paramLong2));
  }
  
  public void onProgressChanged(SeekBar paramSeekBar, int paramInt, boolean paramBoolean) {
    if (paramBoolean) {
      long l = getDuration();
      this.currentTimeTextView.setText(JZUtils.stringForTime(paramInt * l / 100L));
    } 
  }
  
  public void onSeekComplete() {}
  
  public void onStartTrackingTouch(SeekBar paramSeekBar) {
    StringBuilder stringBuilder = new StringBuilder();
    stringBuilder.append("bottomProgress onStartTrackingTouch [");
    stringBuilder.append(hashCode());
    stringBuilder.append("] ");
    Log.i("JZVD", stringBuilder.toString());
    cancelProgressTimer();
    for (ViewParent viewParent = getParent(); viewParent != null; viewParent = viewParent.getParent())
      viewParent.requestDisallowInterceptTouchEvent(true); 
  }
  
  public void onStateAutoComplete() {
    StringBuilder stringBuilder = new StringBuilder();
    stringBuilder.append("onStateAutoComplete  [");
    stringBuilder.append(hashCode());
    stringBuilder.append("] ");
    Log.i("JZVD", stringBuilder.toString());
    this.state = 7;
    cancelProgressTimer();
    this.progressBar.setProgress(100);
    this.currentTimeTextView.setText(this.totalTimeTextView.getText());
  }
  
  public void onStateError() {
    StringBuilder stringBuilder = new StringBuilder();
    stringBuilder.append("onStateError  [");
    stringBuilder.append(hashCode());
    stringBuilder.append("] ");
    Log.i("JZVD", stringBuilder.toString());
    this.state = 8;
    cancelProgressTimer();
  }
  
  public void onStateNormal() {
    StringBuilder stringBuilder = new StringBuilder();
    stringBuilder.append("onStateNormal  [");
    stringBuilder.append(hashCode());
    stringBuilder.append("] ");
    Log.i("JZVD", stringBuilder.toString());
    this.state = 0;
    cancelProgressTimer();
    JZMediaInterface jZMediaInterface = this.mediaInterface;
    if (jZMediaInterface != null)
      jZMediaInterface.release(); 
  }
  
  public void onStatePause() {
    StringBuilder stringBuilder = new StringBuilder();
    stringBuilder.append("onStatePause  [");
    stringBuilder.append(hashCode());
    stringBuilder.append("] ");
    Log.i("JZVD", stringBuilder.toString());
    this.state = 6;
    startProgressTimer();
  }
  
  public void onStatePlaying() {
    StringBuilder stringBuilder = new StringBuilder();
    stringBuilder.append("onStatePlaying  [");
    stringBuilder.append(hashCode());
    stringBuilder.append("] ");
    Log.i("JZVD", stringBuilder.toString());
    if (this.state == 4) {
      Log.d("JZVD", "onStatePlaying:STATE_PREPARED ");
      AudioManager audioManager = (AudioManager)getApplicationContext().getSystemService("audio");
      this.mAudioManager = audioManager;
      audioManager.requestAudioFocus(onAudioFocusChangeListener, 3, 2);
      long l = this.seekToInAdvance;
      if (l != 0L) {
        this.mediaInterface.seekTo(l);
        this.seekToInAdvance = 0L;
      } else {
        l = JZUtils.getSavedProgress(getContext(), this.jzDataSource.getCurrentUrl());
        if (l != 0L)
          this.mediaInterface.seekTo(l); 
      } 
    } 
    this.state = 5;
    startProgressTimer();
  }
  
  public void onStatePreparing() {
    StringBuilder stringBuilder = new StringBuilder();
    stringBuilder.append("onStatePreparing  [");
    stringBuilder.append(hashCode());
    stringBuilder.append("] ");
    Log.i("JZVD", stringBuilder.toString());
    this.state = 1;
    resetProgressAndTime();
  }
  
  public void onStatePreparingChangeUrl() {
    StringBuilder stringBuilder = new StringBuilder();
    stringBuilder.append("onStatePreparingChangeUrl  [");
    stringBuilder.append(hashCode());
    stringBuilder.append("] ");
    Log.i("JZVD", stringBuilder.toString());
    this.state = 2;
    releaseAllVideos();
    startVideo();
  }
  
  public void onStatePreparingPlaying() {
    StringBuilder stringBuilder = new StringBuilder();
    stringBuilder.append("onStatePreparingPlaying  [");
    stringBuilder.append(hashCode());
    stringBuilder.append("] ");
    Log.i("JZVD", stringBuilder.toString());
    this.state = 3;
  }
  
  public void onStopTrackingTouch(SeekBar paramSeekBar) {
    StringBuilder stringBuilder2 = new StringBuilder();
    stringBuilder2.append("bottomProgress onStopTrackingTouch [");
    stringBuilder2.append(hashCode());
    stringBuilder2.append("] ");
    Log.i("JZVD", stringBuilder2.toString());
    startProgressTimer();
    for (ViewParent viewParent = getParent(); viewParent != null; viewParent = viewParent.getParent())
      viewParent.requestDisallowInterceptTouchEvent(false); 
    int i = this.state;
    if (i != 5 && i != 6)
      return; 
    long l = paramSeekBar.getProgress() * getDuration() / 100L;
    this.seekToManulPosition = paramSeekBar.getProgress();
    this.mediaInterface.seekTo(l);
    StringBuilder stringBuilder1 = new StringBuilder();
    stringBuilder1.append("seekTo ");
    stringBuilder1.append(l);
    stringBuilder1.append(" [");
    stringBuilder1.append(hashCode());
    stringBuilder1.append("] ");
    Log.i("JZVD", stringBuilder1.toString());
  }
  
  public boolean onTouch(View paramView, MotionEvent paramMotionEvent) {
    float f1 = paramMotionEvent.getX();
    float f2 = paramMotionEvent.getY();
    if (paramView.getId() == R.id.surface_container) {
      int i = paramMotionEvent.getAction();
      if (i != 0) {
        if (i != 1) {
          if (i == 2)
            touchActionMove(f1, f2); 
        } else {
          touchActionUp();
        } 
      } else {
        touchActionDown(f1, f2);
      } 
    } 
    return false;
  }
  
  public void onVideoSizeChanged(int paramInt1, int paramInt2) {
    StringBuilder stringBuilder = new StringBuilder();
    stringBuilder.append("onVideoSizeChanged  [");
    stringBuilder.append(hashCode());
    stringBuilder.append("] ");
    Log.i("JZVD", stringBuilder.toString());
    JZTextureView jZTextureView = this.textureView;
    if (jZTextureView != null) {
      int i = this.videoRotation;
      if (i != 0)
        jZTextureView.setRotation(i); 
      this.textureView.setVideoSize(paramInt1, paramInt2);
    } 
  }
  
  public void reset() {
    StringBuilder stringBuilder = new StringBuilder();
    stringBuilder.append("reset  [");
    stringBuilder.append(hashCode());
    stringBuilder.append("] ");
    Log.i("JZVD", stringBuilder.toString());
    int i = this.state;
    if (i == 5 || i == 6) {
      long l = getCurrentPositionWhenPlaying();
      JZUtils.saveProgress(getContext(), this.jzDataSource.getCurrentUrl(), l);
    } 
    cancelProgressTimer();
    dismissBrightnessDialog();
    dismissProgressDialog();
    dismissVolumeDialog();
    onStateNormal();
    this.textureViewContainer.removeAllViews();
    ((AudioManager)getApplicationContext().getSystemService("audio")).abandonAudioFocus(onAudioFocusChangeListener);
    JZUtils.scanForActivity(getContext()).getWindow().clearFlags(128);
    JZMediaInterface jZMediaInterface = this.mediaInterface;
    if (jZMediaInterface != null)
      jZMediaInterface.release(); 
  }
  
  public void resetProgressAndTime() {
    this.mCurrentPosition = 0L;
    this.progressBar.setProgress(0);
    this.progressBar.setSecondaryProgress(0);
    this.currentTimeTextView.setText(JZUtils.stringForTime(0L));
    this.totalTimeTextView.setText(JZUtils.stringForTime(0L));
  }
  
  public void setBufferProgress(int paramInt) {
    this.progressBar.setSecondaryProgress(paramInt);
  }
  
  public void setMediaInterface(Class paramClass) {
    reset();
    this.mediaInterfaceClass = paramClass;
  }
  
  public void setScreen(int paramInt) {
    if (paramInt != 0) {
      if (paramInt != 1) {
        if (paramInt != 2)
          return; 
        setScreenTiny();
        return;
      } 
      setScreenFullscreen();
      return;
    } 
    setScreenNormal();
  }
  
  public void setScreenFullscreen() {
    this.screen = 1;
  }
  
  public void setScreenNormal() {
    this.screen = 0;
  }
  
  public void setScreenTiny() {
    this.screen = 2;
  }
  
  public void setState(int paramInt) {
    switch (paramInt) {
      default:
        return;
      case 8:
        onStateError();
        return;
      case 7:
        onStateAutoComplete();
        return;
      case 6:
        onStatePause();
        return;
      case 5:
        onStatePlaying();
        return;
      case 3:
        onStatePreparingPlaying();
        return;
      case 2:
        onStatePreparingChangeUrl();
        return;
      case 1:
        onStatePreparing();
        return;
      case 0:
        break;
    } 
    onStateNormal();
  }
  
  public void setUp(JZDataSource paramJZDataSource, int paramInt) {
    setUp(paramJZDataSource, paramInt, JZMediaSystem.class);
  }
  
  public void setUp(JZDataSource paramJZDataSource, int paramInt, Class paramClass) {
    this.jzDataSource = paramJZDataSource;
    this.screen = paramInt;
    onStateNormal();
    this.mediaInterfaceClass = paramClass;
  }
  
  public void setUp(String paramString1, String paramString2) {
    setUp(new JZDataSource(paramString1, paramString2), 0);
  }
  
  public void showBrightnessDialog(int paramInt) {}
  
  public void showProgressDialog(float paramFloat, String paramString1, long paramLong1, String paramString2, long paramLong2) {}
  
  public void showVolumeDialog(float paramFloat, int paramInt) {}
  
  public void showWifiDialog() {}
  
  public void startProgressTimer() {
    StringBuilder stringBuilder = new StringBuilder();
    stringBuilder.append("startProgressTimer:  [");
    stringBuilder.append(hashCode());
    stringBuilder.append("] ");
    Log.i("JZVD", stringBuilder.toString());
    cancelProgressTimer();
    this.UPDATE_PROGRESS_TIMER = new Timer();
    ProgressTimerTask progressTimerTask = new ProgressTimerTask();
    this.mProgressTimerTask = progressTimerTask;
    this.UPDATE_PROGRESS_TIMER.schedule(progressTimerTask, 0L, 300L);
  }
  
  public void startVideo() {
    StringBuilder stringBuilder = new StringBuilder();
    stringBuilder.append("startVideo [");
    stringBuilder.append(hashCode());
    stringBuilder.append("] ");
    Log.d("JZVD", stringBuilder.toString());
    setCurrentJzvd(this);
    try {
      this.mediaInterface = this.mediaInterfaceClass.getConstructor(new Class[] { Jzvd.class }).newInstance(new Object[] { this });
    } catch (NoSuchMethodException noSuchMethodException) {
      noSuchMethodException.printStackTrace();
    } catch (IllegalAccessException illegalAccessException) {
      illegalAccessException.printStackTrace();
    } catch (InstantiationException instantiationException) {
      instantiationException.printStackTrace();
    } catch (InvocationTargetException invocationTargetException) {
      invocationTargetException.printStackTrace();
    } 
    addTextureView();
    JZUtils.scanForActivity(getContext()).getWindow().addFlags(128);
    onStatePreparing();
  }
  
  public void startVideoAfterPreloading() {
    if (this.state == 4) {
      this.mediaInterface.start();
      return;
    } 
    this.preloading = false;
    startVideo();
  }
  
  protected void touchActionDown(float paramFloat1, float paramFloat2) {
    StringBuilder stringBuilder = new StringBuilder();
    stringBuilder.append("onTouch surfaceContainer actionDown [");
    stringBuilder.append(hashCode());
    stringBuilder.append("] ");
    Log.i("JZVD", stringBuilder.toString());
    this.mTouchingProgressBar = true;
    this.mDownX = paramFloat1;
    this.mDownY = paramFloat2;
    this.mChangeVolume = false;
    this.mChangePosition = false;
    this.mChangeBrightness = false;
  }
  
  protected void touchActionMove(float paramFloat1, float paramFloat2) {
    StringBuilder stringBuilder = new StringBuilder();
    stringBuilder.append("onTouch surfaceContainer actionMove [");
    stringBuilder.append(hashCode());
    stringBuilder.append("] ");
    Log.i("JZVD", stringBuilder.toString());
    paramFloat1 -= this.mDownX;
    paramFloat2 -= this.mDownY;
    float f1 = Math.abs(paramFloat1);
    float f2 = Math.abs(paramFloat2);
    if (this.screen == 1)
      if (this.mDownX <= JZUtils.getScreenWidth(getContext())) {
        if (this.mDownY < JZUtils.getStatusBarHeight(getContext()))
          return; 
        if (!this.mChangePosition && !this.mChangeVolume && !this.mChangeBrightness) {
          int i = f1 cmp 80.0F;
          if (i > 0 || f2 > 80.0F) {
            cancelProgressTimer();
            if (i >= 0) {
              if (this.state != 8) {
                this.mChangePosition = true;
                this.mGestureDownPosition = getCurrentPositionWhenPlaying();
              } 
            } else if (this.mDownX < this.mScreenHeight * 0.5F) {
              this.mChangeBrightness = true;
              f1 = (JZUtils.getWindow(getContext()).getAttributes()).screenBrightness;
              if (f1 < 0.0F) {
                try {
                  this.mGestureDownBrightness = Settings.System.getInt(getContext().getContentResolver(), "screen_brightness");
                  stringBuilder = new StringBuilder();
                  stringBuilder.append("current system brightness: ");
                  stringBuilder.append(this.mGestureDownBrightness);
                  Log.i("JZVD", stringBuilder.toString());
                } catch (android.provider.Settings.SettingNotFoundException settingNotFoundException) {
                  settingNotFoundException.printStackTrace();
                } 
              } else {
                this.mGestureDownBrightness = f1 * 255.0F;
                stringBuilder = new StringBuilder();
                stringBuilder.append("current activity brightness: ");
                stringBuilder.append(this.mGestureDownBrightness);
                Log.i("JZVD", stringBuilder.toString());
              } 
            } else {
              this.mChangeVolume = true;
              this.mGestureDownVolume = this.mAudioManager.getStreamVolume(3);
            } 
          } 
        } 
      } else {
        return;
      }  
    if (this.mChangePosition) {
      long l1 = getDuration();
      if (PROGRESS_DRAG_RATE <= 0.0F) {
        Log.d("JZVD", "error PROGRESS_DRAG_RATE value");
        PROGRESS_DRAG_RATE = 1.0F;
      } 
      long l2 = (int)((float)this.mGestureDownPosition + (float)l1 * paramFloat1 / this.mScreenWidth * PROGRESS_DRAG_RATE);
      this.mSeekTimePosition = l2;
      if (l2 > l1)
        this.mSeekTimePosition = l1; 
      String str1 = JZUtils.stringForTime(this.mSeekTimePosition);
      String str2 = JZUtils.stringForTime(l1);
      showProgressDialog(paramFloat1, str1, this.mSeekTimePosition, str2, l1);
    } 
    paramFloat1 = paramFloat2;
    if (this.mChangeVolume) {
      paramFloat1 = -paramFloat2;
      int i = this.mAudioManager.getStreamMaxVolume(3);
      int j = (int)(i * paramFloat1 * 3.0F / this.mScreenHeight);
      this.mAudioManager.setStreamVolume(3, this.mGestureDownVolume + j, 0);
      i = (int)((this.mGestureDownVolume * 100 / i) + paramFloat1 * 3.0F * 100.0F / this.mScreenHeight);
      showVolumeDialog(-paramFloat1, i);
    } 
    if (this.mChangeBrightness) {
      paramFloat1 = -paramFloat1;
      int i = (int)(paramFloat1 * 255.0F * 3.0F / this.mScreenHeight);
      WindowManager.LayoutParams layoutParams = JZUtils.getWindow(getContext()).getAttributes();
      paramFloat2 = this.mGestureDownBrightness;
      f1 = i;
      if ((paramFloat2 + f1) / 255.0F >= 1.0F) {
        layoutParams.screenBrightness = 1.0F;
      } else if ((paramFloat2 + f1) / 255.0F <= 0.0F) {
        layoutParams.screenBrightness = 0.01F;
      } else {
        layoutParams.screenBrightness = (paramFloat2 + f1) / 255.0F;
      } 
      JZUtils.getWindow(getContext()).setAttributes(layoutParams);
      showBrightnessDialog((int)(this.mGestureDownBrightness * 100.0F / 255.0F + paramFloat1 * 3.0F * 100.0F / this.mScreenHeight));
    } 
  }
  
  protected void touchActionUp() {
    StringBuilder stringBuilder = new StringBuilder();
    stringBuilder.append("onTouch surfaceContainer actionUp [");
    stringBuilder.append(hashCode());
    stringBuilder.append("] ");
    Log.i("JZVD", stringBuilder.toString());
    this.mTouchingProgressBar = false;
    dismissProgressDialog();
    dismissVolumeDialog();
    dismissBrightnessDialog();
    if (this.mChangePosition) {
      this.mediaInterface.seekTo(this.mSeekTimePosition);
      long l2 = getDuration();
      long l3 = this.mSeekTimePosition;
      long l1 = l2;
      if (l2 == 0L)
        l1 = 1L; 
      int i = (int)(l3 * 100L / l1);
      this.progressBar.setProgress(i);
    } 
    startProgressTimer();
  }
  
  public class ProgressTimerTask extends TimerTask {
    public void run() {
      Jzvd jzvd = Jzvd.this;
      int i = jzvd.state;
      if (i == 5 || i == 6 || i == 3)
        jzvd.post((Runnable)new Jzvd$ProgressTimerTask$.ExternalSyntheticLambda0(this)); 
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\MagicAI - AI Art & Anime Art-dex2jar.jar!\cn\jzvd\Jzvd.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */