package com.applovin.adview;

import android.content.Context;
import android.graphics.Color;
import android.util.AttributeSet;
import android.util.DisplayMetrics;
import android.util.TypedValue;
import android.view.View;
import android.widget.RelativeLayout;
import android.widget.TextView;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import com.applovin.impl.adview.b;
import com.applovin.impl.sdk.y;
import com.applovin.sdk.AppLovinAd;
import com.applovin.sdk.AppLovinAdClickListener;
import com.applovin.sdk.AppLovinAdDisplayListener;
import com.applovin.sdk.AppLovinAdLoadListener;
import com.applovin.sdk.AppLovinAdSize;
import com.applovin.sdk.AppLovinSdk;

public class AppLovinAdView extends RelativeLayout {
  public static final String NAMESPACE = "http://schemas.applovin.com/android/1.0";
  
  private b a;
  
  public AppLovinAdView(Context paramContext, AttributeSet paramAttributeSet) {
    this(paramContext, paramAttributeSet, 0);
  }
  
  public AppLovinAdView(Context paramContext, AttributeSet paramAttributeSet, int paramInt) {
    super(paramContext, paramAttributeSet, paramInt);
    a(null, null, null, paramContext, paramAttributeSet);
  }
  
  public AppLovinAdView(AppLovinAdSize paramAppLovinAdSize, Context paramContext) {
    this(paramAppLovinAdSize, (String)null, paramContext);
  }
  
  public AppLovinAdView(AppLovinAdSize paramAppLovinAdSize, String paramString, Context paramContext) {
    super(paramContext);
    a(paramAppLovinAdSize, paramString, null, paramContext, null);
  }
  
  public AppLovinAdView(AppLovinSdk paramAppLovinSdk, AppLovinAdSize paramAppLovinAdSize, Context paramContext) {
    this(paramAppLovinSdk, paramAppLovinAdSize, null, paramContext);
  }
  
  public AppLovinAdView(AppLovinSdk paramAppLovinSdk, AppLovinAdSize paramAppLovinAdSize, String paramString, Context paramContext) {
    super(paramContext.getApplicationContext());
    a(paramAppLovinAdSize, paramString, paramAppLovinSdk, paramContext, null);
  }
  
  private void a(AttributeSet paramAttributeSet, Context paramContext) {
    DisplayMetrics displayMetrics = paramContext.getResources().getDisplayMetrics();
    int i = displayMetrics.widthPixels;
    int j = (int)TypedValue.applyDimension(1, 50.0F, displayMetrics);
    TextView textView = new TextView(paramContext);
    textView.setBackgroundColor(Color.rgb(220, 220, 220));
    textView.setTextColor(-16777216);
    textView.setText("AppLovin Ad");
    textView.setGravity(17);
    addView((View)textView, i, j);
  }
  
  private void a(AppLovinAdSize paramAppLovinAdSize, String paramString, AppLovinSdk paramAppLovinSdk, Context paramContext, AttributeSet paramAttributeSet) {
    if (!isInEditMode()) {
      b b1 = new b();
      this.a = b1;
      b1.a(this, paramContext, paramAppLovinAdSize, paramString, paramAppLovinSdk, paramAttributeSet);
      return;
    } 
    a(paramAttributeSet, paramContext);
  }
  
  public void destroy() {
    b b1 = this.a;
    if (b1 != null)
      b1.f(); 
  }
  
  public b getController() {
    return this.a;
  }
  
  public AppLovinAdSize getSize() {
    b b1 = this.a;
    return (b1 != null) ? b1.b() : null;
  }
  
  public String getZoneId() {
    b b1 = this.a;
    return (b1 != null) ? b1.c() : null;
  }
  
  public void loadNextAd() {
    b b1 = this.a;
    if (b1 != null) {
      b1.a();
      return;
    } 
    y.g("AppLovinSdk", "Unable to load next ad: AppLovinAdView is not initialized.");
  }
  
  protected void onAttachedToWindow() {
    super.onAttachedToWindow();
    b b1 = this.a;
    if (b1 != null)
      b1.i(); 
  }
  
  protected void onDetachedFromWindow() {
    b b1 = this.a;
    if (b1 != null)
      b1.j(); 
    super.onDetachedFromWindow();
  }
  
  protected void onMeasure(int paramInt1, int paramInt2) {
    if (!true) {
      setMeasuredDimension(0, 0);
      return;
    } 
    super.onMeasure(paramInt1, paramInt2);
  }
  
  public void pause() {
    b b1 = this.a;
    if (b1 != null)
      b1.d(); 
  }
  
  public void renderAd(AppLovinAd paramAppLovinAd) {
    b b1 = this.a;
    if (b1 != null)
      b1.a(paramAppLovinAd); 
  }
  
  public void resume() {
    b b1 = this.a;
    if (b1 != null)
      b1.e(); 
  }
  
  public void setAdClickListener(AppLovinAdClickListener paramAppLovinAdClickListener) {
    b b1 = this.a;
    if (b1 != null)
      b1.a(paramAppLovinAdClickListener); 
  }
  
  public void setAdDisplayListener(AppLovinAdDisplayListener paramAppLovinAdDisplayListener) {
    b b1 = this.a;
    if (b1 != null)
      b1.a(paramAppLovinAdDisplayListener); 
  }
  
  public void setAdLoadListener(AppLovinAdLoadListener paramAppLovinAdLoadListener) {
    b b1 = this.a;
    if (b1 != null)
      b1.a(paramAppLovinAdLoadListener); 
  }
  
  public void setAdViewEventListener(AppLovinAdViewEventListener paramAppLovinAdViewEventListener) {
    b b1 = this.a;
    if (b1 != null)
      b1.a(paramAppLovinAdViewEventListener); 
  }
  
  public void setExtraInfo(@NonNull String paramString, @Nullable Object paramObject) {
    if (paramString != null) {
      b b1 = this.a;
      if (b1 != null)
        b1.a(paramString, paramObject); 
      return;
    } 
    throw new IllegalArgumentException("No key specified");
  }
  
  public String toString() {
    StringBuilder stringBuilder = new StringBuilder();
    stringBuilder.append("AppLovinAdView{zoneId='");
    stringBuilder.append(getZoneId());
    stringBuilder.append("\", size=");
    stringBuilder.append(getSize());
    stringBuilder.append('}');
    return stringBuilder.toString();
  }
}


/* Location:              C:\soft\dex2jar-2.0\MagicAI - AI Art & Anime Art-dex2jar.jar!\com\applovin\adview\AppLovinAdView.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */