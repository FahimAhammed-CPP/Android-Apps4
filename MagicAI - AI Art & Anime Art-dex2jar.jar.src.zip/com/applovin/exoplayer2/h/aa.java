package com.applovin.exoplayer2.h;

import android.net.Uri;
import androidx.annotation.Nullable;
import com.applovin.exoplayer2.ab;
import com.applovin.exoplayer2.ba;
import com.applovin.exoplayer2.l.a;

public final class aa extends ba {
  private static final Object c = new Object();
  
  private static final ab d = (new ab.b()).a("SinglePeriodTimeline").a(Uri.EMPTY).a();
  
  private final long e;
  
  private final long f;
  
  private final long g;
  
  private final long h;
  
  private final long i;
  
  private final long j;
  
  private final long k;
  
  private final boolean l;
  
  private final boolean m;
  
  private final boolean n;
  
  @Nullable
  private final Object o;
  
  @Nullable
  private final ab p;
  
  @Nullable
  private final ab.e q;
  
  public aa(long paramLong1, long paramLong2, long paramLong3, long paramLong4, long paramLong5, long paramLong6, long paramLong7, boolean paramBoolean1, boolean paramBoolean2, boolean paramBoolean3, @Nullable Object paramObject, ab paramab, @Nullable ab.e parame) {
    this.e = paramLong1;
    this.f = paramLong2;
    this.g = paramLong3;
    this.h = paramLong4;
    this.i = paramLong5;
    this.j = paramLong6;
    this.k = paramLong7;
    this.l = paramBoolean1;
    this.m = paramBoolean2;
    this.n = paramBoolean3;
    this.o = paramObject;
    this.p = (ab)a.b(paramab);
    this.q = parame;
  }
  
  public aa(long paramLong1, long paramLong2, long paramLong3, long paramLong4, boolean paramBoolean1, boolean paramBoolean2, boolean paramBoolean3, @Nullable Object paramObject, ab paramab) {
    this(-9223372036854775807L, -9223372036854775807L, -9223372036854775807L, paramLong1, paramLong2, paramLong3, paramLong4, paramBoolean1, paramBoolean2, false, paramObject, paramab, e1);
  }
  
  public aa(long paramLong, boolean paramBoolean1, boolean paramBoolean2, boolean paramBoolean3, @Nullable Object paramObject, ab paramab) {
    this(paramLong, paramLong, 0L, 0L, paramBoolean1, paramBoolean2, paramBoolean3, paramObject, paramab);
  }
  
  public ba.a a(int paramInt, ba.a parama, boolean paramBoolean) {
    Object object;
    a.a(paramInt, 0, 1);
    if (paramBoolean) {
      object = c;
    } else {
      object = null;
    } 
    return parama.a(null, object, 0, this.h, -this.j);
  }
  
  public ba.c a(int paramInt, ba.c paramc, long paramLong) {
    a.a(paramInt, 0, 1);
    long l2 = this.k;
    boolean bool = this.m;
    long l1 = l2;
    if (bool) {
      l1 = l2;
      if (!this.n) {
        l1 = l2;
        if (paramLong != 0L) {
          long l = this.i;
          if (l == -9223372036854775807L) {
            l1 = -9223372036854775807L;
            return paramc.a(ba.c.a, this.p, this.o, this.e, this.f, this.g, this.l, bool, this.q, l1, this.i, 0, 0, this.j);
          } 
          paramLong = l2 + paramLong;
          l1 = paramLong;
          if (paramLong > l) {
            l1 = -9223372036854775807L;
            return paramc.a(ba.c.a, this.p, this.o, this.e, this.f, this.g, this.l, bool, this.q, l1, this.i, 0, 0, this.j);
          } 
        } 
      } 
    } 
    return paramc.a(ba.c.a, this.p, this.o, this.e, this.f, this.g, this.l, bool, this.q, l1, this.i, 0, 0, this.j);
  }
  
  public Object a(int paramInt) {
    a.a(paramInt, 0, 1);
    return c;
  }
  
  public int b() {
    return 1;
  }
  
  public int c() {
    return 1;
  }
  
  public int c(Object paramObject) {
    return c.equals(paramObject) ? 0 : -1;
  }
}


/* Location:              C:\soft\dex2jar-2.0\MagicAI - AI Art & Anime Art-dex2jar.jar!\com\applovin\exoplayer2\h\aa.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */