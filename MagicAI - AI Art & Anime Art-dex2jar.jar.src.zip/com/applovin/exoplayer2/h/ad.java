package com.applovin.exoplayer2.h;

import android.os.Bundle;
import androidx.annotation.Nullable;
import com.applovin.exoplayer2.common.a.s;
import com.applovin.exoplayer2.g;
import com.applovin.exoplayer2.l.c;
import java.util.Arrays;
import java.util.List;

public final class ad implements g {
  public static final ad a = new ad(new ac[0]);
  
  public static final g.a<ad> c = (g.a<ad>)new ad$.ExternalSyntheticLambda0();
  
  public final int b;
  
  private final ac[] d;
  
  private int e;
  
  public ad(ac... paramVarArgs) {
    this.d = paramVarArgs;
    this.b = paramVarArgs.length;
  }
  
  private static String b(int paramInt) {
    return Integer.toString(paramInt, 36);
  }
  
  public int a(ac paramac) {
    for (int i = 0; i < this.b; i++) {
      if (this.d[i] == paramac)
        return i; 
    } 
    return -1;
  }
  
  public ac a(int paramInt) {
    return this.d[paramInt];
  }
  
  public boolean a() {
    return (this.b == 0);
  }
  
  public boolean equals(@Nullable Object paramObject) {
    if (this == paramObject)
      return true; 
    if (paramObject != null) {
      if (ad.class != paramObject.getClass())
        return false; 
      paramObject = paramObject;
      return (this.b == ((ad)paramObject).b && Arrays.equals((Object[])this.d, (Object[])((ad)paramObject).d));
    } 
    return false;
  }
  
  public int hashCode() {
    if (this.e == 0)
      this.e = Arrays.hashCode((Object[])this.d); 
    return this.e;
  }
}


/* Location:              C:\soft\dex2jar-2.0\MagicAI - AI Art & Anime Art-dex2jar.jar!\com\applovin\exoplayer2\h\ad.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */