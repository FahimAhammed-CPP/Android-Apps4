package com.applovin.exoplayer2.g.e;

import android.os.Parcel;
import android.os.Parcelable;
import androidx.annotation.Nullable;
import com.applovin.exoplayer2.l.ai;
import java.util.Arrays;

public final class c extends h {
  public static final Parcelable.Creator<c> CREATOR = new Parcelable.Creator<c>() {
      public c a(Parcel param1Parcel) {
        return new c(param1Parcel);
      }
      
      public c[] a(int param1Int) {
        return new c[param1Int];
      }
    };
  
  public final String a;
  
  public final int b;
  
  public final int c;
  
  public final long d;
  
  public final long e;
  
  private final h[] g;
  
  c(Parcel paramParcel) {
    super("CHAP");
    this.a = (String)ai.a(paramParcel.readString());
    this.b = paramParcel.readInt();
    this.c = paramParcel.readInt();
    this.d = paramParcel.readLong();
    this.e = paramParcel.readLong();
    int j = paramParcel.readInt();
    this.g = new h[j];
    for (int i = 0; i < j; i++)
      this.g[i] = (h)paramParcel.readParcelable(h.class.getClassLoader()); 
  }
  
  public c(String paramString, int paramInt1, int paramInt2, long paramLong1, long paramLong2, h[] paramArrayOfh) {
    super("CHAP");
    this.a = paramString;
    this.b = paramInt1;
    this.c = paramInt2;
    this.d = paramLong1;
    this.e = paramLong2;
    this.g = paramArrayOfh;
  }
  
  public int describeContents() {
    return 0;
  }
  
  public boolean equals(@Nullable Object paramObject) {
    if (this == paramObject)
      return true; 
    if (paramObject != null) {
      if (c.class != paramObject.getClass())
        return false; 
      paramObject = paramObject;
      return (this.b == ((c)paramObject).b && this.c == ((c)paramObject).c && this.d == ((c)paramObject).d && this.e == ((c)paramObject).e && ai.a(this.a, ((c)paramObject).a) && Arrays.equals((Object[])this.g, (Object[])((c)paramObject).g));
    } 
    return false;
  }
  
  public int hashCode() {
    byte b;
    int i = this.b;
    int j = this.c;
    int k = (int)this.d;
    int m = (int)this.e;
    String str = this.a;
    if (str != null) {
      b = str.hashCode();
    } else {
      b = 0;
    } 
    return ((((527 + i) * 31 + j) * 31 + k) * 31 + m) * 31 + b;
  }
  
  public void writeToParcel(Parcel paramParcel, int paramInt) {
    paramParcel.writeString(this.a);
    paramParcel.writeInt(this.b);
    paramParcel.writeInt(this.c);
    paramParcel.writeLong(this.d);
    paramParcel.writeLong(this.e);
    paramParcel.writeInt(this.g.length);
    h[] arrayOfH = this.g;
    int i = arrayOfH.length;
    for (paramInt = 0; paramInt < i; paramInt++)
      paramParcel.writeParcelable((Parcelable)arrayOfH[paramInt], 0); 
  }
}


/* Location:              C:\soft\dex2jar-2.0\MagicAI - AI Art & Anime Art-dex2jar.jar!\com\applovin\exoplayer2\g\e\c.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */