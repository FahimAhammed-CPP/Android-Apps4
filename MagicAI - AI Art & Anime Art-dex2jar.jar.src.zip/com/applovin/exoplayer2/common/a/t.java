package com.applovin.exoplayer2.common.a;

import java.util.Collection;
import java.util.Comparator;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import org.checkerframework.checker.nullness.compatqual.NullableDecl;

public class t<K, V> extends v<K, V> implements z<K, V> {
  t(u<K, s<V>> paramu, int paramInt) {
    super(paramu, paramInt);
  }
  
  public static <K, V> t<K, V> a() {
    return (t<K, V>)o.a;
  }
  
  static <K, V> t<K, V> a(Collection<? extends Map.Entry<? extends K, ? extends Collection<? extends V>>> paramCollection, @NullableDecl Comparator<? super V> paramComparator) {
    if (paramCollection.isEmpty())
      return a(); 
    u.a a = new u.a(paramCollection.size());
    Iterator<? extends Map.Entry<? extends K, ? extends Collection<? extends V>>> iterator = paramCollection.iterator();
    int i = 0;
    while (iterator.hasNext()) {
      s s;
      Map.Entry entry = iterator.next();
      Object object = entry.getKey();
      Collection collection = (Collection)entry.getValue();
      if (paramComparator == null) {
        s = s.a(collection);
      } else {
        s = s.a(paramComparator, (Iterable)s);
      } 
      if (!s.isEmpty()) {
        a.a(object, s);
        i += s.size();
      } 
    } 
    return new t<K, V>(a.a(), i);
  }
  
  public static <K, V> a<K, V> c() {
    return new a<K, V>();
  }
  
  public s<V> c(@NullableDecl K paramK) {
    s<V> s2 = (s)this.b.get(paramK);
    s<V> s1 = s2;
    if (s2 == null)
      s1 = s.g(); 
    return s1;
  }
  
  public static final class a<K, V> extends v.a<K, V> {
    public a<K, V> a(K param1K, Iterable<? extends V> param1Iterable) {
      super.b(param1K, param1Iterable);
      return this;
    }
    
    public a<K, V> a(K param1K, V... param1VarArgs) {
      super.b(param1K, (Object[])param1VarArgs);
      return this;
    }
    
    public t<K, V> a() {
      return (t<K, V>)super.b();
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\MagicAI - AI Art & Anime Art-dex2jar.jar!\com\applovin\exoplayer2\common\a\t.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */