package com.applovin.exoplayer2.e.i;

import com.applovin.exoplayer2.e.a;
import com.applovin.exoplayer2.e.i;
import com.applovin.exoplayer2.l.ag;
import com.applovin.exoplayer2.l.ai;
import com.applovin.exoplayer2.l.y;
import java.io.IOException;

final class aa extends a {
  public aa(ag paramag, long paramLong1, long paramLong2, int paramInt1, int paramInt2) {
    super((a.d)new a.b(), new a(paramInt1, paramag, paramInt2), paramLong1, 0L, paramLong1 + 1L, 0L, paramLong2, 188L, 940);
  }
  
  private static final class a implements a.f {
    private final ag a;
    
    private final y b;
    
    private final int c;
    
    private final int d;
    
    public a(int param1Int1, ag param1ag, int param1Int2) {
      this.c = param1Int1;
      this.a = param1ag;
      this.d = param1Int2;
      this.b = new y();
    }
    
    private a.e a(y param1y, long param1Long1, long param1Long2) {
      int i = param1y.b();
      long l3 = -1L;
      long l2 = -1L;
      long l1;
      for (l1 = -9223372036854775807L; param1y.a() >= 188; l1 = l4) {
        int j = ae.a(param1y.d(), param1y.c(), i);
        int k = j + 188;
        if (k > i)
          break; 
        l3 = ae.a(param1y, j, this.c);
        long l5 = l2;
        long l4 = l1;
        if (l3 != -9223372036854775807L) {
          l4 = this.a.b(l3);
          if (l4 > param1Long1)
            return (l1 == -9223372036854775807L) ? a.e.a(l4, param1Long2) : a.e.a(param1Long2 + l2); 
          if (100000L + l4 > param1Long1)
            return a.e.a(param1Long2 + j); 
          l5 = j;
        } 
        param1y.d(k);
        l3 = k;
        l2 = l5;
      } 
      return (l1 != -9223372036854775807L) ? a.e.b(l1, param1Long2 + l3) : a.e.a;
    }
    
    public a.e a(i param1i, long param1Long) throws IOException {
      long l = param1i.c();
      int j = (int)Math.min(this.d, param1i.d() - l);
      this.b.a(j);
      param1i.d(this.b.d(), 0, j);
      return a(this.b, param1Long, l);
    }
    
    public void a() {
      this.b.a(ai.f);
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\MagicAI - AI Art & Anime Art-dex2jar.jar!\com\applovin\exoplayer2\e\i\aa.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */