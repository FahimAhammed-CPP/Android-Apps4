package com.applovin.array.apphub.aidl;

import android.os.Binder;
import android.os.IBinder;
import android.os.IInterface;
import android.os.Parcel;
import android.os.RemoteException;

public interface IAppHubDirectDownloadServiceCallback extends IInterface {
  void onAppDetailsDismissed(String paramString) throws RemoteException;
  
  void onAppDetailsShown(String paramString) throws RemoteException;
  
  void onDownloadStarted(String paramString) throws RemoteException;
  
  void onError(String paramString1, String paramString2) throws RemoteException;
  
  public static class Default implements IAppHubDirectDownloadServiceCallback {
    public IBinder asBinder() {
      return null;
    }
    
    public void onAppDetailsDismissed(String param1String) throws RemoteException {}
    
    public void onAppDetailsShown(String param1String) throws RemoteException {}
    
    public void onDownloadStarted(String param1String) throws RemoteException {}
    
    public void onError(String param1String1, String param1String2) throws RemoteException {}
  }
  
  public static abstract class Stub extends Binder implements IAppHubDirectDownloadServiceCallback {
    private static final String DESCRIPTOR = "com.applovin.array.apphub.aidl.IAppHubDirectDownloadServiceCallback";
    
    static final int TRANSACTION_onAppDetailsDismissed = 2;
    
    static final int TRANSACTION_onAppDetailsShown = 1;
    
    static final int TRANSACTION_onDownloadStarted = 3;
    
    static final int TRANSACTION_onError = 4;
    
    public Stub() {
      attachInterface(this, "com.applovin.array.apphub.aidl.IAppHubDirectDownloadServiceCallback");
    }
    
    public static IAppHubDirectDownloadServiceCallback asInterface(IBinder param1IBinder) {
      if (param1IBinder == null)
        return null; 
      IInterface iInterface = param1IBinder.queryLocalInterface("com.applovin.array.apphub.aidl.IAppHubDirectDownloadServiceCallback");
      return (iInterface != null && iInterface instanceof IAppHubDirectDownloadServiceCallback) ? (IAppHubDirectDownloadServiceCallback)iInterface : new Proxy(param1IBinder);
    }
    
    public static IAppHubDirectDownloadServiceCallback getDefaultImpl() {
      return Proxy.sDefaultImpl;
    }
    
    public static boolean setDefaultImpl(IAppHubDirectDownloadServiceCallback param1IAppHubDirectDownloadServiceCallback) {
      if (Proxy.sDefaultImpl == null) {
        if (param1IAppHubDirectDownloadServiceCallback != null) {
          Proxy.sDefaultImpl = param1IAppHubDirectDownloadServiceCallback;
          return true;
        } 
        return false;
      } 
      throw new IllegalStateException("setDefaultImpl() called twice");
    }
    
    public IBinder asBinder() {
      return (IBinder)this;
    }
    
    public boolean onTransact(int param1Int1, Parcel param1Parcel1, Parcel param1Parcel2, int param1Int2) throws RemoteException {
      if (param1Int1 != 1) {
        if (param1Int1 != 2) {
          if (param1Int1 != 3) {
            if (param1Int1 != 4) {
              if (param1Int1 != 1598968902)
                return super.onTransact(param1Int1, param1Parcel1, param1Parcel2, param1Int2); 
              param1Parcel2.writeString("com.applovin.array.apphub.aidl.IAppHubDirectDownloadServiceCallback");
              return true;
            } 
            param1Parcel1.enforceInterface("com.applovin.array.apphub.aidl.IAppHubDirectDownloadServiceCallback");
            onError(param1Parcel1.readString(), param1Parcel1.readString());
            return true;
          } 
          param1Parcel1.enforceInterface("com.applovin.array.apphub.aidl.IAppHubDirectDownloadServiceCallback");
          onDownloadStarted(param1Parcel1.readString());
          return true;
        } 
        param1Parcel1.enforceInterface("com.applovin.array.apphub.aidl.IAppHubDirectDownloadServiceCallback");
        onAppDetailsDismissed(param1Parcel1.readString());
        return true;
      } 
      param1Parcel1.enforceInterface("com.applovin.array.apphub.aidl.IAppHubDirectDownloadServiceCallback");
      onAppDetailsShown(param1Parcel1.readString());
      return true;
    }
    
    private static class Proxy implements IAppHubDirectDownloadServiceCallback {
      public static IAppHubDirectDownloadServiceCallback sDefaultImpl;
      
      private IBinder mRemote;
      
      Proxy(IBinder param2IBinder) {
        this.mRemote = param2IBinder;
      }
      
      public IBinder asBinder() {
        return this.mRemote;
      }
      
      public String getInterfaceDescriptor() {
        return "com.applovin.array.apphub.aidl.IAppHubDirectDownloadServiceCallback";
      }
      
      public void onAppDetailsDismissed(String param2String) throws RemoteException {
        Parcel parcel = Parcel.obtain();
        try {
          parcel.writeInterfaceToken("com.applovin.array.apphub.aidl.IAppHubDirectDownloadServiceCallback");
          parcel.writeString(param2String);
          if (!this.mRemote.transact(2, parcel, null, 1) && IAppHubDirectDownloadServiceCallback.Stub.getDefaultImpl() != null) {
            IAppHubDirectDownloadServiceCallback.Stub.getDefaultImpl().onAppDetailsDismissed(param2String);
            return;
          } 
          return;
        } finally {
          parcel.recycle();
        } 
      }
      
      public void onAppDetailsShown(String param2String) throws RemoteException {
        Parcel parcel = Parcel.obtain();
        try {
          parcel.writeInterfaceToken("com.applovin.array.apphub.aidl.IAppHubDirectDownloadServiceCallback");
          parcel.writeString(param2String);
          if (!this.mRemote.transact(1, parcel, null, 1) && IAppHubDirectDownloadServiceCallback.Stub.getDefaultImpl() != null) {
            IAppHubDirectDownloadServiceCallback.Stub.getDefaultImpl().onAppDetailsShown(param2String);
            return;
          } 
          return;
        } finally {
          parcel.recycle();
        } 
      }
      
      public void onDownloadStarted(String param2String) throws RemoteException {
        Parcel parcel = Parcel.obtain();
        try {
          parcel.writeInterfaceToken("com.applovin.array.apphub.aidl.IAppHubDirectDownloadServiceCallback");
          parcel.writeString(param2String);
          if (!this.mRemote.transact(3, parcel, null, 1) && IAppHubDirectDownloadServiceCallback.Stub.getDefaultImpl() != null) {
            IAppHubDirectDownloadServiceCallback.Stub.getDefaultImpl().onDownloadStarted(param2String);
            return;
          } 
          return;
        } finally {
          parcel.recycle();
        } 
      }
      
      public void onError(String param2String1, String param2String2) throws RemoteException {
        Parcel parcel = Parcel.obtain();
        try {
          parcel.writeInterfaceToken("com.applovin.array.apphub.aidl.IAppHubDirectDownloadServiceCallback");
          parcel.writeString(param2String1);
          parcel.writeString(param2String2);
          if (!this.mRemote.transact(4, parcel, null, 1) && IAppHubDirectDownloadServiceCallback.Stub.getDefaultImpl() != null) {
            IAppHubDirectDownloadServiceCallback.Stub.getDefaultImpl().onError(param2String1, param2String2);
            return;
          } 
          return;
        } finally {
          parcel.recycle();
        } 
      }
    }
  }
  
  private static class Proxy implements IAppHubDirectDownloadServiceCallback {
    public static IAppHubDirectDownloadServiceCallback sDefaultImpl;
    
    private IBinder mRemote;
    
    Proxy(IBinder param1IBinder) {
      this.mRemote = param1IBinder;
    }
    
    public IBinder asBinder() {
      return this.mRemote;
    }
    
    public String getInterfaceDescriptor() {
      return "com.applovin.array.apphub.aidl.IAppHubDirectDownloadServiceCallback";
    }
    
    public void onAppDetailsDismissed(String param1String) throws RemoteException {
      Parcel parcel = Parcel.obtain();
      try {
        parcel.writeInterfaceToken("com.applovin.array.apphub.aidl.IAppHubDirectDownloadServiceCallback");
        parcel.writeString(param1String);
        if (!this.mRemote.transact(2, parcel, null, 1) && IAppHubDirectDownloadServiceCallback.Stub.getDefaultImpl() != null) {
          IAppHubDirectDownloadServiceCallback.Stub.getDefaultImpl().onAppDetailsDismissed(param1String);
          return;
        } 
        return;
      } finally {
        parcel.recycle();
      } 
    }
    
    public void onAppDetailsShown(String param1String) throws RemoteException {
      Parcel parcel = Parcel.obtain();
      try {
        parcel.writeInterfaceToken("com.applovin.array.apphub.aidl.IAppHubDirectDownloadServiceCallback");
        parcel.writeString(param1String);
        if (!this.mRemote.transact(1, parcel, null, 1) && IAppHubDirectDownloadServiceCallback.Stub.getDefaultImpl() != null) {
          IAppHubDirectDownloadServiceCallback.Stub.getDefaultImpl().onAppDetailsShown(param1String);
          return;
        } 
        return;
      } finally {
        parcel.recycle();
      } 
    }
    
    public void onDownloadStarted(String param1String) throws RemoteException {
      Parcel parcel = Parcel.obtain();
      try {
        parcel.writeInterfaceToken("com.applovin.array.apphub.aidl.IAppHubDirectDownloadServiceCallback");
        parcel.writeString(param1String);
        if (!this.mRemote.transact(3, parcel, null, 1) && IAppHubDirectDownloadServiceCallback.Stub.getDefaultImpl() != null) {
          IAppHubDirectDownloadServiceCallback.Stub.getDefaultImpl().onDownloadStarted(param1String);
          return;
        } 
        return;
      } finally {
        parcel.recycle();
      } 
    }
    
    public void onError(String param1String1, String param1String2) throws RemoteException {
      Parcel parcel = Parcel.obtain();
      try {
        parcel.writeInterfaceToken("com.applovin.array.apphub.aidl.IAppHubDirectDownloadServiceCallback");
        parcel.writeString(param1String1);
        parcel.writeString(param1String2);
        if (!this.mRemote.transact(4, parcel, null, 1) && IAppHubDirectDownloadServiceCallback.Stub.getDefaultImpl() != null) {
          IAppHubDirectDownloadServiceCallback.Stub.getDefaultImpl().onError(param1String1, param1String2);
          return;
        } 
        return;
      } finally {
        parcel.recycle();
      } 
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\MagicAI - AI Art & Anime Art-dex2jar.jar!\com\applovin\array\apphub\aidl\IAppHubDirectDownloadServiceCallback.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */