package com.android.billingclient.api;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.content.ServiceConnection;
import android.content.pm.ResolveInfo;
import android.content.pm.ServiceInfo;
import android.graphics.Rect;
import android.os.Bundle;
import android.os.Handler;
import android.os.IBinder;
import android.os.Looper;
import android.os.RemoteException;
import android.os.ResultReceiver;
import android.text.TextUtils;
import android.view.View;
import androidx.annotation.AnyThread;
import androidx.annotation.Nullable;
import androidx.core.app.BundleCompat;
import com.google.android.gms.internal.play_billing.zzb;
import com.google.android.gms.internal.play_billing.zze;
import com.google.android.gms.internal.play_billing.zzfa;
import com.google.android.gms.internal.play_billing.zzfb;
import com.google.android.gms.internal.play_billing.zzfe;
import com.google.android.gms.internal.play_billing.zzff;
import com.google.android.gms.internal.play_billing.zzfh;
import com.google.android.gms.internal.play_billing.zzfj;
import com.google.android.gms.internal.play_billing.zzfl;
import com.google.android.gms.internal.play_billing.zzfm;
import com.google.android.gms.internal.play_billing.zzfu;
import com.google.android.gms.internal.play_billing.zzfw;
import com.google.android.gms.internal.play_billing.zzg;
import com.google.android.gms.internal.play_billing.zzm;
import com.google.android.gms.internal.play_billing.zzu;
import com.google.android.gms.internal.play_billing.zzz;
import com.safedk.android.analytics.brandsafety.BrandSafetyUtils;
import com.safedk.android.utils.Logger;
import java.lang.ref.WeakReference;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Iterator;
import java.util.List;
import java.util.concurrent.Callable;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.Future;
import java.util.concurrent.ThreadFactory;
import org.json.JSONException;

class BillingClientImpl extends BillingClient {
  private volatile int zza = 0;
  
  private final String zzb;
  
  private final Handler zzc = new Handler(Looper.getMainLooper());
  
  private volatile zzh zzd;
  
  private Context zze;
  
  private zzar zzf;
  
  private volatile zze zzg;
  
  private volatile zzaf zzh;
  
  private boolean zzi;
  
  private boolean zzj;
  
  private int zzk = 0;
  
  private boolean zzl;
  
  private boolean zzm;
  
  private boolean zzn;
  
  private boolean zzo;
  
  private boolean zzp;
  
  private boolean zzq;
  
  private boolean zzr;
  
  private boolean zzs;
  
  private boolean zzt;
  
  private boolean zzu;
  
  private boolean zzv;
  
  private boolean zzw;
  
  private zzbe zzx;
  
  private boolean zzy;
  
  private ExecutorService zzz;
  
  @AnyThread
  private BillingClientImpl(Context paramContext, zzbe paramzzbe, PurchasesUpdatedListener paramPurchasesUpdatedListener, String paramString1, String paramString2, @Nullable AlternativeBillingListener paramAlternativeBillingListener, @Nullable zzar paramzzar) {
    this.zzb = paramString1;
    initialize(paramContext, paramPurchasesUpdatedListener, paramzzbe, paramAlternativeBillingListener, paramString1, null);
  }
  
  @AnyThread
  BillingClientImpl(@Nullable String paramString, zzbe paramzzbe, Context paramContext, PurchasesUpdatedListener paramPurchasesUpdatedListener, @Nullable AlternativeBillingListener paramAlternativeBillingListener, @Nullable zzar paramzzar) {
    this(paramContext, paramzzbe, paramPurchasesUpdatedListener, zzR(), null, paramAlternativeBillingListener, null);
  }
  
  @AnyThread
  BillingClientImpl(@Nullable String paramString, zzbe paramzzbe, Context paramContext, zzaz paramzzaz, @Nullable zzar paramzzar) {
    this.zzb = zzR();
    this.zze = paramContext.getApplicationContext();
    zzfl zzfl = zzfm.zzv();
    zzfl.zzj(zzR());
    zzfl.zzi(this.zze.getPackageName());
    this.zzf = (zzar)new zzaw(this.zze, (zzfm)zzfl.zzc());
    zzb.zzj("BillingClient", "Billing client should have a valid listener but the provided is null.");
    this.zzd = new zzh(this.zze, null, this.zzf);
    this.zzx = paramzzbe;
  }
  
  private void initialize(Context paramContext, PurchasesUpdatedListener paramPurchasesUpdatedListener, zzbe paramzzbe, @Nullable AlternativeBillingListener paramAlternativeBillingListener, String paramString, @Nullable zzar paramzzar) {
    boolean bool;
    this.zze = paramContext.getApplicationContext();
    zzfl zzfl = zzfm.zzv();
    zzfl.zzj(paramString);
    zzfl.zzi(this.zze.getPackageName());
    if (paramzzar != null) {
      this.zzf = paramzzar;
    } else {
      this.zzf = (zzar)new zzaw(this.zze, (zzfm)zzfl.zzc());
    } 
    if (paramPurchasesUpdatedListener == null)
      zzb.zzj("BillingClient", "Billing client should have a valid listener but the provided is null."); 
    this.zzd = new zzh(this.zze, paramPurchasesUpdatedListener, paramAlternativeBillingListener, this.zzf);
    this.zzx = paramzzbe;
    if (paramAlternativeBillingListener != null) {
      bool = true;
    } else {
      bool = false;
    } 
    this.zzy = bool;
  }
  
  public static void safedk_Activity_startActivity_9d898b58165fa4ba0e12c3900a2b8533(Activity paramActivity, Intent paramIntent) {
    Logger.d("SafeDK-Special|SafeDK: Call> Landroid/app/Activity;->startActivity(Landroid/content/Intent;)V");
    if (paramIntent == null)
      return; 
    BrandSafetyUtils.detectAdClick(paramIntent, "com.android.billingclient");
    paramActivity.startActivity(paramIntent);
  }
  
  private final Handler zzO() {
    return (Looper.myLooper() == null) ? this.zzc : new Handler(Looper.myLooper());
  }
  
  private final BillingResult zzP(BillingResult paramBillingResult) {
    if (Thread.interrupted())
      return paramBillingResult; 
    this.zzc.post((Runnable)new zzx(this, paramBillingResult));
    return paramBillingResult;
  }
  
  private final BillingResult zzQ() {
    return (this.zza == 0 || this.zza == 3) ? zzat.zzm : zzat.zzj;
  }
  
  @SuppressLint({"PrivateApi"})
  private static String zzR() {
    try {
      return (String)Class.forName("com.android.billingclient.ktx.BuildConfig").getField("VERSION_NAME").get(null);
    } catch (Exception exception) {
      return "6.0.1";
    } 
  }
  
  @Nullable
  private final Future zzS(Callable<?> paramCallable, long paramLong, @Nullable Runnable paramRunnable, Handler paramHandler) {
    if (this.zzz == null)
      this.zzz = Executors.newFixedThreadPool(zzb.zza, (ThreadFactory)new zzab(this)); 
    try {
      Future<?> future = this.zzz.submit(paramCallable);
      double d = paramLong;
      paramHandler.postDelayed((Runnable)new zzw(future, paramRunnable), (long)(d * 0.95D));
      return future;
    } catch (Exception exception) {
      zzb.zzk("BillingClient", "Async task throws exception!", exception);
      return null;
    } 
  }
  
  private final void zzT(String paramString, PurchaseHistoryResponseListener paramPurchaseHistoryResponseListener) {
    zzar zzar1;
    if (!isReady()) {
      zzar1 = this.zzf;
      BillingResult billingResult = zzat.zzm;
      zzar1.zza(zzaq.zza(2, 11, billingResult));
      paramPurchaseHistoryResponseListener.onPurchaseHistoryResponse(billingResult, null);
      return;
    } 
    if (zzS((Callable)new zzz(this, (String)zzar1, paramPurchaseHistoryResponseListener), 30000L, (Runnable)new zzo(this, paramPurchaseHistoryResponseListener), zzO()) == null) {
      BillingResult billingResult = zzQ();
      this.zzf.zza(zzaq.zza(25, 11, billingResult));
      paramPurchaseHistoryResponseListener.onPurchaseHistoryResponse(billingResult, null);
    } 
  }
  
  private final void zzU(String paramString, PurchasesResponseListener paramPurchasesResponseListener) {
    zzar zzar1;
    if (!isReady()) {
      zzar1 = this.zzf;
      BillingResult billingResult = zzat.zzm;
      zzar1.zza(zzaq.zza(2, 9, billingResult));
      paramPurchasesResponseListener.onQueryPurchasesResponse(billingResult, (List)zzu.zzk());
      return;
    } 
    if (TextUtils.isEmpty((CharSequence)zzar1)) {
      zzb.zzj("BillingClient", "Please provide a valid product type.");
      zzar1 = this.zzf;
      BillingResult billingResult = zzat.zzg;
      zzar1.zza(zzaq.zza(50, 9, billingResult));
      paramPurchasesResponseListener.onQueryPurchasesResponse(billingResult, (List)zzu.zzk());
      return;
    } 
    if (zzS((Callable)new zzy(this, (String)zzar1, paramPurchasesResponseListener), 30000L, (Runnable)new zzu(this, paramPurchasesResponseListener), zzO()) == null) {
      BillingResult billingResult = zzQ();
      this.zzf.zza(zzaq.zza(25, 9, billingResult));
      paramPurchasesResponseListener.onQueryPurchasesResponse(billingResult, (List)zzu.zzk());
    } 
  }
  
  private final void zzV(BillingResult paramBillingResult, int paramInt1, int paramInt2) {
    if (paramBillingResult.getResponseCode() != 0) {
      zzar zzar2 = this.zzf;
      zzfa zzfa = zzfb.zzv();
      zzfh zzfh = zzfj.zzv();
      zzfh.zzj(paramBillingResult.getResponseCode());
      zzfh.zzi(paramBillingResult.getDebugMessage());
      zzfh.zzk(paramInt1);
      zzfa.zzi(zzfh);
      zzfa.zzk(5);
      zzfu zzfu1 = zzfw.zzv();
      zzfu1.zzi(paramInt2);
      zzfa.zzj((zzfw)zzfu1.zzc());
      zzar2.zza((zzfb)zzfa.zzc());
      return;
    } 
    zzar zzar1 = this.zzf;
    zzfe zzfe = zzff.zzv();
    zzfe.zzj(5);
    zzfu zzfu = zzfw.zzv();
    zzfu.zzi(paramInt2);
    zzfe.zzi((zzfw)zzfu.zzc());
    zzar1.zzb((zzff)zzfe.zzc());
  }
  
  public final void acknowledgePurchase(AcknowledgePurchaseParams paramAcknowledgePurchaseParams, AcknowledgePurchaseResponseListener paramAcknowledgePurchaseResponseListener) {
    zzar zzar1;
    if (!isReady()) {
      zzar1 = this.zzf;
      BillingResult billingResult = zzat.zzm;
      zzar1.zza(zzaq.zza(2, 3, billingResult));
      paramAcknowledgePurchaseResponseListener.onAcknowledgePurchaseResponse(billingResult);
      return;
    } 
    if (TextUtils.isEmpty(zzar1.getPurchaseToken())) {
      zzb.zzj("BillingClient", "Please provide a valid purchase token.");
      zzar1 = this.zzf;
      BillingResult billingResult = zzat.zzi;
      zzar1.zza(zzaq.zza(26, 3, billingResult));
      paramAcknowledgePurchaseResponseListener.onAcknowledgePurchaseResponse(billingResult);
      return;
    } 
    if (!this.zzn) {
      zzar1 = this.zzf;
      BillingResult billingResult = zzat.zzb;
      zzar1.zza(zzaq.zza(27, 3, billingResult));
      paramAcknowledgePurchaseResponseListener.onAcknowledgePurchaseResponse(billingResult);
      return;
    } 
    if (zzS((Callable)new zzp(this, (AcknowledgePurchaseParams)zzar1, paramAcknowledgePurchaseResponseListener), 30000L, (Runnable)new zzq(this, paramAcknowledgePurchaseResponseListener), zzO()) == null) {
      BillingResult billingResult = zzQ();
      this.zzf.zza(zzaq.zza(25, 3, billingResult));
      paramAcknowledgePurchaseResponseListener.onAcknowledgePurchaseResponse(billingResult);
    } 
  }
  
  public final void consumeAsync(ConsumeParams paramConsumeParams, ConsumeResponseListener paramConsumeResponseListener) {
    if (!isReady()) {
      zzar zzar1 = this.zzf;
      BillingResult billingResult = zzat.zzm;
      zzar1.zza(zzaq.zza(2, 4, billingResult));
      paramConsumeResponseListener.onConsumeResponse(billingResult, paramConsumeParams.getPurchaseToken());
      return;
    } 
    if (zzS((Callable)new zzm(this, paramConsumeParams, paramConsumeResponseListener), 30000L, (Runnable)new zzn(this, paramConsumeResponseListener, paramConsumeParams), zzO()) == null) {
      BillingResult billingResult = zzQ();
      this.zzf.zza(zzaq.zza(25, 4, billingResult));
      paramConsumeResponseListener.onConsumeResponse(billingResult, paramConsumeParams.getPurchaseToken());
    } 
  }
  
  public final void endConnection() {
    Exception exception;
    this.zzf.zzb(zzaq.zzb(12));
    try {
      this.zzd.zzd();
      if (this.zzh != null)
        this.zzh.zzc(); 
      if (this.zzh != null && this.zzg != null) {
        zzb.zzi("BillingClient", "Unbinding from service.");
        this.zze.unbindService((ServiceConnection)this.zzh);
        this.zzh = null;
      } 
      this.zzg = null;
      ExecutorService executorService = this.zzz;
      if (executorService != null) {
        executorService.shutdownNow();
        this.zzz = null;
      } 
      this.zza = 3;
      return;
    } catch (Exception null) {
      zzb.zzk("BillingClient", "There was an exception while ending connection!", exception);
      this.zza = 3;
      return;
    } finally {}
    this.zza = 3;
    throw exception;
  }
  
  public final BillingResult isFeatureSupported(String paramString) {
    BillingResult billingResult1;
    byte b;
    if (!isReady()) {
      billingResult1 = zzat.zzm;
      if (billingResult1.getResponseCode() != 0) {
        this.zzf.zza(zzaq.zza(2, 5, billingResult1));
        return billingResult1;
      } 
      this.zzf.zzb(zzaq.zzb(5));
      return billingResult1;
    } 
    BillingResult billingResult2 = zzat.zza;
    switch (billingResult1.hashCode()) {
      default:
        b = -1;
        break;
      case 1987365622:
        if (billingResult1.equals("subscriptions")) {
          b = 0;
          break;
        } 
      case 207616302:
        if (billingResult1.equals("priceChangeConfirmation")) {
          b = 2;
          break;
        } 
      case 104265:
        if (billingResult1.equals("iii")) {
          b = 11;
          break;
        } 
      case 103272:
        if (billingResult1.equals("hhh")) {
          b = 10;
          break;
        } 
      case 102279:
        if (billingResult1.equals("ggg")) {
          b = 9;
          break;
        } 
      case 101286:
        if (billingResult1.equals("fff")) {
          b = 8;
          break;
        } 
      case 100293:
        if (billingResult1.equals("eee")) {
          b = 7;
          break;
        } 
      case 99300:
        if (billingResult1.equals("ddd")) {
          b = 5;
          break;
        } 
      case 98307:
        if (billingResult1.equals("ccc")) {
          b = 6;
          break;
        } 
      case 97314:
        if (billingResult1.equals("bbb")) {
          b = 3;
          break;
        } 
      case 96321:
        if (billingResult1.equals("aaa")) {
          b = 4;
          break;
        } 
      case -422092961:
        if (billingResult1.equals("subscriptionsUpdate")) {
          b = 1;
          break;
        } 
    } 
    switch (b) {
      default:
        zzb.zzj("BillingClient", "Unsupported feature: ".concat((String)billingResult1));
        billingResult1 = zzat.zzy;
        zzV(billingResult1, 34, 1);
        return billingResult1;
      case 11:
        if (this.zzw) {
          billingResult1 = zzat.zzl;
        } else {
          billingResult1 = zzat.zzC;
        } 
        zzV(billingResult1, 60, 13);
        return billingResult1;
      case 10:
        if (this.zzu) {
          billingResult1 = zzat.zzl;
        } else {
          billingResult1 = zzat.zzA;
        } 
        zzV(billingResult1, 33, 12);
        return billingResult1;
      case 9:
        if (this.zzu) {
          billingResult1 = zzat.zzl;
        } else {
          billingResult1 = zzat.zzz;
        } 
        zzV(billingResult1, 32, 11);
        return billingResult1;
      case 8:
        if (this.zzt) {
          billingResult1 = zzat.zzl;
        } else {
          billingResult1 = zzat.zzv;
        } 
        zzV(billingResult1, 20, 10);
        return billingResult1;
      case 7:
        if (this.zzs) {
          billingResult1 = zzat.zzl;
        } else {
          billingResult1 = zzat.zzt;
        } 
        zzV(billingResult1, 61, 9);
        return billingResult1;
      case 6:
        if (this.zzs) {
          billingResult1 = zzat.zzl;
        } else {
          billingResult1 = zzat.zzt;
        } 
        zzV(billingResult1, 19, 8);
        return billingResult1;
      case 5:
        if (this.zzq) {
          billingResult1 = zzat.zzl;
        } else {
          billingResult1 = zzat.zzu;
        } 
        zzV(billingResult1, 21, 7);
        return billingResult1;
      case 4:
        if (this.zzr) {
          billingResult1 = zzat.zzl;
        } else {
          billingResult1 = zzat.zzs;
        } 
        zzV(billingResult1, 31, 6);
        return billingResult1;
      case 3:
        if (this.zzp) {
          billingResult1 = zzat.zzl;
        } else {
          billingResult1 = zzat.zzw;
        } 
        zzV(billingResult1, 30, 5);
        return billingResult1;
      case 2:
        if (this.zzm) {
          billingResult1 = zzat.zzl;
        } else {
          billingResult1 = zzat.zzr;
        } 
        zzV(billingResult1, 35, 4);
        return billingResult1;
      case 1:
        if (this.zzj) {
          billingResult1 = zzat.zzl;
        } else {
          billingResult1 = zzat.zzp;
        } 
        zzV(billingResult1, 10, 3);
        return billingResult1;
      case 0:
        break;
    } 
    if (this.zzi) {
      billingResult1 = zzat.zzl;
    } else {
      billingResult1 = zzat.zzo;
    } 
    zzV(billingResult1, 9, 2);
    return billingResult1;
  }
  
  public final boolean isReady() {
    return (this.zza == 2 && this.zzg != null && this.zzh != null);
  }
  
  public final BillingResult launchBillingFlow(Activity paramActivity, BillingFlowParams paramBillingFlowParams) {
    BillingResult billingResult;
    String str1;
    String str2;
    BillingFlowParams.ProductDetailsParams productDetailsParams2;
    Bundle bundle;
    BillingClientImpl billingClientImpl = this;
    if (!isReady()) {
      zzar zzar1 = billingClientImpl.zzf;
      billingResult = zzat.zzm;
      zzar1.zza(zzaq.zza(2, 2, billingResult));
      billingClientImpl.zzP(billingResult);
      return billingResult;
    } 
    ArrayList<SkuDetails> arrayList = billingResult.zzg();
    List<BillingFlowParams.ProductDetailsParams> list = billingResult.zzh();
    SkuDetails skuDetails = (SkuDetails)zzz.zza(arrayList, null);
    BillingFlowParams.ProductDetailsParams productDetailsParams1 = (BillingFlowParams.ProductDetailsParams)zzz.zza(list, null);
    if (skuDetails != null) {
      str1 = skuDetails.getSku();
      str2 = skuDetails.getType();
    } else {
      str1 = productDetailsParams1.zza().getProductId();
      str2 = productDetailsParams1.zza().getProductType();
    } 
    if (!str2.equals("subs") || billingClientImpl.zzi) {
      if (!billingResult.zzq() || billingClientImpl.zzl) {
        if (arrayList.size() <= 1 || billingClientImpl.zzs) {
          if (list.isEmpty() || billingClientImpl.zzt) {
            if (billingClientImpl.zzl) {
              SkuDetails skuDetails1;
              boolean bool1 = billingClientImpl.zzn;
              boolean bool2 = billingClientImpl.zzy;
              String str = billingClientImpl.zzb;
              bundle = new Bundle();
              bundle.putString("playBillingLibraryVersion", str);
              if (billingResult.zzb() != 0) {
                bundle.putInt("prorationMode", billingResult.zzb());
              } else if (billingResult.zza() != 0) {
                bundle.putInt("prorationMode", billingResult.zza());
              } 
              if (!TextUtils.isEmpty(billingResult.zzc()))
                bundle.putString("accountId", billingResult.zzc()); 
              if (!TextUtils.isEmpty(billingResult.zzd()))
                bundle.putString("obfuscatedProfileId", billingResult.zzd()); 
              if (billingResult.zzp())
                bundle.putBoolean("isOfferPersonalizedByDeveloper", true); 
              if (!TextUtils.isEmpty(null))
                bundle.putStringArrayList("skusToReplace", new ArrayList(Arrays.asList((Object[])new String[] { null }))); 
              if (!TextUtils.isEmpty(billingResult.zze()))
                bundle.putString("oldSkuPurchaseToken", billingResult.zze()); 
              if (!TextUtils.isEmpty(null))
                bundle.putString("oldSkuPurchaseId", null); 
              if (!TextUtils.isEmpty(billingResult.zzf()))
                bundle.putString("originalExternalTransactionId", billingResult.zzf()); 
              if (!TextUtils.isEmpty(null))
                bundle.putString("paymentsPurchaseParams", null); 
              if (bool1)
                bundle.putBoolean("enablePendingPurchases", true); 
              if (bool2)
                bundle.putBoolean("enableAlternativeBilling", true); 
              if (!arrayList.isEmpty()) {
                ArrayList<String> arrayList1 = new ArrayList();
                ArrayList<String> arrayList2 = new ArrayList();
                ArrayList<String> arrayList3 = new ArrayList();
                ArrayList<Integer> arrayList4 = new ArrayList();
                ArrayList<String> arrayList5 = new ArrayList();
                Iterator<SkuDetails> iterator = arrayList.iterator();
                int m = 0;
                int k = 0;
                int j = 0;
                int i = 0;
                while (iterator.hasNext()) {
                  SkuDetails skuDetails2 = iterator.next();
                  if (!skuDetails2.zzf().isEmpty())
                    arrayList1.add(skuDetails2.zzf()); 
                  String str3 = skuDetails2.zzc();
                  String str4 = skuDetails2.zzb();
                  int i1 = skuDetails2.zza();
                  String str5 = skuDetails2.zze();
                  arrayList2.add(str3);
                  m |= TextUtils.isEmpty(str3) ^ true;
                  arrayList3.add(str4);
                  int n = k | TextUtils.isEmpty(str4) ^ true;
                  arrayList4.add(Integer.valueOf(i1));
                  if (i1 != 0) {
                    k = 1;
                  } else {
                    k = 0;
                  } 
                  j |= k;
                  i |= TextUtils.isEmpty(str5) ^ true;
                  arrayList5.add(str5);
                  k = n;
                } 
                if (!arrayList1.isEmpty())
                  bundle.putStringArrayList("skuDetailsTokens", arrayList1); 
                if (m != 0)
                  bundle.putStringArrayList("SKU_OFFER_ID_TOKEN_LIST", arrayList2); 
                if (k != 0)
                  bundle.putStringArrayList("SKU_OFFER_ID_LIST", arrayList3); 
                if (j != 0)
                  bundle.putIntegerArrayList("SKU_OFFER_TYPE_LIST", arrayList4); 
                if (i != 0)
                  bundle.putStringArrayList("SKU_SERIALIZED_DOCID_LIST", arrayList5); 
                productDetailsParams2 = productDetailsParams1;
                skuDetails1 = skuDetails;
                if (arrayList.size() > 1) {
                  ArrayList<String> arrayList6 = new ArrayList(arrayList.size() - 1);
                  ArrayList<String> arrayList7 = new ArrayList(arrayList.size() - 1);
                  for (i = 1; i < arrayList.size(); i++) {
                    arrayList6.add(((SkuDetails)arrayList.get(i)).getSku());
                    arrayList7.add(((SkuDetails)arrayList.get(i)).getType());
                  } 
                  bundle.putStringArrayList("additionalSkus", arrayList6);
                  bundle.putStringArrayList("additionalSkuTypes", arrayList7);
                  BillingFlowParams.ProductDetailsParams productDetailsParams = productDetailsParams1;
                  SkuDetails skuDetails2 = skuDetails;
                } 
              } else {
                arrayList = new ArrayList<SkuDetails>(list.size() - 1);
                ArrayList<String> arrayList3 = new ArrayList(list.size() - 1);
                ArrayList<String> arrayList1 = new ArrayList();
                ArrayList<String> arrayList2 = new ArrayList();
                ArrayList<String> arrayList4 = new ArrayList();
                for (int i = 0; i < list.size(); i++) {
                  BillingFlowParams.ProductDetailsParams productDetailsParams = list.get(i);
                  ProductDetails productDetails = productDetailsParams.zza();
                  if (!productDetails.zzb().isEmpty())
                    arrayList1.add(productDetails.zzb()); 
                  arrayList2.add(productDetailsParams.zzb());
                  if (!TextUtils.isEmpty(productDetails.zzc()))
                    arrayList4.add(productDetails.zzc()); 
                  if (i > 0) {
                    arrayList.add(((BillingFlowParams.ProductDetailsParams)list.get(i)).zza().getProductId());
                    arrayList3.add(((BillingFlowParams.ProductDetailsParams)list.get(i)).zza().getProductType());
                  } 
                } 
                bundle.putStringArrayList("SKU_OFFER_ID_TOKEN_LIST", arrayList2);
                if (!arrayList1.isEmpty())
                  bundle.putStringArrayList("skuDetailsTokens", arrayList1); 
                if (!arrayList4.isEmpty())
                  bundle.putStringArrayList("SKU_SERIALIZED_DOCID_LIST", arrayList4); 
                productDetailsParams2 = productDetailsParams1;
                skuDetails1 = skuDetails;
                if (!arrayList.isEmpty()) {
                  bundle.putStringArrayList("additionalSkus", arrayList);
                  bundle.putStringArrayList("additionalSkuTypes", arrayList3);
                  skuDetails1 = skuDetails;
                  productDetailsParams2 = productDetailsParams1;
                } 
              } 
              bool1 = bundle.containsKey("SKU_OFFER_ID_TOKEN_LIST");
              BillingClientImpl billingClientImpl1 = this;
              if (!bool1 || billingClientImpl1.zzq) {
                if (skuDetails1 != null && !TextUtils.isEmpty(skuDetails1.zzd())) {
                  bundle.putString("skuPackageName", skuDetails1.zzd());
                } else if (productDetailsParams2 != null && !TextUtils.isEmpty(productDetailsParams2.zza().zza())) {
                  bundle.putString("skuPackageName", productDetailsParams2.zza().zza());
                } else {
                  boolean bool3 = false;
                  if (!TextUtils.isEmpty(null))
                    bundle.putString("accountName", null); 
                } 
                boolean bool = true;
              } else {
                zzar zzar1 = billingClientImpl1.zzf;
                billingResult = zzat.zzu;
                zzar1.zza(zzaq.zza(21, 2, billingResult));
                billingClientImpl1.zzP(billingResult);
                return billingResult;
              } 
            } else {
              String str = "BillingClient";
              Future future = zzS((Callable)new zzt((BillingClientImpl)productDetailsParams2, str1, str2), 5000L, null, ((BillingClientImpl)productDetailsParams2).zzc);
              BillingClientImpl billingClientImpl1 = this;
            } 
          } else {
            zzb.zzj("BillingClient", "Current client doesn't support purchases with ProductDetails.");
            zzar zzar1 = ((BillingClientImpl)productDetailsParams2).zzf;
            billingResult = zzat.zzv;
            zzar1.zza(zzaq.zza(20, 2, billingResult));
            productDetailsParams2.zzP(billingResult);
            return billingResult;
          } 
        } else {
          zzb.zzj("BillingClient", "Current client doesn't support multi-item purchases.");
          zzar zzar1 = ((BillingClientImpl)productDetailsParams2).zzf;
          billingResult = zzat.zzt;
          zzar1.zza(zzaq.zza(19, 2, billingResult));
          productDetailsParams2.zzP(billingResult);
          return billingResult;
        } 
      } else {
        zzb.zzj("BillingClient", "Current client doesn't support extra params for buy intent.");
        zzar zzar1 = ((BillingClientImpl)productDetailsParams2).zzf;
        billingResult = zzat.zzh;
        zzar1.zza(zzaq.zza(18, 2, billingResult));
        productDetailsParams2.zzP(billingResult);
        return billingResult;
      } 
    } else {
      zzb.zzj("BillingClient", "Current client doesn't support subscriptions.");
      zzar zzar1 = ((BillingClientImpl)productDetailsParams2).zzf;
      billingResult = zzat.zzo;
      zzar1.zza(zzaq.zza(9, 2, billingResult));
      productDetailsParams2.zzP(billingResult);
      return billingResult;
    } 
    if (!TextUtils.isEmpty(null))
      bundle.putString("accountName", null); 
  }
  
  public final void queryProductDetailsAsync(QueryProductDetailsParams paramQueryProductDetailsParams, ProductDetailsResponseListener paramProductDetailsResponseListener) {
    zzar zzar1;
    if (!isReady()) {
      zzar1 = this.zzf;
      BillingResult billingResult = zzat.zzm;
      zzar1.zza(zzaq.zza(2, 7, billingResult));
      paramProductDetailsResponseListener.onProductDetailsResponse(billingResult, new ArrayList());
      return;
    } 
    if (!this.zzt) {
      zzb.zzj("BillingClient", "Querying product details is not supported.");
      zzar1 = this.zzf;
      BillingResult billingResult = zzat.zzv;
      zzar1.zza(zzaq.zza(20, 7, billingResult));
      paramProductDetailsResponseListener.onProductDetailsResponse(billingResult, new ArrayList());
      return;
    } 
    if (zzS((Callable)new zzk(this, (QueryProductDetailsParams)zzar1, paramProductDetailsResponseListener), 30000L, (Runnable)new zzl(this, paramProductDetailsResponseListener), zzO()) == null) {
      BillingResult billingResult = zzQ();
      this.zzf.zza(zzaq.zza(25, 7, billingResult));
      paramProductDetailsResponseListener.onProductDetailsResponse(billingResult, new ArrayList());
    } 
  }
  
  public final void queryPurchaseHistoryAsync(QueryPurchaseHistoryParams paramQueryPurchaseHistoryParams, PurchaseHistoryResponseListener paramPurchaseHistoryResponseListener) {
    zzT(paramQueryPurchaseHistoryParams.zza(), paramPurchaseHistoryResponseListener);
  }
  
  public final void queryPurchasesAsync(QueryPurchasesParams paramQueryPurchasesParams, PurchasesResponseListener paramPurchasesResponseListener) {
    zzU(paramQueryPurchasesParams.zza(), paramPurchasesResponseListener);
  }
  
  public final BillingResult showInAppMessages(Activity paramActivity, InAppMessageParams paramInAppMessageParams, InAppMessageResponseListener paramInAppMessageResponseListener) {
    if (!isReady()) {
      zzb.zzj("BillingClient", "Service disconnected.");
      return zzat.zzm;
    } 
    if (!this.zzp) {
      zzb.zzj("BillingClient", "Current client doesn't support showing in-app messages.");
      return zzat.zzw;
    } 
    View view = paramActivity.findViewById(16908290);
    IBinder iBinder = view.getWindowToken();
    Rect rect = new Rect();
    view.getGlobalVisibleRect(rect);
    Bundle bundle = new Bundle();
    BundleCompat.putBinder(bundle, "KEY_WINDOW_TOKEN", iBinder);
    bundle.putInt("KEY_DIMEN_LEFT", rect.left);
    bundle.putInt("KEY_DIMEN_TOP", rect.top);
    bundle.putInt("KEY_DIMEN_RIGHT", rect.right);
    bundle.putInt("KEY_DIMEN_BOTTOM", rect.bottom);
    bundle.putString("playBillingLibraryVersion", this.zzb);
    bundle.putIntegerArrayList("KEY_CATEGORY_IDS", paramInAppMessageParams.zza());
    zzS((Callable)new zzv(this, bundle, paramActivity, (ResultReceiver)new zzaa(this, this.zzc, paramInAppMessageResponseListener)), 5000L, null, this.zzc);
    return zzat.zzl;
  }
  
  public final void startConnection(BillingClientStateListener paramBillingClientStateListener) {
    if (isReady()) {
      zzb.zzi("BillingClient", "Service connection is valid. No need to re-initialize.");
      this.zzf.zzb(zzaq.zzb(6));
      paramBillingClientStateListener.onBillingSetupFinished(zzat.zzl);
      return;
    } 
    int i = this.zza;
    byte b = 1;
    if (i == 1) {
      zzb.zzj("BillingClient", "Client is already in the process of connecting to billing service.");
      zzar zzar2 = this.zzf;
      BillingResult billingResult1 = zzat.zzd;
      zzar2.zza(zzaq.zza(37, 6, billingResult1));
      paramBillingClientStateListener.onBillingSetupFinished(billingResult1);
      return;
    } 
    if (this.zza == 3) {
      zzb.zzj("BillingClient", "Client was already closed and can't be reused. Please create another instance.");
      zzar zzar2 = this.zzf;
      BillingResult billingResult1 = zzat.zzm;
      zzar2.zza(zzaq.zza(38, 6, billingResult1));
      paramBillingClientStateListener.onBillingSetupFinished(billingResult1);
      return;
    } 
    this.zza = 1;
    this.zzd.zze();
    zzb.zzi("BillingClient", "Starting in-app billing setup.");
    this.zzh = new zzaf(this, paramBillingClientStateListener, null);
    Intent intent = new Intent("com.android.vending.billing.InAppBillingService.BIND");
    intent.setPackage("com.android.vending");
    List list = this.zze.getPackageManager().queryIntentServices(intent, 0);
    if (list != null && !list.isEmpty()) {
      ServiceInfo serviceInfo = ((ResolveInfo)list.get(0)).serviceInfo;
      if (serviceInfo != null) {
        String str1 = serviceInfo.packageName;
        String str2 = serviceInfo.name;
        if ("com.android.vending".equals(str1) && str2 != null) {
          ComponentName componentName = new ComponentName(str1, str2);
          intent = new Intent(intent);
          intent.setComponent(componentName);
          intent.putExtra("playBillingLibraryVersion", this.zzb);
          if (this.zze.bindService(intent, (ServiceConnection)this.zzh, 1)) {
            zzb.zzi("BillingClient", "Service was bonded successfully.");
            return;
          } 
          zzb.zzj("BillingClient", "Connection to Billing service is blocked.");
          b = 39;
        } else {
          zzb.zzj("BillingClient", "The device doesn't have valid Play Store.");
          b = 40;
        } 
      } 
    } else {
      b = 41;
    } 
    this.zza = 0;
    zzb.zzi("BillingClient", "Billing service unavailable on device.");
    zzar zzar1 = this.zzf;
    BillingResult billingResult = zzat.zzc;
    zzar1.zza(zzaq.zza(b, 6, billingResult));
    paramBillingClientStateListener.onBillingSetupFinished(billingResult);
  }
}


/* Location:              C:\soft\dex2jar-2.0\MagicAI - AI Art & Anime Art-dex2jar.jar!\com\android\billingclient\api\BillingClientImpl.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */