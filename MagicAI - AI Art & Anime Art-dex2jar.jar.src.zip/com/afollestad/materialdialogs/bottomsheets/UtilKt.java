package com.afollestad.materialdialogs.bottomsheets;

import android.animation.Animator;
import android.animation.AnimatorListenerAdapter;
import android.animation.TimeInterpolator;
import android.animation.ValueAnimator;
import android.view.View;
import android.view.animation.DecelerateInterpolator;
import androidx.annotation.CheckResult;
import com.google.android.material.bottomsheet.BottomSheetBehavior;
import kotlin.Metadata;
import kotlin.TypeCastException;
import kotlin.Unit;
import kotlin.jvm.functions.Function0;
import kotlin.jvm.functions.Function1;
import kotlin.jvm.internal.CallableReference;
import kotlin.jvm.internal.FunctionReference;
import kotlin.jvm.internal.Intrinsics;
import kotlin.jvm.internal.Lambda;
import kotlin.jvm.internal.Reflection;
import kotlin.reflect.KDeclarationContainer;

@Metadata(d1 = {"\0002\n\002\030\002\n\002\030\002\n\002\020\b\n\002\020\002\n\000\n\002\030\002\n\002\b\002\n\002\030\002\n\002\b\003\n\002\020\t\n\002\b\006\n\002\030\002\n\002\b\006\0322\020\007\032\0020\003*\006\022\002\b\0030\0002\022\020\004\032\016\022\004\022\0020\002\022\004\022\0020\0030\0012\f\020\006\032\b\022\004\022\0020\0030\005H\000\032B\020\017\032\0020\003*\006\022\002\b\0030\0002\006\020\t\032\0020\b2\b\b\002\020\n\032\0020\0022\006\020\013\032\0020\0022\006\020\r\032\0020\f2\016\b\002\020\016\032\b\022\004\022\0020\0030\005H\000\032D\020\024\032\0020\0232\006\020\020\032\0020\0022\006\020\021\032\0020\0022\006\020\r\032\0020\f2\022\020\022\032\016\022\004\022\0020\002\022\004\022\0020\0030\0012\016\b\002\020\016\032\b\022\004\022\0020\0030\005H\001\0321\020\027\032\0020\003\"\b\b\000\020\025*\0020\b*\0028\0002\022\020\026\032\016\022\004\022\0028\000\022\004\022\0020\0030\001H\000¢\006\004\b\027\020\030¨\006\031"}, d2 = {"Lcom/google/android/material/bottomsheet/BottomSheetBehavior;", "Lkotlin/Function1;", "", "", "onSlide", "Lkotlin/Function0;", "onHide", "setCallbacks", "Landroid/view/View;", "view", "start", "dest", "", "duration", "onEnd", "animatePeekHeight", "from", "to", "onUpdate", "Landroid/animation/Animator;", "animateValues", "T", "onAttached", "onDetach", "(Landroid/view/View;Lkotlin/jvm/functions/Function1;)V", "bottomsheets"}, k = 2, mv = {1, 4, 0})
public final class UtilKt {
  public static final void animatePeekHeight(BottomSheetBehavior<?> paramBottomSheetBehavior, View paramView, int paramInt1, int paramInt2, long paramLong, Function0<Unit> paramFunction0) {
    Intrinsics.checkParameterIsNotNull(paramBottomSheetBehavior, "$this$animatePeekHeight");
    Intrinsics.checkParameterIsNotNull(paramView, "view");
    Intrinsics.checkParameterIsNotNull(paramFunction0, "onEnd");
    if (paramInt2 == paramInt1)
      return; 
    if (paramLong <= 0L) {
      paramBottomSheetBehavior.setPeekHeight(paramInt2);
      return;
    } 
    Animator animator = animateValues(paramInt1, paramInt2, paramLong, new UtilKt$animatePeekHeight$animator$1(paramBottomSheetBehavior), paramFunction0);
    onDetach(paramView, new UtilKt$animatePeekHeight$2(animator));
    animator.start();
  }
  
  @CheckResult
  public static final Animator animateValues(int paramInt1, int paramInt2, long paramLong, Function1<? super Integer, Unit> paramFunction1, Function0<Unit> paramFunction0) {
    Intrinsics.checkParameterIsNotNull(paramFunction1, "onUpdate");
    Intrinsics.checkParameterIsNotNull(paramFunction0, "onEnd");
    ValueAnimator valueAnimator = ValueAnimator.ofInt(new int[] { paramInt1, paramInt2 });
    Intrinsics.checkExpressionValueIsNotNull(valueAnimator, "this");
    valueAnimator.setInterpolator((TimeInterpolator)new DecelerateInterpolator());
    valueAnimator.setDuration(paramLong);
    valueAnimator.addUpdateListener(new UtilKt$animateValues$$inlined$apply$lambda$1(paramLong, paramFunction1, paramFunction0));
    valueAnimator.addListener((Animator.AnimatorListener)new UtilKt$animateValues$$inlined$apply$lambda$2(paramLong, paramFunction1, paramFunction0));
    Intrinsics.checkExpressionValueIsNotNull(valueAnimator, "ValueAnimator.ofInt(from…nEnd()\n        })\n      }");
    return (Animator)valueAnimator;
  }
  
  public static final <T extends View> void onDetach(T paramT, Function1<? super T, Unit> paramFunction1) {
    Intrinsics.checkParameterIsNotNull(paramT, "$this$onDetach");
    Intrinsics.checkParameterIsNotNull(paramFunction1, "onAttached");
    paramT.addOnAttachStateChangeListener(new UtilKt$onDetach$1(paramT, paramFunction1));
  }
  
  public static final void setCallbacks(BottomSheetBehavior<?> paramBottomSheetBehavior, Function1<? super Integer, Unit> paramFunction1, Function0<Unit> paramFunction0) {
    Intrinsics.checkParameterIsNotNull(paramBottomSheetBehavior, "$this$setCallbacks");
    Intrinsics.checkParameterIsNotNull(paramFunction1, "onSlide");
    Intrinsics.checkParameterIsNotNull(paramFunction0, "onHide");
    paramBottomSheetBehavior.setBottomSheetCallback(new UtilKt$setCallbacks$1(paramBottomSheetBehavior, paramFunction1, paramFunction0));
  }
  
  @Metadata(bv = {1, 0, 3}, d1 = {"\000\b\n\000\n\002\020\002\n\000\020\000\032\0020\001H\n¢\006\002\b\002"}, d2 = {"<anonymous>", "", "invoke"}, k = 3, mv = {1, 1, 16})
  static final class UtilKt$animatePeekHeight$1 extends Lambda implements Function0<Unit> {
    public static final UtilKt$animatePeekHeight$1 INSTANCE = new UtilKt$animatePeekHeight$1();
    
    UtilKt$animatePeekHeight$1() {
      super(0);
    }
    
    public final void invoke() {}
  }
  
  @Metadata(bv = {1, 0, 3}, d1 = {"\000\f\n\000\n\002\020\002\n\002\030\002\n\000\020\000\032\0020\001*\0020\002H\n¢\006\002\b\003"}, d2 = {"<anonymous>", "", "Landroid/view/View;", "invoke"}, k = 3, mv = {1, 1, 16})
  static final class UtilKt$animatePeekHeight$2 extends Lambda implements Function1<View, Unit> {
    UtilKt$animatePeekHeight$2(Animator param1Animator) {
      super(1);
    }
    
    public final void invoke(View param1View) {
      Intrinsics.checkParameterIsNotNull(param1View, "$receiver");
      this.$animator.cancel();
    }
  }
  
  @Metadata(bv = {1, 0, 3}, d1 = {"\000\024\n\000\n\002\020\002\n\000\n\002\030\002\n\002\b\002\n\002\b\003\020\000\032\0020\0012\016\020\002\032\n \004*\004\030\0010\0030\003H\n¢\006\002\b\005¨\006\006"}, d2 = {"<anonymous>", "", "it", "Landroid/animation/ValueAnimator;", "kotlin.jvm.PlatformType", "onAnimationUpdate", "com/afollestad/materialdialogs/bottomsheets/UtilKt$animateValues$2$1"}, k = 3, mv = {1, 1, 16})
  static final class UtilKt$animateValues$$inlined$apply$lambda$1 implements ValueAnimator.AnimatorUpdateListener {
    UtilKt$animateValues$$inlined$apply$lambda$1(long param1Long, Function1 param1Function1, Function0 param1Function0) {}
    
    public final void onAnimationUpdate(ValueAnimator param1ValueAnimator) {
      Function1 function1 = this.$onUpdate$inlined;
      Intrinsics.checkExpressionValueIsNotNull(param1ValueAnimator, "it");
      Object object = param1ValueAnimator.getAnimatedValue();
      if (object != null) {
        function1.invoke(object);
        return;
      } 
      throw new TypeCastException("null cannot be cast to non-null type kotlin.Int");
    }
  }
  
  @Metadata(bv = {1, 0, 3}, d1 = {"\000\027\n\000\n\002\030\002\n\000\n\002\020\002\n\000\n\002\030\002\n\000*\001\000\b\n\030\0002\0020\001J\020\020\002\032\0020\0032\006\020\004\032\0020\005H\026¨\006\006¸\006\000"}, d2 = {"com/afollestad/materialdialogs/bottomsheets/UtilKt$animateValues$2$2", "Landroid/animation/AnimatorListenerAdapter;", "onAnimationEnd", "", "animation", "Landroid/animation/Animator;", "bottomsheets"}, k = 1, mv = {1, 1, 16})
  public static final class UtilKt$animateValues$$inlined$apply$lambda$2 extends AnimatorListenerAdapter {
    UtilKt$animateValues$$inlined$apply$lambda$2(long param1Long, Function1 param1Function1, Function0 param1Function0) {}
    
    public void onAnimationEnd(Animator param1Animator) {
      Intrinsics.checkParameterIsNotNull(param1Animator, "animation");
      this.$onEnd$inlined.invoke();
    }
  }
  
  @Metadata(bv = {1, 0, 3}, d1 = {"\000\b\n\000\n\002\020\002\n\000\020\000\032\0020\001H\n¢\006\002\b\002"}, d2 = {"<anonymous>", "", "invoke"}, k = 3, mv = {1, 1, 16})
  static final class UtilKt$animateValues$1 extends Lambda implements Function0<Unit> {
    public static final UtilKt$animateValues$1 INSTANCE = new UtilKt$animateValues$1();
    
    UtilKt$animateValues$1() {
      super(0);
    }
    
    public final void invoke() {}
  }
  
  @Metadata(bv = {1, 0, 3}, d1 = {"\000\031\n\000\n\002\030\002\n\000\n\002\020\002\n\000\n\002\030\002\n\002\b\002*\001\000\b\n\030\0002\0020\001J\020\020\002\032\0020\0032\006\020\004\032\0020\005H\026J\020\020\006\032\0020\0032\006\020\004\032\0020\005H\026¨\006\007"}, d2 = {"com/afollestad/materialdialogs/bottomsheets/UtilKt$onDetach$1", "Landroid/view/View$OnAttachStateChangeListener;", "onViewAttachedToWindow", "", "v", "Landroid/view/View;", "onViewDetachedFromWindow", "bottomsheets"}, k = 1, mv = {1, 1, 16})
  public static final class UtilKt$onDetach$1 implements View.OnAttachStateChangeListener {
    UtilKt$onDetach$1(T param1T, Function1 param1Function1) {}
    
    public void onViewAttachedToWindow(View param1View) {
      Intrinsics.checkParameterIsNotNull(param1View, "v");
    }
    
    public void onViewDetachedFromWindow(View param1View) {
      Intrinsics.checkParameterIsNotNull(param1View, "v");
      this.$this_onDetach.removeOnAttachStateChangeListener(this);
      this.$onAttached.invoke(param1View);
    }
  }
  
  @Metadata(bv = {1, 0, 3}, d1 = {"\000%\n\000\n\002\030\002\n\000\n\002\020\b\n\000\n\002\020\002\n\000\n\002\030\002\n\000\n\002\020\007\n\002\b\003*\001\000\b\n\030\0002\0020\001J\030\020\004\032\0020\0052\006\020\006\032\0020\0072\006\020\b\032\0020\tH\026J\030\020\n\032\0020\0052\006\020\006\032\0020\0072\006\020\013\032\0020\003H\026R\016\020\002\032\0020\003X\016¢\006\002\n\000¨\006\f"}, d2 = {"com/afollestad/materialdialogs/bottomsheets/UtilKt$setCallbacks$1", "Lcom/google/android/material/bottomsheet/BottomSheetBehavior$BottomSheetCallback;", "currentState", "", "onSlide", "", "view", "Landroid/view/View;", "dY", "", "onStateChanged", "state", "bottomsheets"}, k = 1, mv = {1, 1, 16})
  public static final class UtilKt$setCallbacks$1 extends BottomSheetBehavior.BottomSheetCallback {
    private int currentState = 4;
    
    UtilKt$setCallbacks$1(BottomSheetBehavior<?> param1BottomSheetBehavior, Function1 param1Function1, Function0 param1Function0) {}
    
    public void onSlide(View param1View, float param1Float) {
      Intrinsics.checkParameterIsNotNull(param1View, "view");
      if (this.$this_setCallbacks.getState() == 5)
        return; 
      float f = param1Float;
      if (Float.isNaN(param1Float))
        f = 0.0F; 
      if (f > 0.0F) {
        param1Float = this.$this_setCallbacks.getPeekHeight();
        f = Math.abs(f);
        this.$onSlide.invoke(Integer.valueOf((int)(this.$this_setCallbacks.getPeekHeight() + param1Float * f)));
        return;
      } 
      param1Float = this.$this_setCallbacks.getPeekHeight();
      f = Math.abs(f);
      this.$onSlide.invoke(Integer.valueOf((int)(this.$this_setCallbacks.getPeekHeight() - param1Float * f)));
    }
    
    public void onStateChanged(View param1View, int param1Int) {
      Intrinsics.checkParameterIsNotNull(param1View, "view");
      this.currentState = param1Int;
      if (param1Int == 5)
        this.$onHide.invoke(); 
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\MagicAI - AI Art & Anime Art-dex2jar.jar!\com\afollestad\materialdialogs\bottomsheets\UtilKt.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */