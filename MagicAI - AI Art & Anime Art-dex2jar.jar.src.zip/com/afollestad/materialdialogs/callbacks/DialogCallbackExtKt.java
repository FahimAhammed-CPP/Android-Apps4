package com.afollestad.materialdialogs.callbacks;

import android.content.DialogInterface;
import com.afollestad.materialdialogs.MaterialDialog;
import java.util.Iterator;
import java.util.List;
import kotlin.Metadata;
import kotlin.Unit;
import kotlin.jvm.functions.Function1;
import kotlin.jvm.internal.Intrinsics;

@Metadata(bv = {1, 0, 3}, d1 = {"\000\032\n\000\n\002\020\002\n\002\020!\n\002\030\002\n\002\030\002\n\002\030\002\n\002\b\007\032*\020\000\032\0020\001*\030\022\024\022\022\022\004\022\0020\004\022\004\022\0020\0010\003j\002`\0050\0022\006\020\006\032\0020\004H\000\032\"\020\007\032\0020\004*\0020\0042\026\020\b\032\022\022\004\022\0020\004\022\004\022\0020\0010\003j\002`\005\032\"\020\t\032\0020\004*\0020\0042\026\020\b\032\022\022\004\022\0020\004\022\004\022\0020\0010\003j\002`\005\032\"\020\n\032\0020\004*\0020\0042\026\020\b\032\022\022\004\022\0020\004\022\004\022\0020\0010\003j\002`\005\032\"\020\013\032\0020\004*\0020\0042\026\020\b\032\022\022\004\022\0020\004\022\004\022\0020\0010\003j\002`\005¨\006\f"}, d2 = {"invokeAll", "", "", "Lkotlin/Function1;", "Lcom/afollestad/materialdialogs/MaterialDialog;", "Lcom/afollestad/materialdialogs/DialogCallback;", "dialog", "onCancel", "callback", "onDismiss", "onPreShow", "onShow", "core"}, k = 2, mv = {1, 1, 16})
public final class DialogCallbackExtKt {
  public static final void invokeAll(List<Function1<MaterialDialog, Unit>> paramList, MaterialDialog paramMaterialDialog) {
    Intrinsics.checkParameterIsNotNull(paramList, "$this$invokeAll");
    Intrinsics.checkParameterIsNotNull(paramMaterialDialog, "dialog");
    Iterator<Function1<MaterialDialog, Unit>> iterator = paramList.iterator();
    while (iterator.hasNext())
      ((Function1)iterator.next()).invoke(paramMaterialDialog); 
  }
  
  public static final MaterialDialog onCancel(MaterialDialog paramMaterialDialog, Function1<? super MaterialDialog, Unit> paramFunction1) {
    Intrinsics.checkParameterIsNotNull(paramMaterialDialog, "$this$onCancel");
    Intrinsics.checkParameterIsNotNull(paramFunction1, "callback");
    paramMaterialDialog.getCancelListeners$core().add(paramFunction1);
    paramMaterialDialog.setOnCancelListener(new DialogCallbackExtKt$onCancel$1(paramMaterialDialog));
    return paramMaterialDialog;
  }
  
  public static final MaterialDialog onDismiss(MaterialDialog paramMaterialDialog, Function1<? super MaterialDialog, Unit> paramFunction1) {
    Intrinsics.checkParameterIsNotNull(paramMaterialDialog, "$this$onDismiss");
    Intrinsics.checkParameterIsNotNull(paramFunction1, "callback");
    paramMaterialDialog.getDismissListeners$core().add(paramFunction1);
    paramMaterialDialog.setOnDismissListener(new DialogCallbackExtKt$onDismiss$1(paramMaterialDialog));
    return paramMaterialDialog;
  }
  
  public static final MaterialDialog onPreShow(MaterialDialog paramMaterialDialog, Function1<? super MaterialDialog, Unit> paramFunction1) {
    Intrinsics.checkParameterIsNotNull(paramMaterialDialog, "$this$onPreShow");
    Intrinsics.checkParameterIsNotNull(paramFunction1, "callback");
    paramMaterialDialog.getPreShowListeners$core().add(paramFunction1);
    return paramMaterialDialog;
  }
  
  public static final MaterialDialog onShow(MaterialDialog paramMaterialDialog, Function1<? super MaterialDialog, Unit> paramFunction1) {
    Intrinsics.checkParameterIsNotNull(paramMaterialDialog, "$this$onShow");
    Intrinsics.checkParameterIsNotNull(paramFunction1, "callback");
    paramMaterialDialog.getShowListeners$core().add(paramFunction1);
    if (paramMaterialDialog.isShowing())
      invokeAll(paramMaterialDialog.getShowListeners$core(), paramMaterialDialog); 
    paramMaterialDialog.setOnShowListener(new DialogCallbackExtKt$onShow$1(paramMaterialDialog));
    return paramMaterialDialog;
  }
  
  @Metadata(bv = {1, 0, 3}, d1 = {"\000\020\n\000\n\002\020\002\n\000\n\002\030\002\n\002\b\002\020\000\032\0020\0012\016\020\002\032\n \004*\004\030\0010\0030\003H\n¢\006\002\b\005"}, d2 = {"<anonymous>", "", "it", "Landroid/content/DialogInterface;", "kotlin.jvm.PlatformType", "onCancel"}, k = 3, mv = {1, 1, 16})
  static final class DialogCallbackExtKt$onCancel$1 implements DialogInterface.OnCancelListener {
    DialogCallbackExtKt$onCancel$1(MaterialDialog param1MaterialDialog) {}
    
    public final void onCancel(DialogInterface param1DialogInterface) {
      DialogCallbackExtKt.invokeAll(this.$this_onCancel.getCancelListeners$core(), this.$this_onCancel);
    }
  }
  
  @Metadata(bv = {1, 0, 3}, d1 = {"\000\020\n\000\n\002\020\002\n\000\n\002\030\002\n\002\b\002\020\000\032\0020\0012\016\020\002\032\n \004*\004\030\0010\0030\003H\n¢\006\002\b\005"}, d2 = {"<anonymous>", "", "it", "Landroid/content/DialogInterface;", "kotlin.jvm.PlatformType", "onDismiss"}, k = 3, mv = {1, 1, 16})
  static final class DialogCallbackExtKt$onDismiss$1 implements DialogInterface.OnDismissListener {
    DialogCallbackExtKt$onDismiss$1(MaterialDialog param1MaterialDialog) {}
    
    public final void onDismiss(DialogInterface param1DialogInterface) {
      DialogCallbackExtKt.invokeAll(this.$this_onDismiss.getDismissListeners$core(), this.$this_onDismiss);
    }
  }
  
  @Metadata(bv = {1, 0, 3}, d1 = {"\000\020\n\000\n\002\020\002\n\000\n\002\030\002\n\002\b\002\020\000\032\0020\0012\016\020\002\032\n \004*\004\030\0010\0030\003H\n¢\006\002\b\005"}, d2 = {"<anonymous>", "", "it", "Landroid/content/DialogInterface;", "kotlin.jvm.PlatformType", "onShow"}, k = 3, mv = {1, 1, 16})
  static final class DialogCallbackExtKt$onShow$1 implements DialogInterface.OnShowListener {
    DialogCallbackExtKt$onShow$1(MaterialDialog param1MaterialDialog) {}
    
    public final void onShow(DialogInterface param1DialogInterface) {
      DialogCallbackExtKt.invokeAll(this.$this_onShow.getShowListeners$core(), this.$this_onShow);
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\MagicAI - AI Art & Anime Art-dex2jar.jar!\com\afollestad\materialdialogs\callbacks\DialogCallbackExtKt.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */