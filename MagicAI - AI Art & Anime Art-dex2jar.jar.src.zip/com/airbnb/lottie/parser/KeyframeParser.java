package com.airbnb.lottie.parser;

import android.graphics.PointF;
import android.view.animation.Interpolator;
import android.view.animation.LinearInterpolator;
import androidx.annotation.Nullable;
import androidx.collection.SparseArrayCompat;
import com.airbnb.lottie.LottieComposition;
import com.airbnb.lottie.parser.moshi.JsonReader;
import com.airbnb.lottie.value.Keyframe;
import java.io.IOException;
import java.lang.ref.WeakReference;

class KeyframeParser {
  static JsonReader.Options INTERPOLATOR_NAMES;
  
  private static final Interpolator LINEAR_INTERPOLATOR = (Interpolator)new LinearInterpolator();
  
  static JsonReader.Options NAMES = JsonReader.Options.of(new String[] { "t", "s", "e", "o", "i", "h", "to", "ti" });
  
  private static SparseArrayCompat<WeakReference<Interpolator>> pathInterpolatorCache;
  
  static {
    INTERPOLATOR_NAMES = JsonReader.Options.of(new String[] { "x", "y" });
  }
  
  @Nullable
  private static WeakReference<Interpolator> getInterpolator(int paramInt) {
    // Byte code:
    //   0: ldc com/airbnb/lottie/parser/KeyframeParser
    //   2: monitorenter
    //   3: invokestatic pathInterpolatorCache : ()Landroidx/collection/SparseArrayCompat;
    //   6: iload_0
    //   7: invokevirtual get : (I)Ljava/lang/Object;
    //   10: checkcast java/lang/ref/WeakReference
    //   13: astore_1
    //   14: ldc com/airbnb/lottie/parser/KeyframeParser
    //   16: monitorexit
    //   17: aload_1
    //   18: areturn
    //   19: astore_1
    //   20: ldc com/airbnb/lottie/parser/KeyframeParser
    //   22: monitorexit
    //   23: aload_1
    //   24: athrow
    // Exception table:
    //   from	to	target	type
    //   3	17	19	finally
    //   20	23	19	finally
  }
  
  private static Interpolator interpolatorFor(PointF paramPointF1, PointF paramPointF2) {
    // Byte code:
    //   0: aload_0
    //   1: aload_0
    //   2: getfield x : F
    //   5: ldc -1.0
    //   7: fconst_1
    //   8: invokestatic clamp : (FFF)F
    //   11: putfield x : F
    //   14: aload_0
    //   15: aload_0
    //   16: getfield y : F
    //   19: ldc -100.0
    //   21: ldc 100.0
    //   23: invokestatic clamp : (FFF)F
    //   26: putfield y : F
    //   29: aload_1
    //   30: aload_1
    //   31: getfield x : F
    //   34: ldc -1.0
    //   36: fconst_1
    //   37: invokestatic clamp : (FFF)F
    //   40: putfield x : F
    //   43: aload_1
    //   44: getfield y : F
    //   47: ldc -100.0
    //   49: ldc 100.0
    //   51: invokestatic clamp : (FFF)F
    //   54: fstore_2
    //   55: aload_1
    //   56: fload_2
    //   57: putfield y : F
    //   60: aload_0
    //   61: getfield x : F
    //   64: aload_0
    //   65: getfield y : F
    //   68: aload_1
    //   69: getfield x : F
    //   72: fload_2
    //   73: invokestatic hashFor : (FFFF)I
    //   76: istore_3
    //   77: invokestatic getDisablePathInterpolatorCache : ()Z
    //   80: istore #4
    //   82: aconst_null
    //   83: astore #5
    //   85: iload #4
    //   87: ifeq -> 96
    //   90: aconst_null
    //   91: astore #6
    //   93: goto -> 102
    //   96: iload_3
    //   97: invokestatic getInterpolator : (I)Ljava/lang/ref/WeakReference;
    //   100: astore #6
    //   102: aload #6
    //   104: ifnull -> 117
    //   107: aload #6
    //   109: invokevirtual get : ()Ljava/lang/Object;
    //   112: checkcast android/view/animation/Interpolator
    //   115: astore #5
    //   117: aload #6
    //   119: ifnull -> 131
    //   122: aload #5
    //   124: astore #6
    //   126: aload #5
    //   128: ifnonnull -> 236
    //   131: aload_0
    //   132: getfield x : F
    //   135: aload_0
    //   136: getfield y : F
    //   139: aload_1
    //   140: getfield x : F
    //   143: aload_1
    //   144: getfield y : F
    //   147: invokestatic create : (FFFF)Landroid/view/animation/Interpolator;
    //   150: astore #5
    //   152: aload #5
    //   154: astore_0
    //   155: goto -> 212
    //   158: astore #5
    //   160: ldc 'The Path cannot loop back on itself.'
    //   162: aload #5
    //   164: invokevirtual getMessage : ()Ljava/lang/String;
    //   167: invokevirtual equals : (Ljava/lang/Object;)Z
    //   170: ifeq -> 204
    //   173: aload_0
    //   174: getfield x : F
    //   177: fconst_1
    //   178: invokestatic min : (FF)F
    //   181: aload_0
    //   182: getfield y : F
    //   185: aload_1
    //   186: getfield x : F
    //   189: fconst_0
    //   190: invokestatic max : (FF)F
    //   193: aload_1
    //   194: getfield y : F
    //   197: invokestatic create : (FFFF)Landroid/view/animation/Interpolator;
    //   200: astore_0
    //   201: goto -> 212
    //   204: new android/view/animation/LinearInterpolator
    //   207: dup
    //   208: invokespecial <init> : ()V
    //   211: astore_0
    //   212: aload_0
    //   213: astore #6
    //   215: invokestatic getDisablePathInterpolatorCache : ()Z
    //   218: ifne -> 236
    //   221: iload_3
    //   222: new java/lang/ref/WeakReference
    //   225: dup
    //   226: aload_0
    //   227: invokespecial <init> : (Ljava/lang/Object;)V
    //   230: invokestatic putInterpolator : (ILjava/lang/ref/WeakReference;)V
    //   233: aload_0
    //   234: astore #6
    //   236: aload #6
    //   238: areturn
    //   239: astore_1
    //   240: aload_0
    //   241: areturn
    // Exception table:
    //   from	to	target	type
    //   131	152	158	java/lang/IllegalArgumentException
    //   221	233	239	java/lang/ArrayIndexOutOfBoundsException
  }
  
  static <T> Keyframe<T> parse(JsonReader paramJsonReader, LottieComposition paramLottieComposition, float paramFloat, ValueParser<T> paramValueParser, boolean paramBoolean1, boolean paramBoolean2) throws IOException {
    return (paramBoolean1 && paramBoolean2) ? parseMultiDimensionalKeyframe(paramLottieComposition, paramJsonReader, paramFloat, paramValueParser) : (paramBoolean1 ? parseKeyframe(paramLottieComposition, paramJsonReader, paramFloat, paramValueParser) : parseStaticValue(paramJsonReader, paramFloat, paramValueParser));
  }
  
  private static <T> Keyframe<T> parseKeyframe(LottieComposition paramLottieComposition, JsonReader paramJsonReader, float paramFloat, ValueParser<T> paramValueParser) throws IOException {
    Interpolator interpolator;
    paramJsonReader.beginObject();
    PointF pointF4 = null;
    PointF pointF3 = null;
    Object object2 = pointF3;
    Object object1 = object2;
    PointF pointF1 = (PointF)object1;
    PointF pointF2 = pointF1;
    boolean bool = false;
    float f;
    for (f = 0.0F; paramJsonReader.hasNext(); f = (float)paramJsonReader.nextDouble()) {
      Object object;
      switch (paramJsonReader.selectName(NAMES)) {
        default:
          paramJsonReader.skipValue();
          continue;
        case 7:
          pointF2 = JsonUtils.jsonToPoint(paramJsonReader, paramFloat);
          continue;
        case 6:
          pointF1 = JsonUtils.jsonToPoint(paramJsonReader, paramFloat);
          continue;
        case 5:
          if (paramJsonReader.nextInt() == 1) {
            bool = true;
            continue;
          } 
          bool = false;
          continue;
        case 4:
          pointF3 = JsonUtils.jsonToPoint(paramJsonReader, 1.0F);
          continue;
        case 3:
          pointF4 = JsonUtils.jsonToPoint(paramJsonReader, 1.0F);
          continue;
        case 2:
          object = paramValueParser.parse(paramJsonReader, paramFloat);
          continue;
        case 1:
          object1 = paramValueParser.parse(paramJsonReader, paramFloat);
          continue;
        case 0:
          break;
      } 
    } 
    paramJsonReader.endObject();
    if (bool) {
      interpolator = LINEAR_INTERPOLATOR;
      object2 = object1;
    } else if (pointF4 != null && pointF3 != null) {
      interpolator = interpolatorFor(pointF4, pointF3);
    } else {
      interpolator = LINEAR_INTERPOLATOR;
    } 
    Keyframe<T> keyframe = new Keyframe(paramLottieComposition, object1, object2, interpolator, f, null);
    keyframe.pathCp1 = pointF1;
    keyframe.pathCp2 = pointF2;
    return keyframe;
  }
  
  private static <T> Keyframe<T> parseMultiDimensionalKeyframe(LottieComposition paramLottieComposition, JsonReader paramJsonReader, float paramFloat, ValueParser<T> paramValueParser) throws IOException {
    // Byte code:
    //   0: aload_1
    //   1: invokevirtual beginObject : ()V
    //   4: aconst_null
    //   5: astore #11
    //   7: iconst_0
    //   8: istore #9
    //   10: aconst_null
    //   11: astore #20
    //   13: aconst_null
    //   14: astore #19
    //   16: aconst_null
    //   17: astore #17
    //   19: aconst_null
    //   20: astore #14
    //   22: aconst_null
    //   23: astore #15
    //   25: aconst_null
    //   26: astore #18
    //   28: aconst_null
    //   29: astore #16
    //   31: fconst_0
    //   32: fstore #4
    //   34: aconst_null
    //   35: astore #12
    //   37: aconst_null
    //   38: astore #13
    //   40: aload_1
    //   41: invokevirtual hasNext : ()Z
    //   44: ifeq -> 681
    //   47: aload_1
    //   48: getstatic com/airbnb/lottie/parser/KeyframeParser.NAMES : Lcom/airbnb/lottie/parser/moshi/JsonReader$Options;
    //   51: invokevirtual selectName : (Lcom/airbnb/lottie/parser/moshi/JsonReader$Options;)I
    //   54: tableswitch default -> 100, 0 -> 671, 1 -> 658, 2 -> 645, 3 -> 396, 4 -> 147, 5 -> 127, 6 -> 117, 7 -> 107
    //   100: aload_1
    //   101: invokevirtual skipValue : ()V
    //   104: goto -> 678
    //   107: aload_1
    //   108: fload_2
    //   109: invokestatic jsonToPoint : (Lcom/airbnb/lottie/parser/moshi/JsonReader;F)Landroid/graphics/PointF;
    //   112: astore #11
    //   114: goto -> 40
    //   117: aload_1
    //   118: fload_2
    //   119: invokestatic jsonToPoint : (Lcom/airbnb/lottie/parser/moshi/JsonReader;F)Landroid/graphics/PointF;
    //   122: astore #12
    //   124: goto -> 40
    //   127: aload_1
    //   128: invokevirtual nextInt : ()I
    //   131: iconst_1
    //   132: if_icmpne -> 141
    //   135: iconst_1
    //   136: istore #9
    //   138: goto -> 40
    //   141: iconst_0
    //   142: istore #9
    //   144: goto -> 40
    //   147: aload_1
    //   148: invokevirtual peek : ()Lcom/airbnb/lottie/parser/moshi/JsonReader$Token;
    //   151: getstatic com/airbnb/lottie/parser/moshi/JsonReader$Token.BEGIN_OBJECT : Lcom/airbnb/lottie/parser/moshi/JsonReader$Token;
    //   154: if_acmpne -> 386
    //   157: aload_1
    //   158: invokevirtual beginObject : ()V
    //   161: fconst_0
    //   162: fstore #7
    //   164: fconst_0
    //   165: fstore #6
    //   167: fconst_0
    //   168: fstore #8
    //   170: fconst_0
    //   171: fstore #5
    //   173: aload_1
    //   174: invokevirtual hasNext : ()Z
    //   177: ifeq -> 353
    //   180: aload_1
    //   181: getstatic com/airbnb/lottie/parser/KeyframeParser.INTERPOLATOR_NAMES : Lcom/airbnb/lottie/parser/moshi/JsonReader$Options;
    //   184: invokevirtual selectName : (Lcom/airbnb/lottie/parser/moshi/JsonReader$Options;)I
    //   187: istore #10
    //   189: iload #10
    //   191: ifeq -> 280
    //   194: iload #10
    //   196: iconst_1
    //   197: if_icmpeq -> 207
    //   200: aload_1
    //   201: invokevirtual skipValue : ()V
    //   204: goto -> 173
    //   207: aload_1
    //   208: invokevirtual peek : ()Lcom/airbnb/lottie/parser/moshi/JsonReader$Token;
    //   211: astore #16
    //   213: getstatic com/airbnb/lottie/parser/moshi/JsonReader$Token.NUMBER : Lcom/airbnb/lottie/parser/moshi/JsonReader$Token;
    //   216: astore #18
    //   218: aload #16
    //   220: aload #18
    //   222: if_acmpne -> 239
    //   225: aload_1
    //   226: invokevirtual nextDouble : ()D
    //   229: d2f
    //   230: fstore #5
    //   232: fload #5
    //   234: fstore #6
    //   236: goto -> 204
    //   239: aload_1
    //   240: invokevirtual beginArray : ()V
    //   243: aload_1
    //   244: invokevirtual nextDouble : ()D
    //   247: d2f
    //   248: fstore #6
    //   250: aload_1
    //   251: invokevirtual peek : ()Lcom/airbnb/lottie/parser/moshi/JsonReader$Token;
    //   254: aload #18
    //   256: if_acmpne -> 269
    //   259: aload_1
    //   260: invokevirtual nextDouble : ()D
    //   263: d2f
    //   264: fstore #5
    //   266: goto -> 273
    //   269: fload #6
    //   271: fstore #5
    //   273: aload_1
    //   274: invokevirtual endArray : ()V
    //   277: goto -> 173
    //   280: aload_1
    //   281: invokevirtual peek : ()Lcom/airbnb/lottie/parser/moshi/JsonReader$Token;
    //   284: astore #16
    //   286: getstatic com/airbnb/lottie/parser/moshi/JsonReader$Token.NUMBER : Lcom/airbnb/lottie/parser/moshi/JsonReader$Token;
    //   289: astore #18
    //   291: aload #16
    //   293: aload #18
    //   295: if_acmpne -> 312
    //   298: aload_1
    //   299: invokevirtual nextDouble : ()D
    //   302: d2f
    //   303: fstore #8
    //   305: fload #8
    //   307: fstore #7
    //   309: goto -> 204
    //   312: aload_1
    //   313: invokevirtual beginArray : ()V
    //   316: aload_1
    //   317: invokevirtual nextDouble : ()D
    //   320: d2f
    //   321: fstore #7
    //   323: aload_1
    //   324: invokevirtual peek : ()Lcom/airbnb/lottie/parser/moshi/JsonReader$Token;
    //   327: aload #18
    //   329: if_acmpne -> 342
    //   332: aload_1
    //   333: invokevirtual nextDouble : ()D
    //   336: d2f
    //   337: fstore #8
    //   339: goto -> 346
    //   342: fload #7
    //   344: fstore #8
    //   346: aload_1
    //   347: invokevirtual endArray : ()V
    //   350: goto -> 204
    //   353: new android/graphics/PointF
    //   356: dup
    //   357: fload #7
    //   359: fload #6
    //   361: invokespecial <init> : (FF)V
    //   364: astore #18
    //   366: new android/graphics/PointF
    //   369: dup
    //   370: fload #8
    //   372: fload #5
    //   374: invokespecial <init> : (FF)V
    //   377: astore #16
    //   379: aload_1
    //   380: invokevirtual endObject : ()V
    //   383: goto -> 632
    //   386: aload_1
    //   387: fload_2
    //   388: invokestatic jsonToPoint : (Lcom/airbnb/lottie/parser/moshi/JsonReader;F)Landroid/graphics/PointF;
    //   391: astore #19
    //   393: goto -> 678
    //   396: aload_1
    //   397: invokevirtual peek : ()Lcom/airbnb/lottie/parser/moshi/JsonReader$Token;
    //   400: getstatic com/airbnb/lottie/parser/moshi/JsonReader$Token.BEGIN_OBJECT : Lcom/airbnb/lottie/parser/moshi/JsonReader$Token;
    //   403: if_acmpne -> 635
    //   406: aload_1
    //   407: invokevirtual beginObject : ()V
    //   410: fconst_0
    //   411: fstore #7
    //   413: fconst_0
    //   414: fstore #5
    //   416: fconst_0
    //   417: fstore #8
    //   419: fconst_0
    //   420: fstore #6
    //   422: aload_1
    //   423: invokevirtual hasNext : ()Z
    //   426: ifeq -> 602
    //   429: aload_1
    //   430: getstatic com/airbnb/lottie/parser/KeyframeParser.INTERPOLATOR_NAMES : Lcom/airbnb/lottie/parser/moshi/JsonReader$Options;
    //   433: invokevirtual selectName : (Lcom/airbnb/lottie/parser/moshi/JsonReader$Options;)I
    //   436: istore #10
    //   438: iload #10
    //   440: ifeq -> 529
    //   443: iload #10
    //   445: iconst_1
    //   446: if_icmpeq -> 456
    //   449: aload_1
    //   450: invokevirtual skipValue : ()V
    //   453: goto -> 422
    //   456: aload_1
    //   457: invokevirtual peek : ()Lcom/airbnb/lottie/parser/moshi/JsonReader$Token;
    //   460: astore #15
    //   462: getstatic com/airbnb/lottie/parser/moshi/JsonReader$Token.NUMBER : Lcom/airbnb/lottie/parser/moshi/JsonReader$Token;
    //   465: astore #17
    //   467: aload #15
    //   469: aload #17
    //   471: if_acmpne -> 488
    //   474: aload_1
    //   475: invokevirtual nextDouble : ()D
    //   478: d2f
    //   479: fstore #6
    //   481: fload #6
    //   483: fstore #5
    //   485: goto -> 422
    //   488: aload_1
    //   489: invokevirtual beginArray : ()V
    //   492: aload_1
    //   493: invokevirtual nextDouble : ()D
    //   496: d2f
    //   497: fstore #5
    //   499: aload_1
    //   500: invokevirtual peek : ()Lcom/airbnb/lottie/parser/moshi/JsonReader$Token;
    //   503: aload #17
    //   505: if_acmpne -> 518
    //   508: aload_1
    //   509: invokevirtual nextDouble : ()D
    //   512: d2f
    //   513: fstore #6
    //   515: goto -> 522
    //   518: fload #5
    //   520: fstore #6
    //   522: aload_1
    //   523: invokevirtual endArray : ()V
    //   526: goto -> 422
    //   529: aload_1
    //   530: invokevirtual peek : ()Lcom/airbnb/lottie/parser/moshi/JsonReader$Token;
    //   533: astore #15
    //   535: getstatic com/airbnb/lottie/parser/moshi/JsonReader$Token.NUMBER : Lcom/airbnb/lottie/parser/moshi/JsonReader$Token;
    //   538: astore #17
    //   540: aload #15
    //   542: aload #17
    //   544: if_acmpne -> 561
    //   547: aload_1
    //   548: invokevirtual nextDouble : ()D
    //   551: d2f
    //   552: fstore #8
    //   554: fload #8
    //   556: fstore #7
    //   558: goto -> 422
    //   561: aload_1
    //   562: invokevirtual beginArray : ()V
    //   565: aload_1
    //   566: invokevirtual nextDouble : ()D
    //   569: d2f
    //   570: fstore #7
    //   572: aload_1
    //   573: invokevirtual peek : ()Lcom/airbnb/lottie/parser/moshi/JsonReader$Token;
    //   576: aload #17
    //   578: if_acmpne -> 591
    //   581: aload_1
    //   582: invokevirtual nextDouble : ()D
    //   585: d2f
    //   586: fstore #8
    //   588: goto -> 595
    //   591: fload #7
    //   593: fstore #8
    //   595: aload_1
    //   596: invokevirtual endArray : ()V
    //   599: goto -> 422
    //   602: new android/graphics/PointF
    //   605: dup
    //   606: fload #7
    //   608: fload #5
    //   610: invokespecial <init> : (FF)V
    //   613: astore #17
    //   615: new android/graphics/PointF
    //   618: dup
    //   619: fload #8
    //   621: fload #6
    //   623: invokespecial <init> : (FF)V
    //   626: astore #15
    //   628: aload_1
    //   629: invokevirtual endObject : ()V
    //   632: goto -> 678
    //   635: aload_1
    //   636: fload_2
    //   637: invokestatic jsonToPoint : (Lcom/airbnb/lottie/parser/moshi/JsonReader;F)Landroid/graphics/PointF;
    //   640: astore #20
    //   642: goto -> 678
    //   645: aload_3
    //   646: aload_1
    //   647: fload_2
    //   648: invokeinterface parse : (Lcom/airbnb/lottie/parser/moshi/JsonReader;F)Ljava/lang/Object;
    //   653: astore #13
    //   655: goto -> 678
    //   658: aload_3
    //   659: aload_1
    //   660: fload_2
    //   661: invokeinterface parse : (Lcom/airbnb/lottie/parser/moshi/JsonReader;F)Ljava/lang/Object;
    //   666: astore #14
    //   668: goto -> 678
    //   671: aload_1
    //   672: invokevirtual nextDouble : ()D
    //   675: d2f
    //   676: fstore #4
    //   678: goto -> 40
    //   681: aload_1
    //   682: invokevirtual endObject : ()V
    //   685: iload #9
    //   687: ifeq -> 712
    //   690: getstatic com/airbnb/lottie/parser/KeyframeParser.LINEAR_INTERPOLATOR : Landroid/view/animation/Interpolator;
    //   693: astore_3
    //   694: aload #14
    //   696: astore_1
    //   697: aconst_null
    //   698: astore #16
    //   700: aconst_null
    //   701: astore #15
    //   703: aload_1
    //   704: astore #13
    //   706: aload #16
    //   708: astore_1
    //   709: goto -> 785
    //   712: aload #20
    //   714: ifnull -> 733
    //   717: aload #19
    //   719: ifnull -> 733
    //   722: aload #20
    //   724: aload #19
    //   726: invokestatic interpolatorFor : (Landroid/graphics/PointF;Landroid/graphics/PointF;)Landroid/view/animation/Interpolator;
    //   729: astore_3
    //   730: goto -> 779
    //   733: aload #17
    //   735: ifnull -> 775
    //   738: aload #15
    //   740: ifnull -> 775
    //   743: aload #18
    //   745: ifnull -> 775
    //   748: aload #16
    //   750: ifnull -> 775
    //   753: aload #17
    //   755: aload #18
    //   757: invokestatic interpolatorFor : (Landroid/graphics/PointF;Landroid/graphics/PointF;)Landroid/view/animation/Interpolator;
    //   760: astore_1
    //   761: aload #15
    //   763: aload #16
    //   765: invokestatic interpolatorFor : (Landroid/graphics/PointF;Landroid/graphics/PointF;)Landroid/view/animation/Interpolator;
    //   768: astore #15
    //   770: aconst_null
    //   771: astore_3
    //   772: goto -> 785
    //   775: getstatic com/airbnb/lottie/parser/KeyframeParser.LINEAR_INTERPOLATOR : Landroid/view/animation/Interpolator;
    //   778: astore_3
    //   779: aload #13
    //   781: astore_1
    //   782: goto -> 697
    //   785: aload_1
    //   786: ifnull -> 816
    //   789: aload #15
    //   791: ifnull -> 816
    //   794: new com/airbnb/lottie/value/Keyframe
    //   797: dup
    //   798: aload_0
    //   799: aload #14
    //   801: aload #13
    //   803: aload_1
    //   804: aload #15
    //   806: fload #4
    //   808: aconst_null
    //   809: invokespecial <init> : (Lcom/airbnb/lottie/LottieComposition;Ljava/lang/Object;Ljava/lang/Object;Landroid/view/animation/Interpolator;Landroid/view/animation/Interpolator;FLjava/lang/Float;)V
    //   812: astore_0
    //   813: goto -> 833
    //   816: new com/airbnb/lottie/value/Keyframe
    //   819: dup
    //   820: aload_0
    //   821: aload #14
    //   823: aload #13
    //   825: aload_3
    //   826: fload #4
    //   828: aconst_null
    //   829: invokespecial <init> : (Lcom/airbnb/lottie/LottieComposition;Ljava/lang/Object;Ljava/lang/Object;Landroid/view/animation/Interpolator;FLjava/lang/Float;)V
    //   832: astore_0
    //   833: aload_0
    //   834: aload #12
    //   836: putfield pathCp1 : Landroid/graphics/PointF;
    //   839: aload_0
    //   840: aload #11
    //   842: putfield pathCp2 : Landroid/graphics/PointF;
    //   845: aload_0
    //   846: areturn
  }
  
  private static <T> Keyframe<T> parseStaticValue(JsonReader paramJsonReader, float paramFloat, ValueParser<T> paramValueParser) throws IOException {
    return new Keyframe(paramValueParser.parse(paramJsonReader, paramFloat));
  }
  
  private static SparseArrayCompat<WeakReference<Interpolator>> pathInterpolatorCache() {
    if (pathInterpolatorCache == null)
      pathInterpolatorCache = new SparseArrayCompat(); 
    return pathInterpolatorCache;
  }
  
  private static void putInterpolator(int paramInt, WeakReference<Interpolator> paramWeakReference) {
    // Byte code:
    //   0: ldc com/airbnb/lottie/parser/KeyframeParser
    //   2: monitorenter
    //   3: getstatic com/airbnb/lottie/parser/KeyframeParser.pathInterpolatorCache : Landroidx/collection/SparseArrayCompat;
    //   6: iload_0
    //   7: aload_1
    //   8: invokevirtual put : (ILjava/lang/Object;)V
    //   11: ldc com/airbnb/lottie/parser/KeyframeParser
    //   13: monitorexit
    //   14: return
    //   15: astore_1
    //   16: ldc com/airbnb/lottie/parser/KeyframeParser
    //   18: monitorexit
    //   19: aload_1
    //   20: athrow
    // Exception table:
    //   from	to	target	type
    //   3	14	15	finally
    //   16	19	15	finally
  }
}


/* Location:              C:\soft\dex2jar-2.0\MagicAI - AI Art & Anime Art-dex2jar.jar!\com\airbnb\lottie\parser\KeyframeParser.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */