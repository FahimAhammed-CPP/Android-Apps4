package com.airbnb.lottie.animation.content;

import com.airbnb.lottie.model.KeyPathElement;

public interface KeyPathElementContent extends KeyPathElement, Content {}


/* Location:              C:\soft\dex2jar-2.0\MagicAI - AI Art & Anime Art-dex2jar.jar!\com\airbnb\lottie\animation\content\KeyPathElementContent.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */