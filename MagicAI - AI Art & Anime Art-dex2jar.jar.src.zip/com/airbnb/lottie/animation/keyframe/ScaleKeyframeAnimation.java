package com.airbnb.lottie.animation.keyframe;

import com.airbnb.lottie.utils.MiscUtils;
import com.airbnb.lottie.value.Keyframe;
import com.airbnb.lottie.value.LottieValueCallback;
import com.airbnb.lottie.value.ScaleXY;
import java.util.List;

public class ScaleKeyframeAnimation extends KeyframeAnimation<ScaleXY> {
  private final ScaleXY scaleXY = new ScaleXY();
  
  public ScaleKeyframeAnimation(List<Keyframe<ScaleXY>> paramList) {
    super(paramList);
  }
  
  public ScaleXY getValue(Keyframe<ScaleXY> paramKeyframe, float paramFloat) {
    Object object = paramKeyframe.startValue;
    if (object != null) {
      Object object1 = paramKeyframe.endValue;
      if (object1 != null) {
        object = object;
        object1 = object1;
        LottieValueCallback lottieValueCallback = ((BaseKeyframeAnimation)this).valueCallback;
        if (lottieValueCallback != null) {
          ScaleXY scaleXY = (ScaleXY)lottieValueCallback.getValueInternal(paramKeyframe.startFrame, paramKeyframe.endFrame.floatValue(), object, object1, paramFloat, getLinearCurrentKeyframeProgress(), getProgress());
          if (scaleXY != null)
            return scaleXY; 
        } 
        this.scaleXY.set(MiscUtils.lerp(object.getScaleX(), object1.getScaleX(), paramFloat), MiscUtils.lerp(object.getScaleY(), object1.getScaleY(), paramFloat));
        return this.scaleXY;
      } 
    } 
    throw new IllegalStateException("Missing values for keyframe.");
  }
}


/* Location:              C:\soft\dex2jar-2.0\MagicAI - AI Art & Anime Art-dex2jar.jar!\com\airbnb\lottie\animation\keyframe\ScaleKeyframeAnimation.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */