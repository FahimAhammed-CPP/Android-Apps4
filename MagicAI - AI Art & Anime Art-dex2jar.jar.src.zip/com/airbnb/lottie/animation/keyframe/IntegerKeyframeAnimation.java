package com.airbnb.lottie.animation.keyframe;

import com.airbnb.lottie.utils.MiscUtils;
import com.airbnb.lottie.value.Keyframe;
import com.airbnb.lottie.value.LottieValueCallback;
import java.util.List;

public class IntegerKeyframeAnimation extends KeyframeAnimation<Integer> {
  public IntegerKeyframeAnimation(List<Keyframe<Integer>> paramList) {
    super(paramList);
  }
  
  public int getIntValue() {
    return getIntValue(getCurrentKeyframe(), getInterpolatedCurrentKeyframeProgress());
  }
  
  int getIntValue(Keyframe<Integer> paramKeyframe, float paramFloat) {
    if (paramKeyframe.startValue != null && paramKeyframe.endValue != null) {
      LottieValueCallback lottieValueCallback = ((BaseKeyframeAnimation)this).valueCallback;
      if (lottieValueCallback != null) {
        Integer integer = (Integer)lottieValueCallback.getValueInternal(paramKeyframe.startFrame, paramKeyframe.endFrame.floatValue(), paramKeyframe.startValue, paramKeyframe.endValue, paramFloat, getLinearCurrentKeyframeProgress(), getProgress());
        if (integer != null)
          return integer.intValue(); 
      } 
      return MiscUtils.lerp(paramKeyframe.getStartValueInt(), paramKeyframe.getEndValueInt(), paramFloat);
    } 
    throw new IllegalStateException("Missing values for keyframe.");
  }
  
  Integer getValue(Keyframe<Integer> paramKeyframe, float paramFloat) {
    return Integer.valueOf(getIntValue(paramKeyframe, paramFloat));
  }
}


/* Location:              C:\soft\dex2jar-2.0\MagicAI - AI Art & Anime Art-dex2jar.jar!\com\airbnb\lottie\animation\keyframe\IntegerKeyframeAnimation.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */