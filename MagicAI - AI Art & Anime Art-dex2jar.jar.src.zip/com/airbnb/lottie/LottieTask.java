package com.airbnb.lottie;

import android.os.Handler;
import android.os.Looper;
import androidx.annotation.Nullable;
import androidx.annotation.RestrictTo;
import java.util.LinkedHashSet;
import java.util.Set;
import java.util.concurrent.Callable;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.Executor;
import java.util.concurrent.Executors;
import java.util.concurrent.FutureTask;

public class LottieTask<T> {
  public static Executor EXECUTOR = Executors.newCachedThreadPool();
  
  private final Set<LottieListener<Throwable>> failureListeners = new LinkedHashSet<LottieListener<Throwable>>(1);
  
  private final Handler handler = new Handler(Looper.getMainLooper());
  
  @Nullable
  private volatile LottieResult<T> result = null;
  
  private final Set<LottieListener<T>> successListeners = new LinkedHashSet<LottieListener<T>>(1);
  
  @RestrictTo({RestrictTo.Scope.LIBRARY})
  public LottieTask(Callable<LottieResult<T>> paramCallable) {
    this(paramCallable, false);
  }
  
  @RestrictTo({RestrictTo.Scope.LIBRARY})
  LottieTask(Callable<LottieResult<T>> paramCallable, boolean paramBoolean) {
    if (paramBoolean)
      try {
        return;
      } finally {
        paramCallable = null;
        setResult(new LottieResult((Throwable)paramCallable));
      }  
    EXECUTOR.execute(new LottieFutureTask(paramCallable));
  }
  
  private void notifyFailureListeners(Throwable paramThrowable) {
    // Byte code:
    //   0: aload_0
    //   1: monitorenter
    //   2: new java/util/ArrayList
    //   5: dup
    //   6: aload_0
    //   7: getfield failureListeners : Ljava/util/Set;
    //   10: invokespecial <init> : (Ljava/util/Collection;)V
    //   13: astore_2
    //   14: aload_2
    //   15: invokeinterface isEmpty : ()Z
    //   20: ifeq -> 32
    //   23: ldc 'Lottie encountered an error but no failure listener was added:'
    //   25: aload_1
    //   26: invokestatic warning : (Ljava/lang/String;Ljava/lang/Throwable;)V
    //   29: aload_0
    //   30: monitorexit
    //   31: return
    //   32: aload_2
    //   33: invokeinterface iterator : ()Ljava/util/Iterator;
    //   38: astore_2
    //   39: aload_2
    //   40: invokeinterface hasNext : ()Z
    //   45: ifeq -> 66
    //   48: aload_2
    //   49: invokeinterface next : ()Ljava/lang/Object;
    //   54: checkcast com/airbnb/lottie/LottieListener
    //   57: aload_1
    //   58: invokeinterface onResult : (Ljava/lang/Object;)V
    //   63: goto -> 39
    //   66: aload_0
    //   67: monitorexit
    //   68: return
    //   69: astore_1
    //   70: aload_0
    //   71: monitorexit
    //   72: aload_1
    //   73: athrow
    // Exception table:
    //   from	to	target	type
    //   2	29	69	finally
    //   32	39	69	finally
    //   39	63	69	finally
  }
  
  private void notifyListeners() {
    this.handler.post((Runnable)new LottieTask$.ExternalSyntheticLambda0(this));
  }
  
  private void notifySuccessListeners(T paramT) {
    // Byte code:
    //   0: aload_0
    //   1: monitorenter
    //   2: new java/util/ArrayList
    //   5: dup
    //   6: aload_0
    //   7: getfield successListeners : Ljava/util/Set;
    //   10: invokespecial <init> : (Ljava/util/Collection;)V
    //   13: invokeinterface iterator : ()Ljava/util/Iterator;
    //   18: astore_2
    //   19: aload_2
    //   20: invokeinterface hasNext : ()Z
    //   25: ifeq -> 46
    //   28: aload_2
    //   29: invokeinterface next : ()Ljava/lang/Object;
    //   34: checkcast com/airbnb/lottie/LottieListener
    //   37: aload_1
    //   38: invokeinterface onResult : (Ljava/lang/Object;)V
    //   43: goto -> 19
    //   46: aload_0
    //   47: monitorexit
    //   48: return
    //   49: astore_1
    //   50: aload_0
    //   51: monitorexit
    //   52: aload_1
    //   53: athrow
    // Exception table:
    //   from	to	target	type
    //   2	19	49	finally
    //   19	43	49	finally
  }
  
  private void setResult(@Nullable LottieResult<T> paramLottieResult) {
    if (this.result == null) {
      this.result = paramLottieResult;
      notifyListeners();
      return;
    } 
    throw new IllegalStateException("A task may only be set once.");
  }
  
  public LottieTask<T> addFailureListener(LottieListener<Throwable> paramLottieListener) {
    // Byte code:
    //   0: aload_0
    //   1: monitorenter
    //   2: aload_0
    //   3: getfield result : Lcom/airbnb/lottie/LottieResult;
    //   6: astore_2
    //   7: aload_2
    //   8: ifnull -> 28
    //   11: aload_2
    //   12: invokevirtual getException : ()Ljava/lang/Throwable;
    //   15: ifnull -> 28
    //   18: aload_1
    //   19: aload_2
    //   20: invokevirtual getException : ()Ljava/lang/Throwable;
    //   23: invokeinterface onResult : (Ljava/lang/Object;)V
    //   28: aload_0
    //   29: getfield failureListeners : Ljava/util/Set;
    //   32: aload_1
    //   33: invokeinterface add : (Ljava/lang/Object;)Z
    //   38: pop
    //   39: aload_0
    //   40: monitorexit
    //   41: aload_0
    //   42: areturn
    //   43: astore_1
    //   44: aload_0
    //   45: monitorexit
    //   46: aload_1
    //   47: athrow
    // Exception table:
    //   from	to	target	type
    //   2	7	43	finally
    //   11	28	43	finally
    //   28	39	43	finally
  }
  
  public LottieTask<T> addListener(LottieListener<T> paramLottieListener) {
    // Byte code:
    //   0: aload_0
    //   1: monitorenter
    //   2: aload_0
    //   3: getfield result : Lcom/airbnb/lottie/LottieResult;
    //   6: astore_2
    //   7: aload_2
    //   8: ifnull -> 28
    //   11: aload_2
    //   12: invokevirtual getValue : ()Ljava/lang/Object;
    //   15: ifnull -> 28
    //   18: aload_1
    //   19: aload_2
    //   20: invokevirtual getValue : ()Ljava/lang/Object;
    //   23: invokeinterface onResult : (Ljava/lang/Object;)V
    //   28: aload_0
    //   29: getfield successListeners : Ljava/util/Set;
    //   32: aload_1
    //   33: invokeinterface add : (Ljava/lang/Object;)Z
    //   38: pop
    //   39: aload_0
    //   40: monitorexit
    //   41: aload_0
    //   42: areturn
    //   43: astore_1
    //   44: aload_0
    //   45: monitorexit
    //   46: aload_1
    //   47: athrow
    // Exception table:
    //   from	to	target	type
    //   2	7	43	finally
    //   11	28	43	finally
    //   28	39	43	finally
  }
  
  public LottieTask<T> removeFailureListener(LottieListener<Throwable> paramLottieListener) {
    // Byte code:
    //   0: aload_0
    //   1: monitorenter
    //   2: aload_0
    //   3: getfield failureListeners : Ljava/util/Set;
    //   6: aload_1
    //   7: invokeinterface remove : (Ljava/lang/Object;)Z
    //   12: pop
    //   13: aload_0
    //   14: monitorexit
    //   15: aload_0
    //   16: areturn
    //   17: astore_1
    //   18: aload_0
    //   19: monitorexit
    //   20: aload_1
    //   21: athrow
    // Exception table:
    //   from	to	target	type
    //   2	13	17	finally
  }
  
  public LottieTask<T> removeListener(LottieListener<T> paramLottieListener) {
    // Byte code:
    //   0: aload_0
    //   1: monitorenter
    //   2: aload_0
    //   3: getfield successListeners : Ljava/util/Set;
    //   6: aload_1
    //   7: invokeinterface remove : (Ljava/lang/Object;)Z
    //   12: pop
    //   13: aload_0
    //   14: monitorexit
    //   15: aload_0
    //   16: areturn
    //   17: astore_1
    //   18: aload_0
    //   19: monitorexit
    //   20: aload_1
    //   21: athrow
    // Exception table:
    //   from	to	target	type
    //   2	13	17	finally
  }
  
  private class LottieFutureTask extends FutureTask<LottieResult<T>> {
    LottieFutureTask(Callable<LottieResult<T>> param1Callable) {
      super(param1Callable);
    }
    
    protected void done() {
      if (isCancelled())
        return; 
      try {
        LottieTask.this.setResult((LottieResult)get());
        return;
      } catch (InterruptedException interruptedException) {
      
      } catch (ExecutionException executionException) {}
      LottieTask.this.setResult(new LottieResult(executionException));
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\MagicAI - AI Art & Anime Art-dex2jar.jar!\com\airbnb\lottie\LottieTask.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */