package com.airbnb.lottie;

import android.animation.ValueAnimator;
import android.annotation.SuppressLint;
import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.ColorFilter;
import android.graphics.Matrix;
import android.graphics.Paint;
import android.graphics.Rect;
import android.graphics.RectF;
import android.graphics.Typeface;
import android.graphics.drawable.Animatable;
import android.graphics.drawable.Drawable;
import android.os.Build;
import android.view.View;
import android.view.ViewGroup;
import android.view.ViewParent;
import android.widget.ImageView;
import androidx.annotation.FloatRange;
import androidx.annotation.IntRange;
import androidx.annotation.MainThread;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.annotation.RestrictTo;
import com.airbnb.lottie.animation.LPaint;
import com.airbnb.lottie.manager.FontAssetManager;
import com.airbnb.lottie.manager.ImageAssetManager;
import com.airbnb.lottie.model.Font;
import com.airbnb.lottie.model.KeyPath;
import com.airbnb.lottie.model.Marker;
import com.airbnb.lottie.model.layer.CompositionLayer;
import com.airbnb.lottie.parser.LayerParser;
import com.airbnb.lottie.utils.Logger;
import com.airbnb.lottie.utils.LottieThreadFactory;
import com.airbnb.lottie.utils.LottieValueAnimator;
import com.airbnb.lottie.utils.MiscUtils;
import com.airbnb.lottie.value.LottieValueCallback;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.concurrent.Executor;
import java.util.concurrent.LinkedBlockingQueue;
import java.util.concurrent.Semaphore;
import java.util.concurrent.ThreadFactory;
import java.util.concurrent.ThreadPoolExecutor;
import java.util.concurrent.TimeUnit;

public class LottieDrawable extends Drawable implements Drawable.Callback, Animatable {
  private static final Executor setProgressExecutor = new ThreadPoolExecutor(0, 2, 35L, TimeUnit.MILLISECONDS, new LinkedBlockingQueue<Runnable>(), (ThreadFactory)new LottieThreadFactory());
  
  private int alpha;
  
  private final LottieValueAnimator animator;
  
  private AsyncUpdates asyncUpdates;
  
  private Rect canvasClipBounds;
  
  private RectF canvasClipBoundsRectF;
  
  private boolean clipToCompositionBounds;
  
  private LottieComposition composition;
  
  @Nullable
  private CompositionLayer compositionLayer;
  
  @Nullable
  String defaultFontFileExtension;
  
  private boolean enableMergePaths;
  
  @Nullable
  private FontAssetManager fontAssetManager;
  
  @Nullable
  private Map<String, Typeface> fontMap;
  
  private boolean ignoreSystemAnimationsDisabled;
  
  @Nullable
  private ImageAssetManager imageAssetManager;
  
  @Nullable
  private String imageAssetsFolder;
  
  private boolean isApplyingOpacityToLayersEnabled;
  
  private boolean isDirty;
  
  private float lastDrawnProgress;
  
  private final ArrayList<LazyCompositionTask> lazyCompositionTasks;
  
  private boolean maintainOriginalImageBounds;
  
  private OnVisibleAction onVisibleAction;
  
  private boolean outlineMasksAndMattes;
  
  private boolean performanceTrackingEnabled;
  
  private final ValueAnimator.AnimatorUpdateListener progressUpdateListener;
  
  private RenderMode renderMode;
  
  private final Matrix renderingMatrix;
  
  private boolean safeMode;
  
  private final Semaphore setProgressDrawLock;
  
  private Bitmap softwareRenderingBitmap;
  
  private Canvas softwareRenderingCanvas;
  
  private Rect softwareRenderingDstBoundsRect;
  
  private RectF softwareRenderingDstBoundsRectF;
  
  private Matrix softwareRenderingOriginalCanvasMatrix;
  
  private Matrix softwareRenderingOriginalCanvasMatrixInverse;
  
  private Paint softwareRenderingPaint;
  
  private Rect softwareRenderingSrcBoundsRect;
  
  private RectF softwareRenderingTransformedBounds;
  
  private boolean systemAnimationsEnabled;
  
  private final Runnable updateProgressRunnable;
  
  private boolean useSoftwareRendering;
  
  public LottieDrawable() {
    LottieValueAnimator lottieValueAnimator = new LottieValueAnimator();
    this.animator = lottieValueAnimator;
    this.systemAnimationsEnabled = true;
    this.ignoreSystemAnimationsDisabled = false;
    this.safeMode = false;
    this.onVisibleAction = OnVisibleAction.NONE;
    this.lazyCompositionTasks = new ArrayList<LazyCompositionTask>();
    this.maintainOriginalImageBounds = false;
    this.clipToCompositionBounds = true;
    this.alpha = 255;
    this.renderMode = RenderMode.AUTOMATIC;
    this.useSoftwareRendering = false;
    this.renderingMatrix = new Matrix();
    this.asyncUpdates = AsyncUpdates.AUTOMATIC;
    LottieDrawable$.ExternalSyntheticLambda0 externalSyntheticLambda0 = new LottieDrawable$.ExternalSyntheticLambda0(this);
    this.progressUpdateListener = (ValueAnimator.AnimatorUpdateListener)externalSyntheticLambda0;
    this.setProgressDrawLock = new Semaphore(1);
    this.updateProgressRunnable = (Runnable)new LottieDrawable$.ExternalSyntheticLambda1(this);
    this.lastDrawnProgress = -3.4028235E38F;
    this.isDirty = false;
    lottieValueAnimator.addUpdateListener((ValueAnimator.AnimatorUpdateListener)externalSyntheticLambda0);
  }
  
  private boolean animationsEnabled() {
    return (this.systemAnimationsEnabled || this.ignoreSystemAnimationsDisabled);
  }
  
  private void buildCompositionLayer() {
    LottieComposition lottieComposition = this.composition;
    if (lottieComposition == null)
      return; 
    CompositionLayer compositionLayer = new CompositionLayer(this, LayerParser.parse(lottieComposition), lottieComposition.getLayers(), lottieComposition);
    this.compositionLayer = compositionLayer;
    if (this.outlineMasksAndMattes)
      compositionLayer.setOutlineMasksAndMattes(true); 
    this.compositionLayer.setClipToCompositionBounds(this.clipToCompositionBounds);
  }
  
  private void computeRenderMode() {
    LottieComposition lottieComposition = this.composition;
    if (lottieComposition == null)
      return; 
    this.useSoftwareRendering = this.renderMode.useSoftwareRendering(Build.VERSION.SDK_INT, lottieComposition.hasDashPattern(), lottieComposition.getMaskAndMatteCount());
  }
  
  private void convertRect(Rect paramRect, RectF paramRectF) {
    paramRectF.set(paramRect.left, paramRect.top, paramRect.right, paramRect.bottom);
  }
  
  private void convertRect(RectF paramRectF, Rect paramRect) {
    paramRect.set((int)Math.floor(paramRectF.left), (int)Math.floor(paramRectF.top), (int)Math.ceil(paramRectF.right), (int)Math.ceil(paramRectF.bottom));
  }
  
  private void drawDirectlyToCanvas(Canvas paramCanvas) {
    CompositionLayer compositionLayer = this.compositionLayer;
    LottieComposition lottieComposition = this.composition;
    if (compositionLayer != null) {
      if (lottieComposition == null)
        return; 
      this.renderingMatrix.reset();
      Rect rect = getBounds();
      if (!rect.isEmpty()) {
        float f1 = rect.width() / lottieComposition.getBounds().width();
        float f2 = rect.height() / lottieComposition.getBounds().height();
        this.renderingMatrix.preScale(f1, f2);
        this.renderingMatrix.preTranslate(rect.left, rect.top);
      } 
      compositionLayer.draw(paramCanvas, this.renderingMatrix, this.alpha);
    } 
  }
  
  private void ensureSoftwareRenderingBitmap(int paramInt1, int paramInt2) {
    Bitmap bitmap = this.softwareRenderingBitmap;
    if (bitmap == null || bitmap.getWidth() < paramInt1 || this.softwareRenderingBitmap.getHeight() < paramInt2) {
      bitmap = Bitmap.createBitmap(paramInt1, paramInt2, Bitmap.Config.ARGB_8888);
      this.softwareRenderingBitmap = bitmap;
      this.softwareRenderingCanvas.setBitmap(bitmap);
      this.isDirty = true;
      return;
    } 
    if (this.softwareRenderingBitmap.getWidth() > paramInt1 || this.softwareRenderingBitmap.getHeight() > paramInt2) {
      bitmap = Bitmap.createBitmap(this.softwareRenderingBitmap, 0, 0, paramInt1, paramInt2);
      this.softwareRenderingBitmap = bitmap;
      this.softwareRenderingCanvas.setBitmap(bitmap);
      this.isDirty = true;
      return;
    } 
  }
  
  private void ensureSoftwareRenderingObjectsInitialized() {
    if (this.softwareRenderingCanvas != null)
      return; 
    this.softwareRenderingCanvas = new Canvas();
    this.softwareRenderingTransformedBounds = new RectF();
    this.softwareRenderingOriginalCanvasMatrix = new Matrix();
    this.softwareRenderingOriginalCanvasMatrixInverse = new Matrix();
    this.canvasClipBounds = new Rect();
    this.canvasClipBoundsRectF = new RectF();
    this.softwareRenderingPaint = (Paint)new LPaint();
    this.softwareRenderingSrcBoundsRect = new Rect();
    this.softwareRenderingDstBoundsRect = new Rect();
    this.softwareRenderingDstBoundsRectF = new RectF();
  }
  
  @Nullable
  private Context getContext() {
    Drawable.Callback callback = getCallback();
    return (callback == null) ? null : ((callback instanceof View) ? ((View)callback).getContext() : null);
  }
  
  private FontAssetManager getFontAssetManager() {
    if (getCallback() == null)
      return null; 
    if (this.fontAssetManager == null) {
      FontAssetManager fontAssetManager = new FontAssetManager(getCallback(), null);
      this.fontAssetManager = fontAssetManager;
      String str = this.defaultFontFileExtension;
      if (str != null)
        fontAssetManager.setDefaultFontFileExtension(str); 
    } 
    return this.fontAssetManager;
  }
  
  private ImageAssetManager getImageAssetManager() {
    ImageAssetManager imageAssetManager = this.imageAssetManager;
    if (imageAssetManager != null && !imageAssetManager.hasSameContext(getContext()))
      this.imageAssetManager = null; 
    if (this.imageAssetManager == null)
      this.imageAssetManager = new ImageAssetManager(getCallback(), this.imageAssetsFolder, null, this.composition.getImages()); 
    return this.imageAssetManager;
  }
  
  private boolean ignoreCanvasClipBounds() {
    Drawable.Callback callback = getCallback();
    if (!(callback instanceof View))
      return false; 
    ViewParent viewParent = ((View)callback).getParent();
    return (viewParent instanceof ViewGroup) ? (((ViewGroup)viewParent).getClipChildren() ^ true) : false;
  }
  
  private void renderAndDrawAsBitmap(Canvas paramCanvas, CompositionLayer paramCompositionLayer) {
    if (this.composition != null) {
      if (paramCompositionLayer == null)
        return; 
      ensureSoftwareRenderingObjectsInitialized();
      paramCanvas.getMatrix(this.softwareRenderingOriginalCanvasMatrix);
      paramCanvas.getClipBounds(this.canvasClipBounds);
      convertRect(this.canvasClipBounds, this.canvasClipBoundsRectF);
      this.softwareRenderingOriginalCanvasMatrix.mapRect(this.canvasClipBoundsRectF);
      convertRect(this.canvasClipBoundsRectF, this.canvasClipBounds);
      if (this.clipToCompositionBounds) {
        this.softwareRenderingTransformedBounds.set(0.0F, 0.0F, getIntrinsicWidth(), getIntrinsicHeight());
      } else {
        paramCompositionLayer.getBounds(this.softwareRenderingTransformedBounds, null, false);
      } 
      this.softwareRenderingOriginalCanvasMatrix.mapRect(this.softwareRenderingTransformedBounds);
      Rect rect = getBounds();
      float f1 = rect.width() / getIntrinsicWidth();
      float f2 = rect.height() / getIntrinsicHeight();
      scaleRect(this.softwareRenderingTransformedBounds, f1, f2);
      if (!ignoreCanvasClipBounds()) {
        RectF rectF = this.softwareRenderingTransformedBounds;
        Rect rect1 = this.canvasClipBounds;
        rectF.intersect(rect1.left, rect1.top, rect1.right, rect1.bottom);
      } 
      int i = (int)Math.ceil(this.softwareRenderingTransformedBounds.width());
      int j = (int)Math.ceil(this.softwareRenderingTransformedBounds.height());
      if (i != 0) {
        if (j == 0)
          return; 
        ensureSoftwareRenderingBitmap(i, j);
        if (this.isDirty) {
          this.renderingMatrix.set(this.softwareRenderingOriginalCanvasMatrix);
          this.renderingMatrix.preScale(f1, f2);
          Matrix matrix = this.renderingMatrix;
          RectF rectF = this.softwareRenderingTransformedBounds;
          matrix.postTranslate(-rectF.left, -rectF.top);
          this.softwareRenderingBitmap.eraseColor(0);
          paramCompositionLayer.draw(this.softwareRenderingCanvas, this.renderingMatrix, this.alpha);
          this.softwareRenderingOriginalCanvasMatrix.invert(this.softwareRenderingOriginalCanvasMatrixInverse);
          this.softwareRenderingOriginalCanvasMatrixInverse.mapRect(this.softwareRenderingDstBoundsRectF, this.softwareRenderingTransformedBounds);
          convertRect(this.softwareRenderingDstBoundsRectF, this.softwareRenderingDstBoundsRect);
        } 
        this.softwareRenderingSrcBoundsRect.set(0, 0, i, j);
        paramCanvas.drawBitmap(this.softwareRenderingBitmap, this.softwareRenderingSrcBoundsRect, this.softwareRenderingDstBoundsRect, this.softwareRenderingPaint);
      } 
    } 
  }
  
  private void scaleRect(RectF paramRectF, float paramFloat1, float paramFloat2) {
    paramRectF.set(paramRectF.left * paramFloat1, paramRectF.top * paramFloat2, paramRectF.right * paramFloat1, paramRectF.bottom * paramFloat2);
  }
  
  private boolean shouldSetProgressBeforeDrawing() {
    LottieComposition lottieComposition = this.composition;
    boolean bool = false;
    if (lottieComposition == null)
      return false; 
    float f1 = this.lastDrawnProgress;
    float f2 = this.animator.getAnimatedValueAbsolute();
    this.lastDrawnProgress = f2;
    float f3 = lottieComposition.getDuration();
    if (Math.abs(f2 - f1) * f3 >= 50.0F)
      bool = true; 
    return bool;
  }
  
  public <T> void addValueCallback(KeyPath paramKeyPath, T paramT, @Nullable LottieValueCallback<T> paramLottieValueCallback) {
    CompositionLayer compositionLayer = this.compositionLayer;
    if (compositionLayer == null) {
      this.lazyCompositionTasks.add(new LottieDrawable$.ExternalSyntheticLambda9(this, paramKeyPath, paramT, paramLottieValueCallback));
      return;
    } 
    KeyPath keyPath = KeyPath.COMPOSITION;
    int i = 1;
    if (paramKeyPath == keyPath) {
      compositionLayer.addValueCallback(paramT, paramLottieValueCallback);
    } else if (paramKeyPath.getResolvedElement() != null) {
      paramKeyPath.getResolvedElement().addValueCallback(paramT, paramLottieValueCallback);
    } else {
      List<KeyPath> list = resolveKeyPath(paramKeyPath);
      for (i = 0; i < list.size(); i++)
        ((KeyPath)list.get(i)).getResolvedElement().addValueCallback(paramT, paramLottieValueCallback); 
      i = true ^ list.isEmpty();
    } 
    if (i != 0) {
      invalidateSelf();
      if (paramT == LottieProperty.TIME_REMAP)
        setProgress(getProgress()); 
    } 
  }
  
  public void clearComposition() {
    if (this.animator.isRunning()) {
      this.animator.cancel();
      if (!isVisible())
        this.onVisibleAction = OnVisibleAction.NONE; 
    } 
    this.composition = null;
    this.compositionLayer = null;
    this.imageAssetManager = null;
    this.lastDrawnProgress = -3.4028235E38F;
    this.animator.clearComposition();
    invalidateSelf();
  }
  
  public void draw(@NonNull Canvas paramCanvas) {
    // Byte code:
    //   0: aload_0
    //   1: getfield compositionLayer : Lcom/airbnb/lottie/model/layer/CompositionLayer;
    //   4: astore #4
    //   6: aload #4
    //   8: ifnonnull -> 12
    //   11: return
    //   12: aload_0
    //   13: invokevirtual getAsyncUpdatesEnabled : ()Z
    //   16: istore_2
    //   17: iload_2
    //   18: ifeq -> 31
    //   21: aload_0
    //   22: getfield setProgressDrawLock : Ljava/util/concurrent/Semaphore;
    //   25: invokevirtual acquire : ()V
    //   28: goto -> 31
    //   31: ldc_w 'Drawable#draw'
    //   34: invokestatic beginSection : (Ljava/lang/String;)V
    //   37: iload_2
    //   38: ifeq -> 59
    //   41: aload_0
    //   42: invokespecial shouldSetProgressBeforeDrawing : ()Z
    //   45: ifeq -> 59
    //   48: aload_0
    //   49: aload_0
    //   50: getfield animator : Lcom/airbnb/lottie/utils/LottieValueAnimator;
    //   53: invokevirtual getAnimatedValueAbsolute : ()F
    //   56: invokevirtual setProgress : (F)V
    //   59: aload_0
    //   60: getfield safeMode : Z
    //   63: istore_3
    //   64: iload_3
    //   65: ifeq -> 104
    //   68: aload_0
    //   69: getfield useSoftwareRendering : Z
    //   72: ifeq -> 85
    //   75: aload_0
    //   76: aload_1
    //   77: aload #4
    //   79: invokespecial renderAndDrawAsBitmap : (Landroid/graphics/Canvas;Lcom/airbnb/lottie/model/layer/CompositionLayer;)V
    //   82: goto -> 126
    //   85: aload_0
    //   86: aload_1
    //   87: invokespecial drawDirectlyToCanvas : (Landroid/graphics/Canvas;)V
    //   90: goto -> 126
    //   93: astore_1
    //   94: ldc_w 'Lottie crashed in draw!'
    //   97: aload_1
    //   98: invokestatic error : (Ljava/lang/String;Ljava/lang/Throwable;)V
    //   101: goto -> 126
    //   104: aload_0
    //   105: getfield useSoftwareRendering : Z
    //   108: ifeq -> 121
    //   111: aload_0
    //   112: aload_1
    //   113: aload #4
    //   115: invokespecial renderAndDrawAsBitmap : (Landroid/graphics/Canvas;Lcom/airbnb/lottie/model/layer/CompositionLayer;)V
    //   118: goto -> 126
    //   121: aload_0
    //   122: aload_1
    //   123: invokespecial drawDirectlyToCanvas : (Landroid/graphics/Canvas;)V
    //   126: aload_0
    //   127: iconst_0
    //   128: putfield isDirty : Z
    //   131: ldc_w 'Drawable#draw'
    //   134: invokestatic endSection : (Ljava/lang/String;)F
    //   137: pop
    //   138: iload_2
    //   139: ifeq -> 262
    //   142: aload_0
    //   143: getfield setProgressDrawLock : Ljava/util/concurrent/Semaphore;
    //   146: invokevirtual release : ()V
    //   149: aload #4
    //   151: invokevirtual getProgress : ()F
    //   154: aload_0
    //   155: getfield animator : Lcom/airbnb/lottie/utils/LottieValueAnimator;
    //   158: invokevirtual getAnimatedValueAbsolute : ()F
    //   161: fcmpl
    //   162: ifeq -> 262
    //   165: goto -> 250
    //   168: ldc_w 'Drawable#draw'
    //   171: invokestatic endSection : (Ljava/lang/String;)F
    //   174: pop
    //   175: iload_2
    //   176: ifeq -> 214
    //   179: aload_0
    //   180: getfield setProgressDrawLock : Ljava/util/concurrent/Semaphore;
    //   183: invokevirtual release : ()V
    //   186: aload #4
    //   188: invokevirtual getProgress : ()F
    //   191: aload_0
    //   192: getfield animator : Lcom/airbnb/lottie/utils/LottieValueAnimator;
    //   195: invokevirtual getAnimatedValueAbsolute : ()F
    //   198: fcmpl
    //   199: ifeq -> 214
    //   202: getstatic com/airbnb/lottie/LottieDrawable.setProgressExecutor : Ljava/util/concurrent/Executor;
    //   205: aload_0
    //   206: getfield updateProgressRunnable : Ljava/lang/Runnable;
    //   209: invokeinterface execute : (Ljava/lang/Runnable;)V
    //   214: aload_1
    //   215: athrow
    //   216: ldc_w 'Drawable#draw'
    //   219: invokestatic endSection : (Ljava/lang/String;)F
    //   222: pop
    //   223: iload_2
    //   224: ifeq -> 262
    //   227: aload_0
    //   228: getfield setProgressDrawLock : Ljava/util/concurrent/Semaphore;
    //   231: invokevirtual release : ()V
    //   234: aload #4
    //   236: invokevirtual getProgress : ()F
    //   239: aload_0
    //   240: getfield animator : Lcom/airbnb/lottie/utils/LottieValueAnimator;
    //   243: invokevirtual getAnimatedValueAbsolute : ()F
    //   246: fcmpl
    //   247: ifeq -> 262
    //   250: getstatic com/airbnb/lottie/LottieDrawable.setProgressExecutor : Ljava/util/concurrent/Executor;
    //   253: aload_0
    //   254: getfield updateProgressRunnable : Ljava/lang/Runnable;
    //   257: invokeinterface execute : (Ljava/lang/Runnable;)V
    //   262: return
    //   263: astore_1
    //   264: goto -> 271
    //   267: astore_1
    //   268: goto -> 168
    //   271: goto -> 216
    // Exception table:
    //   from	to	target	type
    //   21	28	263	java/lang/InterruptedException
    //   21	28	267	finally
    //   31	37	263	java/lang/InterruptedException
    //   31	37	267	finally
    //   41	59	263	java/lang/InterruptedException
    //   41	59	267	finally
    //   59	64	263	java/lang/InterruptedException
    //   59	64	267	finally
    //   68	82	93	finally
    //   85	90	93	finally
    //   94	101	263	java/lang/InterruptedException
    //   94	101	267	finally
    //   104	118	263	java/lang/InterruptedException
    //   104	118	267	finally
    //   121	126	263	java/lang/InterruptedException
    //   121	126	267	finally
    //   126	131	263	java/lang/InterruptedException
    //   126	131	267	finally
  }
  
  public void enableMergePathsForKitKatAndAbove(boolean paramBoolean) {
    if (this.enableMergePaths == paramBoolean)
      return; 
    this.enableMergePaths = paramBoolean;
    if (this.composition != null)
      buildCompositionLayer(); 
  }
  
  public boolean enableMergePathsForKitKatAndAbove() {
    return this.enableMergePaths;
  }
  
  @MainThread
  public void endAnimation() {
    this.lazyCompositionTasks.clear();
    this.animator.endAnimation();
    if (!isVisible())
      this.onVisibleAction = OnVisibleAction.NONE; 
  }
  
  public int getAlpha() {
    return this.alpha;
  }
  
  public AsyncUpdates getAsyncUpdates() {
    return this.asyncUpdates;
  }
  
  public boolean getAsyncUpdatesEnabled() {
    return (this.asyncUpdates == AsyncUpdates.ENABLED);
  }
  
  @Nullable
  public Bitmap getBitmapForId(String paramString) {
    ImageAssetManager imageAssetManager = getImageAssetManager();
    return (imageAssetManager != null) ? imageAssetManager.bitmapForId(paramString) : null;
  }
  
  public boolean getClipToCompositionBounds() {
    return this.clipToCompositionBounds;
  }
  
  public LottieComposition getComposition() {
    return this.composition;
  }
  
  public int getFrame() {
    return (int)this.animator.getFrame();
  }
  
  @Nullable
  public String getImageAssetsFolder() {
    return this.imageAssetsFolder;
  }
  
  public int getIntrinsicHeight() {
    LottieComposition lottieComposition = this.composition;
    return (lottieComposition == null) ? -1 : lottieComposition.getBounds().height();
  }
  
  public int getIntrinsicWidth() {
    LottieComposition lottieComposition = this.composition;
    return (lottieComposition == null) ? -1 : lottieComposition.getBounds().width();
  }
  
  @Nullable
  public LottieImageAsset getLottieImageAssetForId(String paramString) {
    LottieComposition lottieComposition = this.composition;
    return (lottieComposition == null) ? null : (LottieImageAsset)lottieComposition.getImages().get(paramString);
  }
  
  public boolean getMaintainOriginalImageBounds() {
    return this.maintainOriginalImageBounds;
  }
  
  public float getMaxFrame() {
    return this.animator.getMaxFrame();
  }
  
  public float getMinFrame() {
    return this.animator.getMinFrame();
  }
  
  public int getOpacity() {
    return -3;
  }
  
  @Nullable
  public PerformanceTracker getPerformanceTracker() {
    LottieComposition lottieComposition = this.composition;
    return (lottieComposition != null) ? lottieComposition.getPerformanceTracker() : null;
  }
  
  @FloatRange(from = 0.0D, to = 1.0D)
  public float getProgress() {
    return this.animator.getAnimatedValueAbsolute();
  }
  
  public RenderMode getRenderMode() {
    return this.useSoftwareRendering ? RenderMode.SOFTWARE : RenderMode.HARDWARE;
  }
  
  public int getRepeatCount() {
    return this.animator.getRepeatCount();
  }
  
  @SuppressLint({"WrongConstant"})
  public int getRepeatMode() {
    return this.animator.getRepeatMode();
  }
  
  public float getSpeed() {
    return this.animator.getSpeed();
  }
  
  @Nullable
  public TextDelegate getTextDelegate() {
    return null;
  }
  
  @Nullable
  @RestrictTo({RestrictTo.Scope.LIBRARY})
  public Typeface getTypeface(Font paramFont) {
    Map<String, Typeface> map = this.fontMap;
    if (map != null) {
      String str2 = paramFont.getFamily();
      if (map.containsKey(str2))
        return map.get(str2); 
      str2 = paramFont.getName();
      if (map.containsKey(str2))
        return map.get(str2); 
      StringBuilder stringBuilder = new StringBuilder();
      stringBuilder.append(paramFont.getFamily());
      stringBuilder.append("-");
      stringBuilder.append(paramFont.getStyle());
      String str1 = stringBuilder.toString();
      if (map.containsKey(str1))
        return map.get(str1); 
    } 
    FontAssetManager fontAssetManager = getFontAssetManager();
    return (fontAssetManager != null) ? fontAssetManager.getTypeface(paramFont) : null;
  }
  
  public void invalidateDrawable(@NonNull Drawable paramDrawable) {
    Drawable.Callback callback = getCallback();
    if (callback == null)
      return; 
    callback.invalidateDrawable(this);
  }
  
  public void invalidateSelf() {
    if (this.isDirty)
      return; 
    this.isDirty = true;
    Drawable.Callback callback = getCallback();
    if (callback != null)
      callback.invalidateDrawable(this); 
  }
  
  public boolean isAnimating() {
    LottieValueAnimator lottieValueAnimator = this.animator;
    return (lottieValueAnimator == null) ? false : lottieValueAnimator.isRunning();
  }
  
  boolean isAnimatingOrWillAnimateOnVisible() {
    if (isVisible())
      return this.animator.isRunning(); 
    OnVisibleAction onVisibleAction = this.onVisibleAction;
    return (onVisibleAction == OnVisibleAction.PLAY || onVisibleAction == OnVisibleAction.RESUME);
  }
  
  public boolean isApplyingOpacityToLayersEnabled() {
    return this.isApplyingOpacityToLayersEnabled;
  }
  
  public boolean isRunning() {
    return isAnimating();
  }
  
  public void pauseAnimation() {
    this.lazyCompositionTasks.clear();
    this.animator.pauseAnimation();
    if (!isVisible())
      this.onVisibleAction = OnVisibleAction.NONE; 
  }
  
  @MainThread
  public void playAnimation() {
    if (this.compositionLayer == null) {
      this.lazyCompositionTasks.add(new LottieDrawable$.ExternalSyntheticLambda11(this));
      return;
    } 
    computeRenderMode();
    if (animationsEnabled() || getRepeatCount() == 0)
      if (isVisible()) {
        this.animator.playAnimation();
        this.onVisibleAction = OnVisibleAction.NONE;
      } else {
        this.onVisibleAction = OnVisibleAction.PLAY;
      }  
    if (!animationsEnabled()) {
      float f;
      if (getSpeed() < 0.0F) {
        f = getMinFrame();
      } else {
        f = getMaxFrame();
      } 
      setFrame((int)f);
      this.animator.endAnimation();
      if (!isVisible())
        this.onVisibleAction = OnVisibleAction.NONE; 
    } 
  }
  
  public List<KeyPath> resolveKeyPath(KeyPath paramKeyPath) {
    if (this.compositionLayer == null) {
      Logger.warning("Cannot resolve KeyPath. Composition is not set yet.");
      return Collections.emptyList();
    } 
    ArrayList<KeyPath> arrayList = new ArrayList();
    this.compositionLayer.resolveKeyPath(paramKeyPath, 0, arrayList, new KeyPath(new String[0]));
    return arrayList;
  }
  
  @MainThread
  public void resumeAnimation() {
    if (this.compositionLayer == null) {
      this.lazyCompositionTasks.add(new LottieDrawable$.ExternalSyntheticLambda6(this));
      return;
    } 
    computeRenderMode();
    if (animationsEnabled() || getRepeatCount() == 0)
      if (isVisible()) {
        this.animator.resumeAnimation();
        this.onVisibleAction = OnVisibleAction.NONE;
      } else {
        this.onVisibleAction = OnVisibleAction.RESUME;
      }  
    if (!animationsEnabled()) {
      float f;
      if (getSpeed() < 0.0F) {
        f = getMinFrame();
      } else {
        f = getMaxFrame();
      } 
      setFrame((int)f);
      this.animator.endAnimation();
      if (!isVisible())
        this.onVisibleAction = OnVisibleAction.NONE; 
    } 
  }
  
  public void scheduleDrawable(@NonNull Drawable paramDrawable, @NonNull Runnable paramRunnable, long paramLong) {
    Drawable.Callback callback = getCallback();
    if (callback == null)
      return; 
    callback.scheduleDrawable(this, paramRunnable, paramLong);
  }
  
  public void setAlpha(@IntRange(from = 0L, to = 255L) int paramInt) {
    this.alpha = paramInt;
    invalidateSelf();
  }
  
  public void setApplyingOpacityToLayersEnabled(boolean paramBoolean) {
    this.isApplyingOpacityToLayersEnabled = paramBoolean;
  }
  
  public void setAsyncUpdates(AsyncUpdates paramAsyncUpdates) {
    this.asyncUpdates = paramAsyncUpdates;
  }
  
  public void setClipToCompositionBounds(boolean paramBoolean) {
    if (paramBoolean != this.clipToCompositionBounds) {
      this.clipToCompositionBounds = paramBoolean;
      CompositionLayer compositionLayer = this.compositionLayer;
      if (compositionLayer != null)
        compositionLayer.setClipToCompositionBounds(paramBoolean); 
      invalidateSelf();
    } 
  }
  
  public void setColorFilter(@Nullable ColorFilter paramColorFilter) {
    Logger.warning("Use addColorFilter instead.");
  }
  
  public boolean setComposition(LottieComposition paramLottieComposition) {
    if (this.composition == paramLottieComposition)
      return false; 
    this.isDirty = true;
    clearComposition();
    this.composition = paramLottieComposition;
    buildCompositionLayer();
    this.animator.setComposition(paramLottieComposition);
    setProgress(this.animator.getAnimatedFraction());
    Iterator<?> iterator = (new ArrayList(this.lazyCompositionTasks)).iterator();
    while (iterator.hasNext()) {
      LazyCompositionTask lazyCompositionTask = (LazyCompositionTask)iterator.next();
      if (lazyCompositionTask != null)
        lazyCompositionTask.run(paramLottieComposition); 
      iterator.remove();
    } 
    this.lazyCompositionTasks.clear();
    paramLottieComposition.setPerformanceTrackingEnabled(this.performanceTrackingEnabled);
    computeRenderMode();
    Drawable.Callback callback = getCallback();
    if (callback instanceof ImageView) {
      ImageView imageView = (ImageView)callback;
      imageView.setImageDrawable(null);
      imageView.setImageDrawable(this);
    } 
    return true;
  }
  
  public void setDefaultFontFileExtension(String paramString) {
    this.defaultFontFileExtension = paramString;
    FontAssetManager fontAssetManager = getFontAssetManager();
    if (fontAssetManager != null)
      fontAssetManager.setDefaultFontFileExtension(paramString); 
  }
  
  public void setFontAssetDelegate(FontAssetDelegate paramFontAssetDelegate) {
    FontAssetManager fontAssetManager = this.fontAssetManager;
    if (fontAssetManager != null)
      fontAssetManager.setDelegate(paramFontAssetDelegate); 
  }
  
  public void setFontMap(@Nullable Map<String, Typeface> paramMap) {
    if (paramMap == this.fontMap)
      return; 
    this.fontMap = paramMap;
    invalidateSelf();
  }
  
  public void setFrame(int paramInt) {
    if (this.composition == null) {
      this.lazyCompositionTasks.add(new LottieDrawable$.ExternalSyntheticLambda12(this, paramInt));
      return;
    } 
    this.animator.setFrame(paramInt);
  }
  
  public void setIgnoreDisabledSystemAnimations(boolean paramBoolean) {
    this.ignoreSystemAnimationsDisabled = paramBoolean;
  }
  
  public void setImageAssetDelegate(ImageAssetDelegate paramImageAssetDelegate) {
    ImageAssetManager imageAssetManager = this.imageAssetManager;
    if (imageAssetManager != null)
      imageAssetManager.setDelegate(paramImageAssetDelegate); 
  }
  
  public void setImagesAssetsFolder(@Nullable String paramString) {
    this.imageAssetsFolder = paramString;
  }
  
  public void setMaintainOriginalImageBounds(boolean paramBoolean) {
    this.maintainOriginalImageBounds = paramBoolean;
  }
  
  public void setMaxFrame(int paramInt) {
    if (this.composition == null) {
      this.lazyCompositionTasks.add(new LottieDrawable$.ExternalSyntheticLambda5(this, paramInt));
      return;
    } 
    this.animator.setMaxFrame(paramInt + 0.99F);
  }
  
  public void setMaxFrame(String paramString) {
    LottieComposition lottieComposition = this.composition;
    if (lottieComposition == null) {
      this.lazyCompositionTasks.add(new LottieDrawable$.ExternalSyntheticLambda7(this, paramString));
      return;
    } 
    Marker marker = lottieComposition.getMarker(paramString);
    if (marker != null) {
      setMaxFrame((int)(marker.startFrame + marker.durationFrames));
      return;
    } 
    StringBuilder stringBuilder = new StringBuilder();
    stringBuilder.append("Cannot find marker with name ");
    stringBuilder.append(paramString);
    stringBuilder.append(".");
    throw new IllegalArgumentException(stringBuilder.toString());
  }
  
  public void setMaxProgress(@FloatRange(from = 0.0D, to = 1.0D) float paramFloat) {
    LottieComposition lottieComposition = this.composition;
    if (lottieComposition == null) {
      this.lazyCompositionTasks.add(new LottieDrawable$.ExternalSyntheticLambda10(this, paramFloat));
      return;
    } 
    this.animator.setMaxFrame(MiscUtils.lerp(lottieComposition.getStartFrame(), this.composition.getEndFrame(), paramFloat));
  }
  
  public void setMinAndMaxFrame(int paramInt1, int paramInt2) {
    if (this.composition == null) {
      this.lazyCompositionTasks.add(new LottieDrawable$.ExternalSyntheticLambda14(this, paramInt1, paramInt2));
      return;
    } 
    this.animator.setMinAndMaxFrames(paramInt1, paramInt2 + 0.99F);
  }
  
  public void setMinAndMaxFrame(String paramString) {
    LottieComposition lottieComposition = this.composition;
    if (lottieComposition == null) {
      this.lazyCompositionTasks.add(new LottieDrawable$.ExternalSyntheticLambda13(this, paramString));
      return;
    } 
    Marker marker = lottieComposition.getMarker(paramString);
    if (marker != null) {
      int i = (int)marker.startFrame;
      setMinAndMaxFrame(i, (int)marker.durationFrames + i);
      return;
    } 
    StringBuilder stringBuilder = new StringBuilder();
    stringBuilder.append("Cannot find marker with name ");
    stringBuilder.append(paramString);
    stringBuilder.append(".");
    throw new IllegalArgumentException(stringBuilder.toString());
  }
  
  public void setMinFrame(int paramInt) {
    if (this.composition == null) {
      this.lazyCompositionTasks.add(new LottieDrawable$.ExternalSyntheticLambda3(this, paramInt));
      return;
    } 
    this.animator.setMinFrame(paramInt);
  }
  
  public void setMinFrame(String paramString) {
    LottieComposition lottieComposition = this.composition;
    if (lottieComposition == null) {
      this.lazyCompositionTasks.add(new LottieDrawable$.ExternalSyntheticLambda8(this, paramString));
      return;
    } 
    Marker marker = lottieComposition.getMarker(paramString);
    if (marker != null) {
      setMinFrame((int)marker.startFrame);
      return;
    } 
    StringBuilder stringBuilder = new StringBuilder();
    stringBuilder.append("Cannot find marker with name ");
    stringBuilder.append(paramString);
    stringBuilder.append(".");
    throw new IllegalArgumentException(stringBuilder.toString());
  }
  
  public void setMinProgress(float paramFloat) {
    LottieComposition lottieComposition = this.composition;
    if (lottieComposition == null) {
      this.lazyCompositionTasks.add(new LottieDrawable$.ExternalSyntheticLambda4(this, paramFloat));
      return;
    } 
    setMinFrame((int)MiscUtils.lerp(lottieComposition.getStartFrame(), this.composition.getEndFrame(), paramFloat));
  }
  
  public void setOutlineMasksAndMattes(boolean paramBoolean) {
    if (this.outlineMasksAndMattes == paramBoolean)
      return; 
    this.outlineMasksAndMattes = paramBoolean;
    CompositionLayer compositionLayer = this.compositionLayer;
    if (compositionLayer != null)
      compositionLayer.setOutlineMasksAndMattes(paramBoolean); 
  }
  
  public void setPerformanceTrackingEnabled(boolean paramBoolean) {
    this.performanceTrackingEnabled = paramBoolean;
    LottieComposition lottieComposition = this.composition;
    if (lottieComposition != null)
      lottieComposition.setPerformanceTrackingEnabled(paramBoolean); 
  }
  
  public void setProgress(@FloatRange(from = 0.0D, to = 1.0D) float paramFloat) {
    if (this.composition == null) {
      this.lazyCompositionTasks.add(new LottieDrawable$.ExternalSyntheticLambda2(this, paramFloat));
      return;
    } 
    L.beginSection("Drawable#setProgress");
    this.animator.setFrame(this.composition.getFrameForProgress(paramFloat));
    L.endSection("Drawable#setProgress");
  }
  
  public void setRenderMode(RenderMode paramRenderMode) {
    this.renderMode = paramRenderMode;
    computeRenderMode();
  }
  
  public void setRepeatCount(int paramInt) {
    this.animator.setRepeatCount(paramInt);
  }
  
  public void setRepeatMode(int paramInt) {
    this.animator.setRepeatMode(paramInt);
  }
  
  public void setSafeMode(boolean paramBoolean) {
    this.safeMode = paramBoolean;
  }
  
  public void setSpeed(float paramFloat) {
    this.animator.setSpeed(paramFloat);
  }
  
  public void setSystemAnimationsAreEnabled(Boolean paramBoolean) {
    this.systemAnimationsEnabled = paramBoolean.booleanValue();
  }
  
  public void setTextDelegate(TextDelegate paramTextDelegate) {}
  
  public void setUseCompositionFrameRate(boolean paramBoolean) {
    this.animator.setUseCompositionFrameRate(paramBoolean);
  }
  
  public boolean setVisible(boolean paramBoolean1, boolean paramBoolean2) {
    boolean bool = isVisible();
    paramBoolean2 = super.setVisible(paramBoolean1, paramBoolean2);
    if (paramBoolean1) {
      OnVisibleAction onVisibleAction = this.onVisibleAction;
      if (onVisibleAction == OnVisibleAction.PLAY) {
        playAnimation();
        return paramBoolean2;
      } 
      if (onVisibleAction == OnVisibleAction.RESUME) {
        resumeAnimation();
        return paramBoolean2;
      } 
    } else {
      if (this.animator.isRunning()) {
        pauseAnimation();
        this.onVisibleAction = OnVisibleAction.RESUME;
        return paramBoolean2;
      } 
      if ((bool ^ true) == 0)
        this.onVisibleAction = OnVisibleAction.NONE; 
    } 
    return paramBoolean2;
  }
  
  @MainThread
  public void start() {
    Drawable.Callback callback = getCallback();
    if (callback instanceof View && ((View)callback).isInEditMode())
      return; 
    playAnimation();
  }
  
  @MainThread
  public void stop() {
    endAnimation();
  }
  
  public void unscheduleDrawable(@NonNull Drawable paramDrawable, @NonNull Runnable paramRunnable) {
    Drawable.Callback callback = getCallback();
    if (callback == null)
      return; 
    callback.unscheduleDrawable(this, paramRunnable);
  }
  
  public boolean useTextGlyphs() {
    return (this.fontMap == null && this.composition.getCharacters().size() > 0);
  }
  
  private static interface LazyCompositionTask {
    void run(LottieComposition param1LottieComposition);
  }
  
  private enum OnVisibleAction {
    NONE, PLAY, RESUME;
    
    static {
    
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\MagicAI - AI Art & Anime Art-dex2jar.jar!\com\airbnb\lottie\LottieDrawable.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */