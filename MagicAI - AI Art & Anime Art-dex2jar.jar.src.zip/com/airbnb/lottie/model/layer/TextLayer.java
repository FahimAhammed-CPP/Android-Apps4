package com.airbnb.lottie.model.layer;

import android.graphics.Canvas;
import android.graphics.Matrix;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.PointF;
import android.graphics.RectF;
import android.graphics.Typeface;
import androidx.annotation.Nullable;
import androidx.collection.LongSparseArray;
import com.airbnb.lottie.LottieComposition;
import com.airbnb.lottie.LottieDrawable;
import com.airbnb.lottie.LottieProperty;
import com.airbnb.lottie.animation.content.ContentGroup;
import com.airbnb.lottie.animation.keyframe.BaseKeyframeAnimation;
import com.airbnb.lottie.animation.keyframe.TextKeyframeAnimation;
import com.airbnb.lottie.animation.keyframe.ValueCallbackKeyframeAnimation;
import com.airbnb.lottie.model.DocumentData;
import com.airbnb.lottie.model.Font;
import com.airbnb.lottie.model.FontCharacter;
import com.airbnb.lottie.model.animatable.AnimatableColorValue;
import com.airbnb.lottie.model.animatable.AnimatableFloatValue;
import com.airbnb.lottie.model.animatable.AnimatableTextProperties;
import com.airbnb.lottie.model.content.ShapeGroup;
import com.airbnb.lottie.utils.Utils;
import com.airbnb.lottie.value.LottieValueCallback;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class TextLayer extends BaseLayer {
  private final LongSparseArray<String> codePointCache = new LongSparseArray();
  
  @Nullable
  private BaseKeyframeAnimation<Integer, Integer> colorAnimation;
  
  @Nullable
  private BaseKeyframeAnimation<Integer, Integer> colorCallbackAnimation;
  
  private final LottieComposition composition;
  
  private final Map<FontCharacter, List<ContentGroup>> contentsForCharacter = new HashMap<FontCharacter, List<ContentGroup>>();
  
  private final Paint fillPaint = new Paint(1) {
    
    };
  
  private final LottieDrawable lottieDrawable;
  
  private final Matrix matrix = new Matrix();
  
  private final RectF rectF = new RectF();
  
  private final StringBuilder stringBuilder = new StringBuilder(2);
  
  @Nullable
  private BaseKeyframeAnimation<Integer, Integer> strokeColorAnimation;
  
  @Nullable
  private BaseKeyframeAnimation<Integer, Integer> strokeColorCallbackAnimation;
  
  private final Paint strokePaint = new Paint(1) {
    
    };
  
  @Nullable
  private BaseKeyframeAnimation<Float, Float> strokeWidthAnimation;
  
  @Nullable
  private BaseKeyframeAnimation<Float, Float> strokeWidthCallbackAnimation;
  
  private final TextKeyframeAnimation textAnimation;
  
  @Nullable
  private BaseKeyframeAnimation<Float, Float> textSizeCallbackAnimation;
  
  private final List<TextSubLine> textSubLines = new ArrayList<TextSubLine>();
  
  @Nullable
  private BaseKeyframeAnimation<Float, Float> trackingAnimation;
  
  @Nullable
  private BaseKeyframeAnimation<Float, Float> trackingCallbackAnimation;
  
  @Nullable
  private BaseKeyframeAnimation<Typeface, Typeface> typefaceCallbackAnimation;
  
  TextLayer(LottieDrawable paramLottieDrawable, Layer paramLayer) {
    super(paramLottieDrawable, paramLayer);
    this.lottieDrawable = paramLottieDrawable;
    this.composition = paramLayer.getComposition();
    TextKeyframeAnimation textKeyframeAnimation = paramLayer.getText().createAnimation();
    this.textAnimation = textKeyframeAnimation;
    textKeyframeAnimation.addUpdateListener((BaseKeyframeAnimation.AnimationListener)this);
    addAnimation((BaseKeyframeAnimation)textKeyframeAnimation);
    AnimatableTextProperties animatableTextProperties = paramLayer.getTextProperties();
    if (animatableTextProperties != null) {
      AnimatableColorValue animatableColorValue = animatableTextProperties.color;
      if (animatableColorValue != null) {
        BaseKeyframeAnimation<Integer, Integer> baseKeyframeAnimation = animatableColorValue.createAnimation();
        this.colorAnimation = baseKeyframeAnimation;
        baseKeyframeAnimation.addUpdateListener((BaseKeyframeAnimation.AnimationListener)this);
        addAnimation(this.colorAnimation);
      } 
    } 
    if (animatableTextProperties != null) {
      AnimatableColorValue animatableColorValue = animatableTextProperties.stroke;
      if (animatableColorValue != null) {
        BaseKeyframeAnimation<Integer, Integer> baseKeyframeAnimation = animatableColorValue.createAnimation();
        this.strokeColorAnimation = baseKeyframeAnimation;
        baseKeyframeAnimation.addUpdateListener((BaseKeyframeAnimation.AnimationListener)this);
        addAnimation(this.strokeColorAnimation);
      } 
    } 
    if (animatableTextProperties != null) {
      AnimatableFloatValue animatableFloatValue = animatableTextProperties.strokeWidth;
      if (animatableFloatValue != null) {
        BaseKeyframeAnimation<Float, Float> baseKeyframeAnimation = animatableFloatValue.createAnimation();
        this.strokeWidthAnimation = baseKeyframeAnimation;
        baseKeyframeAnimation.addUpdateListener((BaseKeyframeAnimation.AnimationListener)this);
        addAnimation(this.strokeWidthAnimation);
      } 
    } 
    if (animatableTextProperties != null) {
      AnimatableFloatValue animatableFloatValue = animatableTextProperties.tracking;
      if (animatableFloatValue != null) {
        BaseKeyframeAnimation<Float, Float> baseKeyframeAnimation = animatableFloatValue.createAnimation();
        this.trackingAnimation = baseKeyframeAnimation;
        baseKeyframeAnimation.addUpdateListener((BaseKeyframeAnimation.AnimationListener)this);
        addAnimation(this.trackingAnimation);
      } 
    } 
  }
  
  private String codePointToString(String paramString, int paramInt) {
    int j = paramString.codePointAt(paramInt);
    int i = Character.charCount(j) + paramInt;
    while (i < paramString.length()) {
      int k = paramString.codePointAt(i);
      if (!isModifier(k))
        break; 
      i += Character.charCount(k);
      j = j * 31 + k;
    } 
    LongSparseArray<String> longSparseArray = this.codePointCache;
    long l = j;
    if (longSparseArray.containsKey(l))
      return (String)this.codePointCache.get(l); 
    this.stringBuilder.setLength(0);
    while (paramInt < i) {
      j = paramString.codePointAt(paramInt);
      this.stringBuilder.appendCodePoint(j);
      paramInt += Character.charCount(j);
    } 
    paramString = this.stringBuilder.toString();
    this.codePointCache.put(l, paramString);
    return paramString;
  }
  
  private void configurePaint(DocumentData paramDocumentData, int paramInt) {
    int i;
    BaseKeyframeAnimation<Integer, Integer> baseKeyframeAnimation1 = this.colorCallbackAnimation;
    if (baseKeyframeAnimation1 != null) {
      this.fillPaint.setColor(((Integer)baseKeyframeAnimation1.getValue()).intValue());
    } else {
      baseKeyframeAnimation1 = this.colorAnimation;
      if (baseKeyframeAnimation1 != null) {
        this.fillPaint.setColor(((Integer)baseKeyframeAnimation1.getValue()).intValue());
      } else {
        this.fillPaint.setColor(paramDocumentData.color);
      } 
    } 
    baseKeyframeAnimation1 = this.strokeColorCallbackAnimation;
    if (baseKeyframeAnimation1 != null) {
      this.strokePaint.setColor(((Integer)baseKeyframeAnimation1.getValue()).intValue());
    } else {
      baseKeyframeAnimation1 = this.strokeColorAnimation;
      if (baseKeyframeAnimation1 != null) {
        this.strokePaint.setColor(((Integer)baseKeyframeAnimation1.getValue()).intValue());
      } else {
        this.strokePaint.setColor(paramDocumentData.strokeColor);
      } 
    } 
    if (this.transform.getOpacity() == null) {
      i = 100;
    } else {
      i = ((Integer)this.transform.getOpacity().getValue()).intValue();
    } 
    paramInt = i * 255 / 100 * paramInt / 255;
    this.fillPaint.setAlpha(paramInt);
    this.strokePaint.setAlpha(paramInt);
    BaseKeyframeAnimation<Float, Float> baseKeyframeAnimation = this.strokeWidthCallbackAnimation;
    if (baseKeyframeAnimation != null) {
      this.strokePaint.setStrokeWidth(((Float)baseKeyframeAnimation.getValue()).floatValue());
      return;
    } 
    baseKeyframeAnimation = this.strokeWidthAnimation;
    if (baseKeyframeAnimation != null) {
      this.strokePaint.setStrokeWidth(((Float)baseKeyframeAnimation.getValue()).floatValue());
      return;
    } 
    this.strokePaint.setStrokeWidth(paramDocumentData.strokeWidth * Utils.dpScale());
  }
  
  private void drawCharacter(String paramString, Paint paramPaint, Canvas paramCanvas) {
    if (paramPaint.getColor() == 0)
      return; 
    if (paramPaint.getStyle() == Paint.Style.STROKE && paramPaint.getStrokeWidth() == 0.0F)
      return; 
    paramCanvas.drawText(paramString, 0, paramString.length(), 0.0F, 0.0F, paramPaint);
  }
  
  private void drawCharacterAsGlyph(FontCharacter paramFontCharacter, float paramFloat, DocumentData paramDocumentData, Canvas paramCanvas) {
    List<ContentGroup> list = getContentsForCharacter(paramFontCharacter);
    int i;
    for (i = 0; i < list.size(); i++) {
      Path path = ((ContentGroup)list.get(i)).getPath();
      path.computeBounds(this.rectF, false);
      this.matrix.reset();
      this.matrix.preTranslate(0.0F, -paramDocumentData.baselineShift * Utils.dpScale());
      this.matrix.preScale(paramFloat, paramFloat);
      path.transform(this.matrix);
      if (paramDocumentData.strokeOverFill) {
        drawGlyph(path, this.fillPaint, paramCanvas);
        drawGlyph(path, this.strokePaint, paramCanvas);
      } else {
        drawGlyph(path, this.strokePaint, paramCanvas);
        drawGlyph(path, this.fillPaint, paramCanvas);
      } 
    } 
  }
  
  private void drawCharacterFromFont(String paramString, DocumentData paramDocumentData, Canvas paramCanvas) {
    if (paramDocumentData.strokeOverFill) {
      drawCharacter(paramString, this.fillPaint, paramCanvas);
      drawCharacter(paramString, this.strokePaint, paramCanvas);
      return;
    } 
    drawCharacter(paramString, this.strokePaint, paramCanvas);
    drawCharacter(paramString, this.fillPaint, paramCanvas);
  }
  
  private void drawFontTextLine(String paramString, DocumentData paramDocumentData, Canvas paramCanvas, float paramFloat) {
    int i = 0;
    while (i < paramString.length()) {
      String str = codePointToString(paramString, i);
      i += str.length();
      drawCharacterFromFont(str, paramDocumentData, paramCanvas);
      paramCanvas.translate(this.fillPaint.measureText(str) + paramFloat, 0.0F);
    } 
  }
  
  private void drawGlyph(Path paramPath, Paint paramPaint, Canvas paramCanvas) {
    if (paramPaint.getColor() == 0)
      return; 
    if (paramPaint.getStyle() == Paint.Style.STROKE && paramPaint.getStrokeWidth() == 0.0F)
      return; 
    paramCanvas.drawPath(paramPath, paramPaint);
  }
  
  private void drawGlyphTextLine(String paramString, DocumentData paramDocumentData, Font paramFont, Canvas paramCanvas, float paramFloat1, float paramFloat2, float paramFloat3) {
    int i;
    for (i = 0; i < paramString.length(); i++) {
      int j = FontCharacter.hashFor(paramString.charAt(i), paramFont.getFamily(), paramFont.getStyle());
      FontCharacter fontCharacter = (FontCharacter)this.composition.getCharacters().get(j);
      if (fontCharacter != null) {
        drawCharacterAsGlyph(fontCharacter, paramFloat2, paramDocumentData, paramCanvas);
        paramCanvas.translate((float)fontCharacter.getWidth() * paramFloat2 * Utils.dpScale() + paramFloat3, 0.0F);
      } 
    } 
  }
  
  private void drawTextWithFont(DocumentData paramDocumentData, Font paramFont, Canvas paramCanvas) {
    // Byte code:
    //   0: aload_0
    //   1: aload_2
    //   2: invokespecial getTypeface : (Lcom/airbnb/lottie/model/Font;)Landroid/graphics/Typeface;
    //   5: astore #12
    //   7: aload #12
    //   9: ifnonnull -> 13
    //   12: return
    //   13: aload_1
    //   14: getfield text : Ljava/lang/String;
    //   17: astore #11
    //   19: aload_0
    //   20: getfield lottieDrawable : Lcom/airbnb/lottie/LottieDrawable;
    //   23: invokevirtual getTextDelegate : ()Lcom/airbnb/lottie/TextDelegate;
    //   26: pop
    //   27: aload_0
    //   28: getfield fillPaint : Landroid/graphics/Paint;
    //   31: aload #12
    //   33: invokevirtual setTypeface : (Landroid/graphics/Typeface;)Landroid/graphics/Typeface;
    //   36: pop
    //   37: aload_0
    //   38: getfield textSizeCallbackAnimation : Lcom/airbnb/lottie/animation/keyframe/BaseKeyframeAnimation;
    //   41: astore #12
    //   43: aload #12
    //   45: ifnull -> 64
    //   48: aload #12
    //   50: invokevirtual getValue : ()Ljava/lang/Object;
    //   53: checkcast java/lang/Float
    //   56: invokevirtual floatValue : ()F
    //   59: fstore #4
    //   61: goto -> 70
    //   64: aload_1
    //   65: getfield size : F
    //   68: fstore #4
    //   70: aload_0
    //   71: getfield fillPaint : Landroid/graphics/Paint;
    //   74: invokestatic dpScale : ()F
    //   77: fload #4
    //   79: fmul
    //   80: invokevirtual setTextSize : (F)V
    //   83: aload_0
    //   84: getfield strokePaint : Landroid/graphics/Paint;
    //   87: aload_0
    //   88: getfield fillPaint : Landroid/graphics/Paint;
    //   91: invokevirtual getTypeface : ()Landroid/graphics/Typeface;
    //   94: invokevirtual setTypeface : (Landroid/graphics/Typeface;)Landroid/graphics/Typeface;
    //   97: pop
    //   98: aload_0
    //   99: getfield strokePaint : Landroid/graphics/Paint;
    //   102: aload_0
    //   103: getfield fillPaint : Landroid/graphics/Paint;
    //   106: invokevirtual getTextSize : ()F
    //   109: invokevirtual setTextSize : (F)V
    //   112: aload_1
    //   113: getfield tracking : I
    //   116: i2f
    //   117: ldc_w 10.0
    //   120: fdiv
    //   121: fstore #6
    //   123: aload_0
    //   124: getfield trackingCallbackAnimation : Lcom/airbnb/lottie/animation/keyframe/BaseKeyframeAnimation;
    //   127: astore #12
    //   129: aload #12
    //   131: ifnull -> 157
    //   134: aload #12
    //   136: invokevirtual getValue : ()Ljava/lang/Object;
    //   139: checkcast java/lang/Float
    //   142: invokevirtual floatValue : ()F
    //   145: fstore #5
    //   147: fload #6
    //   149: fload #5
    //   151: fadd
    //   152: fstore #5
    //   154: goto -> 188
    //   157: aload_0
    //   158: getfield trackingAnimation : Lcom/airbnb/lottie/animation/keyframe/BaseKeyframeAnimation;
    //   161: astore #12
    //   163: fload #6
    //   165: fstore #5
    //   167: aload #12
    //   169: ifnull -> 188
    //   172: aload #12
    //   174: invokevirtual getValue : ()Ljava/lang/Object;
    //   177: checkcast java/lang/Float
    //   180: invokevirtual floatValue : ()F
    //   183: fstore #5
    //   185: goto -> 147
    //   188: fload #5
    //   190: invokestatic dpScale : ()F
    //   193: fmul
    //   194: fload #4
    //   196: fmul
    //   197: ldc_w 100.0
    //   200: fdiv
    //   201: fstore #5
    //   203: aload_0
    //   204: aload #11
    //   206: invokespecial getTextLines : (Ljava/lang/String;)Ljava/util/List;
    //   209: astore #11
    //   211: aload #11
    //   213: invokeinterface size : ()I
    //   218: istore #10
    //   220: iconst_0
    //   221: istore #7
    //   223: iconst_m1
    //   224: istore #8
    //   226: iload #7
    //   228: iload #10
    //   230: if_icmpge -> 374
    //   233: aload #11
    //   235: iload #7
    //   237: invokeinterface get : (I)Ljava/lang/Object;
    //   242: checkcast java/lang/String
    //   245: astore #12
    //   247: aload_1
    //   248: getfield boxSize : Landroid/graphics/PointF;
    //   251: astore #13
    //   253: aload #13
    //   255: ifnonnull -> 264
    //   258: fconst_0
    //   259: fstore #4
    //   261: goto -> 271
    //   264: aload #13
    //   266: getfield x : F
    //   269: fstore #4
    //   271: aload_0
    //   272: aload #12
    //   274: fload #4
    //   276: aload_2
    //   277: fconst_0
    //   278: fload #5
    //   280: iconst_0
    //   281: invokespecial splitGlyphTextIntoLines : (Ljava/lang/String;FLcom/airbnb/lottie/model/Font;FFZ)Ljava/util/List;
    //   284: astore #12
    //   286: iconst_0
    //   287: istore #9
    //   289: iload #9
    //   291: aload #12
    //   293: invokeinterface size : ()I
    //   298: if_icmpge -> 365
    //   301: aload #12
    //   303: iload #9
    //   305: invokeinterface get : (I)Ljava/lang/Object;
    //   310: checkcast com/airbnb/lottie/model/layer/TextLayer$TextSubLine
    //   313: astore #13
    //   315: iload #8
    //   317: iconst_1
    //   318: iadd
    //   319: istore #8
    //   321: aload_3
    //   322: invokevirtual save : ()I
    //   325: pop
    //   326: aload_0
    //   327: aload_3
    //   328: aload_1
    //   329: iload #8
    //   331: aload #13
    //   333: invokestatic access$000 : (Lcom/airbnb/lottie/model/layer/TextLayer$TextSubLine;)F
    //   336: invokespecial offsetCanvas : (Landroid/graphics/Canvas;Lcom/airbnb/lottie/model/DocumentData;IF)V
    //   339: aload_0
    //   340: aload #13
    //   342: invokestatic access$100 : (Lcom/airbnb/lottie/model/layer/TextLayer$TextSubLine;)Ljava/lang/String;
    //   345: aload_1
    //   346: aload_3
    //   347: fload #5
    //   349: invokespecial drawFontTextLine : (Ljava/lang/String;Lcom/airbnb/lottie/model/DocumentData;Landroid/graphics/Canvas;F)V
    //   352: aload_3
    //   353: invokevirtual restore : ()V
    //   356: iload #9
    //   358: iconst_1
    //   359: iadd
    //   360: istore #9
    //   362: goto -> 289
    //   365: iload #7
    //   367: iconst_1
    //   368: iadd
    //   369: istore #7
    //   371: goto -> 226
    //   374: return
  }
  
  private void drawTextWithGlyphs(DocumentData paramDocumentData, Matrix paramMatrix, Font paramFont, Canvas paramCanvas) {
    // Byte code:
    //   0: aload_0
    //   1: getfield textSizeCallbackAnimation : Lcom/airbnb/lottie/animation/keyframe/BaseKeyframeAnimation;
    //   4: astore #13
    //   6: aload #13
    //   8: ifnull -> 27
    //   11: aload #13
    //   13: invokevirtual getValue : ()Ljava/lang/Object;
    //   16: checkcast java/lang/Float
    //   19: invokevirtual floatValue : ()F
    //   22: fstore #5
    //   24: goto -> 33
    //   27: aload_1
    //   28: getfield size : F
    //   31: fstore #5
    //   33: fload #5
    //   35: ldc_w 100.0
    //   38: fdiv
    //   39: fstore #7
    //   41: aload_2
    //   42: invokestatic getScale : (Landroid/graphics/Matrix;)F
    //   45: fstore #8
    //   47: aload_0
    //   48: aload_1
    //   49: getfield text : Ljava/lang/String;
    //   52: invokespecial getTextLines : (Ljava/lang/String;)Ljava/util/List;
    //   55: astore #13
    //   57: aload #13
    //   59: invokeinterface size : ()I
    //   64: istore #12
    //   66: aload_1
    //   67: getfield tracking : I
    //   70: i2f
    //   71: ldc_w 10.0
    //   74: fdiv
    //   75: fstore #6
    //   77: aload_0
    //   78: getfield trackingCallbackAnimation : Lcom/airbnb/lottie/animation/keyframe/BaseKeyframeAnimation;
    //   81: astore_2
    //   82: aload_2
    //   83: ifnull -> 108
    //   86: aload_2
    //   87: invokevirtual getValue : ()Ljava/lang/Object;
    //   90: checkcast java/lang/Float
    //   93: invokevirtual floatValue : ()F
    //   96: fstore #5
    //   98: fload #6
    //   100: fload #5
    //   102: fadd
    //   103: fstore #5
    //   105: goto -> 136
    //   108: aload_0
    //   109: getfield trackingAnimation : Lcom/airbnb/lottie/animation/keyframe/BaseKeyframeAnimation;
    //   112: astore_2
    //   113: fload #6
    //   115: fstore #5
    //   117: aload_2
    //   118: ifnull -> 136
    //   121: aload_2
    //   122: invokevirtual getValue : ()Ljava/lang/Object;
    //   125: checkcast java/lang/Float
    //   128: invokevirtual floatValue : ()F
    //   131: fstore #5
    //   133: goto -> 98
    //   136: iconst_0
    //   137: istore #9
    //   139: iconst_m1
    //   140: istore #11
    //   142: iload #9
    //   144: iload #12
    //   146: if_icmpge -> 295
    //   149: aload #13
    //   151: iload #9
    //   153: invokeinterface get : (I)Ljava/lang/Object;
    //   158: checkcast java/lang/String
    //   161: astore_2
    //   162: aload_1
    //   163: getfield boxSize : Landroid/graphics/PointF;
    //   166: astore #14
    //   168: aload #14
    //   170: ifnonnull -> 179
    //   173: fconst_0
    //   174: fstore #6
    //   176: goto -> 186
    //   179: aload #14
    //   181: getfield x : F
    //   184: fstore #6
    //   186: aload_0
    //   187: aload_2
    //   188: fload #6
    //   190: aload_3
    //   191: fload #7
    //   193: fload #5
    //   195: iconst_1
    //   196: invokespecial splitGlyphTextIntoLines : (Ljava/lang/String;FLcom/airbnb/lottie/model/Font;FFZ)Ljava/util/List;
    //   199: astore_2
    //   200: iconst_0
    //   201: istore #10
    //   203: iload #10
    //   205: aload_2
    //   206: invokeinterface size : ()I
    //   211: if_icmpge -> 286
    //   214: aload_2
    //   215: iload #10
    //   217: invokeinterface get : (I)Ljava/lang/Object;
    //   222: checkcast com/airbnb/lottie/model/layer/TextLayer$TextSubLine
    //   225: astore #14
    //   227: iload #11
    //   229: iconst_1
    //   230: iadd
    //   231: istore #11
    //   233: aload #4
    //   235: invokevirtual save : ()I
    //   238: pop
    //   239: aload_0
    //   240: aload #4
    //   242: aload_1
    //   243: iload #11
    //   245: aload #14
    //   247: invokestatic access$000 : (Lcom/airbnb/lottie/model/layer/TextLayer$TextSubLine;)F
    //   250: invokespecial offsetCanvas : (Landroid/graphics/Canvas;Lcom/airbnb/lottie/model/DocumentData;IF)V
    //   253: aload_0
    //   254: aload #14
    //   256: invokestatic access$100 : (Lcom/airbnb/lottie/model/layer/TextLayer$TextSubLine;)Ljava/lang/String;
    //   259: aload_1
    //   260: aload_3
    //   261: aload #4
    //   263: fload #8
    //   265: fload #7
    //   267: fload #5
    //   269: invokespecial drawGlyphTextLine : (Ljava/lang/String;Lcom/airbnb/lottie/model/DocumentData;Lcom/airbnb/lottie/model/Font;Landroid/graphics/Canvas;FFF)V
    //   272: aload #4
    //   274: invokevirtual restore : ()V
    //   277: iload #10
    //   279: iconst_1
    //   280: iadd
    //   281: istore #10
    //   283: goto -> 203
    //   286: iload #9
    //   288: iconst_1
    //   289: iadd
    //   290: istore #9
    //   292: goto -> 142
    //   295: return
  }
  
  private TextSubLine ensureEnoughSubLines(int paramInt) {
    for (int i = this.textSubLines.size(); i < paramInt; i++)
      this.textSubLines.add(new TextSubLine()); 
    return this.textSubLines.get(paramInt - 1);
  }
  
  private List<ContentGroup> getContentsForCharacter(FontCharacter paramFontCharacter) {
    if (this.contentsForCharacter.containsKey(paramFontCharacter))
      return this.contentsForCharacter.get(paramFontCharacter); 
    List<ShapeGroup> list = paramFontCharacter.getShapes();
    int j = list.size();
    ArrayList<ContentGroup> arrayList = new ArrayList(j);
    for (int i = 0; i < j; i++) {
      ShapeGroup shapeGroup = list.get(i);
      arrayList.add(new ContentGroup(this.lottieDrawable, this, shapeGroup, this.composition));
    } 
    this.contentsForCharacter.put(paramFontCharacter, arrayList);
    return arrayList;
  }
  
  private List<String> getTextLines(String paramString) {
    return Arrays.asList(paramString.replaceAll("\r\n", "\r").replaceAll("\003", "\r").replaceAll("\n", "\r").split("\r"));
  }
  
  @Nullable
  private Typeface getTypeface(Font paramFont) {
    BaseKeyframeAnimation<Typeface, Typeface> baseKeyframeAnimation = this.typefaceCallbackAnimation;
    if (baseKeyframeAnimation != null) {
      Typeface typeface1 = (Typeface)baseKeyframeAnimation.getValue();
      if (typeface1 != null)
        return typeface1; 
    } 
    Typeface typeface = this.lottieDrawable.getTypeface(paramFont);
    return (typeface != null) ? typeface : paramFont.getTypeface();
  }
  
  private boolean isModifier(int paramInt) {
    return (Character.getType(paramInt) == 16 || Character.getType(paramInt) == 27 || Character.getType(paramInt) == 6 || Character.getType(paramInt) == 28 || Character.getType(paramInt) == 8 || Character.getType(paramInt) == 19);
  }
  
  private void offsetCanvas(Canvas paramCanvas, DocumentData paramDocumentData, int paramInt, float paramFloat) {
    float f1;
    PointF pointF1 = paramDocumentData.boxPosition;
    PointF pointF2 = paramDocumentData.boxSize;
    float f3 = Utils.dpScale();
    float f2 = 0.0F;
    if (pointF1 == null) {
      f1 = 0.0F;
    } else {
      f1 = paramDocumentData.lineHeight * f3 + pointF1.y;
    } 
    f3 = paramInt * paramDocumentData.lineHeight * f3 + f1;
    if (pointF1 == null) {
      f1 = 0.0F;
    } else {
      f1 = pointF1.x;
    } 
    if (pointF2 != null)
      f2 = pointF2.x; 
    paramInt = null.$SwitchMap$com$airbnb$lottie$model$DocumentData$Justification[paramDocumentData.justification.ordinal()];
    if (paramInt != 1) {
      if (paramInt != 2) {
        if (paramInt != 3)
          return; 
        paramCanvas.translate(f1 + f2 / 2.0F - paramFloat / 2.0F, f3);
        return;
      } 
      paramCanvas.translate(f1 + f2 - paramFloat, f3);
      return;
    } 
    paramCanvas.translate(f1, f3);
  }
  
  private List<TextSubLine> splitGlyphTextIntoLines(String paramString, float paramFloat1, Font paramFont, float paramFloat2, float paramFloat3, boolean paramBoolean) {
    int i = 0;
    float f2 = 0.0F;
    byte b = 0;
    int j = 0;
    boolean bool1 = false;
    float f1 = 0.0F;
    boolean bool2 = false;
    float f3;
    for (f3 = 0.0F;; f3 = f5) {
      float f4;
      float f5;
      int k;
      boolean bool3;
      byte b1;
      boolean bool4;
      if (i < paramString.length()) {
        char c = paramString.charAt(i);
        if (paramBoolean) {
          k = FontCharacter.hashFor(c, paramFont.getFamily(), paramFont.getStyle());
          FontCharacter fontCharacter = (FontCharacter)this.composition.getCharacters().get(k);
          if (fontCharacter == null) {
            b1 = b;
            k = j;
            bool4 = bool1;
            f4 = f1;
            bool3 = bool2;
            f5 = f3;
          } else {
            float f = (float)fontCharacter.getWidth() * paramFloat2 * Utils.dpScale();
            f += paramFloat3;
          } 
        } else {
          float f = this.fillPaint.measureText(paramString.substring(i, i + 1));
          f += paramFloat3;
        } 
      } else {
        break;
      } 
      i++;
      b = b1;
      j = k;
      bool1 = bool4;
      f1 = f4;
      bool2 = bool3;
    } 
    i = b;
    if (f2 > 0.0F) {
      i = b + 1;
      ensureEnoughSubLines(i).set(paramString.substring(j), f2);
    } 
    return this.textSubLines.subList(0, i);
  }
  
  public <T> void addValueCallback(T paramT, @Nullable LottieValueCallback<T> paramLottieValueCallback) {
    ValueCallbackKeyframeAnimation valueCallbackKeyframeAnimation;
    super.addValueCallback(paramT, paramLottieValueCallback);
    if (paramT == LottieProperty.COLOR) {
      BaseKeyframeAnimation<Integer, Integer> baseKeyframeAnimation = this.colorCallbackAnimation;
      if (baseKeyframeAnimation != null)
        removeAnimation(baseKeyframeAnimation); 
      if (paramLottieValueCallback == null) {
        this.colorCallbackAnimation = null;
        return;
      } 
      valueCallbackKeyframeAnimation = new ValueCallbackKeyframeAnimation(paramLottieValueCallback);
      this.colorCallbackAnimation = (BaseKeyframeAnimation<Integer, Integer>)valueCallbackKeyframeAnimation;
      valueCallbackKeyframeAnimation.addUpdateListener((BaseKeyframeAnimation.AnimationListener)this);
      addAnimation(this.colorCallbackAnimation);
      return;
    } 
    if (valueCallbackKeyframeAnimation == LottieProperty.STROKE_COLOR) {
      BaseKeyframeAnimation<Integer, Integer> baseKeyframeAnimation = this.strokeColorCallbackAnimation;
      if (baseKeyframeAnimation != null)
        removeAnimation(baseKeyframeAnimation); 
      if (paramLottieValueCallback == null) {
        this.strokeColorCallbackAnimation = null;
        return;
      } 
      valueCallbackKeyframeAnimation = new ValueCallbackKeyframeAnimation(paramLottieValueCallback);
      this.strokeColorCallbackAnimation = (BaseKeyframeAnimation<Integer, Integer>)valueCallbackKeyframeAnimation;
      valueCallbackKeyframeAnimation.addUpdateListener((BaseKeyframeAnimation.AnimationListener)this);
      addAnimation(this.strokeColorCallbackAnimation);
      return;
    } 
    if (valueCallbackKeyframeAnimation == LottieProperty.STROKE_WIDTH) {
      BaseKeyframeAnimation<Float, Float> baseKeyframeAnimation = this.strokeWidthCallbackAnimation;
      if (baseKeyframeAnimation != null)
        removeAnimation(baseKeyframeAnimation); 
      if (paramLottieValueCallback == null) {
        this.strokeWidthCallbackAnimation = null;
        return;
      } 
      valueCallbackKeyframeAnimation = new ValueCallbackKeyframeAnimation(paramLottieValueCallback);
      this.strokeWidthCallbackAnimation = (BaseKeyframeAnimation<Float, Float>)valueCallbackKeyframeAnimation;
      valueCallbackKeyframeAnimation.addUpdateListener((BaseKeyframeAnimation.AnimationListener)this);
      addAnimation(this.strokeWidthCallbackAnimation);
      return;
    } 
    if (valueCallbackKeyframeAnimation == LottieProperty.TEXT_TRACKING) {
      BaseKeyframeAnimation<Float, Float> baseKeyframeAnimation = this.trackingCallbackAnimation;
      if (baseKeyframeAnimation != null)
        removeAnimation(baseKeyframeAnimation); 
      if (paramLottieValueCallback == null) {
        this.trackingCallbackAnimation = null;
        return;
      } 
      valueCallbackKeyframeAnimation = new ValueCallbackKeyframeAnimation(paramLottieValueCallback);
      this.trackingCallbackAnimation = (BaseKeyframeAnimation<Float, Float>)valueCallbackKeyframeAnimation;
      valueCallbackKeyframeAnimation.addUpdateListener((BaseKeyframeAnimation.AnimationListener)this);
      addAnimation(this.trackingCallbackAnimation);
      return;
    } 
    if (valueCallbackKeyframeAnimation == LottieProperty.TEXT_SIZE) {
      BaseKeyframeAnimation<Float, Float> baseKeyframeAnimation = this.textSizeCallbackAnimation;
      if (baseKeyframeAnimation != null)
        removeAnimation(baseKeyframeAnimation); 
      if (paramLottieValueCallback == null) {
        this.textSizeCallbackAnimation = null;
        return;
      } 
      valueCallbackKeyframeAnimation = new ValueCallbackKeyframeAnimation(paramLottieValueCallback);
      this.textSizeCallbackAnimation = (BaseKeyframeAnimation<Float, Float>)valueCallbackKeyframeAnimation;
      valueCallbackKeyframeAnimation.addUpdateListener((BaseKeyframeAnimation.AnimationListener)this);
      addAnimation(this.textSizeCallbackAnimation);
      return;
    } 
    if (valueCallbackKeyframeAnimation == LottieProperty.TYPEFACE) {
      BaseKeyframeAnimation<Typeface, Typeface> baseKeyframeAnimation = this.typefaceCallbackAnimation;
      if (baseKeyframeAnimation != null)
        removeAnimation(baseKeyframeAnimation); 
      if (paramLottieValueCallback == null) {
        this.typefaceCallbackAnimation = null;
        return;
      } 
      valueCallbackKeyframeAnimation = new ValueCallbackKeyframeAnimation(paramLottieValueCallback);
      this.typefaceCallbackAnimation = (BaseKeyframeAnimation<Typeface, Typeface>)valueCallbackKeyframeAnimation;
      valueCallbackKeyframeAnimation.addUpdateListener((BaseKeyframeAnimation.AnimationListener)this);
      addAnimation(this.typefaceCallbackAnimation);
      return;
    } 
    if (valueCallbackKeyframeAnimation == LottieProperty.TEXT)
      this.textAnimation.setStringValueCallback(paramLottieValueCallback); 
  }
  
  void drawLayer(Canvas paramCanvas, Matrix paramMatrix, int paramInt) {
    DocumentData documentData = (DocumentData)this.textAnimation.getValue();
    Font font = (Font)this.composition.getFonts().get(documentData.fontName);
    if (font == null)
      return; 
    paramCanvas.save();
    paramCanvas.concat(paramMatrix);
    configurePaint(documentData, paramInt);
    if (this.lottieDrawable.useTextGlyphs()) {
      drawTextWithGlyphs(documentData, paramMatrix, font, paramCanvas);
    } else {
      drawTextWithFont(documentData, font, paramCanvas);
    } 
    paramCanvas.restore();
  }
  
  public void getBounds(RectF paramRectF, Matrix paramMatrix, boolean paramBoolean) {
    super.getBounds(paramRectF, paramMatrix, paramBoolean);
    paramRectF.set(0.0F, 0.0F, this.composition.getBounds().width(), this.composition.getBounds().height());
  }
  
  private static class TextSubLine {
    private String text = "";
    
    private float width = 0.0F;
    
    private TextSubLine() {}
    
    void set(String param1String, float param1Float) {
      this.text = param1String;
      this.width = param1Float;
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\MagicAI - AI Art & Anime Art-dex2jar.jar!\com\airbnb\lottie\model\layer\TextLayer.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */