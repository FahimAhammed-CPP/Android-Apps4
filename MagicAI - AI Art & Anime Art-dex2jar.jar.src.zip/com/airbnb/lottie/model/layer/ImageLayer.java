package com.airbnb.lottie.model.layer;

import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.ColorFilter;
import android.graphics.Matrix;
import android.graphics.Paint;
import android.graphics.Rect;
import android.graphics.RectF;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import com.airbnb.lottie.LottieDrawable;
import com.airbnb.lottie.LottieImageAsset;
import com.airbnb.lottie.LottieProperty;
import com.airbnb.lottie.animation.LPaint;
import com.airbnb.lottie.animation.keyframe.BaseKeyframeAnimation;
import com.airbnb.lottie.animation.keyframe.ValueCallbackKeyframeAnimation;
import com.airbnb.lottie.utils.Utils;
import com.airbnb.lottie.value.LottieValueCallback;

public class ImageLayer extends BaseLayer {
  @Nullable
  private BaseKeyframeAnimation<ColorFilter, ColorFilter> colorFilterAnimation;
  
  private final Rect dst = new Rect();
  
  @Nullable
  private BaseKeyframeAnimation<Bitmap, Bitmap> imageAnimation;
  
  @Nullable
  private final LottieImageAsset lottieImageAsset;
  
  private final Paint paint = (Paint)new LPaint(3);
  
  private final Rect src = new Rect();
  
  ImageLayer(LottieDrawable paramLottieDrawable, Layer paramLayer) {
    super(paramLottieDrawable, paramLayer);
    this.lottieImageAsset = paramLottieDrawable.getLottieImageAssetForId(paramLayer.getRefId());
  }
  
  @Nullable
  private Bitmap getBitmap() {
    BaseKeyframeAnimation<Bitmap, Bitmap> baseKeyframeAnimation = this.imageAnimation;
    if (baseKeyframeAnimation != null) {
      Bitmap bitmap1 = (Bitmap)baseKeyframeAnimation.getValue();
      if (bitmap1 != null)
        return bitmap1; 
    } 
    String str = this.layerModel.getRefId();
    Bitmap bitmap = this.lottieDrawable.getBitmapForId(str);
    if (bitmap != null)
      return bitmap; 
    LottieImageAsset lottieImageAsset = this.lottieImageAsset;
    return (lottieImageAsset != null) ? lottieImageAsset.getBitmap() : null;
  }
  
  public <T> void addValueCallback(T paramT, @Nullable LottieValueCallback<T> paramLottieValueCallback) {
    super.addValueCallback(paramT, paramLottieValueCallback);
    if (paramT == LottieProperty.COLOR_FILTER) {
      if (paramLottieValueCallback == null) {
        this.colorFilterAnimation = null;
        return;
      } 
      this.colorFilterAnimation = (BaseKeyframeAnimation<ColorFilter, ColorFilter>)new ValueCallbackKeyframeAnimation(paramLottieValueCallback);
      return;
    } 
    if (paramT == LottieProperty.IMAGE) {
      if (paramLottieValueCallback == null) {
        this.imageAnimation = null;
        return;
      } 
      this.imageAnimation = (BaseKeyframeAnimation<Bitmap, Bitmap>)new ValueCallbackKeyframeAnimation(paramLottieValueCallback);
    } 
  }
  
  public void drawLayer(@NonNull Canvas paramCanvas, Matrix paramMatrix, int paramInt) {
    Bitmap bitmap = getBitmap();
    if (bitmap != null && !bitmap.isRecycled()) {
      if (this.lottieImageAsset == null)
        return; 
      float f = Utils.dpScale();
      this.paint.setAlpha(paramInt);
      BaseKeyframeAnimation<ColorFilter, ColorFilter> baseKeyframeAnimation = this.colorFilterAnimation;
      if (baseKeyframeAnimation != null)
        this.paint.setColorFilter((ColorFilter)baseKeyframeAnimation.getValue()); 
      paramCanvas.save();
      paramCanvas.concat(paramMatrix);
      this.src.set(0, 0, bitmap.getWidth(), bitmap.getHeight());
      if (this.lottieDrawable.getMaintainOriginalImageBounds()) {
        this.dst.set(0, 0, (int)(this.lottieImageAsset.getWidth() * f), (int)(this.lottieImageAsset.getHeight() * f));
      } else {
        this.dst.set(0, 0, (int)(bitmap.getWidth() * f), (int)(bitmap.getHeight() * f));
      } 
      paramCanvas.drawBitmap(bitmap, this.src, this.dst, this.paint);
      paramCanvas.restore();
    } 
  }
  
  public void getBounds(RectF paramRectF, Matrix paramMatrix, boolean paramBoolean) {
    super.getBounds(paramRectF, paramMatrix, paramBoolean);
    if (this.lottieImageAsset != null) {
      float f = Utils.dpScale();
      paramRectF.set(0.0F, 0.0F, this.lottieImageAsset.getWidth() * f, this.lottieImageAsset.getHeight() * f);
      this.boundsMatrix.mapRect(paramRectF);
    } 
  }
}


/* Location:              C:\soft\dex2jar-2.0\MagicAI - AI Art & Anime Art-dex2jar.jar!\com\airbnb\lottie\model\layer\ImageLayer.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */