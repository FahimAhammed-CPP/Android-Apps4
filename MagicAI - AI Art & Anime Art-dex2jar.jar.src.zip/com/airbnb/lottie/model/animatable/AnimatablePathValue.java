package com.airbnb.lottie.model.animatable;

import android.graphics.PointF;
import com.airbnb.lottie.animation.keyframe.BaseKeyframeAnimation;
import com.airbnb.lottie.animation.keyframe.PathKeyframeAnimation;
import com.airbnb.lottie.animation.keyframe.PointKeyframeAnimation;
import com.airbnb.lottie.value.Keyframe;
import java.util.List;

public class AnimatablePathValue implements AnimatableValue<PointF, PointF> {
  private final List<Keyframe<PointF>> keyframes;
  
  public AnimatablePathValue(List<Keyframe<PointF>> paramList) {
    this.keyframes = paramList;
  }
  
  public BaseKeyframeAnimation<PointF, PointF> createAnimation() {
    return (BaseKeyframeAnimation<PointF, PointF>)(((Keyframe)this.keyframes.get(0)).isStatic() ? new PointKeyframeAnimation(this.keyframes) : new PathKeyframeAnimation(this.keyframes));
  }
  
  public List<Keyframe<PointF>> getKeyframes() {
    return this.keyframes;
  }
  
  public boolean isStatic() {
    int i = this.keyframes.size();
    boolean bool2 = false;
    boolean bool1 = bool2;
    if (i == 1) {
      bool1 = bool2;
      if (((Keyframe)this.keyframes.get(0)).isStatic())
        bool1 = true; 
    } 
    return bool1;
  }
}


/* Location:              C:\soft\dex2jar-2.0\MagicAI - AI Art & Anime Art-dex2jar.jar!\com\airbnb\lottie\model\animatable\AnimatablePathValue.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */