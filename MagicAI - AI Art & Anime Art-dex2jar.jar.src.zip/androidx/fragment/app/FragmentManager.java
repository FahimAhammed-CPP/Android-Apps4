package androidx.fragment.app;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.content.Context;
import android.content.ContextWrapper;
import android.content.Intent;
import android.content.IntentSender;
import android.content.res.Configuration;
import android.os.Bundle;
import android.os.Looper;
import android.os.Parcel;
import android.os.Parcelable;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.view.ViewParent;
import androidx.activity.OnBackPressedCallback;
import androidx.activity.OnBackPressedDispatcher;
import androidx.activity.OnBackPressedDispatcherOwner;
import androidx.activity.result.ActivityResult;
import androidx.activity.result.ActivityResultCallback;
import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.ActivityResultRegistry;
import androidx.activity.result.ActivityResultRegistryOwner;
import androidx.activity.result.IntentSenderRequest;
import androidx.activity.result.contract.ActivityResultContract;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.annotation.IdRes;
import androidx.annotation.MainThread;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.annotation.RestrictTo;
import androidx.annotation.StringRes;
import androidx.core.app.MultiWindowModeChangedInfo;
import androidx.core.app.OnMultiWindowModeChangedProvider;
import androidx.core.app.OnPictureInPictureModeChangedProvider;
import androidx.core.app.PictureInPictureModeChangedInfo;
import androidx.core.content.OnConfigurationChangedProvider;
import androidx.core.content.OnTrimMemoryProvider;
import androidx.core.util.Consumer;
import androidx.core.view.MenuHost;
import androidx.core.view.MenuProvider;
import androidx.fragment.R;
import androidx.fragment.app.strictmode.FragmentStrictMode;
import androidx.lifecycle.Lifecycle;
import androidx.lifecycle.LifecycleEventObserver;
import androidx.lifecycle.LifecycleObserver;
import androidx.lifecycle.LifecycleOwner;
import androidx.lifecycle.ViewModelStore;
import androidx.lifecycle.ViewModelStoreOwner;
import androidx.savedstate.SavedStateRegistry;
import androidx.savedstate.SavedStateRegistryOwner;
import j$.util.DesugarCollections;
import java.io.FileDescriptor;
import java.io.PrintWriter;
import java.io.Writer;
import java.util.ArrayDeque;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.concurrent.CopyOnWriteArrayList;
import java.util.concurrent.atomic.AtomicInteger;

public abstract class FragmentManager implements FragmentResultOwner {
  private static boolean DEBUG = false;
  
  private static final String EXTRA_CREATED_FILLIN_INTENT = "androidx.fragment.extra.ACTIVITY_OPTIONS_BUNDLE";
  
  static final String FRAGMENT_MANAGER_STATE_TAG = "state";
  
  static final String FRAGMENT_NAME_PREFIX = "fragment_";
  
  static final String FRAGMENT_STATE_TAG = "state";
  
  public static final int POP_BACK_STACK_INCLUSIVE = 1;
  
  static final String RESULT_NAME_PREFIX = "result_";
  
  static final String SAVED_STATE_TAG = "android:support:fragments";
  
  @RestrictTo({RestrictTo.Scope.LIBRARY})
  public static final String TAG = "FragmentManager";
  
  ArrayList<BackStackRecord> mBackStack;
  
  private ArrayList<OnBackStackChangedListener> mBackStackChangeListeners;
  
  private final AtomicInteger mBackStackIndex = new AtomicInteger();
  
  private final Map<String, BackStackState> mBackStackStates = DesugarCollections.synchronizedMap(new HashMap<Object, Object>());
  
  private FragmentContainer mContainer;
  
  private ArrayList<Fragment> mCreatedMenus;
  
  int mCurState = -1;
  
  private SpecialEffectsControllerFactory mDefaultSpecialEffectsControllerFactory = new SpecialEffectsControllerFactory() {
      @NonNull
      public SpecialEffectsController createController(@NonNull ViewGroup param1ViewGroup) {
        return (SpecialEffectsController)new DefaultSpecialEffectsController(param1ViewGroup);
      }
    };
  
  private boolean mDestroyed;
  
  private Runnable mExecCommit = new Runnable() {
      public void run() {
        FragmentManager.this.execPendingActions(true);
      }
    };
  
  private boolean mExecutingActions;
  
  private FragmentFactory mFragmentFactory = null;
  
  private final FragmentStore mFragmentStore = new FragmentStore();
  
  private boolean mHavePendingDeferredStart;
  
  private FragmentHostCallback<?> mHost;
  
  private FragmentFactory mHostFragmentFactory = new FragmentFactory() {
      @NonNull
      public Fragment instantiate(@NonNull ClassLoader param1ClassLoader, @NonNull String param1String) {
        return FragmentManager.this.getHost().instantiate(FragmentManager.this.getHost().getContext(), param1String, null);
      }
    };
  
  ArrayDeque<LaunchedFragmentInfo> mLaunchedFragments = new ArrayDeque<LaunchedFragmentInfo>();
  
  private final FragmentLayoutInflaterFactory mLayoutInflaterFactory = new FragmentLayoutInflaterFactory(this);
  
  private final FragmentLifecycleCallbacksDispatcher mLifecycleCallbacksDispatcher = new FragmentLifecycleCallbacksDispatcher(this);
  
  private final MenuProvider mMenuProvider = new MenuProvider() {
      public void onCreateMenu(@NonNull Menu param1Menu, @NonNull MenuInflater param1MenuInflater) {
        FragmentManager.this.dispatchCreateOptionsMenu(param1Menu, param1MenuInflater);
      }
      
      public void onMenuClosed(@NonNull Menu param1Menu) {
        FragmentManager.this.dispatchOptionsMenuClosed(param1Menu);
      }
      
      public boolean onMenuItemSelected(@NonNull MenuItem param1MenuItem) {
        return FragmentManager.this.dispatchOptionsItemSelected(param1MenuItem);
      }
      
      public void onPrepareMenu(@NonNull Menu param1Menu) {
        FragmentManager.this.dispatchPrepareOptionsMenu(param1Menu);
      }
    };
  
  private boolean mNeedMenuInvalidate;
  
  private FragmentManagerViewModel mNonConfig;
  
  private final CopyOnWriteArrayList<FragmentOnAttachListener> mOnAttachListeners = new CopyOnWriteArrayList<FragmentOnAttachListener>();
  
  private final OnBackPressedCallback mOnBackPressedCallback = new OnBackPressedCallback(false) {
      public void handleOnBackPressed() {
        FragmentManager.this.handleOnBackPressed();
      }
    };
  
  private OnBackPressedDispatcher mOnBackPressedDispatcher;
  
  private final Consumer<Configuration> mOnConfigurationChangedListener = (Consumer<Configuration>)new FragmentManager$.ExternalSyntheticLambda0(this);
  
  private final Consumer<MultiWindowModeChangedInfo> mOnMultiWindowModeChangedListener = (Consumer<MultiWindowModeChangedInfo>)new FragmentManager$.ExternalSyntheticLambda2(this);
  
  private final Consumer<PictureInPictureModeChangedInfo> mOnPictureInPictureModeChangedListener = (Consumer<PictureInPictureModeChangedInfo>)new FragmentManager$.ExternalSyntheticLambda3(this);
  
  private final Consumer<Integer> mOnTrimMemoryListener = (Consumer<Integer>)new FragmentManager$.ExternalSyntheticLambda1(this);
  
  private Fragment mParent;
  
  private final ArrayList<OpGenerator> mPendingActions = new ArrayList<OpGenerator>();
  
  @Nullable
  Fragment mPrimaryNav;
  
  private ActivityResultLauncher<String[]> mRequestPermissions;
  
  private final Map<String, LifecycleAwareResultListener> mResultListeners = DesugarCollections.synchronizedMap(new HashMap<Object, Object>());
  
  private final Map<String, Bundle> mResults = DesugarCollections.synchronizedMap(new HashMap<Object, Object>());
  
  private SpecialEffectsControllerFactory mSpecialEffectsControllerFactory = null;
  
  private ActivityResultLauncher<Intent> mStartActivityForResult;
  
  private ActivityResultLauncher<IntentSenderRequest> mStartIntentSenderForResult;
  
  private boolean mStateSaved;
  
  private boolean mStopped;
  
  private FragmentStrictMode.Policy mStrictModePolicy;
  
  private ArrayList<Fragment> mTmpAddedFragments;
  
  private ArrayList<Boolean> mTmpIsPop;
  
  private ArrayList<BackStackRecord> mTmpRecords;
  
  private void checkStateLoss() {
    if (!isStateSaved())
      return; 
    throw new IllegalStateException("Can not perform this action after onSaveInstanceState");
  }
  
  private void cleanupExec() {
    this.mExecutingActions = false;
    this.mTmpIsPop.clear();
    this.mTmpRecords.clear();
  }
  
  private void clearBackStackStateViewModels() {
    boolean bool;
    FragmentHostCallback<?> fragmentHostCallback = this.mHost;
    if (fragmentHostCallback instanceof ViewModelStoreOwner) {
      bool = this.mFragmentStore.getNonConfig().isCleared();
    } else if (fragmentHostCallback.getContext() instanceof Activity) {
      bool = ((Activity)this.mHost.getContext()).isChangingConfigurations() ^ true;
    } else {
      bool = true;
    } 
    if (bool) {
      Iterator iterator = this.mBackStackStates.values().iterator();
      while (iterator.hasNext()) {
        for (String str : ((BackStackState)iterator.next()).mFragments)
          this.mFragmentStore.getNonConfig().clearNonConfigState(str); 
      } 
    } 
  }
  
  private Set<SpecialEffectsController> collectAllSpecialEffectsController() {
    HashSet<SpecialEffectsController> hashSet = new HashSet();
    Iterator iterator = this.mFragmentStore.getActiveFragmentStateManagers().iterator();
    while (iterator.hasNext()) {
      ViewGroup viewGroup = (((FragmentStateManager)iterator.next()).getFragment()).mContainer;
      if (viewGroup != null)
        hashSet.add(SpecialEffectsController.getOrCreateController(viewGroup, getSpecialEffectsControllerFactory())); 
    } 
    return hashSet;
  }
  
  private Set<SpecialEffectsController> collectChangedControllers(@NonNull ArrayList<BackStackRecord> paramArrayList, int paramInt1, int paramInt2) {
    HashSet<SpecialEffectsController> hashSet = new HashSet();
    while (paramInt1 < paramInt2) {
      Iterator iterator = ((FragmentTransaction)paramArrayList.get(paramInt1)).mOps.iterator();
      while (iterator.hasNext()) {
        Fragment fragment = ((FragmentTransaction.Op)iterator.next()).mFragment;
        if (fragment != null) {
          ViewGroup viewGroup = fragment.mContainer;
          if (viewGroup != null)
            hashSet.add(SpecialEffectsController.getOrCreateController(viewGroup, this)); 
        } 
      } 
      paramInt1++;
    } 
    return hashSet;
  }
  
  private void dispatchParentPrimaryNavigationFragmentChanged(@Nullable Fragment paramFragment) {
    if (paramFragment != null && paramFragment.equals(findActiveFragment(paramFragment.mWho)))
      paramFragment.performPrimaryNavigationFragmentChanged(); 
  }
  
  private void dispatchStateChange(int paramInt) {
    try {
      this.mExecutingActions = true;
      this.mFragmentStore.dispatchStateChange(paramInt);
      moveToState(paramInt, false);
      Iterator<SpecialEffectsController> iterator = collectAllSpecialEffectsController().iterator();
      while (iterator.hasNext())
        ((SpecialEffectsController)iterator.next()).forceCompleteAllOperations(); 
      this.mExecutingActions = false;
      return;
    } finally {
      this.mExecutingActions = false;
    } 
  }
  
  private void doPendingDeferredStart() {
    if (this.mHavePendingDeferredStart) {
      this.mHavePendingDeferredStart = false;
      startPendingDeferredFragments();
    } 
  }
  
  @Deprecated
  public static void enableDebugLogging(boolean paramBoolean) {
    DEBUG = paramBoolean;
  }
  
  private void endAnimatingAwayFragments() {
    Iterator<SpecialEffectsController> iterator = collectAllSpecialEffectsController().iterator();
    while (iterator.hasNext())
      ((SpecialEffectsController)iterator.next()).forceCompleteAllOperations(); 
  }
  
  private void ensureExecReady(boolean paramBoolean) {
    if (!this.mExecutingActions) {
      if (this.mHost == null) {
        if (this.mDestroyed)
          throw new IllegalStateException("FragmentManager has been destroyed"); 
        throw new IllegalStateException("FragmentManager has not been attached to a host.");
      } 
      if (Looper.myLooper() == this.mHost.getHandler().getLooper()) {
        if (!paramBoolean)
          checkStateLoss(); 
        if (this.mTmpRecords == null) {
          this.mTmpRecords = new ArrayList<BackStackRecord>();
          this.mTmpIsPop = new ArrayList<Boolean>();
        } 
        return;
      } 
      throw new IllegalStateException("Must be called from main thread of fragment host");
    } 
    throw new IllegalStateException("FragmentManager is already executing transactions");
  }
  
  private static void executeOps(@NonNull ArrayList<BackStackRecord> paramArrayList, @NonNull ArrayList<Boolean> paramArrayList1, int paramInt1, int paramInt2) {
    while (paramInt1 < paramInt2) {
      BackStackRecord backStackRecord = paramArrayList.get(paramInt1);
      if (((Boolean)paramArrayList1.get(paramInt1)).booleanValue()) {
        backStackRecord.bumpBackStackNesting(-1);
        backStackRecord.executePopOps();
      } else {
        backStackRecord.bumpBackStackNesting(1);
        backStackRecord.executeOps();
      } 
      paramInt1++;
    } 
  }
  
  private void executeOpsTogether(@NonNull ArrayList<BackStackRecord> paramArrayList, @NonNull ArrayList<Boolean> paramArrayList1, int paramInt1, int paramInt2) {
    boolean bool1 = ((FragmentTransaction)paramArrayList.get(paramInt1)).mReorderingAllowed;
    ArrayList<Fragment> arrayList = this.mTmpAddedFragments;
    if (arrayList == null) {
      this.mTmpAddedFragments = new ArrayList<Fragment>();
    } else {
      arrayList.clear();
    } 
    this.mTmpAddedFragments.addAll(this.mFragmentStore.getFragments());
    Fragment fragment = getPrimaryNavigationFragment();
    int i = paramInt1;
    boolean bool = false;
    while (i < paramInt2) {
      BackStackRecord backStackRecord = paramArrayList.get(i);
      if (!((Boolean)paramArrayList1.get(i)).booleanValue()) {
        fragment = backStackRecord.expandOps(this.mTmpAddedFragments, fragment);
      } else {
        fragment = backStackRecord.trackAddedFragmentsInPop(this.mTmpAddedFragments, fragment);
      } 
      if (bool || ((FragmentTransaction)backStackRecord).mAddToBackStack) {
        bool = true;
      } else {
        bool = false;
      } 
      i++;
    } 
    this.mTmpAddedFragments.clear();
    if (!bool1 && this.mCurState >= 1)
      for (i = paramInt1; i < paramInt2; i++) {
        Iterator iterator1 = ((FragmentTransaction)paramArrayList.get(i)).mOps.iterator();
        while (iterator1.hasNext()) {
          Fragment fragment1 = ((FragmentTransaction.Op)iterator1.next()).mFragment;
          if (fragment1 != null && fragment1.mFragmentManager != null) {
            FragmentStateManager fragmentStateManager = createOrGetFragmentStateManager(fragment1);
            this.mFragmentStore.makeActive(fragmentStateManager);
          } 
        } 
      }  
    executeOps(paramArrayList, paramArrayList1, paramInt1, paramInt2);
    bool1 = ((Boolean)paramArrayList1.get(paramInt2 - 1)).booleanValue();
    for (i = paramInt1; i < paramInt2; i++) {
      BackStackRecord backStackRecord = paramArrayList.get(i);
      if (bool1) {
        int j;
        for (j = ((FragmentTransaction)backStackRecord).mOps.size() - 1; j >= 0; j--) {
          Fragment fragment1 = ((FragmentTransaction.Op)((FragmentTransaction)backStackRecord).mOps.get(j)).mFragment;
          if (fragment1 != null)
            createOrGetFragmentStateManager(fragment1).moveToExpectedState(); 
        } 
      } else {
        Iterator iterator1 = ((FragmentTransaction)backStackRecord).mOps.iterator();
        while (iterator1.hasNext()) {
          Fragment fragment1 = ((FragmentTransaction.Op)iterator1.next()).mFragment;
          if (fragment1 != null)
            createOrGetFragmentStateManager(fragment1).moveToExpectedState(); 
        } 
      } 
    } 
    moveToState(this.mCurState, true);
    Iterator<SpecialEffectsController> iterator = collectChangedControllers(paramArrayList, paramInt1, paramInt2).iterator();
    while (true) {
      i = paramInt1;
      if (iterator.hasNext()) {
        SpecialEffectsController specialEffectsController = iterator.next();
        specialEffectsController.updateOperationDirection(bool1);
        specialEffectsController.markPostponedState();
        specialEffectsController.executePendingOperations();
        continue;
      } 
      break;
    } 
    while (i < paramInt2) {
      BackStackRecord backStackRecord = paramArrayList.get(i);
      if (((Boolean)paramArrayList1.get(i)).booleanValue() && backStackRecord.mIndex >= 0)
        backStackRecord.mIndex = -1; 
      backStackRecord.runOnCommitRunnables();
      i++;
    } 
    if (bool)
      reportBackStackChanged(); 
  }
  
  private int findBackStackIndex(@Nullable String paramString, int paramInt, boolean paramBoolean) {
    ArrayList<BackStackRecord> arrayList = this.mBackStack;
    if (arrayList != null) {
      int j;
      if (arrayList.isEmpty())
        return -1; 
      if (paramString == null && paramInt < 0)
        return paramBoolean ? 0 : (this.mBackStack.size() - 1); 
      int i;
      for (i = this.mBackStack.size() - 1; i >= 0; i--) {
        BackStackRecord backStackRecord = this.mBackStack.get(i);
        if ((paramString != null && paramString.equals(backStackRecord.getName())) || (paramInt >= 0 && paramInt == backStackRecord.mIndex))
          break; 
      } 
      if (i < 0)
        return i; 
      if (paramBoolean) {
        while (true) {
          j = i;
          if (i > 0) {
            BackStackRecord backStackRecord = this.mBackStack.get(i - 1);
            if (paramString == null || !paramString.equals(backStackRecord.getName())) {
              j = i;
              if (paramInt >= 0) {
                j = i;
                if (paramInt == backStackRecord.mIndex)
                  continue; 
              } 
              break;
            } 
            continue;
          } 
          break;
          i--;
        } 
      } else {
        if (i == this.mBackStack.size() - 1)
          return -1; 
        j = i + 1;
      } 
      return j;
    } 
    return -1;
  }
  
  @NonNull
  public static <F extends Fragment> F findFragment(@NonNull View paramView) {
    Fragment fragment = findViewFragment(paramView);
    if (fragment != null)
      return (F)fragment; 
    StringBuilder stringBuilder = new StringBuilder();
    stringBuilder.append("View ");
    stringBuilder.append(paramView);
    stringBuilder.append(" does not have a Fragment set");
    throw new IllegalStateException(stringBuilder.toString());
  }
  
  @NonNull
  static FragmentManager findFragmentManager(@NonNull View paramView) {
    Fragment fragment = findViewFragment(paramView);
    if (fragment != null) {
      if (fragment.isAdded())
        return fragment.getChildFragmentManager(); 
      StringBuilder stringBuilder1 = new StringBuilder();
      stringBuilder1.append("The Fragment ");
      stringBuilder1.append(fragment);
      stringBuilder1.append(" that owns View ");
      stringBuilder1.append(paramView);
      stringBuilder1.append(" has already been destroyed. Nested fragments should always use the child FragmentManager.");
      throw new IllegalStateException(stringBuilder1.toString());
    } 
    Context context = paramView.getContext();
    while (true) {
      if (context instanceof ContextWrapper) {
        FragmentActivity fragmentActivity;
        if (context instanceof FragmentActivity) {
          fragmentActivity = (FragmentActivity)context;
          break;
        } 
        Context context1 = ((ContextWrapper)fragmentActivity).getBaseContext();
        continue;
      } 
      context = null;
      break;
    } 
    if (context != null)
      return context.getSupportFragmentManager(); 
    StringBuilder stringBuilder = new StringBuilder();
    stringBuilder.append("View ");
    stringBuilder.append(paramView);
    stringBuilder.append(" is not within a subclass of FragmentActivity.");
    throw new IllegalStateException(stringBuilder.toString());
  }
  
  @Nullable
  private static Fragment findViewFragment(@NonNull View paramView) {
    while (paramView != null) {
      Fragment fragment = getViewFragment(paramView);
      if (fragment != null)
        return fragment; 
      ViewParent viewParent = paramView.getParent();
      if (viewParent instanceof View) {
        View view = (View)viewParent;
        continue;
      } 
      viewParent = null;
    } 
    return null;
  }
  
  private void forcePostponedTransactions() {
    Iterator<SpecialEffectsController> iterator = collectAllSpecialEffectsController().iterator();
    while (iterator.hasNext())
      ((SpecialEffectsController)iterator.next()).forcePostponedExecutePendingOperations(); 
  }
  
  private boolean generateOpsForPendingActions(@NonNull ArrayList<BackStackRecord> paramArrayList, @NonNull ArrayList<Boolean> paramArrayList1) {
    synchronized (this.mPendingActions) {
      boolean bool = this.mPendingActions.isEmpty();
      int i = 0;
      if (bool)
        return false; 
      try {
        int j = this.mPendingActions.size();
        bool = false;
        while (i < j) {
          boolean bool1 = ((OpGenerator)this.mPendingActions.get(i)).generateOps(paramArrayList, paramArrayList1);
          bool |= bool1;
          i++;
        } 
        return bool;
      } finally {
        this.mPendingActions.clear();
        this.mHost.getHandler().removeCallbacks(this.mExecCommit);
      } 
    } 
  }
  
  @NonNull
  private FragmentManagerViewModel getChildNonConfig(@NonNull Fragment paramFragment) {
    return this.mNonConfig.getChildNonConfig(paramFragment);
  }
  
  private ViewGroup getFragmentContainer(@NonNull Fragment paramFragment) {
    ViewGroup viewGroup = paramFragment.mContainer;
    if (viewGroup != null)
      return viewGroup; 
    if (paramFragment.mContainerId <= 0)
      return null; 
    if (this.mContainer.onHasView()) {
      View view = this.mContainer.onFindViewById(paramFragment.mContainerId);
      if (view instanceof ViewGroup)
        return (ViewGroup)view; 
    } 
    return null;
  }
  
  @Nullable
  static Fragment getViewFragment(@NonNull View paramView) {
    Object object = paramView.getTag(R.id.fragment_container_view_tag);
    return (object instanceof Fragment) ? (Fragment)object : null;
  }
  
  @RestrictTo({RestrictTo.Scope.LIBRARY})
  public static boolean isLoggingEnabled(int paramInt) {
    return (DEBUG || Log.isLoggable("FragmentManager", paramInt));
  }
  
  private boolean isMenuAvailable(@NonNull Fragment paramFragment) {
    return ((paramFragment.mHasMenu && paramFragment.mMenuVisible) || paramFragment.mChildFragmentManager.checkForMenus());
  }
  
  private boolean isParentAdded() {
    Fragment fragment = this.mParent;
    return (fragment == null) ? true : ((fragment.isAdded() && this.mParent.getParentFragmentManager().isParentAdded()));
  }
  
  private boolean popBackStackImmediate(@Nullable String paramString, int paramInt1, int paramInt2) {
    execPendingActions(false);
    ensureExecReady(true);
    Fragment fragment = this.mPrimaryNav;
    if (fragment != null && paramInt1 < 0 && paramString == null && fragment.getChildFragmentManager().popBackStackImmediate())
      return true; 
    boolean bool = popBackStackState(this.mTmpRecords, this.mTmpIsPop, paramString, paramInt1, paramInt2);
    if (bool) {
      this.mExecutingActions = true;
      try {
        removeRedundantOperationsAndExecute(this.mTmpRecords, this.mTmpIsPop);
      } finally {
        cleanupExec();
      } 
    } 
    updateOnBackPressedCallbackEnabled();
    doPendingDeferredStart();
    this.mFragmentStore.burpActive();
    return bool;
  }
  
  private void removeRedundantOperationsAndExecute(@NonNull ArrayList<BackStackRecord> paramArrayList, @NonNull ArrayList<Boolean> paramArrayList1) {
    if (paramArrayList.isEmpty())
      return; 
    if (paramArrayList.size() == paramArrayList1.size()) {
      int k = paramArrayList.size();
      int i = 0;
      int j;
      for (j = 0; i < k; j = m) {
        int n = i;
        int m = j;
        if (!((FragmentTransaction)paramArrayList.get(i)).mReorderingAllowed) {
          if (j != i)
            executeOpsTogether(paramArrayList, paramArrayList1, j, i); 
          j = i + 1;
          m = j;
          if (((Boolean)paramArrayList1.get(i)).booleanValue())
            while (true) {
              m = j;
              if (j < k) {
                m = j;
                if (((Boolean)paramArrayList1.get(j)).booleanValue()) {
                  m = j;
                  if (!((FragmentTransaction)paramArrayList.get(j)).mReorderingAllowed) {
                    j++;
                    continue;
                  } 
                } 
              } 
              break;
            }  
          executeOpsTogether(paramArrayList, paramArrayList1, i, m);
          n = m - 1;
        } 
        i = n + 1;
      } 
      if (j != k)
        executeOpsTogether(paramArrayList, paramArrayList1, j, k); 
      return;
    } 
    throw new IllegalStateException("Internal error with the back stack records");
  }
  
  private void reportBackStackChanged() {
    if (this.mBackStackChangeListeners != null)
      for (int i = 0; i < this.mBackStackChangeListeners.size(); i++)
        ((OnBackStackChangedListener)this.mBackStackChangeListeners.get(i)).onBackStackChanged();  
  }
  
  static int reverseTransit(int paramInt) {
    char c = ' ';
    if (paramInt != 4097)
      if (paramInt != 8194) {
        c = 'င';
        if (paramInt != 8197)
          return (paramInt != 4099) ? ((paramInt != 4100) ? 0 : 8197) : 4099; 
      } else {
        c = 'ခ';
      }  
    return c;
  }
  
  private void setVisibleRemovingFragment(@NonNull Fragment paramFragment) {
    ViewGroup viewGroup = getFragmentContainer(paramFragment);
    if (viewGroup != null && paramFragment.getEnterAnim() + paramFragment.getExitAnim() + paramFragment.getPopEnterAnim() + paramFragment.getPopExitAnim() > 0) {
      int i = R.id.visible_removing_fragment_view_tag;
      if (viewGroup.getTag(i) == null)
        viewGroup.setTag(i, paramFragment); 
      ((Fragment)viewGroup.getTag(i)).setPopDirection(paramFragment.getPopDirection());
    } 
  }
  
  private void startPendingDeferredFragments() {
    Iterator<FragmentStateManager> iterator = this.mFragmentStore.getActiveFragmentStateManagers().iterator();
    while (iterator.hasNext())
      performPendingDeferredStart(iterator.next()); 
  }
  
  private void throwException(RuntimeException paramRuntimeException) {
    Log.e("FragmentManager", paramRuntimeException.getMessage());
    Log.e("FragmentManager", "Activity state:");
    PrintWriter printWriter = new PrintWriter((Writer)new LogWriter("FragmentManager"));
    FragmentHostCallback<?> fragmentHostCallback = this.mHost;
    if (fragmentHostCallback != null) {
      try {
        fragmentHostCallback.onDump("  ", null, printWriter, new String[0]);
      } catch (Exception exception) {
        Log.e("FragmentManager", "Failed dumping state", exception);
      } 
    } else {
      try {
        dump("  ", null, (PrintWriter)exception, new String[0]);
      } catch (Exception exception1) {
        Log.e("FragmentManager", "Failed dumping state", exception1);
      } 
    } 
    throw paramRuntimeException;
  }
  
  private void updateOnBackPressedCallbackEnabled() {
    ArrayList<OpGenerator> arrayList;
    OnBackPressedCallback onBackPressedCallback;
    synchronized (this.mPendingActions) {
      boolean bool1 = this.mPendingActions.isEmpty();
      boolean bool = true;
      if (!bool1) {
        this.mOnBackPressedCallback.setEnabled(true);
        return;
      } 
      onBackPressedCallback = this.mOnBackPressedCallback;
      if (getBackStackEntryCount() <= 0 || !isPrimaryNavigation(this.mParent))
        bool = false; 
      onBackPressedCallback.setEnabled(bool);
      return;
    } 
  }
  
  void addBackStackState(BackStackRecord paramBackStackRecord) {
    if (this.mBackStack == null)
      this.mBackStack = new ArrayList<BackStackRecord>(); 
    this.mBackStack.add(paramBackStackRecord);
  }
  
  FragmentStateManager addFragment(@NonNull Fragment paramFragment) {
    String str = paramFragment.mPreviousWho;
    if (str != null)
      FragmentStrictMode.onFragmentReuse(paramFragment, str); 
    if (isLoggingEnabled(2)) {
      StringBuilder stringBuilder = new StringBuilder();
      stringBuilder.append("add: ");
      stringBuilder.append(paramFragment);
      Log.v("FragmentManager", stringBuilder.toString());
    } 
    FragmentStateManager fragmentStateManager = createOrGetFragmentStateManager(paramFragment);
    paramFragment.mFragmentManager = this;
    this.mFragmentStore.makeActive(fragmentStateManager);
    if (!paramFragment.mDetached) {
      this.mFragmentStore.addFragment(paramFragment);
      paramFragment.mRemoving = false;
      if (paramFragment.mView == null)
        paramFragment.mHiddenChanged = false; 
      if (isMenuAvailable(paramFragment))
        this.mNeedMenuInvalidate = true; 
    } 
    return fragmentStateManager;
  }
  
  public void addFragmentOnAttachListener(@NonNull FragmentOnAttachListener paramFragmentOnAttachListener) {
    this.mOnAttachListeners.add(paramFragmentOnAttachListener);
  }
  
  public void addOnBackStackChangedListener(@NonNull OnBackStackChangedListener paramOnBackStackChangedListener) {
    if (this.mBackStackChangeListeners == null)
      this.mBackStackChangeListeners = new ArrayList<OnBackStackChangedListener>(); 
    this.mBackStackChangeListeners.add(paramOnBackStackChangedListener);
  }
  
  void addRetainedFragment(@NonNull Fragment paramFragment) {
    this.mNonConfig.addRetainedFragment(paramFragment);
  }
  
  int allocBackStackIndex() {
    return this.mBackStackIndex.getAndIncrement();
  }
  
  @SuppressLint({"SyntheticAccessor"})
  void attachController(@NonNull FragmentHostCallback<?> paramFragmentHostCallback, @NonNull FragmentContainer paramFragmentContainer, @Nullable final Fragment parent) {
    if (this.mHost == null) {
      this.mHost = paramFragmentHostCallback;
      this.mContainer = paramFragmentContainer;
      this.mParent = parent;
      if (parent != null) {
        addFragmentOnAttachListener(new FragmentOnAttachListener() {
              public void onAttachFragment(@NonNull FragmentManager param1FragmentManager, @NonNull Fragment param1Fragment) {
                parent.onAttachFragment(param1Fragment);
              }
            });
      } else if (paramFragmentHostCallback instanceof FragmentOnAttachListener) {
        addFragmentOnAttachListener((FragmentOnAttachListener)paramFragmentHostCallback);
      } 
      if (this.mParent != null)
        updateOnBackPressedCallbackEnabled(); 
      if (paramFragmentHostCallback instanceof OnBackPressedDispatcherOwner) {
        Fragment fragment;
        OnBackPressedDispatcherOwner onBackPressedDispatcherOwner = (OnBackPressedDispatcherOwner)paramFragmentHostCallback;
        OnBackPressedDispatcher onBackPressedDispatcher = onBackPressedDispatcherOwner.getOnBackPressedDispatcher();
        this.mOnBackPressedDispatcher = onBackPressedDispatcher;
        if (parent != null)
          fragment = parent; 
        onBackPressedDispatcher.addCallback((LifecycleOwner)fragment, this.mOnBackPressedCallback);
      } 
      if (parent != null) {
        this.mNonConfig = parent.mFragmentManager.getChildNonConfig(parent);
      } else if (paramFragmentHostCallback instanceof ViewModelStoreOwner) {
        this.mNonConfig = FragmentManagerViewModel.getInstance(((ViewModelStoreOwner)paramFragmentHostCallback).getViewModelStore());
      } else {
        this.mNonConfig = new FragmentManagerViewModel(false);
      } 
      this.mNonConfig.setIsStateSaved(isStateSaved());
      this.mFragmentStore.setNonConfig(this.mNonConfig);
      paramFragmentHostCallback = this.mHost;
      if (paramFragmentHostCallback instanceof SavedStateRegistryOwner && parent == null) {
        SavedStateRegistry savedStateRegistry = ((SavedStateRegistryOwner)paramFragmentHostCallback).getSavedStateRegistry();
        savedStateRegistry.registerSavedStateProvider("android:support:fragments", (SavedStateRegistry.SavedStateProvider)new FragmentManager$.ExternalSyntheticLambda4(this));
        Bundle bundle = savedStateRegistry.consumeRestoredStateForKey("android:support:fragments");
        if (bundle != null)
          restoreSaveStateInternal((Parcelable)bundle); 
      } 
      paramFragmentHostCallback = this.mHost;
      if (paramFragmentHostCallback instanceof ActivityResultRegistryOwner) {
        ActivityResultRegistry activityResultRegistry = ((ActivityResultRegistryOwner)paramFragmentHostCallback).getActivityResultRegistry();
        if (parent != null) {
          StringBuilder stringBuilder1 = new StringBuilder();
          stringBuilder1.append(parent.mWho);
          stringBuilder1.append(":");
          str = stringBuilder1.toString();
        } else {
          str = "";
        } 
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("FragmentManager:");
        stringBuilder.append(str);
        String str = stringBuilder.toString();
        stringBuilder = new StringBuilder();
        stringBuilder.append(str);
        stringBuilder.append("StartActivityForResult");
        this.mStartActivityForResult = activityResultRegistry.register(stringBuilder.toString(), (ActivityResultContract)new ActivityResultContracts.StartActivityForResult(), new ActivityResultCallback<ActivityResult>() {
              public void onActivityResult(ActivityResult param1ActivityResult) {
                StringBuilder stringBuilder;
                FragmentManager.LaunchedFragmentInfo launchedFragmentInfo = FragmentManager.this.mLaunchedFragments.pollFirst();
                if (launchedFragmentInfo == null) {
                  stringBuilder = new StringBuilder();
                  stringBuilder.append("No Activities were started for result for ");
                  stringBuilder.append(this);
                  Log.w("FragmentManager", stringBuilder.toString());
                  return;
                } 
                String str = launchedFragmentInfo.mWho;
                int i = launchedFragmentInfo.mRequestCode;
                Fragment fragment = FragmentManager.this.mFragmentStore.findFragmentByWho(str);
                if (fragment == null) {
                  stringBuilder = new StringBuilder();
                  stringBuilder.append("Activity result delivered for unknown Fragment ");
                  stringBuilder.append(str);
                  Log.w("FragmentManager", stringBuilder.toString());
                  return;
                } 
                fragment.onActivityResult(i, stringBuilder.getResultCode(), stringBuilder.getData());
              }
            });
        stringBuilder = new StringBuilder();
        stringBuilder.append(str);
        stringBuilder.append("StartIntentSenderForResult");
        this.mStartIntentSenderForResult = activityResultRegistry.register(stringBuilder.toString(), new FragmentIntentSenderContract(), new ActivityResultCallback<ActivityResult>() {
              public void onActivityResult(ActivityResult param1ActivityResult) {
                StringBuilder stringBuilder;
                FragmentManager.LaunchedFragmentInfo launchedFragmentInfo = FragmentManager.this.mLaunchedFragments.pollFirst();
                if (launchedFragmentInfo == null) {
                  stringBuilder = new StringBuilder();
                  stringBuilder.append("No IntentSenders were started for ");
                  stringBuilder.append(this);
                  Log.w("FragmentManager", stringBuilder.toString());
                  return;
                } 
                String str = launchedFragmentInfo.mWho;
                int i = launchedFragmentInfo.mRequestCode;
                Fragment fragment = FragmentManager.this.mFragmentStore.findFragmentByWho(str);
                if (fragment == null) {
                  stringBuilder = new StringBuilder();
                  stringBuilder.append("Intent Sender result delivered for unknown Fragment ");
                  stringBuilder.append(str);
                  Log.w("FragmentManager", stringBuilder.toString());
                  return;
                } 
                fragment.onActivityResult(i, stringBuilder.getResultCode(), stringBuilder.getData());
              }
            });
        stringBuilder = new StringBuilder();
        stringBuilder.append(str);
        stringBuilder.append("RequestPermissions");
        this.mRequestPermissions = activityResultRegistry.register(stringBuilder.toString(), (ActivityResultContract)new ActivityResultContracts.RequestMultiplePermissions(), new ActivityResultCallback<Map<String, Boolean>>() {
              @SuppressLint({"SyntheticAccessor"})
              public void onActivityResult(Map<String, Boolean> param1Map) {
                StringBuilder stringBuilder;
                String[] arrayOfString = (String[])param1Map.keySet().toArray((Object[])new String[0]);
                ArrayList<Boolean> arrayList = new ArrayList(param1Map.values());
                int[] arrayOfInt = new int[arrayList.size()];
                int i;
                for (i = 0; i < arrayList.size(); i++) {
                  byte b;
                  if (((Boolean)arrayList.get(i)).booleanValue()) {
                    b = 0;
                  } else {
                    b = -1;
                  } 
                  arrayOfInt[i] = b;
                } 
                FragmentManager.LaunchedFragmentInfo launchedFragmentInfo = FragmentManager.this.mLaunchedFragments.pollFirst();
                if (launchedFragmentInfo == null) {
                  stringBuilder = new StringBuilder();
                  stringBuilder.append("No permissions were requested for ");
                  stringBuilder.append(this);
                  Log.w("FragmentManager", stringBuilder.toString());
                  return;
                } 
                String str = launchedFragmentInfo.mWho;
                i = launchedFragmentInfo.mRequestCode;
                Fragment fragment = FragmentManager.this.mFragmentStore.findFragmentByWho(str);
                if (fragment == null) {
                  stringBuilder = new StringBuilder();
                  stringBuilder.append("Permission request result delivered for unknown Fragment ");
                  stringBuilder.append(str);
                  Log.w("FragmentManager", stringBuilder.toString());
                  return;
                } 
                fragment.onRequestPermissionsResult(i, arrayOfString, (int[])stringBuilder);
              }
            });
      } 
      paramFragmentHostCallback = this.mHost;
      if (paramFragmentHostCallback instanceof OnConfigurationChangedProvider)
        ((OnConfigurationChangedProvider)paramFragmentHostCallback).addOnConfigurationChangedListener(this.mOnConfigurationChangedListener); 
      paramFragmentHostCallback = this.mHost;
      if (paramFragmentHostCallback instanceof OnTrimMemoryProvider)
        ((OnTrimMemoryProvider)paramFragmentHostCallback).addOnTrimMemoryListener(this.mOnTrimMemoryListener); 
      paramFragmentHostCallback = this.mHost;
      if (paramFragmentHostCallback instanceof OnMultiWindowModeChangedProvider)
        ((OnMultiWindowModeChangedProvider)paramFragmentHostCallback).addOnMultiWindowModeChangedListener(this.mOnMultiWindowModeChangedListener); 
      paramFragmentHostCallback = this.mHost;
      if (paramFragmentHostCallback instanceof OnPictureInPictureModeChangedProvider)
        ((OnPictureInPictureModeChangedProvider)paramFragmentHostCallback).addOnPictureInPictureModeChangedListener(this.mOnPictureInPictureModeChangedListener); 
      paramFragmentHostCallback = this.mHost;
      if (paramFragmentHostCallback instanceof MenuHost && parent == null)
        ((MenuHost)paramFragmentHostCallback).addMenuProvider(this.mMenuProvider); 
      return;
    } 
    throw new IllegalStateException("Already attached");
  }
  
  void attachFragment(@NonNull Fragment paramFragment) {
    if (isLoggingEnabled(2)) {
      StringBuilder stringBuilder = new StringBuilder();
      stringBuilder.append("attach: ");
      stringBuilder.append(paramFragment);
      Log.v("FragmentManager", stringBuilder.toString());
    } 
    if (paramFragment.mDetached) {
      paramFragment.mDetached = false;
      if (!paramFragment.mAdded) {
        this.mFragmentStore.addFragment(paramFragment);
        if (isLoggingEnabled(2)) {
          StringBuilder stringBuilder = new StringBuilder();
          stringBuilder.append("add from attach: ");
          stringBuilder.append(paramFragment);
          Log.v("FragmentManager", stringBuilder.toString());
        } 
        if (isMenuAvailable(paramFragment))
          this.mNeedMenuInvalidate = true; 
      } 
    } 
  }
  
  @NonNull
  public FragmentTransaction beginTransaction() {
    return (FragmentTransaction)new BackStackRecord(this);
  }
  
  boolean checkForMenus() {
    Iterator<Fragment> iterator = this.mFragmentStore.getActiveFragments().iterator();
    boolean bool = false;
    while (iterator.hasNext()) {
      Fragment fragment = iterator.next();
      boolean bool1 = bool;
      if (fragment != null)
        bool1 = isMenuAvailable(fragment); 
      bool = bool1;
      if (bool1)
        return true; 
    } 
    return false;
  }
  
  public void clearBackStack(@NonNull String paramString) {
    enqueueAction(new ClearBackStackState(paramString), false);
  }
  
  boolean clearBackStackState(@NonNull ArrayList<BackStackRecord> paramArrayList, @NonNull ArrayList<Boolean> paramArrayList1, @NonNull String paramString) {
    return !restoreBackStackState(paramArrayList, paramArrayList1, paramString) ? false : popBackStackState(paramArrayList, paramArrayList1, paramString, -1, 1);
  }
  
  public final void clearFragmentResult(@NonNull String paramString) {
    this.mResults.remove(paramString);
    if (isLoggingEnabled(2)) {
      StringBuilder stringBuilder = new StringBuilder();
      stringBuilder.append("Clearing fragment result with key ");
      stringBuilder.append(paramString);
      Log.v("FragmentManager", stringBuilder.toString());
    } 
  }
  
  public final void clearFragmentResultListener(@NonNull String paramString) {
    LifecycleAwareResultListener lifecycleAwareResultListener = this.mResultListeners.remove(paramString);
    if (lifecycleAwareResultListener != null)
      lifecycleAwareResultListener.removeObserver(); 
    if (isLoggingEnabled(2)) {
      StringBuilder stringBuilder = new StringBuilder();
      stringBuilder.append("Clearing FragmentResultListener for key ");
      stringBuilder.append(paramString);
      Log.v("FragmentManager", stringBuilder.toString());
    } 
  }
  
  @NonNull
  FragmentStateManager createOrGetFragmentStateManager(@NonNull Fragment paramFragment) {
    FragmentStateManager fragmentStateManager2 = this.mFragmentStore.getFragmentStateManager(paramFragment.mWho);
    if (fragmentStateManager2 != null)
      return fragmentStateManager2; 
    FragmentStateManager fragmentStateManager1 = new FragmentStateManager(this.mLifecycleCallbacksDispatcher, this.mFragmentStore, paramFragment);
    fragmentStateManager1.restoreState(this.mHost.getContext().getClassLoader());
    fragmentStateManager1.setFragmentManagerState(this.mCurState);
    return fragmentStateManager1;
  }
  
  void detachFragment(@NonNull Fragment paramFragment) {
    if (isLoggingEnabled(2)) {
      StringBuilder stringBuilder = new StringBuilder();
      stringBuilder.append("detach: ");
      stringBuilder.append(paramFragment);
      Log.v("FragmentManager", stringBuilder.toString());
    } 
    if (!paramFragment.mDetached) {
      paramFragment.mDetached = true;
      if (paramFragment.mAdded) {
        if (isLoggingEnabled(2)) {
          StringBuilder stringBuilder = new StringBuilder();
          stringBuilder.append("remove from detach: ");
          stringBuilder.append(paramFragment);
          Log.v("FragmentManager", stringBuilder.toString());
        } 
        this.mFragmentStore.removeFragment(paramFragment);
        if (isMenuAvailable(paramFragment))
          this.mNeedMenuInvalidate = true; 
        setVisibleRemovingFragment(paramFragment);
      } 
    } 
  }
  
  void dispatchActivityCreated() {
    this.mStateSaved = false;
    this.mStopped = false;
    this.mNonConfig.setIsStateSaved(false);
    dispatchStateChange(4);
  }
  
  void dispatchAttach() {
    this.mStateSaved = false;
    this.mStopped = false;
    this.mNonConfig.setIsStateSaved(false);
    dispatchStateChange(0);
  }
  
  void dispatchConfigurationChanged(@NonNull Configuration paramConfiguration, boolean paramBoolean) {
    if (paramBoolean && this.mHost instanceof OnConfigurationChangedProvider)
      throwException(new IllegalStateException("Do not call dispatchConfigurationChanged() on host. Host implements OnConfigurationChangedProvider and automatically dispatches configuration changes to fragments.")); 
    for (Fragment fragment : this.mFragmentStore.getFragments()) {
      if (fragment != null) {
        fragment.performConfigurationChanged(paramConfiguration);
        if (paramBoolean)
          fragment.mChildFragmentManager.dispatchConfigurationChanged(paramConfiguration, true); 
      } 
    } 
  }
  
  boolean dispatchContextItemSelected(@NonNull MenuItem paramMenuItem) {
    if (this.mCurState < 1)
      return false; 
    for (Fragment fragment : this.mFragmentStore.getFragments()) {
      if (fragment != null && fragment.performContextItemSelected(paramMenuItem))
        return true; 
    } 
    return false;
  }
  
  void dispatchCreate() {
    this.mStateSaved = false;
    this.mStopped = false;
    this.mNonConfig.setIsStateSaved(false);
    dispatchStateChange(1);
  }
  
  boolean dispatchCreateOptionsMenu(@NonNull Menu paramMenu, @NonNull MenuInflater paramMenuInflater) {
    int j = this.mCurState;
    int i = 0;
    if (j < 1)
      return false; 
    Iterator<Fragment> iterator = this.mFragmentStore.getFragments().iterator();
    ArrayList<Fragment> arrayList = null;
    boolean bool = false;
    while (iterator.hasNext()) {
      Fragment fragment = iterator.next();
      if (fragment != null && isParentMenuVisible(fragment) && fragment.performCreateOptionsMenu(paramMenu, paramMenuInflater)) {
        ArrayList<Fragment> arrayList1 = arrayList;
        if (arrayList == null)
          arrayList1 = new ArrayList(); 
        arrayList1.add(fragment);
        bool = true;
        arrayList = arrayList1;
      } 
    } 
    if (this.mCreatedMenus != null)
      while (i < this.mCreatedMenus.size()) {
        Fragment fragment = this.mCreatedMenus.get(i);
        if (arrayList == null || !arrayList.contains(fragment))
          fragment.onDestroyOptionsMenu(); 
        i++;
      }  
    this.mCreatedMenus = arrayList;
    return bool;
  }
  
  void dispatchDestroy() {
    this.mDestroyed = true;
    execPendingActions(true);
    endAnimatingAwayFragments();
    clearBackStackStateViewModels();
    dispatchStateChange(-1);
    FragmentHostCallback<?> fragmentHostCallback = this.mHost;
    if (fragmentHostCallback instanceof OnTrimMemoryProvider)
      ((OnTrimMemoryProvider)fragmentHostCallback).removeOnTrimMemoryListener(this.mOnTrimMemoryListener); 
    fragmentHostCallback = this.mHost;
    if (fragmentHostCallback instanceof OnConfigurationChangedProvider)
      ((OnConfigurationChangedProvider)fragmentHostCallback).removeOnConfigurationChangedListener(this.mOnConfigurationChangedListener); 
    fragmentHostCallback = this.mHost;
    if (fragmentHostCallback instanceof OnMultiWindowModeChangedProvider)
      ((OnMultiWindowModeChangedProvider)fragmentHostCallback).removeOnMultiWindowModeChangedListener(this.mOnMultiWindowModeChangedListener); 
    fragmentHostCallback = this.mHost;
    if (fragmentHostCallback instanceof OnPictureInPictureModeChangedProvider)
      ((OnPictureInPictureModeChangedProvider)fragmentHostCallback).removeOnPictureInPictureModeChangedListener(this.mOnPictureInPictureModeChangedListener); 
    fragmentHostCallback = this.mHost;
    if (fragmentHostCallback instanceof MenuHost && this.mParent == null)
      ((MenuHost)fragmentHostCallback).removeMenuProvider(this.mMenuProvider); 
    this.mHost = null;
    this.mContainer = null;
    this.mParent = null;
    if (this.mOnBackPressedDispatcher != null) {
      this.mOnBackPressedCallback.remove();
      this.mOnBackPressedDispatcher = null;
    } 
    ActivityResultLauncher<Intent> activityResultLauncher = this.mStartActivityForResult;
    if (activityResultLauncher != null) {
      activityResultLauncher.unregister();
      this.mStartIntentSenderForResult.unregister();
      this.mRequestPermissions.unregister();
    } 
  }
  
  void dispatchDestroyView() {
    dispatchStateChange(1);
  }
  
  void dispatchLowMemory(boolean paramBoolean) {
    if (paramBoolean && this.mHost instanceof OnTrimMemoryProvider)
      throwException(new IllegalStateException("Do not call dispatchLowMemory() on host. Host implements OnTrimMemoryProvider and automatically dispatches low memory callbacks to fragments.")); 
    for (Fragment fragment : this.mFragmentStore.getFragments()) {
      if (fragment != null) {
        fragment.performLowMemory();
        if (paramBoolean)
          fragment.mChildFragmentManager.dispatchLowMemory(true); 
      } 
    } 
  }
  
  void dispatchMultiWindowModeChanged(boolean paramBoolean1, boolean paramBoolean2) {
    if (paramBoolean2 && this.mHost instanceof OnMultiWindowModeChangedProvider)
      throwException(new IllegalStateException("Do not call dispatchMultiWindowModeChanged() on host. Host implements OnMultiWindowModeChangedProvider and automatically dispatches multi-window mode changes to fragments.")); 
    for (Fragment fragment : this.mFragmentStore.getFragments()) {
      if (fragment != null) {
        fragment.performMultiWindowModeChanged(paramBoolean1);
        if (paramBoolean2)
          fragment.mChildFragmentManager.dispatchMultiWindowModeChanged(paramBoolean1, true); 
      } 
    } 
  }
  
  void dispatchOnAttachFragment(@NonNull Fragment paramFragment) {
    Iterator<FragmentOnAttachListener> iterator = this.mOnAttachListeners.iterator();
    while (iterator.hasNext())
      ((FragmentOnAttachListener)iterator.next()).onAttachFragment(this, paramFragment); 
  }
  
  void dispatchOnHiddenChanged() {
    for (Fragment fragment : this.mFragmentStore.getActiveFragments()) {
      if (fragment != null) {
        fragment.onHiddenChanged(fragment.isHidden());
        fragment.mChildFragmentManager.dispatchOnHiddenChanged();
      } 
    } 
  }
  
  boolean dispatchOptionsItemSelected(@NonNull MenuItem paramMenuItem) {
    if (this.mCurState < 1)
      return false; 
    for (Fragment fragment : this.mFragmentStore.getFragments()) {
      if (fragment != null && fragment.performOptionsItemSelected(paramMenuItem))
        return true; 
    } 
    return false;
  }
  
  void dispatchOptionsMenuClosed(@NonNull Menu paramMenu) {
    if (this.mCurState < 1)
      return; 
    for (Fragment fragment : this.mFragmentStore.getFragments()) {
      if (fragment != null)
        fragment.performOptionsMenuClosed(paramMenu); 
    } 
  }
  
  void dispatchPause() {
    dispatchStateChange(5);
  }
  
  void dispatchPictureInPictureModeChanged(boolean paramBoolean1, boolean paramBoolean2) {
    if (paramBoolean2 && this.mHost instanceof OnPictureInPictureModeChangedProvider)
      throwException(new IllegalStateException("Do not call dispatchPictureInPictureModeChanged() on host. Host implements OnPictureInPictureModeChangedProvider and automatically dispatches picture-in-picture mode changes to fragments.")); 
    for (Fragment fragment : this.mFragmentStore.getFragments()) {
      if (fragment != null) {
        fragment.performPictureInPictureModeChanged(paramBoolean1);
        if (paramBoolean2)
          fragment.mChildFragmentManager.dispatchPictureInPictureModeChanged(paramBoolean1, true); 
      } 
    } 
  }
  
  boolean dispatchPrepareOptionsMenu(@NonNull Menu paramMenu) {
    int i = this.mCurState;
    boolean bool = false;
    if (i < 1)
      return false; 
    for (Fragment fragment : this.mFragmentStore.getFragments()) {
      if (fragment != null && isParentMenuVisible(fragment) && fragment.performPrepareOptionsMenu(paramMenu))
        bool = true; 
    } 
    return bool;
  }
  
  void dispatchPrimaryNavigationFragmentChanged() {
    updateOnBackPressedCallbackEnabled();
    dispatchParentPrimaryNavigationFragmentChanged(this.mPrimaryNav);
  }
  
  void dispatchResume() {
    this.mStateSaved = false;
    this.mStopped = false;
    this.mNonConfig.setIsStateSaved(false);
    dispatchStateChange(7);
  }
  
  void dispatchStart() {
    this.mStateSaved = false;
    this.mStopped = false;
    this.mNonConfig.setIsStateSaved(false);
    dispatchStateChange(5);
  }
  
  void dispatchStop() {
    this.mStopped = true;
    this.mNonConfig.setIsStateSaved(true);
    dispatchStateChange(4);
  }
  
  void dispatchViewCreated() {
    dispatchStateChange(2);
  }
  
  public void dump(@NonNull String paramString, @Nullable FileDescriptor paramFileDescriptor, @NonNull PrintWriter paramPrintWriter, @Nullable String[] paramArrayOfString) {
    StringBuilder stringBuilder2 = new StringBuilder();
    stringBuilder2.append(paramString);
    stringBuilder2.append("    ");
    String str = stringBuilder2.toString();
    this.mFragmentStore.dump(paramString, paramFileDescriptor, paramPrintWriter, paramArrayOfString);
    ArrayList<Fragment> arrayList1 = this.mCreatedMenus;
    byte b = 0;
    if (arrayList1 != null) {
      int i = arrayList1.size();
      if (i > 0) {
        paramPrintWriter.print(paramString);
        paramPrintWriter.println("Fragments Created Menus:");
        int j;
        for (j = 0; j < i; j++) {
          Fragment fragment = this.mCreatedMenus.get(j);
          paramPrintWriter.print(paramString);
          paramPrintWriter.print("  #");
          paramPrintWriter.print(j);
          paramPrintWriter.print(": ");
          paramPrintWriter.println(fragment.toString());
        } 
      } 
    } 
    ArrayList<BackStackRecord> arrayList = this.mBackStack;
    if (arrayList != null) {
      int i = arrayList.size();
      if (i > 0) {
        paramPrintWriter.print(paramString);
        paramPrintWriter.println("Back Stack:");
        int j;
        for (j = 0; j < i; j++) {
          BackStackRecord backStackRecord = this.mBackStack.get(j);
          paramPrintWriter.print(paramString);
          paramPrintWriter.print("  #");
          paramPrintWriter.print(j);
          paramPrintWriter.print(": ");
          paramPrintWriter.println(backStackRecord.toString());
          backStackRecord.dump(str, paramPrintWriter);
        } 
      } 
    } 
    paramPrintWriter.print(paramString);
    StringBuilder stringBuilder1 = new StringBuilder();
    stringBuilder1.append("Back Stack Index: ");
    stringBuilder1.append(this.mBackStackIndex.get());
    paramPrintWriter.println(stringBuilder1.toString());
    synchronized (this.mPendingActions) {
      int i = this.mPendingActions.size();
      if (i > 0) {
        paramPrintWriter.print(paramString);
        paramPrintWriter.println("Pending Actions:");
        int j;
        for (j = b; j < i; j++) {
          OpGenerator opGenerator = this.mPendingActions.get(j);
          paramPrintWriter.print(paramString);
          paramPrintWriter.print("  #");
          paramPrintWriter.print(j);
          paramPrintWriter.print(": ");
          paramPrintWriter.println(opGenerator);
        } 
      } 
      paramPrintWriter.print(paramString);
      paramPrintWriter.println("FragmentManager misc state:");
      paramPrintWriter.print(paramString);
      paramPrintWriter.print("  mHost=");
      paramPrintWriter.println(this.mHost);
      paramPrintWriter.print(paramString);
      paramPrintWriter.print("  mContainer=");
      paramPrintWriter.println(this.mContainer);
      if (this.mParent != null) {
        paramPrintWriter.print(paramString);
        paramPrintWriter.print("  mParent=");
        paramPrintWriter.println(this.mParent);
      } 
      paramPrintWriter.print(paramString);
      paramPrintWriter.print("  mCurState=");
      paramPrintWriter.print(this.mCurState);
      paramPrintWriter.print(" mStateSaved=");
      paramPrintWriter.print(this.mStateSaved);
      paramPrintWriter.print(" mStopped=");
      paramPrintWriter.print(this.mStopped);
      paramPrintWriter.print(" mDestroyed=");
      paramPrintWriter.println(this.mDestroyed);
      if (this.mNeedMenuInvalidate) {
        paramPrintWriter.print(paramString);
        paramPrintWriter.print("  mNeedMenuInvalidate=");
        paramPrintWriter.println(this.mNeedMenuInvalidate);
      } 
      return;
    } 
  }
  
  void enqueueAction(@NonNull OpGenerator paramOpGenerator, boolean paramBoolean) {
    if (!paramBoolean) {
      if (this.mHost == null) {
        if (this.mDestroyed)
          throw new IllegalStateException("FragmentManager has been destroyed"); 
        throw new IllegalStateException("FragmentManager has not been attached to a host.");
      } 
      checkStateLoss();
    } 
    synchronized (this.mPendingActions) {
      if (this.mHost == null) {
        if (paramBoolean)
          return; 
        throw new IllegalStateException("Activity has been destroyed");
      } 
      this.mPendingActions.add(paramOpGenerator);
      scheduleCommit();
      return;
    } 
  }
  
  boolean execPendingActions(boolean paramBoolean) {
    ensureExecReady(paramBoolean);
    paramBoolean = false;
    while (generateOpsForPendingActions(this.mTmpRecords, this.mTmpIsPop)) {
      paramBoolean = true;
      this.mExecutingActions = true;
      try {
        removeRedundantOperationsAndExecute(this.mTmpRecords, this.mTmpIsPop);
      } finally {
        cleanupExec();
      } 
    } 
    updateOnBackPressedCallbackEnabled();
    doPendingDeferredStart();
    this.mFragmentStore.burpActive();
    return paramBoolean;
  }
  
  void execSingleAction(@NonNull OpGenerator paramOpGenerator, boolean paramBoolean) {
    if (paramBoolean && (this.mHost == null || this.mDestroyed))
      return; 
    ensureExecReady(paramBoolean);
    if (paramOpGenerator.generateOps(this.mTmpRecords, this.mTmpIsPop)) {
      this.mExecutingActions = true;
      try {
        removeRedundantOperationsAndExecute(this.mTmpRecords, this.mTmpIsPop);
      } finally {
        cleanupExec();
      } 
    } 
    updateOnBackPressedCallbackEnabled();
    doPendingDeferredStart();
    this.mFragmentStore.burpActive();
  }
  
  public boolean executePendingTransactions() {
    boolean bool = execPendingActions(true);
    forcePostponedTransactions();
    return bool;
  }
  
  @Nullable
  Fragment findActiveFragment(@NonNull String paramString) {
    return this.mFragmentStore.findActiveFragment(paramString);
  }
  
  @Nullable
  public Fragment findFragmentById(@IdRes int paramInt) {
    return this.mFragmentStore.findFragmentById(paramInt);
  }
  
  @Nullable
  public Fragment findFragmentByTag(@Nullable String paramString) {
    return this.mFragmentStore.findFragmentByTag(paramString);
  }
  
  Fragment findFragmentByWho(@NonNull String paramString) {
    return this.mFragmentStore.findFragmentByWho(paramString);
  }
  
  int getActiveFragmentCount() {
    return this.mFragmentStore.getActiveFragmentCount();
  }
  
  @NonNull
  List<Fragment> getActiveFragments() {
    return this.mFragmentStore.getActiveFragments();
  }
  
  @NonNull
  public BackStackEntry getBackStackEntryAt(int paramInt) {
    return (BackStackEntry)this.mBackStack.get(paramInt);
  }
  
  public int getBackStackEntryCount() {
    ArrayList<BackStackRecord> arrayList = this.mBackStack;
    return (arrayList != null) ? arrayList.size() : 0;
  }
  
  @NonNull
  FragmentContainer getContainer() {
    return this.mContainer;
  }
  
  @Nullable
  public Fragment getFragment(@NonNull Bundle paramBundle, @NonNull String paramString) {
    String str = paramBundle.getString(paramString);
    if (str == null)
      return null; 
    Fragment fragment = findActiveFragment(str);
    if (fragment == null) {
      StringBuilder stringBuilder = new StringBuilder();
      stringBuilder.append("Fragment no longer exists for key ");
      stringBuilder.append(paramString);
      stringBuilder.append(": unique id ");
      stringBuilder.append(str);
      throwException(new IllegalStateException(stringBuilder.toString()));
    } 
    return fragment;
  }
  
  @NonNull
  public FragmentFactory getFragmentFactory() {
    FragmentFactory fragmentFactory = this.mFragmentFactory;
    if (fragmentFactory != null)
      return fragmentFactory; 
    Fragment fragment = this.mParent;
    return (fragment != null) ? fragment.mFragmentManager.getFragmentFactory() : this.mHostFragmentFactory;
  }
  
  @NonNull
  FragmentStore getFragmentStore() {
    return this.mFragmentStore;
  }
  
  @NonNull
  public List<Fragment> getFragments() {
    return this.mFragmentStore.getFragments();
  }
  
  @NonNull
  @RestrictTo({RestrictTo.Scope.LIBRARY})
  public FragmentHostCallback<?> getHost() {
    return this.mHost;
  }
  
  @NonNull
  LayoutInflater.Factory2 getLayoutInflaterFactory() {
    return (LayoutInflater.Factory2)this.mLayoutInflaterFactory;
  }
  
  @NonNull
  FragmentLifecycleCallbacksDispatcher getLifecycleCallbacksDispatcher() {
    return this.mLifecycleCallbacksDispatcher;
  }
  
  @Nullable
  Fragment getParent() {
    return this.mParent;
  }
  
  @Nullable
  public Fragment getPrimaryNavigationFragment() {
    return this.mPrimaryNav;
  }
  
  @NonNull
  SpecialEffectsControllerFactory getSpecialEffectsControllerFactory() {
    SpecialEffectsControllerFactory specialEffectsControllerFactory = this.mSpecialEffectsControllerFactory;
    if (specialEffectsControllerFactory != null)
      return specialEffectsControllerFactory; 
    Fragment fragment = this.mParent;
    return (fragment != null) ? fragment.mFragmentManager.getSpecialEffectsControllerFactory() : this.mDefaultSpecialEffectsControllerFactory;
  }
  
  @Nullable
  public FragmentStrictMode.Policy getStrictModePolicy() {
    return this.mStrictModePolicy;
  }
  
  @NonNull
  ViewModelStore getViewModelStore(@NonNull Fragment paramFragment) {
    return this.mNonConfig.getViewModelStore(paramFragment);
  }
  
  void handleOnBackPressed() {
    execPendingActions(true);
    if (this.mOnBackPressedCallback.isEnabled()) {
      popBackStackImmediate();
      return;
    } 
    this.mOnBackPressedDispatcher.onBackPressed();
  }
  
  void hideFragment(@NonNull Fragment paramFragment) {
    if (isLoggingEnabled(2)) {
      StringBuilder stringBuilder = new StringBuilder();
      stringBuilder.append("hide: ");
      stringBuilder.append(paramFragment);
      Log.v("FragmentManager", stringBuilder.toString());
    } 
    if (!paramFragment.mHidden) {
      paramFragment.mHidden = true;
      paramFragment.mHiddenChanged = true ^ paramFragment.mHiddenChanged;
      setVisibleRemovingFragment(paramFragment);
    } 
  }
  
  void invalidateMenuForFragment(@NonNull Fragment paramFragment) {
    if (paramFragment.mAdded && isMenuAvailable(paramFragment))
      this.mNeedMenuInvalidate = true; 
  }
  
  public boolean isDestroyed() {
    return this.mDestroyed;
  }
  
  boolean isParentHidden(@Nullable Fragment paramFragment) {
    return (paramFragment == null) ? false : paramFragment.isHidden();
  }
  
  boolean isParentMenuVisible(@Nullable Fragment paramFragment) {
    return (paramFragment == null) ? true : paramFragment.isMenuVisible();
  }
  
  boolean isPrimaryNavigation(@Nullable Fragment paramFragment) {
    if (paramFragment == null)
      return true; 
    FragmentManager fragmentManager = paramFragment.mFragmentManager;
    return (paramFragment.equals(fragmentManager.getPrimaryNavigationFragment()) && isPrimaryNavigation(fragmentManager.mParent));
  }
  
  boolean isStateAtLeast(int paramInt) {
    return (this.mCurState >= paramInt);
  }
  
  public boolean isStateSaved() {
    return (this.mStateSaved || this.mStopped);
  }
  
  void launchRequestPermissions(@NonNull Fragment paramFragment, @NonNull String[] paramArrayOfString, int paramInt) {
    LaunchedFragmentInfo launchedFragmentInfo;
    if (this.mRequestPermissions != null) {
      launchedFragmentInfo = new LaunchedFragmentInfo(paramFragment.mWho, paramInt);
      this.mLaunchedFragments.addLast(launchedFragmentInfo);
      this.mRequestPermissions.launch(paramArrayOfString);
      return;
    } 
    this.mHost.onRequestPermissionsFromFragment((Fragment)launchedFragmentInfo, paramArrayOfString, paramInt);
  }
  
  void launchStartActivityForResult(@NonNull Fragment paramFragment, @SuppressLint({"UnknownNullness"}) Intent paramIntent, int paramInt, @Nullable Bundle paramBundle) {
    LaunchedFragmentInfo launchedFragmentInfo;
    if (this.mStartActivityForResult != null) {
      launchedFragmentInfo = new LaunchedFragmentInfo(paramFragment.mWho, paramInt);
      this.mLaunchedFragments.addLast(launchedFragmentInfo);
      if (paramIntent != null && paramBundle != null)
        paramIntent.putExtra("androidx.activity.result.contract.extra.ACTIVITY_OPTIONS_BUNDLE", paramBundle); 
      this.mStartActivityForResult.launch(paramIntent);
      return;
    } 
    this.mHost.onStartActivityFromFragment((Fragment)launchedFragmentInfo, paramIntent, paramInt, paramBundle);
  }
  
  void launchStartIntentSenderForResult(@NonNull Fragment paramFragment, @SuppressLint({"UnknownNullness"}) IntentSender paramIntentSender, int paramInt1, @Nullable Intent paramIntent, int paramInt2, int paramInt3, int paramInt4, @Nullable Bundle paramBundle) throws IntentSender.SendIntentException {
    IntentSenderRequest intentSenderRequest;
    StringBuilder stringBuilder;
    if (this.mStartIntentSenderForResult != null) {
      if (paramBundle != null) {
        if (paramIntent == null) {
          paramIntent = new Intent();
          paramIntent.putExtra("androidx.fragment.extra.ACTIVITY_OPTIONS_BUNDLE", true);
        } 
        if (isLoggingEnabled(2)) {
          StringBuilder stringBuilder1 = new StringBuilder();
          stringBuilder1.append("ActivityOptions ");
          stringBuilder1.append(paramBundle);
          stringBuilder1.append(" were added to fillInIntent ");
          stringBuilder1.append(paramIntent);
          stringBuilder1.append(" for fragment ");
          stringBuilder1.append(paramFragment);
          Log.v("FragmentManager", stringBuilder1.toString());
        } 
        paramIntent.putExtra("androidx.activity.result.contract.extra.ACTIVITY_OPTIONS_BUNDLE", paramBundle);
      } 
      intentSenderRequest = (new IntentSenderRequest.Builder(paramIntentSender)).setFillInIntent(paramIntent).setFlags(paramInt3, paramInt2).build();
      LaunchedFragmentInfo launchedFragmentInfo = new LaunchedFragmentInfo(paramFragment.mWho, paramInt1);
      this.mLaunchedFragments.addLast(launchedFragmentInfo);
      if (isLoggingEnabled(2)) {
        stringBuilder = new StringBuilder();
        stringBuilder.append("Fragment ");
        stringBuilder.append(paramFragment);
        stringBuilder.append("is launching an IntentSender for result ");
        Log.v("FragmentManager", stringBuilder.toString());
      } 
      this.mStartIntentSenderForResult.launch(intentSenderRequest);
      return;
    } 
    this.mHost.onStartIntentSenderFromFragment(paramFragment, (IntentSender)intentSenderRequest, paramInt1, (Intent)stringBuilder, paramInt2, paramInt3, paramInt4, paramBundle);
  }
  
  void moveToState(int paramInt, boolean paramBoolean) {
    if (this.mHost != null || paramInt == -1) {
      if (!paramBoolean && paramInt == this.mCurState)
        return; 
      this.mCurState = paramInt;
      this.mFragmentStore.moveToExpectedState();
      startPendingDeferredFragments();
      if (this.mNeedMenuInvalidate) {
        FragmentHostCallback<?> fragmentHostCallback = this.mHost;
        if (fragmentHostCallback != null && this.mCurState == 7) {
          fragmentHostCallback.onSupportInvalidateOptionsMenu();
          this.mNeedMenuInvalidate = false;
        } 
      } 
      return;
    } 
    throw new IllegalStateException("No activity");
  }
  
  void noteStateNotSaved() {
    if (this.mHost == null)
      return; 
    this.mStateSaved = false;
    this.mStopped = false;
    this.mNonConfig.setIsStateSaved(false);
    for (Fragment fragment : this.mFragmentStore.getFragments()) {
      if (fragment != null)
        fragment.noteStateNotSaved(); 
    } 
  }
  
  void onContainerAvailable(@NonNull FragmentContainerView paramFragmentContainerView) {
    for (FragmentStateManager fragmentStateManager : this.mFragmentStore.getActiveFragmentStateManagers()) {
      Fragment fragment = fragmentStateManager.getFragment();
      if (fragment.mContainerId == paramFragmentContainerView.getId()) {
        View view = fragment.mView;
        if (view != null && view.getParent() == null) {
          fragment.mContainer = (ViewGroup)paramFragmentContainerView;
          fragmentStateManager.addViewToContainer();
        } 
      } 
    } 
  }
  
  @Deprecated
  @NonNull
  @RestrictTo({RestrictTo.Scope.LIBRARY_GROUP_PREFIX})
  public FragmentTransaction openTransaction() {
    return beginTransaction();
  }
  
  void performPendingDeferredStart(@NonNull FragmentStateManager paramFragmentStateManager) {
    Fragment fragment = paramFragmentStateManager.getFragment();
    if (fragment.mDeferStart) {
      if (this.mExecutingActions) {
        this.mHavePendingDeferredStart = true;
        return;
      } 
      fragment.mDeferStart = false;
      paramFragmentStateManager.moveToExpectedState();
    } 
  }
  
  public void popBackStack() {
    enqueueAction(new PopBackStackState(null, -1, 0), false);
  }
  
  public void popBackStack(int paramInt1, int paramInt2) {
    popBackStack(paramInt1, paramInt2, false);
  }
  
  void popBackStack(int paramInt1, int paramInt2, boolean paramBoolean) {
    if (paramInt1 >= 0) {
      enqueueAction(new PopBackStackState(null, paramInt1, paramInt2), paramBoolean);
      return;
    } 
    StringBuilder stringBuilder = new StringBuilder();
    stringBuilder.append("Bad id: ");
    stringBuilder.append(paramInt1);
    throw new IllegalArgumentException(stringBuilder.toString());
  }
  
  public void popBackStack(@Nullable String paramString, int paramInt) {
    enqueueAction(new PopBackStackState(paramString, -1, paramInt), false);
  }
  
  public boolean popBackStackImmediate() {
    return popBackStackImmediate(null, -1, 0);
  }
  
  public boolean popBackStackImmediate(int paramInt1, int paramInt2) {
    if (paramInt1 >= 0)
      return popBackStackImmediate(null, paramInt1, paramInt2); 
    StringBuilder stringBuilder = new StringBuilder();
    stringBuilder.append("Bad id: ");
    stringBuilder.append(paramInt1);
    throw new IllegalArgumentException(stringBuilder.toString());
  }
  
  public boolean popBackStackImmediate(@Nullable String paramString, int paramInt) {
    return popBackStackImmediate(paramString, -1, paramInt);
  }
  
  boolean popBackStackState(@NonNull ArrayList<BackStackRecord> paramArrayList, @NonNull ArrayList<Boolean> paramArrayList1, @Nullable String paramString, int paramInt1, int paramInt2) {
    boolean bool;
    if ((paramInt2 & 0x1) != 0) {
      bool = true;
    } else {
      bool = false;
    } 
    paramInt2 = findBackStackIndex(paramString, paramInt1, bool);
    if (paramInt2 < 0)
      return false; 
    for (paramInt1 = this.mBackStack.size() - 1; paramInt1 >= paramInt2; paramInt1--) {
      paramArrayList.add(this.mBackStack.remove(paramInt1));
      paramArrayList1.add(Boolean.TRUE);
    } 
    return true;
  }
  
  public void putFragment(@NonNull Bundle paramBundle, @NonNull String paramString, @NonNull Fragment paramFragment) {
    if (paramFragment.mFragmentManager != this) {
      StringBuilder stringBuilder = new StringBuilder();
      stringBuilder.append("Fragment ");
      stringBuilder.append(paramFragment);
      stringBuilder.append(" is not currently in the FragmentManager");
      throwException(new IllegalStateException(stringBuilder.toString()));
    } 
    paramBundle.putString(paramString, paramFragment.mWho);
  }
  
  public void registerFragmentLifecycleCallbacks(@NonNull FragmentLifecycleCallbacks paramFragmentLifecycleCallbacks, boolean paramBoolean) {
    this.mLifecycleCallbacksDispatcher.registerFragmentLifecycleCallbacks(paramFragmentLifecycleCallbacks, paramBoolean);
  }
  
  void removeFragment(@NonNull Fragment paramFragment) {
    if (isLoggingEnabled(2)) {
      StringBuilder stringBuilder = new StringBuilder();
      stringBuilder.append("remove: ");
      stringBuilder.append(paramFragment);
      stringBuilder.append(" nesting=");
      stringBuilder.append(paramFragment.mBackStackNesting);
      Log.v("FragmentManager", stringBuilder.toString());
    } 
    boolean bool = paramFragment.isInBackStack();
    if (!paramFragment.mDetached || (bool ^ true) != 0) {
      this.mFragmentStore.removeFragment(paramFragment);
      if (isMenuAvailable(paramFragment))
        this.mNeedMenuInvalidate = true; 
      paramFragment.mRemoving = true;
      setVisibleRemovingFragment(paramFragment);
    } 
  }
  
  public void removeFragmentOnAttachListener(@NonNull FragmentOnAttachListener paramFragmentOnAttachListener) {
    this.mOnAttachListeners.remove(paramFragmentOnAttachListener);
  }
  
  public void removeOnBackStackChangedListener(@NonNull OnBackStackChangedListener paramOnBackStackChangedListener) {
    ArrayList<OnBackStackChangedListener> arrayList = this.mBackStackChangeListeners;
    if (arrayList != null)
      arrayList.remove(paramOnBackStackChangedListener); 
  }
  
  void removeRetainedFragment(@NonNull Fragment paramFragment) {
    this.mNonConfig.removeRetainedFragment(paramFragment);
  }
  
  void restoreAllState(@Nullable Parcelable paramParcelable, @Nullable FragmentManagerNonConfig paramFragmentManagerNonConfig) {
    if (this.mHost instanceof ViewModelStoreOwner)
      throwException(new IllegalStateException("You must use restoreSaveState when your FragmentHostCallback implements ViewModelStoreOwner")); 
    this.mNonConfig.restoreFromSnapshot(paramFragmentManagerNonConfig);
    restoreSaveStateInternal(paramParcelable);
  }
  
  public void restoreBackStack(@NonNull String paramString) {
    enqueueAction(new RestoreBackStackState(paramString), false);
  }
  
  boolean restoreBackStackState(@NonNull ArrayList<BackStackRecord> paramArrayList, @NonNull ArrayList<Boolean> paramArrayList1, @NonNull String paramString) {
    BackStackState backStackState = this.mBackStackStates.remove(paramString);
    if (backStackState == null)
      return false; 
    HashMap<Object, Object> hashMap = new HashMap<Object, Object>();
    for (BackStackRecord backStackRecord : paramArrayList) {
      if (backStackRecord.mBeingSaved) {
        Iterator iterator1 = ((FragmentTransaction)backStackRecord).mOps.iterator();
        while (iterator1.hasNext()) {
          Fragment fragment = ((FragmentTransaction.Op)iterator1.next()).mFragment;
          if (fragment != null)
            hashMap.put(fragment.mWho, fragment); 
        } 
      } 
    } 
    Iterator<BackStackRecord> iterator = backStackState.instantiate(this, hashMap).iterator();
    label25: while (true) {
      boolean bool = false;
      while (iterator.hasNext()) {
        if (((BackStackRecord)iterator.next()).generateOps(paramArrayList, paramArrayList1) || bool) {
          bool = true;
          continue;
        } 
        continue label25;
      } 
      return bool;
    } 
  }
  
  void restoreSaveState(@Nullable Parcelable paramParcelable) {
    if (this.mHost instanceof SavedStateRegistryOwner)
      throwException(new IllegalStateException("You cannot use restoreSaveState when your FragmentHostCallback implements SavedStateRegistryOwner.")); 
    restoreSaveStateInternal(paramParcelable);
  }
  
  void restoreSaveStateInternal(@Nullable Parcelable paramParcelable) {
    if (paramParcelable == null)
      return; 
    Bundle bundle = (Bundle)paramParcelable;
    for (String str1 : bundle.keySet()) {
      if (str1.startsWith("result_")) {
        Bundle bundle1 = bundle.getBundle(str1);
        if (bundle1 != null) {
          bundle1.setClassLoader(this.mHost.getContext().getClassLoader());
          str1 = str1.substring(7);
          this.mResults.put(str1, bundle1);
        } 
      } 
    } 
    ArrayList<FragmentState> arrayList1 = new ArrayList();
    for (String str1 : bundle.keySet()) {
      if (str1.startsWith("fragment_")) {
        Bundle bundle1 = bundle.getBundle(str1);
        if (bundle1 != null) {
          bundle1.setClassLoader(this.mHost.getContext().getClassLoader());
          arrayList1.add((FragmentState)bundle1.getParcelable("state"));
        } 
      } 
    } 
    this.mFragmentStore.restoreSaveState(arrayList1);
    FragmentManagerState fragmentManagerState = (FragmentManagerState)bundle.getParcelable("state");
    if (fragmentManagerState == null)
      return; 
    this.mFragmentStore.resetActiveFragments();
    for (String str1 : fragmentManagerState.mActive) {
      FragmentState fragmentState = this.mFragmentStore.setSavedState(str1, null);
      if (fragmentState != null) {
        FragmentStateManager fragmentStateManager;
        Fragment fragment = this.mNonConfig.findRetainedFragmentByWho(fragmentState.mWho);
        if (fragment != null) {
          if (isLoggingEnabled(2)) {
            StringBuilder stringBuilder = new StringBuilder();
            stringBuilder.append("restoreSaveState: re-attaching retained ");
            stringBuilder.append(fragment);
            Log.v("FragmentManager", stringBuilder.toString());
          } 
          fragmentStateManager = new FragmentStateManager(this.mLifecycleCallbacksDispatcher, this.mFragmentStore, fragment, fragmentState);
        } else {
          fragmentStateManager = new FragmentStateManager(this.mLifecycleCallbacksDispatcher, this.mFragmentStore, this.mHost.getContext().getClassLoader(), getFragmentFactory(), (FragmentState)fragmentStateManager);
        } 
        fragment = fragmentStateManager.getFragment();
        fragment.mFragmentManager = this;
        if (isLoggingEnabled(2)) {
          StringBuilder stringBuilder = new StringBuilder();
          stringBuilder.append("restoreSaveState: active (");
          stringBuilder.append(fragment.mWho);
          stringBuilder.append("): ");
          stringBuilder.append(fragment);
          Log.v("FragmentManager", stringBuilder.toString());
        } 
        fragmentStateManager.restoreState(this.mHost.getContext().getClassLoader());
        this.mFragmentStore.makeActive(fragmentStateManager);
        fragmentStateManager.setFragmentManagerState(this.mCurState);
      } 
    } 
    for (Fragment fragment : this.mNonConfig.getRetainedFragments()) {
      if (!this.mFragmentStore.containsActiveFragment(fragment.mWho)) {
        if (isLoggingEnabled(2)) {
          StringBuilder stringBuilder = new StringBuilder();
          stringBuilder.append("Discarding retained Fragment ");
          stringBuilder.append(fragment);
          stringBuilder.append(" that was not found in the set of active Fragments ");
          stringBuilder.append(fragmentManagerState.mActive);
          Log.v("FragmentManager", stringBuilder.toString());
        } 
        this.mNonConfig.removeRetainedFragment(fragment);
        fragment.mFragmentManager = this;
        FragmentStateManager fragmentStateManager = new FragmentStateManager(this.mLifecycleCallbacksDispatcher, this.mFragmentStore, fragment);
        fragmentStateManager.setFragmentManagerState(1);
        fragmentStateManager.moveToExpectedState();
        fragment.mRemoving = true;
        fragmentStateManager.moveToExpectedState();
      } 
    } 
    this.mFragmentStore.restoreAddedFragments(fragmentManagerState.mAdded);
    BackStackRecordState[] arrayOfBackStackRecordState = fragmentManagerState.mBackStack;
    byte b = 0;
    if (arrayOfBackStackRecordState != null) {
      this.mBackStack = new ArrayList<BackStackRecord>(fragmentManagerState.mBackStack.length);
      int i = 0;
      while (true) {
        arrayOfBackStackRecordState = fragmentManagerState.mBackStack;
        if (i < arrayOfBackStackRecordState.length) {
          BackStackRecord backStackRecord = arrayOfBackStackRecordState[i].instantiate(this);
          if (isLoggingEnabled(2)) {
            StringBuilder stringBuilder = new StringBuilder();
            stringBuilder.append("restoreAllState: back stack #");
            stringBuilder.append(i);
            stringBuilder.append(" (index ");
            stringBuilder.append(backStackRecord.mIndex);
            stringBuilder.append("): ");
            stringBuilder.append(backStackRecord);
            Log.v("FragmentManager", stringBuilder.toString());
            PrintWriter printWriter = new PrintWriter((Writer)new LogWriter("FragmentManager"));
            backStackRecord.dump("  ", printWriter, false);
            printWriter.close();
          } 
          this.mBackStack.add(backStackRecord);
          i++;
          continue;
        } 
        break;
      } 
    } else {
      this.mBackStack = null;
    } 
    this.mBackStackIndex.set(fragmentManagerState.mBackStackIndex);
    String str = fragmentManagerState.mPrimaryNavActiveWho;
    if (str != null) {
      Fragment fragment = findActiveFragment(str);
      this.mPrimaryNav = fragment;
      dispatchParentPrimaryNavigationFragmentChanged(fragment);
    } 
    ArrayList<String> arrayList = fragmentManagerState.mBackStackStateKeys;
    if (arrayList != null)
      for (int i = b; i < arrayList.size(); i++)
        this.mBackStackStates.put(arrayList.get(i), fragmentManagerState.mBackStackStates.get(i));  
    this.mLaunchedFragments = new ArrayDeque<LaunchedFragmentInfo>(fragmentManagerState.mLaunchedFragments);
  }
  
  @Deprecated
  FragmentManagerNonConfig retainNonConfig() {
    if (this.mHost instanceof ViewModelStoreOwner)
      throwException(new IllegalStateException("You cannot use retainNonConfig when your FragmentHostCallback implements ViewModelStoreOwner.")); 
    return this.mNonConfig.getSnapshot();
  }
  
  Parcelable saveAllState() {
    if (this.mHost instanceof SavedStateRegistryOwner)
      throwException(new IllegalStateException("You cannot use saveAllState when your FragmentHostCallback implements SavedStateRegistryOwner.")); 
    Bundle bundle2 = saveAllStateInternal();
    Bundle bundle1 = bundle2;
    if (bundle2.isEmpty())
      bundle1 = null; 
    return (Parcelable)bundle1;
  }
  
  @NonNull
  Bundle saveAllStateInternal() {
    // Byte code:
    //   0: new android/os/Bundle
    //   3: dup
    //   4: invokespecial <init> : ()V
    //   7: astore #5
    //   9: aload_0
    //   10: invokespecial forcePostponedTransactions : ()V
    //   13: aload_0
    //   14: invokespecial endAnimatingAwayFragments : ()V
    //   17: aload_0
    //   18: iconst_1
    //   19: invokevirtual execPendingActions : (Z)Z
    //   22: pop
    //   23: aload_0
    //   24: iconst_1
    //   25: putfield mStateSaved : Z
    //   28: aload_0
    //   29: getfield mNonConfig : Landroidx/fragment/app/FragmentManagerViewModel;
    //   32: iconst_1
    //   33: invokevirtual setIsStateSaved : (Z)V
    //   36: aload_0
    //   37: getfield mFragmentStore : Landroidx/fragment/app/FragmentStore;
    //   40: invokevirtual saveActiveFragments : ()Ljava/util/ArrayList;
    //   43: astore #7
    //   45: aload_0
    //   46: getfield mFragmentStore : Landroidx/fragment/app/FragmentStore;
    //   49: invokevirtual getAllSavedState : ()Ljava/util/ArrayList;
    //   52: astore #6
    //   54: aload #6
    //   56: invokevirtual isEmpty : ()Z
    //   59: ifeq -> 81
    //   62: iconst_2
    //   63: invokestatic isLoggingEnabled : (I)Z
    //   66: ifeq -> 509
    //   69: ldc 'FragmentManager'
    //   71: ldc_w 'saveAllState: no fragments!'
    //   74: invokestatic v : (Ljava/lang/String;Ljava/lang/String;)I
    //   77: pop
    //   78: aload #5
    //   80: areturn
    //   81: aload_0
    //   82: getfield mFragmentStore : Landroidx/fragment/app/FragmentStore;
    //   85: invokevirtual saveAddedFragments : ()Ljava/util/ArrayList;
    //   88: astore #8
    //   90: aload_0
    //   91: getfield mBackStack : Ljava/util/ArrayList;
    //   94: astore_3
    //   95: aload_3
    //   96: ifnull -> 213
    //   99: aload_3
    //   100: invokevirtual size : ()I
    //   103: istore_2
    //   104: iload_2
    //   105: ifle -> 213
    //   108: iload_2
    //   109: anewarray androidx/fragment/app/BackStackRecordState
    //   112: astore #4
    //   114: iconst_0
    //   115: istore_1
    //   116: aload #4
    //   118: astore_3
    //   119: iload_1
    //   120: iload_2
    //   121: if_icmpge -> 215
    //   124: aload #4
    //   126: iload_1
    //   127: new androidx/fragment/app/BackStackRecordState
    //   130: dup
    //   131: aload_0
    //   132: getfield mBackStack : Ljava/util/ArrayList;
    //   135: iload_1
    //   136: invokevirtual get : (I)Ljava/lang/Object;
    //   139: checkcast androidx/fragment/app/BackStackRecord
    //   142: invokespecial <init> : (Landroidx/fragment/app/BackStackRecord;)V
    //   145: aastore
    //   146: iconst_2
    //   147: invokestatic isLoggingEnabled : (I)Z
    //   150: ifeq -> 206
    //   153: new java/lang/StringBuilder
    //   156: dup
    //   157: invokespecial <init> : ()V
    //   160: astore_3
    //   161: aload_3
    //   162: ldc_w 'saveAllState: adding back stack #'
    //   165: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   168: pop
    //   169: aload_3
    //   170: iload_1
    //   171: invokevirtual append : (I)Ljava/lang/StringBuilder;
    //   174: pop
    //   175: aload_3
    //   176: ldc_w ': '
    //   179: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   182: pop
    //   183: aload_3
    //   184: aload_0
    //   185: getfield mBackStack : Ljava/util/ArrayList;
    //   188: iload_1
    //   189: invokevirtual get : (I)Ljava/lang/Object;
    //   192: invokevirtual append : (Ljava/lang/Object;)Ljava/lang/StringBuilder;
    //   195: pop
    //   196: ldc 'FragmentManager'
    //   198: aload_3
    //   199: invokevirtual toString : ()Ljava/lang/String;
    //   202: invokestatic v : (Ljava/lang/String;Ljava/lang/String;)I
    //   205: pop
    //   206: iload_1
    //   207: iconst_1
    //   208: iadd
    //   209: istore_1
    //   210: goto -> 116
    //   213: aconst_null
    //   214: astore_3
    //   215: new androidx/fragment/app/FragmentManagerState
    //   218: dup
    //   219: invokespecial <init> : ()V
    //   222: astore #4
    //   224: aload #4
    //   226: aload #7
    //   228: putfield mActive : Ljava/util/ArrayList;
    //   231: aload #4
    //   233: aload #8
    //   235: putfield mAdded : Ljava/util/ArrayList;
    //   238: aload #4
    //   240: aload_3
    //   241: putfield mBackStack : [Landroidx/fragment/app/BackStackRecordState;
    //   244: aload #4
    //   246: aload_0
    //   247: getfield mBackStackIndex : Ljava/util/concurrent/atomic/AtomicInteger;
    //   250: invokevirtual get : ()I
    //   253: putfield mBackStackIndex : I
    //   256: aload_0
    //   257: getfield mPrimaryNav : Landroidx/fragment/app/Fragment;
    //   260: astore_3
    //   261: aload_3
    //   262: ifnull -> 274
    //   265: aload #4
    //   267: aload_3
    //   268: getfield mWho : Ljava/lang/String;
    //   271: putfield mPrimaryNavActiveWho : Ljava/lang/String;
    //   274: aload #4
    //   276: getfield mBackStackStateKeys : Ljava/util/ArrayList;
    //   279: aload_0
    //   280: getfield mBackStackStates : Ljava/util/Map;
    //   283: invokeinterface keySet : ()Ljava/util/Set;
    //   288: invokevirtual addAll : (Ljava/util/Collection;)Z
    //   291: pop
    //   292: aload #4
    //   294: getfield mBackStackStates : Ljava/util/ArrayList;
    //   297: aload_0
    //   298: getfield mBackStackStates : Ljava/util/Map;
    //   301: invokeinterface values : ()Ljava/util/Collection;
    //   306: invokevirtual addAll : (Ljava/util/Collection;)Z
    //   309: pop
    //   310: aload #4
    //   312: new java/util/ArrayList
    //   315: dup
    //   316: aload_0
    //   317: getfield mLaunchedFragments : Ljava/util/ArrayDeque;
    //   320: invokespecial <init> : (Ljava/util/Collection;)V
    //   323: putfield mLaunchedFragments : Ljava/util/ArrayList;
    //   326: aload #5
    //   328: ldc 'state'
    //   330: aload #4
    //   332: invokevirtual putParcelable : (Ljava/lang/String;Landroid/os/Parcelable;)V
    //   335: aload_0
    //   336: getfield mResults : Ljava/util/Map;
    //   339: invokeinterface keySet : ()Ljava/util/Set;
    //   344: invokeinterface iterator : ()Ljava/util/Iterator;
    //   349: astore_3
    //   350: aload_3
    //   351: invokeinterface hasNext : ()Z
    //   356: ifeq -> 422
    //   359: aload_3
    //   360: invokeinterface next : ()Ljava/lang/Object;
    //   365: checkcast java/lang/String
    //   368: astore #4
    //   370: new java/lang/StringBuilder
    //   373: dup
    //   374: invokespecial <init> : ()V
    //   377: astore #7
    //   379: aload #7
    //   381: ldc 'result_'
    //   383: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   386: pop
    //   387: aload #7
    //   389: aload #4
    //   391: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   394: pop
    //   395: aload #5
    //   397: aload #7
    //   399: invokevirtual toString : ()Ljava/lang/String;
    //   402: aload_0
    //   403: getfield mResults : Ljava/util/Map;
    //   406: aload #4
    //   408: invokeinterface get : (Ljava/lang/Object;)Ljava/lang/Object;
    //   413: checkcast android/os/Bundle
    //   416: invokevirtual putBundle : (Ljava/lang/String;Landroid/os/Bundle;)V
    //   419: goto -> 350
    //   422: aload #6
    //   424: invokevirtual iterator : ()Ljava/util/Iterator;
    //   427: astore_3
    //   428: aload_3
    //   429: invokeinterface hasNext : ()Z
    //   434: ifeq -> 509
    //   437: aload_3
    //   438: invokeinterface next : ()Ljava/lang/Object;
    //   443: checkcast androidx/fragment/app/FragmentState
    //   446: astore #4
    //   448: new android/os/Bundle
    //   451: dup
    //   452: invokespecial <init> : ()V
    //   455: astore #6
    //   457: aload #6
    //   459: ldc 'state'
    //   461: aload #4
    //   463: invokevirtual putParcelable : (Ljava/lang/String;Landroid/os/Parcelable;)V
    //   466: new java/lang/StringBuilder
    //   469: dup
    //   470: invokespecial <init> : ()V
    //   473: astore #7
    //   475: aload #7
    //   477: ldc 'fragment_'
    //   479: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   482: pop
    //   483: aload #7
    //   485: aload #4
    //   487: getfield mWho : Ljava/lang/String;
    //   490: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   493: pop
    //   494: aload #5
    //   496: aload #7
    //   498: invokevirtual toString : ()Ljava/lang/String;
    //   501: aload #6
    //   503: invokevirtual putBundle : (Ljava/lang/String;Landroid/os/Bundle;)V
    //   506: goto -> 428
    //   509: aload #5
    //   511: areturn
  }
  
  public void saveBackStack(@NonNull String paramString) {
    enqueueAction(new SaveBackStackState(paramString), false);
  }
  
  boolean saveBackStackState(@NonNull ArrayList<BackStackRecord> paramArrayList, @NonNull ArrayList<Boolean> paramArrayList1, @NonNull String paramString) {
    int i = findBackStackIndex(paramString, -1, true);
    if (i < 0)
      return false; 
    int j;
    for (j = i; j < this.mBackStack.size(); j++) {
      BackStackRecord backStackRecord = this.mBackStack.get(j);
      if (!((FragmentTransaction)backStackRecord).mReorderingAllowed) {
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("saveBackStack(\"");
        stringBuilder.append(paramString);
        stringBuilder.append("\") included FragmentTransactions must use setReorderingAllowed(true) to ensure that the back stack can be restored as an atomic operation. Found ");
        stringBuilder.append(backStackRecord);
        stringBuilder.append(" that did not use setReorderingAllowed(true).");
        throwException(new IllegalArgumentException(stringBuilder.toString()));
      } 
    } 
    HashSet<?> hashSet = new HashSet();
    for (j = i; j < this.mBackStack.size(); j++) {
      BackStackRecord backStackRecord = this.mBackStack.get(j);
      HashSet hashSet1 = new HashSet();
      HashSet<Object> hashSet2 = new HashSet();
      Iterator iterator1 = ((FragmentTransaction)backStackRecord).mOps.iterator();
      while (true) {
        while (true)
          break; 
        if (SYNTHETIC_LOCAL_VARIABLE_6 == true || SYNTHETIC_LOCAL_VARIABLE_6 == 2)
          hashSet2.add(SYNTHETIC_LOCAL_VARIABLE_13); 
      } 
      hashSet1.removeAll(hashSet2);
      if (!hashSet1.isEmpty()) {
        String str;
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("saveBackStack(\"");
        stringBuilder.append(paramString);
        stringBuilder.append("\") must be self contained and not reference fragments from non-saved FragmentTransactions. Found reference to fragment");
        if (hashSet1.size() == 1) {
          StringBuilder stringBuilder1 = new StringBuilder();
          stringBuilder1.append(" ");
          stringBuilder1.append(hashSet1.iterator().next());
          str = stringBuilder1.toString();
        } else {
          StringBuilder stringBuilder1 = new StringBuilder();
          stringBuilder1.append("s ");
          stringBuilder1.append(str);
          str = stringBuilder1.toString();
        } 
        stringBuilder.append(str);
        stringBuilder.append(" in ");
        stringBuilder.append(backStackRecord);
        stringBuilder.append(" that were previously added to the FragmentManager through a separate FragmentTransaction.");
        throwException(new IllegalArgumentException(stringBuilder.toString()));
      } 
    } 
    ArrayDeque<Fragment> arrayDeque = new ArrayDeque(hashSet);
    while (!arrayDeque.isEmpty()) {
      fragment = arrayDeque.removeFirst();
      if (fragment.mRetainInstance) {
        String str;
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("saveBackStack(\"");
        stringBuilder.append(paramString);
        stringBuilder.append("\") must not contain retained fragments. Found ");
        if (hashSet.contains(fragment)) {
          str = "direct reference to retained ";
        } else {
          str = "retained child ";
        } 
        stringBuilder.append(str);
        stringBuilder.append("fragment ");
        stringBuilder.append(fragment);
        throwException(new IllegalArgumentException(stringBuilder.toString()));
      } 
      for (Fragment fragment : fragment.mChildFragmentManager.getActiveFragments()) {
        if (fragment != null)
          arrayDeque.addLast(fragment); 
      } 
    } 
    ArrayList<String> arrayList1 = new ArrayList();
    Iterator<?> iterator = hashSet.iterator();
    while (iterator.hasNext())
      arrayList1.add(((Fragment)iterator.next()).mWho); 
    ArrayList<BackStackRecordState> arrayList = new ArrayList(this.mBackStack.size() - i);
    for (j = i; j < this.mBackStack.size(); j++)
      arrayList.add(null); 
    BackStackState backStackState = new BackStackState(arrayList1, arrayList);
    for (j = this.mBackStack.size() - 1; j >= i; j--) {
      BackStackRecord backStackRecord1 = this.mBackStack.remove(j);
      BackStackRecord backStackRecord2 = new BackStackRecord(backStackRecord1);
      backStackRecord2.collapseOps();
      arrayList.set(j - i, new BackStackRecordState(backStackRecord2));
      backStackRecord1.mBeingSaved = true;
      paramArrayList.add(backStackRecord1);
      paramArrayList1.add(Boolean.TRUE);
    } 
    this.mBackStackStates.put(paramString, backStackState);
    return true;
  }
  
  @Nullable
  public Fragment.SavedState saveFragmentInstanceState(@NonNull Fragment paramFragment) {
    FragmentStateManager fragmentStateManager = this.mFragmentStore.getFragmentStateManager(paramFragment.mWho);
    if (fragmentStateManager == null || !fragmentStateManager.getFragment().equals(paramFragment)) {
      StringBuilder stringBuilder = new StringBuilder();
      stringBuilder.append("Fragment ");
      stringBuilder.append(paramFragment);
      stringBuilder.append(" is not currently in the FragmentManager");
      throwException(new IllegalStateException(stringBuilder.toString()));
    } 
    return fragmentStateManager.saveInstanceState();
  }
  
  void scheduleCommit() {
    synchronized (this.mPendingActions) {
      int i = this.mPendingActions.size();
      boolean bool = true;
      if (i != 1)
        bool = false; 
      if (bool) {
        this.mHost.getHandler().removeCallbacks(this.mExecCommit);
        this.mHost.getHandler().post(this.mExecCommit);
        updateOnBackPressedCallbackEnabled();
      } 
      return;
    } 
  }
  
  void setExitAnimationOrder(@NonNull Fragment paramFragment, boolean paramBoolean) {
    ViewGroup viewGroup = getFragmentContainer(paramFragment);
    if (viewGroup != null && viewGroup instanceof FragmentContainerView)
      ((FragmentContainerView)viewGroup).setDrawDisappearingViewsLast(paramBoolean ^ true); 
  }
  
  public void setFragmentFactory(@NonNull FragmentFactory paramFragmentFactory) {
    this.mFragmentFactory = paramFragmentFactory;
  }
  
  public final void setFragmentResult(@NonNull String paramString, @NonNull Bundle paramBundle) {
    LifecycleAwareResultListener lifecycleAwareResultListener = this.mResultListeners.get(paramString);
    if (lifecycleAwareResultListener != null && lifecycleAwareResultListener.isAtLeast(Lifecycle.State.STARTED)) {
      lifecycleAwareResultListener.onFragmentResult(paramString, paramBundle);
    } else {
      this.mResults.put(paramString, paramBundle);
    } 
    if (isLoggingEnabled(2)) {
      StringBuilder stringBuilder = new StringBuilder();
      stringBuilder.append("Setting fragment result with key ");
      stringBuilder.append(paramString);
      stringBuilder.append(" and result ");
      stringBuilder.append(paramBundle);
      Log.v("FragmentManager", stringBuilder.toString());
    } 
  }
  
  @SuppressLint({"SyntheticAccessor"})
  public final void setFragmentResultListener(@NonNull final String requestKey, @NonNull LifecycleOwner paramLifecycleOwner, @NonNull final FragmentResultListener listener) {
    final Lifecycle lifecycle = paramLifecycleOwner.getLifecycle();
    if (lifecycle.getCurrentState() == Lifecycle.State.DESTROYED)
      return; 
    LifecycleEventObserver lifecycleEventObserver = new LifecycleEventObserver() {
        public void onStateChanged(@NonNull LifecycleOwner param1LifecycleOwner, @NonNull Lifecycle.Event param1Event) {
          if (param1Event == Lifecycle.Event.ON_START) {
            Bundle bundle = (Bundle)FragmentManager.this.mResults.get(requestKey);
            if (bundle != null) {
              listener.onFragmentResult(requestKey, bundle);
              FragmentManager.this.clearFragmentResult(requestKey);
            } 
          } 
          if (param1Event == Lifecycle.Event.ON_DESTROY) {
            lifecycle.removeObserver((LifecycleObserver)this);
            FragmentManager.this.mResultListeners.remove(requestKey);
          } 
        }
      };
    LifecycleAwareResultListener lifecycleAwareResultListener = this.mResultListeners.put(requestKey, new LifecycleAwareResultListener(lifecycle, listener, lifecycleEventObserver));
    if (lifecycleAwareResultListener != null)
      lifecycleAwareResultListener.removeObserver(); 
    if (isLoggingEnabled(2)) {
      StringBuilder stringBuilder = new StringBuilder();
      stringBuilder.append("Setting FragmentResultListener with key ");
      stringBuilder.append(requestKey);
      stringBuilder.append(" lifecycleOwner ");
      stringBuilder.append(lifecycle);
      stringBuilder.append(" and listener ");
      stringBuilder.append(listener);
      Log.v("FragmentManager", stringBuilder.toString());
    } 
    lifecycle.addObserver((LifecycleObserver)lifecycleEventObserver);
  }
  
  void setMaxLifecycle(@NonNull Fragment paramFragment, @NonNull Lifecycle.State paramState) {
    if (paramFragment.equals(findActiveFragment(paramFragment.mWho)) && (paramFragment.mHost == null || paramFragment.mFragmentManager == this)) {
      paramFragment.mMaxState = paramState;
      return;
    } 
    StringBuilder stringBuilder = new StringBuilder();
    stringBuilder.append("Fragment ");
    stringBuilder.append(paramFragment);
    stringBuilder.append(" is not an active fragment of FragmentManager ");
    stringBuilder.append(this);
    throw new IllegalArgumentException(stringBuilder.toString());
  }
  
  void setPrimaryNavigationFragment(@Nullable Fragment paramFragment) {
    if (paramFragment == null || (paramFragment.equals(findActiveFragment(paramFragment.mWho)) && (paramFragment.mHost == null || paramFragment.mFragmentManager == this))) {
      Fragment fragment = this.mPrimaryNav;
      this.mPrimaryNav = paramFragment;
      dispatchParentPrimaryNavigationFragmentChanged(fragment);
      dispatchParentPrimaryNavigationFragmentChanged(this.mPrimaryNav);
      return;
    } 
    StringBuilder stringBuilder = new StringBuilder();
    stringBuilder.append("Fragment ");
    stringBuilder.append(paramFragment);
    stringBuilder.append(" is not an active fragment of FragmentManager ");
    stringBuilder.append(this);
    throw new IllegalArgumentException(stringBuilder.toString());
  }
  
  void setSpecialEffectsControllerFactory(@NonNull SpecialEffectsControllerFactory paramSpecialEffectsControllerFactory) {
    this.mSpecialEffectsControllerFactory = paramSpecialEffectsControllerFactory;
  }
  
  public void setStrictModePolicy(@Nullable FragmentStrictMode.Policy paramPolicy) {
    this.mStrictModePolicy = paramPolicy;
  }
  
  void showFragment(@NonNull Fragment paramFragment) {
    if (isLoggingEnabled(2)) {
      StringBuilder stringBuilder = new StringBuilder();
      stringBuilder.append("show: ");
      stringBuilder.append(paramFragment);
      Log.v("FragmentManager", stringBuilder.toString());
    } 
    if (paramFragment.mHidden) {
      paramFragment.mHidden = false;
      paramFragment.mHiddenChanged ^= 0x1;
    } 
  }
  
  @NonNull
  public String toString() {
    StringBuilder stringBuilder = new StringBuilder(128);
    stringBuilder.append("FragmentManager{");
    stringBuilder.append(Integer.toHexString(System.identityHashCode(this)));
    stringBuilder.append(" in ");
    Fragment fragment = this.mParent;
    if (fragment != null) {
      stringBuilder.append(fragment.getClass().getSimpleName());
      stringBuilder.append("{");
      stringBuilder.append(Integer.toHexString(System.identityHashCode(this.mParent)));
      stringBuilder.append("}");
    } else {
      FragmentHostCallback<?> fragmentHostCallback = this.mHost;
      if (fragmentHostCallback != null) {
        stringBuilder.append(fragmentHostCallback.getClass().getSimpleName());
        stringBuilder.append("{");
        stringBuilder.append(Integer.toHexString(System.identityHashCode(this.mHost)));
        stringBuilder.append("}");
      } else {
        stringBuilder.append("null");
      } 
    } 
    stringBuilder.append("}}");
    return stringBuilder.toString();
  }
  
  public void unregisterFragmentLifecycleCallbacks(@NonNull FragmentLifecycleCallbacks paramFragmentLifecycleCallbacks) {
    this.mLifecycleCallbacksDispatcher.unregisterFragmentLifecycleCallbacks(paramFragmentLifecycleCallbacks);
  }
  
  public static interface BackStackEntry {
    @Deprecated
    @Nullable
    CharSequence getBreadCrumbShortTitle();
    
    @Deprecated
    @StringRes
    int getBreadCrumbShortTitleRes();
    
    @Deprecated
    @Nullable
    CharSequence getBreadCrumbTitle();
    
    @Deprecated
    @StringRes
    int getBreadCrumbTitleRes();
    
    int getId();
    
    @Nullable
    String getName();
  }
  
  private class ClearBackStackState implements OpGenerator {
    private final String mName;
    
    ClearBackStackState(String param1String) {
      this.mName = param1String;
    }
    
    public boolean generateOps(@NonNull ArrayList<BackStackRecord> param1ArrayList, @NonNull ArrayList<Boolean> param1ArrayList1) {
      return FragmentManager.this.clearBackStackState(param1ArrayList, param1ArrayList1, this.mName);
    }
  }
  
  static class FragmentIntentSenderContract extends ActivityResultContract<IntentSenderRequest, ActivityResult> {
    @NonNull
    public Intent createIntent(@NonNull Context param1Context, IntentSenderRequest param1IntentSenderRequest) {
      Intent intent1 = new Intent("androidx.activity.result.contract.action.INTENT_SENDER_REQUEST");
      Intent intent2 = param1IntentSenderRequest.getFillInIntent();
      IntentSenderRequest intentSenderRequest = param1IntentSenderRequest;
      if (intent2 != null) {
        Bundle bundle = intent2.getBundleExtra("androidx.activity.result.contract.extra.ACTIVITY_OPTIONS_BUNDLE");
        intentSenderRequest = param1IntentSenderRequest;
        if (bundle != null) {
          intent1.putExtra("androidx.activity.result.contract.extra.ACTIVITY_OPTIONS_BUNDLE", bundle);
          intent2.removeExtra("androidx.activity.result.contract.extra.ACTIVITY_OPTIONS_BUNDLE");
          intentSenderRequest = param1IntentSenderRequest;
          if (intent2.getBooleanExtra("androidx.fragment.extra.ACTIVITY_OPTIONS_BUNDLE", false))
            intentSenderRequest = (new IntentSenderRequest.Builder(param1IntentSenderRequest.getIntentSender())).setFillInIntent(null).setFlags(param1IntentSenderRequest.getFlagsValues(), param1IntentSenderRequest.getFlagsMask()).build(); 
        } 
      } 
      intent1.putExtra("androidx.activity.result.contract.extra.INTENT_SENDER_REQUEST", (Parcelable)intentSenderRequest);
      if (FragmentManager.isLoggingEnabled(2)) {
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("CreateIntent created the following intent: ");
        stringBuilder.append(intent1);
        Log.v("FragmentManager", stringBuilder.toString());
      } 
      return intent1;
    }
    
    @NonNull
    public ActivityResult parseResult(int param1Int, @Nullable Intent param1Intent) {
      return new ActivityResult(param1Int, param1Intent);
    }
  }
  
  public static abstract class FragmentLifecycleCallbacks {
    @Deprecated
    public void onFragmentActivityCreated(@NonNull FragmentManager param1FragmentManager, @NonNull Fragment param1Fragment, @Nullable Bundle param1Bundle) {}
    
    public void onFragmentAttached(@NonNull FragmentManager param1FragmentManager, @NonNull Fragment param1Fragment, @NonNull Context param1Context) {}
    
    public void onFragmentCreated(@NonNull FragmentManager param1FragmentManager, @NonNull Fragment param1Fragment, @Nullable Bundle param1Bundle) {}
    
    public void onFragmentDestroyed(@NonNull FragmentManager param1FragmentManager, @NonNull Fragment param1Fragment) {}
    
    public void onFragmentDetached(@NonNull FragmentManager param1FragmentManager, @NonNull Fragment param1Fragment) {}
    
    public void onFragmentPaused(@NonNull FragmentManager param1FragmentManager, @NonNull Fragment param1Fragment) {}
    
    public void onFragmentPreAttached(@NonNull FragmentManager param1FragmentManager, @NonNull Fragment param1Fragment, @NonNull Context param1Context) {}
    
    public void onFragmentPreCreated(@NonNull FragmentManager param1FragmentManager, @NonNull Fragment param1Fragment, @Nullable Bundle param1Bundle) {}
    
    public void onFragmentResumed(@NonNull FragmentManager param1FragmentManager, @NonNull Fragment param1Fragment) {}
    
    public void onFragmentSaveInstanceState(@NonNull FragmentManager param1FragmentManager, @NonNull Fragment param1Fragment, @NonNull Bundle param1Bundle) {}
    
    public void onFragmentStarted(@NonNull FragmentManager param1FragmentManager, @NonNull Fragment param1Fragment) {}
    
    public void onFragmentStopped(@NonNull FragmentManager param1FragmentManager, @NonNull Fragment param1Fragment) {}
    
    public void onFragmentViewCreated(@NonNull FragmentManager param1FragmentManager, @NonNull Fragment param1Fragment, @NonNull View param1View, @Nullable Bundle param1Bundle) {}
    
    public void onFragmentViewDestroyed(@NonNull FragmentManager param1FragmentManager, @NonNull Fragment param1Fragment) {}
  }
  
  @SuppressLint({"BanParcelableUsage"})
  static class LaunchedFragmentInfo implements Parcelable {
    public static final Parcelable.Creator<LaunchedFragmentInfo> CREATOR = new Parcelable.Creator<LaunchedFragmentInfo>() {
        public FragmentManager.LaunchedFragmentInfo createFromParcel(Parcel param2Parcel) {
          return new FragmentManager.LaunchedFragmentInfo(param2Parcel);
        }
        
        public FragmentManager.LaunchedFragmentInfo[] newArray(int param2Int) {
          return new FragmentManager.LaunchedFragmentInfo[param2Int];
        }
      };
    
    int mRequestCode;
    
    String mWho;
    
    LaunchedFragmentInfo(@NonNull Parcel param1Parcel) {
      this.mWho = param1Parcel.readString();
      this.mRequestCode = param1Parcel.readInt();
    }
    
    LaunchedFragmentInfo(@NonNull String param1String, int param1Int) {
      this.mWho = param1String;
      this.mRequestCode = param1Int;
    }
    
    public int describeContents() {
      return 0;
    }
    
    public void writeToParcel(Parcel param1Parcel, int param1Int) {
      param1Parcel.writeString(this.mWho);
      param1Parcel.writeInt(this.mRequestCode);
    }
  }
  
  class null implements Parcelable.Creator<LaunchedFragmentInfo> {
    public FragmentManager.LaunchedFragmentInfo createFromParcel(Parcel param1Parcel) {
      return new FragmentManager.LaunchedFragmentInfo(param1Parcel);
    }
    
    public FragmentManager.LaunchedFragmentInfo[] newArray(int param1Int) {
      return new FragmentManager.LaunchedFragmentInfo[param1Int];
    }
  }
  
  private static class LifecycleAwareResultListener implements FragmentResultListener {
    private final Lifecycle mLifecycle;
    
    private final FragmentResultListener mListener;
    
    private final LifecycleEventObserver mObserver;
    
    LifecycleAwareResultListener(@NonNull Lifecycle param1Lifecycle, @NonNull FragmentResultListener param1FragmentResultListener, @NonNull LifecycleEventObserver param1LifecycleEventObserver) {
      this.mLifecycle = param1Lifecycle;
      this.mListener = param1FragmentResultListener;
      this.mObserver = param1LifecycleEventObserver;
    }
    
    public boolean isAtLeast(Lifecycle.State param1State) {
      return this.mLifecycle.getCurrentState().isAtLeast(param1State);
    }
    
    public void onFragmentResult(@NonNull String param1String, @NonNull Bundle param1Bundle) {
      this.mListener.onFragmentResult(param1String, param1Bundle);
    }
    
    public void removeObserver() {
      this.mLifecycle.removeObserver((LifecycleObserver)this.mObserver);
    }
  }
  
  public static interface OnBackStackChangedListener {
    @MainThread
    void onBackStackChanged();
  }
  
  static interface OpGenerator {
    boolean generateOps(@NonNull ArrayList<BackStackRecord> param1ArrayList, @NonNull ArrayList<Boolean> param1ArrayList1);
  }
  
  private class PopBackStackState implements OpGenerator {
    final int mFlags;
    
    final int mId;
    
    final String mName;
    
    PopBackStackState(String param1String, int param1Int1, int param1Int2) {
      this.mName = param1String;
      this.mId = param1Int1;
      this.mFlags = param1Int2;
    }
    
    public boolean generateOps(@NonNull ArrayList<BackStackRecord> param1ArrayList, @NonNull ArrayList<Boolean> param1ArrayList1) {
      Fragment fragment = FragmentManager.this.mPrimaryNav;
      return (fragment != null && this.mId < 0 && this.mName == null && fragment.getChildFragmentManager().popBackStackImmediate()) ? false : FragmentManager.this.popBackStackState(param1ArrayList, param1ArrayList1, this.mName, this.mId, this.mFlags);
    }
  }
  
  private class RestoreBackStackState implements OpGenerator {
    private final String mName;
    
    RestoreBackStackState(String param1String) {
      this.mName = param1String;
    }
    
    public boolean generateOps(@NonNull ArrayList<BackStackRecord> param1ArrayList, @NonNull ArrayList<Boolean> param1ArrayList1) {
      return FragmentManager.this.restoreBackStackState(param1ArrayList, param1ArrayList1, this.mName);
    }
  }
  
  private class SaveBackStackState implements OpGenerator {
    private final String mName;
    
    SaveBackStackState(String param1String) {
      this.mName = param1String;
    }
    
    public boolean generateOps(@NonNull ArrayList<BackStackRecord> param1ArrayList, @NonNull ArrayList<Boolean> param1ArrayList1) {
      return FragmentManager.this.saveBackStackState(param1ArrayList, param1ArrayList1, this.mName);
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\MagicAI - AI Art & Anime Art-dex2jar.jar!\androidx\fragment\app\FragmentManager.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */