package androidx.fragment.app.strictmode;

import androidx.fragment.app.Fragment;
import kotlin.Metadata;

@Metadata(d1 = {"\000\022\n\002\030\002\n\002\030\002\n\000\n\002\030\002\n\002\b\002\030\0002\0020\001B\017\b\000\022\006\020\002\032\0020\003¢\006\002\020\004¨\006\005"}, d2 = {"Landroidx/fragment/app/strictmode/SetRetainInstanceUsageViolation;", "Landroidx/fragment/app/strictmode/RetainInstanceUsageViolation;", "fragment", "Landroidx/fragment/app/Fragment;", "(Landroidx/fragment/app/Fragment;)V", "fragment_release"}, k = 1, mv = {1, 6, 0}, xi = 48)
public final class SetRetainInstanceUsageViolation extends RetainInstanceUsageViolation {
  public SetRetainInstanceUsageViolation(Fragment paramFragment) {
    super(paramFragment, stringBuilder.toString());
  }
}


/* Location:              C:\soft\dex2jar-2.0\MagicAI - AI Art & Anime Art-dex2jar.jar!\androidx\fragment\app\strictmode\SetRetainInstanceUsageViolation.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */