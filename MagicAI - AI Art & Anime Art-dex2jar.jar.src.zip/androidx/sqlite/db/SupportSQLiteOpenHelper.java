package androidx.sqlite.db;

import android.content.Context;
import android.database.sqlite.SQLiteException;
import android.util.Log;
import android.util.Pair;
import androidx.annotation.RequiresApi;
import java.io.Closeable;
import java.io.File;
import java.io.IOException;
import java.util.Iterator;
import java.util.List;
import kotlin.Metadata;
import kotlin.jvm.internal.DefaultConstructorMarker;
import kotlin.jvm.internal.Intrinsics;
import kotlin.text.StringsKt;

@Metadata(d1 = {"\000*\n\002\030\002\n\002\030\002\n\000\n\002\020\016\n\002\b\003\n\002\030\002\n\002\b\005\n\002\020\002\n\002\b\002\n\002\020\013\n\002\b\004\bf\030\0002\0020\001:\003\021\022\023J\b\020\f\032\0020\rH&J\020\020\016\032\0020\r2\006\020\017\032\0020\020H'R\024\020\002\032\004\030\0010\003X¦\004¢\006\006\032\004\b\004\020\005R\022\020\006\032\0020\007X¦\004¢\006\006\032\004\b\b\020\tR\022\020\n\032\0020\007X¦\004¢\006\006\032\004\b\013\020\tø\001\000\002\006\n\004\b!0\001¨\006\024À\006\001"}, d2 = {"Landroidx/sqlite/db/SupportSQLiteOpenHelper;", "Ljava/io/Closeable;", "databaseName", "", "getDatabaseName", "()Ljava/lang/String;", "readableDatabase", "Landroidx/sqlite/db/SupportSQLiteDatabase;", "getReadableDatabase", "()Landroidx/sqlite/db/SupportSQLiteDatabase;", "writableDatabase", "getWritableDatabase", "close", "", "setWriteAheadLoggingEnabled", "enabled", "", "Callback", "Configuration", "Factory", "sqlite_release"}, k = 1, mv = {1, 7, 1}, xi = 48)
public interface SupportSQLiteOpenHelper extends Closeable {
  void close();
  
  String getDatabaseName();
  
  SupportSQLiteDatabase getReadableDatabase();
  
  SupportSQLiteDatabase getWritableDatabase();
  
  @RequiresApi(api = 16)
  void setWriteAheadLoggingEnabled(boolean paramBoolean);
  
  @Metadata(d1 = {"\000(\n\002\030\002\n\002\020\000\n\000\n\002\020\b\n\002\b\002\n\002\020\002\n\000\n\002\020\016\n\002\b\002\n\002\030\002\n\002\b\t\b&\030\000 \0232\0020\001:\001\023B\r\022\006\020\002\032\0020\003¢\006\002\020\004J\020\020\005\032\0020\0062\006\020\007\032\0020\bH\002J\020\020\t\032\0020\0062\006\020\n\032\0020\013H\026J\020\020\f\032\0020\0062\006\020\n\032\0020\013H\026J\020\020\r\032\0020\0062\006\020\n\032\0020\013H&J \020\016\032\0020\0062\006\020\n\032\0020\0132\006\020\017\032\0020\0032\006\020\020\032\0020\003H\026J\020\020\021\032\0020\0062\006\020\n\032\0020\013H\026J \020\022\032\0020\0062\006\020\n\032\0020\0132\006\020\017\032\0020\0032\006\020\020\032\0020\003H&R\020\020\002\032\0020\0038\006X\004¢\006\002\n\000¨\006\024"}, d2 = {"Landroidx/sqlite/db/SupportSQLiteOpenHelper$Callback;", "", "version", "", "(I)V", "deleteDatabaseFile", "", "fileName", "", "onConfigure", "db", "Landroidx/sqlite/db/SupportSQLiteDatabase;", "onCorruption", "onCreate", "onDowngrade", "oldVersion", "newVersion", "onOpen", "onUpgrade", "Companion", "sqlite_release"}, k = 1, mv = {1, 7, 1}, xi = 48)
  public static abstract class Callback {
    public static final Companion Companion = new Companion(null);
    
    private static final String TAG = "SupportSQLite";
    
    public final int version;
    
    public Callback(int param1Int) {
      this.version = param1Int;
    }
    
    private final void deleteDatabaseFile(String param1String) {
      boolean bool = true;
      if (!StringsKt.equals(param1String, ":memory:", true)) {
        int j = param1String.length() - 1;
        int i = 0;
        boolean bool1 = false;
        while (i <= j) {
          int k;
          if (!bool1) {
            k = i;
          } else {
            k = j;
          } 
          if (Intrinsics.compare(param1String.charAt(k), 32) <= 0) {
            k = 1;
          } else {
            k = 0;
          } 
          if (!bool1) {
            if (k == 0) {
              bool1 = true;
              continue;
            } 
            i++;
            continue;
          } 
          if (k == 0)
            break; 
          j--;
        } 
        if (param1String.subSequence(i, j + 1).toString().length() == 0) {
          i = bool;
        } else {
          i = 0;
        } 
        if (i != 0)
          return; 
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("deleting the database file: ");
        stringBuilder.append(param1String);
        Log.w("SupportSQLite", stringBuilder.toString());
        try {
          SupportSQLiteCompat.Api16Impl.deleteDatabase(new File(param1String));
          return;
        } catch (Exception exception) {
          Log.w("SupportSQLite", "delete failed: ", exception);
        } 
      } 
    }
    
    public void onConfigure(SupportSQLiteDatabase param1SupportSQLiteDatabase) {
      Intrinsics.checkNotNullParameter(param1SupportSQLiteDatabase, "db");
    }
    
    public void onCorruption(SupportSQLiteDatabase param1SupportSQLiteDatabase) {
      String str;
      Iterator iterator;
      Intrinsics.checkNotNullParameter(param1SupportSQLiteDatabase, "db");
      null = new StringBuilder();
      null.append("Corruption reported by sqlite on database: ");
      null.append(param1SupportSQLiteDatabase);
      null.append(".path");
      Log.e("SupportSQLite", null.toString());
      if (!param1SupportSQLiteDatabase.isOpen()) {
        str = param1SupportSQLiteDatabase.getPath();
        if (str != null)
          deleteDatabaseFile(str); 
        return;
      } 
      null = null;
      sQLiteException = null;
      try {
        List list2 = str.getAttachedDbs();
      } catch (SQLiteException sQLiteException) {
      
      } finally {
        if (sQLiteException != null) {
          iterator = ((Iterable)sQLiteException).iterator();
          while (iterator.hasNext()) {
            Object object1 = ((Pair)iterator.next()).second;
            Intrinsics.checkNotNullExpressionValue(object1, "p.second");
            deleteDatabaseFile((String)object1);
          } 
        } else {
          str = iterator.getPath();
          if (str != null)
            deleteDatabaseFile(str); 
        } 
      } 
      Object object = SYNTHETIC_LOCAL_VARIABLE_2;
      try {
        str.close();
      } catch (IOException iOException) {}
      if (SYNTHETIC_LOCAL_VARIABLE_2 != null) {
        iterator = ((Iterable)SYNTHETIC_LOCAL_VARIABLE_2).iterator();
        while (iterator.hasNext()) {
          Object object1 = ((Pair)iterator.next()).second;
          Intrinsics.checkNotNullExpressionValue(object1, "p.second");
          deleteDatabaseFile((String)object1);
        } 
      } else {
        String str1 = iterator.getPath();
        if (str1 != null)
          deleteDatabaseFile(str1); 
      } 
    }
    
    public abstract void onCreate(SupportSQLiteDatabase param1SupportSQLiteDatabase);
    
    public void onDowngrade(SupportSQLiteDatabase param1SupportSQLiteDatabase, int param1Int1, int param1Int2) {
      Intrinsics.checkNotNullParameter(param1SupportSQLiteDatabase, "db");
      StringBuilder stringBuilder = new StringBuilder();
      stringBuilder.append("Can't downgrade database from version ");
      stringBuilder.append(param1Int1);
      stringBuilder.append(" to ");
      stringBuilder.append(param1Int2);
      throw new SQLiteException(stringBuilder.toString());
    }
    
    public void onOpen(SupportSQLiteDatabase param1SupportSQLiteDatabase) {
      Intrinsics.checkNotNullParameter(param1SupportSQLiteDatabase, "db");
    }
    
    public abstract void onUpgrade(SupportSQLiteDatabase param1SupportSQLiteDatabase, int param1Int1, int param1Int2);
    
    @Metadata(d1 = {"\000\022\n\002\030\002\n\002\020\000\n\002\b\002\n\002\020\016\n\000\b\003\030\0002\0020\001B\007\b\002¢\006\002\020\002R\016\020\003\032\0020\004XT¢\006\002\n\000¨\006\005"}, d2 = {"Landroidx/sqlite/db/SupportSQLiteOpenHelper$Callback$Companion;", "", "()V", "TAG", "", "sqlite_release"}, k = 1, mv = {1, 7, 1}, xi = 48)
    public static final class Companion {
      private Companion() {}
    }
  }
  
  @Metadata(d1 = {"\000\022\n\002\030\002\n\002\020\000\n\002\b\002\n\002\020\016\n\000\b\003\030\0002\0020\001B\007\b\002¢\006\002\020\002R\016\020\003\032\0020\004XT¢\006\002\n\000¨\006\005"}, d2 = {"Landroidx/sqlite/db/SupportSQLiteOpenHelper$Callback$Companion;", "", "()V", "TAG", "", "sqlite_release"}, k = 1, mv = {1, 7, 1}, xi = 48)
  public static final class Companion {
    private Companion() {}
  }
  
  @Metadata(d1 = {"\000$\n\002\030\002\n\002\020\000\n\000\n\002\030\002\n\000\n\002\020\016\n\000\n\002\030\002\n\000\n\002\020\013\n\002\b\005\030\000 \r2\0020\001:\002\f\rB3\022\006\020\002\032\0020\003\022\b\020\004\032\004\030\0010\005\022\006\020\006\032\0020\007\022\b\b\002\020\b\032\0020\t\022\b\b\002\020\n\032\0020\t¢\006\002\020\013R\020\020\n\032\0020\t8\006X\004¢\006\002\n\000R\020\020\006\032\0020\0078\006X\004¢\006\002\n\000R\020\020\002\032\0020\0038\006X\004¢\006\002\n\000R\022\020\004\032\004\030\0010\0058\006X\004¢\006\002\n\000R\020\020\b\032\0020\t8\006X\004¢\006\002\n\000¨\006\016"}, d2 = {"Landroidx/sqlite/db/SupportSQLiteOpenHelper$Configuration;", "", "context", "Landroid/content/Context;", "name", "", "callback", "Landroidx/sqlite/db/SupportSQLiteOpenHelper$Callback;", "useNoBackupDirectory", "", "allowDataLossOnRecovery", "(Landroid/content/Context;Ljava/lang/String;Landroidx/sqlite/db/SupportSQLiteOpenHelper$Callback;ZZ)V", "Builder", "Companion", "sqlite_release"}, k = 1, mv = {1, 7, 1}, xi = 48)
  public static final class Configuration {
    public static final Companion Companion = new Companion(null);
    
    public final boolean allowDataLossOnRecovery;
    
    public final SupportSQLiteOpenHelper.Callback callback;
    
    public final Context context;
    
    public final String name;
    
    public final boolean useNoBackupDirectory;
    
    public Configuration(Context param1Context, String param1String, SupportSQLiteOpenHelper.Callback param1Callback, boolean param1Boolean1, boolean param1Boolean2) {
      this.context = param1Context;
      this.name = param1String;
      this.callback = param1Callback;
      this.useNoBackupDirectory = param1Boolean1;
      this.allowDataLossOnRecovery = param1Boolean2;
    }
    
    public static final Builder builder(Context param1Context) {
      return Companion.builder(param1Context);
    }
    
    @Metadata(d1 = {"\000.\n\002\030\002\n\002\020\000\n\000\n\002\030\002\n\002\b\002\n\002\020\013\n\000\n\002\030\002\n\000\n\002\020\016\n\002\b\002\n\002\030\002\n\002\b\002\b\026\030\0002\0020\001B\017\b\000\022\006\020\002\032\0020\003¢\006\002\020\004J\020\020\005\032\0020\0002\006\020\005\032\0020\006H\026J\b\020\f\032\0020\rH\026J\020\020\007\032\0020\0002\006\020\007\032\0020\bH\026J\022\020\t\032\0020\0002\b\020\t\032\004\030\0010\nH\026J\020\020\016\032\0020\0002\006\020\013\032\0020\006H\026R\016\020\005\032\0020\006X\016¢\006\002\n\000R\020\020\007\032\004\030\0010\bX\016¢\006\002\n\000R\016\020\002\032\0020\003X\004¢\006\002\n\000R\020\020\t\032\004\030\0010\nX\016¢\006\002\n\000R\016\020\013\032\0020\006X\016¢\006\002\n\000¨\006\017"}, d2 = {"Landroidx/sqlite/db/SupportSQLiteOpenHelper$Configuration$Builder;", "", "context", "Landroid/content/Context;", "(Landroid/content/Context;)V", "allowDataLossOnRecovery", "", "callback", "Landroidx/sqlite/db/SupportSQLiteOpenHelper$Callback;", "name", "", "useNoBackupDirectory", "build", "Landroidx/sqlite/db/SupportSQLiteOpenHelper$Configuration;", "noBackupDirectory", "sqlite_release"}, k = 1, mv = {1, 7, 1}, xi = 48)
    public static class Builder {
      private boolean allowDataLossOnRecovery;
      
      private SupportSQLiteOpenHelper.Callback callback;
      
      private final Context context;
      
      private String name;
      
      private boolean useNoBackupDirectory;
      
      public Builder(Context param2Context) {
        this.context = param2Context;
      }
      
      public Builder allowDataLossOnRecovery(boolean param2Boolean) {
        this.allowDataLossOnRecovery = param2Boolean;
        return this;
      }
      
      public SupportSQLiteOpenHelper.Configuration build() {
        SupportSQLiteOpenHelper.Callback callback = this.callback;
        if (callback != null) {
          boolean bool = this.useNoBackupDirectory;
          boolean bool2 = true;
          boolean bool1 = bool2;
          if (bool) {
            String str = this.name;
            if (str == null || str.length() == 0) {
              bool1 = true;
            } else {
              bool1 = false;
            } 
            if (!bool1) {
              bool1 = bool2;
            } else {
              bool1 = false;
            } 
          } 
          if (bool1)
            return new SupportSQLiteOpenHelper.Configuration(this.context, this.name, callback, this.useNoBackupDirectory, this.allowDataLossOnRecovery); 
          throw new IllegalArgumentException("Must set a non-null database name to a configuration that uses the no backup directory.".toString());
        } 
        throw new IllegalArgumentException("Must set a callback to create the configuration.".toString());
      }
      
      public Builder callback(SupportSQLiteOpenHelper.Callback param2Callback) {
        Intrinsics.checkNotNullParameter(param2Callback, "callback");
        this.callback = param2Callback;
        return this;
      }
      
      public Builder name(String param2String) {
        this.name = param2String;
        return this;
      }
      
      public Builder noBackupDirectory(boolean param2Boolean) {
        this.useNoBackupDirectory = param2Boolean;
        return this;
      }
    }
    
    @Metadata(d1 = {"\000\030\n\002\030\002\n\002\020\000\n\002\b\002\n\002\030\002\n\000\n\002\030\002\n\000\b\003\030\0002\0020\001B\007\b\002¢\006\002\020\002J\020\020\003\032\0020\0042\006\020\005\032\0020\006H\007¨\006\007"}, d2 = {"Landroidx/sqlite/db/SupportSQLiteOpenHelper$Configuration$Companion;", "", "()V", "builder", "Landroidx/sqlite/db/SupportSQLiteOpenHelper$Configuration$Builder;", "context", "Landroid/content/Context;", "sqlite_release"}, k = 1, mv = {1, 7, 1}, xi = 48)
    public static final class Companion {
      private Companion() {}
      
      public final SupportSQLiteOpenHelper.Configuration.Builder builder(Context param2Context) {
        Intrinsics.checkNotNullParameter(param2Context, "context");
        return new SupportSQLiteOpenHelper.Configuration.Builder(param2Context);
      }
    }
  }
  
  @Metadata(d1 = {"\000.\n\002\030\002\n\002\020\000\n\000\n\002\030\002\n\002\b\002\n\002\020\013\n\000\n\002\030\002\n\000\n\002\020\016\n\002\b\002\n\002\030\002\n\002\b\002\b\026\030\0002\0020\001B\017\b\000\022\006\020\002\032\0020\003¢\006\002\020\004J\020\020\005\032\0020\0002\006\020\005\032\0020\006H\026J\b\020\f\032\0020\rH\026J\020\020\007\032\0020\0002\006\020\007\032\0020\bH\026J\022\020\t\032\0020\0002\b\020\t\032\004\030\0010\nH\026J\020\020\016\032\0020\0002\006\020\013\032\0020\006H\026R\016\020\005\032\0020\006X\016¢\006\002\n\000R\020\020\007\032\004\030\0010\bX\016¢\006\002\n\000R\016\020\002\032\0020\003X\004¢\006\002\n\000R\020\020\t\032\004\030\0010\nX\016¢\006\002\n\000R\016\020\013\032\0020\006X\016¢\006\002\n\000¨\006\017"}, d2 = {"Landroidx/sqlite/db/SupportSQLiteOpenHelper$Configuration$Builder;", "", "context", "Landroid/content/Context;", "(Landroid/content/Context;)V", "allowDataLossOnRecovery", "", "callback", "Landroidx/sqlite/db/SupportSQLiteOpenHelper$Callback;", "name", "", "useNoBackupDirectory", "build", "Landroidx/sqlite/db/SupportSQLiteOpenHelper$Configuration;", "noBackupDirectory", "sqlite_release"}, k = 1, mv = {1, 7, 1}, xi = 48)
  public static class Builder {
    private boolean allowDataLossOnRecovery;
    
    private SupportSQLiteOpenHelper.Callback callback;
    
    private final Context context;
    
    private String name;
    
    private boolean useNoBackupDirectory;
    
    public Builder(Context param1Context) {
      this.context = param1Context;
    }
    
    public Builder allowDataLossOnRecovery(boolean param1Boolean) {
      this.allowDataLossOnRecovery = param1Boolean;
      return this;
    }
    
    public SupportSQLiteOpenHelper.Configuration build() {
      SupportSQLiteOpenHelper.Callback callback = this.callback;
      if (callback != null) {
        boolean bool = this.useNoBackupDirectory;
        boolean bool2 = true;
        boolean bool1 = bool2;
        if (bool) {
          String str = this.name;
          if (str == null || str.length() == 0) {
            bool1 = true;
          } else {
            bool1 = false;
          } 
          if (!bool1) {
            bool1 = bool2;
          } else {
            bool1 = false;
          } 
        } 
        if (bool1)
          return new SupportSQLiteOpenHelper.Configuration(this.context, this.name, callback, this.useNoBackupDirectory, this.allowDataLossOnRecovery); 
        throw new IllegalArgumentException("Must set a non-null database name to a configuration that uses the no backup directory.".toString());
      } 
      throw new IllegalArgumentException("Must set a callback to create the configuration.".toString());
    }
    
    public Builder callback(SupportSQLiteOpenHelper.Callback param1Callback) {
      Intrinsics.checkNotNullParameter(param1Callback, "callback");
      this.callback = param1Callback;
      return this;
    }
    
    public Builder name(String param1String) {
      this.name = param1String;
      return this;
    }
    
    public Builder noBackupDirectory(boolean param1Boolean) {
      this.useNoBackupDirectory = param1Boolean;
      return this;
    }
  }
  
  @Metadata(d1 = {"\000\030\n\002\030\002\n\002\020\000\n\002\b\002\n\002\030\002\n\000\n\002\030\002\n\000\b\003\030\0002\0020\001B\007\b\002¢\006\002\020\002J\020\020\003\032\0020\0042\006\020\005\032\0020\006H\007¨\006\007"}, d2 = {"Landroidx/sqlite/db/SupportSQLiteOpenHelper$Configuration$Companion;", "", "()V", "builder", "Landroidx/sqlite/db/SupportSQLiteOpenHelper$Configuration$Builder;", "context", "Landroid/content/Context;", "sqlite_release"}, k = 1, mv = {1, 7, 1}, xi = 48)
  public static final class Companion {
    private Companion() {}
    
    public final SupportSQLiteOpenHelper.Configuration.Builder builder(Context param1Context) {
      Intrinsics.checkNotNullParameter(param1Context, "context");
      return new SupportSQLiteOpenHelper.Configuration.Builder(param1Context);
    }
  }
  
  @Metadata(d1 = {"\000\026\n\002\030\002\n\002\020\000\n\000\n\002\030\002\n\000\n\002\030\002\n\000\bæ\001\030\0002\0020\001J\020\020\002\032\0020\0032\006\020\004\032\0020\005H&ø\001\000\002\006\n\004\b!0\001¨\006\006À\006\001"}, d2 = {"Landroidx/sqlite/db/SupportSQLiteOpenHelper$Factory;", "", "create", "Landroidx/sqlite/db/SupportSQLiteOpenHelper;", "configuration", "Landroidx/sqlite/db/SupportSQLiteOpenHelper$Configuration;", "sqlite_release"}, k = 1, mv = {1, 7, 1}, xi = 48)
  public static interface Factory {
    SupportSQLiteOpenHelper create(SupportSQLiteOpenHelper.Configuration param1Configuration);
  }
}


/* Location:              C:\soft\dex2jar-2.0\MagicAI - AI Art & Anime Art-dex2jar.jar!\androidx\sqlite\db\SupportSQLiteOpenHelper.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */