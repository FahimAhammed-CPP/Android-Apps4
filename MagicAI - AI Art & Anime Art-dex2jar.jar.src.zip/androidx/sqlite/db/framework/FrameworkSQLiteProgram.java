package androidx.sqlite.db.framework;

import android.database.sqlite.SQLiteProgram;
import androidx.sqlite.db.SupportSQLiteProgram;
import kotlin.Metadata;
import kotlin.jvm.internal.Intrinsics;

@Metadata(d1 = {"\000:\n\002\030\002\n\002\030\002\n\000\n\002\030\002\n\002\b\002\n\002\020\002\n\000\n\002\020\b\n\000\n\002\020\022\n\000\n\002\020\006\n\000\n\002\020\t\n\002\b\002\n\002\020\016\n\002\b\003\b\020\030\0002\0020\001B\r\022\006\020\002\032\0020\003¢\006\002\020\004J\030\020\005\032\0020\0062\006\020\007\032\0020\b2\006\020\t\032\0020\nH\026J\030\020\013\032\0020\0062\006\020\007\032\0020\b2\006\020\t\032\0020\fH\026J\030\020\r\032\0020\0062\006\020\007\032\0020\b2\006\020\t\032\0020\016H\026J\020\020\017\032\0020\0062\006\020\007\032\0020\bH\026J\030\020\020\032\0020\0062\006\020\007\032\0020\b2\006\020\t\032\0020\021H\026J\b\020\022\032\0020\006H\026J\b\020\023\032\0020\006H\026R\016\020\002\032\0020\003X\004¢\006\002\n\000¨\006\024"}, d2 = {"Landroidx/sqlite/db/framework/FrameworkSQLiteProgram;", "Landroidx/sqlite/db/SupportSQLiteProgram;", "delegate", "Landroid/database/sqlite/SQLiteProgram;", "(Landroid/database/sqlite/SQLiteProgram;)V", "bindBlob", "", "index", "", "value", "", "bindDouble", "", "bindLong", "", "bindNull", "bindString", "", "clearBindings", "close", "sqlite-framework_release"}, k = 1, mv = {1, 7, 1}, xi = 48)
public class FrameworkSQLiteProgram implements SupportSQLiteProgram {
  private final SQLiteProgram delegate;
  
  public FrameworkSQLiteProgram(SQLiteProgram paramSQLiteProgram) {
    this.delegate = paramSQLiteProgram;
  }
  
  public void bindBlob(int paramInt, byte[] paramArrayOfbyte) {
    Intrinsics.checkNotNullParameter(paramArrayOfbyte, "value");
    this.delegate.bindBlob(paramInt, paramArrayOfbyte);
  }
  
  public void bindDouble(int paramInt, double paramDouble) {
    this.delegate.bindDouble(paramInt, paramDouble);
  }
  
  public void bindLong(int paramInt, long paramLong) {
    this.delegate.bindLong(paramInt, paramLong);
  }
  
  public void bindNull(int paramInt) {
    this.delegate.bindNull(paramInt);
  }
  
  public void bindString(int paramInt, String paramString) {
    Intrinsics.checkNotNullParameter(paramString, "value");
    this.delegate.bindString(paramInt, paramString);
  }
  
  public void clearBindings() {
    this.delegate.clearBindings();
  }
  
  public void close() {
    this.delegate.close();
  }
}


/* Location:              C:\soft\dex2jar-2.0\MagicAI - AI Art & Anime Art-dex2jar.jar!\androidx\sqlite\db\framework\FrameworkSQLiteProgram.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */