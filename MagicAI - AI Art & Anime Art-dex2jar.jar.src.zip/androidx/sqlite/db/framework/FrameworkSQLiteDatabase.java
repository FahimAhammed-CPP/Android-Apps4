package androidx.sqlite.db.framework;

import android.content.ContentValues;
import android.database.Cursor;
import android.database.SQLException;
import android.database.sqlite.SQLiteCursor;
import android.database.sqlite.SQLiteCursorDriver;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteProgram;
import android.database.sqlite.SQLiteQuery;
import android.database.sqlite.SQLiteStatement;
import android.database.sqlite.SQLiteTransactionListener;
import android.os.Build;
import android.os.CancellationSignal;
import android.text.TextUtils;
import android.util.Pair;
import androidx.annotation.DoNotInline;
import androidx.annotation.RequiresApi;
import androidx.sqlite.db.SimpleSQLiteQuery;
import androidx.sqlite.db.SupportSQLiteCompat;
import androidx.sqlite.db.SupportSQLiteDatabase;
import androidx.sqlite.db.SupportSQLiteProgram;
import androidx.sqlite.db.SupportSQLiteQuery;
import androidx.sqlite.db.SupportSQLiteStatement;
import java.io.IOException;
import java.util.Iterator;
import java.util.List;
import java.util.Locale;
import kotlin.Metadata;
import kotlin.jvm.functions.Function4;
import kotlin.jvm.internal.DefaultConstructorMarker;
import kotlin.jvm.internal.Intrinsics;
import kotlin.jvm.internal.Lambda;

@Metadata(d1 = {"\000\001\n\002\030\002\n\002\030\002\n\000\n\002\030\002\n\002\b\002\n\002\020 \n\002\030\002\n\002\020\016\n\002\b\003\n\002\020\013\n\002\b\007\n\002\020\t\n\002\b\f\n\002\020\b\n\002\b\006\n\002\020\002\n\002\b\003\n\002\030\002\n\002\b\003\n\002\030\002\n\002\b\005\n\002\020\021\n\002\020\000\n\002\b\f\n\002\030\002\n\002\b\005\n\002\030\002\n\002\030\002\n\000\n\002\030\002\n\002\b\005\n\002\030\002\n\002\b\n\b\000\030\000 \\2\0020\001:\002[\\B\r\022\006\020\002\032\0020\003¢\006\002\020\004J\b\020'\032\0020(H\026J\b\020)\032\0020(H\026J\020\020*\032\0020(2\006\020+\032\0020,H\026J\020\020-\032\0020(2\006\020+\032\0020,H\026J\b\020.\032\0020(H\026J\020\020/\032\002002\006\0201\032\0020\bH\026J3\0202\032\0020!2\006\0203\032\0020\b2\b\0204\032\004\030\0010\b2\022\0205\032\016\022\b\b\001\022\004\030\00107\030\00106H\026¢\006\002\0208J\b\0209\032\0020(H\027J\b\020:\032\0020\fH\026J\b\020;\032\0020(H\026J)\020<\032\0020(2\006\0201\032\0020\b2\022\020=\032\016\022\b\b\001\022\004\030\00107\030\00106H\026¢\006\002\020>J\020\020?\032\0020(2\006\0201\032\0020\bH\026J'\020?\032\0020(2\006\0201\032\0020\b2\020\020=\032\f\022\b\b\001\022\004\030\0010706H\026¢\006\002\020>J\b\020@\032\0020\fH\026J \020A\032\0020\0242\006\0203\032\0020\b2\006\020B\032\0020!2\006\020C\032\0020DH\026J\016\020E\032\0020\f2\006\020F\032\0020\003J\020\020G\032\0020\f2\006\020H\032\0020!H\026J\020\020I\032\0020J2\006\020I\032\0020KH\026J\032\020I\032\0020J2\006\020I\032\0020K2\b\020L\032\004\030\0010MH\027J\020\020I\032\0020J2\006\020I\032\0020\bH\026J'\020I\032\0020J2\006\020I\032\0020\b2\020\020=\032\f\022\b\b\001\022\004\030\0010706H\026¢\006\002\020NJ\020\020O\032\0020(2\006\020P\032\0020\fH\027J\020\020Q\032\0020(2\006\020R\032\0020SH\026J\020\020T\032\0020(2\006\020U\032\0020!H\026J\020\020\030\032\0020\0242\006\020\023\032\0020\024H\026J\b\020V\032\0020(H\026JC\020W\032\0020!2\006\0203\032\0020\b2\006\020B\032\0020!2\006\020C\032\0020D2\b\0204\032\004\030\0010\b2\022\0205\032\016\022\b\b\001\022\004\030\00107\030\00106H\026¢\006\002\020XJ\b\020Y\032\0020\fH\026J\020\020Y\032\0020\f2\006\020Z\032\0020\024H\026R(\020\005\032\026\022\020\022\016\022\004\022\0020\b\022\004\022\0020\b0\007\030\0010\006X\004¢\006\b\n\000\032\004\b\t\020\nR\016\020\002\032\0020\003X\004¢\006\002\n\000R\024\020\013\032\0020\f8VX\004¢\006\006\032\004\b\013\020\rR\024\020\016\032\0020\f8VX\004¢\006\006\032\004\b\016\020\rR\024\020\017\032\0020\f8VX\004¢\006\006\032\004\b\017\020\rR\024\020\020\032\0020\f8VX\004¢\006\006\032\004\b\020\020\rR\024\020\021\032\0020\f8VX\004¢\006\006\032\004\b\021\020\rR\024\020\022\032\0020\f8WX\004¢\006\006\032\004\b\022\020\rR$\020\025\032\0020\0242\006\020\023\032\0020\0248V@VX\016¢\006\f\032\004\b\026\020\027\"\004\b\030\020\031R$\020\032\032\0020\0242\006\020\023\032\0020\0248V@VX\016¢\006\f\032\004\b\033\020\027\"\004\b\034\020\031R\026\020\035\032\004\030\0010\b8VX\004¢\006\006\032\004\b\036\020\037R$\020\"\032\0020!2\006\020 \032\0020!8V@VX\016¢\006\f\032\004\b#\020$\"\004\b%\020&¨\006]"}, d2 = {"Landroidx/sqlite/db/framework/FrameworkSQLiteDatabase;", "Landroidx/sqlite/db/SupportSQLiteDatabase;", "delegate", "Landroid/database/sqlite/SQLiteDatabase;", "(Landroid/database/sqlite/SQLiteDatabase;)V", "attachedDbs", "", "Landroid/util/Pair;", "", "getAttachedDbs", "()Ljava/util/List;", "isDatabaseIntegrityOk", "", "()Z", "isDbLockedByCurrentThread", "isExecPerConnectionSQLSupported", "isOpen", "isReadOnly", "isWriteAheadLoggingEnabled", "numBytes", "", "maximumSize", "getMaximumSize", "()J", "setMaximumSize", "(J)V", "pageSize", "getPageSize", "setPageSize", "path", "getPath", "()Ljava/lang/String;", "value", "", "version", "getVersion", "()I", "setVersion", "(I)V", "beginTransaction", "", "beginTransactionNonExclusive", "beginTransactionWithListener", "transactionListener", "Landroid/database/sqlite/SQLiteTransactionListener;", "beginTransactionWithListenerNonExclusive", "close", "compileStatement", "Landroidx/sqlite/db/SupportSQLiteStatement;", "sql", "delete", "table", "whereClause", "whereArgs", "", "", "(Ljava/lang/String;Ljava/lang/String;[Ljava/lang/Object;)I", "disableWriteAheadLogging", "enableWriteAheadLogging", "endTransaction", "execPerConnectionSQL", "bindArgs", "(Ljava/lang/String;[Ljava/lang/Object;)V", "execSQL", "inTransaction", "insert", "conflictAlgorithm", "values", "Landroid/content/ContentValues;", "isDelegate", "sqLiteDatabase", "needUpgrade", "newVersion", "query", "Landroid/database/Cursor;", "Landroidx/sqlite/db/SupportSQLiteQuery;", "cancellationSignal", "Landroid/os/CancellationSignal;", "(Ljava/lang/String;[Ljava/lang/Object;)Landroid/database/Cursor;", "setForeignKeyConstraintsEnabled", "enabled", "setLocale", "locale", "Ljava/util/Locale;", "setMaxSqlCacheSize", "cacheSize", "setTransactionSuccessful", "update", "(Ljava/lang/String;ILandroid/content/ContentValues;Ljava/lang/String;[Ljava/lang/Object;)I", "yieldIfContendedSafely", "sleepAfterYieldDelayMillis", "Api30Impl", "Companion", "sqlite-framework_release"}, k = 1, mv = {1, 7, 1}, xi = 48)
public final class FrameworkSQLiteDatabase implements SupportSQLiteDatabase {
  private static final String[] CONFLICT_VALUES;
  
  public static final Companion Companion = new Companion(null);
  
  private static final String[] EMPTY_STRING_ARRAY;
  
  private final List<Pair<String, String>> attachedDbs;
  
  private final SQLiteDatabase delegate;
  
  static {
    CONFLICT_VALUES = new String[] { "", " OR ROLLBACK ", " OR ABORT ", " OR FAIL ", " OR IGNORE ", " OR REPLACE " };
    EMPTY_STRING_ARRAY = new String[0];
  }
  
  public FrameworkSQLiteDatabase(SQLiteDatabase paramSQLiteDatabase) {
    this.delegate = paramSQLiteDatabase;
    this.attachedDbs = paramSQLiteDatabase.getAttachedDbs();
  }
  
  private static final Cursor query$lambda$0(Function4 paramFunction4, SQLiteDatabase paramSQLiteDatabase, SQLiteCursorDriver paramSQLiteCursorDriver, String paramString, SQLiteQuery paramSQLiteQuery) {
    Intrinsics.checkNotNullParameter(paramFunction4, "$tmp0");
    return (Cursor)paramFunction4.invoke(paramSQLiteDatabase, paramSQLiteCursorDriver, paramString, paramSQLiteQuery);
  }
  
  private static final Cursor query$lambda$1(SupportSQLiteQuery paramSupportSQLiteQuery, SQLiteDatabase paramSQLiteDatabase, SQLiteCursorDriver paramSQLiteCursorDriver, String paramString, SQLiteQuery paramSQLiteQuery) {
    Intrinsics.checkNotNullParameter(paramSupportSQLiteQuery, "$query");
    Intrinsics.checkNotNull(paramSQLiteQuery);
    paramSupportSQLiteQuery.bindTo(new FrameworkSQLiteProgram((SQLiteProgram)paramSQLiteQuery));
    return (Cursor)new SQLiteCursor(paramSQLiteCursorDriver, paramString, paramSQLiteQuery);
  }
  
  public void beginTransaction() {
    this.delegate.beginTransaction();
  }
  
  public void beginTransactionNonExclusive() {
    this.delegate.beginTransactionNonExclusive();
  }
  
  public void beginTransactionWithListener(SQLiteTransactionListener paramSQLiteTransactionListener) {
    Intrinsics.checkNotNullParameter(paramSQLiteTransactionListener, "transactionListener");
    this.delegate.beginTransactionWithListener(paramSQLiteTransactionListener);
  }
  
  public void beginTransactionWithListenerNonExclusive(SQLiteTransactionListener paramSQLiteTransactionListener) {
    Intrinsics.checkNotNullParameter(paramSQLiteTransactionListener, "transactionListener");
    this.delegate.beginTransactionWithListenerNonExclusive(paramSQLiteTransactionListener);
  }
  
  public void close() throws IOException {
    this.delegate.close();
  }
  
  public SupportSQLiteStatement compileStatement(String paramString) {
    Intrinsics.checkNotNullParameter(paramString, "sql");
    SQLiteStatement sQLiteStatement = this.delegate.compileStatement(paramString);
    Intrinsics.checkNotNullExpressionValue(sQLiteStatement, "delegate.compileStatement(sql)");
    return (SupportSQLiteStatement)new FrameworkSQLiteStatement(sQLiteStatement);
  }
  
  public int delete(String paramString1, String paramString2, Object[] paramArrayOfObject) {
    boolean bool;
    Intrinsics.checkNotNullParameter(paramString1, "table");
    StringBuilder stringBuilder = new StringBuilder();
    stringBuilder.append("DELETE FROM ");
    stringBuilder.append(paramString1);
    if (paramString2 == null || paramString2.length() == 0) {
      bool = true;
    } else {
      bool = false;
    } 
    if (!bool) {
      stringBuilder.append(" WHERE ");
      stringBuilder.append(paramString2);
    } 
    paramString1 = stringBuilder.toString();
    Intrinsics.checkNotNullExpressionValue(paramString1, "StringBuilder().apply(builderAction).toString()");
    SupportSQLiteStatement supportSQLiteStatement = compileStatement(paramString1);
    SimpleSQLiteQuery.Companion.bind((SupportSQLiteProgram)supportSQLiteStatement, paramArrayOfObject);
    return supportSQLiteStatement.executeUpdateDelete();
  }
  
  @RequiresApi(api = 16)
  public void disableWriteAheadLogging() {
    SupportSQLiteCompat.Api16Impl.disableWriteAheadLogging(this.delegate);
  }
  
  public boolean enableWriteAheadLogging() {
    return this.delegate.enableWriteAheadLogging();
  }
  
  public void endTransaction() {
    this.delegate.endTransaction();
  }
  
  public void execPerConnectionSQL(String paramString, Object[] paramArrayOfObject) {
    Intrinsics.checkNotNullParameter(paramString, "sql");
    int i = Build.VERSION.SDK_INT;
    if (i >= 30) {
      Api30Impl.INSTANCE.execPerConnectionSQL(this.delegate, paramString, paramArrayOfObject);
      return;
    } 
    StringBuilder stringBuilder = new StringBuilder();
    stringBuilder.append("execPerConnectionSQL is not supported on a SDK version lower than 30, current version is: ");
    stringBuilder.append(i);
    throw new UnsupportedOperationException(stringBuilder.toString());
  }
  
  public void execSQL(String paramString) throws SQLException {
    Intrinsics.checkNotNullParameter(paramString, "sql");
    this.delegate.execSQL(paramString);
  }
  
  public void execSQL(String paramString, Object[] paramArrayOfObject) throws SQLException {
    Intrinsics.checkNotNullParameter(paramString, "sql");
    Intrinsics.checkNotNullParameter(paramArrayOfObject, "bindArgs");
    this.delegate.execSQL(paramString, paramArrayOfObject);
  }
  
  public List<Pair<String, String>> getAttachedDbs() {
    return this.attachedDbs;
  }
  
  public long getMaximumSize() {
    return this.delegate.getMaximumSize();
  }
  
  public long getPageSize() {
    return this.delegate.getPageSize();
  }
  
  public String getPath() {
    return this.delegate.getPath();
  }
  
  public int getVersion() {
    return this.delegate.getVersion();
  }
  
  public boolean inTransaction() {
    return this.delegate.inTransaction();
  }
  
  public long insert(String paramString, int paramInt, ContentValues paramContentValues) throws SQLException {
    Intrinsics.checkNotNullParameter(paramString, "table");
    Intrinsics.checkNotNullParameter(paramContentValues, "values");
    return this.delegate.insertWithOnConflict(paramString, null, paramContentValues, paramInt);
  }
  
  public boolean isDatabaseIntegrityOk() {
    return this.delegate.isDatabaseIntegrityOk();
  }
  
  public boolean isDbLockedByCurrentThread() {
    return this.delegate.isDbLockedByCurrentThread();
  }
  
  public final boolean isDelegate(SQLiteDatabase paramSQLiteDatabase) {
    Intrinsics.checkNotNullParameter(paramSQLiteDatabase, "sqLiteDatabase");
    return Intrinsics.areEqual(this.delegate, paramSQLiteDatabase);
  }
  
  public boolean isExecPerConnectionSQLSupported() {
    return (Build.VERSION.SDK_INT >= 30);
  }
  
  public boolean isOpen() {
    return this.delegate.isOpen();
  }
  
  public boolean isReadOnly() {
    return this.delegate.isReadOnly();
  }
  
  @RequiresApi(api = 16)
  public boolean isWriteAheadLoggingEnabled() {
    return SupportSQLiteCompat.Api16Impl.isWriteAheadLoggingEnabled(this.delegate);
  }
  
  public boolean needUpgrade(int paramInt) {
    return this.delegate.needUpgrade(paramInt);
  }
  
  public Cursor query(SupportSQLiteQuery paramSupportSQLiteQuery) {
    Intrinsics.checkNotNullParameter(paramSupportSQLiteQuery, "query");
    FrameworkSQLiteDatabase$query$cursorFactory$1 frameworkSQLiteDatabase$query$cursorFactory$1 = new FrameworkSQLiteDatabase$query$cursorFactory$1(paramSupportSQLiteQuery);
    Cursor cursor = this.delegate.rawQueryWithFactory((SQLiteDatabase.CursorFactory)new FrameworkSQLiteDatabase$.ExternalSyntheticLambda1(frameworkSQLiteDatabase$query$cursorFactory$1), paramSupportSQLiteQuery.getSql(), EMPTY_STRING_ARRAY, null);
    Intrinsics.checkNotNullExpressionValue(cursor, "delegate.rawQueryWithFac…EMPTY_STRING_ARRAY, null)");
    return cursor;
  }
  
  @RequiresApi(16)
  public Cursor query(SupportSQLiteQuery paramSupportSQLiteQuery, CancellationSignal paramCancellationSignal) {
    Intrinsics.checkNotNullParameter(paramSupportSQLiteQuery, "query");
    SQLiteDatabase sQLiteDatabase = this.delegate;
    String str = paramSupportSQLiteQuery.getSql();
    String[] arrayOfString = EMPTY_STRING_ARRAY;
    Intrinsics.checkNotNull(paramCancellationSignal);
    return SupportSQLiteCompat.Api16Impl.rawQueryWithFactory(sQLiteDatabase, str, arrayOfString, null, paramCancellationSignal, (SQLiteDatabase.CursorFactory)new FrameworkSQLiteDatabase$.ExternalSyntheticLambda0(paramSupportSQLiteQuery));
  }
  
  public Cursor query(String paramString) {
    Intrinsics.checkNotNullParameter(paramString, "query");
    return query((SupportSQLiteQuery)new SimpleSQLiteQuery(paramString));
  }
  
  public Cursor query(String paramString, Object[] paramArrayOfObject) {
    Intrinsics.checkNotNullParameter(paramString, "query");
    Intrinsics.checkNotNullParameter(paramArrayOfObject, "bindArgs");
    return query((SupportSQLiteQuery)new SimpleSQLiteQuery(paramString, paramArrayOfObject));
  }
  
  @RequiresApi(api = 16)
  public void setForeignKeyConstraintsEnabled(boolean paramBoolean) {
    SupportSQLiteCompat.Api16Impl.setForeignKeyConstraintsEnabled(this.delegate, paramBoolean);
  }
  
  public void setLocale(Locale paramLocale) {
    Intrinsics.checkNotNullParameter(paramLocale, "locale");
    this.delegate.setLocale(paramLocale);
  }
  
  public void setMaxSqlCacheSize(int paramInt) {
    this.delegate.setMaxSqlCacheSize(paramInt);
  }
  
  public long setMaximumSize(long paramLong) {
    this.delegate.setMaximumSize(paramLong);
    return this.delegate.getMaximumSize();
  }
  
  public void setMaximumSize(long paramLong) {
    this.delegate.setMaximumSize(paramLong);
  }
  
  public void setPageSize(long paramLong) {
    this.delegate.setPageSize(paramLong);
  }
  
  public void setTransactionSuccessful() {
    this.delegate.setTransactionSuccessful();
  }
  
  public void setVersion(int paramInt) {
    this.delegate.setVersion(paramInt);
  }
  
  public int update(String paramString1, int paramInt, ContentValues paramContentValues, String paramString2, Object[] paramArrayOfObject) {
    Intrinsics.checkNotNullParameter(paramString1, "table");
    Intrinsics.checkNotNullParameter(paramContentValues, "values");
    int i = paramContentValues.size();
    boolean bool = false;
    if (i != 0) {
      i = 1;
    } else {
      i = 0;
    } 
    if (i != 0) {
      int j;
      i = paramContentValues.size();
      if (paramArrayOfObject == null) {
        j = i;
      } else {
        j = paramArrayOfObject.length + i;
      } 
      Object[] arrayOfObject = new Object[j];
      StringBuilder stringBuilder = new StringBuilder();
      stringBuilder.append("UPDATE ");
      stringBuilder.append(CONFLICT_VALUES[paramInt]);
      stringBuilder.append(paramString1);
      stringBuilder.append(" SET ");
      Iterator<String> iterator = paramContentValues.keySet().iterator();
      for (paramInt = bool; iterator.hasNext(); paramInt++) {
        String str = iterator.next();
        if (paramInt > 0) {
          paramString1 = ",";
        } else {
          paramString1 = "";
        } 
        stringBuilder.append(paramString1);
        stringBuilder.append(str);
        arrayOfObject[paramInt] = paramContentValues.get(str);
        stringBuilder.append("=?");
      } 
      if (paramArrayOfObject != null)
        for (paramInt = i; paramInt < j; paramInt++)
          arrayOfObject[paramInt] = paramArrayOfObject[paramInt - i];  
      if (!TextUtils.isEmpty(paramString2)) {
        stringBuilder.append(" WHERE ");
        stringBuilder.append(paramString2);
      } 
      paramString1 = stringBuilder.toString();
      Intrinsics.checkNotNullExpressionValue(paramString1, "StringBuilder().apply(builderAction).toString()");
      SupportSQLiteStatement supportSQLiteStatement = compileStatement(paramString1);
      SimpleSQLiteQuery.Companion.bind((SupportSQLiteProgram)supportSQLiteStatement, arrayOfObject);
      return supportSQLiteStatement.executeUpdateDelete();
    } 
    throw new IllegalArgumentException("Empty values".toString());
  }
  
  public boolean yieldIfContendedSafely() {
    return this.delegate.yieldIfContendedSafely();
  }
  
  public boolean yieldIfContendedSafely(long paramLong) {
    return this.delegate.yieldIfContendedSafely(paramLong);
  }
  
  @Metadata(d1 = {"\000&\n\002\030\002\n\002\020\000\n\002\b\002\n\002\020\002\n\000\n\002\030\002\n\000\n\002\020\016\n\000\n\002\020\021\n\002\b\002\bÁ\002\030\0002\0020\001B\007\b\002¢\006\002\020\002J1\020\003\032\0020\0042\006\020\005\032\0020\0062\006\020\007\032\0020\b2\022\020\t\032\016\022\b\b\001\022\004\030\0010\001\030\0010\nH\007¢\006\002\020\013¨\006\f"}, d2 = {"Landroidx/sqlite/db/framework/FrameworkSQLiteDatabase$Api30Impl;", "", "()V", "execPerConnectionSQL", "", "sQLiteDatabase", "Landroid/database/sqlite/SQLiteDatabase;", "sql", "", "bindArgs", "", "(Landroid/database/sqlite/SQLiteDatabase;Ljava/lang/String;[Ljava/lang/Object;)V", "sqlite-framework_release"}, k = 1, mv = {1, 7, 1}, xi = 48)
  @RequiresApi(30)
  public static final class Api30Impl {
    public static final Api30Impl INSTANCE = new Api30Impl();
    
    @DoNotInline
    public final void execPerConnectionSQL(SQLiteDatabase param1SQLiteDatabase, String param1String, Object[] param1ArrayOfObject) {
      Intrinsics.checkNotNullParameter(param1SQLiteDatabase, "sQLiteDatabase");
      Intrinsics.checkNotNullParameter(param1String, "sql");
      FrameworkSQLiteDatabase$Api30Impl$.ExternalSyntheticApiModelOutline0.m(param1SQLiteDatabase, param1String, param1ArrayOfObject);
    }
  }
  
  @Metadata(d1 = {"\000\030\n\002\030\002\n\002\020\000\n\002\b\002\n\002\020\021\n\002\020\016\n\002\b\003\b\003\030\0002\0020\001B\007\b\002¢\006\002\020\002R\026\020\003\032\b\022\004\022\0020\0050\004X\004¢\006\004\n\002\020\006R\030\020\007\032\n\022\006\022\004\030\0010\0050\004X\004¢\006\004\n\002\020\006¨\006\b"}, d2 = {"Landroidx/sqlite/db/framework/FrameworkSQLiteDatabase$Companion;", "", "()V", "CONFLICT_VALUES", "", "", "[Ljava/lang/String;", "EMPTY_STRING_ARRAY", "sqlite-framework_release"}, k = 1, mv = {1, 7, 1}, xi = 48)
  public static final class Companion {
    private Companion() {}
  }
  
  @Metadata(d1 = {"\000 \n\000\n\002\030\002\n\000\n\002\030\002\n\000\n\002\030\002\n\000\n\002\020\016\n\000\n\002\030\002\n\000\020\000\032\0020\0012\b\020\002\032\004\030\0010\0032\b\020\004\032\004\030\0010\0052\b\020\006\032\004\030\0010\0072\b\020\b\032\004\030\0010\tH\n¢\006\002\b\n"}, d2 = {"<anonymous>", "Landroid/database/sqlite/SQLiteCursor;", "<anonymous parameter 0>", "Landroid/database/sqlite/SQLiteDatabase;", "masterQuery", "Landroid/database/sqlite/SQLiteCursorDriver;", "editTable", "", "sqLiteQuery", "Landroid/database/sqlite/SQLiteQuery;", "invoke"}, k = 3, mv = {1, 7, 1}, xi = 48)
  static final class FrameworkSQLiteDatabase$query$cursorFactory$1 extends Lambda implements Function4<SQLiteDatabase, SQLiteCursorDriver, String, SQLiteQuery, SQLiteCursor> {
    FrameworkSQLiteDatabase$query$cursorFactory$1(SupportSQLiteQuery param1SupportSQLiteQuery) {
      super(4);
    }
    
    public final SQLiteCursor invoke(SQLiteDatabase param1SQLiteDatabase, SQLiteCursorDriver param1SQLiteCursorDriver, String param1String, SQLiteQuery param1SQLiteQuery) {
      SupportSQLiteQuery supportSQLiteQuery = this.$query;
      Intrinsics.checkNotNull(param1SQLiteQuery);
      supportSQLiteQuery.bindTo(new FrameworkSQLiteProgram((SQLiteProgram)param1SQLiteQuery));
      return new SQLiteCursor(param1SQLiteCursorDriver, param1String, param1SQLiteQuery);
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\MagicAI - AI Art & Anime Art-dex2jar.jar!\androidx\sqlite\db\framework\FrameworkSQLiteDatabase.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */