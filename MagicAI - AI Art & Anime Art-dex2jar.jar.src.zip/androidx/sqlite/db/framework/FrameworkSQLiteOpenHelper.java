package androidx.sqlite.db.framework;

import android.content.Context;
import android.database.DatabaseErrorHandler;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.os.Build;
import android.util.Log;
import androidx.annotation.RequiresApi;
import androidx.sqlite.db.SupportSQLiteCompat;
import androidx.sqlite.db.SupportSQLiteDatabase;
import androidx.sqlite.db.SupportSQLiteOpenHelper;
import androidx.sqlite.util.ProcessLock;
import java.io.File;
import java.util.UUID;
import kotlin.Lazy;
import kotlin.LazyKt;
import kotlin.Metadata;
import kotlin.jvm.functions.Function0;
import kotlin.jvm.internal.DefaultConstructorMarker;
import kotlin.jvm.internal.Intrinsics;
import kotlin.jvm.internal.Lambda;

@Metadata(d1 = {"\000B\n\002\030\002\n\002\030\002\n\000\n\002\030\002\n\000\n\002\020\016\n\000\n\002\030\002\n\000\n\002\020\013\n\002\b\006\n\002\030\002\n\002\b\005\n\002\030\002\n\000\n\002\030\002\n\002\b\006\n\002\020\002\n\002\b\006\b\000\030\000 \"2\0020\001:\003\"#$B5\b\007\022\006\020\002\032\0020\003\022\b\020\004\032\004\030\0010\005\022\006\020\006\032\0020\007\022\b\b\002\020\b\032\0020\t\022\b\b\002\020\n\032\0020\t¢\006\002\020\013J\b\020\036\032\0020\037H\026J\020\020 \032\0020\0372\006\020!\032\0020\tH\027R\016\020\n\032\0020\tX\004¢\006\002\n\000R\016\020\006\032\0020\007X\004¢\006\002\n\000R\016\020\002\032\0020\003X\004¢\006\002\n\000R\026\020\f\032\004\030\0010\0058VX\004¢\006\006\032\004\b\r\020\016R\033\020\017\032\0020\0208BX\002¢\006\f\032\004\b\023\020\024*\004\b\021\020\022R\024\020\025\032\b\022\004\022\0020\0200\026X\004¢\006\002\n\000R\020\020\004\032\004\030\0010\005X\004¢\006\002\n\000R\024\020\027\032\0020\0308VX\004¢\006\006\032\004\b\031\020\032R\016\020\b\032\0020\tX\004¢\006\002\n\000R\024\020\033\032\0020\0308VX\004¢\006\006\032\004\b\034\020\032R\016\020\035\032\0020\tX\016¢\006\002\n\000¨\006%"}, d2 = {"Landroidx/sqlite/db/framework/FrameworkSQLiteOpenHelper;", "Landroidx/sqlite/db/SupportSQLiteOpenHelper;", "context", "Landroid/content/Context;", "name", "", "callback", "Landroidx/sqlite/db/SupportSQLiteOpenHelper$Callback;", "useNoBackupDirectory", "", "allowDataLossOnRecovery", "(Landroid/content/Context;Ljava/lang/String;Landroidx/sqlite/db/SupportSQLiteOpenHelper$Callback;ZZ)V", "databaseName", "getDatabaseName", "()Ljava/lang/String;", "delegate", "Landroidx/sqlite/db/framework/FrameworkSQLiteOpenHelper$OpenHelper;", "getDelegate$delegate", "(Landroidx/sqlite/db/framework/FrameworkSQLiteOpenHelper;)Ljava/lang/Object;", "getDelegate", "()Landroidx/sqlite/db/framework/FrameworkSQLiteOpenHelper$OpenHelper;", "lazyDelegate", "Lkotlin/Lazy;", "readableDatabase", "Landroidx/sqlite/db/SupportSQLiteDatabase;", "getReadableDatabase", "()Landroidx/sqlite/db/SupportSQLiteDatabase;", "writableDatabase", "getWritableDatabase", "writeAheadLoggingEnabled", "close", "", "setWriteAheadLoggingEnabled", "enabled", "Companion", "DBRefHolder", "OpenHelper", "sqlite-framework_release"}, k = 1, mv = {1, 7, 1}, xi = 48)
public final class FrameworkSQLiteOpenHelper implements SupportSQLiteOpenHelper {
  public static final Companion Companion = new Companion(null);
  
  private static final String TAG = "SupportSQLite";
  
  private final boolean allowDataLossOnRecovery;
  
  private final SupportSQLiteOpenHelper.Callback callback;
  
  private final Context context;
  
  private final Lazy<OpenHelper> lazyDelegate;
  
  private final String name;
  
  private final boolean useNoBackupDirectory;
  
  private boolean writeAheadLoggingEnabled;
  
  public FrameworkSQLiteOpenHelper(Context paramContext, String paramString, SupportSQLiteOpenHelper.Callback paramCallback) {
    this(paramContext, paramString, paramCallback, false, false, 24, null);
  }
  
  public FrameworkSQLiteOpenHelper(Context paramContext, String paramString, SupportSQLiteOpenHelper.Callback paramCallback, boolean paramBoolean) {
    this(paramContext, paramString, paramCallback, paramBoolean, false, 16, null);
  }
  
  public FrameworkSQLiteOpenHelper(Context paramContext, String paramString, SupportSQLiteOpenHelper.Callback paramCallback, boolean paramBoolean1, boolean paramBoolean2) {
    this.context = paramContext;
    this.name = paramString;
    this.callback = paramCallback;
    this.useNoBackupDirectory = paramBoolean1;
    this.allowDataLossOnRecovery = paramBoolean2;
    this.lazyDelegate = LazyKt.lazy(new FrameworkSQLiteOpenHelper$lazyDelegate$1());
  }
  
  private final OpenHelper getDelegate() {
    return (OpenHelper)this.lazyDelegate.getValue();
  }
  
  private static Object getDelegate$delegate(FrameworkSQLiteOpenHelper paramFrameworkSQLiteOpenHelper) {
    return paramFrameworkSQLiteOpenHelper.lazyDelegate;
  }
  
  public void close() {
    if (this.lazyDelegate.isInitialized())
      getDelegate().close(); 
  }
  
  public String getDatabaseName() {
    return this.name;
  }
  
  public SupportSQLiteDatabase getReadableDatabase() {
    return getDelegate().getSupportDatabase(false);
  }
  
  public SupportSQLiteDatabase getWritableDatabase() {
    return getDelegate().getSupportDatabase(true);
  }
  
  @RequiresApi(api = 16)
  public void setWriteAheadLoggingEnabled(boolean paramBoolean) {
    if (this.lazyDelegate.isInitialized())
      SupportSQLiteCompat.Api16Impl.setWriteAheadLoggingEnabled(getDelegate(), paramBoolean); 
    this.writeAheadLoggingEnabled = paramBoolean;
  }
  
  @Metadata(d1 = {"\000\022\n\002\030\002\n\002\020\000\n\002\b\002\n\002\020\016\n\000\b\003\030\0002\0020\001B\007\b\002¢\006\002\020\002R\016\020\003\032\0020\004XT¢\006\002\n\000¨\006\005"}, d2 = {"Landroidx/sqlite/db/framework/FrameworkSQLiteOpenHelper$Companion;", "", "()V", "TAG", "", "sqlite-framework_release"}, k = 1, mv = {1, 7, 1}, xi = 48)
  public static final class Companion {
    private Companion() {}
  }
  
  @Metadata(d1 = {"\000\022\n\002\030\002\n\002\020\000\n\000\n\002\030\002\n\002\b\005\b\002\030\0002\0020\001B\017\022\b\020\002\032\004\030\0010\003¢\006\002\020\004R\034\020\002\032\004\030\0010\003X\016¢\006\016\n\000\032\004\b\005\020\006\"\004\b\007\020\004¨\006\b"}, d2 = {"Landroidx/sqlite/db/framework/FrameworkSQLiteOpenHelper$DBRefHolder;", "", "db", "Landroidx/sqlite/db/framework/FrameworkSQLiteDatabase;", "(Landroidx/sqlite/db/framework/FrameworkSQLiteDatabase;)V", "getDb", "()Landroidx/sqlite/db/framework/FrameworkSQLiteDatabase;", "setDb", "sqlite-framework_release"}, k = 1, mv = {1, 7, 1}, xi = 48)
  private static final class DBRefHolder {
    private FrameworkSQLiteDatabase db;
    
    public DBRefHolder(FrameworkSQLiteDatabase param1FrameworkSQLiteDatabase) {
      this.db = param1FrameworkSQLiteDatabase;
    }
    
    public final FrameworkSQLiteDatabase getDb() {
      return this.db;
    }
    
    public final void setDb(FrameworkSQLiteDatabase param1FrameworkSQLiteDatabase) {
      this.db = param1FrameworkSQLiteDatabase;
    }
  }
  
  @Metadata(d1 = {"\000V\n\002\030\002\n\002\030\002\n\000\n\002\030\002\n\000\n\002\020\016\n\000\n\002\030\002\n\000\n\002\030\002\n\000\n\002\020\013\n\002\b\n\n\002\030\002\n\002\b\003\n\002\020\002\n\000\n\002\030\002\n\002\b\002\n\002\030\002\n\000\n\002\030\002\n\002\b\007\n\002\020\b\n\002\b\007\b\002\030\000 /2\0020\001:\003-./B/\022\006\020\002\032\0020\003\022\b\020\004\032\004\030\0010\005\022\006\020\006\032\0020\007\022\006\020\b\032\0020\t\022\006\020\n\032\0020\013¢\006\002\020\fJ\b\020\031\032\0020\032H\026J\016\020\033\032\0020\0342\006\020\035\032\0020\013J\016\020\036\032\0020\0372\006\020 \032\0020!J\020\020\"\032\0020!2\006\020\035\032\0020\013H\002J\020\020#\032\0020!2\006\020\035\032\0020\013H\002J\020\020$\032\0020\0322\006\020%\032\0020!H\026J\020\020&\032\0020\0322\006\020 \032\0020!H\026J \020'\032\0020\0322\006\020%\032\0020!2\006\020(\032\0020)2\006\020*\032\0020)H\026J\020\020+\032\0020\0322\006\020%\032\0020!H\026J \020,\032\0020\0322\006\020 \032\0020!2\006\020(\032\0020)2\006\020*\032\0020)H\026R\021\020\n\032\0020\013¢\006\b\n\000\032\004\b\r\020\016R\021\020\b\032\0020\t¢\006\b\n\000\032\004\b\017\020\020R\021\020\002\032\0020\003¢\006\b\n\000\032\004\b\021\020\022R\021\020\006\032\0020\007¢\006\b\n\000\032\004\b\023\020\024R\016\020\025\032\0020\026X\004¢\006\002\n\000R\016\020\027\032\0020\013X\016¢\006\002\n\000R\016\020\030\032\0020\013X\016¢\006\002\n\000¨\0060"}, d2 = {"Landroidx/sqlite/db/framework/FrameworkSQLiteOpenHelper$OpenHelper;", "Landroid/database/sqlite/SQLiteOpenHelper;", "context", "Landroid/content/Context;", "name", "", "dbRef", "Landroidx/sqlite/db/framework/FrameworkSQLiteOpenHelper$DBRefHolder;", "callback", "Landroidx/sqlite/db/SupportSQLiteOpenHelper$Callback;", "allowDataLossOnRecovery", "", "(Landroid/content/Context;Ljava/lang/String;Landroidx/sqlite/db/framework/FrameworkSQLiteOpenHelper$DBRefHolder;Landroidx/sqlite/db/SupportSQLiteOpenHelper$Callback;Z)V", "getAllowDataLossOnRecovery", "()Z", "getCallback", "()Landroidx/sqlite/db/SupportSQLiteOpenHelper$Callback;", "getContext", "()Landroid/content/Context;", "getDbRef", "()Landroidx/sqlite/db/framework/FrameworkSQLiteOpenHelper$DBRefHolder;", "lock", "Landroidx/sqlite/util/ProcessLock;", "migrated", "opened", "close", "", "getSupportDatabase", "Landroidx/sqlite/db/SupportSQLiteDatabase;", "writable", "getWrappedDb", "Landroidx/sqlite/db/framework/FrameworkSQLiteDatabase;", "sqLiteDatabase", "Landroid/database/sqlite/SQLiteDatabase;", "getWritableOrReadableDatabase", "innerGetDatabase", "onConfigure", "db", "onCreate", "onDowngrade", "oldVersion", "", "newVersion", "onOpen", "onUpgrade", "CallbackException", "CallbackName", "Companion", "sqlite-framework_release"}, k = 1, mv = {1, 7, 1}, xi = 48)
  private static final class OpenHelper extends SQLiteOpenHelper {
    public static final Companion Companion = new Companion(null);
    
    private final boolean allowDataLossOnRecovery;
    
    private final SupportSQLiteOpenHelper.Callback callback;
    
    private final Context context;
    
    private final FrameworkSQLiteOpenHelper.DBRefHolder dbRef;
    
    private final ProcessLock lock;
    
    private boolean migrated;
    
    private boolean opened;
    
    public OpenHelper(Context param1Context, String param1String, FrameworkSQLiteOpenHelper.DBRefHolder param1DBRefHolder, SupportSQLiteOpenHelper.Callback param1Callback, boolean param1Boolean) {
      super(param1Context, param1String, null, param1Callback.version, (DatabaseErrorHandler)new FrameworkSQLiteOpenHelper$OpenHelper$.ExternalSyntheticLambda0(param1Callback, param1DBRefHolder));
      this.context = param1Context;
      this.dbRef = param1DBRefHolder;
      this.callback = param1Callback;
      this.allowDataLossOnRecovery = param1Boolean;
      String str = param1String;
      if (param1String == null) {
        str = UUID.randomUUID().toString();
        Intrinsics.checkNotNullExpressionValue(str, "randomUUID().toString()");
      } 
      File file = param1Context.getCacheDir();
      Intrinsics.checkNotNullExpressionValue(file, "context.cacheDir");
      this.lock = new ProcessLock(str, file, false);
    }
    
    private static final void _init_$lambda$0(SupportSQLiteOpenHelper.Callback param1Callback, FrameworkSQLiteOpenHelper.DBRefHolder param1DBRefHolder, SQLiteDatabase param1SQLiteDatabase) {
      Intrinsics.checkNotNullParameter(param1Callback, "$callback");
      Intrinsics.checkNotNullParameter(param1DBRefHolder, "$dbRef");
      Companion companion = Companion;
      Intrinsics.checkNotNullExpressionValue(param1SQLiteDatabase, "dbObj");
      param1Callback.onCorruption(companion.getWrappedDb(param1DBRefHolder, param1SQLiteDatabase));
    }
    
    private final SQLiteDatabase getWritableOrReadableDatabase(boolean param1Boolean) {
      if (param1Boolean) {
        SQLiteDatabase sQLiteDatabase1 = getWritableDatabase();
        Intrinsics.checkNotNullExpressionValue(sQLiteDatabase1, "{\n                super.…eDatabase()\n            }");
        return sQLiteDatabase1;
      } 
      SQLiteDatabase sQLiteDatabase = getReadableDatabase();
      Intrinsics.checkNotNullExpressionValue(sQLiteDatabase, "{\n                super.…eDatabase()\n            }");
      return sQLiteDatabase;
    }
    
    private final SQLiteDatabase innerGetDatabase(boolean param1Boolean) {
      String str = getDatabaseName();
      if (str != null) {
        File file = this.context.getDatabasePath(str).getParentFile();
        if (file != null) {
          file.mkdirs();
          if (!file.isDirectory()) {
            StringBuilder stringBuilder = new StringBuilder();
            stringBuilder.append("Invalid database parent file, not a directory: ");
            stringBuilder.append(file);
            Log.w("SupportSQLite", stringBuilder.toString());
          } 
        } 
      } 
      try {
        return getWritableOrReadableDatabase(param1Boolean);
      } finally {
        Exception exception = null;
        super.close();
        try {
          Thread.sleep(500L);
        } catch (InterruptedException interruptedException) {}
      } 
    }
    
    public void close() {
      try {
        ProcessLock.lock$default(this.lock, false, 1, null);
        super.close();
        this.dbRef.setDb(null);
        this.opened = false;
        return;
      } finally {
        this.lock.unlock();
      } 
    }
    
    public final boolean getAllowDataLossOnRecovery() {
      return this.allowDataLossOnRecovery;
    }
    
    public final SupportSQLiteOpenHelper.Callback getCallback() {
      return this.callback;
    }
    
    public final Context getContext() {
      return this.context;
    }
    
    public final FrameworkSQLiteOpenHelper.DBRefHolder getDbRef() {
      return this.dbRef;
    }
    
    public final SupportSQLiteDatabase getSupportDatabase(boolean param1Boolean) {
      try {
        boolean bool;
        ProcessLock processLock = this.lock;
        if (!this.opened && getDatabaseName() != null) {
          bool = true;
        } else {
          bool = false;
        } 
        processLock.lock(bool);
        this.migrated = false;
        SQLiteDatabase sQLiteDatabase = innerGetDatabase(param1Boolean);
        if (this.migrated) {
          close();
          supportSQLiteDatabase = getSupportDatabase(param1Boolean);
          return supportSQLiteDatabase;
        } 
        SupportSQLiteDatabase supportSQLiteDatabase = getWrappedDb((SQLiteDatabase)supportSQLiteDatabase);
        return supportSQLiteDatabase;
      } finally {
        this.lock.unlock();
      } 
    }
    
    public final FrameworkSQLiteDatabase getWrappedDb(SQLiteDatabase param1SQLiteDatabase) {
      Intrinsics.checkNotNullParameter(param1SQLiteDatabase, "sqLiteDatabase");
      return Companion.getWrappedDb(this.dbRef, param1SQLiteDatabase);
    }
    
    public void onConfigure(SQLiteDatabase param1SQLiteDatabase) {
      Intrinsics.checkNotNullParameter(param1SQLiteDatabase, "db");
      try {
        return;
      } finally {
        param1SQLiteDatabase = null;
      } 
    }
    
    public void onCreate(SQLiteDatabase param1SQLiteDatabase) {
      Intrinsics.checkNotNullParameter(param1SQLiteDatabase, "sqLiteDatabase");
      try {
        return;
      } finally {
        param1SQLiteDatabase = null;
      } 
    }
    
    public void onDowngrade(SQLiteDatabase param1SQLiteDatabase, int param1Int1, int param1Int2) {
      Intrinsics.checkNotNullParameter(param1SQLiteDatabase, "db");
      this.migrated = true;
      try {
        return;
      } finally {
        param1SQLiteDatabase = null;
      } 
    }
    
    public void onOpen(SQLiteDatabase param1SQLiteDatabase) {
      Intrinsics.checkNotNullParameter(param1SQLiteDatabase, "db");
      if (!this.migrated)
        try {
          this.callback.onOpen(getWrappedDb(param1SQLiteDatabase));
        } finally {
          param1SQLiteDatabase = null;
        }  
      this.opened = true;
    }
    
    public void onUpgrade(SQLiteDatabase param1SQLiteDatabase, int param1Int1, int param1Int2) {
      Intrinsics.checkNotNullParameter(param1SQLiteDatabase, "sqLiteDatabase");
      this.migrated = true;
      try {
        return;
      } finally {
        param1SQLiteDatabase = null;
      } 
    }
    
    @Metadata(d1 = {"\000\034\n\002\030\002\n\002\030\002\n\002\030\002\n\000\n\002\030\002\n\000\n\002\020\003\n\002\b\006\b\002\030\0002\0060\001j\002`\002B\025\022\006\020\003\032\0020\004\022\006\020\005\032\0020\006¢\006\002\020\007R\021\020\003\032\0020\004¢\006\b\n\000\032\004\b\b\020\tR\024\020\005\032\0020\006X\004¢\006\b\n\000\032\004\b\n\020\013¨\006\f"}, d2 = {"Landroidx/sqlite/db/framework/FrameworkSQLiteOpenHelper$OpenHelper$CallbackException;", "Ljava/lang/RuntimeException;", "Lkotlin/RuntimeException;", "callbackName", "Landroidx/sqlite/db/framework/FrameworkSQLiteOpenHelper$OpenHelper$CallbackName;", "cause", "", "(Landroidx/sqlite/db/framework/FrameworkSQLiteOpenHelper$OpenHelper$CallbackName;Ljava/lang/Throwable;)V", "getCallbackName", "()Landroidx/sqlite/db/framework/FrameworkSQLiteOpenHelper$OpenHelper$CallbackName;", "getCause", "()Ljava/lang/Throwable;", "sqlite-framework_release"}, k = 1, mv = {1, 7, 1}, xi = 48)
    private static final class CallbackException extends RuntimeException {
      private final FrameworkSQLiteOpenHelper.OpenHelper.CallbackName callbackName;
      
      private final Throwable cause;
      
      public CallbackException(FrameworkSQLiteOpenHelper.OpenHelper.CallbackName param2CallbackName, Throwable param2Throwable) {
        super(param2Throwable);
        this.callbackName = param2CallbackName;
        this.cause = param2Throwable;
      }
      
      public final FrameworkSQLiteOpenHelper.OpenHelper.CallbackName getCallbackName() {
        return this.callbackName;
      }
      
      public Throwable getCause() {
        return this.cause;
      }
    }
    
    @Metadata(d1 = {"\000\f\n\002\030\002\n\002\020\020\n\002\b\007\b\001\030\0002\b\022\004\022\0020\0000\001B\007\b\002¢\006\002\020\002j\002\b\003j\002\b\004j\002\b\005j\002\b\006j\002\b\007¨\006\b"}, d2 = {"Landroidx/sqlite/db/framework/FrameworkSQLiteOpenHelper$OpenHelper$CallbackName;", "", "(Ljava/lang/String;I)V", "ON_CONFIGURE", "ON_CREATE", "ON_UPGRADE", "ON_DOWNGRADE", "ON_OPEN", "sqlite-framework_release"}, k = 1, mv = {1, 7, 1}, xi = 48)
    public enum CallbackName {
      ON_CONFIGURE, ON_CREATE, ON_DOWNGRADE, ON_OPEN, ON_UPGRADE;
      
      static {
      
      }
    }
    
    @Metadata(d1 = {"\000\036\n\002\030\002\n\002\020\000\n\002\b\002\n\002\030\002\n\000\n\002\030\002\n\000\n\002\030\002\n\000\b\003\030\0002\0020\001B\007\b\002¢\006\002\020\002J\026\020\003\032\0020\0042\006\020\005\032\0020\0062\006\020\007\032\0020\b¨\006\t"}, d2 = {"Landroidx/sqlite/db/framework/FrameworkSQLiteOpenHelper$OpenHelper$Companion;", "", "()V", "getWrappedDb", "Landroidx/sqlite/db/framework/FrameworkSQLiteDatabase;", "refHolder", "Landroidx/sqlite/db/framework/FrameworkSQLiteOpenHelper$DBRefHolder;", "sqLiteDatabase", "Landroid/database/sqlite/SQLiteDatabase;", "sqlite-framework_release"}, k = 1, mv = {1, 7, 1}, xi = 48)
    public static final class Companion {
      private Companion() {}
      
      public final FrameworkSQLiteDatabase getWrappedDb(FrameworkSQLiteOpenHelper.DBRefHolder param2DBRefHolder, SQLiteDatabase param2SQLiteDatabase) {
        Intrinsics.checkNotNullParameter(param2DBRefHolder, "refHolder");
        Intrinsics.checkNotNullParameter(param2SQLiteDatabase, "sqLiteDatabase");
        FrameworkSQLiteDatabase frameworkSQLiteDatabase2 = param2DBRefHolder.getDb();
        if (frameworkSQLiteDatabase2 != null) {
          FrameworkSQLiteDatabase frameworkSQLiteDatabase = frameworkSQLiteDatabase2;
          if (!frameworkSQLiteDatabase2.isDelegate(param2SQLiteDatabase)) {
            frameworkSQLiteDatabase = new FrameworkSQLiteDatabase(param2SQLiteDatabase);
            param2DBRefHolder.setDb(frameworkSQLiteDatabase);
            return frameworkSQLiteDatabase;
          } 
          return frameworkSQLiteDatabase;
        } 
        FrameworkSQLiteDatabase frameworkSQLiteDatabase1 = new FrameworkSQLiteDatabase(param2SQLiteDatabase);
        param2DBRefHolder.setDb(frameworkSQLiteDatabase1);
        return frameworkSQLiteDatabase1;
      }
    }
  }
  
  @Metadata(d1 = {"\000\034\n\002\030\002\n\002\030\002\n\002\030\002\n\000\n\002\030\002\n\000\n\002\020\003\n\002\b\006\b\002\030\0002\0060\001j\002`\002B\025\022\006\020\003\032\0020\004\022\006\020\005\032\0020\006¢\006\002\020\007R\021\020\003\032\0020\004¢\006\b\n\000\032\004\b\b\020\tR\024\020\005\032\0020\006X\004¢\006\b\n\000\032\004\b\n\020\013¨\006\f"}, d2 = {"Landroidx/sqlite/db/framework/FrameworkSQLiteOpenHelper$OpenHelper$CallbackException;", "Ljava/lang/RuntimeException;", "Lkotlin/RuntimeException;", "callbackName", "Landroidx/sqlite/db/framework/FrameworkSQLiteOpenHelper$OpenHelper$CallbackName;", "cause", "", "(Landroidx/sqlite/db/framework/FrameworkSQLiteOpenHelper$OpenHelper$CallbackName;Ljava/lang/Throwable;)V", "getCallbackName", "()Landroidx/sqlite/db/framework/FrameworkSQLiteOpenHelper$OpenHelper$CallbackName;", "getCause", "()Ljava/lang/Throwable;", "sqlite-framework_release"}, k = 1, mv = {1, 7, 1}, xi = 48)
  private static final class CallbackException extends RuntimeException {
    private final FrameworkSQLiteOpenHelper.OpenHelper.CallbackName callbackName;
    
    private final Throwable cause;
    
    public CallbackException(FrameworkSQLiteOpenHelper.OpenHelper.CallbackName param1CallbackName, Throwable param1Throwable) {
      super(param1Throwable);
      this.callbackName = param1CallbackName;
      this.cause = param1Throwable;
    }
    
    public final FrameworkSQLiteOpenHelper.OpenHelper.CallbackName getCallbackName() {
      return this.callbackName;
    }
    
    public Throwable getCause() {
      return this.cause;
    }
  }
  
  @Metadata(d1 = {"\000\f\n\002\030\002\n\002\020\020\n\002\b\007\b\001\030\0002\b\022\004\022\0020\0000\001B\007\b\002¢\006\002\020\002j\002\b\003j\002\b\004j\002\b\005j\002\b\006j\002\b\007¨\006\b"}, d2 = {"Landroidx/sqlite/db/framework/FrameworkSQLiteOpenHelper$OpenHelper$CallbackName;", "", "(Ljava/lang/String;I)V", "ON_CONFIGURE", "ON_CREATE", "ON_UPGRADE", "ON_DOWNGRADE", "ON_OPEN", "sqlite-framework_release"}, k = 1, mv = {1, 7, 1}, xi = 48)
  public enum CallbackName {
    ON_CONFIGURE, ON_CREATE, ON_DOWNGRADE, ON_OPEN, ON_UPGRADE;
    
    static {
      $VALUES = $values();
    }
  }
  
  @Metadata(d1 = {"\000\036\n\002\030\002\n\002\020\000\n\002\b\002\n\002\030\002\n\000\n\002\030\002\n\000\n\002\030\002\n\000\b\003\030\0002\0020\001B\007\b\002¢\006\002\020\002J\026\020\003\032\0020\0042\006\020\005\032\0020\0062\006\020\007\032\0020\b¨\006\t"}, d2 = {"Landroidx/sqlite/db/framework/FrameworkSQLiteOpenHelper$OpenHelper$Companion;", "", "()V", "getWrappedDb", "Landroidx/sqlite/db/framework/FrameworkSQLiteDatabase;", "refHolder", "Landroidx/sqlite/db/framework/FrameworkSQLiteOpenHelper$DBRefHolder;", "sqLiteDatabase", "Landroid/database/sqlite/SQLiteDatabase;", "sqlite-framework_release"}, k = 1, mv = {1, 7, 1}, xi = 48)
  public static final class Companion {
    private Companion() {}
    
    public final FrameworkSQLiteDatabase getWrappedDb(FrameworkSQLiteOpenHelper.DBRefHolder param1DBRefHolder, SQLiteDatabase param1SQLiteDatabase) {
      Intrinsics.checkNotNullParameter(param1DBRefHolder, "refHolder");
      Intrinsics.checkNotNullParameter(param1SQLiteDatabase, "sqLiteDatabase");
      FrameworkSQLiteDatabase frameworkSQLiteDatabase2 = param1DBRefHolder.getDb();
      if (frameworkSQLiteDatabase2 != null) {
        FrameworkSQLiteDatabase frameworkSQLiteDatabase = frameworkSQLiteDatabase2;
        if (!frameworkSQLiteDatabase2.isDelegate(param1SQLiteDatabase)) {
          frameworkSQLiteDatabase = new FrameworkSQLiteDatabase(param1SQLiteDatabase);
          param1DBRefHolder.setDb(frameworkSQLiteDatabase);
          return frameworkSQLiteDatabase;
        } 
        return frameworkSQLiteDatabase;
      } 
      FrameworkSQLiteDatabase frameworkSQLiteDatabase1 = new FrameworkSQLiteDatabase(param1SQLiteDatabase);
      param1DBRefHolder.setDb(frameworkSQLiteDatabase1);
      return frameworkSQLiteDatabase1;
    }
  }
  
  @Metadata(d1 = {"\000\b\n\000\n\002\030\002\n\000\020\000\032\0020\001H\n¢\006\002\b\002"}, d2 = {"<anonymous>", "Landroidx/sqlite/db/framework/FrameworkSQLiteOpenHelper$OpenHelper;", "invoke"}, k = 3, mv = {1, 7, 1}, xi = 48)
  static final class FrameworkSQLiteOpenHelper$lazyDelegate$1 extends Lambda implements Function0<OpenHelper> {
    FrameworkSQLiteOpenHelper$lazyDelegate$1() {
      super(0);
    }
    
    public final FrameworkSQLiteOpenHelper.OpenHelper invoke() {
      FrameworkSQLiteOpenHelper.OpenHelper openHelper;
      if (Build.VERSION.SDK_INT >= 23 && FrameworkSQLiteOpenHelper.this.name != null && FrameworkSQLiteOpenHelper.this.useNoBackupDirectory) {
        File file = new File(SupportSQLiteCompat.Api21Impl.getNoBackupFilesDir(FrameworkSQLiteOpenHelper.this.context), FrameworkSQLiteOpenHelper.this.name);
        openHelper = new FrameworkSQLiteOpenHelper.OpenHelper(FrameworkSQLiteOpenHelper.this.context, file.getAbsolutePath(), new FrameworkSQLiteOpenHelper.DBRefHolder(null), FrameworkSQLiteOpenHelper.this.callback, FrameworkSQLiteOpenHelper.this.allowDataLossOnRecovery);
      } else {
        openHelper = new FrameworkSQLiteOpenHelper.OpenHelper(FrameworkSQLiteOpenHelper.this.context, FrameworkSQLiteOpenHelper.this.name, new FrameworkSQLiteOpenHelper.DBRefHolder(null), FrameworkSQLiteOpenHelper.this.callback, FrameworkSQLiteOpenHelper.this.allowDataLossOnRecovery);
      } 
      SupportSQLiteCompat.Api16Impl.setWriteAheadLoggingEnabled(openHelper, FrameworkSQLiteOpenHelper.this.writeAheadLoggingEnabled);
      return openHelper;
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\MagicAI - AI Art & Anime Art-dex2jar.jar!\androidx\sqlite\db\framework\FrameworkSQLiteOpenHelper.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */