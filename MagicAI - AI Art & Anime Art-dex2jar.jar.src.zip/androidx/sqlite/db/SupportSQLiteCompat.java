package androidx.sqlite.db;

import android.app.ActivityManager;
import android.content.ContentResolver;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.net.Uri;
import android.os.Bundle;
import android.os.CancellationSignal;
import androidx.annotation.RequiresApi;
import androidx.annotation.RestrictTo;
import java.io.File;
import java.util.List;
import kotlin.Metadata;
import kotlin.jvm.internal.Intrinsics;

@Metadata(d1 = {"\000\f\n\002\030\002\n\002\020\000\n\002\b\007\b\007\030\0002\0020\001:\005\003\004\005\006\007B\007\b\002¢\006\002\020\002¨\006\b"}, d2 = {"Landroidx/sqlite/db/SupportSQLiteCompat;", "", "()V", "Api16Impl", "Api19Impl", "Api21Impl", "Api23Impl", "Api29Impl", "sqlite_release"}, k = 1, mv = {1, 7, 1}, xi = 48)
@RestrictTo({RestrictTo.Scope.LIBRARY_GROUP})
public final class SupportSQLiteCompat {
  @Metadata(d1 = {"\000T\n\002\030\002\n\002\020\000\n\002\b\002\n\002\020\002\n\000\n\002\030\002\n\002\b\002\n\002\020\013\n\000\n\002\030\002\n\002\b\002\n\002\030\002\n\002\b\002\n\002\030\002\n\000\n\002\020\016\n\000\n\002\020\021\n\002\b\002\n\002\030\002\n\002\b\005\n\002\030\002\n\002\b\002\bÇ\002\030\0002\0020\001B\007\b\002¢\006\002\020\002J\020\020\003\032\0020\0042\006\020\005\032\0020\006H\007J\b\020\007\032\0020\006H\007J\020\020\b\032\0020\t2\006\020\n\032\0020\013H\007J\020\020\f\032\0020\0042\006\020\r\032\0020\016H\007J\020\020\017\032\0020\t2\006\020\r\032\0020\016H\007JI\020\020\032\0020\0212\006\020\r\032\0020\0162\006\020\022\032\0020\0232\020\020\024\032\f\022\b\b\001\022\004\030\0010\0230\0252\b\020\026\032\004\030\0010\0232\006\020\005\032\0020\0062\006\020\027\032\0020\030H\007¢\006\002\020\031J\030\020\032\032\0020\0042\006\020\r\032\0020\0162\006\020\033\032\0020\tH\007J\030\020\034\032\0020\0042\006\020\035\032\0020\0362\006\020\037\032\0020\tH\007¨\006 "}, d2 = {"Landroidx/sqlite/db/SupportSQLiteCompat$Api16Impl;", "", "()V", "cancel", "", "cancellationSignal", "Landroid/os/CancellationSignal;", "createCancellationSignal", "deleteDatabase", "", "file", "Ljava/io/File;", "disableWriteAheadLogging", "sQLiteDatabase", "Landroid/database/sqlite/SQLiteDatabase;", "isWriteAheadLoggingEnabled", "rawQueryWithFactory", "Landroid/database/Cursor;", "sql", "", "selectionArgs", "", "editTable", "cursorFactory", "Landroid/database/sqlite/SQLiteDatabase$CursorFactory;", "(Landroid/database/sqlite/SQLiteDatabase;Ljava/lang/String;[Ljava/lang/String;Ljava/lang/String;Landroid/os/CancellationSignal;Landroid/database/sqlite/SQLiteDatabase$CursorFactory;)Landroid/database/Cursor;", "setForeignKeyConstraintsEnabled", "enable", "setWriteAheadLoggingEnabled", "sQLiteOpenHelper", "Landroid/database/sqlite/SQLiteOpenHelper;", "enabled", "sqlite_release"}, k = 1, mv = {1, 7, 1}, xi = 48)
  @RequiresApi(16)
  @RestrictTo({RestrictTo.Scope.LIBRARY_GROUP})
  public static final class Api16Impl {
    public static final Api16Impl INSTANCE = new Api16Impl();
    
    @RestrictTo({RestrictTo.Scope.LIBRARY_GROUP})
    public static final void cancel(CancellationSignal param1CancellationSignal) {
      Intrinsics.checkNotNullParameter(param1CancellationSignal, "cancellationSignal");
      param1CancellationSignal.cancel();
    }
    
    @RestrictTo({RestrictTo.Scope.LIBRARY_GROUP})
    public static final CancellationSignal createCancellationSignal() {
      return new CancellationSignal();
    }
    
    @RestrictTo({RestrictTo.Scope.LIBRARY_GROUP})
    public static final boolean deleteDatabase(File param1File) {
      Intrinsics.checkNotNullParameter(param1File, "file");
      return SQLiteDatabase.deleteDatabase(param1File);
    }
    
    @RestrictTo({RestrictTo.Scope.LIBRARY_GROUP})
    public static final void disableWriteAheadLogging(SQLiteDatabase param1SQLiteDatabase) {
      Intrinsics.checkNotNullParameter(param1SQLiteDatabase, "sQLiteDatabase");
      param1SQLiteDatabase.disableWriteAheadLogging();
    }
    
    @RestrictTo({RestrictTo.Scope.LIBRARY_GROUP})
    public static final boolean isWriteAheadLoggingEnabled(SQLiteDatabase param1SQLiteDatabase) {
      Intrinsics.checkNotNullParameter(param1SQLiteDatabase, "sQLiteDatabase");
      return param1SQLiteDatabase.isWriteAheadLoggingEnabled();
    }
    
    @RestrictTo({RestrictTo.Scope.LIBRARY_GROUP})
    public static final Cursor rawQueryWithFactory(SQLiteDatabase param1SQLiteDatabase, String param1String1, String[] param1ArrayOfString, String param1String2, CancellationSignal param1CancellationSignal, SQLiteDatabase.CursorFactory param1CursorFactory) {
      Intrinsics.checkNotNullParameter(param1SQLiteDatabase, "sQLiteDatabase");
      Intrinsics.checkNotNullParameter(param1String1, "sql");
      Intrinsics.checkNotNullParameter(param1ArrayOfString, "selectionArgs");
      Intrinsics.checkNotNullParameter(param1CancellationSignal, "cancellationSignal");
      Intrinsics.checkNotNullParameter(param1CursorFactory, "cursorFactory");
      Cursor cursor = param1SQLiteDatabase.rawQueryWithFactory(param1CursorFactory, param1String1, param1ArrayOfString, param1String2, param1CancellationSignal);
      Intrinsics.checkNotNullExpressionValue(cursor, "sQLiteDatabase.rawQueryW…ationSignal\n            )");
      return cursor;
    }
    
    @RestrictTo({RestrictTo.Scope.LIBRARY_GROUP})
    public static final void setForeignKeyConstraintsEnabled(SQLiteDatabase param1SQLiteDatabase, boolean param1Boolean) {
      Intrinsics.checkNotNullParameter(param1SQLiteDatabase, "sQLiteDatabase");
      param1SQLiteDatabase.setForeignKeyConstraintsEnabled(param1Boolean);
    }
    
    @RestrictTo({RestrictTo.Scope.LIBRARY_GROUP})
    public static final void setWriteAheadLoggingEnabled(SQLiteOpenHelper param1SQLiteOpenHelper, boolean param1Boolean) {
      Intrinsics.checkNotNullParameter(param1SQLiteOpenHelper, "sQLiteOpenHelper");
      param1SQLiteOpenHelper.setWriteAheadLoggingEnabled(param1Boolean);
    }
  }
  
  @Metadata(d1 = {"\000$\n\002\030\002\n\002\020\000\n\002\b\002\n\002\030\002\n\000\n\002\030\002\n\000\n\002\020\013\n\000\n\002\030\002\n\000\bÇ\002\030\0002\0020\001B\007\b\002¢\006\002\020\002J\020\020\003\032\0020\0042\006\020\005\032\0020\006H\007J\020\020\007\032\0020\b2\006\020\t\032\0020\nH\007¨\006\013"}, d2 = {"Landroidx/sqlite/db/SupportSQLiteCompat$Api19Impl;", "", "()V", "getNotificationUri", "Landroid/net/Uri;", "cursor", "Landroid/database/Cursor;", "isLowRamDevice", "", "activityManager", "Landroid/app/ActivityManager;", "sqlite_release"}, k = 1, mv = {1, 7, 1}, xi = 48)
  @RequiresApi(19)
  @RestrictTo({RestrictTo.Scope.LIBRARY_GROUP})
  public static final class Api19Impl {
    public static final Api19Impl INSTANCE = new Api19Impl();
    
    @RestrictTo({RestrictTo.Scope.LIBRARY_GROUP})
    public static final Uri getNotificationUri(Cursor param1Cursor) {
      Intrinsics.checkNotNullParameter(param1Cursor, "cursor");
      Uri uri = param1Cursor.getNotificationUri();
      Intrinsics.checkNotNullExpressionValue(uri, "cursor.notificationUri");
      return uri;
    }
    
    @RestrictTo({RestrictTo.Scope.LIBRARY_GROUP})
    public static final boolean isLowRamDevice(ActivityManager param1ActivityManager) {
      Intrinsics.checkNotNullParameter(param1ActivityManager, "activityManager");
      return param1ActivityManager.isLowRamDevice();
    }
  }
  
  @Metadata(d1 = {"\000\030\n\002\030\002\n\002\020\000\n\002\b\002\n\002\030\002\n\000\n\002\030\002\n\000\bÇ\002\030\0002\0020\001B\007\b\002¢\006\002\020\002J\020\020\003\032\0020\0042\006\020\005\032\0020\006H\007¨\006\007"}, d2 = {"Landroidx/sqlite/db/SupportSQLiteCompat$Api21Impl;", "", "()V", "getNoBackupFilesDir", "Ljava/io/File;", "context", "Landroid/content/Context;", "sqlite_release"}, k = 1, mv = {1, 7, 1}, xi = 48)
  @RequiresApi(21)
  @RestrictTo({RestrictTo.Scope.LIBRARY_GROUP})
  public static final class Api21Impl {
    public static final Api21Impl INSTANCE = new Api21Impl();
    
    @RestrictTo({RestrictTo.Scope.LIBRARY_GROUP})
    public static final File getNoBackupFilesDir(Context param1Context) {
      Intrinsics.checkNotNullParameter(param1Context, "context");
      File file = param1Context.getNoBackupFilesDir();
      Intrinsics.checkNotNullExpressionValue(file, "context.noBackupFilesDir");
      return file;
    }
  }
  
  @Metadata(d1 = {"\000\036\n\002\030\002\n\002\020\000\n\002\b\002\n\002\020\002\n\000\n\002\030\002\n\000\n\002\030\002\n\000\bÇ\002\030\0002\0020\001B\007\b\002¢\006\002\020\002J\030\020\003\032\0020\0042\006\020\005\032\0020\0062\006\020\007\032\0020\bH\007¨\006\t"}, d2 = {"Landroidx/sqlite/db/SupportSQLiteCompat$Api23Impl;", "", "()V", "setExtras", "", "cursor", "Landroid/database/Cursor;", "extras", "Landroid/os/Bundle;", "sqlite_release"}, k = 1, mv = {1, 7, 1}, xi = 48)
  @RequiresApi(23)
  @RestrictTo({RestrictTo.Scope.LIBRARY_GROUP})
  public static final class Api23Impl {
    public static final Api23Impl INSTANCE = new Api23Impl();
    
    @RestrictTo({RestrictTo.Scope.LIBRARY_GROUP})
    public static final void setExtras(Cursor param1Cursor, Bundle param1Bundle) {
      Intrinsics.checkNotNullParameter(param1Cursor, "cursor");
      Intrinsics.checkNotNullParameter(param1Bundle, "extras");
      SupportSQLiteCompat$Api23Impl$.ExternalSyntheticApiModelOutline0.m(param1Cursor, param1Bundle);
    }
  }
  
  @Metadata(d1 = {"\000*\n\002\030\002\n\002\020\000\n\002\b\002\n\002\020 \n\002\030\002\n\000\n\002\030\002\n\000\n\002\020\002\n\000\n\002\030\002\n\002\b\002\bÇ\002\030\0002\0020\001B\007\b\002¢\006\002\020\002J\026\020\003\032\b\022\004\022\0020\0050\0042\006\020\006\032\0020\007H\007J(\020\b\032\0020\t2\006\020\006\032\0020\0072\006\020\n\032\0020\0132\016\020\f\032\n\022\006\022\004\030\0010\0050\004H\007¨\006\r"}, d2 = {"Landroidx/sqlite/db/SupportSQLiteCompat$Api29Impl;", "", "()V", "getNotificationUris", "", "Landroid/net/Uri;", "cursor", "Landroid/database/Cursor;", "setNotificationUris", "", "cr", "Landroid/content/ContentResolver;", "uris", "sqlite_release"}, k = 1, mv = {1, 7, 1}, xi = 48)
  @RequiresApi(29)
  @RestrictTo({RestrictTo.Scope.LIBRARY_GROUP})
  public static final class Api29Impl {
    public static final Api29Impl INSTANCE = new Api29Impl();
    
    @RestrictTo({RestrictTo.Scope.LIBRARY_GROUP})
    public static final List<Uri> getNotificationUris(Cursor param1Cursor) {
      Intrinsics.checkNotNullParameter(param1Cursor, "cursor");
      List<Uri> list = SupportSQLiteCompat$Api29Impl$.ExternalSyntheticApiModelOutline1.m(param1Cursor);
      Intrinsics.checkNotNull(list);
      return list;
    }
    
    @RestrictTo({RestrictTo.Scope.LIBRARY_GROUP})
    public static final void setNotificationUris(Cursor param1Cursor, ContentResolver param1ContentResolver, List<? extends Uri> param1List) {
      Intrinsics.checkNotNullParameter(param1Cursor, "cursor");
      Intrinsics.checkNotNullParameter(param1ContentResolver, "cr");
      Intrinsics.checkNotNullParameter(param1List, "uris");
      SupportSQLiteCompat$Api29Impl$.ExternalSyntheticApiModelOutline0.m(param1Cursor, param1ContentResolver, param1List);
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\MagicAI - AI Art & Anime Art-dex2jar.jar!\androidx\sqlite\db\SupportSQLiteCompat.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */