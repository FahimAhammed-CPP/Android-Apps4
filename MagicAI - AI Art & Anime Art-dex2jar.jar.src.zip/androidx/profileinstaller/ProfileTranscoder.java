package androidx.profileinstaller;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.annotation.RequiresApi;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.BitSet;
import java.util.Iterator;
import java.util.Map;
import java.util.TreeMap;

@RequiresApi(19)
class ProfileTranscoder {
  private static final int HOT = 1;
  
  private static final int INLINE_CACHE_MEGAMORPHIC_ENCODING = 7;
  
  private static final int INLINE_CACHE_MISSING_TYPES_ENCODING = 6;
  
  static final byte[] MAGIC_PROF = new byte[] { 112, 114, 111, 0 };
  
  static final byte[] MAGIC_PROFM = new byte[] { 112, 114, 109, 0 };
  
  private static final int POST_STARTUP = 4;
  
  private static final int STARTUP = 2;
  
  private static int computeMethodFlags(@NonNull DexProfileData paramDexProfileData) {
    Iterator<Map.Entry> iterator = paramDexProfileData.methods.entrySet().iterator();
    int i;
    for (i = 0; iterator.hasNext(); i |= ((Integer)((Map.Entry)iterator.next()).getValue()).intValue());
    return i;
  }
  
  @NonNull
  private static byte[] createCompressibleBody(@NonNull DexProfileData[] paramArrayOfDexProfileData, @NonNull byte[] paramArrayOfbyte) throws IOException {
    int n = paramArrayOfDexProfileData.length;
    int k = 0;
    int m = 0;
    int j = 0;
    int i = 0;
    while (j < n) {
      DexProfileData dexProfileData = paramArrayOfDexProfileData[j];
      i += Encoding.utf8Length(generateDexKey(dexProfileData.apkName, dexProfileData.dexName, paramArrayOfbyte)) + 16 + dexProfileData.classSetSize * 2 + dexProfileData.hotMethodRegionSize + getMethodBitmapStorageSize(dexProfileData.numMethodIds);
      j++;
    } 
    ByteArrayOutputStream byteArrayOutputStream = new ByteArrayOutputStream(i);
    if (Arrays.equals(paramArrayOfbyte, ProfileVersion.V009_O_MR1)) {
      k = paramArrayOfDexProfileData.length;
      for (j = m; j < k; j++) {
        DexProfileData dexProfileData = paramArrayOfDexProfileData[j];
        writeLineHeader(byteArrayOutputStream, dexProfileData, generateDexKey(dexProfileData.apkName, dexProfileData.dexName, paramArrayOfbyte));
        writeLineData(byteArrayOutputStream, dexProfileData);
      } 
    } else {
      m = paramArrayOfDexProfileData.length;
      for (j = 0; j < m; j++) {
        DexProfileData dexProfileData = paramArrayOfDexProfileData[j];
        writeLineHeader(byteArrayOutputStream, dexProfileData, generateDexKey(dexProfileData.apkName, dexProfileData.dexName, paramArrayOfbyte));
      } 
      m = paramArrayOfDexProfileData.length;
      for (j = k; j < m; j++)
        writeLineData(byteArrayOutputStream, paramArrayOfDexProfileData[j]); 
    } 
    if (byteArrayOutputStream.size() == i)
      return byteArrayOutputStream.toByteArray(); 
    StringBuilder stringBuilder = new StringBuilder();
    stringBuilder.append("The bytes saved do not match expectation. actual=");
    stringBuilder.append(byteArrayOutputStream.size());
    stringBuilder.append(" expected=");
    stringBuilder.append(i);
    throw Encoding.error(stringBuilder.toString());
  }
  
  private static WritableFileSection createCompressibleClassSection(@NonNull DexProfileData[] paramArrayOfDexProfileData) throws IOException {
    ByteArrayOutputStream byteArrayOutputStream = new ByteArrayOutputStream();
    int i = 0;
    int j = 0;
    try {
      WritableFileSection writableFileSection;
      while (i < paramArrayOfDexProfileData.length) {
        DexProfileData dexProfileData = paramArrayOfDexProfileData[i];
        Encoding.writeUInt16(byteArrayOutputStream, i);
        Encoding.writeUInt16(byteArrayOutputStream, dexProfileData.classSetSize);
        j = j + 2 + 2 + dexProfileData.classSetSize * 2;
        writeClasses(byteArrayOutputStream, dexProfileData);
        i++;
      } 
      byte[] arrayOfByte = byteArrayOutputStream.toByteArray();
      if (j == arrayOfByte.length) {
        writableFileSection = new WritableFileSection(FileSectionType.CLASSES, j, arrayOfByte, true);
        return writableFileSection;
      } 
      StringBuilder stringBuilder = new StringBuilder();
      stringBuilder.append("Expected size ");
      stringBuilder.append(j);
      stringBuilder.append(", does not match actual size ");
      stringBuilder.append(writableFileSection.length);
      throw Encoding.error(stringBuilder.toString());
    } finally {
      try {
        byteArrayOutputStream.close();
      } finally {
        byteArrayOutputStream = null;
      } 
    } 
  }
  
  private static WritableFileSection createCompressibleMethodsSection(@NonNull DexProfileData[] paramArrayOfDexProfileData) throws IOException {
    ByteArrayOutputStream byteArrayOutputStream = new ByteArrayOutputStream();
    int i = 0;
    int j = 0;
    try {
      WritableFileSection writableFileSection;
      while (i < paramArrayOfDexProfileData.length) {
        DexProfileData dexProfileData = paramArrayOfDexProfileData[i];
        int k = computeMethodFlags(dexProfileData);
        byte[] arrayOfByte1 = createMethodBitmapRegion(dexProfileData);
        byte[] arrayOfByte2 = createMethodsWithInlineCaches(dexProfileData);
        Encoding.writeUInt16(byteArrayOutputStream, i);
        int m = arrayOfByte1.length + 2 + arrayOfByte2.length;
        Encoding.writeUInt32(byteArrayOutputStream, m);
        Encoding.writeUInt16(byteArrayOutputStream, k);
        byteArrayOutputStream.write(arrayOfByte1);
        byteArrayOutputStream.write(arrayOfByte2);
        j = j + 2 + 4 + m;
        i++;
      } 
      byte[] arrayOfByte = byteArrayOutputStream.toByteArray();
      if (j == arrayOfByte.length) {
        writableFileSection = new WritableFileSection(FileSectionType.METHODS, j, arrayOfByte, true);
        return writableFileSection;
      } 
      StringBuilder stringBuilder = new StringBuilder();
      stringBuilder.append("Expected size ");
      stringBuilder.append(j);
      stringBuilder.append(", does not match actual size ");
      stringBuilder.append(writableFileSection.length);
      throw Encoding.error(stringBuilder.toString());
    } finally {
      try {
        byteArrayOutputStream.close();
      } finally {
        byteArrayOutputStream = null;
      } 
    } 
  }
  
  private static byte[] createMethodBitmapRegion(@NonNull DexProfileData paramDexProfileData) throws IOException {
    ByteArrayOutputStream byteArrayOutputStream = new ByteArrayOutputStream();
    try {
      writeMethodBitmap(byteArrayOutputStream, paramDexProfileData);
      return byteArrayOutputStream.toByteArray();
    } finally {
      try {
        byteArrayOutputStream.close();
      } finally {
        byteArrayOutputStream = null;
      } 
    } 
  }
  
  private static byte[] createMethodsWithInlineCaches(@NonNull DexProfileData paramDexProfileData) throws IOException {
    ByteArrayOutputStream byteArrayOutputStream = new ByteArrayOutputStream();
    try {
      writeMethodsWithInlineCaches(byteArrayOutputStream, paramDexProfileData);
      return byteArrayOutputStream.toByteArray();
    } finally {
      try {
        byteArrayOutputStream.close();
      } finally {
        byteArrayOutputStream = null;
      } 
    } 
  }
  
  @NonNull
  private static String enforceSeparator(@NonNull String paramString1, @NonNull String paramString2) {
    if ("!".equals(paramString2))
      return paramString1.replace(":", "!"); 
    String str = paramString1;
    if (":".equals(paramString2))
      str = paramString1.replace("!", ":"); 
    return str;
  }
  
  @NonNull
  private static String extractKey(@NonNull String paramString) {
    int j = paramString.indexOf("!");
    int i = j;
    if (j < 0)
      i = paramString.indexOf(":"); 
    String str = paramString;
    if (i > 0)
      str = paramString.substring(i + 1); 
    return str;
  }
  
  @Nullable
  private static DexProfileData findByDexName(@NonNull DexProfileData[] paramArrayOfDexProfileData, @NonNull String paramString) {
    if (paramArrayOfDexProfileData.length <= 0)
      return null; 
    paramString = extractKey(paramString);
    for (int i = 0; i < paramArrayOfDexProfileData.length; i++) {
      if ((paramArrayOfDexProfileData[i]).dexName.equals(paramString))
        return paramArrayOfDexProfileData[i]; 
    } 
    return null;
  }
  
  @NonNull
  private static String generateDexKey(@NonNull String paramString1, @NonNull String paramString2, @NonNull byte[] paramArrayOfbyte) {
    String str = ProfileVersion.dexKeySeparator(paramArrayOfbyte);
    if (paramString1.length() <= 0)
      return enforceSeparator(paramString2, str); 
    if (paramString2.equals("classes.dex"))
      return paramString1; 
    if (paramString2.contains("!") || paramString2.contains(":"))
      return enforceSeparator(paramString2, str); 
    if (paramString2.endsWith(".apk"))
      return paramString2; 
    StringBuilder stringBuilder = new StringBuilder();
    stringBuilder.append(paramString1);
    stringBuilder.append(ProfileVersion.dexKeySeparator(paramArrayOfbyte));
    stringBuilder.append(paramString2);
    return stringBuilder.toString();
  }
  
  private static int getMethodBitmapStorageSize(int paramInt) {
    return roundUpToByte(paramInt * 2) / 8;
  }
  
  private static int methodFlagBitmapIndex(int paramInt1, int paramInt2, int paramInt3) {
    if (paramInt1 != 1) {
      if (paramInt1 != 2) {
        if (paramInt1 == 4)
          return paramInt2 + paramInt3; 
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("Unexpected flag: ");
        stringBuilder.append(paramInt1);
        throw Encoding.error(stringBuilder.toString());
      } 
      return paramInt2;
    } 
    throw Encoding.error("HOT methods are not stored in the bitmap");
  }
  
  private static int[] readClasses(@NonNull InputStream paramInputStream, int paramInt) throws IOException {
    int[] arrayOfInt = new int[paramInt];
    int i = 0;
    int j = 0;
    while (i < paramInt) {
      j += Encoding.readUInt16(paramInputStream);
      arrayOfInt[i] = j;
      i++;
    } 
    return arrayOfInt;
  }
  
  private static int readFlagsFromBitmap(@NonNull BitSet paramBitSet, int paramInt1, int paramInt2) {
    byte b = 2;
    if (!paramBitSet.get(methodFlagBitmapIndex(2, paramInt1, paramInt2)))
      b = 0; 
    int i = b;
    if (paramBitSet.get(methodFlagBitmapIndex(4, paramInt1, paramInt2)))
      i = b | 0x4; 
    return i;
  }
  
  static byte[] readHeader(@NonNull InputStream paramInputStream, @NonNull byte[] paramArrayOfbyte) throws IOException {
    if (Arrays.equals(paramArrayOfbyte, Encoding.read(paramInputStream, paramArrayOfbyte.length)))
      return Encoding.read(paramInputStream, ProfileVersion.V010_P.length); 
    throw Encoding.error("Invalid magic");
  }
  
  private static void readHotMethodRegion(@NonNull InputStream paramInputStream, @NonNull DexProfileData paramDexProfileData) throws IOException {
    int j = paramInputStream.available() - paramDexProfileData.hotMethodRegionSize;
    int i = 0;
    label13: while (paramInputStream.available() > j) {
      int m = i + Encoding.readUInt16(paramInputStream);
      paramDexProfileData.methods.put(Integer.valueOf(m), Integer.valueOf(1));
      int k = Encoding.readUInt16(paramInputStream);
      while (true) {
        i = m;
        if (k > 0) {
          skipInlineCache(paramInputStream);
          k--;
          continue;
        } 
        continue label13;
      } 
    } 
    if (paramInputStream.available() == j)
      return; 
    throw Encoding.error("Read too much data during profile line parse");
  }
  
  @NonNull
  static DexProfileData[] readMeta(@NonNull InputStream paramInputStream, @NonNull byte[] paramArrayOfbyte1, @NonNull byte[] paramArrayOfbyte2, DexProfileData[] paramArrayOfDexProfileData) throws IOException {
    if (Arrays.equals(paramArrayOfbyte1, ProfileVersion.METADATA_V001_N)) {
      if (!Arrays.equals(ProfileVersion.V015_S, paramArrayOfbyte2))
        return readMetadata001(paramInputStream, paramArrayOfbyte1, paramArrayOfDexProfileData); 
      throw Encoding.error("Requires new Baseline Profile Metadata. Please rebuild the APK with Android Gradle Plugin 7.2 Canary 7 or higher");
    } 
    if (Arrays.equals(paramArrayOfbyte1, ProfileVersion.METADATA_V002))
      return readMetadataV002(paramInputStream, paramArrayOfbyte2, paramArrayOfDexProfileData); 
    throw Encoding.error("Unsupported meta version");
  }
  
  @NonNull
  static DexProfileData[] readMetadata001(@NonNull InputStream paramInputStream, @NonNull byte[] paramArrayOfbyte, DexProfileData[] paramArrayOfDexProfileData) throws IOException {
    if (Arrays.equals(paramArrayOfbyte, ProfileVersion.METADATA_V001_N)) {
      int i = Encoding.readUInt8(paramInputStream);
      long l = Encoding.readUInt32(paramInputStream);
      paramArrayOfbyte = Encoding.readCompressed(paramInputStream, (int)Encoding.readUInt32(paramInputStream), (int)l);
      if (paramInputStream.read() <= 0) {
        paramInputStream = new ByteArrayInputStream(paramArrayOfbyte);
        try {
          return readMetadataForNBody(paramInputStream, i, paramArrayOfDexProfileData);
        } finally {
          try {
            paramInputStream.close();
          } finally {
            paramInputStream = null;
          } 
        } 
      } 
      throw Encoding.error("Content found after the end of file");
    } 
    throw Encoding.error("Unsupported meta version");
  }
  
  @NonNull
  private static DexProfileData[] readMetadataForNBody(@NonNull InputStream paramInputStream, int paramInt, DexProfileData[] paramArrayOfDexProfileData) throws IOException {
    int i = paramInputStream.available();
    byte b = 0;
    if (i == 0)
      return new DexProfileData[0]; 
    if (paramInt == paramArrayOfDexProfileData.length) {
      int j;
      String[] arrayOfString = new String[paramInt];
      int[] arrayOfInt = new int[paramInt];
      i = 0;
      while (true) {
        j = b;
        if (i < paramInt) {
          j = Encoding.readUInt16(paramInputStream);
          arrayOfInt[i] = Encoding.readUInt16(paramInputStream);
          arrayOfString[i] = Encoding.readString(paramInputStream, j);
          i++;
          continue;
        } 
        break;
      } 
      while (j < paramInt) {
        DexProfileData dexProfileData = paramArrayOfDexProfileData[j];
        if (dexProfileData.dexName.equals(arrayOfString[j])) {
          i = arrayOfInt[j];
          dexProfileData.classSetSize = i;
          dexProfileData.classes = readClasses(paramInputStream, i);
          j++;
          continue;
        } 
        throw Encoding.error("Order of dexfiles in metadata did not match baseline");
      } 
      return paramArrayOfDexProfileData;
    } 
    throw Encoding.error("Mismatched number of dex files found in metadata");
  }
  
  @NonNull
  static DexProfileData[] readMetadataV002(@NonNull InputStream paramInputStream, @NonNull byte[] paramArrayOfbyte, DexProfileData[] paramArrayOfDexProfileData) throws IOException {
    int i = Encoding.readUInt16(paramInputStream);
    long l = Encoding.readUInt32(paramInputStream);
    byte[] arrayOfByte = Encoding.readCompressed(paramInputStream, (int)Encoding.readUInt32(paramInputStream), (int)l);
    if (paramInputStream.read() <= 0) {
      paramInputStream = new ByteArrayInputStream(arrayOfByte);
      try {
        return readMetadataV002Body(paramInputStream, paramArrayOfbyte, i, paramArrayOfDexProfileData);
      } finally {
        try {
          paramInputStream.close();
        } finally {
          paramInputStream = null;
        } 
      } 
    } 
    throw Encoding.error("Content found after the end of file");
  }
  
  @NonNull
  private static DexProfileData[] readMetadataV002Body(@NonNull InputStream paramInputStream, @NonNull byte[] paramArrayOfbyte, int paramInt, DexProfileData[] paramArrayOfDexProfileData) throws IOException {
    int j = paramInputStream.available();
    int i = 0;
    if (j == 0)
      return new DexProfileData[0]; 
    if (paramInt == paramArrayOfDexProfileData.length) {
      while (i < paramInt) {
        int[] arrayOfInt;
        Encoding.readUInt16(paramInputStream);
        String str = Encoding.readString(paramInputStream, Encoding.readUInt16(paramInputStream));
        long l = Encoding.readUInt32(paramInputStream);
        j = Encoding.readUInt16(paramInputStream);
        DexProfileData dexProfileData = findByDexName(paramArrayOfDexProfileData, str);
        if (dexProfileData != null) {
          dexProfileData.mTypeIdCount = l;
          arrayOfInt = readClasses(paramInputStream, j);
          if (Arrays.equals(paramArrayOfbyte, ProfileVersion.V001_N)) {
            dexProfileData.classSetSize = j;
            dexProfileData.classes = arrayOfInt;
          } 
          i++;
          continue;
        } 
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("Missing profile key: ");
        stringBuilder.append((String)arrayOfInt);
        throw Encoding.error(stringBuilder.toString());
      } 
      return paramArrayOfDexProfileData;
    } 
    throw Encoding.error("Mismatched number of dex files found in metadata");
  }
  
  private static void readMethodBitmap(@NonNull InputStream paramInputStream, @NonNull DexProfileData paramDexProfileData) throws IOException {
    BitSet bitSet = BitSet.valueOf(Encoding.read(paramInputStream, Encoding.bitsToBytes(paramDexProfileData.numMethodIds * 2)));
    int i = 0;
    while (true) {
      int j = paramDexProfileData.numMethodIds;
      if (i < j) {
        j = readFlagsFromBitmap(bitSet, i, j);
        if (j != 0) {
          Integer integer2 = (Integer)paramDexProfileData.methods.get(Integer.valueOf(i));
          Integer integer1 = integer2;
          if (integer2 == null)
            integer1 = Integer.valueOf(0); 
          paramDexProfileData.methods.put(Integer.valueOf(i), Integer.valueOf(j | integer1.intValue()));
        } 
        i++;
        continue;
      } 
      break;
    } 
  }
  
  @NonNull
  static DexProfileData[] readProfile(@NonNull InputStream paramInputStream, @NonNull byte[] paramArrayOfbyte, @NonNull String paramString) throws IOException {
    if (Arrays.equals(paramArrayOfbyte, ProfileVersion.V010_P)) {
      int i = Encoding.readUInt8(paramInputStream);
      long l = Encoding.readUInt32(paramInputStream);
      paramArrayOfbyte = Encoding.readCompressed(paramInputStream, (int)Encoding.readUInt32(paramInputStream), (int)l);
      if (paramInputStream.read() <= 0) {
        paramInputStream = new ByteArrayInputStream(paramArrayOfbyte);
        try {
          return readUncompressedBody(paramInputStream, paramString, i);
        } finally {
          try {
            paramInputStream.close();
          } finally {
            paramInputStream = null;
          } 
        } 
      } 
      throw Encoding.error("Content found after the end of file");
    } 
    throw Encoding.error("Unsupported version");
  }
  
  @NonNull
  private static DexProfileData[] readUncompressedBody(@NonNull InputStream paramInputStream, @NonNull String paramString, int paramInt) throws IOException {
    int j;
    int i = paramInputStream.available();
    byte b = 0;
    if (i == 0)
      return new DexProfileData[0]; 
    DexProfileData[] arrayOfDexProfileData = new DexProfileData[paramInt];
    i = 0;
    while (true) {
      j = b;
      if (i < paramInt) {
        j = Encoding.readUInt16(paramInputStream);
        int k = Encoding.readUInt16(paramInputStream);
        long l1 = Encoding.readUInt32(paramInputStream);
        long l2 = Encoding.readUInt32(paramInputStream);
        long l3 = Encoding.readUInt32(paramInputStream);
        arrayOfDexProfileData[i] = new DexProfileData(paramString, Encoding.readString(paramInputStream, j), l2, 0L, k, (int)l1, (int)l3, new int[k], new TreeMap<Object, Object>());
        i++;
        continue;
      } 
      break;
    } 
    while (j < paramInt) {
      DexProfileData dexProfileData = arrayOfDexProfileData[j];
      readHotMethodRegion(paramInputStream, dexProfileData);
      dexProfileData.classes = readClasses(paramInputStream, dexProfileData.classSetSize);
      readMethodBitmap(paramInputStream, dexProfileData);
      j++;
    } 
    return arrayOfDexProfileData;
  }
  
  private static int roundUpToByte(int paramInt) {
    return paramInt + 8 - 1 & 0xFFFFFFF8;
  }
  
  private static void setMethodBitmapBit(@NonNull byte[] paramArrayOfbyte, int paramInt1, int paramInt2, @NonNull DexProfileData paramDexProfileData) {
    paramInt1 = methodFlagBitmapIndex(paramInt1, paramInt2, paramDexProfileData.numMethodIds);
    paramInt2 = paramInt1 / 8;
    paramArrayOfbyte[paramInt2] = (byte)(1 << paramInt1 % 8 | paramArrayOfbyte[paramInt2]);
  }
  
  private static void skipInlineCache(@NonNull InputStream paramInputStream) throws IOException {
    Encoding.readUInt16(paramInputStream);
    int j = Encoding.readUInt8(paramInputStream);
    if (j == 6)
      return; 
    int i = j;
    if (j == 7)
      return; 
    while (i > 0) {
      Encoding.readUInt8(paramInputStream);
      for (j = Encoding.readUInt8(paramInputStream); j > 0; j--)
        Encoding.readUInt16(paramInputStream); 
      i--;
    } 
  }
  
  static boolean transcodeAndWriteBody(@NonNull OutputStream paramOutputStream, @NonNull byte[] paramArrayOfbyte, @NonNull DexProfileData[] paramArrayOfDexProfileData) throws IOException {
    if (Arrays.equals(paramArrayOfbyte, ProfileVersion.V015_S)) {
      writeProfileForS(paramOutputStream, paramArrayOfDexProfileData);
      return true;
    } 
    if (Arrays.equals(paramArrayOfbyte, ProfileVersion.V010_P)) {
      writeProfileForP(paramOutputStream, paramArrayOfDexProfileData);
      return true;
    } 
    if (Arrays.equals(paramArrayOfbyte, ProfileVersion.V005_O)) {
      writeProfileForO(paramOutputStream, paramArrayOfDexProfileData);
      return true;
    } 
    if (Arrays.equals(paramArrayOfbyte, ProfileVersion.V009_O_MR1)) {
      writeProfileForO_MR1(paramOutputStream, paramArrayOfDexProfileData);
      return true;
    } 
    if (Arrays.equals(paramArrayOfbyte, ProfileVersion.V001_N)) {
      writeProfileForN(paramOutputStream, paramArrayOfDexProfileData);
      return true;
    } 
    return false;
  }
  
  private static void writeClasses(@NonNull OutputStream paramOutputStream, @NonNull DexProfileData paramDexProfileData) throws IOException {
    int[] arrayOfInt = paramDexProfileData.classes;
    int k = arrayOfInt.length;
    int i = 0;
    int j = 0;
    while (i < k) {
      Integer integer = Integer.valueOf(arrayOfInt[i]);
      Encoding.writeUInt16(paramOutputStream, integer.intValue() - j);
      j = integer.intValue();
      i++;
    } 
  }
  
  private static WritableFileSection writeDexFileSection(@NonNull DexProfileData[] paramArrayOfDexProfileData) throws IOException {
    ByteArrayOutputStream byteArrayOutputStream = new ByteArrayOutputStream();
    try {
      WritableFileSection writableFileSection;
      Encoding.writeUInt16(byteArrayOutputStream, paramArrayOfDexProfileData.length);
      int i = 0;
      int j = 2;
      while (i < paramArrayOfDexProfileData.length) {
        DexProfileData dexProfileData = paramArrayOfDexProfileData[i];
        Encoding.writeUInt32(byteArrayOutputStream, dexProfileData.dexChecksum);
        Encoding.writeUInt32(byteArrayOutputStream, dexProfileData.mTypeIdCount);
        Encoding.writeUInt32(byteArrayOutputStream, dexProfileData.numMethodIds);
        String str = generateDexKey(dexProfileData.apkName, dexProfileData.dexName, ProfileVersion.V015_S);
        int k = Encoding.utf8Length(str);
        Encoding.writeUInt16(byteArrayOutputStream, k);
        j = j + 4 + 4 + 4 + 2 + k * 1;
        Encoding.writeString(byteArrayOutputStream, str);
        i++;
      } 
      byte[] arrayOfByte = byteArrayOutputStream.toByteArray();
      if (j == arrayOfByte.length) {
        writableFileSection = new WritableFileSection(FileSectionType.DEX_FILES, j, arrayOfByte, false);
        return writableFileSection;
      } 
      StringBuilder stringBuilder = new StringBuilder();
      stringBuilder.append("Expected size ");
      stringBuilder.append(j);
      stringBuilder.append(", does not match actual size ");
      stringBuilder.append(writableFileSection.length);
      throw Encoding.error(stringBuilder.toString());
    } finally {
      try {
        byteArrayOutputStream.close();
      } finally {
        byteArrayOutputStream = null;
      } 
    } 
  }
  
  static void writeHeader(@NonNull OutputStream paramOutputStream, byte[] paramArrayOfbyte) throws IOException {
    paramOutputStream.write(MAGIC_PROF);
    paramOutputStream.write(paramArrayOfbyte);
  }
  
  private static void writeLineData(@NonNull OutputStream paramOutputStream, @NonNull DexProfileData paramDexProfileData) throws IOException {
    writeMethodsWithInlineCaches(paramOutputStream, paramDexProfileData);
    writeClasses(paramOutputStream, paramDexProfileData);
    writeMethodBitmap(paramOutputStream, paramDexProfileData);
  }
  
  private static void writeLineHeader(@NonNull OutputStream paramOutputStream, @NonNull DexProfileData paramDexProfileData, @NonNull String paramString) throws IOException {
    Encoding.writeUInt16(paramOutputStream, Encoding.utf8Length(paramString));
    Encoding.writeUInt16(paramOutputStream, paramDexProfileData.classSetSize);
    Encoding.writeUInt32(paramOutputStream, paramDexProfileData.hotMethodRegionSize);
    Encoding.writeUInt32(paramOutputStream, paramDexProfileData.dexChecksum);
    Encoding.writeUInt32(paramOutputStream, paramDexProfileData.numMethodIds);
    Encoding.writeString(paramOutputStream, paramString);
  }
  
  private static void writeMethodBitmap(@NonNull OutputStream paramOutputStream, @NonNull DexProfileData paramDexProfileData) throws IOException {
    byte[] arrayOfByte = new byte[getMethodBitmapStorageSize(paramDexProfileData.numMethodIds)];
    for (Map.Entry entry : paramDexProfileData.methods.entrySet()) {
      int i = ((Integer)entry.getKey()).intValue();
      int j = ((Integer)entry.getValue()).intValue();
      if ((j & 0x2) != 0)
        setMethodBitmapBit(arrayOfByte, 2, i, paramDexProfileData); 
      if ((j & 0x4) != 0)
        setMethodBitmapBit(arrayOfByte, 4, i, paramDexProfileData); 
    } 
    paramOutputStream.write(arrayOfByte);
  }
  
  private static void writeMethodsWithInlineCaches(@NonNull OutputStream paramOutputStream, @NonNull DexProfileData paramDexProfileData) throws IOException {
    Iterator<Map.Entry> iterator = paramDexProfileData.methods.entrySet().iterator();
    for (int i = 0; iterator.hasNext(); i = j) {
      Map.Entry entry = iterator.next();
      int j = ((Integer)entry.getKey()).intValue();
      if ((((Integer)entry.getValue()).intValue() & 0x1) == 0)
        continue; 
      Encoding.writeUInt16(paramOutputStream, j - i);
      Encoding.writeUInt16(paramOutputStream, 0);
    } 
  }
  
  private static void writeProfileForN(@NonNull OutputStream paramOutputStream, @NonNull DexProfileData[] paramArrayOfDexProfileData) throws IOException {
    Encoding.writeUInt16(paramOutputStream, paramArrayOfDexProfileData.length);
    int j = paramArrayOfDexProfileData.length;
    for (int i = 0; i < j; i++) {
      DexProfileData dexProfileData = paramArrayOfDexProfileData[i];
      String str = generateDexKey(dexProfileData.apkName, dexProfileData.dexName, ProfileVersion.V001_N);
      Encoding.writeUInt16(paramOutputStream, Encoding.utf8Length(str));
      Encoding.writeUInt16(paramOutputStream, dexProfileData.methods.size());
      Encoding.writeUInt16(paramOutputStream, dexProfileData.classes.length);
      Encoding.writeUInt32(paramOutputStream, dexProfileData.dexChecksum);
      Encoding.writeString(paramOutputStream, str);
      Iterator<Integer> iterator = dexProfileData.methods.keySet().iterator();
      while (iterator.hasNext())
        Encoding.writeUInt16(paramOutputStream, ((Integer)iterator.next()).intValue()); 
      int[] arrayOfInt = dexProfileData.classes;
      int m = arrayOfInt.length;
      for (int k = 0; k < m; k++)
        Encoding.writeUInt16(paramOutputStream, arrayOfInt[k]); 
    } 
  }
  
  private static void writeProfileForO(@NonNull OutputStream paramOutputStream, @NonNull DexProfileData[] paramArrayOfDexProfileData) throws IOException {
    Encoding.writeUInt8(paramOutputStream, paramArrayOfDexProfileData.length);
    int j = paramArrayOfDexProfileData.length;
    for (int i = 0; i < j; i++) {
      DexProfileData dexProfileData = paramArrayOfDexProfileData[i];
      int k = dexProfileData.methods.size();
      String str = generateDexKey(dexProfileData.apkName, dexProfileData.dexName, ProfileVersion.V005_O);
      Encoding.writeUInt16(paramOutputStream, Encoding.utf8Length(str));
      Encoding.writeUInt16(paramOutputStream, dexProfileData.classes.length);
      Encoding.writeUInt32(paramOutputStream, (k * 4));
      Encoding.writeUInt32(paramOutputStream, dexProfileData.dexChecksum);
      Encoding.writeString(paramOutputStream, str);
      Iterator<Integer> iterator = dexProfileData.methods.keySet().iterator();
      while (iterator.hasNext()) {
        Encoding.writeUInt16(paramOutputStream, ((Integer)iterator.next()).intValue());
        Encoding.writeUInt16(paramOutputStream, 0);
      } 
      int[] arrayOfInt = dexProfileData.classes;
      int m = arrayOfInt.length;
      for (k = 0; k < m; k++)
        Encoding.writeUInt16(paramOutputStream, arrayOfInt[k]); 
    } 
  }
  
  private static void writeProfileForO_MR1(@NonNull OutputStream paramOutputStream, @NonNull DexProfileData[] paramArrayOfDexProfileData) throws IOException {
    byte[] arrayOfByte = createCompressibleBody(paramArrayOfDexProfileData, ProfileVersion.V009_O_MR1);
    Encoding.writeUInt8(paramOutputStream, paramArrayOfDexProfileData.length);
    Encoding.writeCompressed(paramOutputStream, arrayOfByte);
  }
  
  private static void writeProfileForP(@NonNull OutputStream paramOutputStream, @NonNull DexProfileData[] paramArrayOfDexProfileData) throws IOException {
    byte[] arrayOfByte = createCompressibleBody(paramArrayOfDexProfileData, ProfileVersion.V010_P);
    Encoding.writeUInt8(paramOutputStream, paramArrayOfDexProfileData.length);
    Encoding.writeCompressed(paramOutputStream, arrayOfByte);
  }
  
  private static void writeProfileForS(@NonNull OutputStream paramOutputStream, @NonNull DexProfileData[] paramArrayOfDexProfileData) throws IOException {
    writeProfileSections(paramOutputStream, paramArrayOfDexProfileData);
  }
  
  private static void writeProfileSections(@NonNull OutputStream paramOutputStream, @NonNull DexProfileData[] paramArrayOfDexProfileData) throws IOException {
    int j;
    ArrayList<WritableFileSection> arrayList = new ArrayList(3);
    ArrayList<byte[]> arrayList1 = new ArrayList(3);
    arrayList.add(writeDexFileSection(paramArrayOfDexProfileData));
    arrayList.add(createCompressibleClassSection(paramArrayOfDexProfileData));
    arrayList.add(createCompressibleMethodsSection(paramArrayOfDexProfileData));
    long l = ProfileVersion.V015_S.length + MAGIC_PROF.length + 4L + (arrayList.size() * 16);
    Encoding.writeUInt32(paramOutputStream, arrayList.size());
    byte b = 0;
    int i = 0;
    while (true) {
      j = b;
      if (i < arrayList.size()) {
        byte[] arrayOfByte;
        WritableFileSection writableFileSection = arrayList.get(i);
        Encoding.writeUInt32(paramOutputStream, writableFileSection.mType.getValue());
        Encoding.writeUInt32(paramOutputStream, l);
        if (writableFileSection.mNeedsCompression) {
          arrayOfByte = writableFileSection.mContents;
          long l1 = arrayOfByte.length;
          arrayOfByte = Encoding.compress(arrayOfByte);
          arrayList1.add(arrayOfByte);
          Encoding.writeUInt32(paramOutputStream, arrayOfByte.length);
          Encoding.writeUInt32(paramOutputStream, l1);
          j = arrayOfByte.length;
        } else {
          arrayList1.add(((WritableFileSection)arrayOfByte).mContents);
          Encoding.writeUInt32(paramOutputStream, ((WritableFileSection)arrayOfByte).mContents.length);
          Encoding.writeUInt32(paramOutputStream, 0L);
          j = ((WritableFileSection)arrayOfByte).mContents.length;
        } 
        l += j;
        i++;
        continue;
      } 
      break;
    } 
    while (j < arrayList1.size()) {
      paramOutputStream.write(arrayList1.get(j));
      j++;
    } 
  }
}


/* Location:              C:\soft\dex2jar-2.0\MagicAI - AI Art & Anime Art-dex2jar.jar!\androidx\profileinstaller\ProfileTranscoder.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */