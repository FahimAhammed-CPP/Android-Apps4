package androidx.profileinstaller;

import android.content.Context;
import android.os.Build;
import android.os.Handler;
import android.os.Looper;
import android.view.Choreographer;
import androidx.annotation.DoNotInline;
import androidx.annotation.NonNull;
import androidx.annotation.RequiresApi;
import androidx.arch.core.executor.DefaultTaskExecutor$Api28Impl$;
import androidx.startup.Initializer;
import java.util.Collections;
import java.util.List;
import java.util.Random;
import java.util.concurrent.LinkedBlockingQueue;
import java.util.concurrent.ThreadPoolExecutor;
import java.util.concurrent.TimeUnit;

public class ProfileInstallerInitializer implements Initializer<ProfileInstallerInitializer.Result> {
  private static final int DELAY_MS = 5000;
  
  private static void writeInBackground(@NonNull Context paramContext) {
    (new ThreadPoolExecutor(0, 1, 0L, TimeUnit.MILLISECONDS, new LinkedBlockingQueue<Runnable>())).execute((Runnable)new ProfileInstallerInitializer$.ExternalSyntheticLambda2(paramContext));
  }
  
  @NonNull
  public Result create(@NonNull Context paramContext) {
    if (Build.VERSION.SDK_INT < 24)
      return new Result(); 
    delayAfterFirstFrame(paramContext.getApplicationContext());
    return new Result();
  }
  
  @RequiresApi(16)
  void delayAfterFirstFrame(@NonNull Context paramContext) {
    Choreographer16Impl.postFrameCallback((Runnable)new ProfileInstallerInitializer$.ExternalSyntheticLambda1(this, paramContext));
  }
  
  @NonNull
  public List<Class<? extends Initializer<?>>> dependencies() {
    return Collections.emptyList();
  }
  
  void installAfterDelay(@NonNull Context paramContext) {
    Handler handler;
    if (Build.VERSION.SDK_INT >= 28) {
      handler = Handler28Impl.createAsync(Looper.getMainLooper());
    } else {
      handler = new Handler(Looper.getMainLooper());
    } 
    int i = (new Random()).nextInt(Math.max(1000, 1));
    handler.postDelayed((Runnable)new ProfileInstallerInitializer$.ExternalSyntheticLambda0(paramContext), (i + 5000));
  }
  
  @RequiresApi(16)
  private static class Choreographer16Impl {
    @DoNotInline
    public static void postFrameCallback(Runnable param1Runnable) {
      Choreographer.getInstance().postFrameCallback((Choreographer.FrameCallback)new ProfileInstallerInitializer$Choreographer16Impl$.ExternalSyntheticLambda0(param1Runnable));
    }
  }
  
  @RequiresApi(28)
  private static class Handler28Impl {
    @DoNotInline
    public static Handler createAsync(Looper param1Looper) {
      return DefaultTaskExecutor$Api28Impl$.ExternalSyntheticApiModelOutline0.m(param1Looper);
    }
  }
  
  public static class Result {}
}


/* Location:              C:\soft\dex2jar-2.0\MagicAI - AI Art & Anime Art-dex2jar.jar!\androidx\profileinstaller\ProfileInstallerInitializer.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */