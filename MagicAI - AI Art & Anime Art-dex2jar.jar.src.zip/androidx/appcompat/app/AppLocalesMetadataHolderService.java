package androidx.appcompat.app;

import android.app.Service;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.content.pm.ServiceInfo;
import android.os.Build;
import android.os.IBinder;
import androidx.annotation.DoNotInline;
import androidx.annotation.NonNull;
import androidx.annotation.RequiresApi;

public final class AppLocalesMetadataHolderService extends Service {
  @NonNull
  public static ServiceInfo getServiceInfo(@NonNull Context paramContext) throws PackageManager.NameNotFoundException {
    char c;
    if (Build.VERSION.SDK_INT >= 24) {
      c = Api24Impl.getDisabledComponentFlag() | 0x80;
    } else {
      c = 'ʀ';
    } 
    return paramContext.getPackageManager().getServiceInfo(new ComponentName(paramContext, AppLocalesMetadataHolderService.class), c);
  }
  
  @NonNull
  public IBinder onBind(@NonNull Intent paramIntent) {
    throw new UnsupportedOperationException();
  }
  
  @RequiresApi(24)
  private static class Api24Impl {
    @DoNotInline
    static int getDisabledComponentFlag() {
      return 512;
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\MagicAI - AI Art & Anime Art-dex2jar.jar!\androidx\appcompat\app\AppLocalesMetadataHolderService.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */