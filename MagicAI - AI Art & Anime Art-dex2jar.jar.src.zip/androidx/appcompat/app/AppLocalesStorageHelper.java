package androidx.appcompat.app;

import android.content.ComponentName;
import android.content.Context;
import android.os.Build;
import androidx.annotation.NonNull;
import java.util.ArrayDeque;
import java.util.Queue;
import java.util.concurrent.Executor;

class AppLocalesStorageHelper {
  static final String APPLICATION_LOCALES_RECORD_FILE = "androidx.appcompat.app.AppCompatDelegate.application_locales_record_file";
  
  static final String APP_LOCALES_META_DATA_HOLDER_SERVICE_NAME = "androidx.appcompat.app.AppLocalesMetadataHolderService";
  
  static final String LOCALE_RECORD_ATTRIBUTE_TAG = "application_locales";
  
  static final String LOCALE_RECORD_FILE_TAG = "locales";
  
  static final String TAG = "AppLocalesStorageHelper";
  
  static void persistLocales(@NonNull Context paramContext, @NonNull String paramString) {
    // Byte code:
    //   0: aload_1
    //   1: ldc ''
    //   3: invokevirtual equals : (Ljava/lang/Object;)Z
    //   6: ifeq -> 17
    //   9: aload_0
    //   10: ldc 'androidx.appcompat.app.AppCompatDelegate.application_locales_record_file'
    //   12: invokevirtual deleteFile : (Ljava/lang/String;)Z
    //   15: pop
    //   16: return
    //   17: aload_0
    //   18: ldc 'androidx.appcompat.app.AppCompatDelegate.application_locales_record_file'
    //   20: iconst_0
    //   21: invokevirtual openFileOutput : (Ljava/lang/String;I)Ljava/io/FileOutputStream;
    //   24: astore_0
    //   25: invokestatic newSerializer : ()Lorg/xmlpull/v1/XmlSerializer;
    //   28: astore_2
    //   29: aload_2
    //   30: aload_0
    //   31: aconst_null
    //   32: invokeinterface setOutput : (Ljava/io/OutputStream;Ljava/lang/String;)V
    //   37: aload_2
    //   38: ldc 'UTF-8'
    //   40: getstatic java/lang/Boolean.TRUE : Ljava/lang/Boolean;
    //   43: invokeinterface startDocument : (Ljava/lang/String;Ljava/lang/Boolean;)V
    //   48: aload_2
    //   49: aconst_null
    //   50: ldc 'locales'
    //   52: invokeinterface startTag : (Ljava/lang/String;Ljava/lang/String;)Lorg/xmlpull/v1/XmlSerializer;
    //   57: pop
    //   58: aload_2
    //   59: aconst_null
    //   60: ldc 'application_locales'
    //   62: aload_1
    //   63: invokeinterface attribute : (Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)Lorg/xmlpull/v1/XmlSerializer;
    //   68: pop
    //   69: aload_2
    //   70: aconst_null
    //   71: ldc 'locales'
    //   73: invokeinterface endTag : (Ljava/lang/String;Ljava/lang/String;)Lorg/xmlpull/v1/XmlSerializer;
    //   78: pop
    //   79: aload_2
    //   80: invokeinterface endDocument : ()V
    //   85: new java/lang/StringBuilder
    //   88: dup
    //   89: invokespecial <init> : ()V
    //   92: astore_2
    //   93: aload_2
    //   94: ldc 'Storing App Locales : app-locales: '
    //   96: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   99: pop
    //   100: aload_2
    //   101: aload_1
    //   102: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   105: pop
    //   106: aload_2
    //   107: ldc ' persisted successfully.'
    //   109: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   112: pop
    //   113: ldc 'AppLocalesStorageHelper'
    //   115: aload_2
    //   116: invokevirtual toString : ()Ljava/lang/String;
    //   119: invokestatic d : (Ljava/lang/String;Ljava/lang/String;)I
    //   122: pop
    //   123: aload_0
    //   124: ifnull -> 176
    //   127: aload_0
    //   128: invokevirtual close : ()V
    //   131: return
    //   132: astore_1
    //   133: goto -> 177
    //   136: astore_2
    //   137: new java/lang/StringBuilder
    //   140: dup
    //   141: invokespecial <init> : ()V
    //   144: astore_3
    //   145: aload_3
    //   146: ldc 'Storing App Locales : Failed to persist app-locales: '
    //   148: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   151: pop
    //   152: aload_3
    //   153: aload_1
    //   154: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   157: pop
    //   158: ldc 'AppLocalesStorageHelper'
    //   160: aload_3
    //   161: invokevirtual toString : ()Ljava/lang/String;
    //   164: aload_2
    //   165: invokestatic w : (Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)I
    //   168: pop
    //   169: aload_0
    //   170: ifnull -> 176
    //   173: goto -> 127
    //   176: return
    //   177: aload_0
    //   178: ifnull -> 185
    //   181: aload_0
    //   182: invokevirtual close : ()V
    //   185: aload_1
    //   186: athrow
    //   187: ldc 'AppLocalesStorageHelper'
    //   189: ldc 'Storing App Locales : FileNotFoundException: Cannot open file %s for writing '
    //   191: iconst_1
    //   192: anewarray java/lang/Object
    //   195: dup
    //   196: iconst_0
    //   197: ldc 'androidx.appcompat.app.AppCompatDelegate.application_locales_record_file'
    //   199: aastore
    //   200: invokestatic format : (Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/String;
    //   203: invokestatic w : (Ljava/lang/String;Ljava/lang/String;)I
    //   206: pop
    //   207: return
    //   208: astore_0
    //   209: goto -> 187
    //   212: astore_0
    //   213: return
    //   214: astore_0
    //   215: goto -> 185
    // Exception table:
    //   from	to	target	type
    //   17	25	208	java/io/FileNotFoundException
    //   29	123	136	java/lang/Exception
    //   29	123	132	finally
    //   127	131	212	java/io/IOException
    //   137	169	132	finally
    //   181	185	214	java/io/IOException
  }
  
  @NonNull
  static String readLocales(@NonNull Context paramContext) {
    // Byte code:
    //   0: ldc ''
    //   2: astore #4
    //   4: aload_0
    //   5: ldc 'androidx.appcompat.app.AppCompatDelegate.application_locales_record_file'
    //   7: invokevirtual openFileInput : (Ljava/lang/String;)Ljava/io/FileInputStream;
    //   10: astore #6
    //   12: invokestatic newPullParser : ()Lorg/xmlpull/v1/XmlPullParser;
    //   15: astore #5
    //   17: aload #5
    //   19: aload #6
    //   21: ldc 'UTF-8'
    //   23: invokeinterface setInput : (Ljava/io/InputStream;Ljava/lang/String;)V
    //   28: aload #5
    //   30: invokeinterface getDepth : ()I
    //   35: istore_1
    //   36: aload #5
    //   38: invokeinterface next : ()I
    //   43: istore_2
    //   44: aload #4
    //   46: astore_3
    //   47: iload_2
    //   48: iconst_1
    //   49: if_icmpeq -> 100
    //   52: iload_2
    //   53: iconst_3
    //   54: if_icmpne -> 245
    //   57: aload #4
    //   59: astore_3
    //   60: aload #5
    //   62: invokeinterface getDepth : ()I
    //   67: iload_1
    //   68: if_icmple -> 100
    //   71: goto -> 245
    //   74: aload #5
    //   76: invokeinterface getName : ()Ljava/lang/String;
    //   81: ldc 'locales'
    //   83: invokevirtual equals : (Ljava/lang/Object;)Z
    //   86: ifeq -> 36
    //   89: aload #5
    //   91: aconst_null
    //   92: ldc 'application_locales'
    //   94: invokeinterface getAttributeValue : (Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;
    //   99: astore_3
    //   100: aload_3
    //   101: astore #5
    //   103: aload #6
    //   105: ifnull -> 152
    //   108: aload #6
    //   110: invokevirtual close : ()V
    //   113: aload_3
    //   114: astore #5
    //   116: goto -> 152
    //   119: aload_3
    //   120: astore #5
    //   122: goto -> 152
    //   125: astore_0
    //   126: goto -> 205
    //   129: ldc 'AppLocalesStorageHelper'
    //   131: ldc 'Reading app Locales : Unable to parse through file :androidx.appcompat.app.AppCompatDelegate.application_locales_record_file'
    //   133: invokestatic w : (Ljava/lang/String;Ljava/lang/String;)I
    //   136: pop
    //   137: aload #4
    //   139: astore #5
    //   141: aload #6
    //   143: ifnull -> 152
    //   146: aload #4
    //   148: astore_3
    //   149: goto -> 108
    //   152: aload #5
    //   154: invokevirtual isEmpty : ()Z
    //   157: ifne -> 195
    //   160: new java/lang/StringBuilder
    //   163: dup
    //   164: invokespecial <init> : ()V
    //   167: astore_0
    //   168: aload_0
    //   169: ldc 'Reading app Locales : Locales read from file: androidx.appcompat.app.AppCompatDelegate.application_locales_record_file , appLocales: '
    //   171: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   174: pop
    //   175: aload_0
    //   176: aload #5
    //   178: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   181: pop
    //   182: ldc 'AppLocalesStorageHelper'
    //   184: aload_0
    //   185: invokevirtual toString : ()Ljava/lang/String;
    //   188: invokestatic d : (Ljava/lang/String;Ljava/lang/String;)I
    //   191: pop
    //   192: aload #5
    //   194: areturn
    //   195: aload_0
    //   196: ldc 'androidx.appcompat.app.AppCompatDelegate.application_locales_record_file'
    //   198: invokevirtual deleteFile : (Ljava/lang/String;)Z
    //   201: pop
    //   202: aload #5
    //   204: areturn
    //   205: aload #6
    //   207: ifnull -> 215
    //   210: aload #6
    //   212: invokevirtual close : ()V
    //   215: aload_0
    //   216: athrow
    //   217: ldc 'AppLocalesStorageHelper'
    //   219: ldc 'Reading app Locales : Locales record file not found: androidx.appcompat.app.AppCompatDelegate.application_locales_record_file'
    //   221: invokestatic w : (Ljava/lang/String;Ljava/lang/String;)I
    //   224: pop
    //   225: ldc ''
    //   227: areturn
    //   228: astore_0
    //   229: goto -> 217
    //   232: astore_3
    //   233: goto -> 129
    //   236: astore #4
    //   238: goto -> 119
    //   241: astore_3
    //   242: goto -> 215
    //   245: iload_2
    //   246: iconst_3
    //   247: if_icmpeq -> 36
    //   250: iload_2
    //   251: iconst_4
    //   252: if_icmpne -> 74
    //   255: goto -> 36
    // Exception table:
    //   from	to	target	type
    //   4	12	228	java/io/FileNotFoundException
    //   12	36	232	org/xmlpull/v1/XmlPullParserException
    //   12	36	232	java/io/IOException
    //   12	36	125	finally
    //   36	44	232	org/xmlpull/v1/XmlPullParserException
    //   36	44	232	java/io/IOException
    //   36	44	125	finally
    //   60	71	232	org/xmlpull/v1/XmlPullParserException
    //   60	71	232	java/io/IOException
    //   60	71	125	finally
    //   74	100	232	org/xmlpull/v1/XmlPullParserException
    //   74	100	232	java/io/IOException
    //   74	100	125	finally
    //   108	113	236	java/io/IOException
    //   129	137	125	finally
    //   210	215	241	java/io/IOException
  }
  
  static void syncLocalesToFramework(Context paramContext) {
    if (Build.VERSION.SDK_INT >= 33) {
      ComponentName componentName = new ComponentName(paramContext, "androidx.appcompat.app.AppLocalesMetadataHolderService");
      if (paramContext.getPackageManager().getComponentEnabledSetting(componentName) != 1) {
        if (AppCompatDelegate.getApplicationLocales().isEmpty()) {
          String str = readLocales(paramContext);
          Object object = paramContext.getSystemService("locale");
          if (object != null)
            AppCompatDelegate.Api33Impl.localeManagerSetApplicationLocales(object, AppCompatDelegate.Api24Impl.localeListForLanguageTags(str)); 
        } 
        paramContext.getPackageManager().setComponentEnabledSetting(componentName, 1, 1);
      } 
    } 
  }
  
  static class SerialExecutor implements Executor {
    Runnable mActive;
    
    final Executor mExecutor;
    
    private final Object mLock = new Object();
    
    final Queue<Runnable> mTasks = new ArrayDeque<Runnable>();
    
    SerialExecutor(Executor param1Executor) {
      this.mExecutor = param1Executor;
    }
    
    public void execute(Runnable param1Runnable) {
      synchronized (this.mLock) {
        this.mTasks.add(new AppLocalesStorageHelper$SerialExecutor$.ExternalSyntheticLambda0(this, param1Runnable));
        if (this.mActive == null)
          scheduleNext(); 
        return;
      } 
    }
    
    protected void scheduleNext() {
      synchronized (this.mLock) {
        Runnable runnable = this.mTasks.poll();
        this.mActive = runnable;
        if (runnable != null)
          this.mExecutor.execute(runnable); 
        return;
      } 
    }
  }
  
  static class ThreadPerTaskExecutor implements Executor {
    public void execute(Runnable param1Runnable) {
      (new Thread(param1Runnable)).start();
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\MagicAI - AI Art & Anime Art-dex2jar.jar!\androidx\appcompat\app\AppLocalesStorageHelper.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */