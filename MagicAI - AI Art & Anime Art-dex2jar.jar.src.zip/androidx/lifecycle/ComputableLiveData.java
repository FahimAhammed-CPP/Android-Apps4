package androidx.lifecycle;

import androidx.annotation.RestrictTo;
import androidx.annotation.VisibleForTesting;
import androidx.annotation.WorkerThread;
import androidx.arch.core.executor.ArchTaskExecutor;
import java.util.concurrent.Executor;
import java.util.concurrent.atomic.AtomicBoolean;
import kotlin.Metadata;
import kotlin.jvm.internal.DefaultConstructorMarker;
import kotlin.jvm.internal.Intrinsics;

@Metadata(d1 = {"\0000\n\002\030\002\n\000\n\002\020\000\n\000\n\002\030\002\n\002\b\002\n\002\030\002\n\000\n\002\030\002\n\002\b\007\n\002\030\002\n\002\b\n\n\002\020\002\n\000\b'\030\000*\004\b\000\020\0012\0020\002B\021\b\007\022\b\b\002\020\003\032\0020\004¢\006\002\020\005J\r\020\031\032\0028\000H%¢\006\002\020\032J\b\020\033\032\0020\034H\026R\026\020\006\032\n\022\006\022\004\030\0018\0000\007X\004¢\006\002\n\000R\024\020\b\032\0020\tX\004¢\006\b\n\000\032\004\b\n\020\013R\024\020\003\032\0020\004X\004¢\006\b\n\000\032\004\b\f\020\rR\024\020\016\032\0020\tX\004¢\006\b\n\000\032\004\b\017\020\013R\026\020\020\032\0020\0218\000X\004¢\006\b\n\000\022\004\b\022\020\023R\034\020\024\032\n\022\006\022\004\030\0018\0000\007X\004¢\006\b\n\000\032\004\b\025\020\026R\026\020\027\032\0020\0218\000X\004¢\006\b\n\000\022\004\b\030\020\023¨\006\035"}, d2 = {"Landroidx/lifecycle/ComputableLiveData;", "T", "", "executor", "Ljava/util/concurrent/Executor;", "(Ljava/util/concurrent/Executor;)V", "_liveData", "Landroidx/lifecycle/LiveData;", "computing", "Ljava/util/concurrent/atomic/AtomicBoolean;", "getComputing$lifecycle_livedata_release", "()Ljava/util/concurrent/atomic/AtomicBoolean;", "getExecutor$lifecycle_livedata_release", "()Ljava/util/concurrent/Executor;", "invalid", "getInvalid$lifecycle_livedata_release", "invalidationRunnable", "Ljava/lang/Runnable;", "getInvalidationRunnable$lifecycle_livedata_release$annotations", "()V", "liveData", "getLiveData", "()Landroidx/lifecycle/LiveData;", "refreshRunnable", "getRefreshRunnable$lifecycle_livedata_release$annotations", "compute", "()Ljava/lang/Object;", "invalidate", "", "lifecycle-livedata_release"}, k = 1, mv = {1, 8, 0}, xi = 48)
@RestrictTo({RestrictTo.Scope.LIBRARY_GROUP_PREFIX})
public abstract class ComputableLiveData<T> {
  private final LiveData<T> _liveData;
  
  private final AtomicBoolean computing;
  
  private final Executor executor;
  
  private final AtomicBoolean invalid;
  
  public final Runnable invalidationRunnable;
  
  private final LiveData<T> liveData;
  
  public final Runnable refreshRunnable;
  
  public ComputableLiveData() {
    this(null, 1, null);
  }
  
  public ComputableLiveData(Executor paramExecutor) {
    this.executor = paramExecutor;
    ComputableLiveData$_liveData$1 computableLiveData$_liveData$1 = new ComputableLiveData$_liveData$1();
    this._liveData = computableLiveData$_liveData$1;
    this.liveData = computableLiveData$_liveData$1;
    this.invalid = new AtomicBoolean(true);
    this.computing = new AtomicBoolean(false);
    this.refreshRunnable = (Runnable)new ComputableLiveData$.ExternalSyntheticLambda0(this);
    this.invalidationRunnable = (Runnable)new ComputableLiveData$.ExternalSyntheticLambda1(this);
  }
  
  private static final void invalidationRunnable$lambda$1(ComputableLiveData<T> paramComputableLiveData) {
    Intrinsics.checkNotNullParameter(paramComputableLiveData, "this$0");
    boolean bool = paramComputableLiveData.getLiveData().hasActiveObservers();
    if (paramComputableLiveData.invalid.compareAndSet(false, true) && bool)
      paramComputableLiveData.executor.execute(paramComputableLiveData.refreshRunnable); 
  }
  
  private static final void refreshRunnable$lambda$0(ComputableLiveData<AtomicBoolean> paramComputableLiveData) {
    boolean bool;
    Intrinsics.checkNotNullParameter(paramComputableLiveData, "this$0");
    do {
      null = paramComputableLiveData.computing;
      bool = false;
      if (!null.compareAndSet(false, true))
        continue; 
      null = null;
      bool = false;
      try {
        while (paramComputableLiveData.invalid.compareAndSet(true, false)) {
          null = paramComputableLiveData.compute();
          bool = true;
        } 
        if (bool)
          paramComputableLiveData.getLiveData().postValue(null); 
      } finally {
        paramComputableLiveData.computing.set(false);
      } 
    } while (bool && paramComputableLiveData.invalid.get());
  }
  
  @WorkerThread
  protected abstract T compute();
  
  public final AtomicBoolean getComputing$lifecycle_livedata_release() {
    return this.computing;
  }
  
  public final Executor getExecutor$lifecycle_livedata_release() {
    return this.executor;
  }
  
  public final AtomicBoolean getInvalid$lifecycle_livedata_release() {
    return this.invalid;
  }
  
  public LiveData<T> getLiveData() {
    return this.liveData;
  }
  
  public void invalidate() {
    ArchTaskExecutor.getInstance().executeOnMainThread(this.invalidationRunnable);
  }
  
  @Metadata(d1 = {"\000\021\n\000\n\002\030\002\n\000\n\002\020\002\n\000*\001\000\b\n\030\0002\n\022\006\022\004\030\0018\0000\001J\b\020\002\032\0020\003H\024¨\006\004"}, d2 = {"androidx/lifecycle/ComputableLiveData$_liveData$1", "Landroidx/lifecycle/LiveData;", "onActive", "", "lifecycle-livedata_release"}, k = 1, mv = {1, 8, 0}, xi = 48)
  public static final class ComputableLiveData$_liveData$1 extends LiveData<T> {
    protected void onActive() {
      ComputableLiveData.this.getExecutor$lifecycle_livedata_release().execute(ComputableLiveData.this.refreshRunnable);
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\MagicAI - AI Art & Anime Art-dex2jar.jar!\androidx\lifecycle\ComputableLiveData.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */