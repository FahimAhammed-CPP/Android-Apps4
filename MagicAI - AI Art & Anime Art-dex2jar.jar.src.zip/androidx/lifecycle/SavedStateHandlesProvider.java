package androidx.lifecycle;

import android.os.Bundle;
import androidx.savedstate.SavedStateRegistry;
import java.util.Map;
import kotlin.Lazy;
import kotlin.LazyKt;
import kotlin.Metadata;
import kotlin.jvm.functions.Function0;
import kotlin.jvm.internal.Intrinsics;
import kotlin.jvm.internal.Lambda;

@Metadata(d1 = {"\000:\n\002\030\002\n\002\030\002\n\000\n\002\030\002\n\000\n\002\030\002\n\002\b\002\n\002\020\013\n\000\n\002\030\002\n\000\n\002\030\002\n\002\b\006\n\002\020\016\n\000\n\002\020\002\n\002\b\002\b\000\030\0002\0020\001B\025\022\006\020\002\032\0020\003\022\006\020\004\032\0020\005¢\006\002\020\006J\020\020\021\032\004\030\0010\n2\006\020\022\032\0020\023J\006\020\024\032\0020\025J\b\020\026\032\0020\nH\026R\016\020\007\032\0020\bX\016¢\006\002\n\000R\020\020\t\032\004\030\0010\nX\016¢\006\002\n\000R\016\020\002\032\0020\003X\004¢\006\002\n\000R\033\020\013\032\0020\f8BX\002¢\006\f\n\004\b\017\020\020\032\004\b\r\020\016¨\006\027"}, d2 = {"Landroidx/lifecycle/SavedStateHandlesProvider;", "Landroidx/savedstate/SavedStateRegistry$SavedStateProvider;", "savedStateRegistry", "Landroidx/savedstate/SavedStateRegistry;", "viewModelStoreOwner", "Landroidx/lifecycle/ViewModelStoreOwner;", "(Landroidx/savedstate/SavedStateRegistry;Landroidx/lifecycle/ViewModelStoreOwner;)V", "restored", "", "restoredState", "Landroid/os/Bundle;", "viewModel", "Landroidx/lifecycle/SavedStateHandlesVM;", "getViewModel", "()Landroidx/lifecycle/SavedStateHandlesVM;", "viewModel$delegate", "Lkotlin/Lazy;", "consumeRestoredStateForKey", "key", "", "performRestore", "", "saveState", "lifecycle-viewmodel-savedstate_release"}, k = 1, mv = {1, 8, 0}, xi = 48)
public final class SavedStateHandlesProvider implements SavedStateRegistry.SavedStateProvider {
  private boolean restored;
  
  private Bundle restoredState;
  
  private final SavedStateRegistry savedStateRegistry;
  
  private final Lazy viewModel$delegate;
  
  public SavedStateHandlesProvider(SavedStateRegistry paramSavedStateRegistry, ViewModelStoreOwner paramViewModelStoreOwner) {
    this.savedStateRegistry = paramSavedStateRegistry;
    this.viewModel$delegate = LazyKt.lazy(new SavedStateHandlesProvider$viewModel$2(paramViewModelStoreOwner));
  }
  
  private final SavedStateHandlesVM getViewModel() {
    return (SavedStateHandlesVM)this.viewModel$delegate.getValue();
  }
  
  public final Bundle consumeRestoredStateForKey(String paramString) {
    Intrinsics.checkNotNullParameter(paramString, "key");
    performRestore();
    Bundle bundle2 = this.restoredState;
    if (bundle2 != null) {
      bundle2 = bundle2.getBundle(paramString);
    } else {
      bundle2 = null;
    } 
    Bundle bundle3 = this.restoredState;
    if (bundle3 != null)
      bundle3.remove(paramString); 
    Bundle bundle1 = this.restoredState;
    boolean bool2 = false;
    boolean bool1 = bool2;
    if (bundle1 != null) {
      bool1 = bool2;
      if (bundle1.isEmpty() == true)
        bool1 = true; 
    } 
    if (bool1)
      this.restoredState = null; 
    return bundle2;
  }
  
  public final void performRestore() {
    if (!this.restored) {
      this.restoredState = this.savedStateRegistry.consumeRestoredStateForKey("androidx.lifecycle.internal.SavedStateHandlesProvider");
      this.restored = true;
      getViewModel();
    } 
  }
  
  public Bundle saveState() {
    Bundle bundle1 = new Bundle();
    Bundle bundle2 = this.restoredState;
    if (bundle2 != null)
      bundle1.putAll(bundle2); 
    for (Map.Entry entry : getViewModel().getHandles().entrySet()) {
      String str = (String)entry.getKey();
      Bundle bundle = ((SavedStateHandle)entry.getValue()).savedStateProvider().saveState();
      if (!Intrinsics.areEqual(bundle, Bundle.EMPTY))
        bundle1.putBundle(str, bundle); 
    } 
    this.restored = false;
    return bundle1;
  }
  
  @Metadata(d1 = {"\000\b\n\000\n\002\030\002\n\000\020\000\032\0020\001H\n¢\006\002\b\002"}, d2 = {"<anonymous>", "Landroidx/lifecycle/SavedStateHandlesVM;", "invoke"}, k = 3, mv = {1, 8, 0}, xi = 48)
  static final class SavedStateHandlesProvider$viewModel$2 extends Lambda implements Function0<SavedStateHandlesVM> {
    SavedStateHandlesProvider$viewModel$2(ViewModelStoreOwner param1ViewModelStoreOwner) {
      super(0);
    }
    
    public final SavedStateHandlesVM invoke() {
      return SavedStateHandleSupport.getSavedStateHandlesVM(this.$viewModelStoreOwner);
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\MagicAI - AI Art & Anime Art-dex2jar.jar!\androidx\lifecycle\SavedStateHandlesProvider.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */