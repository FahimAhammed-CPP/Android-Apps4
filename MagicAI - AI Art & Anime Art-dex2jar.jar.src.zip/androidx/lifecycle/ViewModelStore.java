package androidx.lifecycle;

import androidx.annotation.RestrictTo;
import java.util.HashSet;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.Map;
import java.util.Set;
import kotlin.Metadata;
import kotlin.jvm.internal.Intrinsics;

@Metadata(d1 = {"\000*\n\002\030\002\n\002\020\000\n\002\b\002\n\002\020%\n\002\020\016\n\002\030\002\n\000\n\002\020\002\n\002\b\003\n\002\020\"\n\002\b\003\b\026\030\0002\0020\001B\005¢\006\002\020\002J\006\020\007\032\0020\bJ\023\020\t\032\004\030\0010\0062\006\020\n\032\0020\005H\002J\016\020\013\032\b\022\004\022\0020\0050\fH\007J\030\020\r\032\0020\b2\006\020\n\032\0020\0052\006\020\016\032\0020\006H\007R\032\020\003\032\016\022\004\022\0020\005\022\004\022\0020\0060\004X\004¢\006\002\n\000¨\006\017"}, d2 = {"Landroidx/lifecycle/ViewModelStore;", "", "()V", "map", "", "", "Landroidx/lifecycle/ViewModel;", "clear", "", "get", "key", "keys", "", "put", "viewModel", "lifecycle-viewmodel_release"}, k = 1, mv = {1, 8, 0}, xi = 48)
public class ViewModelStore {
  private final Map<String, ViewModel> map = new LinkedHashMap<String, ViewModel>();
  
  public final void clear() {
    Iterator<ViewModel> iterator = this.map.values().iterator();
    while (iterator.hasNext())
      ((ViewModel)iterator.next()).clear(); 
    this.map.clear();
  }
  
  @RestrictTo({RestrictTo.Scope.LIBRARY_GROUP})
  public final ViewModel get(String paramString) {
    Intrinsics.checkNotNullParameter(paramString, "key");
    return this.map.get(paramString);
  }
  
  @RestrictTo({RestrictTo.Scope.LIBRARY_GROUP})
  public final Set<String> keys() {
    return new HashSet<String>(this.map.keySet());
  }
  
  @RestrictTo({RestrictTo.Scope.LIBRARY_GROUP})
  public final void put(String paramString, ViewModel paramViewModel) {
    Intrinsics.checkNotNullParameter(paramString, "key");
    Intrinsics.checkNotNullParameter(paramViewModel, "viewModel");
    ViewModel viewModel = this.map.put(paramString, paramViewModel);
    if (viewModel != null)
      viewModel.onCleared(); 
  }
}


/* Location:              C:\soft\dex2jar-2.0\MagicAI - AI Art & Anime Art-dex2jar.jar!\androidx\lifecycle\ViewModelStore.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */