package androidx.lifecycle;

import androidx.annotation.MainThread;
import kotlin.Metadata;
import kotlin.jvm.internal.Intrinsics;
import kotlinx.coroutines.Job;

@Metadata(d1 = {"\0002\n\002\030\002\n\002\020\000\n\000\n\002\030\002\n\000\n\002\030\002\n\000\n\002\030\002\n\000\n\002\030\002\n\002\b\002\n\002\030\002\n\000\n\002\020\002\n\002\b\002\b\001\030\0002\0020\001B%\022\006\020\002\032\0020\003\022\006\020\004\032\0020\005\022\006\020\006\032\0020\007\022\006\020\b\032\0020\t¢\006\002\020\nJ\b\020\r\032\0020\016H\007J\021\020\017\032\0020\0162\006\020\b\032\0020\tH\bR\016\020\006\032\0020\007X\004¢\006\002\n\000R\016\020\002\032\0020\003X\004¢\006\002\n\000R\016\020\004\032\0020\005X\004¢\006\002\n\000R\016\020\013\032\0020\fX\004¢\006\002\n\000¨\006\020"}, d2 = {"Landroidx/lifecycle/LifecycleController;", "", "lifecycle", "Landroidx/lifecycle/Lifecycle;", "minState", "Landroidx/lifecycle/Lifecycle$State;", "dispatchQueue", "Landroidx/lifecycle/DispatchQueue;", "parentJob", "Lkotlinx/coroutines/Job;", "(Landroidx/lifecycle/Lifecycle;Landroidx/lifecycle/Lifecycle$State;Landroidx/lifecycle/DispatchQueue;Lkotlinx/coroutines/Job;)V", "observer", "Landroidx/lifecycle/LifecycleEventObserver;", "finish", "", "handleDestroy", "lifecycle-common"}, k = 1, mv = {1, 8, 0}, xi = 48)
@MainThread
public final class LifecycleController {
  private final DispatchQueue dispatchQueue;
  
  private final Lifecycle lifecycle;
  
  private final Lifecycle.State minState;
  
  private final LifecycleEventObserver observer;
  
  public LifecycleController(Lifecycle paramLifecycle, Lifecycle.State paramState, DispatchQueue paramDispatchQueue, Job paramJob) {
    this.lifecycle = paramLifecycle;
    this.minState = paramState;
    this.dispatchQueue = paramDispatchQueue;
    LifecycleController$.ExternalSyntheticLambda0 externalSyntheticLambda0 = new LifecycleController$.ExternalSyntheticLambda0(this, paramJob);
    this.observer = (LifecycleEventObserver)externalSyntheticLambda0;
    if (paramLifecycle.getCurrentState() == Lifecycle.State.DESTROYED) {
      Job.DefaultImpls.cancel$default(paramJob, null, 1, null);
      finish();
      return;
    } 
    paramLifecycle.addObserver((LifecycleObserver)externalSyntheticLambda0);
  }
  
  private final void handleDestroy(Job paramJob) {
    Job.DefaultImpls.cancel$default(paramJob, null, 1, null);
    finish();
  }
  
  private static final void observer$lambda$0(LifecycleController paramLifecycleController, Job paramJob, LifecycleOwner paramLifecycleOwner, Lifecycle.Event paramEvent) {
    Intrinsics.checkNotNullParameter(paramLifecycleController, "this$0");
    Intrinsics.checkNotNullParameter(paramJob, "$parentJob");
    Intrinsics.checkNotNullParameter(paramLifecycleOwner, "source");
    Intrinsics.checkNotNullParameter(paramEvent, "<anonymous parameter 1>");
    if (paramLifecycleOwner.getLifecycle().getCurrentState() == Lifecycle.State.DESTROYED) {
      Job.DefaultImpls.cancel$default(paramJob, null, 1, null);
      paramLifecycleController.finish();
      return;
    } 
    if (paramLifecycleOwner.getLifecycle().getCurrentState().compareTo(paramLifecycleController.minState) < 0) {
      paramLifecycleController.dispatchQueue.pause();
      return;
    } 
    paramLifecycleController.dispatchQueue.resume();
  }
  
  @MainThread
  public final void finish() {
    this.lifecycle.removeObserver((LifecycleObserver)this.observer);
    this.dispatchQueue.finish();
  }
}


/* Location:              C:\soft\dex2jar-2.0\MagicAI - AI Art & Anime Art-dex2jar.jar!\androidx\lifecycle\LifecycleController.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */