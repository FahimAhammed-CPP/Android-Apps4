package androidx.lifecycle.viewmodel;

import androidx.lifecycle.ViewModel;
import androidx.lifecycle.ViewModelProvider;
import kotlin.Metadata;
import kotlin.jvm.internal.Intrinsics;

@Metadata(d1 = {"\000*\n\002\030\002\n\002\030\002\n\000\n\002\020\021\n\002\030\002\n\002\b\004\n\002\030\002\n\000\n\002\030\002\n\000\n\002\030\002\n\002\b\002\b\000\030\0002\0020\001B!\022\032\020\002\032\016\022\n\b\001\022\006\022\002\b\0030\0040\003\"\006\022\002\b\0030\004¢\006\002\020\005J-\020\007\032\002H\b\"\b\b\000\020\b*\0020\t2\f\020\n\032\b\022\004\022\002H\b0\0132\006\020\f\032\0020\rH\026¢\006\002\020\016R\034\020\002\032\016\022\n\b\001\022\006\022\002\b\0030\0040\003X\004¢\006\004\n\002\020\006¨\006\017"}, d2 = {"Landroidx/lifecycle/viewmodel/InitializerViewModelFactory;", "Landroidx/lifecycle/ViewModelProvider$Factory;", "initializers", "", "Landroidx/lifecycle/viewmodel/ViewModelInitializer;", "([Landroidx/lifecycle/viewmodel/ViewModelInitializer;)V", "[Landroidx/lifecycle/viewmodel/ViewModelInitializer;", "create", "T", "Landroidx/lifecycle/ViewModel;", "modelClass", "Ljava/lang/Class;", "extras", "Landroidx/lifecycle/viewmodel/CreationExtras;", "(Ljava/lang/Class;Landroidx/lifecycle/viewmodel/CreationExtras;)Landroidx/lifecycle/ViewModel;", "lifecycle-viewmodel_release"}, k = 1, mv = {1, 8, 0}, xi = 48)
public final class InitializerViewModelFactory implements ViewModelProvider.Factory {
  private final ViewModelInitializer<?>[] initializers;
  
  public InitializerViewModelFactory(ViewModelInitializer<?>... paramVarArgs) {
    this.initializers = paramVarArgs;
  }
  
  public <T extends ViewModel> T create(Class<T> paramClass, CreationExtras paramCreationExtras) {
    Intrinsics.checkNotNullParameter(paramClass, "modelClass");
    Intrinsics.checkNotNullParameter(paramCreationExtras, "extras");
    ViewModelInitializer<?>[] arrayOfViewModelInitializer = this.initializers;
    int j = arrayOfViewModelInitializer.length;
    int i = 0;
    Object object = null;
    while (i < j) {
      ViewModelInitializer<?> viewModelInitializer = arrayOfViewModelInitializer[i];
      if (Intrinsics.areEqual(viewModelInitializer.getClazz$lifecycle_viewmodel_release(), paramClass)) {
        object = viewModelInitializer.getInitializer$lifecycle_viewmodel_release().invoke(paramCreationExtras);
        if (object instanceof ViewModel) {
          object = object;
        } else {
          object = null;
        } 
      } 
      i++;
    } 
    if (object != null)
      return (T)object; 
    StringBuilder stringBuilder = new StringBuilder();
    stringBuilder.append("No initializer set for given class ");
    stringBuilder.append(paramClass.getName());
    throw new IllegalArgumentException(stringBuilder.toString());
  }
}


/* Location:              C:\soft\dex2jar-2.0\MagicAI - AI Art & Anime Art-dex2jar.jar!\androidx\lifecycle\viewmodel\InitializerViewModelFactory.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */