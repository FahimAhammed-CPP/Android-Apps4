package androidx.lifecycle;

import android.view.View;
import android.view.ViewParent;
import androidx.lifecycle.runtime.R;
import kotlin.Metadata;
import kotlin.jvm.functions.Function1;
import kotlin.jvm.internal.Intrinsics;
import kotlin.jvm.internal.Lambda;
import kotlin.sequences.SequencesKt;

@Metadata(d1 = {"\000\026\n\000\n\002\030\002\n\002\030\002\n\002\b\002\n\002\020\002\n\002\b\003\032\023\020\000\032\004\030\0010\001*\0020\002H\007¢\006\002\b\003\032\033\020\004\032\0020\005*\0020\0022\b\020\006\032\004\030\0010\001H\007¢\006\002\b\007¨\006\b"}, d2 = {"findViewTreeLifecycleOwner", "Landroidx/lifecycle/LifecycleOwner;", "Landroid/view/View;", "get", "setViewTreeLifecycleOwner", "", "lifecycleOwner", "set", "lifecycle-runtime_release"}, k = 2, mv = {1, 8, 0}, xi = 48)
public final class ViewTreeLifecycleOwner {
  public static final LifecycleOwner get(View paramView) {
    Intrinsics.checkNotNullParameter(paramView, "<this>");
    return (LifecycleOwner)SequencesKt.firstOrNull(SequencesKt.mapNotNull(SequencesKt.generateSequence(paramView, ViewTreeLifecycleOwner$findViewTreeLifecycleOwner$1.INSTANCE), ViewTreeLifecycleOwner$findViewTreeLifecycleOwner$2.INSTANCE));
  }
  
  public static final void set(View paramView, LifecycleOwner paramLifecycleOwner) {
    Intrinsics.checkNotNullParameter(paramView, "<this>");
    paramView.setTag(R.id.view_tree_lifecycle_owner, paramLifecycleOwner);
  }
  
  @Metadata(d1 = {"\000\n\n\000\n\002\030\002\n\002\b\002\020\000\032\004\030\0010\0012\006\020\002\032\0020\001H\n¢\006\002\b\003"}, d2 = {"<anonymous>", "Landroid/view/View;", "currentView", "invoke"}, k = 3, mv = {1, 8, 0}, xi = 48)
  static final class ViewTreeLifecycleOwner$findViewTreeLifecycleOwner$1 extends Lambda implements Function1<View, View> {
    public static final ViewTreeLifecycleOwner$findViewTreeLifecycleOwner$1 INSTANCE = new ViewTreeLifecycleOwner$findViewTreeLifecycleOwner$1();
    
    ViewTreeLifecycleOwner$findViewTreeLifecycleOwner$1() {
      super(1);
    }
    
    public final View invoke(View param1View) {
      Intrinsics.checkNotNullParameter(param1View, "currentView");
      ViewParent viewParent = param1View.getParent();
      return (viewParent instanceof View) ? (View)viewParent : null;
    }
  }
  
  @Metadata(d1 = {"\000\016\n\000\n\002\030\002\n\000\n\002\030\002\n\000\020\000\032\004\030\0010\0012\006\020\002\032\0020\003H\n¢\006\002\b\004"}, d2 = {"<anonymous>", "Landroidx/lifecycle/LifecycleOwner;", "viewParent", "Landroid/view/View;", "invoke"}, k = 3, mv = {1, 8, 0}, xi = 48)
  static final class ViewTreeLifecycleOwner$findViewTreeLifecycleOwner$2 extends Lambda implements Function1<View, LifecycleOwner> {
    public static final ViewTreeLifecycleOwner$findViewTreeLifecycleOwner$2 INSTANCE = new ViewTreeLifecycleOwner$findViewTreeLifecycleOwner$2();
    
    ViewTreeLifecycleOwner$findViewTreeLifecycleOwner$2() {
      super(1);
    }
    
    public final LifecycleOwner invoke(View param1View) {
      Intrinsics.checkNotNullParameter(param1View, "viewParent");
      Object object = param1View.getTag(R.id.view_tree_lifecycle_owner);
      return (object instanceof LifecycleOwner) ? (LifecycleOwner)object : null;
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\MagicAI - AI Art & Anime Art-dex2jar.jar!\androidx\lifecycle\ViewTreeLifecycleOwner.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */