package androidx.lifecycle;

import android.os.Bundle;
import androidx.savedstate.SavedStateRegistry;



/* Location:              C:\soft\dex2jar-2.0\MagicAI - AI Art & Anime Art-dex2jar.jar!\androidx\lifecycle\SavedStateHandle$$ExternalSyntheticLambda0.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */