package androidx.lifecycle;

import androidx.annotation.CheckResult;
import androidx.annotation.MainThread;
import androidx.arch.core.util.Function;
import kotlin.Function;
import kotlin.Metadata;
import kotlin.Unit;
import kotlin.jvm.functions.Function1;
import kotlin.jvm.internal.FunctionAdapter;
import kotlin.jvm.internal.Intrinsics;
import kotlin.jvm.internal.Lambda;
import kotlin.jvm.internal.Ref;

@Metadata(d1 = {"\000\030\n\002\b\002\n\002\030\002\n\002\030\002\n\002\b\002\n\002\030\002\n\002\b\005\0328\020\005\032\b\022\004\022\0028\0010\002\"\004\b\000\020\000\"\004\b\001\020\001*\b\022\004\022\0028\0000\0022\022\020\004\032\016\022\004\022\0028\000\022\004\022\0028\0010\003H\007\0328\020\005\032\b\022\004\022\0028\0010\002\"\004\b\000\020\000\"\004\b\001\020\001*\b\022\004\022\0028\0000\0022\022\020\007\032\016\022\004\022\0028\000\022\004\022\0028\0010\006H\007\032@\020\b\032\b\022\004\022\0028\0010\002\"\004\b\000\020\000\"\004\b\001\020\001*\b\022\004\022\0028\0000\0022\032\020\004\032\026\022\004\022\0028\000\022\f\022\n\022\004\022\0028\001\030\0010\0020\003H\007\032>\020\b\032\b\022\004\022\0028\0010\002\"\004\b\000\020\000\"\004\b\001\020\001*\b\022\004\022\0028\0000\0022\030\020\t\032\024\022\004\022\0028\000\022\n\022\b\022\004\022\0028\0010\0020\006H\007\032\036\020\n\032\b\022\004\022\0028\0000\002\"\004\b\000\020\000*\b\022\004\022\0028\0000\002H\007¨\006\013"}, d2 = {"X", "Y", "Landroidx/lifecycle/LiveData;", "Lkotlin/Function1;", "transform", "map", "Landroidx/arch/core/util/Function;", "mapFunction", "switchMap", "switchMapFunction", "distinctUntilChanged", "lifecycle-livedata_release"}, k = 2, mv = {1, 8, 0})
public final class Transformations {
  @CheckResult
  @MainThread
  public static final <X> LiveData<X> distinctUntilChanged(LiveData<X> paramLiveData) {
    Intrinsics.checkNotNullParameter(paramLiveData, "<this>");
    MediatorLiveData<X> mediatorLiveData = new MediatorLiveData();
    Ref.BooleanRef booleanRef = new Ref.BooleanRef();
    booleanRef.element = true;
    if (paramLiveData.isInitialized()) {
      mediatorLiveData.setValue(paramLiveData.getValue());
      booleanRef.element = false;
    } 
    mediatorLiveData.addSource(paramLiveData, new Transformations$sam$androidx_lifecycle_Observer$0(new Transformations$distinctUntilChanged$1(mediatorLiveData, booleanRef)));
    return (LiveData<X>)mediatorLiveData;
  }
  
  @CheckResult
  @MainThread
  public static final <X, Y> LiveData<Y> map(LiveData<X> paramLiveData, Function1<X, Y> paramFunction1) {
    Intrinsics.checkNotNullParameter(paramLiveData, "<this>");
    Intrinsics.checkNotNullParameter(paramFunction1, "transform");
    MediatorLiveData<Y> mediatorLiveData = new MediatorLiveData();
    mediatorLiveData.addSource(paramLiveData, new Transformations$sam$androidx_lifecycle_Observer$0(new Transformations$map$1(mediatorLiveData, paramFunction1)));
    return (LiveData<Y>)mediatorLiveData;
  }
  
  @CheckResult
  @MainThread
  public static final <X, Y> LiveData<Y> switchMap(LiveData<X> paramLiveData, Function1<X, LiveData<Y>> paramFunction1) {
    Intrinsics.checkNotNullParameter(paramLiveData, "<this>");
    Intrinsics.checkNotNullParameter(paramFunction1, "transform");
    MediatorLiveData<Y> mediatorLiveData = new MediatorLiveData();
    mediatorLiveData.addSource(paramLiveData, new Transformations$switchMap$1(paramFunction1, mediatorLiveData));
    return (LiveData<Y>)mediatorLiveData;
  }
  
  @Metadata(d1 = {"\000\n\n\000\n\002\020\002\n\002\b\005\020\000\032\0020\001\"\004\b\000\020\0022\016\020\003\032\n \004*\004\030\001H\002H\002H\n¢\006\004\b\005\020\006"}, d2 = {"<anonymous>", "", "X", "value", "kotlin.jvm.PlatformType", "invoke", "(Ljava/lang/Object;)V"}, k = 3, mv = {1, 8, 0}, xi = 48)
  static final class Transformations$distinctUntilChanged$1 extends Lambda implements Function1<X, Unit> {
    Transformations$distinctUntilChanged$1(MediatorLiveData<X> param1MediatorLiveData, Ref.BooleanRef param1BooleanRef) {
      super(1);
    }
    
    public final void invoke(X param1X) {
      Object object = this.$outputLiveData.getValue();
      if (this.$firstTime.element || (object == null && param1X != null) || (object != null && !Intrinsics.areEqual(object, param1X))) {
        this.$firstTime.element = false;
        this.$outputLiveData.setValue(param1X);
      } 
    }
  }
  
  @Metadata(d1 = {"\000\n\n\000\n\002\020\002\n\002\b\006\020\000\032\0020\001\"\004\b\000\020\002\"\004\b\001\020\0032\016\020\004\032\n \005*\004\030\001H\002H\002H\n¢\006\004\b\006\020\007"}, d2 = {"<anonymous>", "", "X", "Y", "x", "kotlin.jvm.PlatformType", "invoke", "(Ljava/lang/Object;)V"}, k = 3, mv = {1, 8, 0}, xi = 48)
  static final class Transformations$map$1 extends Lambda implements Function1<X, Unit> {
    Transformations$map$1(MediatorLiveData<Y> param1MediatorLiveData, Function1<X, Y> param1Function1) {
      super(1);
    }
    
    public final void invoke(X param1X) {
      this.$result.setValue(this.$transform.invoke(param1X));
    }
  }
  
  @Metadata(d1 = {"\000\n\n\000\n\002\020\002\n\002\b\006\020\000\032\0020\001\"\004\b\000\020\002\"\004\b\001\020\0032\016\020\004\032\n \005*\004\030\001H\002H\002H\n¢\006\004\b\006\020\007"}, d2 = {"<anonymous>", "", "X", "Y", "x", "kotlin.jvm.PlatformType", "invoke", "(Ljava/lang/Object;)V"}, k = 3, mv = {1, 8, 0}, xi = 48)
  static final class Transformations$map$2 extends Lambda implements Function1 {
    Transformations$map$2(MediatorLiveData param1MediatorLiveData, Function param1Function) {
      super(1);
    }
    
    public final void invoke(Object param1Object) {
      this.$result.setValue(this.$mapFunction.apply(param1Object));
    }
  }
  
  @Metadata(d1 = {"\000\033\n\000\n\002\030\002\n\000\n\002\030\002\n\002\b\005\n\002\020\002\n\002\b\003*\001\000\b\n\030\0002\b\022\004\022\0028\0000\001J\025\020\b\032\0020\t2\006\020\n\032\0028\000H\026¢\006\002\020\013R\"\020\002\032\n\022\004\022\0028\001\030\0010\003X\016¢\006\016\n\000\032\004\b\004\020\005\"\004\b\006\020\007¨\006\f"}, d2 = {"androidx/lifecycle/Transformations$switchMap$1", "Landroidx/lifecycle/Observer;", "liveData", "Landroidx/lifecycle/LiveData;", "getLiveData", "()Landroidx/lifecycle/LiveData;", "setLiveData", "(Landroidx/lifecycle/LiveData;)V", "onChanged", "", "value", "(Ljava/lang/Object;)V", "lifecycle-livedata_release"}, k = 1, mv = {1, 8, 0}, xi = 48)
  public static final class Transformations$switchMap$1 implements Observer<X> {
    private LiveData<Y> liveData;
    
    Transformations$switchMap$1(Function1<X, LiveData<Y>> param1Function1, MediatorLiveData<Y> param1MediatorLiveData) {}
    
    public final LiveData<Y> getLiveData() {
      return this.liveData;
    }
    
    public void onChanged(X param1X) {
      LiveData<Y> liveData1 = (LiveData)this.$transform.invoke(param1X);
      LiveData<Y> liveData2 = this.liveData;
      if (liveData2 == liveData1)
        return; 
      if (liveData2 != null) {
        MediatorLiveData<Y> mediatorLiveData = this.$result;
        Intrinsics.checkNotNull(liveData2);
        mediatorLiveData.removeSource(liveData2);
      } 
      this.liveData = liveData1;
      if (liveData1 != null) {
        MediatorLiveData<Y> mediatorLiveData = this.$result;
        Intrinsics.checkNotNull(liveData1);
        mediatorLiveData.addSource(liveData1, new Transformations$sam$androidx_lifecycle_Observer$0(new Transformations$switchMap$1$onChanged$1(this.$result)));
      } 
    }
    
    public final void setLiveData(LiveData<Y> param1LiveData) {
      this.liveData = param1LiveData;
    }
    
    @Metadata(d1 = {"\000\n\n\000\n\002\020\002\n\002\b\006\020\000\032\0020\001\"\004\b\000\020\002\"\004\b\001\020\0032\016\020\004\032\n \005*\004\030\001H\003H\003H\n¢\006\004\b\006\020\007"}, d2 = {"<anonymous>", "", "X", "Y", "y", "kotlin.jvm.PlatformType", "invoke", "(Ljava/lang/Object;)V"}, k = 3, mv = {1, 8, 0}, xi = 48)
    static final class Transformations$switchMap$1$onChanged$1 extends Lambda implements Function1<Y, Unit> {
      Transformations$switchMap$1$onChanged$1(MediatorLiveData<Y> param1MediatorLiveData) {
        super(1);
      }
      
      public final void invoke(Y param1Y) {
        this.$result.setValue(param1Y);
      }
    }
  }
  
  @Metadata(d1 = {"\000\n\n\000\n\002\020\002\n\002\b\006\020\000\032\0020\001\"\004\b\000\020\002\"\004\b\001\020\0032\016\020\004\032\n \005*\004\030\001H\003H\003H\n¢\006\004\b\006\020\007"}, d2 = {"<anonymous>", "", "X", "Y", "y", "kotlin.jvm.PlatformType", "invoke", "(Ljava/lang/Object;)V"}, k = 3, mv = {1, 8, 0}, xi = 48)
  static final class Transformations$switchMap$1$onChanged$1 extends Lambda implements Function1<Y, Unit> {
    Transformations$switchMap$1$onChanged$1(MediatorLiveData<Y> param1MediatorLiveData) {
      super(1);
    }
    
    public final void invoke(Y param1Y) {
      this.$result.setValue(param1Y);
    }
  }
  
  @Metadata(d1 = {"\000\033\n\000\n\002\030\002\n\000\n\002\030\002\n\002\b\005\n\002\020\002\n\002\b\003*\001\000\b\n\030\0002\b\022\004\022\0028\0000\001J\025\020\b\032\0020\t2\006\020\n\032\0028\000H\026¢\006\002\020\013R\"\020\002\032\n\022\004\022\0028\001\030\0010\003X\016¢\006\016\n\000\032\004\b\004\020\005\"\004\b\006\020\007¨\006\f"}, d2 = {"androidx/lifecycle/Transformations$switchMap$2", "Landroidx/lifecycle/Observer;", "liveData", "Landroidx/lifecycle/LiveData;", "getLiveData", "()Landroidx/lifecycle/LiveData;", "setLiveData", "(Landroidx/lifecycle/LiveData;)V", "onChanged", "", "value", "(Ljava/lang/Object;)V", "lifecycle-livedata_release"}, k = 1, mv = {1, 8, 0}, xi = 48)
  public static final class Transformations$switchMap$2 implements Observer {
    private LiveData liveData;
    
    Transformations$switchMap$2(Function param1Function, MediatorLiveData param1MediatorLiveData) {}
    
    public final LiveData getLiveData() {
      return this.liveData;
    }
    
    public void onChanged(Object param1Object) {
      param1Object = this.$switchMapFunction.apply(param1Object);
      LiveData liveData = this.liveData;
      if (liveData == param1Object)
        return; 
      if (liveData != null) {
        MediatorLiveData mediatorLiveData = this.$result;
        Intrinsics.checkNotNull(liveData);
        mediatorLiveData.removeSource(liveData);
      } 
      this.liveData = (LiveData)param1Object;
      if (param1Object != null) {
        MediatorLiveData mediatorLiveData = this.$result;
        Intrinsics.checkNotNull(param1Object);
        mediatorLiveData.addSource((LiveData)param1Object, new Transformations$sam$androidx_lifecycle_Observer$0(new Transformations$switchMap$2$onChanged$1(this.$result)));
      } 
    }
    
    public final void setLiveData(LiveData param1LiveData) {
      this.liveData = param1LiveData;
    }
    
    @Metadata(d1 = {"\000\n\n\000\n\002\020\002\n\002\b\006\020\000\032\0020\001\"\004\b\000\020\002\"\004\b\001\020\0032\016\020\004\032\n \005*\004\030\001H\003H\003H\n¢\006\004\b\006\020\007"}, d2 = {"<anonymous>", "", "X", "Y", "y", "kotlin.jvm.PlatformType", "invoke", "(Ljava/lang/Object;)V"}, k = 3, mv = {1, 8, 0}, xi = 48)
    static final class Transformations$switchMap$2$onChanged$1 extends Lambda implements Function1 {
      Transformations$switchMap$2$onChanged$1(MediatorLiveData param1MediatorLiveData) {
        super(1);
      }
      
      public final void invoke(Object param1Object) {
        this.$result.setValue(param1Object);
      }
    }
  }
  
  @Metadata(d1 = {"\000\n\n\000\n\002\020\002\n\002\b\006\020\000\032\0020\001\"\004\b\000\020\002\"\004\b\001\020\0032\016\020\004\032\n \005*\004\030\001H\003H\003H\n¢\006\004\b\006\020\007"}, d2 = {"<anonymous>", "", "X", "Y", "y", "kotlin.jvm.PlatformType", "invoke", "(Ljava/lang/Object;)V"}, k = 3, mv = {1, 8, 0}, xi = 48)
  static final class Transformations$switchMap$2$onChanged$1 extends Lambda implements Function1 {
    Transformations$switchMap$2$onChanged$1(MediatorLiveData param1MediatorLiveData) {
      super(1);
    }
    
    public final void invoke(Object param1Object) {
      this.$result.setValue(param1Object);
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\MagicAI - AI Art & Anime Art-dex2jar.jar!\androidx\lifecycle\Transformations.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */