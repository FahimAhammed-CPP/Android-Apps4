package androidx.lifecycle;

import kotlin.Metadata;
import kotlin.ResultKt;
import kotlin.Unit;
import kotlin.coroutines.Continuation;
import kotlin.coroutines.CoroutineContext;
import kotlin.coroutines.intrinsics.IntrinsicsKt;
import kotlin.coroutines.jvm.internal.DebugMetadata;
import kotlin.coroutines.jvm.internal.SuspendLambda;
import kotlin.jvm.functions.Function2;
import kotlin.jvm.internal.Intrinsics;
import kotlinx.coroutines.BuildersKt;
import kotlinx.coroutines.CoroutineScope;
import kotlinx.coroutines.Job;

@Metadata(d1 = {"\000*\n\002\030\002\n\002\030\002\n\002\030\002\n\002\030\002\n\002\020\002\n\002\020\000\n\000\n\002\030\002\n\002\b\004\n\002\030\002\n\002\b\006\b&\030\0002\0020\001B\t\b\000¢\006\004\b\020\020\021J6\020\b\032\0020\0072\"\020\006\032\036\b\001\022\004\022\0020\001\022\n\022\b\022\004\022\0020\0040\003\022\006\022\004\030\0010\0050\002H\007ø\001\000¢\006\004\b\b\020\tJ6\020\n\032\0020\0072\"\020\006\032\036\b\001\022\004\022\0020\001\022\n\022\b\022\004\022\0020\0040\003\022\006\022\004\030\0010\0050\002H\007ø\001\000¢\006\004\b\n\020\tJ6\020\013\032\0020\0072\"\020\006\032\036\b\001\022\004\022\0020\001\022\n\022\b\022\004\022\0020\0040\003\022\006\022\004\030\0010\0050\002H\007ø\001\000¢\006\004\b\013\020\tR\024\020\017\032\0020\f8 X \004¢\006\006\032\004\b\r\020\016\002\004\n\002\b\031¨\006\022"}, d2 = {"Landroidx/lifecycle/LifecycleCoroutineScope;", "Lkotlinx/coroutines/CoroutineScope;", "Lkotlin/Function2;", "Lkotlin/coroutines/Continuation;", "", "", "block", "Lkotlinx/coroutines/Job;", "launchWhenCreated", "(Lkotlin/jvm/functions/Function2;)Lkotlinx/coroutines/Job;", "launchWhenStarted", "launchWhenResumed", "Landroidx/lifecycle/Lifecycle;", "getLifecycle$lifecycle_common", "()Landroidx/lifecycle/Lifecycle;", "lifecycle", "<init>", "()V", "lifecycle-common"}, k = 1, mv = {1, 8, 0})
public abstract class LifecycleCoroutineScope implements CoroutineScope {
  public abstract Lifecycle getLifecycle$lifecycle_common();
  
  public final Job launchWhenCreated(Function2<? super CoroutineScope, ? super Continuation<? super Unit>, ? extends Object> paramFunction2) {
    Intrinsics.checkNotNullParameter(paramFunction2, "block");
    return BuildersKt.launch$default(this, null, null, new LifecycleCoroutineScope$launchWhenCreated$1(paramFunction2, null), 3, null);
  }
  
  public final Job launchWhenResumed(Function2<? super CoroutineScope, ? super Continuation<? super Unit>, ? extends Object> paramFunction2) {
    Intrinsics.checkNotNullParameter(paramFunction2, "block");
    return BuildersKt.launch$default(this, null, null, new LifecycleCoroutineScope$launchWhenResumed$1(paramFunction2, null), 3, null);
  }
  
  public final Job launchWhenStarted(Function2<? super CoroutineScope, ? super Continuation<? super Unit>, ? extends Object> paramFunction2) {
    Intrinsics.checkNotNullParameter(paramFunction2, "block");
    return BuildersKt.launch$default(this, null, null, new LifecycleCoroutineScope$launchWhenStarted$1(paramFunction2, null), 3, null);
  }
  
  @Metadata(d1 = {"\000\n\n\002\030\002\n\002\020\002\n\000\020\002\032\0020\001*\0020\000H@"}, d2 = {"Lkotlinx/coroutines/CoroutineScope;", "", "<anonymous>"}, k = 3, mv = {1, 8, 0})
  @DebugMetadata(c = "androidx.lifecycle.LifecycleCoroutineScope$launchWhenCreated$1", f = "Lifecycle.kt", l = {337}, m = "invokeSuspend")
  static final class LifecycleCoroutineScope$launchWhenCreated$1 extends SuspendLambda implements Function2<CoroutineScope, Continuation<? super Unit>, Object> {
    int label;
    
    LifecycleCoroutineScope$launchWhenCreated$1(Function2<? super CoroutineScope, ? super Continuation<? super Unit>, ? extends Object> param1Function2, Continuation<? super LifecycleCoroutineScope$launchWhenCreated$1> param1Continuation) {
      super(2, param1Continuation);
    }
    
    public final Continuation<Unit> create(Object param1Object, Continuation<?> param1Continuation) {
      return (Continuation<Unit>)new LifecycleCoroutineScope$launchWhenCreated$1(this.$block, (Continuation)param1Continuation);
    }
    
    public final Object invoke(CoroutineScope param1CoroutineScope, Continuation<? super Unit> param1Continuation) {
      return ((LifecycleCoroutineScope$launchWhenCreated$1)create(param1CoroutineScope, param1Continuation)).invokeSuspend(Unit.INSTANCE);
    }
    
    public final Object invokeSuspend(Object param1Object) {
      Object object = IntrinsicsKt.getCOROUTINE_SUSPENDED();
      int i = this.label;
      if (i != 0) {
        if (i == 1) {
          ResultKt.throwOnFailure(param1Object);
        } else {
          throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
        } 
      } else {
        ResultKt.throwOnFailure(param1Object);
        param1Object = LifecycleCoroutineScope.this.getLifecycle$lifecycle_common();
        Function2<CoroutineScope, Continuation<? super Unit>, Object> function2 = this.$block;
        this.label = 1;
        if (PausingDispatcherKt.whenCreated((Lifecycle)param1Object, function2, (Continuation)this) == object)
          return object; 
      } 
      return Unit.INSTANCE;
    }
  }
  
  @Metadata(d1 = {"\000\n\n\002\030\002\n\002\020\002\n\000\020\002\032\0020\001*\0020\000H@"}, d2 = {"Lkotlinx/coroutines/CoroutineScope;", "", "<anonymous>"}, k = 3, mv = {1, 8, 0})
  @DebugMetadata(c = "androidx.lifecycle.LifecycleCoroutineScope$launchWhenResumed$1", f = "Lifecycle.kt", l = {375}, m = "invokeSuspend")
  static final class LifecycleCoroutineScope$launchWhenResumed$1 extends SuspendLambda implements Function2<CoroutineScope, Continuation<? super Unit>, Object> {
    int label;
    
    LifecycleCoroutineScope$launchWhenResumed$1(Function2<? super CoroutineScope, ? super Continuation<? super Unit>, ? extends Object> param1Function2, Continuation<? super LifecycleCoroutineScope$launchWhenResumed$1> param1Continuation) {
      super(2, param1Continuation);
    }
    
    public final Continuation<Unit> create(Object param1Object, Continuation<?> param1Continuation) {
      return (Continuation<Unit>)new LifecycleCoroutineScope$launchWhenResumed$1(this.$block, (Continuation)param1Continuation);
    }
    
    public final Object invoke(CoroutineScope param1CoroutineScope, Continuation<? super Unit> param1Continuation) {
      return ((LifecycleCoroutineScope$launchWhenResumed$1)create(param1CoroutineScope, param1Continuation)).invokeSuspend(Unit.INSTANCE);
    }
    
    public final Object invokeSuspend(Object param1Object) {
      Object object = IntrinsicsKt.getCOROUTINE_SUSPENDED();
      int i = this.label;
      if (i != 0) {
        if (i == 1) {
          ResultKt.throwOnFailure(param1Object);
        } else {
          throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
        } 
      } else {
        ResultKt.throwOnFailure(param1Object);
        param1Object = LifecycleCoroutineScope.this.getLifecycle$lifecycle_common();
        Function2<CoroutineScope, Continuation<? super Unit>, Object> function2 = this.$block;
        this.label = 1;
        if (PausingDispatcherKt.whenResumed((Lifecycle)param1Object, function2, (Continuation)this) == object)
          return object; 
      } 
      return Unit.INSTANCE;
    }
  }
  
  @Metadata(d1 = {"\000\n\n\002\030\002\n\002\020\002\n\000\020\002\032\0020\001*\0020\000H@"}, d2 = {"Lkotlinx/coroutines/CoroutineScope;", "", "<anonymous>"}, k = 3, mv = {1, 8, 0})
  @DebugMetadata(c = "androidx.lifecycle.LifecycleCoroutineScope$launchWhenStarted$1", f = "Lifecycle.kt", l = {356}, m = "invokeSuspend")
  static final class LifecycleCoroutineScope$launchWhenStarted$1 extends SuspendLambda implements Function2<CoroutineScope, Continuation<? super Unit>, Object> {
    int label;
    
    LifecycleCoroutineScope$launchWhenStarted$1(Function2<? super CoroutineScope, ? super Continuation<? super Unit>, ? extends Object> param1Function2, Continuation<? super LifecycleCoroutineScope$launchWhenStarted$1> param1Continuation) {
      super(2, param1Continuation);
    }
    
    public final Continuation<Unit> create(Object param1Object, Continuation<?> param1Continuation) {
      return (Continuation<Unit>)new LifecycleCoroutineScope$launchWhenStarted$1(this.$block, (Continuation)param1Continuation);
    }
    
    public final Object invoke(CoroutineScope param1CoroutineScope, Continuation<? super Unit> param1Continuation) {
      return ((LifecycleCoroutineScope$launchWhenStarted$1)create(param1CoroutineScope, param1Continuation)).invokeSuspend(Unit.INSTANCE);
    }
    
    public final Object invokeSuspend(Object param1Object) {
      Object object = IntrinsicsKt.getCOROUTINE_SUSPENDED();
      int i = this.label;
      if (i != 0) {
        if (i == 1) {
          ResultKt.throwOnFailure(param1Object);
        } else {
          throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
        } 
      } else {
        ResultKt.throwOnFailure(param1Object);
        param1Object = LifecycleCoroutineScope.this.getLifecycle$lifecycle_common();
        Function2<CoroutineScope, Continuation<? super Unit>, Object> function2 = this.$block;
        this.label = 1;
        if (PausingDispatcherKt.whenStarted((Lifecycle)param1Object, function2, (Continuation)this) == object)
          return object; 
      } 
      return Unit.INSTANCE;
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\MagicAI - AI Art & Anime Art-dex2jar.jar!\androidx\lifecycle\LifecycleCoroutineScope.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */