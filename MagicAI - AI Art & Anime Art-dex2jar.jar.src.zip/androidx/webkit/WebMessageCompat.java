package androidx.webkit;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.annotation.RestrictTo;
import j$.util.Objects;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;

public class WebMessageCompat {
  @RestrictTo({RestrictTo.Scope.LIBRARY_GROUP})
  public static final int TYPE_ARRAY_BUFFER = 1;
  
  @RestrictTo({RestrictTo.Scope.LIBRARY_GROUP})
  public static final int TYPE_STRING = 0;
  
  @Nullable
  private final byte[] mArrayBuffer;
  
  @Nullable
  private final WebMessagePortCompat[] mPorts;
  
  @Nullable
  private final String mString;
  
  private final int mType;
  
  public WebMessageCompat(@Nullable String paramString) {
    this(paramString, (WebMessagePortCompat[])null);
  }
  
  public WebMessageCompat(@Nullable String paramString, @Nullable WebMessagePortCompat[] paramArrayOfWebMessagePortCompat) {
    this.mString = paramString;
    this.mArrayBuffer = null;
    this.mPorts = paramArrayOfWebMessagePortCompat;
    this.mType = 0;
  }
  
  @RestrictTo({RestrictTo.Scope.LIBRARY_GROUP})
  public WebMessageCompat(@NonNull byte[] paramArrayOfbyte) {
    this(paramArrayOfbyte, (WebMessagePortCompat[])null);
  }
  
  @RestrictTo({RestrictTo.Scope.LIBRARY_GROUP})
  public WebMessageCompat(@NonNull byte[] paramArrayOfbyte, @Nullable WebMessagePortCompat[] paramArrayOfWebMessagePortCompat) {
    Objects.requireNonNull(paramArrayOfbyte);
    this.mArrayBuffer = paramArrayOfbyte;
    this.mString = null;
    this.mPorts = paramArrayOfWebMessagePortCompat;
    this.mType = 1;
  }
  
  @Nullable
  @RestrictTo({RestrictTo.Scope.LIBRARY_GROUP})
  public byte[] getArrayBuffer() {
    return this.mArrayBuffer;
  }
  
  @Nullable
  public String getData() {
    return this.mString;
  }
  
  @Nullable
  public WebMessagePortCompat[] getPorts() {
    return this.mPorts;
  }
  
  @RestrictTo({RestrictTo.Scope.LIBRARY_GROUP})
  public int getType() {
    return this.mType;
  }
  
  @Retention(RetentionPolicy.SOURCE)
  @RestrictTo({RestrictTo.Scope.LIBRARY_GROUP})
  public static @interface Type {}
}


/* Location:              C:\soft\dex2jar-2.0\MagicAI - AI Art & Anime Art-dex2jar.jar!\androidx\webkit\WebMessageCompat.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */