package androidx.webkit.internal;

import android.content.Context;
import android.net.Uri;
import android.webkit.SafeBrowsingResponse;
import android.webkit.ValueCallback;
import androidx.annotation.DoNotInline;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.annotation.RequiresApi;
import java.util.List;

@RequiresApi(27)
public class ApiHelperForOMR1 {
  @DoNotInline
  public static void backToSafety(@NonNull SafeBrowsingResponse paramSafeBrowsingResponse, boolean paramBoolean) {
    ApiHelperForOMR1$.ExternalSyntheticApiModelOutline3.m(paramSafeBrowsingResponse, paramBoolean);
  }
  
  @DoNotInline
  @NonNull
  public static Uri getSafeBrowsingPrivacyPolicyUrl() {
    return ApiHelperForOMR1$.ExternalSyntheticApiModelOutline5.m();
  }
  
  @DoNotInline
  public static void proceed(@NonNull SafeBrowsingResponse paramSafeBrowsingResponse, boolean paramBoolean) {
    ApiHelperForOMR1$.ExternalSyntheticApiModelOutline0.m(paramSafeBrowsingResponse, paramBoolean);
  }
  
  @DoNotInline
  public static void setSafeBrowsingWhitelist(@NonNull List<String> paramList, @Nullable ValueCallback<Boolean> paramValueCallback) {
    ApiHelperForOMR1$.ExternalSyntheticApiModelOutline1.m(paramList, paramValueCallback);
  }
  
  @DoNotInline
  public static void showInterstitial(@NonNull SafeBrowsingResponse paramSafeBrowsingResponse, boolean paramBoolean) {
    ApiHelperForOMR1$.ExternalSyntheticApiModelOutline4.m(paramSafeBrowsingResponse, paramBoolean);
  }
  
  @DoNotInline
  public static void startSafeBrowsing(@NonNull Context paramContext, @Nullable ValueCallback<Boolean> paramValueCallback) {
    ApiHelperForOMR1$.ExternalSyntheticApiModelOutline2.m(paramContext, paramValueCallback);
  }
}


/* Location:              C:\soft\dex2jar-2.0\MagicAI - AI Art & Anime Art-dex2jar.jar!\androidx\webkit\internal\ApiHelperForOMR1.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */