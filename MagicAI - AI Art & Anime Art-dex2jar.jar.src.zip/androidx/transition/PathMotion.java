package androidx.transition;

import android.content.Context;
import android.graphics.Path;
import android.util.AttributeSet;
import androidx.annotation.NonNull;

public abstract class PathMotion {
  public PathMotion() {}
  
  public PathMotion(@NonNull Context paramContext, @NonNull AttributeSet paramAttributeSet) {}
  
  @NonNull
  public abstract Path getPath(float paramFloat1, float paramFloat2, float paramFloat3, float paramFloat4);
}


/* Location:              C:\soft\dex2jar-2.0\MagicAI - AI Art & Anime Art-dex2jar.jar!\androidx\transition\PathMotion.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */