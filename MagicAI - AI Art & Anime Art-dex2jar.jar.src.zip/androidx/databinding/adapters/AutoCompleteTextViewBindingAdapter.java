package androidx.databinding.adapters;

import android.widget.AdapterView;
import android.widget.AutoCompleteTextView;
import androidx.annotation.RestrictTo;
import androidx.databinding.BindingAdapter;
import androidx.databinding.BindingMethod;
import androidx.databinding.BindingMethods;

@RestrictTo({RestrictTo.Scope.LIBRARY})
@BindingMethods({@BindingMethod(attribute = "android:completionThreshold", method = "setThreshold", type = AutoCompleteTextView.class), @BindingMethod(attribute = "android:popupBackground", method = "setDropDownBackgroundDrawable", type = AutoCompleteTextView.class), @BindingMethod(attribute = "android:onDismiss", method = "setOnDismissListener", type = AutoCompleteTextView.class), @BindingMethod(attribute = "android:onItemClick", method = "setOnItemClickListener", type = AutoCompleteTextView.class)})
public class AutoCompleteTextViewBindingAdapter {
  @BindingAdapter(requireAll = false, value = {"android:onItemSelected", "android:onNothingSelected"})
  public static void setOnItemSelectedListener(AutoCompleteTextView paramAutoCompleteTextView, AdapterViewBindingAdapter.OnItemSelected paramOnItemSelected, AdapterViewBindingAdapter.OnNothingSelected paramOnNothingSelected) {
    if (paramOnItemSelected == null && paramOnNothingSelected == null) {
      paramAutoCompleteTextView.setOnItemSelectedListener(null);
      return;
    } 
    paramAutoCompleteTextView.setOnItemSelectedListener((AdapterView.OnItemSelectedListener)new AdapterViewBindingAdapter.OnItemSelectedComponentListener(paramOnItemSelected, paramOnNothingSelected, null));
  }
  
  @BindingAdapter(requireAll = false, value = {"android:fixText", "android:isValid"})
  public static void setValidator(AutoCompleteTextView paramAutoCompleteTextView, final FixText fixText, final IsValid isValid) {
    if (fixText == null && isValid == null) {
      paramAutoCompleteTextView.setValidator(null);
      return;
    } 
    paramAutoCompleteTextView.setValidator(new AutoCompleteTextView.Validator() {
          public CharSequence fixText(CharSequence param1CharSequence) {
            AutoCompleteTextViewBindingAdapter.FixText fixText = fixText;
            CharSequence charSequence = param1CharSequence;
            if (fixText != null)
              charSequence = fixText.fixText(param1CharSequence); 
            return charSequence;
          }
          
          public boolean isValid(CharSequence param1CharSequence) {
            AutoCompleteTextViewBindingAdapter.IsValid isValid = isValid;
            return (isValid != null) ? isValid.isValid(param1CharSequence) : true;
          }
        });
  }
  
  public static interface FixText {
    CharSequence fixText(CharSequence param1CharSequence);
  }
  
  public static interface IsValid {
    boolean isValid(CharSequence param1CharSequence);
  }
}


/* Location:              C:\soft\dex2jar-2.0\MagicAI - AI Art & Anime Art-dex2jar.jar!\androidx\databinding\adapters\AutoCompleteTextViewBindingAdapter.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */