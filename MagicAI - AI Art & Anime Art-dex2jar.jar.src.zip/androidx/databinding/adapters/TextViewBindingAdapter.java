package androidx.databinding.adapters;

import android.graphics.drawable.Drawable;
import android.text.Editable;
import android.text.InputFilter;
import android.text.TextWatcher;
import android.text.method.DialerKeyListener;
import android.text.method.DigitsKeyListener;
import android.text.method.KeyListener;
import android.text.method.PasswordTransformationMethod;
import android.text.method.TextKeyListener;
import android.text.method.TransformationMethod;
import android.util.Log;
import android.view.View;
import android.widget.TextView;
import androidx.annotation.RestrictTo;
import androidx.databinding.BindingAdapter;
import androidx.databinding.BindingMethod;
import androidx.databinding.BindingMethods;
import androidx.databinding.InverseBindingAdapter;
import androidx.databinding.InverseBindingListener;
import androidx.databinding.library.baseAdapters.R;

@RestrictTo({RestrictTo.Scope.LIBRARY})
@BindingMethods({@BindingMethod(attribute = "android:autoLink", method = "setAutoLinkMask", type = TextView.class), @BindingMethod(attribute = "android:drawablePadding", method = "setCompoundDrawablePadding", type = TextView.class), @BindingMethod(attribute = "android:editorExtras", method = "setInputExtras", type = TextView.class), @BindingMethod(attribute = "android:inputType", method = "setRawInputType", type = TextView.class), @BindingMethod(attribute = "android:scrollHorizontally", method = "setHorizontallyScrolling", type = TextView.class), @BindingMethod(attribute = "android:textAllCaps", method = "setAllCaps", type = TextView.class), @BindingMethod(attribute = "android:textColorHighlight", method = "setHighlightColor", type = TextView.class), @BindingMethod(attribute = "android:textColorHint", method = "setHintTextColor", type = TextView.class), @BindingMethod(attribute = "android:textColorLink", method = "setLinkTextColor", type = TextView.class), @BindingMethod(attribute = "android:onEditorAction", method = "setOnEditorActionListener", type = TextView.class)})
public class TextViewBindingAdapter {
  public static final int DECIMAL = 5;
  
  public static final int INTEGER = 1;
  
  public static final int SIGNED = 3;
  
  private static final String TAG = "TextViewBindingAdapters";
  
  @InverseBindingAdapter(attribute = "android:text", event = "android:textAttrChanged")
  public static String getTextString(TextView paramTextView) {
    return paramTextView.getText().toString();
  }
  
  private static boolean haveContentsChanged(CharSequence paramCharSequence1, CharSequence paramCharSequence2) {
    if (paramCharSequence1 == null) {
      i = 1;
    } else {
      i = 0;
    } 
    if (paramCharSequence2 == null) {
      j = 1;
    } else {
      j = 0;
    } 
    if (i != j)
      return true; 
    if (paramCharSequence1 == null)
      return false; 
    int j = paramCharSequence1.length();
    if (j != paramCharSequence2.length())
      return true; 
    for (int i = 0; i < j; i++) {
      if (paramCharSequence1.charAt(i) != paramCharSequence2.charAt(i))
        return true; 
    } 
    return false;
  }
  
  @BindingAdapter({"android:autoText"})
  public static void setAutoText(TextView paramTextView, boolean paramBoolean) {
    boolean bool;
    KeyListener keyListener = paramTextView.getKeyListener();
    TextKeyListener.Capitalize capitalize = TextKeyListener.Capitalize.NONE;
    if (keyListener != null) {
      bool = keyListener.getInputType();
    } else {
      bool = false;
    } 
    if ((bool & 0x1000) != 0) {
      capitalize = TextKeyListener.Capitalize.CHARACTERS;
    } else if ((bool & 0x2000) != 0) {
      capitalize = TextKeyListener.Capitalize.WORDS;
    } else if ((bool & 0x4000) != 0) {
      capitalize = TextKeyListener.Capitalize.SENTENCES;
    } 
    paramTextView.setKeyListener((KeyListener)TextKeyListener.getInstance(paramBoolean, capitalize));
  }
  
  @BindingAdapter({"android:bufferType"})
  public static void setBufferType(TextView paramTextView, TextView.BufferType paramBufferType) {
    paramTextView.setText(paramTextView.getText(), paramBufferType);
  }
  
  @BindingAdapter({"android:capitalize"})
  public static void setCapitalize(TextView paramTextView, TextKeyListener.Capitalize paramCapitalize) {
    boolean bool;
    if ((paramTextView.getKeyListener().getInputType() & 0x8000) != 0) {
      bool = true;
    } else {
      bool = false;
    } 
    paramTextView.setKeyListener((KeyListener)TextKeyListener.getInstance(bool, paramCapitalize));
  }
  
  @BindingAdapter({"android:digits"})
  public static void setDigits(TextView paramTextView, CharSequence paramCharSequence) {
    if (paramCharSequence != null) {
      paramTextView.setKeyListener((KeyListener)DigitsKeyListener.getInstance(paramCharSequence.toString()));
      return;
    } 
    if (paramTextView.getKeyListener() instanceof DigitsKeyListener)
      paramTextView.setKeyListener(null); 
  }
  
  @BindingAdapter({"android:drawableBottom"})
  public static void setDrawableBottom(TextView paramTextView, Drawable paramDrawable) {
    setIntrinsicBounds(paramDrawable);
    Drawable[] arrayOfDrawable = paramTextView.getCompoundDrawables();
    paramTextView.setCompoundDrawables(arrayOfDrawable[0], arrayOfDrawable[1], arrayOfDrawable[2], paramDrawable);
  }
  
  @BindingAdapter({"android:drawableEnd"})
  public static void setDrawableEnd(TextView paramTextView, Drawable paramDrawable) {
    setIntrinsicBounds(paramDrawable);
    Drawable[] arrayOfDrawable = paramTextView.getCompoundDrawablesRelative();
    paramTextView.setCompoundDrawablesRelative(arrayOfDrawable[0], arrayOfDrawable[1], paramDrawable, arrayOfDrawable[3]);
  }
  
  @BindingAdapter({"android:drawableLeft"})
  public static void setDrawableLeft(TextView paramTextView, Drawable paramDrawable) {
    setIntrinsicBounds(paramDrawable);
    Drawable[] arrayOfDrawable = paramTextView.getCompoundDrawables();
    paramTextView.setCompoundDrawables(paramDrawable, arrayOfDrawable[1], arrayOfDrawable[2], arrayOfDrawable[3]);
  }
  
  @BindingAdapter({"android:drawableRight"})
  public static void setDrawableRight(TextView paramTextView, Drawable paramDrawable) {
    setIntrinsicBounds(paramDrawable);
    Drawable[] arrayOfDrawable = paramTextView.getCompoundDrawables();
    paramTextView.setCompoundDrawables(arrayOfDrawable[0], arrayOfDrawable[1], paramDrawable, arrayOfDrawable[3]);
  }
  
  @BindingAdapter({"android:drawableStart"})
  public static void setDrawableStart(TextView paramTextView, Drawable paramDrawable) {
    setIntrinsicBounds(paramDrawable);
    Drawable[] arrayOfDrawable = paramTextView.getCompoundDrawablesRelative();
    paramTextView.setCompoundDrawablesRelative(paramDrawable, arrayOfDrawable[1], arrayOfDrawable[2], arrayOfDrawable[3]);
  }
  
  @BindingAdapter({"android:drawableTop"})
  public static void setDrawableTop(TextView paramTextView, Drawable paramDrawable) {
    setIntrinsicBounds(paramDrawable);
    Drawable[] arrayOfDrawable = paramTextView.getCompoundDrawables();
    paramTextView.setCompoundDrawables(arrayOfDrawable[0], paramDrawable, arrayOfDrawable[2], arrayOfDrawable[3]);
  }
  
  @BindingAdapter({"android:imeActionId"})
  public static void setImeActionLabel(TextView paramTextView, int paramInt) {
    paramTextView.setImeActionLabel(paramTextView.getImeActionLabel(), paramInt);
  }
  
  @BindingAdapter({"android:imeActionLabel"})
  public static void setImeActionLabel(TextView paramTextView, CharSequence paramCharSequence) {
    paramTextView.setImeActionLabel(paramCharSequence, paramTextView.getImeActionId());
  }
  
  @BindingAdapter({"android:inputMethod"})
  public static void setInputMethod(TextView paramTextView, CharSequence paramCharSequence) {
    try {
      paramTextView.setKeyListener((KeyListener)Class.forName(paramCharSequence.toString()).newInstance());
      return;
    } catch (ClassNotFoundException classNotFoundException) {
      StringBuilder stringBuilder = new StringBuilder();
      stringBuilder.append("Could not create input method: ");
      stringBuilder.append(paramCharSequence);
      Log.e("TextViewBindingAdapters", stringBuilder.toString(), classNotFoundException);
      return;
    } catch (InstantiationException instantiationException) {
      StringBuilder stringBuilder = new StringBuilder();
      stringBuilder.append("Could not create input method: ");
      stringBuilder.append(paramCharSequence);
      Log.e("TextViewBindingAdapters", stringBuilder.toString(), instantiationException);
      return;
    } catch (IllegalAccessException illegalAccessException) {
      StringBuilder stringBuilder = new StringBuilder();
      stringBuilder.append("Could not create input method: ");
      stringBuilder.append(paramCharSequence);
      Log.e("TextViewBindingAdapters", stringBuilder.toString(), illegalAccessException);
      return;
    } 
  }
  
  private static void setIntrinsicBounds(Drawable paramDrawable) {
    if (paramDrawable != null)
      paramDrawable.setBounds(0, 0, paramDrawable.getIntrinsicWidth(), paramDrawable.getIntrinsicHeight()); 
  }
  
  @BindingAdapter({"android:lineSpacingExtra"})
  public static void setLineSpacingExtra(TextView paramTextView, float paramFloat) {
    paramTextView.setLineSpacing(paramFloat, paramTextView.getLineSpacingMultiplier());
  }
  
  @BindingAdapter({"android:lineSpacingMultiplier"})
  public static void setLineSpacingMultiplier(TextView paramTextView, float paramFloat) {
    paramTextView.setLineSpacing(paramTextView.getLineSpacingExtra(), paramFloat);
  }
  
  @BindingAdapter({"android:maxLength"})
  public static void setMaxLength(TextView paramTextView, int paramInt) {
    InputFilter[] arrayOfInputFilter1;
    InputFilter[] arrayOfInputFilter2 = paramTextView.getFilters();
    if (arrayOfInputFilter2 == null) {
      arrayOfInputFilter1 = new InputFilter[1];
      arrayOfInputFilter1[0] = (InputFilter)new InputFilter.LengthFilter(paramInt);
    } else {
      int i = 0;
      while (true) {
        if (i < arrayOfInputFilter2.length) {
          InputFilter inputFilter = arrayOfInputFilter2[i];
          if (inputFilter instanceof InputFilter.LengthFilter) {
            boolean bool;
            if (((InputFilter.LengthFilter)inputFilter).getMax() != paramInt) {
              bool = true;
            } else {
              bool = false;
            } 
            if (bool)
              arrayOfInputFilter2[i] = (InputFilter)new InputFilter.LengthFilter(paramInt); 
            i = 1;
            break;
          } 
          i++;
          continue;
        } 
        i = 0;
        break;
      } 
      arrayOfInputFilter1 = arrayOfInputFilter2;
      if (i == 0) {
        i = arrayOfInputFilter2.length + 1;
        arrayOfInputFilter1 = new InputFilter[i];
        System.arraycopy(arrayOfInputFilter2, 0, arrayOfInputFilter1, 0, arrayOfInputFilter2.length);
        arrayOfInputFilter1[i - 1] = (InputFilter)new InputFilter.LengthFilter(paramInt);
      } 
    } 
    paramTextView.setFilters(arrayOfInputFilter1);
  }
  
  @BindingAdapter({"android:numeric"})
  public static void setNumeric(TextView paramTextView, int paramInt) {
    boolean bool1;
    boolean bool2 = true;
    if ((paramInt & 0x3) != 0) {
      bool1 = true;
    } else {
      bool1 = false;
    } 
    if ((paramInt & 0x5) == 0)
      bool2 = false; 
    paramTextView.setKeyListener((KeyListener)DigitsKeyListener.getInstance(bool1, bool2));
  }
  
  @BindingAdapter({"android:password"})
  public static void setPassword(TextView paramTextView, boolean paramBoolean) {
    if (paramBoolean) {
      paramTextView.setTransformationMethod((TransformationMethod)PasswordTransformationMethod.getInstance());
      return;
    } 
    if (paramTextView.getTransformationMethod() instanceof PasswordTransformationMethod)
      paramTextView.setTransformationMethod(null); 
  }
  
  @BindingAdapter({"android:phoneNumber"})
  public static void setPhoneNumber(TextView paramTextView, boolean paramBoolean) {
    if (paramBoolean) {
      paramTextView.setKeyListener((KeyListener)DialerKeyListener.getInstance());
      return;
    } 
    if (paramTextView.getKeyListener() instanceof DialerKeyListener)
      paramTextView.setKeyListener(null); 
  }
  
  @BindingAdapter({"android:shadowColor"})
  public static void setShadowColor(TextView paramTextView, int paramInt) {
    float f1 = paramTextView.getShadowDx();
    float f2 = paramTextView.getShadowDy();
    paramTextView.setShadowLayer(paramTextView.getShadowRadius(), f1, f2, paramInt);
  }
  
  @BindingAdapter({"android:shadowDx"})
  public static void setShadowDx(TextView paramTextView, float paramFloat) {
    int i = paramTextView.getShadowColor();
    float f = paramTextView.getShadowDy();
    paramTextView.setShadowLayer(paramTextView.getShadowRadius(), paramFloat, f, i);
  }
  
  @BindingAdapter({"android:shadowDy"})
  public static void setShadowDy(TextView paramTextView, float paramFloat) {
    int i = paramTextView.getShadowColor();
    float f = paramTextView.getShadowDx();
    paramTextView.setShadowLayer(paramTextView.getShadowRadius(), f, paramFloat, i);
  }
  
  @BindingAdapter({"android:shadowRadius"})
  public static void setShadowRadius(TextView paramTextView, float paramFloat) {
    int i = paramTextView.getShadowColor();
    paramTextView.setShadowLayer(paramFloat, paramTextView.getShadowDx(), paramTextView.getShadowDy(), i);
  }
  
  @BindingAdapter({"android:text"})
  public static void setText(TextView paramTextView, CharSequence paramCharSequence) {
    CharSequence charSequence = paramTextView.getText();
    if (paramCharSequence != charSequence) {
      if (paramCharSequence == null && charSequence.length() == 0)
        return; 
      if (paramCharSequence instanceof android.text.Spanned) {
        if (paramCharSequence.equals(charSequence))
          return; 
      } else if (!haveContentsChanged(paramCharSequence, charSequence)) {
        return;
      } 
      paramTextView.setText(paramCharSequence);
    } 
  }
  
  @BindingAdapter({"android:textSize"})
  public static void setTextSize(TextView paramTextView, float paramFloat) {
    paramTextView.setTextSize(0, paramFloat);
  }
  
  @BindingAdapter(requireAll = false, value = {"android:beforeTextChanged", "android:onTextChanged", "android:afterTextChanged", "android:textAttrChanged"})
  public static void setTextWatcher(TextView paramTextView, final BeforeTextChanged before, final OnTextChanged on, final AfterTextChanged after, final InverseBindingListener textAttrChanged) {
    TextWatcher textWatcher1;
    if (before == null && after == null && on == null && textAttrChanged == null) {
      before = null;
    } else {
      textWatcher1 = new TextWatcher() {
          public void afterTextChanged(Editable param1Editable) {
            TextViewBindingAdapter.AfterTextChanged afterTextChanged = after;
            if (afterTextChanged != null)
              afterTextChanged.afterTextChanged(param1Editable); 
          }
          
          public void beforeTextChanged(CharSequence param1CharSequence, int param1Int1, int param1Int2, int param1Int3) {
            TextViewBindingAdapter.BeforeTextChanged beforeTextChanged = before;
            if (beforeTextChanged != null)
              beforeTextChanged.beforeTextChanged(param1CharSequence, param1Int1, param1Int2, param1Int3); 
          }
          
          public void onTextChanged(CharSequence param1CharSequence, int param1Int1, int param1Int2, int param1Int3) {
            TextViewBindingAdapter.OnTextChanged onTextChanged = on;
            if (onTextChanged != null)
              onTextChanged.onTextChanged(param1CharSequence, param1Int1, param1Int2, param1Int3); 
            InverseBindingListener inverseBindingListener = textAttrChanged;
            if (inverseBindingListener != null)
              inverseBindingListener.onChange(); 
          }
        };
    } 
    TextWatcher textWatcher2 = (TextWatcher)ListenerUtil.trackListener((View)paramTextView, textWatcher1, R.id.textWatcher);
    if (textWatcher2 != null)
      paramTextView.removeTextChangedListener(textWatcher2); 
    if (textWatcher1 != null)
      paramTextView.addTextChangedListener(textWatcher1); 
  }
  
  public static interface AfterTextChanged {
    void afterTextChanged(Editable param1Editable);
  }
  
  public static interface BeforeTextChanged {
    void beforeTextChanged(CharSequence param1CharSequence, int param1Int1, int param1Int2, int param1Int3);
  }
  
  public static interface OnTextChanged {
    void onTextChanged(CharSequence param1CharSequence, int param1Int1, int param1Int2, int param1Int3);
  }
}


/* Location:              C:\soft\dex2jar-2.0\MagicAI - AI Art & Anime Art-dex2jar.jar!\androidx\databinding\adapters\TextViewBindingAdapter.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */