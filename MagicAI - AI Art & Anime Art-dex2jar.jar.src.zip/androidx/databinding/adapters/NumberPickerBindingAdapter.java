package androidx.databinding.adapters;

import android.widget.NumberPicker;
import androidx.annotation.RestrictTo;
import androidx.databinding.BindingAdapter;
import androidx.databinding.BindingMethod;
import androidx.databinding.BindingMethods;
import androidx.databinding.InverseBindingListener;
import androidx.databinding.InverseBindingMethod;
import androidx.databinding.InverseBindingMethods;

@RestrictTo({RestrictTo.Scope.LIBRARY})
@BindingMethods({@BindingMethod(attribute = "android:format", method = "setFormatter", type = NumberPicker.class), @BindingMethod(attribute = "android:onScrollStateChange", method = "setOnScrollListener", type = NumberPicker.class)})
@InverseBindingMethods({@InverseBindingMethod(attribute = "android:value", type = NumberPicker.class)})
public class NumberPickerBindingAdapter {
  @BindingAdapter(requireAll = false, value = {"android:onValueChange", "android:valueAttrChanged"})
  public static void setListeners(NumberPicker paramNumberPicker, final NumberPicker.OnValueChangeListener listener, final InverseBindingListener attrChange) {
    if (attrChange == null) {
      paramNumberPicker.setOnValueChangedListener(listener);
      return;
    } 
    paramNumberPicker.setOnValueChangedListener(new NumberPicker.OnValueChangeListener() {
          public void onValueChange(NumberPicker param1NumberPicker, int param1Int1, int param1Int2) {
            NumberPicker.OnValueChangeListener onValueChangeListener = listener;
            if (onValueChangeListener != null)
              onValueChangeListener.onValueChange(param1NumberPicker, param1Int1, param1Int2); 
            attrChange.onChange();
          }
        });
  }
  
  @BindingAdapter({"android:value"})
  public static void setValue(NumberPicker paramNumberPicker, int paramInt) {
    if (paramNumberPicker.getValue() != paramInt)
      paramNumberPicker.setValue(paramInt); 
  }
}


/* Location:              C:\soft\dex2jar-2.0\MagicAI - AI Art & Anime Art-dex2jar.jar!\androidx\databinding\adapters\NumberPickerBindingAdapter.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */