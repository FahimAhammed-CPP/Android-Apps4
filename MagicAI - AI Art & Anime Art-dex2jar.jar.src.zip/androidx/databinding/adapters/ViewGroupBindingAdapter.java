package androidx.databinding.adapters;

import android.animation.LayoutTransition;
import android.annotation.TargetApi;
import android.view.View;
import android.view.ViewGroup;
import android.view.animation.Animation;
import androidx.annotation.RestrictTo;
import androidx.databinding.BindingAdapter;
import androidx.databinding.BindingMethod;
import androidx.databinding.BindingMethods;

@RestrictTo({RestrictTo.Scope.LIBRARY})
@BindingMethods({@BindingMethod(attribute = "android:alwaysDrawnWithCache", method = "setAlwaysDrawnWithCacheEnabled", type = ViewGroup.class), @BindingMethod(attribute = "android:animationCache", method = "setAnimationCacheEnabled", type = ViewGroup.class), @BindingMethod(attribute = "android:splitMotionEvents", method = "setMotionEventSplittingEnabled", type = ViewGroup.class)})
public class ViewGroupBindingAdapter {
  @TargetApi(11)
  @BindingAdapter({"android:animateLayoutChanges"})
  public static void setAnimateLayoutChanges(ViewGroup paramViewGroup, boolean paramBoolean) {
    if (paramBoolean) {
      paramViewGroup.setLayoutTransition(new LayoutTransition());
      return;
    } 
    paramViewGroup.setLayoutTransition(null);
  }
  
  @BindingAdapter(requireAll = false, value = {"android:onAnimationStart", "android:onAnimationEnd", "android:onAnimationRepeat"})
  public static void setListener(ViewGroup paramViewGroup, final OnAnimationStart start, final OnAnimationEnd end, final OnAnimationRepeat repeat) {
    if (start == null && end == null && repeat == null) {
      paramViewGroup.setLayoutAnimationListener(null);
      return;
    } 
    paramViewGroup.setLayoutAnimationListener(new Animation.AnimationListener() {
          public void onAnimationEnd(Animation param1Animation) {
            ViewGroupBindingAdapter.OnAnimationEnd onAnimationEnd = end;
            if (onAnimationEnd != null)
              onAnimationEnd.onAnimationEnd(param1Animation); 
          }
          
          public void onAnimationRepeat(Animation param1Animation) {
            ViewGroupBindingAdapter.OnAnimationRepeat onAnimationRepeat = repeat;
            if (onAnimationRepeat != null)
              onAnimationRepeat.onAnimationRepeat(param1Animation); 
          }
          
          public void onAnimationStart(Animation param1Animation) {
            ViewGroupBindingAdapter.OnAnimationStart onAnimationStart = start;
            if (onAnimationStart != null)
              onAnimationStart.onAnimationStart(param1Animation); 
          }
        });
  }
  
  @BindingAdapter(requireAll = false, value = {"android:onChildViewAdded", "android:onChildViewRemoved"})
  public static void setListener(ViewGroup paramViewGroup, final OnChildViewAdded added, final OnChildViewRemoved removed) {
    if (added == null && removed == null) {
      paramViewGroup.setOnHierarchyChangeListener(null);
      return;
    } 
    paramViewGroup.setOnHierarchyChangeListener(new ViewGroup.OnHierarchyChangeListener() {
          public void onChildViewAdded(View param1View1, View param1View2) {
            ViewGroupBindingAdapter.OnChildViewAdded onChildViewAdded = added;
            if (onChildViewAdded != null)
              onChildViewAdded.onChildViewAdded(param1View1, param1View2); 
          }
          
          public void onChildViewRemoved(View param1View1, View param1View2) {
            ViewGroupBindingAdapter.OnChildViewRemoved onChildViewRemoved = removed;
            if (onChildViewRemoved != null)
              onChildViewRemoved.onChildViewRemoved(param1View1, param1View2); 
          }
        });
  }
  
  public static interface OnAnimationEnd {
    void onAnimationEnd(Animation param1Animation);
  }
  
  public static interface OnAnimationRepeat {
    void onAnimationRepeat(Animation param1Animation);
  }
  
  public static interface OnAnimationStart {
    void onAnimationStart(Animation param1Animation);
  }
  
  public static interface OnChildViewAdded {
    void onChildViewAdded(View param1View1, View param1View2);
  }
  
  public static interface OnChildViewRemoved {
    void onChildViewRemoved(View param1View1, View param1View2);
  }
}


/* Location:              C:\soft\dex2jar-2.0\MagicAI - AI Art & Anime Art-dex2jar.jar!\androidx\databinding\adapters\ViewGroupBindingAdapter.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */