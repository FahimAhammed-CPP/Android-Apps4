package androidx.databinding.adapters;

import android.view.View;
import android.widget.DatePicker;
import androidx.annotation.RestrictTo;
import androidx.databinding.BindingAdapter;
import androidx.databinding.InverseBindingListener;
import androidx.databinding.InverseBindingMethod;
import androidx.databinding.InverseBindingMethods;
import androidx.databinding.library.baseAdapters.R;

@RestrictTo({RestrictTo.Scope.LIBRARY})
@InverseBindingMethods({@InverseBindingMethod(attribute = "android:year", type = DatePicker.class), @InverseBindingMethod(attribute = "android:month", type = DatePicker.class), @InverseBindingMethod(attribute = "android:day", method = "getDayOfMonth", type = DatePicker.class)})
public class DatePickerBindingAdapter {
  @BindingAdapter(requireAll = false, value = {"android:year", "android:month", "android:day", "android:onDateChanged", "android:yearAttrChanged", "android:monthAttrChanged", "android:dayAttrChanged"})
  public static void setListeners(DatePicker paramDatePicker, int paramInt1, int paramInt2, int paramInt3, DatePicker.OnDateChangedListener paramOnDateChangedListener, InverseBindingListener paramInverseBindingListener1, InverseBindingListener paramInverseBindingListener2, InverseBindingListener paramInverseBindingListener3) {
    int i = paramInt1;
    if (paramInt1 == 0)
      i = paramDatePicker.getYear(); 
    paramInt1 = paramInt3;
    if (paramInt3 == 0)
      paramInt1 = paramDatePicker.getDayOfMonth(); 
    if (paramInverseBindingListener1 == null && paramInverseBindingListener2 == null && paramInverseBindingListener3 == null) {
      paramDatePicker.init(i, paramInt2, paramInt1, paramOnDateChangedListener);
      return;
    } 
    paramInt3 = R.id.onDateChanged;
    DateChangedListener dateChangedListener2 = (DateChangedListener)ListenerUtil.getListener((View)paramDatePicker, paramInt3);
    DateChangedListener dateChangedListener1 = dateChangedListener2;
    if (dateChangedListener2 == null) {
      dateChangedListener1 = new DateChangedListener();
      ListenerUtil.trackListener((View)paramDatePicker, dateChangedListener1, paramInt3);
    } 
    dateChangedListener1.setListeners(paramOnDateChangedListener, paramInverseBindingListener1, paramInverseBindingListener2, paramInverseBindingListener3);
    paramDatePicker.init(i, paramInt2, paramInt1, dateChangedListener1);
  }
  
  private static class DateChangedListener implements DatePicker.OnDateChangedListener {
    InverseBindingListener mDayChanged;
    
    DatePicker.OnDateChangedListener mListener;
    
    InverseBindingListener mMonthChanged;
    
    InverseBindingListener mYearChanged;
    
    private DateChangedListener() {}
    
    public void onDateChanged(DatePicker param1DatePicker, int param1Int1, int param1Int2, int param1Int3) {
      DatePicker.OnDateChangedListener onDateChangedListener = this.mListener;
      if (onDateChangedListener != null)
        onDateChangedListener.onDateChanged(param1DatePicker, param1Int1, param1Int2, param1Int3); 
      InverseBindingListener inverseBindingListener = this.mYearChanged;
      if (inverseBindingListener != null)
        inverseBindingListener.onChange(); 
      inverseBindingListener = this.mMonthChanged;
      if (inverseBindingListener != null)
        inverseBindingListener.onChange(); 
      inverseBindingListener = this.mDayChanged;
      if (inverseBindingListener != null)
        inverseBindingListener.onChange(); 
    }
    
    public void setListeners(DatePicker.OnDateChangedListener param1OnDateChangedListener, InverseBindingListener param1InverseBindingListener1, InverseBindingListener param1InverseBindingListener2, InverseBindingListener param1InverseBindingListener3) {
      this.mListener = param1OnDateChangedListener;
      this.mYearChanged = param1InverseBindingListener1;
      this.mMonthChanged = param1InverseBindingListener2;
      this.mDayChanged = param1InverseBindingListener3;
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\MagicAI - AI Art & Anime Art-dex2jar.jar!\androidx\databinding\adapters\DatePickerBindingAdapter.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */