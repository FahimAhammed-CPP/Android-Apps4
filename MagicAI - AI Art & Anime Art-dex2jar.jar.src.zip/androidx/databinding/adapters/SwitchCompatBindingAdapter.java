package androidx.databinding.adapters;

import androidx.annotation.RestrictTo;
import androidx.appcompat.widget.SwitchCompat;
import androidx.databinding.BindingAdapter;
import androidx.databinding.BindingMethod;
import androidx.databinding.BindingMethods;

@RestrictTo({RestrictTo.Scope.LIBRARY})
@BindingMethods({@BindingMethod(attribute = "android:thumb", method = "setThumbDrawable", type = SwitchCompat.class), @BindingMethod(attribute = "android:track", method = "setTrackDrawable", type = SwitchCompat.class)})
public class SwitchCompatBindingAdapter {
  @BindingAdapter({"android:switchTextAppearance"})
  public static void setSwitchTextAppearance(SwitchCompat paramSwitchCompat, int paramInt) {
    paramSwitchCompat.setSwitchTextAppearance(null, paramInt);
  }
}


/* Location:              C:\soft\dex2jar-2.0\MagicAI - AI Art & Anime Art-dex2jar.jar!\androidx\databinding\adapters\SwitchCompatBindingAdapter.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */