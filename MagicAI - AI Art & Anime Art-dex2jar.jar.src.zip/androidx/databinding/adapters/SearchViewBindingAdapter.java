package androidx.databinding.adapters;

import android.annotation.TargetApi;
import android.widget.SearchView;
import androidx.annotation.RestrictTo;
import androidx.databinding.BindingAdapter;
import androidx.databinding.BindingMethod;
import androidx.databinding.BindingMethods;

@RestrictTo({RestrictTo.Scope.LIBRARY})
@BindingMethods({@BindingMethod(attribute = "android:onQueryTextFocusChange", method = "setOnQueryTextFocusChangeListener", type = SearchView.class), @BindingMethod(attribute = "android:onSearchClick", method = "setOnSearchClickListener", type = SearchView.class), @BindingMethod(attribute = "android:onClose", method = "setOnCloseListener", type = SearchView.class)})
public class SearchViewBindingAdapter {
  @BindingAdapter(requireAll = false, value = {"android:onQueryTextSubmit", "android:onQueryTextChange"})
  public static void setOnQueryTextListener(SearchView paramSearchView, final OnQueryTextSubmit submit, final OnQueryTextChange change) {
    if (submit == null && change == null) {
      paramSearchView.setOnQueryTextListener(null);
      return;
    } 
    paramSearchView.setOnQueryTextListener(new SearchView.OnQueryTextListener() {
          public boolean onQueryTextChange(String param1String) {
            SearchViewBindingAdapter.OnQueryTextChange onQueryTextChange = change;
            return (onQueryTextChange != null) ? onQueryTextChange.onQueryTextChange(param1String) : false;
          }
          
          public boolean onQueryTextSubmit(String param1String) {
            SearchViewBindingAdapter.OnQueryTextSubmit onQueryTextSubmit = submit;
            return (onQueryTextSubmit != null) ? onQueryTextSubmit.onQueryTextSubmit(param1String) : false;
          }
        });
  }
  
  @BindingAdapter(requireAll = false, value = {"android:onSuggestionSelect", "android:onSuggestionClick"})
  public static void setOnSuggestListener(SearchView paramSearchView, final OnSuggestionSelect submit, final OnSuggestionClick change) {
    if (submit == null && change == null) {
      paramSearchView.setOnSuggestionListener(null);
      return;
    } 
    paramSearchView.setOnSuggestionListener(new SearchView.OnSuggestionListener() {
          public boolean onSuggestionClick(int param1Int) {
            SearchViewBindingAdapter.OnSuggestionClick onSuggestionClick = change;
            return (onSuggestionClick != null) ? onSuggestionClick.onSuggestionClick(param1Int) : false;
          }
          
          public boolean onSuggestionSelect(int param1Int) {
            SearchViewBindingAdapter.OnSuggestionSelect onSuggestionSelect = submit;
            return (onSuggestionSelect != null) ? onSuggestionSelect.onSuggestionSelect(param1Int) : false;
          }
        });
  }
  
  @TargetApi(11)
  public static interface OnQueryTextChange {
    boolean onQueryTextChange(String param1String);
  }
  
  @TargetApi(11)
  public static interface OnQueryTextSubmit {
    boolean onQueryTextSubmit(String param1String);
  }
  
  @TargetApi(11)
  public static interface OnSuggestionClick {
    boolean onSuggestionClick(int param1Int);
  }
  
  @TargetApi(11)
  public static interface OnSuggestionSelect {
    boolean onSuggestionSelect(int param1Int);
  }
}


/* Location:              C:\soft\dex2jar-2.0\MagicAI - AI Art & Anime Art-dex2jar.jar!\androidx\databinding\adapters\SearchViewBindingAdapter.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */