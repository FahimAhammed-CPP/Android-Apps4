package androidx.databinding;

import androidx.annotation.RestrictTo;
import androidx.lifecycle.Lifecycle;
import androidx.lifecycle.LifecycleOwner;
import androidx.lifecycle.LifecycleOwnerKt;
import androidx.lifecycle.RepeatOnLifecycleKt;
import java.lang.ref.ReferenceQueue;
import java.lang.ref.WeakReference;
import kotlin.Metadata;
import kotlin.ResultKt;
import kotlin.Unit;
import kotlin.coroutines.Continuation;
import kotlin.coroutines.intrinsics.IntrinsicsKt;
import kotlin.coroutines.jvm.internal.DebugMetadata;
import kotlin.coroutines.jvm.internal.SuspendLambda;
import kotlin.jvm.functions.Function2;
import kotlin.jvm.internal.Intrinsics;
import kotlinx.coroutines.BuildersKt;
import kotlinx.coroutines.CoroutineScope;
import kotlinx.coroutines.Job;
import kotlinx.coroutines.flow.Flow;
import kotlinx.coroutines.flow.FlowCollector;

@Metadata(d1 = {"\000,\n\002\030\002\n\002\020\000\n\002\b\002\n\002\030\002\n\000\n\002\020\013\n\000\n\002\030\002\n\000\n\002\020\b\n\000\n\002\030\002\n\002\b\002\bÇ\002\030\0002\0020\001:\001\rB\007\b\002¢\006\002\020\002J&\020\005\032\0020\0062\006\020\007\032\0020\b2\006\020\t\032\0020\n2\f\020\013\032\b\022\002\b\003\030\0010\fH\007R\016\020\003\032\0020\004X\004¢\006\002\n\000¨\006\016"}, d2 = {"Landroidx/databinding/ViewDataBindingKtx;", "", "()V", "CREATE_STATE_FLOW_LISTENER", "Landroidx/databinding/CreateWeakListener;", "updateStateFlowRegistration", "", "viewDataBinding", "Landroidx/databinding/ViewDataBinding;", "localFieldId", "", "observable", "Lkotlinx/coroutines/flow/Flow;", "StateFlowListener", "databindingKtx_release"}, k = 1, mv = {1, 7, 1}, xi = 48)
@RestrictTo({RestrictTo.Scope.LIBRARY_GROUP})
public final class ViewDataBindingKtx {
  private static final CreateWeakListener CREATE_STATE_FLOW_LISTENER;
  
  public static final ViewDataBindingKtx INSTANCE = new ViewDataBindingKtx();
  
  static {
    CREATE_STATE_FLOW_LISTENER = (CreateWeakListener)new ViewDataBindingKtx$.ExternalSyntheticLambda0();
  }
  
  private static final WeakListener CREATE_STATE_FLOW_LISTENER$lambda-0(ViewDataBinding paramViewDataBinding, int paramInt, ReferenceQueue<ViewDataBinding> paramReferenceQueue) {
    Intrinsics.checkNotNullExpressionValue(paramReferenceQueue, "referenceQueue");
    return (new StateFlowListener(paramViewDataBinding, paramInt, paramReferenceQueue)).getListener();
  }
  
  @RestrictTo({RestrictTo.Scope.LIBRARY_GROUP})
  public static final boolean updateStateFlowRegistration(ViewDataBinding paramViewDataBinding, int paramInt, Flow<?> paramFlow) {
    Intrinsics.checkNotNullParameter(paramViewDataBinding, "viewDataBinding");
    paramViewDataBinding.mInStateFlowRegisterObserver = true;
    try {
      return paramViewDataBinding.updateRegistration(paramInt, paramFlow, CREATE_STATE_FLOW_LISTENER);
    } finally {
      paramViewDataBinding.mInStateFlowRegisterObserver = false;
    } 
  }
  
  @Metadata(d1 = {"\000D\n\002\030\002\n\002\030\002\n\002\030\002\n\002\020\000\n\000\n\002\030\002\n\000\n\002\020\b\n\000\n\002\030\002\n\002\b\002\n\002\030\002\n\002\030\002\n\000\n\002\030\002\n\000\n\002\030\002\n\000\n\002\020\002\n\002\b\t\b\000\030\0002\020\022\f\022\n\022\006\022\004\030\0010\0030\0020\001B%\022\b\020\004\032\004\030\0010\005\022\006\020\006\032\0020\007\022\f\020\b\032\b\022\004\022\0020\0050\t¢\006\002\020\nJ\032\020\022\032\0020\0232\020\020\024\032\f\022\006\022\004\030\0010\003\030\0010\002H\026J\026\020\025\032\020\022\f\022\n\022\006\022\004\030\0010\0030\0020\017H\026J\032\020\026\032\0020\0232\020\020\024\032\f\022\006\022\004\030\0010\003\030\0010\002H\026J\022\020\027\032\0020\0232\b\020\030\032\004\030\0010\rH\026J \020\031\032\0020\0232\006\020\032\032\0020\r2\016\020\033\032\n\022\006\022\004\030\0010\0030\002H\002R\026\020\013\032\n\022\004\022\0020\r\030\0010\fX\016¢\006\002\n\000R\034\020\016\032\020\022\f\022\n\022\006\022\004\030\0010\0030\0020\017X\004¢\006\002\n\000R\020\020\020\032\004\030\0010\021X\016¢\006\002\n\000¨\006\034"}, d2 = {"Landroidx/databinding/ViewDataBindingKtx$StateFlowListener;", "Landroidx/databinding/ObservableReference;", "Lkotlinx/coroutines/flow/Flow;", "", "binder", "Landroidx/databinding/ViewDataBinding;", "localFieldId", "", "referenceQueue", "Ljava/lang/ref/ReferenceQueue;", "(Landroidx/databinding/ViewDataBinding;ILjava/lang/ref/ReferenceQueue;)V", "_lifecycleOwnerRef", "Ljava/lang/ref/WeakReference;", "Landroidx/lifecycle/LifecycleOwner;", "listener", "Landroidx/databinding/WeakListener;", "observerJob", "Lkotlinx/coroutines/Job;", "addListener", "", "target", "getListener", "removeListener", "setLifecycleOwner", "lifecycleOwner", "startCollection", "owner", "flow", "databindingKtx_release"}, k = 1, mv = {1, 7, 1}, xi = 48)
  public static final class StateFlowListener implements ObservableReference<Flow<? extends Object>> {
    private WeakReference<LifecycleOwner> _lifecycleOwnerRef;
    
    private final WeakListener<Flow<Object>> listener;
    
    private Job observerJob;
    
    public StateFlowListener(ViewDataBinding param1ViewDataBinding, int param1Int, ReferenceQueue<ViewDataBinding> param1ReferenceQueue) {
      this.listener = new WeakListener(param1ViewDataBinding, param1Int, this, param1ReferenceQueue);
    }
    
    private final void startCollection(LifecycleOwner param1LifecycleOwner, Flow<? extends Object> param1Flow) {
      Job job = this.observerJob;
      if (job != null)
        Job.DefaultImpls.cancel$default(job, null, 1, null); 
      this.observerJob = BuildersKt.launch$default((CoroutineScope)LifecycleOwnerKt.getLifecycleScope(param1LifecycleOwner), null, null, new ViewDataBindingKtx$StateFlowListener$startCollection$1(param1Flow, this, null), 3, null);
    }
    
    public void addListener(Flow<? extends Object> param1Flow) {
      WeakReference<LifecycleOwner> weakReference = this._lifecycleOwnerRef;
      if (weakReference != null) {
        LifecycleOwner lifecycleOwner = weakReference.get();
        if (lifecycleOwner == null)
          return; 
        if (param1Flow != null)
          startCollection(lifecycleOwner, param1Flow); 
      } 
    }
    
    public WeakListener<Flow<Object>> getListener() {
      return this.listener;
    }
    
    public void removeListener(Flow<? extends Object> param1Flow) {
      Job job = this.observerJob;
      if (job != null)
        Job.DefaultImpls.cancel$default(job, null, 1, null); 
      this.observerJob = null;
    }
    
    public void setLifecycleOwner(LifecycleOwner param1LifecycleOwner) {
      WeakReference<LifecycleOwner> weakReference = this._lifecycleOwnerRef;
      if (weakReference != null) {
        LifecycleOwner lifecycleOwner = weakReference.get();
      } else {
        weakReference = null;
      } 
      if (weakReference == param1LifecycleOwner)
        return; 
      Job job = this.observerJob;
      if (job != null)
        Job.DefaultImpls.cancel$default(job, null, 1, null); 
      if (param1LifecycleOwner == null) {
        this._lifecycleOwnerRef = null;
        return;
      } 
      this._lifecycleOwnerRef = new WeakReference<LifecycleOwner>(param1LifecycleOwner);
      Flow<? extends Object> flow = (Flow)this.listener.getTarget();
      if (flow != null)
        startCollection(param1LifecycleOwner, flow); 
    }
    
    @Metadata(d1 = {"\000\n\n\002\030\002\n\002\020\002\n\000\020\002\032\0020\001*\0020\000H@"}, d2 = {"Lkotlinx/coroutines/CoroutineScope;", "", "<anonymous>"}, k = 3, mv = {1, 7, 1})
    @DebugMetadata(c = "androidx.databinding.ViewDataBindingKtx$StateFlowListener$startCollection$1", f = "ViewDataBindingKtx.kt", l = {95}, m = "invokeSuspend")
    static final class ViewDataBindingKtx$StateFlowListener$startCollection$1 extends SuspendLambda implements Function2<CoroutineScope, Continuation<? super Unit>, Object> {
      int label;
      
      ViewDataBindingKtx$StateFlowListener$startCollection$1(Flow<? extends Object> param2Flow, ViewDataBindingKtx.StateFlowListener param2StateFlowListener, Continuation<? super ViewDataBindingKtx$StateFlowListener$startCollection$1> param2Continuation) {
        super(2, param2Continuation);
      }
      
      public final Continuation<Unit> create(Object param2Object, Continuation<?> param2Continuation) {
        return (Continuation<Unit>)new ViewDataBindingKtx$StateFlowListener$startCollection$1(this.$flow, ViewDataBindingKtx.StateFlowListener.this, (Continuation)param2Continuation);
      }
      
      public final Object invoke(CoroutineScope param2CoroutineScope, Continuation<? super Unit> param2Continuation) {
        return ((ViewDataBindingKtx$StateFlowListener$startCollection$1)create(param2CoroutineScope, param2Continuation)).invokeSuspend(Unit.INSTANCE);
      }
      
      public final Object invokeSuspend(Object param2Object) {
        Object object = IntrinsicsKt.getCOROUTINE_SUSPENDED();
        int i = this.label;
        if (i != 0) {
          if (i == 1) {
            ResultKt.throwOnFailure(param2Object);
          } else {
            throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
          } 
        } else {
          ResultKt.throwOnFailure(param2Object);
          param2Object = this.$owner.getLifecycle();
          Intrinsics.checkNotNullExpressionValue(param2Object, "owner.lifecycle");
          Lifecycle.State state = Lifecycle.State.STARTED;
          Function2<CoroutineScope, Continuation<? super Unit>, Object> function2 = new Function2<CoroutineScope, Continuation<? super Unit>, Object>(ViewDataBindingKtx.StateFlowListener.this, null) {
              int label;
              
              public final Continuation<Unit> create(Object param1Object, Continuation<?> param1Continuation) {
                return (Continuation)new Function2<CoroutineScope, Continuation<? super Unit>, Object>(this.$flow, ViewDataBindingKtx.StateFlowListener.this, (Continuation)param1Continuation);
              }
              
              public final Object invoke(CoroutineScope param1CoroutineScope, Continuation<? super Unit> param1Continuation) {
                return ((null)create(param1CoroutineScope, param1Continuation)).invokeSuspend(Unit.INSTANCE);
              }
              
              public final Object invokeSuspend(Object<Object> param1Object) {
                Object object = IntrinsicsKt.getCOROUTINE_SUSPENDED();
                int i = this.label;
                if (i != 0) {
                  if (i == 1) {
                    ResultKt.throwOnFailure(param1Object);
                  } else {
                    throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
                  } 
                } else {
                  ResultKt.throwOnFailure(param1Object);
                  param1Object = (Object<Object>)this.$flow;
                  ViewDataBindingKtx$StateFlowListener$startCollection$1$1$invokeSuspend$$inlined$collect$1 viewDataBindingKtx$StateFlowListener$startCollection$1$1$invokeSuspend$$inlined$collect$1 = new ViewDataBindingKtx$StateFlowListener$startCollection$1$1$invokeSuspend$$inlined$collect$1();
                  this.label = 1;
                  if (param1Object.collect(viewDataBindingKtx$StateFlowListener$startCollection$1$1$invokeSuspend$$inlined$collect$1, (Continuation)this) == object)
                    return object; 
                } 
                return Unit.INSTANCE;
              }
              
              @Metadata(d1 = {"\000\023\n\000\n\002\030\002\n\000\n\002\020\002\n\002\b\003*\001\000\b\n\030\0002\b\022\004\022\0028\0000\001J\031\020\002\032\0020\0032\006\020\004\032\0028\000H@ø\001\000¢\006\002\020\005\002\004\n\002\b\031¨\006\006¸\006\000"}, d2 = {"kotlinx/coroutines/flow/FlowKt__CollectKt$collect$3", "Lkotlinx/coroutines/flow/FlowCollector;", "emit", "", "value", "(Ljava/lang/Object;Lkotlin/coroutines/Continuation;)Ljava/lang/Object;", "kotlinx-coroutines-core"}, k = 1, mv = {1, 7, 1}, xi = 48)
              public static final class ViewDataBindingKtx$StateFlowListener$startCollection$1$1$invokeSuspend$$inlined$collect$1 implements FlowCollector<Object> {
                public Object emit(Object param2Object, Continuation<? super Unit> param2Continuation) {
                  param2Object = ViewDataBindingKtx.StateFlowListener.this.listener.getBinder();
                  if (param2Object != null)
                    param2Object.handleFieldChange(ViewDataBindingKtx.StateFlowListener.this.listener.mLocalFieldId, ViewDataBindingKtx.StateFlowListener.this.listener.getTarget(), 0); 
                  return Unit.INSTANCE;
                }
              }
            };
          this.label = 1;
          if (RepeatOnLifecycleKt.repeatOnLifecycle((Lifecycle)param2Object, state, function2, (Continuation)this) == object)
            return object; 
        } 
        return Unit.INSTANCE;
      }
    }
    
    @Metadata(d1 = {"\000\n\n\002\030\002\n\002\020\002\n\000\020\002\032\0020\001*\0020\000H@"}, d2 = {"Lkotlinx/coroutines/CoroutineScope;", "", "<anonymous>"}, k = 3, mv = {1, 7, 1})
    @DebugMetadata(c = "androidx.databinding.ViewDataBindingKtx$StateFlowListener$startCollection$1$1", f = "ViewDataBindingKtx.kt", l = {123}, m = "invokeSuspend")
    static final class null extends SuspendLambda implements Function2<CoroutineScope, Continuation<? super Unit>, Object> {
      int label;
      
      null(ViewDataBindingKtx.StateFlowListener param2StateFlowListener, Continuation<? super null> param2Continuation) {
        super(2, param2Continuation);
      }
      
      public final Continuation<Unit> create(Object param2Object, Continuation<?> param2Continuation) {
        return (Continuation)new Function2<CoroutineScope, Continuation<? super Unit>, Object>(this.$flow, ViewDataBindingKtx.StateFlowListener.this, (Continuation)param2Continuation);
      }
      
      public final Object invoke(CoroutineScope param2CoroutineScope, Continuation<? super Unit> param2Continuation) {
        return ((null)create(param2CoroutineScope, param2Continuation)).invokeSuspend(Unit.INSTANCE);
      }
      
      public final Object invokeSuspend(Object<Object> param2Object) {
        Object object = IntrinsicsKt.getCOROUTINE_SUSPENDED();
        int i = this.label;
        if (i != 0) {
          if (i == 1) {
            ResultKt.throwOnFailure(param2Object);
          } else {
            throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
          } 
        } else {
          ResultKt.throwOnFailure(param2Object);
          param2Object = (Object<Object>)this.$flow;
          ViewDataBindingKtx$StateFlowListener$startCollection$1$1$invokeSuspend$$inlined$collect$1 viewDataBindingKtx$StateFlowListener$startCollection$1$1$invokeSuspend$$inlined$collect$1 = new ViewDataBindingKtx$StateFlowListener$startCollection$1$1$invokeSuspend$$inlined$collect$1();
          this.label = 1;
          if (param2Object.collect(viewDataBindingKtx$StateFlowListener$startCollection$1$1$invokeSuspend$$inlined$collect$1, (Continuation)this) == object)
            return object; 
        } 
        return Unit.INSTANCE;
      }
      
      @Metadata(d1 = {"\000\023\n\000\n\002\030\002\n\000\n\002\020\002\n\002\b\003*\001\000\b\n\030\0002\b\022\004\022\0028\0000\001J\031\020\002\032\0020\0032\006\020\004\032\0028\000H@ø\001\000¢\006\002\020\005\002\004\n\002\b\031¨\006\006¸\006\000"}, d2 = {"kotlinx/coroutines/flow/FlowKt__CollectKt$collect$3", "Lkotlinx/coroutines/flow/FlowCollector;", "emit", "", "value", "(Ljava/lang/Object;Lkotlin/coroutines/Continuation;)Ljava/lang/Object;", "kotlinx-coroutines-core"}, k = 1, mv = {1, 7, 1}, xi = 48)
      public static final class ViewDataBindingKtx$StateFlowListener$startCollection$1$1$invokeSuspend$$inlined$collect$1 implements FlowCollector<Object> {
        public Object emit(Object param2Object, Continuation<? super Unit> param2Continuation) {
          param2Object = ViewDataBindingKtx.StateFlowListener.this.listener.getBinder();
          if (param2Object != null)
            param2Object.handleFieldChange(ViewDataBindingKtx.StateFlowListener.this.listener.mLocalFieldId, ViewDataBindingKtx.StateFlowListener.this.listener.getTarget(), 0); 
          return Unit.INSTANCE;
        }
      }
    }
    
    @Metadata(d1 = {"\000\023\n\000\n\002\030\002\n\000\n\002\020\002\n\002\b\003*\001\000\b\n\030\0002\b\022\004\022\0028\0000\001J\031\020\002\032\0020\0032\006\020\004\032\0028\000H@ø\001\000¢\006\002\020\005\002\004\n\002\b\031¨\006\006¸\006\000"}, d2 = {"kotlinx/coroutines/flow/FlowKt__CollectKt$collect$3", "Lkotlinx/coroutines/flow/FlowCollector;", "emit", "", "value", "(Ljava/lang/Object;Lkotlin/coroutines/Continuation;)Ljava/lang/Object;", "kotlinx-coroutines-core"}, k = 1, mv = {1, 7, 1}, xi = 48)
    public static final class ViewDataBindingKtx$StateFlowListener$startCollection$1$1$invokeSuspend$$inlined$collect$1 implements FlowCollector<Object> {
      public Object emit(Object param2Object, Continuation<? super Unit> param2Continuation) {
        param2Object = ViewDataBindingKtx.StateFlowListener.this.listener.getBinder();
        if (param2Object != null)
          param2Object.handleFieldChange(ViewDataBindingKtx.StateFlowListener.this.listener.mLocalFieldId, ViewDataBindingKtx.StateFlowListener.this.listener.getTarget(), 0); 
        return Unit.INSTANCE;
      }
    }
  }
  
  @Metadata(d1 = {"\000\n\n\002\030\002\n\002\020\002\n\000\020\002\032\0020\001*\0020\000H@"}, d2 = {"Lkotlinx/coroutines/CoroutineScope;", "", "<anonymous>"}, k = 3, mv = {1, 7, 1})
  @DebugMetadata(c = "androidx.databinding.ViewDataBindingKtx$StateFlowListener$startCollection$1", f = "ViewDataBindingKtx.kt", l = {95}, m = "invokeSuspend")
  static final class ViewDataBindingKtx$StateFlowListener$startCollection$1 extends SuspendLambda implements Function2<CoroutineScope, Continuation<? super Unit>, Object> {
    int label;
    
    ViewDataBindingKtx$StateFlowListener$startCollection$1(Flow<? extends Object> param1Flow, ViewDataBindingKtx.StateFlowListener param1StateFlowListener, Continuation<? super ViewDataBindingKtx$StateFlowListener$startCollection$1> param1Continuation) {
      super(2, param1Continuation);
    }
    
    public final Continuation<Unit> create(Object param1Object, Continuation<?> param1Continuation) {
      return (Continuation<Unit>)new ViewDataBindingKtx$StateFlowListener$startCollection$1(this.$flow, ViewDataBindingKtx.StateFlowListener.this, (Continuation)param1Continuation);
    }
    
    public final Object invoke(CoroutineScope param1CoroutineScope, Continuation<? super Unit> param1Continuation) {
      return ((ViewDataBindingKtx$StateFlowListener$startCollection$1)create(param1CoroutineScope, param1Continuation)).invokeSuspend(Unit.INSTANCE);
    }
    
    public final Object invokeSuspend(Object param1Object) {
      Object object = IntrinsicsKt.getCOROUTINE_SUSPENDED();
      int i = this.label;
      if (i != 0) {
        if (i == 1) {
          ResultKt.throwOnFailure(param1Object);
        } else {
          throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
        } 
      } else {
        ResultKt.throwOnFailure(param1Object);
        param1Object = this.$owner.getLifecycle();
        Intrinsics.checkNotNullExpressionValue(param1Object, "owner.lifecycle");
        Lifecycle.State state = Lifecycle.State.STARTED;
        Function2<CoroutineScope, Continuation<? super Unit>, Object> function2 = new Function2<CoroutineScope, Continuation<? super Unit>, Object>(ViewDataBindingKtx.StateFlowListener.this, null) {
            int label;
            
            public final Continuation<Unit> create(Object param1Object, Continuation<?> param1Continuation) {
              return (Continuation)new Function2<CoroutineScope, Continuation<? super Unit>, Object>(this.$flow, ViewDataBindingKtx.StateFlowListener.this, (Continuation)param1Continuation);
            }
            
            public final Object invoke(CoroutineScope param1CoroutineScope, Continuation<? super Unit> param1Continuation) {
              return ((null)create(param1CoroutineScope, param1Continuation)).invokeSuspend(Unit.INSTANCE);
            }
            
            public final Object invokeSuspend(Object<Object> param1Object) {
              Object object = IntrinsicsKt.getCOROUTINE_SUSPENDED();
              int i = this.label;
              if (i != 0) {
                if (i == 1) {
                  ResultKt.throwOnFailure(param1Object);
                } else {
                  throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
                } 
              } else {
                ResultKt.throwOnFailure(param1Object);
                param1Object = (Object<Object>)this.$flow;
                ViewDataBindingKtx$StateFlowListener$startCollection$1$1$invokeSuspend$$inlined$collect$1 viewDataBindingKtx$StateFlowListener$startCollection$1$1$invokeSuspend$$inlined$collect$1 = new ViewDataBindingKtx$StateFlowListener$startCollection$1$1$invokeSuspend$$inlined$collect$1();
                this.label = 1;
                if (param1Object.collect(viewDataBindingKtx$StateFlowListener$startCollection$1$1$invokeSuspend$$inlined$collect$1, (Continuation)this) == object)
                  return object; 
              } 
              return Unit.INSTANCE;
            }
            
            @Metadata(d1 = {"\000\023\n\000\n\002\030\002\n\000\n\002\020\002\n\002\b\003*\001\000\b\n\030\0002\b\022\004\022\0028\0000\001J\031\020\002\032\0020\0032\006\020\004\032\0028\000H@ø\001\000¢\006\002\020\005\002\004\n\002\b\031¨\006\006¸\006\000"}, d2 = {"kotlinx/coroutines/flow/FlowKt__CollectKt$collect$3", "Lkotlinx/coroutines/flow/FlowCollector;", "emit", "", "value", "(Ljava/lang/Object;Lkotlin/coroutines/Continuation;)Ljava/lang/Object;", "kotlinx-coroutines-core"}, k = 1, mv = {1, 7, 1}, xi = 48)
            public static final class ViewDataBindingKtx$StateFlowListener$startCollection$1$1$invokeSuspend$$inlined$collect$1 implements FlowCollector<Object> {
              public Object emit(Object param2Object, Continuation<? super Unit> param2Continuation) {
                param2Object = ViewDataBindingKtx.StateFlowListener.this.listener.getBinder();
                if (param2Object != null)
                  param2Object.handleFieldChange(ViewDataBindingKtx.StateFlowListener.this.listener.mLocalFieldId, ViewDataBindingKtx.StateFlowListener.this.listener.getTarget(), 0); 
                return Unit.INSTANCE;
              }
            }
          };
        this.label = 1;
        if (RepeatOnLifecycleKt.repeatOnLifecycle((Lifecycle)param1Object, state, function2, (Continuation)this) == object)
          return object; 
      } 
      return Unit.INSTANCE;
    }
  }
  
  @Metadata(d1 = {"\000\n\n\002\030\002\n\002\020\002\n\000\020\002\032\0020\001*\0020\000H@"}, d2 = {"Lkotlinx/coroutines/CoroutineScope;", "", "<anonymous>"}, k = 3, mv = {1, 7, 1})
  @DebugMetadata(c = "androidx.databinding.ViewDataBindingKtx$StateFlowListener$startCollection$1$1", f = "ViewDataBindingKtx.kt", l = {123}, m = "invokeSuspend")
  static final class null extends SuspendLambda implements Function2<CoroutineScope, Continuation<? super Unit>, Object> {
    int label;
    
    null(ViewDataBindingKtx.StateFlowListener param1StateFlowListener, Continuation<? super null> param1Continuation) {
      super(2, param1Continuation);
    }
    
    public final Continuation<Unit> create(Object param1Object, Continuation<?> param1Continuation) {
      return (Continuation)new Function2<CoroutineScope, Continuation<? super Unit>, Object>(this.$flow, ViewDataBindingKtx.StateFlowListener.this, (Continuation)param1Continuation);
    }
    
    public final Object invoke(CoroutineScope param1CoroutineScope, Continuation<? super Unit> param1Continuation) {
      return ((null)create(param1CoroutineScope, param1Continuation)).invokeSuspend(Unit.INSTANCE);
    }
    
    public final Object invokeSuspend(Object<Object> param1Object) {
      Object object = IntrinsicsKt.getCOROUTINE_SUSPENDED();
      int i = this.label;
      if (i != 0) {
        if (i == 1) {
          ResultKt.throwOnFailure(param1Object);
        } else {
          throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
        } 
      } else {
        ResultKt.throwOnFailure(param1Object);
        param1Object = (Object<Object>)this.$flow;
        ViewDataBindingKtx$StateFlowListener$startCollection$1$1$invokeSuspend$$inlined$collect$1 viewDataBindingKtx$StateFlowListener$startCollection$1$1$invokeSuspend$$inlined$collect$1 = new ViewDataBindingKtx$StateFlowListener$startCollection$1$1$invokeSuspend$$inlined$collect$1();
        this.label = 1;
        if (param1Object.collect(viewDataBindingKtx$StateFlowListener$startCollection$1$1$invokeSuspend$$inlined$collect$1, (Continuation)this) == object)
          return object; 
      } 
      return Unit.INSTANCE;
    }
    
    @Metadata(d1 = {"\000\023\n\000\n\002\030\002\n\000\n\002\020\002\n\002\b\003*\001\000\b\n\030\0002\b\022\004\022\0028\0000\001J\031\020\002\032\0020\0032\006\020\004\032\0028\000H@ø\001\000¢\006\002\020\005\002\004\n\002\b\031¨\006\006¸\006\000"}, d2 = {"kotlinx/coroutines/flow/FlowKt__CollectKt$collect$3", "Lkotlinx/coroutines/flow/FlowCollector;", "emit", "", "value", "(Ljava/lang/Object;Lkotlin/coroutines/Continuation;)Ljava/lang/Object;", "kotlinx-coroutines-core"}, k = 1, mv = {1, 7, 1}, xi = 48)
    public static final class ViewDataBindingKtx$StateFlowListener$startCollection$1$1$invokeSuspend$$inlined$collect$1 implements FlowCollector<Object> {
      public Object emit(Object param2Object, Continuation<? super Unit> param2Continuation) {
        param2Object = ViewDataBindingKtx.StateFlowListener.this.listener.getBinder();
        if (param2Object != null)
          param2Object.handleFieldChange(ViewDataBindingKtx.StateFlowListener.this.listener.mLocalFieldId, ViewDataBindingKtx.StateFlowListener.this.listener.getTarget(), 0); 
        return Unit.INSTANCE;
      }
    }
  }
  
  @Metadata(d1 = {"\000\023\n\000\n\002\030\002\n\000\n\002\020\002\n\002\b\003*\001\000\b\n\030\0002\b\022\004\022\0028\0000\001J\031\020\002\032\0020\0032\006\020\004\032\0028\000H@ø\001\000¢\006\002\020\005\002\004\n\002\b\031¨\006\006¸\006\000"}, d2 = {"kotlinx/coroutines/flow/FlowKt__CollectKt$collect$3", "Lkotlinx/coroutines/flow/FlowCollector;", "emit", "", "value", "(Ljava/lang/Object;Lkotlin/coroutines/Continuation;)Ljava/lang/Object;", "kotlinx-coroutines-core"}, k = 1, mv = {1, 7, 1}, xi = 48)
  public static final class ViewDataBindingKtx$StateFlowListener$startCollection$1$1$invokeSuspend$$inlined$collect$1 implements FlowCollector<Object> {
    public Object emit(Object param1Object, Continuation<? super Unit> param1Continuation) {
      param1Object = ViewDataBindingKtx.StateFlowListener.this.listener.getBinder();
      if (param1Object != null)
        param1Object.handleFieldChange(ViewDataBindingKtx.StateFlowListener.this.listener.mLocalFieldId, ViewDataBindingKtx.StateFlowListener.this.listener.getTarget(), 0); 
      return Unit.INSTANCE;
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\MagicAI - AI Art & Anime Art-dex2jar.jar!\androidx\databinding\ViewDataBindingKtx.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */