package androidx.databinding;

import android.annotation.TargetApi;
import android.content.res.ColorStateList;
import android.graphics.drawable.Drawable;
import android.os.Build;
import android.os.Handler;
import android.os.Looper;
import android.text.TextUtils;
import android.util.Log;
import android.util.LongSparseArray;
import android.util.SparseArray;
import android.util.SparseBooleanArray;
import android.util.SparseIntArray;
import android.util.SparseLongArray;
import android.view.Choreographer;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import androidx.annotation.MainThread;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.annotation.RestrictTo;
import androidx.collection.LongSparseArray;
import androidx.core.content.ContextCompat$Api23Impl$;
import androidx.databinding.library.R;
import androidx.lifecycle.Lifecycle;
import androidx.lifecycle.LifecycleObserver;
import androidx.lifecycle.LifecycleOwner;
import androidx.lifecycle.LiveData;
import androidx.lifecycle.Observer;
import androidx.lifecycle.OnLifecycleEvent;
import androidx.viewbinding.ViewBinding;
import java.lang.ref.Reference;
import java.lang.ref.ReferenceQueue;
import java.lang.ref.WeakReference;
import java.util.List;
import java.util.Map;

public abstract class ViewDataBinding extends BaseObservable implements ViewBinding {
  private static final int BINDING_NUMBER_START = 8;
  
  public static final String BINDING_TAG_PREFIX = "binding_";
  
  private static final CreateWeakListener CREATE_LIST_LISTENER;
  
  private static final CreateWeakListener CREATE_LIVE_DATA_LISTENER;
  
  private static final CreateWeakListener CREATE_MAP_LISTENER;
  
  private static final CreateWeakListener CREATE_PROPERTY_LISTENER;
  
  private static final int HALTED = 2;
  
  private static final int REBIND = 1;
  
  private static final CallbackRegistry.NotifierCallback<OnRebindCallback, ViewDataBinding, Void> REBIND_NOTIFIER;
  
  private static final int REBOUND = 3;
  
  private static final View.OnAttachStateChangeListener ROOT_REATTACHED_LISTENER;
  
  static int SDK_INT = Build.VERSION.SDK_INT;
  
  private static final boolean USE_CHOREOGRAPHER = true;
  
  private static final ReferenceQueue<ViewDataBinding> sReferenceQueue;
  
  protected final DataBindingComponent mBindingComponent;
  
  private Choreographer mChoreographer;
  
  private ViewDataBinding mContainingBinding;
  
  private final Choreographer.FrameCallback mFrameCallback;
  
  private boolean mInLiveDataRegisterObserver;
  
  @RestrictTo({RestrictTo.Scope.LIBRARY_GROUP})
  protected boolean mInStateFlowRegisterObserver;
  
  private boolean mIsExecutingPendingBindings;
  
  private LifecycleOwner mLifecycleOwner;
  
  private WeakListener[] mLocalFieldObservers;
  
  private OnStartListener mOnStartListener;
  
  private boolean mPendingRebind = false;
  
  private CallbackRegistry<OnRebindCallback, ViewDataBinding, Void> mRebindCallbacks;
  
  private boolean mRebindHalted = false;
  
  private final Runnable mRebindRunnable = new Runnable() {
      public void run() {
        // Byte code:
        //   0: aload_0
        //   1: monitorenter
        //   2: aload_0
        //   3: getfield this$0 : Landroidx/databinding/ViewDataBinding;
        //   6: iconst_0
        //   7: invokestatic access$202 : (Landroidx/databinding/ViewDataBinding;Z)Z
        //   10: pop
        //   11: aload_0
        //   12: monitorexit
        //   13: invokestatic access$300 : ()V
        //   16: aload_0
        //   17: getfield this$0 : Landroidx/databinding/ViewDataBinding;
        //   20: invokestatic access$400 : (Landroidx/databinding/ViewDataBinding;)Landroid/view/View;
        //   23: invokevirtual isAttachedToWindow : ()Z
        //   26: ifne -> 56
        //   29: aload_0
        //   30: getfield this$0 : Landroidx/databinding/ViewDataBinding;
        //   33: invokestatic access$400 : (Landroidx/databinding/ViewDataBinding;)Landroid/view/View;
        //   36: invokestatic access$500 : ()Landroid/view/View$OnAttachStateChangeListener;
        //   39: invokevirtual removeOnAttachStateChangeListener : (Landroid/view/View$OnAttachStateChangeListener;)V
        //   42: aload_0
        //   43: getfield this$0 : Landroidx/databinding/ViewDataBinding;
        //   46: invokestatic access$400 : (Landroidx/databinding/ViewDataBinding;)Landroid/view/View;
        //   49: invokestatic access$500 : ()Landroid/view/View$OnAttachStateChangeListener;
        //   52: invokevirtual addOnAttachStateChangeListener : (Landroid/view/View$OnAttachStateChangeListener;)V
        //   55: return
        //   56: aload_0
        //   57: getfield this$0 : Landroidx/databinding/ViewDataBinding;
        //   60: invokevirtual executePendingBindings : ()V
        //   63: return
        //   64: astore_1
        //   65: aload_0
        //   66: monitorexit
        //   67: aload_1
        //   68: athrow
        // Exception table:
        //   from	to	target	type
        //   2	13	64	finally
        //   65	67	64	finally
      }
    };
  
  private final View mRoot;
  
  private Handler mUIThreadHandler;
  
  static {
    CREATE_PROPERTY_LISTENER = new CreateWeakListener() {
        public WeakListener create(ViewDataBinding param1ViewDataBinding, int param1Int, ReferenceQueue<ViewDataBinding> param1ReferenceQueue) {
          return (new ViewDataBinding.WeakPropertyListener(param1ViewDataBinding, param1Int, param1ReferenceQueue)).getListener();
        }
      };
    CREATE_LIST_LISTENER = new CreateWeakListener() {
        public WeakListener create(ViewDataBinding param1ViewDataBinding, int param1Int, ReferenceQueue<ViewDataBinding> param1ReferenceQueue) {
          return (new ViewDataBinding.WeakListListener(param1ViewDataBinding, param1Int, param1ReferenceQueue)).getListener();
        }
      };
    CREATE_MAP_LISTENER = new CreateWeakListener() {
        public WeakListener create(ViewDataBinding param1ViewDataBinding, int param1Int, ReferenceQueue<ViewDataBinding> param1ReferenceQueue) {
          return (new ViewDataBinding.WeakMapListener(param1ViewDataBinding, param1Int, param1ReferenceQueue)).getListener();
        }
      };
    CREATE_LIVE_DATA_LISTENER = new CreateWeakListener() {
        public WeakListener create(ViewDataBinding param1ViewDataBinding, int param1Int, ReferenceQueue<ViewDataBinding> param1ReferenceQueue) {
          return (new ViewDataBinding.LiveDataListener(param1ViewDataBinding, param1Int, param1ReferenceQueue)).getListener();
        }
      };
    REBIND_NOTIFIER = new CallbackRegistry.NotifierCallback<OnRebindCallback, ViewDataBinding, Void>() {
        public void onNotifyCallback(OnRebindCallback param1OnRebindCallback, ViewDataBinding param1ViewDataBinding, int param1Int, Void param1Void) {
          if (param1Int != 1) {
            if (param1Int != 2) {
              if (param1Int != 3)
                return; 
              param1OnRebindCallback.onBound(param1ViewDataBinding);
              return;
            } 
            param1OnRebindCallback.onCanceled(param1ViewDataBinding);
            return;
          } 
          if (!param1OnRebindCallback.onPreBind(param1ViewDataBinding))
            ViewDataBinding.access$002(param1ViewDataBinding, true); 
        }
      };
    sReferenceQueue = new ReferenceQueue<ViewDataBinding>();
    ROOT_REATTACHED_LISTENER = new View.OnAttachStateChangeListener() {
        @TargetApi(19)
        public void onViewAttachedToWindow(View param1View) {
          (ViewDataBinding.getBinding(param1View)).mRebindRunnable.run();
          param1View.removeOnAttachStateChangeListener(this);
        }
        
        public void onViewDetachedFromWindow(View param1View) {}
      };
  }
  
  protected ViewDataBinding(DataBindingComponent paramDataBindingComponent, View paramView, int paramInt) {
    this.mBindingComponent = paramDataBindingComponent;
    this.mLocalFieldObservers = new WeakListener[paramInt];
    this.mRoot = paramView;
    if (Looper.myLooper() != null) {
      if (USE_CHOREOGRAPHER) {
        this.mChoreographer = Choreographer.getInstance();
        this.mFrameCallback = new Choreographer.FrameCallback() {
            public void doFrame(long param1Long) {
              ViewDataBinding.this.mRebindRunnable.run();
            }
          };
        return;
      } 
      this.mFrameCallback = null;
      this.mUIThreadHandler = new Handler(Looper.myLooper());
      return;
    } 
    throw new IllegalStateException("DataBinding must be created in view's UI Thread");
  }
  
  protected ViewDataBinding(Object paramObject, View paramView, int paramInt) {
    this(checkAndCastToBindingComponent(paramObject), paramView, paramInt);
  }
  
  protected static ViewDataBinding bind(Object paramObject, View paramView, int paramInt) {
    return DataBindingUtil.bind(checkAndCastToBindingComponent(paramObject), paramView, paramInt);
  }
  
  private static DataBindingComponent checkAndCastToBindingComponent(Object paramObject) {
    if (paramObject == null)
      return null; 
    if (paramObject instanceof DataBindingComponent)
      return (DataBindingComponent)paramObject; 
    throw new IllegalArgumentException("The provided bindingComponent parameter must be an instance of DataBindingComponent. See  https://issuetracker.google.com/issues/116541301 for details of why this parameter is not defined as DataBindingComponent");
  }
  
  private void executeBindingsInternal() {
    if (this.mIsExecutingPendingBindings) {
      requestRebind();
      return;
    } 
    if (!hasPendingBindings())
      return; 
    this.mIsExecutingPendingBindings = true;
    this.mRebindHalted = false;
    CallbackRegistry<OnRebindCallback, ViewDataBinding, Void> callbackRegistry = this.mRebindCallbacks;
    if (callbackRegistry != null) {
      callbackRegistry.notifyCallbacks(this, 1, null);
      if (this.mRebindHalted)
        this.mRebindCallbacks.notifyCallbacks(this, 2, null); 
    } 
    if (!this.mRebindHalted) {
      executeBindings();
      callbackRegistry = this.mRebindCallbacks;
      if (callbackRegistry != null)
        callbackRegistry.notifyCallbacks(this, 3, null); 
    } 
    this.mIsExecutingPendingBindings = false;
  }
  
  protected static void executeBindingsOn(ViewDataBinding paramViewDataBinding) {
    paramViewDataBinding.executeBindingsInternal();
  }
  
  private static int findIncludeIndex(String paramString, int paramInt1, IncludedLayouts paramIncludedLayouts, int paramInt2) {
    CharSequence charSequence = paramString.subSequence(paramString.indexOf('/') + 1, paramString.length() - 2);
    String[] arrayOfString = paramIncludedLayouts.layouts[paramInt2];
    paramInt2 = arrayOfString.length;
    while (paramInt1 < paramInt2) {
      if (TextUtils.equals(charSequence, arrayOfString[paramInt1]))
        return paramInt1; 
      paramInt1++;
    } 
    return -1;
  }
  
  private static int findLastMatching(ViewGroup paramViewGroup, int paramInt) {
    String str1 = (String)paramViewGroup.getChildAt(paramInt).getTag();
    String str2 = str1.substring(0, str1.length() - 1);
    int k = str2.length();
    int m = paramViewGroup.getChildCount();
    int j = paramInt + 1;
    int i = paramInt;
    paramInt = j;
    while (paramInt < m) {
      View view = paramViewGroup.getChildAt(paramInt);
      if (view.getTag() instanceof String) {
        String str = (String)view.getTag();
      } else {
        view = null;
      } 
      j = i;
      if (view != null) {
        j = i;
        if (view.startsWith(str2)) {
          if (view.length() == str1.length() && view.charAt(view.length() - 1) == '0')
            return i; 
          j = i;
          if (isNumeric((String)view, k))
            j = paramInt; 
        } 
      } 
      paramInt++;
      i = j;
    } 
    return i;
  }
  
  static ViewDataBinding getBinding(View paramView) {
    return (paramView != null) ? (ViewDataBinding)paramView.getTag(R.id.dataBinding) : null;
  }
  
  public static int getBuildSdkInt() {
    return SDK_INT;
  }
  
  protected static int getColorFromResource(View paramView, int paramInt) {
    return (Build.VERSION.SDK_INT >= 23) ? ContextCompat$Api23Impl$.ExternalSyntheticApiModelOutline1.m(paramView.getContext(), paramInt) : paramView.getResources().getColor(paramInt);
  }
  
  protected static ColorStateList getColorStateListFromResource(View paramView, int paramInt) {
    return (Build.VERSION.SDK_INT >= 23) ? ViewDataBinding$.ExternalSyntheticApiModelOutline0.m(paramView.getContext(), paramInt) : paramView.getResources().getColorStateList(paramInt);
  }
  
  protected static Drawable getDrawableFromResource(View paramView, int paramInt) {
    return paramView.getContext().getDrawable(paramInt);
  }
  
  protected static <K, T> T getFrom(Map<K, T> paramMap, K paramK) {
    return (paramMap == null) ? null : paramMap.get(paramK);
  }
  
  protected static byte getFromArray(byte[] paramArrayOfbyte, int paramInt) {
    return (paramArrayOfbyte == null || paramInt < 0 || paramInt >= paramArrayOfbyte.length) ? 0 : paramArrayOfbyte[paramInt];
  }
  
  protected static char getFromArray(char[] paramArrayOfchar, int paramInt) {
    return (paramArrayOfchar == null || paramInt < 0 || paramInt >= paramArrayOfchar.length) ? Character.MIN_VALUE : paramArrayOfchar[paramInt];
  }
  
  protected static double getFromArray(double[] paramArrayOfdouble, int paramInt) {
    return (paramArrayOfdouble == null || paramInt < 0 || paramInt >= paramArrayOfdouble.length) ? 0.0D : paramArrayOfdouble[paramInt];
  }
  
  protected static float getFromArray(float[] paramArrayOffloat, int paramInt) {
    return (paramArrayOffloat == null || paramInt < 0 || paramInt >= paramArrayOffloat.length) ? 0.0F : paramArrayOffloat[paramInt];
  }
  
  protected static int getFromArray(int[] paramArrayOfint, int paramInt) {
    return (paramArrayOfint == null || paramInt < 0 || paramInt >= paramArrayOfint.length) ? 0 : paramArrayOfint[paramInt];
  }
  
  protected static long getFromArray(long[] paramArrayOflong, int paramInt) {
    return (paramArrayOflong == null || paramInt < 0 || paramInt >= paramArrayOflong.length) ? 0L : paramArrayOflong[paramInt];
  }
  
  protected static <T> T getFromArray(T[] paramArrayOfT, int paramInt) {
    return (paramArrayOfT == null || paramInt < 0 || paramInt >= paramArrayOfT.length) ? null : paramArrayOfT[paramInt];
  }
  
  protected static short getFromArray(short[] paramArrayOfshort, int paramInt) {
    return (paramArrayOfshort == null || paramInt < 0 || paramInt >= paramArrayOfshort.length) ? 0 : paramArrayOfshort[paramInt];
  }
  
  protected static boolean getFromArray(boolean[] paramArrayOfboolean, int paramInt) {
    return (paramArrayOfboolean == null || paramInt < 0 || paramInt >= paramArrayOfboolean.length) ? false : paramArrayOfboolean[paramInt];
  }
  
  protected static int getFromList(SparseIntArray paramSparseIntArray, int paramInt) {
    return (paramSparseIntArray == null || paramInt < 0) ? 0 : paramSparseIntArray.get(paramInt);
  }
  
  @TargetApi(18)
  protected static long getFromList(SparseLongArray paramSparseLongArray, int paramInt) {
    return (paramSparseLongArray == null || paramInt < 0) ? 0L : paramSparseLongArray.get(paramInt);
  }
  
  @TargetApi(16)
  protected static <T> T getFromList(LongSparseArray<T> paramLongSparseArray, int paramInt) {
    return (T)((paramLongSparseArray == null || paramInt < 0) ? null : paramLongSparseArray.get(paramInt));
  }
  
  protected static <T> T getFromList(SparseArray<T> paramSparseArray, int paramInt) {
    return (T)((paramSparseArray == null || paramInt < 0) ? null : paramSparseArray.get(paramInt));
  }
  
  protected static <T> T getFromList(LongSparseArray<T> paramLongSparseArray, int paramInt) {
    return (T)((paramLongSparseArray == null || paramInt < 0) ? null : paramLongSparseArray.get(paramInt));
  }
  
  protected static <T> T getFromList(List<T> paramList, int paramInt) {
    return (paramList == null || paramInt < 0 || paramInt >= paramList.size()) ? null : paramList.get(paramInt);
  }
  
  protected static boolean getFromList(SparseBooleanArray paramSparseBooleanArray, int paramInt) {
    return (paramSparseBooleanArray == null || paramInt < 0) ? false : paramSparseBooleanArray.get(paramInt);
  }
  
  @RestrictTo({RestrictTo.Scope.LIBRARY_GROUP})
  protected static <T extends ViewDataBinding> T inflateInternal(@NonNull LayoutInflater paramLayoutInflater, int paramInt, @Nullable ViewGroup paramViewGroup, boolean paramBoolean, @Nullable Object paramObject) {
    return (T)DataBindingUtil.inflate(paramLayoutInflater, paramInt, paramViewGroup, paramBoolean, checkAndCastToBindingComponent(paramObject));
  }
  
  private static boolean isNumeric(String paramString, int paramInt) {
    int j = paramString.length();
    int i = paramInt;
    if (j == paramInt)
      return false; 
    while (i < j) {
      if (!Character.isDigit(paramString.charAt(i)))
        return false; 
      i++;
    } 
    return true;
  }
  
  private static void mapBindings(DataBindingComponent paramDataBindingComponent, View paramView, Object[] paramArrayOfObject, IncludedLayouts paramIncludedLayouts, SparseIntArray paramSparseIntArray, boolean paramBoolean) {
    // Byte code:
    //   0: aload_1
    //   1: invokestatic getBinding : (Landroid/view/View;)Landroidx/databinding/ViewDataBinding;
    //   4: ifnull -> 8
    //   7: return
    //   8: aload_1
    //   9: invokevirtual getTag : ()Ljava/lang/Object;
    //   12: astore #14
    //   14: aload #14
    //   16: instanceof java/lang/String
    //   19: ifeq -> 32
    //   22: aload #14
    //   24: checkcast java/lang/String
    //   27: astore #14
    //   29: goto -> 35
    //   32: aconst_null
    //   33: astore #14
    //   35: iload #5
    //   37: ifeq -> 129
    //   40: aload #14
    //   42: ifnull -> 129
    //   45: aload #14
    //   47: ldc_w 'layout'
    //   50: invokevirtual startsWith : (Ljava/lang/String;)Z
    //   53: ifeq -> 129
    //   56: aload #14
    //   58: bipush #95
    //   60: invokevirtual lastIndexOf : (I)I
    //   63: istore #6
    //   65: iload #6
    //   67: ifle -> 120
    //   70: iload #6
    //   72: iconst_1
    //   73: iadd
    //   74: istore #6
    //   76: aload #14
    //   78: iload #6
    //   80: invokestatic isNumeric : (Ljava/lang/String;I)Z
    //   83: ifeq -> 120
    //   86: aload #14
    //   88: iload #6
    //   90: invokestatic parseTagInt : (Ljava/lang/String;I)I
    //   93: istore #7
    //   95: aload_2
    //   96: iload #7
    //   98: aaload
    //   99: ifnonnull -> 107
    //   102: aload_2
    //   103: iload #7
    //   105: aload_1
    //   106: aastore
    //   107: aload_3
    //   108: ifnonnull -> 114
    //   111: iconst_m1
    //   112: istore #7
    //   114: iconst_1
    //   115: istore #6
    //   117: goto -> 126
    //   120: iconst_m1
    //   121: istore #7
    //   123: iconst_0
    //   124: istore #6
    //   126: goto -> 189
    //   129: aload #14
    //   131: ifnull -> 183
    //   134: aload #14
    //   136: ldc 'binding_'
    //   138: invokevirtual startsWith : (Ljava/lang/String;)Z
    //   141: ifeq -> 183
    //   144: aload #14
    //   146: getstatic androidx/databinding/ViewDataBinding.BINDING_NUMBER_START : I
    //   149: invokestatic parseTagInt : (Ljava/lang/String;I)I
    //   152: istore #6
    //   154: aload_2
    //   155: iload #6
    //   157: aaload
    //   158: ifnonnull -> 166
    //   161: aload_2
    //   162: iload #6
    //   164: aload_1
    //   165: aastore
    //   166: aload_3
    //   167: ifnonnull -> 173
    //   170: iconst_m1
    //   171: istore #6
    //   173: iload #6
    //   175: istore #7
    //   177: iconst_1
    //   178: istore #6
    //   180: goto -> 189
    //   183: iconst_0
    //   184: istore #6
    //   186: iconst_m1
    //   187: istore #7
    //   189: iload #6
    //   191: ifne -> 237
    //   194: aload_1
    //   195: invokevirtual getId : ()I
    //   198: istore #6
    //   200: iload #6
    //   202: ifle -> 237
    //   205: aload #4
    //   207: ifnull -> 237
    //   210: aload #4
    //   212: iload #6
    //   214: iconst_m1
    //   215: invokevirtual get : (II)I
    //   218: istore #6
    //   220: iload #6
    //   222: iflt -> 237
    //   225: aload_2
    //   226: iload #6
    //   228: aaload
    //   229: ifnonnull -> 237
    //   232: aload_2
    //   233: iload #6
    //   235: aload_1
    //   236: aastore
    //   237: aload_1
    //   238: instanceof android/view/ViewGroup
    //   241: ifeq -> 539
    //   244: aload_1
    //   245: checkcast android/view/ViewGroup
    //   248: astore_1
    //   249: aload_1
    //   250: invokevirtual getChildCount : ()I
    //   253: istore #11
    //   255: iconst_0
    //   256: istore #6
    //   258: iconst_0
    //   259: istore #8
    //   261: iload #6
    //   263: iload #11
    //   265: if_icmpge -> 539
    //   268: aload_1
    //   269: iload #6
    //   271: invokevirtual getChildAt : (I)Landroid/view/View;
    //   274: astore #14
    //   276: iload #7
    //   278: iflt -> 495
    //   281: aload #14
    //   283: invokevirtual getTag : ()Ljava/lang/Object;
    //   286: instanceof java/lang/String
    //   289: ifeq -> 495
    //   292: aload #14
    //   294: invokevirtual getTag : ()Ljava/lang/Object;
    //   297: checkcast java/lang/String
    //   300: astore #15
    //   302: aload #15
    //   304: ldc_w '_0'
    //   307: invokevirtual endsWith : (Ljava/lang/String;)Z
    //   310: ifeq -> 495
    //   313: aload #15
    //   315: ldc_w 'layout'
    //   318: invokevirtual startsWith : (Ljava/lang/String;)Z
    //   321: ifeq -> 495
    //   324: aload #15
    //   326: bipush #47
    //   328: invokevirtual indexOf : (I)I
    //   331: ifle -> 495
    //   334: aload #15
    //   336: iload #8
    //   338: aload_3
    //   339: iload #7
    //   341: invokestatic findIncludeIndex : (Ljava/lang/String;ILandroidx/databinding/ViewDataBinding$IncludedLayouts;I)I
    //   344: istore #9
    //   346: iload #9
    //   348: iflt -> 495
    //   351: aload_3
    //   352: getfield indexes : [[I
    //   355: iload #7
    //   357: aaload
    //   358: iload #9
    //   360: iaload
    //   361: istore #10
    //   363: aload_3
    //   364: getfield layoutIds : [[I
    //   367: iload #7
    //   369: aaload
    //   370: iload #9
    //   372: iaload
    //   373: istore #12
    //   375: aload_1
    //   376: iload #6
    //   378: invokestatic findLastMatching : (Landroid/view/ViewGroup;I)I
    //   381: istore #8
    //   383: iload #8
    //   385: iload #6
    //   387: if_icmpne -> 422
    //   390: aload_2
    //   391: iload #10
    //   393: aload_0
    //   394: aload #14
    //   396: iload #12
    //   398: invokestatic bind : (Landroidx/databinding/DataBindingComponent;Landroid/view/View;I)Landroidx/databinding/ViewDataBinding;
    //   401: aastore
    //   402: iload #9
    //   404: iconst_1
    //   405: iadd
    //   406: istore #10
    //   408: iconst_1
    //   409: istore #8
    //   411: iload #6
    //   413: istore #9
    //   415: iload #10
    //   417: istore #6
    //   419: goto -> 506
    //   422: iload #8
    //   424: iload #6
    //   426: isub
    //   427: iconst_1
    //   428: iadd
    //   429: istore #13
    //   431: iload #13
    //   433: anewarray android/view/View
    //   436: astore #15
    //   438: iconst_0
    //   439: istore #8
    //   441: iload #8
    //   443: iload #13
    //   445: if_icmpge -> 471
    //   448: aload #15
    //   450: iload #8
    //   452: aload_1
    //   453: iload #6
    //   455: iload #8
    //   457: iadd
    //   458: invokevirtual getChildAt : (I)Landroid/view/View;
    //   461: aastore
    //   462: iload #8
    //   464: iconst_1
    //   465: iadd
    //   466: istore #8
    //   468: goto -> 441
    //   471: aload_2
    //   472: iload #10
    //   474: aload_0
    //   475: aload #15
    //   477: iload #12
    //   479: invokestatic bind : (Landroidx/databinding/DataBindingComponent;[Landroid/view/View;I)Landroidx/databinding/ViewDataBinding;
    //   482: aastore
    //   483: iload #6
    //   485: iload #13
    //   487: iconst_1
    //   488: isub
    //   489: iadd
    //   490: istore #6
    //   492: goto -> 402
    //   495: iload #6
    //   497: istore #9
    //   499: iload #8
    //   501: istore #6
    //   503: iconst_0
    //   504: istore #8
    //   506: iload #8
    //   508: ifne -> 522
    //   511: aload_0
    //   512: aload #14
    //   514: aload_2
    //   515: aload_3
    //   516: aload #4
    //   518: iconst_0
    //   519: invokestatic mapBindings : (Landroidx/databinding/DataBindingComponent;Landroid/view/View;[Ljava/lang/Object;Landroidx/databinding/ViewDataBinding$IncludedLayouts;Landroid/util/SparseIntArray;Z)V
    //   522: iload #9
    //   524: iconst_1
    //   525: iadd
    //   526: istore #9
    //   528: iload #6
    //   530: istore #8
    //   532: iload #9
    //   534: istore #6
    //   536: goto -> 261
    //   539: return
  }
  
  protected static Object[] mapBindings(DataBindingComponent paramDataBindingComponent, View paramView, int paramInt, IncludedLayouts paramIncludedLayouts, SparseIntArray paramSparseIntArray) {
    Object[] arrayOfObject = new Object[paramInt];
    mapBindings(paramDataBindingComponent, paramView, arrayOfObject, paramIncludedLayouts, paramSparseIntArray, true);
    return arrayOfObject;
  }
  
  protected static Object[] mapBindings(DataBindingComponent paramDataBindingComponent, View[] paramArrayOfView, int paramInt, IncludedLayouts paramIncludedLayouts, SparseIntArray paramSparseIntArray) {
    Object[] arrayOfObject = new Object[paramInt];
    for (paramInt = 0; paramInt < paramArrayOfView.length; paramInt++)
      mapBindings(paramDataBindingComponent, paramArrayOfView[paramInt], arrayOfObject, paramIncludedLayouts, paramSparseIntArray, true); 
    return arrayOfObject;
  }
  
  protected static byte parse(String paramString, byte paramByte) {
    try {
      return Byte.parseByte(paramString);
    } catch (NumberFormatException numberFormatException) {
      return paramByte;
    } 
  }
  
  protected static char parse(String paramString, char paramChar) {
    return (paramString != null) ? (paramString.isEmpty() ? paramChar : paramString.charAt(0)) : paramChar;
  }
  
  protected static double parse(String paramString, double paramDouble) {
    try {
      return Double.parseDouble(paramString);
    } catch (NumberFormatException numberFormatException) {
      return paramDouble;
    } 
  }
  
  protected static float parse(String paramString, float paramFloat) {
    try {
      return Float.parseFloat(paramString);
    } catch (NumberFormatException numberFormatException) {
      return paramFloat;
    } 
  }
  
  protected static int parse(String paramString, int paramInt) {
    try {
      return Integer.parseInt(paramString);
    } catch (NumberFormatException numberFormatException) {
      return paramInt;
    } 
  }
  
  protected static long parse(String paramString, long paramLong) {
    try {
      return Long.parseLong(paramString);
    } catch (NumberFormatException numberFormatException) {
      return paramLong;
    } 
  }
  
  protected static short parse(String paramString, short paramShort) {
    try {
      return Short.parseShort(paramString);
    } catch (NumberFormatException numberFormatException) {
      return paramShort;
    } 
  }
  
  protected static boolean parse(String paramString, boolean paramBoolean) {
    return (paramString == null) ? paramBoolean : Boolean.parseBoolean(paramString);
  }
  
  private static int parseTagInt(String paramString, int paramInt) {
    int j = paramString.length();
    int i = 0;
    while (paramInt < j) {
      i = i * 10 + paramString.charAt(paramInt) - 48;
      paramInt++;
    } 
    return i;
  }
  
  private static void processReferenceQueue() {
    while (true) {
      Reference<? extends ViewDataBinding> reference = sReferenceQueue.poll();
      if (reference != null) {
        if (reference instanceof WeakListener)
          ((WeakListener)reference).unregister(); 
        continue;
      } 
      break;
    } 
  }
  
  protected static byte safeUnbox(Byte paramByte) {
    return (paramByte == null) ? 0 : paramByte.byteValue();
  }
  
  protected static char safeUnbox(Character paramCharacter) {
    return (paramCharacter == null) ? Character.MIN_VALUE : paramCharacter.charValue();
  }
  
  protected static double safeUnbox(Double paramDouble) {
    return (paramDouble == null) ? 0.0D : paramDouble.doubleValue();
  }
  
  protected static float safeUnbox(Float paramFloat) {
    return (paramFloat == null) ? 0.0F : paramFloat.floatValue();
  }
  
  protected static int safeUnbox(Integer paramInteger) {
    return (paramInteger == null) ? 0 : paramInteger.intValue();
  }
  
  protected static long safeUnbox(Long paramLong) {
    return (paramLong == null) ? 0L : paramLong.longValue();
  }
  
  protected static short safeUnbox(Short paramShort) {
    return (paramShort == null) ? 0 : paramShort.shortValue();
  }
  
  protected static boolean safeUnbox(Boolean paramBoolean) {
    return (paramBoolean == null) ? false : paramBoolean.booleanValue();
  }
  
  protected static void setBindingInverseListener(ViewDataBinding paramViewDataBinding, InverseBindingListener paramInverseBindingListener, PropertyChangedInverseListener paramPropertyChangedInverseListener) {
    if (paramInverseBindingListener != paramPropertyChangedInverseListener) {
      if (paramInverseBindingListener != null)
        paramViewDataBinding.removeOnPropertyChangedCallback((PropertyChangedInverseListener)paramInverseBindingListener); 
      if (paramPropertyChangedInverseListener != null)
        paramViewDataBinding.addOnPropertyChangedCallback(paramPropertyChangedInverseListener); 
    } 
  }
  
  @TargetApi(16)
  protected static <T> void setTo(LongSparseArray<T> paramLongSparseArray, int paramInt, T paramT) {
    if (paramLongSparseArray != null && paramInt >= 0) {
      if (paramInt >= paramLongSparseArray.size())
        return; 
      paramLongSparseArray.put(paramInt, paramT);
    } 
  }
  
  protected static <T> void setTo(SparseArray<T> paramSparseArray, int paramInt, T paramT) {
    if (paramSparseArray != null && paramInt >= 0) {
      if (paramInt >= paramSparseArray.size())
        return; 
      paramSparseArray.put(paramInt, paramT);
    } 
  }
  
  protected static void setTo(SparseBooleanArray paramSparseBooleanArray, int paramInt, boolean paramBoolean) {
    if (paramSparseBooleanArray != null && paramInt >= 0) {
      if (paramInt >= paramSparseBooleanArray.size())
        return; 
      paramSparseBooleanArray.put(paramInt, paramBoolean);
    } 
  }
  
  protected static void setTo(SparseIntArray paramSparseIntArray, int paramInt1, int paramInt2) {
    if (paramSparseIntArray != null && paramInt1 >= 0) {
      if (paramInt1 >= paramSparseIntArray.size())
        return; 
      paramSparseIntArray.put(paramInt1, paramInt2);
    } 
  }
  
  @TargetApi(18)
  protected static void setTo(SparseLongArray paramSparseLongArray, int paramInt, long paramLong) {
    if (paramSparseLongArray != null && paramInt >= 0) {
      if (paramInt >= paramSparseLongArray.size())
        return; 
      paramSparseLongArray.put(paramInt, paramLong);
    } 
  }
  
  protected static <T> void setTo(LongSparseArray<T> paramLongSparseArray, int paramInt, T paramT) {
    if (paramLongSparseArray != null && paramInt >= 0) {
      if (paramInt >= paramLongSparseArray.size())
        return; 
      paramLongSparseArray.put(paramInt, paramT);
    } 
  }
  
  protected static <T> void setTo(List<T> paramList, int paramInt, T paramT) {
    if (paramList != null && paramInt >= 0) {
      if (paramInt >= paramList.size())
        return; 
      paramList.set(paramInt, paramT);
    } 
  }
  
  protected static <K, T> void setTo(Map<K, T> paramMap, K paramK, T paramT) {
    if (paramMap == null)
      return; 
    paramMap.put(paramK, paramT);
  }
  
  protected static void setTo(byte[] paramArrayOfbyte, int paramInt, byte paramByte) {
    if (paramArrayOfbyte != null && paramInt >= 0) {
      if (paramInt >= paramArrayOfbyte.length)
        return; 
      paramArrayOfbyte[paramInt] = paramByte;
    } 
  }
  
  protected static void setTo(char[] paramArrayOfchar, int paramInt, char paramChar) {
    if (paramArrayOfchar != null && paramInt >= 0) {
      if (paramInt >= paramArrayOfchar.length)
        return; 
      paramArrayOfchar[paramInt] = paramChar;
    } 
  }
  
  protected static void setTo(double[] paramArrayOfdouble, int paramInt, double paramDouble) {
    if (paramArrayOfdouble != null && paramInt >= 0) {
      if (paramInt >= paramArrayOfdouble.length)
        return; 
      paramArrayOfdouble[paramInt] = paramDouble;
    } 
  }
  
  protected static void setTo(float[] paramArrayOffloat, int paramInt, float paramFloat) {
    if (paramArrayOffloat != null && paramInt >= 0) {
      if (paramInt >= paramArrayOffloat.length)
        return; 
      paramArrayOffloat[paramInt] = paramFloat;
    } 
  }
  
  protected static void setTo(int[] paramArrayOfint, int paramInt1, int paramInt2) {
    if (paramArrayOfint != null && paramInt1 >= 0) {
      if (paramInt1 >= paramArrayOfint.length)
        return; 
      paramArrayOfint[paramInt1] = paramInt2;
    } 
  }
  
  protected static void setTo(long[] paramArrayOflong, int paramInt, long paramLong) {
    if (paramArrayOflong != null && paramInt >= 0) {
      if (paramInt >= paramArrayOflong.length)
        return; 
      paramArrayOflong[paramInt] = paramLong;
    } 
  }
  
  protected static <T> void setTo(T[] paramArrayOfT, int paramInt, T paramT) {
    if (paramArrayOfT != null && paramInt >= 0) {
      if (paramInt >= paramArrayOfT.length)
        return; 
      paramArrayOfT[paramInt] = paramT;
    } 
  }
  
  protected static void setTo(short[] paramArrayOfshort, int paramInt, short paramShort) {
    if (paramArrayOfshort != null && paramInt >= 0) {
      if (paramInt >= paramArrayOfshort.length)
        return; 
      paramArrayOfshort[paramInt] = paramShort;
    } 
  }
  
  protected static void setTo(boolean[] paramArrayOfboolean, int paramInt, boolean paramBoolean) {
    if (paramArrayOfboolean != null && paramInt >= 0) {
      if (paramInt >= paramArrayOfboolean.length)
        return; 
      paramArrayOfboolean[paramInt] = paramBoolean;
    } 
  }
  
  public void addOnRebindCallback(@NonNull OnRebindCallback paramOnRebindCallback) {
    if (this.mRebindCallbacks == null)
      this.mRebindCallbacks = new CallbackRegistry(REBIND_NOTIFIER); 
    this.mRebindCallbacks.add(paramOnRebindCallback);
  }
  
  protected void ensureBindingComponentIsNotNull(Class<?> paramClass) {
    if (this.mBindingComponent != null)
      return; 
    StringBuilder stringBuilder = new StringBuilder();
    stringBuilder.append("Required DataBindingComponent is null in class ");
    stringBuilder.append(getClass().getSimpleName());
    stringBuilder.append(". A BindingAdapter in ");
    stringBuilder.append(paramClass.getCanonicalName());
    stringBuilder.append(" is not static and requires an object to use, retrieved from the DataBindingComponent. If you don't use an inflation method taking a DataBindingComponent, use DataBindingUtil.setDefaultComponent or make all BindingAdapter methods static.");
    throw new IllegalStateException(stringBuilder.toString());
  }
  
  protected abstract void executeBindings();
  
  public void executePendingBindings() {
    ViewDataBinding viewDataBinding = this.mContainingBinding;
    if (viewDataBinding == null) {
      executeBindingsInternal();
      return;
    } 
    viewDataBinding.executePendingBindings();
  }
  
  void forceExecuteBindings() {
    executeBindings();
  }
  
  @Nullable
  public LifecycleOwner getLifecycleOwner() {
    return this.mLifecycleOwner;
  }
  
  protected Object getObservedField(int paramInt) {
    WeakListener weakListener = this.mLocalFieldObservers[paramInt];
    return (weakListener == null) ? null : weakListener.getTarget();
  }
  
  @NonNull
  public View getRoot() {
    return this.mRoot;
  }
  
  @RestrictTo({RestrictTo.Scope.LIBRARY_GROUP})
  protected void handleFieldChange(int paramInt1, Object paramObject, int paramInt2) {
    if (!this.mInLiveDataRegisterObserver) {
      if (this.mInStateFlowRegisterObserver)
        return; 
      if (onFieldChange(paramInt1, paramObject, paramInt2))
        requestRebind(); 
    } 
  }
  
  public abstract boolean hasPendingBindings();
  
  public abstract void invalidateAll();
  
  protected abstract boolean onFieldChange(int paramInt1, Object paramObject, int paramInt2);
  
  protected void registerTo(int paramInt, Object paramObject, CreateWeakListener paramCreateWeakListener) {
    if (paramObject == null)
      return; 
    WeakListener weakListener2 = this.mLocalFieldObservers[paramInt];
    WeakListener weakListener1 = weakListener2;
    if (weakListener2 == null) {
      WeakListener weakListener = paramCreateWeakListener.create(this, paramInt, sReferenceQueue);
      this.mLocalFieldObservers[paramInt] = weakListener;
      LifecycleOwner lifecycleOwner = this.mLifecycleOwner;
      weakListener1 = weakListener;
      if (lifecycleOwner != null) {
        weakListener.setLifecycleOwner(lifecycleOwner);
        weakListener1 = weakListener;
      } 
    } 
    weakListener1.setTarget(paramObject);
  }
  
  public void removeOnRebindCallback(@NonNull OnRebindCallback paramOnRebindCallback) {
    CallbackRegistry<OnRebindCallback, ViewDataBinding, Void> callbackRegistry = this.mRebindCallbacks;
    if (callbackRegistry != null)
      callbackRegistry.remove(paramOnRebindCallback); 
  }
  
  protected void requestRebind() {
    // Byte code:
    //   0: aload_0
    //   1: getfield mContainingBinding : Landroidx/databinding/ViewDataBinding;
    //   4: astore_1
    //   5: aload_1
    //   6: ifnull -> 14
    //   9: aload_1
    //   10: invokevirtual requestRebind : ()V
    //   13: return
    //   14: aload_0
    //   15: getfield mLifecycleOwner : Landroidx/lifecycle/LifecycleOwner;
    //   18: astore_1
    //   19: aload_1
    //   20: ifnull -> 42
    //   23: aload_1
    //   24: invokeinterface getLifecycle : ()Landroidx/lifecycle/Lifecycle;
    //   29: invokevirtual getCurrentState : ()Landroidx/lifecycle/Lifecycle$State;
    //   32: getstatic androidx/lifecycle/Lifecycle$State.STARTED : Landroidx/lifecycle/Lifecycle$State;
    //   35: invokevirtual isAtLeast : (Landroidx/lifecycle/Lifecycle$State;)Z
    //   38: ifne -> 42
    //   41: return
    //   42: aload_0
    //   43: monitorenter
    //   44: aload_0
    //   45: getfield mPendingRebind : Z
    //   48: ifeq -> 54
    //   51: aload_0
    //   52: monitorexit
    //   53: return
    //   54: aload_0
    //   55: iconst_1
    //   56: putfield mPendingRebind : Z
    //   59: aload_0
    //   60: monitorexit
    //   61: getstatic androidx/databinding/ViewDataBinding.USE_CHOREOGRAPHER : Z
    //   64: ifeq -> 79
    //   67: aload_0
    //   68: getfield mChoreographer : Landroid/view/Choreographer;
    //   71: aload_0
    //   72: getfield mFrameCallback : Landroid/view/Choreographer$FrameCallback;
    //   75: invokevirtual postFrameCallback : (Landroid/view/Choreographer$FrameCallback;)V
    //   78: return
    //   79: aload_0
    //   80: getfield mUIThreadHandler : Landroid/os/Handler;
    //   83: aload_0
    //   84: getfield mRebindRunnable : Ljava/lang/Runnable;
    //   87: invokevirtual post : (Ljava/lang/Runnable;)Z
    //   90: pop
    //   91: return
    //   92: astore_1
    //   93: aload_0
    //   94: monitorexit
    //   95: aload_1
    //   96: athrow
    // Exception table:
    //   from	to	target	type
    //   44	53	92	finally
    //   54	61	92	finally
    //   93	95	92	finally
  }
  
  protected void setContainedBinding(ViewDataBinding paramViewDataBinding) {
    if (paramViewDataBinding != null)
      paramViewDataBinding.mContainingBinding = this; 
  }
  
  @MainThread
  public void setLifecycleOwner(@Nullable LifecycleOwner paramLifecycleOwner) {
    if (paramLifecycleOwner instanceof androidx.fragment.app.Fragment)
      Log.w("DataBinding", "Setting the fragment as the LifecycleOwner might cause memory leaks because views lives shorter than the Fragment. Consider using Fragment's view lifecycle"); 
    LifecycleOwner lifecycleOwner = this.mLifecycleOwner;
    if (lifecycleOwner == paramLifecycleOwner)
      return; 
    if (lifecycleOwner != null)
      lifecycleOwner.getLifecycle().removeObserver(this.mOnStartListener); 
    this.mLifecycleOwner = paramLifecycleOwner;
    if (paramLifecycleOwner != null) {
      if (this.mOnStartListener == null)
        this.mOnStartListener = new OnStartListener(this); 
      paramLifecycleOwner.getLifecycle().addObserver(this.mOnStartListener);
    } 
    for (WeakListener weakListener : this.mLocalFieldObservers) {
      if (weakListener != null)
        weakListener.setLifecycleOwner(paramLifecycleOwner); 
    } 
  }
  
  protected void setRootTag(View paramView) {
    paramView.setTag(R.id.dataBinding, this);
  }
  
  protected void setRootTag(View[] paramArrayOfView) {
    int j = paramArrayOfView.length;
    for (int i = 0; i < j; i++)
      paramArrayOfView[i].setTag(R.id.dataBinding, this); 
  }
  
  public abstract boolean setVariable(int paramInt, @Nullable Object paramObject);
  
  public void unbind() {
    for (WeakListener weakListener : this.mLocalFieldObservers) {
      if (weakListener != null)
        weakListener.unregister(); 
    } 
  }
  
  protected boolean unregisterFrom(int paramInt) {
    WeakListener weakListener = this.mLocalFieldObservers[paramInt];
    return (weakListener != null) ? weakListener.unregister() : false;
  }
  
  protected boolean updateLiveDataRegistration(int paramInt, LiveData<?> paramLiveData) {
    this.mInLiveDataRegisterObserver = true;
    try {
      return updateRegistration(paramInt, paramLiveData, CREATE_LIVE_DATA_LISTENER);
    } finally {
      this.mInLiveDataRegisterObserver = false;
    } 
  }
  
  protected boolean updateRegistration(int paramInt, Observable paramObservable) {
    return updateRegistration(paramInt, paramObservable, CREATE_PROPERTY_LISTENER);
  }
  
  protected boolean updateRegistration(int paramInt, ObservableList paramObservableList) {
    return updateRegistration(paramInt, paramObservableList, CREATE_LIST_LISTENER);
  }
  
  protected boolean updateRegistration(int paramInt, ObservableMap paramObservableMap) {
    return updateRegistration(paramInt, paramObservableMap, CREATE_MAP_LISTENER);
  }
  
  @RestrictTo({RestrictTo.Scope.LIBRARY_GROUP})
  protected boolean updateRegistration(int paramInt, Object paramObject, CreateWeakListener paramCreateWeakListener) {
    if (paramObject == null)
      return unregisterFrom(paramInt); 
    WeakListener weakListener = this.mLocalFieldObservers[paramInt];
    if (weakListener == null) {
      registerTo(paramInt, paramObject, paramCreateWeakListener);
      return true;
    } 
    if (weakListener.getTarget() == paramObject)
      return false; 
    unregisterFrom(paramInt);
    registerTo(paramInt, paramObject, paramCreateWeakListener);
    return true;
  }
  
  protected static class IncludedLayouts {
    public final int[][] indexes;
    
    public final int[][] layoutIds;
    
    public final String[][] layouts;
    
    public IncludedLayouts(int param1Int) {
      this.layouts = new String[param1Int][];
      this.indexes = new int[param1Int][];
      this.layoutIds = new int[param1Int][];
    }
    
    public void setIncludes(int param1Int, String[] param1ArrayOfString, int[] param1ArrayOfint1, int[] param1ArrayOfint2) {
      this.layouts[param1Int] = param1ArrayOfString;
      this.indexes[param1Int] = param1ArrayOfint1;
      this.layoutIds[param1Int] = param1ArrayOfint2;
    }
  }
  
  private static class LiveDataListener implements Observer, ObservableReference<LiveData<?>> {
    @Nullable
    WeakReference<LifecycleOwner> mLifecycleOwnerRef = null;
    
    final WeakListener<LiveData<?>> mListener;
    
    public LiveDataListener(ViewDataBinding param1ViewDataBinding, int param1Int, ReferenceQueue<ViewDataBinding> param1ReferenceQueue) {
      this.mListener = new WeakListener(param1ViewDataBinding, param1Int, this, param1ReferenceQueue);
    }
    
    @Nullable
    private LifecycleOwner getLifecycleOwner() {
      WeakReference<LifecycleOwner> weakReference = this.mLifecycleOwnerRef;
      return (weakReference == null) ? null : weakReference.get();
    }
    
    public void addListener(LiveData<?> param1LiveData) {
      LifecycleOwner lifecycleOwner = getLifecycleOwner();
      if (lifecycleOwner != null)
        param1LiveData.observe(lifecycleOwner, this); 
    }
    
    public WeakListener<LiveData<?>> getListener() {
      return this.mListener;
    }
    
    public void onChanged(@Nullable Object param1Object) {
      param1Object = this.mListener.getBinder();
      if (param1Object != null) {
        WeakListener<LiveData<?>> weakListener = this.mListener;
        param1Object.handleFieldChange(weakListener.mLocalFieldId, weakListener.getTarget(), 0);
      } 
    }
    
    public void removeListener(LiveData<?> param1LiveData) {
      param1LiveData.removeObserver(this);
    }
    
    public void setLifecycleOwner(@Nullable LifecycleOwner param1LifecycleOwner) {
      LifecycleOwner lifecycleOwner = getLifecycleOwner();
      LiveData liveData = (LiveData)this.mListener.getTarget();
      if (liveData != null) {
        if (lifecycleOwner != null)
          liveData.removeObserver(this); 
        if (param1LifecycleOwner != null)
          liveData.observe(param1LifecycleOwner, this); 
      } 
      if (param1LifecycleOwner != null)
        this.mLifecycleOwnerRef = new WeakReference<LifecycleOwner>(param1LifecycleOwner); 
    }
  }
  
  static class OnStartListener implements LifecycleObserver {
    final WeakReference<ViewDataBinding> mBinding;
    
    private OnStartListener(ViewDataBinding param1ViewDataBinding) {
      this.mBinding = new WeakReference<ViewDataBinding>(param1ViewDataBinding);
    }
    
    @OnLifecycleEvent(Lifecycle.Event.ON_START)
    public void onStart() {
      ViewDataBinding viewDataBinding = this.mBinding.get();
      if (viewDataBinding != null)
        viewDataBinding.executePendingBindings(); 
    }
  }
  
  protected static abstract class PropertyChangedInverseListener extends Observable.OnPropertyChangedCallback implements InverseBindingListener {
    final int mPropertyId;
    
    public PropertyChangedInverseListener(int param1Int) {
      this.mPropertyId = param1Int;
    }
    
    public void onPropertyChanged(Observable param1Observable, int param1Int) {
      if (param1Int == this.mPropertyId || param1Int == 0)
        onChange(); 
    }
  }
  
  private static class WeakListListener extends ObservableList.OnListChangedCallback implements ObservableReference<ObservableList> {
    final WeakListener<ObservableList> mListener;
    
    public WeakListListener(ViewDataBinding param1ViewDataBinding, int param1Int, ReferenceQueue<ViewDataBinding> param1ReferenceQueue) {
      this.mListener = new WeakListener(param1ViewDataBinding, param1Int, this, param1ReferenceQueue);
    }
    
    public void addListener(ObservableList param1ObservableList) {
      param1ObservableList.addOnListChangedCallback(this);
    }
    
    public WeakListener<ObservableList> getListener() {
      return this.mListener;
    }
    
    public void onChanged(ObservableList param1ObservableList) {
      ViewDataBinding viewDataBinding = this.mListener.getBinder();
      if (viewDataBinding == null)
        return; 
      ObservableList observableList = (ObservableList)this.mListener.getTarget();
      if (observableList != param1ObservableList)
        return; 
      viewDataBinding.handleFieldChange(this.mListener.mLocalFieldId, observableList, 0);
    }
    
    public void onItemRangeChanged(ObservableList param1ObservableList, int param1Int1, int param1Int2) {
      onChanged(param1ObservableList);
    }
    
    public void onItemRangeInserted(ObservableList param1ObservableList, int param1Int1, int param1Int2) {
      onChanged(param1ObservableList);
    }
    
    public void onItemRangeMoved(ObservableList param1ObservableList, int param1Int1, int param1Int2, int param1Int3) {
      onChanged(param1ObservableList);
    }
    
    public void onItemRangeRemoved(ObservableList param1ObservableList, int param1Int1, int param1Int2) {
      onChanged(param1ObservableList);
    }
    
    public void removeListener(ObservableList param1ObservableList) {
      param1ObservableList.removeOnListChangedCallback(this);
    }
    
    public void setLifecycleOwner(LifecycleOwner param1LifecycleOwner) {}
  }
  
  private static class WeakMapListener extends ObservableMap.OnMapChangedCallback implements ObservableReference<ObservableMap> {
    final WeakListener<ObservableMap> mListener;
    
    public WeakMapListener(ViewDataBinding param1ViewDataBinding, int param1Int, ReferenceQueue<ViewDataBinding> param1ReferenceQueue) {
      this.mListener = new WeakListener(param1ViewDataBinding, param1Int, this, param1ReferenceQueue);
    }
    
    public void addListener(ObservableMap param1ObservableMap) {
      param1ObservableMap.addOnMapChangedCallback(this);
    }
    
    public WeakListener<ObservableMap> getListener() {
      return this.mListener;
    }
    
    public void onMapChanged(ObservableMap param1ObservableMap, Object param1Object) {
      param1Object = this.mListener.getBinder();
      if (param1Object != null) {
        if (param1ObservableMap != this.mListener.getTarget())
          return; 
        param1Object.handleFieldChange(this.mListener.mLocalFieldId, param1ObservableMap, 0);
      } 
    }
    
    public void removeListener(ObservableMap param1ObservableMap) {
      param1ObservableMap.removeOnMapChangedCallback(this);
    }
    
    public void setLifecycleOwner(LifecycleOwner param1LifecycleOwner) {}
  }
  
  private static class WeakPropertyListener extends Observable.OnPropertyChangedCallback implements ObservableReference<Observable> {
    final WeakListener<Observable> mListener;
    
    public WeakPropertyListener(ViewDataBinding param1ViewDataBinding, int param1Int, ReferenceQueue<ViewDataBinding> param1ReferenceQueue) {
      this.mListener = new WeakListener(param1ViewDataBinding, param1Int, this, param1ReferenceQueue);
    }
    
    public void addListener(Observable param1Observable) {
      param1Observable.addOnPropertyChangedCallback(this);
    }
    
    public WeakListener<Observable> getListener() {
      return this.mListener;
    }
    
    public void onPropertyChanged(Observable param1Observable, int param1Int) {
      ViewDataBinding viewDataBinding = this.mListener.getBinder();
      if (viewDataBinding == null)
        return; 
      if ((Observable)this.mListener.getTarget() != param1Observable)
        return; 
      viewDataBinding.handleFieldChange(this.mListener.mLocalFieldId, param1Observable, param1Int);
    }
    
    public void removeListener(Observable param1Observable) {
      param1Observable.removeOnPropertyChangedCallback(this);
    }
    
    public void setLifecycleOwner(LifecycleOwner param1LifecycleOwner) {}
  }
}


/* Location:              C:\soft\dex2jar-2.0\MagicAI - AI Art & Anime Art-dex2jar.jar!\androidx\databinding\ViewDataBinding.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */