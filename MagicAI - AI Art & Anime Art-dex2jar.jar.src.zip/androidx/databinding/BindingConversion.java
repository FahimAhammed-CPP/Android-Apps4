package androidx.databinding;

import java.lang.annotation.ElementType;
import java.lang.annotation.Target;

@Target({ElementType.METHOD})
public @interface BindingConversion {}


/* Location:              C:\soft\dex2jar-2.0\MagicAI - AI Art & Anime Art-dex2jar.jar!\androidx\databinding\BindingConversion.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */