package androidx.databinding;

import android.os.Parcel;
import android.os.Parcelable;
import java.io.Serializable;

public class ObservableInt extends BaseObservableField implements Parcelable, Serializable {
  public static final Parcelable.Creator<ObservableInt> CREATOR = new Parcelable.Creator<ObservableInt>() {
      public ObservableInt createFromParcel(Parcel param1Parcel) {
        return new ObservableInt(param1Parcel.readInt());
      }
      
      public ObservableInt[] newArray(int param1Int) {
        return new ObservableInt[param1Int];
      }
    };
  
  static final long serialVersionUID = 1L;
  
  private int mValue;
  
  public ObservableInt() {}
  
  public ObservableInt(int paramInt) {
    this.mValue = paramInt;
  }
  
  public ObservableInt(Observable... paramVarArgs) {
    super(paramVarArgs);
  }
  
  public int describeContents() {
    return 0;
  }
  
  public int get() {
    return this.mValue;
  }
  
  public void set(int paramInt) {
    if (paramInt != this.mValue) {
      this.mValue = paramInt;
      notifyChange();
    } 
  }
  
  public void writeToParcel(Parcel paramParcel, int paramInt) {
    paramParcel.writeInt(this.mValue);
  }
}


/* Location:              C:\soft\dex2jar-2.0\MagicAI - AI Art & Anime Art-dex2jar.jar!\androidx\databinding\ObservableInt.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */