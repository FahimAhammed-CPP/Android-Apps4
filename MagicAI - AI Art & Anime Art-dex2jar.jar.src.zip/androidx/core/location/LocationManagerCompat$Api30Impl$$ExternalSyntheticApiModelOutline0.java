package androidx.core.location;

import android.location.GnssStatus;
import android.location.LocationManager;
import java.util.concurrent.Executor;



/* Location:              C:\soft\dex2jar-2.0\MagicAI - AI Art & Anime Art-dex2jar.jar!\androidx\core\location\LocationManagerCompat$Api30Impl$$ExternalSyntheticApiModelOutline0.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */