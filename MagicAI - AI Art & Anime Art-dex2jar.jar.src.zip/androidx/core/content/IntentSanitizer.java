package androidx.core.content;

import android.annotation.SuppressLint;
import android.content.ClipData;
import android.content.ComponentName;
import android.content.Intent;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Parcelable;
import androidx.annotation.DoNotInline;
import androidx.annotation.NonNull;
import androidx.annotation.RequiresApi;
import androidx.core.util.Consumer;
import androidx.core.util.Preconditions;
import androidx.core.util.Predicate;
import j$.util.Objects;
import java.io.Serializable;
import java.util.HashMap;
import java.util.Map;
import java.util.Set;

public class IntentSanitizer {
  private static final String TAG = "IntentSanitizer";
  
  private boolean mAllowAnyComponent;
  
  private boolean mAllowClipDataText;
  
  private boolean mAllowIdentifier;
  
  private boolean mAllowSelector;
  
  private boolean mAllowSourceBounds;
  
  private Predicate<String> mAllowedActions;
  
  private Predicate<String> mAllowedCategories;
  
  private Predicate<ClipData> mAllowedClipData;
  
  private Predicate<Uri> mAllowedClipDataUri;
  
  private Predicate<ComponentName> mAllowedComponents;
  
  private Predicate<Uri> mAllowedData;
  
  private Map<String, Predicate<Object>> mAllowedExtras;
  
  private int mAllowedFlags;
  
  private Predicate<String> mAllowedPackages;
  
  private Predicate<String> mAllowedTypes;
  
  private IntentSanitizer() {}
  
  private void putExtra(Intent paramIntent, String paramString, Object paramObject) {
    if (paramObject == null) {
      paramIntent.getExtras().putString(paramString, null);
      return;
    } 
    if (paramObject instanceof Parcelable) {
      paramIntent.putExtra(paramString, (Parcelable)paramObject);
      return;
    } 
    if (paramObject instanceof Parcelable[]) {
      paramIntent.putExtra(paramString, (Parcelable[])paramObject);
      return;
    } 
    if (paramObject instanceof Serializable) {
      paramIntent.putExtra(paramString, (Serializable)paramObject);
      return;
    } 
    StringBuilder stringBuilder = new StringBuilder();
    stringBuilder.append("Unsupported type ");
    stringBuilder.append(paramObject.getClass());
    throw new IllegalArgumentException(stringBuilder.toString());
  }
  
  @NonNull
  public Intent sanitize(@NonNull Intent paramIntent, @NonNull Consumer<String> paramConsumer) {
    Intent intent = new Intent();
    ComponentName componentName = paramIntent.getComponent();
    if ((this.mAllowAnyComponent && componentName == null) || this.mAllowedComponents.test(componentName)) {
      intent.setComponent(componentName);
    } else {
      StringBuilder stringBuilder = new StringBuilder();
      stringBuilder.append("Component is not allowed: ");
      stringBuilder.append(componentName);
      paramConsumer.accept(stringBuilder.toString());
      intent.setComponent(new ComponentName("android", "java.lang.Void"));
    } 
    String str2 = paramIntent.getPackage();
    if (str2 == null || this.mAllowedPackages.test(str2)) {
      intent.setPackage(str2);
    } else {
      StringBuilder stringBuilder = new StringBuilder();
      stringBuilder.append("Package is not allowed: ");
      stringBuilder.append(str2);
      paramConsumer.accept(stringBuilder.toString());
    } 
    int i = this.mAllowedFlags;
    int j = paramIntent.getFlags();
    int k = this.mAllowedFlags;
    if ((i | j) == k) {
      intent.setFlags(paramIntent.getFlags());
    } else {
      intent.setFlags(paramIntent.getFlags() & k);
      StringBuilder stringBuilder = new StringBuilder();
      stringBuilder.append("The intent contains flags that are not allowed: 0x");
      stringBuilder.append(Integer.toHexString(paramIntent.getFlags() & this.mAllowedFlags));
      paramConsumer.accept(stringBuilder.toString());
    } 
    str2 = paramIntent.getAction();
    if (str2 == null || this.mAllowedActions.test(str2)) {
      intent.setAction(str2);
    } else {
      StringBuilder stringBuilder = new StringBuilder();
      stringBuilder.append("Action is not allowed: ");
      stringBuilder.append(str2);
      paramConsumer.accept(stringBuilder.toString());
    } 
    Uri uri = paramIntent.getData();
    if (uri == null || this.mAllowedData.test(uri)) {
      intent.setData(uri);
    } else {
      StringBuilder stringBuilder = new StringBuilder();
      stringBuilder.append("Data is not allowed: ");
      stringBuilder.append(uri);
      paramConsumer.accept(stringBuilder.toString());
    } 
    String str1 = paramIntent.getType();
    if (str1 == null || this.mAllowedTypes.test(str1)) {
      intent.setDataAndType(intent.getData(), str1);
    } else {
      StringBuilder stringBuilder = new StringBuilder();
      stringBuilder.append("Type is not allowed: ");
      stringBuilder.append(str1);
      paramConsumer.accept(stringBuilder.toString());
    } 
    Set set = paramIntent.getCategories();
    if (set != null)
      for (String str : set) {
        if (this.mAllowedCategories.test(str)) {
          intent.addCategory(str);
          continue;
        } 
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("Category is not allowed: ");
        stringBuilder.append(str);
        paramConsumer.accept(stringBuilder.toString());
      }  
    Bundle bundle = paramIntent.getExtras();
    if (bundle != null)
      for (String str : bundle.keySet()) {
        if (str.equals("android.intent.extra.STREAM") && (this.mAllowedFlags & 0x1) == 0) {
          paramConsumer.accept("Allowing Extra Stream requires also allowing at least  FLAG_GRANT_READ_URI_PERMISSION Flag.");
          continue;
        } 
        if (str.equals("output") && (this.mAllowedFlags & 0x3) != 0) {
          paramConsumer.accept("Allowing Extra Output requires also allowing FLAG_GRANT_READ_URI_PERMISSION and FLAG_GRANT_WRITE_URI_PERMISSION Flags.");
          continue;
        } 
        Object object = bundle.get(str);
        Predicate predicate = this.mAllowedExtras.get(str);
        if (predicate != null && predicate.test(object)) {
          putExtra(intent, str, object);
          continue;
        } 
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("Extra is not allowed. Key: ");
        stringBuilder.append(str);
        stringBuilder.append(". Value: ");
        stringBuilder.append(object);
        paramConsumer.accept(stringBuilder.toString());
      }  
    i = Build.VERSION.SDK_INT;
    Api16Impl.sanitizeClipData(paramIntent, intent, this.mAllowedClipData, this.mAllowClipDataText, this.mAllowedClipDataUri, paramConsumer);
    if (i >= 29)
      if (this.mAllowIdentifier) {
        Api29Impl.setIdentifier(intent, Api29Impl.getIdentifier(paramIntent));
      } else if (Api29Impl.getIdentifier(paramIntent) != null) {
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("Identifier is not allowed: ");
        stringBuilder.append(Api29Impl.getIdentifier(paramIntent));
        paramConsumer.accept(stringBuilder.toString());
      }  
    if (this.mAllowSelector) {
      Api15Impl.setSelector(intent, Api15Impl.getSelector(paramIntent));
    } else if (Api15Impl.getSelector(paramIntent) != null) {
      StringBuilder stringBuilder = new StringBuilder();
      stringBuilder.append("Selector is not allowed: ");
      stringBuilder.append(Api15Impl.getSelector(paramIntent));
      paramConsumer.accept(stringBuilder.toString());
    } 
    if (this.mAllowSourceBounds) {
      intent.setSourceBounds(paramIntent.getSourceBounds());
      return intent;
    } 
    if (paramIntent.getSourceBounds() != null) {
      StringBuilder stringBuilder = new StringBuilder();
      stringBuilder.append("SourceBounds is not allowed: ");
      stringBuilder.append(paramIntent.getSourceBounds());
      paramConsumer.accept(stringBuilder.toString());
    } 
    return intent;
  }
  
  @NonNull
  public Intent sanitizeByFiltering(@NonNull Intent paramIntent) {
    return sanitize(paramIntent, (Consumer<String>)new IntentSanitizer$.ExternalSyntheticLambda0());
  }
  
  @NonNull
  public Intent sanitizeByThrowing(@NonNull Intent paramIntent) {
    return sanitize(paramIntent, (Consumer<String>)new IntentSanitizer$.ExternalSyntheticLambda1());
  }
  
  @RequiresApi(15)
  private static class Api15Impl {
    @DoNotInline
    static Intent getSelector(Intent param1Intent) {
      return param1Intent.getSelector();
    }
    
    @DoNotInline
    static void setSelector(Intent param1Intent1, Intent param1Intent2) {
      param1Intent1.setSelector(param1Intent2);
    }
  }
  
  @RequiresApi(16)
  private static class Api16Impl {
    private static void checkOtherMembers(int param1Int, ClipData.Item param1Item, Consumer<String> param1Consumer) {
      if (param1Item.getHtmlText() != null || param1Item.getIntent() != null) {
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("ClipData item at position ");
        stringBuilder.append(param1Int);
        stringBuilder.append(" contains htmlText, textLinks or intent: ");
        stringBuilder.append(param1Item);
        param1Consumer.accept(stringBuilder.toString());
      } 
    }
    
    @DoNotInline
    static void sanitizeClipData(@NonNull Intent param1Intent1, Intent param1Intent2, Predicate<ClipData> param1Predicate, boolean param1Boolean, Predicate<Uri> param1Predicate1, Consumer<String> param1Consumer) {
      // Byte code:
      //   0: aload_0
      //   1: invokevirtual getClipData : ()Landroid/content/ClipData;
      //   4: astore #9
      //   6: aload #9
      //   8: ifnonnull -> 12
      //   11: return
      //   12: aload_2
      //   13: ifnull -> 34
      //   16: aload_2
      //   17: aload #9
      //   19: invokeinterface test : (Ljava/lang/Object;)Z
      //   24: ifeq -> 34
      //   27: aload_1
      //   28: aload #9
      //   30: invokevirtual setClipData : (Landroid/content/ClipData;)V
      //   33: return
      //   34: iconst_0
      //   35: istore #6
      //   37: aconst_null
      //   38: astore_0
      //   39: iload #6
      //   41: aload #9
      //   43: invokevirtual getItemCount : ()I
      //   46: if_icmpge -> 401
      //   49: aload #9
      //   51: iload #6
      //   53: invokevirtual getItemAt : (I)Landroid/content/ClipData$Item;
      //   56: astore #7
      //   58: getstatic android/os/Build$VERSION.SDK_INT : I
      //   61: bipush #31
      //   63: if_icmplt -> 78
      //   66: iload #6
      //   68: aload #7
      //   70: aload #5
      //   72: invokestatic checkOtherMembers : (ILandroid/content/ClipData$Item;Landroidx/core/util/Consumer;)V
      //   75: goto -> 87
      //   78: iload #6
      //   80: aload #7
      //   82: aload #5
      //   84: invokestatic checkOtherMembers : (ILandroid/content/ClipData$Item;Landroidx/core/util/Consumer;)V
      //   87: iload_3
      //   88: ifeq -> 100
      //   91: aload #7
      //   93: invokevirtual getText : ()Ljava/lang/CharSequence;
      //   96: astore_2
      //   97: goto -> 160
      //   100: aload #7
      //   102: invokevirtual getText : ()Ljava/lang/CharSequence;
      //   105: ifnull -> 158
      //   108: new java/lang/StringBuilder
      //   111: dup
      //   112: invokespecial <init> : ()V
      //   115: astore_2
      //   116: aload_2
      //   117: ldc 'Item text cannot contain value. Item position: '
      //   119: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
      //   122: pop
      //   123: aload_2
      //   124: iload #6
      //   126: invokevirtual append : (I)Ljava/lang/StringBuilder;
      //   129: pop
      //   130: aload_2
      //   131: ldc '. Text: '
      //   133: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
      //   136: pop
      //   137: aload_2
      //   138: aload #7
      //   140: invokevirtual getText : ()Ljava/lang/CharSequence;
      //   143: invokevirtual append : (Ljava/lang/Object;)Ljava/lang/StringBuilder;
      //   146: pop
      //   147: aload #5
      //   149: aload_2
      //   150: invokevirtual toString : ()Ljava/lang/String;
      //   153: invokeinterface accept : (Ljava/lang/Object;)V
      //   158: aconst_null
      //   159: astore_2
      //   160: aload #4
      //   162: ifnonnull -> 232
      //   165: aload #7
      //   167: invokevirtual getUri : ()Landroid/net/Uri;
      //   170: ifnull -> 314
      //   173: new java/lang/StringBuilder
      //   176: dup
      //   177: invokespecial <init> : ()V
      //   180: astore #8
      //   182: aload #8
      //   184: ldc 'Item URI is not allowed. Item position: '
      //   186: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
      //   189: pop
      //   190: aload #8
      //   192: iload #6
      //   194: invokevirtual append : (I)Ljava/lang/StringBuilder;
      //   197: pop
      //   198: aload #8
      //   200: ldc '. URI: '
      //   202: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
      //   205: pop
      //   206: aload #8
      //   208: aload #7
      //   210: invokevirtual getUri : ()Landroid/net/Uri;
      //   213: invokevirtual append : (Ljava/lang/Object;)Ljava/lang/StringBuilder;
      //   216: pop
      //   217: aload #5
      //   219: aload #8
      //   221: invokevirtual toString : ()Ljava/lang/String;
      //   224: invokeinterface accept : (Ljava/lang/Object;)V
      //   229: goto -> 314
      //   232: aload #7
      //   234: invokevirtual getUri : ()Landroid/net/Uri;
      //   237: ifnull -> 320
      //   240: aload #4
      //   242: aload #7
      //   244: invokevirtual getUri : ()Landroid/net/Uri;
      //   247: invokeinterface test : (Ljava/lang/Object;)Z
      //   252: ifeq -> 258
      //   255: goto -> 320
      //   258: new java/lang/StringBuilder
      //   261: dup
      //   262: invokespecial <init> : ()V
      //   265: astore #8
      //   267: aload #8
      //   269: ldc 'Item URI is not allowed. Item position: '
      //   271: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
      //   274: pop
      //   275: aload #8
      //   277: iload #6
      //   279: invokevirtual append : (I)Ljava/lang/StringBuilder;
      //   282: pop
      //   283: aload #8
      //   285: ldc '. URI: '
      //   287: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
      //   290: pop
      //   291: aload #8
      //   293: aload #7
      //   295: invokevirtual getUri : ()Landroid/net/Uri;
      //   298: invokevirtual append : (Ljava/lang/Object;)Ljava/lang/StringBuilder;
      //   301: pop
      //   302: aload #5
      //   304: aload #8
      //   306: invokevirtual toString : ()Ljava/lang/String;
      //   309: invokeinterface accept : (Ljava/lang/Object;)V
      //   314: aconst_null
      //   315: astore #7
      //   317: goto -> 327
      //   320: aload #7
      //   322: invokevirtual getUri : ()Landroid/net/Uri;
      //   325: astore #7
      //   327: aload_2
      //   328: ifnonnull -> 339
      //   331: aload_0
      //   332: astore #8
      //   334: aload #7
      //   336: ifnull -> 389
      //   339: aload_0
      //   340: ifnonnull -> 371
      //   343: new android/content/ClipData
      //   346: dup
      //   347: aload #9
      //   349: invokevirtual getDescription : ()Landroid/content/ClipDescription;
      //   352: new android/content/ClipData$Item
      //   355: dup
      //   356: aload_2
      //   357: aconst_null
      //   358: aload #7
      //   360: invokespecial <init> : (Ljava/lang/CharSequence;Landroid/content/Intent;Landroid/net/Uri;)V
      //   363: invokespecial <init> : (Landroid/content/ClipDescription;Landroid/content/ClipData$Item;)V
      //   366: astore #8
      //   368: goto -> 389
      //   371: aload_0
      //   372: new android/content/ClipData$Item
      //   375: dup
      //   376: aload_2
      //   377: aconst_null
      //   378: aload #7
      //   380: invokespecial <init> : (Ljava/lang/CharSequence;Landroid/content/Intent;Landroid/net/Uri;)V
      //   383: invokevirtual addItem : (Landroid/content/ClipData$Item;)V
      //   386: aload_0
      //   387: astore #8
      //   389: iload #6
      //   391: iconst_1
      //   392: iadd
      //   393: istore #6
      //   395: aload #8
      //   397: astore_0
      //   398: goto -> 39
      //   401: aload_0
      //   402: ifnull -> 410
      //   405: aload_1
      //   406: aload_0
      //   407: invokevirtual setClipData : (Landroid/content/ClipData;)V
      //   410: return
    }
    
    @RequiresApi(31)
    private static class Api31Impl {
      @DoNotInline
      static void checkOtherMembers(int param2Int, ClipData.Item param2Item, Consumer<String> param2Consumer) {
        if (param2Item.getHtmlText() != null || param2Item.getIntent() != null || IntentSanitizer$Api16Impl$Api31Impl$.ExternalSyntheticApiModelOutline0.m(param2Item) != null) {
          StringBuilder stringBuilder = new StringBuilder();
          stringBuilder.append("ClipData item at position ");
          stringBuilder.append(param2Int);
          stringBuilder.append(" contains htmlText, textLinks or intent: ");
          stringBuilder.append(param2Item);
          param2Consumer.accept(stringBuilder.toString());
        } 
      }
    }
  }
  
  @RequiresApi(31)
  private static class Api31Impl {
    @DoNotInline
    static void checkOtherMembers(int param1Int, ClipData.Item param1Item, Consumer<String> param1Consumer) {
      if (param1Item.getHtmlText() != null || param1Item.getIntent() != null || IntentSanitizer$Api16Impl$Api31Impl$.ExternalSyntheticApiModelOutline0.m(param1Item) != null) {
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("ClipData item at position ");
        stringBuilder.append(param1Int);
        stringBuilder.append(" contains htmlText, textLinks or intent: ");
        stringBuilder.append(param1Item);
        param1Consumer.accept(stringBuilder.toString());
      } 
    }
  }
  
  @RequiresApi(29)
  private static class Api29Impl {
    @DoNotInline
    static String getIdentifier(Intent param1Intent) {
      return IntentSanitizer$Api29Impl$.ExternalSyntheticApiModelOutline0.m(param1Intent);
    }
    
    @DoNotInline
    static Intent setIdentifier(Intent param1Intent, String param1String) {
      return IntentSanitizer$Api29Impl$.ExternalSyntheticApiModelOutline1.m(param1Intent, param1String);
    }
  }
  
  public static final class Builder {
    private static final int HISTORY_STACK_FLAGS = 2112614400;
    
    private static final int RECEIVER_FLAGS = 2015363072;
    
    private boolean mAllowAnyComponent;
    
    private boolean mAllowClipDataText = false;
    
    private boolean mAllowIdentifier;
    
    private boolean mAllowSelector;
    
    private boolean mAllowSomeComponents;
    
    private boolean mAllowSourceBounds;
    
    private Predicate<String> mAllowedActions = (Predicate<String>)new IntentSanitizer$Builder$.ExternalSyntheticLambda2();
    
    private Predicate<String> mAllowedCategories = (Predicate<String>)new IntentSanitizer$Builder$.ExternalSyntheticLambda5();
    
    private Predicate<ClipData> mAllowedClipData = (Predicate<ClipData>)new IntentSanitizer$Builder$.ExternalSyntheticLambda9();
    
    private Predicate<Uri> mAllowedClipDataUri = (Predicate<Uri>)new IntentSanitizer$Builder$.ExternalSyntheticLambda8();
    
    private Predicate<ComponentName> mAllowedComponents = (Predicate<ComponentName>)new IntentSanitizer$Builder$.ExternalSyntheticLambda7();
    
    private Predicate<Uri> mAllowedData = (Predicate<Uri>)new IntentSanitizer$Builder$.ExternalSyntheticLambda3();
    
    private Map<String, Predicate<Object>> mAllowedExtras = new HashMap<String, Predicate<Object>>();
    
    private int mAllowedFlags;
    
    private Predicate<String> mAllowedPackages = (Predicate<String>)new IntentSanitizer$Builder$.ExternalSyntheticLambda6();
    
    private Predicate<String> mAllowedTypes = (Predicate<String>)new IntentSanitizer$Builder$.ExternalSyntheticLambda4();
    
    @SuppressLint({"BuilderSetStyle"})
    @NonNull
    public Builder allowAction(@NonNull Predicate<String> param1Predicate) {
      Preconditions.checkNotNull(param1Predicate);
      this.mAllowedActions = this.mAllowedActions.or(param1Predicate);
      return this;
    }
    
    @SuppressLint({"BuilderSetStyle"})
    @NonNull
    public Builder allowAction(@NonNull String param1String) {
      Preconditions.checkNotNull(param1String);
      Objects.requireNonNull(param1String);
      allowAction((Predicate<String>)new IntentSanitizer$Builder$.ExternalSyntheticLambda11(param1String));
      return this;
    }
    
    @SuppressLint({"BuilderSetStyle"})
    @NonNull
    public Builder allowAnyComponent() {
      this.mAllowAnyComponent = true;
      this.mAllowedComponents = (Predicate<ComponentName>)new IntentSanitizer$Builder$.ExternalSyntheticLambda13();
      return this;
    }
    
    @SuppressLint({"BuilderSetStyle"})
    @NonNull
    public Builder allowCategory(@NonNull Predicate<String> param1Predicate) {
      Preconditions.checkNotNull(param1Predicate);
      this.mAllowedCategories = this.mAllowedCategories.or(param1Predicate);
      return this;
    }
    
    @SuppressLint({"BuilderSetStyle"})
    @NonNull
    public Builder allowCategory(@NonNull String param1String) {
      Preconditions.checkNotNull(param1String);
      Objects.requireNonNull(param1String);
      return allowCategory((Predicate<String>)new IntentSanitizer$Builder$.ExternalSyntheticLambda11(param1String));
    }
    
    @SuppressLint({"BuilderSetStyle"})
    @NonNull
    public Builder allowClipData(@NonNull Predicate<ClipData> param1Predicate) {
      Preconditions.checkNotNull(param1Predicate);
      this.mAllowedClipData = this.mAllowedClipData.or(param1Predicate);
      return this;
    }
    
    @SuppressLint({"BuilderSetStyle"})
    @NonNull
    public Builder allowClipDataText() {
      this.mAllowClipDataText = true;
      return this;
    }
    
    @SuppressLint({"BuilderSetStyle"})
    @NonNull
    public Builder allowClipDataUri(@NonNull Predicate<Uri> param1Predicate) {
      Preconditions.checkNotNull(param1Predicate);
      this.mAllowedClipDataUri = this.mAllowedClipDataUri.or(param1Predicate);
      return this;
    }
    
    @SuppressLint({"BuilderSetStyle"})
    @NonNull
    public Builder allowClipDataUriWithAuthority(@NonNull String param1String) {
      Preconditions.checkNotNull(param1String);
      return allowClipDataUri((Predicate<Uri>)new IntentSanitizer$Builder$.ExternalSyntheticLambda10(param1String));
    }
    
    @SuppressLint({"BuilderSetStyle"})
    @NonNull
    public Builder allowComponent(@NonNull ComponentName param1ComponentName) {
      Preconditions.checkNotNull(param1ComponentName);
      Objects.requireNonNull(param1ComponentName);
      return allowComponent((Predicate<ComponentName>)new IntentSanitizer$Builder$.ExternalSyntheticLambda18(param1ComponentName));
    }
    
    @SuppressLint({"BuilderSetStyle"})
    @NonNull
    public Builder allowComponent(@NonNull Predicate<ComponentName> param1Predicate) {
      Preconditions.checkNotNull(param1Predicate);
      this.mAllowSomeComponents = true;
      this.mAllowedComponents = this.mAllowedComponents.or(param1Predicate);
      return this;
    }
    
    @SuppressLint({"BuilderSetStyle"})
    @NonNull
    public Builder allowComponentWithPackage(@NonNull String param1String) {
      Preconditions.checkNotNull(param1String);
      return allowComponent((Predicate<ComponentName>)new IntentSanitizer$Builder$.ExternalSyntheticLambda15(param1String));
    }
    
    @SuppressLint({"BuilderSetStyle"})
    @NonNull
    public Builder allowData(@NonNull Predicate<Uri> param1Predicate) {
      Preconditions.checkNotNull(param1Predicate);
      this.mAllowedData = this.mAllowedData.or(param1Predicate);
      return this;
    }
    
    @SuppressLint({"BuilderSetStyle"})
    @NonNull
    public Builder allowDataWithAuthority(@NonNull String param1String) {
      Preconditions.checkNotNull(param1String);
      allowData((Predicate<Uri>)new IntentSanitizer$Builder$.ExternalSyntheticLambda16(param1String));
      return this;
    }
    
    @SuppressLint({"BuilderSetStyle"})
    @NonNull
    public Builder allowExtra(@NonNull String param1String, @NonNull Predicate<Object> param1Predicate) {
      IntentSanitizer$Builder$.ExternalSyntheticLambda0 externalSyntheticLambda0;
      Preconditions.checkNotNull(param1String);
      Preconditions.checkNotNull(param1Predicate);
      Predicate predicate2 = this.mAllowedExtras.get(param1String);
      Predicate predicate1 = predicate2;
      if (predicate2 == null)
        externalSyntheticLambda0 = new IntentSanitizer$Builder$.ExternalSyntheticLambda0(); 
      param1Predicate = externalSyntheticLambda0.or(param1Predicate);
      this.mAllowedExtras.put(param1String, param1Predicate);
      return this;
    }
    
    @SuppressLint({"BuilderSetStyle"})
    @NonNull
    public Builder allowExtra(@NonNull String param1String, @NonNull Class<?> param1Class) {
      return allowExtra(param1String, param1Class, (Predicate<?>)new IntentSanitizer$Builder$.ExternalSyntheticLambda1());
    }
    
    @SuppressLint({"BuilderSetStyle"})
    @NonNull
    public <T> Builder allowExtra(@NonNull String param1String, @NonNull Class<T> param1Class, @NonNull Predicate<T> param1Predicate) {
      Preconditions.checkNotNull(param1String);
      Preconditions.checkNotNull(param1Class);
      Preconditions.checkNotNull(param1Predicate);
      return allowExtra(param1String, (Predicate<Object>)new IntentSanitizer$Builder$.ExternalSyntheticLambda14(param1Class, param1Predicate));
    }
    
    @SuppressLint({"BuilderSetStyle"})
    @NonNull
    public Builder allowExtraOutput(@NonNull Predicate<Uri> param1Predicate) {
      allowExtra("output", Uri.class, param1Predicate);
      return this;
    }
    
    @SuppressLint({"BuilderSetStyle"})
    @NonNull
    public Builder allowExtraOutput(@NonNull String param1String) {
      allowExtra("output", Uri.class, (Predicate<Uri>)new IntentSanitizer$Builder$.ExternalSyntheticLambda17(param1String));
      return this;
    }
    
    @SuppressLint({"BuilderSetStyle"})
    @NonNull
    public Builder allowExtraStream(@NonNull Predicate<Uri> param1Predicate) {
      allowExtra("android.intent.extra.STREAM", Uri.class, param1Predicate);
      return this;
    }
    
    @SuppressLint({"BuilderSetStyle"})
    @NonNull
    public Builder allowExtraStreamUriWithAuthority(@NonNull String param1String) {
      Preconditions.checkNotNull(param1String);
      allowExtra("android.intent.extra.STREAM", Uri.class, (Predicate<Uri>)new IntentSanitizer$Builder$.ExternalSyntheticLambda12(param1String));
      return this;
    }
    
    @SuppressLint({"BuilderSetStyle"})
    @NonNull
    public Builder allowFlags(int param1Int) {
      this.mAllowedFlags = param1Int | this.mAllowedFlags;
      return this;
    }
    
    @SuppressLint({"BuilderSetStyle"})
    @NonNull
    public Builder allowHistoryStackFlags() {
      this.mAllowedFlags |= 0x7DEBF000;
      return this;
    }
    
    @SuppressLint({"BuilderSetStyle"})
    @NonNull
    public Builder allowIdentifier() {
      this.mAllowIdentifier = true;
      return this;
    }
    
    @SuppressLint({"BuilderSetStyle"})
    @NonNull
    public Builder allowPackage(@NonNull Predicate<String> param1Predicate) {
      Preconditions.checkNotNull(param1Predicate);
      this.mAllowedPackages = this.mAllowedPackages.or(param1Predicate);
      return this;
    }
    
    @SuppressLint({"BuilderSetStyle"})
    @NonNull
    public Builder allowPackage(@NonNull String param1String) {
      Preconditions.checkNotNull(param1String);
      Objects.requireNonNull(param1String);
      return allowPackage((Predicate<String>)new IntentSanitizer$Builder$.ExternalSyntheticLambda11(param1String));
    }
    
    @SuppressLint({"BuilderSetStyle"})
    @NonNull
    public Builder allowReceiverFlags() {
      this.mAllowedFlags |= 0x78200000;
      return this;
    }
    
    @SuppressLint({"BuilderSetStyle"})
    @NonNull
    public Builder allowSelector() {
      this.mAllowSelector = true;
      return this;
    }
    
    @SuppressLint({"BuilderSetStyle"})
    @NonNull
    public Builder allowSourceBounds() {
      this.mAllowSourceBounds = true;
      return this;
    }
    
    @SuppressLint({"BuilderSetStyle"})
    @NonNull
    public Builder allowType(@NonNull Predicate<String> param1Predicate) {
      Preconditions.checkNotNull(param1Predicate);
      this.mAllowedTypes = this.mAllowedTypes.or(param1Predicate);
      return this;
    }
    
    @SuppressLint({"BuilderSetStyle"})
    @NonNull
    public Builder allowType(@NonNull String param1String) {
      Preconditions.checkNotNull(param1String);
      Objects.requireNonNull(param1String);
      return allowType((Predicate<String>)new IntentSanitizer$Builder$.ExternalSyntheticLambda11(param1String));
    }
    
    @SuppressLint({"SyntheticAccessor"})
    @NonNull
    public IntentSanitizer build() {
      boolean bool = this.mAllowAnyComponent;
      if ((!bool || !this.mAllowSomeComponents) && (bool || this.mAllowSomeComponents)) {
        IntentSanitizer intentSanitizer = new IntentSanitizer();
        IntentSanitizer.access$102(intentSanitizer, this.mAllowedFlags);
        IntentSanitizer.access$202(intentSanitizer, this.mAllowedActions);
        IntentSanitizer.access$302(intentSanitizer, this.mAllowedData);
        IntentSanitizer.access$402(intentSanitizer, this.mAllowedTypes);
        IntentSanitizer.access$502(intentSanitizer, this.mAllowedCategories);
        IntentSanitizer.access$602(intentSanitizer, this.mAllowedPackages);
        IntentSanitizer.access$702(intentSanitizer, this.mAllowAnyComponent);
        IntentSanitizer.access$802(intentSanitizer, this.mAllowedComponents);
        IntentSanitizer.access$902(intentSanitizer, this.mAllowedExtras);
        IntentSanitizer.access$1002(intentSanitizer, this.mAllowClipDataText);
        IntentSanitizer.access$1102(intentSanitizer, this.mAllowedClipDataUri);
        IntentSanitizer.access$1202(intentSanitizer, this.mAllowedClipData);
        IntentSanitizer.access$1302(intentSanitizer, this.mAllowIdentifier);
        IntentSanitizer.access$1402(intentSanitizer, this.mAllowSelector);
        IntentSanitizer.access$1502(intentSanitizer, this.mAllowSourceBounds);
        return intentSanitizer;
      } 
      throw new SecurityException("You must call either allowAnyComponent or one or more of the allowComponent methods; but not both.");
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\MagicAI - AI Art & Anime Art-dex2jar.jar!\androidx\core\content\IntentSanitizer.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */