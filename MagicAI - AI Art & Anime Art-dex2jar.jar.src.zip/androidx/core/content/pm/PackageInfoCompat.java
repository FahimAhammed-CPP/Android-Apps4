package androidx.core.content.pm;

import android.content.pm.PackageInfo;
import android.content.pm.PackageManager;
import android.content.pm.Signature;
import android.content.pm.SigningInfo;
import android.os.Build;
import androidx.annotation.DoNotInline;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.annotation.RequiresApi;
import androidx.annotation.Size;
import androidx.browser.trusted.PackageIdentityUtils$Api28Implementation$;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.util.Arrays;
import java.util.Collections;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Set;

public final class PackageInfoCompat {
  private static boolean byteArrayContains(@NonNull byte[][] paramArrayOfbyte, @NonNull byte[] paramArrayOfbyte1) {
    int j = paramArrayOfbyte.length;
    for (int i = 0; i < j; i++) {
      if (Arrays.equals(paramArrayOfbyte1, paramArrayOfbyte[i]))
        return true; 
    } 
    return false;
  }
  
  private static byte[] computeSHA256Digest(byte[] paramArrayOfbyte) {
    try {
      return MessageDigest.getInstance("SHA256").digest(paramArrayOfbyte);
    } catch (NoSuchAlgorithmException noSuchAlgorithmException) {
      throw new RuntimeException("Device doesn't support SHA256 cert checking", noSuchAlgorithmException);
    } 
  }
  
  public static long getLongVersionCode(@NonNull PackageInfo paramPackageInfo) {
    return (Build.VERSION.SDK_INT >= 28) ? Api28Impl.getLongVersionCode(paramPackageInfo) : paramPackageInfo.versionCode;
  }
  
  @NonNull
  public static List<Signature> getSignatures(@NonNull PackageManager paramPackageManager, @NonNull String paramString) throws PackageManager.NameNotFoundException {
    Signature[] arrayOfSignature;
    if (Build.VERSION.SDK_INT >= 28) {
      SigningInfo signingInfo = PackageIdentityUtils$Api28Implementation$.ExternalSyntheticApiModelOutline0.m(paramPackageManager.getPackageInfo(paramString, 134217728));
      if (Api28Impl.hasMultipleSigners(signingInfo)) {
        arrayOfSignature = Api28Impl.getApkContentsSigners(signingInfo);
      } else {
        arrayOfSignature = Api28Impl.getSigningCertificateHistory((SigningInfo)arrayOfSignature);
      } 
    } else {
      arrayOfSignature = (arrayOfSignature.getPackageInfo(paramString, 64)).signatures;
    } 
    return (arrayOfSignature == null) ? Collections.emptyList() : Arrays.asList(arrayOfSignature);
  }
  
  public static boolean hasSignatures(@NonNull PackageManager paramPackageManager, @NonNull String paramString, @NonNull @Size(min = 1L) Map<byte[], Integer> paramMap, boolean paramBoolean) throws PackageManager.NameNotFoundException {
    StringBuilder stringBuilder;
    if (paramMap.isEmpty())
      return false; 
    Set<byte> set = paramMap.keySet();
    for (byte[] arrayOfByte1 : set) {
      if (arrayOfByte1 != null) {
        Integer integer = paramMap.get(arrayOfByte1);
        if (integer != null) {
          int i = integer.intValue();
          if (i == 0 || i == 1)
            continue; 
          StringBuilder stringBuilder2 = new StringBuilder();
          stringBuilder2.append("Unsupported certificate type ");
          stringBuilder2.append(integer);
          stringBuilder2.append(" when verifying ");
          stringBuilder2.append(paramString);
          throw new IllegalArgumentException(stringBuilder2.toString());
        } 
        StringBuilder stringBuilder1 = new StringBuilder();
        stringBuilder1.append("Type must be specified for cert when verifying ");
        stringBuilder1.append(paramString);
        throw new IllegalArgumentException(stringBuilder1.toString());
      } 
      stringBuilder = new StringBuilder();
      stringBuilder.append("Cert byte array cannot be null when verifying ");
      stringBuilder.append(paramString);
      throw new IllegalArgumentException(stringBuilder.toString());
    } 
    List<Signature> list = getSignatures((PackageManager)stringBuilder, paramString);
    if (!paramBoolean && Build.VERSION.SDK_INT >= 28) {
      for (byte[] arrayOfByte : set) {
        if (!Api28Impl.hasSigningCertificate((PackageManager)stringBuilder, paramString, arrayOfByte, ((Integer)paramMap.get(arrayOfByte)).intValue()))
          return false; 
      } 
      return true;
    } 
    if (arrayOfByte.size() != 0 && paramMap.size() <= arrayOfByte.size()) {
      if (paramBoolean && paramMap.size() != arrayOfByte.size())
        return false; 
      if (paramMap.containsValue(Integer.valueOf(1))) {
        byte[][] arrayOfByte1 = new byte[arrayOfByte.size()][];
        int i = 0;
        while (true) {
          byte[][] arrayOfByte2 = arrayOfByte1;
          if (i < arrayOfByte.size()) {
            arrayOfByte1[i] = computeSHA256Digest(((Signature)arrayOfByte.get(i)).toByteArray());
            i++;
            continue;
          } 
          break;
        } 
      } else {
        stringBuilder = null;
      } 
      Iterator<byte> iterator = set.iterator();
      if (iterator.hasNext()) {
        byte[] arrayOfByte1 = (byte[])iterator.next();
        Integer integer = paramMap.get(arrayOfByte1);
        int i = integer.intValue();
        if (i != 0) {
          if (i == 1) {
            if (!byteArrayContains((byte[][])stringBuilder, arrayOfByte1))
              return false; 
          } else {
            stringBuilder = new StringBuilder();
            stringBuilder.append("Unsupported certificate type ");
            stringBuilder.append(integer);
            throw new IllegalArgumentException(stringBuilder.toString());
          } 
        } else if (!arrayOfByte.contains(new Signature(arrayOfByte1))) {
          return false;
        } 
        return true;
      } 
    } 
    return false;
  }
  
  @RequiresApi(28)
  private static class Api28Impl {
    @DoNotInline
    @Nullable
    static Signature[] getApkContentsSigners(@NonNull SigningInfo param1SigningInfo) {
      return PackageIdentityUtils$Api28Implementation$.ExternalSyntheticApiModelOutline2.m(param1SigningInfo);
    }
    
    @DoNotInline
    static long getLongVersionCode(PackageInfo param1PackageInfo) {
      return PackageInfoCompat$Api28Impl$.ExternalSyntheticApiModelOutline0.m(param1PackageInfo);
    }
    
    @DoNotInline
    @Nullable
    static Signature[] getSigningCertificateHistory(@NonNull SigningInfo param1SigningInfo) {
      return PackageIdentityUtils$Api28Implementation$.ExternalSyntheticApiModelOutline3.m(param1SigningInfo);
    }
    
    @DoNotInline
    static boolean hasMultipleSigners(@NonNull SigningInfo param1SigningInfo) {
      return PackageIdentityUtils$Api28Implementation$.ExternalSyntheticApiModelOutline1.m(param1SigningInfo);
    }
    
    @DoNotInline
    static boolean hasSigningCertificate(@NonNull PackageManager param1PackageManager, @NonNull String param1String, @NonNull byte[] param1ArrayOfbyte, int param1Int) {
      return PackageIdentityUtils$Api28Implementation$.ExternalSyntheticApiModelOutline4.m(param1PackageManager, param1String, param1ArrayOfbyte, param1Int);
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\MagicAI - AI Art & Anime Art-dex2jar.jar!\androidx\core\content\pm\PackageInfoCompat.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */