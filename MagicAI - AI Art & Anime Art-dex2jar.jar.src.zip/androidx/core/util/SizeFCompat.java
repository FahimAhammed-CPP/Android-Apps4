package androidx.core.util;

import android.util.SizeF;
import androidx.annotation.DoNotInline;
import androidx.annotation.NonNull;
import androidx.annotation.RequiresApi;

public final class SizeFCompat {
  private final float mHeight;
  
  private final float mWidth;
  
  public SizeFCompat(float paramFloat1, float paramFloat2) {
    this.mWidth = Preconditions.checkArgumentFinite(paramFloat1, "width");
    this.mHeight = Preconditions.checkArgumentFinite(paramFloat2, "height");
  }
  
  @NonNull
  @RequiresApi(21)
  public static SizeFCompat toSizeFCompat(@NonNull SizeF paramSizeF) {
    return Api21Impl.toSizeFCompat(paramSizeF);
  }
  
  public boolean equals(Object paramObject) {
    if (this == paramObject)
      return true; 
    if (!(paramObject instanceof SizeFCompat))
      return false; 
    paramObject = paramObject;
    return (((SizeFCompat)paramObject).mWidth == this.mWidth && ((SizeFCompat)paramObject).mHeight == this.mHeight);
  }
  
  public float getHeight() {
    return this.mHeight;
  }
  
  public float getWidth() {
    return this.mWidth;
  }
  
  public int hashCode() {
    return Float.floatToIntBits(this.mWidth) ^ Float.floatToIntBits(this.mHeight);
  }
  
  @NonNull
  @RequiresApi(21)
  public SizeF toSizeF() {
    return Api21Impl.toSizeF(this);
  }
  
  @NonNull
  public String toString() {
    StringBuilder stringBuilder = new StringBuilder();
    stringBuilder.append(this.mWidth);
    stringBuilder.append("x");
    stringBuilder.append(this.mHeight);
    return stringBuilder.toString();
  }
  
  @RequiresApi(21)
  private static final class Api21Impl {
    @DoNotInline
    @NonNull
    static SizeF toSizeF(@NonNull SizeFCompat param1SizeFCompat) {
      Preconditions.checkNotNull(param1SizeFCompat);
      return new SizeF(param1SizeFCompat.getWidth(), param1SizeFCompat.getHeight());
    }
    
    @DoNotInline
    @NonNull
    static SizeFCompat toSizeFCompat(@NonNull SizeF param1SizeF) {
      Preconditions.checkNotNull(param1SizeF);
      return new SizeFCompat(param1SizeF.getWidth(), param1SizeF.getHeight());
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\MagicAI - AI Art & Anime Art-dex2jar.jar!\androidx\cor\\util\SizeFCompat.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */