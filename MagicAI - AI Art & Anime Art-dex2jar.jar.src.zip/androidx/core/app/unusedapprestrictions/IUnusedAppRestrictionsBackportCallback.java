package androidx.core.app.unusedapprestrictions;

import android.os.Binder;
import android.os.IBinder;
import android.os.IInterface;
import android.os.Parcel;
import android.os.RemoteException;

public interface IUnusedAppRestrictionsBackportCallback extends IInterface {
  public static final String DESCRIPTOR = "androidx$core$app$unusedapprestrictions$IUnusedAppRestrictionsBackportCallback".replace('$', '.');
  
  void onIsPermissionRevocationEnabledForAppResult(boolean paramBoolean1, boolean paramBoolean2) throws RemoteException;
  
  public static class Default implements IUnusedAppRestrictionsBackportCallback {
    public IBinder asBinder() {
      return null;
    }
    
    public void onIsPermissionRevocationEnabledForAppResult(boolean param1Boolean1, boolean param1Boolean2) throws RemoteException {}
  }
  
  public static abstract class Stub extends Binder implements IUnusedAppRestrictionsBackportCallback {
    static final int TRANSACTION_onIsPermissionRevocationEnabledForAppResult = 1;
    
    public Stub() {
      attachInterface(this, IUnusedAppRestrictionsBackportCallback.DESCRIPTOR);
    }
    
    public static IUnusedAppRestrictionsBackportCallback asInterface(IBinder param1IBinder) {
      if (param1IBinder == null)
        return null; 
      IInterface iInterface = param1IBinder.queryLocalInterface(IUnusedAppRestrictionsBackportCallback.DESCRIPTOR);
      return (iInterface != null && iInterface instanceof IUnusedAppRestrictionsBackportCallback) ? (IUnusedAppRestrictionsBackportCallback)iInterface : new Proxy(param1IBinder);
    }
    
    public IBinder asBinder() {
      return (IBinder)this;
    }
    
    public boolean onTransact(int param1Int1, Parcel param1Parcel1, Parcel param1Parcel2, int param1Int2) throws RemoteException {
      String str = IUnusedAppRestrictionsBackportCallback.DESCRIPTOR;
      if (param1Int1 >= 1 && param1Int1 <= 16777215)
        param1Parcel1.enforceInterface(str); 
      if (param1Int1 != 1598968902) {
        boolean bool1;
        if (param1Int1 != 1)
          return super.onTransact(param1Int1, param1Parcel1, param1Parcel2, param1Int2); 
        param1Int1 = param1Parcel1.readInt();
        boolean bool2 = false;
        if (param1Int1 != 0) {
          bool1 = true;
        } else {
          bool1 = false;
        } 
        if (param1Parcel1.readInt() != 0)
          bool2 = true; 
        onIsPermissionRevocationEnabledForAppResult(bool1, bool2);
        return true;
      } 
      param1Parcel2.writeString(str);
      return true;
    }
    
    private static class Proxy implements IUnusedAppRestrictionsBackportCallback {
      private IBinder mRemote;
      
      Proxy(IBinder param2IBinder) {
        this.mRemote = param2IBinder;
      }
      
      public IBinder asBinder() {
        return this.mRemote;
      }
      
      public String getInterfaceDescriptor() {
        return IUnusedAppRestrictionsBackportCallback.DESCRIPTOR;
      }
      
      public void onIsPermissionRevocationEnabledForAppResult(boolean param2Boolean1, boolean param2Boolean2) throws RemoteException {
        Parcel parcel = Parcel.obtain();
        try {
          parcel.writeInterfaceToken(IUnusedAppRestrictionsBackportCallback.DESCRIPTOR);
          boolean bool2 = false;
          if (param2Boolean1) {
            bool1 = true;
          } else {
            bool1 = false;
          } 
          parcel.writeInt(bool1);
          boolean bool1 = bool2;
          if (param2Boolean2)
            bool1 = true; 
          parcel.writeInt(bool1);
          this.mRemote.transact(1, parcel, null, 1);
          return;
        } finally {
          parcel.recycle();
        } 
      }
    }
  }
  
  private static class Proxy implements IUnusedAppRestrictionsBackportCallback {
    private IBinder mRemote;
    
    Proxy(IBinder param1IBinder) {
      this.mRemote = param1IBinder;
    }
    
    public IBinder asBinder() {
      return this.mRemote;
    }
    
    public String getInterfaceDescriptor() {
      return IUnusedAppRestrictionsBackportCallback.DESCRIPTOR;
    }
    
    public void onIsPermissionRevocationEnabledForAppResult(boolean param1Boolean1, boolean param1Boolean2) throws RemoteException {
      Parcel parcel = Parcel.obtain();
      try {
        parcel.writeInterfaceToken(IUnusedAppRestrictionsBackportCallback.DESCRIPTOR);
        boolean bool2 = false;
        if (param1Boolean1) {
          bool1 = true;
        } else {
          bool1 = false;
        } 
        parcel.writeInt(bool1);
        boolean bool1 = bool2;
        if (param1Boolean2)
          bool1 = true; 
        parcel.writeInt(bool1);
        this.mRemote.transact(1, parcel, null, 1);
        return;
      } finally {
        parcel.recycle();
      } 
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\MagicAI - AI Art & Anime Art-dex2jar.jar!\androidx\core\ap\\unusedapprestrictions\IUnusedAppRestrictionsBackportCallback.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */