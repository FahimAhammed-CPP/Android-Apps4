package androidx.core.app;

import android.app.job.JobInfo;
import android.app.job.JobScheduler;
import android.app.job.JobWorkItem;



/* Location:              C:\soft\dex2jar-2.0\MagicAI - AI Art & Anime Art-dex2jar.jar!\androidx\core\app\JobIntentService$JobWorkEnqueuer$$ExternalSyntheticApiModelOutline0.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */