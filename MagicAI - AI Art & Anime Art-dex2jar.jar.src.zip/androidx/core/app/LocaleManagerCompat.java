package androidx.core.app;

import android.app.LocaleManager;
import android.content.Context;
import android.content.res.Configuration;
import android.os.Build;
import android.os.LocaleList;
import androidx.annotation.AnyThread;
import androidx.annotation.DoNotInline;
import androidx.annotation.NonNull;
import androidx.annotation.OptIn;
import androidx.annotation.RequiresApi;
import androidx.annotation.VisibleForTesting;
import androidx.appcompat.app.AppCompatDelegateImpl$Api24Impl$;
import androidx.core.os.BuildCompat;
import androidx.core.os.LocaleListCompat;
import java.util.Locale;

public final class LocaleManagerCompat {
  @VisibleForTesting
  static LocaleListCompat getConfigurationLocales(Configuration paramConfiguration) {
    return (Build.VERSION.SDK_INT >= 24) ? Api24Impl.getLocales(paramConfiguration) : LocaleListCompat.forLanguageTags(Api21Impl.toLanguageTag(paramConfiguration.locale));
  }
  
  @RequiresApi(33)
  private static Object getLocaleManagerForApplication(Context paramContext) {
    return paramContext.getSystemService("locale");
  }
  
  @AnyThread
  @NonNull
  @OptIn(markerClass = {BuildCompat.PrereleaseSdkCheck.class})
  public static LocaleListCompat getSystemLocales(@NonNull Context paramContext) {
    LocaleListCompat localeListCompat1;
    LocaleListCompat localeListCompat2 = LocaleListCompat.getEmptyLocaleList();
    if (BuildCompat.isAtLeastT()) {
      Object object = getLocaleManagerForApplication(paramContext);
      localeListCompat1 = localeListCompat2;
      if (object != null)
        return LocaleListCompat.wrap(Api33Impl.localeManagerGetSystemLocales(object)); 
    } else {
      localeListCompat1 = getConfigurationLocales(localeListCompat1.getApplicationContext().getResources().getConfiguration());
    } 
    return localeListCompat1;
  }
  
  @RequiresApi(21)
  static class Api21Impl {
    @DoNotInline
    static String toLanguageTag(Locale param1Locale) {
      return param1Locale.toLanguageTag();
    }
  }
  
  @RequiresApi(24)
  static class Api24Impl {
    @DoNotInline
    static LocaleListCompat getLocales(Configuration param1Configuration) {
      return LocaleListCompat.forLanguageTags(AppCompatDelegateImpl$Api24Impl$.ExternalSyntheticApiModelOutline2.m(AppCompatDelegateImpl$Api24Impl$.ExternalSyntheticApiModelOutline1.m(param1Configuration)));
    }
  }
  
  @RequiresApi(33)
  static class Api33Impl {
    @DoNotInline
    static LocaleList localeManagerGetSystemLocales(Object param1Object) {
      return ((LocaleManager)param1Object).getSystemLocales();
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\MagicAI - AI Art & Anime Art-dex2jar.jar!\androidx\core\app\LocaleManagerCompat.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */