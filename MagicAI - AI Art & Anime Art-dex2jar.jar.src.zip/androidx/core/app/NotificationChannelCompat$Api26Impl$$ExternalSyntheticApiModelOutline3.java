package androidx.core.app;

import android.app.NotificationChannel;



/* Location:              C:\soft\dex2jar-2.0\MagicAI - AI Art & Anime Art-dex2jar.jar!\androidx\core\app\NotificationChannelCompat$Api26Impl$$ExternalSyntheticApiModelOutline3.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */