package androidx.core.view.accessibility;

import android.accessibilityservice.AccessibilityServiceInfo;
import android.view.accessibility.AccessibilityManager;
import androidx.annotation.DoNotInline;
import androidx.annotation.NonNull;
import androidx.annotation.RequiresApi;
import java.util.List;

public final class AccessibilityManagerCompat {
  @Deprecated
  public static boolean addAccessibilityStateChangeListener(AccessibilityManager paramAccessibilityManager, AccessibilityStateChangeListener paramAccessibilityStateChangeListener) {
    return (paramAccessibilityStateChangeListener == null) ? false : paramAccessibilityManager.addAccessibilityStateChangeListener(new AccessibilityStateChangeListenerWrapper(paramAccessibilityStateChangeListener));
  }
  
  public static boolean addTouchExplorationStateChangeListener(@NonNull AccessibilityManager paramAccessibilityManager, @NonNull TouchExplorationStateChangeListener paramTouchExplorationStateChangeListener) {
    return Api19Impl.addTouchExplorationStateChangeListenerWrapper(paramAccessibilityManager, paramTouchExplorationStateChangeListener);
  }
  
  @Deprecated
  public static List<AccessibilityServiceInfo> getEnabledAccessibilityServiceList(AccessibilityManager paramAccessibilityManager, int paramInt) {
    return paramAccessibilityManager.getEnabledAccessibilityServiceList(paramInt);
  }
  
  @Deprecated
  public static List<AccessibilityServiceInfo> getInstalledAccessibilityServiceList(AccessibilityManager paramAccessibilityManager) {
    return paramAccessibilityManager.getInstalledAccessibilityServiceList();
  }
  
  @Deprecated
  public static boolean isTouchExplorationEnabled(AccessibilityManager paramAccessibilityManager) {
    return paramAccessibilityManager.isTouchExplorationEnabled();
  }
  
  @Deprecated
  public static boolean removeAccessibilityStateChangeListener(AccessibilityManager paramAccessibilityManager, AccessibilityStateChangeListener paramAccessibilityStateChangeListener) {
    return (paramAccessibilityStateChangeListener == null) ? false : paramAccessibilityManager.removeAccessibilityStateChangeListener(new AccessibilityStateChangeListenerWrapper(paramAccessibilityStateChangeListener));
  }
  
  public static boolean removeTouchExplorationStateChangeListener(@NonNull AccessibilityManager paramAccessibilityManager, @NonNull TouchExplorationStateChangeListener paramTouchExplorationStateChangeListener) {
    return Api19Impl.removeTouchExplorationStateChangeListenerWrapper(paramAccessibilityManager, paramTouchExplorationStateChangeListener);
  }
  
  @Deprecated
  public static interface AccessibilityStateChangeListener {
    @Deprecated
    void onAccessibilityStateChanged(boolean param1Boolean);
  }
  
  @Deprecated
  public static abstract class AccessibilityStateChangeListenerCompat implements AccessibilityStateChangeListener {}
  
  private static class AccessibilityStateChangeListenerWrapper implements AccessibilityManager.AccessibilityStateChangeListener {
    AccessibilityManagerCompat.AccessibilityStateChangeListener mListener;
    
    AccessibilityStateChangeListenerWrapper(@NonNull AccessibilityManagerCompat.AccessibilityStateChangeListener param1AccessibilityStateChangeListener) {
      this.mListener = param1AccessibilityStateChangeListener;
    }
    
    public boolean equals(Object param1Object) {
      if (this == param1Object)
        return true; 
      if (!(param1Object instanceof AccessibilityStateChangeListenerWrapper))
        return false; 
      param1Object = param1Object;
      return this.mListener.equals(((AccessibilityStateChangeListenerWrapper)param1Object).mListener);
    }
    
    public int hashCode() {
      return this.mListener.hashCode();
    }
    
    public void onAccessibilityStateChanged(boolean param1Boolean) {
      this.mListener.onAccessibilityStateChanged(param1Boolean);
    }
  }
  
  @RequiresApi(19)
  static class Api19Impl {
    @DoNotInline
    static boolean addTouchExplorationStateChangeListenerWrapper(AccessibilityManager param1AccessibilityManager, AccessibilityManagerCompat.TouchExplorationStateChangeListener param1TouchExplorationStateChangeListener) {
      return param1AccessibilityManager.addTouchExplorationStateChangeListener(new AccessibilityManagerCompat.TouchExplorationStateChangeListenerWrapper(param1TouchExplorationStateChangeListener));
    }
    
    @DoNotInline
    static boolean removeTouchExplorationStateChangeListenerWrapper(AccessibilityManager param1AccessibilityManager, AccessibilityManagerCompat.TouchExplorationStateChangeListener param1TouchExplorationStateChangeListener) {
      return param1AccessibilityManager.removeTouchExplorationStateChangeListener(new AccessibilityManagerCompat.TouchExplorationStateChangeListenerWrapper(param1TouchExplorationStateChangeListener));
    }
  }
  
  public static interface TouchExplorationStateChangeListener {
    void onTouchExplorationStateChanged(boolean param1Boolean);
  }
  
  @RequiresApi(19)
  private static final class TouchExplorationStateChangeListenerWrapper implements AccessibilityManager.TouchExplorationStateChangeListener {
    final AccessibilityManagerCompat.TouchExplorationStateChangeListener mListener;
    
    TouchExplorationStateChangeListenerWrapper(@NonNull AccessibilityManagerCompat.TouchExplorationStateChangeListener param1TouchExplorationStateChangeListener) {
      this.mListener = param1TouchExplorationStateChangeListener;
    }
    
    public boolean equals(Object param1Object) {
      if (this == param1Object)
        return true; 
      if (!(param1Object instanceof TouchExplorationStateChangeListenerWrapper))
        return false; 
      param1Object = param1Object;
      return this.mListener.equals(((TouchExplorationStateChangeListenerWrapper)param1Object).mListener);
    }
    
    public int hashCode() {
      return this.mListener.hashCode();
    }
    
    public void onTouchExplorationStateChanged(boolean param1Boolean) {
      this.mListener.onTouchExplorationStateChanged(param1Boolean);
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\MagicAI - AI Art & Anime Art-dex2jar.jar!\androidx\core\view\accessibility\AccessibilityManagerCompat.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */