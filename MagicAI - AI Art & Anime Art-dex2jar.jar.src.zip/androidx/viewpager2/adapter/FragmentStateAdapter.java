package androidx.viewpager2.adapter;

import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.os.Parcelable;
import android.view.View;
import android.view.ViewGroup;
import android.view.ViewParent;
import android.widget.FrameLayout;
import androidx.annotation.CallSuper;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.annotation.OptIn;
import androidx.annotation.RequiresOptIn;
import androidx.collection.ArraySet;
import androidx.collection.LongSparseArray;
import androidx.core.util.Preconditions;
import androidx.core.view.ViewCompat;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentActivity;
import androidx.fragment.app.FragmentManager;
import androidx.fragment.app.FragmentTransaction;
import androidx.lifecycle.Lifecycle;
import androidx.lifecycle.LifecycleEventObserver;
import androidx.lifecycle.LifecycleObserver;
import androidx.lifecycle.LifecycleOwner;
import androidx.recyclerview.widget.RecyclerView;
import androidx.viewpager2.widget.ViewPager2;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Iterator;
import java.util.List;
import java.util.concurrent.CopyOnWriteArrayList;

public abstract class FragmentStateAdapter extends RecyclerView.Adapter<FragmentViewHolder> implements StatefulAdapter {
  private static final long GRACE_WINDOW_TIME_MS = 10000L;
  
  private static final String KEY_PREFIX_FRAGMENT = "f#";
  
  private static final String KEY_PREFIX_STATE = "s#";
  
  FragmentEventDispatcher mFragmentEventDispatcher = new FragmentEventDispatcher();
  
  final FragmentManager mFragmentManager;
  
  private FragmentMaxLifecycleEnforcer mFragmentMaxLifecycleEnforcer;
  
  final LongSparseArray<Fragment> mFragments = new LongSparseArray();
  
  private boolean mHasStaleFragments = false;
  
  boolean mIsInGracePeriod = false;
  
  private final LongSparseArray<Integer> mItemIdToViewHolder = new LongSparseArray();
  
  final Lifecycle mLifecycle;
  
  private final LongSparseArray<Fragment.SavedState> mSavedStates = new LongSparseArray();
  
  public FragmentStateAdapter(@NonNull Fragment paramFragment) {
    this(paramFragment.getChildFragmentManager(), paramFragment.getLifecycle());
  }
  
  public FragmentStateAdapter(@NonNull FragmentActivity paramFragmentActivity) {
    this(paramFragmentActivity.getSupportFragmentManager(), paramFragmentActivity.getLifecycle());
  }
  
  public FragmentStateAdapter(@NonNull FragmentManager paramFragmentManager, @NonNull Lifecycle paramLifecycle) {
    this.mFragmentManager = paramFragmentManager;
    this.mLifecycle = paramLifecycle;
    super.setHasStableIds(true);
  }
  
  @NonNull
  private static String createKey(@NonNull String paramString, long paramLong) {
    StringBuilder stringBuilder = new StringBuilder();
    stringBuilder.append(paramString);
    stringBuilder.append(paramLong);
    return stringBuilder.toString();
  }
  
  private void ensureFragment(int paramInt) {
    long l = getItemId(paramInt);
    if (!this.mFragments.containsKey(l)) {
      Fragment fragment = createFragment(paramInt);
      fragment.setInitialSavedState((Fragment.SavedState)this.mSavedStates.get(l));
      this.mFragments.put(l, fragment);
    } 
  }
  
  private boolean isFragmentViewBound(long paramLong) {
    if (this.mItemIdToViewHolder.containsKey(paramLong))
      return true; 
    Fragment fragment = (Fragment)this.mFragments.get(paramLong);
    if (fragment == null)
      return false; 
    View view = fragment.getView();
    return (view == null) ? false : ((view.getParent() != null));
  }
  
  private static boolean isValidKey(@NonNull String paramString1, @NonNull String paramString2) {
    return (paramString1.startsWith(paramString2) && paramString1.length() > paramString2.length());
  }
  
  private Long itemForViewHolder(int paramInt) {
    Long long_ = null;
    int i = 0;
    while (i < this.mItemIdToViewHolder.size()) {
      Long long_1 = long_;
      if (((Integer)this.mItemIdToViewHolder.valueAt(i)).intValue() == paramInt)
        if (long_ == null) {
          long_1 = Long.valueOf(this.mItemIdToViewHolder.keyAt(i));
        } else {
          throw new IllegalStateException("Design assumption violated: a ViewHolder can only be bound to one item at a time.");
        }  
      i++;
      long_ = long_1;
    } 
    return long_;
  }
  
  private static long parseIdFromKey(@NonNull String paramString1, @NonNull String paramString2) {
    return Long.parseLong(paramString1.substring(paramString2.length()));
  }
  
  private void removeFragment(long paramLong) {
    null = (Fragment)this.mFragments.get(paramLong);
    if (null == null)
      return; 
    if (null.getView() != null) {
      ViewParent viewParent = null.getView().getParent();
      if (viewParent != null)
        ((FrameLayout)viewParent).removeAllViews(); 
    } 
    if (!containsItem(paramLong))
      this.mSavedStates.remove(paramLong); 
    if (!null.isAdded()) {
      this.mFragments.remove(paramLong);
      return;
    } 
    if (shouldDelayFragmentTransactions()) {
      this.mHasStaleFragments = true;
      return;
    } 
    if (null.isAdded() && containsItem(paramLong)) {
      List<FragmentTransactionCallback.OnPostEventListener> list1 = this.mFragmentEventDispatcher.dispatchPreSavedInstanceState(null);
      Fragment.SavedState savedState = this.mFragmentManager.saveFragmentInstanceState(null);
      this.mFragmentEventDispatcher.dispatchPostEvents(list1);
      this.mSavedStates.put(paramLong, savedState);
    } 
    List<FragmentTransactionCallback.OnPostEventListener> list = this.mFragmentEventDispatcher.dispatchPreRemoved(null);
    try {
      this.mFragmentManager.beginTransaction().remove(null).commitNow();
      this.mFragments.remove(paramLong);
      return;
    } finally {
      this.mFragmentEventDispatcher.dispatchPostEvents(list);
    } 
  }
  
  private void scheduleGracePeriodEnd() {
    final Handler handler = new Handler(Looper.getMainLooper());
    final Runnable runnable = new Runnable() {
        public void run() {
          FragmentStateAdapter fragmentStateAdapter = FragmentStateAdapter.this;
          fragmentStateAdapter.mIsInGracePeriod = false;
          fragmentStateAdapter.gcFragments();
        }
      };
    this.mLifecycle.addObserver((LifecycleObserver)new LifecycleEventObserver() {
          public void onStateChanged(@NonNull LifecycleOwner param1LifecycleOwner, @NonNull Lifecycle.Event param1Event) {
            if (param1Event == Lifecycle.Event.ON_DESTROY) {
              handler.removeCallbacks(runnable);
              param1LifecycleOwner.getLifecycle().removeObserver((LifecycleObserver)this);
            } 
          }
        });
    handler.postDelayed(runnable, 10000L);
  }
  
  private void scheduleViewAttach(final Fragment fragment, @NonNull final FrameLayout container) {
    this.mFragmentManager.registerFragmentLifecycleCallbacks(new FragmentManager.FragmentLifecycleCallbacks() {
          public void onFragmentViewCreated(@NonNull FragmentManager param1FragmentManager, @NonNull Fragment param1Fragment, @NonNull View param1View, @Nullable Bundle param1Bundle) {
            if (param1Fragment == fragment) {
              param1FragmentManager.unregisterFragmentLifecycleCallbacks(this);
              FragmentStateAdapter.this.addViewToContainer(param1View, container);
            } 
          }
        }false);
  }
  
  void addViewToContainer(@NonNull View paramView, @NonNull FrameLayout paramFrameLayout) {
    if (paramFrameLayout.getChildCount() <= 1) {
      if (paramView.getParent() == paramFrameLayout)
        return; 
      if (paramFrameLayout.getChildCount() > 0)
        paramFrameLayout.removeAllViews(); 
      if (paramView.getParent() != null)
        ((ViewGroup)paramView.getParent()).removeView(paramView); 
      paramFrameLayout.addView(paramView);
      return;
    } 
    throw new IllegalStateException("Design assumption violated.");
  }
  
  public boolean containsItem(long paramLong) {
    return (paramLong >= 0L && paramLong < getItemCount());
  }
  
  @NonNull
  public abstract Fragment createFragment(int paramInt);
  
  void gcFragments() {
    if (this.mHasStaleFragments) {
      if (shouldDelayFragmentTransactions())
        return; 
      ArraySet<Long> arraySet = new ArraySet();
      boolean bool = false;
      int i;
      for (i = 0; i < this.mFragments.size(); i++) {
        long l = this.mFragments.keyAt(i);
        if (!containsItem(l)) {
          arraySet.add(Long.valueOf(l));
          this.mItemIdToViewHolder.remove(l);
        } 
      } 
      if (!this.mIsInGracePeriod) {
        this.mHasStaleFragments = false;
        for (i = bool; i < this.mFragments.size(); i++) {
          long l = this.mFragments.keyAt(i);
          if (!isFragmentViewBound(l))
            arraySet.add(Long.valueOf(l)); 
        } 
      } 
      Iterator<Long> iterator = arraySet.iterator();
      while (iterator.hasNext())
        removeFragment(((Long)iterator.next()).longValue()); 
    } 
  }
  
  public long getItemId(int paramInt) {
    return paramInt;
  }
  
  @CallSuper
  public void onAttachedToRecyclerView(@NonNull RecyclerView paramRecyclerView) {
    boolean bool;
    if (this.mFragmentMaxLifecycleEnforcer == null) {
      bool = true;
    } else {
      bool = false;
    } 
    Preconditions.checkArgument(bool);
    FragmentMaxLifecycleEnforcer fragmentMaxLifecycleEnforcer = new FragmentMaxLifecycleEnforcer();
    this.mFragmentMaxLifecycleEnforcer = fragmentMaxLifecycleEnforcer;
    fragmentMaxLifecycleEnforcer.register(paramRecyclerView);
  }
  
  public final void onBindViewHolder(@NonNull FragmentViewHolder paramFragmentViewHolder, int paramInt) {
    long l = paramFragmentViewHolder.getItemId();
    int i = paramFragmentViewHolder.getContainer().getId();
    Long long_ = itemForViewHolder(i);
    if (long_ != null && long_.longValue() != l) {
      removeFragment(long_.longValue());
      this.mItemIdToViewHolder.remove(long_.longValue());
    } 
    this.mItemIdToViewHolder.put(l, Integer.valueOf(i));
    ensureFragment(paramInt);
    if (ViewCompat.isAttachedToWindow((View)paramFragmentViewHolder.getContainer()))
      placeFragmentInViewHolder(paramFragmentViewHolder); 
    gcFragments();
  }
  
  @NonNull
  public final FragmentViewHolder onCreateViewHolder(@NonNull ViewGroup paramViewGroup, int paramInt) {
    return FragmentViewHolder.create(paramViewGroup);
  }
  
  @CallSuper
  public void onDetachedFromRecyclerView(@NonNull RecyclerView paramRecyclerView) {
    this.mFragmentMaxLifecycleEnforcer.unregister(paramRecyclerView);
    this.mFragmentMaxLifecycleEnforcer = null;
  }
  
  public final boolean onFailedToRecycleView(@NonNull FragmentViewHolder paramFragmentViewHolder) {
    return true;
  }
  
  public final void onViewAttachedToWindow(@NonNull FragmentViewHolder paramFragmentViewHolder) {
    placeFragmentInViewHolder(paramFragmentViewHolder);
    gcFragments();
  }
  
  public final void onViewRecycled(@NonNull FragmentViewHolder paramFragmentViewHolder) {
    Long long_ = itemForViewHolder(paramFragmentViewHolder.getContainer().getId());
    if (long_ != null) {
      removeFragment(long_.longValue());
      this.mItemIdToViewHolder.remove(long_.longValue());
    } 
  }
  
  void placeFragmentInViewHolder(@NonNull final FragmentViewHolder holder) {
    Fragment fragment = (Fragment)this.mFragments.get(holder.getItemId());
    if (fragment != null) {
      FrameLayout frameLayout = holder.getContainer();
      View view = fragment.getView();
      if (fragment.isAdded() || view == null) {
        if (fragment.isAdded() && view == null) {
          scheduleViewAttach(fragment, frameLayout);
          return;
        } 
        if (fragment.isAdded() && view.getParent() != null) {
          if (view.getParent() != frameLayout)
            addViewToContainer(view, frameLayout); 
          return;
        } 
        if (fragment.isAdded()) {
          addViewToContainer(view, frameLayout);
          return;
        } 
        if (!shouldDelayFragmentTransactions()) {
          scheduleViewAttach(fragment, frameLayout);
          List<FragmentTransactionCallback.OnPostEventListener> list = this.mFragmentEventDispatcher.dispatchPreAdded(fragment);
          try {
            fragment.setMenuVisibility(false);
            FragmentTransaction fragmentTransaction = this.mFragmentManager.beginTransaction();
            StringBuilder stringBuilder = new StringBuilder();
            stringBuilder.append("f");
            stringBuilder.append(holder.getItemId());
            fragmentTransaction.add(fragment, stringBuilder.toString()).setMaxLifecycle(fragment, Lifecycle.State.STARTED).commitNow();
            this.mFragmentMaxLifecycleEnforcer.updateFragmentMaxLifecycle(false);
            return;
          } finally {
            this.mFragmentEventDispatcher.dispatchPostEvents(list);
          } 
        } 
        if (this.mFragmentManager.isDestroyed())
          return; 
        this.mLifecycle.addObserver((LifecycleObserver)new LifecycleEventObserver() {
              public void onStateChanged(@NonNull LifecycleOwner param1LifecycleOwner, @NonNull Lifecycle.Event param1Event) {
                if (FragmentStateAdapter.this.shouldDelayFragmentTransactions())
                  return; 
                param1LifecycleOwner.getLifecycle().removeObserver((LifecycleObserver)this);
                if (ViewCompat.isAttachedToWindow((View)holder.getContainer()))
                  FragmentStateAdapter.this.placeFragmentInViewHolder(holder); 
              }
            });
        return;
      } 
      throw new IllegalStateException("Design assumption violated.");
    } 
    throw new IllegalStateException("Design assumption violated.");
  }
  
  public void registerFragmentTransactionCallback(@NonNull FragmentTransactionCallback paramFragmentTransactionCallback) {
    this.mFragmentEventDispatcher.registerCallback(paramFragmentTransactionCallback);
  }
  
  public final void restoreState(@NonNull Parcelable paramParcelable) {
    if (this.mSavedStates.isEmpty() && this.mFragments.isEmpty()) {
      Bundle bundle = (Bundle)paramParcelable;
      if (bundle.getClassLoader() == null)
        bundle.setClassLoader(getClass().getClassLoader()); 
      for (String str : bundle.keySet()) {
        Fragment fragment;
        Fragment.SavedState savedState;
        if (isValidKey(str, "f#")) {
          long l = parseIdFromKey(str, "f#");
          fragment = this.mFragmentManager.getFragment(bundle, str);
          this.mFragments.put(l, fragment);
          continue;
        } 
        if (isValidKey((String)fragment, "s#")) {
          long l = parseIdFromKey((String)fragment, "s#");
          savedState = (Fragment.SavedState)bundle.getParcelable((String)fragment);
          if (containsItem(l))
            this.mSavedStates.put(l, savedState); 
          continue;
        } 
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("Unexpected key in savedState: ");
        stringBuilder.append((String)savedState);
        throw new IllegalArgumentException(stringBuilder.toString());
      } 
      if (!this.mFragments.isEmpty()) {
        this.mHasStaleFragments = true;
        this.mIsInGracePeriod = true;
        gcFragments();
        scheduleGracePeriodEnd();
      } 
      return;
    } 
    throw new IllegalStateException("Expected the adapter to be 'fresh' while restoring state.");
  }
  
  @NonNull
  public final Parcelable saveState() {
    int j;
    Bundle bundle = new Bundle(this.mFragments.size() + this.mSavedStates.size());
    byte b = 0;
    int i = 0;
    while (true) {
      j = b;
      if (i < this.mFragments.size()) {
        long l = this.mFragments.keyAt(i);
        Fragment fragment = (Fragment)this.mFragments.get(l);
        if (fragment != null && fragment.isAdded()) {
          String str = createKey("f#", l);
          this.mFragmentManager.putFragment(bundle, str, fragment);
        } 
        i++;
        continue;
      } 
      break;
    } 
    while (j < this.mSavedStates.size()) {
      long l = this.mSavedStates.keyAt(j);
      if (containsItem(l))
        bundle.putParcelable(createKey("s#", l), (Parcelable)this.mSavedStates.get(l)); 
      j++;
    } 
    return (Parcelable)bundle;
  }
  
  public final void setHasStableIds(boolean paramBoolean) {
    throw new UnsupportedOperationException("Stable Ids are required for the adapter to function properly, and the adapter takes care of setting the flag.");
  }
  
  boolean shouldDelayFragmentTransactions() {
    return this.mFragmentManager.isStateSaved();
  }
  
  public void unregisterFragmentTransactionCallback(@NonNull FragmentTransactionCallback paramFragmentTransactionCallback) {
    this.mFragmentEventDispatcher.unregisterCallback(paramFragmentTransactionCallback);
  }
  
  private static abstract class DataSetChangeObserver extends RecyclerView.AdapterDataObserver {
    private DataSetChangeObserver() {}
    
    public abstract void onChanged();
    
    public final void onItemRangeChanged(int param1Int1, int param1Int2) {
      onChanged();
    }
    
    public final void onItemRangeChanged(int param1Int1, int param1Int2, @Nullable Object param1Object) {
      onChanged();
    }
    
    public final void onItemRangeInserted(int param1Int1, int param1Int2) {
      onChanged();
    }
    
    public final void onItemRangeMoved(int param1Int1, int param1Int2, int param1Int3) {
      onChanged();
    }
    
    public final void onItemRangeRemoved(int param1Int1, int param1Int2) {
      onChanged();
    }
  }
  
  @RequiresOptIn(level = RequiresOptIn.Level.WARNING)
  public static @interface ExperimentalFragmentStateAdapterApi {}
  
  static class FragmentEventDispatcher {
    private List<FragmentStateAdapter.FragmentTransactionCallback> mCallbacks = new CopyOnWriteArrayList<FragmentStateAdapter.FragmentTransactionCallback>();
    
    public List<FragmentStateAdapter.FragmentTransactionCallback.OnPostEventListener> dispatchMaxLifecyclePreUpdated(Fragment param1Fragment, Lifecycle.State param1State) {
      ArrayList<FragmentStateAdapter.FragmentTransactionCallback.OnPostEventListener> arrayList = new ArrayList();
      Iterator<FragmentStateAdapter.FragmentTransactionCallback> iterator = this.mCallbacks.iterator();
      while (iterator.hasNext())
        arrayList.add(((FragmentStateAdapter.FragmentTransactionCallback)iterator.next()).onFragmentMaxLifecyclePreUpdated(param1Fragment, param1State)); 
      return arrayList;
    }
    
    public void dispatchPostEvents(List<FragmentStateAdapter.FragmentTransactionCallback.OnPostEventListener> param1List) {
      Iterator<FragmentStateAdapter.FragmentTransactionCallback.OnPostEventListener> iterator = param1List.iterator();
      while (iterator.hasNext())
        ((FragmentStateAdapter.FragmentTransactionCallback.OnPostEventListener)iterator.next()).onPost(); 
    }
    
    public List<FragmentStateAdapter.FragmentTransactionCallback.OnPostEventListener> dispatchPreAdded(Fragment param1Fragment) {
      ArrayList<FragmentStateAdapter.FragmentTransactionCallback.OnPostEventListener> arrayList = new ArrayList();
      Iterator<FragmentStateAdapter.FragmentTransactionCallback> iterator = this.mCallbacks.iterator();
      while (iterator.hasNext())
        arrayList.add(((FragmentStateAdapter.FragmentTransactionCallback)iterator.next()).onFragmentPreAdded(param1Fragment)); 
      return arrayList;
    }
    
    public List<FragmentStateAdapter.FragmentTransactionCallback.OnPostEventListener> dispatchPreRemoved(Fragment param1Fragment) {
      ArrayList<FragmentStateAdapter.FragmentTransactionCallback.OnPostEventListener> arrayList = new ArrayList();
      Iterator<FragmentStateAdapter.FragmentTransactionCallback> iterator = this.mCallbacks.iterator();
      while (iterator.hasNext())
        arrayList.add(((FragmentStateAdapter.FragmentTransactionCallback)iterator.next()).onFragmentPreRemoved(param1Fragment)); 
      return arrayList;
    }
    
    @OptIn(markerClass = {FragmentStateAdapter.ExperimentalFragmentStateAdapterApi.class})
    public List<FragmentStateAdapter.FragmentTransactionCallback.OnPostEventListener> dispatchPreSavedInstanceState(Fragment param1Fragment) {
      ArrayList<FragmentStateAdapter.FragmentTransactionCallback.OnPostEventListener> arrayList = new ArrayList();
      Iterator<FragmentStateAdapter.FragmentTransactionCallback> iterator = this.mCallbacks.iterator();
      while (iterator.hasNext())
        arrayList.add(((FragmentStateAdapter.FragmentTransactionCallback)iterator.next()).onFragmentPreSavedInstanceState(param1Fragment)); 
      return arrayList;
    }
    
    public void registerCallback(FragmentStateAdapter.FragmentTransactionCallback param1FragmentTransactionCallback) {
      this.mCallbacks.add(param1FragmentTransactionCallback);
    }
    
    public void unregisterCallback(FragmentStateAdapter.FragmentTransactionCallback param1FragmentTransactionCallback) {
      this.mCallbacks.remove(param1FragmentTransactionCallback);
    }
  }
  
  class FragmentMaxLifecycleEnforcer {
    private RecyclerView.AdapterDataObserver mDataObserver;
    
    private LifecycleEventObserver mLifecycleObserver;
    
    private ViewPager2.OnPageChangeCallback mPageChangeCallback;
    
    private long mPrimaryItemId = -1L;
    
    private ViewPager2 mViewPager;
    
    @NonNull
    private ViewPager2 inferViewPager(@NonNull RecyclerView param1RecyclerView) {
      ViewParent viewParent = param1RecyclerView.getParent();
      if (viewParent instanceof ViewPager2)
        return (ViewPager2)viewParent; 
      StringBuilder stringBuilder = new StringBuilder();
      stringBuilder.append("Expected ViewPager2 instance. Got: ");
      stringBuilder.append(viewParent);
      throw new IllegalStateException(stringBuilder.toString());
    }
    
    void register(@NonNull RecyclerView param1RecyclerView) {
      this.mViewPager = inferViewPager(param1RecyclerView);
      ViewPager2.OnPageChangeCallback onPageChangeCallback = new ViewPager2.OnPageChangeCallback() {
          public void onPageScrollStateChanged(int param2Int) {
            FragmentStateAdapter.FragmentMaxLifecycleEnforcer.this.updateFragmentMaxLifecycle(false);
          }
          
          public void onPageSelected(int param2Int) {
            FragmentStateAdapter.FragmentMaxLifecycleEnforcer.this.updateFragmentMaxLifecycle(false);
          }
        };
      this.mPageChangeCallback = onPageChangeCallback;
      this.mViewPager.registerOnPageChangeCallback(onPageChangeCallback);
      FragmentStateAdapter.DataSetChangeObserver dataSetChangeObserver = new FragmentStateAdapter.DataSetChangeObserver() {
          public void onChanged() {
            FragmentStateAdapter.FragmentMaxLifecycleEnforcer.this.updateFragmentMaxLifecycle(true);
          }
        };
      this.mDataObserver = dataSetChangeObserver;
      FragmentStateAdapter.this.registerAdapterDataObserver(dataSetChangeObserver);
      LifecycleEventObserver lifecycleEventObserver = new LifecycleEventObserver() {
          public void onStateChanged(@NonNull LifecycleOwner param2LifecycleOwner, @NonNull Lifecycle.Event param2Event) {
            FragmentStateAdapter.FragmentMaxLifecycleEnforcer.this.updateFragmentMaxLifecycle(false);
          }
        };
      this.mLifecycleObserver = lifecycleEventObserver;
      FragmentStateAdapter.this.mLifecycle.addObserver((LifecycleObserver)lifecycleEventObserver);
    }
    
    void unregister(@NonNull RecyclerView param1RecyclerView) {
      inferViewPager(param1RecyclerView).unregisterOnPageChangeCallback(this.mPageChangeCallback);
      FragmentStateAdapter.this.unregisterAdapterDataObserver(this.mDataObserver);
      FragmentStateAdapter.this.mLifecycle.removeObserver((LifecycleObserver)this.mLifecycleObserver);
      this.mViewPager = null;
    }
    
    void updateFragmentMaxLifecycle(boolean param1Boolean) {
      if (FragmentStateAdapter.this.shouldDelayFragmentTransactions())
        return; 
      if (this.mViewPager.getScrollState() != 0)
        return; 
      if (!FragmentStateAdapter.this.mFragments.isEmpty()) {
        if (FragmentStateAdapter.this.getItemCount() == 0)
          return; 
        int i = this.mViewPager.getCurrentItem();
        if (i >= FragmentStateAdapter.this.getItemCount())
          return; 
        long l = FragmentStateAdapter.this.getItemId(i);
        if (l == this.mPrimaryItemId && !param1Boolean)
          return; 
        Fragment fragment = (Fragment)FragmentStateAdapter.this.mFragments.get(l);
        if (fragment != null) {
          if (!fragment.isAdded())
            return; 
          this.mPrimaryItemId = l;
          FragmentTransaction fragmentTransaction = FragmentStateAdapter.this.mFragmentManager.beginTransaction();
          ArrayList<List<FragmentStateAdapter.FragmentTransactionCallback.OnPostEventListener>> arrayList = new ArrayList();
          fragment = null;
          for (i = 0; i < FragmentStateAdapter.this.mFragments.size(); i++) {
            l = FragmentStateAdapter.this.mFragments.keyAt(i);
            Fragment fragment1 = (Fragment)FragmentStateAdapter.this.mFragments.valueAt(i);
            if (fragment1.isAdded()) {
              if (l != this.mPrimaryItemId) {
                Lifecycle.State state = Lifecycle.State.STARTED;
                fragmentTransaction.setMaxLifecycle(fragment1, state);
                arrayList.add(FragmentStateAdapter.this.mFragmentEventDispatcher.dispatchMaxLifecyclePreUpdated(fragment1, state));
              } else {
                fragment = fragment1;
              } 
              if (l == this.mPrimaryItemId) {
                param1Boolean = true;
              } else {
                param1Boolean = false;
              } 
              fragment1.setMenuVisibility(param1Boolean);
            } 
          } 
          if (fragment != null) {
            Lifecycle.State state = Lifecycle.State.RESUMED;
            fragmentTransaction.setMaxLifecycle(fragment, state);
            arrayList.add(FragmentStateAdapter.this.mFragmentEventDispatcher.dispatchMaxLifecyclePreUpdated(fragment, state));
          } 
          if (!fragmentTransaction.isEmpty()) {
            fragmentTransaction.commitNow();
            Collections.reverse(arrayList);
            for (List<FragmentStateAdapter.FragmentTransactionCallback.OnPostEventListener> list : arrayList)
              FragmentStateAdapter.this.mFragmentEventDispatcher.dispatchPostEvents(list); 
          } 
        } 
      } 
    }
  }
  
  class null extends ViewPager2.OnPageChangeCallback {
    public void onPageScrollStateChanged(int param1Int) {
      this.this$1.updateFragmentMaxLifecycle(false);
    }
    
    public void onPageSelected(int param1Int) {
      this.this$1.updateFragmentMaxLifecycle(false);
    }
  }
  
  class null extends DataSetChangeObserver {
    public void onChanged() {
      this.this$1.updateFragmentMaxLifecycle(true);
    }
  }
  
  class null implements LifecycleEventObserver {
    public void onStateChanged(@NonNull LifecycleOwner param1LifecycleOwner, @NonNull Lifecycle.Event param1Event) {
      this.this$1.updateFragmentMaxLifecycle(false);
    }
  }
  
  public static abstract class FragmentTransactionCallback {
    @NonNull
    private static final OnPostEventListener NO_OP = new OnPostEventListener() {
        public void onPost() {}
      };
    
    @NonNull
    public OnPostEventListener onFragmentMaxLifecyclePreUpdated(@NonNull Fragment param1Fragment, @NonNull Lifecycle.State param1State) {
      return NO_OP;
    }
    
    @NonNull
    public OnPostEventListener onFragmentPreAdded(@NonNull Fragment param1Fragment) {
      return NO_OP;
    }
    
    @NonNull
    public OnPostEventListener onFragmentPreRemoved(@NonNull Fragment param1Fragment) {
      return NO_OP;
    }
    
    @NonNull
    @ExperimentalFragmentStateAdapterApi
    public OnPostEventListener onFragmentPreSavedInstanceState(@NonNull Fragment param1Fragment) {
      return NO_OP;
    }
    
    public static interface OnPostEventListener {
      void onPost();
    }
  }
  
  class null implements FragmentTransactionCallback.OnPostEventListener {
    public void onPost() {}
  }
  
  public static interface OnPostEventListener {
    void onPost();
  }
}


/* Location:              C:\soft\dex2jar-2.0\MagicAI - AI Art & Anime Art-dex2jar.jar!\androidx\viewpager2\adapter\FragmentStateAdapter.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */