package androidx.viewpager2.widget;

import android.animation.LayoutTransition;
import android.view.View;
import android.view.ViewGroup;
import androidx.annotation.NonNull;
import androidx.recyclerview.widget.LinearLayoutManager;
import java.lang.reflect.Array;
import java.util.Arrays;
import java.util.Comparator;

final class AnimateLayoutChangeDetector {
  private static final ViewGroup.MarginLayoutParams ZERO_MARGIN_LAYOUT_PARAMS;
  
  private LinearLayoutManager mLayoutManager;
  
  static {
    ViewGroup.MarginLayoutParams marginLayoutParams = new ViewGroup.MarginLayoutParams(-1, -1);
    ZERO_MARGIN_LAYOUT_PARAMS = marginLayoutParams;
    marginLayoutParams.setMargins(0, 0, 0, 0);
  }
  
  AnimateLayoutChangeDetector(@NonNull LinearLayoutManager paramLinearLayoutManager) {
    this.mLayoutManager = paramLinearLayoutManager;
  }
  
  private boolean arePagesLaidOutContiguously() {
    int k = this.mLayoutManager.getChildCount();
    if (k == 0)
      return true; 
    if (this.mLayoutManager.getOrientation() == 0) {
      i = 1;
    } else {
      i = 0;
    } 
    int[][] arrayOfInt1 = (int[][])Array.newInstance(int.class, new int[] { k, 2 });
    int j = 0;
    while (j < k) {
      View view = this.mLayoutManager.getChildAt(j);
      if (view != null) {
        int m;
        int n;
        ViewGroup.MarginLayoutParams marginLayoutParams;
        ViewGroup.LayoutParams layoutParams = view.getLayoutParams();
        if (layoutParams instanceof ViewGroup.MarginLayoutParams) {
          marginLayoutParams = (ViewGroup.MarginLayoutParams)layoutParams;
        } else {
          marginLayoutParams = ZERO_MARGIN_LAYOUT_PARAMS;
        } 
        int[] arrayOfInt2 = arrayOfInt1[j];
        if (i) {
          m = view.getLeft();
          n = marginLayoutParams.leftMargin;
        } else {
          m = view.getTop();
          n = marginLayoutParams.topMargin;
        } 
        arrayOfInt2[0] = m - n;
        arrayOfInt2 = arrayOfInt1[j];
        if (i) {
          m = view.getRight();
          n = marginLayoutParams.rightMargin;
        } else {
          m = view.getBottom();
          n = marginLayoutParams.bottomMargin;
        } 
        arrayOfInt2[1] = m + n;
        j++;
        continue;
      } 
      throw new IllegalStateException("null view contained in the view hierarchy");
    } 
    Arrays.sort(arrayOfInt1, (Comparator)new Comparator<int[]>() {
          public int compare(int[] param1ArrayOfint1, int[] param1ArrayOfint2) {
            return param1ArrayOfint1[0] - param1ArrayOfint2[0];
          }
        });
    int i;
    for (i = 1; i < k; i++) {
      if (arrayOfInt1[i - 1][1] != arrayOfInt1[i][0])
        return false; 
    } 
    int[] arrayOfInt = arrayOfInt1[0];
    i = arrayOfInt[1];
    j = arrayOfInt[0];
    return (j <= 0) ? (!(arrayOfInt1[k - 1][1] < i - j)) : false;
  }
  
  private boolean hasRunningChangingLayoutTransition() {
    int j = this.mLayoutManager.getChildCount();
    for (int i = 0; i < j; i++) {
      if (hasRunningChangingLayoutTransition(this.mLayoutManager.getChildAt(i)))
        return true; 
    } 
    return false;
  }
  
  private static boolean hasRunningChangingLayoutTransition(View paramView) {
    if (paramView instanceof ViewGroup) {
      ViewGroup viewGroup = (ViewGroup)paramView;
      LayoutTransition layoutTransition = viewGroup.getLayoutTransition();
      if (layoutTransition != null && layoutTransition.isChangingLayout())
        return true; 
      int j = viewGroup.getChildCount();
      for (int i = 0; i < j; i++) {
        if (hasRunningChangingLayoutTransition(viewGroup.getChildAt(i)))
          return true; 
      } 
    } 
    return false;
  }
  
  boolean mayHaveInterferingAnimations() {
    return ((!arePagesLaidOutContiguously() || this.mLayoutManager.getChildCount() <= 1) && hasRunningChangingLayoutTransition());
  }
}


/* Location:              C:\soft\dex2jar-2.0\MagicAI - AI Art & Anime Art-dex2jar.jar!\androidx\viewpager2\widget\AnimateLayoutChangeDetector.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */