package androidx.constraintlayout.core.widgets;

import androidx.constraintlayout.core.LinearSystem;
import androidx.constraintlayout.core.Metrics;
import androidx.constraintlayout.core.SolverVariable;
import androidx.constraintlayout.core.widgets.analyzer.BasicMeasure;
import androidx.constraintlayout.core.widgets.analyzer.DependencyGraph;
import java.lang.ref.WeakReference;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashSet;
import java.util.Iterator;

public class ConstraintWidgetContainer extends WidgetContainer {
  private static final boolean DEBUG = false;
  
  static final boolean DEBUG_GRAPH = false;
  
  private static final boolean DEBUG_LAYOUT = false;
  
  private static final int MAX_ITERATIONS = 8;
  
  static int myCounter;
  
  private WeakReference<ConstraintAnchor> horizontalWrapMax = null;
  
  private WeakReference<ConstraintAnchor> horizontalWrapMin = null;
  
  BasicMeasure mBasicMeasureSolver = new BasicMeasure(this);
  
  int mDebugSolverPassCount = 0;
  
  public DependencyGraph mDependencyGraph = new DependencyGraph(this);
  
  public boolean mGroupsWrapOptimized = false;
  
  private boolean mHeightMeasuredTooSmall = false;
  
  ChainHead[] mHorizontalChainsArray = new ChainHead[4];
  
  public int mHorizontalChainsSize = 0;
  
  public boolean mHorizontalWrapOptimized = false;
  
  private boolean mIsRtl = false;
  
  public BasicMeasure.Measure mMeasure = new BasicMeasure.Measure();
  
  protected BasicMeasure.Measurer mMeasurer = null;
  
  public Metrics mMetrics;
  
  private int mOptimizationLevel = 257;
  
  int mPaddingBottom;
  
  int mPaddingLeft;
  
  int mPaddingRight;
  
  int mPaddingTop;
  
  public boolean mSkipSolver = false;
  
  protected LinearSystem mSystem = new LinearSystem();
  
  ChainHead[] mVerticalChainsArray = new ChainHead[4];
  
  public int mVerticalChainsSize = 0;
  
  public boolean mVerticalWrapOptimized = false;
  
  private boolean mWidthMeasuredTooSmall = false;
  
  public int mWrapFixedHeight = 0;
  
  public int mWrapFixedWidth = 0;
  
  private int pass;
  
  private WeakReference<ConstraintAnchor> verticalWrapMax = null;
  
  private WeakReference<ConstraintAnchor> verticalWrapMin = null;
  
  HashSet<ConstraintWidget> widgetsToAdd = new HashSet<ConstraintWidget>();
  
  public ConstraintWidgetContainer() {}
  
  public ConstraintWidgetContainer(int paramInt1, int paramInt2) {
    super(paramInt1, paramInt2);
  }
  
  public ConstraintWidgetContainer(int paramInt1, int paramInt2, int paramInt3, int paramInt4) {
    super(paramInt1, paramInt2, paramInt3, paramInt4);
  }
  
  public ConstraintWidgetContainer(String paramString, int paramInt1, int paramInt2) {
    super(paramInt1, paramInt2);
    setDebugName(paramString);
  }
  
  private void addHorizontalChain(ConstraintWidget paramConstraintWidget) {
    int i = this.mHorizontalChainsSize;
    ChainHead[] arrayOfChainHead = this.mHorizontalChainsArray;
    if (i + 1 >= arrayOfChainHead.length)
      this.mHorizontalChainsArray = Arrays.<ChainHead>copyOf(arrayOfChainHead, arrayOfChainHead.length * 2); 
    this.mHorizontalChainsArray[this.mHorizontalChainsSize] = new ChainHead(paramConstraintWidget, 0, isRtl());
    this.mHorizontalChainsSize++;
  }
  
  private void addMaxWrap(ConstraintAnchor paramConstraintAnchor, SolverVariable paramSolverVariable) {
    SolverVariable solverVariable = this.mSystem.createObjectVariable(paramConstraintAnchor);
    this.mSystem.addGreaterThan(paramSolverVariable, solverVariable, 0, 5);
  }
  
  private void addMinWrap(ConstraintAnchor paramConstraintAnchor, SolverVariable paramSolverVariable) {
    SolverVariable solverVariable = this.mSystem.createObjectVariable(paramConstraintAnchor);
    this.mSystem.addGreaterThan(solverVariable, paramSolverVariable, 0, 5);
  }
  
  private void addVerticalChain(ConstraintWidget paramConstraintWidget) {
    int i = this.mVerticalChainsSize;
    ChainHead[] arrayOfChainHead = this.mVerticalChainsArray;
    if (i + 1 >= arrayOfChainHead.length)
      this.mVerticalChainsArray = Arrays.<ChainHead>copyOf(arrayOfChainHead, arrayOfChainHead.length * 2); 
    this.mVerticalChainsArray[this.mVerticalChainsSize] = new ChainHead(paramConstraintWidget, 1, isRtl());
    this.mVerticalChainsSize++;
  }
  
  public static boolean measure(int paramInt1, ConstraintWidget paramConstraintWidget, BasicMeasure.Measurer paramMeasurer, BasicMeasure.Measure paramMeasure, int paramInt2) {
    boolean bool1;
    boolean bool2;
    if (paramMeasurer == null)
      return false; 
    if (paramConstraintWidget.getVisibility() == 8 || paramConstraintWidget instanceof Guideline || paramConstraintWidget instanceof Barrier) {
      paramMeasure.measuredWidth = 0;
      paramMeasure.measuredHeight = 0;
      return false;
    } 
    paramMeasure.horizontalBehavior = paramConstraintWidget.getHorizontalDimensionBehaviour();
    paramMeasure.verticalBehavior = paramConstraintWidget.getVerticalDimensionBehaviour();
    paramMeasure.horizontalDimension = paramConstraintWidget.getWidth();
    paramMeasure.verticalDimension = paramConstraintWidget.getHeight();
    paramMeasure.measuredNeedsSolverPass = false;
    paramMeasure.measureStrategy = paramInt2;
    ConstraintWidget.DimensionBehaviour dimensionBehaviour1 = paramMeasure.horizontalBehavior;
    ConstraintWidget.DimensionBehaviour dimensionBehaviour2 = ConstraintWidget.DimensionBehaviour.MATCH_CONSTRAINT;
    if (dimensionBehaviour1 == dimensionBehaviour2) {
      paramInt1 = 1;
    } else {
      paramInt1 = 0;
    } 
    if (paramMeasure.verticalBehavior == dimensionBehaviour2) {
      paramInt2 = 1;
    } else {
      paramInt2 = 0;
    } 
    if (paramInt1 != 0 && paramConstraintWidget.mDimensionRatio > 0.0F) {
      bool2 = true;
    } else {
      bool2 = false;
    } 
    if (paramInt2 != 0 && paramConstraintWidget.mDimensionRatio > 0.0F) {
      bool1 = true;
    } else {
      bool1 = false;
    } 
    int i = paramInt1;
    if (paramInt1 != 0) {
      i = paramInt1;
      if (paramConstraintWidget.hasDanglingDimension(0)) {
        i = paramInt1;
        if (paramConstraintWidget.mMatchConstraintDefaultWidth == 0) {
          i = paramInt1;
          if (!bool2) {
            paramMeasure.horizontalBehavior = ConstraintWidget.DimensionBehaviour.WRAP_CONTENT;
            if (paramInt2 != 0 && paramConstraintWidget.mMatchConstraintDefaultHeight == 0)
              paramMeasure.horizontalBehavior = ConstraintWidget.DimensionBehaviour.FIXED; 
            i = 0;
          } 
        } 
      } 
    } 
    paramInt1 = paramInt2;
    if (paramInt2 != 0) {
      paramInt1 = paramInt2;
      if (paramConstraintWidget.hasDanglingDimension(1)) {
        paramInt1 = paramInt2;
        if (paramConstraintWidget.mMatchConstraintDefaultHeight == 0) {
          paramInt1 = paramInt2;
          if (!bool1) {
            paramMeasure.verticalBehavior = ConstraintWidget.DimensionBehaviour.WRAP_CONTENT;
            if (i != 0 && paramConstraintWidget.mMatchConstraintDefaultWidth == 0)
              paramMeasure.verticalBehavior = ConstraintWidget.DimensionBehaviour.FIXED; 
            paramInt1 = 0;
          } 
        } 
      } 
    } 
    if (paramConstraintWidget.isResolvedHorizontally()) {
      paramMeasure.horizontalBehavior = ConstraintWidget.DimensionBehaviour.FIXED;
      i = 0;
    } 
    if (paramConstraintWidget.isResolvedVertically()) {
      paramMeasure.verticalBehavior = ConstraintWidget.DimensionBehaviour.FIXED;
      paramInt1 = 0;
    } 
    if (bool2)
      if (paramConstraintWidget.mResolvedMatchConstraintDefault[0] == 4) {
        paramMeasure.horizontalBehavior = ConstraintWidget.DimensionBehaviour.FIXED;
      } else if (paramInt1 == 0) {
        dimensionBehaviour1 = paramMeasure.verticalBehavior;
        dimensionBehaviour2 = ConstraintWidget.DimensionBehaviour.FIXED;
        if (dimensionBehaviour1 == dimensionBehaviour2) {
          paramInt1 = paramMeasure.verticalDimension;
        } else {
          paramMeasure.horizontalBehavior = ConstraintWidget.DimensionBehaviour.WRAP_CONTENT;
          paramMeasurer.measure(paramConstraintWidget, paramMeasure);
          paramInt1 = paramMeasure.measuredHeight;
        } 
        paramMeasure.horizontalBehavior = dimensionBehaviour2;
        paramMeasure.horizontalDimension = (int)(paramConstraintWidget.getDimensionRatio() * paramInt1);
      }  
    if (bool1)
      if (paramConstraintWidget.mResolvedMatchConstraintDefault[1] == 4) {
        paramMeasure.verticalBehavior = ConstraintWidget.DimensionBehaviour.FIXED;
      } else if (i == 0) {
        dimensionBehaviour1 = paramMeasure.horizontalBehavior;
        dimensionBehaviour2 = ConstraintWidget.DimensionBehaviour.FIXED;
        if (dimensionBehaviour1 == dimensionBehaviour2) {
          paramInt1 = paramMeasure.horizontalDimension;
        } else {
          paramMeasure.verticalBehavior = ConstraintWidget.DimensionBehaviour.WRAP_CONTENT;
          paramMeasurer.measure(paramConstraintWidget, paramMeasure);
          paramInt1 = paramMeasure.measuredWidth;
        } 
        paramMeasure.verticalBehavior = dimensionBehaviour2;
        if (paramConstraintWidget.getDimensionRatioSide() == -1) {
          paramMeasure.verticalDimension = (int)(paramInt1 / paramConstraintWidget.getDimensionRatio());
        } else {
          paramMeasure.verticalDimension = (int)(paramConstraintWidget.getDimensionRatio() * paramInt1);
        } 
      }  
    paramMeasurer.measure(paramConstraintWidget, paramMeasure);
    paramConstraintWidget.setWidth(paramMeasure.measuredWidth);
    paramConstraintWidget.setHeight(paramMeasure.measuredHeight);
    paramConstraintWidget.setHasBaseline(paramMeasure.measuredHasBaseline);
    paramConstraintWidget.setBaselineDistance(paramMeasure.measuredBaseline);
    paramMeasure.measureStrategy = BasicMeasure.Measure.SELF_DIMENSIONS;
    return paramMeasure.measuredNeedsSolverPass;
  }
  
  private void resetChains() {
    this.mHorizontalChainsSize = 0;
    this.mVerticalChainsSize = 0;
  }
  
  void addChain(ConstraintWidget paramConstraintWidget, int paramInt) {
    if (paramInt == 0) {
      addHorizontalChain(paramConstraintWidget);
      return;
    } 
    if (paramInt == 1)
      addVerticalChain(paramConstraintWidget); 
  }
  
  public boolean addChildrenToSolver(LinearSystem paramLinearSystem) {
    boolean bool1 = optimizeFor(64);
    addToSolver(paramLinearSystem, bool1);
    int j = this.mChildren.size();
    int i = 0;
    boolean bool = false;
    while (i < j) {
      ConstraintWidget constraintWidget = this.mChildren.get(i);
      constraintWidget.setInBarrier(0, false);
      constraintWidget.setInBarrier(1, false);
      if (constraintWidget instanceof Barrier)
        bool = true; 
      i++;
    } 
    if (bool)
      for (i = 0; i < j; i++) {
        ConstraintWidget constraintWidget = this.mChildren.get(i);
        if (constraintWidget instanceof Barrier)
          ((Barrier)constraintWidget).markWidgets(); 
      }  
    this.widgetsToAdd.clear();
    for (i = 0; i < j; i++) {
      ConstraintWidget constraintWidget = this.mChildren.get(i);
      if (constraintWidget.addFirst())
        if (constraintWidget instanceof VirtualLayout) {
          this.widgetsToAdd.add(constraintWidget);
        } else {
          constraintWidget.addToSolver(paramLinearSystem, bool1);
        }  
    } 
    while (this.widgetsToAdd.size() > 0) {
      i = this.widgetsToAdd.size();
      for (VirtualLayout virtualLayout : this.widgetsToAdd) {
        if (virtualLayout.contains(this.widgetsToAdd)) {
          virtualLayout.addToSolver(paramLinearSystem, bool1);
          this.widgetsToAdd.remove(virtualLayout);
          break;
        } 
      } 
      if (i == this.widgetsToAdd.size()) {
        Iterator<ConstraintWidget> iterator = this.widgetsToAdd.iterator();
        while (iterator.hasNext())
          ((ConstraintWidget)iterator.next()).addToSolver(paramLinearSystem, bool1); 
        this.widgetsToAdd.clear();
      } 
    } 
    if (LinearSystem.USE_DEPENDENCY_ORDERING) {
      HashSet<ConstraintWidget> hashSet = new HashSet();
      for (i = 0; i < j; i++) {
        ConstraintWidget constraintWidget = this.mChildren.get(i);
        if (!constraintWidget.addFirst())
          hashSet.add(constraintWidget); 
      } 
      if (getHorizontalDimensionBehaviour() == ConstraintWidget.DimensionBehaviour.WRAP_CONTENT) {
        i = 0;
      } else {
        i = 1;
      } 
      addChildrenToSolverByDependency(this, paramLinearSystem, hashSet, i, false);
      for (ConstraintWidget constraintWidget : hashSet) {
        Optimizer.checkMatchParent(this, paramLinearSystem, constraintWidget);
        constraintWidget.addToSolver(paramLinearSystem, bool1);
      } 
    } else {
      for (i = 0; i < j; i++) {
        ConstraintWidget constraintWidget = this.mChildren.get(i);
        if (constraintWidget instanceof ConstraintWidgetContainer) {
          ConstraintWidget.DimensionBehaviour[] arrayOfDimensionBehaviour = constraintWidget.mListDimensionBehaviors;
          ConstraintWidget.DimensionBehaviour dimensionBehaviour1 = arrayOfDimensionBehaviour[0];
          ConstraintWidget.DimensionBehaviour dimensionBehaviour2 = arrayOfDimensionBehaviour[1];
          ConstraintWidget.DimensionBehaviour dimensionBehaviour3 = ConstraintWidget.DimensionBehaviour.WRAP_CONTENT;
          if (dimensionBehaviour1 == dimensionBehaviour3)
            constraintWidget.setHorizontalDimensionBehaviour(ConstraintWidget.DimensionBehaviour.FIXED); 
          if (dimensionBehaviour2 == dimensionBehaviour3)
            constraintWidget.setVerticalDimensionBehaviour(ConstraintWidget.DimensionBehaviour.FIXED); 
          constraintWidget.addToSolver(paramLinearSystem, bool1);
          if (dimensionBehaviour1 == dimensionBehaviour3)
            constraintWidget.setHorizontalDimensionBehaviour(dimensionBehaviour1); 
          if (dimensionBehaviour2 == dimensionBehaviour3)
            constraintWidget.setVerticalDimensionBehaviour(dimensionBehaviour2); 
        } else {
          Optimizer.checkMatchParent(this, paramLinearSystem, constraintWidget);
          if (!constraintWidget.addFirst())
            constraintWidget.addToSolver(paramLinearSystem, bool1); 
        } 
      } 
    } 
    if (this.mHorizontalChainsSize > 0)
      Chain.applyChainConstraints(this, paramLinearSystem, null, 0); 
    if (this.mVerticalChainsSize > 0)
      Chain.applyChainConstraints(this, paramLinearSystem, null, 1); 
    return true;
  }
  
  public void addHorizontalWrapMaxVariable(ConstraintAnchor paramConstraintAnchor) {
    WeakReference<ConstraintAnchor> weakReference = this.horizontalWrapMax;
    if (weakReference == null || weakReference.get() == null || paramConstraintAnchor.getFinalValue() > ((ConstraintAnchor)this.horizontalWrapMax.get()).getFinalValue())
      this.horizontalWrapMax = new WeakReference<ConstraintAnchor>(paramConstraintAnchor); 
  }
  
  public void addHorizontalWrapMinVariable(ConstraintAnchor paramConstraintAnchor) {
    WeakReference<ConstraintAnchor> weakReference = this.horizontalWrapMin;
    if (weakReference == null || weakReference.get() == null || paramConstraintAnchor.getFinalValue() > ((ConstraintAnchor)this.horizontalWrapMin.get()).getFinalValue())
      this.horizontalWrapMin = new WeakReference<ConstraintAnchor>(paramConstraintAnchor); 
  }
  
  void addVerticalWrapMaxVariable(ConstraintAnchor paramConstraintAnchor) {
    WeakReference<ConstraintAnchor> weakReference = this.verticalWrapMax;
    if (weakReference == null || weakReference.get() == null || paramConstraintAnchor.getFinalValue() > ((ConstraintAnchor)this.verticalWrapMax.get()).getFinalValue())
      this.verticalWrapMax = new WeakReference<ConstraintAnchor>(paramConstraintAnchor); 
  }
  
  void addVerticalWrapMinVariable(ConstraintAnchor paramConstraintAnchor) {
    WeakReference<ConstraintAnchor> weakReference = this.verticalWrapMin;
    if (weakReference == null || weakReference.get() == null || paramConstraintAnchor.getFinalValue() > ((ConstraintAnchor)this.verticalWrapMin.get()).getFinalValue())
      this.verticalWrapMin = new WeakReference<ConstraintAnchor>(paramConstraintAnchor); 
  }
  
  public void defineTerminalWidgets() {
    this.mDependencyGraph.defineTerminalWidgets(getHorizontalDimensionBehaviour(), getVerticalDimensionBehaviour());
  }
  
  public boolean directMeasure(boolean paramBoolean) {
    return this.mDependencyGraph.directMeasure(paramBoolean);
  }
  
  public boolean directMeasureSetup(boolean paramBoolean) {
    return this.mDependencyGraph.directMeasureSetup(paramBoolean);
  }
  
  public boolean directMeasureWithOrientation(boolean paramBoolean, int paramInt) {
    return this.mDependencyGraph.directMeasureWithOrientation(paramBoolean, paramInt);
  }
  
  public void fillMetrics(Metrics paramMetrics) {
    this.mMetrics = paramMetrics;
    this.mSystem.fillMetrics(paramMetrics);
  }
  
  public ArrayList<Guideline> getHorizontalGuidelines() {
    ArrayList<Guideline> arrayList = new ArrayList();
    int j = this.mChildren.size();
    for (int i = 0; i < j; i++) {
      ConstraintWidget constraintWidget = this.mChildren.get(i);
      if (constraintWidget instanceof Guideline) {
        Guideline guideline = (Guideline)constraintWidget;
        if (guideline.getOrientation() == 0)
          arrayList.add(guideline); 
      } 
    } 
    return arrayList;
  }
  
  public BasicMeasure.Measurer getMeasurer() {
    return this.mMeasurer;
  }
  
  public int getOptimizationLevel() {
    return this.mOptimizationLevel;
  }
  
  public void getSceneString(StringBuilder paramStringBuilder) {
    StringBuilder stringBuilder = new StringBuilder();
    stringBuilder.append(((ConstraintWidget)this).stringId);
    stringBuilder.append(":{\n");
    paramStringBuilder.append(stringBuilder.toString());
    stringBuilder = new StringBuilder();
    stringBuilder.append("  actualWidth:");
    stringBuilder.append(((ConstraintWidget)this).mWidth);
    paramStringBuilder.append(stringBuilder.toString());
    paramStringBuilder.append("\n");
    stringBuilder = new StringBuilder();
    stringBuilder.append("  actualHeight:");
    stringBuilder.append(((ConstraintWidget)this).mHeight);
    paramStringBuilder.append(stringBuilder.toString());
    paramStringBuilder.append("\n");
    Iterator<ConstraintWidget> iterator = getChildren().iterator();
    while (iterator.hasNext()) {
      ((ConstraintWidget)iterator.next()).getSceneString(paramStringBuilder);
      paramStringBuilder.append(",\n");
    } 
    paramStringBuilder.append("}");
  }
  
  public LinearSystem getSystem() {
    return this.mSystem;
  }
  
  public String getType() {
    return "ConstraintLayout";
  }
  
  public ArrayList<Guideline> getVerticalGuidelines() {
    ArrayList<Guideline> arrayList = new ArrayList();
    int j = this.mChildren.size();
    for (int i = 0; i < j; i++) {
      ConstraintWidget constraintWidget = this.mChildren.get(i);
      if (constraintWidget instanceof Guideline) {
        Guideline guideline = (Guideline)constraintWidget;
        if (guideline.getOrientation() == 1)
          arrayList.add(guideline); 
      } 
    } 
    return arrayList;
  }
  
  public boolean handlesInternalConstraints() {
    return false;
  }
  
  public void invalidateGraph() {
    this.mDependencyGraph.invalidateGraph();
  }
  
  public void invalidateMeasures() {
    this.mDependencyGraph.invalidateMeasures();
  }
  
  public boolean isHeightMeasuredTooSmall() {
    return this.mHeightMeasuredTooSmall;
  }
  
  public boolean isRtl() {
    return this.mIsRtl;
  }
  
  public boolean isWidthMeasuredTooSmall() {
    return this.mWidthMeasuredTooSmall;
  }
  
  public void layout() {
    // Byte code:
    //   0: aload_0
    //   1: iconst_0
    //   2: putfield mX : I
    //   5: aload_0
    //   6: iconst_0
    //   7: putfield mY : I
    //   10: aload_0
    //   11: iconst_0
    //   12: putfield mWidthMeasuredTooSmall : Z
    //   15: aload_0
    //   16: iconst_0
    //   17: putfield mHeightMeasuredTooSmall : Z
    //   20: aload_0
    //   21: getfield mChildren : Ljava/util/ArrayList;
    //   24: invokevirtual size : ()I
    //   27: istore #9
    //   29: iconst_0
    //   30: aload_0
    //   31: invokevirtual getWidth : ()I
    //   34: invokestatic max : (II)I
    //   37: istore_2
    //   38: iconst_0
    //   39: aload_0
    //   40: invokevirtual getHeight : ()I
    //   43: invokestatic max : (II)I
    //   46: istore_3
    //   47: aload_0
    //   48: getfield mListDimensionBehaviors : [Landroidx/constraintlayout/core/widgets/ConstraintWidget$DimensionBehaviour;
    //   51: astore #15
    //   53: aload #15
    //   55: iconst_1
    //   56: aaload
    //   57: astore #14
    //   59: aload #15
    //   61: iconst_0
    //   62: aaload
    //   63: astore #15
    //   65: aload_0
    //   66: getfield mMetrics : Landroidx/constraintlayout/core/Metrics;
    //   69: astore #16
    //   71: aload #16
    //   73: ifnull -> 88
    //   76: aload #16
    //   78: aload #16
    //   80: getfield layouts : J
    //   83: lconst_1
    //   84: ladd
    //   85: putfield layouts : J
    //   88: aload_0
    //   89: getfield pass : I
    //   92: ifne -> 274
    //   95: aload_0
    //   96: getfield mOptimizationLevel : I
    //   99: iconst_1
    //   100: invokestatic enabled : (II)Z
    //   103: ifeq -> 274
    //   106: aload_0
    //   107: aload_0
    //   108: invokevirtual getMeasurer : ()Landroidx/constraintlayout/core/widgets/analyzer/BasicMeasure$Measurer;
    //   111: invokestatic solvingPass : (Landroidx/constraintlayout/core/widgets/ConstraintWidgetContainer;Landroidx/constraintlayout/core/widgets/analyzer/BasicMeasure$Measurer;)V
    //   114: iconst_0
    //   115: istore_1
    //   116: iload_1
    //   117: iload #9
    //   119: if_icmpge -> 274
    //   122: aload_0
    //   123: getfield mChildren : Ljava/util/ArrayList;
    //   126: iload_1
    //   127: invokevirtual get : (I)Ljava/lang/Object;
    //   130: checkcast androidx/constraintlayout/core/widgets/ConstraintWidget
    //   133: astore #16
    //   135: aload #16
    //   137: invokevirtual isMeasureRequested : ()Z
    //   140: ifeq -> 267
    //   143: aload #16
    //   145: instanceof androidx/constraintlayout/core/widgets/Guideline
    //   148: ifne -> 267
    //   151: aload #16
    //   153: instanceof androidx/constraintlayout/core/widgets/Barrier
    //   156: ifne -> 267
    //   159: aload #16
    //   161: instanceof androidx/constraintlayout/core/widgets/VirtualLayout
    //   164: ifne -> 267
    //   167: aload #16
    //   169: invokevirtual isInVirtualLayout : ()Z
    //   172: ifne -> 267
    //   175: aload #16
    //   177: iconst_0
    //   178: invokevirtual getDimensionBehaviour : (I)Landroidx/constraintlayout/core/widgets/ConstraintWidget$DimensionBehaviour;
    //   181: astore #17
    //   183: aload #16
    //   185: iconst_1
    //   186: invokevirtual getDimensionBehaviour : (I)Landroidx/constraintlayout/core/widgets/ConstraintWidget$DimensionBehaviour;
    //   189: astore #18
    //   191: getstatic androidx/constraintlayout/core/widgets/ConstraintWidget$DimensionBehaviour.MATCH_CONSTRAINT : Landroidx/constraintlayout/core/widgets/ConstraintWidget$DimensionBehaviour;
    //   194: astore #19
    //   196: aload #17
    //   198: aload #19
    //   200: if_acmpne -> 234
    //   203: aload #16
    //   205: getfield mMatchConstraintDefaultWidth : I
    //   208: iconst_1
    //   209: if_icmpeq -> 234
    //   212: aload #18
    //   214: aload #19
    //   216: if_acmpne -> 234
    //   219: aload #16
    //   221: getfield mMatchConstraintDefaultHeight : I
    //   224: iconst_1
    //   225: if_icmpeq -> 234
    //   228: iconst_1
    //   229: istore #4
    //   231: goto -> 237
    //   234: iconst_0
    //   235: istore #4
    //   237: iload #4
    //   239: ifne -> 267
    //   242: new androidx/constraintlayout/core/widgets/analyzer/BasicMeasure$Measure
    //   245: dup
    //   246: invokespecial <init> : ()V
    //   249: astore #17
    //   251: iconst_0
    //   252: aload #16
    //   254: aload_0
    //   255: getfield mMeasurer : Landroidx/constraintlayout/core/widgets/analyzer/BasicMeasure$Measurer;
    //   258: aload #17
    //   260: getstatic androidx/constraintlayout/core/widgets/analyzer/BasicMeasure$Measure.SELF_DIMENSIONS : I
    //   263: invokestatic measure : (ILandroidx/constraintlayout/core/widgets/ConstraintWidget;Landroidx/constraintlayout/core/widgets/analyzer/BasicMeasure$Measurer;Landroidx/constraintlayout/core/widgets/analyzer/BasicMeasure$Measure;I)Z
    //   266: pop
    //   267: iload_1
    //   268: iconst_1
    //   269: iadd
    //   270: istore_1
    //   271: goto -> 116
    //   274: iload #9
    //   276: iconst_2
    //   277: if_icmple -> 416
    //   280: getstatic androidx/constraintlayout/core/widgets/ConstraintWidget$DimensionBehaviour.WRAP_CONTENT : Landroidx/constraintlayout/core/widgets/ConstraintWidget$DimensionBehaviour;
    //   283: astore #16
    //   285: aload #15
    //   287: aload #16
    //   289: if_acmpeq -> 299
    //   292: aload #14
    //   294: aload #16
    //   296: if_acmpne -> 416
    //   299: aload_0
    //   300: getfield mOptimizationLevel : I
    //   303: sipush #1024
    //   306: invokestatic enabled : (II)Z
    //   309: ifeq -> 416
    //   312: aload_0
    //   313: aload_0
    //   314: invokevirtual getMeasurer : ()Landroidx/constraintlayout/core/widgets/analyzer/BasicMeasure$Measurer;
    //   317: invokestatic simpleSolvingPass : (Landroidx/constraintlayout/core/widgets/ConstraintWidgetContainer;Landroidx/constraintlayout/core/widgets/analyzer/BasicMeasure$Measurer;)Z
    //   320: ifeq -> 416
    //   323: iload_2
    //   324: istore_1
    //   325: aload #15
    //   327: aload #16
    //   329: if_acmpne -> 364
    //   332: iload_2
    //   333: aload_0
    //   334: invokevirtual getWidth : ()I
    //   337: if_icmpge -> 359
    //   340: iload_2
    //   341: ifle -> 359
    //   344: aload_0
    //   345: iload_2
    //   346: invokevirtual setWidth : (I)V
    //   349: aload_0
    //   350: iconst_1
    //   351: putfield mWidthMeasuredTooSmall : Z
    //   354: iload_2
    //   355: istore_1
    //   356: goto -> 364
    //   359: aload_0
    //   360: invokevirtual getWidth : ()I
    //   363: istore_1
    //   364: iload_3
    //   365: istore_2
    //   366: aload #14
    //   368: aload #16
    //   370: if_acmpne -> 405
    //   373: iload_3
    //   374: aload_0
    //   375: invokevirtual getHeight : ()I
    //   378: if_icmpge -> 400
    //   381: iload_3
    //   382: ifle -> 400
    //   385: aload_0
    //   386: iload_3
    //   387: invokevirtual setHeight : (I)V
    //   390: aload_0
    //   391: iconst_1
    //   392: putfield mHeightMeasuredTooSmall : Z
    //   395: iload_3
    //   396: istore_2
    //   397: goto -> 405
    //   400: aload_0
    //   401: invokevirtual getHeight : ()I
    //   404: istore_2
    //   405: iload_1
    //   406: istore #4
    //   408: iconst_1
    //   409: istore_1
    //   410: iload_2
    //   411: istore #5
    //   413: goto -> 424
    //   416: iconst_0
    //   417: istore_1
    //   418: iload_3
    //   419: istore #5
    //   421: iload_2
    //   422: istore #4
    //   424: aload_0
    //   425: bipush #64
    //   427: invokevirtual optimizeFor : (I)Z
    //   430: ifne -> 451
    //   433: aload_0
    //   434: sipush #128
    //   437: invokevirtual optimizeFor : (I)Z
    //   440: ifeq -> 446
    //   443: goto -> 451
    //   446: iconst_0
    //   447: istore_2
    //   448: goto -> 453
    //   451: iconst_1
    //   452: istore_2
    //   453: aload_0
    //   454: getfield mSystem : Landroidx/constraintlayout/core/LinearSystem;
    //   457: astore #16
    //   459: aload #16
    //   461: iconst_0
    //   462: putfield graphOptimizer : Z
    //   465: aload #16
    //   467: iconst_0
    //   468: putfield newgraphOptimizer : Z
    //   471: aload_0
    //   472: getfield mOptimizationLevel : I
    //   475: ifeq -> 488
    //   478: iload_2
    //   479: ifeq -> 488
    //   482: aload #16
    //   484: iconst_1
    //   485: putfield newgraphOptimizer : Z
    //   488: aload_0
    //   489: getfield mChildren : Ljava/util/ArrayList;
    //   492: astore #16
    //   494: aload_0
    //   495: invokevirtual getHorizontalDimensionBehaviour : ()Landroidx/constraintlayout/core/widgets/ConstraintWidget$DimensionBehaviour;
    //   498: astore #17
    //   500: getstatic androidx/constraintlayout/core/widgets/ConstraintWidget$DimensionBehaviour.WRAP_CONTENT : Landroidx/constraintlayout/core/widgets/ConstraintWidget$DimensionBehaviour;
    //   503: astore #18
    //   505: aload #17
    //   507: aload #18
    //   509: if_acmpeq -> 530
    //   512: aload_0
    //   513: invokevirtual getVerticalDimensionBehaviour : ()Landroidx/constraintlayout/core/widgets/ConstraintWidget$DimensionBehaviour;
    //   516: aload #18
    //   518: if_acmpne -> 524
    //   521: goto -> 530
    //   524: iconst_0
    //   525: istore #6
    //   527: goto -> 533
    //   530: iconst_1
    //   531: istore #6
    //   533: aload_0
    //   534: invokespecial resetChains : ()V
    //   537: iconst_0
    //   538: istore_2
    //   539: iload_2
    //   540: iload #9
    //   542: if_icmpge -> 581
    //   545: aload_0
    //   546: getfield mChildren : Ljava/util/ArrayList;
    //   549: iload_2
    //   550: invokevirtual get : (I)Ljava/lang/Object;
    //   553: checkcast androidx/constraintlayout/core/widgets/ConstraintWidget
    //   556: astore #17
    //   558: aload #17
    //   560: instanceof androidx/constraintlayout/core/widgets/WidgetContainer
    //   563: ifeq -> 574
    //   566: aload #17
    //   568: checkcast androidx/constraintlayout/core/widgets/WidgetContainer
    //   571: invokevirtual layout : ()V
    //   574: iload_2
    //   575: iconst_1
    //   576: iadd
    //   577: istore_2
    //   578: goto -> 539
    //   581: aload_0
    //   582: bipush #64
    //   584: invokevirtual optimizeFor : (I)Z
    //   587: istore #13
    //   589: iconst_0
    //   590: istore_2
    //   591: iconst_1
    //   592: istore #11
    //   594: iload #11
    //   596: ifeq -> 1565
    //   599: iload_2
    //   600: iconst_1
    //   601: iadd
    //   602: istore #8
    //   604: iload #11
    //   606: istore #10
    //   608: aload_0
    //   609: getfield mSystem : Landroidx/constraintlayout/core/LinearSystem;
    //   612: invokevirtual reset : ()V
    //   615: iload #11
    //   617: istore #10
    //   619: aload_0
    //   620: invokespecial resetChains : ()V
    //   623: iload #11
    //   625: istore #10
    //   627: aload_0
    //   628: aload_0
    //   629: getfield mSystem : Landroidx/constraintlayout/core/LinearSystem;
    //   632: invokevirtual createObjectVariables : (Landroidx/constraintlayout/core/LinearSystem;)V
    //   635: iconst_0
    //   636: istore_2
    //   637: iload_2
    //   638: iload #9
    //   640: if_icmpge -> 672
    //   643: iload #11
    //   645: istore #10
    //   647: aload_0
    //   648: getfield mChildren : Ljava/util/ArrayList;
    //   651: iload_2
    //   652: invokevirtual get : (I)Ljava/lang/Object;
    //   655: checkcast androidx/constraintlayout/core/widgets/ConstraintWidget
    //   658: aload_0
    //   659: getfield mSystem : Landroidx/constraintlayout/core/LinearSystem;
    //   662: invokevirtual createObjectVariables : (Landroidx/constraintlayout/core/LinearSystem;)V
    //   665: iload_2
    //   666: iconst_1
    //   667: iadd
    //   668: istore_2
    //   669: goto -> 637
    //   672: iload #11
    //   674: istore #10
    //   676: aload_0
    //   677: aload_0
    //   678: getfield mSystem : Landroidx/constraintlayout/core/LinearSystem;
    //   681: invokevirtual addChildrenToSolver : (Landroidx/constraintlayout/core/LinearSystem;)Z
    //   684: istore #11
    //   686: iload #11
    //   688: istore #10
    //   690: aload_0
    //   691: getfield verticalWrapMin : Ljava/lang/ref/WeakReference;
    //   694: astore #17
    //   696: aload #17
    //   698: ifnull -> 751
    //   701: iload #11
    //   703: istore #10
    //   705: aload #17
    //   707: invokevirtual get : ()Ljava/lang/Object;
    //   710: ifnull -> 751
    //   713: iload #11
    //   715: istore #10
    //   717: aload_0
    //   718: aload_0
    //   719: getfield verticalWrapMin : Ljava/lang/ref/WeakReference;
    //   722: invokevirtual get : ()Ljava/lang/Object;
    //   725: checkcast androidx/constraintlayout/core/widgets/ConstraintAnchor
    //   728: aload_0
    //   729: getfield mSystem : Landroidx/constraintlayout/core/LinearSystem;
    //   732: aload_0
    //   733: getfield mTop : Landroidx/constraintlayout/core/widgets/ConstraintAnchor;
    //   736: invokevirtual createObjectVariable : (Ljava/lang/Object;)Landroidx/constraintlayout/core/SolverVariable;
    //   739: invokespecial addMinWrap : (Landroidx/constraintlayout/core/widgets/ConstraintAnchor;Landroidx/constraintlayout/core/SolverVariable;)V
    //   742: iload #11
    //   744: istore #10
    //   746: aload_0
    //   747: aconst_null
    //   748: putfield verticalWrapMin : Ljava/lang/ref/WeakReference;
    //   751: iload #11
    //   753: istore #10
    //   755: aload_0
    //   756: getfield verticalWrapMax : Ljava/lang/ref/WeakReference;
    //   759: astore #17
    //   761: aload #17
    //   763: ifnull -> 816
    //   766: iload #11
    //   768: istore #10
    //   770: aload #17
    //   772: invokevirtual get : ()Ljava/lang/Object;
    //   775: ifnull -> 816
    //   778: iload #11
    //   780: istore #10
    //   782: aload_0
    //   783: aload_0
    //   784: getfield verticalWrapMax : Ljava/lang/ref/WeakReference;
    //   787: invokevirtual get : ()Ljava/lang/Object;
    //   790: checkcast androidx/constraintlayout/core/widgets/ConstraintAnchor
    //   793: aload_0
    //   794: getfield mSystem : Landroidx/constraintlayout/core/LinearSystem;
    //   797: aload_0
    //   798: getfield mBottom : Landroidx/constraintlayout/core/widgets/ConstraintAnchor;
    //   801: invokevirtual createObjectVariable : (Ljava/lang/Object;)Landroidx/constraintlayout/core/SolverVariable;
    //   804: invokespecial addMaxWrap : (Landroidx/constraintlayout/core/widgets/ConstraintAnchor;Landroidx/constraintlayout/core/SolverVariable;)V
    //   807: iload #11
    //   809: istore #10
    //   811: aload_0
    //   812: aconst_null
    //   813: putfield verticalWrapMax : Ljava/lang/ref/WeakReference;
    //   816: iload #11
    //   818: istore #10
    //   820: aload_0
    //   821: getfield horizontalWrapMin : Ljava/lang/ref/WeakReference;
    //   824: astore #17
    //   826: aload #17
    //   828: ifnull -> 881
    //   831: iload #11
    //   833: istore #10
    //   835: aload #17
    //   837: invokevirtual get : ()Ljava/lang/Object;
    //   840: ifnull -> 881
    //   843: iload #11
    //   845: istore #10
    //   847: aload_0
    //   848: aload_0
    //   849: getfield horizontalWrapMin : Ljava/lang/ref/WeakReference;
    //   852: invokevirtual get : ()Ljava/lang/Object;
    //   855: checkcast androidx/constraintlayout/core/widgets/ConstraintAnchor
    //   858: aload_0
    //   859: getfield mSystem : Landroidx/constraintlayout/core/LinearSystem;
    //   862: aload_0
    //   863: getfield mLeft : Landroidx/constraintlayout/core/widgets/ConstraintAnchor;
    //   866: invokevirtual createObjectVariable : (Ljava/lang/Object;)Landroidx/constraintlayout/core/SolverVariable;
    //   869: invokespecial addMinWrap : (Landroidx/constraintlayout/core/widgets/ConstraintAnchor;Landroidx/constraintlayout/core/SolverVariable;)V
    //   872: iload #11
    //   874: istore #10
    //   876: aload_0
    //   877: aconst_null
    //   878: putfield horizontalWrapMin : Ljava/lang/ref/WeakReference;
    //   881: iload #11
    //   883: istore #10
    //   885: aload_0
    //   886: getfield horizontalWrapMax : Ljava/lang/ref/WeakReference;
    //   889: astore #17
    //   891: aload #17
    //   893: ifnull -> 946
    //   896: iload #11
    //   898: istore #10
    //   900: aload #17
    //   902: invokevirtual get : ()Ljava/lang/Object;
    //   905: ifnull -> 946
    //   908: iload #11
    //   910: istore #10
    //   912: aload_0
    //   913: aload_0
    //   914: getfield horizontalWrapMax : Ljava/lang/ref/WeakReference;
    //   917: invokevirtual get : ()Ljava/lang/Object;
    //   920: checkcast androidx/constraintlayout/core/widgets/ConstraintAnchor
    //   923: aload_0
    //   924: getfield mSystem : Landroidx/constraintlayout/core/LinearSystem;
    //   927: aload_0
    //   928: getfield mRight : Landroidx/constraintlayout/core/widgets/ConstraintAnchor;
    //   931: invokevirtual createObjectVariable : (Ljava/lang/Object;)Landroidx/constraintlayout/core/SolverVariable;
    //   934: invokespecial addMaxWrap : (Landroidx/constraintlayout/core/widgets/ConstraintAnchor;Landroidx/constraintlayout/core/SolverVariable;)V
    //   937: iload #11
    //   939: istore #10
    //   941: aload_0
    //   942: aconst_null
    //   943: putfield horizontalWrapMax : Ljava/lang/ref/WeakReference;
    //   946: iload #11
    //   948: istore #10
    //   950: iload #11
    //   952: ifeq -> 1021
    //   955: iload #11
    //   957: istore #10
    //   959: aload_0
    //   960: getfield mSystem : Landroidx/constraintlayout/core/LinearSystem;
    //   963: invokevirtual minimize : ()V
    //   966: iload #11
    //   968: istore #10
    //   970: goto -> 1021
    //   973: astore #17
    //   975: aload #17
    //   977: invokevirtual printStackTrace : ()V
    //   980: getstatic java/lang/System.out : Ljava/io/PrintStream;
    //   983: astore #18
    //   985: new java/lang/StringBuilder
    //   988: dup
    //   989: invokespecial <init> : ()V
    //   992: astore #19
    //   994: aload #19
    //   996: ldc_w 'EXCEPTION : '
    //   999: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   1002: pop
    //   1003: aload #19
    //   1005: aload #17
    //   1007: invokevirtual append : (Ljava/lang/Object;)Ljava/lang/StringBuilder;
    //   1010: pop
    //   1011: aload #18
    //   1013: aload #19
    //   1015: invokevirtual toString : ()Ljava/lang/String;
    //   1018: invokevirtual println : (Ljava/lang/String;)V
    //   1021: iload #10
    //   1023: ifeq -> 1042
    //   1026: aload_0
    //   1027: aload_0
    //   1028: getfield mSystem : Landroidx/constraintlayout/core/LinearSystem;
    //   1031: getstatic androidx/constraintlayout/core/widgets/Optimizer.flags : [Z
    //   1034: invokevirtual updateChildrenFromSolver : (Landroidx/constraintlayout/core/LinearSystem;[Z)Z
    //   1037: istore #10
    //   1039: goto -> 1090
    //   1042: aload_0
    //   1043: aload_0
    //   1044: getfield mSystem : Landroidx/constraintlayout/core/LinearSystem;
    //   1047: iload #13
    //   1049: invokevirtual updateFromSolver : (Landroidx/constraintlayout/core/LinearSystem;Z)V
    //   1052: iconst_0
    //   1053: istore_2
    //   1054: iload_2
    //   1055: iload #9
    //   1057: if_icmpge -> 1087
    //   1060: aload_0
    //   1061: getfield mChildren : Ljava/util/ArrayList;
    //   1064: iload_2
    //   1065: invokevirtual get : (I)Ljava/lang/Object;
    //   1068: checkcast androidx/constraintlayout/core/widgets/ConstraintWidget
    //   1071: aload_0
    //   1072: getfield mSystem : Landroidx/constraintlayout/core/LinearSystem;
    //   1075: iload #13
    //   1077: invokevirtual updateFromSolver : (Landroidx/constraintlayout/core/LinearSystem;Z)V
    //   1080: iload_2
    //   1081: iconst_1
    //   1082: iadd
    //   1083: istore_2
    //   1084: goto -> 1054
    //   1087: iconst_0
    //   1088: istore #10
    //   1090: iload #6
    //   1092: ifeq -> 1297
    //   1095: iload #8
    //   1097: bipush #8
    //   1099: if_icmpge -> 1297
    //   1102: getstatic androidx/constraintlayout/core/widgets/Optimizer.flags : [Z
    //   1105: iconst_2
    //   1106: baload
    //   1107: ifeq -> 1297
    //   1110: iconst_0
    //   1111: istore_3
    //   1112: iconst_0
    //   1113: istore_2
    //   1114: iconst_0
    //   1115: istore #7
    //   1117: iload_3
    //   1118: iload #9
    //   1120: if_icmpge -> 1177
    //   1123: aload_0
    //   1124: getfield mChildren : Ljava/util/ArrayList;
    //   1127: iload_3
    //   1128: invokevirtual get : (I)Ljava/lang/Object;
    //   1131: checkcast androidx/constraintlayout/core/widgets/ConstraintWidget
    //   1134: astore #17
    //   1136: iload #7
    //   1138: aload #17
    //   1140: getfield mX : I
    //   1143: aload #17
    //   1145: invokevirtual getWidth : ()I
    //   1148: iadd
    //   1149: invokestatic max : (II)I
    //   1152: istore #7
    //   1154: iload_2
    //   1155: aload #17
    //   1157: getfield mY : I
    //   1160: aload #17
    //   1162: invokevirtual getHeight : ()I
    //   1165: iadd
    //   1166: invokestatic max : (II)I
    //   1169: istore_2
    //   1170: iload_3
    //   1171: iconst_1
    //   1172: iadd
    //   1173: istore_3
    //   1174: goto -> 1117
    //   1177: aload_0
    //   1178: getfield mMinWidth : I
    //   1181: iload #7
    //   1183: invokestatic max : (II)I
    //   1186: istore #7
    //   1188: aload_0
    //   1189: getfield mMinHeight : I
    //   1192: iload_2
    //   1193: invokestatic max : (II)I
    //   1196: istore_3
    //   1197: getstatic androidx/constraintlayout/core/widgets/ConstraintWidget$DimensionBehaviour.WRAP_CONTENT : Landroidx/constraintlayout/core/widgets/ConstraintWidget$DimensionBehaviour;
    //   1200: astore #17
    //   1202: iload_1
    //   1203: istore_2
    //   1204: iload #10
    //   1206: istore #11
    //   1208: aload #15
    //   1210: aload #17
    //   1212: if_acmpne -> 1249
    //   1215: iload_1
    //   1216: istore_2
    //   1217: iload #10
    //   1219: istore #11
    //   1221: aload_0
    //   1222: invokevirtual getWidth : ()I
    //   1225: iload #7
    //   1227: if_icmpge -> 1249
    //   1230: aload_0
    //   1231: iload #7
    //   1233: invokevirtual setWidth : (I)V
    //   1236: aload_0
    //   1237: getfield mListDimensionBehaviors : [Landroidx/constraintlayout/core/widgets/ConstraintWidget$DimensionBehaviour;
    //   1240: iconst_0
    //   1241: aload #17
    //   1243: aastore
    //   1244: iconst_1
    //   1245: istore_2
    //   1246: iconst_1
    //   1247: istore #11
    //   1249: iload_2
    //   1250: istore_1
    //   1251: iload #11
    //   1253: istore #10
    //   1255: aload #14
    //   1257: aload #17
    //   1259: if_acmpne -> 1297
    //   1262: iload_2
    //   1263: istore_1
    //   1264: iload #11
    //   1266: istore #10
    //   1268: aload_0
    //   1269: invokevirtual getHeight : ()I
    //   1272: iload_3
    //   1273: if_icmpge -> 1297
    //   1276: aload_0
    //   1277: iload_3
    //   1278: invokevirtual setHeight : (I)V
    //   1281: aload_0
    //   1282: getfield mListDimensionBehaviors : [Landroidx/constraintlayout/core/widgets/ConstraintWidget$DimensionBehaviour;
    //   1285: iconst_1
    //   1286: aload #17
    //   1288: aastore
    //   1289: iconst_1
    //   1290: istore_1
    //   1291: iconst_1
    //   1292: istore #10
    //   1294: goto -> 1297
    //   1297: aload_0
    //   1298: getfield mMinWidth : I
    //   1301: aload_0
    //   1302: invokevirtual getWidth : ()I
    //   1305: invokestatic max : (II)I
    //   1308: istore_2
    //   1309: iload_2
    //   1310: aload_0
    //   1311: invokevirtual getWidth : ()I
    //   1314: if_icmple -> 1336
    //   1317: aload_0
    //   1318: iload_2
    //   1319: invokevirtual setWidth : (I)V
    //   1322: aload_0
    //   1323: getfield mListDimensionBehaviors : [Landroidx/constraintlayout/core/widgets/ConstraintWidget$DimensionBehaviour;
    //   1326: iconst_0
    //   1327: getstatic androidx/constraintlayout/core/widgets/ConstraintWidget$DimensionBehaviour.FIXED : Landroidx/constraintlayout/core/widgets/ConstraintWidget$DimensionBehaviour;
    //   1330: aastore
    //   1331: iconst_1
    //   1332: istore_1
    //   1333: iconst_1
    //   1334: istore #10
    //   1336: aload_0
    //   1337: getfield mMinHeight : I
    //   1340: aload_0
    //   1341: invokevirtual getHeight : ()I
    //   1344: invokestatic max : (II)I
    //   1347: istore_2
    //   1348: iload_2
    //   1349: aload_0
    //   1350: invokevirtual getHeight : ()I
    //   1353: if_icmple -> 1378
    //   1356: aload_0
    //   1357: iload_2
    //   1358: invokevirtual setHeight : (I)V
    //   1361: aload_0
    //   1362: getfield mListDimensionBehaviors : [Landroidx/constraintlayout/core/widgets/ConstraintWidget$DimensionBehaviour;
    //   1365: iconst_1
    //   1366: getstatic androidx/constraintlayout/core/widgets/ConstraintWidget$DimensionBehaviour.FIXED : Landroidx/constraintlayout/core/widgets/ConstraintWidget$DimensionBehaviour;
    //   1369: aastore
    //   1370: iconst_1
    //   1371: istore_1
    //   1372: iconst_1
    //   1373: istore #10
    //   1375: goto -> 1378
    //   1378: iload_1
    //   1379: istore_3
    //   1380: iload #10
    //   1382: istore #12
    //   1384: iload_1
    //   1385: ifne -> 1536
    //   1388: aload_0
    //   1389: getfield mListDimensionBehaviors : [Landroidx/constraintlayout/core/widgets/ConstraintWidget$DimensionBehaviour;
    //   1392: iconst_0
    //   1393: aaload
    //   1394: astore #17
    //   1396: getstatic androidx/constraintlayout/core/widgets/ConstraintWidget$DimensionBehaviour.WRAP_CONTENT : Landroidx/constraintlayout/core/widgets/ConstraintWidget$DimensionBehaviour;
    //   1399: astore #18
    //   1401: iload_1
    //   1402: istore_2
    //   1403: iload #10
    //   1405: istore #11
    //   1407: aload #17
    //   1409: aload #18
    //   1411: if_acmpne -> 1465
    //   1414: iload_1
    //   1415: istore_2
    //   1416: iload #10
    //   1418: istore #11
    //   1420: iload #4
    //   1422: ifle -> 1465
    //   1425: iload_1
    //   1426: istore_2
    //   1427: iload #10
    //   1429: istore #11
    //   1431: aload_0
    //   1432: invokevirtual getWidth : ()I
    //   1435: iload #4
    //   1437: if_icmple -> 1465
    //   1440: aload_0
    //   1441: iconst_1
    //   1442: putfield mWidthMeasuredTooSmall : Z
    //   1445: aload_0
    //   1446: getfield mListDimensionBehaviors : [Landroidx/constraintlayout/core/widgets/ConstraintWidget$DimensionBehaviour;
    //   1449: iconst_0
    //   1450: getstatic androidx/constraintlayout/core/widgets/ConstraintWidget$DimensionBehaviour.FIXED : Landroidx/constraintlayout/core/widgets/ConstraintWidget$DimensionBehaviour;
    //   1453: aastore
    //   1454: aload_0
    //   1455: iload #4
    //   1457: invokevirtual setWidth : (I)V
    //   1460: iconst_1
    //   1461: istore_2
    //   1462: iconst_1
    //   1463: istore #11
    //   1465: iload_2
    //   1466: istore_3
    //   1467: iload #11
    //   1469: istore #12
    //   1471: aload_0
    //   1472: getfield mListDimensionBehaviors : [Landroidx/constraintlayout/core/widgets/ConstraintWidget$DimensionBehaviour;
    //   1475: iconst_1
    //   1476: aaload
    //   1477: aload #18
    //   1479: if_acmpne -> 1536
    //   1482: iload_2
    //   1483: istore_3
    //   1484: iload #11
    //   1486: istore #12
    //   1488: iload #5
    //   1490: ifle -> 1536
    //   1493: iload_2
    //   1494: istore_3
    //   1495: iload #11
    //   1497: istore #12
    //   1499: aload_0
    //   1500: invokevirtual getHeight : ()I
    //   1503: iload #5
    //   1505: if_icmple -> 1536
    //   1508: aload_0
    //   1509: iconst_1
    //   1510: putfield mHeightMeasuredTooSmall : Z
    //   1513: aload_0
    //   1514: getfield mListDimensionBehaviors : [Landroidx/constraintlayout/core/widgets/ConstraintWidget$DimensionBehaviour;
    //   1517: iconst_1
    //   1518: getstatic androidx/constraintlayout/core/widgets/ConstraintWidget$DimensionBehaviour.FIXED : Landroidx/constraintlayout/core/widgets/ConstraintWidget$DimensionBehaviour;
    //   1521: aastore
    //   1522: aload_0
    //   1523: iload #5
    //   1525: invokevirtual setHeight : (I)V
    //   1528: iconst_1
    //   1529: istore #10
    //   1531: iconst_1
    //   1532: istore_1
    //   1533: goto -> 1542
    //   1536: iload_3
    //   1537: istore_1
    //   1538: iload #12
    //   1540: istore #10
    //   1542: iload #8
    //   1544: bipush #8
    //   1546: if_icmple -> 1555
    //   1549: iconst_0
    //   1550: istore #11
    //   1552: goto -> 1559
    //   1555: iload #10
    //   1557: istore #11
    //   1559: iload #8
    //   1561: istore_2
    //   1562: goto -> 594
    //   1565: aload_0
    //   1566: aload #16
    //   1568: putfield mChildren : Ljava/util/ArrayList;
    //   1571: iload_1
    //   1572: ifeq -> 1593
    //   1575: aload_0
    //   1576: getfield mListDimensionBehaviors : [Landroidx/constraintlayout/core/widgets/ConstraintWidget$DimensionBehaviour;
    //   1579: astore #16
    //   1581: aload #16
    //   1583: iconst_0
    //   1584: aload #15
    //   1586: aastore
    //   1587: aload #16
    //   1589: iconst_1
    //   1590: aload #14
    //   1592: aastore
    //   1593: aload_0
    //   1594: aload_0
    //   1595: getfield mSystem : Landroidx/constraintlayout/core/LinearSystem;
    //   1598: invokevirtual getCache : ()Landroidx/constraintlayout/core/Cache;
    //   1601: invokevirtual resetSolverVariables : (Landroidx/constraintlayout/core/Cache;)V
    //   1604: return
    // Exception table:
    //   from	to	target	type
    //   608	615	973	java/lang/Exception
    //   619	623	973	java/lang/Exception
    //   627	635	973	java/lang/Exception
    //   647	665	973	java/lang/Exception
    //   676	686	973	java/lang/Exception
    //   690	696	973	java/lang/Exception
    //   705	713	973	java/lang/Exception
    //   717	742	973	java/lang/Exception
    //   746	751	973	java/lang/Exception
    //   755	761	973	java/lang/Exception
    //   770	778	973	java/lang/Exception
    //   782	807	973	java/lang/Exception
    //   811	816	973	java/lang/Exception
    //   820	826	973	java/lang/Exception
    //   835	843	973	java/lang/Exception
    //   847	872	973	java/lang/Exception
    //   876	881	973	java/lang/Exception
    //   885	891	973	java/lang/Exception
    //   900	908	973	java/lang/Exception
    //   912	937	973	java/lang/Exception
    //   941	946	973	java/lang/Exception
    //   959	966	973	java/lang/Exception
  }
  
  public long measure(int paramInt1, int paramInt2, int paramInt3, int paramInt4, int paramInt5, int paramInt6, int paramInt7, int paramInt8, int paramInt9) {
    this.mPaddingLeft = paramInt8;
    this.mPaddingTop = paramInt9;
    return this.mBasicMeasureSolver.solverMeasure(this, paramInt1, paramInt8, paramInt9, paramInt2, paramInt3, paramInt4, paramInt5, paramInt6, paramInt7);
  }
  
  public boolean optimizeFor(int paramInt) {
    return ((this.mOptimizationLevel & paramInt) == paramInt);
  }
  
  public void reset() {
    this.mSystem.reset();
    this.mPaddingLeft = 0;
    this.mPaddingRight = 0;
    this.mPaddingTop = 0;
    this.mPaddingBottom = 0;
    this.mSkipSolver = false;
    super.reset();
  }
  
  public void setMeasurer(BasicMeasure.Measurer paramMeasurer) {
    this.mMeasurer = paramMeasurer;
    this.mDependencyGraph.setMeasurer(paramMeasurer);
  }
  
  public void setOptimizationLevel(int paramInt) {
    this.mOptimizationLevel = paramInt;
    LinearSystem.USE_DEPENDENCY_ORDERING = optimizeFor(512);
  }
  
  public void setPadding(int paramInt1, int paramInt2, int paramInt3, int paramInt4) {
    this.mPaddingLeft = paramInt1;
    this.mPaddingTop = paramInt2;
    this.mPaddingRight = paramInt3;
    this.mPaddingBottom = paramInt4;
  }
  
  public void setPass(int paramInt) {
    this.pass = paramInt;
  }
  
  public void setRtl(boolean paramBoolean) {
    this.mIsRtl = paramBoolean;
  }
  
  public boolean updateChildrenFromSolver(LinearSystem paramLinearSystem, boolean[] paramArrayOfboolean) {
    int i = 0;
    paramArrayOfboolean[2] = false;
    boolean bool1 = optimizeFor(64);
    updateFromSolver(paramLinearSystem, bool1);
    int j = this.mChildren.size();
    boolean bool = false;
    while (i < j) {
      ConstraintWidget constraintWidget = this.mChildren.get(i);
      constraintWidget.updateFromSolver(paramLinearSystem, bool1);
      if (constraintWidget.hasDimensionOverride())
        bool = true; 
      i++;
    } 
    return bool;
  }
  
  public void updateFromRuns(boolean paramBoolean1, boolean paramBoolean2) {
    super.updateFromRuns(paramBoolean1, paramBoolean2);
    int j = this.mChildren.size();
    for (int i = 0; i < j; i++)
      ((ConstraintWidget)this.mChildren.get(i)).updateFromRuns(paramBoolean1, paramBoolean2); 
  }
  
  public void updateHierarchy() {
    this.mBasicMeasureSolver.updateHierarchy(this);
  }
}


/* Location:              C:\soft\dex2jar-2.0\MagicAI - AI Art & Anime Art-dex2jar.jar!\androidx\constraintlayout\core\widgets\ConstraintWidgetContainer.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */