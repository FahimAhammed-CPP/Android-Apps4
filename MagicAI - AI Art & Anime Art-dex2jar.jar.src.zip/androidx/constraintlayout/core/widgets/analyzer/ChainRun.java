package androidx.constraintlayout.core.widgets.analyzer;

import androidx.constraintlayout.core.widgets.ConstraintAnchor;
import androidx.constraintlayout.core.widgets.ConstraintWidget;
import androidx.constraintlayout.core.widgets.ConstraintWidgetContainer;
import java.util.ArrayList;
import java.util.Iterator;

public class ChainRun extends WidgetRun {
  private int chainStyle;
  
  ArrayList<WidgetRun> widgets = new ArrayList<WidgetRun>();
  
  public ChainRun(ConstraintWidget paramConstraintWidget, int paramInt) {
    super(paramConstraintWidget);
    this.orientation = paramInt;
    build();
  }
  
  private void build() {
    int i;
    ConstraintWidget constraintWidget2 = this.widget;
    ConstraintWidget constraintWidget1;
    for (constraintWidget1 = constraintWidget2.getPreviousChainMember(this.orientation); constraintWidget1 != null; constraintWidget1 = constraintWidget) {
      ConstraintWidget constraintWidget = constraintWidget1.getPreviousChainMember(this.orientation);
      constraintWidget2 = constraintWidget1;
    } 
    this.widget = constraintWidget2;
    this.widgets.add(constraintWidget2.getRun(this.orientation));
    for (constraintWidget1 = constraintWidget2.getNextChainMember(this.orientation); constraintWidget1 != null; constraintWidget1 = constraintWidget1.getNextChainMember(this.orientation))
      this.widgets.add(constraintWidget1.getRun(this.orientation)); 
    for (WidgetRun widgetRun : this.widgets) {
      i = this.orientation;
      if (i == 0) {
        widgetRun.widget.horizontalChainRun = this;
        continue;
      } 
      if (i == 1)
        widgetRun.widget.verticalChainRun = this; 
    } 
    if (this.orientation == 0 && ((ConstraintWidgetContainer)this.widget.getParent()).isRtl()) {
      i = 1;
    } else {
      i = 0;
    } 
    if (i && this.widgets.size() > 1) {
      ArrayList<WidgetRun> arrayList = this.widgets;
      this.widget = ((WidgetRun)arrayList.get(arrayList.size() - 1)).widget;
    } 
    if (this.orientation == 0) {
      i = this.widget.getHorizontalChainStyle();
    } else {
      i = this.widget.getVerticalChainStyle();
    } 
    this.chainStyle = i;
  }
  
  private ConstraintWidget getFirstVisibleWidget() {
    for (int i = 0; i < this.widgets.size(); i++) {
      WidgetRun widgetRun = this.widgets.get(i);
      if (widgetRun.widget.getVisibility() != 8)
        return widgetRun.widget; 
    } 
    return null;
  }
  
  private ConstraintWidget getLastVisibleWidget() {
    for (int i = this.widgets.size() - 1; i >= 0; i--) {
      WidgetRun widgetRun = this.widgets.get(i);
      if (widgetRun.widget.getVisibility() != 8)
        return widgetRun.widget; 
    } 
    return null;
  }
  
  void apply() {
    DependencyNode dependencyNode;
    Iterator<WidgetRun> iterator = this.widgets.iterator();
    while (iterator.hasNext())
      ((WidgetRun)iterator.next()).apply(); 
    int i = this.widgets.size();
    if (i < 1)
      return; 
    ConstraintWidget constraintWidget2 = ((WidgetRun)this.widgets.get(0)).widget;
    ConstraintWidget constraintWidget1 = ((WidgetRun)this.widgets.get(i - 1)).widget;
    if (this.orientation == 0) {
      ConstraintAnchor constraintAnchor2 = constraintWidget2.mLeft;
      ConstraintAnchor constraintAnchor1 = constraintWidget1.mRight;
      DependencyNode dependencyNode1 = getTarget(constraintAnchor2, 0);
      i = constraintAnchor2.getMargin();
      ConstraintWidget constraintWidget = getFirstVisibleWidget();
      if (constraintWidget != null)
        i = constraintWidget.mLeft.getMargin(); 
      if (dependencyNode1 != null)
        addTarget(this.start, dependencyNode1, i); 
      dependencyNode = getTarget(constraintAnchor1, 0);
      i = constraintAnchor1.getMargin();
      constraintWidget1 = getLastVisibleWidget();
      if (constraintWidget1 != null)
        i = constraintWidget1.mRight.getMargin(); 
      if (dependencyNode != null)
        addTarget(this.end, dependencyNode, -i); 
    } else {
      ConstraintAnchor constraintAnchor2 = ((ConstraintWidget)dependencyNode).mTop;
      ConstraintAnchor constraintAnchor1 = constraintWidget1.mBottom;
      DependencyNode dependencyNode2 = getTarget(constraintAnchor2, 1);
      i = constraintAnchor2.getMargin();
      ConstraintWidget constraintWidget4 = getFirstVisibleWidget();
      if (constraintWidget4 != null)
        i = constraintWidget4.mTop.getMargin(); 
      if (dependencyNode2 != null)
        addTarget(this.start, dependencyNode2, i); 
      DependencyNode dependencyNode1 = getTarget(constraintAnchor1, 1);
      i = constraintAnchor1.getMargin();
      ConstraintWidget constraintWidget3 = getLastVisibleWidget();
      if (constraintWidget3 != null)
        i = constraintWidget3.mBottom.getMargin(); 
      if (dependencyNode1 != null)
        addTarget(this.end, dependencyNode1, -i); 
    } 
    this.start.updateDelegate = (Dependency)this;
    this.end.updateDelegate = (Dependency)this;
  }
  
  public void applyToWidget() {
    for (int i = 0; i < this.widgets.size(); i++)
      ((WidgetRun)this.widgets.get(i)).applyToWidget(); 
  }
  
  void clear() {
    this.runGroup = null;
    Iterator<WidgetRun> iterator = this.widgets.iterator();
    while (iterator.hasNext())
      ((WidgetRun)iterator.next()).clear(); 
  }
  
  public long getWrapDimension() {
    int j = this.widgets.size();
    long l = 0L;
    for (int i = 0; i < j; i++) {
      WidgetRun widgetRun = this.widgets.get(i);
      l = l + widgetRun.start.margin + widgetRun.getWrapDimension() + widgetRun.end.margin;
    } 
    return l;
  }
  
  void reset() {
    this.start.resolved = false;
    this.end.resolved = false;
  }
  
  boolean supportsWrapComputation() {
    int j = this.widgets.size();
    for (int i = 0; i < j; i++) {
      if (!((WidgetRun)this.widgets.get(i)).supportsWrapComputation())
        return false; 
    } 
    return true;
  }
  
  public String toString() {
    String str;
    StringBuilder stringBuilder = new StringBuilder("ChainRun ");
    if (this.orientation == 0) {
      str = "horizontal : ";
    } else {
      str = "vertical : ";
    } 
    stringBuilder.append(str);
    for (WidgetRun widgetRun : this.widgets) {
      stringBuilder.append("<");
      stringBuilder.append(widgetRun);
      stringBuilder.append("> ");
    } 
    return stringBuilder.toString();
  }
  
  public void update(Dependency paramDependency) {
    // Byte code:
    //   0: aload_0
    //   1: getfield start : Landroidx/constraintlayout/core/widgets/analyzer/DependencyNode;
    //   4: getfield resolved : Z
    //   7: ifeq -> 2419
    //   10: aload_0
    //   11: getfield end : Landroidx/constraintlayout/core/widgets/analyzer/DependencyNode;
    //   14: getfield resolved : Z
    //   17: ifne -> 21
    //   20: return
    //   21: aload_0
    //   22: getfield widget : Landroidx/constraintlayout/core/widgets/ConstraintWidget;
    //   25: invokevirtual getParent : ()Landroidx/constraintlayout/core/widgets/ConstraintWidget;
    //   28: astore_1
    //   29: aload_1
    //   30: instanceof androidx/constraintlayout/core/widgets/ConstraintWidgetContainer
    //   33: ifeq -> 48
    //   36: aload_1
    //   37: checkcast androidx/constraintlayout/core/widgets/ConstraintWidgetContainer
    //   40: invokevirtual isRtl : ()Z
    //   43: istore #21
    //   45: goto -> 51
    //   48: iconst_0
    //   49: istore #21
    //   51: aload_0
    //   52: getfield end : Landroidx/constraintlayout/core/widgets/analyzer/DependencyNode;
    //   55: getfield value : I
    //   58: aload_0
    //   59: getfield start : Landroidx/constraintlayout/core/widgets/analyzer/DependencyNode;
    //   62: getfield value : I
    //   65: isub
    //   66: istore #20
    //   68: aload_0
    //   69: getfield widgets : Ljava/util/ArrayList;
    //   72: invokevirtual size : ()I
    //   75: istore #19
    //   77: iconst_0
    //   78: istore #5
    //   80: iconst_m1
    //   81: istore #6
    //   83: iload #5
    //   85: iload #19
    //   87: if_icmpge -> 126
    //   90: iload #5
    //   92: istore #14
    //   94: aload_0
    //   95: getfield widgets : Ljava/util/ArrayList;
    //   98: iload #5
    //   100: invokevirtual get : (I)Ljava/lang/Object;
    //   103: checkcast androidx/constraintlayout/core/widgets/analyzer/WidgetRun
    //   106: getfield widget : Landroidx/constraintlayout/core/widgets/ConstraintWidget;
    //   109: invokevirtual getVisibility : ()I
    //   112: bipush #8
    //   114: if_icmpne -> 129
    //   117: iload #5
    //   119: iconst_1
    //   120: iadd
    //   121: istore #5
    //   123: goto -> 80
    //   126: iconst_m1
    //   127: istore #14
    //   129: iload #19
    //   131: iconst_1
    //   132: isub
    //   133: istore #18
    //   135: iload #18
    //   137: istore #5
    //   139: iload #6
    //   141: istore #15
    //   143: iload #5
    //   145: iflt -> 184
    //   148: aload_0
    //   149: getfield widgets : Ljava/util/ArrayList;
    //   152: iload #5
    //   154: invokevirtual get : (I)Ljava/lang/Object;
    //   157: checkcast androidx/constraintlayout/core/widgets/analyzer/WidgetRun
    //   160: getfield widget : Landroidx/constraintlayout/core/widgets/ConstraintWidget;
    //   163: invokevirtual getVisibility : ()I
    //   166: bipush #8
    //   168: if_icmpne -> 180
    //   171: iload #5
    //   173: iconst_1
    //   174: isub
    //   175: istore #5
    //   177: goto -> 139
    //   180: iload #5
    //   182: istore #15
    //   184: iconst_0
    //   185: istore #9
    //   187: iload #9
    //   189: iconst_2
    //   190: if_icmpge -> 610
    //   193: iconst_0
    //   194: istore #10
    //   196: iconst_0
    //   197: istore #8
    //   199: iconst_0
    //   200: istore #5
    //   202: iconst_0
    //   203: istore #6
    //   205: fconst_0
    //   206: fstore_2
    //   207: iload #10
    //   209: iload #19
    //   211: if_icmpge -> 575
    //   214: aload_0
    //   215: getfield widgets : Ljava/util/ArrayList;
    //   218: iload #10
    //   220: invokevirtual get : (I)Ljava/lang/Object;
    //   223: checkcast androidx/constraintlayout/core/widgets/analyzer/WidgetRun
    //   226: astore_1
    //   227: aload_1
    //   228: getfield widget : Landroidx/constraintlayout/core/widgets/ConstraintWidget;
    //   231: invokevirtual getVisibility : ()I
    //   234: bipush #8
    //   236: if_icmpne -> 246
    //   239: iload #5
    //   241: istore #11
    //   243: goto -> 562
    //   246: iload #6
    //   248: iconst_1
    //   249: iadd
    //   250: istore #12
    //   252: iload #8
    //   254: istore #6
    //   256: iload #10
    //   258: ifle -> 284
    //   261: iload #8
    //   263: istore #6
    //   265: iload #10
    //   267: iload #14
    //   269: if_icmplt -> 284
    //   272: iload #8
    //   274: aload_1
    //   275: getfield start : Landroidx/constraintlayout/core/widgets/analyzer/DependencyNode;
    //   278: getfield margin : I
    //   281: iadd
    //   282: istore #6
    //   284: aload_1
    //   285: getfield dimension : Landroidx/constraintlayout/core/widgets/analyzer/DimensionDependency;
    //   288: astore #22
    //   290: aload #22
    //   292: getfield value : I
    //   295: istore #8
    //   297: aload_1
    //   298: getfield dimensionBehavior : Landroidx/constraintlayout/core/widgets/ConstraintWidget$DimensionBehaviour;
    //   301: getstatic androidx/constraintlayout/core/widgets/ConstraintWidget$DimensionBehaviour.MATCH_CONSTRAINT : Landroidx/constraintlayout/core/widgets/ConstraintWidget$DimensionBehaviour;
    //   304: if_acmpeq -> 313
    //   307: iconst_1
    //   308: istore #7
    //   310: goto -> 316
    //   313: iconst_0
    //   314: istore #7
    //   316: iload #7
    //   318: ifeq -> 375
    //   321: aload_0
    //   322: getfield orientation : I
    //   325: istore #11
    //   327: iload #11
    //   329: ifne -> 349
    //   332: aload_1
    //   333: getfield widget : Landroidx/constraintlayout/core/widgets/ConstraintWidget;
    //   336: getfield horizontalRun : Landroidx/constraintlayout/core/widgets/analyzer/HorizontalWidgetRun;
    //   339: getfield dimension : Landroidx/constraintlayout/core/widgets/analyzer/DimensionDependency;
    //   342: getfield resolved : Z
    //   345: ifne -> 349
    //   348: return
    //   349: iload #11
    //   351: iconst_1
    //   352: if_icmpne -> 372
    //   355: aload_1
    //   356: getfield widget : Landroidx/constraintlayout/core/widgets/ConstraintWidget;
    //   359: getfield verticalRun : Landroidx/constraintlayout/core/widgets/analyzer/VerticalWidgetRun;
    //   362: getfield dimension : Landroidx/constraintlayout/core/widgets/analyzer/DimensionDependency;
    //   365: getfield resolved : Z
    //   368: ifne -> 372
    //   371: return
    //   372: goto -> 422
    //   375: aload_1
    //   376: getfield matchConstraintsType : I
    //   379: iconst_1
    //   380: if_icmpne -> 404
    //   383: iload #9
    //   385: ifne -> 404
    //   388: aload #22
    //   390: getfield wrapValue : I
    //   393: istore #7
    //   395: iload #5
    //   397: iconst_1
    //   398: iadd
    //   399: istore #5
    //   401: goto -> 416
    //   404: aload #22
    //   406: getfield resolved : Z
    //   409: ifeq -> 422
    //   412: iload #8
    //   414: istore #7
    //   416: iconst_1
    //   417: istore #11
    //   419: goto -> 430
    //   422: iload #7
    //   424: istore #11
    //   426: iload #8
    //   428: istore #7
    //   430: iload #11
    //   432: ifne -> 488
    //   435: iload #5
    //   437: iconst_1
    //   438: iadd
    //   439: istore #8
    //   441: aload_1
    //   442: getfield widget : Landroidx/constraintlayout/core/widgets/ConstraintWidget;
    //   445: getfield mWeight : [F
    //   448: aload_0
    //   449: getfield orientation : I
    //   452: faload
    //   453: fstore #4
    //   455: iload #6
    //   457: istore #7
    //   459: iload #8
    //   461: istore #5
    //   463: fload_2
    //   464: fstore_3
    //   465: fload #4
    //   467: fconst_0
    //   468: fcmpl
    //   469: iflt -> 497
    //   472: fload_2
    //   473: fload #4
    //   475: fadd
    //   476: fstore_3
    //   477: iload #6
    //   479: istore #7
    //   481: iload #8
    //   483: istore #5
    //   485: goto -> 497
    //   488: iload #6
    //   490: iload #7
    //   492: iadd
    //   493: istore #7
    //   495: fload_2
    //   496: fstore_3
    //   497: iload #7
    //   499: istore #8
    //   501: iload #5
    //   503: istore #11
    //   505: iload #12
    //   507: istore #6
    //   509: fload_3
    //   510: fstore_2
    //   511: iload #10
    //   513: iload #18
    //   515: if_icmpge -> 562
    //   518: iload #7
    //   520: istore #8
    //   522: iload #5
    //   524: istore #11
    //   526: iload #12
    //   528: istore #6
    //   530: fload_3
    //   531: fstore_2
    //   532: iload #10
    //   534: iload #15
    //   536: if_icmpge -> 562
    //   539: iload #7
    //   541: aload_1
    //   542: getfield end : Landroidx/constraintlayout/core/widgets/analyzer/DependencyNode;
    //   545: getfield margin : I
    //   548: ineg
    //   549: iadd
    //   550: istore #8
    //   552: fload_3
    //   553: fstore_2
    //   554: iload #12
    //   556: istore #6
    //   558: iload #5
    //   560: istore #11
    //   562: iload #10
    //   564: iconst_1
    //   565: iadd
    //   566: istore #10
    //   568: iload #11
    //   570: istore #5
    //   572: goto -> 207
    //   575: iload #8
    //   577: iload #20
    //   579: if_icmplt -> 599
    //   582: iload #5
    //   584: ifne -> 590
    //   587: goto -> 599
    //   590: iload #9
    //   592: iconst_1
    //   593: iadd
    //   594: istore #9
    //   596: goto -> 187
    //   599: iload #6
    //   601: istore #7
    //   603: iload #5
    //   605: istore #6
    //   607: goto -> 621
    //   610: iconst_0
    //   611: istore #7
    //   613: iconst_0
    //   614: istore #8
    //   616: iconst_0
    //   617: istore #6
    //   619: fconst_0
    //   620: fstore_2
    //   621: aload_0
    //   622: getfield start : Landroidx/constraintlayout/core/widgets/analyzer/DependencyNode;
    //   625: getfield value : I
    //   628: istore #9
    //   630: iload #21
    //   632: ifeq -> 644
    //   635: aload_0
    //   636: getfield end : Landroidx/constraintlayout/core/widgets/analyzer/DependencyNode;
    //   639: getfield value : I
    //   642: istore #9
    //   644: iload #9
    //   646: istore #5
    //   648: iload #8
    //   650: iload #20
    //   652: if_icmple -> 697
    //   655: iload #21
    //   657: ifeq -> 680
    //   660: iload #9
    //   662: iload #8
    //   664: iload #20
    //   666: isub
    //   667: i2f
    //   668: fconst_2
    //   669: fdiv
    //   670: ldc 0.5
    //   672: fadd
    //   673: f2i
    //   674: iadd
    //   675: istore #5
    //   677: goto -> 697
    //   680: iload #9
    //   682: iload #8
    //   684: iload #20
    //   686: isub
    //   687: i2f
    //   688: fconst_2
    //   689: fdiv
    //   690: ldc 0.5
    //   692: fadd
    //   693: f2i
    //   694: isub
    //   695: istore #5
    //   697: iload #6
    //   699: ifle -> 1186
    //   702: iload #20
    //   704: iload #8
    //   706: isub
    //   707: i2f
    //   708: fstore_3
    //   709: fload_3
    //   710: iload #6
    //   712: i2f
    //   713: fdiv
    //   714: ldc 0.5
    //   716: fadd
    //   717: f2i
    //   718: istore #11
    //   720: iconst_0
    //   721: istore #16
    //   723: iconst_0
    //   724: istore #10
    //   726: iload #8
    //   728: istore #9
    //   730: iload #10
    //   732: istore #8
    //   734: iload #5
    //   736: istore #10
    //   738: iload #16
    //   740: iload #19
    //   742: if_icmpge -> 986
    //   745: aload_0
    //   746: getfield widgets : Ljava/util/ArrayList;
    //   749: iload #16
    //   751: invokevirtual get : (I)Ljava/lang/Object;
    //   754: checkcast androidx/constraintlayout/core/widgets/analyzer/WidgetRun
    //   757: astore_1
    //   758: aload_1
    //   759: getfield widget : Landroidx/constraintlayout/core/widgets/ConstraintWidget;
    //   762: invokevirtual getVisibility : ()I
    //   765: bipush #8
    //   767: if_icmpne -> 773
    //   770: goto -> 977
    //   773: aload_1
    //   774: getfield dimensionBehavior : Landroidx/constraintlayout/core/widgets/ConstraintWidget$DimensionBehaviour;
    //   777: getstatic androidx/constraintlayout/core/widgets/ConstraintWidget$DimensionBehaviour.MATCH_CONSTRAINT : Landroidx/constraintlayout/core/widgets/ConstraintWidget$DimensionBehaviour;
    //   780: if_acmpne -> 977
    //   783: aload_1
    //   784: getfield dimension : Landroidx/constraintlayout/core/widgets/analyzer/DimensionDependency;
    //   787: astore #22
    //   789: aload #22
    //   791: getfield resolved : Z
    //   794: ifne -> 977
    //   797: fload_2
    //   798: fconst_0
    //   799: fcmpl
    //   800: ifle -> 828
    //   803: aload_1
    //   804: getfield widget : Landroidx/constraintlayout/core/widgets/ConstraintWidget;
    //   807: getfield mWeight : [F
    //   810: aload_0
    //   811: getfield orientation : I
    //   814: faload
    //   815: fload_3
    //   816: fmul
    //   817: fload_2
    //   818: fdiv
    //   819: ldc 0.5
    //   821: fadd
    //   822: f2i
    //   823: istore #5
    //   825: goto -> 832
    //   828: iload #11
    //   830: istore #5
    //   832: aload_0
    //   833: getfield orientation : I
    //   836: ifne -> 862
    //   839: aload_1
    //   840: getfield widget : Landroidx/constraintlayout/core/widgets/ConstraintWidget;
    //   843: astore #23
    //   845: aload #23
    //   847: getfield mMatchConstraintMaxWidth : I
    //   850: istore #13
    //   852: aload #23
    //   854: getfield mMatchConstraintMinWidth : I
    //   857: istore #12
    //   859: goto -> 882
    //   862: aload_1
    //   863: getfield widget : Landroidx/constraintlayout/core/widgets/ConstraintWidget;
    //   866: astore #23
    //   868: aload #23
    //   870: getfield mMatchConstraintMaxHeight : I
    //   873: istore #13
    //   875: aload #23
    //   877: getfield mMatchConstraintMinHeight : I
    //   880: istore #12
    //   882: aload_1
    //   883: getfield matchConstraintsType : I
    //   886: iconst_1
    //   887: if_icmpne -> 905
    //   890: iload #5
    //   892: aload #22
    //   894: getfield wrapValue : I
    //   897: invokestatic min : (II)I
    //   900: istore #17
    //   902: goto -> 909
    //   905: iload #5
    //   907: istore #17
    //   909: iload #12
    //   911: iload #17
    //   913: invokestatic max : (II)I
    //   916: istore #17
    //   918: iload #17
    //   920: istore #12
    //   922: iload #13
    //   924: ifle -> 936
    //   927: iload #13
    //   929: iload #17
    //   931: invokestatic min : (II)I
    //   934: istore #12
    //   936: iload #5
    //   938: istore #17
    //   940: iload #8
    //   942: istore #13
    //   944: iload #12
    //   946: iload #5
    //   948: if_icmpeq -> 961
    //   951: iload #8
    //   953: iconst_1
    //   954: iadd
    //   955: istore #13
    //   957: iload #12
    //   959: istore #17
    //   961: aload_1
    //   962: getfield dimension : Landroidx/constraintlayout/core/widgets/analyzer/DimensionDependency;
    //   965: iload #17
    //   967: invokevirtual resolve : (I)V
    //   970: iload #13
    //   972: istore #8
    //   974: goto -> 977
    //   977: iload #16
    //   979: iconst_1
    //   980: iadd
    //   981: istore #16
    //   983: goto -> 738
    //   986: iload #8
    //   988: ifle -> 1134
    //   991: iload #6
    //   993: iload #8
    //   995: isub
    //   996: istore #11
    //   998: iconst_0
    //   999: istore #6
    //   1001: iconst_0
    //   1002: istore #5
    //   1004: iload #6
    //   1006: iload #19
    //   1008: if_icmpge -> 1127
    //   1011: aload_0
    //   1012: getfield widgets : Ljava/util/ArrayList;
    //   1015: iload #6
    //   1017: invokevirtual get : (I)Ljava/lang/Object;
    //   1020: checkcast androidx/constraintlayout/core/widgets/analyzer/WidgetRun
    //   1023: astore_1
    //   1024: aload_1
    //   1025: getfield widget : Landroidx/constraintlayout/core/widgets/ConstraintWidget;
    //   1028: invokevirtual getVisibility : ()I
    //   1031: bipush #8
    //   1033: if_icmpne -> 1039
    //   1036: goto -> 1118
    //   1039: iload #5
    //   1041: istore #9
    //   1043: iload #6
    //   1045: ifle -> 1071
    //   1048: iload #5
    //   1050: istore #9
    //   1052: iload #6
    //   1054: iload #14
    //   1056: if_icmplt -> 1071
    //   1059: iload #5
    //   1061: aload_1
    //   1062: getfield start : Landroidx/constraintlayout/core/widgets/analyzer/DependencyNode;
    //   1065: getfield margin : I
    //   1068: iadd
    //   1069: istore #9
    //   1071: iload #9
    //   1073: aload_1
    //   1074: getfield dimension : Landroidx/constraintlayout/core/widgets/analyzer/DimensionDependency;
    //   1077: getfield value : I
    //   1080: iadd
    //   1081: istore #9
    //   1083: iload #9
    //   1085: istore #5
    //   1087: iload #6
    //   1089: iload #18
    //   1091: if_icmpge -> 1118
    //   1094: iload #9
    //   1096: istore #5
    //   1098: iload #6
    //   1100: iload #15
    //   1102: if_icmpge -> 1118
    //   1105: iload #9
    //   1107: aload_1
    //   1108: getfield end : Landroidx/constraintlayout/core/widgets/analyzer/DependencyNode;
    //   1111: getfield margin : I
    //   1114: ineg
    //   1115: iadd
    //   1116: istore #5
    //   1118: iload #6
    //   1120: iconst_1
    //   1121: iadd
    //   1122: istore #6
    //   1124: goto -> 1004
    //   1127: iload #11
    //   1129: istore #6
    //   1131: goto -> 1138
    //   1134: iload #9
    //   1136: istore #5
    //   1138: aload_0
    //   1139: getfield chainStyle : I
    //   1142: iconst_2
    //   1143: if_icmpne -> 1171
    //   1146: iload #8
    //   1148: ifne -> 1171
    //   1151: aload_0
    //   1152: iconst_0
    //   1153: putfield chainStyle : I
    //   1156: iload #5
    //   1158: istore #8
    //   1160: iload #6
    //   1162: istore #9
    //   1164: iload #10
    //   1166: istore #5
    //   1168: goto -> 1190
    //   1171: iload #5
    //   1173: istore #8
    //   1175: iload #6
    //   1177: istore #9
    //   1179: iload #10
    //   1181: istore #5
    //   1183: goto -> 1190
    //   1186: iload #6
    //   1188: istore #9
    //   1190: iload #8
    //   1192: iload #20
    //   1194: if_icmple -> 1202
    //   1197: aload_0
    //   1198: iconst_2
    //   1199: putfield chainStyle : I
    //   1202: iload #7
    //   1204: ifle -> 1224
    //   1207: iload #9
    //   1209: ifne -> 1224
    //   1212: iload #14
    //   1214: iload #15
    //   1216: if_icmpne -> 1224
    //   1219: aload_0
    //   1220: iconst_2
    //   1221: putfield chainStyle : I
    //   1224: aload_0
    //   1225: getfield chainStyle : I
    //   1228: istore #6
    //   1230: iload #6
    //   1232: iconst_1
    //   1233: if_icmpne -> 1652
    //   1236: iload #7
    //   1238: iconst_1
    //   1239: if_icmple -> 1257
    //   1242: iload #20
    //   1244: iload #8
    //   1246: isub
    //   1247: iload #7
    //   1249: iconst_1
    //   1250: isub
    //   1251: idiv
    //   1252: istore #6
    //   1254: goto -> 1278
    //   1257: iload #7
    //   1259: iconst_1
    //   1260: if_icmpne -> 1275
    //   1263: iload #20
    //   1265: iload #8
    //   1267: isub
    //   1268: iconst_2
    //   1269: idiv
    //   1270: istore #6
    //   1272: goto -> 1278
    //   1275: iconst_0
    //   1276: istore #6
    //   1278: iload #6
    //   1280: istore #8
    //   1282: iload #9
    //   1284: ifle -> 1290
    //   1287: iconst_0
    //   1288: istore #8
    //   1290: iconst_0
    //   1291: istore #6
    //   1293: iload #5
    //   1295: istore #7
    //   1297: iload #6
    //   1299: iload #19
    //   1301: if_icmpge -> 2419
    //   1304: iload #21
    //   1306: ifeq -> 1321
    //   1309: iload #19
    //   1311: iload #6
    //   1313: iconst_1
    //   1314: iadd
    //   1315: isub
    //   1316: istore #5
    //   1318: goto -> 1325
    //   1321: iload #6
    //   1323: istore #5
    //   1325: aload_0
    //   1326: getfield widgets : Ljava/util/ArrayList;
    //   1329: iload #5
    //   1331: invokevirtual get : (I)Ljava/lang/Object;
    //   1334: checkcast androidx/constraintlayout/core/widgets/analyzer/WidgetRun
    //   1337: astore_1
    //   1338: aload_1
    //   1339: getfield widget : Landroidx/constraintlayout/core/widgets/ConstraintWidget;
    //   1342: invokevirtual getVisibility : ()I
    //   1345: bipush #8
    //   1347: if_icmpne -> 1375
    //   1350: aload_1
    //   1351: getfield start : Landroidx/constraintlayout/core/widgets/analyzer/DependencyNode;
    //   1354: iload #7
    //   1356: invokevirtual resolve : (I)V
    //   1359: aload_1
    //   1360: getfield end : Landroidx/constraintlayout/core/widgets/analyzer/DependencyNode;
    //   1363: iload #7
    //   1365: invokevirtual resolve : (I)V
    //   1368: iload #7
    //   1370: istore #5
    //   1372: goto -> 1639
    //   1375: iload #7
    //   1377: istore #5
    //   1379: iload #6
    //   1381: ifle -> 1406
    //   1384: iload #21
    //   1386: ifeq -> 1399
    //   1389: iload #7
    //   1391: iload #8
    //   1393: isub
    //   1394: istore #5
    //   1396: goto -> 1406
    //   1399: iload #7
    //   1401: iload #8
    //   1403: iadd
    //   1404: istore #5
    //   1406: iload #5
    //   1408: istore #7
    //   1410: iload #6
    //   1412: ifle -> 1458
    //   1415: iload #5
    //   1417: istore #7
    //   1419: iload #6
    //   1421: iload #14
    //   1423: if_icmplt -> 1458
    //   1426: iload #21
    //   1428: ifeq -> 1446
    //   1431: iload #5
    //   1433: aload_1
    //   1434: getfield start : Landroidx/constraintlayout/core/widgets/analyzer/DependencyNode;
    //   1437: getfield margin : I
    //   1440: isub
    //   1441: istore #7
    //   1443: goto -> 1458
    //   1446: iload #5
    //   1448: aload_1
    //   1449: getfield start : Landroidx/constraintlayout/core/widgets/analyzer/DependencyNode;
    //   1452: getfield margin : I
    //   1455: iadd
    //   1456: istore #7
    //   1458: iload #21
    //   1460: ifeq -> 1475
    //   1463: aload_1
    //   1464: getfield end : Landroidx/constraintlayout/core/widgets/analyzer/DependencyNode;
    //   1467: iload #7
    //   1469: invokevirtual resolve : (I)V
    //   1472: goto -> 1484
    //   1475: aload_1
    //   1476: getfield start : Landroidx/constraintlayout/core/widgets/analyzer/DependencyNode;
    //   1479: iload #7
    //   1481: invokevirtual resolve : (I)V
    //   1484: aload_1
    //   1485: getfield dimension : Landroidx/constraintlayout/core/widgets/analyzer/DimensionDependency;
    //   1488: astore #22
    //   1490: aload #22
    //   1492: getfield value : I
    //   1495: istore #9
    //   1497: iload #9
    //   1499: istore #5
    //   1501: aload_1
    //   1502: getfield dimensionBehavior : Landroidx/constraintlayout/core/widgets/ConstraintWidget$DimensionBehaviour;
    //   1505: getstatic androidx/constraintlayout/core/widgets/ConstraintWidget$DimensionBehaviour.MATCH_CONSTRAINT : Landroidx/constraintlayout/core/widgets/ConstraintWidget$DimensionBehaviour;
    //   1508: if_acmpne -> 1530
    //   1511: iload #9
    //   1513: istore #5
    //   1515: aload_1
    //   1516: getfield matchConstraintsType : I
    //   1519: iconst_1
    //   1520: if_icmpne -> 1530
    //   1523: aload #22
    //   1525: getfield wrapValue : I
    //   1528: istore #5
    //   1530: iload #21
    //   1532: ifeq -> 1545
    //   1535: iload #7
    //   1537: iload #5
    //   1539: isub
    //   1540: istore #7
    //   1542: goto -> 1552
    //   1545: iload #7
    //   1547: iload #5
    //   1549: iadd
    //   1550: istore #7
    //   1552: iload #21
    //   1554: ifeq -> 1569
    //   1557: aload_1
    //   1558: getfield start : Landroidx/constraintlayout/core/widgets/analyzer/DependencyNode;
    //   1561: iload #7
    //   1563: invokevirtual resolve : (I)V
    //   1566: goto -> 1578
    //   1569: aload_1
    //   1570: getfield end : Landroidx/constraintlayout/core/widgets/analyzer/DependencyNode;
    //   1573: iload #7
    //   1575: invokevirtual resolve : (I)V
    //   1578: aload_1
    //   1579: iconst_1
    //   1580: putfield resolved : Z
    //   1583: iload #7
    //   1585: istore #5
    //   1587: iload #6
    //   1589: iload #18
    //   1591: if_icmpge -> 1639
    //   1594: iload #7
    //   1596: istore #5
    //   1598: iload #6
    //   1600: iload #15
    //   1602: if_icmpge -> 1639
    //   1605: iload #21
    //   1607: ifeq -> 1626
    //   1610: iload #7
    //   1612: aload_1
    //   1613: getfield end : Landroidx/constraintlayout/core/widgets/analyzer/DependencyNode;
    //   1616: getfield margin : I
    //   1619: ineg
    //   1620: isub
    //   1621: istore #5
    //   1623: goto -> 1639
    //   1626: iload #7
    //   1628: aload_1
    //   1629: getfield end : Landroidx/constraintlayout/core/widgets/analyzer/DependencyNode;
    //   1632: getfield margin : I
    //   1635: ineg
    //   1636: iadd
    //   1637: istore #5
    //   1639: iload #6
    //   1641: iconst_1
    //   1642: iadd
    //   1643: istore #6
    //   1645: iload #5
    //   1647: istore #7
    //   1649: goto -> 1297
    //   1652: iload #6
    //   1654: ifne -> 2018
    //   1657: iload #20
    //   1659: iload #8
    //   1661: isub
    //   1662: iload #7
    //   1664: iconst_1
    //   1665: iadd
    //   1666: idiv
    //   1667: istore #8
    //   1669: iload #9
    //   1671: ifle -> 1677
    //   1674: iconst_0
    //   1675: istore #8
    //   1677: iconst_0
    //   1678: istore #6
    //   1680: iload #6
    //   1682: iload #19
    //   1684: if_icmpge -> 2419
    //   1687: iload #21
    //   1689: ifeq -> 1704
    //   1692: iload #19
    //   1694: iload #6
    //   1696: iconst_1
    //   1697: iadd
    //   1698: isub
    //   1699: istore #7
    //   1701: goto -> 1708
    //   1704: iload #6
    //   1706: istore #7
    //   1708: aload_0
    //   1709: getfield widgets : Ljava/util/ArrayList;
    //   1712: iload #7
    //   1714: invokevirtual get : (I)Ljava/lang/Object;
    //   1717: checkcast androidx/constraintlayout/core/widgets/analyzer/WidgetRun
    //   1720: astore_1
    //   1721: aload_1
    //   1722: getfield widget : Landroidx/constraintlayout/core/widgets/ConstraintWidget;
    //   1725: invokevirtual getVisibility : ()I
    //   1728: bipush #8
    //   1730: if_icmpne -> 1754
    //   1733: aload_1
    //   1734: getfield start : Landroidx/constraintlayout/core/widgets/analyzer/DependencyNode;
    //   1737: iload #5
    //   1739: invokevirtual resolve : (I)V
    //   1742: aload_1
    //   1743: getfield end : Landroidx/constraintlayout/core/widgets/analyzer/DependencyNode;
    //   1746: iload #5
    //   1748: invokevirtual resolve : (I)V
    //   1751: goto -> 2009
    //   1754: iload #21
    //   1756: ifeq -> 1769
    //   1759: iload #5
    //   1761: iload #8
    //   1763: isub
    //   1764: istore #7
    //   1766: goto -> 1776
    //   1769: iload #5
    //   1771: iload #8
    //   1773: iadd
    //   1774: istore #7
    //   1776: iload #7
    //   1778: istore #5
    //   1780: iload #6
    //   1782: ifle -> 1828
    //   1785: iload #7
    //   1787: istore #5
    //   1789: iload #6
    //   1791: iload #14
    //   1793: if_icmplt -> 1828
    //   1796: iload #21
    //   1798: ifeq -> 1816
    //   1801: iload #7
    //   1803: aload_1
    //   1804: getfield start : Landroidx/constraintlayout/core/widgets/analyzer/DependencyNode;
    //   1807: getfield margin : I
    //   1810: isub
    //   1811: istore #5
    //   1813: goto -> 1828
    //   1816: iload #7
    //   1818: aload_1
    //   1819: getfield start : Landroidx/constraintlayout/core/widgets/analyzer/DependencyNode;
    //   1822: getfield margin : I
    //   1825: iadd
    //   1826: istore #5
    //   1828: iload #21
    //   1830: ifeq -> 1845
    //   1833: aload_1
    //   1834: getfield end : Landroidx/constraintlayout/core/widgets/analyzer/DependencyNode;
    //   1837: iload #5
    //   1839: invokevirtual resolve : (I)V
    //   1842: goto -> 1854
    //   1845: aload_1
    //   1846: getfield start : Landroidx/constraintlayout/core/widgets/analyzer/DependencyNode;
    //   1849: iload #5
    //   1851: invokevirtual resolve : (I)V
    //   1854: aload_1
    //   1855: getfield dimension : Landroidx/constraintlayout/core/widgets/analyzer/DimensionDependency;
    //   1858: astore #22
    //   1860: aload #22
    //   1862: getfield value : I
    //   1865: istore #9
    //   1867: iload #9
    //   1869: istore #7
    //   1871: aload_1
    //   1872: getfield dimensionBehavior : Landroidx/constraintlayout/core/widgets/ConstraintWidget$DimensionBehaviour;
    //   1875: getstatic androidx/constraintlayout/core/widgets/ConstraintWidget$DimensionBehaviour.MATCH_CONSTRAINT : Landroidx/constraintlayout/core/widgets/ConstraintWidget$DimensionBehaviour;
    //   1878: if_acmpne -> 1905
    //   1881: iload #9
    //   1883: istore #7
    //   1885: aload_1
    //   1886: getfield matchConstraintsType : I
    //   1889: iconst_1
    //   1890: if_icmpne -> 1905
    //   1893: iload #9
    //   1895: aload #22
    //   1897: getfield wrapValue : I
    //   1900: invokestatic min : (II)I
    //   1903: istore #7
    //   1905: iload #21
    //   1907: ifeq -> 1920
    //   1910: iload #5
    //   1912: iload #7
    //   1914: isub
    //   1915: istore #7
    //   1917: goto -> 1927
    //   1920: iload #5
    //   1922: iload #7
    //   1924: iadd
    //   1925: istore #7
    //   1927: iload #21
    //   1929: ifeq -> 1944
    //   1932: aload_1
    //   1933: getfield start : Landroidx/constraintlayout/core/widgets/analyzer/DependencyNode;
    //   1936: iload #7
    //   1938: invokevirtual resolve : (I)V
    //   1941: goto -> 1953
    //   1944: aload_1
    //   1945: getfield end : Landroidx/constraintlayout/core/widgets/analyzer/DependencyNode;
    //   1948: iload #7
    //   1950: invokevirtual resolve : (I)V
    //   1953: iload #7
    //   1955: istore #5
    //   1957: iload #6
    //   1959: iload #18
    //   1961: if_icmpge -> 2009
    //   1964: iload #7
    //   1966: istore #5
    //   1968: iload #6
    //   1970: iload #15
    //   1972: if_icmpge -> 2009
    //   1975: iload #21
    //   1977: ifeq -> 1996
    //   1980: iload #7
    //   1982: aload_1
    //   1983: getfield end : Landroidx/constraintlayout/core/widgets/analyzer/DependencyNode;
    //   1986: getfield margin : I
    //   1989: ineg
    //   1990: isub
    //   1991: istore #5
    //   1993: goto -> 2009
    //   1996: iload #7
    //   1998: aload_1
    //   1999: getfield end : Landroidx/constraintlayout/core/widgets/analyzer/DependencyNode;
    //   2002: getfield margin : I
    //   2005: ineg
    //   2006: iadd
    //   2007: istore #5
    //   2009: iload #6
    //   2011: iconst_1
    //   2012: iadd
    //   2013: istore #6
    //   2015: goto -> 1680
    //   2018: iload #6
    //   2020: iconst_2
    //   2021: if_icmpne -> 2419
    //   2024: aload_0
    //   2025: getfield orientation : I
    //   2028: ifne -> 2042
    //   2031: aload_0
    //   2032: getfield widget : Landroidx/constraintlayout/core/widgets/ConstraintWidget;
    //   2035: invokevirtual getHorizontalBiasPercent : ()F
    //   2038: fstore_2
    //   2039: goto -> 2050
    //   2042: aload_0
    //   2043: getfield widget : Landroidx/constraintlayout/core/widgets/ConstraintWidget;
    //   2046: invokevirtual getVerticalBiasPercent : ()F
    //   2049: fstore_2
    //   2050: fload_2
    //   2051: fstore_3
    //   2052: iload #21
    //   2054: ifeq -> 2061
    //   2057: fconst_1
    //   2058: fload_2
    //   2059: fsub
    //   2060: fstore_3
    //   2061: iload #20
    //   2063: iload #8
    //   2065: isub
    //   2066: i2f
    //   2067: fload_3
    //   2068: fmul
    //   2069: ldc 0.5
    //   2071: fadd
    //   2072: f2i
    //   2073: istore #6
    //   2075: iload #6
    //   2077: iflt -> 2085
    //   2080: iload #9
    //   2082: ifle -> 2088
    //   2085: iconst_0
    //   2086: istore #6
    //   2088: iload #21
    //   2090: ifeq -> 2103
    //   2093: iload #5
    //   2095: iload #6
    //   2097: isub
    //   2098: istore #5
    //   2100: goto -> 2110
    //   2103: iload #5
    //   2105: iload #6
    //   2107: iadd
    //   2108: istore #5
    //   2110: iconst_0
    //   2111: istore #6
    //   2113: iload #6
    //   2115: iload #19
    //   2117: if_icmpge -> 2419
    //   2120: iload #21
    //   2122: ifeq -> 2137
    //   2125: iload #19
    //   2127: iload #6
    //   2129: iconst_1
    //   2130: iadd
    //   2131: isub
    //   2132: istore #7
    //   2134: goto -> 2141
    //   2137: iload #6
    //   2139: istore #7
    //   2141: aload_0
    //   2142: getfield widgets : Ljava/util/ArrayList;
    //   2145: iload #7
    //   2147: invokevirtual get : (I)Ljava/lang/Object;
    //   2150: checkcast androidx/constraintlayout/core/widgets/analyzer/WidgetRun
    //   2153: astore_1
    //   2154: aload_1
    //   2155: getfield widget : Landroidx/constraintlayout/core/widgets/ConstraintWidget;
    //   2158: invokevirtual getVisibility : ()I
    //   2161: bipush #8
    //   2163: if_icmpne -> 2187
    //   2166: aload_1
    //   2167: getfield start : Landroidx/constraintlayout/core/widgets/analyzer/DependencyNode;
    //   2170: iload #5
    //   2172: invokevirtual resolve : (I)V
    //   2175: aload_1
    //   2176: getfield end : Landroidx/constraintlayout/core/widgets/analyzer/DependencyNode;
    //   2179: iload #5
    //   2181: invokevirtual resolve : (I)V
    //   2184: goto -> 2410
    //   2187: iload #5
    //   2189: istore #7
    //   2191: iload #6
    //   2193: ifle -> 2239
    //   2196: iload #5
    //   2198: istore #7
    //   2200: iload #6
    //   2202: iload #14
    //   2204: if_icmplt -> 2239
    //   2207: iload #21
    //   2209: ifeq -> 2227
    //   2212: iload #5
    //   2214: aload_1
    //   2215: getfield start : Landroidx/constraintlayout/core/widgets/analyzer/DependencyNode;
    //   2218: getfield margin : I
    //   2221: isub
    //   2222: istore #7
    //   2224: goto -> 2239
    //   2227: iload #5
    //   2229: aload_1
    //   2230: getfield start : Landroidx/constraintlayout/core/widgets/analyzer/DependencyNode;
    //   2233: getfield margin : I
    //   2236: iadd
    //   2237: istore #7
    //   2239: iload #21
    //   2241: ifeq -> 2256
    //   2244: aload_1
    //   2245: getfield end : Landroidx/constraintlayout/core/widgets/analyzer/DependencyNode;
    //   2248: iload #7
    //   2250: invokevirtual resolve : (I)V
    //   2253: goto -> 2265
    //   2256: aload_1
    //   2257: getfield start : Landroidx/constraintlayout/core/widgets/analyzer/DependencyNode;
    //   2260: iload #7
    //   2262: invokevirtual resolve : (I)V
    //   2265: aload_1
    //   2266: getfield dimension : Landroidx/constraintlayout/core/widgets/analyzer/DimensionDependency;
    //   2269: astore #22
    //   2271: aload #22
    //   2273: getfield value : I
    //   2276: istore #5
    //   2278: aload_1
    //   2279: getfield dimensionBehavior : Landroidx/constraintlayout/core/widgets/ConstraintWidget$DimensionBehaviour;
    //   2282: getstatic androidx/constraintlayout/core/widgets/ConstraintWidget$DimensionBehaviour.MATCH_CONSTRAINT : Landroidx/constraintlayout/core/widgets/ConstraintWidget$DimensionBehaviour;
    //   2285: if_acmpne -> 2306
    //   2288: aload_1
    //   2289: getfield matchConstraintsType : I
    //   2292: iconst_1
    //   2293: if_icmpne -> 2306
    //   2296: aload #22
    //   2298: getfield wrapValue : I
    //   2301: istore #5
    //   2303: goto -> 2306
    //   2306: iload #21
    //   2308: ifeq -> 2321
    //   2311: iload #7
    //   2313: iload #5
    //   2315: isub
    //   2316: istore #7
    //   2318: goto -> 2328
    //   2321: iload #7
    //   2323: iload #5
    //   2325: iadd
    //   2326: istore #7
    //   2328: iload #21
    //   2330: ifeq -> 2345
    //   2333: aload_1
    //   2334: getfield start : Landroidx/constraintlayout/core/widgets/analyzer/DependencyNode;
    //   2337: iload #7
    //   2339: invokevirtual resolve : (I)V
    //   2342: goto -> 2354
    //   2345: aload_1
    //   2346: getfield end : Landroidx/constraintlayout/core/widgets/analyzer/DependencyNode;
    //   2349: iload #7
    //   2351: invokevirtual resolve : (I)V
    //   2354: iload #7
    //   2356: istore #5
    //   2358: iload #6
    //   2360: iload #18
    //   2362: if_icmpge -> 2410
    //   2365: iload #7
    //   2367: istore #5
    //   2369: iload #6
    //   2371: iload #15
    //   2373: if_icmpge -> 2410
    //   2376: iload #21
    //   2378: ifeq -> 2397
    //   2381: iload #7
    //   2383: aload_1
    //   2384: getfield end : Landroidx/constraintlayout/core/widgets/analyzer/DependencyNode;
    //   2387: getfield margin : I
    //   2390: ineg
    //   2391: isub
    //   2392: istore #5
    //   2394: goto -> 2410
    //   2397: iload #7
    //   2399: aload_1
    //   2400: getfield end : Landroidx/constraintlayout/core/widgets/analyzer/DependencyNode;
    //   2403: getfield margin : I
    //   2406: ineg
    //   2407: iadd
    //   2408: istore #5
    //   2410: iload #6
    //   2412: iconst_1
    //   2413: iadd
    //   2414: istore #6
    //   2416: goto -> 2113
    //   2419: return
  }
}


/* Location:              C:\soft\dex2jar-2.0\MagicAI - AI Art & Anime Art-dex2jar.jar!\androidx\constraintlayout\core\widgets\analyzer\ChainRun.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */