package androidx.constraintlayout.widget;

public final class R {
  public static final class anim {
    public static final int abc_fade_in = 2130771968;
    
    public static final int abc_fade_out = 2130771969;
    
    public static final int abc_grow_fade_in_from_bottom = 2130771970;
    
    public static final int abc_popup_enter = 2130771971;
    
    public static final int abc_popup_exit = 2130771972;
    
    public static final int abc_shrink_fade_out_from_bottom = 2130771973;
    
    public static final int abc_slide_in_bottom = 2130771974;
    
    public static final int abc_slide_in_top = 2130771975;
    
    public static final int abc_slide_out_bottom = 2130771976;
    
    public static final int abc_slide_out_top = 2130771977;
    
    public static final int abc_tooltip_enter = 2130771978;
    
    public static final int abc_tooltip_exit = 2130771979;
    
    public static final int btn_checkbox_to_checked_box_inner_merged_animation = 2130771982;
    
    public static final int btn_checkbox_to_checked_box_outer_merged_animation = 2130771983;
    
    public static final int btn_checkbox_to_checked_icon_null_animation = 2130771984;
    
    public static final int btn_checkbox_to_unchecked_box_inner_merged_animation = 2130771985;
    
    public static final int btn_checkbox_to_unchecked_check_path_merged_animation = 2130771986;
    
    public static final int btn_checkbox_to_unchecked_icon_null_animation = 2130771987;
    
    public static final int btn_radio_to_off_mtrl_dot_group_animation = 2130771988;
    
    public static final int btn_radio_to_off_mtrl_ring_outer_animation = 2130771989;
    
    public static final int btn_radio_to_off_mtrl_ring_outer_path_animation = 2130771990;
    
    public static final int btn_radio_to_on_mtrl_dot_group_animation = 2130771991;
    
    public static final int btn_radio_to_on_mtrl_ring_outer_animation = 2130771992;
    
    public static final int btn_radio_to_on_mtrl_ring_outer_path_animation = 2130771993;
  }
  
  public static final class attr {
    public static final int SharedValue = 2130968576;
    
    public static final int SharedValueId = 2130968577;
    
    public static final int actionBarDivider = 2130968581;
    
    public static final int actionBarItemBackground = 2130968582;
    
    public static final int actionBarPopupTheme = 2130968583;
    
    public static final int actionBarSize = 2130968584;
    
    public static final int actionBarSplitStyle = 2130968585;
    
    public static final int actionBarStyle = 2130968586;
    
    public static final int actionBarTabBarStyle = 2130968587;
    
    public static final int actionBarTabStyle = 2130968588;
    
    public static final int actionBarTabTextStyle = 2130968589;
    
    public static final int actionBarTheme = 2130968590;
    
    public static final int actionBarWidgetTheme = 2130968591;
    
    public static final int actionButtonStyle = 2130968592;
    
    public static final int actionDropDownStyle = 2130968593;
    
    public static final int actionLayout = 2130968594;
    
    public static final int actionMenuTextAppearance = 2130968595;
    
    public static final int actionMenuTextColor = 2130968596;
    
    public static final int actionModeBackground = 2130968597;
    
    public static final int actionModeCloseButtonStyle = 2130968598;
    
    public static final int actionModeCloseDrawable = 2130968600;
    
    public static final int actionModeCopyDrawable = 2130968601;
    
    public static final int actionModeCutDrawable = 2130968602;
    
    public static final int actionModeFindDrawable = 2130968603;
    
    public static final int actionModePasteDrawable = 2130968604;
    
    public static final int actionModePopupWindowStyle = 2130968605;
    
    public static final int actionModeSelectAllDrawable = 2130968606;
    
    public static final int actionModeShareDrawable = 2130968607;
    
    public static final int actionModeSplitBackground = 2130968608;
    
    public static final int actionModeStyle = 2130968609;
    
    public static final int actionModeWebSearchDrawable = 2130968611;
    
    public static final int actionOverflowButtonStyle = 2130968612;
    
    public static final int actionOverflowMenuStyle = 2130968613;
    
    public static final int actionProviderClass = 2130968614;
    
    public static final int actionViewClass = 2130968616;
    
    public static final int activityChooserViewStyle = 2130968617;
    
    public static final int alertDialogButtonGroupStyle = 2130968661;
    
    public static final int alertDialogCenterButtons = 2130968662;
    
    public static final int alertDialogStyle = 2130968663;
    
    public static final int alertDialogTheme = 2130968664;
    
    public static final int allowStacking = 2130968667;
    
    public static final int alpha = 2130968668;
    
    public static final int alphabeticModifiers = 2130968669;
    
    public static final int altSrc = 2130968670;
    
    public static final int animateCircleAngleTo = 2130968671;
    
    public static final int animateRelativeTo = 2130968674;
    
    public static final int applyMotionScene = 2130968677;
    
    public static final int arcMode = 2130968678;
    
    public static final int arrowHeadLength = 2130968683;
    
    public static final int arrowShaftLength = 2130968686;
    
    public static final int attributeName = 2130968692;
    
    public static final int autoCompleteMode = 2130968693;
    
    public static final int autoCompleteTextViewStyle = 2130968694;
    
    public static final int autoSizeMaxTextSize = 2130968696;
    
    public static final int autoSizeMinTextSize = 2130968697;
    
    public static final int autoSizePresetSizes = 2130968698;
    
    public static final int autoSizeStepGranularity = 2130968699;
    
    public static final int autoSizeTextType = 2130968700;
    
    public static final int autoTransition = 2130968701;
    
    public static final int background = 2130968702;
    
    public static final int backgroundSplit = 2130968710;
    
    public static final int backgroundStacked = 2130968711;
    
    public static final int backgroundTint = 2130968712;
    
    public static final int backgroundTintMode = 2130968713;
    
    public static final int barLength = 2130968751;
    
    public static final int barrierAllowsGoneWidgets = 2130968752;
    
    public static final int barrierDirection = 2130968753;
    
    public static final int barrierMargin = 2130968754;
    
    public static final int blendSrc = 2130968767;
    
    public static final int borderRound = 2130968768;
    
    public static final int borderRoundPercent = 2130968769;
    
    public static final int borderlessButtonStyle = 2130968771;
    
    public static final int brightness = 2130968789;
    
    public static final int buttonBarButtonStyle = 2130968792;
    
    public static final int buttonBarNegativeButtonStyle = 2130968793;
    
    public static final int buttonBarNeutralButtonStyle = 2130968794;
    
    public static final int buttonBarPositiveButtonStyle = 2130968795;
    
    public static final int buttonBarStyle = 2130968796;
    
    public static final int buttonCompat = 2130968797;
    
    public static final int buttonGravity = 2130968798;
    
    public static final int buttonIconDimen = 2130968800;
    
    public static final int buttonPanelSideLayout = 2130968803;
    
    public static final int buttonStyle = 2130968805;
    
    public static final int buttonStyleSmall = 2130968806;
    
    public static final int buttonTint = 2130968807;
    
    public static final int buttonTintMode = 2130968808;
    
    public static final int carousel_backwardTransition = 2130968832;
    
    public static final int carousel_emptyViewsBehavior = 2130968833;
    
    public static final int carousel_firstView = 2130968834;
    
    public static final int carousel_forwardTransition = 2130968835;
    
    public static final int carousel_infinite = 2130968836;
    
    public static final int carousel_nextState = 2130968837;
    
    public static final int carousel_previousState = 2130968838;
    
    public static final int carousel_touchUpMode = 2130968839;
    
    public static final int carousel_touchUp_dampeningFactor = 2130968840;
    
    public static final int carousel_touchUp_velocityThreshold = 2130968841;
    
    public static final int chainUseRtl = 2130968843;
    
    public static final int checkboxStyle = 2130968847;
    
    public static final int checkedTextViewStyle = 2130968858;
    
    public static final int circleRadius = 2130968880;
    
    public static final int circularflow_angles = 2130968882;
    
    public static final int circularflow_defaultAngle = 2130968883;
    
    public static final int circularflow_defaultRadius = 2130968884;
    
    public static final int circularflow_radiusInDP = 2130968885;
    
    public static final int circularflow_viewCenter = 2130968886;
    
    public static final int clearsTag = 2130968891;
    
    public static final int clickAction = 2130968892;
    
    public static final int closeIcon = 2130968897;
    
    public static final int closeItemLayout = 2130968904;
    
    public static final int collapseContentDescription = 2130968905;
    
    public static final int collapseIcon = 2130968906;
    
    public static final int color = 2130968916;
    
    public static final int colorAccent = 2130968917;
    
    public static final int colorBackgroundFloating = 2130968918;
    
    public static final int colorButtonNormal = 2130968919;
    
    public static final int colorControlActivated = 2130968921;
    
    public static final int colorControlHighlight = 2130968922;
    
    public static final int colorControlNormal = 2130968923;
    
    public static final int colorError = 2130968924;
    
    public static final int colorPrimary = 2130968949;
    
    public static final int colorPrimaryDark = 2130968951;
    
    public static final int colorSwitchThumbNormal = 2130968973;
    
    public static final int commitIcon = 2130968978;
    
    public static final int constraintRotate = 2130968980;
    
    public static final int constraintSet = 2130968981;
    
    public static final int constraintSetEnd = 2130968982;
    
    public static final int constraintSetStart = 2130968983;
    
    public static final int constraint_referenced_ids = 2130968984;
    
    public static final int constraint_referenced_tags = 2130968985;
    
    public static final int constraints = 2130968986;
    
    public static final int content = 2130968987;
    
    public static final int contentDescription = 2130968988;
    
    public static final int contentInsetEnd = 2130968989;
    
    public static final int contentInsetEndWithActions = 2130968990;
    
    public static final int contentInsetLeft = 2130968991;
    
    public static final int contentInsetRight = 2130968992;
    
    public static final int contentInsetStart = 2130968993;
    
    public static final int contentInsetStartWithNavigation = 2130968994;
    
    public static final int contrast = 2130969003;
    
    public static final int controlBackground = 2130969004;
    
    public static final int crossfade = 2130969047;
    
    public static final int currentState = 2130969048;
    
    public static final int curveFit = 2130969049;
    
    public static final int customBoolean = 2130969050;
    
    public static final int customColorDrawableValue = 2130969051;
    
    public static final int customColorValue = 2130969052;
    
    public static final int customDimension = 2130969053;
    
    public static final int customFloatValue = 2130969054;
    
    public static final int customIntegerValue = 2130969055;
    
    public static final int customNavigationLayout = 2130969056;
    
    public static final int customPixelDimension = 2130969057;
    
    public static final int customReference = 2130969058;
    
    public static final int customStringValue = 2130969059;
    
    public static final int defaultDuration = 2130969064;
    
    public static final int defaultQueryHint = 2130969066;
    
    public static final int defaultState = 2130969068;
    
    public static final int deltaPolarAngle = 2130969072;
    
    public static final int deltaPolarRadius = 2130969073;
    
    public static final int deriveConstraintsFrom = 2130969074;
    
    public static final int dialogCornerRadius = 2130969075;
    
    public static final int dialogPreferredPadding = 2130969076;
    
    public static final int dialogTheme = 2130969077;
    
    public static final int displayOptions = 2130969078;
    
    public static final int divider = 2130969079;
    
    public static final int dividerHorizontal = 2130969084;
    
    public static final int dividerPadding = 2130969087;
    
    public static final int dividerVertical = 2130969089;
    
    public static final int dragDirection = 2130969094;
    
    public static final int dragScale = 2130969095;
    
    public static final int dragThreshold = 2130969096;
    
    public static final int drawPath = 2130969097;
    
    public static final int drawableBottomCompat = 2130969098;
    
    public static final int drawableEndCompat = 2130969099;
    
    public static final int drawableLeftCompat = 2130969101;
    
    public static final int drawableRightCompat = 2130969103;
    
    public static final int drawableSize = 2130969104;
    
    public static final int drawableStartCompat = 2130969105;
    
    public static final int drawableTint = 2130969106;
    
    public static final int drawableTintMode = 2130969107;
    
    public static final int drawableTopCompat = 2130969108;
    
    public static final int drawerArrowStyle = 2130969109;
    
    public static final int dropDownListViewStyle = 2130969113;
    
    public static final int dropdownListPreferredItemHeight = 2130969114;
    
    public static final int duration = 2130969119;
    
    public static final int editTextBackground = 2130969139;
    
    public static final int editTextColor = 2130969140;
    
    public static final int editTextStyle = 2130969141;
    
    public static final int elevation = 2130969145;
    
    public static final int expandActivityOverflowButtonDrawable = 2130969175;
    
    public static final int firstBaselineToTopHeight = 2130969209;
    
    public static final int flow_firstHorizontalBias = 2130969251;
    
    public static final int flow_firstHorizontalStyle = 2130969252;
    
    public static final int flow_firstVerticalBias = 2130969253;
    
    public static final int flow_firstVerticalStyle = 2130969254;
    
    public static final int flow_horizontalAlign = 2130969255;
    
    public static final int flow_horizontalBias = 2130969256;
    
    public static final int flow_horizontalGap = 2130969257;
    
    public static final int flow_horizontalStyle = 2130969258;
    
    public static final int flow_lastHorizontalBias = 2130969259;
    
    public static final int flow_lastHorizontalStyle = 2130969260;
    
    public static final int flow_lastVerticalBias = 2130969261;
    
    public static final int flow_lastVerticalStyle = 2130969262;
    
    public static final int flow_maxElementsWrap = 2130969263;
    
    public static final int flow_padding = 2130969264;
    
    public static final int flow_verticalAlign = 2130969265;
    
    public static final int flow_verticalBias = 2130969266;
    
    public static final int flow_verticalGap = 2130969267;
    
    public static final int flow_verticalStyle = 2130969268;
    
    public static final int flow_wrapMode = 2130969269;
    
    public static final int font = 2130969273;
    
    public static final int fontFamily = 2130969274;
    
    public static final int fontProviderAuthority = 2130969275;
    
    public static final int fontProviderCerts = 2130969276;
    
    public static final int fontProviderFetchStrategy = 2130969277;
    
    public static final int fontProviderFetchTimeout = 2130969278;
    
    public static final int fontProviderPackage = 2130969279;
    
    public static final int fontProviderQuery = 2130969280;
    
    public static final int fontStyle = 2130969282;
    
    public static final int fontVariationSettings = 2130969283;
    
    public static final int fontWeight = 2130969284;
    
    public static final int framePosition = 2130969288;
    
    public static final int gapBetweenBars = 2130969290;
    
    public static final int goIcon = 2130969293;
    
    public static final int guidelineUseRtl = 2130969299;
    
    public static final int height = 2130969303;
    
    public static final int hideOnContentScroll = 2130969312;
    
    public static final int homeAsUpIndicator = 2130969318;
    
    public static final int homeLayout = 2130969319;
    
    public static final int icon = 2130969323;
    
    public static final int iconTint = 2130969329;
    
    public static final int iconTintMode = 2130969330;
    
    public static final int iconifiedByDefault = 2130969331;
    
    public static final int ifTagNotSet = 2130969332;
    
    public static final int ifTagSet = 2130969333;
    
    public static final int imageButtonStyle = 2130969336;
    
    public static final int imagePanX = 2130969337;
    
    public static final int imagePanY = 2130969338;
    
    public static final int imageRotate = 2130969339;
    
    public static final int imageZoom = 2130969340;
    
    public static final int indeterminateProgressStyle = 2130969343;
    
    public static final int initialActivityCount = 2130969349;
    
    public static final int isLightTheme = 2130969351;
    
    public static final int itemPadding = 2130969404;
    
    public static final int keyPositionType = 2130969424;
    
    public static final int lastBaselineToBottomHeight = 2130969431;
    
    public static final int layout = 2130969433;
    
    public static final int layoutDescription = 2130969434;
    
    public static final int layoutDuringTransition = 2130969435;
    
    public static final int layout_constrainedHeight = 2130969443;
    
    public static final int layout_constrainedWidth = 2130969444;
    
    public static final int layout_constraintBaseline_creator = 2130969445;
    
    public static final int layout_constraintBaseline_toBaselineOf = 2130969446;
    
    public static final int layout_constraintBaseline_toBottomOf = 2130969447;
    
    public static final int layout_constraintBaseline_toTopOf = 2130969448;
    
    public static final int layout_constraintBottom_creator = 2130969449;
    
    public static final int layout_constraintBottom_toBottomOf = 2130969450;
    
    public static final int layout_constraintBottom_toTopOf = 2130969451;
    
    public static final int layout_constraintCircle = 2130969452;
    
    public static final int layout_constraintCircleAngle = 2130969453;
    
    public static final int layout_constraintCircleRadius = 2130969454;
    
    public static final int layout_constraintDimensionRatio = 2130969455;
    
    public static final int layout_constraintEnd_toEndOf = 2130969456;
    
    public static final int layout_constraintEnd_toStartOf = 2130969457;
    
    public static final int layout_constraintGuide_begin = 2130969458;
    
    public static final int layout_constraintGuide_end = 2130969459;
    
    public static final int layout_constraintGuide_percent = 2130969460;
    
    public static final int layout_constraintHeight = 2130969461;
    
    public static final int layout_constraintHeight_default = 2130969462;
    
    public static final int layout_constraintHeight_max = 2130969463;
    
    public static final int layout_constraintHeight_min = 2130969464;
    
    public static final int layout_constraintHeight_percent = 2130969465;
    
    public static final int layout_constraintHorizontal_bias = 2130969466;
    
    public static final int layout_constraintHorizontal_chainStyle = 2130969467;
    
    public static final int layout_constraintHorizontal_weight = 2130969468;
    
    public static final int layout_constraintLeft_creator = 2130969469;
    
    public static final int layout_constraintLeft_toLeftOf = 2130969470;
    
    public static final int layout_constraintLeft_toRightOf = 2130969471;
    
    public static final int layout_constraintRight_creator = 2130969472;
    
    public static final int layout_constraintRight_toLeftOf = 2130969473;
    
    public static final int layout_constraintRight_toRightOf = 2130969474;
    
    public static final int layout_constraintStart_toEndOf = 2130969475;
    
    public static final int layout_constraintStart_toStartOf = 2130969476;
    
    public static final int layout_constraintTag = 2130969477;
    
    public static final int layout_constraintTop_creator = 2130969478;
    
    public static final int layout_constraintTop_toBottomOf = 2130969479;
    
    public static final int layout_constraintTop_toTopOf = 2130969480;
    
    public static final int layout_constraintVertical_bias = 2130969481;
    
    public static final int layout_constraintVertical_chainStyle = 2130969482;
    
    public static final int layout_constraintVertical_weight = 2130969483;
    
    public static final int layout_constraintWidth = 2130969484;
    
    public static final int layout_constraintWidth_default = 2130969485;
    
    public static final int layout_constraintWidth_max = 2130969486;
    
    public static final int layout_constraintWidth_min = 2130969487;
    
    public static final int layout_constraintWidth_percent = 2130969488;
    
    public static final int layout_editor_absoluteX = 2130969490;
    
    public static final int layout_editor_absoluteY = 2130969491;
    
    public static final int layout_goneMarginBaseline = 2130969495;
    
    public static final int layout_goneMarginBottom = 2130969496;
    
    public static final int layout_goneMarginEnd = 2130969497;
    
    public static final int layout_goneMarginLeft = 2130969498;
    
    public static final int layout_goneMarginRight = 2130969499;
    
    public static final int layout_goneMarginStart = 2130969500;
    
    public static final int layout_goneMarginTop = 2130969501;
    
    public static final int layout_marginBaseline = 2130969504;
    
    public static final int layout_optimizationLevel = 2130969509;
    
    public static final int layout_wrapBehaviorInParent = 2130969517;
    
    public static final int limitBoundsTo = 2130969522;
    
    public static final int lineHeight = 2130969523;
    
    public static final int listChoiceBackgroundIndicator = 2130969526;
    
    public static final int listChoiceIndicatorMultipleAnimated = 2130969527;
    
    public static final int listChoiceIndicatorSingleAnimated = 2130969528;
    
    public static final int listDividerAlertDialog = 2130969529;
    
    public static final int listItemLayout = 2130969530;
    
    public static final int listLayout = 2130969531;
    
    public static final int listMenuViewStyle = 2130969532;
    
    public static final int listPopupWindowStyle = 2130969533;
    
    public static final int listPreferredItemHeight = 2130969534;
    
    public static final int listPreferredItemHeightLarge = 2130969535;
    
    public static final int listPreferredItemHeightSmall = 2130969536;
    
    public static final int listPreferredItemPaddingEnd = 2130969537;
    
    public static final int listPreferredItemPaddingLeft = 2130969538;
    
    public static final int listPreferredItemPaddingRight = 2130969539;
    
    public static final int listPreferredItemPaddingStart = 2130969540;
    
    public static final int logo = 2130969542;
    
    public static final int logoDescription = 2130969544;
    
    public static final int maxAcceleration = 2130969628;
    
    public static final int maxButtonHeight = 2130969630;
    
    public static final int maxHeight = 2130969632;
    
    public static final int maxVelocity = 2130969637;
    
    public static final int maxWidth = 2130969638;
    
    public static final int measureWithLargestChild = 2130969662;
    
    public static final int menu = 2130969663;
    
    public static final int methodName = 2130969666;
    
    public static final int minHeight = 2130969672;
    
    public static final int minWidth = 2130969677;
    
    public static final int mock_diagonalsColor = 2130969678;
    
    public static final int mock_label = 2130969679;
    
    public static final int mock_labelBackgroundColor = 2130969680;
    
    public static final int mock_labelColor = 2130969681;
    
    public static final int mock_showDiagonals = 2130969682;
    
    public static final int mock_showLabel = 2130969683;
    
    public static final int motionDebug = 2130969684;
    
    public static final int motionEffect_alpha = 2130969713;
    
    public static final int motionEffect_end = 2130969714;
    
    public static final int motionEffect_move = 2130969715;
    
    public static final int motionEffect_start = 2130969716;
    
    public static final int motionEffect_strict = 2130969717;
    
    public static final int motionEffect_translationX = 2130969718;
    
    public static final int motionEffect_translationY = 2130969719;
    
    public static final int motionEffect_viewTransition = 2130969720;
    
    public static final int motionInterpolator = 2130969721;
    
    public static final int motionPathRotate = 2130969723;
    
    public static final int motionProgress = 2130969724;
    
    public static final int motionStagger = 2130969725;
    
    public static final int motionTarget = 2130969726;
    
    public static final int motion_postLayoutCollision = 2130969727;
    
    public static final int motion_triggerOnCollision = 2130969728;
    
    public static final int moveWhenScrollAtTop = 2130969729;
    
    public static final int multiChoiceItemLayout = 2130969730;
    
    public static final int navigationContentDescription = 2130969737;
    
    public static final int navigationIcon = 2130969738;
    
    public static final int navigationMode = 2130969740;
    
    public static final int nestedScrollFlags = 2130969743;
    
    public static final int numericModifiers = 2130969758;
    
    public static final int onCross = 2130969760;
    
    public static final int onHide = 2130969761;
    
    public static final int onNegativeCross = 2130969762;
    
    public static final int onPositiveCross = 2130969763;
    
    public static final int onShow = 2130969764;
    
    public static final int onStateTransition = 2130969765;
    
    public static final int onTouchUp = 2130969766;
    
    public static final int overlapAnchor = 2130969767;
    
    public static final int overlay = 2130969768;
    
    public static final int paddingBottomNoButtons = 2130969769;
    
    public static final int paddingEnd = 2130969771;
    
    public static final int paddingStart = 2130969774;
    
    public static final int paddingTopNoTitle = 2130969775;
    
    public static final int panelBackground = 2130969781;
    
    public static final int panelMenuListTheme = 2130969782;
    
    public static final int panelMenuListWidth = 2130969783;
    
    public static final int pathMotionArc = 2130969789;
    
    public static final int path_percent = 2130969790;
    
    public static final int percentHeight = 2130969791;
    
    public static final int percentWidth = 2130969792;
    
    public static final int percentX = 2130969793;
    
    public static final int percentY = 2130969794;
    
    public static final int perpendicularPath_percent = 2130969795;
    
    public static final int pivotAnchor = 2130969796;
    
    public static final int placeholder_emptyVisibility = 2130969800;
    
    public static final int polarRelativeTo = 2130969801;
    
    public static final int popupMenuStyle = 2130969803;
    
    public static final int popupTheme = 2130969805;
    
    public static final int popupWindowStyle = 2130969806;
    
    public static final int preserveIconSpacing = 2130969810;
    
    public static final int progressBarPadding = 2130969812;
    
    public static final int progressBarStyle = 2130969813;
    
    public static final int quantizeMotionInterpolator = 2130969817;
    
    public static final int quantizeMotionPhase = 2130969818;
    
    public static final int quantizeMotionSteps = 2130969819;
    
    public static final int queryBackground = 2130969820;
    
    public static final int queryHint = 2130969821;
    
    public static final int radioButtonStyle = 2130969824;
    
    public static final int ratingBarStyle = 2130969826;
    
    public static final int ratingBarStyleIndicator = 2130969827;
    
    public static final int ratingBarStyleSmall = 2130969828;
    
    public static final int reactiveGuide_animateChange = 2130969829;
    
    public static final int reactiveGuide_applyToAllConstraintSets = 2130969830;
    
    public static final int reactiveGuide_applyToConstraintSet = 2130969831;
    
    public static final int reactiveGuide_valueId = 2130969832;
    
    public static final int region_heightLessThan = 2130969840;
    
    public static final int region_heightMoreThan = 2130969841;
    
    public static final int region_widthLessThan = 2130969842;
    
    public static final int region_widthMoreThan = 2130969843;
    
    public static final int rotationCenterId = 2130969860;
    
    public static final int round = 2130969861;
    
    public static final int roundPercent = 2130969862;
    
    public static final int saturation = 2130969863;
    
    public static final int scaleFromTextSize = 2130969864;
    
    public static final int searchHintIcon = 2130969870;
    
    public static final int searchIcon = 2130969871;
    
    public static final int searchViewStyle = 2130969873;
    
    public static final int seekBarStyle = 2130969874;
    
    public static final int selectableItemBackground = 2130969875;
    
    public static final int selectableItemBackgroundBorderless = 2130969876;
    
    public static final int setsTag = 2130969882;
    
    public static final int showAsAction = 2130969897;
    
    public static final int showDividers = 2130969902;
    
    public static final int showPaths = 2130969904;
    
    public static final int showText = 2130969905;
    
    public static final int showTitle = 2130969906;
    
    public static final int singleChoiceItemLayout = 2130969914;
    
    public static final int sizePercent = 2130969917;
    
    public static final int spinBars = 2130969923;
    
    public static final int spinnerDropDownItemStyle = 2130969924;
    
    public static final int spinnerStyle = 2130969925;
    
    public static final int splitTrack = 2130969926;
    
    public static final int springBoundary = 2130969927;
    
    public static final int springDamping = 2130969928;
    
    public static final int springMass = 2130969929;
    
    public static final int springStiffness = 2130969930;
    
    public static final int springStopThreshold = 2130969931;
    
    public static final int srcCompat = 2130969933;
    
    public static final int staggered = 2130970005;
    
    public static final int state_above_anchor = 2130970014;
    
    public static final int subMenuArrow = 2130970029;
    
    public static final int submitBackground = 2130970034;
    
    public static final int subtitle = 2130970035;
    
    public static final int subtitleTextAppearance = 2130970037;
    
    public static final int subtitleTextColor = 2130970038;
    
    public static final int subtitleTextStyle = 2130970039;
    
    public static final int suggestionRowLayout = 2130970043;
    
    public static final int switchMinWidth = 2130970045;
    
    public static final int switchPadding = 2130970046;
    
    public static final int switchStyle = 2130970047;
    
    public static final int switchTextAppearance = 2130970048;
    
    public static final int targetId = 2130970078;
    
    public static final int telltales_tailColor = 2130970079;
    
    public static final int telltales_tailScale = 2130970080;
    
    public static final int telltales_velocityMode = 2130970081;
    
    public static final int textAllCaps = 2130970082;
    
    public static final int textAppearanceLargePopupMenu = 2130970105;
    
    public static final int textAppearanceListItem = 2130970107;
    
    public static final int textAppearanceListItemSecondary = 2130970108;
    
    public static final int textAppearanceListItemSmall = 2130970109;
    
    public static final int textAppearancePopupMenuHeader = 2130970111;
    
    public static final int textAppearanceSearchResultSubtitle = 2130970112;
    
    public static final int textAppearanceSearchResultTitle = 2130970113;
    
    public static final int textAppearanceSmallPopupMenu = 2130970114;
    
    public static final int textBackground = 2130970120;
    
    public static final int textBackgroundPanX = 2130970121;
    
    public static final int textBackgroundPanY = 2130970122;
    
    public static final int textBackgroundRotate = 2130970123;
    
    public static final int textBackgroundZoom = 2130970124;
    
    public static final int textColorAlertDialogListItem = 2130970126;
    
    public static final int textColorSearchUrl = 2130970127;
    
    public static final int textFillColor = 2130970129;
    
    public static final int textLocale = 2130970138;
    
    public static final int textOutlineColor = 2130970139;
    
    public static final int textOutlineThickness = 2130970140;
    
    public static final int textPanX = 2130970141;
    
    public static final int textPanY = 2130970142;
    
    public static final int textureBlurFactor = 2130970147;
    
    public static final int textureEffect = 2130970148;
    
    public static final int textureHeight = 2130970149;
    
    public static final int textureWidth = 2130970150;
    
    public static final int theme = 2130970151;
    
    public static final int thickness = 2130970152;
    
    public static final int thumbTextPadding = 2130970161;
    
    public static final int thumbTint = 2130970162;
    
    public static final int thumbTintMode = 2130970163;
    
    public static final int tickMark = 2130970167;
    
    public static final int tickMarkTint = 2130970168;
    
    public static final int tickMarkTintMode = 2130970169;
    
    public static final int tint = 2130970174;
    
    public static final int tintMode = 2130970175;
    
    public static final int title = 2130970177;
    
    public static final int titleMargin = 2130970181;
    
    public static final int titleMarginBottom = 2130970182;
    
    public static final int titleMarginEnd = 2130970183;
    
    public static final int titleMarginStart = 2130970184;
    
    public static final int titleMarginTop = 2130970185;
    
    public static final int titleMargins = 2130970186;
    
    public static final int titleTextAppearance = 2130970188;
    
    public static final int titleTextColor = 2130970189;
    
    public static final int titleTextStyle = 2130970191;
    
    public static final int toolbarNavigationButtonStyle = 2130970232;
    
    public static final int toolbarStyle = 2130970233;
    
    public static final int tooltipForegroundColor = 2130970235;
    
    public static final int tooltipFrameBackground = 2130970236;
    
    public static final int tooltipText = 2130970238;
    
    public static final int touchAnchorId = 2130970240;
    
    public static final int touchAnchorSide = 2130970241;
    
    public static final int touchRegionId = 2130970243;
    
    public static final int track = 2130970244;
    
    public static final int trackTint = 2130970254;
    
    public static final int trackTintMode = 2130970255;
    
    public static final int transformPivotTarget = 2130970256;
    
    public static final int transitionDisable = 2130970257;
    
    public static final int transitionEasing = 2130970258;
    
    public static final int transitionFlags = 2130970259;
    
    public static final int transitionPathRotate = 2130970260;
    
    public static final int triggerId = 2130970262;
    
    public static final int triggerReceiver = 2130970263;
    
    public static final int triggerSlack = 2130970264;
    
    public static final int ttcIndex = 2130970265;
    
    public static final int upDuration = 2130970282;
    
    public static final int viewInflaterClass = 2130970291;
    
    public static final int viewTransitionMode = 2130970292;
    
    public static final int viewTransitionOnCross = 2130970293;
    
    public static final int viewTransitionOnNegativeCross = 2130970294;
    
    public static final int viewTransitionOnPositiveCross = 2130970295;
    
    public static final int visibilityMode = 2130970296;
    
    public static final int voiceIcon = 2130970297;
    
    public static final int warmth = 2130970305;
    
    public static final int waveDecay = 2130970306;
    
    public static final int waveOffset = 2130970307;
    
    public static final int wavePeriod = 2130970308;
    
    public static final int wavePhase = 2130970309;
    
    public static final int waveShape = 2130970310;
    
    public static final int waveVariesBy = 2130970311;
    
    public static final int windowActionBar = 2130970312;
    
    public static final int windowActionBarOverlay = 2130970313;
    
    public static final int windowActionModeOverlay = 2130970314;
    
    public static final int windowFixedHeightMajor = 2130970315;
    
    public static final int windowFixedHeightMinor = 2130970316;
    
    public static final int windowFixedWidthMajor = 2130970317;
    
    public static final int windowFixedWidthMinor = 2130970318;
    
    public static final int windowMinWidthMajor = 2130970319;
    
    public static final int windowMinWidthMinor = 2130970320;
    
    public static final int windowNoTitle = 2130970321;
  }
  
  public static final class bool {
    public static final int abc_action_bar_embed_tabs = 2131034112;
    
    public static final int abc_config_actionMenuItemAllCaps = 2131034113;
  }
  
  public static final class color {
    public static final int abc_background_cache_hint_selector_material_dark = 2131099655;
    
    public static final int abc_background_cache_hint_selector_material_light = 2131099656;
    
    public static final int abc_btn_colored_borderless_text_material = 2131099657;
    
    public static final int abc_btn_colored_text_material = 2131099658;
    
    public static final int abc_color_highlight_material = 2131099659;
    
    public static final int abc_decor_view_status_guard = 2131099660;
    
    public static final int abc_decor_view_status_guard_light = 2131099661;
    
    public static final int abc_hint_foreground_material_dark = 2131099662;
    
    public static final int abc_hint_foreground_material_light = 2131099663;
    
    public static final int abc_primary_text_disable_only_material_dark = 2131099664;
    
    public static final int abc_primary_text_disable_only_material_light = 2131099665;
    
    public static final int abc_primary_text_material_dark = 2131099666;
    
    public static final int abc_primary_text_material_light = 2131099667;
    
    public static final int abc_search_url_text = 2131099668;
    
    public static final int abc_search_url_text_normal = 2131099669;
    
    public static final int abc_search_url_text_pressed = 2131099670;
    
    public static final int abc_search_url_text_selected = 2131099671;
    
    public static final int abc_secondary_text_material_dark = 2131099672;
    
    public static final int abc_secondary_text_material_light = 2131099673;
    
    public static final int abc_tint_btn_checkable = 2131099674;
    
    public static final int abc_tint_default = 2131099675;
    
    public static final int abc_tint_edittext = 2131099676;
    
    public static final int abc_tint_seek_thumb = 2131099677;
    
    public static final int abc_tint_spinner = 2131099678;
    
    public static final int abc_tint_switch_track = 2131099679;
    
    public static final int accent_material_dark = 2131099680;
    
    public static final int accent_material_light = 2131099681;
    
    public static final int androidx_core_ripple_material_light = 2131099691;
    
    public static final int androidx_core_secondary_text_default_material_light = 2131099692;
    
    public static final int background_floating_material_dark = 2131099719;
    
    public static final int background_floating_material_light = 2131099720;
    
    public static final int background_material_dark = 2131099721;
    
    public static final int background_material_light = 2131099722;
    
    public static final int bright_foreground_disabled_material_dark = 2131099776;
    
    public static final int bright_foreground_disabled_material_light = 2131099777;
    
    public static final int bright_foreground_inverse_material_dark = 2131099778;
    
    public static final int bright_foreground_inverse_material_light = 2131099779;
    
    public static final int bright_foreground_material_dark = 2131099780;
    
    public static final int bright_foreground_material_light = 2131099781;
    
    public static final int button_material_dark = 2131099786;
    
    public static final int button_material_light = 2131099787;
    
    public static final int dim_foreground_disabled_material_dark = 2131099877;
    
    public static final int dim_foreground_disabled_material_light = 2131099878;
    
    public static final int dim_foreground_material_dark = 2131099879;
    
    public static final int dim_foreground_material_light = 2131099880;
    
    public static final int error_color_material_dark = 2131099882;
    
    public static final int error_color_material_light = 2131099883;
    
    public static final int foreground_material_dark = 2131099885;
    
    public static final int foreground_material_light = 2131099886;
    
    public static final int highlighted_text_material_dark = 2131099919;
    
    public static final int highlighted_text_material_light = 2131099920;
    
    public static final int material_blue_grey_800 = 2131100351;
    
    public static final int material_blue_grey_900 = 2131100352;
    
    public static final int material_blue_grey_950 = 2131100353;
    
    public static final int material_deep_teal_200 = 2131100355;
    
    public static final int material_deep_teal_500 = 2131100356;
    
    public static final int material_grey_100 = 2131100423;
    
    public static final int material_grey_300 = 2131100424;
    
    public static final int material_grey_50 = 2131100425;
    
    public static final int material_grey_600 = 2131100426;
    
    public static final int material_grey_800 = 2131100427;
    
    public static final int material_grey_850 = 2131100428;
    
    public static final int material_grey_900 = 2131100429;
    
    public static final int notification_action_color_filter = 2131100632;
    
    public static final int notification_icon_bg_color = 2131100633;
    
    public static final int primary_dark_material_dark = 2131100654;
    
    public static final int primary_dark_material_light = 2131100655;
    
    public static final int primary_material_dark = 2131100656;
    
    public static final int primary_material_light = 2131100657;
    
    public static final int primary_text_default_material_dark = 2131100658;
    
    public static final int primary_text_default_material_light = 2131100659;
    
    public static final int primary_text_disabled_material_dark = 2131100660;
    
    public static final int primary_text_disabled_material_light = 2131100661;
    
    public static final int ripple_material_dark = 2131100757;
    
    public static final int ripple_material_light = 2131100758;
    
    public static final int secondary_text_default_material_dark = 2131100759;
    
    public static final int secondary_text_default_material_light = 2131100760;
    
    public static final int secondary_text_disabled_material_dark = 2131100761;
    
    public static final int secondary_text_disabled_material_light = 2131100762;
    
    public static final int switch_thumb_disabled_material_dark = 2131100772;
    
    public static final int switch_thumb_disabled_material_light = 2131100773;
    
    public static final int switch_thumb_material_dark = 2131100774;
    
    public static final int switch_thumb_material_light = 2131100775;
    
    public static final int switch_thumb_normal_material_dark = 2131100776;
    
    public static final int switch_thumb_normal_material_light = 2131100777;
    
    public static final int tooltip_background_dark = 2131100783;
    
    public static final int tooltip_background_light = 2131100784;
  }
  
  public static final class dimen {
    public static final int abc_action_bar_content_inset_material = 2131165184;
    
    public static final int abc_action_bar_content_inset_with_nav = 2131165185;
    
    public static final int abc_action_bar_default_height_material = 2131165186;
    
    public static final int abc_action_bar_default_padding_end_material = 2131165187;
    
    public static final int abc_action_bar_default_padding_start_material = 2131165188;
    
    public static final int abc_action_bar_elevation_material = 2131165189;
    
    public static final int abc_action_bar_icon_vertical_padding_material = 2131165190;
    
    public static final int abc_action_bar_overflow_padding_end_material = 2131165191;
    
    public static final int abc_action_bar_overflow_padding_start_material = 2131165192;
    
    public static final int abc_action_bar_stacked_max_height = 2131165193;
    
    public static final int abc_action_bar_stacked_tab_max_width = 2131165194;
    
    public static final int abc_action_bar_subtitle_bottom_margin_material = 2131165195;
    
    public static final int abc_action_bar_subtitle_top_margin_material = 2131165196;
    
    public static final int abc_action_button_min_height_material = 2131165197;
    
    public static final int abc_action_button_min_width_material = 2131165198;
    
    public static final int abc_action_button_min_width_overflow_material = 2131165199;
    
    public static final int abc_alert_dialog_button_bar_height = 2131165200;
    
    public static final int abc_alert_dialog_button_dimen = 2131165201;
    
    public static final int abc_button_inset_horizontal_material = 2131165202;
    
    public static final int abc_button_inset_vertical_material = 2131165203;
    
    public static final int abc_button_padding_horizontal_material = 2131165204;
    
    public static final int abc_button_padding_vertical_material = 2131165205;
    
    public static final int abc_cascading_menus_min_smallest_width = 2131165206;
    
    public static final int abc_config_prefDialogWidth = 2131165207;
    
    public static final int abc_control_corner_material = 2131165208;
    
    public static final int abc_control_inset_material = 2131165209;
    
    public static final int abc_control_padding_material = 2131165210;
    
    public static final int abc_dialog_corner_radius_material = 2131165211;
    
    public static final int abc_dialog_fixed_height_major = 2131165212;
    
    public static final int abc_dialog_fixed_height_minor = 2131165213;
    
    public static final int abc_dialog_fixed_width_major = 2131165214;
    
    public static final int abc_dialog_fixed_width_minor = 2131165215;
    
    public static final int abc_dialog_list_padding_bottom_no_buttons = 2131165216;
    
    public static final int abc_dialog_list_padding_top_no_title = 2131165217;
    
    public static final int abc_dialog_min_width_major = 2131165218;
    
    public static final int abc_dialog_min_width_minor = 2131165219;
    
    public static final int abc_dialog_padding_material = 2131165220;
    
    public static final int abc_dialog_padding_top_material = 2131165221;
    
    public static final int abc_dialog_title_divider_material = 2131165222;
    
    public static final int abc_disabled_alpha_material_dark = 2131165223;
    
    public static final int abc_disabled_alpha_material_light = 2131165224;
    
    public static final int abc_dropdownitem_icon_width = 2131165225;
    
    public static final int abc_dropdownitem_text_padding_left = 2131165226;
    
    public static final int abc_dropdownitem_text_padding_right = 2131165227;
    
    public static final int abc_edit_text_inset_bottom_material = 2131165228;
    
    public static final int abc_edit_text_inset_horizontal_material = 2131165229;
    
    public static final int abc_edit_text_inset_top_material = 2131165230;
    
    public static final int abc_floating_window_z = 2131165231;
    
    public static final int abc_list_item_height_large_material = 2131165232;
    
    public static final int abc_list_item_height_material = 2131165233;
    
    public static final int abc_list_item_height_small_material = 2131165234;
    
    public static final int abc_list_item_padding_horizontal_material = 2131165235;
    
    public static final int abc_panel_menu_list_width = 2131165236;
    
    public static final int abc_progress_bar_height_material = 2131165237;
    
    public static final int abc_search_view_preferred_height = 2131165238;
    
    public static final int abc_search_view_preferred_width = 2131165239;
    
    public static final int abc_seekbar_track_background_height_material = 2131165240;
    
    public static final int abc_seekbar_track_progress_height_material = 2131165241;
    
    public static final int abc_select_dialog_padding_start_material = 2131165242;
    
    public static final int abc_switch_padding = 2131165246;
    
    public static final int abc_text_size_body_1_material = 2131165247;
    
    public static final int abc_text_size_body_2_material = 2131165248;
    
    public static final int abc_text_size_button_material = 2131165249;
    
    public static final int abc_text_size_caption_material = 2131165250;
    
    public static final int abc_text_size_display_1_material = 2131165251;
    
    public static final int abc_text_size_display_2_material = 2131165252;
    
    public static final int abc_text_size_display_3_material = 2131165253;
    
    public static final int abc_text_size_display_4_material = 2131165254;
    
    public static final int abc_text_size_headline_material = 2131165255;
    
    public static final int abc_text_size_large_material = 2131165256;
    
    public static final int abc_text_size_medium_material = 2131165257;
    
    public static final int abc_text_size_menu_header_material = 2131165258;
    
    public static final int abc_text_size_menu_material = 2131165259;
    
    public static final int abc_text_size_small_material = 2131165260;
    
    public static final int abc_text_size_subhead_material = 2131165261;
    
    public static final int abc_text_size_subtitle_material_toolbar = 2131165262;
    
    public static final int abc_text_size_title_material = 2131165263;
    
    public static final int abc_text_size_title_material_toolbar = 2131165264;
    
    public static final int compat_button_inset_horizontal_material = 2131165318;
    
    public static final int compat_button_inset_vertical_material = 2131165319;
    
    public static final int compat_button_padding_horizontal_material = 2131165320;
    
    public static final int compat_button_padding_vertical_material = 2131165321;
    
    public static final int compat_control_corner_material = 2131165322;
    
    public static final int compat_notification_large_icon_max_height = 2131165323;
    
    public static final int compat_notification_large_icon_max_width = 2131165324;
    
    public static final int disabled_alpha_material_dark = 2131165376;
    
    public static final int disabled_alpha_material_light = 2131165377;
    
    public static final int highlight_alpha_material_colored = 2131165768;
    
    public static final int highlight_alpha_material_dark = 2131165769;
    
    public static final int highlight_alpha_material_light = 2131165770;
    
    public static final int hint_alpha_material_dark = 2131165771;
    
    public static final int hint_alpha_material_light = 2131165772;
    
    public static final int hint_pressed_alpha_material_dark = 2131165773;
    
    public static final int hint_pressed_alpha_material_light = 2131165774;
    
    public static final int notification_action_icon_size = 2131166423;
    
    public static final int notification_action_text_size = 2131166424;
    
    public static final int notification_big_circle_margin = 2131166425;
    
    public static final int notification_content_margin_start = 2131166426;
    
    public static final int notification_large_icon_height = 2131166427;
    
    public static final int notification_large_icon_width = 2131166428;
    
    public static final int notification_main_column_padding_top = 2131166429;
    
    public static final int notification_media_narrow_margin = 2131166430;
    
    public static final int notification_right_icon_size = 2131166431;
    
    public static final int notification_right_side_padding_top = 2131166432;
    
    public static final int notification_small_icon_background_padding = 2131166433;
    
    public static final int notification_small_icon_size_as_large = 2131166434;
    
    public static final int notification_subtext_size = 2131166435;
    
    public static final int notification_top_pad = 2131166436;
    
    public static final int notification_top_pad_large_text = 2131166437;
    
    public static final int tooltip_corner_radius = 2131166481;
    
    public static final int tooltip_horizontal_padding = 2131166482;
    
    public static final int tooltip_margin = 2131166483;
    
    public static final int tooltip_precise_anchor_extra_offset = 2131166484;
    
    public static final int tooltip_precise_anchor_threshold = 2131166485;
    
    public static final int tooltip_vertical_padding = 2131166486;
    
    public static final int tooltip_y_offset_non_touch = 2131166487;
    
    public static final int tooltip_y_offset_touch = 2131166488;
  }
  
  public static final class drawable {
    public static final int abc_ab_share_pack_mtrl_alpha = 2131230787;
    
    public static final int abc_action_bar_item_background_material = 2131230788;
    
    public static final int abc_btn_borderless_material = 2131230789;
    
    public static final int abc_btn_check_material = 2131230790;
    
    public static final int abc_btn_check_material_anim = 2131230791;
    
    public static final int abc_btn_check_to_on_mtrl_000 = 2131230792;
    
    public static final int abc_btn_check_to_on_mtrl_015 = 2131230793;
    
    public static final int abc_btn_colored_material = 2131230794;
    
    public static final int abc_btn_default_mtrl_shape = 2131230795;
    
    public static final int abc_btn_radio_material = 2131230796;
    
    public static final int abc_btn_radio_material_anim = 2131230797;
    
    public static final int abc_btn_radio_to_on_mtrl_000 = 2131230798;
    
    public static final int abc_btn_radio_to_on_mtrl_015 = 2131230799;
    
    public static final int abc_btn_switch_to_on_mtrl_00001 = 2131230800;
    
    public static final int abc_btn_switch_to_on_mtrl_00012 = 2131230801;
    
    public static final int abc_cab_background_internal_bg = 2131230802;
    
    public static final int abc_cab_background_top_material = 2131230803;
    
    public static final int abc_cab_background_top_mtrl_alpha = 2131230804;
    
    public static final int abc_control_background_material = 2131230805;
    
    public static final int abc_dialog_material_background = 2131230806;
    
    public static final int abc_edit_text_material = 2131230807;
    
    public static final int abc_ic_ab_back_material = 2131230808;
    
    public static final int abc_ic_arrow_drop_right_black_24dp = 2131230809;
    
    public static final int abc_ic_clear_material = 2131230810;
    
    public static final int abc_ic_commit_search_api_mtrl_alpha = 2131230811;
    
    public static final int abc_ic_go_search_api_material = 2131230812;
    
    public static final int abc_ic_menu_copy_mtrl_am_alpha = 2131230813;
    
    public static final int abc_ic_menu_cut_mtrl_alpha = 2131230814;
    
    public static final int abc_ic_menu_overflow_material = 2131230815;
    
    public static final int abc_ic_menu_paste_mtrl_am_alpha = 2131230816;
    
    public static final int abc_ic_menu_selectall_mtrl_alpha = 2131230817;
    
    public static final int abc_ic_menu_share_mtrl_alpha = 2131230818;
    
    public static final int abc_ic_search_api_material = 2131230819;
    
    public static final int abc_ic_voice_search_api_material = 2131230820;
    
    public static final int abc_item_background_holo_dark = 2131230821;
    
    public static final int abc_item_background_holo_light = 2131230822;
    
    public static final int abc_list_divider_material = 2131230823;
    
    public static final int abc_list_divider_mtrl_alpha = 2131230824;
    
    public static final int abc_list_focused_holo = 2131230825;
    
    public static final int abc_list_longpressed_holo = 2131230826;
    
    public static final int abc_list_pressed_holo_dark = 2131230827;
    
    public static final int abc_list_pressed_holo_light = 2131230828;
    
    public static final int abc_list_selector_background_transition_holo_dark = 2131230829;
    
    public static final int abc_list_selector_background_transition_holo_light = 2131230830;
    
    public static final int abc_list_selector_disabled_holo_dark = 2131230831;
    
    public static final int abc_list_selector_disabled_holo_light = 2131230832;
    
    public static final int abc_list_selector_holo_dark = 2131230833;
    
    public static final int abc_list_selector_holo_light = 2131230834;
    
    public static final int abc_menu_hardkey_panel_mtrl_mult = 2131230835;
    
    public static final int abc_popup_background_mtrl_mult = 2131230836;
    
    public static final int abc_ratingbar_indicator_material = 2131230837;
    
    public static final int abc_ratingbar_material = 2131230838;
    
    public static final int abc_ratingbar_small_material = 2131230839;
    
    public static final int abc_scrubber_control_off_mtrl_alpha = 2131230840;
    
    public static final int abc_scrubber_control_to_pressed_mtrl_000 = 2131230841;
    
    public static final int abc_scrubber_control_to_pressed_mtrl_005 = 2131230842;
    
    public static final int abc_scrubber_primary_mtrl_alpha = 2131230843;
    
    public static final int abc_scrubber_track_mtrl_alpha = 2131230844;
    
    public static final int abc_seekbar_thumb_material = 2131230845;
    
    public static final int abc_seekbar_tick_mark_material = 2131230846;
    
    public static final int abc_seekbar_track_material = 2131230847;
    
    public static final int abc_spinner_mtrl_am_alpha = 2131230848;
    
    public static final int abc_spinner_textfield_background_material = 2131230849;
    
    public static final int abc_switch_thumb_material = 2131230852;
    
    public static final int abc_switch_track_mtrl_alpha = 2131230853;
    
    public static final int abc_tab_indicator_material = 2131230854;
    
    public static final int abc_tab_indicator_mtrl_alpha = 2131230855;
    
    public static final int abc_text_cursor_material = 2131230856;
    
    public static final int abc_textfield_activated_mtrl_alpha = 2131230860;
    
    public static final int abc_textfield_default_mtrl_alpha = 2131230861;
    
    public static final int abc_textfield_search_activated_mtrl_alpha = 2131230862;
    
    public static final int abc_textfield_search_default_mtrl_alpha = 2131230863;
    
    public static final int abc_textfield_search_material = 2131230864;
    
    public static final int abc_vector_test = 2131230865;
    
    public static final int btn_checkbox_checked_mtrl = 2131231028;
    
    public static final int btn_checkbox_checked_to_unchecked_mtrl_animation = 2131231029;
    
    public static final int btn_checkbox_unchecked_mtrl = 2131231030;
    
    public static final int btn_checkbox_unchecked_to_checked_mtrl_animation = 2131231031;
    
    public static final int btn_radio_off_mtrl = 2131231040;
    
    public static final int btn_radio_off_to_on_mtrl_animation = 2131231041;
    
    public static final int btn_radio_on_mtrl = 2131231042;
    
    public static final int btn_radio_on_to_off_mtrl_animation = 2131231043;
    
    public static final int notification_action_background = 2131231550;
    
    public static final int notification_bg = 2131231551;
    
    public static final int notification_bg_low = 2131231552;
    
    public static final int notification_bg_low_normal = 2131231553;
    
    public static final int notification_bg_low_pressed = 2131231554;
    
    public static final int notification_bg_normal = 2131231555;
    
    public static final int notification_bg_normal_pressed = 2131231556;
    
    public static final int notification_icon_background = 2131231557;
    
    public static final int notification_template_icon_bg = 2131231558;
    
    public static final int notification_template_icon_low_bg = 2131231559;
    
    public static final int notification_tile_bg = 2131231560;
    
    public static final int notify_panel_notification_icon_bg = 2131231561;
    
    public static final int tooltip_frame_dark = 2131231679;
    
    public static final int tooltip_frame_light = 2131231680;
  }
  
  public static final class id {
    public static final int NO_DEBUG = 2131361821;
    
    public static final int SHOW_ALL = 2131361829;
    
    public static final int SHOW_PATH = 2131361830;
    
    public static final int SHOW_PROGRESS = 2131361831;
    
    public static final int accelerate = 2131361845;
    
    public static final int accessibility_action_clickable_span = 2131361846;
    
    public static final int accessibility_custom_action_0 = 2131361847;
    
    public static final int accessibility_custom_action_1 = 2131361848;
    
    public static final int accessibility_custom_action_10 = 2131361849;
    
    public static final int accessibility_custom_action_11 = 2131361850;
    
    public static final int accessibility_custom_action_12 = 2131361851;
    
    public static final int accessibility_custom_action_13 = 2131361852;
    
    public static final int accessibility_custom_action_14 = 2131361853;
    
    public static final int accessibility_custom_action_15 = 2131361854;
    
    public static final int accessibility_custom_action_16 = 2131361855;
    
    public static final int accessibility_custom_action_17 = 2131361856;
    
    public static final int accessibility_custom_action_18 = 2131361857;
    
    public static final int accessibility_custom_action_19 = 2131361858;
    
    public static final int accessibility_custom_action_2 = 2131361859;
    
    public static final int accessibility_custom_action_20 = 2131361860;
    
    public static final int accessibility_custom_action_21 = 2131361861;
    
    public static final int accessibility_custom_action_22 = 2131361862;
    
    public static final int accessibility_custom_action_23 = 2131361863;
    
    public static final int accessibility_custom_action_24 = 2131361864;
    
    public static final int accessibility_custom_action_25 = 2131361865;
    
    public static final int accessibility_custom_action_26 = 2131361866;
    
    public static final int accessibility_custom_action_27 = 2131361867;
    
    public static final int accessibility_custom_action_28 = 2131361868;
    
    public static final int accessibility_custom_action_29 = 2131361869;
    
    public static final int accessibility_custom_action_3 = 2131361870;
    
    public static final int accessibility_custom_action_30 = 2131361871;
    
    public static final int accessibility_custom_action_31 = 2131361872;
    
    public static final int accessibility_custom_action_4 = 2131361873;
    
    public static final int accessibility_custom_action_5 = 2131361874;
    
    public static final int accessibility_custom_action_6 = 2131361875;
    
    public static final int accessibility_custom_action_7 = 2131361876;
    
    public static final int accessibility_custom_action_8 = 2131361877;
    
    public static final int accessibility_custom_action_9 = 2131361878;
    
    public static final int actionDown = 2131361880;
    
    public static final int actionDownUp = 2131361881;
    
    public static final int actionUp = 2131361882;
    
    public static final int action_bar = 2131361883;
    
    public static final int action_bar_activity_content = 2131361884;
    
    public static final int action_bar_container = 2131361885;
    
    public static final int action_bar_root = 2131361886;
    
    public static final int action_bar_spinner = 2131361887;
    
    public static final int action_bar_subtitle = 2131361888;
    
    public static final int action_bar_title = 2131361889;
    
    public static final int action_container = 2131361890;
    
    public static final int action_context_bar = 2131361891;
    
    public static final int action_divider = 2131361892;
    
    public static final int action_image = 2131361893;
    
    public static final int action_menu_divider = 2131361894;
    
    public static final int action_menu_presenter = 2131361895;
    
    public static final int action_mode_bar = 2131361896;
    
    public static final int action_mode_bar_stub = 2131361897;
    
    public static final int action_mode_close_button = 2131361898;
    
    public static final int action_text = 2131361902;
    
    public static final int actions = 2131361903;
    
    public static final int activity_chooser_view_content = 2131361904;
    
    public static final int add = 2131361909;
    
    public static final int alertTitle = 2131361954;
    
    public static final int aligned = 2131361955;
    
    public static final int allStates = 2131361957;
    
    public static final int animateToEnd = 2131361961;
    
    public static final int animateToStart = 2131361962;
    
    public static final int antiClockwise = 2131361967;
    
    public static final int anticipate = 2131361968;
    
    public static final int asConfigured = 2131361990;
    
    public static final int async = 2131361991;
    
    public static final int auto = 2131361993;
    
    public static final int autoComplete = 2131361994;
    
    public static final int autoCompleteToEnd = 2131361995;
    
    public static final int autoCompleteToStart = 2131361996;
    
    public static final int baseline = 2131362012;
    
    public static final int bestChoice = 2131362017;
    
    public static final int blocking = 2131362019;
    
    public static final int bottom = 2131362020;
    
    public static final int bounce = 2131362026;
    
    public static final int buttonPanel = 2131362057;
    
    public static final int callMeasure = 2131362060;
    
    public static final int carryVelocity = 2131362066;
    
    public static final int center = 2131362071;
    
    public static final int chain = 2131362077;
    
    public static final int chain2 = 2131362078;
    
    public static final int checkbox = 2131362081;
    
    public static final int checked = 2131362082;
    
    public static final int chronometer = 2131362083;
    
    public static final int clockwise = 2131362092;
    
    public static final int closest = 2131362093;
    
    public static final int constraint = 2131362102;
    
    public static final int content = 2131362104;
    
    public static final int contentPanel = 2131362105;
    
    public static final int continuousVelocity = 2131362108;
    
    public static final int cos = 2131362114;
    
    public static final int currentState = 2131362120;
    
    public static final int custom = 2131362121;
    
    public static final int customPanel = 2131362122;
    
    public static final int decelerate = 2131362130;
    
    public static final int decelerateAndComplete = 2131362131;
    
    public static final int decor_content_parent = 2131362132;
    
    public static final int default_activity_button = 2131362133;
    
    public static final int deltaRelative = 2131362138;
    
    public static final int dialog_button = 2131362147;
    
    public static final int dragAnticlockwise = 2131362160;
    
    public static final int dragClockwise = 2131362161;
    
    public static final int dragDown = 2131362162;
    
    public static final int dragEnd = 2131362163;
    
    public static final int dragLeft = 2131362164;
    
    public static final int dragRight = 2131362165;
    
    public static final int dragStart = 2131362166;
    
    public static final int dragUp = 2131362167;
    
    public static final int easeIn = 2131362174;
    
    public static final int easeInOut = 2131362175;
    
    public static final int easeOut = 2131362176;
    
    public static final int east = 2131362177;
    
    public static final int edit_query = 2131362179;
    
    public static final int end = 2131362186;
    
    public static final int expand_activities_button = 2131362218;
    
    public static final int expanded_menu = 2131362220;
    
    public static final int flip = 2131362253;
    
    public static final int forever = 2131362257;
    
    public static final int frost = 2131362260;
    
    public static final int gone = 2131362272;
    
    public static final int group_divider = 2131362275;
    
    public static final int home = 2131362282;
    
    public static final int honorRequest = 2131362286;
    
    public static final int horizontal_only = 2131362288;
    
    public static final int icon = 2131362290;
    
    public static final int icon_group = 2131362291;
    
    public static final int ignore = 2131362294;
    
    public static final int ignoreRequest = 2131362295;
    
    public static final int image = 2131362296;
    
    public static final int immediateStop = 2131362309;
    
    public static final int included = 2131362310;
    
    public static final int info = 2131362314;
    
    public static final int invisible = 2131362318;
    
    public static final int italic = 2131362322;
    
    public static final int jumpToEnd = 2131362427;
    
    public static final int jumpToStart = 2131362428;
    
    public static final int layout = 2131362434;
    
    public static final int left = 2131362441;
    
    public static final int line1 = 2131362446;
    
    public static final int line3 = 2131362447;
    
    public static final int linear = 2131362449;
    
    public static final int listMode = 2131362450;
    
    public static final int list_item = 2131362452;
    
    public static final int match_constraint = 2131362561;
    
    public static final int match_parent = 2131362562;
    
    public static final int message = 2131362784;
    
    public static final int middle = 2131362786;
    
    public static final int motion_base = 2131362800;
    
    public static final int multiply = 2131362831;
    
    public static final int neverCompleteToEnd = 2131362849;
    
    public static final int neverCompleteToStart = 2131362850;
    
    public static final int noState = 2131362852;
    
    public static final int none = 2131362853;
    
    public static final int normal = 2131362854;
    
    public static final int north = 2131362855;
    
    public static final int notification_background = 2131362856;
    
    public static final int notification_main_column = 2131362857;
    
    public static final int notification_main_column_container = 2131362858;
    
    public static final int off = 2131362863;
    
    public static final int on = 2131362864;
    
    public static final int overshoot = 2131362873;
    
    public static final int packed = 2131362874;
    
    public static final int parent = 2131362877;
    
    public static final int parentPanel = 2131362878;
    
    public static final int parentRelative = 2131362879;
    
    public static final int path = 2131362884;
    
    public static final int pathRelative = 2131362885;
    
    public static final int percent = 2131362888;
    
    public static final int position = 2131362908;
    
    public static final int postLayout = 2131362910;
    
    public static final int progress_circular = 2131362919;
    
    public static final int progress_horizontal = 2131362920;
    
    public static final int radio = 2131362940;
    
    public static final int rectangles = 2131362959;
    
    public static final int reverseSawtooth = 2131362981;
    
    public static final int right = 2131362991;
    
    public static final int right_icon = 2131362993;
    
    public static final int right_side = 2131362994;
    
    public static final int sawtooth = 2131363021;
    
    public static final int screen = 2131363031;
    
    public static final int scrollIndicatorDown = 2131363033;
    
    public static final int scrollIndicatorUp = 2131363034;
    
    public static final int scrollView = 2131363035;
    
    public static final int search_badge = 2131363038;
    
    public static final int search_bar = 2131363039;
    
    public static final int search_button = 2131363041;
    
    public static final int search_close_btn = 2131363042;
    
    public static final int search_edit_frame = 2131363043;
    
    public static final int search_go_btn = 2131363044;
    
    public static final int search_mag_icon = 2131363045;
    
    public static final int search_plate = 2131363046;
    
    public static final int search_src_text = 2131363048;
    
    public static final int search_voice_btn = 2131363062;
    
    public static final int select_dialog_listview = 2131363066;
    
    public static final int sharedValueSet = 2131363070;
    
    public static final int sharedValueUnset = 2131363071;
    
    public static final int shortcut = 2131363072;
    
    public static final int sin = 2131363082;
    
    public static final int skipped = 2131363085;
    
    public static final int south = 2131363094;
    
    public static final int spacer = 2131363100;
    
    public static final int spline = 2131363107;
    
    public static final int split_action_bar = 2131363108;
    
    public static final int spread = 2131363109;
    
    public static final int spread_inside = 2131363110;
    
    public static final int spring = 2131363111;
    
    public static final int square = 2131363112;
    
    public static final int src_atop = 2131363113;
    
    public static final int src_in = 2131363114;
    
    public static final int src_over = 2131363115;
    
    public static final int standard = 2131363122;
    
    public static final int start = 2131363123;
    
    public static final int startHorizontal = 2131363124;
    
    public static final int startVertical = 2131363126;
    
    public static final int staticLayout = 2131363133;
    
    public static final int staticPostLayout = 2131363134;
    
    public static final int stop = 2131363137;
    
    public static final int submenuarrow = 2131363142;
    
    public static final int submit_area = 2131363143;
    
    public static final int tabMode = 2131363149;
    
    public static final int tag_accessibility_actions = 2131363151;
    
    public static final int tag_accessibility_clickable_spans = 2131363152;
    
    public static final int tag_accessibility_heading = 2131363153;
    
    public static final int tag_accessibility_pane_title = 2131363154;
    
    public static final int tag_screen_reader_focusable = 2131363158;
    
    public static final int tag_transition_group = 2131363160;
    
    public static final int tag_unhandled_key_event_manager = 2131363161;
    
    public static final int tag_unhandled_key_listeners = 2131363162;
    
    public static final int text = 2131363165;
    
    public static final int text2 = 2131363166;
    
    public static final int textSpacerNoButtons = 2131363168;
    
    public static final int textSpacerNoTitle = 2131363169;
    
    public static final int time = 2131363190;
    
    public static final int title = 2131363192;
    
    public static final int titleDividerNoCustom = 2131363193;
    
    public static final int title_template = 2131363196;
    
    public static final int top = 2131363201;
    
    public static final int topPanel = 2131363202;
    
    public static final int triangle = 2131363216;
    
    public static final int unchecked = 2131363402;
    
    public static final int uniform = 2131363404;
    
    public static final int up = 2131363406;
    
    public static final int vertical_only = 2131363417;
    
    public static final int view_transition = 2131363433;
    
    public static final int visible = 2131363444;
    
    public static final int west = 2131363452;
    
    public static final int wrap = 2131363459;
    
    public static final int wrap_content = 2131363460;
    
    public static final int wrap_content_constrained = 2131363461;
    
    public static final int x_left = 2131363467;
    
    public static final int x_right = 2131363468;
  }
  
  public static final class integer {
    public static final int abc_config_activityDefaultDur = 2131427328;
    
    public static final int abc_config_activityShortDur = 2131427329;
    
    public static final int cancel_button_image_alpha = 2131427334;
    
    public static final int config_tooltipAnimTime = 2131427335;
    
    public static final int status_bar_notification_info_maxnum = 2131427398;
  }
  
  public static final class interpolator {
    public static final int btn_checkbox_checked_mtrl_animation_interpolator_0 = 2131492864;
    
    public static final int btn_checkbox_checked_mtrl_animation_interpolator_1 = 2131492865;
    
    public static final int btn_checkbox_unchecked_mtrl_animation_interpolator_0 = 2131492866;
    
    public static final int btn_checkbox_unchecked_mtrl_animation_interpolator_1 = 2131492867;
    
    public static final int btn_radio_to_off_mtrl_animation_interpolator_0 = 2131492868;
    
    public static final int btn_radio_to_on_mtrl_animation_interpolator_0 = 2131492869;
    
    public static final int fast_out_slow_in = 2131492870;
  }
  
  public static final class layout {
    public static final int abc_action_bar_title_item = 2131558423;
    
    public static final int abc_action_bar_up_container = 2131558424;
    
    public static final int abc_action_menu_item_layout = 2131558425;
    
    public static final int abc_action_menu_layout = 2131558426;
    
    public static final int abc_action_mode_bar = 2131558427;
    
    public static final int abc_action_mode_close_item_material = 2131558428;
    
    public static final int abc_activity_chooser_view = 2131558429;
    
    public static final int abc_activity_chooser_view_list_item = 2131558430;
    
    public static final int abc_alert_dialog_button_bar_material = 2131558431;
    
    public static final int abc_alert_dialog_material = 2131558432;
    
    public static final int abc_alert_dialog_title_material = 2131558433;
    
    public static final int abc_cascading_menu_item_layout = 2131558434;
    
    public static final int abc_dialog_title_material = 2131558435;
    
    public static final int abc_expanded_menu_layout = 2131558436;
    
    public static final int abc_list_menu_item_checkbox = 2131558437;
    
    public static final int abc_list_menu_item_icon = 2131558438;
    
    public static final int abc_list_menu_item_layout = 2131558439;
    
    public static final int abc_list_menu_item_radio = 2131558440;
    
    public static final int abc_popup_menu_header_item_layout = 2131558441;
    
    public static final int abc_popup_menu_item_layout = 2131558442;
    
    public static final int abc_screen_content_include = 2131558443;
    
    public static final int abc_screen_simple = 2131558444;
    
    public static final int abc_screen_simple_overlay_action_mode = 2131558445;
    
    public static final int abc_screen_toolbar = 2131558446;
    
    public static final int abc_search_dropdown_item_icons_2line = 2131558447;
    
    public static final int abc_search_view = 2131558448;
    
    public static final int abc_select_dialog_material = 2131558449;
    
    public static final int abc_tooltip = 2131558450;
    
    public static final int custom_dialog = 2131558525;
    
    public static final int notification_action = 2131558805;
    
    public static final int notification_action_tombstone = 2131558806;
    
    public static final int notification_template_custom_big = 2131558813;
    
    public static final int notification_template_icon_group = 2131558814;
    
    public static final int notification_template_part_chronometer = 2131558818;
    
    public static final int notification_template_part_time = 2131558819;
    
    public static final int select_dialog_item_material = 2131558870;
    
    public static final int select_dialog_multichoice_material = 2131558871;
    
    public static final int select_dialog_singlechoice_material = 2131558872;
    
    public static final int support_simple_spinner_dropdown_item = 2131558889;
  }
  
  public static final class string {
    public static final int abc_action_bar_home_description = 2131951617;
    
    public static final int abc_action_bar_up_description = 2131951618;
    
    public static final int abc_action_menu_overflow_description = 2131951619;
    
    public static final int abc_action_mode_done = 2131951620;
    
    public static final int abc_activity_chooser_view_see_all = 2131951621;
    
    public static final int abc_activitychooserview_choose_application = 2131951622;
    
    public static final int abc_capital_off = 2131951623;
    
    public static final int abc_capital_on = 2131951624;
    
    public static final int abc_menu_alt_shortcut_label = 2131951625;
    
    public static final int abc_menu_ctrl_shortcut_label = 2131951626;
    
    public static final int abc_menu_delete_shortcut_label = 2131951627;
    
    public static final int abc_menu_enter_shortcut_label = 2131951628;
    
    public static final int abc_menu_function_shortcut_label = 2131951629;
    
    public static final int abc_menu_meta_shortcut_label = 2131951630;
    
    public static final int abc_menu_shift_shortcut_label = 2131951631;
    
    public static final int abc_menu_space_shortcut_label = 2131951632;
    
    public static final int abc_menu_sym_shortcut_label = 2131951633;
    
    public static final int abc_prepend_shortcut_label = 2131951634;
    
    public static final int abc_search_hint = 2131951635;
    
    public static final int abc_searchview_description_clear = 2131951636;
    
    public static final int abc_searchview_description_query = 2131951637;
    
    public static final int abc_searchview_description_search = 2131951638;
    
    public static final int abc_searchview_description_submit = 2131951639;
    
    public static final int abc_searchview_description_voice = 2131951640;
    
    public static final int abc_shareactionprovider_share_with = 2131951641;
    
    public static final int abc_shareactionprovider_share_with_application = 2131951642;
    
    public static final int abc_toolbar_collapse_description = 2131951643;
    
    public static final int search_menu_title = 2131952092;
    
    public static final int status_bar_notification_info_overflow = 2131952121;
  }
  
  public static final class style {
    public static final int AlertDialog_AppCompat = 2132017153;
    
    public static final int AlertDialog_AppCompat_Light = 2132017154;
    
    public static final int Animation_AppCompat_Dialog = 2132017155;
    
    public static final int Animation_AppCompat_DropDownUp = 2132017156;
    
    public static final int Animation_AppCompat_Tooltip = 2132017157;
    
    public static final int Base_AlertDialog_AppCompat = 2132017198;
    
    public static final int Base_AlertDialog_AppCompat_Light = 2132017199;
    
    public static final int Base_Animation_AppCompat_Dialog = 2132017200;
    
    public static final int Base_Animation_AppCompat_DropDownUp = 2132017201;
    
    public static final int Base_Animation_AppCompat_Tooltip = 2132017202;
    
    public static final int Base_DialogWindowTitleBackground_AppCompat = 2132017205;
    
    public static final int Base_DialogWindowTitle_AppCompat = 2132017204;
    
    public static final int Base_TextAppearance_AppCompat = 2132017209;
    
    public static final int Base_TextAppearance_AppCompat_Body1 = 2132017210;
    
    public static final int Base_TextAppearance_AppCompat_Body2 = 2132017211;
    
    public static final int Base_TextAppearance_AppCompat_Button = 2132017212;
    
    public static final int Base_TextAppearance_AppCompat_Caption = 2132017213;
    
    public static final int Base_TextAppearance_AppCompat_Display1 = 2132017214;
    
    public static final int Base_TextAppearance_AppCompat_Display2 = 2132017215;
    
    public static final int Base_TextAppearance_AppCompat_Display3 = 2132017216;
    
    public static final int Base_TextAppearance_AppCompat_Display4 = 2132017217;
    
    public static final int Base_TextAppearance_AppCompat_Headline = 2132017218;
    
    public static final int Base_TextAppearance_AppCompat_Inverse = 2132017219;
    
    public static final int Base_TextAppearance_AppCompat_Large = 2132017220;
    
    public static final int Base_TextAppearance_AppCompat_Large_Inverse = 2132017221;
    
    public static final int Base_TextAppearance_AppCompat_Light_Widget_PopupMenu_Large = 2132017222;
    
    public static final int Base_TextAppearance_AppCompat_Light_Widget_PopupMenu_Small = 2132017223;
    
    public static final int Base_TextAppearance_AppCompat_Medium = 2132017224;
    
    public static final int Base_TextAppearance_AppCompat_Medium_Inverse = 2132017225;
    
    public static final int Base_TextAppearance_AppCompat_Menu = 2132017226;
    
    public static final int Base_TextAppearance_AppCompat_SearchResult = 2132017227;
    
    public static final int Base_TextAppearance_AppCompat_SearchResult_Subtitle = 2132017228;
    
    public static final int Base_TextAppearance_AppCompat_SearchResult_Title = 2132017229;
    
    public static final int Base_TextAppearance_AppCompat_Small = 2132017230;
    
    public static final int Base_TextAppearance_AppCompat_Small_Inverse = 2132017231;
    
    public static final int Base_TextAppearance_AppCompat_Subhead = 2132017232;
    
    public static final int Base_TextAppearance_AppCompat_Subhead_Inverse = 2132017233;
    
    public static final int Base_TextAppearance_AppCompat_Title = 2132017234;
    
    public static final int Base_TextAppearance_AppCompat_Title_Inverse = 2132017235;
    
    public static final int Base_TextAppearance_AppCompat_Tooltip = 2132017236;
    
    public static final int Base_TextAppearance_AppCompat_Widget_ActionBar_Menu = 2132017237;
    
    public static final int Base_TextAppearance_AppCompat_Widget_ActionBar_Subtitle = 2132017238;
    
    public static final int Base_TextAppearance_AppCompat_Widget_ActionBar_Subtitle_Inverse = 2132017239;
    
    public static final int Base_TextAppearance_AppCompat_Widget_ActionBar_Title = 2132017240;
    
    public static final int Base_TextAppearance_AppCompat_Widget_ActionBar_Title_Inverse = 2132017241;
    
    public static final int Base_TextAppearance_AppCompat_Widget_ActionMode_Subtitle = 2132017242;
    
    public static final int Base_TextAppearance_AppCompat_Widget_ActionMode_Title = 2132017243;
    
    public static final int Base_TextAppearance_AppCompat_Widget_Button = 2132017244;
    
    public static final int Base_TextAppearance_AppCompat_Widget_Button_Borderless_Colored = 2132017245;
    
    public static final int Base_TextAppearance_AppCompat_Widget_Button_Colored = 2132017246;
    
    public static final int Base_TextAppearance_AppCompat_Widget_Button_Inverse = 2132017247;
    
    public static final int Base_TextAppearance_AppCompat_Widget_DropDownItem = 2132017248;
    
    public static final int Base_TextAppearance_AppCompat_Widget_PopupMenu_Header = 2132017249;
    
    public static final int Base_TextAppearance_AppCompat_Widget_PopupMenu_Large = 2132017250;
    
    public static final int Base_TextAppearance_AppCompat_Widget_PopupMenu_Small = 2132017251;
    
    public static final int Base_TextAppearance_AppCompat_Widget_Switch = 2132017252;
    
    public static final int Base_TextAppearance_AppCompat_Widget_TextView_SpinnerItem = 2132017253;
    
    public static final int Base_TextAppearance_Widget_AppCompat_ExpandedMenu_Item = 2132017259;
    
    public static final int Base_TextAppearance_Widget_AppCompat_Toolbar_Subtitle = 2132017260;
    
    public static final int Base_TextAppearance_Widget_AppCompat_Toolbar_Title = 2132017261;
    
    public static final int Base_ThemeOverlay_AppCompat = 2132017304;
    
    public static final int Base_ThemeOverlay_AppCompat_ActionBar = 2132017305;
    
    public static final int Base_ThemeOverlay_AppCompat_Dark = 2132017306;
    
    public static final int Base_ThemeOverlay_AppCompat_Dark_ActionBar = 2132017307;
    
    public static final int Base_ThemeOverlay_AppCompat_Dialog = 2132017308;
    
    public static final int Base_ThemeOverlay_AppCompat_Dialog_Alert = 2132017309;
    
    public static final int Base_ThemeOverlay_AppCompat_Light = 2132017310;
    
    public static final int Base_Theme_AppCompat = 2132017262;
    
    public static final int Base_Theme_AppCompat_CompactMenu = 2132017263;
    
    public static final int Base_Theme_AppCompat_Dialog = 2132017264;
    
    public static final int Base_Theme_AppCompat_DialogWhenLarge = 2132017268;
    
    public static final int Base_Theme_AppCompat_Dialog_Alert = 2132017265;
    
    public static final int Base_Theme_AppCompat_Dialog_FixedSize = 2132017266;
    
    public static final int Base_Theme_AppCompat_Dialog_MinWidth = 2132017267;
    
    public static final int Base_Theme_AppCompat_Light = 2132017269;
    
    public static final int Base_Theme_AppCompat_Light_DarkActionBar = 2132017270;
    
    public static final int Base_Theme_AppCompat_Light_Dialog = 2132017271;
    
    public static final int Base_Theme_AppCompat_Light_DialogWhenLarge = 2132017275;
    
    public static final int Base_Theme_AppCompat_Light_Dialog_Alert = 2132017272;
    
    public static final int Base_Theme_AppCompat_Light_Dialog_FixedSize = 2132017273;
    
    public static final int Base_Theme_AppCompat_Light_Dialog_MinWidth = 2132017274;
    
    public static final int Base_V21_ThemeOverlay_AppCompat_Dialog = 2132017353;
    
    public static final int Base_V21_Theme_AppCompat = 2132017345;
    
    public static final int Base_V21_Theme_AppCompat_Dialog = 2132017346;
    
    public static final int Base_V21_Theme_AppCompat_Light = 2132017347;
    
    public static final int Base_V21_Theme_AppCompat_Light_Dialog = 2132017348;
    
    public static final int Base_V22_Theme_AppCompat = 2132017357;
    
    public static final int Base_V22_Theme_AppCompat_Light = 2132017358;
    
    public static final int Base_V23_Theme_AppCompat = 2132017359;
    
    public static final int Base_V23_Theme_AppCompat_Light = 2132017360;
    
    public static final int Base_V26_Theme_AppCompat = 2132017365;
    
    public static final int Base_V26_Theme_AppCompat_Light = 2132017366;
    
    public static final int Base_V26_Widget_AppCompat_Toolbar = 2132017367;
    
    public static final int Base_V28_Theme_AppCompat = 2132017368;
    
    public static final int Base_V28_Theme_AppCompat_Light = 2132017369;
    
    public static final int Base_V7_ThemeOverlay_AppCompat_Dialog = 2132017374;
    
    public static final int Base_V7_Theme_AppCompat = 2132017370;
    
    public static final int Base_V7_Theme_AppCompat_Dialog = 2132017371;
    
    public static final int Base_V7_Theme_AppCompat_Light = 2132017372;
    
    public static final int Base_V7_Theme_AppCompat_Light_Dialog = 2132017373;
    
    public static final int Base_V7_Widget_AppCompat_AutoCompleteTextView = 2132017375;
    
    public static final int Base_V7_Widget_AppCompat_EditText = 2132017376;
    
    public static final int Base_V7_Widget_AppCompat_Toolbar = 2132017377;
    
    public static final int Base_Widget_AppCompat_ActionBar = 2132017378;
    
    public static final int Base_Widget_AppCompat_ActionBar_Solid = 2132017379;
    
    public static final int Base_Widget_AppCompat_ActionBar_TabBar = 2132017380;
    
    public static final int Base_Widget_AppCompat_ActionBar_TabText = 2132017381;
    
    public static final int Base_Widget_AppCompat_ActionBar_TabView = 2132017382;
    
    public static final int Base_Widget_AppCompat_ActionButton = 2132017383;
    
    public static final int Base_Widget_AppCompat_ActionButton_CloseMode = 2132017384;
    
    public static final int Base_Widget_AppCompat_ActionButton_Overflow = 2132017385;
    
    public static final int Base_Widget_AppCompat_ActionMode = 2132017386;
    
    public static final int Base_Widget_AppCompat_ActivityChooserView = 2132017387;
    
    public static final int Base_Widget_AppCompat_AutoCompleteTextView = 2132017388;
    
    public static final int Base_Widget_AppCompat_Button = 2132017389;
    
    public static final int Base_Widget_AppCompat_ButtonBar = 2132017395;
    
    public static final int Base_Widget_AppCompat_ButtonBar_AlertDialog = 2132017396;
    
    public static final int Base_Widget_AppCompat_Button_Borderless = 2132017390;
    
    public static final int Base_Widget_AppCompat_Button_Borderless_Colored = 2132017391;
    
    public static final int Base_Widget_AppCompat_Button_ButtonBar_AlertDialog = 2132017392;
    
    public static final int Base_Widget_AppCompat_Button_Colored = 2132017393;
    
    public static final int Base_Widget_AppCompat_Button_Small = 2132017394;
    
    public static final int Base_Widget_AppCompat_CompoundButton_CheckBox = 2132017397;
    
    public static final int Base_Widget_AppCompat_CompoundButton_RadioButton = 2132017398;
    
    public static final int Base_Widget_AppCompat_CompoundButton_Switch = 2132017399;
    
    public static final int Base_Widget_AppCompat_DrawerArrowToggle = 2132017400;
    
    public static final int Base_Widget_AppCompat_DrawerArrowToggle_Common = 2132017401;
    
    public static final int Base_Widget_AppCompat_DropDownItem_Spinner = 2132017402;
    
    public static final int Base_Widget_AppCompat_EditText = 2132017403;
    
    public static final int Base_Widget_AppCompat_ImageButton = 2132017404;
    
    public static final int Base_Widget_AppCompat_Light_ActionBar = 2132017405;
    
    public static final int Base_Widget_AppCompat_Light_ActionBar_Solid = 2132017406;
    
    public static final int Base_Widget_AppCompat_Light_ActionBar_TabBar = 2132017407;
    
    public static final int Base_Widget_AppCompat_Light_ActionBar_TabText = 2132017408;
    
    public static final int Base_Widget_AppCompat_Light_ActionBar_TabText_Inverse = 2132017409;
    
    public static final int Base_Widget_AppCompat_Light_ActionBar_TabView = 2132017410;
    
    public static final int Base_Widget_AppCompat_Light_PopupMenu = 2132017411;
    
    public static final int Base_Widget_AppCompat_Light_PopupMenu_Overflow = 2132017412;
    
    public static final int Base_Widget_AppCompat_ListMenuView = 2132017413;
    
    public static final int Base_Widget_AppCompat_ListPopupWindow = 2132017414;
    
    public static final int Base_Widget_AppCompat_ListView = 2132017415;
    
    public static final int Base_Widget_AppCompat_ListView_DropDown = 2132017416;
    
    public static final int Base_Widget_AppCompat_ListView_Menu = 2132017417;
    
    public static final int Base_Widget_AppCompat_PopupMenu = 2132017418;
    
    public static final int Base_Widget_AppCompat_PopupMenu_Overflow = 2132017419;
    
    public static final int Base_Widget_AppCompat_PopupWindow = 2132017420;
    
    public static final int Base_Widget_AppCompat_ProgressBar = 2132017421;
    
    public static final int Base_Widget_AppCompat_ProgressBar_Horizontal = 2132017422;
    
    public static final int Base_Widget_AppCompat_RatingBar = 2132017423;
    
    public static final int Base_Widget_AppCompat_RatingBar_Indicator = 2132017424;
    
    public static final int Base_Widget_AppCompat_RatingBar_Small = 2132017425;
    
    public static final int Base_Widget_AppCompat_SearchView = 2132017426;
    
    public static final int Base_Widget_AppCompat_SearchView_ActionBar = 2132017427;
    
    public static final int Base_Widget_AppCompat_SeekBar = 2132017428;
    
    public static final int Base_Widget_AppCompat_SeekBar_Discrete = 2132017429;
    
    public static final int Base_Widget_AppCompat_Spinner = 2132017430;
    
    public static final int Base_Widget_AppCompat_Spinner_Underlined = 2132017431;
    
    public static final int Base_Widget_AppCompat_TextView = 2132017432;
    
    public static final int Base_Widget_AppCompat_TextView_SpinnerItem = 2132017433;
    
    public static final int Base_Widget_AppCompat_Toolbar = 2132017434;
    
    public static final int Base_Widget_AppCompat_Toolbar_Button_Navigation = 2132017435;
    
    public static final int Platform_AppCompat = 2132017534;
    
    public static final int Platform_AppCompat_Light = 2132017535;
    
    public static final int Platform_ThemeOverlay_AppCompat = 2132017540;
    
    public static final int Platform_ThemeOverlay_AppCompat_Dark = 2132017541;
    
    public static final int Platform_ThemeOverlay_AppCompat_Light = 2132017542;
    
    public static final int Platform_V21_AppCompat = 2132017543;
    
    public static final int Platform_V21_AppCompat_Light = 2132017544;
    
    public static final int Platform_V25_AppCompat = 2132017545;
    
    public static final int Platform_V25_AppCompat_Light = 2132017546;
    
    public static final int Platform_Widget_AppCompat_Spinner = 2132017547;
    
    public static final int RtlOverlay_DialogWindowTitle_AppCompat = 2132017549;
    
    public static final int RtlOverlay_Widget_AppCompat_ActionBar_TitleItem = 2132017550;
    
    public static final int RtlOverlay_Widget_AppCompat_DialogTitle_Icon = 2132017551;
    
    public static final int RtlOverlay_Widget_AppCompat_PopupMenuItem = 2132017552;
    
    public static final int RtlOverlay_Widget_AppCompat_PopupMenuItem_InternalGroup = 2132017553;
    
    public static final int RtlOverlay_Widget_AppCompat_PopupMenuItem_Shortcut = 2132017554;
    
    public static final int RtlOverlay_Widget_AppCompat_PopupMenuItem_SubmenuArrow = 2132017555;
    
    public static final int RtlOverlay_Widget_AppCompat_PopupMenuItem_Text = 2132017556;
    
    public static final int RtlOverlay_Widget_AppCompat_PopupMenuItem_Title = 2132017557;
    
    public static final int RtlOverlay_Widget_AppCompat_SearchView_MagIcon = 2132017563;
    
    public static final int RtlOverlay_Widget_AppCompat_Search_DropDown = 2132017558;
    
    public static final int RtlOverlay_Widget_AppCompat_Search_DropDown_Icon1 = 2132017559;
    
    public static final int RtlOverlay_Widget_AppCompat_Search_DropDown_Icon2 = 2132017560;
    
    public static final int RtlOverlay_Widget_AppCompat_Search_DropDown_Query = 2132017561;
    
    public static final int RtlOverlay_Widget_AppCompat_Search_DropDown_Text = 2132017562;
    
    public static final int RtlUnderlay_Widget_AppCompat_ActionButton = 2132017564;
    
    public static final int RtlUnderlay_Widget_AppCompat_ActionButton_Overflow = 2132017565;
    
    public static final int TextAppearance_AppCompat = 2132017676;
    
    public static final int TextAppearance_AppCompat_Body1 = 2132017677;
    
    public static final int TextAppearance_AppCompat_Body2 = 2132017678;
    
    public static final int TextAppearance_AppCompat_Button = 2132017679;
    
    public static final int TextAppearance_AppCompat_Caption = 2132017680;
    
    public static final int TextAppearance_AppCompat_Display1 = 2132017681;
    
    public static final int TextAppearance_AppCompat_Display2 = 2132017682;
    
    public static final int TextAppearance_AppCompat_Display3 = 2132017683;
    
    public static final int TextAppearance_AppCompat_Display4 = 2132017684;
    
    public static final int TextAppearance_AppCompat_Headline = 2132017685;
    
    public static final int TextAppearance_AppCompat_Inverse = 2132017686;
    
    public static final int TextAppearance_AppCompat_Large = 2132017687;
    
    public static final int TextAppearance_AppCompat_Large_Inverse = 2132017688;
    
    public static final int TextAppearance_AppCompat_Light_SearchResult_Subtitle = 2132017689;
    
    public static final int TextAppearance_AppCompat_Light_SearchResult_Title = 2132017690;
    
    public static final int TextAppearance_AppCompat_Light_Widget_PopupMenu_Large = 2132017691;
    
    public static final int TextAppearance_AppCompat_Light_Widget_PopupMenu_Small = 2132017692;
    
    public static final int TextAppearance_AppCompat_Medium = 2132017693;
    
    public static final int TextAppearance_AppCompat_Medium_Inverse = 2132017694;
    
    public static final int TextAppearance_AppCompat_Menu = 2132017695;
    
    public static final int TextAppearance_AppCompat_SearchResult_Subtitle = 2132017696;
    
    public static final int TextAppearance_AppCompat_SearchResult_Title = 2132017697;
    
    public static final int TextAppearance_AppCompat_Small = 2132017698;
    
    public static final int TextAppearance_AppCompat_Small_Inverse = 2132017699;
    
    public static final int TextAppearance_AppCompat_Subhead = 2132017700;
    
    public static final int TextAppearance_AppCompat_Subhead_Inverse = 2132017701;
    
    public static final int TextAppearance_AppCompat_Title = 2132017702;
    
    public static final int TextAppearance_AppCompat_Title_Inverse = 2132017703;
    
    public static final int TextAppearance_AppCompat_Tooltip = 2132017704;
    
    public static final int TextAppearance_AppCompat_Widget_ActionBar_Menu = 2132017705;
    
    public static final int TextAppearance_AppCompat_Widget_ActionBar_Subtitle = 2132017706;
    
    public static final int TextAppearance_AppCompat_Widget_ActionBar_Subtitle_Inverse = 2132017707;
    
    public static final int TextAppearance_AppCompat_Widget_ActionBar_Title = 2132017708;
    
    public static final int TextAppearance_AppCompat_Widget_ActionBar_Title_Inverse = 2132017709;
    
    public static final int TextAppearance_AppCompat_Widget_ActionMode_Subtitle = 2132017710;
    
    public static final int TextAppearance_AppCompat_Widget_ActionMode_Subtitle_Inverse = 2132017711;
    
    public static final int TextAppearance_AppCompat_Widget_ActionMode_Title = 2132017712;
    
    public static final int TextAppearance_AppCompat_Widget_ActionMode_Title_Inverse = 2132017713;
    
    public static final int TextAppearance_AppCompat_Widget_Button = 2132017714;
    
    public static final int TextAppearance_AppCompat_Widget_Button_Borderless_Colored = 2132017715;
    
    public static final int TextAppearance_AppCompat_Widget_Button_Colored = 2132017716;
    
    public static final int TextAppearance_AppCompat_Widget_Button_Inverse = 2132017717;
    
    public static final int TextAppearance_AppCompat_Widget_DropDownItem = 2132017718;
    
    public static final int TextAppearance_AppCompat_Widget_PopupMenu_Header = 2132017719;
    
    public static final int TextAppearance_AppCompat_Widget_PopupMenu_Large = 2132017720;
    
    public static final int TextAppearance_AppCompat_Widget_PopupMenu_Small = 2132017721;
    
    public static final int TextAppearance_AppCompat_Widget_Switch = 2132017722;
    
    public static final int TextAppearance_AppCompat_Widget_TextView_SpinnerItem = 2132017723;
    
    public static final int TextAppearance_Compat_Notification = 2132017724;
    
    public static final int TextAppearance_Compat_Notification_Info = 2132017725;
    
    public static final int TextAppearance_Compat_Notification_Line2 = 2132017727;
    
    public static final int TextAppearance_Compat_Notification_Time = 2132017730;
    
    public static final int TextAppearance_Compat_Notification_Title = 2132017732;
    
    public static final int TextAppearance_Widget_AppCompat_ExpandedMenu_Item = 2132017798;
    
    public static final int TextAppearance_Widget_AppCompat_Toolbar_Subtitle = 2132017799;
    
    public static final int TextAppearance_Widget_AppCompat_Toolbar_Title = 2132017800;
    
    public static final int ThemeOverlay_AppCompat = 2132017905;
    
    public static final int ThemeOverlay_AppCompat_ActionBar = 2132017906;
    
    public static final int ThemeOverlay_AppCompat_Dark = 2132017907;
    
    public static final int ThemeOverlay_AppCompat_Dark_ActionBar = 2132017908;
    
    public static final int ThemeOverlay_AppCompat_DayNight = 2132017909;
    
    public static final int ThemeOverlay_AppCompat_DayNight_ActionBar = 2132017910;
    
    public static final int ThemeOverlay_AppCompat_Dialog = 2132017911;
    
    public static final int ThemeOverlay_AppCompat_Dialog_Alert = 2132017912;
    
    public static final int ThemeOverlay_AppCompat_Light = 2132017913;
    
    public static final int Theme_AppCompat = 2132017801;
    
    public static final int Theme_AppCompat_CompactMenu = 2132017802;
    
    public static final int Theme_AppCompat_DayNight = 2132017803;
    
    public static final int Theme_AppCompat_DayNight_DarkActionBar = 2132017804;
    
    public static final int Theme_AppCompat_DayNight_Dialog = 2132017805;
    
    public static final int Theme_AppCompat_DayNight_DialogWhenLarge = 2132017808;
    
    public static final int Theme_AppCompat_DayNight_Dialog_Alert = 2132017806;
    
    public static final int Theme_AppCompat_DayNight_Dialog_MinWidth = 2132017807;
    
    public static final int Theme_AppCompat_DayNight_NoActionBar = 2132017809;
    
    public static final int Theme_AppCompat_Dialog = 2132017810;
    
    public static final int Theme_AppCompat_DialogWhenLarge = 2132017813;
    
    public static final int Theme_AppCompat_Dialog_Alert = 2132017811;
    
    public static final int Theme_AppCompat_Dialog_MinWidth = 2132017812;
    
    public static final int Theme_AppCompat_Empty = 2132017814;
    
    public static final int Theme_AppCompat_Light = 2132017815;
    
    public static final int Theme_AppCompat_Light_DarkActionBar = 2132017816;
    
    public static final int Theme_AppCompat_Light_Dialog = 2132017817;
    
    public static final int Theme_AppCompat_Light_DialogWhenLarge = 2132017820;
    
    public static final int Theme_AppCompat_Light_Dialog_Alert = 2132017818;
    
    public static final int Theme_AppCompat_Light_Dialog_MinWidth = 2132017819;
    
    public static final int Theme_AppCompat_Light_NoActionBar = 2132017821;
    
    public static final int Theme_AppCompat_NoActionBar = 2132017822;
    
    public static final int Widget_AppCompat_ActionBar = 2132018016;
    
    public static final int Widget_AppCompat_ActionBar_Solid = 2132018017;
    
    public static final int Widget_AppCompat_ActionBar_TabBar = 2132018018;
    
    public static final int Widget_AppCompat_ActionBar_TabText = 2132018019;
    
    public static final int Widget_AppCompat_ActionBar_TabView = 2132018020;
    
    public static final int Widget_AppCompat_ActionButton = 2132018021;
    
    public static final int Widget_AppCompat_ActionButton_CloseMode = 2132018022;
    
    public static final int Widget_AppCompat_ActionButton_Overflow = 2132018023;
    
    public static final int Widget_AppCompat_ActionMode = 2132018024;
    
    public static final int Widget_AppCompat_ActivityChooserView = 2132018025;
    
    public static final int Widget_AppCompat_AutoCompleteTextView = 2132018026;
    
    public static final int Widget_AppCompat_Button = 2132018027;
    
    public static final int Widget_AppCompat_ButtonBar = 2132018033;
    
    public static final int Widget_AppCompat_ButtonBar_AlertDialog = 2132018034;
    
    public static final int Widget_AppCompat_Button_Borderless = 2132018028;
    
    public static final int Widget_AppCompat_Button_Borderless_Colored = 2132018029;
    
    public static final int Widget_AppCompat_Button_ButtonBar_AlertDialog = 2132018030;
    
    public static final int Widget_AppCompat_Button_Colored = 2132018031;
    
    public static final int Widget_AppCompat_Button_Small = 2132018032;
    
    public static final int Widget_AppCompat_CompoundButton_CheckBox = 2132018035;
    
    public static final int Widget_AppCompat_CompoundButton_RadioButton = 2132018036;
    
    public static final int Widget_AppCompat_CompoundButton_Switch = 2132018037;
    
    public static final int Widget_AppCompat_DrawerArrowToggle = 2132018038;
    
    public static final int Widget_AppCompat_DropDownItem_Spinner = 2132018039;
    
    public static final int Widget_AppCompat_EditText = 2132018040;
    
    public static final int Widget_AppCompat_ImageButton = 2132018041;
    
    public static final int Widget_AppCompat_Light_ActionBar = 2132018042;
    
    public static final int Widget_AppCompat_Light_ActionBar_Solid = 2132018043;
    
    public static final int Widget_AppCompat_Light_ActionBar_Solid_Inverse = 2132018044;
    
    public static final int Widget_AppCompat_Light_ActionBar_TabBar = 2132018045;
    
    public static final int Widget_AppCompat_Light_ActionBar_TabBar_Inverse = 2132018046;
    
    public static final int Widget_AppCompat_Light_ActionBar_TabText = 2132018047;
    
    public static final int Widget_AppCompat_Light_ActionBar_TabText_Inverse = 2132018048;
    
    public static final int Widget_AppCompat_Light_ActionBar_TabView = 2132018049;
    
    public static final int Widget_AppCompat_Light_ActionBar_TabView_Inverse = 2132018050;
    
    public static final int Widget_AppCompat_Light_ActionButton = 2132018051;
    
    public static final int Widget_AppCompat_Light_ActionButton_CloseMode = 2132018052;
    
    public static final int Widget_AppCompat_Light_ActionButton_Overflow = 2132018053;
    
    public static final int Widget_AppCompat_Light_ActionMode_Inverse = 2132018054;
    
    public static final int Widget_AppCompat_Light_ActivityChooserView = 2132018055;
    
    public static final int Widget_AppCompat_Light_AutoCompleteTextView = 2132018056;
    
    public static final int Widget_AppCompat_Light_DropDownItem_Spinner = 2132018057;
    
    public static final int Widget_AppCompat_Light_ListPopupWindow = 2132018058;
    
    public static final int Widget_AppCompat_Light_ListView_DropDown = 2132018059;
    
    public static final int Widget_AppCompat_Light_PopupMenu = 2132018060;
    
    public static final int Widget_AppCompat_Light_PopupMenu_Overflow = 2132018061;
    
    public static final int Widget_AppCompat_Light_SearchView = 2132018062;
    
    public static final int Widget_AppCompat_Light_Spinner_DropDown_ActionBar = 2132018063;
    
    public static final int Widget_AppCompat_ListMenuView = 2132018064;
    
    public static final int Widget_AppCompat_ListPopupWindow = 2132018065;
    
    public static final int Widget_AppCompat_ListView = 2132018066;
    
    public static final int Widget_AppCompat_ListView_DropDown = 2132018067;
    
    public static final int Widget_AppCompat_ListView_Menu = 2132018068;
    
    public static final int Widget_AppCompat_PopupMenu = 2132018069;
    
    public static final int Widget_AppCompat_PopupMenu_Overflow = 2132018070;
    
    public static final int Widget_AppCompat_PopupWindow = 2132018071;
    
    public static final int Widget_AppCompat_ProgressBar = 2132018072;
    
    public static final int Widget_AppCompat_ProgressBar_Horizontal = 2132018073;
    
    public static final int Widget_AppCompat_RatingBar = 2132018074;
    
    public static final int Widget_AppCompat_RatingBar_Indicator = 2132018075;
    
    public static final int Widget_AppCompat_RatingBar_Small = 2132018076;
    
    public static final int Widget_AppCompat_SearchView = 2132018077;
    
    public static final int Widget_AppCompat_SearchView_ActionBar = 2132018078;
    
    public static final int Widget_AppCompat_SeekBar = 2132018079;
    
    public static final int Widget_AppCompat_SeekBar_Discrete = 2132018080;
    
    public static final int Widget_AppCompat_Spinner = 2132018081;
    
    public static final int Widget_AppCompat_Spinner_DropDown = 2132018082;
    
    public static final int Widget_AppCompat_Spinner_DropDown_ActionBar = 2132018083;
    
    public static final int Widget_AppCompat_Spinner_Underlined = 2132018084;
    
    public static final int Widget_AppCompat_TextView = 2132018085;
    
    public static final int Widget_AppCompat_TextView_SpinnerItem = 2132018086;
    
    public static final int Widget_AppCompat_Toolbar = 2132018087;
    
    public static final int Widget_AppCompat_Toolbar_Button_Navigation = 2132018088;
    
    public static final int Widget_Compat_NotificationActionContainer = 2132018089;
    
    public static final int Widget_Compat_NotificationActionText = 2132018090;
  }
  
  public static final class styleable {
    public static final int[] ActionBar = new int[] { 
        2130968702, 2130968710, 2130968711, 2130968989, 2130968990, 2130968991, 2130968992, 2130968993, 2130968994, 2130969056, 
        2130969078, 2130969079, 2130969145, 2130969303, 2130969312, 2130969318, 2130969319, 2130969323, 2130969343, 2130969404, 
        2130969542, 2130969740, 2130969805, 2130969812, 2130969813, 2130970035, 2130970039, 2130970177, 2130970191 };
    
    public static final int[] ActionBarLayout = new int[] { 16842931 };
    
    public static final int ActionBarLayout_android_layout_gravity = 0;
    
    public static final int ActionBar_background = 0;
    
    public static final int ActionBar_backgroundSplit = 1;
    
    public static final int ActionBar_backgroundStacked = 2;
    
    public static final int ActionBar_contentInsetEnd = 3;
    
    public static final int ActionBar_contentInsetEndWithActions = 4;
    
    public static final int ActionBar_contentInsetLeft = 5;
    
    public static final int ActionBar_contentInsetRight = 6;
    
    public static final int ActionBar_contentInsetStart = 7;
    
    public static final int ActionBar_contentInsetStartWithNavigation = 8;
    
    public static final int ActionBar_customNavigationLayout = 9;
    
    public static final int ActionBar_displayOptions = 10;
    
    public static final int ActionBar_divider = 11;
    
    public static final int ActionBar_elevation = 12;
    
    public static final int ActionBar_height = 13;
    
    public static final int ActionBar_hideOnContentScroll = 14;
    
    public static final int ActionBar_homeAsUpIndicator = 15;
    
    public static final int ActionBar_homeLayout = 16;
    
    public static final int ActionBar_icon = 17;
    
    public static final int ActionBar_indeterminateProgressStyle = 18;
    
    public static final int ActionBar_itemPadding = 19;
    
    public static final int ActionBar_logo = 20;
    
    public static final int ActionBar_navigationMode = 21;
    
    public static final int ActionBar_popupTheme = 22;
    
    public static final int ActionBar_progressBarPadding = 23;
    
    public static final int ActionBar_progressBarStyle = 24;
    
    public static final int ActionBar_subtitle = 25;
    
    public static final int ActionBar_subtitleTextStyle = 26;
    
    public static final int ActionBar_title = 27;
    
    public static final int ActionBar_titleTextStyle = 28;
    
    public static final int[] ActionMenuItemView = new int[] { 16843071 };
    
    public static final int ActionMenuItemView_android_minWidth = 0;
    
    public static final int[] ActionMenuView = new int[0];
    
    public static final int[] ActionMode = new int[] { 2130968702, 2130968710, 2130968904, 2130969303, 2130970039, 2130970191 };
    
    public static final int ActionMode_background = 0;
    
    public static final int ActionMode_backgroundSplit = 1;
    
    public static final int ActionMode_closeItemLayout = 2;
    
    public static final int ActionMode_height = 3;
    
    public static final int ActionMode_subtitleTextStyle = 4;
    
    public static final int ActionMode_titleTextStyle = 5;
    
    public static final int[] ActivityChooserView = new int[] { 2130969175, 2130969349 };
    
    public static final int ActivityChooserView_expandActivityOverflowButtonDrawable = 0;
    
    public static final int ActivityChooserView_initialActivityCount = 1;
    
    public static final int[] AlertDialog = new int[] { 16842994, 2130968800, 2130968803, 2130969530, 2130969531, 2130969730, 2130969906, 2130969914 };
    
    public static final int AlertDialog_android_layout = 0;
    
    public static final int AlertDialog_buttonIconDimen = 1;
    
    public static final int AlertDialog_buttonPanelSideLayout = 2;
    
    public static final int AlertDialog_listItemLayout = 3;
    
    public static final int AlertDialog_listLayout = 4;
    
    public static final int AlertDialog_multiChoiceItemLayout = 5;
    
    public static final int AlertDialog_showTitle = 6;
    
    public static final int AlertDialog_singleChoiceItemLayout = 7;
    
    public static final int[] AnimatedStateListDrawableCompat = new int[] { 16843036, 16843156, 16843157, 16843158, 16843532, 16843533 };
    
    public static final int AnimatedStateListDrawableCompat_android_constantSize = 3;
    
    public static final int AnimatedStateListDrawableCompat_android_dither = 0;
    
    public static final int AnimatedStateListDrawableCompat_android_enterFadeDuration = 4;
    
    public static final int AnimatedStateListDrawableCompat_android_exitFadeDuration = 5;
    
    public static final int AnimatedStateListDrawableCompat_android_variablePadding = 2;
    
    public static final int AnimatedStateListDrawableCompat_android_visible = 1;
    
    public static final int[] AnimatedStateListDrawableItem = new int[] { 16842960, 16843161 };
    
    public static final int AnimatedStateListDrawableItem_android_drawable = 1;
    
    public static final int AnimatedStateListDrawableItem_android_id = 0;
    
    public static final int[] AnimatedStateListDrawableTransition = new int[] { 16843161, 16843849, 16843850, 16843851 };
    
    public static final int AnimatedStateListDrawableTransition_android_drawable = 0;
    
    public static final int AnimatedStateListDrawableTransition_android_fromId = 2;
    
    public static final int AnimatedStateListDrawableTransition_android_reversible = 3;
    
    public static final int AnimatedStateListDrawableTransition_android_toId = 1;
    
    public static final int[] AppCompatImageView = new int[] { 16843033, 2130969933, 2130970174, 2130970175 };
    
    public static final int AppCompatImageView_android_src = 0;
    
    public static final int AppCompatImageView_srcCompat = 1;
    
    public static final int AppCompatImageView_tint = 2;
    
    public static final int AppCompatImageView_tintMode = 3;
    
    public static final int[] AppCompatSeekBar = new int[] { 16843074, 2130970167, 2130970168, 2130970169 };
    
    public static final int AppCompatSeekBar_android_thumb = 0;
    
    public static final int AppCompatSeekBar_tickMark = 1;
    
    public static final int AppCompatSeekBar_tickMarkTint = 2;
    
    public static final int AppCompatSeekBar_tickMarkTintMode = 3;
    
    public static final int[] AppCompatTextHelper = new int[] { 16842804, 16843117, 16843118, 16843119, 16843120, 16843666, 16843667 };
    
    public static final int AppCompatTextHelper_android_drawableBottom = 2;
    
    public static final int AppCompatTextHelper_android_drawableEnd = 6;
    
    public static final int AppCompatTextHelper_android_drawableLeft = 3;
    
    public static final int AppCompatTextHelper_android_drawableRight = 4;
    
    public static final int AppCompatTextHelper_android_drawableStart = 5;
    
    public static final int AppCompatTextHelper_android_drawableTop = 1;
    
    public static final int AppCompatTextHelper_android_textAppearance = 0;
    
    public static final int[] AppCompatTextView = new int[] { 
        16842804, 2130968696, 2130968697, 2130968698, 2130968699, 2130968700, 2130969098, 2130969099, 2130969101, 2130969103, 
        2130969105, 2130969106, 2130969107, 2130969108, 2130969149, 2130969209, 2130969274, 2130969283, 2130969431, 2130969523, 
        2130970082, 2130970138 };
    
    public static final int AppCompatTextView_android_textAppearance = 0;
    
    public static final int AppCompatTextView_autoSizeMaxTextSize = 1;
    
    public static final int AppCompatTextView_autoSizeMinTextSize = 2;
    
    public static final int AppCompatTextView_autoSizePresetSizes = 3;
    
    public static final int AppCompatTextView_autoSizeStepGranularity = 4;
    
    public static final int AppCompatTextView_autoSizeTextType = 5;
    
    public static final int AppCompatTextView_drawableBottomCompat = 6;
    
    public static final int AppCompatTextView_drawableEndCompat = 7;
    
    public static final int AppCompatTextView_drawableLeftCompat = 8;
    
    public static final int AppCompatTextView_drawableRightCompat = 9;
    
    public static final int AppCompatTextView_drawableStartCompat = 10;
    
    public static final int AppCompatTextView_drawableTint = 11;
    
    public static final int AppCompatTextView_drawableTintMode = 12;
    
    public static final int AppCompatTextView_drawableTopCompat = 13;
    
    public static final int AppCompatTextView_emojiCompatEnabled = 14;
    
    public static final int AppCompatTextView_firstBaselineToTopHeight = 15;
    
    public static final int AppCompatTextView_fontFamily = 16;
    
    public static final int AppCompatTextView_fontVariationSettings = 17;
    
    public static final int AppCompatTextView_lastBaselineToBottomHeight = 18;
    
    public static final int AppCompatTextView_lineHeight = 19;
    
    public static final int AppCompatTextView_textAllCaps = 20;
    
    public static final int AppCompatTextView_textLocale = 21;
    
    public static final int[] AppCompatTheme = new int[] { 
        16842839, 16842926, 2130968581, 2130968582, 2130968583, 2130968584, 2130968585, 2130968586, 2130968587, 2130968588, 
        2130968589, 2130968590, 2130968591, 2130968592, 2130968593, 2130968595, 2130968596, 2130968597, 2130968598, 2130968599, 
        2130968600, 2130968601, 2130968602, 2130968603, 2130968604, 2130968605, 2130968606, 2130968607, 2130968608, 2130968609, 
        2130968610, 2130968611, 2130968612, 2130968613, 2130968617, 2130968661, 2130968662, 2130968663, 2130968664, 2130968694, 
        2130968771, 2130968792, 2130968793, 2130968794, 2130968795, 2130968796, 2130968805, 2130968806, 2130968847, 2130968858, 
        2130968917, 2130968918, 2130968919, 2130968921, 2130968922, 2130968923, 2130968924, 2130968949, 2130968951, 2130968973, 
        2130969004, 2130969075, 2130969076, 2130969077, 2130969084, 2130969089, 2130969113, 2130969114, 2130969139, 2130969140, 
        2130969141, 2130969318, 2130969336, 2130969526, 2130969527, 2130969528, 2130969529, 2130969532, 2130969533, 2130969534, 
        2130969535, 2130969536, 2130969537, 2130969538, 2130969539, 2130969540, 2130969781, 2130969782, 2130969783, 2130969803, 
        2130969806, 2130969824, 2130969826, 2130969827, 2130969828, 2130969873, 2130969874, 2130969875, 2130969876, 2130969924, 
        2130969925, 2130970047, 2130970105, 2130970107, 2130970108, 2130970109, 2130970111, 2130970112, 2130970113, 2130970114, 
        2130970126, 2130970127, 2130970232, 2130970233, 2130970235, 2130970236, 2130970291, 2130970312, 2130970313, 2130970314, 
        2130970315, 2130970316, 2130970317, 2130970318, 2130970319, 2130970320, 2130970321 };
    
    public static final int AppCompatTheme_actionBarDivider = 2;
    
    public static final int AppCompatTheme_actionBarItemBackground = 3;
    
    public static final int AppCompatTheme_actionBarPopupTheme = 4;
    
    public static final int AppCompatTheme_actionBarSize = 5;
    
    public static final int AppCompatTheme_actionBarSplitStyle = 6;
    
    public static final int AppCompatTheme_actionBarStyle = 7;
    
    public static final int AppCompatTheme_actionBarTabBarStyle = 8;
    
    public static final int AppCompatTheme_actionBarTabStyle = 9;
    
    public static final int AppCompatTheme_actionBarTabTextStyle = 10;
    
    public static final int AppCompatTheme_actionBarTheme = 11;
    
    public static final int AppCompatTheme_actionBarWidgetTheme = 12;
    
    public static final int AppCompatTheme_actionButtonStyle = 13;
    
    public static final int AppCompatTheme_actionDropDownStyle = 14;
    
    public static final int AppCompatTheme_actionMenuTextAppearance = 15;
    
    public static final int AppCompatTheme_actionMenuTextColor = 16;
    
    public static final int AppCompatTheme_actionModeBackground = 17;
    
    public static final int AppCompatTheme_actionModeCloseButtonStyle = 18;
    
    public static final int AppCompatTheme_actionModeCloseContentDescription = 19;
    
    public static final int AppCompatTheme_actionModeCloseDrawable = 20;
    
    public static final int AppCompatTheme_actionModeCopyDrawable = 21;
    
    public static final int AppCompatTheme_actionModeCutDrawable = 22;
    
    public static final int AppCompatTheme_actionModeFindDrawable = 23;
    
    public static final int AppCompatTheme_actionModePasteDrawable = 24;
    
    public static final int AppCompatTheme_actionModePopupWindowStyle = 25;
    
    public static final int AppCompatTheme_actionModeSelectAllDrawable = 26;
    
    public static final int AppCompatTheme_actionModeShareDrawable = 27;
    
    public static final int AppCompatTheme_actionModeSplitBackground = 28;
    
    public static final int AppCompatTheme_actionModeStyle = 29;
    
    public static final int AppCompatTheme_actionModeTheme = 30;
    
    public static final int AppCompatTheme_actionModeWebSearchDrawable = 31;
    
    public static final int AppCompatTheme_actionOverflowButtonStyle = 32;
    
    public static final int AppCompatTheme_actionOverflowMenuStyle = 33;
    
    public static final int AppCompatTheme_activityChooserViewStyle = 34;
    
    public static final int AppCompatTheme_alertDialogButtonGroupStyle = 35;
    
    public static final int AppCompatTheme_alertDialogCenterButtons = 36;
    
    public static final int AppCompatTheme_alertDialogStyle = 37;
    
    public static final int AppCompatTheme_alertDialogTheme = 38;
    
    public static final int AppCompatTheme_android_windowAnimationStyle = 1;
    
    public static final int AppCompatTheme_android_windowIsFloating = 0;
    
    public static final int AppCompatTheme_autoCompleteTextViewStyle = 39;
    
    public static final int AppCompatTheme_borderlessButtonStyle = 40;
    
    public static final int AppCompatTheme_buttonBarButtonStyle = 41;
    
    public static final int AppCompatTheme_buttonBarNegativeButtonStyle = 42;
    
    public static final int AppCompatTheme_buttonBarNeutralButtonStyle = 43;
    
    public static final int AppCompatTheme_buttonBarPositiveButtonStyle = 44;
    
    public static final int AppCompatTheme_buttonBarStyle = 45;
    
    public static final int AppCompatTheme_buttonStyle = 46;
    
    public static final int AppCompatTheme_buttonStyleSmall = 47;
    
    public static final int AppCompatTheme_checkboxStyle = 48;
    
    public static final int AppCompatTheme_checkedTextViewStyle = 49;
    
    public static final int AppCompatTheme_colorAccent = 50;
    
    public static final int AppCompatTheme_colorBackgroundFloating = 51;
    
    public static final int AppCompatTheme_colorButtonNormal = 52;
    
    public static final int AppCompatTheme_colorControlActivated = 53;
    
    public static final int AppCompatTheme_colorControlHighlight = 54;
    
    public static final int AppCompatTheme_colorControlNormal = 55;
    
    public static final int AppCompatTheme_colorError = 56;
    
    public static final int AppCompatTheme_colorPrimary = 57;
    
    public static final int AppCompatTheme_colorPrimaryDark = 58;
    
    public static final int AppCompatTheme_colorSwitchThumbNormal = 59;
    
    public static final int AppCompatTheme_controlBackground = 60;
    
    public static final int AppCompatTheme_dialogCornerRadius = 61;
    
    public static final int AppCompatTheme_dialogPreferredPadding = 62;
    
    public static final int AppCompatTheme_dialogTheme = 63;
    
    public static final int AppCompatTheme_dividerHorizontal = 64;
    
    public static final int AppCompatTheme_dividerVertical = 65;
    
    public static final int AppCompatTheme_dropDownListViewStyle = 66;
    
    public static final int AppCompatTheme_dropdownListPreferredItemHeight = 67;
    
    public static final int AppCompatTheme_editTextBackground = 68;
    
    public static final int AppCompatTheme_editTextColor = 69;
    
    public static final int AppCompatTheme_editTextStyle = 70;
    
    public static final int AppCompatTheme_homeAsUpIndicator = 71;
    
    public static final int AppCompatTheme_imageButtonStyle = 72;
    
    public static final int AppCompatTheme_listChoiceBackgroundIndicator = 73;
    
    public static final int AppCompatTheme_listChoiceIndicatorMultipleAnimated = 74;
    
    public static final int AppCompatTheme_listChoiceIndicatorSingleAnimated = 75;
    
    public static final int AppCompatTheme_listDividerAlertDialog = 76;
    
    public static final int AppCompatTheme_listMenuViewStyle = 77;
    
    public static final int AppCompatTheme_listPopupWindowStyle = 78;
    
    public static final int AppCompatTheme_listPreferredItemHeight = 79;
    
    public static final int AppCompatTheme_listPreferredItemHeightLarge = 80;
    
    public static final int AppCompatTheme_listPreferredItemHeightSmall = 81;
    
    public static final int AppCompatTheme_listPreferredItemPaddingEnd = 82;
    
    public static final int AppCompatTheme_listPreferredItemPaddingLeft = 83;
    
    public static final int AppCompatTheme_listPreferredItemPaddingRight = 84;
    
    public static final int AppCompatTheme_listPreferredItemPaddingStart = 85;
    
    public static final int AppCompatTheme_panelBackground = 86;
    
    public static final int AppCompatTheme_panelMenuListTheme = 87;
    
    public static final int AppCompatTheme_panelMenuListWidth = 88;
    
    public static final int AppCompatTheme_popupMenuStyle = 89;
    
    public static final int AppCompatTheme_popupWindowStyle = 90;
    
    public static final int AppCompatTheme_radioButtonStyle = 91;
    
    public static final int AppCompatTheme_ratingBarStyle = 92;
    
    public static final int AppCompatTheme_ratingBarStyleIndicator = 93;
    
    public static final int AppCompatTheme_ratingBarStyleSmall = 94;
    
    public static final int AppCompatTheme_searchViewStyle = 95;
    
    public static final int AppCompatTheme_seekBarStyle = 96;
    
    public static final int AppCompatTheme_selectableItemBackground = 97;
    
    public static final int AppCompatTheme_selectableItemBackgroundBorderless = 98;
    
    public static final int AppCompatTheme_spinnerDropDownItemStyle = 99;
    
    public static final int AppCompatTheme_spinnerStyle = 100;
    
    public static final int AppCompatTheme_switchStyle = 101;
    
    public static final int AppCompatTheme_textAppearanceLargePopupMenu = 102;
    
    public static final int AppCompatTheme_textAppearanceListItem = 103;
    
    public static final int AppCompatTheme_textAppearanceListItemSecondary = 104;
    
    public static final int AppCompatTheme_textAppearanceListItemSmall = 105;
    
    public static final int AppCompatTheme_textAppearancePopupMenuHeader = 106;
    
    public static final int AppCompatTheme_textAppearanceSearchResultSubtitle = 107;
    
    public static final int AppCompatTheme_textAppearanceSearchResultTitle = 108;
    
    public static final int AppCompatTheme_textAppearanceSmallPopupMenu = 109;
    
    public static final int AppCompatTheme_textColorAlertDialogListItem = 110;
    
    public static final int AppCompatTheme_textColorSearchUrl = 111;
    
    public static final int AppCompatTheme_toolbarNavigationButtonStyle = 112;
    
    public static final int AppCompatTheme_toolbarStyle = 113;
    
    public static final int AppCompatTheme_tooltipForegroundColor = 114;
    
    public static final int AppCompatTheme_tooltipFrameBackground = 115;
    
    public static final int AppCompatTheme_viewInflaterClass = 116;
    
    public static final int AppCompatTheme_windowActionBar = 117;
    
    public static final int AppCompatTheme_windowActionBarOverlay = 118;
    
    public static final int AppCompatTheme_windowActionModeOverlay = 119;
    
    public static final int AppCompatTheme_windowFixedHeightMajor = 120;
    
    public static final int AppCompatTheme_windowFixedHeightMinor = 121;
    
    public static final int AppCompatTheme_windowFixedWidthMajor = 122;
    
    public static final int AppCompatTheme_windowFixedWidthMinor = 123;
    
    public static final int AppCompatTheme_windowMinWidthMajor = 124;
    
    public static final int AppCompatTheme_windowMinWidthMinor = 125;
    
    public static final int AppCompatTheme_windowNoTitle = 126;
    
    public static final int[] ButtonBarLayout = new int[] { 2130968667 };
    
    public static final int ButtonBarLayout_allowStacking = 0;
    
    public static final int[] Carousel = new int[] { 2130968832, 2130968833, 2130968834, 2130968835, 2130968836, 2130968837, 2130968838, 2130968839, 2130968840, 2130968841 };
    
    public static final int Carousel_carousel_backwardTransition = 0;
    
    public static final int Carousel_carousel_emptyViewsBehavior = 1;
    
    public static final int Carousel_carousel_firstView = 2;
    
    public static final int Carousel_carousel_forwardTransition = 3;
    
    public static final int Carousel_carousel_infinite = 4;
    
    public static final int Carousel_carousel_nextState = 5;
    
    public static final int Carousel_carousel_previousState = 6;
    
    public static final int Carousel_carousel_touchUpMode = 7;
    
    public static final int Carousel_carousel_touchUp_dampeningFactor = 8;
    
    public static final int Carousel_carousel_touchUp_velocityThreshold = 9;
    
    public static final int[] ColorStateListItem = new int[] { 16843173, 16843551, 16844359, 2130968668, 2130969427 };
    
    public static final int ColorStateListItem_alpha = 3;
    
    public static final int ColorStateListItem_android_alpha = 1;
    
    public static final int ColorStateListItem_android_color = 0;
    
    public static final int ColorStateListItem_android_lStar = 2;
    
    public static final int ColorStateListItem_lStar = 4;
    
    public static final int[] CompoundButton = new int[] { 16843015, 2130968797, 2130968807, 2130968808 };
    
    public static final int CompoundButton_android_button = 0;
    
    public static final int CompoundButton_buttonCompat = 1;
    
    public static final int CompoundButton_buttonTint = 2;
    
    public static final int CompoundButton_buttonTintMode = 3;
    
    public static final int[] Constraint = new int[] { 
        16842948, 16842960, 16842972, 16842996, 16842997, 16842999, 16843000, 16843001, 16843002, 16843039, 
        16843040, 16843071, 16843072, 16843551, 16843552, 16843553, 16843554, 16843555, 16843556, 16843557, 
        16843558, 16843559, 16843560, 16843701, 16843702, 16843770, 16843840, 2130968671, 2130968674, 2130968752, 
        2130968753, 2130968754, 2130968843, 2130968984, 2130968985, 2130969097, 2130969251, 2130969252, 2130969253, 2130969254, 
        2130969255, 2130969256, 2130969257, 2130969258, 2130969259, 2130969260, 2130969261, 2130969262, 2130969263, 2130969265, 
        2130969266, 2130969267, 2130969268, 2130969269, 2130969299, 2130969443, 2130969444, 2130969445, 2130969446, 2130969447, 
        2130969448, 2130969449, 2130969450, 2130969451, 2130969452, 2130969453, 2130969454, 2130969455, 2130969456, 2130969457, 
        2130969458, 2130969459, 2130969460, 2130969461, 2130969462, 2130969463, 2130969464, 2130969465, 2130969466, 2130969467, 
        2130969468, 2130969469, 2130969470, 2130969471, 2130969472, 2130969473, 2130969474, 2130969475, 2130969476, 2130969477, 
        2130969478, 2130969479, 2130969480, 2130969481, 2130969482, 2130969483, 2130969484, 2130969485, 2130969486, 2130969487, 
        2130969488, 2130969490, 2130969491, 2130969495, 2130969496, 2130969497, 2130969498, 2130969499, 2130969500, 2130969501, 
        2130969504, 2130969517, 2130969724, 2130969725, 2130969789, 2130969796, 2130969801, 2130969817, 2130969818, 2130969819, 
        2130970256, 2130970258, 2130970260, 2130970296 };
    
    public static final int[] ConstraintLayout_Layout = new int[] { 
        16842948, 16842965, 16842966, 16842967, 16842968, 16842969, 16842972, 16842996, 16842997, 16842998, 
        16842999, 16843000, 16843001, 16843002, 16843039, 16843040, 16843071, 16843072, 16843699, 16843700, 
        16843701, 16843702, 16843840, 16844091, 16844092, 2130968752, 2130968753, 2130968754, 2130968843, 2130968882, 
        2130968883, 2130968884, 2130968885, 2130968886, 2130968981, 2130968984, 2130968985, 2130969251, 2130969252, 2130969253, 
        2130969254, 2130969255, 2130969256, 2130969257, 2130969258, 2130969259, 2130969260, 2130969261, 2130969262, 2130969263, 
        2130969265, 2130969266, 2130969267, 2130969268, 2130969269, 2130969299, 2130969434, 2130969443, 2130969444, 2130969445, 
        2130969446, 2130969447, 2130969448, 2130969449, 2130969450, 2130969451, 2130969452, 2130969453, 2130969454, 2130969455, 
        2130969456, 2130969457, 2130969458, 2130969459, 2130969460, 2130969461, 2130969462, 2130969463, 2130969464, 2130969465, 
        2130969466, 2130969467, 2130969468, 2130969469, 2130969470, 2130969471, 2130969472, 2130969473, 2130969474, 2130969475, 
        2130969476, 2130969477, 2130969478, 2130969479, 2130969480, 2130969481, 2130969482, 2130969483, 2130969484, 2130969485, 
        2130969486, 2130969487, 2130969488, 2130969490, 2130969491, 2130969495, 2130969496, 2130969497, 2130969498, 2130969499, 
        2130969500, 2130969501, 2130969504, 2130969509, 2130969517 };
    
    public static final int ConstraintLayout_Layout_android_elevation = 22;
    
    public static final int ConstraintLayout_Layout_android_layout_height = 8;
    
    public static final int ConstraintLayout_Layout_android_layout_margin = 9;
    
    public static final int ConstraintLayout_Layout_android_layout_marginBottom = 13;
    
    public static final int ConstraintLayout_Layout_android_layout_marginEnd = 21;
    
    public static final int ConstraintLayout_Layout_android_layout_marginHorizontal = 23;
    
    public static final int ConstraintLayout_Layout_android_layout_marginLeft = 10;
    
    public static final int ConstraintLayout_Layout_android_layout_marginRight = 12;
    
    public static final int ConstraintLayout_Layout_android_layout_marginStart = 20;
    
    public static final int ConstraintLayout_Layout_android_layout_marginTop = 11;
    
    public static final int ConstraintLayout_Layout_android_layout_marginVertical = 24;
    
    public static final int ConstraintLayout_Layout_android_layout_width = 7;
    
    public static final int ConstraintLayout_Layout_android_maxHeight = 15;
    
    public static final int ConstraintLayout_Layout_android_maxWidth = 14;
    
    public static final int ConstraintLayout_Layout_android_minHeight = 17;
    
    public static final int ConstraintLayout_Layout_android_minWidth = 16;
    
    public static final int ConstraintLayout_Layout_android_orientation = 0;
    
    public static final int ConstraintLayout_Layout_android_padding = 1;
    
    public static final int ConstraintLayout_Layout_android_paddingBottom = 5;
    
    public static final int ConstraintLayout_Layout_android_paddingEnd = 19;
    
    public static final int ConstraintLayout_Layout_android_paddingLeft = 2;
    
    public static final int ConstraintLayout_Layout_android_paddingRight = 4;
    
    public static final int ConstraintLayout_Layout_android_paddingStart = 18;
    
    public static final int ConstraintLayout_Layout_android_paddingTop = 3;
    
    public static final int ConstraintLayout_Layout_android_visibility = 6;
    
    public static final int ConstraintLayout_Layout_barrierAllowsGoneWidgets = 25;
    
    public static final int ConstraintLayout_Layout_barrierDirection = 26;
    
    public static final int ConstraintLayout_Layout_barrierMargin = 27;
    
    public static final int ConstraintLayout_Layout_chainUseRtl = 28;
    
    public static final int ConstraintLayout_Layout_circularflow_angles = 29;
    
    public static final int ConstraintLayout_Layout_circularflow_defaultAngle = 30;
    
    public static final int ConstraintLayout_Layout_circularflow_defaultRadius = 31;
    
    public static final int ConstraintLayout_Layout_circularflow_radiusInDP = 32;
    
    public static final int ConstraintLayout_Layout_circularflow_viewCenter = 33;
    
    public static final int ConstraintLayout_Layout_constraintSet = 34;
    
    public static final int ConstraintLayout_Layout_constraint_referenced_ids = 35;
    
    public static final int ConstraintLayout_Layout_constraint_referenced_tags = 36;
    
    public static final int ConstraintLayout_Layout_flow_firstHorizontalBias = 37;
    
    public static final int ConstraintLayout_Layout_flow_firstHorizontalStyle = 38;
    
    public static final int ConstraintLayout_Layout_flow_firstVerticalBias = 39;
    
    public static final int ConstraintLayout_Layout_flow_firstVerticalStyle = 40;
    
    public static final int ConstraintLayout_Layout_flow_horizontalAlign = 41;
    
    public static final int ConstraintLayout_Layout_flow_horizontalBias = 42;
    
    public static final int ConstraintLayout_Layout_flow_horizontalGap = 43;
    
    public static final int ConstraintLayout_Layout_flow_horizontalStyle = 44;
    
    public static final int ConstraintLayout_Layout_flow_lastHorizontalBias = 45;
    
    public static final int ConstraintLayout_Layout_flow_lastHorizontalStyle = 46;
    
    public static final int ConstraintLayout_Layout_flow_lastVerticalBias = 47;
    
    public static final int ConstraintLayout_Layout_flow_lastVerticalStyle = 48;
    
    public static final int ConstraintLayout_Layout_flow_maxElementsWrap = 49;
    
    public static final int ConstraintLayout_Layout_flow_verticalAlign = 50;
    
    public static final int ConstraintLayout_Layout_flow_verticalBias = 51;
    
    public static final int ConstraintLayout_Layout_flow_verticalGap = 52;
    
    public static final int ConstraintLayout_Layout_flow_verticalStyle = 53;
    
    public static final int ConstraintLayout_Layout_flow_wrapMode = 54;
    
    public static final int ConstraintLayout_Layout_guidelineUseRtl = 55;
    
    public static final int ConstraintLayout_Layout_layoutDescription = 56;
    
    public static final int ConstraintLayout_Layout_layout_constrainedHeight = 57;
    
    public static final int ConstraintLayout_Layout_layout_constrainedWidth = 58;
    
    public static final int ConstraintLayout_Layout_layout_constraintBaseline_creator = 59;
    
    public static final int ConstraintLayout_Layout_layout_constraintBaseline_toBaselineOf = 60;
    
    public static final int ConstraintLayout_Layout_layout_constraintBaseline_toBottomOf = 61;
    
    public static final int ConstraintLayout_Layout_layout_constraintBaseline_toTopOf = 62;
    
    public static final int ConstraintLayout_Layout_layout_constraintBottom_creator = 63;
    
    public static final int ConstraintLayout_Layout_layout_constraintBottom_toBottomOf = 64;
    
    public static final int ConstraintLayout_Layout_layout_constraintBottom_toTopOf = 65;
    
    public static final int ConstraintLayout_Layout_layout_constraintCircle = 66;
    
    public static final int ConstraintLayout_Layout_layout_constraintCircleAngle = 67;
    
    public static final int ConstraintLayout_Layout_layout_constraintCircleRadius = 68;
    
    public static final int ConstraintLayout_Layout_layout_constraintDimensionRatio = 69;
    
    public static final int ConstraintLayout_Layout_layout_constraintEnd_toEndOf = 70;
    
    public static final int ConstraintLayout_Layout_layout_constraintEnd_toStartOf = 71;
    
    public static final int ConstraintLayout_Layout_layout_constraintGuide_begin = 72;
    
    public static final int ConstraintLayout_Layout_layout_constraintGuide_end = 73;
    
    public static final int ConstraintLayout_Layout_layout_constraintGuide_percent = 74;
    
    public static final int ConstraintLayout_Layout_layout_constraintHeight = 75;
    
    public static final int ConstraintLayout_Layout_layout_constraintHeight_default = 76;
    
    public static final int ConstraintLayout_Layout_layout_constraintHeight_max = 77;
    
    public static final int ConstraintLayout_Layout_layout_constraintHeight_min = 78;
    
    public static final int ConstraintLayout_Layout_layout_constraintHeight_percent = 79;
    
    public static final int ConstraintLayout_Layout_layout_constraintHorizontal_bias = 80;
    
    public static final int ConstraintLayout_Layout_layout_constraintHorizontal_chainStyle = 81;
    
    public static final int ConstraintLayout_Layout_layout_constraintHorizontal_weight = 82;
    
    public static final int ConstraintLayout_Layout_layout_constraintLeft_creator = 83;
    
    public static final int ConstraintLayout_Layout_layout_constraintLeft_toLeftOf = 84;
    
    public static final int ConstraintLayout_Layout_layout_constraintLeft_toRightOf = 85;
    
    public static final int ConstraintLayout_Layout_layout_constraintRight_creator = 86;
    
    public static final int ConstraintLayout_Layout_layout_constraintRight_toLeftOf = 87;
    
    public static final int ConstraintLayout_Layout_layout_constraintRight_toRightOf = 88;
    
    public static final int ConstraintLayout_Layout_layout_constraintStart_toEndOf = 89;
    
    public static final int ConstraintLayout_Layout_layout_constraintStart_toStartOf = 90;
    
    public static final int ConstraintLayout_Layout_layout_constraintTag = 91;
    
    public static final int ConstraintLayout_Layout_layout_constraintTop_creator = 92;
    
    public static final int ConstraintLayout_Layout_layout_constraintTop_toBottomOf = 93;
    
    public static final int ConstraintLayout_Layout_layout_constraintTop_toTopOf = 94;
    
    public static final int ConstraintLayout_Layout_layout_constraintVertical_bias = 95;
    
    public static final int ConstraintLayout_Layout_layout_constraintVertical_chainStyle = 96;
    
    public static final int ConstraintLayout_Layout_layout_constraintVertical_weight = 97;
    
    public static final int ConstraintLayout_Layout_layout_constraintWidth = 98;
    
    public static final int ConstraintLayout_Layout_layout_constraintWidth_default = 99;
    
    public static final int ConstraintLayout_Layout_layout_constraintWidth_max = 100;
    
    public static final int ConstraintLayout_Layout_layout_constraintWidth_min = 101;
    
    public static final int ConstraintLayout_Layout_layout_constraintWidth_percent = 102;
    
    public static final int ConstraintLayout_Layout_layout_editor_absoluteX = 103;
    
    public static final int ConstraintLayout_Layout_layout_editor_absoluteY = 104;
    
    public static final int ConstraintLayout_Layout_layout_goneMarginBaseline = 105;
    
    public static final int ConstraintLayout_Layout_layout_goneMarginBottom = 106;
    
    public static final int ConstraintLayout_Layout_layout_goneMarginEnd = 107;
    
    public static final int ConstraintLayout_Layout_layout_goneMarginLeft = 108;
    
    public static final int ConstraintLayout_Layout_layout_goneMarginRight = 109;
    
    public static final int ConstraintLayout_Layout_layout_goneMarginStart = 110;
    
    public static final int ConstraintLayout_Layout_layout_goneMarginTop = 111;
    
    public static final int ConstraintLayout_Layout_layout_marginBaseline = 112;
    
    public static final int ConstraintLayout_Layout_layout_optimizationLevel = 113;
    
    public static final int ConstraintLayout_Layout_layout_wrapBehaviorInParent = 114;
    
    public static final int[] ConstraintLayout_ReactiveGuide = new int[] { 2130969829, 2130969830, 2130969831, 2130969832 };
    
    public static final int ConstraintLayout_ReactiveGuide_reactiveGuide_animateChange = 0;
    
    public static final int ConstraintLayout_ReactiveGuide_reactiveGuide_applyToAllConstraintSets = 1;
    
    public static final int ConstraintLayout_ReactiveGuide_reactiveGuide_applyToConstraintSet = 2;
    
    public static final int ConstraintLayout_ReactiveGuide_reactiveGuide_valueId = 3;
    
    public static final int[] ConstraintLayout_placeholder = new int[] { 2130968987, 2130969800 };
    
    public static final int ConstraintLayout_placeholder_content = 0;
    
    public static final int ConstraintLayout_placeholder_placeholder_emptyVisibility = 1;
    
    public static final int[] ConstraintOverride = new int[] { 
        16842948, 16842960, 16842972, 16842996, 16842997, 16842999, 16843000, 16843001, 16843002, 16843039, 
        16843040, 16843071, 16843072, 16843551, 16843552, 16843553, 16843554, 16843555, 16843556, 16843557, 
        16843558, 16843559, 16843560, 16843701, 16843702, 16843770, 16843840, 2130968671, 2130968674, 2130968752, 
        2130968753, 2130968754, 2130968843, 2130968984, 2130969097, 2130969251, 2130969252, 2130969253, 2130969254, 2130969255, 
        2130969256, 2130969257, 2130969258, 2130969259, 2130969260, 2130969261, 2130969262, 2130969263, 2130969265, 2130969266, 
        2130969267, 2130969268, 2130969269, 2130969299, 2130969443, 2130969444, 2130969445, 2130969449, 2130969453, 2130969454, 
        2130969455, 2130969458, 2130969459, 2130969460, 2130969461, 2130969462, 2130969463, 2130969464, 2130969465, 2130969466, 
        2130969467, 2130969468, 2130969469, 2130969472, 2130969477, 2130969478, 2130969481, 2130969482, 2130969483, 2130969484, 
        2130969485, 2130969486, 2130969487, 2130969488, 2130969490, 2130969491, 2130969495, 2130969496, 2130969497, 2130969498, 
        2130969499, 2130969500, 2130969501, 2130969504, 2130969517, 2130969724, 2130969725, 2130969726, 2130969789, 2130969796, 
        2130969801, 2130969817, 2130969818, 2130969819, 2130970256, 2130970258, 2130970260, 2130970296 };
    
    public static final int ConstraintOverride_android_alpha = 13;
    
    public static final int ConstraintOverride_android_elevation = 26;
    
    public static final int ConstraintOverride_android_id = 1;
    
    public static final int ConstraintOverride_android_layout_height = 4;
    
    public static final int ConstraintOverride_android_layout_marginBottom = 8;
    
    public static final int ConstraintOverride_android_layout_marginEnd = 24;
    
    public static final int ConstraintOverride_android_layout_marginLeft = 5;
    
    public static final int ConstraintOverride_android_layout_marginRight = 7;
    
    public static final int ConstraintOverride_android_layout_marginStart = 23;
    
    public static final int ConstraintOverride_android_layout_marginTop = 6;
    
    public static final int ConstraintOverride_android_layout_width = 3;
    
    public static final int ConstraintOverride_android_maxHeight = 10;
    
    public static final int ConstraintOverride_android_maxWidth = 9;
    
    public static final int ConstraintOverride_android_minHeight = 12;
    
    public static final int ConstraintOverride_android_minWidth = 11;
    
    public static final int ConstraintOverride_android_orientation = 0;
    
    public static final int ConstraintOverride_android_rotation = 20;
    
    public static final int ConstraintOverride_android_rotationX = 21;
    
    public static final int ConstraintOverride_android_rotationY = 22;
    
    public static final int ConstraintOverride_android_scaleX = 18;
    
    public static final int ConstraintOverride_android_scaleY = 19;
    
    public static final int ConstraintOverride_android_transformPivotX = 14;
    
    public static final int ConstraintOverride_android_transformPivotY = 15;
    
    public static final int ConstraintOverride_android_translationX = 16;
    
    public static final int ConstraintOverride_android_translationY = 17;
    
    public static final int ConstraintOverride_android_translationZ = 25;
    
    public static final int ConstraintOverride_android_visibility = 2;
    
    public static final int ConstraintOverride_animateCircleAngleTo = 27;
    
    public static final int ConstraintOverride_animateRelativeTo = 28;
    
    public static final int ConstraintOverride_barrierAllowsGoneWidgets = 29;
    
    public static final int ConstraintOverride_barrierDirection = 30;
    
    public static final int ConstraintOverride_barrierMargin = 31;
    
    public static final int ConstraintOverride_chainUseRtl = 32;
    
    public static final int ConstraintOverride_constraint_referenced_ids = 33;
    
    public static final int ConstraintOverride_drawPath = 34;
    
    public static final int ConstraintOverride_flow_firstHorizontalBias = 35;
    
    public static final int ConstraintOverride_flow_firstHorizontalStyle = 36;
    
    public static final int ConstraintOverride_flow_firstVerticalBias = 37;
    
    public static final int ConstraintOverride_flow_firstVerticalStyle = 38;
    
    public static final int ConstraintOverride_flow_horizontalAlign = 39;
    
    public static final int ConstraintOverride_flow_horizontalBias = 40;
    
    public static final int ConstraintOverride_flow_horizontalGap = 41;
    
    public static final int ConstraintOverride_flow_horizontalStyle = 42;
    
    public static final int ConstraintOverride_flow_lastHorizontalBias = 43;
    
    public static final int ConstraintOverride_flow_lastHorizontalStyle = 44;
    
    public static final int ConstraintOverride_flow_lastVerticalBias = 45;
    
    public static final int ConstraintOverride_flow_lastVerticalStyle = 46;
    
    public static final int ConstraintOverride_flow_maxElementsWrap = 47;
    
    public static final int ConstraintOverride_flow_verticalAlign = 48;
    
    public static final int ConstraintOverride_flow_verticalBias = 49;
    
    public static final int ConstraintOverride_flow_verticalGap = 50;
    
    public static final int ConstraintOverride_flow_verticalStyle = 51;
    
    public static final int ConstraintOverride_flow_wrapMode = 52;
    
    public static final int ConstraintOverride_guidelineUseRtl = 53;
    
    public static final int ConstraintOverride_layout_constrainedHeight = 54;
    
    public static final int ConstraintOverride_layout_constrainedWidth = 55;
    
    public static final int ConstraintOverride_layout_constraintBaseline_creator = 56;
    
    public static final int ConstraintOverride_layout_constraintBottom_creator = 57;
    
    public static final int ConstraintOverride_layout_constraintCircleAngle = 58;
    
    public static final int ConstraintOverride_layout_constraintCircleRadius = 59;
    
    public static final int ConstraintOverride_layout_constraintDimensionRatio = 60;
    
    public static final int ConstraintOverride_layout_constraintGuide_begin = 61;
    
    public static final int ConstraintOverride_layout_constraintGuide_end = 62;
    
    public static final int ConstraintOverride_layout_constraintGuide_percent = 63;
    
    public static final int ConstraintOverride_layout_constraintHeight = 64;
    
    public static final int ConstraintOverride_layout_constraintHeight_default = 65;
    
    public static final int ConstraintOverride_layout_constraintHeight_max = 66;
    
    public static final int ConstraintOverride_layout_constraintHeight_min = 67;
    
    public static final int ConstraintOverride_layout_constraintHeight_percent = 68;
    
    public static final int ConstraintOverride_layout_constraintHorizontal_bias = 69;
    
    public static final int ConstraintOverride_layout_constraintHorizontal_chainStyle = 70;
    
    public static final int ConstraintOverride_layout_constraintHorizontal_weight = 71;
    
    public static final int ConstraintOverride_layout_constraintLeft_creator = 72;
    
    public static final int ConstraintOverride_layout_constraintRight_creator = 73;
    
    public static final int ConstraintOverride_layout_constraintTag = 74;
    
    public static final int ConstraintOverride_layout_constraintTop_creator = 75;
    
    public static final int ConstraintOverride_layout_constraintVertical_bias = 76;
    
    public static final int ConstraintOverride_layout_constraintVertical_chainStyle = 77;
    
    public static final int ConstraintOverride_layout_constraintVertical_weight = 78;
    
    public static final int ConstraintOverride_layout_constraintWidth = 79;
    
    public static final int ConstraintOverride_layout_constraintWidth_default = 80;
    
    public static final int ConstraintOverride_layout_constraintWidth_max = 81;
    
    public static final int ConstraintOverride_layout_constraintWidth_min = 82;
    
    public static final int ConstraintOverride_layout_constraintWidth_percent = 83;
    
    public static final int ConstraintOverride_layout_editor_absoluteX = 84;
    
    public static final int ConstraintOverride_layout_editor_absoluteY = 85;
    
    public static final int ConstraintOverride_layout_goneMarginBaseline = 86;
    
    public static final int ConstraintOverride_layout_goneMarginBottom = 87;
    
    public static final int ConstraintOverride_layout_goneMarginEnd = 88;
    
    public static final int ConstraintOverride_layout_goneMarginLeft = 89;
    
    public static final int ConstraintOverride_layout_goneMarginRight = 90;
    
    public static final int ConstraintOverride_layout_goneMarginStart = 91;
    
    public static final int ConstraintOverride_layout_goneMarginTop = 92;
    
    public static final int ConstraintOverride_layout_marginBaseline = 93;
    
    public static final int ConstraintOverride_layout_wrapBehaviorInParent = 94;
    
    public static final int ConstraintOverride_motionProgress = 95;
    
    public static final int ConstraintOverride_motionStagger = 96;
    
    public static final int ConstraintOverride_motionTarget = 97;
    
    public static final int ConstraintOverride_pathMotionArc = 98;
    
    public static final int ConstraintOverride_pivotAnchor = 99;
    
    public static final int ConstraintOverride_polarRelativeTo = 100;
    
    public static final int ConstraintOverride_quantizeMotionInterpolator = 101;
    
    public static final int ConstraintOverride_quantizeMotionPhase = 102;
    
    public static final int ConstraintOverride_quantizeMotionSteps = 103;
    
    public static final int ConstraintOverride_transformPivotTarget = 104;
    
    public static final int ConstraintOverride_transitionEasing = 105;
    
    public static final int ConstraintOverride_transitionPathRotate = 106;
    
    public static final int ConstraintOverride_visibilityMode = 107;
    
    public static final int[] ConstraintSet = new int[] { 
        16842948, 16842960, 16842972, 16842996, 16842997, 16842999, 16843000, 16843001, 16843002, 16843039, 
        16843040, 16843071, 16843072, 16843189, 16843190, 16843551, 16843552, 16843553, 16843554, 16843555, 
        16843556, 16843557, 16843558, 16843559, 16843560, 16843701, 16843702, 16843770, 16843840, 2130968671, 
        2130968674, 2130968752, 2130968753, 2130968754, 2130968843, 2130968980, 2130968984, 2130968985, 2130969074, 2130969097, 
        2130969251, 2130969252, 2130969253, 2130969254, 2130969255, 2130969256, 2130969257, 2130969258, 2130969259, 2130969260, 
        2130969261, 2130969262, 2130969263, 2130969265, 2130969266, 2130969267, 2130969268, 2130969269, 2130969299, 2130969443, 
        2130969444, 2130969445, 2130969446, 2130969447, 2130969448, 2130969449, 2130969450, 2130969451, 2130969452, 2130969453, 
        2130969454, 2130969455, 2130969456, 2130969457, 2130969458, 2130969459, 2130969460, 2130969462, 2130969463, 2130969464, 
        2130969465, 2130969466, 2130969467, 2130969468, 2130969469, 2130969470, 2130969471, 2130969472, 2130969473, 2130969474, 
        2130969475, 2130969476, 2130969477, 2130969478, 2130969479, 2130969480, 2130969481, 2130969482, 2130969483, 2130969485, 
        2130969486, 2130969487, 2130969488, 2130969490, 2130969491, 2130969495, 2130969496, 2130969497, 2130969498, 2130969499, 
        2130969500, 2130969501, 2130969504, 2130969517, 2130969724, 2130969725, 2130969789, 2130969796, 2130969801, 2130969819, 
        2130970258, 2130970260 };
    
    public static final int ConstraintSet_android_alpha = 15;
    
    public static final int ConstraintSet_android_elevation = 28;
    
    public static final int ConstraintSet_android_id = 1;
    
    public static final int ConstraintSet_android_layout_height = 4;
    
    public static final int ConstraintSet_android_layout_marginBottom = 8;
    
    public static final int ConstraintSet_android_layout_marginEnd = 26;
    
    public static final int ConstraintSet_android_layout_marginLeft = 5;
    
    public static final int ConstraintSet_android_layout_marginRight = 7;
    
    public static final int ConstraintSet_android_layout_marginStart = 25;
    
    public static final int ConstraintSet_android_layout_marginTop = 6;
    
    public static final int ConstraintSet_android_layout_width = 3;
    
    public static final int ConstraintSet_android_maxHeight = 10;
    
    public static final int ConstraintSet_android_maxWidth = 9;
    
    public static final int ConstraintSet_android_minHeight = 12;
    
    public static final int ConstraintSet_android_minWidth = 11;
    
    public static final int ConstraintSet_android_orientation = 0;
    
    public static final int ConstraintSet_android_pivotX = 13;
    
    public static final int ConstraintSet_android_pivotY = 14;
    
    public static final int ConstraintSet_android_rotation = 22;
    
    public static final int ConstraintSet_android_rotationX = 23;
    
    public static final int ConstraintSet_android_rotationY = 24;
    
    public static final int ConstraintSet_android_scaleX = 20;
    
    public static final int ConstraintSet_android_scaleY = 21;
    
    public static final int ConstraintSet_android_transformPivotX = 16;
    
    public static final int ConstraintSet_android_transformPivotY = 17;
    
    public static final int ConstraintSet_android_translationX = 18;
    
    public static final int ConstraintSet_android_translationY = 19;
    
    public static final int ConstraintSet_android_translationZ = 27;
    
    public static final int ConstraintSet_android_visibility = 2;
    
    public static final int ConstraintSet_animateCircleAngleTo = 29;
    
    public static final int ConstraintSet_animateRelativeTo = 30;
    
    public static final int ConstraintSet_barrierAllowsGoneWidgets = 31;
    
    public static final int ConstraintSet_barrierDirection = 32;
    
    public static final int ConstraintSet_barrierMargin = 33;
    
    public static final int ConstraintSet_chainUseRtl = 34;
    
    public static final int ConstraintSet_constraintRotate = 35;
    
    public static final int ConstraintSet_constraint_referenced_ids = 36;
    
    public static final int ConstraintSet_constraint_referenced_tags = 37;
    
    public static final int ConstraintSet_deriveConstraintsFrom = 38;
    
    public static final int ConstraintSet_drawPath = 39;
    
    public static final int ConstraintSet_flow_firstHorizontalBias = 40;
    
    public static final int ConstraintSet_flow_firstHorizontalStyle = 41;
    
    public static final int ConstraintSet_flow_firstVerticalBias = 42;
    
    public static final int ConstraintSet_flow_firstVerticalStyle = 43;
    
    public static final int ConstraintSet_flow_horizontalAlign = 44;
    
    public static final int ConstraintSet_flow_horizontalBias = 45;
    
    public static final int ConstraintSet_flow_horizontalGap = 46;
    
    public static final int ConstraintSet_flow_horizontalStyle = 47;
    
    public static final int ConstraintSet_flow_lastHorizontalBias = 48;
    
    public static final int ConstraintSet_flow_lastHorizontalStyle = 49;
    
    public static final int ConstraintSet_flow_lastVerticalBias = 50;
    
    public static final int ConstraintSet_flow_lastVerticalStyle = 51;
    
    public static final int ConstraintSet_flow_maxElementsWrap = 52;
    
    public static final int ConstraintSet_flow_verticalAlign = 53;
    
    public static final int ConstraintSet_flow_verticalBias = 54;
    
    public static final int ConstraintSet_flow_verticalGap = 55;
    
    public static final int ConstraintSet_flow_verticalStyle = 56;
    
    public static final int ConstraintSet_flow_wrapMode = 57;
    
    public static final int ConstraintSet_guidelineUseRtl = 58;
    
    public static final int ConstraintSet_layout_constrainedHeight = 59;
    
    public static final int ConstraintSet_layout_constrainedWidth = 60;
    
    public static final int ConstraintSet_layout_constraintBaseline_creator = 61;
    
    public static final int ConstraintSet_layout_constraintBaseline_toBaselineOf = 62;
    
    public static final int ConstraintSet_layout_constraintBaseline_toBottomOf = 63;
    
    public static final int ConstraintSet_layout_constraintBaseline_toTopOf = 64;
    
    public static final int ConstraintSet_layout_constraintBottom_creator = 65;
    
    public static final int ConstraintSet_layout_constraintBottom_toBottomOf = 66;
    
    public static final int ConstraintSet_layout_constraintBottom_toTopOf = 67;
    
    public static final int ConstraintSet_layout_constraintCircle = 68;
    
    public static final int ConstraintSet_layout_constraintCircleAngle = 69;
    
    public static final int ConstraintSet_layout_constraintCircleRadius = 70;
    
    public static final int ConstraintSet_layout_constraintDimensionRatio = 71;
    
    public static final int ConstraintSet_layout_constraintEnd_toEndOf = 72;
    
    public static final int ConstraintSet_layout_constraintEnd_toStartOf = 73;
    
    public static final int ConstraintSet_layout_constraintGuide_begin = 74;
    
    public static final int ConstraintSet_layout_constraintGuide_end = 75;
    
    public static final int ConstraintSet_layout_constraintGuide_percent = 76;
    
    public static final int ConstraintSet_layout_constraintHeight_default = 77;
    
    public static final int ConstraintSet_layout_constraintHeight_max = 78;
    
    public static final int ConstraintSet_layout_constraintHeight_min = 79;
    
    public static final int ConstraintSet_layout_constraintHeight_percent = 80;
    
    public static final int ConstraintSet_layout_constraintHorizontal_bias = 81;
    
    public static final int ConstraintSet_layout_constraintHorizontal_chainStyle = 82;
    
    public static final int ConstraintSet_layout_constraintHorizontal_weight = 83;
    
    public static final int ConstraintSet_layout_constraintLeft_creator = 84;
    
    public static final int ConstraintSet_layout_constraintLeft_toLeftOf = 85;
    
    public static final int ConstraintSet_layout_constraintLeft_toRightOf = 86;
    
    public static final int ConstraintSet_layout_constraintRight_creator = 87;
    
    public static final int ConstraintSet_layout_constraintRight_toLeftOf = 88;
    
    public static final int ConstraintSet_layout_constraintRight_toRightOf = 89;
    
    public static final int ConstraintSet_layout_constraintStart_toEndOf = 90;
    
    public static final int ConstraintSet_layout_constraintStart_toStartOf = 91;
    
    public static final int ConstraintSet_layout_constraintTag = 92;
    
    public static final int ConstraintSet_layout_constraintTop_creator = 93;
    
    public static final int ConstraintSet_layout_constraintTop_toBottomOf = 94;
    
    public static final int ConstraintSet_layout_constraintTop_toTopOf = 95;
    
    public static final int ConstraintSet_layout_constraintVertical_bias = 96;
    
    public static final int ConstraintSet_layout_constraintVertical_chainStyle = 97;
    
    public static final int ConstraintSet_layout_constraintVertical_weight = 98;
    
    public static final int ConstraintSet_layout_constraintWidth_default = 99;
    
    public static final int ConstraintSet_layout_constraintWidth_max = 100;
    
    public static final int ConstraintSet_layout_constraintWidth_min = 101;
    
    public static final int ConstraintSet_layout_constraintWidth_percent = 102;
    
    public static final int ConstraintSet_layout_editor_absoluteX = 103;
    
    public static final int ConstraintSet_layout_editor_absoluteY = 104;
    
    public static final int ConstraintSet_layout_goneMarginBaseline = 105;
    
    public static final int ConstraintSet_layout_goneMarginBottom = 106;
    
    public static final int ConstraintSet_layout_goneMarginEnd = 107;
    
    public static final int ConstraintSet_layout_goneMarginLeft = 108;
    
    public static final int ConstraintSet_layout_goneMarginRight = 109;
    
    public static final int ConstraintSet_layout_goneMarginStart = 110;
    
    public static final int ConstraintSet_layout_goneMarginTop = 111;
    
    public static final int ConstraintSet_layout_marginBaseline = 112;
    
    public static final int ConstraintSet_layout_wrapBehaviorInParent = 113;
    
    public static final int ConstraintSet_motionProgress = 114;
    
    public static final int ConstraintSet_motionStagger = 115;
    
    public static final int ConstraintSet_pathMotionArc = 116;
    
    public static final int ConstraintSet_pivotAnchor = 117;
    
    public static final int ConstraintSet_polarRelativeTo = 118;
    
    public static final int ConstraintSet_quantizeMotionSteps = 119;
    
    public static final int ConstraintSet_transitionEasing = 120;
    
    public static final int ConstraintSet_transitionPathRotate = 121;
    
    public static final int Constraint_android_alpha = 13;
    
    public static final int Constraint_android_elevation = 26;
    
    public static final int Constraint_android_id = 1;
    
    public static final int Constraint_android_layout_height = 4;
    
    public static final int Constraint_android_layout_marginBottom = 8;
    
    public static final int Constraint_android_layout_marginEnd = 24;
    
    public static final int Constraint_android_layout_marginLeft = 5;
    
    public static final int Constraint_android_layout_marginRight = 7;
    
    public static final int Constraint_android_layout_marginStart = 23;
    
    public static final int Constraint_android_layout_marginTop = 6;
    
    public static final int Constraint_android_layout_width = 3;
    
    public static final int Constraint_android_maxHeight = 10;
    
    public static final int Constraint_android_maxWidth = 9;
    
    public static final int Constraint_android_minHeight = 12;
    
    public static final int Constraint_android_minWidth = 11;
    
    public static final int Constraint_android_orientation = 0;
    
    public static final int Constraint_android_rotation = 20;
    
    public static final int Constraint_android_rotationX = 21;
    
    public static final int Constraint_android_rotationY = 22;
    
    public static final int Constraint_android_scaleX = 18;
    
    public static final int Constraint_android_scaleY = 19;
    
    public static final int Constraint_android_transformPivotX = 14;
    
    public static final int Constraint_android_transformPivotY = 15;
    
    public static final int Constraint_android_translationX = 16;
    
    public static final int Constraint_android_translationY = 17;
    
    public static final int Constraint_android_translationZ = 25;
    
    public static final int Constraint_android_visibility = 2;
    
    public static final int Constraint_animateCircleAngleTo = 27;
    
    public static final int Constraint_animateRelativeTo = 28;
    
    public static final int Constraint_barrierAllowsGoneWidgets = 29;
    
    public static final int Constraint_barrierDirection = 30;
    
    public static final int Constraint_barrierMargin = 31;
    
    public static final int Constraint_chainUseRtl = 32;
    
    public static final int Constraint_constraint_referenced_ids = 33;
    
    public static final int Constraint_constraint_referenced_tags = 34;
    
    public static final int Constraint_drawPath = 35;
    
    public static final int Constraint_flow_firstHorizontalBias = 36;
    
    public static final int Constraint_flow_firstHorizontalStyle = 37;
    
    public static final int Constraint_flow_firstVerticalBias = 38;
    
    public static final int Constraint_flow_firstVerticalStyle = 39;
    
    public static final int Constraint_flow_horizontalAlign = 40;
    
    public static final int Constraint_flow_horizontalBias = 41;
    
    public static final int Constraint_flow_horizontalGap = 42;
    
    public static final int Constraint_flow_horizontalStyle = 43;
    
    public static final int Constraint_flow_lastHorizontalBias = 44;
    
    public static final int Constraint_flow_lastHorizontalStyle = 45;
    
    public static final int Constraint_flow_lastVerticalBias = 46;
    
    public static final int Constraint_flow_lastVerticalStyle = 47;
    
    public static final int Constraint_flow_maxElementsWrap = 48;
    
    public static final int Constraint_flow_verticalAlign = 49;
    
    public static final int Constraint_flow_verticalBias = 50;
    
    public static final int Constraint_flow_verticalGap = 51;
    
    public static final int Constraint_flow_verticalStyle = 52;
    
    public static final int Constraint_flow_wrapMode = 53;
    
    public static final int Constraint_guidelineUseRtl = 54;
    
    public static final int Constraint_layout_constrainedHeight = 55;
    
    public static final int Constraint_layout_constrainedWidth = 56;
    
    public static final int Constraint_layout_constraintBaseline_creator = 57;
    
    public static final int Constraint_layout_constraintBaseline_toBaselineOf = 58;
    
    public static final int Constraint_layout_constraintBaseline_toBottomOf = 59;
    
    public static final int Constraint_layout_constraintBaseline_toTopOf = 60;
    
    public static final int Constraint_layout_constraintBottom_creator = 61;
    
    public static final int Constraint_layout_constraintBottom_toBottomOf = 62;
    
    public static final int Constraint_layout_constraintBottom_toTopOf = 63;
    
    public static final int Constraint_layout_constraintCircle = 64;
    
    public static final int Constraint_layout_constraintCircleAngle = 65;
    
    public static final int Constraint_layout_constraintCircleRadius = 66;
    
    public static final int Constraint_layout_constraintDimensionRatio = 67;
    
    public static final int Constraint_layout_constraintEnd_toEndOf = 68;
    
    public static final int Constraint_layout_constraintEnd_toStartOf = 69;
    
    public static final int Constraint_layout_constraintGuide_begin = 70;
    
    public static final int Constraint_layout_constraintGuide_end = 71;
    
    public static final int Constraint_layout_constraintGuide_percent = 72;
    
    public static final int Constraint_layout_constraintHeight = 73;
    
    public static final int Constraint_layout_constraintHeight_default = 74;
    
    public static final int Constraint_layout_constraintHeight_max = 75;
    
    public static final int Constraint_layout_constraintHeight_min = 76;
    
    public static final int Constraint_layout_constraintHeight_percent = 77;
    
    public static final int Constraint_layout_constraintHorizontal_bias = 78;
    
    public static final int Constraint_layout_constraintHorizontal_chainStyle = 79;
    
    public static final int Constraint_layout_constraintHorizontal_weight = 80;
    
    public static final int Constraint_layout_constraintLeft_creator = 81;
    
    public static final int Constraint_layout_constraintLeft_toLeftOf = 82;
    
    public static final int Constraint_layout_constraintLeft_toRightOf = 83;
    
    public static final int Constraint_layout_constraintRight_creator = 84;
    
    public static final int Constraint_layout_constraintRight_toLeftOf = 85;
    
    public static final int Constraint_layout_constraintRight_toRightOf = 86;
    
    public static final int Constraint_layout_constraintStart_toEndOf = 87;
    
    public static final int Constraint_layout_constraintStart_toStartOf = 88;
    
    public static final int Constraint_layout_constraintTag = 89;
    
    public static final int Constraint_layout_constraintTop_creator = 90;
    
    public static final int Constraint_layout_constraintTop_toBottomOf = 91;
    
    public static final int Constraint_layout_constraintTop_toTopOf = 92;
    
    public static final int Constraint_layout_constraintVertical_bias = 93;
    
    public static final int Constraint_layout_constraintVertical_chainStyle = 94;
    
    public static final int Constraint_layout_constraintVertical_weight = 95;
    
    public static final int Constraint_layout_constraintWidth = 96;
    
    public static final int Constraint_layout_constraintWidth_default = 97;
    
    public static final int Constraint_layout_constraintWidth_max = 98;
    
    public static final int Constraint_layout_constraintWidth_min = 99;
    
    public static final int Constraint_layout_constraintWidth_percent = 100;
    
    public static final int Constraint_layout_editor_absoluteX = 101;
    
    public static final int Constraint_layout_editor_absoluteY = 102;
    
    public static final int Constraint_layout_goneMarginBaseline = 103;
    
    public static final int Constraint_layout_goneMarginBottom = 104;
    
    public static final int Constraint_layout_goneMarginEnd = 105;
    
    public static final int Constraint_layout_goneMarginLeft = 106;
    
    public static final int Constraint_layout_goneMarginRight = 107;
    
    public static final int Constraint_layout_goneMarginStart = 108;
    
    public static final int Constraint_layout_goneMarginTop = 109;
    
    public static final int Constraint_layout_marginBaseline = 110;
    
    public static final int Constraint_layout_wrapBehaviorInParent = 111;
    
    public static final int Constraint_motionProgress = 112;
    
    public static final int Constraint_motionStagger = 113;
    
    public static final int Constraint_pathMotionArc = 114;
    
    public static final int Constraint_pivotAnchor = 115;
    
    public static final int Constraint_polarRelativeTo = 116;
    
    public static final int Constraint_quantizeMotionInterpolator = 117;
    
    public static final int Constraint_quantizeMotionPhase = 118;
    
    public static final int Constraint_quantizeMotionSteps = 119;
    
    public static final int Constraint_transformPivotTarget = 120;
    
    public static final int Constraint_transitionEasing = 121;
    
    public static final int Constraint_transitionPathRotate = 122;
    
    public static final int Constraint_visibilityMode = 123;
    
    public static final int[] CustomAttribute = new int[] { 
        2130968692, 2130969050, 2130969051, 2130969052, 2130969053, 2130969054, 2130969055, 2130969057, 2130969058, 2130969059, 
        2130969666 };
    
    public static final int CustomAttribute_attributeName = 0;
    
    public static final int CustomAttribute_customBoolean = 1;
    
    public static final int CustomAttribute_customColorDrawableValue = 2;
    
    public static final int CustomAttribute_customColorValue = 3;
    
    public static final int CustomAttribute_customDimension = 4;
    
    public static final int CustomAttribute_customFloatValue = 5;
    
    public static final int CustomAttribute_customIntegerValue = 6;
    
    public static final int CustomAttribute_customPixelDimension = 7;
    
    public static final int CustomAttribute_customReference = 8;
    
    public static final int CustomAttribute_customStringValue = 9;
    
    public static final int CustomAttribute_methodName = 10;
    
    public static final int[] DrawerArrowToggle = new int[] { 2130968683, 2130968686, 2130968751, 2130968916, 2130969104, 2130969290, 2130969923, 2130970152 };
    
    public static final int DrawerArrowToggle_arrowHeadLength = 0;
    
    public static final int DrawerArrowToggle_arrowShaftLength = 1;
    
    public static final int DrawerArrowToggle_barLength = 2;
    
    public static final int DrawerArrowToggle_color = 3;
    
    public static final int DrawerArrowToggle_drawableSize = 4;
    
    public static final int DrawerArrowToggle_gapBetweenBars = 5;
    
    public static final int DrawerArrowToggle_spinBars = 6;
    
    public static final int DrawerArrowToggle_thickness = 7;
    
    public static final int[] FontFamily = new int[] { 2130969275, 2130969276, 2130969277, 2130969278, 2130969279, 2130969280, 2130969281 };
    
    public static final int[] FontFamilyFont = new int[] { 16844082, 16844083, 16844095, 16844143, 16844144, 2130969273, 2130969282, 2130969283, 2130969284, 2130970265 };
    
    public static final int FontFamilyFont_android_font = 0;
    
    public static final int FontFamilyFont_android_fontStyle = 2;
    
    public static final int FontFamilyFont_android_fontVariationSettings = 4;
    
    public static final int FontFamilyFont_android_fontWeight = 1;
    
    public static final int FontFamilyFont_android_ttcIndex = 3;
    
    public static final int FontFamilyFont_font = 5;
    
    public static final int FontFamilyFont_fontStyle = 6;
    
    public static final int FontFamilyFont_fontVariationSettings = 7;
    
    public static final int FontFamilyFont_fontWeight = 8;
    
    public static final int FontFamilyFont_ttcIndex = 9;
    
    public static final int FontFamily_fontProviderAuthority = 0;
    
    public static final int FontFamily_fontProviderCerts = 1;
    
    public static final int FontFamily_fontProviderFetchStrategy = 2;
    
    public static final int FontFamily_fontProviderFetchTimeout = 3;
    
    public static final int FontFamily_fontProviderPackage = 4;
    
    public static final int FontFamily_fontProviderQuery = 5;
    
    public static final int FontFamily_fontProviderSystemFontFamily = 6;
    
    public static final int[] GradientColor = new int[] { 
        16843165, 16843166, 16843169, 16843170, 16843171, 16843172, 16843265, 16843275, 16844048, 16844049, 
        16844050, 16844051 };
    
    public static final int[] GradientColorItem = new int[] { 16843173, 16844052 };
    
    public static final int GradientColorItem_android_color = 0;
    
    public static final int GradientColorItem_android_offset = 1;
    
    public static final int GradientColor_android_centerColor = 7;
    
    public static final int GradientColor_android_centerX = 3;
    
    public static final int GradientColor_android_centerY = 4;
    
    public static final int GradientColor_android_endColor = 1;
    
    public static final int GradientColor_android_endX = 10;
    
    public static final int GradientColor_android_endY = 11;
    
    public static final int GradientColor_android_gradientRadius = 5;
    
    public static final int GradientColor_android_startColor = 0;
    
    public static final int GradientColor_android_startX = 8;
    
    public static final int GradientColor_android_startY = 9;
    
    public static final int GradientColor_android_tileMode = 6;
    
    public static final int GradientColor_android_type = 2;
    
    public static final int[] ImageFilterView = new int[] { 
        2130968670, 2130968767, 2130968789, 2130969003, 2130969047, 2130969337, 2130969338, 2130969339, 2130969340, 2130969768, 
        2130969861, 2130969862, 2130969863, 2130970305 };
    
    public static final int ImageFilterView_altSrc = 0;
    
    public static final int ImageFilterView_blendSrc = 1;
    
    public static final int ImageFilterView_brightness = 2;
    
    public static final int ImageFilterView_contrast = 3;
    
    public static final int ImageFilterView_crossfade = 4;
    
    public static final int ImageFilterView_imagePanX = 5;
    
    public static final int ImageFilterView_imagePanY = 6;
    
    public static final int ImageFilterView_imageRotate = 7;
    
    public static final int ImageFilterView_imageZoom = 8;
    
    public static final int ImageFilterView_overlay = 9;
    
    public static final int ImageFilterView_round = 10;
    
    public static final int ImageFilterView_roundPercent = 11;
    
    public static final int ImageFilterView_saturation = 12;
    
    public static final int ImageFilterView_warmth = 13;
    
    public static final int[] KeyAttribute = new int[] { 
        16843551, 16843552, 16843553, 16843554, 16843555, 16843556, 16843557, 16843558, 16843559, 16843560, 
        16843770, 16843840, 2130969049, 2130969288, 2130969724, 2130969726, 2130970256, 2130970258, 2130970260 };
    
    public static final int KeyAttribute_android_alpha = 0;
    
    public static final int KeyAttribute_android_elevation = 11;
    
    public static final int KeyAttribute_android_rotation = 7;
    
    public static final int KeyAttribute_android_rotationX = 8;
    
    public static final int KeyAttribute_android_rotationY = 9;
    
    public static final int KeyAttribute_android_scaleX = 5;
    
    public static final int KeyAttribute_android_scaleY = 6;
    
    public static final int KeyAttribute_android_transformPivotX = 1;
    
    public static final int KeyAttribute_android_transformPivotY = 2;
    
    public static final int KeyAttribute_android_translationX = 3;
    
    public static final int KeyAttribute_android_translationY = 4;
    
    public static final int KeyAttribute_android_translationZ = 10;
    
    public static final int KeyAttribute_curveFit = 12;
    
    public static final int KeyAttribute_framePosition = 13;
    
    public static final int KeyAttribute_motionProgress = 14;
    
    public static final int KeyAttribute_motionTarget = 15;
    
    public static final int KeyAttribute_transformPivotTarget = 16;
    
    public static final int KeyAttribute_transitionEasing = 17;
    
    public static final int KeyAttribute_transitionPathRotate = 18;
    
    public static final int[] KeyCycle = new int[] { 
        16843551, 16843554, 16843555, 16843556, 16843557, 16843558, 16843559, 16843560, 16843770, 16843840, 
        2130969049, 2130969288, 2130969724, 2130969726, 2130970258, 2130970260, 2130970307, 2130970308, 2130970309, 2130970310, 
        2130970311 };
    
    public static final int KeyCycle_android_alpha = 0;
    
    public static final int KeyCycle_android_elevation = 9;
    
    public static final int KeyCycle_android_rotation = 5;
    
    public static final int KeyCycle_android_rotationX = 6;
    
    public static final int KeyCycle_android_rotationY = 7;
    
    public static final int KeyCycle_android_scaleX = 3;
    
    public static final int KeyCycle_android_scaleY = 4;
    
    public static final int KeyCycle_android_translationX = 1;
    
    public static final int KeyCycle_android_translationY = 2;
    
    public static final int KeyCycle_android_translationZ = 8;
    
    public static final int KeyCycle_curveFit = 10;
    
    public static final int KeyCycle_framePosition = 11;
    
    public static final int KeyCycle_motionProgress = 12;
    
    public static final int KeyCycle_motionTarget = 13;
    
    public static final int KeyCycle_transitionEasing = 14;
    
    public static final int KeyCycle_transitionPathRotate = 15;
    
    public static final int KeyCycle_waveOffset = 16;
    
    public static final int KeyCycle_wavePeriod = 17;
    
    public static final int KeyCycle_wavePhase = 18;
    
    public static final int KeyCycle_waveShape = 19;
    
    public static final int KeyCycle_waveVariesBy = 20;
    
    public static final int[] KeyFrame = new int[0];
    
    public static final int[] KeyFramesAcceleration = new int[0];
    
    public static final int[] KeyFramesVelocity = new int[0];
    
    public static final int[] KeyPosition = new int[] { 
        2130969049, 2130969097, 2130969288, 2130969424, 2130969726, 2130969789, 2130969791, 2130969792, 2130969793, 2130969794, 
        2130969917, 2130970258 };
    
    public static final int KeyPosition_curveFit = 0;
    
    public static final int KeyPosition_drawPath = 1;
    
    public static final int KeyPosition_framePosition = 2;
    
    public static final int KeyPosition_keyPositionType = 3;
    
    public static final int KeyPosition_motionTarget = 4;
    
    public static final int KeyPosition_pathMotionArc = 5;
    
    public static final int KeyPosition_percentHeight = 6;
    
    public static final int KeyPosition_percentWidth = 7;
    
    public static final int KeyPosition_percentX = 8;
    
    public static final int KeyPosition_percentY = 9;
    
    public static final int KeyPosition_sizePercent = 10;
    
    public static final int KeyPosition_transitionEasing = 11;
    
    public static final int[] KeyTimeCycle = new int[] { 
        16843551, 16843554, 16843555, 16843556, 16843557, 16843558, 16843559, 16843560, 16843770, 16843840, 
        2130969049, 2130969288, 2130969724, 2130969726, 2130970258, 2130970260, 2130970306, 2130970307, 2130970308, 2130970309, 
        2130970310 };
    
    public static final int KeyTimeCycle_android_alpha = 0;
    
    public static final int KeyTimeCycle_android_elevation = 9;
    
    public static final int KeyTimeCycle_android_rotation = 5;
    
    public static final int KeyTimeCycle_android_rotationX = 6;
    
    public static final int KeyTimeCycle_android_rotationY = 7;
    
    public static final int KeyTimeCycle_android_scaleX = 3;
    
    public static final int KeyTimeCycle_android_scaleY = 4;
    
    public static final int KeyTimeCycle_android_translationX = 1;
    
    public static final int KeyTimeCycle_android_translationY = 2;
    
    public static final int KeyTimeCycle_android_translationZ = 8;
    
    public static final int KeyTimeCycle_curveFit = 10;
    
    public static final int KeyTimeCycle_framePosition = 11;
    
    public static final int KeyTimeCycle_motionProgress = 12;
    
    public static final int KeyTimeCycle_motionTarget = 13;
    
    public static final int KeyTimeCycle_transitionEasing = 14;
    
    public static final int KeyTimeCycle_transitionPathRotate = 15;
    
    public static final int KeyTimeCycle_waveDecay = 16;
    
    public static final int KeyTimeCycle_waveOffset = 17;
    
    public static final int KeyTimeCycle_wavePeriod = 18;
    
    public static final int KeyTimeCycle_wavePhase = 19;
    
    public static final int KeyTimeCycle_waveShape = 20;
    
    public static final int[] KeyTrigger = new int[] { 
        2130969288, 2130969726, 2130969727, 2130969728, 2130969760, 2130969762, 2130969763, 2130970262, 2130970263, 2130970264, 
        2130970293, 2130970294, 2130970295 };
    
    public static final int KeyTrigger_framePosition = 0;
    
    public static final int KeyTrigger_motionTarget = 1;
    
    public static final int KeyTrigger_motion_postLayoutCollision = 2;
    
    public static final int KeyTrigger_motion_triggerOnCollision = 3;
    
    public static final int KeyTrigger_onCross = 4;
    
    public static final int KeyTrigger_onNegativeCross = 5;
    
    public static final int KeyTrigger_onPositiveCross = 6;
    
    public static final int KeyTrigger_triggerId = 7;
    
    public static final int KeyTrigger_triggerReceiver = 8;
    
    public static final int KeyTrigger_triggerSlack = 9;
    
    public static final int KeyTrigger_viewTransitionOnCross = 10;
    
    public static final int KeyTrigger_viewTransitionOnNegativeCross = 11;
    
    public static final int KeyTrigger_viewTransitionOnPositiveCross = 12;
    
    public static final int[] Layout = new int[] { 
        16842948, 16842996, 16842997, 16842999, 16843000, 16843001, 16843002, 16843701, 16843702, 2130968752, 
        2130968753, 2130968754, 2130968843, 2130968984, 2130968985, 2130969299, 2130969443, 2130969444, 2130969445, 2130969446, 
        2130969447, 2130969448, 2130969449, 2130969450, 2130969451, 2130969452, 2130969453, 2130969454, 2130969455, 2130969456, 
        2130969457, 2130969458, 2130969459, 2130969460, 2130969461, 2130969462, 2130969463, 2130969464, 2130969465, 2130969466, 
        2130969467, 2130969468, 2130969469, 2130969470, 2130969471, 2130969472, 2130969473, 2130969474, 2130969475, 2130969476, 
        2130969478, 2130969479, 2130969480, 2130969481, 2130969482, 2130969483, 2130969484, 2130969485, 2130969486, 2130969487, 
        2130969488, 2130969490, 2130969491, 2130969495, 2130969496, 2130969497, 2130969498, 2130969499, 2130969500, 2130969501, 
        2130969504, 2130969517, 2130969632, 2130969638, 2130969672, 2130969677 };
    
    public static final int Layout_android_layout_height = 2;
    
    public static final int Layout_android_layout_marginBottom = 6;
    
    public static final int Layout_android_layout_marginEnd = 8;
    
    public static final int Layout_android_layout_marginLeft = 3;
    
    public static final int Layout_android_layout_marginRight = 5;
    
    public static final int Layout_android_layout_marginStart = 7;
    
    public static final int Layout_android_layout_marginTop = 4;
    
    public static final int Layout_android_layout_width = 1;
    
    public static final int Layout_android_orientation = 0;
    
    public static final int Layout_barrierAllowsGoneWidgets = 9;
    
    public static final int Layout_barrierDirection = 10;
    
    public static final int Layout_barrierMargin = 11;
    
    public static final int Layout_chainUseRtl = 12;
    
    public static final int Layout_constraint_referenced_ids = 13;
    
    public static final int Layout_constraint_referenced_tags = 14;
    
    public static final int Layout_guidelineUseRtl = 15;
    
    public static final int Layout_layout_constrainedHeight = 16;
    
    public static final int Layout_layout_constrainedWidth = 17;
    
    public static final int Layout_layout_constraintBaseline_creator = 18;
    
    public static final int Layout_layout_constraintBaseline_toBaselineOf = 19;
    
    public static final int Layout_layout_constraintBaseline_toBottomOf = 20;
    
    public static final int Layout_layout_constraintBaseline_toTopOf = 21;
    
    public static final int Layout_layout_constraintBottom_creator = 22;
    
    public static final int Layout_layout_constraintBottom_toBottomOf = 23;
    
    public static final int Layout_layout_constraintBottom_toTopOf = 24;
    
    public static final int Layout_layout_constraintCircle = 25;
    
    public static final int Layout_layout_constraintCircleAngle = 26;
    
    public static final int Layout_layout_constraintCircleRadius = 27;
    
    public static final int Layout_layout_constraintDimensionRatio = 28;
    
    public static final int Layout_layout_constraintEnd_toEndOf = 29;
    
    public static final int Layout_layout_constraintEnd_toStartOf = 30;
    
    public static final int Layout_layout_constraintGuide_begin = 31;
    
    public static final int Layout_layout_constraintGuide_end = 32;
    
    public static final int Layout_layout_constraintGuide_percent = 33;
    
    public static final int Layout_layout_constraintHeight = 34;
    
    public static final int Layout_layout_constraintHeight_default = 35;
    
    public static final int Layout_layout_constraintHeight_max = 36;
    
    public static final int Layout_layout_constraintHeight_min = 37;
    
    public static final int Layout_layout_constraintHeight_percent = 38;
    
    public static final int Layout_layout_constraintHorizontal_bias = 39;
    
    public static final int Layout_layout_constraintHorizontal_chainStyle = 40;
    
    public static final int Layout_layout_constraintHorizontal_weight = 41;
    
    public static final int Layout_layout_constraintLeft_creator = 42;
    
    public static final int Layout_layout_constraintLeft_toLeftOf = 43;
    
    public static final int Layout_layout_constraintLeft_toRightOf = 44;
    
    public static final int Layout_layout_constraintRight_creator = 45;
    
    public static final int Layout_layout_constraintRight_toLeftOf = 46;
    
    public static final int Layout_layout_constraintRight_toRightOf = 47;
    
    public static final int Layout_layout_constraintStart_toEndOf = 48;
    
    public static final int Layout_layout_constraintStart_toStartOf = 49;
    
    public static final int Layout_layout_constraintTop_creator = 50;
    
    public static final int Layout_layout_constraintTop_toBottomOf = 51;
    
    public static final int Layout_layout_constraintTop_toTopOf = 52;
    
    public static final int Layout_layout_constraintVertical_bias = 53;
    
    public static final int Layout_layout_constraintVertical_chainStyle = 54;
    
    public static final int Layout_layout_constraintVertical_weight = 55;
    
    public static final int Layout_layout_constraintWidth = 56;
    
    public static final int Layout_layout_constraintWidth_default = 57;
    
    public static final int Layout_layout_constraintWidth_max = 58;
    
    public static final int Layout_layout_constraintWidth_min = 59;
    
    public static final int Layout_layout_constraintWidth_percent = 60;
    
    public static final int Layout_layout_editor_absoluteX = 61;
    
    public static final int Layout_layout_editor_absoluteY = 62;
    
    public static final int Layout_layout_goneMarginBaseline = 63;
    
    public static final int Layout_layout_goneMarginBottom = 64;
    
    public static final int Layout_layout_goneMarginEnd = 65;
    
    public static final int Layout_layout_goneMarginLeft = 66;
    
    public static final int Layout_layout_goneMarginRight = 67;
    
    public static final int Layout_layout_goneMarginStart = 68;
    
    public static final int Layout_layout_goneMarginTop = 69;
    
    public static final int Layout_layout_marginBaseline = 70;
    
    public static final int Layout_layout_wrapBehaviorInParent = 71;
    
    public static final int Layout_maxHeight = 72;
    
    public static final int Layout_maxWidth = 73;
    
    public static final int Layout_minHeight = 74;
    
    public static final int Layout_minWidth = 75;
    
    public static final int[] LinearLayoutCompat = new int[] { 16842927, 16842948, 16843046, 16843047, 16843048, 2130969079, 2130969087, 2130969662, 2130969902 };
    
    public static final int[] LinearLayoutCompat_Layout = new int[] { 16842931, 16842996, 16842997, 16843137 };
    
    public static final int LinearLayoutCompat_Layout_android_layout_gravity = 0;
    
    public static final int LinearLayoutCompat_Layout_android_layout_height = 2;
    
    public static final int LinearLayoutCompat_Layout_android_layout_weight = 3;
    
    public static final int LinearLayoutCompat_Layout_android_layout_width = 1;
    
    public static final int LinearLayoutCompat_android_baselineAligned = 2;
    
    public static final int LinearLayoutCompat_android_baselineAlignedChildIndex = 3;
    
    public static final int LinearLayoutCompat_android_gravity = 0;
    
    public static final int LinearLayoutCompat_android_orientation = 1;
    
    public static final int LinearLayoutCompat_android_weightSum = 4;
    
    public static final int LinearLayoutCompat_divider = 5;
    
    public static final int LinearLayoutCompat_dividerPadding = 6;
    
    public static final int LinearLayoutCompat_measureWithLargestChild = 7;
    
    public static final int LinearLayoutCompat_showDividers = 8;
    
    public static final int[] ListPopupWindow = new int[] { 16843436, 16843437 };
    
    public static final int ListPopupWindow_android_dropDownHorizontalOffset = 0;
    
    public static final int ListPopupWindow_android_dropDownVerticalOffset = 1;
    
    public static final int[] MenuGroup = new int[] { 16842766, 16842960, 16843156, 16843230, 16843231, 16843232 };
    
    public static final int MenuGroup_android_checkableBehavior = 5;
    
    public static final int MenuGroup_android_enabled = 0;
    
    public static final int MenuGroup_android_id = 1;
    
    public static final int MenuGroup_android_menuCategory = 3;
    
    public static final int MenuGroup_android_orderInCategory = 4;
    
    public static final int MenuGroup_android_visible = 2;
    
    public static final int[] MenuItem = new int[] { 
        16842754, 16842766, 16842960, 16843014, 16843156, 16843230, 16843231, 16843233, 16843234, 16843235, 
        16843236, 16843237, 16843375, 2130968594, 2130968614, 2130968616, 2130968669, 2130968988, 2130969329, 2130969330, 
        2130969758, 2130969897, 2130970238 };
    
    public static final int MenuItem_actionLayout = 13;
    
    public static final int MenuItem_actionProviderClass = 14;
    
    public static final int MenuItem_actionViewClass = 15;
    
    public static final int MenuItem_alphabeticModifiers = 16;
    
    public static final int MenuItem_android_alphabeticShortcut = 9;
    
    public static final int MenuItem_android_checkable = 11;
    
    public static final int MenuItem_android_checked = 3;
    
    public static final int MenuItem_android_enabled = 1;
    
    public static final int MenuItem_android_icon = 0;
    
    public static final int MenuItem_android_id = 2;
    
    public static final int MenuItem_android_menuCategory = 5;
    
    public static final int MenuItem_android_numericShortcut = 10;
    
    public static final int MenuItem_android_onClick = 12;
    
    public static final int MenuItem_android_orderInCategory = 6;
    
    public static final int MenuItem_android_title = 7;
    
    public static final int MenuItem_android_titleCondensed = 8;
    
    public static final int MenuItem_android_visible = 4;
    
    public static final int MenuItem_contentDescription = 17;
    
    public static final int MenuItem_iconTint = 18;
    
    public static final int MenuItem_iconTintMode = 19;
    
    public static final int MenuItem_numericModifiers = 20;
    
    public static final int MenuItem_showAsAction = 21;
    
    public static final int MenuItem_tooltipText = 22;
    
    public static final int[] MenuView = new int[] { 16842926, 16843052, 16843053, 16843054, 16843055, 16843056, 16843057, 2130969810, 2130970029 };
    
    public static final int MenuView_android_headerBackground = 4;
    
    public static final int MenuView_android_horizontalDivider = 2;
    
    public static final int MenuView_android_itemBackground = 5;
    
    public static final int MenuView_android_itemIconDisabledAlpha = 6;
    
    public static final int MenuView_android_itemTextAppearance = 1;
    
    public static final int MenuView_android_verticalDivider = 3;
    
    public static final int MenuView_android_windowAnimationStyle = 0;
    
    public static final int MenuView_preserveIconSpacing = 7;
    
    public static final int MenuView_subMenuArrow = 8;
    
    public static final int[] MockView = new int[] { 2130969678, 2130969679, 2130969680, 2130969681, 2130969682, 2130969683 };
    
    public static final int MockView_mock_diagonalsColor = 0;
    
    public static final int MockView_mock_label = 1;
    
    public static final int MockView_mock_labelBackgroundColor = 2;
    
    public static final int MockView_mock_labelColor = 3;
    
    public static final int MockView_mock_showDiagonals = 4;
    
    public static final int MockView_mock_showLabel = 5;
    
    public static final int[] Motion = new int[] { 2130968671, 2130968674, 2130969097, 2130969723, 2130969725, 2130969789, 2130969817, 2130969818, 2130969819, 2130970258 };
    
    public static final int[] MotionEffect = new int[] { 2130969713, 2130969714, 2130969715, 2130969716, 2130969717, 2130969718, 2130969719, 2130969720 };
    
    public static final int MotionEffect_motionEffect_alpha = 0;
    
    public static final int MotionEffect_motionEffect_end = 1;
    
    public static final int MotionEffect_motionEffect_move = 2;
    
    public static final int MotionEffect_motionEffect_start = 3;
    
    public static final int MotionEffect_motionEffect_strict = 4;
    
    public static final int MotionEffect_motionEffect_translationX = 5;
    
    public static final int MotionEffect_motionEffect_translationY = 6;
    
    public static final int MotionEffect_motionEffect_viewTransition = 7;
    
    public static final int[] MotionHelper = new int[] { 2130969761, 2130969764 };
    
    public static final int MotionHelper_onHide = 0;
    
    public static final int MotionHelper_onShow = 1;
    
    public static final int[] MotionLabel = new int[] { 
        16842901, 16842902, 16842903, 16842904, 16842927, 16843087, 16843108, 16843692, 16844085, 2130968768, 
        2130968769, 2130969864, 2130970120, 2130970121, 2130970122, 2130970123, 2130970124, 2130970139, 2130970140, 2130970141, 
        2130970142, 2130970147, 2130970148, 2130970149, 2130970150 };
    
    public static final int MotionLabel_android_autoSizeTextType = 8;
    
    public static final int MotionLabel_android_fontFamily = 7;
    
    public static final int MotionLabel_android_gravity = 4;
    
    public static final int MotionLabel_android_shadowRadius = 6;
    
    public static final int MotionLabel_android_text = 5;
    
    public static final int MotionLabel_android_textColor = 3;
    
    public static final int MotionLabel_android_textSize = 0;
    
    public static final int MotionLabel_android_textStyle = 2;
    
    public static final int MotionLabel_android_typeface = 1;
    
    public static final int MotionLabel_borderRound = 9;
    
    public static final int MotionLabel_borderRoundPercent = 10;
    
    public static final int MotionLabel_scaleFromTextSize = 11;
    
    public static final int MotionLabel_textBackground = 12;
    
    public static final int MotionLabel_textBackgroundPanX = 13;
    
    public static final int MotionLabel_textBackgroundPanY = 14;
    
    public static final int MotionLabel_textBackgroundRotate = 15;
    
    public static final int MotionLabel_textBackgroundZoom = 16;
    
    public static final int MotionLabel_textOutlineColor = 17;
    
    public static final int MotionLabel_textOutlineThickness = 18;
    
    public static final int MotionLabel_textPanX = 19;
    
    public static final int MotionLabel_textPanY = 20;
    
    public static final int MotionLabel_textureBlurFactor = 21;
    
    public static final int MotionLabel_textureEffect = 22;
    
    public static final int MotionLabel_textureHeight = 23;
    
    public static final int MotionLabel_textureWidth = 24;
    
    public static final int[] MotionLayout = new int[] { 2130968677, 2130969048, 2130969434, 2130969684, 2130969724, 2130969904 };
    
    public static final int MotionLayout_applyMotionScene = 0;
    
    public static final int MotionLayout_currentState = 1;
    
    public static final int MotionLayout_layoutDescription = 2;
    
    public static final int MotionLayout_motionDebug = 3;
    
    public static final int MotionLayout_motionProgress = 4;
    
    public static final int MotionLayout_showPaths = 5;
    
    public static final int[] MotionScene = new int[] { 2130969064, 2130969435 };
    
    public static final int MotionScene_defaultDuration = 0;
    
    public static final int MotionScene_layoutDuringTransition = 1;
    
    public static final int[] MotionTelltales = new int[] { 2130970079, 2130970080, 2130970081 };
    
    public static final int MotionTelltales_telltales_tailColor = 0;
    
    public static final int MotionTelltales_telltales_tailScale = 1;
    
    public static final int MotionTelltales_telltales_velocityMode = 2;
    
    public static final int Motion_animateCircleAngleTo = 0;
    
    public static final int Motion_animateRelativeTo = 1;
    
    public static final int Motion_drawPath = 2;
    
    public static final int Motion_motionPathRotate = 3;
    
    public static final int Motion_motionStagger = 4;
    
    public static final int Motion_pathMotionArc = 5;
    
    public static final int Motion_quantizeMotionInterpolator = 6;
    
    public static final int Motion_quantizeMotionPhase = 7;
    
    public static final int Motion_quantizeMotionSteps = 8;
    
    public static final int Motion_transitionEasing = 9;
    
    public static final int[] OnClick = new int[] { 2130968892, 2130970078 };
    
    public static final int OnClick_clickAction = 0;
    
    public static final int OnClick_targetId = 1;
    
    public static final int[] OnSwipe = new int[] { 
        2130968693, 2130969094, 2130969095, 2130969096, 2130969522, 2130969628, 2130969637, 2130969729, 2130969743, 2130969766, 
        2130969860, 2130969927, 2130969928, 2130969929, 2130969930, 2130969931, 2130970240, 2130970241, 2130970243 };
    
    public static final int OnSwipe_autoCompleteMode = 0;
    
    public static final int OnSwipe_dragDirection = 1;
    
    public static final int OnSwipe_dragScale = 2;
    
    public static final int OnSwipe_dragThreshold = 3;
    
    public static final int OnSwipe_limitBoundsTo = 4;
    
    public static final int OnSwipe_maxAcceleration = 5;
    
    public static final int OnSwipe_maxVelocity = 6;
    
    public static final int OnSwipe_moveWhenScrollAtTop = 7;
    
    public static final int OnSwipe_nestedScrollFlags = 8;
    
    public static final int OnSwipe_onTouchUp = 9;
    
    public static final int OnSwipe_rotationCenterId = 10;
    
    public static final int OnSwipe_springBoundary = 11;
    
    public static final int OnSwipe_springDamping = 12;
    
    public static final int OnSwipe_springMass = 13;
    
    public static final int OnSwipe_springStiffness = 14;
    
    public static final int OnSwipe_springStopThreshold = 15;
    
    public static final int OnSwipe_touchAnchorId = 16;
    
    public static final int OnSwipe_touchAnchorSide = 17;
    
    public static final int OnSwipe_touchRegionId = 18;
    
    public static final int[] PopupWindow = new int[] { 16843126, 16843465, 2130969767 };
    
    public static final int[] PopupWindowBackgroundState = new int[] { 2130970014 };
    
    public static final int PopupWindowBackgroundState_state_above_anchor = 0;
    
    public static final int PopupWindow_android_popupAnimationStyle = 1;
    
    public static final int PopupWindow_android_popupBackground = 0;
    
    public static final int PopupWindow_overlapAnchor = 2;
    
    public static final int[] PropertySet = new int[] { 16842972, 16843551, 2130969477, 2130969724, 2130970296 };
    
    public static final int PropertySet_android_alpha = 1;
    
    public static final int PropertySet_android_visibility = 0;
    
    public static final int PropertySet_layout_constraintTag = 2;
    
    public static final int PropertySet_motionProgress = 3;
    
    public static final int PropertySet_visibilityMode = 4;
    
    public static final int[] RecycleListView = new int[] { 2130969769, 2130969775 };
    
    public static final int RecycleListView_paddingBottomNoButtons = 0;
    
    public static final int RecycleListView_paddingTopNoTitle = 1;
    
    public static final int[] SearchView = new int[] { 
        16842804, 16842970, 16843039, 16843087, 16843088, 16843296, 16843364, 2130968672, 2130968673, 2130968695, 
        2130968897, 2130968978, 2130969066, 2130969293, 2130969302, 2130969311, 2130969331, 2130969433, 2130969820, 2130969821, 
        2130969870, 2130969871, 2130969872, 2130970034, 2130970043, 2130970284, 2130970297 };
    
    public static final int SearchView_android_focusable = 1;
    
    public static final int SearchView_android_hint = 4;
    
    public static final int SearchView_android_imeOptions = 6;
    
    public static final int SearchView_android_inputType = 5;
    
    public static final int SearchView_android_maxWidth = 2;
    
    public static final int SearchView_android_text = 3;
    
    public static final int SearchView_android_textAppearance = 0;
    
    public static final int SearchView_animateMenuItems = 7;
    
    public static final int SearchView_animateNavigationIcon = 8;
    
    public static final int SearchView_autoShowKeyboard = 9;
    
    public static final int SearchView_closeIcon = 10;
    
    public static final int SearchView_commitIcon = 11;
    
    public static final int SearchView_defaultQueryHint = 12;
    
    public static final int SearchView_goIcon = 13;
    
    public static final int SearchView_headerLayout = 14;
    
    public static final int SearchView_hideNavigationIcon = 15;
    
    public static final int SearchView_iconifiedByDefault = 16;
    
    public static final int SearchView_layout = 17;
    
    public static final int SearchView_queryBackground = 18;
    
    public static final int SearchView_queryHint = 19;
    
    public static final int SearchView_searchHintIcon = 20;
    
    public static final int SearchView_searchIcon = 21;
    
    public static final int SearchView_searchPrefixText = 22;
    
    public static final int SearchView_submitBackground = 23;
    
    public static final int SearchView_suggestionRowLayout = 24;
    
    public static final int SearchView_useDrawerArrowDrawable = 25;
    
    public static final int SearchView_voiceIcon = 26;
    
    public static final int[] Spinner = new int[] { 16842930, 16843126, 16843131, 16843362, 2130969805 };
    
    public static final int Spinner_android_dropDownWidth = 3;
    
    public static final int Spinner_android_entries = 0;
    
    public static final int Spinner_android_popupBackground = 1;
    
    public static final int Spinner_android_prompt = 2;
    
    public static final int Spinner_popupTheme = 4;
    
    public static final int[] State = new int[] { 16842960, 2130968986 };
    
    public static final int[] StateListDrawable = new int[] { 16843036, 16843156, 16843157, 16843158, 16843532, 16843533 };
    
    public static final int[] StateListDrawableItem = new int[] { 16843161 };
    
    public static final int StateListDrawableItem_android_drawable = 0;
    
    public static final int StateListDrawable_android_constantSize = 3;
    
    public static final int StateListDrawable_android_dither = 0;
    
    public static final int StateListDrawable_android_enterFadeDuration = 4;
    
    public static final int StateListDrawable_android_exitFadeDuration = 5;
    
    public static final int StateListDrawable_android_variablePadding = 2;
    
    public static final int StateListDrawable_android_visible = 1;
    
    public static final int[] StateSet = new int[] { 2130969068 };
    
    public static final int StateSet_defaultState = 0;
    
    public static final int State_android_id = 0;
    
    public static final int State_constraints = 1;
    
    public static final int[] SwitchCompat = new int[] { 
        16843044, 16843045, 16843074, 2130969905, 2130969926, 2130970045, 2130970046, 2130970048, 2130970161, 2130970162, 
        2130970163, 2130970244, 2130970254, 2130970255 };
    
    public static final int SwitchCompat_android_textOff = 1;
    
    public static final int SwitchCompat_android_textOn = 0;
    
    public static final int SwitchCompat_android_thumb = 2;
    
    public static final int SwitchCompat_showText = 3;
    
    public static final int SwitchCompat_splitTrack = 4;
    
    public static final int SwitchCompat_switchMinWidth = 5;
    
    public static final int SwitchCompat_switchPadding = 6;
    
    public static final int SwitchCompat_switchTextAppearance = 7;
    
    public static final int SwitchCompat_thumbTextPadding = 8;
    
    public static final int SwitchCompat_thumbTint = 9;
    
    public static final int SwitchCompat_thumbTintMode = 10;
    
    public static final int SwitchCompat_track = 11;
    
    public static final int SwitchCompat_trackTint = 12;
    
    public static final int SwitchCompat_trackTintMode = 13;
    
    public static final int[] TextAppearance = new int[] { 
        16842901, 16842902, 16842903, 16842904, 16842906, 16842907, 16843105, 16843106, 16843107, 16843108, 
        16843692, 16844165, 2130969274, 2130969283, 2130970082, 2130970138 };
    
    public static final int TextAppearance_android_fontFamily = 10;
    
    public static final int TextAppearance_android_shadowColor = 6;
    
    public static final int TextAppearance_android_shadowDx = 7;
    
    public static final int TextAppearance_android_shadowDy = 8;
    
    public static final int TextAppearance_android_shadowRadius = 9;
    
    public static final int TextAppearance_android_textColor = 3;
    
    public static final int TextAppearance_android_textColorHint = 4;
    
    public static final int TextAppearance_android_textColorLink = 5;
    
    public static final int TextAppearance_android_textFontWeight = 11;
    
    public static final int TextAppearance_android_textSize = 0;
    
    public static final int TextAppearance_android_textStyle = 2;
    
    public static final int TextAppearance_android_typeface = 1;
    
    public static final int TextAppearance_fontFamily = 12;
    
    public static final int TextAppearance_fontVariationSettings = 13;
    
    public static final int TextAppearance_textAllCaps = 14;
    
    public static final int TextAppearance_textLocale = 15;
    
    public static final int[] TextEffects = new int[] { 
        16842901, 16842902, 16842903, 16843087, 16843105, 16843106, 16843107, 16843108, 16843692, 2130968768, 
        2130968769, 2130970129, 2130970139, 2130970140 };
    
    public static final int TextEffects_android_fontFamily = 8;
    
    public static final int TextEffects_android_shadowColor = 4;
    
    public static final int TextEffects_android_shadowDx = 5;
    
    public static final int TextEffects_android_shadowDy = 6;
    
    public static final int TextEffects_android_shadowRadius = 7;
    
    public static final int TextEffects_android_text = 3;
    
    public static final int TextEffects_android_textSize = 0;
    
    public static final int TextEffects_android_textStyle = 2;
    
    public static final int TextEffects_android_typeface = 1;
    
    public static final int TextEffects_borderRound = 9;
    
    public static final int TextEffects_borderRoundPercent = 10;
    
    public static final int TextEffects_textFillColor = 11;
    
    public static final int TextEffects_textOutlineColor = 12;
    
    public static final int TextEffects_textOutlineThickness = 13;
    
    public static final int[] Toolbar = new int[] { 
        16842927, 16843072, 2130968798, 2130968905, 2130968906, 2130968989, 2130968990, 2130968991, 2130968992, 2130968993, 
        2130968994, 2130969542, 2130969544, 2130969630, 2130969663, 2130969737, 2130969738, 2130969805, 2130970035, 2130970037, 
        2130970038, 2130970177, 2130970181, 2130970182, 2130970183, 2130970184, 2130970185, 2130970186, 2130970188, 2130970189 };
    
    public static final int Toolbar_android_gravity = 0;
    
    public static final int Toolbar_android_minHeight = 1;
    
    public static final int Toolbar_buttonGravity = 2;
    
    public static final int Toolbar_collapseContentDescription = 3;
    
    public static final int Toolbar_collapseIcon = 4;
    
    public static final int Toolbar_contentInsetEnd = 5;
    
    public static final int Toolbar_contentInsetEndWithActions = 6;
    
    public static final int Toolbar_contentInsetLeft = 7;
    
    public static final int Toolbar_contentInsetRight = 8;
    
    public static final int Toolbar_contentInsetStart = 9;
    
    public static final int Toolbar_contentInsetStartWithNavigation = 10;
    
    public static final int Toolbar_logo = 11;
    
    public static final int Toolbar_logoDescription = 12;
    
    public static final int Toolbar_maxButtonHeight = 13;
    
    public static final int Toolbar_menu = 14;
    
    public static final int Toolbar_navigationContentDescription = 15;
    
    public static final int Toolbar_navigationIcon = 16;
    
    public static final int Toolbar_popupTheme = 17;
    
    public static final int Toolbar_subtitle = 18;
    
    public static final int Toolbar_subtitleTextAppearance = 19;
    
    public static final int Toolbar_subtitleTextColor = 20;
    
    public static final int Toolbar_title = 21;
    
    public static final int Toolbar_titleMargin = 22;
    
    public static final int Toolbar_titleMarginBottom = 23;
    
    public static final int Toolbar_titleMarginEnd = 24;
    
    public static final int Toolbar_titleMarginStart = 25;
    
    public static final int Toolbar_titleMarginTop = 26;
    
    public static final int Toolbar_titleMargins = 27;
    
    public static final int Toolbar_titleTextAppearance = 28;
    
    public static final int Toolbar_titleTextColor = 29;
    
    public static final int[] Transform = new int[] { 
        16843552, 16843553, 16843554, 16843555, 16843556, 16843557, 16843558, 16843559, 16843560, 16843770, 
        16843840, 2130970256 };
    
    public static final int Transform_android_elevation = 10;
    
    public static final int Transform_android_rotation = 6;
    
    public static final int Transform_android_rotationX = 7;
    
    public static final int Transform_android_rotationY = 8;
    
    public static final int Transform_android_scaleX = 4;
    
    public static final int Transform_android_scaleY = 5;
    
    public static final int Transform_android_transformPivotX = 0;
    
    public static final int Transform_android_transformPivotY = 1;
    
    public static final int Transform_android_translationX = 2;
    
    public static final int Transform_android_translationY = 3;
    
    public static final int Transform_android_translationZ = 9;
    
    public static final int Transform_transformPivotTarget = 11;
    
    public static final int[] Transition = new int[] { 
        16842960, 2130968701, 2130968982, 2130968983, 2130969119, 2130969435, 2130969721, 2130969789, 2130970005, 2130970257, 
        2130970259 };
    
    public static final int Transition_android_id = 0;
    
    public static final int Transition_autoTransition = 1;
    
    public static final int Transition_constraintSetEnd = 2;
    
    public static final int Transition_constraintSetStart = 3;
    
    public static final int Transition_duration = 4;
    
    public static final int Transition_layoutDuringTransition = 5;
    
    public static final int Transition_motionInterpolator = 6;
    
    public static final int Transition_pathMotionArc = 7;
    
    public static final int Transition_staggered = 8;
    
    public static final int Transition_transitionDisable = 9;
    
    public static final int Transition_transitionFlags = 10;
    
    public static final int[] Variant = new int[] { 2130968986, 2130969840, 2130969841, 2130969842, 2130969843 };
    
    public static final int Variant_constraints = 0;
    
    public static final int Variant_region_heightLessThan = 1;
    
    public static final int Variant_region_heightMoreThan = 2;
    
    public static final int Variant_region_widthLessThan = 3;
    
    public static final int Variant_region_widthMoreThan = 4;
    
    public static final int[] View = new int[] { 16842752, 16842970, 2130969771, 2130969774, 2130970151 };
    
    public static final int[] ViewBackgroundHelper = new int[] { 16842964, 2130968712, 2130968713 };
    
    public static final int ViewBackgroundHelper_android_background = 0;
    
    public static final int ViewBackgroundHelper_backgroundTint = 1;
    
    public static final int ViewBackgroundHelper_backgroundTintMode = 2;
    
    public static final int[] ViewStubCompat = new int[] { 16842960, 16842994, 16842995 };
    
    public static final int ViewStubCompat_android_id = 0;
    
    public static final int ViewStubCompat_android_inflatedId = 2;
    
    public static final int ViewStubCompat_android_layout = 1;
    
    public static final int[] ViewTransition = new int[] { 
        16842960, 2130968576, 2130968577, 2130968891, 2130969119, 2130969332, 2130969333, 2130969721, 2130969726, 2130969765, 
        2130969789, 2130969882, 2130970257, 2130970282, 2130970292 };
    
    public static final int ViewTransition_SharedValue = 1;
    
    public static final int ViewTransition_SharedValueId = 2;
    
    public static final int ViewTransition_android_id = 0;
    
    public static final int ViewTransition_clearsTag = 3;
    
    public static final int ViewTransition_duration = 4;
    
    public static final int ViewTransition_ifTagNotSet = 5;
    
    public static final int ViewTransition_ifTagSet = 6;
    
    public static final int ViewTransition_motionInterpolator = 7;
    
    public static final int ViewTransition_motionTarget = 8;
    
    public static final int ViewTransition_onStateTransition = 9;
    
    public static final int ViewTransition_pathMotionArc = 10;
    
    public static final int ViewTransition_setsTag = 11;
    
    public static final int ViewTransition_transitionDisable = 12;
    
    public static final int ViewTransition_upDuration = 13;
    
    public static final int ViewTransition_viewTransitionMode = 14;
    
    public static final int View_android_focusable = 1;
    
    public static final int View_android_theme = 0;
    
    public static final int View_paddingEnd = 2;
    
    public static final int View_paddingStart = 3;
    
    public static final int View_theme = 4;
    
    public static final int[] include = new int[] { 2130968981 };
    
    public static final int include_constraintSet = 0;
  }
}


/* Location:              C:\soft\dex2jar-2.0\MagicAI - AI Art & Anime Art-dex2jar.jar!\androidx\constraintlayout\widget\R.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */