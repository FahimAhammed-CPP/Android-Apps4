package androidx.room.util;

import android.database.Cursor;
import android.database.CursorWrapper;
import android.database.MatrixCursor;
import android.os.Build;
import android.util.Log;
import androidx.annotation.RestrictTo;
import androidx.annotation.VisibleForTesting;
import java.io.Closeable;
import kotlin.Metadata;
import kotlin.collections.ArraysKt;
import kotlin.io.CloseableKt;
import kotlin.jvm.functions.Function1;
import kotlin.jvm.internal.InlineMarker;
import kotlin.jvm.internal.Intrinsics;
import kotlin.text.StringsKt;

@Metadata(d1 = {"\0000\n\000\n\002\030\002\n\002\b\002\n\002\020\b\n\002\b\002\n\002\020\016\n\000\n\002\020\021\n\002\b\005\n\002\020\025\n\002\b\004\n\002\030\002\n\002\b\002\032\016\020\000\032\0020\0012\006\020\002\032\0020\001\032\030\020\003\032\0020\0042\006\020\005\032\0020\0012\006\020\006\032\0020\007H\002\032#\020\003\032\0020\0042\f\020\b\032\b\022\004\022\0020\0070\t2\006\020\006\032\0020\007H\007¢\006\002\020\n\032\026\020\013\032\0020\0042\006\020\002\032\0020\0012\006\020\006\032\0020\007\032\026\020\f\032\0020\0042\006\020\002\032\0020\0012\006\020\006\032\0020\007\032)\020\r\032\0020\0012\006\020\005\032\0020\0012\f\020\b\032\b\022\004\022\0020\0070\t2\006\020\016\032\0020\017¢\006\002\020\020\032/\020\021\032\002H\022\"\004\b\000\020\022*\0020\0012\022\020\023\032\016\022\004\022\0020\001\022\004\022\002H\0220\024H\bø\001\000¢\006\002\020\025\002\007\n\005\b20\001¨\006\026"}, d2 = {"copyAndClose", "Landroid/database/Cursor;", "c", "findColumnIndexBySuffix", "", "cursor", "name", "", "columnNames", "", "([Ljava/lang/String;Ljava/lang/String;)I", "getColumnIndex", "getColumnIndexOrThrow", "wrapMappedColumns", "mapping", "", "(Landroid/database/Cursor;[Ljava/lang/String;[I)Landroid/database/Cursor;", "useCursor", "R", "block", "Lkotlin/Function1;", "(Landroid/database/Cursor;Lkotlin/jvm/functions/Function1;)Ljava/lang/Object;", "room-runtime_release"}, k = 2, mv = {1, 7, 1}, xi = 48)
@RestrictTo({RestrictTo.Scope.LIBRARY_GROUP_PREFIX})
public final class CursorUtil {
  public static final Cursor copyAndClose(Cursor paramCursor) {
    Intrinsics.checkNotNullParameter(paramCursor, "c");
    Closeable closeable = (Closeable)paramCursor;
    try {
      Cursor cursor = (Cursor)closeable;
      MatrixCursor matrixCursor = new MatrixCursor(cursor.getColumnNames(), cursor.getCount());
      label34: while (true) {
        if (cursor.moveToNext()) {
          Object[] arrayOfObject = new Object[cursor.getColumnCount()];
          int j = paramCursor.getColumnCount();
          for (int i = 0;; i++) {
            if (i < j) {
              int k = cursor.getType(i);
              if (k != 0) {
                if (k != 1) {
                  if (k != 2) {
                    if (k != 3) {
                      if (k == 4) {
                        arrayOfObject[i] = cursor.getBlob(i);
                      } else {
                        throw new IllegalStateException();
                      } 
                    } else {
                      arrayOfObject[i] = cursor.getString(i);
                    } 
                  } else {
                    arrayOfObject[i] = Double.valueOf(cursor.getDouble(i));
                  } 
                } else {
                  arrayOfObject[i] = Long.valueOf(cursor.getLong(i));
                } 
              } else {
                arrayOfObject[i] = null;
              } 
            } else {
              matrixCursor.addRow(arrayOfObject);
              continue label34;
            } 
          } 
          break;
        } 
        return (Cursor)matrixCursor;
      } 
    } finally {
      paramCursor = null;
    } 
  }
  
  private static final int findColumnIndexBySuffix(Cursor paramCursor, String paramString) {
    boolean bool;
    if (Build.VERSION.SDK_INT > 25)
      return -1; 
    if (paramString.length() == 0) {
      bool = true;
    } else {
      bool = false;
    } 
    if (bool)
      return -1; 
    String[] arrayOfString = paramCursor.getColumnNames();
    Intrinsics.checkNotNullExpressionValue(arrayOfString, "columnNames");
    return findColumnIndexBySuffix(arrayOfString, paramString);
  }
  
  @VisibleForTesting(otherwise = 2)
  public static final int findColumnIndexBySuffix(String[] paramArrayOfString, String paramString) {
    Intrinsics.checkNotNullParameter(paramArrayOfString, "columnNames");
    Intrinsics.checkNotNullParameter(paramString, "name");
    StringBuilder stringBuilder1 = new StringBuilder();
    stringBuilder1.append('.');
    stringBuilder1.append(paramString);
    String str1 = stringBuilder1.toString();
    StringBuilder stringBuilder2 = new StringBuilder();
    stringBuilder2.append('.');
    stringBuilder2.append(paramString);
    stringBuilder2.append('`');
    String str2 = stringBuilder2.toString();
    int k = paramArrayOfString.length;
    int j = 0;
    for (int i = 0; j < k; i++) {
      String str = paramArrayOfString[j];
      if (str.length() >= paramString.length() + 2) {
        if (StringsKt.endsWith$default(str, str1, false, 2, null))
          return i; 
        if (str.charAt(0) == '`' && StringsKt.endsWith$default(str, str2, false, 2, null))
          return i; 
      } 
      j++;
    } 
    return -1;
  }
  
  public static final int getColumnIndex(Cursor paramCursor, String paramString) {
    Intrinsics.checkNotNullParameter(paramCursor, "c");
    Intrinsics.checkNotNullParameter(paramString, "name");
    int i = paramCursor.getColumnIndex(paramString);
    if (i >= 0)
      return i; 
    StringBuilder stringBuilder = new StringBuilder();
    stringBuilder.append('`');
    stringBuilder.append(paramString);
    stringBuilder.append('`');
    i = paramCursor.getColumnIndex(stringBuilder.toString());
    return (i >= 0) ? i : findColumnIndexBySuffix(paramCursor, paramString);
  }
  
  public static final int getColumnIndexOrThrow(Cursor paramCursor, String paramString) {
    String str;
    Intrinsics.checkNotNullParameter(paramCursor, "c");
    Intrinsics.checkNotNullParameter(paramString, "name");
    int i = getColumnIndex(paramCursor, paramString);
    if (i >= 0)
      return i; 
    try {
      String[] arrayOfString = paramCursor.getColumnNames();
      Intrinsics.checkNotNullExpressionValue(arrayOfString, "c.columnNames");
      str = ArraysKt.joinToString$default((Object[])arrayOfString, null, null, null, 0, null, null, 63, null);
    } catch (Exception exception) {
      Log.d("RoomCursorUtil", "Cannot collect column names for debug purposes", exception);
      str = "unknown";
    } 
    StringBuilder stringBuilder = new StringBuilder();
    stringBuilder.append("column '");
    stringBuilder.append(paramString);
    stringBuilder.append("' does not exist. Available columns: ");
    stringBuilder.append(str);
    throw new IllegalArgumentException(stringBuilder.toString());
  }
  
  public static final <R> R useCursor(Cursor paramCursor, Function1<? super Cursor, ? extends R> paramFunction1) {
    Intrinsics.checkNotNullParameter(paramCursor, "<this>");
    Intrinsics.checkNotNullParameter(paramFunction1, "block");
    Closeable closeable = (Closeable)paramCursor;
    try {
      Object object = paramFunction1.invoke(closeable);
      InlineMarker.finallyStart(1);
      CloseableKt.closeFinally(closeable, null);
      return (R)object;
    } finally {
      paramFunction1 = null;
    } 
  }
  
  public static final Cursor wrapMappedColumns(Cursor paramCursor, String[] paramArrayOfString, int[] paramArrayOfint) {
    boolean bool;
    Intrinsics.checkNotNullParameter(paramCursor, "cursor");
    Intrinsics.checkNotNullParameter(paramArrayOfString, "columnNames");
    Intrinsics.checkNotNullParameter(paramArrayOfint, "mapping");
    if (paramArrayOfString.length == paramArrayOfint.length) {
      bool = true;
    } else {
      bool = false;
    } 
    if (bool)
      return (Cursor)new CursorUtil$wrapMappedColumns$2(paramCursor, paramArrayOfString, paramArrayOfint); 
    throw new IllegalStateException("Expected columnNames.length == mapping.length".toString());
  }
  
  @Metadata(d1 = {"\000\027\n\000\n\002\030\002\n\000\n\002\020\b\n\000\n\002\020\016\n\000*\001\000\b\n\030\0002\0020\001J\020\020\002\032\0020\0032\006\020\004\032\0020\005H\026¨\006\006"}, d2 = {"androidx/room/util/CursorUtil$wrapMappedColumns$2", "Landroid/database/CursorWrapper;", "getColumnIndex", "", "columnName", "", "room-runtime_release"}, k = 1, mv = {1, 7, 1}, xi = 48)
  public static final class CursorUtil$wrapMappedColumns$2 extends CursorWrapper {
    CursorUtil$wrapMappedColumns$2(Cursor param1Cursor, String[] param1ArrayOfString, int[] param1ArrayOfint) {
      super(param1Cursor);
    }
    
    public int getColumnIndex(String param1String) {
      Intrinsics.checkNotNullParameter(param1String, "columnName");
      String[] arrayOfString = this.$columnNames;
      int[] arrayOfInt = this.$mapping;
      int k = arrayOfString.length;
      int j = 0;
      for (int i = 0; j < k; i++) {
        if (StringsKt.equals(arrayOfString[j], param1String, true))
          return arrayOfInt[i]; 
        j++;
      } 
      return super.getColumnIndex(param1String);
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\MagicAI - AI Art & Anime Art-dex2jar.jar!\androidx\roo\\util\CursorUtil.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */