package androidx.room;

import android.content.ContentResolver;
import android.content.ContentValues;
import android.database.CharArrayBuffer;
import android.database.ContentObserver;
import android.database.Cursor;
import android.database.DataSetObserver;
import android.database.SQLException;
import android.database.sqlite.SQLiteTransactionListener;
import android.net.Uri;
import android.os.Bundle;
import android.os.CancellationSignal;
import android.util.Pair;
import androidx.annotation.RequiresApi;
import androidx.sqlite.db.SupportSQLiteCompat;
import androidx.sqlite.db.SupportSQLiteDatabase;
import androidx.sqlite.db.SupportSQLiteOpenHelper;
import androidx.sqlite.db.SupportSQLiteQuery;
import androidx.sqlite.db.SupportSQLiteStatement;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Locale;
import kotlin.Metadata;
import kotlin.Unit;
import kotlin.collections.CollectionsKt;
import kotlin.jvm.functions.Function1;
import kotlin.jvm.internal.FunctionReferenceImpl;
import kotlin.jvm.internal.Intrinsics;
import kotlin.jvm.internal.Lambda;
import kotlin.jvm.internal.MutablePropertyReference1Impl;
import kotlin.jvm.internal.PropertyReference1Impl;

@Metadata(d1 = {"\000>\n\002\030\002\n\002\030\002\n\002\030\002\n\002\b\002\n\002\030\002\n\002\b\002\n\002\030\002\n\000\n\002\020\016\n\002\b\005\n\002\030\002\n\002\b\005\n\002\020\002\n\002\b\002\n\002\020\013\n\002\b\004\b\000\030\0002\0020\0012\0020\002:\003\032\033\034B\025\022\006\020\003\032\0020\001\022\006\020\004\032\0020\005¢\006\002\020\006J\b\020\025\032\0020\026H\026J\021\020\027\032\0020\0262\006\020\030\032\0020\031H\001R\020\020\004\032\0020\0058\000X\004¢\006\002\n\000R\016\020\007\032\0020\bX\004¢\006\002\n\000R\024\020\t\032\004\030\0010\nX\005¢\006\006\032\004\b\013\020\fR\024\020\003\032\0020\001X\004¢\006\b\n\000\032\004\b\r\020\016R\024\020\017\032\0020\0208WX\004¢\006\006\032\004\b\021\020\022R\024\020\023\032\0020\0208WX\004¢\006\006\032\004\b\024\020\022¨\006\035"}, d2 = {"Landroidx/room/AutoClosingRoomOpenHelper;", "Landroidx/sqlite/db/SupportSQLiteOpenHelper;", "Landroidx/room/DelegatingOpenHelper;", "delegate", "autoCloser", "Landroidx/room/AutoCloser;", "(Landroidx/sqlite/db/SupportSQLiteOpenHelper;Landroidx/room/AutoCloser;)V", "autoClosingDb", "Landroidx/room/AutoClosingRoomOpenHelper$AutoClosingSupportSQLiteDatabase;", "databaseName", "", "getDatabaseName", "()Ljava/lang/String;", "getDelegate", "()Landroidx/sqlite/db/SupportSQLiteOpenHelper;", "readableDatabase", "Landroidx/sqlite/db/SupportSQLiteDatabase;", "getReadableDatabase", "()Landroidx/sqlite/db/SupportSQLiteDatabase;", "writableDatabase", "getWritableDatabase", "close", "", "setWriteAheadLoggingEnabled", "enabled", "", "AutoClosingSupportSQLiteDatabase", "AutoClosingSupportSqliteStatement", "KeepAliveCursor", "room-runtime_release"}, k = 1, mv = {1, 7, 1}, xi = 48)
public final class AutoClosingRoomOpenHelper implements SupportSQLiteOpenHelper, DelegatingOpenHelper {
  public final AutoCloser autoCloser;
  
  private final AutoClosingSupportSQLiteDatabase autoClosingDb;
  
  private final SupportSQLiteOpenHelper delegate;
  
  public AutoClosingRoomOpenHelper(SupportSQLiteOpenHelper paramSupportSQLiteOpenHelper, AutoCloser paramAutoCloser) {
    this.delegate = paramSupportSQLiteOpenHelper;
    this.autoCloser = paramAutoCloser;
    paramAutoCloser.init(getDelegate());
    this.autoClosingDb = new AutoClosingSupportSQLiteDatabase(paramAutoCloser);
  }
  
  public void close() {
    this.autoClosingDb.close();
  }
  
  public String getDatabaseName() {
    return this.delegate.getDatabaseName();
  }
  
  public SupportSQLiteOpenHelper getDelegate() {
    return this.delegate;
  }
  
  @RequiresApi(api = 24)
  public SupportSQLiteDatabase getReadableDatabase() {
    this.autoClosingDb.pokeOpen();
    return this.autoClosingDb;
  }
  
  @RequiresApi(api = 24)
  public SupportSQLiteDatabase getWritableDatabase() {
    this.autoClosingDb.pokeOpen();
    return this.autoClosingDb;
  }
  
  @RequiresApi(api = 16)
  public void setWriteAheadLoggingEnabled(boolean paramBoolean) {
    this.delegate.setWriteAheadLoggingEnabled(paramBoolean);
  }
  
  @Metadata(d1 = {"\000\001\n\002\030\002\n\002\030\002\n\000\n\002\030\002\n\002\b\002\n\002\020 \n\002\030\002\n\002\020\016\n\002\b\003\n\002\020\013\n\002\b\006\n\002\020\t\n\002\b\013\n\002\020\b\n\002\b\005\n\002\020\002\n\002\b\003\n\002\030\002\n\002\b\003\n\002\030\002\n\002\b\005\n\002\020\021\n\002\020\000\n\002\b\013\n\002\030\002\n\002\b\004\n\002\030\002\n\002\030\002\n\000\n\002\030\002\n\002\b\005\n\002\030\002\n\002\b\t\b\000\030\0002\0020\001B\r\022\006\020\002\032\0020\003¢\006\002\020\004J\b\020$\032\0020%H\026J\b\020&\032\0020%H\026J\020\020'\032\0020%2\006\020(\032\0020)H\026J\020\020*\032\0020%2\006\020(\032\0020)H\026J\b\020+\032\0020%H\026J\020\020,\032\0020-2\006\020.\032\0020\bH\026J3\020/\032\0020\0372\006\0200\032\0020\b2\b\0201\032\004\030\0010\b2\022\0202\032\016\022\b\b\001\022\004\030\00104\030\00103H\026¢\006\002\0205J\b\0206\032\0020%H\026J\b\0207\032\0020\fH\026J\b\0208\032\0020%H\026J\020\0209\032\0020%2\006\020.\032\0020\bH\026J'\0209\032\0020%2\006\020.\032\0020\b2\020\020:\032\f\022\b\b\001\022\004\030\0010403H\026¢\006\002\020;J\b\020<\032\0020\fH\026J \020=\032\0020\0232\006\0200\032\0020\b2\006\020>\032\0020\0372\006\020?\032\0020@H\026J\020\020A\032\0020\f2\006\020B\032\0020\037H\026J\006\020C\032\0020%J\020\020D\032\0020E2\006\020D\032\0020FH\026J\032\020D\032\0020E2\006\020D\032\0020F2\b\020G\032\004\030\0010HH\027J\020\020D\032\0020E2\006\020D\032\0020\bH\026J'\020D\032\0020E2\006\020D\032\0020\b2\020\020:\032\f\022\b\b\001\022\004\030\0010403H\026¢\006\002\020IJ\020\020J\032\0020%2\006\020K\032\0020\fH\027J\020\020L\032\0020%2\006\020M\032\0020NH\026J\020\020O\032\0020%2\006\020P\032\0020\037H\026J\020\020Q\032\0020\0232\006\020\026\032\0020\023H\026J\b\020R\032\0020%H\026JC\020S\032\0020\0372\006\0200\032\0020\b2\006\020>\032\0020\0372\006\020?\032\0020@2\b\0201\032\004\030\0010\b2\022\0202\032\016\022\b\b\001\022\004\030\00104\030\00103H\026¢\006\002\020TJ\b\020U\032\0020\fH\026J\020\020U\032\0020\f2\006\020V\032\0020\023H\026R(\020\005\032\026\022\020\022\016\022\004\022\0020\b\022\004\022\0020\b0\007\030\0010\0068VX\004¢\006\006\032\004\b\t\020\nR\016\020\002\032\0020\003X\004¢\006\002\n\000R\024\020\013\032\0020\f8VX\004¢\006\006\032\004\b\013\020\rR\024\020\016\032\0020\f8VX\004¢\006\006\032\004\b\016\020\rR\024\020\017\032\0020\f8VX\004¢\006\006\032\004\b\017\020\rR\024\020\020\032\0020\f8VX\004¢\006\006\032\004\b\020\020\rR\024\020\021\032\0020\f8WX\004¢\006\006\032\004\b\021\020\rR\024\020\022\032\0020\0238VX\004¢\006\006\032\004\b\024\020\025R$\020\027\032\0020\0232\006\020\026\032\0020\0238V@VX\016¢\006\f\032\004\b\030\020\025\"\004\b\031\020\032R\026\020\033\032\004\030\0010\b8VX\004¢\006\006\032\004\b\034\020\035R$\020\036\032\0020\0372\006\020\036\032\0020\0378V@VX\016¢\006\f\032\004\b \020!\"\004\b\"\020#¨\006W"}, d2 = {"Landroidx/room/AutoClosingRoomOpenHelper$AutoClosingSupportSQLiteDatabase;", "Landroidx/sqlite/db/SupportSQLiteDatabase;", "autoCloser", "Landroidx/room/AutoCloser;", "(Landroidx/room/AutoCloser;)V", "attachedDbs", "", "Landroid/util/Pair;", "", "getAttachedDbs", "()Ljava/util/List;", "isDatabaseIntegrityOk", "", "()Z", "isDbLockedByCurrentThread", "isOpen", "isReadOnly", "isWriteAheadLoggingEnabled", "maximumSize", "", "getMaximumSize", "()J", "numBytes", "pageSize", "getPageSize", "setPageSize", "(J)V", "path", "getPath", "()Ljava/lang/String;", "version", "", "getVersion", "()I", "setVersion", "(I)V", "beginTransaction", "", "beginTransactionNonExclusive", "beginTransactionWithListener", "transactionListener", "Landroid/database/sqlite/SQLiteTransactionListener;", "beginTransactionWithListenerNonExclusive", "close", "compileStatement", "Landroidx/sqlite/db/SupportSQLiteStatement;", "sql", "delete", "table", "whereClause", "whereArgs", "", "", "(Ljava/lang/String;Ljava/lang/String;[Ljava/lang/Object;)I", "disableWriteAheadLogging", "enableWriteAheadLogging", "endTransaction", "execSQL", "bindArgs", "(Ljava/lang/String;[Ljava/lang/Object;)V", "inTransaction", "insert", "conflictAlgorithm", "values", "Landroid/content/ContentValues;", "needUpgrade", "newVersion", "pokeOpen", "query", "Landroid/database/Cursor;", "Landroidx/sqlite/db/SupportSQLiteQuery;", "cancellationSignal", "Landroid/os/CancellationSignal;", "(Ljava/lang/String;[Ljava/lang/Object;)Landroid/database/Cursor;", "setForeignKeyConstraintsEnabled", "enabled", "setLocale", "locale", "Ljava/util/Locale;", "setMaxSqlCacheSize", "cacheSize", "setMaximumSize", "setTransactionSuccessful", "update", "(Ljava/lang/String;ILandroid/content/ContentValues;Ljava/lang/String;[Ljava/lang/Object;)I", "yieldIfContendedSafely", "sleepAfterYieldDelayMillis", "room-runtime_release"}, k = 1, mv = {1, 7, 1}, xi = 48)
  public static final class AutoClosingSupportSQLiteDatabase implements SupportSQLiteDatabase {
    private final AutoCloser autoCloser;
    
    public AutoClosingSupportSQLiteDatabase(AutoCloser param1AutoCloser) {
      this.autoCloser = param1AutoCloser;
    }
    
    public void beginTransaction() {
      null = this.autoCloser.incrementCountAndEnsureDbIsOpen();
      try {
        return;
      } finally {
        this.autoCloser.decrementCountAndScheduleClose();
      } 
    }
    
    public void beginTransactionNonExclusive() {
      null = this.autoCloser.incrementCountAndEnsureDbIsOpen();
      try {
        return;
      } finally {
        this.autoCloser.decrementCountAndScheduleClose();
      } 
    }
    
    public void beginTransactionWithListener(SQLiteTransactionListener param1SQLiteTransactionListener) {
      Intrinsics.checkNotNullParameter(param1SQLiteTransactionListener, "transactionListener");
      SupportSQLiteDatabase supportSQLiteDatabase = this.autoCloser.incrementCountAndEnsureDbIsOpen();
      try {
        return;
      } finally {
        this.autoCloser.decrementCountAndScheduleClose();
      } 
    }
    
    public void beginTransactionWithListenerNonExclusive(SQLiteTransactionListener param1SQLiteTransactionListener) {
      Intrinsics.checkNotNullParameter(param1SQLiteTransactionListener, "transactionListener");
      SupportSQLiteDatabase supportSQLiteDatabase = this.autoCloser.incrementCountAndEnsureDbIsOpen();
      try {
        return;
      } finally {
        this.autoCloser.decrementCountAndScheduleClose();
      } 
    }
    
    public void close() throws IOException {
      this.autoCloser.closeDatabaseIfOpen();
    }
    
    public SupportSQLiteStatement compileStatement(String param1String) {
      Intrinsics.checkNotNullParameter(param1String, "sql");
      return new AutoClosingRoomOpenHelper.AutoClosingSupportSqliteStatement(param1String, this.autoCloser);
    }
    
    public int delete(String param1String1, String param1String2, Object[] param1ArrayOfObject) {
      Intrinsics.checkNotNullParameter(param1String1, "table");
      return ((Number)this.autoCloser.executeRefCountingFunction(new AutoClosingRoomOpenHelper$AutoClosingSupportSQLiteDatabase$delete$1(param1String1, param1String2, param1ArrayOfObject))).intValue();
    }
    
    public void disableWriteAheadLogging() {
      throw new UnsupportedOperationException("Enable/disable write ahead logging on the OpenHelper instead of on the database directly.");
    }
    
    public boolean enableWriteAheadLogging() {
      throw new UnsupportedOperationException("Enable/disable write ahead logging on the OpenHelper instead of on the database directly.");
    }
    
    public void endTransaction() {
      if (this.autoCloser.getDelegateDatabase$room_runtime_release() != null)
        try {
          SupportSQLiteDatabase supportSQLiteDatabase = this.autoCloser.getDelegateDatabase$room_runtime_release();
          Intrinsics.checkNotNull(supportSQLiteDatabase);
          supportSQLiteDatabase.endTransaction();
          return;
        } finally {
          this.autoCloser.decrementCountAndScheduleClose();
        }  
      throw new IllegalStateException("End transaction called but delegateDb is null".toString());
    }
    
    public void execSQL(String param1String) throws SQLException {
      Intrinsics.checkNotNullParameter(param1String, "sql");
      this.autoCloser.executeRefCountingFunction(new AutoClosingRoomOpenHelper$AutoClosingSupportSQLiteDatabase$execSQL$1(param1String));
    }
    
    public void execSQL(String param1String, Object[] param1ArrayOfObject) throws SQLException {
      Intrinsics.checkNotNullParameter(param1String, "sql");
      Intrinsics.checkNotNullParameter(param1ArrayOfObject, "bindArgs");
      this.autoCloser.executeRefCountingFunction(new AutoClosingRoomOpenHelper$AutoClosingSupportSQLiteDatabase$execSQL$2(param1String, param1ArrayOfObject));
    }
    
    public List<Pair<String, String>> getAttachedDbs() {
      return (List<Pair<String, String>>)this.autoCloser.executeRefCountingFunction(AutoClosingRoomOpenHelper$AutoClosingSupportSQLiteDatabase$attachedDbs$1.INSTANCE);
    }
    
    public long getMaximumSize() {
      return ((Number)this.autoCloser.executeRefCountingFunction((Function1)AutoClosingRoomOpenHelper$AutoClosingSupportSQLiteDatabase$maximumSize$1.INSTANCE)).longValue();
    }
    
    public long getPageSize() {
      return ((Number)this.autoCloser.executeRefCountingFunction((Function1)AutoClosingRoomOpenHelper$AutoClosingSupportSQLiteDatabase$pageSize$1.INSTANCE)).longValue();
    }
    
    public String getPath() {
      return (String)this.autoCloser.executeRefCountingFunction(AutoClosingRoomOpenHelper$AutoClosingSupportSQLiteDatabase$path$1.INSTANCE);
    }
    
    public int getVersion() {
      return ((Number)this.autoCloser.executeRefCountingFunction((Function1)AutoClosingRoomOpenHelper$AutoClosingSupportSQLiteDatabase$version$1.INSTANCE)).intValue();
    }
    
    public boolean inTransaction() {
      return (this.autoCloser.getDelegateDatabase$room_runtime_release() == null) ? false : ((Boolean)this.autoCloser.executeRefCountingFunction(AutoClosingRoomOpenHelper$AutoClosingSupportSQLiteDatabase$inTransaction$1.INSTANCE)).booleanValue();
    }
    
    public long insert(String param1String, int param1Int, ContentValues param1ContentValues) throws SQLException {
      Intrinsics.checkNotNullParameter(param1String, "table");
      Intrinsics.checkNotNullParameter(param1ContentValues, "values");
      return ((Number)this.autoCloser.executeRefCountingFunction(new AutoClosingRoomOpenHelper$AutoClosingSupportSQLiteDatabase$insert$1(param1String, param1Int, param1ContentValues))).longValue();
    }
    
    public boolean isDatabaseIntegrityOk() {
      return ((Boolean)this.autoCloser.executeRefCountingFunction(AutoClosingRoomOpenHelper$AutoClosingSupportSQLiteDatabase$isDatabaseIntegrityOk$1.INSTANCE)).booleanValue();
    }
    
    public boolean isDbLockedByCurrentThread() {
      return (this.autoCloser.getDelegateDatabase$room_runtime_release() == null) ? false : ((Boolean)this.autoCloser.executeRefCountingFunction((Function1)AutoClosingRoomOpenHelper$AutoClosingSupportSQLiteDatabase$isDbLockedByCurrentThread$1.INSTANCE)).booleanValue();
    }
    
    public boolean isOpen() {
      SupportSQLiteDatabase supportSQLiteDatabase = this.autoCloser.getDelegateDatabase$room_runtime_release();
      return (supportSQLiteDatabase == null) ? false : supportSQLiteDatabase.isOpen();
    }
    
    public boolean isReadOnly() {
      return ((Boolean)this.autoCloser.executeRefCountingFunction(AutoClosingRoomOpenHelper$AutoClosingSupportSQLiteDatabase$isReadOnly$1.INSTANCE)).booleanValue();
    }
    
    @RequiresApi(api = 16)
    public boolean isWriteAheadLoggingEnabled() {
      return ((Boolean)this.autoCloser.executeRefCountingFunction(AutoClosingRoomOpenHelper$AutoClosingSupportSQLiteDatabase$isWriteAheadLoggingEnabled$1.INSTANCE)).booleanValue();
    }
    
    public boolean needUpgrade(int param1Int) {
      return ((Boolean)this.autoCloser.executeRefCountingFunction(new AutoClosingRoomOpenHelper$AutoClosingSupportSQLiteDatabase$needUpgrade$1(param1Int))).booleanValue();
    }
    
    public final void pokeOpen() {
      this.autoCloser.executeRefCountingFunction(AutoClosingRoomOpenHelper$AutoClosingSupportSQLiteDatabase$pokeOpen$1.INSTANCE);
    }
    
    public Cursor query(SupportSQLiteQuery param1SupportSQLiteQuery) {
      Intrinsics.checkNotNullParameter(param1SupportSQLiteQuery, "query");
      try {
        return new AutoClosingRoomOpenHelper.KeepAliveCursor(cursor, this.autoCloser);
      } finally {
        this.autoCloser.decrementCountAndScheduleClose();
      } 
    }
    
    @RequiresApi(api = 24)
    public Cursor query(SupportSQLiteQuery param1SupportSQLiteQuery, CancellationSignal param1CancellationSignal) {
      Intrinsics.checkNotNullParameter(param1SupportSQLiteQuery, "query");
      try {
        return new AutoClosingRoomOpenHelper.KeepAliveCursor(cursor, this.autoCloser);
      } finally {
        this.autoCloser.decrementCountAndScheduleClose();
      } 
    }
    
    public Cursor query(String param1String) {
      Intrinsics.checkNotNullParameter(param1String, "query");
      try {
        return new AutoClosingRoomOpenHelper.KeepAliveCursor(cursor, this.autoCloser);
      } finally {
        this.autoCloser.decrementCountAndScheduleClose();
      } 
    }
    
    public Cursor query(String param1String, Object[] param1ArrayOfObject) {
      Intrinsics.checkNotNullParameter(param1String, "query");
      Intrinsics.checkNotNullParameter(param1ArrayOfObject, "bindArgs");
      try {
        return new AutoClosingRoomOpenHelper.KeepAliveCursor(cursor, this.autoCloser);
      } finally {
        this.autoCloser.decrementCountAndScheduleClose();
      } 
    }
    
    @RequiresApi(api = 16)
    public void setForeignKeyConstraintsEnabled(boolean param1Boolean) {
      this.autoCloser.executeRefCountingFunction(new AutoClosingRoomOpenHelper$AutoClosingSupportSQLiteDatabase$setForeignKeyConstraintsEnabled$1(param1Boolean));
    }
    
    public void setLocale(Locale param1Locale) {
      Intrinsics.checkNotNullParameter(param1Locale, "locale");
      this.autoCloser.executeRefCountingFunction(new AutoClosingRoomOpenHelper$AutoClosingSupportSQLiteDatabase$setLocale$1(param1Locale));
    }
    
    public void setMaxSqlCacheSize(int param1Int) {
      this.autoCloser.executeRefCountingFunction(new AutoClosingRoomOpenHelper$AutoClosingSupportSQLiteDatabase$setMaxSqlCacheSize$1(param1Int));
    }
    
    public long setMaximumSize(long param1Long) {
      return ((Number)this.autoCloser.executeRefCountingFunction(new AutoClosingRoomOpenHelper$AutoClosingSupportSQLiteDatabase$setMaximumSize$1(param1Long))).longValue();
    }
    
    public void setPageSize(long param1Long) {
      this.autoCloser.executeRefCountingFunction(new AutoClosingRoomOpenHelper$AutoClosingSupportSQLiteDatabase$pageSize$2(param1Long));
    }
    
    public void setTransactionSuccessful() {
      SupportSQLiteDatabase supportSQLiteDatabase = this.autoCloser.getDelegateDatabase$room_runtime_release();
      if (supportSQLiteDatabase != null) {
        supportSQLiteDatabase.setTransactionSuccessful();
        Unit unit = Unit.INSTANCE;
      } else {
        supportSQLiteDatabase = null;
      } 
      if (supportSQLiteDatabase != null)
        return; 
      throw new IllegalStateException("setTransactionSuccessful called but delegateDb is null".toString());
    }
    
    public void setVersion(int param1Int) {
      this.autoCloser.executeRefCountingFunction(new AutoClosingRoomOpenHelper$AutoClosingSupportSQLiteDatabase$version$2(param1Int));
    }
    
    public int update(String param1String1, int param1Int, ContentValues param1ContentValues, String param1String2, Object[] param1ArrayOfObject) {
      Intrinsics.checkNotNullParameter(param1String1, "table");
      Intrinsics.checkNotNullParameter(param1ContentValues, "values");
      return ((Number)this.autoCloser.executeRefCountingFunction(new AutoClosingRoomOpenHelper$AutoClosingSupportSQLiteDatabase$update$1(param1String1, param1Int, param1ContentValues, param1String2, param1ArrayOfObject))).intValue();
    }
    
    public boolean yieldIfContendedSafely() {
      return ((Boolean)this.autoCloser.executeRefCountingFunction(AutoClosingRoomOpenHelper$AutoClosingSupportSQLiteDatabase$yieldIfContendedSafely$1.INSTANCE)).booleanValue();
    }
    
    public boolean yieldIfContendedSafely(long param1Long) {
      return ((Boolean)this.autoCloser.executeRefCountingFunction(AutoClosingRoomOpenHelper$AutoClosingSupportSQLiteDatabase$yieldIfContendedSafely$2.INSTANCE)).booleanValue();
    }
    
    @Metadata(d1 = {"\000\026\n\000\n\002\020 \n\002\030\002\n\002\020\016\n\000\n\002\030\002\n\000\020\000\032\026\022\020\022\016\022\004\022\0020\003\022\004\022\0020\0030\002\030\0010\0012\006\020\004\032\0020\005H\n¢\006\002\b\006"}, d2 = {"<anonymous>", "", "Landroid/util/Pair;", "", "obj", "Landroidx/sqlite/db/SupportSQLiteDatabase;", "invoke"}, k = 3, mv = {1, 7, 1}, xi = 48)
    static final class AutoClosingRoomOpenHelper$AutoClosingSupportSQLiteDatabase$attachedDbs$1 extends Lambda implements Function1<SupportSQLiteDatabase, List<? extends Pair<String, String>>> {
      public static final AutoClosingRoomOpenHelper$AutoClosingSupportSQLiteDatabase$attachedDbs$1 INSTANCE = new AutoClosingRoomOpenHelper$AutoClosingSupportSQLiteDatabase$attachedDbs$1();
      
      AutoClosingRoomOpenHelper$AutoClosingSupportSQLiteDatabase$attachedDbs$1() {
        super(1);
      }
      
      public final List<Pair<String, String>> invoke(SupportSQLiteDatabase param2SupportSQLiteDatabase) {
        Intrinsics.checkNotNullParameter(param2SupportSQLiteDatabase, "obj");
        return param2SupportSQLiteDatabase.getAttachedDbs();
      }
    }
    
    @Metadata(d1 = {"\000\020\n\000\n\002\020\b\n\000\n\002\030\002\n\002\b\002\020\000\032\0020\0012\006\020\002\032\0020\003H\n¢\006\004\b\004\020\005"}, d2 = {"<anonymous>", "", "db", "Landroidx/sqlite/db/SupportSQLiteDatabase;", "invoke", "(Landroidx/sqlite/db/SupportSQLiteDatabase;)Ljava/lang/Integer;"}, k = 3, mv = {1, 7, 1}, xi = 48)
    static final class AutoClosingRoomOpenHelper$AutoClosingSupportSQLiteDatabase$delete$1 extends Lambda implements Function1<SupportSQLiteDatabase, Integer> {
      AutoClosingRoomOpenHelper$AutoClosingSupportSQLiteDatabase$delete$1(String param2String1, String param2String2, Object[] param2ArrayOfObject) {
        super(1);
      }
      
      public final Integer invoke(SupportSQLiteDatabase param2SupportSQLiteDatabase) {
        Intrinsics.checkNotNullParameter(param2SupportSQLiteDatabase, "db");
        return Integer.valueOf(param2SupportSQLiteDatabase.delete(this.$table, this.$whereClause, this.$whereArgs));
      }
    }
    
    @Metadata(d1 = {"\000\016\n\000\n\002\020\000\n\000\n\002\030\002\n\000\020\000\032\004\030\0010\0012\006\020\002\032\0020\003H\n¢\006\002\b\004"}, d2 = {"<anonymous>", "", "db", "Landroidx/sqlite/db/SupportSQLiteDatabase;", "invoke"}, k = 3, mv = {1, 7, 1}, xi = 48)
    static final class AutoClosingRoomOpenHelper$AutoClosingSupportSQLiteDatabase$execSQL$1 extends Lambda implements Function1<SupportSQLiteDatabase, Object> {
      AutoClosingRoomOpenHelper$AutoClosingSupportSQLiteDatabase$execSQL$1(String param2String) {
        super(1);
      }
      
      public final Object invoke(SupportSQLiteDatabase param2SupportSQLiteDatabase) {
        Intrinsics.checkNotNullParameter(param2SupportSQLiteDatabase, "db");
        param2SupportSQLiteDatabase.execSQL(this.$sql);
        return null;
      }
    }
    
    @Metadata(d1 = {"\000\016\n\000\n\002\020\000\n\000\n\002\030\002\n\000\020\000\032\004\030\0010\0012\006\020\002\032\0020\003H\n¢\006\002\b\004"}, d2 = {"<anonymous>", "", "db", "Landroidx/sqlite/db/SupportSQLiteDatabase;", "invoke"}, k = 3, mv = {1, 7, 1}, xi = 48)
    static final class AutoClosingRoomOpenHelper$AutoClosingSupportSQLiteDatabase$execSQL$2 extends Lambda implements Function1<SupportSQLiteDatabase, Object> {
      AutoClosingRoomOpenHelper$AutoClosingSupportSQLiteDatabase$execSQL$2(String param2String, Object[] param2ArrayOfObject) {
        super(1);
      }
      
      public final Object invoke(SupportSQLiteDatabase param2SupportSQLiteDatabase) {
        Intrinsics.checkNotNullParameter(param2SupportSQLiteDatabase, "db");
        param2SupportSQLiteDatabase.execSQL(this.$sql, this.$bindArgs);
        return null;
      }
    }
    
    @Metadata(d1 = {"\000\020\n\000\n\002\020\t\n\000\n\002\030\002\n\002\b\002\020\000\032\0020\0012\006\020\002\032\0020\003H\n¢\006\004\b\004\020\005"}, d2 = {"<anonymous>", "", "db", "Landroidx/sqlite/db/SupportSQLiteDatabase;", "invoke", "(Landroidx/sqlite/db/SupportSQLiteDatabase;)Ljava/lang/Long;"}, k = 3, mv = {1, 7, 1}, xi = 48)
    static final class AutoClosingRoomOpenHelper$AutoClosingSupportSQLiteDatabase$insert$1 extends Lambda implements Function1<SupportSQLiteDatabase, Long> {
      AutoClosingRoomOpenHelper$AutoClosingSupportSQLiteDatabase$insert$1(String param2String, int param2Int, ContentValues param2ContentValues) {
        super(1);
      }
      
      public final Long invoke(SupportSQLiteDatabase param2SupportSQLiteDatabase) {
        Intrinsics.checkNotNullParameter(param2SupportSQLiteDatabase, "db");
        return Long.valueOf(param2SupportSQLiteDatabase.insert(this.$table, this.$conflictAlgorithm, this.$values));
      }
    }
    
    @Metadata(d1 = {"\000\020\n\000\n\002\020\013\n\000\n\002\030\002\n\002\b\002\020\000\032\0020\0012\006\020\002\032\0020\003H\n¢\006\004\b\004\020\005"}, d2 = {"<anonymous>", "", "obj", "Landroidx/sqlite/db/SupportSQLiteDatabase;", "invoke", "(Landroidx/sqlite/db/SupportSQLiteDatabase;)Ljava/lang/Boolean;"}, k = 3, mv = {1, 7, 1}, xi = 48)
    static final class AutoClosingRoomOpenHelper$AutoClosingSupportSQLiteDatabase$isDatabaseIntegrityOk$1 extends Lambda implements Function1<SupportSQLiteDatabase, Boolean> {
      public static final AutoClosingRoomOpenHelper$AutoClosingSupportSQLiteDatabase$isDatabaseIntegrityOk$1 INSTANCE = new AutoClosingRoomOpenHelper$AutoClosingSupportSQLiteDatabase$isDatabaseIntegrityOk$1();
      
      AutoClosingRoomOpenHelper$AutoClosingSupportSQLiteDatabase$isDatabaseIntegrityOk$1() {
        super(1);
      }
      
      public final Boolean invoke(SupportSQLiteDatabase param2SupportSQLiteDatabase) {
        Intrinsics.checkNotNullParameter(param2SupportSQLiteDatabase, "obj");
        return Boolean.valueOf(param2SupportSQLiteDatabase.isDatabaseIntegrityOk());
      }
    }
    
    @Metadata(d1 = {"\000\020\n\000\n\002\020\013\n\000\n\002\030\002\n\002\b\002\020\000\032\0020\0012\006\020\002\032\0020\003H\n¢\006\004\b\004\020\005"}, d2 = {"<anonymous>", "", "obj", "Landroidx/sqlite/db/SupportSQLiteDatabase;", "invoke", "(Landroidx/sqlite/db/SupportSQLiteDatabase;)Ljava/lang/Boolean;"}, k = 3, mv = {1, 7, 1}, xi = 48)
    static final class AutoClosingRoomOpenHelper$AutoClosingSupportSQLiteDatabase$isReadOnly$1 extends Lambda implements Function1<SupportSQLiteDatabase, Boolean> {
      public static final AutoClosingRoomOpenHelper$AutoClosingSupportSQLiteDatabase$isReadOnly$1 INSTANCE = new AutoClosingRoomOpenHelper$AutoClosingSupportSQLiteDatabase$isReadOnly$1();
      
      AutoClosingRoomOpenHelper$AutoClosingSupportSQLiteDatabase$isReadOnly$1() {
        super(1);
      }
      
      public final Boolean invoke(SupportSQLiteDatabase param2SupportSQLiteDatabase) {
        Intrinsics.checkNotNullParameter(param2SupportSQLiteDatabase, "obj");
        return Boolean.valueOf(param2SupportSQLiteDatabase.isReadOnly());
      }
    }
    
    @Metadata(d1 = {"\000\020\n\000\n\002\020\013\n\000\n\002\030\002\n\002\b\002\020\000\032\0020\0012\006\020\002\032\0020\003H\n¢\006\004\b\004\020\005"}, d2 = {"<anonymous>", "", "db", "Landroidx/sqlite/db/SupportSQLiteDatabase;", "invoke", "(Landroidx/sqlite/db/SupportSQLiteDatabase;)Ljava/lang/Boolean;"}, k = 3, mv = {1, 7, 1}, xi = 48)
    static final class AutoClosingRoomOpenHelper$AutoClosingSupportSQLiteDatabase$isWriteAheadLoggingEnabled$1 extends Lambda implements Function1<SupportSQLiteDatabase, Boolean> {
      public static final AutoClosingRoomOpenHelper$AutoClosingSupportSQLiteDatabase$isWriteAheadLoggingEnabled$1 INSTANCE = new AutoClosingRoomOpenHelper$AutoClosingSupportSQLiteDatabase$isWriteAheadLoggingEnabled$1();
      
      AutoClosingRoomOpenHelper$AutoClosingSupportSQLiteDatabase$isWriteAheadLoggingEnabled$1() {
        super(1);
      }
      
      public final Boolean invoke(SupportSQLiteDatabase param2SupportSQLiteDatabase) {
        Intrinsics.checkNotNullParameter(param2SupportSQLiteDatabase, "db");
        return Boolean.valueOf(param2SupportSQLiteDatabase.isWriteAheadLoggingEnabled());
      }
    }
    
    @Metadata(d1 = {"\000\020\n\000\n\002\020\013\n\000\n\002\030\002\n\002\b\002\020\000\032\0020\0012\006\020\002\032\0020\003H\n¢\006\004\b\004\020\005"}, d2 = {"<anonymous>", "", "db", "Landroidx/sqlite/db/SupportSQLiteDatabase;", "invoke", "(Landroidx/sqlite/db/SupportSQLiteDatabase;)Ljava/lang/Boolean;"}, k = 3, mv = {1, 7, 1}, xi = 48)
    static final class AutoClosingRoomOpenHelper$AutoClosingSupportSQLiteDatabase$needUpgrade$1 extends Lambda implements Function1<SupportSQLiteDatabase, Boolean> {
      AutoClosingRoomOpenHelper$AutoClosingSupportSQLiteDatabase$needUpgrade$1(int param2Int) {
        super(1);
      }
      
      public final Boolean invoke(SupportSQLiteDatabase param2SupportSQLiteDatabase) {
        Intrinsics.checkNotNullParameter(param2SupportSQLiteDatabase, "db");
        return Boolean.valueOf(param2SupportSQLiteDatabase.needUpgrade(this.$newVersion));
      }
    }
    
    @Metadata(d1 = {"\000\016\n\000\n\002\020\000\n\000\n\002\030\002\n\000\020\000\032\004\030\0010\0012\006\020\002\032\0020\003H\n¢\006\002\b\004"}, d2 = {"<anonymous>", "", "db", "Landroidx/sqlite/db/SupportSQLiteDatabase;", "invoke"}, k = 3, mv = {1, 7, 1}, xi = 48)
    static final class AutoClosingRoomOpenHelper$AutoClosingSupportSQLiteDatabase$pageSize$2 extends Lambda implements Function1<SupportSQLiteDatabase, Object> {
      AutoClosingRoomOpenHelper$AutoClosingSupportSQLiteDatabase$pageSize$2(long param2Long) {
        super(1);
      }
      
      public final Object invoke(SupportSQLiteDatabase param2SupportSQLiteDatabase) {
        Intrinsics.checkNotNullParameter(param2SupportSQLiteDatabase, "db");
        param2SupportSQLiteDatabase.setPageSize(this.$numBytes);
        return null;
      }
    }
    
    @Metadata(d1 = {"\000\016\n\000\n\002\020\016\n\000\n\002\030\002\n\000\020\000\032\004\030\0010\0012\006\020\002\032\0020\003H\n¢\006\002\b\004"}, d2 = {"<anonymous>", "", "obj", "Landroidx/sqlite/db/SupportSQLiteDatabase;", "invoke"}, k = 3, mv = {1, 7, 1}, xi = 48)
    static final class AutoClosingRoomOpenHelper$AutoClosingSupportSQLiteDatabase$path$1 extends Lambda implements Function1<SupportSQLiteDatabase, String> {
      public static final AutoClosingRoomOpenHelper$AutoClosingSupportSQLiteDatabase$path$1 INSTANCE = new AutoClosingRoomOpenHelper$AutoClosingSupportSQLiteDatabase$path$1();
      
      AutoClosingRoomOpenHelper$AutoClosingSupportSQLiteDatabase$path$1() {
        super(1);
      }
      
      public final String invoke(SupportSQLiteDatabase param2SupportSQLiteDatabase) {
        Intrinsics.checkNotNullParameter(param2SupportSQLiteDatabase, "obj");
        return param2SupportSQLiteDatabase.getPath();
      }
    }
    
    @Metadata(d1 = {"\000\016\n\000\n\002\020\000\n\000\n\002\030\002\n\000\020\000\032\004\030\0010\0012\006\020\002\032\0020\003H\n¢\006\002\b\004"}, d2 = {"<anonymous>", "", "it", "Landroidx/sqlite/db/SupportSQLiteDatabase;", "invoke"}, k = 3, mv = {1, 7, 1}, xi = 48)
    static final class AutoClosingRoomOpenHelper$AutoClosingSupportSQLiteDatabase$pokeOpen$1 extends Lambda implements Function1<SupportSQLiteDatabase, Object> {
      public static final AutoClosingRoomOpenHelper$AutoClosingSupportSQLiteDatabase$pokeOpen$1 INSTANCE = new AutoClosingRoomOpenHelper$AutoClosingSupportSQLiteDatabase$pokeOpen$1();
      
      AutoClosingRoomOpenHelper$AutoClosingSupportSQLiteDatabase$pokeOpen$1() {
        super(1);
      }
      
      public final Object invoke(SupportSQLiteDatabase param2SupportSQLiteDatabase) {
        Intrinsics.checkNotNullParameter(param2SupportSQLiteDatabase, "it");
        return null;
      }
    }
    
    @Metadata(d1 = {"\000\016\n\000\n\002\020\000\n\000\n\002\030\002\n\000\020\000\032\004\030\0010\0012\006\020\002\032\0020\003H\n¢\006\002\b\004"}, d2 = {"<anonymous>", "", "db", "Landroidx/sqlite/db/SupportSQLiteDatabase;", "invoke"}, k = 3, mv = {1, 7, 1}, xi = 48)
    static final class AutoClosingRoomOpenHelper$AutoClosingSupportSQLiteDatabase$setForeignKeyConstraintsEnabled$1 extends Lambda implements Function1<SupportSQLiteDatabase, Object> {
      AutoClosingRoomOpenHelper$AutoClosingSupportSQLiteDatabase$setForeignKeyConstraintsEnabled$1(boolean param2Boolean) {
        super(1);
      }
      
      public final Object invoke(SupportSQLiteDatabase param2SupportSQLiteDatabase) {
        Intrinsics.checkNotNullParameter(param2SupportSQLiteDatabase, "db");
        param2SupportSQLiteDatabase.setForeignKeyConstraintsEnabled(this.$enabled);
        return null;
      }
    }
    
    @Metadata(d1 = {"\000\016\n\000\n\002\020\000\n\000\n\002\030\002\n\000\020\000\032\004\030\0010\0012\006\020\002\032\0020\003H\n¢\006\002\b\004"}, d2 = {"<anonymous>", "", "db", "Landroidx/sqlite/db/SupportSQLiteDatabase;", "invoke"}, k = 3, mv = {1, 7, 1}, xi = 48)
    static final class AutoClosingRoomOpenHelper$AutoClosingSupportSQLiteDatabase$setLocale$1 extends Lambda implements Function1<SupportSQLiteDatabase, Object> {
      AutoClosingRoomOpenHelper$AutoClosingSupportSQLiteDatabase$setLocale$1(Locale param2Locale) {
        super(1);
      }
      
      public final Object invoke(SupportSQLiteDatabase param2SupportSQLiteDatabase) {
        Intrinsics.checkNotNullParameter(param2SupportSQLiteDatabase, "db");
        param2SupportSQLiteDatabase.setLocale(this.$locale);
        return null;
      }
    }
    
    @Metadata(d1 = {"\000\016\n\000\n\002\020\000\n\000\n\002\030\002\n\000\020\000\032\004\030\0010\0012\006\020\002\032\0020\003H\n¢\006\002\b\004"}, d2 = {"<anonymous>", "", "db", "Landroidx/sqlite/db/SupportSQLiteDatabase;", "invoke"}, k = 3, mv = {1, 7, 1}, xi = 48)
    static final class AutoClosingRoomOpenHelper$AutoClosingSupportSQLiteDatabase$setMaxSqlCacheSize$1 extends Lambda implements Function1<SupportSQLiteDatabase, Object> {
      AutoClosingRoomOpenHelper$AutoClosingSupportSQLiteDatabase$setMaxSqlCacheSize$1(int param2Int) {
        super(1);
      }
      
      public final Object invoke(SupportSQLiteDatabase param2SupportSQLiteDatabase) {
        Intrinsics.checkNotNullParameter(param2SupportSQLiteDatabase, "db");
        param2SupportSQLiteDatabase.setMaxSqlCacheSize(this.$cacheSize);
        return null;
      }
    }
    
    @Metadata(d1 = {"\000\020\n\000\n\002\020\t\n\000\n\002\030\002\n\002\b\002\020\000\032\0020\0012\006\020\002\032\0020\003H\n¢\006\004\b\004\020\005"}, d2 = {"<anonymous>", "", "db", "Landroidx/sqlite/db/SupportSQLiteDatabase;", "invoke", "(Landroidx/sqlite/db/SupportSQLiteDatabase;)Ljava/lang/Long;"}, k = 3, mv = {1, 7, 1}, xi = 48)
    static final class AutoClosingRoomOpenHelper$AutoClosingSupportSQLiteDatabase$setMaximumSize$1 extends Lambda implements Function1<SupportSQLiteDatabase, Long> {
      AutoClosingRoomOpenHelper$AutoClosingSupportSQLiteDatabase$setMaximumSize$1(long param2Long) {
        super(1);
      }
      
      public final Long invoke(SupportSQLiteDatabase param2SupportSQLiteDatabase) {
        Intrinsics.checkNotNullParameter(param2SupportSQLiteDatabase, "db");
        return Long.valueOf(param2SupportSQLiteDatabase.setMaximumSize(this.$numBytes));
      }
    }
    
    @Metadata(d1 = {"\000\020\n\000\n\002\020\b\n\000\n\002\030\002\n\002\b\002\020\000\032\0020\0012\006\020\002\032\0020\003H\n¢\006\004\b\004\020\005"}, d2 = {"<anonymous>", "", "db", "Landroidx/sqlite/db/SupportSQLiteDatabase;", "invoke", "(Landroidx/sqlite/db/SupportSQLiteDatabase;)Ljava/lang/Integer;"}, k = 3, mv = {1, 7, 1}, xi = 48)
    static final class AutoClosingRoomOpenHelper$AutoClosingSupportSQLiteDatabase$update$1 extends Lambda implements Function1<SupportSQLiteDatabase, Integer> {
      AutoClosingRoomOpenHelper$AutoClosingSupportSQLiteDatabase$update$1(String param2String1, int param2Int, ContentValues param2ContentValues, String param2String2, Object[] param2ArrayOfObject) {
        super(1);
      }
      
      public final Integer invoke(SupportSQLiteDatabase param2SupportSQLiteDatabase) {
        Intrinsics.checkNotNullParameter(param2SupportSQLiteDatabase, "db");
        return Integer.valueOf(param2SupportSQLiteDatabase.update(this.$table, this.$conflictAlgorithm, this.$values, this.$whereClause, this.$whereArgs));
      }
    }
    
    @Metadata(d1 = {"\000\016\n\000\n\002\020\000\n\000\n\002\030\002\n\000\020\000\032\004\030\0010\0012\006\020\002\032\0020\003H\n¢\006\002\b\004"}, d2 = {"<anonymous>", "", "db", "Landroidx/sqlite/db/SupportSQLiteDatabase;", "invoke"}, k = 3, mv = {1, 7, 1}, xi = 48)
    static final class AutoClosingRoomOpenHelper$AutoClosingSupportSQLiteDatabase$version$2 extends Lambda implements Function1<SupportSQLiteDatabase, Object> {
      AutoClosingRoomOpenHelper$AutoClosingSupportSQLiteDatabase$version$2(int param2Int) {
        super(1);
      }
      
      public final Object invoke(SupportSQLiteDatabase param2SupportSQLiteDatabase) {
        Intrinsics.checkNotNullParameter(param2SupportSQLiteDatabase, "db");
        param2SupportSQLiteDatabase.setVersion(this.$version);
        return null;
      }
    }
  }
  
  @Metadata(d1 = {"\000\026\n\000\n\002\020 \n\002\030\002\n\002\020\016\n\000\n\002\030\002\n\000\020\000\032\026\022\020\022\016\022\004\022\0020\003\022\004\022\0020\0030\002\030\0010\0012\006\020\004\032\0020\005H\n¢\006\002\b\006"}, d2 = {"<anonymous>", "", "Landroid/util/Pair;", "", "obj", "Landroidx/sqlite/db/SupportSQLiteDatabase;", "invoke"}, k = 3, mv = {1, 7, 1}, xi = 48)
  static final class AutoClosingRoomOpenHelper$AutoClosingSupportSQLiteDatabase$attachedDbs$1 extends Lambda implements Function1<SupportSQLiteDatabase, List<? extends Pair<String, String>>> {
    public static final AutoClosingRoomOpenHelper$AutoClosingSupportSQLiteDatabase$attachedDbs$1 INSTANCE = new AutoClosingRoomOpenHelper$AutoClosingSupportSQLiteDatabase$attachedDbs$1();
    
    AutoClosingRoomOpenHelper$AutoClosingSupportSQLiteDatabase$attachedDbs$1() {
      super(1);
    }
    
    public final List<Pair<String, String>> invoke(SupportSQLiteDatabase param1SupportSQLiteDatabase) {
      Intrinsics.checkNotNullParameter(param1SupportSQLiteDatabase, "obj");
      return param1SupportSQLiteDatabase.getAttachedDbs();
    }
  }
  
  @Metadata(d1 = {"\000\020\n\000\n\002\020\b\n\000\n\002\030\002\n\002\b\002\020\000\032\0020\0012\006\020\002\032\0020\003H\n¢\006\004\b\004\020\005"}, d2 = {"<anonymous>", "", "db", "Landroidx/sqlite/db/SupportSQLiteDatabase;", "invoke", "(Landroidx/sqlite/db/SupportSQLiteDatabase;)Ljava/lang/Integer;"}, k = 3, mv = {1, 7, 1}, xi = 48)
  static final class AutoClosingRoomOpenHelper$AutoClosingSupportSQLiteDatabase$delete$1 extends Lambda implements Function1<SupportSQLiteDatabase, Integer> {
    AutoClosingRoomOpenHelper$AutoClosingSupportSQLiteDatabase$delete$1(String param1String1, String param1String2, Object[] param1ArrayOfObject) {
      super(1);
    }
    
    public final Integer invoke(SupportSQLiteDatabase param1SupportSQLiteDatabase) {
      Intrinsics.checkNotNullParameter(param1SupportSQLiteDatabase, "db");
      return Integer.valueOf(param1SupportSQLiteDatabase.delete(this.$table, this.$whereClause, this.$whereArgs));
    }
  }
  
  @Metadata(d1 = {"\000\016\n\000\n\002\020\000\n\000\n\002\030\002\n\000\020\000\032\004\030\0010\0012\006\020\002\032\0020\003H\n¢\006\002\b\004"}, d2 = {"<anonymous>", "", "db", "Landroidx/sqlite/db/SupportSQLiteDatabase;", "invoke"}, k = 3, mv = {1, 7, 1}, xi = 48)
  static final class AutoClosingRoomOpenHelper$AutoClosingSupportSQLiteDatabase$execSQL$1 extends Lambda implements Function1<SupportSQLiteDatabase, Object> {
    AutoClosingRoomOpenHelper$AutoClosingSupportSQLiteDatabase$execSQL$1(String param1String) {
      super(1);
    }
    
    public final Object invoke(SupportSQLiteDatabase param1SupportSQLiteDatabase) {
      Intrinsics.checkNotNullParameter(param1SupportSQLiteDatabase, "db");
      param1SupportSQLiteDatabase.execSQL(this.$sql);
      return null;
    }
  }
  
  @Metadata(d1 = {"\000\016\n\000\n\002\020\000\n\000\n\002\030\002\n\000\020\000\032\004\030\0010\0012\006\020\002\032\0020\003H\n¢\006\002\b\004"}, d2 = {"<anonymous>", "", "db", "Landroidx/sqlite/db/SupportSQLiteDatabase;", "invoke"}, k = 3, mv = {1, 7, 1}, xi = 48)
  static final class AutoClosingRoomOpenHelper$AutoClosingSupportSQLiteDatabase$execSQL$2 extends Lambda implements Function1<SupportSQLiteDatabase, Object> {
    AutoClosingRoomOpenHelper$AutoClosingSupportSQLiteDatabase$execSQL$2(String param1String, Object[] param1ArrayOfObject) {
      super(1);
    }
    
    public final Object invoke(SupportSQLiteDatabase param1SupportSQLiteDatabase) {
      Intrinsics.checkNotNullParameter(param1SupportSQLiteDatabase, "db");
      param1SupportSQLiteDatabase.execSQL(this.$sql, this.$bindArgs);
      return null;
    }
  }
  
  @Metadata(d1 = {"\000\020\n\000\n\002\020\t\n\000\n\002\030\002\n\002\b\002\020\000\032\0020\0012\006\020\002\032\0020\003H\n¢\006\004\b\004\020\005"}, d2 = {"<anonymous>", "", "db", "Landroidx/sqlite/db/SupportSQLiteDatabase;", "invoke", "(Landroidx/sqlite/db/SupportSQLiteDatabase;)Ljava/lang/Long;"}, k = 3, mv = {1, 7, 1}, xi = 48)
  static final class AutoClosingRoomOpenHelper$AutoClosingSupportSQLiteDatabase$insert$1 extends Lambda implements Function1<SupportSQLiteDatabase, Long> {
    AutoClosingRoomOpenHelper$AutoClosingSupportSQLiteDatabase$insert$1(String param1String, int param1Int, ContentValues param1ContentValues) {
      super(1);
    }
    
    public final Long invoke(SupportSQLiteDatabase param1SupportSQLiteDatabase) {
      Intrinsics.checkNotNullParameter(param1SupportSQLiteDatabase, "db");
      return Long.valueOf(param1SupportSQLiteDatabase.insert(this.$table, this.$conflictAlgorithm, this.$values));
    }
  }
  
  @Metadata(d1 = {"\000\020\n\000\n\002\020\013\n\000\n\002\030\002\n\002\b\002\020\000\032\0020\0012\006\020\002\032\0020\003H\n¢\006\004\b\004\020\005"}, d2 = {"<anonymous>", "", "obj", "Landroidx/sqlite/db/SupportSQLiteDatabase;", "invoke", "(Landroidx/sqlite/db/SupportSQLiteDatabase;)Ljava/lang/Boolean;"}, k = 3, mv = {1, 7, 1}, xi = 48)
  static final class AutoClosingRoomOpenHelper$AutoClosingSupportSQLiteDatabase$isDatabaseIntegrityOk$1 extends Lambda implements Function1<SupportSQLiteDatabase, Boolean> {
    public static final AutoClosingRoomOpenHelper$AutoClosingSupportSQLiteDatabase$isDatabaseIntegrityOk$1 INSTANCE = new AutoClosingRoomOpenHelper$AutoClosingSupportSQLiteDatabase$isDatabaseIntegrityOk$1();
    
    AutoClosingRoomOpenHelper$AutoClosingSupportSQLiteDatabase$isDatabaseIntegrityOk$1() {
      super(1);
    }
    
    public final Boolean invoke(SupportSQLiteDatabase param1SupportSQLiteDatabase) {
      Intrinsics.checkNotNullParameter(param1SupportSQLiteDatabase, "obj");
      return Boolean.valueOf(param1SupportSQLiteDatabase.isDatabaseIntegrityOk());
    }
  }
  
  @Metadata(d1 = {"\000\020\n\000\n\002\020\013\n\000\n\002\030\002\n\002\b\002\020\000\032\0020\0012\006\020\002\032\0020\003H\n¢\006\004\b\004\020\005"}, d2 = {"<anonymous>", "", "obj", "Landroidx/sqlite/db/SupportSQLiteDatabase;", "invoke", "(Landroidx/sqlite/db/SupportSQLiteDatabase;)Ljava/lang/Boolean;"}, k = 3, mv = {1, 7, 1}, xi = 48)
  static final class AutoClosingRoomOpenHelper$AutoClosingSupportSQLiteDatabase$isReadOnly$1 extends Lambda implements Function1<SupportSQLiteDatabase, Boolean> {
    public static final AutoClosingRoomOpenHelper$AutoClosingSupportSQLiteDatabase$isReadOnly$1 INSTANCE = new AutoClosingRoomOpenHelper$AutoClosingSupportSQLiteDatabase$isReadOnly$1();
    
    AutoClosingRoomOpenHelper$AutoClosingSupportSQLiteDatabase$isReadOnly$1() {
      super(1);
    }
    
    public final Boolean invoke(SupportSQLiteDatabase param1SupportSQLiteDatabase) {
      Intrinsics.checkNotNullParameter(param1SupportSQLiteDatabase, "obj");
      return Boolean.valueOf(param1SupportSQLiteDatabase.isReadOnly());
    }
  }
  
  @Metadata(d1 = {"\000\020\n\000\n\002\020\013\n\000\n\002\030\002\n\002\b\002\020\000\032\0020\0012\006\020\002\032\0020\003H\n¢\006\004\b\004\020\005"}, d2 = {"<anonymous>", "", "db", "Landroidx/sqlite/db/SupportSQLiteDatabase;", "invoke", "(Landroidx/sqlite/db/SupportSQLiteDatabase;)Ljava/lang/Boolean;"}, k = 3, mv = {1, 7, 1}, xi = 48)
  static final class AutoClosingRoomOpenHelper$AutoClosingSupportSQLiteDatabase$isWriteAheadLoggingEnabled$1 extends Lambda implements Function1<SupportSQLiteDatabase, Boolean> {
    public static final AutoClosingRoomOpenHelper$AutoClosingSupportSQLiteDatabase$isWriteAheadLoggingEnabled$1 INSTANCE = new AutoClosingRoomOpenHelper$AutoClosingSupportSQLiteDatabase$isWriteAheadLoggingEnabled$1();
    
    AutoClosingRoomOpenHelper$AutoClosingSupportSQLiteDatabase$isWriteAheadLoggingEnabled$1() {
      super(1);
    }
    
    public final Boolean invoke(SupportSQLiteDatabase param1SupportSQLiteDatabase) {
      Intrinsics.checkNotNullParameter(param1SupportSQLiteDatabase, "db");
      return Boolean.valueOf(param1SupportSQLiteDatabase.isWriteAheadLoggingEnabled());
    }
  }
  
  @Metadata(d1 = {"\000\020\n\000\n\002\020\013\n\000\n\002\030\002\n\002\b\002\020\000\032\0020\0012\006\020\002\032\0020\003H\n¢\006\004\b\004\020\005"}, d2 = {"<anonymous>", "", "db", "Landroidx/sqlite/db/SupportSQLiteDatabase;", "invoke", "(Landroidx/sqlite/db/SupportSQLiteDatabase;)Ljava/lang/Boolean;"}, k = 3, mv = {1, 7, 1}, xi = 48)
  static final class AutoClosingRoomOpenHelper$AutoClosingSupportSQLiteDatabase$needUpgrade$1 extends Lambda implements Function1<SupportSQLiteDatabase, Boolean> {
    AutoClosingRoomOpenHelper$AutoClosingSupportSQLiteDatabase$needUpgrade$1(int param1Int) {
      super(1);
    }
    
    public final Boolean invoke(SupportSQLiteDatabase param1SupportSQLiteDatabase) {
      Intrinsics.checkNotNullParameter(param1SupportSQLiteDatabase, "db");
      return Boolean.valueOf(param1SupportSQLiteDatabase.needUpgrade(this.$newVersion));
    }
  }
  
  @Metadata(d1 = {"\000\016\n\000\n\002\020\000\n\000\n\002\030\002\n\000\020\000\032\004\030\0010\0012\006\020\002\032\0020\003H\n¢\006\002\b\004"}, d2 = {"<anonymous>", "", "db", "Landroidx/sqlite/db/SupportSQLiteDatabase;", "invoke"}, k = 3, mv = {1, 7, 1}, xi = 48)
  static final class AutoClosingRoomOpenHelper$AutoClosingSupportSQLiteDatabase$pageSize$2 extends Lambda implements Function1<SupportSQLiteDatabase, Object> {
    AutoClosingRoomOpenHelper$AutoClosingSupportSQLiteDatabase$pageSize$2(long param1Long) {
      super(1);
    }
    
    public final Object invoke(SupportSQLiteDatabase param1SupportSQLiteDatabase) {
      Intrinsics.checkNotNullParameter(param1SupportSQLiteDatabase, "db");
      param1SupportSQLiteDatabase.setPageSize(this.$numBytes);
      return null;
    }
  }
  
  @Metadata(d1 = {"\000\016\n\000\n\002\020\016\n\000\n\002\030\002\n\000\020\000\032\004\030\0010\0012\006\020\002\032\0020\003H\n¢\006\002\b\004"}, d2 = {"<anonymous>", "", "obj", "Landroidx/sqlite/db/SupportSQLiteDatabase;", "invoke"}, k = 3, mv = {1, 7, 1}, xi = 48)
  static final class AutoClosingRoomOpenHelper$AutoClosingSupportSQLiteDatabase$path$1 extends Lambda implements Function1<SupportSQLiteDatabase, String> {
    public static final AutoClosingRoomOpenHelper$AutoClosingSupportSQLiteDatabase$path$1 INSTANCE = new AutoClosingRoomOpenHelper$AutoClosingSupportSQLiteDatabase$path$1();
    
    AutoClosingRoomOpenHelper$AutoClosingSupportSQLiteDatabase$path$1() {
      super(1);
    }
    
    public final String invoke(SupportSQLiteDatabase param1SupportSQLiteDatabase) {
      Intrinsics.checkNotNullParameter(param1SupportSQLiteDatabase, "obj");
      return param1SupportSQLiteDatabase.getPath();
    }
  }
  
  @Metadata(d1 = {"\000\016\n\000\n\002\020\000\n\000\n\002\030\002\n\000\020\000\032\004\030\0010\0012\006\020\002\032\0020\003H\n¢\006\002\b\004"}, d2 = {"<anonymous>", "", "it", "Landroidx/sqlite/db/SupportSQLiteDatabase;", "invoke"}, k = 3, mv = {1, 7, 1}, xi = 48)
  static final class AutoClosingRoomOpenHelper$AutoClosingSupportSQLiteDatabase$pokeOpen$1 extends Lambda implements Function1<SupportSQLiteDatabase, Object> {
    public static final AutoClosingRoomOpenHelper$AutoClosingSupportSQLiteDatabase$pokeOpen$1 INSTANCE = new AutoClosingRoomOpenHelper$AutoClosingSupportSQLiteDatabase$pokeOpen$1();
    
    AutoClosingRoomOpenHelper$AutoClosingSupportSQLiteDatabase$pokeOpen$1() {
      super(1);
    }
    
    public final Object invoke(SupportSQLiteDatabase param1SupportSQLiteDatabase) {
      Intrinsics.checkNotNullParameter(param1SupportSQLiteDatabase, "it");
      return null;
    }
  }
  
  @Metadata(d1 = {"\000\016\n\000\n\002\020\000\n\000\n\002\030\002\n\000\020\000\032\004\030\0010\0012\006\020\002\032\0020\003H\n¢\006\002\b\004"}, d2 = {"<anonymous>", "", "db", "Landroidx/sqlite/db/SupportSQLiteDatabase;", "invoke"}, k = 3, mv = {1, 7, 1}, xi = 48)
  static final class AutoClosingRoomOpenHelper$AutoClosingSupportSQLiteDatabase$setForeignKeyConstraintsEnabled$1 extends Lambda implements Function1<SupportSQLiteDatabase, Object> {
    AutoClosingRoomOpenHelper$AutoClosingSupportSQLiteDatabase$setForeignKeyConstraintsEnabled$1(boolean param1Boolean) {
      super(1);
    }
    
    public final Object invoke(SupportSQLiteDatabase param1SupportSQLiteDatabase) {
      Intrinsics.checkNotNullParameter(param1SupportSQLiteDatabase, "db");
      param1SupportSQLiteDatabase.setForeignKeyConstraintsEnabled(this.$enabled);
      return null;
    }
  }
  
  @Metadata(d1 = {"\000\016\n\000\n\002\020\000\n\000\n\002\030\002\n\000\020\000\032\004\030\0010\0012\006\020\002\032\0020\003H\n¢\006\002\b\004"}, d2 = {"<anonymous>", "", "db", "Landroidx/sqlite/db/SupportSQLiteDatabase;", "invoke"}, k = 3, mv = {1, 7, 1}, xi = 48)
  static final class AutoClosingRoomOpenHelper$AutoClosingSupportSQLiteDatabase$setLocale$1 extends Lambda implements Function1<SupportSQLiteDatabase, Object> {
    AutoClosingRoomOpenHelper$AutoClosingSupportSQLiteDatabase$setLocale$1(Locale param1Locale) {
      super(1);
    }
    
    public final Object invoke(SupportSQLiteDatabase param1SupportSQLiteDatabase) {
      Intrinsics.checkNotNullParameter(param1SupportSQLiteDatabase, "db");
      param1SupportSQLiteDatabase.setLocale(this.$locale);
      return null;
    }
  }
  
  @Metadata(d1 = {"\000\016\n\000\n\002\020\000\n\000\n\002\030\002\n\000\020\000\032\004\030\0010\0012\006\020\002\032\0020\003H\n¢\006\002\b\004"}, d2 = {"<anonymous>", "", "db", "Landroidx/sqlite/db/SupportSQLiteDatabase;", "invoke"}, k = 3, mv = {1, 7, 1}, xi = 48)
  static final class AutoClosingRoomOpenHelper$AutoClosingSupportSQLiteDatabase$setMaxSqlCacheSize$1 extends Lambda implements Function1<SupportSQLiteDatabase, Object> {
    AutoClosingRoomOpenHelper$AutoClosingSupportSQLiteDatabase$setMaxSqlCacheSize$1(int param1Int) {
      super(1);
    }
    
    public final Object invoke(SupportSQLiteDatabase param1SupportSQLiteDatabase) {
      Intrinsics.checkNotNullParameter(param1SupportSQLiteDatabase, "db");
      param1SupportSQLiteDatabase.setMaxSqlCacheSize(this.$cacheSize);
      return null;
    }
  }
  
  @Metadata(d1 = {"\000\020\n\000\n\002\020\t\n\000\n\002\030\002\n\002\b\002\020\000\032\0020\0012\006\020\002\032\0020\003H\n¢\006\004\b\004\020\005"}, d2 = {"<anonymous>", "", "db", "Landroidx/sqlite/db/SupportSQLiteDatabase;", "invoke", "(Landroidx/sqlite/db/SupportSQLiteDatabase;)Ljava/lang/Long;"}, k = 3, mv = {1, 7, 1}, xi = 48)
  static final class AutoClosingRoomOpenHelper$AutoClosingSupportSQLiteDatabase$setMaximumSize$1 extends Lambda implements Function1<SupportSQLiteDatabase, Long> {
    AutoClosingRoomOpenHelper$AutoClosingSupportSQLiteDatabase$setMaximumSize$1(long param1Long) {
      super(1);
    }
    
    public final Long invoke(SupportSQLiteDatabase param1SupportSQLiteDatabase) {
      Intrinsics.checkNotNullParameter(param1SupportSQLiteDatabase, "db");
      return Long.valueOf(param1SupportSQLiteDatabase.setMaximumSize(this.$numBytes));
    }
  }
  
  @Metadata(d1 = {"\000\020\n\000\n\002\020\b\n\000\n\002\030\002\n\002\b\002\020\000\032\0020\0012\006\020\002\032\0020\003H\n¢\006\004\b\004\020\005"}, d2 = {"<anonymous>", "", "db", "Landroidx/sqlite/db/SupportSQLiteDatabase;", "invoke", "(Landroidx/sqlite/db/SupportSQLiteDatabase;)Ljava/lang/Integer;"}, k = 3, mv = {1, 7, 1}, xi = 48)
  static final class AutoClosingRoomOpenHelper$AutoClosingSupportSQLiteDatabase$update$1 extends Lambda implements Function1<SupportSQLiteDatabase, Integer> {
    AutoClosingRoomOpenHelper$AutoClosingSupportSQLiteDatabase$update$1(String param1String1, int param1Int, ContentValues param1ContentValues, String param1String2, Object[] param1ArrayOfObject) {
      super(1);
    }
    
    public final Integer invoke(SupportSQLiteDatabase param1SupportSQLiteDatabase) {
      Intrinsics.checkNotNullParameter(param1SupportSQLiteDatabase, "db");
      return Integer.valueOf(param1SupportSQLiteDatabase.update(this.$table, this.$conflictAlgorithm, this.$values, this.$whereClause, this.$whereArgs));
    }
  }
  
  @Metadata(d1 = {"\000\016\n\000\n\002\020\000\n\000\n\002\030\002\n\000\020\000\032\004\030\0010\0012\006\020\002\032\0020\003H\n¢\006\002\b\004"}, d2 = {"<anonymous>", "", "db", "Landroidx/sqlite/db/SupportSQLiteDatabase;", "invoke"}, k = 3, mv = {1, 7, 1}, xi = 48)
  static final class AutoClosingRoomOpenHelper$AutoClosingSupportSQLiteDatabase$version$2 extends Lambda implements Function1<SupportSQLiteDatabase, Object> {
    AutoClosingRoomOpenHelper$AutoClosingSupportSQLiteDatabase$version$2(int param1Int) {
      super(1);
    }
    
    public final Object invoke(SupportSQLiteDatabase param1SupportSQLiteDatabase) {
      Intrinsics.checkNotNullParameter(param1SupportSQLiteDatabase, "db");
      param1SupportSQLiteDatabase.setVersion(this.$version);
      return null;
    }
  }
  
  @Metadata(d1 = {"\000N\n\002\030\002\n\002\030\002\n\000\n\002\020\016\n\000\n\002\030\002\n\002\b\002\n\002\030\002\n\002\020\000\n\002\030\002\n\000\n\002\020\002\n\000\n\002\020\b\n\000\n\002\020\022\n\000\n\002\020\006\n\000\n\002\020\t\n\002\b\013\n\002\030\002\n\002\b\007\b\002\030\0002\0020\001B\025\022\006\020\002\032\0020\003\022\006\020\004\032\0020\005¢\006\002\020\006J\030\020\013\032\0020\f2\006\020\r\032\0020\0162\006\020\017\032\0020\020H\026J\030\020\021\032\0020\f2\006\020\r\032\0020\0162\006\020\017\032\0020\022H\026J\030\020\023\032\0020\f2\006\020\r\032\0020\0162\006\020\017\032\0020\024H\026J\020\020\025\032\0020\f2\006\020\r\032\0020\016H\026J\030\020\026\032\0020\f2\006\020\r\032\0020\0162\006\020\017\032\0020\003H\026J\b\020\027\032\0020\fH\026J\b\020\030\032\0020\fH\026J\020\020\031\032\0020\f2\006\020\032\032\0020\001H\002J\b\020\033\032\0020\fH\026J\b\020\034\032\0020\024H\026J'\020\035\032\002H\036\"\004\b\000\020\0362\022\020\037\032\016\022\004\022\0020\001\022\004\022\002H\0360 H\002¢\006\002\020!J\b\020\"\032\0020\016H\026J\032\020#\032\0020\f2\006\020$\032\0020\0162\b\020\017\032\004\030\0010\tH\002J\b\020%\032\0020\024H\026J\n\020&\032\004\030\0010\003H\026R\016\020\004\032\0020\005X\004¢\006\002\n\000R\"\020\007\032\026\022\006\022\004\030\0010\t0\bj\n\022\006\022\004\030\0010\t`\nX\004¢\006\002\n\000R\016\020\002\032\0020\003X\004¢\006\002\n\000¨\006'"}, d2 = {"Landroidx/room/AutoClosingRoomOpenHelper$AutoClosingSupportSqliteStatement;", "Landroidx/sqlite/db/SupportSQLiteStatement;", "sql", "", "autoCloser", "Landroidx/room/AutoCloser;", "(Ljava/lang/String;Landroidx/room/AutoCloser;)V", "binds", "Ljava/util/ArrayList;", "", "Lkotlin/collections/ArrayList;", "bindBlob", "", "index", "", "value", "", "bindDouble", "", "bindLong", "", "bindNull", "bindString", "clearBindings", "close", "doBinds", "supportSQLiteStatement", "execute", "executeInsert", "executeSqliteStatementWithRefCount", "T", "block", "Lkotlin/Function1;", "(Lkotlin/jvm/functions/Function1;)Ljava/lang/Object;", "executeUpdateDelete", "saveBinds", "bindIndex", "simpleQueryForLong", "simpleQueryForString", "room-runtime_release"}, k = 1, mv = {1, 7, 1}, xi = 48)
  private static final class AutoClosingSupportSqliteStatement implements SupportSQLiteStatement {
    private final AutoCloser autoCloser;
    
    private final ArrayList<Object> binds;
    
    private final String sql;
    
    public AutoClosingSupportSqliteStatement(String param1String, AutoCloser param1AutoCloser) {
      this.sql = param1String;
      this.autoCloser = param1AutoCloser;
      this.binds = new ArrayList();
    }
    
    private final void doBinds(SupportSQLiteStatement param1SupportSQLiteStatement) {
      Iterator iterator = this.binds.iterator();
      for (int i = 0; iterator.hasNext(); i = j) {
        iterator.next();
        int j = i + 1;
        if (i < 0)
          CollectionsKt.throwIndexOverflow(); 
        Object object = this.binds.get(i);
        if (object == null) {
          param1SupportSQLiteStatement.bindNull(j);
        } else if (object instanceof Long) {
          param1SupportSQLiteStatement.bindLong(j, ((Number)object).longValue());
        } else if (object instanceof Double) {
          param1SupportSQLiteStatement.bindDouble(j, ((Number)object).doubleValue());
        } else if (object instanceof String) {
          param1SupportSQLiteStatement.bindString(j, (String)object);
        } else if (object instanceof byte[]) {
          param1SupportSQLiteStatement.bindBlob(j, (byte[])object);
        } 
      } 
    }
    
    private final <T> T executeSqliteStatementWithRefCount(Function1<? super SupportSQLiteStatement, ? extends T> param1Function1) {
      return (T)this.autoCloser.executeRefCountingFunction(new AutoClosingRoomOpenHelper$AutoClosingSupportSqliteStatement$executeSqliteStatementWithRefCount$1(param1Function1));
    }
    
    private final void saveBinds(int param1Int, Object param1Object) {
      int i = param1Int - 1;
      if (i >= this.binds.size()) {
        param1Int = this.binds.size();
        if (param1Int <= i)
          while (true) {
            this.binds.add(null);
            if (param1Int != i) {
              param1Int++;
              continue;
            } 
            break;
          }  
      } 
      this.binds.set(i, param1Object);
    }
    
    public void bindBlob(int param1Int, byte[] param1ArrayOfbyte) {
      Intrinsics.checkNotNullParameter(param1ArrayOfbyte, "value");
      saveBinds(param1Int, param1ArrayOfbyte);
    }
    
    public void bindDouble(int param1Int, double param1Double) {
      saveBinds(param1Int, Double.valueOf(param1Double));
    }
    
    public void bindLong(int param1Int, long param1Long) {
      saveBinds(param1Int, Long.valueOf(param1Long));
    }
    
    public void bindNull(int param1Int) {
      saveBinds(param1Int, null);
    }
    
    public void bindString(int param1Int, String param1String) {
      Intrinsics.checkNotNullParameter(param1String, "value");
      saveBinds(param1Int, param1String);
    }
    
    public void clearBindings() {
      this.binds.clear();
    }
    
    public void close() throws IOException {}
    
    public void execute() {
      executeSqliteStatementWithRefCount(AutoClosingRoomOpenHelper$AutoClosingSupportSqliteStatement$execute$1.INSTANCE);
    }
    
    public long executeInsert() {
      return ((Number)executeSqliteStatementWithRefCount(AutoClosingRoomOpenHelper$AutoClosingSupportSqliteStatement$executeInsert$1.INSTANCE)).longValue();
    }
    
    public int executeUpdateDelete() {
      return ((Number)executeSqliteStatementWithRefCount(AutoClosingRoomOpenHelper$AutoClosingSupportSqliteStatement$executeUpdateDelete$1.INSTANCE)).intValue();
    }
    
    public long simpleQueryForLong() {
      return ((Number)executeSqliteStatementWithRefCount(AutoClosingRoomOpenHelper$AutoClosingSupportSqliteStatement$simpleQueryForLong$1.INSTANCE)).longValue();
    }
    
    public String simpleQueryForString() {
      return executeSqliteStatementWithRefCount(AutoClosingRoomOpenHelper$AutoClosingSupportSqliteStatement$simpleQueryForString$1.INSTANCE);
    }
    
    @Metadata(d1 = {"\000\016\n\000\n\002\020\000\n\000\n\002\030\002\n\000\020\000\032\004\030\0010\0012\006\020\002\032\0020\003H\n¢\006\002\b\004"}, d2 = {"<anonymous>", "", "statement", "Landroidx/sqlite/db/SupportSQLiteStatement;", "invoke"}, k = 3, mv = {1, 7, 1}, xi = 48)
    static final class AutoClosingRoomOpenHelper$AutoClosingSupportSqliteStatement$execute$1 extends Lambda implements Function1<SupportSQLiteStatement, Object> {
      public static final AutoClosingRoomOpenHelper$AutoClosingSupportSqliteStatement$execute$1 INSTANCE = new AutoClosingRoomOpenHelper$AutoClosingSupportSqliteStatement$execute$1();
      
      AutoClosingRoomOpenHelper$AutoClosingSupportSqliteStatement$execute$1() {
        super(1);
      }
      
      public final Object invoke(SupportSQLiteStatement param2SupportSQLiteStatement) {
        Intrinsics.checkNotNullParameter(param2SupportSQLiteStatement, "statement");
        param2SupportSQLiteStatement.execute();
        return null;
      }
    }
    
    @Metadata(d1 = {"\000\020\n\000\n\002\020\t\n\000\n\002\030\002\n\002\b\002\020\000\032\0020\0012\006\020\002\032\0020\003H\n¢\006\004\b\004\020\005"}, d2 = {"<anonymous>", "", "obj", "Landroidx/sqlite/db/SupportSQLiteStatement;", "invoke", "(Landroidx/sqlite/db/SupportSQLiteStatement;)Ljava/lang/Long;"}, k = 3, mv = {1, 7, 1}, xi = 48)
    static final class AutoClosingRoomOpenHelper$AutoClosingSupportSqliteStatement$executeInsert$1 extends Lambda implements Function1<SupportSQLiteStatement, Long> {
      public static final AutoClosingRoomOpenHelper$AutoClosingSupportSqliteStatement$executeInsert$1 INSTANCE = new AutoClosingRoomOpenHelper$AutoClosingSupportSqliteStatement$executeInsert$1();
      
      AutoClosingRoomOpenHelper$AutoClosingSupportSqliteStatement$executeInsert$1() {
        super(1);
      }
      
      public final Long invoke(SupportSQLiteStatement param2SupportSQLiteStatement) {
        Intrinsics.checkNotNullParameter(param2SupportSQLiteStatement, "obj");
        return Long.valueOf(param2SupportSQLiteStatement.executeInsert());
      }
    }
    
    @Metadata(d1 = {"\000\f\n\002\b\003\n\002\030\002\n\002\b\002\020\000\032\002H\001\"\004\b\000\020\0012\006\020\002\032\0020\003H\n¢\006\004\b\004\020\005"}, d2 = {"<anonymous>", "T", "db", "Landroidx/sqlite/db/SupportSQLiteDatabase;", "invoke", "(Landroidx/sqlite/db/SupportSQLiteDatabase;)Ljava/lang/Object;"}, k = 3, mv = {1, 7, 1}, xi = 48)
    static final class AutoClosingRoomOpenHelper$AutoClosingSupportSqliteStatement$executeSqliteStatementWithRefCount$1 extends Lambda implements Function1<SupportSQLiteDatabase, T> {
      AutoClosingRoomOpenHelper$AutoClosingSupportSqliteStatement$executeSqliteStatementWithRefCount$1(Function1<? super SupportSQLiteStatement, ? extends T> param2Function1) {
        super(1);
      }
      
      public final T invoke(SupportSQLiteDatabase param2SupportSQLiteDatabase) {
        Intrinsics.checkNotNullParameter(param2SupportSQLiteDatabase, "db");
        SupportSQLiteStatement supportSQLiteStatement = param2SupportSQLiteDatabase.compileStatement(AutoClosingRoomOpenHelper.AutoClosingSupportSqliteStatement.this.sql);
        AutoClosingRoomOpenHelper.AutoClosingSupportSqliteStatement.this.doBinds(supportSQLiteStatement);
        return (T)this.$block.invoke(supportSQLiteStatement);
      }
    }
    
    @Metadata(d1 = {"\000\020\n\000\n\002\020\b\n\000\n\002\030\002\n\002\b\002\020\000\032\0020\0012\006\020\002\032\0020\003H\n¢\006\004\b\004\020\005"}, d2 = {"<anonymous>", "", "obj", "Landroidx/sqlite/db/SupportSQLiteStatement;", "invoke", "(Landroidx/sqlite/db/SupportSQLiteStatement;)Ljava/lang/Integer;"}, k = 3, mv = {1, 7, 1}, xi = 48)
    static final class AutoClosingRoomOpenHelper$AutoClosingSupportSqliteStatement$executeUpdateDelete$1 extends Lambda implements Function1<SupportSQLiteStatement, Integer> {
      public static final AutoClosingRoomOpenHelper$AutoClosingSupportSqliteStatement$executeUpdateDelete$1 INSTANCE = new AutoClosingRoomOpenHelper$AutoClosingSupportSqliteStatement$executeUpdateDelete$1();
      
      AutoClosingRoomOpenHelper$AutoClosingSupportSqliteStatement$executeUpdateDelete$1() {
        super(1);
      }
      
      public final Integer invoke(SupportSQLiteStatement param2SupportSQLiteStatement) {
        Intrinsics.checkNotNullParameter(param2SupportSQLiteStatement, "obj");
        return Integer.valueOf(param2SupportSQLiteStatement.executeUpdateDelete());
      }
    }
    
    @Metadata(d1 = {"\000\020\n\000\n\002\020\t\n\000\n\002\030\002\n\002\b\002\020\000\032\0020\0012\006\020\002\032\0020\003H\n¢\006\004\b\004\020\005"}, d2 = {"<anonymous>", "", "obj", "Landroidx/sqlite/db/SupportSQLiteStatement;", "invoke", "(Landroidx/sqlite/db/SupportSQLiteStatement;)Ljava/lang/Long;"}, k = 3, mv = {1, 7, 1}, xi = 48)
    static final class AutoClosingRoomOpenHelper$AutoClosingSupportSqliteStatement$simpleQueryForLong$1 extends Lambda implements Function1<SupportSQLiteStatement, Long> {
      public static final AutoClosingRoomOpenHelper$AutoClosingSupportSqliteStatement$simpleQueryForLong$1 INSTANCE = new AutoClosingRoomOpenHelper$AutoClosingSupportSqliteStatement$simpleQueryForLong$1();
      
      AutoClosingRoomOpenHelper$AutoClosingSupportSqliteStatement$simpleQueryForLong$1() {
        super(1);
      }
      
      public final Long invoke(SupportSQLiteStatement param2SupportSQLiteStatement) {
        Intrinsics.checkNotNullParameter(param2SupportSQLiteStatement, "obj");
        return Long.valueOf(param2SupportSQLiteStatement.simpleQueryForLong());
      }
    }
    
    @Metadata(d1 = {"\000\016\n\000\n\002\020\016\n\000\n\002\030\002\n\000\020\000\032\004\030\0010\0012\006\020\002\032\0020\003H\n¢\006\002\b\004"}, d2 = {"<anonymous>", "", "obj", "Landroidx/sqlite/db/SupportSQLiteStatement;", "invoke"}, k = 3, mv = {1, 7, 1}, xi = 48)
    static final class AutoClosingRoomOpenHelper$AutoClosingSupportSqliteStatement$simpleQueryForString$1 extends Lambda implements Function1<SupportSQLiteStatement, String> {
      public static final AutoClosingRoomOpenHelper$AutoClosingSupportSqliteStatement$simpleQueryForString$1 INSTANCE = new AutoClosingRoomOpenHelper$AutoClosingSupportSqliteStatement$simpleQueryForString$1();
      
      AutoClosingRoomOpenHelper$AutoClosingSupportSqliteStatement$simpleQueryForString$1() {
        super(1);
      }
      
      public final String invoke(SupportSQLiteStatement param2SupportSQLiteStatement) {
        Intrinsics.checkNotNullParameter(param2SupportSQLiteStatement, "obj");
        return param2SupportSQLiteStatement.simpleQueryForString();
      }
    }
  }
  
  @Metadata(d1 = {"\000\016\n\000\n\002\020\000\n\000\n\002\030\002\n\000\020\000\032\004\030\0010\0012\006\020\002\032\0020\003H\n¢\006\002\b\004"}, d2 = {"<anonymous>", "", "statement", "Landroidx/sqlite/db/SupportSQLiteStatement;", "invoke"}, k = 3, mv = {1, 7, 1}, xi = 48)
  static final class AutoClosingRoomOpenHelper$AutoClosingSupportSqliteStatement$execute$1 extends Lambda implements Function1<SupportSQLiteStatement, Object> {
    public static final AutoClosingRoomOpenHelper$AutoClosingSupportSqliteStatement$execute$1 INSTANCE = new AutoClosingRoomOpenHelper$AutoClosingSupportSqliteStatement$execute$1();
    
    AutoClosingRoomOpenHelper$AutoClosingSupportSqliteStatement$execute$1() {
      super(1);
    }
    
    public final Object invoke(SupportSQLiteStatement param1SupportSQLiteStatement) {
      Intrinsics.checkNotNullParameter(param1SupportSQLiteStatement, "statement");
      param1SupportSQLiteStatement.execute();
      return null;
    }
  }
  
  @Metadata(d1 = {"\000\020\n\000\n\002\020\t\n\000\n\002\030\002\n\002\b\002\020\000\032\0020\0012\006\020\002\032\0020\003H\n¢\006\004\b\004\020\005"}, d2 = {"<anonymous>", "", "obj", "Landroidx/sqlite/db/SupportSQLiteStatement;", "invoke", "(Landroidx/sqlite/db/SupportSQLiteStatement;)Ljava/lang/Long;"}, k = 3, mv = {1, 7, 1}, xi = 48)
  static final class AutoClosingRoomOpenHelper$AutoClosingSupportSqliteStatement$executeInsert$1 extends Lambda implements Function1<SupportSQLiteStatement, Long> {
    public static final AutoClosingRoomOpenHelper$AutoClosingSupportSqliteStatement$executeInsert$1 INSTANCE = new AutoClosingRoomOpenHelper$AutoClosingSupportSqliteStatement$executeInsert$1();
    
    AutoClosingRoomOpenHelper$AutoClosingSupportSqliteStatement$executeInsert$1() {
      super(1);
    }
    
    public final Long invoke(SupportSQLiteStatement param1SupportSQLiteStatement) {
      Intrinsics.checkNotNullParameter(param1SupportSQLiteStatement, "obj");
      return Long.valueOf(param1SupportSQLiteStatement.executeInsert());
    }
  }
  
  @Metadata(d1 = {"\000\f\n\002\b\003\n\002\030\002\n\002\b\002\020\000\032\002H\001\"\004\b\000\020\0012\006\020\002\032\0020\003H\n¢\006\004\b\004\020\005"}, d2 = {"<anonymous>", "T", "db", "Landroidx/sqlite/db/SupportSQLiteDatabase;", "invoke", "(Landroidx/sqlite/db/SupportSQLiteDatabase;)Ljava/lang/Object;"}, k = 3, mv = {1, 7, 1}, xi = 48)
  static final class AutoClosingRoomOpenHelper$AutoClosingSupportSqliteStatement$executeSqliteStatementWithRefCount$1 extends Lambda implements Function1<SupportSQLiteDatabase, T> {
    AutoClosingRoomOpenHelper$AutoClosingSupportSqliteStatement$executeSqliteStatementWithRefCount$1(Function1<? super SupportSQLiteStatement, ? extends T> param1Function1) {
      super(1);
    }
    
    public final T invoke(SupportSQLiteDatabase param1SupportSQLiteDatabase) {
      Intrinsics.checkNotNullParameter(param1SupportSQLiteDatabase, "db");
      SupportSQLiteStatement supportSQLiteStatement = param1SupportSQLiteDatabase.compileStatement(AutoClosingRoomOpenHelper.AutoClosingSupportSqliteStatement.this.sql);
      AutoClosingRoomOpenHelper.AutoClosingSupportSqliteStatement.this.doBinds(supportSQLiteStatement);
      return (T)this.$block.invoke(supportSQLiteStatement);
    }
  }
  
  @Metadata(d1 = {"\000\020\n\000\n\002\020\b\n\000\n\002\030\002\n\002\b\002\020\000\032\0020\0012\006\020\002\032\0020\003H\n¢\006\004\b\004\020\005"}, d2 = {"<anonymous>", "", "obj", "Landroidx/sqlite/db/SupportSQLiteStatement;", "invoke", "(Landroidx/sqlite/db/SupportSQLiteStatement;)Ljava/lang/Integer;"}, k = 3, mv = {1, 7, 1}, xi = 48)
  static final class AutoClosingRoomOpenHelper$AutoClosingSupportSqliteStatement$executeUpdateDelete$1 extends Lambda implements Function1<SupportSQLiteStatement, Integer> {
    public static final AutoClosingRoomOpenHelper$AutoClosingSupportSqliteStatement$executeUpdateDelete$1 INSTANCE = new AutoClosingRoomOpenHelper$AutoClosingSupportSqliteStatement$executeUpdateDelete$1();
    
    AutoClosingRoomOpenHelper$AutoClosingSupportSqliteStatement$executeUpdateDelete$1() {
      super(1);
    }
    
    public final Integer invoke(SupportSQLiteStatement param1SupportSQLiteStatement) {
      Intrinsics.checkNotNullParameter(param1SupportSQLiteStatement, "obj");
      return Integer.valueOf(param1SupportSQLiteStatement.executeUpdateDelete());
    }
  }
  
  @Metadata(d1 = {"\000\020\n\000\n\002\020\t\n\000\n\002\030\002\n\002\b\002\020\000\032\0020\0012\006\020\002\032\0020\003H\n¢\006\004\b\004\020\005"}, d2 = {"<anonymous>", "", "obj", "Landroidx/sqlite/db/SupportSQLiteStatement;", "invoke", "(Landroidx/sqlite/db/SupportSQLiteStatement;)Ljava/lang/Long;"}, k = 3, mv = {1, 7, 1}, xi = 48)
  static final class AutoClosingRoomOpenHelper$AutoClosingSupportSqliteStatement$simpleQueryForLong$1 extends Lambda implements Function1<SupportSQLiteStatement, Long> {
    public static final AutoClosingRoomOpenHelper$AutoClosingSupportSqliteStatement$simpleQueryForLong$1 INSTANCE = new AutoClosingRoomOpenHelper$AutoClosingSupportSqliteStatement$simpleQueryForLong$1();
    
    AutoClosingRoomOpenHelper$AutoClosingSupportSqliteStatement$simpleQueryForLong$1() {
      super(1);
    }
    
    public final Long invoke(SupportSQLiteStatement param1SupportSQLiteStatement) {
      Intrinsics.checkNotNullParameter(param1SupportSQLiteStatement, "obj");
      return Long.valueOf(param1SupportSQLiteStatement.simpleQueryForLong());
    }
  }
  
  @Metadata(d1 = {"\000\016\n\000\n\002\020\016\n\000\n\002\030\002\n\000\020\000\032\004\030\0010\0012\006\020\002\032\0020\003H\n¢\006\002\b\004"}, d2 = {"<anonymous>", "", "obj", "Landroidx/sqlite/db/SupportSQLiteStatement;", "invoke"}, k = 3, mv = {1, 7, 1}, xi = 48)
  static final class AutoClosingRoomOpenHelper$AutoClosingSupportSqliteStatement$simpleQueryForString$1 extends Lambda implements Function1<SupportSQLiteStatement, String> {
    public static final AutoClosingRoomOpenHelper$AutoClosingSupportSqliteStatement$simpleQueryForString$1 INSTANCE = new AutoClosingRoomOpenHelper$AutoClosingSupportSqliteStatement$simpleQueryForString$1();
    
    AutoClosingRoomOpenHelper$AutoClosingSupportSqliteStatement$simpleQueryForString$1() {
      super(1);
    }
    
    public final String invoke(SupportSQLiteStatement param1SupportSQLiteStatement) {
      Intrinsics.checkNotNullParameter(param1SupportSQLiteStatement, "obj");
      return param1SupportSQLiteStatement.simpleQueryForString();
    }
  }
  
  @Metadata(d1 = {"\000\001\n\002\030\002\n\002\030\002\n\002\b\002\n\002\030\002\n\002\b\002\n\002\020\002\n\002\b\002\n\002\020\b\n\000\n\002\030\002\n\002\b\003\n\002\020\022\n\002\b\002\n\002\020\016\n\002\b\003\n\002\020\021\n\002\b\003\n\002\020\006\n\000\n\002\030\002\n\000\n\002\020\007\n\002\b\002\n\002\020\t\n\000\n\002\030\002\n\000\n\002\020 \n\002\b\002\n\002\020\n\n\002\b\003\n\002\020\013\n\002\b\r\n\002\030\002\n\000\n\002\030\002\n\002\b\005\n\002\030\002\n\002\b\006\b\002\030\0002\0020\001B\025\022\006\020\002\032\0020\001\022\006\020\003\032\0020\004¢\006\002\020\005J\b\020\006\032\0020\007H\026J!\020\b\032\0020\0072\006\020\t\032\0020\n2\016\020\013\032\n \r*\004\030\0010\f0\fH\001J\t\020\016\032\0020\007H\001J\031\020\017\032\n \r*\004\030\0010\0200\0202\006\020\t\032\0020\nH\001J\t\020\021\032\0020\nH\001J\031\020\022\032\0020\n2\016\020\t\032\n \r*\004\030\0010\0230\023H\001J\031\020\024\032\0020\n2\016\020\t\032\n \r*\004\030\0010\0230\023H\001J\031\020\025\032\n \r*\004\030\0010\0230\0232\006\020\t\032\0020\nH\001J4\020\026\032(\022\f\022\n \r*\004\030\0010\0230\023 \r*\024\022\016\b\001\022\n \r*\004\030\0010\0230\023\030\0010\0270\027H\001¢\006\002\020\030J\t\020\031\032\0020\nH\001J\021\020\032\032\0020\0332\006\020\t\032\0020\nH\001J\021\020\034\032\n \r*\004\030\0010\0350\035H\001J\021\020\036\032\0020\0372\006\020\t\032\0020\nH\001J\021\020 \032\0020\n2\006\020\t\032\0020\nH\001J\021\020!\032\0020\"2\006\020\t\032\0020\nH\001J\b\020#\032\0020$H\027J\016\020%\032\b\022\004\022\0020$0&H\027J\t\020'\032\0020\nH\001J\021\020(\032\0020)2\006\020\t\032\0020\nH\001J\031\020*\032\n \r*\004\030\0010\0230\0232\006\020\t\032\0020\nH\001J\021\020+\032\0020\n2\006\020\t\032\0020\nH\001J\t\020,\032\0020-H\001J\t\020.\032\0020-H\001J\t\020/\032\0020-H\001J\t\0200\032\0020-H\001J\t\0201\032\0020-H\001J\t\0202\032\0020-H\001J\021\0203\032\0020-2\006\020\t\032\0020\nH\001J\021\0204\032\0020-2\006\020\t\032\0020\nH\001J\t\0205\032\0020-H\001J\t\0206\032\0020-H\001J\t\0207\032\0020-H\001J\021\0208\032\0020-2\006\020\t\032\0020\nH\001J\t\0209\032\0020-H\001J\031\020:\032\0020\0072\016\020\t\032\n \r*\004\030\0010;0;H\001J\031\020<\032\0020\0072\016\020\t\032\n \r*\004\030\0010=0=H\001J\t\020>\032\0020-H\001J!\020?\032\n \r*\004\030\0010\0350\0352\016\020\t\032\n \r*\004\030\0010\0350\035H\001J\020\020@\032\0020\0072\006\020A\032\0020\035H\027J)\020B\032\0020\0072\016\020\t\032\n \r*\004\030\0010C0C2\016\020\013\032\n \r*\004\030\0010$0$H\001J\036\020D\032\0020\0072\006\020E\032\0020C2\f\020F\032\b\022\004\022\0020$0&H\027J\031\020G\032\0020\0072\016\020\t\032\n \r*\004\030\0010;0;H\001J\031\020H\032\0020\0072\016\020\t\032\n \r*\004\030\0010=0=H\001R\016\020\003\032\0020\004X\004¢\006\002\n\000R\016\020\002\032\0020\001X\004¢\006\002\n\000¨\006I"}, d2 = {"Landroidx/room/AutoClosingRoomOpenHelper$KeepAliveCursor;", "Landroid/database/Cursor;", "delegate", "autoCloser", "Landroidx/room/AutoCloser;", "(Landroid/database/Cursor;Landroidx/room/AutoCloser;)V", "close", "", "copyStringToBuffer", "p0", "", "p1", "Landroid/database/CharArrayBuffer;", "kotlin.jvm.PlatformType", "deactivate", "getBlob", "", "getColumnCount", "getColumnIndex", "", "getColumnIndexOrThrow", "getColumnName", "getColumnNames", "", "()[Ljava/lang/String;", "getCount", "getDouble", "", "getExtras", "Landroid/os/Bundle;", "getFloat", "", "getInt", "getLong", "", "getNotificationUri", "Landroid/net/Uri;", "getNotificationUris", "", "getPosition", "getShort", "", "getString", "getType", "getWantsAllOnMoveCalls", "", "isAfterLast", "isBeforeFirst", "isClosed", "isFirst", "isLast", "isNull", "move", "moveToFirst", "moveToLast", "moveToNext", "moveToPosition", "moveToPrevious", "registerContentObserver", "Landroid/database/ContentObserver;", "registerDataSetObserver", "Landroid/database/DataSetObserver;", "requery", "respond", "setExtras", "extras", "setNotificationUri", "Landroid/content/ContentResolver;", "setNotificationUris", "cr", "uris", "unregisterContentObserver", "unregisterDataSetObserver", "room-runtime_release"}, k = 1, mv = {1, 7, 1}, xi = 48)
  private static final class KeepAliveCursor implements Cursor {
    private final AutoCloser autoCloser;
    
    private final Cursor delegate;
    
    public KeepAliveCursor(Cursor param1Cursor, AutoCloser param1AutoCloser) {
      this.delegate = param1Cursor;
      this.autoCloser = param1AutoCloser;
    }
    
    public void close() {
      this.delegate.close();
      this.autoCloser.decrementCountAndScheduleClose();
    }
    
    public void copyStringToBuffer(int param1Int, CharArrayBuffer param1CharArrayBuffer) {
      this.delegate.copyStringToBuffer(param1Int, param1CharArrayBuffer);
    }
    
    public void deactivate() {
      this.delegate.deactivate();
    }
    
    public byte[] getBlob(int param1Int) {
      return this.delegate.getBlob(param1Int);
    }
    
    public int getColumnCount() {
      return this.delegate.getColumnCount();
    }
    
    public int getColumnIndex(String param1String) {
      return this.delegate.getColumnIndex(param1String);
    }
    
    public int getColumnIndexOrThrow(String param1String) {
      return this.delegate.getColumnIndexOrThrow(param1String);
    }
    
    public String getColumnName(int param1Int) {
      return this.delegate.getColumnName(param1Int);
    }
    
    public String[] getColumnNames() {
      return this.delegate.getColumnNames();
    }
    
    public int getCount() {
      return this.delegate.getCount();
    }
    
    public double getDouble(int param1Int) {
      return this.delegate.getDouble(param1Int);
    }
    
    public Bundle getExtras() {
      return this.delegate.getExtras();
    }
    
    public float getFloat(int param1Int) {
      return this.delegate.getFloat(param1Int);
    }
    
    public int getInt(int param1Int) {
      return this.delegate.getInt(param1Int);
    }
    
    public long getLong(int param1Int) {
      return this.delegate.getLong(param1Int);
    }
    
    @RequiresApi(api = 19)
    public Uri getNotificationUri() {
      return SupportSQLiteCompat.Api19Impl.getNotificationUri(this.delegate);
    }
    
    @RequiresApi(api = 29)
    public List<Uri> getNotificationUris() {
      return SupportSQLiteCompat.Api29Impl.getNotificationUris(this.delegate);
    }
    
    public int getPosition() {
      return this.delegate.getPosition();
    }
    
    public short getShort(int param1Int) {
      return this.delegate.getShort(param1Int);
    }
    
    public String getString(int param1Int) {
      return this.delegate.getString(param1Int);
    }
    
    public int getType(int param1Int) {
      return this.delegate.getType(param1Int);
    }
    
    public boolean getWantsAllOnMoveCalls() {
      return this.delegate.getWantsAllOnMoveCalls();
    }
    
    public boolean isAfterLast() {
      return this.delegate.isAfterLast();
    }
    
    public boolean isBeforeFirst() {
      return this.delegate.isBeforeFirst();
    }
    
    public boolean isClosed() {
      return this.delegate.isClosed();
    }
    
    public boolean isFirst() {
      return this.delegate.isFirst();
    }
    
    public boolean isLast() {
      return this.delegate.isLast();
    }
    
    public boolean isNull(int param1Int) {
      return this.delegate.isNull(param1Int);
    }
    
    public boolean move(int param1Int) {
      return this.delegate.move(param1Int);
    }
    
    public boolean moveToFirst() {
      return this.delegate.moveToFirst();
    }
    
    public boolean moveToLast() {
      return this.delegate.moveToLast();
    }
    
    public boolean moveToNext() {
      return this.delegate.moveToNext();
    }
    
    public boolean moveToPosition(int param1Int) {
      return this.delegate.moveToPosition(param1Int);
    }
    
    public boolean moveToPrevious() {
      return this.delegate.moveToPrevious();
    }
    
    public void registerContentObserver(ContentObserver param1ContentObserver) {
      this.delegate.registerContentObserver(param1ContentObserver);
    }
    
    public void registerDataSetObserver(DataSetObserver param1DataSetObserver) {
      this.delegate.registerDataSetObserver(param1DataSetObserver);
    }
    
    public boolean requery() {
      return this.delegate.requery();
    }
    
    public Bundle respond(Bundle param1Bundle) {
      return this.delegate.respond(param1Bundle);
    }
    
    @RequiresApi(api = 23)
    public void setExtras(Bundle param1Bundle) {
      Intrinsics.checkNotNullParameter(param1Bundle, "extras");
      SupportSQLiteCompat.Api23Impl.setExtras(this.delegate, param1Bundle);
    }
    
    public void setNotificationUri(ContentResolver param1ContentResolver, Uri param1Uri) {
      this.delegate.setNotificationUri(param1ContentResolver, param1Uri);
    }
    
    @RequiresApi(api = 29)
    public void setNotificationUris(ContentResolver param1ContentResolver, List<? extends Uri> param1List) {
      Intrinsics.checkNotNullParameter(param1ContentResolver, "cr");
      Intrinsics.checkNotNullParameter(param1List, "uris");
      SupportSQLiteCompat.Api29Impl.setNotificationUris(this.delegate, param1ContentResolver, param1List);
    }
    
    public void unregisterContentObserver(ContentObserver param1ContentObserver) {
      this.delegate.unregisterContentObserver(param1ContentObserver);
    }
    
    public void unregisterDataSetObserver(DataSetObserver param1DataSetObserver) {
      this.delegate.unregisterDataSetObserver(param1DataSetObserver);
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\MagicAI - AI Art & Anime Art-dex2jar.jar!\androidx\room\AutoClosingRoomOpenHelper.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */