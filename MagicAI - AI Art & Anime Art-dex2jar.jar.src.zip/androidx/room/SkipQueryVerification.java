package androidx.room;

import java.lang.annotation.ElementType;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.lang.annotation.Target;
import kotlin.Metadata;

@Retention(RetentionPolicy.CLASS)
@Target({ElementType.TYPE, ElementType.METHOD})
@Metadata(d1 = {"\000\n\n\002\030\002\n\002\020\033\n\000\b\002\030\0002\0020\001B\000¨\006\002"}, d2 = {"Landroidx/room/SkipQueryVerification;", "", "room-common"}, k = 1, mv = {1, 7, 1}, xi = 48)
public @interface SkipQueryVerification {}


/* Location:              C:\soft\dex2jar-2.0\MagicAI - AI Art & Anime Art-dex2jar.jar!\androidx\room\SkipQueryVerification.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */