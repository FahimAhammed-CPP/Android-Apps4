package androidx.room;

import android.annotation.SuppressLint;
import android.app.ActivityManager;
import android.content.Context;
import android.content.Intent;
import android.database.Cursor;
import android.os.CancellationSignal;
import android.os.Looper;
import android.util.Log;
import androidx.annotation.CallSuper;
import androidx.annotation.IntRange;
import androidx.annotation.RestrictTo;
import androidx.annotation.WorkerThread;
import androidx.room.migration.AutoMigrationSpec;
import androidx.room.migration.Migration;
import androidx.sqlite.db.SimpleSQLiteQuery;
import androidx.sqlite.db.SupportSQLiteCompat;
import androidx.sqlite.db.SupportSQLiteDatabase;
import androidx.sqlite.db.SupportSQLiteOpenHelper;
import androidx.sqlite.db.SupportSQLiteQuery;
import androidx.sqlite.db.SupportSQLiteStatement;
import j$.util.DesugarCollections;
import java.io.File;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.BitSet;
import java.util.HashSet;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.TreeMap;
import java.util.concurrent.Callable;
import java.util.concurrent.Executor;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.locks.Lock;
import java.util.concurrent.locks.ReentrantReadWriteLock;
import kotlin.Metadata;
import kotlin.collections.CollectionsKt;
import kotlin.collections.MapsKt;
import kotlin.collections.SetsKt;
import kotlin.jvm.functions.Function1;
import kotlin.jvm.internal.DefaultConstructorMarker;
import kotlin.jvm.internal.Intrinsics;
import kotlin.jvm.internal.Lambda;

@Metadata(d1 = {"\000Ä\001\n\002\030\002\n\002\020\000\n\002\b\002\n\002\020\013\n\000\n\002\030\002\n\000\n\002\020%\n\002\030\002\n\002\030\002\n\002\b\005\n\002\020\016\n\002\b\002\n\002\030\002\n\000\n\002\030\002\n\002\b\002\n\002\030\002\n\002\b\b\n\002\020 \n\002\030\002\n\002\b\002\n\002\030\002\n\002\b\b\n\002\030\002\n\000\n\002\030\002\n\002\020\b\n\002\b\007\n\002\020\002\n\002\b\005\n\002\030\002\n\002\b\004\n\002\030\002\n\002\b\002\n\002\030\002\n\002\020$\n\000\n\002\030\002\n\002\b\002\n\002\020\"\n\002\b\r\n\002\030\002\n\002\030\002\n\000\n\002\030\002\n\000\n\002\020\021\n\002\b\003\n\002\030\002\n\000\n\002\030\002\n\002\b\r\b&\030\000 n2\0020\001:\007lmnopqrB\005¢\006\002\020\002J\b\0208\032\00209H\027J\b\020:\032\00209H\027J\b\020;\032\00209H\027J\b\020<\032\00209H'J\b\020=\032\00209H\026J\020\020>\032\0020?2\006\020@\032\0020\020H\026J\b\020A\032\0020\030H$J\020\020B\032\0020\0232\006\020C\032\0020DH$J\b\020E\032\00209H\027J*\020F\032\b\022\004\022\0020G0!2\032\020\007\032\026\022\f\022\n\022\006\b\001\022\0020\n0\t\022\004\022\0020\n0HH\027J\r\020I\032\0020JH\000¢\006\002\bKJ\026\020L\032\020\022\f\022\n\022\006\b\001\022\0020\n0\t0MH\027J\"\020N\032\034\022\b\022\006\022\002\b\0030\t\022\016\022\f\022\b\022\006\022\002\b\0030\t0!0HH\025J#\020O\032\004\030\001HP\"\004\b\000\020P2\f\020Q\032\b\022\004\022\002HP0\tH\026¢\006\002\020RJ\b\020S\032\0020\004H\026J\020\020T\032\002092\006\020U\032\0020DH\027J\b\020V\032\00209H\002J\b\020W\032\00209H\002J\020\020X\032\002092\006\020Y\032\0020%H\024J\034\020Z\032\0020[2\006\020Z\032\0020\\2\n\b\002\020]\032\004\030\0010^H\027J)\020Z\032\0020[2\006\020Z\032\0020\0202\022\020_\032\016\022\b\b\001\022\004\030\0010\001\030\0010`H\026¢\006\002\020aJ\020\020b\032\002092\006\020c\032\0020dH\026J!\020b\032\002He\"\004\b\000\020e2\f\020c\032\b\022\004\022\002He0fH\026¢\006\002\020gJ\b\020h\032\00209H\027J+\020i\032\004\030\001HP\"\004\b\000\020P2\f\020j\032\b\022\004\022\002HP0\t2\006\020'\032\0020\023H\002¢\006\002\020kR\016\020\003\032\0020\004X\016¢\006\002\n\000R\020\020\005\032\004\030\0010\006X\016¢\006\002\n\000R2\020\007\032\026\022\f\022\n\022\006\b\001\022\0020\n0\t\022\004\022\0020\n0\b8\004@\004X\016¢\006\016\n\000\032\004\b\013\020\f\"\004\b\r\020\016R\037\020\017\032\016\022\004\022\0020\020\022\004\022\0020\0010\b8G¢\006\b\n\000\032\004\b\021\020\fR\016\020\022\032\0020\023X.¢\006\002\n\000R\016\020\024\032\0020\025X.¢\006\002\n\000R\016\020\026\032\0020\025X.¢\006\002\n\000R\024\020\027\032\0020\030X\004¢\006\b\n\000\032\004\b\031\020\032R\024\020\033\032\0020\0048@X\004¢\006\006\032\004\b\034\020\035R\032\020\036\032\0020\0048VX\004¢\006\f\022\004\b\037\020\002\032\004\b\036\020\035R \020 \032\n\022\004\022\0020\"\030\0010!8\004@\004X\016¢\006\b\n\000\022\004\b#\020\002R\032\020$\032\004\030\0010%8\004@\004X\016¢\006\b\n\000\022\004\b&\020\002R\024\020'\032\0020\0238VX\004¢\006\006\032\004\b(\020)R\024\020*\032\0020\0258VX\004¢\006\006\032\004\b+\020,R\016\020-\032\0020.X\004¢\006\002\n\000R\031\020/\032\b\022\004\022\00201008G¢\006\b\n\000\032\004\b2\0203R\024\0204\032\0020\0258VX\004¢\006\006\032\004\b5\020,R\036\0206\032\022\022\b\022\006\022\002\b\0030\t\022\004\022\0020\0010\bX\004¢\006\002\n\000R\016\0207\032\0020\004X\016¢\006\002\n\000¨\006s"}, d2 = {"Landroidx/room/RoomDatabase;", "", "()V", "allowMainThreadQueries", "", "autoCloser", "Landroidx/room/AutoCloser;", "autoMigrationSpecs", "", "Ljava/lang/Class;", "Landroidx/room/migration/AutoMigrationSpec;", "getAutoMigrationSpecs", "()Ljava/util/Map;", "setAutoMigrationSpecs", "(Ljava/util/Map;)V", "backingFieldMap", "", "getBackingFieldMap", "internalOpenHelper", "Landroidx/sqlite/db/SupportSQLiteOpenHelper;", "internalQueryExecutor", "Ljava/util/concurrent/Executor;", "internalTransactionExecutor", "invalidationTracker", "Landroidx/room/InvalidationTracker;", "getInvalidationTracker", "()Landroidx/room/InvalidationTracker;", "isMainThread", "isMainThread$room_runtime_release", "()Z", "isOpen", "isOpen$annotations", "mCallbacks", "", "Landroidx/room/RoomDatabase$Callback;", "getMCallbacks$annotations", "mDatabase", "Landroidx/sqlite/db/SupportSQLiteDatabase;", "getMDatabase$annotations", "openHelper", "getOpenHelper", "()Landroidx/sqlite/db/SupportSQLiteOpenHelper;", "queryExecutor", "getQueryExecutor", "()Ljava/util/concurrent/Executor;", "readWriteLock", "Ljava/util/concurrent/locks/ReentrantReadWriteLock;", "suspendingTransactionId", "Ljava/lang/ThreadLocal;", "", "getSuspendingTransactionId", "()Ljava/lang/ThreadLocal;", "transactionExecutor", "getTransactionExecutor", "typeConverters", "writeAheadLoggingEnabled", "assertNotMainThread", "", "assertNotSuspendingTransaction", "beginTransaction", "clearAllTables", "close", "compileStatement", "Landroidx/sqlite/db/SupportSQLiteStatement;", "sql", "createInvalidationTracker", "createOpenHelper", "config", "Landroidx/room/DatabaseConfiguration;", "endTransaction", "getAutoMigrations", "Landroidx/room/migration/Migration;", "", "getCloseLock", "Ljava/util/concurrent/locks/Lock;", "getCloseLock$room_runtime_release", "getRequiredAutoMigrationSpecs", "", "getRequiredTypeConverters", "getTypeConverter", "T", "klass", "(Ljava/lang/Class;)Ljava/lang/Object;", "inTransaction", "init", "configuration", "internalBeginTransaction", "internalEndTransaction", "internalInitInvalidationTracker", "db", "query", "Landroid/database/Cursor;", "Landroidx/sqlite/db/SupportSQLiteQuery;", "signal", "Landroid/os/CancellationSignal;", "args", "", "(Ljava/lang/String;[Ljava/lang/Object;)Landroid/database/Cursor;", "runInTransaction", "body", "Ljava/lang/Runnable;", "V", "Ljava/util/concurrent/Callable;", "(Ljava/util/concurrent/Callable;)Ljava/lang/Object;", "setTransactionSuccessful", "unwrapOpenHelper", "clazz", "(Ljava/lang/Class;Landroidx/sqlite/db/SupportSQLiteOpenHelper;)Ljava/lang/Object;", "Builder", "Callback", "Companion", "JournalMode", "MigrationContainer", "PrepackagedDatabaseCallback", "QueryCallback", "room-runtime_release"}, k = 1, mv = {1, 7, 1}, xi = 48)
public abstract class RoomDatabase {
  public static final Companion Companion = new Companion(null);
  
  @RestrictTo({RestrictTo.Scope.LIBRARY_GROUP_PREFIX})
  public static final int MAX_BIND_PARAMETER_CNT = 999;
  
  private boolean allowMainThreadQueries;
  
  private AutoCloser autoCloser;
  
  @RestrictTo({RestrictTo.Scope.LIBRARY_GROUP})
  private Map<Class<? extends AutoMigrationSpec>, AutoMigrationSpec> autoMigrationSpecs = new LinkedHashMap<Class<? extends AutoMigrationSpec>, AutoMigrationSpec>();
  
  private final Map<String, Object> backingFieldMap;
  
  private SupportSQLiteOpenHelper internalOpenHelper;
  
  private Executor internalQueryExecutor;
  
  private Executor internalTransactionExecutor;
  
  private final InvalidationTracker invalidationTracker = createInvalidationTracker();
  
  @RestrictTo({RestrictTo.Scope.LIBRARY_GROUP_PREFIX})
  protected List<? extends Callback> mCallbacks;
  
  protected volatile SupportSQLiteDatabase mDatabase;
  
  private final ReentrantReadWriteLock readWriteLock = new ReentrantReadWriteLock();
  
  private final ThreadLocal<Integer> suspendingTransactionId = new ThreadLocal<Integer>();
  
  private final Map<Class<?>, Object> typeConverters;
  
  private boolean writeAheadLoggingEnabled;
  
  public RoomDatabase() {
    Map<String, Object> map = DesugarCollections.synchronizedMap(new LinkedHashMap<Object, Object>());
    Intrinsics.checkNotNullExpressionValue(map, "synchronizedMap(mutableMapOf())");
    this.backingFieldMap = map;
    this.typeConverters = new LinkedHashMap<Class<?>, Object>();
  }
  
  private final void internalBeginTransaction() {
    assertNotMainThread();
    SupportSQLiteDatabase supportSQLiteDatabase = getOpenHelper().getWritableDatabase();
    getInvalidationTracker().syncTriggers$room_runtime_release(supportSQLiteDatabase);
    if (supportSQLiteDatabase.isWriteAheadLoggingEnabled()) {
      supportSQLiteDatabase.beginTransactionNonExclusive();
      return;
    } 
    supportSQLiteDatabase.beginTransaction();
  }
  
  private final void internalEndTransaction() {
    getOpenHelper().getWritableDatabase().endTransaction();
    if (!inTransaction())
      getInvalidationTracker().refreshVersionsAsync(); 
  }
  
  private final <T> T unwrapOpenHelper(Class<T> paramClass, SupportSQLiteOpenHelper paramSupportSQLiteOpenHelper) {
    return (T)(paramClass.isInstance(paramSupportSQLiteOpenHelper) ? paramSupportSQLiteOpenHelper : (Object)((paramSupportSQLiteOpenHelper instanceof DelegatingOpenHelper) ? unwrapOpenHelper(paramClass, ((DelegatingOpenHelper)paramSupportSQLiteOpenHelper).getDelegate()) : null));
  }
  
  @RestrictTo({RestrictTo.Scope.LIBRARY_GROUP_PREFIX})
  public void assertNotMainThread() {
    if (this.allowMainThreadQueries)
      return; 
    if ((isMainThread$room_runtime_release() ^ true) != 0)
      return; 
    throw new IllegalStateException("Cannot access database on the main thread since it may potentially lock the UI for a long period of time.".toString());
  }
  
  @RestrictTo({RestrictTo.Scope.LIBRARY_GROUP})
  public void assertNotSuspendingTransaction() {
    boolean bool;
    if (inTransaction() || this.suspendingTransactionId.get() == null) {
      bool = true;
    } else {
      bool = false;
    } 
    if (bool)
      return; 
    throw new IllegalStateException("Cannot access database on a different coroutine context inherited from a suspending transaction.".toString());
  }
  
  public void beginTransaction() {
    assertNotMainThread();
    AutoCloser autoCloser = this.autoCloser;
    if (autoCloser == null) {
      internalBeginTransaction();
      return;
    } 
    autoCloser.executeRefCountingFunction(new RoomDatabase$beginTransaction$1());
  }
  
  @WorkerThread
  public abstract void clearAllTables();
  
  public void close() {
    if (isOpen()) {
      ReentrantReadWriteLock.WriteLock writeLock = this.readWriteLock.writeLock();
      Intrinsics.checkNotNullExpressionValue(writeLock, "readWriteLock.writeLock()");
      writeLock.lock();
      try {
        getInvalidationTracker().stopMultiInstanceInvalidation$room_runtime_release();
        getOpenHelper().close();
        return;
      } finally {
        writeLock.unlock();
      } 
    } 
  }
  
  public SupportSQLiteStatement compileStatement(String paramString) {
    Intrinsics.checkNotNullParameter(paramString, "sql");
    assertNotMainThread();
    assertNotSuspendingTransaction();
    return getOpenHelper().getWritableDatabase().compileStatement(paramString);
  }
  
  protected abstract InvalidationTracker createInvalidationTracker();
  
  protected abstract SupportSQLiteOpenHelper createOpenHelper(DatabaseConfiguration paramDatabaseConfiguration);
  
  public void endTransaction() {
    AutoCloser autoCloser = this.autoCloser;
    if (autoCloser == null) {
      internalEndTransaction();
      return;
    } 
    autoCloser.executeRefCountingFunction(new RoomDatabase$endTransaction$1());
  }
  
  protected final Map<Class<? extends AutoMigrationSpec>, AutoMigrationSpec> getAutoMigrationSpecs() {
    return this.autoMigrationSpecs;
  }
  
  @RestrictTo({RestrictTo.Scope.LIBRARY_GROUP})
  public List<Migration> getAutoMigrations(Map<Class<? extends AutoMigrationSpec>, AutoMigrationSpec> paramMap) {
    Intrinsics.checkNotNullParameter(paramMap, "autoMigrationSpecs");
    return CollectionsKt.emptyList();
  }
  
  @RestrictTo({RestrictTo.Scope.LIBRARY_GROUP})
  public final Map<String, Object> getBackingFieldMap() {
    return this.backingFieldMap;
  }
  
  public final Lock getCloseLock$room_runtime_release() {
    ReentrantReadWriteLock.ReadLock readLock = this.readWriteLock.readLock();
    Intrinsics.checkNotNullExpressionValue(readLock, "readWriteLock.readLock()");
    return readLock;
  }
  
  public InvalidationTracker getInvalidationTracker() {
    return this.invalidationTracker;
  }
  
  public SupportSQLiteOpenHelper getOpenHelper() {
    SupportSQLiteOpenHelper supportSQLiteOpenHelper2 = this.internalOpenHelper;
    SupportSQLiteOpenHelper supportSQLiteOpenHelper1 = supportSQLiteOpenHelper2;
    if (supportSQLiteOpenHelper2 == null) {
      Intrinsics.throwUninitializedPropertyAccessException("internalOpenHelper");
      supportSQLiteOpenHelper1 = null;
    } 
    return supportSQLiteOpenHelper1;
  }
  
  public Executor getQueryExecutor() {
    Executor executor2 = this.internalQueryExecutor;
    Executor executor1 = executor2;
    if (executor2 == null) {
      Intrinsics.throwUninitializedPropertyAccessException("internalQueryExecutor");
      executor1 = null;
    } 
    return executor1;
  }
  
  @RestrictTo({RestrictTo.Scope.LIBRARY_GROUP})
  public Set<Class<? extends AutoMigrationSpec>> getRequiredAutoMigrationSpecs() {
    return SetsKt.emptySet();
  }
  
  @RestrictTo({RestrictTo.Scope.LIBRARY_GROUP})
  protected Map<Class<?>, List<Class<?>>> getRequiredTypeConverters() {
    return MapsKt.emptyMap();
  }
  
  @RestrictTo({RestrictTo.Scope.LIBRARY_GROUP})
  public final ThreadLocal<Integer> getSuspendingTransactionId() {
    return this.suspendingTransactionId;
  }
  
  public Executor getTransactionExecutor() {
    Executor executor2 = this.internalTransactionExecutor;
    Executor executor1 = executor2;
    if (executor2 == null) {
      Intrinsics.throwUninitializedPropertyAccessException("internalTransactionExecutor");
      executor1 = null;
    } 
    return executor1;
  }
  
  public <T> T getTypeConverter(Class<T> paramClass) {
    Intrinsics.checkNotNullParameter(paramClass, "klass");
    return (T)this.typeConverters.get(paramClass);
  }
  
  public boolean inTransaction() {
    return getOpenHelper().getWritableDatabase().inTransaction();
  }
  
  @CallSuper
  public void init(DatabaseConfiguration paramDatabaseConfiguration) {
    Intrinsics.checkNotNullParameter(paramDatabaseConfiguration, "configuration");
    this.internalOpenHelper = createOpenHelper(paramDatabaseConfiguration);
    Set<Class<? extends AutoMigrationSpec>> set = getRequiredAutoMigrationSpecs();
    BitSet bitSet = new BitSet();
    Iterator<Class<? extends AutoMigrationSpec>> iterator = set.iterator();
    while (true) {
      StringBuilder stringBuilder;
      boolean bool = iterator.hasNext();
      int j = 1;
      byte b = -1;
      if (bool) {
        Class<? extends AutoMigrationSpec> clazz = iterator.next();
        int m = paramDatabaseConfiguration.autoMigrationSpecs.size() - 1;
        int k = b;
        if (m >= 0)
          for (k = m;; k = m) {
            m = k - 1;
            if (clazz.isAssignableFrom(paramDatabaseConfiguration.autoMigrationSpecs.get(k).getClass())) {
              bitSet.set(k);
              break;
            } 
            if (m < 0) {
              k = b;
              break;
            } 
          }  
        if (k < 0)
          j = 0; 
        if (j) {
          this.autoMigrationSpecs.put(clazz, paramDatabaseConfiguration.autoMigrationSpecs.get(k));
          continue;
        } 
        stringBuilder = new StringBuilder();
        stringBuilder.append("A required auto migration spec (");
        stringBuilder.append(clazz.getCanonicalName());
        stringBuilder.append(") is missing in the database configuration.");
        throw new IllegalArgumentException(stringBuilder.toString().toString());
      } 
      int i = ((DatabaseConfiguration)stringBuilder).autoMigrationSpecs.size() - 1;
      if (i >= 0)
        while (true) {
          j = i - 1;
          if (bitSet.get(i)) {
            if (j < 0)
              break; 
            i = j;
            continue;
          } 
          throw new IllegalArgumentException("Unexpected auto migration specs found. Annotate AutoMigrationSpec implementation with @ProvidedAutoMigrationSpec annotation or remove this spec from the builder.".toString());
        }  
      for (Migration migration : getAutoMigrations(this.autoMigrationSpecs)) {
        if (!((DatabaseConfiguration)stringBuilder).migrationContainer.contains(migration.startVersion, migration.endVersion))
          ((DatabaseConfiguration)stringBuilder).migrationContainer.addMigrations(new Migration[] { migration }); 
      } 
      SQLiteCopyOpenHelper sQLiteCopyOpenHelper = unwrapOpenHelper(SQLiteCopyOpenHelper.class, getOpenHelper());
      if (sQLiteCopyOpenHelper != null)
        sQLiteCopyOpenHelper.setDatabaseConfiguration((DatabaseConfiguration)stringBuilder); 
      AutoClosingRoomOpenHelper autoClosingRoomOpenHelper = unwrapOpenHelper(AutoClosingRoomOpenHelper.class, getOpenHelper());
      if (autoClosingRoomOpenHelper != null) {
        this.autoCloser = autoClosingRoomOpenHelper.autoCloser;
        getInvalidationTracker().setAutoCloser$room_runtime_release(autoClosingRoomOpenHelper.autoCloser);
      } 
      if (((DatabaseConfiguration)stringBuilder).journalMode == JournalMode.WRITE_AHEAD_LOGGING) {
        bool = true;
      } else {
        bool = false;
      } 
      getOpenHelper().setWriteAheadLoggingEnabled(bool);
      this.mCallbacks = ((DatabaseConfiguration)stringBuilder).callbacks;
      this.internalQueryExecutor = ((DatabaseConfiguration)stringBuilder).queryExecutor;
      this.internalTransactionExecutor = (Executor)new TransactionExecutor(((DatabaseConfiguration)stringBuilder).transactionExecutor);
      this.allowMainThreadQueries = ((DatabaseConfiguration)stringBuilder).allowMainThreadQueries;
      this.writeAheadLoggingEnabled = bool;
      if (((DatabaseConfiguration)stringBuilder).multiInstanceInvalidationServiceIntent != null)
        if (((DatabaseConfiguration)stringBuilder).name != null) {
          getInvalidationTracker().startMultiInstanceInvalidation$room_runtime_release(((DatabaseConfiguration)stringBuilder).context, ((DatabaseConfiguration)stringBuilder).name, ((DatabaseConfiguration)stringBuilder).multiInstanceInvalidationServiceIntent);
        } else {
          throw new IllegalArgumentException("Required value was null.".toString());
        }  
      Map<Class<?>, List<Class<?>>> map = getRequiredTypeConverters();
      BitSet bitSet1 = new BitSet();
      for (Map.Entry<Class<?>, List<Class<?>>> entry : map.entrySet()) {
        Class clazz = (Class)entry.getKey();
        label93: for (Class<?> clazz1 : (Iterable<Class<?>>)entry.getValue()) {
          i = ((DatabaseConfiguration)stringBuilder).typeConverters.size() - 1;
          if (i >= 0) {
            while (true) {
              j = i - 1;
              if (clazz1.isAssignableFrom(((DatabaseConfiguration)stringBuilder).typeConverters.get(i).getClass())) {
                bitSet1.set(i);
                break;
              } 
              if (j < 0)
                continue label93; 
              i = j;
            } 
          } else {
            i = -1;
          } 
          if (i >= 0) {
            j = 1;
          } else {
            j = 0;
          } 
          if (j != 0) {
            this.typeConverters.put(clazz1, ((DatabaseConfiguration)stringBuilder).typeConverters.get(i));
            continue;
          } 
          stringBuilder = new StringBuilder();
          stringBuilder.append("A required type converter (");
          stringBuilder.append(clazz1);
          stringBuilder.append(") for ");
          stringBuilder.append(clazz.getCanonicalName());
          stringBuilder.append(" is missing in the database configuration.");
          throw new IllegalArgumentException(stringBuilder.toString().toString());
        } 
      } 
      i = ((DatabaseConfiguration)stringBuilder).typeConverters.size() - 1;
      if (i >= 0) {
        while (true) {
          j = i - 1;
          if (bitSet1.get(i)) {
            if (j < 0)
              return; 
            i = j;
            continue;
          } 
          stringBuilder = ((DatabaseConfiguration)stringBuilder).typeConverters.get(i);
          StringBuilder stringBuilder1 = new StringBuilder();
          stringBuilder1.append("Unexpected type converter ");
          stringBuilder1.append(stringBuilder);
          stringBuilder1.append(". Annotate TypeConverter class with @ProvidedTypeConverter annotation or remove this converter from the builder.");
          throw new IllegalArgumentException(stringBuilder1.toString());
        } 
        break;
      } 
      return;
    } 
  }
  
  protected void internalInitInvalidationTracker(SupportSQLiteDatabase paramSupportSQLiteDatabase) {
    Intrinsics.checkNotNullParameter(paramSupportSQLiteDatabase, "db");
    getInvalidationTracker().internalInit$room_runtime_release(paramSupportSQLiteDatabase);
  }
  
  public final boolean isMainThread$room_runtime_release() {
    return (Looper.getMainLooper().getThread() == Thread.currentThread());
  }
  
  public boolean isOpen() {
    boolean bool;
    AutoCloser autoCloser = this.autoCloser;
    if (autoCloser != null) {
      bool = autoCloser.isActive();
    } else {
      SupportSQLiteDatabase supportSQLiteDatabase = this.mDatabase;
      if (supportSQLiteDatabase != null) {
        bool = supportSQLiteDatabase.isOpen();
      } else {
        supportSQLiteDatabase = null;
        return Intrinsics.areEqual(supportSQLiteDatabase, Boolean.TRUE);
      } 
    } 
    Boolean bool1 = Boolean.valueOf(bool);
    return Intrinsics.areEqual(bool1, Boolean.TRUE);
  }
  
  public final Cursor query(SupportSQLiteQuery paramSupportSQLiteQuery) {
    Intrinsics.checkNotNullParameter(paramSupportSQLiteQuery, "query");
    return query$default(this, paramSupportSQLiteQuery, null, 2, null);
  }
  
  public Cursor query(SupportSQLiteQuery paramSupportSQLiteQuery, CancellationSignal paramCancellationSignal) {
    Intrinsics.checkNotNullParameter(paramSupportSQLiteQuery, "query");
    assertNotMainThread();
    assertNotSuspendingTransaction();
    return (paramCancellationSignal != null) ? getOpenHelper().getWritableDatabase().query(paramSupportSQLiteQuery, paramCancellationSignal) : getOpenHelper().getWritableDatabase().query(paramSupportSQLiteQuery);
  }
  
  public Cursor query(String paramString, Object[] paramArrayOfObject) {
    Intrinsics.checkNotNullParameter(paramString, "query");
    return getOpenHelper().getWritableDatabase().query((SupportSQLiteQuery)new SimpleSQLiteQuery(paramString, paramArrayOfObject));
  }
  
  public <V> V runInTransaction(Callable<V> paramCallable) {
    Intrinsics.checkNotNullParameter(paramCallable, "body");
    beginTransaction();
    try {
      paramCallable = (Callable<V>)paramCallable.call();
      setTransactionSuccessful();
      return (V)paramCallable;
    } finally {
      endTransaction();
    } 
  }
  
  public void runInTransaction(Runnable paramRunnable) {
    Intrinsics.checkNotNullParameter(paramRunnable, "body");
    beginTransaction();
    try {
      paramRunnable.run();
      setTransactionSuccessful();
      return;
    } finally {
      endTransaction();
    } 
  }
  
  protected final void setAutoMigrationSpecs(Map<Class<? extends AutoMigrationSpec>, AutoMigrationSpec> paramMap) {
    Intrinsics.checkNotNullParameter(paramMap, "<set-?>");
    this.autoMigrationSpecs = paramMap;
  }
  
  public void setTransactionSuccessful() {
    getOpenHelper().getWritableDatabase().setTransactionSuccessful();
  }
  
  @Metadata(d1 = {"\000¦\001\n\002\030\002\n\000\n\002\030\002\n\002\020\000\n\000\n\002\030\002\n\000\n\002\030\002\n\000\n\002\020\016\n\002\b\002\n\002\020\013\n\002\b\002\n\002\030\002\n\000\n\002\020\t\n\000\n\002\020!\n\002\030\002\n\000\n\002\030\002\n\002\b\002\n\002\030\002\n\000\n\002\030\002\n\002\030\002\n\000\n\002\030\002\n\000\n\002\030\002\n\000\n\002\030\002\n\000\n\002\020#\n\002\020\b\n\002\b\002\n\002\030\002\n\000\n\002\030\002\n\000\n\002\030\002\n\000\n\002\030\002\n\002\b\n\n\002\020\021\n\002\030\002\n\002\b\017\n\002\020\025\n\002\b\013\b\026\030\000*\b\b\000\020\001*\0020\0022\0020\003B'\b\000\022\006\020\004\032\0020\005\022\f\020\006\032\b\022\004\022\0028\0000\007\022\b\020\b\032\004\030\0010\t¢\006\002\020\nJ\026\0203\032\b\022\004\022\0028\0000\0002\006\0204\032\0020\024H\026J\026\0205\032\b\022\004\022\0028\0000\0002\006\0206\032\0020\026H\026J'\0207\032\b\022\004\022\0028\0000\0002\022\0208\032\n\022\006\b\001\022\0020:09\"\0020:H\026¢\006\002\020;J\026\020<\032\b\022\004\022\0028\0000\0002\006\020=\032\0020\003H\026J\016\020\r\032\b\022\004\022\0028\0000\000H\026J\r\020>\032\0028\000H\026¢\006\002\020?J\026\020@\032\b\022\004\022\0028\0000\0002\006\020A\032\0020\tH\026J\036\020@\032\b\022\004\022\0028\0000\0002\006\020A\032\0020\t2\006\0206\032\0020*H\027J\026\020B\032\b\022\004\022\0028\0000\0002\006\020C\032\0020\031H\026J\036\020B\032\b\022\004\022\0028\0000\0002\006\020C\032\0020\0312\006\0206\032\0020*H\027J\034\020D\032\b\022\004\022\0028\0000\0002\f\020E\032\b\022\004\022\0020\0340\033H\027J$\020D\032\b\022\004\022\0028\0000\0002\f\020E\032\b\022\004\022\0020\0340\0332\006\0206\032\0020*H\027J\016\020F\032\b\022\004\022\0028\0000\000H\026J\016\020G\032\b\022\004\022\0028\0000\000H\026J\032\020H\032\b\022\004\022\0028\0000\0002\n\020I\032\0020J\"\0020%H\026J\016\020K\032\b\022\004\022\0028\0000\000H\026J\030\020L\032\b\022\004\022\0028\0000\0002\b\020\035\032\004\030\0010\036H\026J \020M\032\b\022\004\022\0028\0000\0002\b\b\001\020\020\032\0020\0212\006\020\016\032\0020\017H\027J\026\020N\032\b\022\004\022\0028\0000\0002\006\020\037\032\0020 H\026J\026\020O\032\b\022\004\022\0028\0000\0002\006\020P\032\0020(H\027J\036\020Q\032\b\022\004\022\0028\0000\0002\006\020+\032\0020,2\006\020R\032\0020.H\026J\026\020S\032\b\022\004\022\0028\0000\0002\006\020R\032\0020.H\026J\026\020T\032\b\022\004\022\0028\0000\0002\006\020R\032\0020.H\026R\016\020\013\032\0020\fX\016¢\006\002\n\000R\016\020\r\032\0020\fX\016¢\006\002\n\000R\020\020\016\032\004\030\0010\017X\016¢\006\002\n\000R\016\020\020\032\0020\021X\016¢\006\002\n\000R\024\020\022\032\b\022\004\022\0020\0240\023X\016¢\006\002\n\000R\024\020\025\032\b\022\004\022\0020\0260\023X\004¢\006\002\n\000R\016\020\004\032\0020\005X\004¢\006\002\n\000R\020\020\027\032\004\030\0010\tX\016¢\006\002\n\000R\020\020\030\032\004\030\0010\031X\016¢\006\002\n\000R\026\020\032\032\n\022\004\022\0020\034\030\0010\033X\016¢\006\002\n\000R\020\020\035\032\004\030\0010\036X\016¢\006\002\n\000R\016\020\037\032\0020 X\016¢\006\002\n\000R\024\020\006\032\b\022\004\022\0028\0000\007X\004¢\006\002\n\000R\016\020!\032\0020\"X\004¢\006\002\n\000R\026\020#\032\n\022\004\022\0020%\030\0010$X\016¢\006\002\n\000R\024\020&\032\b\022\004\022\0020%0$X\016¢\006\002\n\000R\020\020'\032\004\030\0010(X\016¢\006\002\n\000R\020\020\b\032\004\030\0010\tX\004¢\006\002\n\000R\020\020)\032\004\030\0010*X\016¢\006\002\n\000R\020\020+\032\004\030\0010,X\016¢\006\002\n\000R\020\020-\032\004\030\0010.X\016¢\006\002\n\000R\020\020/\032\004\030\0010.X\016¢\006\002\n\000R\016\0200\032\0020\fX\016¢\006\002\n\000R\020\0201\032\004\030\0010.X\016¢\006\002\n\000R\024\0202\032\b\022\004\022\0020\0030\023X\004¢\006\002\n\000¨\006U"}, d2 = {"Landroidx/room/RoomDatabase$Builder;", "T", "Landroidx/room/RoomDatabase;", "", "context", "Landroid/content/Context;", "klass", "Ljava/lang/Class;", "name", "", "(Landroid/content/Context;Ljava/lang/Class;Ljava/lang/String;)V", "allowDestructiveMigrationOnDowngrade", "", "allowMainThreadQueries", "autoCloseTimeUnit", "Ljava/util/concurrent/TimeUnit;", "autoCloseTimeout", "", "autoMigrationSpecs", "", "Landroidx/room/migration/AutoMigrationSpec;", "callbacks", "Landroidx/room/RoomDatabase$Callback;", "copyFromAssetPath", "copyFromFile", "Ljava/io/File;", "copyFromInputStream", "Ljava/util/concurrent/Callable;", "Ljava/io/InputStream;", "factory", "Landroidx/sqlite/db/SupportSQLiteOpenHelper$Factory;", "journalMode", "Landroidx/room/RoomDatabase$JournalMode;", "migrationContainer", "Landroidx/room/RoomDatabase$MigrationContainer;", "migrationStartAndEndVersions", "", "", "migrationsNotRequiredFrom", "multiInstanceInvalidationIntent", "Landroid/content/Intent;", "prepackagedDatabaseCallback", "Landroidx/room/RoomDatabase$PrepackagedDatabaseCallback;", "queryCallback", "Landroidx/room/RoomDatabase$QueryCallback;", "queryCallbackExecutor", "Ljava/util/concurrent/Executor;", "queryExecutor", "requireMigration", "transactionExecutor", "typeConverters", "addAutoMigrationSpec", "autoMigrationSpec", "addCallback", "callback", "addMigrations", "migrations", "", "Landroidx/room/migration/Migration;", "([Landroidx/room/migration/Migration;)Landroidx/room/RoomDatabase$Builder;", "addTypeConverter", "typeConverter", "build", "()Landroidx/room/RoomDatabase;", "createFromAsset", "databaseFilePath", "createFromFile", "databaseFile", "createFromInputStream", "inputStreamCallable", "enableMultiInstanceInvalidation", "fallbackToDestructiveMigration", "fallbackToDestructiveMigrationFrom", "startVersions", "", "fallbackToDestructiveMigrationOnDowngrade", "openHelperFactory", "setAutoCloseTimeout", "setJournalMode", "setMultiInstanceInvalidationServiceIntent", "invalidationServiceIntent", "setQueryCallback", "executor", "setQueryExecutor", "setTransactionExecutor", "room-runtime_release"}, k = 1, mv = {1, 7, 1}, xi = 48)
  public static class Builder<T extends RoomDatabase> {
    private boolean allowDestructiveMigrationOnDowngrade;
    
    private boolean allowMainThreadQueries;
    
    private TimeUnit autoCloseTimeUnit;
    
    private long autoCloseTimeout;
    
    private List<AutoMigrationSpec> autoMigrationSpecs;
    
    private final List<RoomDatabase.Callback> callbacks;
    
    private final Context context;
    
    private String copyFromAssetPath;
    
    private File copyFromFile;
    
    private Callable<InputStream> copyFromInputStream;
    
    private SupportSQLiteOpenHelper.Factory factory;
    
    private RoomDatabase.JournalMode journalMode;
    
    private final Class<T> klass;
    
    private final RoomDatabase.MigrationContainer migrationContainer;
    
    private Set<Integer> migrationStartAndEndVersions;
    
    private Set<Integer> migrationsNotRequiredFrom;
    
    private Intent multiInstanceInvalidationIntent;
    
    private final String name;
    
    private RoomDatabase.PrepackagedDatabaseCallback prepackagedDatabaseCallback;
    
    private RoomDatabase.QueryCallback queryCallback;
    
    private Executor queryCallbackExecutor;
    
    private Executor queryExecutor;
    
    private boolean requireMigration;
    
    private Executor transactionExecutor;
    
    private final List<Object> typeConverters;
    
    public Builder(Context param1Context, Class<T> param1Class, String param1String) {
      this.context = param1Context;
      this.klass = param1Class;
      this.name = param1String;
      this.callbacks = new ArrayList<RoomDatabase.Callback>();
      this.typeConverters = new ArrayList();
      this.autoMigrationSpecs = new ArrayList<AutoMigrationSpec>();
      this.journalMode = RoomDatabase.JournalMode.AUTOMATIC;
      this.requireMigration = true;
      this.autoCloseTimeout = -1L;
      this.migrationContainer = new RoomDatabase.MigrationContainer();
      this.migrationsNotRequiredFrom = new LinkedHashSet<Integer>();
    }
    
    public Builder<T> addAutoMigrationSpec(AutoMigrationSpec param1AutoMigrationSpec) {
      Intrinsics.checkNotNullParameter(param1AutoMigrationSpec, "autoMigrationSpec");
      this.autoMigrationSpecs.add(param1AutoMigrationSpec);
      return this;
    }
    
    public Builder<T> addCallback(RoomDatabase.Callback param1Callback) {
      Intrinsics.checkNotNullParameter(param1Callback, "callback");
      this.callbacks.add(param1Callback);
      return this;
    }
    
    public Builder<T> addMigrations(Migration... param1VarArgs) {
      Intrinsics.checkNotNullParameter(param1VarArgs, "migrations");
      if (this.migrationStartAndEndVersions == null)
        this.migrationStartAndEndVersions = new HashSet<Integer>(); 
      int j = param1VarArgs.length;
      for (int i = 0; i < j; i++) {
        Migration migration = param1VarArgs[i];
        Set<Integer> set = this.migrationStartAndEndVersions;
        Intrinsics.checkNotNull(set);
        set.add(Integer.valueOf(migration.startVersion));
        set = this.migrationStartAndEndVersions;
        Intrinsics.checkNotNull(set);
        set.add(Integer.valueOf(migration.endVersion));
      } 
      this.migrationContainer.addMigrations(Arrays.<Migration>copyOf(param1VarArgs, param1VarArgs.length));
      return this;
    }
    
    public Builder<T> addTypeConverter(Object param1Object) {
      Intrinsics.checkNotNullParameter(param1Object, "typeConverter");
      this.typeConverters.add(param1Object);
      return this;
    }
    
    public Builder<T> allowMainThreadQueries() {
      this.allowMainThreadQueries = true;
      return this;
    }
    
    public T build() {
      // Byte code:
      //   0: aload_0
      //   1: getfield queryExecutor : Ljava/util/concurrent/Executor;
      //   4: astore #8
      //   6: aload #8
      //   8: ifnonnull -> 38
      //   11: aload_0
      //   12: getfield transactionExecutor : Ljava/util/concurrent/Executor;
      //   15: ifnonnull -> 38
      //   18: invokestatic getIOThreadExecutor : ()Ljava/util/concurrent/Executor;
      //   21: astore #8
      //   23: aload_0
      //   24: aload #8
      //   26: putfield transactionExecutor : Ljava/util/concurrent/Executor;
      //   29: aload_0
      //   30: aload #8
      //   32: putfield queryExecutor : Ljava/util/concurrent/Executor;
      //   35: goto -> 72
      //   38: aload #8
      //   40: ifnull -> 59
      //   43: aload_0
      //   44: getfield transactionExecutor : Ljava/util/concurrent/Executor;
      //   47: ifnonnull -> 59
      //   50: aload_0
      //   51: aload #8
      //   53: putfield transactionExecutor : Ljava/util/concurrent/Executor;
      //   56: goto -> 72
      //   59: aload #8
      //   61: ifnonnull -> 72
      //   64: aload_0
      //   65: aload_0
      //   66: getfield transactionExecutor : Ljava/util/concurrent/Executor;
      //   69: putfield queryExecutor : Ljava/util/concurrent/Executor;
      //   72: aload_0
      //   73: getfield migrationStartAndEndVersions : Ljava/util/Set;
      //   76: astore #8
      //   78: iconst_1
      //   79: istore #4
      //   81: aload #8
      //   83: ifnull -> 186
      //   86: aload #8
      //   88: invokestatic checkNotNull : (Ljava/lang/Object;)V
      //   91: aload #8
      //   93: invokeinterface iterator : ()Ljava/util/Iterator;
      //   98: astore #8
      //   100: aload #8
      //   102: invokeinterface hasNext : ()Z
      //   107: ifeq -> 186
      //   110: aload #8
      //   112: invokeinterface next : ()Ljava/lang/Object;
      //   117: checkcast java/lang/Number
      //   120: invokevirtual intValue : ()I
      //   123: istore_1
      //   124: aload_0
      //   125: getfield migrationsNotRequiredFrom : Ljava/util/Set;
      //   128: iload_1
      //   129: invokestatic valueOf : (I)Ljava/lang/Integer;
      //   132: invokeinterface contains : (Ljava/lang/Object;)Z
      //   137: iconst_1
      //   138: ixor
      //   139: ifeq -> 145
      //   142: goto -> 100
      //   145: new java/lang/StringBuilder
      //   148: dup
      //   149: invokespecial <init> : ()V
      //   152: astore #8
      //   154: aload #8
      //   156: ldc_w 'Inconsistency detected. A Migration was supplied to addMigration(Migration... migrations) that has a start or end version equal to a start version supplied to fallbackToDestructiveMigrationFrom(int... startVersions). Start version: '
      //   159: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
      //   162: pop
      //   163: aload #8
      //   165: iload_1
      //   166: invokevirtual append : (I)Ljava/lang/StringBuilder;
      //   169: pop
      //   170: new java/lang/IllegalArgumentException
      //   173: dup
      //   174: aload #8
      //   176: invokevirtual toString : ()Ljava/lang/String;
      //   179: invokevirtual toString : ()Ljava/lang/String;
      //   182: invokespecial <init> : (Ljava/lang/String;)V
      //   185: athrow
      //   186: aload_0
      //   187: getfield factory : Landroidx/sqlite/db/SupportSQLiteOpenHelper$Factory;
      //   190: astore #9
      //   192: aload #9
      //   194: astore #8
      //   196: aload #9
      //   198: ifnonnull -> 210
      //   201: new androidx/sqlite/db/framework/FrameworkSQLiteOpenHelperFactory
      //   204: dup
      //   205: invokespecial <init> : ()V
      //   208: astore #8
      //   210: aload #8
      //   212: ifnull -> 485
      //   215: aload #8
      //   217: astore #9
      //   219: aload_0
      //   220: getfield autoCloseTimeout : J
      //   223: lconst_0
      //   224: lcmp
      //   225: ifle -> 332
      //   228: aload_0
      //   229: getfield name : Ljava/lang/String;
      //   232: ifnull -> 318
      //   235: aload_0
      //   236: getfield autoCloseTimeout : J
      //   239: lstore #5
      //   241: aload_0
      //   242: getfield autoCloseTimeUnit : Ljava/util/concurrent/TimeUnit;
      //   245: astore #9
      //   247: aload #9
      //   249: ifnull -> 304
      //   252: aload_0
      //   253: getfield queryExecutor : Ljava/util/concurrent/Executor;
      //   256: astore #10
      //   258: aload #10
      //   260: ifnull -> 290
      //   263: new androidx/room/AutoClosingRoomOpenHelperFactory
      //   266: dup
      //   267: aload #8
      //   269: new androidx/room/AutoCloser
      //   272: dup
      //   273: lload #5
      //   275: aload #9
      //   277: aload #10
      //   279: invokespecial <init> : (JLjava/util/concurrent/TimeUnit;Ljava/util/concurrent/Executor;)V
      //   282: invokespecial <init> : (Landroidx/sqlite/db/SupportSQLiteOpenHelper$Factory;Landroidx/room/AutoCloser;)V
      //   285: astore #9
      //   287: goto -> 332
      //   290: new java/lang/IllegalArgumentException
      //   293: dup
      //   294: ldc_w 'Required value was null.'
      //   297: invokevirtual toString : ()Ljava/lang/String;
      //   300: invokespecial <init> : (Ljava/lang/String;)V
      //   303: athrow
      //   304: new java/lang/IllegalArgumentException
      //   307: dup
      //   308: ldc_w 'Required value was null.'
      //   311: invokevirtual toString : ()Ljava/lang/String;
      //   314: invokespecial <init> : (Ljava/lang/String;)V
      //   317: athrow
      //   318: new java/lang/IllegalArgumentException
      //   321: dup
      //   322: ldc_w 'Cannot create auto-closing database for an in-memory database.'
      //   325: invokevirtual toString : ()Ljava/lang/String;
      //   328: invokespecial <init> : (Ljava/lang/String;)V
      //   331: athrow
      //   332: aload_0
      //   333: getfield copyFromAssetPath : Ljava/lang/String;
      //   336: astore #10
      //   338: aload #10
      //   340: ifnonnull -> 361
      //   343: aload_0
      //   344: getfield copyFromFile : Ljava/io/File;
      //   347: ifnonnull -> 361
      //   350: aload #9
      //   352: astore #8
      //   354: aload_0
      //   355: getfield copyFromInputStream : Ljava/util/concurrent/Callable;
      //   358: ifnull -> 488
      //   361: aload_0
      //   362: getfield name : Ljava/lang/String;
      //   365: ifnull -> 471
      //   368: aload #10
      //   370: ifnonnull -> 378
      //   373: iconst_0
      //   374: istore_1
      //   375: goto -> 380
      //   378: iconst_1
      //   379: istore_1
      //   380: aload_0
      //   381: getfield copyFromFile : Ljava/io/File;
      //   384: astore #8
      //   386: aload #8
      //   388: ifnonnull -> 396
      //   391: iconst_0
      //   392: istore_2
      //   393: goto -> 398
      //   396: iconst_1
      //   397: istore_2
      //   398: aload_0
      //   399: getfield copyFromInputStream : Ljava/util/concurrent/Callable;
      //   402: astore #11
      //   404: aload #11
      //   406: ifnonnull -> 414
      //   409: iconst_0
      //   410: istore_3
      //   411: goto -> 416
      //   414: iconst_1
      //   415: istore_3
      //   416: iload_1
      //   417: iload_2
      //   418: iadd
      //   419: iload_3
      //   420: iadd
      //   421: iconst_1
      //   422: if_icmpne -> 431
      //   425: iload #4
      //   427: istore_1
      //   428: goto -> 433
      //   431: iconst_0
      //   432: istore_1
      //   433: iload_1
      //   434: ifeq -> 457
      //   437: new androidx/room/SQLiteCopyOpenHelperFactory
      //   440: dup
      //   441: aload #10
      //   443: aload #8
      //   445: aload #11
      //   447: aload #9
      //   449: invokespecial <init> : (Ljava/lang/String;Ljava/io/File;Ljava/util/concurrent/Callable;Landroidx/sqlite/db/SupportSQLiteOpenHelper$Factory;)V
      //   452: astore #8
      //   454: goto -> 488
      //   457: new java/lang/IllegalArgumentException
      //   460: dup
      //   461: ldc_w 'More than one of createFromAsset(), createFromInputStream(), and createFromFile() were called on this Builder, but the database can only be created using one of the three configurations.'
      //   464: invokevirtual toString : ()Ljava/lang/String;
      //   467: invokespecial <init> : (Ljava/lang/String;)V
      //   470: athrow
      //   471: new java/lang/IllegalArgumentException
      //   474: dup
      //   475: ldc_w 'Cannot create from asset or file for an in-memory database.'
      //   478: invokevirtual toString : ()Ljava/lang/String;
      //   481: invokespecial <init> : (Ljava/lang/String;)V
      //   484: athrow
      //   485: aconst_null
      //   486: astore #8
      //   488: aload #8
      //   490: ifnull -> 749
      //   493: aload_0
      //   494: getfield queryCallback : Landroidx/room/RoomDatabase$QueryCallback;
      //   497: astore #9
      //   499: aload #9
      //   501: ifnull -> 566
      //   504: aload_0
      //   505: getfield queryCallbackExecutor : Ljava/util/concurrent/Executor;
      //   508: astore #10
      //   510: aload #10
      //   512: ifnull -> 552
      //   515: aload #9
      //   517: ifnull -> 538
      //   520: new androidx/room/QueryInterceptorOpenHelperFactory
      //   523: dup
      //   524: aload #8
      //   526: aload #10
      //   528: aload #9
      //   530: invokespecial <init> : (Landroidx/sqlite/db/SupportSQLiteOpenHelper$Factory;Ljava/util/concurrent/Executor;Landroidx/room/RoomDatabase$QueryCallback;)V
      //   533: astore #8
      //   535: goto -> 566
      //   538: new java/lang/IllegalArgumentException
      //   541: dup
      //   542: ldc_w 'Required value was null.'
      //   545: invokevirtual toString : ()Ljava/lang/String;
      //   548: invokespecial <init> : (Ljava/lang/String;)V
      //   551: athrow
      //   552: new java/lang/IllegalArgumentException
      //   555: dup
      //   556: ldc_w 'Required value was null.'
      //   559: invokevirtual toString : ()Ljava/lang/String;
      //   562: invokespecial <init> : (Ljava/lang/String;)V
      //   565: athrow
      //   566: aload_0
      //   567: getfield context : Landroid/content/Context;
      //   570: astore #9
      //   572: aload_0
      //   573: getfield name : Ljava/lang/String;
      //   576: astore #10
      //   578: aload_0
      //   579: getfield migrationContainer : Landroidx/room/RoomDatabase$MigrationContainer;
      //   582: astore #11
      //   584: aload_0
      //   585: getfield callbacks : Ljava/util/List;
      //   588: astore #12
      //   590: aload_0
      //   591: getfield allowMainThreadQueries : Z
      //   594: istore #7
      //   596: aload_0
      //   597: getfield journalMode : Landroidx/room/RoomDatabase$JournalMode;
      //   600: aload #9
      //   602: invokevirtual resolve$room_runtime_release : (Landroid/content/Context;)Landroidx/room/RoomDatabase$JournalMode;
      //   605: astore #13
      //   607: aload_0
      //   608: getfield queryExecutor : Ljava/util/concurrent/Executor;
      //   611: astore #14
      //   613: aload #14
      //   615: ifnull -> 735
      //   618: aload_0
      //   619: getfield transactionExecutor : Ljava/util/concurrent/Executor;
      //   622: astore #15
      //   624: aload #15
      //   626: ifnull -> 721
      //   629: new androidx/room/DatabaseConfiguration
      //   632: dup
      //   633: aload #9
      //   635: aload #10
      //   637: aload #8
      //   639: aload #11
      //   641: aload #12
      //   643: iload #7
      //   645: aload #13
      //   647: aload #14
      //   649: aload #15
      //   651: aload_0
      //   652: getfield multiInstanceInvalidationIntent : Landroid/content/Intent;
      //   655: aload_0
      //   656: getfield requireMigration : Z
      //   659: aload_0
      //   660: getfield allowDestructiveMigrationOnDowngrade : Z
      //   663: aload_0
      //   664: getfield migrationsNotRequiredFrom : Ljava/util/Set;
      //   667: aload_0
      //   668: getfield copyFromAssetPath : Ljava/lang/String;
      //   671: aload_0
      //   672: getfield copyFromFile : Ljava/io/File;
      //   675: aload_0
      //   676: getfield copyFromInputStream : Ljava/util/concurrent/Callable;
      //   679: aload_0
      //   680: getfield prepackagedDatabaseCallback : Landroidx/room/RoomDatabase$PrepackagedDatabaseCallback;
      //   683: aload_0
      //   684: getfield typeConverters : Ljava/util/List;
      //   687: aload_0
      //   688: getfield autoMigrationSpecs : Ljava/util/List;
      //   691: invokespecial <init> : (Landroid/content/Context;Ljava/lang/String;Landroidx/sqlite/db/SupportSQLiteOpenHelper$Factory;Landroidx/room/RoomDatabase$MigrationContainer;Ljava/util/List;ZLandroidx/room/RoomDatabase$JournalMode;Ljava/util/concurrent/Executor;Ljava/util/concurrent/Executor;Landroid/content/Intent;ZZLjava/util/Set;Ljava/lang/String;Ljava/io/File;Ljava/util/concurrent/Callable;Landroidx/room/RoomDatabase$PrepackagedDatabaseCallback;Ljava/util/List;Ljava/util/List;)V
      //   694: astore #8
      //   696: aload_0
      //   697: getfield klass : Ljava/lang/Class;
      //   700: ldc_w '_Impl'
      //   703: invokestatic getGeneratedImplementation : (Ljava/lang/Class;Ljava/lang/String;)Ljava/lang/Object;
      //   706: checkcast androidx/room/RoomDatabase
      //   709: astore #9
      //   711: aload #9
      //   713: aload #8
      //   715: invokevirtual init : (Landroidx/room/DatabaseConfiguration;)V
      //   718: aload #9
      //   720: areturn
      //   721: new java/lang/IllegalArgumentException
      //   724: dup
      //   725: ldc_w 'Required value was null.'
      //   728: invokevirtual toString : ()Ljava/lang/String;
      //   731: invokespecial <init> : (Ljava/lang/String;)V
      //   734: athrow
      //   735: new java/lang/IllegalArgumentException
      //   738: dup
      //   739: ldc_w 'Required value was null.'
      //   742: invokevirtual toString : ()Ljava/lang/String;
      //   745: invokespecial <init> : (Ljava/lang/String;)V
      //   748: athrow
      //   749: new java/lang/IllegalArgumentException
      //   752: dup
      //   753: ldc_w 'Required value was null.'
      //   756: invokevirtual toString : ()Ljava/lang/String;
      //   759: invokespecial <init> : (Ljava/lang/String;)V
      //   762: athrow
    }
    
    public Builder<T> createFromAsset(String param1String) {
      Intrinsics.checkNotNullParameter(param1String, "databaseFilePath");
      this.copyFromAssetPath = param1String;
      return this;
    }
    
    @SuppressLint({"BuilderSetStyle"})
    public Builder<T> createFromAsset(String param1String, RoomDatabase.PrepackagedDatabaseCallback param1PrepackagedDatabaseCallback) {
      Intrinsics.checkNotNullParameter(param1String, "databaseFilePath");
      Intrinsics.checkNotNullParameter(param1PrepackagedDatabaseCallback, "callback");
      this.prepackagedDatabaseCallback = param1PrepackagedDatabaseCallback;
      this.copyFromAssetPath = param1String;
      return this;
    }
    
    public Builder<T> createFromFile(File param1File) {
      Intrinsics.checkNotNullParameter(param1File, "databaseFile");
      this.copyFromFile = param1File;
      return this;
    }
    
    @SuppressLint({"BuilderSetStyle", "StreamFiles"})
    public Builder<T> createFromFile(File param1File, RoomDatabase.PrepackagedDatabaseCallback param1PrepackagedDatabaseCallback) {
      Intrinsics.checkNotNullParameter(param1File, "databaseFile");
      Intrinsics.checkNotNullParameter(param1PrepackagedDatabaseCallback, "callback");
      this.prepackagedDatabaseCallback = param1PrepackagedDatabaseCallback;
      this.copyFromFile = param1File;
      return this;
    }
    
    @SuppressLint({"BuilderSetStyle"})
    public Builder<T> createFromInputStream(Callable<InputStream> param1Callable) {
      Intrinsics.checkNotNullParameter(param1Callable, "inputStreamCallable");
      this.copyFromInputStream = param1Callable;
      return this;
    }
    
    @SuppressLint({"BuilderSetStyle", "LambdaLast"})
    public Builder<T> createFromInputStream(Callable<InputStream> param1Callable, RoomDatabase.PrepackagedDatabaseCallback param1PrepackagedDatabaseCallback) {
      Intrinsics.checkNotNullParameter(param1Callable, "inputStreamCallable");
      Intrinsics.checkNotNullParameter(param1PrepackagedDatabaseCallback, "callback");
      this.prepackagedDatabaseCallback = param1PrepackagedDatabaseCallback;
      this.copyFromInputStream = param1Callable;
      return this;
    }
    
    public Builder<T> enableMultiInstanceInvalidation() {
      Intent intent;
      if (this.name != null) {
        intent = new Intent(this.context, MultiInstanceInvalidationService.class);
      } else {
        intent = null;
      } 
      this.multiInstanceInvalidationIntent = intent;
      return this;
    }
    
    public Builder<T> fallbackToDestructiveMigration() {
      this.requireMigration = false;
      this.allowDestructiveMigrationOnDowngrade = true;
      return this;
    }
    
    public Builder<T> fallbackToDestructiveMigrationFrom(int... param1VarArgs) {
      Intrinsics.checkNotNullParameter(param1VarArgs, "startVersions");
      int j = param1VarArgs.length;
      for (int i = 0; i < j; i++) {
        int k = param1VarArgs[i];
        this.migrationsNotRequiredFrom.add(Integer.valueOf(k));
      } 
      return this;
    }
    
    public Builder<T> fallbackToDestructiveMigrationOnDowngrade() {
      this.requireMigration = true;
      this.allowDestructiveMigrationOnDowngrade = true;
      return this;
    }
    
    public Builder<T> openHelperFactory(SupportSQLiteOpenHelper.Factory param1Factory) {
      this.factory = param1Factory;
      return this;
    }
    
    @ExperimentalRoomApi
    public Builder<T> setAutoCloseTimeout(@IntRange(from = 0L) long param1Long, TimeUnit param1TimeUnit) {
      boolean bool;
      Intrinsics.checkNotNullParameter(param1TimeUnit, "autoCloseTimeUnit");
      if (param1Long >= 0L) {
        bool = true;
      } else {
        bool = false;
      } 
      if (bool) {
        this.autoCloseTimeout = param1Long;
        this.autoCloseTimeUnit = param1TimeUnit;
        return this;
      } 
      throw new IllegalArgumentException("autoCloseTimeout must be >= 0".toString());
    }
    
    public Builder<T> setJournalMode(RoomDatabase.JournalMode param1JournalMode) {
      Intrinsics.checkNotNullParameter(param1JournalMode, "journalMode");
      this.journalMode = param1JournalMode;
      return this;
    }
    
    @ExperimentalRoomApi
    public Builder<T> setMultiInstanceInvalidationServiceIntent(Intent param1Intent) {
      Intrinsics.checkNotNullParameter(param1Intent, "invalidationServiceIntent");
      if (this.name == null)
        param1Intent = null; 
      this.multiInstanceInvalidationIntent = param1Intent;
      return this;
    }
    
    public Builder<T> setQueryCallback(RoomDatabase.QueryCallback param1QueryCallback, Executor param1Executor) {
      Intrinsics.checkNotNullParameter(param1QueryCallback, "queryCallback");
      Intrinsics.checkNotNullParameter(param1Executor, "executor");
      this.queryCallback = param1QueryCallback;
      this.queryCallbackExecutor = param1Executor;
      return this;
    }
    
    public Builder<T> setQueryExecutor(Executor param1Executor) {
      Intrinsics.checkNotNullParameter(param1Executor, "executor");
      this.queryExecutor = param1Executor;
      return this;
    }
    
    public Builder<T> setTransactionExecutor(Executor param1Executor) {
      Intrinsics.checkNotNullParameter(param1Executor, "executor");
      this.transactionExecutor = param1Executor;
      return this;
    }
  }
  
  @Metadata(d1 = {"\000\032\n\002\030\002\n\002\020\000\n\002\b\002\n\002\020\002\n\000\n\002\030\002\n\002\b\003\b&\030\0002\0020\001B\005¢\006\002\020\002J\020\020\003\032\0020\0042\006\020\005\032\0020\006H\026J\020\020\007\032\0020\0042\006\020\005\032\0020\006H\026J\020\020\b\032\0020\0042\006\020\005\032\0020\006H\026¨\006\t"}, d2 = {"Landroidx/room/RoomDatabase$Callback;", "", "()V", "onCreate", "", "db", "Landroidx/sqlite/db/SupportSQLiteDatabase;", "onDestructiveMigration", "onOpen", "room-runtime_release"}, k = 1, mv = {1, 7, 1}, xi = 48)
  public static abstract class Callback {
    public void onCreate(SupportSQLiteDatabase param1SupportSQLiteDatabase) {
      Intrinsics.checkNotNullParameter(param1SupportSQLiteDatabase, "db");
    }
    
    public void onDestructiveMigration(SupportSQLiteDatabase param1SupportSQLiteDatabase) {
      Intrinsics.checkNotNullParameter(param1SupportSQLiteDatabase, "db");
    }
    
    public void onOpen(SupportSQLiteDatabase param1SupportSQLiteDatabase) {
      Intrinsics.checkNotNullParameter(param1SupportSQLiteDatabase, "db");
    }
  }
  
  @Metadata(d1 = {"\000\022\n\002\030\002\n\002\020\000\n\002\b\002\n\002\020\b\n\000\b\003\030\0002\0020\001B\007\b\002¢\006\002\020\002R\020\020\003\032\0020\0048\006XT¢\006\002\n\000¨\006\005"}, d2 = {"Landroidx/room/RoomDatabase$Companion;", "", "()V", "MAX_BIND_PARAMETER_CNT", "", "room-runtime_release"}, k = 1, mv = {1, 7, 1}, xi = 48)
  public static final class Companion {
    private Companion() {}
  }
  
  @Metadata(d1 = {"\000\"\n\002\030\002\n\002\020\020\n\002\b\002\n\002\020\013\n\000\n\002\030\002\n\002\b\002\n\002\030\002\n\002\b\005\b\001\030\0002\b\022\004\022\0020\0000\001B\007\b\002¢\006\002\020\002J\020\020\003\032\0020\0042\006\020\005\032\0020\006H\002J\025\020\007\032\0020\0002\006\020\b\032\0020\tH\000¢\006\002\b\nj\002\b\013j\002\b\fj\002\b\r¨\006\016"}, d2 = {"Landroidx/room/RoomDatabase$JournalMode;", "", "(Ljava/lang/String;I)V", "isLowRamDevice", "", "activityManager", "Landroid/app/ActivityManager;", "resolve", "context", "Landroid/content/Context;", "resolve$room_runtime_release", "AUTOMATIC", "TRUNCATE", "WRITE_AHEAD_LOGGING", "room-runtime_release"}, k = 1, mv = {1, 7, 1}, xi = 48)
  public enum JournalMode {
    AUTOMATIC, TRUNCATE, WRITE_AHEAD_LOGGING;
    
    static {
    
    }
    
    private final boolean isLowRamDevice(ActivityManager param1ActivityManager) {
      return SupportSQLiteCompat.Api19Impl.isLowRamDevice(param1ActivityManager);
    }
    
    public final JournalMode resolve$room_runtime_release(Context param1Context) {
      Intrinsics.checkNotNullParameter(param1Context, "context");
      if (this != AUTOMATIC)
        return this; 
      Object object = param1Context.getSystemService("activity");
      Intrinsics.checkNotNull(object, "null cannot be cast to non-null type android.app.ActivityManager");
      return !isLowRamDevice((ActivityManager)object) ? WRITE_AHEAD_LOGGING : TRUNCATE;
    }
  }
  
  @Metadata(d1 = {"\000H\n\002\030\002\n\002\020\000\n\002\b\002\n\002\020%\n\002\020\b\n\002\030\002\n\002\030\002\n\000\n\002\020\002\n\002\b\002\n\002\020\021\n\000\n\002\020 \n\000\n\002\020\013\n\002\b\007\n\002\020!\n\002\b\002\n\002\020$\n\000\b\026\030\0002\0020\001B\005¢\006\002\020\002J\020\020\b\032\0020\t2\006\020\n\032\0020\007H\002J!\020\013\032\0020\t2\022\020\003\032\n\022\006\b\001\022\0020\0070\f\"\0020\007H\026¢\006\002\020\rJ\026\020\013\032\0020\t2\f\020\003\032\b\022\004\022\0020\0070\016H\026J\026\020\017\032\0020\0202\006\020\021\032\0020\0052\006\020\022\032\0020\005J \020\023\032\n\022\004\022\0020\007\030\0010\0162\006\020\024\032\0020\0052\006\020\025\032\0020\005H\026J6\020\026\032\n\022\004\022\0020\007\030\0010\0162\f\020\027\032\b\022\004\022\0020\0070\0302\006\020\031\032\0020\0202\006\020\024\032\0020\0052\006\020\025\032\0020\005H\002J \020\032\032\032\022\004\022\0020\005\022\020\022\016\022\004\022\0020\005\022\004\022\0020\0070\0330\033H\026R&\020\003\032\032\022\004\022\0020\005\022\020\022\016\022\004\022\0020\005\022\004\022\0020\0070\0060\004X\004¢\006\002\n\000¨\006\034"}, d2 = {"Landroidx/room/RoomDatabase$MigrationContainer;", "", "()V", "migrations", "", "", "Ljava/util/TreeMap;", "Landroidx/room/migration/Migration;", "addMigration", "", "migration", "addMigrations", "", "([Landroidx/room/migration/Migration;)V", "", "contains", "", "startVersion", "endVersion", "findMigrationPath", "start", "end", "findUpMigrationPath", "result", "", "upgrade", "getMigrations", "", "room-runtime_release"}, k = 1, mv = {1, 7, 1}, xi = 48)
  public static class MigrationContainer {
    private final Map<Integer, TreeMap<Integer, Migration>> migrations = new LinkedHashMap<Integer, TreeMap<Integer, Migration>>();
    
    private final void addMigration(Migration param1Migration) {
      int i = param1Migration.startVersion;
      int j = param1Migration.endVersion;
      Map<Integer, TreeMap<Integer, Migration>> map = this.migrations;
      Integer integer = Integer.valueOf(i);
      TreeMap<Object, Object> treeMap2 = (TreeMap<Object, Object>)map.get(integer);
      TreeMap<Object, Object> treeMap1 = treeMap2;
      if (treeMap2 == null) {
        treeMap1 = new TreeMap<Object, Object>();
        map.put(integer, treeMap1);
      } 
      treeMap1 = treeMap1;
      if (treeMap1.containsKey(Integer.valueOf(j))) {
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("Overriding migration ");
        stringBuilder.append(treeMap1.get(Integer.valueOf(j)));
        stringBuilder.append(" with ");
        stringBuilder.append(param1Migration);
        Log.w("ROOM", stringBuilder.toString());
      } 
      treeMap1.put(Integer.valueOf(j), param1Migration);
    }
    
    private final List<Migration> findUpMigrationPath(List<Migration> param1List, boolean param1Boolean, int param1Int1, int param1Int2) {
      while (true) {
        boolean bool1;
        boolean bool2 = true;
        if (param1Boolean ? (param1Int1 < param1Int2) : (param1Int1 > param1Int2)) {
          bool1 = true;
        } else {
          bool1 = false;
        } 
        if (bool1) {
          Set set;
          TreeMap treeMap = this.migrations.get(Integer.valueOf(param1Int1));
          if (treeMap == null)
            return null; 
          if (param1Boolean) {
            set = treeMap.descendingKeySet();
          } else {
            set = treeMap.keySet();
          } 
          Iterator iterator = set.iterator();
          while (true) {
            while (true)
              break; 
            if (bool1) {
              treeMap = (TreeMap)treeMap.get(set);
              Intrinsics.checkNotNull(treeMap);
              param1List.add(treeMap);
              param1Int1 = set.intValue();
              bool1 = bool2;
              break;
            } 
          } 
          if (!bool1)
            return null; 
          continue;
        } 
        return param1List;
      } 
    }
    
    public void addMigrations(List<? extends Migration> param1List) {
      Intrinsics.checkNotNullParameter(param1List, "migrations");
      Iterator<? extends Migration> iterator = param1List.iterator();
      while (iterator.hasNext())
        addMigration(iterator.next()); 
    }
    
    public void addMigrations(Migration... param1VarArgs) {
      Intrinsics.checkNotNullParameter(param1VarArgs, "migrations");
      int j = param1VarArgs.length;
      for (int i = 0; i < j; i++)
        addMigration(param1VarArgs[i]); 
    }
    
    public final boolean contains(int param1Int1, int param1Int2) {
      Map<Integer, Map<Integer, Migration>> map = getMigrations();
      if (map.containsKey(Integer.valueOf(param1Int1))) {
        Map<Integer, Map<Integer, Migration>> map1 = (Map)map.get(Integer.valueOf(param1Int1));
        map = map1;
        if (map1 == null)
          map = MapsKt.emptyMap(); 
        return map.containsKey(Integer.valueOf(param1Int2));
      } 
      return false;
    }
    
    public List<Migration> findMigrationPath(int param1Int1, int param1Int2) {
      boolean bool;
      if (param1Int1 == param1Int2)
        return CollectionsKt.emptyList(); 
      if (param1Int2 > param1Int1) {
        bool = true;
      } else {
        bool = false;
      } 
      return findUpMigrationPath(new ArrayList<Migration>(), bool, param1Int1, param1Int2);
    }
    
    public Map<Integer, Map<Integer, Migration>> getMigrations() {
      return (Map)this.migrations;
    }
  }
  
  @Metadata(d1 = {"\000\030\n\002\030\002\n\002\020\000\n\002\b\002\n\002\020\002\n\000\n\002\030\002\n\000\b&\030\0002\0020\001B\005¢\006\002\020\002J\020\020\003\032\0020\0042\006\020\005\032\0020\006H\026¨\006\007"}, d2 = {"Landroidx/room/RoomDatabase$PrepackagedDatabaseCallback;", "", "()V", "onOpenPrepackagedDatabase", "", "db", "Landroidx/sqlite/db/SupportSQLiteDatabase;", "room-runtime_release"}, k = 1, mv = {1, 7, 1}, xi = 48)
  public static abstract class PrepackagedDatabaseCallback {
    public void onOpenPrepackagedDatabase(SupportSQLiteDatabase param1SupportSQLiteDatabase) {
      Intrinsics.checkNotNullParameter(param1SupportSQLiteDatabase, "db");
    }
  }
  
  @Metadata(d1 = {"\000\034\n\002\030\002\n\002\020\000\n\000\n\002\020\002\n\000\n\002\020\016\n\000\n\002\020 \n\000\bf\030\0002\0020\001J \020\002\032\0020\0032\006\020\004\032\0020\0052\016\020\006\032\n\022\006\022\004\030\0010\0010\007H&ø\001\000\002\006\n\004\b!0\001¨\006\bÀ\006\001"}, d2 = {"Landroidx/room/RoomDatabase$QueryCallback;", "", "onQuery", "", "sqlQuery", "", "bindArgs", "", "room-runtime_release"}, k = 1, mv = {1, 7, 1}, xi = 48)
  public static interface QueryCallback {
    void onQuery(String param1String, List<? extends Object> param1List);
  }
  
  @Metadata(d1 = {"\000\016\n\000\n\002\020\000\n\000\n\002\030\002\n\000\020\000\032\004\030\0010\0012\006\020\002\032\0020\003H\n¢\006\002\b\004"}, d2 = {"<anonymous>", "", "it", "Landroidx/sqlite/db/SupportSQLiteDatabase;", "invoke"}, k = 3, mv = {1, 7, 1}, xi = 48)
  static final class RoomDatabase$beginTransaction$1 extends Lambda implements Function1<SupportSQLiteDatabase, Object> {
    RoomDatabase$beginTransaction$1() {
      super(1);
    }
    
    public final Object invoke(SupportSQLiteDatabase param1SupportSQLiteDatabase) {
      Intrinsics.checkNotNullParameter(param1SupportSQLiteDatabase, "it");
      RoomDatabase.this.internalBeginTransaction();
      return null;
    }
  }
  
  @Metadata(d1 = {"\000\016\n\000\n\002\020\000\n\000\n\002\030\002\n\000\020\000\032\004\030\0010\0012\006\020\002\032\0020\003H\n¢\006\002\b\004"}, d2 = {"<anonymous>", "", "it", "Landroidx/sqlite/db/SupportSQLiteDatabase;", "invoke"}, k = 3, mv = {1, 7, 1}, xi = 48)
  static final class RoomDatabase$endTransaction$1 extends Lambda implements Function1<SupportSQLiteDatabase, Object> {
    RoomDatabase$endTransaction$1() {
      super(1);
    }
    
    public final Object invoke(SupportSQLiteDatabase param1SupportSQLiteDatabase) {
      Intrinsics.checkNotNullParameter(param1SupportSQLiteDatabase, "it");
      RoomDatabase.this.internalEndTransaction();
      return null;
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\MagicAI - AI Art & Anime Art-dex2jar.jar!\androidx\room\RoomDatabase.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */