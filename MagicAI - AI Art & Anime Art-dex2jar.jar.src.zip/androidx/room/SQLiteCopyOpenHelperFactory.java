package androidx.room;

import androidx.sqlite.db.SupportSQLiteOpenHelper;
import java.io.File;
import java.io.InputStream;
import java.util.concurrent.Callable;
import kotlin.Metadata;
import kotlin.jvm.internal.Intrinsics;

@Metadata(d1 = {"\000.\n\002\030\002\n\002\030\002\n\000\n\002\020\016\n\000\n\002\030\002\n\000\n\002\030\002\n\002\030\002\n\002\b\003\n\002\030\002\n\000\n\002\030\002\n\000\b\000\030\0002\0020\001B1\022\b\020\002\032\004\030\0010\003\022\b\020\004\032\004\030\0010\005\022\016\020\006\032\n\022\004\022\0020\b\030\0010\007\022\006\020\t\032\0020\001¢\006\002\020\nJ\020\020\013\032\0020\f2\006\020\r\032\0020\016H\026R\020\020\002\032\004\030\0010\003X\004¢\006\002\n\000R\020\020\004\032\004\030\0010\005X\004¢\006\002\n\000R\026\020\006\032\n\022\004\022\0020\b\030\0010\007X\004¢\006\002\n\000R\016\020\t\032\0020\001X\004¢\006\002\n\000¨\006\017"}, d2 = {"Landroidx/room/SQLiteCopyOpenHelperFactory;", "Landroidx/sqlite/db/SupportSQLiteOpenHelper$Factory;", "mCopyFromAssetPath", "", "mCopyFromFile", "Ljava/io/File;", "mCopyFromInputStream", "Ljava/util/concurrent/Callable;", "Ljava/io/InputStream;", "mDelegate", "(Ljava/lang/String;Ljava/io/File;Ljava/util/concurrent/Callable;Landroidx/sqlite/db/SupportSQLiteOpenHelper$Factory;)V", "create", "Landroidx/sqlite/db/SupportSQLiteOpenHelper;", "configuration", "Landroidx/sqlite/db/SupportSQLiteOpenHelper$Configuration;", "room-runtime_release"}, k = 1, mv = {1, 7, 1}, xi = 48)
public final class SQLiteCopyOpenHelperFactory implements SupportSQLiteOpenHelper.Factory {
  private final String mCopyFromAssetPath;
  
  private final File mCopyFromFile;
  
  private final Callable<InputStream> mCopyFromInputStream;
  
  private final SupportSQLiteOpenHelper.Factory mDelegate;
  
  public SQLiteCopyOpenHelperFactory(String paramString, File paramFile, Callable<InputStream> paramCallable, SupportSQLiteOpenHelper.Factory paramFactory) {
    this.mCopyFromAssetPath = paramString;
    this.mCopyFromFile = paramFile;
    this.mCopyFromInputStream = paramCallable;
    this.mDelegate = paramFactory;
  }
  
  public SupportSQLiteOpenHelper create(SupportSQLiteOpenHelper.Configuration paramConfiguration) {
    Intrinsics.checkNotNullParameter(paramConfiguration, "configuration");
    return (SupportSQLiteOpenHelper)new SQLiteCopyOpenHelper(paramConfiguration.context, this.mCopyFromAssetPath, this.mCopyFromFile, this.mCopyFromInputStream, paramConfiguration.callback.version, this.mDelegate.create(paramConfiguration));
  }
}


/* Location:              C:\soft\dex2jar-2.0\MagicAI - AI Art & Anime Art-dex2jar.jar!\androidx\room\SQLiteCopyOpenHelperFactory.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */