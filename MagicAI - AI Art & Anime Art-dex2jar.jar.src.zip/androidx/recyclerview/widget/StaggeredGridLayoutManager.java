package androidx.recyclerview.widget;

import android.annotation.SuppressLint;
import android.content.Context;
import android.graphics.PointF;
import android.graphics.Rect;
import android.os.Parcel;
import android.os.Parcelable;
import android.util.AttributeSet;
import android.view.View;
import android.view.ViewGroup;
import android.view.accessibility.AccessibilityEvent;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.annotation.RestrictTo;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.BitSet;
import java.util.List;

public class StaggeredGridLayoutManager extends RecyclerView.LayoutManager implements RecyclerView.SmoothScroller.ScrollVectorProvider {
  static final boolean DEBUG = false;
  
  @Deprecated
  public static final int GAP_HANDLING_LAZY = 1;
  
  public static final int GAP_HANDLING_MOVE_ITEMS_BETWEEN_SPANS = 2;
  
  public static final int GAP_HANDLING_NONE = 0;
  
  public static final int HORIZONTAL = 0;
  
  static final int INVALID_OFFSET = -2147483648;
  
  private static final float MAX_SCROLL_FACTOR = 0.33333334F;
  
  private static final String TAG = "StaggeredGridLManager";
  
  public static final int VERTICAL = 1;
  
  private final AnchorInfo mAnchorInfo = new AnchorInfo();
  
  private final Runnable mCheckForGapsRunnable = new Runnable() {
      public void run() {
        StaggeredGridLayoutManager.this.checkForGaps();
      }
    };
  
  private int mFullSizeSpec;
  
  private int mGapStrategy = 2;
  
  private boolean mLaidOutInvalidFullSpan = false;
  
  private boolean mLastLayoutFromEnd;
  
  private boolean mLastLayoutRTL;
  
  @NonNull
  private final LayoutState mLayoutState;
  
  LazySpanLookup mLazySpanLookup = new LazySpanLookup();
  
  private int mOrientation;
  
  private SavedState mPendingSavedState;
  
  int mPendingScrollPosition = -1;
  
  int mPendingScrollPositionOffset = Integer.MIN_VALUE;
  
  private int[] mPrefetchDistances;
  
  @NonNull
  OrientationHelper mPrimaryOrientation;
  
  private BitSet mRemainingSpans;
  
  boolean mReverseLayout = false;
  
  @NonNull
  OrientationHelper mSecondaryOrientation;
  
  boolean mShouldReverseLayout = false;
  
  private int mSizePerSpan;
  
  private boolean mSmoothScrollbarEnabled = true;
  
  private int mSpanCount = -1;
  
  Span[] mSpans;
  
  private final Rect mTmpRect = new Rect();
  
  public StaggeredGridLayoutManager(int paramInt1, int paramInt2) {
    this.mOrientation = paramInt2;
    setSpanCount(paramInt1);
    this.mLayoutState = new LayoutState();
    createOrientationHelpers();
  }
  
  public StaggeredGridLayoutManager(Context paramContext, AttributeSet paramAttributeSet, int paramInt1, int paramInt2) {
    RecyclerView.LayoutManager.Properties properties = RecyclerView.LayoutManager.getProperties(paramContext, paramAttributeSet, paramInt1, paramInt2);
    setOrientation(properties.orientation);
    setSpanCount(properties.spanCount);
    setReverseLayout(properties.reverseLayout);
    this.mLayoutState = new LayoutState();
    createOrientationHelpers();
  }
  
  private void appendViewToAllSpans(View paramView) {
    for (int i = this.mSpanCount - 1; i >= 0; i--)
      this.mSpans[i].appendToSpan(paramView); 
  }
  
  private void applyPendingSavedState(AnchorInfo paramAnchorInfo) {
    SavedState savedState = this.mPendingSavedState;
    int i = savedState.mSpanOffsetsSize;
    if (i > 0)
      if (i == this.mSpanCount) {
        for (i = 0; i < this.mSpanCount; i++) {
          this.mSpans[i].clear();
          savedState = this.mPendingSavedState;
          int k = savedState.mSpanOffsets[i];
          int j = k;
          if (k != Integer.MIN_VALUE) {
            if (savedState.mAnchorLayoutFromEnd) {
              j = this.mPrimaryOrientation.getEndAfterPadding();
            } else {
              j = this.mPrimaryOrientation.getStartAfterPadding();
            } 
            j = k + j;
          } 
          this.mSpans[i].setLine(j);
        } 
      } else {
        savedState.invalidateSpanInfo();
        savedState = this.mPendingSavedState;
        savedState.mAnchorPosition = savedState.mVisibleAnchorPosition;
      }  
    savedState = this.mPendingSavedState;
    this.mLastLayoutRTL = savedState.mLastLayoutRTL;
    setReverseLayout(savedState.mReverseLayout);
    resolveShouldLayoutReverse();
    savedState = this.mPendingSavedState;
    i = savedState.mAnchorPosition;
    if (i != -1) {
      this.mPendingScrollPosition = i;
      paramAnchorInfo.mLayoutFromEnd = savedState.mAnchorLayoutFromEnd;
    } else {
      paramAnchorInfo.mLayoutFromEnd = this.mShouldReverseLayout;
    } 
    if (savedState.mSpanLookupSize > 1) {
      LazySpanLookup lazySpanLookup = this.mLazySpanLookup;
      lazySpanLookup.mData = savedState.mSpanLookup;
      lazySpanLookup.mFullSpanItems = savedState.mFullSpanItems;
    } 
  }
  
  private void attachViewToSpans(View paramView, LayoutParams paramLayoutParams, LayoutState paramLayoutState) {
    if (paramLayoutState.mLayoutDirection == 1) {
      if (paramLayoutParams.mFullSpan) {
        appendViewToAllSpans(paramView);
        return;
      } 
      paramLayoutParams.mSpan.appendToSpan(paramView);
      return;
    } 
    if (paramLayoutParams.mFullSpan) {
      prependViewToAllSpans(paramView);
      return;
    } 
    paramLayoutParams.mSpan.prependToSpan(paramView);
  }
  
  private int calculateScrollDirectionForPosition(int paramInt) {
    boolean bool;
    int i = getChildCount();
    byte b = -1;
    if (i == 0) {
      paramInt = b;
      if (this.mShouldReverseLayout)
        paramInt = 1; 
      return paramInt;
    } 
    if (paramInt < getFirstChildPosition()) {
      bool = true;
    } else {
      bool = false;
    } 
    return (bool != this.mShouldReverseLayout) ? -1 : 1;
  }
  
  private boolean checkSpanForGap(Span paramSpan) {
    if (this.mShouldReverseLayout) {
      if (paramSpan.getEndLine() < this.mPrimaryOrientation.getEndAfterPadding()) {
        ArrayList<View> arrayList = paramSpan.mViews;
        return (paramSpan.getLayoutParams((View)arrayList.get(arrayList.size() - 1))).mFullSpan ^ true;
      } 
    } else if (paramSpan.getStartLine() > this.mPrimaryOrientation.getStartAfterPadding()) {
      return (paramSpan.getLayoutParams((View)paramSpan.mViews.get(0))).mFullSpan ^ true;
    } 
    return false;
  }
  
  private int computeScrollExtent(RecyclerView.State paramState) {
    return (getChildCount() == 0) ? 0 : ScrollbarHelper.computeScrollExtent(paramState, this.mPrimaryOrientation, findFirstVisibleItemClosestToStart(this.mSmoothScrollbarEnabled ^ true), findFirstVisibleItemClosestToEnd(this.mSmoothScrollbarEnabled ^ true), this, this.mSmoothScrollbarEnabled);
  }
  
  private int computeScrollOffset(RecyclerView.State paramState) {
    return (getChildCount() == 0) ? 0 : ScrollbarHelper.computeScrollOffset(paramState, this.mPrimaryOrientation, findFirstVisibleItemClosestToStart(this.mSmoothScrollbarEnabled ^ true), findFirstVisibleItemClosestToEnd(this.mSmoothScrollbarEnabled ^ true), this, this.mSmoothScrollbarEnabled, this.mShouldReverseLayout);
  }
  
  private int computeScrollRange(RecyclerView.State paramState) {
    return (getChildCount() == 0) ? 0 : ScrollbarHelper.computeScrollRange(paramState, this.mPrimaryOrientation, findFirstVisibleItemClosestToStart(this.mSmoothScrollbarEnabled ^ true), findFirstVisibleItemClosestToEnd(this.mSmoothScrollbarEnabled ^ true), this, this.mSmoothScrollbarEnabled);
  }
  
  private int convertFocusDirectionToLayoutDirection(int paramInt) {
    return (paramInt != 1) ? ((paramInt != 2) ? ((paramInt != 17) ? ((paramInt != 33) ? ((paramInt != 66) ? ((paramInt != 130) ? Integer.MIN_VALUE : ((this.mOrientation == 1) ? 1 : Integer.MIN_VALUE)) : ((this.mOrientation == 0) ? 1 : Integer.MIN_VALUE)) : ((this.mOrientation == 1) ? -1 : Integer.MIN_VALUE)) : ((this.mOrientation == 0) ? -1 : Integer.MIN_VALUE)) : ((this.mOrientation == 1) ? 1 : (isLayoutRTL() ? -1 : 1))) : ((this.mOrientation == 1) ? -1 : (isLayoutRTL() ? 1 : -1));
  }
  
  private LazySpanLookup.FullSpanItem createFullSpanItemFromEnd(int paramInt) {
    LazySpanLookup.FullSpanItem fullSpanItem = new LazySpanLookup.FullSpanItem();
    fullSpanItem.mGapPerSpan = new int[this.mSpanCount];
    for (int i = 0; i < this.mSpanCount; i++)
      fullSpanItem.mGapPerSpan[i] = paramInt - this.mSpans[i].getEndLine(paramInt); 
    return fullSpanItem;
  }
  
  private LazySpanLookup.FullSpanItem createFullSpanItemFromStart(int paramInt) {
    LazySpanLookup.FullSpanItem fullSpanItem = new LazySpanLookup.FullSpanItem();
    fullSpanItem.mGapPerSpan = new int[this.mSpanCount];
    for (int i = 0; i < this.mSpanCount; i++)
      fullSpanItem.mGapPerSpan[i] = this.mSpans[i].getStartLine(paramInt) - paramInt; 
    return fullSpanItem;
  }
  
  private void createOrientationHelpers() {
    this.mPrimaryOrientation = OrientationHelper.createOrientationHelper(this, this.mOrientation);
    this.mSecondaryOrientation = OrientationHelper.createOrientationHelper(this, 1 - this.mOrientation);
  }
  
  private int fill(RecyclerView.Recycler paramRecycler, LayoutState paramLayoutState, RecyclerView.State paramState) {
    int i;
    int k;
    this.mRemainingSpans.set(0, this.mSpanCount, true);
    if (this.mLayoutState.mInfinite) {
      if (paramLayoutState.mLayoutDirection == 1) {
        i = Integer.MAX_VALUE;
      } else {
        i = Integer.MIN_VALUE;
      } 
    } else if (paramLayoutState.mLayoutDirection == 1) {
      i = paramLayoutState.mEndLine + paramLayoutState.mAvailable;
    } else {
      i = paramLayoutState.mStartLine - paramLayoutState.mAvailable;
    } 
    updateAllRemainingSpans(paramLayoutState.mLayoutDirection, i);
    if (this.mShouldReverseLayout) {
      k = this.mPrimaryOrientation.getEndAfterPadding();
    } else {
      k = this.mPrimaryOrientation.getStartAfterPadding();
    } 
    int j;
    for (j = 0; paramLayoutState.hasMore(paramState) && (this.mLayoutState.mInfinite || !this.mRemainingSpans.isEmpty()); j = 1) {
      int m;
      int n;
      int i1;
      Span span;
      View view = paramLayoutState.next(paramRecycler);
      LayoutParams layoutParams = (LayoutParams)view.getLayoutParams();
      int i2 = layoutParams.getViewLayoutPosition();
      j = this.mLazySpanLookup.getSpan(i2);
      if (j == -1) {
        i1 = 1;
      } else {
        i1 = 0;
      } 
      if (i1) {
        if (layoutParams.mFullSpan) {
          span = this.mSpans[0];
        } else {
          span = getNextSpan(paramLayoutState);
        } 
        this.mLazySpanLookup.setSpan(i2, span);
      } else {
        span = this.mSpans[j];
      } 
      layoutParams.mSpan = span;
      if (paramLayoutState.mLayoutDirection == 1) {
        addView(view);
      } else {
        addView(view, 0);
      } 
      measureChildWithDecorationsAndMargin(view, layoutParams, false);
      if (paramLayoutState.mLayoutDirection == 1) {
        if (layoutParams.mFullSpan) {
          j = getMaxEnd(k);
        } else {
          j = span.getEndLine(k);
        } 
        m = this.mPrimaryOrientation.getDecoratedMeasurement(view);
        if (i1 && layoutParams.mFullSpan) {
          LazySpanLookup.FullSpanItem fullSpanItem = createFullSpanItemFromEnd(j);
          fullSpanItem.mGapDir = -1;
          fullSpanItem.mPosition = i2;
          this.mLazySpanLookup.addFullSpanItem(fullSpanItem);
        } 
        n = m + j;
        m = j;
      } else {
        if (layoutParams.mFullSpan) {
          j = getMinStart(k);
        } else {
          j = span.getStartLine(k);
        } 
        m = j - this.mPrimaryOrientation.getDecoratedMeasurement(view);
        if (i1 && layoutParams.mFullSpan) {
          LazySpanLookup.FullSpanItem fullSpanItem = createFullSpanItemFromStart(j);
          fullSpanItem.mGapDir = 1;
          fullSpanItem.mPosition = i2;
          this.mLazySpanLookup.addFullSpanItem(fullSpanItem);
        } 
        n = j;
      } 
      if (layoutParams.mFullSpan && paramLayoutState.mItemDirection == -1)
        if (i1) {
          this.mLaidOutInvalidFullSpan = true;
        } else {
          boolean bool;
          if (paramLayoutState.mLayoutDirection == 1) {
            bool = areAllEndsEqual();
          } else {
            bool = areAllStartsEqual();
          } 
          if ((bool ^ true) != 0) {
            LazySpanLookup.FullSpanItem fullSpanItem = this.mLazySpanLookup.getFullSpanItem(i2);
            if (fullSpanItem != null)
              fullSpanItem.mHasUnwantedGapAfter = true; 
            this.mLaidOutInvalidFullSpan = true;
          } 
        }  
      attachViewToSpans(view, layoutParams, paramLayoutState);
      if (isLayoutRTL() && this.mOrientation == 1) {
        if (layoutParams.mFullSpan) {
          j = this.mSecondaryOrientation.getEndAfterPadding();
        } else {
          j = this.mSecondaryOrientation.getEndAfterPadding() - (this.mSpanCount - 1 - span.mIndex) * this.mSizePerSpan;
        } 
        i2 = this.mSecondaryOrientation.getDecoratedMeasurement(view);
        i1 = j;
        j -= i2;
        i2 = i1;
      } else {
        if (layoutParams.mFullSpan) {
          j = this.mSecondaryOrientation.getStartAfterPadding();
        } else {
          j = span.mIndex * this.mSizePerSpan + this.mSecondaryOrientation.getStartAfterPadding();
        } 
        i2 = this.mSecondaryOrientation.getDecoratedMeasurement(view);
        i1 = j;
        i2 += j;
        j = i1;
      } 
      if (this.mOrientation == 1) {
        layoutDecoratedWithMargins(view, j, m, i2, n);
      } else {
        layoutDecoratedWithMargins(view, m, j, n, i2);
      } 
      if (layoutParams.mFullSpan) {
        updateAllRemainingSpans(this.mLayoutState.mLayoutDirection, i);
      } else {
        updateRemainingSpans(span, this.mLayoutState.mLayoutDirection, i);
      } 
      recycle(paramRecycler, this.mLayoutState);
      if (this.mLayoutState.mStopInFocusable && view.hasFocusable())
        if (layoutParams.mFullSpan) {
          this.mRemainingSpans.clear();
        } else {
          this.mRemainingSpans.set(span.mIndex, false);
        }  
    } 
    if (j == 0)
      recycle(paramRecycler, this.mLayoutState); 
    if (this.mLayoutState.mLayoutDirection == -1) {
      i = getMinStart(this.mPrimaryOrientation.getStartAfterPadding());
      i = this.mPrimaryOrientation.getStartAfterPadding() - i;
    } else {
      i = getMaxEnd(this.mPrimaryOrientation.getEndAfterPadding()) - this.mPrimaryOrientation.getEndAfterPadding();
    } 
    return (i > 0) ? Math.min(paramLayoutState.mAvailable, i) : 0;
  }
  
  private int findFirstReferenceChildPosition(int paramInt) {
    int j = getChildCount();
    for (int i = 0; i < j; i++) {
      int k = getPosition(getChildAt(i));
      if (k >= 0 && k < paramInt)
        return k; 
    } 
    return 0;
  }
  
  private int findLastReferenceChildPosition(int paramInt) {
    for (int i = getChildCount() - 1; i >= 0; i--) {
      int j = getPosition(getChildAt(i));
      if (j >= 0 && j < paramInt)
        return j; 
    } 
    return 0;
  }
  
  private void fixEndGap(RecyclerView.Recycler paramRecycler, RecyclerView.State paramState, boolean paramBoolean) {
    int i = getMaxEnd(-2147483648);
    if (i == Integer.MIN_VALUE)
      return; 
    i = this.mPrimaryOrientation.getEndAfterPadding() - i;
    if (i > 0) {
      i -= -scrollBy(-i, paramRecycler, paramState);
      if (paramBoolean && i > 0)
        this.mPrimaryOrientation.offsetChildren(i); 
    } 
  }
  
  private void fixStartGap(RecyclerView.Recycler paramRecycler, RecyclerView.State paramState, boolean paramBoolean) {
    int i = getMinStart(2147483647);
    if (i == Integer.MAX_VALUE)
      return; 
    i -= this.mPrimaryOrientation.getStartAfterPadding();
    if (i > 0) {
      i -= scrollBy(i, paramRecycler, paramState);
      if (paramBoolean && i > 0)
        this.mPrimaryOrientation.offsetChildren(-i); 
    } 
  }
  
  private int getMaxEnd(int paramInt) {
    int j = this.mSpans[0].getEndLine(paramInt);
    int i = 1;
    while (i < this.mSpanCount) {
      int m = this.mSpans[i].getEndLine(paramInt);
      int k = j;
      if (m > j)
        k = m; 
      i++;
      j = k;
    } 
    return j;
  }
  
  private int getMaxStart(int paramInt) {
    int j = this.mSpans[0].getStartLine(paramInt);
    int i = 1;
    while (i < this.mSpanCount) {
      int m = this.mSpans[i].getStartLine(paramInt);
      int k = j;
      if (m > j)
        k = m; 
      i++;
      j = k;
    } 
    return j;
  }
  
  private int getMinEnd(int paramInt) {
    int j = this.mSpans[0].getEndLine(paramInt);
    int i = 1;
    while (i < this.mSpanCount) {
      int m = this.mSpans[i].getEndLine(paramInt);
      int k = j;
      if (m < j)
        k = m; 
      i++;
      j = k;
    } 
    return j;
  }
  
  private int getMinStart(int paramInt) {
    int j = this.mSpans[0].getStartLine(paramInt);
    int i = 1;
    while (i < this.mSpanCount) {
      int m = this.mSpans[i].getStartLine(paramInt);
      int k = j;
      if (m < j)
        k = m; 
      i++;
      j = k;
    } 
    return j;
  }
  
  private Span getNextSpan(LayoutState paramLayoutState) {
    int i;
    int j;
    byte b;
    if (preferLastSpan(paramLayoutState.mLayoutDirection)) {
      i = this.mSpanCount - 1;
      j = -1;
      b = -1;
    } else {
      j = this.mSpanCount;
      i = 0;
      b = 1;
    } 
    int k = paramLayoutState.mLayoutDirection;
    Span span2 = null;
    paramLayoutState = null;
    if (k == 1) {
      Span span;
      int n = this.mPrimaryOrientation.getStartAfterPadding();
      for (k = Integer.MAX_VALUE; i != j; k = i1) {
        span2 = this.mSpans[i];
        int i2 = span2.getEndLine(n);
        int i1 = k;
        if (i2 < k) {
          span = span2;
          i1 = i2;
        } 
        i += b;
      } 
      return span;
    } 
    int m = this.mPrimaryOrientation.getEndAfterPadding();
    k = Integer.MIN_VALUE;
    Span span1 = span2;
    while (i != j) {
      span2 = this.mSpans[i];
      int i1 = span2.getStartLine(m);
      int n = k;
      if (i1 > k) {
        span1 = span2;
        n = i1;
      } 
      i += b;
      k = n;
    } 
    return span1;
  }
  
  private void handleUpdate(int paramInt1, int paramInt2, int paramInt3) {
    if (this.mShouldReverseLayout) {
      int j = getLastChildPosition();
    } else {
      int j = getFirstChildPosition();
    } 
    if (paramInt3 == 8) {
      if (paramInt1 < paramInt2) {
        int j = paramInt2 + 1;
      } else {
        int j = paramInt1 + 1;
        int k = paramInt2;
        this.mLazySpanLookup.invalidateAfter(k);
      } 
    } else {
      int j = paramInt1 + paramInt2;
    } 
    int i = paramInt1;
    this.mLazySpanLookup.invalidateAfter(i);
  }
  
  private void measureChildWithDecorationsAndMargin(View paramView, int paramInt1, int paramInt2, boolean paramBoolean) {
    calculateItemDecorationsForChild(paramView, this.mTmpRect);
    LayoutParams layoutParams = (LayoutParams)paramView.getLayoutParams();
    int i = layoutParams.leftMargin;
    Rect rect = this.mTmpRect;
    paramInt1 = updateSpecWithExtra(paramInt1, i + rect.left, layoutParams.rightMargin + rect.right);
    i = layoutParams.topMargin;
    rect = this.mTmpRect;
    paramInt2 = updateSpecWithExtra(paramInt2, i + rect.top, layoutParams.bottomMargin + rect.bottom);
    if (paramBoolean) {
      paramBoolean = shouldReMeasureChild(paramView, paramInt1, paramInt2, layoutParams);
    } else {
      paramBoolean = shouldMeasureChild(paramView, paramInt1, paramInt2, layoutParams);
    } 
    if (paramBoolean)
      paramView.measure(paramInt1, paramInt2); 
  }
  
  private void measureChildWithDecorationsAndMargin(View paramView, LayoutParams paramLayoutParams, boolean paramBoolean) {
    if (paramLayoutParams.mFullSpan) {
      if (this.mOrientation == 1) {
        measureChildWithDecorationsAndMargin(paramView, this.mFullSizeSpec, RecyclerView.LayoutManager.getChildMeasureSpec(getHeight(), getHeightMode(), getPaddingTop() + getPaddingBottom(), paramLayoutParams.height, true), paramBoolean);
        return;
      } 
      measureChildWithDecorationsAndMargin(paramView, RecyclerView.LayoutManager.getChildMeasureSpec(getWidth(), getWidthMode(), getPaddingLeft() + getPaddingRight(), paramLayoutParams.width, true), this.mFullSizeSpec, paramBoolean);
      return;
    } 
    if (this.mOrientation == 1) {
      measureChildWithDecorationsAndMargin(paramView, RecyclerView.LayoutManager.getChildMeasureSpec(this.mSizePerSpan, getWidthMode(), 0, paramLayoutParams.width, false), RecyclerView.LayoutManager.getChildMeasureSpec(getHeight(), getHeightMode(), getPaddingTop() + getPaddingBottom(), paramLayoutParams.height, true), paramBoolean);
      return;
    } 
    measureChildWithDecorationsAndMargin(paramView, RecyclerView.LayoutManager.getChildMeasureSpec(getWidth(), getWidthMode(), getPaddingLeft() + getPaddingRight(), paramLayoutParams.width, true), RecyclerView.LayoutManager.getChildMeasureSpec(this.mSizePerSpan, getHeightMode(), 0, paramLayoutParams.height, false), paramBoolean);
  }
  
  private void onLayoutChildren(RecyclerView.Recycler paramRecycler, RecyclerView.State paramState, boolean paramBoolean) {
    // Byte code:
    //   0: aload_0
    //   1: getfield mAnchorInfo : Landroidx/recyclerview/widget/StaggeredGridLayoutManager$AnchorInfo;
    //   4: astore #8
    //   6: aload_0
    //   7: getfield mPendingSavedState : Landroidx/recyclerview/widget/StaggeredGridLayoutManager$SavedState;
    //   10: ifnonnull -> 21
    //   13: aload_0
    //   14: getfield mPendingScrollPosition : I
    //   17: iconst_m1
    //   18: if_icmpeq -> 39
    //   21: aload_2
    //   22: invokevirtual getItemCount : ()I
    //   25: ifne -> 39
    //   28: aload_0
    //   29: aload_1
    //   30: invokevirtual removeAndRecycleAllViews : (Landroidx/recyclerview/widget/RecyclerView$Recycler;)V
    //   33: aload #8
    //   35: invokevirtual reset : ()V
    //   38: return
    //   39: aload #8
    //   41: getfield mValid : Z
    //   44: istore #7
    //   46: iconst_1
    //   47: istore #5
    //   49: iload #7
    //   51: ifeq -> 78
    //   54: aload_0
    //   55: getfield mPendingScrollPosition : I
    //   58: iconst_m1
    //   59: if_icmpne -> 78
    //   62: aload_0
    //   63: getfield mPendingSavedState : Landroidx/recyclerview/widget/StaggeredGridLayoutManager$SavedState;
    //   66: ifnull -> 72
    //   69: goto -> 78
    //   72: iconst_0
    //   73: istore #4
    //   75: goto -> 81
    //   78: iconst_1
    //   79: istore #4
    //   81: iload #4
    //   83: ifeq -> 133
    //   86: aload #8
    //   88: invokevirtual reset : ()V
    //   91: aload_0
    //   92: getfield mPendingSavedState : Landroidx/recyclerview/widget/StaggeredGridLayoutManager$SavedState;
    //   95: ifnull -> 107
    //   98: aload_0
    //   99: aload #8
    //   101: invokespecial applyPendingSavedState : (Landroidx/recyclerview/widget/StaggeredGridLayoutManager$AnchorInfo;)V
    //   104: goto -> 120
    //   107: aload_0
    //   108: invokespecial resolveShouldLayoutReverse : ()V
    //   111: aload #8
    //   113: aload_0
    //   114: getfield mShouldReverseLayout : Z
    //   117: putfield mLayoutFromEnd : Z
    //   120: aload_0
    //   121: aload_2
    //   122: aload #8
    //   124: invokevirtual updateAnchorInfoForLayout : (Landroidx/recyclerview/widget/RecyclerView$State;Landroidx/recyclerview/widget/StaggeredGridLayoutManager$AnchorInfo;)V
    //   127: aload #8
    //   129: iconst_1
    //   130: putfield mValid : Z
    //   133: aload_0
    //   134: getfield mPendingSavedState : Landroidx/recyclerview/widget/StaggeredGridLayoutManager$SavedState;
    //   137: ifnonnull -> 184
    //   140: aload_0
    //   141: getfield mPendingScrollPosition : I
    //   144: iconst_m1
    //   145: if_icmpne -> 184
    //   148: aload #8
    //   150: getfield mLayoutFromEnd : Z
    //   153: aload_0
    //   154: getfield mLastLayoutFromEnd : Z
    //   157: if_icmpne -> 171
    //   160: aload_0
    //   161: invokevirtual isLayoutRTL : ()Z
    //   164: aload_0
    //   165: getfield mLastLayoutRTL : Z
    //   168: if_icmpeq -> 184
    //   171: aload_0
    //   172: getfield mLazySpanLookup : Landroidx/recyclerview/widget/StaggeredGridLayoutManager$LazySpanLookup;
    //   175: invokevirtual clear : ()V
    //   178: aload #8
    //   180: iconst_1
    //   181: putfield mInvalidateOffsets : Z
    //   184: aload_0
    //   185: invokevirtual getChildCount : ()I
    //   188: ifle -> 395
    //   191: aload_0
    //   192: getfield mPendingSavedState : Landroidx/recyclerview/widget/StaggeredGridLayoutManager$SavedState;
    //   195: astore #9
    //   197: aload #9
    //   199: ifnull -> 211
    //   202: aload #9
    //   204: getfield mSpanOffsetsSize : I
    //   207: iconst_1
    //   208: if_icmpge -> 395
    //   211: aload #8
    //   213: getfield mInvalidateOffsets : Z
    //   216: ifeq -> 276
    //   219: iconst_0
    //   220: istore #4
    //   222: iload #4
    //   224: aload_0
    //   225: getfield mSpanCount : I
    //   228: if_icmpge -> 395
    //   231: aload_0
    //   232: getfield mSpans : [Landroidx/recyclerview/widget/StaggeredGridLayoutManager$Span;
    //   235: iload #4
    //   237: aaload
    //   238: invokevirtual clear : ()V
    //   241: aload #8
    //   243: getfield mOffset : I
    //   246: istore #6
    //   248: iload #6
    //   250: ldc -2147483648
    //   252: if_icmpeq -> 267
    //   255: aload_0
    //   256: getfield mSpans : [Landroidx/recyclerview/widget/StaggeredGridLayoutManager$Span;
    //   259: iload #4
    //   261: aaload
    //   262: iload #6
    //   264: invokevirtual setLine : (I)V
    //   267: iload #4
    //   269: iconst_1
    //   270: iadd
    //   271: istore #4
    //   273: goto -> 222
    //   276: iload #4
    //   278: ifne -> 344
    //   281: aload_0
    //   282: getfield mAnchorInfo : Landroidx/recyclerview/widget/StaggeredGridLayoutManager$AnchorInfo;
    //   285: getfield mSpanReferenceLines : [I
    //   288: ifnonnull -> 294
    //   291: goto -> 344
    //   294: iconst_0
    //   295: istore #4
    //   297: iload #4
    //   299: aload_0
    //   300: getfield mSpanCount : I
    //   303: if_icmpge -> 395
    //   306: aload_0
    //   307: getfield mSpans : [Landroidx/recyclerview/widget/StaggeredGridLayoutManager$Span;
    //   310: iload #4
    //   312: aaload
    //   313: astore #9
    //   315: aload #9
    //   317: invokevirtual clear : ()V
    //   320: aload #9
    //   322: aload_0
    //   323: getfield mAnchorInfo : Landroidx/recyclerview/widget/StaggeredGridLayoutManager$AnchorInfo;
    //   326: getfield mSpanReferenceLines : [I
    //   329: iload #4
    //   331: iaload
    //   332: invokevirtual setLine : (I)V
    //   335: iload #4
    //   337: iconst_1
    //   338: iadd
    //   339: istore #4
    //   341: goto -> 297
    //   344: iconst_0
    //   345: istore #4
    //   347: iload #4
    //   349: aload_0
    //   350: getfield mSpanCount : I
    //   353: if_icmpge -> 384
    //   356: aload_0
    //   357: getfield mSpans : [Landroidx/recyclerview/widget/StaggeredGridLayoutManager$Span;
    //   360: iload #4
    //   362: aaload
    //   363: aload_0
    //   364: getfield mShouldReverseLayout : Z
    //   367: aload #8
    //   369: getfield mOffset : I
    //   372: invokevirtual cacheReferenceLineAndClear : (ZI)V
    //   375: iload #4
    //   377: iconst_1
    //   378: iadd
    //   379: istore #4
    //   381: goto -> 347
    //   384: aload_0
    //   385: getfield mAnchorInfo : Landroidx/recyclerview/widget/StaggeredGridLayoutManager$AnchorInfo;
    //   388: aload_0
    //   389: getfield mSpans : [Landroidx/recyclerview/widget/StaggeredGridLayoutManager$Span;
    //   392: invokevirtual saveSpanReferenceLines : ([Landroidx/recyclerview/widget/StaggeredGridLayoutManager$Span;)V
    //   395: aload_0
    //   396: aload_1
    //   397: invokevirtual detachAndScrapAttachedViews : (Landroidx/recyclerview/widget/RecyclerView$Recycler;)V
    //   400: aload_0
    //   401: getfield mLayoutState : Landroidx/recyclerview/widget/LayoutState;
    //   404: iconst_0
    //   405: putfield mRecycle : Z
    //   408: aload_0
    //   409: iconst_0
    //   410: putfield mLaidOutInvalidFullSpan : Z
    //   413: aload_0
    //   414: aload_0
    //   415: getfield mSecondaryOrientation : Landroidx/recyclerview/widget/OrientationHelper;
    //   418: invokevirtual getTotalSpace : ()I
    //   421: invokevirtual updateMeasureSpecs : (I)V
    //   424: aload_0
    //   425: aload #8
    //   427: getfield mPosition : I
    //   430: aload_2
    //   431: invokespecial updateLayoutState : (ILandroidx/recyclerview/widget/RecyclerView$State;)V
    //   434: aload #8
    //   436: getfield mLayoutFromEnd : Z
    //   439: ifeq -> 497
    //   442: aload_0
    //   443: iconst_m1
    //   444: invokespecial setLayoutStateDirection : (I)V
    //   447: aload_0
    //   448: aload_1
    //   449: aload_0
    //   450: getfield mLayoutState : Landroidx/recyclerview/widget/LayoutState;
    //   453: aload_2
    //   454: invokespecial fill : (Landroidx/recyclerview/widget/RecyclerView$Recycler;Landroidx/recyclerview/widget/LayoutState;Landroidx/recyclerview/widget/RecyclerView$State;)I
    //   457: pop
    //   458: aload_0
    //   459: iconst_1
    //   460: invokespecial setLayoutStateDirection : (I)V
    //   463: aload_0
    //   464: getfield mLayoutState : Landroidx/recyclerview/widget/LayoutState;
    //   467: astore #9
    //   469: aload #9
    //   471: aload #8
    //   473: getfield mPosition : I
    //   476: aload #9
    //   478: getfield mItemDirection : I
    //   481: iadd
    //   482: putfield mCurrentPosition : I
    //   485: aload_0
    //   486: aload_1
    //   487: aload #9
    //   489: aload_2
    //   490: invokespecial fill : (Landroidx/recyclerview/widget/RecyclerView$Recycler;Landroidx/recyclerview/widget/LayoutState;Landroidx/recyclerview/widget/RecyclerView$State;)I
    //   493: pop
    //   494: goto -> 549
    //   497: aload_0
    //   498: iconst_1
    //   499: invokespecial setLayoutStateDirection : (I)V
    //   502: aload_0
    //   503: aload_1
    //   504: aload_0
    //   505: getfield mLayoutState : Landroidx/recyclerview/widget/LayoutState;
    //   508: aload_2
    //   509: invokespecial fill : (Landroidx/recyclerview/widget/RecyclerView$Recycler;Landroidx/recyclerview/widget/LayoutState;Landroidx/recyclerview/widget/RecyclerView$State;)I
    //   512: pop
    //   513: aload_0
    //   514: iconst_m1
    //   515: invokespecial setLayoutStateDirection : (I)V
    //   518: aload_0
    //   519: getfield mLayoutState : Landroidx/recyclerview/widget/LayoutState;
    //   522: astore #9
    //   524: aload #9
    //   526: aload #8
    //   528: getfield mPosition : I
    //   531: aload #9
    //   533: getfield mItemDirection : I
    //   536: iadd
    //   537: putfield mCurrentPosition : I
    //   540: aload_0
    //   541: aload_1
    //   542: aload #9
    //   544: aload_2
    //   545: invokespecial fill : (Landroidx/recyclerview/widget/RecyclerView$Recycler;Landroidx/recyclerview/widget/LayoutState;Landroidx/recyclerview/widget/RecyclerView$State;)I
    //   548: pop
    //   549: aload_0
    //   550: invokespecial repositionToWrapContentIfNecessary : ()V
    //   553: aload_0
    //   554: invokevirtual getChildCount : ()I
    //   557: ifle -> 598
    //   560: aload_0
    //   561: getfield mShouldReverseLayout : Z
    //   564: ifeq -> 584
    //   567: aload_0
    //   568: aload_1
    //   569: aload_2
    //   570: iconst_1
    //   571: invokespecial fixEndGap : (Landroidx/recyclerview/widget/RecyclerView$Recycler;Landroidx/recyclerview/widget/RecyclerView$State;Z)V
    //   574: aload_0
    //   575: aload_1
    //   576: aload_2
    //   577: iconst_0
    //   578: invokespecial fixStartGap : (Landroidx/recyclerview/widget/RecyclerView$Recycler;Landroidx/recyclerview/widget/RecyclerView$State;Z)V
    //   581: goto -> 598
    //   584: aload_0
    //   585: aload_1
    //   586: aload_2
    //   587: iconst_1
    //   588: invokespecial fixStartGap : (Landroidx/recyclerview/widget/RecyclerView$Recycler;Landroidx/recyclerview/widget/RecyclerView$State;Z)V
    //   591: aload_0
    //   592: aload_1
    //   593: aload_2
    //   594: iconst_0
    //   595: invokespecial fixEndGap : (Landroidx/recyclerview/widget/RecyclerView$Recycler;Landroidx/recyclerview/widget/RecyclerView$State;Z)V
    //   598: iload_3
    //   599: ifeq -> 674
    //   602: aload_2
    //   603: invokevirtual isPreLayout : ()Z
    //   606: ifne -> 674
    //   609: aload_0
    //   610: getfield mGapStrategy : I
    //   613: ifeq -> 643
    //   616: aload_0
    //   617: invokevirtual getChildCount : ()I
    //   620: ifle -> 643
    //   623: aload_0
    //   624: getfield mLaidOutInvalidFullSpan : Z
    //   627: ifne -> 637
    //   630: aload_0
    //   631: invokevirtual hasGapsToFix : ()Landroid/view/View;
    //   634: ifnull -> 643
    //   637: iconst_1
    //   638: istore #4
    //   640: goto -> 646
    //   643: iconst_0
    //   644: istore #4
    //   646: iload #4
    //   648: ifeq -> 674
    //   651: aload_0
    //   652: aload_0
    //   653: getfield mCheckForGapsRunnable : Ljava/lang/Runnable;
    //   656: invokevirtual removeCallbacks : (Ljava/lang/Runnable;)Z
    //   659: pop
    //   660: aload_0
    //   661: invokevirtual checkForGaps : ()Z
    //   664: ifeq -> 674
    //   667: iload #5
    //   669: istore #4
    //   671: goto -> 677
    //   674: iconst_0
    //   675: istore #4
    //   677: aload_2
    //   678: invokevirtual isPreLayout : ()Z
    //   681: ifeq -> 691
    //   684: aload_0
    //   685: getfield mAnchorInfo : Landroidx/recyclerview/widget/StaggeredGridLayoutManager$AnchorInfo;
    //   688: invokevirtual reset : ()V
    //   691: aload_0
    //   692: aload #8
    //   694: getfield mLayoutFromEnd : Z
    //   697: putfield mLastLayoutFromEnd : Z
    //   700: aload_0
    //   701: aload_0
    //   702: invokevirtual isLayoutRTL : ()Z
    //   705: putfield mLastLayoutRTL : Z
    //   708: iload #4
    //   710: ifeq -> 727
    //   713: aload_0
    //   714: getfield mAnchorInfo : Landroidx/recyclerview/widget/StaggeredGridLayoutManager$AnchorInfo;
    //   717: invokevirtual reset : ()V
    //   720: aload_0
    //   721: aload_1
    //   722: aload_2
    //   723: iconst_0
    //   724: invokespecial onLayoutChildren : (Landroidx/recyclerview/widget/RecyclerView$Recycler;Landroidx/recyclerview/widget/RecyclerView$State;Z)V
    //   727: return
  }
  
  private boolean preferLastSpan(int paramInt) {
    boolean bool;
    if (this.mOrientation == 0) {
      if (paramInt == -1) {
        bool = true;
      } else {
        bool = false;
      } 
      return (bool != this.mShouldReverseLayout);
    } 
    if (paramInt == -1) {
      bool = true;
    } else {
      bool = false;
    } 
    if (bool == this.mShouldReverseLayout) {
      bool = true;
    } else {
      bool = false;
    } 
    return (bool == isLayoutRTL());
  }
  
  private void prependViewToAllSpans(View paramView) {
    for (int i = this.mSpanCount - 1; i >= 0; i--)
      this.mSpans[i].prependToSpan(paramView); 
  }
  
  private void recycle(RecyclerView.Recycler paramRecycler, LayoutState paramLayoutState) {
    if (paramLayoutState.mRecycle) {
      if (paramLayoutState.mInfinite)
        return; 
      if (paramLayoutState.mAvailable == 0) {
        if (paramLayoutState.mLayoutDirection == -1) {
          recycleFromEnd(paramRecycler, paramLayoutState.mEndLine);
          return;
        } 
        recycleFromStart(paramRecycler, paramLayoutState.mStartLine);
        return;
      } 
      if (paramLayoutState.mLayoutDirection == -1) {
        int j = paramLayoutState.mStartLine;
        j -= getMaxStart(j);
        if (j < 0) {
          j = paramLayoutState.mEndLine;
        } else {
          j = paramLayoutState.mEndLine - Math.min(j, paramLayoutState.mAvailable);
        } 
        recycleFromEnd(paramRecycler, j);
        return;
      } 
      int i = getMinEnd(paramLayoutState.mEndLine) - paramLayoutState.mEndLine;
      if (i < 0) {
        i = paramLayoutState.mStartLine;
      } else {
        int j = paramLayoutState.mStartLine;
        i = Math.min(i, paramLayoutState.mAvailable) + j;
      } 
      recycleFromStart(paramRecycler, i);
    } 
  }
  
  private void recycleFromEnd(RecyclerView.Recycler paramRecycler, int paramInt) {
    int i = getChildCount() - 1;
    while (i >= 0) {
      View view = getChildAt(i);
      if (this.mPrimaryOrientation.getDecoratedStart(view) >= paramInt && this.mPrimaryOrientation.getTransformedStartWithDecoration(view) >= paramInt) {
        LayoutParams layoutParams = (LayoutParams)view.getLayoutParams();
        if (layoutParams.mFullSpan) {
          int k;
          byte b = 0;
          int j = 0;
          while (true) {
            k = b;
            if (j < this.mSpanCount) {
              if ((this.mSpans[j]).mViews.size() == 1)
                return; 
              j++;
              continue;
            } 
            break;
          } 
          while (k < this.mSpanCount) {
            this.mSpans[k].popEnd();
            k++;
          } 
        } else {
          if (layoutParams.mSpan.mViews.size() == 1)
            return; 
          layoutParams.mSpan.popEnd();
        } 
        removeAndRecycleView(view, paramRecycler);
        i--;
      } 
    } 
  }
  
  private void recycleFromStart(RecyclerView.Recycler paramRecycler, int paramInt) {
    while (getChildCount() > 0) {
      byte b = 0;
      View view = getChildAt(0);
      if (this.mPrimaryOrientation.getDecoratedEnd(view) <= paramInt && this.mPrimaryOrientation.getTransformedEndWithDecoration(view) <= paramInt) {
        LayoutParams layoutParams = (LayoutParams)view.getLayoutParams();
        if (layoutParams.mFullSpan) {
          int j;
          int i = 0;
          while (true) {
            j = b;
            if (i < this.mSpanCount) {
              if ((this.mSpans[i]).mViews.size() == 1)
                return; 
              i++;
              continue;
            } 
            break;
          } 
          while (j < this.mSpanCount) {
            this.mSpans[j].popStart();
            j++;
          } 
        } else {
          if (layoutParams.mSpan.mViews.size() == 1)
            return; 
          layoutParams.mSpan.popStart();
        } 
        removeAndRecycleView(view, paramRecycler);
      } 
    } 
  }
  
  private void repositionToWrapContentIfNecessary() {
    if (this.mSecondaryOrientation.getMode() == 1073741824)
      return; 
    int m = getChildCount();
    int j = 0;
    float f = 0.0F;
    int i;
    for (i = 0; i < m; i++) {
      View view = getChildAt(i);
      float f1 = this.mSecondaryOrientation.getDecoratedMeasurement(view);
      if (f1 >= f) {
        float f2 = f1;
        if (((LayoutParams)view.getLayoutParams()).isFullSpan())
          f2 = f1 * 1.0F / this.mSpanCount; 
        f = Math.max(f, f2);
      } 
    } 
    int n = this.mSizePerSpan;
    int k = Math.round(f * this.mSpanCount);
    i = k;
    if (this.mSecondaryOrientation.getMode() == Integer.MIN_VALUE)
      i = Math.min(k, this.mSecondaryOrientation.getTotalSpace()); 
    updateMeasureSpecs(i);
    i = j;
    if (this.mSizePerSpan == n)
      return; 
    while (i < m) {
      View view = getChildAt(i);
      LayoutParams layoutParams = (LayoutParams)view.getLayoutParams();
      if (!layoutParams.mFullSpan)
        if (isLayoutRTL() && this.mOrientation == 1) {
          j = this.mSpanCount;
          k = layoutParams.mSpan.mIndex;
          view.offsetLeftAndRight(-(j - 1 - k) * this.mSizePerSpan - -(j - 1 - k) * n);
        } else {
          k = layoutParams.mSpan.mIndex;
          j = this.mSizePerSpan * k;
          k *= n;
          if (this.mOrientation == 1) {
            view.offsetLeftAndRight(j - k);
          } else {
            view.offsetTopAndBottom(j - k);
          } 
        }  
      i++;
    } 
  }
  
  private void resolveShouldLayoutReverse() {
    if (this.mOrientation == 1 || !isLayoutRTL()) {
      this.mShouldReverseLayout = this.mReverseLayout;
      return;
    } 
    this.mShouldReverseLayout = this.mReverseLayout ^ true;
  }
  
  private void setLayoutStateDirection(int paramInt) {
    boolean bool1;
    LayoutState layoutState = this.mLayoutState;
    layoutState.mLayoutDirection = paramInt;
    boolean bool2 = this.mShouldReverseLayout;
    boolean bool = true;
    if (paramInt == -1) {
      bool1 = true;
    } else {
      bool1 = false;
    } 
    if (bool2 == bool1) {
      paramInt = bool;
    } else {
      paramInt = -1;
    } 
    layoutState.mItemDirection = paramInt;
  }
  
  private void updateAllRemainingSpans(int paramInt1, int paramInt2) {
    for (int i = 0; i < this.mSpanCount; i++) {
      if (!(this.mSpans[i]).mViews.isEmpty())
        updateRemainingSpans(this.mSpans[i], paramInt1, paramInt2); 
    } 
  }
  
  private boolean updateAnchorFromChildren(RecyclerView.State paramState, AnchorInfo paramAnchorInfo) {
    int i;
    if (this.mLastLayoutFromEnd) {
      i = findLastReferenceChildPosition(paramState.getItemCount());
    } else {
      i = findFirstReferenceChildPosition(paramState.getItemCount());
    } 
    paramAnchorInfo.mPosition = i;
    paramAnchorInfo.mOffset = Integer.MIN_VALUE;
    return true;
  }
  
  private void updateLayoutState(int paramInt, RecyclerView.State paramState) {
    // Byte code:
    //   0: aload_0
    //   1: getfield mLayoutState : Landroidx/recyclerview/widget/LayoutState;
    //   4: astore #7
    //   6: iconst_0
    //   7: istore #5
    //   9: aload #7
    //   11: iconst_0
    //   12: putfield mAvailable : I
    //   15: aload #7
    //   17: iload_1
    //   18: putfield mCurrentPosition : I
    //   21: aload_0
    //   22: invokevirtual isSmoothScrolling : ()Z
    //   25: ifeq -> 89
    //   28: aload_2
    //   29: invokevirtual getTargetScrollPosition : ()I
    //   32: istore_3
    //   33: iload_3
    //   34: iconst_m1
    //   35: if_icmpeq -> 89
    //   38: aload_0
    //   39: getfield mShouldReverseLayout : Z
    //   42: istore #6
    //   44: iload_3
    //   45: iload_1
    //   46: if_icmpge -> 55
    //   49: iconst_1
    //   50: istore #4
    //   52: goto -> 58
    //   55: iconst_0
    //   56: istore #4
    //   58: iload #6
    //   60: iload #4
    //   62: if_icmpne -> 76
    //   65: aload_0
    //   66: getfield mPrimaryOrientation : Landroidx/recyclerview/widget/OrientationHelper;
    //   69: invokevirtual getTotalSpace : ()I
    //   72: istore_1
    //   73: goto -> 91
    //   76: aload_0
    //   77: getfield mPrimaryOrientation : Landroidx/recyclerview/widget/OrientationHelper;
    //   80: invokevirtual getTotalSpace : ()I
    //   83: istore_3
    //   84: iconst_0
    //   85: istore_1
    //   86: goto -> 93
    //   89: iconst_0
    //   90: istore_1
    //   91: iconst_0
    //   92: istore_3
    //   93: aload_0
    //   94: invokevirtual getClipToPadding : ()Z
    //   97: ifeq -> 135
    //   100: aload_0
    //   101: getfield mLayoutState : Landroidx/recyclerview/widget/LayoutState;
    //   104: aload_0
    //   105: getfield mPrimaryOrientation : Landroidx/recyclerview/widget/OrientationHelper;
    //   108: invokevirtual getStartAfterPadding : ()I
    //   111: iload_3
    //   112: isub
    //   113: putfield mStartLine : I
    //   116: aload_0
    //   117: getfield mLayoutState : Landroidx/recyclerview/widget/LayoutState;
    //   120: aload_0
    //   121: getfield mPrimaryOrientation : Landroidx/recyclerview/widget/OrientationHelper;
    //   124: invokevirtual getEndAfterPadding : ()I
    //   127: iload_1
    //   128: iadd
    //   129: putfield mEndLine : I
    //   132: goto -> 160
    //   135: aload_0
    //   136: getfield mLayoutState : Landroidx/recyclerview/widget/LayoutState;
    //   139: aload_0
    //   140: getfield mPrimaryOrientation : Landroidx/recyclerview/widget/OrientationHelper;
    //   143: invokevirtual getEnd : ()I
    //   146: iload_1
    //   147: iadd
    //   148: putfield mEndLine : I
    //   151: aload_0
    //   152: getfield mLayoutState : Landroidx/recyclerview/widget/LayoutState;
    //   155: iload_3
    //   156: ineg
    //   157: putfield mStartLine : I
    //   160: aload_0
    //   161: getfield mLayoutState : Landroidx/recyclerview/widget/LayoutState;
    //   164: astore_2
    //   165: aload_2
    //   166: iconst_0
    //   167: putfield mStopInFocusable : Z
    //   170: aload_2
    //   171: iconst_1
    //   172: putfield mRecycle : Z
    //   175: iload #5
    //   177: istore #4
    //   179: aload_0
    //   180: getfield mPrimaryOrientation : Landroidx/recyclerview/widget/OrientationHelper;
    //   183: invokevirtual getMode : ()I
    //   186: ifne -> 206
    //   189: iload #5
    //   191: istore #4
    //   193: aload_0
    //   194: getfield mPrimaryOrientation : Landroidx/recyclerview/widget/OrientationHelper;
    //   197: invokevirtual getEnd : ()I
    //   200: ifne -> 206
    //   203: iconst_1
    //   204: istore #4
    //   206: aload_2
    //   207: iload #4
    //   209: putfield mInfinite : Z
    //   212: return
  }
  
  private void updateRemainingSpans(Span paramSpan, int paramInt1, int paramInt2) {
    int i = paramSpan.getDeletedSize();
    if (paramInt1 == -1) {
      if (paramSpan.getStartLine() + i <= paramInt2) {
        this.mRemainingSpans.set(paramSpan.mIndex, false);
        return;
      } 
    } else if (paramSpan.getEndLine() - i >= paramInt2) {
      this.mRemainingSpans.set(paramSpan.mIndex, false);
    } 
  }
  
  private int updateSpecWithExtra(int paramInt1, int paramInt2, int paramInt3) {
    if (paramInt2 == 0 && paramInt3 == 0)
      return paramInt1; 
    int i = View.MeasureSpec.getMode(paramInt1);
    return (i == Integer.MIN_VALUE || i == 1073741824) ? View.MeasureSpec.makeMeasureSpec(Math.max(0, View.MeasureSpec.getSize(paramInt1) - paramInt2 - paramInt3), i) : paramInt1;
  }
  
  boolean areAllEndsEqual() {
    int j = this.mSpans[0].getEndLine(-2147483648);
    for (int i = 1; i < this.mSpanCount; i++) {
      if (this.mSpans[i].getEndLine(-2147483648) != j)
        return false; 
    } 
    return true;
  }
  
  boolean areAllStartsEqual() {
    int j = this.mSpans[0].getStartLine(-2147483648);
    for (int i = 1; i < this.mSpanCount; i++) {
      if (this.mSpans[i].getStartLine(-2147483648) != j)
        return false; 
    } 
    return true;
  }
  
  public void assertNotInLayoutOrScroll(String paramString) {
    if (this.mPendingSavedState == null)
      super.assertNotInLayoutOrScroll(paramString); 
  }
  
  public boolean canScrollHorizontally() {
    return (this.mOrientation == 0);
  }
  
  public boolean canScrollVertically() {
    return (this.mOrientation == 1);
  }
  
  boolean checkForGaps() {
    if (getChildCount() != 0 && this.mGapStrategy != 0) {
      int i;
      int j;
      byte b;
      if (!isAttachedToWindow())
        return false; 
      if (this.mShouldReverseLayout) {
        i = getLastChildPosition();
        j = getFirstChildPosition();
      } else {
        i = getFirstChildPosition();
        j = getLastChildPosition();
      } 
      if (i == 0 && hasGapsToFix() != null) {
        this.mLazySpanLookup.clear();
        requestSimpleAnimationsInNextLayout();
        requestLayout();
        return true;
      } 
      if (!this.mLaidOutInvalidFullSpan)
        return false; 
      if (this.mShouldReverseLayout) {
        b = -1;
      } else {
        b = 1;
      } 
      LazySpanLookup lazySpanLookup = this.mLazySpanLookup;
      LazySpanLookup.FullSpanItem fullSpanItem1 = lazySpanLookup.getFirstFullSpanItemInRange(i, ++j, b, true);
      if (fullSpanItem1 == null) {
        this.mLaidOutInvalidFullSpan = false;
        this.mLazySpanLookup.forceInvalidateAfter(j);
        return false;
      } 
      LazySpanLookup.FullSpanItem fullSpanItem2 = this.mLazySpanLookup.getFirstFullSpanItemInRange(i, fullSpanItem1.mPosition, b * -1, true);
      if (fullSpanItem2 == null) {
        this.mLazySpanLookup.forceInvalidateAfter(fullSpanItem1.mPosition);
      } else {
        this.mLazySpanLookup.forceInvalidateAfter(fullSpanItem2.mPosition + 1);
      } 
      requestSimpleAnimationsInNextLayout();
      requestLayout();
      return true;
    } 
    return false;
  }
  
  public boolean checkLayoutParams(RecyclerView.LayoutParams paramLayoutParams) {
    return paramLayoutParams instanceof LayoutParams;
  }
  
  @RestrictTo({RestrictTo.Scope.LIBRARY})
  public void collectAdjacentPrefetchPositions(int paramInt1, int paramInt2, RecyclerView.State paramState, RecyclerView.LayoutManager.LayoutPrefetchRegistry paramLayoutPrefetchRegistry) {
    if (this.mOrientation != 0)
      paramInt1 = paramInt2; 
    if (getChildCount() != 0) {
      if (paramInt1 == 0)
        return; 
      prepareLayoutStateForDelta(paramInt1, paramState);
      int[] arrayOfInt = this.mPrefetchDistances;
      if (arrayOfInt == null || arrayOfInt.length < this.mSpanCount)
        this.mPrefetchDistances = new int[this.mSpanCount]; 
      boolean bool = false;
      paramInt2 = 0;
      for (paramInt1 = 0; paramInt2 < this.mSpanCount; paramInt1 = i) {
        LayoutState layoutState = this.mLayoutState;
        if (layoutState.mItemDirection == -1) {
          i = layoutState.mStartLine;
          j = this.mSpans[paramInt2].getStartLine(i);
        } else {
          i = this.mSpans[paramInt2].getEndLine(layoutState.mEndLine);
          j = this.mLayoutState.mEndLine;
        } 
        int j = i - j;
        int i = paramInt1;
        if (j >= 0) {
          this.mPrefetchDistances[paramInt1] = j;
          i = paramInt1 + 1;
        } 
        paramInt2++;
      } 
      Arrays.sort(this.mPrefetchDistances, 0, paramInt1);
      for (paramInt2 = bool; paramInt2 < paramInt1 && this.mLayoutState.hasMore(paramState); paramInt2++) {
        paramLayoutPrefetchRegistry.addPosition(this.mLayoutState.mCurrentPosition, this.mPrefetchDistances[paramInt2]);
        LayoutState layoutState = this.mLayoutState;
        layoutState.mCurrentPosition += layoutState.mItemDirection;
      } 
    } 
  }
  
  public int computeHorizontalScrollExtent(RecyclerView.State paramState) {
    return computeScrollExtent(paramState);
  }
  
  public int computeHorizontalScrollOffset(RecyclerView.State paramState) {
    return computeScrollOffset(paramState);
  }
  
  public int computeHorizontalScrollRange(RecyclerView.State paramState) {
    return computeScrollRange(paramState);
  }
  
  public PointF computeScrollVectorForPosition(int paramInt) {
    paramInt = calculateScrollDirectionForPosition(paramInt);
    PointF pointF = new PointF();
    if (paramInt == 0)
      return null; 
    if (this.mOrientation == 0) {
      pointF.x = paramInt;
      pointF.y = 0.0F;
      return pointF;
    } 
    pointF.x = 0.0F;
    pointF.y = paramInt;
    return pointF;
  }
  
  public int computeVerticalScrollExtent(RecyclerView.State paramState) {
    return computeScrollExtent(paramState);
  }
  
  public int computeVerticalScrollOffset(RecyclerView.State paramState) {
    return computeScrollOffset(paramState);
  }
  
  public int computeVerticalScrollRange(RecyclerView.State paramState) {
    return computeScrollRange(paramState);
  }
  
  public int[] findFirstCompletelyVisibleItemPositions(int[] paramArrayOfint) {
    if (paramArrayOfint == null) {
      paramArrayOfint = new int[this.mSpanCount];
    } else if (paramArrayOfint.length < this.mSpanCount) {
      StringBuilder stringBuilder = new StringBuilder();
      stringBuilder.append("Provided int[]'s size must be more than or equal to span count. Expected:");
      stringBuilder.append(this.mSpanCount);
      stringBuilder.append(", array size:");
      stringBuilder.append(paramArrayOfint.length);
      throw new IllegalArgumentException(stringBuilder.toString());
    } 
    for (int i = 0; i < this.mSpanCount; i++)
      paramArrayOfint[i] = this.mSpans[i].findFirstCompletelyVisibleItemPosition(); 
    return paramArrayOfint;
  }
  
  View findFirstVisibleItemClosestToEnd(boolean paramBoolean) {
    int j = this.mPrimaryOrientation.getStartAfterPadding();
    int k = this.mPrimaryOrientation.getEndAfterPadding();
    int i = getChildCount() - 1;
    View view;
    for (view = null; i >= 0; view = view1) {
      View view2 = getChildAt(i);
      int m = this.mPrimaryOrientation.getDecoratedStart(view2);
      int n = this.mPrimaryOrientation.getDecoratedEnd(view2);
      View view1 = view;
      if (n > j)
        if (m >= k) {
          view1 = view;
        } else if (n > k) {
          if (!paramBoolean)
            return view2; 
          view1 = view;
          if (view == null)
            view1 = view2; 
        } else {
          return view2;
        }  
      i--;
    } 
    return view;
  }
  
  View findFirstVisibleItemClosestToStart(boolean paramBoolean) {
    int j = this.mPrimaryOrientation.getStartAfterPadding();
    int k = this.mPrimaryOrientation.getEndAfterPadding();
    int m = getChildCount();
    View view = null;
    int i = 0;
    while (i < m) {
      View view2 = getChildAt(i);
      int n = this.mPrimaryOrientation.getDecoratedStart(view2);
      View view1 = view;
      if (this.mPrimaryOrientation.getDecoratedEnd(view2) > j)
        if (n >= k) {
          view1 = view;
        } else if (n < j) {
          if (!paramBoolean)
            return view2; 
          view1 = view;
          if (view == null)
            view1 = view2; 
        } else {
          return view2;
        }  
      i++;
      view = view1;
    } 
    return view;
  }
  
  int findFirstVisibleItemPositionInt() {
    View view;
    if (this.mShouldReverseLayout) {
      view = findFirstVisibleItemClosestToEnd(true);
    } else {
      view = findFirstVisibleItemClosestToStart(true);
    } 
    return (view == null) ? -1 : getPosition(view);
  }
  
  public int[] findFirstVisibleItemPositions(int[] paramArrayOfint) {
    if (paramArrayOfint == null) {
      paramArrayOfint = new int[this.mSpanCount];
    } else if (paramArrayOfint.length < this.mSpanCount) {
      StringBuilder stringBuilder = new StringBuilder();
      stringBuilder.append("Provided int[]'s size must be more than or equal to span count. Expected:");
      stringBuilder.append(this.mSpanCount);
      stringBuilder.append(", array size:");
      stringBuilder.append(paramArrayOfint.length);
      throw new IllegalArgumentException(stringBuilder.toString());
    } 
    for (int i = 0; i < this.mSpanCount; i++)
      paramArrayOfint[i] = this.mSpans[i].findFirstVisibleItemPosition(); 
    return paramArrayOfint;
  }
  
  public int[] findLastCompletelyVisibleItemPositions(int[] paramArrayOfint) {
    if (paramArrayOfint == null) {
      paramArrayOfint = new int[this.mSpanCount];
    } else if (paramArrayOfint.length < this.mSpanCount) {
      StringBuilder stringBuilder = new StringBuilder();
      stringBuilder.append("Provided int[]'s size must be more than or equal to span count. Expected:");
      stringBuilder.append(this.mSpanCount);
      stringBuilder.append(", array size:");
      stringBuilder.append(paramArrayOfint.length);
      throw new IllegalArgumentException(stringBuilder.toString());
    } 
    for (int i = 0; i < this.mSpanCount; i++)
      paramArrayOfint[i] = this.mSpans[i].findLastCompletelyVisibleItemPosition(); 
    return paramArrayOfint;
  }
  
  public int[] findLastVisibleItemPositions(int[] paramArrayOfint) {
    if (paramArrayOfint == null) {
      paramArrayOfint = new int[this.mSpanCount];
    } else if (paramArrayOfint.length < this.mSpanCount) {
      StringBuilder stringBuilder = new StringBuilder();
      stringBuilder.append("Provided int[]'s size must be more than or equal to span count. Expected:");
      stringBuilder.append(this.mSpanCount);
      stringBuilder.append(", array size:");
      stringBuilder.append(paramArrayOfint.length);
      throw new IllegalArgumentException(stringBuilder.toString());
    } 
    for (int i = 0; i < this.mSpanCount; i++)
      paramArrayOfint[i] = this.mSpans[i].findLastVisibleItemPosition(); 
    return paramArrayOfint;
  }
  
  public RecyclerView.LayoutParams generateDefaultLayoutParams() {
    return (this.mOrientation == 0) ? new LayoutParams(-2, -1) : new LayoutParams(-1, -2);
  }
  
  public RecyclerView.LayoutParams generateLayoutParams(Context paramContext, AttributeSet paramAttributeSet) {
    return new LayoutParams(paramContext, paramAttributeSet);
  }
  
  public RecyclerView.LayoutParams generateLayoutParams(ViewGroup.LayoutParams paramLayoutParams) {
    return (paramLayoutParams instanceof ViewGroup.MarginLayoutParams) ? new LayoutParams((ViewGroup.MarginLayoutParams)paramLayoutParams) : new LayoutParams(paramLayoutParams);
  }
  
  int getFirstChildPosition() {
    return (getChildCount() == 0) ? 0 : getPosition(getChildAt(0));
  }
  
  public int getGapStrategy() {
    return this.mGapStrategy;
  }
  
  int getLastChildPosition() {
    int i = getChildCount();
    return (i == 0) ? 0 : getPosition(getChildAt(i - 1));
  }
  
  public int getOrientation() {
    return this.mOrientation;
  }
  
  public boolean getReverseLayout() {
    return this.mReverseLayout;
  }
  
  public int getSpanCount() {
    return this.mSpanCount;
  }
  
  View hasGapsToFix() {
    // Byte code:
    //   0: aload_0
    //   1: invokevirtual getChildCount : ()I
    //   4: iconst_1
    //   5: isub
    //   6: istore_1
    //   7: new java/util/BitSet
    //   10: dup
    //   11: aload_0
    //   12: getfield mSpanCount : I
    //   15: invokespecial <init> : (I)V
    //   18: astore #7
    //   20: aload #7
    //   22: iconst_0
    //   23: aload_0
    //   24: getfield mSpanCount : I
    //   27: iconst_1
    //   28: invokevirtual set : (IIZ)V
    //   31: aload_0
    //   32: getfield mOrientation : I
    //   35: istore_2
    //   36: iconst_m1
    //   37: istore #5
    //   39: iload_2
    //   40: iconst_1
    //   41: if_icmpne -> 56
    //   44: aload_0
    //   45: invokevirtual isLayoutRTL : ()Z
    //   48: ifeq -> 56
    //   51: iconst_1
    //   52: istore_2
    //   53: goto -> 58
    //   56: iconst_m1
    //   57: istore_2
    //   58: aload_0
    //   59: getfield mShouldReverseLayout : Z
    //   62: ifeq -> 70
    //   65: iconst_m1
    //   66: istore_3
    //   67: goto -> 76
    //   70: iload_1
    //   71: iconst_1
    //   72: iadd
    //   73: istore_3
    //   74: iconst_0
    //   75: istore_1
    //   76: iload_1
    //   77: istore #4
    //   79: iload_1
    //   80: iload_3
    //   81: if_icmpge -> 90
    //   84: iconst_1
    //   85: istore #5
    //   87: iload_1
    //   88: istore #4
    //   90: iload #4
    //   92: iload_3
    //   93: if_icmpeq -> 349
    //   96: aload_0
    //   97: iload #4
    //   99: invokevirtual getChildAt : (I)Landroid/view/View;
    //   102: astore #8
    //   104: aload #8
    //   106: invokevirtual getLayoutParams : ()Landroid/view/ViewGroup$LayoutParams;
    //   109: checkcast androidx/recyclerview/widget/StaggeredGridLayoutManager$LayoutParams
    //   112: astore #9
    //   114: aload #7
    //   116: aload #9
    //   118: getfield mSpan : Landroidx/recyclerview/widget/StaggeredGridLayoutManager$Span;
    //   121: getfield mIndex : I
    //   124: invokevirtual get : (I)Z
    //   127: ifeq -> 158
    //   130: aload_0
    //   131: aload #9
    //   133: getfield mSpan : Landroidx/recyclerview/widget/StaggeredGridLayoutManager$Span;
    //   136: invokespecial checkSpanForGap : (Landroidx/recyclerview/widget/StaggeredGridLayoutManager$Span;)Z
    //   139: ifeq -> 145
    //   142: aload #8
    //   144: areturn
    //   145: aload #7
    //   147: aload #9
    //   149: getfield mSpan : Landroidx/recyclerview/widget/StaggeredGridLayoutManager$Span;
    //   152: getfield mIndex : I
    //   155: invokevirtual clear : (I)V
    //   158: aload #9
    //   160: getfield mFullSpan : Z
    //   163: ifeq -> 169
    //   166: goto -> 339
    //   169: iload #4
    //   171: iload #5
    //   173: iadd
    //   174: istore_1
    //   175: iload_1
    //   176: iload_3
    //   177: if_icmpeq -> 339
    //   180: aload_0
    //   181: iload_1
    //   182: invokevirtual getChildAt : (I)Landroid/view/View;
    //   185: astore #10
    //   187: aload_0
    //   188: getfield mShouldReverseLayout : Z
    //   191: ifeq -> 233
    //   194: aload_0
    //   195: getfield mPrimaryOrientation : Landroidx/recyclerview/widget/OrientationHelper;
    //   198: aload #8
    //   200: invokevirtual getDecoratedEnd : (Landroid/view/View;)I
    //   203: istore_1
    //   204: aload_0
    //   205: getfield mPrimaryOrientation : Landroidx/recyclerview/widget/OrientationHelper;
    //   208: aload #10
    //   210: invokevirtual getDecoratedEnd : (Landroid/view/View;)I
    //   213: istore #6
    //   215: iload_1
    //   216: iload #6
    //   218: if_icmpge -> 224
    //   221: aload #8
    //   223: areturn
    //   224: iload_1
    //   225: iload #6
    //   227: if_icmpne -> 274
    //   230: goto -> 269
    //   233: aload_0
    //   234: getfield mPrimaryOrientation : Landroidx/recyclerview/widget/OrientationHelper;
    //   237: aload #8
    //   239: invokevirtual getDecoratedStart : (Landroid/view/View;)I
    //   242: istore_1
    //   243: aload_0
    //   244: getfield mPrimaryOrientation : Landroidx/recyclerview/widget/OrientationHelper;
    //   247: aload #10
    //   249: invokevirtual getDecoratedStart : (Landroid/view/View;)I
    //   252: istore #6
    //   254: iload_1
    //   255: iload #6
    //   257: if_icmple -> 263
    //   260: aload #8
    //   262: areturn
    //   263: iload_1
    //   264: iload #6
    //   266: if_icmpne -> 274
    //   269: iconst_1
    //   270: istore_1
    //   271: goto -> 276
    //   274: iconst_0
    //   275: istore_1
    //   276: iload_1
    //   277: ifeq -> 339
    //   280: aload #10
    //   282: invokevirtual getLayoutParams : ()Landroid/view/ViewGroup$LayoutParams;
    //   285: checkcast androidx/recyclerview/widget/StaggeredGridLayoutManager$LayoutParams
    //   288: astore #10
    //   290: aload #9
    //   292: getfield mSpan : Landroidx/recyclerview/widget/StaggeredGridLayoutManager$Span;
    //   295: getfield mIndex : I
    //   298: aload #10
    //   300: getfield mSpan : Landroidx/recyclerview/widget/StaggeredGridLayoutManager$Span;
    //   303: getfield mIndex : I
    //   306: isub
    //   307: ifge -> 315
    //   310: iconst_1
    //   311: istore_1
    //   312: goto -> 317
    //   315: iconst_0
    //   316: istore_1
    //   317: iload_2
    //   318: ifge -> 327
    //   321: iconst_1
    //   322: istore #6
    //   324: goto -> 330
    //   327: iconst_0
    //   328: istore #6
    //   330: iload_1
    //   331: iload #6
    //   333: if_icmpeq -> 339
    //   336: aload #8
    //   338: areturn
    //   339: iload #4
    //   341: iload #5
    //   343: iadd
    //   344: istore #4
    //   346: goto -> 90
    //   349: aconst_null
    //   350: areturn
  }
  
  public void invalidateSpanAssignments() {
    this.mLazySpanLookup.clear();
    requestLayout();
  }
  
  public boolean isAutoMeasureEnabled() {
    return (this.mGapStrategy != 0);
  }
  
  boolean isLayoutRTL() {
    return (getLayoutDirection() == 1);
  }
  
  public void offsetChildrenHorizontal(int paramInt) {
    super.offsetChildrenHorizontal(paramInt);
    for (int i = 0; i < this.mSpanCount; i++)
      this.mSpans[i].onOffset(paramInt); 
  }
  
  public void offsetChildrenVertical(int paramInt) {
    super.offsetChildrenVertical(paramInt);
    for (int i = 0; i < this.mSpanCount; i++)
      this.mSpans[i].onOffset(paramInt); 
  }
  
  public void onAdapterChanged(@Nullable RecyclerView.Adapter paramAdapter1, @Nullable RecyclerView.Adapter paramAdapter2) {
    this.mLazySpanLookup.clear();
    for (int i = 0; i < this.mSpanCount; i++)
      this.mSpans[i].clear(); 
  }
  
  public void onDetachedFromWindow(RecyclerView paramRecyclerView, RecyclerView.Recycler paramRecycler) {
    super.onDetachedFromWindow(paramRecyclerView, paramRecycler);
    removeCallbacks(this.mCheckForGapsRunnable);
    for (int i = 0; i < this.mSpanCount; i++)
      this.mSpans[i].clear(); 
    paramRecyclerView.requestLayout();
  }
  
  @Nullable
  public View onFocusSearchFailed(View paramView, int paramInt, RecyclerView.Recycler paramRecycler, RecyclerView.State paramState) {
    if (getChildCount() == 0)
      return null; 
    paramView = findContainingItemView(paramView);
    if (paramView == null)
      return null; 
    resolveShouldLayoutReverse();
    int k = convertFocusDirectionToLayoutDirection(paramInt);
    if (k == Integer.MIN_VALUE)
      return null; 
    LayoutParams layoutParams = (LayoutParams)paramView.getLayoutParams();
    boolean bool1 = layoutParams.mFullSpan;
    Span span = layoutParams.mSpan;
    if (k == 1) {
      paramInt = getLastChildPosition();
    } else {
      paramInt = getFirstChildPosition();
    } 
    updateLayoutState(paramInt, paramState);
    setLayoutStateDirection(k);
    LayoutState layoutState = this.mLayoutState;
    layoutState.mCurrentPosition = layoutState.mItemDirection + paramInt;
    layoutState.mAvailable = (int)(this.mPrimaryOrientation.getTotalSpace() * 0.33333334F);
    layoutState = this.mLayoutState;
    layoutState.mStopInFocusable = true;
    int j = 0;
    layoutState.mRecycle = false;
    fill(paramRecycler, layoutState, paramState);
    this.mLastLayoutFromEnd = this.mShouldReverseLayout;
    if (!bool1) {
      View view = span.getFocusableViewAfter(paramInt, k);
      if (view != null && view != paramView)
        return view; 
    } 
    if (preferLastSpan(k)) {
      int m;
      for (m = this.mSpanCount - 1; m >= 0; m--) {
        View view = this.mSpans[m].getFocusableViewAfter(paramInt, k);
        if (view != null && view != paramView)
          return view; 
      } 
    } else {
      int m;
      for (m = 0; m < this.mSpanCount; m++) {
        View view = this.mSpans[m].getFocusableViewAfter(paramInt, k);
        if (view != null && view != paramView)
          return view; 
      } 
    } 
    boolean bool2 = this.mReverseLayout;
    if (k == -1) {
      paramInt = 1;
    } else {
      paramInt = 0;
    } 
    if ((bool2 ^ true) == paramInt) {
      paramInt = 1;
    } else {
      paramInt = 0;
    } 
    if (!bool1) {
      int m;
      if (paramInt != 0) {
        m = span.findFirstPartiallyVisibleItemPosition();
      } else {
        m = span.findLastPartiallyVisibleItemPosition();
      } 
      View view = findViewByPosition(m);
      if (view != null && view != paramView)
        return view; 
    } 
    int i = j;
    if (preferLastSpan(k)) {
      for (i = this.mSpanCount - 1; i >= 0; i--) {
        if (i != span.mIndex) {
          if (paramInt != 0) {
            j = this.mSpans[i].findFirstPartiallyVisibleItemPosition();
          } else {
            j = this.mSpans[i].findLastPartiallyVisibleItemPosition();
          } 
          View view = findViewByPosition(j);
          if (view != null && view != paramView)
            return view; 
        } 
      } 
    } else {
      while (i < this.mSpanCount) {
        if (paramInt != 0) {
          j = this.mSpans[i].findFirstPartiallyVisibleItemPosition();
        } else {
          j = this.mSpans[i].findLastPartiallyVisibleItemPosition();
        } 
        View view = findViewByPosition(j);
        if (view != null && view != paramView)
          return view; 
        i++;
      } 
    } 
    return null;
  }
  
  public void onInitializeAccessibilityEvent(AccessibilityEvent paramAccessibilityEvent) {
    super.onInitializeAccessibilityEvent(paramAccessibilityEvent);
    if (getChildCount() > 0) {
      View view1 = findFirstVisibleItemClosestToStart(false);
      View view2 = findFirstVisibleItemClosestToEnd(false);
      if (view1 != null) {
        if (view2 == null)
          return; 
        int i = getPosition(view1);
        int j = getPosition(view2);
        if (i < j) {
          paramAccessibilityEvent.setFromIndex(i);
          paramAccessibilityEvent.setToIndex(j);
          return;
        } 
        paramAccessibilityEvent.setFromIndex(j);
        paramAccessibilityEvent.setToIndex(i);
      } 
    } 
  }
  
  public void onItemsAdded(RecyclerView paramRecyclerView, int paramInt1, int paramInt2) {
    handleUpdate(paramInt1, paramInt2, 1);
  }
  
  public void onItemsChanged(RecyclerView paramRecyclerView) {
    this.mLazySpanLookup.clear();
    requestLayout();
  }
  
  public void onItemsMoved(RecyclerView paramRecyclerView, int paramInt1, int paramInt2, int paramInt3) {
    handleUpdate(paramInt1, paramInt2, 8);
  }
  
  public void onItemsRemoved(RecyclerView paramRecyclerView, int paramInt1, int paramInt2) {
    handleUpdate(paramInt1, paramInt2, 2);
  }
  
  public void onItemsUpdated(RecyclerView paramRecyclerView, int paramInt1, int paramInt2, Object paramObject) {
    handleUpdate(paramInt1, paramInt2, 4);
  }
  
  public void onLayoutChildren(RecyclerView.Recycler paramRecycler, RecyclerView.State paramState) {
    onLayoutChildren(paramRecycler, paramState, true);
  }
  
  public void onLayoutCompleted(RecyclerView.State paramState) {
    super.onLayoutCompleted(paramState);
    this.mPendingScrollPosition = -1;
    this.mPendingScrollPositionOffset = Integer.MIN_VALUE;
    this.mPendingSavedState = null;
    this.mAnchorInfo.reset();
  }
  
  public void onRestoreInstanceState(Parcelable paramParcelable) {
    if (paramParcelable instanceof SavedState) {
      paramParcelable = paramParcelable;
      this.mPendingSavedState = (SavedState)paramParcelable;
      if (this.mPendingScrollPosition != -1) {
        paramParcelable.invalidateAnchorPositionInfo();
        this.mPendingSavedState.invalidateSpanInfo();
      } 
      requestLayout();
    } 
  }
  
  public Parcelable onSaveInstanceState() {
    // Byte code:
    //   0: aload_0
    //   1: getfield mPendingSavedState : Landroidx/recyclerview/widget/StaggeredGridLayoutManager$SavedState;
    //   4: ifnull -> 19
    //   7: new androidx/recyclerview/widget/StaggeredGridLayoutManager$SavedState
    //   10: dup
    //   11: aload_0
    //   12: getfield mPendingSavedState : Landroidx/recyclerview/widget/StaggeredGridLayoutManager$SavedState;
    //   15: invokespecial <init> : (Landroidx/recyclerview/widget/StaggeredGridLayoutManager$SavedState;)V
    //   18: areturn
    //   19: new androidx/recyclerview/widget/StaggeredGridLayoutManager$SavedState
    //   22: dup
    //   23: invokespecial <init> : ()V
    //   26: astore #4
    //   28: aload #4
    //   30: aload_0
    //   31: getfield mReverseLayout : Z
    //   34: putfield mReverseLayout : Z
    //   37: aload #4
    //   39: aload_0
    //   40: getfield mLastLayoutFromEnd : Z
    //   43: putfield mAnchorLayoutFromEnd : Z
    //   46: aload #4
    //   48: aload_0
    //   49: getfield mLastLayoutRTL : Z
    //   52: putfield mLastLayoutRTL : Z
    //   55: aload_0
    //   56: getfield mLazySpanLookup : Landroidx/recyclerview/widget/StaggeredGridLayoutManager$LazySpanLookup;
    //   59: astore #5
    //   61: iconst_0
    //   62: istore_2
    //   63: aload #5
    //   65: ifnull -> 108
    //   68: aload #5
    //   70: getfield mData : [I
    //   73: astore #6
    //   75: aload #6
    //   77: ifnull -> 108
    //   80: aload #4
    //   82: aload #6
    //   84: putfield mSpanLookup : [I
    //   87: aload #4
    //   89: aload #6
    //   91: arraylength
    //   92: putfield mSpanLookupSize : I
    //   95: aload #4
    //   97: aload #5
    //   99: getfield mFullSpanItems : Ljava/util/List;
    //   102: putfield mFullSpanItems : Ljava/util/List;
    //   105: goto -> 114
    //   108: aload #4
    //   110: iconst_0
    //   111: putfield mSpanLookupSize : I
    //   114: aload_0
    //   115: invokevirtual getChildCount : ()I
    //   118: ifle -> 268
    //   121: aload_0
    //   122: getfield mLastLayoutFromEnd : Z
    //   125: ifeq -> 136
    //   128: aload_0
    //   129: invokevirtual getLastChildPosition : ()I
    //   132: istore_1
    //   133: goto -> 141
    //   136: aload_0
    //   137: invokevirtual getFirstChildPosition : ()I
    //   140: istore_1
    //   141: aload #4
    //   143: iload_1
    //   144: putfield mAnchorPosition : I
    //   147: aload #4
    //   149: aload_0
    //   150: invokevirtual findFirstVisibleItemPositionInt : ()I
    //   153: putfield mVisibleAnchorPosition : I
    //   156: aload_0
    //   157: getfield mSpanCount : I
    //   160: istore_1
    //   161: aload #4
    //   163: iload_1
    //   164: putfield mSpanOffsetsSize : I
    //   167: aload #4
    //   169: iload_1
    //   170: newarray int
    //   172: putfield mSpanOffsets : [I
    //   175: iload_2
    //   176: aload_0
    //   177: getfield mSpanCount : I
    //   180: if_icmpge -> 286
    //   183: aload_0
    //   184: getfield mLastLayoutFromEnd : Z
    //   187: ifeq -> 221
    //   190: aload_0
    //   191: getfield mSpans : [Landroidx/recyclerview/widget/StaggeredGridLayoutManager$Span;
    //   194: iload_2
    //   195: aaload
    //   196: ldc -2147483648
    //   198: invokevirtual getEndLine : (I)I
    //   201: istore_3
    //   202: iload_3
    //   203: istore_1
    //   204: iload_3
    //   205: ldc -2147483648
    //   207: if_icmpeq -> 253
    //   210: aload_0
    //   211: getfield mPrimaryOrientation : Landroidx/recyclerview/widget/OrientationHelper;
    //   214: invokevirtual getEndAfterPadding : ()I
    //   217: istore_1
    //   218: goto -> 249
    //   221: aload_0
    //   222: getfield mSpans : [Landroidx/recyclerview/widget/StaggeredGridLayoutManager$Span;
    //   225: iload_2
    //   226: aaload
    //   227: ldc -2147483648
    //   229: invokevirtual getStartLine : (I)I
    //   232: istore_3
    //   233: iload_3
    //   234: istore_1
    //   235: iload_3
    //   236: ldc -2147483648
    //   238: if_icmpeq -> 253
    //   241: aload_0
    //   242: getfield mPrimaryOrientation : Landroidx/recyclerview/widget/OrientationHelper;
    //   245: invokevirtual getStartAfterPadding : ()I
    //   248: istore_1
    //   249: iload_3
    //   250: iload_1
    //   251: isub
    //   252: istore_1
    //   253: aload #4
    //   255: getfield mSpanOffsets : [I
    //   258: iload_2
    //   259: iload_1
    //   260: iastore
    //   261: iload_2
    //   262: iconst_1
    //   263: iadd
    //   264: istore_2
    //   265: goto -> 175
    //   268: aload #4
    //   270: iconst_m1
    //   271: putfield mAnchorPosition : I
    //   274: aload #4
    //   276: iconst_m1
    //   277: putfield mVisibleAnchorPosition : I
    //   280: aload #4
    //   282: iconst_0
    //   283: putfield mSpanOffsetsSize : I
    //   286: aload #4
    //   288: areturn
  }
  
  public void onScrollStateChanged(int paramInt) {
    if (paramInt == 0)
      checkForGaps(); 
  }
  
  void prepareLayoutStateForDelta(int paramInt, RecyclerView.State paramState) {
    int i;
    byte b;
    if (paramInt > 0) {
      i = getLastChildPosition();
      b = 1;
    } else {
      i = getFirstChildPosition();
      b = -1;
    } 
    this.mLayoutState.mRecycle = true;
    updateLayoutState(i, paramState);
    setLayoutStateDirection(b);
    LayoutState layoutState = this.mLayoutState;
    layoutState.mCurrentPosition = i + layoutState.mItemDirection;
    layoutState.mAvailable = Math.abs(paramInt);
  }
  
  int scrollBy(int paramInt, RecyclerView.Recycler paramRecycler, RecyclerView.State paramState) {
    if (getChildCount() != 0) {
      if (paramInt == 0)
        return 0; 
      prepareLayoutStateForDelta(paramInt, paramState);
      int i = fill(paramRecycler, this.mLayoutState, paramState);
      if (this.mLayoutState.mAvailable >= i)
        if (paramInt < 0) {
          paramInt = -i;
        } else {
          paramInt = i;
        }  
      this.mPrimaryOrientation.offsetChildren(-paramInt);
      this.mLastLayoutFromEnd = this.mShouldReverseLayout;
      LayoutState layoutState = this.mLayoutState;
      layoutState.mAvailable = 0;
      recycle(paramRecycler, layoutState);
      return paramInt;
    } 
    return 0;
  }
  
  public int scrollHorizontallyBy(int paramInt, RecyclerView.Recycler paramRecycler, RecyclerView.State paramState) {
    return scrollBy(paramInt, paramRecycler, paramState);
  }
  
  public void scrollToPosition(int paramInt) {
    SavedState savedState = this.mPendingSavedState;
    if (savedState != null && savedState.mAnchorPosition != paramInt)
      savedState.invalidateAnchorPositionInfo(); 
    this.mPendingScrollPosition = paramInt;
    this.mPendingScrollPositionOffset = Integer.MIN_VALUE;
    requestLayout();
  }
  
  public void scrollToPositionWithOffset(int paramInt1, int paramInt2) {
    SavedState savedState = this.mPendingSavedState;
    if (savedState != null)
      savedState.invalidateAnchorPositionInfo(); 
    this.mPendingScrollPosition = paramInt1;
    this.mPendingScrollPositionOffset = paramInt2;
    requestLayout();
  }
  
  public int scrollVerticallyBy(int paramInt, RecyclerView.Recycler paramRecycler, RecyclerView.State paramState) {
    return scrollBy(paramInt, paramRecycler, paramState);
  }
  
  public void setGapStrategy(int paramInt) {
    assertNotInLayoutOrScroll(null);
    if (paramInt == this.mGapStrategy)
      return; 
    if (paramInt == 0 || paramInt == 2) {
      this.mGapStrategy = paramInt;
      requestLayout();
      return;
    } 
    throw new IllegalArgumentException("invalid gap strategy. Must be GAP_HANDLING_NONE or GAP_HANDLING_MOVE_ITEMS_BETWEEN_SPANS");
  }
  
  public void setMeasuredDimension(Rect paramRect, int paramInt1, int paramInt2) {
    int i = getPaddingLeft() + getPaddingRight();
    int j = getPaddingTop() + getPaddingBottom();
    if (this.mOrientation == 1) {
      paramInt2 = RecyclerView.LayoutManager.chooseSize(paramInt2, paramRect.height() + j, getMinimumHeight());
      i = RecyclerView.LayoutManager.chooseSize(paramInt1, this.mSizePerSpan * this.mSpanCount + i, getMinimumWidth());
      paramInt1 = paramInt2;
      paramInt2 = i;
    } else {
      paramInt1 = RecyclerView.LayoutManager.chooseSize(paramInt1, paramRect.width() + i, getMinimumWidth());
      i = RecyclerView.LayoutManager.chooseSize(paramInt2, this.mSizePerSpan * this.mSpanCount + j, getMinimumHeight());
      paramInt2 = paramInt1;
      paramInt1 = i;
    } 
    setMeasuredDimension(paramInt2, paramInt1);
  }
  
  public void setOrientation(int paramInt) {
    if (paramInt == 0 || paramInt == 1) {
      assertNotInLayoutOrScroll(null);
      if (paramInt == this.mOrientation)
        return; 
      this.mOrientation = paramInt;
      OrientationHelper orientationHelper = this.mPrimaryOrientation;
      this.mPrimaryOrientation = this.mSecondaryOrientation;
      this.mSecondaryOrientation = orientationHelper;
      requestLayout();
      return;
    } 
    throw new IllegalArgumentException("invalid orientation.");
  }
  
  public void setReverseLayout(boolean paramBoolean) {
    assertNotInLayoutOrScroll(null);
    SavedState savedState = this.mPendingSavedState;
    if (savedState != null && savedState.mReverseLayout != paramBoolean)
      savedState.mReverseLayout = paramBoolean; 
    this.mReverseLayout = paramBoolean;
    requestLayout();
  }
  
  public void setSpanCount(int paramInt) {
    assertNotInLayoutOrScroll(null);
    if (paramInt != this.mSpanCount) {
      invalidateSpanAssignments();
      this.mSpanCount = paramInt;
      this.mRemainingSpans = new BitSet(this.mSpanCount);
      this.mSpans = new Span[this.mSpanCount];
      for (paramInt = 0; paramInt < this.mSpanCount; paramInt++)
        this.mSpans[paramInt] = new Span(paramInt); 
      requestLayout();
    } 
  }
  
  public void smoothScrollToPosition(RecyclerView paramRecyclerView, RecyclerView.State paramState, int paramInt) {
    LinearSmoothScroller linearSmoothScroller = new LinearSmoothScroller(paramRecyclerView.getContext());
    linearSmoothScroller.setTargetPosition(paramInt);
    startSmoothScroll((RecyclerView.SmoothScroller)linearSmoothScroller);
  }
  
  public boolean supportsPredictiveItemAnimations() {
    return (this.mPendingSavedState == null);
  }
  
  boolean updateAnchorFromPendingData(RecyclerView.State paramState, AnchorInfo paramAnchorInfo) {
    boolean bool1 = paramState.isPreLayout();
    boolean bool = false;
    if (!bool1) {
      int i = this.mPendingScrollPosition;
      if (i == -1)
        return false; 
      if (i < 0 || i >= paramState.getItemCount()) {
        this.mPendingScrollPosition = -1;
        this.mPendingScrollPositionOffset = Integer.MIN_VALUE;
        return false;
      } 
      SavedState savedState = this.mPendingSavedState;
      if (savedState == null || savedState.mAnchorPosition == -1 || savedState.mSpanOffsetsSize < 1) {
        View view = findViewByPosition(this.mPendingScrollPosition);
        if (view != null) {
          if (this.mShouldReverseLayout) {
            i = getLastChildPosition();
          } else {
            i = getFirstChildPosition();
          } 
          paramAnchorInfo.mPosition = i;
          if (this.mPendingScrollPositionOffset != Integer.MIN_VALUE) {
            if (paramAnchorInfo.mLayoutFromEnd) {
              paramAnchorInfo.mOffset = this.mPrimaryOrientation.getEndAfterPadding() - this.mPendingScrollPositionOffset - this.mPrimaryOrientation.getDecoratedEnd(view);
              return true;
            } 
            paramAnchorInfo.mOffset = this.mPrimaryOrientation.getStartAfterPadding() + this.mPendingScrollPositionOffset - this.mPrimaryOrientation.getDecoratedStart(view);
            return true;
          } 
          if (this.mPrimaryOrientation.getDecoratedMeasurement(view) > this.mPrimaryOrientation.getTotalSpace()) {
            if (paramAnchorInfo.mLayoutFromEnd) {
              i = this.mPrimaryOrientation.getEndAfterPadding();
            } else {
              i = this.mPrimaryOrientation.getStartAfterPadding();
            } 
            paramAnchorInfo.mOffset = i;
            return true;
          } 
          i = this.mPrimaryOrientation.getDecoratedStart(view) - this.mPrimaryOrientation.getStartAfterPadding();
          if (i < 0) {
            paramAnchorInfo.mOffset = -i;
            return true;
          } 
          i = this.mPrimaryOrientation.getEndAfterPadding() - this.mPrimaryOrientation.getDecoratedEnd(view);
          if (i < 0) {
            paramAnchorInfo.mOffset = i;
            return true;
          } 
          paramAnchorInfo.mOffset = Integer.MIN_VALUE;
          return true;
        } 
        i = this.mPendingScrollPosition;
        paramAnchorInfo.mPosition = i;
        int j = this.mPendingScrollPositionOffset;
        if (j == Integer.MIN_VALUE) {
          if (calculateScrollDirectionForPosition(i) == 1)
            bool = true; 
          paramAnchorInfo.mLayoutFromEnd = bool;
          paramAnchorInfo.assignCoordinateFromPadding();
        } else {
          paramAnchorInfo.assignCoordinateFromPadding(j);
        } 
        paramAnchorInfo.mInvalidateOffsets = true;
        return true;
      } 
      paramAnchorInfo.mOffset = Integer.MIN_VALUE;
      paramAnchorInfo.mPosition = this.mPendingScrollPosition;
      return true;
    } 
    return false;
  }
  
  void updateAnchorInfoForLayout(RecyclerView.State paramState, AnchorInfo paramAnchorInfo) {
    if (updateAnchorFromPendingData(paramState, paramAnchorInfo))
      return; 
    if (updateAnchorFromChildren(paramState, paramAnchorInfo))
      return; 
    paramAnchorInfo.assignCoordinateFromPadding();
    paramAnchorInfo.mPosition = 0;
  }
  
  void updateMeasureSpecs(int paramInt) {
    this.mSizePerSpan = paramInt / this.mSpanCount;
    this.mFullSizeSpec = View.MeasureSpec.makeMeasureSpec(paramInt, this.mSecondaryOrientation.getMode());
  }
  
  class AnchorInfo {
    boolean mInvalidateOffsets;
    
    boolean mLayoutFromEnd;
    
    int mOffset;
    
    int mPosition;
    
    int[] mSpanReferenceLines;
    
    boolean mValid;
    
    AnchorInfo() {
      reset();
    }
    
    void assignCoordinateFromPadding() {
      int i;
      if (this.mLayoutFromEnd) {
        i = StaggeredGridLayoutManager.this.mPrimaryOrientation.getEndAfterPadding();
      } else {
        i = StaggeredGridLayoutManager.this.mPrimaryOrientation.getStartAfterPadding();
      } 
      this.mOffset = i;
    }
    
    void assignCoordinateFromPadding(int param1Int) {
      if (this.mLayoutFromEnd) {
        this.mOffset = StaggeredGridLayoutManager.this.mPrimaryOrientation.getEndAfterPadding() - param1Int;
        return;
      } 
      this.mOffset = StaggeredGridLayoutManager.this.mPrimaryOrientation.getStartAfterPadding() + param1Int;
    }
    
    void reset() {
      this.mPosition = -1;
      this.mOffset = Integer.MIN_VALUE;
      this.mLayoutFromEnd = false;
      this.mInvalidateOffsets = false;
      this.mValid = false;
      int[] arrayOfInt = this.mSpanReferenceLines;
      if (arrayOfInt != null)
        Arrays.fill(arrayOfInt, -1); 
    }
    
    void saveSpanReferenceLines(StaggeredGridLayoutManager.Span[] param1ArrayOfSpan) {
      int j = param1ArrayOfSpan.length;
      int[] arrayOfInt = this.mSpanReferenceLines;
      if (arrayOfInt == null || arrayOfInt.length < j)
        this.mSpanReferenceLines = new int[StaggeredGridLayoutManager.this.mSpans.length]; 
      for (int i = 0; i < j; i++)
        this.mSpanReferenceLines[i] = param1ArrayOfSpan[i].getStartLine(-2147483648); 
    }
  }
  
  public static class LayoutParams extends RecyclerView.LayoutParams {
    public static final int INVALID_SPAN_ID = -1;
    
    boolean mFullSpan;
    
    StaggeredGridLayoutManager.Span mSpan;
    
    public LayoutParams(int param1Int1, int param1Int2) {
      super(param1Int1, param1Int2);
    }
    
    public LayoutParams(Context param1Context, AttributeSet param1AttributeSet) {
      super(param1Context, param1AttributeSet);
    }
    
    public LayoutParams(ViewGroup.LayoutParams param1LayoutParams) {
      super(param1LayoutParams);
    }
    
    public LayoutParams(ViewGroup.MarginLayoutParams param1MarginLayoutParams) {
      super(param1MarginLayoutParams);
    }
    
    public LayoutParams(RecyclerView.LayoutParams param1LayoutParams) {
      super(param1LayoutParams);
    }
    
    public final int getSpanIndex() {
      StaggeredGridLayoutManager.Span span = this.mSpan;
      return (span == null) ? -1 : span.mIndex;
    }
    
    public boolean isFullSpan() {
      return this.mFullSpan;
    }
    
    public void setFullSpan(boolean param1Boolean) {
      this.mFullSpan = param1Boolean;
    }
  }
  
  static class LazySpanLookup {
    private static final int MIN_SIZE = 10;
    
    int[] mData;
    
    List<FullSpanItem> mFullSpanItems;
    
    private int invalidateFullSpansAfter(int param1Int) {
      // Byte code:
      //   0: aload_0
      //   1: getfield mFullSpanItems : Ljava/util/List;
      //   4: ifnonnull -> 9
      //   7: iconst_m1
      //   8: ireturn
      //   9: aload_0
      //   10: iload_1
      //   11: invokevirtual getFullSpanItem : (I)Landroidx/recyclerview/widget/StaggeredGridLayoutManager$LazySpanLookup$FullSpanItem;
      //   14: astore #4
      //   16: aload #4
      //   18: ifnull -> 33
      //   21: aload_0
      //   22: getfield mFullSpanItems : Ljava/util/List;
      //   25: aload #4
      //   27: invokeinterface remove : (Ljava/lang/Object;)Z
      //   32: pop
      //   33: aload_0
      //   34: getfield mFullSpanItems : Ljava/util/List;
      //   37: invokeinterface size : ()I
      //   42: istore_3
      //   43: iconst_0
      //   44: istore_2
      //   45: iload_2
      //   46: iload_3
      //   47: if_icmpge -> 80
      //   50: aload_0
      //   51: getfield mFullSpanItems : Ljava/util/List;
      //   54: iload_2
      //   55: invokeinterface get : (I)Ljava/lang/Object;
      //   60: checkcast androidx/recyclerview/widget/StaggeredGridLayoutManager$LazySpanLookup$FullSpanItem
      //   63: getfield mPosition : I
      //   66: iload_1
      //   67: if_icmplt -> 73
      //   70: goto -> 82
      //   73: iload_2
      //   74: iconst_1
      //   75: iadd
      //   76: istore_2
      //   77: goto -> 45
      //   80: iconst_m1
      //   81: istore_2
      //   82: iload_2
      //   83: iconst_m1
      //   84: if_icmpeq -> 119
      //   87: aload_0
      //   88: getfield mFullSpanItems : Ljava/util/List;
      //   91: iload_2
      //   92: invokeinterface get : (I)Ljava/lang/Object;
      //   97: checkcast androidx/recyclerview/widget/StaggeredGridLayoutManager$LazySpanLookup$FullSpanItem
      //   100: astore #4
      //   102: aload_0
      //   103: getfield mFullSpanItems : Ljava/util/List;
      //   106: iload_2
      //   107: invokeinterface remove : (I)Ljava/lang/Object;
      //   112: pop
      //   113: aload #4
      //   115: getfield mPosition : I
      //   118: ireturn
      //   119: iconst_m1
      //   120: ireturn
    }
    
    private void offsetFullSpansForAddition(int param1Int1, int param1Int2) {
      List<FullSpanItem> list = this.mFullSpanItems;
      if (list == null)
        return; 
      for (int i = list.size() - 1; i >= 0; i--) {
        FullSpanItem fullSpanItem = this.mFullSpanItems.get(i);
        int j = fullSpanItem.mPosition;
        if (j >= param1Int1)
          fullSpanItem.mPosition = j + param1Int2; 
      } 
    }
    
    private void offsetFullSpansForRemoval(int param1Int1, int param1Int2) {
      List<FullSpanItem> list = this.mFullSpanItems;
      if (list == null)
        return; 
      for (int i = list.size() - 1; i >= 0; i--) {
        FullSpanItem fullSpanItem = this.mFullSpanItems.get(i);
        int j = fullSpanItem.mPosition;
        if (j >= param1Int1)
          if (j < param1Int1 + param1Int2) {
            this.mFullSpanItems.remove(i);
          } else {
            fullSpanItem.mPosition = j - param1Int2;
          }  
      } 
    }
    
    public void addFullSpanItem(FullSpanItem param1FullSpanItem) {
      if (this.mFullSpanItems == null)
        this.mFullSpanItems = new ArrayList<FullSpanItem>(); 
      int j = this.mFullSpanItems.size();
      for (int i = 0; i < j; i++) {
        FullSpanItem fullSpanItem = this.mFullSpanItems.get(i);
        if (fullSpanItem.mPosition == param1FullSpanItem.mPosition)
          this.mFullSpanItems.remove(i); 
        if (fullSpanItem.mPosition >= param1FullSpanItem.mPosition) {
          this.mFullSpanItems.add(i, param1FullSpanItem);
          return;
        } 
      } 
      this.mFullSpanItems.add(param1FullSpanItem);
    }
    
    void clear() {
      int[] arrayOfInt = this.mData;
      if (arrayOfInt != null)
        Arrays.fill(arrayOfInt, -1); 
      this.mFullSpanItems = null;
    }
    
    void ensureSize(int param1Int) {
      int[] arrayOfInt = this.mData;
      if (arrayOfInt == null) {
        arrayOfInt = new int[Math.max(param1Int, 10) + 1];
        this.mData = arrayOfInt;
        Arrays.fill(arrayOfInt, -1);
        return;
      } 
      if (param1Int >= arrayOfInt.length) {
        int[] arrayOfInt1 = new int[sizeForPosition(param1Int)];
        this.mData = arrayOfInt1;
        System.arraycopy(arrayOfInt, 0, arrayOfInt1, 0, arrayOfInt.length);
        arrayOfInt1 = this.mData;
        Arrays.fill(arrayOfInt1, arrayOfInt.length, arrayOfInt1.length, -1);
      } 
    }
    
    int forceInvalidateAfter(int param1Int) {
      List<FullSpanItem> list = this.mFullSpanItems;
      if (list != null)
        for (int i = list.size() - 1; i >= 0; i--) {
          if (((FullSpanItem)this.mFullSpanItems.get(i)).mPosition >= param1Int)
            this.mFullSpanItems.remove(i); 
        }  
      return invalidateAfter(param1Int);
    }
    
    public FullSpanItem getFirstFullSpanItemInRange(int param1Int1, int param1Int2, int param1Int3, boolean param1Boolean) {
      List<FullSpanItem> list = this.mFullSpanItems;
      if (list == null)
        return null; 
      int j = list.size();
      int i;
      for (i = 0; i < j; i++) {
        FullSpanItem fullSpanItem = this.mFullSpanItems.get(i);
        int k = fullSpanItem.mPosition;
        if (k >= param1Int2)
          return null; 
        if (k >= param1Int1 && (param1Int3 == 0 || fullSpanItem.mGapDir == param1Int3 || (param1Boolean && fullSpanItem.mHasUnwantedGapAfter)))
          return fullSpanItem; 
      } 
      return null;
    }
    
    public FullSpanItem getFullSpanItem(int param1Int) {
      List<FullSpanItem> list = this.mFullSpanItems;
      if (list == null)
        return null; 
      for (int i = list.size() - 1; i >= 0; i--) {
        FullSpanItem fullSpanItem = this.mFullSpanItems.get(i);
        if (fullSpanItem.mPosition == param1Int)
          return fullSpanItem; 
      } 
      return null;
    }
    
    int getSpan(int param1Int) {
      int[] arrayOfInt = this.mData;
      return (arrayOfInt == null || param1Int >= arrayOfInt.length) ? -1 : arrayOfInt[param1Int];
    }
    
    int invalidateAfter(int param1Int) {
      int[] arrayOfInt = this.mData;
      if (arrayOfInt == null)
        return -1; 
      if (param1Int >= arrayOfInt.length)
        return -1; 
      int i = invalidateFullSpansAfter(param1Int);
      if (i == -1) {
        arrayOfInt = this.mData;
        Arrays.fill(arrayOfInt, param1Int, arrayOfInt.length, -1);
        return this.mData.length;
      } 
      i = Math.min(i + 1, this.mData.length);
      Arrays.fill(this.mData, param1Int, i, -1);
      return i;
    }
    
    void offsetForAddition(int param1Int1, int param1Int2) {
      int[] arrayOfInt = this.mData;
      if (arrayOfInt != null) {
        if (param1Int1 >= arrayOfInt.length)
          return; 
        int i = param1Int1 + param1Int2;
        ensureSize(i);
        arrayOfInt = this.mData;
        System.arraycopy(arrayOfInt, param1Int1, arrayOfInt, i, arrayOfInt.length - param1Int1 - param1Int2);
        Arrays.fill(this.mData, param1Int1, i, -1);
        offsetFullSpansForAddition(param1Int1, param1Int2);
      } 
    }
    
    void offsetForRemoval(int param1Int1, int param1Int2) {
      int[] arrayOfInt = this.mData;
      if (arrayOfInt != null) {
        if (param1Int1 >= arrayOfInt.length)
          return; 
        int i = param1Int1 + param1Int2;
        ensureSize(i);
        arrayOfInt = this.mData;
        System.arraycopy(arrayOfInt, i, arrayOfInt, param1Int1, arrayOfInt.length - param1Int1 - param1Int2);
        arrayOfInt = this.mData;
        Arrays.fill(arrayOfInt, arrayOfInt.length - param1Int2, arrayOfInt.length, -1);
        offsetFullSpansForRemoval(param1Int1, param1Int2);
      } 
    }
    
    void setSpan(int param1Int, StaggeredGridLayoutManager.Span param1Span) {
      ensureSize(param1Int);
      this.mData[param1Int] = param1Span.mIndex;
    }
    
    int sizeForPosition(int param1Int) {
      int i;
      for (i = this.mData.length; i <= param1Int; i *= 2);
      return i;
    }
    
    @SuppressLint({"BanParcelableUsage"})
    static class FullSpanItem implements Parcelable {
      public static final Parcelable.Creator<FullSpanItem> CREATOR = new Parcelable.Creator<FullSpanItem>() {
          public StaggeredGridLayoutManager.LazySpanLookup.FullSpanItem createFromParcel(Parcel param3Parcel) {
            return new StaggeredGridLayoutManager.LazySpanLookup.FullSpanItem(param3Parcel);
          }
          
          public StaggeredGridLayoutManager.LazySpanLookup.FullSpanItem[] newArray(int param3Int) {
            return new StaggeredGridLayoutManager.LazySpanLookup.FullSpanItem[param3Int];
          }
        };
      
      int mGapDir;
      
      int[] mGapPerSpan;
      
      boolean mHasUnwantedGapAfter;
      
      int mPosition;
      
      FullSpanItem() {}
      
      FullSpanItem(Parcel param2Parcel) {
        this.mPosition = param2Parcel.readInt();
        this.mGapDir = param2Parcel.readInt();
        int i = param2Parcel.readInt();
        boolean bool = true;
        if (i != 1)
          bool = false; 
        this.mHasUnwantedGapAfter = bool;
        i = param2Parcel.readInt();
        if (i > 0) {
          int[] arrayOfInt = new int[i];
          this.mGapPerSpan = arrayOfInt;
          param2Parcel.readIntArray(arrayOfInt);
        } 
      }
      
      public int describeContents() {
        return 0;
      }
      
      int getGapForSpan(int param2Int) {
        int[] arrayOfInt = this.mGapPerSpan;
        return (arrayOfInt == null) ? 0 : arrayOfInt[param2Int];
      }
      
      public String toString() {
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("FullSpanItem{mPosition=");
        stringBuilder.append(this.mPosition);
        stringBuilder.append(", mGapDir=");
        stringBuilder.append(this.mGapDir);
        stringBuilder.append(", mHasUnwantedGapAfter=");
        stringBuilder.append(this.mHasUnwantedGapAfter);
        stringBuilder.append(", mGapPerSpan=");
        stringBuilder.append(Arrays.toString(this.mGapPerSpan));
        stringBuilder.append('}');
        return stringBuilder.toString();
      }
      
      public void writeToParcel(Parcel param2Parcel, int param2Int) {
        throw new RuntimeException("d2j fail translate: java.lang.RuntimeException: can not merge I and Z\r\n\tat com.googlecode.dex2jar.ir.TypeClass.merge(TypeClass.java:100)\r\n\tat com.googlecode.dex2jar.ir.ts.TypeTransformer$TypeRef.updateTypeClass(TypeTransformer.java:174)\r\n\tat com.googlecode.dex2jar.ir.ts.TypeTransformer$TypeAnalyze.provideAs(TypeTransformer.java:780)\r\n\tat com.googlecode.dex2jar.ir.ts.TypeTransformer$TypeAnalyze.e1expr(TypeTransformer.java:496)\r\n\tat com.googlecode.dex2jar.ir.ts.TypeTransformer$TypeAnalyze.exExpr(TypeTransformer.java:713)\r\n\tat com.googlecode.dex2jar.ir.ts.TypeTransformer$TypeAnalyze.exExpr(TypeTransformer.java:703)\r\n\tat com.googlecode.dex2jar.ir.ts.TypeTransformer$TypeAnalyze.enexpr(TypeTransformer.java:698)\r\n\tat com.googlecode.dex2jar.ir.ts.TypeTransformer$TypeAnalyze.exExpr(TypeTransformer.java:719)\r\n\tat com.googlecode.dex2jar.ir.ts.TypeTransformer$TypeAnalyze.exExpr(TypeTransformer.java:703)\r\n\tat com.googlecode.dex2jar.ir.ts.TypeTransformer$TypeAnalyze.s1stmt(TypeTransformer.java:810)\r\n\tat com.googlecode.dex2jar.ir.ts.TypeTransformer$TypeAnalyze.sxStmt(TypeTransformer.java:840)\r\n\tat com.googlecode.dex2jar.ir.ts.TypeTransformer$TypeAnalyze.analyze(TypeTransformer.java:206)\r\n\tat com.googlecode.dex2jar.ir.ts.TypeTransformer.transform(TypeTransformer.java:44)\r\n\tat com.googlecode.d2j.dex.Dex2jar$2.optimize(Dex2jar.java:162)\r\n\tat com.googlecode.d2j.dex.Dex2Asm.convertCode(Dex2Asm.java:414)\r\n\tat com.googlecode.d2j.dex.ExDex2Asm.convertCode(ExDex2Asm.java:42)\r\n\tat com.googlecode.d2j.dex.Dex2jar$2.convertCode(Dex2jar.java:128)\r\n\tat com.googlecode.d2j.dex.Dex2Asm.convertMethod(Dex2Asm.java:509)\r\n\tat com.googlecode.d2j.dex.Dex2Asm.convertClass(Dex2Asm.java:406)\r\n\tat com.googlecode.d2j.dex.Dex2Asm.convertDex(Dex2Asm.java:422)\r\n\tat com.googlecode.d2j.dex.Dex2jar.doTranslate(Dex2jar.java:172)\r\n\tat com.googlecode.d2j.dex.Dex2jar.to(Dex2jar.java:272)\r\n\tat com.googlecode.dex2jar.tools.Dex2jarCmd.doCommandLine(Dex2jarCmd.java:108)\r\n\tat com.googlecode.dex2jar.tools.BaseCmd.doMain(BaseCmd.java:288)\r\n\tat com.googlecode.dex2jar.tools.Dex2jarCmd.main(Dex2jarCmd.java:32)\r\n");
      }
    }
    
    class null implements Parcelable.Creator<FullSpanItem> {
      public StaggeredGridLayoutManager.LazySpanLookup.FullSpanItem createFromParcel(Parcel param2Parcel) {
        return new StaggeredGridLayoutManager.LazySpanLookup.FullSpanItem(param2Parcel);
      }
      
      public StaggeredGridLayoutManager.LazySpanLookup.FullSpanItem[] newArray(int param2Int) {
        return new StaggeredGridLayoutManager.LazySpanLookup.FullSpanItem[param2Int];
      }
    }
  }
  
  @SuppressLint({"BanParcelableUsage"})
  static class FullSpanItem implements Parcelable {
    public static final Parcelable.Creator<FullSpanItem> CREATOR = new Parcelable.Creator<FullSpanItem>() {
        public StaggeredGridLayoutManager.LazySpanLookup.FullSpanItem createFromParcel(Parcel param3Parcel) {
          return new StaggeredGridLayoutManager.LazySpanLookup.FullSpanItem(param3Parcel);
        }
        
        public StaggeredGridLayoutManager.LazySpanLookup.FullSpanItem[] newArray(int param3Int) {
          return new StaggeredGridLayoutManager.LazySpanLookup.FullSpanItem[param3Int];
        }
      };
    
    int mGapDir;
    
    int[] mGapPerSpan;
    
    boolean mHasUnwantedGapAfter;
    
    int mPosition;
    
    FullSpanItem() {}
    
    FullSpanItem(Parcel param1Parcel) {
      this.mPosition = param1Parcel.readInt();
      this.mGapDir = param1Parcel.readInt();
      int i = param1Parcel.readInt();
      boolean bool = true;
      if (i != 1)
        bool = false; 
      this.mHasUnwantedGapAfter = bool;
      i = param1Parcel.readInt();
      if (i > 0) {
        int[] arrayOfInt = new int[i];
        this.mGapPerSpan = arrayOfInt;
        param1Parcel.readIntArray(arrayOfInt);
      } 
    }
    
    public int describeContents() {
      return 0;
    }
    
    int getGapForSpan(int param1Int) {
      int[] arrayOfInt = this.mGapPerSpan;
      return (arrayOfInt == null) ? 0 : arrayOfInt[param1Int];
    }
    
    public String toString() {
      StringBuilder stringBuilder = new StringBuilder();
      stringBuilder.append("FullSpanItem{mPosition=");
      stringBuilder.append(this.mPosition);
      stringBuilder.append(", mGapDir=");
      stringBuilder.append(this.mGapDir);
      stringBuilder.append(", mHasUnwantedGapAfter=");
      stringBuilder.append(this.mHasUnwantedGapAfter);
      stringBuilder.append(", mGapPerSpan=");
      stringBuilder.append(Arrays.toString(this.mGapPerSpan));
      stringBuilder.append('}');
      return stringBuilder.toString();
    }
    
    public void writeToParcel(Parcel param1Parcel, int param1Int) {
      throw new RuntimeException("d2j fail translate: java.lang.RuntimeException: can not merge I and Z\r\n\tat com.googlecode.dex2jar.ir.TypeClass.merge(TypeClass.java:100)\r\n\tat com.googlecode.dex2jar.ir.ts.TypeTransformer$TypeRef.updateTypeClass(TypeTransformer.java:174)\r\n\tat com.googlecode.dex2jar.ir.ts.TypeTransformer$TypeAnalyze.provideAs(TypeTransformer.java:780)\r\n\tat com.googlecode.dex2jar.ir.ts.TypeTransformer$TypeAnalyze.e1expr(TypeTransformer.java:496)\r\n\tat com.googlecode.dex2jar.ir.ts.TypeTransformer$TypeAnalyze.exExpr(TypeTransformer.java:713)\r\n\tat com.googlecode.dex2jar.ir.ts.TypeTransformer$TypeAnalyze.exExpr(TypeTransformer.java:703)\r\n\tat com.googlecode.dex2jar.ir.ts.TypeTransformer$TypeAnalyze.enexpr(TypeTransformer.java:698)\r\n\tat com.googlecode.dex2jar.ir.ts.TypeTransformer$TypeAnalyze.exExpr(TypeTransformer.java:719)\r\n\tat com.googlecode.dex2jar.ir.ts.TypeTransformer$TypeAnalyze.exExpr(TypeTransformer.java:703)\r\n\tat com.googlecode.dex2jar.ir.ts.TypeTransformer$TypeAnalyze.s1stmt(TypeTransformer.java:810)\r\n\tat com.googlecode.dex2jar.ir.ts.TypeTransformer$TypeAnalyze.sxStmt(TypeTransformer.java:840)\r\n\tat com.googlecode.dex2jar.ir.ts.TypeTransformer$TypeAnalyze.analyze(TypeTransformer.java:206)\r\n\tat com.googlecode.dex2jar.ir.ts.TypeTransformer.transform(TypeTransformer.java:44)\r\n\tat com.googlecode.d2j.dex.Dex2jar$2.optimize(Dex2jar.java:162)\r\n\tat com.googlecode.d2j.dex.Dex2Asm.convertCode(Dex2Asm.java:414)\r\n\tat com.googlecode.d2j.dex.ExDex2Asm.convertCode(ExDex2Asm.java:42)\r\n\tat com.googlecode.d2j.dex.Dex2jar$2.convertCode(Dex2jar.java:128)\r\n\tat com.googlecode.d2j.dex.Dex2Asm.convertMethod(Dex2Asm.java:509)\r\n\tat com.googlecode.d2j.dex.Dex2Asm.convertClass(Dex2Asm.java:406)\r\n\tat com.googlecode.d2j.dex.Dex2Asm.convertDex(Dex2Asm.java:422)\r\n\tat com.googlecode.d2j.dex.Dex2jar.doTranslate(Dex2jar.java:172)\r\n\tat com.googlecode.d2j.dex.Dex2jar.to(Dex2jar.java:272)\r\n\tat com.googlecode.dex2jar.tools.Dex2jarCmd.doCommandLine(Dex2jarCmd.java:108)\r\n\tat com.googlecode.dex2jar.tools.BaseCmd.doMain(BaseCmd.java:288)\r\n\tat com.googlecode.dex2jar.tools.Dex2jarCmd.main(Dex2jarCmd.java:32)\r\n");
    }
  }
  
  class null implements Parcelable.Creator<LazySpanLookup.FullSpanItem> {
    public StaggeredGridLayoutManager.LazySpanLookup.FullSpanItem createFromParcel(Parcel param1Parcel) {
      return new StaggeredGridLayoutManager.LazySpanLookup.FullSpanItem(param1Parcel);
    }
    
    public StaggeredGridLayoutManager.LazySpanLookup.FullSpanItem[] newArray(int param1Int) {
      return new StaggeredGridLayoutManager.LazySpanLookup.FullSpanItem[param1Int];
    }
  }
  
  @SuppressLint({"BanParcelableUsage"})
  @RestrictTo({RestrictTo.Scope.LIBRARY})
  public static class SavedState implements Parcelable {
    public static final Parcelable.Creator<SavedState> CREATOR = new Parcelable.Creator<SavedState>() {
        public StaggeredGridLayoutManager.SavedState createFromParcel(Parcel param2Parcel) {
          return new StaggeredGridLayoutManager.SavedState(param2Parcel);
        }
        
        public StaggeredGridLayoutManager.SavedState[] newArray(int param2Int) {
          return new StaggeredGridLayoutManager.SavedState[param2Int];
        }
      };
    
    boolean mAnchorLayoutFromEnd;
    
    int mAnchorPosition;
    
    List<StaggeredGridLayoutManager.LazySpanLookup.FullSpanItem> mFullSpanItems;
    
    boolean mLastLayoutRTL;
    
    boolean mReverseLayout;
    
    int[] mSpanLookup;
    
    int mSpanLookupSize;
    
    int[] mSpanOffsets;
    
    int mSpanOffsetsSize;
    
    int mVisibleAnchorPosition;
    
    public SavedState() {}
    
    SavedState(Parcel param1Parcel) {
      this.mAnchorPosition = param1Parcel.readInt();
      this.mVisibleAnchorPosition = param1Parcel.readInt();
      int i = param1Parcel.readInt();
      this.mSpanOffsetsSize = i;
      if (i > 0) {
        int[] arrayOfInt = new int[i];
        this.mSpanOffsets = arrayOfInt;
        param1Parcel.readIntArray(arrayOfInt);
      } 
      i = param1Parcel.readInt();
      this.mSpanLookupSize = i;
      if (i > 0) {
        int[] arrayOfInt = new int[i];
        this.mSpanLookup = arrayOfInt;
        param1Parcel.readIntArray(arrayOfInt);
      } 
      i = param1Parcel.readInt();
      boolean bool2 = false;
      if (i == 1) {
        bool1 = true;
      } else {
        bool1 = false;
      } 
      this.mReverseLayout = bool1;
      if (param1Parcel.readInt() == 1) {
        bool1 = true;
      } else {
        bool1 = false;
      } 
      this.mAnchorLayoutFromEnd = bool1;
      boolean bool1 = bool2;
      if (param1Parcel.readInt() == 1)
        bool1 = true; 
      this.mLastLayoutRTL = bool1;
      this.mFullSpanItems = param1Parcel.readArrayList(StaggeredGridLayoutManager.LazySpanLookup.FullSpanItem.class.getClassLoader());
    }
    
    public SavedState(SavedState param1SavedState) {
      this.mSpanOffsetsSize = param1SavedState.mSpanOffsetsSize;
      this.mAnchorPosition = param1SavedState.mAnchorPosition;
      this.mVisibleAnchorPosition = param1SavedState.mVisibleAnchorPosition;
      this.mSpanOffsets = param1SavedState.mSpanOffsets;
      this.mSpanLookupSize = param1SavedState.mSpanLookupSize;
      this.mSpanLookup = param1SavedState.mSpanLookup;
      this.mReverseLayout = param1SavedState.mReverseLayout;
      this.mAnchorLayoutFromEnd = param1SavedState.mAnchorLayoutFromEnd;
      this.mLastLayoutRTL = param1SavedState.mLastLayoutRTL;
      this.mFullSpanItems = param1SavedState.mFullSpanItems;
    }
    
    public int describeContents() {
      return 0;
    }
    
    void invalidateAnchorPositionInfo() {
      this.mSpanOffsets = null;
      this.mSpanOffsetsSize = 0;
      this.mAnchorPosition = -1;
      this.mVisibleAnchorPosition = -1;
    }
    
    void invalidateSpanInfo() {
      this.mSpanOffsets = null;
      this.mSpanOffsetsSize = 0;
      this.mSpanLookupSize = 0;
      this.mSpanLookup = null;
      this.mFullSpanItems = null;
    }
    
    public void writeToParcel(Parcel param1Parcel, int param1Int) {
      throw new RuntimeException("d2j fail translate: java.lang.RuntimeException: can not merge I and Z\r\n\tat com.googlecode.dex2jar.ir.TypeClass.merge(TypeClass.java:100)\r\n\tat com.googlecode.dex2jar.ir.ts.TypeTransformer$TypeRef.updateTypeClass(TypeTransformer.java:174)\r\n\tat com.googlecode.dex2jar.ir.ts.TypeTransformer$TypeAnalyze.provideAs(TypeTransformer.java:780)\r\n\tat com.googlecode.dex2jar.ir.ts.TypeTransformer$TypeAnalyze.e1expr(TypeTransformer.java:496)\r\n\tat com.googlecode.dex2jar.ir.ts.TypeTransformer$TypeAnalyze.exExpr(TypeTransformer.java:713)\r\n\tat com.googlecode.dex2jar.ir.ts.TypeTransformer$TypeAnalyze.exExpr(TypeTransformer.java:703)\r\n\tat com.googlecode.dex2jar.ir.ts.TypeTransformer$TypeAnalyze.enexpr(TypeTransformer.java:698)\r\n\tat com.googlecode.dex2jar.ir.ts.TypeTransformer$TypeAnalyze.exExpr(TypeTransformer.java:719)\r\n\tat com.googlecode.dex2jar.ir.ts.TypeTransformer$TypeAnalyze.exExpr(TypeTransformer.java:703)\r\n\tat com.googlecode.dex2jar.ir.ts.TypeTransformer$TypeAnalyze.s1stmt(TypeTransformer.java:810)\r\n\tat com.googlecode.dex2jar.ir.ts.TypeTransformer$TypeAnalyze.sxStmt(TypeTransformer.java:840)\r\n\tat com.googlecode.dex2jar.ir.ts.TypeTransformer$TypeAnalyze.analyze(TypeTransformer.java:206)\r\n\tat com.googlecode.dex2jar.ir.ts.TypeTransformer.transform(TypeTransformer.java:44)\r\n\tat com.googlecode.d2j.dex.Dex2jar$2.optimize(Dex2jar.java:162)\r\n\tat com.googlecode.d2j.dex.Dex2Asm.convertCode(Dex2Asm.java:414)\r\n\tat com.googlecode.d2j.dex.ExDex2Asm.convertCode(ExDex2Asm.java:42)\r\n\tat com.googlecode.d2j.dex.Dex2jar$2.convertCode(Dex2jar.java:128)\r\n\tat com.googlecode.d2j.dex.Dex2Asm.convertMethod(Dex2Asm.java:509)\r\n\tat com.googlecode.d2j.dex.Dex2Asm.convertClass(Dex2Asm.java:406)\r\n\tat com.googlecode.d2j.dex.Dex2Asm.convertDex(Dex2Asm.java:422)\r\n\tat com.googlecode.d2j.dex.Dex2jar.doTranslate(Dex2jar.java:172)\r\n\tat com.googlecode.d2j.dex.Dex2jar.to(Dex2jar.java:272)\r\n\tat com.googlecode.dex2jar.tools.Dex2jarCmd.doCommandLine(Dex2jarCmd.java:108)\r\n\tat com.googlecode.dex2jar.tools.BaseCmd.doMain(BaseCmd.java:288)\r\n\tat com.googlecode.dex2jar.tools.Dex2jarCmd.main(Dex2jarCmd.java:32)\r\n");
    }
  }
  
  class null implements Parcelable.Creator<SavedState> {
    public StaggeredGridLayoutManager.SavedState createFromParcel(Parcel param1Parcel) {
      return new StaggeredGridLayoutManager.SavedState(param1Parcel);
    }
    
    public StaggeredGridLayoutManager.SavedState[] newArray(int param1Int) {
      return new StaggeredGridLayoutManager.SavedState[param1Int];
    }
  }
  
  class Span {
    static final int INVALID_LINE = -2147483648;
    
    int mCachedEnd = Integer.MIN_VALUE;
    
    int mCachedStart = Integer.MIN_VALUE;
    
    int mDeletedSize = 0;
    
    final int mIndex;
    
    ArrayList<View> mViews = new ArrayList<View>();
    
    Span(int param1Int) {
      this.mIndex = param1Int;
    }
    
    void appendToSpan(View param1View) {
      StaggeredGridLayoutManager.LayoutParams layoutParams = getLayoutParams(param1View);
      layoutParams.mSpan = this;
      this.mViews.add(param1View);
      this.mCachedEnd = Integer.MIN_VALUE;
      if (this.mViews.size() == 1)
        this.mCachedStart = Integer.MIN_VALUE; 
      if (layoutParams.isItemRemoved() || layoutParams.isItemChanged())
        this.mDeletedSize += StaggeredGridLayoutManager.this.mPrimaryOrientation.getDecoratedMeasurement(param1View); 
    }
    
    void cacheReferenceLineAndClear(boolean param1Boolean, int param1Int) {
      int i;
      if (param1Boolean) {
        i = getEndLine(-2147483648);
      } else {
        i = getStartLine(-2147483648);
      } 
      clear();
      if (i == Integer.MIN_VALUE)
        return; 
      if ((param1Boolean && i < StaggeredGridLayoutManager.this.mPrimaryOrientation.getEndAfterPadding()) || (!param1Boolean && i > StaggeredGridLayoutManager.this.mPrimaryOrientation.getStartAfterPadding()))
        return; 
      int j = i;
      if (param1Int != Integer.MIN_VALUE)
        j = i + param1Int; 
      this.mCachedEnd = j;
      this.mCachedStart = j;
    }
    
    void calculateCachedEnd() {
      ArrayList<View> arrayList = this.mViews;
      View view = arrayList.get(arrayList.size() - 1);
      StaggeredGridLayoutManager.LayoutParams layoutParams = getLayoutParams(view);
      this.mCachedEnd = StaggeredGridLayoutManager.this.mPrimaryOrientation.getDecoratedEnd(view);
      if (layoutParams.mFullSpan) {
        StaggeredGridLayoutManager.LazySpanLookup.FullSpanItem fullSpanItem = StaggeredGridLayoutManager.this.mLazySpanLookup.getFullSpanItem(layoutParams.getViewLayoutPosition());
        if (fullSpanItem != null && fullSpanItem.mGapDir == 1)
          this.mCachedEnd += fullSpanItem.getGapForSpan(this.mIndex); 
      } 
    }
    
    void calculateCachedStart() {
      View view = this.mViews.get(0);
      StaggeredGridLayoutManager.LayoutParams layoutParams = getLayoutParams(view);
      this.mCachedStart = StaggeredGridLayoutManager.this.mPrimaryOrientation.getDecoratedStart(view);
      if (layoutParams.mFullSpan) {
        StaggeredGridLayoutManager.LazySpanLookup.FullSpanItem fullSpanItem = StaggeredGridLayoutManager.this.mLazySpanLookup.getFullSpanItem(layoutParams.getViewLayoutPosition());
        if (fullSpanItem != null && fullSpanItem.mGapDir == -1)
          this.mCachedStart -= fullSpanItem.getGapForSpan(this.mIndex); 
      } 
    }
    
    void clear() {
      this.mViews.clear();
      invalidateCache();
      this.mDeletedSize = 0;
    }
    
    public int findFirstCompletelyVisibleItemPosition() {
      return StaggeredGridLayoutManager.this.mReverseLayout ? findOneVisibleChild(this.mViews.size() - 1, -1, true) : findOneVisibleChild(0, this.mViews.size(), true);
    }
    
    public int findFirstPartiallyVisibleItemPosition() {
      return StaggeredGridLayoutManager.this.mReverseLayout ? findOnePartiallyVisibleChild(this.mViews.size() - 1, -1, true) : findOnePartiallyVisibleChild(0, this.mViews.size(), true);
    }
    
    public int findFirstVisibleItemPosition() {
      return StaggeredGridLayoutManager.this.mReverseLayout ? findOneVisibleChild(this.mViews.size() - 1, -1, false) : findOneVisibleChild(0, this.mViews.size(), false);
    }
    
    public int findLastCompletelyVisibleItemPosition() {
      return StaggeredGridLayoutManager.this.mReverseLayout ? findOneVisibleChild(0, this.mViews.size(), true) : findOneVisibleChild(this.mViews.size() - 1, -1, true);
    }
    
    public int findLastPartiallyVisibleItemPosition() {
      return StaggeredGridLayoutManager.this.mReverseLayout ? findOnePartiallyVisibleChild(0, this.mViews.size(), true) : findOnePartiallyVisibleChild(this.mViews.size() - 1, -1, true);
    }
    
    public int findLastVisibleItemPosition() {
      return StaggeredGridLayoutManager.this.mReverseLayout ? findOneVisibleChild(0, this.mViews.size(), false) : findOneVisibleChild(this.mViews.size() - 1, -1, false);
    }
    
    int findOnePartiallyOrCompletelyVisibleChild(int param1Int1, int param1Int2, boolean param1Boolean1, boolean param1Boolean2, boolean param1Boolean3) {
      byte b;
      int i = StaggeredGridLayoutManager.this.mPrimaryOrientation.getStartAfterPadding();
      int j = StaggeredGridLayoutManager.this.mPrimaryOrientation.getEndAfterPadding();
      if (param1Int2 > param1Int1) {
        b = 1;
      } else {
        b = -1;
      } 
      while (param1Int1 != param1Int2) {
        boolean bool1;
        View view = this.mViews.get(param1Int1);
        int k = StaggeredGridLayoutManager.this.mPrimaryOrientation.getDecoratedStart(view);
        int m = StaggeredGridLayoutManager.this.mPrimaryOrientation.getDecoratedEnd(view);
        boolean bool2 = false;
        if (param1Boolean3 ? (k <= j) : (k < j)) {
          bool1 = true;
        } else {
          bool1 = false;
        } 
        if (param1Boolean3 ? (m >= i) : (m > i))
          bool2 = true; 
        if (bool1 && bool2)
          if (param1Boolean1 && param1Boolean2) {
            if (k >= i && m <= j)
              return StaggeredGridLayoutManager.this.getPosition(view); 
          } else {
            if (param1Boolean2)
              return StaggeredGridLayoutManager.this.getPosition(view); 
            if (k < i || m > j)
              return StaggeredGridLayoutManager.this.getPosition(view); 
          }  
        param1Int1 += b;
      } 
      return -1;
    }
    
    int findOnePartiallyVisibleChild(int param1Int1, int param1Int2, boolean param1Boolean) {
      return findOnePartiallyOrCompletelyVisibleChild(param1Int1, param1Int2, false, false, param1Boolean);
    }
    
    int findOneVisibleChild(int param1Int1, int param1Int2, boolean param1Boolean) {
      return findOnePartiallyOrCompletelyVisibleChild(param1Int1, param1Int2, param1Boolean, true, false);
    }
    
    public int getDeletedSize() {
      return this.mDeletedSize;
    }
    
    int getEndLine() {
      int i = this.mCachedEnd;
      if (i != Integer.MIN_VALUE)
        return i; 
      calculateCachedEnd();
      return this.mCachedEnd;
    }
    
    int getEndLine(int param1Int) {
      int i = this.mCachedEnd;
      if (i != Integer.MIN_VALUE)
        return i; 
      if (this.mViews.size() == 0)
        return param1Int; 
      calculateCachedEnd();
      return this.mCachedEnd;
    }
    
    public View getFocusableViewAfter(int param1Int1, int param1Int2) {
      // Byte code:
      //   0: aconst_null
      //   1: astore #5
      //   3: aconst_null
      //   4: astore #4
      //   6: iload_2
      //   7: iconst_m1
      //   8: if_icmpne -> 123
      //   11: aload_0
      //   12: getfield mViews : Ljava/util/ArrayList;
      //   15: invokevirtual size : ()I
      //   18: istore_3
      //   19: iconst_0
      //   20: istore_2
      //   21: aload #4
      //   23: astore #5
      //   25: iload_2
      //   26: iload_3
      //   27: if_icmpge -> 238
      //   30: aload_0
      //   31: getfield mViews : Ljava/util/ArrayList;
      //   34: iload_2
      //   35: invokevirtual get : (I)Ljava/lang/Object;
      //   38: checkcast android/view/View
      //   41: astore #6
      //   43: aload_0
      //   44: getfield this$0 : Landroidx/recyclerview/widget/StaggeredGridLayoutManager;
      //   47: astore #7
      //   49: aload #7
      //   51: getfield mReverseLayout : Z
      //   54: ifeq -> 72
      //   57: aload #4
      //   59: astore #5
      //   61: aload #7
      //   63: aload #6
      //   65: invokevirtual getPosition : (Landroid/view/View;)I
      //   68: iload_1
      //   69: if_icmple -> 238
      //   72: aload_0
      //   73: getfield this$0 : Landroidx/recyclerview/widget/StaggeredGridLayoutManager;
      //   76: astore #5
      //   78: aload #5
      //   80: getfield mReverseLayout : Z
      //   83: ifne -> 100
      //   86: aload #5
      //   88: aload #6
      //   90: invokevirtual getPosition : (Landroid/view/View;)I
      //   93: iload_1
      //   94: if_icmplt -> 100
      //   97: aload #4
      //   99: areturn
      //   100: aload #4
      //   102: astore #5
      //   104: aload #6
      //   106: invokevirtual hasFocusable : ()Z
      //   109: ifeq -> 238
      //   112: iload_2
      //   113: iconst_1
      //   114: iadd
      //   115: istore_2
      //   116: aload #6
      //   118: astore #4
      //   120: goto -> 21
      //   123: aload_0
      //   124: getfield mViews : Ljava/util/ArrayList;
      //   127: invokevirtual size : ()I
      //   130: iconst_1
      //   131: isub
      //   132: istore_2
      //   133: aload #5
      //   135: astore #4
      //   137: aload #4
      //   139: astore #5
      //   141: iload_2
      //   142: iflt -> 238
      //   145: aload_0
      //   146: getfield mViews : Ljava/util/ArrayList;
      //   149: iload_2
      //   150: invokevirtual get : (I)Ljava/lang/Object;
      //   153: checkcast android/view/View
      //   156: astore #6
      //   158: aload_0
      //   159: getfield this$0 : Landroidx/recyclerview/widget/StaggeredGridLayoutManager;
      //   162: astore #7
      //   164: aload #7
      //   166: getfield mReverseLayout : Z
      //   169: ifeq -> 187
      //   172: aload #4
      //   174: astore #5
      //   176: aload #7
      //   178: aload #6
      //   180: invokevirtual getPosition : (Landroid/view/View;)I
      //   183: iload_1
      //   184: if_icmpge -> 238
      //   187: aload_0
      //   188: getfield this$0 : Landroidx/recyclerview/widget/StaggeredGridLayoutManager;
      //   191: astore #5
      //   193: aload #5
      //   195: getfield mReverseLayout : Z
      //   198: ifne -> 215
      //   201: aload #5
      //   203: aload #6
      //   205: invokevirtual getPosition : (Landroid/view/View;)I
      //   208: iload_1
      //   209: if_icmpgt -> 215
      //   212: aload #4
      //   214: areturn
      //   215: aload #4
      //   217: astore #5
      //   219: aload #6
      //   221: invokevirtual hasFocusable : ()Z
      //   224: ifeq -> 238
      //   227: iload_2
      //   228: iconst_1
      //   229: isub
      //   230: istore_2
      //   231: aload #6
      //   233: astore #4
      //   235: goto -> 137
      //   238: aload #5
      //   240: areturn
    }
    
    StaggeredGridLayoutManager.LayoutParams getLayoutParams(View param1View) {
      return (StaggeredGridLayoutManager.LayoutParams)param1View.getLayoutParams();
    }
    
    int getStartLine() {
      int i = this.mCachedStart;
      if (i != Integer.MIN_VALUE)
        return i; 
      calculateCachedStart();
      return this.mCachedStart;
    }
    
    int getStartLine(int param1Int) {
      int i = this.mCachedStart;
      if (i != Integer.MIN_VALUE)
        return i; 
      if (this.mViews.size() == 0)
        return param1Int; 
      calculateCachedStart();
      return this.mCachedStart;
    }
    
    void invalidateCache() {
      this.mCachedStart = Integer.MIN_VALUE;
      this.mCachedEnd = Integer.MIN_VALUE;
    }
    
    void onOffset(int param1Int) {
      int i = this.mCachedStart;
      if (i != Integer.MIN_VALUE)
        this.mCachedStart = i + param1Int; 
      i = this.mCachedEnd;
      if (i != Integer.MIN_VALUE)
        this.mCachedEnd = i + param1Int; 
    }
    
    void popEnd() {
      int i = this.mViews.size();
      View view = this.mViews.remove(i - 1);
      StaggeredGridLayoutManager.LayoutParams layoutParams = getLayoutParams(view);
      layoutParams.mSpan = null;
      if (layoutParams.isItemRemoved() || layoutParams.isItemChanged())
        this.mDeletedSize -= StaggeredGridLayoutManager.this.mPrimaryOrientation.getDecoratedMeasurement(view); 
      if (i == 1)
        this.mCachedStart = Integer.MIN_VALUE; 
      this.mCachedEnd = Integer.MIN_VALUE;
    }
    
    void popStart() {
      View view = this.mViews.remove(0);
      StaggeredGridLayoutManager.LayoutParams layoutParams = getLayoutParams(view);
      layoutParams.mSpan = null;
      if (this.mViews.size() == 0)
        this.mCachedEnd = Integer.MIN_VALUE; 
      if (layoutParams.isItemRemoved() || layoutParams.isItemChanged())
        this.mDeletedSize -= StaggeredGridLayoutManager.this.mPrimaryOrientation.getDecoratedMeasurement(view); 
      this.mCachedStart = Integer.MIN_VALUE;
    }
    
    void prependToSpan(View param1View) {
      StaggeredGridLayoutManager.LayoutParams layoutParams = getLayoutParams(param1View);
      layoutParams.mSpan = this;
      this.mViews.add(0, param1View);
      this.mCachedStart = Integer.MIN_VALUE;
      if (this.mViews.size() == 1)
        this.mCachedEnd = Integer.MIN_VALUE; 
      if (layoutParams.isItemRemoved() || layoutParams.isItemChanged())
        this.mDeletedSize += StaggeredGridLayoutManager.this.mPrimaryOrientation.getDecoratedMeasurement(param1View); 
    }
    
    void setLine(int param1Int) {
      this.mCachedStart = param1Int;
      this.mCachedEnd = param1Int;
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\MagicAI - AI Art & Anime Art-dex2jar.jar!\androidx\recyclerview\widget\StaggeredGridLayoutManager.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */