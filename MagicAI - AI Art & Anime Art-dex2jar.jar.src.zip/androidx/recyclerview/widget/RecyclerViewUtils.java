package androidx.recyclerview.widget;

public class RecyclerViewUtils {
  public static void setItemViewType(RecyclerView.ViewHolder paramViewHolder, int paramInt) {
    paramViewHolder.mItemViewType = paramInt;
  }
}


/* Location:              C:\soft\dex2jar-2.0\MagicAI - AI Art & Anime Art-dex2jar.jar!\androidx\recyclerview\widget\RecyclerViewUtils.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */