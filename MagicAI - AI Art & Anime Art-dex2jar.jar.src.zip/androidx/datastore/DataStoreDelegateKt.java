package androidx.datastore;

import android.content.Context;
import androidx.datastore.core.DataMigration;
import androidx.datastore.core.DataStore;
import androidx.datastore.core.Serializer;
import androidx.datastore.core.handlers.ReplaceFileCorruptionHandler;
import java.util.List;
import kotlin.Metadata;
import kotlin.collections.CollectionsKt;
import kotlin.coroutines.CoroutineContext;
import kotlin.jvm.functions.Function1;
import kotlin.jvm.internal.Intrinsics;
import kotlin.jvm.internal.Lambda;
import kotlin.properties.ReadOnlyProperty;
import kotlinx.coroutines.CoroutineScope;
import kotlinx.coroutines.CoroutineScopeKt;
import kotlinx.coroutines.Dispatchers;
import kotlinx.coroutines.SupervisorKt;

@Metadata(d1 = {"\0008\n\000\n\002\030\002\n\002\030\002\n\002\030\002\n\002\b\002\n\002\020\016\n\000\n\002\030\002\n\000\n\002\030\002\n\000\n\002\030\002\n\002\020 \n\002\030\002\n\000\n\002\030\002\n\000\032r\020\000\032\024\022\004\022\0020\002\022\n\022\b\022\004\022\002H\0040\0030\001\"\004\b\000\020\0042\006\020\005\032\0020\0062\f\020\007\032\b\022\004\022\002H\0040\b2\020\b\002\020\t\032\n\022\004\022\002H\004\030\0010\n2 \b\002\020\013\032\032\022\004\022\0020\002\022\020\022\016\022\n\022\b\022\004\022\002H\0040\0160\r0\f2\b\b\002\020\017\032\0020\020¨\006\021"}, d2 = {"dataStore", "Lkotlin/properties/ReadOnlyProperty;", "Landroid/content/Context;", "Landroidx/datastore/core/DataStore;", "T", "fileName", "", "serializer", "Landroidx/datastore/core/Serializer;", "corruptionHandler", "Landroidx/datastore/core/handlers/ReplaceFileCorruptionHandler;", "produceMigrations", "Lkotlin/Function1;", "", "Landroidx/datastore/core/DataMigration;", "scope", "Lkotlinx/coroutines/CoroutineScope;", "datastore_release"}, k = 2, mv = {1, 5, 1}, xi = 48)
public final class DataStoreDelegateKt {
  public static final <T> ReadOnlyProperty<Context, DataStore<T>> dataStore(String paramString, Serializer<T> paramSerializer, ReplaceFileCorruptionHandler<T> paramReplaceFileCorruptionHandler, Function1<? super Context, ? extends List<? extends DataMigration<T>>> paramFunction1, CoroutineScope paramCoroutineScope) {
    Intrinsics.checkNotNullParameter(paramString, "fileName");
    Intrinsics.checkNotNullParameter(paramSerializer, "serializer");
    Intrinsics.checkNotNullParameter(paramFunction1, "produceMigrations");
    Intrinsics.checkNotNullParameter(paramCoroutineScope, "scope");
    return (ReadOnlyProperty<Context, DataStore<T>>)new DataStoreSingletonDelegate(paramString, paramSerializer, paramReplaceFileCorruptionHandler, paramFunction1, paramCoroutineScope);
  }
  
  @Metadata(d1 = {"\000\022\n\000\n\002\030\002\n\000\n\002\020 \n\002\030\002\n\000\020\005\032\016\022\n\022\b\022\004\022\0028\0000\0040\003\"\004\b\000\020\0002\006\020\002\032\0020\001H\n"}, d2 = {"T", "Landroid/content/Context;", "it", "", "Landroidx/datastore/core/DataMigration;", "<anonymous>"}, k = 3, mv = {1, 5, 1})
  static final class DataStoreDelegateKt$dataStore$1 extends Lambda implements Function1 {
    public static final DataStoreDelegateKt$dataStore$1 INSTANCE = new DataStoreDelegateKt$dataStore$1();
    
    DataStoreDelegateKt$dataStore$1() {
      super(1);
    }
    
    public final List invoke(Context param1Context) {
      Intrinsics.checkNotNullParameter(param1Context, "it");
      return CollectionsKt.emptyList();
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\MagicAI - AI Art & Anime Art-dex2jar.jar!\androidx\datastore\DataStoreDelegateKt.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */