package androidx.datastore.preferences;

import android.content.Context;
import androidx.datastore.DataStoreFile;
import java.io.File;
import kotlin.Metadata;
import kotlin.jvm.internal.Intrinsics;

@Metadata(d1 = {"\000\022\n\000\n\002\030\002\n\002\030\002\n\000\n\002\020\016\n\000\032\022\020\000\032\0020\001*\0020\0022\006\020\003\032\0020\004¨\006\005"}, d2 = {"preferencesDataStoreFile", "Ljava/io/File;", "Landroid/content/Context;", "name", "", "datastore-preferences_release"}, k = 2, mv = {1, 5, 1}, xi = 48)
public final class PreferenceDataStoreFile {
  public static final File preferencesDataStoreFile(Context paramContext, String paramString) {
    Intrinsics.checkNotNullParameter(paramContext, "<this>");
    Intrinsics.checkNotNullParameter(paramString, "name");
    return DataStoreFile.dataStoreFile(paramContext, Intrinsics.stringPlus(paramString, ".preferences_pb"));
  }
}


/* Location:              C:\soft\dex2jar-2.0\MagicAI - AI Art & Anime Art-dex2jar.jar!\androidx\datastore\preferences\PreferenceDataStoreFile.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */