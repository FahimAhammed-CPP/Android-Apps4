package androidx.datastore.preferences.core;

import java.util.Set;
import kotlin.Metadata;
import kotlin.jvm.internal.Intrinsics;

@Metadata(d1 = {"\000<\n\000\n\002\030\002\n\002\020\013\n\000\n\002\020\016\n\002\b\002\n\002\020\006\n\002\b\002\n\002\020\007\n\002\b\002\n\002\020\b\n\002\b\002\n\002\020\t\n\002\b\004\n\002\020\"\n\002\b\002\032\033\020\000\032\b\022\004\022\0020\0020\0012\006\020\003\032\0020\004H\007¢\006\002\b\005\032\033\020\006\032\b\022\004\022\0020\0070\0012\006\020\003\032\0020\004H\007¢\006\002\b\b\032\033\020\t\032\b\022\004\022\0020\n0\0012\006\020\003\032\0020\004H\007¢\006\002\b\013\032\033\020\f\032\b\022\004\022\0020\r0\0012\006\020\003\032\0020\004H\007¢\006\002\b\016\032\033\020\017\032\b\022\004\022\0020\0200\0012\006\020\003\032\0020\004H\007¢\006\002\b\021\032\033\020\022\032\b\022\004\022\0020\0040\0012\006\020\003\032\0020\004H\007¢\006\002\b\023\032!\020\024\032\016\022\n\022\b\022\004\022\0020\0040\0250\0012\006\020\003\032\0020\004H\007¢\006\002\b\026¨\006\027"}, d2 = {"booleanPreferencesKey", "Landroidx/datastore/preferences/core/Preferences$Key;", "", "name", "", "booleanKey", "doublePreferencesKey", "", "doubleKey", "floatPreferencesKey", "", "floatKey", "intPreferencesKey", "", "intKey", "longPreferencesKey", "", "longKey", "stringPreferencesKey", "stringKey", "stringSetPreferencesKey", "", "stringSetKey", "datastore-preferences-core"}, k = 2, mv = {1, 5, 1}, xi = 48)
public final class PreferencesKeys {
  public static final Preferences.Key<Boolean> booleanKey(String paramString) {
    Intrinsics.checkNotNullParameter(paramString, "name");
    return new Preferences.Key(paramString);
  }
  
  public static final Preferences.Key<Double> doubleKey(String paramString) {
    Intrinsics.checkNotNullParameter(paramString, "name");
    return new Preferences.Key(paramString);
  }
  
  public static final Preferences.Key<Float> floatKey(String paramString) {
    Intrinsics.checkNotNullParameter(paramString, "name");
    return new Preferences.Key(paramString);
  }
  
  public static final Preferences.Key<Integer> intKey(String paramString) {
    Intrinsics.checkNotNullParameter(paramString, "name");
    return new Preferences.Key(paramString);
  }
  
  public static final Preferences.Key<Long> longKey(String paramString) {
    Intrinsics.checkNotNullParameter(paramString, "name");
    return new Preferences.Key(paramString);
  }
  
  public static final Preferences.Key<String> stringKey(String paramString) {
    Intrinsics.checkNotNullParameter(paramString, "name");
    return new Preferences.Key(paramString);
  }
  
  public static final Preferences.Key<Set<String>> stringSetKey(String paramString) {
    Intrinsics.checkNotNullParameter(paramString, "name");
    return new Preferences.Key(paramString);
  }
}


/* Location:              C:\soft\dex2jar-2.0\MagicAI - AI Art & Anime Art-dex2jar.jar!\androidx\datastore\preferences\core\PreferencesKeys.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */