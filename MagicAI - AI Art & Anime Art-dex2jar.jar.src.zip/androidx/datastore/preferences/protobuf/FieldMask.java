package androidx.datastore.preferences.protobuf;

import java.io.IOException;
import java.io.InputStream;
import java.nio.ByteBuffer;
import java.util.Collections;
import java.util.List;

public final class FieldMask extends GeneratedMessageLite<FieldMask, FieldMask.Builder> implements FieldMaskOrBuilder {
  private static final FieldMask DEFAULT_INSTANCE;
  
  private static volatile Parser<FieldMask> PARSER;
  
  public static final int PATHS_FIELD_NUMBER = 1;
  
  private Internal.ProtobufList<String> paths_ = GeneratedMessageLite.emptyProtobufList();
  
  static {
    FieldMask fieldMask = new FieldMask();
    DEFAULT_INSTANCE = fieldMask;
    GeneratedMessageLite.registerDefaultInstance(FieldMask.class, fieldMask);
  }
  
  private void addAllPaths(Iterable<String> paramIterable) {
    ensurePathsIsMutable();
    AbstractMessageLite.addAll(paramIterable, this.paths_);
  }
  
  private void addPaths(String paramString) {
    paramString.getClass();
    ensurePathsIsMutable();
    this.paths_.add(paramString);
  }
  
  private void addPathsBytes(ByteString paramByteString) {
    paramByteString.getClass();
    AbstractMessageLite.checkByteStringIsUtf8(paramByteString);
    ensurePathsIsMutable();
    this.paths_.add(paramByteString.toStringUtf8());
  }
  
  private void clearPaths() {
    this.paths_ = GeneratedMessageLite.emptyProtobufList();
  }
  
  private void ensurePathsIsMutable() {
    if (!this.paths_.isModifiable())
      this.paths_ = GeneratedMessageLite.mutableCopy(this.paths_); 
  }
  
  public static FieldMask getDefaultInstance() {
    return DEFAULT_INSTANCE;
  }
  
  public static Builder newBuilder() {
    return (Builder)DEFAULT_INSTANCE.createBuilder();
  }
  
  public static Builder newBuilder(FieldMask paramFieldMask) {
    return (Builder)DEFAULT_INSTANCE.createBuilder(paramFieldMask);
  }
  
  public static FieldMask parseDelimitedFrom(InputStream paramInputStream) throws IOException {
    return (FieldMask)GeneratedMessageLite.parseDelimitedFrom(DEFAULT_INSTANCE, paramInputStream);
  }
  
  public static FieldMask parseDelimitedFrom(InputStream paramInputStream, ExtensionRegistryLite paramExtensionRegistryLite) throws IOException {
    return (FieldMask)GeneratedMessageLite.parseDelimitedFrom(DEFAULT_INSTANCE, paramInputStream, paramExtensionRegistryLite);
  }
  
  public static FieldMask parseFrom(ByteString paramByteString) throws InvalidProtocolBufferException {
    return (FieldMask)GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, paramByteString);
  }
  
  public static FieldMask parseFrom(ByteString paramByteString, ExtensionRegistryLite paramExtensionRegistryLite) throws InvalidProtocolBufferException {
    return (FieldMask)GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, paramByteString, paramExtensionRegistryLite);
  }
  
  public static FieldMask parseFrom(CodedInputStream paramCodedInputStream) throws IOException {
    return (FieldMask)GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, paramCodedInputStream);
  }
  
  public static FieldMask parseFrom(CodedInputStream paramCodedInputStream, ExtensionRegistryLite paramExtensionRegistryLite) throws IOException {
    return (FieldMask)GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, paramCodedInputStream, paramExtensionRegistryLite);
  }
  
  public static FieldMask parseFrom(InputStream paramInputStream) throws IOException {
    return (FieldMask)GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, paramInputStream);
  }
  
  public static FieldMask parseFrom(InputStream paramInputStream, ExtensionRegistryLite paramExtensionRegistryLite) throws IOException {
    return (FieldMask)GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, paramInputStream, paramExtensionRegistryLite);
  }
  
  public static FieldMask parseFrom(ByteBuffer paramByteBuffer) throws InvalidProtocolBufferException {
    return (FieldMask)GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, paramByteBuffer);
  }
  
  public static FieldMask parseFrom(ByteBuffer paramByteBuffer, ExtensionRegistryLite paramExtensionRegistryLite) throws InvalidProtocolBufferException {
    return (FieldMask)GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, paramByteBuffer, paramExtensionRegistryLite);
  }
  
  public static FieldMask parseFrom(byte[] paramArrayOfbyte) throws InvalidProtocolBufferException {
    return (FieldMask)GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, paramArrayOfbyte);
  }
  
  public static FieldMask parseFrom(byte[] paramArrayOfbyte, ExtensionRegistryLite paramExtensionRegistryLite) throws InvalidProtocolBufferException {
    return (FieldMask)GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, paramArrayOfbyte, paramExtensionRegistryLite);
  }
  
  public static Parser<FieldMask> parser() {
    return DEFAULT_INSTANCE.getParserForType();
  }
  
  private void setPaths(int paramInt, String paramString) {
    paramString.getClass();
    ensurePathsIsMutable();
    this.paths_.set(paramInt, paramString);
  }
  
  protected final Object dynamicMethod(GeneratedMessageLite.MethodToInvoke paramMethodToInvoke, Object<FieldMask> paramObject1, Object paramObject2) {
    // Byte code:
    //   0: getstatic androidx/datastore/preferences/protobuf/FieldMask$1.$SwitchMap$com$google$protobuf$GeneratedMessageLite$MethodToInvoke : [I
    //   3: aload_1
    //   4: invokevirtual ordinal : ()I
    //   7: iaload
    //   8: tableswitch default -> 52, 1 -> 147, 2 -> 138, 3 -> 120, 4 -> 116, 5 -> 67, 6 -> 62, 7 -> 60
    //   52: new java/lang/UnsupportedOperationException
    //   55: dup
    //   56: invokespecial <init> : ()V
    //   59: athrow
    //   60: aconst_null
    //   61: areturn
    //   62: iconst_1
    //   63: invokestatic valueOf : (B)Ljava/lang/Byte;
    //   66: areturn
    //   67: getstatic androidx/datastore/preferences/protobuf/FieldMask.PARSER : Landroidx/datastore/preferences/protobuf/Parser;
    //   70: astore_1
    //   71: aload_1
    //   72: ifnonnull -> 114
    //   75: ldc androidx/datastore/preferences/protobuf/FieldMask
    //   77: monitorenter
    //   78: getstatic androidx/datastore/preferences/protobuf/FieldMask.PARSER : Landroidx/datastore/preferences/protobuf/Parser;
    //   81: astore_2
    //   82: aload_2
    //   83: astore_1
    //   84: aload_2
    //   85: ifnonnull -> 103
    //   88: new androidx/datastore/preferences/protobuf/GeneratedMessageLite$DefaultInstanceBasedParser
    //   91: dup
    //   92: getstatic androidx/datastore/preferences/protobuf/FieldMask.DEFAULT_INSTANCE : Landroidx/datastore/preferences/protobuf/FieldMask;
    //   95: invokespecial <init> : (Landroidx/datastore/preferences/protobuf/GeneratedMessageLite;)V
    //   98: astore_1
    //   99: aload_1
    //   100: putstatic androidx/datastore/preferences/protobuf/FieldMask.PARSER : Landroidx/datastore/preferences/protobuf/Parser;
    //   103: ldc androidx/datastore/preferences/protobuf/FieldMask
    //   105: monitorexit
    //   106: aload_1
    //   107: areturn
    //   108: astore_1
    //   109: ldc androidx/datastore/preferences/protobuf/FieldMask
    //   111: monitorexit
    //   112: aload_1
    //   113: athrow
    //   114: aload_1
    //   115: areturn
    //   116: getstatic androidx/datastore/preferences/protobuf/FieldMask.DEFAULT_INSTANCE : Landroidx/datastore/preferences/protobuf/FieldMask;
    //   119: areturn
    //   120: getstatic androidx/datastore/preferences/protobuf/FieldMask.DEFAULT_INSTANCE : Landroidx/datastore/preferences/protobuf/FieldMask;
    //   123: ldc '     Ț'
    //   125: iconst_1
    //   126: anewarray java/lang/Object
    //   129: dup
    //   130: iconst_0
    //   131: ldc 'paths_'
    //   133: aastore
    //   134: invokestatic newMessageInfo : (Landroidx/datastore/preferences/protobuf/MessageLite;Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/Object;
    //   137: areturn
    //   138: new androidx/datastore/preferences/protobuf/FieldMask$Builder
    //   141: dup
    //   142: aconst_null
    //   143: invokespecial <init> : (Landroidx/datastore/preferences/protobuf/FieldMask$1;)V
    //   146: areturn
    //   147: new androidx/datastore/preferences/protobuf/FieldMask
    //   150: dup
    //   151: invokespecial <init> : ()V
    //   154: areturn
    // Exception table:
    //   from	to	target	type
    //   78	82	108	finally
    //   88	103	108	finally
    //   103	106	108	finally
    //   109	112	108	finally
  }
  
  public String getPaths(int paramInt) {
    return this.paths_.get(paramInt);
  }
  
  public ByteString getPathsBytes(int paramInt) {
    return ByteString.copyFromUtf8(this.paths_.get(paramInt));
  }
  
  public int getPathsCount() {
    return this.paths_.size();
  }
  
  public List<String> getPathsList() {
    return this.paths_;
  }
  
  public static final class Builder extends GeneratedMessageLite.Builder<FieldMask, Builder> implements FieldMaskOrBuilder {
    private Builder() {
      super(FieldMask.DEFAULT_INSTANCE);
    }
    
    public Builder addAllPaths(Iterable<String> param1Iterable) {
      copyOnWrite();
      ((FieldMask)this.instance).addAllPaths(param1Iterable);
      return this;
    }
    
    public Builder addPaths(String param1String) {
      copyOnWrite();
      ((FieldMask)this.instance).addPaths(param1String);
      return this;
    }
    
    public Builder addPathsBytes(ByteString param1ByteString) {
      copyOnWrite();
      ((FieldMask)this.instance).addPathsBytes(param1ByteString);
      return this;
    }
    
    public Builder clearPaths() {
      copyOnWrite();
      ((FieldMask)this.instance).clearPaths();
      return this;
    }
    
    public String getPaths(int param1Int) {
      return ((FieldMask)this.instance).getPaths(param1Int);
    }
    
    public ByteString getPathsBytes(int param1Int) {
      return ((FieldMask)this.instance).getPathsBytes(param1Int);
    }
    
    public int getPathsCount() {
      return ((FieldMask)this.instance).getPathsCount();
    }
    
    public List<String> getPathsList() {
      return Collections.unmodifiableList(((FieldMask)this.instance).getPathsList());
    }
    
    public Builder setPaths(int param1Int, String param1String) {
      copyOnWrite();
      ((FieldMask)this.instance).setPaths(param1Int, param1String);
      return this;
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\MagicAI - AI Art & Anime Art-dex2jar.jar!\androidx\datastore\preferences\protobuf\FieldMask.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */