package androidx.datastore.preferences.protobuf;

import java.io.IOException;
import java.io.InputStream;
import java.nio.ByteBuffer;

public final class FloatValue extends GeneratedMessageLite<FloatValue, FloatValue.Builder> implements FloatValueOrBuilder {
  private static final FloatValue DEFAULT_INSTANCE;
  
  private static volatile Parser<FloatValue> PARSER;
  
  public static final int VALUE_FIELD_NUMBER = 1;
  
  private float value_;
  
  static {
    FloatValue floatValue = new FloatValue();
    DEFAULT_INSTANCE = floatValue;
    GeneratedMessageLite.registerDefaultInstance(FloatValue.class, floatValue);
  }
  
  private void clearValue() {
    this.value_ = 0.0F;
  }
  
  public static FloatValue getDefaultInstance() {
    return DEFAULT_INSTANCE;
  }
  
  public static Builder newBuilder() {
    return (Builder)DEFAULT_INSTANCE.createBuilder();
  }
  
  public static Builder newBuilder(FloatValue paramFloatValue) {
    return (Builder)DEFAULT_INSTANCE.createBuilder(paramFloatValue);
  }
  
  public static FloatValue of(float paramFloat) {
    return (FloatValue)newBuilder().setValue(paramFloat).build();
  }
  
  public static FloatValue parseDelimitedFrom(InputStream paramInputStream) throws IOException {
    return (FloatValue)GeneratedMessageLite.parseDelimitedFrom(DEFAULT_INSTANCE, paramInputStream);
  }
  
  public static FloatValue parseDelimitedFrom(InputStream paramInputStream, ExtensionRegistryLite paramExtensionRegistryLite) throws IOException {
    return (FloatValue)GeneratedMessageLite.parseDelimitedFrom(DEFAULT_INSTANCE, paramInputStream, paramExtensionRegistryLite);
  }
  
  public static FloatValue parseFrom(ByteString paramByteString) throws InvalidProtocolBufferException {
    return (FloatValue)GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, paramByteString);
  }
  
  public static FloatValue parseFrom(ByteString paramByteString, ExtensionRegistryLite paramExtensionRegistryLite) throws InvalidProtocolBufferException {
    return (FloatValue)GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, paramByteString, paramExtensionRegistryLite);
  }
  
  public static FloatValue parseFrom(CodedInputStream paramCodedInputStream) throws IOException {
    return (FloatValue)GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, paramCodedInputStream);
  }
  
  public static FloatValue parseFrom(CodedInputStream paramCodedInputStream, ExtensionRegistryLite paramExtensionRegistryLite) throws IOException {
    return (FloatValue)GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, paramCodedInputStream, paramExtensionRegistryLite);
  }
  
  public static FloatValue parseFrom(InputStream paramInputStream) throws IOException {
    return (FloatValue)GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, paramInputStream);
  }
  
  public static FloatValue parseFrom(InputStream paramInputStream, ExtensionRegistryLite paramExtensionRegistryLite) throws IOException {
    return (FloatValue)GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, paramInputStream, paramExtensionRegistryLite);
  }
  
  public static FloatValue parseFrom(ByteBuffer paramByteBuffer) throws InvalidProtocolBufferException {
    return (FloatValue)GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, paramByteBuffer);
  }
  
  public static FloatValue parseFrom(ByteBuffer paramByteBuffer, ExtensionRegistryLite paramExtensionRegistryLite) throws InvalidProtocolBufferException {
    return (FloatValue)GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, paramByteBuffer, paramExtensionRegistryLite);
  }
  
  public static FloatValue parseFrom(byte[] paramArrayOfbyte) throws InvalidProtocolBufferException {
    return (FloatValue)GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, paramArrayOfbyte);
  }
  
  public static FloatValue parseFrom(byte[] paramArrayOfbyte, ExtensionRegistryLite paramExtensionRegistryLite) throws InvalidProtocolBufferException {
    return (FloatValue)GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, paramArrayOfbyte, paramExtensionRegistryLite);
  }
  
  public static Parser<FloatValue> parser() {
    return DEFAULT_INSTANCE.getParserForType();
  }
  
  private void setValue(float paramFloat) {
    this.value_ = paramFloat;
  }
  
  protected final Object dynamicMethod(GeneratedMessageLite.MethodToInvoke paramMethodToInvoke, Object<FloatValue> paramObject1, Object paramObject2) {
    // Byte code:
    //   0: getstatic androidx/datastore/preferences/protobuf/FloatValue$1.$SwitchMap$com$google$protobuf$GeneratedMessageLite$MethodToInvoke : [I
    //   3: aload_1
    //   4: invokevirtual ordinal : ()I
    //   7: iaload
    //   8: tableswitch default -> 52, 1 -> 147, 2 -> 138, 3 -> 120, 4 -> 116, 5 -> 67, 6 -> 62, 7 -> 60
    //   52: new java/lang/UnsupportedOperationException
    //   55: dup
    //   56: invokespecial <init> : ()V
    //   59: athrow
    //   60: aconst_null
    //   61: areturn
    //   62: iconst_1
    //   63: invokestatic valueOf : (B)Ljava/lang/Byte;
    //   66: areturn
    //   67: getstatic androidx/datastore/preferences/protobuf/FloatValue.PARSER : Landroidx/datastore/preferences/protobuf/Parser;
    //   70: astore_1
    //   71: aload_1
    //   72: ifnonnull -> 114
    //   75: ldc androidx/datastore/preferences/protobuf/FloatValue
    //   77: monitorenter
    //   78: getstatic androidx/datastore/preferences/protobuf/FloatValue.PARSER : Landroidx/datastore/preferences/protobuf/Parser;
    //   81: astore_2
    //   82: aload_2
    //   83: astore_1
    //   84: aload_2
    //   85: ifnonnull -> 103
    //   88: new androidx/datastore/preferences/protobuf/GeneratedMessageLite$DefaultInstanceBasedParser
    //   91: dup
    //   92: getstatic androidx/datastore/preferences/protobuf/FloatValue.DEFAULT_INSTANCE : Landroidx/datastore/preferences/protobuf/FloatValue;
    //   95: invokespecial <init> : (Landroidx/datastore/preferences/protobuf/GeneratedMessageLite;)V
    //   98: astore_1
    //   99: aload_1
    //   100: putstatic androidx/datastore/preferences/protobuf/FloatValue.PARSER : Landroidx/datastore/preferences/protobuf/Parser;
    //   103: ldc androidx/datastore/preferences/protobuf/FloatValue
    //   105: monitorexit
    //   106: aload_1
    //   107: areturn
    //   108: astore_1
    //   109: ldc androidx/datastore/preferences/protobuf/FloatValue
    //   111: monitorexit
    //   112: aload_1
    //   113: athrow
    //   114: aload_1
    //   115: areturn
    //   116: getstatic androidx/datastore/preferences/protobuf/FloatValue.DEFAULT_INSTANCE : Landroidx/datastore/preferences/protobuf/FloatValue;
    //   119: areturn
    //   120: getstatic androidx/datastore/preferences/protobuf/FloatValue.DEFAULT_INSTANCE : Landroidx/datastore/preferences/protobuf/FloatValue;
    //   123: ldc '      '
    //   125: iconst_1
    //   126: anewarray java/lang/Object
    //   129: dup
    //   130: iconst_0
    //   131: ldc 'value_'
    //   133: aastore
    //   134: invokestatic newMessageInfo : (Landroidx/datastore/preferences/protobuf/MessageLite;Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/Object;
    //   137: areturn
    //   138: new androidx/datastore/preferences/protobuf/FloatValue$Builder
    //   141: dup
    //   142: aconst_null
    //   143: invokespecial <init> : (Landroidx/datastore/preferences/protobuf/FloatValue$1;)V
    //   146: areturn
    //   147: new androidx/datastore/preferences/protobuf/FloatValue
    //   150: dup
    //   151: invokespecial <init> : ()V
    //   154: areturn
    // Exception table:
    //   from	to	target	type
    //   78	82	108	finally
    //   88	103	108	finally
    //   103	106	108	finally
    //   109	112	108	finally
  }
  
  public float getValue() {
    return this.value_;
  }
  
  public static final class Builder extends GeneratedMessageLite.Builder<FloatValue, Builder> implements FloatValueOrBuilder {
    private Builder() {
      super(FloatValue.DEFAULT_INSTANCE);
    }
    
    public Builder clearValue() {
      copyOnWrite();
      ((FloatValue)this.instance).clearValue();
      return this;
    }
    
    public float getValue() {
      return ((FloatValue)this.instance).getValue();
    }
    
    public Builder setValue(float param1Float) {
      copyOnWrite();
      ((FloatValue)this.instance).setValue(param1Float);
      return this;
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\MagicAI - AI Art & Anime Art-dex2jar.jar!\androidx\datastore\preferences\protobuf\FloatValue.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */