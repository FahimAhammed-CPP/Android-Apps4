package androidx.datastore.preferences.protobuf;

public interface StringValueOrBuilder extends MessageLiteOrBuilder {
  String getValue();
  
  ByteString getValueBytes();
}


/* Location:              C:\soft\dex2jar-2.0\MagicAI - AI Art & Anime Art-dex2jar.jar!\androidx\datastore\preferences\protobuf\StringValueOrBuilder.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */