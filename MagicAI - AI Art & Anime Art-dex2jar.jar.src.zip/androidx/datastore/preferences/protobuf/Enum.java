package androidx.datastore.preferences.protobuf;

import java.io.IOException;
import java.io.InputStream;
import java.nio.ByteBuffer;
import java.util.Collections;
import java.util.List;

public final class Enum extends GeneratedMessageLite<Enum, Enum.Builder> implements EnumOrBuilder {
  private static final Enum DEFAULT_INSTANCE;
  
  public static final int ENUMVALUE_FIELD_NUMBER = 2;
  
  public static final int NAME_FIELD_NUMBER = 1;
  
  public static final int OPTIONS_FIELD_NUMBER = 3;
  
  private static volatile Parser<Enum> PARSER;
  
  public static final int SOURCE_CONTEXT_FIELD_NUMBER = 4;
  
  public static final int SYNTAX_FIELD_NUMBER = 5;
  
  private Internal.ProtobufList<EnumValue> enumvalue_ = GeneratedMessageLite.emptyProtobufList();
  
  private String name_ = "";
  
  private Internal.ProtobufList<Option> options_ = GeneratedMessageLite.emptyProtobufList();
  
  private SourceContext sourceContext_;
  
  private int syntax_;
  
  static {
    Enum enum_ = new Enum();
    DEFAULT_INSTANCE = enum_;
    GeneratedMessageLite.registerDefaultInstance(Enum.class, enum_);
  }
  
  private void addAllEnumvalue(Iterable<? extends EnumValue> paramIterable) {
    ensureEnumvalueIsMutable();
    AbstractMessageLite.addAll(paramIterable, this.enumvalue_);
  }
  
  private void addAllOptions(Iterable<? extends Option> paramIterable) {
    ensureOptionsIsMutable();
    AbstractMessageLite.addAll(paramIterable, this.options_);
  }
  
  private void addEnumvalue(int paramInt, EnumValue.Builder paramBuilder) {
    ensureEnumvalueIsMutable();
    this.enumvalue_.add(paramInt, paramBuilder.build());
  }
  
  private void addEnumvalue(int paramInt, EnumValue paramEnumValue) {
    paramEnumValue.getClass();
    ensureEnumvalueIsMutable();
    this.enumvalue_.add(paramInt, paramEnumValue);
  }
  
  private void addEnumvalue(EnumValue.Builder paramBuilder) {
    ensureEnumvalueIsMutable();
    this.enumvalue_.add(paramBuilder.build());
  }
  
  private void addEnumvalue(EnumValue paramEnumValue) {
    paramEnumValue.getClass();
    ensureEnumvalueIsMutable();
    this.enumvalue_.add(paramEnumValue);
  }
  
  private void addOptions(int paramInt, Option.Builder paramBuilder) {
    ensureOptionsIsMutable();
    this.options_.add(paramInt, paramBuilder.build());
  }
  
  private void addOptions(int paramInt, Option paramOption) {
    paramOption.getClass();
    ensureOptionsIsMutable();
    this.options_.add(paramInt, paramOption);
  }
  
  private void addOptions(Option.Builder paramBuilder) {
    ensureOptionsIsMutable();
    this.options_.add(paramBuilder.build());
  }
  
  private void addOptions(Option paramOption) {
    paramOption.getClass();
    ensureOptionsIsMutable();
    this.options_.add(paramOption);
  }
  
  private void clearEnumvalue() {
    this.enumvalue_ = GeneratedMessageLite.emptyProtobufList();
  }
  
  private void clearName() {
    this.name_ = getDefaultInstance().getName();
  }
  
  private void clearOptions() {
    this.options_ = GeneratedMessageLite.emptyProtobufList();
  }
  
  private void clearSourceContext() {
    this.sourceContext_ = null;
  }
  
  private void clearSyntax() {
    this.syntax_ = 0;
  }
  
  private void ensureEnumvalueIsMutable() {
    if (!this.enumvalue_.isModifiable())
      this.enumvalue_ = GeneratedMessageLite.mutableCopy(this.enumvalue_); 
  }
  
  private void ensureOptionsIsMutable() {
    if (!this.options_.isModifiable())
      this.options_ = GeneratedMessageLite.mutableCopy(this.options_); 
  }
  
  public static Enum getDefaultInstance() {
    return DEFAULT_INSTANCE;
  }
  
  private void mergeSourceContext(SourceContext paramSourceContext) {
    paramSourceContext.getClass();
    SourceContext sourceContext = this.sourceContext_;
    if (sourceContext != null && sourceContext != SourceContext.getDefaultInstance()) {
      this.sourceContext_ = (SourceContext)((SourceContext.Builder)SourceContext.newBuilder(this.sourceContext_).mergeFrom((GeneratedMessageLite)paramSourceContext)).buildPartial();
      return;
    } 
    this.sourceContext_ = paramSourceContext;
  }
  
  public static Builder newBuilder() {
    return (Builder)DEFAULT_INSTANCE.createBuilder();
  }
  
  public static Builder newBuilder(Enum paramEnum) {
    return (Builder)DEFAULT_INSTANCE.createBuilder(paramEnum);
  }
  
  public static Enum parseDelimitedFrom(InputStream paramInputStream) throws IOException {
    return (Enum)GeneratedMessageLite.parseDelimitedFrom(DEFAULT_INSTANCE, paramInputStream);
  }
  
  public static Enum parseDelimitedFrom(InputStream paramInputStream, ExtensionRegistryLite paramExtensionRegistryLite) throws IOException {
    return (Enum)GeneratedMessageLite.parseDelimitedFrom(DEFAULT_INSTANCE, paramInputStream, paramExtensionRegistryLite);
  }
  
  public static Enum parseFrom(ByteString paramByteString) throws InvalidProtocolBufferException {
    return (Enum)GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, paramByteString);
  }
  
  public static Enum parseFrom(ByteString paramByteString, ExtensionRegistryLite paramExtensionRegistryLite) throws InvalidProtocolBufferException {
    return (Enum)GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, paramByteString, paramExtensionRegistryLite);
  }
  
  public static Enum parseFrom(CodedInputStream paramCodedInputStream) throws IOException {
    return (Enum)GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, paramCodedInputStream);
  }
  
  public static Enum parseFrom(CodedInputStream paramCodedInputStream, ExtensionRegistryLite paramExtensionRegistryLite) throws IOException {
    return (Enum)GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, paramCodedInputStream, paramExtensionRegistryLite);
  }
  
  public static Enum parseFrom(InputStream paramInputStream) throws IOException {
    return (Enum)GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, paramInputStream);
  }
  
  public static Enum parseFrom(InputStream paramInputStream, ExtensionRegistryLite paramExtensionRegistryLite) throws IOException {
    return (Enum)GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, paramInputStream, paramExtensionRegistryLite);
  }
  
  public static Enum parseFrom(ByteBuffer paramByteBuffer) throws InvalidProtocolBufferException {
    return (Enum)GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, paramByteBuffer);
  }
  
  public static Enum parseFrom(ByteBuffer paramByteBuffer, ExtensionRegistryLite paramExtensionRegistryLite) throws InvalidProtocolBufferException {
    return (Enum)GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, paramByteBuffer, paramExtensionRegistryLite);
  }
  
  public static Enum parseFrom(byte[] paramArrayOfbyte) throws InvalidProtocolBufferException {
    return (Enum)GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, paramArrayOfbyte);
  }
  
  public static Enum parseFrom(byte[] paramArrayOfbyte, ExtensionRegistryLite paramExtensionRegistryLite) throws InvalidProtocolBufferException {
    return (Enum)GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, paramArrayOfbyte, paramExtensionRegistryLite);
  }
  
  public static Parser<Enum> parser() {
    return DEFAULT_INSTANCE.getParserForType();
  }
  
  private void removeEnumvalue(int paramInt) {
    ensureEnumvalueIsMutable();
    this.enumvalue_.remove(paramInt);
  }
  
  private void removeOptions(int paramInt) {
    ensureOptionsIsMutable();
    this.options_.remove(paramInt);
  }
  
  private void setEnumvalue(int paramInt, EnumValue.Builder paramBuilder) {
    ensureEnumvalueIsMutable();
    this.enumvalue_.set(paramInt, paramBuilder.build());
  }
  
  private void setEnumvalue(int paramInt, EnumValue paramEnumValue) {
    paramEnumValue.getClass();
    ensureEnumvalueIsMutable();
    this.enumvalue_.set(paramInt, paramEnumValue);
  }
  
  private void setName(String paramString) {
    paramString.getClass();
    this.name_ = paramString;
  }
  
  private void setNameBytes(ByteString paramByteString) {
    paramByteString.getClass();
    AbstractMessageLite.checkByteStringIsUtf8(paramByteString);
    this.name_ = paramByteString.toStringUtf8();
  }
  
  private void setOptions(int paramInt, Option.Builder paramBuilder) {
    ensureOptionsIsMutable();
    this.options_.set(paramInt, paramBuilder.build());
  }
  
  private void setOptions(int paramInt, Option paramOption) {
    paramOption.getClass();
    ensureOptionsIsMutable();
    this.options_.set(paramInt, paramOption);
  }
  
  private void setSourceContext(SourceContext.Builder paramBuilder) {
    this.sourceContext_ = (SourceContext)paramBuilder.build();
  }
  
  private void setSourceContext(SourceContext paramSourceContext) {
    paramSourceContext.getClass();
    this.sourceContext_ = paramSourceContext;
  }
  
  private void setSyntax(Syntax paramSyntax) {
    paramSyntax.getClass();
    this.syntax_ = paramSyntax.getNumber();
  }
  
  private void setSyntaxValue(int paramInt) {
    this.syntax_ = paramInt;
  }
  
  protected final Object dynamicMethod(GeneratedMessageLite.MethodToInvoke paramMethodToInvoke, Object<Enum> paramObject1, Object paramObject2) {
    // Byte code:
    //   0: getstatic androidx/datastore/preferences/protobuf/Enum$1.$SwitchMap$com$google$protobuf$GeneratedMessageLite$MethodToInvoke : [I
    //   3: aload_1
    //   4: invokevirtual ordinal : ()I
    //   7: iaload
    //   8: tableswitch default -> 52, 1 -> 187, 2 -> 178, 3 -> 120, 4 -> 116, 5 -> 67, 6 -> 62, 7 -> 60
    //   52: new java/lang/UnsupportedOperationException
    //   55: dup
    //   56: invokespecial <init> : ()V
    //   59: athrow
    //   60: aconst_null
    //   61: areturn
    //   62: iconst_1
    //   63: invokestatic valueOf : (B)Ljava/lang/Byte;
    //   66: areturn
    //   67: getstatic androidx/datastore/preferences/protobuf/Enum.PARSER : Landroidx/datastore/preferences/protobuf/Parser;
    //   70: astore_1
    //   71: aload_1
    //   72: ifnonnull -> 114
    //   75: ldc androidx/datastore/preferences/protobuf/Enum
    //   77: monitorenter
    //   78: getstatic androidx/datastore/preferences/protobuf/Enum.PARSER : Landroidx/datastore/preferences/protobuf/Parser;
    //   81: astore_2
    //   82: aload_2
    //   83: astore_1
    //   84: aload_2
    //   85: ifnonnull -> 103
    //   88: new androidx/datastore/preferences/protobuf/GeneratedMessageLite$DefaultInstanceBasedParser
    //   91: dup
    //   92: getstatic androidx/datastore/preferences/protobuf/Enum.DEFAULT_INSTANCE : Landroidx/datastore/preferences/protobuf/Enum;
    //   95: invokespecial <init> : (Landroidx/datastore/preferences/protobuf/GeneratedMessageLite;)V
    //   98: astore_1
    //   99: aload_1
    //   100: putstatic androidx/datastore/preferences/protobuf/Enum.PARSER : Landroidx/datastore/preferences/protobuf/Parser;
    //   103: ldc androidx/datastore/preferences/protobuf/Enum
    //   105: monitorexit
    //   106: aload_1
    //   107: areturn
    //   108: astore_1
    //   109: ldc androidx/datastore/preferences/protobuf/Enum
    //   111: monitorexit
    //   112: aload_1
    //   113: athrow
    //   114: aload_1
    //   115: areturn
    //   116: getstatic androidx/datastore/preferences/protobuf/Enum.DEFAULT_INSTANCE : Landroidx/datastore/preferences/protobuf/Enum;
    //   119: areturn
    //   120: getstatic androidx/datastore/preferences/protobuf/Enum.DEFAULT_INSTANCE : Landroidx/datastore/preferences/protobuf/Enum;
    //   123: ldc_w '     Ȉ\\t\\f'
    //   126: bipush #7
    //   128: anewarray java/lang/Object
    //   131: dup
    //   132: iconst_0
    //   133: ldc_w 'name_'
    //   136: aastore
    //   137: dup
    //   138: iconst_1
    //   139: ldc_w 'enumvalue_'
    //   142: aastore
    //   143: dup
    //   144: iconst_2
    //   145: ldc_w androidx/datastore/preferences/protobuf/EnumValue
    //   148: aastore
    //   149: dup
    //   150: iconst_3
    //   151: ldc_w 'options_'
    //   154: aastore
    //   155: dup
    //   156: iconst_4
    //   157: ldc_w androidx/datastore/preferences/protobuf/Option
    //   160: aastore
    //   161: dup
    //   162: iconst_5
    //   163: ldc_w 'sourceContext_'
    //   166: aastore
    //   167: dup
    //   168: bipush #6
    //   170: ldc_w 'syntax_'
    //   173: aastore
    //   174: invokestatic newMessageInfo : (Landroidx/datastore/preferences/protobuf/MessageLite;Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/Object;
    //   177: areturn
    //   178: new androidx/datastore/preferences/protobuf/Enum$Builder
    //   181: dup
    //   182: aconst_null
    //   183: invokespecial <init> : (Landroidx/datastore/preferences/protobuf/Enum$1;)V
    //   186: areturn
    //   187: new androidx/datastore/preferences/protobuf/Enum
    //   190: dup
    //   191: invokespecial <init> : ()V
    //   194: areturn
    // Exception table:
    //   from	to	target	type
    //   78	82	108	finally
    //   88	103	108	finally
    //   103	106	108	finally
    //   109	112	108	finally
  }
  
  public EnumValue getEnumvalue(int paramInt) {
    return this.enumvalue_.get(paramInt);
  }
  
  public int getEnumvalueCount() {
    return this.enumvalue_.size();
  }
  
  public List<EnumValue> getEnumvalueList() {
    return this.enumvalue_;
  }
  
  public EnumValueOrBuilder getEnumvalueOrBuilder(int paramInt) {
    return this.enumvalue_.get(paramInt);
  }
  
  public List<? extends EnumValueOrBuilder> getEnumvalueOrBuilderList() {
    return (List)this.enumvalue_;
  }
  
  public String getName() {
    return this.name_;
  }
  
  public ByteString getNameBytes() {
    return ByteString.copyFromUtf8(this.name_);
  }
  
  public Option getOptions(int paramInt) {
    return this.options_.get(paramInt);
  }
  
  public int getOptionsCount() {
    return this.options_.size();
  }
  
  public List<Option> getOptionsList() {
    return this.options_;
  }
  
  public OptionOrBuilder getOptionsOrBuilder(int paramInt) {
    return (OptionOrBuilder)this.options_.get(paramInt);
  }
  
  public List<? extends OptionOrBuilder> getOptionsOrBuilderList() {
    return (List)this.options_;
  }
  
  public SourceContext getSourceContext() {
    SourceContext sourceContext2 = this.sourceContext_;
    SourceContext sourceContext1 = sourceContext2;
    if (sourceContext2 == null)
      sourceContext1 = SourceContext.getDefaultInstance(); 
    return sourceContext1;
  }
  
  public Syntax getSyntax() {
    Syntax syntax2 = Syntax.forNumber(this.syntax_);
    Syntax syntax1 = syntax2;
    if (syntax2 == null)
      syntax1 = Syntax.UNRECOGNIZED; 
    return syntax1;
  }
  
  public int getSyntaxValue() {
    return this.syntax_;
  }
  
  public boolean hasSourceContext() {
    return (this.sourceContext_ != null);
  }
  
  public static final class Builder extends GeneratedMessageLite.Builder<Enum, Builder> implements EnumOrBuilder {
    private Builder() {
      super(Enum.DEFAULT_INSTANCE);
    }
    
    public Builder addAllEnumvalue(Iterable<? extends EnumValue> param1Iterable) {
      copyOnWrite();
      ((Enum)this.instance).addAllEnumvalue(param1Iterable);
      return this;
    }
    
    public Builder addAllOptions(Iterable<? extends Option> param1Iterable) {
      copyOnWrite();
      ((Enum)this.instance).addAllOptions(param1Iterable);
      return this;
    }
    
    public Builder addEnumvalue(int param1Int, EnumValue.Builder param1Builder) {
      copyOnWrite();
      ((Enum)this.instance).addEnumvalue(param1Int, param1Builder);
      return this;
    }
    
    public Builder addEnumvalue(int param1Int, EnumValue param1EnumValue) {
      copyOnWrite();
      ((Enum)this.instance).addEnumvalue(param1Int, param1EnumValue);
      return this;
    }
    
    public Builder addEnumvalue(EnumValue.Builder param1Builder) {
      copyOnWrite();
      ((Enum)this.instance).addEnumvalue(param1Builder);
      return this;
    }
    
    public Builder addEnumvalue(EnumValue param1EnumValue) {
      copyOnWrite();
      ((Enum)this.instance).addEnumvalue(param1EnumValue);
      return this;
    }
    
    public Builder addOptions(int param1Int, Option.Builder param1Builder) {
      copyOnWrite();
      ((Enum)this.instance).addOptions(param1Int, param1Builder);
      return this;
    }
    
    public Builder addOptions(int param1Int, Option param1Option) {
      copyOnWrite();
      ((Enum)this.instance).addOptions(param1Int, param1Option);
      return this;
    }
    
    public Builder addOptions(Option.Builder param1Builder) {
      copyOnWrite();
      ((Enum)this.instance).addOptions(param1Builder);
      return this;
    }
    
    public Builder addOptions(Option param1Option) {
      copyOnWrite();
      ((Enum)this.instance).addOptions(param1Option);
      return this;
    }
    
    public Builder clearEnumvalue() {
      copyOnWrite();
      ((Enum)this.instance).clearEnumvalue();
      return this;
    }
    
    public Builder clearName() {
      copyOnWrite();
      ((Enum)this.instance).clearName();
      return this;
    }
    
    public Builder clearOptions() {
      copyOnWrite();
      ((Enum)this.instance).clearOptions();
      return this;
    }
    
    public Builder clearSourceContext() {
      copyOnWrite();
      ((Enum)this.instance).clearSourceContext();
      return this;
    }
    
    public Builder clearSyntax() {
      copyOnWrite();
      ((Enum)this.instance).clearSyntax();
      return this;
    }
    
    public EnumValue getEnumvalue(int param1Int) {
      return ((Enum)this.instance).getEnumvalue(param1Int);
    }
    
    public int getEnumvalueCount() {
      return ((Enum)this.instance).getEnumvalueCount();
    }
    
    public List<EnumValue> getEnumvalueList() {
      return Collections.unmodifiableList(((Enum)this.instance).getEnumvalueList());
    }
    
    public String getName() {
      return ((Enum)this.instance).getName();
    }
    
    public ByteString getNameBytes() {
      return ((Enum)this.instance).getNameBytes();
    }
    
    public Option getOptions(int param1Int) {
      return ((Enum)this.instance).getOptions(param1Int);
    }
    
    public int getOptionsCount() {
      return ((Enum)this.instance).getOptionsCount();
    }
    
    public List<Option> getOptionsList() {
      return Collections.unmodifiableList(((Enum)this.instance).getOptionsList());
    }
    
    public SourceContext getSourceContext() {
      return ((Enum)this.instance).getSourceContext();
    }
    
    public Syntax getSyntax() {
      return ((Enum)this.instance).getSyntax();
    }
    
    public int getSyntaxValue() {
      return ((Enum)this.instance).getSyntaxValue();
    }
    
    public boolean hasSourceContext() {
      return ((Enum)this.instance).hasSourceContext();
    }
    
    public Builder mergeSourceContext(SourceContext param1SourceContext) {
      copyOnWrite();
      ((Enum)this.instance).mergeSourceContext(param1SourceContext);
      return this;
    }
    
    public Builder removeEnumvalue(int param1Int) {
      copyOnWrite();
      ((Enum)this.instance).removeEnumvalue(param1Int);
      return this;
    }
    
    public Builder removeOptions(int param1Int) {
      copyOnWrite();
      ((Enum)this.instance).removeOptions(param1Int);
      return this;
    }
    
    public Builder setEnumvalue(int param1Int, EnumValue.Builder param1Builder) {
      copyOnWrite();
      ((Enum)this.instance).setEnumvalue(param1Int, param1Builder);
      return this;
    }
    
    public Builder setEnumvalue(int param1Int, EnumValue param1EnumValue) {
      copyOnWrite();
      ((Enum)this.instance).setEnumvalue(param1Int, param1EnumValue);
      return this;
    }
    
    public Builder setName(String param1String) {
      copyOnWrite();
      ((Enum)this.instance).setName(param1String);
      return this;
    }
    
    public Builder setNameBytes(ByteString param1ByteString) {
      copyOnWrite();
      ((Enum)this.instance).setNameBytes(param1ByteString);
      return this;
    }
    
    public Builder setOptions(int param1Int, Option.Builder param1Builder) {
      copyOnWrite();
      ((Enum)this.instance).setOptions(param1Int, param1Builder);
      return this;
    }
    
    public Builder setOptions(int param1Int, Option param1Option) {
      copyOnWrite();
      ((Enum)this.instance).setOptions(param1Int, param1Option);
      return this;
    }
    
    public Builder setSourceContext(SourceContext.Builder param1Builder) {
      copyOnWrite();
      ((Enum)this.instance).setSourceContext(param1Builder);
      return this;
    }
    
    public Builder setSourceContext(SourceContext param1SourceContext) {
      copyOnWrite();
      ((Enum)this.instance).setSourceContext(param1SourceContext);
      return this;
    }
    
    public Builder setSyntax(Syntax param1Syntax) {
      copyOnWrite();
      ((Enum)this.instance).setSyntax(param1Syntax);
      return this;
    }
    
    public Builder setSyntaxValue(int param1Int) {
      copyOnWrite();
      ((Enum)this.instance).setSyntaxValue(param1Int);
      return this;
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\MagicAI - AI Art & Anime Art-dex2jar.jar!\androidx\datastore\preferences\protobuf\Enum.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */