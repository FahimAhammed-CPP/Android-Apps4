package androidx.datastore.preferences.protobuf;

import java.io.IOException;
import java.io.InputStream;
import java.nio.ByteBuffer;

public final class UInt32Value extends GeneratedMessageLite<UInt32Value, UInt32Value.Builder> implements UInt32ValueOrBuilder {
  private static final UInt32Value DEFAULT_INSTANCE;
  
  private static volatile Parser<UInt32Value> PARSER;
  
  public static final int VALUE_FIELD_NUMBER = 1;
  
  private int value_;
  
  static {
    UInt32Value uInt32Value = new UInt32Value();
    DEFAULT_INSTANCE = uInt32Value;
    GeneratedMessageLite.registerDefaultInstance(UInt32Value.class, uInt32Value);
  }
  
  private void clearValue() {
    this.value_ = 0;
  }
  
  public static UInt32Value getDefaultInstance() {
    return DEFAULT_INSTANCE;
  }
  
  public static Builder newBuilder() {
    return (Builder)DEFAULT_INSTANCE.createBuilder();
  }
  
  public static Builder newBuilder(UInt32Value paramUInt32Value) {
    return (Builder)DEFAULT_INSTANCE.createBuilder(paramUInt32Value);
  }
  
  public static UInt32Value of(int paramInt) {
    return (UInt32Value)newBuilder().setValue(paramInt).build();
  }
  
  public static UInt32Value parseDelimitedFrom(InputStream paramInputStream) throws IOException {
    return (UInt32Value)GeneratedMessageLite.parseDelimitedFrom(DEFAULT_INSTANCE, paramInputStream);
  }
  
  public static UInt32Value parseDelimitedFrom(InputStream paramInputStream, ExtensionRegistryLite paramExtensionRegistryLite) throws IOException {
    return (UInt32Value)GeneratedMessageLite.parseDelimitedFrom(DEFAULT_INSTANCE, paramInputStream, paramExtensionRegistryLite);
  }
  
  public static UInt32Value parseFrom(ByteString paramByteString) throws InvalidProtocolBufferException {
    return (UInt32Value)GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, paramByteString);
  }
  
  public static UInt32Value parseFrom(ByteString paramByteString, ExtensionRegistryLite paramExtensionRegistryLite) throws InvalidProtocolBufferException {
    return (UInt32Value)GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, paramByteString, paramExtensionRegistryLite);
  }
  
  public static UInt32Value parseFrom(CodedInputStream paramCodedInputStream) throws IOException {
    return (UInt32Value)GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, paramCodedInputStream);
  }
  
  public static UInt32Value parseFrom(CodedInputStream paramCodedInputStream, ExtensionRegistryLite paramExtensionRegistryLite) throws IOException {
    return (UInt32Value)GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, paramCodedInputStream, paramExtensionRegistryLite);
  }
  
  public static UInt32Value parseFrom(InputStream paramInputStream) throws IOException {
    return (UInt32Value)GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, paramInputStream);
  }
  
  public static UInt32Value parseFrom(InputStream paramInputStream, ExtensionRegistryLite paramExtensionRegistryLite) throws IOException {
    return (UInt32Value)GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, paramInputStream, paramExtensionRegistryLite);
  }
  
  public static UInt32Value parseFrom(ByteBuffer paramByteBuffer) throws InvalidProtocolBufferException {
    return (UInt32Value)GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, paramByteBuffer);
  }
  
  public static UInt32Value parseFrom(ByteBuffer paramByteBuffer, ExtensionRegistryLite paramExtensionRegistryLite) throws InvalidProtocolBufferException {
    return (UInt32Value)GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, paramByteBuffer, paramExtensionRegistryLite);
  }
  
  public static UInt32Value parseFrom(byte[] paramArrayOfbyte) throws InvalidProtocolBufferException {
    return (UInt32Value)GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, paramArrayOfbyte);
  }
  
  public static UInt32Value parseFrom(byte[] paramArrayOfbyte, ExtensionRegistryLite paramExtensionRegistryLite) throws InvalidProtocolBufferException {
    return (UInt32Value)GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, paramArrayOfbyte, paramExtensionRegistryLite);
  }
  
  public static Parser<UInt32Value> parser() {
    return DEFAULT_INSTANCE.getParserForType();
  }
  
  private void setValue(int paramInt) {
    this.value_ = paramInt;
  }
  
  protected final Object dynamicMethod(GeneratedMessageLite.MethodToInvoke paramMethodToInvoke, Object<UInt32Value> paramObject1, Object paramObject2) {
    // Byte code:
    //   0: getstatic androidx/datastore/preferences/protobuf/UInt32Value$1.$SwitchMap$com$google$protobuf$GeneratedMessageLite$MethodToInvoke : [I
    //   3: aload_1
    //   4: invokevirtual ordinal : ()I
    //   7: iaload
    //   8: tableswitch default -> 52, 1 -> 147, 2 -> 138, 3 -> 120, 4 -> 116, 5 -> 67, 6 -> 62, 7 -> 60
    //   52: new java/lang/UnsupportedOperationException
    //   55: dup
    //   56: invokespecial <init> : ()V
    //   59: athrow
    //   60: aconst_null
    //   61: areturn
    //   62: iconst_1
    //   63: invokestatic valueOf : (B)Ljava/lang/Byte;
    //   66: areturn
    //   67: getstatic androidx/datastore/preferences/protobuf/UInt32Value.PARSER : Landroidx/datastore/preferences/protobuf/Parser;
    //   70: astore_1
    //   71: aload_1
    //   72: ifnonnull -> 114
    //   75: ldc androidx/datastore/preferences/protobuf/UInt32Value
    //   77: monitorenter
    //   78: getstatic androidx/datastore/preferences/protobuf/UInt32Value.PARSER : Landroidx/datastore/preferences/protobuf/Parser;
    //   81: astore_2
    //   82: aload_2
    //   83: astore_1
    //   84: aload_2
    //   85: ifnonnull -> 103
    //   88: new androidx/datastore/preferences/protobuf/GeneratedMessageLite$DefaultInstanceBasedParser
    //   91: dup
    //   92: getstatic androidx/datastore/preferences/protobuf/UInt32Value.DEFAULT_INSTANCE : Landroidx/datastore/preferences/protobuf/UInt32Value;
    //   95: invokespecial <init> : (Landroidx/datastore/preferences/protobuf/GeneratedMessageLite;)V
    //   98: astore_1
    //   99: aload_1
    //   100: putstatic androidx/datastore/preferences/protobuf/UInt32Value.PARSER : Landroidx/datastore/preferences/protobuf/Parser;
    //   103: ldc androidx/datastore/preferences/protobuf/UInt32Value
    //   105: monitorexit
    //   106: aload_1
    //   107: areturn
    //   108: astore_1
    //   109: ldc androidx/datastore/preferences/protobuf/UInt32Value
    //   111: monitorexit
    //   112: aload_1
    //   113: athrow
    //   114: aload_1
    //   115: areturn
    //   116: getstatic androidx/datastore/preferences/protobuf/UInt32Value.DEFAULT_INSTANCE : Landroidx/datastore/preferences/protobuf/UInt32Value;
    //   119: areturn
    //   120: getstatic androidx/datastore/preferences/protobuf/UInt32Value.DEFAULT_INSTANCE : Landroidx/datastore/preferences/protobuf/UInt32Value;
    //   123: ldc '      '
    //   125: iconst_1
    //   126: anewarray java/lang/Object
    //   129: dup
    //   130: iconst_0
    //   131: ldc 'value_'
    //   133: aastore
    //   134: invokestatic newMessageInfo : (Landroidx/datastore/preferences/protobuf/MessageLite;Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/Object;
    //   137: areturn
    //   138: new androidx/datastore/preferences/protobuf/UInt32Value$Builder
    //   141: dup
    //   142: aconst_null
    //   143: invokespecial <init> : (Landroidx/datastore/preferences/protobuf/UInt32Value$1;)V
    //   146: areturn
    //   147: new androidx/datastore/preferences/protobuf/UInt32Value
    //   150: dup
    //   151: invokespecial <init> : ()V
    //   154: areturn
    // Exception table:
    //   from	to	target	type
    //   78	82	108	finally
    //   88	103	108	finally
    //   103	106	108	finally
    //   109	112	108	finally
  }
  
  public int getValue() {
    return this.value_;
  }
  
  public static final class Builder extends GeneratedMessageLite.Builder<UInt32Value, Builder> implements UInt32ValueOrBuilder {
    private Builder() {
      super(UInt32Value.DEFAULT_INSTANCE);
    }
    
    public Builder clearValue() {
      copyOnWrite();
      ((UInt32Value)this.instance).clearValue();
      return this;
    }
    
    public int getValue() {
      return ((UInt32Value)this.instance).getValue();
    }
    
    public Builder setValue(int param1Int) {
      copyOnWrite();
      ((UInt32Value)this.instance).setValue(param1Int);
      return this;
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\MagicAI - AI Art & Anime Art-dex2jar.jar!\androidx\datastore\preferences\protobuf\UInt32Value.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */