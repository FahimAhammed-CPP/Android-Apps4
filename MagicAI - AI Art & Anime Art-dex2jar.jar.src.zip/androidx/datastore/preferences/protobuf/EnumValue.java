package androidx.datastore.preferences.protobuf;

import java.io.IOException;
import java.io.InputStream;
import java.nio.ByteBuffer;
import java.util.Collections;
import java.util.List;

public final class EnumValue extends GeneratedMessageLite<EnumValue, EnumValue.Builder> implements EnumValueOrBuilder {
  private static final EnumValue DEFAULT_INSTANCE;
  
  public static final int NAME_FIELD_NUMBER = 1;
  
  public static final int NUMBER_FIELD_NUMBER = 2;
  
  public static final int OPTIONS_FIELD_NUMBER = 3;
  
  private static volatile Parser<EnumValue> PARSER;
  
  private String name_ = "";
  
  private int number_;
  
  private Internal.ProtobufList<Option> options_ = GeneratedMessageLite.emptyProtobufList();
  
  static {
    EnumValue enumValue = new EnumValue();
    DEFAULT_INSTANCE = enumValue;
    GeneratedMessageLite.registerDefaultInstance(EnumValue.class, enumValue);
  }
  
  private void addAllOptions(Iterable<? extends Option> paramIterable) {
    ensureOptionsIsMutable();
    AbstractMessageLite.addAll(paramIterable, this.options_);
  }
  
  private void addOptions(int paramInt, Option.Builder paramBuilder) {
    ensureOptionsIsMutable();
    this.options_.add(paramInt, paramBuilder.build());
  }
  
  private void addOptions(int paramInt, Option paramOption) {
    paramOption.getClass();
    ensureOptionsIsMutable();
    this.options_.add(paramInt, paramOption);
  }
  
  private void addOptions(Option.Builder paramBuilder) {
    ensureOptionsIsMutable();
    this.options_.add(paramBuilder.build());
  }
  
  private void addOptions(Option paramOption) {
    paramOption.getClass();
    ensureOptionsIsMutable();
    this.options_.add(paramOption);
  }
  
  private void clearName() {
    this.name_ = getDefaultInstance().getName();
  }
  
  private void clearNumber() {
    this.number_ = 0;
  }
  
  private void clearOptions() {
    this.options_ = GeneratedMessageLite.emptyProtobufList();
  }
  
  private void ensureOptionsIsMutable() {
    if (!this.options_.isModifiable())
      this.options_ = GeneratedMessageLite.mutableCopy(this.options_); 
  }
  
  public static EnumValue getDefaultInstance() {
    return DEFAULT_INSTANCE;
  }
  
  public static Builder newBuilder() {
    return (Builder)DEFAULT_INSTANCE.createBuilder();
  }
  
  public static Builder newBuilder(EnumValue paramEnumValue) {
    return (Builder)DEFAULT_INSTANCE.createBuilder(paramEnumValue);
  }
  
  public static EnumValue parseDelimitedFrom(InputStream paramInputStream) throws IOException {
    return (EnumValue)GeneratedMessageLite.parseDelimitedFrom(DEFAULT_INSTANCE, paramInputStream);
  }
  
  public static EnumValue parseDelimitedFrom(InputStream paramInputStream, ExtensionRegistryLite paramExtensionRegistryLite) throws IOException {
    return (EnumValue)GeneratedMessageLite.parseDelimitedFrom(DEFAULT_INSTANCE, paramInputStream, paramExtensionRegistryLite);
  }
  
  public static EnumValue parseFrom(ByteString paramByteString) throws InvalidProtocolBufferException {
    return (EnumValue)GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, paramByteString);
  }
  
  public static EnumValue parseFrom(ByteString paramByteString, ExtensionRegistryLite paramExtensionRegistryLite) throws InvalidProtocolBufferException {
    return (EnumValue)GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, paramByteString, paramExtensionRegistryLite);
  }
  
  public static EnumValue parseFrom(CodedInputStream paramCodedInputStream) throws IOException {
    return (EnumValue)GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, paramCodedInputStream);
  }
  
  public static EnumValue parseFrom(CodedInputStream paramCodedInputStream, ExtensionRegistryLite paramExtensionRegistryLite) throws IOException {
    return (EnumValue)GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, paramCodedInputStream, paramExtensionRegistryLite);
  }
  
  public static EnumValue parseFrom(InputStream paramInputStream) throws IOException {
    return (EnumValue)GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, paramInputStream);
  }
  
  public static EnumValue parseFrom(InputStream paramInputStream, ExtensionRegistryLite paramExtensionRegistryLite) throws IOException {
    return (EnumValue)GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, paramInputStream, paramExtensionRegistryLite);
  }
  
  public static EnumValue parseFrom(ByteBuffer paramByteBuffer) throws InvalidProtocolBufferException {
    return (EnumValue)GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, paramByteBuffer);
  }
  
  public static EnumValue parseFrom(ByteBuffer paramByteBuffer, ExtensionRegistryLite paramExtensionRegistryLite) throws InvalidProtocolBufferException {
    return (EnumValue)GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, paramByteBuffer, paramExtensionRegistryLite);
  }
  
  public static EnumValue parseFrom(byte[] paramArrayOfbyte) throws InvalidProtocolBufferException {
    return (EnumValue)GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, paramArrayOfbyte);
  }
  
  public static EnumValue parseFrom(byte[] paramArrayOfbyte, ExtensionRegistryLite paramExtensionRegistryLite) throws InvalidProtocolBufferException {
    return (EnumValue)GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, paramArrayOfbyte, paramExtensionRegistryLite);
  }
  
  public static Parser<EnumValue> parser() {
    return DEFAULT_INSTANCE.getParserForType();
  }
  
  private void removeOptions(int paramInt) {
    ensureOptionsIsMutable();
    this.options_.remove(paramInt);
  }
  
  private void setName(String paramString) {
    paramString.getClass();
    this.name_ = paramString;
  }
  
  private void setNameBytes(ByteString paramByteString) {
    paramByteString.getClass();
    AbstractMessageLite.checkByteStringIsUtf8(paramByteString);
    this.name_ = paramByteString.toStringUtf8();
  }
  
  private void setNumber(int paramInt) {
    this.number_ = paramInt;
  }
  
  private void setOptions(int paramInt, Option.Builder paramBuilder) {
    ensureOptionsIsMutable();
    this.options_.set(paramInt, paramBuilder.build());
  }
  
  private void setOptions(int paramInt, Option paramOption) {
    paramOption.getClass();
    ensureOptionsIsMutable();
    this.options_.set(paramInt, paramOption);
  }
  
  protected final Object dynamicMethod(GeneratedMessageLite.MethodToInvoke paramMethodToInvoke, Object<EnumValue> paramObject1, Object paramObject2) {
    // Byte code:
    //   0: getstatic androidx/datastore/preferences/protobuf/EnumValue$1.$SwitchMap$com$google$protobuf$GeneratedMessageLite$MethodToInvoke : [I
    //   3: aload_1
    //   4: invokevirtual ordinal : ()I
    //   7: iaload
    //   8: tableswitch default -> 52, 1 -> 167, 2 -> 158, 3 -> 120, 4 -> 116, 5 -> 67, 6 -> 62, 7 -> 60
    //   52: new java/lang/UnsupportedOperationException
    //   55: dup
    //   56: invokespecial <init> : ()V
    //   59: athrow
    //   60: aconst_null
    //   61: areturn
    //   62: iconst_1
    //   63: invokestatic valueOf : (B)Ljava/lang/Byte;
    //   66: areturn
    //   67: getstatic androidx/datastore/preferences/protobuf/EnumValue.PARSER : Landroidx/datastore/preferences/protobuf/Parser;
    //   70: astore_1
    //   71: aload_1
    //   72: ifnonnull -> 114
    //   75: ldc androidx/datastore/preferences/protobuf/EnumValue
    //   77: monitorenter
    //   78: getstatic androidx/datastore/preferences/protobuf/EnumValue.PARSER : Landroidx/datastore/preferences/protobuf/Parser;
    //   81: astore_2
    //   82: aload_2
    //   83: astore_1
    //   84: aload_2
    //   85: ifnonnull -> 103
    //   88: new androidx/datastore/preferences/protobuf/GeneratedMessageLite$DefaultInstanceBasedParser
    //   91: dup
    //   92: getstatic androidx/datastore/preferences/protobuf/EnumValue.DEFAULT_INSTANCE : Landroidx/datastore/preferences/protobuf/EnumValue;
    //   95: invokespecial <init> : (Landroidx/datastore/preferences/protobuf/GeneratedMessageLite;)V
    //   98: astore_1
    //   99: aload_1
    //   100: putstatic androidx/datastore/preferences/protobuf/EnumValue.PARSER : Landroidx/datastore/preferences/protobuf/Parser;
    //   103: ldc androidx/datastore/preferences/protobuf/EnumValue
    //   105: monitorexit
    //   106: aload_1
    //   107: areturn
    //   108: astore_1
    //   109: ldc androidx/datastore/preferences/protobuf/EnumValue
    //   111: monitorexit
    //   112: aload_1
    //   113: athrow
    //   114: aload_1
    //   115: areturn
    //   116: getstatic androidx/datastore/preferences/protobuf/EnumValue.DEFAULT_INSTANCE : Landroidx/datastore/preferences/protobuf/EnumValue;
    //   119: areturn
    //   120: getstatic androidx/datastore/preferences/protobuf/EnumValue.DEFAULT_INSTANCE : Landroidx/datastore/preferences/protobuf/EnumValue;
    //   123: ldc_w '     Ȉ'
    //   126: iconst_4
    //   127: anewarray java/lang/Object
    //   130: dup
    //   131: iconst_0
    //   132: ldc_w 'name_'
    //   135: aastore
    //   136: dup
    //   137: iconst_1
    //   138: ldc_w 'number_'
    //   141: aastore
    //   142: dup
    //   143: iconst_2
    //   144: ldc_w 'options_'
    //   147: aastore
    //   148: dup
    //   149: iconst_3
    //   150: ldc_w androidx/datastore/preferences/protobuf/Option
    //   153: aastore
    //   154: invokestatic newMessageInfo : (Landroidx/datastore/preferences/protobuf/MessageLite;Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/Object;
    //   157: areturn
    //   158: new androidx/datastore/preferences/protobuf/EnumValue$Builder
    //   161: dup
    //   162: aconst_null
    //   163: invokespecial <init> : (Landroidx/datastore/preferences/protobuf/EnumValue$1;)V
    //   166: areturn
    //   167: new androidx/datastore/preferences/protobuf/EnumValue
    //   170: dup
    //   171: invokespecial <init> : ()V
    //   174: areturn
    // Exception table:
    //   from	to	target	type
    //   78	82	108	finally
    //   88	103	108	finally
    //   103	106	108	finally
    //   109	112	108	finally
  }
  
  public String getName() {
    return this.name_;
  }
  
  public ByteString getNameBytes() {
    return ByteString.copyFromUtf8(this.name_);
  }
  
  public int getNumber() {
    return this.number_;
  }
  
  public Option getOptions(int paramInt) {
    return this.options_.get(paramInt);
  }
  
  public int getOptionsCount() {
    return this.options_.size();
  }
  
  public List<Option> getOptionsList() {
    return this.options_;
  }
  
  public OptionOrBuilder getOptionsOrBuilder(int paramInt) {
    return (OptionOrBuilder)this.options_.get(paramInt);
  }
  
  public List<? extends OptionOrBuilder> getOptionsOrBuilderList() {
    return (List)this.options_;
  }
  
  public static final class Builder extends GeneratedMessageLite.Builder<EnumValue, Builder> implements EnumValueOrBuilder {
    private Builder() {
      super(EnumValue.DEFAULT_INSTANCE);
    }
    
    public Builder addAllOptions(Iterable<? extends Option> param1Iterable) {
      copyOnWrite();
      ((EnumValue)this.instance).addAllOptions(param1Iterable);
      return this;
    }
    
    public Builder addOptions(int param1Int, Option.Builder param1Builder) {
      copyOnWrite();
      ((EnumValue)this.instance).addOptions(param1Int, param1Builder);
      return this;
    }
    
    public Builder addOptions(int param1Int, Option param1Option) {
      copyOnWrite();
      ((EnumValue)this.instance).addOptions(param1Int, param1Option);
      return this;
    }
    
    public Builder addOptions(Option.Builder param1Builder) {
      copyOnWrite();
      ((EnumValue)this.instance).addOptions(param1Builder);
      return this;
    }
    
    public Builder addOptions(Option param1Option) {
      copyOnWrite();
      ((EnumValue)this.instance).addOptions(param1Option);
      return this;
    }
    
    public Builder clearName() {
      copyOnWrite();
      ((EnumValue)this.instance).clearName();
      return this;
    }
    
    public Builder clearNumber() {
      copyOnWrite();
      ((EnumValue)this.instance).clearNumber();
      return this;
    }
    
    public Builder clearOptions() {
      copyOnWrite();
      ((EnumValue)this.instance).clearOptions();
      return this;
    }
    
    public String getName() {
      return ((EnumValue)this.instance).getName();
    }
    
    public ByteString getNameBytes() {
      return ((EnumValue)this.instance).getNameBytes();
    }
    
    public int getNumber() {
      return ((EnumValue)this.instance).getNumber();
    }
    
    public Option getOptions(int param1Int) {
      return ((EnumValue)this.instance).getOptions(param1Int);
    }
    
    public int getOptionsCount() {
      return ((EnumValue)this.instance).getOptionsCount();
    }
    
    public List<Option> getOptionsList() {
      return Collections.unmodifiableList(((EnumValue)this.instance).getOptionsList());
    }
    
    public Builder removeOptions(int param1Int) {
      copyOnWrite();
      ((EnumValue)this.instance).removeOptions(param1Int);
      return this;
    }
    
    public Builder setName(String param1String) {
      copyOnWrite();
      ((EnumValue)this.instance).setName(param1String);
      return this;
    }
    
    public Builder setNameBytes(ByteString param1ByteString) {
      copyOnWrite();
      ((EnumValue)this.instance).setNameBytes(param1ByteString);
      return this;
    }
    
    public Builder setNumber(int param1Int) {
      copyOnWrite();
      ((EnumValue)this.instance).setNumber(param1Int);
      return this;
    }
    
    public Builder setOptions(int param1Int, Option.Builder param1Builder) {
      copyOnWrite();
      ((EnumValue)this.instance).setOptions(param1Int, param1Builder);
      return this;
    }
    
    public Builder setOptions(int param1Int, Option param1Option) {
      copyOnWrite();
      ((EnumValue)this.instance).setOptions(param1Int, param1Option);
      return this;
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\MagicAI - AI Art & Anime Art-dex2jar.jar!\androidx\datastore\preferences\protobuf\EnumValue.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */