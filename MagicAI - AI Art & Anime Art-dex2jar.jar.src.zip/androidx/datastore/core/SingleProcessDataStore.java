package androidx.datastore.core;

import androidx.annotation.GuardedBy;
import androidx.datastore.core.handlers.NoOpCorruptionHandler;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.OutputStream;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Set;
import java.util.concurrent.CancellationException;
import kotlin.Lazy;
import kotlin.LazyKt;
import kotlin.Metadata;
import kotlin.ResultKt;
import kotlin.Unit;
import kotlin.collections.CollectionsKt;
import kotlin.coroutines.Continuation;
import kotlin.coroutines.CoroutineContext;
import kotlin.coroutines.intrinsics.IntrinsicsKt;
import kotlin.coroutines.jvm.internal.Boxing;
import kotlin.coroutines.jvm.internal.ContinuationImpl;
import kotlin.coroutines.jvm.internal.DebugMetadata;
import kotlin.coroutines.jvm.internal.SuspendLambda;
import kotlin.jvm.functions.Function0;
import kotlin.jvm.functions.Function1;
import kotlin.jvm.functions.Function2;
import kotlin.jvm.internal.DefaultConstructorMarker;
import kotlin.jvm.internal.Intrinsics;
import kotlin.jvm.internal.Lambda;
import kotlin.jvm.internal.Ref;
import kotlinx.coroutines.CompletableDeferred;
import kotlinx.coroutines.CompletableDeferredKt;
import kotlinx.coroutines.CoroutineScope;
import kotlinx.coroutines.flow.Flow;
import kotlinx.coroutines.flow.FlowCollector;
import kotlinx.coroutines.flow.FlowKt;
import kotlinx.coroutines.flow.MutableStateFlow;
import kotlinx.coroutines.flow.StateFlowKt;
import kotlinx.coroutines.sync.Mutex;

@Metadata(d1 = {"\000\001\n\002\030\002\n\000\n\002\030\002\n\002\030\002\n\000\n\002\020\002\n\002\b\002\n\002\030\002\n\002\b\t\n\002\030\002\n\002\030\002\n\002\020\000\n\000\n\002\030\002\n\002\b\003\n\002\030\002\n\002\b\007\n\002\030\002\n\002\b\002\n\002\030\002\n\002\b\002\n\002\030\002\n\002\b\002\n\002\030\002\n\002\b\002\n\002\030\002\n\002\b\004\n\002\020\016\n\002\b\007\n\002\030\002\n\002\030\002\n\002\b\004\n\002\020 \n\002\030\002\n\002\b\002\n\002\030\002\n\002\030\002\n\002\b\t\b\000\030\000 L*\004\b\000\020\0012\b\022\004\022\0028\0000\002:\003LMNBr\022\f\020#\032\b\022\004\022\0020\0320\"\022\f\020&\032\b\022\004\022\0028\0000%\0220\b\002\020I\032*\022&\022$\b\001\022\n\022\b\022\004\022\0028\0000B\022\n\022\b\022\004\022\0020\0050\023\022\006\022\004\030\0010\0240\0220A\022\016\b\002\020)\032\b\022\004\022\0028\0000(\022\b\b\002\020,\032\0020+ø\001\000¢\006\004\bJ\020KJ!\020\006\032\0020\0052\f\020\004\032\b\022\004\022\0028\0000\003H@ø\001\000¢\006\004\b\006\020\007J!\020\n\032\0020\0052\f\020\t\032\b\022\004\022\0028\0000\bH@ø\001\000¢\006\004\b\n\020\013J\023\020\f\032\0020\005H@ø\001\000¢\006\004\b\f\020\rJ\023\020\016\032\0020\005H@ø\001\000¢\006\004\b\016\020\rJ\023\020\017\032\0020\005H@ø\001\000¢\006\004\b\017\020\rJ\023\020\020\032\0028\000H@ø\001\000¢\006\004\b\020\020\rJ\023\020\021\032\0028\000H@ø\001\000¢\006\004\b\021\020\rJ?\020\030\032\0028\0002\"\020\025\032\036\b\001\022\004\022\0028\000\022\n\022\b\022\004\022\0028\0000\023\022\006\022\004\030\0010\0240\0222\006\020\027\032\0020\026H@ø\001\000¢\006\004\b\030\020\031J\f\020\033\032\0020\005*\0020\032H\002J7\020\034\032\0028\0002\"\020\025\032\036\b\001\022\004\022\0028\000\022\n\022\b\022\004\022\0028\0000\023\022\006\022\004\030\0010\0240\022H@ø\001\000¢\006\004\b\034\020\035J\033\020!\032\0020\0052\006\020\036\032\0028\000H@ø\001\000¢\006\004\b\037\020 R\032\020#\032\b\022\004\022\0020\0320\"8\002X\004¢\006\006\n\004\b#\020$R\032\020&\032\b\022\004\022\0028\0000%8\002X\004¢\006\006\n\004\b&\020'R\032\020)\032\b\022\004\022\0028\0000(8\002X\004¢\006\006\n\004\b)\020*R\024\020,\032\0020+8\002X\004¢\006\006\n\004\b,\020-R \020/\032\b\022\004\022\0028\0000.8\026X\004¢\006\f\n\004\b/\0200\032\004\b1\0202R\024\0204\032\002038\002XD¢\006\006\n\004\b4\0205R\033\020:\032\0020\0328BX\002¢\006\f\n\004\b6\0207\032\004\b8\0209R&\020=\032\016\022\n\022\b\022\004\022\0028\0000<0;8\002X\004¢\006\f\n\004\b=\020>\022\004\b?\020@RC\020C\032,\022&\022$\b\001\022\n\022\b\022\004\022\0028\0000B\022\n\022\b\022\004\022\0020\0050\023\022\006\022\004\030\0010\0240\022\030\0010A8\002@\002X\016ø\001\000¢\006\006\n\004\bC\020DR \020G\032\016\022\n\022\b\022\004\022\0028\0000F0E8\002X\004¢\006\006\n\004\bG\020H\002\004\n\002\b\031¨\006O"}, d2 = {"Landroidx/datastore/core/SingleProcessDataStore;", "T", "Landroidx/datastore/core/DataStore;", "Landroidx/datastore/core/SingleProcessDataStore$Message$Read;", "read", "", "handleRead", "(Landroidx/datastore/core/SingleProcessDataStore$Message$Read;Lkotlin/coroutines/Continuation;)Ljava/lang/Object;", "Landroidx/datastore/core/SingleProcessDataStore$Message$Update;", "update", "handleUpdate", "(Landroidx/datastore/core/SingleProcessDataStore$Message$Update;Lkotlin/coroutines/Continuation;)Ljava/lang/Object;", "readAndInitOrPropagateAndThrowFailure", "(Lkotlin/coroutines/Continuation;)Ljava/lang/Object;", "readAndInitOrPropagateFailure", "readAndInit", "readDataOrHandleCorruption", "readData", "Lkotlin/Function2;", "Lkotlin/coroutines/Continuation;", "", "transform", "Lkotlin/coroutines/CoroutineContext;", "callerContext", "transformAndWrite", "(Lkotlin/jvm/functions/Function2;Lkotlin/coroutines/CoroutineContext;Lkotlin/coroutines/Continuation;)Ljava/lang/Object;", "Ljava/io/File;", "createParentDirectories", "updateData", "(Lkotlin/jvm/functions/Function2;Lkotlin/coroutines/Continuation;)Ljava/lang/Object;", "newData", "writeData$datastore_core", "(Ljava/lang/Object;Lkotlin/coroutines/Continuation;)Ljava/lang/Object;", "writeData", "Lkotlin/Function0;", "produceFile", "Lkotlin/jvm/functions/Function0;", "Landroidx/datastore/core/Serializer;", "serializer", "Landroidx/datastore/core/Serializer;", "Landroidx/datastore/core/CorruptionHandler;", "corruptionHandler", "Landroidx/datastore/core/CorruptionHandler;", "Lkotlinx/coroutines/CoroutineScope;", "scope", "Lkotlinx/coroutines/CoroutineScope;", "Lkotlinx/coroutines/flow/Flow;", "data", "Lkotlinx/coroutines/flow/Flow;", "getData", "()Lkotlinx/coroutines/flow/Flow;", "", "SCRATCH_SUFFIX", "Ljava/lang/String;", "file$delegate", "Lkotlin/Lazy;", "getFile", "()Ljava/io/File;", "file", "Lkotlinx/coroutines/flow/MutableStateFlow;", "Landroidx/datastore/core/State;", "downstreamFlow", "Lkotlinx/coroutines/flow/MutableStateFlow;", "getDownstreamFlow$annotations", "()V", "", "Landroidx/datastore/core/InitializerApi;", "initTasks", "Ljava/util/List;", "Landroidx/datastore/core/SimpleActor;", "Landroidx/datastore/core/SingleProcessDataStore$Message;", "actor", "Landroidx/datastore/core/SimpleActor;", "initTasksList", "<init>", "(Lkotlin/jvm/functions/Function0;Landroidx/datastore/core/Serializer;Ljava/util/List;Landroidx/datastore/core/CorruptionHandler;Lkotlinx/coroutines/CoroutineScope;)V", "Companion", "Message", "UncloseableOutputStream", "datastore-core"}, k = 1, mv = {1, 5, 1})
public final class SingleProcessDataStore<T> implements DataStore<T> {
  public static final Companion Companion = new Companion(null);
  
  @GuardedBy("activeFilesLock")
  private static final Set<String> activeFiles = new LinkedHashSet<String>();
  
  private static final Object activeFilesLock = new Object();
  
  private final String SCRATCH_SUFFIX;
  
  private final SimpleActor<Message<T>> actor;
  
  private final CorruptionHandler<T> corruptionHandler;
  
  private final Flow<T> data;
  
  private final MutableStateFlow<State<T>> downstreamFlow;
  
  private final Lazy file$delegate;
  
  private List<? extends Function2<? super InitializerApi<T>, ? super Continuation<? super Unit>, ? extends Object>> initTasks;
  
  private final Function0<File> produceFile;
  
  private final CoroutineScope scope;
  
  private final Serializer<T> serializer;
  
  public SingleProcessDataStore(Function0<? extends File> paramFunction0, Serializer<T> paramSerializer, List<? extends Function2<? super InitializerApi<T>, ? super Continuation<? super Unit>, ? extends Object>> paramList, CorruptionHandler<T> paramCorruptionHandler, CoroutineScope paramCoroutineScope) {
    this.produceFile = (Function0)paramFunction0;
    this.serializer = paramSerializer;
    this.corruptionHandler = paramCorruptionHandler;
    this.scope = paramCoroutineScope;
    this.data = FlowKt.flow(new SingleProcessDataStore$data$1(null));
    this.SCRATCH_SUFFIX = ".tmp";
    this.file$delegate = LazyKt.lazy(new SingleProcessDataStore$file$2());
    this.downstreamFlow = StateFlowKt.MutableStateFlow(UnInitialized.INSTANCE);
    this.initTasks = CollectionsKt.toList(paramList);
    this.actor = new SimpleActor(paramCoroutineScope, new SingleProcessDataStore$actor$1(), SingleProcessDataStore$actor$2.INSTANCE, new SingleProcessDataStore$actor$3(null));
  }
  
  private final void createParentDirectories(File paramFile) {
    File file = paramFile.getCanonicalFile().getParentFile();
    if (file == null)
      return; 
    file.mkdirs();
    if (file.isDirectory())
      return; 
    throw new IOException(Intrinsics.stringPlus("Unable to create parent directories of ", paramFile));
  }
  
  private final File getFile() {
    return (File)this.file$delegate.getValue();
  }
  
  private final Object handleRead(Message.Read<T> paramRead, Continuation<? super Unit> paramContinuation) {
    State<T> state = (State)this.downstreamFlow.getValue();
    if (!(state instanceof Data))
      if (state instanceof ReadException) {
        if (state == paramRead.getLastState()) {
          Object object = readAndInitOrPropagateFailure(paramContinuation);
          return (object == IntrinsicsKt.getCOROUTINE_SUSPENDED()) ? object : Unit.INSTANCE;
        } 
      } else {
        if (Intrinsics.areEqual(state, UnInitialized.INSTANCE)) {
          Object object = readAndInitOrPropagateFailure(paramContinuation);
          return (object == IntrinsicsKt.getCOROUTINE_SUSPENDED()) ? object : Unit.INSTANCE;
        } 
        if (state instanceof Final)
          throw new IllegalStateException("Can't read in final state.".toString()); 
      }  
    return Unit.INSTANCE;
  }
  
  private final Object handleUpdate(Message.Update<T> paramUpdate, Continuation<? super Unit> paramContinuation) {
    // Byte code:
    //   0: aload_2
    //   1: instanceof androidx/datastore/core/SingleProcessDataStore$handleUpdate$1
    //   4: ifeq -> 40
    //   7: aload_2
    //   8: checkcast androidx/datastore/core/SingleProcessDataStore$handleUpdate$1
    //   11: astore #6
    //   13: aload #6
    //   15: getfield label : I
    //   18: istore_3
    //   19: iload_3
    //   20: ldc_w -2147483648
    //   23: iand
    //   24: ifeq -> 40
    //   27: aload #6
    //   29: iload_3
    //   30: ldc_w -2147483648
    //   33: iadd
    //   34: putfield label : I
    //   37: goto -> 51
    //   40: new androidx/datastore/core/SingleProcessDataStore$handleUpdate$1
    //   43: dup
    //   44: aload_0
    //   45: aload_2
    //   46: invokespecial <init> : (Landroidx/datastore/core/SingleProcessDataStore;Lkotlin/coroutines/Continuation;)V
    //   49: astore #6
    //   51: aload #6
    //   53: getfield result : Ljava/lang/Object;
    //   56: astore #5
    //   58: invokestatic getCOROUTINE_SUSPENDED : ()Ljava/lang/Object;
    //   61: astore #9
    //   63: aload #6
    //   65: getfield label : I
    //   68: istore_3
    //   69: iconst_1
    //   70: istore #4
    //   72: iload_3
    //   73: ifeq -> 178
    //   76: iload_3
    //   77: iconst_1
    //   78: if_icmpeq -> 155
    //   81: iload_3
    //   82: iconst_2
    //   83: if_icmpeq -> 114
    //   86: iload_3
    //   87: iconst_3
    //   88: if_icmpne -> 103
    //   91: aload #6
    //   93: getfield L$0 : Ljava/lang/Object;
    //   96: checkcast kotlinx/coroutines/CompletableDeferred
    //   99: astore_2
    //   100: goto -> 164
    //   103: new java/lang/IllegalStateException
    //   106: dup
    //   107: ldc_w 'call to 'resume' before 'invoke' with coroutine'
    //   110: invokespecial <init> : (Ljava/lang/String;)V
    //   113: athrow
    //   114: aload #6
    //   116: getfield L$2 : Ljava/lang/Object;
    //   119: checkcast kotlinx/coroutines/CompletableDeferred
    //   122: astore_2
    //   123: aload #6
    //   125: getfield L$1 : Ljava/lang/Object;
    //   128: checkcast androidx/datastore/core/SingleProcessDataStore
    //   131: astore #7
    //   133: aload #6
    //   135: getfield L$0 : Ljava/lang/Object;
    //   138: checkcast androidx/datastore/core/SingleProcessDataStore$Message$Update
    //   141: astore #8
    //   143: aload_2
    //   144: astore_1
    //   145: aload #5
    //   147: invokestatic throwOnFailure : (Ljava/lang/Object;)V
    //   150: aload_2
    //   151: astore_1
    //   152: goto -> 386
    //   155: aload #6
    //   157: getfield L$0 : Ljava/lang/Object;
    //   160: checkcast kotlinx/coroutines/CompletableDeferred
    //   163: astore_2
    //   164: aload_2
    //   165: astore_1
    //   166: aload #5
    //   168: invokestatic throwOnFailure : (Ljava/lang/Object;)V
    //   171: goto -> 464
    //   174: astore_2
    //   175: goto -> 536
    //   178: aload #5
    //   180: invokestatic throwOnFailure : (Ljava/lang/Object;)V
    //   183: aload_1
    //   184: invokevirtual getAck : ()Lkotlinx/coroutines/CompletableDeferred;
    //   187: astore #5
    //   189: aload #5
    //   191: astore_2
    //   192: getstatic kotlin/Result.Companion : Lkotlin/Result$Companion;
    //   195: astore #7
    //   197: aload #5
    //   199: astore_2
    //   200: aload_0
    //   201: getfield downstreamFlow : Lkotlinx/coroutines/flow/MutableStateFlow;
    //   204: invokeinterface getValue : ()Ljava/lang/Object;
    //   209: checkcast androidx/datastore/core/State
    //   212: astore #7
    //   214: aload #5
    //   216: astore_2
    //   217: aload #7
    //   219: instanceof androidx/datastore/core/Data
    //   222: ifeq -> 291
    //   225: aload #5
    //   227: astore_2
    //   228: aload_1
    //   229: invokevirtual getTransform : ()Lkotlin/jvm/functions/Function2;
    //   232: astore #7
    //   234: aload #5
    //   236: astore_2
    //   237: aload_1
    //   238: invokevirtual getCallerContext : ()Lkotlin/coroutines/CoroutineContext;
    //   241: astore_1
    //   242: aload #5
    //   244: astore_2
    //   245: aload #6
    //   247: aload #5
    //   249: putfield L$0 : Ljava/lang/Object;
    //   252: aload #5
    //   254: astore_2
    //   255: aload #6
    //   257: iconst_1
    //   258: putfield label : I
    //   261: aload #5
    //   263: astore_2
    //   264: aload_0
    //   265: aload #7
    //   267: aload_1
    //   268: aload #6
    //   270: invokespecial transformAndWrite : (Lkotlin/jvm/functions/Function2;Lkotlin/coroutines/CoroutineContext;Lkotlin/coroutines/Continuation;)Ljava/lang/Object;
    //   273: astore #6
    //   275: aload #6
    //   277: astore_2
    //   278: aload #5
    //   280: astore_1
    //   281: aload #6
    //   283: aload #9
    //   285: if_acmpne -> 559
    //   288: aload #9
    //   290: areturn
    //   291: aload #5
    //   293: astore_2
    //   294: aload #7
    //   296: instanceof androidx/datastore/core/ReadException
    //   299: ifeq -> 305
    //   302: goto -> 315
    //   305: aload #5
    //   307: astore_2
    //   308: aload #7
    //   310: instanceof androidx/datastore/core/UnInitialized
    //   313: istore #4
    //   315: iload #4
    //   317: ifeq -> 493
    //   320: aload #5
    //   322: astore_2
    //   323: aload #7
    //   325: aload_1
    //   326: invokevirtual getLastState : ()Landroidx/datastore/core/State;
    //   329: if_acmpne -> 481
    //   332: aload #5
    //   334: astore_2
    //   335: aload #6
    //   337: aload_1
    //   338: putfield L$0 : Ljava/lang/Object;
    //   341: aload #5
    //   343: astore_2
    //   344: aload #6
    //   346: aload_0
    //   347: putfield L$1 : Ljava/lang/Object;
    //   350: aload #5
    //   352: astore_2
    //   353: aload #6
    //   355: aload #5
    //   357: putfield L$2 : Ljava/lang/Object;
    //   360: aload #5
    //   362: astore_2
    //   363: aload #6
    //   365: iconst_2
    //   366: putfield label : I
    //   369: aload #5
    //   371: astore_2
    //   372: aload_0
    //   373: aload #6
    //   375: invokespecial readAndInitOrPropagateAndThrowFailure : (Lkotlin/coroutines/Continuation;)Ljava/lang/Object;
    //   378: aload #9
    //   380: if_acmpne -> 567
    //   383: aload #9
    //   385: areturn
    //   386: aload_1
    //   387: astore_2
    //   388: aload #8
    //   390: invokevirtual getTransform : ()Lkotlin/jvm/functions/Function2;
    //   393: astore #5
    //   395: aload_1
    //   396: astore_2
    //   397: aload #8
    //   399: invokevirtual getCallerContext : ()Lkotlin/coroutines/CoroutineContext;
    //   402: astore #8
    //   404: aload_1
    //   405: astore_2
    //   406: aload #6
    //   408: aload_1
    //   409: putfield L$0 : Ljava/lang/Object;
    //   412: aload_1
    //   413: astore_2
    //   414: aload #6
    //   416: aconst_null
    //   417: putfield L$1 : Ljava/lang/Object;
    //   420: aload_1
    //   421: astore_2
    //   422: aload #6
    //   424: aconst_null
    //   425: putfield L$2 : Ljava/lang/Object;
    //   428: aload_1
    //   429: astore_2
    //   430: aload #6
    //   432: iconst_3
    //   433: putfield label : I
    //   436: aload_1
    //   437: astore_2
    //   438: aload #7
    //   440: aload #5
    //   442: aload #8
    //   444: aload #6
    //   446: invokespecial transformAndWrite : (Lkotlin/jvm/functions/Function2;Lkotlin/coroutines/CoroutineContext;Lkotlin/coroutines/Continuation;)Ljava/lang/Object;
    //   449: astore #5
    //   451: aload #5
    //   453: astore_2
    //   454: aload #5
    //   456: aload #9
    //   458: if_acmpne -> 559
    //   461: aload #9
    //   463: areturn
    //   464: aload_2
    //   465: astore_1
    //   466: aload #5
    //   468: invokestatic constructor-impl : (Ljava/lang/Object;)Ljava/lang/Object;
    //   471: astore #5
    //   473: aload_2
    //   474: astore_1
    //   475: aload #5
    //   477: astore_2
    //   478: goto -> 549
    //   481: aload #5
    //   483: astore_2
    //   484: aload #7
    //   486: checkcast androidx/datastore/core/ReadException
    //   489: invokevirtual getReadException : ()Ljava/lang/Throwable;
    //   492: athrow
    //   493: aload #5
    //   495: astore_2
    //   496: aload #7
    //   498: instanceof androidx/datastore/core/Final
    //   501: ifeq -> 516
    //   504: aload #5
    //   506: astore_2
    //   507: aload #7
    //   509: checkcast androidx/datastore/core/Final
    //   512: invokevirtual getFinalException : ()Ljava/lang/Throwable;
    //   515: athrow
    //   516: aload #5
    //   518: astore_2
    //   519: new kotlin/NoWhenBranchMatchedException
    //   522: dup
    //   523: invokespecial <init> : ()V
    //   526: athrow
    //   527: astore_1
    //   528: aload_2
    //   529: astore #5
    //   531: aload_1
    //   532: astore_2
    //   533: aload #5
    //   535: astore_1
    //   536: getstatic kotlin/Result.Companion : Lkotlin/Result$Companion;
    //   539: astore #5
    //   541: aload_2
    //   542: invokestatic createFailure : (Ljava/lang/Throwable;)Ljava/lang/Object;
    //   545: invokestatic constructor-impl : (Ljava/lang/Object;)Ljava/lang/Object;
    //   548: astore_2
    //   549: aload_1
    //   550: aload_2
    //   551: invokestatic completeWith : (Lkotlinx/coroutines/CompletableDeferred;Ljava/lang/Object;)Z
    //   554: pop
    //   555: getstatic kotlin/Unit.INSTANCE : Lkotlin/Unit;
    //   558: areturn
    //   559: aload_2
    //   560: astore #5
    //   562: aload_1
    //   563: astore_2
    //   564: goto -> 464
    //   567: aload_0
    //   568: astore #7
    //   570: aload_1
    //   571: astore #8
    //   573: aload #5
    //   575: astore_1
    //   576: goto -> 386
    // Exception table:
    //   from	to	target	type
    //   145	150	174	finally
    //   166	171	174	finally
    //   192	197	527	finally
    //   200	214	527	finally
    //   217	225	527	finally
    //   228	234	527	finally
    //   237	242	527	finally
    //   245	252	527	finally
    //   255	261	527	finally
    //   264	275	527	finally
    //   294	302	527	finally
    //   308	315	527	finally
    //   323	332	527	finally
    //   335	341	527	finally
    //   344	350	527	finally
    //   353	360	527	finally
    //   363	369	527	finally
    //   372	383	527	finally
    //   388	395	527	finally
    //   397	404	527	finally
    //   406	412	527	finally
    //   414	420	527	finally
    //   422	428	527	finally
    //   430	436	527	finally
    //   438	451	527	finally
    //   466	473	174	finally
    //   484	493	527	finally
    //   496	504	527	finally
    //   507	516	527	finally
    //   519	527	527	finally
  }
  
  private final Object readAndInit(Continuation<? super Unit> paramContinuation) {
    // Byte code:
    //   0: aload_1
    //   1: instanceof androidx/datastore/core/SingleProcessDataStore$readAndInit$1
    //   4: ifeq -> 40
    //   7: aload_1
    //   8: checkcast androidx/datastore/core/SingleProcessDataStore$readAndInit$1
    //   11: astore #6
    //   13: aload #6
    //   15: getfield label : I
    //   18: istore_2
    //   19: iload_2
    //   20: ldc_w -2147483648
    //   23: iand
    //   24: ifeq -> 40
    //   27: aload #6
    //   29: iload_2
    //   30: ldc_w -2147483648
    //   33: iadd
    //   34: putfield label : I
    //   37: goto -> 51
    //   40: new androidx/datastore/core/SingleProcessDataStore$readAndInit$1
    //   43: dup
    //   44: aload_0
    //   45: aload_1
    //   46: invokespecial <init> : (Landroidx/datastore/core/SingleProcessDataStore;Lkotlin/coroutines/Continuation;)V
    //   49: astore #6
    //   51: aload #6
    //   53: getfield result : Ljava/lang/Object;
    //   56: astore #8
    //   58: invokestatic getCOROUTINE_SUSPENDED : ()Ljava/lang/Object;
    //   61: astore #12
    //   63: aload #6
    //   65: getfield label : I
    //   68: istore_2
    //   69: iconst_0
    //   70: istore_3
    //   71: iload_2
    //   72: ifeq -> 270
    //   75: iload_2
    //   76: iconst_1
    //   77: if_icmpeq -> 223
    //   80: iload_2
    //   81: iconst_2
    //   82: if_icmpeq -> 152
    //   85: iload_2
    //   86: iconst_3
    //   87: if_icmpne -> 141
    //   90: aload #6
    //   92: getfield L$3 : Ljava/lang/Object;
    //   95: checkcast kotlinx/coroutines/sync/Mutex
    //   98: astore #5
    //   100: aload #6
    //   102: getfield L$2 : Ljava/lang/Object;
    //   105: checkcast kotlin/jvm/internal/Ref$BooleanRef
    //   108: astore #7
    //   110: aload #6
    //   112: getfield L$1 : Ljava/lang/Object;
    //   115: checkcast kotlin/jvm/internal/Ref$ObjectRef
    //   118: astore_1
    //   119: aload #6
    //   121: getfield L$0 : Ljava/lang/Object;
    //   124: checkcast androidx/datastore/core/SingleProcessDataStore
    //   127: astore #4
    //   129: aload #8
    //   131: invokestatic throwOnFailure : (Ljava/lang/Object;)V
    //   134: aload #7
    //   136: astore #6
    //   138: goto -> 662
    //   141: new java/lang/IllegalStateException
    //   144: dup
    //   145: ldc_w 'call to 'resume' before 'invoke' with coroutine'
    //   148: invokespecial <init> : (Ljava/lang/String;)V
    //   151: athrow
    //   152: aload #6
    //   154: getfield L$5 : Ljava/lang/Object;
    //   157: checkcast java/util/Iterator
    //   160: astore #9
    //   162: aload #6
    //   164: getfield L$4 : Ljava/lang/Object;
    //   167: checkcast androidx/datastore/core/SingleProcessDataStore$readAndInit$api$1
    //   170: astore #10
    //   172: aload #6
    //   174: getfield L$3 : Ljava/lang/Object;
    //   177: checkcast kotlin/jvm/internal/Ref$BooleanRef
    //   180: astore_1
    //   181: aload #6
    //   183: getfield L$2 : Ljava/lang/Object;
    //   186: checkcast kotlin/jvm/internal/Ref$ObjectRef
    //   189: astore #7
    //   191: aload #6
    //   193: getfield L$1 : Ljava/lang/Object;
    //   196: checkcast kotlinx/coroutines/sync/Mutex
    //   199: astore #5
    //   201: aload #6
    //   203: getfield L$0 : Ljava/lang/Object;
    //   206: checkcast androidx/datastore/core/SingleProcessDataStore
    //   209: astore #4
    //   211: aload #8
    //   213: invokestatic throwOnFailure : (Ljava/lang/Object;)V
    //   216: aload #10
    //   218: astore #8
    //   220: goto -> 499
    //   223: aload #6
    //   225: getfield L$3 : Ljava/lang/Object;
    //   228: checkcast kotlin/jvm/internal/Ref$ObjectRef
    //   231: astore #7
    //   233: aload #6
    //   235: getfield L$2 : Ljava/lang/Object;
    //   238: checkcast kotlin/jvm/internal/Ref$ObjectRef
    //   241: astore_1
    //   242: aload #6
    //   244: getfield L$1 : Ljava/lang/Object;
    //   247: checkcast kotlinx/coroutines/sync/Mutex
    //   250: astore #4
    //   252: aload #6
    //   254: getfield L$0 : Ljava/lang/Object;
    //   257: checkcast androidx/datastore/core/SingleProcessDataStore
    //   260: astore #5
    //   262: aload #8
    //   264: invokestatic throwOnFailure : (Ljava/lang/Object;)V
    //   267: goto -> 396
    //   270: aload #8
    //   272: invokestatic throwOnFailure : (Ljava/lang/Object;)V
    //   275: aload_0
    //   276: getfield downstreamFlow : Lkotlinx/coroutines/flow/MutableStateFlow;
    //   279: invokeinterface getValue : ()Ljava/lang/Object;
    //   284: getstatic androidx/datastore/core/UnInitialized.INSTANCE : Landroidx/datastore/core/UnInitialized;
    //   287: invokestatic areEqual : (Ljava/lang/Object;Ljava/lang/Object;)Z
    //   290: ifne -> 316
    //   293: aload_0
    //   294: getfield downstreamFlow : Lkotlinx/coroutines/flow/MutableStateFlow;
    //   297: invokeinterface getValue : ()Ljava/lang/Object;
    //   302: instanceof androidx/datastore/core/ReadException
    //   305: ifeq -> 311
    //   308: goto -> 316
    //   311: iconst_0
    //   312: istore_2
    //   313: goto -> 318
    //   316: iconst_1
    //   317: istore_2
    //   318: iload_2
    //   319: ifeq -> 735
    //   322: iconst_0
    //   323: iconst_1
    //   324: aconst_null
    //   325: invokestatic Mutex$default : (ZILjava/lang/Object;)Lkotlinx/coroutines/sync/Mutex;
    //   328: astore #4
    //   330: new kotlin/jvm/internal/Ref$ObjectRef
    //   333: dup
    //   334: invokespecial <init> : ()V
    //   337: astore #7
    //   339: aload #6
    //   341: aload_0
    //   342: putfield L$0 : Ljava/lang/Object;
    //   345: aload #6
    //   347: aload #4
    //   349: putfield L$1 : Ljava/lang/Object;
    //   352: aload #6
    //   354: aload #7
    //   356: putfield L$2 : Ljava/lang/Object;
    //   359: aload #6
    //   361: aload #7
    //   363: putfield L$3 : Ljava/lang/Object;
    //   366: aload #6
    //   368: iconst_1
    //   369: putfield label : I
    //   372: aload_0
    //   373: aload #6
    //   375: invokespecial readDataOrHandleCorruption : (Lkotlin/coroutines/Continuation;)Ljava/lang/Object;
    //   378: astore #8
    //   380: aload #8
    //   382: aload #12
    //   384: if_acmpne -> 390
    //   387: aload #12
    //   389: areturn
    //   390: aload_0
    //   391: astore #5
    //   393: aload #7
    //   395: astore_1
    //   396: aload #7
    //   398: aload #8
    //   400: putfield element : Ljava/lang/Object;
    //   403: new kotlin/jvm/internal/Ref$BooleanRef
    //   406: dup
    //   407: invokespecial <init> : ()V
    //   410: astore #7
    //   412: new androidx/datastore/core/SingleProcessDataStore$readAndInit$api$1
    //   415: dup
    //   416: aload #4
    //   418: aload #7
    //   420: aload_1
    //   421: aload #5
    //   423: invokespecial <init> : (Lkotlinx/coroutines/sync/Mutex;Lkotlin/jvm/internal/Ref$BooleanRef;Lkotlin/jvm/internal/Ref$ObjectRef;Landroidx/datastore/core/SingleProcessDataStore;)V
    //   426: astore #8
    //   428: aload #5
    //   430: getfield initTasks : Ljava/util/List;
    //   433: astore #9
    //   435: aload #9
    //   437: ifnonnull -> 465
    //   440: aload #4
    //   442: astore #9
    //   444: aload #7
    //   446: astore #8
    //   448: aload #5
    //   450: astore #4
    //   452: aload #9
    //   454: astore #5
    //   456: aload_1
    //   457: astore #7
    //   459: aload #8
    //   461: astore_1
    //   462: goto -> 587
    //   465: aload #9
    //   467: checkcast java/lang/Iterable
    //   470: invokeinterface iterator : ()Ljava/util/Iterator;
    //   475: astore #9
    //   477: aload #4
    //   479: astore #11
    //   481: aload #7
    //   483: astore #10
    //   485: aload #5
    //   487: astore #4
    //   489: aload #11
    //   491: astore #5
    //   493: aload_1
    //   494: astore #7
    //   496: aload #10
    //   498: astore_1
    //   499: aload #9
    //   501: invokeinterface hasNext : ()Z
    //   506: ifeq -> 587
    //   509: aload #9
    //   511: invokeinterface next : ()Ljava/lang/Object;
    //   516: checkcast kotlin/jvm/functions/Function2
    //   519: astore #10
    //   521: aload #6
    //   523: aload #4
    //   525: putfield L$0 : Ljava/lang/Object;
    //   528: aload #6
    //   530: aload #5
    //   532: putfield L$1 : Ljava/lang/Object;
    //   535: aload #6
    //   537: aload #7
    //   539: putfield L$2 : Ljava/lang/Object;
    //   542: aload #6
    //   544: aload_1
    //   545: putfield L$3 : Ljava/lang/Object;
    //   548: aload #6
    //   550: aload #8
    //   552: putfield L$4 : Ljava/lang/Object;
    //   555: aload #6
    //   557: aload #9
    //   559: putfield L$5 : Ljava/lang/Object;
    //   562: aload #6
    //   564: iconst_2
    //   565: putfield label : I
    //   568: aload #10
    //   570: aload #8
    //   572: aload #6
    //   574: invokeinterface invoke : (Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    //   579: aload #12
    //   581: if_acmpne -> 499
    //   584: aload #12
    //   586: areturn
    //   587: aload #4
    //   589: aconst_null
    //   590: putfield initTasks : Ljava/util/List;
    //   593: aload #6
    //   595: aload #4
    //   597: putfield L$0 : Ljava/lang/Object;
    //   600: aload #6
    //   602: aload #7
    //   604: putfield L$1 : Ljava/lang/Object;
    //   607: aload #6
    //   609: aload_1
    //   610: putfield L$2 : Ljava/lang/Object;
    //   613: aload #6
    //   615: aload #5
    //   617: putfield L$3 : Ljava/lang/Object;
    //   620: aload #6
    //   622: aconst_null
    //   623: putfield L$4 : Ljava/lang/Object;
    //   626: aload #6
    //   628: aconst_null
    //   629: putfield L$5 : Ljava/lang/Object;
    //   632: aload #6
    //   634: iconst_3
    //   635: putfield label : I
    //   638: aload #5
    //   640: aconst_null
    //   641: aload #6
    //   643: invokeinterface lock : (Ljava/lang/Object;Lkotlin/coroutines/Continuation;)Ljava/lang/Object;
    //   648: aload #12
    //   650: if_acmpne -> 656
    //   653: aload #12
    //   655: areturn
    //   656: aload_1
    //   657: astore #6
    //   659: aload #7
    //   661: astore_1
    //   662: aload #6
    //   664: iconst_1
    //   665: putfield element : Z
    //   668: getstatic kotlin/Unit.INSTANCE : Lkotlin/Unit;
    //   671: astore #6
    //   673: aload #5
    //   675: aconst_null
    //   676: invokeinterface unlock : (Ljava/lang/Object;)V
    //   681: aload #4
    //   683: getfield downstreamFlow : Lkotlinx/coroutines/flow/MutableStateFlow;
    //   686: astore #4
    //   688: aload_1
    //   689: getfield element : Ljava/lang/Object;
    //   692: astore_1
    //   693: iload_3
    //   694: istore_2
    //   695: aload_1
    //   696: ifnull -> 704
    //   699: aload_1
    //   700: invokevirtual hashCode : ()I
    //   703: istore_2
    //   704: aload #4
    //   706: new androidx/datastore/core/Data
    //   709: dup
    //   710: aload_1
    //   711: iload_2
    //   712: invokespecial <init> : (Ljava/lang/Object;I)V
    //   715: invokeinterface setValue : (Ljava/lang/Object;)V
    //   720: getstatic kotlin/Unit.INSTANCE : Lkotlin/Unit;
    //   723: areturn
    //   724: astore_1
    //   725: aload #5
    //   727: aconst_null
    //   728: invokeinterface unlock : (Ljava/lang/Object;)V
    //   733: aload_1
    //   734: athrow
    //   735: new java/lang/IllegalStateException
    //   738: dup
    //   739: ldc_w 'Check failed.'
    //   742: invokevirtual toString : ()Ljava/lang/String;
    //   745: invokespecial <init> : (Ljava/lang/String;)V
    //   748: athrow
    // Exception table:
    //   from	to	target	type
    //   662	673	724	finally
  }
  
  private final Object readAndInitOrPropagateAndThrowFailure(Continuation<? super Unit> paramContinuation) {
    // Byte code:
    //   0: aload_1
    //   1: instanceof androidx/datastore/core/SingleProcessDataStore$readAndInitOrPropagateAndThrowFailure$1
    //   4: ifeq -> 39
    //   7: aload_1
    //   8: checkcast androidx/datastore/core/SingleProcessDataStore$readAndInitOrPropagateAndThrowFailure$1
    //   11: astore_3
    //   12: aload_3
    //   13: getfield label : I
    //   16: istore_2
    //   17: iload_2
    //   18: ldc_w -2147483648
    //   21: iand
    //   22: ifeq -> 39
    //   25: aload_3
    //   26: iload_2
    //   27: ldc_w -2147483648
    //   30: iadd
    //   31: putfield label : I
    //   34: aload_3
    //   35: astore_1
    //   36: goto -> 49
    //   39: new androidx/datastore/core/SingleProcessDataStore$readAndInitOrPropagateAndThrowFailure$1
    //   42: dup
    //   43: aload_0
    //   44: aload_1
    //   45: invokespecial <init> : (Landroidx/datastore/core/SingleProcessDataStore;Lkotlin/coroutines/Continuation;)V
    //   48: astore_1
    //   49: aload_1
    //   50: getfield result : Ljava/lang/Object;
    //   53: astore_3
    //   54: invokestatic getCOROUTINE_SUSPENDED : ()Ljava/lang/Object;
    //   57: astore #4
    //   59: aload_1
    //   60: getfield label : I
    //   63: istore_2
    //   64: iload_2
    //   65: ifeq -> 103
    //   68: iload_2
    //   69: iconst_1
    //   70: if_icmpne -> 92
    //   73: aload_1
    //   74: getfield L$0 : Ljava/lang/Object;
    //   77: checkcast androidx/datastore/core/SingleProcessDataStore
    //   80: astore_1
    //   81: aload_3
    //   82: invokestatic throwOnFailure : (Ljava/lang/Object;)V
    //   85: goto -> 132
    //   88: astore_3
    //   89: goto -> 139
    //   92: new java/lang/IllegalStateException
    //   95: dup
    //   96: ldc_w 'call to 'resume' before 'invoke' with coroutine'
    //   99: invokespecial <init> : (Ljava/lang/String;)V
    //   102: athrow
    //   103: aload_3
    //   104: invokestatic throwOnFailure : (Ljava/lang/Object;)V
    //   107: aload_1
    //   108: aload_0
    //   109: putfield L$0 : Ljava/lang/Object;
    //   112: aload_1
    //   113: iconst_1
    //   114: putfield label : I
    //   117: aload_0
    //   118: aload_1
    //   119: invokespecial readAndInit : (Lkotlin/coroutines/Continuation;)Ljava/lang/Object;
    //   122: astore_1
    //   123: aload_1
    //   124: aload #4
    //   126: if_acmpne -> 132
    //   129: aload #4
    //   131: areturn
    //   132: getstatic kotlin/Unit.INSTANCE : Lkotlin/Unit;
    //   135: areturn
    //   136: astore_3
    //   137: aload_0
    //   138: astore_1
    //   139: aload_1
    //   140: getfield downstreamFlow : Lkotlinx/coroutines/flow/MutableStateFlow;
    //   143: new androidx/datastore/core/ReadException
    //   146: dup
    //   147: aload_3
    //   148: invokespecial <init> : (Ljava/lang/Throwable;)V
    //   151: invokeinterface setValue : (Ljava/lang/Object;)V
    //   156: aload_3
    //   157: athrow
    // Exception table:
    //   from	to	target	type
    //   81	85	88	finally
    //   107	123	136	finally
  }
  
  private final Object readAndInitOrPropagateFailure(Continuation<? super Unit> paramContinuation) {
    // Byte code:
    //   0: aload_1
    //   1: instanceof androidx/datastore/core/SingleProcessDataStore$readAndInitOrPropagateFailure$1
    //   4: ifeq -> 39
    //   7: aload_1
    //   8: checkcast androidx/datastore/core/SingleProcessDataStore$readAndInitOrPropagateFailure$1
    //   11: astore_3
    //   12: aload_3
    //   13: getfield label : I
    //   16: istore_2
    //   17: iload_2
    //   18: ldc_w -2147483648
    //   21: iand
    //   22: ifeq -> 39
    //   25: aload_3
    //   26: iload_2
    //   27: ldc_w -2147483648
    //   30: iadd
    //   31: putfield label : I
    //   34: aload_3
    //   35: astore_1
    //   36: goto -> 49
    //   39: new androidx/datastore/core/SingleProcessDataStore$readAndInitOrPropagateFailure$1
    //   42: dup
    //   43: aload_0
    //   44: aload_1
    //   45: invokespecial <init> : (Landroidx/datastore/core/SingleProcessDataStore;Lkotlin/coroutines/Continuation;)V
    //   48: astore_1
    //   49: aload_1
    //   50: getfield result : Ljava/lang/Object;
    //   53: astore_3
    //   54: invokestatic getCOROUTINE_SUSPENDED : ()Ljava/lang/Object;
    //   57: astore #4
    //   59: aload_1
    //   60: getfield label : I
    //   63: istore_2
    //   64: iload_2
    //   65: ifeq -> 103
    //   68: iload_2
    //   69: iconst_1
    //   70: if_icmpne -> 92
    //   73: aload_1
    //   74: getfield L$0 : Ljava/lang/Object;
    //   77: checkcast androidx/datastore/core/SingleProcessDataStore
    //   80: astore_1
    //   81: aload_3
    //   82: invokestatic throwOnFailure : (Ljava/lang/Object;)V
    //   85: goto -> 152
    //   88: astore_3
    //   89: goto -> 135
    //   92: new java/lang/IllegalStateException
    //   95: dup
    //   96: ldc_w 'call to 'resume' before 'invoke' with coroutine'
    //   99: invokespecial <init> : (Ljava/lang/String;)V
    //   102: athrow
    //   103: aload_3
    //   104: invokestatic throwOnFailure : (Ljava/lang/Object;)V
    //   107: aload_1
    //   108: aload_0
    //   109: putfield L$0 : Ljava/lang/Object;
    //   112: aload_1
    //   113: iconst_1
    //   114: putfield label : I
    //   117: aload_0
    //   118: aload_1
    //   119: invokespecial readAndInit : (Lkotlin/coroutines/Continuation;)Ljava/lang/Object;
    //   122: astore_1
    //   123: aload_1
    //   124: aload #4
    //   126: if_acmpne -> 152
    //   129: aload #4
    //   131: areturn
    //   132: astore_3
    //   133: aload_0
    //   134: astore_1
    //   135: aload_1
    //   136: getfield downstreamFlow : Lkotlinx/coroutines/flow/MutableStateFlow;
    //   139: new androidx/datastore/core/ReadException
    //   142: dup
    //   143: aload_3
    //   144: invokespecial <init> : (Ljava/lang/Throwable;)V
    //   147: invokeinterface setValue : (Ljava/lang/Object;)V
    //   152: getstatic kotlin/Unit.INSTANCE : Lkotlin/Unit;
    //   155: areturn
    // Exception table:
    //   from	to	target	type
    //   81	85	88	finally
    //   107	123	132	finally
  }
  
  private final Object readData(Continuation<? super T> paramContinuation) {
    // Byte code:
    //   0: aload_1
    //   1: instanceof androidx/datastore/core/SingleProcessDataStore$readData$1
    //   4: ifeq -> 37
    //   7: aload_1
    //   8: checkcast androidx/datastore/core/SingleProcessDataStore$readData$1
    //   11: astore_3
    //   12: aload_3
    //   13: getfield label : I
    //   16: istore_2
    //   17: iload_2
    //   18: ldc_w -2147483648
    //   21: iand
    //   22: ifeq -> 37
    //   25: aload_3
    //   26: iload_2
    //   27: ldc_w -2147483648
    //   30: iadd
    //   31: putfield label : I
    //   34: goto -> 47
    //   37: new androidx/datastore/core/SingleProcessDataStore$readData$1
    //   40: dup
    //   41: aload_0
    //   42: aload_1
    //   43: invokespecial <init> : (Landroidx/datastore/core/SingleProcessDataStore;Lkotlin/coroutines/Continuation;)V
    //   46: astore_3
    //   47: aload_3
    //   48: getfield result : Ljava/lang/Object;
    //   51: astore #5
    //   53: invokestatic getCOROUTINE_SUSPENDED : ()Ljava/lang/Object;
    //   56: astore #4
    //   58: aload_3
    //   59: getfield label : I
    //   62: istore_2
    //   63: iload_2
    //   64: ifeq -> 127
    //   67: iload_2
    //   68: iconst_1
    //   69: if_icmpne -> 116
    //   72: aload_3
    //   73: getfield L$2 : Ljava/lang/Object;
    //   76: checkcast java/lang/Throwable
    //   79: astore #6
    //   81: aload_3
    //   82: getfield L$1 : Ljava/lang/Object;
    //   85: checkcast java/io/Closeable
    //   88: astore #4
    //   90: aload_3
    //   91: getfield L$0 : Ljava/lang/Object;
    //   94: checkcast androidx/datastore/core/SingleProcessDataStore
    //   97: astore_1
    //   98: aload #5
    //   100: invokestatic throwOnFailure : (Ljava/lang/Object;)V
    //   103: aload #6
    //   105: astore_3
    //   106: goto -> 202
    //   109: astore #5
    //   111: aload_1
    //   112: astore_3
    //   113: goto -> 222
    //   116: new java/lang/IllegalStateException
    //   119: dup
    //   120: ldc_w 'call to 'resume' before 'invoke' with coroutine'
    //   123: invokespecial <init> : (Ljava/lang/String;)V
    //   126: athrow
    //   127: aload #5
    //   129: invokestatic throwOnFailure : (Ljava/lang/Object;)V
    //   132: new java/io/FileInputStream
    //   135: dup
    //   136: aload_0
    //   137: invokespecial getFile : ()Ljava/io/File;
    //   140: invokespecial <init> : (Ljava/io/File;)V
    //   143: astore_1
    //   144: aload_0
    //   145: getfield serializer : Landroidx/datastore/core/Serializer;
    //   148: astore #5
    //   150: aload_3
    //   151: aload_0
    //   152: putfield L$0 : Ljava/lang/Object;
    //   155: aload_3
    //   156: aload_1
    //   157: putfield L$1 : Ljava/lang/Object;
    //   160: aload_3
    //   161: aconst_null
    //   162: putfield L$2 : Ljava/lang/Object;
    //   165: aload_3
    //   166: iconst_1
    //   167: putfield label : I
    //   170: aload #5
    //   172: aload_1
    //   173: aload_3
    //   174: invokeinterface readFrom : (Ljava/io/InputStream;Lkotlin/coroutines/Continuation;)Ljava/lang/Object;
    //   179: astore #5
    //   181: aload #5
    //   183: aload #4
    //   185: if_acmpne -> 191
    //   188: aload #4
    //   190: areturn
    //   191: aload_0
    //   192: astore #6
    //   194: aconst_null
    //   195: astore_3
    //   196: aload_1
    //   197: astore #4
    //   199: aload #6
    //   201: astore_1
    //   202: aload #4
    //   204: aload_3
    //   205: invokestatic closeFinally : (Ljava/io/Closeable;Ljava/lang/Throwable;)V
    //   208: aload #5
    //   210: areturn
    //   211: astore_3
    //   212: goto -> 244
    //   215: astore #5
    //   217: aload_0
    //   218: astore_3
    //   219: aload_1
    //   220: astore #4
    //   222: aload #5
    //   224: athrow
    //   225: astore #6
    //   227: aload_3
    //   228: astore_1
    //   229: aload #4
    //   231: aload #5
    //   233: invokestatic closeFinally : (Ljava/io/Closeable;Ljava/lang/Throwable;)V
    //   236: aload_3
    //   237: astore_1
    //   238: aload #6
    //   240: athrow
    //   241: astore_3
    //   242: aload_0
    //   243: astore_1
    //   244: aload_1
    //   245: invokespecial getFile : ()Ljava/io/File;
    //   248: invokevirtual exists : ()Z
    //   251: ifne -> 264
    //   254: aload_1
    //   255: getfield serializer : Landroidx/datastore/core/Serializer;
    //   258: invokeinterface getDefaultValue : ()Ljava/lang/Object;
    //   263: areturn
    //   264: aload_3
    //   265: athrow
    // Exception table:
    //   from	to	target	type
    //   98	103	109	finally
    //   132	144	241	java/io/FileNotFoundException
    //   144	181	215	finally
    //   202	208	211	java/io/FileNotFoundException
    //   222	225	225	finally
    //   229	236	211	java/io/FileNotFoundException
    //   238	241	211	java/io/FileNotFoundException
  }
  
  private final Object readDataOrHandleCorruption(Continuation<? super T> paramContinuation) {
    // Byte code:
    //   0: aload_1
    //   1: instanceof androidx/datastore/core/SingleProcessDataStore$readDataOrHandleCorruption$1
    //   4: ifeq -> 40
    //   7: aload_1
    //   8: checkcast androidx/datastore/core/SingleProcessDataStore$readDataOrHandleCorruption$1
    //   11: astore #4
    //   13: aload #4
    //   15: getfield label : I
    //   18: istore_2
    //   19: iload_2
    //   20: ldc_w -2147483648
    //   23: iand
    //   24: ifeq -> 40
    //   27: aload #4
    //   29: iload_2
    //   30: ldc_w -2147483648
    //   33: iadd
    //   34: putfield label : I
    //   37: goto -> 51
    //   40: new androidx/datastore/core/SingleProcessDataStore$readDataOrHandleCorruption$1
    //   43: dup
    //   44: aload_0
    //   45: aload_1
    //   46: invokespecial <init> : (Landroidx/datastore/core/SingleProcessDataStore;Lkotlin/coroutines/Continuation;)V
    //   49: astore #4
    //   51: aload #4
    //   53: getfield result : Ljava/lang/Object;
    //   56: astore #5
    //   58: invokestatic getCOROUTINE_SUSPENDED : ()Ljava/lang/Object;
    //   61: astore #7
    //   63: aload #4
    //   65: getfield label : I
    //   68: istore_2
    //   69: iload_2
    //   70: ifeq -> 173
    //   73: iload_2
    //   74: iconst_1
    //   75: if_icmpeq -> 152
    //   78: iload_2
    //   79: iconst_2
    //   80: if_icmpeq -> 125
    //   83: iload_2
    //   84: iconst_3
    //   85: if_icmpne -> 114
    //   88: aload #4
    //   90: getfield L$1 : Ljava/lang/Object;
    //   93: astore_3
    //   94: aload #4
    //   96: getfield L$0 : Ljava/lang/Object;
    //   99: checkcast androidx/datastore/core/CorruptionException
    //   102: astore_1
    //   103: aload #5
    //   105: invokestatic throwOnFailure : (Ljava/lang/Object;)V
    //   108: aload_3
    //   109: areturn
    //   110: astore_3
    //   111: goto -> 304
    //   114: new java/lang/IllegalStateException
    //   117: dup
    //   118: ldc_w 'call to 'resume' before 'invoke' with coroutine'
    //   121: invokespecial <init> : (Ljava/lang/String;)V
    //   124: athrow
    //   125: aload #4
    //   127: getfield L$1 : Ljava/lang/Object;
    //   130: checkcast androidx/datastore/core/CorruptionException
    //   133: astore_1
    //   134: aload #4
    //   136: getfield L$0 : Ljava/lang/Object;
    //   139: checkcast androidx/datastore/core/SingleProcessDataStore
    //   142: astore #6
    //   144: aload #5
    //   146: invokestatic throwOnFailure : (Ljava/lang/Object;)V
    //   149: goto -> 262
    //   152: aload #4
    //   154: getfield L$0 : Ljava/lang/Object;
    //   157: checkcast androidx/datastore/core/SingleProcessDataStore
    //   160: astore_1
    //   161: aload #5
    //   163: invokestatic throwOnFailure : (Ljava/lang/Object;)V
    //   166: aload #5
    //   168: areturn
    //   169: astore_3
    //   170: goto -> 211
    //   173: aload #5
    //   175: invokestatic throwOnFailure : (Ljava/lang/Object;)V
    //   178: aload #4
    //   180: aload_0
    //   181: putfield L$0 : Ljava/lang/Object;
    //   184: aload #4
    //   186: iconst_1
    //   187: putfield label : I
    //   190: aload_0
    //   191: aload #4
    //   193: invokespecial readData : (Lkotlin/coroutines/Continuation;)Ljava/lang/Object;
    //   196: astore_1
    //   197: aload_1
    //   198: aload #7
    //   200: if_acmpne -> 206
    //   203: aload #7
    //   205: areturn
    //   206: aload_1
    //   207: areturn
    //   208: astore_3
    //   209: aload_0
    //   210: astore_1
    //   211: aload_1
    //   212: getfield corruptionHandler : Landroidx/datastore/core/CorruptionHandler;
    //   215: astore #5
    //   217: aload #4
    //   219: aload_1
    //   220: putfield L$0 : Ljava/lang/Object;
    //   223: aload #4
    //   225: aload_3
    //   226: putfield L$1 : Ljava/lang/Object;
    //   229: aload #4
    //   231: iconst_2
    //   232: putfield label : I
    //   235: aload #5
    //   237: aload_3
    //   238: aload #4
    //   240: invokeinterface handleCorruption : (Landroidx/datastore/core/CorruptionException;Lkotlin/coroutines/Continuation;)Ljava/lang/Object;
    //   245: astore #5
    //   247: aload #5
    //   249: aload #7
    //   251: if_acmpne -> 257
    //   254: aload #7
    //   256: areturn
    //   257: aload_1
    //   258: astore #6
    //   260: aload_3
    //   261: astore_1
    //   262: aload #4
    //   264: aload_1
    //   265: putfield L$0 : Ljava/lang/Object;
    //   268: aload #4
    //   270: aload #5
    //   272: putfield L$1 : Ljava/lang/Object;
    //   275: aload #4
    //   277: iconst_3
    //   278: putfield label : I
    //   281: aload #6
    //   283: aload #5
    //   285: aload #4
    //   287: invokevirtual writeData$datastore_core : (Ljava/lang/Object;Lkotlin/coroutines/Continuation;)Ljava/lang/Object;
    //   290: astore_3
    //   291: aload_3
    //   292: aload #7
    //   294: if_acmpne -> 300
    //   297: aload #7
    //   299: areturn
    //   300: aload #5
    //   302: areturn
    //   303: astore_3
    //   304: aload_1
    //   305: aload_3
    //   306: invokestatic addSuppressed : (Ljava/lang/Throwable;Ljava/lang/Throwable;)V
    //   309: aload_1
    //   310: athrow
    // Exception table:
    //   from	to	target	type
    //   103	108	110	java/io/IOException
    //   161	166	169	androidx/datastore/core/CorruptionException
    //   178	197	208	androidx/datastore/core/CorruptionException
    //   262	291	303	java/io/IOException
  }
  
  private final Object transformAndWrite(Function2<? super T, ? super Continuation<? super T>, ? extends Object> paramFunction2, CoroutineContext paramCoroutineContext, Continuation<? super T> paramContinuation) {
    // Byte code:
    //   0: aload_3
    //   1: instanceof androidx/datastore/core/SingleProcessDataStore$transformAndWrite$1
    //   4: ifeq -> 46
    //   7: aload_3
    //   8: checkcast androidx/datastore/core/SingleProcessDataStore$transformAndWrite$1
    //   11: astore #5
    //   13: aload #5
    //   15: getfield label : I
    //   18: istore #4
    //   20: iload #4
    //   22: ldc_w -2147483648
    //   25: iand
    //   26: ifeq -> 46
    //   29: aload #5
    //   31: iload #4
    //   33: ldc_w -2147483648
    //   36: iadd
    //   37: putfield label : I
    //   40: aload #5
    //   42: astore_3
    //   43: goto -> 56
    //   46: new androidx/datastore/core/SingleProcessDataStore$transformAndWrite$1
    //   49: dup
    //   50: aload_0
    //   51: aload_3
    //   52: invokespecial <init> : (Landroidx/datastore/core/SingleProcessDataStore;Lkotlin/coroutines/Continuation;)V
    //   55: astore_3
    //   56: aload_3
    //   57: getfield result : Ljava/lang/Object;
    //   60: astore #5
    //   62: invokestatic getCOROUTINE_SUSPENDED : ()Ljava/lang/Object;
    //   65: astore #8
    //   67: aload_3
    //   68: getfield label : I
    //   71: istore #4
    //   73: iload #4
    //   75: ifeq -> 156
    //   78: iload #4
    //   80: iconst_1
    //   81: if_icmpeq -> 122
    //   84: iload #4
    //   86: iconst_2
    //   87: if_icmpne -> 111
    //   90: aload_3
    //   91: getfield L$1 : Ljava/lang/Object;
    //   94: astore_2
    //   95: aload_3
    //   96: getfield L$0 : Ljava/lang/Object;
    //   99: checkcast androidx/datastore/core/SingleProcessDataStore
    //   102: astore_1
    //   103: aload #5
    //   105: invokestatic throwOnFailure : (Ljava/lang/Object;)V
    //   108: goto -> 300
    //   111: new java/lang/IllegalStateException
    //   114: dup
    //   115: ldc_w 'call to 'resume' before 'invoke' with coroutine'
    //   118: invokespecial <init> : (Ljava/lang/String;)V
    //   121: athrow
    //   122: aload_3
    //   123: getfield L$2 : Ljava/lang/Object;
    //   126: astore #6
    //   128: aload_3
    //   129: getfield L$1 : Ljava/lang/Object;
    //   132: checkcast androidx/datastore/core/Data
    //   135: astore #7
    //   137: aload_3
    //   138: getfield L$0 : Ljava/lang/Object;
    //   141: checkcast androidx/datastore/core/SingleProcessDataStore
    //   144: astore_1
    //   145: aload #5
    //   147: invokestatic throwOnFailure : (Ljava/lang/Object;)V
    //   150: aload #5
    //   152: astore_2
    //   153: goto -> 249
    //   156: aload #5
    //   158: invokestatic throwOnFailure : (Ljava/lang/Object;)V
    //   161: aload_0
    //   162: getfield downstreamFlow : Lkotlinx/coroutines/flow/MutableStateFlow;
    //   165: invokeinterface getValue : ()Ljava/lang/Object;
    //   170: checkcast androidx/datastore/core/Data
    //   173: astore #5
    //   175: aload #5
    //   177: invokevirtual checkHashCode : ()V
    //   180: aload #5
    //   182: invokevirtual getValue : ()Ljava/lang/Object;
    //   185: astore #6
    //   187: new androidx/datastore/core/SingleProcessDataStore$transformAndWrite$newData$1
    //   190: dup
    //   191: aload_1
    //   192: aload #6
    //   194: aconst_null
    //   195: invokespecial <init> : (Lkotlin/jvm/functions/Function2;Ljava/lang/Object;Lkotlin/coroutines/Continuation;)V
    //   198: astore_1
    //   199: aload_3
    //   200: aload_0
    //   201: putfield L$0 : Ljava/lang/Object;
    //   204: aload_3
    //   205: aload #5
    //   207: putfield L$1 : Ljava/lang/Object;
    //   210: aload_3
    //   211: aload #6
    //   213: putfield L$2 : Ljava/lang/Object;
    //   216: aload_3
    //   217: iconst_1
    //   218: putfield label : I
    //   221: aload_2
    //   222: aload_1
    //   223: aload_3
    //   224: invokestatic withContext : (Lkotlin/coroutines/CoroutineContext;Lkotlin/jvm/functions/Function2;Lkotlin/coroutines/Continuation;)Ljava/lang/Object;
    //   227: astore_2
    //   228: aload_2
    //   229: aload #8
    //   231: if_acmpne -> 237
    //   234: aload #8
    //   236: areturn
    //   237: aload #5
    //   239: astore_1
    //   240: aload_0
    //   241: astore #5
    //   243: aload_1
    //   244: astore #7
    //   246: aload #5
    //   248: astore_1
    //   249: aload #7
    //   251: invokevirtual checkHashCode : ()V
    //   254: aload #6
    //   256: aload_2
    //   257: invokestatic areEqual : (Ljava/lang/Object;Ljava/lang/Object;)Z
    //   260: ifeq -> 266
    //   263: aload #6
    //   265: areturn
    //   266: aload_3
    //   267: aload_1
    //   268: putfield L$0 : Ljava/lang/Object;
    //   271: aload_3
    //   272: aload_2
    //   273: putfield L$1 : Ljava/lang/Object;
    //   276: aload_3
    //   277: aconst_null
    //   278: putfield L$2 : Ljava/lang/Object;
    //   281: aload_3
    //   282: iconst_2
    //   283: putfield label : I
    //   286: aload_1
    //   287: aload_2
    //   288: aload_3
    //   289: invokevirtual writeData$datastore_core : (Ljava/lang/Object;Lkotlin/coroutines/Continuation;)Ljava/lang/Object;
    //   292: aload #8
    //   294: if_acmpne -> 300
    //   297: aload #8
    //   299: areturn
    //   300: aload_1
    //   301: getfield downstreamFlow : Lkotlinx/coroutines/flow/MutableStateFlow;
    //   304: astore_1
    //   305: aload_2
    //   306: ifnull -> 318
    //   309: aload_2
    //   310: invokevirtual hashCode : ()I
    //   313: istore #4
    //   315: goto -> 321
    //   318: iconst_0
    //   319: istore #4
    //   321: aload_1
    //   322: new androidx/datastore/core/Data
    //   325: dup
    //   326: aload_2
    //   327: iload #4
    //   329: invokespecial <init> : (Ljava/lang/Object;I)V
    //   332: invokeinterface setValue : (Ljava/lang/Object;)V
    //   337: aload_2
    //   338: areturn
  }
  
  public Flow<T> getData() {
    return this.data;
  }
  
  public Object updateData(Function2<? super T, ? super Continuation<? super T>, ? extends Object> paramFunction2, Continuation<? super T> paramContinuation) {
    CompletableDeferred<T> completableDeferred = CompletableDeferredKt.CompletableDeferred$default(null, 1, null);
    Message.Update<T> update = new Message.Update<T>(paramFunction2, completableDeferred, (State<T>)this.downstreamFlow.getValue(), paramContinuation.getContext());
    this.actor.offer(update);
    return completableDeferred.await(paramContinuation);
  }
  
  public final Object writeData$datastore_core(T paramT, Continuation<? super Unit> paramContinuation) {
    // Byte code:
    //   0: aload_2
    //   1: instanceof androidx/datastore/core/SingleProcessDataStore$writeData$1
    //   4: ifeq -> 40
    //   7: aload_2
    //   8: checkcast androidx/datastore/core/SingleProcessDataStore$writeData$1
    //   11: astore #6
    //   13: aload #6
    //   15: getfield label : I
    //   18: istore_3
    //   19: iload_3
    //   20: ldc_w -2147483648
    //   23: iand
    //   24: ifeq -> 40
    //   27: aload #6
    //   29: iload_3
    //   30: ldc_w -2147483648
    //   33: iadd
    //   34: putfield label : I
    //   37: goto -> 51
    //   40: new androidx/datastore/core/SingleProcessDataStore$writeData$1
    //   43: dup
    //   44: aload_0
    //   45: aload_2
    //   46: invokespecial <init> : (Landroidx/datastore/core/SingleProcessDataStore;Lkotlin/coroutines/Continuation;)V
    //   49: astore #6
    //   51: aload #6
    //   53: getfield result : Ljava/lang/Object;
    //   56: astore #11
    //   58: invokestatic getCOROUTINE_SUSPENDED : ()Ljava/lang/Object;
    //   61: astore #7
    //   63: aload #6
    //   65: getfield label : I
    //   68: istore_3
    //   69: iload_3
    //   70: ifeq -> 167
    //   73: iload_3
    //   74: iconst_1
    //   75: if_icmpne -> 156
    //   78: aload #6
    //   80: getfield L$4 : Ljava/lang/Object;
    //   83: checkcast java/io/FileOutputStream
    //   86: astore #10
    //   88: aload #6
    //   90: getfield L$3 : Ljava/lang/Object;
    //   93: checkcast java/lang/Throwable
    //   96: astore #8
    //   98: aload #6
    //   100: getfield L$2 : Ljava/lang/Object;
    //   103: checkcast java/io/Closeable
    //   106: astore #9
    //   108: aload #6
    //   110: getfield L$1 : Ljava/lang/Object;
    //   113: checkcast java/io/File
    //   116: astore_1
    //   117: aload #6
    //   119: getfield L$0 : Ljava/lang/Object;
    //   122: checkcast androidx/datastore/core/SingleProcessDataStore
    //   125: astore #7
    //   127: aload #9
    //   129: astore #5
    //   131: aload_1
    //   132: astore_2
    //   133: aload #11
    //   135: invokestatic throwOnFailure : (Ljava/lang/Object;)V
    //   138: aload #9
    //   140: astore #6
    //   142: aload #10
    //   144: astore #9
    //   146: goto -> 303
    //   149: astore #6
    //   151: aload_2
    //   152: astore_1
    //   153: goto -> 424
    //   156: new java/lang/IllegalStateException
    //   159: dup
    //   160: ldc_w 'call to 'resume' before 'invoke' with coroutine'
    //   163: invokespecial <init> : (Ljava/lang/String;)V
    //   166: athrow
    //   167: aload #11
    //   169: invokestatic throwOnFailure : (Ljava/lang/Object;)V
    //   172: aload_0
    //   173: aload_0
    //   174: invokespecial getFile : ()Ljava/io/File;
    //   177: invokespecial createParentDirectories : (Ljava/io/File;)V
    //   180: new java/io/File
    //   183: dup
    //   184: aload_0
    //   185: invokespecial getFile : ()Ljava/io/File;
    //   188: invokevirtual getAbsolutePath : ()Ljava/lang/String;
    //   191: aload_0
    //   192: getfield SCRATCH_SUFFIX : Ljava/lang/String;
    //   195: invokestatic stringPlus : (Ljava/lang/String;Ljava/lang/Object;)Ljava/lang/String;
    //   198: invokespecial <init> : (Ljava/lang/String;)V
    //   201: astore #5
    //   203: new java/io/FileOutputStream
    //   206: dup
    //   207: aload #5
    //   209: invokespecial <init> : (Ljava/io/File;)V
    //   212: astore_2
    //   213: aload_0
    //   214: getfield serializer : Landroidx/datastore/core/Serializer;
    //   217: astore #8
    //   219: new androidx/datastore/core/SingleProcessDataStore$UncloseableOutputStream
    //   222: dup
    //   223: aload_2
    //   224: invokespecial <init> : (Ljava/io/FileOutputStream;)V
    //   227: astore #9
    //   229: aload #6
    //   231: aload_0
    //   232: putfield L$0 : Ljava/lang/Object;
    //   235: aload #6
    //   237: aload #5
    //   239: putfield L$1 : Ljava/lang/Object;
    //   242: aload #6
    //   244: aload_2
    //   245: putfield L$2 : Ljava/lang/Object;
    //   248: aload #6
    //   250: aconst_null
    //   251: putfield L$3 : Ljava/lang/Object;
    //   254: aload #6
    //   256: aload_2
    //   257: putfield L$4 : Ljava/lang/Object;
    //   260: aload #6
    //   262: iconst_1
    //   263: putfield label : I
    //   266: aload #8
    //   268: aload_1
    //   269: aload #9
    //   271: aload #6
    //   273: invokeinterface writeTo : (Ljava/lang/Object;Ljava/io/OutputStream;Lkotlin/coroutines/Continuation;)Ljava/lang/Object;
    //   278: astore_1
    //   279: aload_1
    //   280: aload #7
    //   282: if_acmpne -> 288
    //   285: aload #7
    //   287: areturn
    //   288: aload_0
    //   289: astore #7
    //   291: aload #5
    //   293: astore_1
    //   294: aload_2
    //   295: astore #9
    //   297: aconst_null
    //   298: astore #8
    //   300: aload_2
    //   301: astore #6
    //   303: aload #6
    //   305: astore #5
    //   307: aload_1
    //   308: astore_2
    //   309: aload #9
    //   311: invokevirtual getFD : ()Ljava/io/FileDescriptor;
    //   314: invokevirtual sync : ()V
    //   317: aload #6
    //   319: astore #5
    //   321: aload_1
    //   322: astore_2
    //   323: getstatic kotlin/Unit.INSTANCE : Lkotlin/Unit;
    //   326: astore #9
    //   328: aload_1
    //   329: astore_2
    //   330: aload #6
    //   332: aload #8
    //   334: invokestatic closeFinally : (Ljava/io/Closeable;Ljava/lang/Throwable;)V
    //   337: aload_1
    //   338: astore_2
    //   339: aload_1
    //   340: aload #7
    //   342: invokespecial getFile : ()Ljava/io/File;
    //   345: invokevirtual renameTo : (Ljava/io/File;)Z
    //   348: istore #4
    //   350: iload #4
    //   352: ifeq -> 359
    //   355: getstatic kotlin/Unit.INSTANCE : Lkotlin/Unit;
    //   358: areturn
    //   359: aload_1
    //   360: astore_2
    //   361: new java/lang/StringBuilder
    //   364: dup
    //   365: invokespecial <init> : ()V
    //   368: astore #5
    //   370: aload_1
    //   371: astore_2
    //   372: aload #5
    //   374: ldc_w 'Unable to rename '
    //   377: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   380: pop
    //   381: aload_1
    //   382: astore_2
    //   383: aload #5
    //   385: aload_1
    //   386: invokevirtual append : (Ljava/lang/Object;)Ljava/lang/StringBuilder;
    //   389: pop
    //   390: aload_1
    //   391: astore_2
    //   392: aload #5
    //   394: ldc_w '.This likely means that there are multiple instances of DataStore for this file. Ensure that you are only creating a single instance of datastore for this file.'
    //   397: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   400: pop
    //   401: aload_1
    //   402: astore_2
    //   403: new java/io/IOException
    //   406: dup
    //   407: aload #5
    //   409: invokevirtual toString : ()Ljava/lang/String;
    //   412: invokespecial <init> : (Ljava/lang/String;)V
    //   415: athrow
    //   416: astore #6
    //   418: aload #5
    //   420: astore_1
    //   421: aload_2
    //   422: astore #5
    //   424: aload #6
    //   426: athrow
    //   427: astore #7
    //   429: aload_1
    //   430: astore_2
    //   431: aload #5
    //   433: aload #6
    //   435: invokestatic closeFinally : (Ljava/io/Closeable;Ljava/lang/Throwable;)V
    //   438: aload_1
    //   439: astore_2
    //   440: aload #7
    //   442: athrow
    //   443: astore_1
    //   444: goto -> 451
    //   447: astore_1
    //   448: aload #5
    //   450: astore_2
    //   451: aload_2
    //   452: invokevirtual exists : ()Z
    //   455: ifeq -> 463
    //   458: aload_2
    //   459: invokevirtual delete : ()Z
    //   462: pop
    //   463: aload_1
    //   464: athrow
    // Exception table:
    //   from	to	target	type
    //   133	138	149	finally
    //   203	213	447	java/io/IOException
    //   213	279	416	finally
    //   309	317	149	finally
    //   323	328	149	finally
    //   330	337	443	java/io/IOException
    //   339	350	443	java/io/IOException
    //   361	370	443	java/io/IOException
    //   372	381	443	java/io/IOException
    //   383	390	443	java/io/IOException
    //   392	401	443	java/io/IOException
    //   403	416	443	java/io/IOException
    //   424	427	427	finally
    //   431	438	443	java/io/IOException
    //   440	443	443	java/io/IOException
  }
  
  @Metadata(d1 = {"\000\030\n\002\030\002\n\002\020\000\n\002\b\002\n\002\020#\n\002\020\016\n\002\b\006\b\003\030\0002\0020\001B\007\b\002¢\006\002\020\002R\034\020\003\032\b\022\004\022\0020\0050\0048\000X\004¢\006\b\n\000\032\004\b\006\020\007R\024\020\b\032\0020\001X\004¢\006\b\n\000\032\004\b\t\020\n¨\006\013"}, d2 = {"Landroidx/datastore/core/SingleProcessDataStore$Companion;", "", "()V", "activeFiles", "", "", "getActiveFiles$datastore_core", "()Ljava/util/Set;", "activeFilesLock", "getActiveFilesLock$datastore_core", "()Ljava/lang/Object;", "datastore-core"}, k = 1, mv = {1, 5, 1}, xi = 48)
  public static final class Companion {
    private Companion() {}
    
    public final Set<String> getActiveFiles$datastore_core() {
      return SingleProcessDataStore.activeFiles;
    }
    
    public final Object getActiveFilesLock$datastore_core() {
      return SingleProcessDataStore.activeFilesLock;
    }
  }
  
  @Metadata(d1 = {"\000 \n\002\030\002\n\000\n\002\020\000\n\002\b\002\n\002\030\002\n\002\b\004\n\002\030\002\n\002\030\002\n\000\b2\030\000*\004\b\001\020\0012\0020\002:\002\b\tB\007\b\004¢\006\002\020\003R\032\020\004\032\n\022\004\022\0028\001\030\0010\005X¦\004¢\006\006\032\004\b\006\020\007\001\002\n\013¨\006\f"}, d2 = {"Landroidx/datastore/core/SingleProcessDataStore$Message;", "T", "", "()V", "lastState", "Landroidx/datastore/core/State;", "getLastState", "()Landroidx/datastore/core/State;", "Read", "Update", "Landroidx/datastore/core/SingleProcessDataStore$Message$Read;", "Landroidx/datastore/core/SingleProcessDataStore$Message$Update;", "datastore-core"}, k = 1, mv = {1, 5, 1}, xi = 48)
  private static abstract class Message<T> {
    private Message() {}
    
    public abstract State<T> getLastState();
    
    @Metadata(d1 = {"\000\024\n\002\030\002\n\000\n\002\030\002\n\000\n\002\030\002\n\002\b\004\030\000*\004\b\002\020\0012\b\022\004\022\002H\0010\002B\025\022\016\020\003\032\n\022\004\022\0028\002\030\0010\004¢\006\002\020\005R\034\020\003\032\n\022\004\022\0028\002\030\0010\004X\004¢\006\b\n\000\032\004\b\006\020\007¨\006\b"}, d2 = {"Landroidx/datastore/core/SingleProcessDataStore$Message$Read;", "T", "Landroidx/datastore/core/SingleProcessDataStore$Message;", "lastState", "Landroidx/datastore/core/State;", "(Landroidx/datastore/core/State;)V", "getLastState", "()Landroidx/datastore/core/State;", "datastore-core"}, k = 1, mv = {1, 5, 1}, xi = 48)
    public static final class Read<T> extends Message<T> {
      private final State<T> lastState;
      
      public Read(State<T> param2State) {
        super(null);
        this.lastState = param2State;
      }
      
      public State<T> getLastState() {
        return this.lastState;
      }
    }
    
    @Metadata(d1 = {"\0002\n\002\030\002\n\000\n\002\030\002\n\002\030\002\n\002\030\002\n\002\020\000\n\002\b\004\n\002\030\002\n\002\b\004\n\002\030\002\n\002\b\004\n\002\030\002\n\002\b\007\030\000*\004\b\002\020\0012\b\022\004\022\0028\0020\002BT\022\"\020\006\032\036\b\001\022\004\022\0028\002\022\n\022\b\022\004\022\0028\0020\004\022\006\022\004\030\0010\0050\003\022\f\020\013\032\b\022\004\022\0028\0020\n\022\016\020\020\032\n\022\004\022\0028\002\030\0010\017\022\006\020\025\032\0020\024ø\001\000¢\006\004\b\031\020\032R6\020\006\032\036\b\001\022\004\022\0028\002\022\n\022\b\022\004\022\0028\0020\004\022\006\022\004\030\0010\0050\0038\006ø\001\000¢\006\f\n\004\b\006\020\007\032\004\b\b\020\tR\035\020\013\032\b\022\004\022\0028\0020\n8\006¢\006\f\n\004\b\013\020\f\032\004\b\r\020\016R\"\020\020\032\n\022\004\022\0028\002\030\0010\0178\026X\004¢\006\f\n\004\b\020\020\021\032\004\b\022\020\023R\027\020\025\032\0020\0248\006¢\006\f\n\004\b\025\020\026\032\004\b\027\020\030\002\004\n\002\b\031¨\006\033"}, d2 = {"Landroidx/datastore/core/SingleProcessDataStore$Message$Update;", "T", "Landroidx/datastore/core/SingleProcessDataStore$Message;", "Lkotlin/Function2;", "Lkotlin/coroutines/Continuation;", "", "transform", "Lkotlin/jvm/functions/Function2;", "getTransform", "()Lkotlin/jvm/functions/Function2;", "Lkotlinx/coroutines/CompletableDeferred;", "ack", "Lkotlinx/coroutines/CompletableDeferred;", "getAck", "()Lkotlinx/coroutines/CompletableDeferred;", "Landroidx/datastore/core/State;", "lastState", "Landroidx/datastore/core/State;", "getLastState", "()Landroidx/datastore/core/State;", "Lkotlin/coroutines/CoroutineContext;", "callerContext", "Lkotlin/coroutines/CoroutineContext;", "getCallerContext", "()Lkotlin/coroutines/CoroutineContext;", "<init>", "(Lkotlin/jvm/functions/Function2;Lkotlinx/coroutines/CompletableDeferred;Landroidx/datastore/core/State;Lkotlin/coroutines/CoroutineContext;)V", "datastore-core"}, k = 1, mv = {1, 5, 1})
    public static final class Update<T> extends Message<T> {
      private final CompletableDeferred<T> ack;
      
      private final CoroutineContext callerContext;
      
      private final State<T> lastState;
      
      private final Function2<T, Continuation<? super T>, Object> transform;
      
      public Update(Function2<? super T, ? super Continuation<? super T>, ? extends Object> param2Function2, CompletableDeferred<T> param2CompletableDeferred, State<T> param2State, CoroutineContext param2CoroutineContext) {
        super(null);
        this.transform = (Function2)param2Function2;
        this.ack = param2CompletableDeferred;
        this.lastState = param2State;
        this.callerContext = param2CoroutineContext;
      }
      
      public final CompletableDeferred<T> getAck() {
        return this.ack;
      }
      
      public final CoroutineContext getCallerContext() {
        return this.callerContext;
      }
      
      public State<T> getLastState() {
        return this.lastState;
      }
      
      public final Function2<T, Continuation<? super T>, Object> getTransform() {
        return this.transform;
      }
    }
  }
  
  @Metadata(d1 = {"\000\024\n\002\030\002\n\000\n\002\030\002\n\000\n\002\030\002\n\002\b\004\030\000*\004\b\002\020\0012\b\022\004\022\002H\0010\002B\025\022\016\020\003\032\n\022\004\022\0028\002\030\0010\004¢\006\002\020\005R\034\020\003\032\n\022\004\022\0028\002\030\0010\004X\004¢\006\b\n\000\032\004\b\006\020\007¨\006\b"}, d2 = {"Landroidx/datastore/core/SingleProcessDataStore$Message$Read;", "T", "Landroidx/datastore/core/SingleProcessDataStore$Message;", "lastState", "Landroidx/datastore/core/State;", "(Landroidx/datastore/core/State;)V", "getLastState", "()Landroidx/datastore/core/State;", "datastore-core"}, k = 1, mv = {1, 5, 1}, xi = 48)
  public static final class Read<T> extends Message<T> {
    private final State<T> lastState;
    
    public Read(State<T> param1State) {
      super(null);
      this.lastState = param1State;
    }
    
    public State<T> getLastState() {
      return this.lastState;
    }
  }
  
  @Metadata(d1 = {"\0002\n\002\030\002\n\000\n\002\030\002\n\002\030\002\n\002\030\002\n\002\020\000\n\002\b\004\n\002\030\002\n\002\b\004\n\002\030\002\n\002\b\004\n\002\030\002\n\002\b\007\030\000*\004\b\002\020\0012\b\022\004\022\0028\0020\002BT\022\"\020\006\032\036\b\001\022\004\022\0028\002\022\n\022\b\022\004\022\0028\0020\004\022\006\022\004\030\0010\0050\003\022\f\020\013\032\b\022\004\022\0028\0020\n\022\016\020\020\032\n\022\004\022\0028\002\030\0010\017\022\006\020\025\032\0020\024ø\001\000¢\006\004\b\031\020\032R6\020\006\032\036\b\001\022\004\022\0028\002\022\n\022\b\022\004\022\0028\0020\004\022\006\022\004\030\0010\0050\0038\006ø\001\000¢\006\f\n\004\b\006\020\007\032\004\b\b\020\tR\035\020\013\032\b\022\004\022\0028\0020\n8\006¢\006\f\n\004\b\013\020\f\032\004\b\r\020\016R\"\020\020\032\n\022\004\022\0028\002\030\0010\0178\026X\004¢\006\f\n\004\b\020\020\021\032\004\b\022\020\023R\027\020\025\032\0020\0248\006¢\006\f\n\004\b\025\020\026\032\004\b\027\020\030\002\004\n\002\b\031¨\006\033"}, d2 = {"Landroidx/datastore/core/SingleProcessDataStore$Message$Update;", "T", "Landroidx/datastore/core/SingleProcessDataStore$Message;", "Lkotlin/Function2;", "Lkotlin/coroutines/Continuation;", "", "transform", "Lkotlin/jvm/functions/Function2;", "getTransform", "()Lkotlin/jvm/functions/Function2;", "Lkotlinx/coroutines/CompletableDeferred;", "ack", "Lkotlinx/coroutines/CompletableDeferred;", "getAck", "()Lkotlinx/coroutines/CompletableDeferred;", "Landroidx/datastore/core/State;", "lastState", "Landroidx/datastore/core/State;", "getLastState", "()Landroidx/datastore/core/State;", "Lkotlin/coroutines/CoroutineContext;", "callerContext", "Lkotlin/coroutines/CoroutineContext;", "getCallerContext", "()Lkotlin/coroutines/CoroutineContext;", "<init>", "(Lkotlin/jvm/functions/Function2;Lkotlinx/coroutines/CompletableDeferred;Landroidx/datastore/core/State;Lkotlin/coroutines/CoroutineContext;)V", "datastore-core"}, k = 1, mv = {1, 5, 1})
  public static final class Update<T> extends Message<T> {
    private final CompletableDeferred<T> ack;
    
    private final CoroutineContext callerContext;
    
    private final State<T> lastState;
    
    private final Function2<T, Continuation<? super T>, Object> transform;
    
    public Update(Function2<? super T, ? super Continuation<? super T>, ? extends Object> param1Function2, CompletableDeferred<T> param1CompletableDeferred, State<T> param1State, CoroutineContext param1CoroutineContext) {
      super(null);
      this.transform = (Function2)param1Function2;
      this.ack = param1CompletableDeferred;
      this.lastState = param1State;
      this.callerContext = param1CoroutineContext;
    }
    
    public final CompletableDeferred<T> getAck() {
      return this.ack;
    }
    
    public final CoroutineContext getCallerContext() {
      return this.callerContext;
    }
    
    public State<T> getLastState() {
      return this.lastState;
    }
    
    public final Function2<T, Continuation<? super T>, Object> getTransform() {
      return this.transform;
    }
  }
  
  @Metadata(d1 = {"\000*\n\002\030\002\n\002\030\002\n\000\n\002\030\002\n\002\b\004\n\002\020\002\n\002\b\003\n\002\020\022\n\002\b\002\n\002\020\b\n\002\b\002\b\002\030\0002\0020\001B\r\022\006\020\002\032\0020\003¢\006\002\020\004J\b\020\007\032\0020\bH\026J\b\020\t\032\0020\bH\026J\020\020\n\032\0020\b2\006\020\013\032\0020\fH\026J \020\n\032\0020\b2\006\020\r\032\0020\f2\006\020\016\032\0020\0172\006\020\020\032\0020\017H\026J\020\020\n\032\0020\b2\006\020\013\032\0020\017H\026R\021\020\002\032\0020\003¢\006\b\n\000\032\004\b\005\020\006¨\006\021"}, d2 = {"Landroidx/datastore/core/SingleProcessDataStore$UncloseableOutputStream;", "Ljava/io/OutputStream;", "fileOutputStream", "Ljava/io/FileOutputStream;", "(Ljava/io/FileOutputStream;)V", "getFileOutputStream", "()Ljava/io/FileOutputStream;", "close", "", "flush", "write", "b", "", "bytes", "off", "", "len", "datastore-core"}, k = 1, mv = {1, 5, 1}, xi = 48)
  private static final class UncloseableOutputStream extends OutputStream {
    private final FileOutputStream fileOutputStream;
    
    public UncloseableOutputStream(FileOutputStream param1FileOutputStream) {
      this.fileOutputStream = param1FileOutputStream;
    }
    
    public void close() {}
    
    public void flush() {
      this.fileOutputStream.flush();
    }
    
    public final FileOutputStream getFileOutputStream() {
      return this.fileOutputStream;
    }
    
    public void write(int param1Int) {
      this.fileOutputStream.write(param1Int);
    }
    
    public void write(byte[] param1ArrayOfbyte) {
      Intrinsics.checkNotNullParameter(param1ArrayOfbyte, "b");
      this.fileOutputStream.write(param1ArrayOfbyte);
    }
    
    public void write(byte[] param1ArrayOfbyte, int param1Int1, int param1Int2) {
      Intrinsics.checkNotNullParameter(param1ArrayOfbyte, "bytes");
      this.fileOutputStream.write(param1ArrayOfbyte, param1Int1, param1Int2);
    }
  }
  
  @Metadata(d1 = {"\000\016\n\000\n\002\020\003\n\000\n\002\020\002\n\000\020\004\032\0020\003\"\004\b\000\020\0002\b\020\002\032\004\030\0010\001H\n"}, d2 = {"T", "", "it", "", "<anonymous>"}, k = 3, mv = {1, 5, 1})
  static final class SingleProcessDataStore$actor$1 extends Lambda implements Function1<Throwable, Unit> {
    SingleProcessDataStore$actor$1() {
      super(1);
    }
    
    public final void invoke(Throwable param1Throwable) {
      if (param1Throwable != null)
        SingleProcessDataStore.this.downstreamFlow.setValue(new Final(param1Throwable)); 
      null = SingleProcessDataStore.Companion;
      Object object = null.getActiveFilesLock$datastore_core();
      synchronized (SingleProcessDataStore.this) {
        null.getActiveFiles$datastore_core().remove(null.getFile().getAbsolutePath());
        Unit unit = Unit.INSTANCE;
        /* monitor exit ClassFileLocalVariableReferenceExpression{type=ObjectType{java/lang/Object}, name=null} */
        return;
      } 
    }
  }
  
  @Metadata(d1 = {"\000\024\n\000\n\002\030\002\n\000\n\002\020\003\n\000\n\002\020\002\n\000\020\006\032\0020\005\"\004\b\000\020\0002\f\020\002\032\b\022\004\022\0028\0000\0012\b\020\004\032\004\030\0010\003H\n"}, d2 = {"T", "Landroidx/datastore/core/SingleProcessDataStore$Message;", "msg", "", "ex", "", "<anonymous>"}, k = 3, mv = {1, 5, 1})
  static final class SingleProcessDataStore$actor$2 extends Lambda implements Function2<Message<T>, Throwable, Unit> {
    public static final SingleProcessDataStore$actor$2 INSTANCE = new SingleProcessDataStore$actor$2();
    
    SingleProcessDataStore$actor$2() {
      super(2);
    }
    
    public final void invoke(SingleProcessDataStore.Message<T> param1Message, Throwable param1Throwable) {
      Intrinsics.checkNotNullParameter(param1Message, "msg");
      if (param1Message instanceof SingleProcessDataStore.Message.Update) {
        CompletableDeferred completableDeferred = ((SingleProcessDataStore.Message.Update)param1Message).getAck();
        Throwable throwable = param1Throwable;
        if (param1Throwable == null)
          throwable = new CancellationException("DataStore scope was cancelled before updateData could complete"); 
        completableDeferred.completeExceptionally(throwable);
      } 
    }
  }
  
  @Metadata(d1 = {"\000\016\n\000\n\002\030\002\n\000\n\002\020\002\n\000\020\004\032\0020\003\"\004\b\000\020\0002\f\020\002\032\b\022\004\022\0028\0000\001H@"}, d2 = {"T", "Landroidx/datastore/core/SingleProcessDataStore$Message;", "msg", "", "<anonymous>"}, k = 3, mv = {1, 5, 1})
  @DebugMetadata(c = "androidx.datastore.core.SingleProcessDataStore$actor$3", f = "SingleProcessDataStore.kt", l = {239, 242}, m = "invokeSuspend")
  static final class SingleProcessDataStore$actor$3 extends SuspendLambda implements Function2<Message<T>, Continuation<? super Unit>, Object> {
    int label;
    
    SingleProcessDataStore$actor$3(Continuation<? super SingleProcessDataStore$actor$3> param1Continuation) {
      super(2, param1Continuation);
    }
    
    public final Continuation<Unit> create(Object param1Object, Continuation<?> param1Continuation) {
      SingleProcessDataStore$actor$3 singleProcessDataStore$actor$3 = new SingleProcessDataStore$actor$3((Continuation)param1Continuation);
      singleProcessDataStore$actor$3.L$0 = param1Object;
      return (Continuation<Unit>)singleProcessDataStore$actor$3;
    }
    
    public final Object invoke(SingleProcessDataStore.Message<T> param1Message, Continuation<? super Unit> param1Continuation) {
      return ((SingleProcessDataStore$actor$3)create(param1Message, param1Continuation)).invokeSuspend(Unit.INSTANCE);
    }
    
    public final Object invokeSuspend(Object param1Object) {
      Object object = IntrinsicsKt.getCOROUTINE_SUSPENDED();
      int i = this.label;
      if (i != 0) {
        if (i == 1 || i == 2) {
          ResultKt.throwOnFailure(param1Object);
          return Unit.INSTANCE;
        } 
        throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
      } 
      ResultKt.throwOnFailure(param1Object);
      param1Object = this.L$0;
      if (param1Object instanceof SingleProcessDataStore.Message.Read) {
        SingleProcessDataStore<T> singleProcessDataStore = SingleProcessDataStore.this;
        param1Object = param1Object;
        this.label = 1;
        if (singleProcessDataStore.handleRead((SingleProcessDataStore.Message.Read<T>)param1Object, (Continuation<? super Unit>)this) == object)
          return object; 
      } else if (param1Object instanceof SingleProcessDataStore.Message.Update) {
        SingleProcessDataStore<T> singleProcessDataStore = SingleProcessDataStore.this;
        param1Object = param1Object;
        this.label = 2;
        if (singleProcessDataStore.handleUpdate((SingleProcessDataStore.Message.Update<T>)param1Object, (Continuation<? super Unit>)this) == object)
          return object; 
      } 
      return Unit.INSTANCE;
    }
  }
  
  @Metadata(d1 = {"\000\f\n\000\n\002\030\002\n\002\020\002\n\000\020\003\032\0020\002\"\004\b\000\020\000*\b\022\004\022\0028\0000\001H@"}, d2 = {"T", "Lkotlinx/coroutines/flow/FlowCollector;", "", "<anonymous>"}, k = 3, mv = {1, 5, 1})
  @DebugMetadata(c = "androidx.datastore.core.SingleProcessDataStore$data$1", f = "SingleProcessDataStore.kt", l = {117}, m = "invokeSuspend")
  static final class SingleProcessDataStore$data$1 extends SuspendLambda implements Function2<FlowCollector<? super T>, Continuation<? super Unit>, Object> {
    int label;
    
    SingleProcessDataStore$data$1(Continuation<? super SingleProcessDataStore$data$1> param1Continuation) {
      super(2, param1Continuation);
    }
    
    public final Continuation<Unit> create(Object param1Object, Continuation<?> param1Continuation) {
      SingleProcessDataStore$data$1 singleProcessDataStore$data$1 = new SingleProcessDataStore$data$1((Continuation)param1Continuation);
      singleProcessDataStore$data$1.L$0 = param1Object;
      return (Continuation<Unit>)singleProcessDataStore$data$1;
    }
    
    public final Object invoke(FlowCollector<? super T> param1FlowCollector, Continuation<? super Unit> param1Continuation) {
      return ((SingleProcessDataStore$data$1)create(param1FlowCollector, param1Continuation)).invokeSuspend(Unit.INSTANCE);
    }
    
    public final Object invokeSuspend(Object param1Object) {
      Object object = IntrinsicsKt.getCOROUTINE_SUSPENDED();
      int i = this.label;
      if (i != 0) {
        if (i == 1) {
          ResultKt.throwOnFailure(param1Object);
        } else {
          throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
        } 
      } else {
        ResultKt.throwOnFailure(param1Object);
        param1Object = this.L$0;
        State<?> state = (State)SingleProcessDataStore.this.downstreamFlow.getValue();
        if (!(state instanceof Data))
          SingleProcessDataStore.this.actor.offer(new SingleProcessDataStore.Message.Read(state)); 
        SingleProcessDataStore$data$1$invokeSuspend$$inlined$map$1 singleProcessDataStore$data$1$invokeSuspend$$inlined$map$1 = new SingleProcessDataStore$data$1$invokeSuspend$$inlined$map$1(FlowKt.dropWhile((Flow)SingleProcessDataStore.this.downstreamFlow, new Function2<State<T>, Continuation<? super Boolean>, Object>((State)state, null) {
                int label;
                
                public final Continuation<Unit> create(Object param1Object, Continuation<?> param1Continuation) {
                  Function2<State<T>, Continuation<? super Boolean>, Object> function2 = new Function2<State<T>, Continuation<? super Boolean>, Object>(this.$currentDownStreamFlowState, (Continuation)param1Continuation);
                  function2.L$0 = param1Object;
                  return (Continuation)function2;
                }
                
                public final Object invoke(State<T> param1State, Continuation<? super Boolean> param1Continuation) {
                  return ((null)create(param1State, param1Continuation)).invokeSuspend(Unit.INSTANCE);
                }
                
                public final Object invokeSuspend(Object param1Object) {
                  IntrinsicsKt.getCOROUTINE_SUSPENDED();
                  if (this.label == 0) {
                    ResultKt.throwOnFailure(param1Object);
                    param1Object = this.L$0;
                    State<T> state = this.$currentDownStreamFlowState;
                    boolean bool = state instanceof Data;
                    boolean bool2 = false;
                    boolean bool1 = bool2;
                    if (!bool)
                      if (state instanceof Final) {
                        bool1 = bool2;
                      } else {
                        bool1 = bool2;
                        if (param1Object == state)
                          bool1 = true; 
                      }  
                    return Boxing.boxBoolean(bool1);
                  } 
                  throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
                }
              }));
        this.label = 1;
        if (FlowKt.emitAll((FlowCollector)param1Object, singleProcessDataStore$data$1$invokeSuspend$$inlined$map$1, (Continuation)this) == object)
          return object; 
      } 
      return Unit.INSTANCE;
    }
    
    @Metadata(d1 = {"\000\031\n\000\n\002\030\002\n\000\n\002\020\002\n\000\n\002\030\002\n\002\b\004*\001\000\b\n\030\0002\b\022\004\022\0028\0000\001J\037\020\002\032\0020\0032\f\020\004\032\b\022\004\022\0028\0000\005H@ø\001\000¢\006\002\020\006\002\004\n\002\b\031¨\006\007¸\006\t"}, d2 = {"kotlinx/coroutines/flow/internal/SafeCollector_commonKt$unsafeFlow$1", "Lkotlinx/coroutines/flow/Flow;", "collect", "", "collector", "Lkotlinx/coroutines/flow/FlowCollector;", "(Lkotlinx/coroutines/flow/FlowCollector;Lkotlin/coroutines/Continuation;)Ljava/lang/Object;", "kotlinx-coroutines-core", "kotlinx/coroutines/flow/FlowKt__EmittersKt$unsafeTransform$$inlined$unsafeFlow$1", "kotlinx/coroutines/flow/FlowKt__TransformKt$map$$inlined$unsafeTransform$1"}, k = 1, mv = {1, 5, 1}, xi = 48)
    public static final class SingleProcessDataStore$data$1$invokeSuspend$$inlined$map$1 implements Flow<T> {
      public SingleProcessDataStore$data$1$invokeSuspend$$inlined$map$1(Flow param1Flow) {}
      
      public Object collect(FlowCollector param1FlowCollector, Continuation param1Continuation) {
        Object object = this.$this_unsafeTransform$inlined.collect(new FlowCollector<State<T>>(param1FlowCollector) {
              public Object emit(Object param1Object, Continuation param1Continuation) {
                // Byte code:
                //   0: aload_2
                //   1: instanceof androidx/datastore/core/SingleProcessDataStore$data$1$invokeSuspend$$inlined$map$1$2$1
                //   4: ifeq -> 41
                //   7: aload_2
                //   8: checkcast androidx/datastore/core/SingleProcessDataStore$data$1$invokeSuspend$$inlined$map$1$2$1
                //   11: astore #4
                //   13: aload #4
                //   15: getfield label : I
                //   18: istore_3
                //   19: iload_3
                //   20: ldc -2147483648
                //   22: iand
                //   23: ifeq -> 41
                //   26: aload #4
                //   28: iload_3
                //   29: ldc -2147483648
                //   31: iadd
                //   32: putfield label : I
                //   35: aload #4
                //   37: astore_2
                //   38: goto -> 51
                //   41: new androidx/datastore/core/SingleProcessDataStore$data$1$invokeSuspend$$inlined$map$1$2$1
                //   44: dup
                //   45: aload_0
                //   46: aload_2
                //   47: invokespecial <init> : (Landroidx/datastore/core/SingleProcessDataStore$data$1$invokeSuspend$$inlined$map$1$2;Lkotlin/coroutines/Continuation;)V
                //   50: astore_2
                //   51: aload_2
                //   52: getfield result : Ljava/lang/Object;
                //   55: astore #5
                //   57: invokestatic getCOROUTINE_SUSPENDED : ()Ljava/lang/Object;
                //   60: astore #4
                //   62: aload_2
                //   63: getfield label : I
                //   66: istore_3
                //   67: iload_3
                //   68: ifeq -> 94
                //   71: iload_3
                //   72: iconst_1
                //   73: if_icmpne -> 84
                //   76: aload #5
                //   78: invokestatic throwOnFailure : (Ljava/lang/Object;)V
                //   81: goto -> 161
                //   84: new java/lang/IllegalStateException
                //   87: dup
                //   88: ldc 'call to 'resume' before 'invoke' with coroutine'
                //   90: invokespecial <init> : (Ljava/lang/String;)V
                //   93: athrow
                //   94: aload #5
                //   96: invokestatic throwOnFailure : (Ljava/lang/Object;)V
                //   99: aload_0
                //   100: getfield $this_unsafeFlow$inlined : Lkotlinx/coroutines/flow/FlowCollector;
                //   103: astore #5
                //   105: aload_1
                //   106: checkcast androidx/datastore/core/State
                //   109: astore_1
                //   110: aload_1
                //   111: instanceof androidx/datastore/core/ReadException
                //   114: ifne -> 201
                //   117: aload_1
                //   118: instanceof androidx/datastore/core/Final
                //   121: ifne -> 193
                //   124: aload_1
                //   125: instanceof androidx/datastore/core/Data
                //   128: ifeq -> 165
                //   131: aload_1
                //   132: checkcast androidx/datastore/core/Data
                //   135: invokevirtual getValue : ()Ljava/lang/Object;
                //   138: astore_1
                //   139: aload_2
                //   140: iconst_1
                //   141: putfield label : I
                //   144: aload #5
                //   146: aload_1
                //   147: aload_2
                //   148: invokeinterface emit : (Ljava/lang/Object;Lkotlin/coroutines/Continuation;)Ljava/lang/Object;
                //   153: aload #4
                //   155: if_acmpne -> 161
                //   158: aload #4
                //   160: areturn
                //   161: getstatic kotlin/Unit.INSTANCE : Lkotlin/Unit;
                //   164: areturn
                //   165: aload_1
                //   166: instanceof androidx/datastore/core/UnInitialized
                //   169: ifeq -> 185
                //   172: new java/lang/IllegalStateException
                //   175: dup
                //   176: ldc 'This is a bug in DataStore. Please file a bug at: https://issuetracker.google.com/issues/new?component=907884&template=1466542'
                //   178: invokevirtual toString : ()Ljava/lang/String;
                //   181: invokespecial <init> : (Ljava/lang/String;)V
                //   184: athrow
                //   185: new kotlin/NoWhenBranchMatchedException
                //   188: dup
                //   189: invokespecial <init> : ()V
                //   192: athrow
                //   193: aload_1
                //   194: checkcast androidx/datastore/core/Final
                //   197: invokevirtual getFinalException : ()Ljava/lang/Throwable;
                //   200: athrow
                //   201: aload_1
                //   202: checkcast androidx/datastore/core/ReadException
                //   205: invokevirtual getReadException : ()Ljava/lang/Throwable;
                //   208: athrow
              }
            },  param1Continuation);
        return (object == IntrinsicsKt.getCOROUTINE_SUSPENDED()) ? object : Unit.INSTANCE;
      }
    }
    
    @Metadata(d1 = {"\000\023\n\000\n\002\030\002\n\000\n\002\020\002\n\002\b\005*\001\000\b\n\030\0002\b\022\004\022\0028\0000\001J\031\020\002\032\0020\0032\006\020\004\032\0028\000H@ø\001\000¢\006\002\020\005\002\004\n\002\b\031¨\006\006¸\006\b"}, d2 = {"kotlinx/coroutines/flow/FlowKt__CollectKt$collect$3", "Lkotlinx/coroutines/flow/FlowCollector;", "emit", "", "value", "(Ljava/lang/Object;Lkotlin/coroutines/Continuation;)Ljava/lang/Object;", "kotlinx-coroutines-core", "kotlinx/coroutines/flow/FlowKt__EmittersKt$unsafeTransform$lambda-1$$inlined$collect$1", "kotlinx/coroutines/flow/FlowKt__TransformKt$map$$inlined$unsafeTransform$1$2"}, k = 1, mv = {1, 5, 1}, xi = 48)
    public static final class null implements FlowCollector<State<T>> {
      public null(FlowCollector param1FlowCollector) {}
      
      public Object emit(Object param1Object, Continuation param1Continuation) {
        // Byte code:
        //   0: aload_2
        //   1: instanceof androidx/datastore/core/SingleProcessDataStore$data$1$invokeSuspend$$inlined$map$1$2$1
        //   4: ifeq -> 41
        //   7: aload_2
        //   8: checkcast androidx/datastore/core/SingleProcessDataStore$data$1$invokeSuspend$$inlined$map$1$2$1
        //   11: astore #4
        //   13: aload #4
        //   15: getfield label : I
        //   18: istore_3
        //   19: iload_3
        //   20: ldc -2147483648
        //   22: iand
        //   23: ifeq -> 41
        //   26: aload #4
        //   28: iload_3
        //   29: ldc -2147483648
        //   31: iadd
        //   32: putfield label : I
        //   35: aload #4
        //   37: astore_2
        //   38: goto -> 51
        //   41: new androidx/datastore/core/SingleProcessDataStore$data$1$invokeSuspend$$inlined$map$1$2$1
        //   44: dup
        //   45: aload_0
        //   46: aload_2
        //   47: invokespecial <init> : (Landroidx/datastore/core/SingleProcessDataStore$data$1$invokeSuspend$$inlined$map$1$2;Lkotlin/coroutines/Continuation;)V
        //   50: astore_2
        //   51: aload_2
        //   52: getfield result : Ljava/lang/Object;
        //   55: astore #5
        //   57: invokestatic getCOROUTINE_SUSPENDED : ()Ljava/lang/Object;
        //   60: astore #4
        //   62: aload_2
        //   63: getfield label : I
        //   66: istore_3
        //   67: iload_3
        //   68: ifeq -> 94
        //   71: iload_3
        //   72: iconst_1
        //   73: if_icmpne -> 84
        //   76: aload #5
        //   78: invokestatic throwOnFailure : (Ljava/lang/Object;)V
        //   81: goto -> 161
        //   84: new java/lang/IllegalStateException
        //   87: dup
        //   88: ldc 'call to 'resume' before 'invoke' with coroutine'
        //   90: invokespecial <init> : (Ljava/lang/String;)V
        //   93: athrow
        //   94: aload #5
        //   96: invokestatic throwOnFailure : (Ljava/lang/Object;)V
        //   99: aload_0
        //   100: getfield $this_unsafeFlow$inlined : Lkotlinx/coroutines/flow/FlowCollector;
        //   103: astore #5
        //   105: aload_1
        //   106: checkcast androidx/datastore/core/State
        //   109: astore_1
        //   110: aload_1
        //   111: instanceof androidx/datastore/core/ReadException
        //   114: ifne -> 201
        //   117: aload_1
        //   118: instanceof androidx/datastore/core/Final
        //   121: ifne -> 193
        //   124: aload_1
        //   125: instanceof androidx/datastore/core/Data
        //   128: ifeq -> 165
        //   131: aload_1
        //   132: checkcast androidx/datastore/core/Data
        //   135: invokevirtual getValue : ()Ljava/lang/Object;
        //   138: astore_1
        //   139: aload_2
        //   140: iconst_1
        //   141: putfield label : I
        //   144: aload #5
        //   146: aload_1
        //   147: aload_2
        //   148: invokeinterface emit : (Ljava/lang/Object;Lkotlin/coroutines/Continuation;)Ljava/lang/Object;
        //   153: aload #4
        //   155: if_acmpne -> 161
        //   158: aload #4
        //   160: areturn
        //   161: getstatic kotlin/Unit.INSTANCE : Lkotlin/Unit;
        //   164: areturn
        //   165: aload_1
        //   166: instanceof androidx/datastore/core/UnInitialized
        //   169: ifeq -> 185
        //   172: new java/lang/IllegalStateException
        //   175: dup
        //   176: ldc 'This is a bug in DataStore. Please file a bug at: https://issuetracker.google.com/issues/new?component=907884&template=1466542'
        //   178: invokevirtual toString : ()Ljava/lang/String;
        //   181: invokespecial <init> : (Ljava/lang/String;)V
        //   184: athrow
        //   185: new kotlin/NoWhenBranchMatchedException
        //   188: dup
        //   189: invokespecial <init> : ()V
        //   192: athrow
        //   193: aload_1
        //   194: checkcast androidx/datastore/core/Final
        //   197: invokevirtual getFinalException : ()Ljava/lang/Throwable;
        //   200: athrow
        //   201: aload_1
        //   202: checkcast androidx/datastore/core/ReadException
        //   205: invokevirtual getReadException : ()Ljava/lang/Throwable;
        //   208: athrow
      }
    }
    
    @Metadata(k = 3, mv = {1, 5, 1}, xi = 48)
    @DebugMetadata(c = "androidx.datastore.core.SingleProcessDataStore$data$1$invokeSuspend$$inlined$map$1$2", f = "SingleProcessDataStore.kt", l = {137}, m = "emit")
    public static final class null extends ContinuationImpl {
      Object L$0;
      
      int label;
      
      public final Object invokeSuspend(Object param1Object) {
        this.result = param1Object;
        this.label |= Integer.MIN_VALUE;
        return SingleProcessDataStore$data$1$invokeSuspend$$inlined$map$1.null.this.emit(null, (Continuation)this);
      }
    }
  }
  
  @Metadata(d1 = {"\000\016\n\000\n\002\030\002\n\000\n\002\020\013\n\000\020\004\032\0020\003\"\004\b\000\020\0002\f\020\002\032\b\022\004\022\0028\0000\001H@"}, d2 = {"T", "Landroidx/datastore/core/State;", "it", "", "<anonymous>"}, k = 3, mv = {1, 5, 1})
  @DebugMetadata(c = "androidx.datastore.core.SingleProcessDataStore$data$1$1", f = "SingleProcessDataStore.kt", l = {}, m = "invokeSuspend")
  static final class null extends SuspendLambda implements Function2<State<T>, Continuation<? super Boolean>, Object> {
    int label;
    
    null(State<T> param1State, Continuation<? super null> param1Continuation) {
      super(2, param1Continuation);
    }
    
    public final Continuation<Unit> create(Object param1Object, Continuation<?> param1Continuation) {
      Function2<State<T>, Continuation<? super Boolean>, Object> function2 = new Function2<State<T>, Continuation<? super Boolean>, Object>(this.$currentDownStreamFlowState, (Continuation)param1Continuation);
      function2.L$0 = param1Object;
      return (Continuation)function2;
    }
    
    public final Object invoke(State<T> param1State, Continuation<? super Boolean> param1Continuation) {
      return ((null)create(param1State, param1Continuation)).invokeSuspend(Unit.INSTANCE);
    }
    
    public final Object invokeSuspend(Object param1Object) {
      IntrinsicsKt.getCOROUTINE_SUSPENDED();
      if (this.label == 0) {
        ResultKt.throwOnFailure(param1Object);
        param1Object = this.L$0;
        State<T> state = this.$currentDownStreamFlowState;
        boolean bool = state instanceof Data;
        boolean bool2 = false;
        boolean bool1 = bool2;
        if (!bool)
          if (state instanceof Final) {
            bool1 = bool2;
          } else {
            bool1 = bool2;
            if (param1Object == state)
              bool1 = true; 
          }  
        return Boxing.boxBoolean(bool1);
      } 
      throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
    }
  }
  
  @Metadata(d1 = {"\000\031\n\000\n\002\030\002\n\000\n\002\020\002\n\000\n\002\030\002\n\002\b\004*\001\000\b\n\030\0002\b\022\004\022\0028\0000\001J\037\020\002\032\0020\0032\f\020\004\032\b\022\004\022\0028\0000\005H@ø\001\000¢\006\002\020\006\002\004\n\002\b\031¨\006\007¸\006\t"}, d2 = {"kotlinx/coroutines/flow/internal/SafeCollector_commonKt$unsafeFlow$1", "Lkotlinx/coroutines/flow/Flow;", "collect", "", "collector", "Lkotlinx/coroutines/flow/FlowCollector;", "(Lkotlinx/coroutines/flow/FlowCollector;Lkotlin/coroutines/Continuation;)Ljava/lang/Object;", "kotlinx-coroutines-core", "kotlinx/coroutines/flow/FlowKt__EmittersKt$unsafeTransform$$inlined$unsafeFlow$1", "kotlinx/coroutines/flow/FlowKt__TransformKt$map$$inlined$unsafeTransform$1"}, k = 1, mv = {1, 5, 1}, xi = 48)
  public static final class SingleProcessDataStore$data$1$invokeSuspend$$inlined$map$1 implements Flow<T> {
    public SingleProcessDataStore$data$1$invokeSuspend$$inlined$map$1(Flow param1Flow) {}
    
    public Object collect(FlowCollector param1FlowCollector, Continuation param1Continuation) {
      Object object = this.$this_unsafeTransform$inlined.collect(new FlowCollector<State<T>>(param1FlowCollector) {
            public Object emit(Object param1Object, Continuation param1Continuation) {
              // Byte code:
              //   0: aload_2
              //   1: instanceof androidx/datastore/core/SingleProcessDataStore$data$1$invokeSuspend$$inlined$map$1$2$1
              //   4: ifeq -> 41
              //   7: aload_2
              //   8: checkcast androidx/datastore/core/SingleProcessDataStore$data$1$invokeSuspend$$inlined$map$1$2$1
              //   11: astore #4
              //   13: aload #4
              //   15: getfield label : I
              //   18: istore_3
              //   19: iload_3
              //   20: ldc -2147483648
              //   22: iand
              //   23: ifeq -> 41
              //   26: aload #4
              //   28: iload_3
              //   29: ldc -2147483648
              //   31: iadd
              //   32: putfield label : I
              //   35: aload #4
              //   37: astore_2
              //   38: goto -> 51
              //   41: new androidx/datastore/core/SingleProcessDataStore$data$1$invokeSuspend$$inlined$map$1$2$1
              //   44: dup
              //   45: aload_0
              //   46: aload_2
              //   47: invokespecial <init> : (Landroidx/datastore/core/SingleProcessDataStore$data$1$invokeSuspend$$inlined$map$1$2;Lkotlin/coroutines/Continuation;)V
              //   50: astore_2
              //   51: aload_2
              //   52: getfield result : Ljava/lang/Object;
              //   55: astore #5
              //   57: invokestatic getCOROUTINE_SUSPENDED : ()Ljava/lang/Object;
              //   60: astore #4
              //   62: aload_2
              //   63: getfield label : I
              //   66: istore_3
              //   67: iload_3
              //   68: ifeq -> 94
              //   71: iload_3
              //   72: iconst_1
              //   73: if_icmpne -> 84
              //   76: aload #5
              //   78: invokestatic throwOnFailure : (Ljava/lang/Object;)V
              //   81: goto -> 161
              //   84: new java/lang/IllegalStateException
              //   87: dup
              //   88: ldc 'call to 'resume' before 'invoke' with coroutine'
              //   90: invokespecial <init> : (Ljava/lang/String;)V
              //   93: athrow
              //   94: aload #5
              //   96: invokestatic throwOnFailure : (Ljava/lang/Object;)V
              //   99: aload_0
              //   100: getfield $this_unsafeFlow$inlined : Lkotlinx/coroutines/flow/FlowCollector;
              //   103: astore #5
              //   105: aload_1
              //   106: checkcast androidx/datastore/core/State
              //   109: astore_1
              //   110: aload_1
              //   111: instanceof androidx/datastore/core/ReadException
              //   114: ifne -> 201
              //   117: aload_1
              //   118: instanceof androidx/datastore/core/Final
              //   121: ifne -> 193
              //   124: aload_1
              //   125: instanceof androidx/datastore/core/Data
              //   128: ifeq -> 165
              //   131: aload_1
              //   132: checkcast androidx/datastore/core/Data
              //   135: invokevirtual getValue : ()Ljava/lang/Object;
              //   138: astore_1
              //   139: aload_2
              //   140: iconst_1
              //   141: putfield label : I
              //   144: aload #5
              //   146: aload_1
              //   147: aload_2
              //   148: invokeinterface emit : (Ljava/lang/Object;Lkotlin/coroutines/Continuation;)Ljava/lang/Object;
              //   153: aload #4
              //   155: if_acmpne -> 161
              //   158: aload #4
              //   160: areturn
              //   161: getstatic kotlin/Unit.INSTANCE : Lkotlin/Unit;
              //   164: areturn
              //   165: aload_1
              //   166: instanceof androidx/datastore/core/UnInitialized
              //   169: ifeq -> 185
              //   172: new java/lang/IllegalStateException
              //   175: dup
              //   176: ldc 'This is a bug in DataStore. Please file a bug at: https://issuetracker.google.com/issues/new?component=907884&template=1466542'
              //   178: invokevirtual toString : ()Ljava/lang/String;
              //   181: invokespecial <init> : (Ljava/lang/String;)V
              //   184: athrow
              //   185: new kotlin/NoWhenBranchMatchedException
              //   188: dup
              //   189: invokespecial <init> : ()V
              //   192: athrow
              //   193: aload_1
              //   194: checkcast androidx/datastore/core/Final
              //   197: invokevirtual getFinalException : ()Ljava/lang/Throwable;
              //   200: athrow
              //   201: aload_1
              //   202: checkcast androidx/datastore/core/ReadException
              //   205: invokevirtual getReadException : ()Ljava/lang/Throwable;
              //   208: athrow
            }
          },  param1Continuation);
      return (object == IntrinsicsKt.getCOROUTINE_SUSPENDED()) ? object : Unit.INSTANCE;
    }
  }
  
  @Metadata(d1 = {"\000\023\n\000\n\002\030\002\n\000\n\002\020\002\n\002\b\005*\001\000\b\n\030\0002\b\022\004\022\0028\0000\001J\031\020\002\032\0020\0032\006\020\004\032\0028\000H@ø\001\000¢\006\002\020\005\002\004\n\002\b\031¨\006\006¸\006\b"}, d2 = {"kotlinx/coroutines/flow/FlowKt__CollectKt$collect$3", "Lkotlinx/coroutines/flow/FlowCollector;", "emit", "", "value", "(Ljava/lang/Object;Lkotlin/coroutines/Continuation;)Ljava/lang/Object;", "kotlinx-coroutines-core", "kotlinx/coroutines/flow/FlowKt__EmittersKt$unsafeTransform$lambda-1$$inlined$collect$1", "kotlinx/coroutines/flow/FlowKt__TransformKt$map$$inlined$unsafeTransform$1$2"}, k = 1, mv = {1, 5, 1}, xi = 48)
  public static final class null implements FlowCollector<State<T>> {
    public null(FlowCollector param1FlowCollector) {}
    
    public Object emit(Object param1Object, Continuation param1Continuation) {
      // Byte code:
      //   0: aload_2
      //   1: instanceof androidx/datastore/core/SingleProcessDataStore$data$1$invokeSuspend$$inlined$map$1$2$1
      //   4: ifeq -> 41
      //   7: aload_2
      //   8: checkcast androidx/datastore/core/SingleProcessDataStore$data$1$invokeSuspend$$inlined$map$1$2$1
      //   11: astore #4
      //   13: aload #4
      //   15: getfield label : I
      //   18: istore_3
      //   19: iload_3
      //   20: ldc -2147483648
      //   22: iand
      //   23: ifeq -> 41
      //   26: aload #4
      //   28: iload_3
      //   29: ldc -2147483648
      //   31: iadd
      //   32: putfield label : I
      //   35: aload #4
      //   37: astore_2
      //   38: goto -> 51
      //   41: new androidx/datastore/core/SingleProcessDataStore$data$1$invokeSuspend$$inlined$map$1$2$1
      //   44: dup
      //   45: aload_0
      //   46: aload_2
      //   47: invokespecial <init> : (Landroidx/datastore/core/SingleProcessDataStore$data$1$invokeSuspend$$inlined$map$1$2;Lkotlin/coroutines/Continuation;)V
      //   50: astore_2
      //   51: aload_2
      //   52: getfield result : Ljava/lang/Object;
      //   55: astore #5
      //   57: invokestatic getCOROUTINE_SUSPENDED : ()Ljava/lang/Object;
      //   60: astore #4
      //   62: aload_2
      //   63: getfield label : I
      //   66: istore_3
      //   67: iload_3
      //   68: ifeq -> 94
      //   71: iload_3
      //   72: iconst_1
      //   73: if_icmpne -> 84
      //   76: aload #5
      //   78: invokestatic throwOnFailure : (Ljava/lang/Object;)V
      //   81: goto -> 161
      //   84: new java/lang/IllegalStateException
      //   87: dup
      //   88: ldc 'call to 'resume' before 'invoke' with coroutine'
      //   90: invokespecial <init> : (Ljava/lang/String;)V
      //   93: athrow
      //   94: aload #5
      //   96: invokestatic throwOnFailure : (Ljava/lang/Object;)V
      //   99: aload_0
      //   100: getfield $this_unsafeFlow$inlined : Lkotlinx/coroutines/flow/FlowCollector;
      //   103: astore #5
      //   105: aload_1
      //   106: checkcast androidx/datastore/core/State
      //   109: astore_1
      //   110: aload_1
      //   111: instanceof androidx/datastore/core/ReadException
      //   114: ifne -> 201
      //   117: aload_1
      //   118: instanceof androidx/datastore/core/Final
      //   121: ifne -> 193
      //   124: aload_1
      //   125: instanceof androidx/datastore/core/Data
      //   128: ifeq -> 165
      //   131: aload_1
      //   132: checkcast androidx/datastore/core/Data
      //   135: invokevirtual getValue : ()Ljava/lang/Object;
      //   138: astore_1
      //   139: aload_2
      //   140: iconst_1
      //   141: putfield label : I
      //   144: aload #5
      //   146: aload_1
      //   147: aload_2
      //   148: invokeinterface emit : (Ljava/lang/Object;Lkotlin/coroutines/Continuation;)Ljava/lang/Object;
      //   153: aload #4
      //   155: if_acmpne -> 161
      //   158: aload #4
      //   160: areturn
      //   161: getstatic kotlin/Unit.INSTANCE : Lkotlin/Unit;
      //   164: areturn
      //   165: aload_1
      //   166: instanceof androidx/datastore/core/UnInitialized
      //   169: ifeq -> 185
      //   172: new java/lang/IllegalStateException
      //   175: dup
      //   176: ldc 'This is a bug in DataStore. Please file a bug at: https://issuetracker.google.com/issues/new?component=907884&template=1466542'
      //   178: invokevirtual toString : ()Ljava/lang/String;
      //   181: invokespecial <init> : (Ljava/lang/String;)V
      //   184: athrow
      //   185: new kotlin/NoWhenBranchMatchedException
      //   188: dup
      //   189: invokespecial <init> : ()V
      //   192: athrow
      //   193: aload_1
      //   194: checkcast androidx/datastore/core/Final
      //   197: invokevirtual getFinalException : ()Ljava/lang/Throwable;
      //   200: athrow
      //   201: aload_1
      //   202: checkcast androidx/datastore/core/ReadException
      //   205: invokevirtual getReadException : ()Ljava/lang/Throwable;
      //   208: athrow
    }
  }
  
  @Metadata(k = 3, mv = {1, 5, 1}, xi = 48)
  @DebugMetadata(c = "androidx.datastore.core.SingleProcessDataStore$data$1$invokeSuspend$$inlined$map$1$2", f = "SingleProcessDataStore.kt", l = {137}, m = "emit")
  public static final class null extends ContinuationImpl {
    Object L$0;
    
    int label;
    
    public final Object invokeSuspend(Object param1Object) {
      this.result = param1Object;
      this.label |= Integer.MIN_VALUE;
      return SingleProcessDataStore$data$1$invokeSuspend$$inlined$map$1.null.this.emit(null, (Continuation)this);
    }
  }
  
  @Metadata(d1 = {"\000\b\n\000\n\002\030\002\n\000\020\002\032\0020\001\"\004\b\000\020\000H\n"}, d2 = {"T", "Ljava/io/File;", "<anonymous>"}, k = 3, mv = {1, 5, 1})
  static final class SingleProcessDataStore$file$2 extends Lambda implements Function0<File> {
    SingleProcessDataStore$file$2() {
      super(0);
    }
    
    public final File invoke() {
      null = (File)SingleProcessDataStore.this.produceFile.invoke();
      String str = null.getAbsolutePath();
      SingleProcessDataStore.Companion companion = SingleProcessDataStore.Companion;
      synchronized (companion.getActiveFilesLock$datastore_core()) {
        if ((companion.getActiveFiles$datastore_core().contains(str) ^ true) != 0) {
          Set<String> set = companion.getActiveFiles$datastore_core();
          Intrinsics.checkNotNullExpressionValue(str, "it");
          set.add(str);
          return null;
        } 
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("There are multiple DataStores active for the same file: ");
        stringBuilder.append(null);
        stringBuilder.append(". You should either maintain your DataStore as a singleton or confirm that there is no two DataStore's active on the same file (by confirming that the scope is cancelled).");
        throw new IllegalStateException(stringBuilder.toString().toString());
      } 
    }
  }
  
  @Metadata(k = 3, mv = {1, 5, 1}, xi = 48)
  @DebugMetadata(c = "androidx.datastore.core.SingleProcessDataStore", f = "SingleProcessDataStore.kt", l = {276, 281, 284}, m = "handleUpdate")
  static final class SingleProcessDataStore$handleUpdate$1 extends ContinuationImpl {
    Object L$0;
    
    Object L$1;
    
    Object L$2;
    
    int label;
    
    SingleProcessDataStore$handleUpdate$1(Continuation<? super SingleProcessDataStore$handleUpdate$1> param1Continuation) {
      super(param1Continuation);
    }
    
    public final Object invokeSuspend(Object param1Object) {
      this.result = param1Object;
      this.label |= Integer.MIN_VALUE;
      return SingleProcessDataStore.this.handleUpdate(null, (Continuation<? super Unit>)this);
    }
  }
  
  @Metadata(k = 3, mv = {1, 5, 1}, xi = 48)
  @DebugMetadata(c = "androidx.datastore.core.SingleProcessDataStore", f = "SingleProcessDataStore.kt", l = {322, 348, 505}, m = "readAndInit")
  static final class SingleProcessDataStore$readAndInit$1 extends ContinuationImpl {
    Object L$0;
    
    Object L$1;
    
    Object L$2;
    
    Object L$3;
    
    Object L$4;
    
    Object L$5;
    
    int label;
    
    SingleProcessDataStore$readAndInit$1(Continuation<? super SingleProcessDataStore$readAndInit$1> param1Continuation) {
      super(param1Continuation);
    }
    
    public final Object invokeSuspend(Object param1Object) {
      this.result = param1Object;
      this.label |= Integer.MIN_VALUE;
      return SingleProcessDataStore.this.readAndInit((Continuation<? super Unit>)this);
    }
  }
  
  @Metadata(d1 = {"\000\031\n\000\n\002\030\002\n\002\030\002\n\002\030\002\n\002\020\000\n\002\b\004*\001\000\b\n\030\0002\b\022\004\022\0028\0000\001J7\020\006\032\0028\0002\"\020\005\032\036\b\001\022\004\022\0028\000\022\n\022\b\022\004\022\0028\0000\003\022\006\022\004\030\0010\0040\002H@ø\001\000¢\006\004\b\006\020\007\002\004\n\002\b\031¨\006\b"}, d2 = {"androidx/datastore/core/SingleProcessDataStore$readAndInit$api$1", "Landroidx/datastore/core/InitializerApi;", "Lkotlin/Function2;", "Lkotlin/coroutines/Continuation;", "", "transform", "updateData", "(Lkotlin/jvm/functions/Function2;Lkotlin/coroutines/Continuation;)Ljava/lang/Object;", "datastore-core"}, k = 1, mv = {1, 5, 1})
  public static final class SingleProcessDataStore$readAndInit$api$1 implements InitializerApi<T> {
    SingleProcessDataStore$readAndInit$api$1(Ref.BooleanRef param1BooleanRef, Ref.ObjectRef<T> param1ObjectRef, SingleProcessDataStore<T> param1SingleProcessDataStore) {}
    
    public Object updateData(Function2<? super T, ? super Continuation<? super T>, ? extends Object> param1Function2, Continuation<? super T> param1Continuation) {
      // Byte code:
      //   0: aload_2
      //   1: instanceof androidx/datastore/core/SingleProcessDataStore$readAndInit$api$1$updateData$1
      //   4: ifeq -> 38
      //   7: aload_2
      //   8: checkcast androidx/datastore/core/SingleProcessDataStore$readAndInit$api$1$updateData$1
      //   11: astore #6
      //   13: aload #6
      //   15: getfield label : I
      //   18: istore_3
      //   19: iload_3
      //   20: ldc -2147483648
      //   22: iand
      //   23: ifeq -> 38
      //   26: aload #6
      //   28: iload_3
      //   29: ldc -2147483648
      //   31: iadd
      //   32: putfield label : I
      //   35: goto -> 49
      //   38: new androidx/datastore/core/SingleProcessDataStore$readAndInit$api$1$updateData$1
      //   41: dup
      //   42: aload_0
      //   43: aload_2
      //   44: invokespecial <init> : (Landroidx/datastore/core/SingleProcessDataStore$readAndInit$api$1;Lkotlin/coroutines/Continuation;)V
      //   47: astore #6
      //   49: aload #6
      //   51: getfield result : Ljava/lang/Object;
      //   54: astore #5
      //   56: invokestatic getCOROUTINE_SUSPENDED : ()Ljava/lang/Object;
      //   59: astore #9
      //   61: aload #6
      //   63: getfield label : I
      //   66: istore_3
      //   67: iload_3
      //   68: ifeq -> 246
      //   71: iload_3
      //   72: iconst_1
      //   73: if_icmpeq -> 186
      //   76: iload_3
      //   77: iconst_2
      //   78: if_icmpeq -> 140
      //   81: iload_3
      //   82: iconst_3
      //   83: if_icmpne -> 130
      //   86: aload #6
      //   88: getfield L$2 : Ljava/lang/Object;
      //   91: astore #7
      //   93: aload #6
      //   95: getfield L$1 : Ljava/lang/Object;
      //   98: checkcast kotlin/jvm/internal/Ref$ObjectRef
      //   101: astore #4
      //   103: aload #6
      //   105: getfield L$0 : Ljava/lang/Object;
      //   108: checkcast kotlinx/coroutines/sync/Mutex
      //   111: astore_2
      //   112: aload_2
      //   113: astore_1
      //   114: aload #5
      //   116: invokestatic throwOnFailure : (Ljava/lang/Object;)V
      //   119: aload #7
      //   121: astore #5
      //   123: goto -> 508
      //   126: astore_2
      //   127: goto -> 563
      //   130: new java/lang/IllegalStateException
      //   133: dup
      //   134: ldc 'call to 'resume' before 'invoke' with coroutine'
      //   136: invokespecial <init> : (Ljava/lang/String;)V
      //   139: athrow
      //   140: aload #6
      //   142: getfield L$2 : Ljava/lang/Object;
      //   145: checkcast androidx/datastore/core/SingleProcessDataStore
      //   148: astore #7
      //   150: aload #6
      //   152: getfield L$1 : Ljava/lang/Object;
      //   155: checkcast kotlin/jvm/internal/Ref$ObjectRef
      //   158: astore_2
      //   159: aload #6
      //   161: getfield L$0 : Ljava/lang/Object;
      //   164: checkcast kotlinx/coroutines/sync/Mutex
      //   167: astore_1
      //   168: aload_1
      //   169: astore #4
      //   171: aload #5
      //   173: invokestatic throwOnFailure : (Ljava/lang/Object;)V
      //   176: goto -> 427
      //   179: astore_2
      //   180: aload #4
      //   182: astore_1
      //   183: goto -> 563
      //   186: aload #6
      //   188: getfield L$4 : Ljava/lang/Object;
      //   191: checkcast androidx/datastore/core/SingleProcessDataStore
      //   194: astore_1
      //   195: aload #6
      //   197: getfield L$3 : Ljava/lang/Object;
      //   200: checkcast kotlin/jvm/internal/Ref$ObjectRef
      //   203: astore #4
      //   205: aload #6
      //   207: getfield L$2 : Ljava/lang/Object;
      //   210: checkcast kotlin/jvm/internal/Ref$BooleanRef
      //   213: astore #8
      //   215: aload #6
      //   217: getfield L$1 : Ljava/lang/Object;
      //   220: checkcast kotlinx/coroutines/sync/Mutex
      //   223: astore_2
      //   224: aload #6
      //   226: getfield L$0 : Ljava/lang/Object;
      //   229: checkcast kotlin/jvm/functions/Function2
      //   232: astore #7
      //   234: aload #5
      //   236: invokestatic throwOnFailure : (Ljava/lang/Object;)V
      //   239: aload #7
      //   241: astore #5
      //   243: goto -> 344
      //   246: aload #5
      //   248: invokestatic throwOnFailure : (Ljava/lang/Object;)V
      //   251: aload_0
      //   252: getfield $updateLock : Lkotlinx/coroutines/sync/Mutex;
      //   255: astore_2
      //   256: aload_0
      //   257: getfield $initializationComplete : Lkotlin/jvm/internal/Ref$BooleanRef;
      //   260: astore #4
      //   262: aload_0
      //   263: getfield $initData : Lkotlin/jvm/internal/Ref$ObjectRef;
      //   266: astore #7
      //   268: aload_0
      //   269: getfield this$0 : Landroidx/datastore/core/SingleProcessDataStore;
      //   272: astore #8
      //   274: aload #6
      //   276: aload_1
      //   277: putfield L$0 : Ljava/lang/Object;
      //   280: aload #6
      //   282: aload_2
      //   283: putfield L$1 : Ljava/lang/Object;
      //   286: aload #6
      //   288: aload #4
      //   290: putfield L$2 : Ljava/lang/Object;
      //   293: aload #6
      //   295: aload #7
      //   297: putfield L$3 : Ljava/lang/Object;
      //   300: aload #6
      //   302: aload #8
      //   304: putfield L$4 : Ljava/lang/Object;
      //   307: aload #6
      //   309: iconst_1
      //   310: putfield label : I
      //   313: aload_2
      //   314: aconst_null
      //   315: aload #6
      //   317: invokeinterface lock : (Ljava/lang/Object;Lkotlin/coroutines/Continuation;)Ljava/lang/Object;
      //   322: aload #9
      //   324: if_acmpne -> 330
      //   327: aload #9
      //   329: areturn
      //   330: aload_1
      //   331: astore #5
      //   333: aload #8
      //   335: astore_1
      //   336: aload #4
      //   338: astore #8
      //   340: aload #7
      //   342: astore #4
      //   344: aload #8
      //   346: getfield element : Z
      //   349: ifne -> 546
      //   352: aload #4
      //   354: getfield element : Ljava/lang/Object;
      //   357: astore #7
      //   359: aload #6
      //   361: aload_2
      //   362: putfield L$0 : Ljava/lang/Object;
      //   365: aload #6
      //   367: aload #4
      //   369: putfield L$1 : Ljava/lang/Object;
      //   372: aload #6
      //   374: aload_1
      //   375: putfield L$2 : Ljava/lang/Object;
      //   378: aload #6
      //   380: aconst_null
      //   381: putfield L$3 : Ljava/lang/Object;
      //   384: aload #6
      //   386: aconst_null
      //   387: putfield L$4 : Ljava/lang/Object;
      //   390: aload #6
      //   392: iconst_2
      //   393: putfield label : I
      //   396: aload #5
      //   398: aload #7
      //   400: aload #6
      //   402: invokeinterface invoke : (Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
      //   407: astore #5
      //   409: aload #5
      //   411: aload #9
      //   413: if_acmpne -> 419
      //   416: aload #9
      //   418: areturn
      //   419: aload_1
      //   420: astore #7
      //   422: aload_2
      //   423: astore_1
      //   424: aload #4
      //   426: astore_2
      //   427: aload_1
      //   428: astore #4
      //   430: aload #5
      //   432: aload_2
      //   433: getfield element : Ljava/lang/Object;
      //   436: invokestatic areEqual : (Ljava/lang/Object;Ljava/lang/Object;)Z
      //   439: ifne -> 572
      //   442: aload_1
      //   443: astore #4
      //   445: aload #6
      //   447: aload_1
      //   448: putfield L$0 : Ljava/lang/Object;
      //   451: aload_1
      //   452: astore #4
      //   454: aload #6
      //   456: aload_2
      //   457: putfield L$1 : Ljava/lang/Object;
      //   460: aload_1
      //   461: astore #4
      //   463: aload #6
      //   465: aload #5
      //   467: putfield L$2 : Ljava/lang/Object;
      //   470: aload_1
      //   471: astore #4
      //   473: aload #6
      //   475: iconst_3
      //   476: putfield label : I
      //   479: aload_1
      //   480: astore #4
      //   482: aload #7
      //   484: aload #5
      //   486: aload #6
      //   488: invokevirtual writeData$datastore_core : (Ljava/lang/Object;Lkotlin/coroutines/Continuation;)Ljava/lang/Object;
      //   491: astore #6
      //   493: aload #6
      //   495: aload #9
      //   497: if_acmpne -> 503
      //   500: aload #9
      //   502: areturn
      //   503: aload_2
      //   504: astore #4
      //   506: aload_1
      //   507: astore_2
      //   508: aload_2
      //   509: astore_1
      //   510: aload #4
      //   512: aload #5
      //   514: putfield element : Ljava/lang/Object;
      //   517: aload #4
      //   519: astore_1
      //   520: aload_2
      //   521: astore #4
      //   523: aload_1
      //   524: astore_2
      //   525: goto -> 528
      //   528: aload #4
      //   530: astore_1
      //   531: aload_2
      //   532: getfield element : Ljava/lang/Object;
      //   535: astore_2
      //   536: aload #4
      //   538: aconst_null
      //   539: invokeinterface unlock : (Ljava/lang/Object;)V
      //   544: aload_2
      //   545: areturn
      //   546: new java/lang/IllegalStateException
      //   549: dup
      //   550: ldc 'InitializerApi.updateData should not be called after initialization is complete.'
      //   552: invokespecial <init> : (Ljava/lang/String;)V
      //   555: athrow
      //   556: astore #4
      //   558: aload_2
      //   559: astore_1
      //   560: aload #4
      //   562: astore_2
      //   563: aload_1
      //   564: aconst_null
      //   565: invokeinterface unlock : (Ljava/lang/Object;)V
      //   570: aload_2
      //   571: athrow
      //   572: aload_1
      //   573: astore #4
      //   575: goto -> 528
      // Exception table:
      //   from	to	target	type
      //   114	119	126	finally
      //   171	176	179	finally
      //   344	409	556	finally
      //   430	442	179	finally
      //   445	451	179	finally
      //   454	460	179	finally
      //   463	470	179	finally
      //   473	479	179	finally
      //   482	493	179	finally
      //   510	517	126	finally
      //   531	536	126	finally
      //   546	556	556	finally
    }
    
    @Metadata(k = 3, mv = {1, 5, 1}, xi = 48)
    @DebugMetadata(c = "androidx.datastore.core.SingleProcessDataStore$readAndInit$api$1", f = "SingleProcessDataStore.kt", l = {503, 337, 339}, m = "updateData")
    static final class SingleProcessDataStore$readAndInit$api$1$updateData$1 extends ContinuationImpl {
      Object L$0;
      
      Object L$1;
      
      Object L$2;
      
      Object L$3;
      
      Object L$4;
      
      int label;
      
      SingleProcessDataStore$readAndInit$api$1$updateData$1(Continuation<? super SingleProcessDataStore$readAndInit$api$1$updateData$1> param1Continuation) {
        super(param1Continuation);
      }
      
      public final Object invokeSuspend(Object param1Object) {
        this.result = param1Object;
        this.label |= Integer.MIN_VALUE;
        return SingleProcessDataStore$readAndInit$api$1.this.updateData(null, (Continuation<? super T>)this);
      }
    }
  }
  
  @Metadata(k = 3, mv = {1, 5, 1}, xi = 48)
  @DebugMetadata(c = "androidx.datastore.core.SingleProcessDataStore$readAndInit$api$1", f = "SingleProcessDataStore.kt", l = {503, 337, 339}, m = "updateData")
  static final class SingleProcessDataStore$readAndInit$api$1$updateData$1 extends ContinuationImpl {
    Object L$0;
    
    Object L$1;
    
    Object L$2;
    
    Object L$3;
    
    Object L$4;
    
    int label;
    
    SingleProcessDataStore$readAndInit$api$1$updateData$1(Continuation<? super SingleProcessDataStore$readAndInit$api$1$updateData$1> param1Continuation) {
      super(param1Continuation);
    }
    
    public final Object invokeSuspend(Object param1Object) {
      this.result = param1Object;
      this.label |= Integer.MIN_VALUE;
      return SingleProcessDataStore$readAndInit$api$1.this.updateData(null, (Continuation<? super T>)this);
    }
  }
  
  @Metadata(k = 3, mv = {1, 5, 1}, xi = 48)
  @DebugMetadata(c = "androidx.datastore.core.SingleProcessDataStore", f = "SingleProcessDataStore.kt", l = {302}, m = "readAndInitOrPropagateAndThrowFailure")
  static final class SingleProcessDataStore$readAndInitOrPropagateAndThrowFailure$1 extends ContinuationImpl {
    Object L$0;
    
    int label;
    
    SingleProcessDataStore$readAndInitOrPropagateAndThrowFailure$1(Continuation<? super SingleProcessDataStore$readAndInitOrPropagateAndThrowFailure$1> param1Continuation) {
      super(param1Continuation);
    }
    
    public final Object invokeSuspend(Object param1Object) {
      this.result = param1Object;
      this.label |= Integer.MIN_VALUE;
      return SingleProcessDataStore.this.readAndInitOrPropagateAndThrowFailure((Continuation<? super Unit>)this);
    }
  }
  
  @Metadata(k = 3, mv = {1, 5, 1}, xi = 48)
  @DebugMetadata(c = "androidx.datastore.core.SingleProcessDataStore", f = "SingleProcessDataStore.kt", l = {311}, m = "readAndInitOrPropagateFailure")
  static final class SingleProcessDataStore$readAndInitOrPropagateFailure$1 extends ContinuationImpl {
    Object L$0;
    
    int label;
    
    SingleProcessDataStore$readAndInitOrPropagateFailure$1(Continuation<? super SingleProcessDataStore$readAndInitOrPropagateFailure$1> param1Continuation) {
      super(param1Continuation);
    }
    
    public final Object invokeSuspend(Object param1Object) {
      this.result = param1Object;
      this.label |= Integer.MIN_VALUE;
      return SingleProcessDataStore.this.readAndInitOrPropagateFailure((Continuation<? super Unit>)this);
    }
  }
  
  @Metadata(k = 3, mv = {1, 5, 1}, xi = 48)
  @DebugMetadata(c = "androidx.datastore.core.SingleProcessDataStore", f = "SingleProcessDataStore.kt", l = {381}, m = "readData")
  static final class SingleProcessDataStore$readData$1 extends ContinuationImpl {
    Object L$0;
    
    Object L$1;
    
    Object L$2;
    
    int label;
    
    SingleProcessDataStore$readData$1(Continuation<? super SingleProcessDataStore$readData$1> param1Continuation) {
      super(param1Continuation);
    }
    
    public final Object invokeSuspend(Object param1Object) {
      this.result = param1Object;
      this.label |= Integer.MIN_VALUE;
      return SingleProcessDataStore.this.readData((Continuation<? super T>)this);
    }
  }
  
  @Metadata(k = 3, mv = {1, 5, 1}, xi = 48)
  @DebugMetadata(c = "androidx.datastore.core.SingleProcessDataStore", f = "SingleProcessDataStore.kt", l = {359, 362, 365}, m = "readDataOrHandleCorruption")
  static final class SingleProcessDataStore$readDataOrHandleCorruption$1 extends ContinuationImpl {
    Object L$0;
    
    Object L$1;
    
    int label;
    
    SingleProcessDataStore$readDataOrHandleCorruption$1(Continuation<? super SingleProcessDataStore$readDataOrHandleCorruption$1> param1Continuation) {
      super(param1Continuation);
    }
    
    public final Object invokeSuspend(Object param1Object) {
      this.result = param1Object;
      this.label |= Integer.MIN_VALUE;
      return SingleProcessDataStore.this.readDataOrHandleCorruption((Continuation<? super T>)this);
    }
  }
  
  @Metadata(k = 3, mv = {1, 5, 1}, xi = 48)
  @DebugMetadata(c = "androidx.datastore.core.SingleProcessDataStore", f = "SingleProcessDataStore.kt", l = {402, 410}, m = "transformAndWrite")
  static final class SingleProcessDataStore$transformAndWrite$1 extends ContinuationImpl {
    Object L$0;
    
    Object L$1;
    
    Object L$2;
    
    int label;
    
    SingleProcessDataStore$transformAndWrite$1(Continuation<? super SingleProcessDataStore$transformAndWrite$1> param1Continuation) {
      super(param1Continuation);
    }
    
    public final Object invokeSuspend(Object param1Object) {
      this.result = param1Object;
      this.label |= Integer.MIN_VALUE;
      return SingleProcessDataStore.this.transformAndWrite(null, null, (Continuation<? super T>)this);
    }
  }
  
  @Metadata(d1 = {"\000\b\n\000\n\002\030\002\n\000\020\002\032\0028\000\"\004\b\000\020\000*\0020\001H@"}, d2 = {"T", "Lkotlinx/coroutines/CoroutineScope;", "<anonymous>"}, k = 3, mv = {1, 5, 1})
  @DebugMetadata(c = "androidx.datastore.core.SingleProcessDataStore$transformAndWrite$newData$1", f = "SingleProcessDataStore.kt", l = {402}, m = "invokeSuspend")
  static final class SingleProcessDataStore$transformAndWrite$newData$1 extends SuspendLambda implements Function2<CoroutineScope, Continuation<? super T>, Object> {
    int label;
    
    SingleProcessDataStore$transformAndWrite$newData$1(Function2<? super T, ? super Continuation<? super T>, ? extends Object> param1Function2, T param1T, Continuation<? super SingleProcessDataStore$transformAndWrite$newData$1> param1Continuation) {
      super(2, param1Continuation);
    }
    
    public final Continuation<Unit> create(Object param1Object, Continuation<?> param1Continuation) {
      return (Continuation<Unit>)new SingleProcessDataStore$transformAndWrite$newData$1(this.$transform, this.$curData, (Continuation)param1Continuation);
    }
    
    public final Object invoke(CoroutineScope param1CoroutineScope, Continuation<? super T> param1Continuation) {
      return ((SingleProcessDataStore$transformAndWrite$newData$1)create(param1CoroutineScope, param1Continuation)).invokeSuspend(Unit.INSTANCE);
    }
    
    public final Object invokeSuspend(Object<T, Continuation<? super T>, Object> param1Object) {
      Object object = IntrinsicsKt.getCOROUTINE_SUSPENDED();
      int i = this.label;
      if (i != 0) {
        if (i == 1) {
          ResultKt.throwOnFailure(param1Object);
          return param1Object;
        } 
        throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
      } 
      ResultKt.throwOnFailure(param1Object);
      param1Object = (Object<T, Continuation<? super T>, Object>)this.$transform;
      T t = this.$curData;
      this.label = 1;
      param1Object = (Object<T, Continuation<? super T>, Object>)param1Object.invoke(t, this);
      return (param1Object == object) ? object : param1Object;
    }
  }
  
  @Metadata(k = 3, mv = {1, 5, 1}, xi = 48)
  @DebugMetadata(c = "androidx.datastore.core.SingleProcessDataStore", f = "SingleProcessDataStore.kt", l = {426}, m = "writeData$datastore_core")
  static final class SingleProcessDataStore$writeData$1 extends ContinuationImpl {
    Object L$0;
    
    Object L$1;
    
    Object L$2;
    
    Object L$3;
    
    Object L$4;
    
    int label;
    
    SingleProcessDataStore$writeData$1(Continuation<? super SingleProcessDataStore$writeData$1> param1Continuation) {
      super(param1Continuation);
    }
    
    public final Object invokeSuspend(Object param1Object) {
      this.result = param1Object;
      this.label |= Integer.MIN_VALUE;
      return SingleProcessDataStore.this.writeData$datastore_core(null, (Continuation<? super Unit>)this);
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\MagicAI - AI Art & Anime Art-dex2jar.jar!\androidx\datastore\core\SingleProcessDataStore.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */