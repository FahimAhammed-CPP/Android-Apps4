package androidx.work;

import android.content.Context;
import androidx.work.impl.utils.futures.SettableFuture;
import com.google.common.util.concurrent.ListenableFuture;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.Executor;
import kotlin.Metadata;
import kotlin.ResultKt;
import kotlin.Unit;
import kotlin.coroutines.Continuation;
import kotlin.coroutines.CoroutineContext;
import kotlin.coroutines.intrinsics.IntrinsicsKt;
import kotlin.coroutines.jvm.internal.DebugMetadata;
import kotlin.coroutines.jvm.internal.DebugProbesKt;
import kotlin.coroutines.jvm.internal.SuspendLambda;
import kotlin.jvm.functions.Function1;
import kotlin.jvm.functions.Function2;
import kotlin.jvm.internal.Intrinsics;
import kotlinx.coroutines.BuildersKt;
import kotlinx.coroutines.CancellableContinuation;
import kotlinx.coroutines.CancellableContinuationImpl;
import kotlinx.coroutines.CompletableJob;
import kotlinx.coroutines.CoroutineDispatcher;
import kotlinx.coroutines.CoroutineScope;
import kotlinx.coroutines.CoroutineScopeKt;
import kotlinx.coroutines.Dispatchers;
import kotlinx.coroutines.Job;
import kotlinx.coroutines.JobKt;

@Metadata(d1 = {"\000P\n\002\030\002\n\002\030\002\n\000\n\002\030\002\n\000\n\002\030\002\n\002\b\002\n\002\030\002\n\002\b\005\n\002\030\002\n\002\030\002\n\002\b\003\n\002\030\002\n\002\b\005\n\002\030\002\n\000\n\002\030\002\n\000\n\002\020\002\n\002\b\005\n\002\030\002\n\002\b\003\b&\030\0002\0020\001B\025\022\006\020\002\032\0020\003\022\006\020\004\032\0020\005¢\006\002\020\006J\021\020\026\032\0020\017H¦@ø\001\000¢\006\002\020\027J\021\020\030\032\0020\031H@ø\001\000¢\006\002\020\027J\f\020\032\032\b\022\004\022\0020\0310\033J\006\020\034\032\0020\035J\031\020\036\032\0020\0352\006\020\037\032\0020\031H@ø\001\000¢\006\002\020 J\031\020!\032\0020\0352\006\020\"\032\0020#H@ø\001\000¢\006\002\020$J\f\020%\032\b\022\004\022\0020\0170\033R\034\020\007\032\0020\b8\026X\004¢\006\016\n\000\022\004\b\t\020\n\032\004\b\013\020\fR\032\020\r\032\b\022\004\022\0020\0170\016X\004¢\006\b\n\000\032\004\b\020\020\021R\024\020\022\032\0020\023X\004¢\006\b\n\000\032\004\b\024\020\025\002\004\n\002\b\031¨\006&"}, d2 = {"Landroidx/work/CoroutineWorker;", "Landroidx/work/ListenableWorker;", "appContext", "Landroid/content/Context;", "params", "Landroidx/work/WorkerParameters;", "(Landroid/content/Context;Landroidx/work/WorkerParameters;)V", "coroutineContext", "Lkotlinx/coroutines/CoroutineDispatcher;", "getCoroutineContext$annotations", "()V", "getCoroutineContext", "()Lkotlinx/coroutines/CoroutineDispatcher;", "future", "Landroidx/work/impl/utils/futures/SettableFuture;", "Landroidx/work/ListenableWorker$Result;", "getFuture$work_runtime_ktx_release", "()Landroidx/work/impl/utils/futures/SettableFuture;", "job", "Lkotlinx/coroutines/CompletableJob;", "getJob$work_runtime_ktx_release", "()Lkotlinx/coroutines/CompletableJob;", "doWork", "(Lkotlin/coroutines/Continuation;)Ljava/lang/Object;", "getForegroundInfo", "Landroidx/work/ForegroundInfo;", "getForegroundInfoAsync", "Lcom/google/common/util/concurrent/ListenableFuture;", "onStopped", "", "setForeground", "foregroundInfo", "(Landroidx/work/ForegroundInfo;Lkotlin/coroutines/Continuation;)Ljava/lang/Object;", "setProgress", "data", "Landroidx/work/Data;", "(Landroidx/work/Data;Lkotlin/coroutines/Continuation;)Ljava/lang/Object;", "startWork", "work-runtime-ktx_release"}, k = 1, mv = {1, 7, 1}, xi = 48)
public abstract class CoroutineWorker extends ListenableWorker {
  private final CoroutineDispatcher coroutineContext;
  
  private final SettableFuture<ListenableWorker.Result> future;
  
  private final CompletableJob job = JobKt.Job$default(null, 1, null);
  
  public CoroutineWorker(Context paramContext, WorkerParameters paramWorkerParameters) {
    super(paramContext, paramWorkerParameters);
    SettableFuture<ListenableWorker.Result> settableFuture = SettableFuture.create();
    Intrinsics.checkNotNullExpressionValue(settableFuture, "create()");
    this.future = settableFuture;
    settableFuture.addListener((Runnable)new CoroutineWorker$.ExternalSyntheticLambda0(this), (Executor)getTaskExecutor().getSerialTaskExecutor());
    this.coroutineContext = Dispatchers.getDefault();
  }
  
  private static final void _init_$lambda$0(CoroutineWorker paramCoroutineWorker) {
    Intrinsics.checkNotNullParameter(paramCoroutineWorker, "this$0");
    if (paramCoroutineWorker.future.isCancelled())
      Job.DefaultImpls.cancel$default((Job)paramCoroutineWorker.job, null, 1, null); 
  }
  
  public abstract Object doWork(Continuation<? super ListenableWorker.Result> paramContinuation);
  
  public CoroutineDispatcher getCoroutineContext() {
    return this.coroutineContext;
  }
  
  public Object getForegroundInfo(Continuation<? super ForegroundInfo> paramContinuation) {
    return getForegroundInfo$suspendImpl(this, paramContinuation);
  }
  
  public final ListenableFuture<ForegroundInfo> getForegroundInfoAsync() {
    CompletableJob completableJob = JobKt.Job$default(null, 1, null);
    CoroutineScope coroutineScope = CoroutineScopeKt.CoroutineScope(getCoroutineContext().plus((CoroutineContext)completableJob));
    JobListenableFuture<ForegroundInfo> jobListenableFuture = new JobListenableFuture((Job)completableJob, null, 2, null);
    BuildersKt.launch$default(coroutineScope, null, null, new CoroutineWorker$getForegroundInfoAsync$1(this, null), 3, null);
    return jobListenableFuture;
  }
  
  public final SettableFuture<ListenableWorker.Result> getFuture$work_runtime_ktx_release() {
    return this.future;
  }
  
  public final CompletableJob getJob$work_runtime_ktx_release() {
    return this.job;
  }
  
  public final void onStopped() {
    super.onStopped();
    this.future.cancel(false);
  }
  
  public final Object setForeground(ForegroundInfo paramForegroundInfo, Continuation<? super Unit> paramContinuation) {
    Throwable throwable1;
    Throwable throwable2;
    ListenableFuture listenableFuture = setForegroundAsync(paramForegroundInfo);
    Intrinsics.checkNotNullExpressionValue(listenableFuture, "setForegroundAsync(foregroundInfo)");
    if (listenableFuture.isDone()) {
      try {
        listenableFuture.get();
      } catch (ExecutionException null) {
        throwable2 = throwable1.getCause();
        if (throwable2 != null)
          throwable1 = throwable2; 
        throw throwable1;
      } 
    } else {
      CancellableContinuationImpl cancellableContinuationImpl = new CancellableContinuationImpl(IntrinsicsKt.intercepted((Continuation)throwable2), 1);
      cancellableContinuationImpl.initCancellability();
      throwable1.addListener((Runnable)new Object((CancellableContinuation)cancellableContinuationImpl, (ListenableFuture)throwable1), (Executor)DirectExecutor.INSTANCE);
      cancellableContinuationImpl.invokeOnCancellation((Function1)new Object((ListenableFuture)throwable1));
      Object object = cancellableContinuationImpl.getResult();
      if (object == IntrinsicsKt.getCOROUTINE_SUSPENDED())
        DebugProbesKt.probeCoroutineSuspended((Continuation)throwable2); 
      if (object == IntrinsicsKt.getCOROUTINE_SUSPENDED())
        return object; 
    } 
    return Unit.INSTANCE;
  }
  
  public final Object setProgress(Data paramData, Continuation<? super Unit> paramContinuation) {
    Throwable throwable1;
    Throwable throwable2;
    ListenableFuture listenableFuture = setProgressAsync(paramData);
    Intrinsics.checkNotNullExpressionValue(listenableFuture, "setProgressAsync(data)");
    if (listenableFuture.isDone()) {
      try {
        listenableFuture.get();
      } catch (ExecutionException null) {
        throwable2 = throwable1.getCause();
        if (throwable2 != null)
          throwable1 = throwable2; 
        throw throwable1;
      } 
    } else {
      CancellableContinuationImpl cancellableContinuationImpl = new CancellableContinuationImpl(IntrinsicsKt.intercepted((Continuation)throwable2), 1);
      cancellableContinuationImpl.initCancellability();
      throwable1.addListener((Runnable)new Object((CancellableContinuation)cancellableContinuationImpl, (ListenableFuture)throwable1), (Executor)DirectExecutor.INSTANCE);
      cancellableContinuationImpl.invokeOnCancellation((Function1)new Object((ListenableFuture)throwable1));
      Object object = cancellableContinuationImpl.getResult();
      if (object == IntrinsicsKt.getCOROUTINE_SUSPENDED())
        DebugProbesKt.probeCoroutineSuspended((Continuation)throwable2); 
      if (object == IntrinsicsKt.getCOROUTINE_SUSPENDED())
        return object; 
    } 
    return Unit.INSTANCE;
  }
  
  public final ListenableFuture<ListenableWorker.Result> startWork() {
    BuildersKt.launch$default(CoroutineScopeKt.CoroutineScope(getCoroutineContext().plus((CoroutineContext)this.job)), null, null, new CoroutineWorker$startWork$1(null), 3, null);
    return (ListenableFuture<ListenableWorker.Result>)this.future;
  }
  
  @Metadata(d1 = {"\000\n\n\002\030\002\n\002\020\002\n\000\020\002\032\0020\001*\0020\000H@"}, d2 = {"Lkotlinx/coroutines/CoroutineScope;", "", "<anonymous>"}, k = 3, mv = {1, 7, 1})
  @DebugMetadata(c = "androidx.work.CoroutineWorker$getForegroundInfoAsync$1", f = "CoroutineWorker.kt", l = {134}, m = "invokeSuspend")
  static final class CoroutineWorker$getForegroundInfoAsync$1 extends SuspendLambda implements Function2<CoroutineScope, Continuation<? super Unit>, Object> {
    Object L$0;
    
    int label;
    
    CoroutineWorker$getForegroundInfoAsync$1(CoroutineWorker param1CoroutineWorker, Continuation<? super CoroutineWorker$getForegroundInfoAsync$1> param1Continuation) {
      super(2, param1Continuation);
    }
    
    public final Continuation<Unit> create(Object param1Object, Continuation<?> param1Continuation) {
      return (Continuation<Unit>)new CoroutineWorker$getForegroundInfoAsync$1(CoroutineWorker.this, (Continuation)param1Continuation);
    }
    
    public final Object invoke(CoroutineScope param1CoroutineScope, Continuation<? super Unit> param1Continuation) {
      return ((CoroutineWorker$getForegroundInfoAsync$1)create(param1CoroutineScope, param1Continuation)).invokeSuspend(Unit.INSTANCE);
    }
    
    public final Object invokeSuspend(Object<ForegroundInfo> param1Object) {
      Object object1;
      Object<ForegroundInfo> object = (Object<ForegroundInfo>)IntrinsicsKt.getCOROUTINE_SUSPENDED();
      int i = this.label;
      if (i != 0) {
        if (i == 1) {
          object = (Object<ForegroundInfo>)this.L$0;
          ResultKt.throwOnFailure(param1Object);
          object1 = param1Object;
        } else {
          throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
        } 
      } else {
        ResultKt.throwOnFailure(param1Object);
        param1Object = (Object<ForegroundInfo>)this.$jobFuture;
        CoroutineWorker coroutineWorker = CoroutineWorker.this;
        this.L$0 = param1Object;
        this.label = 1;
        object1 = coroutineWorker.getForegroundInfo((Continuation<? super ForegroundInfo>)this);
        if (object1 == object)
          return object; 
        object = param1Object;
      } 
      object.complete(object1);
      return Unit.INSTANCE;
    }
  }
  
  @Metadata(d1 = {"\000\n\n\002\030\002\n\002\020\002\n\000\020\002\032\0020\001*\0020\000H@"}, d2 = {"Lkotlinx/coroutines/CoroutineScope;", "", "<anonymous>"}, k = 3, mv = {1, 7, 1})
  @DebugMetadata(c = "androidx.work.CoroutineWorker$startWork$1", f = "CoroutineWorker.kt", l = {68}, m = "invokeSuspend")
  static final class CoroutineWorker$startWork$1 extends SuspendLambda implements Function2<CoroutineScope, Continuation<? super Unit>, Object> {
    int label;
    
    CoroutineWorker$startWork$1(Continuation<? super CoroutineWorker$startWork$1> param1Continuation) {
      super(2, param1Continuation);
    }
    
    public final Continuation<Unit> create(Object param1Object, Continuation<?> param1Continuation) {
      return (Continuation<Unit>)new CoroutineWorker$startWork$1((Continuation)param1Continuation);
    }
    
    public final Object invoke(CoroutineScope param1CoroutineScope, Continuation<? super Unit> param1Continuation) {
      return ((CoroutineWorker$startWork$1)create(param1CoroutineScope, param1Continuation)).invokeSuspend(Unit.INSTANCE);
    }
    
    public final Object invokeSuspend(Object param1Object) {
      Object object = IntrinsicsKt.getCOROUTINE_SUSPENDED();
      int i = this.label;
      if (i != 0) {
        if (i == 1) {
          try {
            ResultKt.throwOnFailure(param1Object);
          } finally {}
        } else {
          throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
        } 
      } else {
        ResultKt.throwOnFailure(param1Object);
        param1Object = CoroutineWorker.this;
        this.label = 1;
        Object object1 = param1Object.doWork((Continuation<? super ListenableWorker.Result>)this);
        param1Object = object1;
        if (object1 == object)
          return object; 
      } 
      param1Object = param1Object;
      CoroutineWorker.this.getFuture$work_runtime_ktx_release().set(param1Object);
      return Unit.INSTANCE;
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\MagicAI - AI Art & Anime Art-dex2jar.jar!\androidx\work\CoroutineWorker.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */