package androidx.work;

import android.annotation.SuppressLint;
import android.os.Build;
import androidx.annotation.RequiresApi;
import androidx.work.impl.utils.DurationApi26Impl;
import j$.time.Duration;
import java.util.concurrent.TimeUnit;
import kotlin.Metadata;
import kotlin.jvm.internal.DefaultConstructorMarker;

@Metadata(d1 = {"\000\022\n\002\030\002\n\002\030\002\n\000\n\002\030\002\n\002\b\004\030\000 \0062\0020\001:\002\005\006B\017\b\000\022\006\020\002\032\0020\003¢\006\002\020\004¨\006\007"}, d2 = {"Landroidx/work/PeriodicWorkRequest;", "Landroidx/work/WorkRequest;", "builder", "Landroidx/work/PeriodicWorkRequest$Builder;", "(Landroidx/work/PeriodicWorkRequest$Builder;)V", "Builder", "Companion", "work-runtime_release"}, k = 1, mv = {1, 7, 1}, xi = 48)
public final class PeriodicWorkRequest extends WorkRequest {
  public static final Companion Companion = new Companion(null);
  
  @SuppressLint({"MinMaxConstant"})
  public static final long MIN_PERIODIC_FLEX_MILLIS = 300000L;
  
  @SuppressLint({"MinMaxConstant"})
  public static final long MIN_PERIODIC_INTERVAL_MILLIS = 900000L;
  
  public PeriodicWorkRequest(Builder paramBuilder) {
    super(paramBuilder.getId$work_runtime_release(), paramBuilder.getWorkSpec$work_runtime_release(), paramBuilder.getTags$work_runtime_release());
  }
  
  @Metadata(d1 = {"\000,\n\002\030\002\n\002\030\002\n\002\030\002\n\002\b\006\n\002\030\002\n\002\030\002\n\000\n\002\020\t\n\000\n\002\030\002\n\002\b\003\n\002\b\007\030\0002\016\022\004\022\0020\000\022\004\022\0020\0020\001B+\b\026\022\020\020\013\032\f\022\b\b\001\022\004\030\0010\n0\t\022\006\020\r\032\0020\f\022\006\020\017\032\0020\016¢\006\004\b\020\020\021B!\b\027\022\016\020\013\032\n\022\006\b\001\022\0020\n0\t\022\006\020\r\032\0020\022¢\006\004\b\020\020\023B;\b\026\022\020\020\013\032\f\022\b\b\001\022\004\030\0010\n0\t\022\006\020\r\032\0020\f\022\006\020\017\032\0020\016\022\006\020\024\032\0020\f\022\006\020\025\032\0020\016¢\006\004\b\020\020\026B+\b\027\022\020\020\013\032\f\022\b\b\001\022\004\030\0010\n0\t\022\006\020\r\032\0020\022\022\006\020\024\032\0020\022¢\006\004\b\020\020\027J\017\020\005\032\0020\002H\020¢\006\004\b\003\020\004R\024\020\b\032\0020\0008PX\004¢\006\006\032\004\b\006\020\007¨\006\030"}, d2 = {"Landroidx/work/PeriodicWorkRequest$Builder;", "Landroidx/work/WorkRequest$Builder;", "Landroidx/work/PeriodicWorkRequest;", "buildInternal$work_runtime_release", "()Landroidx/work/PeriodicWorkRequest;", "buildInternal", "getThisObject$work_runtime_release", "()Landroidx/work/PeriodicWorkRequest$Builder;", "thisObject", "Ljava/lang/Class;", "Landroidx/work/ListenableWorker;", "workerClass", "", "repeatInterval", "Ljava/util/concurrent/TimeUnit;", "repeatIntervalTimeUnit", "<init>", "(Ljava/lang/Class;JLjava/util/concurrent/TimeUnit;)V", "j$/time/Duration", "(Ljava/lang/Class;Lj$/time/Duration;)V", "flexInterval", "flexIntervalTimeUnit", "(Ljava/lang/Class;JLjava/util/concurrent/TimeUnit;JLjava/util/concurrent/TimeUnit;)V", "(Ljava/lang/Class;Lj$/time/Duration;Lj$/time/Duration;)V", "work-runtime_release"}, k = 1, mv = {1, 7, 1})
  public static final class Builder extends WorkRequest.Builder<Builder, PeriodicWorkRequest> {
    public Builder(Class<? extends ListenableWorker> param1Class, long param1Long, TimeUnit param1TimeUnit) {
      super(param1Class);
      getWorkSpec$work_runtime_release().setPeriodic(param1TimeUnit.toMillis(param1Long));
    }
    
    public Builder(Class<? extends ListenableWorker> param1Class, long param1Long1, TimeUnit param1TimeUnit1, long param1Long2, TimeUnit param1TimeUnit2) {
      super(param1Class);
      getWorkSpec$work_runtime_release().setPeriodic(param1TimeUnit1.toMillis(param1Long1), param1TimeUnit2.toMillis(param1Long2));
    }
    
    @RequiresApi(26)
    public Builder(Class<? extends ListenableWorker> param1Class, Duration param1Duration) {
      super(param1Class);
      getWorkSpec$work_runtime_release().setPeriodic(DurationApi26Impl.toMillisCompat(param1Duration));
    }
    
    @RequiresApi(26)
    public Builder(Class<? extends ListenableWorker> param1Class, Duration param1Duration1, Duration param1Duration2) {
      super(param1Class);
      getWorkSpec$work_runtime_release().setPeriodic(DurationApi26Impl.toMillisCompat(param1Duration1), DurationApi26Impl.toMillisCompat(param1Duration2));
    }
    
    public PeriodicWorkRequest buildInternal$work_runtime_release() {
      boolean bool;
      if (!getBackoffCriteriaSet$work_runtime_release() || Build.VERSION.SDK_INT < 23 || !(getWorkSpec$work_runtime_release()).constraints.requiresDeviceIdle()) {
        bool = true;
      } else {
        bool = false;
      } 
      if (bool) {
        if (((getWorkSpec$work_runtime_release()).expedited ^ true) != 0)
          return new PeriodicWorkRequest(this); 
        throw new IllegalArgumentException("PeriodicWorkRequests cannot be expedited".toString());
      } 
      throw new IllegalArgumentException("Cannot set backoff criteria on an idle mode job".toString());
    }
    
    public Builder getThisObject$work_runtime_release() {
      return this;
    }
  }
  
  @Metadata(d1 = {"\000\024\n\002\030\002\n\002\020\000\n\002\b\002\n\002\020\t\n\002\b\002\b\003\030\0002\0020\001B\007\b\002¢\006\002\020\002R\020\020\003\032\0020\0048\006XT¢\006\002\n\000R\020\020\005\032\0020\0048\006XT¢\006\002\n\000¨\006\006"}, d2 = {"Landroidx/work/PeriodicWorkRequest$Companion;", "", "()V", "MIN_PERIODIC_FLEX_MILLIS", "", "MIN_PERIODIC_INTERVAL_MILLIS", "work-runtime_release"}, k = 1, mv = {1, 7, 1}, xi = 48)
  public static final class Companion {
    private Companion() {}
  }
}


/* Location:              C:\soft\dex2jar-2.0\MagicAI - AI Art & Anime Art-dex2jar.jar!\androidx\work\PeriodicWorkRequest.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */