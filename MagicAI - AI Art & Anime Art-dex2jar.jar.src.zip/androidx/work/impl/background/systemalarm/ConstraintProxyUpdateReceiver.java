package androidx.work.impl.background.systemalarm;

import android.content.BroadcastReceiver;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.work.Logger;
import androidx.work.impl.WorkManagerImpl;
import androidx.work.impl.utils.PackageManagerHelper;

public class ConstraintProxyUpdateReceiver extends BroadcastReceiver {
  static final String ACTION = "androidx.work.impl.background.systemalarm.UpdateProxies";
  
  static final String KEY_BATTERY_CHARGING_PROXY_ENABLED = "KEY_BATTERY_CHARGING_PROXY_ENABLED";
  
  static final String KEY_BATTERY_NOT_LOW_PROXY_ENABLED = "KEY_BATTERY_NOT_LOW_PROXY_ENABLED";
  
  static final String KEY_NETWORK_STATE_PROXY_ENABLED = "KEY_NETWORK_STATE_PROXY_ENABLED";
  
  static final String KEY_STORAGE_NOT_LOW_PROXY_ENABLED = "KEY_STORAGE_NOT_LOW_PROXY_ENABLED";
  
  static final String TAG = Logger.tagWithPrefix("ConstrntProxyUpdtRecvr");
  
  @NonNull
  public static Intent newConstraintProxyUpdateIntent(@NonNull Context paramContext, boolean paramBoolean1, boolean paramBoolean2, boolean paramBoolean3, boolean paramBoolean4) {
    Intent intent = new Intent("androidx.work.impl.background.systemalarm.UpdateProxies");
    intent.setComponent(new ComponentName(paramContext, ConstraintProxyUpdateReceiver.class));
    intent.putExtra("KEY_BATTERY_NOT_LOW_PROXY_ENABLED", paramBoolean1).putExtra("KEY_BATTERY_CHARGING_PROXY_ENABLED", paramBoolean2).putExtra("KEY_STORAGE_NOT_LOW_PROXY_ENABLED", paramBoolean3).putExtra("KEY_NETWORK_STATE_PROXY_ENABLED", paramBoolean4);
    return intent;
  }
  
  public void onReceive(@NonNull Context paramContext, @Nullable Intent paramIntent) {
    final Logger context;
    final String intent;
    String str2;
    if (paramIntent != null) {
      str2 = paramIntent.getAction();
    } else {
      str2 = null;
    } 
    if (!"androidx.work.impl.background.systemalarm.UpdateProxies".equals(str2)) {
      logger = Logger.get();
      str1 = TAG;
      StringBuilder stringBuilder = new StringBuilder();
      stringBuilder.append("Ignoring unknown action ");
      stringBuilder.append(str2);
      logger.debug(str1, stringBuilder.toString());
      return;
    } 
    final BroadcastReceiver.PendingResult pendingResult = goAsync();
    WorkManagerImpl.getInstance((Context)logger).getWorkTaskExecutor().executeOnTaskThread(new Runnable() {
          public void run() {
            try {
              boolean bool1 = intent.getBooleanExtra("KEY_BATTERY_NOT_LOW_PROXY_ENABLED", false);
              boolean bool2 = intent.getBooleanExtra("KEY_BATTERY_CHARGING_PROXY_ENABLED", false);
              boolean bool3 = intent.getBooleanExtra("KEY_STORAGE_NOT_LOW_PROXY_ENABLED", false);
              boolean bool4 = intent.getBooleanExtra("KEY_NETWORK_STATE_PROXY_ENABLED", false);
              StringBuilder stringBuilder = new StringBuilder();
              stringBuilder.append("Updating proxies: (BatteryNotLowProxy (");
              stringBuilder.append(bool1);
              stringBuilder.append("), BatteryChargingProxy (");
              stringBuilder.append(bool2);
              stringBuilder.append("), StorageNotLowProxy (");
              stringBuilder.append(bool3);
              stringBuilder.append("), NetworkStateProxy (");
              stringBuilder.append(bool4);
              stringBuilder.append("), ");
              String str = stringBuilder.toString();
              Logger.get().debug(ConstraintProxyUpdateReceiver.TAG, str);
              PackageManagerHelper.setComponentEnabled(context, ConstraintProxy.BatteryNotLowProxy.class, bool1);
              PackageManagerHelper.setComponentEnabled(context, ConstraintProxy.BatteryChargingProxy.class, bool2);
              PackageManagerHelper.setComponentEnabled(context, ConstraintProxy.StorageNotLowProxy.class, bool3);
              PackageManagerHelper.setComponentEnabled(context, ConstraintProxy.NetworkStateProxy.class, bool4);
              return;
            } finally {
              pendingResult.finish();
            } 
          }
        });
  }
}


/* Location:              C:\soft\dex2jar-2.0\MagicAI - AI Art & Anime Art-dex2jar.jar!\androidx\work\impl\background\systemalarm\ConstraintProxyUpdateReceiver.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */