package androidx.work.impl.background.systemalarm;

import android.app.AlarmManager;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.os.Build;
import androidx.annotation.DoNotInline;
import androidx.annotation.NonNull;
import androidx.annotation.RequiresApi;
import androidx.annotation.RestrictTo;
import androidx.work.Logger;
import androidx.work.impl.WorkDatabase;
import androidx.work.impl.model.SystemIdInfo;
import androidx.work.impl.model.SystemIdInfoDao;
import androidx.work.impl.model.SystemIdInfoKt;
import androidx.work.impl.model.WorkGenerationalId;
import androidx.work.impl.utils.IdGenerator;

@RestrictTo({RestrictTo.Scope.LIBRARY_GROUP})
class Alarms {
  private static final String TAG = Logger.tagWithPrefix("Alarms");
  
  public static void cancelAlarm(@NonNull Context paramContext, @NonNull WorkDatabase paramWorkDatabase, @NonNull WorkGenerationalId paramWorkGenerationalId) {
    SystemIdInfoDao systemIdInfoDao = paramWorkDatabase.systemIdInfoDao();
    SystemIdInfo systemIdInfo = systemIdInfoDao.getSystemIdInfo(paramWorkGenerationalId);
    if (systemIdInfo != null) {
      cancelExactAlarm(paramContext, paramWorkGenerationalId, systemIdInfo.systemId);
      Logger logger = Logger.get();
      String str = TAG;
      StringBuilder stringBuilder = new StringBuilder();
      stringBuilder.append("Removing SystemIdInfo for workSpecId (");
      stringBuilder.append(paramWorkGenerationalId);
      stringBuilder.append(")");
      logger.debug(str, stringBuilder.toString());
      systemIdInfoDao.removeSystemIdInfo(paramWorkGenerationalId);
    } 
  }
  
  private static void cancelExactAlarm(@NonNull Context paramContext, @NonNull WorkGenerationalId paramWorkGenerationalId, int paramInt) {
    int i;
    AlarmManager alarmManager = (AlarmManager)paramContext.getSystemService("alarm");
    Intent intent = CommandHandler.createDelayMetIntent(paramContext, paramWorkGenerationalId);
    if (Build.VERSION.SDK_INT >= 23) {
      i = 603979776;
    } else {
      i = 536870912;
    } 
    PendingIntent pendingIntent = PendingIntent.getService(paramContext, paramInt, intent, i);
    if (pendingIntent != null && alarmManager != null) {
      Logger logger = Logger.get();
      String str = TAG;
      StringBuilder stringBuilder = new StringBuilder();
      stringBuilder.append("Cancelling existing alarm with (workSpecId, systemId) (");
      stringBuilder.append(paramWorkGenerationalId);
      stringBuilder.append(", ");
      stringBuilder.append(paramInt);
      stringBuilder.append(")");
      logger.debug(str, stringBuilder.toString());
      alarmManager.cancel(pendingIntent);
    } 
  }
  
  public static void setAlarm(@NonNull Context paramContext, @NonNull WorkDatabase paramWorkDatabase, @NonNull WorkGenerationalId paramWorkGenerationalId, long paramLong) {
    SystemIdInfoDao systemIdInfoDao = paramWorkDatabase.systemIdInfoDao();
    SystemIdInfo systemIdInfo = systemIdInfoDao.getSystemIdInfo(paramWorkGenerationalId);
    if (systemIdInfo != null) {
      cancelExactAlarm(paramContext, paramWorkGenerationalId, systemIdInfo.systemId);
      setExactAlarm(paramContext, paramWorkGenerationalId, systemIdInfo.systemId, paramLong);
      return;
    } 
    int i = (new IdGenerator(paramWorkDatabase)).nextAlarmManagerId();
    systemIdInfoDao.insertSystemIdInfo(SystemIdInfoKt.systemIdInfo(paramWorkGenerationalId, i));
    setExactAlarm(paramContext, paramWorkGenerationalId, i, paramLong);
  }
  
  private static void setExactAlarm(@NonNull Context paramContext, @NonNull WorkGenerationalId paramWorkGenerationalId, int paramInt, long paramLong) {
    int i;
    AlarmManager alarmManager = (AlarmManager)paramContext.getSystemService("alarm");
    if (Build.VERSION.SDK_INT >= 23) {
      i = 201326592;
    } else {
      i = 134217728;
    } 
    PendingIntent pendingIntent = PendingIntent.getService(paramContext, paramInt, CommandHandler.createDelayMetIntent(paramContext, paramWorkGenerationalId), i);
    if (alarmManager != null)
      Api19Impl.setExact(alarmManager, 0, paramLong, pendingIntent); 
  }
  
  @RequiresApi(19)
  static class Api19Impl {
    @DoNotInline
    static void setExact(AlarmManager param1AlarmManager, int param1Int, long param1Long, PendingIntent param1PendingIntent) {
      param1AlarmManager.setExact(param1Int, param1Long, param1PendingIntent);
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\MagicAI - AI Art & Anime Art-dex2jar.jar!\androidx\work\impl\background\systemalarm\Alarms.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */