package androidx.work.impl.model;

import android.database.Cursor;
import androidx.collection.ArrayMap;
import androidx.lifecycle.LiveData;
import androidx.room.EntityDeletionOrUpdateAdapter;
import androidx.room.EntityInsertionAdapter;
import androidx.room.InvalidationTracker;
import androidx.room.RoomDatabase;
import androidx.room.RoomSQLiteQuery;
import androidx.room.SharedSQLiteStatement;
import androidx.room.util.CursorUtil;
import androidx.room.util.DBUtil;
import androidx.room.util.StringUtil;
import androidx.sqlite.db.SupportSQLiteQuery;
import androidx.sqlite.db.SupportSQLiteStatement;
import androidx.work.BackoffPolicy;
import androidx.work.Constraints;
import androidx.work.Data;
import androidx.work.NetworkType;
import androidx.work.OutOfQuotaPolicy;
import androidx.work.WorkInfo;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Iterator;
import java.util.List;
import java.util.Set;
import java.util.concurrent.Callable;

public final class WorkSpecDao_Impl implements WorkSpecDao {
  private final RoomDatabase __db;
  
  private final EntityInsertionAdapter<WorkSpec> __insertionAdapterOfWorkSpec;
  
  private final SharedSQLiteStatement __preparedStmtOfDelete;
  
  private final SharedSQLiteStatement __preparedStmtOfIncrementGeneration;
  
  private final SharedSQLiteStatement __preparedStmtOfIncrementPeriodCount;
  
  private final SharedSQLiteStatement __preparedStmtOfIncrementWorkSpecRunAttemptCount;
  
  private final SharedSQLiteStatement __preparedStmtOfMarkWorkSpecScheduled;
  
  private final SharedSQLiteStatement __preparedStmtOfPruneFinishedWorkWithZeroDependentsIgnoringKeepForAtLeast;
  
  private final SharedSQLiteStatement __preparedStmtOfResetScheduledState;
  
  private final SharedSQLiteStatement __preparedStmtOfResetWorkSpecRunAttemptCount;
  
  private final SharedSQLiteStatement __preparedStmtOfSetLastEnqueuedTime;
  
  private final SharedSQLiteStatement __preparedStmtOfSetOutput;
  
  private final SharedSQLiteStatement __preparedStmtOfSetState;
  
  private final EntityDeletionOrUpdateAdapter<WorkSpec> __updateAdapterOfWorkSpec;
  
  public WorkSpecDao_Impl(RoomDatabase paramRoomDatabase) {
    this.__db = paramRoomDatabase;
    this.__insertionAdapterOfWorkSpec = new EntityInsertionAdapter<WorkSpec>(paramRoomDatabase) {
        public void bind(SupportSQLiteStatement param1SupportSQLiteStatement, WorkSpec param1WorkSpec) {
          throw new RuntimeException("d2j fail translate: java.lang.RuntimeException: can not merge I and Z\r\n\tat com.googlecode.dex2jar.ir.TypeClass.merge(TypeClass.java:100)\r\n\tat com.googlecode.dex2jar.ir.ts.TypeTransformer$TypeRef.updateTypeClass(TypeTransformer.java:174)\r\n\tat com.googlecode.dex2jar.ir.ts.TypeTransformer$TypeAnalyze.provideAs(TypeTransformer.java:780)\r\n\tat com.googlecode.dex2jar.ir.ts.TypeTransformer$TypeAnalyze.e1expr(TypeTransformer.java:496)\r\n\tat com.googlecode.dex2jar.ir.ts.TypeTransformer$TypeAnalyze.exExpr(TypeTransformer.java:713)\r\n\tat com.googlecode.dex2jar.ir.ts.TypeTransformer$TypeAnalyze.exExpr(TypeTransformer.java:703)\r\n\tat com.googlecode.dex2jar.ir.ts.TypeTransformer$TypeAnalyze.e1expr(TypeTransformer.java:539)\r\n\tat com.googlecode.dex2jar.ir.ts.TypeTransformer$TypeAnalyze.exExpr(TypeTransformer.java:713)\r\n\tat com.googlecode.dex2jar.ir.ts.TypeTransformer$TypeAnalyze.exExpr(TypeTransformer.java:703)\r\n\tat com.googlecode.dex2jar.ir.ts.TypeTransformer$TypeAnalyze.enexpr(TypeTransformer.java:698)\r\n\tat com.googlecode.dex2jar.ir.ts.TypeTransformer$TypeAnalyze.exExpr(TypeTransformer.java:719)\r\n\tat com.googlecode.dex2jar.ir.ts.TypeTransformer$TypeAnalyze.exExpr(TypeTransformer.java:703)\r\n\tat com.googlecode.dex2jar.ir.ts.TypeTransformer$TypeAnalyze.s1stmt(TypeTransformer.java:810)\r\n\tat com.googlecode.dex2jar.ir.ts.TypeTransformer$TypeAnalyze.sxStmt(TypeTransformer.java:840)\r\n\tat com.googlecode.dex2jar.ir.ts.TypeTransformer$TypeAnalyze.analyze(TypeTransformer.java:206)\r\n\tat com.googlecode.dex2jar.ir.ts.TypeTransformer.transform(TypeTransformer.java:44)\r\n\tat com.googlecode.d2j.dex.Dex2jar$2.optimize(Dex2jar.java:162)\r\n\tat com.googlecode.d2j.dex.Dex2Asm.convertCode(Dex2Asm.java:414)\r\n\tat com.googlecode.d2j.dex.ExDex2Asm.convertCode(ExDex2Asm.java:42)\r\n\tat com.googlecode.d2j.dex.Dex2jar$2.convertCode(Dex2jar.java:128)\r\n\tat com.googlecode.d2j.dex.Dex2Asm.convertMethod(Dex2Asm.java:509)\r\n\tat com.googlecode.d2j.dex.Dex2Asm.convertClass(Dex2Asm.java:406)\r\n\tat com.googlecode.d2j.dex.Dex2Asm.convertDex(Dex2Asm.java:422)\r\n\tat com.googlecode.d2j.dex.Dex2jar.doTranslate(Dex2jar.java:172)\r\n\tat com.googlecode.d2j.dex.Dex2jar.to(Dex2jar.java:272)\r\n\tat com.googlecode.dex2jar.tools.Dex2jarCmd.doCommandLine(Dex2jarCmd.java:108)\r\n\tat com.googlecode.dex2jar.tools.BaseCmd.doMain(BaseCmd.java:288)\r\n\tat com.googlecode.dex2jar.tools.Dex2jarCmd.main(Dex2jarCmd.java:32)\r\n");
        }
        
        public String createQuery() {
          return "INSERT OR IGNORE INTO `WorkSpec` (`id`,`state`,`worker_class_name`,`input_merger_class_name`,`input`,`output`,`initial_delay`,`interval_duration`,`flex_duration`,`run_attempt_count`,`backoff_policy`,`backoff_delay_duration`,`last_enqueue_time`,`minimum_retention_duration`,`schedule_requested_at`,`run_in_foreground`,`out_of_quota_policy`,`period_count`,`generation`,`required_network_type`,`requires_charging`,`requires_device_idle`,`requires_battery_not_low`,`requires_storage_not_low`,`trigger_content_update_delay`,`trigger_max_content_delay`,`content_uri_triggers`) VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)";
        }
      };
    this.__updateAdapterOfWorkSpec = new EntityDeletionOrUpdateAdapter<WorkSpec>(paramRoomDatabase) {
        public void bind(SupportSQLiteStatement param1SupportSQLiteStatement, WorkSpec param1WorkSpec) {
          throw new RuntimeException("d2j fail translate: java.lang.RuntimeException: can not merge I and Z\r\n\tat com.googlecode.dex2jar.ir.TypeClass.merge(TypeClass.java:100)\r\n\tat com.googlecode.dex2jar.ir.ts.TypeTransformer$TypeRef.updateTypeClass(TypeTransformer.java:174)\r\n\tat com.googlecode.dex2jar.ir.ts.TypeTransformer$TypeAnalyze.provideAs(TypeTransformer.java:780)\r\n\tat com.googlecode.dex2jar.ir.ts.TypeTransformer$TypeAnalyze.e1expr(TypeTransformer.java:496)\r\n\tat com.googlecode.dex2jar.ir.ts.TypeTransformer$TypeAnalyze.exExpr(TypeTransformer.java:713)\r\n\tat com.googlecode.dex2jar.ir.ts.TypeTransformer$TypeAnalyze.exExpr(TypeTransformer.java:703)\r\n\tat com.googlecode.dex2jar.ir.ts.TypeTransformer$TypeAnalyze.e1expr(TypeTransformer.java:539)\r\n\tat com.googlecode.dex2jar.ir.ts.TypeTransformer$TypeAnalyze.exExpr(TypeTransformer.java:713)\r\n\tat com.googlecode.dex2jar.ir.ts.TypeTransformer$TypeAnalyze.exExpr(TypeTransformer.java:703)\r\n\tat com.googlecode.dex2jar.ir.ts.TypeTransformer$TypeAnalyze.enexpr(TypeTransformer.java:698)\r\n\tat com.googlecode.dex2jar.ir.ts.TypeTransformer$TypeAnalyze.exExpr(TypeTransformer.java:719)\r\n\tat com.googlecode.dex2jar.ir.ts.TypeTransformer$TypeAnalyze.exExpr(TypeTransformer.java:703)\r\n\tat com.googlecode.dex2jar.ir.ts.TypeTransformer$TypeAnalyze.s1stmt(TypeTransformer.java:810)\r\n\tat com.googlecode.dex2jar.ir.ts.TypeTransformer$TypeAnalyze.sxStmt(TypeTransformer.java:840)\r\n\tat com.googlecode.dex2jar.ir.ts.TypeTransformer$TypeAnalyze.analyze(TypeTransformer.java:206)\r\n\tat com.googlecode.dex2jar.ir.ts.TypeTransformer.transform(TypeTransformer.java:44)\r\n\tat com.googlecode.d2j.dex.Dex2jar$2.optimize(Dex2jar.java:162)\r\n\tat com.googlecode.d2j.dex.Dex2Asm.convertCode(Dex2Asm.java:414)\r\n\tat com.googlecode.d2j.dex.ExDex2Asm.convertCode(ExDex2Asm.java:42)\r\n\tat com.googlecode.d2j.dex.Dex2jar$2.convertCode(Dex2jar.java:128)\r\n\tat com.googlecode.d2j.dex.Dex2Asm.convertMethod(Dex2Asm.java:509)\r\n\tat com.googlecode.d2j.dex.Dex2Asm.convertClass(Dex2Asm.java:406)\r\n\tat com.googlecode.d2j.dex.Dex2Asm.convertDex(Dex2Asm.java:422)\r\n\tat com.googlecode.d2j.dex.Dex2jar.doTranslate(Dex2jar.java:172)\r\n\tat com.googlecode.d2j.dex.Dex2jar.to(Dex2jar.java:272)\r\n\tat com.googlecode.dex2jar.tools.Dex2jarCmd.doCommandLine(Dex2jarCmd.java:108)\r\n\tat com.googlecode.dex2jar.tools.BaseCmd.doMain(BaseCmd.java:288)\r\n\tat com.googlecode.dex2jar.tools.Dex2jarCmd.main(Dex2jarCmd.java:32)\r\n");
        }
        
        public String createQuery() {
          return "UPDATE OR ABORT `WorkSpec` SET `id` = ?,`state` = ?,`worker_class_name` = ?,`input_merger_class_name` = ?,`input` = ?,`output` = ?,`initial_delay` = ?,`interval_duration` = ?,`flex_duration` = ?,`run_attempt_count` = ?,`backoff_policy` = ?,`backoff_delay_duration` = ?,`last_enqueue_time` = ?,`minimum_retention_duration` = ?,`schedule_requested_at` = ?,`run_in_foreground` = ?,`out_of_quota_policy` = ?,`period_count` = ?,`generation` = ?,`required_network_type` = ?,`requires_charging` = ?,`requires_device_idle` = ?,`requires_battery_not_low` = ?,`requires_storage_not_low` = ?,`trigger_content_update_delay` = ?,`trigger_max_content_delay` = ?,`content_uri_triggers` = ? WHERE `id` = ?";
        }
      };
    this.__preparedStmtOfDelete = new SharedSQLiteStatement(paramRoomDatabase) {
        public String createQuery() {
          return "DELETE FROM workspec WHERE id=?";
        }
      };
    this.__preparedStmtOfSetState = new SharedSQLiteStatement(paramRoomDatabase) {
        public String createQuery() {
          return "UPDATE workspec SET state=? WHERE id=?";
        }
      };
    this.__preparedStmtOfIncrementPeriodCount = new SharedSQLiteStatement(paramRoomDatabase) {
        public String createQuery() {
          return "UPDATE workspec SET period_count=period_count+1 WHERE id=?";
        }
      };
    this.__preparedStmtOfSetOutput = new SharedSQLiteStatement(paramRoomDatabase) {
        public String createQuery() {
          return "UPDATE workspec SET output=? WHERE id=?";
        }
      };
    this.__preparedStmtOfSetLastEnqueuedTime = new SharedSQLiteStatement(paramRoomDatabase) {
        public String createQuery() {
          return "UPDATE workspec SET last_enqueue_time=? WHERE id=?";
        }
      };
    this.__preparedStmtOfIncrementWorkSpecRunAttemptCount = new SharedSQLiteStatement(paramRoomDatabase) {
        public String createQuery() {
          return "UPDATE workspec SET run_attempt_count=run_attempt_count+1 WHERE id=?";
        }
      };
    this.__preparedStmtOfResetWorkSpecRunAttemptCount = new SharedSQLiteStatement(paramRoomDatabase) {
        public String createQuery() {
          return "UPDATE workspec SET run_attempt_count=0 WHERE id=?";
        }
      };
    this.__preparedStmtOfMarkWorkSpecScheduled = new SharedSQLiteStatement(paramRoomDatabase) {
        public String createQuery() {
          return "UPDATE workspec SET schedule_requested_at=? WHERE id=?";
        }
      };
    this.__preparedStmtOfResetScheduledState = new SharedSQLiteStatement(paramRoomDatabase) {
        public String createQuery() {
          return "UPDATE workspec SET schedule_requested_at=-1 WHERE state NOT IN (2, 3, 5)";
        }
      };
    this.__preparedStmtOfPruneFinishedWorkWithZeroDependentsIgnoringKeepForAtLeast = new SharedSQLiteStatement(paramRoomDatabase) {
        public String createQuery() {
          return "DELETE FROM workspec WHERE state IN (2, 3, 5) AND (SELECT COUNT(*)=0 FROM dependency WHERE     prerequisite_id=id AND     work_spec_id NOT IN         (SELECT id FROM workspec WHERE state IN (2, 3, 5)))";
        }
      };
    this.__preparedStmtOfIncrementGeneration = new SharedSQLiteStatement(paramRoomDatabase) {
        public String createQuery() {
          return "UPDATE workspec SET generation=generation+1 WHERE id=?";
        }
      };
  }
  
  private void __fetchRelationshipWorkProgressAsandroidxWorkData(ArrayMap<String, ArrayList<Data>> paramArrayMap) {
    Set set = paramArrayMap.keySet();
    if (set.isEmpty())
      return; 
    if (paramArrayMap.size() > 999) {
      ArrayMap<String, ArrayList<Data>> arrayMap = new ArrayMap(999);
      int k = paramArrayMap.size();
      int j = 0;
      while (true) {
        int m = 0;
        while (j < k) {
          arrayMap.put(paramArrayMap.keyAt(j), paramArrayMap.valueAt(j));
          int n = j + 1;
          int i1 = m + 1;
          j = n;
          m = i1;
          if (i1 == 999) {
            __fetchRelationshipWorkProgressAsandroidxWorkData(arrayMap);
            arrayMap = new ArrayMap(999);
            j = n;
          } 
        } 
        if (m > 0)
          __fetchRelationshipWorkProgressAsandroidxWorkData(arrayMap); 
        return;
      } 
    } 
    StringBuilder stringBuilder = StringUtil.newStringBuilder();
    stringBuilder.append("SELECT `progress`,`work_spec_id` FROM `WorkProgress` WHERE `work_spec_id` IN (");
    int i = set.size();
    StringUtil.appendPlaceholders(stringBuilder, i);
    stringBuilder.append(")");
    RoomSQLiteQuery roomSQLiteQuery = RoomSQLiteQuery.acquire(stringBuilder.toString(), i + 0);
    Iterator<String> iterator = set.iterator();
    for (i = 1; iterator.hasNext(); i++) {
      String str = iterator.next();
      if (str == null) {
        roomSQLiteQuery.bindNull(i);
      } else {
        roomSQLiteQuery.bindString(i, str);
      } 
    } 
    Cursor cursor = DBUtil.query(this.__db, (SupportSQLiteQuery)roomSQLiteQuery, false, null);
    try {
      i = CursorUtil.getColumnIndex(cursor, "work_spec_id");
      if (i == -1)
        return; 
      while (cursor.moveToNext()) {
        ArrayList<Data> arrayList = (ArrayList)paramArrayMap.get(cursor.getString(i));
        if (arrayList != null) {
          byte[] arrayOfByte;
          if (cursor.isNull(0)) {
            roomSQLiteQuery = null;
          } else {
            arrayOfByte = cursor.getBlob(0);
          } 
          arrayList.add(Data.fromByteArray(arrayOfByte));
        } 
      } 
      return;
    } finally {
      cursor.close();
    } 
  }
  
  private void __fetchRelationshipWorkTagAsjavaLangString(ArrayMap<String, ArrayList<String>> paramArrayMap) {
    Set set = paramArrayMap.keySet();
    if (set.isEmpty())
      return; 
    if (paramArrayMap.size() > 999) {
      ArrayMap<String, ArrayList<String>> arrayMap = new ArrayMap(999);
      int k = paramArrayMap.size();
      int j = 0;
      while (true) {
        int m = 0;
        while (j < k) {
          arrayMap.put(paramArrayMap.keyAt(j), paramArrayMap.valueAt(j));
          int n = j + 1;
          int i1 = m + 1;
          j = n;
          m = i1;
          if (i1 == 999) {
            __fetchRelationshipWorkTagAsjavaLangString(arrayMap);
            arrayMap = new ArrayMap(999);
            j = n;
          } 
        } 
        if (m > 0)
          __fetchRelationshipWorkTagAsjavaLangString(arrayMap); 
        return;
      } 
    } 
    StringBuilder stringBuilder = StringUtil.newStringBuilder();
    stringBuilder.append("SELECT `tag`,`work_spec_id` FROM `WorkTag` WHERE `work_spec_id` IN (");
    int i = set.size();
    StringUtil.appendPlaceholders(stringBuilder, i);
    stringBuilder.append(")");
    RoomSQLiteQuery roomSQLiteQuery = RoomSQLiteQuery.acquire(stringBuilder.toString(), i + 0);
    Iterator<String> iterator = set.iterator();
    for (i = 1; iterator.hasNext(); i++) {
      String str = iterator.next();
      if (str == null) {
        roomSQLiteQuery.bindNull(i);
      } else {
        roomSQLiteQuery.bindString(i, str);
      } 
    } 
    Cursor cursor = DBUtil.query(this.__db, (SupportSQLiteQuery)roomSQLiteQuery, false, null);
    try {
      i = CursorUtil.getColumnIndex(cursor, "work_spec_id");
      if (i == -1)
        return; 
      while (cursor.moveToNext()) {
        ArrayList<String> arrayList = (ArrayList)paramArrayMap.get(cursor.getString(i));
        if (arrayList != null) {
          String str;
          if (cursor.isNull(0)) {
            roomSQLiteQuery = null;
          } else {
            str = cursor.getString(0);
          } 
          arrayList.add(str);
        } 
      } 
      return;
    } finally {
      cursor.close();
    } 
  }
  
  public static List<Class<?>> getRequiredConverters() {
    return Collections.emptyList();
  }
  
  public void delete(String paramString) {
    this.__db.assertNotSuspendingTransaction();
    SupportSQLiteStatement supportSQLiteStatement = this.__preparedStmtOfDelete.acquire();
    if (paramString == null) {
      supportSQLiteStatement.bindNull(1);
    } else {
      supportSQLiteStatement.bindString(1, paramString);
    } 
    this.__db.beginTransaction();
    try {
      supportSQLiteStatement.executeUpdateDelete();
      this.__db.setTransactionSuccessful();
      return;
    } finally {
      this.__db.endTransaction();
      this.__preparedStmtOfDelete.release(supportSQLiteStatement);
    } 
  }
  
  public List<WorkSpec> getAllEligibleWorkSpecsForScheduling(int paramInt) {
    Exception exception;
    RoomSQLiteQuery roomSQLiteQuery = RoomSQLiteQuery.acquire("SELECT * FROM workspec WHERE state=0 ORDER BY last_enqueue_time LIMIT ?", 1);
    roomSQLiteQuery.bindLong(1, paramInt);
    this.__db.assertNotSuspendingTransaction();
    Cursor cursor = DBUtil.query(this.__db, (SupportSQLiteQuery)roomSQLiteQuery, false, null);
    try {
      int j = CursorUtil.getColumnIndexOrThrow(cursor, "id");
      int k = CursorUtil.getColumnIndexOrThrow(cursor, "state");
      int m = CursorUtil.getColumnIndexOrThrow(cursor, "worker_class_name");
      int n = CursorUtil.getColumnIndexOrThrow(cursor, "input_merger_class_name");
      int i1 = CursorUtil.getColumnIndexOrThrow(cursor, "input");
      int i2 = CursorUtil.getColumnIndexOrThrow(cursor, "output");
      int i3 = CursorUtil.getColumnIndexOrThrow(cursor, "initial_delay");
      int i4 = CursorUtil.getColumnIndexOrThrow(cursor, "interval_duration");
      int i5 = CursorUtil.getColumnIndexOrThrow(cursor, "flex_duration");
      int i6 = CursorUtil.getColumnIndexOrThrow(cursor, "run_attempt_count");
      int i7 = CursorUtil.getColumnIndexOrThrow(cursor, "backoff_policy");
      int i8 = CursorUtil.getColumnIndexOrThrow(cursor, "backoff_delay_duration");
      int i9 = CursorUtil.getColumnIndexOrThrow(cursor, "last_enqueue_time");
      int i = CursorUtil.getColumnIndexOrThrow(cursor, "minimum_retention_duration");
      try {
        int i21 = CursorUtil.getColumnIndexOrThrow(cursor, "schedule_requested_at");
        int i20 = CursorUtil.getColumnIndexOrThrow(cursor, "run_in_foreground");
        int i13 = CursorUtil.getColumnIndexOrThrow(cursor, "out_of_quota_policy");
        int i19 = CursorUtil.getColumnIndexOrThrow(cursor, "period_count");
        int i18 = CursorUtil.getColumnIndexOrThrow(cursor, "generation");
        int i17 = CursorUtil.getColumnIndexOrThrow(cursor, "required_network_type");
        int i16 = CursorUtil.getColumnIndexOrThrow(cursor, "requires_charging");
        int i12 = CursorUtil.getColumnIndexOrThrow(cursor, "requires_device_idle");
        int i11 = CursorUtil.getColumnIndexOrThrow(cursor, "requires_battery_not_low");
        int i10 = CursorUtil.getColumnIndexOrThrow(cursor, "requires_storage_not_low");
        paramInt = CursorUtil.getColumnIndexOrThrow(cursor, "trigger_content_update_delay");
        int i15 = CursorUtil.getColumnIndexOrThrow(cursor, "trigger_max_content_delay");
        int i14 = CursorUtil.getColumnIndexOrThrow(cursor, "content_uri_triggers");
        ArrayList<WorkSpec> arrayList = new ArrayList(cursor.getCount());
        while (true) {
          if (cursor.moveToNext()) {
            boolean bool1;
            boolean bool2;
            boolean bool3;
            boolean bool4;
            boolean bool5;
            String str1;
            String str2;
            String str3;
            byte[] arrayOfByte;
            if (cursor.isNull(j)) {
              str1 = null;
            } else {
              str1 = cursor.getString(j);
            } 
            WorkInfo.State state = WorkTypeConverters.intToState(cursor.getInt(k));
            if (cursor.isNull(m)) {
              str2 = null;
            } else {
              str2 = cursor.getString(m);
            } 
            if (cursor.isNull(n)) {
              str3 = null;
            } else {
              str3 = cursor.getString(n);
            } 
            if (cursor.isNull(i1)) {
              arrayOfByte = null;
            } else {
              arrayOfByte = cursor.getBlob(i1);
            } 
            Data data1 = Data.fromByteArray(arrayOfByte);
            if (cursor.isNull(i2)) {
              arrayOfByte = null;
            } else {
              arrayOfByte = cursor.getBlob(i2);
            } 
            Data data2 = Data.fromByteArray(arrayOfByte);
            long l1 = cursor.getLong(i3);
            long l2 = cursor.getLong(i4);
            long l3 = cursor.getLong(i5);
            int i22 = cursor.getInt(i6);
            BackoffPolicy backoffPolicy = WorkTypeConverters.intToBackoffPolicy(cursor.getInt(i7));
            long l4 = cursor.getLong(i8);
            long l5 = cursor.getLong(i9);
            long l6 = cursor.getLong(i);
            long l7 = cursor.getLong(i21);
            if (cursor.getInt(i20) != 0) {
              bool1 = true;
            } else {
              bool1 = false;
            } 
            OutOfQuotaPolicy outOfQuotaPolicy = WorkTypeConverters.intToOutOfQuotaPolicy(cursor.getInt(i13));
            int i23 = cursor.getInt(i19);
            int i24 = cursor.getInt(i18);
            NetworkType networkType = WorkTypeConverters.intToNetworkType(cursor.getInt(i17));
            if (cursor.getInt(i16) != 0) {
              bool2 = true;
            } else {
              bool2 = false;
            } 
            if (cursor.getInt(i12) != 0) {
              bool3 = true;
            } else {
              bool3 = false;
            } 
            if (cursor.getInt(i11) != 0) {
              bool4 = true;
            } else {
              bool4 = false;
            } 
            if (cursor.getInt(i10) != 0) {
              bool5 = true;
            } else {
              bool5 = false;
            } 
            long l8 = cursor.getLong(paramInt);
            long l9 = cursor.getLong(i15);
            if (cursor.isNull(i14)) {
              arrayOfByte = null;
            } else {
              arrayOfByte = cursor.getBlob(i14);
            } 
            Constraints constraints = new Constraints(networkType, bool2, bool3, bool4, bool5, l8, l9, WorkTypeConverters.byteArrayToSetOfTriggers(arrayOfByte));
            arrayList.add(new WorkSpec(str1, state, str2, str3, data1, data2, l1, l2, l3, constraints, i22, backoffPolicy, l4, l5, l6, l7, bool1, outOfQuotaPolicy, i23, i24));
            continue;
          } 
          cursor.close();
          roomSQLiteQuery.release();
          return arrayList;
        } 
      } finally {}
    } finally {}
    cursor.close();
    roomSQLiteQuery.release();
    throw exception;
  }
  
  public List<String> getAllUnfinishedWork() {
    RoomSQLiteQuery roomSQLiteQuery = RoomSQLiteQuery.acquire("SELECT id FROM workspec WHERE state NOT IN (2, 3, 5)", 0);
    this.__db.assertNotSuspendingTransaction();
    Cursor cursor = DBUtil.query(this.__db, (SupportSQLiteQuery)roomSQLiteQuery, false, null);
    try {
      ArrayList<String> arrayList = new ArrayList(cursor.getCount());
      while (cursor.moveToNext()) {
        String str;
        if (cursor.isNull(0)) {
          str = null;
        } else {
          str = cursor.getString(0);
        } 
        arrayList.add(str);
      } 
      return arrayList;
    } finally {
      cursor.close();
      roomSQLiteQuery.release();
    } 
  }
  
  public List<String> getAllWorkSpecIds() {
    RoomSQLiteQuery roomSQLiteQuery = RoomSQLiteQuery.acquire("SELECT id FROM workspec", 0);
    this.__db.assertNotSuspendingTransaction();
    Cursor cursor = DBUtil.query(this.__db, (SupportSQLiteQuery)roomSQLiteQuery, false, null);
    try {
      ArrayList<String> arrayList = new ArrayList(cursor.getCount());
      while (cursor.moveToNext()) {
        String str;
        if (cursor.isNull(0)) {
          str = null;
        } else {
          str = cursor.getString(0);
        } 
        arrayList.add(str);
      } 
      return arrayList;
    } finally {
      cursor.close();
      roomSQLiteQuery.release();
    } 
  }
  
  public LiveData<List<String>> getAllWorkSpecIdsLiveData() {
    final RoomSQLiteQuery _statement = RoomSQLiteQuery.acquire("SELECT id FROM workspec", 0);
    InvalidationTracker invalidationTracker = this.__db.getInvalidationTracker();
    Callable<List<String>> callable = new Callable<List<String>>() {
        public List<String> call() throws Exception {
          WorkSpecDao_Impl.this.__db.beginTransaction();
          try {
            Cursor cursor = DBUtil.query(WorkSpecDao_Impl.this.__db, (SupportSQLiteQuery)_statement, false, null);
          } finally {
            WorkSpecDao_Impl.this.__db.endTransaction();
          } 
        }
        
        protected void finalize() {
          _statement.release();
        }
      };
    return invalidationTracker.createLiveData(new String[] { "workspec" }, true, callable);
  }
  
  public List<WorkSpec> getEligibleWorkForScheduling(int paramInt) {
    Exception exception;
    RoomSQLiteQuery roomSQLiteQuery = RoomSQLiteQuery.acquire("SELECT * FROM workspec WHERE state=0 AND schedule_requested_at=-1 ORDER BY last_enqueue_time LIMIT (SELECT MAX(?-COUNT(*), 0) FROM workspec WHERE schedule_requested_at<>-1 AND state NOT IN (2, 3, 5))", 1);
    roomSQLiteQuery.bindLong(1, paramInt);
    this.__db.assertNotSuspendingTransaction();
    Cursor cursor = DBUtil.query(this.__db, (SupportSQLiteQuery)roomSQLiteQuery, false, null);
    try {
      int j = CursorUtil.getColumnIndexOrThrow(cursor, "id");
      int k = CursorUtil.getColumnIndexOrThrow(cursor, "state");
      int m = CursorUtil.getColumnIndexOrThrow(cursor, "worker_class_name");
      int n = CursorUtil.getColumnIndexOrThrow(cursor, "input_merger_class_name");
      int i1 = CursorUtil.getColumnIndexOrThrow(cursor, "input");
      int i2 = CursorUtil.getColumnIndexOrThrow(cursor, "output");
      int i3 = CursorUtil.getColumnIndexOrThrow(cursor, "initial_delay");
      int i4 = CursorUtil.getColumnIndexOrThrow(cursor, "interval_duration");
      int i5 = CursorUtil.getColumnIndexOrThrow(cursor, "flex_duration");
      int i6 = CursorUtil.getColumnIndexOrThrow(cursor, "run_attempt_count");
      int i7 = CursorUtil.getColumnIndexOrThrow(cursor, "backoff_policy");
      int i8 = CursorUtil.getColumnIndexOrThrow(cursor, "backoff_delay_duration");
      int i9 = CursorUtil.getColumnIndexOrThrow(cursor, "last_enqueue_time");
      int i = CursorUtil.getColumnIndexOrThrow(cursor, "minimum_retention_duration");
      try {
        int i21 = CursorUtil.getColumnIndexOrThrow(cursor, "schedule_requested_at");
        int i20 = CursorUtil.getColumnIndexOrThrow(cursor, "run_in_foreground");
        int i13 = CursorUtil.getColumnIndexOrThrow(cursor, "out_of_quota_policy");
        int i19 = CursorUtil.getColumnIndexOrThrow(cursor, "period_count");
        int i18 = CursorUtil.getColumnIndexOrThrow(cursor, "generation");
        int i17 = CursorUtil.getColumnIndexOrThrow(cursor, "required_network_type");
        int i16 = CursorUtil.getColumnIndexOrThrow(cursor, "requires_charging");
        int i12 = CursorUtil.getColumnIndexOrThrow(cursor, "requires_device_idle");
        int i11 = CursorUtil.getColumnIndexOrThrow(cursor, "requires_battery_not_low");
        int i10 = CursorUtil.getColumnIndexOrThrow(cursor, "requires_storage_not_low");
        paramInt = CursorUtil.getColumnIndexOrThrow(cursor, "trigger_content_update_delay");
        int i15 = CursorUtil.getColumnIndexOrThrow(cursor, "trigger_max_content_delay");
        int i14 = CursorUtil.getColumnIndexOrThrow(cursor, "content_uri_triggers");
        ArrayList<WorkSpec> arrayList = new ArrayList(cursor.getCount());
        while (true) {
          if (cursor.moveToNext()) {
            boolean bool1;
            boolean bool2;
            boolean bool3;
            boolean bool4;
            boolean bool5;
            String str1;
            String str2;
            String str3;
            byte[] arrayOfByte;
            if (cursor.isNull(j)) {
              str1 = null;
            } else {
              str1 = cursor.getString(j);
            } 
            WorkInfo.State state = WorkTypeConverters.intToState(cursor.getInt(k));
            if (cursor.isNull(m)) {
              str2 = null;
            } else {
              str2 = cursor.getString(m);
            } 
            if (cursor.isNull(n)) {
              str3 = null;
            } else {
              str3 = cursor.getString(n);
            } 
            if (cursor.isNull(i1)) {
              arrayOfByte = null;
            } else {
              arrayOfByte = cursor.getBlob(i1);
            } 
            Data data1 = Data.fromByteArray(arrayOfByte);
            if (cursor.isNull(i2)) {
              arrayOfByte = null;
            } else {
              arrayOfByte = cursor.getBlob(i2);
            } 
            Data data2 = Data.fromByteArray(arrayOfByte);
            long l1 = cursor.getLong(i3);
            long l2 = cursor.getLong(i4);
            long l3 = cursor.getLong(i5);
            int i22 = cursor.getInt(i6);
            BackoffPolicy backoffPolicy = WorkTypeConverters.intToBackoffPolicy(cursor.getInt(i7));
            long l4 = cursor.getLong(i8);
            long l5 = cursor.getLong(i9);
            long l6 = cursor.getLong(i);
            long l7 = cursor.getLong(i21);
            if (cursor.getInt(i20) != 0) {
              bool1 = true;
            } else {
              bool1 = false;
            } 
            OutOfQuotaPolicy outOfQuotaPolicy = WorkTypeConverters.intToOutOfQuotaPolicy(cursor.getInt(i13));
            int i23 = cursor.getInt(i19);
            int i24 = cursor.getInt(i18);
            NetworkType networkType = WorkTypeConverters.intToNetworkType(cursor.getInt(i17));
            if (cursor.getInt(i16) != 0) {
              bool2 = true;
            } else {
              bool2 = false;
            } 
            if (cursor.getInt(i12) != 0) {
              bool3 = true;
            } else {
              bool3 = false;
            } 
            if (cursor.getInt(i11) != 0) {
              bool4 = true;
            } else {
              bool4 = false;
            } 
            if (cursor.getInt(i10) != 0) {
              bool5 = true;
            } else {
              bool5 = false;
            } 
            long l8 = cursor.getLong(paramInt);
            long l9 = cursor.getLong(i15);
            if (cursor.isNull(i14)) {
              arrayOfByte = null;
            } else {
              arrayOfByte = cursor.getBlob(i14);
            } 
            Constraints constraints = new Constraints(networkType, bool2, bool3, bool4, bool5, l8, l9, WorkTypeConverters.byteArrayToSetOfTriggers(arrayOfByte));
            arrayList.add(new WorkSpec(str1, state, str2, str3, data1, data2, l1, l2, l3, constraints, i22, backoffPolicy, l4, l5, l6, l7, bool1, outOfQuotaPolicy, i23, i24));
            continue;
          } 
          cursor.close();
          roomSQLiteQuery.release();
          return arrayList;
        } 
      } finally {}
    } finally {}
    cursor.close();
    roomSQLiteQuery.release();
    throw exception;
  }
  
  public List<Data> getInputsFromPrerequisites(String paramString) {
    RoomSQLiteQuery roomSQLiteQuery = RoomSQLiteQuery.acquire("SELECT output FROM workspec WHERE id IN\n             (SELECT prerequisite_id FROM dependency WHERE work_spec_id=?)", 1);
    if (paramString == null) {
      roomSQLiteQuery.bindNull(1);
    } else {
      roomSQLiteQuery.bindString(1, paramString);
    } 
    this.__db.assertNotSuspendingTransaction();
    Cursor cursor = DBUtil.query(this.__db, (SupportSQLiteQuery)roomSQLiteQuery, false, null);
    try {
      ArrayList<Data> arrayList = new ArrayList(cursor.getCount());
      while (cursor.moveToNext()) {
        byte[] arrayOfByte;
        if (cursor.isNull(0)) {
          paramString = null;
        } else {
          arrayOfByte = cursor.getBlob(0);
        } 
        arrayList.add(Data.fromByteArray(arrayOfByte));
      } 
      return arrayList;
    } finally {
      cursor.close();
      roomSQLiteQuery.release();
    } 
  }
  
  public List<WorkSpec> getRecentlyCompletedWork(long paramLong) {
    Exception exception;
    RoomSQLiteQuery roomSQLiteQuery = RoomSQLiteQuery.acquire("SELECT * FROM workspec WHERE last_enqueue_time >= ? AND state IN (2, 3, 5) ORDER BY last_enqueue_time DESC", 1);
    roomSQLiteQuery.bindLong(1, paramLong);
    this.__db.assertNotSuspendingTransaction();
    Cursor cursor = DBUtil.query(this.__db, (SupportSQLiteQuery)roomSQLiteQuery, false, null);
    try {
      int j = CursorUtil.getColumnIndexOrThrow(cursor, "id");
      int k = CursorUtil.getColumnIndexOrThrow(cursor, "state");
      int m = CursorUtil.getColumnIndexOrThrow(cursor, "worker_class_name");
      int n = CursorUtil.getColumnIndexOrThrow(cursor, "input_merger_class_name");
      int i1 = CursorUtil.getColumnIndexOrThrow(cursor, "input");
      int i2 = CursorUtil.getColumnIndexOrThrow(cursor, "output");
      int i3 = CursorUtil.getColumnIndexOrThrow(cursor, "initial_delay");
      int i4 = CursorUtil.getColumnIndexOrThrow(cursor, "interval_duration");
      int i5 = CursorUtil.getColumnIndexOrThrow(cursor, "flex_duration");
      int i6 = CursorUtil.getColumnIndexOrThrow(cursor, "run_attempt_count");
      int i7 = CursorUtil.getColumnIndexOrThrow(cursor, "backoff_policy");
      int i8 = CursorUtil.getColumnIndexOrThrow(cursor, "backoff_delay_duration");
      int i9 = CursorUtil.getColumnIndexOrThrow(cursor, "last_enqueue_time");
      int i = CursorUtil.getColumnIndexOrThrow(cursor, "minimum_retention_duration");
      try {
        int i22 = CursorUtil.getColumnIndexOrThrow(cursor, "schedule_requested_at");
        int i21 = CursorUtil.getColumnIndexOrThrow(cursor, "run_in_foreground");
        int i14 = CursorUtil.getColumnIndexOrThrow(cursor, "out_of_quota_policy");
        int i20 = CursorUtil.getColumnIndexOrThrow(cursor, "period_count");
        int i19 = CursorUtil.getColumnIndexOrThrow(cursor, "generation");
        int i18 = CursorUtil.getColumnIndexOrThrow(cursor, "required_network_type");
        int i17 = CursorUtil.getColumnIndexOrThrow(cursor, "requires_charging");
        int i13 = CursorUtil.getColumnIndexOrThrow(cursor, "requires_device_idle");
        int i12 = CursorUtil.getColumnIndexOrThrow(cursor, "requires_battery_not_low");
        int i11 = CursorUtil.getColumnIndexOrThrow(cursor, "requires_storage_not_low");
        int i10 = CursorUtil.getColumnIndexOrThrow(cursor, "trigger_content_update_delay");
        int i16 = CursorUtil.getColumnIndexOrThrow(cursor, "trigger_max_content_delay");
        int i15 = CursorUtil.getColumnIndexOrThrow(cursor, "content_uri_triggers");
        ArrayList<WorkSpec> arrayList = new ArrayList(cursor.getCount());
        while (true) {
          if (cursor.moveToNext()) {
            boolean bool1;
            boolean bool2;
            boolean bool3;
            boolean bool4;
            boolean bool5;
            String str1;
            String str2;
            String str3;
            byte[] arrayOfByte;
            if (cursor.isNull(j)) {
              str1 = null;
            } else {
              str1 = cursor.getString(j);
            } 
            WorkInfo.State state = WorkTypeConverters.intToState(cursor.getInt(k));
            if (cursor.isNull(m)) {
              str2 = null;
            } else {
              str2 = cursor.getString(m);
            } 
            if (cursor.isNull(n)) {
              str3 = null;
            } else {
              str3 = cursor.getString(n);
            } 
            if (cursor.isNull(i1)) {
              arrayOfByte = null;
            } else {
              arrayOfByte = cursor.getBlob(i1);
            } 
            Data data1 = Data.fromByteArray(arrayOfByte);
            if (cursor.isNull(i2)) {
              arrayOfByte = null;
            } else {
              arrayOfByte = cursor.getBlob(i2);
            } 
            Data data2 = Data.fromByteArray(arrayOfByte);
            paramLong = cursor.getLong(i3);
            long l1 = cursor.getLong(i4);
            long l2 = cursor.getLong(i5);
            int i23 = cursor.getInt(i6);
            BackoffPolicy backoffPolicy = WorkTypeConverters.intToBackoffPolicy(cursor.getInt(i7));
            long l3 = cursor.getLong(i8);
            long l4 = cursor.getLong(i9);
            long l5 = cursor.getLong(i);
            long l6 = cursor.getLong(i22);
            if (cursor.getInt(i21) != 0) {
              bool1 = true;
            } else {
              bool1 = false;
            } 
            OutOfQuotaPolicy outOfQuotaPolicy = WorkTypeConverters.intToOutOfQuotaPolicy(cursor.getInt(i14));
            int i24 = cursor.getInt(i20);
            int i25 = cursor.getInt(i19);
            NetworkType networkType = WorkTypeConverters.intToNetworkType(cursor.getInt(i18));
            if (cursor.getInt(i17) != 0) {
              bool2 = true;
            } else {
              bool2 = false;
            } 
            if (cursor.getInt(i13) != 0) {
              bool3 = true;
            } else {
              bool3 = false;
            } 
            if (cursor.getInt(i12) != 0) {
              bool4 = true;
            } else {
              bool4 = false;
            } 
            if (cursor.getInt(i11) != 0) {
              bool5 = true;
            } else {
              bool5 = false;
            } 
            long l7 = cursor.getLong(i10);
            long l8 = cursor.getLong(i16);
            if (cursor.isNull(i15)) {
              arrayOfByte = null;
            } else {
              arrayOfByte = cursor.getBlob(i15);
            } 
            Constraints constraints = new Constraints(networkType, bool2, bool3, bool4, bool5, l7, l8, WorkTypeConverters.byteArrayToSetOfTriggers(arrayOfByte));
            arrayList.add(new WorkSpec(str1, state, str2, str3, data1, data2, paramLong, l1, l2, constraints, i23, backoffPolicy, l3, l4, l5, l6, bool1, outOfQuotaPolicy, i24, i25));
            continue;
          } 
          cursor.close();
          roomSQLiteQuery.release();
          return arrayList;
        } 
      } finally {}
    } finally {}
    cursor.close();
    roomSQLiteQuery.release();
    throw exception;
  }
  
  public List<WorkSpec> getRunningWork() {
    Exception exception;
    RoomSQLiteQuery roomSQLiteQuery = RoomSQLiteQuery.acquire("SELECT * FROM workspec WHERE state=1", 0);
    this.__db.assertNotSuspendingTransaction();
    Cursor cursor = DBUtil.query(this.__db, (SupportSQLiteQuery)roomSQLiteQuery, false, null);
    try {
      int j = CursorUtil.getColumnIndexOrThrow(cursor, "id");
      int k = CursorUtil.getColumnIndexOrThrow(cursor, "state");
      int m = CursorUtil.getColumnIndexOrThrow(cursor, "worker_class_name");
      int n = CursorUtil.getColumnIndexOrThrow(cursor, "input_merger_class_name");
      int i1 = CursorUtil.getColumnIndexOrThrow(cursor, "input");
      int i2 = CursorUtil.getColumnIndexOrThrow(cursor, "output");
      int i3 = CursorUtil.getColumnIndexOrThrow(cursor, "initial_delay");
      int i4 = CursorUtil.getColumnIndexOrThrow(cursor, "interval_duration");
      int i5 = CursorUtil.getColumnIndexOrThrow(cursor, "flex_duration");
      int i6 = CursorUtil.getColumnIndexOrThrow(cursor, "run_attempt_count");
      int i7 = CursorUtil.getColumnIndexOrThrow(cursor, "backoff_policy");
      int i8 = CursorUtil.getColumnIndexOrThrow(cursor, "backoff_delay_duration");
      int i9 = CursorUtil.getColumnIndexOrThrow(cursor, "last_enqueue_time");
      int i = CursorUtil.getColumnIndexOrThrow(cursor, "minimum_retention_duration");
      try {
        int i22 = CursorUtil.getColumnIndexOrThrow(cursor, "schedule_requested_at");
        int i21 = CursorUtil.getColumnIndexOrThrow(cursor, "run_in_foreground");
        int i14 = CursorUtil.getColumnIndexOrThrow(cursor, "out_of_quota_policy");
        int i20 = CursorUtil.getColumnIndexOrThrow(cursor, "period_count");
        int i19 = CursorUtil.getColumnIndexOrThrow(cursor, "generation");
        int i18 = CursorUtil.getColumnIndexOrThrow(cursor, "required_network_type");
        int i17 = CursorUtil.getColumnIndexOrThrow(cursor, "requires_charging");
        int i13 = CursorUtil.getColumnIndexOrThrow(cursor, "requires_device_idle");
        int i12 = CursorUtil.getColumnIndexOrThrow(cursor, "requires_battery_not_low");
        int i11 = CursorUtil.getColumnIndexOrThrow(cursor, "requires_storage_not_low");
        int i10 = CursorUtil.getColumnIndexOrThrow(cursor, "trigger_content_update_delay");
        int i16 = CursorUtil.getColumnIndexOrThrow(cursor, "trigger_max_content_delay");
        int i15 = CursorUtil.getColumnIndexOrThrow(cursor, "content_uri_triggers");
        ArrayList<WorkSpec> arrayList = new ArrayList(cursor.getCount());
        while (true) {
          if (cursor.moveToNext()) {
            boolean bool1;
            boolean bool2;
            boolean bool3;
            boolean bool4;
            boolean bool5;
            String str1;
            String str2;
            String str3;
            byte[] arrayOfByte;
            if (cursor.isNull(j)) {
              str1 = null;
            } else {
              str1 = cursor.getString(j);
            } 
            WorkInfo.State state = WorkTypeConverters.intToState(cursor.getInt(k));
            if (cursor.isNull(m)) {
              str2 = null;
            } else {
              str2 = cursor.getString(m);
            } 
            if (cursor.isNull(n)) {
              str3 = null;
            } else {
              str3 = cursor.getString(n);
            } 
            if (cursor.isNull(i1)) {
              arrayOfByte = null;
            } else {
              arrayOfByte = cursor.getBlob(i1);
            } 
            Data data1 = Data.fromByteArray(arrayOfByte);
            if (cursor.isNull(i2)) {
              arrayOfByte = null;
            } else {
              arrayOfByte = cursor.getBlob(i2);
            } 
            Data data2 = Data.fromByteArray(arrayOfByte);
            long l1 = cursor.getLong(i3);
            long l2 = cursor.getLong(i4);
            long l3 = cursor.getLong(i5);
            int i23 = cursor.getInt(i6);
            BackoffPolicy backoffPolicy = WorkTypeConverters.intToBackoffPolicy(cursor.getInt(i7));
            long l4 = cursor.getLong(i8);
            long l5 = cursor.getLong(i9);
            long l6 = cursor.getLong(i);
            long l7 = cursor.getLong(i22);
            if (cursor.getInt(i21) != 0) {
              bool1 = true;
            } else {
              bool1 = false;
            } 
            OutOfQuotaPolicy outOfQuotaPolicy = WorkTypeConverters.intToOutOfQuotaPolicy(cursor.getInt(i14));
            int i24 = cursor.getInt(i20);
            int i25 = cursor.getInt(i19);
            NetworkType networkType = WorkTypeConverters.intToNetworkType(cursor.getInt(i18));
            if (cursor.getInt(i17) != 0) {
              bool2 = true;
            } else {
              bool2 = false;
            } 
            if (cursor.getInt(i13) != 0) {
              bool3 = true;
            } else {
              bool3 = false;
            } 
            if (cursor.getInt(i12) != 0) {
              bool4 = true;
            } else {
              bool4 = false;
            } 
            if (cursor.getInt(i11) != 0) {
              bool5 = true;
            } else {
              bool5 = false;
            } 
            long l8 = cursor.getLong(i10);
            long l9 = cursor.getLong(i16);
            if (cursor.isNull(i15)) {
              arrayOfByte = null;
            } else {
              arrayOfByte = cursor.getBlob(i15);
            } 
            Constraints constraints = new Constraints(networkType, bool2, bool3, bool4, bool5, l8, l9, WorkTypeConverters.byteArrayToSetOfTriggers(arrayOfByte));
            arrayList.add(new WorkSpec(str1, state, str2, str3, data1, data2, l1, l2, l3, constraints, i23, backoffPolicy, l4, l5, l6, l7, bool1, outOfQuotaPolicy, i24, i25));
            continue;
          } 
          cursor.close();
          roomSQLiteQuery.release();
          return arrayList;
        } 
      } finally {}
    } finally {}
    cursor.close();
    roomSQLiteQuery.release();
    throw exception;
  }
  
  public LiveData<Long> getScheduleRequestedAtLiveData(String paramString) {
    final RoomSQLiteQuery _statement = RoomSQLiteQuery.acquire("SELECT schedule_requested_at FROM workspec WHERE id=?", 1);
    if (paramString == null) {
      roomSQLiteQuery.bindNull(1);
    } else {
      roomSQLiteQuery.bindString(1, paramString);
    } 
    InvalidationTracker invalidationTracker = this.__db.getInvalidationTracker();
    Callable<Long> callable = new Callable<Long>() {
        public Long call() throws Exception {
          long l;
          Cursor cursor = DBUtil.query(WorkSpecDao_Impl.this.__db, (SupportSQLiteQuery)_statement, false, null);
          try {
            if (cursor.moveToFirst()) {
              long l1 = cursor.getLong(0);
              return Long.valueOf(l1);
            } 
          } finally {
            cursor.close();
          } 
          cursor.close();
          return Long.valueOf(l);
        }
        
        protected void finalize() {
          _statement.release();
        }
      };
    return invalidationTracker.createLiveData(new String[] { "workspec" }, false, callable);
  }
  
  public List<WorkSpec> getScheduledWork() {
    Exception exception;
    RoomSQLiteQuery roomSQLiteQuery = RoomSQLiteQuery.acquire("SELECT * FROM workspec WHERE state=0 AND schedule_requested_at<>-1", 0);
    this.__db.assertNotSuspendingTransaction();
    Cursor cursor = DBUtil.query(this.__db, (SupportSQLiteQuery)roomSQLiteQuery, false, null);
    try {
      int j = CursorUtil.getColumnIndexOrThrow(cursor, "id");
      int k = CursorUtil.getColumnIndexOrThrow(cursor, "state");
      int m = CursorUtil.getColumnIndexOrThrow(cursor, "worker_class_name");
      int n = CursorUtil.getColumnIndexOrThrow(cursor, "input_merger_class_name");
      int i1 = CursorUtil.getColumnIndexOrThrow(cursor, "input");
      int i2 = CursorUtil.getColumnIndexOrThrow(cursor, "output");
      int i3 = CursorUtil.getColumnIndexOrThrow(cursor, "initial_delay");
      int i4 = CursorUtil.getColumnIndexOrThrow(cursor, "interval_duration");
      int i5 = CursorUtil.getColumnIndexOrThrow(cursor, "flex_duration");
      int i6 = CursorUtil.getColumnIndexOrThrow(cursor, "run_attempt_count");
      int i7 = CursorUtil.getColumnIndexOrThrow(cursor, "backoff_policy");
      int i8 = CursorUtil.getColumnIndexOrThrow(cursor, "backoff_delay_duration");
      int i9 = CursorUtil.getColumnIndexOrThrow(cursor, "last_enqueue_time");
      int i = CursorUtil.getColumnIndexOrThrow(cursor, "minimum_retention_duration");
      try {
        int i22 = CursorUtil.getColumnIndexOrThrow(cursor, "schedule_requested_at");
        int i21 = CursorUtil.getColumnIndexOrThrow(cursor, "run_in_foreground");
        int i14 = CursorUtil.getColumnIndexOrThrow(cursor, "out_of_quota_policy");
        int i20 = CursorUtil.getColumnIndexOrThrow(cursor, "period_count");
        int i19 = CursorUtil.getColumnIndexOrThrow(cursor, "generation");
        int i18 = CursorUtil.getColumnIndexOrThrow(cursor, "required_network_type");
        int i17 = CursorUtil.getColumnIndexOrThrow(cursor, "requires_charging");
        int i13 = CursorUtil.getColumnIndexOrThrow(cursor, "requires_device_idle");
        int i12 = CursorUtil.getColumnIndexOrThrow(cursor, "requires_battery_not_low");
        int i11 = CursorUtil.getColumnIndexOrThrow(cursor, "requires_storage_not_low");
        int i10 = CursorUtil.getColumnIndexOrThrow(cursor, "trigger_content_update_delay");
        int i16 = CursorUtil.getColumnIndexOrThrow(cursor, "trigger_max_content_delay");
        int i15 = CursorUtil.getColumnIndexOrThrow(cursor, "content_uri_triggers");
        ArrayList<WorkSpec> arrayList = new ArrayList(cursor.getCount());
        while (true) {
          if (cursor.moveToNext()) {
            boolean bool1;
            boolean bool2;
            boolean bool3;
            boolean bool4;
            boolean bool5;
            String str1;
            String str2;
            String str3;
            byte[] arrayOfByte;
            if (cursor.isNull(j)) {
              str1 = null;
            } else {
              str1 = cursor.getString(j);
            } 
            WorkInfo.State state = WorkTypeConverters.intToState(cursor.getInt(k));
            if (cursor.isNull(m)) {
              str2 = null;
            } else {
              str2 = cursor.getString(m);
            } 
            if (cursor.isNull(n)) {
              str3 = null;
            } else {
              str3 = cursor.getString(n);
            } 
            if (cursor.isNull(i1)) {
              arrayOfByte = null;
            } else {
              arrayOfByte = cursor.getBlob(i1);
            } 
            Data data1 = Data.fromByteArray(arrayOfByte);
            if (cursor.isNull(i2)) {
              arrayOfByte = null;
            } else {
              arrayOfByte = cursor.getBlob(i2);
            } 
            Data data2 = Data.fromByteArray(arrayOfByte);
            long l1 = cursor.getLong(i3);
            long l2 = cursor.getLong(i4);
            long l3 = cursor.getLong(i5);
            int i23 = cursor.getInt(i6);
            BackoffPolicy backoffPolicy = WorkTypeConverters.intToBackoffPolicy(cursor.getInt(i7));
            long l4 = cursor.getLong(i8);
            long l5 = cursor.getLong(i9);
            long l6 = cursor.getLong(i);
            long l7 = cursor.getLong(i22);
            if (cursor.getInt(i21) != 0) {
              bool1 = true;
            } else {
              bool1 = false;
            } 
            OutOfQuotaPolicy outOfQuotaPolicy = WorkTypeConverters.intToOutOfQuotaPolicy(cursor.getInt(i14));
            int i24 = cursor.getInt(i20);
            int i25 = cursor.getInt(i19);
            NetworkType networkType = WorkTypeConverters.intToNetworkType(cursor.getInt(i18));
            if (cursor.getInt(i17) != 0) {
              bool2 = true;
            } else {
              bool2 = false;
            } 
            if (cursor.getInt(i13) != 0) {
              bool3 = true;
            } else {
              bool3 = false;
            } 
            if (cursor.getInt(i12) != 0) {
              bool4 = true;
            } else {
              bool4 = false;
            } 
            if (cursor.getInt(i11) != 0) {
              bool5 = true;
            } else {
              bool5 = false;
            } 
            long l8 = cursor.getLong(i10);
            long l9 = cursor.getLong(i16);
            if (cursor.isNull(i15)) {
              arrayOfByte = null;
            } else {
              arrayOfByte = cursor.getBlob(i15);
            } 
            Constraints constraints = new Constraints(networkType, bool2, bool3, bool4, bool5, l8, l9, WorkTypeConverters.byteArrayToSetOfTriggers(arrayOfByte));
            arrayList.add(new WorkSpec(str1, state, str2, str3, data1, data2, l1, l2, l3, constraints, i23, backoffPolicy, l4, l5, l6, l7, bool1, outOfQuotaPolicy, i24, i25));
            continue;
          } 
          cursor.close();
          roomSQLiteQuery.release();
          return arrayList;
        } 
      } finally {}
    } finally {}
    cursor.close();
    roomSQLiteQuery.release();
    throw exception;
  }
  
  public WorkInfo.State getState(String paramString) {
    RoomDatabase roomDatabase1;
    RoomSQLiteQuery roomSQLiteQuery = RoomSQLiteQuery.acquire("SELECT state FROM workspec WHERE id=?", 1);
    if (paramString == null) {
      roomSQLiteQuery.bindNull(1);
    } else {
      roomSQLiteQuery.bindString(1, paramString);
    } 
    this.__db.assertNotSuspendingTransaction();
    null = this.__db;
    RoomDatabase roomDatabase2 = null;
    Cursor cursor = DBUtil.query(null, (SupportSQLiteQuery)roomSQLiteQuery, false, null);
    null = roomDatabase2;
    try {
    
    } finally {
      cursor.close();
      roomSQLiteQuery.release();
    } 
    if (paramString == null) {
      roomDatabase1 = roomDatabase2;
      cursor.close();
      roomSQLiteQuery.release();
      return (WorkInfo.State)roomDatabase1;
    } 
    WorkTypeConverters workTypeConverters = WorkTypeConverters.INSTANCE;
    WorkInfo.State state = WorkTypeConverters.intToState(roomDatabase1.intValue());
    cursor.close();
    roomSQLiteQuery.release();
    return state;
  }
  
  public List<String> getUnfinishedWorkWithName(String paramString) {
    RoomSQLiteQuery roomSQLiteQuery = RoomSQLiteQuery.acquire("SELECT id FROM workspec WHERE state NOT IN (2, 3, 5) AND id IN (SELECT work_spec_id FROM workname WHERE name=?)", 1);
    if (paramString == null) {
      roomSQLiteQuery.bindNull(1);
    } else {
      roomSQLiteQuery.bindString(1, paramString);
    } 
    this.__db.assertNotSuspendingTransaction();
    Cursor cursor = DBUtil.query(this.__db, (SupportSQLiteQuery)roomSQLiteQuery, false, null);
    try {
      ArrayList<String> arrayList = new ArrayList(cursor.getCount());
      while (cursor.moveToNext()) {
        if (cursor.isNull(0)) {
          paramString = null;
        } else {
          paramString = cursor.getString(0);
        } 
        arrayList.add(paramString);
      } 
      return arrayList;
    } finally {
      cursor.close();
      roomSQLiteQuery.release();
    } 
  }
  
  public List<String> getUnfinishedWorkWithTag(String paramString) {
    RoomSQLiteQuery roomSQLiteQuery = RoomSQLiteQuery.acquire("SELECT id FROM workspec WHERE state NOT IN (2, 3, 5) AND id IN (SELECT work_spec_id FROM worktag WHERE tag=?)", 1);
    if (paramString == null) {
      roomSQLiteQuery.bindNull(1);
    } else {
      roomSQLiteQuery.bindString(1, paramString);
    } 
    this.__db.assertNotSuspendingTransaction();
    Cursor cursor = DBUtil.query(this.__db, (SupportSQLiteQuery)roomSQLiteQuery, false, null);
    try {
      ArrayList<String> arrayList = new ArrayList(cursor.getCount());
      while (cursor.moveToNext()) {
        if (cursor.isNull(0)) {
          paramString = null;
        } else {
          paramString = cursor.getString(0);
        } 
        arrayList.add(paramString);
      } 
      return arrayList;
    } finally {
      cursor.close();
      roomSQLiteQuery.release();
    } 
  }
  
  public WorkSpec getWorkSpec(String paramString) {
    RoomSQLiteQuery roomSQLiteQuery = RoomSQLiteQuery.acquire("SELECT * FROM workspec WHERE id=?", 1);
    if (paramString == null) {
      roomSQLiteQuery.bindNull(1);
    } else {
      roomSQLiteQuery.bindString(1, paramString);
    } 
    this.__db.assertNotSuspendingTransaction();
    Cursor cursor = DBUtil.query(this.__db, (SupportSQLiteQuery)roomSQLiteQuery, false, null);
    try {
      int n = CursorUtil.getColumnIndexOrThrow(cursor, "id");
      int i1 = CursorUtil.getColumnIndexOrThrow(cursor, "state");
      int i2 = CursorUtil.getColumnIndexOrThrow(cursor, "worker_class_name");
      int i3 = CursorUtil.getColumnIndexOrThrow(cursor, "input_merger_class_name");
      int i4 = CursorUtil.getColumnIndexOrThrow(cursor, "input");
      int i5 = CursorUtil.getColumnIndexOrThrow(cursor, "output");
      int i6 = CursorUtil.getColumnIndexOrThrow(cursor, "initial_delay");
      int i7 = CursorUtil.getColumnIndexOrThrow(cursor, "interval_duration");
      int i8 = CursorUtil.getColumnIndexOrThrow(cursor, "flex_duration");
      int i9 = CursorUtil.getColumnIndexOrThrow(cursor, "run_attempt_count");
      int i = CursorUtil.getColumnIndexOrThrow(cursor, "backoff_policy");
      int j = CursorUtil.getColumnIndexOrThrow(cursor, "backoff_delay_duration");
      int k = CursorUtil.getColumnIndexOrThrow(cursor, "last_enqueue_time");
      int m = CursorUtil.getColumnIndexOrThrow(cursor, "minimum_retention_duration");
      try {
        int i19 = CursorUtil.getColumnIndexOrThrow(cursor, "schedule_requested_at");
        int i20 = CursorUtil.getColumnIndexOrThrow(cursor, "run_in_foreground");
        int i21 = CursorUtil.getColumnIndexOrThrow(cursor, "out_of_quota_policy");
        int i22 = CursorUtil.getColumnIndexOrThrow(cursor, "period_count");
        int i18 = CursorUtil.getColumnIndexOrThrow(cursor, "generation");
        int i10 = CursorUtil.getColumnIndexOrThrow(cursor, "required_network_type");
        int i11 = CursorUtil.getColumnIndexOrThrow(cursor, "requires_charging");
        int i12 = CursorUtil.getColumnIndexOrThrow(cursor, "requires_device_idle");
        int i13 = CursorUtil.getColumnIndexOrThrow(cursor, "requires_battery_not_low");
        int i14 = CursorUtil.getColumnIndexOrThrow(cursor, "requires_storage_not_low");
        int i15 = CursorUtil.getColumnIndexOrThrow(cursor, "trigger_content_update_delay");
        int i16 = CursorUtil.getColumnIndexOrThrow(cursor, "trigger_max_content_delay");
        int i17 = CursorUtil.getColumnIndexOrThrow(cursor, "content_uri_triggers");
        if (cursor.moveToFirst()) {
          boolean bool1;
          boolean bool2;
          boolean bool3;
          boolean bool4;
          boolean bool5;
          String str1;
          String str2;
          byte[] arrayOfByte;
          if (cursor.isNull(n)) {
            paramString = null;
          } else {
            paramString = cursor.getString(n);
          } 
          WorkInfo.State state = WorkTypeConverters.intToState(cursor.getInt(i1));
          if (cursor.isNull(i2)) {
            str1 = null;
          } else {
            str1 = cursor.getString(i2);
          } 
          if (cursor.isNull(i3)) {
            str2 = null;
          } else {
            str2 = cursor.getString(i3);
          } 
          if (cursor.isNull(i4)) {
            arrayOfByte = null;
          } else {
            arrayOfByte = cursor.getBlob(i4);
          } 
          Data data1 = Data.fromByteArray(arrayOfByte);
          if (cursor.isNull(i5)) {
            arrayOfByte = null;
          } else {
            arrayOfByte = cursor.getBlob(i5);
          } 
          Data data2 = Data.fromByteArray(arrayOfByte);
          long l1 = cursor.getLong(i6);
          long l2 = cursor.getLong(i7);
          long l3 = cursor.getLong(i8);
          n = cursor.getInt(i9);
          BackoffPolicy backoffPolicy = WorkTypeConverters.intToBackoffPolicy(cursor.getInt(i));
          long l4 = cursor.getLong(j);
          long l5 = cursor.getLong(k);
          long l6 = cursor.getLong(m);
          long l7 = cursor.getLong(i19);
          if (cursor.getInt(i20) != 0) {
            bool1 = true;
          } else {
            bool1 = false;
          } 
          OutOfQuotaPolicy outOfQuotaPolicy = WorkTypeConverters.intToOutOfQuotaPolicy(cursor.getInt(i21));
          i = cursor.getInt(i22);
          i18 = cursor.getInt(i18);
          NetworkType networkType = WorkTypeConverters.intToNetworkType(cursor.getInt(i10));
          if (cursor.getInt(i11) != 0) {
            bool2 = true;
          } else {
            bool2 = false;
          } 
          if (cursor.getInt(i12) != 0) {
            bool3 = true;
          } else {
            bool3 = false;
          } 
          if (cursor.getInt(i13) != 0) {
            bool4 = true;
          } else {
            bool4 = false;
          } 
          if (cursor.getInt(i14) != 0) {
            bool5 = true;
          } else {
            bool5 = false;
          } 
          long l8 = cursor.getLong(i15);
          long l9 = cursor.getLong(i16);
          if (cursor.isNull(i17)) {
            arrayOfByte = null;
          } else {
            arrayOfByte = cursor.getBlob(i17);
          } 
          WorkSpec workSpec = new WorkSpec(paramString, state, str1, str2, data1, data2, l1, l2, l3, new Constraints(networkType, bool2, bool3, bool4, bool5, l8, l9, WorkTypeConverters.byteArrayToSetOfTriggers(arrayOfByte)), n, backoffPolicy, l4, l5, l6, l7, bool1, outOfQuotaPolicy, i, i18);
        } else {
          paramString = null;
        } 
        cursor.close();
        roomSQLiteQuery.release();
        return (WorkSpec)paramString;
      } finally {}
    } finally {}
    cursor.close();
    roomSQLiteQuery.release();
    throw paramString;
  }
  
  public List<WorkSpec.IdAndState> getWorkSpecIdAndStatesForName(String paramString) {
    RoomSQLiteQuery roomSQLiteQuery = RoomSQLiteQuery.acquire("SELECT id, state FROM workspec WHERE id IN (SELECT work_spec_id FROM workname WHERE name=?)", 1);
    if (paramString == null) {
      roomSQLiteQuery.bindNull(1);
    } else {
      roomSQLiteQuery.bindString(1, paramString);
    } 
    this.__db.assertNotSuspendingTransaction();
    Cursor cursor = DBUtil.query(this.__db, (SupportSQLiteQuery)roomSQLiteQuery, false, null);
    try {
      ArrayList<WorkSpec.IdAndState> arrayList = new ArrayList(cursor.getCount());
      while (cursor.moveToNext()) {
        if (cursor.isNull(0)) {
          paramString = null;
        } else {
          paramString = cursor.getString(0);
        } 
        arrayList.add(new WorkSpec.IdAndState(paramString, WorkTypeConverters.intToState(cursor.getInt(1))));
      } 
      return arrayList;
    } finally {
      cursor.close();
      roomSQLiteQuery.release();
    } 
  }
  
  public WorkSpec.WorkInfoPojo getWorkStatusPojoForId(String paramString) {
    RoomSQLiteQuery roomSQLiteQuery = RoomSQLiteQuery.acquire("SELECT id, state, output, run_attempt_count, generation FROM workspec WHERE id=?", 1);
    if (paramString == null) {
      roomSQLiteQuery.bindNull(1);
    } else {
      roomSQLiteQuery.bindString(1, paramString);
    } 
    this.__db.assertNotSuspendingTransaction();
    this.__db.beginTransaction();
    try {
      RoomDatabase roomDatabase = this.__db;
      paramString = null;
      byte[] arrayOfByte = null;
      Cursor cursor = DBUtil.query(roomDatabase, (SupportSQLiteQuery)roomSQLiteQuery, true, null);
    } finally {
      this.__db.endTransaction();
    } 
  }
  
  public List<WorkSpec.WorkInfoPojo> getWorkStatusPojoForIds(List<String> paramList) {
    StringBuilder stringBuilder = StringUtil.newStringBuilder();
    stringBuilder.append("SELECT id, state, output, run_attempt_count, generation FROM workspec WHERE id IN (");
    int i = paramList.size();
    StringUtil.appendPlaceholders(stringBuilder, i);
    stringBuilder.append(")");
    RoomSQLiteQuery roomSQLiteQuery = RoomSQLiteQuery.acquire(stringBuilder.toString(), i + 0);
    null = paramList.iterator();
    for (i = 1; null.hasNext(); i++) {
      String str = null.next();
      if (str == null) {
        roomSQLiteQuery.bindNull(i);
      } else {
        roomSQLiteQuery.bindString(i, str);
      } 
    } 
    this.__db.assertNotSuspendingTransaction();
    this.__db.beginTransaction();
    try {
      Cursor cursor = DBUtil.query(this.__db, (SupportSQLiteQuery)roomSQLiteQuery, true, null);
    } finally {
      this.__db.endTransaction();
    } 
  }
  
  public List<WorkSpec.WorkInfoPojo> getWorkStatusPojoForName(String paramString) {
    RoomSQLiteQuery roomSQLiteQuery = RoomSQLiteQuery.acquire("SELECT id, state, output, run_attempt_count, generation FROM workspec WHERE id IN (SELECT work_spec_id FROM workname WHERE name=?)", 1);
    if (paramString == null) {
      roomSQLiteQuery.bindNull(1);
    } else {
      roomSQLiteQuery.bindString(1, paramString);
    } 
    this.__db.assertNotSuspendingTransaction();
    this.__db.beginTransaction();
    try {
      Cursor cursor = DBUtil.query(this.__db, (SupportSQLiteQuery)roomSQLiteQuery, true, null);
    } finally {
      this.__db.endTransaction();
    } 
  }
  
  public List<WorkSpec.WorkInfoPojo> getWorkStatusPojoForTag(String paramString) {
    RoomSQLiteQuery roomSQLiteQuery = RoomSQLiteQuery.acquire("SELECT id, state, output, run_attempt_count, generation FROM workspec WHERE id IN\n            (SELECT work_spec_id FROM worktag WHERE tag=?)", 1);
    if (paramString == null) {
      roomSQLiteQuery.bindNull(1);
    } else {
      roomSQLiteQuery.bindString(1, paramString);
    } 
    this.__db.assertNotSuspendingTransaction();
    this.__db.beginTransaction();
    try {
      Cursor cursor = DBUtil.query(this.__db, (SupportSQLiteQuery)roomSQLiteQuery, true, null);
    } finally {
      this.__db.endTransaction();
    } 
  }
  
  public LiveData<List<WorkSpec.WorkInfoPojo>> getWorkStatusPojoLiveDataForIds(List<String> paramList) {
    StringBuilder stringBuilder = StringUtil.newStringBuilder();
    stringBuilder.append("SELECT id, state, output, run_attempt_count, generation FROM workspec WHERE id IN (");
    int i = paramList.size();
    StringUtil.appendPlaceholders(stringBuilder, i);
    stringBuilder.append(")");
    final RoomSQLiteQuery _statement = RoomSQLiteQuery.acquire(stringBuilder.toString(), i + 0);
    Iterator<String> iterator = paramList.iterator();
    for (i = 1; iterator.hasNext(); i++) {
      String str = iterator.next();
      if (str == null) {
        roomSQLiteQuery.bindNull(i);
      } else {
        roomSQLiteQuery.bindString(i, str);
      } 
    } 
    InvalidationTracker invalidationTracker = this.__db.getInvalidationTracker();
    Callable<List<WorkSpec.WorkInfoPojo>> callable = new Callable<List<WorkSpec.WorkInfoPojo>>() {
        public List<WorkSpec.WorkInfoPojo> call() throws Exception {
          WorkSpecDao_Impl.this.__db.beginTransaction();
          try {
            Cursor cursor = DBUtil.query(WorkSpecDao_Impl.this.__db, (SupportSQLiteQuery)_statement, true, null);
          } finally {
            WorkSpecDao_Impl.this.__db.endTransaction();
          } 
        }
        
        protected void finalize() {
          _statement.release();
        }
      };
    return invalidationTracker.createLiveData(new String[] { "WorkTag", "WorkProgress", "workspec" }, true, callable);
  }
  
  public LiveData<List<WorkSpec.WorkInfoPojo>> getWorkStatusPojoLiveDataForName(String paramString) {
    final RoomSQLiteQuery _statement = RoomSQLiteQuery.acquire("SELECT id, state, output, run_attempt_count, generation FROM workspec WHERE id IN (SELECT work_spec_id FROM workname WHERE name=?)", 1);
    if (paramString == null) {
      roomSQLiteQuery.bindNull(1);
    } else {
      roomSQLiteQuery.bindString(1, paramString);
    } 
    InvalidationTracker invalidationTracker = this.__db.getInvalidationTracker();
    Callable<List<WorkSpec.WorkInfoPojo>> callable = new Callable<List<WorkSpec.WorkInfoPojo>>() {
        public List<WorkSpec.WorkInfoPojo> call() throws Exception {
          WorkSpecDao_Impl.this.__db.beginTransaction();
          try {
            Cursor cursor = DBUtil.query(WorkSpecDao_Impl.this.__db, (SupportSQLiteQuery)_statement, true, null);
          } finally {
            WorkSpecDao_Impl.this.__db.endTransaction();
          } 
        }
        
        protected void finalize() {
          _statement.release();
        }
      };
    return invalidationTracker.createLiveData(new String[] { "WorkTag", "WorkProgress", "workspec", "workname" }, true, callable);
  }
  
  public LiveData<List<WorkSpec.WorkInfoPojo>> getWorkStatusPojoLiveDataForTag(String paramString) {
    final RoomSQLiteQuery _statement = RoomSQLiteQuery.acquire("SELECT id, state, output, run_attempt_count, generation FROM workspec WHERE id IN\n            (SELECT work_spec_id FROM worktag WHERE tag=?)", 1);
    if (paramString == null) {
      roomSQLiteQuery.bindNull(1);
    } else {
      roomSQLiteQuery.bindString(1, paramString);
    } 
    InvalidationTracker invalidationTracker = this.__db.getInvalidationTracker();
    Callable<List<WorkSpec.WorkInfoPojo>> callable = new Callable<List<WorkSpec.WorkInfoPojo>>() {
        public List<WorkSpec.WorkInfoPojo> call() throws Exception {
          WorkSpecDao_Impl.this.__db.beginTransaction();
          try {
            Cursor cursor = DBUtil.query(WorkSpecDao_Impl.this.__db, (SupportSQLiteQuery)_statement, true, null);
          } finally {
            WorkSpecDao_Impl.this.__db.endTransaction();
          } 
        }
        
        protected void finalize() {
          _statement.release();
        }
      };
    return invalidationTracker.createLiveData(new String[] { "WorkTag", "WorkProgress", "workspec", "worktag" }, true, callable);
  }
  
  public boolean hasUnfinishedWork() {
    boolean bool2 = false;
    RoomSQLiteQuery roomSQLiteQuery = RoomSQLiteQuery.acquire("SELECT COUNT(*) > 0 FROM workspec WHERE state NOT IN (2, 3, 5) LIMIT 1", 0);
    this.__db.assertNotSuspendingTransaction();
    Cursor cursor = DBUtil.query(this.__db, (SupportSQLiteQuery)roomSQLiteQuery, false, null);
    boolean bool1 = bool2;
    try {
      if (cursor.moveToFirst()) {
        int i = cursor.getInt(0);
        bool1 = bool2;
        if (i != 0)
          bool1 = true; 
      } 
      return bool1;
    } finally {
      cursor.close();
      roomSQLiteQuery.release();
    } 
  }
  
  public void incrementGeneration(String paramString) {
    this.__db.assertNotSuspendingTransaction();
    SupportSQLiteStatement supportSQLiteStatement = this.__preparedStmtOfIncrementGeneration.acquire();
    if (paramString == null) {
      supportSQLiteStatement.bindNull(1);
    } else {
      supportSQLiteStatement.bindString(1, paramString);
    } 
    this.__db.beginTransaction();
    try {
      supportSQLiteStatement.executeUpdateDelete();
      this.__db.setTransactionSuccessful();
      return;
    } finally {
      this.__db.endTransaction();
      this.__preparedStmtOfIncrementGeneration.release(supportSQLiteStatement);
    } 
  }
  
  public void incrementPeriodCount(String paramString) {
    this.__db.assertNotSuspendingTransaction();
    SupportSQLiteStatement supportSQLiteStatement = this.__preparedStmtOfIncrementPeriodCount.acquire();
    if (paramString == null) {
      supportSQLiteStatement.bindNull(1);
    } else {
      supportSQLiteStatement.bindString(1, paramString);
    } 
    this.__db.beginTransaction();
    try {
      supportSQLiteStatement.executeUpdateDelete();
      this.__db.setTransactionSuccessful();
      return;
    } finally {
      this.__db.endTransaction();
      this.__preparedStmtOfIncrementPeriodCount.release(supportSQLiteStatement);
    } 
  }
  
  public int incrementWorkSpecRunAttemptCount(String paramString) {
    this.__db.assertNotSuspendingTransaction();
    SupportSQLiteStatement supportSQLiteStatement = this.__preparedStmtOfIncrementWorkSpecRunAttemptCount.acquire();
    if (paramString == null) {
      supportSQLiteStatement.bindNull(1);
    } else {
      supportSQLiteStatement.bindString(1, paramString);
    } 
    this.__db.beginTransaction();
    try {
      int i = supportSQLiteStatement.executeUpdateDelete();
      this.__db.setTransactionSuccessful();
      return i;
    } finally {
      this.__db.endTransaction();
      this.__preparedStmtOfIncrementWorkSpecRunAttemptCount.release(supportSQLiteStatement);
    } 
  }
  
  public void insertWorkSpec(WorkSpec paramWorkSpec) {
    this.__db.assertNotSuspendingTransaction();
    this.__db.beginTransaction();
    try {
      this.__insertionAdapterOfWorkSpec.insert(paramWorkSpec);
      this.__db.setTransactionSuccessful();
      return;
    } finally {
      this.__db.endTransaction();
    } 
  }
  
  public int markWorkSpecScheduled(String paramString, long paramLong) {
    this.__db.assertNotSuspendingTransaction();
    SupportSQLiteStatement supportSQLiteStatement = this.__preparedStmtOfMarkWorkSpecScheduled.acquire();
    supportSQLiteStatement.bindLong(1, paramLong);
    if (paramString == null) {
      supportSQLiteStatement.bindNull(2);
    } else {
      supportSQLiteStatement.bindString(2, paramString);
    } 
    this.__db.beginTransaction();
    try {
      int i = supportSQLiteStatement.executeUpdateDelete();
      this.__db.setTransactionSuccessful();
      return i;
    } finally {
      this.__db.endTransaction();
      this.__preparedStmtOfMarkWorkSpecScheduled.release(supportSQLiteStatement);
    } 
  }
  
  public void pruneFinishedWorkWithZeroDependentsIgnoringKeepForAtLeast() {
    this.__db.assertNotSuspendingTransaction();
    SupportSQLiteStatement supportSQLiteStatement = this.__preparedStmtOfPruneFinishedWorkWithZeroDependentsIgnoringKeepForAtLeast.acquire();
    this.__db.beginTransaction();
    try {
      supportSQLiteStatement.executeUpdateDelete();
      this.__db.setTransactionSuccessful();
      return;
    } finally {
      this.__db.endTransaction();
      this.__preparedStmtOfPruneFinishedWorkWithZeroDependentsIgnoringKeepForAtLeast.release(supportSQLiteStatement);
    } 
  }
  
  public int resetScheduledState() {
    this.__db.assertNotSuspendingTransaction();
    SupportSQLiteStatement supportSQLiteStatement = this.__preparedStmtOfResetScheduledState.acquire();
    this.__db.beginTransaction();
    try {
      int i = supportSQLiteStatement.executeUpdateDelete();
      this.__db.setTransactionSuccessful();
      return i;
    } finally {
      this.__db.endTransaction();
      this.__preparedStmtOfResetScheduledState.release(supportSQLiteStatement);
    } 
  }
  
  public int resetWorkSpecRunAttemptCount(String paramString) {
    this.__db.assertNotSuspendingTransaction();
    SupportSQLiteStatement supportSQLiteStatement = this.__preparedStmtOfResetWorkSpecRunAttemptCount.acquire();
    if (paramString == null) {
      supportSQLiteStatement.bindNull(1);
    } else {
      supportSQLiteStatement.bindString(1, paramString);
    } 
    this.__db.beginTransaction();
    try {
      int i = supportSQLiteStatement.executeUpdateDelete();
      this.__db.setTransactionSuccessful();
      return i;
    } finally {
      this.__db.endTransaction();
      this.__preparedStmtOfResetWorkSpecRunAttemptCount.release(supportSQLiteStatement);
    } 
  }
  
  public void setLastEnqueuedTime(String paramString, long paramLong) {
    this.__db.assertNotSuspendingTransaction();
    SupportSQLiteStatement supportSQLiteStatement = this.__preparedStmtOfSetLastEnqueuedTime.acquire();
    supportSQLiteStatement.bindLong(1, paramLong);
    if (paramString == null) {
      supportSQLiteStatement.bindNull(2);
    } else {
      supportSQLiteStatement.bindString(2, paramString);
    } 
    this.__db.beginTransaction();
    try {
      supportSQLiteStatement.executeUpdateDelete();
      this.__db.setTransactionSuccessful();
      return;
    } finally {
      this.__db.endTransaction();
      this.__preparedStmtOfSetLastEnqueuedTime.release(supportSQLiteStatement);
    } 
  }
  
  public void setOutput(String paramString, Data paramData) {
    this.__db.assertNotSuspendingTransaction();
    SupportSQLiteStatement supportSQLiteStatement = this.__preparedStmtOfSetOutput.acquire();
    byte[] arrayOfByte = Data.toByteArrayInternal(paramData);
    if (arrayOfByte == null) {
      supportSQLiteStatement.bindNull(1);
    } else {
      supportSQLiteStatement.bindBlob(1, arrayOfByte);
    } 
    if (paramString == null) {
      supportSQLiteStatement.bindNull(2);
    } else {
      supportSQLiteStatement.bindString(2, paramString);
    } 
    this.__db.beginTransaction();
    try {
      supportSQLiteStatement.executeUpdateDelete();
      this.__db.setTransactionSuccessful();
      return;
    } finally {
      this.__db.endTransaction();
      this.__preparedStmtOfSetOutput.release(supportSQLiteStatement);
    } 
  }
  
  public int setState(WorkInfo.State paramState, String paramString) {
    this.__db.assertNotSuspendingTransaction();
    SupportSQLiteStatement supportSQLiteStatement = this.__preparedStmtOfSetState.acquire();
    supportSQLiteStatement.bindLong(1, WorkTypeConverters.stateToInt(paramState));
    if (paramString == null) {
      supportSQLiteStatement.bindNull(2);
    } else {
      supportSQLiteStatement.bindString(2, paramString);
    } 
    this.__db.beginTransaction();
    try {
      int i = supportSQLiteStatement.executeUpdateDelete();
      this.__db.setTransactionSuccessful();
      return i;
    } finally {
      this.__db.endTransaction();
      this.__preparedStmtOfSetState.release(supportSQLiteStatement);
    } 
  }
  
  public void updateWorkSpec(WorkSpec paramWorkSpec) {
    this.__db.assertNotSuspendingTransaction();
    this.__db.beginTransaction();
    try {
      this.__updateAdapterOfWorkSpec.handle(paramWorkSpec);
      this.__db.setTransactionSuccessful();
      return;
    } finally {
      this.__db.endTransaction();
    } 
  }
}


/* Location:              C:\soft\dex2jar-2.0\MagicAI - AI Art & Anime Art-dex2jar.jar!\androidx\work\impl\model\WorkSpecDao_Impl.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */