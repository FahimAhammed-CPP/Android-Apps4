package androidx.work.impl.model;

import androidx.room.Dao;
import androidx.room.Insert;
import androidx.room.Query;
import java.util.List;
import kotlin.Metadata;
import kotlin.jvm.internal.Intrinsics;

@Metadata(d1 = {"\0000\n\002\030\002\n\002\020\000\n\000\n\002\030\002\n\000\n\002\030\002\n\000\n\002\020\016\n\000\n\002\020\b\n\000\n\002\020 \n\000\n\002\020\002\n\002\b\003\bg\030\0002\0020\001J\022\020\002\032\004\030\0010\0032\006\020\004\032\0020\005H\026J\032\020\002\032\004\030\0010\0032\006\020\006\032\0020\0072\006\020\b\032\0020\tH'J\016\020\n\032\b\022\004\022\0020\0070\013H'J\020\020\f\032\0020\r2\006\020\016\032\0020\003H'J\020\020\017\032\0020\r2\006\020\004\032\0020\005H\026J\020\020\017\032\0020\r2\006\020\006\032\0020\007H'J\030\020\017\032\0020\r2\006\020\006\032\0020\0072\006\020\b\032\0020\tH'¨\006\020"}, d2 = {"Landroidx/work/impl/model/SystemIdInfoDao;", "", "getSystemIdInfo", "Landroidx/work/impl/model/SystemIdInfo;", "id", "Landroidx/work/impl/model/WorkGenerationalId;", "workSpecId", "", "generation", "", "getWorkSpecIds", "", "insertSystemIdInfo", "", "systemIdInfo", "removeSystemIdInfo", "work-runtime_release"}, k = 1, mv = {1, 7, 1}, xi = 48)
@Dao
public interface SystemIdInfoDao {
  SystemIdInfo getSystemIdInfo(WorkGenerationalId paramWorkGenerationalId);
  
  @Query("SELECT * FROM SystemIdInfo WHERE work_spec_id=:workSpecId AND generation=:generation")
  SystemIdInfo getSystemIdInfo(String paramString, int paramInt);
  
  @Query("SELECT DISTINCT work_spec_id FROM SystemIdInfo")
  List<String> getWorkSpecIds();
  
  @Insert(onConflict = 1)
  void insertSystemIdInfo(SystemIdInfo paramSystemIdInfo);
  
  void removeSystemIdInfo(WorkGenerationalId paramWorkGenerationalId);
  
  @Query("DELETE FROM SystemIdInfo where work_spec_id=:workSpecId")
  void removeSystemIdInfo(String paramString);
  
  @Query("DELETE FROM SystemIdInfo where work_spec_id=:workSpecId AND generation=:generation")
  void removeSystemIdInfo(String paramString, int paramInt);
  
  @Metadata(k = 3, mv = {1, 7, 1}, xi = 48)
  public static final class DefaultImpls {
    public static SystemIdInfo getSystemIdInfo(SystemIdInfoDao param1SystemIdInfoDao, WorkGenerationalId param1WorkGenerationalId) {
      Intrinsics.checkNotNullParameter(param1WorkGenerationalId, "id");
      return param1SystemIdInfoDao.getSystemIdInfo(param1WorkGenerationalId.getWorkSpecId(), param1WorkGenerationalId.getGeneration());
    }
    
    public static void removeSystemIdInfo(SystemIdInfoDao param1SystemIdInfoDao, WorkGenerationalId param1WorkGenerationalId) {
      Intrinsics.checkNotNullParameter(param1WorkGenerationalId, "id");
      param1SystemIdInfoDao.removeSystemIdInfo(param1WorkGenerationalId.getWorkSpecId(), param1WorkGenerationalId.getGeneration());
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\MagicAI - AI Art & Anime Art-dex2jar.jar!\androidx\work\impl\model\SystemIdInfoDao.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */