package androidx.work.impl.model;

import androidx.annotation.RestrictTo;
import androidx.room.ColumnInfo;
import androidx.room.Entity;
import androidx.room.ForeignKey;
import kotlin.Metadata;
import kotlin.jvm.internal.Intrinsics;

@Metadata(d1 = {"\000 \n\002\030\002\n\002\020\000\n\000\n\002\020\016\n\000\n\002\020\b\n\002\b\t\n\002\020\013\n\002\b\004\b\b\030\0002\0020\001B\035\022\006\020\002\032\0020\003\022\006\020\004\032\0020\005\022\006\020\006\032\0020\005¢\006\002\020\007J\t\020\n\032\0020\003HÆ\003J\t\020\013\032\0020\005HÆ\003J\t\020\f\032\0020\005HÆ\003J'\020\r\032\0020\0002\b\b\002\020\002\032\0020\0032\b\b\002\020\004\032\0020\0052\b\b\002\020\006\032\0020\005HÆ\001J\023\020\016\032\0020\0172\b\020\020\032\004\030\0010\001HÖ\003J\t\020\021\032\0020\005HÖ\001J\t\020\022\032\0020\003HÖ\001R\026\020\004\032\0020\0058\006X\004¢\006\b\n\000\032\004\b\b\020\tR\020\020\006\032\0020\0058\006X\004¢\006\002\n\000R\020\020\002\032\0020\0038\006X\004¢\006\002\n\000¨\006\023"}, d2 = {"Landroidx/work/impl/model/SystemIdInfo;", "", "workSpecId", "", "generation", "", "systemId", "(Ljava/lang/String;II)V", "getGeneration", "()I", "component1", "component2", "component3", "copy", "equals", "", "other", "hashCode", "toString", "work-runtime_release"}, k = 1, mv = {1, 7, 1}, xi = 48)
@RestrictTo({RestrictTo.Scope.LIBRARY_GROUP})
@Entity(foreignKeys = {@ForeignKey(childColumns = {"work_spec_id"}, entity = WorkSpec.class, onDelete = 5, onUpdate = 5, parentColumns = {"id"})}, primaryKeys = {"work_spec_id", "generation"})
public final class SystemIdInfo {
  @ColumnInfo(defaultValue = "0")
  private final int generation;
  
  @ColumnInfo(name = "system_id")
  public final int systemId;
  
  @ColumnInfo(name = "work_spec_id")
  public final String workSpecId;
  
  public SystemIdInfo(String paramString, int paramInt1, int paramInt2) {
    this.workSpecId = paramString;
    this.generation = paramInt1;
    this.systemId = paramInt2;
  }
  
  public final String component1() {
    return this.workSpecId;
  }
  
  public final int component2() {
    return this.generation;
  }
  
  public final int component3() {
    return this.systemId;
  }
  
  public final SystemIdInfo copy(String paramString, int paramInt1, int paramInt2) {
    Intrinsics.checkNotNullParameter(paramString, "workSpecId");
    return new SystemIdInfo(paramString, paramInt1, paramInt2);
  }
  
  public boolean equals(Object paramObject) {
    if (this == paramObject)
      return true; 
    if (!(paramObject instanceof SystemIdInfo))
      return false; 
    paramObject = paramObject;
    return !Intrinsics.areEqual(this.workSpecId, ((SystemIdInfo)paramObject).workSpecId) ? false : ((this.generation != ((SystemIdInfo)paramObject).generation) ? false : (!(this.systemId != ((SystemIdInfo)paramObject).systemId)));
  }
  
  public final int getGeneration() {
    return this.generation;
  }
  
  public int hashCode() {
    return (this.workSpecId.hashCode() * 31 + this.generation) * 31 + this.systemId;
  }
  
  public String toString() {
    StringBuilder stringBuilder = new StringBuilder();
    stringBuilder.append("SystemIdInfo(workSpecId=");
    stringBuilder.append(this.workSpecId);
    stringBuilder.append(", generation=");
    stringBuilder.append(this.generation);
    stringBuilder.append(", systemId=");
    stringBuilder.append(this.systemId);
    stringBuilder.append(')');
    return stringBuilder.toString();
  }
}


/* Location:              C:\soft\dex2jar-2.0\MagicAI - AI Art & Anime Art-dex2jar.jar!\androidx\work\impl\model\SystemIdInfo.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */