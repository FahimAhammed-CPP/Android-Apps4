package androidx.work.impl.foreground;

import androidx.annotation.NonNull;
import androidx.annotation.RestrictTo;
import androidx.work.ForegroundInfo;

@RestrictTo({RestrictTo.Scope.LIBRARY_GROUP})
public interface ForegroundProcessor {
  boolean isEnqueuedInForeground(@NonNull String paramString);
  
  void startForeground(@NonNull String paramString, @NonNull ForegroundInfo paramForegroundInfo);
  
  void stopForeground(@NonNull String paramString);
}


/* Location:              C:\soft\dex2jar-2.0\MagicAI - AI Art & Anime Art-dex2jar.jar!\androidx\work\impl\foreground\ForegroundProcessor.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */