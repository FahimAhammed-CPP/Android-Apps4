package androidx.work.impl.workers;

import android.content.Context;
import androidx.work.ListenableWorker;
import androidx.work.Logger;
import androidx.work.Worker;
import androidx.work.WorkerParameters;
import androidx.work.impl.WorkDatabase;
import androidx.work.impl.WorkManagerImpl;
import androidx.work.impl.model.SystemIdInfoDao;
import androidx.work.impl.model.WorkNameDao;
import androidx.work.impl.model.WorkSpecDao;
import androidx.work.impl.model.WorkTagDao;
import java.util.List;
import java.util.concurrent.TimeUnit;
import kotlin.Metadata;
import kotlin.jvm.internal.Intrinsics;

@Metadata(d1 = {"\000\036\n\002\030\002\n\002\030\002\n\000\n\002\030\002\n\000\n\002\030\002\n\002\b\002\n\002\030\002\n\000\b\000\030\0002\0020\001B\025\022\006\020\002\032\0020\003\022\006\020\004\032\0020\005¢\006\002\020\006J\b\020\007\032\0020\bH\026¨\006\t"}, d2 = {"Landroidx/work/impl/workers/DiagnosticsWorker;", "Landroidx/work/Worker;", "context", "Landroid/content/Context;", "parameters", "Landroidx/work/WorkerParameters;", "(Landroid/content/Context;Landroidx/work/WorkerParameters;)V", "doWork", "Landroidx/work/ListenableWorker$Result;", "work-runtime_release"}, k = 1, mv = {1, 7, 1}, xi = 48)
public final class DiagnosticsWorker extends Worker {
  public DiagnosticsWorker(Context paramContext, WorkerParameters paramWorkerParameters) {
    super(paramContext, paramWorkerParameters);
  }
  
  public ListenableWorker.Result doWork() {
    WorkManagerImpl workManagerImpl = WorkManagerImpl.getInstance(getApplicationContext());
    Intrinsics.checkNotNullExpressionValue(workManagerImpl, "getInstance(applicationContext)");
    WorkDatabase workDatabase = workManagerImpl.getWorkDatabase();
    Intrinsics.checkNotNullExpressionValue(workDatabase, "workManager.workDatabase");
    WorkSpecDao workSpecDao = workDatabase.workSpecDao();
    WorkNameDao workNameDao = workDatabase.workNameDao();
    WorkTagDao workTagDao = workDatabase.workTagDao();
    SystemIdInfoDao systemIdInfoDao = workDatabase.systemIdInfoDao();
    List list2 = workSpecDao.getRecentlyCompletedWork(System.currentTimeMillis() - TimeUnit.DAYS.toMillis(1L));
    List list3 = workSpecDao.getRunningWork();
    List list1 = workSpecDao.getAllEligibleWorkSpecsForScheduling(200);
    if ((list2.isEmpty() ^ true) != 0) {
      Logger.get().info(DiagnosticsWorkerKt.access$getTAG$p(), "Recently completed work:\n\n");
      Logger.get().info(DiagnosticsWorkerKt.access$getTAG$p(), DiagnosticsWorkerKt.access$workSpecRows(workNameDao, workTagDao, systemIdInfoDao, list2));
    } 
    if ((list3.isEmpty() ^ true) != 0) {
      Logger.get().info(DiagnosticsWorkerKt.access$getTAG$p(), "Running work:\n\n");
      Logger.get().info(DiagnosticsWorkerKt.access$getTAG$p(), DiagnosticsWorkerKt.access$workSpecRows(workNameDao, workTagDao, systemIdInfoDao, list3));
    } 
    if ((list1.isEmpty() ^ true) != 0) {
      Logger.get().info(DiagnosticsWorkerKt.access$getTAG$p(), "Enqueued work:\n\n");
      Logger.get().info(DiagnosticsWorkerKt.access$getTAG$p(), DiagnosticsWorkerKt.access$workSpecRows(workNameDao, workTagDao, systemIdInfoDao, list1));
    } 
    ListenableWorker.Result result = ListenableWorker.Result.success();
    Intrinsics.checkNotNullExpressionValue(result, "success()");
    return result;
  }
}


/* Location:              C:\soft\dex2jar-2.0\MagicAI - AI Art & Anime Art-dex2jar.jar!\androidx\work\impl\workers\DiagnosticsWorker.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */