package androidx.work.impl.constraints.controllers;

import android.os.Build;
import androidx.work.Logger;
import androidx.work.NetworkType;
import androidx.work.impl.constraints.NetworkState;
import androidx.work.impl.constraints.trackers.ConstraintTracker;
import androidx.work.impl.model.WorkSpec;
import kotlin.Metadata;
import kotlin.jvm.internal.DefaultConstructorMarker;
import kotlin.jvm.internal.Intrinsics;

@Metadata(d1 = {"\000$\n\002\030\002\n\002\030\002\n\002\030\002\n\000\n\002\030\002\n\002\b\002\n\002\020\013\n\000\n\002\030\002\n\002\b\004\030\000 \f2\b\022\004\022\0020\0020\001:\001\fB\023\022\f\020\003\032\b\022\004\022\0020\0020\004¢\006\002\020\005J\020\020\006\032\0020\0072\006\020\b\032\0020\tH\026J\020\020\n\032\0020\0072\006\020\013\032\0020\002H\026¨\006\r"}, d2 = {"Landroidx/work/impl/constraints/controllers/NetworkNotRoamingController;", "Landroidx/work/impl/constraints/controllers/ConstraintController;", "Landroidx/work/impl/constraints/NetworkState;", "tracker", "Landroidx/work/impl/constraints/trackers/ConstraintTracker;", "(Landroidx/work/impl/constraints/trackers/ConstraintTracker;)V", "hasConstraint", "", "workSpec", "Landroidx/work/impl/model/WorkSpec;", "isConstrained", "value", "Companion", "work-runtime_release"}, k = 1, mv = {1, 7, 1}, xi = 48)
public final class NetworkNotRoamingController extends ConstraintController<NetworkState> {
  public static final Companion Companion = new Companion(null);
  
  private static final String TAG;
  
  static {
    String str = Logger.tagWithPrefix("NetworkNotRoamingCtrlr");
    Intrinsics.checkNotNullExpressionValue(str, "tagWithPrefix(\"NetworkNotRoamingCtrlr\")");
    TAG = str;
  }
  
  public NetworkNotRoamingController(ConstraintTracker<NetworkState> paramConstraintTracker) {
    super(paramConstraintTracker);
  }
  
  public boolean hasConstraint(WorkSpec paramWorkSpec) {
    Intrinsics.checkNotNullParameter(paramWorkSpec, "workSpec");
    return (paramWorkSpec.constraints.getRequiredNetworkType() == NetworkType.NOT_ROAMING);
  }
  
  public boolean isConstrained(NetworkState paramNetworkState) {
    Intrinsics.checkNotNullParameter(paramNetworkState, "value");
    int i = Build.VERSION.SDK_INT;
    boolean bool = false;
    if (i < 24) {
      Logger.get().debug(TAG, "Not-roaming network constraint is not supported before API 24, only checking for connected state.");
      if (!paramNetworkState.isConnected())
        return true; 
    } else if (!paramNetworkState.isConnected() || !paramNetworkState.isNotRoaming()) {
      return true;
    } 
    return bool;
  }
  
  @Metadata(d1 = {"\000\022\n\002\030\002\n\002\020\000\n\002\b\002\n\002\020\016\n\000\b\003\030\0002\0020\001B\007\b\002¢\006\002\020\002R\016\020\003\032\0020\004X\004¢\006\002\n\000¨\006\005"}, d2 = {"Landroidx/work/impl/constraints/controllers/NetworkNotRoamingController$Companion;", "", "()V", "TAG", "", "work-runtime_release"}, k = 1, mv = {1, 7, 1}, xi = 48)
  public static final class Companion {
    private Companion() {}
  }
}


/* Location:              C:\soft\dex2jar-2.0\MagicAI - AI Art & Anime Art-dex2jar.jar!\androidx\work\impl\constraints\controllers\NetworkNotRoamingController.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */