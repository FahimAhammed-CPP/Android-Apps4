package androidx.work.impl.constraints.controllers;

import androidx.work.impl.constraints.trackers.BatteryNotLowTracker;
import androidx.work.impl.constraints.trackers.ConstraintTracker;
import androidx.work.impl.model.WorkSpec;
import kotlin.Metadata;
import kotlin.jvm.internal.Intrinsics;

@Metadata(d1 = {"\000\036\n\002\030\002\n\002\030\002\n\002\020\013\n\000\n\002\030\002\n\002\b\003\n\002\030\002\n\002\b\003\030\0002\b\022\004\022\0020\0020\001B\r\022\006\020\003\032\0020\004¢\006\002\020\005J\020\020\006\032\0020\0022\006\020\007\032\0020\bH\026J\020\020\t\032\0020\0022\006\020\n\032\0020\002H\026¨\006\013"}, d2 = {"Landroidx/work/impl/constraints/controllers/BatteryNotLowController;", "Landroidx/work/impl/constraints/controllers/ConstraintController;", "", "tracker", "Landroidx/work/impl/constraints/trackers/BatteryNotLowTracker;", "(Landroidx/work/impl/constraints/trackers/BatteryNotLowTracker;)V", "hasConstraint", "workSpec", "Landroidx/work/impl/model/WorkSpec;", "isConstrained", "value", "work-runtime_release"}, k = 1, mv = {1, 7, 1}, xi = 48)
public final class BatteryNotLowController extends ConstraintController<Boolean> {
  public BatteryNotLowController(BatteryNotLowTracker paramBatteryNotLowTracker) {
    super((ConstraintTracker)paramBatteryNotLowTracker);
  }
  
  public boolean hasConstraint(WorkSpec paramWorkSpec) {
    Intrinsics.checkNotNullParameter(paramWorkSpec, "workSpec");
    return paramWorkSpec.constraints.requiresBatteryNotLow();
  }
  
  public boolean isConstrained(boolean paramBoolean) {
    return paramBoolean ^ true;
  }
}


/* Location:              C:\soft\dex2jar-2.0\MagicAI - AI Art & Anime Art-dex2jar.jar!\androidx\work\impl\constraints\controllers\BatteryNotLowController.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */