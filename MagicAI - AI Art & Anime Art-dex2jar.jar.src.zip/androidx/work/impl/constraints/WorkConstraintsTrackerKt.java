package androidx.work.impl.constraints;

import androidx.work.Logger;
import kotlin.Metadata;
import kotlin.jvm.internal.Intrinsics;

@Metadata(d1 = {"\000\b\n\000\n\002\020\016\n\000\"\016\020\000\032\0020\001X\004¢\006\002\n\000¨\006\002"}, d2 = {"TAG", "", "work-runtime_release"}, k = 2, mv = {1, 7, 1}, xi = 48)
public final class WorkConstraintsTrackerKt {
  private static final String TAG;
  
  static {
    String str = Logger.tagWithPrefix("WorkConstraintsTracker");
    Intrinsics.checkNotNullExpressionValue(str, "tagWithPrefix(\"WorkConstraintsTracker\")");
    TAG = str;
  }
}


/* Location:              C:\soft\dex2jar-2.0\MagicAI - AI Art & Anime Art-dex2jar.jar!\androidx\work\impl\constraints\WorkConstraintsTrackerKt.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */