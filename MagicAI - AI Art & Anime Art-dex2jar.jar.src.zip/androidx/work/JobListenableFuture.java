package androidx.work;

import androidx.work.impl.utils.futures.SettableFuture;
import com.google.common.util.concurrent.ListenableFuture;
import java.util.concurrent.Executor;
import java.util.concurrent.TimeUnit;
import kotlin.Metadata;
import kotlin.Unit;
import kotlin.jvm.functions.Function1;
import kotlin.jvm.internal.DefaultConstructorMarker;
import kotlin.jvm.internal.Lambda;
import kotlinx.coroutines.Job;

@Metadata(d1 = {"\000B\n\002\030\002\n\000\n\002\030\002\n\000\n\002\030\002\n\000\n\002\030\002\n\002\b\002\n\002\020\002\n\000\n\002\030\002\n\002\b\002\n\002\030\002\n\000\n\002\020\013\n\002\b\005\n\002\020\t\n\002\030\002\n\002\b\004\b\000\030\000*\004\b\000\020\0012\b\022\004\022\002H\0010\002B\035\022\006\020\003\032\0020\004\022\016\b\002\020\005\032\b\022\004\022\0028\0000\006¢\006\002\020\007J)\020\b\032\0020\t2\016\020\n\032\n \f*\004\030\0010\0130\0132\016\020\r\032\n \f*\004\030\0010\0160\016H\001J\021\020\017\032\0020\0202\006\020\n\032\0020\020H\001J\023\020\021\032\0020\t2\006\020\022\032\0028\000¢\006\002\020\023J\026\020\024\032\n \f*\004\030\0018\0008\000H\001¢\006\002\020\025J.\020\024\032\n \f*\004\030\0018\0008\0002\006\020\n\032\0020\0262\016\020\r\032\n \f*\004\030\0010\0270\027H\003¢\006\002\020\030J\t\020\031\032\0020\020H\001J\t\020\032\032\0020\020H\001R\016\020\003\032\0020\004X\004¢\006\002\n\000R\024\020\005\032\b\022\004\022\0028\0000\006X\004¢\006\002\n\000¨\006\033"}, d2 = {"Landroidx/work/JobListenableFuture;", "R", "Lcom/google/common/util/concurrent/ListenableFuture;", "job", "Lkotlinx/coroutines/Job;", "underlying", "Landroidx/work/impl/utils/futures/SettableFuture;", "(Lkotlinx/coroutines/Job;Landroidx/work/impl/utils/futures/SettableFuture;)V", "addListener", "", "p0", "Ljava/lang/Runnable;", "kotlin.jvm.PlatformType", "p1", "Ljava/util/concurrent/Executor;", "cancel", "", "complete", "result", "(Ljava/lang/Object;)V", "get", "()Ljava/lang/Object;", "", "Ljava/util/concurrent/TimeUnit;", "(JLjava/util/concurrent/TimeUnit;)Ljava/lang/Object;", "isCancelled", "isDone", "work-runtime-ktx_release"}, k = 1, mv = {1, 7, 1}, xi = 48)
public final class JobListenableFuture<R> implements ListenableFuture<R> {
  private final Job job;
  
  private final SettableFuture<R> underlying;
  
  public JobListenableFuture(Job paramJob, SettableFuture<R> paramSettableFuture) {
    this.job = paramJob;
    this.underlying = paramSettableFuture;
    paramJob.invokeOnCompletion(new Function1<Throwable, Unit>() {
          public final void invoke(Throwable param1Throwable) {
            if (param1Throwable == null) {
              if (JobListenableFuture.this.underlying.isDone())
                return; 
              throw new IllegalArgumentException("Failed requirement.".toString());
            } 
            if (param1Throwable instanceof java.util.concurrent.CancellationException) {
              JobListenableFuture.this.underlying.cancel(true);
              return;
            } 
            SettableFuture settableFuture = JobListenableFuture.this.underlying;
            Throwable throwable = param1Throwable.getCause();
            if (throwable != null)
              param1Throwable = throwable; 
            settableFuture.setException(param1Throwable);
          }
        });
  }
  
  public void addListener(Runnable paramRunnable, Executor paramExecutor) {
    this.underlying.addListener(paramRunnable, paramExecutor);
  }
  
  public boolean cancel(boolean paramBoolean) {
    return this.underlying.cancel(paramBoolean);
  }
  
  public final void complete(R paramR) {
    this.underlying.set(paramR);
  }
  
  public R get() {
    return (R)this.underlying.get();
  }
  
  public R get(long paramLong, TimeUnit paramTimeUnit) {
    return (R)this.underlying.get(paramLong, paramTimeUnit);
  }
  
  public boolean isCancelled() {
    return this.underlying.isCancelled();
  }
  
  public boolean isDone() {
    return this.underlying.isDone();
  }
}


/* Location:              C:\soft\dex2jar-2.0\MagicAI - AI Art & Anime Art-dex2jar.jar!\androidx\work\JobListenableFuture.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */