package androidx.work;

import androidx.annotation.RequiresApi;
import kotlin.Metadata;

@Metadata(d1 = {"\000\f\n\002\030\002\n\002\020\020\n\002\b\b\b\001\030\0002\b\022\004\022\0020\0000\001B\007\b\002¢\006\002\020\002j\002\b\003j\002\b\004j\002\b\005j\002\b\006j\002\b\007j\002\b\b¨\006\t"}, d2 = {"Landroidx/work/NetworkType;", "", "(Ljava/lang/String;I)V", "NOT_REQUIRED", "CONNECTED", "UNMETERED", "NOT_ROAMING", "METERED", "TEMPORARILY_UNMETERED", "work-runtime_release"}, k = 1, mv = {1, 7, 1}, xi = 48)
public enum NetworkType {
  CONNECTED, METERED, NOT_REQUIRED, NOT_ROAMING, TEMPORARILY_UNMETERED, UNMETERED;
  
  static {
    CONNECTED = new NetworkType("CONNECTED", 1);
    UNMETERED = new NetworkType("UNMETERED", 2);
    NOT_ROAMING = new NetworkType("NOT_ROAMING", 3);
    METERED = new NetworkType("METERED", 4);
    TEMPORARILY_UNMETERED = new NetworkType("TEMPORARILY_UNMETERED", 5);
    $VALUES = $values();
  }
}


/* Location:              C:\soft\dex2jar-2.0\MagicAI - AI Art & Anime Art-dex2jar.jar!\androidx\work\NetworkType.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */