package androidx.emoji2.text.flatbuffer;

import java.nio.ByteBuffer;

public final class BooleanVector extends BaseVector {
  public BooleanVector __assign(int paramInt, ByteBuffer paramByteBuffer) {
    __reset(paramInt, 1, paramByteBuffer);
    return this;
  }
  
  public boolean get(int paramInt) {
    return (this.bb.get(__element(paramInt)) != 0);
  }
}


/* Location:              C:\soft\dex2jar-2.0\MagicAI - AI Art & Anime Art-dex2jar.jar!\androidx\emoji2\text\flatbuffer\BooleanVector.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */