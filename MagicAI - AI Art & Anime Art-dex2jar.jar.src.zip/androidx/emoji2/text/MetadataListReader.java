package androidx.emoji2.text;

import android.content.res.AssetManager;
import androidx.annotation.AnyThread;
import androidx.annotation.IntRange;
import androidx.annotation.NonNull;
import androidx.annotation.RequiresApi;
import androidx.annotation.RestrictTo;
import androidx.emoji2.text.flatbuffer.MetadataList;
import java.io.IOException;
import java.io.InputStream;
import java.nio.ByteBuffer;
import java.nio.ByteOrder;

@AnyThread
@RequiresApi(19)
@RestrictTo({RestrictTo.Scope.LIBRARY})
class MetadataListReader {
  private static final int EMJI_TAG = 1164798569;
  
  private static final int EMJI_TAG_DEPRECATED = 1701669481;
  
  private static final int META_TABLE_NAME = 1835365473;
  
  private static OffsetInfo findOffsetInfo(OpenTypeReader paramOpenTypeReader) throws IOException {
    // Byte code:
    //   0: aload_0
    //   1: iconst_4
    //   2: invokeinterface skip : (I)V
    //   7: aload_0
    //   8: invokeinterface readUnsignedShort : ()I
    //   13: istore_3
    //   14: iload_3
    //   15: bipush #100
    //   17: if_icmpgt -> 210
    //   20: aload_0
    //   21: bipush #6
    //   23: invokeinterface skip : (I)V
    //   28: iconst_0
    //   29: istore_2
    //   30: iconst_0
    //   31: istore_1
    //   32: iload_1
    //   33: iload_3
    //   34: if_icmpge -> 84
    //   37: aload_0
    //   38: invokeinterface readTag : ()I
    //   43: istore #4
    //   45: aload_0
    //   46: iconst_4
    //   47: invokeinterface skip : (I)V
    //   52: aload_0
    //   53: invokeinterface readUnsignedInt : ()J
    //   58: lstore #5
    //   60: aload_0
    //   61: iconst_4
    //   62: invokeinterface skip : (I)V
    //   67: ldc 1835365473
    //   69: iload #4
    //   71: if_icmpne -> 77
    //   74: goto -> 89
    //   77: iload_1
    //   78: iconst_1
    //   79: iadd
    //   80: istore_1
    //   81: goto -> 32
    //   84: ldc2_w -1
    //   87: lstore #5
    //   89: lload #5
    //   91: ldc2_w -1
    //   94: lcmp
    //   95: ifeq -> 200
    //   98: aload_0
    //   99: lload #5
    //   101: aload_0
    //   102: invokeinterface getPosition : ()J
    //   107: lsub
    //   108: l2i
    //   109: invokeinterface skip : (I)V
    //   114: aload_0
    //   115: bipush #12
    //   117: invokeinterface skip : (I)V
    //   122: aload_0
    //   123: invokeinterface readUnsignedInt : ()J
    //   128: lstore #7
    //   130: iload_2
    //   131: istore_1
    //   132: iload_1
    //   133: i2l
    //   134: lload #7
    //   136: lcmp
    //   137: ifge -> 200
    //   140: aload_0
    //   141: invokeinterface readTag : ()I
    //   146: istore_2
    //   147: aload_0
    //   148: invokeinterface readUnsignedInt : ()J
    //   153: lstore #9
    //   155: aload_0
    //   156: invokeinterface readUnsignedInt : ()J
    //   161: lstore #11
    //   163: ldc 1164798569
    //   165: iload_2
    //   166: if_icmpeq -> 185
    //   169: ldc 1701669481
    //   171: iload_2
    //   172: if_icmpne -> 178
    //   175: goto -> 185
    //   178: iload_1
    //   179: iconst_1
    //   180: iadd
    //   181: istore_1
    //   182: goto -> 132
    //   185: new androidx/emoji2/text/MetadataListReader$OffsetInfo
    //   188: dup
    //   189: lload #9
    //   191: lload #5
    //   193: ladd
    //   194: lload #11
    //   196: invokespecial <init> : (JJ)V
    //   199: areturn
    //   200: new java/io/IOException
    //   203: dup
    //   204: ldc 'Cannot read metadata.'
    //   206: invokespecial <init> : (Ljava/lang/String;)V
    //   209: athrow
    //   210: new java/io/IOException
    //   213: dup
    //   214: ldc 'Cannot read metadata.'
    //   216: invokespecial <init> : (Ljava/lang/String;)V
    //   219: athrow
  }
  
  static MetadataList read(AssetManager paramAssetManager, String paramString) throws IOException {
    InputStream inputStream = paramAssetManager.open(paramString);
    try {
      return read(inputStream);
    } finally {
      if (inputStream != null)
        try {
          inputStream.close();
        } finally {
          inputStream = null;
        }  
    } 
  }
  
  static MetadataList read(InputStream paramInputStream) throws IOException {
    InputStreamOpenTypeReader inputStreamOpenTypeReader = new InputStreamOpenTypeReader(paramInputStream);
    OffsetInfo offsetInfo = findOffsetInfo(inputStreamOpenTypeReader);
    inputStreamOpenTypeReader.skip((int)(offsetInfo.getStartOffset() - inputStreamOpenTypeReader.getPosition()));
    ByteBuffer byteBuffer = ByteBuffer.allocate((int)offsetInfo.getLength());
    int i = paramInputStream.read(byteBuffer.array());
    if (i == offsetInfo.getLength())
      return MetadataList.getRootAsMetadataList(byteBuffer); 
    StringBuilder stringBuilder = new StringBuilder();
    stringBuilder.append("Needed ");
    stringBuilder.append(offsetInfo.getLength());
    stringBuilder.append(" bytes, got ");
    stringBuilder.append(i);
    throw new IOException(stringBuilder.toString());
  }
  
  static MetadataList read(ByteBuffer paramByteBuffer) throws IOException {
    paramByteBuffer = paramByteBuffer.duplicate();
    paramByteBuffer.position((int)findOffsetInfo(new ByteBufferReader(paramByteBuffer)).getStartOffset());
    return MetadataList.getRootAsMetadataList(paramByteBuffer);
  }
  
  static long toUnsignedInt(int paramInt) {
    return paramInt & 0xFFFFFFFFL;
  }
  
  static int toUnsignedShort(short paramShort) {
    return paramShort & 0xFFFF;
  }
  
  private static class ByteBufferReader implements OpenTypeReader {
    @NonNull
    private final ByteBuffer mByteBuffer;
    
    ByteBufferReader(@NonNull ByteBuffer param1ByteBuffer) {
      this.mByteBuffer = param1ByteBuffer;
      param1ByteBuffer.order(ByteOrder.BIG_ENDIAN);
    }
    
    public long getPosition() {
      return this.mByteBuffer.position();
    }
    
    public int readTag() throws IOException {
      return this.mByteBuffer.getInt();
    }
    
    public long readUnsignedInt() throws IOException {
      return MetadataListReader.toUnsignedInt(this.mByteBuffer.getInt());
    }
    
    public int readUnsignedShort() throws IOException {
      return MetadataListReader.toUnsignedShort(this.mByteBuffer.getShort());
    }
    
    public void skip(int param1Int) throws IOException {
      ByteBuffer byteBuffer = this.mByteBuffer;
      byteBuffer.position(byteBuffer.position() + param1Int);
    }
  }
  
  private static class InputStreamOpenTypeReader implements OpenTypeReader {
    @NonNull
    private final byte[] mByteArray;
    
    @NonNull
    private final ByteBuffer mByteBuffer;
    
    @NonNull
    private final InputStream mInputStream;
    
    private long mPosition = 0L;
    
    InputStreamOpenTypeReader(@NonNull InputStream param1InputStream) {
      this.mInputStream = param1InputStream;
      byte[] arrayOfByte = new byte[4];
      this.mByteArray = arrayOfByte;
      ByteBuffer byteBuffer = ByteBuffer.wrap(arrayOfByte);
      this.mByteBuffer = byteBuffer;
      byteBuffer.order(ByteOrder.BIG_ENDIAN);
    }
    
    private void read(@IntRange(from = 0L, to = 4L) int param1Int) throws IOException {
      if (this.mInputStream.read(this.mByteArray, 0, param1Int) == param1Int) {
        this.mPosition += param1Int;
        return;
      } 
      throw new IOException("read failed");
    }
    
    public long getPosition() {
      return this.mPosition;
    }
    
    public int readTag() throws IOException {
      this.mByteBuffer.position(0);
      read(4);
      return this.mByteBuffer.getInt();
    }
    
    public long readUnsignedInt() throws IOException {
      this.mByteBuffer.position(0);
      read(4);
      return MetadataListReader.toUnsignedInt(this.mByteBuffer.getInt());
    }
    
    public int readUnsignedShort() throws IOException {
      this.mByteBuffer.position(0);
      read(2);
      return MetadataListReader.toUnsignedShort(this.mByteBuffer.getShort());
    }
    
    public void skip(int param1Int) throws IOException {
      while (param1Int > 0) {
        int i = (int)this.mInputStream.skip(param1Int);
        if (i >= 1) {
          param1Int -= i;
          this.mPosition += i;
          continue;
        } 
        throw new IOException("Skip didn't move at least 1 byte forward");
      } 
    }
  }
  
  private static class OffsetInfo {
    private final long mLength;
    
    private final long mStartOffset;
    
    OffsetInfo(long param1Long1, long param1Long2) {
      this.mStartOffset = param1Long1;
      this.mLength = param1Long2;
    }
    
    long getLength() {
      return this.mLength;
    }
    
    long getStartOffset() {
      return this.mStartOffset;
    }
  }
  
  private static interface OpenTypeReader {
    public static final int UINT16_BYTE_COUNT = 2;
    
    public static final int UINT32_BYTE_COUNT = 4;
    
    long getPosition();
    
    int readTag() throws IOException;
    
    long readUnsignedInt() throws IOException;
    
    int readUnsignedShort() throws IOException;
    
    void skip(int param1Int) throws IOException;
  }
}


/* Location:              C:\soft\dex2jar-2.0\MagicAI - AI Art & Anime Art-dex2jar.jar!\androidx\emoji2\text\MetadataListReader.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */