package androidx.emoji2.text;

import android.os.Build;
import android.os.Handler;
import android.os.Looper;
import androidx.annotation.DoNotInline;
import androidx.annotation.NonNull;
import androidx.annotation.RequiresApi;
import androidx.arch.core.executor.DefaultTaskExecutor$Api28Impl$;
import j$.util.Objects;
import java.util.concurrent.Executor;
import java.util.concurrent.LinkedBlockingDeque;
import java.util.concurrent.ThreadFactory;
import java.util.concurrent.ThreadPoolExecutor;
import java.util.concurrent.TimeUnit;

class ConcurrencyHelpers {
  private static final int FONT_LOAD_TIMEOUT_SECONDS = 15;
  
  @Deprecated
  @NonNull
  static Executor convertHandlerToExecutor(@NonNull Handler paramHandler) {
    Objects.requireNonNull(paramHandler);
    return (Executor)new ConcurrencyHelpers$.ExternalSyntheticLambda1(paramHandler);
  }
  
  static ThreadPoolExecutor createBackgroundPriorityExecutor(@NonNull String paramString) {
    ConcurrencyHelpers$.ExternalSyntheticLambda0 externalSyntheticLambda0 = new ConcurrencyHelpers$.ExternalSyntheticLambda0(paramString);
    ThreadPoolExecutor threadPoolExecutor = new ThreadPoolExecutor(0, 1, 15L, TimeUnit.SECONDS, new LinkedBlockingDeque<Runnable>(), (ThreadFactory)externalSyntheticLambda0);
    threadPoolExecutor.allowCoreThreadTimeOut(true);
    return threadPoolExecutor;
  }
  
  static Handler mainHandlerAsync() {
    return (Build.VERSION.SDK_INT >= 28) ? Handler28Impl.createAsync(Looper.getMainLooper()) : new Handler(Looper.getMainLooper());
  }
  
  @RequiresApi(28)
  static class Handler28Impl {
    @DoNotInline
    public static Handler createAsync(Looper param1Looper) {
      return DefaultTaskExecutor$Api28Impl$.ExternalSyntheticApiModelOutline0.m(param1Looper);
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\MagicAI - AI Art & Anime Art-dex2jar.jar!\androidx\emoji2\text\ConcurrencyHelpers.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */