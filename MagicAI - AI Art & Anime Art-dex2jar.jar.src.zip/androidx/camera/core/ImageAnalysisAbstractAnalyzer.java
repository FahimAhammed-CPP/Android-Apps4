package androidx.camera.core;

import android.graphics.Matrix;
import android.graphics.Rect;
import android.graphics.RectF;
import android.media.ImageWriter;
import android.os.Build;
import androidx.annotation.GuardedBy;
import androidx.annotation.IntRange;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.annotation.RequiresApi;
import androidx.annotation.VisibleForTesting;
import androidx.camera.core.impl.ImageReaderProxy;
import androidx.camera.core.impl.TagBundle;
import androidx.camera.core.impl.utils.TransformUtils;
import androidx.camera.core.internal.compat.ImageWriterCompat;
import androidx.concurrent.futures.CallbackToFutureAdapter;
import androidx.core.os.OperationCanceledException;
import com.google.common.util.concurrent.ListenableFuture;
import java.nio.ByteBuffer;
import java.util.concurrent.Executor;

@RequiresApi(21)
abstract class ImageAnalysisAbstractAnalyzer implements ImageReaderProxy.OnImageAvailableListener {
  private static final String TAG = "ImageAnalysisAnalyzer";
  
  private final Object mAnalyzerLock = new Object();
  
  protected boolean mIsAttached = true;
  
  private volatile boolean mOnePixelShiftEnabled;
  
  @GuardedBy("mAnalyzerLock")
  private Matrix mOriginalSensorToBufferTransformMatrix = new Matrix();
  
  @GuardedBy("mAnalyzerLock")
  private Rect mOriginalViewPortCropRect = new Rect();
  
  private volatile int mOutputImageFormat = 1;
  
  private volatile boolean mOutputImageRotationEnabled;
  
  @IntRange(from = 0L, to = 359L)
  private volatile int mPrevBufferRotationDegrees;
  
  @GuardedBy("mAnalyzerLock")
  @Nullable
  private SafeCloseImageReaderProxy mProcessedImageReaderProxy;
  
  @GuardedBy("mAnalyzerLock")
  @Nullable
  private ImageWriter mProcessedImageWriter;
  
  @GuardedBy("mAnalyzerLock")
  @Nullable
  @VisibleForTesting
  ByteBuffer mRGBConvertedBuffer;
  
  @IntRange(from = 0L, to = 359L)
  private volatile int mRelativeRotation;
  
  @GuardedBy("mAnalyzerLock")
  private ImageAnalysis.Analyzer mSubscribedAnalyzer;
  
  @GuardedBy("mAnalyzerLock")
  @Nullable
  @VisibleForTesting
  ByteBuffer mURotatedBuffer;
  
  @GuardedBy("mAnalyzerLock")
  private Matrix mUpdatedSensorToBufferTransformMatrix = new Matrix();
  
  @GuardedBy("mAnalyzerLock")
  private Rect mUpdatedViewPortCropRect = new Rect();
  
  @GuardedBy("mAnalyzerLock")
  private Executor mUserExecutor;
  
  @GuardedBy("mAnalyzerLock")
  @Nullable
  @VisibleForTesting
  ByteBuffer mVRotatedBuffer;
  
  @GuardedBy("mAnalyzerLock")
  @Nullable
  @VisibleForTesting
  ByteBuffer mYRotatedBuffer;
  
  @GuardedBy("mAnalyzerLock")
  private void createHelperBuffer(@NonNull ImageProxy paramImageProxy) {
    if (this.mOutputImageFormat == 1) {
      if (this.mYRotatedBuffer == null)
        this.mYRotatedBuffer = ByteBuffer.allocateDirect(paramImageProxy.getWidth() * paramImageProxy.getHeight()); 
      this.mYRotatedBuffer.position(0);
      if (this.mURotatedBuffer == null)
        this.mURotatedBuffer = ByteBuffer.allocateDirect(paramImageProxy.getWidth() * paramImageProxy.getHeight() / 4); 
      this.mURotatedBuffer.position(0);
      if (this.mVRotatedBuffer == null)
        this.mVRotatedBuffer = ByteBuffer.allocateDirect(paramImageProxy.getWidth() * paramImageProxy.getHeight() / 4); 
      this.mVRotatedBuffer.position(0);
      return;
    } 
    if (this.mOutputImageFormat == 2 && this.mRGBConvertedBuffer == null)
      this.mRGBConvertedBuffer = ByteBuffer.allocateDirect(paramImageProxy.getWidth() * paramImageProxy.getHeight() * 4); 
  }
  
  @NonNull
  private static SafeCloseImageReaderProxy createImageReaderProxy(int paramInt1, int paramInt2, int paramInt3, int paramInt4, int paramInt5) {
    int i;
    if (paramInt3 == 90 || paramInt3 == 270) {
      paramInt3 = 1;
    } else {
      paramInt3 = 0;
    } 
    if (paramInt3 != 0) {
      i = paramInt2;
    } else {
      i = paramInt1;
    } 
    if (paramInt3 == 0)
      paramInt1 = paramInt2; 
    return new SafeCloseImageReaderProxy(ImageReaderProxys.createIsolatedReader(i, paramInt1, paramInt4, paramInt5));
  }
  
  @NonNull
  @VisibleForTesting
  static Matrix getAdditionalTransformMatrixAppliedByProcessor(int paramInt1, int paramInt2, int paramInt3, int paramInt4, @IntRange(from = 0L, to = 359L) int paramInt5) {
    Matrix matrix = new Matrix();
    if (paramInt5 > 0) {
      matrix.setRectToRect(new RectF(0.0F, 0.0F, paramInt1, paramInt2), TransformUtils.NORMALIZED_RECT, Matrix.ScaleToFit.FILL);
      matrix.postRotate(paramInt5);
      matrix.postConcat(TransformUtils.getNormalizedToBuffer(new RectF(0.0F, 0.0F, paramInt3, paramInt4)));
    } 
    return matrix;
  }
  
  @NonNull
  static Rect getUpdatedCropRect(@NonNull Rect paramRect, @NonNull Matrix paramMatrix) {
    RectF rectF = new RectF(paramRect);
    paramMatrix.mapRect(rectF);
    Rect rect = new Rect();
    rectF.round(rect);
    return rect;
  }
  
  @GuardedBy("mAnalyzerLock")
  private void recalculateTransformMatrixAndCropRect(int paramInt1, int paramInt2, int paramInt3, int paramInt4) {
    Matrix matrix = getAdditionalTransformMatrixAppliedByProcessor(paramInt1, paramInt2, paramInt3, paramInt4, this.mRelativeRotation);
    this.mUpdatedViewPortCropRect = getUpdatedCropRect(this.mOriginalViewPortCropRect, matrix);
    this.mUpdatedSensorToBufferTransformMatrix.setConcat(this.mOriginalSensorToBufferTransformMatrix, matrix);
  }
  
  @GuardedBy("mAnalyzerLock")
  private void recreateImageReaderProxy(@NonNull ImageProxy paramImageProxy, @IntRange(from = 0L, to = 359L) int paramInt) {
    SafeCloseImageReaderProxy safeCloseImageReaderProxy = this.mProcessedImageReaderProxy;
    if (safeCloseImageReaderProxy == null)
      return; 
    safeCloseImageReaderProxy.safeClose();
    this.mProcessedImageReaderProxy = createImageReaderProxy(paramImageProxy.getWidth(), paramImageProxy.getHeight(), paramInt, this.mProcessedImageReaderProxy.getImageFormat(), this.mProcessedImageReaderProxy.getMaxImages());
    if (Build.VERSION.SDK_INT >= 23 && this.mOutputImageFormat == 1) {
      ImageWriter imageWriter = this.mProcessedImageWriter;
      if (imageWriter != null)
        ImageWriterCompat.close(imageWriter); 
      this.mProcessedImageWriter = ImageWriterCompat.newInstance(this.mProcessedImageReaderProxy.getSurface(), this.mProcessedImageReaderProxy.getMaxImages());
    } 
  }
  
  @Nullable
  abstract ImageProxy acquireImage(@NonNull ImageReaderProxy paramImageReaderProxy);
  
  ListenableFuture<Void> analyzeImage(@NonNull ImageProxy paramImageProxy) {
    // Byte code:
    //   0: aload_0
    //   1: getfield mOutputImageRotationEnabled : Z
    //   4: istore #5
    //   6: iconst_0
    //   7: istore #4
    //   9: iload #5
    //   11: ifeq -> 22
    //   14: aload_0
    //   15: getfield mRelativeRotation : I
    //   18: istore_2
    //   19: goto -> 24
    //   22: iconst_0
    //   23: istore_2
    //   24: aload_0
    //   25: getfield mAnalyzerLock : Ljava/lang/Object;
    //   28: astore #6
    //   30: aload #6
    //   32: monitorenter
    //   33: aload_0
    //   34: getfield mUserExecutor : Ljava/util/concurrent/Executor;
    //   37: astore #7
    //   39: aload_0
    //   40: getfield mSubscribedAnalyzer : Landroidx/camera/core/ImageAnalysis$Analyzer;
    //   43: astore #8
    //   45: aload_0
    //   46: getfield mOutputImageRotationEnabled : Z
    //   49: ifeq -> 397
    //   52: iload_2
    //   53: aload_0
    //   54: getfield mPrevBufferRotationDegrees : I
    //   57: if_icmpeq -> 397
    //   60: iconst_1
    //   61: istore_3
    //   62: goto -> 65
    //   65: iload_3
    //   66: ifeq -> 75
    //   69: aload_0
    //   70: aload_1
    //   71: iload_2
    //   72: invokespecial recreateImageReaderProxy : (Landroidx/camera/core/ImageProxy;I)V
    //   75: aload_0
    //   76: getfield mOutputImageRotationEnabled : Z
    //   79: ifeq -> 87
    //   82: aload_0
    //   83: aload_1
    //   84: invokespecial createHelperBuffer : (Landroidx/camera/core/ImageProxy;)V
    //   87: aload_0
    //   88: getfield mProcessedImageReaderProxy : Landroidx/camera/core/SafeCloseImageReaderProxy;
    //   91: astore #9
    //   93: aload_0
    //   94: getfield mProcessedImageWriter : Landroid/media/ImageWriter;
    //   97: astore #10
    //   99: aload_0
    //   100: getfield mRGBConvertedBuffer : Ljava/nio/ByteBuffer;
    //   103: astore #11
    //   105: aload_0
    //   106: getfield mYRotatedBuffer : Ljava/nio/ByteBuffer;
    //   109: astore #12
    //   111: aload_0
    //   112: getfield mURotatedBuffer : Ljava/nio/ByteBuffer;
    //   115: astore #13
    //   117: aload_0
    //   118: getfield mVRotatedBuffer : Ljava/nio/ByteBuffer;
    //   121: astore #14
    //   123: aload #6
    //   125: monitorexit
    //   126: aload #8
    //   128: ifnull -> 377
    //   131: aload #7
    //   133: ifnull -> 377
    //   136: aload_0
    //   137: getfield mIsAttached : Z
    //   140: ifeq -> 377
    //   143: aload #9
    //   145: ifnull -> 234
    //   148: aload_0
    //   149: getfield mOutputImageFormat : I
    //   152: iconst_2
    //   153: if_icmpne -> 174
    //   156: aload_1
    //   157: aload #9
    //   159: aload #11
    //   161: iload_2
    //   162: aload_0
    //   163: getfield mOnePixelShiftEnabled : Z
    //   166: invokestatic convertYUVToRGB : (Landroidx/camera/core/ImageProxy;Landroidx/camera/core/impl/ImageReaderProxy;Ljava/nio/ByteBuffer;IZ)Landroidx/camera/core/ImageProxy;
    //   169: astore #6
    //   171: goto -> 237
    //   174: aload_0
    //   175: getfield mOutputImageFormat : I
    //   178: iconst_1
    //   179: if_icmpne -> 234
    //   182: aload_0
    //   183: getfield mOnePixelShiftEnabled : Z
    //   186: ifeq -> 194
    //   189: aload_1
    //   190: invokestatic applyPixelShiftForYUV : (Landroidx/camera/core/ImageProxy;)Z
    //   193: pop
    //   194: aload #10
    //   196: ifnull -> 234
    //   199: aload #12
    //   201: ifnull -> 234
    //   204: aload #13
    //   206: ifnull -> 234
    //   209: aload #14
    //   211: ifnull -> 234
    //   214: aload_1
    //   215: aload #9
    //   217: aload #10
    //   219: aload #12
    //   221: aload #13
    //   223: aload #14
    //   225: iload_2
    //   226: invokestatic rotateYUV : (Landroidx/camera/core/ImageProxy;Landroidx/camera/core/impl/ImageReaderProxy;Landroid/media/ImageWriter;Ljava/nio/ByteBuffer;Ljava/nio/ByteBuffer;Ljava/nio/ByteBuffer;I)Landroidx/camera/core/ImageProxy;
    //   229: astore #6
    //   231: goto -> 237
    //   234: aconst_null
    //   235: astore #6
    //   237: aload #6
    //   239: ifnonnull -> 245
    //   242: iconst_1
    //   243: istore #4
    //   245: iload #4
    //   247: ifeq -> 256
    //   250: aload_1
    //   251: astore #6
    //   253: goto -> 256
    //   256: new android/graphics/Rect
    //   259: dup
    //   260: invokespecial <init> : ()V
    //   263: astore #10
    //   265: new android/graphics/Matrix
    //   268: dup
    //   269: invokespecial <init> : ()V
    //   272: astore #11
    //   274: aload_0
    //   275: getfield mAnalyzerLock : Ljava/lang/Object;
    //   278: astore #9
    //   280: aload #9
    //   282: monitorenter
    //   283: iload_3
    //   284: ifeq -> 322
    //   287: iload #4
    //   289: ifne -> 322
    //   292: aload_0
    //   293: aload_1
    //   294: invokeinterface getWidth : ()I
    //   299: aload_1
    //   300: invokeinterface getHeight : ()I
    //   305: aload #6
    //   307: invokeinterface getWidth : ()I
    //   312: aload #6
    //   314: invokeinterface getHeight : ()I
    //   319: invokespecial recalculateTransformMatrixAndCropRect : (IIII)V
    //   322: aload_0
    //   323: iload_2
    //   324: putfield mPrevBufferRotationDegrees : I
    //   327: aload #10
    //   329: aload_0
    //   330: getfield mUpdatedViewPortCropRect : Landroid/graphics/Rect;
    //   333: invokevirtual set : (Landroid/graphics/Rect;)V
    //   336: aload #11
    //   338: aload_0
    //   339: getfield mUpdatedSensorToBufferTransformMatrix : Landroid/graphics/Matrix;
    //   342: invokevirtual set : (Landroid/graphics/Matrix;)V
    //   345: aload #9
    //   347: monitorexit
    //   348: new androidx/camera/core/ImageAnalysisAbstractAnalyzer$$ExternalSyntheticLambda0
    //   351: dup
    //   352: aload_0
    //   353: aload #7
    //   355: aload_1
    //   356: aload #11
    //   358: aload #6
    //   360: aload #10
    //   362: aload #8
    //   364: invokespecial <init> : (Landroidx/camera/core/ImageAnalysisAbstractAnalyzer;Ljava/util/concurrent/Executor;Landroidx/camera/core/ImageProxy;Landroid/graphics/Matrix;Landroidx/camera/core/ImageProxy;Landroid/graphics/Rect;Landroidx/camera/core/ImageAnalysis$Analyzer;)V
    //   367: invokestatic getFuture : (Landroidx/concurrent/futures/CallbackToFutureAdapter$Resolver;)Lcom/google/common/util/concurrent/ListenableFuture;
    //   370: areturn
    //   371: astore_1
    //   372: aload #9
    //   374: monitorexit
    //   375: aload_1
    //   376: athrow
    //   377: new androidx/core/os/OperationCanceledException
    //   380: dup
    //   381: ldc_w 'No analyzer or executor currently set.'
    //   384: invokespecial <init> : (Ljava/lang/String;)V
    //   387: invokestatic immediateFailedFuture : (Ljava/lang/Throwable;)Lcom/google/common/util/concurrent/ListenableFuture;
    //   390: areturn
    //   391: astore_1
    //   392: aload #6
    //   394: monitorexit
    //   395: aload_1
    //   396: athrow
    //   397: iconst_0
    //   398: istore_3
    //   399: goto -> 65
    // Exception table:
    //   from	to	target	type
    //   33	60	391	finally
    //   69	75	391	finally
    //   75	87	391	finally
    //   87	126	391	finally
    //   292	322	371	finally
    //   322	348	371	finally
    //   372	375	371	finally
    //   392	395	391	finally
  }
  
  void attach() {
    this.mIsAttached = true;
  }
  
  abstract void clearCache();
  
  void detach() {
    this.mIsAttached = false;
    clearCache();
  }
  
  public void onImageAvailable(@NonNull ImageReaderProxy paramImageReaderProxy) {
    try {
      ImageProxy imageProxy = acquireImage(paramImageReaderProxy);
      if (imageProxy != null) {
        onValidImageAvailable(imageProxy);
        return;
      } 
    } catch (IllegalStateException illegalStateException) {
      Logger.e("ImageAnalysisAnalyzer", "Failed to acquire image.", illegalStateException);
    } 
  }
  
  abstract void onValidImageAvailable(@NonNull ImageProxy paramImageProxy);
  
  void setAnalyzer(@Nullable Executor paramExecutor, @Nullable ImageAnalysis.Analyzer paramAnalyzer) {
    if (paramAnalyzer == null)
      clearCache(); 
    synchronized (this.mAnalyzerLock) {
      this.mSubscribedAnalyzer = paramAnalyzer;
      this.mUserExecutor = paramExecutor;
      return;
    } 
  }
  
  void setOnePixelShiftEnabled(boolean paramBoolean) {
    this.mOnePixelShiftEnabled = paramBoolean;
  }
  
  void setOutputImageFormat(int paramInt) {
    this.mOutputImageFormat = paramInt;
  }
  
  void setOutputImageRotationEnabled(boolean paramBoolean) {
    this.mOutputImageRotationEnabled = paramBoolean;
  }
  
  void setProcessedImageReaderProxy(@NonNull SafeCloseImageReaderProxy paramSafeCloseImageReaderProxy) {
    synchronized (this.mAnalyzerLock) {
      this.mProcessedImageReaderProxy = paramSafeCloseImageReaderProxy;
      return;
    } 
  }
  
  void setRelativeRotation(int paramInt) {
    this.mRelativeRotation = paramInt;
  }
  
  void setSensorToBufferTransformMatrix(@NonNull Matrix paramMatrix) {
    synchronized (this.mAnalyzerLock) {
      this.mOriginalSensorToBufferTransformMatrix = paramMatrix;
      this.mUpdatedSensorToBufferTransformMatrix = new Matrix(this.mOriginalSensorToBufferTransformMatrix);
      return;
    } 
  }
  
  void setViewPortCropRect(@NonNull Rect paramRect) {
    synchronized (this.mAnalyzerLock) {
      this.mOriginalViewPortCropRect = paramRect;
      this.mUpdatedViewPortCropRect = new Rect(this.mOriginalViewPortCropRect);
      return;
    } 
  }
}


/* Location:              C:\soft\dex2jar-2.0\MagicAI - AI Art & Anime Art-dex2jar.jar!\androidx\camera\core\ImageAnalysisAbstractAnalyzer.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */