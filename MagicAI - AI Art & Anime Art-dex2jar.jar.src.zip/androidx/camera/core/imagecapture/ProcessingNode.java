package androidx.camera.core.imagecapture;

import android.graphics.Bitmap;
import androidx.annotation.NonNull;
import androidx.annotation.RequiresApi;
import androidx.annotation.VisibleForTesting;
import androidx.annotation.WorkerThread;
import androidx.camera.core.ImageCapture;
import androidx.camera.core.ImageCaptureException;
import androidx.camera.core.ImageProxy;
import androidx.camera.core.impl.utils.executor.CameraXExecutors;
import androidx.camera.core.processing.Edge;
import androidx.camera.core.processing.Node;
import androidx.camera.core.processing.Operation;
import androidx.camera.core.processing.Packet;
import androidx.core.util.Consumer;
import j$.util.Objects;
import java.util.concurrent.Executor;

@RequiresApi(api = 21)
public class ProcessingNode implements Node<ProcessingNode.In, Void> {
  private Operation<Bitmap2JpegBytes.In, Packet<byte[]>> mBitmap2JpegBytes;
  
  @NonNull
  private final Executor mBlockingExecutor;
  
  private Operation<Image2JpegBytes.In, Packet<byte[]>> mImage2JpegBytes;
  
  private Operation<InputPacket, Packet<ImageProxy>> mInput2Packet;
  
  private Operation<Packet<byte[]>, Packet<Bitmap>> mJpegBytes2CroppedBitmap;
  
  private Operation<JpegBytes2Disk.In, ImageCapture.OutputFileResults> mJpegBytes2Disk;
  
  private Operation<Packet<byte[]>, Packet<ImageProxy>> mJpegBytes2Image;
  
  private Operation<Packet<ImageProxy>, ImageProxy> mJpegImage2Result;
  
  ProcessingNode(@NonNull Executor paramExecutor) {
    this.mBlockingExecutor = paramExecutor;
  }
  
  private static void sendError(@NonNull ProcessingRequest paramProcessingRequest, @NonNull ImageCaptureException paramImageCaptureException) {
    CameraXExecutors.mainThreadExecutor().execute((Runnable)new ProcessingNode$.ExternalSyntheticLambda1(paramProcessingRequest, paramImageCaptureException));
  }
  
  @VisibleForTesting
  void injectJpegBytes2CroppedBitmapForTesting(@NonNull Operation<Packet<byte[]>, Packet<Bitmap>> paramOperation) {
    this.mJpegBytes2CroppedBitmap = paramOperation;
  }
  
  @NonNull
  @WorkerThread
  ImageProxy processInMemoryCapture(@NonNull InputPacket paramInputPacket) throws ImageCaptureException {
    ProcessingRequest processingRequest = paramInputPacket.getProcessingRequest();
    Packet packet2 = (Packet)this.mInput2Packet.apply(paramInputPacket);
    Packet packet1 = packet2;
    if (packet2.getFormat() == 35) {
      packet1 = (Packet)this.mImage2JpegBytes.apply(Image2JpegBytes.In.of(packet2, processingRequest.getJpegQuality()));
      packet1 = (Packet)this.mJpegBytes2Image.apply(packet1);
    } 
    return (ImageProxy)this.mJpegImage2Result.apply(packet1);
  }
  
  @WorkerThread
  void processInputPacket(@NonNull InputPacket paramInputPacket) {
    ProcessingRequest processingRequest = paramInputPacket.getProcessingRequest();
    try {
      ImageProxy imageProxy;
      if (paramInputPacket.getProcessingRequest().isInMemoryCapture()) {
        imageProxy = processInMemoryCapture(paramInputPacket);
        CameraXExecutors.mainThreadExecutor().execute((Runnable)new ProcessingNode$.ExternalSyntheticLambda3(processingRequest, imageProxy));
        return;
      } 
      ImageCapture.OutputFileResults outputFileResults = processOnDiskCapture((InputPacket)imageProxy);
      CameraXExecutors.mainThreadExecutor().execute((Runnable)new ProcessingNode$.ExternalSyntheticLambda4(processingRequest, outputFileResults));
      return;
    } catch (ImageCaptureException imageCaptureException) {
      sendError(processingRequest, imageCaptureException);
      return;
    } catch (RuntimeException runtimeException) {
      sendError(processingRequest, new ImageCaptureException(0, "Processing failed.", runtimeException));
      return;
    } 
  }
  
  @NonNull
  @WorkerThread
  ImageCapture.OutputFileResults processOnDiskCapture(@NonNull InputPacket paramInputPacket) throws ImageCaptureException {
    ProcessingRequest processingRequest = paramInputPacket.getProcessingRequest();
    Packet packet1 = (Packet)this.mInput2Packet.apply(paramInputPacket);
    Packet packet2 = (Packet)this.mImage2JpegBytes.apply(Image2JpegBytes.In.of(packet1, processingRequest.getJpegQuality()));
    packet1 = packet2;
    if (packet2.hasCropping()) {
      packet1 = (Packet)this.mJpegBytes2CroppedBitmap.apply(packet2);
      packet1 = (Packet)this.mBitmap2JpegBytes.apply(Bitmap2JpegBytes.In.of(packet1, processingRequest.getJpegQuality()));
    } 
    Operation<JpegBytes2Disk.In, ImageCapture.OutputFileResults> operation = this.mJpegBytes2Disk;
    ImageCapture.OutputFileOptions outputFileOptions = processingRequest.getOutputFileOptions();
    Objects.requireNonNull(outputFileOptions);
    return (ImageCapture.OutputFileResults)operation.apply(JpegBytes2Disk.In.of(packet1, outputFileOptions));
  }
  
  public void release() {}
  
  @NonNull
  public Void transform(@NonNull In paramIn) {
    paramIn.getEdge().setListener((Consumer)new ProcessingNode$.ExternalSyntheticLambda0(this));
    this.mInput2Packet = (Operation<InputPacket, Packet<ImageProxy>>)new ProcessingInput2Packet();
    this.mImage2JpegBytes = (Operation<Image2JpegBytes.In, Packet<byte[]>>)new Image2JpegBytes();
    this.mJpegBytes2CroppedBitmap = (Operation<Packet<byte[]>, Packet<Bitmap>>)new JpegBytes2CroppedBitmap();
    this.mBitmap2JpegBytes = (Operation<Bitmap2JpegBytes.In, Packet<byte[]>>)new Bitmap2JpegBytes();
    this.mJpegBytes2Disk = (Operation<JpegBytes2Disk.In, ImageCapture.OutputFileResults>)new JpegBytes2Disk();
    this.mJpegImage2Result = (Operation<Packet<ImageProxy>, ImageProxy>)new JpegImage2Result();
    if (paramIn.getFormat() == 35)
      this.mJpegBytes2Image = new JpegBytes2Image(); 
    return null;
  }
  
  static abstract class In {
    static In of(int param1Int) {
      return (In)new AutoValue_ProcessingNode_In(new Edge(), param1Int);
    }
    
    abstract Edge<ProcessingNode.InputPacket> getEdge();
    
    abstract int getFormat();
  }
  
  static abstract class InputPacket {
    static InputPacket of(@NonNull ProcessingRequest param1ProcessingRequest, @NonNull ImageProxy param1ImageProxy) {
      return (InputPacket)new AutoValue_ProcessingNode_InputPacket(param1ProcessingRequest, param1ImageProxy);
    }
    
    @NonNull
    abstract ImageProxy getImageProxy();
    
    @NonNull
    abstract ProcessingRequest getProcessingRequest();
  }
}


/* Location:              C:\soft\dex2jar-2.0\MagicAI - AI Art & Anime Art-dex2jar.jar!\androidx\camera\core\imagecapture\ProcessingNode.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */