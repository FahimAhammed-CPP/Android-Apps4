package androidx.camera.core.imagecapture;

import androidx.annotation.NonNull;
import androidx.annotation.RequiresApi;
import androidx.camera.core.ImageCaptureException;
import androidx.camera.core.ImageProcessingUtil;
import androidx.camera.core.ImageProxy;
import androidx.camera.core.ImageReaderProxys;
import androidx.camera.core.SafeCloseImageReaderProxy;
import androidx.camera.core.impl.ImageReaderProxy;
import androidx.camera.core.impl.utils.Exif;
import androidx.camera.core.processing.Operation;
import androidx.camera.core.processing.Packet;
import j$.util.Objects;

@RequiresApi(api = 21)
public class JpegBytes2Image implements Operation<Packet<byte[]>, Packet<ImageProxy>> {
  private static final int MAX_IMAGES = 2;
  
  @NonNull
  public Packet<ImageProxy> apply(@NonNull Packet<byte[]> paramPacket) throws ImageCaptureException {
    SafeCloseImageReaderProxy safeCloseImageReaderProxy = new SafeCloseImageReaderProxy(ImageReaderProxys.createIsolatedReader(paramPacket.getSize().getWidth(), paramPacket.getSize().getHeight(), 256, 2));
    ImageProxy imageProxy2 = ImageProcessingUtil.convertJpegBytesToImage((ImageReaderProxy)safeCloseImageReaderProxy, (byte[])paramPacket.getData());
    safeCloseImageReaderProxy.safeClose();
    Objects.requireNonNull(imageProxy2);
    ImageProxy imageProxy1 = imageProxy2;
    Exif exif = paramPacket.getExif();
    Objects.requireNonNull(exif);
    return Packet.of(imageProxy1, exif, paramPacket.getCropRect(), paramPacket.getRotationDegrees(), paramPacket.getSensorToBufferTransform(), paramPacket.getCameraCaptureResult());
  }
}


/* Location:              C:\soft\dex2jar-2.0\MagicAI - AI Art & Anime Art-dex2jar.jar!\androidx\camera\core\imagecapture\JpegBytes2Image.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */