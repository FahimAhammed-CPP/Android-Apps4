package androidx.camera.core.imagecapture;

import androidx.annotation.NonNull;
import androidx.camera.core.ImageCapture;
import androidx.camera.core.processing.Packet;

final class AutoValue_JpegBytes2Disk_In extends JpegBytes2Disk.In {
  private final ImageCapture.OutputFileOptions outputFileOptions;
  
  private final Packet<byte[]> packet;
  
  AutoValue_JpegBytes2Disk_In(Packet<byte[]> paramPacket, ImageCapture.OutputFileOptions paramOutputFileOptions) {
    if (paramPacket != null) {
      this.packet = paramPacket;
      if (paramOutputFileOptions != null) {
        this.outputFileOptions = paramOutputFileOptions;
        return;
      } 
      throw new NullPointerException("Null outputFileOptions");
    } 
    throw new NullPointerException("Null packet");
  }
  
  public boolean equals(Object paramObject) {
    if (paramObject == this)
      return true; 
    if (paramObject instanceof JpegBytes2Disk.In) {
      paramObject = paramObject;
      return (this.packet.equals(paramObject.getPacket()) && this.outputFileOptions.equals(paramObject.getOutputFileOptions()));
    } 
    return false;
  }
  
  @NonNull
  ImageCapture.OutputFileOptions getOutputFileOptions() {
    return this.outputFileOptions;
  }
  
  @NonNull
  Packet<byte[]> getPacket() {
    return this.packet;
  }
  
  public int hashCode() {
    return (this.packet.hashCode() ^ 0xF4243) * 1000003 ^ this.outputFileOptions.hashCode();
  }
  
  public String toString() {
    StringBuilder stringBuilder = new StringBuilder();
    stringBuilder.append("In{packet=");
    stringBuilder.append(this.packet);
    stringBuilder.append(", outputFileOptions=");
    stringBuilder.append(this.outputFileOptions);
    stringBuilder.append("}");
    return stringBuilder.toString();
  }
}


/* Location:              C:\soft\dex2jar-2.0\MagicAI - AI Art & Anime Art-dex2jar.jar!\androidx\camera\core\imagecapture\AutoValue_JpegBytes2Disk_In.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */