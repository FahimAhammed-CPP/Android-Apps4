package androidx.camera.core.imagecapture;

import androidx.concurrent.futures.CallbackToFutureAdapter;



/* Location:              C:\soft\dex2jar-2.0\MagicAI - AI Art & Anime Art-dex2jar.jar!\androidx\camera\core\imagecapture\RequestWithCallback$$ExternalSyntheticLambda0.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */