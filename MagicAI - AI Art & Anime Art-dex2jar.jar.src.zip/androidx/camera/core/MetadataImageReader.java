package androidx.camera.core;

import android.media.ImageReader;
import android.util.LongSparseArray;
import android.view.Surface;
import androidx.annotation.GuardedBy;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.annotation.RequiresApi;
import androidx.annotation.RestrictTo;
import androidx.camera.core.impl.CameraCaptureCallback;
import androidx.camera.core.impl.CameraCaptureResult;
import androidx.camera.core.impl.ImageReaderProxy;
import androidx.camera.core.internal.CameraCaptureResultImageInfo;
import androidx.core.util.Preconditions;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.concurrent.Executor;

@RequiresApi(21)
@RestrictTo({RestrictTo.Scope.LIBRARY_GROUP})
public class MetadataImageReader implements ImageReaderProxy, ForwardingImageProxy.OnImageCloseListener {
  private static final String TAG = "MetadataImageReader";
  
  @GuardedBy("mLock")
  private final List<ImageProxy> mAcquiredImageProxies = new ArrayList<ImageProxy>();
  
  private CameraCaptureCallback mCameraCaptureCallback = new CameraCaptureCallback() {
      public void onCaptureCompleted(@NonNull CameraCaptureResult param1CameraCaptureResult) {
        super.onCaptureCompleted(param1CameraCaptureResult);
        MetadataImageReader.this.resultIncoming(param1CameraCaptureResult);
      }
    };
  
  @GuardedBy("mLock")
  private boolean mClosed = false;
  
  @GuardedBy("mLock")
  @Nullable
  private Executor mExecutor;
  
  @GuardedBy("mLock")
  private int mImageProxiesIndex;
  
  @GuardedBy("mLock")
  private final ImageReaderProxy mImageReaderProxy;
  
  @GuardedBy("mLock")
  @Nullable
  ImageReaderProxy.OnImageAvailableListener mListener;
  
  private final Object mLock = new Object();
  
  @GuardedBy("mLock")
  private final List<ImageProxy> mMatchedImageProxies;
  
  @GuardedBy("mLock")
  private final LongSparseArray<ImageInfo> mPendingImageInfos = new LongSparseArray();
  
  @GuardedBy("mLock")
  private final LongSparseArray<ImageProxy> mPendingImages = new LongSparseArray();
  
  private ImageReaderProxy.OnImageAvailableListener mTransformedListener = (ImageReaderProxy.OnImageAvailableListener)new MetadataImageReader$.ExternalSyntheticLambda1(this);
  
  @GuardedBy("mLock")
  private int mUnAcquiredAvailableImageCount = 0;
  
  public MetadataImageReader(int paramInt1, int paramInt2, int paramInt3, int paramInt4) {
    this(createImageReaderProxy(paramInt1, paramInt2, paramInt3, paramInt4));
  }
  
  MetadataImageReader(@NonNull ImageReaderProxy paramImageReaderProxy) {
    this.mImageReaderProxy = paramImageReaderProxy;
    this.mImageProxiesIndex = 0;
    this.mMatchedImageProxies = new ArrayList<ImageProxy>(getMaxImages());
  }
  
  private static ImageReaderProxy createImageReaderProxy(int paramInt1, int paramInt2, int paramInt3, int paramInt4) {
    return (ImageReaderProxy)new AndroidImageReaderProxy(ImageReader.newInstance(paramInt1, paramInt2, paramInt3, paramInt4));
  }
  
  private void dequeImageProxy(ImageProxy paramImageProxy) {
    synchronized (this.mLock) {
      int i = this.mMatchedImageProxies.indexOf(paramImageProxy);
      if (i >= 0) {
        this.mMatchedImageProxies.remove(i);
        int j = this.mImageProxiesIndex;
        if (i <= j)
          this.mImageProxiesIndex = j - 1; 
      } 
      this.mAcquiredImageProxies.remove(paramImageProxy);
      if (this.mUnAcquiredAvailableImageCount > 0)
        imageIncoming(this.mImageReaderProxy); 
      return;
    } 
  }
  
  private void enqueueImageProxy(SettableImageProxy paramSettableImageProxy) {
    synchronized (this.mLock) {
      Executor executor;
      ImageReaderProxy.OnImageAvailableListener onImageAvailableListener;
      if (this.mMatchedImageProxies.size() < getMaxImages()) {
        paramSettableImageProxy.addOnImageCloseListener(this);
        this.mMatchedImageProxies.add(paramSettableImageProxy);
        onImageAvailableListener = this.mListener;
        executor = this.mExecutor;
      } else {
        Logger.d("TAG", "Maximum image number reached.");
        executor.close();
        onImageAvailableListener = null;
        executor = null;
      } 
      if (onImageAvailableListener != null) {
        if (executor != null) {
          executor.execute((Runnable)new MetadataImageReader$.ExternalSyntheticLambda0(this, onImageAvailableListener));
          return;
        } 
        onImageAvailableListener.onImageAvailable(this);
      } 
      return;
    } 
  }
  
  private void matchImages() {
    synchronized (this.mLock) {
      for (int i = this.mPendingImageInfos.size() - 1;; i--) {
        if (i >= 0) {
          ImageInfo imageInfo = (ImageInfo)this.mPendingImageInfos.valueAt(i);
          long l = imageInfo.getTimestamp();
          ImageProxy imageProxy = (ImageProxy)this.mPendingImages.get(l);
          if (imageProxy != null) {
            this.mPendingImages.remove(l);
            this.mPendingImageInfos.removeAt(i);
            enqueueImageProxy(new SettableImageProxy(imageProxy, imageInfo));
          } 
        } else {
          removeStaleData();
          return;
        } 
      } 
    } 
  }
  
  private void removeStaleData() {
    synchronized (this.mLock) {
      if (this.mPendingImages.size() == 0 || this.mPendingImageInfos.size() == 0)
        return; 
      LongSparseArray<ImageProxy> longSparseArray = this.mPendingImages;
      boolean bool = false;
      Long long_1 = Long.valueOf(longSparseArray.keyAt(0));
      Long long_2 = Long.valueOf(this.mPendingImageInfos.keyAt(0));
      if (!long_2.equals(long_1))
        bool = true; 
      Preconditions.checkArgument(bool);
      if (long_2.longValue() > long_1.longValue())
        for (int j = this.mPendingImages.size() - 1;; j--) {
          if (j >= 0) {
            if (this.mPendingImages.keyAt(j) < long_2.longValue()) {
              ((ImageProxy)this.mPendingImages.valueAt(j)).close();
              this.mPendingImages.removeAt(j);
            } 
            continue;
          } 
          return;
        }  
      for (int i = this.mPendingImageInfos.size() - 1;; i--) {
        if (i >= 0) {
          if (this.mPendingImageInfos.keyAt(i) < long_1.longValue())
            this.mPendingImageInfos.removeAt(i); 
          continue;
        } 
        return;
      } 
    } 
  }
  
  @Nullable
  public ImageProxy acquireLatestImage() {
    synchronized (this.mLock) {
      if (this.mMatchedImageProxies.isEmpty())
        return null; 
      if (this.mImageProxiesIndex < this.mMatchedImageProxies.size()) {
        ArrayList<ImageProxy> arrayList = new ArrayList();
        for (int i = 0;; i++) {
          if (i < this.mMatchedImageProxies.size() - 1) {
            if (!this.mAcquiredImageProxies.contains(this.mMatchedImageProxies.get(i)))
              arrayList.add(this.mMatchedImageProxies.get(i)); 
          } else {
            Iterator<ImageProxy> iterator = arrayList.iterator();
            while (iterator.hasNext())
              ((ImageProxy)iterator.next()).close(); 
            i = this.mMatchedImageProxies.size() - 1;
            List<ImageProxy> list = this.mMatchedImageProxies;
            this.mImageProxiesIndex = i + 1;
            ImageProxy imageProxy = list.get(i);
            this.mAcquiredImageProxies.add(imageProxy);
            return imageProxy;
          } 
        } 
      } 
      throw new IllegalStateException("Maximum image number reached.");
    } 
  }
  
  @Nullable
  public ImageProxy acquireNextImage() {
    synchronized (this.mLock) {
      if (this.mMatchedImageProxies.isEmpty())
        return null; 
      if (this.mImageProxiesIndex < this.mMatchedImageProxies.size()) {
        List<ImageProxy> list = this.mMatchedImageProxies;
        int i = this.mImageProxiesIndex;
        this.mImageProxiesIndex = i + 1;
        ImageProxy imageProxy = list.get(i);
        this.mAcquiredImageProxies.add(imageProxy);
        return imageProxy;
      } 
      throw new IllegalStateException("Maximum image number reached.");
    } 
  }
  
  public void clearOnImageAvailableListener() {
    synchronized (this.mLock) {
      this.mImageReaderProxy.clearOnImageAvailableListener();
      this.mListener = null;
      this.mExecutor = null;
      this.mUnAcquiredAvailableImageCount = 0;
      return;
    } 
  }
  
  public void close() {
    synchronized (this.mLock) {
      if (this.mClosed)
        return; 
      Iterator<?> iterator = (new ArrayList(this.mMatchedImageProxies)).iterator();
      while (iterator.hasNext())
        ((ImageProxy)iterator.next()).close(); 
      this.mMatchedImageProxies.clear();
      this.mImageReaderProxy.close();
      this.mClosed = true;
      return;
    } 
  }
  
  @NonNull
  public CameraCaptureCallback getCameraCaptureCallback() {
    return this.mCameraCaptureCallback;
  }
  
  public int getHeight() {
    synchronized (this.mLock) {
      return this.mImageReaderProxy.getHeight();
    } 
  }
  
  public int getImageFormat() {
    synchronized (this.mLock) {
      return this.mImageReaderProxy.getImageFormat();
    } 
  }
  
  public int getMaxImages() {
    synchronized (this.mLock) {
      return this.mImageReaderProxy.getMaxImages();
    } 
  }
  
  @Nullable
  public Surface getSurface() {
    synchronized (this.mLock) {
      return this.mImageReaderProxy.getSurface();
    } 
  }
  
  public int getWidth() {
    synchronized (this.mLock) {
      return this.mImageReaderProxy.getWidth();
    } 
  }
  
  void imageIncoming(ImageReaderProxy paramImageReaderProxy) {
    synchronized (this.mLock) {
      if (this.mClosed)
        return; 
      int j = this.mPendingImages.size() + this.mMatchedImageProxies.size();
      int i = j;
      if (j >= paramImageReaderProxy.getMaxImages()) {
        Logger.d("MetadataImageReader", "Skip to acquire the next image because the acquired image count has reached the max images count.");
        return;
      } 
      while (true) {
        try {
          ImageProxy imageProxy2 = paramImageReaderProxy.acquireNextImage();
          j = i;
          ImageProxy imageProxy1 = imageProxy2;
          if (imageProxy2 != null) {
            this.mUnAcquiredAvailableImageCount--;
            j = i + 1;
            this.mPendingImages.put(imageProxy2.getImageInfo().getTimestamp(), imageProxy2);
            matchImages();
            imageProxy1 = imageProxy2;
          } 
        } catch (IllegalStateException illegalStateException) {
          Logger.d("MetadataImageReader", "Failed to acquire next image.", illegalStateException);
          illegalStateException = null;
          j = i;
        } finally {}
        if (illegalStateException != null && this.mUnAcquiredAvailableImageCount > 0) {
          i = j;
          if (j >= paramImageReaderProxy.getMaxImages())
            return; 
          continue;
        } 
        return;
      } 
    } 
  }
  
  public void onImageClose(@NonNull ImageProxy paramImageProxy) {
    synchronized (this.mLock) {
      dequeImageProxy(paramImageProxy);
      return;
    } 
  }
  
  void resultIncoming(CameraCaptureResult paramCameraCaptureResult) {
    synchronized (this.mLock) {
      if (this.mClosed)
        return; 
      this.mPendingImageInfos.put(paramCameraCaptureResult.getTimestamp(), new CameraCaptureResultImageInfo(paramCameraCaptureResult));
      matchImages();
      return;
    } 
  }
  
  public void setOnImageAvailableListener(@NonNull ImageReaderProxy.OnImageAvailableListener paramOnImageAvailableListener, @NonNull Executor paramExecutor) {
    synchronized (this.mLock) {
      this.mListener = (ImageReaderProxy.OnImageAvailableListener)Preconditions.checkNotNull(paramOnImageAvailableListener);
      this.mExecutor = (Executor)Preconditions.checkNotNull(paramExecutor);
      this.mImageReaderProxy.setOnImageAvailableListener(this.mTransformedListener, paramExecutor);
      return;
    } 
  }
}


/* Location:              C:\soft\dex2jar-2.0\MagicAI - AI Art & Anime Art-dex2jar.jar!\androidx\camera\core\MetadataImageReader.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */