package androidx.camera.core;

import android.content.ContentValues;
import android.graphics.Rect;
import android.net.Uri;
import android.os.Build;
import androidx.annotation.IntRange;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.annotation.RequiresApi;
import androidx.camera.core.impl.utils.Exif;
import androidx.camera.core.internal.utils.ImageUtil;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.OutputStream;
import java.util.UUID;
import java.util.concurrent.Executor;
import java.util.concurrent.RejectedExecutionException;

@RequiresApi(21)
final class ImageSaver implements Runnable {
  private static final int COPY_BUFFER_SIZE = 1024;
  
  private static final int NOT_PENDING = 0;
  
  private static final int PENDING = 1;
  
  private static final String TAG = "ImageSaver";
  
  private static final String TEMP_FILE_PREFIX = "CameraX";
  
  private static final String TEMP_FILE_SUFFIX = ".tmp";
  
  @NonNull
  private final OnImageSavedCallback mCallback;
  
  private final ImageProxy mImage;
  
  private final int mJpegQuality;
  
  private final int mOrientation;
  
  @NonNull
  private final ImageCapture.OutputFileOptions mOutputFileOptions;
  
  @NonNull
  private final Executor mSequentialIoExecutor;
  
  @NonNull
  private final Executor mUserCallbackExecutor;
  
  ImageSaver(@NonNull ImageProxy paramImageProxy, @NonNull ImageCapture.OutputFileOptions paramOutputFileOptions, int paramInt1, @IntRange(from = 1L, to = 100L) int paramInt2, @NonNull Executor paramExecutor1, @NonNull Executor paramExecutor2, @NonNull OnImageSavedCallback paramOnImageSavedCallback) {
    this.mImage = paramImageProxy;
    this.mOutputFileOptions = paramOutputFileOptions;
    this.mOrientation = paramInt1;
    this.mJpegQuality = paramInt2;
    this.mCallback = paramOnImageSavedCallback;
    this.mUserCallbackExecutor = paramExecutor1;
    this.mSequentialIoExecutor = paramExecutor2;
  }
  
  private void copyTempFileToOutputStream(@NonNull File paramFile, @NonNull OutputStream paramOutputStream) throws IOException {
    FileInputStream fileInputStream = new FileInputStream(paramFile);
    try {
      byte[] arrayOfByte = new byte[1024];
      while (true) {
        int i = fileInputStream.read(arrayOfByte);
        if (i > 0) {
          paramOutputStream.write(arrayOfByte, 0, i);
          continue;
        } 
        return;
      } 
    } finally {
      try {
        fileInputStream.close();
      } finally {
        fileInputStream = null;
      } 
    } 
  }
  
  private boolean copyTempFileToUri(@NonNull File paramFile, @NonNull Uri paramUri) throws IOException {
    OutputStream outputStream = this.mOutputFileOptions.getContentResolver().openOutputStream(paramUri);
    if (outputStream == null) {
      if (outputStream != null)
        outputStream.close(); 
      return false;
    } 
    try {
      copyTempFileToOutputStream(paramFile, outputStream);
      return true;
    } finally {
      try {
        outputStream.close();
      } finally {
        outputStream = null;
      } 
    } 
  }
  
  @NonNull
  private byte[] imageToJpegByteArray(@NonNull ImageProxy paramImageProxy, @IntRange(from = 1L, to = 100L) int paramInt) throws ImageUtil.CodecFailedException {
    boolean bool = ImageUtil.shouldCropImage(paramImageProxy);
    int i = paramImageProxy.getFormat();
    if (i == 256)
      return !bool ? ImageUtil.jpegImageToJpegByteArray(paramImageProxy) : ImageUtil.jpegImageToJpegByteArray(paramImageProxy, paramImageProxy.getCropRect(), paramInt); 
    Rect rect = null;
    if (i == 35) {
      if (bool)
        rect = paramImageProxy.getCropRect(); 
      return ImageUtil.yuvImageToJpegByteArray(paramImageProxy, rect, paramInt);
    } 
    StringBuilder stringBuilder = new StringBuilder();
    stringBuilder.append("Unrecognized image format: ");
    stringBuilder.append(i);
    Logger.w("ImageSaver", stringBuilder.toString());
    return null;
  }
  
  private boolean isSaveToFile() {
    return (this.mOutputFileOptions.getFile() != null);
  }
  
  private boolean isSaveToMediaStore() {
    return (this.mOutputFileOptions.getSaveCollection() != null && this.mOutputFileOptions.getContentResolver() != null && this.mOutputFileOptions.getContentValues() != null);
  }
  
  private boolean isSaveToOutputStream() {
    return (this.mOutputFileOptions.getOutputStream() != null);
  }
  
  private void postError(SaveError paramSaveError, String paramString, @Nullable Throwable paramThrowable) {
    try {
      this.mUserCallbackExecutor.execute((Runnable)new ImageSaver$.ExternalSyntheticLambda1(this, paramSaveError, paramString, paramThrowable));
      return;
    } catch (RejectedExecutionException rejectedExecutionException) {
      Logger.e("ImageSaver", "Application executor rejected executing OnImageSavedCallback.onError callback. Skipping.");
      return;
    } 
  }
  
  private void postSuccess(@Nullable Uri paramUri) {
    try {
      this.mUserCallbackExecutor.execute((Runnable)new ImageSaver$.ExternalSyntheticLambda0(this, paramUri));
      return;
    } catch (RejectedExecutionException rejectedExecutionException) {
      Logger.e("ImageSaver", "Application executor rejected executing OnImageSavedCallback.onImageSaved callback. Skipping.");
      return;
    } 
  }
  
  @Nullable
  private File saveImageToTempFile() {
    try {
      SaveError saveError;
      String str;
      File file;
      boolean bool = isSaveToFile();
      if (bool) {
        String str1 = this.mOutputFileOptions.getFile().getParent();
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("CameraX");
        stringBuilder.append(UUID.randomUUID().toString());
        stringBuilder.append(".tmp");
        file = new File(str1, stringBuilder.toString());
      } else {
        file = File.createTempFile("CameraX", ".tmp");
      } 
      try {
        Exif exif;
        ImageProxy imageProxy = this.mImage;
        try {
          Exif exif1;
          FileOutputStream fileOutputStream = new FileOutputStream(file);
        } finally {
          if (exif != null)
            try {
              exif.close();
            } finally {
              exif = null;
            }  
        } 
      } catch (IOException iOException) {
        saveError = SaveError.FILE_IO_FAILED;
        str = "Failed to write temp file";
      } catch (IllegalArgumentException illegalArgumentException) {
      
      } catch (androidx.camera.core.internal.utils.ImageUtil.CodecFailedException codecFailedException) {
        int i = null.$SwitchMap$androidx$camera$core$internal$utils$ImageUtil$CodecFailedException$FailureType[codecFailedException.getFailureType().ordinal()];
        if (i != 1) {
          if (i != 2) {
            saveError = SaveError.UNKNOWN;
            str = "Failed to transcode mImage";
          } else {
            saveError = SaveError.CROP_FAILED;
            str = "Failed to crop mImage";
          } 
        } else {
          saveError = SaveError.ENCODE_FAILED;
          str = "Failed to encode mImage";
        } 
      } 
      if (saveError != null) {
        postError(saveError, str, (Throwable)codecFailedException);
        file.delete();
        return null;
      } 
      return file;
    } catch (IOException iOException) {
      postError(SaveError.FILE_IO_FAILED, "Failed to create temp file", iOException);
      return null;
    } 
  }
  
  private void setContentValuePending(@NonNull ContentValues paramContentValues, int paramInt) {
    if (Build.VERSION.SDK_INT >= 29)
      paramContentValues.put("is_pending", Integer.valueOf(paramInt)); 
  }
  
  private void setUriNotPending(@NonNull Uri paramUri) {
    if (Build.VERSION.SDK_INT >= 29) {
      ContentValues contentValues = new ContentValues();
      setContentValuePending(contentValues, 0);
      this.mOutputFileOptions.getContentResolver().update(paramUri, contentValues, null, null);
    } 
  }
  
  void copyTempFileToDestination(@NonNull File paramFile) {
    // Byte code:
    //   0: aload_1
    //   1: invokestatic checkNotNull : (Ljava/lang/Object;)Ljava/lang/Object;
    //   4: pop
    //   5: aconst_null
    //   6: astore #5
    //   8: aload_0
    //   9: invokespecial isSaveToMediaStore : ()Z
    //   12: ifeq -> 133
    //   15: aload_0
    //   16: getfield mOutputFileOptions : Landroidx/camera/core/ImageCapture$OutputFileOptions;
    //   19: invokevirtual getContentValues : ()Landroid/content/ContentValues;
    //   22: ifnull -> 43
    //   25: new android/content/ContentValues
    //   28: dup
    //   29: aload_0
    //   30: getfield mOutputFileOptions : Landroidx/camera/core/ImageCapture$OutputFileOptions;
    //   33: invokevirtual getContentValues : ()Landroid/content/ContentValues;
    //   36: invokespecial <init> : (Landroid/content/ContentValues;)V
    //   39: astore_2
    //   40: goto -> 51
    //   43: new android/content/ContentValues
    //   46: dup
    //   47: invokespecial <init> : ()V
    //   50: astore_2
    //   51: aload_0
    //   52: aload_2
    //   53: iconst_1
    //   54: invokespecial setContentValuePending : (Landroid/content/ContentValues;I)V
    //   57: aload_0
    //   58: getfield mOutputFileOptions : Landroidx/camera/core/ImageCapture$OutputFileOptions;
    //   61: invokevirtual getContentResolver : ()Landroid/content/ContentResolver;
    //   64: aload_0
    //   65: getfield mOutputFileOptions : Landroidx/camera/core/ImageCapture$OutputFileOptions;
    //   68: invokevirtual getSaveCollection : ()Landroid/net/Uri;
    //   71: aload_2
    //   72: invokevirtual insert : (Landroid/net/Uri;Landroid/content/ContentValues;)Landroid/net/Uri;
    //   75: astore #4
    //   77: aload #4
    //   79: ifnonnull -> 93
    //   82: getstatic androidx/camera/core/ImageSaver$SaveError.FILE_IO_FAILED : Landroidx/camera/core/ImageSaver$SaveError;
    //   85: astore_2
    //   86: ldc_w 'Failed to insert URI.'
    //   89: astore_3
    //   90: goto -> 249
    //   93: aload_0
    //   94: aload_1
    //   95: aload #4
    //   97: invokespecial copyTempFileToUri : (Ljava/io/File;Landroid/net/Uri;)Z
    //   100: ifne -> 281
    //   103: getstatic androidx/camera/core/ImageSaver$SaveError.FILE_IO_FAILED : Landroidx/camera/core/ImageSaver$SaveError;
    //   106: astore_2
    //   107: ldc_w 'Failed to save to URI.'
    //   110: astore_3
    //   111: goto -> 114
    //   114: aload_0
    //   115: aload #4
    //   117: invokespecial setUriNotPending : (Landroid/net/Uri;)V
    //   120: goto -> 249
    //   123: astore #5
    //   125: goto -> 241
    //   128: astore #5
    //   130: goto -> 241
    //   133: aload_0
    //   134: invokespecial isSaveToOutputStream : ()Z
    //   137: ifeq -> 155
    //   140: aload_0
    //   141: aload_1
    //   142: aload_0
    //   143: getfield mOutputFileOptions : Landroidx/camera/core/ImageCapture$OutputFileOptions;
    //   146: invokevirtual getOutputStream : ()Ljava/io/OutputStream;
    //   149: invokespecial copyTempFileToOutputStream : (Ljava/io/File;Ljava/io/OutputStream;)V
    //   152: goto -> 215
    //   155: aload_0
    //   156: invokespecial isSaveToFile : ()Z
    //   159: ifeq -> 215
    //   162: aload_0
    //   163: getfield mOutputFileOptions : Landroidx/camera/core/ImageCapture$OutputFileOptions;
    //   166: invokevirtual getFile : ()Ljava/io/File;
    //   169: astore #4
    //   171: aload #4
    //   173: invokevirtual exists : ()Z
    //   176: ifeq -> 185
    //   179: aload #4
    //   181: invokevirtual delete : ()Z
    //   184: pop
    //   185: aload_1
    //   186: aload #4
    //   188: invokevirtual renameTo : (Ljava/io/File;)Z
    //   191: ifne -> 288
    //   194: getstatic androidx/camera/core/ImageSaver$SaveError.FILE_IO_FAILED : Landroidx/camera/core/ImageSaver$SaveError;
    //   197: astore_2
    //   198: ldc_w 'Failed to rename file.'
    //   201: astore_3
    //   202: goto -> 205
    //   205: aload #4
    //   207: invokestatic fromFile : (Ljava/io/File;)Landroid/net/Uri;
    //   210: astore #4
    //   212: goto -> 249
    //   215: aconst_null
    //   216: astore #4
    //   218: aload #4
    //   220: astore_2
    //   221: aload_2
    //   222: astore_3
    //   223: goto -> 249
    //   226: astore_2
    //   227: goto -> 274
    //   230: astore_2
    //   231: goto -> 235
    //   234: astore_2
    //   235: aconst_null
    //   236: astore #4
    //   238: aload_2
    //   239: astore #5
    //   241: getstatic androidx/camera/core/ImageSaver$SaveError.FILE_IO_FAILED : Landroidx/camera/core/ImageSaver$SaveError;
    //   244: astore_2
    //   245: ldc_w 'Failed to write destination file.'
    //   248: astore_3
    //   249: aload_1
    //   250: invokevirtual delete : ()Z
    //   253: pop
    //   254: aload_2
    //   255: ifnull -> 267
    //   258: aload_0
    //   259: aload_2
    //   260: aload_3
    //   261: aload #5
    //   263: invokespecial postError : (Landroidx/camera/core/ImageSaver$SaveError;Ljava/lang/String;Ljava/lang/Throwable;)V
    //   266: return
    //   267: aload_0
    //   268: aload #4
    //   270: invokespecial postSuccess : (Landroid/net/Uri;)V
    //   273: return
    //   274: aload_1
    //   275: invokevirtual delete : ()Z
    //   278: pop
    //   279: aload_2
    //   280: athrow
    //   281: aconst_null
    //   282: astore_2
    //   283: aload_2
    //   284: astore_3
    //   285: goto -> 114
    //   288: aconst_null
    //   289: astore_2
    //   290: aload_2
    //   291: astore_3
    //   292: goto -> 205
    // Exception table:
    //   from	to	target	type
    //   8	40	234	java/io/IOException
    //   8	40	230	java/lang/IllegalArgumentException
    //   8	40	226	finally
    //   43	51	234	java/io/IOException
    //   43	51	230	java/lang/IllegalArgumentException
    //   43	51	226	finally
    //   51	77	234	java/io/IOException
    //   51	77	230	java/lang/IllegalArgumentException
    //   51	77	226	finally
    //   82	86	128	java/io/IOException
    //   82	86	123	java/lang/IllegalArgumentException
    //   82	86	226	finally
    //   93	107	128	java/io/IOException
    //   93	107	123	java/lang/IllegalArgumentException
    //   93	107	226	finally
    //   114	120	128	java/io/IOException
    //   114	120	123	java/lang/IllegalArgumentException
    //   114	120	226	finally
    //   133	152	234	java/io/IOException
    //   133	152	230	java/lang/IllegalArgumentException
    //   133	152	226	finally
    //   155	185	234	java/io/IOException
    //   155	185	230	java/lang/IllegalArgumentException
    //   155	185	226	finally
    //   185	198	234	java/io/IOException
    //   185	198	230	java/lang/IllegalArgumentException
    //   185	198	226	finally
    //   205	212	234	java/io/IOException
    //   205	212	230	java/lang/IllegalArgumentException
    //   205	212	226	finally
    //   241	245	226	finally
  }
  
  public void run() {
    File file = saveImageToTempFile();
    if (file != null)
      this.mSequentialIoExecutor.execute((Runnable)new ImageSaver$.ExternalSyntheticLambda2(this, file)); 
  }
  
  public static interface OnImageSavedCallback {
    void onError(@NonNull ImageSaver.SaveError param1SaveError, @NonNull String param1String, @Nullable Throwable param1Throwable);
    
    void onImageSaved(@NonNull ImageCapture.OutputFileResults param1OutputFileResults);
  }
  
  public enum SaveError {
    CROP_FAILED, ENCODE_FAILED, FILE_IO_FAILED, UNKNOWN;
    
    static {
      SaveError saveError1 = new SaveError("FILE_IO_FAILED", 0);
      FILE_IO_FAILED = saveError1;
      SaveError saveError2 = new SaveError("ENCODE_FAILED", 1);
      ENCODE_FAILED = saveError2;
      SaveError saveError3 = new SaveError("CROP_FAILED", 2);
      CROP_FAILED = saveError3;
      SaveError saveError4 = new SaveError("UNKNOWN", 3);
      UNKNOWN = saveError4;
      $VALUES = new SaveError[] { saveError1, saveError2, saveError3, saveError4 };
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\MagicAI - AI Art & Anime Art-dex2jar.jar!\androidx\camera\core\ImageSaver.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */