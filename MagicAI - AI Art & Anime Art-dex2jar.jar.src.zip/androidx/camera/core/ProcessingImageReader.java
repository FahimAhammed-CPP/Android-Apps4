package androidx.camera.core;

import android.media.ImageReader;
import android.util.Size;
import android.view.Surface;
import androidx.annotation.GuardedBy;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.annotation.RequiresApi;
import androidx.arch.core.util.Function;
import androidx.camera.core.impl.CameraCaptureCallback;
import androidx.camera.core.impl.CaptureBundle;
import androidx.camera.core.impl.CaptureProcessor;
import androidx.camera.core.impl.CaptureStage;
import androidx.camera.core.impl.ImageReaderProxy;
import androidx.camera.core.impl.utils.executor.CameraXExecutors;
import androidx.camera.core.impl.utils.futures.FutureCallback;
import androidx.camera.core.impl.utils.futures.Futures;
import androidx.concurrent.futures.CallbackToFutureAdapter;
import androidx.core.util.Preconditions;
import com.google.common.util.concurrent.ListenableFuture;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.concurrent.Executor;
import java.util.concurrent.Executors;

@RequiresApi(21)
class ProcessingImageReader implements ImageReaderProxy {
  private static final int EXIF_MAX_SIZE_BYTES = 64000;
  
  private static final String TAG = "ProcessingImageReader";
  
  private final List<Integer> mCaptureIdList = new ArrayList<Integer>();
  
  @NonNull
  final CaptureProcessor mCaptureProcessor;
  
  private FutureCallback<List<ImageProxy>> mCaptureStageReadyCallback = new FutureCallback<List<ImageProxy>>() {
      public void onFailure(@NonNull Throwable param1Throwable) {}
      
      public void onSuccess(@Nullable List<ImageProxy> param1List) {
        // Byte code:
        //   0: aload_0
        //   1: getfield this$0 : Landroidx/camera/core/ProcessingImageReader;
        //   4: getfield mLock : Ljava/lang/Object;
        //   7: astore_3
        //   8: aload_3
        //   9: monitorenter
        //   10: aload_0
        //   11: getfield this$0 : Landroidx/camera/core/ProcessingImageReader;
        //   14: astore #4
        //   16: aload #4
        //   18: getfield mClosed : Z
        //   21: ifeq -> 27
        //   24: aload_3
        //   25: monitorexit
        //   26: return
        //   27: aload #4
        //   29: iconst_1
        //   30: putfield mProcessing : Z
        //   33: aload #4
        //   35: getfield mSettableImageProxyBundle : Landroidx/camera/core/SettableImageProxyBundle;
        //   38: astore #5
        //   40: aload #4
        //   42: getfield mOnProcessingErrorCallback : Landroidx/camera/core/ProcessingImageReader$OnProcessingErrorCallback;
        //   45: astore_1
        //   46: aload #4
        //   48: getfield mErrorCallbackExecutor : Ljava/util/concurrent/Executor;
        //   51: astore_2
        //   52: aload_3
        //   53: monitorexit
        //   54: aload #4
        //   56: getfield mCaptureProcessor : Landroidx/camera/core/impl/CaptureProcessor;
        //   59: aload #5
        //   61: invokeinterface process : (Landroidx/camera/core/impl/ImageProxyBundle;)V
        //   66: goto -> 117
        //   69: astore #4
        //   71: aload_0
        //   72: getfield this$0 : Landroidx/camera/core/ProcessingImageReader;
        //   75: getfield mLock : Ljava/lang/Object;
        //   78: astore_3
        //   79: aload_3
        //   80: monitorenter
        //   81: aload_0
        //   82: getfield this$0 : Landroidx/camera/core/ProcessingImageReader;
        //   85: getfield mSettableImageProxyBundle : Landroidx/camera/core/SettableImageProxyBundle;
        //   88: invokevirtual reset : ()V
        //   91: aload_1
        //   92: ifnull -> 115
        //   95: aload_2
        //   96: ifnull -> 115
        //   99: aload_2
        //   100: new androidx/camera/core/ProcessingImageReader$3$$ExternalSyntheticLambda0
        //   103: dup
        //   104: aload_1
        //   105: aload #4
        //   107: invokespecial <init> : (Landroidx/camera/core/ProcessingImageReader$OnProcessingErrorCallback;Ljava/lang/Exception;)V
        //   110: invokeinterface execute : (Ljava/lang/Runnable;)V
        //   115: aload_3
        //   116: monitorexit
        //   117: aload_0
        //   118: getfield this$0 : Landroidx/camera/core/ProcessingImageReader;
        //   121: getfield mLock : Ljava/lang/Object;
        //   124: astore_1
        //   125: aload_1
        //   126: monitorenter
        //   127: aload_0
        //   128: getfield this$0 : Landroidx/camera/core/ProcessingImageReader;
        //   131: astore_2
        //   132: aload_2
        //   133: iconst_0
        //   134: putfield mProcessing : Z
        //   137: aload_1
        //   138: monitorexit
        //   139: aload_2
        //   140: invokevirtual closeAndCompleteFutureIfNecessary : ()V
        //   143: return
        //   144: astore_2
        //   145: aload_1
        //   146: monitorexit
        //   147: aload_2
        //   148: athrow
        //   149: astore_1
        //   150: aload_3
        //   151: monitorexit
        //   152: aload_1
        //   153: athrow
        //   154: astore_1
        //   155: aload_3
        //   156: monitorexit
        //   157: aload_1
        //   158: athrow
        // Exception table:
        //   from	to	target	type
        //   10	26	154	finally
        //   27	54	154	finally
        //   54	66	69	java/lang/Exception
        //   81	91	149	finally
        //   99	115	149	finally
        //   115	117	149	finally
        //   127	139	144	finally
        //   145	147	144	finally
        //   150	152	149	finally
        //   155	157	154	finally
      }
    };
  
  @GuardedBy("mLock")
  CallbackToFutureAdapter.Completer<Void> mCloseCompleter;
  
  @GuardedBy("mLock")
  private ListenableFuture<Void> mCloseFuture;
  
  @GuardedBy("mLock")
  boolean mClosed = false;
  
  @GuardedBy("mLock")
  Executor mErrorCallbackExecutor;
  
  @GuardedBy("mLock")
  @Nullable
  Executor mExecutor;
  
  private ImageReaderProxy.OnImageAvailableListener mImageProcessedListener = new ImageReaderProxy.OnImageAvailableListener() {
      public void onImageAvailable(@NonNull ImageReaderProxy param1ImageReaderProxy) {
        synchronized (ProcessingImageReader.this.mLock) {
          ProcessingImageReader processingImageReader = ProcessingImageReader.this;
          ImageReaderProxy.OnImageAvailableListener onImageAvailableListener = processingImageReader.mListener;
          Executor executor = processingImageReader.mExecutor;
          processingImageReader.mSettableImageProxyBundle.reset();
          ProcessingImageReader.this.setupSettableImageProxyBundleCallbacks();
          if (onImageAvailableListener != null) {
            if (executor != null) {
              executor.execute((Runnable)new ProcessingImageReader$2$.ExternalSyntheticLambda0(this, onImageAvailableListener));
              return;
            } 
            onImageAvailableListener.onImageAvailable(ProcessingImageReader.this);
          } 
          return;
        } 
      }
    };
  
  @GuardedBy("mLock")
  final ImageReaderProxy mInputImageReader;
  
  @GuardedBy("mLock")
  @Nullable
  ImageReaderProxy.OnImageAvailableListener mListener;
  
  final Object mLock = new Object();
  
  @GuardedBy("mLock")
  OnProcessingErrorCallback mOnProcessingErrorCallback;
  
  @GuardedBy("mLock")
  final ImageReaderProxy mOutputImageReader;
  
  @NonNull
  final Executor mPostProcessExecutor;
  
  @GuardedBy("mLock")
  boolean mProcessing = false;
  
  @GuardedBy("mLock")
  @NonNull
  SettableImageProxyBundle mSettableImageProxyBundle = new SettableImageProxyBundle(Collections.emptyList(), this.mTagBundleKey);
  
  private ListenableFuture<List<ImageProxy>> mSettableImageProxyFutureList = Futures.immediateFuture(new ArrayList());
  
  private String mTagBundleKey = new String();
  
  private ImageReaderProxy.OnImageAvailableListener mTransformedListener = new ImageReaderProxy.OnImageAvailableListener() {
      public void onImageAvailable(@NonNull ImageReaderProxy param1ImageReaderProxy) {
        ProcessingImageReader.this.imageIncoming(param1ImageReaderProxy);
      }
    };
  
  @NonNull
  private final ListenableFuture<Void> mUnderlyingCaptureProcessorCloseFuture;
  
  ProcessingImageReader(@NonNull Builder paramBuilder) {
    if (paramBuilder.mInputImageReader.getMaxImages() >= paramBuilder.mCaptureBundle.getCaptureStages().size()) {
      ImageReaderProxy imageReaderProxy = paramBuilder.mInputImageReader;
      this.mInputImageReader = imageReaderProxy;
      int k = imageReaderProxy.getWidth();
      int m = imageReaderProxy.getHeight();
      int n = paramBuilder.mOutputFormat;
      int j = k;
      int i = m;
      if (n == 256) {
        j = (int)((k * m) * 1.5F) + 64000;
        i = 1;
      } 
      AndroidImageReaderProxy androidImageReaderProxy = new AndroidImageReaderProxy(ImageReader.newInstance(j, i, n, imageReaderProxy.getMaxImages()));
      this.mOutputImageReader = (ImageReaderProxy)androidImageReaderProxy;
      this.mPostProcessExecutor = paramBuilder.mPostProcessExecutor;
      CaptureProcessor captureProcessor = paramBuilder.mCaptureProcessor;
      this.mCaptureProcessor = captureProcessor;
      captureProcessor.onOutputSurface(androidImageReaderProxy.getSurface(), paramBuilder.mOutputFormat);
      captureProcessor.onResolutionUpdate(new Size(imageReaderProxy.getWidth(), imageReaderProxy.getHeight()));
      this.mUnderlyingCaptureProcessorCloseFuture = captureProcessor.getCloseFuture();
      setCaptureBundle(paramBuilder.mCaptureBundle);
      return;
    } 
    throw new IllegalArgumentException("MetadataImageReader is smaller than CaptureBundle.");
  }
  
  private void cancelSettableImageProxyBundleFutureList() {
    synchronized (this.mLock) {
      if (!this.mSettableImageProxyFutureList.isDone())
        this.mSettableImageProxyFutureList.cancel(true); 
      this.mSettableImageProxyBundle.reset();
      return;
    } 
  }
  
  @Nullable
  public ImageProxy acquireLatestImage() {
    synchronized (this.mLock) {
      return this.mOutputImageReader.acquireLatestImage();
    } 
  }
  
  @Nullable
  public ImageProxy acquireNextImage() {
    synchronized (this.mLock) {
      return this.mOutputImageReader.acquireNextImage();
    } 
  }
  
  public void clearOnImageAvailableListener() {
    synchronized (this.mLock) {
      this.mListener = null;
      this.mExecutor = null;
      this.mInputImageReader.clearOnImageAvailableListener();
      this.mOutputImageReader.clearOnImageAvailableListener();
      if (!this.mProcessing)
        this.mSettableImageProxyBundle.close(); 
      return;
    } 
  }
  
  public void close() {
    synchronized (this.mLock) {
      if (this.mClosed)
        return; 
      this.mInputImageReader.clearOnImageAvailableListener();
      this.mOutputImageReader.clearOnImageAvailableListener();
      this.mClosed = true;
      this.mCaptureProcessor.close();
      closeAndCompleteFutureIfNecessary();
      return;
    } 
  }
  
  void closeAndCompleteFutureIfNecessary() {
    synchronized (this.mLock) {
      boolean bool1 = this.mClosed;
      boolean bool2 = this.mProcessing;
      CallbackToFutureAdapter.Completer<Void> completer = this.mCloseCompleter;
      if (bool1 && !bool2) {
        this.mInputImageReader.close();
        this.mSettableImageProxyBundle.close();
        this.mOutputImageReader.close();
      } 
      if (bool1 && !bool2)
        this.mUnderlyingCaptureProcessorCloseFuture.addListener((Runnable)new ProcessingImageReader$.ExternalSyntheticLambda2(this, completer), CameraXExecutors.directExecutor()); 
      return;
    } 
  }
  
  @Nullable
  CameraCaptureCallback getCameraCaptureCallback() {
    synchronized (this.mLock) {
      ImageReaderProxy imageReaderProxy = this.mInputImageReader;
      if (imageReaderProxy instanceof MetadataImageReader)
        return ((MetadataImageReader)imageReaderProxy).getCameraCaptureCallback(); 
      return new CameraCaptureCallback() {
        
        };
    } 
  }
  
  @NonNull
  ListenableFuture<Void> getCloseFuture() {
    synchronized (this.mLock) {
      ListenableFuture<Void> listenableFuture;
      if (this.mClosed && !this.mProcessing) {
        listenableFuture = Futures.transform(this.mUnderlyingCaptureProcessorCloseFuture, (Function)new ProcessingImageReader$.ExternalSyntheticLambda0(), CameraXExecutors.directExecutor());
      } else {
        if (this.mCloseFuture == null)
          this.mCloseFuture = CallbackToFutureAdapter.getFuture((CallbackToFutureAdapter.Resolver)new ProcessingImageReader$.ExternalSyntheticLambda1(this)); 
        listenableFuture = Futures.nonCancellationPropagating(this.mCloseFuture);
      } 
      return listenableFuture;
    } 
  }
  
  public int getHeight() {
    synchronized (this.mLock) {
      return this.mInputImageReader.getHeight();
    } 
  }
  
  public int getImageFormat() {
    synchronized (this.mLock) {
      return this.mOutputImageReader.getImageFormat();
    } 
  }
  
  public int getMaxImages() {
    synchronized (this.mLock) {
      return this.mInputImageReader.getMaxImages();
    } 
  }
  
  @Nullable
  public Surface getSurface() {
    synchronized (this.mLock) {
      return this.mInputImageReader.getSurface();
    } 
  }
  
  @NonNull
  public String getTagBundleKey() {
    return this.mTagBundleKey;
  }
  
  public int getWidth() {
    synchronized (this.mLock) {
      return this.mInputImageReader.getWidth();
    } 
  }
  
  void imageIncoming(ImageReaderProxy paramImageReaderProxy) {
    synchronized (this.mLock) {
      if (this.mClosed)
        return; 
      try {
        ImageProxy imageProxy = paramImageReaderProxy.acquireNextImage();
        if (imageProxy != null) {
          Integer integer = (Integer)imageProxy.getImageInfo().getTagBundle().getTag(this.mTagBundleKey);
          if (!this.mCaptureIdList.contains(integer)) {
            StringBuilder stringBuilder = new StringBuilder();
            stringBuilder.append("ImageProxyBundle does not contain this id: ");
            stringBuilder.append(integer);
            Logger.w("ProcessingImageReader", stringBuilder.toString());
            imageProxy.close();
          } else {
            this.mSettableImageProxyBundle.addImageProxy(imageProxy);
          } 
        } 
      } catch (IllegalStateException illegalStateException) {
        Logger.e("ProcessingImageReader", "Failed to acquire latest image.", illegalStateException);
      } finally {}
      return;
    } 
  }
  
  public void setCaptureBundle(@NonNull CaptureBundle paramCaptureBundle) {
    synchronized (this.mLock) {
      if (this.mClosed)
        return; 
      cancelSettableImageProxyBundleFutureList();
      if (paramCaptureBundle.getCaptureStages() != null)
        if (this.mInputImageReader.getMaxImages() >= paramCaptureBundle.getCaptureStages().size()) {
          this.mCaptureIdList.clear();
          for (CaptureStage captureStage : paramCaptureBundle.getCaptureStages()) {
            if (captureStage != null)
              this.mCaptureIdList.add(Integer.valueOf(captureStage.getId())); 
          } 
        } else {
          throw new IllegalArgumentException("CaptureBundle is larger than InputImageReader.");
        }  
      String str = Integer.toString(paramCaptureBundle.hashCode());
      this.mTagBundleKey = str;
      this.mSettableImageProxyBundle = new SettableImageProxyBundle(this.mCaptureIdList, str);
      setupSettableImageProxyBundleCallbacks();
      return;
    } 
  }
  
  public void setOnImageAvailableListener(@NonNull ImageReaderProxy.OnImageAvailableListener paramOnImageAvailableListener, @NonNull Executor paramExecutor) {
    synchronized (this.mLock) {
      this.mListener = (ImageReaderProxy.OnImageAvailableListener)Preconditions.checkNotNull(paramOnImageAvailableListener);
      this.mExecutor = (Executor)Preconditions.checkNotNull(paramExecutor);
      this.mInputImageReader.setOnImageAvailableListener(this.mTransformedListener, paramExecutor);
      this.mOutputImageReader.setOnImageAvailableListener(this.mImageProcessedListener, paramExecutor);
      return;
    } 
  }
  
  public void setOnProcessingErrorCallback(@NonNull Executor paramExecutor, @NonNull OnProcessingErrorCallback paramOnProcessingErrorCallback) {
    synchronized (this.mLock) {
      this.mErrorCallbackExecutor = paramExecutor;
      this.mOnProcessingErrorCallback = paramOnProcessingErrorCallback;
      return;
    } 
  }
  
  @GuardedBy("mLock")
  void setupSettableImageProxyBundleCallbacks() {
    ArrayList<ListenableFuture<ImageProxy>> arrayList = new ArrayList();
    for (Integer integer : this.mCaptureIdList)
      arrayList.add(this.mSettableImageProxyBundle.getImageProxy(integer.intValue())); 
    this.mSettableImageProxyFutureList = Futures.allAsList(arrayList);
    Futures.addCallback(Futures.allAsList(arrayList), this.mCaptureStageReadyCallback, this.mPostProcessExecutor);
  }
  
  static final class Builder {
    @NonNull
    protected final CaptureBundle mCaptureBundle;
    
    @NonNull
    protected final CaptureProcessor mCaptureProcessor;
    
    @NonNull
    protected final ImageReaderProxy mInputImageReader;
    
    protected int mOutputFormat;
    
    @NonNull
    protected Executor mPostProcessExecutor = Executors.newSingleThreadExecutor();
    
    Builder(int param1Int1, int param1Int2, int param1Int3, int param1Int4, @NonNull CaptureBundle param1CaptureBundle, @NonNull CaptureProcessor param1CaptureProcessor) {
      this(new MetadataImageReader(param1Int1, param1Int2, param1Int3, param1Int4), param1CaptureBundle, param1CaptureProcessor);
    }
    
    Builder(@NonNull ImageReaderProxy param1ImageReaderProxy, @NonNull CaptureBundle param1CaptureBundle, @NonNull CaptureProcessor param1CaptureProcessor) {
      this.mInputImageReader = param1ImageReaderProxy;
      this.mCaptureBundle = param1CaptureBundle;
      this.mCaptureProcessor = param1CaptureProcessor;
      this.mOutputFormat = param1ImageReaderProxy.getImageFormat();
    }
    
    ProcessingImageReader build() {
      return new ProcessingImageReader(this);
    }
    
    @NonNull
    Builder setOutputFormat(int param1Int) {
      this.mOutputFormat = param1Int;
      return this;
    }
    
    @NonNull
    Builder setPostProcessExecutor(@NonNull Executor param1Executor) {
      this.mPostProcessExecutor = param1Executor;
      return this;
    }
  }
  
  static interface OnProcessingErrorCallback {
    void notifyProcessingError(@Nullable String param1String, @Nullable Throwable param1Throwable);
  }
}


/* Location:              C:\soft\dex2jar-2.0\MagicAI - AI Art & Anime Art-dex2jar.jar!\androidx\camera\core\ProcessingImageReader.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */