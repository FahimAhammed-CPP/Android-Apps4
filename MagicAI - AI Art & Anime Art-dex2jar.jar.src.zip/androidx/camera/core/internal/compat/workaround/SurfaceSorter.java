package androidx.camera.core.internal.compat.workaround;

import android.media.MediaCodec;
import androidx.annotation.NonNull;
import androidx.annotation.RequiresApi;
import androidx.camera.core.Preview;
import androidx.camera.core.VideoCapture;
import androidx.camera.core.impl.DeferrableSurface;
import androidx.camera.core.impl.SessionConfig;
import androidx.camera.core.internal.compat.quirk.DeviceQuirks;
import androidx.camera.core.internal.compat.quirk.SurfaceOrderQuirk;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;

@RequiresApi(21)
public class SurfaceSorter {
  private static final int PRIORITY_MEDIA_CODEC_SURFACE = 2;
  
  private static final int PRIORITY_OTHERS = 1;
  
  private static final int PRIORITY_PREVIEW_SURFACE = 0;
  
  private final boolean mHasQuirk;
  
  public SurfaceSorter() {
    boolean bool;
    if (DeviceQuirks.get(SurfaceOrderQuirk.class) != null) {
      bool = true;
    } else {
      bool = false;
    } 
    this.mHasQuirk = bool;
  }
  
  private int getSurfacePriority(@NonNull DeferrableSurface paramDeferrableSurface) {
    return (paramDeferrableSurface.getContainerClass() == MediaCodec.class || paramDeferrableSurface.getContainerClass() == VideoCapture.class) ? 2 : ((paramDeferrableSurface.getContainerClass() == Preview.class) ? 0 : 1);
  }
  
  public void sort(@NonNull List<SessionConfig.OutputConfig> paramList) {
    if (!this.mHasQuirk)
      return; 
    Collections.sort(paramList, (Comparator<? super SessionConfig.OutputConfig>)new SurfaceSorter$.ExternalSyntheticLambda0(this));
  }
}


/* Location:              C:\soft\dex2jar-2.0\MagicAI - AI Art & Anime Art-dex2jar.jar!\androidx\camera\core\internal\compat\workaround\SurfaceSorter.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */