package androidx.camera.core.internal;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.annotation.RequiresApi;
import androidx.camera.core.impl.Config;
import androidx.camera.core.impl.ReadableConfig;
import java.util.concurrent.Executor;

@RequiresApi(21)
public interface IoConfig extends ReadableConfig {
  public static final Config.Option<Executor> OPTION_IO_EXECUTOR = Config.Option.create("camerax.core.io.ioExecutor", Executor.class);
  
  @NonNull
  Executor getIoExecutor();
  
  @Nullable
  Executor getIoExecutor(@Nullable Executor paramExecutor);
  
  public static interface Builder<B> {
    @NonNull
    B setIoExecutor(@NonNull Executor param1Executor);
  }
}


/* Location:              C:\soft\dex2jar-2.0\MagicAI - AI Art & Anime Art-dex2jar.jar!\androidx\camera\core\internal\IoConfig.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */