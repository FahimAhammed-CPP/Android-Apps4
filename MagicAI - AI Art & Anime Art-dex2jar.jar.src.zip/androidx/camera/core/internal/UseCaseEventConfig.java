package androidx.camera.core.internal;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.annotation.RequiresApi;
import androidx.camera.core.UseCase;
import androidx.camera.core.impl.Config;
import androidx.camera.core.impl.ReadableConfig;

@RequiresApi(21)
public interface UseCaseEventConfig extends ReadableConfig {
  public static final Config.Option<UseCase.EventCallback> OPTION_USE_CASE_EVENT_CALLBACK = Config.Option.create("camerax.core.useCaseEventCallback", UseCase.EventCallback.class);
  
  @NonNull
  UseCase.EventCallback getUseCaseEventCallback();
  
  @Nullable
  UseCase.EventCallback getUseCaseEventCallback(@Nullable UseCase.EventCallback paramEventCallback);
  
  public static interface Builder<B> {
    @NonNull
    B setUseCaseEventCallback(@NonNull UseCase.EventCallback param1EventCallback);
  }
}


/* Location:              C:\soft\dex2jar-2.0\MagicAI - AI Art & Anime Art-dex2jar.jar!\androidx\camera\core\internal\UseCaseEventConfig.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */