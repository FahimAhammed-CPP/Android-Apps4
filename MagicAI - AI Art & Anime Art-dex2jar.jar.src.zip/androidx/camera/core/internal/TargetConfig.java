package androidx.camera.core.internal;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.annotation.RequiresApi;
import androidx.annotation.RestrictTo;
import androidx.camera.core.impl.Config;
import androidx.camera.core.impl.ReadableConfig;

@RequiresApi(21)
public interface TargetConfig<T> extends ReadableConfig {
  @NonNull
  @RestrictTo({RestrictTo.Scope.LIBRARY_GROUP})
  public static final Config.Option<Class<?>> OPTION_TARGET_CLASS;
  
  @NonNull
  @RestrictTo({RestrictTo.Scope.LIBRARY_GROUP})
  public static final Config.Option<String> OPTION_TARGET_NAME = Config.Option.create("camerax.core.target.name", String.class);
  
  static {
    OPTION_TARGET_CLASS = Config.Option.create("camerax.core.target.class", Class.class);
  }
  
  @NonNull
  Class<T> getTargetClass();
  
  @Nullable
  Class<T> getTargetClass(@Nullable Class<T> paramClass);
  
  @NonNull
  String getTargetName();
  
  @Nullable
  String getTargetName(@Nullable String paramString);
  
  public static interface Builder<T, B> {
    @NonNull
    B setTargetClass(@NonNull Class<T> param1Class);
    
    @NonNull
    B setTargetName(@NonNull String param1String);
  }
}


/* Location:              C:\soft\dex2jar-2.0\MagicAI - AI Art & Anime Art-dex2jar.jar!\androidx\camera\core\internal\TargetConfig.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */