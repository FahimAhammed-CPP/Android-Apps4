package androidx.camera.core.internal;

import android.graphics.Matrix;
import androidx.annotation.NonNull;
import androidx.annotation.RequiresApi;
import androidx.camera.core.ImageInfo;
import androidx.camera.core.impl.CameraCaptureResult;
import androidx.camera.core.impl.TagBundle;
import androidx.camera.core.impl.utils.ExifData;

@RequiresApi(21)
public final class CameraCaptureResultImageInfo implements ImageInfo {
  private final CameraCaptureResult mCameraCaptureResult;
  
  public CameraCaptureResultImageInfo(@NonNull CameraCaptureResult paramCameraCaptureResult) {
    this.mCameraCaptureResult = paramCameraCaptureResult;
  }
  
  @NonNull
  public CameraCaptureResult getCameraCaptureResult() {
    return this.mCameraCaptureResult;
  }
  
  public int getRotationDegrees() {
    return 0;
  }
  
  @NonNull
  public Matrix getSensorToBufferTransformMatrix() {
    return new Matrix();
  }
  
  @NonNull
  public TagBundle getTagBundle() {
    return this.mCameraCaptureResult.getTagBundle();
  }
  
  public long getTimestamp() {
    return this.mCameraCaptureResult.getTimestamp();
  }
  
  public void populateExifData(@NonNull ExifData.Builder paramBuilder) {
    this.mCameraCaptureResult.populateExifData(paramBuilder);
  }
}


/* Location:              C:\soft\dex2jar-2.0\MagicAI - AI Art & Anime Art-dex2jar.jar!\androidx\camera\core\internal\CameraCaptureResultImageInfo.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */