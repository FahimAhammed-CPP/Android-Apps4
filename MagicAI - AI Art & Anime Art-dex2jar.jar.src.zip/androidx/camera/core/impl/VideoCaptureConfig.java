package androidx.camera.core.impl;

import android.util.Range;
import android.util.Size;
import androidx.annotation.NonNull;
import androidx.annotation.RequiresApi;
import androidx.camera.core.CameraSelector;
import androidx.camera.core.UseCase;
import androidx.camera.core.VideoCapture;
import androidx.camera.core.internal.TargetConfig;
import androidx.camera.core.internal.ThreadConfig;
import androidx.camera.core.internal.UseCaseEventConfig;
import java.util.List;
import java.util.Set;
import java.util.concurrent.Executor;

@RequiresApi(21)
public final class VideoCaptureConfig implements UseCaseConfig<VideoCapture>, ImageOutputConfig, ThreadConfig {
  public static final Config.Option<Integer> OPTION_AUDIO_BIT_RATE;
  
  public static final Config.Option<Integer> OPTION_AUDIO_CHANNEL_COUNT;
  
  public static final Config.Option<Integer> OPTION_AUDIO_MIN_BUFFER_SIZE;
  
  public static final Config.Option<Integer> OPTION_AUDIO_SAMPLE_RATE;
  
  public static final Config.Option<Integer> OPTION_BIT_RATE;
  
  public static final Config.Option<Integer> OPTION_INTRA_FRAME_INTERVAL;
  
  public static final Config.Option<Integer> OPTION_VIDEO_FRAME_RATE;
  
  private final OptionsBundle mConfig;
  
  static {
    Class<int> clazz = int.class;
    OPTION_VIDEO_FRAME_RATE = Config.Option.create("camerax.core.videoCapture.recordingFrameRate", clazz);
    OPTION_BIT_RATE = Config.Option.create("camerax.core.videoCapture.bitRate", clazz);
    OPTION_INTRA_FRAME_INTERVAL = Config.Option.create("camerax.core.videoCapture.intraFrameInterval", clazz);
    OPTION_AUDIO_BIT_RATE = Config.Option.create("camerax.core.videoCapture.audioBitRate", clazz);
    OPTION_AUDIO_SAMPLE_RATE = Config.Option.create("camerax.core.videoCapture.audioSampleRate", clazz);
    OPTION_AUDIO_CHANNEL_COUNT = Config.Option.create("camerax.core.videoCapture.audioChannelCount", clazz);
    OPTION_AUDIO_MIN_BUFFER_SIZE = Config.Option.create("camerax.core.videoCapture.audioMinBufferSize", clazz);
  }
  
  public VideoCaptureConfig(@NonNull OptionsBundle paramOptionsBundle) {
    this.mConfig = paramOptionsBundle;
  }
  
  public int getAudioBitRate() {
    return ((Integer)retrieveOption(OPTION_AUDIO_BIT_RATE)).intValue();
  }
  
  public int getAudioBitRate(int paramInt) {
    return ((Integer)retrieveOption(OPTION_AUDIO_BIT_RATE, Integer.valueOf(paramInt))).intValue();
  }
  
  public int getAudioChannelCount() {
    return ((Integer)retrieveOption(OPTION_AUDIO_CHANNEL_COUNT)).intValue();
  }
  
  public int getAudioChannelCount(int paramInt) {
    return ((Integer)retrieveOption(OPTION_AUDIO_CHANNEL_COUNT, Integer.valueOf(paramInt))).intValue();
  }
  
  public int getAudioMinBufferSize() {
    return ((Integer)retrieveOption(OPTION_AUDIO_MIN_BUFFER_SIZE)).intValue();
  }
  
  public int getAudioMinBufferSize(int paramInt) {
    return ((Integer)retrieveOption(OPTION_AUDIO_MIN_BUFFER_SIZE, Integer.valueOf(paramInt))).intValue();
  }
  
  public int getAudioSampleRate() {
    return ((Integer)retrieveOption(OPTION_AUDIO_SAMPLE_RATE)).intValue();
  }
  
  public int getAudioSampleRate(int paramInt) {
    return ((Integer)retrieveOption(OPTION_AUDIO_SAMPLE_RATE, Integer.valueOf(paramInt))).intValue();
  }
  
  public int getBitRate() {
    return ((Integer)retrieveOption(OPTION_BIT_RATE)).intValue();
  }
  
  public int getBitRate(int paramInt) {
    return ((Integer)retrieveOption(OPTION_BIT_RATE, Integer.valueOf(paramInt))).intValue();
  }
  
  @NonNull
  public Config getConfig() {
    return (Config)this.mConfig;
  }
  
  public int getIFrameInterval() {
    return ((Integer)retrieveOption(OPTION_INTRA_FRAME_INTERVAL)).intValue();
  }
  
  public int getIFrameInterval(int paramInt) {
    return ((Integer)retrieveOption(OPTION_INTRA_FRAME_INTERVAL, Integer.valueOf(paramInt))).intValue();
  }
  
  public int getInputFormat() {
    return 34;
  }
  
  public int getVideoFrameRate() {
    return ((Integer)retrieveOption(OPTION_VIDEO_FRAME_RATE)).intValue();
  }
  
  public int getVideoFrameRate(int paramInt) {
    return ((Integer)retrieveOption(OPTION_VIDEO_FRAME_RATE, Integer.valueOf(paramInt))).intValue();
  }
}


/* Location:              C:\soft\dex2jar-2.0\MagicAI - AI Art & Anime Art-dex2jar.jar!\androidx\camera\core\impl\VideoCaptureConfig.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */