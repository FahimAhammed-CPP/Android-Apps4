package androidx.camera.core.impl;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.annotation.RequiresApi;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;

@RequiresApi(21)
public interface CameraConfig extends ReadableConfig {
  public static final Config.Option<Identifier> OPTION_COMPATIBILITY_ID;
  
  public static final Config.Option<SessionProcessor> OPTION_SESSION_PROCESSOR;
  
  public static final Config.Option<UseCaseConfigFactory> OPTION_USECASE_CONFIG_FACTORY = Config.Option.create("camerax.core.camera.useCaseConfigFactory", UseCaseConfigFactory.class);
  
  public static final Config.Option<Integer> OPTION_USE_CASE_COMBINATION_REQUIRED_RULE;
  
  public static final Config.Option<Boolean> OPTION_ZSL_DISABLED;
  
  public static final int REQUIRED_RULE_COEXISTING_PREVIEW_AND_IMAGE_CAPTURE = 1;
  
  public static final int REQUIRED_RULE_NONE = 0;
  
  static {
    OPTION_COMPATIBILITY_ID = Config.Option.create("camerax.core.camera.compatibilityId", Identifier.class);
    OPTION_USE_CASE_COMBINATION_REQUIRED_RULE = Config.Option.create("camerax.core.camera.useCaseCombinationRequiredRule", Integer.class);
    OPTION_SESSION_PROCESSOR = Config.Option.create("camerax.core.camera.SessionProcessor", SessionProcessor.class);
    OPTION_ZSL_DISABLED = Config.Option.create("camerax.core.camera.isZslDisabled", Boolean.class);
  }
  
  @NonNull
  Identifier getCompatibilityId();
  
  @NonNull
  SessionProcessor getSessionProcessor();
  
  @Nullable
  SessionProcessor getSessionProcessor(@Nullable SessionProcessor paramSessionProcessor);
  
  int getUseCaseCombinationRequiredRule();
  
  @NonNull
  UseCaseConfigFactory getUseCaseConfigFactory();
  
  public static interface Builder<B> {
    @NonNull
    B setCompatibilityId(@NonNull Identifier param1Identifier);
    
    @NonNull
    B setSessionProcessor(@NonNull SessionProcessor param1SessionProcessor);
    
    @NonNull
    B setUseCaseCombinationRequiredRule(int param1Int);
    
    @NonNull
    B setUseCaseConfigFactory(@NonNull UseCaseConfigFactory param1UseCaseConfigFactory);
    
    @NonNull
    B setZslDisabled(boolean param1Boolean);
  }
  
  @Retention(RetentionPolicy.SOURCE)
  public static @interface RequiredRule {}
}


/* Location:              C:\soft\dex2jar-2.0\MagicAI - AI Art & Anime Art-dex2jar.jar!\androidx\camera\core\impl\CameraConfig.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */