package androidx.camera.core.impl;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import java.util.List;

final class AutoValue_SessionConfig_OutputConfig extends SessionConfig.OutputConfig {
  private final String physicalCameraId;
  
  private final List<DeferrableSurface> sharedSurfaces;
  
  private final DeferrableSurface surface;
  
  private final int surfaceGroupId;
  
  private AutoValue_SessionConfig_OutputConfig(DeferrableSurface paramDeferrableSurface, List<DeferrableSurface> paramList, @Nullable String paramString, int paramInt) {
    this.surface = paramDeferrableSurface;
    this.sharedSurfaces = paramList;
    this.physicalCameraId = paramString;
    this.surfaceGroupId = paramInt;
  }
  
  public boolean equals(Object paramObject) {
    if (paramObject == this)
      return true; 
    if (paramObject instanceof SessionConfig.OutputConfig) {
      paramObject = paramObject;
      if (this.surface.equals(paramObject.getSurface()) && this.sharedSurfaces.equals(paramObject.getSharedSurfaces())) {
        String str = this.physicalCameraId;
        if (((str == null) ? (paramObject.getPhysicalCameraId() == null) : str.equals(paramObject.getPhysicalCameraId())) && this.surfaceGroupId == paramObject.getSurfaceGroupId())
          return true; 
      } 
      return false;
    } 
    return false;
  }
  
  @Nullable
  public String getPhysicalCameraId() {
    return this.physicalCameraId;
  }
  
  @NonNull
  public List<DeferrableSurface> getSharedSurfaces() {
    return this.sharedSurfaces;
  }
  
  @NonNull
  public DeferrableSurface getSurface() {
    return this.surface;
  }
  
  public int getSurfaceGroupId() {
    return this.surfaceGroupId;
  }
  
  public int hashCode() {
    int i;
    int j = this.surface.hashCode();
    int k = this.sharedSurfaces.hashCode();
    String str = this.physicalCameraId;
    if (str == null) {
      i = 0;
    } else {
      i = str.hashCode();
    } 
    return (((j ^ 0xF4243) * 1000003 ^ k) * 1000003 ^ i) * 1000003 ^ this.surfaceGroupId;
  }
  
  public String toString() {
    StringBuilder stringBuilder = new StringBuilder();
    stringBuilder.append("OutputConfig{surface=");
    stringBuilder.append(this.surface);
    stringBuilder.append(", sharedSurfaces=");
    stringBuilder.append(this.sharedSurfaces);
    stringBuilder.append(", physicalCameraId=");
    stringBuilder.append(this.physicalCameraId);
    stringBuilder.append(", surfaceGroupId=");
    stringBuilder.append(this.surfaceGroupId);
    stringBuilder.append("}");
    return stringBuilder.toString();
  }
  
  static final class Builder extends SessionConfig.OutputConfig.Builder {
    private String physicalCameraId;
    
    private List<DeferrableSurface> sharedSurfaces;
    
    private DeferrableSurface surface;
    
    private Integer surfaceGroupId;
    
    public SessionConfig.OutputConfig build() {
      DeferrableSurface deferrableSurface = this.surface;
      String str1 = "";
      if (deferrableSurface == null) {
        StringBuilder stringBuilder1 = new StringBuilder();
        stringBuilder1.append("");
        stringBuilder1.append(" surface");
        str1 = stringBuilder1.toString();
      } 
      String str2 = str1;
      if (this.sharedSurfaces == null) {
        StringBuilder stringBuilder1 = new StringBuilder();
        stringBuilder1.append(str1);
        stringBuilder1.append(" sharedSurfaces");
        str2 = stringBuilder1.toString();
      } 
      str1 = str2;
      if (this.surfaceGroupId == null) {
        StringBuilder stringBuilder1 = new StringBuilder();
        stringBuilder1.append(str2);
        stringBuilder1.append(" surfaceGroupId");
        str1 = stringBuilder1.toString();
      } 
      if (str1.isEmpty())
        return new AutoValue_SessionConfig_OutputConfig(this.surface, this.sharedSurfaces, this.physicalCameraId, this.surfaceGroupId.intValue()); 
      StringBuilder stringBuilder = new StringBuilder();
      stringBuilder.append("Missing required properties:");
      stringBuilder.append(str1);
      throw new IllegalStateException(stringBuilder.toString());
    }
    
    public SessionConfig.OutputConfig.Builder setPhysicalCameraId(@Nullable String param1String) {
      this.physicalCameraId = param1String;
      return this;
    }
    
    public SessionConfig.OutputConfig.Builder setSharedSurfaces(List<DeferrableSurface> param1List) {
      if (param1List != null) {
        this.sharedSurfaces = param1List;
        return this;
      } 
      throw new NullPointerException("Null sharedSurfaces");
    }
    
    public SessionConfig.OutputConfig.Builder setSurface(DeferrableSurface param1DeferrableSurface) {
      if (param1DeferrableSurface != null) {
        this.surface = param1DeferrableSurface;
        return this;
      } 
      throw new NullPointerException("Null surface");
    }
    
    public SessionConfig.OutputConfig.Builder setSurfaceGroupId(int param1Int) {
      this.surfaceGroupId = Integer.valueOf(param1Int);
      return this;
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\MagicAI - AI Art & Anime Art-dex2jar.jar!\androidx\camera\core\impl\AutoValue_SessionConfig_OutputConfig.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */