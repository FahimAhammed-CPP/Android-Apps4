package androidx.camera.core.impl;

import androidx.annotation.Nullable;
import androidx.annotation.RequiresApi;

@RequiresApi(21)
public interface CamcorderProfileProvider {
  public static final CamcorderProfileProvider EMPTY = new CamcorderProfileProvider() {
      @Nullable
      public CamcorderProfileProxy get(int param1Int) {
        return null;
      }
      
      public boolean hasProfile(int param1Int) {
        return false;
      }
    };
  
  @Nullable
  CamcorderProfileProxy get(int paramInt);
  
  boolean hasProfile(int paramInt);
}


/* Location:              C:\soft\dex2jar-2.0\MagicAI - AI Art & Anime Art-dex2jar.jar!\androidx\camera\core\impl\CamcorderProfileProvider.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */