package androidx.camera.core.impl;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.annotation.RequiresApi;
import androidx.camera.core.CameraInfo;
import androidx.camera.core.CameraSelector;
import java.util.concurrent.Executor;

@RequiresApi(21)
public interface CameraInfoInternal extends CameraInfo {
  void addSessionCaptureCallback(@NonNull Executor paramExecutor, @NonNull CameraCaptureCallback paramCameraCaptureCallback);
  
  @NonNull
  CamcorderProfileProvider getCamcorderProfileProvider();
  
  @NonNull
  String getCameraId();
  
  @NonNull
  Quirks getCameraQuirks();
  
  @NonNull
  CameraSelector getCameraSelector();
  
  @Nullable
  Integer getLensFacing();
  
  @NonNull
  Timebase getTimebase();
  
  void removeSessionCaptureCallback(@NonNull CameraCaptureCallback paramCameraCaptureCallback);
}


/* Location:              C:\soft\dex2jar-2.0\MagicAI - AI Art & Anime Art-dex2jar.jar!\androidx\camera\core\impl\CameraInfoInternal.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */