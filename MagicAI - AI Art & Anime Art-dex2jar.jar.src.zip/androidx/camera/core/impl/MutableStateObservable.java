package androidx.camera.core.impl;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.annotation.RequiresApi;

@RequiresApi(21)
public class MutableStateObservable<T> extends StateObservable<T> {
  private MutableStateObservable(@Nullable Object paramObject, boolean paramBoolean) {
    super(paramObject, paramBoolean);
  }
  
  @NonNull
  public static <T> MutableStateObservable<T> withInitialError(@NonNull Throwable paramThrowable) {
    return new MutableStateObservable<T>(paramThrowable, true);
  }
  
  @NonNull
  public static <T> MutableStateObservable<T> withInitialState(@Nullable T paramT) {
    return new MutableStateObservable<T>(paramT, false);
  }
  
  public void setError(@NonNull Throwable paramThrowable) {
    updateStateAsError(paramThrowable);
  }
  
  public void setState(@Nullable T paramT) {
    updateState(paramT);
  }
}


/* Location:              C:\soft\dex2jar-2.0\MagicAI - AI Art & Anime Art-dex2jar.jar!\androidx\camera\core\impl\MutableStateObservable.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */