package androidx.camera.core.impl;

import android.os.Handler;
import androidx.annotation.NonNull;
import androidx.annotation.RequiresApi;
import java.util.concurrent.Executor;

@RequiresApi(21)
public abstract class CameraThreadConfig {
  @NonNull
  public static CameraThreadConfig create(@NonNull Executor paramExecutor, @NonNull Handler paramHandler) {
    return (CameraThreadConfig)new AutoValue_CameraThreadConfig(paramExecutor, paramHandler);
  }
  
  @NonNull
  public abstract Executor getCameraExecutor();
  
  @NonNull
  public abstract Handler getSchedulerHandler();
}


/* Location:              C:\soft\dex2jar-2.0\MagicAI - AI Art & Anime Art-dex2jar.jar!\androidx\camera\core\impl\CameraThreadConfig.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */