package androidx.camera.core.impl;

import android.content.Context;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.annotation.RequiresApi;
import androidx.camera.core.CameraInfo;

@RequiresApi(21)
public interface CameraConfigProvider {
  public static final CameraConfigProvider EMPTY = (CameraConfigProvider)new CameraConfigProvider$.ExternalSyntheticLambda0();
  
  @Nullable
  CameraConfig getConfig(@NonNull CameraInfo paramCameraInfo, @NonNull Context paramContext);
}


/* Location:              C:\soft\dex2jar-2.0\MagicAI - AI Art & Anime Art-dex2jar.jar!\androidx\camera\core\impl\CameraConfigProvider.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */