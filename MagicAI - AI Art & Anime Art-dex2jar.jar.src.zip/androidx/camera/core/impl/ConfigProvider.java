package androidx.camera.core.impl;

import androidx.annotation.NonNull;
import androidx.annotation.RequiresApi;

@RequiresApi(21)
public interface ConfigProvider<C extends Config> {
  @NonNull
  C getConfig();
}


/* Location:              C:\soft\dex2jar-2.0\MagicAI - AI Art & Anime Art-dex2jar.jar!\androidx\camera\core\impl\ConfigProvider.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */