package androidx.camera.core.impl.utils.futures;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.annotation.RequiresApi;
import androidx.arch.core.util.Function;
import androidx.camera.core.impl.utils.executor.CameraXExecutors;
import androidx.concurrent.futures.CallbackToFutureAdapter;
import androidx.core.util.Preconditions;
import com.google.common.util.concurrent.ListenableFuture;
import java.util.ArrayList;
import java.util.Collection;
import java.util.List;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.Executor;
import java.util.concurrent.Future;
import java.util.concurrent.ScheduledFuture;

@RequiresApi(21)
public final class Futures {
  private static final Function<?, ?> IDENTITY_FUNCTION = new Function<Object, Object>() {
      public Object apply(Object param1Object) {
        return param1Object;
      }
    };
  
  public static <V> void addCallback(@NonNull ListenableFuture<V> paramListenableFuture, @NonNull FutureCallback<? super V> paramFutureCallback, @NonNull Executor paramExecutor) {
    Preconditions.checkNotNull(paramFutureCallback);
    paramListenableFuture.addListener(new CallbackListener<V>((Future<V>)paramListenableFuture, paramFutureCallback), paramExecutor);
  }
  
  @NonNull
  public static <V> ListenableFuture<List<V>> allAsList(@NonNull Collection<? extends ListenableFuture<? extends V>> paramCollection) {
    return (ListenableFuture<List<V>>)new ListFuture(new ArrayList<ListenableFuture<? extends V>>(paramCollection), true, CameraXExecutors.directExecutor());
  }
  
  @Nullable
  public static <V> V getDone(@NonNull Future<V> paramFuture) throws ExecutionException {
    boolean bool = paramFuture.isDone();
    StringBuilder stringBuilder = new StringBuilder();
    stringBuilder.append("Future was expected to be done, ");
    stringBuilder.append(paramFuture);
    Preconditions.checkState(bool, stringBuilder.toString());
    return getUninterruptibly(paramFuture);
  }
  
  @Nullable
  public static <V> V getUninterruptibly(@NonNull Future<V> paramFuture) throws ExecutionException {
    boolean bool = false;
    while (true) {
      try {
        return paramFuture.get();
      } catch (InterruptedException interruptedException) {
      
      } finally {
        if (bool)
          Thread.currentThread().interrupt(); 
      } 
    } 
  }
  
  @NonNull
  public static <V> ListenableFuture<V> immediateFailedFuture(@NonNull Throwable paramThrowable) {
    return (ListenableFuture<V>)new ImmediateFuture.ImmediateFailedFuture(paramThrowable);
  }
  
  @NonNull
  public static <V> ScheduledFuture<V> immediateFailedScheduledFuture(@NonNull Throwable paramThrowable) {
    return (ScheduledFuture<V>)new ImmediateFuture.ImmediateFailedScheduledFuture(paramThrowable);
  }
  
  @NonNull
  public static <V> ListenableFuture<V> immediateFuture(@Nullable V paramV) {
    return (ListenableFuture<V>)((paramV == null) ? ImmediateFuture.nullFuture() : new ImmediateFuture.ImmediateSuccessfulFuture(paramV));
  }
  
  @NonNull
  public static <V> ListenableFuture<V> nonCancellationPropagating(@NonNull ListenableFuture<V> paramListenableFuture) {
    Preconditions.checkNotNull(paramListenableFuture);
    return paramListenableFuture.isDone() ? paramListenableFuture : CallbackToFutureAdapter.getFuture((CallbackToFutureAdapter.Resolver)new Futures$.ExternalSyntheticLambda0(paramListenableFuture));
  }
  
  public static <V> void propagate(@NonNull ListenableFuture<V> paramListenableFuture, @NonNull CallbackToFutureAdapter.Completer<V> paramCompleter) {
    propagateTransform(paramListenableFuture, (Function)IDENTITY_FUNCTION, paramCompleter, CameraXExecutors.directExecutor());
  }
  
  public static <I, O> void propagateTransform(@NonNull ListenableFuture<I> paramListenableFuture, @NonNull Function<? super I, ? extends O> paramFunction, @NonNull CallbackToFutureAdapter.Completer<O> paramCompleter, @NonNull Executor paramExecutor) {
    propagateTransform(true, paramListenableFuture, paramFunction, paramCompleter, paramExecutor);
  }
  
  private static <I, O> void propagateTransform(boolean paramBoolean, @NonNull final ListenableFuture<I> input, @NonNull final Function<? super I, ? extends O> function, @NonNull final CallbackToFutureAdapter.Completer<O> completer, @NonNull Executor paramExecutor) {
    Preconditions.checkNotNull(input);
    Preconditions.checkNotNull(function);
    Preconditions.checkNotNull(completer);
    Preconditions.checkNotNull(paramExecutor);
    addCallback(input, new FutureCallback<I>() {
          public void onFailure(@NonNull Throwable param1Throwable) {
            completer.setException(param1Throwable);
          }
          
          public void onSuccess(@Nullable I param1I) {
            try {
              return;
            } finally {
              param1I = null;
              completer.setException((Throwable)param1I);
            } 
          }
        },  paramExecutor);
    if (paramBoolean)
      completer.addCancellationListener(new Runnable() {
            public void run() {
              input.cancel(true);
            }
          },  CameraXExecutors.directExecutor()); 
  }
  
  @NonNull
  public static <V> ListenableFuture<List<V>> successfulAsList(@NonNull Collection<? extends ListenableFuture<? extends V>> paramCollection) {
    return (ListenableFuture<List<V>>)new ListFuture(new ArrayList<ListenableFuture<? extends V>>(paramCollection), false, CameraXExecutors.directExecutor());
  }
  
  @NonNull
  public static <I, O> ListenableFuture<O> transform(@NonNull ListenableFuture<I> paramListenableFuture, @NonNull final Function<? super I, ? extends O> function, @NonNull Executor paramExecutor) {
    Preconditions.checkNotNull(function);
    return transformAsync(paramListenableFuture, new AsyncFunction<I, O>() {
          @NonNull
          public ListenableFuture<O> apply(I param1I) {
            return Futures.immediateFuture((O)function.apply(param1I));
          }
        },  paramExecutor);
  }
  
  @NonNull
  public static <I, O> ListenableFuture<O> transformAsync(@NonNull ListenableFuture<I> paramListenableFuture, @NonNull AsyncFunction<? super I, ? extends O> paramAsyncFunction, @NonNull Executor paramExecutor) {
    ChainingListenableFuture<I, O> chainingListenableFuture = new ChainingListenableFuture<I, O>(paramAsyncFunction, paramListenableFuture);
    paramListenableFuture.addListener(chainingListenableFuture, paramExecutor);
    return (ListenableFuture)chainingListenableFuture;
  }
  
  private static final class CallbackListener<V> implements Runnable {
    final FutureCallback<? super V> mCallback;
    
    final Future<V> mFuture;
    
    CallbackListener(Future<V> param1Future, FutureCallback<? super V> param1FutureCallback) {
      this.mFuture = param1Future;
      this.mCallback = param1FutureCallback;
    }
    
    public void run() {
      try {
        Object object = Futures.getDone((Future)this.mFuture);
        this.mCallback.onSuccess(object);
        return;
      } catch (ExecutionException executionException) {
        Throwable throwable = executionException.getCause();
        if (throwable == null) {
          this.mCallback.onFailure(executionException);
          return;
        } 
        this.mCallback.onFailure(throwable);
        return;
      } catch (RuntimeException runtimeException) {
        this.mCallback.onFailure(runtimeException);
        return;
      } catch (Error error) {
        this.mCallback.onFailure(error);
        return;
      } 
    }
    
    public String toString() {
      StringBuilder stringBuilder = new StringBuilder();
      stringBuilder.append(CallbackListener.class.getSimpleName());
      stringBuilder.append(",");
      stringBuilder.append(this.mCallback);
      return stringBuilder.toString();
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\MagicAI - AI Art & Anime Art-dex2jar.jar!\androidx\camera\core\imp\\utils\futures\Futures.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */