package androidx.camera.core.impl.utils.futures;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.annotation.RequiresApi;
import androidx.camera.core.impl.utils.executor.CameraXExecutors;
import androidx.core.util.Preconditions;
import com.google.common.util.concurrent.ListenableFuture;
import java.lang.reflect.UndeclaredThrowableException;
import java.util.concurrent.BlockingQueue;
import java.util.concurrent.CancellationException;
import java.util.concurrent.CountDownLatch;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.Future;
import java.util.concurrent.LinkedBlockingQueue;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.TimeoutException;

@RequiresApi(21)
class ChainingListenableFuture<I, O> extends FutureChain<O> implements Runnable {
  @Nullable
  private AsyncFunction<? super I, ? extends O> mFunction;
  
  @Nullable
  private ListenableFuture<? extends I> mInputFuture;
  
  private final BlockingQueue<Boolean> mMayInterruptIfRunningChannel = new LinkedBlockingQueue<Boolean>(1);
  
  private final CountDownLatch mOutputCreated = new CountDownLatch(1);
  
  @Nullable
  volatile ListenableFuture<? extends O> mOutputFuture;
  
  ChainingListenableFuture(@NonNull AsyncFunction<? super I, ? extends O> paramAsyncFunction, @NonNull ListenableFuture<? extends I> paramListenableFuture) {
    this.mFunction = (AsyncFunction<? super I, ? extends O>)Preconditions.checkNotNull(paramAsyncFunction);
    this.mInputFuture = (ListenableFuture<? extends I>)Preconditions.checkNotNull(paramListenableFuture);
  }
  
  private void cancel(@Nullable Future<?> paramFuture, boolean paramBoolean) {
    if (paramFuture != null)
      paramFuture.cancel(paramBoolean); 
  }
  
  private <E> void putUninterruptibly(@NonNull BlockingQueue<E> paramBlockingQueue, @NonNull E paramE) {
    boolean bool = false;
    while (true) {
      try {
        paramBlockingQueue.put(paramE);
        return;
      } catch (InterruptedException interruptedException) {
      
      } finally {
        if (bool)
          Thread.currentThread().interrupt(); 
      } 
    } 
  }
  
  private <E> E takeUninterruptibly(@NonNull BlockingQueue<E> paramBlockingQueue) {
    boolean bool = false;
    while (true) {
      try {
        return paramBlockingQueue.take();
      } catch (InterruptedException interruptedException) {
      
      } finally {
        if (bool)
          Thread.currentThread().interrupt(); 
      } 
    } 
  }
  
  public boolean cancel(boolean paramBoolean) {
    if (super.cancel(paramBoolean)) {
      putUninterruptibly(this.mMayInterruptIfRunningChannel, Boolean.valueOf(paramBoolean));
      cancel((Future<?>)this.mInputFuture, paramBoolean);
      cancel((Future<?>)this.mOutputFuture, paramBoolean);
      return true;
    } 
    return false;
  }
  
  @Nullable
  public O get() throws InterruptedException, ExecutionException {
    if (!isDone()) {
      ListenableFuture<? extends I> listenableFuture = this.mInputFuture;
      if (listenableFuture != null)
        listenableFuture.get(); 
      this.mOutputCreated.await();
      listenableFuture = this.mOutputFuture;
      if (listenableFuture != null)
        listenableFuture.get(); 
    } 
    return (O)super.get();
  }
  
  @Nullable
  public O get(long paramLong, @NonNull TimeUnit paramTimeUnit) throws TimeoutException, ExecutionException, InterruptedException {
    long l = paramLong;
    TimeUnit timeUnit = paramTimeUnit;
    if (!isDone()) {
      timeUnit = TimeUnit.NANOSECONDS;
      l = paramLong;
      TimeUnit timeUnit1 = paramTimeUnit;
      if (paramTimeUnit != timeUnit) {
        l = timeUnit.convert(paramLong, paramTimeUnit);
        timeUnit1 = timeUnit;
      } 
      ListenableFuture<? extends I> listenableFuture = this.mInputFuture;
      paramLong = l;
      if (listenableFuture != null) {
        paramLong = System.nanoTime();
        listenableFuture.get(l, timeUnit1);
        paramLong = l - Math.max(0L, System.nanoTime() - paramLong);
      } 
      l = System.nanoTime();
      if (this.mOutputCreated.await(paramLong, timeUnit1)) {
        paramLong -= Math.max(0L, System.nanoTime() - l);
        listenableFuture = this.mOutputFuture;
        l = paramLong;
        timeUnit = timeUnit1;
        if (listenableFuture != null) {
          listenableFuture.get(paramLong, timeUnit1);
          l = paramLong;
          timeUnit = timeUnit1;
        } 
      } else {
        throw new TimeoutException();
      } 
    } 
    return (O)super.get(l, timeUnit);
  }
  
  public void run() {
    try {
      final ListenableFuture<? extends O> outputFuture = (ListenableFuture<? extends O>)Futures.getUninterruptibly((Future)this.mInputFuture);
      listenableFuture = this.mFunction.apply(listenableFuture);
      this.mOutputFuture = listenableFuture;
      if (isCancelled()) {
        listenableFuture.cancel(((Boolean)takeUninterruptibly(this.mMayInterruptIfRunningChannel)).booleanValue());
        this.mOutputFuture = null;
      } else {
        listenableFuture.addListener(new Runnable() {
              public void run() {
                try {
                  ChainingListenableFuture.this.set(Futures.getUninterruptibly((Future<?>)outputFuture));
                  return;
                } catch (CancellationException cancellationException) {
                  ChainingListenableFuture.this.cancel(false);
                  return;
                } catch (ExecutionException executionException) {
                  ChainingListenableFuture.this.setException(executionException.getCause());
                  return;
                } finally {
                  ChainingListenableFuture.this.mOutputFuture = null;
                } 
              }
            },  CameraXExecutors.directExecutor());
        this.mFunction = null;
        this.mInputFuture = null;
        this.mOutputCreated.countDown();
      } 
      return;
    } catch (CancellationException cancellationException) {
      cancel(false);
      return;
    } catch (ExecutionException executionException) {
      setException(executionException.getCause());
      return;
    } catch (UndeclaredThrowableException undeclaredThrowableException) {
    
    } catch (Exception exception) {
    
    } catch (Error error) {
    
    } finally {
      this.mFunction = null;
      this.mInputFuture = null;
      this.mOutputCreated.countDown();
    } 
    this.mFunction = null;
    this.mInputFuture = null;
    this.mOutputCreated.countDown();
  }
}


/* Location:              C:\soft\dex2jar-2.0\MagicAI - AI Art & Anime Art-dex2jar.jar!\androidx\camera\core\imp\\utils\futures\ChainingListenableFuture.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */