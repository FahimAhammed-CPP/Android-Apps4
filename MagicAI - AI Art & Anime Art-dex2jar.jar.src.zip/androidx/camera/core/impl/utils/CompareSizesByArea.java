package androidx.camera.core.impl.utils;

import android.util.Size;
import androidx.annotation.NonNull;
import androidx.annotation.RequiresApi;
import java.util.Comparator;

@RequiresApi(21)
public final class CompareSizesByArea implements Comparator<Size> {
  private boolean mReverse;
  
  public CompareSizesByArea() {
    this(false);
  }
  
  public CompareSizesByArea(boolean paramBoolean) {
    this.mReverse = paramBoolean;
  }
  
  public int compare(@NonNull Size paramSize1, @NonNull Size paramSize2) {
    int j = Long.signum(paramSize1.getWidth() * paramSize1.getHeight() - paramSize2.getWidth() * paramSize2.getHeight());
    int i = j;
    if (this.mReverse)
      i = j * -1; 
    return i;
  }
}


/* Location:              C:\soft\dex2jar-2.0\MagicAI - AI Art & Anime Art-dex2jar.jar!\androidx\camera\core\imp\\utils\CompareSizesByArea.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */