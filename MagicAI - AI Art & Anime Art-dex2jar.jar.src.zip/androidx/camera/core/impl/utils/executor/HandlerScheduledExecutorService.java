package androidx.camera.core.impl.utils.executor;

import android.os.Handler;
import android.os.Looper;
import android.os.SystemClock;
import androidx.annotation.NonNull;
import androidx.annotation.RequiresApi;
import androidx.camera.core.impl.utils.futures.Futures;
import androidx.concurrent.futures.CallbackToFutureAdapter;
import com.google.common.util.concurrent.ListenableFuture;
import java.util.List;
import java.util.concurrent.AbstractExecutorService;
import java.util.concurrent.Callable;
import java.util.concurrent.Delayed;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.RejectedExecutionException;
import java.util.concurrent.RunnableScheduledFuture;
import java.util.concurrent.ScheduledExecutorService;
import java.util.concurrent.ScheduledFuture;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.TimeoutException;
import java.util.concurrent.atomic.AtomicReference;

@RequiresApi(21)
final class HandlerScheduledExecutorService extends AbstractExecutorService implements ScheduledExecutorService {
  private static ThreadLocal<ScheduledExecutorService> sThreadLocalInstance = new ThreadLocal<ScheduledExecutorService>() {
      public ScheduledExecutorService initialValue() {
        return (Looper.myLooper() == Looper.getMainLooper()) ? CameraXExecutors.mainThreadExecutor() : ((Looper.myLooper() != null) ? new HandlerScheduledExecutorService(new Handler(Looper.myLooper())) : null);
      }
    };
  
  private final Handler mHandler;
  
  HandlerScheduledExecutorService(@NonNull Handler paramHandler) {
    this.mHandler = paramHandler;
  }
  
  private RejectedExecutionException createPostFailedException() {
    StringBuilder stringBuilder = new StringBuilder();
    stringBuilder.append(this.mHandler);
    stringBuilder.append(" is shutting down");
    return new RejectedExecutionException(stringBuilder.toString());
  }
  
  static ScheduledExecutorService currentThreadExecutor() {
    ScheduledExecutorService scheduledExecutorService = sThreadLocalInstance.get();
    if (scheduledExecutorService == null) {
      Looper looper = Looper.myLooper();
      if (looper != null) {
        scheduledExecutorService = new HandlerScheduledExecutorService(new Handler(looper));
        sThreadLocalInstance.set(scheduledExecutorService);
        return scheduledExecutorService;
      } 
      throw new IllegalStateException("Current thread has no looper!");
    } 
    return scheduledExecutorService;
  }
  
  public boolean awaitTermination(long paramLong, @NonNull TimeUnit paramTimeUnit) {
    StringBuilder stringBuilder = new StringBuilder();
    stringBuilder.append(HandlerScheduledExecutorService.class.getSimpleName());
    stringBuilder.append(" cannot be shut down. Use Looper.quitSafely().");
    throw new UnsupportedOperationException(stringBuilder.toString());
  }
  
  public void execute(@NonNull Runnable paramRunnable) {
    if (this.mHandler.post(paramRunnable))
      return; 
    throw createPostFailedException();
  }
  
  public boolean isShutdown() {
    return false;
  }
  
  public boolean isTerminated() {
    return false;
  }
  
  public ScheduledFuture<?> schedule(@NonNull final Runnable command, long paramLong, @NonNull TimeUnit paramTimeUnit) {
    return schedule(new Callable<Void>() {
          public Void call() {
            command.run();
            return null;
          }
        },  paramLong, paramTimeUnit);
  }
  
  @NonNull
  public <V> ScheduledFuture<V> schedule(@NonNull Callable<V> paramCallable, long paramLong, @NonNull TimeUnit paramTimeUnit) {
    paramLong = SystemClock.uptimeMillis() + TimeUnit.MILLISECONDS.convert(paramLong, paramTimeUnit);
    HandlerScheduledFuture<V> handlerScheduledFuture = new HandlerScheduledFuture<V>(this.mHandler, paramLong, paramCallable);
    return this.mHandler.postAtTime(handlerScheduledFuture, paramLong) ? handlerScheduledFuture : Futures.immediateFailedScheduledFuture(createPostFailedException());
  }
  
  @NonNull
  public ScheduledFuture<?> scheduleAtFixedRate(@NonNull Runnable paramRunnable, long paramLong1, long paramLong2, @NonNull TimeUnit paramTimeUnit) {
    StringBuilder stringBuilder = new StringBuilder();
    stringBuilder.append(HandlerScheduledExecutorService.class.getSimpleName());
    stringBuilder.append(" does not yet support fixed-rate scheduling.");
    throw new UnsupportedOperationException(stringBuilder.toString());
  }
  
  @NonNull
  public ScheduledFuture<?> scheduleWithFixedDelay(@NonNull Runnable paramRunnable, long paramLong1, long paramLong2, @NonNull TimeUnit paramTimeUnit) {
    StringBuilder stringBuilder = new StringBuilder();
    stringBuilder.append(HandlerScheduledExecutorService.class.getSimpleName());
    stringBuilder.append(" does not yet support fixed-delay scheduling.");
    throw new UnsupportedOperationException(stringBuilder.toString());
  }
  
  public void shutdown() {
    StringBuilder stringBuilder = new StringBuilder();
    stringBuilder.append(HandlerScheduledExecutorService.class.getSimpleName());
    stringBuilder.append(" cannot be shut down. Use Looper.quitSafely().");
    throw new UnsupportedOperationException(stringBuilder.toString());
  }
  
  @NonNull
  public List<Runnable> shutdownNow() {
    StringBuilder stringBuilder = new StringBuilder();
    stringBuilder.append(HandlerScheduledExecutorService.class.getSimpleName());
    stringBuilder.append(" cannot be shut down. Use Looper.quitSafely().");
    throw new UnsupportedOperationException(stringBuilder.toString());
  }
  
  private static class HandlerScheduledFuture<V> implements RunnableScheduledFuture<V> {
    final AtomicReference<CallbackToFutureAdapter.Completer<V>> mCompleter = new AtomicReference<CallbackToFutureAdapter.Completer<V>>(null);
    
    private final ListenableFuture<V> mDelegate;
    
    private final long mRunAtMillis;
    
    private final Callable<V> mTask;
    
    HandlerScheduledFuture(final Handler handler, long param1Long, final Callable<V> task) {
      this.mRunAtMillis = param1Long;
      this.mTask = task;
      this.mDelegate = CallbackToFutureAdapter.getFuture(new CallbackToFutureAdapter.Resolver<V>() {
            public Object attachCompleter(@NonNull CallbackToFutureAdapter.Completer<V> param2Completer) throws RejectedExecutionException {
              param2Completer.addCancellationListener(new Runnable() {
                    public void run() {
                      if (HandlerScheduledExecutorService.HandlerScheduledFuture.this.mCompleter.getAndSet(null) != null) {
                        HandlerScheduledExecutorService.HandlerScheduledFuture.null  = HandlerScheduledExecutorService.HandlerScheduledFuture.null.this;
                        handler.removeCallbacks(HandlerScheduledExecutorService.HandlerScheduledFuture.this);
                      } 
                    }
                  },  CameraXExecutors.directExecutor());
              HandlerScheduledExecutorService.HandlerScheduledFuture.this.mCompleter.set(param2Completer);
              StringBuilder stringBuilder = new StringBuilder();
              stringBuilder.append("HandlerScheduledFuture-");
              stringBuilder.append(task.toString());
              return stringBuilder.toString();
            }
          });
    }
    
    public boolean cancel(boolean param1Boolean) {
      return this.mDelegate.cancel(param1Boolean);
    }
    
    public int compareTo(Delayed param1Delayed) {
      TimeUnit timeUnit = TimeUnit.MILLISECONDS;
      return Long.compare(getDelay(timeUnit), param1Delayed.getDelay(timeUnit));
    }
    
    public V get() throws ExecutionException, InterruptedException {
      return this.mDelegate.get();
    }
    
    public V get(long param1Long, @NonNull TimeUnit param1TimeUnit) throws ExecutionException, InterruptedException, TimeoutException {
      return this.mDelegate.get(param1Long, param1TimeUnit);
    }
    
    public long getDelay(TimeUnit param1TimeUnit) {
      return param1TimeUnit.convert(this.mRunAtMillis - System.currentTimeMillis(), TimeUnit.MILLISECONDS);
    }
    
    public boolean isCancelled() {
      return this.mDelegate.isCancelled();
    }
    
    public boolean isDone() {
      return this.mDelegate.isDone();
    }
    
    public boolean isPeriodic() {
      return false;
    }
    
    public void run() {
      CallbackToFutureAdapter.Completer completer = this.mCompleter.getAndSet(null);
      if (completer != null)
        try {
          completer.set(this.mTask.call());
          return;
        } catch (Exception exception) {
          completer.setException(exception);
        }  
    }
  }
  
  class null implements CallbackToFutureAdapter.Resolver<V> {
    public Object attachCompleter(@NonNull CallbackToFutureAdapter.Completer<V> param1Completer) throws RejectedExecutionException {
      param1Completer.addCancellationListener(new Runnable() {
            public void run() {
              if (this.this$1.this$0.mCompleter.getAndSet(null) != null) {
                HandlerScheduledExecutorService.HandlerScheduledFuture.null  = HandlerScheduledExecutorService.HandlerScheduledFuture.null.this;
                handler.removeCallbacks(.this$0);
              } 
            }
          },  CameraXExecutors.directExecutor());
      this.this$0.mCompleter.set(param1Completer);
      StringBuilder stringBuilder = new StringBuilder();
      stringBuilder.append("HandlerScheduledFuture-");
      stringBuilder.append(task.toString());
      return stringBuilder.toString();
    }
  }
  
  class null implements Runnable {
    public void run() {
      if (this.this$1.this$0.mCompleter.getAndSet(null) != null) {
        HandlerScheduledExecutorService.HandlerScheduledFuture.null  = this.this$1;
        handler.removeCallbacks(.this$0);
      } 
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\MagicAI - AI Art & Anime Art-dex2jar.jar!\androidx\camera\core\imp\\utils\executor\HandlerScheduledExecutorService.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */