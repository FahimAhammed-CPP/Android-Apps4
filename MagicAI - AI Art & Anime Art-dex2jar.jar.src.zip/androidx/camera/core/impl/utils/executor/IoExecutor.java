package androidx.camera.core.impl.utils.executor;

import androidx.annotation.NonNull;
import androidx.annotation.RequiresApi;
import java.util.Locale;
import java.util.concurrent.Executor;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.ThreadFactory;
import java.util.concurrent.atomic.AtomicInteger;

@RequiresApi(21)
final class IoExecutor implements Executor {
  private static volatile Executor sExecutor;
  
  private final ExecutorService mIoService = Executors.newFixedThreadPool(2, new ThreadFactory() {
        private static final String THREAD_NAME_STEM = "CameraX-camerax_io_%d";
        
        private final AtomicInteger mThreadId = new AtomicInteger(0);
        
        public Thread newThread(Runnable param1Runnable) {
          param1Runnable = new Thread(param1Runnable);
          param1Runnable.setName(String.format(Locale.US, "CameraX-camerax_io_%d", new Object[] { Integer.valueOf(this.mThreadId.getAndIncrement()) }));
          return (Thread)param1Runnable;
        }
      });
  
  static Executor getInstance() {
    // Byte code:
    //   0: getstatic androidx/camera/core/impl/utils/executor/IoExecutor.sExecutor : Ljava/util/concurrent/Executor;
    //   3: ifnull -> 10
    //   6: getstatic androidx/camera/core/impl/utils/executor/IoExecutor.sExecutor : Ljava/util/concurrent/Executor;
    //   9: areturn
    //   10: ldc androidx/camera/core/impl/utils/executor/IoExecutor
    //   12: monitorenter
    //   13: getstatic androidx/camera/core/impl/utils/executor/IoExecutor.sExecutor : Ljava/util/concurrent/Executor;
    //   16: ifnonnull -> 29
    //   19: new androidx/camera/core/impl/utils/executor/IoExecutor
    //   22: dup
    //   23: invokespecial <init> : ()V
    //   26: putstatic androidx/camera/core/impl/utils/executor/IoExecutor.sExecutor : Ljava/util/concurrent/Executor;
    //   29: ldc androidx/camera/core/impl/utils/executor/IoExecutor
    //   31: monitorexit
    //   32: getstatic androidx/camera/core/impl/utils/executor/IoExecutor.sExecutor : Ljava/util/concurrent/Executor;
    //   35: areturn
    //   36: astore_0
    //   37: ldc androidx/camera/core/impl/utils/executor/IoExecutor
    //   39: monitorexit
    //   40: aload_0
    //   41: athrow
    // Exception table:
    //   from	to	target	type
    //   13	29	36	finally
    //   29	32	36	finally
    //   37	40	36	finally
  }
  
  public void execute(@NonNull Runnable paramRunnable) {
    this.mIoService.execute(paramRunnable);
  }
}


/* Location:              C:\soft\dex2jar-2.0\MagicAI - AI Art & Anime Art-dex2jar.jar!\androidx\camera\core\imp\\utils\executor\IoExecutor.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */