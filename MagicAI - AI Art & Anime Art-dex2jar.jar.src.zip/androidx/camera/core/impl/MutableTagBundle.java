package androidx.camera.core.impl;

import android.util.ArrayMap;
import androidx.annotation.NonNull;
import androidx.annotation.RequiresApi;
import java.util.Map;

@RequiresApi(21)
public class MutableTagBundle extends TagBundle {
  private MutableTagBundle(Map<String, Object> paramMap) {
    super(paramMap);
  }
  
  @NonNull
  public static MutableTagBundle create() {
    return new MutableTagBundle((Map<String, Object>)new ArrayMap());
  }
  
  @NonNull
  public static MutableTagBundle from(@NonNull TagBundle paramTagBundle) {
    ArrayMap<String, Object> arrayMap = new ArrayMap();
    for (String str : paramTagBundle.listKeys())
      arrayMap.put(str, paramTagBundle.getTag(str)); 
    return new MutableTagBundle((Map<String, Object>)arrayMap);
  }
  
  public void addTagBundle(@NonNull TagBundle paramTagBundle) {
    Map map = this.mTagMap;
    if (map != null) {
      Map map1 = paramTagBundle.mTagMap;
      if (map1 != null)
        map.putAll(map1); 
    } 
  }
  
  public void putTag(@NonNull String paramString, @NonNull Object paramObject) {
    this.mTagMap.put(paramString, paramObject);
  }
}


/* Location:              C:\soft\dex2jar-2.0\MagicAI - AI Art & Anime Art-dex2jar.jar!\androidx\camera\core\impl\MutableTagBundle.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */