package androidx.camera.core.impl.annotation;

import androidx.annotation.RestrictTo;
import java.lang.annotation.ElementType;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.lang.annotation.Target;

@Retention(RetentionPolicy.SOURCE)
@Target({ElementType.METHOD})
@RestrictTo({RestrictTo.Scope.LIBRARY_GROUP})
public @interface ExecutedBy {
  String value();
}


/* Location:              C:\soft\dex2jar-2.0\MagicAI - AI Art & Anime Art-dex2jar.jar!\androidx\camera\core\impl\annotation\ExecutedBy.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */