package androidx.camera.core.impl;

import androidx.annotation.NonNull;

final class AutoValue_StateObservable_ErrorWrapper extends StateObservable.ErrorWrapper {
  private final Throwable error;
  
  AutoValue_StateObservable_ErrorWrapper(Throwable paramThrowable) {
    if (paramThrowable != null) {
      this.error = paramThrowable;
      return;
    } 
    throw new NullPointerException("Null error");
  }
  
  public boolean equals(Object paramObject) {
    if (paramObject == this)
      return true; 
    if (paramObject instanceof StateObservable.ErrorWrapper) {
      paramObject = paramObject;
      return this.error.equals(paramObject.getError());
    } 
    return false;
  }
  
  @NonNull
  public Throwable getError() {
    return this.error;
  }
  
  public int hashCode() {
    return this.error.hashCode() ^ 0xF4243;
  }
  
  public String toString() {
    StringBuilder stringBuilder = new StringBuilder();
    stringBuilder.append("ErrorWrapper{error=");
    stringBuilder.append(this.error);
    stringBuilder.append("}");
    return stringBuilder.toString();
  }
}


/* Location:              C:\soft\dex2jar-2.0\MagicAI - AI Art & Anime Art-dex2jar.jar!\androidx\camera\core\impl\AutoValue_StateObservable_ErrorWrapper.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */