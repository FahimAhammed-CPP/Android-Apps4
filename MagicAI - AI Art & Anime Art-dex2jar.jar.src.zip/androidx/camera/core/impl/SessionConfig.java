package androidx.camera.core.impl;

import android.hardware.camera2.CameraCaptureSession;
import android.hardware.camera2.CameraDevice;
import android.hardware.camera2.params.InputConfiguration;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.annotation.RequiresApi;
import androidx.camera.core.Logger;
import androidx.camera.core.internal.compat.workaround.SurfaceSorter;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collection;
import java.util.Collections;
import java.util.Iterator;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Set;

@RequiresApi(21)
public final class SessionConfig {
  private final List<CameraDevice.StateCallback> mDeviceStateCallbacks;
  
  private final List<ErrorListener> mErrorListeners;
  
  @Nullable
  private InputConfiguration mInputConfiguration;
  
  private final List<OutputConfig> mOutputConfigs;
  
  private final CaptureConfig mRepeatingCaptureConfig;
  
  private final List<CameraCaptureSession.StateCallback> mSessionStateCallbacks;
  
  private final List<CameraCaptureCallback> mSingleCameraCaptureCallbacks;
  
  SessionConfig(List<OutputConfig> paramList, List<CameraDevice.StateCallback> paramList1, List<CameraCaptureSession.StateCallback> paramList2, List<CameraCaptureCallback> paramList3, List<ErrorListener> paramList4, CaptureConfig paramCaptureConfig, @Nullable InputConfiguration paramInputConfiguration) {
    this.mOutputConfigs = paramList;
    this.mDeviceStateCallbacks = Collections.unmodifiableList(paramList1);
    this.mSessionStateCallbacks = Collections.unmodifiableList(paramList2);
    this.mSingleCameraCaptureCallbacks = Collections.unmodifiableList(paramList3);
    this.mErrorListeners = Collections.unmodifiableList(paramList4);
    this.mRepeatingCaptureConfig = paramCaptureConfig;
    this.mInputConfiguration = paramInputConfiguration;
  }
  
  @NonNull
  public static SessionConfig defaultEmptySessionConfig() {
    return new SessionConfig(new ArrayList<OutputConfig>(), new ArrayList<CameraDevice.StateCallback>(0), new ArrayList<CameraCaptureSession.StateCallback>(0), new ArrayList<CameraCaptureCallback>(0), new ArrayList<ErrorListener>(0), (new CaptureConfig.Builder()).build(), null);
  }
  
  @NonNull
  public List<CameraDevice.StateCallback> getDeviceStateCallbacks() {
    return this.mDeviceStateCallbacks;
  }
  
  @NonNull
  public List<ErrorListener> getErrorListeners() {
    return this.mErrorListeners;
  }
  
  @NonNull
  public Config getImplementationOptions() {
    return this.mRepeatingCaptureConfig.getImplementationOptions();
  }
  
  @Nullable
  public InputConfiguration getInputConfiguration() {
    return this.mInputConfiguration;
  }
  
  @NonNull
  public List<OutputConfig> getOutputConfigs() {
    return this.mOutputConfigs;
  }
  
  @NonNull
  public List<CameraCaptureCallback> getRepeatingCameraCaptureCallbacks() {
    return this.mRepeatingCaptureConfig.getCameraCaptureCallbacks();
  }
  
  @NonNull
  public CaptureConfig getRepeatingCaptureConfig() {
    return this.mRepeatingCaptureConfig;
  }
  
  @NonNull
  public List<CameraCaptureSession.StateCallback> getSessionStateCallbacks() {
    return this.mSessionStateCallbacks;
  }
  
  @NonNull
  public List<CameraCaptureCallback> getSingleCameraCaptureCallbacks() {
    return this.mSingleCameraCaptureCallbacks;
  }
  
  @NonNull
  public List<DeferrableSurface> getSurfaces() {
    ArrayList<DeferrableSurface> arrayList = new ArrayList();
    for (OutputConfig outputConfig : this.mOutputConfigs) {
      arrayList.add(outputConfig.getSurface());
      Iterator<DeferrableSurface> iterator = outputConfig.getSharedSurfaces().iterator();
      while (iterator.hasNext())
        arrayList.add(iterator.next()); 
    } 
    return Collections.unmodifiableList(arrayList);
  }
  
  public int getTemplateType() {
    return this.mRepeatingCaptureConfig.getTemplateType();
  }
  
  static class BaseBuilder {
    final CaptureConfig.Builder mCaptureConfigBuilder = new CaptureConfig.Builder();
    
    final List<CameraDevice.StateCallback> mDeviceStateCallbacks = new ArrayList<CameraDevice.StateCallback>();
    
    final List<SessionConfig.ErrorListener> mErrorListeners = new ArrayList<SessionConfig.ErrorListener>();
    
    @Nullable
    InputConfiguration mInputConfiguration;
    
    final Set<SessionConfig.OutputConfig> mOutputConfigs = new LinkedHashSet<SessionConfig.OutputConfig>();
    
    final List<CameraCaptureSession.StateCallback> mSessionStateCallbacks = new ArrayList<CameraCaptureSession.StateCallback>();
    
    final List<CameraCaptureCallback> mSingleCameraCaptureCallbacks = new ArrayList<CameraCaptureCallback>();
  }
  
  public static class Builder extends BaseBuilder {
    @NonNull
    public static Builder createFrom(@NonNull UseCaseConfig<?> param1UseCaseConfig) {
      SessionConfig.OptionUnpacker optionUnpacker = param1UseCaseConfig.getSessionOptionUnpacker(null);
      if (optionUnpacker != null) {
        Builder builder = new Builder();
        optionUnpacker.unpack(param1UseCaseConfig, builder);
        return builder;
      } 
      StringBuilder stringBuilder = new StringBuilder();
      stringBuilder.append("Implementation is missing option unpacker for ");
      stringBuilder.append(param1UseCaseConfig.getTargetName(param1UseCaseConfig.toString()));
      throw new IllegalStateException(stringBuilder.toString());
    }
    
    @NonNull
    public Builder addAllCameraCaptureCallbacks(@NonNull Collection<CameraCaptureCallback> param1Collection) {
      for (CameraCaptureCallback cameraCaptureCallback : param1Collection) {
        this.mCaptureConfigBuilder.addCameraCaptureCallback(cameraCaptureCallback);
        if (!this.mSingleCameraCaptureCallbacks.contains(cameraCaptureCallback))
          this.mSingleCameraCaptureCallbacks.add(cameraCaptureCallback); 
      } 
      return this;
    }
    
    @NonNull
    public Builder addAllDeviceStateCallbacks(@NonNull Collection<CameraDevice.StateCallback> param1Collection) {
      Iterator<CameraDevice.StateCallback> iterator = param1Collection.iterator();
      while (iterator.hasNext())
        addDeviceStateCallback(iterator.next()); 
      return this;
    }
    
    @NonNull
    public Builder addAllRepeatingCameraCaptureCallbacks(@NonNull Collection<CameraCaptureCallback> param1Collection) {
      this.mCaptureConfigBuilder.addAllCameraCaptureCallbacks(param1Collection);
      return this;
    }
    
    @NonNull
    public Builder addAllSessionStateCallbacks(@NonNull List<CameraCaptureSession.StateCallback> param1List) {
      Iterator<CameraCaptureSession.StateCallback> iterator = param1List.iterator();
      while (iterator.hasNext())
        addSessionStateCallback(iterator.next()); 
      return this;
    }
    
    @NonNull
    public Builder addCameraCaptureCallback(@NonNull CameraCaptureCallback param1CameraCaptureCallback) {
      this.mCaptureConfigBuilder.addCameraCaptureCallback(param1CameraCaptureCallback);
      if (!this.mSingleCameraCaptureCallbacks.contains(param1CameraCaptureCallback))
        this.mSingleCameraCaptureCallbacks.add(param1CameraCaptureCallback); 
      return this;
    }
    
    @NonNull
    public Builder addDeviceStateCallback(@NonNull CameraDevice.StateCallback param1StateCallback) {
      if (this.mDeviceStateCallbacks.contains(param1StateCallback))
        return this; 
      this.mDeviceStateCallbacks.add(param1StateCallback);
      return this;
    }
    
    @NonNull
    public Builder addErrorListener(@NonNull SessionConfig.ErrorListener param1ErrorListener) {
      this.mErrorListeners.add(param1ErrorListener);
      return this;
    }
    
    @NonNull
    public Builder addImplementationOptions(@NonNull Config param1Config) {
      this.mCaptureConfigBuilder.addImplementationOptions(param1Config);
      return this;
    }
    
    @NonNull
    public Builder addNonRepeatingSurface(@NonNull DeferrableSurface param1DeferrableSurface) {
      SessionConfig.OutputConfig outputConfig = SessionConfig.OutputConfig.builder(param1DeferrableSurface).build();
      this.mOutputConfigs.add(outputConfig);
      return this;
    }
    
    @NonNull
    public Builder addOutputConfig(@NonNull SessionConfig.OutputConfig param1OutputConfig) {
      this.mOutputConfigs.add(param1OutputConfig);
      this.mCaptureConfigBuilder.addSurface(param1OutputConfig.getSurface());
      for (DeferrableSurface deferrableSurface : param1OutputConfig.getSharedSurfaces())
        this.mCaptureConfigBuilder.addSurface(deferrableSurface); 
      return this;
    }
    
    @NonNull
    public Builder addRepeatingCameraCaptureCallback(@NonNull CameraCaptureCallback param1CameraCaptureCallback) {
      this.mCaptureConfigBuilder.addCameraCaptureCallback(param1CameraCaptureCallback);
      return this;
    }
    
    @NonNull
    public Builder addSessionStateCallback(@NonNull CameraCaptureSession.StateCallback param1StateCallback) {
      if (this.mSessionStateCallbacks.contains(param1StateCallback))
        return this; 
      this.mSessionStateCallbacks.add(param1StateCallback);
      return this;
    }
    
    @NonNull
    public Builder addSurface(@NonNull DeferrableSurface param1DeferrableSurface) {
      SessionConfig.OutputConfig outputConfig = SessionConfig.OutputConfig.builder(param1DeferrableSurface).build();
      this.mOutputConfigs.add(outputConfig);
      this.mCaptureConfigBuilder.addSurface(param1DeferrableSurface);
      return this;
    }
    
    @NonNull
    public Builder addTag(@NonNull String param1String, @NonNull Object param1Object) {
      this.mCaptureConfigBuilder.addTag(param1String, param1Object);
      return this;
    }
    
    @NonNull
    public SessionConfig build() {
      return new SessionConfig(new ArrayList<SessionConfig.OutputConfig>(this.mOutputConfigs), this.mDeviceStateCallbacks, this.mSessionStateCallbacks, this.mSingleCameraCaptureCallbacks, this.mErrorListeners, this.mCaptureConfigBuilder.build(), this.mInputConfiguration);
    }
    
    @NonNull
    public Builder clearSurfaces() {
      this.mOutputConfigs.clear();
      this.mCaptureConfigBuilder.clearSurfaces();
      return this;
    }
    
    @NonNull
    public List<CameraCaptureCallback> getSingleCameraCaptureCallbacks() {
      return Collections.unmodifiableList(this.mSingleCameraCaptureCallbacks);
    }
    
    public boolean removeCameraCaptureCallback(@NonNull CameraCaptureCallback param1CameraCaptureCallback) {
      boolean bool1 = this.mCaptureConfigBuilder.removeCameraCaptureCallback(param1CameraCaptureCallback);
      boolean bool2 = this.mSingleCameraCaptureCallbacks.remove(param1CameraCaptureCallback);
      return (bool1 || bool2);
    }
    
    @NonNull
    public Builder removeSurface(@NonNull DeferrableSurface param1DeferrableSurface) {
      // Byte code:
      //   0: aload_0
      //   1: getfield mOutputConfigs : Ljava/util/Set;
      //   4: invokeinterface iterator : ()Ljava/util/Iterator;
      //   9: astore_3
      //   10: aload_3
      //   11: invokeinterface hasNext : ()Z
      //   16: ifeq -> 43
      //   19: aload_3
      //   20: invokeinterface next : ()Ljava/lang/Object;
      //   25: checkcast androidx/camera/core/impl/SessionConfig$OutputConfig
      //   28: astore_2
      //   29: aload_2
      //   30: invokevirtual getSurface : ()Landroidx/camera/core/impl/DeferrableSurface;
      //   33: aload_1
      //   34: invokevirtual equals : (Ljava/lang/Object;)Z
      //   37: ifeq -> 10
      //   40: goto -> 45
      //   43: aconst_null
      //   44: astore_2
      //   45: aload_2
      //   46: ifnull -> 60
      //   49: aload_0
      //   50: getfield mOutputConfigs : Ljava/util/Set;
      //   53: aload_2
      //   54: invokeinterface remove : (Ljava/lang/Object;)Z
      //   59: pop
      //   60: aload_0
      //   61: getfield mCaptureConfigBuilder : Landroidx/camera/core/impl/CaptureConfig$Builder;
      //   64: aload_1
      //   65: invokevirtual removeSurface : (Landroidx/camera/core/impl/DeferrableSurface;)V
      //   68: aload_0
      //   69: areturn
    }
    
    @NonNull
    public Builder setImplementationOptions(@NonNull Config param1Config) {
      this.mCaptureConfigBuilder.setImplementationOptions(param1Config);
      return this;
    }
    
    @NonNull
    public Builder setInputConfiguration(@Nullable InputConfiguration param1InputConfiguration) {
      this.mInputConfiguration = param1InputConfiguration;
      return this;
    }
    
    @NonNull
    public Builder setTemplateType(int param1Int) {
      this.mCaptureConfigBuilder.setTemplateType(param1Int);
      return this;
    }
  }
  
  public static interface ErrorListener {
    void onError(@NonNull SessionConfig param1SessionConfig, @NonNull SessionConfig.SessionError param1SessionError);
  }
  
  public static interface OptionUnpacker {
    void unpack(@NonNull UseCaseConfig<?> param1UseCaseConfig, @NonNull SessionConfig.Builder param1Builder);
  }
  
  public static abstract class OutputConfig {
    public static final int SURFACE_GROUP_ID_NONE = -1;
    
    @NonNull
    public static Builder builder(@NonNull DeferrableSurface param1DeferrableSurface) {
      return (new AutoValue_SessionConfig_OutputConfig.Builder()).setSurface(param1DeferrableSurface).setSharedSurfaces(Collections.emptyList()).setPhysicalCameraId(null).setSurfaceGroupId(-1);
    }
    
    @Nullable
    public abstract String getPhysicalCameraId();
    
    @NonNull
    public abstract List<DeferrableSurface> getSharedSurfaces();
    
    @NonNull
    public abstract DeferrableSurface getSurface();
    
    public abstract int getSurfaceGroupId();
    
    public static abstract class Builder {
      @NonNull
      public abstract SessionConfig.OutputConfig build();
      
      @NonNull
      public abstract Builder setPhysicalCameraId(@Nullable String param2String);
      
      @NonNull
      public abstract Builder setSharedSurfaces(@NonNull List<DeferrableSurface> param2List);
      
      @NonNull
      public abstract Builder setSurface(@NonNull DeferrableSurface param2DeferrableSurface);
      
      @NonNull
      public abstract Builder setSurfaceGroupId(int param2Int);
    }
  }
  
  public static abstract class Builder {
    @NonNull
    public abstract SessionConfig.OutputConfig build();
    
    @NonNull
    public abstract Builder setPhysicalCameraId(@Nullable String param1String);
    
    @NonNull
    public abstract Builder setSharedSurfaces(@NonNull List<DeferrableSurface> param1List);
    
    @NonNull
    public abstract Builder setSurface(@NonNull DeferrableSurface param1DeferrableSurface);
    
    @NonNull
    public abstract Builder setSurfaceGroupId(int param1Int);
  }
  
  public enum SessionError {
    SESSION_ERROR_SURFACE_NEEDS_RESET, SESSION_ERROR_UNKNOWN;
    
    static {
      SessionError sessionError1 = new SessionError("SESSION_ERROR_SURFACE_NEEDS_RESET", 0);
      SESSION_ERROR_SURFACE_NEEDS_RESET = sessionError1;
      SessionError sessionError2 = new SessionError("SESSION_ERROR_UNKNOWN", 1);
      SESSION_ERROR_UNKNOWN = sessionError2;
      $VALUES = new SessionError[] { sessionError1, sessionError2 };
    }
  }
  
  public static final class ValidatingBuilder extends BaseBuilder {
    private static final List<Integer> SUPPORTED_TEMPLATE_PRIORITY = Arrays.asList(new Integer[] { Integer.valueOf(1), Integer.valueOf(5), Integer.valueOf(3) });
    
    private static final String TAG = "ValidatingBuilder";
    
    private final SurfaceSorter mSurfaceSorter = new SurfaceSorter();
    
    private boolean mTemplateSet = false;
    
    private boolean mValid = true;
    
    private List<DeferrableSurface> getSurfaces() {
      ArrayList<DeferrableSurface> arrayList = new ArrayList();
      for (SessionConfig.OutputConfig outputConfig : this.mOutputConfigs) {
        arrayList.add(outputConfig.getSurface());
        Iterator<DeferrableSurface> iterator = outputConfig.getSharedSurfaces().iterator();
        while (iterator.hasNext())
          arrayList.add(iterator.next()); 
      } 
      return arrayList;
    }
    
    private int selectTemplateType(int param1Int1, int param1Int2) {
      List<Integer> list = SUPPORTED_TEMPLATE_PRIORITY;
      return (list.indexOf(Integer.valueOf(param1Int1)) >= list.indexOf(Integer.valueOf(param1Int2))) ? param1Int1 : param1Int2;
    }
    
    public void add(@NonNull SessionConfig param1SessionConfig) {
      CaptureConfig captureConfig = param1SessionConfig.getRepeatingCaptureConfig();
      if (captureConfig.getTemplateType() != -1) {
        this.mTemplateSet = true;
        this.mCaptureConfigBuilder.setTemplateType(selectTemplateType(captureConfig.getTemplateType(), this.mCaptureConfigBuilder.getTemplateType()));
      } 
      TagBundle tagBundle = param1SessionConfig.getRepeatingCaptureConfig().getTagBundle();
      this.mCaptureConfigBuilder.addAllTags(tagBundle);
      this.mDeviceStateCallbacks.addAll(param1SessionConfig.getDeviceStateCallbacks());
      this.mSessionStateCallbacks.addAll(param1SessionConfig.getSessionStateCallbacks());
      this.mCaptureConfigBuilder.addAllCameraCaptureCallbacks(param1SessionConfig.getRepeatingCameraCaptureCallbacks());
      this.mSingleCameraCaptureCallbacks.addAll(param1SessionConfig.getSingleCameraCaptureCallbacks());
      this.mErrorListeners.addAll(param1SessionConfig.getErrorListeners());
      if (param1SessionConfig.getInputConfiguration() != null)
        this.mInputConfiguration = param1SessionConfig.getInputConfiguration(); 
      this.mOutputConfigs.addAll(param1SessionConfig.getOutputConfigs());
      this.mCaptureConfigBuilder.getSurfaces().addAll(captureConfig.getSurfaces());
      if (!getSurfaces().containsAll(this.mCaptureConfigBuilder.getSurfaces())) {
        Logger.d("ValidatingBuilder", "Invalid configuration due to capture request surfaces are not a subset of surfaces");
        this.mValid = false;
      } 
      this.mCaptureConfigBuilder.addImplementationOptions(captureConfig.getImplementationOptions());
    }
    
    public <T> void addImplementationOption(@NonNull Config.Option<T> param1Option, @NonNull T param1T) {
      this.mCaptureConfigBuilder.addImplementationOption(param1Option, param1T);
    }
    
    @NonNull
    public SessionConfig build() {
      if (this.mValid) {
        ArrayList<SessionConfig.OutputConfig> arrayList = new ArrayList<SessionConfig.OutputConfig>(this.mOutputConfigs);
        this.mSurfaceSorter.sort(arrayList);
        return new SessionConfig(arrayList, this.mDeviceStateCallbacks, this.mSessionStateCallbacks, this.mSingleCameraCaptureCallbacks, this.mErrorListeners, this.mCaptureConfigBuilder.build(), this.mInputConfiguration);
      } 
      throw new IllegalArgumentException("Unsupported session configuration combination");
    }
    
    public void clearSurfaces() {
      this.mOutputConfigs.clear();
      this.mCaptureConfigBuilder.clearSurfaces();
    }
    
    public boolean isValid() {
      return (this.mTemplateSet && this.mValid);
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\MagicAI - AI Art & Anime Art-dex2jar.jar!\androidx\camera\core\impl\SessionConfig.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */