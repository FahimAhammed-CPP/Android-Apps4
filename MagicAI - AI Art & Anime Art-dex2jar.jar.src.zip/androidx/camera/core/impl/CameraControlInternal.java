package androidx.camera.core.impl;

import android.graphics.Rect;
import androidx.annotation.NonNull;
import androidx.annotation.RequiresApi;
import androidx.camera.core.CameraControl;
import androidx.camera.core.FocusMeteringAction;
import androidx.camera.core.FocusMeteringResult;
import androidx.camera.core.impl.utils.futures.Futures;
import com.google.common.util.concurrent.ListenableFuture;
import java.util.Collections;
import java.util.List;

@RequiresApi(21)
public interface CameraControlInternal extends CameraControl {
  public static final CameraControlInternal DEFAULT_EMPTY_INSTANCE = new CameraControlInternal() {
      public void addInteropConfig(@NonNull Config param1Config) {}
      
      public void addZslConfig(@NonNull SessionConfig.Builder param1Builder) {}
      
      @NonNull
      public ListenableFuture<Void> cancelFocusAndMetering() {
        return Futures.immediateFuture(null);
      }
      
      public void clearInteropConfig() {}
      
      @NonNull
      public ListenableFuture<Void> enableTorch(boolean param1Boolean) {
        return Futures.immediateFuture(null);
      }
      
      public int getFlashMode() {
        return 2;
      }
      
      @NonNull
      public Config getInteropConfig() {
        return null;
      }
      
      @NonNull
      public Rect getSensorRect() {
        return new Rect();
      }
      
      @NonNull
      public SessionConfig getSessionConfig() {
        return SessionConfig.defaultEmptySessionConfig();
      }
      
      public boolean isZslDisabledByByUserCaseConfig() {
        return false;
      }
      
      @NonNull
      public ListenableFuture<Integer> setExposureCompensationIndex(int param1Int) {
        return Futures.immediateFuture(Integer.valueOf(0));
      }
      
      public void setFlashMode(int param1Int) {}
      
      @NonNull
      public ListenableFuture<Void> setLinearZoom(float param1Float) {
        return Futures.immediateFuture(null);
      }
      
      @NonNull
      public ListenableFuture<Void> setZoomRatio(float param1Float) {
        return Futures.immediateFuture(null);
      }
      
      public void setZslDisabledByUserCaseConfig(boolean param1Boolean) {}
      
      @NonNull
      public ListenableFuture<FocusMeteringResult> startFocusAndMetering(@NonNull FocusMeteringAction param1FocusMeteringAction) {
        return Futures.immediateFuture(FocusMeteringResult.emptyInstance());
      }
      
      @NonNull
      public ListenableFuture<List<Void>> submitStillCaptureRequests(@NonNull List<CaptureConfig> param1List, int param1Int1, int param1Int2) {
        return Futures.immediateFuture(Collections.emptyList());
      }
    };
  
  void addInteropConfig(@NonNull Config paramConfig);
  
  void addZslConfig(@NonNull SessionConfig.Builder paramBuilder);
  
  void clearInteropConfig();
  
  int getFlashMode();
  
  @NonNull
  Config getInteropConfig();
  
  @NonNull
  Rect getSensorRect();
  
  @NonNull
  SessionConfig getSessionConfig();
  
  boolean isZslDisabledByByUserCaseConfig();
  
  void setFlashMode(int paramInt);
  
  void setZslDisabledByUserCaseConfig(boolean paramBoolean);
  
  @NonNull
  ListenableFuture<List<Void>> submitStillCaptureRequests(@NonNull List<CaptureConfig> paramList, int paramInt1, int paramInt2);
  
  public static final class CameraControlException extends Exception {
    @NonNull
    private CameraCaptureFailure mCameraCaptureFailure;
    
    public CameraControlException(@NonNull CameraCaptureFailure param1CameraCaptureFailure) {
      this.mCameraCaptureFailure = param1CameraCaptureFailure;
    }
    
    public CameraControlException(@NonNull CameraCaptureFailure param1CameraCaptureFailure, @NonNull Throwable param1Throwable) {
      super(param1Throwable);
      this.mCameraCaptureFailure = param1CameraCaptureFailure;
    }
    
    @NonNull
    public CameraCaptureFailure getCameraCaptureFailure() {
      return this.mCameraCaptureFailure;
    }
  }
  
  public static interface ControlUpdateCallback {
    void onCameraControlCaptureRequests(@NonNull List<CaptureConfig> param1List);
    
    void onCameraControlUpdateSessionConfig();
  }
}


/* Location:              C:\soft\dex2jar-2.0\MagicAI - AI Art & Anime Art-dex2jar.jar!\androidx\camera\core\impl\CameraControlInternal.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */