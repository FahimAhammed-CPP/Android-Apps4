package androidx.camera.core.impl;

import androidx.annotation.NonNull;
import androidx.annotation.RequiresApi;
import androidx.camera.core.CameraFilter;
import androidx.camera.core.CameraInfo;
import androidx.core.util.Preconditions;
import java.util.ArrayList;
import java.util.List;

@RequiresApi(21)
public class LensFacingCameraFilter implements CameraFilter {
  private int mLensFacing;
  
  public LensFacingCameraFilter(int paramInt) {
    this.mLensFacing = paramInt;
  }
  
  @NonNull
  public List<CameraInfo> filter(@NonNull List<CameraInfo> paramList) {
    ArrayList<CameraInfo> arrayList = new ArrayList();
    for (CameraInfo cameraInfo : paramList) {
      Preconditions.checkArgument(cameraInfo instanceof CameraInfoInternal, "The camera info doesn't contain internal implementation.");
      Integer integer = ((CameraInfoInternal)cameraInfo).getLensFacing();
      if (integer != null && integer.intValue() == this.mLensFacing)
        arrayList.add(cameraInfo); 
    } 
    return arrayList;
  }
  
  public int getLensFacing() {
    return this.mLensFacing;
  }
}


/* Location:              C:\soft\dex2jar-2.0\MagicAI - AI Art & Anime Art-dex2jar.jar!\androidx\camera\core\impl\LensFacingCameraFilter.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */