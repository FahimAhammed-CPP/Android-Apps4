package androidx.camera.core;

import android.util.SparseArray;
import androidx.annotation.GuardedBy;
import androidx.annotation.NonNull;
import androidx.annotation.RequiresApi;
import androidx.camera.core.impl.ImageProxyBundle;
import androidx.concurrent.futures.CallbackToFutureAdapter;
import com.google.common.util.concurrent.ListenableFuture;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Iterator;
import java.util.List;

@RequiresApi(21)
final class SettableImageProxyBundle implements ImageProxyBundle {
  private final List<Integer> mCaptureIdList;
  
  @GuardedBy("mLock")
  private boolean mClosed = false;
  
  @GuardedBy("mLock")
  final SparseArray<CallbackToFutureAdapter.Completer<ImageProxy>> mCompleters = new SparseArray();
  
  @GuardedBy("mLock")
  private final SparseArray<ListenableFuture<ImageProxy>> mFutureResults = new SparseArray();
  
  final Object mLock = new Object();
  
  @GuardedBy("mLock")
  private final List<ImageProxy> mOwnedImageProxies = new ArrayList<ImageProxy>();
  
  private String mTagBundleKey;
  
  SettableImageProxyBundle(List<Integer> paramList, String paramString) {
    this.mCaptureIdList = paramList;
    this.mTagBundleKey = paramString;
    setup();
  }
  
  private void setup() {
    synchronized (this.mLock) {
      Iterator<Integer> iterator = this.mCaptureIdList.iterator();
      while (iterator.hasNext()) {
        final int captureId = ((Integer)iterator.next()).intValue();
        ListenableFuture listenableFuture = CallbackToFutureAdapter.getFuture(new CallbackToFutureAdapter.Resolver<ImageProxy>() {
              public Object attachCompleter(@NonNull CallbackToFutureAdapter.Completer<ImageProxy> param1Completer) {
                synchronized (SettableImageProxyBundle.this.mLock) {
                  SettableImageProxyBundle.this.mCompleters.put(captureId, param1Completer);
                  StringBuilder stringBuilder = new StringBuilder();
                  stringBuilder.append("getImageProxy(id: ");
                  stringBuilder.append(captureId);
                  stringBuilder.append(")");
                  return stringBuilder.toString();
                } 
              }
            });
        this.mFutureResults.put(i, listenableFuture);
      } 
      return;
    } 
  }
  
  void addImageProxy(ImageProxy paramImageProxy) {
    synchronized (this.mLock) {
      if (this.mClosed)
        return; 
      Integer integer = (Integer)paramImageProxy.getImageInfo().getTagBundle().getTag(this.mTagBundleKey);
      if (integer != null) {
        CallbackToFutureAdapter.Completer completer = (CallbackToFutureAdapter.Completer)this.mCompleters.get(integer.intValue());
        if (completer != null) {
          this.mOwnedImageProxies.add(paramImageProxy);
          completer.set(paramImageProxy);
          return;
        } 
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("ImageProxyBundle does not contain this id: ");
        stringBuilder.append(integer);
        throw new IllegalArgumentException(stringBuilder.toString());
      } 
      throw new IllegalArgumentException("CaptureId is null.");
    } 
  }
  
  void close() {
    synchronized (this.mLock) {
      if (this.mClosed)
        return; 
      Iterator<ImageProxy> iterator = this.mOwnedImageProxies.iterator();
      while (iterator.hasNext())
        ((ImageProxy)iterator.next()).close(); 
      this.mOwnedImageProxies.clear();
      this.mFutureResults.clear();
      this.mCompleters.clear();
      this.mClosed = true;
      return;
    } 
  }
  
  @NonNull
  public List<Integer> getCaptureIds() {
    return Collections.unmodifiableList(this.mCaptureIdList);
  }
  
  @NonNull
  public ListenableFuture<ImageProxy> getImageProxy(int paramInt) {
    synchronized (this.mLock) {
      if (!this.mClosed) {
        ListenableFuture<ImageProxy> listenableFuture = (ListenableFuture)this.mFutureResults.get(paramInt);
        if (listenableFuture != null)
          return listenableFuture; 
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("ImageProxyBundle does not contain this id: ");
        stringBuilder.append(paramInt);
        throw new IllegalArgumentException(stringBuilder.toString());
      } 
      throw new IllegalStateException("ImageProxyBundle already closed.");
    } 
  }
  
  void reset() {
    synchronized (this.mLock) {
      if (this.mClosed)
        return; 
      Iterator<ImageProxy> iterator = this.mOwnedImageProxies.iterator();
      while (iterator.hasNext())
        ((ImageProxy)iterator.next()).close(); 
      this.mOwnedImageProxies.clear();
      this.mFutureResults.clear();
      this.mCompleters.clear();
      setup();
      return;
    } 
  }
}


/* Location:              C:\soft\dex2jar-2.0\MagicAI - AI Art & Anime Art-dex2jar.jar!\androidx\camera\core\SettableImageProxyBundle.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */