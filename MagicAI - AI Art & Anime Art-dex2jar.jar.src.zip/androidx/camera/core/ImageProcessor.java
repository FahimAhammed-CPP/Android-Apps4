package androidx.camera.core;

import androidx.annotation.AnyThread;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.annotation.RestrictTo;
import java.util.List;

@RestrictTo({RestrictTo.Scope.LIBRARY_GROUP})
public interface ImageProcessor {
  @NonNull
  Response process(@NonNull Request paramRequest);
  
  public static interface Request {
    @AnyThread
    @NonNull
    List<ImageProxy> getInputImages();
    
    @AnyThread
    int getOutputFormat();
  }
  
  public static interface Response {
    @AnyThread
    @Nullable
    ImageProxy getOutputImage();
  }
}


/* Location:              C:\soft\dex2jar-2.0\MagicAI - AI Art & Anime Art-dex2jar.jar!\androidx\camera\core\ImageProcessor.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */