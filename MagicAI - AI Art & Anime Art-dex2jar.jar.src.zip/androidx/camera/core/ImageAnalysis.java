package androidx.camera.core;

import android.graphics.Matrix;
import android.graphics.Rect;
import android.util.Pair;
import android.util.Size;
import androidx.annotation.GuardedBy;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.annotation.RequiresApi;
import androidx.annotation.RestrictTo;
import androidx.camera.core.impl.CameraInfoInternal;
import androidx.camera.core.impl.CameraInternal;
import androidx.camera.core.impl.CaptureConfig;
import androidx.camera.core.impl.Config;
import androidx.camera.core.impl.ConfigProvider;
import androidx.camera.core.impl.DeferrableSurface;
import androidx.camera.core.impl.ImageAnalysisConfig;
import androidx.camera.core.impl.ImageOutputConfig;
import androidx.camera.core.impl.MutableConfig;
import androidx.camera.core.impl.MutableOptionsBundle;
import androidx.camera.core.impl.OptionsBundle;
import androidx.camera.core.impl.SessionConfig;
import androidx.camera.core.impl.UseCaseConfig;
import androidx.camera.core.impl.UseCaseConfigFactory;
import androidx.camera.core.impl.utils.Threads;
import androidx.camera.core.impl.utils.executor.CameraXExecutors;
import androidx.camera.core.internal.TargetConfig;
import androidx.camera.core.internal.ThreadConfig;
import androidx.camera.core.internal.UseCaseEventConfig;
import androidx.camera.core.internal.compat.quirk.OnePixelShiftQuirk;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.util.List;
import java.util.UUID;
import java.util.concurrent.Executor;

@RequiresApi(21)
public final class ImageAnalysis extends UseCase {
  public static final int COORDINATE_SYSTEM_ORIGINAL = 0;
  
  private static final int DEFAULT_BACKPRESSURE_STRATEGY = 0;
  
  @RestrictTo({RestrictTo.Scope.LIBRARY_GROUP})
  public static final Defaults DEFAULT_CONFIG = new Defaults();
  
  private static final int DEFAULT_IMAGE_QUEUE_DEPTH = 6;
  
  private static final Boolean DEFAULT_ONE_PIXEL_SHIFT_ENABLED = null;
  
  private static final int DEFAULT_OUTPUT_IMAGE_FORMAT = 1;
  
  private static final boolean DEFAULT_OUTPUT_IMAGE_ROTATION_ENABLED = false;
  
  private static final int NON_BLOCKING_IMAGE_DEPTH = 4;
  
  public static final int OUTPUT_IMAGE_FORMAT_RGBA_8888 = 2;
  
  public static final int OUTPUT_IMAGE_FORMAT_YUV_420_888 = 1;
  
  public static final int STRATEGY_BLOCK_PRODUCER = 1;
  
  public static final int STRATEGY_KEEP_ONLY_LATEST = 0;
  
  private static final String TAG = "ImageAnalysis";
  
  private final Object mAnalysisLock = new Object();
  
  @Nullable
  private DeferrableSurface mDeferrableSurface;
  
  final ImageAnalysisAbstractAnalyzer mImageAnalysisAbstractAnalyzer;
  
  @GuardedBy("mAnalysisLock")
  private Analyzer mSubscribedAnalyzer;
  
  ImageAnalysis(@NonNull ImageAnalysisConfig paramImageAnalysisConfig) {
    super((UseCaseConfig)paramImageAnalysisConfig);
    if (((ImageAnalysisConfig)getCurrentConfig()).getBackpressureStrategy(0) == 1) {
      this.mImageAnalysisAbstractAnalyzer = (ImageAnalysisAbstractAnalyzer)new ImageAnalysisBlockingAnalyzer();
    } else {
      this.mImageAnalysisAbstractAnalyzer = (ImageAnalysisAbstractAnalyzer)new ImageAnalysisNonBlockingAnalyzer(paramImageAnalysisConfig.getBackgroundExecutor(CameraXExecutors.highPriorityExecutor()));
    } 
    this.mImageAnalysisAbstractAnalyzer.setOutputImageFormat(getOutputImageFormat());
    this.mImageAnalysisAbstractAnalyzer.setOutputImageRotationEnabled(isOutputImageRotationEnabled());
  }
  
  private boolean isFlipWH(@NonNull CameraInternal paramCameraInternal) {
    boolean bool = isOutputImageRotationEnabled();
    boolean bool2 = false;
    boolean bool1 = bool2;
    if (bool) {
      bool1 = bool2;
      if (getRelativeRotation(paramCameraInternal) % 180 != 0)
        bool1 = true; 
    } 
    return bool1;
  }
  
  private void tryUpdateRelativeRotation() {
    CameraInternal cameraInternal = getCamera();
    if (cameraInternal != null)
      this.mImageAnalysisAbstractAnalyzer.setRelativeRotation(getRelativeRotation(cameraInternal)); 
  }
  
  public void clearAnalyzer() {
    synchronized (this.mAnalysisLock) {
      this.mImageAnalysisAbstractAnalyzer.setAnalyzer(null, null);
      if (this.mSubscribedAnalyzer != null)
        notifyInactive(); 
      this.mSubscribedAnalyzer = null;
      return;
    } 
  }
  
  void clearPipeline() {
    Threads.checkMainThread();
    DeferrableSurface deferrableSurface = this.mDeferrableSurface;
    if (deferrableSurface != null) {
      deferrableSurface.close();
      this.mDeferrableSurface = null;
    } 
  }
  
  SessionConfig.Builder createPipeline(@NonNull String paramString, @NonNull ImageAnalysisConfig paramImageAnalysisConfig, @NonNull Size paramSize) {
    // Byte code:
    //   0: invokestatic checkMainThread : ()V
    //   3: aload_2
    //   4: invokestatic highPriorityExecutor : ()Ljava/util/concurrent/Executor;
    //   7: invokevirtual getBackgroundExecutor : (Ljava/util/concurrent/Executor;)Ljava/util/concurrent/Executor;
    //   10: invokestatic checkNotNull : (Ljava/lang/Object;)Ljava/lang/Object;
    //   13: checkcast java/util/concurrent/Executor
    //   16: astore #13
    //   18: aload_0
    //   19: invokevirtual getBackpressureStrategy : ()I
    //   22: istore #4
    //   24: iconst_1
    //   25: istore #9
    //   27: iload #4
    //   29: iconst_1
    //   30: if_icmpne -> 42
    //   33: aload_0
    //   34: invokevirtual getImageQueueDepth : ()I
    //   37: istore #4
    //   39: goto -> 45
    //   42: iconst_4
    //   43: istore #4
    //   45: aload_2
    //   46: invokevirtual getImageReaderProxyProvider : ()Landroidx/camera/core/ImageReaderProxyProvider;
    //   49: ifnull -> 88
    //   52: new androidx/camera/core/SafeCloseImageReaderProxy
    //   55: dup
    //   56: aload_2
    //   57: invokevirtual getImageReaderProxyProvider : ()Landroidx/camera/core/ImageReaderProxyProvider;
    //   60: aload_3
    //   61: invokevirtual getWidth : ()I
    //   64: aload_3
    //   65: invokevirtual getHeight : ()I
    //   68: aload_0
    //   69: invokevirtual getImageFormat : ()I
    //   72: iload #4
    //   74: lconst_0
    //   75: invokeinterface newInstance : (IIIIJ)Landroidx/camera/core/impl/ImageReaderProxy;
    //   80: invokespecial <init> : (Landroidx/camera/core/impl/ImageReaderProxy;)V
    //   83: astore #11
    //   85: goto -> 114
    //   88: new androidx/camera/core/SafeCloseImageReaderProxy
    //   91: dup
    //   92: aload_3
    //   93: invokevirtual getWidth : ()I
    //   96: aload_3
    //   97: invokevirtual getHeight : ()I
    //   100: aload_0
    //   101: invokevirtual getImageFormat : ()I
    //   104: iload #4
    //   106: invokestatic createIsolatedReader : (IIII)Landroidx/camera/core/impl/ImageReaderProxy;
    //   109: invokespecial <init> : (Landroidx/camera/core/impl/ImageReaderProxy;)V
    //   112: astore #11
    //   114: aload_0
    //   115: invokevirtual getCamera : ()Landroidx/camera/core/impl/CameraInternal;
    //   118: ifnull -> 134
    //   121: aload_0
    //   122: aload_0
    //   123: invokevirtual getCamera : ()Landroidx/camera/core/impl/CameraInternal;
    //   126: invokespecial isFlipWH : (Landroidx/camera/core/impl/CameraInternal;)Z
    //   129: istore #10
    //   131: goto -> 137
    //   134: iconst_0
    //   135: istore #10
    //   137: iload #10
    //   139: ifeq -> 151
    //   142: aload_3
    //   143: invokevirtual getHeight : ()I
    //   146: istore #4
    //   148: goto -> 157
    //   151: aload_3
    //   152: invokevirtual getWidth : ()I
    //   155: istore #4
    //   157: iload #10
    //   159: ifeq -> 171
    //   162: aload_3
    //   163: invokevirtual getWidth : ()I
    //   166: istore #5
    //   168: goto -> 177
    //   171: aload_3
    //   172: invokevirtual getHeight : ()I
    //   175: istore #5
    //   177: aload_0
    //   178: invokevirtual getOutputImageFormat : ()I
    //   181: iconst_2
    //   182: if_icmpne -> 191
    //   185: iconst_1
    //   186: istore #6
    //   188: goto -> 195
    //   191: bipush #35
    //   193: istore #6
    //   195: aload_0
    //   196: invokevirtual getImageFormat : ()I
    //   199: bipush #35
    //   201: if_icmpne -> 218
    //   204: aload_0
    //   205: invokevirtual getOutputImageFormat : ()I
    //   208: iconst_2
    //   209: if_icmpne -> 218
    //   212: iconst_1
    //   213: istore #7
    //   215: goto -> 221
    //   218: iconst_0
    //   219: istore #7
    //   221: aload_0
    //   222: invokevirtual getImageFormat : ()I
    //   225: bipush #35
    //   227: if_icmpne -> 272
    //   230: aload_0
    //   231: invokevirtual getCamera : ()Landroidx/camera/core/impl/CameraInternal;
    //   234: ifnull -> 252
    //   237: iload #9
    //   239: istore #8
    //   241: aload_0
    //   242: aload_0
    //   243: invokevirtual getCamera : ()Landroidx/camera/core/impl/CameraInternal;
    //   246: invokevirtual getRelativeRotation : (Landroidx/camera/core/impl/CameraInternal;)I
    //   249: ifne -> 275
    //   252: getstatic java/lang/Boolean.TRUE : Ljava/lang/Boolean;
    //   255: aload_0
    //   256: invokevirtual getOnePixelShiftEnabled : ()Ljava/lang/Boolean;
    //   259: invokevirtual equals : (Ljava/lang/Object;)Z
    //   262: ifeq -> 272
    //   265: iload #9
    //   267: istore #8
    //   269: goto -> 275
    //   272: iconst_0
    //   273: istore #8
    //   275: iload #7
    //   277: ifne -> 294
    //   280: iload #8
    //   282: ifeq -> 288
    //   285: goto -> 294
    //   288: aconst_null
    //   289: astore #12
    //   291: goto -> 317
    //   294: new androidx/camera/core/SafeCloseImageReaderProxy
    //   297: dup
    //   298: iload #4
    //   300: iload #5
    //   302: iload #6
    //   304: aload #11
    //   306: invokevirtual getMaxImages : ()I
    //   309: invokestatic createIsolatedReader : (IIII)Landroidx/camera/core/impl/ImageReaderProxy;
    //   312: invokespecial <init> : (Landroidx/camera/core/impl/ImageReaderProxy;)V
    //   315: astore #12
    //   317: aload #12
    //   319: ifnull -> 331
    //   322: aload_0
    //   323: getfield mImageAnalysisAbstractAnalyzer : Landroidx/camera/core/ImageAnalysisAbstractAnalyzer;
    //   326: aload #12
    //   328: invokevirtual setProcessedImageReaderProxy : (Landroidx/camera/core/SafeCloseImageReaderProxy;)V
    //   331: aload_0
    //   332: invokespecial tryUpdateRelativeRotation : ()V
    //   335: aload #11
    //   337: aload_0
    //   338: getfield mImageAnalysisAbstractAnalyzer : Landroidx/camera/core/ImageAnalysisAbstractAnalyzer;
    //   341: aload #13
    //   343: invokevirtual setOnImageAvailableListener : (Landroidx/camera/core/impl/ImageReaderProxy$OnImageAvailableListener;Ljava/util/concurrent/Executor;)V
    //   346: aload_2
    //   347: invokestatic createFrom : (Landroidx/camera/core/impl/UseCaseConfig;)Landroidx/camera/core/impl/SessionConfig$Builder;
    //   350: astore #13
    //   352: aload_0
    //   353: getfield mDeferrableSurface : Landroidx/camera/core/impl/DeferrableSurface;
    //   356: astore #14
    //   358: aload #14
    //   360: ifnull -> 368
    //   363: aload #14
    //   365: invokevirtual close : ()V
    //   368: new androidx/camera/core/impl/ImmediateSurface
    //   371: dup
    //   372: aload #11
    //   374: invokevirtual getSurface : ()Landroid/view/Surface;
    //   377: aload_3
    //   378: aload_0
    //   379: invokevirtual getImageFormat : ()I
    //   382: invokespecial <init> : (Landroid/view/Surface;Landroid/util/Size;I)V
    //   385: astore #14
    //   387: aload_0
    //   388: aload #14
    //   390: putfield mDeferrableSurface : Landroidx/camera/core/impl/DeferrableSurface;
    //   393: aload #14
    //   395: invokevirtual getTerminationFuture : ()Lcom/google/common/util/concurrent/ListenableFuture;
    //   398: new androidx/camera/core/ImageAnalysis$$ExternalSyntheticLambda0
    //   401: dup
    //   402: aload #11
    //   404: aload #12
    //   406: invokespecial <init> : (Landroidx/camera/core/SafeCloseImageReaderProxy;Landroidx/camera/core/SafeCloseImageReaderProxy;)V
    //   409: invokestatic mainThreadExecutor : ()Ljava/util/concurrent/ScheduledExecutorService;
    //   412: invokeinterface addListener : (Ljava/lang/Runnable;Ljava/util/concurrent/Executor;)V
    //   417: aload #13
    //   419: aload_0
    //   420: getfield mDeferrableSurface : Landroidx/camera/core/impl/DeferrableSurface;
    //   423: invokevirtual addSurface : (Landroidx/camera/core/impl/DeferrableSurface;)Landroidx/camera/core/impl/SessionConfig$Builder;
    //   426: pop
    //   427: aload #13
    //   429: new androidx/camera/core/ImageAnalysis$$ExternalSyntheticLambda1
    //   432: dup
    //   433: aload_0
    //   434: aload_1
    //   435: aload_2
    //   436: aload_3
    //   437: invokespecial <init> : (Landroidx/camera/core/ImageAnalysis;Ljava/lang/String;Landroidx/camera/core/impl/ImageAnalysisConfig;Landroid/util/Size;)V
    //   440: invokevirtual addErrorListener : (Landroidx/camera/core/impl/SessionConfig$ErrorListener;)Landroidx/camera/core/impl/SessionConfig$Builder;
    //   443: pop
    //   444: aload #13
    //   446: areturn
  }
  
  @Nullable
  @ExperimentalUseCaseApi
  public Executor getBackgroundExecutor() {
    return ((ImageAnalysisConfig)getCurrentConfig()).getBackgroundExecutor(null);
  }
  
  public int getBackpressureStrategy() {
    return ((ImageAnalysisConfig)getCurrentConfig()).getBackpressureStrategy(0);
  }
  
  @Nullable
  @RestrictTo({RestrictTo.Scope.LIBRARY_GROUP})
  public UseCaseConfig<?> getDefaultConfig(boolean paramBoolean, @NonNull UseCaseConfigFactory paramUseCaseConfigFactory) {
    Config config2 = paramUseCaseConfigFactory.getConfig(UseCaseConfigFactory.CaptureType.IMAGE_ANALYSIS, 1);
    Config config1 = config2;
    if (paramBoolean)
      config1 = Config.-CC.mergeConfigs(config2, (Config)DEFAULT_CONFIG.getConfig()); 
    return (config1 == null) ? null : getUseCaseConfigBuilder(config1).getUseCaseConfig();
  }
  
  public int getImageQueueDepth() {
    return ((ImageAnalysisConfig)getCurrentConfig()).getImageQueueDepth(6);
  }
  
  @Nullable
  @RestrictTo({RestrictTo.Scope.LIBRARY_GROUP})
  public Boolean getOnePixelShiftEnabled() {
    return ((ImageAnalysisConfig)getCurrentConfig()).getOnePixelShiftEnabled(DEFAULT_ONE_PIXEL_SHIFT_ENABLED);
  }
  
  public int getOutputImageFormat() {
    return ((ImageAnalysisConfig)getCurrentConfig()).getOutputImageFormat(1);
  }
  
  @Nullable
  public ResolutionInfo getResolutionInfo() {
    return super.getResolutionInfo();
  }
  
  public int getTargetRotation() {
    return getTargetRotationInternal();
  }
  
  @NonNull
  @RestrictTo({RestrictTo.Scope.LIBRARY_GROUP})
  public UseCaseConfig.Builder<?, ?, ?> getUseCaseConfigBuilder(@NonNull Config paramConfig) {
    return Builder.fromConfig(paramConfig);
  }
  
  public boolean isOutputImageRotationEnabled() {
    return ((ImageAnalysisConfig)getCurrentConfig()).isOutputImageRotationEnabled(Boolean.FALSE).booleanValue();
  }
  
  @RestrictTo({RestrictTo.Scope.LIBRARY_GROUP})
  public void onAttached() {
    this.mImageAnalysisAbstractAnalyzer.attach();
  }
  
  @RestrictTo({RestrictTo.Scope.LIBRARY_GROUP})
  public void onDetached() {
    clearPipeline();
    this.mImageAnalysisAbstractAnalyzer.detach();
  }
  
  @NonNull
  @RestrictTo({RestrictTo.Scope.LIBRARY_GROUP})
  protected UseCaseConfig<?> onMergeConfig(@NonNull CameraInfoInternal paramCameraInfoInternal, @NonNull UseCaseConfig.Builder<?, ?, ?> paramBuilder) {
    Boolean bool1 = getOnePixelShiftEnabled();
    boolean bool = paramCameraInfoInternal.getCameraQuirks().contains(OnePixelShiftQuirk.class);
    null = this.mImageAnalysisAbstractAnalyzer;
    if (bool1 != null)
      bool = bool1.booleanValue(); 
    null.setOnePixelShiftEnabled(bool);
    synchronized (this.mAnalysisLock) {
      Analyzer analyzer = this.mSubscribedAnalyzer;
      if (analyzer != null) {
        Size size = analyzer.getDefaultTargetResolution();
      } else {
        analyzer = null;
      } 
      if (analyzer != null) {
        null = paramBuilder.getUseCaseConfig();
        Config.Option option = ImageOutputConfig.OPTION_TARGET_RESOLUTION;
        if (!null.containsOption(option))
          paramBuilder.getMutableConfig().insertOption(option, analyzer); 
      } 
      return paramBuilder.getUseCaseConfig();
    } 
  }
  
  @NonNull
  @RestrictTo({RestrictTo.Scope.LIBRARY_GROUP})
  protected Size onSuggestedResolutionUpdated(@NonNull Size paramSize) {
    ImageAnalysisConfig imageAnalysisConfig = (ImageAnalysisConfig)getCurrentConfig();
    updateSessionConfig(createPipeline(getCameraId(), imageAnalysisConfig, paramSize).build());
    return paramSize;
  }
  
  public void setAnalyzer(@NonNull Executor paramExecutor, @NonNull Analyzer paramAnalyzer) {
    synchronized (this.mAnalysisLock) {
      this.mImageAnalysisAbstractAnalyzer.setAnalyzer(paramExecutor, (Analyzer)new ImageAnalysis$.ExternalSyntheticLambda2(paramAnalyzer));
      if (this.mSubscribedAnalyzer == null)
        notifyActive(); 
      this.mSubscribedAnalyzer = paramAnalyzer;
      return;
    } 
  }
  
  @RestrictTo({RestrictTo.Scope.LIBRARY_GROUP})
  public void setSensorToBufferTransformMatrix(@NonNull Matrix paramMatrix) {
    super.setSensorToBufferTransformMatrix(paramMatrix);
    this.mImageAnalysisAbstractAnalyzer.setSensorToBufferTransformMatrix(paramMatrix);
  }
  
  public void setTargetRotation(int paramInt) {
    if (setTargetRotationInternal(paramInt))
      tryUpdateRelativeRotation(); 
  }
  
  @RestrictTo({RestrictTo.Scope.LIBRARY_GROUP})
  public void setViewPortCropRect(@NonNull Rect paramRect) {
    super.setViewPortCropRect(paramRect);
    this.mImageAnalysisAbstractAnalyzer.setViewPortCropRect(paramRect);
  }
  
  @NonNull
  public String toString() {
    StringBuilder stringBuilder = new StringBuilder();
    stringBuilder.append("ImageAnalysis:");
    stringBuilder.append(getName());
    return stringBuilder.toString();
  }
  
  public static interface Analyzer {
    void analyze(@NonNull ImageProxy param1ImageProxy);
    
    @Nullable
    Size getDefaultTargetResolution();
    
    int getTargetCoordinateSystem();
    
    void updateTransform(@Nullable Matrix param1Matrix);
  }
  
  @Retention(RetentionPolicy.SOURCE)
  @RestrictTo({RestrictTo.Scope.LIBRARY_GROUP})
  public static @interface BackpressureStrategy {}
  
  public static final class Builder implements ImageOutputConfig.Builder<Builder>, ThreadConfig.Builder<Builder>, UseCaseConfig.Builder<ImageAnalysis, ImageAnalysisConfig, Builder> {
    private final MutableOptionsBundle mMutableConfig;
    
    public Builder() {
      this(MutableOptionsBundle.create());
    }
    
    private Builder(MutableOptionsBundle param1MutableOptionsBundle) {
      this.mMutableConfig = param1MutableOptionsBundle;
      Class clazz = (Class)param1MutableOptionsBundle.retrieveOption(TargetConfig.OPTION_TARGET_CLASS, null);
      if (clazz == null || clazz.equals(ImageAnalysis.class)) {
        setTargetClass(ImageAnalysis.class);
        return;
      } 
      StringBuilder stringBuilder = new StringBuilder();
      stringBuilder.append("Invalid target class configuration for ");
      stringBuilder.append(this);
      stringBuilder.append(": ");
      stringBuilder.append(clazz);
      throw new IllegalArgumentException(stringBuilder.toString());
    }
    
    @NonNull
    @RestrictTo({RestrictTo.Scope.LIBRARY_GROUP})
    static Builder fromConfig(@NonNull Config param1Config) {
      return new Builder(MutableOptionsBundle.from(param1Config));
    }
    
    @NonNull
    @RestrictTo({RestrictTo.Scope.LIBRARY_GROUP})
    public static Builder fromConfig(@NonNull ImageAnalysisConfig param1ImageAnalysisConfig) {
      return new Builder(MutableOptionsBundle.from((Config)param1ImageAnalysisConfig));
    }
    
    @NonNull
    public ImageAnalysis build() {
      if (getMutableConfig().retrieveOption(ImageOutputConfig.OPTION_TARGET_ASPECT_RATIO, null) == null || getMutableConfig().retrieveOption(ImageOutputConfig.OPTION_TARGET_RESOLUTION, null) == null)
        return new ImageAnalysis(getUseCaseConfig()); 
      throw new IllegalArgumentException("Cannot use both setTargetResolution and setTargetAspectRatio on the same config.");
    }
    
    @NonNull
    @RestrictTo({RestrictTo.Scope.LIBRARY_GROUP})
    public MutableConfig getMutableConfig() {
      return (MutableConfig)this.mMutableConfig;
    }
    
    @NonNull
    @RestrictTo({RestrictTo.Scope.LIBRARY_GROUP})
    public ImageAnalysisConfig getUseCaseConfig() {
      return new ImageAnalysisConfig(OptionsBundle.from((Config)this.mMutableConfig));
    }
    
    @NonNull
    public Builder setBackgroundExecutor(@NonNull Executor param1Executor) {
      getMutableConfig().insertOption(ThreadConfig.OPTION_BACKGROUND_EXECUTOR, param1Executor);
      return this;
    }
    
    @NonNull
    public Builder setBackpressureStrategy(int param1Int) {
      getMutableConfig().insertOption(ImageAnalysisConfig.OPTION_BACKPRESSURE_STRATEGY, Integer.valueOf(param1Int));
      return this;
    }
    
    @NonNull
    @RestrictTo({RestrictTo.Scope.LIBRARY})
    public Builder setCameraSelector(@NonNull CameraSelector param1CameraSelector) {
      getMutableConfig().insertOption(UseCaseConfig.OPTION_CAMERA_SELECTOR, param1CameraSelector);
      return this;
    }
    
    @NonNull
    @RestrictTo({RestrictTo.Scope.LIBRARY_GROUP})
    public Builder setCaptureOptionUnpacker(@NonNull CaptureConfig.OptionUnpacker param1OptionUnpacker) {
      getMutableConfig().insertOption(UseCaseConfig.OPTION_CAPTURE_CONFIG_UNPACKER, param1OptionUnpacker);
      return this;
    }
    
    @NonNull
    @RestrictTo({RestrictTo.Scope.LIBRARY_GROUP})
    public Builder setDefaultCaptureConfig(@NonNull CaptureConfig param1CaptureConfig) {
      getMutableConfig().insertOption(UseCaseConfig.OPTION_DEFAULT_CAPTURE_CONFIG, param1CaptureConfig);
      return this;
    }
    
    @NonNull
    @RestrictTo({RestrictTo.Scope.LIBRARY_GROUP})
    public Builder setDefaultResolution(@NonNull Size param1Size) {
      getMutableConfig().insertOption(ImageOutputConfig.OPTION_DEFAULT_RESOLUTION, param1Size);
      return this;
    }
    
    @NonNull
    @RestrictTo({RestrictTo.Scope.LIBRARY_GROUP})
    public Builder setDefaultSessionConfig(@NonNull SessionConfig param1SessionConfig) {
      getMutableConfig().insertOption(UseCaseConfig.OPTION_DEFAULT_SESSION_CONFIG, param1SessionConfig);
      return this;
    }
    
    @NonNull
    public Builder setImageQueueDepth(int param1Int) {
      getMutableConfig().insertOption(ImageAnalysisConfig.OPTION_IMAGE_QUEUE_DEPTH, Integer.valueOf(param1Int));
      return this;
    }
    
    @NonNull
    @RestrictTo({RestrictTo.Scope.LIBRARY_GROUP})
    public Builder setImageReaderProxyProvider(@NonNull ImageReaderProxyProvider param1ImageReaderProxyProvider) {
      getMutableConfig().insertOption(ImageAnalysisConfig.OPTION_IMAGE_READER_PROXY_PROVIDER, param1ImageReaderProxyProvider);
      return this;
    }
    
    @NonNull
    @RestrictTo({RestrictTo.Scope.LIBRARY_GROUP})
    public Builder setMaxResolution(@NonNull Size param1Size) {
      getMutableConfig().insertOption(ImageOutputConfig.OPTION_MAX_RESOLUTION, param1Size);
      return this;
    }
    
    @NonNull
    @RestrictTo({RestrictTo.Scope.LIBRARY_GROUP})
    public Builder setOnePixelShiftEnabled(boolean param1Boolean) {
      getMutableConfig().insertOption(ImageAnalysisConfig.OPTION_ONE_PIXEL_SHIFT_ENABLED, Boolean.valueOf(param1Boolean));
      return this;
    }
    
    @NonNull
    public Builder setOutputImageFormat(int param1Int) {
      getMutableConfig().insertOption(ImageAnalysisConfig.OPTION_OUTPUT_IMAGE_FORMAT, Integer.valueOf(param1Int));
      return this;
    }
    
    @NonNull
    @RequiresApi(23)
    public Builder setOutputImageRotationEnabled(boolean param1Boolean) {
      getMutableConfig().insertOption(ImageAnalysisConfig.OPTION_OUTPUT_IMAGE_ROTATION_ENABLED, Boolean.valueOf(param1Boolean));
      return this;
    }
    
    @NonNull
    @RestrictTo({RestrictTo.Scope.LIBRARY_GROUP})
    public Builder setSessionOptionUnpacker(@NonNull SessionConfig.OptionUnpacker param1OptionUnpacker) {
      getMutableConfig().insertOption(UseCaseConfig.OPTION_SESSION_CONFIG_UNPACKER, param1OptionUnpacker);
      return this;
    }
    
    @NonNull
    @RestrictTo({RestrictTo.Scope.LIBRARY_GROUP})
    public Builder setSupportedResolutions(@NonNull List<Pair<Integer, Size[]>> param1List) {
      getMutableConfig().insertOption(ImageOutputConfig.OPTION_SUPPORTED_RESOLUTIONS, param1List);
      return this;
    }
    
    @NonNull
    @RestrictTo({RestrictTo.Scope.LIBRARY_GROUP})
    public Builder setSurfaceOccupancyPriority(int param1Int) {
      getMutableConfig().insertOption(UseCaseConfig.OPTION_SURFACE_OCCUPANCY_PRIORITY, Integer.valueOf(param1Int));
      return this;
    }
    
    @NonNull
    public Builder setTargetAspectRatio(int param1Int) {
      getMutableConfig().insertOption(ImageOutputConfig.OPTION_TARGET_ASPECT_RATIO, Integer.valueOf(param1Int));
      return this;
    }
    
    @NonNull
    @RestrictTo({RestrictTo.Scope.LIBRARY_GROUP})
    public Builder setTargetClass(@NonNull Class<ImageAnalysis> param1Class) {
      getMutableConfig().insertOption(TargetConfig.OPTION_TARGET_CLASS, param1Class);
      if (getMutableConfig().retrieveOption(TargetConfig.OPTION_TARGET_NAME, null) == null) {
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append(param1Class.getCanonicalName());
        stringBuilder.append("-");
        stringBuilder.append(UUID.randomUUID());
        setTargetName(stringBuilder.toString());
      } 
      return this;
    }
    
    @NonNull
    public Builder setTargetName(@NonNull String param1String) {
      getMutableConfig().insertOption(TargetConfig.OPTION_TARGET_NAME, param1String);
      return this;
    }
    
    @NonNull
    public Builder setTargetResolution(@NonNull Size param1Size) {
      getMutableConfig().insertOption(ImageOutputConfig.OPTION_TARGET_RESOLUTION, param1Size);
      return this;
    }
    
    @NonNull
    public Builder setTargetRotation(int param1Int) {
      getMutableConfig().insertOption(ImageOutputConfig.OPTION_TARGET_ROTATION, Integer.valueOf(param1Int));
      return this;
    }
    
    @NonNull
    @RestrictTo({RestrictTo.Scope.LIBRARY_GROUP})
    public Builder setUseCaseEventCallback(@NonNull UseCase.EventCallback param1EventCallback) {
      getMutableConfig().insertOption(UseCaseEventConfig.OPTION_USE_CASE_EVENT_CALLBACK, param1EventCallback);
      return this;
    }
    
    @NonNull
    @RestrictTo({RestrictTo.Scope.LIBRARY_GROUP})
    public Builder setZslDisabled(boolean param1Boolean) {
      getMutableConfig().insertOption(UseCaseConfig.OPTION_ZSL_DISABLED, Boolean.valueOf(param1Boolean));
      return this;
    }
  }
  
  @RestrictTo({RestrictTo.Scope.LIBRARY_GROUP})
  public static final class Defaults implements ConfigProvider<ImageAnalysisConfig> {
    private static final int DEFAULT_ASPECT_RATIO = 0;
    
    private static final ImageAnalysisConfig DEFAULT_CONFIG;
    
    private static final int DEFAULT_SURFACE_OCCUPANCY_PRIORITY = 1;
    
    private static final Size DEFAULT_TARGET_RESOLUTION;
    
    static {
      Size size = new Size(640, 480);
      DEFAULT_TARGET_RESOLUTION = size;
      DEFAULT_CONFIG = (new ImageAnalysis.Builder()).setDefaultResolution(size).setSurfaceOccupancyPriority(1).setTargetAspectRatio(0).getUseCaseConfig();
    }
    
    @NonNull
    public ImageAnalysisConfig getConfig() {
      return DEFAULT_CONFIG;
    }
  }
  
  @Retention(RetentionPolicy.SOURCE)
  @RestrictTo({RestrictTo.Scope.LIBRARY_GROUP})
  public static @interface OutputImageFormat {}
}


/* Location:              C:\soft\dex2jar-2.0\MagicAI - AI Art & Anime Art-dex2jar.jar!\androidx\camera\core\ImageAnalysis.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */