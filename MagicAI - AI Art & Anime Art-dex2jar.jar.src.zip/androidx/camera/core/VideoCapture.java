package androidx.camera.core;

import android.content.ContentResolver;
import android.content.ContentValues;
import android.location.Location;
import android.media.AudioRecord;
import android.media.CamcorderProfile;
import android.media.MediaCodec;
import android.media.MediaFormat;
import android.media.MediaMuxer;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.HandlerThread;
import android.os.Looper;
import android.os.ParcelFileDescriptor;
import android.util.Pair;
import android.util.Size;
import android.view.Surface;
import androidx.annotation.DoNotInline;
import androidx.annotation.GuardedBy;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.annotation.RequiresApi;
import androidx.annotation.RequiresPermission;
import androidx.annotation.RestrictTo;
import androidx.annotation.UiThread;
import androidx.annotation.VisibleForTesting;
import androidx.camera.core.impl.CameraInternal;
import androidx.camera.core.impl.CaptureConfig;
import androidx.camera.core.impl.Config;
import androidx.camera.core.impl.ConfigProvider;
import androidx.camera.core.impl.DeferrableSurface;
import androidx.camera.core.impl.ImageOutputConfig;
import androidx.camera.core.impl.ImmediateSurface;
import androidx.camera.core.impl.MutableConfig;
import androidx.camera.core.impl.MutableOptionsBundle;
import androidx.camera.core.impl.OptionsBundle;
import androidx.camera.core.impl.SessionConfig;
import androidx.camera.core.impl.UseCaseConfig;
import androidx.camera.core.impl.UseCaseConfigFactory;
import androidx.camera.core.impl.VideoCaptureConfig;
import androidx.camera.core.impl.utils.executor.CameraXExecutors;
import androidx.camera.core.internal.TargetConfig;
import androidx.camera.core.internal.ThreadConfig;
import androidx.camera.core.internal.UseCaseEventConfig;
import androidx.camera.core.internal.utils.VideoUtil;
import androidx.concurrent.futures.CallbackToFutureAdapter;
import androidx.core.util.Preconditions;
import com.google.common.util.concurrent.ListenableFuture;
import j$.util.Objects;
import java.io.File;
import java.io.FileDescriptor;
import java.io.IOException;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.nio.ByteBuffer;
import java.util.List;
import java.util.UUID;
import java.util.concurrent.Executor;
import java.util.concurrent.RejectedExecutionException;
import java.util.concurrent.atomic.AtomicBoolean;
import java.util.concurrent.atomic.AtomicReference;

@Deprecated
@RequiresApi(21)
@RestrictTo({RestrictTo.Scope.LIBRARY_GROUP})
public final class VideoCapture extends UseCase {
  private static final String AUDIO_MIME_TYPE = "audio/mp4a-latm";
  
  private static final int[] CamcorderQuality;
  
  @RestrictTo({RestrictTo.Scope.LIBRARY_GROUP})
  public static final Defaults DEFAULT_CONFIG = new Defaults();
  
  private static final int DEQUE_TIMEOUT_USEC = 10000;
  
  public static final int ERROR_ENCODER = 1;
  
  public static final int ERROR_FILE_IO = 4;
  
  public static final int ERROR_INVALID_CAMERA = 5;
  
  public static final int ERROR_MUXER = 2;
  
  public static final int ERROR_RECORDING_IN_PROGRESS = 3;
  
  public static final int ERROR_RECORDING_TOO_SHORT = 6;
  
  public static final int ERROR_UNKNOWN = 0;
  
  private static final String TAG = "VideoCapture";
  
  private static final String VIDEO_MIME_TYPE = "video/avc";
  
  private int mAudioBitRate;
  
  private final MediaCodec.BufferInfo mAudioBufferInfo = new MediaCodec.BufferInfo();
  
  private volatile int mAudioBufferSize;
  
  private int mAudioChannelCount;
  
  @NonNull
  private MediaCodec mAudioEncoder;
  
  private Handler mAudioHandler;
  
  private HandlerThread mAudioHandlerThread;
  
  @Nullable
  private volatile AudioRecord mAudioRecorder;
  
  private int mAudioSampleRate;
  
  @GuardedBy("mMuxerLock")
  private int mAudioTrackIndex;
  
  Surface mCameraSurface;
  
  private DeferrableSurface mDeferrableSurface;
  
  private final AtomicBoolean mEndOfAudioStreamSignal = new AtomicBoolean(true);
  
  private final AtomicBoolean mEndOfAudioVideoSignal = new AtomicBoolean(true);
  
  private final AtomicBoolean mEndOfVideoStreamSignal = new AtomicBoolean(true);
  
  private final AtomicBoolean mIsAudioEnabled = new AtomicBoolean(true);
  
  @VisibleForTesting(otherwise = 2)
  public final AtomicBoolean mIsFirstAudioSampleWrite = new AtomicBoolean(false);
  
  @VisibleForTesting(otherwise = 2)
  public final AtomicBoolean mIsFirstVideoKeyFrameWrite = new AtomicBoolean(false);
  
  private volatile boolean mIsRecording = false;
  
  @GuardedBy("mMuxerLock")
  private MediaMuxer mMuxer;
  
  private final Object mMuxerLock = new Object();
  
  private final AtomicBoolean mMuxerStarted = new AtomicBoolean(false);
  
  private volatile ParcelFileDescriptor mParcelFileDescriptor;
  
  @Nullable
  private ListenableFuture<Void> mRecordingFuture = null;
  
  volatile Uri mSavedVideoUri;
  
  @NonNull
  private SessionConfig.Builder mSessionConfigBuilder = new SessionConfig.Builder();
  
  private final MediaCodec.BufferInfo mVideoBufferInfo = new MediaCodec.BufferInfo();
  
  @NonNull
  MediaCodec mVideoEncoder;
  
  @Nullable
  private Throwable mVideoEncoderErrorMessage;
  
  private VideoEncoderInitStatus mVideoEncoderInitStatus = VideoEncoderInitStatus.VIDEO_ENCODER_INIT_STATUS_UNINITIALIZED;
  
  private Handler mVideoHandler;
  
  private HandlerThread mVideoHandlerThread;
  
  @GuardedBy("mMuxerLock")
  private int mVideoTrackIndex;
  
  static {
    CamcorderQuality = new int[] { 8, 6, 5, 4 };
  }
  
  VideoCapture(@NonNull VideoCaptureConfig paramVideoCaptureConfig) {
    super((UseCaseConfig)paramVideoCaptureConfig);
  }
  
  @RequiresPermission("android.permission.RECORD_AUDIO")
  private AudioRecord autoConfigAudioRecordSource(VideoCaptureConfig paramVideoCaptureConfig) {
    byte b;
    if (this.mAudioChannelCount == 1) {
      b = 16;
    } else {
      b = 12;
    } 
    try {
      int j = AudioRecord.getMinBufferSize(this.mAudioSampleRate, b, 2);
      int i = j;
      if (j <= 0)
        i = paramVideoCaptureConfig.getAudioMinBufferSize(); 
      AudioRecord audioRecord = new AudioRecord(5, this.mAudioSampleRate, b, 2, i * 2);
      if (audioRecord.getState() == 1) {
        this.mAudioBufferSize = i;
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("source: 5 audioSampleRate: ");
        stringBuilder.append(this.mAudioSampleRate);
        stringBuilder.append(" channelConfig: ");
        stringBuilder.append(b);
        stringBuilder.append(" audioFormat: ");
        stringBuilder.append(2);
        stringBuilder.append(" bufferSize: ");
        stringBuilder.append(i);
        Logger.i("VideoCapture", stringBuilder.toString());
        return audioRecord;
      } 
    } catch (Exception exception) {
      Logger.e("VideoCapture", "Exception, keep trying.", exception);
    } 
    return null;
  }
  
  private MediaFormat createAudioMediaFormat() {
    MediaFormat mediaFormat = MediaFormat.createAudioFormat("audio/mp4a-latm", this.mAudioSampleRate, this.mAudioChannelCount);
    mediaFormat.setInteger("aac-profile", 2);
    mediaFormat.setInteger("bitrate", this.mAudioBitRate);
    return mediaFormat;
  }
  
  private static MediaFormat createVideoMediaFormat(VideoCaptureConfig paramVideoCaptureConfig, Size paramSize) {
    MediaFormat mediaFormat = MediaFormat.createVideoFormat("video/avc", paramSize.getWidth(), paramSize.getHeight());
    mediaFormat.setInteger("color-format", 2130708361);
    mediaFormat.setInteger("bitrate", paramVideoCaptureConfig.getBitRate());
    mediaFormat.setInteger("frame-rate", paramVideoCaptureConfig.getVideoFrameRate());
    mediaFormat.setInteger("i-frame-interval", paramVideoCaptureConfig.getIFrameInterval());
    return mediaFormat;
  }
  
  private ByteBuffer getInputBuffer(MediaCodec paramMediaCodec, int paramInt) {
    return paramMediaCodec.getInputBuffer(paramInt);
  }
  
  private ByteBuffer getOutputBuffer(MediaCodec paramMediaCodec, int paramInt) {
    return paramMediaCodec.getOutputBuffer(paramInt);
  }
  
  @NonNull
  private MediaMuxer initMediaMuxer(@NonNull OutputFileOptions paramOutputFileOptions) throws IOException {
    if (paramOutputFileOptions.isSavingToFile()) {
      File file = paramOutputFileOptions.getFile();
      this.mSavedVideoUri = Uri.fromFile(paramOutputFileOptions.getFile());
      return new MediaMuxer(file.getAbsolutePath(), 0);
    } 
    if (paramOutputFileOptions.isSavingToFileDescriptor()) {
      if (Build.VERSION.SDK_INT >= 26)
        return Api26Impl.createMediaMuxer(paramOutputFileOptions.getFileDescriptor(), 0); 
      throw new IllegalArgumentException("Using a FileDescriptor to record a video is only supported for Android 8.0 or above.");
    } 
    if (paramOutputFileOptions.isSavingToMediaStore()) {
      ContentValues contentValues;
      if (paramOutputFileOptions.getContentValues() != null) {
        contentValues = new ContentValues(paramOutputFileOptions.getContentValues());
      } else {
        contentValues = new ContentValues();
      } 
      this.mSavedVideoUri = paramOutputFileOptions.getContentResolver().insert(paramOutputFileOptions.getSaveCollection(), contentValues);
      if (this.mSavedVideoUri != null)
        try {
          String str;
          if (Build.VERSION.SDK_INT < 26) {
            str = VideoUtil.getAbsolutePathFromUri(paramOutputFileOptions.getContentResolver(), this.mSavedVideoUri);
            StringBuilder stringBuilder = new StringBuilder();
            stringBuilder.append("Saved Location Path: ");
            stringBuilder.append(str);
            Logger.i("VideoCapture", stringBuilder.toString());
            return new MediaMuxer(str, 0);
          } 
          this.mParcelFileDescriptor = str.getContentResolver().openFileDescriptor(this.mSavedVideoUri, "rw");
          return Api26Impl.createMediaMuxer(this.mParcelFileDescriptor.getFileDescriptor(), 0);
        } catch (IOException iOException) {
          this.mSavedVideoUri = null;
          throw iOException;
        }  
      throw new IOException("Invalid Uri!");
    } 
    throw new IllegalArgumentException("The OutputFileOptions should assign before recording");
  }
  
  private void releaseAudioInputResource() {
    this.mAudioHandlerThread.quitSafely();
    MediaCodec mediaCodec = this.mAudioEncoder;
    if (mediaCodec != null) {
      mediaCodec.release();
      this.mAudioEncoder = null;
    } 
    if (this.mAudioRecorder != null) {
      this.mAudioRecorder.release();
      this.mAudioRecorder = null;
    } 
  }
  
  @UiThread
  private void releaseCameraSurface(boolean paramBoolean) {
    DeferrableSurface deferrableSurface = this.mDeferrableSurface;
    if (deferrableSurface == null)
      return; 
    MediaCodec mediaCodec = this.mVideoEncoder;
    deferrableSurface.close();
    this.mDeferrableSurface.getTerminationFuture().addListener((Runnable)new VideoCapture$.ExternalSyntheticLambda6(paramBoolean, mediaCodec), CameraXExecutors.mainThreadExecutor());
    if (paramBoolean)
      this.mVideoEncoder = null; 
    this.mCameraSurface = null;
    this.mDeferrableSurface = null;
  }
  
  private void releaseResources() {
    this.mVideoHandlerThread.quitSafely();
    releaseAudioInputResource();
    if (this.mCameraSurface != null)
      releaseCameraSurface(true); 
  }
  
  private boolean removeRecordingResultIfNoVideoKeyFrameArrived(@NonNull OutputFileOptions paramOutputFileOptions) {
    File file;
    boolean bool;
    StringBuilder stringBuilder = new StringBuilder();
    stringBuilder.append("check Recording Result First Video Key Frame Write: ");
    stringBuilder.append(this.mIsFirstVideoKeyFrameWrite.get());
    Logger.i("VideoCapture", stringBuilder.toString());
    if (!this.mIsFirstVideoKeyFrameWrite.get()) {
      Logger.i("VideoCapture", "The recording result has no key frame.");
      bool = false;
    } else {
      bool = true;
    } 
    if (paramOutputFileOptions.isSavingToFile()) {
      file = paramOutputFileOptions.getFile();
      if (!bool) {
        Logger.i("VideoCapture", "Delete file.");
        file.delete();
        return bool;
      } 
    } else if (file.isSavingToMediaStore() && !bool) {
      Logger.i("VideoCapture", "Delete file.");
      if (this.mSavedVideoUri != null)
        file.getContentResolver().delete(this.mSavedVideoUri, null, null); 
    } 
    return bool;
  }
  
  private void setAudioParametersByCamcorderProfile(Size paramSize, String paramString) {
    byte b1;
    byte b2 = 0;
    try {
      int[] arrayOfInt = CamcorderQuality;
      int j = arrayOfInt.length;
      int i = 0;
      while (true) {
        b1 = b2;
        if (i < j) {
          b1 = arrayOfInt[i];
          if (CamcorderProfile.hasProfile(Integer.parseInt(paramString), b1)) {
            CamcorderProfile camcorderProfile = CamcorderProfile.get(Integer.parseInt(paramString), b1);
            if (paramSize.getWidth() == camcorderProfile.videoFrameWidth && paramSize.getHeight() == camcorderProfile.videoFrameHeight) {
              this.mAudioChannelCount = camcorderProfile.audioChannels;
              this.mAudioSampleRate = camcorderProfile.audioSampleRate;
              this.mAudioBitRate = camcorderProfile.audioBitRate;
              b1 = 1;
              break;
            } 
          } 
          i++;
          continue;
        } 
        break;
      } 
    } catch (NumberFormatException numberFormatException) {
      Logger.i("VideoCapture", "The camera Id is not an integer because the camera may be a removable device. Use the default values for the audio related settings.");
      b1 = b2;
    } 
    if (b1 == 0) {
      VideoCaptureConfig videoCaptureConfig = (VideoCaptureConfig)getCurrentConfig();
      this.mAudioChannelCount = videoCaptureConfig.getAudioChannelCount();
      this.mAudioSampleRate = videoCaptureConfig.getAudioSampleRate();
      this.mAudioBitRate = videoCaptureConfig.getAudioBitRate();
    } 
  }
  
  private boolean writeAudioEncodedBuffer(int paramInt) {
    ByteBuffer byteBuffer = getOutputBuffer(this.mAudioEncoder, paramInt);
    byteBuffer.position(this.mAudioBufferInfo.offset);
    if (this.mMuxerStarted.get())
      try {
        MediaCodec.BufferInfo bufferInfo = this.mAudioBufferInfo;
        if (bufferInfo.size > 0 && bufferInfo.presentationTimeUs > 0L) {
          synchronized (this.mMuxerLock) {
            if (!this.mIsFirstAudioSampleWrite.get()) {
              Logger.i("VideoCapture", "First audio sample written.");
              this.mIsFirstAudioSampleWrite.set(true);
            } 
            this.mMuxer.writeSampleData(this.mAudioTrackIndex, byteBuffer, this.mAudioBufferInfo);
          } 
        } else {
          StringBuilder stringBuilder = new StringBuilder();
          stringBuilder.append("mAudioBufferInfo size: ");
          stringBuilder.append(this.mAudioBufferInfo.size);
          stringBuilder.append(" presentationTimeUs: ");
          stringBuilder.append(this.mAudioBufferInfo.presentationTimeUs);
          Logger.i("VideoCapture", stringBuilder.toString());
        } 
      } catch (Exception exception) {
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("audio error:size=");
        stringBuilder.append(this.mAudioBufferInfo.size);
        stringBuilder.append("/offset=");
        stringBuilder.append(this.mAudioBufferInfo.offset);
        stringBuilder.append("/timeUs=");
        stringBuilder.append(this.mAudioBufferInfo.presentationTimeUs);
        Logger.e("VideoCapture", stringBuilder.toString());
        exception.printStackTrace();
      }  
    this.mAudioEncoder.releaseOutputBuffer(paramInt, false);
    return ((this.mAudioBufferInfo.flags & 0x4) != 0);
  }
  
  private boolean writeVideoEncodedBuffer(int paramInt) {
    boolean bool = false;
    if (paramInt < 0) {
      StringBuilder stringBuilder = new StringBuilder();
      stringBuilder.append("Output buffer should not have negative index: ");
      stringBuilder.append(paramInt);
      Logger.e("VideoCapture", stringBuilder.toString());
      return false;
    } 
    ByteBuffer byteBuffer = this.mVideoEncoder.getOutputBuffer(paramInt);
    if (byteBuffer == null) {
      Logger.d("VideoCapture", "OutputBuffer was null.");
      return false;
    } 
    if (this.mMuxerStarted.get()) {
      MediaCodec.BufferInfo bufferInfo = this.mVideoBufferInfo;
      if (bufferInfo.size > 0) {
        byteBuffer.position(bufferInfo.offset);
        bufferInfo = this.mVideoBufferInfo;
        byteBuffer.limit(bufferInfo.offset + bufferInfo.size);
        this.mVideoBufferInfo.presentationTimeUs = System.nanoTime() / 1000L;
        synchronized (this.mMuxerLock) {
          if (!this.mIsFirstVideoKeyFrameWrite.get()) {
            boolean bool1;
            if ((this.mVideoBufferInfo.flags & 0x1) != 0) {
              bool1 = true;
            } else {
              bool1 = false;
            } 
            if (bool1) {
              Logger.i("VideoCapture", "First video key frame written.");
              this.mIsFirstVideoKeyFrameWrite.set(true);
            } else {
              Bundle bundle = new Bundle();
              bundle.putInt("request-sync", 0);
              this.mVideoEncoder.setParameters(bundle);
            } 
          } 
          this.mMuxer.writeSampleData(this.mVideoTrackIndex, byteBuffer, this.mVideoBufferInfo);
        } 
      } else {
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("mVideoBufferInfo.size <= 0, index ");
        stringBuilder.append(paramInt);
        Logger.i("VideoCapture", stringBuilder.toString());
      } 
    } 
    this.mVideoEncoder.releaseOutputBuffer(paramInt, false);
    if ((this.mVideoBufferInfo.flags & 0x4) != 0)
      bool = true; 
    return bool;
  }
  
  boolean audioEncode(OnVideoSavedCallback paramOnVideoSavedCallback) {
    long l = 0L;
    boolean bool = false;
    label60: while (true) {
      if (!bool && this.mIsRecording) {
        if (this.mEndOfAudioStreamSignal.get()) {
          this.mEndOfAudioStreamSignal.set(false);
          this.mIsRecording = false;
        } 
        if (this.mAudioEncoder != null && this.mAudioRecorder != null) {
          long l1;
          boolean bool1;
          try {
            int i = this.mAudioEncoder.dequeueInputBuffer(-1L);
            bool1 = bool;
            l1 = l;
            if (i >= 0) {
              ByteBuffer byteBuffer = getInputBuffer(this.mAudioEncoder, i);
              byteBuffer.clear();
              int j = this.mAudioRecorder.read(byteBuffer, this.mAudioBufferSize);
              bool1 = bool;
              l1 = l;
              if (j > 0) {
                byte b;
                MediaCodec mediaCodec = this.mAudioEncoder;
                long l2 = System.nanoTime() / 1000L;
                if (this.mIsRecording) {
                  b = 0;
                } else {
                  b = 4;
                } 
                mediaCodec.queueInputBuffer(i, 0, j, l2, b);
                bool1 = bool;
                l1 = l;
              } 
            } 
          } catch (android.media.MediaCodec.CodecException codecException) {
            StringBuilder stringBuilder = new StringBuilder();
            stringBuilder.append("audio dequeueInputBuffer CodecException ");
            stringBuilder.append(codecException.getMessage());
            Logger.i("VideoCapture", stringBuilder.toString());
            l1 = l;
            bool1 = bool;
          } catch (IllegalStateException illegalStateException) {
            StringBuilder stringBuilder = new StringBuilder();
            stringBuilder.append("audio dequeueInputBuffer IllegalStateException ");
            stringBuilder.append(illegalStateException.getMessage());
            Logger.i("VideoCapture", stringBuilder.toString());
            bool1 = bool;
            l1 = l;
          } 
          while (true) {
            long l2;
            boolean bool2;
            int i = this.mAudioEncoder.dequeueOutputBuffer(this.mAudioBufferInfo, 0L);
            if (i != -2) {
              bool2 = bool1;
              l2 = l1;
              if (i != -1)
                if (this.mAudioBufferInfo.presentationTimeUs > l1) {
                  bool2 = writeAudioEncodedBuffer(i);
                  l2 = this.mAudioBufferInfo.presentationTimeUs;
                } else {
                  StringBuilder stringBuilder = new StringBuilder();
                  stringBuilder.append("Drops frame, current frame's timestamp ");
                  stringBuilder.append(this.mAudioBufferInfo.presentationTimeUs);
                  stringBuilder.append(" is earlier that last frame ");
                  stringBuilder.append(l1);
                  Logger.w("VideoCapture", stringBuilder.toString());
                  this.mAudioEncoder.releaseOutputBuffer(i, false);
                  bool2 = bool1;
                  l2 = l1;
                }  
            } else {
              synchronized (this.mMuxerLock) {
                int j = this.mMuxer.addTrack(this.mAudioEncoder.getOutputFormat());
                this.mAudioTrackIndex = j;
                if (j >= 0 && this.mVideoTrackIndex >= 0) {
                  Logger.i("VideoCapture", "MediaMuxer start on audio encoder thread.");
                  this.mMuxer.start();
                  this.mMuxerStarted.set(true);
                } 
                bool2 = bool1;
                l2 = l1;
              } 
            } 
            bool = bool2;
            l = l2;
            if (i >= 0) {
              bool1 = bool2;
              l1 = l2;
              if (bool2) {
                bool = bool2;
                l = l2;
              } 
              continue;
            } 
            continue label60;
          } 
          break;
        } 
        continue;
      } 
      try {
        Logger.i("VideoCapture", "audioRecorder stop");
        this.mAudioRecorder.stop();
      } catch (IllegalStateException illegalStateException) {
        paramOnVideoSavedCallback.onError(1, "Audio recorder stop failed!", illegalStateException);
      } 
      try {
        this.mAudioEncoder.stop();
      } catch (IllegalStateException illegalStateException) {
        paramOnVideoSavedCallback.onError(1, "Audio encoder stop failed!", illegalStateException);
      } 
      Logger.i("VideoCapture", "Audio encode thread end");
      this.mEndOfVideoStreamSignal.set(true);
      return false;
    } 
  }
  
  @Nullable
  @RestrictTo({RestrictTo.Scope.LIBRARY_GROUP})
  public UseCaseConfig<?> getDefaultConfig(boolean paramBoolean, @NonNull UseCaseConfigFactory paramUseCaseConfigFactory) {
    Config config2 = paramUseCaseConfigFactory.getConfig(UseCaseConfigFactory.CaptureType.VIDEO_CAPTURE, 1);
    Config config1 = config2;
    if (paramBoolean)
      config1 = Config.-CC.mergeConfigs(config2, (Config)DEFAULT_CONFIG.getConfig()); 
    return (config1 == null) ? null : getUseCaseConfigBuilder(config1).getUseCaseConfig();
  }
  
  @NonNull
  @RestrictTo({RestrictTo.Scope.LIBRARY_GROUP})
  public UseCaseConfig.Builder<?, ?, ?> getUseCaseConfigBuilder(@NonNull Config paramConfig) {
    return Builder.fromConfig(paramConfig);
  }
  
  @RestrictTo({RestrictTo.Scope.LIBRARY_GROUP})
  public void onAttached() {
    this.mVideoHandlerThread = new HandlerThread("CameraX-video encoding thread");
    this.mAudioHandlerThread = new HandlerThread("CameraX-audio encoding thread");
    this.mVideoHandlerThread.start();
    this.mVideoHandler = new Handler(this.mVideoHandlerThread.getLooper());
    this.mAudioHandlerThread.start();
    this.mAudioHandler = new Handler(this.mAudioHandlerThread.getLooper());
  }
  
  @RestrictTo({RestrictTo.Scope.LIBRARY_GROUP})
  public void onDetached() {
    stopRecording();
    ListenableFuture<Void> listenableFuture = this.mRecordingFuture;
    if (listenableFuture != null) {
      listenableFuture.addListener((Runnable)new VideoCapture$.ExternalSyntheticLambda7(this), CameraXExecutors.mainThreadExecutor());
      return;
    } 
    releaseResources();
  }
  
  @RestrictTo({RestrictTo.Scope.LIBRARY_GROUP})
  @UiThread
  public void onStateDetached() {
    stopRecording();
  }
  
  @NonNull
  @RequiresPermission("android.permission.RECORD_AUDIO")
  @RestrictTo({RestrictTo.Scope.LIBRARY_GROUP})
  protected Size onSuggestedResolutionUpdated(@NonNull Size paramSize) {
    if (this.mCameraSurface != null) {
      this.mVideoEncoder.stop();
      this.mVideoEncoder.release();
      this.mAudioEncoder.stop();
      this.mAudioEncoder.release();
      releaseCameraSurface(false);
    } 
    try {
      this.mVideoEncoder = MediaCodec.createEncoderByType("video/avc");
      this.mAudioEncoder = MediaCodec.createEncoderByType("audio/mp4a-latm");
      setupEncoder(getCameraId(), paramSize);
      notifyActive();
      return paramSize;
    } catch (IOException iOException) {
      StringBuilder stringBuilder = new StringBuilder();
      stringBuilder.append("Unable to create MediaCodec due to: ");
      stringBuilder.append(iOException.getCause());
      throw new IllegalStateException(stringBuilder.toString());
    } 
  }
  
  public void setTargetRotation(int paramInt) {
    setTargetRotationInternal(paramInt);
  }
  
  @RequiresPermission("android.permission.RECORD_AUDIO")
  @UiThread
  void setupEncoder(@NonNull final String cameraId, @NonNull final Size resolution) {
    VideoCaptureConfig videoCaptureConfig = (VideoCaptureConfig)getCurrentConfig();
    this.mVideoEncoder.reset();
    this.mVideoEncoderInitStatus = VideoEncoderInitStatus.VIDEO_ENCODER_INIT_STATUS_UNINITIALIZED;
    try {
      this.mVideoEncoder.configure(createVideoMediaFormat(videoCaptureConfig, resolution), null, null, 1);
      if (this.mCameraSurface != null)
        releaseCameraSurface(false); 
      Surface surface = this.mVideoEncoder.createInputSurface();
      this.mCameraSurface = surface;
      this.mSessionConfigBuilder = SessionConfig.Builder.createFrom((UseCaseConfig)videoCaptureConfig);
      DeferrableSurface deferrableSurface = this.mDeferrableSurface;
      if (deferrableSurface != null)
        deferrableSurface.close(); 
      ImmediateSurface immediateSurface = new ImmediateSurface(this.mCameraSurface, resolution, getImageFormat());
      this.mDeferrableSurface = (DeferrableSurface)immediateSurface;
      ListenableFuture listenableFuture = immediateSurface.getTerminationFuture();
      Objects.requireNonNull(surface);
      listenableFuture.addListener((Runnable)new VideoCapture$.ExternalSyntheticLambda8(surface), CameraXExecutors.mainThreadExecutor());
      this.mSessionConfigBuilder.addNonRepeatingSurface(this.mDeferrableSurface);
      this.mSessionConfigBuilder.addErrorListener(new SessionConfig.ErrorListener() {
            @RequiresPermission("android.permission.RECORD_AUDIO")
            public void onError(@NonNull SessionConfig param1SessionConfig, @NonNull SessionConfig.SessionError param1SessionError) {
              if (VideoCapture.this.isCurrentCamera(cameraId)) {
                VideoCapture.this.setupEncoder(cameraId, resolution);
                VideoCapture.this.notifyReset();
              } 
            }
          });
      updateSessionConfig(this.mSessionConfigBuilder.build());
      this.mIsAudioEnabled.set(true);
      setAudioParametersByCamcorderProfile(resolution, cameraId);
      this.mAudioEncoder.reset();
      this.mAudioEncoder.configure(createAudioMediaFormat(), null, null, 1);
      if (this.mAudioRecorder != null)
        this.mAudioRecorder.release(); 
      this.mAudioRecorder = autoConfigAudioRecordSource(videoCaptureConfig);
      if (this.mAudioRecorder == null) {
        Logger.e("VideoCapture", "AudioRecord object cannot initialized correctly!");
        this.mIsAudioEnabled.set(false);
      } 
      synchronized (this.mMuxerLock) {
        this.mVideoTrackIndex = -1;
        this.mAudioTrackIndex = -1;
        this.mIsRecording = false;
        return;
      } 
    } catch (android.media.MediaCodec.CodecException codecException) {
      if (Build.VERSION.SDK_INT >= 23) {
        int i = Api23Impl.getCodecExceptionErrorCode(codecException);
        String str = codecException.getDiagnosticInfo();
        if (i == 1100) {
          StringBuilder stringBuilder = new StringBuilder();
          stringBuilder.append("CodecException: code: ");
          stringBuilder.append(i);
          stringBuilder.append(" diagnostic: ");
          stringBuilder.append(str);
          Logger.i("VideoCapture", stringBuilder.toString());
          this.mVideoEncoderInitStatus = VideoEncoderInitStatus.VIDEO_ENCODER_INIT_STATUS_INSUFFICIENT_RESOURCE;
        } else if (i == 1101) {
          StringBuilder stringBuilder = new StringBuilder();
          stringBuilder.append("CodecException: code: ");
          stringBuilder.append(i);
          stringBuilder.append(" diagnostic: ");
          stringBuilder.append(str);
          Logger.i("VideoCapture", stringBuilder.toString());
          this.mVideoEncoderInitStatus = VideoEncoderInitStatus.VIDEO_ENCODER_INIT_STATUS_RESOURCE_RECLAIMED;
        } 
      } else {
        this.mVideoEncoderInitStatus = VideoEncoderInitStatus.VIDEO_ENCODER_INIT_STATUS_INITIALIZED_FAILED;
      } 
      this.mVideoEncoderErrorMessage = (Throwable)codecException;
      return;
    } catch (IllegalArgumentException illegalArgumentException) {
      this.mVideoEncoderInitStatus = VideoEncoderInitStatus.VIDEO_ENCODER_INIT_STATUS_INITIALIZED_FAILED;
      this.mVideoEncoderErrorMessage = illegalArgumentException;
      return;
    } catch (IllegalStateException illegalStateException) {
      this.mVideoEncoderInitStatus = VideoEncoderInitStatus.VIDEO_ENCODER_INIT_STATUS_INITIALIZED_FAILED;
      this.mVideoEncoderErrorMessage = illegalStateException;
      return;
    } 
  }
  
  @RequiresPermission("android.permission.RECORD_AUDIO")
  public void startRecording(@NonNull OutputFileOptions paramOutputFileOptions, @NonNull Executor paramExecutor, @NonNull OnVideoSavedCallback paramOnVideoSavedCallback) {
    StringBuilder stringBuilder;
    if (Looper.getMainLooper() != Looper.myLooper()) {
      CameraXExecutors.mainThreadExecutor().execute((Runnable)new VideoCapture$.ExternalSyntheticLambda0(this, paramOutputFileOptions, paramExecutor, paramOnVideoSavedCallback));
      return;
    } 
    Logger.i("VideoCapture", "startRecording");
    this.mIsFirstVideoKeyFrameWrite.set(false);
    this.mIsFirstAudioSampleWrite.set(false);
    VideoSavedListenerWrapper videoSavedListenerWrapper = new VideoSavedListenerWrapper(paramExecutor, paramOnVideoSavedCallback);
    CameraInternal cameraInternal = getCamera();
    if (cameraInternal == null) {
      stringBuilder = new StringBuilder();
      stringBuilder.append("Not bound to a Camera [");
      stringBuilder.append(this);
      stringBuilder.append("]");
      videoSavedListenerWrapper.onError(5, stringBuilder.toString(), null);
      return;
    } 
    VideoEncoderInitStatus videoEncoderInitStatus = this.mVideoEncoderInitStatus;
    if (videoEncoderInitStatus == VideoEncoderInitStatus.VIDEO_ENCODER_INIT_STATUS_INSUFFICIENT_RESOURCE || videoEncoderInitStatus == VideoEncoderInitStatus.VIDEO_ENCODER_INIT_STATUS_INITIALIZED_FAILED || videoEncoderInitStatus == VideoEncoderInitStatus.VIDEO_ENCODER_INIT_STATUS_RESOURCE_RECLAIMED) {
      videoSavedListenerWrapper.onError(1, "Video encoder initialization failed before start recording ", this.mVideoEncoderErrorMessage);
      return;
    } 
    if (!this.mEndOfAudioVideoSignal.get()) {
      videoSavedListenerWrapper.onError(3, "It is still in video recording!", null);
      return;
    } 
    if (this.mIsAudioEnabled.get()) {
      try {
        if (this.mAudioRecorder.getState() == 1)
          this.mAudioRecorder.startRecording(); 
      } catch (IllegalStateException illegalStateException) {
        StringBuilder stringBuilder1 = new StringBuilder();
        stringBuilder1.append("AudioRecorder cannot start recording, disable audio.");
        stringBuilder1.append(illegalStateException.getMessage());
        Logger.i("VideoCapture", stringBuilder1.toString());
        this.mIsAudioEnabled.set(false);
        releaseAudioInputResource();
      } 
      if (this.mAudioRecorder.getRecordingState() != 3) {
        StringBuilder stringBuilder1 = new StringBuilder();
        stringBuilder1.append("AudioRecorder startRecording failed - incorrect state: ");
        stringBuilder1.append(this.mAudioRecorder.getRecordingState());
        Logger.i("VideoCapture", stringBuilder1.toString());
        this.mIsAudioEnabled.set(false);
        releaseAudioInputResource();
      } 
    } 
    AtomicReference<CallbackToFutureAdapter.Completer> atomicReference = new AtomicReference();
    this.mRecordingFuture = CallbackToFutureAdapter.getFuture((CallbackToFutureAdapter.Resolver)new VideoCapture$.ExternalSyntheticLambda1(atomicReference));
    CallbackToFutureAdapter.Completer completer = (CallbackToFutureAdapter.Completer)Preconditions.checkNotNull(atomicReference.get());
    this.mRecordingFuture.addListener((Runnable)new VideoCapture$.ExternalSyntheticLambda2(this), CameraXExecutors.mainThreadExecutor());
    try {
      Logger.i("VideoCapture", "videoEncoder start");
      this.mVideoEncoder.start();
      if (this.mIsAudioEnabled.get()) {
        Logger.i("VideoCapture", "audioEncoder start");
        this.mAudioEncoder.start();
      } 
      try {
        synchronized (this.mMuxerLock) {
          MediaMuxer mediaMuxer = initMediaMuxer((OutputFileOptions)stringBuilder);
          this.mMuxer = mediaMuxer;
          Preconditions.checkNotNull(mediaMuxer);
          this.mMuxer.setOrientationHint(getRelativeRotation(cameraInternal));
          Metadata metadata = stringBuilder.getMetadata();
          if (metadata != null) {
            Location location = metadata.location;
            if (location != null)
              this.mMuxer.setLocation((float)location.getLatitude(), (float)metadata.location.getLongitude()); 
          } 
          this.mEndOfVideoStreamSignal.set(false);
          this.mEndOfAudioStreamSignal.set(false);
          this.mEndOfAudioVideoSignal.set(false);
          this.mIsRecording = true;
          this.mSessionConfigBuilder.clearSurfaces();
          this.mSessionConfigBuilder.addSurface(this.mDeferrableSurface);
          updateSessionConfig(this.mSessionConfigBuilder.build());
          notifyUpdated();
          if (this.mIsAudioEnabled.get())
            this.mAudioHandler.post((Runnable)new VideoCapture$.ExternalSyntheticLambda3(this, videoSavedListenerWrapper)); 
          String str = getCameraId();
          null = getAttachedSurfaceResolution();
          this.mVideoHandler.post((Runnable)new VideoCapture$.ExternalSyntheticLambda4(this, videoSavedListenerWrapper, str, (Size)null, (OutputFileOptions)stringBuilder, completer));
          return;
        } 
      } catch (IOException iOException) {
        completer.set(null);
        videoSavedListenerWrapper.onError(2, "MediaMuxer creation failed!", iOException);
        return;
      } 
    } catch (IllegalStateException illegalStateException) {
      completer.set(null);
      videoSavedListenerWrapper.onError(1, "Audio/Video encoder start fail", illegalStateException);
      return;
    } 
  }
  
  public void stopRecording() {
    if (Looper.getMainLooper() != Looper.myLooper()) {
      CameraXExecutors.mainThreadExecutor().execute((Runnable)new VideoCapture$.ExternalSyntheticLambda5(this));
      return;
    } 
    Logger.i("VideoCapture", "stopRecording");
    this.mSessionConfigBuilder.clearSurfaces();
    this.mSessionConfigBuilder.addNonRepeatingSurface(this.mDeferrableSurface);
    updateSessionConfig(this.mSessionConfigBuilder.build());
    notifyUpdated();
    if (this.mIsRecording) {
      if (this.mIsAudioEnabled.get()) {
        this.mEndOfAudioStreamSignal.set(true);
        return;
      } 
      this.mEndOfVideoStreamSignal.set(true);
    } 
  }
  
  boolean videoEncode(@NonNull OnVideoSavedCallback paramOnVideoSavedCallback, @NonNull String paramString, @NonNull Size paramSize, @NonNull OutputFileOptions paramOutputFileOptions) {
    // Byte code:
    //   0: iconst_0
    //   1: istore #7
    //   3: iconst_0
    //   4: istore #6
    //   6: iload #7
    //   8: ifne -> 230
    //   11: iload #6
    //   13: ifne -> 230
    //   16: aload_0
    //   17: getfield mEndOfVideoStreamSignal : Ljava/util/concurrent/atomic/AtomicBoolean;
    //   20: invokevirtual get : ()Z
    //   23: ifeq -> 41
    //   26: aload_0
    //   27: getfield mVideoEncoder : Landroid/media/MediaCodec;
    //   30: invokevirtual signalEndOfInputStream : ()V
    //   33: aload_0
    //   34: getfield mEndOfVideoStreamSignal : Ljava/util/concurrent/atomic/AtomicBoolean;
    //   37: iconst_0
    //   38: invokevirtual set : (Z)V
    //   41: aload_0
    //   42: getfield mVideoEncoder : Landroid/media/MediaCodec;
    //   45: aload_0
    //   46: getfield mVideoBufferInfo : Landroid/media/MediaCodec$BufferInfo;
    //   49: ldc2_w 10000
    //   52: invokevirtual dequeueOutputBuffer : (Landroid/media/MediaCodec$BufferInfo;J)I
    //   55: istore #5
    //   57: iload #5
    //   59: bipush #-2
    //   61: if_icmpeq -> 81
    //   64: iload #5
    //   66: iconst_m1
    //   67: if_icmpeq -> 6
    //   70: aload_0
    //   71: iload #5
    //   73: invokespecial writeVideoEncodedBuffer : (I)Z
    //   76: istore #7
    //   78: goto -> 6
    //   81: aload_0
    //   82: getfield mMuxerStarted : Ljava/util/concurrent/atomic/AtomicBoolean;
    //   85: invokevirtual get : ()Z
    //   88: ifeq -> 105
    //   91: aload_1
    //   92: iconst_1
    //   93: ldc_w 'Unexpected change in video encoding format.'
    //   96: aconst_null
    //   97: invokeinterface onError : (ILjava/lang/String;Ljava/lang/Throwable;)V
    //   102: iconst_1
    //   103: istore #6
    //   105: aload_0
    //   106: getfield mMuxerLock : Ljava/lang/Object;
    //   109: astore_2
    //   110: aload_2
    //   111: monitorenter
    //   112: aload_0
    //   113: aload_0
    //   114: getfield mMuxer : Landroid/media/MediaMuxer;
    //   117: aload_0
    //   118: getfield mVideoEncoder : Landroid/media/MediaCodec;
    //   121: invokevirtual getOutputFormat : ()Landroid/media/MediaFormat;
    //   124: invokevirtual addTrack : (Landroid/media/MediaFormat;)I
    //   127: putfield mVideoTrackIndex : I
    //   130: aload_0
    //   131: getfield mIsAudioEnabled : Ljava/util/concurrent/atomic/AtomicBoolean;
    //   134: invokevirtual get : ()Z
    //   137: ifeq -> 154
    //   140: aload_0
    //   141: getfield mAudioTrackIndex : I
    //   144: iflt -> 154
    //   147: aload_0
    //   148: getfield mVideoTrackIndex : I
    //   151: ifge -> 171
    //   154: aload_0
    //   155: getfield mIsAudioEnabled : Ljava/util/concurrent/atomic/AtomicBoolean;
    //   158: invokevirtual get : ()Z
    //   161: ifne -> 220
    //   164: aload_0
    //   165: getfield mVideoTrackIndex : I
    //   168: iflt -> 220
    //   171: new java/lang/StringBuilder
    //   174: dup
    //   175: invokespecial <init> : ()V
    //   178: astore_3
    //   179: aload_3
    //   180: ldc_w 'MediaMuxer started on video encode thread and audio enabled: '
    //   183: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   186: pop
    //   187: aload_3
    //   188: aload_0
    //   189: getfield mIsAudioEnabled : Ljava/util/concurrent/atomic/AtomicBoolean;
    //   192: invokevirtual append : (Ljava/lang/Object;)Ljava/lang/StringBuilder;
    //   195: pop
    //   196: ldc 'VideoCapture'
    //   198: aload_3
    //   199: invokevirtual toString : ()Ljava/lang/String;
    //   202: invokestatic i : (Ljava/lang/String;Ljava/lang/String;)V
    //   205: aload_0
    //   206: getfield mMuxer : Landroid/media/MediaMuxer;
    //   209: invokevirtual start : ()V
    //   212: aload_0
    //   213: getfield mMuxerStarted : Ljava/util/concurrent/atomic/AtomicBoolean;
    //   216: iconst_1
    //   217: invokevirtual set : (Z)V
    //   220: aload_2
    //   221: monitorexit
    //   222: goto -> 6
    //   225: astore_1
    //   226: aload_2
    //   227: monitorexit
    //   228: aload_1
    //   229: athrow
    //   230: ldc 'VideoCapture'
    //   232: ldc_w 'videoEncoder stop'
    //   235: invokestatic i : (Ljava/lang/String;Ljava/lang/String;)V
    //   238: aload_0
    //   239: getfield mVideoEncoder : Landroid/media/MediaCodec;
    //   242: invokevirtual stop : ()V
    //   245: goto -> 263
    //   248: astore_2
    //   249: aload_1
    //   250: iconst_1
    //   251: ldc_w 'Video encoder stop failed!'
    //   254: aload_2
    //   255: invokeinterface onError : (ILjava/lang/String;Ljava/lang/Throwable;)V
    //   260: iconst_1
    //   261: istore #6
    //   263: aload_0
    //   264: getfield mMuxerLock : Ljava/lang/Object;
    //   267: astore_2
    //   268: aload_2
    //   269: monitorenter
    //   270: aload_0
    //   271: getfield mMuxer : Landroid/media/MediaMuxer;
    //   274: ifnull -> 314
    //   277: aload_0
    //   278: getfield mMuxerStarted : Ljava/util/concurrent/atomic/AtomicBoolean;
    //   281: invokevirtual get : ()Z
    //   284: ifeq -> 302
    //   287: ldc 'VideoCapture'
    //   289: ldc_w 'Muxer already started'
    //   292: invokestatic i : (Ljava/lang/String;Ljava/lang/String;)V
    //   295: aload_0
    //   296: getfield mMuxer : Landroid/media/MediaMuxer;
    //   299: invokevirtual stop : ()V
    //   302: aload_0
    //   303: getfield mMuxer : Landroid/media/MediaMuxer;
    //   306: invokevirtual release : ()V
    //   309: aload_0
    //   310: aconst_null
    //   311: putfield mMuxer : Landroid/media/MediaMuxer;
    //   314: aload_2
    //   315: monitorexit
    //   316: aload_0
    //   317: aload #4
    //   319: invokespecial removeRecordingResultIfNoVideoKeyFrameArrived : (Landroidx/camera/core/VideoCapture$OutputFileOptions;)Z
    //   322: ifne -> 455
    //   325: aload_1
    //   326: bipush #6
    //   328: ldc_w 'The file has no video key frame.'
    //   331: aconst_null
    //   332: invokeinterface onError : (ILjava/lang/String;Ljava/lang/Throwable;)V
    //   337: goto -> 452
    //   340: astore_3
    //   341: aload_2
    //   342: monitorexit
    //   343: aload_3
    //   344: athrow
    //   345: astore_2
    //   346: new java/lang/StringBuilder
    //   349: dup
    //   350: invokespecial <init> : ()V
    //   353: astore_3
    //   354: aload_3
    //   355: ldc_w 'muxer stop IllegalStateException: '
    //   358: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   361: pop
    //   362: aload_3
    //   363: invokestatic currentTimeMillis : ()J
    //   366: invokevirtual append : (J)Ljava/lang/StringBuilder;
    //   369: pop
    //   370: ldc 'VideoCapture'
    //   372: aload_3
    //   373: invokevirtual toString : ()Ljava/lang/String;
    //   376: invokestatic i : (Ljava/lang/String;Ljava/lang/String;)V
    //   379: new java/lang/StringBuilder
    //   382: dup
    //   383: invokespecial <init> : ()V
    //   386: astore_3
    //   387: aload_3
    //   388: ldc_w 'muxer stop exception, mIsFirstVideoKeyFrameWrite: '
    //   391: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   394: pop
    //   395: aload_3
    //   396: aload_0
    //   397: getfield mIsFirstVideoKeyFrameWrite : Ljava/util/concurrent/atomic/AtomicBoolean;
    //   400: invokevirtual get : ()Z
    //   403: invokevirtual append : (Z)Ljava/lang/StringBuilder;
    //   406: pop
    //   407: ldc 'VideoCapture'
    //   409: aload_3
    //   410: invokevirtual toString : ()Ljava/lang/String;
    //   413: invokestatic i : (Ljava/lang/String;Ljava/lang/String;)V
    //   416: aload_0
    //   417: getfield mIsFirstVideoKeyFrameWrite : Ljava/util/concurrent/atomic/AtomicBoolean;
    //   420: invokevirtual get : ()Z
    //   423: ifeq -> 440
    //   426: aload_1
    //   427: iconst_2
    //   428: ldc_w 'Muxer stop failed!'
    //   431: aload_2
    //   432: invokeinterface onError : (ILjava/lang/String;Ljava/lang/Throwable;)V
    //   437: goto -> 452
    //   440: aload_1
    //   441: bipush #6
    //   443: ldc_w 'The file has no video key frame.'
    //   446: aconst_null
    //   447: invokeinterface onError : (ILjava/lang/String;Ljava/lang/Throwable;)V
    //   452: iconst_1
    //   453: istore #6
    //   455: iload #6
    //   457: istore #7
    //   459: aload_0
    //   460: getfield mParcelFileDescriptor : Landroid/os/ParcelFileDescriptor;
    //   463: ifnull -> 500
    //   466: aload_0
    //   467: getfield mParcelFileDescriptor : Landroid/os/ParcelFileDescriptor;
    //   470: invokevirtual close : ()V
    //   473: aload_0
    //   474: aconst_null
    //   475: putfield mParcelFileDescriptor : Landroid/os/ParcelFileDescriptor;
    //   478: iload #6
    //   480: istore #7
    //   482: goto -> 500
    //   485: astore_2
    //   486: aload_1
    //   487: iconst_2
    //   488: ldc_w 'File descriptor close failed!'
    //   491: aload_2
    //   492: invokeinterface onError : (ILjava/lang/String;Ljava/lang/Throwable;)V
    //   497: iconst_1
    //   498: istore #7
    //   500: aload_0
    //   501: getfield mMuxerStarted : Ljava/util/concurrent/atomic/AtomicBoolean;
    //   504: iconst_0
    //   505: invokevirtual set : (Z)V
    //   508: aload_0
    //   509: getfield mEndOfAudioVideoSignal : Ljava/util/concurrent/atomic/AtomicBoolean;
    //   512: iconst_1
    //   513: invokevirtual set : (Z)V
    //   516: aload_0
    //   517: getfield mIsFirstVideoKeyFrameWrite : Ljava/util/concurrent/atomic/AtomicBoolean;
    //   520: iconst_0
    //   521: invokevirtual set : (Z)V
    //   524: ldc 'VideoCapture'
    //   526: ldc_w 'Video encode thread end.'
    //   529: invokestatic i : (Ljava/lang/String;Ljava/lang/String;)V
    //   532: iload #7
    //   534: ireturn
    // Exception table:
    //   from	to	target	type
    //   112	154	225	finally
    //   154	171	225	finally
    //   171	220	225	finally
    //   220	222	225	finally
    //   226	228	225	finally
    //   230	245	248	java/lang/IllegalStateException
    //   263	270	345	java/lang/IllegalStateException
    //   270	302	340	finally
    //   302	314	340	finally
    //   314	316	340	finally
    //   316	337	345	java/lang/IllegalStateException
    //   341	343	340	finally
    //   343	345	345	java/lang/IllegalStateException
    //   466	478	485	java/io/IOException
  }
  
  @RequiresApi(23)
  private static class Api23Impl {
    @DoNotInline
    static int getCodecExceptionErrorCode(MediaCodec.CodecException param1CodecException) {
      return VideoCapture$Api23Impl$.ExternalSyntheticApiModelOutline0.m(param1CodecException);
    }
  }
  
  @RequiresApi(26)
  private static class Api26Impl {
    @DoNotInline
    @NonNull
    static MediaMuxer createMediaMuxer(@NonNull FileDescriptor param1FileDescriptor, int param1Int) throws IOException {
      return new MediaMuxer(param1FileDescriptor, param1Int);
    }
  }
  
  public static final class Builder implements UseCaseConfig.Builder<VideoCapture, VideoCaptureConfig, Builder>, ImageOutputConfig.Builder<Builder>, ThreadConfig.Builder<Builder> {
    private final MutableOptionsBundle mMutableConfig;
    
    public Builder() {
      this(MutableOptionsBundle.create());
    }
    
    private Builder(@NonNull MutableOptionsBundle param1MutableOptionsBundle) {
      this.mMutableConfig = param1MutableOptionsBundle;
      Class clazz = (Class)param1MutableOptionsBundle.retrieveOption(TargetConfig.OPTION_TARGET_CLASS, null);
      if (clazz == null || clazz.equals(VideoCapture.class)) {
        setTargetClass(VideoCapture.class);
        return;
      } 
      StringBuilder stringBuilder = new StringBuilder();
      stringBuilder.append("Invalid target class configuration for ");
      stringBuilder.append(this);
      stringBuilder.append(": ");
      stringBuilder.append(clazz);
      throw new IllegalArgumentException(stringBuilder.toString());
    }
    
    @NonNull
    @RestrictTo({RestrictTo.Scope.LIBRARY_GROUP})
    static Builder fromConfig(@NonNull Config param1Config) {
      return new Builder(MutableOptionsBundle.from(param1Config));
    }
    
    @NonNull
    public static Builder fromConfig(@NonNull VideoCaptureConfig param1VideoCaptureConfig) {
      return new Builder(MutableOptionsBundle.from((Config)param1VideoCaptureConfig));
    }
    
    @NonNull
    public VideoCapture build() {
      if (getMutableConfig().retrieveOption(ImageOutputConfig.OPTION_TARGET_ASPECT_RATIO, null) == null || getMutableConfig().retrieveOption(ImageOutputConfig.OPTION_TARGET_RESOLUTION, null) == null)
        return new VideoCapture(getUseCaseConfig()); 
      throw new IllegalArgumentException("Cannot use both setTargetResolution and setTargetAspectRatio on the same config.");
    }
    
    @NonNull
    @RestrictTo({RestrictTo.Scope.LIBRARY_GROUP})
    public MutableConfig getMutableConfig() {
      return (MutableConfig)this.mMutableConfig;
    }
    
    @NonNull
    @RestrictTo({RestrictTo.Scope.LIBRARY_GROUP})
    public VideoCaptureConfig getUseCaseConfig() {
      return new VideoCaptureConfig(OptionsBundle.from((Config)this.mMutableConfig));
    }
    
    @NonNull
    @RestrictTo({RestrictTo.Scope.LIBRARY_GROUP})
    public Builder setAudioBitRate(int param1Int) {
      getMutableConfig().insertOption(VideoCaptureConfig.OPTION_AUDIO_BIT_RATE, Integer.valueOf(param1Int));
      return this;
    }
    
    @NonNull
    @RestrictTo({RestrictTo.Scope.LIBRARY_GROUP})
    public Builder setAudioChannelCount(int param1Int) {
      getMutableConfig().insertOption(VideoCaptureConfig.OPTION_AUDIO_CHANNEL_COUNT, Integer.valueOf(param1Int));
      return this;
    }
    
    @NonNull
    @RestrictTo({RestrictTo.Scope.LIBRARY_GROUP})
    public Builder setAudioMinBufferSize(int param1Int) {
      getMutableConfig().insertOption(VideoCaptureConfig.OPTION_AUDIO_MIN_BUFFER_SIZE, Integer.valueOf(param1Int));
      return this;
    }
    
    @NonNull
    @RestrictTo({RestrictTo.Scope.LIBRARY_GROUP})
    public Builder setAudioSampleRate(int param1Int) {
      getMutableConfig().insertOption(VideoCaptureConfig.OPTION_AUDIO_SAMPLE_RATE, Integer.valueOf(param1Int));
      return this;
    }
    
    @NonNull
    @RestrictTo({RestrictTo.Scope.LIBRARY_GROUP})
    public Builder setBackgroundExecutor(@NonNull Executor param1Executor) {
      getMutableConfig().insertOption(ThreadConfig.OPTION_BACKGROUND_EXECUTOR, param1Executor);
      return this;
    }
    
    @NonNull
    @RestrictTo({RestrictTo.Scope.LIBRARY_GROUP})
    public Builder setBitRate(int param1Int) {
      getMutableConfig().insertOption(VideoCaptureConfig.OPTION_BIT_RATE, Integer.valueOf(param1Int));
      return this;
    }
    
    @NonNull
    @RestrictTo({RestrictTo.Scope.LIBRARY})
    public Builder setCameraSelector(@NonNull CameraSelector param1CameraSelector) {
      getMutableConfig().insertOption(UseCaseConfig.OPTION_CAMERA_SELECTOR, param1CameraSelector);
      return this;
    }
    
    @NonNull
    @RestrictTo({RestrictTo.Scope.LIBRARY_GROUP})
    public Builder setCaptureOptionUnpacker(@NonNull CaptureConfig.OptionUnpacker param1OptionUnpacker) {
      getMutableConfig().insertOption(UseCaseConfig.OPTION_CAPTURE_CONFIG_UNPACKER, param1OptionUnpacker);
      return this;
    }
    
    @NonNull
    @RestrictTo({RestrictTo.Scope.LIBRARY_GROUP})
    public Builder setDefaultCaptureConfig(@NonNull CaptureConfig param1CaptureConfig) {
      getMutableConfig().insertOption(UseCaseConfig.OPTION_DEFAULT_CAPTURE_CONFIG, param1CaptureConfig);
      return this;
    }
    
    @NonNull
    @RestrictTo({RestrictTo.Scope.LIBRARY_GROUP})
    public Builder setDefaultResolution(@NonNull Size param1Size) {
      getMutableConfig().insertOption(ImageOutputConfig.OPTION_DEFAULT_RESOLUTION, param1Size);
      return this;
    }
    
    @NonNull
    @RestrictTo({RestrictTo.Scope.LIBRARY_GROUP})
    public Builder setDefaultSessionConfig(@NonNull SessionConfig param1SessionConfig) {
      getMutableConfig().insertOption(UseCaseConfig.OPTION_DEFAULT_SESSION_CONFIG, param1SessionConfig);
      return this;
    }
    
    @NonNull
    @RestrictTo({RestrictTo.Scope.LIBRARY_GROUP})
    public Builder setIFrameInterval(int param1Int) {
      getMutableConfig().insertOption(VideoCaptureConfig.OPTION_INTRA_FRAME_INTERVAL, Integer.valueOf(param1Int));
      return this;
    }
    
    @NonNull
    @RestrictTo({RestrictTo.Scope.LIBRARY_GROUP})
    public Builder setMaxResolution(@NonNull Size param1Size) {
      getMutableConfig().insertOption(ImageOutputConfig.OPTION_MAX_RESOLUTION, param1Size);
      return this;
    }
    
    @NonNull
    @RestrictTo({RestrictTo.Scope.LIBRARY_GROUP})
    public Builder setSessionOptionUnpacker(@NonNull SessionConfig.OptionUnpacker param1OptionUnpacker) {
      getMutableConfig().insertOption(UseCaseConfig.OPTION_SESSION_CONFIG_UNPACKER, param1OptionUnpacker);
      return this;
    }
    
    @NonNull
    @RestrictTo({RestrictTo.Scope.LIBRARY_GROUP})
    public Builder setSupportedResolutions(@NonNull List<Pair<Integer, Size[]>> param1List) {
      getMutableConfig().insertOption(ImageOutputConfig.OPTION_SUPPORTED_RESOLUTIONS, param1List);
      return this;
    }
    
    @NonNull
    @RestrictTo({RestrictTo.Scope.LIBRARY_GROUP})
    public Builder setSurfaceOccupancyPriority(int param1Int) {
      getMutableConfig().insertOption(UseCaseConfig.OPTION_SURFACE_OCCUPANCY_PRIORITY, Integer.valueOf(param1Int));
      return this;
    }
    
    @NonNull
    @RestrictTo({RestrictTo.Scope.LIBRARY_GROUP})
    public Builder setTargetAspectRatio(int param1Int) {
      getMutableConfig().insertOption(ImageOutputConfig.OPTION_TARGET_ASPECT_RATIO, Integer.valueOf(param1Int));
      return this;
    }
    
    @NonNull
    @RestrictTo({RestrictTo.Scope.LIBRARY_GROUP})
    public Builder setTargetClass(@NonNull Class<VideoCapture> param1Class) {
      getMutableConfig().insertOption(TargetConfig.OPTION_TARGET_CLASS, param1Class);
      if (getMutableConfig().retrieveOption(TargetConfig.OPTION_TARGET_NAME, null) == null) {
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append(param1Class.getCanonicalName());
        stringBuilder.append("-");
        stringBuilder.append(UUID.randomUUID());
        setTargetName(stringBuilder.toString());
      } 
      return this;
    }
    
    @NonNull
    public Builder setTargetName(@NonNull String param1String) {
      getMutableConfig().insertOption(TargetConfig.OPTION_TARGET_NAME, param1String);
      return this;
    }
    
    @NonNull
    @RestrictTo({RestrictTo.Scope.LIBRARY_GROUP})
    public Builder setTargetResolution(@NonNull Size param1Size) {
      getMutableConfig().insertOption(ImageOutputConfig.OPTION_TARGET_RESOLUTION, param1Size);
      return this;
    }
    
    @NonNull
    @RestrictTo({RestrictTo.Scope.LIBRARY_GROUP})
    public Builder setTargetRotation(int param1Int) {
      getMutableConfig().insertOption(ImageOutputConfig.OPTION_TARGET_ROTATION, Integer.valueOf(param1Int));
      return this;
    }
    
    @NonNull
    @RestrictTo({RestrictTo.Scope.LIBRARY_GROUP})
    public Builder setUseCaseEventCallback(@NonNull UseCase.EventCallback param1EventCallback) {
      getMutableConfig().insertOption(UseCaseEventConfig.OPTION_USE_CASE_EVENT_CALLBACK, param1EventCallback);
      return this;
    }
    
    @NonNull
    @RestrictTo({RestrictTo.Scope.LIBRARY_GROUP})
    public Builder setVideoFrameRate(int param1Int) {
      getMutableConfig().insertOption(VideoCaptureConfig.OPTION_VIDEO_FRAME_RATE, Integer.valueOf(param1Int));
      return this;
    }
    
    @NonNull
    @RestrictTo({RestrictTo.Scope.LIBRARY_GROUP})
    public Builder setZslDisabled(boolean param1Boolean) {
      getMutableConfig().insertOption(UseCaseConfig.OPTION_ZSL_DISABLED, Boolean.valueOf(param1Boolean));
      return this;
    }
  }
  
  @RestrictTo({RestrictTo.Scope.LIBRARY_GROUP})
  public static final class Defaults implements ConfigProvider<VideoCaptureConfig> {
    private static final int DEFAULT_ASPECT_RATIO = 1;
    
    private static final int DEFAULT_AUDIO_BIT_RATE = 64000;
    
    private static final int DEFAULT_AUDIO_CHANNEL_COUNT = 1;
    
    private static final int DEFAULT_AUDIO_MIN_BUFFER_SIZE = 1024;
    
    private static final int DEFAULT_AUDIO_SAMPLE_RATE = 8000;
    
    private static final int DEFAULT_BIT_RATE = 8388608;
    
    private static final VideoCaptureConfig DEFAULT_CONFIG;
    
    private static final int DEFAULT_INTRA_FRAME_INTERVAL = 1;
    
    private static final Size DEFAULT_MAX_RESOLUTION;
    
    private static final int DEFAULT_SURFACE_OCCUPANCY_PRIORITY = 3;
    
    private static final int DEFAULT_VIDEO_FRAME_RATE = 30;
    
    static {
      Size size = new Size(1920, 1080);
      DEFAULT_MAX_RESOLUTION = size;
      DEFAULT_CONFIG = (new VideoCapture.Builder()).setVideoFrameRate(30).setBitRate(8388608).setIFrameInterval(1).setAudioBitRate(64000).setAudioSampleRate(8000).setAudioChannelCount(1).setAudioMinBufferSize(1024).setMaxResolution(size).setSurfaceOccupancyPriority(3).setTargetAspectRatio(1).getUseCaseConfig();
    }
    
    @NonNull
    public VideoCaptureConfig getConfig() {
      return DEFAULT_CONFIG;
    }
  }
  
  public static final class Metadata {
    @Nullable
    public Location location;
  }
  
  public static interface OnVideoSavedCallback {
    void onError(int param1Int, @NonNull String param1String, @Nullable Throwable param1Throwable);
    
    void onVideoSaved(@NonNull VideoCapture.OutputFileResults param1OutputFileResults);
  }
  
  public static final class OutputFileOptions {
    private static final VideoCapture.Metadata EMPTY_METADATA = new VideoCapture.Metadata();
    
    @Nullable
    private final ContentResolver mContentResolver;
    
    @Nullable
    private final ContentValues mContentValues;
    
    @Nullable
    private final File mFile;
    
    @Nullable
    private final FileDescriptor mFileDescriptor;
    
    @Nullable
    private final VideoCapture.Metadata mMetadata;
    
    @Nullable
    private final Uri mSaveCollection;
    
    OutputFileOptions(@Nullable File param1File, @Nullable FileDescriptor param1FileDescriptor, @Nullable ContentResolver param1ContentResolver, @Nullable Uri param1Uri, @Nullable ContentValues param1ContentValues, @Nullable VideoCapture.Metadata param1Metadata) {
      this.mFile = param1File;
      this.mFileDescriptor = param1FileDescriptor;
      this.mContentResolver = param1ContentResolver;
      this.mSaveCollection = param1Uri;
      this.mContentValues = param1ContentValues;
      VideoCapture.Metadata metadata = param1Metadata;
      if (param1Metadata == null)
        metadata = EMPTY_METADATA; 
      this.mMetadata = metadata;
    }
    
    @Nullable
    ContentResolver getContentResolver() {
      return this.mContentResolver;
    }
    
    @Nullable
    ContentValues getContentValues() {
      return this.mContentValues;
    }
    
    @Nullable
    File getFile() {
      return this.mFile;
    }
    
    @Nullable
    FileDescriptor getFileDescriptor() {
      return this.mFileDescriptor;
    }
    
    @Nullable
    VideoCapture.Metadata getMetadata() {
      return this.mMetadata;
    }
    
    @Nullable
    Uri getSaveCollection() {
      return this.mSaveCollection;
    }
    
    boolean isSavingToFile() {
      return (getFile() != null);
    }
    
    boolean isSavingToFileDescriptor() {
      return (getFileDescriptor() != null);
    }
    
    boolean isSavingToMediaStore() {
      return (getSaveCollection() != null && getContentResolver() != null && getContentValues() != null);
    }
    
    public static final class Builder {
      @Nullable
      private ContentResolver mContentResolver;
      
      @Nullable
      private ContentValues mContentValues;
      
      @Nullable
      private File mFile;
      
      @Nullable
      private FileDescriptor mFileDescriptor;
      
      @Nullable
      private VideoCapture.Metadata mMetadata;
      
      @Nullable
      private Uri mSaveCollection;
      
      public Builder(@NonNull ContentResolver param2ContentResolver, @NonNull Uri param2Uri, @NonNull ContentValues param2ContentValues) {
        this.mContentResolver = param2ContentResolver;
        this.mSaveCollection = param2Uri;
        this.mContentValues = param2ContentValues;
      }
      
      public Builder(@NonNull File param2File) {
        this.mFile = param2File;
      }
      
      public Builder(@NonNull FileDescriptor param2FileDescriptor) {
        boolean bool;
        if (Build.VERSION.SDK_INT >= 26) {
          bool = true;
        } else {
          bool = false;
        } 
        Preconditions.checkArgument(bool, "Using a FileDescriptor to record a video is only supported for Android 8.0 or above.");
        this.mFileDescriptor = param2FileDescriptor;
      }
      
      @NonNull
      public VideoCapture.OutputFileOptions build() {
        return new VideoCapture.OutputFileOptions(this.mFile, this.mFileDescriptor, this.mContentResolver, this.mSaveCollection, this.mContentValues, this.mMetadata);
      }
      
      @NonNull
      public Builder setMetadata(@NonNull VideoCapture.Metadata param2Metadata) {
        this.mMetadata = param2Metadata;
        return this;
      }
    }
  }
  
  public static final class Builder {
    @Nullable
    private ContentResolver mContentResolver;
    
    @Nullable
    private ContentValues mContentValues;
    
    @Nullable
    private File mFile;
    
    @Nullable
    private FileDescriptor mFileDescriptor;
    
    @Nullable
    private VideoCapture.Metadata mMetadata;
    
    @Nullable
    private Uri mSaveCollection;
    
    public Builder(@NonNull ContentResolver param1ContentResolver, @NonNull Uri param1Uri, @NonNull ContentValues param1ContentValues) {
      this.mContentResolver = param1ContentResolver;
      this.mSaveCollection = param1Uri;
      this.mContentValues = param1ContentValues;
    }
    
    public Builder(@NonNull File param1File) {
      this.mFile = param1File;
    }
    
    public Builder(@NonNull FileDescriptor param1FileDescriptor) {
      boolean bool;
      if (Build.VERSION.SDK_INT >= 26) {
        bool = true;
      } else {
        bool = false;
      } 
      Preconditions.checkArgument(bool, "Using a FileDescriptor to record a video is only supported for Android 8.0 or above.");
      this.mFileDescriptor = param1FileDescriptor;
    }
    
    @NonNull
    public VideoCapture.OutputFileOptions build() {
      return new VideoCapture.OutputFileOptions(this.mFile, this.mFileDescriptor, this.mContentResolver, this.mSaveCollection, this.mContentValues, this.mMetadata);
    }
    
    @NonNull
    public Builder setMetadata(@NonNull VideoCapture.Metadata param1Metadata) {
      this.mMetadata = param1Metadata;
      return this;
    }
  }
  
  public static class OutputFileResults {
    @Nullable
    private Uri mSavedUri;
    
    OutputFileResults(@Nullable Uri param1Uri) {
      this.mSavedUri = param1Uri;
    }
    
    @Nullable
    public Uri getSavedUri() {
      return this.mSavedUri;
    }
  }
  
  @Retention(RetentionPolicy.SOURCE)
  @RestrictTo({RestrictTo.Scope.LIBRARY_GROUP})
  public static @interface VideoCaptureError {}
  
  enum VideoEncoderInitStatus {
    VIDEO_ENCODER_INIT_STATUS_INITIALIZED_FAILED, VIDEO_ENCODER_INIT_STATUS_INSUFFICIENT_RESOURCE, VIDEO_ENCODER_INIT_STATUS_RESOURCE_RECLAIMED, VIDEO_ENCODER_INIT_STATUS_UNINITIALIZED;
    
    static {
      VideoEncoderInitStatus videoEncoderInitStatus1 = new VideoEncoderInitStatus("VIDEO_ENCODER_INIT_STATUS_UNINITIALIZED", 0);
      VIDEO_ENCODER_INIT_STATUS_UNINITIALIZED = videoEncoderInitStatus1;
      VideoEncoderInitStatus videoEncoderInitStatus2 = new VideoEncoderInitStatus("VIDEO_ENCODER_INIT_STATUS_INITIALIZED_FAILED", 1);
      VIDEO_ENCODER_INIT_STATUS_INITIALIZED_FAILED = videoEncoderInitStatus2;
      VideoEncoderInitStatus videoEncoderInitStatus3 = new VideoEncoderInitStatus("VIDEO_ENCODER_INIT_STATUS_INSUFFICIENT_RESOURCE", 2);
      VIDEO_ENCODER_INIT_STATUS_INSUFFICIENT_RESOURCE = videoEncoderInitStatus3;
      VideoEncoderInitStatus videoEncoderInitStatus4 = new VideoEncoderInitStatus("VIDEO_ENCODER_INIT_STATUS_RESOURCE_RECLAIMED", 3);
      VIDEO_ENCODER_INIT_STATUS_RESOURCE_RECLAIMED = videoEncoderInitStatus4;
      $VALUES = new VideoEncoderInitStatus[] { videoEncoderInitStatus1, videoEncoderInitStatus2, videoEncoderInitStatus3, videoEncoderInitStatus4 };
    }
  }
  
  private static final class VideoSavedListenerWrapper implements OnVideoSavedCallback {
    @NonNull
    Executor mExecutor;
    
    @NonNull
    VideoCapture.OnVideoSavedCallback mOnVideoSavedCallback;
    
    VideoSavedListenerWrapper(@NonNull Executor param1Executor, @NonNull VideoCapture.OnVideoSavedCallback param1OnVideoSavedCallback) {
      this.mExecutor = param1Executor;
      this.mOnVideoSavedCallback = param1OnVideoSavedCallback;
    }
    
    public void onError(int param1Int, @NonNull String param1String, @Nullable Throwable param1Throwable) {
      try {
        this.mExecutor.execute((Runnable)new VideoCapture$VideoSavedListenerWrapper$.ExternalSyntheticLambda1(this, param1Int, param1String, param1Throwable));
        return;
      } catch (RejectedExecutionException rejectedExecutionException) {
        Logger.e("VideoCapture", "Unable to post to the supplied executor.");
        return;
      } 
    }
    
    public void onVideoSaved(@NonNull VideoCapture.OutputFileResults param1OutputFileResults) {
      try {
        this.mExecutor.execute((Runnable)new VideoCapture$VideoSavedListenerWrapper$.ExternalSyntheticLambda0(this, param1OutputFileResults));
        return;
      } catch (RejectedExecutionException rejectedExecutionException) {
        Logger.e("VideoCapture", "Unable to post to the supplied executor.");
        return;
      } 
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\MagicAI - AI Art & Anime Art-dex2jar.jar!\androidx\camera\core\VideoCapture.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */