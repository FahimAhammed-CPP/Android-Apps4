package androidx.camera.camera2.impl;

import android.hardware.camera2.CameraCaptureSession;
import android.hardware.camera2.CameraDevice;
import android.hardware.camera2.CaptureRequest;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.annotation.OptIn;
import androidx.annotation.RequiresApi;
import androidx.annotation.RestrictTo;
import androidx.camera.camera2.interop.CaptureRequestOptions;
import androidx.camera.camera2.interop.ExperimentalCamera2Interop;
import androidx.camera.core.ExtendableBuilder;
import androidx.camera.core.impl.Config;
import androidx.camera.core.impl.MutableConfig;
import androidx.camera.core.impl.MutableOptionsBundle;
import androidx.camera.core.impl.OptionsBundle;

@OptIn(markerClass = {ExperimentalCamera2Interop.class})
@RequiresApi(21)
public final class Camera2ImplConfig extends CaptureRequestOptions {
  @RestrictTo({RestrictTo.Scope.LIBRARY})
  public static final Config.Option<CameraEventCallbacks> CAMERA_EVENT_CALLBACK_OPTION;
  
  @RestrictTo({RestrictTo.Scope.LIBRARY})
  public static final String CAPTURE_REQUEST_ID_STEM = "camera2.captureRequest.option.";
  
  @RestrictTo({RestrictTo.Scope.LIBRARY})
  public static final Config.Option<Object> CAPTURE_REQUEST_TAG_OPTION;
  
  @RestrictTo({RestrictTo.Scope.LIBRARY})
  public static final Config.Option<CameraDevice.StateCallback> DEVICE_STATE_CALLBACK_OPTION;
  
  @RestrictTo({RestrictTo.Scope.LIBRARY})
  public static final Config.Option<CameraCaptureSession.CaptureCallback> SESSION_CAPTURE_CALLBACK_OPTION;
  
  @RestrictTo({RestrictTo.Scope.LIBRARY})
  public static final Config.Option<String> SESSION_PHYSICAL_CAMERA_ID_OPTION;
  
  @RestrictTo({RestrictTo.Scope.LIBRARY})
  public static final Config.Option<CameraCaptureSession.StateCallback> SESSION_STATE_CALLBACK_OPTION;
  
  @RestrictTo({RestrictTo.Scope.LIBRARY})
  public static final Config.Option<Long> STREAM_USE_CASE_OPTION;
  
  @RestrictTo({RestrictTo.Scope.LIBRARY})
  public static final Config.Option<Integer> TEMPLATE_TYPE_OPTION = Config.Option.create("camera2.captureRequest.templateType", int.class);
  
  static {
    STREAM_USE_CASE_OPTION = Config.Option.create("camera2.cameraCaptureSession.streamUseCase", long.class);
    DEVICE_STATE_CALLBACK_OPTION = Config.Option.create("camera2.cameraDevice.stateCallback", CameraDevice.StateCallback.class);
    SESSION_STATE_CALLBACK_OPTION = Config.Option.create("camera2.cameraCaptureSession.stateCallback", CameraCaptureSession.StateCallback.class);
    SESSION_CAPTURE_CALLBACK_OPTION = Config.Option.create("camera2.cameraCaptureSession.captureCallback", CameraCaptureSession.CaptureCallback.class);
    CAMERA_EVENT_CALLBACK_OPTION = Config.Option.create("camera2.cameraEvent.callback", CameraEventCallbacks.class);
    CAPTURE_REQUEST_TAG_OPTION = Config.Option.create("camera2.captureRequest.tag", Object.class);
    SESSION_PHYSICAL_CAMERA_ID_OPTION = Config.Option.create("camera2.cameraCaptureSession.physicalCameraId", String.class);
  }
  
  public Camera2ImplConfig(@NonNull Config paramConfig) {
    super(paramConfig);
  }
  
  @NonNull
  @RestrictTo({RestrictTo.Scope.LIBRARY})
  public static Config.Option<Object> createCaptureRequestOption(@NonNull CaptureRequest.Key<?> paramKey) {
    StringBuilder stringBuilder = new StringBuilder();
    stringBuilder.append("camera2.captureRequest.option.");
    stringBuilder.append(paramKey.getName());
    return Config.Option.create(stringBuilder.toString(), Object.class, paramKey);
  }
  
  @Nullable
  public CameraEventCallbacks getCameraEventCallback(@Nullable CameraEventCallbacks paramCameraEventCallbacks) {
    return (CameraEventCallbacks)getConfig().retrieveOption(CAMERA_EVENT_CALLBACK_OPTION, paramCameraEventCallbacks);
  }
  
  @NonNull
  @RestrictTo({RestrictTo.Scope.LIBRARY})
  public CaptureRequestOptions getCaptureRequestOptions() {
    return CaptureRequestOptions.Builder.from(getConfig()).build();
  }
  
  @Nullable
  public Object getCaptureRequestTag(@Nullable Object paramObject) {
    return getConfig().retrieveOption(CAPTURE_REQUEST_TAG_OPTION, paramObject);
  }
  
  public int getCaptureRequestTemplate(int paramInt) {
    return ((Integer)getConfig().retrieveOption(TEMPLATE_TYPE_OPTION, Integer.valueOf(paramInt))).intValue();
  }
  
  @Nullable
  public CameraDevice.StateCallback getDeviceStateCallback(@Nullable CameraDevice.StateCallback paramStateCallback) {
    return (CameraDevice.StateCallback)getConfig().retrieveOption(DEVICE_STATE_CALLBACK_OPTION, paramStateCallback);
  }
  
  @Nullable
  public String getPhysicalCameraId(@Nullable String paramString) {
    return (String)getConfig().retrieveOption(SESSION_PHYSICAL_CAMERA_ID_OPTION, paramString);
  }
  
  @Nullable
  public CameraCaptureSession.CaptureCallback getSessionCaptureCallback(@Nullable CameraCaptureSession.CaptureCallback paramCaptureCallback) {
    return (CameraCaptureSession.CaptureCallback)getConfig().retrieveOption(SESSION_CAPTURE_CALLBACK_OPTION, paramCaptureCallback);
  }
  
  @Nullable
  public CameraCaptureSession.StateCallback getSessionStateCallback(@Nullable CameraCaptureSession.StateCallback paramStateCallback) {
    return (CameraCaptureSession.StateCallback)getConfig().retrieveOption(SESSION_STATE_CALLBACK_OPTION, paramStateCallback);
  }
  
  public long getStreamUseCase(long paramLong) {
    return ((Long)getConfig().retrieveOption(STREAM_USE_CASE_OPTION, Long.valueOf(paramLong))).longValue();
  }
  
  public static final class Builder implements ExtendableBuilder<Camera2ImplConfig> {
    private final MutableOptionsBundle mMutableOptionsBundle = MutableOptionsBundle.create();
    
    @NonNull
    public Camera2ImplConfig build() {
      return new Camera2ImplConfig((Config)OptionsBundle.from((Config)this.mMutableOptionsBundle));
    }
    
    @NonNull
    public MutableConfig getMutableConfig() {
      return (MutableConfig)this.mMutableOptionsBundle;
    }
    
    @NonNull
    public Builder insertAllOptions(@NonNull Config param1Config) {
      for (Config.Option option : param1Config.listOptions())
        this.mMutableOptionsBundle.insertOption(option, param1Config.retrieveOption(option)); 
      return this;
    }
    
    @NonNull
    public <ValueT> Builder setCaptureRequestOption(@NonNull CaptureRequest.Key<ValueT> param1Key, @NonNull ValueT param1ValueT) {
      Config.Option<Object> option = Camera2ImplConfig.createCaptureRequestOption(param1Key);
      this.mMutableOptionsBundle.insertOption(option, param1ValueT);
      return this;
    }
    
    @NonNull
    public <ValueT> Builder setCaptureRequestOptionWithPriority(@NonNull CaptureRequest.Key<ValueT> param1Key, @NonNull ValueT param1ValueT, @NonNull Config.OptionPriority param1OptionPriority) {
      Config.Option<Object> option = Camera2ImplConfig.createCaptureRequestOption(param1Key);
      this.mMutableOptionsBundle.insertOption(option, param1OptionPriority, param1ValueT);
      return this;
    }
  }
  
  public static final class Extender<T> {
    ExtendableBuilder<T> mBaseBuilder;
    
    public Extender(@NonNull ExtendableBuilder<T> param1ExtendableBuilder) {
      this.mBaseBuilder = param1ExtendableBuilder;
    }
    
    @NonNull
    public Extender<T> setCameraEventCallback(@NonNull CameraEventCallbacks param1CameraEventCallbacks) {
      this.mBaseBuilder.getMutableConfig().insertOption(Camera2ImplConfig.CAMERA_EVENT_CALLBACK_OPTION, param1CameraEventCallbacks);
      return this;
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\MagicAI - AI Art & Anime Art-dex2jar.jar!\androidx\camera\camera2\impl\Camera2ImplConfig.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */