package androidx.camera.camera2.interop;

import android.hardware.camera2.TotalCaptureResult;
import androidx.camera.camera2.internal.Camera2CameraControlImpl;



/* Location:              C:\soft\dex2jar-2.0\MagicAI - AI Art & Anime Art-dex2jar.jar!\androidx\camera\camera2\interop\Camera2CameraControl$$ExternalSyntheticLambda4.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */