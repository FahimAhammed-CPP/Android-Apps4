package androidx.camera.camera2.internal;

import android.hardware.camera2.CameraDevice;
import android.hardware.camera2.CaptureRequest;
import android.hardware.camera2.CaptureResult;
import android.util.Size;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.annotation.OptIn;
import androidx.annotation.RequiresApi;
import androidx.arch.core.util.Function;
import androidx.camera.camera2.impl.Camera2ImplConfig;
import androidx.camera.camera2.interop.CaptureRequestOptions;
import androidx.camera.camera2.interop.ExperimentalCamera2Interop;
import androidx.camera.core.CameraInfo;
import androidx.camera.core.ImageAnalysis;
import androidx.camera.core.ImageCapture;
import androidx.camera.core.Logger;
import androidx.camera.core.Preview;
import androidx.camera.core.impl.CameraCaptureCallback;
import androidx.camera.core.impl.CameraCaptureFailure;
import androidx.camera.core.impl.CameraCaptureResult;
import androidx.camera.core.impl.CaptureConfig;
import androidx.camera.core.impl.Config;
import androidx.camera.core.impl.DeferrableSurface;
import androidx.camera.core.impl.DeferrableSurfaces;
import androidx.camera.core.impl.OutputSurface;
import androidx.camera.core.impl.RequestProcessor;
import androidx.camera.core.impl.SessionConfig;
import androidx.camera.core.impl.SessionProcessor;
import androidx.camera.core.impl.SessionProcessorSurface;
import androidx.camera.core.impl.utils.executor.CameraXExecutors;
import androidx.camera.core.impl.utils.futures.AsyncFunction;
import androidx.camera.core.impl.utils.futures.FutureCallback;
import androidx.camera.core.impl.utils.futures.FutureChain;
import androidx.camera.core.impl.utils.futures.Futures;
import androidx.core.util.Preconditions;
import com.google.common.util.concurrent.ListenableFuture;
import j$.util.Objects;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.concurrent.Executor;
import java.util.concurrent.ScheduledExecutorService;

@OptIn(markerClass = {ExperimentalCamera2Interop.class})
@RequiresApi(21)
final class ProcessingCaptureSession implements CaptureSessionInterface {
  private static final String TAG = "ProcessingCaptureSession";
  
  private static final long TIMEOUT_GET_SURFACE_IN_MS = 5000L;
  
  private static List<DeferrableSurface> sHeldProcessorSurfaces = new ArrayList<DeferrableSurface>();
  
  private static int sNextInstanceId = 0;
  
  private final Camera2CameraInfoImpl mCamera2CameraInfoImpl;
  
  private final CaptureSession mCaptureSession = new CaptureSession();
  
  final Executor mExecutor;
  
  private int mInstanceId = 0;
  
  volatile boolean mIsExecutingStillCaptureRequest = false;
  
  private List<DeferrableSurface> mOutputSurfaces = new ArrayList<DeferrableSurface>();
  
  @Nullable
  private volatile CaptureConfig mPendingCaptureConfig = null;
  
  @Nullable
  private SessionConfig mProcessorSessionConfig;
  
  private ProcessorState mProcessorState;
  
  @Nullable
  private Camera2RequestProcessor mRequestProcessor;
  
  private final ScheduledExecutorService mScheduledExecutorService;
  
  @Nullable
  private SessionConfig mSessionConfig;
  
  private CaptureRequestOptions mSessionOptions = (new CaptureRequestOptions.Builder()).build();
  
  private final SessionProcessor mSessionProcessor;
  
  private final SessionProcessorCaptureCallback mSessionProcessorCaptureCallback;
  
  private CaptureRequestOptions mStillCaptureOptions = (new CaptureRequestOptions.Builder()).build();
  
  ProcessingCaptureSession(@NonNull SessionProcessor paramSessionProcessor, @NonNull Camera2CameraInfoImpl paramCamera2CameraInfoImpl, @NonNull Executor paramExecutor, @NonNull ScheduledExecutorService paramScheduledExecutorService) {
    this.mSessionProcessor = paramSessionProcessor;
    this.mCamera2CameraInfoImpl = paramCamera2CameraInfoImpl;
    this.mExecutor = paramExecutor;
    this.mScheduledExecutorService = paramScheduledExecutorService;
    this.mProcessorState = ProcessorState.UNINITIALIZED;
    this.mSessionProcessorCaptureCallback = new SessionProcessorCaptureCallback();
    int i = sNextInstanceId;
    sNextInstanceId = i + 1;
    this.mInstanceId = i;
    StringBuilder stringBuilder = new StringBuilder();
    stringBuilder.append("New ProcessingCaptureSession (id=");
    stringBuilder.append(this.mInstanceId);
    stringBuilder.append(")");
    Logger.d("ProcessingCaptureSession", stringBuilder.toString());
  }
  
  private static void cancelRequests(@NonNull List<CaptureConfig> paramList) {
    Iterator<CaptureConfig> iterator = paramList.iterator();
    while (iterator.hasNext()) {
      Iterator<CameraCaptureCallback> iterator1 = ((CaptureConfig)iterator.next()).getCameraCaptureCallbacks().iterator();
      while (iterator1.hasNext())
        ((CameraCaptureCallback)iterator1.next()).onCaptureCancelled(); 
    } 
  }
  
  private static List<SessionProcessorSurface> getSessionProcessorSurfaceList(List<DeferrableSurface> paramList) {
    ArrayList<SessionProcessorSurface> arrayList = new ArrayList();
    for (DeferrableSurface deferrableSurface : paramList) {
      Preconditions.checkArgument(deferrableSurface instanceof SessionProcessorSurface, "Surface must be SessionProcessorSurface");
      arrayList.add((SessionProcessorSurface)deferrableSurface);
    } 
    return arrayList;
  }
  
  private boolean isStillCapture(@NonNull List<CaptureConfig> paramList) {
    if (paramList.isEmpty())
      return false; 
    Iterator<CaptureConfig> iterator = paramList.iterator();
    while (iterator.hasNext()) {
      if (((CaptureConfig)iterator.next()).getTemplateType() != 2)
        return false; 
    } 
    return true;
  }
  
  private void updateParameters(@NonNull CaptureRequestOptions paramCaptureRequestOptions1, @NonNull CaptureRequestOptions paramCaptureRequestOptions2) {
    Camera2ImplConfig.Builder builder = new Camera2ImplConfig.Builder();
    builder.insertAllOptions((Config)paramCaptureRequestOptions1);
    builder.insertAllOptions((Config)paramCaptureRequestOptions2);
    this.mSessionProcessor.setParameters((Config)builder.build());
  }
  
  public void cancelIssuedCaptureRequests() {
    StringBuilder stringBuilder = new StringBuilder();
    stringBuilder.append("cancelIssuedCaptureRequests (id=");
    stringBuilder.append(this.mInstanceId);
    stringBuilder.append(")");
    Logger.d("ProcessingCaptureSession", stringBuilder.toString());
    if (this.mPendingCaptureConfig != null) {
      Iterator<CameraCaptureCallback> iterator = this.mPendingCaptureConfig.getCameraCaptureCallbacks().iterator();
      while (iterator.hasNext())
        ((CameraCaptureCallback)iterator.next()).onCaptureCancelled(); 
      this.mPendingCaptureConfig = null;
    } 
  }
  
  public void close() {
    // Byte code:
    //   0: new java/lang/StringBuilder
    //   3: dup
    //   4: invokespecial <init> : ()V
    //   7: astore_2
    //   8: aload_2
    //   9: ldc_w 'close (id='
    //   12: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   15: pop
    //   16: aload_2
    //   17: aload_0
    //   18: getfield mInstanceId : I
    //   21: invokevirtual append : (I)Ljava/lang/StringBuilder;
    //   24: pop
    //   25: aload_2
    //   26: ldc_w ') state='
    //   29: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   32: pop
    //   33: aload_2
    //   34: aload_0
    //   35: getfield mProcessorState : Landroidx/camera/camera2/internal/ProcessingCaptureSession$ProcessorState;
    //   38: invokevirtual append : (Ljava/lang/Object;)Ljava/lang/StringBuilder;
    //   41: pop
    //   42: ldc 'ProcessingCaptureSession'
    //   44: aload_2
    //   45: invokevirtual toString : ()Ljava/lang/String;
    //   48: invokestatic d : (Ljava/lang/String;Ljava/lang/String;)V
    //   51: getstatic androidx/camera/camera2/internal/ProcessingCaptureSession$3.$SwitchMap$androidx$camera$camera2$internal$ProcessingCaptureSession$ProcessorState : [I
    //   54: aload_0
    //   55: getfield mProcessorState : Landroidx/camera/camera2/internal/ProcessingCaptureSession$ProcessorState;
    //   58: invokevirtual ordinal : ()I
    //   61: iaload
    //   62: istore_1
    //   63: iload_1
    //   64: iconst_2
    //   65: if_icmpeq -> 116
    //   68: iload_1
    //   69: iconst_3
    //   70: if_icmpeq -> 87
    //   73: iload_1
    //   74: iconst_4
    //   75: if_icmpeq -> 116
    //   78: iload_1
    //   79: iconst_5
    //   80: if_icmpeq -> 86
    //   83: goto -> 125
    //   86: return
    //   87: aload_0
    //   88: getfield mSessionProcessor : Landroidx/camera/core/impl/SessionProcessor;
    //   91: invokeinterface onCaptureSessionEnd : ()V
    //   96: aload_0
    //   97: getfield mRequestProcessor : Landroidx/camera/camera2/internal/Camera2RequestProcessor;
    //   100: astore_2
    //   101: aload_2
    //   102: ifnull -> 109
    //   105: aload_2
    //   106: invokevirtual close : ()V
    //   109: aload_0
    //   110: getstatic androidx/camera/camera2/internal/ProcessingCaptureSession$ProcessorState.ON_CAPTURE_SESSION_ENDED : Landroidx/camera/camera2/internal/ProcessingCaptureSession$ProcessorState;
    //   113: putfield mProcessorState : Landroidx/camera/camera2/internal/ProcessingCaptureSession$ProcessorState;
    //   116: aload_0
    //   117: getfield mSessionProcessor : Landroidx/camera/core/impl/SessionProcessor;
    //   120: invokeinterface deInitSession : ()V
    //   125: aload_0
    //   126: getstatic androidx/camera/camera2/internal/ProcessingCaptureSession$ProcessorState.CLOSED : Landroidx/camera/camera2/internal/ProcessingCaptureSession$ProcessorState;
    //   129: putfield mProcessorState : Landroidx/camera/camera2/internal/ProcessingCaptureSession$ProcessorState;
    //   132: aload_0
    //   133: getfield mCaptureSession : Landroidx/camera/camera2/internal/CaptureSession;
    //   136: invokevirtual close : ()V
    //   139: return
  }
  
  @NonNull
  public List<CaptureConfig> getCaptureConfigs() {
    return (this.mPendingCaptureConfig != null) ? Arrays.asList(new CaptureConfig[] { this.mPendingCaptureConfig }) : Collections.emptyList();
  }
  
  @Nullable
  public SessionConfig getSessionConfig() {
    return this.mSessionConfig;
  }
  
  public void issueCaptureRequests(@NonNull List<CaptureConfig> paramList) {
    final StringBuilder captureConfig;
    if (paramList.isEmpty())
      return; 
    if (paramList.size() > 1 || !isStillCapture(paramList)) {
      cancelRequests(paramList);
      return;
    } 
    if (this.mPendingCaptureConfig != null || this.mIsExecutingStillCaptureRequest) {
      cancelRequests(paramList);
      return;
    } 
    CaptureConfig captureConfig = paramList.get(0);
    StringBuilder stringBuilder2 = new StringBuilder();
    stringBuilder2.append("issueCaptureRequests (id=");
    stringBuilder2.append(this.mInstanceId);
    stringBuilder2.append(") + state =");
    stringBuilder2.append(this.mProcessorState);
    Logger.d("ProcessingCaptureSession", stringBuilder2.toString());
    int i = null.$SwitchMap$androidx$camera$camera2$internal$ProcessingCaptureSession$ProcessorState[this.mProcessorState.ordinal()];
    if (i != 1 && i != 2) {
      if (i != 3) {
        if (i != 4 && i != 5)
          return; 
        stringBuilder1 = new StringBuilder();
        stringBuilder1.append("Run issueCaptureRequests in wrong state, state = ");
        stringBuilder1.append(this.mProcessorState);
        Logger.d("ProcessingCaptureSession", stringBuilder1.toString());
        cancelRequests(paramList);
        return;
      } 
      this.mIsExecutingStillCaptureRequest = true;
      CaptureRequestOptions.Builder builder = CaptureRequestOptions.Builder.from(stringBuilder1.getImplementationOptions());
      Config config = stringBuilder1.getImplementationOptions();
      Config.Option option = CaptureConfig.OPTION_ROTATION;
      if (config.containsOption(option))
        builder.setCaptureRequestOption(CaptureRequest.JPEG_ORIENTATION, stringBuilder1.getImplementationOptions().retrieveOption(option)); 
      config = stringBuilder1.getImplementationOptions();
      option = CaptureConfig.OPTION_JPEG_QUALITY;
      if (config.containsOption(option))
        builder.setCaptureRequestOption(CaptureRequest.JPEG_QUALITY, Byte.valueOf(((Integer)stringBuilder1.getImplementationOptions().retrieveOption(option)).byteValue())); 
      CaptureRequestOptions captureRequestOptions = builder.build();
      this.mStillCaptureOptions = captureRequestOptions;
      updateParameters(this.mSessionOptions, captureRequestOptions);
      this.mSessionProcessor.startCapture(new SessionProcessor.CaptureCallback() {
            public void onCaptureCompleted(long param1Long, int param1Int, @NonNull Map<CaptureResult.Key, Object> param1Map) {}
            
            public void onCaptureFailed(int param1Int) {
              ProcessingCaptureSession.this.mExecutor.execute((Runnable)new ProcessingCaptureSession$2$.ExternalSyntheticLambda1(this, captureConfig));
            }
            
            public void onCaptureProcessStarted(int param1Int) {}
            
            public void onCaptureSequenceAborted(int param1Int) {}
            
            public void onCaptureSequenceCompleted(int param1Int) {
              ProcessingCaptureSession.this.mExecutor.execute((Runnable)new ProcessingCaptureSession$2$.ExternalSyntheticLambda0(this, captureConfig));
            }
            
            public void onCaptureStarted(int param1Int, long param1Long) {}
          });
      return;
    } 
    this.mPendingCaptureConfig = (CaptureConfig)stringBuilder1;
  }
  
  void onConfigured(@NonNull CaptureSession paramCaptureSession) {
    boolean bool;
    if (this.mProcessorState == ProcessorState.SESSION_INITIALIZED) {
      bool = true;
    } else {
      bool = false;
    } 
    StringBuilder stringBuilder = new StringBuilder();
    stringBuilder.append("Invalid state state:");
    stringBuilder.append(this.mProcessorState);
    Preconditions.checkArgument(bool, stringBuilder.toString());
    Camera2RequestProcessor camera2RequestProcessor = new Camera2RequestProcessor(paramCaptureSession, getSessionProcessorSurfaceList(this.mProcessorSessionConfig.getSurfaces()));
    this.mRequestProcessor = camera2RequestProcessor;
    this.mSessionProcessor.onCaptureSessionStart((RequestProcessor)camera2RequestProcessor);
    this.mProcessorState = ProcessorState.ON_CAPTURE_SESSION_STARTED;
    SessionConfig sessionConfig = this.mSessionConfig;
    if (sessionConfig != null)
      setSessionConfig(sessionConfig); 
    if (this.mPendingCaptureConfig != null) {
      List<CaptureConfig> list = Arrays.asList(new CaptureConfig[] { this.mPendingCaptureConfig });
      this.mPendingCaptureConfig = null;
      issueCaptureRequests(list);
    } 
  }
  
  @NonNull
  public ListenableFuture<Void> open(@NonNull SessionConfig paramSessionConfig, @NonNull CameraDevice paramCameraDevice, @NonNull SynchronizedCaptureSessionOpener paramSynchronizedCaptureSessionOpener) {
    boolean bool;
    if (this.mProcessorState == ProcessorState.UNINITIALIZED) {
      bool = true;
    } else {
      bool = false;
    } 
    StringBuilder stringBuilder = new StringBuilder();
    stringBuilder.append("Invalid state state:");
    stringBuilder.append(this.mProcessorState);
    Preconditions.checkArgument(bool, stringBuilder.toString());
    Preconditions.checkArgument(paramSessionConfig.getSurfaces().isEmpty() ^ true, "SessionConfig contains no surfaces");
    stringBuilder = new StringBuilder();
    stringBuilder.append("open (id=");
    stringBuilder.append(this.mInstanceId);
    stringBuilder.append(")");
    Logger.d("ProcessingCaptureSession", stringBuilder.toString());
    List<DeferrableSurface> list = paramSessionConfig.getSurfaces();
    this.mOutputSurfaces = list;
    return (ListenableFuture<Void>)FutureChain.from(DeferrableSurfaces.surfaceListWithTimeout(list, false, 5000L, this.mExecutor, this.mScheduledExecutorService)).transformAsync((AsyncFunction)new ProcessingCaptureSession$.ExternalSyntheticLambda2(this, paramSessionConfig, paramCameraDevice, paramSynchronizedCaptureSessionOpener), this.mExecutor).transform((Function)new ProcessingCaptureSession$.ExternalSyntheticLambda3(this), this.mExecutor);
  }
  
  @NonNull
  public ListenableFuture<Void> release(boolean paramBoolean) {
    boolean bool;
    if (this.mProcessorState == ProcessorState.CLOSED) {
      bool = true;
    } else {
      bool = false;
    } 
    Preconditions.checkState(bool, "release() can only be called in CLOSED state");
    StringBuilder stringBuilder = new StringBuilder();
    stringBuilder.append("release (id=");
    stringBuilder.append(this.mInstanceId);
    stringBuilder.append(")");
    Logger.d("ProcessingCaptureSession", stringBuilder.toString());
    return this.mCaptureSession.release(paramBoolean);
  }
  
  public void setSessionConfig(@Nullable SessionConfig paramSessionConfig) {
    StringBuilder stringBuilder = new StringBuilder();
    stringBuilder.append("setSessionConfig (id=");
    stringBuilder.append(this.mInstanceId);
    stringBuilder.append(")");
    Logger.d("ProcessingCaptureSession", stringBuilder.toString());
    this.mSessionConfig = paramSessionConfig;
    if (paramSessionConfig == null)
      return; 
    Camera2RequestProcessor camera2RequestProcessor = this.mRequestProcessor;
    if (camera2RequestProcessor != null)
      camera2RequestProcessor.updateSessionConfig(paramSessionConfig); 
    if (this.mProcessorState == ProcessorState.ON_CAPTURE_SESSION_STARTED) {
      CaptureRequestOptions captureRequestOptions = CaptureRequestOptions.Builder.from(paramSessionConfig.getImplementationOptions()).build();
      this.mSessionOptions = captureRequestOptions;
      updateParameters(captureRequestOptions, this.mStillCaptureOptions);
      this.mSessionProcessor.startRepeating(this.mSessionProcessorCaptureCallback);
    } 
  }
  
  private enum ProcessorState {
    CLOSED, ON_CAPTURE_SESSION_ENDED, ON_CAPTURE_SESSION_STARTED, SESSION_INITIALIZED, UNINITIALIZED;
    
    static {
      ProcessorState processorState1 = new ProcessorState("UNINITIALIZED", 0);
      UNINITIALIZED = processorState1;
      ProcessorState processorState2 = new ProcessorState("SESSION_INITIALIZED", 1);
      SESSION_INITIALIZED = processorState2;
      ProcessorState processorState3 = new ProcessorState("ON_CAPTURE_SESSION_STARTED", 2);
      ON_CAPTURE_SESSION_STARTED = processorState3;
      ProcessorState processorState4 = new ProcessorState("ON_CAPTURE_SESSION_ENDED", 3);
      ON_CAPTURE_SESSION_ENDED = processorState4;
      ProcessorState processorState5 = new ProcessorState("CLOSED", 4);
      CLOSED = processorState5;
      $VALUES = new ProcessorState[] { processorState1, processorState2, processorState3, processorState4, processorState5 };
    }
  }
  
  private static class SessionProcessorCaptureCallback implements SessionProcessor.CaptureCallback {
    public void onCaptureCompleted(long param1Long, int param1Int, @NonNull Map<CaptureResult.Key, Object> param1Map) {}
    
    public void onCaptureFailed(int param1Int) {}
    
    public void onCaptureProcessStarted(int param1Int) {}
    
    public void onCaptureSequenceAborted(int param1Int) {}
    
    public void onCaptureSequenceCompleted(int param1Int) {}
    
    public void onCaptureStarted(int param1Int, long param1Long) {}
  }
}


/* Location:              C:\soft\dex2jar-2.0\MagicAI - AI Art & Anime Art-dex2jar.jar!\androidx\camera\camera2\internal\ProcessingCaptureSession.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */