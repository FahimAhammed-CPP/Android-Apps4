package androidx.camera.camera2.internal;

import android.hardware.camera2.CameraCaptureSession;
import android.view.Surface;
import androidx.annotation.NonNull;
import androidx.annotation.RequiresApi;
import androidx.camera.camera2.internal.compat.ApiCompat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Iterator;
import java.util.List;

@RequiresApi(21)
final class SynchronizedCaptureSessionStateCallbacks extends SynchronizedCaptureSession.StateCallback {
  private final List<SynchronizedCaptureSession.StateCallback> mCallbacks;
  
  SynchronizedCaptureSessionStateCallbacks(@NonNull List<SynchronizedCaptureSession.StateCallback> paramList) {
    ArrayList<SynchronizedCaptureSession.StateCallback> arrayList = new ArrayList();
    this.mCallbacks = arrayList;
    arrayList.addAll(paramList);
  }
  
  @NonNull
  static SynchronizedCaptureSession.StateCallback createComboCallback(@NonNull SynchronizedCaptureSession.StateCallback... paramVarArgs) {
    return new SynchronizedCaptureSessionStateCallbacks(Arrays.asList(paramVarArgs));
  }
  
  public void onActive(@NonNull SynchronizedCaptureSession paramSynchronizedCaptureSession) {
    Iterator<SynchronizedCaptureSession.StateCallback> iterator = this.mCallbacks.iterator();
    while (iterator.hasNext())
      ((SynchronizedCaptureSession.StateCallback)iterator.next()).onActive(paramSynchronizedCaptureSession); 
  }
  
  @RequiresApi(api = 26)
  public void onCaptureQueueEmpty(@NonNull SynchronizedCaptureSession paramSynchronizedCaptureSession) {
    Iterator<SynchronizedCaptureSession.StateCallback> iterator = this.mCallbacks.iterator();
    while (iterator.hasNext())
      ((SynchronizedCaptureSession.StateCallback)iterator.next()).onCaptureQueueEmpty(paramSynchronizedCaptureSession); 
  }
  
  public void onClosed(@NonNull SynchronizedCaptureSession paramSynchronizedCaptureSession) {
    Iterator<SynchronizedCaptureSession.StateCallback> iterator = this.mCallbacks.iterator();
    while (iterator.hasNext())
      ((SynchronizedCaptureSession.StateCallback)iterator.next()).onClosed(paramSynchronizedCaptureSession); 
  }
  
  public void onConfigureFailed(@NonNull SynchronizedCaptureSession paramSynchronizedCaptureSession) {
    Iterator<SynchronizedCaptureSession.StateCallback> iterator = this.mCallbacks.iterator();
    while (iterator.hasNext())
      ((SynchronizedCaptureSession.StateCallback)iterator.next()).onConfigureFailed(paramSynchronizedCaptureSession); 
  }
  
  public void onConfigured(@NonNull SynchronizedCaptureSession paramSynchronizedCaptureSession) {
    Iterator<SynchronizedCaptureSession.StateCallback> iterator = this.mCallbacks.iterator();
    while (iterator.hasNext())
      ((SynchronizedCaptureSession.StateCallback)iterator.next()).onConfigured(paramSynchronizedCaptureSession); 
  }
  
  public void onReady(@NonNull SynchronizedCaptureSession paramSynchronizedCaptureSession) {
    Iterator<SynchronizedCaptureSession.StateCallback> iterator = this.mCallbacks.iterator();
    while (iterator.hasNext())
      ((SynchronizedCaptureSession.StateCallback)iterator.next()).onReady(paramSynchronizedCaptureSession); 
  }
  
  void onSessionFinished(@NonNull SynchronizedCaptureSession paramSynchronizedCaptureSession) {
    Iterator<SynchronizedCaptureSession.StateCallback> iterator = this.mCallbacks.iterator();
    while (iterator.hasNext())
      ((SynchronizedCaptureSession.StateCallback)iterator.next()).onSessionFinished(paramSynchronizedCaptureSession); 
  }
  
  @RequiresApi(api = 23)
  public void onSurfacePrepared(@NonNull SynchronizedCaptureSession paramSynchronizedCaptureSession, @NonNull Surface paramSurface) {
    Iterator<SynchronizedCaptureSession.StateCallback> iterator = this.mCallbacks.iterator();
    while (iterator.hasNext())
      ((SynchronizedCaptureSession.StateCallback)iterator.next()).onSurfacePrepared(paramSynchronizedCaptureSession, paramSurface); 
  }
  
  @RequiresApi(21)
  static class Adapter extends SynchronizedCaptureSession.StateCallback {
    @NonNull
    private final CameraCaptureSession.StateCallback mCameraCaptureSessionStateCallback;
    
    Adapter(@NonNull CameraCaptureSession.StateCallback param1StateCallback) {
      this.mCameraCaptureSessionStateCallback = param1StateCallback;
    }
    
    Adapter(@NonNull List<CameraCaptureSession.StateCallback> param1List) {
      this(CameraCaptureSessionStateCallbacks.createComboCallback(param1List));
    }
    
    public void onActive(@NonNull SynchronizedCaptureSession param1SynchronizedCaptureSession) {
      this.mCameraCaptureSessionStateCallback.onActive(param1SynchronizedCaptureSession.toCameraCaptureSessionCompat().toCameraCaptureSession());
    }
    
    @RequiresApi(api = 26)
    public void onCaptureQueueEmpty(@NonNull SynchronizedCaptureSession param1SynchronizedCaptureSession) {
      ApiCompat.Api26Impl.onCaptureQueueEmpty(this.mCameraCaptureSessionStateCallback, param1SynchronizedCaptureSession.toCameraCaptureSessionCompat().toCameraCaptureSession());
    }
    
    public void onClosed(@NonNull SynchronizedCaptureSession param1SynchronizedCaptureSession) {
      this.mCameraCaptureSessionStateCallback.onClosed(param1SynchronizedCaptureSession.toCameraCaptureSessionCompat().toCameraCaptureSession());
    }
    
    public void onConfigureFailed(@NonNull SynchronizedCaptureSession param1SynchronizedCaptureSession) {
      this.mCameraCaptureSessionStateCallback.onConfigureFailed(param1SynchronizedCaptureSession.toCameraCaptureSessionCompat().toCameraCaptureSession());
    }
    
    public void onConfigured(@NonNull SynchronizedCaptureSession param1SynchronizedCaptureSession) {
      this.mCameraCaptureSessionStateCallback.onConfigured(param1SynchronizedCaptureSession.toCameraCaptureSessionCompat().toCameraCaptureSession());
    }
    
    public void onReady(@NonNull SynchronizedCaptureSession param1SynchronizedCaptureSession) {
      this.mCameraCaptureSessionStateCallback.onReady(param1SynchronizedCaptureSession.toCameraCaptureSessionCompat().toCameraCaptureSession());
    }
    
    void onSessionFinished(@NonNull SynchronizedCaptureSession param1SynchronizedCaptureSession) {}
    
    @RequiresApi(api = 23)
    public void onSurfacePrepared(@NonNull SynchronizedCaptureSession param1SynchronizedCaptureSession, @NonNull Surface param1Surface) {
      ApiCompat.Api23Impl.onSurfacePrepared(this.mCameraCaptureSessionStateCallback, param1SynchronizedCaptureSession.toCameraCaptureSessionCompat().toCameraCaptureSession(), param1Surface);
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\MagicAI - AI Art & Anime Art-dex2jar.jar!\androidx\camera\camera2\internal\SynchronizedCaptureSessionStateCallbacks.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */