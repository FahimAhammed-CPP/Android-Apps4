package androidx.camera.camera2.internal;

import android.graphics.Rect;
import android.hardware.camera2.CameraCaptureSession;
import android.hardware.camera2.CameraCharacteristics;
import android.hardware.camera2.CaptureRequest;
import android.hardware.camera2.TotalCaptureResult;
import android.os.Build;
import android.util.ArrayMap;
import android.util.Rational;
import androidx.annotation.GuardedBy;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.annotation.OptIn;
import androidx.annotation.RequiresApi;
import androidx.annotation.VisibleForTesting;
import androidx.camera.camera2.impl.Camera2ImplConfig;
import androidx.camera.camera2.internal.compat.CameraCharacteristicsCompat;
import androidx.camera.camera2.internal.compat.workaround.AeFpsRange;
import androidx.camera.camera2.internal.compat.workaround.AutoFlashAEModeDisabler;
import androidx.camera.camera2.interop.Camera2CameraControl;
import androidx.camera.camera2.interop.CaptureRequestOptions;
import androidx.camera.camera2.interop.ExperimentalCamera2Interop;
import androidx.camera.core.CameraControl;
import androidx.camera.core.FocusMeteringAction;
import androidx.camera.core.FocusMeteringResult;
import androidx.camera.core.Logger;
import androidx.camera.core.impl.CameraCaptureCallback;
import androidx.camera.core.impl.CameraCaptureFailure;
import androidx.camera.core.impl.CameraCaptureResult;
import androidx.camera.core.impl.CameraControlInternal;
import androidx.camera.core.impl.CaptureConfig;
import androidx.camera.core.impl.Config;
import androidx.camera.core.impl.Quirks;
import androidx.camera.core.impl.SessionConfig;
import androidx.camera.core.impl.TagBundle;
import androidx.camera.core.impl.utils.executor.CameraXExecutors;
import androidx.camera.core.impl.utils.futures.AsyncFunction;
import androidx.camera.core.impl.utils.futures.FutureChain;
import androidx.camera.core.impl.utils.futures.Futures;
import androidx.concurrent.futures.CallbackToFutureAdapter;
import androidx.core.util.Preconditions;
import com.google.common.util.concurrent.ListenableFuture;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.concurrent.Executor;
import java.util.concurrent.RejectedExecutionException;
import java.util.concurrent.ScheduledExecutorService;
import java.util.concurrent.atomic.AtomicLong;

@OptIn(markerClass = {ExperimentalCamera2Interop.class})
@RequiresApi(21)
public class Camera2CameraControlImpl implements CameraControlInternal {
  private static final int DEFAULT_TEMPLATE = 1;
  
  private static final String TAG = "Camera2CameraControlImp";
  
  static final String TAG_SESSION_UPDATE_ID = "CameraControlSessionUpdateId";
  
  private final AeFpsRange mAeFpsRange;
  
  private final AutoFlashAEModeDisabler mAutoFlashAEModeDisabler;
  
  private final Camera2CameraControl mCamera2CameraControl;
  
  private final Camera2CapturePipeline mCamera2CapturePipeline;
  
  private final CameraCaptureCallbackSet mCameraCaptureCallbackSet;
  
  private final CameraCharacteristicsCompat mCameraCharacteristics;
  
  private final CameraControlInternal.ControlUpdateCallback mControlUpdateCallback;
  
  private long mCurrentSessionUpdateId;
  
  final Executor mExecutor;
  
  private final ExposureControl mExposureControl;
  
  private volatile int mFlashMode;
  
  @NonNull
  private volatile ListenableFuture<Void> mFlashModeChangeSessionUpdateFuture;
  
  private final FocusMeteringControl mFocusMeteringControl;
  
  private volatile boolean mIsTorchOn;
  
  private final Object mLock = new Object();
  
  private final AtomicLong mNextSessionUpdateId;
  
  @VisibleForTesting
  final CameraControlSessionCallback mSessionCallback;
  
  private final SessionConfig.Builder mSessionConfigBuilder;
  
  private int mTemplate;
  
  private final TorchControl mTorchControl;
  
  @GuardedBy("mLock")
  private int mUseCount;
  
  private final ZoomControl mZoomControl;
  
  @VisibleForTesting
  ZslControl mZslControl;
  
  @VisibleForTesting
  Camera2CameraControlImpl(@NonNull CameraCharacteristicsCompat paramCameraCharacteristicsCompat, @NonNull ScheduledExecutorService paramScheduledExecutorService, @NonNull Executor paramExecutor, @NonNull CameraControlInternal.ControlUpdateCallback paramControlUpdateCallback) {
    this(paramCameraCharacteristicsCompat, paramScheduledExecutorService, paramExecutor, paramControlUpdateCallback, new Quirks(new ArrayList()));
  }
  
  Camera2CameraControlImpl(@NonNull CameraCharacteristicsCompat paramCameraCharacteristicsCompat, @NonNull ScheduledExecutorService paramScheduledExecutorService, @NonNull Executor paramExecutor, @NonNull CameraControlInternal.ControlUpdateCallback paramControlUpdateCallback, @NonNull Quirks paramQuirks) {
    SessionConfig.Builder builder = new SessionConfig.Builder();
    this.mSessionConfigBuilder = builder;
    this.mUseCount = 0;
    this.mIsTorchOn = false;
    this.mFlashMode = 2;
    this.mNextSessionUpdateId = new AtomicLong(0L);
    this.mFlashModeChangeSessionUpdateFuture = Futures.immediateFuture(null);
    this.mTemplate = 1;
    this.mCurrentSessionUpdateId = 0L;
    CameraCaptureCallbackSet cameraCaptureCallbackSet = new CameraCaptureCallbackSet();
    this.mCameraCaptureCallbackSet = cameraCaptureCallbackSet;
    this.mCameraCharacteristics = paramCameraCharacteristicsCompat;
    this.mControlUpdateCallback = paramControlUpdateCallback;
    this.mExecutor = paramExecutor;
    CameraControlSessionCallback cameraControlSessionCallback = new CameraControlSessionCallback(paramExecutor);
    this.mSessionCallback = cameraControlSessionCallback;
    builder.setTemplateType(this.mTemplate);
    builder.addRepeatingCameraCaptureCallback((CameraCaptureCallback)CaptureCallbackContainer.create(cameraControlSessionCallback));
    builder.addRepeatingCameraCaptureCallback(cameraCaptureCallbackSet);
    this.mExposureControl = new ExposureControl(this, paramCameraCharacteristicsCompat, paramExecutor);
    this.mFocusMeteringControl = new FocusMeteringControl(this, paramScheduledExecutorService, paramExecutor, paramQuirks);
    this.mZoomControl = new ZoomControl(this, paramCameraCharacteristicsCompat, paramExecutor);
    this.mTorchControl = new TorchControl(this, paramCameraCharacteristicsCompat, paramExecutor);
    if (Build.VERSION.SDK_INT >= 23) {
      this.mZslControl = (ZslControl)new ZslControlImpl(paramCameraCharacteristicsCompat);
    } else {
      this.mZslControl = (ZslControl)new ZslControlNoOpImpl();
    } 
    this.mAeFpsRange = new AeFpsRange(paramQuirks);
    this.mAutoFlashAEModeDisabler = new AutoFlashAEModeDisabler(paramQuirks);
    this.mCamera2CameraControl = new Camera2CameraControl(this, paramExecutor);
    this.mCamera2CapturePipeline = new Camera2CapturePipeline(this, paramCameraCharacteristicsCompat, paramQuirks, paramExecutor);
    paramExecutor.execute((Runnable)new Camera2CameraControlImpl$.ExternalSyntheticLambda9(this));
  }
  
  private int getSupportedAwbMode(int paramInt) {
    int[] arrayOfInt = (int[])this.mCameraCharacteristics.get(CameraCharacteristics.CONTROL_AWB_AVAILABLE_MODES);
    return (arrayOfInt == null) ? 0 : (isModeInList(paramInt, arrayOfInt) ? paramInt : (isModeInList(1, arrayOfInt) ? 1 : 0));
  }
  
  private boolean isControlInUse() {
    return (getUseCount() > 0);
  }
  
  private boolean isModeInList(int paramInt, int[] paramArrayOfint) {
    int j = paramArrayOfint.length;
    for (int i = 0; i < j; i++) {
      if (paramInt == paramArrayOfint[i])
        return true; 
    } 
    return false;
  }
  
  static boolean isSessionUpdated(@NonNull TotalCaptureResult paramTotalCaptureResult, long paramLong) {
    if (paramTotalCaptureResult.getRequest() == null)
      return false; 
    Object object = paramTotalCaptureResult.getRequest().getTag();
    if (object instanceof TagBundle) {
      object = ((TagBundle)object).getTag("CameraControlSessionUpdateId");
      if (object == null)
        return false; 
      if (object.longValue() >= paramLong)
        return true; 
    } 
    return false;
  }
  
  @NonNull
  private ListenableFuture<Void> waitForSessionUpdateId(long paramLong) {
    return CallbackToFutureAdapter.getFuture((CallbackToFutureAdapter.Resolver)new Camera2CameraControlImpl$.ExternalSyntheticLambda5(this, paramLong));
  }
  
  void addCaptureResultListener(@NonNull CaptureResultListener paramCaptureResultListener) {
    this.mSessionCallback.addListener(paramCaptureResultListener);
  }
  
  public void addInteropConfig(@NonNull Config paramConfig) {
    this.mCamera2CameraControl.addCaptureRequestOptions(CaptureRequestOptions.Builder.from(paramConfig).build()).addListener((Runnable)new Camera2CameraControlImpl$.ExternalSyntheticLambda10(), CameraXExecutors.directExecutor());
  }
  
  void addSessionCameraCaptureCallback(@NonNull Executor paramExecutor, @NonNull CameraCaptureCallback paramCameraCaptureCallback) {
    this.mExecutor.execute((Runnable)new Camera2CameraControlImpl$.ExternalSyntheticLambda4(this, paramExecutor, paramCameraCaptureCallback));
  }
  
  public void addZslConfig(@NonNull SessionConfig.Builder paramBuilder) {
    this.mZslControl.addZslConfig(paramBuilder);
  }
  
  @NonNull
  public ListenableFuture<Void> cancelFocusAndMetering() {
    return !isControlInUse() ? Futures.immediateFailedFuture((Throwable)new CameraControl.OperationCanceledException("Camera is not active.")) : Futures.nonCancellationPropagating(this.mFocusMeteringControl.cancelFocusAndMetering());
  }
  
  public void clearInteropConfig() {
    this.mCamera2CameraControl.clearCaptureRequestOptions().addListener((Runnable)new Camera2CameraControlImpl$.ExternalSyntheticLambda3(), CameraXExecutors.directExecutor());
  }
  
  void decrementUseCount() {
    synchronized (this.mLock) {
      int i = this.mUseCount;
      if (i != 0) {
        this.mUseCount = i - 1;
        return;
      } 
      throw new IllegalStateException("Decrementing use count occurs more times than incrementing");
    } 
  }
  
  @NonNull
  public ListenableFuture<Void> enableTorch(boolean paramBoolean) {
    return !isControlInUse() ? Futures.immediateFailedFuture((Throwable)new CameraControl.OperationCanceledException("Camera is not active.")) : Futures.nonCancellationPropagating(this.mTorchControl.enableTorch(paramBoolean));
  }
  
  void enableTorchInternal(boolean paramBoolean) {
    this.mIsTorchOn = paramBoolean;
    if (!paramBoolean) {
      CaptureConfig.Builder builder = new CaptureConfig.Builder();
      builder.setTemplateType(this.mTemplate);
      builder.setUseRepeatingSurface(true);
      Camera2ImplConfig.Builder builder1 = new Camera2ImplConfig.Builder();
      builder1.setCaptureRequestOption(CaptureRequest.CONTROL_AE_MODE, Integer.valueOf(getSupportedAeMode(1)));
      builder1.setCaptureRequestOption(CaptureRequest.FLASH_MODE, Integer.valueOf(0));
      builder.addImplementationOptions((Config)builder1.build());
      submitCaptureRequestsInternal(Collections.singletonList(builder.build()));
    } 
    updateSessionConfigSynchronous();
  }
  
  @NonNull
  public Camera2CameraControl getCamera2CameraControl() {
    return this.mCamera2CameraControl;
  }
  
  @NonNull
  Rect getCropSensorRegion() {
    return this.mZoomControl.getCropSensorRegion();
  }
  
  @VisibleForTesting
  long getCurrentSessionUpdateId() {
    return this.mCurrentSessionUpdateId;
  }
  
  @NonNull
  public ExposureControl getExposureControl() {
    return this.mExposureControl;
  }
  
  public int getFlashMode() {
    return this.mFlashMode;
  }
  
  @NonNull
  public FocusMeteringControl getFocusMeteringControl() {
    return this.mFocusMeteringControl;
  }
  
  @NonNull
  public Config getInteropConfig() {
    return (Config)this.mCamera2CameraControl.getCamera2ImplConfig();
  }
  
  int getMaxAeRegionCount() {
    Integer integer = (Integer)this.mCameraCharacteristics.get(CameraCharacteristics.CONTROL_MAX_REGIONS_AE);
    return (integer == null) ? 0 : integer.intValue();
  }
  
  int getMaxAfRegionCount() {
    Integer integer = (Integer)this.mCameraCharacteristics.get(CameraCharacteristics.CONTROL_MAX_REGIONS_AF);
    return (integer == null) ? 0 : integer.intValue();
  }
  
  int getMaxAwbRegionCount() {
    Integer integer = (Integer)this.mCameraCharacteristics.get(CameraCharacteristics.CONTROL_MAX_REGIONS_AWB);
    return (integer == null) ? 0 : integer.intValue();
  }
  
  @NonNull
  public Rect getSensorRect() {
    return (Rect)Preconditions.checkNotNull(this.mCameraCharacteristics.get(CameraCharacteristics.SENSOR_INFO_ACTIVE_ARRAY_SIZE));
  }
  
  @NonNull
  public SessionConfig getSessionConfig() {
    this.mSessionConfigBuilder.setTemplateType(this.mTemplate);
    this.mSessionConfigBuilder.setImplementationOptions(getSessionOptions());
    Object object = this.mCamera2CameraControl.getCamera2ImplConfig().getCaptureRequestTag(null);
    if (object != null && object instanceof Integer)
      this.mSessionConfigBuilder.addTag("Camera2CameraControl", object); 
    this.mSessionConfigBuilder.addTag("CameraControlSessionUpdateId", Long.valueOf(this.mCurrentSessionUpdateId));
    return this.mSessionConfigBuilder.build();
  }
  
  @VisibleForTesting
  Config getSessionOptions() {
    // Byte code:
    //   0: new androidx/camera/camera2/impl/Camera2ImplConfig$Builder
    //   3: dup
    //   4: invokespecial <init> : ()V
    //   7: astore_2
    //   8: aload_2
    //   9: getstatic android/hardware/camera2/CaptureRequest.CONTROL_MODE : Landroid/hardware/camera2/CaptureRequest$Key;
    //   12: iconst_1
    //   13: invokestatic valueOf : (I)Ljava/lang/Integer;
    //   16: invokevirtual setCaptureRequestOption : (Landroid/hardware/camera2/CaptureRequest$Key;Ljava/lang/Object;)Landroidx/camera/camera2/impl/Camera2ImplConfig$Builder;
    //   19: pop
    //   20: aload_0
    //   21: getfield mFocusMeteringControl : Landroidx/camera/camera2/internal/FocusMeteringControl;
    //   24: aload_2
    //   25: invokevirtual addFocusMeteringOptions : (Landroidx/camera/camera2/impl/Camera2ImplConfig$Builder;)V
    //   28: aload_0
    //   29: getfield mAeFpsRange : Landroidx/camera/camera2/internal/compat/workaround/AeFpsRange;
    //   32: aload_2
    //   33: invokevirtual addAeFpsRangeOptions : (Landroidx/camera/camera2/impl/Camera2ImplConfig$Builder;)V
    //   36: aload_0
    //   37: getfield mZoomControl : Landroidx/camera/camera2/internal/ZoomControl;
    //   40: aload_2
    //   41: invokevirtual addZoomOption : (Landroidx/camera/camera2/impl/Camera2ImplConfig$Builder;)V
    //   44: aload_0
    //   45: getfield mIsTorchOn : Z
    //   48: ifeq -> 66
    //   51: aload_2
    //   52: getstatic android/hardware/camera2/CaptureRequest.FLASH_MODE : Landroid/hardware/camera2/CaptureRequest$Key;
    //   55: iconst_2
    //   56: invokestatic valueOf : (I)Ljava/lang/Integer;
    //   59: invokevirtual setCaptureRequestOption : (Landroid/hardware/camera2/CaptureRequest$Key;Ljava/lang/Object;)Landroidx/camera/camera2/impl/Camera2ImplConfig$Builder;
    //   62: pop
    //   63: goto -> 80
    //   66: aload_0
    //   67: getfield mFlashMode : I
    //   70: istore_1
    //   71: iload_1
    //   72: ifeq -> 90
    //   75: iload_1
    //   76: iconst_1
    //   77: if_icmpeq -> 85
    //   80: iconst_1
    //   81: istore_1
    //   82: goto -> 99
    //   85: iconst_3
    //   86: istore_1
    //   87: goto -> 99
    //   90: aload_0
    //   91: getfield mAutoFlashAEModeDisabler : Landroidx/camera/camera2/internal/compat/workaround/AutoFlashAEModeDisabler;
    //   94: iconst_2
    //   95: invokevirtual getCorrectedAeMode : (I)I
    //   98: istore_1
    //   99: aload_2
    //   100: getstatic android/hardware/camera2/CaptureRequest.CONTROL_AE_MODE : Landroid/hardware/camera2/CaptureRequest$Key;
    //   103: aload_0
    //   104: iload_1
    //   105: invokevirtual getSupportedAeMode : (I)I
    //   108: invokestatic valueOf : (I)Ljava/lang/Integer;
    //   111: invokevirtual setCaptureRequestOption : (Landroid/hardware/camera2/CaptureRequest$Key;Ljava/lang/Object;)Landroidx/camera/camera2/impl/Camera2ImplConfig$Builder;
    //   114: pop
    //   115: aload_2
    //   116: getstatic android/hardware/camera2/CaptureRequest.CONTROL_AWB_MODE : Landroid/hardware/camera2/CaptureRequest$Key;
    //   119: aload_0
    //   120: iconst_1
    //   121: invokespecial getSupportedAwbMode : (I)I
    //   124: invokestatic valueOf : (I)Ljava/lang/Integer;
    //   127: invokevirtual setCaptureRequestOption : (Landroid/hardware/camera2/CaptureRequest$Key;Ljava/lang/Object;)Landroidx/camera/camera2/impl/Camera2ImplConfig$Builder;
    //   130: pop
    //   131: aload_0
    //   132: getfield mExposureControl : Landroidx/camera/camera2/internal/ExposureControl;
    //   135: aload_2
    //   136: invokevirtual setCaptureRequestOption : (Landroidx/camera/camera2/impl/Camera2ImplConfig$Builder;)V
    //   139: aload_0
    //   140: getfield mCamera2CameraControl : Landroidx/camera/camera2/interop/Camera2CameraControl;
    //   143: invokevirtual getCamera2ImplConfig : ()Landroidx/camera/camera2/impl/Camera2ImplConfig;
    //   146: astore_3
    //   147: aload_3
    //   148: invokeinterface listOptions : ()Ljava/util/Set;
    //   153: invokeinterface iterator : ()Ljava/util/Iterator;
    //   158: astore #4
    //   160: aload #4
    //   162: invokeinterface hasNext : ()Z
    //   167: ifeq -> 207
    //   170: aload #4
    //   172: invokeinterface next : ()Ljava/lang/Object;
    //   177: checkcast androidx/camera/core/impl/Config$Option
    //   180: astore #5
    //   182: aload_2
    //   183: invokevirtual getMutableConfig : ()Landroidx/camera/core/impl/MutableConfig;
    //   186: aload #5
    //   188: getstatic androidx/camera/core/impl/Config$OptionPriority.ALWAYS_OVERRIDE : Landroidx/camera/core/impl/Config$OptionPriority;
    //   191: aload_3
    //   192: aload #5
    //   194: invokeinterface retrieveOption : (Landroidx/camera/core/impl/Config$Option;)Ljava/lang/Object;
    //   199: invokeinterface insertOption : (Landroidx/camera/core/impl/Config$Option;Landroidx/camera/core/impl/Config$OptionPriority;Ljava/lang/Object;)V
    //   204: goto -> 160
    //   207: aload_2
    //   208: invokevirtual build : ()Landroidx/camera/camera2/impl/Camera2ImplConfig;
    //   211: areturn
  }
  
  int getSupportedAeMode(int paramInt) {
    int[] arrayOfInt = (int[])this.mCameraCharacteristics.get(CameraCharacteristics.CONTROL_AE_AVAILABLE_MODES);
    return (arrayOfInt == null) ? 0 : (isModeInList(paramInt, arrayOfInt) ? paramInt : (isModeInList(1, arrayOfInt) ? 1 : 0));
  }
  
  int getSupportedAfMode(int paramInt) {
    int[] arrayOfInt = (int[])this.mCameraCharacteristics.get(CameraCharacteristics.CONTROL_AF_AVAILABLE_MODES);
    return (arrayOfInt == null) ? 0 : (isModeInList(paramInt, arrayOfInt) ? paramInt : (isModeInList(4, arrayOfInt) ? 4 : (isModeInList(1, arrayOfInt) ? 1 : 0)));
  }
  
  @NonNull
  public TorchControl getTorchControl() {
    return this.mTorchControl;
  }
  
  @VisibleForTesting
  int getUseCount() {
    synchronized (this.mLock) {
      return this.mUseCount;
    } 
  }
  
  @NonNull
  public ZoomControl getZoomControl() {
    return this.mZoomControl;
  }
  
  @NonNull
  public ZslControl getZslControl() {
    return this.mZslControl;
  }
  
  void incrementUseCount() {
    synchronized (this.mLock) {
      this.mUseCount++;
      return;
    } 
  }
  
  boolean isTorchOn() {
    return this.mIsTorchOn;
  }
  
  public boolean isZslDisabledByByUserCaseConfig() {
    return this.mZslControl.isZslDisabledByUserCaseConfig();
  }
  
  void removeCaptureResultListener(@NonNull CaptureResultListener paramCaptureResultListener) {
    this.mSessionCallback.removeListener(paramCaptureResultListener);
  }
  
  void removeSessionCameraCaptureCallback(@NonNull CameraCaptureCallback paramCameraCaptureCallback) {
    this.mExecutor.execute((Runnable)new Camera2CameraControlImpl$.ExternalSyntheticLambda0(this, paramCameraCaptureCallback));
  }
  
  void resetTemplate() {
    setTemplate(1);
  }
  
  void setActive(boolean paramBoolean) {
    this.mFocusMeteringControl.setActive(paramBoolean);
    this.mZoomControl.setActive(paramBoolean);
    this.mTorchControl.setActive(paramBoolean);
    this.mExposureControl.setActive(paramBoolean);
    this.mCamera2CameraControl.setActive(paramBoolean);
  }
  
  @NonNull
  public ListenableFuture<Integer> setExposureCompensationIndex(int paramInt) {
    return !isControlInUse() ? Futures.immediateFailedFuture((Throwable)new CameraControl.OperationCanceledException("Camera is not active.")) : this.mExposureControl.setExposureCompensationIndex(paramInt);
  }
  
  public void setFlashMode(int paramInt) {
    if (!isControlInUse()) {
      Logger.w("Camera2CameraControlImp", "Camera is not active.");
      return;
    } 
    this.mFlashMode = paramInt;
    ZslControl zslControl = this.mZslControl;
    paramInt = this.mFlashMode;
    boolean bool2 = true;
    boolean bool1 = bool2;
    if (paramInt != 1)
      if (this.mFlashMode == 0) {
        bool1 = bool2;
      } else {
        bool1 = false;
      }  
    zslControl.setZslDisabledByFlashMode(bool1);
    this.mFlashModeChangeSessionUpdateFuture = updateSessionConfigAsync();
  }
  
  @NonNull
  public ListenableFuture<Void> setLinearZoom(float paramFloat) {
    return !isControlInUse() ? Futures.immediateFailedFuture((Throwable)new CameraControl.OperationCanceledException("Camera is not active.")) : Futures.nonCancellationPropagating(this.mZoomControl.setLinearZoom(paramFloat));
  }
  
  public void setPreviewAspectRatio(@Nullable Rational paramRational) {
    this.mFocusMeteringControl.setPreviewAspectRatio(paramRational);
  }
  
  void setTemplate(int paramInt) {
    this.mTemplate = paramInt;
    this.mFocusMeteringControl.setTemplate(paramInt);
    this.mCamera2CapturePipeline.setTemplate(this.mTemplate);
  }
  
  @NonNull
  public ListenableFuture<Void> setZoomRatio(float paramFloat) {
    return !isControlInUse() ? Futures.immediateFailedFuture((Throwable)new CameraControl.OperationCanceledException("Camera is not active.")) : Futures.nonCancellationPropagating(this.mZoomControl.setZoomRatio(paramFloat));
  }
  
  public void setZslDisabledByUserCaseConfig(boolean paramBoolean) {
    this.mZslControl.setZslDisabledByUserCaseConfig(paramBoolean);
  }
  
  @NonNull
  public ListenableFuture<FocusMeteringResult> startFocusAndMetering(@NonNull FocusMeteringAction paramFocusMeteringAction) {
    return !isControlInUse() ? Futures.immediateFailedFuture((Throwable)new CameraControl.OperationCanceledException("Camera is not active.")) : Futures.nonCancellationPropagating(this.mFocusMeteringControl.startFocusAndMetering(paramFocusMeteringAction));
  }
  
  void submitCaptureRequestsInternal(List<CaptureConfig> paramList) {
    this.mControlUpdateCallback.onCameraControlCaptureRequests(paramList);
  }
  
  @NonNull
  public ListenableFuture<List<Void>> submitStillCaptureRequests(@NonNull List<CaptureConfig> paramList, int paramInt1, int paramInt2) {
    if (!isControlInUse()) {
      Logger.w("Camera2CameraControlImp", "Camera is not active.");
      return Futures.immediateFailedFuture((Throwable)new CameraControl.OperationCanceledException("Camera is not active."));
    } 
    int i = getFlashMode();
    return (ListenableFuture<List<Void>>)FutureChain.from(Futures.nonCancellationPropagating(this.mFlashModeChangeSessionUpdateFuture)).transformAsync((AsyncFunction)new Camera2CameraControlImpl$.ExternalSyntheticLambda7(this, paramList, paramInt1, i, paramInt2), this.mExecutor);
  }
  
  public void updateSessionConfig() {
    this.mExecutor.execute((Runnable)new Camera2CameraControlImpl$.ExternalSyntheticLambda1(this));
  }
  
  @NonNull
  ListenableFuture<Void> updateSessionConfigAsync() {
    return Futures.nonCancellationPropagating(CallbackToFutureAdapter.getFuture((CallbackToFutureAdapter.Resolver)new Camera2CameraControlImpl$.ExternalSyntheticLambda2(this)));
  }
  
  long updateSessionConfigSynchronous() {
    this.mCurrentSessionUpdateId = this.mNextSessionUpdateId.getAndIncrement();
    this.mControlUpdateCallback.onCameraControlUpdateSessionConfig();
    return this.mCurrentSessionUpdateId;
  }
  
  @RequiresApi(21)
  static final class CameraCaptureCallbackSet extends CameraCaptureCallback {
    Map<CameraCaptureCallback, Executor> mCallbackExecutors = (Map<CameraCaptureCallback, Executor>)new ArrayMap();
    
    Set<CameraCaptureCallback> mCallbacks = new HashSet<CameraCaptureCallback>();
    
    void addCaptureCallback(@NonNull Executor param1Executor, @NonNull CameraCaptureCallback param1CameraCaptureCallback) {
      this.mCallbacks.add(param1CameraCaptureCallback);
      this.mCallbackExecutors.put(param1CameraCaptureCallback, param1Executor);
    }
    
    public void onCaptureCancelled() {
      for (CameraCaptureCallback cameraCaptureCallback : this.mCallbacks) {
        try {
          ((Executor)this.mCallbackExecutors.get(cameraCaptureCallback)).execute(new Camera2CameraControlImpl$CameraCaptureCallbackSet$$ExternalSyntheticLambda1(cameraCaptureCallback));
        } catch (RejectedExecutionException rejectedExecutionException) {
          Logger.e("Camera2CameraControlImp", "Executor rejected to invoke onCaptureCancelled.", rejectedExecutionException);
        } 
      } 
    }
    
    public void onCaptureCompleted(@NonNull CameraCaptureResult param1CameraCaptureResult) {
      for (CameraCaptureCallback cameraCaptureCallback : this.mCallbacks) {
        try {
          ((Executor)this.mCallbackExecutors.get(cameraCaptureCallback)).execute(new Camera2CameraControlImpl$CameraCaptureCallbackSet$$ExternalSyntheticLambda2(cameraCaptureCallback, param1CameraCaptureResult));
        } catch (RejectedExecutionException rejectedExecutionException) {
          Logger.e("Camera2CameraControlImp", "Executor rejected to invoke onCaptureCompleted.", rejectedExecutionException);
        } 
      } 
    }
    
    public void onCaptureFailed(@NonNull CameraCaptureFailure param1CameraCaptureFailure) {
      for (CameraCaptureCallback cameraCaptureCallback : this.mCallbacks) {
        try {
          ((Executor)this.mCallbackExecutors.get(cameraCaptureCallback)).execute(new Camera2CameraControlImpl$CameraCaptureCallbackSet$$ExternalSyntheticLambda0(cameraCaptureCallback, param1CameraCaptureFailure));
        } catch (RejectedExecutionException rejectedExecutionException) {
          Logger.e("Camera2CameraControlImp", "Executor rejected to invoke onCaptureFailed.", rejectedExecutionException);
        } 
      } 
    }
    
    void removeCaptureCallback(@NonNull CameraCaptureCallback param1CameraCaptureCallback) {
      this.mCallbacks.remove(param1CameraCaptureCallback);
      this.mCallbackExecutors.remove(param1CameraCaptureCallback);
    }
  }
  
  static final class CameraControlSessionCallback extends CameraCaptureSession.CaptureCallback {
    private final Executor mExecutor;
    
    final Set<Camera2CameraControlImpl.CaptureResultListener> mResultListeners = new HashSet<Camera2CameraControlImpl.CaptureResultListener>();
    
    CameraControlSessionCallback(@NonNull Executor param1Executor) {
      this.mExecutor = param1Executor;
    }
    
    void addListener(@NonNull Camera2CameraControlImpl.CaptureResultListener param1CaptureResultListener) {
      this.mResultListeners.add(param1CaptureResultListener);
    }
    
    public void onCaptureCompleted(@NonNull CameraCaptureSession param1CameraCaptureSession, @NonNull CaptureRequest param1CaptureRequest, @NonNull TotalCaptureResult param1TotalCaptureResult) {
      this.mExecutor.execute((Runnable)new Camera2CameraControlImpl$CameraControlSessionCallback$.ExternalSyntheticLambda0(this, param1TotalCaptureResult));
    }
    
    void removeListener(@NonNull Camera2CameraControlImpl.CaptureResultListener param1CaptureResultListener) {
      this.mResultListeners.remove(param1CaptureResultListener);
    }
  }
  
  public static interface CaptureResultListener {
    boolean onCaptureResult(@NonNull TotalCaptureResult param1TotalCaptureResult);
  }
}


/* Location:              C:\soft\dex2jar-2.0\MagicAI - AI Art & Anime Art-dex2jar.jar!\androidx\camera\camera2\internal\Camera2CameraControlImpl.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */