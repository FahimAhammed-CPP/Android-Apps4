package androidx.camera.camera2.internal;

import android.hardware.camera2.CameraDevice;
import androidx.annotation.NonNull;
import androidx.annotation.RequiresApi;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Iterator;
import java.util.List;

@RequiresApi(21)
public final class CameraDeviceStateCallbacks {
  @NonNull
  public static CameraDevice.StateCallback createComboCallback(@NonNull List<CameraDevice.StateCallback> paramList) {
    return paramList.isEmpty() ? createNoOpCallback() : ((paramList.size() == 1) ? paramList.get(0) : new ComboDeviceStateCallback(paramList));
  }
  
  @NonNull
  public static CameraDevice.StateCallback createComboCallback(@NonNull CameraDevice.StateCallback... paramVarArgs) {
    return createComboCallback(Arrays.asList(paramVarArgs));
  }
  
  @NonNull
  public static CameraDevice.StateCallback createNoOpCallback() {
    return new NoOpDeviceStateCallback();
  }
  
  private static final class ComboDeviceStateCallback extends CameraDevice.StateCallback {
    private final List<CameraDevice.StateCallback> mCallbacks = new ArrayList<CameraDevice.StateCallback>();
    
    ComboDeviceStateCallback(@NonNull List<CameraDevice.StateCallback> param1List) {
      for (CameraDevice.StateCallback stateCallback : param1List) {
        if (!(stateCallback instanceof CameraDeviceStateCallbacks.NoOpDeviceStateCallback))
          this.mCallbacks.add(stateCallback); 
      } 
    }
    
    public void onClosed(@NonNull CameraDevice param1CameraDevice) {
      Iterator<CameraDevice.StateCallback> iterator = this.mCallbacks.iterator();
      while (iterator.hasNext())
        ((CameraDevice.StateCallback)iterator.next()).onClosed(param1CameraDevice); 
    }
    
    public void onDisconnected(@NonNull CameraDevice param1CameraDevice) {
      Iterator<CameraDevice.StateCallback> iterator = this.mCallbacks.iterator();
      while (iterator.hasNext())
        ((CameraDevice.StateCallback)iterator.next()).onDisconnected(param1CameraDevice); 
    }
    
    public void onError(@NonNull CameraDevice param1CameraDevice, int param1Int) {
      Iterator<CameraDevice.StateCallback> iterator = this.mCallbacks.iterator();
      while (iterator.hasNext())
        ((CameraDevice.StateCallback)iterator.next()).onError(param1CameraDevice, param1Int); 
    }
    
    public void onOpened(@NonNull CameraDevice param1CameraDevice) {
      Iterator<CameraDevice.StateCallback> iterator = this.mCallbacks.iterator();
      while (iterator.hasNext())
        ((CameraDevice.StateCallback)iterator.next()).onOpened(param1CameraDevice); 
    }
  }
  
  static final class NoOpDeviceStateCallback extends CameraDevice.StateCallback {
    public void onClosed(@NonNull CameraDevice param1CameraDevice) {}
    
    public void onDisconnected(@NonNull CameraDevice param1CameraDevice) {}
    
    public void onError(@NonNull CameraDevice param1CameraDevice, int param1Int) {}
    
    public void onOpened(@NonNull CameraDevice param1CameraDevice) {}
  }
}


/* Location:              C:\soft\dex2jar-2.0\MagicAI - AI Art & Anime Art-dex2jar.jar!\androidx\camera\camera2\internal\CameraDeviceStateCallbacks.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */