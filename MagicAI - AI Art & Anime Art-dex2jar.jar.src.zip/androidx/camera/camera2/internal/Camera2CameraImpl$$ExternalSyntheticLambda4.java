package androidx.camera.camera2.internal;

import androidx.concurrent.futures.CallbackToFutureAdapter;



/* Location:              C:\soft\dex2jar-2.0\MagicAI - AI Art & Anime Art-dex2jar.jar!\androidx\camera\camera2\internal\Camera2CameraImpl$$ExternalSyntheticLambda4.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */