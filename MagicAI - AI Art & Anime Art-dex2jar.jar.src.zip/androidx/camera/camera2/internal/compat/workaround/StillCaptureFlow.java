package androidx.camera.camera2.internal.compat.workaround;

import android.hardware.camera2.CaptureRequest;
import androidx.annotation.NonNull;
import androidx.annotation.RequiresApi;
import androidx.camera.camera2.internal.compat.quirk.DeviceQuirks;
import androidx.camera.camera2.internal.compat.quirk.StillCaptureFlashStopRepeatingQuirk;
import java.util.Iterator;
import java.util.List;

@RequiresApi(21)
public class StillCaptureFlow {
  private final boolean mShouldStopRepeatingBeforeStillCapture;
  
  public StillCaptureFlow() {
    boolean bool;
    if ((StillCaptureFlashStopRepeatingQuirk)DeviceQuirks.get(StillCaptureFlashStopRepeatingQuirk.class) != null) {
      bool = true;
    } else {
      bool = false;
    } 
    this.mShouldStopRepeatingBeforeStillCapture = bool;
  }
  
  public boolean shouldStopRepeatingBeforeCapture(@NonNull List<CaptureRequest> paramList, boolean paramBoolean) {
    if (this.mShouldStopRepeatingBeforeStillCapture) {
      if (!paramBoolean)
        return false; 
      Iterator<CaptureRequest> iterator = paramList.iterator();
      while (iterator.hasNext()) {
        int i = ((Integer)((CaptureRequest)iterator.next()).get(CaptureRequest.CONTROL_AE_MODE)).intValue();
        if (i == 2 || i == 3)
          return true; 
      } 
    } 
    return false;
  }
}


/* Location:              C:\soft\dex2jar-2.0\MagicAI - AI Art & Anime Art-dex2jar.jar!\androidx\camera\camera2\internal\compat\workaround\StillCaptureFlow.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */