package androidx.camera.camera2.internal.compat.params;

import android.hardware.camera2.params.OutputConfiguration;
import android.os.Build;
import android.util.Size;
import android.view.Surface;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.annotation.RequiresApi;
import androidx.annotation.RestrictTo;
import androidx.camera.camera2.internal.compat.ApiCompat;
import java.util.List;

@RequiresApi(21)
public final class OutputConfigurationCompat {
  public static final int STREAM_USE_CASE_NONE = -1;
  
  public static final int SURFACE_GROUP_ID_NONE = -1;
  
  private final OutputConfigurationCompatImpl mImpl;
  
  public OutputConfigurationCompat(int paramInt, @NonNull Surface paramSurface) {
    int i = Build.VERSION.SDK_INT;
    if (i >= 33) {
      this.mImpl = (OutputConfigurationCompatImpl)new OutputConfigurationCompatApi33Impl(paramInt, paramSurface);
      return;
    } 
    if (i >= 28) {
      this.mImpl = (OutputConfigurationCompatImpl)new OutputConfigurationCompatApi28Impl(paramInt, paramSurface);
      return;
    } 
    if (i >= 26) {
      this.mImpl = (OutputConfigurationCompatImpl)new OutputConfigurationCompatApi26Impl(paramInt, paramSurface);
      return;
    } 
    if (i >= 24) {
      this.mImpl = (OutputConfigurationCompatImpl)new OutputConfigurationCompatApi24Impl(paramInt, paramSurface);
      return;
    } 
    this.mImpl = (OutputConfigurationCompatImpl)new OutputConfigurationCompatBaseImpl(paramSurface);
  }
  
  @RequiresApi(26)
  public <T> OutputConfigurationCompat(@NonNull Size paramSize, @NonNull Class<T> paramClass) {
    OutputConfiguration outputConfiguration = ApiCompat.Api26Impl.newOutputConfiguration(paramSize, paramClass);
    int i = Build.VERSION.SDK_INT;
    if (i >= 33) {
      this.mImpl = (OutputConfigurationCompatImpl)OutputConfigurationCompatApi33Impl.wrap(outputConfiguration);
      return;
    } 
    if (i >= 28) {
      this.mImpl = (OutputConfigurationCompatImpl)OutputConfigurationCompatApi28Impl.wrap(outputConfiguration);
      return;
    } 
    this.mImpl = (OutputConfigurationCompatImpl)OutputConfigurationCompatApi26Impl.wrap(outputConfiguration);
  }
  
  public OutputConfigurationCompat(@NonNull Surface paramSurface) {
    this(-1, paramSurface);
  }
  
  private OutputConfigurationCompat(@NonNull OutputConfigurationCompatImpl paramOutputConfigurationCompatImpl) {
    this.mImpl = paramOutputConfigurationCompatImpl;
  }
  
  @Nullable
  public static OutputConfigurationCompat wrap(@Nullable Object paramObject) {
    if (paramObject == null)
      return null; 
    int i = Build.VERSION.SDK_INT;
    if (i >= 33) {
      paramObject = OutputConfigurationCompatApi33Impl.wrap((OutputConfiguration)paramObject);
    } else if (i >= 28) {
      paramObject = OutputConfigurationCompatApi28Impl.wrap((OutputConfiguration)paramObject);
    } else if (i >= 26) {
      paramObject = OutputConfigurationCompatApi26Impl.wrap((OutputConfiguration)paramObject);
    } else if (i >= 24) {
      paramObject = OutputConfigurationCompatApi24Impl.wrap((OutputConfiguration)paramObject);
    } else {
      paramObject = null;
    } 
    return (paramObject == null) ? null : new OutputConfigurationCompat((OutputConfigurationCompatImpl)paramObject);
  }
  
  public void addSurface(@NonNull Surface paramSurface) {
    this.mImpl.addSurface(paramSurface);
  }
  
  public void enableSurfaceSharing() {
    this.mImpl.enableSurfaceSharing();
  }
  
  public boolean equals(Object paramObject) {
    return !(paramObject instanceof OutputConfigurationCompat) ? false : this.mImpl.equals(((OutputConfigurationCompat)paramObject).mImpl);
  }
  
  public int getMaxSharedSurfaceCount() {
    return this.mImpl.getMaxSharedSurfaceCount();
  }
  
  @Nullable
  @RestrictTo({RestrictTo.Scope.LIBRARY})
  public String getPhysicalCameraId() {
    return this.mImpl.getPhysicalCameraId();
  }
  
  public long getStreamUseCase() {
    return this.mImpl.getStreamUseCase();
  }
  
  @Nullable
  public Surface getSurface() {
    return this.mImpl.getSurface();
  }
  
  public int getSurfaceGroupId() {
    return this.mImpl.getSurfaceGroupId();
  }
  
  @NonNull
  public List<Surface> getSurfaces() {
    return this.mImpl.getSurfaces();
  }
  
  public int hashCode() {
    return this.mImpl.hashCode();
  }
  
  public void removeSurface(@NonNull Surface paramSurface) {
    this.mImpl.removeSurface(paramSurface);
  }
  
  public void setPhysicalCameraId(@Nullable String paramString) {
    this.mImpl.setPhysicalCameraId(paramString);
  }
  
  public void setStreamUseCase(long paramLong) {
    this.mImpl.setStreamUseCase(paramLong);
  }
  
  @Nullable
  public Object unwrap() {
    return this.mImpl.getOutputConfiguration();
  }
  
  static interface OutputConfigurationCompatImpl {
    void addSurface(@NonNull Surface param1Surface);
    
    void enableSurfaceSharing();
    
    int getMaxSharedSurfaceCount();
    
    @Nullable
    Object getOutputConfiguration();
    
    @Nullable
    String getPhysicalCameraId();
    
    long getStreamUseCase();
    
    @Nullable
    Surface getSurface();
    
    int getSurfaceGroupId();
    
    List<Surface> getSurfaces();
    
    void removeSurface(@NonNull Surface param1Surface);
    
    void setPhysicalCameraId(@Nullable String param1String);
    
    void setStreamUseCase(long param1Long);
  }
}


/* Location:              C:\soft\dex2jar-2.0\MagicAI - AI Art & Anime Art-dex2jar.jar!\androidx\camera\camera2\internal\compat\params\OutputConfigurationCompat.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */