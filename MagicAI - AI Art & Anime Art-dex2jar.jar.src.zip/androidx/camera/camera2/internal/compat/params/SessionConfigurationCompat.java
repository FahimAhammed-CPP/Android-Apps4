package androidx.camera.camera2.internal.compat.params;

import android.hardware.camera2.CameraCaptureSession;
import android.hardware.camera2.CaptureRequest;
import android.hardware.camera2.params.InputConfiguration;
import android.hardware.camera2.params.OutputConfiguration;
import android.hardware.camera2.params.SessionConfiguration;
import android.os.Build;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.annotation.RequiresApi;
import androidx.annotation.RestrictTo;
import j$.util.Objects;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Iterator;
import java.util.List;
import java.util.concurrent.Executor;

@RequiresApi(21)
public final class SessionConfigurationCompat {
  public static final int SESSION_HIGH_SPEED = 1;
  
  public static final int SESSION_REGULAR = 0;
  
  private final SessionConfigurationCompatImpl mImpl;
  
  public SessionConfigurationCompat(int paramInt, @NonNull List<OutputConfigurationCompat> paramList, @NonNull Executor paramExecutor, @NonNull CameraCaptureSession.StateCallback paramStateCallback) {
    if (Build.VERSION.SDK_INT < 28) {
      this.mImpl = new SessionConfigurationCompatBaseImpl(paramInt, paramList, paramExecutor, paramStateCallback);
      return;
    } 
    this.mImpl = new SessionConfigurationCompatApi28Impl(paramInt, paramList, paramExecutor, paramStateCallback);
  }
  
  private SessionConfigurationCompat(@NonNull SessionConfigurationCompatImpl paramSessionConfigurationCompatImpl) {
    this.mImpl = paramSessionConfigurationCompatImpl;
  }
  
  @NonNull
  @RequiresApi(24)
  @RestrictTo({RestrictTo.Scope.LIBRARY})
  public static List<OutputConfiguration> transformFromCompat(@NonNull List<OutputConfigurationCompat> paramList) {
    ArrayList<OutputConfiguration> arrayList = new ArrayList(paramList.size());
    Iterator<OutputConfigurationCompat> iterator = paramList.iterator();
    while (iterator.hasNext())
      arrayList.add((OutputConfiguration)((OutputConfigurationCompat)iterator.next()).unwrap()); 
    return arrayList;
  }
  
  @RequiresApi(24)
  static List<OutputConfigurationCompat> transformToCompat(@NonNull List<OutputConfiguration> paramList) {
    ArrayList<OutputConfigurationCompat> arrayList = new ArrayList(paramList.size());
    Iterator<OutputConfiguration> iterator = paramList.iterator();
    while (iterator.hasNext())
      arrayList.add(OutputConfigurationCompat.wrap(iterator.next())); 
    return arrayList;
  }
  
  @Nullable
  public static SessionConfigurationCompat wrap(@Nullable Object paramObject) {
    return (paramObject == null) ? null : ((Build.VERSION.SDK_INT < 28) ? null : new SessionConfigurationCompat(new SessionConfigurationCompatApi28Impl(paramObject)));
  }
  
  public boolean equals(@Nullable Object paramObject) {
    return !(paramObject instanceof SessionConfigurationCompat) ? false : this.mImpl.equals(((SessionConfigurationCompat)paramObject).mImpl);
  }
  
  @NonNull
  public Executor getExecutor() {
    return this.mImpl.getExecutor();
  }
  
  @Nullable
  public InputConfigurationCompat getInputConfiguration() {
    return this.mImpl.getInputConfiguration();
  }
  
  @NonNull
  public List<OutputConfigurationCompat> getOutputConfigurations() {
    return this.mImpl.getOutputConfigurations();
  }
  
  @Nullable
  public CaptureRequest getSessionParameters() {
    return this.mImpl.getSessionParameters();
  }
  
  public int getSessionType() {
    return this.mImpl.getSessionType();
  }
  
  @NonNull
  public CameraCaptureSession.StateCallback getStateCallback() {
    return this.mImpl.getStateCallback();
  }
  
  public int hashCode() {
    return this.mImpl.hashCode();
  }
  
  public void setInputConfiguration(@NonNull InputConfigurationCompat paramInputConfigurationCompat) {
    this.mImpl.setInputConfiguration(paramInputConfigurationCompat);
  }
  
  public void setSessionParameters(@NonNull CaptureRequest paramCaptureRequest) {
    this.mImpl.setSessionParameters(paramCaptureRequest);
  }
  
  @Nullable
  public Object unwrap() {
    return this.mImpl.getSessionConfiguration();
  }
  
  @RequiresApi(28)
  private static final class SessionConfigurationCompatApi28Impl implements SessionConfigurationCompatImpl {
    private final SessionConfiguration mObject;
    
    private final List<OutputConfigurationCompat> mOutputConfigurations;
    
    SessionConfigurationCompatApi28Impl(int param1Int, @NonNull List<OutputConfigurationCompat> param1List, @NonNull Executor param1Executor, @NonNull CameraCaptureSession.StateCallback param1StateCallback) {
      this(new SessionConfiguration(param1Int, SessionConfigurationCompat.transformFromCompat(param1List), param1Executor, param1StateCallback));
    }
    
    SessionConfigurationCompatApi28Impl(@NonNull Object param1Object) {
      param1Object = param1Object;
      this.mObject = (SessionConfiguration)param1Object;
      this.mOutputConfigurations = Collections.unmodifiableList(SessionConfigurationCompat.transformToCompat(SessionConfigurationCompat$SessionConfigurationCompatApi28Impl$.ExternalSyntheticApiModelOutline1.m((SessionConfiguration)param1Object)));
    }
    
    public boolean equals(@Nullable Object param1Object) {
      return !(param1Object instanceof SessionConfigurationCompatApi28Impl) ? false : Objects.equals(this.mObject, ((SessionConfigurationCompatApi28Impl)param1Object).mObject);
    }
    
    @NonNull
    public Executor getExecutor() {
      return SessionConfigurationCompat$SessionConfigurationCompatApi28Impl$.ExternalSyntheticApiModelOutline0.m(this.mObject);
    }
    
    public InputConfigurationCompat getInputConfiguration() {
      return InputConfigurationCompat.wrap(SessionConfigurationCompat$SessionConfigurationCompatApi28Impl$.ExternalSyntheticApiModelOutline3.m(this.mObject));
    }
    
    @NonNull
    public List<OutputConfigurationCompat> getOutputConfigurations() {
      return this.mOutputConfigurations;
    }
    
    @Nullable
    public Object getSessionConfiguration() {
      return this.mObject;
    }
    
    public CaptureRequest getSessionParameters() {
      return SessionConfigurationCompat$SessionConfigurationCompatApi28Impl$.ExternalSyntheticApiModelOutline7.m(this.mObject);
    }
    
    public int getSessionType() {
      return SessionConfigurationCompat$SessionConfigurationCompatApi28Impl$.ExternalSyntheticApiModelOutline6.m(this.mObject);
    }
    
    @NonNull
    public CameraCaptureSession.StateCallback getStateCallback() {
      return SessionConfigurationCompat$SessionConfigurationCompatApi28Impl$.ExternalSyntheticApiModelOutline5.m(this.mObject);
    }
    
    public int hashCode() {
      return SessionConfigurationCompat$SessionConfigurationCompatApi28Impl$.ExternalSyntheticApiModelOutline8.m(this.mObject);
    }
    
    public void setInputConfiguration(@NonNull InputConfigurationCompat param1InputConfigurationCompat) {
      SessionConfigurationCompat$SessionConfigurationCompatApi28Impl$.ExternalSyntheticApiModelOutline4.m(this.mObject, (InputConfiguration)param1InputConfigurationCompat.unwrap());
    }
    
    public void setSessionParameters(@NonNull CaptureRequest param1CaptureRequest) {
      SessionConfigurationCompat$SessionConfigurationCompatApi28Impl$.ExternalSyntheticApiModelOutline2.m(this.mObject, param1CaptureRequest);
    }
  }
  
  @RequiresApi(21)
  private static final class SessionConfigurationCompatBaseImpl implements SessionConfigurationCompatImpl {
    private final Executor mExecutor;
    
    private InputConfigurationCompat mInputConfig = null;
    
    private final List<OutputConfigurationCompat> mOutputConfigurations;
    
    private CaptureRequest mSessionParameters = null;
    
    private final int mSessionType;
    
    private final CameraCaptureSession.StateCallback mStateCallback;
    
    SessionConfigurationCompatBaseImpl(int param1Int, @NonNull List<OutputConfigurationCompat> param1List, @NonNull Executor param1Executor, @NonNull CameraCaptureSession.StateCallback param1StateCallback) {
      this.mSessionType = param1Int;
      this.mOutputConfigurations = Collections.unmodifiableList(new ArrayList<OutputConfigurationCompat>(param1List));
      this.mStateCallback = param1StateCallback;
      this.mExecutor = param1Executor;
    }
    
    public boolean equals(@Nullable Object param1Object) {
      if (this == param1Object)
        return true; 
      if (param1Object instanceof SessionConfigurationCompatBaseImpl) {
        param1Object = param1Object;
        if (Objects.equals(this.mInputConfig, ((SessionConfigurationCompatBaseImpl)param1Object).mInputConfig) && this.mSessionType == ((SessionConfigurationCompatBaseImpl)param1Object).mSessionType) {
          if (this.mOutputConfigurations.size() != ((SessionConfigurationCompatBaseImpl)param1Object).mOutputConfigurations.size())
            return false; 
          for (int i = 0; i < this.mOutputConfigurations.size(); i++) {
            if (!((OutputConfigurationCompat)this.mOutputConfigurations.get(i)).equals(((SessionConfigurationCompatBaseImpl)param1Object).mOutputConfigurations.get(i)))
              return false; 
          } 
          return true;
        } 
      } 
      return false;
    }
    
    @NonNull
    public Executor getExecutor() {
      return this.mExecutor;
    }
    
    @Nullable
    public InputConfigurationCompat getInputConfiguration() {
      return this.mInputConfig;
    }
    
    @NonNull
    public List<OutputConfigurationCompat> getOutputConfigurations() {
      return this.mOutputConfigurations;
    }
    
    @Nullable
    public Object getSessionConfiguration() {
      return null;
    }
    
    public CaptureRequest getSessionParameters() {
      return this.mSessionParameters;
    }
    
    public int getSessionType() {
      return this.mSessionType;
    }
    
    @NonNull
    public CameraCaptureSession.StateCallback getStateCallback() {
      return this.mStateCallback;
    }
    
    public int hashCode() {
      int i;
      int j = this.mOutputConfigurations.hashCode() ^ 0x1F;
      InputConfigurationCompat inputConfigurationCompat = this.mInputConfig;
      if (inputConfigurationCompat == null) {
        i = 0;
      } else {
        i = inputConfigurationCompat.hashCode();
      } 
      i ^= (j << 5) - j;
      return this.mSessionType ^ (i << 5) - i;
    }
    
    public void setInputConfiguration(@NonNull InputConfigurationCompat param1InputConfigurationCompat) {
      if (this.mSessionType != 1) {
        this.mInputConfig = param1InputConfigurationCompat;
        return;
      } 
      throw new UnsupportedOperationException("Method not supported for high speed session types");
    }
    
    public void setSessionParameters(@NonNull CaptureRequest param1CaptureRequest) {
      this.mSessionParameters = param1CaptureRequest;
    }
  }
  
  private static interface SessionConfigurationCompatImpl {
    @NonNull
    Executor getExecutor();
    
    @Nullable
    InputConfigurationCompat getInputConfiguration();
    
    @NonNull
    List<OutputConfigurationCompat> getOutputConfigurations();
    
    @Nullable
    Object getSessionConfiguration();
    
    @Nullable
    CaptureRequest getSessionParameters();
    
    int getSessionType();
    
    @NonNull
    CameraCaptureSession.StateCallback getStateCallback();
    
    void setInputConfiguration(@NonNull InputConfigurationCompat param1InputConfigurationCompat);
    
    void setSessionParameters(@NonNull CaptureRequest param1CaptureRequest);
  }
  
  @Retention(RetentionPolicy.SOURCE)
  @RestrictTo({RestrictTo.Scope.LIBRARY})
  public static @interface SessionMode {}
}


/* Location:              C:\soft\dex2jar-2.0\MagicAI - AI Art & Anime Art-dex2jar.jar!\androidx\camera\camera2\internal\compat\params\SessionConfigurationCompat.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */