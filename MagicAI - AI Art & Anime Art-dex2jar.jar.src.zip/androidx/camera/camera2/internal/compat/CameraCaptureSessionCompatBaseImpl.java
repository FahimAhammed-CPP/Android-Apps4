package androidx.camera.camera2.internal.compat;

import android.hardware.camera2.CameraAccessException;
import android.hardware.camera2.CameraCaptureSession;
import android.hardware.camera2.CaptureRequest;
import android.os.Handler;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.annotation.RequiresApi;
import androidx.core.util.Preconditions;
import java.util.List;
import java.util.concurrent.Executor;

@RequiresApi(21)
class CameraCaptureSessionCompatBaseImpl implements CameraCaptureSessionCompat.CameraCaptureSessionCompatImpl {
  final CameraCaptureSession mCameraCaptureSession;
  
  final Object mObject;
  
  CameraCaptureSessionCompatBaseImpl(@NonNull CameraCaptureSession paramCameraCaptureSession, @Nullable Object paramObject) {
    this.mCameraCaptureSession = (CameraCaptureSession)Preconditions.checkNotNull(paramCameraCaptureSession);
    this.mObject = paramObject;
  }
  
  static CameraCaptureSessionCompat.CameraCaptureSessionCompatImpl create(@NonNull CameraCaptureSession paramCameraCaptureSession, @NonNull Handler paramHandler) {
    return new CameraCaptureSessionCompatBaseImpl(paramCameraCaptureSession, new CameraCaptureSessionCompatParamsApi21(paramHandler));
  }
  
  public int captureBurstRequests(@NonNull List<CaptureRequest> paramList, @NonNull Executor paramExecutor, @NonNull CameraCaptureSession.CaptureCallback paramCaptureCallback) throws CameraAccessException {
    CameraCaptureSessionCompat.CaptureCallbackExecutorWrapper captureCallbackExecutorWrapper = new CameraCaptureSessionCompat.CaptureCallbackExecutorWrapper(paramExecutor, paramCaptureCallback);
    CameraCaptureSessionCompatParamsApi21 cameraCaptureSessionCompatParamsApi21 = (CameraCaptureSessionCompatParamsApi21)this.mObject;
    return this.mCameraCaptureSession.captureBurst(paramList, (CameraCaptureSession.CaptureCallback)captureCallbackExecutorWrapper, cameraCaptureSessionCompatParamsApi21.mCompatHandler);
  }
  
  public int captureSingleRequest(@NonNull CaptureRequest paramCaptureRequest, @NonNull Executor paramExecutor, @NonNull CameraCaptureSession.CaptureCallback paramCaptureCallback) throws CameraAccessException {
    CameraCaptureSessionCompat.CaptureCallbackExecutorWrapper captureCallbackExecutorWrapper = new CameraCaptureSessionCompat.CaptureCallbackExecutorWrapper(paramExecutor, paramCaptureCallback);
    CameraCaptureSessionCompatParamsApi21 cameraCaptureSessionCompatParamsApi21 = (CameraCaptureSessionCompatParamsApi21)this.mObject;
    return this.mCameraCaptureSession.capture(paramCaptureRequest, (CameraCaptureSession.CaptureCallback)captureCallbackExecutorWrapper, cameraCaptureSessionCompatParamsApi21.mCompatHandler);
  }
  
  public int setRepeatingBurstRequests(@NonNull List<CaptureRequest> paramList, @NonNull Executor paramExecutor, @NonNull CameraCaptureSession.CaptureCallback paramCaptureCallback) throws CameraAccessException {
    CameraCaptureSessionCompat.CaptureCallbackExecutorWrapper captureCallbackExecutorWrapper = new CameraCaptureSessionCompat.CaptureCallbackExecutorWrapper(paramExecutor, paramCaptureCallback);
    CameraCaptureSessionCompatParamsApi21 cameraCaptureSessionCompatParamsApi21 = (CameraCaptureSessionCompatParamsApi21)this.mObject;
    return this.mCameraCaptureSession.setRepeatingBurst(paramList, (CameraCaptureSession.CaptureCallback)captureCallbackExecutorWrapper, cameraCaptureSessionCompatParamsApi21.mCompatHandler);
  }
  
  public int setSingleRepeatingRequest(@NonNull CaptureRequest paramCaptureRequest, @NonNull Executor paramExecutor, @NonNull CameraCaptureSession.CaptureCallback paramCaptureCallback) throws CameraAccessException {
    CameraCaptureSessionCompat.CaptureCallbackExecutorWrapper captureCallbackExecutorWrapper = new CameraCaptureSessionCompat.CaptureCallbackExecutorWrapper(paramExecutor, paramCaptureCallback);
    CameraCaptureSessionCompatParamsApi21 cameraCaptureSessionCompatParamsApi21 = (CameraCaptureSessionCompatParamsApi21)this.mObject;
    return this.mCameraCaptureSession.setRepeatingRequest(paramCaptureRequest, (CameraCaptureSession.CaptureCallback)captureCallbackExecutorWrapper, cameraCaptureSessionCompatParamsApi21.mCompatHandler);
  }
  
  @NonNull
  public CameraCaptureSession unwrap() {
    return this.mCameraCaptureSession;
  }
  
  private static class CameraCaptureSessionCompatParamsApi21 {
    final Handler mCompatHandler;
    
    CameraCaptureSessionCompatParamsApi21(@NonNull Handler param1Handler) {
      this.mCompatHandler = param1Handler;
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\MagicAI - AI Art & Anime Art-dex2jar.jar!\androidx\camera\camera2\internal\compat\CameraCaptureSessionCompatBaseImpl.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */