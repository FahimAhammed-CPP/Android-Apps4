package androidx.camera.camera2.internal.compat.quirk;

import android.os.Build;
import androidx.annotation.NonNull;
import androidx.annotation.RequiresApi;
import androidx.camera.camera2.internal.compat.CameraCharacteristicsCompat;
import androidx.camera.core.internal.compat.quirk.SoftwareJpegEncodingPreferredQuirk;
import java.util.Arrays;
import java.util.HashSet;
import java.util.Locale;
import java.util.Set;

@RequiresApi(21)
public final class JpegHalCorruptImageQuirk implements SoftwareJpegEncodingPreferredQuirk {
  private static final Set<String> KNOWN_AFFECTED_DEVICES = new HashSet<String>(Arrays.asList(new String[] { "heroqltevzw", "heroqltetmo", "k61v1_basic_ref" }));
  
  static boolean load(@NonNull CameraCharacteristicsCompat paramCameraCharacteristicsCompat) {
    return KNOWN_AFFECTED_DEVICES.contains(Build.DEVICE.toLowerCase(Locale.US));
  }
}


/* Location:              C:\soft\dex2jar-2.0\MagicAI - AI Art & Anime Art-dex2jar.jar!\androidx\camera\camera2\internal\compat\quirk\JpegHalCorruptImageQuirk.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */