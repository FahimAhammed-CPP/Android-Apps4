package androidx.camera.camera2.internal.compat;

import android.hardware.camera2.CameraCharacteristics;
import android.os.Build;
import androidx.annotation.GuardedBy;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.annotation.RequiresApi;
import androidx.annotation.VisibleForTesting;
import java.util.HashMap;
import java.util.Map;
import java.util.Set;

@RequiresApi(21)
public class CameraCharacteristicsCompat {
  @NonNull
  private final CameraCharacteristicsCompatImpl mCameraCharacteristicsImpl;
  
  @GuardedBy("this")
  @NonNull
  private final Map<CameraCharacteristics.Key<?>, Object> mValuesCache = new HashMap<CameraCharacteristics.Key<?>, Object>();
  
  private CameraCharacteristicsCompat(@NonNull CameraCharacteristics paramCameraCharacteristics) {
    if (Build.VERSION.SDK_INT >= 28) {
      this.mCameraCharacteristicsImpl = (CameraCharacteristicsCompatImpl)new CameraCharacteristicsApi28Impl(paramCameraCharacteristics);
      return;
    } 
    this.mCameraCharacteristicsImpl = (CameraCharacteristicsCompatImpl)new CameraCharacteristicsBaseImpl(paramCameraCharacteristics);
  }
  
  private boolean isKeyNonCacheable(@NonNull CameraCharacteristics.Key<?> paramKey) {
    return paramKey.equals(CameraCharacteristics.SENSOR_ORIENTATION);
  }
  
  @NonNull
  @VisibleForTesting(otherwise = 3)
  public static CameraCharacteristicsCompat toCameraCharacteristicsCompat(@NonNull CameraCharacteristics paramCameraCharacteristics) {
    return new CameraCharacteristicsCompat(paramCameraCharacteristics);
  }
  
  @Nullable
  public <T> T get(@NonNull CameraCharacteristics.Key<T> paramKey) {
    // Byte code:
    //   0: aload_0
    //   1: aload_1
    //   2: invokespecial isKeyNonCacheable : (Landroid/hardware/camera2/CameraCharacteristics$Key;)Z
    //   5: ifeq -> 19
    //   8: aload_0
    //   9: getfield mCameraCharacteristicsImpl : Landroidx/camera/camera2/internal/compat/CameraCharacteristicsCompat$CameraCharacteristicsCompatImpl;
    //   12: aload_1
    //   13: invokeinterface get : (Landroid/hardware/camera2/CameraCharacteristics$Key;)Ljava/lang/Object;
    //   18: areturn
    //   19: aload_0
    //   20: monitorenter
    //   21: aload_0
    //   22: getfield mValuesCache : Ljava/util/Map;
    //   25: aload_1
    //   26: invokeinterface get : (Ljava/lang/Object;)Ljava/lang/Object;
    //   31: astore_2
    //   32: aload_2
    //   33: ifnull -> 40
    //   36: aload_0
    //   37: monitorexit
    //   38: aload_2
    //   39: areturn
    //   40: aload_0
    //   41: getfield mCameraCharacteristicsImpl : Landroidx/camera/camera2/internal/compat/CameraCharacteristicsCompat$CameraCharacteristicsCompatImpl;
    //   44: aload_1
    //   45: invokeinterface get : (Landroid/hardware/camera2/CameraCharacteristics$Key;)Ljava/lang/Object;
    //   50: astore_2
    //   51: aload_2
    //   52: ifnull -> 67
    //   55: aload_0
    //   56: getfield mValuesCache : Ljava/util/Map;
    //   59: aload_1
    //   60: aload_2
    //   61: invokeinterface put : (Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    //   66: pop
    //   67: aload_0
    //   68: monitorexit
    //   69: aload_2
    //   70: areturn
    //   71: astore_1
    //   72: aload_0
    //   73: monitorexit
    //   74: aload_1
    //   75: athrow
    // Exception table:
    //   from	to	target	type
    //   21	32	71	finally
    //   36	38	71	finally
    //   40	51	71	finally
    //   55	67	71	finally
    //   67	69	71	finally
    //   72	74	71	finally
  }
  
  @NonNull
  public Set<String> getPhysicalCameraIds() {
    return this.mCameraCharacteristicsImpl.getPhysicalCameraIds();
  }
  
  @NonNull
  public CameraCharacteristics toCameraCharacteristics() {
    return this.mCameraCharacteristicsImpl.unwrap();
  }
  
  public static interface CameraCharacteristicsCompatImpl {
    @Nullable
    <T> T get(@NonNull CameraCharacteristics.Key<T> param1Key);
    
    @NonNull
    Set<String> getPhysicalCameraIds();
    
    @NonNull
    CameraCharacteristics unwrap();
  }
}


/* Location:              C:\soft\dex2jar-2.0\MagicAI - AI Art & Anime Art-dex2jar.jar!\androidx\camera\camera2\internal\compat\CameraCharacteristicsCompat.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */