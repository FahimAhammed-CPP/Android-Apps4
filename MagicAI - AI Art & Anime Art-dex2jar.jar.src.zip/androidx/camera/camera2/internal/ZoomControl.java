package androidx.camera.camera2.internal;

import android.graphics.Rect;
import android.hardware.camera2.TotalCaptureResult;
import android.os.Build;
import android.os.Looper;
import android.util.Range;
import androidx.annotation.FloatRange;
import androidx.annotation.GuardedBy;
import androidx.annotation.NonNull;
import androidx.annotation.RequiresApi;
import androidx.annotation.VisibleForTesting;
import androidx.camera.camera2.impl.Camera2ImplConfig;
import androidx.camera.camera2.internal.compat.CameraCharacteristicsCompat;
import androidx.camera.core.CameraControl;
import androidx.camera.core.Logger;
import androidx.camera.core.ZoomState;
import androidx.camera.core.impl.utils.futures.Futures;
import androidx.camera.core.internal.ImmutableZoomState;
import androidx.concurrent.futures.CallbackToFutureAdapter;
import androidx.lifecycle.LiveData;
import androidx.lifecycle.MutableLiveData;
import com.google.common.util.concurrent.ListenableFuture;
import java.util.concurrent.Executor;

@RequiresApi(21)
final class ZoomControl {
  public static final float DEFAULT_ZOOM_RATIO = 1.0F;
  
  private static final String TAG = "ZoomControl";
  
  private final Camera2CameraControlImpl mCamera2CameraControlImpl;
  
  private Camera2CameraControlImpl.CaptureResultListener mCaptureResultListener = new Camera2CameraControlImpl.CaptureResultListener() {
      public boolean onCaptureResult(@NonNull TotalCaptureResult param1TotalCaptureResult) {
        ZoomControl.this.mZoomImpl.onCaptureResult(param1TotalCaptureResult);
        return false;
      }
    };
  
  @GuardedBy("mCurrentZoomState")
  private final ZoomStateImpl mCurrentZoomState;
  
  private final Executor mExecutor;
  
  private boolean mIsActive = false;
  
  @NonNull
  final ZoomImpl mZoomImpl;
  
  private final MutableLiveData<ZoomState> mZoomStateLiveData;
  
  ZoomControl(@NonNull Camera2CameraControlImpl paramCamera2CameraControlImpl, @NonNull CameraCharacteristicsCompat paramCameraCharacteristicsCompat, @NonNull Executor paramExecutor) {
    this.mCamera2CameraControlImpl = paramCamera2CameraControlImpl;
    this.mExecutor = paramExecutor;
    ZoomImpl zoomImpl = createZoomImpl(paramCameraCharacteristicsCompat);
    this.mZoomImpl = zoomImpl;
    ZoomStateImpl zoomStateImpl = new ZoomStateImpl(zoomImpl.getMaxZoom(), zoomImpl.getMinZoom());
    this.mCurrentZoomState = zoomStateImpl;
    zoomStateImpl.setZoomRatio(1.0F);
    this.mZoomStateLiveData = new MutableLiveData(ImmutableZoomState.create((ZoomState)zoomStateImpl));
    paramCamera2CameraControlImpl.addCaptureResultListener(this.mCaptureResultListener);
  }
  
  private static ZoomImpl createZoomImpl(@NonNull CameraCharacteristicsCompat paramCameraCharacteristicsCompat) {
    return (ZoomImpl)(isAndroidRZoomSupported(paramCameraCharacteristicsCompat) ? new AndroidRZoomImpl(paramCameraCharacteristicsCompat) : new CropRegionZoomImpl(paramCameraCharacteristicsCompat));
  }
  
  static ZoomState getDefaultZoomState(CameraCharacteristicsCompat paramCameraCharacteristicsCompat) {
    ZoomImpl zoomImpl = createZoomImpl(paramCameraCharacteristicsCompat);
    ZoomStateImpl zoomStateImpl = new ZoomStateImpl(zoomImpl.getMaxZoom(), zoomImpl.getMinZoom());
    zoomStateImpl.setZoomRatio(1.0F);
    return ImmutableZoomState.create((ZoomState)zoomStateImpl);
  }
  
  @RequiresApi(30)
  private static Range<Float> getZoomRatioRange(CameraCharacteristicsCompat paramCameraCharacteristicsCompat) {
    try {
      return (Range)paramCameraCharacteristicsCompat.get(AndroidRZoomImpl$.ExternalSyntheticApiModelOutline0.m());
    } catch (AssertionError assertionError) {
      Logger.w("ZoomControl", "AssertionError, fail to get camera characteristic.", assertionError);
      return null;
    } 
  }
  
  @VisibleForTesting
  static boolean isAndroidRZoomSupported(CameraCharacteristicsCompat paramCameraCharacteristicsCompat) {
    return (Build.VERSION.SDK_INT >= 30 && getZoomRatioRange(paramCameraCharacteristicsCompat) != null);
  }
  
  private void submitCameraZoomRatio(@NonNull CallbackToFutureAdapter.Completer<Void> paramCompleter, @NonNull ZoomState paramZoomState) {
    if (!this.mIsActive)
      synchronized (this.mCurrentZoomState) {
        this.mCurrentZoomState.setZoomRatio(1.0F);
        ZoomState zoomState = ImmutableZoomState.create((ZoomState)this.mCurrentZoomState);
        updateLiveData(zoomState);
        paramCompleter.setException((Throwable)new CameraControl.OperationCanceledException("Camera is not active."));
        return;
      }  
    updateLiveData(paramZoomState);
    this.mZoomImpl.setZoomRatio(paramZoomState.getZoomRatio(), paramCompleter);
    this.mCamera2CameraControlImpl.updateSessionConfigSynchronous();
  }
  
  private void updateLiveData(ZoomState paramZoomState) {
    if (Looper.myLooper() == Looper.getMainLooper()) {
      this.mZoomStateLiveData.setValue(paramZoomState);
      return;
    } 
    this.mZoomStateLiveData.postValue(paramZoomState);
  }
  
  void addZoomOption(@NonNull Camera2ImplConfig.Builder paramBuilder) {
    this.mZoomImpl.addRequestOption(paramBuilder);
  }
  
  @NonNull
  Rect getCropSensorRegion() {
    return this.mZoomImpl.getCropSensorRegion();
  }
  
  LiveData<ZoomState> getZoomState() {
    return (LiveData<ZoomState>)this.mZoomStateLiveData;
  }
  
  void setActive(boolean paramBoolean) {
    if (this.mIsActive == paramBoolean)
      return; 
    this.mIsActive = paramBoolean;
    if (!paramBoolean)
      synchronized (this.mCurrentZoomState) {
        this.mCurrentZoomState.setZoomRatio(1.0F);
        ZoomState zoomState = ImmutableZoomState.create((ZoomState)this.mCurrentZoomState);
        updateLiveData(zoomState);
        this.mZoomImpl.resetZoom();
        this.mCamera2CameraControlImpl.updateSessionConfigSynchronous();
        return;
      }  
  }
  
  @NonNull
  ListenableFuture<Void> setLinearZoom(@FloatRange(from = 0.0D, to = 1.0D) float paramFloat) {
    Exception exception;
    ZoomStateImpl zoomStateImpl = this.mCurrentZoomState;
    /* monitor enter ClassFileLocalVariableReferenceExpression{type=ObjectType{androidx/camera/camera2/internal/ZoomStateImpl}, name=null} */
    try {
      this.mCurrentZoomState.setLinearZoom(paramFloat);
      ZoomState zoomState = ImmutableZoomState.create((ZoomState)this.mCurrentZoomState);
      /* monitor exit ClassFileLocalVariableReferenceExpression{type=ObjectType{androidx/camera/camera2/internal/ZoomStateImpl}, name=null} */
      updateLiveData(zoomState);
      return CallbackToFutureAdapter.getFuture((CallbackToFutureAdapter.Resolver)new ZoomControl$.ExternalSyntheticLambda3(this, zoomState));
    } catch (IllegalArgumentException illegalArgumentException) {
      ListenableFuture<Void> listenableFuture = Futures.immediateFailedFuture(illegalArgumentException);
      /* monitor exit ClassFileLocalVariableReferenceExpression{type=ObjectType{androidx/camera/camera2/internal/ZoomStateImpl}, name=null} */
      return listenableFuture;
    } finally {}
    /* monitor exit ClassFileLocalVariableReferenceExpression{type=ObjectType{androidx/camera/camera2/internal/ZoomStateImpl}, name=null} */
    throw exception;
  }
  
  @NonNull
  ListenableFuture<Void> setZoomRatio(float paramFloat) {
    Exception exception;
    ZoomStateImpl zoomStateImpl = this.mCurrentZoomState;
    /* monitor enter ClassFileLocalVariableReferenceExpression{type=ObjectType{androidx/camera/camera2/internal/ZoomStateImpl}, name=null} */
    try {
      this.mCurrentZoomState.setZoomRatio(paramFloat);
      ZoomState zoomState = ImmutableZoomState.create((ZoomState)this.mCurrentZoomState);
      /* monitor exit ClassFileLocalVariableReferenceExpression{type=ObjectType{androidx/camera/camera2/internal/ZoomStateImpl}, name=null} */
      updateLiveData(zoomState);
      return CallbackToFutureAdapter.getFuture((CallbackToFutureAdapter.Resolver)new ZoomControl$.ExternalSyntheticLambda0(this, zoomState));
    } catch (IllegalArgumentException illegalArgumentException) {
      ListenableFuture<Void> listenableFuture = Futures.immediateFailedFuture(illegalArgumentException);
      /* monitor exit ClassFileLocalVariableReferenceExpression{type=ObjectType{androidx/camera/camera2/internal/ZoomStateImpl}, name=null} */
      return listenableFuture;
    } finally {}
    /* monitor exit ClassFileLocalVariableReferenceExpression{type=ObjectType{androidx/camera/camera2/internal/ZoomStateImpl}, name=null} */
    throw exception;
  }
  
  static interface ZoomImpl {
    void addRequestOption(@NonNull Camera2ImplConfig.Builder param1Builder);
    
    @NonNull
    Rect getCropSensorRegion();
    
    float getMaxZoom();
    
    float getMinZoom();
    
    void onCaptureResult(@NonNull TotalCaptureResult param1TotalCaptureResult);
    
    void resetZoom();
    
    void setZoomRatio(float param1Float, @NonNull CallbackToFutureAdapter.Completer<Void> param1Completer);
  }
}


/* Location:              C:\soft\dex2jar-2.0\MagicAI - AI Art & Anime Art-dex2jar.jar!\androidx\camera\camera2\internal\ZoomControl.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */