package androidx.camera.camera2.internal;

import android.hardware.camera2.CameraCaptureSession;
import android.view.Surface;
import androidx.annotation.NonNull;
import androidx.annotation.RequiresApi;
import androidx.camera.camera2.internal.compat.ApiCompat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Iterator;
import java.util.List;

@RequiresApi(21)
public final class CameraCaptureSessionStateCallbacks {
  @NonNull
  public static CameraCaptureSession.StateCallback createComboCallback(@NonNull List<CameraCaptureSession.StateCallback> paramList) {
    return paramList.isEmpty() ? createNoOpCallback() : ((paramList.size() == 1) ? paramList.get(0) : new ComboSessionStateCallback(paramList));
  }
  
  @NonNull
  public static CameraCaptureSession.StateCallback createComboCallback(@NonNull CameraCaptureSession.StateCallback... paramVarArgs) {
    return createComboCallback(Arrays.asList(paramVarArgs));
  }
  
  @NonNull
  public static CameraCaptureSession.StateCallback createNoOpCallback() {
    return new NoOpSessionStateCallback();
  }
  
  @RequiresApi(21)
  static final class ComboSessionStateCallback extends CameraCaptureSession.StateCallback {
    private final List<CameraCaptureSession.StateCallback> mCallbacks = new ArrayList<CameraCaptureSession.StateCallback>();
    
    ComboSessionStateCallback(@NonNull List<CameraCaptureSession.StateCallback> param1List) {
      for (CameraCaptureSession.StateCallback stateCallback : param1List) {
        if (!(stateCallback instanceof CameraCaptureSessionStateCallbacks.NoOpSessionStateCallback))
          this.mCallbacks.add(stateCallback); 
      } 
    }
    
    public void onActive(@NonNull CameraCaptureSession param1CameraCaptureSession) {
      Iterator<CameraCaptureSession.StateCallback> iterator = this.mCallbacks.iterator();
      while (iterator.hasNext())
        ((CameraCaptureSession.StateCallback)iterator.next()).onActive(param1CameraCaptureSession); 
    }
    
    @RequiresApi(api = 26)
    public void onCaptureQueueEmpty(@NonNull CameraCaptureSession param1CameraCaptureSession) {
      Iterator<CameraCaptureSession.StateCallback> iterator = this.mCallbacks.iterator();
      while (iterator.hasNext())
        ApiCompat.Api26Impl.onCaptureQueueEmpty(iterator.next(), param1CameraCaptureSession); 
    }
    
    public void onClosed(@NonNull CameraCaptureSession param1CameraCaptureSession) {
      Iterator<CameraCaptureSession.StateCallback> iterator = this.mCallbacks.iterator();
      while (iterator.hasNext())
        ((CameraCaptureSession.StateCallback)iterator.next()).onClosed(param1CameraCaptureSession); 
    }
    
    public void onConfigureFailed(@NonNull CameraCaptureSession param1CameraCaptureSession) {
      Iterator<CameraCaptureSession.StateCallback> iterator = this.mCallbacks.iterator();
      while (iterator.hasNext())
        ((CameraCaptureSession.StateCallback)iterator.next()).onConfigureFailed(param1CameraCaptureSession); 
    }
    
    public void onConfigured(@NonNull CameraCaptureSession param1CameraCaptureSession) {
      Iterator<CameraCaptureSession.StateCallback> iterator = this.mCallbacks.iterator();
      while (iterator.hasNext())
        ((CameraCaptureSession.StateCallback)iterator.next()).onConfigured(param1CameraCaptureSession); 
    }
    
    public void onReady(@NonNull CameraCaptureSession param1CameraCaptureSession) {
      Iterator<CameraCaptureSession.StateCallback> iterator = this.mCallbacks.iterator();
      while (iterator.hasNext())
        ((CameraCaptureSession.StateCallback)iterator.next()).onReady(param1CameraCaptureSession); 
    }
    
    @RequiresApi(api = 23)
    public void onSurfacePrepared(@NonNull CameraCaptureSession param1CameraCaptureSession, @NonNull Surface param1Surface) {
      Iterator<CameraCaptureSession.StateCallback> iterator = this.mCallbacks.iterator();
      while (iterator.hasNext())
        ApiCompat.Api23Impl.onSurfacePrepared(iterator.next(), param1CameraCaptureSession, param1Surface); 
    }
  }
  
  static final class NoOpSessionStateCallback extends CameraCaptureSession.StateCallback {
    public void onActive(@NonNull CameraCaptureSession param1CameraCaptureSession) {}
    
    public void onCaptureQueueEmpty(@NonNull CameraCaptureSession param1CameraCaptureSession) {}
    
    public void onClosed(@NonNull CameraCaptureSession param1CameraCaptureSession) {}
    
    public void onConfigureFailed(@NonNull CameraCaptureSession param1CameraCaptureSession) {}
    
    public void onConfigured(@NonNull CameraCaptureSession param1CameraCaptureSession) {}
    
    public void onReady(@NonNull CameraCaptureSession param1CameraCaptureSession) {}
    
    public void onSurfacePrepared(@NonNull CameraCaptureSession param1CameraCaptureSession, @NonNull Surface param1Surface) {}
  }
}


/* Location:              C:\soft\dex2jar-2.0\MagicAI - AI Art & Anime Art-dex2jar.jar!\androidx\camera\camera2\internal\CameraCaptureSessionStateCallbacks.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */