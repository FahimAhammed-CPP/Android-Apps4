package androidx.camera.camera2.internal;

import android.hardware.camera2.CameraCharacteristics;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.annotation.RequiresApi;
import androidx.camera.camera2.internal.compat.CameraAccessExceptionCompat;
import androidx.camera.camera2.internal.compat.CameraManagerCompat;
import androidx.camera.core.CameraSelector;
import androidx.camera.core.CameraUnavailableException;
import androidx.camera.core.InitializationException;
import androidx.camera.core.impl.CameraInfoInternal;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Iterator;
import java.util.List;

@RequiresApi(21)
class CameraSelectionOptimizer {
  private static String decideSkippedCameraIdByHeuristic(CameraManagerCompat paramCameraManagerCompat, Integer paramInteger, List<String> paramList) throws CameraAccessExceptionCompat {
    String str2 = null;
    if (paramInteger == null)
      return null; 
    String str1 = str2;
    if (paramList.contains("0")) {
      if (!paramList.contains("1"))
        return null; 
      if (paramInteger.intValue() == 1) {
        str1 = str2;
        if (((Integer)paramCameraManagerCompat.getCameraCharacteristicsCompat("0").get(CameraCharacteristics.LENS_FACING)).intValue() == 1)
          return "1"; 
      } else {
        str1 = str2;
        if (paramInteger.intValue() == 0) {
          str1 = str2;
          if (((Integer)paramCameraManagerCompat.getCameraCharacteristicsCompat("1").get(CameraCharacteristics.LENS_FACING)).intValue() == 0)
            str1 = "0"; 
        } 
      } 
    } 
    return str1;
  }
  
  static List<String> getSelectedAvailableCameraIds(@NonNull Camera2CameraFactory paramCamera2CameraFactory, @Nullable CameraSelector paramCameraSelector) throws InitializationException {
    try {
      ArrayList<String> arrayList = new ArrayList();
      List<String> list = Arrays.asList(paramCamera2CameraFactory.getCameraManager().getCameraIdList());
      if (paramCameraSelector == null) {
        iterator = list.iterator();
        while (iterator.hasNext())
          arrayList.add(iterator.next()); 
        return arrayList;
      } 
      try {
        Integer integer = paramCameraSelector.getLensFacing();
        String str = decideSkippedCameraIdByHeuristic(iterator.getCameraManager(), integer, list);
      } catch (IllegalStateException illegalStateException) {
        illegalStateException = null;
      } 
      ArrayList<Camera2CameraInfoImpl> arrayList1 = new ArrayList();
      for (String str : list) {
        if (str.equals(illegalStateException))
          continue; 
        arrayList1.add(iterator.getCameraInfo(str));
      } 
      Iterator<String> iterator = paramCameraSelector.filter(arrayList1).iterator();
      while (iterator.hasNext())
        arrayList.add(((CameraInfoInternal)iterator.next()).getCameraId()); 
      return arrayList;
    } catch (CameraAccessExceptionCompat cameraAccessExceptionCompat) {
      throw new InitializationException(CameraUnavailableExceptionHelper.createFrom(cameraAccessExceptionCompat));
    } catch (CameraUnavailableException cameraUnavailableException) {
      throw new InitializationException(cameraUnavailableException);
    } 
  }
}


/* Location:              C:\soft\dex2jar-2.0\MagicAI - AI Art & Anime Art-dex2jar.jar!\androidx\camera\camera2\internal\CameraSelectionOptimizer.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */