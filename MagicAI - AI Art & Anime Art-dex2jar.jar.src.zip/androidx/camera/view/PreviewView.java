package androidx.camera.view;

import android.annotation.SuppressLint;
import android.content.Context;
import android.content.res.Resources;
import android.content.res.TypedArray;
import android.graphics.Bitmap;
import android.graphics.Matrix;
import android.graphics.Rect;
import android.hardware.display.DisplayManager;
import android.os.Build;
import android.os.Handler;
import android.os.Looper;
import android.util.AttributeSet;
import android.util.Rational;
import android.util.Size;
import android.view.Display;
import android.view.MotionEvent;
import android.view.ScaleGestureDetector;
import android.view.View;
import android.view.ViewConfiguration;
import android.widget.FrameLayout;
import androidx.annotation.AnyThread;
import androidx.annotation.ColorRes;
import androidx.annotation.MainThread;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.annotation.OptIn;
import androidx.annotation.RequiresApi;
import androidx.annotation.RestrictTo;
import androidx.annotation.UiThread;
import androidx.annotation.VisibleForTesting;
import androidx.camera.core.Logger;
import androidx.camera.core.MeteringPointFactory;
import androidx.camera.core.Preview;
import androidx.camera.core.SurfaceRequest;
import androidx.camera.core.ViewPort;
import androidx.camera.core.impl.CameraInfoInternal;
import androidx.camera.core.impl.CameraInternal;
import androidx.camera.core.impl.Observable;
import androidx.camera.core.impl.utils.Threads;
import androidx.camera.core.impl.utils.TransformUtils;
import androidx.camera.view.internal.compat.quirk.DeviceQuirks;
import androidx.camera.view.internal.compat.quirk.SurfaceViewNotCroppedByParentQuirk;
import androidx.camera.view.internal.compat.quirk.SurfaceViewStretchedQuirk;
import androidx.camera.view.transform.OutputTransform;
import androidx.core.content.ContextCompat;
import androidx.core.view.ViewCompat;
import androidx.lifecycle.LiveData;
import androidx.lifecycle.MutableLiveData;
import java.util.concurrent.Executor;
import java.util.concurrent.atomic.AtomicReference;

@RequiresApi(21)
public final class PreviewView extends FrameLayout {
  @ColorRes
  static final int DEFAULT_BACKGROUND_COLOR = 17170444;
  
  private static final ImplementationMode DEFAULT_IMPL_MODE = ImplementationMode.PERFORMANCE;
  
  private static final String TAG = "PreviewView";
  
  @Nullable
  final AtomicReference<PreviewStreamStateObserver> mActiveStreamStateObserver;
  
  CameraController mCameraController;
  
  @Nullable
  CameraInfoInternal mCameraInfoInternal;
  
  @NonNull
  private final DisplayRotationListener mDisplayRotationListener;
  
  @Nullable
  @VisibleForTesting
  PreviewViewImplementation mImplementation;
  
  @NonNull
  ImplementationMode mImplementationMode;
  
  @Nullable
  OnFrameUpdateListener mOnFrameUpdateListener;
  
  @Nullable
  Executor mOnFrameUpdateListenerExecutor;
  
  private final View.OnLayoutChangeListener mOnLayoutChangeListener;
  
  @NonNull
  final MutableLiveData<StreamState> mPreviewStreamStateLiveData;
  
  @NonNull
  final PreviewTransformation mPreviewTransform;
  
  @NonNull
  PreviewViewMeteringPointFactory mPreviewViewMeteringPointFactory;
  
  @NonNull
  private final ScaleGestureDetector mScaleGestureDetector;
  
  final Preview.SurfaceProvider mSurfaceProvider;
  
  @Nullable
  private MotionEvent mTouchUpEvent;
  
  boolean mUseDisplayRotation;
  
  @UiThread
  public PreviewView(@NonNull Context paramContext) {
    this(paramContext, null);
  }
  
  @UiThread
  public PreviewView(@NonNull Context paramContext, @Nullable AttributeSet paramAttributeSet) {
    this(paramContext, paramAttributeSet, 0);
  }
  
  @UiThread
  public PreviewView(@NonNull Context paramContext, @Nullable AttributeSet paramAttributeSet, int paramInt) {
    this(paramContext, paramAttributeSet, paramInt, 0);
  }
  
  @UiThread
  public PreviewView(@NonNull Context paramContext, @Nullable AttributeSet paramAttributeSet, int paramInt1, int paramInt2) {
    super(paramContext, paramAttributeSet, paramInt1, paramInt2);
    ImplementationMode implementationMode = DEFAULT_IMPL_MODE;
    this.mImplementationMode = implementationMode;
    PreviewTransformation previewTransformation = new PreviewTransformation();
    this.mPreviewTransform = previewTransformation;
    this.mUseDisplayRotation = true;
    this.mPreviewStreamStateLiveData = new MutableLiveData(StreamState.IDLE);
    this.mActiveStreamStateObserver = new AtomicReference<PreviewStreamStateObserver>();
    this.mPreviewViewMeteringPointFactory = new PreviewViewMeteringPointFactory(previewTransformation);
    this.mDisplayRotationListener = new DisplayRotationListener();
    this.mOnLayoutChangeListener = (View.OnLayoutChangeListener)new PreviewView$.ExternalSyntheticLambda0(this);
    this.mSurfaceProvider = new Preview.SurfaceProvider() {
        @AnyThread
        public void onSurfaceRequested(@NonNull SurfaceRequest param1SurfaceRequest) {
          SurfaceViewImplementation surfaceViewImplementation;
          if (!Threads.isMainThread()) {
            ContextCompat.getMainExecutor(PreviewView.this.getContext()).execute((Runnable)new PreviewView$1$.ExternalSyntheticLambda1(this, param1SurfaceRequest));
            return;
          } 
          Logger.d("PreviewView", "Surface requested by Preview.");
          CameraInternal cameraInternal = param1SurfaceRequest.getCamera();
          PreviewView.this.mCameraInfoInternal = cameraInternal.getCameraInfoInternal();
          param1SurfaceRequest.setTransformationInfoListener(ContextCompat.getMainExecutor(PreviewView.this.getContext()), (SurfaceRequest.TransformationInfoListener)new PreviewView$1$.ExternalSyntheticLambda2(this, cameraInternal, param1SurfaceRequest));
          PreviewView previewView2 = PreviewView.this;
          if (PreviewView.shouldUseTextureView(param1SurfaceRequest, previewView2.mImplementationMode)) {
            PreviewView previewView = PreviewView.this;
            TextureViewImplementation textureViewImplementation = new TextureViewImplementation(previewView, previewView.mPreviewTransform);
          } else {
            PreviewView previewView = PreviewView.this;
            surfaceViewImplementation = new SurfaceViewImplementation(previewView, previewView.mPreviewTransform);
          } 
          previewView2.mImplementation = (PreviewViewImplementation)surfaceViewImplementation;
          CameraInfoInternal cameraInfoInternal = cameraInternal.getCameraInfoInternal();
          previewView2 = PreviewView.this;
          PreviewStreamStateObserver previewStreamStateObserver = new PreviewStreamStateObserver(cameraInfoInternal, previewView2.mPreviewStreamStateLiveData, previewView2.mImplementation);
          PreviewView.this.mActiveStreamStateObserver.set(previewStreamStateObserver);
          cameraInternal.getCameraState().addObserver(ContextCompat.getMainExecutor(PreviewView.this.getContext()), (Observable.Observer)previewStreamStateObserver);
          PreviewView.this.mImplementation.onSurfaceRequested(param1SurfaceRequest, (PreviewViewImplementation.OnSurfaceNotInUseListener)new PreviewView$1$.ExternalSyntheticLambda3(this, previewStreamStateObserver, cameraInternal));
          PreviewView previewView1 = PreviewView.this;
          PreviewView.OnFrameUpdateListener onFrameUpdateListener = previewView1.mOnFrameUpdateListener;
          if (onFrameUpdateListener != null) {
            Executor executor = previewView1.mOnFrameUpdateListenerExecutor;
            if (executor != null)
              previewView1.mImplementation.setFrameUpdateListener(executor, onFrameUpdateListener); 
          } 
        }
      };
    Threads.checkMainThread();
    Resources.Theme theme = paramContext.getTheme();
    int[] arrayOfInt = R.styleable.PreviewView;
    TypedArray typedArray = theme.obtainStyledAttributes(paramAttributeSet, arrayOfInt, paramInt1, paramInt2);
    ViewCompat.saveAttributeDataForStyleable((View)this, paramContext, arrayOfInt, paramAttributeSet, typedArray, paramInt1, paramInt2);
    try {
      setScaleType(ScaleType.fromId(typedArray.getInteger(R.styleable.PreviewView_scaleType, previewTransformation.getScaleType().getId())));
      setImplementationMode(ImplementationMode.fromId(typedArray.getInteger(R.styleable.PreviewView_implementationMode, implementationMode.getId())));
      typedArray.recycle();
      this.mScaleGestureDetector = new ScaleGestureDetector(paramContext, (ScaleGestureDetector.OnScaleGestureListener)new PinchToZoomOnScaleGestureListener());
      return;
    } finally {
      typedArray.recycle();
    } 
  }
  
  @MainThread
  private void attachToControllerIfReady(boolean paramBoolean) {
    Threads.checkMainThread();
    Display display = getDisplay();
    ViewPort viewPort = getViewPort();
    if (this.mCameraController != null && viewPort != null && isAttachedToWindow() && display != null)
      try {
        this.mCameraController.attachPreviewSurface(getSurfaceProvider(), viewPort, display);
        return;
      } catch (IllegalStateException illegalStateException) {
        if (paramBoolean) {
          Logger.e("PreviewView", illegalStateException.toString(), illegalStateException);
          return;
        } 
        throw illegalStateException;
      }  
  }
  
  @Nullable
  private DisplayManager getDisplayManager() {
    Context context = getContext();
    return (context == null) ? null : (DisplayManager)context.getApplicationContext().getSystemService("display");
  }
  
  private int getViewPortScaleType() {
    StringBuilder stringBuilder;
    switch (getScaleType()) {
      default:
        stringBuilder = new StringBuilder();
        stringBuilder.append("Unexpected scale type: ");
        stringBuilder.append(getScaleType());
        throw new IllegalStateException(stringBuilder.toString());
      case null:
      case null:
      case null:
        return 3;
      case null:
        return 0;
      case null:
        return 1;
      case null:
        break;
    } 
    return 2;
  }
  
  static boolean shouldUseTextureView(@NonNull SurfaceRequest paramSurfaceRequest, @NonNull ImplementationMode paramImplementationMode) {
    int i;
    boolean bool = paramSurfaceRequest.getCamera().getCameraInfoInternal().getImplementationType().equals("androidx.camera.camera2.legacy");
    if (DeviceQuirks.get(SurfaceViewStretchedQuirk.class) != null || DeviceQuirks.get(SurfaceViewNotCroppedByParentQuirk.class) != null) {
      i = 1;
    } else {
      i = 0;
    } 
    if (!paramSurfaceRequest.isRGBA8888Required() && Build.VERSION.SDK_INT > 24 && !bool) {
      if (i)
        return true; 
      i = null.$SwitchMap$androidx$camera$view$PreviewView$ImplementationMode[paramImplementationMode.ordinal()];
      if (i != 1) {
        if (i == 2)
          return false; 
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("Invalid implementation mode: ");
        stringBuilder.append(paramImplementationMode);
        throw new IllegalArgumentException(stringBuilder.toString());
      } 
    } 
    return true;
  }
  
  private void startListeningToDisplayChange() {
    DisplayManager displayManager = getDisplayManager();
    if (displayManager == null)
      return; 
    displayManager.registerDisplayListener(this.mDisplayRotationListener, new Handler(Looper.getMainLooper()));
  }
  
  private void stopListeningToDisplayChange() {
    DisplayManager displayManager = getDisplayManager();
    if (displayManager == null)
      return; 
    displayManager.unregisterDisplayListener(this.mDisplayRotationListener);
  }
  
  @Nullable
  @UiThread
  public Bitmap getBitmap() {
    Threads.checkMainThread();
    PreviewViewImplementation previewViewImplementation = this.mImplementation;
    return (previewViewImplementation == null) ? null : previewViewImplementation.getBitmap();
  }
  
  @Nullable
  @UiThread
  public CameraController getController() {
    Threads.checkMainThread();
    return this.mCameraController;
  }
  
  @NonNull
  @UiThread
  public ImplementationMode getImplementationMode() {
    Threads.checkMainThread();
    return this.mImplementationMode;
  }
  
  @NonNull
  @UiThread
  public MeteringPointFactory getMeteringPointFactory() {
    Threads.checkMainThread();
    return (MeteringPointFactory)this.mPreviewViewMeteringPointFactory;
  }
  
  @Nullable
  @TransformExperimental
  public OutputTransform getOutputTransform() {
    Threads.checkMainThread();
    try {
      Matrix matrix = this.mPreviewTransform.getSurfaceToPreviewViewMatrix(new Size(getWidth(), getHeight()), getLayoutDirection());
    } catch (IllegalStateException illegalStateException) {
      illegalStateException = null;
    } 
    Rect rect = this.mPreviewTransform.getSurfaceCropRect();
    if (illegalStateException == null || rect == null) {
      Logger.d("PreviewView", "Transform info is not ready");
      return null;
    } 
    illegalStateException.preConcat(TransformUtils.getNormalizedToBuffer(rect));
    if (this.mImplementation instanceof TextureViewImplementation) {
      illegalStateException.postConcat(getMatrix());
    } else {
      Logger.w("PreviewView", "PreviewView needs to be in COMPATIBLE mode for the transform to work correctly.");
    } 
    return new OutputTransform((Matrix)illegalStateException, new Size(rect.width(), rect.height()));
  }
  
  @NonNull
  public LiveData<StreamState> getPreviewStreamState() {
    return (LiveData<StreamState>)this.mPreviewStreamStateLiveData;
  }
  
  @NonNull
  @UiThread
  public ScaleType getScaleType() {
    Threads.checkMainThread();
    return this.mPreviewTransform.getScaleType();
  }
  
  @NonNull
  @UiThread
  public Preview.SurfaceProvider getSurfaceProvider() {
    Threads.checkMainThread();
    return this.mSurfaceProvider;
  }
  
  @Nullable
  @UiThread
  public ViewPort getViewPort() {
    Threads.checkMainThread();
    return (getDisplay() == null) ? null : getViewPort(getDisplay().getRotation());
  }
  
  @SuppressLint({"WrongConstant"})
  @Nullable
  @UiThread
  public ViewPort getViewPort(int paramInt) {
    Threads.checkMainThread();
    return (getWidth() == 0 || getHeight() == 0) ? null : (new ViewPort.Builder(new Rational(getWidth(), getHeight()), paramInt)).setScaleType(getViewPortScaleType()).setLayoutDirection(getLayoutDirection()).build();
  }
  
  protected void onAttachedToWindow() {
    super.onAttachedToWindow();
    updateDisplayRotationIfNeeded();
    startListeningToDisplayChange();
    addOnLayoutChangeListener(this.mOnLayoutChangeListener);
    PreviewViewImplementation previewViewImplementation = this.mImplementation;
    if (previewViewImplementation != null)
      previewViewImplementation.onAttachedToWindow(); 
    attachToControllerIfReady(true);
  }
  
  protected void onDetachedFromWindow() {
    super.onDetachedFromWindow();
    removeOnLayoutChangeListener(this.mOnLayoutChangeListener);
    PreviewViewImplementation previewViewImplementation = this.mImplementation;
    if (previewViewImplementation != null)
      previewViewImplementation.onDetachedFromWindow(); 
    CameraController cameraController = this.mCameraController;
    if (cameraController != null)
      cameraController.clearPreviewSurface(); 
    stopListeningToDisplayChange();
  }
  
  public boolean onTouchEvent(@NonNull MotionEvent paramMotionEvent) {
    boolean bool1;
    boolean bool2;
    if (this.mCameraController == null)
      return super.onTouchEvent(paramMotionEvent); 
    int i = paramMotionEvent.getPointerCount();
    boolean bool3 = false;
    if (i == 1) {
      i = 1;
    } else {
      i = 0;
    } 
    if (paramMotionEvent.getAction() == 1) {
      bool1 = true;
    } else {
      bool1 = false;
    } 
    if (paramMotionEvent.getEventTime() - paramMotionEvent.getDownTime() < ViewConfiguration.getLongPressTimeout()) {
      bool2 = true;
    } else {
      bool2 = false;
    } 
    if (i != 0 && bool1 && bool2) {
      this.mTouchUpEvent = paramMotionEvent;
      performClick();
      return true;
    } 
    if (this.mScaleGestureDetector.onTouchEvent(paramMotionEvent) || super.onTouchEvent(paramMotionEvent))
      bool3 = true; 
    return bool3;
  }
  
  public boolean performClick() {
    if (this.mCameraController != null) {
      float f1;
      float f2;
      MotionEvent motionEvent = this.mTouchUpEvent;
      if (motionEvent != null) {
        f1 = motionEvent.getX();
      } else {
        f1 = getWidth() / 2.0F;
      } 
      motionEvent = this.mTouchUpEvent;
      if (motionEvent != null) {
        f2 = motionEvent.getY();
      } else {
        f2 = getHeight() / 2.0F;
      } 
      this.mCameraController.onTapToFocus((MeteringPointFactory)this.mPreviewViewMeteringPointFactory, f1, f2);
    } 
    this.mTouchUpEvent = null;
    return super.performClick();
  }
  
  @MainThread
  @OptIn(markerClass = {TransformExperimental.class})
  void redrawPreview() {
    Threads.checkMainThread();
    PreviewViewImplementation previewViewImplementation = this.mImplementation;
    if (previewViewImplementation != null)
      previewViewImplementation.redrawPreview(); 
    this.mPreviewViewMeteringPointFactory.recalculate(new Size(getWidth(), getHeight()), getLayoutDirection());
    CameraController cameraController = this.mCameraController;
    if (cameraController != null)
      cameraController.updatePreviewViewTransform(getOutputTransform()); 
  }
  
  @UiThread
  public void setController(@Nullable CameraController paramCameraController) {
    Threads.checkMainThread();
    CameraController cameraController = this.mCameraController;
    if (cameraController != null && cameraController != paramCameraController)
      cameraController.clearPreviewSurface(); 
    this.mCameraController = paramCameraController;
    attachToControllerIfReady(false);
  }
  
  @RestrictTo({RestrictTo.Scope.LIBRARY_GROUP})
  public void setFrameUpdateListener(@NonNull Executor paramExecutor, @NonNull OnFrameUpdateListener paramOnFrameUpdateListener) {
    if (this.mImplementationMode != ImplementationMode.PERFORMANCE) {
      this.mOnFrameUpdateListener = paramOnFrameUpdateListener;
      this.mOnFrameUpdateListenerExecutor = paramExecutor;
      PreviewViewImplementation previewViewImplementation = this.mImplementation;
      if (previewViewImplementation != null)
        previewViewImplementation.setFrameUpdateListener(paramExecutor, paramOnFrameUpdateListener); 
      return;
    } 
    throw new IllegalArgumentException("PERFORMANCE mode doesn't support frame update listener");
  }
  
  @UiThread
  public void setImplementationMode(@NonNull ImplementationMode paramImplementationMode) {
    Threads.checkMainThread();
    this.mImplementationMode = paramImplementationMode;
    if (paramImplementationMode == ImplementationMode.PERFORMANCE) {
      if (this.mOnFrameUpdateListener == null)
        return; 
      throw new IllegalArgumentException("PERFORMANCE mode doesn't support frame update listener");
    } 
  }
  
  @UiThread
  public void setScaleType(@NonNull ScaleType paramScaleType) {
    Threads.checkMainThread();
    this.mPreviewTransform.setScaleType(paramScaleType);
    redrawPreview();
    attachToControllerIfReady(false);
  }
  
  void updateDisplayRotationIfNeeded() {
    if (this.mUseDisplayRotation) {
      Display display = getDisplay();
      if (display != null) {
        CameraInfoInternal cameraInfoInternal = this.mCameraInfoInternal;
        if (cameraInfoInternal != null)
          this.mPreviewTransform.overrideWithDisplayRotation(cameraInfoInternal.getSensorRotationDegrees(display.getRotation()), display.getRotation()); 
      } 
    } 
  }
  
  class DisplayRotationListener implements DisplayManager.DisplayListener {
    public void onDisplayAdded(int param1Int) {}
    
    public void onDisplayChanged(int param1Int) {
      Display display = PreviewView.this.getDisplay();
      if (display != null && display.getDisplayId() == param1Int) {
        PreviewView.this.updateDisplayRotationIfNeeded();
        PreviewView.this.redrawPreview();
      } 
    }
    
    public void onDisplayRemoved(int param1Int) {}
  }
  
  @RequiresApi(21)
  public enum ImplementationMode {
    COMPATIBLE, PERFORMANCE;
    
    private final int mId;
    
    static {
      ImplementationMode implementationMode1 = new ImplementationMode("PERFORMANCE", 0, 0);
      PERFORMANCE = implementationMode1;
      ImplementationMode implementationMode2 = new ImplementationMode("COMPATIBLE", 1, 1);
      COMPATIBLE = implementationMode2;
      $VALUES = new ImplementationMode[] { implementationMode1, implementationMode2 };
    }
    
    ImplementationMode(int param1Int1) {
      this.mId = param1Int1;
    }
    
    static ImplementationMode fromId(int param1Int) {
      for (ImplementationMode implementationMode : values()) {
        if (implementationMode.mId == param1Int)
          return implementationMode; 
      } 
      StringBuilder stringBuilder = new StringBuilder();
      stringBuilder.append("Unknown implementation mode id ");
      stringBuilder.append(param1Int);
      throw new IllegalArgumentException(stringBuilder.toString());
    }
    
    int getId() {
      return this.mId;
    }
  }
  
  @RestrictTo({RestrictTo.Scope.LIBRARY_GROUP})
  public static interface OnFrameUpdateListener {
    void onFrameUpdate(long param1Long);
  }
  
  class PinchToZoomOnScaleGestureListener extends ScaleGestureDetector.SimpleOnScaleGestureListener {
    public boolean onScale(ScaleGestureDetector param1ScaleGestureDetector) {
      CameraController cameraController = PreviewView.this.mCameraController;
      if (cameraController != null)
        cameraController.onPinchToZoom(param1ScaleGestureDetector.getScaleFactor()); 
      return true;
    }
  }
  
  @RequiresApi(21)
  public enum ScaleType {
    FILL_CENTER, FILL_END, FILL_START, FIT_CENTER, FIT_END, FIT_START;
    
    private final int mId;
    
    static {
      ScaleType scaleType1 = new ScaleType("FILL_START", 0, 0);
      FILL_START = scaleType1;
      ScaleType scaleType2 = new ScaleType("FILL_CENTER", 1, 1);
      FILL_CENTER = scaleType2;
      ScaleType scaleType3 = new ScaleType("FILL_END", 2, 2);
      FILL_END = scaleType3;
      ScaleType scaleType4 = new ScaleType("FIT_START", 3, 3);
      FIT_START = scaleType4;
      ScaleType scaleType5 = new ScaleType("FIT_CENTER", 4, 4);
      FIT_CENTER = scaleType5;
      ScaleType scaleType6 = new ScaleType("FIT_END", 5, 5);
      FIT_END = scaleType6;
      $VALUES = new ScaleType[] { scaleType1, scaleType2, scaleType3, scaleType4, scaleType5, scaleType6 };
    }
    
    ScaleType(int param1Int1) {
      this.mId = param1Int1;
    }
    
    static ScaleType fromId(int param1Int) {
      for (ScaleType scaleType : values()) {
        if (scaleType.mId == param1Int)
          return scaleType; 
      } 
      StringBuilder stringBuilder = new StringBuilder();
      stringBuilder.append("Unknown scale type id ");
      stringBuilder.append(param1Int);
      throw new IllegalArgumentException(stringBuilder.toString());
    }
    
    int getId() {
      return this.mId;
    }
  }
  
  public enum StreamState {
    IDLE, STREAMING;
    
    static {
      StreamState streamState1 = new StreamState("IDLE", 0);
      IDLE = streamState1;
      StreamState streamState2 = new StreamState("STREAMING", 1);
      STREAMING = streamState2;
      $VALUES = new StreamState[] { streamState1, streamState2 };
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\MagicAI - AI Art & Anime Art-dex2jar.jar!\androidx\camera\view\PreviewView.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */