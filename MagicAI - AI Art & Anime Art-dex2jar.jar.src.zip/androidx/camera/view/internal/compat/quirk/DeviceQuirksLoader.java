package androidx.camera.view.internal.compat.quirk;

import androidx.annotation.NonNull;
import androidx.annotation.RequiresApi;
import androidx.camera.core.impl.Quirk;
import java.util.ArrayList;
import java.util.List;

@RequiresApi(21)
public class DeviceQuirksLoader {
  @NonNull
  static List<Quirk> loadQuirks() {
    ArrayList<SurfaceViewStretchedQuirk> arrayList = new ArrayList();
    if (SurfaceViewStretchedQuirk.load())
      arrayList.add(new SurfaceViewStretchedQuirk()); 
    if (SurfaceViewNotCroppedByParentQuirk.load())
      arrayList.add(new SurfaceViewNotCroppedByParentQuirk()); 
    return (List)arrayList;
  }
}


/* Location:              C:\soft\dex2jar-2.0\MagicAI - AI Art & Anime Art-dex2jar.jar!\androidx\camera\view\internal\compat\quirk\DeviceQuirksLoader.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */