package androidx.savedstate;

public final class R {
  public static final class id {
    public static final int view_tree_saved_state_registry_owner = 2131363436;
  }
}


/* Location:              C:\soft\dex2jar-2.0\MagicAI - AI Art & Anime Art-dex2jar.jar!\androidx\savedstate\R.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */