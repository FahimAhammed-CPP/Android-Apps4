package androidx.renderscript;

public class Byte2 {
  public byte x;
  
  public byte y;
  
  public Byte2() {}
  
  public Byte2(byte paramByte1, byte paramByte2) {
    this.x = paramByte1;
    this.y = paramByte2;
  }
}


/* Location:              C:\soft\dex2jar-2.0\MagicAI - AI Art & Anime Art-dex2jar.jar!\androidx\renderscript\Byte2.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */