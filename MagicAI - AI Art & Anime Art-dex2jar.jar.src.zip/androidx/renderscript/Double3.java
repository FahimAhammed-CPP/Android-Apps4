package androidx.renderscript;

public class Double3 {
  public double x;
  
  public double y;
  
  public double z;
  
  public Double3() {}
  
  public Double3(double paramDouble1, double paramDouble2, double paramDouble3) {
    this.x = paramDouble1;
    this.y = paramDouble2;
    this.z = paramDouble3;
  }
}


/* Location:              C:\soft\dex2jar-2.0\MagicAI - AI Art & Anime Art-dex2jar.jar!\androidx\renderscript\Double3.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */