package androidx.renderscript;

public class Double4 {
  public double w;
  
  public double x;
  
  public double y;
  
  public double z;
  
  public Double4() {}
  
  public Double4(double paramDouble1, double paramDouble2, double paramDouble3, double paramDouble4) {
    this.x = paramDouble1;
    this.y = paramDouble2;
    this.z = paramDouble3;
    this.w = paramDouble4;
  }
}


/* Location:              C:\soft\dex2jar-2.0\MagicAI - AI Art & Anime Art-dex2jar.jar!\androidx\renderscript\Double4.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */