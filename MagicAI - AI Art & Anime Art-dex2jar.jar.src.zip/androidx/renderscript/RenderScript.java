package androidx.renderscript;

import android.content.Context;
import android.graphics.Bitmap;
import android.view.Surface;
import java.io.File;
import java.lang.reflect.Method;
import java.nio.ByteBuffer;
import java.util.ArrayList;
import java.util.concurrent.locks.ReentrantReadWriteLock;

public class RenderScript {
  private static final String CACHE_PATH = "com.android.renderscript.cache";
  
  public static final int CREATE_FLAG_NONE = 0;
  
  static final boolean DEBUG = false;
  
  static final boolean LOG_ENABLED = false;
  
  static final String LOG_TAG = "RenderScript_jni";
  
  static final int SUPPORT_LIB_API = 23;
  
  static final int SUPPORT_LIB_VERSION = 2301;
  
  static Object lock;
  
  private static String mBlackList;
  
  static String mCachePath;
  
  private static ArrayList<RenderScript> mProcessContextList = new ArrayList<RenderScript>();
  
  static Method registerNativeAllocation;
  
  static Method registerNativeFree;
  
  static boolean sInitialized;
  
  private static int sNative;
  
  static int sPointerSize;
  
  static Object sRuntime;
  
  private static int sSdkVersion;
  
  static boolean sUseGCHooks;
  
  private static boolean useIOlib;
  
  private static boolean useNative;
  
  private Context mApplicationContext;
  
  long mContext;
  
  private int mContextFlags = 0;
  
  private int mContextSdkVersion = 0;
  
  ContextType mContextType = ContextType.NORMAL;
  
  private boolean mDestroyed = false;
  
  private int mDispatchAPILevel = 0;
  
  Element mElement_ALLOCATION;
  
  Element mElement_A_8;
  
  Element mElement_BOOLEAN;
  
  Element mElement_CHAR_2;
  
  Element mElement_CHAR_3;
  
  Element mElement_CHAR_4;
  
  Element mElement_DOUBLE_2;
  
  Element mElement_DOUBLE_3;
  
  Element mElement_DOUBLE_4;
  
  Element mElement_ELEMENT;
  
  Element mElement_F32;
  
  Element mElement_F64;
  
  Element mElement_FLOAT_2;
  
  Element mElement_FLOAT_3;
  
  Element mElement_FLOAT_4;
  
  Element mElement_I16;
  
  Element mElement_I32;
  
  Element mElement_I64;
  
  Element mElement_I8;
  
  Element mElement_INT_2;
  
  Element mElement_INT_3;
  
  Element mElement_INT_4;
  
  Element mElement_LONG_2;
  
  Element mElement_LONG_3;
  
  Element mElement_LONG_4;
  
  Element mElement_MATRIX_2X2;
  
  Element mElement_MATRIX_3X3;
  
  Element mElement_MATRIX_4X4;
  
  Element mElement_RGBA_4444;
  
  Element mElement_RGBA_5551;
  
  Element mElement_RGBA_8888;
  
  Element mElement_RGB_565;
  
  Element mElement_RGB_888;
  
  Element mElement_SAMPLER;
  
  Element mElement_SCRIPT;
  
  Element mElement_SHORT_2;
  
  Element mElement_SHORT_3;
  
  Element mElement_SHORT_4;
  
  Element mElement_TYPE;
  
  Element mElement_U16;
  
  Element mElement_U32;
  
  Element mElement_U64;
  
  Element mElement_U8;
  
  Element mElement_UCHAR_2;
  
  Element mElement_UCHAR_3;
  
  Element mElement_UCHAR_4;
  
  Element mElement_UINT_2;
  
  Element mElement_UINT_3;
  
  Element mElement_UINT_4;
  
  Element mElement_ULONG_2;
  
  Element mElement_ULONG_3;
  
  Element mElement_ULONG_4;
  
  Element mElement_USHORT_2;
  
  Element mElement_USHORT_3;
  
  Element mElement_USHORT_4;
  
  private boolean mEnableMultiInput = false;
  
  RSErrorHandler mErrorCallback = null;
  
  long mIncCon;
  
  boolean mIncLoaded;
  
  private boolean mIsProcessContext = false;
  
  RSMessageHandler mMessageCallback = null;
  
  MessageThread mMessageThread;
  
  private String mNativeLibDir;
  
  ReentrantReadWriteLock mRWLock;
  
  Sampler mSampler_CLAMP_LINEAR;
  
  Sampler mSampler_CLAMP_LINEAR_MIP_LINEAR;
  
  Sampler mSampler_CLAMP_NEAREST;
  
  Sampler mSampler_MIRRORED_REPEAT_LINEAR;
  
  Sampler mSampler_MIRRORED_REPEAT_LINEAR_MIP_LINEAR;
  
  Sampler mSampler_MIRRORED_REPEAT_NEAREST;
  
  Sampler mSampler_WRAP_LINEAR;
  
  Sampler mSampler_WRAP_LINEAR_MIP_LINEAR;
  
  Sampler mSampler_WRAP_NEAREST;
  
  static {
    mBlackList = "";
    lock = new Object();
    sNative = -1;
    sSdkVersion = -1;
    useIOlib = false;
  }
  
  RenderScript(Context paramContext) {
    if (paramContext != null) {
      paramContext = paramContext.getApplicationContext();
      this.mApplicationContext = paramContext;
      this.mNativeLibDir = (paramContext.getApplicationInfo()).nativeLibraryDir;
    } 
    this.mIncCon = 0L;
    this.mIncLoaded = false;
    this.mRWLock = new ReentrantReadWriteLock();
  }
  
  public static RenderScript create(Context paramContext) {
    return create(paramContext, ContextType.NORMAL);
  }
  
  public static RenderScript create(Context paramContext, int paramInt) {
    return create(paramContext, paramInt, ContextType.NORMAL, 0);
  }
  
  public static RenderScript create(Context paramContext, int paramInt, ContextType paramContextType) {
    return create(paramContext, paramInt, paramContextType, 0);
  }
  
  public static RenderScript create(Context paramContext, int paramInt1, ContextType paramContextType, int paramInt2) {
    synchronized (mProcessContextList) {
      for (RenderScript renderScript1 : mProcessContextList) {
        if (renderScript1.mContextType == paramContextType && renderScript1.mContextFlags == paramInt2 && renderScript1.mContextSdkVersion == paramInt1)
          return renderScript1; 
      } 
      RenderScript renderScript = internalCreate(paramContext, paramInt1, paramContextType, paramInt2);
      renderScript.mIsProcessContext = true;
      mProcessContextList.add(renderScript);
      return renderScript;
    } 
  }
  
  public static RenderScript create(Context paramContext, ContextType paramContextType) {
    return create(paramContext, paramContextType, 0);
  }
  
  public static RenderScript create(Context paramContext, ContextType paramContextType, int paramInt) {
    return create(paramContext, (paramContext.getApplicationInfo()).targetSdkVersion, paramContextType, paramInt);
  }
  
  public static RenderScript createMultiContext(Context paramContext, ContextType paramContextType, int paramInt1, int paramInt2) {
    return internalCreate(paramContext, paramInt2, paramContextType, paramInt1);
  }
  
  public static void forceCompat() {
    sNative = 0;
  }
  
  public static int getPointerSize() {
    synchronized (lock) {
      if (sInitialized)
        return sPointerSize; 
      throw new RSInvalidStateException("Calling getPointerSize() before any RenderScript instantiated");
    } 
  }
  
  private void helpDestroy() {
    // Byte code:
    //   0: aload_0
    //   1: monitorenter
    //   2: aload_0
    //   3: getfield mDestroyed : Z
    //   6: istore #4
    //   8: iconst_0
    //   9: istore_2
    //   10: iload #4
    //   12: ifne -> 145
    //   15: aload_0
    //   16: iconst_1
    //   17: putfield mDestroyed : Z
    //   20: iconst_1
    //   21: istore_1
    //   22: goto -> 25
    //   25: aload_0
    //   26: monitorexit
    //   27: iload_1
    //   28: ifeq -> 132
    //   31: aload_0
    //   32: invokevirtual nContextFinish : ()V
    //   35: aload_0
    //   36: getfield mIncCon : J
    //   39: lconst_0
    //   40: lcmp
    //   41: ifeq -> 57
    //   44: aload_0
    //   45: invokevirtual nIncContextFinish : ()V
    //   48: aload_0
    //   49: invokevirtual nIncContextDestroy : ()V
    //   52: aload_0
    //   53: lconst_0
    //   54: putfield mIncCon : J
    //   57: aload_0
    //   58: aload_0
    //   59: getfield mContext : J
    //   62: invokevirtual nContextDeinitToClient : (J)V
    //   65: aload_0
    //   66: getfield mMessageThread : Landroidx/renderscript/RenderScript$MessageThread;
    //   69: astore #5
    //   71: aload #5
    //   73: iconst_0
    //   74: putfield mRun : Z
    //   77: aload #5
    //   79: invokevirtual interrupt : ()V
    //   82: iconst_0
    //   83: istore_3
    //   84: iload_2
    //   85: istore_1
    //   86: iload_3
    //   87: istore_2
    //   88: iload_1
    //   89: ifne -> 109
    //   92: aload_0
    //   93: getfield mMessageThread : Landroidx/renderscript/RenderScript$MessageThread;
    //   96: invokevirtual join : ()V
    //   99: iconst_1
    //   100: istore_1
    //   101: goto -> 88
    //   104: iconst_1
    //   105: istore_2
    //   106: goto -> 88
    //   109: iload_2
    //   110: ifeq -> 128
    //   113: ldc 'RenderScript_jni'
    //   115: ldc_w 'Interrupted during wait for MessageThread to join'
    //   118: invokestatic v : (Ljava/lang/String;Ljava/lang/String;)I
    //   121: pop
    //   122: invokestatic currentThread : ()Ljava/lang/Thread;
    //   125: invokevirtual interrupt : ()V
    //   128: aload_0
    //   129: invokevirtual nContextDestroy : ()V
    //   132: return
    //   133: astore #5
    //   135: aload_0
    //   136: monitorexit
    //   137: aload #5
    //   139: athrow
    //   140: astore #5
    //   142: goto -> 104
    //   145: iconst_0
    //   146: istore_1
    //   147: goto -> 25
    // Exception table:
    //   from	to	target	type
    //   2	8	133	finally
    //   15	20	133	finally
    //   25	27	133	finally
    //   92	99	140	java/lang/InterruptedException
    //   135	137	133	finally
  }
  
  private static RenderScript internalCreate(Context paramContext, int paramInt1, ContextType paramContextType, int paramInt2) {
    // Byte code:
    //   0: new androidx/renderscript/RenderScript
    //   3: dup
    //   4: aload_0
    //   5: invokespecial <init> : (Landroid/content/Context;)V
    //   8: astore #10
    //   10: getstatic androidx/renderscript/RenderScript.sSdkVersion : I
    //   13: istore #4
    //   15: iload #4
    //   17: iconst_m1
    //   18: if_icmpne -> 28
    //   21: iload_1
    //   22: putstatic androidx/renderscript/RenderScript.sSdkVersion : I
    //   25: goto -> 34
    //   28: iload #4
    //   30: iload_1
    //   31: if_icmpne -> 834
    //   34: getstatic androidx/renderscript/RenderScript.sSdkVersion : I
    //   37: aload_0
    //   38: invokestatic setupNative : (ILandroid/content/Context;)Z
    //   41: putstatic androidx/renderscript/RenderScript.useNative : Z
    //   44: getstatic androidx/renderscript/RenderScript.lock : Ljava/lang/Object;
    //   47: astore_0
    //   48: aload_0
    //   49: monitorenter
    //   50: getstatic androidx/renderscript/RenderScript.sInitialized : Z
    //   53: istore #6
    //   55: aconst_null
    //   56: astore #9
    //   58: iload #6
    //   60: ifne -> 327
    //   63: ldc_w 'dalvik.system.VMRuntime'
    //   66: invokestatic forName : (Ljava/lang/String;)Ljava/lang/Class;
    //   69: astore #11
    //   71: aload #11
    //   73: ldc_w 'getRuntime'
    //   76: iconst_0
    //   77: anewarray java/lang/Class
    //   80: invokevirtual getDeclaredMethod : (Ljava/lang/String;[Ljava/lang/Class;)Ljava/lang/reflect/Method;
    //   83: aconst_null
    //   84: iconst_0
    //   85: anewarray java/lang/Object
    //   88: invokevirtual invoke : (Ljava/lang/Object;[Ljava/lang/Object;)Ljava/lang/Object;
    //   91: putstatic androidx/renderscript/RenderScript.sRuntime : Ljava/lang/Object;
    //   94: getstatic java/lang/Integer.TYPE : Ljava/lang/Class;
    //   97: astore #12
    //   99: aload #11
    //   101: ldc_w 'registerNativeAllocation'
    //   104: iconst_1
    //   105: anewarray java/lang/Class
    //   108: dup
    //   109: iconst_0
    //   110: aload #12
    //   112: aastore
    //   113: invokevirtual getDeclaredMethod : (Ljava/lang/String;[Ljava/lang/Class;)Ljava/lang/reflect/Method;
    //   116: putstatic androidx/renderscript/RenderScript.registerNativeAllocation : Ljava/lang/reflect/Method;
    //   119: aload #11
    //   121: ldc_w 'registerNativeFree'
    //   124: iconst_1
    //   125: anewarray java/lang/Class
    //   128: dup
    //   129: iconst_0
    //   130: aload #12
    //   132: aastore
    //   133: invokevirtual getDeclaredMethod : (Ljava/lang/String;[Ljava/lang/Class;)Ljava/lang/reflect/Method;
    //   136: putstatic androidx/renderscript/RenderScript.registerNativeFree : Ljava/lang/reflect/Method;
    //   139: iconst_1
    //   140: putstatic androidx/renderscript/RenderScript.sUseGCHooks : Z
    //   143: goto -> 159
    //   146: ldc 'RenderScript_jni'
    //   148: ldc_w 'No GC methods'
    //   151: invokestatic e : (Ljava/lang/String;Ljava/lang/String;)I
    //   154: pop
    //   155: iconst_0
    //   156: putstatic androidx/renderscript/RenderScript.sUseGCHooks : Z
    //   159: getstatic android/os/Build$VERSION.SDK_INT : I
    //   162: bipush #23
    //   164: if_icmpge -> 215
    //   167: aload #10
    //   169: getfield mNativeLibDir : Ljava/lang/String;
    //   172: ifnull -> 215
    //   175: new java/lang/StringBuilder
    //   178: dup
    //   179: invokespecial <init> : ()V
    //   182: astore #11
    //   184: aload #11
    //   186: aload #10
    //   188: getfield mNativeLibDir : Ljava/lang/String;
    //   191: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   194: pop
    //   195: aload #11
    //   197: ldc_w '/librsjni_androidx.so'
    //   200: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   203: pop
    //   204: aload #11
    //   206: invokevirtual toString : ()Ljava/lang/String;
    //   209: invokestatic load : (Ljava/lang/String;)V
    //   212: goto -> 221
    //   215: ldc_w 'rsjni_androidx'
    //   218: invokestatic loadLibrary : (Ljava/lang/String;)V
    //   221: iconst_1
    //   222: putstatic androidx/renderscript/RenderScript.sInitialized : Z
    //   225: invokestatic rsnSystemGetPointerSize : ()I
    //   228: putstatic androidx/renderscript/RenderScript.sPointerSize : I
    //   231: goto -> 327
    //   234: astore_2
    //   235: new java/lang/StringBuilder
    //   238: dup
    //   239: invokespecial <init> : ()V
    //   242: astore #9
    //   244: aload #9
    //   246: ldc_w 'Error loading RS jni library: '
    //   249: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   252: pop
    //   253: aload #9
    //   255: aload_2
    //   256: invokevirtual append : (Ljava/lang/Object;)Ljava/lang/StringBuilder;
    //   259: pop
    //   260: ldc 'RenderScript_jni'
    //   262: aload #9
    //   264: invokevirtual toString : ()Ljava/lang/String;
    //   267: invokestatic e : (Ljava/lang/String;Ljava/lang/String;)I
    //   270: pop
    //   271: new java/lang/StringBuilder
    //   274: dup
    //   275: invokespecial <init> : ()V
    //   278: astore #9
    //   280: aload #9
    //   282: ldc_w 'Error loading RS jni library: '
    //   285: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   288: pop
    //   289: aload #9
    //   291: aload_2
    //   292: invokevirtual append : (Ljava/lang/Object;)Ljava/lang/StringBuilder;
    //   295: pop
    //   296: aload #9
    //   298: ldc_w ' Support lib API: '
    //   301: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   304: pop
    //   305: aload #9
    //   307: sipush #2301
    //   310: invokevirtual append : (I)Ljava/lang/StringBuilder;
    //   313: pop
    //   314: new androidx/renderscript/RSRuntimeException
    //   317: dup
    //   318: aload #9
    //   320: invokevirtual toString : ()Ljava/lang/String;
    //   323: invokespecial <init> : (Ljava/lang/String;)V
    //   326: athrow
    //   327: aload_0
    //   328: monitorexit
    //   329: getstatic androidx/renderscript/RenderScript.useNative : Z
    //   332: ifeq -> 347
    //   335: ldc 'RenderScript_jni'
    //   337: ldc_w 'RS native mode'
    //   340: invokestatic v : (Ljava/lang/String;Ljava/lang/String;)I
    //   343: pop
    //   344: goto -> 356
    //   347: ldc 'RenderScript_jni'
    //   349: ldc_w 'RS compat mode'
    //   352: invokestatic v : (Ljava/lang/String;Ljava/lang/String;)I
    //   355: pop
    //   356: getstatic android/os/Build$VERSION.SDK_INT : I
    //   359: istore #5
    //   361: iconst_1
    //   362: putstatic androidx/renderscript/RenderScript.useIOlib : Z
    //   365: iload_1
    //   366: iload #5
    //   368: if_icmpge -> 378
    //   371: iload #5
    //   373: istore #4
    //   375: goto -> 381
    //   378: iload_1
    //   379: istore #4
    //   381: aload #9
    //   383: astore_0
    //   384: iload #5
    //   386: bipush #23
    //   388: if_icmpge -> 433
    //   391: aload #9
    //   393: astore_0
    //   394: aload #10
    //   396: getfield mNativeLibDir : Ljava/lang/String;
    //   399: ifnull -> 433
    //   402: new java/lang/StringBuilder
    //   405: dup
    //   406: invokespecial <init> : ()V
    //   409: astore_0
    //   410: aload_0
    //   411: aload #10
    //   413: getfield mNativeLibDir : Ljava/lang/String;
    //   416: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   419: pop
    //   420: aload_0
    //   421: ldc_w '/libRSSupport.so'
    //   424: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   427: pop
    //   428: aload_0
    //   429: invokevirtual toString : ()Ljava/lang/String;
    //   432: astore_0
    //   433: aload #10
    //   435: getstatic androidx/renderscript/RenderScript.useNative : Z
    //   438: iload #4
    //   440: aload_0
    //   441: invokevirtual nLoadSO : (ZILjava/lang/String;)Z
    //   444: ifne -> 628
    //   447: getstatic androidx/renderscript/RenderScript.useNative : Z
    //   450: ifeq -> 466
    //   453: ldc 'RenderScript_jni'
    //   455: ldc_w 'Unable to load libRS.so, falling back to compat mode'
    //   458: invokestatic v : (Ljava/lang/String;Ljava/lang/String;)I
    //   461: pop
    //   462: iconst_0
    //   463: putstatic androidx/renderscript/RenderScript.useNative : Z
    //   466: iload #5
    //   468: bipush #23
    //   470: if_icmpge -> 488
    //   473: aload #10
    //   475: getfield mNativeLibDir : Ljava/lang/String;
    //   478: ifnull -> 488
    //   481: aload_0
    //   482: invokestatic load : (Ljava/lang/String;)V
    //   485: goto -> 494
    //   488: ldc_w 'RSSupport'
    //   491: invokestatic loadLibrary : (Ljava/lang/String;)V
    //   494: aload #10
    //   496: iconst_0
    //   497: iload #4
    //   499: aload_0
    //   500: invokevirtual nLoadSO : (ZILjava/lang/String;)Z
    //   503: ifeq -> 509
    //   506: goto -> 628
    //   509: ldc 'RenderScript_jni'
    //   511: ldc_w 'Error loading RS Compat library: nLoadSO() failed; Support lib version: 2301'
    //   514: invokestatic e : (Ljava/lang/String;Ljava/lang/String;)I
    //   517: pop
    //   518: new androidx/renderscript/RSRuntimeException
    //   521: dup
    //   522: ldc_w 'Error loading libRSSupport library, Support lib version: 2301'
    //   525: invokespecial <init> : (Ljava/lang/String;)V
    //   528: athrow
    //   529: astore_0
    //   530: new java/lang/StringBuilder
    //   533: dup
    //   534: invokespecial <init> : ()V
    //   537: astore_2
    //   538: aload_2
    //   539: ldc_w 'Error loading RS Compat library: '
    //   542: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   545: pop
    //   546: aload_2
    //   547: aload_0
    //   548: invokevirtual append : (Ljava/lang/Object;)Ljava/lang/StringBuilder;
    //   551: pop
    //   552: aload_2
    //   553: ldc_w ' Support lib version: '
    //   556: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   559: pop
    //   560: aload_2
    //   561: sipush #2301
    //   564: invokevirtual append : (I)Ljava/lang/StringBuilder;
    //   567: pop
    //   568: ldc 'RenderScript_jni'
    //   570: aload_2
    //   571: invokevirtual toString : ()Ljava/lang/String;
    //   574: invokestatic e : (Ljava/lang/String;Ljava/lang/String;)I
    //   577: pop
    //   578: new java/lang/StringBuilder
    //   581: dup
    //   582: invokespecial <init> : ()V
    //   585: astore_2
    //   586: aload_2
    //   587: ldc_w 'Error loading RS Compat library: '
    //   590: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   593: pop
    //   594: aload_2
    //   595: aload_0
    //   596: invokevirtual append : (Ljava/lang/Object;)Ljava/lang/StringBuilder;
    //   599: pop
    //   600: aload_2
    //   601: ldc_w ' Support lib version: '
    //   604: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   607: pop
    //   608: aload_2
    //   609: sipush #2301
    //   612: invokevirtual append : (I)Ljava/lang/StringBuilder;
    //   615: pop
    //   616: new androidx/renderscript/RSRuntimeException
    //   619: dup
    //   620: aload_2
    //   621: invokevirtual toString : ()Ljava/lang/String;
    //   624: invokespecial <init> : (Ljava/lang/String;)V
    //   627: athrow
    //   628: getstatic androidx/renderscript/RenderScript.useIOlib : Z
    //   631: ifeq -> 674
    //   634: ldc_w 'RSSupportIO'
    //   637: invokestatic loadLibrary : (Ljava/lang/String;)V
    //   640: goto -> 647
    //   643: iconst_0
    //   644: putstatic androidx/renderscript/RenderScript.useIOlib : Z
    //   647: getstatic androidx/renderscript/RenderScript.useIOlib : Z
    //   650: ifeq -> 661
    //   653: aload #10
    //   655: invokevirtual nLoadIOSO : ()Z
    //   658: ifne -> 674
    //   661: ldc 'RenderScript_jni'
    //   663: ldc_w 'Unable to load libRSSupportIO.so, USAGE_IO not supported'
    //   666: invokestatic v : (Ljava/lang/String;Ljava/lang/String;)I
    //   669: pop
    //   670: iconst_0
    //   671: putstatic androidx/renderscript/RenderScript.useIOlib : Z
    //   674: iload #4
    //   676: bipush #23
    //   678: if_icmplt -> 733
    //   681: aload #10
    //   683: iconst_1
    //   684: putfield mEnableMultiInput : Z
    //   687: ldc_w 'blasV8'
    //   690: invokestatic loadLibrary : (Ljava/lang/String;)V
    //   693: goto -> 733
    //   696: astore_0
    //   697: new java/lang/StringBuilder
    //   700: dup
    //   701: invokespecial <init> : ()V
    //   704: astore #9
    //   706: aload #9
    //   708: ldc_w 'Unable to load BLAS lib, ONLY BNNM will be supported: '
    //   711: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   714: pop
    //   715: aload #9
    //   717: aload_0
    //   718: invokevirtual append : (Ljava/lang/Object;)Ljava/lang/StringBuilder;
    //   721: pop
    //   722: ldc 'RenderScript_jni'
    //   724: aload #9
    //   726: invokevirtual toString : ()Ljava/lang/String;
    //   729: invokestatic v : (Ljava/lang/String;Ljava/lang/String;)I
    //   732: pop
    //   733: aload #10
    //   735: aload #10
    //   737: invokevirtual nDeviceCreate : ()J
    //   740: iconst_0
    //   741: iload_1
    //   742: aload_2
    //   743: getfield mID : I
    //   746: aload #10
    //   748: getfield mNativeLibDir : Ljava/lang/String;
    //   751: invokevirtual nContextCreate : (JIIILjava/lang/String;)J
    //   754: lstore #7
    //   756: aload #10
    //   758: lload #7
    //   760: putfield mContext : J
    //   763: aload #10
    //   765: aload_2
    //   766: putfield mContextType : Landroidx/renderscript/RenderScript$ContextType;
    //   769: aload #10
    //   771: iload_3
    //   772: putfield mContextFlags : I
    //   775: aload #10
    //   777: iload_1
    //   778: putfield mContextSdkVersion : I
    //   781: aload #10
    //   783: iload #4
    //   785: putfield mDispatchAPILevel : I
    //   788: lload #7
    //   790: lconst_0
    //   791: lcmp
    //   792: ifeq -> 818
    //   795: new androidx/renderscript/RenderScript$MessageThread
    //   798: dup
    //   799: aload #10
    //   801: invokespecial <init> : (Landroidx/renderscript/RenderScript;)V
    //   804: astore_0
    //   805: aload #10
    //   807: aload_0
    //   808: putfield mMessageThread : Landroidx/renderscript/RenderScript$MessageThread;
    //   811: aload_0
    //   812: invokevirtual start : ()V
    //   815: aload #10
    //   817: areturn
    //   818: new androidx/renderscript/RSDriverException
    //   821: dup
    //   822: ldc_w 'Failed to create RS context.'
    //   825: invokespecial <init> : (Ljava/lang/String;)V
    //   828: athrow
    //   829: astore_2
    //   830: aload_0
    //   831: monitorexit
    //   832: aload_2
    //   833: athrow
    //   834: new androidx/renderscript/RSRuntimeException
    //   837: dup
    //   838: ldc_w 'Can't have two contexts with different SDK versions in support lib'
    //   841: invokespecial <init> : (Ljava/lang/String;)V
    //   844: athrow
    //   845: astore #11
    //   847: goto -> 146
    //   850: astore_0
    //   851: goto -> 643
    // Exception table:
    //   from	to	target	type
    //   50	55	829	finally
    //   63	143	845	java/lang/Exception
    //   63	143	829	finally
    //   146	159	829	finally
    //   159	212	234	java/lang/UnsatisfiedLinkError
    //   159	212	829	finally
    //   215	221	234	java/lang/UnsatisfiedLinkError
    //   215	221	829	finally
    //   221	231	234	java/lang/UnsatisfiedLinkError
    //   221	231	829	finally
    //   235	327	829	finally
    //   327	329	829	finally
    //   473	485	529	java/lang/UnsatisfiedLinkError
    //   488	494	529	java/lang/UnsatisfiedLinkError
    //   634	640	850	java/lang/UnsatisfiedLinkError
    //   687	693	696	java/lang/UnsatisfiedLinkError
    //   830	832	829	finally
  }
  
  public static void releaseAllContexts() {
    synchronized (mProcessContextList) {
      ArrayList<RenderScript> arrayList = mProcessContextList;
      mProcessContextList = new ArrayList<RenderScript>();
      for (RenderScript renderScript : arrayList) {
        renderScript.mIsProcessContext = false;
        renderScript.destroy();
      } 
      arrayList.clear();
      return;
    } 
  }
  
  static native int rsnSystemGetPointerSize();
  
  public static void setBlackList(String paramString) {
    if (paramString != null)
      mBlackList = paramString; 
  }
  
  public static void setupDiskCache(File paramFile) {
    paramFile = new File(paramFile, "com.android.renderscript.cache");
    mCachePath = paramFile.getAbsolutePath();
    paramFile.mkdirs();
  }
  
  private static boolean setupNative(int paramInt, Context paramContext) {
    // Byte code:
    //   0: getstatic android/os/Build$VERSION.SDK_INT : I
    //   3: istore_0
    //   4: getstatic androidx/renderscript/RenderScript.sNative : I
    //   7: iconst_m1
    //   8: if_icmpne -> 196
    //   11: ldc_w 'android.os.SystemProperties'
    //   14: invokestatic forName : (Ljava/lang/String;)Ljava/lang/Class;
    //   17: ldc_w 'getInt'
    //   20: iconst_2
    //   21: anewarray java/lang/Class
    //   24: dup
    //   25: iconst_0
    //   26: ldc_w java/lang/String
    //   29: aastore
    //   30: dup
    //   31: iconst_1
    //   32: getstatic java/lang/Integer.TYPE : Ljava/lang/Class;
    //   35: aastore
    //   36: invokevirtual getDeclaredMethod : (Ljava/lang/String;[Ljava/lang/Class;)Ljava/lang/reflect/Method;
    //   39: aconst_null
    //   40: iconst_2
    //   41: anewarray java/lang/Object
    //   44: dup
    //   45: iconst_0
    //   46: ldc_w 'debug.rs.forcecompat'
    //   49: aastore
    //   50: dup
    //   51: iconst_1
    //   52: new java/lang/Integer
    //   55: dup
    //   56: iconst_0
    //   57: invokespecial <init> : (I)V
    //   60: aastore
    //   61: invokevirtual invoke : (Ljava/lang/Object;[Ljava/lang/Object;)Ljava/lang/Object;
    //   64: checkcast java/lang/Integer
    //   67: invokevirtual intValue : ()I
    //   70: istore_0
    //   71: goto -> 76
    //   74: iconst_0
    //   75: istore_0
    //   76: iload_0
    //   77: ifne -> 87
    //   80: iconst_1
    //   81: putstatic androidx/renderscript/RenderScript.sNative : I
    //   84: goto -> 91
    //   87: iconst_0
    //   88: putstatic androidx/renderscript/RenderScript.sNative : I
    //   91: getstatic androidx/renderscript/RenderScript.sNative : I
    //   94: iconst_1
    //   95: if_icmpne -> 196
    //   98: aload_1
    //   99: invokevirtual getPackageManager : ()Landroid/content/pm/PackageManager;
    //   102: aload_1
    //   103: invokevirtual getPackageName : ()Ljava/lang/String;
    //   106: sipush #128
    //   109: invokevirtual getApplicationInfo : (Ljava/lang/String;I)Landroid/content/pm/ApplicationInfo;
    //   112: astore_1
    //   113: ldc_w 'android.renderscript.RenderScript'
    //   116: invokestatic forName : (Ljava/lang/String;)Ljava/lang/Class;
    //   119: ldc_w 'getMinorID'
    //   122: iconst_0
    //   123: anewarray java/lang/Class
    //   126: invokevirtual getDeclaredMethod : (Ljava/lang/String;[Ljava/lang/Class;)Ljava/lang/reflect/Method;
    //   129: aconst_null
    //   130: iconst_0
    //   131: anewarray java/lang/Object
    //   134: invokevirtual invoke : (Ljava/lang/Object;[Ljava/lang/Object;)Ljava/lang/Object;
    //   137: checkcast java/lang/Long
    //   140: invokevirtual longValue : ()J
    //   143: lstore_2
    //   144: goto -> 149
    //   147: lconst_0
    //   148: lstore_2
    //   149: aload_1
    //   150: getfield metaData : Landroid/os/Bundle;
    //   153: astore #4
    //   155: aload #4
    //   157: ifnull -> 196
    //   160: aload #4
    //   162: ldc_w 'androidx.renderscript.EnableAsyncTeardown'
    //   165: invokevirtual getBoolean : (Ljava/lang/String;)Z
    //   168: iconst_1
    //   169: if_icmpne -> 182
    //   172: lload_2
    //   173: lconst_0
    //   174: lcmp
    //   175: ifne -> 182
    //   178: iconst_0
    //   179: putstatic androidx/renderscript/RenderScript.sNative : I
    //   182: aload_1
    //   183: getfield metaData : Landroid/os/Bundle;
    //   186: ldc_w 'androidx.renderscript.EnableBlurWorkaround'
    //   189: invokevirtual getBoolean : (Ljava/lang/String;)Z
    //   192: pop
    //   193: goto -> 196
    //   196: getstatic androidx/renderscript/RenderScript.sNative : I
    //   199: iconst_1
    //   200: if_icmpne -> 295
    //   203: getstatic androidx/renderscript/RenderScript.mBlackList : Ljava/lang/String;
    //   206: invokevirtual length : ()I
    //   209: ifle -> 293
    //   212: new java/lang/StringBuilder
    //   215: dup
    //   216: invokespecial <init> : ()V
    //   219: astore_1
    //   220: aload_1
    //   221: bipush #40
    //   223: invokevirtual append : (C)Ljava/lang/StringBuilder;
    //   226: pop
    //   227: aload_1
    //   228: getstatic android/os/Build.MANUFACTURER : Ljava/lang/String;
    //   231: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   234: pop
    //   235: aload_1
    //   236: bipush #58
    //   238: invokevirtual append : (C)Ljava/lang/StringBuilder;
    //   241: pop
    //   242: aload_1
    //   243: getstatic android/os/Build.PRODUCT : Ljava/lang/String;
    //   246: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   249: pop
    //   250: aload_1
    //   251: bipush #58
    //   253: invokevirtual append : (C)Ljava/lang/StringBuilder;
    //   256: pop
    //   257: aload_1
    //   258: getstatic android/os/Build.MODEL : Ljava/lang/String;
    //   261: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   264: pop
    //   265: aload_1
    //   266: bipush #41
    //   268: invokevirtual append : (C)Ljava/lang/StringBuilder;
    //   271: pop
    //   272: aload_1
    //   273: invokevirtual toString : ()Ljava/lang/String;
    //   276: astore_1
    //   277: getstatic androidx/renderscript/RenderScript.mBlackList : Ljava/lang/String;
    //   280: aload_1
    //   281: invokevirtual contains : (Ljava/lang/CharSequence;)Z
    //   284: ifeq -> 293
    //   287: iconst_0
    //   288: putstatic androidx/renderscript/RenderScript.sNative : I
    //   291: iconst_0
    //   292: ireturn
    //   293: iconst_1
    //   294: ireturn
    //   295: iconst_0
    //   296: ireturn
    //   297: astore #4
    //   299: goto -> 74
    //   302: astore_1
    //   303: iconst_1
    //   304: ireturn
    //   305: astore #4
    //   307: goto -> 147
    // Exception table:
    //   from	to	target	type
    //   11	71	297	java/lang/Exception
    //   98	113	302	android/content/pm/PackageManager$NameNotFoundException
    //   113	144	305	java/lang/Exception
  }
  
  public void contextDump() {
    validate();
    nContextDump(0);
  }
  
  public void destroy() {
    if (this.mIsProcessContext)
      return; 
    validate();
    helpDestroy();
  }
  
  protected void finalize() throws Throwable {
    helpDestroy();
    super.finalize();
  }
  
  public void finish() {
    nContextFinish();
  }
  
  public final Context getApplicationContext() {
    return this.mApplicationContext;
  }
  
  int getDispatchAPILevel() {
    return this.mDispatchAPILevel;
  }
  
  public RSErrorHandler getErrorHandler() {
    return this.mErrorCallback;
  }
  
  public RSMessageHandler getMessageHandler() {
    return this.mMessageCallback;
  }
  
  boolean isAlive() {
    return (this.mContext != 0L);
  }
  
  boolean isUseNative() {
    return useNative;
  }
  
  void nAllocationCopyFromBitmap(long paramLong, Bitmap paramBitmap) {
    // Byte code:
    //   0: aload_0
    //   1: monitorenter
    //   2: aload_0
    //   3: invokevirtual validate : ()V
    //   6: aload_0
    //   7: aload_0
    //   8: getfield mContext : J
    //   11: lload_1
    //   12: aload_3
    //   13: invokevirtual rsnAllocationCopyFromBitmap : (JJLandroid/graphics/Bitmap;)V
    //   16: aload_0
    //   17: monitorexit
    //   18: return
    //   19: astore_3
    //   20: aload_0
    //   21: monitorexit
    //   22: aload_3
    //   23: athrow
    // Exception table:
    //   from	to	target	type
    //   2	16	19	finally
  }
  
  void nAllocationCopyToBitmap(long paramLong, Bitmap paramBitmap) {
    // Byte code:
    //   0: aload_0
    //   1: monitorenter
    //   2: aload_0
    //   3: invokevirtual validate : ()V
    //   6: aload_0
    //   7: aload_0
    //   8: getfield mContext : J
    //   11: lload_1
    //   12: aload_3
    //   13: invokevirtual rsnAllocationCopyToBitmap : (JJLandroid/graphics/Bitmap;)V
    //   16: aload_0
    //   17: monitorexit
    //   18: return
    //   19: astore_3
    //   20: aload_0
    //   21: monitorexit
    //   22: aload_3
    //   23: athrow
    // Exception table:
    //   from	to	target	type
    //   2	16	19	finally
  }
  
  long nAllocationCreateBitmapBackedAllocation(long paramLong, int paramInt1, Bitmap paramBitmap, int paramInt2) {
    // Byte code:
    //   0: aload_0
    //   1: monitorenter
    //   2: aload_0
    //   3: invokevirtual validate : ()V
    //   6: aload_0
    //   7: aload_0
    //   8: getfield mContext : J
    //   11: lload_1
    //   12: iload_3
    //   13: aload #4
    //   15: iload #5
    //   17: invokevirtual rsnAllocationCreateBitmapBackedAllocation : (JJILandroid/graphics/Bitmap;I)J
    //   20: lstore_1
    //   21: aload_0
    //   22: monitorexit
    //   23: lload_1
    //   24: lreturn
    //   25: astore #4
    //   27: aload_0
    //   28: monitorexit
    //   29: aload #4
    //   31: athrow
    // Exception table:
    //   from	to	target	type
    //   2	21	25	finally
  }
  
  long nAllocationCreateBitmapRef(long paramLong, Bitmap paramBitmap) {
    // Byte code:
    //   0: aload_0
    //   1: monitorenter
    //   2: aload_0
    //   3: invokevirtual validate : ()V
    //   6: aload_0
    //   7: aload_0
    //   8: getfield mContext : J
    //   11: lload_1
    //   12: aload_3
    //   13: invokevirtual rsnAllocationCreateBitmapRef : (JJLandroid/graphics/Bitmap;)J
    //   16: lstore_1
    //   17: aload_0
    //   18: monitorexit
    //   19: lload_1
    //   20: lreturn
    //   21: astore_3
    //   22: aload_0
    //   23: monitorexit
    //   24: aload_3
    //   25: athrow
    // Exception table:
    //   from	to	target	type
    //   2	17	21	finally
  }
  
  long nAllocationCreateFromAssetStream(int paramInt1, int paramInt2, int paramInt3) {
    // Byte code:
    //   0: aload_0
    //   1: monitorenter
    //   2: aload_0
    //   3: invokevirtual validate : ()V
    //   6: aload_0
    //   7: aload_0
    //   8: getfield mContext : J
    //   11: iload_1
    //   12: iload_2
    //   13: iload_3
    //   14: invokevirtual rsnAllocationCreateFromAssetStream : (JIII)J
    //   17: lstore #4
    //   19: aload_0
    //   20: monitorexit
    //   21: lload #4
    //   23: lreturn
    //   24: astore #6
    //   26: aload_0
    //   27: monitorexit
    //   28: aload #6
    //   30: athrow
    // Exception table:
    //   from	to	target	type
    //   2	19	24	finally
  }
  
  long nAllocationCreateFromBitmap(long paramLong, int paramInt1, Bitmap paramBitmap, int paramInt2) {
    // Byte code:
    //   0: aload_0
    //   1: monitorenter
    //   2: aload_0
    //   3: invokevirtual validate : ()V
    //   6: aload_0
    //   7: aload_0
    //   8: getfield mContext : J
    //   11: lload_1
    //   12: iload_3
    //   13: aload #4
    //   15: iload #5
    //   17: invokevirtual rsnAllocationCreateFromBitmap : (JJILandroid/graphics/Bitmap;I)J
    //   20: lstore_1
    //   21: aload_0
    //   22: monitorexit
    //   23: lload_1
    //   24: lreturn
    //   25: astore #4
    //   27: aload_0
    //   28: monitorexit
    //   29: aload #4
    //   31: athrow
    // Exception table:
    //   from	to	target	type
    //   2	21	25	finally
  }
  
  long nAllocationCreateTyped(long paramLong1, int paramInt1, int paramInt2, long paramLong2) {
    // Byte code:
    //   0: aload_0
    //   1: monitorenter
    //   2: aload_0
    //   3: invokevirtual validate : ()V
    //   6: aload_0
    //   7: aload_0
    //   8: getfield mContext : J
    //   11: lload_1
    //   12: iload_3
    //   13: iload #4
    //   15: lload #5
    //   17: invokevirtual rsnAllocationCreateTyped : (JJIIJ)J
    //   20: lstore_1
    //   21: aload_0
    //   22: monitorexit
    //   23: lload_1
    //   24: lreturn
    //   25: astore #7
    //   27: aload_0
    //   28: monitorexit
    //   29: aload #7
    //   31: athrow
    // Exception table:
    //   from	to	target	type
    //   2	21	25	finally
  }
  
  long nAllocationCubeCreateFromBitmap(long paramLong, int paramInt1, Bitmap paramBitmap, int paramInt2) {
    // Byte code:
    //   0: aload_0
    //   1: monitorenter
    //   2: aload_0
    //   3: invokevirtual validate : ()V
    //   6: aload_0
    //   7: aload_0
    //   8: getfield mContext : J
    //   11: lload_1
    //   12: iload_3
    //   13: aload #4
    //   15: iload #5
    //   17: invokevirtual rsnAllocationCubeCreateFromBitmap : (JJILandroid/graphics/Bitmap;I)J
    //   20: lstore_1
    //   21: aload_0
    //   22: monitorexit
    //   23: lload_1
    //   24: lreturn
    //   25: astore #4
    //   27: aload_0
    //   28: monitorexit
    //   29: aload #4
    //   31: athrow
    // Exception table:
    //   from	to	target	type
    //   2	21	25	finally
  }
  
  void nAllocationData1D(long paramLong, int paramInt1, int paramInt2, int paramInt3, Object paramObject, int paramInt4, Element.DataType paramDataType, int paramInt5, boolean paramBoolean) {
    // Byte code:
    //   0: aload_0
    //   1: monitorenter
    //   2: aload_0
    //   3: invokevirtual validate : ()V
    //   6: aload_0
    //   7: aload_0
    //   8: getfield mContext : J
    //   11: lload_1
    //   12: iload_3
    //   13: iload #4
    //   15: iload #5
    //   17: aload #6
    //   19: iload #7
    //   21: aload #8
    //   23: getfield mID : I
    //   26: iload #9
    //   28: iload #10
    //   30: invokevirtual rsnAllocationData1D : (JJIIILjava/lang/Object;IIIZ)V
    //   33: aload_0
    //   34: monitorexit
    //   35: return
    //   36: astore #6
    //   38: aload_0
    //   39: monitorexit
    //   40: aload #6
    //   42: athrow
    // Exception table:
    //   from	to	target	type
    //   2	33	36	finally
  }
  
  void nAllocationData2D(long paramLong1, int paramInt1, int paramInt2, int paramInt3, int paramInt4, int paramInt5, int paramInt6, long paramLong2, int paramInt7, int paramInt8, int paramInt9, int paramInt10) {
    // Byte code:
    //   0: aload_0
    //   1: monitorenter
    //   2: aload_0
    //   3: invokevirtual validate : ()V
    //   6: aload_0
    //   7: aload_0
    //   8: getfield mContext : J
    //   11: lload_1
    //   12: iload_3
    //   13: iload #4
    //   15: iload #5
    //   17: iload #6
    //   19: iload #7
    //   21: iload #8
    //   23: lload #9
    //   25: iload #11
    //   27: iload #12
    //   29: iload #13
    //   31: iload #14
    //   33: invokevirtual rsnAllocationData2D : (JJIIIIIIJIIII)V
    //   36: aload_0
    //   37: monitorexit
    //   38: return
    //   39: astore #15
    //   41: aload_0
    //   42: monitorexit
    //   43: aload #15
    //   45: athrow
    // Exception table:
    //   from	to	target	type
    //   2	36	39	finally
  }
  
  void nAllocationData2D(long paramLong, int paramInt1, int paramInt2, int paramInt3, int paramInt4, int paramInt5, int paramInt6, Object paramObject, int paramInt7, Element.DataType paramDataType, int paramInt8, boolean paramBoolean) {
    // Byte code:
    //   0: aload_0
    //   1: monitorenter
    //   2: aload_0
    //   3: invokevirtual validate : ()V
    //   6: aload_0
    //   7: aload_0
    //   8: getfield mContext : J
    //   11: lload_1
    //   12: iload_3
    //   13: iload #4
    //   15: iload #5
    //   17: iload #6
    //   19: iload #7
    //   21: iload #8
    //   23: aload #9
    //   25: iload #10
    //   27: aload #11
    //   29: getfield mID : I
    //   32: iload #12
    //   34: iload #13
    //   36: invokevirtual rsnAllocationData2D : (JJIIIIIILjava/lang/Object;IIIZ)V
    //   39: aload_0
    //   40: monitorexit
    //   41: return
    //   42: astore #9
    //   44: aload_0
    //   45: monitorexit
    //   46: aload #9
    //   48: athrow
    // Exception table:
    //   from	to	target	type
    //   2	39	42	finally
  }
  
  void nAllocationData2D(long paramLong, int paramInt1, int paramInt2, int paramInt3, int paramInt4, Bitmap paramBitmap) {
    // Byte code:
    //   0: aload_0
    //   1: monitorenter
    //   2: aload_0
    //   3: invokevirtual validate : ()V
    //   6: aload_0
    //   7: aload_0
    //   8: getfield mContext : J
    //   11: lload_1
    //   12: iload_3
    //   13: iload #4
    //   15: iload #5
    //   17: iload #6
    //   19: aload #7
    //   21: invokevirtual rsnAllocationData2D : (JJIIIILandroid/graphics/Bitmap;)V
    //   24: aload_0
    //   25: monitorexit
    //   26: return
    //   27: astore #7
    //   29: aload_0
    //   30: monitorexit
    //   31: aload #7
    //   33: athrow
    // Exception table:
    //   from	to	target	type
    //   2	24	27	finally
  }
  
  void nAllocationData3D(long paramLong1, int paramInt1, int paramInt2, int paramInt3, int paramInt4, int paramInt5, int paramInt6, int paramInt7, long paramLong2, int paramInt8, int paramInt9, int paramInt10, int paramInt11) {
    // Byte code:
    //   0: aload_0
    //   1: monitorenter
    //   2: aload_0
    //   3: invokevirtual validate : ()V
    //   6: aload_0
    //   7: aload_0
    //   8: getfield mContext : J
    //   11: lload_1
    //   12: iload_3
    //   13: iload #4
    //   15: iload #5
    //   17: iload #6
    //   19: iload #7
    //   21: iload #8
    //   23: iload #9
    //   25: lload #10
    //   27: iload #12
    //   29: iload #13
    //   31: iload #14
    //   33: iload #15
    //   35: invokevirtual rsnAllocationData3D : (JJIIIIIIIJIIII)V
    //   38: aload_0
    //   39: monitorexit
    //   40: return
    //   41: astore #16
    //   43: aload_0
    //   44: monitorexit
    //   45: aload #16
    //   47: athrow
    // Exception table:
    //   from	to	target	type
    //   2	38	41	finally
  }
  
  void nAllocationData3D(long paramLong, int paramInt1, int paramInt2, int paramInt3, int paramInt4, int paramInt5, int paramInt6, int paramInt7, Object paramObject, int paramInt8, Element.DataType paramDataType, int paramInt9, boolean paramBoolean) {
    // Byte code:
    //   0: aload_0
    //   1: monitorenter
    //   2: aload_0
    //   3: invokevirtual validate : ()V
    //   6: aload_0
    //   7: aload_0
    //   8: getfield mContext : J
    //   11: lload_1
    //   12: iload_3
    //   13: iload #4
    //   15: iload #5
    //   17: iload #6
    //   19: iload #7
    //   21: iload #8
    //   23: iload #9
    //   25: aload #10
    //   27: iload #11
    //   29: aload #12
    //   31: getfield mID : I
    //   34: iload #13
    //   36: iload #14
    //   38: invokevirtual rsnAllocationData3D : (JJIIIIIIILjava/lang/Object;IIIZ)V
    //   41: aload_0
    //   42: monitorexit
    //   43: return
    //   44: astore #10
    //   46: aload_0
    //   47: monitorexit
    //   48: aload #10
    //   50: athrow
    // Exception table:
    //   from	to	target	type
    //   2	41	44	finally
  }
  
  void nAllocationElementData1D(long paramLong, int paramInt1, int paramInt2, int paramInt3, byte[] paramArrayOfbyte, int paramInt4) {
    // Byte code:
    //   0: aload_0
    //   1: monitorenter
    //   2: aload_0
    //   3: invokevirtual validate : ()V
    //   6: aload_0
    //   7: aload_0
    //   8: getfield mContext : J
    //   11: lload_1
    //   12: iload_3
    //   13: iload #4
    //   15: iload #5
    //   17: aload #6
    //   19: iload #7
    //   21: invokevirtual rsnAllocationElementData1D : (JJIII[BI)V
    //   24: aload_0
    //   25: monitorexit
    //   26: return
    //   27: astore #6
    //   29: aload_0
    //   30: monitorexit
    //   31: aload #6
    //   33: athrow
    // Exception table:
    //   from	to	target	type
    //   2	24	27	finally
  }
  
  void nAllocationGenerateMipmaps(long paramLong) {
    // Byte code:
    //   0: aload_0
    //   1: monitorenter
    //   2: aload_0
    //   3: invokevirtual validate : ()V
    //   6: aload_0
    //   7: aload_0
    //   8: getfield mContext : J
    //   11: lload_1
    //   12: invokevirtual rsnAllocationGenerateMipmaps : (JJ)V
    //   15: aload_0
    //   16: monitorexit
    //   17: return
    //   18: astore_3
    //   19: aload_0
    //   20: monitorexit
    //   21: aload_3
    //   22: athrow
    // Exception table:
    //   from	to	target	type
    //   2	15	18	finally
  }
  
  ByteBuffer nAllocationGetByteBuffer(long paramLong, int paramInt1, int paramInt2, int paramInt3) {
    // Byte code:
    //   0: aload_0
    //   1: monitorenter
    //   2: aload_0
    //   3: invokevirtual validate : ()V
    //   6: aload_0
    //   7: aload_0
    //   8: getfield mContext : J
    //   11: lload_1
    //   12: iload_3
    //   13: iload #4
    //   15: iload #5
    //   17: invokevirtual rsnAllocationGetByteBuffer : (JJIII)Ljava/nio/ByteBuffer;
    //   20: astore #6
    //   22: aload_0
    //   23: monitorexit
    //   24: aload #6
    //   26: areturn
    //   27: astore #6
    //   29: aload_0
    //   30: monitorexit
    //   31: aload #6
    //   33: athrow
    // Exception table:
    //   from	to	target	type
    //   2	22	27	finally
  }
  
  long nAllocationGetStride(long paramLong) {
    // Byte code:
    //   0: aload_0
    //   1: monitorenter
    //   2: aload_0
    //   3: invokevirtual validate : ()V
    //   6: aload_0
    //   7: aload_0
    //   8: getfield mContext : J
    //   11: lload_1
    //   12: invokevirtual rsnAllocationGetStride : (JJ)J
    //   15: lstore_1
    //   16: aload_0
    //   17: monitorexit
    //   18: lload_1
    //   19: lreturn
    //   20: astore_3
    //   21: aload_0
    //   22: monitorexit
    //   23: aload_3
    //   24: athrow
    // Exception table:
    //   from	to	target	type
    //   2	16	20	finally
  }
  
  long nAllocationGetType(long paramLong) {
    // Byte code:
    //   0: aload_0
    //   1: monitorenter
    //   2: aload_0
    //   3: invokevirtual validate : ()V
    //   6: aload_0
    //   7: aload_0
    //   8: getfield mContext : J
    //   11: lload_1
    //   12: invokevirtual rsnAllocationGetType : (JJ)J
    //   15: lstore_1
    //   16: aload_0
    //   17: monitorexit
    //   18: lload_1
    //   19: lreturn
    //   20: astore_3
    //   21: aload_0
    //   22: monitorexit
    //   23: aload_3
    //   24: athrow
    // Exception table:
    //   from	to	target	type
    //   2	16	20	finally
  }
  
  void nAllocationIoReceive(long paramLong) {
    // Byte code:
    //   0: aload_0
    //   1: monitorenter
    //   2: aload_0
    //   3: invokevirtual validate : ()V
    //   6: aload_0
    //   7: aload_0
    //   8: getfield mContext : J
    //   11: lload_1
    //   12: invokevirtual rsnAllocationIoReceive : (JJ)V
    //   15: aload_0
    //   16: monitorexit
    //   17: return
    //   18: astore_3
    //   19: aload_0
    //   20: monitorexit
    //   21: aload_3
    //   22: athrow
    // Exception table:
    //   from	to	target	type
    //   2	15	18	finally
  }
  
  void nAllocationIoSend(long paramLong) {
    // Byte code:
    //   0: aload_0
    //   1: monitorenter
    //   2: aload_0
    //   3: invokevirtual validate : ()V
    //   6: aload_0
    //   7: aload_0
    //   8: getfield mContext : J
    //   11: lload_1
    //   12: invokevirtual rsnAllocationIoSend : (JJ)V
    //   15: aload_0
    //   16: monitorexit
    //   17: return
    //   18: astore_3
    //   19: aload_0
    //   20: monitorexit
    //   21: aload_3
    //   22: athrow
    // Exception table:
    //   from	to	target	type
    //   2	15	18	finally
  }
  
  void nAllocationRead(long paramLong, Object paramObject, Element.DataType paramDataType, int paramInt, boolean paramBoolean) {
    // Byte code:
    //   0: aload_0
    //   1: monitorenter
    //   2: aload_0
    //   3: invokevirtual validate : ()V
    //   6: aload_0
    //   7: aload_0
    //   8: getfield mContext : J
    //   11: lload_1
    //   12: aload_3
    //   13: aload #4
    //   15: getfield mID : I
    //   18: iload #5
    //   20: iload #6
    //   22: invokevirtual rsnAllocationRead : (JJLjava/lang/Object;IIZ)V
    //   25: aload_0
    //   26: monitorexit
    //   27: return
    //   28: astore_3
    //   29: aload_0
    //   30: monitorexit
    //   31: aload_3
    //   32: athrow
    // Exception table:
    //   from	to	target	type
    //   2	25	28	finally
  }
  
  void nAllocationRead1D(long paramLong, int paramInt1, int paramInt2, int paramInt3, Object paramObject, int paramInt4, Element.DataType paramDataType, int paramInt5, boolean paramBoolean) {
    // Byte code:
    //   0: aload_0
    //   1: monitorenter
    //   2: aload_0
    //   3: invokevirtual validate : ()V
    //   6: aload_0
    //   7: aload_0
    //   8: getfield mContext : J
    //   11: lload_1
    //   12: iload_3
    //   13: iload #4
    //   15: iload #5
    //   17: aload #6
    //   19: iload #7
    //   21: aload #8
    //   23: getfield mID : I
    //   26: iload #9
    //   28: iload #10
    //   30: invokevirtual rsnAllocationRead1D : (JJIIILjava/lang/Object;IIIZ)V
    //   33: aload_0
    //   34: monitorexit
    //   35: return
    //   36: astore #6
    //   38: aload_0
    //   39: monitorexit
    //   40: aload #6
    //   42: athrow
    // Exception table:
    //   from	to	target	type
    //   2	33	36	finally
  }
  
  void nAllocationRead2D(long paramLong, int paramInt1, int paramInt2, int paramInt3, int paramInt4, int paramInt5, int paramInt6, Object paramObject, int paramInt7, Element.DataType paramDataType, int paramInt8, boolean paramBoolean) {
    // Byte code:
    //   0: aload_0
    //   1: monitorenter
    //   2: aload_0
    //   3: invokevirtual validate : ()V
    //   6: aload_0
    //   7: aload_0
    //   8: getfield mContext : J
    //   11: lload_1
    //   12: iload_3
    //   13: iload #4
    //   15: iload #5
    //   17: iload #6
    //   19: iload #7
    //   21: iload #8
    //   23: aload #9
    //   25: iload #10
    //   27: aload #11
    //   29: getfield mID : I
    //   32: iload #12
    //   34: iload #13
    //   36: invokevirtual rsnAllocationRead2D : (JJIIIIIILjava/lang/Object;IIIZ)V
    //   39: aload_0
    //   40: monitorexit
    //   41: return
    //   42: astore #9
    //   44: aload_0
    //   45: monitorexit
    //   46: aload #9
    //   48: athrow
    // Exception table:
    //   from	to	target	type
    //   2	39	42	finally
  }
  
  void nAllocationResize1D(long paramLong, int paramInt) {
    // Byte code:
    //   0: aload_0
    //   1: monitorenter
    //   2: aload_0
    //   3: invokevirtual validate : ()V
    //   6: aload_0
    //   7: aload_0
    //   8: getfield mContext : J
    //   11: lload_1
    //   12: iload_3
    //   13: invokevirtual rsnAllocationResize1D : (JJI)V
    //   16: aload_0
    //   17: monitorexit
    //   18: return
    //   19: astore #4
    //   21: aload_0
    //   22: monitorexit
    //   23: aload #4
    //   25: athrow
    // Exception table:
    //   from	to	target	type
    //   2	16	19	finally
  }
  
  void nAllocationResize2D(long paramLong, int paramInt1, int paramInt2) {
    // Byte code:
    //   0: aload_0
    //   1: monitorenter
    //   2: aload_0
    //   3: invokevirtual validate : ()V
    //   6: aload_0
    //   7: aload_0
    //   8: getfield mContext : J
    //   11: lload_1
    //   12: iload_3
    //   13: iload #4
    //   15: invokevirtual rsnAllocationResize2D : (JJII)V
    //   18: aload_0
    //   19: monitorexit
    //   20: return
    //   21: astore #5
    //   23: aload_0
    //   24: monitorexit
    //   25: aload #5
    //   27: athrow
    // Exception table:
    //   from	to	target	type
    //   2	18	21	finally
  }
  
  void nAllocationSetSurface(long paramLong, Surface paramSurface) {
    // Byte code:
    //   0: aload_0
    //   1: monitorenter
    //   2: aload_0
    //   3: invokevirtual validate : ()V
    //   6: aload_0
    //   7: aload_0
    //   8: getfield mContext : J
    //   11: lload_1
    //   12: aload_3
    //   13: invokevirtual rsnAllocationSetSurface : (JJLandroid/view/Surface;)V
    //   16: aload_0
    //   17: monitorexit
    //   18: return
    //   19: astore_3
    //   20: aload_0
    //   21: monitorexit
    //   22: aload_3
    //   23: athrow
    // Exception table:
    //   from	to	target	type
    //   2	16	19	finally
  }
  
  void nAllocationSyncAll(long paramLong, int paramInt) {
    // Byte code:
    //   0: aload_0
    //   1: monitorenter
    //   2: aload_0
    //   3: invokevirtual validate : ()V
    //   6: aload_0
    //   7: aload_0
    //   8: getfield mContext : J
    //   11: lload_1
    //   12: iload_3
    //   13: invokevirtual rsnAllocationSyncAll : (JJI)V
    //   16: aload_0
    //   17: monitorexit
    //   18: return
    //   19: astore #4
    //   21: aload_0
    //   22: monitorexit
    //   23: aload #4
    //   25: athrow
    // Exception table:
    //   from	to	target	type
    //   2	16	19	finally
  }
  
  long nClosureCreate(long paramLong1, long paramLong2, long[] paramArrayOflong1, long[] paramArrayOflong2, int[] paramArrayOfint, long[] paramArrayOflong3, long[] paramArrayOflong4) {
    // Byte code:
    //   0: aload_0
    //   1: monitorenter
    //   2: aload_0
    //   3: invokevirtual validate : ()V
    //   6: aload_0
    //   7: aload_0
    //   8: getfield mContext : J
    //   11: lload_1
    //   12: lload_3
    //   13: aload #5
    //   15: aload #6
    //   17: aload #7
    //   19: aload #8
    //   21: aload #9
    //   23: invokevirtual rsnClosureCreate : (JJJ[J[J[I[J[J)J
    //   26: lstore_1
    //   27: lload_1
    //   28: lconst_0
    //   29: lcmp
    //   30: ifeq -> 37
    //   33: aload_0
    //   34: monitorexit
    //   35: lload_1
    //   36: lreturn
    //   37: new androidx/renderscript/RSRuntimeException
    //   40: dup
    //   41: ldc_w 'Failed creating closure.'
    //   44: invokespecial <init> : (Ljava/lang/String;)V
    //   47: athrow
    //   48: astore #5
    //   50: aload_0
    //   51: monitorexit
    //   52: aload #5
    //   54: athrow
    // Exception table:
    //   from	to	target	type
    //   2	27	48	finally
    //   37	48	48	finally
  }
  
  void nClosureSetArg(long paramLong1, int paramInt1, long paramLong2, int paramInt2) {
    // Byte code:
    //   0: aload_0
    //   1: monitorenter
    //   2: aload_0
    //   3: invokevirtual validate : ()V
    //   6: aload_0
    //   7: aload_0
    //   8: getfield mContext : J
    //   11: lload_1
    //   12: iload_3
    //   13: lload #4
    //   15: iload #6
    //   17: invokevirtual rsnClosureSetArg : (JJIJI)V
    //   20: aload_0
    //   21: monitorexit
    //   22: return
    //   23: astore #7
    //   25: aload_0
    //   26: monitorexit
    //   27: aload #7
    //   29: athrow
    // Exception table:
    //   from	to	target	type
    //   2	20	23	finally
  }
  
  void nClosureSetGlobal(long paramLong1, long paramLong2, long paramLong3, int paramInt) {
    // Byte code:
    //   0: aload_0
    //   1: monitorenter
    //   2: aload_0
    //   3: invokevirtual validate : ()V
    //   6: aload_0
    //   7: aload_0
    //   8: getfield mContext : J
    //   11: lload_1
    //   12: lload_3
    //   13: lload #5
    //   15: iload #7
    //   17: invokevirtual rsnClosureSetGlobal : (JJJJI)V
    //   20: aload_0
    //   21: monitorexit
    //   22: return
    //   23: astore #8
    //   25: aload_0
    //   26: monitorexit
    //   27: aload #8
    //   29: athrow
    // Exception table:
    //   from	to	target	type
    //   2	20	23	finally
  }
  
  long nContextCreate(long paramLong, int paramInt1, int paramInt2, int paramInt3, String paramString) {
    // Byte code:
    //   0: aload_0
    //   1: monitorenter
    //   2: aload_0
    //   3: lload_1
    //   4: iload_3
    //   5: iload #4
    //   7: iload #5
    //   9: aload #6
    //   11: invokevirtual rsnContextCreate : (JIIILjava/lang/String;)J
    //   14: lstore_1
    //   15: aload_0
    //   16: monitorexit
    //   17: lload_1
    //   18: lreturn
    //   19: astore #6
    //   21: aload_0
    //   22: monitorexit
    //   23: aload #6
    //   25: athrow
    // Exception table:
    //   from	to	target	type
    //   2	15	19	finally
  }
  
  native void nContextDeinitToClient(long paramLong);
  
  void nContextDestroy() {
    // Byte code:
    //   0: aload_0
    //   1: monitorenter
    //   2: aload_0
    //   3: invokevirtual validate : ()V
    //   6: aload_0
    //   7: getfield mRWLock : Ljava/util/concurrent/locks/ReentrantReadWriteLock;
    //   10: invokevirtual writeLock : ()Ljava/util/concurrent/locks/ReentrantReadWriteLock$WriteLock;
    //   13: astore_3
    //   14: aload_3
    //   15: invokevirtual lock : ()V
    //   18: aload_0
    //   19: getfield mContext : J
    //   22: lstore_1
    //   23: aload_0
    //   24: lconst_0
    //   25: putfield mContext : J
    //   28: aload_3
    //   29: invokevirtual unlock : ()V
    //   32: aload_0
    //   33: lload_1
    //   34: invokevirtual rsnContextDestroy : (J)V
    //   37: aload_0
    //   38: monitorexit
    //   39: return
    //   40: astore_3
    //   41: aload_0
    //   42: monitorexit
    //   43: aload_3
    //   44: athrow
    // Exception table:
    //   from	to	target	type
    //   2	37	40	finally
  }
  
  void nContextDump(int paramInt) {
    // Byte code:
    //   0: aload_0
    //   1: monitorenter
    //   2: aload_0
    //   3: invokevirtual validate : ()V
    //   6: aload_0
    //   7: aload_0
    //   8: getfield mContext : J
    //   11: iload_1
    //   12: invokevirtual rsnContextDump : (JI)V
    //   15: aload_0
    //   16: monitorexit
    //   17: return
    //   18: astore_2
    //   19: aload_0
    //   20: monitorexit
    //   21: aload_2
    //   22: athrow
    // Exception table:
    //   from	to	target	type
    //   2	15	18	finally
  }
  
  void nContextFinish() {
    // Byte code:
    //   0: aload_0
    //   1: monitorenter
    //   2: aload_0
    //   3: invokevirtual validate : ()V
    //   6: aload_0
    //   7: aload_0
    //   8: getfield mContext : J
    //   11: invokevirtual rsnContextFinish : (J)V
    //   14: aload_0
    //   15: monitorexit
    //   16: return
    //   17: astore_1
    //   18: aload_0
    //   19: monitorexit
    //   20: aload_1
    //   21: athrow
    // Exception table:
    //   from	to	target	type
    //   2	14	17	finally
  }
  
  native String nContextGetErrorMessage(long paramLong);
  
  native int nContextGetUserMessage(long paramLong, int[] paramArrayOfint);
  
  native void nContextInitToClient(long paramLong);
  
  native int nContextPeekMessage(long paramLong, int[] paramArrayOfint);
  
  void nContextSendMessage(int paramInt, int[] paramArrayOfint) {
    // Byte code:
    //   0: aload_0
    //   1: monitorenter
    //   2: aload_0
    //   3: invokevirtual validate : ()V
    //   6: aload_0
    //   7: aload_0
    //   8: getfield mContext : J
    //   11: iload_1
    //   12: aload_2
    //   13: invokevirtual rsnContextSendMessage : (JI[I)V
    //   16: aload_0
    //   17: monitorexit
    //   18: return
    //   19: astore_2
    //   20: aload_0
    //   21: monitorexit
    //   22: aload_2
    //   23: athrow
    // Exception table:
    //   from	to	target	type
    //   2	16	19	finally
  }
  
  void nContextSetPriority(int paramInt) {
    // Byte code:
    //   0: aload_0
    //   1: monitorenter
    //   2: aload_0
    //   3: invokevirtual validate : ()V
    //   6: aload_0
    //   7: aload_0
    //   8: getfield mContext : J
    //   11: iload_1
    //   12: invokevirtual rsnContextSetPriority : (JI)V
    //   15: aload_0
    //   16: monitorexit
    //   17: return
    //   18: astore_2
    //   19: aload_0
    //   20: monitorexit
    //   21: aload_2
    //   22: athrow
    // Exception table:
    //   from	to	target	type
    //   2	15	18	finally
  }
  
  native long nDeviceCreate();
  
  native void nDeviceDestroy(long paramLong);
  
  native void nDeviceSetConfig(long paramLong, int paramInt1, int paramInt2);
  
  long nElementCreate(long paramLong, int paramInt1, boolean paramBoolean, int paramInt2) {
    // Byte code:
    //   0: aload_0
    //   1: monitorenter
    //   2: aload_0
    //   3: invokevirtual validate : ()V
    //   6: aload_0
    //   7: aload_0
    //   8: getfield mContext : J
    //   11: lload_1
    //   12: iload_3
    //   13: iload #4
    //   15: iload #5
    //   17: invokevirtual rsnElementCreate : (JJIZI)J
    //   20: lstore_1
    //   21: aload_0
    //   22: monitorexit
    //   23: lload_1
    //   24: lreturn
    //   25: astore #6
    //   27: aload_0
    //   28: monitorexit
    //   29: aload #6
    //   31: athrow
    // Exception table:
    //   from	to	target	type
    //   2	21	25	finally
  }
  
  long nElementCreate2(long[] paramArrayOflong, String[] paramArrayOfString, int[] paramArrayOfint) {
    // Byte code:
    //   0: aload_0
    //   1: monitorenter
    //   2: aload_0
    //   3: invokevirtual validate : ()V
    //   6: aload_0
    //   7: aload_0
    //   8: getfield mContext : J
    //   11: aload_1
    //   12: aload_2
    //   13: aload_3
    //   14: invokevirtual rsnElementCreate2 : (J[J[Ljava/lang/String;[I)J
    //   17: lstore #4
    //   19: aload_0
    //   20: monitorexit
    //   21: lload #4
    //   23: lreturn
    //   24: astore_1
    //   25: aload_0
    //   26: monitorexit
    //   27: aload_1
    //   28: athrow
    // Exception table:
    //   from	to	target	type
    //   2	19	24	finally
  }
  
  void nElementGetNativeData(long paramLong, int[] paramArrayOfint) {
    // Byte code:
    //   0: aload_0
    //   1: monitorenter
    //   2: aload_0
    //   3: invokevirtual validate : ()V
    //   6: aload_0
    //   7: aload_0
    //   8: getfield mContext : J
    //   11: lload_1
    //   12: aload_3
    //   13: invokevirtual rsnElementGetNativeData : (JJ[I)V
    //   16: aload_0
    //   17: monitorexit
    //   18: return
    //   19: astore_3
    //   20: aload_0
    //   21: monitorexit
    //   22: aload_3
    //   23: athrow
    // Exception table:
    //   from	to	target	type
    //   2	16	19	finally
  }
  
  void nElementGetSubElements(long paramLong, long[] paramArrayOflong, String[] paramArrayOfString, int[] paramArrayOfint) {
    // Byte code:
    //   0: aload_0
    //   1: monitorenter
    //   2: aload_0
    //   3: invokevirtual validate : ()V
    //   6: aload_0
    //   7: aload_0
    //   8: getfield mContext : J
    //   11: lload_1
    //   12: aload_3
    //   13: aload #4
    //   15: aload #5
    //   17: invokevirtual rsnElementGetSubElements : (JJ[J[Ljava/lang/String;[I)V
    //   20: aload_0
    //   21: monitorexit
    //   22: return
    //   23: astore_3
    //   24: aload_0
    //   25: monitorexit
    //   26: aload_3
    //   27: athrow
    // Exception table:
    //   from	to	target	type
    //   2	20	23	finally
  }
  
  long nIncAllocationCreateTyped(long paramLong1, long paramLong2, int paramInt) {
    // Byte code:
    //   0: aload_0
    //   1: monitorenter
    //   2: aload_0
    //   3: invokevirtual validate : ()V
    //   6: aload_0
    //   7: aload_0
    //   8: getfield mContext : J
    //   11: aload_0
    //   12: getfield mIncCon : J
    //   15: lload_1
    //   16: lload_3
    //   17: iload #5
    //   19: invokevirtual rsnIncAllocationCreateTyped : (JJJJI)J
    //   22: lstore_1
    //   23: aload_0
    //   24: monitorexit
    //   25: lload_1
    //   26: lreturn
    //   27: astore #6
    //   29: aload_0
    //   30: monitorexit
    //   31: aload #6
    //   33: athrow
    // Exception table:
    //   from	to	target	type
    //   2	23	27	finally
  }
  
  long nIncContextCreate(long paramLong, int paramInt1, int paramInt2, int paramInt3) {
    // Byte code:
    //   0: aload_0
    //   1: monitorenter
    //   2: aload_0
    //   3: lload_1
    //   4: iload_3
    //   5: iload #4
    //   7: iload #5
    //   9: invokevirtual rsnIncContextCreate : (JIII)J
    //   12: lstore_1
    //   13: aload_0
    //   14: monitorexit
    //   15: lload_1
    //   16: lreturn
    //   17: astore #6
    //   19: aload_0
    //   20: monitorexit
    //   21: aload #6
    //   23: athrow
    // Exception table:
    //   from	to	target	type
    //   2	13	17	finally
  }
  
  void nIncContextDestroy() {
    // Byte code:
    //   0: aload_0
    //   1: monitorenter
    //   2: aload_0
    //   3: invokevirtual validate : ()V
    //   6: aload_0
    //   7: getfield mRWLock : Ljava/util/concurrent/locks/ReentrantReadWriteLock;
    //   10: invokevirtual writeLock : ()Ljava/util/concurrent/locks/ReentrantReadWriteLock$WriteLock;
    //   13: astore_3
    //   14: aload_3
    //   15: invokevirtual lock : ()V
    //   18: aload_0
    //   19: getfield mIncCon : J
    //   22: lstore_1
    //   23: aload_0
    //   24: lconst_0
    //   25: putfield mIncCon : J
    //   28: aload_3
    //   29: invokevirtual unlock : ()V
    //   32: aload_0
    //   33: lload_1
    //   34: invokevirtual rsnIncContextDestroy : (J)V
    //   37: aload_0
    //   38: monitorexit
    //   39: return
    //   40: astore_3
    //   41: aload_0
    //   42: monitorexit
    //   43: aload_3
    //   44: athrow
    // Exception table:
    //   from	to	target	type
    //   2	37	40	finally
  }
  
  void nIncContextFinish() {
    // Byte code:
    //   0: aload_0
    //   1: monitorenter
    //   2: aload_0
    //   3: invokevirtual validate : ()V
    //   6: aload_0
    //   7: aload_0
    //   8: getfield mIncCon : J
    //   11: invokevirtual rsnIncContextFinish : (J)V
    //   14: aload_0
    //   15: monitorexit
    //   16: return
    //   17: astore_1
    //   18: aload_0
    //   19: monitorexit
    //   20: aload_1
    //   21: athrow
    // Exception table:
    //   from	to	target	type
    //   2	14	17	finally
  }
  
  native long nIncDeviceCreate();
  
  native void nIncDeviceDestroy(long paramLong);
  
  long nIncElementCreate(long paramLong, int paramInt1, boolean paramBoolean, int paramInt2) {
    // Byte code:
    //   0: aload_0
    //   1: monitorenter
    //   2: aload_0
    //   3: invokevirtual validate : ()V
    //   6: aload_0
    //   7: aload_0
    //   8: getfield mIncCon : J
    //   11: lload_1
    //   12: iload_3
    //   13: iload #4
    //   15: iload #5
    //   17: invokevirtual rsnIncElementCreate : (JJIZI)J
    //   20: lstore_1
    //   21: aload_0
    //   22: monitorexit
    //   23: lload_1
    //   24: lreturn
    //   25: astore #6
    //   27: aload_0
    //   28: monitorexit
    //   29: aload #6
    //   31: athrow
    // Exception table:
    //   from	to	target	type
    //   2	21	25	finally
  }
  
  native boolean nIncLoadSO(int paramInt, String paramString);
  
  void nIncObjDestroy(long paramLong) {
    long l = this.mIncCon;
    if (l != 0L)
      rsnIncObjDestroy(l, paramLong); 
  }
  
  long nIncTypeCreate(long paramLong, int paramInt1, int paramInt2, int paramInt3, boolean paramBoolean1, boolean paramBoolean2, int paramInt4) {
    // Byte code:
    //   0: aload_0
    //   1: monitorenter
    //   2: aload_0
    //   3: invokevirtual validate : ()V
    //   6: aload_0
    //   7: aload_0
    //   8: getfield mIncCon : J
    //   11: lload_1
    //   12: iload_3
    //   13: iload #4
    //   15: iload #5
    //   17: iload #6
    //   19: iload #7
    //   21: iload #8
    //   23: invokevirtual rsnIncTypeCreate : (JJIIIZZI)J
    //   26: lstore_1
    //   27: aload_0
    //   28: monitorexit
    //   29: lload_1
    //   30: lreturn
    //   31: astore #9
    //   33: aload_0
    //   34: monitorexit
    //   35: aload #9
    //   37: athrow
    // Exception table:
    //   from	to	target	type
    //   2	27	31	finally
  }
  
  long nInvokeClosureCreate(long paramLong, byte[] paramArrayOfbyte, long[] paramArrayOflong1, long[] paramArrayOflong2, int[] paramArrayOfint) {
    // Byte code:
    //   0: aload_0
    //   1: monitorenter
    //   2: aload_0
    //   3: invokevirtual validate : ()V
    //   6: aload_0
    //   7: aload_0
    //   8: getfield mContext : J
    //   11: lload_1
    //   12: aload_3
    //   13: aload #4
    //   15: aload #5
    //   17: aload #6
    //   19: invokevirtual rsnInvokeClosureCreate : (JJ[B[J[J[I)J
    //   22: lstore_1
    //   23: lload_1
    //   24: lconst_0
    //   25: lcmp
    //   26: ifeq -> 33
    //   29: aload_0
    //   30: monitorexit
    //   31: lload_1
    //   32: lreturn
    //   33: new androidx/renderscript/RSRuntimeException
    //   36: dup
    //   37: ldc_w 'Failed creating closure.'
    //   40: invokespecial <init> : (Ljava/lang/String;)V
    //   43: athrow
    //   44: astore_3
    //   45: aload_0
    //   46: monitorexit
    //   47: aload_3
    //   48: athrow
    // Exception table:
    //   from	to	target	type
    //   2	23	44	finally
    //   33	44	44	finally
  }
  
  native boolean nLoadIOSO();
  
  native boolean nLoadSO(boolean paramBoolean, int paramInt, String paramString);
  
  void nObjDestroy(long paramLong) {
    long l = this.mContext;
    if (l != 0L)
      rsnObjDestroy(l, paramLong); 
  }
  
  long nSamplerCreate(int paramInt1, int paramInt2, int paramInt3, int paramInt4, int paramInt5, float paramFloat) {
    // Byte code:
    //   0: aload_0
    //   1: monitorenter
    //   2: aload_0
    //   3: invokevirtual validate : ()V
    //   6: aload_0
    //   7: aload_0
    //   8: getfield mContext : J
    //   11: iload_1
    //   12: iload_2
    //   13: iload_3
    //   14: iload #4
    //   16: iload #5
    //   18: fload #6
    //   20: invokevirtual rsnSamplerCreate : (JIIIIIF)J
    //   23: lstore #7
    //   25: aload_0
    //   26: monitorexit
    //   27: lload #7
    //   29: lreturn
    //   30: astore #9
    //   32: aload_0
    //   33: monitorexit
    //   34: aload #9
    //   36: athrow
    // Exception table:
    //   from	to	target	type
    //   2	25	30	finally
  }
  
  void nScriptBindAllocation(long paramLong1, long paramLong2, int paramInt, boolean paramBoolean) {
    // Byte code:
    //   0: aload_0
    //   1: monitorenter
    //   2: aload_0
    //   3: invokevirtual validate : ()V
    //   6: aload_0
    //   7: getfield mContext : J
    //   10: lstore #7
    //   12: iload #6
    //   14: ifeq -> 23
    //   17: aload_0
    //   18: getfield mIncCon : J
    //   21: lstore #7
    //   23: aload_0
    //   24: lload #7
    //   26: lload_1
    //   27: lload_3
    //   28: iload #5
    //   30: iload #6
    //   32: invokevirtual rsnScriptBindAllocation : (JJJIZ)V
    //   35: aload_0
    //   36: monitorexit
    //   37: return
    //   38: astore #9
    //   40: aload_0
    //   41: monitorexit
    //   42: aload #9
    //   44: athrow
    // Exception table:
    //   from	to	target	type
    //   2	12	38	finally
    //   17	23	38	finally
    //   23	35	38	finally
  }
  
  long nScriptCCreate(String paramString1, String paramString2, byte[] paramArrayOfbyte, int paramInt) {
    // Byte code:
    //   0: aload_0
    //   1: monitorenter
    //   2: aload_0
    //   3: invokevirtual validate : ()V
    //   6: aload_0
    //   7: aload_0
    //   8: getfield mContext : J
    //   11: aload_1
    //   12: aload_2
    //   13: aload_3
    //   14: iload #4
    //   16: invokevirtual rsnScriptCCreate : (JLjava/lang/String;Ljava/lang/String;[BI)J
    //   19: lstore #5
    //   21: aload_0
    //   22: monitorexit
    //   23: lload #5
    //   25: lreturn
    //   26: astore_1
    //   27: aload_0
    //   28: monitorexit
    //   29: aload_1
    //   30: athrow
    // Exception table:
    //   from	to	target	type
    //   2	21	26	finally
  }
  
  long nScriptFieldIDCreate(long paramLong, int paramInt, boolean paramBoolean) {
    // Byte code:
    //   0: aload_0
    //   1: monitorenter
    //   2: aload_0
    //   3: invokevirtual validate : ()V
    //   6: aload_0
    //   7: getfield mContext : J
    //   10: lstore #5
    //   12: iload #4
    //   14: ifeq -> 23
    //   17: aload_0
    //   18: getfield mIncCon : J
    //   21: lstore #5
    //   23: aload_0
    //   24: lload #5
    //   26: lload_1
    //   27: iload_3
    //   28: iload #4
    //   30: invokevirtual rsnScriptFieldIDCreate : (JJIZ)J
    //   33: lstore_1
    //   34: aload_0
    //   35: monitorexit
    //   36: lload_1
    //   37: lreturn
    //   38: astore #7
    //   40: aload_0
    //   41: monitorexit
    //   42: aload #7
    //   44: athrow
    // Exception table:
    //   from	to	target	type
    //   2	12	38	finally
    //   17	23	38	finally
    //   23	34	38	finally
  }
  
  void nScriptForEach(long paramLong1, int paramInt, long paramLong2, long paramLong3, byte[] paramArrayOfbyte, boolean paramBoolean) {
    // Byte code:
    //   0: aload_0
    //   1: monitorenter
    //   2: aload_0
    //   3: invokevirtual validate : ()V
    //   6: aload #8
    //   8: ifnonnull -> 34
    //   11: aload_0
    //   12: aload_0
    //   13: getfield mContext : J
    //   16: aload_0
    //   17: getfield mIncCon : J
    //   20: lload_1
    //   21: iload_3
    //   22: lload #4
    //   24: lload #6
    //   26: iload #9
    //   28: invokevirtual rsnScriptForEach : (JJJIJJZ)V
    //   31: goto -> 56
    //   34: aload_0
    //   35: aload_0
    //   36: getfield mContext : J
    //   39: aload_0
    //   40: getfield mIncCon : J
    //   43: lload_1
    //   44: iload_3
    //   45: lload #4
    //   47: lload #6
    //   49: aload #8
    //   51: iload #9
    //   53: invokevirtual rsnScriptForEach : (JJJIJJ[BZ)V
    //   56: aload_0
    //   57: monitorexit
    //   58: return
    //   59: astore #8
    //   61: aload_0
    //   62: monitorexit
    //   63: aload #8
    //   65: athrow
    // Exception table:
    //   from	to	target	type
    //   2	6	59	finally
    //   11	31	59	finally
    //   34	56	59	finally
  }
  
  void nScriptForEach(long paramLong1, int paramInt, long[] paramArrayOflong, long paramLong2, byte[] paramArrayOfbyte, int[] paramArrayOfint) {
    // Byte code:
    //   0: aload_0
    //   1: monitorenter
    //   2: aload_0
    //   3: getfield mEnableMultiInput : Z
    //   6: ifeq -> 34
    //   9: aload_0
    //   10: invokevirtual validate : ()V
    //   13: aload_0
    //   14: aload_0
    //   15: getfield mContext : J
    //   18: lload_1
    //   19: iload_3
    //   20: aload #4
    //   22: lload #5
    //   24: aload #7
    //   26: aload #8
    //   28: invokevirtual rsnScriptForEach : (JJI[JJ[B[I)V
    //   31: aload_0
    //   32: monitorexit
    //   33: return
    //   34: ldc 'RenderScript_jni'
    //   36: ldc_w 'Multi-input kernels are not supported, please change targetSdkVersion to >= 23'
    //   39: invokestatic e : (Ljava/lang/String;Ljava/lang/String;)I
    //   42: pop
    //   43: new androidx/renderscript/RSRuntimeException
    //   46: dup
    //   47: ldc_w 'Multi-input kernels are not supported before API 23)'
    //   50: invokespecial <init> : (Ljava/lang/String;)V
    //   53: athrow
    //   54: astore #4
    //   56: aload_0
    //   57: monitorexit
    //   58: aload #4
    //   60: athrow
    // Exception table:
    //   from	to	target	type
    //   2	31	54	finally
    //   34	54	54	finally
  }
  
  void nScriptForEachClipped(long paramLong1, int paramInt1, long paramLong2, long paramLong3, byte[] paramArrayOfbyte, int paramInt2, int paramInt3, int paramInt4, int paramInt5, int paramInt6, int paramInt7, boolean paramBoolean) {
    // Byte code:
    //   0: aload_0
    //   1: monitorenter
    //   2: aload_0
    //   3: invokevirtual validate : ()V
    //   6: aload #8
    //   8: ifnonnull -> 46
    //   11: aload_0
    //   12: aload_0
    //   13: getfield mContext : J
    //   16: aload_0
    //   17: getfield mIncCon : J
    //   20: lload_1
    //   21: iload_3
    //   22: lload #4
    //   24: lload #6
    //   26: iload #9
    //   28: iload #10
    //   30: iload #11
    //   32: iload #12
    //   34: iload #13
    //   36: iload #14
    //   38: iload #15
    //   40: invokevirtual rsnScriptForEachClipped : (JJJIJJIIIIIIZ)V
    //   43: goto -> 80
    //   46: aload_0
    //   47: aload_0
    //   48: getfield mContext : J
    //   51: aload_0
    //   52: getfield mIncCon : J
    //   55: lload_1
    //   56: iload_3
    //   57: lload #4
    //   59: lload #6
    //   61: aload #8
    //   63: iload #9
    //   65: iload #10
    //   67: iload #11
    //   69: iload #12
    //   71: iload #13
    //   73: iload #14
    //   75: iload #15
    //   77: invokevirtual rsnScriptForEachClipped : (JJJIJJ[BIIIIIIZ)V
    //   80: aload_0
    //   81: monitorexit
    //   82: return
    //   83: astore #8
    //   85: aload_0
    //   86: monitorexit
    //   87: aload #8
    //   89: athrow
    // Exception table:
    //   from	to	target	type
    //   2	6	83	finally
    //   11	43	83	finally
    //   46	80	83	finally
  }
  
  long nScriptGroup2Create(String paramString1, String paramString2, long[] paramArrayOflong) {
    // Byte code:
    //   0: aload_0
    //   1: monitorenter
    //   2: aload_0
    //   3: invokevirtual validate : ()V
    //   6: aload_0
    //   7: aload_0
    //   8: getfield mContext : J
    //   11: aload_1
    //   12: aload_2
    //   13: aload_3
    //   14: invokevirtual rsnScriptGroup2Create : (JLjava/lang/String;Ljava/lang/String;[J)J
    //   17: lstore #4
    //   19: aload_0
    //   20: monitorexit
    //   21: lload #4
    //   23: lreturn
    //   24: astore_1
    //   25: aload_0
    //   26: monitorexit
    //   27: aload_1
    //   28: athrow
    // Exception table:
    //   from	to	target	type
    //   2	19	24	finally
  }
  
  void nScriptGroup2Execute(long paramLong) {
    // Byte code:
    //   0: aload_0
    //   1: monitorenter
    //   2: aload_0
    //   3: invokevirtual validate : ()V
    //   6: aload_0
    //   7: aload_0
    //   8: getfield mContext : J
    //   11: lload_1
    //   12: invokevirtual rsnScriptGroup2Execute : (JJ)V
    //   15: aload_0
    //   16: monitorexit
    //   17: return
    //   18: astore_3
    //   19: aload_0
    //   20: monitorexit
    //   21: aload_3
    //   22: athrow
    // Exception table:
    //   from	to	target	type
    //   2	15	18	finally
  }
  
  long nScriptGroupCreate(long[] paramArrayOflong1, long[] paramArrayOflong2, long[] paramArrayOflong3, long[] paramArrayOflong4, long[] paramArrayOflong5) {
    // Byte code:
    //   0: aload_0
    //   1: monitorenter
    //   2: aload_0
    //   3: invokevirtual validate : ()V
    //   6: aload_0
    //   7: aload_0
    //   8: getfield mContext : J
    //   11: aload_1
    //   12: aload_2
    //   13: aload_3
    //   14: aload #4
    //   16: aload #5
    //   18: invokevirtual rsnScriptGroupCreate : (J[J[J[J[J[J)J
    //   21: lstore #6
    //   23: aload_0
    //   24: monitorexit
    //   25: lload #6
    //   27: lreturn
    //   28: astore_1
    //   29: aload_0
    //   30: monitorexit
    //   31: aload_1
    //   32: athrow
    // Exception table:
    //   from	to	target	type
    //   2	23	28	finally
  }
  
  void nScriptGroupExecute(long paramLong) {
    // Byte code:
    //   0: aload_0
    //   1: monitorenter
    //   2: aload_0
    //   3: invokevirtual validate : ()V
    //   6: aload_0
    //   7: aload_0
    //   8: getfield mContext : J
    //   11: lload_1
    //   12: invokevirtual rsnScriptGroupExecute : (JJ)V
    //   15: aload_0
    //   16: monitorexit
    //   17: return
    //   18: astore_3
    //   19: aload_0
    //   20: monitorexit
    //   21: aload_3
    //   22: athrow
    // Exception table:
    //   from	to	target	type
    //   2	15	18	finally
  }
  
  void nScriptGroupSetInput(long paramLong1, long paramLong2, long paramLong3) {
    // Byte code:
    //   0: aload_0
    //   1: monitorenter
    //   2: aload_0
    //   3: invokevirtual validate : ()V
    //   6: aload_0
    //   7: aload_0
    //   8: getfield mContext : J
    //   11: lload_1
    //   12: lload_3
    //   13: lload #5
    //   15: invokevirtual rsnScriptGroupSetInput : (JJJJ)V
    //   18: aload_0
    //   19: monitorexit
    //   20: return
    //   21: astore #7
    //   23: aload_0
    //   24: monitorexit
    //   25: aload #7
    //   27: athrow
    // Exception table:
    //   from	to	target	type
    //   2	18	21	finally
  }
  
  void nScriptGroupSetOutput(long paramLong1, long paramLong2, long paramLong3) {
    // Byte code:
    //   0: aload_0
    //   1: monitorenter
    //   2: aload_0
    //   3: invokevirtual validate : ()V
    //   6: aload_0
    //   7: aload_0
    //   8: getfield mContext : J
    //   11: lload_1
    //   12: lload_3
    //   13: lload #5
    //   15: invokevirtual rsnScriptGroupSetOutput : (JJJJ)V
    //   18: aload_0
    //   19: monitorexit
    //   20: return
    //   21: astore #7
    //   23: aload_0
    //   24: monitorexit
    //   25: aload #7
    //   27: athrow
    // Exception table:
    //   from	to	target	type
    //   2	18	21	finally
  }
  
  void nScriptIntrinsicBLAS_BNNM(long paramLong1, int paramInt1, int paramInt2, int paramInt3, long paramLong2, int paramInt4, long paramLong3, int paramInt5, long paramLong4, int paramInt6, int paramInt7, boolean paramBoolean) {
    // Byte code:
    //   0: aload_0
    //   1: monitorenter
    //   2: aload_0
    //   3: invokevirtual validate : ()V
    //   6: aload_0
    //   7: aload_0
    //   8: getfield mContext : J
    //   11: aload_0
    //   12: getfield mIncCon : J
    //   15: lload_1
    //   16: iload_3
    //   17: iload #4
    //   19: iload #5
    //   21: lload #6
    //   23: iload #8
    //   25: lload #9
    //   27: iload #11
    //   29: lload #12
    //   31: iload #14
    //   33: iload #15
    //   35: iload #16
    //   37: invokevirtual rsnScriptIntrinsicBLAS_BNNM : (JJJIIIJIJIJIIZ)V
    //   40: aload_0
    //   41: monitorexit
    //   42: return
    //   43: astore #17
    //   45: aload_0
    //   46: monitorexit
    //   47: aload #17
    //   49: athrow
    // Exception table:
    //   from	to	target	type
    //   2	40	43	finally
  }
  
  void nScriptIntrinsicBLAS_Complex(long paramLong1, int paramInt1, int paramInt2, int paramInt3, int paramInt4, int paramInt5, int paramInt6, int paramInt7, int paramInt8, int paramInt9, float paramFloat1, float paramFloat2, long paramLong2, long paramLong3, float paramFloat3, float paramFloat4, long paramLong4, int paramInt10, int paramInt11, int paramInt12, int paramInt13, boolean paramBoolean) {
    // Byte code:
    //   0: aload_0
    //   1: monitorenter
    //   2: aload_0
    //   3: invokevirtual validate : ()V
    //   6: aload_0
    //   7: aload_0
    //   8: getfield mContext : J
    //   11: aload_0
    //   12: getfield mIncCon : J
    //   15: lload_1
    //   16: iload_3
    //   17: iload #4
    //   19: iload #5
    //   21: iload #6
    //   23: iload #7
    //   25: iload #8
    //   27: iload #9
    //   29: iload #10
    //   31: iload #11
    //   33: fload #12
    //   35: fload #13
    //   37: lload #14
    //   39: lload #16
    //   41: fload #18
    //   43: fload #19
    //   45: lload #20
    //   47: iload #22
    //   49: iload #23
    //   51: iload #24
    //   53: iload #25
    //   55: iload #26
    //   57: invokevirtual rsnScriptIntrinsicBLAS_Complex : (JJJIIIIIIIIIFFJJFFJIIIIZ)V
    //   60: aload_0
    //   61: monitorexit
    //   62: return
    //   63: astore #27
    //   65: aload_0
    //   66: monitorexit
    //   67: aload #27
    //   69: athrow
    // Exception table:
    //   from	to	target	type
    //   2	60	63	finally
  }
  
  void nScriptIntrinsicBLAS_Double(long paramLong1, int paramInt1, int paramInt2, int paramInt3, int paramInt4, int paramInt5, int paramInt6, int paramInt7, int paramInt8, int paramInt9, double paramDouble1, long paramLong2, long paramLong3, double paramDouble2, long paramLong4, int paramInt10, int paramInt11, int paramInt12, int paramInt13, boolean paramBoolean) {
    // Byte code:
    //   0: aload_0
    //   1: monitorenter
    //   2: aload_0
    //   3: invokevirtual validate : ()V
    //   6: aload_0
    //   7: aload_0
    //   8: getfield mContext : J
    //   11: aload_0
    //   12: getfield mIncCon : J
    //   15: lload_1
    //   16: iload_3
    //   17: iload #4
    //   19: iload #5
    //   21: iload #6
    //   23: iload #7
    //   25: iload #8
    //   27: iload #9
    //   29: iload #10
    //   31: iload #11
    //   33: dload #12
    //   35: lload #14
    //   37: lload #16
    //   39: dload #18
    //   41: lload #20
    //   43: iload #22
    //   45: iload #23
    //   47: iload #24
    //   49: iload #25
    //   51: iload #26
    //   53: invokevirtual rsnScriptIntrinsicBLAS_Double : (JJJIIIIIIIIIDJJDJIIIIZ)V
    //   56: aload_0
    //   57: monitorexit
    //   58: return
    //   59: astore #27
    //   61: aload_0
    //   62: monitorexit
    //   63: aload #27
    //   65: athrow
    // Exception table:
    //   from	to	target	type
    //   2	56	59	finally
  }
  
  void nScriptIntrinsicBLAS_Single(long paramLong1, int paramInt1, int paramInt2, int paramInt3, int paramInt4, int paramInt5, int paramInt6, int paramInt7, int paramInt8, int paramInt9, float paramFloat1, long paramLong2, long paramLong3, float paramFloat2, long paramLong4, int paramInt10, int paramInt11, int paramInt12, int paramInt13, boolean paramBoolean) {
    // Byte code:
    //   0: aload_0
    //   1: monitorenter
    //   2: aload_0
    //   3: invokevirtual validate : ()V
    //   6: aload_0
    //   7: aload_0
    //   8: getfield mContext : J
    //   11: aload_0
    //   12: getfield mIncCon : J
    //   15: lload_1
    //   16: iload_3
    //   17: iload #4
    //   19: iload #5
    //   21: iload #6
    //   23: iload #7
    //   25: iload #8
    //   27: iload #9
    //   29: iload #10
    //   31: iload #11
    //   33: fload #12
    //   35: lload #13
    //   37: lload #15
    //   39: fload #17
    //   41: lload #18
    //   43: iload #20
    //   45: iload #21
    //   47: iload #22
    //   49: iload #23
    //   51: iload #24
    //   53: invokevirtual rsnScriptIntrinsicBLAS_Single : (JJJIIIIIIIIIFJJFJIIIIZ)V
    //   56: aload_0
    //   57: monitorexit
    //   58: return
    //   59: astore #25
    //   61: aload_0
    //   62: monitorexit
    //   63: aload #25
    //   65: athrow
    // Exception table:
    //   from	to	target	type
    //   2	56	59	finally
  }
  
  void nScriptIntrinsicBLAS_Z(long paramLong1, int paramInt1, int paramInt2, int paramInt3, int paramInt4, int paramInt5, int paramInt6, int paramInt7, int paramInt8, int paramInt9, double paramDouble1, double paramDouble2, long paramLong2, long paramLong3, double paramDouble3, double paramDouble4, long paramLong4, int paramInt10, int paramInt11, int paramInt12, int paramInt13, boolean paramBoolean) {
    // Byte code:
    //   0: aload_0
    //   1: monitorenter
    //   2: aload_0
    //   3: invokevirtual validate : ()V
    //   6: aload_0
    //   7: aload_0
    //   8: getfield mContext : J
    //   11: aload_0
    //   12: getfield mIncCon : J
    //   15: lload_1
    //   16: iload_3
    //   17: iload #4
    //   19: iload #5
    //   21: iload #6
    //   23: iload #7
    //   25: iload #8
    //   27: iload #9
    //   29: iload #10
    //   31: iload #11
    //   33: dload #12
    //   35: dload #14
    //   37: lload #16
    //   39: lload #18
    //   41: dload #20
    //   43: dload #22
    //   45: lload #24
    //   47: iload #26
    //   49: iload #27
    //   51: iload #28
    //   53: iload #29
    //   55: iload #30
    //   57: invokevirtual rsnScriptIntrinsicBLAS_Z : (JJJIIIIIIIIIDDJJDDJIIIIZ)V
    //   60: aload_0
    //   61: monitorexit
    //   62: return
    //   63: astore #31
    //   65: aload_0
    //   66: monitorexit
    //   67: aload #31
    //   69: athrow
    // Exception table:
    //   from	to	target	type
    //   2	60	63	finally
  }
  
  long nScriptIntrinsicCreate(int paramInt, long paramLong, boolean paramBoolean) {
    // Byte code:
    //   0: aload_0
    //   1: monitorenter
    //   2: aload_0
    //   3: invokevirtual validate : ()V
    //   6: iload #4
    //   8: ifeq -> 208
    //   11: aload_0
    //   12: getfield mIncLoaded : Z
    //   15: istore #5
    //   17: iload #5
    //   19: ifne -> 167
    //   22: ldc_w 'RSSupport'
    //   25: invokestatic loadLibrary : (Ljava/lang/String;)V
    //   28: new java/lang/StringBuilder
    //   31: dup
    //   32: invokespecial <init> : ()V
    //   35: astore #6
    //   37: aload #6
    //   39: aload_0
    //   40: getfield mNativeLibDir : Ljava/lang/String;
    //   43: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   46: pop
    //   47: aload #6
    //   49: ldc_w '/libRSSupport.so'
    //   52: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   55: pop
    //   56: aload_0
    //   57: bipush #23
    //   59: aload #6
    //   61: invokevirtual toString : ()Ljava/lang/String;
    //   64: invokevirtual nIncLoadSO : (ILjava/lang/String;)Z
    //   67: ifeq -> 78
    //   70: aload_0
    //   71: iconst_1
    //   72: putfield mIncLoaded : Z
    //   75: goto -> 167
    //   78: new androidx/renderscript/RSRuntimeException
    //   81: dup
    //   82: ldc_w 'Error loading libRSSupport library for Incremental Intrinsic Support'
    //   85: invokespecial <init> : (Ljava/lang/String;)V
    //   88: athrow
    //   89: astore #6
    //   91: new java/lang/StringBuilder
    //   94: dup
    //   95: invokespecial <init> : ()V
    //   98: astore #7
    //   100: aload #7
    //   102: ldc_w 'Error loading RS Compat library for Incremental Intrinsic Support: '
    //   105: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   108: pop
    //   109: aload #7
    //   111: aload #6
    //   113: invokevirtual append : (Ljava/lang/Object;)Ljava/lang/StringBuilder;
    //   116: pop
    //   117: ldc 'RenderScript_jni'
    //   119: aload #7
    //   121: invokevirtual toString : ()Ljava/lang/String;
    //   124: invokestatic e : (Ljava/lang/String;Ljava/lang/String;)I
    //   127: pop
    //   128: new java/lang/StringBuilder
    //   131: dup
    //   132: invokespecial <init> : ()V
    //   135: astore #7
    //   137: aload #7
    //   139: ldc_w 'Error loading RS Compat library for Incremental Intrinsic Support: '
    //   142: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   145: pop
    //   146: aload #7
    //   148: aload #6
    //   150: invokevirtual append : (Ljava/lang/Object;)Ljava/lang/StringBuilder;
    //   153: pop
    //   154: new androidx/renderscript/RSRuntimeException
    //   157: dup
    //   158: aload #7
    //   160: invokevirtual toString : ()Ljava/lang/String;
    //   163: invokespecial <init> : (Ljava/lang/String;)V
    //   166: athrow
    //   167: aload_0
    //   168: getfield mIncCon : J
    //   171: lconst_0
    //   172: lcmp
    //   173: ifne -> 191
    //   176: aload_0
    //   177: aload_0
    //   178: aload_0
    //   179: invokevirtual nIncDeviceCreate : ()J
    //   182: iconst_0
    //   183: iconst_0
    //   184: iconst_0
    //   185: invokevirtual nIncContextCreate : (JIII)J
    //   188: putfield mIncCon : J
    //   191: aload_0
    //   192: aload_0
    //   193: getfield mIncCon : J
    //   196: iload_1
    //   197: lload_2
    //   198: iload #4
    //   200: invokevirtual rsnScriptIntrinsicCreate : (JIJZ)J
    //   203: lstore_2
    //   204: aload_0
    //   205: monitorexit
    //   206: lload_2
    //   207: lreturn
    //   208: aload_0
    //   209: aload_0
    //   210: getfield mContext : J
    //   213: iload_1
    //   214: lload_2
    //   215: iload #4
    //   217: invokevirtual rsnScriptIntrinsicCreate : (JIJZ)J
    //   220: lstore_2
    //   221: aload_0
    //   222: monitorexit
    //   223: lload_2
    //   224: lreturn
    //   225: astore #6
    //   227: aload_0
    //   228: monitorexit
    //   229: aload #6
    //   231: athrow
    // Exception table:
    //   from	to	target	type
    //   2	6	225	finally
    //   11	17	225	finally
    //   22	28	89	java/lang/UnsatisfiedLinkError
    //   22	28	225	finally
    //   28	75	225	finally
    //   78	89	225	finally
    //   91	167	225	finally
    //   167	191	225	finally
    //   191	204	225	finally
    //   208	221	225	finally
  }
  
  void nScriptInvoke(long paramLong, int paramInt, boolean paramBoolean) {
    // Byte code:
    //   0: aload_0
    //   1: monitorenter
    //   2: aload_0
    //   3: invokevirtual validate : ()V
    //   6: aload_0
    //   7: getfield mContext : J
    //   10: lstore #5
    //   12: iload #4
    //   14: ifeq -> 23
    //   17: aload_0
    //   18: getfield mIncCon : J
    //   21: lstore #5
    //   23: aload_0
    //   24: lload #5
    //   26: lload_1
    //   27: iload_3
    //   28: iload #4
    //   30: invokevirtual rsnScriptInvoke : (JJIZ)V
    //   33: aload_0
    //   34: monitorexit
    //   35: return
    //   36: astore #7
    //   38: aload_0
    //   39: monitorexit
    //   40: aload #7
    //   42: athrow
    // Exception table:
    //   from	to	target	type
    //   2	12	36	finally
    //   17	23	36	finally
    //   23	33	36	finally
  }
  
  long nScriptInvokeIDCreate(long paramLong, int paramInt) {
    // Byte code:
    //   0: aload_0
    //   1: monitorenter
    //   2: aload_0
    //   3: invokevirtual validate : ()V
    //   6: aload_0
    //   7: aload_0
    //   8: getfield mContext : J
    //   11: lload_1
    //   12: iload_3
    //   13: invokevirtual rsnScriptInvokeIDCreate : (JJI)J
    //   16: lstore_1
    //   17: aload_0
    //   18: monitorexit
    //   19: lload_1
    //   20: lreturn
    //   21: astore #4
    //   23: aload_0
    //   24: monitorexit
    //   25: aload #4
    //   27: athrow
    // Exception table:
    //   from	to	target	type
    //   2	17	21	finally
  }
  
  void nScriptInvokeV(long paramLong, int paramInt, byte[] paramArrayOfbyte, boolean paramBoolean) {
    // Byte code:
    //   0: aload_0
    //   1: monitorenter
    //   2: aload_0
    //   3: invokevirtual validate : ()V
    //   6: aload_0
    //   7: getfield mContext : J
    //   10: lstore #6
    //   12: iload #5
    //   14: ifeq -> 23
    //   17: aload_0
    //   18: getfield mIncCon : J
    //   21: lstore #6
    //   23: aload_0
    //   24: lload #6
    //   26: lload_1
    //   27: iload_3
    //   28: aload #4
    //   30: iload #5
    //   32: invokevirtual rsnScriptInvokeV : (JJI[BZ)V
    //   35: aload_0
    //   36: monitorexit
    //   37: return
    //   38: astore #4
    //   40: aload_0
    //   41: monitorexit
    //   42: aload #4
    //   44: athrow
    // Exception table:
    //   from	to	target	type
    //   2	12	38	finally
    //   17	23	38	finally
    //   23	35	38	finally
  }
  
  long nScriptKernelIDCreate(long paramLong, int paramInt1, int paramInt2, boolean paramBoolean) {
    // Byte code:
    //   0: aload_0
    //   1: monitorenter
    //   2: aload_0
    //   3: invokevirtual validate : ()V
    //   6: aload_0
    //   7: getfield mContext : J
    //   10: lstore #6
    //   12: iload #5
    //   14: ifeq -> 23
    //   17: aload_0
    //   18: getfield mIncCon : J
    //   21: lstore #6
    //   23: aload_0
    //   24: lload #6
    //   26: lload_1
    //   27: iload_3
    //   28: iload #4
    //   30: iload #5
    //   32: invokevirtual rsnScriptKernelIDCreate : (JJIIZ)J
    //   35: lstore_1
    //   36: aload_0
    //   37: monitorexit
    //   38: lload_1
    //   39: lreturn
    //   40: astore #8
    //   42: aload_0
    //   43: monitorexit
    //   44: aload #8
    //   46: athrow
    // Exception table:
    //   from	to	target	type
    //   2	12	40	finally
    //   17	23	40	finally
    //   23	36	40	finally
  }
  
  void nScriptReduce(long paramLong1, int paramInt, long[] paramArrayOflong, long paramLong2, int[] paramArrayOfint) {
    // Byte code:
    //   0: aload_0
    //   1: monitorenter
    //   2: aload_0
    //   3: invokevirtual validate : ()V
    //   6: aload_0
    //   7: aload_0
    //   8: getfield mContext : J
    //   11: lload_1
    //   12: iload_3
    //   13: aload #4
    //   15: lload #5
    //   17: aload #7
    //   19: invokevirtual rsnScriptReduce : (JJI[JJ[I)V
    //   22: aload_0
    //   23: monitorexit
    //   24: return
    //   25: astore #4
    //   27: aload_0
    //   28: monitorexit
    //   29: aload #4
    //   31: athrow
    // Exception table:
    //   from	to	target	type
    //   2	22	25	finally
  }
  
  void nScriptSetTimeZone(long paramLong, byte[] paramArrayOfbyte, boolean paramBoolean) {
    // Byte code:
    //   0: aload_0
    //   1: monitorenter
    //   2: aload_0
    //   3: invokevirtual validate : ()V
    //   6: aload_0
    //   7: getfield mContext : J
    //   10: lstore #5
    //   12: iload #4
    //   14: ifeq -> 23
    //   17: aload_0
    //   18: getfield mIncCon : J
    //   21: lstore #5
    //   23: aload_0
    //   24: lload #5
    //   26: lload_1
    //   27: aload_3
    //   28: iload #4
    //   30: invokevirtual rsnScriptSetTimeZone : (JJ[BZ)V
    //   33: aload_0
    //   34: monitorexit
    //   35: return
    //   36: astore_3
    //   37: aload_0
    //   38: monitorexit
    //   39: aload_3
    //   40: athrow
    // Exception table:
    //   from	to	target	type
    //   2	12	36	finally
    //   17	23	36	finally
    //   23	33	36	finally
  }
  
  void nScriptSetVarD(long paramLong, int paramInt, double paramDouble, boolean paramBoolean) {
    // Byte code:
    //   0: aload_0
    //   1: monitorenter
    //   2: aload_0
    //   3: invokevirtual validate : ()V
    //   6: aload_0
    //   7: getfield mContext : J
    //   10: lstore #7
    //   12: iload #6
    //   14: ifeq -> 23
    //   17: aload_0
    //   18: getfield mIncCon : J
    //   21: lstore #7
    //   23: aload_0
    //   24: lload #7
    //   26: lload_1
    //   27: iload_3
    //   28: dload #4
    //   30: iload #6
    //   32: invokevirtual rsnScriptSetVarD : (JJIDZ)V
    //   35: aload_0
    //   36: monitorexit
    //   37: return
    //   38: astore #9
    //   40: aload_0
    //   41: monitorexit
    //   42: aload #9
    //   44: athrow
    // Exception table:
    //   from	to	target	type
    //   2	12	38	finally
    //   17	23	38	finally
    //   23	35	38	finally
  }
  
  void nScriptSetVarF(long paramLong, int paramInt, float paramFloat, boolean paramBoolean) {
    // Byte code:
    //   0: aload_0
    //   1: monitorenter
    //   2: aload_0
    //   3: invokevirtual validate : ()V
    //   6: aload_0
    //   7: getfield mContext : J
    //   10: lstore #6
    //   12: iload #5
    //   14: ifeq -> 23
    //   17: aload_0
    //   18: getfield mIncCon : J
    //   21: lstore #6
    //   23: aload_0
    //   24: lload #6
    //   26: lload_1
    //   27: iload_3
    //   28: fload #4
    //   30: iload #5
    //   32: invokevirtual rsnScriptSetVarF : (JJIFZ)V
    //   35: aload_0
    //   36: monitorexit
    //   37: return
    //   38: astore #8
    //   40: aload_0
    //   41: monitorexit
    //   42: aload #8
    //   44: athrow
    // Exception table:
    //   from	to	target	type
    //   2	12	38	finally
    //   17	23	38	finally
    //   23	35	38	finally
  }
  
  void nScriptSetVarI(long paramLong, int paramInt1, int paramInt2, boolean paramBoolean) {
    // Byte code:
    //   0: aload_0
    //   1: monitorenter
    //   2: aload_0
    //   3: invokevirtual validate : ()V
    //   6: aload_0
    //   7: getfield mContext : J
    //   10: lstore #6
    //   12: iload #5
    //   14: ifeq -> 23
    //   17: aload_0
    //   18: getfield mIncCon : J
    //   21: lstore #6
    //   23: aload_0
    //   24: lload #6
    //   26: lload_1
    //   27: iload_3
    //   28: iload #4
    //   30: iload #5
    //   32: invokevirtual rsnScriptSetVarI : (JJIIZ)V
    //   35: aload_0
    //   36: monitorexit
    //   37: return
    //   38: astore #8
    //   40: aload_0
    //   41: monitorexit
    //   42: aload #8
    //   44: athrow
    // Exception table:
    //   from	to	target	type
    //   2	12	38	finally
    //   17	23	38	finally
    //   23	35	38	finally
  }
  
  void nScriptSetVarJ(long paramLong1, int paramInt, long paramLong2, boolean paramBoolean) {
    // Byte code:
    //   0: aload_0
    //   1: monitorenter
    //   2: aload_0
    //   3: invokevirtual validate : ()V
    //   6: aload_0
    //   7: getfield mContext : J
    //   10: lstore #7
    //   12: iload #6
    //   14: ifeq -> 23
    //   17: aload_0
    //   18: getfield mIncCon : J
    //   21: lstore #7
    //   23: aload_0
    //   24: lload #7
    //   26: lload_1
    //   27: iload_3
    //   28: lload #4
    //   30: iload #6
    //   32: invokevirtual rsnScriptSetVarJ : (JJIJZ)V
    //   35: aload_0
    //   36: monitorexit
    //   37: return
    //   38: astore #9
    //   40: aload_0
    //   41: monitorexit
    //   42: aload #9
    //   44: athrow
    // Exception table:
    //   from	to	target	type
    //   2	12	38	finally
    //   17	23	38	finally
    //   23	35	38	finally
  }
  
  void nScriptSetVarObj(long paramLong1, int paramInt, long paramLong2, boolean paramBoolean) {
    // Byte code:
    //   0: aload_0
    //   1: monitorenter
    //   2: aload_0
    //   3: invokevirtual validate : ()V
    //   6: aload_0
    //   7: getfield mContext : J
    //   10: lstore #7
    //   12: iload #6
    //   14: ifeq -> 23
    //   17: aload_0
    //   18: getfield mIncCon : J
    //   21: lstore #7
    //   23: aload_0
    //   24: lload #7
    //   26: lload_1
    //   27: iload_3
    //   28: lload #4
    //   30: iload #6
    //   32: invokevirtual rsnScriptSetVarObj : (JJIJZ)V
    //   35: aload_0
    //   36: monitorexit
    //   37: return
    //   38: astore #9
    //   40: aload_0
    //   41: monitorexit
    //   42: aload #9
    //   44: athrow
    // Exception table:
    //   from	to	target	type
    //   2	12	38	finally
    //   17	23	38	finally
    //   23	35	38	finally
  }
  
  void nScriptSetVarV(long paramLong, int paramInt, byte[] paramArrayOfbyte, boolean paramBoolean) {
    // Byte code:
    //   0: aload_0
    //   1: monitorenter
    //   2: aload_0
    //   3: invokevirtual validate : ()V
    //   6: aload_0
    //   7: getfield mContext : J
    //   10: lstore #6
    //   12: iload #5
    //   14: ifeq -> 23
    //   17: aload_0
    //   18: getfield mIncCon : J
    //   21: lstore #6
    //   23: aload_0
    //   24: lload #6
    //   26: lload_1
    //   27: iload_3
    //   28: aload #4
    //   30: iload #5
    //   32: invokevirtual rsnScriptSetVarV : (JJI[BZ)V
    //   35: aload_0
    //   36: monitorexit
    //   37: return
    //   38: astore #4
    //   40: aload_0
    //   41: monitorexit
    //   42: aload #4
    //   44: athrow
    // Exception table:
    //   from	to	target	type
    //   2	12	38	finally
    //   17	23	38	finally
    //   23	35	38	finally
  }
  
  void nScriptSetVarVE(long paramLong1, int paramInt, byte[] paramArrayOfbyte, long paramLong2, int[] paramArrayOfint, boolean paramBoolean) {
    // Byte code:
    //   0: aload_0
    //   1: monitorenter
    //   2: aload_0
    //   3: invokevirtual validate : ()V
    //   6: aload_0
    //   7: getfield mContext : J
    //   10: lstore #9
    //   12: iload #8
    //   14: ifeq -> 23
    //   17: aload_0
    //   18: getfield mIncCon : J
    //   21: lstore #9
    //   23: aload_0
    //   24: lload #9
    //   26: lload_1
    //   27: iload_3
    //   28: aload #4
    //   30: lload #5
    //   32: aload #7
    //   34: iload #8
    //   36: invokevirtual rsnScriptSetVarVE : (JJI[BJ[IZ)V
    //   39: aload_0
    //   40: monitorexit
    //   41: return
    //   42: astore #4
    //   44: aload_0
    //   45: monitorexit
    //   46: aload #4
    //   48: athrow
    // Exception table:
    //   from	to	target	type
    //   2	12	42	finally
    //   17	23	42	finally
    //   23	39	42	finally
  }
  
  long nTypeCreate(long paramLong, int paramInt1, int paramInt2, int paramInt3, boolean paramBoolean1, boolean paramBoolean2, int paramInt4) {
    // Byte code:
    //   0: aload_0
    //   1: monitorenter
    //   2: aload_0
    //   3: invokevirtual validate : ()V
    //   6: aload_0
    //   7: aload_0
    //   8: getfield mContext : J
    //   11: lload_1
    //   12: iload_3
    //   13: iload #4
    //   15: iload #5
    //   17: iload #6
    //   19: iload #7
    //   21: iload #8
    //   23: invokevirtual rsnTypeCreate : (JJIIIZZI)J
    //   26: lstore_1
    //   27: aload_0
    //   28: monitorexit
    //   29: lload_1
    //   30: lreturn
    //   31: astore #9
    //   33: aload_0
    //   34: monitorexit
    //   35: aload #9
    //   37: athrow
    // Exception table:
    //   from	to	target	type
    //   2	27	31	finally
  }
  
  void nTypeGetNativeData(long paramLong, long[] paramArrayOflong) {
    // Byte code:
    //   0: aload_0
    //   1: monitorenter
    //   2: aload_0
    //   3: invokevirtual validate : ()V
    //   6: aload_0
    //   7: aload_0
    //   8: getfield mContext : J
    //   11: lload_1
    //   12: aload_3
    //   13: invokevirtual rsnTypeGetNativeData : (JJ[J)V
    //   16: aload_0
    //   17: monitorexit
    //   18: return
    //   19: astore_3
    //   20: aload_0
    //   21: monitorexit
    //   22: aload_3
    //   23: athrow
    // Exception table:
    //   from	to	target	type
    //   2	16	19	finally
  }
  
  native void rsnAllocationCopyFromBitmap(long paramLong1, long paramLong2, Bitmap paramBitmap);
  
  native void rsnAllocationCopyToBitmap(long paramLong1, long paramLong2, Bitmap paramBitmap);
  
  native long rsnAllocationCreateBitmapBackedAllocation(long paramLong1, long paramLong2, int paramInt1, Bitmap paramBitmap, int paramInt2);
  
  native long rsnAllocationCreateBitmapRef(long paramLong1, long paramLong2, Bitmap paramBitmap);
  
  native long rsnAllocationCreateFromAssetStream(long paramLong, int paramInt1, int paramInt2, int paramInt3);
  
  native long rsnAllocationCreateFromBitmap(long paramLong1, long paramLong2, int paramInt1, Bitmap paramBitmap, int paramInt2);
  
  native long rsnAllocationCreateTyped(long paramLong1, long paramLong2, int paramInt1, int paramInt2, long paramLong3);
  
  native long rsnAllocationCubeCreateFromBitmap(long paramLong1, long paramLong2, int paramInt1, Bitmap paramBitmap, int paramInt2);
  
  native void rsnAllocationData1D(long paramLong1, long paramLong2, int paramInt1, int paramInt2, int paramInt3, Object paramObject, int paramInt4, int paramInt5, int paramInt6, boolean paramBoolean);
  
  native void rsnAllocationData2D(long paramLong1, long paramLong2, int paramInt1, int paramInt2, int paramInt3, int paramInt4, int paramInt5, int paramInt6, long paramLong3, int paramInt7, int paramInt8, int paramInt9, int paramInt10);
  
  native void rsnAllocationData2D(long paramLong1, long paramLong2, int paramInt1, int paramInt2, int paramInt3, int paramInt4, int paramInt5, int paramInt6, Object paramObject, int paramInt7, int paramInt8, int paramInt9, boolean paramBoolean);
  
  native void rsnAllocationData2D(long paramLong1, long paramLong2, int paramInt1, int paramInt2, int paramInt3, int paramInt4, Bitmap paramBitmap);
  
  native void rsnAllocationData3D(long paramLong1, long paramLong2, int paramInt1, int paramInt2, int paramInt3, int paramInt4, int paramInt5, int paramInt6, int paramInt7, long paramLong3, int paramInt8, int paramInt9, int paramInt10, int paramInt11);
  
  native void rsnAllocationData3D(long paramLong1, long paramLong2, int paramInt1, int paramInt2, int paramInt3, int paramInt4, int paramInt5, int paramInt6, int paramInt7, Object paramObject, int paramInt8, int paramInt9, int paramInt10, boolean paramBoolean);
  
  native void rsnAllocationElementData1D(long paramLong1, long paramLong2, int paramInt1, int paramInt2, int paramInt3, byte[] paramArrayOfbyte, int paramInt4);
  
  native void rsnAllocationGenerateMipmaps(long paramLong1, long paramLong2);
  
  native ByteBuffer rsnAllocationGetByteBuffer(long paramLong1, long paramLong2, int paramInt1, int paramInt2, int paramInt3);
  
  native long rsnAllocationGetStride(long paramLong1, long paramLong2);
  
  native long rsnAllocationGetType(long paramLong1, long paramLong2);
  
  native void rsnAllocationIoReceive(long paramLong1, long paramLong2);
  
  native void rsnAllocationIoSend(long paramLong1, long paramLong2);
  
  native void rsnAllocationRead(long paramLong1, long paramLong2, Object paramObject, int paramInt1, int paramInt2, boolean paramBoolean);
  
  native void rsnAllocationRead1D(long paramLong1, long paramLong2, int paramInt1, int paramInt2, int paramInt3, Object paramObject, int paramInt4, int paramInt5, int paramInt6, boolean paramBoolean);
  
  native void rsnAllocationRead2D(long paramLong1, long paramLong2, int paramInt1, int paramInt2, int paramInt3, int paramInt4, int paramInt5, int paramInt6, Object paramObject, int paramInt7, int paramInt8, int paramInt9, boolean paramBoolean);
  
  native void rsnAllocationResize1D(long paramLong1, long paramLong2, int paramInt);
  
  native void rsnAllocationResize2D(long paramLong1, long paramLong2, int paramInt1, int paramInt2);
  
  native void rsnAllocationSetSurface(long paramLong1, long paramLong2, Surface paramSurface);
  
  native void rsnAllocationSyncAll(long paramLong1, long paramLong2, int paramInt);
  
  native long rsnClosureCreate(long paramLong1, long paramLong2, long paramLong3, long[] paramArrayOflong1, long[] paramArrayOflong2, int[] paramArrayOfint, long[] paramArrayOflong3, long[] paramArrayOflong4);
  
  native void rsnClosureSetArg(long paramLong1, long paramLong2, int paramInt1, long paramLong3, int paramInt2);
  
  native void rsnClosureSetGlobal(long paramLong1, long paramLong2, long paramLong3, long paramLong4, int paramInt);
  
  native long rsnContextCreate(long paramLong, int paramInt1, int paramInt2, int paramInt3, String paramString);
  
  native void rsnContextDestroy(long paramLong);
  
  native void rsnContextDump(long paramLong, int paramInt);
  
  native void rsnContextFinish(long paramLong);
  
  native void rsnContextSendMessage(long paramLong, int paramInt, int[] paramArrayOfint);
  
  native void rsnContextSetPriority(long paramLong, int paramInt);
  
  native long rsnElementCreate(long paramLong1, long paramLong2, int paramInt1, boolean paramBoolean, int paramInt2);
  
  native long rsnElementCreate2(long paramLong, long[] paramArrayOflong, String[] paramArrayOfString, int[] paramArrayOfint);
  
  native void rsnElementGetNativeData(long paramLong1, long paramLong2, int[] paramArrayOfint);
  
  native void rsnElementGetSubElements(long paramLong1, long paramLong2, long[] paramArrayOflong, String[] paramArrayOfString, int[] paramArrayOfint);
  
  native long rsnIncAllocationCreateTyped(long paramLong1, long paramLong2, long paramLong3, long paramLong4, int paramInt);
  
  native long rsnIncContextCreate(long paramLong, int paramInt1, int paramInt2, int paramInt3);
  
  native void rsnIncContextDestroy(long paramLong);
  
  native void rsnIncContextFinish(long paramLong);
  
  native long rsnIncElementCreate(long paramLong1, long paramLong2, int paramInt1, boolean paramBoolean, int paramInt2);
  
  native void rsnIncObjDestroy(long paramLong1, long paramLong2);
  
  native long rsnIncTypeCreate(long paramLong1, long paramLong2, int paramInt1, int paramInt2, int paramInt3, boolean paramBoolean1, boolean paramBoolean2, int paramInt4);
  
  native long rsnInvokeClosureCreate(long paramLong1, long paramLong2, byte[] paramArrayOfbyte, long[] paramArrayOflong1, long[] paramArrayOflong2, int[] paramArrayOfint);
  
  native void rsnObjDestroy(long paramLong1, long paramLong2);
  
  native long rsnSamplerCreate(long paramLong, int paramInt1, int paramInt2, int paramInt3, int paramInt4, int paramInt5, float paramFloat);
  
  native void rsnScriptBindAllocation(long paramLong1, long paramLong2, long paramLong3, int paramInt, boolean paramBoolean);
  
  native long rsnScriptCCreate(long paramLong, String paramString1, String paramString2, byte[] paramArrayOfbyte, int paramInt);
  
  native long rsnScriptFieldIDCreate(long paramLong1, long paramLong2, int paramInt, boolean paramBoolean);
  
  native void rsnScriptForEach(long paramLong1, long paramLong2, int paramInt, long[] paramArrayOflong, long paramLong3, byte[] paramArrayOfbyte, int[] paramArrayOfint);
  
  native void rsnScriptForEach(long paramLong1, long paramLong2, long paramLong3, int paramInt, long paramLong4, long paramLong5, boolean paramBoolean);
  
  native void rsnScriptForEach(long paramLong1, long paramLong2, long paramLong3, int paramInt, long paramLong4, long paramLong5, byte[] paramArrayOfbyte, boolean paramBoolean);
  
  native void rsnScriptForEachClipped(long paramLong1, long paramLong2, long paramLong3, int paramInt1, long paramLong4, long paramLong5, int paramInt2, int paramInt3, int paramInt4, int paramInt5, int paramInt6, int paramInt7, boolean paramBoolean);
  
  native void rsnScriptForEachClipped(long paramLong1, long paramLong2, long paramLong3, int paramInt1, long paramLong4, long paramLong5, byte[] paramArrayOfbyte, int paramInt2, int paramInt3, int paramInt4, int paramInt5, int paramInt6, int paramInt7, boolean paramBoolean);
  
  native long rsnScriptGroup2Create(long paramLong, String paramString1, String paramString2, long[] paramArrayOflong);
  
  native void rsnScriptGroup2Execute(long paramLong1, long paramLong2);
  
  native long rsnScriptGroupCreate(long paramLong, long[] paramArrayOflong1, long[] paramArrayOflong2, long[] paramArrayOflong3, long[] paramArrayOflong4, long[] paramArrayOflong5);
  
  native void rsnScriptGroupExecute(long paramLong1, long paramLong2);
  
  native void rsnScriptGroupSetInput(long paramLong1, long paramLong2, long paramLong3, long paramLong4);
  
  native void rsnScriptGroupSetOutput(long paramLong1, long paramLong2, long paramLong3, long paramLong4);
  
  native void rsnScriptIntrinsicBLAS_BNNM(long paramLong1, long paramLong2, long paramLong3, int paramInt1, int paramInt2, int paramInt3, long paramLong4, int paramInt4, long paramLong5, int paramInt5, long paramLong6, int paramInt6, int paramInt7, boolean paramBoolean);
  
  native void rsnScriptIntrinsicBLAS_Complex(long paramLong1, long paramLong2, long paramLong3, int paramInt1, int paramInt2, int paramInt3, int paramInt4, int paramInt5, int paramInt6, int paramInt7, int paramInt8, int paramInt9, float paramFloat1, float paramFloat2, long paramLong4, long paramLong5, float paramFloat3, float paramFloat4, long paramLong6, int paramInt10, int paramInt11, int paramInt12, int paramInt13, boolean paramBoolean);
  
  native void rsnScriptIntrinsicBLAS_Double(long paramLong1, long paramLong2, long paramLong3, int paramInt1, int paramInt2, int paramInt3, int paramInt4, int paramInt5, int paramInt6, int paramInt7, int paramInt8, int paramInt9, double paramDouble1, long paramLong4, long paramLong5, double paramDouble2, long paramLong6, int paramInt10, int paramInt11, int paramInt12, int paramInt13, boolean paramBoolean);
  
  native void rsnScriptIntrinsicBLAS_Single(long paramLong1, long paramLong2, long paramLong3, int paramInt1, int paramInt2, int paramInt3, int paramInt4, int paramInt5, int paramInt6, int paramInt7, int paramInt8, int paramInt9, float paramFloat1, long paramLong4, long paramLong5, float paramFloat2, long paramLong6, int paramInt10, int paramInt11, int paramInt12, int paramInt13, boolean paramBoolean);
  
  native void rsnScriptIntrinsicBLAS_Z(long paramLong1, long paramLong2, long paramLong3, int paramInt1, int paramInt2, int paramInt3, int paramInt4, int paramInt5, int paramInt6, int paramInt7, int paramInt8, int paramInt9, double paramDouble1, double paramDouble2, long paramLong4, long paramLong5, double paramDouble3, double paramDouble4, long paramLong6, int paramInt10, int paramInt11, int paramInt12, int paramInt13, boolean paramBoolean);
  
  native long rsnScriptIntrinsicCreate(long paramLong1, int paramInt, long paramLong2, boolean paramBoolean);
  
  native void rsnScriptInvoke(long paramLong1, long paramLong2, int paramInt, boolean paramBoolean);
  
  native long rsnScriptInvokeIDCreate(long paramLong1, long paramLong2, int paramInt);
  
  native void rsnScriptInvokeV(long paramLong1, long paramLong2, int paramInt, byte[] paramArrayOfbyte, boolean paramBoolean);
  
  native long rsnScriptKernelIDCreate(long paramLong1, long paramLong2, int paramInt1, int paramInt2, boolean paramBoolean);
  
  native void rsnScriptReduce(long paramLong1, long paramLong2, int paramInt, long[] paramArrayOflong, long paramLong3, int[] paramArrayOfint);
  
  native void rsnScriptSetTimeZone(long paramLong1, long paramLong2, byte[] paramArrayOfbyte, boolean paramBoolean);
  
  native void rsnScriptSetVarD(long paramLong1, long paramLong2, int paramInt, double paramDouble, boolean paramBoolean);
  
  native void rsnScriptSetVarF(long paramLong1, long paramLong2, int paramInt, float paramFloat, boolean paramBoolean);
  
  native void rsnScriptSetVarI(long paramLong1, long paramLong2, int paramInt1, int paramInt2, boolean paramBoolean);
  
  native void rsnScriptSetVarJ(long paramLong1, long paramLong2, int paramInt, long paramLong3, boolean paramBoolean);
  
  native void rsnScriptSetVarObj(long paramLong1, long paramLong2, int paramInt, long paramLong3, boolean paramBoolean);
  
  native void rsnScriptSetVarV(long paramLong1, long paramLong2, int paramInt, byte[] paramArrayOfbyte, boolean paramBoolean);
  
  native void rsnScriptSetVarVE(long paramLong1, long paramLong2, int paramInt, byte[] paramArrayOfbyte, long paramLong3, int[] paramArrayOfint, boolean paramBoolean);
  
  native long rsnTypeCreate(long paramLong1, long paramLong2, int paramInt1, int paramInt2, int paramInt3, boolean paramBoolean1, boolean paramBoolean2, int paramInt4);
  
  native void rsnTypeGetNativeData(long paramLong1, long paramLong2, long[] paramArrayOflong);
  
  long safeID(BaseObj paramBaseObj) {
    return (paramBaseObj != null) ? paramBaseObj.getID(this) : 0L;
  }
  
  public void sendMessage(int paramInt, int[] paramArrayOfint) {
    nContextSendMessage(paramInt, paramArrayOfint);
  }
  
  public void setErrorHandler(RSErrorHandler paramRSErrorHandler) {
    this.mErrorCallback = paramRSErrorHandler;
  }
  
  public void setMessageHandler(RSMessageHandler paramRSMessageHandler) {
    this.mMessageCallback = paramRSMessageHandler;
  }
  
  public void setPriority(Priority paramPriority) {
    validate();
    nContextSetPriority(paramPriority.mID);
  }
  
  boolean usingIO() {
    return useIOlib;
  }
  
  void validate() {
    if (this.mContext != 0L)
      return; 
    throw new RSInvalidStateException("Calling RS with no Context active.");
  }
  
  void validateObject(BaseObj paramBaseObj) {
    if (paramBaseObj != null) {
      if (paramBaseObj.mRS == this)
        return; 
      throw new RSIllegalArgumentException("Attempting to use an object across contexts.");
    } 
  }
  
  public enum ContextType {
    DEBUG, NORMAL, PROFILE;
    
    int mID;
    
    static {
      ContextType contextType1 = new ContextType("NORMAL", 0, 0);
      NORMAL = contextType1;
      ContextType contextType2 = new ContextType("DEBUG", 1, 1);
      DEBUG = contextType2;
      ContextType contextType3 = new ContextType("PROFILE", 2, 2);
      PROFILE = contextType3;
      $VALUES = new ContextType[] { contextType1, contextType2, contextType3 };
    }
    
    ContextType(int param1Int1) {
      this.mID = param1Int1;
    }
  }
  
  static class MessageThread extends Thread {
    static final int RS_ERROR_FATAL_DEBUG = 2048;
    
    static final int RS_ERROR_FATAL_UNKNOWN = 4096;
    
    static final int RS_MESSAGE_TO_CLIENT_ERROR = 3;
    
    static final int RS_MESSAGE_TO_CLIENT_EXCEPTION = 1;
    
    static final int RS_MESSAGE_TO_CLIENT_NONE = 0;
    
    static final int RS_MESSAGE_TO_CLIENT_RESIZE = 2;
    
    static final int RS_MESSAGE_TO_CLIENT_USER = 4;
    
    int[] mAuxData = new int[2];
    
    RenderScript mRS;
    
    boolean mRun = true;
    
    MessageThread(RenderScript param1RenderScript) {
      super("RSMessageThread");
      this.mRS = param1RenderScript;
    }
    
    public void run() {
      // Byte code:
      //   0: bipush #16
      //   2: newarray int
      //   4: astore #4
      //   6: aload_0
      //   7: getfield mRS : Landroidx/renderscript/RenderScript;
      //   10: astore #5
      //   12: aload #5
      //   14: aload #5
      //   16: getfield mContext : J
      //   19: invokevirtual nContextInitToClient : (J)V
      //   22: aload_0
      //   23: getfield mRun : Z
      //   26: ifeq -> 421
      //   29: aload #4
      //   31: iconst_0
      //   32: iconst_0
      //   33: iastore
      //   34: aload_0
      //   35: getfield mRS : Landroidx/renderscript/RenderScript;
      //   38: astore #5
      //   40: aload #5
      //   42: aload #5
      //   44: getfield mContext : J
      //   47: aload_0
      //   48: getfield mAuxData : [I
      //   51: invokevirtual nContextPeekMessage : (J[I)I
      //   54: istore_1
      //   55: aload_0
      //   56: getfield mAuxData : [I
      //   59: astore #5
      //   61: aload #5
      //   63: iconst_1
      //   64: iaload
      //   65: istore_2
      //   66: aload #5
      //   68: iconst_0
      //   69: iaload
      //   70: istore_3
      //   71: iload_1
      //   72: iconst_4
      //   73: if_icmpne -> 185
      //   76: aload #4
      //   78: astore #5
      //   80: iload_2
      //   81: iconst_2
      //   82: ishr
      //   83: aload #4
      //   85: arraylength
      //   86: if_icmplt -> 98
      //   89: iload_2
      //   90: iconst_3
      //   91: iadd
      //   92: iconst_2
      //   93: ishr
      //   94: newarray int
      //   96: astore #5
      //   98: aload_0
      //   99: getfield mRS : Landroidx/renderscript/RenderScript;
      //   102: astore #4
      //   104: aload #4
      //   106: aload #4
      //   108: getfield mContext : J
      //   111: aload #5
      //   113: invokevirtual nContextGetUserMessage : (J[I)I
      //   116: iconst_4
      //   117: if_icmpne -> 175
      //   120: aload_0
      //   121: getfield mRS : Landroidx/renderscript/RenderScript;
      //   124: getfield mMessageCallback : Landroidx/renderscript/RenderScript$RSMessageHandler;
      //   127: astore #4
      //   129: aload #4
      //   131: ifnull -> 165
      //   134: aload #4
      //   136: aload #5
      //   138: putfield mData : [I
      //   141: aload #4
      //   143: iload_3
      //   144: putfield mID : I
      //   147: aload #4
      //   149: iload_2
      //   150: putfield mLength : I
      //   153: aload #4
      //   155: invokevirtual run : ()V
      //   158: aload #5
      //   160: astore #4
      //   162: goto -> 22
      //   165: new androidx/renderscript/RSInvalidStateException
      //   168: dup
      //   169: ldc 'Received a message from the script with no message handler installed.'
      //   171: invokespecial <init> : (Ljava/lang/String;)V
      //   174: athrow
      //   175: new androidx/renderscript/RSDriverException
      //   178: dup
      //   179: ldc 'Error processing message from RenderScript.'
      //   181: invokespecial <init> : (Ljava/lang/String;)V
      //   184: athrow
      //   185: iload_1
      //   186: iconst_3
      //   187: if_icmpne -> 410
      //   190: aload_0
      //   191: getfield mRS : Landroidx/renderscript/RenderScript;
      //   194: astore #5
      //   196: aload #5
      //   198: aload #5
      //   200: getfield mContext : J
      //   203: invokevirtual nContextGetErrorMessage : (J)Ljava/lang/String;
      //   206: astore #5
      //   208: iload_3
      //   209: sipush #4096
      //   212: if_icmpge -> 321
      //   215: iload_3
      //   216: sipush #2048
      //   219: if_icmplt -> 247
      //   222: aload_0
      //   223: getfield mRS : Landroidx/renderscript/RenderScript;
      //   226: astore #6
      //   228: aload #6
      //   230: getfield mContextType : Landroidx/renderscript/RenderScript$ContextType;
      //   233: getstatic androidx/renderscript/RenderScript$ContextType.DEBUG : Landroidx/renderscript/RenderScript$ContextType;
      //   236: if_acmpne -> 321
      //   239: aload #6
      //   241: getfield mErrorCallback : Landroidx/renderscript/RenderScript$RSErrorHandler;
      //   244: ifnull -> 321
      //   247: aload_0
      //   248: getfield mRS : Landroidx/renderscript/RenderScript;
      //   251: getfield mErrorCallback : Landroidx/renderscript/RenderScript$RSErrorHandler;
      //   254: astore #6
      //   256: aload #6
      //   258: ifnull -> 282
      //   261: aload #6
      //   263: aload #5
      //   265: putfield mErrorMessage : Ljava/lang/String;
      //   268: aload #6
      //   270: iload_3
      //   271: putfield mErrorNum : I
      //   274: aload #6
      //   276: invokevirtual run : ()V
      //   279: goto -> 22
      //   282: new java/lang/StringBuilder
      //   285: dup
      //   286: invokespecial <init> : ()V
      //   289: astore #6
      //   291: aload #6
      //   293: ldc 'non fatal RS error, '
      //   295: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
      //   298: pop
      //   299: aload #6
      //   301: aload #5
      //   303: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
      //   306: pop
      //   307: ldc 'RenderScript_jni'
      //   309: aload #6
      //   311: invokevirtual toString : ()Ljava/lang/String;
      //   314: invokestatic e : (Ljava/lang/String;Ljava/lang/String;)I
      //   317: pop
      //   318: goto -> 22
      //   321: new java/lang/StringBuilder
      //   324: dup
      //   325: invokespecial <init> : ()V
      //   328: astore #4
      //   330: aload #4
      //   332: ldc 'fatal RS error, '
      //   334: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
      //   337: pop
      //   338: aload #4
      //   340: aload #5
      //   342: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
      //   345: pop
      //   346: ldc 'RenderScript_jni'
      //   348: aload #4
      //   350: invokevirtual toString : ()Ljava/lang/String;
      //   353: invokestatic e : (Ljava/lang/String;Ljava/lang/String;)I
      //   356: pop
      //   357: new java/lang/StringBuilder
      //   360: dup
      //   361: invokespecial <init> : ()V
      //   364: astore #4
      //   366: aload #4
      //   368: ldc 'Fatal error '
      //   370: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
      //   373: pop
      //   374: aload #4
      //   376: iload_3
      //   377: invokevirtual append : (I)Ljava/lang/StringBuilder;
      //   380: pop
      //   381: aload #4
      //   383: ldc ', details: '
      //   385: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
      //   388: pop
      //   389: aload #4
      //   391: aload #5
      //   393: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
      //   396: pop
      //   397: new androidx/renderscript/RSRuntimeException
      //   400: dup
      //   401: aload #4
      //   403: invokevirtual toString : ()Ljava/lang/String;
      //   406: invokespecial <init> : (Ljava/lang/String;)V
      //   409: athrow
      //   410: lconst_1
      //   411: iconst_0
      //   412: invokestatic sleep : (JI)V
      //   415: goto -> 22
      //   418: goto -> 22
      //   421: return
      //   422: astore #5
      //   424: goto -> 418
      // Exception table:
      //   from	to	target	type
      //   410	415	422	java/lang/InterruptedException
    }
  }
  
  public enum Priority {
    LOW, NORMAL;
    
    int mID;
    
    static {
      Priority priority1 = new Priority("LOW", 0, 15);
      LOW = priority1;
      Priority priority2 = new Priority("NORMAL", 1, -4);
      NORMAL = priority2;
      $VALUES = new Priority[] { priority1, priority2 };
    }
    
    Priority(int param1Int1) {
      this.mID = param1Int1;
    }
  }
  
  public static class RSErrorHandler implements Runnable {
    protected String mErrorMessage;
    
    protected int mErrorNum;
    
    public void run() {}
  }
  
  public static class RSMessageHandler implements Runnable {
    protected int[] mData;
    
    protected int mID;
    
    protected int mLength;
    
    public void run() {}
  }
}


/* Location:              C:\soft\dex2jar-2.0\MagicAI - AI Art & Anime Art-dex2jar.jar!\androidx\renderscript\RenderScript.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */