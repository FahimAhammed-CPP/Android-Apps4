package androidx.renderscript;

public class Byte4 {
  public byte w;
  
  public byte x;
  
  public byte y;
  
  public byte z;
  
  public Byte4() {}
  
  public Byte4(byte paramByte1, byte paramByte2, byte paramByte3, byte paramByte4) {
    this.x = paramByte1;
    this.y = paramByte2;
    this.z = paramByte3;
    this.w = paramByte4;
  }
}


/* Location:              C:\soft\dex2jar-2.0\MagicAI - AI Art & Anime Art-dex2jar.jar!\androidx\renderscript\Byte4.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */