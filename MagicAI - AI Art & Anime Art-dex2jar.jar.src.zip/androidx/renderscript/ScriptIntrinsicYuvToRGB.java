package androidx.renderscript;

public class ScriptIntrinsicYuvToRGB extends ScriptIntrinsic {
  private static final int INTRINSIC_API_LEVEL = 19;
  
  private Allocation mInput;
  
  ScriptIntrinsicYuvToRGB(long paramLong, RenderScript paramRenderScript) {
    super(paramLong, paramRenderScript);
  }
  
  public static ScriptIntrinsicYuvToRGB create(RenderScript paramRenderScript, Element paramElement) {
    paramRenderScript.isUseNative();
    ScriptIntrinsicYuvToRGB scriptIntrinsicYuvToRGB = new ScriptIntrinsicYuvToRGB(paramRenderScript.nScriptIntrinsicCreate(6, paramElement.getID(paramRenderScript), false), paramRenderScript);
    scriptIntrinsicYuvToRGB.setIncSupp(false);
    return scriptIntrinsicYuvToRGB;
  }
  
  public void forEach(Allocation paramAllocation) {
    forEach(0, (Allocation)null, paramAllocation, (FieldPacker)null);
  }
  
  public Script.FieldID getFieldID_Input() {
    return createFieldID(0, null);
  }
  
  public Script.KernelID getKernelID() {
    return createKernelID(0, 2, null, null);
  }
  
  public void setInput(Allocation paramAllocation) {
    this.mInput = paramAllocation;
    setVar(0, (BaseObj)paramAllocation);
  }
}


/* Location:              C:\soft\dex2jar-2.0\MagicAI - AI Art & Anime Art-dex2jar.jar!\androidx\renderscript\ScriptIntrinsicYuvToRGB.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */