package com.google.android.gms.ads.identifier;

import android.content.Context;
import android.content.Intent;
import android.content.ServiceConnection;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.os.Bundle;
import android.util.Log;
import com.google.android.gms.common.GooglePlayServicesNotAvailableException;
import com.google.android.gms.common.GooglePlayServicesRepairableException;
import com.google.android.gms.common.internal.zzac;
import com.google.android.gms.common.zze;
import com.google.android.gms.common.zzg;
import com.google.android.gms.internal.zzcq;
import java.io.IOException;
import java.lang.ref.WeakReference;
import java.util.concurrent.CountDownLatch;
import java.util.concurrent.TimeUnit;

public class AdvertisingIdClient {
  private final Context mContext;
  
  com.google.android.gms.common.zza zzsa;
  
  zzcq zzsb;
  
  boolean zzsc;
  
  Object zzsd = new Object();
  
  zza zzse;
  
  final long zzsf;
  
  public AdvertisingIdClient(Context paramContext) {
    this(paramContext, 30000L, false);
  }
  
  public AdvertisingIdClient(Context paramContext, long paramLong, boolean paramBoolean) {
    zzac.zzw(paramContext);
    if (paramBoolean) {
      Context context = paramContext.getApplicationContext();
      if (context != null)
        paramContext = context; 
      this.mContext = paramContext;
    } else {
      this.mContext = paramContext;
    } 
    this.zzsc = false;
    this.zzsf = paramLong;
  }
  
  public static Info getAdvertisingIdInfo(Context paramContext) throws IOException, IllegalStateException, GooglePlayServicesNotAvailableException, GooglePlayServicesRepairableException {
    float f1;
    float f2 = 0.0F;
    boolean bool2 = false;
    boolean bool3 = false;
    boolean bool1 = bool2;
    try {
      Context context = zzg.getRemoteContext(paramContext);
      f1 = f2;
      bool1 = bool3;
      if (context != null) {
        bool1 = bool2;
        SharedPreferences sharedPreferences = context.getSharedPreferences("google_ads_flags", 1);
        bool1 = bool2;
        bool2 = sharedPreferences.getBoolean("gads:ad_id_app_context:enabled", false);
        bool1 = bool2;
        f1 = sharedPreferences.getFloat("gads:ad_id_app_context:ping_ratio", 0.0F);
        bool1 = bool2;
      } 
    } catch (Exception exception) {
      Log.w("AdvertisingIdClient", "Error while reading from SharedPreferences ", exception);
      f1 = f2;
    } 
    AdvertisingIdClient advertisingIdClient = new AdvertisingIdClient(paramContext, -1L, bool1);
    try {
      advertisingIdClient.zze(false);
      Info info = advertisingIdClient.getInfo();
      advertisingIdClient.zza(info, bool1, f1, null);
      return info;
    } catch (Throwable throwable) {
      advertisingIdClient.zza(null, bool1, f1, throwable);
      return null;
    } finally {
      advertisingIdClient.finish();
    } 
  }
  
  public static void setShouldSkipGmsCoreVersionCheck(boolean paramBoolean) {}
  
  static zzcq zza(Context paramContext, com.google.android.gms.common.zza paramzza) throws IOException {
    try {
      return zzcq.zza.zzf(paramzza.zza(10000L, TimeUnit.MILLISECONDS));
    } catch (InterruptedException interruptedException) {
      throw new IOException("Interrupted exception");
    } catch (Throwable throwable) {
      throw new IOException(throwable);
    } 
  }
  
  private void zza(Info paramInfo, boolean paramBoolean, float paramFloat, Throwable paramThrowable) {
    if (Math.random() > paramFloat)
      return; 
    (new Thread(this, zza(paramInfo, paramBoolean, paramThrowable).toString()) {
        public void run() {
          (new zza()).zzu(this.zzsg);
        }
      }).start();
  }
  
  private void zzbw() {
    synchronized (this.zzsd) {
      if (this.zzse != null) {
        this.zzse.cancel();
        try {
          this.zzse.join();
        } catch (InterruptedException interruptedException) {}
      } 
      if (this.zzsf > 0L)
        this.zzse = new zza(this, this.zzsf); 
      return;
    } 
  }
  
  static com.google.android.gms.common.zza zzf(Context paramContext) throws IOException, GooglePlayServicesNotAvailableException, GooglePlayServicesRepairableException {
    try {
      paramContext.getPackageManager().getPackageInfo("com.android.vending", 0);
      switch (zze.zzuY().isGooglePlayServicesAvailable(paramContext)) {
        default:
          throw new IOException("Google Play services not available");
        case 0:
        case 2:
          break;
      } 
    } catch (android.content.pm.PackageManager.NameNotFoundException nameNotFoundException) {
      throw new GooglePlayServicesNotAvailableException(9);
    } 
    com.google.android.gms.common.zza zza1 = new com.google.android.gms.common.zza();
    Intent intent = new Intent("com.google.android.gms.ads.identifier.service.START");
    intent.setPackage("com.google.android.gms");
    try {
      boolean bool = com.google.android.gms.common.stats.zza.zzyJ().zza((Context)nameNotFoundException, intent, (ServiceConnection)zza1, 1);
      if (bool)
        return zza1; 
    } catch (Throwable throwable) {
      throw new IOException(throwable);
    } 
    throw new IOException("Connection failure");
  }
  
  protected void finalize() throws Throwable {
    finish();
    super.finalize();
  }
  
  public void finish() {
    // Byte code:
    //   0: ldc 'Calling this from your main thread can lead to deadlock'
    //   2: invokestatic zzdk : (Ljava/lang/String;)V
    //   5: aload_0
    //   6: monitorenter
    //   7: aload_0
    //   8: getfield mContext : Landroid/content/Context;
    //   11: ifnull -> 21
    //   14: aload_0
    //   15: getfield zzsa : Lcom/google/android/gms/common/zza;
    //   18: ifnonnull -> 24
    //   21: aload_0
    //   22: monitorexit
    //   23: return
    //   24: aload_0
    //   25: getfield zzsc : Z
    //   28: ifeq -> 45
    //   31: invokestatic zzyJ : ()Lcom/google/android/gms/common/stats/zza;
    //   34: aload_0
    //   35: getfield mContext : Landroid/content/Context;
    //   38: aload_0
    //   39: getfield zzsa : Lcom/google/android/gms/common/zza;
    //   42: invokevirtual zza : (Landroid/content/Context;Landroid/content/ServiceConnection;)V
    //   45: aload_0
    //   46: iconst_0
    //   47: putfield zzsc : Z
    //   50: aload_0
    //   51: aconst_null
    //   52: putfield zzsb : Lcom/google/android/gms/internal/zzcq;
    //   55: aload_0
    //   56: aconst_null
    //   57: putfield zzsa : Lcom/google/android/gms/common/zza;
    //   60: aload_0
    //   61: monitorexit
    //   62: return
    //   63: astore_1
    //   64: aload_0
    //   65: monitorexit
    //   66: aload_1
    //   67: athrow
    //   68: astore_1
    //   69: ldc 'AdvertisingIdClient'
    //   71: ldc_w 'AdvertisingIdClient unbindService failed.'
    //   74: aload_1
    //   75: invokestatic i : (Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)I
    //   78: pop
    //   79: goto -> 45
    //   82: astore_1
    //   83: ldc 'AdvertisingIdClient'
    //   85: ldc_w 'AdvertisingIdClient unbindService failed.'
    //   88: aload_1
    //   89: invokestatic i : (Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)I
    //   92: pop
    //   93: goto -> 45
    // Exception table:
    //   from	to	target	type
    //   7	21	63	finally
    //   21	23	63	finally
    //   24	45	68	java/lang/IllegalArgumentException
    //   24	45	82	java/lang/Throwable
    //   24	45	63	finally
    //   45	62	63	finally
    //   64	66	63	finally
    //   69	79	63	finally
    //   83	93	63	finally
  }
  
  public Info getInfo() throws IOException {
    // Byte code:
    //   0: ldc 'Calling this from your main thread can lead to deadlock'
    //   2: invokestatic zzdk : (Ljava/lang/String;)V
    //   5: aload_0
    //   6: monitorenter
    //   7: aload_0
    //   8: getfield zzsc : Z
    //   11: ifne -> 97
    //   14: aload_0
    //   15: getfield zzsd : Ljava/lang/Object;
    //   18: astore_1
    //   19: aload_1
    //   20: monitorenter
    //   21: aload_0
    //   22: getfield zzse : Lcom/google/android/gms/ads/identifier/AdvertisingIdClient$zza;
    //   25: ifnull -> 38
    //   28: aload_0
    //   29: getfield zzse : Lcom/google/android/gms/ads/identifier/AdvertisingIdClient$zza;
    //   32: invokevirtual zzbx : ()Z
    //   35: ifne -> 59
    //   38: new java/io/IOException
    //   41: dup
    //   42: ldc_w 'AdvertisingIdClient is not connected.'
    //   45: invokespecial <init> : (Ljava/lang/String;)V
    //   48: athrow
    //   49: astore_2
    //   50: aload_1
    //   51: monitorexit
    //   52: aload_2
    //   53: athrow
    //   54: astore_1
    //   55: aload_0
    //   56: monitorexit
    //   57: aload_1
    //   58: athrow
    //   59: aload_1
    //   60: monitorexit
    //   61: aload_0
    //   62: iconst_0
    //   63: invokevirtual zze : (Z)V
    //   66: aload_0
    //   67: getfield zzsc : Z
    //   70: ifne -> 97
    //   73: new java/io/IOException
    //   76: dup
    //   77: ldc_w 'AdvertisingIdClient cannot reconnect.'
    //   80: invokespecial <init> : (Ljava/lang/String;)V
    //   83: athrow
    //   84: astore_1
    //   85: new java/io/IOException
    //   88: dup
    //   89: ldc_w 'AdvertisingIdClient cannot reconnect.'
    //   92: aload_1
    //   93: invokespecial <init> : (Ljava/lang/String;Ljava/lang/Throwable;)V
    //   96: athrow
    //   97: aload_0
    //   98: getfield zzsa : Lcom/google/android/gms/common/zza;
    //   101: invokestatic zzw : (Ljava/lang/Object;)Ljava/lang/Object;
    //   104: pop
    //   105: aload_0
    //   106: getfield zzsb : Lcom/google/android/gms/internal/zzcq;
    //   109: invokestatic zzw : (Ljava/lang/Object;)Ljava/lang/Object;
    //   112: pop
    //   113: new com/google/android/gms/ads/identifier/AdvertisingIdClient$Info
    //   116: dup
    //   117: aload_0
    //   118: getfield zzsb : Lcom/google/android/gms/internal/zzcq;
    //   121: invokeinterface getId : ()Ljava/lang/String;
    //   126: aload_0
    //   127: getfield zzsb : Lcom/google/android/gms/internal/zzcq;
    //   130: iconst_1
    //   131: invokeinterface zzf : (Z)Z
    //   136: invokespecial <init> : (Ljava/lang/String;Z)V
    //   139: astore_1
    //   140: aload_0
    //   141: monitorexit
    //   142: aload_0
    //   143: invokespecial zzbw : ()V
    //   146: aload_1
    //   147: areturn
    //   148: astore_1
    //   149: ldc 'AdvertisingIdClient'
    //   151: ldc_w 'GMS remote exception '
    //   154: aload_1
    //   155: invokestatic i : (Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)I
    //   158: pop
    //   159: new java/io/IOException
    //   162: dup
    //   163: ldc_w 'Remote exception'
    //   166: invokespecial <init> : (Ljava/lang/String;)V
    //   169: athrow
    // Exception table:
    //   from	to	target	type
    //   7	21	54	finally
    //   21	38	49	finally
    //   38	49	49	finally
    //   50	52	49	finally
    //   52	54	54	finally
    //   55	57	54	finally
    //   59	61	49	finally
    //   61	66	84	java/lang/Exception
    //   61	66	54	finally
    //   66	84	54	finally
    //   85	97	54	finally
    //   97	113	54	finally
    //   113	140	148	android/os/RemoteException
    //   113	140	54	finally
    //   140	142	54	finally
    //   149	170	54	finally
  }
  
  public void start() throws IOException, IllegalStateException, GooglePlayServicesNotAvailableException, GooglePlayServicesRepairableException {
    zze(true);
  }
  
  Uri zza(Info paramInfo, boolean paramBoolean, Throwable paramThrowable) {
    Bundle bundle = new Bundle();
    if (paramBoolean) {
      str = "1";
    } else {
      str = "0";
    } 
    bundle.putString("app_context", str);
    if (paramInfo != null) {
      if (paramInfo.isLimitAdTrackingEnabled()) {
        str = "1";
      } else {
        str = "0";
      } 
      bundle.putString("limit_ad_tracking", str);
    } 
    if (paramInfo != null && paramInfo.getId() != null)
      bundle.putString("ad_id_size", Integer.toString(paramInfo.getId().length())); 
    if (paramThrowable != null)
      bundle.putString("error", paramThrowable.getClass().getName()); 
    Uri.Builder builder = Uri.parse("https://pagead2.googlesyndication.com/pagead/gen_204?id=gmob-apps").buildUpon();
    for (String str : bundle.keySet())
      builder.appendQueryParameter(str, bundle.getString(str)); 
    return builder.build();
  }
  
  protected void zze(boolean paramBoolean) throws IOException, IllegalStateException, GooglePlayServicesNotAvailableException, GooglePlayServicesRepairableException {
    // Byte code:
    //   0: ldc 'Calling this from your main thread can lead to deadlock'
    //   2: invokestatic zzdk : (Ljava/lang/String;)V
    //   5: aload_0
    //   6: monitorenter
    //   7: aload_0
    //   8: getfield zzsc : Z
    //   11: ifeq -> 18
    //   14: aload_0
    //   15: invokevirtual finish : ()V
    //   18: aload_0
    //   19: aload_0
    //   20: getfield mContext : Landroid/content/Context;
    //   23: invokestatic zzf : (Landroid/content/Context;)Lcom/google/android/gms/common/zza;
    //   26: putfield zzsa : Lcom/google/android/gms/common/zza;
    //   29: aload_0
    //   30: aload_0
    //   31: getfield mContext : Landroid/content/Context;
    //   34: aload_0
    //   35: getfield zzsa : Lcom/google/android/gms/common/zza;
    //   38: invokestatic zza : (Landroid/content/Context;Lcom/google/android/gms/common/zza;)Lcom/google/android/gms/internal/zzcq;
    //   41: putfield zzsb : Lcom/google/android/gms/internal/zzcq;
    //   44: aload_0
    //   45: iconst_1
    //   46: putfield zzsc : Z
    //   49: iload_1
    //   50: ifeq -> 57
    //   53: aload_0
    //   54: invokespecial zzbw : ()V
    //   57: aload_0
    //   58: monitorexit
    //   59: return
    //   60: astore_2
    //   61: aload_0
    //   62: monitorexit
    //   63: aload_2
    //   64: athrow
    // Exception table:
    //   from	to	target	type
    //   7	18	60	finally
    //   18	49	60	finally
    //   53	57	60	finally
    //   57	59	60	finally
    //   61	63	60	finally
  }
  
  public static final class Info {
    private final String zzsl;
    
    private final boolean zzsm;
    
    public Info(String param1String, boolean param1Boolean) {
      this.zzsl = param1String;
      this.zzsm = param1Boolean;
    }
    
    public String getId() {
      return this.zzsl;
    }
    
    public boolean isLimitAdTrackingEnabled() {
      return this.zzsm;
    }
    
    public String toString() {
      String str = this.zzsl;
      boolean bool = this.zzsm;
      return (new StringBuilder(String.valueOf(str).length() + 7)).append("{").append(str).append("}").append(bool).toString();
    }
  }
  
  static class zza extends Thread {
    private WeakReference<AdvertisingIdClient> zzsh;
    
    private long zzsi;
    
    CountDownLatch zzsj;
    
    boolean zzsk;
    
    public zza(AdvertisingIdClient param1AdvertisingIdClient, long param1Long) {
      this.zzsh = new WeakReference<AdvertisingIdClient>(param1AdvertisingIdClient);
      this.zzsi = param1Long;
      this.zzsj = new CountDownLatch(1);
      this.zzsk = false;
      start();
    }
    
    private void disconnect() {
      AdvertisingIdClient advertisingIdClient = this.zzsh.get();
      if (advertisingIdClient != null) {
        advertisingIdClient.finish();
        this.zzsk = true;
      } 
    }
    
    public void cancel() {
      this.zzsj.countDown();
    }
    
    public void run() {
      try {
        if (!this.zzsj.await(this.zzsi, TimeUnit.MILLISECONDS))
          disconnect(); 
        return;
      } catch (InterruptedException interruptedException) {
        disconnect();
        return;
      } 
    }
    
    public boolean zzbx() {
      return this.zzsk;
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Race Simulator-dex2jar.jar!\com\google\android\gms\ads\identifier\AdvertisingIdClient.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */