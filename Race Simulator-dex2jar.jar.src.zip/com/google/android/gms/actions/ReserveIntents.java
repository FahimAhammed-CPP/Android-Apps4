package com.google.android.gms.actions;

public class ReserveIntents {
  public static final String ACTION_RESERVE_TAXI_RESERVATION = "com.google.android.gms.actions.RESERVE_TAXI_RESERVATION";
}


/* Location:              C:\soft\dex2jar-2.0\Race Simulator-dex2jar.jar!\com\google\android\gms\actions\ReserveIntents.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */