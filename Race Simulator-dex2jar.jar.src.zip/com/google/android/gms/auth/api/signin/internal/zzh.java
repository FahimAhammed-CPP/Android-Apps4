package com.google.android.gms.auth.api.signin.internal;

public class zzh {
  static int zzakE = 31;
  
  private int zzakF = 1;
  
  public zzh zzae(boolean paramBoolean) {
    int i = zzakE;
    int j = this.zzakF;
    if (paramBoolean) {
      byte b1 = 1;
      this.zzakF = b1 + j * i;
      return this;
    } 
    byte b = 0;
    this.zzakF = b + j * i;
    return this;
  }
  
  public zzh zzq(Object paramObject) {
    int j = zzakE;
    int k = this.zzakF;
    if (paramObject == null) {
      byte b = 0;
      this.zzakF = b + k * j;
      return this;
    } 
    int i = paramObject.hashCode();
    this.zzakF = i + k * j;
    return this;
  }
  
  public int zzru() {
    return this.zzakF;
  }
}


/* Location:              C:\soft\dex2jar-2.0\Race Simulator-dex2jar.jar!\com\google\android\gms\auth\api\signin\internal\zzh.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */