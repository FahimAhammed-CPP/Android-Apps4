package com.google.android.gms.auth.api.signin;

import android.os.Bundle;

public interface GoogleSignInOptionsExtension {
  Bundle toBundle();
}


/* Location:              C:\soft\dex2jar-2.0\Race Simulator-dex2jar.jar!\com\google\android\gms\auth\api\signin\GoogleSignInOptionsExtension.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */