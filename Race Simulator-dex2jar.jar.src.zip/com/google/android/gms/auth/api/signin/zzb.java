package com.google.android.gms.auth.api.signin;

import android.accounts.Account;
import android.os.Parcel;
import android.os.Parcelable;
import com.google.android.gms.auth.api.signin.internal.zzg;
import com.google.android.gms.common.api.Scope;
import com.google.android.gms.common.internal.safeparcel.zzc;
import java.util.ArrayList;

public class zzb implements Parcelable.Creator<GoogleSignInOptions> {
  static void zza(GoogleSignInOptions paramGoogleSignInOptions, Parcel paramParcel, int paramInt) {
    int i = zzc.zzaZ(paramParcel);
    zzc.zzc(paramParcel, 1, paramGoogleSignInOptions.versionCode);
    zzc.zzc(paramParcel, 2, paramGoogleSignInOptions.zzrj(), false);
    zzc.zza(paramParcel, 3, (Parcelable)paramGoogleSignInOptions.getAccount(), paramInt, false);
    zzc.zza(paramParcel, 4, paramGoogleSignInOptions.isIdTokenRequested());
    zzc.zza(paramParcel, 5, paramGoogleSignInOptions.zzrk());
    zzc.zza(paramParcel, 6, paramGoogleSignInOptions.zzrl());
    zzc.zza(paramParcel, 7, paramGoogleSignInOptions.getServerClientId(), false);
    zzc.zza(paramParcel, 8, paramGoogleSignInOptions.zzrm(), false);
    zzc.zzc(paramParcel, 9, paramGoogleSignInOptions.zzrn(), false);
    zzc.zzJ(paramParcel, i);
  }
  
  public GoogleSignInOptions zzX(Parcel paramParcel) {
    int j = com.google.android.gms.common.internal.safeparcel.zzb.zzaY(paramParcel);
    ArrayList<zzg> arrayList = null;
    String str1 = null;
    String str2 = null;
    boolean bool1 = false;
    boolean bool2 = false;
    boolean bool3 = false;
    Account account = null;
    ArrayList<Scope> arrayList1 = null;
    int i = 0;
    while (paramParcel.dataPosition() < j) {
      int k = com.google.android.gms.common.internal.safeparcel.zzb.zzaX(paramParcel);
      switch (com.google.android.gms.common.internal.safeparcel.zzb.zzdc(k)) {
        case 1:
          i = com.google.android.gms.common.internal.safeparcel.zzb.zzg(paramParcel, k);
          break;
        case 2:
          arrayList1 = com.google.android.gms.common.internal.safeparcel.zzb.zzc(paramParcel, k, Scope.CREATOR);
          break;
        case 3:
          account = (Account)com.google.android.gms.common.internal.safeparcel.zzb.zza(paramParcel, k, Account.CREATOR);
          break;
        case 4:
          bool3 = com.google.android.gms.common.internal.safeparcel.zzb.zzc(paramParcel, k);
          break;
        case 5:
          bool2 = com.google.android.gms.common.internal.safeparcel.zzb.zzc(paramParcel, k);
          break;
        case 6:
          bool1 = com.google.android.gms.common.internal.safeparcel.zzb.zzc(paramParcel, k);
          break;
        case 7:
          str2 = com.google.android.gms.common.internal.safeparcel.zzb.zzq(paramParcel, k);
          break;
        case 8:
          str1 = com.google.android.gms.common.internal.safeparcel.zzb.zzq(paramParcel, k);
          break;
        case 9:
          arrayList = com.google.android.gms.common.internal.safeparcel.zzb.zzc(paramParcel, k, zzg.CREATOR);
          break;
      } 
    } 
    if (paramParcel.dataPosition() != j)
      throw new com.google.android.gms.common.internal.safeparcel.zzb.zza((new StringBuilder(37)).append("Overread allowed size end=").append(j).toString(), paramParcel); 
    return new GoogleSignInOptions(i, arrayList1, account, bool3, bool2, bool1, str2, str1, arrayList);
  }
  
  public GoogleSignInOptions[] zzbm(int paramInt) {
    return new GoogleSignInOptions[paramInt];
  }
}


/* Location:              C:\soft\dex2jar-2.0\Race Simulator-dex2jar.jar!\com\google\android\gms\auth\api\signin\zzb.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */