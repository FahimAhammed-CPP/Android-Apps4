package com.google.android.gms.auth.api.signin;

import android.accounts.Account;
import android.os.Parcel;
import android.os.Parcelable;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.text.TextUtils;
import com.google.android.gms.auth.api.signin.internal.zzg;
import com.google.android.gms.auth.api.signin.internal.zzh;
import com.google.android.gms.common.api.Api;
import com.google.android.gms.common.api.Scope;
import com.google.android.gms.common.internal.ReflectedParcelable;
import com.google.android.gms.common.internal.safeparcel.zza;
import com.google.android.gms.common.internal.zzac;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Set;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

public class GoogleSignInOptions extends zza implements Api.ApiOptions.Optional, ReflectedParcelable {
  public static final Parcelable.Creator<GoogleSignInOptions> CREATOR;
  
  public static final GoogleSignInOptions DEFAULT_GAMES_SIGN_IN;
  
  public static final GoogleSignInOptions DEFAULT_SIGN_IN;
  
  public static final Scope SCOPE_GAMES;
  
  private static Comparator<Scope> zzakg;
  
  public static final Scope zzakh = new Scope("profile");
  
  public static final Scope zzaki = new Scope("email");
  
  public static final Scope zzakj = new Scope("openid");
  
  final int versionCode;
  
  private Account zzahh;
  
  private boolean zzajv;
  
  private String zzajw;
  
  private final ArrayList<Scope> zzakk;
  
  private final boolean zzakl;
  
  private final boolean zzakm;
  
  private String zzakn;
  
  private ArrayList<zzg> zzako;
  
  private Map<Integer, zzg> zzakp;
  
  static {
    SCOPE_GAMES = new Scope("https://www.googleapis.com/auth/games");
    DEFAULT_SIGN_IN = (new Builder()).requestId().requestProfile().build();
    DEFAULT_GAMES_SIGN_IN = (new Builder()).requestScopes(SCOPE_GAMES, new Scope[0]).build();
    CREATOR = new zzb();
    zzakg = new Comparator<Scope>() {
        public int zza(Scope param1Scope1, Scope param1Scope2) {
          return param1Scope1.zzvt().compareTo(param1Scope2.zzvt());
        }
      };
  }
  
  GoogleSignInOptions(int paramInt, ArrayList<Scope> paramArrayList, Account paramAccount, boolean paramBoolean1, boolean paramBoolean2, boolean paramBoolean3, String paramString1, String paramString2, ArrayList<zzg> paramArrayList1) {
    this(paramInt, paramArrayList, paramAccount, paramBoolean1, paramBoolean2, paramBoolean3, paramString1, paramString2, zzx(paramArrayList1));
  }
  
  private GoogleSignInOptions(int paramInt, ArrayList<Scope> paramArrayList, Account paramAccount, boolean paramBoolean1, boolean paramBoolean2, boolean paramBoolean3, String paramString1, String paramString2, Map<Integer, zzg> paramMap) {
    this.versionCode = paramInt;
    this.zzakk = paramArrayList;
    this.zzahh = paramAccount;
    this.zzajv = paramBoolean1;
    this.zzakl = paramBoolean2;
    this.zzakm = paramBoolean3;
    this.zzajw = paramString1;
    this.zzakn = paramString2;
    this.zzako = new ArrayList<zzg>(paramMap.values());
    this.zzakp = paramMap;
  }
  
  @Nullable
  public static GoogleSignInOptions zzcx(@Nullable String paramString) throws JSONException {
    if (TextUtils.isEmpty(paramString))
      return null; 
    JSONObject jSONObject = new JSONObject(paramString);
    HashSet<Scope> hashSet = new HashSet();
    JSONArray jSONArray = jSONObject.getJSONArray("scopes");
    int j = jSONArray.length();
    for (int i = 0; i < j; i++)
      hashSet.add(new Scope(jSONArray.getString(i))); 
    String str = jSONObject.optString("accountName", null);
    if (!TextUtils.isEmpty(str)) {
      Account account = new Account(str, "com.google");
      return new GoogleSignInOptions(3, new ArrayList<Scope>(hashSet), account, jSONObject.getBoolean("idTokenRequested"), jSONObject.getBoolean("serverAuthRequested"), jSONObject.getBoolean("forceCodeForRefreshToken"), jSONObject.optString("serverClientId", null), jSONObject.optString("hostedDomain", null), new HashMap<Integer, zzg>());
    } 
    str = null;
    return new GoogleSignInOptions(3, new ArrayList<Scope>(hashSet), (Account)str, jSONObject.getBoolean("idTokenRequested"), jSONObject.getBoolean("serverAuthRequested"), jSONObject.getBoolean("forceCodeForRefreshToken"), jSONObject.optString("serverClientId", null), jSONObject.optString("hostedDomain", null), new HashMap<Integer, zzg>());
  }
  
  private JSONObject zzri() {
    JSONArray jSONArray;
    JSONObject jSONObject = new JSONObject();
    try {
      jSONArray = new JSONArray();
      Collections.sort(this.zzakk, zzakg);
      Iterator<Scope> iterator = this.zzakk.iterator();
      while (iterator.hasNext())
        jSONArray.put(((Scope)iterator.next()).zzvt()); 
    } catch (JSONException jSONException) {
      throw new RuntimeException(jSONException);
    } 
    jSONException.put("scopes", jSONArray);
    if (this.zzahh != null)
      jSONException.put("accountName", this.zzahh.name); 
    jSONException.put("idTokenRequested", this.zzajv);
    jSONException.put("forceCodeForRefreshToken", this.zzakm);
    jSONException.put("serverAuthRequested", this.zzakl);
    if (!TextUtils.isEmpty(this.zzajw))
      jSONException.put("serverClientId", this.zzajw); 
    if (!TextUtils.isEmpty(this.zzakn))
      jSONException.put("hostedDomain", this.zzakn); 
    return (JSONObject)jSONException;
  }
  
  private static Map<Integer, zzg> zzx(@Nullable List<zzg> paramList) {
    HashMap<Object, Object> hashMap = new HashMap<Object, Object>();
    if (paramList == null)
      return (Map)hashMap; 
    for (zzg zzg : paramList)
      hashMap.put(Integer.valueOf(zzg.getType()), zzg); 
    return (Map)hashMap;
  }
  
  public boolean equals(Object paramObject) {
    // Byte code:
    //   0: aload_1
    //   1: ifnonnull -> 6
    //   4: iconst_0
    //   5: ireturn
    //   6: aload_1
    //   7: checkcast com/google/android/gms/auth/api/signin/GoogleSignInOptions
    //   10: astore_1
    //   11: aload_0
    //   12: getfield zzako : Ljava/util/ArrayList;
    //   15: invokevirtual size : ()I
    //   18: ifgt -> 4
    //   21: aload_1
    //   22: getfield zzako : Ljava/util/ArrayList;
    //   25: invokevirtual size : ()I
    //   28: ifgt -> 4
    //   31: aload_0
    //   32: getfield zzakk : Ljava/util/ArrayList;
    //   35: invokevirtual size : ()I
    //   38: aload_1
    //   39: invokevirtual zzrj : ()Ljava/util/ArrayList;
    //   42: invokevirtual size : ()I
    //   45: if_icmpne -> 4
    //   48: aload_0
    //   49: getfield zzakk : Ljava/util/ArrayList;
    //   52: aload_1
    //   53: invokevirtual zzrj : ()Ljava/util/ArrayList;
    //   56: invokevirtual containsAll : (Ljava/util/Collection;)Z
    //   59: ifeq -> 4
    //   62: aload_0
    //   63: getfield zzahh : Landroid/accounts/Account;
    //   66: ifnonnull -> 131
    //   69: aload_1
    //   70: invokevirtual getAccount : ()Landroid/accounts/Account;
    //   73: ifnonnull -> 4
    //   76: aload_0
    //   77: getfield zzajw : Ljava/lang/String;
    //   80: invokestatic isEmpty : (Ljava/lang/CharSequence;)Z
    //   83: ifeq -> 148
    //   86: aload_1
    //   87: invokevirtual getServerClientId : ()Ljava/lang/String;
    //   90: invokestatic isEmpty : (Ljava/lang/CharSequence;)Z
    //   93: ifeq -> 4
    //   96: aload_0
    //   97: getfield zzakm : Z
    //   100: aload_1
    //   101: invokevirtual zzrl : ()Z
    //   104: if_icmpne -> 4
    //   107: aload_0
    //   108: getfield zzajv : Z
    //   111: aload_1
    //   112: invokevirtual isIdTokenRequested : ()Z
    //   115: if_icmpne -> 4
    //   118: aload_0
    //   119: getfield zzakl : Z
    //   122: aload_1
    //   123: invokevirtual zzrk : ()Z
    //   126: if_icmpne -> 4
    //   129: iconst_1
    //   130: ireturn
    //   131: aload_0
    //   132: getfield zzahh : Landroid/accounts/Account;
    //   135: aload_1
    //   136: invokevirtual getAccount : ()Landroid/accounts/Account;
    //   139: invokevirtual equals : (Ljava/lang/Object;)Z
    //   142: ifeq -> 4
    //   145: goto -> 76
    //   148: aload_0
    //   149: getfield zzajw : Ljava/lang/String;
    //   152: aload_1
    //   153: invokevirtual getServerClientId : ()Ljava/lang/String;
    //   156: invokevirtual equals : (Ljava/lang/Object;)Z
    //   159: istore_2
    //   160: iload_2
    //   161: ifeq -> 4
    //   164: goto -> 96
    //   167: astore_1
    //   168: iconst_0
    //   169: ireturn
    // Exception table:
    //   from	to	target	type
    //   6	76	167	java/lang/ClassCastException
    //   76	96	167	java/lang/ClassCastException
    //   96	129	167	java/lang/ClassCastException
    //   131	145	167	java/lang/ClassCastException
    //   148	160	167	java/lang/ClassCastException
  }
  
  public Account getAccount() {
    return this.zzahh;
  }
  
  public Scope[] getScopeArray() {
    return this.zzakk.<Scope>toArray(new Scope[this.zzakk.size()]);
  }
  
  public String getServerClientId() {
    return this.zzajw;
  }
  
  public int hashCode() {
    ArrayList<String> arrayList = new ArrayList();
    Iterator<Scope> iterator = this.zzakk.iterator();
    while (iterator.hasNext())
      arrayList.add(((Scope)iterator.next()).zzvt()); 
    Collections.sort(arrayList);
    return (new zzh()).zzq(arrayList).zzq(this.zzahh).zzq(this.zzajw).zzae(this.zzakm).zzae(this.zzajv).zzae(this.zzakl).zzru();
  }
  
  public boolean isIdTokenRequested() {
    return this.zzajv;
  }
  
  public void writeToParcel(Parcel paramParcel, int paramInt) {
    zzb.zza(this, paramParcel, paramInt);
  }
  
  public String zzrg() {
    return zzri().toString();
  }
  
  public ArrayList<Scope> zzrj() {
    return new ArrayList<Scope>(this.zzakk);
  }
  
  public boolean zzrk() {
    return this.zzakl;
  }
  
  public boolean zzrl() {
    return this.zzakm;
  }
  
  public String zzrm() {
    return this.zzakn;
  }
  
  public ArrayList<zzg> zzrn() {
    return this.zzako;
  }
  
  public static final class Builder {
    private Account zzahh;
    
    private boolean zzajv;
    
    private String zzajw;
    
    private boolean zzakl;
    
    private boolean zzakm;
    
    private String zzakn;
    
    private Set<Scope> zzakq = new HashSet<Scope>();
    
    private Map<Integer, zzg> zzakr = new HashMap<Integer, zzg>();
    
    public Builder() {}
    
    public Builder(@NonNull GoogleSignInOptions param1GoogleSignInOptions) {
      zzac.zzw(param1GoogleSignInOptions);
      this.zzakq = new HashSet<Scope>(GoogleSignInOptions.zzb(param1GoogleSignInOptions));
      this.zzakl = GoogleSignInOptions.zzc(param1GoogleSignInOptions);
      this.zzakm = GoogleSignInOptions.zzd(param1GoogleSignInOptions);
      this.zzajv = GoogleSignInOptions.zze(param1GoogleSignInOptions);
      this.zzajw = GoogleSignInOptions.zzf(param1GoogleSignInOptions);
      this.zzahh = GoogleSignInOptions.zzg(param1GoogleSignInOptions);
      this.zzakn = GoogleSignInOptions.zzh(param1GoogleSignInOptions);
      this.zzakr = GoogleSignInOptions.zzy(GoogleSignInOptions.zzi(param1GoogleSignInOptions));
    }
    
    private String zzcy(String param1String) {
      zzac.zzdr(param1String);
      if (this.zzajw == null || this.zzajw.equals(param1String)) {
        boolean bool1 = true;
        zzac.zzb(bool1, "two different server client ids provided");
        return param1String;
      } 
      boolean bool = false;
      zzac.zzb(bool, "two different server client ids provided");
      return param1String;
    }
    
    public Builder addExtension(GoogleSignInOptionsExtension param1GoogleSignInOptionsExtension) {
      if (this.zzakr.containsKey(Integer.valueOf(1)))
        throw new IllegalStateException("Only one extension per type may be added"); 
      this.zzakr.put(Integer.valueOf(1), new zzg(param1GoogleSignInOptionsExtension));
      return this;
    }
    
    public GoogleSignInOptions build() {
      if (this.zzajv && (this.zzahh == null || !this.zzakq.isEmpty()))
        requestId(); 
      return new GoogleSignInOptions(3, new ArrayList<Scope>(this.zzakq), this.zzahh, this.zzajv, this.zzakl, this.zzakm, this.zzajw, this.zzakn, this.zzakr);
    }
    
    public Builder requestEmail() {
      this.zzakq.add(GoogleSignInOptions.zzaki);
      return this;
    }
    
    public Builder requestId() {
      this.zzakq.add(GoogleSignInOptions.zzakj);
      return this;
    }
    
    public Builder requestIdToken(String param1String) {
      this.zzajv = true;
      this.zzajw = zzcy(param1String);
      return this;
    }
    
    public Builder requestProfile() {
      this.zzakq.add(GoogleSignInOptions.zzakh);
      return this;
    }
    
    public Builder requestScopes(Scope param1Scope, Scope... param1VarArgs) {
      this.zzakq.add(param1Scope);
      this.zzakq.addAll(Arrays.asList(param1VarArgs));
      return this;
    }
    
    public Builder requestServerAuthCode(String param1String) {
      return requestServerAuthCode(param1String, false);
    }
    
    public Builder requestServerAuthCode(String param1String, boolean param1Boolean) {
      this.zzakl = true;
      this.zzajw = zzcy(param1String);
      this.zzakm = param1Boolean;
      return this;
    }
    
    public Builder setAccountName(String param1String) {
      this.zzahh = new Account(zzac.zzdr(param1String), "com.google");
      return this;
    }
    
    public Builder setHostedDomain(String param1String) {
      this.zzakn = zzac.zzdr(param1String);
      return this;
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Race Simulator-dex2jar.jar!\com\google\android\gms\auth\api\signin\GoogleSignInOptions.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */