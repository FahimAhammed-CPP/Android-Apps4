package com.google.android.gms.auth.api.signin.internal;

import android.content.Context;
import android.content.SharedPreferences;
import android.text.TextUtils;
import com.google.android.gms.auth.api.signin.GoogleSignInAccount;
import com.google.android.gms.auth.api.signin.GoogleSignInOptions;
import com.google.android.gms.common.internal.zzac;
import java.util.concurrent.locks.Lock;
import java.util.concurrent.locks.ReentrantLock;
import org.json.JSONException;

public class zzn {
  private static final Lock zzakO = new ReentrantLock();
  
  private static zzn zzakP;
  
  private final Lock zzakQ = new ReentrantLock();
  
  private final SharedPreferences zzakR;
  
  zzn(Context paramContext) {
    this.zzakR = paramContext.getSharedPreferences("com.google.android.gms.signin", 0);
  }
  
  public static zzn zzas(Context paramContext) {
    zzac.zzw(paramContext);
    zzakO.lock();
    try {
      if (zzakP == null)
        zzakP = new zzn(paramContext.getApplicationContext()); 
      return zzakP;
    } finally {
      zzakO.unlock();
    } 
  }
  
  private String zzy(String paramString1, String paramString2) {
    String str = String.valueOf(":");
    return (new StringBuilder(String.valueOf(paramString1).length() + String.valueOf(str).length() + String.valueOf(paramString2).length())).append(paramString1).append(str).append(paramString2).toString();
  }
  
  void zza(GoogleSignInAccount paramGoogleSignInAccount, GoogleSignInOptions paramGoogleSignInOptions) {
    zzac.zzw(paramGoogleSignInAccount);
    zzac.zzw(paramGoogleSignInOptions);
    String str = paramGoogleSignInAccount.zzrf();
    zzx(zzy("googleSignInAccount", str), paramGoogleSignInAccount.zzrh());
    zzx(zzy("googleSignInOptions", str), paramGoogleSignInOptions.zzrg());
  }
  
  public void zzb(GoogleSignInAccount paramGoogleSignInAccount, GoogleSignInOptions paramGoogleSignInOptions) {
    zzac.zzw(paramGoogleSignInAccount);
    zzac.zzw(paramGoogleSignInOptions);
    zzx("defaultGoogleSignInAccount", paramGoogleSignInAccount.zzrf());
    zza(paramGoogleSignInAccount, paramGoogleSignInOptions);
  }
  
  GoogleSignInOptions zzcA(String paramString) {
    if (!TextUtils.isEmpty(paramString)) {
      paramString = zzcB(zzy("googleSignInOptions", paramString));
      if (paramString != null)
        try {
          return GoogleSignInOptions.zzcx(paramString);
        } catch (JSONException jSONException) {
          return null;
        }  
    } 
    return null;
  }
  
  protected String zzcB(String paramString) {
    this.zzakQ.lock();
    try {
      paramString = this.zzakR.getString(paramString, null);
      return paramString;
    } finally {
      this.zzakQ.unlock();
    } 
  }
  
  void zzcC(String paramString) {
    if (TextUtils.isEmpty(paramString))
      return; 
    zzcD(zzy("googleSignInAccount", paramString));
    zzcD(zzy("googleSignInOptions", paramString));
  }
  
  protected void zzcD(String paramString) {
    this.zzakQ.lock();
    try {
      this.zzakR.edit().remove(paramString).apply();
      return;
    } finally {
      this.zzakQ.unlock();
    } 
  }
  
  GoogleSignInAccount zzcz(String paramString) {
    if (!TextUtils.isEmpty(paramString)) {
      paramString = zzcB(zzy("googleSignInAccount", paramString));
      if (paramString != null)
        try {
          return GoogleSignInAccount.zzcv(paramString);
        } catch (JSONException jSONException) {
          return null;
        }  
    } 
    return null;
  }
  
  public GoogleSignInAccount zzrB() {
    return zzcz(zzcB("defaultGoogleSignInAccount"));
  }
  
  public GoogleSignInOptions zzrC() {
    return zzcA(zzcB("defaultGoogleSignInAccount"));
  }
  
  public void zzrD() {
    String str = zzcB("defaultGoogleSignInAccount");
    zzcD("defaultGoogleSignInAccount");
    zzcC(str);
  }
  
  protected void zzx(String paramString1, String paramString2) {
    this.zzakQ.lock();
    try {
      this.zzakR.edit().putString(paramString1, paramString2).apply();
      return;
    } finally {
      this.zzakQ.unlock();
    } 
  }
}


/* Location:              C:\soft\dex2jar-2.0\Race Simulator-dex2jar.jar!\com\google\android\gms\auth\api\signin\internal\zzn.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */