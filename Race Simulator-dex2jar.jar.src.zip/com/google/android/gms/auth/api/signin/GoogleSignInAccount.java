package com.google.android.gms.auth.api.signin;

import android.accounts.Account;
import android.net.Uri;
import android.os.Parcel;
import android.os.Parcelable;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.text.TextUtils;
import com.google.android.gms.common.api.Scope;
import com.google.android.gms.common.internal.ReflectedParcelable;
import com.google.android.gms.common.internal.safeparcel.zza;
import com.google.android.gms.common.internal.zzac;
import com.google.android.gms.common.util.zze;
import com.google.android.gms.common.util.zzi;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Set;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

public class GoogleSignInAccount extends zza implements ReflectedParcelable {
  public static final Parcelable.Creator<GoogleSignInAccount> CREATOR = new zza();
  
  public static zze zzajZ = zzi.zzzc();
  
  private static Comparator<Scope> zzakg = new Comparator<Scope>() {
      public int zza(Scope param1Scope1, Scope param1Scope2) {
        return param1Scope1.zzvt().compareTo(param1Scope2.zzvt());
      }
    };
  
  final int versionCode;
  
  private String zzGV;
  
  List<Scope> zzaiN;
  
  private String zzajB;
  
  private String zzajl;
  
  private String zzajm;
  
  private String zzaka;
  
  private String zzakb;
  
  private Uri zzakc;
  
  private String zzakd;
  
  private long zzake;
  
  private String zzakf;
  
  GoogleSignInAccount(int paramInt, String paramString1, String paramString2, String paramString3, String paramString4, Uri paramUri, String paramString5, long paramLong, String paramString6, List<Scope> paramList, String paramString7, String paramString8) {
    this.versionCode = paramInt;
    this.zzGV = paramString1;
    this.zzajB = paramString2;
    this.zzaka = paramString3;
    this.zzakb = paramString4;
    this.zzakc = paramUri;
    this.zzakd = paramString5;
    this.zzake = paramLong;
    this.zzakf = paramString6;
    this.zzaiN = paramList;
    this.zzajl = paramString7;
    this.zzajm = paramString8;
  }
  
  public static GoogleSignInAccount zza(@Nullable String paramString1, @Nullable String paramString2, @Nullable String paramString3, @Nullable String paramString4, @Nullable String paramString5, @Nullable String paramString6, @Nullable Uri paramUri, @Nullable Long paramLong, @NonNull String paramString7, @NonNull Set<Scope> paramSet) {
    Long long_ = paramLong;
    if (paramLong == null)
      long_ = Long.valueOf(zzajZ.currentTimeMillis() / 1000L); 
    return new GoogleSignInAccount(3, paramString1, paramString2, paramString3, paramString4, paramUri, null, long_.longValue(), zzac.zzdr(paramString7), new ArrayList<Scope>((Collection<? extends Scope>)zzac.zzw(paramSet)), paramString5, paramString6);
  }
  
  @Nullable
  public static GoogleSignInAccount zzcv(@Nullable String paramString) throws JSONException {
    if (TextUtils.isEmpty(paramString))
      return null; 
    JSONObject jSONObject = new JSONObject(paramString);
    paramString = jSONObject.optString("photoUrl", null);
    if (!TextUtils.isEmpty(paramString)) {
      Uri uri = Uri.parse(paramString);
    } else {
      paramString = null;
    } 
    long l = Long.parseLong(jSONObject.getString("expirationTime"));
    HashSet<Scope> hashSet = new HashSet();
    JSONArray jSONArray = jSONObject.getJSONArray("grantedScopes");
    int j = jSONArray.length();
    for (int i = 0; i < j; i++)
      hashSet.add(new Scope(jSONArray.getString(i))); 
    return zza(jSONObject.optString("id"), jSONObject.optString("tokenId", null), jSONObject.optString("email", null), jSONObject.optString("displayName", null), jSONObject.optString("givenName", null), jSONObject.optString("familyName", null), (Uri)paramString, Long.valueOf(l), jSONObject.getString("obfuscatedIdentifier"), hashSet).zzcw(jSONObject.optString("serverAuthCode", null));
  }
  
  private JSONObject zzri() {
    JSONArray jSONArray;
    JSONObject jSONObject = new JSONObject();
    try {
      if (getId() != null)
        jSONObject.put("id", getId()); 
      if (getIdToken() != null)
        jSONObject.put("tokenId", getIdToken()); 
      if (getEmail() != null)
        jSONObject.put("email", getEmail()); 
      if (getDisplayName() != null)
        jSONObject.put("displayName", getDisplayName()); 
      if (getGivenName() != null)
        jSONObject.put("givenName", getGivenName()); 
      if (getFamilyName() != null)
        jSONObject.put("familyName", getFamilyName()); 
      if (getPhotoUrl() != null)
        jSONObject.put("photoUrl", getPhotoUrl().toString()); 
      if (getServerAuthCode() != null)
        jSONObject.put("serverAuthCode", getServerAuthCode()); 
      jSONObject.put("expirationTime", this.zzake);
      jSONObject.put("obfuscatedIdentifier", zzrf());
      jSONArray = new JSONArray();
      Collections.sort(this.zzaiN, zzakg);
      Iterator<Scope> iterator = this.zzaiN.iterator();
      while (iterator.hasNext())
        jSONArray.put(((Scope)iterator.next()).zzvt()); 
    } catch (JSONException jSONException) {
      throw new RuntimeException(jSONException);
    } 
    jSONException.put("grantedScopes", jSONArray);
    return (JSONObject)jSONException;
  }
  
  public boolean equals(Object paramObject) {
    return !(paramObject instanceof GoogleSignInAccount) ? false : ((GoogleSignInAccount)paramObject).zzrg().equals(zzrg());
  }
  
  @Nullable
  public Account getAccount() {
    return (this.zzaka == null) ? null : new Account(this.zzaka, "com.google");
  }
  
  @Nullable
  public String getDisplayName() {
    return this.zzakb;
  }
  
  @Nullable
  public String getEmail() {
    return this.zzaka;
  }
  
  @Nullable
  public String getFamilyName() {
    return this.zzajm;
  }
  
  @Nullable
  public String getGivenName() {
    return this.zzajl;
  }
  
  @NonNull
  public Set<Scope> getGrantedScopes() {
    return new HashSet<Scope>(this.zzaiN);
  }
  
  @Nullable
  public String getId() {
    return this.zzGV;
  }
  
  @Nullable
  public String getIdToken() {
    return this.zzajB;
  }
  
  @Nullable
  public Uri getPhotoUrl() {
    return this.zzakc;
  }
  
  @Nullable
  public String getServerAuthCode() {
    return this.zzakd;
  }
  
  public int hashCode() {
    return zzrg().hashCode();
  }
  
  public void writeToParcel(Parcel paramParcel, int paramInt) {
    zza.zza(this, paramParcel, paramInt);
  }
  
  public boolean zza() {
    return (zzajZ.currentTimeMillis() / 1000L >= this.zzake - 300L);
  }
  
  public GoogleSignInAccount zzcw(String paramString) {
    this.zzakd = paramString;
    return this;
  }
  
  public long zzre() {
    return this.zzake;
  }
  
  @NonNull
  public String zzrf() {
    return this.zzakf;
  }
  
  public String zzrg() {
    return zzri().toString();
  }
  
  public String zzrh() {
    JSONObject jSONObject = zzri();
    jSONObject.remove("serverAuthCode");
    return jSONObject.toString();
  }
}


/* Location:              C:\soft\dex2jar-2.0\Race Simulator-dex2jar.jar!\com\google\android\gms\auth\api\signin\GoogleSignInAccount.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */