package android.support.v4.view;

import android.view.View;

class ViewCompatICSMr1 {
  public static boolean hasOnClickListeners(View paramView) {
    return paramView.hasOnClickListeners();
  }
}


/* Location:              C:\soft\dex2jar-2.0\Race Simulator-dex2jar.jar!\android\support\v4\view\ViewCompatICSMr1.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */