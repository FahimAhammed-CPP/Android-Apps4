package android.support.v4.app;

class NotificationCompatApi23 {
  public static final String CATEGORY_REMINDER = "reminder";
}


/* Location:              C:\soft\dex2jar-2.0\Race Simulator-dex2jar.jar!\android\support\v4\app\NotificationCompatApi23.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */