package android.support.v4.media.session;

import android.os.Build;
import android.os.Bundle;
import android.os.Parcel;
import android.os.Parcelable;
import android.os.SystemClock;
import android.support.annotation.Nullable;
import android.text.TextUtils;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

public final class PlaybackStateCompat implements Parcelable {
  public static final long ACTION_FAST_FORWARD = 64L;
  
  public static final long ACTION_PAUSE = 2L;
  
  public static final long ACTION_PLAY = 4L;
  
  public static final long ACTION_PLAY_FROM_MEDIA_ID = 1024L;
  
  public static final long ACTION_PLAY_FROM_SEARCH = 2048L;
  
  public static final long ACTION_PLAY_FROM_URI = 8192L;
  
  public static final long ACTION_PLAY_PAUSE = 512L;
  
  public static final long ACTION_PREPARE = 16384L;
  
  public static final long ACTION_PREPARE_FROM_MEDIA_ID = 32768L;
  
  public static final long ACTION_PREPARE_FROM_SEARCH = 65536L;
  
  public static final long ACTION_PREPARE_FROM_URI = 131072L;
  
  public static final long ACTION_REWIND = 8L;
  
  public static final long ACTION_SEEK_TO = 256L;
  
  public static final long ACTION_SET_RATING = 128L;
  
  public static final long ACTION_SKIP_TO_NEXT = 32L;
  
  public static final long ACTION_SKIP_TO_PREVIOUS = 16L;
  
  public static final long ACTION_SKIP_TO_QUEUE_ITEM = 4096L;
  
  public static final long ACTION_STOP = 1L;
  
  public static final Parcelable.Creator<PlaybackStateCompat> CREATOR = new Parcelable.Creator<PlaybackStateCompat>() {
      public PlaybackStateCompat createFromParcel(Parcel param1Parcel) {
        return new PlaybackStateCompat(param1Parcel);
      }
      
      public PlaybackStateCompat[] newArray(int param1Int) {
        return new PlaybackStateCompat[param1Int];
      }
    };
  
  public static final long PLAYBACK_POSITION_UNKNOWN = -1L;
  
  public static final int STATE_BUFFERING = 6;
  
  public static final int STATE_CONNECTING = 8;
  
  public static final int STATE_ERROR = 7;
  
  public static final int STATE_FAST_FORWARDING = 4;
  
  public static final int STATE_NONE = 0;
  
  public static final int STATE_PAUSED = 2;
  
  public static final int STATE_PLAYING = 3;
  
  public static final int STATE_REWINDING = 5;
  
  public static final int STATE_SKIPPING_TO_NEXT = 10;
  
  public static final int STATE_SKIPPING_TO_PREVIOUS = 9;
  
  public static final int STATE_SKIPPING_TO_QUEUE_ITEM = 11;
  
  public static final int STATE_STOPPED = 1;
  
  private final long mActions;
  
  private final long mActiveItemId;
  
  private final long mBufferedPosition;
  
  private List<CustomAction> mCustomActions;
  
  private final CharSequence mErrorMessage;
  
  private final Bundle mExtras;
  
  private final long mPosition;
  
  private final float mSpeed;
  
  private final int mState;
  
  private Object mStateObj;
  
  private final long mUpdateTime;
  
  private PlaybackStateCompat(int paramInt, long paramLong1, long paramLong2, float paramFloat, long paramLong3, CharSequence paramCharSequence, long paramLong4, List<CustomAction> paramList, long paramLong5, Bundle paramBundle) {
    this.mState = paramInt;
    this.mPosition = paramLong1;
    this.mBufferedPosition = paramLong2;
    this.mSpeed = paramFloat;
    this.mActions = paramLong3;
    this.mErrorMessage = paramCharSequence;
    this.mUpdateTime = paramLong4;
    this.mCustomActions = new ArrayList<CustomAction>(paramList);
    this.mActiveItemId = paramLong5;
    this.mExtras = paramBundle;
  }
  
  private PlaybackStateCompat(Parcel paramParcel) {
    this.mState = paramParcel.readInt();
    this.mPosition = paramParcel.readLong();
    this.mSpeed = paramParcel.readFloat();
    this.mUpdateTime = paramParcel.readLong();
    this.mBufferedPosition = paramParcel.readLong();
    this.mActions = paramParcel.readLong();
    this.mErrorMessage = (CharSequence)TextUtils.CHAR_SEQUENCE_CREATOR.createFromParcel(paramParcel);
    this.mCustomActions = paramParcel.createTypedArrayList(CustomAction.CREATOR);
    this.mActiveItemId = paramParcel.readLong();
    this.mExtras = paramParcel.readBundle();
  }
  
  public static PlaybackStateCompat fromPlaybackState(Object paramObject) {
    if (paramObject == null || Build.VERSION.SDK_INT < 21)
      return null; 
    List<Object> list = PlaybackStateCompatApi21.getCustomActions(paramObject);
    ArrayList<CustomAction> arrayList = null;
    if (list != null) {
      ArrayList<CustomAction> arrayList1 = new ArrayList(list.size());
      Iterator iterator = list.iterator();
      while (true) {
        arrayList = arrayList1;
        if (iterator.hasNext()) {
          arrayList1.add(CustomAction.fromCustomAction(iterator.next()));
          continue;
        } 
        break;
      } 
    } 
    if (Build.VERSION.SDK_INT >= 22) {
      Bundle bundle1 = PlaybackStateCompatApi22.getExtras(paramObject);
      playbackStateCompat = new PlaybackStateCompat(PlaybackStateCompatApi21.getState(paramObject), PlaybackStateCompatApi21.getPosition(paramObject), PlaybackStateCompatApi21.getBufferedPosition(paramObject), PlaybackStateCompatApi21.getPlaybackSpeed(paramObject), PlaybackStateCompatApi21.getActions(paramObject), PlaybackStateCompatApi21.getErrorMessage(paramObject), PlaybackStateCompatApi21.getLastPositionUpdateTime(paramObject), arrayList, PlaybackStateCompatApi21.getActiveQueueItemId(paramObject), bundle1);
      playbackStateCompat.mStateObj = paramObject;
      return playbackStateCompat;
    } 
    Bundle bundle = null;
    PlaybackStateCompat playbackStateCompat = new PlaybackStateCompat(PlaybackStateCompatApi21.getState(paramObject), PlaybackStateCompatApi21.getPosition(paramObject), PlaybackStateCompatApi21.getBufferedPosition(paramObject), PlaybackStateCompatApi21.getPlaybackSpeed(paramObject), PlaybackStateCompatApi21.getActions(paramObject), PlaybackStateCompatApi21.getErrorMessage(paramObject), PlaybackStateCompatApi21.getLastPositionUpdateTime(paramObject), (List<CustomAction>)playbackStateCompat, PlaybackStateCompatApi21.getActiveQueueItemId(paramObject), bundle);
    playbackStateCompat.mStateObj = paramObject;
    return playbackStateCompat;
  }
  
  public int describeContents() {
    return 0;
  }
  
  public long getActions() {
    return this.mActions;
  }
  
  public long getActiveQueueItemId() {
    return this.mActiveItemId;
  }
  
  public long getBufferedPosition() {
    return this.mBufferedPosition;
  }
  
  public List<CustomAction> getCustomActions() {
    return this.mCustomActions;
  }
  
  public CharSequence getErrorMessage() {
    return this.mErrorMessage;
  }
  
  @Nullable
  public Bundle getExtras() {
    return this.mExtras;
  }
  
  public long getLastPositionUpdateTime() {
    return this.mUpdateTime;
  }
  
  public float getPlaybackSpeed() {
    return this.mSpeed;
  }
  
  public Object getPlaybackState() {
    if (this.mStateObj != null || Build.VERSION.SDK_INT < 21)
      return this.mStateObj; 
    ArrayList<Object> arrayList = null;
    if (this.mCustomActions != null) {
      ArrayList<Object> arrayList1 = new ArrayList(this.mCustomActions.size());
      Iterator<CustomAction> iterator = this.mCustomActions.iterator();
      while (true) {
        arrayList = arrayList1;
        if (iterator.hasNext()) {
          arrayList1.add(((CustomAction)iterator.next()).getCustomAction());
          continue;
        } 
        break;
      } 
    } 
    if (Build.VERSION.SDK_INT >= 22) {
      this.mStateObj = PlaybackStateCompatApi22.newInstance(this.mState, this.mPosition, this.mBufferedPosition, this.mSpeed, this.mActions, this.mErrorMessage, this.mUpdateTime, arrayList, this.mActiveItemId, this.mExtras);
      return this.mStateObj;
    } 
    this.mStateObj = PlaybackStateCompatApi21.newInstance(this.mState, this.mPosition, this.mBufferedPosition, this.mSpeed, this.mActions, this.mErrorMessage, this.mUpdateTime, arrayList, this.mActiveItemId);
    return this.mStateObj;
  }
  
  public long getPosition() {
    return this.mPosition;
  }
  
  public int getState() {
    return this.mState;
  }
  
  public String toString() {
    StringBuilder stringBuilder = new StringBuilder("PlaybackState {");
    stringBuilder.append("state=").append(this.mState);
    stringBuilder.append(", position=").append(this.mPosition);
    stringBuilder.append(", buffered position=").append(this.mBufferedPosition);
    stringBuilder.append(", speed=").append(this.mSpeed);
    stringBuilder.append(", updated=").append(this.mUpdateTime);
    stringBuilder.append(", actions=").append(this.mActions);
    stringBuilder.append(", error=").append(this.mErrorMessage);
    stringBuilder.append(", custom actions=").append(this.mCustomActions);
    stringBuilder.append(", active item id=").append(this.mActiveItemId);
    stringBuilder.append("}");
    return stringBuilder.toString();
  }
  
  public void writeToParcel(Parcel paramParcel, int paramInt) {
    paramParcel.writeInt(this.mState);
    paramParcel.writeLong(this.mPosition);
    paramParcel.writeFloat(this.mSpeed);
    paramParcel.writeLong(this.mUpdateTime);
    paramParcel.writeLong(this.mBufferedPosition);
    paramParcel.writeLong(this.mActions);
    TextUtils.writeToParcel(this.mErrorMessage, paramParcel, paramInt);
    paramParcel.writeTypedList(this.mCustomActions);
    paramParcel.writeLong(this.mActiveItemId);
    paramParcel.writeBundle(this.mExtras);
  }
  
  @Retention(RetentionPolicy.SOURCE)
  public static @interface Actions {}
  
  public static final class Builder {
    private long mActions;
    
    private long mActiveItemId = -1L;
    
    private long mBufferedPosition;
    
    private final List<PlaybackStateCompat.CustomAction> mCustomActions = new ArrayList<PlaybackStateCompat.CustomAction>();
    
    private CharSequence mErrorMessage;
    
    private Bundle mExtras;
    
    private long mPosition;
    
    private float mRate;
    
    private int mState;
    
    private long mUpdateTime;
    
    public Builder() {}
    
    public Builder(PlaybackStateCompat param1PlaybackStateCompat) {
      this.mState = param1PlaybackStateCompat.mState;
      this.mPosition = param1PlaybackStateCompat.mPosition;
      this.mRate = param1PlaybackStateCompat.mSpeed;
      this.mUpdateTime = param1PlaybackStateCompat.mUpdateTime;
      this.mBufferedPosition = param1PlaybackStateCompat.mBufferedPosition;
      this.mActions = param1PlaybackStateCompat.mActions;
      this.mErrorMessage = param1PlaybackStateCompat.mErrorMessage;
      if (param1PlaybackStateCompat.mCustomActions != null)
        this.mCustomActions.addAll(param1PlaybackStateCompat.mCustomActions); 
      this.mActiveItemId = param1PlaybackStateCompat.mActiveItemId;
      this.mExtras = param1PlaybackStateCompat.mExtras;
    }
    
    public Builder addCustomAction(PlaybackStateCompat.CustomAction param1CustomAction) {
      if (param1CustomAction == null)
        throw new IllegalArgumentException("You may not add a null CustomAction to PlaybackStateCompat."); 
      this.mCustomActions.add(param1CustomAction);
      return this;
    }
    
    public Builder addCustomAction(String param1String1, String param1String2, int param1Int) {
      return addCustomAction(new PlaybackStateCompat.CustomAction(param1String1, param1String2, param1Int, null));
    }
    
    public PlaybackStateCompat build() {
      return new PlaybackStateCompat(this.mState, this.mPosition, this.mBufferedPosition, this.mRate, this.mActions, this.mErrorMessage, this.mUpdateTime, this.mCustomActions, this.mActiveItemId, this.mExtras);
    }
    
    public Builder setActions(long param1Long) {
      this.mActions = param1Long;
      return this;
    }
    
    public Builder setActiveQueueItemId(long param1Long) {
      this.mActiveItemId = param1Long;
      return this;
    }
    
    public Builder setBufferedPosition(long param1Long) {
      this.mBufferedPosition = param1Long;
      return this;
    }
    
    public Builder setErrorMessage(CharSequence param1CharSequence) {
      this.mErrorMessage = param1CharSequence;
      return this;
    }
    
    public Builder setExtras(Bundle param1Bundle) {
      this.mExtras = param1Bundle;
      return this;
    }
    
    public Builder setState(int param1Int, long param1Long, float param1Float) {
      return setState(param1Int, param1Long, param1Float, SystemClock.elapsedRealtime());
    }
    
    public Builder setState(int param1Int, long param1Long1, float param1Float, long param1Long2) {
      this.mState = param1Int;
      this.mPosition = param1Long1;
      this.mUpdateTime = param1Long2;
      this.mRate = param1Float;
      return this;
    }
  }
  
  public static final class CustomAction implements Parcelable {
    public static final Parcelable.Creator<CustomAction> CREATOR = new Parcelable.Creator<CustomAction>() {
        public PlaybackStateCompat.CustomAction createFromParcel(Parcel param2Parcel) {
          return new PlaybackStateCompat.CustomAction(param2Parcel);
        }
        
        public PlaybackStateCompat.CustomAction[] newArray(int param2Int) {
          return new PlaybackStateCompat.CustomAction[param2Int];
        }
      };
    
    private final String mAction;
    
    private Object mCustomActionObj;
    
    private final Bundle mExtras;
    
    private final int mIcon;
    
    private final CharSequence mName;
    
    private CustomAction(Parcel param1Parcel) {
      this.mAction = param1Parcel.readString();
      this.mName = (CharSequence)TextUtils.CHAR_SEQUENCE_CREATOR.createFromParcel(param1Parcel);
      this.mIcon = param1Parcel.readInt();
      this.mExtras = param1Parcel.readBundle();
    }
    
    private CustomAction(String param1String, CharSequence param1CharSequence, int param1Int, Bundle param1Bundle) {
      this.mAction = param1String;
      this.mName = param1CharSequence;
      this.mIcon = param1Int;
      this.mExtras = param1Bundle;
    }
    
    public static CustomAction fromCustomAction(Object param1Object) {
      if (param1Object == null || Build.VERSION.SDK_INT < 21)
        return null; 
      CustomAction customAction = new CustomAction(PlaybackStateCompatApi21.CustomAction.getAction(param1Object), PlaybackStateCompatApi21.CustomAction.getName(param1Object), PlaybackStateCompatApi21.CustomAction.getIcon(param1Object), PlaybackStateCompatApi21.CustomAction.getExtras(param1Object));
      customAction.mCustomActionObj = param1Object;
      return customAction;
    }
    
    public int describeContents() {
      return 0;
    }
    
    public String getAction() {
      return this.mAction;
    }
    
    public Object getCustomAction() {
      if (this.mCustomActionObj != null || Build.VERSION.SDK_INT < 21)
        return this.mCustomActionObj; 
      this.mCustomActionObj = PlaybackStateCompatApi21.CustomAction.newInstance(this.mAction, this.mName, this.mIcon, this.mExtras);
      return this.mCustomActionObj;
    }
    
    public Bundle getExtras() {
      return this.mExtras;
    }
    
    public int getIcon() {
      return this.mIcon;
    }
    
    public CharSequence getName() {
      return this.mName;
    }
    
    public String toString() {
      return "Action:mName='" + this.mName + ", mIcon=" + this.mIcon + ", mExtras=" + this.mExtras;
    }
    
    public void writeToParcel(Parcel param1Parcel, int param1Int) {
      param1Parcel.writeString(this.mAction);
      TextUtils.writeToParcel(this.mName, param1Parcel, param1Int);
      param1Parcel.writeInt(this.mIcon);
      param1Parcel.writeBundle(this.mExtras);
    }
    
    public static final class Builder {
      private final String mAction;
      
      private Bundle mExtras;
      
      private final int mIcon;
      
      private final CharSequence mName;
      
      public Builder(String param2String, CharSequence param2CharSequence, int param2Int) {
        if (TextUtils.isEmpty(param2String))
          throw new IllegalArgumentException("You must specify an action to build a CustomAction."); 
        if (TextUtils.isEmpty(param2CharSequence))
          throw new IllegalArgumentException("You must specify a name to build a CustomAction."); 
        if (param2Int == 0)
          throw new IllegalArgumentException("You must specify an icon resource id to build a CustomAction."); 
        this.mAction = param2String;
        this.mName = param2CharSequence;
        this.mIcon = param2Int;
      }
      
      public PlaybackStateCompat.CustomAction build() {
        return new PlaybackStateCompat.CustomAction(this.mAction, this.mName, this.mIcon, this.mExtras);
      }
      
      public Builder setExtras(Bundle param2Bundle) {
        this.mExtras = param2Bundle;
        return this;
      }
    }
  }
  
  static final class null implements Parcelable.Creator<CustomAction> {
    public PlaybackStateCompat.CustomAction createFromParcel(Parcel param1Parcel) {
      return new PlaybackStateCompat.CustomAction(param1Parcel);
    }
    
    public PlaybackStateCompat.CustomAction[] newArray(int param1Int) {
      return new PlaybackStateCompat.CustomAction[param1Int];
    }
  }
  
  public static final class Builder {
    private final String mAction;
    
    private Bundle mExtras;
    
    private final int mIcon;
    
    private final CharSequence mName;
    
    public Builder(String param1String, CharSequence param1CharSequence, int param1Int) {
      if (TextUtils.isEmpty(param1String))
        throw new IllegalArgumentException("You must specify an action to build a CustomAction."); 
      if (TextUtils.isEmpty(param1CharSequence))
        throw new IllegalArgumentException("You must specify a name to build a CustomAction."); 
      if (param1Int == 0)
        throw new IllegalArgumentException("You must specify an icon resource id to build a CustomAction."); 
      this.mAction = param1String;
      this.mName = param1CharSequence;
      this.mIcon = param1Int;
    }
    
    public PlaybackStateCompat.CustomAction build() {
      return new PlaybackStateCompat.CustomAction(this.mAction, this.mName, this.mIcon, this.mExtras);
    }
    
    public Builder setExtras(Bundle param1Bundle) {
      this.mExtras = param1Bundle;
      return this;
    }
  }
  
  @Retention(RetentionPolicy.SOURCE)
  public static @interface State {}
}


/* Location:              C:\soft\dex2jar-2.0\Race Simulator-dex2jar.jar!\android\support\v4\media\session\PlaybackStateCompat.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */