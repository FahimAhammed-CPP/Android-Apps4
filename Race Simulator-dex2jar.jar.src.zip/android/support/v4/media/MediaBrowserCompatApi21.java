package android.support.v4.media;

import android.content.ComponentName;
import android.content.Context;
import android.media.browse.MediaBrowser;
import android.os.Bundle;
import android.os.Parcel;
import android.support.annotation.NonNull;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

class MediaBrowserCompatApi21 {
  static final String NULL_MEDIA_ITEM_ID = "android.support.v4.media.MediaBrowserCompat.NULL_MEDIA_ITEM";
  
  public static void connect(Object paramObject) {
    ((MediaBrowser)paramObject).connect();
  }
  
  public static Object createBrowser(Context paramContext, ComponentName paramComponentName, Object paramObject, Bundle paramBundle) {
    return new MediaBrowser(paramContext, paramComponentName, (MediaBrowser.ConnectionCallback)paramObject, paramBundle);
  }
  
  public static Object createConnectionCallback(ConnectionCallback paramConnectionCallback) {
    return new ConnectionCallbackProxy<ConnectionCallback>(paramConnectionCallback);
  }
  
  public static Object createSubscriptionCallback(SubscriptionCallback paramSubscriptionCallback) {
    return new SubscriptionCallbackProxy<SubscriptionCallback>(paramSubscriptionCallback);
  }
  
  public static void disconnect(Object paramObject) {
    ((MediaBrowser)paramObject).disconnect();
  }
  
  public static Bundle getExtras(Object paramObject) {
    return ((MediaBrowser)paramObject).getExtras();
  }
  
  public static String getRoot(Object paramObject) {
    return ((MediaBrowser)paramObject).getRoot();
  }
  
  public static ComponentName getServiceComponent(Object paramObject) {
    return ((MediaBrowser)paramObject).getServiceComponent();
  }
  
  public static Object getSessionToken(Object paramObject) {
    return ((MediaBrowser)paramObject).getSessionToken();
  }
  
  public static boolean isConnected(Object paramObject) {
    return ((MediaBrowser)paramObject).isConnected();
  }
  
  public static void subscribe(Object paramObject1, String paramString, Object paramObject2) {
    ((MediaBrowser)paramObject1).subscribe(paramString, (MediaBrowser.SubscriptionCallback)paramObject2);
  }
  
  public static void unsubscribe(Object paramObject, String paramString) {
    ((MediaBrowser)paramObject).unsubscribe(paramString);
  }
  
  static interface ConnectionCallback {
    void onConnected();
    
    void onConnectionFailed();
    
    void onConnectionSuspended();
  }
  
  static class ConnectionCallbackProxy<T extends ConnectionCallback> extends MediaBrowser.ConnectionCallback {
    protected final T mConnectionCallback;
    
    public ConnectionCallbackProxy(T param1T) {
      this.mConnectionCallback = param1T;
    }
    
    public void onConnected() {
      this.mConnectionCallback.onConnected();
    }
    
    public void onConnectionFailed() {
      this.mConnectionCallback.onConnectionFailed();
    }
    
    public void onConnectionSuspended() {
      this.mConnectionCallback.onConnectionSuspended();
    }
  }
  
  static interface SubscriptionCallback {
    void onChildrenLoaded(@NonNull String param1String, List<Parcel> param1List);
    
    void onError(@NonNull String param1String);
  }
  
  static class SubscriptionCallbackProxy<T extends SubscriptionCallback> extends MediaBrowser.SubscriptionCallback {
    protected final T mSubscriptionCallback;
    
    public SubscriptionCallbackProxy(T param1T) {
      this.mSubscriptionCallback = param1T;
    }
    
    static List<Parcel> itemListToParcelList(List<MediaBrowser.MediaItem> param1List) {
      if (param1List == null || (param1List.size() == 1 && ((MediaBrowser.MediaItem)param1List.get(0)).getMediaId().equals("android.support.v4.media.MediaBrowserCompat.NULL_MEDIA_ITEM")))
        return null; 
      ArrayList<MediaBrowser.MediaItem> arrayList = new ArrayList();
      Iterator<MediaBrowser.MediaItem> iterator = param1List.iterator();
      while (true) {
        MediaBrowser.MediaItem mediaItem;
        param1List = arrayList;
        if (iterator.hasNext()) {
          mediaItem = iterator.next();
          Parcel parcel = Parcel.obtain();
          mediaItem.writeToParcel(parcel, 0);
          arrayList.add(parcel);
          continue;
        } 
        return (List<Parcel>)mediaItem;
      } 
    }
    
    public void onChildrenLoaded(@NonNull String param1String, List<MediaBrowser.MediaItem> param1List) {
      this.mSubscriptionCallback.onChildrenLoaded(param1String, itemListToParcelList(param1List));
    }
    
    public void onError(@NonNull String param1String) {
      this.mSubscriptionCallback.onError(param1String);
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Race Simulator-dex2jar.jar!\android\support\v4\media\MediaBrowserCompatApi21.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */