package android.support.v4.os;

import android.content.Context;

public class UserManagerCompat {
  @Deprecated
  public static boolean isUserRunningAndLocked(Context paramContext) {
    return !isUserUnlocked(paramContext);
  }
  
  @Deprecated
  public static boolean isUserRunningAndUnlocked(Context paramContext) {
    return isUserUnlocked(paramContext);
  }
  
  public static boolean isUserUnlocked(Context paramContext) {
    return BuildCompat.isAtLeastN() ? UserManagerCompatApi24.isUserUnlocked(paramContext) : true;
  }
}


/* Location:              C:\soft\dex2jar-2.0\Race Simulator-dex2jar.jar!\android\support\v4\os\UserManagerCompat.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */