package android.support.v4.graphics.drawable;

import android.content.res.Resources;
import android.graphics.drawable.Drawable;
import android.support.annotation.Nullable;

class DrawableWrapperEclair extends DrawableWrapperDonut {
  DrawableWrapperEclair(Drawable paramDrawable) {
    super(paramDrawable);
  }
  
  DrawableWrapperEclair(DrawableWrapperDonut.DrawableWrapperState paramDrawableWrapperState, Resources paramResources) {
    super(paramDrawableWrapperState, paramResources);
  }
  
  DrawableWrapperDonut.DrawableWrapperState mutateConstantState() {
    return new DrawableWrapperStateEclair(this.mState, null);
  }
  
  protected Drawable newDrawableFromState(Drawable.ConstantState paramConstantState, Resources paramResources) {
    return paramConstantState.newDrawable(paramResources);
  }
  
  private static class DrawableWrapperStateEclair extends DrawableWrapperDonut.DrawableWrapperState {
    DrawableWrapperStateEclair(@Nullable DrawableWrapperDonut.DrawableWrapperState param1DrawableWrapperState, @Nullable Resources param1Resources) {
      super(param1DrawableWrapperState, param1Resources);
    }
    
    public Drawable newDrawable(@Nullable Resources param1Resources) {
      return new DrawableWrapperEclair(this, param1Resources);
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Race Simulator-dex2jar.jar!\android\support\v4\graphics\drawable\DrawableWrapperEclair.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */