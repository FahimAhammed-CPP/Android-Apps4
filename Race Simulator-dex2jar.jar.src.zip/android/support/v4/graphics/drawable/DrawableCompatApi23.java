package android.support.v4.graphics.drawable;

import android.graphics.drawable.Drawable;

class DrawableCompatApi23 {
  public static int getLayoutDirection(Drawable paramDrawable) {
    return paramDrawable.getLayoutDirection();
  }
  
  public static boolean setLayoutDirection(Drawable paramDrawable, int paramInt) {
    return paramDrawable.setLayoutDirection(paramInt);
  }
}


/* Location:              C:\soft\dex2jar-2.0\Race Simulator-dex2jar.jar!\android\support\v4\graphics\drawable\DrawableCompatApi23.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */