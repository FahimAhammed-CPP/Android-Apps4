package android.support.v4.content.res;

import android.content.res.Resources;
import android.support.annotation.NonNull;
import android.util.DisplayMetrics;

class ConfigurationHelperDonut {
  static int getDensityDpi(@NonNull Resources paramResources) {
    return (paramResources.getDisplayMetrics()).densityDpi;
  }
  
  static int getScreenHeightDp(@NonNull Resources paramResources) {
    DisplayMetrics displayMetrics = paramResources.getDisplayMetrics();
    return (int)(displayMetrics.heightPixels / displayMetrics.density);
  }
  
  static int getScreenWidthDp(@NonNull Resources paramResources) {
    DisplayMetrics displayMetrics = paramResources.getDisplayMetrics();
    return (int)(displayMetrics.widthPixels / displayMetrics.density);
  }
  
  static int getSmallestScreenWidthDp(@NonNull Resources paramResources) {
    return Math.min(getScreenWidthDp(paramResources), getScreenHeightDp(paramResources));
  }
}


/* Location:              C:\soft\dex2jar-2.0\Race Simulator-dex2jar.jar!\android\support\v4\content\res\ConfigurationHelperDonut.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */