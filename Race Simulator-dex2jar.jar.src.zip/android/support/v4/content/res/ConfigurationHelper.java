package android.support.v4.content.res;

import android.content.res.Resources;
import android.os.Build;
import android.support.annotation.NonNull;

public final class ConfigurationHelper {
  private static final ConfigurationHelperImpl IMPL = new DonutImpl();
  
  public static int getDensityDpi(@NonNull Resources paramResources) {
    return IMPL.getDensityDpi(paramResources);
  }
  
  public static int getScreenHeightDp(@NonNull Resources paramResources) {
    return IMPL.getScreenHeightDp(paramResources);
  }
  
  public static int getScreenWidthDp(@NonNull Resources paramResources) {
    return IMPL.getScreenWidthDp(paramResources);
  }
  
  public static int getSmallestScreenWidthDp(@NonNull Resources paramResources) {
    return IMPL.getSmallestScreenWidthDp(paramResources);
  }
  
  static {
    int i = Build.VERSION.SDK_INT;
    if (i >= 17) {
      IMPL = new JellybeanMr1Impl();
      return;
    } 
    if (i >= 13) {
      IMPL = new HoneycombMr2Impl();
      return;
    } 
  }
  
  private static interface ConfigurationHelperImpl {
    int getDensityDpi(@NonNull Resources param1Resources);
    
    int getScreenHeightDp(@NonNull Resources param1Resources);
    
    int getScreenWidthDp(@NonNull Resources param1Resources);
    
    int getSmallestScreenWidthDp(@NonNull Resources param1Resources);
  }
  
  private static class DonutImpl implements ConfigurationHelperImpl {
    private DonutImpl() {}
    
    public int getDensityDpi(@NonNull Resources param1Resources) {
      return ConfigurationHelperDonut.getDensityDpi(param1Resources);
    }
    
    public int getScreenHeightDp(@NonNull Resources param1Resources) {
      return ConfigurationHelperDonut.getScreenHeightDp(param1Resources);
    }
    
    public int getScreenWidthDp(@NonNull Resources param1Resources) {
      return ConfigurationHelperDonut.getScreenWidthDp(param1Resources);
    }
    
    public int getSmallestScreenWidthDp(@NonNull Resources param1Resources) {
      return ConfigurationHelperDonut.getSmallestScreenWidthDp(param1Resources);
    }
  }
  
  private static class HoneycombMr2Impl extends DonutImpl {
    private HoneycombMr2Impl() {}
    
    public int getScreenHeightDp(@NonNull Resources param1Resources) {
      return ConfigurationHelperHoneycombMr2.getScreenHeightDp(param1Resources);
    }
    
    public int getScreenWidthDp(@NonNull Resources param1Resources) {
      return ConfigurationHelperHoneycombMr2.getScreenWidthDp(param1Resources);
    }
    
    public int getSmallestScreenWidthDp(@NonNull Resources param1Resources) {
      return ConfigurationHelperHoneycombMr2.getSmallestScreenWidthDp(param1Resources);
    }
  }
  
  private static class JellybeanMr1Impl extends HoneycombMr2Impl {
    private JellybeanMr1Impl() {}
    
    public int getDensityDpi(@NonNull Resources param1Resources) {
      return ConfigurationHelperJellybeanMr1.getDensityDpi(param1Resources);
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Race Simulator-dex2jar.jar!\android\support\v4\content\res\ConfigurationHelper.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */