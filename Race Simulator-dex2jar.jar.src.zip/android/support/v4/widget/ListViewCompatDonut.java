package android.support.v4.widget;

import android.view.View;
import android.widget.ListView;

class ListViewCompatDonut {
  static void scrollListBy(ListView paramListView, int paramInt) {
    int i = paramListView.getFirstVisiblePosition();
    if (i != -1) {
      View view = paramListView.getChildAt(0);
      if (view != null) {
        paramListView.setSelectionFromTop(i, view.getTop() - paramInt);
        return;
      } 
    } 
  }
}


/* Location:              C:\soft\dex2jar-2.0\Race Simulator-dex2jar.jar!\android\support\v4\widget\ListViewCompatDonut.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */