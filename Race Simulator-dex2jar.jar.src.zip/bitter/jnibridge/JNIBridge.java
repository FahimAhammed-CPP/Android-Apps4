package bitter.jnibridge;

import java.lang.reflect.InvocationHandler;
import java.lang.reflect.Method;
import java.lang.reflect.Proxy;

public class JNIBridge {
  static native void delete(long paramLong);
  
  static void disableInterfaceProxy(Object paramObject) {
    ((a)Proxy.getInvocationHandler(paramObject)).a();
  }
  
  static native Object invoke(long paramLong, Class paramClass, Method paramMethod, Object[] paramArrayOfObject);
  
  static Object newInterfaceProxy(long paramLong, Class[] paramArrayOfClass) {
    return Proxy.newProxyInstance(JNIBridge.class.getClassLoader(), paramArrayOfClass, new a(paramLong));
  }
  
  private static final class a implements InvocationHandler {
    private Object a = new Object[0];
    
    private long b;
    
    public a(long param1Long) {
      this.b = param1Long;
    }
    
    public final void a() {
      synchronized (this.a) {
        this.b = 0L;
        return;
      } 
    }
    
    public final void finalize() {
      synchronized (this.a) {
        if (this.b == 0L)
          return; 
        JNIBridge.delete(this.b);
        return;
      } 
    }
    
    public final Object invoke(Object param1Object, Method param1Method, Object[] param1ArrayOfObject) {
      synchronized (this.a) {
        if (this.b == 0L)
          return null; 
        return JNIBridge.invoke(this.b, param1Method.getDeclaringClass(), param1Method, param1ArrayOfObject);
      } 
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Race Simulator-dex2jar.jar!\bitter\jnibridge\JNIBridge.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */