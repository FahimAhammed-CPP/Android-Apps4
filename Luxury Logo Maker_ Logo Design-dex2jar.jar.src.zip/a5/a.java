package a5;

import android.graphics.Canvas;
import android.graphics.drawable.Drawable;
import w4.a;
import z4.d;

public class a extends a implements d {
  public void a() {
    throw null;
  }
  
  public void b() {
    throw null;
  }
  
  public void draw(Canvas paramCanvas) {
    super.draw(paramCanvas);
  }
  
  public Drawable getCircularRevealOverlayDrawable() {
    throw null;
  }
  
  public int getCircularRevealScrimColor() {
    throw null;
  }
  
  public d.e getRevealInfo() {
    throw null;
  }
  
  public boolean isOpaque() {
    return super.isOpaque();
  }
  
  public void setCircularRevealOverlayDrawable(Drawable paramDrawable) {
    throw null;
  }
  
  public void setCircularRevealScrimColor(int paramInt) {
    throw null;
  }
  
  public void setRevealInfo(d.e parame) {
    throw null;
  }
}


/* Location:              C:\soft\dex2jar-2.0\Luxury Logo Maker_ Logo Design-dex2jar.jar!\a5\a.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */