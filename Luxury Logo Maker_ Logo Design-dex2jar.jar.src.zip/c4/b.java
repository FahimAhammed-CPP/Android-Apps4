package c4;

import android.os.IBinder;
import java.lang.reflect.Field;
import java.util.Objects;

public final class b<T> extends a.a {
  public final T h;
  
  public b(T paramT) {
    this.h = paramT;
  }
  
  public static <T> T h0(a parama) {
    Field field;
    if (parama instanceof b)
      return ((b)parama).h; 
    IBinder iBinder = parama.asBinder();
    Field[] arrayOfField = iBinder.getClass().getDeclaredFields();
    int k = arrayOfField.length;
    parama = null;
    int i = 0;
    int j;
    for (j = 0; i < k; j = m) {
      Field field1 = arrayOfField[i];
      int m = j;
      if (!field1.isSynthetic()) {
        m = j + 1;
        field = field1;
      } 
      i++;
    } 
    if (j == 1) {
      Objects.requireNonNull(field, "null reference");
      if (!field.isAccessible()) {
        field.setAccessible(true);
        try {
          return (T)field.get(iBinder);
        } catch (NullPointerException nullPointerException) {
          throw new IllegalArgumentException("Binder object is null.", nullPointerException);
        } catch (IllegalAccessException illegalAccessException) {
          throw new IllegalArgumentException("Could not access the field in remoteBinder.", illegalAccessException);
        } 
      } 
      throw new IllegalArgumentException("IObjectWrapper declared field not private!");
    } 
    i = arrayOfField.length;
    StringBuilder stringBuilder = new StringBuilder(64);
    stringBuilder.append("Unexpected number of IObjectWrapper declared fields: ");
    stringBuilder.append(i);
    throw new IllegalArgumentException(stringBuilder.toString());
  }
}


/* Location:              C:\soft\dex2jar-2.0\Luxury Logo Maker_ Logo Design-dex2jar.jar!\c4\b.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */