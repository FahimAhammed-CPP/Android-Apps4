package c4;

import android.os.IBinder;
import android.os.IInterface;

public interface a extends IInterface {
  public static abstract class a extends i4.a implements a {
    public a() {
      super("com.google.android.gms.dynamic.IObjectWrapper");
    }
    
    public static a f0(IBinder param1IBinder) {
      if (param1IBinder == null)
        return null; 
      IInterface iInterface = param1IBinder.queryLocalInterface("com.google.android.gms.dynamic.IObjectWrapper");
      return (iInterface instanceof a) ? (a)iInterface : new d(param1IBinder);
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Luxury Logo Maker_ Logo Design-dex2jar.jar!\c4\a.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */