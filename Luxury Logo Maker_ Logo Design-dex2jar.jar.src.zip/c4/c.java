package c4;

import android.content.Context;
import android.os.IBinder;
import java.util.Objects;
import t3.i;

public abstract class c<T> {
  public final String a;
  
  public T b;
  
  public c(String paramString) {
    this.a = paramString;
  }
  
  public abstract T a(IBinder paramIBinder);
  
  public final T b(Context paramContext) {
    if (this.b == null) {
      Objects.requireNonNull(paramContext, "null reference");
      paramContext = i.a(paramContext);
      if (paramContext != null) {
        ClassLoader classLoader = paramContext.getClassLoader();
        try {
          this.b = a((IBinder)classLoader.loadClass(this.a).newInstance());
        } catch (ClassNotFoundException classNotFoundException) {
          throw new a("Could not load creator class.", classNotFoundException);
        } catch (InstantiationException instantiationException) {
          throw new a("Could not instantiate creator.", instantiationException);
        } catch (IllegalAccessException illegalAccessException) {
          throw new a("Could not access creator.", illegalAccessException);
        } 
      } else {
        throw new a("Could not get remote context.");
      } 
    } 
    return this.b;
  }
  
  public static class a extends Exception {
    public a(String param1String) {
      super(param1String);
    }
    
    public a(String param1String, Throwable param1Throwable) {
      super(param1String, param1Throwable);
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Luxury Logo Maker_ Logo Design-dex2jar.jar!\c4\c.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */