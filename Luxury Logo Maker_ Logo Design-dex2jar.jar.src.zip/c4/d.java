package c4;

import android.os.IBinder;
import e4.kc;

public final class d extends kc implements a {
  public d(IBinder paramIBinder) {
    super(paramIBinder, "com.google.android.gms.dynamic.IObjectWrapper", 1);
  }
}


/* Location:              C:\soft\dex2jar-2.0\Luxury Logo Maker_ Logo Design-dex2jar.jar!\c4\d.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */