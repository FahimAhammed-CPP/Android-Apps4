package a4;

import e4.aq0;
import e4.oe0;
import g3.p;
import java.util.ArrayList;
import t.d;
import u.e;

public class f implements aq0 {
  public static final char[] h = new char[] { 
      '0', '1', '2', '3', '4', '5', '6', '7', '8', '9', 
      'a', 'b', 'c', 'd', 'e', 'f' };
  
  public static final oe0 i = new oe0(0);
  
  public static void a(e parame, d paramd, ArrayList paramArrayList, int paramInt) {
    // Byte code:
    //   0: aload_0
    //   1: astore #21
    //   3: aload_1
    //   4: astore #23
    //   6: iload_3
    //   7: ifne -> 30
    //   10: aload #21
    //   12: getfield t0 : I
    //   15: istore #9
    //   17: aload #21
    //   19: getfield w0 : [Lu/b;
    //   22: astore #21
    //   24: iconst_0
    //   25: istore #14
    //   27: goto -> 47
    //   30: aload #21
    //   32: getfield u0 : I
    //   35: istore #9
    //   37: aload #21
    //   39: getfield v0 : [Lu/b;
    //   42: astore #21
    //   44: iconst_2
    //   45: istore #14
    //   47: iconst_0
    //   48: istore #8
    //   50: aload_2
    //   51: astore #27
    //   53: aload_0
    //   54: astore #31
    //   56: iload #8
    //   58: iload #9
    //   60: if_icmpge -> 4030
    //   63: aload #21
    //   65: iload #8
    //   67: aaload
    //   68: astore #26
    //   70: aload #26
    //   72: getfield t : Z
    //   75: istore #20
    //   77: aconst_null
    //   78: astore #33
    //   80: iload #20
    //   82: ifne -> 889
    //   85: aload #26
    //   87: getfield o : I
    //   90: iconst_2
    //   91: imul
    //   92: istore #12
    //   94: aload #26
    //   96: getfield a : Lu/d;
    //   99: astore #22
    //   101: aload #22
    //   103: astore #24
    //   105: iconst_0
    //   106: istore #11
    //   108: iload #11
    //   110: ifne -> 744
    //   113: aload #26
    //   115: aload #26
    //   117: getfield i : I
    //   120: iconst_1
    //   121: iadd
    //   122: putfield i : I
    //   125: aload #22
    //   127: getfield i0 : [Lu/d;
    //   130: astore #25
    //   132: aload #26
    //   134: getfield o : I
    //   137: istore #10
    //   139: aload #25
    //   141: iload #10
    //   143: aconst_null
    //   144: aastore
    //   145: aload #22
    //   147: getfield h0 : [Lu/d;
    //   150: iload #10
    //   152: aconst_null
    //   153: aastore
    //   154: aload #22
    //   156: getfield c0 : I
    //   159: bipush #8
    //   161: if_icmpeq -> 630
    //   164: aload #26
    //   166: aload #26
    //   168: getfield l : I
    //   171: iconst_1
    //   172: iadd
    //   173: putfield l : I
    //   176: aload #22
    //   178: iload #10
    //   180: invokevirtual k : (I)I
    //   183: iconst_3
    //   184: if_icmpeq -> 245
    //   187: aload #26
    //   189: getfield m : I
    //   192: istore #13
    //   194: aload #26
    //   196: getfield o : I
    //   199: istore #10
    //   201: iload #10
    //   203: ifne -> 216
    //   206: aload #22
    //   208: invokevirtual r : ()I
    //   211: istore #10
    //   213: goto -> 235
    //   216: iload #10
    //   218: iconst_1
    //   219: if_icmpne -> 232
    //   222: aload #22
    //   224: invokevirtual l : ()I
    //   227: istore #10
    //   229: goto -> 235
    //   232: iconst_0
    //   233: istore #10
    //   235: aload #26
    //   237: iload #13
    //   239: iload #10
    //   241: iadd
    //   242: putfield m : I
    //   245: aload #26
    //   247: getfield m : I
    //   250: istore #10
    //   252: aload #22
    //   254: getfield L : [Lu/c;
    //   257: iload #12
    //   259: aaload
    //   260: invokevirtual d : ()I
    //   263: iload #10
    //   265: iadd
    //   266: istore #13
    //   268: aload #26
    //   270: iload #13
    //   272: putfield m : I
    //   275: aload #22
    //   277: getfield L : [Lu/c;
    //   280: astore #25
    //   282: iload #12
    //   284: iconst_1
    //   285: iadd
    //   286: istore #10
    //   288: aload #26
    //   290: aload #25
    //   292: iload #10
    //   294: aaload
    //   295: invokevirtual d : ()I
    //   298: iload #13
    //   300: iadd
    //   301: putfield m : I
    //   304: aload #26
    //   306: getfield n : I
    //   309: istore #13
    //   311: aload #22
    //   313: getfield L : [Lu/c;
    //   316: iload #12
    //   318: aaload
    //   319: invokevirtual d : ()I
    //   322: iload #13
    //   324: iadd
    //   325: istore #13
    //   327: aload #26
    //   329: iload #13
    //   331: putfield n : I
    //   334: aload #26
    //   336: aload #22
    //   338: getfield L : [Lu/c;
    //   341: iload #10
    //   343: aaload
    //   344: invokevirtual d : ()I
    //   347: iload #13
    //   349: iadd
    //   350: putfield n : I
    //   353: aload #26
    //   355: getfield b : Lu/d;
    //   358: ifnonnull -> 368
    //   361: aload #26
    //   363: aload #22
    //   365: putfield b : Lu/d;
    //   368: aload #26
    //   370: aload #22
    //   372: putfield d : Lu/d;
    //   375: aload #22
    //   377: getfield O : [I
    //   380: astore #25
    //   382: aload #26
    //   384: getfield o : I
    //   387: istore #10
    //   389: aload #25
    //   391: iload #10
    //   393: iaload
    //   394: iconst_3
    //   395: if_icmpne -> 630
    //   398: aload #22
    //   400: getfield n : [I
    //   403: astore #28
    //   405: aload #28
    //   407: iload #10
    //   409: iaload
    //   410: ifeq -> 431
    //   413: aload #28
    //   415: iload #10
    //   417: iaload
    //   418: iconst_3
    //   419: if_icmpeq -> 431
    //   422: aload #28
    //   424: iload #10
    //   426: iaload
    //   427: iconst_2
    //   428: if_icmpne -> 630
    //   431: aload #26
    //   433: aload #26
    //   435: getfield j : I
    //   438: iconst_1
    //   439: iadd
    //   440: putfield j : I
    //   443: aload #22
    //   445: getfield g0 : [F
    //   448: astore #29
    //   450: aload #29
    //   452: iload #10
    //   454: faload
    //   455: fstore #4
    //   457: fload #4
    //   459: fconst_0
    //   460: fcmpl
    //   461: ifle -> 480
    //   464: aload #26
    //   466: aload #26
    //   468: getfield k : F
    //   471: aload #29
    //   473: iload #10
    //   475: faload
    //   476: fadd
    //   477: putfield k : F
    //   480: aload #22
    //   482: getfield c0 : I
    //   485: bipush #8
    //   487: if_icmpeq -> 522
    //   490: aload #25
    //   492: iload #10
    //   494: iaload
    //   495: iconst_3
    //   496: if_icmpne -> 522
    //   499: aload #28
    //   501: iload #10
    //   503: iaload
    //   504: ifeq -> 516
    //   507: aload #28
    //   509: iload #10
    //   511: iaload
    //   512: iconst_3
    //   513: if_icmpne -> 522
    //   516: iconst_1
    //   517: istore #10
    //   519: goto -> 525
    //   522: iconst_0
    //   523: istore #10
    //   525: iload #10
    //   527: ifeq -> 583
    //   530: fload #4
    //   532: fconst_0
    //   533: fcmpg
    //   534: ifge -> 546
    //   537: aload #26
    //   539: iconst_1
    //   540: putfield q : Z
    //   543: goto -> 552
    //   546: aload #26
    //   548: iconst_1
    //   549: putfield r : Z
    //   552: aload #26
    //   554: getfield h : Ljava/util/ArrayList;
    //   557: ifnonnull -> 572
    //   560: aload #26
    //   562: new java/util/ArrayList
    //   565: dup
    //   566: invokespecial <init> : ()V
    //   569: putfield h : Ljava/util/ArrayList;
    //   572: aload #26
    //   574: getfield h : Ljava/util/ArrayList;
    //   577: aload #22
    //   579: invokevirtual add : (Ljava/lang/Object;)Z
    //   582: pop
    //   583: aload #26
    //   585: getfield f : Lu/d;
    //   588: ifnonnull -> 598
    //   591: aload #26
    //   593: aload #22
    //   595: putfield f : Lu/d;
    //   598: aload #26
    //   600: getfield g : Lu/d;
    //   603: astore #25
    //   605: aload #25
    //   607: ifnull -> 623
    //   610: aload #25
    //   612: getfield h0 : [Lu/d;
    //   615: aload #26
    //   617: getfield o : I
    //   620: aload #22
    //   622: aastore
    //   623: aload #26
    //   625: aload #22
    //   627: putfield g : Lu/d;
    //   630: aload #24
    //   632: aload #22
    //   634: if_acmpeq -> 650
    //   637: aload #24
    //   639: getfield i0 : [Lu/d;
    //   642: aload #26
    //   644: getfield o : I
    //   647: aload #22
    //   649: aastore
    //   650: aload #22
    //   652: getfield L : [Lu/c;
    //   655: iload #12
    //   657: iconst_1
    //   658: iadd
    //   659: aaload
    //   660: getfield f : Lu/c;
    //   663: astore #24
    //   665: aload #24
    //   667: ifnull -> 711
    //   670: aload #24
    //   672: getfield d : Lu/d;
    //   675: astore #24
    //   677: aload #24
    //   679: getfield L : [Lu/c;
    //   682: astore #25
    //   684: aload #25
    //   686: iload #12
    //   688: aaload
    //   689: getfield f : Lu/c;
    //   692: ifnull -> 711
    //   695: aload #25
    //   697: iload #12
    //   699: aaload
    //   700: getfield f : Lu/c;
    //   703: getfield d : Lu/d;
    //   706: aload #22
    //   708: if_acmpeq -> 714
    //   711: aconst_null
    //   712: astore #24
    //   714: aload #24
    //   716: ifnull -> 722
    //   719: goto -> 729
    //   722: aload #22
    //   724: astore #24
    //   726: iconst_1
    //   727: istore #11
    //   729: aload #22
    //   731: astore #25
    //   733: aload #24
    //   735: astore #22
    //   737: aload #25
    //   739: astore #24
    //   741: goto -> 108
    //   744: aload #26
    //   746: getfield b : Lu/d;
    //   749: astore #24
    //   751: aload #24
    //   753: ifnull -> 778
    //   756: aload #26
    //   758: aload #26
    //   760: getfield m : I
    //   763: aload #24
    //   765: getfield L : [Lu/c;
    //   768: iload #12
    //   770: aaload
    //   771: invokevirtual d : ()I
    //   774: isub
    //   775: putfield m : I
    //   778: aload #26
    //   780: getfield d : Lu/d;
    //   783: astore #24
    //   785: aload #24
    //   787: ifnull -> 814
    //   790: aload #26
    //   792: aload #26
    //   794: getfield m : I
    //   797: aload #24
    //   799: getfield L : [Lu/c;
    //   802: iload #12
    //   804: iconst_1
    //   805: iadd
    //   806: aaload
    //   807: invokevirtual d : ()I
    //   810: isub
    //   811: putfield m : I
    //   814: aload #26
    //   816: aload #22
    //   818: putfield c : Lu/d;
    //   821: aload #26
    //   823: getfield o : I
    //   826: ifne -> 847
    //   829: aload #26
    //   831: getfield p : Z
    //   834: ifeq -> 847
    //   837: aload #26
    //   839: aload #22
    //   841: putfield e : Lu/d;
    //   844: goto -> 857
    //   847: aload #26
    //   849: aload #26
    //   851: getfield a : Lu/d;
    //   854: putfield e : Lu/d;
    //   857: aload #26
    //   859: getfield r : Z
    //   862: ifeq -> 879
    //   865: aload #26
    //   867: getfield q : Z
    //   870: ifeq -> 879
    //   873: iconst_1
    //   874: istore #20
    //   876: goto -> 882
    //   879: iconst_0
    //   880: istore #20
    //   882: aload #26
    //   884: iload #20
    //   886: putfield s : Z
    //   889: aload #26
    //   891: iconst_1
    //   892: putfield t : Z
    //   895: aload #27
    //   897: ifnull -> 935
    //   900: aload #27
    //   902: aload #26
    //   904: getfield a : Lu/d;
    //   907: invokevirtual contains : (Ljava/lang/Object;)Z
    //   910: ifeq -> 916
    //   913: goto -> 935
    //   916: aload #21
    //   918: astore #22
    //   920: aload #23
    //   922: astore #21
    //   924: iload #8
    //   926: istore #10
    //   928: iload #9
    //   930: istore #8
    //   932: goto -> 4005
    //   935: aload #26
    //   937: getfield a : Lu/d;
    //   940: astore #34
    //   942: aload #26
    //   944: getfield c : Lu/d;
    //   947: astore #24
    //   949: aload #26
    //   951: getfield b : Lu/d;
    //   954: astore #29
    //   956: aload #26
    //   958: getfield d : Lu/d;
    //   961: astore #30
    //   963: aload #26
    //   965: getfield e : Lu/d;
    //   968: astore #25
    //   970: aload #26
    //   972: getfield k : F
    //   975: fstore #5
    //   977: aload #31
    //   979: getfield O : [I
    //   982: iload_3
    //   983: iaload
    //   984: iconst_2
    //   985: if_icmpne -> 994
    //   988: iconst_1
    //   989: istore #15
    //   991: goto -> 997
    //   994: iconst_0
    //   995: istore #15
    //   997: iload_3
    //   998: ifne -> 1062
    //   1001: aload #25
    //   1003: getfield e0 : I
    //   1006: istore #16
    //   1008: iload #16
    //   1010: ifne -> 1019
    //   1013: iconst_1
    //   1014: istore #11
    //   1016: goto -> 1022
    //   1019: iconst_0
    //   1020: istore #11
    //   1022: iload #16
    //   1024: iconst_1
    //   1025: if_icmpne -> 1034
    //   1028: iconst_1
    //   1029: istore #10
    //   1031: goto -> 1037
    //   1034: iconst_0
    //   1035: istore #10
    //   1037: iload #10
    //   1039: istore #12
    //   1041: iload #11
    //   1043: istore #13
    //   1045: iload #16
    //   1047: iconst_2
    //   1048: if_icmpne -> 1126
    //   1051: iload #10
    //   1053: istore #12
    //   1055: iload #11
    //   1057: istore #10
    //   1059: goto -> 1116
    //   1062: aload #25
    //   1064: getfield f0 : I
    //   1067: istore #16
    //   1069: iload #16
    //   1071: ifne -> 1080
    //   1074: iconst_1
    //   1075: istore #10
    //   1077: goto -> 1083
    //   1080: iconst_0
    //   1081: istore #10
    //   1083: iload #16
    //   1085: iconst_1
    //   1086: if_icmpne -> 1095
    //   1089: iconst_1
    //   1090: istore #11
    //   1092: goto -> 1098
    //   1095: iconst_0
    //   1096: istore #11
    //   1098: iload #11
    //   1100: istore #12
    //   1102: iload #10
    //   1104: istore #13
    //   1106: iload #16
    //   1108: iconst_2
    //   1109: if_icmpne -> 1126
    //   1112: iload #11
    //   1114: istore #12
    //   1116: iconst_1
    //   1117: istore #16
    //   1119: iload #10
    //   1121: istore #13
    //   1123: goto -> 1129
    //   1126: iconst_0
    //   1127: istore #16
    //   1129: aload #34
    //   1131: astore #27
    //   1133: iconst_0
    //   1134: istore #11
    //   1136: iload #11
    //   1138: ifne -> 1540
    //   1141: aload #27
    //   1143: getfield L : [Lu/c;
    //   1146: iload #14
    //   1148: aaload
    //   1149: astore #22
    //   1151: iload #16
    //   1153: ifeq -> 1162
    //   1156: iconst_1
    //   1157: istore #10
    //   1159: goto -> 1165
    //   1162: iconst_4
    //   1163: istore #10
    //   1165: aload #22
    //   1167: invokevirtual d : ()I
    //   1170: istore #19
    //   1172: aload #27
    //   1174: getfield O : [I
    //   1177: iload_3
    //   1178: iaload
    //   1179: iconst_3
    //   1180: if_icmpne -> 1199
    //   1183: aload #27
    //   1185: getfield n : [I
    //   1188: iload_3
    //   1189: iaload
    //   1190: ifne -> 1199
    //   1193: iconst_1
    //   1194: istore #18
    //   1196: goto -> 1202
    //   1199: iconst_0
    //   1200: istore #18
    //   1202: aload #22
    //   1204: getfield f : Lu/c;
    //   1207: astore #28
    //   1209: iload #19
    //   1211: istore #17
    //   1213: aload #28
    //   1215: ifnull -> 1239
    //   1218: iload #19
    //   1220: istore #17
    //   1222: aload #27
    //   1224: aload #34
    //   1226: if_acmpeq -> 1239
    //   1229: aload #28
    //   1231: invokevirtual d : ()I
    //   1234: iload #19
    //   1236: iadd
    //   1237: istore #17
    //   1239: iload #16
    //   1241: ifeq -> 1265
    //   1244: aload #27
    //   1246: aload #34
    //   1248: if_acmpeq -> 1265
    //   1251: aload #27
    //   1253: aload #29
    //   1255: if_acmpeq -> 1265
    //   1258: bipush #8
    //   1260: istore #10
    //   1262: goto -> 1265
    //   1265: aload #22
    //   1267: getfield f : Lu/c;
    //   1270: astore #28
    //   1272: aload #28
    //   1274: ifnull -> 1367
    //   1277: aload #27
    //   1279: aload #29
    //   1281: if_acmpne -> 1306
    //   1284: aload #23
    //   1286: aload #22
    //   1288: getfield i : Lt/h;
    //   1291: aload #28
    //   1293: getfield i : Lt/h;
    //   1296: iload #17
    //   1298: bipush #6
    //   1300: invokevirtual f : (Lt/h;Lt/h;II)V
    //   1303: goto -> 1325
    //   1306: aload #23
    //   1308: aload #22
    //   1310: getfield i : Lt/h;
    //   1313: aload #28
    //   1315: getfield i : Lt/h;
    //   1318: iload #17
    //   1320: bipush #8
    //   1322: invokevirtual f : (Lt/h;Lt/h;II)V
    //   1325: iload #18
    //   1327: ifeq -> 1341
    //   1330: iload #16
    //   1332: ifne -> 1341
    //   1335: iconst_5
    //   1336: istore #10
    //   1338: goto -> 1341
    //   1341: aload #23
    //   1343: aload #22
    //   1345: getfield i : Lt/h;
    //   1348: aload #22
    //   1350: getfield f : Lu/c;
    //   1353: getfield i : Lt/h;
    //   1356: iload #17
    //   1358: iload #10
    //   1360: invokevirtual d : (Lt/h;Lt/h;II)Lt/b;
    //   1363: pop
    //   1364: goto -> 1367
    //   1367: iload #15
    //   1369: ifeq -> 1458
    //   1372: aload #27
    //   1374: getfield c0 : I
    //   1377: bipush #8
    //   1379: if_icmpeq -> 1428
    //   1382: aload #27
    //   1384: getfield O : [I
    //   1387: iload_3
    //   1388: iaload
    //   1389: iconst_3
    //   1390: if_icmpne -> 1428
    //   1393: aload #27
    //   1395: getfield L : [Lu/c;
    //   1398: astore #22
    //   1400: aload #23
    //   1402: aload #22
    //   1404: iload #14
    //   1406: iconst_1
    //   1407: iadd
    //   1408: aaload
    //   1409: getfield i : Lt/h;
    //   1412: aload #22
    //   1414: iload #14
    //   1416: aaload
    //   1417: getfield i : Lt/h;
    //   1420: iconst_0
    //   1421: iconst_5
    //   1422: invokevirtual f : (Lt/h;Lt/h;II)V
    //   1425: goto -> 1428
    //   1428: aload #23
    //   1430: aload #27
    //   1432: getfield L : [Lu/c;
    //   1435: iload #14
    //   1437: aaload
    //   1438: getfield i : Lt/h;
    //   1441: aload #31
    //   1443: getfield L : [Lu/c;
    //   1446: iload #14
    //   1448: aaload
    //   1449: getfield i : Lt/h;
    //   1452: iconst_0
    //   1453: bipush #8
    //   1455: invokevirtual f : (Lt/h;Lt/h;II)V
    //   1458: aload #27
    //   1460: getfield L : [Lu/c;
    //   1463: iload #14
    //   1465: iconst_1
    //   1466: iadd
    //   1467: aaload
    //   1468: getfield f : Lu/c;
    //   1471: astore #22
    //   1473: aload #22
    //   1475: ifnull -> 1519
    //   1478: aload #22
    //   1480: getfield d : Lu/d;
    //   1483: astore #22
    //   1485: aload #22
    //   1487: getfield L : [Lu/c;
    //   1490: astore #28
    //   1492: aload #28
    //   1494: iload #14
    //   1496: aaload
    //   1497: getfield f : Lu/c;
    //   1500: ifnull -> 1519
    //   1503: aload #28
    //   1505: iload #14
    //   1507: aaload
    //   1508: getfield f : Lu/c;
    //   1511: getfield d : Lu/d;
    //   1514: aload #27
    //   1516: if_acmpeq -> 1522
    //   1519: aconst_null
    //   1520: astore #22
    //   1522: aload #22
    //   1524: ifnull -> 1534
    //   1527: aload #22
    //   1529: astore #27
    //   1531: goto -> 1537
    //   1534: iconst_1
    //   1535: istore #11
    //   1537: goto -> 1136
    //   1540: iload #9
    //   1542: istore #11
    //   1544: aload #21
    //   1546: astore #28
    //   1548: aload #30
    //   1550: ifnull -> 1753
    //   1553: aload #24
    //   1555: getfield L : [Lu/c;
    //   1558: astore #21
    //   1560: iload #14
    //   1562: iconst_1
    //   1563: iadd
    //   1564: istore #10
    //   1566: aload #21
    //   1568: iload #10
    //   1570: aaload
    //   1571: getfield f : Lu/c;
    //   1574: ifnull -> 1753
    //   1577: aload #30
    //   1579: getfield L : [Lu/c;
    //   1582: iload #10
    //   1584: aaload
    //   1585: astore #21
    //   1587: aload #30
    //   1589: getfield O : [I
    //   1592: iload_3
    //   1593: iaload
    //   1594: iconst_3
    //   1595: if_icmpne -> 1614
    //   1598: aload #30
    //   1600: getfield n : [I
    //   1603: iload_3
    //   1604: iaload
    //   1605: ifne -> 1614
    //   1608: iconst_1
    //   1609: istore #9
    //   1611: goto -> 1617
    //   1614: iconst_0
    //   1615: istore #9
    //   1617: iload #9
    //   1619: ifeq -> 1670
    //   1622: iload #16
    //   1624: ifne -> 1670
    //   1627: aload #21
    //   1629: getfield f : Lu/c;
    //   1632: astore #22
    //   1634: aload #22
    //   1636: getfield d : Lu/d;
    //   1639: aload #31
    //   1641: if_acmpne -> 1670
    //   1644: aload #23
    //   1646: aload #21
    //   1648: getfield i : Lt/h;
    //   1651: aload #22
    //   1653: getfield i : Lt/h;
    //   1656: aload #21
    //   1658: invokevirtual d : ()I
    //   1661: ineg
    //   1662: iconst_5
    //   1663: invokevirtual d : (Lt/h;Lt/h;II)Lt/b;
    //   1666: pop
    //   1667: goto -> 1718
    //   1670: iload #16
    //   1672: ifeq -> 1718
    //   1675: aload #21
    //   1677: getfield f : Lu/c;
    //   1680: astore #22
    //   1682: aload #22
    //   1684: getfield d : Lu/d;
    //   1687: aload #31
    //   1689: if_acmpne -> 1718
    //   1692: aload #23
    //   1694: aload #21
    //   1696: getfield i : Lt/h;
    //   1699: aload #22
    //   1701: getfield i : Lt/h;
    //   1704: aload #21
    //   1706: invokevirtual d : ()I
    //   1709: ineg
    //   1710: iconst_4
    //   1711: invokevirtual d : (Lt/h;Lt/h;II)Lt/b;
    //   1714: pop
    //   1715: goto -> 1718
    //   1718: aload #23
    //   1720: aload #21
    //   1722: getfield i : Lt/h;
    //   1725: aload #24
    //   1727: getfield L : [Lu/c;
    //   1730: iload #10
    //   1732: aaload
    //   1733: getfield f : Lu/c;
    //   1736: getfield i : Lt/h;
    //   1739: aload #21
    //   1741: invokevirtual d : ()I
    //   1744: ineg
    //   1745: bipush #6
    //   1747: invokevirtual g : (Lt/h;Lt/h;II)V
    //   1750: goto -> 1753
    //   1753: iload #15
    //   1755: ifeq -> 1813
    //   1758: aload #31
    //   1760: getfield L : [Lu/c;
    //   1763: astore #21
    //   1765: iload #14
    //   1767: iconst_1
    //   1768: iadd
    //   1769: istore #9
    //   1771: aload #21
    //   1773: iload #9
    //   1775: aaload
    //   1776: getfield i : Lt/h;
    //   1779: astore #21
    //   1781: aload #24
    //   1783: getfield L : [Lu/c;
    //   1786: astore #22
    //   1788: aload #23
    //   1790: aload #21
    //   1792: aload #22
    //   1794: iload #9
    //   1796: aaload
    //   1797: getfield i : Lt/h;
    //   1800: aload #22
    //   1802: iload #9
    //   1804: aaload
    //   1805: invokevirtual d : ()I
    //   1808: bipush #8
    //   1810: invokevirtual f : (Lt/h;Lt/h;II)V
    //   1813: aload #26
    //   1815: getfield h : Ljava/util/ArrayList;
    //   1818: astore #27
    //   1820: aload #26
    //   1822: astore #32
    //   1824: aload #24
    //   1826: astore #21
    //   1828: aload #27
    //   1830: ifnull -> 2384
    //   1833: aload #27
    //   1835: invokevirtual size : ()I
    //   1838: istore #9
    //   1840: aload #26
    //   1842: astore #32
    //   1844: aload #24
    //   1846: astore #21
    //   1848: iload #9
    //   1850: iconst_1
    //   1851: if_icmple -> 2384
    //   1854: aload #26
    //   1856: getfield q : Z
    //   1859: ifeq -> 1881
    //   1862: aload #26
    //   1864: getfield s : Z
    //   1867: ifne -> 1881
    //   1870: aload #26
    //   1872: getfield j : I
    //   1875: i2f
    //   1876: fstore #5
    //   1878: goto -> 1881
    //   1881: aconst_null
    //   1882: astore #31
    //   1884: fconst_0
    //   1885: fstore #6
    //   1887: iconst_0
    //   1888: istore #10
    //   1890: aload #24
    //   1892: astore #22
    //   1894: aload #26
    //   1896: astore #24
    //   1898: aload #24
    //   1900: astore #32
    //   1902: aload #22
    //   1904: astore #21
    //   1906: iload #10
    //   1908: iload #9
    //   1910: if_icmpge -> 2384
    //   1913: aload #27
    //   1915: iload #10
    //   1917: invokevirtual get : (I)Ljava/lang/Object;
    //   1920: checkcast u/d
    //   1923: astore #26
    //   1925: aload #26
    //   1927: getfield g0 : [F
    //   1930: iload_3
    //   1931: faload
    //   1932: fstore #7
    //   1934: fload #7
    //   1936: fstore #4
    //   1938: fload #7
    //   1940: fconst_0
    //   1941: fcmpg
    //   1942: ifge -> 1991
    //   1945: aload #24
    //   1947: getfield s : Z
    //   1950: ifeq -> 1988
    //   1953: aload #26
    //   1955: getfield L : [Lu/c;
    //   1958: astore #26
    //   1960: aload #26
    //   1962: iload #14
    //   1964: iconst_1
    //   1965: iadd
    //   1966: aaload
    //   1967: getfield i : Lt/h;
    //   1970: astore #21
    //   1972: aload #26
    //   1974: iload #14
    //   1976: aaload
    //   1977: getfield i : Lt/h;
    //   1980: astore #26
    //   1982: iconst_4
    //   1983: istore #15
    //   1985: goto -> 2035
    //   1988: fconst_1
    //   1989: fstore #4
    //   1991: fload #4
    //   1993: fconst_0
    //   1994: fcmpl
    //   1995: istore #15
    //   1997: iload #15
    //   1999: ifne -> 2055
    //   2002: aload #26
    //   2004: getfield L : [Lu/c;
    //   2007: astore #26
    //   2009: aload #26
    //   2011: iload #14
    //   2013: iconst_1
    //   2014: iadd
    //   2015: aaload
    //   2016: getfield i : Lt/h;
    //   2019: astore #21
    //   2021: aload #26
    //   2023: iload #14
    //   2025: aaload
    //   2026: getfield i : Lt/h;
    //   2029: astore #26
    //   2031: bipush #8
    //   2033: istore #15
    //   2035: aload #23
    //   2037: aload #21
    //   2039: aload #26
    //   2041: iconst_0
    //   2042: iload #15
    //   2044: invokevirtual d : (Lt/h;Lt/h;II)Lt/b;
    //   2047: pop
    //   2048: fload #6
    //   2050: fstore #4
    //   2052: goto -> 2371
    //   2055: aload #31
    //   2057: ifnull -> 2367
    //   2060: aload #31
    //   2062: getfield L : [Lu/c;
    //   2065: astore #31
    //   2067: aload #31
    //   2069: iload #14
    //   2071: aaload
    //   2072: getfield i : Lt/h;
    //   2075: astore #21
    //   2077: iload #14
    //   2079: iconst_1
    //   2080: iadd
    //   2081: istore #17
    //   2083: aload #31
    //   2085: iload #17
    //   2087: aaload
    //   2088: getfield i : Lt/h;
    //   2091: astore #35
    //   2093: aload #26
    //   2095: getfield L : [Lu/c;
    //   2098: astore #32
    //   2100: aload #32
    //   2102: iload #14
    //   2104: aaload
    //   2105: getfield i : Lt/h;
    //   2108: astore #31
    //   2110: aload #32
    //   2112: iload #17
    //   2114: aaload
    //   2115: getfield i : Lt/h;
    //   2118: astore #36
    //   2120: aload_1
    //   2121: invokevirtual m : ()Lt/b;
    //   2124: astore #32
    //   2126: aload #32
    //   2128: fconst_0
    //   2129: putfield b : F
    //   2132: ldc -1.0
    //   2134: fstore #7
    //   2136: fload #5
    //   2138: fconst_0
    //   2139: fcmpl
    //   2140: ifeq -> 2295
    //   2143: fload #6
    //   2145: fload #4
    //   2147: fcmpl
    //   2148: ifne -> 2154
    //   2151: goto -> 2295
    //   2154: fload #6
    //   2156: fconst_0
    //   2157: fcmpl
    //   2158: ifne -> 2191
    //   2161: aload #32
    //   2163: getfield d : Lt/b$a;
    //   2166: aload #21
    //   2168: fconst_1
    //   2169: invokeinterface d : (Lt/h;F)V
    //   2174: aload #32
    //   2176: getfield d : Lt/b$a;
    //   2179: aload #35
    //   2181: ldc -1.0
    //   2183: invokeinterface d : (Lt/h;F)V
    //   2188: goto -> 2357
    //   2191: iload #15
    //   2193: ifne -> 2226
    //   2196: aload #32
    //   2198: getfield d : Lt/b$a;
    //   2201: aload #31
    //   2203: fconst_1
    //   2204: invokeinterface d : (Lt/h;F)V
    //   2209: aload #32
    //   2211: getfield d : Lt/b$a;
    //   2214: aload #36
    //   2216: ldc -1.0
    //   2218: invokeinterface d : (Lt/h;F)V
    //   2223: goto -> 2357
    //   2226: fload #6
    //   2228: fload #5
    //   2230: fdiv
    //   2231: fload #4
    //   2233: fload #5
    //   2235: fdiv
    //   2236: fdiv
    //   2237: fstore #6
    //   2239: aload #32
    //   2241: getfield d : Lt/b$a;
    //   2244: aload #21
    //   2246: fconst_1
    //   2247: invokeinterface d : (Lt/h;F)V
    //   2252: aload #32
    //   2254: getfield d : Lt/b$a;
    //   2257: aload #35
    //   2259: ldc -1.0
    //   2261: invokeinterface d : (Lt/h;F)V
    //   2266: aload #32
    //   2268: getfield d : Lt/b$a;
    //   2271: aload #36
    //   2273: fload #6
    //   2275: invokeinterface d : (Lt/h;F)V
    //   2280: aload #32
    //   2282: getfield d : Lt/b$a;
    //   2285: astore #21
    //   2287: fload #6
    //   2289: fneg
    //   2290: fstore #6
    //   2292: goto -> 2346
    //   2295: aload #32
    //   2297: getfield d : Lt/b$a;
    //   2300: aload #21
    //   2302: fconst_1
    //   2303: invokeinterface d : (Lt/h;F)V
    //   2308: aload #32
    //   2310: getfield d : Lt/b$a;
    //   2313: aload #35
    //   2315: ldc -1.0
    //   2317: invokeinterface d : (Lt/h;F)V
    //   2322: aload #32
    //   2324: getfield d : Lt/b$a;
    //   2327: aload #36
    //   2329: fconst_1
    //   2330: invokeinterface d : (Lt/h;F)V
    //   2335: aload #32
    //   2337: getfield d : Lt/b$a;
    //   2340: astore #21
    //   2342: fload #7
    //   2344: fstore #6
    //   2346: aload #21
    //   2348: aload #31
    //   2350: fload #6
    //   2352: invokeinterface d : (Lt/h;F)V
    //   2357: aload #23
    //   2359: aload #32
    //   2361: invokevirtual c : (Lt/b;)V
    //   2364: goto -> 2367
    //   2367: aload #26
    //   2369: astore #31
    //   2371: iload #10
    //   2373: iconst_1
    //   2374: iadd
    //   2375: istore #10
    //   2377: fload #4
    //   2379: fstore #6
    //   2381: goto -> 1898
    //   2384: aload #29
    //   2386: ifnull -> 2578
    //   2389: aload #29
    //   2391: aload #30
    //   2393: if_acmpeq -> 2401
    //   2396: iload #16
    //   2398: ifeq -> 2578
    //   2401: aload #34
    //   2403: getfield L : [Lu/c;
    //   2406: iload #14
    //   2408: aaload
    //   2409: astore #22
    //   2411: aload #21
    //   2413: getfield L : [Lu/c;
    //   2416: astore #23
    //   2418: iload #14
    //   2420: iconst_1
    //   2421: iadd
    //   2422: istore #9
    //   2424: aload #23
    //   2426: iload #9
    //   2428: aaload
    //   2429: astore #23
    //   2431: aload #22
    //   2433: getfield f : Lu/c;
    //   2436: astore #22
    //   2438: aload #22
    //   2440: ifnull -> 2453
    //   2443: aload #22
    //   2445: getfield i : Lt/h;
    //   2448: astore #22
    //   2450: goto -> 2456
    //   2453: aconst_null
    //   2454: astore #22
    //   2456: aload #23
    //   2458: getfield f : Lu/c;
    //   2461: astore #23
    //   2463: aload #23
    //   2465: ifnull -> 2478
    //   2468: aload #23
    //   2470: getfield i : Lt/h;
    //   2473: astore #23
    //   2475: goto -> 2481
    //   2478: aconst_null
    //   2479: astore #23
    //   2481: aload #29
    //   2483: getfield L : [Lu/c;
    //   2486: iload #14
    //   2488: aaload
    //   2489: astore #24
    //   2491: aload #30
    //   2493: getfield L : [Lu/c;
    //   2496: iload #9
    //   2498: aaload
    //   2499: astore #26
    //   2501: aload #22
    //   2503: ifnull -> 2575
    //   2506: aload #23
    //   2508: ifnull -> 2575
    //   2511: iload_3
    //   2512: ifne -> 2525
    //   2515: aload #25
    //   2517: getfield Z : F
    //   2520: fstore #4
    //   2522: goto -> 2532
    //   2525: aload #25
    //   2527: getfield a0 : F
    //   2530: fstore #4
    //   2532: aload #24
    //   2534: invokevirtual d : ()I
    //   2537: istore #9
    //   2539: aload #26
    //   2541: invokevirtual d : ()I
    //   2544: istore #10
    //   2546: aload_1
    //   2547: aload #24
    //   2549: getfield i : Lt/h;
    //   2552: aload #22
    //   2554: iload #9
    //   2556: fload #4
    //   2558: aload #23
    //   2560: aload #26
    //   2562: getfield i : Lt/h;
    //   2565: iload #10
    //   2567: bipush #7
    //   2569: invokevirtual b : (Lt/h;Lt/h;IFLt/h;Lt/h;II)V
    //   2572: goto -> 3672
    //   2575: goto -> 3672
    //   2578: aload #30
    //   2580: astore #35
    //   2582: aload #29
    //   2584: astore #23
    //   2586: aload #21
    //   2588: astore #36
    //   2590: iload #13
    //   2592: ifeq -> 3112
    //   2595: aload #23
    //   2597: ifnull -> 3112
    //   2600: aload #32
    //   2602: getfield j : I
    //   2605: istore #9
    //   2607: iload #9
    //   2609: ifle -> 2628
    //   2612: aload #32
    //   2614: getfield i : I
    //   2617: iload #9
    //   2619: if_icmpne -> 2628
    //   2622: iconst_1
    //   2623: istore #15
    //   2625: goto -> 2631
    //   2628: iconst_0
    //   2629: istore #15
    //   2631: aload #23
    //   2633: astore #22
    //   2635: aload #22
    //   2637: astore #25
    //   2639: aload #25
    //   2641: ifnull -> 3672
    //   2644: aload #25
    //   2646: getfield i0 : [Lu/d;
    //   2649: iload_3
    //   2650: aaload
    //   2651: astore #24
    //   2653: aload #24
    //   2655: ifnull -> 2680
    //   2658: aload #24
    //   2660: getfield c0 : I
    //   2663: bipush #8
    //   2665: if_icmpne -> 2680
    //   2668: aload #24
    //   2670: getfield i0 : [Lu/d;
    //   2673: iload_3
    //   2674: aaload
    //   2675: astore #24
    //   2677: goto -> 2653
    //   2680: aload #24
    //   2682: ifnonnull -> 2698
    //   2685: aload #25
    //   2687: aload #35
    //   2689: if_acmpne -> 2695
    //   2692: goto -> 2698
    //   2695: goto -> 3088
    //   2698: aload #25
    //   2700: getfield L : [Lu/c;
    //   2703: iload #14
    //   2705: aaload
    //   2706: astore #31
    //   2708: aload #31
    //   2710: getfield i : Lt/h;
    //   2713: astore #38
    //   2715: aload #31
    //   2717: getfield f : Lu/c;
    //   2720: astore #26
    //   2722: aload #26
    //   2724: ifnull -> 2737
    //   2727: aload #26
    //   2729: getfield i : Lt/h;
    //   2732: astore #27
    //   2734: goto -> 2740
    //   2737: aconst_null
    //   2738: astore #27
    //   2740: aload #22
    //   2742: aload #25
    //   2744: if_acmpeq -> 2762
    //   2747: aload #22
    //   2749: getfield L : [Lu/c;
    //   2752: iload #14
    //   2754: iconst_1
    //   2755: iadd
    //   2756: aaload
    //   2757: astore #26
    //   2759: goto -> 2812
    //   2762: aload #27
    //   2764: astore #26
    //   2766: aload #25
    //   2768: aload #23
    //   2770: if_acmpne -> 2825
    //   2773: aload #27
    //   2775: astore #26
    //   2777: aload #22
    //   2779: aload #25
    //   2781: if_acmpne -> 2825
    //   2784: aload #34
    //   2786: getfield L : [Lu/c;
    //   2789: astore #26
    //   2791: aload #26
    //   2793: iload #14
    //   2795: aaload
    //   2796: getfield f : Lu/c;
    //   2799: ifnull -> 2822
    //   2802: aload #26
    //   2804: iload #14
    //   2806: aaload
    //   2807: getfield f : Lu/c;
    //   2810: astore #26
    //   2812: aload #26
    //   2814: getfield i : Lt/h;
    //   2817: astore #26
    //   2819: goto -> 2825
    //   2822: aconst_null
    //   2823: astore #26
    //   2825: aload #31
    //   2827: invokevirtual d : ()I
    //   2830: istore #16
    //   2832: aload #25
    //   2834: getfield L : [Lu/c;
    //   2837: astore #27
    //   2839: iload #14
    //   2841: iconst_1
    //   2842: iadd
    //   2843: istore #17
    //   2845: aload #27
    //   2847: iload #17
    //   2849: aaload
    //   2850: invokevirtual d : ()I
    //   2853: istore #10
    //   2855: aload #24
    //   2857: ifnull -> 2890
    //   2860: aload #24
    //   2862: getfield L : [Lu/c;
    //   2865: iload #14
    //   2867: aaload
    //   2868: astore #27
    //   2870: aload #27
    //   2872: getfield i : Lt/h;
    //   2875: astore #31
    //   2877: aload #25
    //   2879: getfield L : [Lu/c;
    //   2882: iload #17
    //   2884: aaload
    //   2885: astore #32
    //   2887: goto -> 2939
    //   2890: aload #36
    //   2892: getfield L : [Lu/c;
    //   2895: iload #17
    //   2897: aaload
    //   2898: getfield f : Lu/c;
    //   2901: astore #37
    //   2903: aload #37
    //   2905: ifnull -> 2918
    //   2908: aload #37
    //   2910: getfield i : Lt/h;
    //   2913: astore #27
    //   2915: goto -> 2921
    //   2918: aconst_null
    //   2919: astore #27
    //   2921: aload #25
    //   2923: getfield L : [Lu/c;
    //   2926: iload #17
    //   2928: aaload
    //   2929: astore #32
    //   2931: aload #27
    //   2933: astore #31
    //   2935: aload #37
    //   2937: astore #27
    //   2939: aload #32
    //   2941: getfield i : Lt/h;
    //   2944: astore #32
    //   2946: iload #10
    //   2948: istore #9
    //   2950: aload #27
    //   2952: ifnull -> 2965
    //   2955: iload #10
    //   2957: aload #27
    //   2959: invokevirtual d : ()I
    //   2962: iadd
    //   2963: istore #9
    //   2965: iload #16
    //   2967: istore #10
    //   2969: aload #22
    //   2971: ifnull -> 2990
    //   2974: iload #16
    //   2976: aload #22
    //   2978: getfield L : [Lu/c;
    //   2981: iload #17
    //   2983: aaload
    //   2984: invokevirtual d : ()I
    //   2987: iadd
    //   2988: istore #10
    //   2990: aload #38
    //   2992: ifnull -> 2695
    //   2995: aload #26
    //   2997: ifnull -> 2695
    //   3000: aload #31
    //   3002: ifnull -> 2695
    //   3005: aload #32
    //   3007: ifnull -> 2695
    //   3010: aload #25
    //   3012: aload #23
    //   3014: if_acmpne -> 3030
    //   3017: aload #23
    //   3019: getfield L : [Lu/c;
    //   3022: iload #14
    //   3024: aaload
    //   3025: invokevirtual d : ()I
    //   3028: istore #10
    //   3030: aload #25
    //   3032: aload #35
    //   3034: if_acmpne -> 3053
    //   3037: aload #35
    //   3039: getfield L : [Lu/c;
    //   3042: iload #17
    //   3044: aaload
    //   3045: invokevirtual d : ()I
    //   3048: istore #9
    //   3050: goto -> 3053
    //   3053: iload #15
    //   3055: ifeq -> 3065
    //   3058: bipush #8
    //   3060: istore #16
    //   3062: goto -> 3068
    //   3065: iconst_5
    //   3066: istore #16
    //   3068: aload_1
    //   3069: aload #38
    //   3071: aload #26
    //   3073: iload #10
    //   3075: ldc 0.5
    //   3077: aload #31
    //   3079: aload #32
    //   3081: iload #9
    //   3083: iload #16
    //   3085: invokevirtual b : (Lt/h;Lt/h;IFLt/h;Lt/h;II)V
    //   3088: aload #25
    //   3090: getfield c0 : I
    //   3093: bipush #8
    //   3095: if_icmpeq -> 3105
    //   3098: aload #25
    //   3100: astore #22
    //   3102: goto -> 3105
    //   3105: aload #24
    //   3107: astore #25
    //   3109: goto -> 2639
    //   3112: iload #12
    //   3114: ifeq -> 3672
    //   3117: aload #23
    //   3119: ifnull -> 3672
    //   3122: aload #32
    //   3124: getfield j : I
    //   3127: istore #9
    //   3129: iload #9
    //   3131: ifle -> 3150
    //   3134: aload #32
    //   3136: getfield i : I
    //   3139: iload #9
    //   3141: if_icmpne -> 3150
    //   3144: iconst_1
    //   3145: istore #9
    //   3147: goto -> 3153
    //   3150: iconst_0
    //   3151: istore #9
    //   3153: aload #23
    //   3155: astore #24
    //   3157: aload #24
    //   3159: astore #27
    //   3161: aload #24
    //   3163: ifnull -> 3498
    //   3166: aload #24
    //   3168: getfield i0 : [Lu/d;
    //   3171: iload_3
    //   3172: aaload
    //   3173: astore #22
    //   3175: aload #22
    //   3177: ifnull -> 3202
    //   3180: aload #22
    //   3182: getfield c0 : I
    //   3185: bipush #8
    //   3187: if_icmpne -> 3202
    //   3190: aload #22
    //   3192: getfield i0 : [Lu/d;
    //   3195: iload_3
    //   3196: aaload
    //   3197: astore #22
    //   3199: goto -> 3175
    //   3202: aload #24
    //   3204: aload #23
    //   3206: if_acmpeq -> 3477
    //   3209: aload #24
    //   3211: aload #35
    //   3213: if_acmpeq -> 3477
    //   3216: aload #22
    //   3218: ifnull -> 3477
    //   3221: aload #22
    //   3223: aload #35
    //   3225: if_acmpne -> 3234
    //   3228: aconst_null
    //   3229: astore #22
    //   3231: goto -> 3234
    //   3234: aload #24
    //   3236: getfield L : [Lu/c;
    //   3239: iload #14
    //   3241: aaload
    //   3242: astore #25
    //   3244: aload #25
    //   3246: getfield i : Lt/h;
    //   3249: astore #32
    //   3251: aload #27
    //   3253: getfield L : [Lu/c;
    //   3256: astore #26
    //   3258: iload #14
    //   3260: iconst_1
    //   3261: iadd
    //   3262: istore #15
    //   3264: aload #26
    //   3266: iload #15
    //   3268: aaload
    //   3269: getfield i : Lt/h;
    //   3272: astore #37
    //   3274: aload #25
    //   3276: invokevirtual d : ()I
    //   3279: istore #16
    //   3281: aload #24
    //   3283: getfield L : [Lu/c;
    //   3286: iload #15
    //   3288: aaload
    //   3289: invokevirtual d : ()I
    //   3292: istore #10
    //   3294: aload #22
    //   3296: ifnull -> 3337
    //   3299: aload #22
    //   3301: getfield L : [Lu/c;
    //   3304: iload #14
    //   3306: aaload
    //   3307: astore #25
    //   3309: aload #25
    //   3311: getfield i : Lt/h;
    //   3314: astore #26
    //   3316: aload #25
    //   3318: getfield f : Lu/c;
    //   3321: astore #31
    //   3323: aload #31
    //   3325: ifnull -> 3331
    //   3328: goto -> 3375
    //   3331: aconst_null
    //   3332: astore #31
    //   3334: goto -> 3382
    //   3337: aload #35
    //   3339: getfield L : [Lu/c;
    //   3342: iload #14
    //   3344: aaload
    //   3345: astore #25
    //   3347: aload #25
    //   3349: ifnull -> 3362
    //   3352: aload #25
    //   3354: getfield i : Lt/h;
    //   3357: astore #26
    //   3359: goto -> 3365
    //   3362: aconst_null
    //   3363: astore #26
    //   3365: aload #24
    //   3367: getfield L : [Lu/c;
    //   3370: iload #15
    //   3372: aaload
    //   3373: astore #31
    //   3375: aload #31
    //   3377: getfield i : Lt/h;
    //   3380: astore #31
    //   3382: aload #25
    //   3384: ifnull -> 3400
    //   3387: aload #25
    //   3389: invokevirtual d : ()I
    //   3392: iload #10
    //   3394: iadd
    //   3395: istore #10
    //   3397: goto -> 3400
    //   3400: aload #27
    //   3402: getfield L : [Lu/c;
    //   3405: iload #15
    //   3407: aaload
    //   3408: invokevirtual d : ()I
    //   3411: istore #17
    //   3413: iload #9
    //   3415: ifeq -> 3425
    //   3418: bipush #8
    //   3420: istore #15
    //   3422: goto -> 3428
    //   3425: iconst_4
    //   3426: istore #15
    //   3428: aload #32
    //   3430: ifnull -> 3474
    //   3433: aload #37
    //   3435: ifnull -> 3474
    //   3438: aload #26
    //   3440: ifnull -> 3474
    //   3443: aload #31
    //   3445: ifnull -> 3474
    //   3448: aload_1
    //   3449: aload #32
    //   3451: aload #37
    //   3453: iload #17
    //   3455: iload #16
    //   3457: iadd
    //   3458: ldc 0.5
    //   3460: aload #26
    //   3462: aload #31
    //   3464: iload #10
    //   3466: iload #15
    //   3468: invokevirtual b : (Lt/h;Lt/h;IFLt/h;Lt/h;II)V
    //   3471: goto -> 3474
    //   3474: goto -> 3477
    //   3477: aload #24
    //   3479: getfield c0 : I
    //   3482: bipush #8
    //   3484: if_icmpeq -> 3491
    //   3487: aload #24
    //   3489: astore #27
    //   3491: aload #22
    //   3493: astore #24
    //   3495: goto -> 3161
    //   3498: aload #23
    //   3500: getfield L : [Lu/c;
    //   3503: iload #14
    //   3505: aaload
    //   3506: astore #22
    //   3508: aload #34
    //   3510: getfield L : [Lu/c;
    //   3513: iload #14
    //   3515: aaload
    //   3516: getfield f : Lu/c;
    //   3519: astore #24
    //   3521: aload #35
    //   3523: getfield L : [Lu/c;
    //   3526: astore #25
    //   3528: iload #14
    //   3530: iconst_1
    //   3531: iadd
    //   3532: istore #9
    //   3534: aload #25
    //   3536: iload #9
    //   3538: aaload
    //   3539: astore #25
    //   3541: aload #36
    //   3543: getfield L : [Lu/c;
    //   3546: iload #9
    //   3548: aaload
    //   3549: getfield f : Lu/c;
    //   3552: astore #26
    //   3554: aload #24
    //   3556: ifnull -> 3635
    //   3559: aload #23
    //   3561: aload #35
    //   3563: if_acmpeq -> 3590
    //   3566: aload_1
    //   3567: aload #22
    //   3569: getfield i : Lt/h;
    //   3572: aload #24
    //   3574: getfield i : Lt/h;
    //   3577: aload #22
    //   3579: invokevirtual d : ()I
    //   3582: iconst_5
    //   3583: invokevirtual d : (Lt/h;Lt/h;II)Lt/b;
    //   3586: pop
    //   3587: goto -> 3635
    //   3590: aload #26
    //   3592: ifnull -> 3635
    //   3595: aload_1
    //   3596: aload #22
    //   3598: getfield i : Lt/h;
    //   3601: aload #24
    //   3603: getfield i : Lt/h;
    //   3606: aload #22
    //   3608: invokevirtual d : ()I
    //   3611: ldc 0.5
    //   3613: aload #25
    //   3615: getfield i : Lt/h;
    //   3618: aload #26
    //   3620: getfield i : Lt/h;
    //   3623: aload #25
    //   3625: invokevirtual d : ()I
    //   3628: iconst_5
    //   3629: invokevirtual b : (Lt/h;Lt/h;IFLt/h;Lt/h;II)V
    //   3632: goto -> 3635
    //   3635: aload #26
    //   3637: ifnull -> 3672
    //   3640: aload #23
    //   3642: aload #35
    //   3644: if_acmpeq -> 3672
    //   3647: aload_1
    //   3648: aload #25
    //   3650: getfield i : Lt/h;
    //   3653: aload #26
    //   3655: getfield i : Lt/h;
    //   3658: aload #25
    //   3660: invokevirtual d : ()I
    //   3663: ineg
    //   3664: iconst_5
    //   3665: invokevirtual d : (Lt/h;Lt/h;II)Lt/b;
    //   3668: pop
    //   3669: goto -> 3672
    //   3672: iload #8
    //   3674: istore #9
    //   3676: aload_1
    //   3677: astore #23
    //   3679: aload #21
    //   3681: astore #31
    //   3683: iload #13
    //   3685: ifne -> 3709
    //   3688: aload #23
    //   3690: astore #21
    //   3692: iload #9
    //   3694: istore #10
    //   3696: iload #11
    //   3698: istore #8
    //   3700: aload #28
    //   3702: astore #22
    //   3704: iload #12
    //   3706: ifeq -> 4005
    //   3709: aload #23
    //   3711: astore #21
    //   3713: iload #9
    //   3715: istore #10
    //   3717: iload #11
    //   3719: istore #8
    //   3721: aload #28
    //   3723: astore #22
    //   3725: aload #29
    //   3727: ifnull -> 4005
    //   3730: aload #23
    //   3732: astore #21
    //   3734: iload #9
    //   3736: istore #10
    //   3738: iload #11
    //   3740: istore #8
    //   3742: aload #28
    //   3744: astore #22
    //   3746: aload #29
    //   3748: aload #30
    //   3750: if_acmpeq -> 4005
    //   3753: aload #29
    //   3755: getfield L : [Lu/c;
    //   3758: astore #22
    //   3760: aload #22
    //   3762: iload #14
    //   3764: aaload
    //   3765: astore #26
    //   3767: aload #30
    //   3769: getfield L : [Lu/c;
    //   3772: astore #21
    //   3774: iload #14
    //   3776: iconst_1
    //   3777: iadd
    //   3778: istore #12
    //   3780: aload #21
    //   3782: iload #12
    //   3784: aaload
    //   3785: astore #27
    //   3787: aload #26
    //   3789: getfield f : Lu/c;
    //   3792: astore #21
    //   3794: aload #21
    //   3796: ifnull -> 3809
    //   3799: aload #21
    //   3801: getfield i : Lt/h;
    //   3804: astore #24
    //   3806: goto -> 3812
    //   3809: aconst_null
    //   3810: astore #24
    //   3812: aload #27
    //   3814: getfield f : Lu/c;
    //   3817: astore #21
    //   3819: aload #21
    //   3821: ifnull -> 3834
    //   3824: aload #21
    //   3826: getfield i : Lt/h;
    //   3829: astore #21
    //   3831: goto -> 3837
    //   3834: aconst_null
    //   3835: astore #21
    //   3837: aload #21
    //   3839: astore #25
    //   3841: aload #31
    //   3843: aload #30
    //   3845: if_acmpeq -> 3881
    //   3848: aload #31
    //   3850: getfield L : [Lu/c;
    //   3853: iload #12
    //   3855: aaload
    //   3856: getfield f : Lu/c;
    //   3859: astore #25
    //   3861: aload #33
    //   3863: astore #21
    //   3865: aload #25
    //   3867: ifnull -> 3877
    //   3870: aload #25
    //   3872: getfield i : Lt/h;
    //   3875: astore #21
    //   3877: aload #21
    //   3879: astore #25
    //   3881: aload #29
    //   3883: aload #30
    //   3885: if_acmpne -> 3902
    //   3888: aload #22
    //   3890: iload #14
    //   3892: aaload
    //   3893: astore #26
    //   3895: aload #22
    //   3897: iload #12
    //   3899: aaload
    //   3900: astore #27
    //   3902: aload #23
    //   3904: astore #21
    //   3906: iload #9
    //   3908: istore #10
    //   3910: iload #11
    //   3912: istore #8
    //   3914: aload #28
    //   3916: astore #22
    //   3918: aload #24
    //   3920: ifnull -> 4005
    //   3923: aload #23
    //   3925: astore #21
    //   3927: iload #9
    //   3929: istore #10
    //   3931: iload #11
    //   3933: istore #8
    //   3935: aload #28
    //   3937: astore #22
    //   3939: aload #25
    //   3941: ifnull -> 4005
    //   3944: aload #26
    //   3946: invokevirtual d : ()I
    //   3949: istore #8
    //   3951: aload #30
    //   3953: getfield L : [Lu/c;
    //   3956: iload #12
    //   3958: aaload
    //   3959: invokevirtual d : ()I
    //   3962: istore #10
    //   3964: aload_1
    //   3965: aload #26
    //   3967: getfield i : Lt/h;
    //   3970: aload #24
    //   3972: iload #8
    //   3974: ldc 0.5
    //   3976: aload #25
    //   3978: aload #27
    //   3980: getfield i : Lt/h;
    //   3983: iload #10
    //   3985: iconst_5
    //   3986: invokevirtual b : (Lt/h;Lt/h;IFLt/h;Lt/h;II)V
    //   3989: aload #28
    //   3991: astore #22
    //   3993: iload #11
    //   3995: istore #8
    //   3997: iload #9
    //   3999: istore #10
    //   4001: aload #23
    //   4003: astore #21
    //   4005: iload #10
    //   4007: iconst_1
    //   4008: iadd
    //   4009: istore #10
    //   4011: iload #8
    //   4013: istore #9
    //   4015: iload #10
    //   4017: istore #8
    //   4019: aload #21
    //   4021: astore #23
    //   4023: aload #22
    //   4025: astore #21
    //   4027: goto -> 50
    //   4030: return
  }
  
  public static String b(byte[] paramArrayOfbyte) {
    int i = paramArrayOfbyte.length;
    char[] arrayOfChar = new char[i + i];
    i = 0;
    int j = 0;
    while (i < paramArrayOfbyte.length) {
      int k = paramArrayOfbyte[i] & 0xFF;
      int m = j + 1;
      char[] arrayOfChar1 = h;
      arrayOfChar[j] = arrayOfChar1[k >>> 4];
      j = m + 1;
      arrayOfChar[m] = arrayOfChar1[k & 0xF];
      i++;
    } 
    return new String(arrayOfChar);
  }
  
  public static byte[] c(String paramString) {
    int i = paramString.length();
    if (i % 2 == 0) {
      byte[] arrayOfByte = new byte[i / 2];
      for (int j = 0; j < i; j = k) {
        int k = j + 2;
        arrayOfByte[j / 2] = (byte)Integer.parseInt(paramString.substring(j, k), 16);
      } 
      return arrayOfByte;
    } 
    throw new IllegalArgumentException("Hex string has odd number of characters");
  }
  
  public void d(Object paramObject) {
    ((p)paramObject).Y2();
  }
}


/* Location:              C:\soft\dex2jar-2.0\Luxury Logo Maker_ Logo Design-dex2jar.jar!\a4\f.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */