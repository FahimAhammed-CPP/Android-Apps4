package a4;

import a2.d;
import a2.h;
import android.content.Context;
import android.util.Log;
import e4.aq0;
import e4.h61;
import e4.ne0;
import e4.qj2;
import e4.sr2;
import e4.ti0;
import e4.to0;
import e4.zk1;
import f3.i3;
import java.io.File;
import java.io.IOException;
import java.nio.ByteBuffer;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;
import r.c;
import v2.a;
import z2.f;

public class b implements aq0, d {
  public static final ne0 h = new ne0(0);
  
  public static final byte[] i = new byte[] { 0, 0, 0, 1 };
  
  public static final String[] j = new String[] { "", "A", "B", "C" };
  
  public static final ti0 l = new ti0(2);
  
  public static int b(sr2 paramsr2, qj2 paramqj2, int paramInt, boolean paramBoolean) {
    return paramsr2.d(paramqj2, paramInt, paramBoolean, 0);
  }
  
  public static i3 e(Context paramContext, List paramList) {
    ArrayList<f> arrayList = new ArrayList();
    for (zk1 zk1 : paramList) {
      if (zk1.c) {
        arrayList.add(f.o);
        continue;
      } 
      arrayList.add(new f(zk1.a, zk1.b));
    } 
    return new i3(paramContext, arrayList.<f>toArray(new f[arrayList.size()]));
  }
  
  public static String f(int paramInt1, int paramInt2, int paramInt3) {
    return String.format("avc1.%02X%02X%02X", new Object[] { Integer.valueOf(paramInt1), Integer.valueOf(paramInt2), Integer.valueOf(paramInt3) });
  }
  
  public static String g(int paramInt1, boolean paramBoolean, int paramInt2, int paramInt3, int[] paramArrayOfint, int paramInt4) {
    byte b1;
    String str = j[paramInt1];
    if (true != paramBoolean) {
      b1 = 76;
    } else {
      b1 = 72;
    } 
    StringBuilder stringBuilder = new StringBuilder(h61.c("hvc1.%s%d.%X.%c%d", new Object[] { str, Integer.valueOf(paramInt2), Integer.valueOf(paramInt3), Character.valueOf(b1), Integer.valueOf(paramInt4) }));
    paramInt1 = 6;
    while (paramInt1 > 0) {
      paramInt2 = paramInt1 - 1;
      if (paramArrayOfint[paramInt2] == 0)
        paramInt1 = paramInt2; 
    } 
    for (paramInt2 = 0; paramInt2 < paramInt1; paramInt2++) {
      stringBuilder.append(String.format(".%02X", new Object[] { Integer.valueOf(paramArrayOfint[paramInt2]) }));
    } 
    return stringBuilder.toString();
  }
  
  public static Set h(int paramInt, boolean paramBoolean) {
    float f;
    char c;
    if (true != paramBoolean) {
      f = 1.0F;
    } else {
      f = 0.75F;
    } 
    if (true != paramBoolean) {
      c = 'Ā';
    } else {
      c = '';
    } 
    return (Set)((paramInt <= c) ? new c(paramInt) : new HashSet(paramInt, f));
  }
  
  public static void i(Object paramObject, String paramString) {
    if (paramObject != null)
      return; 
    throw new IllegalArgumentException(paramString);
  }
  
  public static zk1 j(i3 parami3) {
    return parami3.p ? new zk1(-3, 0, true) : new zk1(parami3.l, parami3.i, false);
  }
  
  public boolean a(Object paramObject, File paramFile, h paramh) {
    paramObject = paramObject;
    try {
      a.d((ByteBuffer)paramObject, paramFile);
      return true;
    } catch (IOException iOException) {
      if (Log.isLoggable("ByteBufferEncoder", 3))
        Log.d("ByteBufferEncoder", "Failed to write data", iOException); 
      return false;
    } 
  }
  
  public void d(Object paramObject) {
    ((to0)paramObject).e();
  }
}


/* Location:              C:\soft\dex2jar-2.0\Luxury Logo Maker_ Logo Design-dex2jar.jar!\a4\b.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */