package a4;

import android.os.SystemClock;

public class d implements a {
  public static final d a = new d();
  
  public final long a() {
    return System.currentTimeMillis();
  }
  
  public final long b() {
    return SystemClock.elapsedRealtime();
  }
  
  public final long c() {
    return System.nanoTime();
  }
}


/* Location:              C:\soft\dex2jar-2.0\Luxury Logo Maker_ Logo Design-dex2jar.jar!\a4\d.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */