package c0;

import android.content.res.Resources;
import android.content.res.TypedArray;
import android.util.Base64;
import android.util.Xml;
import h0.e;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import org.xmlpull.v1.XmlPullParser;
import org.xmlpull.v1.XmlPullParserException;

public class c {
  public static a a(XmlPullParser paramXmlPullParser, Resources paramResources) {
    int i;
    while (true) {
      i = paramXmlPullParser.next();
      if (i != 2 && i != 1)
        continue; 
      break;
    } 
    if (i == 2) {
      paramXmlPullParser.require(2, null, "font-family");
      if (paramXmlPullParser.getName().equals("font-family")) {
        TypedArray typedArray = paramResources.obtainAttributes(Xml.asAttributeSet(paramXmlPullParser), b2.b.b);
        String str1 = typedArray.getString(0);
        String str2 = typedArray.getString(4);
        String str3 = typedArray.getString(5);
        i = typedArray.getResourceId(1, 0);
        int j = typedArray.getInteger(2, 1);
        int k = typedArray.getInteger(3, 500);
        String str4 = typedArray.getString(6);
        typedArray.recycle();
        if (str1 != null && str2 != null && str3 != null) {
          while (paramXmlPullParser.next() != 3)
            c(paramXmlPullParser); 
          return new d(new e(str1, str2, str3, b(paramResources, i)), j, k, str4);
        } 
        ArrayList<c> arrayList = new ArrayList();
        while (paramXmlPullParser.next() != 3) {
          if (paramXmlPullParser.getEventType() != 2)
            continue; 
          if (paramXmlPullParser.getName().equals("font")) {
            boolean bool;
            TypedArray typedArray1 = paramResources.obtainAttributes(Xml.asAttributeSet(paramXmlPullParser), b2.b.c);
            i = 8;
            if (!typedArray1.hasValue(8))
              i = 1; 
            k = typedArray1.getInt(i, 400);
            if (typedArray1.hasValue(6)) {
              i = 6;
            } else {
              i = 2;
            } 
            if (1 == typedArray1.getInt(i, 0)) {
              bool = true;
            } else {
              bool = false;
            } 
            i = 9;
            if (!typedArray1.hasValue(9))
              i = 3; 
            j = 7;
            if (!typedArray1.hasValue(7))
              j = 4; 
            str2 = typedArray1.getString(j);
            j = typedArray1.getInt(i, 0);
            if (typedArray1.hasValue(5)) {
              i = 5;
            } else {
              i = 0;
            } 
            int m = typedArray1.getResourceId(i, 0);
            str3 = typedArray1.getString(i);
            typedArray1.recycle();
            while (paramXmlPullParser.next() != 3)
              c(paramXmlPullParser); 
            arrayList.add(new c(str3, k, bool, str2, j, m));
            continue;
          } 
          c(paramXmlPullParser);
        } 
        if (!arrayList.isEmpty())
          return new b(arrayList.<c>toArray(new c[arrayList.size()])); 
      } else {
        c(paramXmlPullParser);
      } 
      return null;
    } 
    throw new XmlPullParserException("No start tag found");
  }
  
  public static List<List<byte[]>> b(Resources paramResources, int paramInt) {
    if (paramInt == 0)
      return Collections.emptyList(); 
    TypedArray typedArray = paramResources.obtainTypedArray(paramInt);
    try {
      List<?> list;
      if (typedArray.length() == 0) {
        list = Collections.emptyList();
        return (List)list;
      } 
      ArrayList<List<byte[]>> arrayList = new ArrayList();
      if (typedArray.getType(0) == 1)
        for (paramInt = 0;; paramInt++) {
          if (paramInt < typedArray.length()) {
            int i = typedArray.getResourceId(paramInt, 0);
            if (i != 0)
              arrayList.add(d(list.getStringArray(i))); 
          } else {
            return arrayList;
          } 
        }  
      arrayList.add(d(list.getStringArray(paramInt)));
      return arrayList;
    } finally {
      typedArray.recycle();
    } 
  }
  
  public static void c(XmlPullParser paramXmlPullParser) {
    for (int i = 1; i; i++) {
      int j = paramXmlPullParser.next();
      if (j != 2) {
        if (j != 3)
          continue; 
        i--;
        continue;
      } 
    } 
  }
  
  public static List<byte[]> d(String[] paramArrayOfString) {
    ArrayList<byte[]> arrayList = new ArrayList();
    int j = paramArrayOfString.length;
    for (int i = 0; i < j; i++)
      arrayList.add(Base64.decode(paramArrayOfString[i], 0)); 
    return (List<byte[]>)arrayList;
  }
  
  public static interface a {}
  
  public static final class b implements a {
    public final c.c[] a;
    
    public b(c.c[] param1ArrayOfc) {
      this.a = param1ArrayOfc;
    }
  }
  
  public static final class c {
    public final String a;
    
    public int b;
    
    public boolean c;
    
    public String d;
    
    public int e;
    
    public int f;
    
    public c(String param1String1, int param1Int1, boolean param1Boolean, String param1String2, int param1Int2, int param1Int3) {
      this.a = param1String1;
      this.b = param1Int1;
      this.c = param1Boolean;
      this.d = param1String2;
      this.e = param1Int2;
      this.f = param1Int3;
    }
  }
  
  public static final class d implements a {
    public final e a;
    
    public final int b;
    
    public final int c;
    
    public final String d;
    
    public d(e param1e, int param1Int1, int param1Int2, String param1String) {
      this.a = param1e;
      this.c = param1Int1;
      this.b = param1Int2;
      this.d = param1String;
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Luxury Logo Maker_ Logo Design-dex2jar.jar!\c0\c.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */