package c0;

import android.content.Context;
import android.content.res.ColorStateList;
import android.content.res.Configuration;
import android.content.res.Resources;
import android.graphics.Typeface;
import android.os.Handler;
import android.os.Looper;
import android.util.SparseArray;
import android.util.TypedValue;
import java.util.Objects;
import java.util.WeakHashMap;

public final class e {
  public static final ThreadLocal<TypedValue> a = new ThreadLocal<TypedValue>();
  
  public static final WeakHashMap<b, SparseArray<a>> b = new WeakHashMap<b, SparseArray<a>>(0);
  
  public static final Object c = new Object();
  
  public static Typeface a(Context paramContext, int paramInt) {
    return paramContext.isRestricted() ? null : b(paramContext, paramInt, new TypedValue(), 0, null, null, false, false);
  }
  
  public static Typeface b(Context paramContext, int paramInt1, TypedValue paramTypedValue, int paramInt2, c paramc, Handler paramHandler, boolean paramBoolean1, boolean paramBoolean2) {
    // Byte code:
    //   0: aload_0
    //   1: invokevirtual getResources : ()Landroid/content/res/Resources;
    //   4: astore #9
    //   6: aload #9
    //   8: iload_1
    //   9: aload_2
    //   10: iconst_1
    //   11: invokevirtual getValue : (ILandroid/util/TypedValue;Z)V
    //   14: aload_2
    //   15: getfield string : Ljava/lang/CharSequence;
    //   18: astore #10
    //   20: aload #10
    //   22: ifnull -> 368
    //   25: aload #10
    //   27: invokeinterface toString : ()Ljava/lang/String;
    //   32: astore #11
    //   34: aload #11
    //   36: ldc 'res/'
    //   38: invokevirtual startsWith : (Ljava/lang/String;)Z
    //   41: istore #8
    //   43: aconst_null
    //   44: astore #10
    //   46: iload #8
    //   48: ifne -> 62
    //   51: aload #10
    //   53: astore_0
    //   54: aload #4
    //   56: ifnull -> 316
    //   59: goto -> 304
    //   62: getstatic d0/e.b : Lr/e;
    //   65: aload #9
    //   67: iload_1
    //   68: iload_3
    //   69: invokestatic c : (Landroid/content/res/Resources;II)Ljava/lang/String;
    //   72: invokevirtual a : (Ljava/lang/Object;)Ljava/lang/Object;
    //   75: checkcast android/graphics/Typeface
    //   78: astore_2
    //   79: aload_2
    //   80: ifnull -> 103
    //   83: aload_2
    //   84: astore_0
    //   85: aload #4
    //   87: ifnull -> 100
    //   90: aload #4
    //   92: aload_2
    //   93: aload #5
    //   95: invokevirtual b : (Landroid/graphics/Typeface;Landroid/os/Handler;)V
    //   98: aload_2
    //   99: astore_0
    //   100: goto -> 316
    //   103: iload #7
    //   105: ifeq -> 114
    //   108: aload #10
    //   110: astore_0
    //   111: goto -> 316
    //   114: aload #11
    //   116: invokevirtual toLowerCase : ()Ljava/lang/String;
    //   119: ldc '.xml'
    //   121: invokevirtual endsWith : (Ljava/lang/String;)Z
    //   124: ifeq -> 193
    //   127: aload #9
    //   129: iload_1
    //   130: invokevirtual getXml : (I)Landroid/content/res/XmlResourceParser;
    //   133: aload #9
    //   135: invokestatic a : (Lorg/xmlpull/v1/XmlPullParser;Landroid/content/res/Resources;)Lc0/c$a;
    //   138: astore_2
    //   139: aload_2
    //   140: ifnonnull -> 174
    //   143: ldc 'ResourcesCompat'
    //   145: ldc 'Failed to find font-family tag'
    //   147: invokestatic e : (Ljava/lang/String;Ljava/lang/String;)I
    //   150: pop
    //   151: aload #10
    //   153: astore_0
    //   154: aload #4
    //   156: ifnull -> 316
    //   159: aload #4
    //   161: bipush #-3
    //   163: aload #5
    //   165: invokevirtual a : (ILandroid/os/Handler;)V
    //   168: aload #10
    //   170: astore_0
    //   171: goto -> 316
    //   174: aload_0
    //   175: aload_2
    //   176: aload #9
    //   178: iload_1
    //   179: iload_3
    //   180: aload #4
    //   182: aload #5
    //   184: iload #6
    //   186: invokestatic a : (Landroid/content/Context;Lc0/c$a;Landroid/content/res/Resources;IILc0/e$c;Landroid/os/Handler;Z)Landroid/graphics/Typeface;
    //   189: astore_0
    //   190: goto -> 316
    //   193: aload_0
    //   194: aload #9
    //   196: iload_1
    //   197: aload #11
    //   199: iload_3
    //   200: invokestatic b : (Landroid/content/Context;Landroid/content/res/Resources;ILjava/lang/String;I)Landroid/graphics/Typeface;
    //   203: astore_2
    //   204: aload_2
    //   205: astore_0
    //   206: aload #4
    //   208: ifnull -> 100
    //   211: aload_2
    //   212: ifnull -> 228
    //   215: aload #4
    //   217: aload_2
    //   218: aload #5
    //   220: invokevirtual b : (Landroid/graphics/Typeface;Landroid/os/Handler;)V
    //   223: aload_2
    //   224: astore_0
    //   225: goto -> 100
    //   228: aload #4
    //   230: bipush #-3
    //   232: aload #5
    //   234: invokevirtual a : (ILandroid/os/Handler;)V
    //   237: aload_2
    //   238: astore_0
    //   239: goto -> 100
    //   242: astore_0
    //   243: new java/lang/StringBuilder
    //   246: dup
    //   247: invokespecial <init> : ()V
    //   250: astore_2
    //   251: ldc 'Failed to read xml resource '
    //   253: astore #9
    //   255: goto -> 271
    //   258: astore_0
    //   259: new java/lang/StringBuilder
    //   262: dup
    //   263: invokespecial <init> : ()V
    //   266: astore_2
    //   267: ldc 'Failed to parse xml resource '
    //   269: astore #9
    //   271: aload_2
    //   272: aload #9
    //   274: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   277: pop
    //   278: aload_2
    //   279: aload #11
    //   281: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   284: pop
    //   285: ldc 'ResourcesCompat'
    //   287: aload_2
    //   288: invokevirtual toString : ()Ljava/lang/String;
    //   291: aload_0
    //   292: invokestatic e : (Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)I
    //   295: pop
    //   296: aload #10
    //   298: astore_0
    //   299: aload #4
    //   301: ifnull -> 316
    //   304: aload #4
    //   306: bipush #-3
    //   308: aload #5
    //   310: invokevirtual a : (ILandroid/os/Handler;)V
    //   313: aload #10
    //   315: astore_0
    //   316: aload_0
    //   317: ifnonnull -> 366
    //   320: aload #4
    //   322: ifnonnull -> 366
    //   325: iload #7
    //   327: ifeq -> 332
    //   330: aload_0
    //   331: areturn
    //   332: ldc 'Font resource ID #0x'
    //   334: invokestatic a : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   337: astore_0
    //   338: aload_0
    //   339: iload_1
    //   340: invokestatic toHexString : (I)Ljava/lang/String;
    //   343: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   346: pop
    //   347: aload_0
    //   348: ldc ' could not be retrieved.'
    //   350: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   353: pop
    //   354: new android/content/res/Resources$NotFoundException
    //   357: dup
    //   358: aload_0
    //   359: invokevirtual toString : ()Ljava/lang/String;
    //   362: invokespecial <init> : (Ljava/lang/String;)V
    //   365: athrow
    //   366: aload_0
    //   367: areturn
    //   368: ldc 'Resource "'
    //   370: invokestatic a : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   373: astore_0
    //   374: aload_0
    //   375: aload #9
    //   377: iload_1
    //   378: invokevirtual getResourceName : (I)Ljava/lang/String;
    //   381: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   384: pop
    //   385: aload_0
    //   386: ldc '" ('
    //   388: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   391: pop
    //   392: aload_0
    //   393: iload_1
    //   394: invokestatic toHexString : (I)Ljava/lang/String;
    //   397: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   400: pop
    //   401: aload_0
    //   402: ldc ') is not a Font: '
    //   404: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   407: pop
    //   408: aload_0
    //   409: aload_2
    //   410: invokevirtual append : (Ljava/lang/Object;)Ljava/lang/StringBuilder;
    //   413: pop
    //   414: new android/content/res/Resources$NotFoundException
    //   417: dup
    //   418: aload_0
    //   419: invokevirtual toString : ()Ljava/lang/String;
    //   422: invokespecial <init> : (Ljava/lang/String;)V
    //   425: athrow
    // Exception table:
    //   from	to	target	type
    //   114	139	258	org/xmlpull/v1/XmlPullParserException
    //   114	139	242	java/io/IOException
    //   143	151	258	org/xmlpull/v1/XmlPullParserException
    //   143	151	242	java/io/IOException
    //   159	168	258	org/xmlpull/v1/XmlPullParserException
    //   159	168	242	java/io/IOException
    //   174	190	258	org/xmlpull/v1/XmlPullParserException
    //   174	190	242	java/io/IOException
    //   193	204	258	org/xmlpull/v1/XmlPullParserException
    //   193	204	242	java/io/IOException
    //   215	223	258	org/xmlpull/v1/XmlPullParserException
    //   215	223	242	java/io/IOException
    //   228	237	258	org/xmlpull/v1/XmlPullParserException
    //   228	237	242	java/io/IOException
  }
  
  public static class a {
    public final ColorStateList a;
    
    public final Configuration b;
    
    public a(ColorStateList param1ColorStateList, Configuration param1Configuration) {
      this.a = param1ColorStateList;
      this.b = param1Configuration;
    }
  }
  
  public static final class b {
    public final Resources a;
    
    public final Resources.Theme b;
    
    public b(Resources param1Resources, Resources.Theme param1Theme) {
      this.a = param1Resources;
      this.b = param1Theme;
    }
    
    public boolean equals(Object param1Object) {
      if (this == param1Object)
        return true; 
      if (param1Object != null) {
        if (b.class != param1Object.getClass())
          return false; 
        param1Object = param1Object;
        return (this.a.equals(((b)param1Object).a) && Objects.equals(this.b, ((b)param1Object).b));
      } 
      return false;
    }
    
    public int hashCode() {
      return Objects.hash(new Object[] { this.a, this.b });
    }
  }
  
  public static abstract class c {
    public static Handler c(Handler param1Handler) {
      Handler handler = param1Handler;
      if (param1Handler == null)
        handler = new Handler(Looper.getMainLooper()); 
      return handler;
    }
    
    public final void a(int param1Int, Handler param1Handler) {
      c(param1Handler).post(new b(this, param1Int));
    }
    
    public final void b(Typeface param1Typeface, Handler param1Handler) {
      c(param1Handler).post(new a(this, param1Typeface));
    }
    
    public abstract void d(int param1Int);
    
    public abstract void e(Typeface param1Typeface);
    
    public class a implements Runnable {
      public a(e.c this$0, Typeface param2Typeface) {}
      
      public void run() {
        this.i.e(this.h);
      }
    }
    
    public class b implements Runnable {
      public b(e.c this$0, int param2Int) {}
      
      public void run() {
        this.i.d(this.h);
      }
    }
  }
  
  public class a implements Runnable {
    public a(e this$0, Typeface param1Typeface) {}
    
    public void run() {
      this.i.e(this.h);
    }
  }
  
  public class b implements Runnable {
    public b(e this$0, int param1Int) {}
    
    public void run() {
      this.i.d(this.h);
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Luxury Logo Maker_ Logo Design-dex2jar.jar!\c0\e.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */