package c0;

import java.util.List;

public final class d {
  public final int[] a;
  
  public final float[] b;
  
  public d(int paramInt1, int paramInt2) {
    this.a = new int[] { paramInt1, paramInt2 };
    this.b = new float[] { 0.0F, 1.0F };
  }
  
  public d(int paramInt1, int paramInt2, int paramInt3) {
    this.a = new int[] { paramInt1, paramInt2, paramInt3 };
    this.b = new float[] { 0.0F, 0.5F, 1.0F };
  }
  
  public d(List<Integer> paramList, List<Float> paramList1) {
    int j = paramList.size();
    this.a = new int[j];
    this.b = new float[j];
    for (int i = 0; i < j; i++) {
      this.a[i] = ((Integer)paramList.get(i)).intValue();
      this.b[i] = ((Float)paramList1.get(i)).floatValue();
    } 
  }
}


/* Location:              C:\soft\dex2jar-2.0\Luxury Logo Maker_ Logo Design-dex2jar.jar!\c0\d.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */