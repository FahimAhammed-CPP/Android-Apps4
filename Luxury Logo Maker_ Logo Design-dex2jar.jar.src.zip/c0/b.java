package c0;

import android.content.res.ColorStateList;
import android.content.res.Resources;
import android.content.res.TypedArray;
import android.content.res.XmlResourceParser;
import android.graphics.LinearGradient;
import android.graphics.RadialGradient;
import android.graphics.Shader;
import android.graphics.SweepGradient;
import android.util.AttributeSet;
import android.util.Xml;
import java.util.ArrayList;
import java.util.Objects;
import org.xmlpull.v1.XmlPullParser;
import org.xmlpull.v1.XmlPullParserException;

public final class b {
  public final Shader a;
  
  public final ColorStateList b;
  
  public int c;
  
  public b(Shader paramShader, ColorStateList paramColorStateList, int paramInt) {
    this.a = paramShader;
    this.b = paramColorStateList;
    this.c = paramInt;
  }
  
  public static b a(Resources paramResources, int paramInt, Resources.Theme paramTheme) {
    XmlResourceParser xmlResourceParser = paramResources.getXml(paramInt);
    AttributeSet attributeSet = Xml.asAttributeSet((XmlPullParser)xmlResourceParser);
    while (true) {
      paramInt = xmlResourceParser.next();
      if (paramInt != 2 && paramInt != 1)
        continue; 
      break;
    } 
    if (paramInt == 2) {
      float[] arrayOfFloat;
      ArrayList<Float> arrayList;
      String str = xmlResourceParser.getName();
      Objects.requireNonNull(str);
      if (!str.equals("gradient")) {
        if (str.equals("selector")) {
          ColorStateList colorStateList = a.b(paramResources, (XmlPullParser)xmlResourceParser, attributeSet, paramTheme);
          return new b(null, colorStateList, colorStateList.getDefaultColor());
        } 
        stringBuilder = new StringBuilder();
        stringBuilder.append(xmlResourceParser.getPositionDescription());
        stringBuilder.append(": unsupported complex color tag ");
        stringBuilder.append(str);
        throw new XmlPullParserException(stringBuilder.toString());
      } 
      str = xmlResourceParser.getName();
      if (str.equals("gradient")) {
        d d;
        SweepGradient sweepGradient;
        RadialGradient radialGradient;
        float f1;
        float f2;
        float f3;
        float f4;
        float f5;
        float f6;
        float f7;
        int i;
        int j;
        int k;
        TypedArray typedArray = g.d((Resources)stringBuilder, paramTheme, attributeSet, b2.b.d);
        if (!g.c((XmlPullParser)xmlResourceParser, "startX")) {
          f4 = 0.0F;
        } else {
          f4 = typedArray.getFloat(8, 0.0F);
        } 
        if (!g.c((XmlPullParser)xmlResourceParser, "startY")) {
          f1 = 0.0F;
        } else {
          f1 = typedArray.getFloat(9, 0.0F);
        } 
        if (!g.c((XmlPullParser)xmlResourceParser, "endX")) {
          f2 = 0.0F;
        } else {
          f2 = typedArray.getFloat(10, 0.0F);
        } 
        if (!g.c((XmlPullParser)xmlResourceParser, "endY")) {
          f5 = 0.0F;
        } else {
          f5 = typedArray.getFloat(11, 0.0F);
        } 
        if (!g.c((XmlPullParser)xmlResourceParser, "centerX")) {
          f6 = 0.0F;
        } else {
          f6 = typedArray.getFloat(3, 0.0F);
        } 
        if (!g.c((XmlPullParser)xmlResourceParser, "centerY")) {
          f3 = 0.0F;
        } else {
          f3 = typedArray.getFloat(4, 0.0F);
        } 
        if (!g.c((XmlPullParser)xmlResourceParser, "type")) {
          paramInt = 0;
        } else {
          paramInt = typedArray.getInt(2, 0);
        } 
        if (!g.c((XmlPullParser)xmlResourceParser, "startColor")) {
          i = 0;
        } else {
          i = typedArray.getColor(0, 0);
        } 
        boolean bool1 = g.c((XmlPullParser)xmlResourceParser, "centerColor");
        if (!g.c((XmlPullParser)xmlResourceParser, "centerColor")) {
          j = 0;
        } else {
          j = typedArray.getColor(7, 0);
        } 
        if (!g.c((XmlPullParser)xmlResourceParser, "endColor")) {
          k = 0;
        } else {
          k = typedArray.getColor(1, 0);
        } 
        boolean bool2 = g.c((XmlPullParser)xmlResourceParser, "tileMode");
        int m = 0;
        if (bool2)
          m = typedArray.getInt(6, 0); 
        if (!g.c((XmlPullParser)xmlResourceParser, "gradientRadius")) {
          f7 = 0.0F;
        } else {
          f7 = typedArray.getFloat(5, 0.0F);
        } 
        typedArray.recycle();
        int n = xmlResourceParser.getDepth() + 1;
        arrayList = new ArrayList(20);
        ArrayList<Integer> arrayList1 = new ArrayList(20);
        while (true) {
          int i1 = xmlResourceParser.next();
          if (i1 != 1) {
            int i2 = xmlResourceParser.getDepth();
            if (i2 >= n || i1 != 3) {
              if (i1 != 2 || i2 > n || !xmlResourceParser.getName().equals("item"))
                continue; 
              TypedArray typedArray1 = g.d((Resources)stringBuilder, paramTheme, attributeSet, b2.b.e);
              bool2 = typedArray1.hasValue(0);
              boolean bool = typedArray1.hasValue(1);
              if (bool2 && bool) {
                i1 = typedArray1.getColor(0, 0);
                float f = typedArray1.getFloat(1, 0.0F);
                typedArray1.recycle();
                arrayList1.add(Integer.valueOf(i1));
                arrayList.add(Float.valueOf(f));
                continue;
              } 
              stringBuilder = new StringBuilder();
              stringBuilder.append(xmlResourceParser.getPositionDescription());
              stringBuilder.append(": <item> tag requires a 'color' attribute and a 'offset' attribute!");
              throw new XmlPullParserException(stringBuilder.toString());
            } 
          } 
          break;
        } 
        if (arrayList1.size() > 0) {
          d = new d(arrayList1, arrayList);
        } else {
          stringBuilder = null;
        } 
        if (stringBuilder == null)
          if (bool1) {
            d = new d(i, j, k);
          } else {
            d = new d(i, k);
          }  
        if (paramInt != 1) {
          LinearGradient linearGradient;
          if (paramInt != 2) {
            Shader.TileMode tileMode;
            int[] arrayOfInt = d.a;
            arrayOfFloat = d.b;
            if (m != 1) {
              if (m != 2) {
                tileMode = Shader.TileMode.CLAMP;
              } else {
                tileMode = Shader.TileMode.MIRROR;
              } 
            } else {
              tileMode = Shader.TileMode.REPEAT;
            } 
            linearGradient = new LinearGradient(f4, f1, f2, f5, arrayOfInt, arrayOfFloat, tileMode);
          } else {
            sweepGradient = new SweepGradient(f6, f3, ((d)linearGradient).a, ((d)linearGradient).b);
          } 
        } else {
          if (f7 > 0.0F) {
            Shader.TileMode tileMode;
            int[] arrayOfInt = ((d)sweepGradient).a;
            arrayOfFloat = ((d)sweepGradient).b;
            if (m != 1) {
              if (m != 2) {
                tileMode = Shader.TileMode.CLAMP;
              } else {
                tileMode = Shader.TileMode.MIRROR;
              } 
            } else {
              tileMode = Shader.TileMode.REPEAT;
            } 
            radialGradient = new RadialGradient(f6, f3, f7, arrayOfInt, arrayOfFloat, tileMode);
            return new b((Shader)radialGradient, null, 0);
          } 
          throw new XmlPullParserException("<gradient> tag requires 'gradientRadius' attribute with radial type");
        } 
        return new b((Shader)radialGradient, null, 0);
      } 
      StringBuilder stringBuilder = new StringBuilder();
      stringBuilder.append(arrayOfFloat.getPositionDescription());
      stringBuilder.append(": invalid gradient color tag ");
      stringBuilder.append((String)arrayList);
      throw new XmlPullParserException(stringBuilder.toString());
    } 
    throw new XmlPullParserException("No start tag found");
  }
  
  public boolean b() {
    return (this.a != null);
  }
  
  public boolean c() {
    if (this.a == null) {
      ColorStateList colorStateList = this.b;
      if (colorStateList != null && colorStateList.isStateful())
        return true; 
    } 
    return false;
  }
  
  public boolean d(int[] paramArrayOfint) {
    if (c()) {
      ColorStateList colorStateList = this.b;
      int i = colorStateList.getColorForState(paramArrayOfint, colorStateList.getDefaultColor());
      if (i != this.c) {
        this.c = i;
        return true;
      } 
    } 
    return false;
  }
}


/* Location:              C:\soft\dex2jar-2.0\Luxury Logo Maker_ Logo Design-dex2jar.jar!\c0\b.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */