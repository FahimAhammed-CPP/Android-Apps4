package c0;

import android.content.res.Resources;
import android.content.res.TypedArray;
import android.util.AttributeSet;
import android.util.Log;
import android.util.TypedValue;
import org.xmlpull.v1.XmlPullParser;

public class g {
  public static b a(TypedArray paramTypedArray, XmlPullParser paramXmlPullParser, Resources.Theme paramTheme, String paramString, int paramInt1, int paramInt2) {
    if (c(paramXmlPullParser, paramString)) {
      TypedValue typedValue = new TypedValue();
      paramTypedArray.getValue(paramInt1, typedValue);
      int i = typedValue.type;
      if (i >= 28 && i <= 31)
        return new b(null, null, typedValue.data); 
      Resources resources = paramTypedArray.getResources();
      paramInt1 = paramTypedArray.getResourceId(paramInt1, 0);
      try {
        b b = b.a(resources, paramInt1, paramTheme);
      } catch (Exception exception) {
        Log.e("ComplexColorCompat", "Failed to inflate ComplexColor.", exception);
        exception = null;
      } 
      if (exception != null)
        return (b)exception; 
    } 
    return new b(null, null, paramInt2);
  }
  
  public static String b(TypedArray paramTypedArray, XmlPullParser paramXmlPullParser, String paramString, int paramInt) {
    return !c(paramXmlPullParser, paramString) ? null : paramTypedArray.getString(paramInt);
  }
  
  public static boolean c(XmlPullParser paramXmlPullParser, String paramString) {
    return (paramXmlPullParser.getAttributeValue("http://schemas.android.com/apk/res/android", paramString) != null);
  }
  
  public static TypedArray d(Resources paramResources, Resources.Theme paramTheme, AttributeSet paramAttributeSet, int[] paramArrayOfint) {
    return (paramTheme == null) ? paramResources.obtainAttributes(paramAttributeSet, paramArrayOfint) : paramTheme.obtainStyledAttributes(paramAttributeSet, paramArrayOfint, 0, 0);
  }
}


/* Location:              C:\soft\dex2jar-2.0\Luxury Logo Maker_ Logo Design-dex2jar.jar!\c0\g.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */