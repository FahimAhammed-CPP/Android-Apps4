package c0;

import android.content.res.ColorStateList;
import android.content.res.Resources;
import android.content.res.TypedArray;
import android.util.AttributeSet;
import android.util.TypedValue;
import android.util.Xml;
import b2.b;
import org.xmlpull.v1.XmlPullParser;
import org.xmlpull.v1.XmlPullParserException;

public final class a {
  public static final ThreadLocal<TypedValue> a = new ThreadLocal<TypedValue>();
  
  public static ColorStateList a(Resources paramResources, XmlPullParser paramXmlPullParser, Resources.Theme paramTheme) {
    int i;
    AttributeSet attributeSet = Xml.asAttributeSet(paramXmlPullParser);
    while (true) {
      i = paramXmlPullParser.next();
      if (i != 2 && i != 1)
        continue; 
      break;
    } 
    if (i == 2)
      return b(paramResources, paramXmlPullParser, attributeSet, paramTheme); 
    throw new XmlPullParserException("No start tag found");
  }
  
  public static ColorStateList b(Resources paramResources, XmlPullParser paramXmlPullParser, AttributeSet paramAttributeSet, Resources.Theme paramTheme) {
    int[][] arrayOfInt;
    Exception exception;
    String str = paramXmlPullParser.getName();
    if (str.equals("selector")) {
      int j = paramXmlPullParser.getDepth() + 1;
      int[][] arrayOfInt1 = new int[20][];
      int[] arrayOfInt2 = new int[20];
      for (int i = 0;; i = k) {
        int k;
        TypedArray typedArray2;
        int m = paramXmlPullParser.next();
        if (m != 1) {
          int n = paramXmlPullParser.getDepth();
          if (n >= j || m != 3) {
            int[] arrayOfInt3 = arrayOfInt2;
            int[][] arrayOfInt4 = arrayOfInt1;
            k = i;
            if (m == 2) {
              arrayOfInt3 = arrayOfInt2;
              arrayOfInt4 = arrayOfInt1;
              k = i;
              if (n <= j)
                if (!paramXmlPullParser.getName().equals("item")) {
                  arrayOfInt3 = arrayOfInt2;
                  arrayOfInt4 = arrayOfInt1;
                  k = i;
                } else {
                  arrayOfInt3 = b.a;
                  if (paramTheme == null) {
                    typedArray2 = paramResources.obtainAttributes(paramAttributeSet, arrayOfInt3);
                  } else {
                    typedArray2 = paramTheme.obtainStyledAttributes(paramAttributeSet, (int[])typedArray2, 0, 0);
                  } 
                  m = typedArray2.getResourceId(0, -1);
                  if (m != -1) {
                    ThreadLocal<TypedValue> threadLocal = a;
                    TypedValue typedValue2 = threadLocal.get();
                    TypedValue typedValue1 = typedValue2;
                    if (typedValue2 == null) {
                      typedValue1 = new TypedValue();
                      threadLocal.set(typedValue1);
                    } 
                    paramResources.getValue(m, typedValue1, true);
                    k = typedValue1.type;
                    if (k >= 28 && k <= 31) {
                      k = 1;
                    } else {
                      k = 0;
                    } 
                    if (k == 0)
                      try {
                        k = a(paramResources, (XmlPullParser)paramResources.getXml(m), paramTheme).getDefaultColor();
                        float f1 = 1.0F;
                      } catch (Exception exception1) {} 
                  } 
                  k = typedArray2.getColor(0, -65281);
                  float f = 1.0F;
                }  
            } 
          } else {
            int[] arrayOfInt3 = new int[i];
            arrayOfInt = new int[i][];
            System.arraycopy(arrayOfInt2, 0, arrayOfInt3, 0, i);
            System.arraycopy(arrayOfInt1, 0, arrayOfInt, 0, i);
            return new ColorStateList(arrayOfInt, arrayOfInt3);
          } 
        } else {
          int[] arrayOfInt3 = new int[i];
          arrayOfInt = new int[i][];
          System.arraycopy(arrayOfInt2, 0, arrayOfInt3, 0, i);
          System.arraycopy(arrayOfInt1, 0, arrayOfInt, 0, i);
          return new ColorStateList(arrayOfInt, arrayOfInt3);
        } 
        TypedArray typedArray1 = typedArray2;
        exception = exception1;
      } 
    } 
    StringBuilder stringBuilder = new StringBuilder();
    stringBuilder.append(arrayOfInt.getPositionDescription());
    stringBuilder.append(": invalid color state list tag ");
    stringBuilder.append((String)exception);
    throw new XmlPullParserException(stringBuilder.toString());
  }
}


/* Location:              C:\soft\dex2jar-2.0\Luxury Logo Maker_ Logo Design-dex2jar.jar!\c0\a.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */