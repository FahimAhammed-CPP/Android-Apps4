package c0;

import java.lang.reflect.Method;

public class f {
  public static final Object a = new Object();
  
  public static Method b;
  
  public static boolean c;
}


/* Location:              C:\soft\dex2jar-2.0\Luxury Logo Maker_ Logo Design-dex2jar.jar!\c0\f.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */