package a6;

import android.support.v4.media.b;
import android.support.v4.media.c;
import java.io.Closeable;
import java.io.EOFException;
import java.io.IOException;
import java.io.Reader;
import java.util.Arrays;
import java.util.Iterator;
import java.util.Map;
import java.util.Objects;
import s5.r;
import v5.f;

public class a implements Closeable {
  public final Reader h;
  
  public boolean i = false;
  
  public final char[] j = new char[1024];
  
  public int k = 0;
  
  public int l = 0;
  
  public int m = 0;
  
  public int n = 0;
  
  public int o = 0;
  
  public long p;
  
  public int q;
  
  public String r;
  
  public int[] s;
  
  public int t;
  
  public String[] u;
  
  public int[] v;
  
  static {
    b.a = new a();
  }
  
  public a(Reader paramReader) {
    int[] arrayOfInt = new int[32];
    this.s = arrayOfInt;
    this.t = 0;
    this.t = 0 + 1;
    arrayOfInt[0] = 6;
    this.u = new String[32];
    this.v = new int[32];
    Objects.requireNonNull(paramReader, "in == null");
    Reader reader = paramReader;
    this.h = paramReader;
  }
  
  public final char A() {
    if (this.k != this.l || h(1)) {
      char[] arrayOfChar = this.j;
      int i = this.k;
      int j = i + 1;
      this.k = j;
      char c = arrayOfChar[i];
      if (c != '\n') {
        if (c != '"' && c != '\'' && c != '/' && c != '\\') {
          if (c != 'b') {
            if (c != 'f') {
              if (c != 'n') {
                if (c != 'r') {
                  if (c != 't') {
                    if (c == 'u') {
                      if (j + 4 <= this.l || h(4)) {
                        c = Character.MIN_VALUE;
                        j = this.k;
                        i = j;
                        while (true) {
                          int k = i;
                          if (k < j + 4) {
                            i = this.j[k];
                            char c1 = (char)(c << 4);
                            if (i >= 48 && i <= 57) {
                              i -= 48;
                            } else {
                              if (i >= 97 && i <= 102) {
                                i -= 97;
                              } else if (i >= 65) {
                                if (i <= 70) {
                                  i -= 65;
                                } else {
                                  StringBuilder stringBuilder = c.a("\\u");
                                  stringBuilder.append(new String(this.j, this.k, 4));
                                  throw new NumberFormatException(stringBuilder.toString());
                                } 
                              } else {
                                continue;
                              } 
                              i += 10;
                            } 
                            c = (char)(i + c1);
                            i = k + 1;
                            continue;
                          } 
                          this.k += 4;
                          return c;
                        } 
                      } 
                      F("Unterminated escape sequence");
                      throw null;
                    } 
                    F("Invalid escape sequence");
                    throw null;
                  } 
                  return '\t';
                } 
                return '\r';
              } 
              return '\n';
            } 
            return '\f';
          } 
          return '\b';
        } 
      } else {
        this.m++;
        this.n = j;
      } 
      return c;
    } 
    F("Unterminated escape sequence");
    throw null;
  }
  
  public final void B(char paramChar) {
    char[] arrayOfChar = this.j;
    label21: while (true) {
      int i = this.k;
      int j = this.l;
      while (i < j) {
        int k = i + 1;
        i = arrayOfChar[i];
        if (i == paramChar) {
          this.k = k;
          return;
        } 
        if (i == 92) {
          this.k = k;
          A();
          continue label21;
        } 
        if (i == 10) {
          this.m++;
          this.n = k;
        } 
        i = k;
      } 
      this.k = i;
      if (h(1))
        continue; 
      F("Unterminated string");
      throw null;
    } 
  }
  
  public final void C() {
    while (this.k < this.l || h(1)) {
      char[] arrayOfChar = this.j;
      int j = this.k;
      int i = j + 1;
      this.k = i;
      j = arrayOfChar[j];
      if (j == 10) {
        this.m++;
        this.n = i;
        return;
      } 
      if (j == 13)
        break; 
    } 
  }
  
  public final void D() {
    do {
      int i = 0;
      while (true) {
        int j = this.k;
        if (j + i < this.l) {
          j = this.j[j + i];
          if (j != 9 && j != 10 && j != 12 && j != 13 && j != 32)
            if (j != 35) {
              if (j != 44)
                if (j != 47 && j != 61) {
                  if (j != 123 && j != 125 && j != 58)
                    if (j != 59) {
                      switch (j) {
                        default:
                          i++;
                          continue;
                        case 92:
                          d();
                          break;
                        case 91:
                        case 93:
                          break;
                      } 
                    } else {
                    
                    }  
                } else {
                
                }  
            } else {
            
            }  
          this.k += i;
          return;
        } 
        this.k = j + i;
        break;
      } 
    } while (h(1));
  }
  
  public void E() {
    int i = 0;
    while (true) {
      int k = this.o;
      int j = k;
      if (k == 0)
        j = e(); 
      switch (j) {
        default:
          j = i;
          break;
        case 17:
          return;
        case 16:
          this.k += this.q;
          j = i;
          break;
        case 14:
          D();
          j = i;
          if (!i) {
            this.u[this.t - 1] = "<skipped>";
            j = i;
          } 
          break;
        case 13:
          B('"');
          j = i;
          if (!i) {
            this.u[this.t - 1] = "<skipped>";
            j = i;
          } 
          break;
        case 12:
          B('\'');
          j = i;
          if (!i) {
            this.u[this.t - 1] = "<skipped>";
            j = i;
          } 
          break;
        case 10:
          D();
          j = i;
          break;
        case 9:
          B('"');
          j = i;
          break;
        case 8:
          B('\'');
          j = i;
          break;
        case 4:
          this.t--;
          j = i - 1;
          break;
        case 3:
          z(1);
          j = i + 1;
          break;
        case 2:
          if (i == 0)
            this.u[this.t - 1] = null; 
        case 1:
          z(3);
          j = i + 1;
          break;
      } 
      this.o = 0;
      i = j;
      if (j <= 0) {
        int[] arrayOfInt = this.v;
        j = this.t - 1;
        arrayOfInt[j] = arrayOfInt[j] + 1;
        return;
      } 
    } 
  }
  
  public final IOException F(String paramString) {
    StringBuilder stringBuilder = c.a(paramString);
    stringBuilder.append(n());
    throw new d(stringBuilder.toString());
  }
  
  public void a() {
    int j = this.o;
    int i = j;
    if (j == 0)
      i = e(); 
    if (i == 3) {
      z(1);
      this.v[this.t - 1] = 0;
      this.o = 0;
      return;
    } 
    StringBuilder stringBuilder = c.a("Expected BEGIN_ARRAY but was ");
    stringBuilder.append(b.c(y()));
    stringBuilder.append(n());
    throw new IllegalStateException(stringBuilder.toString());
  }
  
  public void c() {
    int j = this.o;
    int i = j;
    if (j == 0)
      i = e(); 
    if (i == 1) {
      z(3);
      this.o = 0;
      return;
    } 
    StringBuilder stringBuilder = c.a("Expected BEGIN_OBJECT but was ");
    stringBuilder.append(b.c(y()));
    stringBuilder.append(n());
    throw new IllegalStateException(stringBuilder.toString());
  }
  
  public void close() {
    this.o = 0;
    this.s[0] = 8;
    this.t = 1;
    this.h.close();
  }
  
  public final void d() {
    if (this.i)
      return; 
    F("Use JsonReader.setLenient(true) to accept malformed JSON");
    throw null;
  }
  
  public int e() {
    // Byte code:
    //   0: aload_0
    //   1: getfield s : [I
    //   4: astore #17
    //   6: aload_0
    //   7: getfield t : I
    //   10: istore_3
    //   11: aload #17
    //   13: iload_3
    //   14: iconst_1
    //   15: isub
    //   16: iaload
    //   17: istore_2
    //   18: iload_2
    //   19: iconst_1
    //   20: if_icmpne -> 33
    //   23: aload #17
    //   25: iload_3
    //   26: iconst_1
    //   27: isub
    //   28: iconst_2
    //   29: iastore
    //   30: goto -> 380
    //   33: iload_2
    //   34: iconst_2
    //   35: if_icmpne -> 85
    //   38: aload_0
    //   39: iconst_1
    //   40: invokevirtual t : (Z)I
    //   43: istore_3
    //   44: iload_3
    //   45: bipush #44
    //   47: if_icmpeq -> 30
    //   50: iload_3
    //   51: bipush #59
    //   53: if_icmpeq -> 78
    //   56: iload_3
    //   57: bipush #93
    //   59: if_icmpne -> 69
    //   62: aload_0
    //   63: iconst_4
    //   64: putfield o : I
    //   67: iconst_4
    //   68: ireturn
    //   69: aload_0
    //   70: ldc 'Unterminated array'
    //   72: invokevirtual F : (Ljava/lang/String;)Ljava/io/IOException;
    //   75: pop
    //   76: aconst_null
    //   77: athrow
    //   78: aload_0
    //   79: invokevirtual d : ()V
    //   82: goto -> 30
    //   85: iload_2
    //   86: iconst_3
    //   87: if_icmpeq -> 1389
    //   90: iload_2
    //   91: iconst_5
    //   92: if_icmpne -> 98
    //   95: goto -> 1389
    //   98: iload_2
    //   99: iconst_4
    //   100: if_icmpne -> 190
    //   103: aload #17
    //   105: iload_3
    //   106: iconst_1
    //   107: isub
    //   108: iconst_5
    //   109: iastore
    //   110: aload_0
    //   111: iconst_1
    //   112: invokevirtual t : (Z)I
    //   115: istore_3
    //   116: iload_3
    //   117: bipush #58
    //   119: if_icmpeq -> 30
    //   122: iload_3
    //   123: bipush #61
    //   125: if_icmpne -> 181
    //   128: aload_0
    //   129: invokevirtual d : ()V
    //   132: aload_0
    //   133: getfield k : I
    //   136: aload_0
    //   137: getfield l : I
    //   140: if_icmplt -> 151
    //   143: aload_0
    //   144: iconst_1
    //   145: invokevirtual h : (I)Z
    //   148: ifeq -> 30
    //   151: aload_0
    //   152: getfield j : [C
    //   155: astore #17
    //   157: aload_0
    //   158: getfield k : I
    //   161: istore_3
    //   162: aload #17
    //   164: iload_3
    //   165: caload
    //   166: bipush #62
    //   168: if_icmpne -> 30
    //   171: aload_0
    //   172: iload_3
    //   173: iconst_1
    //   174: iadd
    //   175: putfield k : I
    //   178: goto -> 30
    //   181: aload_0
    //   182: ldc 'Expected ':''
    //   184: invokevirtual F : (Ljava/lang/String;)Ljava/io/IOException;
    //   187: pop
    //   188: aconst_null
    //   189: athrow
    //   190: iload_2
    //   191: bipush #6
    //   193: if_icmpne -> 332
    //   196: aload_0
    //   197: getfield i : Z
    //   200: ifeq -> 316
    //   203: aload_0
    //   204: iconst_1
    //   205: invokevirtual t : (Z)I
    //   208: pop
    //   209: aload_0
    //   210: getfield k : I
    //   213: iconst_1
    //   214: isub
    //   215: istore_3
    //   216: aload_0
    //   217: iload_3
    //   218: putfield k : I
    //   221: iload_3
    //   222: iconst_5
    //   223: iadd
    //   224: aload_0
    //   225: getfield l : I
    //   228: if_icmple -> 242
    //   231: aload_0
    //   232: iconst_5
    //   233: invokevirtual h : (I)Z
    //   236: ifne -> 242
    //   239: goto -> 316
    //   242: aload_0
    //   243: getfield k : I
    //   246: istore_3
    //   247: aload_0
    //   248: getfield j : [C
    //   251: astore #17
    //   253: aload #17
    //   255: iload_3
    //   256: caload
    //   257: bipush #41
    //   259: if_icmpne -> 316
    //   262: aload #17
    //   264: iload_3
    //   265: iconst_1
    //   266: iadd
    //   267: caload
    //   268: bipush #93
    //   270: if_icmpne -> 316
    //   273: aload #17
    //   275: iload_3
    //   276: iconst_2
    //   277: iadd
    //   278: caload
    //   279: bipush #125
    //   281: if_icmpne -> 316
    //   284: aload #17
    //   286: iload_3
    //   287: iconst_3
    //   288: iadd
    //   289: caload
    //   290: bipush #39
    //   292: if_icmpne -> 316
    //   295: aload #17
    //   297: iload_3
    //   298: iconst_4
    //   299: iadd
    //   300: caload
    //   301: bipush #10
    //   303: if_icmpeq -> 309
    //   306: goto -> 316
    //   309: aload_0
    //   310: iload_3
    //   311: iconst_5
    //   312: iadd
    //   313: putfield k : I
    //   316: aload_0
    //   317: getfield s : [I
    //   320: aload_0
    //   321: getfield t : I
    //   324: iconst_1
    //   325: isub
    //   326: bipush #7
    //   328: iastore
    //   329: goto -> 30
    //   332: iload_2
    //   333: bipush #7
    //   335: if_icmpne -> 374
    //   338: aload_0
    //   339: iconst_0
    //   340: invokevirtual t : (Z)I
    //   343: iconst_m1
    //   344: if_icmpne -> 357
    //   347: bipush #17
    //   349: istore_2
    //   350: aload_0
    //   351: iload_2
    //   352: putfield o : I
    //   355: iload_2
    //   356: ireturn
    //   357: aload_0
    //   358: invokevirtual d : ()V
    //   361: aload_0
    //   362: aload_0
    //   363: getfield k : I
    //   366: iconst_1
    //   367: isub
    //   368: putfield k : I
    //   371: goto -> 380
    //   374: iload_2
    //   375: bipush #8
    //   377: if_icmpeq -> 1379
    //   380: aload_0
    //   381: iconst_1
    //   382: invokevirtual t : (Z)I
    //   385: istore_3
    //   386: iload_3
    //   387: bipush #34
    //   389: if_icmpeq -> 1373
    //   392: iload_3
    //   393: bipush #39
    //   395: if_icmpeq -> 1363
    //   398: iload_3
    //   399: bipush #44
    //   401: if_icmpeq -> 1321
    //   404: iload_3
    //   405: bipush #59
    //   407: if_icmpeq -> 1321
    //   410: iload_3
    //   411: bipush #91
    //   413: if_icmpeq -> 1316
    //   416: iload_3
    //   417: bipush #93
    //   419: if_icmpeq -> 1302
    //   422: iload_3
    //   423: bipush #123
    //   425: if_icmpeq -> 1297
    //   428: aload_0
    //   429: getfield k : I
    //   432: iconst_1
    //   433: isub
    //   434: istore_2
    //   435: aload_0
    //   436: iload_2
    //   437: putfield k : I
    //   440: aload_0
    //   441: getfield j : [C
    //   444: iload_2
    //   445: caload
    //   446: istore_2
    //   447: iload_2
    //   448: bipush #116
    //   450: if_icmpeq -> 517
    //   453: iload_2
    //   454: bipush #84
    //   456: if_icmpne -> 462
    //   459: goto -> 517
    //   462: iload_2
    //   463: bipush #102
    //   465: if_icmpeq -> 503
    //   468: iload_2
    //   469: bipush #70
    //   471: if_icmpne -> 477
    //   474: goto -> 503
    //   477: iload_2
    //   478: bipush #110
    //   480: if_icmpeq -> 489
    //   483: iload_2
    //   484: bipush #78
    //   486: if_icmpne -> 657
    //   489: ldc 'null'
    //   491: astore #17
    //   493: ldc 'NULL'
    //   495: astore #18
    //   497: bipush #7
    //   499: istore_2
    //   500: goto -> 527
    //   503: ldc 'false'
    //   505: astore #17
    //   507: ldc 'FALSE'
    //   509: astore #18
    //   511: bipush #6
    //   513: istore_2
    //   514: goto -> 527
    //   517: ldc 'true'
    //   519: astore #17
    //   521: ldc 'TRUE'
    //   523: astore #18
    //   525: iconst_5
    //   526: istore_2
    //   527: aload #17
    //   529: invokevirtual length : ()I
    //   532: istore #4
    //   534: iconst_1
    //   535: istore_3
    //   536: iload_3
    //   537: iload #4
    //   539: if_icmpge -> 613
    //   542: aload_0
    //   543: getfield k : I
    //   546: iload_3
    //   547: iadd
    //   548: aload_0
    //   549: getfield l : I
    //   552: if_icmplt -> 568
    //   555: aload_0
    //   556: iload_3
    //   557: iconst_1
    //   558: iadd
    //   559: invokevirtual h : (I)Z
    //   562: ifne -> 568
    //   565: goto -> 657
    //   568: aload_0
    //   569: getfield j : [C
    //   572: aload_0
    //   573: getfield k : I
    //   576: iload_3
    //   577: iadd
    //   578: caload
    //   579: istore #5
    //   581: iload #5
    //   583: aload #17
    //   585: iload_3
    //   586: invokevirtual charAt : (I)C
    //   589: if_icmpeq -> 606
    //   592: iload #5
    //   594: aload #18
    //   596: iload_3
    //   597: invokevirtual charAt : (I)C
    //   600: if_icmpeq -> 606
    //   603: goto -> 657
    //   606: iload_3
    //   607: iconst_1
    //   608: iadd
    //   609: istore_3
    //   610: goto -> 536
    //   613: aload_0
    //   614: getfield k : I
    //   617: iload #4
    //   619: iadd
    //   620: aload_0
    //   621: getfield l : I
    //   624: if_icmplt -> 638
    //   627: aload_0
    //   628: iload #4
    //   630: iconst_1
    //   631: iadd
    //   632: invokevirtual h : (I)Z
    //   635: ifeq -> 662
    //   638: aload_0
    //   639: aload_0
    //   640: getfield j : [C
    //   643: aload_0
    //   644: getfield k : I
    //   647: iload #4
    //   649: iadd
    //   650: caload
    //   651: invokevirtual m : (C)Z
    //   654: ifeq -> 662
    //   657: iconst_0
    //   658: istore_2
    //   659: goto -> 678
    //   662: aload_0
    //   663: aload_0
    //   664: getfield k : I
    //   667: iload #4
    //   669: iadd
    //   670: putfield k : I
    //   673: aload_0
    //   674: iload_2
    //   675: putfield o : I
    //   678: iload_2
    //   679: ifeq -> 684
    //   682: iload_2
    //   683: ireturn
    //   684: aload_0
    //   685: getfield j : [C
    //   688: astore #17
    //   690: aload_0
    //   691: getfield k : I
    //   694: istore #12
    //   696: aload_0
    //   697: getfield l : I
    //   700: istore #10
    //   702: lconst_0
    //   703: lstore #13
    //   705: iconst_0
    //   706: istore #6
    //   708: iconst_0
    //   709: istore #4
    //   711: iconst_1
    //   712: istore_3
    //   713: iconst_0
    //   714: istore #5
    //   716: iload #12
    //   718: istore #8
    //   720: iload #10
    //   722: istore #7
    //   724: iload #12
    //   726: iload #6
    //   728: iadd
    //   729: iload #10
    //   731: if_icmpne -> 773
    //   734: iload #6
    //   736: aload #17
    //   738: arraylength
    //   739: if_icmpne -> 747
    //   742: iconst_0
    //   743: istore_2
    //   744: goto -> 1253
    //   747: aload_0
    //   748: iload #6
    //   750: iconst_1
    //   751: iadd
    //   752: invokevirtual h : (I)Z
    //   755: ifne -> 761
    //   758: goto -> 1015
    //   761: aload_0
    //   762: getfield k : I
    //   765: istore #8
    //   767: aload_0
    //   768: getfield l : I
    //   771: istore #7
    //   773: aload #17
    //   775: iload #8
    //   777: iload #6
    //   779: iadd
    //   780: caload
    //   781: istore_1
    //   782: iload_1
    //   783: bipush #43
    //   785: if_icmpeq -> 1202
    //   788: iload_1
    //   789: bipush #69
    //   791: if_icmpeq -> 1174
    //   794: iload_1
    //   795: bipush #101
    //   797: if_icmpeq -> 1174
    //   800: iload_1
    //   801: bipush #45
    //   803: if_icmpeq -> 1145
    //   806: iload_1
    //   807: bipush #46
    //   809: if_icmpeq -> 1123
    //   812: iload_1
    //   813: bipush #48
    //   815: if_icmplt -> 1004
    //   818: iload_1
    //   819: bipush #57
    //   821: if_icmple -> 827
    //   824: goto -> 1004
    //   827: iload #4
    //   829: iconst_1
    //   830: if_icmpeq -> 984
    //   833: iload #4
    //   835: ifne -> 841
    //   838: goto -> 984
    //   841: iload #4
    //   843: iconst_2
    //   844: if_icmpne -> 929
    //   847: lload #13
    //   849: lconst_0
    //   850: lcmp
    //   851: ifne -> 857
    //   854: goto -> 742
    //   857: ldc2_w 10
    //   860: lload #13
    //   862: lmul
    //   863: iload_1
    //   864: bipush #48
    //   866: isub
    //   867: i2l
    //   868: lsub
    //   869: lstore #15
    //   871: lload #13
    //   873: ldc2_w -922337203685477580
    //   876: lcmp
    //   877: istore_2
    //   878: iload_2
    //   879: ifgt -> 902
    //   882: iload_2
    //   883: ifne -> 897
    //   886: lload #15
    //   888: lload #13
    //   890: lcmp
    //   891: ifge -> 897
    //   894: goto -> 902
    //   897: iconst_0
    //   898: istore_2
    //   899: goto -> 904
    //   902: iconst_1
    //   903: istore_2
    //   904: iload_3
    //   905: iload_2
    //   906: iand
    //   907: istore_3
    //   908: lload #15
    //   910: lstore #13
    //   912: iload #4
    //   914: istore_2
    //   915: iload_3
    //   916: istore #9
    //   918: lload #13
    //   920: lstore #15
    //   922: iload #5
    //   924: istore #11
    //   926: goto -> 1222
    //   929: iload #4
    //   931: iconst_3
    //   932: if_icmpne -> 940
    //   935: iconst_4
    //   936: istore_2
    //   937: goto -> 915
    //   940: iload #4
    //   942: iconst_5
    //   943: if_icmpeq -> 967
    //   946: iload #4
    //   948: istore_2
    //   949: iload_3
    //   950: istore #9
    //   952: lload #13
    //   954: lstore #15
    //   956: iload #5
    //   958: istore #11
    //   960: iload #4
    //   962: bipush #6
    //   964: if_icmpne -> 1222
    //   967: bipush #7
    //   969: istore_2
    //   970: iload_3
    //   971: istore #9
    //   973: lload #13
    //   975: lstore #15
    //   977: iload #5
    //   979: istore #11
    //   981: goto -> 1222
    //   984: iload_1
    //   985: bipush #48
    //   987: isub
    //   988: ineg
    //   989: i2l
    //   990: lstore #15
    //   992: iconst_2
    //   993: istore_2
    //   994: iload_3
    //   995: istore #9
    //   997: iload #5
    //   999: istore #11
    //   1001: goto -> 1222
    //   1004: aload_0
    //   1005: iload_1
    //   1006: invokevirtual m : (C)Z
    //   1009: ifne -> 742
    //   1012: goto -> 758
    //   1015: iload #4
    //   1017: iconst_2
    //   1018: if_icmpne -> 1087
    //   1021: iload_3
    //   1022: ifeq -> 1087
    //   1025: lload #13
    //   1027: ldc2_w -9223372036854775808
    //   1030: lcmp
    //   1031: ifne -> 1039
    //   1034: iload #5
    //   1036: ifeq -> 1087
    //   1039: lload #13
    //   1041: lconst_0
    //   1042: lcmp
    //   1043: ifne -> 1051
    //   1046: iload #5
    //   1048: ifne -> 1087
    //   1051: iload #5
    //   1053: ifeq -> 1059
    //   1056: goto -> 1064
    //   1059: lload #13
    //   1061: lneg
    //   1062: lstore #13
    //   1064: aload_0
    //   1065: lload #13
    //   1067: putfield p : J
    //   1070: aload_0
    //   1071: aload_0
    //   1072: getfield k : I
    //   1075: iload #6
    //   1077: iadd
    //   1078: putfield k : I
    //   1081: bipush #15
    //   1083: istore_2
    //   1084: goto -> 1115
    //   1087: iload #4
    //   1089: iconst_2
    //   1090: if_icmpeq -> 1106
    //   1093: iload #4
    //   1095: iconst_4
    //   1096: if_icmpeq -> 1106
    //   1099: iload #4
    //   1101: bipush #7
    //   1103: if_icmpne -> 742
    //   1106: aload_0
    //   1107: iload #6
    //   1109: putfield q : I
    //   1112: bipush #16
    //   1114: istore_2
    //   1115: aload_0
    //   1116: iload_2
    //   1117: putfield o : I
    //   1120: goto -> 1253
    //   1123: iload #4
    //   1125: iconst_2
    //   1126: if_icmpne -> 742
    //   1129: iconst_3
    //   1130: istore_2
    //   1131: iload_3
    //   1132: istore #9
    //   1134: lload #13
    //   1136: lstore #15
    //   1138: iload #5
    //   1140: istore #11
    //   1142: goto -> 1222
    //   1145: iload #4
    //   1147: ifne -> 1165
    //   1150: iconst_1
    //   1151: istore_2
    //   1152: iconst_1
    //   1153: istore #11
    //   1155: iload_3
    //   1156: istore #9
    //   1158: lload #13
    //   1160: lstore #15
    //   1162: goto -> 1222
    //   1165: iload #4
    //   1167: iconst_5
    //   1168: if_icmpne -> 742
    //   1171: goto -> 1208
    //   1174: iload #4
    //   1176: iconst_2
    //   1177: if_icmpeq -> 1186
    //   1180: iload #4
    //   1182: iconst_4
    //   1183: if_icmpne -> 742
    //   1186: iconst_5
    //   1187: istore_2
    //   1188: iload_3
    //   1189: istore #9
    //   1191: lload #13
    //   1193: lstore #15
    //   1195: iload #5
    //   1197: istore #11
    //   1199: goto -> 1222
    //   1202: iload #4
    //   1204: iconst_5
    //   1205: if_icmpne -> 742
    //   1208: bipush #6
    //   1210: istore_2
    //   1211: iload #5
    //   1213: istore #11
    //   1215: lload #13
    //   1217: lstore #15
    //   1219: iload_3
    //   1220: istore #9
    //   1222: iload #6
    //   1224: iconst_1
    //   1225: iadd
    //   1226: istore #6
    //   1228: iload #8
    //   1230: istore #12
    //   1232: iload #7
    //   1234: istore #10
    //   1236: iload_2
    //   1237: istore #4
    //   1239: iload #9
    //   1241: istore_3
    //   1242: lload #15
    //   1244: lstore #13
    //   1246: iload #11
    //   1248: istore #5
    //   1250: goto -> 716
    //   1253: iload_2
    //   1254: ifeq -> 1259
    //   1257: iload_2
    //   1258: ireturn
    //   1259: aload_0
    //   1260: aload_0
    //   1261: getfield j : [C
    //   1264: aload_0
    //   1265: getfield k : I
    //   1268: caload
    //   1269: invokevirtual m : (C)Z
    //   1272: ifeq -> 1288
    //   1275: aload_0
    //   1276: invokevirtual d : ()V
    //   1279: aload_0
    //   1280: bipush #10
    //   1282: putfield o : I
    //   1285: bipush #10
    //   1287: ireturn
    //   1288: aload_0
    //   1289: ldc 'Expected value'
    //   1291: invokevirtual F : (Ljava/lang/String;)Ljava/io/IOException;
    //   1294: pop
    //   1295: aconst_null
    //   1296: athrow
    //   1297: iconst_1
    //   1298: istore_2
    //   1299: goto -> 350
    //   1302: iload_2
    //   1303: iconst_1
    //   1304: if_icmpne -> 1321
    //   1307: iconst_4
    //   1308: istore_2
    //   1309: aload_0
    //   1310: iload_2
    //   1311: putfield o : I
    //   1314: iload_2
    //   1315: ireturn
    //   1316: iconst_3
    //   1317: istore_2
    //   1318: goto -> 1309
    //   1321: iload_2
    //   1322: iconst_1
    //   1323: if_icmpeq -> 1343
    //   1326: iload_2
    //   1327: iconst_2
    //   1328: if_icmpne -> 1334
    //   1331: goto -> 1343
    //   1334: aload_0
    //   1335: ldc 'Unexpected value'
    //   1337: invokevirtual F : (Ljava/lang/String;)Ljava/io/IOException;
    //   1340: pop
    //   1341: aconst_null
    //   1342: athrow
    //   1343: aload_0
    //   1344: invokevirtual d : ()V
    //   1347: aload_0
    //   1348: aload_0
    //   1349: getfield k : I
    //   1352: iconst_1
    //   1353: isub
    //   1354: putfield k : I
    //   1357: bipush #7
    //   1359: istore_2
    //   1360: goto -> 350
    //   1363: aload_0
    //   1364: invokevirtual d : ()V
    //   1367: bipush #8
    //   1369: istore_2
    //   1370: goto -> 350
    //   1373: bipush #9
    //   1375: istore_2
    //   1376: goto -> 350
    //   1379: new java/lang/IllegalStateException
    //   1382: dup
    //   1383: ldc 'JsonReader is closed'
    //   1385: invokespecial <init> : (Ljava/lang/String;)V
    //   1388: athrow
    //   1389: aload #17
    //   1391: iload_3
    //   1392: iconst_1
    //   1393: isub
    //   1394: iconst_4
    //   1395: iastore
    //   1396: iload_2
    //   1397: iconst_5
    //   1398: if_icmpne -> 1443
    //   1401: aload_0
    //   1402: iconst_1
    //   1403: invokevirtual t : (Z)I
    //   1406: istore_3
    //   1407: iload_3
    //   1408: bipush #44
    //   1410: if_icmpeq -> 1443
    //   1413: iload_3
    //   1414: bipush #59
    //   1416: if_icmpeq -> 1439
    //   1419: iload_3
    //   1420: bipush #125
    //   1422: if_icmpne -> 1430
    //   1425: iconst_2
    //   1426: istore_2
    //   1427: goto -> 350
    //   1430: aload_0
    //   1431: ldc 'Unterminated object'
    //   1433: invokevirtual F : (Ljava/lang/String;)Ljava/io/IOException;
    //   1436: pop
    //   1437: aconst_null
    //   1438: athrow
    //   1439: aload_0
    //   1440: invokevirtual d : ()V
    //   1443: aload_0
    //   1444: iconst_1
    //   1445: invokevirtual t : (Z)I
    //   1448: istore_3
    //   1449: iload_3
    //   1450: bipush #34
    //   1452: if_icmpeq -> 1534
    //   1455: iload_3
    //   1456: bipush #39
    //   1458: if_icmpeq -> 1524
    //   1461: iload_3
    //   1462: bipush #125
    //   1464: if_icmpeq -> 1505
    //   1467: aload_0
    //   1468: invokevirtual d : ()V
    //   1471: aload_0
    //   1472: aload_0
    //   1473: getfield k : I
    //   1476: iconst_1
    //   1477: isub
    //   1478: putfield k : I
    //   1481: aload_0
    //   1482: iload_3
    //   1483: i2c
    //   1484: invokevirtual m : (C)Z
    //   1487: ifeq -> 1496
    //   1490: bipush #14
    //   1492: istore_2
    //   1493: goto -> 350
    //   1496: aload_0
    //   1497: ldc 'Expected name'
    //   1499: invokevirtual F : (Ljava/lang/String;)Ljava/io/IOException;
    //   1502: pop
    //   1503: aconst_null
    //   1504: athrow
    //   1505: iload_2
    //   1506: iconst_5
    //   1507: if_icmpeq -> 1515
    //   1510: iconst_2
    //   1511: istore_2
    //   1512: goto -> 1309
    //   1515: aload_0
    //   1516: ldc 'Expected name'
    //   1518: invokevirtual F : (Ljava/lang/String;)Ljava/io/IOException;
    //   1521: pop
    //   1522: aconst_null
    //   1523: athrow
    //   1524: aload_0
    //   1525: invokevirtual d : ()V
    //   1528: bipush #12
    //   1530: istore_2
    //   1531: goto -> 350
    //   1534: bipush #13
    //   1536: istore_2
    //   1537: goto -> 350
  }
  
  public void f() {
    int j = this.o;
    int i = j;
    if (j == 0)
      i = e(); 
    if (i == 4) {
      i = this.t - 1;
      this.t = i;
      int[] arrayOfInt = this.v;
      arrayOfInt[--i] = arrayOfInt[i] + 1;
      this.o = 0;
      return;
    } 
    StringBuilder stringBuilder = c.a("Expected END_ARRAY but was ");
    stringBuilder.append(b.c(y()));
    stringBuilder.append(n());
    throw new IllegalStateException(stringBuilder.toString());
  }
  
  public void g() {
    int j = this.o;
    int i = j;
    if (j == 0)
      i = e(); 
    if (i == 2) {
      i = this.t - 1;
      this.t = i;
      this.u[i] = null;
      int[] arrayOfInt = this.v;
      arrayOfInt[--i] = arrayOfInt[i] + 1;
      this.o = 0;
      return;
    } 
    StringBuilder stringBuilder = c.a("Expected END_OBJECT but was ");
    stringBuilder.append(b.c(y()));
    stringBuilder.append(n());
    throw new IllegalStateException(stringBuilder.toString());
  }
  
  public final boolean h(int paramInt) {
    char[] arrayOfChar = this.j;
    int j = this.n;
    int i = this.k;
    this.n = j - i;
    j = this.l;
    if (j != i) {
      j -= i;
      this.l = j;
      System.arraycopy(arrayOfChar, i, arrayOfChar, 0, j);
    } else {
      this.l = 0;
    } 
    this.k = 0;
    while (true) {
      Reader reader = this.h;
      i = this.l;
      i = reader.read(arrayOfChar, i, arrayOfChar.length - i);
      if (i != -1) {
        j = this.l + i;
        this.l = j;
        i = paramInt;
        if (this.m == 0) {
          int k = this.n;
          i = paramInt;
          if (k == 0) {
            i = paramInt;
            if (j > 0) {
              i = paramInt;
              if (arrayOfChar[0] == '﻿') {
                this.k++;
                this.n = k + 1;
                i = paramInt + 1;
              } 
            } 
          } 
        } 
        paramInt = i;
        if (j >= i)
          return true; 
        continue;
      } 
      return false;
    } 
  }
  
  public String i() {
    return j(false);
  }
  
  public final String j(boolean paramBoolean) {
    StringBuilder stringBuilder = new StringBuilder();
    stringBuilder.append('$');
    int i = 0;
    while (true) {
      int j = this.t;
      if (i < j) {
        int k = this.s[i];
        if (k != 1 && k != 2) {
          if (k == 3 || k == 4 || k == 5) {
            stringBuilder.append('.');
            String[] arrayOfString = this.u;
            if (arrayOfString[i] != null)
              stringBuilder.append(arrayOfString[i]); 
          } 
        } else {
          int m = this.v[i];
          k = m;
          if (paramBoolean) {
            k = m;
            if (m > 0) {
              k = m;
              if (i == j - 1)
                k = m - 1; 
            } 
          } 
          stringBuilder.append('[');
          stringBuilder.append(k);
          stringBuilder.append(']');
        } 
        i++;
        continue;
      } 
      return stringBuilder.toString();
    } 
  }
  
  public String k() {
    return j(true);
  }
  
  public boolean l() {
    int j = this.o;
    int i = j;
    if (j == 0)
      i = e(); 
    return (i != 2 && i != 4 && i != 17);
  }
  
  public final boolean m(char paramChar) {
    if (paramChar != '\t' && paramChar != '\n' && paramChar != '\f' && paramChar != '\r' && paramChar != ' ')
      if (paramChar != '#') {
        if (paramChar != ',')
          if (paramChar != '/' && paramChar != '=') {
            if (paramChar != '{' && paramChar != '}' && paramChar != ':')
              if (paramChar != ';') {
                switch (paramChar) {
                  default:
                    return true;
                  case '\\':
                    d();
                    break;
                  case '[':
                  case ']':
                    break;
                } 
                return false;
              }  
            return false;
          }  
        return false;
      }  
    return false;
  }
  
  public String n() {
    StringBuilder stringBuilder = android.support.v4.media.a.a(" at line ", this.m + 1, " column ", this.k - this.n + 1, " path ");
    stringBuilder.append(i());
    return stringBuilder.toString();
  }
  
  public boolean o() {
    int j = this.o;
    int i = j;
    if (j == 0)
      i = e(); 
    if (i == 5) {
      this.o = 0;
      int[] arrayOfInt = this.v;
      i = this.t - 1;
      arrayOfInt[i] = arrayOfInt[i] + 1;
      return true;
    } 
    if (i == 6) {
      this.o = 0;
      int[] arrayOfInt = this.v;
      i = this.t - 1;
      arrayOfInt[i] = arrayOfInt[i] + 1;
      return false;
    } 
    StringBuilder stringBuilder = c.a("Expected a boolean but was ");
    stringBuilder.append(b.c(y()));
    stringBuilder.append(n());
    throw new IllegalStateException(stringBuilder.toString());
  }
  
  public double p() {
    int j = this.o;
    int i = j;
    if (j == 0)
      i = e(); 
    if (i == 15) {
      this.o = 0;
      int[] arrayOfInt = this.v;
      i = this.t - 1;
      arrayOfInt[i] = arrayOfInt[i] + 1;
      return this.p;
    } 
    if (i == 16) {
      this.r = new String(this.j, this.k, this.q);
      this.k += this.q;
    } else {
      StringBuilder stringBuilder;
      if (i == 8 || i == 9) {
        byte b;
        if (i == 8) {
          b = 39;
        } else {
          b = 34;
        } 
        String str = v(b);
      } else if (i == 10) {
        String str = x();
      } else {
        if (i != 11) {
          stringBuilder = c.a("Expected a double but was ");
          stringBuilder.append(b.c(y()));
          stringBuilder.append(n());
          throw new IllegalStateException(stringBuilder.toString());
        } 
        this.o = 11;
        double d1 = Double.parseDouble(this.r);
      } 
      this.r = (String)stringBuilder;
    } 
    this.o = 11;
    double d = Double.parseDouble(this.r);
  }
  
  public int q() {
    int j = this.o;
    int i = j;
    if (j == 0)
      i = e(); 
    if (i == 15) {
      long l = this.p;
      i = (int)l;
      if (l == i) {
        this.o = 0;
        int[] arrayOfInt = this.v;
        j = this.t - 1;
        arrayOfInt[j] = arrayOfInt[j] + 1;
        return i;
      } 
      StringBuilder stringBuilder1 = c.a("Expected an int but was ");
      stringBuilder1.append(this.p);
      stringBuilder1.append(n());
      throw new NumberFormatException(stringBuilder1.toString());
    } 
    if (i == 16) {
      this.r = new String(this.j, this.k, this.q);
      this.k += this.q;
    } else if (i == 8 || i == 9 || i == 10) {
      String str;
      if (i == 10) {
        str = x();
      } else {
        byte b;
        if (i == 8) {
          b = 39;
        } else {
          b = 34;
        } 
        str = v(b);
      } 
      this.r = str;
      try {
        i = Integer.parseInt(this.r);
        this.o = 0;
        int[] arrayOfInt = this.v;
        j = this.t - 1;
        arrayOfInt[j] = arrayOfInt[j] + 1;
        return i;
      } catch (NumberFormatException numberFormatException) {}
    } else {
      StringBuilder stringBuilder1 = c.a("Expected an int but was ");
      stringBuilder1.append(b.c(y()));
      stringBuilder1.append(n());
      throw new IllegalStateException(stringBuilder1.toString());
    } 
    this.o = 11;
    double d = Double.parseDouble(this.r);
    i = (int)d;
    if (i == d) {
      this.r = null;
      this.o = 0;
      int[] arrayOfInt = this.v;
      j = this.t - 1;
      arrayOfInt[j] = arrayOfInt[j] + 1;
      return i;
    } 
    StringBuilder stringBuilder = c.a("Expected an int but was ");
    stringBuilder.append(this.r);
    stringBuilder.append(n());
    throw new NumberFormatException(stringBuilder.toString());
  }
  
  public long r() {
    int j = this.o;
    int i = j;
    if (j == 0)
      i = e(); 
    if (i == 15) {
      this.o = 0;
      int[] arrayOfInt = this.v;
      i = this.t - 1;
      arrayOfInt[i] = arrayOfInt[i] + 1;
      return this.p;
    } 
    if (i == 16) {
      this.r = new String(this.j, this.k, this.q);
      this.k += this.q;
    } else if (i == 8 || i == 9 || i == 10) {
      String str;
      if (i == 10) {
        str = x();
      } else {
        byte b;
        if (i == 8) {
          b = 39;
        } else {
          b = 34;
        } 
        str = v(b);
      } 
      this.r = str;
      try {
        long l1 = Long.parseLong(this.r);
        this.o = 0;
        int[] arrayOfInt = this.v;
        i = this.t - 1;
        arrayOfInt[i] = arrayOfInt[i] + 1;
        return l1;
      } catch (NumberFormatException numberFormatException) {}
    } else {
      StringBuilder stringBuilder1 = c.a("Expected a long but was ");
      stringBuilder1.append(b.c(y()));
      stringBuilder1.append(n());
      throw new IllegalStateException(stringBuilder1.toString());
    } 
    this.o = 11;
    double d = Double.parseDouble(this.r);
    long l = (long)d;
    if (l == d) {
      this.r = null;
      this.o = 0;
      int[] arrayOfInt = this.v;
      i = this.t - 1;
      arrayOfInt[i] = arrayOfInt[i] + 1;
      return l;
    } 
    StringBuilder stringBuilder = c.a("Expected a long but was ");
    stringBuilder.append(this.r);
    stringBuilder.append(n());
    throw new NumberFormatException(stringBuilder.toString());
  }
  
  public String s() {
    String str;
    int j = this.o;
    int i = j;
    if (j == 0)
      i = e(); 
    if (i == 14) {
      str = x();
    } else {
      byte b;
      if (i == 12) {
        b = 39;
      } else if (i == 13) {
        b = 34;
      } else {
        StringBuilder stringBuilder = c.a("Expected a name but was ");
        stringBuilder.append(b.c(y()));
        stringBuilder.append(n());
        throw new IllegalStateException(stringBuilder.toString());
      } 
      str = v(b);
    } 
    this.o = 0;
    this.u[this.t - 1] = str;
    return str;
  }
  
  public final int t(boolean paramBoolean) {
    char[] arrayOfChar = this.j;
    label70: while (true) {
      int i = this.k;
      label69: while (true) {
        int j = this.l;
        while (true) {
          StringBuilder stringBuilder2;
          boolean bool = true;
          int n = i;
          int k = j;
          if (i == j) {
            this.k = i;
            if (!h(1)) {
              if (!paramBoolean)
                return -1; 
              stringBuilder2 = c.a("End of input");
              stringBuilder2.append(n());
              throw new EOFException(stringBuilder2.toString());
            } 
            n = this.k;
            k = this.l;
          } 
          i = n + 1;
          StringBuilder stringBuilder1 = stringBuilder2[n];
          if (stringBuilder1 == 10) {
            this.m++;
            this.n = i;
          } else if (stringBuilder1 != 32 && stringBuilder1 != 13 && stringBuilder1 != 9) {
            int i1;
            if (stringBuilder1 == 47) {
              this.k = i;
              if (i == k) {
                this.k = i - 1;
                boolean bool1 = h(2);
                this.k++;
                if (!bool1)
                  return stringBuilder1; 
              } 
              d();
              i = this.k;
              StringBuilder stringBuilder = stringBuilder2[i];
              if (stringBuilder != 42) {
                if (stringBuilder != 47)
                  return stringBuilder1; 
                this.k = i + 1;
              } else {
                this.k = i + 1;
                label64: while (true) {
                  k = this.k;
                  i1 = this.l;
                  i = 0;
                  if (k + 2 <= i1 || h(2)) {
                    char[] arrayOfChar1 = this.j;
                    k = this.k;
                    if (arrayOfChar1[k] == '\n') {
                      this.m++;
                      this.n = k + 1;
                      continue;
                    } 
                    while (true) {
                      k = bool;
                      if (i < 2) {
                        if (this.j[this.k + i] != "*/".charAt(i)) {
                          this.k++;
                          continue label64;
                        } 
                        i++;
                        continue;
                      } 
                      break;
                    } 
                    break;
                  } 
                  k = 0;
                  break;
                } 
                if (k != 0) {
                  i = this.k + 2;
                  continue label69;
                } 
                F("Unterminated comment");
                throw null;
              } 
            } else {
              this.k = i;
              if (i1 == 35) {
                d();
              } else {
                return i1;
              } 
            } 
            C();
            continue label70;
          } 
          int m = k;
        } 
        break;
      } 
      break;
    } 
  }
  
  public String toString() {
    StringBuilder stringBuilder = new StringBuilder();
    stringBuilder.append(getClass().getSimpleName());
    stringBuilder.append(n());
    return stringBuilder.toString();
  }
  
  public void u() {
    int j = this.o;
    int i = j;
    if (j == 0)
      i = e(); 
    if (i == 7) {
      this.o = 0;
      int[] arrayOfInt = this.v;
      i = this.t - 1;
      arrayOfInt[i] = arrayOfInt[i] + 1;
      return;
    } 
    StringBuilder stringBuilder = c.a("Expected null but was ");
    stringBuilder.append(b.c(y()));
    stringBuilder.append(n());
    throw new IllegalStateException(stringBuilder.toString());
  }
  
  public final String v(char paramChar) {
    char[] arrayOfChar = this.j;
    StringBuilder stringBuilder;
    label30: for (stringBuilder = null;; stringBuilder = stringBuilder1) {
      StringBuilder stringBuilder1;
      int j = this.k;
      int k = this.l;
      int i = j;
      while (true) {
        int m = i;
        if (m < k) {
          i = m + 1;
          m = arrayOfChar[m];
          if (m == paramChar) {
            this.k = i;
            int n = i - j - 1;
            if (stringBuilder == null)
              return new String(arrayOfChar, j, n); 
            stringBuilder.append(arrayOfChar, j, n);
            return stringBuilder.toString();
          } 
          if (m == 92) {
            this.k = i;
            i = i - j - 1;
            StringBuilder stringBuilder2 = stringBuilder;
            if (stringBuilder == null)
              stringBuilder2 = new StringBuilder(Math.max((i + 1) * 2, 16)); 
            stringBuilder2.append(arrayOfChar, j, i);
            stringBuilder2.append(A());
            stringBuilder = stringBuilder2;
            continue label30;
          } 
          if (m == 10) {
            this.m++;
            this.n = i;
          } 
          continue;
        } 
        stringBuilder1 = stringBuilder;
        if (stringBuilder == null)
          stringBuilder1 = new StringBuilder(Math.max((m - j) * 2, 16)); 
        stringBuilder1.append(arrayOfChar, j, m - j);
        this.k = m;
        if (h(1))
          break; 
        F("Unterminated string");
        throw null;
      } 
    } 
  }
  
  public String w() {
    String str;
    int j = this.o;
    int i = j;
    if (j == 0)
      i = e(); 
    if (i == 10) {
      str = x();
    } else {
      byte b;
      if (i == 8) {
        b = 39;
      } else if (i == 9) {
        b = 34;
      } else {
        StringBuilder stringBuilder;
        if (i == 11) {
          String str1 = this.r;
          this.r = null;
        } else if (i == 15) {
          String str1 = Long.toString(this.p);
        } else {
          if (i == 16) {
            String str1 = new String(this.j, this.k, this.q);
            this.k += this.q;
            this.o = 0;
            int[] arrayOfInt2 = this.v;
            i = this.t - 1;
            arrayOfInt2[i] = arrayOfInt2[i] + 1;
            return str1;
          } 
          stringBuilder = c.a("Expected a string but was ");
          stringBuilder.append(b.c(y()));
          stringBuilder.append(n());
          throw new IllegalStateException(stringBuilder.toString());
        } 
        this.o = 0;
        int[] arrayOfInt1 = this.v;
        i = this.t - 1;
        arrayOfInt1[i] = arrayOfInt1[i] + 1;
        return (String)stringBuilder;
      } 
      str = v(b);
    } 
    this.o = 0;
    int[] arrayOfInt = this.v;
    i = this.t - 1;
    arrayOfInt[i] = arrayOfInt[i] + 1;
    return str;
  }
  
  public final String x() {
    byte b;
    String str;
    boolean bool = false;
    StringBuilder stringBuilder = null;
    while (true) {
      b = 0;
      while (true) {
        int i = this.k;
        if (i + b < this.l) {
          i = this.j[i + b];
          if (i != 9 && i != 10 && i != 12 && i != 13 && i != 32)
            if (i != 35) {
              if (i != 44)
                if (i != 47 && i != 61) {
                  if (i != 123 && i != 125 && i != 58)
                    if (i != 59) {
                      switch (i) {
                        case 92:
                          d();
                          break;
                        case 91:
                        case 93:
                          break;
                      } 
                      continue;
                    }  
                  break;
                }  
              break;
            }  
          break;
        } 
        if (b < this.j.length) {
          if (h(b + 1))
            continue; 
          break;
        } 
        StringBuilder stringBuilder1 = stringBuilder;
        if (stringBuilder == null)
          stringBuilder1 = new StringBuilder(Math.max(b, 16)); 
        stringBuilder1.append(this.j, this.k, b);
        this.k += b;
        stringBuilder = stringBuilder1;
        if (!h(1)) {
          stringBuilder = stringBuilder1;
          b = bool;
          break;
        } 
      } 
      break;
    } 
    if (stringBuilder == null) {
      str = new String(this.j, this.k, b);
    } else {
      str.append(this.j, this.k, b);
      str = str.toString();
    } 
    this.k += b;
    return str;
  }
  
  public int y() {
    int j = this.o;
    int i = j;
    if (j == 0)
      i = e(); 
    switch (i) {
      default:
        throw new AssertionError();
      case 17:
        return 10;
      case 15:
      case 16:
        return 7;
      case 12:
      case 13:
      case 14:
        return 5;
      case 8:
      case 9:
      case 10:
      case 11:
        return 6;
      case 7:
        return 9;
      case 5:
      case 6:
        return 8;
      case 4:
        return 2;
      case 3:
        return 1;
      case 2:
        return 4;
      case 1:
        break;
    } 
    return 3;
  }
  
  public final void z(int paramInt) {
    int i = this.t;
    int[] arrayOfInt = this.s;
    if (i == arrayOfInt.length) {
      i *= 2;
      this.s = Arrays.copyOf(arrayOfInt, i);
      this.v = Arrays.copyOf(this.v, i);
      this.u = Arrays.<String>copyOf(this.u, i);
    } 
    arrayOfInt = this.s;
    i = this.t;
    this.t = i + 1;
    arrayOfInt[i] = paramInt;
  }
  
  public class a extends b {
    public void n(a param1a) {
      f f;
      if (param1a instanceof f) {
        f = (f)param1a;
        f.G(5);
        Map.Entry entry = ((Iterator<Map.Entry>)f.I()).next();
        f.K(entry.getValue());
        f.K(new r((String)entry.getKey()));
        return;
      } 
      int j = ((a)f).o;
      int i = j;
      if (j == 0)
        i = f.e(); 
      if (i == 13) {
        i = 9;
      } else if (i == 12) {
        i = 8;
      } else if (i == 14) {
        i = 10;
      } else {
        StringBuilder stringBuilder = c.a("Expected a name but was ");
        stringBuilder.append(b.c(f.y()));
        stringBuilder.append(f.n());
        throw new IllegalStateException(stringBuilder.toString());
      } 
      ((a)f).o = i;
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Luxury Logo Maker_ Logo Design-dex2jar.jar!\a6\a.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */