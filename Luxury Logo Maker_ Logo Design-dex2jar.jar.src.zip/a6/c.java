package a6;

import j.f;
import java.io.Closeable;
import java.io.Flushable;
import java.io.IOException;
import java.io.Writer;
import java.math.BigDecimal;
import java.math.BigInteger;
import java.util.Arrays;
import java.util.Objects;
import java.util.concurrent.atomic.AtomicInteger;
import java.util.concurrent.atomic.AtomicLong;
import java.util.regex.Pattern;

public class c implements Closeable, Flushable {
  public static final Pattern o = Pattern.compile("-?(?:0|[1-9][0-9]*)(?:\\.[0-9]+)?(?:[eE][-+]?[0-9]+)?");
  
  public static final String[] p = new String[128];
  
  public final Writer h;
  
  public int[] i = new int[32];
  
  public int j = 0;
  
  public String k;
  
  public boolean l;
  
  public String m;
  
  public boolean n;
  
  static {
    for (int i = 0; i <= 31; i++) {
      p[i] = String.format("\\u%04x", new Object[] { Integer.valueOf(i) });
    } 
    String[] arrayOfString = p;
    arrayOfString[34] = "\\\"";
    arrayOfString[92] = "\\\\";
    arrayOfString[9] = "\\t";
    arrayOfString[8] = "\\b";
    arrayOfString[10] = "\\n";
    arrayOfString[13] = "\\r";
    arrayOfString[12] = "\\f";
    arrayOfString = (String[])arrayOfString.clone();
    arrayOfString[60] = "\\u003c";
    arrayOfString[62] = "\\u003e";
    arrayOfString[38] = "\\u0026";
    arrayOfString[61] = "\\u003d";
    arrayOfString[39] = "\\u0027";
  }
  
  public c(Writer paramWriter) {
    k(6);
    this.k = ":";
    this.n = true;
    Objects.requireNonNull(paramWriter, "out == null");
    Writer writer = paramWriter;
    this.h = paramWriter;
  }
  
  public final void a() {
    int i = j();
    byte b = 2;
    if (i != 1)
      if (i != 2) {
        if (i != 4) {
          byte b1 = 7;
          b = b1;
          if (i != 6)
            if (i == 7) {
              if (this.l) {
                b = b1;
              } else {
                throw new IllegalStateException("JSON must have only one top-level value.");
              } 
            } else {
              throw new IllegalStateException("Nesting problem.");
            }  
        } else {
          this.h.append(this.k);
          l(5);
          return;
        } 
      } else {
        this.h.append(',');
        return;
      }  
    l(b);
  }
  
  public c c() {
    t();
    a();
    k(1);
    this.h.write(91);
    return this;
  }
  
  public void close() {
    this.h.close();
    int i = this.j;
    if (i <= 1 && (i != 1 || this.i[i - 1] == 7)) {
      this.j = 0;
      return;
    } 
    throw new IOException("Incomplete document");
  }
  
  public c d() {
    t();
    a();
    k(3);
    this.h.write(123);
    return this;
  }
  
  public final c e(int paramInt1, int paramInt2, char paramChar) {
    int i = j();
    if (i == paramInt2 || i == paramInt1) {
      if (this.m == null) {
        this.j--;
        this.h.write(paramChar);
        return this;
      } 
      StringBuilder stringBuilder = android.support.v4.media.c.a("Dangling name: ");
      stringBuilder.append(this.m);
      throw new IllegalStateException(stringBuilder.toString());
    } 
    throw new IllegalStateException("Nesting problem.");
  }
  
  public c f() {
    e(1, 2, ']');
    return this;
  }
  
  public void flush() {
    if (this.j != 0) {
      this.h.flush();
      return;
    } 
    throw new IllegalStateException("JsonWriter is closed.");
  }
  
  public c g() {
    e(3, 5, '}');
    return this;
  }
  
  public c h(String paramString) {
    Objects.requireNonNull(paramString, "name == null");
    if (this.m == null) {
      if (this.j != 0) {
        this.m = paramString;
        return this;
      } 
      throw new IllegalStateException("JsonWriter is closed.");
    } 
    throw new IllegalStateException();
  }
  
  public c i() {
    if (this.m != null)
      if (this.n) {
        t();
      } else {
        this.m = null;
        return this;
      }  
    a();
    this.h.write("null");
    return this;
  }
  
  public final int j() {
    int i = this.j;
    if (i != 0)
      return this.i[i - 1]; 
    throw new IllegalStateException("JsonWriter is closed.");
  }
  
  public final void k(int paramInt) {
    int i = this.j;
    int[] arrayOfInt = this.i;
    if (i == arrayOfInt.length)
      this.i = Arrays.copyOf(arrayOfInt, i * 2); 
    arrayOfInt = this.i;
    i = this.j;
    this.j = i + 1;
    arrayOfInt[i] = paramInt;
  }
  
  public final void l(int paramInt) {
    this.i[this.j - 1] = paramInt;
  }
  
  public final void m(String paramString) {
    Object object;
    String[] arrayOfString = p;
    this.h.write(34);
    int j = paramString.length();
    int i = 0;
    boolean bool = false;
    while (i < j) {
      String str;
      char c1 = paramString.charAt(i);
      if (c1 < '') {
        String str1 = arrayOfString[c1];
        str = str1;
        if (str1 == null) {
          Object object1 = object;
          continue;
        } 
      } else if (c1 == ' ') {
        str = "\\u2028";
      } else {
        Object object1 = object;
        if (c1 == ' ') {
          str = "\\u2029";
        } else {
          continue;
        } 
      } 
      if (object < i)
        this.h.write(paramString, object, i - object); 
      this.h.write(str);
      int k = i + 1;
      continue;
      i++;
      object = SYNTHETIC_LOCAL_VARIABLE_4;
    } 
    if (object < j)
      this.h.write(paramString, object, j - object); 
    this.h.write(34);
  }
  
  public c n(double paramDouble) {
    t();
    if (this.l || (!Double.isNaN(paramDouble) && !Double.isInfinite(paramDouble))) {
      a();
      this.h.append(Double.toString(paramDouble));
      return this;
    } 
    StringBuilder stringBuilder = new StringBuilder();
    stringBuilder.append("Numeric values must be finite, but was ");
    stringBuilder.append(paramDouble);
    throw new IllegalArgumentException(stringBuilder.toString());
  }
  
  public c o(long paramLong) {
    t();
    a();
    this.h.write(Long.toString(paramLong));
    return this;
  }
  
  public c p(Boolean paramBoolean) {
    String str;
    if (paramBoolean == null)
      return i(); 
    t();
    a();
    Writer writer = this.h;
    if (paramBoolean.booleanValue()) {
      str = "true";
    } else {
      str = "false";
    } 
    writer.write(str);
    return this;
  }
  
  public c q(Number paramNumber) {
    boolean bool;
    if (paramNumber == null)
      return i(); 
    t();
    String str = paramNumber.toString();
    if (str.equals("-Infinity") || str.equals("Infinity") || str.equals("NaN")) {
      if (!this.l)
        throw new IllegalArgumentException(f.a("Numeric values must be finite, but was ", str)); 
      a();
      this.h.append(str);
      return this;
    } 
    Class<?> clazz = paramNumber.getClass();
    if (clazz == Integer.class || clazz == Long.class || clazz == Double.class || clazz == Float.class || clazz == Byte.class || clazz == Short.class || clazz == BigDecimal.class || clazz == BigInteger.class || clazz == AtomicInteger.class || clazz == AtomicLong.class) {
      bool = true;
    } else {
      bool = false;
    } 
    if (!bool && !o.matcher(str).matches()) {
      StringBuilder stringBuilder = new StringBuilder();
      stringBuilder.append("String created by ");
      stringBuilder.append(clazz);
      stringBuilder.append(" is not a valid JSON number: ");
      stringBuilder.append(str);
      throw new IllegalArgumentException(stringBuilder.toString());
    } 
    a();
    this.h.append(str);
    return this;
  }
  
  public c r(String paramString) {
    if (paramString == null)
      return i(); 
    t();
    a();
    m(paramString);
    return this;
  }
  
  public c s(boolean paramBoolean) {
    String str;
    t();
    a();
    Writer writer = this.h;
    if (paramBoolean) {
      str = "true";
    } else {
      str = "false";
    } 
    writer.write(str);
    return this;
  }
  
  public final void t() {
    if (this.m != null) {
      int i = j();
      if (i == 5) {
        this.h.write(44);
      } else if (i != 3) {
        throw new IllegalStateException("Nesting problem.");
      } 
      l(4);
      m(this.m);
      this.m = null;
      return;
    } 
  }
}


/* Location:              C:\soft\dex2jar-2.0\Luxury Logo Maker_ Logo Design-dex2jar.jar!\a6\c.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */