package com.bumptech.glide.load.data;

import android.content.ContentResolver;
import android.content.res.AssetFileDescriptor;
import android.net.Uri;
import androidx.appcompat.widget.s0;
import java.io.FileNotFoundException;

public final class a extends l<AssetFileDescriptor> {
  public a(ContentResolver paramContentResolver, Uri paramUri) {
    super(paramContentResolver, paramUri);
  }
  
  public Class<AssetFileDescriptor> a() {
    return AssetFileDescriptor.class;
  }
  
  public void c(Object paramObject) {
    ((AssetFileDescriptor)paramObject).close();
  }
  
  public Object d(Uri paramUri, ContentResolver paramContentResolver) {
    AssetFileDescriptor assetFileDescriptor = paramContentResolver.openAssetFileDescriptor(paramUri, "r");
    if (assetFileDescriptor != null)
      return assetFileDescriptor; 
    throw new FileNotFoundException(s0.a("FileDescriptor is null for: ", paramUri));
  }
}


/* Location:              C:\soft\dex2jar-2.0\Luxury Logo Maker_ Logo Design-dex2jar.jar!\com\bumptech\glide\load\data\a.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */