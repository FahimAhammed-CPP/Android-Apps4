package com.bumptech.glide.load.data;

import android.content.res.AssetManager;
import java.io.InputStream;

public class m extends b<InputStream> {
  public m(AssetManager paramAssetManager, String paramString) {
    super(paramAssetManager, paramString);
  }
  
  public Class<InputStream> a() {
    return InputStream.class;
  }
  
  public void c(Object paramObject) {
    ((InputStream)paramObject).close();
  }
  
  public Object d(AssetManager paramAssetManager, String paramString) {
    return paramAssetManager.open(paramString);
  }
}


/* Location:              C:\soft\dex2jar-2.0\Luxury Logo Maker_ Logo Design-dex2jar.jar!\com\bumptech\glide\load\data\m.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */