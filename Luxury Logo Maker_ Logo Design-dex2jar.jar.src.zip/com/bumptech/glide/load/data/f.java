package com.bumptech.glide.load.data;

import java.util.HashMap;
import java.util.Map;

public class f {
  public static final e.a<?> b = new a();
  
  public final Map<Class<?>, e.a<?>> a = new HashMap<Class<?>, e.a<?>>();
  
  public class a implements e.a<Object> {
    public Class<Object> a() {
      throw new UnsupportedOperationException("Not implemented");
    }
    
    public e<Object> b(Object param1Object) {
      return new f.b(param1Object);
    }
  }
  
  public static final class b implements e<Object> {
    public final Object a;
    
    public b(Object param1Object) {
      this.a = param1Object;
    }
    
    public Object a() {
      return this.a;
    }
    
    public void b() {}
  }
}


/* Location:              C:\soft\dex2jar-2.0\Luxury Logo Maker_ Logo Design-dex2jar.jar!\com\bumptech\glide\load\data\f.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */