package com.bumptech.glide.load.data;

import android.os.Build;
import android.os.ParcelFileDescriptor;
import android.system.ErrnoException;
import android.system.Os;
import android.system.OsConstants;
import java.io.IOException;

public final class ParcelFileDescriptorRewinder implements e<ParcelFileDescriptor> {
  public final InternalRewinder a;
  
  public ParcelFileDescriptorRewinder(ParcelFileDescriptor paramParcelFileDescriptor) {
    this.a = new InternalRewinder(paramParcelFileDescriptor);
  }
  
  public static boolean c() {
    return !"robolectric".equals(Build.FINGERPRINT);
  }
  
  public void b() {}
  
  public ParcelFileDescriptor d() {
    return this.a.rewind();
  }
  
  public static final class InternalRewinder {
    public final ParcelFileDescriptor a;
    
    public InternalRewinder(ParcelFileDescriptor param1ParcelFileDescriptor) {
      this.a = param1ParcelFileDescriptor;
    }
    
    public ParcelFileDescriptor rewind() {
      try {
        Os.lseek(this.a.getFileDescriptor(), 0L, OsConstants.SEEK_SET);
        return this.a;
      } catch (ErrnoException errnoException) {
        throw new IOException(errnoException);
      } 
    }
  }
  
  public static final class a implements e.a<ParcelFileDescriptor> {
    public Class<ParcelFileDescriptor> a() {
      return ParcelFileDescriptor.class;
    }
    
    public e b(Object param1Object) {
      return new ParcelFileDescriptorRewinder((ParcelFileDescriptor)param1Object);
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Luxury Logo Maker_ Logo Design-dex2jar.jar!\com\bumptech\glide\load\data\ParcelFileDescriptorRewinder.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */