package com.bumptech.glide.load.data;

import android.content.res.AssetFileDescriptor;
import android.content.res.AssetManager;

public class h extends b<AssetFileDescriptor> {
  public h(AssetManager paramAssetManager, String paramString) {
    super(paramAssetManager, paramString);
  }
  
  public Class<AssetFileDescriptor> a() {
    return AssetFileDescriptor.class;
  }
  
  public void c(Object paramObject) {
    ((AssetFileDescriptor)paramObject).close();
  }
  
  public Object d(AssetManager paramAssetManager, String paramString) {
    return paramAssetManager.openFd(paramString);
  }
}


/* Location:              C:\soft\dex2jar-2.0\Luxury Logo Maker_ Logo Design-dex2jar.jar!\com\bumptech\glide\load\data\h.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */