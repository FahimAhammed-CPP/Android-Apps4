package com.bumptech.glide.load.data;

import com.bumptech.glide.f;

public interface d<T> {
  Class<T> a();
  
  void b();
  
  void cancel();
  
  a2.a e();
  
  void f(f paramf, a<? super T> parama);
  
  public static interface a<T> {
    void c(Exception param1Exception);
    
    void d(T param1T);
  }
}


/* Location:              C:\soft\dex2jar-2.0\Luxury Logo Maker_ Logo Design-dex2jar.jar!\com\bumptech\glide\load\data\d.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */