package com.bumptech.glide.load.data;

import a2.a;
import android.content.res.AssetManager;
import android.util.Log;
import com.bumptech.glide.f;
import java.io.IOException;

public abstract class b<T> implements d<T> {
  public final String h;
  
  public final AssetManager i;
  
  public T j;
  
  public b(AssetManager paramAssetManager, String paramString) {
    this.i = paramAssetManager;
    this.h = paramString;
  }
  
  public void b() {
    T t = this.j;
    if (t == null)
      return; 
    try {
      c(t);
      return;
    } catch (IOException iOException) {
      return;
    } 
  }
  
  public abstract void c(T paramT);
  
  public void cancel() {}
  
  public abstract T d(AssetManager paramAssetManager, String paramString);
  
  public a e() {
    return a.h;
  }
  
  public void f(f paramf, d.a<? super T> parama) {
    try {
      paramf = (f)d(this.i, this.h);
      this.j = (T)paramf;
      parama.d((T)paramf);
      return;
    } catch (IOException iOException) {
      if (Log.isLoggable("AssetPathFetcher", 3))
        Log.d("AssetPathFetcher", "Failed to load data from asset manager", iOException); 
      parama.c(iOException);
      return;
    } 
  }
}


/* Location:              C:\soft\dex2jar-2.0\Luxury Logo Maker_ Logo Design-dex2jar.jar!\com\bumptech\glide\load\data\b.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */