package com.bumptech.glide.load.data;

import androidx.appcompat.widget.y;
import java.io.FilterInputStream;
import java.io.InputStream;

public final class g extends FilterInputStream {
  public static final byte[] j = new byte[] { 
      -1, -31, 0, 28, 69, 120, 105, 102, 0, 0, 
      77, 77, 0, 0, 0, 0, 0, 8, 0, 1, 
      1, 18, 0, 2, 0, 0, 0, 1, 0 };
  
  public static final int k = 31;
  
  public final byte h;
  
  public int i;
  
  public g(InputStream paramInputStream, int paramInt) {
    super(paramInputStream);
    if (paramInt >= -1 && paramInt <= 8) {
      this.h = (byte)paramInt;
      return;
    } 
    throw new IllegalArgumentException(y.a("Cannot add invalid orientation: ", paramInt));
  }
  
  public void mark(int paramInt) {
    throw new UnsupportedOperationException();
  }
  
  public boolean markSupported() {
    return false;
  }
  
  public int read() {
    // Byte code:
    //   0: aload_0
    //   1: getfield i : I
    //   4: istore_1
    //   5: iload_1
    //   6: iconst_2
    //   7: if_icmplt -> 50
    //   10: getstatic com/bumptech/glide/load/data/g.k : I
    //   13: istore_2
    //   14: iload_1
    //   15: iload_2
    //   16: if_icmple -> 22
    //   19: goto -> 50
    //   22: iload_1
    //   23: iload_2
    //   24: if_icmpne -> 35
    //   27: aload_0
    //   28: getfield h : B
    //   31: istore_1
    //   32: goto -> 55
    //   35: getstatic com/bumptech/glide/load/data/g.j : [B
    //   38: iload_1
    //   39: iconst_2
    //   40: isub
    //   41: baload
    //   42: sipush #255
    //   45: iand
    //   46: istore_1
    //   47: goto -> 55
    //   50: aload_0
    //   51: invokespecial read : ()I
    //   54: istore_1
    //   55: iload_1
    //   56: iconst_m1
    //   57: if_icmpeq -> 70
    //   60: aload_0
    //   61: aload_0
    //   62: getfield i : I
    //   65: iconst_1
    //   66: iadd
    //   67: putfield i : I
    //   70: iload_1
    //   71: ireturn
  }
  
  public int read(byte[] paramArrayOfbyte, int paramInt1, int paramInt2) {
    int i = this.i;
    int j = k;
    if (i > j) {
      paramInt1 = super.read(paramArrayOfbyte, paramInt1, paramInt2);
    } else if (i == j) {
      paramArrayOfbyte[paramInt1] = this.h;
      paramInt1 = 1;
    } else if (i < 2) {
      paramInt1 = super.read(paramArrayOfbyte, paramInt1, 2 - i);
    } else {
      paramInt2 = Math.min(j - i, paramInt2);
      System.arraycopy(j, this.i - 2, paramArrayOfbyte, paramInt1, paramInt2);
      paramInt1 = paramInt2;
    } 
    if (paramInt1 > 0)
      this.i += paramInt1; 
    return paramInt1;
  }
  
  public void reset() {
    throw new UnsupportedOperationException();
  }
  
  public long skip(long paramLong) {
    paramLong = super.skip(paramLong);
    if (paramLong > 0L)
      this.i = (int)(this.i + paramLong); 
    return paramLong;
  }
}


/* Location:              C:\soft\dex2jar-2.0\Luxury Logo Maker_ Logo Design-dex2jar.jar!\com\bumptech\glide\load\data\g.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */