package com.bumptech.glide.load.data;

import android.content.ContentResolver;
import android.content.res.AssetFileDescriptor;
import android.net.Uri;
import android.os.ParcelFileDescriptor;
import androidx.appcompat.widget.s0;
import java.io.FileNotFoundException;

public class i extends l<ParcelFileDescriptor> {
  public i(ContentResolver paramContentResolver, Uri paramUri) {
    super(paramContentResolver, paramUri);
  }
  
  public Class<ParcelFileDescriptor> a() {
    return ParcelFileDescriptor.class;
  }
  
  public void c(Object paramObject) {
    ((ParcelFileDescriptor)paramObject).close();
  }
  
  public Object d(Uri paramUri, ContentResolver paramContentResolver) {
    AssetFileDescriptor assetFileDescriptor = paramContentResolver.openAssetFileDescriptor(paramUri, "r");
    if (assetFileDescriptor != null)
      return assetFileDescriptor.getParcelFileDescriptor(); 
    throw new FileNotFoundException(s0.a("FileDescriptor is null for: ", paramUri));
  }
}


/* Location:              C:\soft\dex2jar-2.0\Luxury Logo Maker_ Logo Design-dex2jar.jar!\com\bumptech\glide\load\data\i.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */