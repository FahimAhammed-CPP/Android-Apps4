package com.bumptech.glide.load.data;

import d2.b;
import java.io.OutputStream;

public final class c extends OutputStream {
  public final OutputStream h;
  
  public byte[] i;
  
  public b j;
  
  public int k;
  
  public c(OutputStream paramOutputStream, b paramb) {
    this.h = paramOutputStream;
    this.j = paramb;
    this.i = (byte[])paramb.e(65536, byte[].class);
  }
  
  public void close() {
    try {
      flush();
      this.h.close();
      byte[] arrayOfByte = this.i;
      return;
    } finally {
      this.h.close();
    } 
  }
  
  public void flush() {
    int i = this.k;
    if (i > 0) {
      this.h.write(this.i, 0, i);
      this.k = 0;
    } 
    this.h.flush();
  }
  
  public void write(int paramInt) {
    byte[] arrayOfByte = this.i;
    int i = this.k;
    int j = i + 1;
    this.k = j;
    arrayOfByte[i] = (byte)paramInt;
    if (j == arrayOfByte.length && j > 0) {
      this.h.write(arrayOfByte, 0, j);
      this.k = 0;
    } 
  }
  
  public void write(byte[] paramArrayOfbyte) {
    write(paramArrayOfbyte, 0, paramArrayOfbyte.length);
  }
  
  public void write(byte[] paramArrayOfbyte, int paramInt1, int paramInt2) {
    int j;
    int i = 0;
    do {
      int k = paramInt2 - i;
      j = paramInt1 + i;
      int m = this.k;
      if (m == 0 && k >= this.i.length) {
        this.h.write(paramArrayOfbyte, j, k);
        return;
      } 
      k = Math.min(k, this.i.length - m);
      System.arraycopy(paramArrayOfbyte, j, this.i, this.k, k);
      m = this.k + k;
      this.k = m;
      j = i + k;
      byte[] arrayOfByte = this.i;
      if (m == arrayOfByte.length && m > 0) {
        this.h.write(arrayOfByte, 0, m);
        this.k = 0;
      } 
      i = j;
    } while (j < paramInt2);
  }
}


/* Location:              C:\soft\dex2jar-2.0\Luxury Logo Maker_ Logo Design-dex2jar.jar!\com\bumptech\glide\load\data\c.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */