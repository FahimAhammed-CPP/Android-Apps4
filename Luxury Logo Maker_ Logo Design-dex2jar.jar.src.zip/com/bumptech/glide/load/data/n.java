package com.bumptech.glide.load.data;

import android.content.ContentResolver;
import android.content.UriMatcher;
import android.net.Uri;
import java.io.InputStream;

public class n extends l<InputStream> {
  public static final UriMatcher k;
  
  static {
    UriMatcher uriMatcher = new UriMatcher(-1);
    k = uriMatcher;
    uriMatcher.addURI("com.android.contacts", "contacts/lookup/*/#", 1);
    uriMatcher.addURI("com.android.contacts", "contacts/lookup/*", 1);
    uriMatcher.addURI("com.android.contacts", "contacts/#/photo", 2);
    uriMatcher.addURI("com.android.contacts", "contacts/#", 3);
    uriMatcher.addURI("com.android.contacts", "contacts/#/display_photo", 4);
    uriMatcher.addURI("com.android.contacts", "phone_lookup/*", 5);
  }
  
  public n(ContentResolver paramContentResolver, Uri paramUri) {
    super(paramContentResolver, paramUri);
  }
  
  public Class<InputStream> a() {
    return InputStream.class;
  }
  
  public void c(Object paramObject) {
    ((InputStream)paramObject).close();
  }
  
  public Object d(Uri paramUri, ContentResolver paramContentResolver) {
    // Byte code:
    //   0: getstatic com/bumptech/glide/load/data/n.k : Landroid/content/UriMatcher;
    //   3: aload_1
    //   4: invokevirtual match : (Landroid/net/Uri;)I
    //   7: istore_3
    //   8: iload_3
    //   9: iconst_1
    //   10: if_icmpeq -> 42
    //   13: iload_3
    //   14: iconst_3
    //   15: if_icmpeq -> 32
    //   18: iload_3
    //   19: iconst_5
    //   20: if_icmpeq -> 42
    //   23: aload_2
    //   24: aload_1
    //   25: invokevirtual openInputStream : (Landroid/net/Uri;)Ljava/io/InputStream;
    //   28: astore_2
    //   29: goto -> 62
    //   32: aload_2
    //   33: aload_1
    //   34: iconst_1
    //   35: invokestatic openContactPhotoInputStream : (Landroid/content/ContentResolver;Landroid/net/Uri;Z)Ljava/io/InputStream;
    //   38: astore_2
    //   39: goto -> 62
    //   42: aload_2
    //   43: aload_1
    //   44: invokestatic lookupContact : (Landroid/content/ContentResolver;Landroid/net/Uri;)Landroid/net/Uri;
    //   47: astore #4
    //   49: aload #4
    //   51: ifnull -> 82
    //   54: aload_2
    //   55: aload #4
    //   57: iconst_1
    //   58: invokestatic openContactPhotoInputStream : (Landroid/content/ContentResolver;Landroid/net/Uri;Z)Ljava/io/InputStream;
    //   61: astore_2
    //   62: aload_2
    //   63: ifnull -> 68
    //   66: aload_2
    //   67: areturn
    //   68: new java/io/FileNotFoundException
    //   71: dup
    //   72: ldc 'InputStream is null for '
    //   74: aload_1
    //   75: invokestatic a : (Ljava/lang/String;Landroid/net/Uri;)Ljava/lang/String;
    //   78: invokespecial <init> : (Ljava/lang/String;)V
    //   81: athrow
    //   82: new java/io/FileNotFoundException
    //   85: dup
    //   86: ldc 'Contact cannot be found'
    //   88: invokespecial <init> : (Ljava/lang/String;)V
    //   91: athrow
  }
}


/* Location:              C:\soft\dex2jar-2.0\Luxury Logo Maker_ Logo Design-dex2jar.jar!\com\bumptech\glide\load\data\n.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */