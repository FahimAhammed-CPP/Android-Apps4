package com.bumptech.glide.load.data;

import a2.a;
import android.content.ContentResolver;
import android.net.Uri;
import android.util.Log;
import com.bumptech.glide.f;
import java.io.FileNotFoundException;
import java.io.IOException;

public abstract class l<T> implements d<T> {
  public final Uri h;
  
  public final ContentResolver i;
  
  public T j;
  
  public l(ContentResolver paramContentResolver, Uri paramUri) {
    this.i = paramContentResolver;
    this.h = paramUri;
  }
  
  public void b() {
    T t = this.j;
    if (t != null)
      try {
        c(t);
        return;
      } catch (IOException iOException) {
        return;
      }  
  }
  
  public abstract void c(T paramT);
  
  public void cancel() {}
  
  public abstract T d(Uri paramUri, ContentResolver paramContentResolver);
  
  public a e() {
    return a.h;
  }
  
  public final void f(f paramf, d.a<? super T> parama) {
    try {
      paramf = (f)d(this.h, this.i);
      this.j = (T)paramf;
      parama.d((T)paramf);
      return;
    } catch (FileNotFoundException fileNotFoundException) {
      if (Log.isLoggable("LocalUriFetcher", 3))
        Log.d("LocalUriFetcher", "Failed to open Uri", fileNotFoundException); 
      parama.c(fileNotFoundException);
      return;
    } 
  }
}


/* Location:              C:\soft\dex2jar-2.0\Luxury Logo Maker_ Logo Design-dex2jar.jar!\com\bumptech\glide\load\data\l.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */