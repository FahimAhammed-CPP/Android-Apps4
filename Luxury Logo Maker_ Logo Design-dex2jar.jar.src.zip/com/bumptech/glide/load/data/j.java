package com.bumptech.glide.load.data;

import a2.e;
import android.os.SystemClock;
import android.text.TextUtils;
import android.util.Log;
import com.bumptech.glide.f;
import g2.g;
import j.f;
import java.io.IOException;
import java.io.InputStream;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URISyntaxException;
import java.net.URL;
import java.util.Map;
import v2.c;
import v2.h;

public class j implements d<InputStream> {
  public static final b m = new a();
  
  public final g h;
  
  public final int i;
  
  public HttpURLConnection j;
  
  public InputStream k;
  
  public volatile boolean l;
  
  public j(g paramg, int paramInt) {
    this.h = paramg;
    this.i = paramInt;
  }
  
  public static int c(HttpURLConnection paramHttpURLConnection) {
    try {
      return paramHttpURLConnection.getResponseCode();
    } catch (IOException iOException) {
      if (Log.isLoggable("HttpUrlFetcher", 3))
        Log.d("HttpUrlFetcher", "Failed to get a response code", iOException); 
      return -1;
    } 
  }
  
  public Class<InputStream> a() {
    return InputStream.class;
  }
  
  public void b() {
    InputStream inputStream = this.k;
    if (inputStream != null)
      try {
        inputStream.close();
      } catch (IOException iOException) {} 
    HttpURLConnection httpURLConnection = this.j;
    if (httpURLConnection != null)
      httpURLConnection.disconnect(); 
    this.j = null;
  }
  
  public void cancel() {
    this.l = true;
  }
  
  public final InputStream d(URL paramURL1, int paramInt, URL paramURL2, Map<String, String> paramMap) {
    if (paramInt < 5) {
      if (paramURL2 != null)
        try {
          if (paramURL1.toURI().equals(paramURL2.toURI()))
            throw new e("In re-direct loop", -1, null); 
        } catch (URISyntaxException uRISyntaxException) {} 
      boolean bool = false;
      try {
        HttpURLConnection httpURLConnection = (HttpURLConnection)paramURL1.openConnection();
        for (Map.Entry<String, String> entry : paramMap.entrySet())
          httpURLConnection.addRequestProperty((String)entry.getKey(), (String)entry.getValue()); 
        httpURLConnection.setConnectTimeout(this.i);
        httpURLConnection.setReadTimeout(this.i);
        httpURLConnection.setUseCaches(false);
        httpURLConnection.setDoInput(true);
        httpURLConnection.setInstanceFollowRedirects(false);
        this.j = httpURLConnection;
        try {
          httpURLConnection.connect();
          this.k = this.j.getInputStream();
          if (this.l)
            return null; 
          int i = c(this.j);
          int k = i / 100;
          if (k == 2) {
            bool1 = true;
          } else {
            bool1 = false;
          } 
          if (bool1) {
            httpURLConnection = this.j;
            try {
              InputStream inputStream;
              if (TextUtils.isEmpty(httpURLConnection.getContentEncoding())) {
                paramInt = httpURLConnection.getContentLength();
                c c = new c(httpURLConnection.getInputStream(), paramInt);
              } else {
                if (Log.isLoggable("HttpUrlFetcher", 3)) {
                  StringBuilder stringBuilder = new StringBuilder();
                  stringBuilder.append("Got non empty content encoding: ");
                  stringBuilder.append(httpURLConnection.getContentEncoding());
                  Log.d("HttpUrlFetcher", stringBuilder.toString());
                } 
                inputStream = httpURLConnection.getInputStream();
              } 
              this.k = inputStream;
              return inputStream;
            } catch (IOException iOException) {
              throw new e("Failed to obtain InputStream", c(httpURLConnection), iOException);
            } 
          } 
          boolean bool1 = bool;
          if (k == 3)
            bool1 = true; 
          if (bool1) {
            String str = this.j.getHeaderField("Location");
            if (!TextUtils.isEmpty(str))
              try {
                URL uRL = new URL((URL)iOException, str);
                b();
                return d(uRL, paramInt + 1, (URL)iOException, paramMap);
              } catch (MalformedURLException malformedURLException) {
                throw new e(f.a("Bad redirect url: ", str), i, malformedURLException);
              }  
            throw new e("Received empty or null redirect url", i, null);
          } 
          if (i == -1)
            throw new e("Http request failed", i, null); 
          try {
            throw new e(this.j.getResponseMessage(), i, null);
          } catch (IOException iOException1) {
            throw new e("Failed to get a response message", i, iOException1);
          } 
        } catch (IOException iOException) {
          throw new e("Failed to connect or obtain data", c(this.j), iOException);
        } 
      } catch (IOException iOException) {
        throw new e("URL.openConnection threw", 0, iOException);
      } 
    } 
    throw new e("Too many (> 5) redirects!", -1, null);
  }
  
  public a2.a e() {
    return a2.a.i;
  }
  
  public void f(f paramf, d.a<? super InputStream> parama) {
    int i = h.b;
    long l = SystemClock.elapsedRealtimeNanos();
    try {
      parama.d(d(this.h.d(), 0, null, this.h.b.a()));
      if (Log.isLoggable("HttpUrlFetcher", 2)) {
        StringBuilder stringBuilder = new StringBuilder();
      } else {
        return;
      } 
    } catch (IOException iOException) {
      if (Log.isLoggable("HttpUrlFetcher", 3))
        Log.d("HttpUrlFetcher", "Failed to load data for url", iOException); 
      parama.c(iOException);
      if (Log.isLoggable("HttpUrlFetcher", 2)) {
        StringBuilder stringBuilder = new StringBuilder();
      } else {
        return;
      } 
    } finally {}
    paramf.append("Finished http url fetcher fetch in ");
    paramf.append(h.a(l));
    Log.v("HttpUrlFetcher", paramf.toString());
  }
  
  public static class a implements b {}
  
  public static interface b {}
}


/* Location:              C:\soft\dex2jar-2.0\Luxury Logo Maker_ Logo Design-dex2jar.jar!\com\bumptech\glide\load\data\j.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */