package com.bumptech.glide.load.data;

import d2.b;
import j2.w;
import java.io.InputStream;

public final class k implements e<InputStream> {
  public final w a;
  
  public k(InputStream paramInputStream, b paramb) {
    w w1 = new w(paramInputStream, paramb);
    this.a = w1;
    w1.mark(5242880);
  }
  
  public void b() {
    this.a.c();
  }
  
  public InputStream c() {
    this.a.reset();
    return (InputStream)this.a;
  }
  
  public static final class a implements e.a<InputStream> {
    public final b a;
    
    public a(b param1b) {
      this.a = param1b;
    }
    
    public Class<InputStream> a() {
      return InputStream.class;
    }
    
    public e b(Object param1Object) {
      return new k((InputStream)param1Object, this.a);
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Luxury Logo Maker_ Logo Design-dex2jar.jar!\com\bumptech\glide\load\data\k.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */