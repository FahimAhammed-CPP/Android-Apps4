package com.bumptech.glide.load;

import d2.b;
import j2.w;
import java.io.InputStream;
import java.nio.ByteBuffer;
import java.util.List;

public final class a {
  public static int a(List<ImageHeaderParser> paramList, InputStream paramInputStream, b paramb) {
    w w;
    if (paramInputStream == null)
      return -1; 
    InputStream inputStream = paramInputStream;
    if (!paramInputStream.markSupported())
      w = new w(paramInputStream, paramb); 
    w.mark(5242880);
    int j = paramList.size();
    int i = 0;
    while (i < j) {
      ImageHeaderParser imageHeaderParser = paramList.get(i);
      try {
        int k = imageHeaderParser.c((InputStream)w, paramb);
        w.reset();
        if (k != -1)
          return k; 
      } finally {
        w.reset();
      } 
    } 
    return -1;
  }
  
  public static ImageHeaderParser.ImageType b(List<ImageHeaderParser> paramList, InputStream paramInputStream, b paramb) {
    w w;
    if (paramInputStream == null)
      return ImageHeaderParser.ImageType.UNKNOWN; 
    InputStream inputStream = paramInputStream;
    if (!paramInputStream.markSupported())
      w = new w(paramInputStream, paramb); 
    w.mark(5242880);
    int j = paramList.size();
    int i = 0;
    while (i < j) {
      ImageHeaderParser imageHeaderParser = paramList.get(i);
      try {
        ImageHeaderParser.ImageType imageType = imageHeaderParser.d((InputStream)w);
        w.reset();
        if (imageType != ImageHeaderParser.ImageType.UNKNOWN)
          return imageType; 
      } finally {
        w.reset();
      } 
    } 
    return ImageHeaderParser.ImageType.UNKNOWN;
  }
  
  public static ImageHeaderParser.ImageType c(List<ImageHeaderParser> paramList, ByteBuffer paramByteBuffer) {
    if (paramByteBuffer == null)
      return ImageHeaderParser.ImageType.UNKNOWN; 
    int j = paramList.size();
    int i = 0;
    while (i < j) {
      ImageHeaderParser imageHeaderParser = paramList.get(i);
      try {
        ImageHeaderParser.ImageType imageType = imageHeaderParser.a(paramByteBuffer);
        v2.a.c(paramByteBuffer);
        if (imageType != ImageHeaderParser.ImageType.UNKNOWN)
          return imageType; 
      } finally {
        v2.a.c(paramByteBuffer);
      } 
    } 
    return ImageHeaderParser.ImageType.UNKNOWN;
  }
}


/* Location:              C:\soft\dex2jar-2.0\Luxury Logo Maker_ Logo Design-dex2jar.jar!\com\bumptech\glide\load\a.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */