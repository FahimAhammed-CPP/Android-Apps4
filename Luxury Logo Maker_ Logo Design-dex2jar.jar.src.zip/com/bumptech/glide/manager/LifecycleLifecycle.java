package com.bumptech.glide.manager;

import androidx.lifecycle.e;
import androidx.lifecycle.h;
import androidx.lifecycle.i;
import androidx.lifecycle.j;
import androidx.lifecycle.q;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.Iterator;
import java.util.Set;
import v2.l;

final class LifecycleLifecycle implements k, h {
  public final Set<l> h = new HashSet<l>();
  
  public final e i;
  
  public LifecycleLifecycle(e parame) {
    this.i = parame;
    parame.a(this);
  }
  
  public void e(l paraml) {
    boolean bool;
    this.h.add(paraml);
    e e1 = this.i;
    if (((j)e1).b == e.c.h) {
      paraml.onDestroy();
      return;
    } 
    if (((j)e1).b.compareTo(e.c.k) >= 0) {
      bool = true;
    } else {
      bool = false;
    } 
    if (bool) {
      paraml.i();
      return;
    } 
    paraml.b();
  }
  
  public void f(l paraml) {
    this.h.remove(paraml);
  }
  
  @q(e.b.ON_DESTROY)
  public void onDestroy(i parami) {
    Iterator<l> iterator = ((ArrayList)l.e(this.h)).iterator();
    while (iterator.hasNext())
      ((l)iterator.next()).onDestroy(); 
    j j = (j)parami.a();
    j.c("removeObserver");
    j.a.j(this);
  }
  
  @q(e.b.ON_START)
  public void onStart(i parami) {
    Iterator<l> iterator = ((ArrayList)l.e(this.h)).iterator();
    while (iterator.hasNext())
      ((l)iterator.next()).i(); 
  }
  
  @q(e.b.ON_STOP)
  public void onStop(i parami) {
    Iterator<l> iterator = ((ArrayList)l.e(this.h)).iterator();
    while (iterator.hasNext())
      ((l)iterator.next()).b(); 
  }
}


/* Location:              C:\soft\dex2jar-2.0\Luxury Logo Maker_ Logo Design-dex2jar.jar!\com\bumptech\glide\manager\LifecycleLifecycle.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */