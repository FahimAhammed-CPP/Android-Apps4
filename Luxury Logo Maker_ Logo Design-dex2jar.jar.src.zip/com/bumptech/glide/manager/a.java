package com.bumptech.glide.manager;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Iterator;
import java.util.Set;
import java.util.WeakHashMap;
import v2.l;

public class a implements k {
  public final Set<l> h = Collections.newSetFromMap(new WeakHashMap<l, Boolean>());
  
  public boolean i;
  
  public boolean j;
  
  public void a() {
    this.j = true;
    Iterator<l> iterator = ((ArrayList)l.e(this.h)).iterator();
    while (iterator.hasNext())
      ((l)iterator.next()).onDestroy(); 
  }
  
  public void b() {
    this.i = true;
    Iterator<l> iterator = ((ArrayList)l.e(this.h)).iterator();
    while (iterator.hasNext())
      ((l)iterator.next()).i(); 
  }
  
  public void c() {
    this.i = false;
    Iterator<l> iterator = ((ArrayList)l.e(this.h)).iterator();
    while (iterator.hasNext())
      ((l)iterator.next()).b(); 
  }
  
  public void e(l paraml) {
    this.h.add(paraml);
    if (this.j) {
      paraml.onDestroy();
      return;
    } 
    if (this.i) {
      paraml.i();
      return;
    } 
    paraml.b();
  }
  
  public void f(l paraml) {
    this.h.remove(paraml);
  }
}


/* Location:              C:\soft\dex2jar-2.0\Luxury Logo Maker_ Logo Design-dex2jar.jar!\com\bumptech\glide\manager\a.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */