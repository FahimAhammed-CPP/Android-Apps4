package com.bumptech.glide.manager;

import android.content.Context;

public final class e implements c {
  public final Context h;
  
  public final c.a i;
  
  public e(Context paramContext, c.a parama) {
    this.h = paramContext.getApplicationContext();
    this.i = parama;
  }
  
  public void b() {
    t t = t.a(this.h);
    synchronized (this.i) {
      t.b.remove(null);
      if (t.c && t.b.isEmpty()) {
        t.a.a();
        t.c = false;
      } 
      /* monitor exit ClassFileLocalVariableReferenceExpression{type=ObjectType{com/bumptech/glide/manager/t}, name=null} */
      return;
    } 
  }
  
  public void i() {
    t t = t.a(this.h);
    synchronized (this.i) {
      t.b.add(null);
      if (!t.c && !t.b.isEmpty())
        t.c = t.a.b(); 
      /* monitor exit ClassFileLocalVariableReferenceExpression{type=ObjectType{com/bumptech/glide/manager/t}, name=null} */
      return;
    } 
  }
  
  public void onDestroy() {}
}


/* Location:              C:\soft\dex2jar-2.0\Luxury Logo Maker_ Logo Design-dex2jar.jar!\com\bumptech\glide\manager\e.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */