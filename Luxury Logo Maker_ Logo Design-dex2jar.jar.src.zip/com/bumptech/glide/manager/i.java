package com.bumptech.glide.manager;

import android.app.Activity;
import android.text.TextUtils;
import android.view.MotionEvent;
import android.view.View;
import android.widget.TextView;
import androidx.appcompat.widget.Toolbar;
import e4.aq0;
import e4.iz0;
import e4.mt1;
import e4.on0;
import e4.uy;
import e4.wy;
import java.io.ByteArrayInputStream;
import java.nio.charset.Charset;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import n6.c;
import n6.d;
import org.json.JSONObject;
import photofiesta.xiaopo.flying.logoSticker.StickerView;

public class i implements j, d, uy, aq0, mt1 {
  public static final iz0 j = new iz0(0);
  
  public static final int[] l = new int[] { 0, 3, 6, 9, 12, 16, 19, 22, 25, 28 };
  
  public static final int[] m = new int[] { 0, 2, 3, 5, 6, 0, 1, 3, 4, 6 };
  
  public static final int[] n = new int[] { 67108863, 33554431 };
  
  public static final int[] o = new int[] { 26, 25 };
  
  public static final int[] p = new int[] { 16842755, 16842960, 16842961 };
  
  public static final int[] q = new int[] { 16842755, 16842961 };
  
  public static TextView g(Toolbar paramToolbar, CharSequence paramCharSequence) {
    for (int k = 0; k < paramToolbar.getChildCount(); k++) {
      View view = paramToolbar.getChildAt(k);
      if (view instanceof TextView) {
        TextView textView = (TextView)view;
        if (TextUtils.equals(textView.getText(), paramCharSequence))
          return textView; 
      } 
    } 
    return null;
  }
  
  public static void h(long[] paramArrayOflong1, long[] paramArrayOflong2, long[] paramArrayOflong3) {
    long[] arrayOfLong = new long[19];
    i(arrayOfLong, paramArrayOflong2, paramArrayOflong3);
    k(arrayOfLong);
    j(arrayOfLong);
    System.arraycopy(arrayOfLong, 0, paramArrayOflong1, 0, 10);
  }
  
  public static void i(long[] paramArrayOflong1, long[] paramArrayOflong2, long[] paramArrayOflong3) {
    paramArrayOflong1[0] = paramArrayOflong2[0] * paramArrayOflong3[0];
    long l1 = paramArrayOflong2[0];
    long l2 = paramArrayOflong3[1];
    paramArrayOflong1[1] = paramArrayOflong2[1] * paramArrayOflong3[0] + l1 * l2;
    l1 = paramArrayOflong2[1];
    l2 = paramArrayOflong3[1];
    long l3 = paramArrayOflong2[0];
    long l4 = paramArrayOflong3[2];
    paramArrayOflong1[2] = paramArrayOflong2[2] * paramArrayOflong3[0] + l3 * l4 + (l1 + l1) * l2;
    l1 = paramArrayOflong2[1];
    l2 = paramArrayOflong3[2];
    l3 = paramArrayOflong2[2];
    l4 = paramArrayOflong3[1];
    long l5 = paramArrayOflong2[0];
    long l6 = paramArrayOflong3[3];
    paramArrayOflong1[3] = paramArrayOflong2[3] * paramArrayOflong3[0] + l5 * l6 + l3 * l4 + l1 * l2;
    l1 = paramArrayOflong2[2];
    l2 = paramArrayOflong3[2];
    l3 = paramArrayOflong2[1];
    l4 = paramArrayOflong3[3];
    l3 = paramArrayOflong2[3] * paramArrayOflong3[1] + l3 * l4;
    l4 = paramArrayOflong2[0];
    l5 = paramArrayOflong3[4];
    paramArrayOflong1[4] = paramArrayOflong2[4] * paramArrayOflong3[0] + l4 * l5 + l3 + l3 + l1 * l2;
    l1 = paramArrayOflong2[2];
    l2 = paramArrayOflong3[3];
    l3 = paramArrayOflong2[3];
    l4 = paramArrayOflong3[2];
    l5 = paramArrayOflong2[1];
    l6 = paramArrayOflong3[4];
    long l7 = paramArrayOflong2[4];
    long l8 = paramArrayOflong3[1];
    long l9 = paramArrayOflong2[0];
    long l10 = paramArrayOflong3[5];
    paramArrayOflong1[5] = paramArrayOflong2[5] * paramArrayOflong3[0] + l9 * l10 + l7 * l8 + l5 * l6 + l3 * l4 + l1 * l2;
    l1 = paramArrayOflong2[3];
    l2 = paramArrayOflong3[3];
    l3 = paramArrayOflong2[1];
    l4 = paramArrayOflong3[5];
    l1 = paramArrayOflong2[5] * paramArrayOflong3[1] + l3 * l4 + l1 * l2;
    l2 = paramArrayOflong2[2];
    l3 = paramArrayOflong3[4];
    l4 = paramArrayOflong2[4];
    l5 = paramArrayOflong3[2];
    l6 = paramArrayOflong2[0];
    l7 = paramArrayOflong3[6];
    paramArrayOflong1[6] = paramArrayOflong2[6] * paramArrayOflong3[0] + l6 * l7 + l4 * l5 + l2 * l3 + l1 + l1;
    l1 = paramArrayOflong2[3];
    l2 = paramArrayOflong3[4];
    l3 = paramArrayOflong2[4];
    l4 = paramArrayOflong3[3];
    l5 = paramArrayOflong2[2];
    l6 = paramArrayOflong3[5];
    l7 = paramArrayOflong2[5];
    l8 = paramArrayOflong3[2];
    l9 = paramArrayOflong2[1];
    l10 = paramArrayOflong3[6];
    long l11 = paramArrayOflong2[6];
    long l12 = paramArrayOflong3[1];
    long l13 = paramArrayOflong2[0];
    long l14 = paramArrayOflong3[7];
    paramArrayOflong1[7] = paramArrayOflong2[7] * paramArrayOflong3[0] + l13 * l14 + l11 * l12 + l9 * l10 + l7 * l8 + l5 * l6 + l3 * l4 + l1 * l2;
    l1 = paramArrayOflong2[4];
    l2 = paramArrayOflong3[4];
    l3 = paramArrayOflong2[3];
    l4 = paramArrayOflong3[5];
    l5 = paramArrayOflong2[5];
    l6 = paramArrayOflong3[3];
    l7 = paramArrayOflong2[1];
    l8 = paramArrayOflong3[7];
    l3 = paramArrayOflong2[7] * paramArrayOflong3[1] + l7 * l8 + l5 * l6 + l3 * l4;
    l4 = paramArrayOflong2[2];
    l5 = paramArrayOflong3[6];
    l6 = paramArrayOflong2[6];
    l7 = paramArrayOflong3[2];
    l8 = paramArrayOflong2[0];
    l9 = paramArrayOflong3[8];
    paramArrayOflong1[8] = paramArrayOflong2[8] * paramArrayOflong3[0] + l8 * l9 + l6 * l7 + l4 * l5 + l3 + l3 + l1 * l2;
    l1 = paramArrayOflong2[4];
    l2 = paramArrayOflong3[5];
    l3 = paramArrayOflong2[5];
    l4 = paramArrayOflong3[4];
    l5 = paramArrayOflong2[3];
    l6 = paramArrayOflong3[6];
    l7 = paramArrayOflong2[6];
    l8 = paramArrayOflong3[3];
    l9 = paramArrayOflong2[2];
    l10 = paramArrayOflong3[7];
    l11 = paramArrayOflong2[7];
    l12 = paramArrayOflong3[2];
    l13 = paramArrayOflong2[1];
    l14 = paramArrayOflong3[8];
    long l15 = paramArrayOflong2[8];
    long l16 = paramArrayOflong3[1];
    long l17 = paramArrayOflong2[0];
    long l18 = paramArrayOflong3[9];
    paramArrayOflong1[9] = paramArrayOflong2[9] * paramArrayOflong3[0] + l17 * l18 + l15 * l16 + l13 * l14 + l11 * l12 + l9 * l10 + l7 * l8 + l5 * l6 + l3 * l4 + l1 * l2;
    l1 = paramArrayOflong2[5];
    l2 = paramArrayOflong3[5];
    l3 = paramArrayOflong2[3];
    l4 = paramArrayOflong3[7];
    l5 = paramArrayOflong2[7];
    l6 = paramArrayOflong3[3];
    l7 = paramArrayOflong2[1];
    l8 = paramArrayOflong3[9];
    l1 = paramArrayOflong2[9] * paramArrayOflong3[1] + l7 * l8 + l5 * l6 + l3 * l4 + l1 * l2;
    l2 = paramArrayOflong2[4];
    l3 = paramArrayOflong3[6];
    l4 = paramArrayOflong2[6];
    l5 = paramArrayOflong3[4];
    l6 = paramArrayOflong2[2];
    l7 = paramArrayOflong3[8];
    paramArrayOflong1[10] = paramArrayOflong2[8] * paramArrayOflong3[2] + l6 * l7 + l4 * l5 + l2 * l3 + l1 + l1;
    l1 = paramArrayOflong2[5];
    l2 = paramArrayOflong3[6];
    l3 = paramArrayOflong2[6];
    l4 = paramArrayOflong3[5];
    l5 = paramArrayOflong2[4];
    l6 = paramArrayOflong3[7];
    l7 = paramArrayOflong2[7];
    l8 = paramArrayOflong3[4];
    l9 = paramArrayOflong2[3];
    l10 = paramArrayOflong3[8];
    l11 = paramArrayOflong2[8];
    l12 = paramArrayOflong3[3];
    l13 = paramArrayOflong2[2];
    l14 = paramArrayOflong3[9];
    paramArrayOflong1[11] = paramArrayOflong2[9] * paramArrayOflong3[2] + l13 * l14 + l11 * l12 + l9 * l10 + l7 * l8 + l5 * l6 + l3 * l4 + l1 * l2;
    l1 = paramArrayOflong2[6];
    l2 = paramArrayOflong3[6];
    l3 = paramArrayOflong2[5];
    l4 = paramArrayOflong3[7];
    l5 = paramArrayOflong2[7];
    l6 = paramArrayOflong3[5];
    l7 = paramArrayOflong2[3];
    l8 = paramArrayOflong3[9];
    l3 = paramArrayOflong2[9] * paramArrayOflong3[3] + l7 * l8 + l5 * l6 + l3 * l4;
    l4 = paramArrayOflong2[4];
    l5 = paramArrayOflong3[8];
    paramArrayOflong1[12] = paramArrayOflong2[8] * paramArrayOflong3[4] + l4 * l5 + l3 + l3 + l1 * l2;
    l1 = paramArrayOflong2[6];
    l2 = paramArrayOflong3[7];
    l3 = paramArrayOflong2[7];
    l4 = paramArrayOflong3[6];
    l5 = paramArrayOflong2[5];
    l6 = paramArrayOflong3[8];
    l7 = paramArrayOflong2[8];
    l8 = paramArrayOflong3[5];
    l9 = paramArrayOflong2[4];
    l10 = paramArrayOflong3[9];
    paramArrayOflong1[13] = paramArrayOflong2[9] * paramArrayOflong3[4] + l9 * l10 + l7 * l8 + l5 * l6 + l3 * l4 + l1 * l2;
    l1 = paramArrayOflong2[7];
    l2 = paramArrayOflong3[7];
    l3 = paramArrayOflong2[5];
    l4 = paramArrayOflong3[9];
    l1 = paramArrayOflong2[9] * paramArrayOflong3[5] + l3 * l4 + l1 * l2;
    l2 = paramArrayOflong2[6];
    l3 = paramArrayOflong3[8];
    paramArrayOflong1[14] = paramArrayOflong2[8] * paramArrayOflong3[6] + l2 * l3 + l1 + l1;
    l1 = paramArrayOflong2[7];
    l2 = paramArrayOflong3[8];
    l3 = paramArrayOflong2[8];
    l4 = paramArrayOflong3[7];
    l5 = paramArrayOflong2[6];
    l6 = paramArrayOflong3[9];
    paramArrayOflong1[15] = paramArrayOflong2[9] * paramArrayOflong3[6] + l5 * l6 + l3 * l4 + l1 * l2;
    l1 = paramArrayOflong2[8];
    l2 = paramArrayOflong3[8];
    l3 = paramArrayOflong2[7];
    l4 = paramArrayOflong3[9];
    l3 = paramArrayOflong2[9] * paramArrayOflong3[7] + l3 * l4;
    paramArrayOflong1[16] = l3 + l3 + l1 * l2;
    l1 = paramArrayOflong2[8];
    l2 = paramArrayOflong3[9];
    paramArrayOflong1[17] = paramArrayOflong2[9] * paramArrayOflong3[8] + l1 * l2;
    l1 = paramArrayOflong2[9];
    paramArrayOflong1[18] = (l1 + l1) * paramArrayOflong3[9];
  }
  
  public static void j(long[] paramArrayOflong) {
    paramArrayOflong[10] = 0L;
    int k = 0;
    while (k < 10) {
      long l3 = paramArrayOflong[k];
      long l4 = l3 / 67108864L;
      paramArrayOflong[k] = l3 - (l4 << 26L);
      int m = k + 1;
      l3 = paramArrayOflong[m] + l4;
      paramArrayOflong[m] = l3;
      l4 = l3 / 33554432L;
      paramArrayOflong[m] = l3 - (l4 << 25L);
      k += 2;
      paramArrayOflong[k] = paramArrayOflong[k] + l4;
    } 
    long l1 = paramArrayOflong[0] + (paramArrayOflong[10] << 4L);
    paramArrayOflong[0] = l1;
    long l2 = paramArrayOflong[10];
    l1 = l2 + l2 + l1;
    paramArrayOflong[0] = l1;
    paramArrayOflong[0] = l1 + paramArrayOflong[10];
    paramArrayOflong[10] = 0L;
    l1 = paramArrayOflong[0];
    l2 = l1 / 67108864L;
    paramArrayOflong[0] = l1 - (l2 << 26L);
    paramArrayOflong[1] = paramArrayOflong[1] + l2;
  }
  
  public static void k(long[] paramArrayOflong) {
    long l1 = paramArrayOflong[8] + (paramArrayOflong[18] << 4L);
    paramArrayOflong[8] = l1;
    long l2 = paramArrayOflong[18];
    l1 = l2 + l2 + l1;
    paramArrayOflong[8] = l1;
    paramArrayOflong[8] = l1 + paramArrayOflong[18];
    l1 = paramArrayOflong[7] + (paramArrayOflong[17] << 4L);
    paramArrayOflong[7] = l1;
    l2 = paramArrayOflong[17];
    l1 = l2 + l2 + l1;
    paramArrayOflong[7] = l1;
    paramArrayOflong[7] = l1 + paramArrayOflong[17];
    l1 = paramArrayOflong[6] + (paramArrayOflong[16] << 4L);
    paramArrayOflong[6] = l1;
    l2 = paramArrayOflong[16];
    l1 = l2 + l2 + l1;
    paramArrayOflong[6] = l1;
    paramArrayOflong[6] = l1 + paramArrayOflong[16];
    l1 = paramArrayOflong[5] + (paramArrayOflong[15] << 4L);
    paramArrayOflong[5] = l1;
    l2 = paramArrayOflong[15];
    l1 = l2 + l2 + l1;
    paramArrayOflong[5] = l1;
    paramArrayOflong[5] = l1 + paramArrayOflong[15];
    l1 = paramArrayOflong[4] + (paramArrayOflong[14] << 4L);
    paramArrayOflong[4] = l1;
    l2 = paramArrayOflong[14];
    l1 = l2 + l2 + l1;
    paramArrayOflong[4] = l1;
    paramArrayOflong[4] = l1 + paramArrayOflong[14];
    l1 = paramArrayOflong[3] + (paramArrayOflong[13] << 4L);
    paramArrayOflong[3] = l1;
    l2 = paramArrayOflong[13];
    l1 = l2 + l2 + l1;
    paramArrayOflong[3] = l1;
    paramArrayOflong[3] = l1 + paramArrayOflong[13];
    l1 = paramArrayOflong[2] + (paramArrayOflong[12] << 4L);
    paramArrayOflong[2] = l1;
    l2 = paramArrayOflong[12];
    l1 = l2 + l2 + l1;
    paramArrayOflong[2] = l1;
    paramArrayOflong[2] = l1 + paramArrayOflong[12];
    l1 = paramArrayOflong[1] + (paramArrayOflong[11] << 4L);
    paramArrayOflong[1] = l1;
    l2 = paramArrayOflong[11];
    l1 = l2 + l2 + l1;
    paramArrayOflong[1] = l1;
    paramArrayOflong[1] = l1 + paramArrayOflong[11];
    l1 = paramArrayOflong[0] + (paramArrayOflong[10] << 4L);
    paramArrayOflong[0] = l1;
    l2 = paramArrayOflong[10];
    l1 = l2 + l2 + l1;
    paramArrayOflong[0] = l1;
    paramArrayOflong[0] = l1 + paramArrayOflong[10];
  }
  
  public static void l(long[] paramArrayOflong1, long[] paramArrayOflong2) {
    long[] arrayOfLong = new long[19];
    long l1 = paramArrayOflong2[0];
    arrayOfLong[0] = l1 * l1;
    l1 = paramArrayOflong2[0];
    arrayOfLong[1] = (l1 + l1) * paramArrayOflong2[1];
    l1 = paramArrayOflong2[1];
    l1 = paramArrayOflong2[0] * paramArrayOflong2[2] + l1 * l1;
    arrayOfLong[2] = l1 + l1;
    l1 = paramArrayOflong2[1];
    long l2 = paramArrayOflong2[2];
    l1 = paramArrayOflong2[0] * paramArrayOflong2[3] + l1 * l2;
    arrayOfLong[3] = l1 + l1;
    l1 = paramArrayOflong2[2];
    l2 = paramArrayOflong2[1];
    long l3 = paramArrayOflong2[3];
    long l4 = paramArrayOflong2[0];
    arrayOfLong[4] = (l4 + l4) * paramArrayOflong2[4] + l2 * 4L * l3 + l1 * l1;
    l1 = paramArrayOflong2[2];
    l2 = paramArrayOflong2[3];
    l3 = paramArrayOflong2[1];
    l4 = paramArrayOflong2[4];
    l1 = paramArrayOflong2[0] * paramArrayOflong2[5] + l3 * l4 + l1 * l2;
    arrayOfLong[5] = l1 + l1;
    l1 = paramArrayOflong2[3];
    l2 = paramArrayOflong2[2];
    l3 = paramArrayOflong2[4];
    l4 = paramArrayOflong2[0];
    long l5 = paramArrayOflong2[6];
    long l6 = paramArrayOflong2[1];
    l1 = (l6 + l6) * paramArrayOflong2[5] + l4 * l5 + l2 * l3 + l1 * l1;
    arrayOfLong[6] = l1 + l1;
    l1 = paramArrayOflong2[3];
    l2 = paramArrayOflong2[4];
    l3 = paramArrayOflong2[2];
    l4 = paramArrayOflong2[5];
    l5 = paramArrayOflong2[1];
    l6 = paramArrayOflong2[6];
    l1 = paramArrayOflong2[0] * paramArrayOflong2[7] + l5 * l6 + l3 * l4 + l1 * l2;
    arrayOfLong[7] = l1 + l1;
    l1 = paramArrayOflong2[4];
    l2 = paramArrayOflong2[2];
    l3 = paramArrayOflong2[6];
    l4 = paramArrayOflong2[0];
    l5 = paramArrayOflong2[8];
    l6 = paramArrayOflong2[1];
    long l7 = paramArrayOflong2[7];
    l6 = paramArrayOflong2[3] * paramArrayOflong2[5] + l6 * l7;
    l2 = l6 + l6 + l4 * l5 + l2 * l3;
    arrayOfLong[8] = l2 + l2 + l1 * l1;
    l1 = paramArrayOflong2[4];
    l2 = paramArrayOflong2[5];
    l3 = paramArrayOflong2[3];
    l4 = paramArrayOflong2[6];
    l5 = paramArrayOflong2[2];
    l6 = paramArrayOflong2[7];
    l7 = paramArrayOflong2[1];
    long l8 = paramArrayOflong2[8];
    l1 = paramArrayOflong2[0] * paramArrayOflong2[9] + l7 * l8 + l5 * l6 + l3 * l4 + l1 * l2;
    arrayOfLong[9] = l1 + l1;
    l1 = paramArrayOflong2[5];
    l2 = paramArrayOflong2[4];
    l3 = paramArrayOflong2[6];
    l4 = paramArrayOflong2[2];
    l5 = paramArrayOflong2[8];
    l6 = paramArrayOflong2[3];
    l7 = paramArrayOflong2[7];
    l6 = paramArrayOflong2[1] * paramArrayOflong2[9] + l6 * l7;
    l1 = l6 + l6 + l4 * l5 + l2 * l3 + l1 * l1;
    arrayOfLong[10] = l1 + l1;
    l1 = paramArrayOflong2[5];
    l2 = paramArrayOflong2[6];
    l3 = paramArrayOflong2[4];
    l4 = paramArrayOflong2[7];
    l5 = paramArrayOflong2[3];
    l6 = paramArrayOflong2[8];
    l1 = paramArrayOflong2[2] * paramArrayOflong2[9] + l5 * l6 + l3 * l4 + l1 * l2;
    arrayOfLong[11] = l1 + l1;
    l1 = paramArrayOflong2[6];
    l2 = paramArrayOflong2[4];
    l3 = paramArrayOflong2[8];
    l4 = paramArrayOflong2[5];
    l5 = paramArrayOflong2[7];
    l4 = paramArrayOflong2[3] * paramArrayOflong2[9] + l4 * l5;
    l2 = l4 + l4 + l2 * l3;
    arrayOfLong[12] = l2 + l2 + l1 * l1;
    l1 = paramArrayOflong2[6];
    l2 = paramArrayOflong2[7];
    l3 = paramArrayOflong2[5];
    l4 = paramArrayOflong2[8];
    l1 = paramArrayOflong2[4] * paramArrayOflong2[9] + l3 * l4 + l1 * l2;
    arrayOfLong[13] = l1 + l1;
    l1 = paramArrayOflong2[7];
    l2 = paramArrayOflong2[6];
    l3 = paramArrayOflong2[8];
    l4 = paramArrayOflong2[5];
    l1 = (l4 + l4) * paramArrayOflong2[9] + l2 * l3 + l1 * l1;
    arrayOfLong[14] = l1 + l1;
    l1 = paramArrayOflong2[7];
    l2 = paramArrayOflong2[8];
    l1 = paramArrayOflong2[6] * paramArrayOflong2[9] + l1 * l2;
    arrayOfLong[15] = l1 + l1;
    l1 = paramArrayOflong2[8];
    arrayOfLong[16] = paramArrayOflong2[7] * 4L * paramArrayOflong2[9] + l1 * l1;
    l1 = paramArrayOflong2[8];
    arrayOfLong[17] = (l1 + l1) * paramArrayOflong2[9];
    l1 = paramArrayOflong2[9];
    arrayOfLong[18] = (l1 + l1) * l1;
    k(arrayOfLong);
    j(arrayOfLong);
    System.arraycopy(arrayOfLong, 0, paramArrayOflong1, 0, 10);
  }
  
  public static void m(long[] paramArrayOflong1, long[] paramArrayOflong2, long[] paramArrayOflong3) {
    for (int k = 0; k < 10; k++)
      paramArrayOflong1[k] = paramArrayOflong2[k] - paramArrayOflong3[k]; 
  }
  
  public static void n(long[] paramArrayOflong1, long[] paramArrayOflong2, long[] paramArrayOflong3) {
    for (int k = 0; k < 10; k++)
      paramArrayOflong1[k] = paramArrayOflong2[k] + paramArrayOflong3[k]; 
  }
  
  public static byte[] o(long[] paramArrayOflong) {
    paramArrayOflong = Arrays.copyOf(paramArrayOflong, 10);
    byte b = 0;
    int k;
    for (k = 0; k < 2; k++) {
      int n = 0;
      while (n < 9) {
        long l2 = paramArrayOflong[n];
        int i2 = o[n & 0x1];
        int i1 = -((int)((l2 >> 31L & l2) >> i2));
        paramArrayOflong[n] = l2 + (i1 << i2);
        paramArrayOflong[++n] = paramArrayOflong[n] - i1;
      } 
      long l1 = paramArrayOflong[9];
      n = -((int)((l1 >> 31L & l1) >> 25L));
      paramArrayOflong[9] = l1 + (n << 25);
      paramArrayOflong[0] = paramArrayOflong[0] - (n * 19);
    } 
    long l = paramArrayOflong[0];
    k = -((int)((l >> 31L & l) >> 26L));
    paramArrayOflong[0] = l + (k << 26);
    paramArrayOflong[1] = paramArrayOflong[1] - k;
    for (k = 0; k < 2; k++) {
      int n = 0;
      while (n < 9) {
        l = paramArrayOflong[n];
        int i2 = n & 0x1;
        int i1 = o[i2];
        paramArrayOflong[n] = n[i2] & l;
        paramArrayOflong[++n] = paramArrayOflong[n] + (int)(l >> i1);
      } 
    } 
    l = paramArrayOflong[9];
    paramArrayOflong[9] = 0x1FFFFFFL & l;
    l = paramArrayOflong[0] + ((int)(l >> 25L) * 19);
    paramArrayOflong[0] = l;
    k = (int)l - 67108845 >> 31;
    int m;
    for (m = 1; m < 10; m++) {
      int n = (int)paramArrayOflong[m] ^ n[m & 0x1];
      n &= n << 16;
      n &= n << 8;
      n &= n << 4;
      n &= n << 2;
      k &= (n & n + n) >> 31;
    } 
    paramArrayOflong[0] = paramArrayOflong[0] - (0x3FFFFED & k);
    l = (0x1FFFFFF & k);
    paramArrayOflong[1] = paramArrayOflong[1] - l;
    for (m = 2; m < 10; m += 2) {
      paramArrayOflong[m] = paramArrayOflong[m] - (0x3FFFFFF & k);
      int n = m + 1;
      paramArrayOflong[n] = paramArrayOflong[n] - l;
    } 
    for (k = 0; k < 10; k++)
      paramArrayOflong[k] = paramArrayOflong[k] << m[k]; 
    byte[] arrayOfByte = new byte[32];
    for (k = b; k < 10; k++) {
      int[] arrayOfInt = l;
      m = arrayOfInt[k];
      b = arrayOfByte[m];
      l = paramArrayOflong[k];
      arrayOfByte[m] = (byte)(int)(b | l & 0xFFL);
      m = arrayOfInt[k] + 1;
      arrayOfByte[m] = (byte)(int)(arrayOfByte[m] | l >> 8L & 0xFFL);
      m = arrayOfInt[k] + 2;
      arrayOfByte[m] = (byte)(int)(arrayOfByte[m] | l >> 16L & 0xFFL);
      m = arrayOfInt[k] + 3;
      arrayOfByte[m] = (byte)(int)(arrayOfByte[m] | l >> 24L & 0xFFL);
    } 
    return arrayOfByte;
  }
  
  public Object a(JSONObject paramJSONObject) {
    Charset charset = wy.a;
    return new ByteArrayInputStream(paramJSONObject.toString().getBytes(wy.a));
  }
  
  public void b(StickerView paramStickerView, MotionEvent paramMotionEvent) {
    List list = StickerView.G;
    c c = StickerView.H;
    ((ArrayList)list).remove(c);
    list = StickerView.G;
    c = StickerView.H;
    ((ArrayList<c>)list).add(c);
    paramStickerView.invalidate();
  }
  
  public void c(StickerView paramStickerView, MotionEvent paramMotionEvent) {}
  
  public void d(Object paramObject) {
    ((on0)paramObject).q();
  }
  
  public void e(Activity paramActivity) {}
  
  public void f(StickerView paramStickerView, MotionEvent paramMotionEvent) {}
  
  public Object zza() {
    return Integer.valueOf(-1);
  }
}


/* Location:              C:\soft\dex2jar-2.0\Luxury Logo Maker_ Logo Design-dex2jar.jar!\com\bumptech\glide\manager\i.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */