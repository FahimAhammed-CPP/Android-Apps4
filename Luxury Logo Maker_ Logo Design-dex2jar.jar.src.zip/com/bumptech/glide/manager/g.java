package com.bumptech.glide.manager;

import android.app.Activity;
import m6.d;

public class g implements j, d {
  public void e(Activity paramActivity) {}
}


/* Location:              C:\soft\dex2jar-2.0\Luxury Logo Maker_ Logo Design-dex2jar.jar!\com\bumptech\glide\manager\g.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */