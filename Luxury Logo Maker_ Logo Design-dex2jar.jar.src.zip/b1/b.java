package b1;

import android.content.Context;
import java.util.List;

public interface b<T> {
  List<Class<? extends b<?>>> a();
  
  T b(Context paramContext);
}


/* Location:              C:\soft\dex2jar-2.0\Luxury Logo Maker_ Logo Design-dex2jar.jar!\b1\b.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */