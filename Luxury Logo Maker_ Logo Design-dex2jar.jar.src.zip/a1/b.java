package a1;

import android.database.Cursor;
import android.database.sqlite.SQLiteCursor;
import android.database.sqlite.SQLiteCursorDriver;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteProgram;
import android.database.sqlite.SQLiteQuery;
import z0.e;

public class b implements SQLiteDatabase.CursorFactory {
  public b(a parama, e parame) {}
  
  public Cursor newCursor(SQLiteDatabase paramSQLiteDatabase, SQLiteCursorDriver paramSQLiteCursorDriver, String paramString, SQLiteQuery paramSQLiteQuery) {
    this.a.e(new e((SQLiteProgram)paramSQLiteQuery));
    return (Cursor)new SQLiteCursor(paramSQLiteCursorDriver, paramString, paramSQLiteQuery);
  }
}


/* Location:              C:\soft\dex2jar-2.0\Luxury Logo Maker_ Logo Design-dex2jar.jar!\a1\b.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */