package a1;

import z0.c;

public final class d implements c.c {
  public c a(c.b paramb) {
    return new c(paramb.a, paramb.b, paramb.c, paramb.d);
  }
}


/* Location:              C:\soft\dex2jar-2.0\Luxury Logo Maker_ Logo Design-dex2jar.jar!\a1\d.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */