package a1;

import android.database.sqlite.SQLiteProgram;
import android.database.sqlite.SQLiteStatement;

public class f extends e {
  public final SQLiteStatement i;
  
  public f(SQLiteStatement paramSQLiteStatement) {
    super((SQLiteProgram)paramSQLiteStatement);
    this.i = paramSQLiteStatement;
  }
  
  public int a() {
    return this.i.executeUpdateDelete();
  }
}


/* Location:              C:\soft\dex2jar-2.0\Luxury Logo Maker_ Logo Design-dex2jar.jar!\a1\f.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */