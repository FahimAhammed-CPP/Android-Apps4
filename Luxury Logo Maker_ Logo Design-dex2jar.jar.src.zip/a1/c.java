package a1;

import android.content.Context;
import android.database.DatabaseErrorHandler;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteException;
import android.database.sqlite.SQLiteOpenHelper;
import android.os.Build;
import android.util.Log;
import android.util.Pair;
import java.io.File;
import java.io.IOException;
import java.util.Iterator;
import java.util.List;
import java.util.Objects;
import w0.g;
import z0.b;
import z0.c;

public class c implements c {
  public final Context h;
  
  public final String i;
  
  public final c.a j;
  
  public final boolean k;
  
  public final Object l;
  
  public a m;
  
  public boolean n;
  
  public c(Context paramContext, String paramString, c.a parama, boolean paramBoolean) {
    this.h = paramContext;
    this.i = paramString;
    this.j = parama;
    this.k = paramBoolean;
    this.l = new Object();
  }
  
  public final a a() {
    synchronized (this.l) {
      if (this.m == null) {
        a[] arrayOfA = new a[1];
        if (Build.VERSION.SDK_INT >= 23 && this.i != null && this.k) {
          File file = new File(this.h.getNoBackupFilesDir(), this.i);
          this.m = new a(this.h, file.getAbsolutePath(), arrayOfA, this.j);
        } else {
          this.m = new a(this.h, this.i, arrayOfA, this.j);
        } 
        this.m.setWriteAheadLoggingEnabled(this.n);
      } 
      return this.m;
    } 
  }
  
  public b b() {
    return a().d();
  }
  
  public void close() {
    a().close();
  }
  
  public String getDatabaseName() {
    return this.i;
  }
  
  public void setWriteAheadLoggingEnabled(boolean paramBoolean) {
    synchronized (this.l) {
      a a1 = this.m;
      if (a1 != null)
        a1.setWriteAheadLoggingEnabled(paramBoolean); 
      this.n = paramBoolean;
      return;
    } 
  }
  
  public static class a extends SQLiteOpenHelper {
    public final a[] h;
    
    public final c.a i;
    
    public boolean j;
    
    public a(Context param1Context, String param1String, a[] param1ArrayOfa, c.a param1a) {
      super(param1Context, param1String, null, param1a.a, new a(param1a, param1ArrayOfa));
      this.i = param1a;
      this.h = param1ArrayOfa;
    }
    
    public static a c(a[] param1ArrayOfa, SQLiteDatabase param1SQLiteDatabase) {
      a a1 = param1ArrayOfa[0];
      if (a1 != null) {
        boolean bool;
        if (a1.h == param1SQLiteDatabase) {
          bool = true;
        } else {
          bool = false;
        } 
        if (!bool) {
          param1ArrayOfa[0] = new a(param1SQLiteDatabase);
          return param1ArrayOfa[0];
        } 
        return param1ArrayOfa[0];
      } 
      param1ArrayOfa[0] = new a(param1SQLiteDatabase);
      return param1ArrayOfa[0];
    }
    
    public a a(SQLiteDatabase param1SQLiteDatabase) {
      return c(this.h, param1SQLiteDatabase);
    }
    
    public void close() {
      // Byte code:
      //   0: aload_0
      //   1: monitorenter
      //   2: aload_0
      //   3: invokespecial close : ()V
      //   6: aload_0
      //   7: getfield h : [La1/a;
      //   10: iconst_0
      //   11: aconst_null
      //   12: aastore
      //   13: aload_0
      //   14: monitorexit
      //   15: return
      //   16: astore_1
      //   17: aload_0
      //   18: monitorexit
      //   19: aload_1
      //   20: athrow
      // Exception table:
      //   from	to	target	type
      //   2	13	16	finally
    }
    
    public b d() {
      // Byte code:
      //   0: aload_0
      //   1: monitorenter
      //   2: aload_0
      //   3: iconst_0
      //   4: putfield j : Z
      //   7: aload_0
      //   8: invokevirtual getWritableDatabase : ()Landroid/database/sqlite/SQLiteDatabase;
      //   11: astore_1
      //   12: aload_0
      //   13: getfield j : Z
      //   16: ifeq -> 32
      //   19: aload_0
      //   20: invokevirtual close : ()V
      //   23: aload_0
      //   24: invokevirtual d : ()Lz0/b;
      //   27: astore_1
      //   28: aload_0
      //   29: monitorexit
      //   30: aload_1
      //   31: areturn
      //   32: aload_0
      //   33: aload_1
      //   34: invokevirtual a : (Landroid/database/sqlite/SQLiteDatabase;)La1/a;
      //   37: astore_1
      //   38: aload_0
      //   39: monitorexit
      //   40: aload_1
      //   41: areturn
      //   42: astore_1
      //   43: aload_0
      //   44: monitorexit
      //   45: aload_1
      //   46: athrow
      // Exception table:
      //   from	to	target	type
      //   2	28	42	finally
      //   32	38	42	finally
    }
    
    public void onConfigure(SQLiteDatabase param1SQLiteDatabase) {
      c.a a1 = this.i;
      c(this.h, param1SQLiteDatabase);
      Objects.requireNonNull(a1);
    }
    
    public void onCreate(SQLiteDatabase param1SQLiteDatabase) {
      // Byte code:
      //   0: aload_0
      //   1: getfield i : Lz0/c$a;
      //   4: astore #6
      //   6: aload_0
      //   7: getfield h : [La1/a;
      //   10: aload_1
      //   11: invokestatic c : ([La1/a;Landroid/database/sqlite/SQLiteDatabase;)La1/a;
      //   14: astore_1
      //   15: aload #6
      //   17: checkcast w0/g
      //   20: astore #6
      //   22: aload #6
      //   24: invokestatic requireNonNull : (Ljava/lang/Object;)Ljava/lang/Object;
      //   27: pop
      //   28: aload_1
      //   29: ldc 'SELECT count(*) FROM sqlite_master WHERE name != 'android_metadata''
      //   31: invokevirtual c : (Ljava/lang/String;)Landroid/database/Cursor;
      //   34: astore #7
      //   36: aload #7
      //   38: invokeinterface moveToFirst : ()Z
      //   43: istore #5
      //   45: iconst_0
      //   46: istore_3
      //   47: iload #5
      //   49: ifeq -> 70
      //   52: aload #7
      //   54: iconst_0
      //   55: invokeinterface getInt : (I)I
      //   60: istore_2
      //   61: iload_2
      //   62: ifne -> 70
      //   65: iconst_1
      //   66: istore_2
      //   67: goto -> 72
      //   70: iconst_0
      //   71: istore_2
      //   72: aload #7
      //   74: invokeinterface close : ()V
      //   79: aload #6
      //   81: getfield c : Lw0/g$a;
      //   84: aload_1
      //   85: invokevirtual a : (Lz0/b;)V
      //   88: iload_2
      //   89: ifne -> 142
      //   92: aload #6
      //   94: getfield c : Lw0/g$a;
      //   97: aload_1
      //   98: invokevirtual b : (Lz0/b;)Lw0/g$b;
      //   101: astore #7
      //   103: aload #7
      //   105: getfield a : Z
      //   108: ifeq -> 114
      //   111: goto -> 142
      //   114: ldc 'Pre-packaged database has an invalid schema: '
      //   116: invokestatic a : (Ljava/lang/String;)Ljava/lang/StringBuilder;
      //   119: astore_1
      //   120: aload_1
      //   121: aload #7
      //   123: getfield b : Ljava/lang/String;
      //   126: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
      //   129: pop
      //   130: new java/lang/IllegalStateException
      //   133: dup
      //   134: aload_1
      //   135: invokevirtual toString : ()Ljava/lang/String;
      //   138: invokespecial <init> : (Ljava/lang/String;)V
      //   141: athrow
      //   142: aload #6
      //   144: aload_1
      //   145: invokevirtual c : (Lz0/b;)V
      //   148: aload #6
      //   150: getfield c : Lw0/g$a;
      //   153: checkcast androidx/work/impl/WorkDatabase_Impl$a
      //   156: astore_1
      //   157: aload_1
      //   158: getfield b : Landroidx/work/impl/WorkDatabase_Impl;
      //   161: astore #6
      //   163: getstatic androidx/work/impl/WorkDatabase_Impl.s : I
      //   166: istore_2
      //   167: aload #6
      //   169: getfield g : Ljava/util/List;
      //   172: astore #6
      //   174: aload #6
      //   176: ifnull -> 223
      //   179: aload #6
      //   181: invokeinterface size : ()I
      //   186: istore #4
      //   188: iload_3
      //   189: istore_2
      //   190: iload_2
      //   191: iload #4
      //   193: if_icmpge -> 223
      //   196: aload_1
      //   197: getfield b : Landroidx/work/impl/WorkDatabase_Impl;
      //   200: getfield g : Ljava/util/List;
      //   203: iload_2
      //   204: invokeinterface get : (I)Ljava/lang/Object;
      //   209: checkcast w0/f$b
      //   212: invokestatic requireNonNull : (Ljava/lang/Object;)Ljava/lang/Object;
      //   215: pop
      //   216: iload_2
      //   217: iconst_1
      //   218: iadd
      //   219: istore_2
      //   220: goto -> 190
      //   223: return
      //   224: astore_1
      //   225: aload #7
      //   227: invokeinterface close : ()V
      //   232: aload_1
      //   233: athrow
      // Exception table:
      //   from	to	target	type
      //   36	45	224	finally
      //   52	61	224	finally
    }
    
    public void onDowngrade(SQLiteDatabase param1SQLiteDatabase, int param1Int1, int param1Int2) {
      this.j = true;
      c.a a2 = this.i;
      a a1 = c(this.h, param1SQLiteDatabase);
      ((g)a2).b(a1, param1Int1, param1Int2);
    }
    
    public void onOpen(SQLiteDatabase param1SQLiteDatabase) {
      // Byte code:
      //   0: aload_0
      //   1: getfield j : Z
      //   4: ifne -> 458
      //   7: aload_0
      //   8: getfield i : Lz0/c$a;
      //   11: astore #7
      //   13: aload_0
      //   14: getfield h : [La1/a;
      //   17: aload_1
      //   18: invokestatic c : ([La1/a;Landroid/database/sqlite/SQLiteDatabase;)La1/a;
      //   21: astore #6
      //   23: aload #7
      //   25: checkcast w0/g
      //   28: astore #7
      //   30: aload #7
      //   32: invokestatic requireNonNull : (Ljava/lang/Object;)Ljava/lang/Object;
      //   35: pop
      //   36: aload #6
      //   38: ldc 'SELECT 1 FROM sqlite_master WHERE type = 'table' AND name='room_master_table''
      //   40: invokevirtual c : (Ljava/lang/String;)Landroid/database/Cursor;
      //   43: astore_1
      //   44: aload_1
      //   45: invokeinterface moveToFirst : ()Z
      //   50: istore #5
      //   52: iconst_0
      //   53: istore_3
      //   54: iload #5
      //   56: ifeq -> 76
      //   59: aload_1
      //   60: iconst_0
      //   61: invokeinterface getInt : (I)I
      //   66: istore_2
      //   67: iload_2
      //   68: ifeq -> 76
      //   71: iconst_1
      //   72: istore_2
      //   73: goto -> 78
      //   76: iconst_0
      //   77: istore_2
      //   78: aload_1
      //   79: invokeinterface close : ()V
      //   84: iload_2
      //   85: ifeq -> 176
      //   88: aload #6
      //   90: new z0/a
      //   93: dup
      //   94: ldc 'SELECT identity_hash FROM room_master_table WHERE id = 42 LIMIT 1'
      //   96: invokespecial <init> : (Ljava/lang/String;)V
      //   99: invokevirtual d : (Lz0/e;)Landroid/database/Cursor;
      //   102: astore #8
      //   104: aload #8
      //   106: invokeinterface moveToFirst : ()Z
      //   111: ifeq -> 126
      //   114: aload #8
      //   116: iconst_0
      //   117: invokeinterface getString : (I)Ljava/lang/String;
      //   122: astore_1
      //   123: goto -> 128
      //   126: aconst_null
      //   127: astore_1
      //   128: aload #8
      //   130: invokeinterface close : ()V
      //   135: ldc 'c103703e120ae8cc73c9248622f3cd1e'
      //   137: aload_1
      //   138: invokevirtual equals : (Ljava/lang/Object;)Z
      //   141: ifne -> 210
      //   144: ldc '49f946663a8deb7054212b8adda248c6'
      //   146: aload_1
      //   147: invokevirtual equals : (Ljava/lang/Object;)Z
      //   150: ifeq -> 156
      //   153: goto -> 210
      //   156: new java/lang/IllegalStateException
      //   159: dup
      //   160: ldc 'Room cannot verify the data integrity. Looks like you've changed schema but forgot to update the version number. You can simply fix this by increasing the version number.'
      //   162: invokespecial <init> : (Ljava/lang/String;)V
      //   165: athrow
      //   166: astore_1
      //   167: aload #8
      //   169: invokeinterface close : ()V
      //   174: aload_1
      //   175: athrow
      //   176: aload #7
      //   178: getfield c : Lw0/g$a;
      //   181: aload #6
      //   183: invokevirtual b : (Lz0/b;)Lw0/g$b;
      //   186: astore_1
      //   187: aload_1
      //   188: getfield a : Z
      //   191: ifeq -> 417
      //   194: aload #7
      //   196: getfield c : Lw0/g$a;
      //   199: invokestatic requireNonNull : (Ljava/lang/Object;)Ljava/lang/Object;
      //   202: pop
      //   203: aload #7
      //   205: aload #6
      //   207: invokevirtual c : (Lz0/b;)V
      //   210: aload #7
      //   212: getfield c : Lw0/g$a;
      //   215: checkcast androidx/work/impl/WorkDatabase_Impl$a
      //   218: astore_1
      //   219: aload_1
      //   220: getfield b : Landroidx/work/impl/WorkDatabase_Impl;
      //   223: astore #8
      //   225: getstatic androidx/work/impl/WorkDatabase_Impl.s : I
      //   228: istore_2
      //   229: aload #8
      //   231: aload #6
      //   233: putfield a : Lz0/b;
      //   236: aload #6
      //   238: getfield h : Landroid/database/sqlite/SQLiteDatabase;
      //   241: ldc 'PRAGMA foreign_keys = ON'
      //   243: invokevirtual execSQL : (Ljava/lang/String;)V
      //   246: aload_1
      //   247: getfield b : Landroidx/work/impl/WorkDatabase_Impl;
      //   250: getfield d : Lw0/e;
      //   253: astore #8
      //   255: aload #8
      //   257: monitorenter
      //   258: aload #8
      //   260: getfield f : Z
      //   263: ifeq -> 277
      //   266: ldc 'ROOM'
      //   268: ldc 'Invalidation tracker is initialized twice :/.'
      //   270: invokestatic e : (Ljava/lang/String;Ljava/lang/String;)I
      //   273: pop
      //   274: goto -> 342
      //   277: aload #6
      //   279: getfield h : Landroid/database/sqlite/SQLiteDatabase;
      //   282: ldc 'PRAGMA temp_store = MEMORY;'
      //   284: invokevirtual execSQL : (Ljava/lang/String;)V
      //   287: aload #6
      //   289: getfield h : Landroid/database/sqlite/SQLiteDatabase;
      //   292: ldc 'PRAGMA recursive_triggers='ON';'
      //   294: invokevirtual execSQL : (Ljava/lang/String;)V
      //   297: aload #6
      //   299: getfield h : Landroid/database/sqlite/SQLiteDatabase;
      //   302: ldc 'CREATE TEMP TABLE room_table_modification_log(table_id INTEGER PRIMARY KEY, invalidated INTEGER NOT NULL DEFAULT 0)'
      //   304: invokevirtual execSQL : (Ljava/lang/String;)V
      //   307: aload #8
      //   309: aload #6
      //   311: invokevirtual d : (Lz0/b;)V
      //   314: aload #8
      //   316: new a1/f
      //   319: dup
      //   320: aload #6
      //   322: getfield h : Landroid/database/sqlite/SQLiteDatabase;
      //   325: ldc 'UPDATE room_table_modification_log SET invalidated = 0 WHERE invalidated = 1 '
      //   327: invokevirtual compileStatement : (Ljava/lang/String;)Landroid/database/sqlite/SQLiteStatement;
      //   330: invokespecial <init> : (Landroid/database/sqlite/SQLiteStatement;)V
      //   333: putfield g : La1/f;
      //   336: aload #8
      //   338: iconst_1
      //   339: putfield f : Z
      //   342: aload #8
      //   344: monitorexit
      //   345: aload_1
      //   346: getfield b : Landroidx/work/impl/WorkDatabase_Impl;
      //   349: getfield g : Ljava/util/List;
      //   352: astore #8
      //   354: aload #8
      //   356: ifnull -> 404
      //   359: aload #8
      //   361: invokeinterface size : ()I
      //   366: istore #4
      //   368: iload_3
      //   369: istore_2
      //   370: iload_2
      //   371: iload #4
      //   373: if_icmpge -> 404
      //   376: aload_1
      //   377: getfield b : Landroidx/work/impl/WorkDatabase_Impl;
      //   380: getfield g : Ljava/util/List;
      //   383: iload_2
      //   384: invokeinterface get : (I)Ljava/lang/Object;
      //   389: checkcast w0/f$b
      //   392: aload #6
      //   394: invokevirtual a : (Lz0/b;)V
      //   397: iload_2
      //   398: iconst_1
      //   399: iadd
      //   400: istore_2
      //   401: goto -> 370
      //   404: aload #7
      //   406: aconst_null
      //   407: putfield b : Lw0/a;
      //   410: return
      //   411: astore_1
      //   412: aload #8
      //   414: monitorexit
      //   415: aload_1
      //   416: athrow
      //   417: ldc 'Pre-packaged database has an invalid schema: '
      //   419: invokestatic a : (Ljava/lang/String;)Ljava/lang/StringBuilder;
      //   422: astore #6
      //   424: aload #6
      //   426: aload_1
      //   427: getfield b : Ljava/lang/String;
      //   430: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
      //   433: pop
      //   434: new java/lang/IllegalStateException
      //   437: dup
      //   438: aload #6
      //   440: invokevirtual toString : ()Ljava/lang/String;
      //   443: invokespecial <init> : (Ljava/lang/String;)V
      //   446: athrow
      //   447: astore #6
      //   449: aload_1
      //   450: invokeinterface close : ()V
      //   455: aload #6
      //   457: athrow
      //   458: return
      // Exception table:
      //   from	to	target	type
      //   44	52	447	finally
      //   59	67	447	finally
      //   104	123	166	finally
      //   258	274	411	finally
      //   277	342	411	finally
      //   342	345	411	finally
      //   412	415	411	finally
    }
    
    public void onUpgrade(SQLiteDatabase param1SQLiteDatabase, int param1Int1, int param1Int2) {
      this.j = true;
      this.i.b(c(this.h, param1SQLiteDatabase), param1Int1, param1Int2);
    }
    
    public class a implements DatabaseErrorHandler {
      public a(c.a this$0, a[] param2ArrayOfa) {}
      
      public void onCorruption(SQLiteDatabase param2SQLiteDatabase) {
        c.a a1 = this.a;
        a a2 = c.a.c(this.b, param2SQLiteDatabase);
        Objects.requireNonNull(a1);
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("Corruption reported by sqlite on database: ");
        stringBuilder.append(a2.a());
        Log.e("SupportSQLite", stringBuilder.toString());
        if (a2.h.isOpen()) {
          stringBuilder = null;
          sQLiteException = null;
          try {
            List list2 = a2.h.getAttachedDbs();
          } catch (SQLiteException sQLiteException) {
          
          } finally {
            if (sQLiteException != null) {
              Iterator iterator = sQLiteException.iterator();
              while (iterator.hasNext())
                a1.a((String)((Pair)iterator.next()).second); 
            } else {
              a1.a(a2.a());
            } 
          } 
          StringBuilder stringBuilder1 = stringBuilder;
          try {
            a2.h.close();
          } catch (IOException iOException) {}
          if (stringBuilder != null) {
            Iterator iterator = stringBuilder.iterator();
            while (iterator.hasNext())
              a1.a((String)((Pair)iterator.next()).second); 
            return;
          } 
        } 
        a1.a(a2.a());
      }
    }
  }
  
  public class a implements DatabaseErrorHandler {
    public a(c this$0, a[] param1ArrayOfa) {}
    
    public void onCorruption(SQLiteDatabase param1SQLiteDatabase) {
      c.a a1 = this.a;
      a a2 = c.a.c(this.b, param1SQLiteDatabase);
      Objects.requireNonNull(a1);
      StringBuilder stringBuilder = new StringBuilder();
      stringBuilder.append("Corruption reported by sqlite on database: ");
      stringBuilder.append(a2.a());
      Log.e("SupportSQLite", stringBuilder.toString());
      if (a2.h.isOpen()) {
        stringBuilder = null;
        sQLiteException = null;
        try {
          List list2 = a2.h.getAttachedDbs();
        } catch (SQLiteException sQLiteException) {
        
        } finally {
          if (sQLiteException != null) {
            Iterator iterator = sQLiteException.iterator();
            while (iterator.hasNext())
              a1.a((String)((Pair)iterator.next()).second); 
          } else {
            a1.a(a2.a());
          } 
        } 
        StringBuilder stringBuilder1 = stringBuilder;
        try {
          a2.h.close();
        } catch (IOException iOException) {}
        if (stringBuilder != null) {
          Iterator iterator = stringBuilder.iterator();
          while (iterator.hasNext())
            a1.a((String)((Pair)iterator.next()).second); 
          return;
        } 
      } 
      a1.a(a2.a());
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Luxury Logo Maker_ Logo Design-dex2jar.jar!\a1\c.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */