package a1;

import android.database.Cursor;
import android.database.sqlite.SQLiteCursor;
import android.database.sqlite.SQLiteCursorDriver;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteProgram;
import android.database.sqlite.SQLiteQuery;
import z0.b;
import z0.e;

public class a implements b {
  public static final String[] i = new String[0];
  
  public final SQLiteDatabase h;
  
  public a(SQLiteDatabase paramSQLiteDatabase) {
    this.h = paramSQLiteDatabase;
  }
  
  public String a() {
    return this.h.getPath();
  }
  
  public Cursor c(String paramString) {
    return d((e)new z0.a(paramString));
  }
  
  public void close() {
    this.h.close();
  }
  
  public Cursor d(e parame) {
    return this.h.rawQueryWithFactory(new a(this, parame), parame.c(), i, null);
  }
  
  public class a implements SQLiteDatabase.CursorFactory {
    public a(a this$0, e param1e) {}
    
    public Cursor newCursor(SQLiteDatabase param1SQLiteDatabase, SQLiteCursorDriver param1SQLiteCursorDriver, String param1String, SQLiteQuery param1SQLiteQuery) {
      this.a.e(new e((SQLiteProgram)param1SQLiteQuery));
      return (Cursor)new SQLiteCursor(param1SQLiteCursorDriver, param1String, param1SQLiteQuery);
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Luxury Logo Maker_ Logo Design-dex2jar.jar!\a1\a.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */