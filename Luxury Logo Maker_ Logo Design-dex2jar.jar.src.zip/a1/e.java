package a1;

import android.database.sqlite.SQLiteProgram;
import z0.d;

public class e implements d {
  public final SQLiteProgram h;
  
  public e(SQLiteProgram paramSQLiteProgram) {
    this.h = paramSQLiteProgram;
  }
  
  public void close() {
    this.h.close();
  }
}


/* Location:              C:\soft\dex2jar-2.0\Luxury Logo Maker_ Logo Design-dex2jar.jar!\a1\e.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */