package b3;

import android.app.Activity;
import android.support.v4.media.b;

public abstract class a {
  public abstract void a(b paramb);
  
  public abstract void b(Activity paramActivity);
}


/* Location:              C:\soft\dex2jar-2.0\Luxury Logo Maker_ Logo Design-dex2jar.jar!\b3\a.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */