package b2;

import android.net.Uri;
import android.os.Bundle;
import android.os.IBinder;
import android.os.Parcel;
import android.os.Parcelable;
import java.util.List;
import k6.f;
import photofiesta.luxury.logomaker.FrameWorking.FrameActivity;

public class b implements f {
  public static final int[] a = new int[] { 16843173, 16843551, 2130968619 };
  
  public static final int[] b = new int[] { 2130968946, 2130968947, 2130968948, 2130968949, 2130968950, 2130968951, 2130968952 };
  
  public static final int[] c = new int[] { 16844082, 16844083, 16844095, 16844143, 16844144, 2130968944, 2130968953, 2130968954, 2130968955, 2130969492 };
  
  public static final int[] d = new int[] { 
      16843165, 16843166, 16843169, 16843170, 16843171, 16843172, 16843265, 16843275, 16844048, 16844049, 
      16844050, 16844051 };
  
  public static final int[] e = new int[] { 16843173, 16844052 };
  
  public static boolean a(Uri paramUri) {
    return (paramUri != null && "content".equals(paramUri.getScheme()) && "media".equals(paramUri.getAuthority()));
  }
  
  public static boolean b(int paramInt1, int paramInt2) {
    return (paramInt1 != Integer.MIN_VALUE && paramInt2 != Integer.MIN_VALUE && paramInt1 <= 512 && paramInt2 <= 384);
  }
  
  public static void c(Parcel paramParcel, int paramInt, Bundle paramBundle, boolean paramBoolean) {
    if (paramBundle == null) {
      if (paramBoolean)
        paramParcel.writeInt(paramInt | 0x0); 
      return;
    } 
    paramInt = l(paramParcel, paramInt);
    paramParcel.writeBundle(paramBundle);
    m(paramParcel, paramInt);
  }
  
  public static void d(Parcel paramParcel, int paramInt, byte[] paramArrayOfbyte, boolean paramBoolean) {
    if (paramArrayOfbyte == null) {
      if (paramBoolean)
        paramParcel.writeInt(paramInt | 0x0); 
      return;
    } 
    paramInt = l(paramParcel, paramInt);
    paramParcel.writeByteArray(paramArrayOfbyte);
    m(paramParcel, paramInt);
  }
  
  public static void e(Parcel paramParcel, int paramInt, IBinder paramIBinder, boolean paramBoolean) {
    if (paramIBinder == null) {
      if (paramBoolean)
        paramParcel.writeInt(paramInt | 0x0); 
      return;
    } 
    paramInt = l(paramParcel, paramInt);
    paramParcel.writeStrongBinder(paramIBinder);
    m(paramParcel, paramInt);
  }
  
  public static void f(Parcel paramParcel, int paramInt1, Parcelable paramParcelable, int paramInt2, boolean paramBoolean) {
    if (paramParcelable == null) {
      if (paramBoolean)
        paramParcel.writeInt(paramInt1 | 0x0); 
      return;
    } 
    paramInt1 = l(paramParcel, paramInt1);
    paramParcelable.writeToParcel(paramParcel, paramInt2);
    m(paramParcel, paramInt1);
  }
  
  public static void g(Parcel paramParcel, int paramInt, String paramString, boolean paramBoolean) {
    if (paramString == null) {
      if (paramBoolean)
        paramParcel.writeInt(paramInt | 0x0); 
      return;
    } 
    paramInt = l(paramParcel, paramInt);
    paramParcel.writeString(paramString);
    m(paramParcel, paramInt);
  }
  
  public static void h(Parcel paramParcel, int paramInt, String[] paramArrayOfString, boolean paramBoolean) {
    if (paramArrayOfString == null) {
      if (paramBoolean)
        paramParcel.writeInt(paramInt | 0x0); 
      return;
    } 
    paramInt = l(paramParcel, paramInt);
    paramParcel.writeStringArray(paramArrayOfString);
    m(paramParcel, paramInt);
  }
  
  public static void i(Parcel paramParcel, int paramInt, List paramList, boolean paramBoolean) {
    if (paramList == null) {
      if (paramBoolean)
        paramParcel.writeInt(paramInt | 0x0); 
      return;
    } 
    paramInt = l(paramParcel, paramInt);
    paramParcel.writeStringList(paramList);
    m(paramParcel, paramInt);
  }
  
  public static void j(Parcel paramParcel, int paramInt1, Parcelable[] paramArrayOfParcelable, int paramInt2, boolean paramBoolean) {
    if (paramArrayOfParcelable == null) {
      if (paramBoolean)
        paramParcel.writeInt(paramInt1 | 0x0); 
      return;
    } 
    int i = l(paramParcel, paramInt1);
    int j = paramArrayOfParcelable.length;
    paramParcel.writeInt(j);
    for (paramInt1 = 0; paramInt1 < j; paramInt1++) {
      Parcelable parcelable = paramArrayOfParcelable[paramInt1];
      if (parcelable == null) {
        paramParcel.writeInt(0);
      } else {
        n(paramParcel, parcelable, paramInt2);
      } 
    } 
    m(paramParcel, i);
  }
  
  public static void k(Parcel paramParcel, int paramInt, List<Parcelable> paramList, boolean paramBoolean) {
    if (paramList == null) {
      if (paramBoolean)
        paramParcel.writeInt(paramInt | 0x0); 
      return;
    } 
    int i = l(paramParcel, paramInt);
    int j = paramList.size();
    paramParcel.writeInt(j);
    for (paramInt = 0; paramInt < j; paramInt++) {
      Parcelable parcelable = paramList.get(paramInt);
      if (parcelable == null) {
        paramParcel.writeInt(0);
      } else {
        n(paramParcel, parcelable, 0);
      } 
    } 
    m(paramParcel, i);
  }
  
  public static int l(Parcel paramParcel, int paramInt) {
    paramParcel.writeInt(paramInt | 0xFFFF0000);
    paramParcel.writeInt(0);
    return paramParcel.dataPosition();
  }
  
  public static void m(Parcel paramParcel, int paramInt) {
    int i = paramParcel.dataPosition();
    paramParcel.setDataPosition(paramInt - 4);
    paramParcel.writeInt(i - paramInt);
    paramParcel.setDataPosition(i);
  }
  
  public static void n(Parcel paramParcel, Parcelable paramParcelable, int paramInt) {
    int i = paramParcel.dataPosition();
    paramParcel.writeInt(1);
    int j = paramParcel.dataPosition();
    paramParcelable.writeToParcel(paramParcel, paramInt);
    paramInt = paramParcel.dataPosition();
    paramParcel.setDataPosition(i);
    paramParcel.writeInt(paramInt - j);
    paramParcel.setDataPosition(paramInt);
  }
}


/* Location:              C:\soft\dex2jar-2.0\Luxury Logo Maker_ Logo Design-dex2jar.jar!\b2\b.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */