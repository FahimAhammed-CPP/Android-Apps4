package b2;

import android.content.ContentResolver;
import com.bumptech.glide.load.ImageHeaderParser;
import d2.b;
import java.util.List;

public class e {
  public static final a e = new a();
  
  public final d a;
  
  public final b b;
  
  public final ContentResolver c;
  
  public final List<ImageHeaderParser> d;
  
  public e(List<ImageHeaderParser> paramList, d paramd, b paramb, ContentResolver paramContentResolver) {
    this.a = paramd;
    this.b = paramb;
    this.c = paramContentResolver;
    this.d = paramList;
  }
}


/* Location:              C:\soft\dex2jar-2.0\Luxury Logo Maker_ Logo Design-dex2jar.jar!\b2\e.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */