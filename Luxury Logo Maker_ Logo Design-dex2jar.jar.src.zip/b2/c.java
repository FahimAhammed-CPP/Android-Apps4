package b2;

import android.content.ContentResolver;
import android.content.Context;
import android.database.Cursor;
import android.net.Uri;
import android.provider.MediaStore;
import android.util.Log;
import com.bumptech.glide.f;
import com.bumptech.glide.load.data.d;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;

public class c implements d<InputStream> {
  public final Uri h;
  
  public final e i;
  
  public InputStream j;
  
  public c(Uri paramUri, e parame) {
    this.h = paramUri;
    this.i = parame;
  }
  
  public static c c(Context paramContext, Uri paramUri, d paramd) {
    d2.b b = (com.bumptech.glide.b.a(paramContext)).k;
    return new c(paramUri, new e((com.bumptech.glide.b.a(paramContext)).j.a().e(), paramd, b, paramContext.getContentResolver()));
  }
  
  public Class<InputStream> a() {
    return InputStream.class;
  }
  
  public void b() {
    InputStream inputStream = this.j;
    if (inputStream != null)
      try {
        inputStream.close();
        return;
      } catch (IOException iOException) {
        return;
      }  
  }
  
  public void cancel() {}
  
  public final InputStream d() {
    // Byte code:
    //   0: aload_0
    //   1: getfield i : Lb2/e;
    //   4: astore #10
    //   6: aload_0
    //   7: getfield h : Landroid/net/Uri;
    //   10: astore #9
    //   12: aload #10
    //   14: invokestatic requireNonNull : (Ljava/lang/Object;)Ljava/lang/Object;
    //   17: pop
    //   18: iconst_0
    //   19: istore_2
    //   20: aconst_null
    //   21: astore #7
    //   23: aconst_null
    //   24: astore #6
    //   26: aconst_null
    //   27: astore #4
    //   29: aconst_null
    //   30: astore #8
    //   32: aload #10
    //   34: getfield a : Lb2/d;
    //   37: aload #9
    //   39: invokeinterface a : (Landroid/net/Uri;)Landroid/database/Cursor;
    //   44: astore_3
    //   45: aload_3
    //   46: ifnull -> 94
    //   49: aload_3
    //   50: astore #4
    //   52: aload_3
    //   53: invokeinterface moveToFirst : ()Z
    //   58: ifeq -> 94
    //   61: aload_3
    //   62: astore #4
    //   64: aload_3
    //   65: iconst_0
    //   66: invokeinterface getString : (I)Ljava/lang/String;
    //   71: astore #5
    //   73: aload_3
    //   74: invokeinterface close : ()V
    //   79: aload #5
    //   81: astore_3
    //   82: goto -> 183
    //   85: astore_3
    //   86: goto -> 539
    //   89: astore #5
    //   91: goto -> 109
    //   94: aload_3
    //   95: ifnull -> 181
    //   98: goto -> 175
    //   101: astore_3
    //   102: goto -> 539
    //   105: astore #5
    //   107: aconst_null
    //   108: astore_3
    //   109: aload_3
    //   110: astore #4
    //   112: ldc 'ThumbStreamOpener'
    //   114: iconst_3
    //   115: invokestatic isLoggable : (Ljava/lang/String;I)Z
    //   118: ifeq -> 171
    //   121: aload_3
    //   122: astore #4
    //   124: new java/lang/StringBuilder
    //   127: dup
    //   128: invokespecial <init> : ()V
    //   131: astore #11
    //   133: aload_3
    //   134: astore #4
    //   136: aload #11
    //   138: ldc 'Failed to query for thumbnail for Uri: '
    //   140: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   143: pop
    //   144: aload_3
    //   145: astore #4
    //   147: aload #11
    //   149: aload #9
    //   151: invokevirtual append : (Ljava/lang/Object;)Ljava/lang/StringBuilder;
    //   154: pop
    //   155: aload_3
    //   156: astore #4
    //   158: ldc 'ThumbStreamOpener'
    //   160: aload #11
    //   162: invokevirtual toString : ()Ljava/lang/String;
    //   165: aload #5
    //   167: invokestatic d : (Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)I
    //   170: pop
    //   171: aload_3
    //   172: ifnull -> 181
    //   175: aload_3
    //   176: invokeinterface close : ()V
    //   181: aconst_null
    //   182: astore_3
    //   183: aload_3
    //   184: invokestatic isEmpty : (Ljava/lang/CharSequence;)Z
    //   187: ifeq -> 195
    //   190: aconst_null
    //   191: astore_3
    //   192: goto -> 250
    //   195: new java/io/File
    //   198: dup
    //   199: aload_3
    //   200: invokespecial <init> : (Ljava/lang/String;)V
    //   203: astore_3
    //   204: iload_2
    //   205: istore_1
    //   206: aload_3
    //   207: invokevirtual exists : ()Z
    //   210: ifeq -> 226
    //   213: iload_2
    //   214: istore_1
    //   215: lconst_0
    //   216: aload_3
    //   217: invokevirtual length : ()J
    //   220: lcmp
    //   221: ifge -> 226
    //   224: iconst_1
    //   225: istore_1
    //   226: iload_1
    //   227: ifne -> 233
    //   230: goto -> 190
    //   233: aload_3
    //   234: invokestatic fromFile : (Ljava/io/File;)Landroid/net/Uri;
    //   237: astore #4
    //   239: aload #10
    //   241: getfield c : Landroid/content/ContentResolver;
    //   244: aload #4
    //   246: invokevirtual openInputStream : (Landroid/net/Uri;)Ljava/io/InputStream;
    //   249: astore_3
    //   250: aload_3
    //   251: ifnull -> 453
    //   254: aload_0
    //   255: getfield i : Lb2/e;
    //   258: astore #10
    //   260: aload_0
    //   261: getfield h : Landroid/net/Uri;
    //   264: astore #9
    //   266: aload #10
    //   268: invokestatic requireNonNull : (Ljava/lang/Object;)Ljava/lang/Object;
    //   271: pop
    //   272: aload #8
    //   274: astore #4
    //   276: aload #7
    //   278: astore #5
    //   280: aload #10
    //   282: getfield c : Landroid/content/ContentResolver;
    //   285: aload #9
    //   287: invokevirtual openInputStream : (Landroid/net/Uri;)Ljava/io/InputStream;
    //   290: astore #7
    //   292: aload #7
    //   294: astore #4
    //   296: aload #7
    //   298: astore #5
    //   300: aload #7
    //   302: astore #6
    //   304: aload #10
    //   306: getfield d : Ljava/util/List;
    //   309: aload #7
    //   311: aload #10
    //   313: getfield b : Ld2/b;
    //   316: invokestatic a : (Ljava/util/List;Ljava/io/InputStream;Ld2/b;)I
    //   319: istore_2
    //   320: iload_2
    //   321: istore_1
    //   322: aload #7
    //   324: ifnull -> 455
    //   327: aload #7
    //   329: invokevirtual close : ()V
    //   332: iload_2
    //   333: istore_1
    //   334: goto -> 455
    //   337: iload_2
    //   338: istore_1
    //   339: goto -> 455
    //   342: astore_3
    //   343: goto -> 441
    //   346: astore #6
    //   348: goto -> 361
    //   351: astore #4
    //   353: aload #6
    //   355: astore #5
    //   357: aload #4
    //   359: astore #6
    //   361: aload #5
    //   363: astore #4
    //   365: ldc 'ThumbStreamOpener'
    //   367: iconst_3
    //   368: invokestatic isLoggable : (Ljava/lang/String;I)Z
    //   371: ifeq -> 428
    //   374: aload #5
    //   376: astore #4
    //   378: new java/lang/StringBuilder
    //   381: dup
    //   382: invokespecial <init> : ()V
    //   385: astore #7
    //   387: aload #5
    //   389: astore #4
    //   391: aload #7
    //   393: ldc 'Failed to open uri: '
    //   395: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   398: pop
    //   399: aload #5
    //   401: astore #4
    //   403: aload #7
    //   405: aload #9
    //   407: invokevirtual append : (Ljava/lang/Object;)Ljava/lang/StringBuilder;
    //   410: pop
    //   411: aload #5
    //   413: astore #4
    //   415: ldc 'ThumbStreamOpener'
    //   417: aload #7
    //   419: invokevirtual toString : ()Ljava/lang/String;
    //   422: aload #6
    //   424: invokestatic d : (Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)I
    //   427: pop
    //   428: aload #5
    //   430: ifnull -> 453
    //   433: aload #5
    //   435: invokevirtual close : ()V
    //   438: goto -> 453
    //   441: aload #4
    //   443: ifnull -> 451
    //   446: aload #4
    //   448: invokevirtual close : ()V
    //   451: aload_3
    //   452: athrow
    //   453: iconst_m1
    //   454: istore_1
    //   455: aload_3
    //   456: astore #4
    //   458: iload_1
    //   459: iconst_m1
    //   460: if_icmpeq -> 474
    //   463: new com/bumptech/glide/load/data/g
    //   466: dup
    //   467: aload_3
    //   468: iload_1
    //   469: invokespecial <init> : (Ljava/io/InputStream;I)V
    //   472: astore #4
    //   474: aload #4
    //   476: areturn
    //   477: astore_3
    //   478: new java/lang/StringBuilder
    //   481: dup
    //   482: invokespecial <init> : ()V
    //   485: astore #5
    //   487: aload #5
    //   489: ldc 'NPE opening uri: '
    //   491: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   494: pop
    //   495: aload #5
    //   497: aload #9
    //   499: invokevirtual append : (Ljava/lang/Object;)Ljava/lang/StringBuilder;
    //   502: pop
    //   503: aload #5
    //   505: ldc ' -> '
    //   507: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   510: pop
    //   511: aload #5
    //   513: aload #4
    //   515: invokevirtual append : (Ljava/lang/Object;)Ljava/lang/StringBuilder;
    //   518: pop
    //   519: new java/io/FileNotFoundException
    //   522: dup
    //   523: aload #5
    //   525: invokevirtual toString : ()Ljava/lang/String;
    //   528: invokespecial <init> : (Ljava/lang/String;)V
    //   531: aload_3
    //   532: invokevirtual initCause : (Ljava/lang/Throwable;)Ljava/lang/Throwable;
    //   535: checkcast java/io/FileNotFoundException
    //   538: athrow
    //   539: aload #4
    //   541: ifnull -> 551
    //   544: aload #4
    //   546: invokeinterface close : ()V
    //   551: aload_3
    //   552: athrow
    //   553: astore #4
    //   555: goto -> 337
    //   558: astore #4
    //   560: goto -> 453
    //   563: astore #4
    //   565: goto -> 451
    // Exception table:
    //   from	to	target	type
    //   32	45	105	java/lang/SecurityException
    //   32	45	101	finally
    //   52	61	89	java/lang/SecurityException
    //   52	61	85	finally
    //   64	73	89	java/lang/SecurityException
    //   64	73	85	finally
    //   112	121	85	finally
    //   124	133	85	finally
    //   136	144	85	finally
    //   147	155	85	finally
    //   158	171	85	finally
    //   239	250	477	java/lang/NullPointerException
    //   280	292	351	java/io/IOException
    //   280	292	346	java/lang/NullPointerException
    //   280	292	342	finally
    //   304	320	351	java/io/IOException
    //   304	320	346	java/lang/NullPointerException
    //   304	320	342	finally
    //   327	332	553	java/io/IOException
    //   365	374	342	finally
    //   378	387	342	finally
    //   391	399	342	finally
    //   403	411	342	finally
    //   415	428	342	finally
    //   433	438	558	java/io/IOException
    //   446	451	563	java/io/IOException
  }
  
  public a2.a e() {
    return a2.a.h;
  }
  
  public void f(f paramf, d.a<? super InputStream> parama) {
    try {
      InputStream inputStream = d();
      this.j = inputStream;
      parama.d(inputStream);
      return;
    } catch (FileNotFoundException fileNotFoundException) {
      if (Log.isLoggable("MediaStoreThumbFetcher", 3))
        Log.d("MediaStoreThumbFetcher", "Failed to find thumbnail file", fileNotFoundException); 
      parama.c(fileNotFoundException);
      return;
    } 
  }
  
  public static class a implements d {
    public static final String[] b = new String[] { "_data" };
    
    public final ContentResolver a;
    
    public a(ContentResolver param1ContentResolver) {
      this.a = param1ContentResolver;
    }
    
    public Cursor a(Uri param1Uri) {
      String str = param1Uri.getLastPathSegment();
      return this.a.query(MediaStore.Images.Thumbnails.EXTERNAL_CONTENT_URI, b, "kind = 1 AND image_id = ?", new String[] { str }, null);
    }
  }
  
  public static class b implements d {
    public static final String[] b = new String[] { "_data" };
    
    public final ContentResolver a;
    
    public b(ContentResolver param1ContentResolver) {
      this.a = param1ContentResolver;
    }
    
    public Cursor a(Uri param1Uri) {
      String str = param1Uri.getLastPathSegment();
      return this.a.query(MediaStore.Video.Thumbnails.EXTERNAL_CONTENT_URI, b, "kind = 1 AND video_id = ?", new String[] { str }, null);
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Luxury Logo Maker_ Logo Design-dex2jar.jar!\b2\c.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */