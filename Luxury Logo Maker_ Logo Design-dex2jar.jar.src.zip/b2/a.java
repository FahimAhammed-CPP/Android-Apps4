package b2;

import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.util.Log;
import android.view.MotionEvent;
import e4.a80;
import e4.jo;
import e4.ka2;
import java.util.ArrayList;
import java.util.Objects;
import java.util.concurrent.atomic.AtomicReference;
import n6.c;
import n6.d;
import photofiesta.xiaopo.flying.logoSticker.StickerView;
import t.d;
import u.c;
import u.d;
import u.e;

public class a implements d {
  public static boolean[] h = new boolean[3];
  
  public static void a(e parame, d paramd, d paramd1) {
    paramd1.j = -1;
    paramd1.k = -1;
    if (((d)parame).O[0] != 2 && paramd1.O[0] == 4) {
      int i = paramd1.D.g;
      int j = parame.r() - paramd1.F.g;
      c c = paramd1.D;
      c.i = paramd.l(c);
      c = paramd1.F;
      c.i = paramd.l(c);
      paramd.e(paramd1.D.i, i);
      paramd.e(paramd1.F.i, j);
      paramd1.j = 2;
      paramd1.U = i;
      i = j - i;
      paramd1.Q = i;
      j = paramd1.X;
      if (i < j)
        paramd1.Q = j; 
    } 
    if (((d)parame).O[1] != 2 && paramd1.O[1] == 4) {
      int i = paramd1.E.g;
      int j = parame.l() - paramd1.G.g;
      c c = paramd1.E;
      c.i = paramd.l(c);
      c = paramd1.G;
      c.i = paramd.l(c);
      paramd.e(paramd1.E.i, i);
      paramd.e(paramd1.G.i, j);
      if (paramd1.W > 0 || paramd1.c0 == 8) {
        c = paramd1.H;
        c.i = paramd.l(c);
        paramd.e(paramd1.H.i, paramd1.W + i);
      } 
      paramd1.k = 2;
      paramd1.V = i;
      i = j - i;
      paramd1.R = i;
      j = paramd1.Y;
      if (i < j)
        paramd1.R = j; 
    } 
  }
  
  public static final boolean d(int paramInt1, int paramInt2) {
    return ((paramInt1 & paramInt2) == paramInt2);
  }
  
  public static int e(Cursor paramCursor, String paramString) {
    int i = paramCursor.getColumnIndex(paramString);
    if (i >= 0)
      return i; 
    StringBuilder stringBuilder = new StringBuilder();
    stringBuilder.append("`");
    stringBuilder.append(paramString);
    stringBuilder.append("`");
    return paramCursor.getColumnIndexOrThrow(stringBuilder.toString());
  }
  
  public static int g(SQLiteDatabase paramSQLiteDatabase, int paramInt) {
    Cursor cursor = n(paramSQLiteDatabase, paramInt);
    if (cursor.getCount() > 0) {
      cursor.moveToNext();
      paramInt = cursor.getInt(cursor.getColumnIndexOrThrow("value"));
    } else {
      paramInt = 0;
    } 
    cursor.close();
    return paramInt;
  }
  
  public static String h(String paramString) {
    char[] arrayOfChar;
    int j = paramString.length();
    for (int i = 0; i < j; i++) {
      char c = paramString.charAt(i);
      if (c >= 'A' && c <= 'Z') {
        c = '\001';
      } else {
        c = Character.MIN_VALUE;
      } 
      if (c != '\000') {
        arrayOfChar = paramString.toCharArray();
        while (i < j) {
          char c1 = arrayOfChar[i];
          if (c1 >= 'A' && c1 <= 'Z') {
            c = '\001';
          } else {
            c = Character.MIN_VALUE;
          } 
          if (c != '\000')
            arrayOfChar[i] = (char)(c1 ^ 0x20); 
          i++;
        } 
        return String.valueOf(arrayOfChar);
      } 
    } 
    return (String)arrayOfChar;
  }
  
  public static long j(SQLiteDatabase paramSQLiteDatabase) {
    long l;
    Cursor cursor = n(paramSQLiteDatabase, 2);
    if (cursor.getCount() > 0) {
      cursor.moveToNext();
      l = cursor.getLong(cursor.getColumnIndexOrThrow("value"));
    } else {
      l = 0L;
    } 
    cursor.close();
    return l;
  }
  
  public static String k(String paramString) {
    char[] arrayOfChar;
    int j = paramString.length();
    for (int i = 0; i < j; i++) {
      char c = paramString.charAt(i);
      if (c >= 'a' && c <= 'z') {
        c = '\001';
      } else {
        c = Character.MIN_VALUE;
      } 
      if (c != '\000') {
        arrayOfChar = paramString.toCharArray();
        while (i < j) {
          char c1 = arrayOfChar[i];
          if (c1 >= 'a' && c1 <= 'z') {
            c = '\001';
          } else {
            c = Character.MIN_VALUE;
          } 
          if (c != '\000')
            arrayOfChar[i] = (char)(c1 ^ 0x20); 
          i++;
        } 
        return String.valueOf(arrayOfChar);
      } 
    } 
    return (String)arrayOfChar;
  }
  
  public static ArrayList l(SQLiteDatabase paramSQLiteDatabase) {
    ArrayList<jo> arrayList = new ArrayList();
    Cursor cursor = paramSQLiteDatabase.query("offline_signal_contents", new String[] { "serialized_proto_data" }, null, null, null, null, null);
    while (cursor.moveToNext()) {
      byte[] arrayOfByte = cursor.getBlob(cursor.getColumnIndexOrThrow("serialized_proto_data"));
      try {
        arrayList.add(jo.F(arrayOfByte));
      } catch (ka2 ka2) {
        a80.d("Unable to deserialize proto from offline signals database:");
        a80.d(ka2.getMessage());
      } 
    } 
    cursor.close();
    return arrayList;
  }
  
  public static boolean m(CharSequence paramCharSequence1, CharSequence paramCharSequence2) {
    int i = paramCharSequence1.length();
    if (paramCharSequence1 == paramCharSequence2)
      return true; 
    if (i == paramCharSequence2.length()) {
      for (int j = 0; j < i; j++) {
        char c2 = paramCharSequence1.charAt(j);
        char c1 = paramCharSequence2.charAt(j);
        if (c2 != c1) {
          c2 = (char)((c2 | 0x20) - 97);
          if (c2 < '\032') {
            if (c2 != (char)((c1 | 0x20) - 97))
              return false; 
          } else {
            return false;
          } 
        } 
      } 
      return true;
    } 
    return false;
  }
  
  public static Cursor n(SQLiteDatabase paramSQLiteDatabase, int paramInt) {
    String[] arrayOfString = new String[1];
    if (paramInt != 0) {
      if (paramInt != 1) {
        arrayOfString[0] = "last_successful_request_time";
      } else {
        arrayOfString[0] = "total_requests";
      } 
    } else {
      arrayOfString[0] = "failed_requests";
    } 
    return paramSQLiteDatabase.query("offline_signal_statistics", new String[] { "value" }, "statistic_name = ?", arrayOfString, null, null, null);
  }
  
  public void b(StickerView paramStickerView, MotionEvent paramMotionEvent) {
    Objects.requireNonNull(paramStickerView);
    c c = StickerView.H;
    if (((ArrayList)StickerView.G).contains(c)) {
      ((ArrayList)StickerView.G).remove(c);
      if (StickerView.H == c)
        StickerView.H = null; 
      paramStickerView.invalidate();
      return;
    } 
    Log.d("StickerView", "remove: the sticker is not in this StickerView");
  }
  
  public void c(StickerView paramStickerView, MotionEvent paramMotionEvent) {}
  
  public void f(StickerView paramStickerView, MotionEvent paramMotionEvent) {}
}


/* Location:              C:\soft\dex2jar-2.0\Luxury Logo Maker_ Logo Design-dex2jar.jar!\b2\a.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */