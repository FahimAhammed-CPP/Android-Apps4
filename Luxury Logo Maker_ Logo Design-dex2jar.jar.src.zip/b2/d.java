package b2;

import android.database.Cursor;
import android.net.Uri;

public interface d {
  Cursor a(Uri paramUri);
}


/* Location:              C:\soft\dex2jar-2.0\Luxury Logo Maker_ Logo Design-dex2jar.jar!\b2\d.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */