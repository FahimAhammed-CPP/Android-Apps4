package b4;

import android.content.Context;

public class c {
  public static c b = new c();
  
  public b a = null;
  
  public static b a(Context paramContext) {
    synchronized (b) {
      if (null.a == null) {
        Context context = paramContext;
        if (paramContext.getApplicationContext() != null)
          context = paramContext.getApplicationContext(); 
        null.a = new b(context);
      } 
      return null.a;
    } 
  }
}


/* Location:              C:\soft\dex2jar-2.0\Luxury Logo Maker_ Logo Design-dex2jar.jar!\b4\c.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */