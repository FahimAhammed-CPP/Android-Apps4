package b4;

import a4.h;
import android.content.Context;
import android.content.pm.ApplicationInfo;
import android.content.pm.PackageInfo;
import android.os.Binder;
import android.os.Process;

public class b {
  public final Context a;
  
  public b(Context paramContext) {
    this.a = paramContext;
  }
  
  public ApplicationInfo a(String paramString, int paramInt) {
    return this.a.getPackageManager().getApplicationInfo(paramString, paramInt);
  }
  
  public CharSequence b(String paramString) {
    return this.a.getPackageManager().getApplicationLabel(this.a.getPackageManager().getApplicationInfo(paramString, 0));
  }
  
  public PackageInfo c(String paramString, int paramInt) {
    return this.a.getPackageManager().getPackageInfo(paramString, paramInt);
  }
  
  public boolean d() {
    if (Binder.getCallingUid() == Process.myUid())
      return a.b(this.a); 
    if (h.a()) {
      String str = this.a.getPackageManager().getNameForUid(Binder.getCallingUid());
      if (str != null)
        return this.a.getPackageManager().isInstantApp(str); 
    } 
    return false;
  }
}


/* Location:              C:\soft\dex2jar-2.0\Luxury Logo Maker_ Logo Design-dex2jar.jar!\b4\b.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */