package b4;

import android.content.Context;
import android.graphics.drawable.Drawable;
import android.view.View;
import android.view.ViewParent;
import android.view.inputmethod.EditorInfo;
import android.view.inputmethod.InputConnection;
import androidx.appcompat.widget.h1;
import com.google.android.material.behavior.SwipeDismissBehavior;
import java.util.WeakHashMap;
import k0.l;
import l5.d;
import l5.f;
import l5.h;

public class a {
  public static Context a;
  
  public static Boolean b;
  
  public static v3.a a(int paramInt) {
    return (v3.a)((paramInt != 0) ? ((paramInt != 1) ? new h() : new d()) : new h());
  }
  
  public static boolean b(Context paramContext) {
    // Byte code:
    //   0: ldc b4/a
    //   2: monitorenter
    //   3: aload_0
    //   4: invokevirtual getApplicationContext : ()Landroid/content/Context;
    //   7: astore_2
    //   8: getstatic b4/a.a : Landroid/content/Context;
    //   11: astore_3
    //   12: aload_3
    //   13: ifnull -> 45
    //   16: getstatic b4/a.b : Ljava/lang/Boolean;
    //   19: astore #4
    //   21: aload #4
    //   23: ifnull -> 45
    //   26: aload_3
    //   27: aload_2
    //   28: if_acmpeq -> 34
    //   31: goto -> 45
    //   34: aload #4
    //   36: invokevirtual booleanValue : ()Z
    //   39: istore_1
    //   40: ldc b4/a
    //   42: monitorexit
    //   43: iload_1
    //   44: ireturn
    //   45: aconst_null
    //   46: putstatic b4/a.b : Ljava/lang/Boolean;
    //   49: invokestatic a : ()Z
    //   52: ifeq -> 73
    //   55: aload_2
    //   56: invokevirtual getPackageManager : ()Landroid/content/pm/PackageManager;
    //   59: invokevirtual isInstantApp : ()Z
    //   62: invokestatic valueOf : (Z)Ljava/lang/Boolean;
    //   65: astore_0
    //   66: aload_0
    //   67: putstatic b4/a.b : Ljava/lang/Boolean;
    //   70: goto -> 99
    //   73: aload_0
    //   74: invokevirtual getClassLoader : ()Ljava/lang/ClassLoader;
    //   77: ldc 'com.google.android.instantapps.supervisor.InstantAppsRuntime'
    //   79: invokevirtual loadClass : (Ljava/lang/String;)Ljava/lang/Class;
    //   82: pop
    //   83: getstatic java/lang/Boolean.TRUE : Ljava/lang/Boolean;
    //   86: putstatic b4/a.b : Ljava/lang/Boolean;
    //   89: goto -> 99
    //   92: getstatic java/lang/Boolean.FALSE : Ljava/lang/Boolean;
    //   95: astore_0
    //   96: goto -> 66
    //   99: aload_2
    //   100: putstatic b4/a.a : Landroid/content/Context;
    //   103: getstatic b4/a.b : Ljava/lang/Boolean;
    //   106: invokevirtual booleanValue : ()Z
    //   109: istore_1
    //   110: ldc b4/a
    //   112: monitorexit
    //   113: iload_1
    //   114: ireturn
    //   115: astore_0
    //   116: ldc b4/a
    //   118: monitorexit
    //   119: aload_0
    //   120: athrow
    //   121: astore_0
    //   122: goto -> 92
    // Exception table:
    //   from	to	target	type
    //   3	12	115	finally
    //   16	21	115	finally
    //   34	40	115	finally
    //   45	66	115	finally
    //   66	70	115	finally
    //   73	89	121	java/lang/ClassNotFoundException
    //   73	89	115	finally
    //   92	96	115	finally
    //   99	110	115	finally
  }
  
  public static InputConnection c(InputConnection paramInputConnection, EditorInfo paramEditorInfo, View paramView) {
    if (paramInputConnection != null && paramEditorInfo.hintText == null)
      for (ViewParent viewParent = paramView.getParent(); viewParent instanceof View; viewParent = viewParent.getParent()) {
        if (viewParent instanceof h1) {
          paramEditorInfo.hintText = ((h1)viewParent).a();
          return paramInputConnection;
        } 
      }  
    return paramInputConnection;
  }
  
  public static void d(View paramView, float paramFloat) {
    Drawable drawable = paramView.getBackground();
    if (drawable instanceof f) {
      f f = (f)drawable;
      f.b b = f.h;
      if (b.o != paramFloat) {
        b.o = paramFloat;
        f.w();
      } 
    } 
  }
  
  public static void e(View paramView, f paramf) {
    boolean bool;
    d5.a a1 = paramf.h.b;
    if (a1 != null && a1.a) {
      bool = true;
    } else {
      bool = false;
    } 
    if (bool) {
      ViewParent viewParent = paramView.getParent();
      float f1 = 0.0F;
      while (viewParent instanceof View) {
        View view = (View)viewParent;
        WeakHashMap weakHashMap = l.a;
        f1 += view.getElevation();
        viewParent = viewParent.getParent();
      } 
      f.b b = paramf.h;
      if (b.n != f1) {
        b.n = f1;
        paramf.w();
      } 
    } 
  }
}


/* Location:              C:\soft\dex2jar-2.0\Luxury Logo Maker_ Logo Design-dex2jar.jar!\b4\a.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */