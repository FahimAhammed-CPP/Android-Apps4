package androidx.coordinatorlayout.widget;

import android.content.Context;
import android.content.res.Resources;
import android.content.res.TypedArray;
import android.graphics.Canvas;
import android.graphics.Matrix;
import android.graphics.Rect;
import android.graphics.RectF;
import android.graphics.drawable.ColorDrawable;
import android.graphics.drawable.Drawable;
import android.os.Build;
import android.os.Parcel;
import android.os.Parcelable;
import android.os.SystemClock;
import android.util.AttributeSet;
import android.util.Log;
import android.util.SparseArray;
import android.view.Gravity;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.view.ViewParent;
import android.view.ViewTreeObserver;
import e4.ho0;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.lang.reflect.Constructor;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.WeakHashMap;
import k0.g;
import k0.h;
import k0.j;
import k0.l;
import k0.r;

public class CoordinatorLayout extends ViewGroup implements g, h {
  public static final String A;
  
  public static final Class<?>[] B;
  
  public static final ThreadLocal<Map<String, Constructor<c>>> C;
  
  public static final Comparator<View> D = new i();
  
  public static final j0.c<Rect> E;
  
  public final List<View> h = new ArrayList<View>();
  
  public final y.a i;
  
  public final List<View> j;
  
  public final List<View> k;
  
  public final int[] l;
  
  public final int[] m;
  
  public boolean n;
  
  public boolean o;
  
  public int[] p;
  
  public View q;
  
  public View r;
  
  public g s;
  
  public boolean t;
  
  public r u;
  
  public boolean v;
  
  public Drawable w;
  
  public ViewGroup.OnHierarchyChangeListener x;
  
  public j y;
  
  public final k0.i z;
  
  static {
    B = new Class[] { Context.class, AttributeSet.class };
    C = new ThreadLocal<Map<String, Constructor<c>>>();
    E = (j0.c<Rect>)new j0.e(12);
  }
  
  public CoordinatorLayout(Context paramContext, AttributeSet paramAttributeSet) {
    super(paramContext, paramAttributeSet, 2130968810);
    int k = 0;
    this.i = new y.a(0);
    this.j = new ArrayList<View>();
    this.k = new ArrayList<View>();
    this.l = new int[2];
    this.m = new int[2];
    this.z = new k0.i();
    int[] arrayOfInt = ho0.k;
    TypedArray typedArray = paramContext.obtainStyledAttributes(paramAttributeSet, arrayOfInt, 2130968810, 0);
    if (Build.VERSION.SDK_INT >= 29)
      saveAttributeDataForStyleable(paramContext, arrayOfInt, paramAttributeSet, typedArray, 2130968810, 0); 
    int m = typedArray.getResourceId(0, 0);
    if (m != 0) {
      Resources resources = paramContext.getResources();
      this.p = resources.getIntArray(m);
      float f = (resources.getDisplayMetrics()).density;
      m = this.p.length;
      while (k < m) {
        int[] arrayOfInt1 = this.p;
        arrayOfInt1[k] = (int)(arrayOfInt1[k] * f);
        k++;
      } 
    } 
    this.w = typedArray.getDrawable(1);
    typedArray.recycle();
    y();
    super.setOnHierarchyChangeListener(new e(this));
    WeakHashMap weakHashMap = l.a;
    if (getImportantForAccessibility() == 0)
      setImportantForAccessibility(1); 
  }
  
  public static Rect a() {
    Rect rect2 = (Rect)((j0.e)E).b();
    Rect rect1 = rect2;
    if (rect2 == null)
      rect1 = new Rect(); 
    return rect1;
  }
  
  public final void b(f paramf, Rect paramRect, int paramInt1, int paramInt2) {
    int m = getWidth();
    int k = getHeight();
    m = Math.max(getPaddingLeft() + paramf.leftMargin, Math.min(paramRect.left, m - getPaddingRight() - paramInt1 - paramf.rightMargin));
    k = Math.max(getPaddingTop() + paramf.topMargin, Math.min(paramRect.top, k - getPaddingBottom() - paramInt2 - paramf.bottomMargin));
    paramRect.set(m, k, paramInt1 + m, paramInt2 + k);
  }
  
  public void c(View paramView, boolean paramBoolean, Rect paramRect) {
    if (paramView.isLayoutRequested() || paramView.getVisibility() == 8) {
      paramRect.setEmpty();
      return;
    } 
    if (paramBoolean) {
      f(paramView, paramRect);
      return;
    } 
    paramRect.set(paramView.getLeft(), paramView.getTop(), paramView.getRight(), paramView.getBottom());
  }
  
  public boolean checkLayoutParams(ViewGroup.LayoutParams paramLayoutParams) {
    return (paramLayoutParams instanceof f && super.checkLayoutParams(paramLayoutParams));
  }
  
  public List<View> d(View paramView) {
    y.a a1 = this.i;
    int m = ((r.g)a1.b).j;
    ArrayList<Object> arrayList = null;
    int k = 0;
    while (k < m) {
      ArrayList arrayList2 = (ArrayList)((r.g)a1.b).l(k);
      ArrayList<Object> arrayList1 = arrayList;
      if (arrayList2 != null) {
        arrayList1 = arrayList;
        if (arrayList2.contains(paramView)) {
          arrayList1 = arrayList;
          if (arrayList == null)
            arrayList1 = new ArrayList(); 
          arrayList1.add(((r.g)a1.b).h(k));
        } 
      } 
      k++;
      arrayList = arrayList1;
    } 
    this.k.clear();
    if (arrayList != null)
      this.k.addAll(arrayList); 
    return this.k;
  }
  
  public boolean drawChild(Canvas paramCanvas, View paramView, long paramLong) {
    c c1 = ((f)paramView.getLayoutParams()).a;
    if (c1 != null)
      Objects.requireNonNull(c1); 
    return super.drawChild(paramCanvas, paramView, paramLong);
  }
  
  public void drawableStateChanged() {
    super.drawableStateChanged();
    int[] arrayOfInt = getDrawableState();
    Drawable drawable = this.w;
    byte b = 0;
    int k = b;
    if (drawable != null) {
      k = b;
      if (drawable.isStateful())
        k = false | drawable.setState(arrayOfInt); 
    } 
    if (k != 0)
      invalidate(); 
  }
  
  public List<View> e(View paramView) {
    List<? extends View> list = (List)((r.g)this.i.b).getOrDefault(paramView, null);
    this.k.clear();
    if (list != null)
      this.k.addAll(list); 
    return this.k;
  }
  
  public void f(View paramView, Rect paramRect) {
    ThreadLocal threadLocal = y.b.a;
    paramRect.set(0, 0, paramView.getWidth(), paramView.getHeight());
    ThreadLocal<Matrix> threadLocal1 = y.b.a;
    Matrix matrix = threadLocal1.get();
    if (matrix == null) {
      matrix = new Matrix();
      threadLocal1.set(matrix);
    } else {
      matrix.reset();
    } 
    y.b.a((ViewParent)this, paramView, matrix);
    ThreadLocal<RectF> threadLocal2 = y.b.b;
    RectF rectF2 = threadLocal2.get();
    RectF rectF1 = rectF2;
    if (rectF2 == null) {
      rectF1 = new RectF();
      threadLocal2.set(rectF1);
    } 
    rectF1.set(paramRect);
    matrix.mapRect(rectF1);
    paramRect.set((int)(rectF1.left + 0.5F), (int)(rectF1.top + 0.5F), (int)(rectF1.right + 0.5F), (int)(rectF1.bottom + 0.5F));
  }
  
  public final void g(int paramInt1, Rect paramRect1, Rect paramRect2, f paramf, int paramInt2, int paramInt3) {
    int m = paramf.c;
    int k = m;
    if (m == 0)
      k = 17; 
    int n = Gravity.getAbsoluteGravity(k, paramInt1);
    m = paramf.d;
    k = m;
    if ((m & 0x7) == 0)
      k = m | 0x800003; 
    m = k;
    if ((k & 0x70) == 0)
      m = k | 0x30; 
    paramInt1 = Gravity.getAbsoluteGravity(m, paramInt1);
    int i1 = n & 0x7;
    n &= 0x70;
    m = paramInt1 & 0x7;
    k = paramInt1 & 0x70;
    if (m != 1) {
      if (m != 5) {
        paramInt1 = paramRect1.left;
      } else {
        paramInt1 = paramRect1.right;
      } 
    } else {
      paramInt1 = paramRect1.left + paramRect1.width() / 2;
    } 
    if (k != 16) {
      if (k != 80) {
        k = paramRect1.top;
      } else {
        k = paramRect1.bottom;
      } 
    } else {
      k = paramRect1.top + paramRect1.height() / 2;
    } 
    if (i1 != 1) {
      m = paramInt1;
      if (i1 != 5)
        m = paramInt1 - paramInt2; 
    } else {
      m = paramInt1 - paramInt2 / 2;
    } 
    if (n != 16) {
      paramInt1 = k;
      if (n != 80)
        paramInt1 = k - paramInt3; 
    } else {
      paramInt1 = k - paramInt3 / 2;
    } 
    paramRect2.set(m, paramInt1, paramInt2 + m, paramInt3 + paramInt1);
  }
  
  public ViewGroup.LayoutParams generateDefaultLayoutParams() {
    return (ViewGroup.LayoutParams)new f(-2, -2);
  }
  
  public ViewGroup.LayoutParams generateLayoutParams(AttributeSet paramAttributeSet) {
    return (ViewGroup.LayoutParams)new f(getContext(), paramAttributeSet);
  }
  
  public ViewGroup.LayoutParams generateLayoutParams(ViewGroup.LayoutParams paramLayoutParams) {
    return (ViewGroup.LayoutParams)((paramLayoutParams instanceof f) ? new f((f)paramLayoutParams) : ((paramLayoutParams instanceof ViewGroup.MarginLayoutParams) ? new f((ViewGroup.MarginLayoutParams)paramLayoutParams) : new f(paramLayoutParams)));
  }
  
  public final List<View> getDependencySortedChildren() {
    u();
    return Collections.unmodifiableList(this.h);
  }
  
  public final r getLastWindowInsets() {
    return this.u;
  }
  
  public int getNestedScrollAxes() {
    return this.z.a();
  }
  
  public Drawable getStatusBarBackground() {
    return this.w;
  }
  
  public int getSuggestedMinimumHeight() {
    int k = super.getSuggestedMinimumHeight();
    int m = getPaddingTop();
    return Math.max(k, getPaddingBottom() + m);
  }
  
  public int getSuggestedMinimumWidth() {
    int k = super.getSuggestedMinimumWidth();
    int m = getPaddingLeft();
    return Math.max(k, getPaddingRight() + m);
  }
  
  public void h(View paramView1, View paramView2, int paramInt1, int paramInt2) {
    k0.i i1 = this.z;
    if (paramInt2 == 1) {
      i1.b = paramInt1;
    } else {
      i1.a = paramInt1;
    } 
    this.r = paramView2;
    int k = getChildCount();
    for (paramInt1 = 0; paramInt1 < k; paramInt1++)
      ((f)getChildAt(paramInt1).getLayoutParams()).a(paramInt2); 
  }
  
  public void i(View paramView, int paramInt) {
    k0.i i1 = this.z;
    if (paramInt == 1) {
      i1.b = 0;
    } else {
      i1.a = 0;
    } 
    int m = getChildCount();
    for (int k = 0; k < m; k++) {
      View view = getChildAt(k);
      f f = (f)view.getLayoutParams();
      if (f.a(paramInt)) {
        c<View> c1 = f.a;
        if (c1 != null)
          c1.q(this, view, paramView, paramInt); 
        f.b(paramInt, false);
        f.p = false;
      } 
    } 
    this.r = null;
  }
  
  public void j(View paramView, int paramInt1, int paramInt2, int[] paramArrayOfint, int paramInt3) {
    int i1 = getChildCount();
    boolean bool = false;
    int k = 0;
    int n = 0;
    int m;
    for (m = 0; k < i1; m = i2) {
      int i2;
      int i3;
      View view = getChildAt(k);
      if (view.getVisibility() == 8) {
        i3 = n;
        i2 = m;
      } else {
        f f = (f)view.getLayoutParams();
        if (!f.a(paramInt3)) {
          i3 = n;
          i2 = m;
        } else {
          c<View> c1 = f.a;
          i3 = n;
          i2 = m;
          if (c1 != null) {
            int[] arrayOfInt2 = this.l;
            arrayOfInt2[0] = 0;
            arrayOfInt2[1] = 0;
            c1.k(this, view, paramView, paramInt1, paramInt2, arrayOfInt2, paramInt3);
            int[] arrayOfInt1 = this.l;
            if (paramInt1 > 0) {
              i2 = Math.max(n, arrayOfInt1[0]);
            } else {
              i2 = Math.min(n, arrayOfInt1[0]);
            } 
            n = i2;
            arrayOfInt1 = this.l;
            if (paramInt2 > 0) {
              i2 = Math.max(m, arrayOfInt1[1]);
            } else {
              i2 = Math.min(m, arrayOfInt1[1]);
            } 
            bool = true;
            i3 = n;
          } 
        } 
      } 
      k++;
      n = i3;
    } 
    paramArrayOfint[0] = n;
    paramArrayOfint[1] = m;
    if (bool)
      q(1); 
  }
  
  public final int k(int paramInt) {
    StringBuilder stringBuilder;
    int[] arrayOfInt = this.p;
    if (arrayOfInt == null) {
      stringBuilder = new StringBuilder();
      stringBuilder.append("No keylines defined for ");
      stringBuilder.append(this);
      stringBuilder.append(" - attempted index lookup ");
      stringBuilder.append(paramInt);
      Log.e("CoordinatorLayout", stringBuilder.toString());
      return 0;
    } 
    if (paramInt < 0 || paramInt >= stringBuilder.length) {
      stringBuilder = new StringBuilder();
      stringBuilder.append("Keyline index ");
      stringBuilder.append(paramInt);
      stringBuilder.append(" out of range for ");
      stringBuilder.append(this);
      Log.e("CoordinatorLayout", stringBuilder.toString());
      return 0;
    } 
    return stringBuilder[paramInt];
  }
  
  public f l(View paramView) {
    f f = (f)paramView.getLayoutParams();
    if (!f.b) {
      c c1;
      if (paramView instanceof b) {
        c1 = ((b)paramView).getBehavior();
        if (c1 == null)
          Log.e("CoordinatorLayout", "Attached behavior class is null"); 
        c c2 = f.a;
        if (c2 != c1) {
          if (c2 != null)
            c2.f(); 
          f.a = c1;
          f.b = true;
          if (c1 != null)
            c1.c(f); 
        } 
      } else {
        d d;
        Class<?> clazz = c1.getClass();
        c1 = null;
        while (clazz != null) {
          d d1 = clazz.<d>getAnnotation(d.class);
          d = d1;
          if (d1 == null) {
            clazz = clazz.getSuperclass();
            d = d1;
          } 
        } 
        if (d != null)
          try {
            c c2 = d.value().getDeclaredConstructor(new Class[0]).newInstance(new Object[0]);
            c c3 = f.a;
            if (c3 != c2) {
              if (c3 != null)
                c3.f(); 
              f.a = c2;
              f.b = true;
              if (c2 != null)
                c2.c(f); 
            } 
          } catch (Exception exception) {
            StringBuilder stringBuilder = android.support.v4.media.c.a("Default behavior class ");
            stringBuilder.append(d.value().getName());
            stringBuilder.append(" could not be instantiated. Did you forget a default constructor?");
            Log.e("CoordinatorLayout", stringBuilder.toString(), exception);
          }  
      } 
      f.b = true;
    } 
    return f;
  }
  
  public void m(View paramView, int paramInt1, int paramInt2, int paramInt3, int paramInt4, int paramInt5, int[] paramArrayOfint) {
    int i1 = getChildCount();
    boolean bool = false;
    int k = 0;
    int n = 0;
    int m;
    for (m = 0; k < i1; m = i2) {
      int i2;
      int i3;
      View view = getChildAt(k);
      if (view.getVisibility() == 8) {
        i3 = n;
        i2 = m;
      } else {
        f f = (f)view.getLayoutParams();
        if (!f.a(paramInt5)) {
          i3 = n;
          i2 = m;
        } else {
          c<View> c1 = f.a;
          i3 = n;
          i2 = m;
          if (c1 != null) {
            int[] arrayOfInt2 = this.l;
            arrayOfInt2[0] = 0;
            arrayOfInt2[1] = 0;
            c1.l(this, view, paramView, paramInt1, paramInt2, paramInt3, paramInt4, paramInt5, arrayOfInt2);
            int[] arrayOfInt1 = this.l;
            if (paramInt3 > 0) {
              i2 = Math.max(n, arrayOfInt1[0]);
            } else {
              i2 = Math.min(n, arrayOfInt1[0]);
            } 
            n = i2;
            if (paramInt4 > 0) {
              i2 = Math.max(m, this.l[1]);
            } else {
              i2 = Math.min(m, this.l[1]);
            } 
            bool = true;
            i3 = n;
          } 
        } 
      } 
      k++;
      n = i3;
    } 
    paramArrayOfint[0] = paramArrayOfint[0] + n;
    paramArrayOfint[1] = paramArrayOfint[1] + m;
    if (bool)
      q(1); 
  }
  
  public void n(View paramView, int paramInt1, int paramInt2, int paramInt3, int paramInt4, int paramInt5) {
    m(paramView, paramInt1, paramInt2, paramInt3, paramInt4, 0, this.m);
  }
  
  public boolean o(View paramView1, View paramView2, int paramInt1, int paramInt2) {
    int m = getChildCount();
    int k = 0;
    boolean bool = false;
    while (k < m) {
      View view = getChildAt(k);
      if (view.getVisibility() != 8) {
        f f = (f)view.getLayoutParams();
        c<View> c1 = f.a;
        if (c1 != null) {
          boolean bool1 = c1.p(this, view, paramView1, paramView2, paramInt1, paramInt2);
          bool |= bool1;
          f.b(paramInt2, bool1);
        } else {
          f.b(paramInt2, false);
        } 
      } 
      k++;
    } 
    return bool;
  }
  
  public void onAttachedToWindow() {
    super.onAttachedToWindow();
    v(false);
    if (this.t) {
      if (this.s == null)
        this.s = new g(this); 
      getViewTreeObserver().addOnPreDrawListener(this.s);
    } 
    if (this.u == null) {
      WeakHashMap weakHashMap = l.a;
      if (getFitsSystemWindows())
        requestApplyInsets(); 
    } 
    this.o = true;
  }
  
  public void onDetachedFromWindow() {
    super.onDetachedFromWindow();
    v(false);
    if (this.t && this.s != null)
      getViewTreeObserver().removeOnPreDrawListener(this.s); 
    View view = this.r;
    if (view != null)
      onStopNestedScroll(view); 
    this.o = false;
  }
  
  public void onDraw(Canvas paramCanvas) {
    super.onDraw(paramCanvas);
    if (this.v && this.w != null) {
      boolean bool;
      r r1 = this.u;
      if (r1 != null) {
        bool = r1.d();
      } else {
        bool = false;
      } 
      if (bool) {
        this.w.setBounds(0, 0, getWidth(), bool);
        this.w.draw(paramCanvas);
      } 
    } 
  }
  
  public boolean onInterceptTouchEvent(MotionEvent paramMotionEvent) {
    int k = paramMotionEvent.getActionMasked();
    if (k == 0)
      v(true); 
    boolean bool = t(paramMotionEvent, 0);
    if (k == 1 || k == 3)
      v(true); 
    return bool;
  }
  
  public void onLayout(boolean paramBoolean, int paramInt1, int paramInt2, int paramInt3, int paramInt4) {
    WeakHashMap weakHashMap = l.a;
    paramInt2 = getLayoutDirection();
    paramInt3 = this.h.size();
    for (paramInt1 = 0; paramInt1 < paramInt3; paramInt1++) {
      View view = this.h.get(paramInt1);
      if (view.getVisibility() != 8) {
        c<View> c1 = ((f)view.getLayoutParams()).a;
        if (c1 == null || !c1.h(this, view, paramInt2))
          r(view, paramInt2); 
      } 
    } 
  }
  
  public void onMeasure(int paramInt1, int paramInt2) {
    // Byte code:
    //   0: aload_0
    //   1: invokevirtual u : ()V
    //   4: aload_0
    //   5: invokevirtual getChildCount : ()I
    //   8: istore #5
    //   10: iconst_0
    //   11: istore_3
    //   12: iload_3
    //   13: iload #5
    //   15: if_icmpge -> 123
    //   18: aload_0
    //   19: iload_3
    //   20: invokevirtual getChildAt : (I)Landroid/view/View;
    //   23: astore #26
    //   25: aload_0
    //   26: getfield i : Ly/a;
    //   29: astore #27
    //   31: aload #27
    //   33: getfield b : Ljava/lang/Object;
    //   36: checkcast r/g
    //   39: getfield j : I
    //   42: istore #6
    //   44: iconst_0
    //   45: istore #4
    //   47: iload #4
    //   49: iload #6
    //   51: if_icmpge -> 102
    //   54: aload #27
    //   56: getfield b : Ljava/lang/Object;
    //   59: checkcast r/g
    //   62: iload #4
    //   64: invokevirtual l : (I)Ljava/lang/Object;
    //   67: checkcast java/util/ArrayList
    //   70: astore #28
    //   72: aload #28
    //   74: ifnull -> 93
    //   77: aload #28
    //   79: aload #26
    //   81: invokevirtual contains : (Ljava/lang/Object;)Z
    //   84: ifeq -> 93
    //   87: iconst_1
    //   88: istore #4
    //   90: goto -> 105
    //   93: iload #4
    //   95: iconst_1
    //   96: iadd
    //   97: istore #4
    //   99: goto -> 47
    //   102: iconst_0
    //   103: istore #4
    //   105: iload #4
    //   107: ifeq -> 116
    //   110: iconst_1
    //   111: istore #25
    //   113: goto -> 126
    //   116: iload_3
    //   117: iconst_1
    //   118: iadd
    //   119: istore_3
    //   120: goto -> 12
    //   123: iconst_0
    //   124: istore #25
    //   126: iload #25
    //   128: aload_0
    //   129: getfield t : Z
    //   132: if_icmpeq -> 215
    //   135: iload #25
    //   137: ifeq -> 185
    //   140: aload_0
    //   141: getfield o : Z
    //   144: ifeq -> 177
    //   147: aload_0
    //   148: getfield s : Landroidx/coordinatorlayout/widget/CoordinatorLayout$g;
    //   151: ifnonnull -> 166
    //   154: aload_0
    //   155: new androidx/coordinatorlayout/widget/CoordinatorLayout$g
    //   158: dup
    //   159: aload_0
    //   160: invokespecial <init> : (Landroidx/coordinatorlayout/widget/CoordinatorLayout;)V
    //   163: putfield s : Landroidx/coordinatorlayout/widget/CoordinatorLayout$g;
    //   166: aload_0
    //   167: invokevirtual getViewTreeObserver : ()Landroid/view/ViewTreeObserver;
    //   170: aload_0
    //   171: getfield s : Landroidx/coordinatorlayout/widget/CoordinatorLayout$g;
    //   174: invokevirtual addOnPreDrawListener : (Landroid/view/ViewTreeObserver$OnPreDrawListener;)V
    //   177: aload_0
    //   178: iconst_1
    //   179: putfield t : Z
    //   182: goto -> 215
    //   185: aload_0
    //   186: getfield o : Z
    //   189: ifeq -> 210
    //   192: aload_0
    //   193: getfield s : Landroidx/coordinatorlayout/widget/CoordinatorLayout$g;
    //   196: ifnull -> 210
    //   199: aload_0
    //   200: invokevirtual getViewTreeObserver : ()Landroid/view/ViewTreeObserver;
    //   203: aload_0
    //   204: getfield s : Landroidx/coordinatorlayout/widget/CoordinatorLayout$g;
    //   207: invokevirtual removeOnPreDrawListener : (Landroid/view/ViewTreeObserver$OnPreDrawListener;)V
    //   210: aload_0
    //   211: iconst_0
    //   212: putfield t : Z
    //   215: aload_0
    //   216: invokevirtual getPaddingLeft : ()I
    //   219: istore #13
    //   221: aload_0
    //   222: invokevirtual getPaddingTop : ()I
    //   225: istore #15
    //   227: aload_0
    //   228: invokevirtual getPaddingRight : ()I
    //   231: istore #16
    //   233: aload_0
    //   234: invokevirtual getPaddingBottom : ()I
    //   237: istore #17
    //   239: getstatic k0/l.a : Ljava/util/WeakHashMap;
    //   242: astore #26
    //   244: aload_0
    //   245: invokevirtual getLayoutDirection : ()I
    //   248: istore #18
    //   250: iload #18
    //   252: iconst_1
    //   253: if_icmpne -> 262
    //   256: iconst_1
    //   257: istore #5
    //   259: goto -> 265
    //   262: iconst_0
    //   263: istore #5
    //   265: iload_1
    //   266: invokestatic getMode : (I)I
    //   269: istore #19
    //   271: iload_1
    //   272: invokestatic getSize : (I)I
    //   275: istore #20
    //   277: iload_2
    //   278: invokestatic getMode : (I)I
    //   281: istore #21
    //   283: iload_2
    //   284: invokestatic getSize : (I)I
    //   287: istore #22
    //   289: aload_0
    //   290: invokevirtual getSuggestedMinimumWidth : ()I
    //   293: istore #11
    //   295: aload_0
    //   296: invokevirtual getSuggestedMinimumHeight : ()I
    //   299: istore #10
    //   301: aload_0
    //   302: getfield u : Lk0/r;
    //   305: ifnull -> 321
    //   308: aload_0
    //   309: invokevirtual getFitsSystemWindows : ()Z
    //   312: ifeq -> 321
    //   315: iconst_1
    //   316: istore #6
    //   318: goto -> 324
    //   321: iconst_0
    //   322: istore #6
    //   324: aload_0
    //   325: getfield h : Ljava/util/List;
    //   328: invokeinterface size : ()I
    //   333: istore #7
    //   335: iconst_0
    //   336: istore_3
    //   337: iconst_0
    //   338: istore #8
    //   340: iload #13
    //   342: istore #4
    //   344: iload #4
    //   346: istore #9
    //   348: iload #8
    //   350: iload #7
    //   352: if_icmpge -> 748
    //   355: aload_0
    //   356: getfield h : Ljava/util/List;
    //   359: iload #8
    //   361: invokeinterface get : (I)Ljava/lang/Object;
    //   366: checkcast android/view/View
    //   369: astore #27
    //   371: aload #27
    //   373: invokevirtual getVisibility : ()I
    //   376: bipush #8
    //   378: if_icmpne -> 384
    //   381: goto -> 735
    //   384: aload #27
    //   386: invokevirtual getLayoutParams : ()Landroid/view/ViewGroup$LayoutParams;
    //   389: checkcast androidx/coordinatorlayout/widget/CoordinatorLayout$f
    //   392: astore #26
    //   394: aload #26
    //   396: getfield e : I
    //   399: istore #4
    //   401: iload #4
    //   403: iflt -> 530
    //   406: iload #19
    //   408: ifeq -> 530
    //   411: aload_0
    //   412: iload #4
    //   414: invokevirtual k : (I)I
    //   417: istore #14
    //   419: aload #26
    //   421: getfield c : I
    //   424: istore #12
    //   426: iload #12
    //   428: istore #4
    //   430: iload #12
    //   432: ifne -> 440
    //   435: ldc_w 8388661
    //   438: istore #4
    //   440: iload #4
    //   442: iload #18
    //   444: invokestatic getAbsoluteGravity : (II)I
    //   447: bipush #7
    //   449: iand
    //   450: istore #4
    //   452: iload #4
    //   454: iconst_3
    //   455: if_icmpne -> 463
    //   458: iload #5
    //   460: ifeq -> 474
    //   463: iload #4
    //   465: iconst_5
    //   466: if_icmpne -> 491
    //   469: iload #5
    //   471: ifeq -> 491
    //   474: iconst_0
    //   475: iload #20
    //   477: iload #16
    //   479: isub
    //   480: iload #14
    //   482: isub
    //   483: invokestatic max : (II)I
    //   486: istore #4
    //   488: goto -> 533
    //   491: iload #4
    //   493: iconst_5
    //   494: if_icmpne -> 502
    //   497: iload #5
    //   499: ifeq -> 513
    //   502: iload #4
    //   504: iconst_3
    //   505: if_icmpne -> 527
    //   508: iload #5
    //   510: ifeq -> 527
    //   513: iconst_0
    //   514: iload #14
    //   516: iload #9
    //   518: isub
    //   519: invokestatic max : (II)I
    //   522: istore #4
    //   524: goto -> 533
    //   527: goto -> 530
    //   530: iconst_0
    //   531: istore #4
    //   533: iload_3
    //   534: istore #14
    //   536: iload #6
    //   538: ifeq -> 615
    //   541: aload #27
    //   543: invokevirtual getFitsSystemWindows : ()Z
    //   546: ifne -> 615
    //   549: aload_0
    //   550: getfield u : Lk0/r;
    //   553: invokevirtual b : ()I
    //   556: istore_3
    //   557: aload_0
    //   558: getfield u : Lk0/r;
    //   561: invokevirtual c : ()I
    //   564: istore #24
    //   566: aload_0
    //   567: getfield u : Lk0/r;
    //   570: invokevirtual d : ()I
    //   573: istore #12
    //   575: aload_0
    //   576: getfield u : Lk0/r;
    //   579: invokevirtual a : ()I
    //   582: istore #23
    //   584: iload #20
    //   586: iload #24
    //   588: iload_3
    //   589: iadd
    //   590: isub
    //   591: iload #19
    //   593: invokestatic makeMeasureSpec : (II)I
    //   596: istore_3
    //   597: iload #22
    //   599: iload #23
    //   601: iload #12
    //   603: iadd
    //   604: isub
    //   605: iload #21
    //   607: invokestatic makeMeasureSpec : (II)I
    //   610: istore #12
    //   612: goto -> 620
    //   615: iload_1
    //   616: istore_3
    //   617: iload_2
    //   618: istore #12
    //   620: aload #26
    //   622: getfield a : Landroidx/coordinatorlayout/widget/CoordinatorLayout$c;
    //   625: astore #28
    //   627: aload #28
    //   629: ifnull -> 652
    //   632: aload #28
    //   634: aload_0
    //   635: aload #27
    //   637: iload_3
    //   638: iload #4
    //   640: iload #12
    //   642: iconst_0
    //   643: invokevirtual i : (Landroidx/coordinatorlayout/widget/CoordinatorLayout;Landroid/view/View;IIII)Z
    //   646: ifne -> 664
    //   649: goto -> 652
    //   652: aload_0
    //   653: aload #27
    //   655: iload_3
    //   656: iload #4
    //   658: iload #12
    //   660: iconst_0
    //   661: invokevirtual measureChildWithMargins : (Landroid/view/View;IIII)V
    //   664: iload #11
    //   666: aload #27
    //   668: invokevirtual getMeasuredWidth : ()I
    //   671: iload #13
    //   673: iload #16
    //   675: iadd
    //   676: iadd
    //   677: aload #26
    //   679: getfield leftMargin : I
    //   682: iadd
    //   683: aload #26
    //   685: getfield rightMargin : I
    //   688: iadd
    //   689: invokestatic max : (II)I
    //   692: istore #11
    //   694: iload #10
    //   696: aload #27
    //   698: invokevirtual getMeasuredHeight : ()I
    //   701: iload #15
    //   703: iload #17
    //   705: iadd
    //   706: iadd
    //   707: aload #26
    //   709: getfield topMargin : I
    //   712: iadd
    //   713: aload #26
    //   715: getfield bottomMargin : I
    //   718: iadd
    //   719: invokestatic max : (II)I
    //   722: istore #10
    //   724: iload #14
    //   726: aload #27
    //   728: invokevirtual getMeasuredState : ()I
    //   731: invokestatic combineMeasuredStates : (II)I
    //   734: istore_3
    //   735: iload #8
    //   737: iconst_1
    //   738: iadd
    //   739: istore #8
    //   741: iload #9
    //   743: istore #4
    //   745: goto -> 344
    //   748: aload_0
    //   749: iload #11
    //   751: iload_1
    //   752: ldc_w -16777216
    //   755: iload_3
    //   756: iand
    //   757: invokestatic resolveSizeAndState : (III)I
    //   760: iload #10
    //   762: iload_2
    //   763: iload_3
    //   764: bipush #16
    //   766: ishl
    //   767: invokestatic resolveSizeAndState : (III)I
    //   770: invokevirtual setMeasuredDimension : (II)V
    //   773: return
  }
  
  public boolean onNestedFling(View paramView, float paramFloat1, float paramFloat2, boolean paramBoolean) {
    int m = getChildCount();
    int k;
    for (k = 0; k < m; k++) {
      paramView = getChildAt(k);
      if (paramView.getVisibility() != 8) {
        f f = (f)paramView.getLayoutParams();
        if (f.a(0))
          c c1 = f.a; 
      } 
    } 
    return false;
  }
  
  public boolean onNestedPreFling(View paramView, float paramFloat1, float paramFloat2) {
    int m = getChildCount();
    int k = 0;
    boolean bool;
    for (bool = false; k < m; bool = bool1) {
      boolean bool1;
      View view = getChildAt(k);
      if (view.getVisibility() == 8) {
        bool1 = bool;
      } else {
        f f = (f)view.getLayoutParams();
        if (!f.a(0)) {
          bool1 = bool;
        } else {
          c<View> c1 = f.a;
          bool1 = bool;
          if (c1 != null)
            bool1 = bool | c1.j(this, view, paramView, paramFloat1, paramFloat2); 
        } 
      } 
      k++;
    } 
    return bool;
  }
  
  public void onNestedPreScroll(View paramView, int paramInt1, int paramInt2, int[] paramArrayOfint) {
    j(paramView, paramInt1, paramInt2, paramArrayOfint, 0);
  }
  
  public void onNestedScroll(View paramView, int paramInt1, int paramInt2, int paramInt3, int paramInt4) {
    m(paramView, paramInt1, paramInt2, paramInt3, paramInt4, 0, this.m);
  }
  
  public void onNestedScrollAccepted(View paramView1, View paramView2, int paramInt) {
    h(paramView1, paramView2, paramInt, 0);
  }
  
  public void onRestoreInstanceState(Parcelable paramParcelable) {
    if (!(paramParcelable instanceof h)) {
      super.onRestoreInstanceState(paramParcelable);
      return;
    } 
    h h1 = (h)paramParcelable;
    super.onRestoreInstanceState(h1.h);
    SparseArray<Parcelable> sparseArray = h1.j;
    int k = 0;
    int m = getChildCount();
    while (k < m) {
      View view = getChildAt(k);
      int n = view.getId();
      c<View> c1 = (l(view)).a;
      if (n != -1 && c1 != null) {
        Parcelable parcelable = (Parcelable)sparseArray.get(n);
        if (parcelable != null)
          c1.n(this, view, parcelable); 
      } 
      k++;
    } 
  }
  
  public Parcelable onSaveInstanceState() {
    h h1 = new h(super.onSaveInstanceState());
    SparseArray<Parcelable> sparseArray = new SparseArray();
    int m = getChildCount();
    for (int k = 0; k < m; k++) {
      View view = getChildAt(k);
      int n = view.getId();
      c<View> c1 = ((f)view.getLayoutParams()).a;
      if (n != -1 && c1 != null) {
        Parcelable parcelable = c1.o(this, view);
        if (parcelable != null)
          sparseArray.append(n, parcelable); 
      } 
    } 
    h1.j = sparseArray;
    return (Parcelable)h1;
  }
  
  public boolean onStartNestedScroll(View paramView1, View paramView2, int paramInt) {
    return o(paramView1, paramView2, paramInt, 0);
  }
  
  public void onStopNestedScroll(View paramView) {
    i(paramView, 0);
  }
  
  public boolean onTouchEvent(MotionEvent paramMotionEvent) {
    // Byte code:
    //   0: aload_1
    //   1: invokevirtual getActionMasked : ()I
    //   4: istore_2
    //   5: aload_0
    //   6: getfield q : Landroid/view/View;
    //   9: ifnonnull -> 29
    //   12: aload_0
    //   13: aload_1
    //   14: iconst_1
    //   15: invokevirtual t : (Landroid/view/MotionEvent;I)Z
    //   18: istore_3
    //   19: iload_3
    //   20: istore #4
    //   22: iload_3
    //   23: ifeq -> 76
    //   26: goto -> 31
    //   29: iconst_0
    //   30: istore_3
    //   31: aload_0
    //   32: getfield q : Landroid/view/View;
    //   35: invokevirtual getLayoutParams : ()Landroid/view/ViewGroup$LayoutParams;
    //   38: checkcast androidx/coordinatorlayout/widget/CoordinatorLayout$f
    //   41: getfield a : Landroidx/coordinatorlayout/widget/CoordinatorLayout$c;
    //   44: astore #8
    //   46: iload_3
    //   47: istore #4
    //   49: aload #8
    //   51: ifnull -> 76
    //   54: aload #8
    //   56: aload_0
    //   57: aload_0
    //   58: getfield q : Landroid/view/View;
    //   61: aload_1
    //   62: invokevirtual r : (Landroidx/coordinatorlayout/widget/CoordinatorLayout;Landroid/view/View;Landroid/view/MotionEvent;)Z
    //   65: istore #5
    //   67: iload_3
    //   68: istore #4
    //   70: iload #5
    //   72: istore_3
    //   73: goto -> 78
    //   76: iconst_0
    //   77: istore_3
    //   78: aload_0
    //   79: getfield q : Landroid/view/View;
    //   82: astore #9
    //   84: aconst_null
    //   85: astore #8
    //   87: aload #9
    //   89: ifnonnull -> 107
    //   92: iload_3
    //   93: aload_0
    //   94: aload_1
    //   95: invokespecial onTouchEvent : (Landroid/view/MotionEvent;)Z
    //   98: ior
    //   99: istore #5
    //   101: aload #8
    //   103: astore_1
    //   104: goto -> 144
    //   107: iload_3
    //   108: istore #5
    //   110: aload #8
    //   112: astore_1
    //   113: iload #4
    //   115: ifeq -> 144
    //   118: invokestatic uptimeMillis : ()J
    //   121: lstore #6
    //   123: lload #6
    //   125: lload #6
    //   127: iconst_3
    //   128: fconst_0
    //   129: fconst_0
    //   130: iconst_0
    //   131: invokestatic obtain : (JJIFFI)Landroid/view/MotionEvent;
    //   134: astore_1
    //   135: aload_0
    //   136: aload_1
    //   137: invokespecial onTouchEvent : (Landroid/view/MotionEvent;)Z
    //   140: pop
    //   141: iload_3
    //   142: istore #5
    //   144: aload_1
    //   145: ifnull -> 152
    //   148: aload_1
    //   149: invokevirtual recycle : ()V
    //   152: iload_2
    //   153: iconst_1
    //   154: if_icmpeq -> 162
    //   157: iload_2
    //   158: iconst_3
    //   159: if_icmpne -> 167
    //   162: aload_0
    //   163: iconst_0
    //   164: invokevirtual v : (Z)V
    //   167: iload #5
    //   169: ireturn
  }
  
  public boolean p(View paramView, int paramInt1, int paramInt2) {
    Rect rect = a();
    f(paramView, rect);
    try {
      return rect.contains(paramInt1, paramInt2);
    } finally {
      rect.setEmpty();
      ((j0.e)E).a(rect);
    } 
  }
  
  public final void q(int paramInt) {
    // Byte code:
    //   0: getstatic k0/l.a : Ljava/util/WeakHashMap;
    //   3: astore #11
    //   5: aload_0
    //   6: invokevirtual getLayoutDirection : ()I
    //   9: istore #7
    //   11: aload_0
    //   12: getfield h : Ljava/util/List;
    //   15: invokeinterface size : ()I
    //   20: istore_2
    //   21: invokestatic a : ()Landroid/graphics/Rect;
    //   24: astore #13
    //   26: invokestatic a : ()Landroid/graphics/Rect;
    //   29: astore #14
    //   31: invokestatic a : ()Landroid/graphics/Rect;
    //   34: astore #11
    //   36: iconst_0
    //   37: istore_3
    //   38: iload_3
    //   39: iload_2
    //   40: if_icmpge -> 1317
    //   43: aload_0
    //   44: getfield h : Ljava/util/List;
    //   47: iload_3
    //   48: invokeinterface get : (I)Ljava/lang/Object;
    //   53: checkcast android/view/View
    //   56: astore #15
    //   58: aload #15
    //   60: invokevirtual getLayoutParams : ()Landroid/view/ViewGroup$LayoutParams;
    //   63: checkcast androidx/coordinatorlayout/widget/CoordinatorLayout$f
    //   66: astore #12
    //   68: iload_1
    //   69: ifne -> 88
    //   72: aload #15
    //   74: invokevirtual getVisibility : ()I
    //   77: bipush #8
    //   79: if_icmpne -> 88
    //   82: iload_3
    //   83: istore #6
    //   85: goto -> 1309
    //   88: iconst_0
    //   89: istore #4
    //   91: iload #4
    //   93: iload_3
    //   94: if_icmpge -> 396
    //   97: aload_0
    //   98: getfield h : Ljava/util/List;
    //   101: iload #4
    //   103: invokeinterface get : (I)Ljava/lang/Object;
    //   108: checkcast android/view/View
    //   111: astore #16
    //   113: aload #12
    //   115: getfield l : Landroid/view/View;
    //   118: aload #16
    //   120: if_acmpne -> 387
    //   123: aload #15
    //   125: invokevirtual getLayoutParams : ()Landroid/view/ViewGroup$LayoutParams;
    //   128: checkcast androidx/coordinatorlayout/widget/CoordinatorLayout$f
    //   131: astore #19
    //   133: aload #19
    //   135: getfield k : Landroid/view/View;
    //   138: ifnull -> 387
    //   141: invokestatic a : ()Landroid/graphics/Rect;
    //   144: astore #16
    //   146: invokestatic a : ()Landroid/graphics/Rect;
    //   149: astore #17
    //   151: invokestatic a : ()Landroid/graphics/Rect;
    //   154: astore #18
    //   156: aload_0
    //   157: aload #19
    //   159: getfield k : Landroid/view/View;
    //   162: aload #16
    //   164: invokevirtual f : (Landroid/view/View;Landroid/graphics/Rect;)V
    //   167: aload_0
    //   168: aload #15
    //   170: iconst_0
    //   171: aload #17
    //   173: invokevirtual c : (Landroid/view/View;ZLandroid/graphics/Rect;)V
    //   176: aload #15
    //   178: invokevirtual getMeasuredWidth : ()I
    //   181: istore #6
    //   183: aload #15
    //   185: invokevirtual getMeasuredHeight : ()I
    //   188: istore #8
    //   190: aload_0
    //   191: iload #7
    //   193: aload #16
    //   195: aload #18
    //   197: aload #19
    //   199: iload #6
    //   201: iload #8
    //   203: invokevirtual g : (ILandroid/graphics/Rect;Landroid/graphics/Rect;Landroidx/coordinatorlayout/widget/CoordinatorLayout$f;II)V
    //   206: aload #18
    //   208: getfield left : I
    //   211: aload #17
    //   213: getfield left : I
    //   216: if_icmpne -> 241
    //   219: aload #18
    //   221: getfield top : I
    //   224: aload #17
    //   226: getfield top : I
    //   229: if_icmpeq -> 235
    //   232: goto -> 241
    //   235: iconst_0
    //   236: istore #5
    //   238: goto -> 244
    //   241: iconst_1
    //   242: istore #5
    //   244: aload_0
    //   245: aload #19
    //   247: aload #18
    //   249: iload #6
    //   251: iload #8
    //   253: invokevirtual b : (Landroidx/coordinatorlayout/widget/CoordinatorLayout$f;Landroid/graphics/Rect;II)V
    //   256: aload #18
    //   258: getfield left : I
    //   261: aload #17
    //   263: getfield left : I
    //   266: isub
    //   267: istore #6
    //   269: aload #18
    //   271: getfield top : I
    //   274: aload #17
    //   276: getfield top : I
    //   279: isub
    //   280: istore #8
    //   282: iload #6
    //   284: ifeq -> 294
    //   287: aload #15
    //   289: iload #6
    //   291: invokestatic m : (Landroid/view/View;I)V
    //   294: iload #8
    //   296: ifeq -> 306
    //   299: aload #15
    //   301: iload #8
    //   303: invokestatic n : (Landroid/view/View;I)V
    //   306: iload #5
    //   308: ifeq -> 337
    //   311: aload #19
    //   313: getfield a : Landroidx/coordinatorlayout/widget/CoordinatorLayout$c;
    //   316: astore #20
    //   318: aload #20
    //   320: ifnull -> 337
    //   323: aload #20
    //   325: aload_0
    //   326: aload #15
    //   328: aload #19
    //   330: getfield k : Landroid/view/View;
    //   333: invokevirtual d : (Landroidx/coordinatorlayout/widget/CoordinatorLayout;Landroid/view/View;Landroid/view/View;)Z
    //   336: pop
    //   337: aload #16
    //   339: invokevirtual setEmpty : ()V
    //   342: getstatic androidx/coordinatorlayout/widget/CoordinatorLayout.E : Lj0/c;
    //   345: checkcast j0/e
    //   348: astore #19
    //   350: aload #19
    //   352: aload #16
    //   354: invokevirtual a : (Ljava/lang/Object;)Z
    //   357: pop
    //   358: aload #17
    //   360: invokevirtual setEmpty : ()V
    //   363: aload #19
    //   365: aload #17
    //   367: invokevirtual a : (Ljava/lang/Object;)Z
    //   370: pop
    //   371: aload #18
    //   373: invokevirtual setEmpty : ()V
    //   376: aload #19
    //   378: aload #18
    //   380: invokevirtual a : (Ljava/lang/Object;)Z
    //   383: pop
    //   384: goto -> 387
    //   387: iload #4
    //   389: iconst_1
    //   390: iadd
    //   391: istore #4
    //   393: goto -> 91
    //   396: iload_3
    //   397: istore #4
    //   399: aload_0
    //   400: aload #15
    //   402: iconst_1
    //   403: aload #14
    //   405: invokevirtual c : (Landroid/view/View;ZLandroid/graphics/Rect;)V
    //   408: aload #12
    //   410: getfield g : I
    //   413: ifeq -> 564
    //   416: aload #14
    //   418: invokevirtual isEmpty : ()Z
    //   421: ifne -> 564
    //   424: aload #12
    //   426: getfield g : I
    //   429: iload #7
    //   431: invokestatic getAbsoluteGravity : (II)I
    //   434: istore_3
    //   435: iload_3
    //   436: bipush #112
    //   438: iand
    //   439: istore #5
    //   441: iload #5
    //   443: bipush #48
    //   445: if_icmpeq -> 484
    //   448: iload #5
    //   450: bipush #80
    //   452: if_icmpeq -> 458
    //   455: goto -> 502
    //   458: aload #13
    //   460: aload #13
    //   462: getfield bottom : I
    //   465: aload_0
    //   466: invokevirtual getHeight : ()I
    //   469: aload #14
    //   471: getfield top : I
    //   474: isub
    //   475: invokestatic max : (II)I
    //   478: putfield bottom : I
    //   481: goto -> 502
    //   484: aload #13
    //   486: aload #13
    //   488: getfield top : I
    //   491: aload #14
    //   493: getfield bottom : I
    //   496: invokestatic max : (II)I
    //   499: putfield top : I
    //   502: iload_3
    //   503: bipush #7
    //   505: iand
    //   506: istore_3
    //   507: iload_3
    //   508: iconst_3
    //   509: if_icmpeq -> 546
    //   512: iload_3
    //   513: iconst_5
    //   514: if_icmpeq -> 520
    //   517: goto -> 564
    //   520: aload #13
    //   522: aload #13
    //   524: getfield right : I
    //   527: aload_0
    //   528: invokevirtual getWidth : ()I
    //   531: aload #14
    //   533: getfield left : I
    //   536: isub
    //   537: invokestatic max : (II)I
    //   540: putfield right : I
    //   543: goto -> 564
    //   546: aload #13
    //   548: aload #13
    //   550: getfield left : I
    //   553: aload #14
    //   555: getfield right : I
    //   558: invokestatic max : (II)I
    //   561: putfield left : I
    //   564: aload #12
    //   566: getfield h : I
    //   569: ifeq -> 1086
    //   572: aload #15
    //   574: invokevirtual getVisibility : ()I
    //   577: ifne -> 1086
    //   580: getstatic k0/l.a : Ljava/util/WeakHashMap;
    //   583: astore #12
    //   585: aload #15
    //   587: invokevirtual isLaidOut : ()Z
    //   590: ifne -> 596
    //   593: goto -> 1086
    //   596: aload #15
    //   598: invokevirtual getWidth : ()I
    //   601: ifle -> 1086
    //   604: aload #15
    //   606: invokevirtual getHeight : ()I
    //   609: ifgt -> 615
    //   612: goto -> 1086
    //   615: aload #15
    //   617: invokevirtual getLayoutParams : ()Landroid/view/ViewGroup$LayoutParams;
    //   620: checkcast androidx/coordinatorlayout/widget/CoordinatorLayout$f
    //   623: astore #17
    //   625: aload #17
    //   627: getfield a : Landroidx/coordinatorlayout/widget/CoordinatorLayout$c;
    //   630: astore #18
    //   632: invokestatic a : ()Landroid/graphics/Rect;
    //   635: astore #12
    //   637: invokestatic a : ()Landroid/graphics/Rect;
    //   640: astore #16
    //   642: aload #16
    //   644: aload #15
    //   646: invokevirtual getLeft : ()I
    //   649: aload #15
    //   651: invokevirtual getTop : ()I
    //   654: aload #15
    //   656: invokevirtual getRight : ()I
    //   659: aload #15
    //   661: invokevirtual getBottom : ()I
    //   664: invokevirtual set : (IIII)V
    //   667: aload #18
    //   669: ifnull -> 750
    //   672: aload #18
    //   674: aload_0
    //   675: aload #15
    //   677: aload #12
    //   679: invokevirtual a : (Landroidx/coordinatorlayout/widget/CoordinatorLayout;Landroid/view/View;Landroid/graphics/Rect;)Z
    //   682: ifeq -> 750
    //   685: aload #16
    //   687: aload #12
    //   689: invokevirtual contains : (Landroid/graphics/Rect;)Z
    //   692: ifeq -> 698
    //   695: goto -> 757
    //   698: ldc_w 'Rect should be within the child's bounds. Rect:'
    //   701: invokestatic a : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   704: astore #11
    //   706: aload #11
    //   708: aload #12
    //   710: invokevirtual toShortString : ()Ljava/lang/String;
    //   713: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   716: pop
    //   717: aload #11
    //   719: ldc_w ' | Bounds:'
    //   722: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   725: pop
    //   726: aload #11
    //   728: aload #16
    //   730: invokevirtual toShortString : ()Ljava/lang/String;
    //   733: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   736: pop
    //   737: new java/lang/IllegalArgumentException
    //   740: dup
    //   741: aload #11
    //   743: invokevirtual toString : ()Ljava/lang/String;
    //   746: invokespecial <init> : (Ljava/lang/String;)V
    //   749: athrow
    //   750: aload #12
    //   752: aload #16
    //   754: invokevirtual set : (Landroid/graphics/Rect;)V
    //   757: aload #16
    //   759: invokevirtual setEmpty : ()V
    //   762: getstatic androidx/coordinatorlayout/widget/CoordinatorLayout.E : Lj0/c;
    //   765: checkcast j0/e
    //   768: astore #18
    //   770: aload #18
    //   772: aload #16
    //   774: invokevirtual a : (Ljava/lang/Object;)Z
    //   777: pop
    //   778: aload #12
    //   780: invokevirtual isEmpty : ()Z
    //   783: ifeq -> 789
    //   786: goto -> 1073
    //   789: aload #17
    //   791: getfield h : I
    //   794: iload #7
    //   796: invokestatic getAbsoluteGravity : (II)I
    //   799: istore #6
    //   801: iload #6
    //   803: bipush #48
    //   805: iand
    //   806: bipush #48
    //   808: if_icmpne -> 857
    //   811: aload #12
    //   813: getfield top : I
    //   816: aload #17
    //   818: getfield topMargin : I
    //   821: isub
    //   822: aload #17
    //   824: getfield j : I
    //   827: isub
    //   828: istore_3
    //   829: aload #13
    //   831: getfield top : I
    //   834: istore #5
    //   836: iload_3
    //   837: iload #5
    //   839: if_icmpge -> 857
    //   842: aload_0
    //   843: aload #15
    //   845: iload #5
    //   847: iload_3
    //   848: isub
    //   849: invokevirtual x : (Landroid/view/View;I)V
    //   852: iconst_1
    //   853: istore_3
    //   854: goto -> 859
    //   857: iconst_0
    //   858: istore_3
    //   859: iload_3
    //   860: istore #5
    //   862: iload #6
    //   864: bipush #80
    //   866: iand
    //   867: bipush #80
    //   869: if_icmpne -> 927
    //   872: aload_0
    //   873: invokevirtual getHeight : ()I
    //   876: aload #12
    //   878: getfield bottom : I
    //   881: isub
    //   882: aload #17
    //   884: getfield bottomMargin : I
    //   887: isub
    //   888: aload #17
    //   890: getfield j : I
    //   893: iadd
    //   894: istore #8
    //   896: aload #13
    //   898: getfield bottom : I
    //   901: istore #9
    //   903: iload_3
    //   904: istore #5
    //   906: iload #8
    //   908: iload #9
    //   910: if_icmpge -> 927
    //   913: aload_0
    //   914: aload #15
    //   916: iload #8
    //   918: iload #9
    //   920: isub
    //   921: invokevirtual x : (Landroid/view/View;I)V
    //   924: iconst_1
    //   925: istore #5
    //   927: iload #5
    //   929: ifne -> 939
    //   932: aload_0
    //   933: aload #15
    //   935: iconst_0
    //   936: invokevirtual x : (Landroid/view/View;I)V
    //   939: iload #6
    //   941: iconst_3
    //   942: iand
    //   943: iconst_3
    //   944: if_icmpne -> 993
    //   947: aload #12
    //   949: getfield left : I
    //   952: aload #17
    //   954: getfield leftMargin : I
    //   957: isub
    //   958: aload #17
    //   960: getfield i : I
    //   963: isub
    //   964: istore_3
    //   965: aload #13
    //   967: getfield left : I
    //   970: istore #5
    //   972: iload_3
    //   973: iload #5
    //   975: if_icmpge -> 993
    //   978: aload_0
    //   979: aload #15
    //   981: iload #5
    //   983: iload_3
    //   984: isub
    //   985: invokevirtual w : (Landroid/view/View;I)V
    //   988: iconst_1
    //   989: istore_3
    //   990: goto -> 995
    //   993: iconst_0
    //   994: istore_3
    //   995: iload_3
    //   996: istore #5
    //   998: iload #6
    //   1000: iconst_5
    //   1001: iand
    //   1002: iconst_5
    //   1003: if_icmpne -> 1061
    //   1006: aload_0
    //   1007: invokevirtual getWidth : ()I
    //   1010: aload #12
    //   1012: getfield right : I
    //   1015: isub
    //   1016: aload #17
    //   1018: getfield rightMargin : I
    //   1021: isub
    //   1022: aload #17
    //   1024: getfield i : I
    //   1027: iadd
    //   1028: istore #6
    //   1030: aload #13
    //   1032: getfield right : I
    //   1035: istore #8
    //   1037: iload_3
    //   1038: istore #5
    //   1040: iload #6
    //   1042: iload #8
    //   1044: if_icmpge -> 1061
    //   1047: aload_0
    //   1048: aload #15
    //   1050: iload #6
    //   1052: iload #8
    //   1054: isub
    //   1055: invokevirtual w : (Landroid/view/View;I)V
    //   1058: iconst_1
    //   1059: istore #5
    //   1061: iload #5
    //   1063: ifne -> 1073
    //   1066: aload_0
    //   1067: aload #15
    //   1069: iconst_0
    //   1070: invokevirtual w : (Landroid/view/View;I)V
    //   1073: aload #12
    //   1075: invokevirtual setEmpty : ()V
    //   1078: aload #18
    //   1080: aload #12
    //   1082: invokevirtual a : (Ljava/lang/Object;)Z
    //   1085: pop
    //   1086: iload_1
    //   1087: iconst_2
    //   1088: if_icmpeq -> 1155
    //   1091: aload #15
    //   1093: invokevirtual getLayoutParams : ()Landroid/view/ViewGroup$LayoutParams;
    //   1096: checkcast androidx/coordinatorlayout/widget/CoordinatorLayout$f
    //   1099: getfield q : Landroid/graphics/Rect;
    //   1102: astore #16
    //   1104: aload #11
    //   1106: astore #12
    //   1108: aload #12
    //   1110: aload #16
    //   1112: invokevirtual set : (Landroid/graphics/Rect;)V
    //   1115: aload #12
    //   1117: aload #14
    //   1119: invokevirtual equals : (Ljava/lang/Object;)Z
    //   1122: ifeq -> 1136
    //   1125: aload #12
    //   1127: astore #11
    //   1129: iload #4
    //   1131: istore #6
    //   1133: goto -> 1309
    //   1136: aload #15
    //   1138: invokevirtual getLayoutParams : ()Landroid/view/ViewGroup$LayoutParams;
    //   1141: checkcast androidx/coordinatorlayout/widget/CoordinatorLayout$f
    //   1144: getfield q : Landroid/graphics/Rect;
    //   1147: aload #14
    //   1149: invokevirtual set : (Landroid/graphics/Rect;)V
    //   1152: goto -> 1155
    //   1155: aload #11
    //   1157: astore #12
    //   1159: iload #4
    //   1161: iconst_1
    //   1162: iadd
    //   1163: istore #5
    //   1165: iload_2
    //   1166: istore_3
    //   1167: iload_3
    //   1168: istore_2
    //   1169: aload #12
    //   1171: astore #11
    //   1173: iload #4
    //   1175: istore #6
    //   1177: iload #5
    //   1179: iload_3
    //   1180: if_icmpge -> 1309
    //   1183: aload_0
    //   1184: getfield h : Ljava/util/List;
    //   1187: iload #5
    //   1189: invokeinterface get : (I)Ljava/lang/Object;
    //   1194: checkcast android/view/View
    //   1197: astore #11
    //   1199: aload #11
    //   1201: invokevirtual getLayoutParams : ()Landroid/view/ViewGroup$LayoutParams;
    //   1204: checkcast androidx/coordinatorlayout/widget/CoordinatorLayout$f
    //   1207: astore #16
    //   1209: aload #16
    //   1211: getfield a : Landroidx/coordinatorlayout/widget/CoordinatorLayout$c;
    //   1214: astore #17
    //   1216: aload #17
    //   1218: ifnull -> 1300
    //   1221: aload #17
    //   1223: aload_0
    //   1224: aload #11
    //   1226: aload #15
    //   1228: invokevirtual b : (Landroidx/coordinatorlayout/widget/CoordinatorLayout;Landroid/view/View;Landroid/view/View;)Z
    //   1231: ifeq -> 1300
    //   1234: iload_1
    //   1235: ifne -> 1255
    //   1238: aload #16
    //   1240: getfield p : Z
    //   1243: ifeq -> 1255
    //   1246: aload #16
    //   1248: iconst_0
    //   1249: putfield p : Z
    //   1252: goto -> 1300
    //   1255: iload_1
    //   1256: iconst_2
    //   1257: if_icmpeq -> 1275
    //   1260: aload #17
    //   1262: aload_0
    //   1263: aload #11
    //   1265: aload #15
    //   1267: invokevirtual d : (Landroidx/coordinatorlayout/widget/CoordinatorLayout;Landroid/view/View;Landroid/view/View;)Z
    //   1270: istore #10
    //   1272: goto -> 1288
    //   1275: aload #17
    //   1277: aload_0
    //   1278: aload #11
    //   1280: aload #15
    //   1282: invokevirtual e : (Landroidx/coordinatorlayout/widget/CoordinatorLayout;Landroid/view/View;Landroid/view/View;)V
    //   1285: iconst_1
    //   1286: istore #10
    //   1288: iload_1
    //   1289: iconst_1
    //   1290: if_icmpne -> 1300
    //   1293: aload #16
    //   1295: iload #10
    //   1297: putfield p : Z
    //   1300: iload #5
    //   1302: iconst_1
    //   1303: iadd
    //   1304: istore #5
    //   1306: goto -> 1167
    //   1309: iload #6
    //   1311: iconst_1
    //   1312: iadd
    //   1313: istore_3
    //   1314: goto -> 38
    //   1317: aload #13
    //   1319: invokevirtual setEmpty : ()V
    //   1322: getstatic androidx/coordinatorlayout/widget/CoordinatorLayout.E : Lj0/c;
    //   1325: checkcast j0/e
    //   1328: astore #12
    //   1330: aload #12
    //   1332: aload #13
    //   1334: invokevirtual a : (Ljava/lang/Object;)Z
    //   1337: pop
    //   1338: aload #14
    //   1340: invokevirtual setEmpty : ()V
    //   1343: aload #12
    //   1345: aload #14
    //   1347: invokevirtual a : (Ljava/lang/Object;)Z
    //   1350: pop
    //   1351: aload #11
    //   1353: invokevirtual setEmpty : ()V
    //   1356: aload #12
    //   1358: aload #11
    //   1360: invokevirtual a : (Ljava/lang/Object;)Z
    //   1363: pop
    //   1364: return
  }
  
  public void r(View paramView, int paramInt) {
    int k;
    f f = (f)paramView.getLayoutParams();
    View view = f.k;
    int m = 0;
    if (view == null && f.f != -1) {
      k = 1;
    } else {
      k = 0;
    } 
    if (!k) {
      if (view != null) {
        rect1 = a();
        Rect rect = a();
        try {
          f(view, rect1);
          f f2 = (f)paramView.getLayoutParams();
          k = paramView.getMeasuredWidth();
          m = paramView.getMeasuredHeight();
          g(paramInt, rect1, rect, f2, k, m);
          b(f2, rect, k, m);
          paramView.layout(rect.left, rect.top, rect.right, rect.bottom);
          return;
        } finally {
          rect1.setEmpty();
          j0.e e1 = (j0.e)E;
          e1.a(rect1);
          rect.setEmpty();
          e1.a(rect);
        } 
      } 
      int n = ((f)rect1).e;
      if (n >= 0) {
        f f2 = (f)paramView.getLayoutParams();
        int i1 = f2.c;
        k = i1;
        if (i1 == 0)
          k = 8388661; 
        k = Gravity.getAbsoluteGravity(k, paramInt);
        int i6 = k & 0x7;
        int i5 = k & 0x70;
        int i4 = getWidth();
        int i3 = getHeight();
        i1 = paramView.getMeasuredWidth();
        int i2 = paramView.getMeasuredHeight();
        k = n;
        if (paramInt == 1)
          k = i4 - n; 
        paramInt = k(k) - i1;
        if (i6 != 1) {
          if (i6 == 5)
            paramInt += i1; 
        } else {
          paramInt += i1 / 2;
        } 
        if (i5 != 16) {
          if (i5 != 80) {
            k = m;
          } else {
            k = i2 + 0;
          } 
        } else {
          k = 0 + i2 / 2;
        } 
        paramInt = Math.max(getPaddingLeft() + f2.leftMargin, Math.min(paramInt, i4 - getPaddingRight() - i1 - f2.rightMargin));
        k = Math.max(getPaddingTop() + f2.topMargin, Math.min(k, i3 - getPaddingBottom() - i2 - f2.bottomMargin));
        paramView.layout(paramInt, k, i1 + paramInt, i2 + k);
        return;
      } 
      f f1 = (f)paramView.getLayoutParams();
      Rect rect1 = a();
      rect1.set(getPaddingLeft() + f1.leftMargin, getPaddingTop() + f1.topMargin, getWidth() - getPaddingRight() - f1.rightMargin, getHeight() - getPaddingBottom() - f1.bottomMargin);
      if (this.u != null) {
        WeakHashMap weakHashMap = l.a;
        if (getFitsSystemWindows() && !paramView.getFitsSystemWindows()) {
          k = rect1.left;
          rect1.left = this.u.b() + k;
          k = rect1.top;
          rect1.top = this.u.d() + k;
          rect1.right -= this.u.c();
          rect1.bottom -= this.u.a();
        } 
      } 
      Rect rect2 = a();
      m = f1.c;
      k = m;
      if ((m & 0x7) == 0)
        k = m | 0x800003; 
      m = k;
      if ((k & 0x70) == 0)
        m = k | 0x30; 
      Gravity.apply(m, paramView.getMeasuredWidth(), paramView.getMeasuredHeight(), rect1, rect2, paramInt);
      paramView.layout(rect2.left, rect2.top, rect2.right, rect2.bottom);
      rect1.setEmpty();
      j0.e e = (j0.e)E;
      e.a(rect1);
      rect2.setEmpty();
      e.a(rect2);
      return;
    } 
    throw new IllegalStateException("An anchor may not be changed after CoordinatorLayout measurement begins before layout is complete.");
  }
  
  public boolean requestChildRectangleOnScreen(View paramView, Rect paramRect, boolean paramBoolean) {
    c<View> c1 = ((f)paramView.getLayoutParams()).a;
    return (c1 != null && c1.m(this, paramView, paramRect, paramBoolean)) ? true : super.requestChildRectangleOnScreen(paramView, paramRect, paramBoolean);
  }
  
  public void requestDisallowInterceptTouchEvent(boolean paramBoolean) {
    super.requestDisallowInterceptTouchEvent(paramBoolean);
    if (paramBoolean && !this.n) {
      v(false);
      this.n = true;
    } 
  }
  
  public void s(View paramView, int paramInt1, int paramInt2, int paramInt3, int paramInt4) {
    measureChildWithMargins(paramView, paramInt1, paramInt2, paramInt3, paramInt4);
  }
  
  public void setFitsSystemWindows(boolean paramBoolean) {
    super.setFitsSystemWindows(paramBoolean);
    y();
  }
  
  public void setOnHierarchyChangeListener(ViewGroup.OnHierarchyChangeListener paramOnHierarchyChangeListener) {
    this.x = paramOnHierarchyChangeListener;
  }
  
  public void setStatusBarBackground(Drawable paramDrawable) {
    Drawable drawable = this.w;
    if (drawable != paramDrawable) {
      Drawable drawable1 = null;
      if (drawable != null)
        drawable.setCallback(null); 
      if (paramDrawable != null)
        drawable1 = paramDrawable.mutate(); 
      this.w = drawable1;
      if (drawable1 != null) {
        boolean bool;
        if (drawable1.isStateful())
          this.w.setState(getDrawableState()); 
        paramDrawable = this.w;
        WeakHashMap weakHashMap1 = l.a;
        e0.a.c(paramDrawable, getLayoutDirection());
        paramDrawable = this.w;
        if (getVisibility() == 0) {
          bool = true;
        } else {
          bool = false;
        } 
        paramDrawable.setVisible(bool, false);
        this.w.setCallback((Drawable.Callback)this);
      } 
      WeakHashMap weakHashMap = l.a;
      postInvalidateOnAnimation();
    } 
  }
  
  public void setStatusBarBackgroundColor(int paramInt) {
    setStatusBarBackground((Drawable)new ColorDrawable(paramInt));
  }
  
  public void setStatusBarBackgroundResource(int paramInt) {
    Drawable drawable;
    if (paramInt != 0) {
      Context context = getContext();
      Object object = b0.a.a;
      drawable = b0.a.c.b(context, paramInt);
    } else {
      drawable = null;
    } 
    setStatusBarBackground(drawable);
  }
  
  public void setVisibility(int paramInt) {
    boolean bool;
    super.setVisibility(paramInt);
    if (paramInt == 0) {
      bool = true;
    } else {
      bool = false;
    } 
    Drawable drawable = this.w;
    if (drawable != null && drawable.isVisible() != bool)
      this.w.setVisible(bool, false); 
  }
  
  public final boolean t(MotionEvent paramMotionEvent, int paramInt) {
    boolean bool2;
    int i1 = paramMotionEvent.getActionMasked();
    List<View> list = this.j;
    list.clear();
    boolean bool1 = isChildrenDrawingOrderEnabled();
    int n = getChildCount();
    int k;
    for (k = n - 1; k >= 0; k--) {
      int i3;
      if (bool1) {
        i3 = getChildDrawingOrder(n, k);
      } else {
        i3 = k;
      } 
      list.add(getChildAt(i3));
    } 
    Comparator<View> comparator = D;
    if (comparator != null)
      Collections.sort(list, comparator); 
    int i2 = list.size();
    comparator = null;
    int m = 0;
    bool1 = false;
    k = 0;
    while (true) {
      bool2 = bool1;
      if (m < i2) {
        boolean bool;
        MotionEvent motionEvent;
        Comparator<View> comparator1;
        View view = list.get(m);
        f f = (f)view.getLayoutParams();
        c<View> c1 = f.a;
        if ((bool1 || k != 0) && i1 != 0) {
          comparator1 = comparator;
          bool = bool1;
          n = k;
          if (c1 != null) {
            comparator1 = comparator;
            if (comparator == null) {
              long l = SystemClock.uptimeMillis();
              motionEvent = MotionEvent.obtain(l, l, 3, 0.0F, 0.0F, 0);
            } 
            if (paramInt != 0) {
              if (paramInt != 1) {
                bool = bool1;
                n = k;
              } else {
                c1.r(this, view, motionEvent);
                bool = bool1;
                n = k;
              } 
            } else {
              c1.g(this, view, motionEvent);
              bool = bool1;
              n = k;
            } 
          } 
        } else {
          int i3;
          bool2 = bool1;
          if (!bool1) {
            bool2 = bool1;
            if (c1 != null) {
              if (paramInt != 0) {
                if (paramInt == 1)
                  bool1 = c1.r(this, view, paramMotionEvent); 
              } else {
                bool1 = c1.g(this, view, paramMotionEvent);
              } 
              bool2 = bool1;
              if (bool1) {
                this.q = view;
                bool2 = bool1;
              } 
            } 
          } 
          if (((f)motionEvent).a == null)
            ((f)motionEvent).m = false; 
          bool = ((f)motionEvent).m;
          if (bool) {
            bool1 = true;
          } else {
            i3 = bool | false;
            ((f)motionEvent).m = i3;
          } 
          if (i3 != 0 && !bool) {
            k = 1;
          } else {
            k = 0;
          } 
          comparator1 = comparator;
          bool = bool2;
          n = k;
          if (i3 != 0) {
            comparator1 = comparator;
            bool = bool2;
            n = k;
            if (k == 0)
              break; 
          } 
        } 
        m++;
        comparator = comparator1;
        bool1 = bool;
        k = n;
        continue;
      } 
      break;
    } 
    list.clear();
    return bool2;
  }
  
  public final void u() {
    // Byte code:
    //   0: aload_0
    //   1: getfield h : Ljava/util/List;
    //   4: invokeinterface clear : ()V
    //   9: aload_0
    //   10: getfield i : Ly/a;
    //   13: astore #7
    //   15: aload #7
    //   17: getfield b : Ljava/lang/Object;
    //   20: checkcast r/g
    //   23: getfield j : I
    //   26: istore_2
    //   27: iconst_0
    //   28: istore #4
    //   30: iconst_0
    //   31: istore_1
    //   32: iload_1
    //   33: iload_2
    //   34: if_icmpge -> 87
    //   37: aload #7
    //   39: getfield b : Ljava/lang/Object;
    //   42: checkcast r/g
    //   45: iload_1
    //   46: invokevirtual l : (I)Ljava/lang/Object;
    //   49: checkcast java/util/ArrayList
    //   52: astore #8
    //   54: aload #8
    //   56: ifnull -> 80
    //   59: aload #8
    //   61: invokevirtual clear : ()V
    //   64: aload #7
    //   66: getfield a : Ljava/lang/Object;
    //   69: checkcast j0/c
    //   72: aload #8
    //   74: invokeinterface a : (Ljava/lang/Object;)Z
    //   79: pop
    //   80: iload_1
    //   81: iconst_1
    //   82: iadd
    //   83: istore_1
    //   84: goto -> 32
    //   87: aload #7
    //   89: getfield b : Ljava/lang/Object;
    //   92: checkcast r/g
    //   95: invokevirtual clear : ()V
    //   98: aload_0
    //   99: invokevirtual getChildCount : ()I
    //   102: istore #5
    //   104: iconst_0
    //   105: istore_1
    //   106: iload_1
    //   107: iload #5
    //   109: if_icmpge -> 834
    //   112: aload_0
    //   113: iload_1
    //   114: invokevirtual getChildAt : (I)Landroid/view/View;
    //   117: astore #9
    //   119: aload_0
    //   120: aload #9
    //   122: invokevirtual l : (Landroid/view/View;)Landroidx/coordinatorlayout/widget/CoordinatorLayout$f;
    //   125: astore #10
    //   127: aload #10
    //   129: getfield f : I
    //   132: iconst_m1
    //   133: if_icmpne -> 151
    //   136: aload #10
    //   138: aconst_null
    //   139: putfield l : Landroid/view/View;
    //   142: aload #10
    //   144: aconst_null
    //   145: putfield k : Landroid/view/View;
    //   148: goto -> 423
    //   151: aload #10
    //   153: getfield k : Landroid/view/View;
    //   156: astore #7
    //   158: aload #7
    //   160: ifnull -> 271
    //   163: aload #7
    //   165: invokevirtual getId : ()I
    //   168: aload #10
    //   170: getfield f : I
    //   173: if_icmpeq -> 179
    //   176: goto -> 253
    //   179: aload #10
    //   181: getfield k : Landroid/view/View;
    //   184: astore #8
    //   186: aload #8
    //   188: invokevirtual getParent : ()Landroid/view/ViewParent;
    //   191: astore #7
    //   193: aload #7
    //   195: aload_0
    //   196: if_acmpeq -> 258
    //   199: aload #7
    //   201: ifnull -> 241
    //   204: aload #7
    //   206: aload #9
    //   208: if_acmpne -> 214
    //   211: goto -> 241
    //   214: aload #7
    //   216: instanceof android/view/View
    //   219: ifeq -> 229
    //   222: aload #7
    //   224: checkcast android/view/View
    //   227: astore #8
    //   229: aload #7
    //   231: invokeinterface getParent : ()Landroid/view/ViewParent;
    //   236: astore #7
    //   238: goto -> 193
    //   241: aload #10
    //   243: aconst_null
    //   244: putfield l : Landroid/view/View;
    //   247: aload #10
    //   249: aconst_null
    //   250: putfield k : Landroid/view/View;
    //   253: iconst_0
    //   254: istore_2
    //   255: goto -> 267
    //   258: aload #10
    //   260: aload #8
    //   262: putfield l : Landroid/view/View;
    //   265: iconst_1
    //   266: istore_2
    //   267: iload_2
    //   268: ifne -> 423
    //   271: aload_0
    //   272: aload #10
    //   274: getfield f : I
    //   277: invokevirtual findViewById : (I)Landroid/view/View;
    //   280: astore #8
    //   282: aload #10
    //   284: aload #8
    //   286: putfield k : Landroid/view/View;
    //   289: aload #8
    //   291: ifnull -> 404
    //   294: aload #8
    //   296: aload_0
    //   297: if_acmpne -> 321
    //   300: aload_0
    //   301: invokevirtual isInEditMode : ()Z
    //   304: ifeq -> 310
    //   307: goto -> 411
    //   310: new java/lang/IllegalStateException
    //   313: dup
    //   314: ldc_w 'View can not be anchored to the the parent CoordinatorLayout'
    //   317: invokespecial <init> : (Ljava/lang/String;)V
    //   320: athrow
    //   321: aload #8
    //   323: invokevirtual getParent : ()Landroid/view/ViewParent;
    //   326: astore #7
    //   328: aload #7
    //   330: aload_0
    //   331: if_acmpeq -> 394
    //   334: aload #7
    //   336: ifnull -> 394
    //   339: aload #7
    //   341: aload #9
    //   343: if_acmpne -> 367
    //   346: aload_0
    //   347: invokevirtual isInEditMode : ()Z
    //   350: ifeq -> 356
    //   353: goto -> 411
    //   356: new java/lang/IllegalStateException
    //   359: dup
    //   360: ldc_w 'Anchor must not be a descendant of the anchored view'
    //   363: invokespecial <init> : (Ljava/lang/String;)V
    //   366: athrow
    //   367: aload #7
    //   369: instanceof android/view/View
    //   372: ifeq -> 382
    //   375: aload #7
    //   377: checkcast android/view/View
    //   380: astore #8
    //   382: aload #7
    //   384: invokeinterface getParent : ()Landroid/view/ViewParent;
    //   389: astore #7
    //   391: goto -> 328
    //   394: aload #10
    //   396: aload #8
    //   398: putfield l : Landroid/view/View;
    //   401: goto -> 423
    //   404: aload_0
    //   405: invokevirtual isInEditMode : ()Z
    //   408: ifeq -> 778
    //   411: aload #10
    //   413: aconst_null
    //   414: putfield l : Landroid/view/View;
    //   417: aload #10
    //   419: aconst_null
    //   420: putfield k : Landroid/view/View;
    //   423: aload_0
    //   424: getfield i : Ly/a;
    //   427: aload #9
    //   429: invokevirtual a : (Ljava/lang/Object;)V
    //   432: iconst_0
    //   433: istore_2
    //   434: iload_2
    //   435: iload #5
    //   437: if_icmpge -> 771
    //   440: iload_2
    //   441: iload_1
    //   442: if_icmpne -> 448
    //   445: goto -> 764
    //   448: aload_0
    //   449: iload_2
    //   450: invokevirtual getChildAt : (I)Landroid/view/View;
    //   453: astore #11
    //   455: aload #11
    //   457: aload #10
    //   459: getfield l : Landroid/view/View;
    //   462: if_acmpeq -> 558
    //   465: getstatic k0/l.a : Ljava/util/WeakHashMap;
    //   468: astore #7
    //   470: aload_0
    //   471: invokevirtual getLayoutDirection : ()I
    //   474: istore_3
    //   475: aload #11
    //   477: invokevirtual getLayoutParams : ()Landroid/view/ViewGroup$LayoutParams;
    //   480: checkcast androidx/coordinatorlayout/widget/CoordinatorLayout$f
    //   483: getfield g : I
    //   486: iload_3
    //   487: invokestatic getAbsoluteGravity : (II)I
    //   490: istore #6
    //   492: iload #6
    //   494: ifeq -> 519
    //   497: aload #10
    //   499: getfield h : I
    //   502: iload_3
    //   503: invokestatic getAbsoluteGravity : (II)I
    //   506: iload #6
    //   508: iand
    //   509: iload #6
    //   511: if_icmpne -> 519
    //   514: iconst_1
    //   515: istore_3
    //   516: goto -> 521
    //   519: iconst_0
    //   520: istore_3
    //   521: iload_3
    //   522: ifne -> 558
    //   525: aload #10
    //   527: getfield a : Landroidx/coordinatorlayout/widget/CoordinatorLayout$c;
    //   530: astore #7
    //   532: aload #7
    //   534: ifnull -> 553
    //   537: aload #7
    //   539: aload_0
    //   540: aload #9
    //   542: aload #11
    //   544: invokevirtual b : (Landroidx/coordinatorlayout/widget/CoordinatorLayout;Landroid/view/View;Landroid/view/View;)Z
    //   547: ifeq -> 553
    //   550: goto -> 558
    //   553: iconst_0
    //   554: istore_3
    //   555: goto -> 560
    //   558: iconst_1
    //   559: istore_3
    //   560: iload_3
    //   561: ifeq -> 764
    //   564: aload_0
    //   565: getfield i : Ly/a;
    //   568: getfield b : Ljava/lang/Object;
    //   571: checkcast r/g
    //   574: aload #11
    //   576: invokevirtual e : (Ljava/lang/Object;)I
    //   579: iflt -> 587
    //   582: iconst_1
    //   583: istore_3
    //   584: goto -> 589
    //   587: iconst_0
    //   588: istore_3
    //   589: iload_3
    //   590: ifne -> 602
    //   593: aload_0
    //   594: getfield i : Ly/a;
    //   597: aload #11
    //   599: invokevirtual a : (Ljava/lang/Object;)V
    //   602: aload_0
    //   603: getfield i : Ly/a;
    //   606: astore #12
    //   608: aload #12
    //   610: getfield b : Ljava/lang/Object;
    //   613: checkcast r/g
    //   616: aload #11
    //   618: invokevirtual e : (Ljava/lang/Object;)I
    //   621: iflt -> 629
    //   624: iconst_1
    //   625: istore_3
    //   626: goto -> 631
    //   629: iconst_0
    //   630: istore_3
    //   631: iload_3
    //   632: ifeq -> 753
    //   635: aload #12
    //   637: getfield b : Ljava/lang/Object;
    //   640: checkcast r/g
    //   643: aload #9
    //   645: invokevirtual e : (Ljava/lang/Object;)I
    //   648: iflt -> 656
    //   651: iconst_1
    //   652: istore_3
    //   653: goto -> 658
    //   656: iconst_0
    //   657: istore_3
    //   658: iload_3
    //   659: ifeq -> 753
    //   662: aload #12
    //   664: getfield b : Ljava/lang/Object;
    //   667: checkcast r/g
    //   670: aload #11
    //   672: aconst_null
    //   673: invokevirtual getOrDefault : (Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    //   676: checkcast java/util/ArrayList
    //   679: astore #8
    //   681: aload #8
    //   683: astore #7
    //   685: aload #8
    //   687: ifnonnull -> 742
    //   690: aload #12
    //   692: getfield a : Ljava/lang/Object;
    //   695: checkcast j0/c
    //   698: invokeinterface b : ()Ljava/lang/Object;
    //   703: checkcast java/util/ArrayList
    //   706: astore #8
    //   708: aload #8
    //   710: astore #7
    //   712: aload #8
    //   714: ifnonnull -> 726
    //   717: new java/util/ArrayList
    //   720: dup
    //   721: invokespecial <init> : ()V
    //   724: astore #7
    //   726: aload #12
    //   728: getfield b : Ljava/lang/Object;
    //   731: checkcast r/g
    //   734: aload #11
    //   736: aload #7
    //   738: invokevirtual put : (Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    //   741: pop
    //   742: aload #7
    //   744: aload #9
    //   746: invokevirtual add : (Ljava/lang/Object;)Z
    //   749: pop
    //   750: goto -> 764
    //   753: new java/lang/IllegalArgumentException
    //   756: dup
    //   757: ldc_w 'All nodes must be present in the graph before being added as an edge'
    //   760: invokespecial <init> : (Ljava/lang/String;)V
    //   763: athrow
    //   764: iload_2
    //   765: iconst_1
    //   766: iadd
    //   767: istore_2
    //   768: goto -> 434
    //   771: iload_1
    //   772: iconst_1
    //   773: iadd
    //   774: istore_1
    //   775: goto -> 106
    //   778: ldc_w 'Could not find CoordinatorLayout descendant view with id '
    //   781: invokestatic a : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   784: astore #7
    //   786: aload #7
    //   788: aload_0
    //   789: invokevirtual getResources : ()Landroid/content/res/Resources;
    //   792: aload #10
    //   794: getfield f : I
    //   797: invokevirtual getResourceName : (I)Ljava/lang/String;
    //   800: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   803: pop
    //   804: aload #7
    //   806: ldc_w ' to anchor view '
    //   809: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   812: pop
    //   813: aload #7
    //   815: aload #9
    //   817: invokevirtual append : (Ljava/lang/Object;)Ljava/lang/StringBuilder;
    //   820: pop
    //   821: new java/lang/IllegalStateException
    //   824: dup
    //   825: aload #7
    //   827: invokevirtual toString : ()Ljava/lang/String;
    //   830: invokespecial <init> : (Ljava/lang/String;)V
    //   833: athrow
    //   834: aload_0
    //   835: getfield h : Ljava/util/List;
    //   838: astore #7
    //   840: aload_0
    //   841: getfield i : Ly/a;
    //   844: astore #8
    //   846: aload #8
    //   848: getfield c : Ljava/lang/Object;
    //   851: checkcast java/util/ArrayList
    //   854: invokevirtual clear : ()V
    //   857: aload #8
    //   859: getfield d : Ljava/lang/Object;
    //   862: checkcast java/util/HashSet
    //   865: invokevirtual clear : ()V
    //   868: aload #8
    //   870: getfield b : Ljava/lang/Object;
    //   873: checkcast r/g
    //   876: getfield j : I
    //   879: istore_2
    //   880: iload #4
    //   882: istore_1
    //   883: iload_1
    //   884: iload_2
    //   885: if_icmpge -> 928
    //   888: aload #8
    //   890: aload #8
    //   892: getfield b : Ljava/lang/Object;
    //   895: checkcast r/g
    //   898: iload_1
    //   899: invokevirtual h : (I)Ljava/lang/Object;
    //   902: aload #8
    //   904: getfield c : Ljava/lang/Object;
    //   907: checkcast java/util/ArrayList
    //   910: aload #8
    //   912: getfield d : Ljava/lang/Object;
    //   915: checkcast java/util/HashSet
    //   918: invokevirtual b : (Ljava/lang/Object;Ljava/util/ArrayList;Ljava/util/HashSet;)V
    //   921: iload_1
    //   922: iconst_1
    //   923: iadd
    //   924: istore_1
    //   925: goto -> 883
    //   928: aload #7
    //   930: aload #8
    //   932: getfield c : Ljava/lang/Object;
    //   935: checkcast java/util/ArrayList
    //   938: invokeinterface addAll : (Ljava/util/Collection;)Z
    //   943: pop
    //   944: aload_0
    //   945: getfield h : Ljava/util/List;
    //   948: invokestatic reverse : (Ljava/util/List;)V
    //   951: return
  }
  
  public final void v(boolean paramBoolean) {
    int m = getChildCount();
    int k;
    for (k = 0; k < m; k++) {
      View view = getChildAt(k);
      c<View> c1 = ((f)view.getLayoutParams()).a;
      if (c1 != null) {
        long l = SystemClock.uptimeMillis();
        MotionEvent motionEvent = MotionEvent.obtain(l, l, 3, 0.0F, 0.0F, 0);
        if (paramBoolean) {
          c1.g(this, view, motionEvent);
        } else {
          c1.r(this, view, motionEvent);
        } 
        motionEvent.recycle();
      } 
    } 
    for (k = 0; k < m; k++)
      ((f)getChildAt(k).getLayoutParams()).m = false; 
    this.q = null;
    this.n = false;
  }
  
  public boolean verifyDrawable(Drawable paramDrawable) {
    return (super.verifyDrawable(paramDrawable) || paramDrawable == this.w);
  }
  
  public final void w(View paramView, int paramInt) {
    f f = (f)paramView.getLayoutParams();
    int k = f.i;
    if (k != paramInt) {
      l.m(paramView, paramInt - k);
      f.i = paramInt;
    } 
  }
  
  public final void x(View paramView, int paramInt) {
    f f = (f)paramView.getLayoutParams();
    int k = f.j;
    if (k != paramInt) {
      l.n(paramView, paramInt - k);
      f.j = paramInt;
    } 
  }
  
  public final void y() {
    WeakHashMap weakHashMap = l.a;
    if (getFitsSystemWindows()) {
      if (this.y == null)
        this.y = new a(this); 
      l.a.d((View)this, this.y);
      setSystemUiVisibility(1280);
      return;
    } 
    l.a.d((View)this, null);
  }
  
  static {
    Package package_ = CoordinatorLayout.class.getPackage();
    if (package_ != null) {
      String str = package_.getName();
    } else {
      package_ = null;
    } 
    A = (String)package_;
  }
  
  public class a implements j {
    public a(CoordinatorLayout this$0) {}
    
    public r a(View param1View, r param1r) {
      CoordinatorLayout coordinatorLayout = this.a;
      if (!Objects.equals(coordinatorLayout.u, param1r)) {
        boolean bool1;
        coordinatorLayout.u = param1r;
        int k = param1r.d();
        boolean bool2 = true;
        int i = 0;
        if (k > 0) {
          bool1 = true;
        } else {
          bool1 = false;
        } 
        coordinatorLayout.v = bool1;
        if (!bool1 && coordinatorLayout.getBackground() == null) {
          bool1 = bool2;
        } else {
          bool1 = false;
        } 
        coordinatorLayout.setWillNotDraw(bool1);
        if (!param1r.f()) {
          k = coordinatorLayout.getChildCount();
          while (i < k) {
            View view = coordinatorLayout.getChildAt(i);
            WeakHashMap weakHashMap = l.a;
            if (view.getFitsSystemWindows() && ((CoordinatorLayout.f)view.getLayoutParams()).a != null && param1r.f())
              break; 
            i++;
          } 
        } 
        coordinatorLayout.requestLayout();
      } 
      return param1r;
    }
  }
  
  public static interface b {
    CoordinatorLayout.c getBehavior();
  }
  
  public static abstract class c<V extends View> {
    public c() {}
    
    public c(Context param1Context, AttributeSet param1AttributeSet) {}
    
    public boolean a(CoordinatorLayout param1CoordinatorLayout, V param1V, Rect param1Rect) {
      return false;
    }
    
    public boolean b(CoordinatorLayout param1CoordinatorLayout, V param1V, View param1View) {
      return false;
    }
    
    public void c(CoordinatorLayout.f param1f) {}
    
    public boolean d(CoordinatorLayout param1CoordinatorLayout, V param1V, View param1View) {
      return false;
    }
    
    public void e(CoordinatorLayout param1CoordinatorLayout, V param1V, View param1View) {}
    
    public void f() {}
    
    public boolean g(CoordinatorLayout param1CoordinatorLayout, V param1V, MotionEvent param1MotionEvent) {
      return false;
    }
    
    public boolean h(CoordinatorLayout param1CoordinatorLayout, V param1V, int param1Int) {
      return false;
    }
    
    public boolean i(CoordinatorLayout param1CoordinatorLayout, V param1V, int param1Int1, int param1Int2, int param1Int3, int param1Int4) {
      return false;
    }
    
    public boolean j(CoordinatorLayout param1CoordinatorLayout, V param1V, View param1View, float param1Float1, float param1Float2) {
      return false;
    }
    
    public void k(CoordinatorLayout param1CoordinatorLayout, V param1V, View param1View, int param1Int1, int param1Int2, int[] param1ArrayOfint, int param1Int3) {}
    
    public void l(CoordinatorLayout param1CoordinatorLayout, V param1V, View param1View, int param1Int1, int param1Int2, int param1Int3, int param1Int4, int param1Int5, int[] param1ArrayOfint) {
      param1ArrayOfint[0] = param1ArrayOfint[0] + param1Int3;
      param1ArrayOfint[1] = param1ArrayOfint[1] + param1Int4;
    }
    
    public boolean m(CoordinatorLayout param1CoordinatorLayout, V param1V, Rect param1Rect, boolean param1Boolean) {
      return false;
    }
    
    public void n(CoordinatorLayout param1CoordinatorLayout, V param1V, Parcelable param1Parcelable) {}
    
    public Parcelable o(CoordinatorLayout param1CoordinatorLayout, V param1V) {
      return (Parcelable)View.BaseSavedState.EMPTY_STATE;
    }
    
    public boolean p(CoordinatorLayout param1CoordinatorLayout, V param1V, View param1View1, View param1View2, int param1Int1, int param1Int2) {
      return false;
    }
    
    public void q(CoordinatorLayout param1CoordinatorLayout, V param1V, View param1View, int param1Int) {}
    
    public boolean r(CoordinatorLayout param1CoordinatorLayout, V param1V, MotionEvent param1MotionEvent) {
      return false;
    }
  }
  
  @Deprecated
  @Retention(RetentionPolicy.RUNTIME)
  public static @interface d {
    Class<? extends CoordinatorLayout.c> value();
  }
  
  public class e implements ViewGroup.OnHierarchyChangeListener {
    public e(CoordinatorLayout this$0) {}
    
    public void onChildViewAdded(View param1View1, View param1View2) {
      ViewGroup.OnHierarchyChangeListener onHierarchyChangeListener = this.h.x;
      if (onHierarchyChangeListener != null)
        onHierarchyChangeListener.onChildViewAdded(param1View1, param1View2); 
    }
    
    public void onChildViewRemoved(View param1View1, View param1View2) {
      this.h.q(2);
      ViewGroup.OnHierarchyChangeListener onHierarchyChangeListener = this.h.x;
      if (onHierarchyChangeListener != null)
        onHierarchyChangeListener.onChildViewRemoved(param1View1, param1View2); 
    }
  }
  
  public static class f extends ViewGroup.MarginLayoutParams {
    public CoordinatorLayout.c a;
    
    public boolean b = false;
    
    public int c = 0;
    
    public int d = 0;
    
    public int e = -1;
    
    public int f = -1;
    
    public int g = 0;
    
    public int h = 0;
    
    public int i;
    
    public int j;
    
    public View k;
    
    public View l;
    
    public boolean m;
    
    public boolean n;
    
    public boolean o;
    
    public boolean p;
    
    public final Rect q = new Rect();
    
    public f(int param1Int1, int param1Int2) {
      super(param1Int1, param1Int2);
    }
    
    public f(Context param1Context, AttributeSet param1AttributeSet) {
      // Byte code:
      //   0: aload_0
      //   1: aload_1
      //   2: aload_2
      //   3: invokespecial <init> : (Landroid/content/Context;Landroid/util/AttributeSet;)V
      //   6: aload_0
      //   7: iconst_0
      //   8: putfield b : Z
      //   11: aload_0
      //   12: iconst_0
      //   13: putfield c : I
      //   16: aload_0
      //   17: iconst_0
      //   18: putfield d : I
      //   21: aload_0
      //   22: iconst_m1
      //   23: putfield e : I
      //   26: aload_0
      //   27: iconst_m1
      //   28: putfield f : I
      //   31: aload_0
      //   32: iconst_0
      //   33: putfield g : I
      //   36: aload_0
      //   37: iconst_0
      //   38: putfield h : I
      //   41: aload_0
      //   42: new android/graphics/Rect
      //   45: dup
      //   46: invokespecial <init> : ()V
      //   49: putfield q : Landroid/graphics/Rect;
      //   52: aload_1
      //   53: aload_2
      //   54: getstatic e4/ho0.l : [I
      //   57: invokevirtual obtainStyledAttributes : (Landroid/util/AttributeSet;[I)Landroid/content/res/TypedArray;
      //   60: astore #8
      //   62: aload_0
      //   63: aload #8
      //   65: iconst_0
      //   66: iconst_0
      //   67: invokevirtual getInteger : (II)I
      //   70: putfield c : I
      //   73: aload_0
      //   74: aload #8
      //   76: iconst_1
      //   77: iconst_m1
      //   78: invokevirtual getResourceId : (II)I
      //   81: putfield f : I
      //   84: aload_0
      //   85: aload #8
      //   87: iconst_2
      //   88: iconst_0
      //   89: invokevirtual getInteger : (II)I
      //   92: putfield d : I
      //   95: aload_0
      //   96: aload #8
      //   98: bipush #6
      //   100: iconst_m1
      //   101: invokevirtual getInteger : (II)I
      //   104: putfield e : I
      //   107: aload_0
      //   108: aload #8
      //   110: iconst_5
      //   111: iconst_0
      //   112: invokevirtual getInt : (II)I
      //   115: putfield g : I
      //   118: aload_0
      //   119: aload #8
      //   121: iconst_4
      //   122: iconst_0
      //   123: invokevirtual getInt : (II)I
      //   126: putfield h : I
      //   129: aload #8
      //   131: iconst_3
      //   132: invokevirtual hasValue : (I)Z
      //   135: istore_3
      //   136: aload_0
      //   137: iload_3
      //   138: putfield b : Z
      //   141: iload_3
      //   142: ifeq -> 437
      //   145: aload #8
      //   147: iconst_3
      //   148: invokevirtual getString : (I)Ljava/lang/String;
      //   151: astore #5
      //   153: getstatic androidx/coordinatorlayout/widget/CoordinatorLayout.A : Ljava/lang/String;
      //   156: astore #4
      //   158: aload #5
      //   160: invokestatic isEmpty : (Ljava/lang/CharSequence;)Z
      //   163: ifeq -> 171
      //   166: aconst_null
      //   167: astore_1
      //   168: goto -> 412
      //   171: aload #5
      //   173: ldc '.'
      //   175: invokevirtual startsWith : (Ljava/lang/String;)Z
      //   178: ifeq -> 218
      //   181: new java/lang/StringBuilder
      //   184: dup
      //   185: invokespecial <init> : ()V
      //   188: astore #4
      //   190: aload #4
      //   192: aload_1
      //   193: invokevirtual getPackageName : ()Ljava/lang/String;
      //   196: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
      //   199: pop
      //   200: aload #4
      //   202: aload #5
      //   204: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
      //   207: pop
      //   208: aload #4
      //   210: invokevirtual toString : ()Ljava/lang/String;
      //   213: astore #4
      //   215: goto -> 292
      //   218: aload #5
      //   220: bipush #46
      //   222: invokevirtual indexOf : (I)I
      //   225: iflt -> 235
      //   228: aload #5
      //   230: astore #4
      //   232: goto -> 292
      //   235: getstatic androidx/coordinatorlayout/widget/CoordinatorLayout.A : Ljava/lang/String;
      //   238: astore #6
      //   240: aload #5
      //   242: astore #4
      //   244: aload #6
      //   246: invokestatic isEmpty : (Ljava/lang/CharSequence;)Z
      //   249: ifne -> 292
      //   252: new java/lang/StringBuilder
      //   255: dup
      //   256: invokespecial <init> : ()V
      //   259: astore #4
      //   261: aload #4
      //   263: aload #6
      //   265: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
      //   268: pop
      //   269: aload #4
      //   271: bipush #46
      //   273: invokevirtual append : (C)Ljava/lang/StringBuilder;
      //   276: pop
      //   277: aload #4
      //   279: aload #5
      //   281: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
      //   284: pop
      //   285: aload #4
      //   287: invokevirtual toString : ()Ljava/lang/String;
      //   290: astore #4
      //   292: getstatic androidx/coordinatorlayout/widget/CoordinatorLayout.C : Ljava/lang/ThreadLocal;
      //   295: astore #7
      //   297: aload #7
      //   299: invokevirtual get : ()Ljava/lang/Object;
      //   302: checkcast java/util/Map
      //   305: astore #6
      //   307: aload #6
      //   309: astore #5
      //   311: aload #6
      //   313: ifnonnull -> 332
      //   316: new java/util/HashMap
      //   319: dup
      //   320: invokespecial <init> : ()V
      //   323: astore #5
      //   325: aload #7
      //   327: aload #5
      //   329: invokevirtual set : (Ljava/lang/Object;)V
      //   332: aload #5
      //   334: aload #4
      //   336: invokeinterface get : (Ljava/lang/Object;)Ljava/lang/Object;
      //   341: checkcast java/lang/reflect/Constructor
      //   344: astore #7
      //   346: aload #7
      //   348: astore #6
      //   350: aload #7
      //   352: ifnonnull -> 391
      //   355: aload #4
      //   357: iconst_0
      //   358: aload_1
      //   359: invokevirtual getClassLoader : ()Ljava/lang/ClassLoader;
      //   362: invokestatic forName : (Ljava/lang/String;ZLjava/lang/ClassLoader;)Ljava/lang/Class;
      //   365: getstatic androidx/coordinatorlayout/widget/CoordinatorLayout.B : [Ljava/lang/Class;
      //   368: invokevirtual getConstructor : ([Ljava/lang/Class;)Ljava/lang/reflect/Constructor;
      //   371: astore #6
      //   373: aload #6
      //   375: iconst_1
      //   376: invokevirtual setAccessible : (Z)V
      //   379: aload #5
      //   381: aload #4
      //   383: aload #6
      //   385: invokeinterface put : (Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
      //   390: pop
      //   391: aload #6
      //   393: iconst_2
      //   394: anewarray java/lang/Object
      //   397: dup
      //   398: iconst_0
      //   399: aload_1
      //   400: aastore
      //   401: dup
      //   402: iconst_1
      //   403: aload_2
      //   404: aastore
      //   405: invokevirtual newInstance : ([Ljava/lang/Object;)Ljava/lang/Object;
      //   408: checkcast androidx/coordinatorlayout/widget/CoordinatorLayout$c
      //   411: astore_1
      //   412: aload_0
      //   413: aload_1
      //   414: putfield a : Landroidx/coordinatorlayout/widget/CoordinatorLayout$c;
      //   417: goto -> 437
      //   420: astore_1
      //   421: new java/lang/RuntimeException
      //   424: dup
      //   425: ldc 'Could not inflate Behavior subclass '
      //   427: aload #4
      //   429: invokestatic a : (Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;
      //   432: aload_1
      //   433: invokespecial <init> : (Ljava/lang/String;Ljava/lang/Throwable;)V
      //   436: athrow
      //   437: aload #8
      //   439: invokevirtual recycle : ()V
      //   442: aload_0
      //   443: getfield a : Landroidx/coordinatorlayout/widget/CoordinatorLayout$c;
      //   446: astore_1
      //   447: aload_1
      //   448: ifnull -> 456
      //   451: aload_1
      //   452: aload_0
      //   453: invokevirtual c : (Landroidx/coordinatorlayout/widget/CoordinatorLayout$f;)V
      //   456: return
      // Exception table:
      //   from	to	target	type
      //   292	307	420	java/lang/Exception
      //   316	332	420	java/lang/Exception
      //   332	346	420	java/lang/Exception
      //   355	391	420	java/lang/Exception
      //   391	412	420	java/lang/Exception
    }
    
    public f(ViewGroup.LayoutParams param1LayoutParams) {
      super(param1LayoutParams);
    }
    
    public f(ViewGroup.MarginLayoutParams param1MarginLayoutParams) {
      super(param1MarginLayoutParams);
    }
    
    public f(f param1f) {
      super(param1f);
    }
    
    public boolean a(int param1Int) {
      return (param1Int != 0) ? ((param1Int != 1) ? false : this.o) : this.n;
    }
    
    public void b(int param1Int, boolean param1Boolean) {
      if (param1Int != 0) {
        if (param1Int != 1)
          return; 
        this.o = param1Boolean;
        return;
      } 
      this.n = param1Boolean;
    }
  }
  
  public class g implements ViewTreeObserver.OnPreDrawListener {
    public g(CoordinatorLayout this$0) {}
    
    public boolean onPreDraw() {
      this.h.q(0);
      return true;
    }
  }
  
  public static class h extends o0.a {
    public static final Parcelable.Creator<h> CREATOR = (Parcelable.Creator<h>)new a();
    
    public SparseArray<Parcelable> j;
    
    public h(Parcel param1Parcel, ClassLoader param1ClassLoader) {
      super(param1Parcel, param1ClassLoader);
      int j = param1Parcel.readInt();
      int[] arrayOfInt = new int[j];
      param1Parcel.readIntArray(arrayOfInt);
      Parcelable[] arrayOfParcelable = param1Parcel.readParcelableArray(param1ClassLoader);
      this.j = new SparseArray(j);
      for (int i = 0; i < j; i++)
        this.j.append(arrayOfInt[i], arrayOfParcelable[i]); 
    }
    
    public h(Parcelable param1Parcelable) {
      super(param1Parcelable);
    }
    
    public void writeToParcel(Parcel param1Parcel, int param1Int) {
      byte b;
      param1Parcel.writeParcelable(this.h, param1Int);
      SparseArray<Parcelable> sparseArray = this.j;
      int i = 0;
      if (sparseArray != null) {
        b = sparseArray.size();
      } else {
        b = 0;
      } 
      param1Parcel.writeInt(b);
      int[] arrayOfInt = new int[b];
      Parcelable[] arrayOfParcelable = new Parcelable[b];
      while (i < b) {
        arrayOfInt[i] = this.j.keyAt(i);
        arrayOfParcelable[i] = (Parcelable)this.j.valueAt(i);
        i++;
      } 
      param1Parcel.writeIntArray(arrayOfInt);
      param1Parcel.writeParcelableArray(arrayOfParcelable, param1Int);
    }
    
    public static final class a implements Parcelable.ClassLoaderCreator<h> {
      public Object createFromParcel(Parcel param2Parcel) {
        return new CoordinatorLayout.h(param2Parcel, null);
      }
      
      public Object createFromParcel(Parcel param2Parcel, ClassLoader param2ClassLoader) {
        return new CoordinatorLayout.h(param2Parcel, param2ClassLoader);
      }
      
      public Object[] newArray(int param2Int) {
        return (Object[])new CoordinatorLayout.h[param2Int];
      }
    }
  }
  
  public static final class a implements Parcelable.ClassLoaderCreator<h> {
    public Object createFromParcel(Parcel param1Parcel) {
      return new CoordinatorLayout.h(param1Parcel, null);
    }
    
    public Object createFromParcel(Parcel param1Parcel, ClassLoader param1ClassLoader) {
      return new CoordinatorLayout.h(param1Parcel, param1ClassLoader);
    }
    
    public Object[] newArray(int param1Int) {
      return (Object[])new CoordinatorLayout.h[param1Int];
    }
  }
  
  public static class i implements Comparator<View> {
    public int compare(Object param1Object1, Object param1Object2) {
      param1Object1 = param1Object1;
      param1Object2 = param1Object2;
      WeakHashMap weakHashMap = l.a;
      float f1 = param1Object1.getZ();
      float f2 = param1Object2.getZ();
      return (f1 > f2) ? -1 : ((f1 < f2) ? 1 : 0);
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Luxury Logo Maker_ Logo Design-dex2jar.jar!\androidx\coordinatorlayout\widget\CoordinatorLayout.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */