package androidx.viewpager2.adapter;

import androidx.lifecycle.e;
import androidx.lifecycle.g;
import androidx.lifecycle.i;

class FragmentStateAdapter$FragmentMaxLifecycleEnforcer$3 implements g {
  public void c(i parami, e.b paramb) {
    throw null;
  }
}


/* Location:              C:\soft\dex2jar-2.0\Luxury Logo Maker_ Logo Design-dex2jar.jar!\androidx\viewpager2\adapter\FragmentStateAdapter$FragmentMaxLifecycleEnforcer$3.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */