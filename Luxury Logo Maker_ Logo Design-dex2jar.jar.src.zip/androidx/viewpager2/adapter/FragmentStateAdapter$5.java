package androidx.viewpager2.adapter;

import androidx.lifecycle.e;
import androidx.lifecycle.g;
import androidx.lifecycle.i;

class FragmentStateAdapter$5 implements g {
  public void c(i parami, e.b paramb) {
    if (paramb != e.b.ON_DESTROY)
      return; 
    throw null;
  }
}


/* Location:              C:\soft\dex2jar-2.0\Luxury Logo Maker_ Logo Design-dex2jar.jar!\androidx\viewpager2\adapter\FragmentStateAdapter$5.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */