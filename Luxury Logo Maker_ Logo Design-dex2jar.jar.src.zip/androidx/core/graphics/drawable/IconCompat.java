package androidx.core.graphics.drawable;

import android.content.res.ColorStateList;
import android.content.res.Resources;
import android.graphics.Bitmap;
import android.graphics.BitmapShader;
import android.graphics.Canvas;
import android.graphics.Matrix;
import android.graphics.Paint;
import android.graphics.PorterDuff;
import android.graphics.Shader;
import android.graphics.drawable.Icon;
import android.net.Uri;
import android.os.Build;
import android.os.Parcelable;
import android.util.Log;
import androidx.versionedparcelable.CustomVersionedParcelable;
import java.lang.reflect.InvocationTargetException;

public class IconCompat extends CustomVersionedParcelable {
  public static final PorterDuff.Mode k = PorterDuff.Mode.SRC_IN;
  
  public int a = -1;
  
  public Object b;
  
  public byte[] c = null;
  
  public Parcelable d = null;
  
  public int e = 0;
  
  public int f = 0;
  
  public ColorStateList g = null;
  
  public PorterDuff.Mode h = k;
  
  public String i = null;
  
  public String j;
  
  public IconCompat() {}
  
  public IconCompat(int paramInt) {
    this.a = paramInt;
  }
  
  public static Bitmap a(Bitmap paramBitmap, boolean paramBoolean) {
    int i = (int)(Math.min(paramBitmap.getWidth(), paramBitmap.getHeight()) * 0.6666667F);
    Bitmap bitmap = Bitmap.createBitmap(i, i, Bitmap.Config.ARGB_8888);
    Canvas canvas = new Canvas(bitmap);
    Paint paint = new Paint(3);
    float f1 = i;
    float f2 = 0.5F * f1;
    float f3 = 0.9166667F * f2;
    if (paramBoolean) {
      float f = 0.010416667F * f1;
      paint.setColor(0);
      paint.setShadowLayer(f, 0.0F, f1 * 0.020833334F, 1023410176);
      canvas.drawCircle(f2, f2, f3, paint);
      paint.setShadowLayer(f, 0.0F, 0.0F, 503316480);
      canvas.drawCircle(f2, f2, f3, paint);
      paint.clearShadowLayer();
    } 
    paint.setColor(-16777216);
    Shader.TileMode tileMode = Shader.TileMode.CLAMP;
    BitmapShader bitmapShader = new BitmapShader(paramBitmap, tileMode, tileMode);
    Matrix matrix = new Matrix();
    matrix.setTranslate((-(paramBitmap.getWidth() - i) / 2), (-(paramBitmap.getHeight() - i) / 2));
    bitmapShader.setLocalMatrix(matrix);
    paint.setShader((Shader)bitmapShader);
    canvas.drawCircle(f2, f2, f3, paint);
    canvas.setBitmap(null);
    return bitmap;
  }
  
  public static IconCompat b(Resources paramResources, String paramString, int paramInt) {
    if (paramInt != 0) {
      IconCompat iconCompat = new IconCompat(2);
      iconCompat.e = paramInt;
      iconCompat.b = paramString;
      iconCompat.j = paramString;
      return iconCompat;
    } 
    throw new IllegalArgumentException("Drawable resource ID must not be 0");
  }
  
  public int c() {
    int i = this.a;
    if (i == -1) {
      int j = Build.VERSION.SDK_INT;
      if (j >= 23) {
        Icon icon = (Icon)this.b;
        if (j >= 28)
          return icon.getResId(); 
        try {
          return ((Integer)icon.getClass().getMethod("getResId", new Class[0]).invoke(icon, new Object[0])).intValue();
        } catch (IllegalAccessException illegalAccessException) {
        
        } catch (InvocationTargetException invocationTargetException) {
        
        } catch (NoSuchMethodException noSuchMethodException) {}
        Log.e("IconCompat", "Unable to get icon resource", noSuchMethodException);
        return 0;
      } 
    } 
    if (i == 2)
      return this.e; 
    StringBuilder stringBuilder = new StringBuilder();
    stringBuilder.append("called getResId() on ");
    stringBuilder.append(this);
    throw new IllegalStateException(stringBuilder.toString());
  }
  
  public Uri d() {
    int i = this.a;
    if (i == -1) {
      int j = Build.VERSION.SDK_INT;
      if (j >= 23) {
        Icon icon = (Icon)this.b;
        if (j >= 28)
          return icon.getUri(); 
        try {
          return (Uri)icon.getClass().getMethod("getUri", new Class[0]).invoke(icon, new Object[0]);
        } catch (IllegalAccessException illegalAccessException) {
        
        } catch (InvocationTargetException invocationTargetException) {
        
        } catch (NoSuchMethodException noSuchMethodException) {}
        Log.e("IconCompat", "Unable to get icon uri", noSuchMethodException);
        return null;
      } 
    } 
    if (i == 4 || i == 6)
      return Uri.parse((String)this.b); 
    StringBuilder stringBuilder = new StringBuilder();
    stringBuilder.append("called getUri() on ");
    stringBuilder.append(this);
    throw new IllegalStateException(stringBuilder.toString());
  }
  
  @Deprecated
  public Icon e() {
    // Byte code:
    //   0: aload_0
    //   1: getfield a : I
    //   4: istore_1
    //   5: aconst_null
    //   6: astore #4
    //   8: iload_1
    //   9: tableswitch default -> 56, -1 -> 419, 0 -> 56, 1 -> 362, 2 -> 185, 3 -> 163, 4 -> 149, 5 -> 112, 6 -> 66
    //   56: new java/lang/IllegalArgumentException
    //   59: dup
    //   60: ldc 'Unknown type'
    //   62: invokespecial <init> : (Ljava/lang/String;)V
    //   65: athrow
    //   66: getstatic android/os/Build$VERSION.SDK_INT : I
    //   69: bipush #30
    //   71: if_icmplt -> 85
    //   74: aload_0
    //   75: invokevirtual d : ()Landroid/net/Uri;
    //   78: invokestatic createWithAdaptiveBitmapContentUri : (Landroid/net/Uri;)Landroid/graphics/drawable/Icon;
    //   81: astore_3
    //   82: goto -> 375
    //   85: ldc 'Context is required to resolve the file uri of the icon: '
    //   87: invokestatic a : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   90: astore_3
    //   91: aload_3
    //   92: aload_0
    //   93: invokevirtual d : ()Landroid/net/Uri;
    //   96: invokevirtual append : (Ljava/lang/Object;)Ljava/lang/StringBuilder;
    //   99: pop
    //   100: new java/lang/IllegalArgumentException
    //   103: dup
    //   104: aload_3
    //   105: invokevirtual toString : ()Ljava/lang/String;
    //   108: invokespecial <init> : (Ljava/lang/String;)V
    //   111: athrow
    //   112: getstatic android/os/Build$VERSION.SDK_INT : I
    //   115: bipush #26
    //   117: if_icmplt -> 134
    //   120: aload_0
    //   121: getfield b : Ljava/lang/Object;
    //   124: checkcast android/graphics/Bitmap
    //   127: invokestatic createWithAdaptiveBitmap : (Landroid/graphics/Bitmap;)Landroid/graphics/drawable/Icon;
    //   130: astore_3
    //   131: goto -> 375
    //   134: aload_0
    //   135: getfield b : Ljava/lang/Object;
    //   138: checkcast android/graphics/Bitmap
    //   141: iconst_0
    //   142: invokestatic a : (Landroid/graphics/Bitmap;Z)Landroid/graphics/Bitmap;
    //   145: astore_3
    //   146: goto -> 370
    //   149: aload_0
    //   150: getfield b : Ljava/lang/Object;
    //   153: checkcast java/lang/String
    //   156: invokestatic createWithContentUri : (Ljava/lang/String;)Landroid/graphics/drawable/Icon;
    //   159: astore_3
    //   160: goto -> 375
    //   163: aload_0
    //   164: getfield b : Ljava/lang/Object;
    //   167: checkcast [B
    //   170: aload_0
    //   171: getfield e : I
    //   174: aload_0
    //   175: getfield f : I
    //   178: invokestatic createWithData : ([BII)Landroid/graphics/drawable/Icon;
    //   181: astore_3
    //   182: goto -> 375
    //   185: iload_1
    //   186: iconst_m1
    //   187: if_icmpne -> 276
    //   190: getstatic android/os/Build$VERSION.SDK_INT : I
    //   193: istore_2
    //   194: iload_2
    //   195: bipush #23
    //   197: if_icmplt -> 276
    //   200: aload_0
    //   201: getfield b : Ljava/lang/Object;
    //   204: checkcast android/graphics/drawable/Icon
    //   207: astore_3
    //   208: iload_2
    //   209: bipush #28
    //   211: if_icmplt -> 222
    //   214: aload_3
    //   215: invokevirtual getResPackage : ()Ljava/lang/String;
    //   218: astore_3
    //   219: goto -> 316
    //   222: aload_3
    //   223: invokevirtual getClass : ()Ljava/lang/Class;
    //   226: ldc_w 'getResPackage'
    //   229: iconst_0
    //   230: anewarray java/lang/Class
    //   233: invokevirtual getMethod : (Ljava/lang/String;[Ljava/lang/Class;)Ljava/lang/reflect/Method;
    //   236: aload_3
    //   237: iconst_0
    //   238: anewarray java/lang/Object
    //   241: invokevirtual invoke : (Ljava/lang/Object;[Ljava/lang/Object;)Ljava/lang/Object;
    //   244: checkcast java/lang/String
    //   247: astore_3
    //   248: goto -> 316
    //   251: astore_3
    //   252: goto -> 260
    //   255: astore_3
    //   256: goto -> 260
    //   259: astore_3
    //   260: ldc 'IconCompat'
    //   262: ldc_w 'Unable to get icon package'
    //   265: aload_3
    //   266: invokestatic e : (Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)I
    //   269: pop
    //   270: aload #4
    //   272: astore_3
    //   273: goto -> 316
    //   276: iload_1
    //   277: iconst_2
    //   278: if_icmpne -> 328
    //   281: aload_0
    //   282: getfield j : Ljava/lang/String;
    //   285: invokestatic isEmpty : (Ljava/lang/CharSequence;)Z
    //   288: ifeq -> 311
    //   291: aload_0
    //   292: getfield b : Ljava/lang/Object;
    //   295: checkcast java/lang/String
    //   298: ldc_w ':'
    //   301: iconst_m1
    //   302: invokevirtual split : (Ljava/lang/String;I)[Ljava/lang/String;
    //   305: iconst_0
    //   306: aaload
    //   307: astore_3
    //   308: goto -> 316
    //   311: aload_0
    //   312: getfield j : Ljava/lang/String;
    //   315: astore_3
    //   316: aload_3
    //   317: aload_0
    //   318: getfield e : I
    //   321: invokestatic createWithResource : (Ljava/lang/String;I)Landroid/graphics/drawable/Icon;
    //   324: astore_3
    //   325: goto -> 375
    //   328: new java/lang/StringBuilder
    //   331: dup
    //   332: invokespecial <init> : ()V
    //   335: astore_3
    //   336: aload_3
    //   337: ldc_w 'called getResPackage() on '
    //   340: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   343: pop
    //   344: aload_3
    //   345: aload_0
    //   346: invokevirtual append : (Ljava/lang/Object;)Ljava/lang/StringBuilder;
    //   349: pop
    //   350: new java/lang/IllegalStateException
    //   353: dup
    //   354: aload_3
    //   355: invokevirtual toString : ()Ljava/lang/String;
    //   358: invokespecial <init> : (Ljava/lang/String;)V
    //   361: athrow
    //   362: aload_0
    //   363: getfield b : Ljava/lang/Object;
    //   366: checkcast android/graphics/Bitmap
    //   369: astore_3
    //   370: aload_3
    //   371: invokestatic createWithBitmap : (Landroid/graphics/Bitmap;)Landroid/graphics/drawable/Icon;
    //   374: astore_3
    //   375: aload_0
    //   376: getfield g : Landroid/content/res/ColorStateList;
    //   379: astore #4
    //   381: aload #4
    //   383: ifnull -> 393
    //   386: aload_3
    //   387: aload #4
    //   389: invokevirtual setTintList : (Landroid/content/res/ColorStateList;)Landroid/graphics/drawable/Icon;
    //   392: pop
    //   393: aload_0
    //   394: getfield h : Landroid/graphics/PorterDuff$Mode;
    //   397: astore #5
    //   399: aload_3
    //   400: astore #4
    //   402: aload #5
    //   404: getstatic androidx/core/graphics/drawable/IconCompat.k : Landroid/graphics/PorterDuff$Mode;
    //   407: if_acmpeq -> 428
    //   410: aload_3
    //   411: aload #5
    //   413: invokevirtual setTintMode : (Landroid/graphics/PorterDuff$Mode;)Landroid/graphics/drawable/Icon;
    //   416: pop
    //   417: aload_3
    //   418: areturn
    //   419: aload_0
    //   420: getfield b : Ljava/lang/Object;
    //   423: checkcast android/graphics/drawable/Icon
    //   426: astore #4
    //   428: aload #4
    //   430: areturn
    // Exception table:
    //   from	to	target	type
    //   222	248	259	java/lang/IllegalAccessException
    //   222	248	255	java/lang/reflect/InvocationTargetException
    //   222	248	251	java/lang/NoSuchMethodException
  }
  
  public String toString() {
    int i;
    String str;
    if (this.a == -1)
      return String.valueOf(this.b); 
    StringBuilder stringBuilder = new StringBuilder("Icon(typ=");
    switch (this.a) {
      default:
        str = "UNKNOWN";
        break;
      case 6:
        str = "URI_MASKABLE";
        break;
      case 5:
        str = "BITMAP_MASKABLE";
        break;
      case 4:
        str = "URI";
        break;
      case 3:
        str = "DATA";
        break;
      case 2:
        str = "RESOURCE";
        break;
      case 1:
        str = "BITMAP";
        break;
    } 
    stringBuilder.append(str);
    switch (this.a) {
      case 4:
      case 6:
        stringBuilder.append(" uri=");
        stringBuilder.append(this.b);
        break;
      case 3:
        stringBuilder.append(" len=");
        stringBuilder.append(this.e);
        if (this.f != 0) {
          stringBuilder.append(" off=");
          i = this.f;
        } else {
          break;
        } 
        stringBuilder.append(i);
        break;
      case 2:
        stringBuilder.append(" pkg=");
        stringBuilder.append(this.j);
        stringBuilder.append(" id=");
        stringBuilder.append(String.format("0x%08x", new Object[] { Integer.valueOf(c()) }));
        break;
      case 1:
      case 5:
        stringBuilder.append(" size=");
        stringBuilder.append(((Bitmap)this.b).getWidth());
        stringBuilder.append("x");
        i = ((Bitmap)this.b).getHeight();
        stringBuilder.append(i);
        break;
    } 
    if (this.g != null) {
      stringBuilder.append(" tint=");
      stringBuilder.append(this.g);
    } 
    if (this.h != k) {
      stringBuilder.append(" mode=");
      stringBuilder.append(this.h);
    } 
    stringBuilder.append(")");
    return stringBuilder.toString();
  }
}


/* Location:              C:\soft\dex2jar-2.0\Luxury Logo Maker_ Logo Design-dex2jar.jar!\androidx\core\graphics\drawable\IconCompat.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */