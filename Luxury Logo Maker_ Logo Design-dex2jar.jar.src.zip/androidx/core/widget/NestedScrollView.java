package androidx.core.widget;

import android.content.Context;
import android.content.res.TypedArray;
import android.graphics.Canvas;
import android.graphics.Rect;
import android.os.Bundle;
import android.os.Parcel;
import android.os.Parcelable;
import android.util.AttributeSet;
import android.util.TypedValue;
import android.view.FocusFinder;
import android.view.KeyEvent;
import android.view.MotionEvent;
import android.view.VelocityTracker;
import android.view.View;
import android.view.ViewConfiguration;
import android.view.ViewGroup;
import android.view.ViewParent;
import android.view.accessibility.AccessibilityEvent;
import android.view.animation.AnimationUtils;
import android.widget.EdgeEffect;
import android.widget.FrameLayout;
import android.widget.OverScroller;
import android.widget.ScrollView;
import androidx.appcompat.app.AlertController;
import java.util.WeakHashMap;
import k0.e;
import k0.f;
import k0.h;
import k0.i;
import k0.l;

public class NestedScrollView extends FrameLayout implements h, e {
  public static final a H = new a();
  
  public static final int[] I = new int[] { 16843130 };
  
  public int A;
  
  public int B;
  
  public c C;
  
  public final i D;
  
  public final f E;
  
  public float F;
  
  public b G;
  
  public long h;
  
  public final Rect i = new Rect();
  
  public OverScroller j = new OverScroller(getContext());
  
  public EdgeEffect k;
  
  public EdgeEffect l;
  
  public int m;
  
  public boolean n = true;
  
  public boolean o = false;
  
  public View p = null;
  
  public boolean q = false;
  
  public VelocityTracker r;
  
  public boolean s;
  
  public boolean t = true;
  
  public int u;
  
  public int v;
  
  public int w;
  
  public int x = -1;
  
  public final int[] y = new int[2];
  
  public final int[] z = new int[2];
  
  public NestedScrollView(Context paramContext, AttributeSet paramAttributeSet) {
    super(paramContext, paramAttributeSet, 2130969205);
    setFocusable(true);
    setDescendantFocusability(262144);
    setWillNotDraw(false);
    ViewConfiguration viewConfiguration = ViewConfiguration.get(getContext());
    this.u = viewConfiguration.getScaledTouchSlop();
    this.v = viewConfiguration.getScaledMinimumFlingVelocity();
    this.w = viewConfiguration.getScaledMaximumFlingVelocity();
    TypedArray typedArray = paramContext.obtainStyledAttributes(paramAttributeSet, I, 2130969205, 0);
    setFillViewport(typedArray.getBoolean(0, false));
    typedArray.recycle();
    this.D = new i();
    this.E = new f((View)this);
    setNestedScrollingEnabled(true);
    l.s((View)this, H);
  }
  
  public static int c(int paramInt1, int paramInt2, int paramInt3) {
    return (paramInt2 >= paramInt3 || paramInt1 < 0) ? 0 : ((paramInt2 + paramInt1 > paramInt3) ? (paramInt3 - paramInt2) : paramInt1);
  }
  
  private float getVerticalScrollFactorCompat() {
    if (this.F == 0.0F) {
      TypedValue typedValue = new TypedValue();
      Context context = getContext();
      if (context.getTheme().resolveAttribute(16842829, typedValue, true)) {
        this.F = typedValue.getDimension(context.getResources().getDisplayMetrics());
      } else {
        throw new IllegalStateException("Expected theme to define listPreferredItemHeight.");
      } 
    } 
    return this.F;
  }
  
  public static boolean s(View paramView1, View paramView2) {
    if (paramView1 == paramView2)
      return true; 
    ViewParent viewParent = paramView1.getParent();
    return (viewParent instanceof ViewGroup && s((View)viewParent, paramView2));
  }
  
  public final void A(View paramView) {
    paramView.getDrawingRect(this.i);
    offsetDescendantRectToMyCoords(paramView, this.i);
    int j = d(this.i);
    if (j != 0)
      scrollBy(0, j); 
  }
  
  public final void B(int paramInt1, int paramInt2, int paramInt3, boolean paramBoolean) {
    if (getChildCount() == 0)
      return; 
    if (AnimationUtils.currentAnimationTimeMillis() - this.h > 250L) {
      View view = getChildAt(0);
      FrameLayout.LayoutParams layoutParams = (FrameLayout.LayoutParams)view.getLayoutParams();
      int j = view.getHeight();
      int k = layoutParams.topMargin;
      int m = layoutParams.bottomMargin;
      int n = getHeight();
      int i1 = getPaddingTop();
      int i2 = getPaddingBottom();
      paramInt1 = getScrollY();
      paramInt2 = Math.max(0, Math.min(paramInt2 + paramInt1, Math.max(0, j + k + m - n - i1 - i2)));
      this.j.startScroll(getScrollX(), paramInt1, 0, paramInt2 - paramInt1, paramInt3);
      y(paramBoolean);
    } else {
      if (!this.j.isFinished())
        a(); 
      scrollBy(paramInt1, paramInt2);
    } 
    this.h = AnimationUtils.currentAnimationTimeMillis();
  }
  
  public boolean C(int paramInt1, int paramInt2) {
    return this.E.i(paramInt1, paramInt2);
  }
  
  public final void a() {
    this.j.abortAnimation();
    this.E.j(1);
  }
  
  public void addView(View paramView) {
    if (getChildCount() <= 0) {
      super.addView(paramView);
      return;
    } 
    throw new IllegalStateException("ScrollView can host only one direct child");
  }
  
  public void addView(View paramView, int paramInt) {
    if (getChildCount() <= 0) {
      super.addView(paramView, paramInt);
      return;
    } 
    throw new IllegalStateException("ScrollView can host only one direct child");
  }
  
  public void addView(View paramView, int paramInt, ViewGroup.LayoutParams paramLayoutParams) {
    if (getChildCount() <= 0) {
      super.addView(paramView, paramInt, paramLayoutParams);
      return;
    } 
    throw new IllegalStateException("ScrollView can host only one direct child");
  }
  
  public void addView(View paramView, ViewGroup.LayoutParams paramLayoutParams) {
    if (getChildCount() <= 0) {
      super.addView(paramView, paramLayoutParams);
      return;
    } 
    throw new IllegalStateException("ScrollView can host only one direct child");
  }
  
  public boolean b(int paramInt) {
    View view2 = findFocus();
    View view1 = view2;
    if (view2 == this)
      view1 = null; 
    view2 = FocusFinder.getInstance().findNextFocus((ViewGroup)this, view1, paramInt);
    int j = getMaxScrollAmount();
    if (view2 != null && t(view2, j, getHeight())) {
      view2.getDrawingRect(this.i);
      offsetDescendantRectToMyCoords(view2, this.i);
      f(d(this.i));
      view2.requestFocus(paramInt);
    } else {
      int k;
      if (paramInt == 33 && getScrollY() < j) {
        k = getScrollY();
      } else {
        k = j;
        if (paramInt == 130) {
          k = j;
          if (getChildCount() > 0) {
            view2 = getChildAt(0);
            FrameLayout.LayoutParams layoutParams = (FrameLayout.LayoutParams)view2.getLayoutParams();
            k = view2.getBottom();
            int m = layoutParams.bottomMargin;
            int n = getScrollY();
            k = Math.min(k + m - getHeight() + n - getPaddingBottom(), j);
          } 
        } 
      } 
      if (k == 0)
        return false; 
      if (paramInt != 130)
        k = -k; 
      f(k);
    } 
    if (view1 != null && view1.isFocused() && (t(view1, 0, getHeight()) ^ true) != 0) {
      paramInt = getDescendantFocusability();
      setDescendantFocusability(131072);
      requestFocus();
      setDescendantFocusability(paramInt);
    } 
    return true;
  }
  
  public int computeHorizontalScrollExtent() {
    return super.computeHorizontalScrollExtent();
  }
  
  public int computeHorizontalScrollOffset() {
    return super.computeHorizontalScrollOffset();
  }
  
  public int computeHorizontalScrollRange() {
    return super.computeHorizontalScrollRange();
  }
  
  public void computeScroll() {
    // Byte code:
    //   0: aload_0
    //   1: getfield j : Landroid/widget/OverScroller;
    //   4: invokevirtual isFinished : ()Z
    //   7: ifeq -> 11
    //   10: return
    //   11: aload_0
    //   12: getfield j : Landroid/widget/OverScroller;
    //   15: invokevirtual computeScrollOffset : ()Z
    //   18: pop
    //   19: aload_0
    //   20: getfield j : Landroid/widget/OverScroller;
    //   23: invokevirtual getCurrY : ()I
    //   26: istore_2
    //   27: iload_2
    //   28: aload_0
    //   29: getfield B : I
    //   32: isub
    //   33: istore_1
    //   34: aload_0
    //   35: iload_2
    //   36: putfield B : I
    //   39: aload_0
    //   40: getfield z : [I
    //   43: astore #6
    //   45: iconst_0
    //   46: istore_3
    //   47: aload #6
    //   49: iconst_1
    //   50: iconst_0
    //   51: iastore
    //   52: aload_0
    //   53: iconst_0
    //   54: iload_1
    //   55: aload #6
    //   57: aconst_null
    //   58: iconst_1
    //   59: invokevirtual e : (II[I[II)Z
    //   62: pop
    //   63: iload_1
    //   64: aload_0
    //   65: getfield z : [I
    //   68: iconst_1
    //   69: iaload
    //   70: isub
    //   71: istore_2
    //   72: aload_0
    //   73: invokevirtual getScrollRange : ()I
    //   76: istore #4
    //   78: iload_2
    //   79: istore_1
    //   80: iload_2
    //   81: ifeq -> 160
    //   84: aload_0
    //   85: invokevirtual getScrollY : ()I
    //   88: istore_1
    //   89: aload_0
    //   90: iconst_0
    //   91: iload_2
    //   92: aload_0
    //   93: invokevirtual getScrollX : ()I
    //   96: iload_1
    //   97: iconst_0
    //   98: iload #4
    //   100: iconst_0
    //   101: iconst_0
    //   102: invokevirtual w : (IIIIIIII)Z
    //   105: pop
    //   106: aload_0
    //   107: invokevirtual getScrollY : ()I
    //   110: iload_1
    //   111: isub
    //   112: istore_1
    //   113: iload_2
    //   114: iload_1
    //   115: isub
    //   116: istore_2
    //   117: aload_0
    //   118: getfield z : [I
    //   121: astore #6
    //   123: aload #6
    //   125: iconst_1
    //   126: iconst_0
    //   127: iastore
    //   128: aload_0
    //   129: getfield y : [I
    //   132: astore #7
    //   134: aload_0
    //   135: getfield E : Lk0/f;
    //   138: iconst_0
    //   139: iload_1
    //   140: iconst_0
    //   141: iload_2
    //   142: aload #7
    //   144: iconst_1
    //   145: aload #6
    //   147: invokevirtual f : (IIII[II[I)Z
    //   150: pop
    //   151: iload_2
    //   152: aload_0
    //   153: getfield z : [I
    //   156: iconst_1
    //   157: iaload
    //   158: isub
    //   159: istore_1
    //   160: iload_1
    //   161: ifeq -> 256
    //   164: aload_0
    //   165: invokevirtual getOverScrollMode : ()I
    //   168: istore #5
    //   170: iload #5
    //   172: ifeq -> 190
    //   175: iload_3
    //   176: istore_2
    //   177: iload #5
    //   179: iconst_1
    //   180: if_icmpne -> 192
    //   183: iload_3
    //   184: istore_2
    //   185: iload #4
    //   187: ifle -> 192
    //   190: iconst_1
    //   191: istore_2
    //   192: iload_2
    //   193: ifeq -> 252
    //   196: aload_0
    //   197: invokevirtual k : ()V
    //   200: iload_1
    //   201: ifge -> 223
    //   204: aload_0
    //   205: getfield k : Landroid/widget/EdgeEffect;
    //   208: invokevirtual isFinished : ()Z
    //   211: ifeq -> 252
    //   214: aload_0
    //   215: getfield k : Landroid/widget/EdgeEffect;
    //   218: astore #6
    //   220: goto -> 239
    //   223: aload_0
    //   224: getfield l : Landroid/widget/EdgeEffect;
    //   227: invokevirtual isFinished : ()Z
    //   230: ifeq -> 252
    //   233: aload_0
    //   234: getfield l : Landroid/widget/EdgeEffect;
    //   237: astore #6
    //   239: aload #6
    //   241: aload_0
    //   242: getfield j : Landroid/widget/OverScroller;
    //   245: invokevirtual getCurrVelocity : ()F
    //   248: f2i
    //   249: invokevirtual onAbsorb : (I)V
    //   252: aload_0
    //   253: invokevirtual a : ()V
    //   256: aload_0
    //   257: getfield j : Landroid/widget/OverScroller;
    //   260: invokevirtual isFinished : ()Z
    //   263: ifne -> 276
    //   266: getstatic k0/l.a : Ljava/util/WeakHashMap;
    //   269: astore #6
    //   271: aload_0
    //   272: invokevirtual postInvalidateOnAnimation : ()V
    //   275: return
    //   276: aload_0
    //   277: getfield E : Lk0/f;
    //   280: iconst_1
    //   281: invokevirtual j : (I)V
    //   284: return
  }
  
  public int computeVerticalScrollExtent() {
    return super.computeVerticalScrollExtent();
  }
  
  public int computeVerticalScrollOffset() {
    return Math.max(0, super.computeVerticalScrollOffset());
  }
  
  public int computeVerticalScrollRange() {
    int k = getChildCount();
    int j = getHeight() - getPaddingBottom() - getPaddingTop();
    if (k == 0)
      return j; 
    View view = getChildAt(0);
    FrameLayout.LayoutParams layoutParams = (FrameLayout.LayoutParams)view.getLayoutParams();
    k = view.getBottom() + layoutParams.bottomMargin;
    int m = getScrollY();
    int n = Math.max(0, k - j);
    if (m < 0)
      return k - m; 
    j = k;
    if (m > n)
      j = k + m - n; 
    return j;
  }
  
  public int d(Rect paramRect) {
    int j = getChildCount();
    boolean bool = false;
    if (j == 0)
      return 0; 
    int n = getHeight();
    int k = getScrollY();
    int m = k + n;
    int i1 = getVerticalFadingEdgeLength();
    j = k;
    if (paramRect.top > 0)
      j = k + i1; 
    View view = getChildAt(0);
    FrameLayout.LayoutParams layoutParams = (FrameLayout.LayoutParams)view.getLayoutParams();
    if (paramRect.bottom < view.getHeight() + layoutParams.topMargin + layoutParams.bottomMargin) {
      k = m - i1;
    } else {
      k = m;
    } 
    i1 = paramRect.bottom;
    if (i1 > k && paramRect.top > j) {
      if (paramRect.height() > n) {
        j = paramRect.top - j;
      } else {
        j = paramRect.bottom - k;
      } 
      return Math.min(j + 0, view.getBottom() + layoutParams.bottomMargin - m);
    } 
    m = bool;
    if (paramRect.top < j) {
      m = bool;
      if (i1 < k) {
        if (paramRect.height() > n) {
          j = 0 - k - paramRect.bottom;
        } else {
          j = 0 - j - paramRect.top;
        } 
        m = Math.max(j, -getScrollY());
      } 
    } 
    return m;
  }
  
  public boolean dispatchKeyEvent(KeyEvent paramKeyEvent) {
    return (super.dispatchKeyEvent(paramKeyEvent) || l(paramKeyEvent));
  }
  
  public boolean dispatchNestedFling(float paramFloat1, float paramFloat2, boolean paramBoolean) {
    return this.E.a(paramFloat1, paramFloat2, paramBoolean);
  }
  
  public boolean dispatchNestedPreFling(float paramFloat1, float paramFloat2) {
    return this.E.b(paramFloat1, paramFloat2);
  }
  
  public boolean dispatchNestedPreScroll(int paramInt1, int paramInt2, int[] paramArrayOfint1, int[] paramArrayOfint2) {
    return e(paramInt1, paramInt2, paramArrayOfint1, paramArrayOfint2, 0);
  }
  
  public boolean dispatchNestedScroll(int paramInt1, int paramInt2, int paramInt3, int paramInt4, int[] paramArrayOfint) {
    return this.E.e(paramInt1, paramInt2, paramInt3, paramInt4, paramArrayOfint);
  }
  
  public void draw(Canvas paramCanvas) {
    super.draw(paramCanvas);
    if (this.k != null) {
      int j = getScrollY();
      boolean bool = this.k.isFinished();
      byte b1 = 0;
      if (!bool) {
        boolean bool1;
        int i3 = paramCanvas.save();
        int k = getWidth();
        int i2 = getHeight();
        int i1 = Math.min(0, j);
        if (getClipToPadding()) {
          bool1 = getPaddingLeft();
          k -= getPaddingRight() + bool1;
          bool1 = getPaddingLeft() + 0;
        } else {
          bool1 = false;
        } 
        int n = i2;
        int m = i1;
        if (getClipToPadding()) {
          m = getPaddingTop();
          n = i2 - getPaddingBottom() + m;
          m = i1 + getPaddingTop();
        } 
        paramCanvas.translate(bool1, m);
        this.k.setSize(k, n);
        if (this.k.draw(paramCanvas)) {
          WeakHashMap weakHashMap = l.a;
          postInvalidateOnAnimation();
        } 
        paramCanvas.restoreToCount(i3);
      } 
      if (!this.l.isFinished()) {
        int i4 = paramCanvas.save();
        int n = getWidth();
        int i2 = getHeight();
        int i3 = Math.max(getScrollRange(), j) + i2;
        int m = b1;
        int k = n;
        if (getClipToPadding()) {
          k = getPaddingLeft();
          k = n - getPaddingRight() + k;
          m = 0 + getPaddingLeft();
        } 
        int i1 = i3;
        n = i2;
        if (getClipToPadding()) {
          n = getPaddingTop();
          n = i2 - getPaddingBottom() + n;
          i1 = i3 - getPaddingBottom();
        } 
        paramCanvas.translate((m - k), i1);
        paramCanvas.rotate(180.0F, k, 0.0F);
        this.l.setSize(k, n);
        if (this.l.draw(paramCanvas)) {
          WeakHashMap weakHashMap = l.a;
          postInvalidateOnAnimation();
        } 
        paramCanvas.restoreToCount(i4);
      } 
    } 
  }
  
  public boolean e(int paramInt1, int paramInt2, int[] paramArrayOfint1, int[] paramArrayOfint2, int paramInt3) {
    return this.E.c(paramInt1, paramInt2, paramArrayOfint1, paramArrayOfint2, paramInt3);
  }
  
  public final void f(int paramInt) {
    if (paramInt != 0) {
      if (this.t) {
        B(0, paramInt, 250, false);
        return;
      } 
      scrollBy(0, paramInt);
    } 
  }
  
  public final void g() {
    this.q = false;
    x();
    this.E.j(0);
    EdgeEffect edgeEffect = this.k;
    if (edgeEffect != null) {
      edgeEffect.onRelease();
      this.l.onRelease();
    } 
  }
  
  public float getBottomFadingEdgeStrength() {
    if (getChildCount() == 0)
      return 0.0F; 
    View view = getChildAt(0);
    FrameLayout.LayoutParams layoutParams = (FrameLayout.LayoutParams)view.getLayoutParams();
    int j = getVerticalFadingEdgeLength();
    int k = getHeight();
    int m = getPaddingBottom();
    k = view.getBottom() + layoutParams.bottomMargin - getScrollY() - k - m;
    return (k < j) ? (k / j) : 1.0F;
  }
  
  public int getMaxScrollAmount() {
    return (int)(getHeight() * 0.5F);
  }
  
  public int getNestedScrollAxes() {
    return this.D.a();
  }
  
  public int getScrollRange() {
    int k = getChildCount();
    int j = 0;
    if (k > 0) {
      View view = getChildAt(0);
      FrameLayout.LayoutParams layoutParams = (FrameLayout.LayoutParams)view.getLayoutParams();
      j = Math.max(0, view.getHeight() + layoutParams.topMargin + layoutParams.bottomMargin - getHeight() - getPaddingTop() - getPaddingBottom());
    } 
    return j;
  }
  
  public float getTopFadingEdgeStrength() {
    if (getChildCount() == 0)
      return 0.0F; 
    int j = getVerticalFadingEdgeLength();
    int k = getScrollY();
    return (k < j) ? (k / j) : 1.0F;
  }
  
  public void h(View paramView1, View paramView2, int paramInt1, int paramInt2) {
    i i1 = this.D;
    if (paramInt2 == 1) {
      i1.b = paramInt1;
    } else {
      i1.a = paramInt1;
    } 
    C(2, paramInt2);
  }
  
  public boolean hasNestedScrollingParent() {
    return r(0);
  }
  
  public void i(View paramView, int paramInt) {
    i i1 = this.D;
    if (paramInt == 1) {
      i1.b = 0;
    } else {
      i1.a = 0;
    } 
    this.E.j(paramInt);
  }
  
  public boolean isNestedScrollingEnabled() {
    return this.E.d;
  }
  
  public void j(View paramView, int paramInt1, int paramInt2, int[] paramArrayOfint, int paramInt3) {
    e(paramInt1, paramInt2, paramArrayOfint, null, paramInt3);
  }
  
  public final void k() {
    if (getOverScrollMode() != 2) {
      if (this.k == null) {
        Context context = getContext();
        this.k = new EdgeEffect(context);
        this.l = new EdgeEffect(context);
        return;
      } 
    } else {
      this.k = null;
      this.l = null;
    } 
  }
  
  public boolean l(KeyEvent paramKeyEvent) {
    // Byte code:
    //   0: aload_0
    //   1: getfield i : Landroid/graphics/Rect;
    //   4: invokevirtual setEmpty : ()V
    //   7: aload_0
    //   8: invokevirtual getChildCount : ()I
    //   11: istore_2
    //   12: iconst_0
    //   13: istore #6
    //   15: iload_2
    //   16: ifle -> 75
    //   19: aload_0
    //   20: iconst_0
    //   21: invokevirtual getChildAt : (I)Landroid/view/View;
    //   24: astore #7
    //   26: aload #7
    //   28: invokevirtual getLayoutParams : ()Landroid/view/ViewGroup$LayoutParams;
    //   31: checkcast android/widget/FrameLayout$LayoutParams
    //   34: astore #8
    //   36: aload #7
    //   38: invokevirtual getHeight : ()I
    //   41: aload #8
    //   43: getfield topMargin : I
    //   46: iadd
    //   47: aload #8
    //   49: getfield bottomMargin : I
    //   52: iadd
    //   53: aload_0
    //   54: invokevirtual getHeight : ()I
    //   57: aload_0
    //   58: invokevirtual getPaddingTop : ()I
    //   61: isub
    //   62: aload_0
    //   63: invokevirtual getPaddingBottom : ()I
    //   66: isub
    //   67: if_icmple -> 75
    //   70: iconst_1
    //   71: istore_2
    //   72: goto -> 77
    //   75: iconst_0
    //   76: istore_2
    //   77: iload_2
    //   78: ifne -> 150
    //   81: aload_0
    //   82: invokevirtual isFocused : ()Z
    //   85: ifeq -> 148
    //   88: aload_1
    //   89: invokevirtual getKeyCode : ()I
    //   92: iconst_4
    //   93: if_icmpeq -> 148
    //   96: aload_0
    //   97: invokevirtual findFocus : ()Landroid/view/View;
    //   100: astore #7
    //   102: aload #7
    //   104: astore_1
    //   105: aload #7
    //   107: aload_0
    //   108: if_acmpne -> 113
    //   111: aconst_null
    //   112: astore_1
    //   113: invokestatic getInstance : ()Landroid/view/FocusFinder;
    //   116: aload_0
    //   117: aload_1
    //   118: sipush #130
    //   121: invokevirtual findNextFocus : (Landroid/view/ViewGroup;Landroid/view/View;I)Landroid/view/View;
    //   124: astore_1
    //   125: aload_1
    //   126: ifnull -> 146
    //   129: aload_1
    //   130: aload_0
    //   131: if_acmpeq -> 146
    //   134: aload_1
    //   135: sipush #130
    //   138: invokevirtual requestFocus : (I)Z
    //   141: ifeq -> 146
    //   144: iconst_1
    //   145: ireturn
    //   146: iconst_0
    //   147: ireturn
    //   148: iconst_0
    //   149: ireturn
    //   150: aload_1
    //   151: invokevirtual getAction : ()I
    //   154: ifne -> 420
    //   157: aload_1
    //   158: invokevirtual getKeyCode : ()I
    //   161: istore_3
    //   162: bipush #33
    //   164: istore_2
    //   165: iload_3
    //   166: bipush #19
    //   168: if_icmpeq -> 398
    //   171: iload_3
    //   172: bipush #20
    //   174: if_icmpeq -> 375
    //   177: iload_3
    //   178: bipush #62
    //   180: if_icmpeq -> 185
    //   183: iconst_0
    //   184: ireturn
    //   185: aload_1
    //   186: invokevirtual isShiftPressed : ()Z
    //   189: ifeq -> 195
    //   192: goto -> 199
    //   195: sipush #130
    //   198: istore_2
    //   199: iload_2
    //   200: sipush #130
    //   203: if_icmpne -> 211
    //   206: iconst_1
    //   207: istore_3
    //   208: goto -> 213
    //   211: iconst_0
    //   212: istore_3
    //   213: aload_0
    //   214: invokevirtual getHeight : ()I
    //   217: istore #4
    //   219: iload_3
    //   220: ifeq -> 309
    //   223: aload_0
    //   224: getfield i : Landroid/graphics/Rect;
    //   227: aload_0
    //   228: invokevirtual getScrollY : ()I
    //   231: iload #4
    //   233: iadd
    //   234: putfield top : I
    //   237: aload_0
    //   238: invokevirtual getChildCount : ()I
    //   241: istore_3
    //   242: iload_3
    //   243: ifle -> 342
    //   246: aload_0
    //   247: iload_3
    //   248: iconst_1
    //   249: isub
    //   250: invokevirtual getChildAt : (I)Landroid/view/View;
    //   253: astore_1
    //   254: aload_1
    //   255: invokevirtual getLayoutParams : ()Landroid/view/ViewGroup$LayoutParams;
    //   258: checkcast android/widget/FrameLayout$LayoutParams
    //   261: astore #7
    //   263: aload_1
    //   264: invokevirtual getBottom : ()I
    //   267: istore_3
    //   268: aload #7
    //   270: getfield bottomMargin : I
    //   273: istore #5
    //   275: aload_0
    //   276: invokevirtual getPaddingBottom : ()I
    //   279: iload_3
    //   280: iload #5
    //   282: iadd
    //   283: iadd
    //   284: istore_3
    //   285: aload_0
    //   286: getfield i : Landroid/graphics/Rect;
    //   289: astore_1
    //   290: aload_1
    //   291: getfield top : I
    //   294: iload #4
    //   296: iadd
    //   297: iload_3
    //   298: if_icmple -> 342
    //   301: iload_3
    //   302: iload #4
    //   304: isub
    //   305: istore_3
    //   306: goto -> 337
    //   309: aload_0
    //   310: getfield i : Landroid/graphics/Rect;
    //   313: aload_0
    //   314: invokevirtual getScrollY : ()I
    //   317: iload #4
    //   319: isub
    //   320: putfield top : I
    //   323: aload_0
    //   324: getfield i : Landroid/graphics/Rect;
    //   327: astore_1
    //   328: aload_1
    //   329: getfield top : I
    //   332: ifge -> 342
    //   335: iconst_0
    //   336: istore_3
    //   337: aload_1
    //   338: iload_3
    //   339: putfield top : I
    //   342: aload_0
    //   343: getfield i : Landroid/graphics/Rect;
    //   346: astore_1
    //   347: aload_1
    //   348: getfield top : I
    //   351: istore_3
    //   352: iload #4
    //   354: iload_3
    //   355: iadd
    //   356: istore #4
    //   358: aload_1
    //   359: iload #4
    //   361: putfield bottom : I
    //   364: aload_0
    //   365: iload_2
    //   366: iload_3
    //   367: iload #4
    //   369: invokevirtual z : (III)Z
    //   372: pop
    //   373: iconst_0
    //   374: ireturn
    //   375: aload_1
    //   376: invokevirtual isAltPressed : ()Z
    //   379: ifne -> 390
    //   382: aload_0
    //   383: sipush #130
    //   386: invokevirtual b : (I)Z
    //   389: ireturn
    //   390: aload_0
    //   391: sipush #130
    //   394: invokevirtual q : (I)Z
    //   397: ireturn
    //   398: aload_1
    //   399: invokevirtual isAltPressed : ()Z
    //   402: ifne -> 412
    //   405: aload_0
    //   406: bipush #33
    //   408: invokevirtual b : (I)Z
    //   411: ireturn
    //   412: aload_0
    //   413: bipush #33
    //   415: invokevirtual q : (I)Z
    //   418: istore #6
    //   420: iload #6
    //   422: ireturn
  }
  
  public void m(View paramView, int paramInt1, int paramInt2, int paramInt3, int paramInt4, int paramInt5, int[] paramArrayOfint) {
    u(paramInt4, paramInt5, paramArrayOfint);
  }
  
  public void measureChild(View paramView, int paramInt1, int paramInt2) {
    ViewGroup.LayoutParams layoutParams = paramView.getLayoutParams();
    paramInt2 = getPaddingLeft();
    paramView.measure(FrameLayout.getChildMeasureSpec(paramInt1, getPaddingRight() + paramInt2, layoutParams.width), View.MeasureSpec.makeMeasureSpec(0, 0));
  }
  
  public void measureChildWithMargins(View paramView, int paramInt1, int paramInt2, int paramInt3, int paramInt4) {
    ViewGroup.MarginLayoutParams marginLayoutParams = (ViewGroup.MarginLayoutParams)paramView.getLayoutParams();
    paramInt3 = getPaddingLeft();
    paramView.measure(FrameLayout.getChildMeasureSpec(paramInt1, getPaddingRight() + paramInt3 + marginLayoutParams.leftMargin + marginLayoutParams.rightMargin + paramInt2, marginLayoutParams.width), View.MeasureSpec.makeMeasureSpec(marginLayoutParams.topMargin + marginLayoutParams.bottomMargin, 0));
  }
  
  public void n(View paramView, int paramInt1, int paramInt2, int paramInt3, int paramInt4, int paramInt5) {
    u(paramInt4, paramInt5, null);
  }
  
  public boolean o(View paramView1, View paramView2, int paramInt1, int paramInt2) {
    return ((paramInt1 & 0x2) != 0);
  }
  
  public void onAttachedToWindow() {
    super.onAttachedToWindow();
    this.o = false;
  }
  
  public boolean onGenericMotionEvent(MotionEvent paramMotionEvent) {
    if ((paramMotionEvent.getSource() & 0x2) != 0) {
      if (paramMotionEvent.getAction() != 8)
        return false; 
      if (!this.q) {
        float f1 = paramMotionEvent.getAxisValue(9);
        if (f1 != 0.0F) {
          int k = (int)(f1 * getVerticalScrollFactorCompat());
          int j = getScrollRange();
          int m = getScrollY();
          k = m - k;
          if (k < 0) {
            j = 0;
          } else if (k <= j) {
            j = k;
          } 
          if (j != m) {
            super.scrollTo(getScrollX(), j);
            return true;
          } 
        } 
      } 
    } 
    return false;
  }
  
  public boolean onInterceptTouchEvent(MotionEvent paramMotionEvent) {
    // Byte code:
    //   0: aload_1
    //   1: invokevirtual getAction : ()I
    //   4: istore_2
    //   5: iload_2
    //   6: iconst_2
    //   7: if_icmpne -> 19
    //   10: aload_0
    //   11: getfield q : Z
    //   14: ifeq -> 19
    //   17: iconst_1
    //   18: ireturn
    //   19: iload_2
    //   20: sipush #255
    //   23: iand
    //   24: istore_2
    //   25: iload_2
    //   26: ifeq -> 275
    //   29: iload_2
    //   30: iconst_1
    //   31: if_icmpeq -> 217
    //   34: iload_2
    //   35: iconst_2
    //   36: if_icmpeq -> 61
    //   39: iload_2
    //   40: iconst_3
    //   41: if_icmpeq -> 217
    //   44: iload_2
    //   45: bipush #6
    //   47: if_icmpeq -> 53
    //   50: goto -> 448
    //   53: aload_0
    //   54: aload_1
    //   55: invokevirtual v : (Landroid/view/MotionEvent;)V
    //   58: goto -> 448
    //   61: aload_0
    //   62: getfield x : I
    //   65: istore_2
    //   66: iload_2
    //   67: iconst_m1
    //   68: if_icmpne -> 74
    //   71: goto -> 448
    //   74: aload_1
    //   75: iload_2
    //   76: invokevirtual findPointerIndex : (I)I
    //   79: istore_3
    //   80: iload_3
    //   81: iconst_m1
    //   82: if_icmpne -> 129
    //   85: new java/lang/StringBuilder
    //   88: dup
    //   89: invokespecial <init> : ()V
    //   92: astore_1
    //   93: aload_1
    //   94: ldc_w 'Invalid pointerId='
    //   97: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   100: pop
    //   101: aload_1
    //   102: iload_2
    //   103: invokevirtual append : (I)Ljava/lang/StringBuilder;
    //   106: pop
    //   107: aload_1
    //   108: ldc_w ' in onInterceptTouchEvent'
    //   111: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   114: pop
    //   115: ldc_w 'NestedScrollView'
    //   118: aload_1
    //   119: invokevirtual toString : ()Ljava/lang/String;
    //   122: invokestatic e : (Ljava/lang/String;Ljava/lang/String;)I
    //   125: pop
    //   126: goto -> 448
    //   129: aload_1
    //   130: iload_3
    //   131: invokevirtual getY : (I)F
    //   134: f2i
    //   135: istore_2
    //   136: iload_2
    //   137: aload_0
    //   138: getfield m : I
    //   141: isub
    //   142: invokestatic abs : (I)I
    //   145: aload_0
    //   146: getfield u : I
    //   149: if_icmple -> 448
    //   152: iconst_2
    //   153: aload_0
    //   154: invokevirtual getNestedScrollAxes : ()I
    //   157: iand
    //   158: ifne -> 448
    //   161: aload_0
    //   162: iconst_1
    //   163: putfield q : Z
    //   166: aload_0
    //   167: iload_2
    //   168: putfield m : I
    //   171: aload_0
    //   172: getfield r : Landroid/view/VelocityTracker;
    //   175: ifnonnull -> 185
    //   178: aload_0
    //   179: invokestatic obtain : ()Landroid/view/VelocityTracker;
    //   182: putfield r : Landroid/view/VelocityTracker;
    //   185: aload_0
    //   186: getfield r : Landroid/view/VelocityTracker;
    //   189: aload_1
    //   190: invokevirtual addMovement : (Landroid/view/MotionEvent;)V
    //   193: aload_0
    //   194: iconst_0
    //   195: putfield A : I
    //   198: aload_0
    //   199: invokevirtual getParent : ()Landroid/view/ViewParent;
    //   202: astore_1
    //   203: aload_1
    //   204: ifnull -> 448
    //   207: aload_1
    //   208: iconst_1
    //   209: invokeinterface requestDisallowInterceptTouchEvent : (Z)V
    //   214: goto -> 448
    //   217: aload_0
    //   218: iconst_0
    //   219: putfield q : Z
    //   222: aload_0
    //   223: iconst_m1
    //   224: putfield x : I
    //   227: aload_0
    //   228: invokevirtual x : ()V
    //   231: aload_0
    //   232: getfield j : Landroid/widget/OverScroller;
    //   235: aload_0
    //   236: invokevirtual getScrollX : ()I
    //   239: aload_0
    //   240: invokevirtual getScrollY : ()I
    //   243: iconst_0
    //   244: iconst_0
    //   245: iconst_0
    //   246: aload_0
    //   247: invokevirtual getScrollRange : ()I
    //   250: invokevirtual springBack : (IIIIII)Z
    //   253: ifeq -> 264
    //   256: getstatic k0/l.a : Ljava/util/WeakHashMap;
    //   259: astore_1
    //   260: aload_0
    //   261: invokevirtual postInvalidateOnAnimation : ()V
    //   264: aload_0
    //   265: getfield E : Lk0/f;
    //   268: iconst_0
    //   269: invokevirtual j : (I)V
    //   272: goto -> 448
    //   275: aload_1
    //   276: invokevirtual getY : ()F
    //   279: f2i
    //   280: istore_3
    //   281: aload_1
    //   282: invokevirtual getX : ()F
    //   285: f2i
    //   286: istore_2
    //   287: aload_0
    //   288: invokevirtual getChildCount : ()I
    //   291: ifle -> 354
    //   294: aload_0
    //   295: invokevirtual getScrollY : ()I
    //   298: istore #4
    //   300: aload_0
    //   301: iconst_0
    //   302: invokevirtual getChildAt : (I)Landroid/view/View;
    //   305: astore #5
    //   307: iload_3
    //   308: aload #5
    //   310: invokevirtual getTop : ()I
    //   313: iload #4
    //   315: isub
    //   316: if_icmplt -> 354
    //   319: iload_3
    //   320: aload #5
    //   322: invokevirtual getBottom : ()I
    //   325: iload #4
    //   327: isub
    //   328: if_icmpge -> 354
    //   331: iload_2
    //   332: aload #5
    //   334: invokevirtual getLeft : ()I
    //   337: if_icmplt -> 354
    //   340: iload_2
    //   341: aload #5
    //   343: invokevirtual getRight : ()I
    //   346: if_icmpge -> 354
    //   349: iconst_1
    //   350: istore_2
    //   351: goto -> 356
    //   354: iconst_0
    //   355: istore_2
    //   356: iload_2
    //   357: ifne -> 372
    //   360: aload_0
    //   361: iconst_0
    //   362: putfield q : Z
    //   365: aload_0
    //   366: invokevirtual x : ()V
    //   369: goto -> 448
    //   372: aload_0
    //   373: iload_3
    //   374: putfield m : I
    //   377: aload_0
    //   378: aload_1
    //   379: iconst_0
    //   380: invokevirtual getPointerId : (I)I
    //   383: putfield x : I
    //   386: aload_0
    //   387: getfield r : Landroid/view/VelocityTracker;
    //   390: astore #5
    //   392: aload #5
    //   394: ifnonnull -> 407
    //   397: aload_0
    //   398: invokestatic obtain : ()Landroid/view/VelocityTracker;
    //   401: putfield r : Landroid/view/VelocityTracker;
    //   404: goto -> 412
    //   407: aload #5
    //   409: invokevirtual clear : ()V
    //   412: aload_0
    //   413: getfield r : Landroid/view/VelocityTracker;
    //   416: aload_1
    //   417: invokevirtual addMovement : (Landroid/view/MotionEvent;)V
    //   420: aload_0
    //   421: getfield j : Landroid/widget/OverScroller;
    //   424: invokevirtual computeScrollOffset : ()Z
    //   427: pop
    //   428: aload_0
    //   429: aload_0
    //   430: getfield j : Landroid/widget/OverScroller;
    //   433: invokevirtual isFinished : ()Z
    //   436: iconst_1
    //   437: ixor
    //   438: putfield q : Z
    //   441: aload_0
    //   442: iconst_2
    //   443: iconst_0
    //   444: invokevirtual C : (II)Z
    //   447: pop
    //   448: aload_0
    //   449: getfield q : Z
    //   452: ireturn
  }
  
  public void onLayout(boolean paramBoolean, int paramInt1, int paramInt2, int paramInt3, int paramInt4) {
    super.onLayout(paramBoolean, paramInt1, paramInt2, paramInt3, paramInt4);
    paramInt1 = 0;
    this.n = false;
    View view = this.p;
    if (view != null && s(view, (View)this))
      A(this.p); 
    this.p = null;
    if (!this.o) {
      if (this.C != null) {
        scrollTo(getScrollX(), this.C.h);
        this.C = null;
      } 
      if (getChildCount() > 0) {
        view = getChildAt(0);
        FrameLayout.LayoutParams layoutParams = (FrameLayout.LayoutParams)view.getLayoutParams();
        paramInt1 = view.getMeasuredHeight() + layoutParams.topMargin + layoutParams.bottomMargin;
      } 
      int j = getPaddingTop();
      int k = getPaddingBottom();
      paramInt3 = getScrollY();
      paramInt1 = c(paramInt3, paramInt4 - paramInt2 - j - k, paramInt1);
      if (paramInt1 != paramInt3)
        scrollTo(getScrollX(), paramInt1); 
    } 
    scrollTo(getScrollX(), getScrollY());
    this.o = true;
  }
  
  public void onMeasure(int paramInt1, int paramInt2) {
    super.onMeasure(paramInt1, paramInt2);
    if (!this.s)
      return; 
    if (View.MeasureSpec.getMode(paramInt2) == 0)
      return; 
    if (getChildCount() > 0) {
      View view = getChildAt(0);
      FrameLayout.LayoutParams layoutParams = (FrameLayout.LayoutParams)view.getLayoutParams();
      int j = view.getMeasuredHeight();
      paramInt2 = getMeasuredHeight() - getPaddingTop() - getPaddingBottom() - layoutParams.topMargin - layoutParams.bottomMargin;
      if (j < paramInt2) {
        j = getPaddingLeft();
        view.measure(FrameLayout.getChildMeasureSpec(paramInt1, getPaddingRight() + j + layoutParams.leftMargin + layoutParams.rightMargin, layoutParams.width), View.MeasureSpec.makeMeasureSpec(paramInt2, 1073741824));
      } 
    } 
  }
  
  public boolean onNestedFling(View paramView, float paramFloat1, float paramFloat2, boolean paramBoolean) {
    if (!paramBoolean) {
      dispatchNestedFling(0.0F, paramFloat2, true);
      p((int)paramFloat2);
      return true;
    } 
    return false;
  }
  
  public boolean onNestedPreFling(View paramView, float paramFloat1, float paramFloat2) {
    return dispatchNestedPreFling(paramFloat1, paramFloat2);
  }
  
  public void onNestedPreScroll(View paramView, int paramInt1, int paramInt2, int[] paramArrayOfint) {
    e(paramInt1, paramInt2, paramArrayOfint, null, 0);
  }
  
  public void onNestedScroll(View paramView, int paramInt1, int paramInt2, int paramInt3, int paramInt4) {
    u(paramInt4, 0, null);
  }
  
  public void onNestedScrollAccepted(View paramView1, View paramView2, int paramInt) {
    this.D.a = paramInt;
    C(2, 0);
  }
  
  public void onOverScrolled(int paramInt1, int paramInt2, boolean paramBoolean1, boolean paramBoolean2) {
    super.scrollTo(paramInt1, paramInt2);
  }
  
  public boolean onRequestFocusInDescendants(int paramInt, Rect paramRect) {
    int j;
    View view;
    if (paramInt == 2) {
      j = 130;
    } else {
      j = paramInt;
      if (paramInt == 1)
        j = 33; 
    } 
    FocusFinder focusFinder = FocusFinder.getInstance();
    if (paramRect == null) {
      view = focusFinder.findNextFocus((ViewGroup)this, null, j);
    } else {
      view = view.findNextFocusFromRect((ViewGroup)this, paramRect, j);
    } 
    return (view == null) ? false : (((true ^ t(view, 0, getHeight())) != 0) ? false : view.requestFocus(j, paramRect));
  }
  
  public void onRestoreInstanceState(Parcelable paramParcelable) {
    if (!(paramParcelable instanceof c)) {
      super.onRestoreInstanceState(paramParcelable);
      return;
    } 
    c c1 = (c)paramParcelable;
    super.onRestoreInstanceState(c1.getSuperState());
    this.C = c1;
    requestLayout();
  }
  
  public Parcelable onSaveInstanceState() {
    c c1 = new c(super.onSaveInstanceState());
    c1.h = getScrollY();
    return (Parcelable)c1;
  }
  
  public void onScrollChanged(int paramInt1, int paramInt2, int paramInt3, int paramInt4) {
    super.onScrollChanged(paramInt1, paramInt2, paramInt3, paramInt4);
    b b1 = this.G;
    if (b1 != null) {
      f.b b2 = (f.b)b1;
      AlertController.c((View)this, b2.a, b2.b);
    } 
  }
  
  public void onSizeChanged(int paramInt1, int paramInt2, int paramInt3, int paramInt4) {
    super.onSizeChanged(paramInt1, paramInt2, paramInt3, paramInt4);
    View view = findFocus();
    if (view != null) {
      if (this == view)
        return; 
      if (t(view, 0, paramInt4)) {
        view.getDrawingRect(this.i);
        offsetDescendantRectToMyCoords(view, this.i);
        f(d(this.i));
      } 
    } 
  }
  
  public boolean onStartNestedScroll(View paramView1, View paramView2, int paramInt) {
    return ((paramInt & 0x2) != 0);
  }
  
  public void onStopNestedScroll(View paramView) {
    this.D.a = 0;
    this.E.j(0);
  }
  
  public boolean onTouchEvent(MotionEvent paramMotionEvent) {
    // Byte code:
    //   0: aload_0
    //   1: getfield r : Landroid/view/VelocityTracker;
    //   4: ifnonnull -> 14
    //   7: aload_0
    //   8: invokestatic obtain : ()Landroid/view/VelocityTracker;
    //   11: putfield r : Landroid/view/VelocityTracker;
    //   14: aload_1
    //   15: invokevirtual getActionMasked : ()I
    //   18: istore_3
    //   19: iload_3
    //   20: ifne -> 28
    //   23: aload_0
    //   24: iconst_0
    //   25: putfield A : I
    //   28: aload_1
    //   29: invokestatic obtain : (Landroid/view/MotionEvent;)Landroid/view/MotionEvent;
    //   32: astore #10
    //   34: aload #10
    //   36: fconst_0
    //   37: aload_0
    //   38: getfield A : I
    //   41: i2f
    //   42: invokevirtual offsetLocation : (FF)V
    //   45: iload_3
    //   46: ifeq -> 829
    //   49: iload_3
    //   50: iconst_1
    //   51: if_icmpeq -> 715
    //   54: iload_3
    //   55: iconst_2
    //   56: if_icmpeq -> 172
    //   59: iload_3
    //   60: iconst_3
    //   61: if_icmpeq -> 130
    //   64: iload_3
    //   65: iconst_5
    //   66: if_icmpeq -> 103
    //   69: iload_3
    //   70: bipush #6
    //   72: if_icmpeq -> 78
    //   75: goto -> 918
    //   78: aload_0
    //   79: aload_1
    //   80: invokevirtual v : (Landroid/view/MotionEvent;)V
    //   83: aload_0
    //   84: aload_1
    //   85: aload_1
    //   86: aload_0
    //   87: getfield x : I
    //   90: invokevirtual findPointerIndex : (I)I
    //   93: invokevirtual getY : (I)F
    //   96: f2i
    //   97: putfield m : I
    //   100: goto -> 918
    //   103: aload_1
    //   104: invokevirtual getActionIndex : ()I
    //   107: istore_3
    //   108: aload_0
    //   109: aload_1
    //   110: iload_3
    //   111: invokevirtual getY : (I)F
    //   114: f2i
    //   115: putfield m : I
    //   118: aload_0
    //   119: aload_1
    //   120: iload_3
    //   121: invokevirtual getPointerId : (I)I
    //   124: putfield x : I
    //   127: goto -> 918
    //   130: aload_0
    //   131: getfield q : Z
    //   134: ifeq -> 817
    //   137: aload_0
    //   138: invokevirtual getChildCount : ()I
    //   141: ifle -> 817
    //   144: aload_0
    //   145: getfield j : Landroid/widget/OverScroller;
    //   148: aload_0
    //   149: invokevirtual getScrollX : ()I
    //   152: aload_0
    //   153: invokevirtual getScrollY : ()I
    //   156: iconst_0
    //   157: iconst_0
    //   158: iconst_0
    //   159: aload_0
    //   160: invokevirtual getScrollRange : ()I
    //   163: invokevirtual springBack : (IIIIII)Z
    //   166: ifeq -> 817
    //   169: goto -> 809
    //   172: aload_1
    //   173: aload_0
    //   174: getfield x : I
    //   177: invokevirtual findPointerIndex : (I)I
    //   180: istore #5
    //   182: iload #5
    //   184: iconst_m1
    //   185: if_icmpne -> 226
    //   188: ldc_w 'Invalid pointerId='
    //   191: invokestatic a : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   194: astore_1
    //   195: aload_1
    //   196: aload_0
    //   197: getfield x : I
    //   200: invokevirtual append : (I)Ljava/lang/StringBuilder;
    //   203: pop
    //   204: aload_1
    //   205: ldc_w ' in onTouchEvent'
    //   208: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   211: pop
    //   212: ldc_w 'NestedScrollView'
    //   215: aload_1
    //   216: invokevirtual toString : ()Ljava/lang/String;
    //   219: invokestatic e : (Ljava/lang/String;Ljava/lang/String;)I
    //   222: pop
    //   223: goto -> 918
    //   226: aload_1
    //   227: iload #5
    //   229: invokevirtual getY : (I)F
    //   232: f2i
    //   233: istore #6
    //   235: aload_0
    //   236: getfield m : I
    //   239: iload #6
    //   241: isub
    //   242: istore #4
    //   244: iload #4
    //   246: istore_3
    //   247: aload_0
    //   248: getfield q : Z
    //   251: ifne -> 316
    //   254: iload #4
    //   256: istore_3
    //   257: iload #4
    //   259: invokestatic abs : (I)I
    //   262: aload_0
    //   263: getfield u : I
    //   266: if_icmple -> 316
    //   269: aload_0
    //   270: invokevirtual getParent : ()Landroid/view/ViewParent;
    //   273: astore #11
    //   275: aload #11
    //   277: ifnull -> 288
    //   280: aload #11
    //   282: iconst_1
    //   283: invokeinterface requestDisallowInterceptTouchEvent : (Z)V
    //   288: aload_0
    //   289: iconst_1
    //   290: putfield q : Z
    //   293: aload_0
    //   294: getfield u : I
    //   297: istore_3
    //   298: iload #4
    //   300: ifle -> 311
    //   303: iload #4
    //   305: iload_3
    //   306: isub
    //   307: istore_3
    //   308: goto -> 316
    //   311: iload #4
    //   313: iload_3
    //   314: iadd
    //   315: istore_3
    //   316: iload_3
    //   317: istore #4
    //   319: aload_0
    //   320: getfield q : Z
    //   323: ifeq -> 918
    //   326: iload #4
    //   328: istore_3
    //   329: aload_0
    //   330: iconst_0
    //   331: iload #4
    //   333: aload_0
    //   334: getfield z : [I
    //   337: aload_0
    //   338: getfield y : [I
    //   341: iconst_0
    //   342: invokevirtual e : (II[I[II)Z
    //   345: ifeq -> 373
    //   348: iload #4
    //   350: aload_0
    //   351: getfield z : [I
    //   354: iconst_1
    //   355: iaload
    //   356: isub
    //   357: istore_3
    //   358: aload_0
    //   359: aload_0
    //   360: getfield A : I
    //   363: aload_0
    //   364: getfield y : [I
    //   367: iconst_1
    //   368: iaload
    //   369: iadd
    //   370: putfield A : I
    //   373: aload_0
    //   374: iload #6
    //   376: aload_0
    //   377: getfield y : [I
    //   380: iconst_1
    //   381: iaload
    //   382: isub
    //   383: putfield m : I
    //   386: aload_0
    //   387: invokevirtual getScrollY : ()I
    //   390: istore #7
    //   392: aload_0
    //   393: invokevirtual getScrollRange : ()I
    //   396: istore #6
    //   398: aload_0
    //   399: invokevirtual getOverScrollMode : ()I
    //   402: istore #4
    //   404: iload #4
    //   406: ifeq -> 429
    //   409: iload #4
    //   411: iconst_1
    //   412: if_icmpne -> 423
    //   415: iload #6
    //   417: ifle -> 423
    //   420: goto -> 429
    //   423: iconst_0
    //   424: istore #4
    //   426: goto -> 432
    //   429: iconst_1
    //   430: istore #4
    //   432: aload_0
    //   433: iconst_0
    //   434: iload_3
    //   435: iconst_0
    //   436: aload_0
    //   437: invokevirtual getScrollY : ()I
    //   440: iconst_0
    //   441: iload #6
    //   443: iconst_0
    //   444: iconst_0
    //   445: invokevirtual w : (IIIIIIII)Z
    //   448: ifeq -> 466
    //   451: aload_0
    //   452: iconst_0
    //   453: invokevirtual r : (I)Z
    //   456: ifne -> 466
    //   459: aload_0
    //   460: getfield r : Landroid/view/VelocityTracker;
    //   463: invokevirtual clear : ()V
    //   466: aload_0
    //   467: invokevirtual getScrollY : ()I
    //   470: iload #7
    //   472: isub
    //   473: istore #8
    //   475: aload_0
    //   476: getfield z : [I
    //   479: astore #11
    //   481: aload #11
    //   483: iconst_1
    //   484: iconst_0
    //   485: iastore
    //   486: aload_0
    //   487: getfield y : [I
    //   490: astore #12
    //   492: aload_0
    //   493: getfield E : Lk0/f;
    //   496: iconst_0
    //   497: iload #8
    //   499: iconst_0
    //   500: iload_3
    //   501: iload #8
    //   503: isub
    //   504: aload #12
    //   506: iconst_0
    //   507: aload #11
    //   509: invokevirtual f : (IIII[II[I)Z
    //   512: pop
    //   513: aload_0
    //   514: getfield m : I
    //   517: istore #8
    //   519: aload_0
    //   520: getfield y : [I
    //   523: astore #11
    //   525: aload_0
    //   526: iload #8
    //   528: aload #11
    //   530: iconst_1
    //   531: iaload
    //   532: isub
    //   533: putfield m : I
    //   536: aload_0
    //   537: aload_0
    //   538: getfield A : I
    //   541: aload #11
    //   543: iconst_1
    //   544: iaload
    //   545: iadd
    //   546: putfield A : I
    //   549: iload #4
    //   551: ifeq -> 918
    //   554: iload_3
    //   555: aload_0
    //   556: getfield z : [I
    //   559: iconst_1
    //   560: iaload
    //   561: isub
    //   562: istore_3
    //   563: aload_0
    //   564: invokevirtual k : ()V
    //   567: iload #7
    //   569: iload_3
    //   570: iadd
    //   571: istore #4
    //   573: iload #4
    //   575: ifge -> 623
    //   578: aload_0
    //   579: getfield k : Landroid/widget/EdgeEffect;
    //   582: iload_3
    //   583: i2f
    //   584: aload_0
    //   585: invokevirtual getHeight : ()I
    //   588: i2f
    //   589: fdiv
    //   590: aload_1
    //   591: iload #5
    //   593: invokevirtual getX : (I)F
    //   596: aload_0
    //   597: invokevirtual getWidth : ()I
    //   600: i2f
    //   601: fdiv
    //   602: invokevirtual onPull : (FF)V
    //   605: aload_0
    //   606: getfield l : Landroid/widget/EdgeEffect;
    //   609: invokevirtual isFinished : ()Z
    //   612: ifne -> 678
    //   615: aload_0
    //   616: getfield l : Landroid/widget/EdgeEffect;
    //   619: astore_1
    //   620: goto -> 674
    //   623: iload #4
    //   625: iload #6
    //   627: if_icmple -> 678
    //   630: aload_0
    //   631: getfield l : Landroid/widget/EdgeEffect;
    //   634: iload_3
    //   635: i2f
    //   636: aload_0
    //   637: invokevirtual getHeight : ()I
    //   640: i2f
    //   641: fdiv
    //   642: fconst_1
    //   643: aload_1
    //   644: iload #5
    //   646: invokevirtual getX : (I)F
    //   649: aload_0
    //   650: invokevirtual getWidth : ()I
    //   653: i2f
    //   654: fdiv
    //   655: fsub
    //   656: invokevirtual onPull : (FF)V
    //   659: aload_0
    //   660: getfield k : Landroid/widget/EdgeEffect;
    //   663: invokevirtual isFinished : ()Z
    //   666: ifne -> 678
    //   669: aload_0
    //   670: getfield k : Landroid/widget/EdgeEffect;
    //   673: astore_1
    //   674: aload_1
    //   675: invokevirtual onRelease : ()V
    //   678: aload_0
    //   679: getfield k : Landroid/widget/EdgeEffect;
    //   682: astore_1
    //   683: aload_1
    //   684: ifnull -> 918
    //   687: aload_1
    //   688: invokevirtual isFinished : ()Z
    //   691: ifeq -> 704
    //   694: aload_0
    //   695: getfield l : Landroid/widget/EdgeEffect;
    //   698: invokevirtual isFinished : ()Z
    //   701: ifne -> 918
    //   704: getstatic k0/l.a : Ljava/util/WeakHashMap;
    //   707: astore_1
    //   708: aload_0
    //   709: invokevirtual postInvalidateOnAnimation : ()V
    //   712: goto -> 918
    //   715: aload_0
    //   716: getfield r : Landroid/view/VelocityTracker;
    //   719: astore_1
    //   720: aload_1
    //   721: sipush #1000
    //   724: aload_0
    //   725: getfield w : I
    //   728: i2f
    //   729: invokevirtual computeCurrentVelocity : (IF)V
    //   732: aload_1
    //   733: aload_0
    //   734: getfield x : I
    //   737: invokevirtual getYVelocity : (I)F
    //   740: f2i
    //   741: istore_3
    //   742: iload_3
    //   743: invokestatic abs : (I)I
    //   746: aload_0
    //   747: getfield v : I
    //   750: if_icmplt -> 784
    //   753: iload_3
    //   754: ineg
    //   755: istore_3
    //   756: iload_3
    //   757: i2f
    //   758: fstore_2
    //   759: aload_0
    //   760: fconst_0
    //   761: fload_2
    //   762: invokevirtual dispatchNestedPreFling : (FF)Z
    //   765: ifne -> 817
    //   768: aload_0
    //   769: fconst_0
    //   770: fload_2
    //   771: iconst_1
    //   772: invokevirtual dispatchNestedFling : (FFZ)Z
    //   775: pop
    //   776: aload_0
    //   777: iload_3
    //   778: invokevirtual p : (I)V
    //   781: goto -> 817
    //   784: aload_0
    //   785: getfield j : Landroid/widget/OverScroller;
    //   788: aload_0
    //   789: invokevirtual getScrollX : ()I
    //   792: aload_0
    //   793: invokevirtual getScrollY : ()I
    //   796: iconst_0
    //   797: iconst_0
    //   798: iconst_0
    //   799: aload_0
    //   800: invokevirtual getScrollRange : ()I
    //   803: invokevirtual springBack : (IIIIII)Z
    //   806: ifeq -> 817
    //   809: getstatic k0/l.a : Ljava/util/WeakHashMap;
    //   812: astore_1
    //   813: aload_0
    //   814: invokevirtual postInvalidateOnAnimation : ()V
    //   817: aload_0
    //   818: iconst_m1
    //   819: putfield x : I
    //   822: aload_0
    //   823: invokevirtual g : ()V
    //   826: goto -> 918
    //   829: aload_0
    //   830: invokevirtual getChildCount : ()I
    //   833: ifne -> 838
    //   836: iconst_0
    //   837: ireturn
    //   838: aload_0
    //   839: getfield j : Landroid/widget/OverScroller;
    //   842: invokevirtual isFinished : ()Z
    //   845: iconst_1
    //   846: ixor
    //   847: istore #9
    //   849: aload_0
    //   850: iload #9
    //   852: putfield q : Z
    //   855: iload #9
    //   857: ifeq -> 879
    //   860: aload_0
    //   861: invokevirtual getParent : ()Landroid/view/ViewParent;
    //   864: astore #11
    //   866: aload #11
    //   868: ifnull -> 879
    //   871: aload #11
    //   873: iconst_1
    //   874: invokeinterface requestDisallowInterceptTouchEvent : (Z)V
    //   879: aload_0
    //   880: getfield j : Landroid/widget/OverScroller;
    //   883: invokevirtual isFinished : ()Z
    //   886: ifne -> 893
    //   889: aload_0
    //   890: invokevirtual a : ()V
    //   893: aload_0
    //   894: aload_1
    //   895: invokevirtual getY : ()F
    //   898: f2i
    //   899: putfield m : I
    //   902: aload_0
    //   903: aload_1
    //   904: iconst_0
    //   905: invokevirtual getPointerId : (I)I
    //   908: putfield x : I
    //   911: aload_0
    //   912: iconst_2
    //   913: iconst_0
    //   914: invokevirtual C : (II)Z
    //   917: pop
    //   918: aload_0
    //   919: getfield r : Landroid/view/VelocityTracker;
    //   922: astore_1
    //   923: aload_1
    //   924: ifnull -> 933
    //   927: aload_1
    //   928: aload #10
    //   930: invokevirtual addMovement : (Landroid/view/MotionEvent;)V
    //   933: aload #10
    //   935: invokevirtual recycle : ()V
    //   938: iconst_1
    //   939: ireturn
  }
  
  public void p(int paramInt) {
    if (getChildCount() > 0) {
      this.j.fling(getScrollX(), getScrollY(), 0, paramInt, 0, 0, -2147483648, 2147483647, 0, 0);
      y(true);
    } 
  }
  
  public boolean q(int paramInt) {
    int j;
    if (paramInt == 130) {
      j = 1;
    } else {
      j = 0;
    } 
    int k = getHeight();
    Rect rect = this.i;
    rect.top = 0;
    rect.bottom = k;
    if (j) {
      j = getChildCount();
      if (j > 0) {
        View view = getChildAt(j - 1);
        FrameLayout.LayoutParams layoutParams = (FrameLayout.LayoutParams)view.getLayoutParams();
        Rect rect2 = this.i;
        j = view.getBottom();
        int m = layoutParams.bottomMargin;
        rect2.bottom = getPaddingBottom() + j + m;
        Rect rect1 = this.i;
        rect1.top = rect1.bottom - k;
      } 
    } 
    rect = this.i;
    return z(paramInt, rect.top, rect.bottom);
  }
  
  public boolean r(int paramInt) {
    return (this.E.g(paramInt) != null);
  }
  
  public void requestChildFocus(View paramView1, View paramView2) {
    if (!this.n) {
      A(paramView2);
    } else {
      this.p = paramView2;
    } 
    super.requestChildFocus(paramView1, paramView2);
  }
  
  public boolean requestChildRectangleOnScreen(View paramView, Rect paramRect, boolean paramBoolean) {
    boolean bool;
    paramRect.offset(paramView.getLeft() - paramView.getScrollX(), paramView.getTop() - paramView.getScrollY());
    int j = d(paramRect);
    if (j != 0) {
      bool = true;
    } else {
      bool = false;
    } 
    if (bool) {
      if (paramBoolean) {
        scrollBy(0, j);
        return bool;
      } 
      B(0, j, 250, false);
    } 
    return bool;
  }
  
  public void requestDisallowInterceptTouchEvent(boolean paramBoolean) {
    if (paramBoolean)
      x(); 
    super.requestDisallowInterceptTouchEvent(paramBoolean);
  }
  
  public void requestLayout() {
    this.n = true;
    super.requestLayout();
  }
  
  public void scrollTo(int paramInt1, int paramInt2) {
    if (getChildCount() > 0) {
      View view = getChildAt(0);
      FrameLayout.LayoutParams layoutParams = (FrameLayout.LayoutParams)view.getLayoutParams();
      int i3 = getWidth();
      int i4 = getPaddingLeft();
      int i5 = getPaddingRight();
      int i6 = view.getWidth();
      int i7 = layoutParams.leftMargin;
      int i8 = layoutParams.rightMargin;
      int j = getHeight();
      int k = getPaddingTop();
      int m = getPaddingBottom();
      int n = view.getHeight();
      int i1 = layoutParams.topMargin;
      int i2 = layoutParams.bottomMargin;
      paramInt1 = c(paramInt1, i3 - i4 - i5, i6 + i7 + i8);
      paramInt2 = c(paramInt2, j - k - m, n + i1 + i2);
      if (paramInt1 != getScrollX() || paramInt2 != getScrollY())
        super.scrollTo(paramInt1, paramInt2); 
    } 
  }
  
  public void setFillViewport(boolean paramBoolean) {
    if (paramBoolean != this.s) {
      this.s = paramBoolean;
      requestLayout();
    } 
  }
  
  public void setNestedScrollingEnabled(boolean paramBoolean) {
    f f1 = this.E;
    if (f1.d) {
      View view = f1.c;
      WeakHashMap weakHashMap = l.a;
      view.stopNestedScroll();
    } 
    f1.d = paramBoolean;
  }
  
  public void setOnScrollChangeListener(b paramb) {
    this.G = paramb;
  }
  
  public void setSmoothScrollingEnabled(boolean paramBoolean) {
    this.t = paramBoolean;
  }
  
  public boolean shouldDelayChildPressedState() {
    return true;
  }
  
  public boolean startNestedScroll(int paramInt) {
    return this.E.i(paramInt, 0);
  }
  
  public void stopNestedScroll() {
    this.E.j(0);
  }
  
  public final boolean t(View paramView, int paramInt1, int paramInt2) {
    paramView.getDrawingRect(this.i);
    offsetDescendantRectToMyCoords(paramView, this.i);
    return (this.i.bottom + paramInt1 >= getScrollY() && this.i.top - paramInt1 <= getScrollY() + paramInt2);
  }
  
  public final void u(int paramInt1, int paramInt2, int[] paramArrayOfint) {
    int j = getScrollY();
    scrollBy(0, paramInt1);
    j = getScrollY() - j;
    if (paramArrayOfint != null)
      paramArrayOfint[1] = paramArrayOfint[1] + j; 
    this.E.d(0, j, 0, paramInt1 - j, null, paramInt2, paramArrayOfint);
  }
  
  public final void v(MotionEvent paramMotionEvent) {
    int j = paramMotionEvent.getActionIndex();
    if (paramMotionEvent.getPointerId(j) == this.x) {
      if (j == 0) {
        j = 1;
      } else {
        j = 0;
      } 
      this.m = (int)paramMotionEvent.getY(j);
      this.x = paramMotionEvent.getPointerId(j);
      VelocityTracker velocityTracker = this.r;
      if (velocityTracker != null)
        velocityTracker.clear(); 
    } 
  }
  
  public boolean w(int paramInt1, int paramInt2, int paramInt3, int paramInt4, int paramInt5, int paramInt6, int paramInt7, int paramInt8) {
    // Byte code:
    //   0: aload_0
    //   1: invokevirtual getOverScrollMode : ()I
    //   4: istore #11
    //   6: aload_0
    //   7: invokevirtual computeHorizontalScrollRange : ()I
    //   10: istore #9
    //   12: aload_0
    //   13: invokevirtual computeHorizontalScrollExtent : ()I
    //   16: istore #10
    //   18: iconst_0
    //   19: istore #14
    //   21: iload #9
    //   23: iload #10
    //   25: if_icmple -> 34
    //   28: iconst_1
    //   29: istore #9
    //   31: goto -> 37
    //   34: iconst_0
    //   35: istore #9
    //   37: aload_0
    //   38: invokevirtual computeVerticalScrollRange : ()I
    //   41: aload_0
    //   42: invokevirtual computeVerticalScrollExtent : ()I
    //   45: if_icmple -> 54
    //   48: iconst_1
    //   49: istore #10
    //   51: goto -> 57
    //   54: iconst_0
    //   55: istore #10
    //   57: iload #11
    //   59: ifeq -> 82
    //   62: iload #11
    //   64: iconst_1
    //   65: if_icmpne -> 76
    //   68: iload #9
    //   70: ifeq -> 76
    //   73: goto -> 82
    //   76: iconst_0
    //   77: istore #9
    //   79: goto -> 85
    //   82: iconst_1
    //   83: istore #9
    //   85: iload #11
    //   87: ifeq -> 110
    //   90: iload #11
    //   92: iconst_1
    //   93: if_icmpne -> 104
    //   96: iload #10
    //   98: ifeq -> 104
    //   101: goto -> 110
    //   104: iconst_0
    //   105: istore #10
    //   107: goto -> 113
    //   110: iconst_1
    //   111: istore #10
    //   113: iload_3
    //   114: iload_1
    //   115: iadd
    //   116: istore_3
    //   117: iload #9
    //   119: ifne -> 127
    //   122: iconst_0
    //   123: istore_1
    //   124: goto -> 130
    //   127: iload #7
    //   129: istore_1
    //   130: iload #4
    //   132: iload_2
    //   133: iadd
    //   134: istore #4
    //   136: iload #10
    //   138: ifne -> 146
    //   141: iconst_0
    //   142: istore_2
    //   143: goto -> 149
    //   146: iload #8
    //   148: istore_2
    //   149: iload_1
    //   150: ineg
    //   151: istore #7
    //   153: iload_1
    //   154: iload #5
    //   156: iadd
    //   157: istore_1
    //   158: iload_2
    //   159: ineg
    //   160: istore #5
    //   162: iload_2
    //   163: iload #6
    //   165: iadd
    //   166: istore #6
    //   168: iload_3
    //   169: iload_1
    //   170: if_icmple -> 181
    //   173: iconst_1
    //   174: istore #12
    //   176: iload_1
    //   177: istore_2
    //   178: goto -> 198
    //   181: iload_3
    //   182: iload #7
    //   184: if_icmpge -> 193
    //   187: iload #7
    //   189: istore_1
    //   190: goto -> 173
    //   193: iconst_0
    //   194: istore #12
    //   196: iload_3
    //   197: istore_2
    //   198: iload #4
    //   200: iload #6
    //   202: if_icmple -> 214
    //   205: iload #6
    //   207: istore_1
    //   208: iconst_1
    //   209: istore #13
    //   211: goto -> 233
    //   214: iload #4
    //   216: iload #5
    //   218: if_icmpge -> 227
    //   221: iload #5
    //   223: istore_1
    //   224: goto -> 208
    //   227: iconst_0
    //   228: istore #13
    //   230: iload #4
    //   232: istore_1
    //   233: iload #13
    //   235: ifeq -> 263
    //   238: aload_0
    //   239: iconst_1
    //   240: invokevirtual r : (I)Z
    //   243: ifne -> 263
    //   246: aload_0
    //   247: getfield j : Landroid/widget/OverScroller;
    //   250: iload_2
    //   251: iload_1
    //   252: iconst_0
    //   253: iconst_0
    //   254: iconst_0
    //   255: aload_0
    //   256: invokevirtual getScrollRange : ()I
    //   259: invokevirtual springBack : (IIIIII)Z
    //   262: pop
    //   263: aload_0
    //   264: iload_2
    //   265: iload_1
    //   266: iload #12
    //   268: iload #13
    //   270: invokevirtual onOverScrolled : (IIZZ)V
    //   273: iload #12
    //   275: ifne -> 287
    //   278: iload #14
    //   280: istore #12
    //   282: iload #13
    //   284: ifeq -> 290
    //   287: iconst_1
    //   288: istore #12
    //   290: iload #12
    //   292: ireturn
  }
  
  public final void x() {
    VelocityTracker velocityTracker = this.r;
    if (velocityTracker != null) {
      velocityTracker.recycle();
      this.r = null;
    } 
  }
  
  public final void y(boolean paramBoolean) {
    if (paramBoolean) {
      C(2, 1);
    } else {
      this.E.j(1);
    } 
    this.B = getScrollY();
    WeakHashMap weakHashMap = l.a;
    postInvalidateOnAnimation();
  }
  
  public final boolean z(int paramInt1, int paramInt2, int paramInt3) {
    // Byte code:
    //   0: aload_0
    //   1: invokevirtual getHeight : ()I
    //   4: istore #4
    //   6: aload_0
    //   7: invokevirtual getScrollY : ()I
    //   10: istore #10
    //   12: iload #4
    //   14: iload #10
    //   16: iadd
    //   17: istore #11
    //   19: iload_1
    //   20: bipush #33
    //   22: if_icmpne -> 31
    //   25: iconst_1
    //   26: istore #6
    //   28: goto -> 34
    //   31: iconst_0
    //   32: istore #6
    //   34: aload_0
    //   35: iconst_2
    //   36: invokevirtual getFocusables : (I)Ljava/util/ArrayList;
    //   39: astore #18
    //   41: aload #18
    //   43: invokeinterface size : ()I
    //   48: istore #12
    //   50: aconst_null
    //   51: astore #16
    //   53: iconst_0
    //   54: istore #7
    //   56: iconst_0
    //   57: istore #8
    //   59: iload #7
    //   61: iload #12
    //   63: if_icmpge -> 285
    //   66: aload #18
    //   68: iload #7
    //   70: invokeinterface get : (I)Ljava/lang/Object;
    //   75: checkcast android/view/View
    //   78: astore #17
    //   80: aload #17
    //   82: invokevirtual getTop : ()I
    //   85: istore #9
    //   87: aload #17
    //   89: invokevirtual getBottom : ()I
    //   92: istore #13
    //   94: aload #16
    //   96: astore #15
    //   98: iload #8
    //   100: istore #5
    //   102: iload_2
    //   103: iload #13
    //   105: if_icmpge -> 268
    //   108: aload #16
    //   110: astore #15
    //   112: iload #8
    //   114: istore #5
    //   116: iload #9
    //   118: iload_3
    //   119: if_icmpge -> 268
    //   122: iload_2
    //   123: iload #9
    //   125: if_icmpge -> 140
    //   128: iload #13
    //   130: iload_3
    //   131: if_icmpge -> 140
    //   134: iconst_1
    //   135: istore #4
    //   137: goto -> 143
    //   140: iconst_0
    //   141: istore #4
    //   143: aload #16
    //   145: ifnonnull -> 159
    //   148: aload #17
    //   150: astore #15
    //   152: iload #4
    //   154: istore #5
    //   156: goto -> 268
    //   159: iload #6
    //   161: ifeq -> 174
    //   164: iload #9
    //   166: aload #16
    //   168: invokevirtual getTop : ()I
    //   171: if_icmplt -> 189
    //   174: iload #6
    //   176: ifne -> 195
    //   179: iload #13
    //   181: aload #16
    //   183: invokevirtual getBottom : ()I
    //   186: if_icmple -> 195
    //   189: iconst_1
    //   190: istore #9
    //   192: goto -> 198
    //   195: iconst_0
    //   196: istore #9
    //   198: iload #8
    //   200: ifeq -> 232
    //   203: aload #16
    //   205: astore #15
    //   207: iload #8
    //   209: istore #5
    //   211: iload #4
    //   213: ifeq -> 268
    //   216: aload #16
    //   218: astore #15
    //   220: iload #8
    //   222: istore #5
    //   224: iload #9
    //   226: ifeq -> 268
    //   229: goto -> 260
    //   232: iload #4
    //   234: ifeq -> 247
    //   237: aload #17
    //   239: astore #15
    //   241: iconst_1
    //   242: istore #5
    //   244: goto -> 268
    //   247: aload #16
    //   249: astore #15
    //   251: iload #8
    //   253: istore #5
    //   255: iload #9
    //   257: ifeq -> 268
    //   260: aload #17
    //   262: astore #15
    //   264: iload #8
    //   266: istore #5
    //   268: iload #7
    //   270: iconst_1
    //   271: iadd
    //   272: istore #7
    //   274: aload #15
    //   276: astore #16
    //   278: iload #5
    //   280: istore #8
    //   282: goto -> 59
    //   285: aload #16
    //   287: astore #15
    //   289: aload #16
    //   291: ifnonnull -> 297
    //   294: aload_0
    //   295: astore #15
    //   297: iload_2
    //   298: iload #10
    //   300: if_icmplt -> 315
    //   303: iload_3
    //   304: iload #11
    //   306: if_icmpgt -> 315
    //   309: iconst_0
    //   310: istore #14
    //   312: goto -> 341
    //   315: iload #6
    //   317: ifeq -> 328
    //   320: iload_2
    //   321: iload #10
    //   323: isub
    //   324: istore_2
    //   325: goto -> 333
    //   328: iload_3
    //   329: iload #11
    //   331: isub
    //   332: istore_2
    //   333: aload_0
    //   334: iload_2
    //   335: invokevirtual f : (I)V
    //   338: iconst_1
    //   339: istore #14
    //   341: aload #15
    //   343: aload_0
    //   344: invokevirtual findFocus : ()Landroid/view/View;
    //   347: if_acmpeq -> 357
    //   350: aload #15
    //   352: iload_1
    //   353: invokevirtual requestFocus : (I)Z
    //   356: pop
    //   357: iload #14
    //   359: ireturn
  }
  
  public static class a extends k0.a {
    public void c(View param1View, AccessibilityEvent param1AccessibilityEvent) {
      boolean bool;
      this.a.onInitializeAccessibilityEvent(param1View, param1AccessibilityEvent);
      NestedScrollView nestedScrollView = (NestedScrollView)param1View;
      param1AccessibilityEvent.setClassName(ScrollView.class.getName());
      if (nestedScrollView.getScrollRange() > 0) {
        bool = true;
      } else {
        bool = false;
      } 
      param1AccessibilityEvent.setScrollable(bool);
      param1AccessibilityEvent.setScrollX(nestedScrollView.getScrollX());
      param1AccessibilityEvent.setScrollY(nestedScrollView.getScrollY());
      param1AccessibilityEvent.setMaxScrollX(nestedScrollView.getScrollX());
      param1AccessibilityEvent.setMaxScrollY(nestedScrollView.getScrollRange());
    }
    
    public void d(View param1View, l0.b param1b) {
      this.a.onInitializeAccessibilityNodeInfo(param1View, param1b.a);
      NestedScrollView nestedScrollView = (NestedScrollView)param1View;
      String str = ScrollView.class.getName();
      param1b.a.setClassName(str);
      if (nestedScrollView.isEnabled()) {
        int i = nestedScrollView.getScrollRange();
        if (i > 0) {
          param1b.a.setScrollable(true);
          if (nestedScrollView.getScrollY() > 0) {
            param1b.a(l0.b.a.g);
            param1b.a(l0.b.a.k);
          } 
          if (nestedScrollView.getScrollY() < i) {
            param1b.a(l0.b.a.f);
            param1b.a(l0.b.a.l);
          } 
        } 
      } 
    }
    
    public boolean g(View param1View, int param1Int, Bundle param1Bundle) {
      if (super.g(param1View, param1Int, param1Bundle))
        return true; 
      NestedScrollView nestedScrollView = (NestedScrollView)param1View;
      if (!nestedScrollView.isEnabled())
        return false; 
      if (param1Int != 4096)
        if (param1Int != 8192 && param1Int != 16908344) {
          if (param1Int != 16908346)
            return false; 
        } else {
          param1Int = nestedScrollView.getHeight();
          int k = nestedScrollView.getPaddingBottom();
          int m = nestedScrollView.getPaddingTop();
          param1Int = Math.max(nestedScrollView.getScrollY() - param1Int - k - m, 0);
          if (param1Int == nestedScrollView.getScrollY())
            return false; 
          nestedScrollView.B(0 - nestedScrollView.getScrollX(), param1Int - nestedScrollView.getScrollY(), 250, true);
          return true;
        }  
      param1Int = nestedScrollView.getHeight();
      int i = nestedScrollView.getPaddingBottom();
      int j = nestedScrollView.getPaddingTop();
      param1Int = Math.min(nestedScrollView.getScrollY() + param1Int - i - j, nestedScrollView.getScrollRange());
      if (param1Int == nestedScrollView.getScrollY())
        return false; 
      nestedScrollView.B(0 - nestedScrollView.getScrollX(), param1Int - nestedScrollView.getScrollY(), 250, true);
      return true;
    }
  }
  
  public static interface b {}
  
  public static class c extends View.BaseSavedState {
    public static final Parcelable.Creator<c> CREATOR = new a();
    
    public int h;
    
    public c(Parcel param1Parcel) {
      super(param1Parcel);
      this.h = param1Parcel.readInt();
    }
    
    public c(Parcelable param1Parcelable) {
      super(param1Parcelable);
    }
    
    public String toString() {
      StringBuilder stringBuilder = android.support.v4.media.c.a("HorizontalScrollView.SavedState{");
      stringBuilder.append(Integer.toHexString(System.identityHashCode(this)));
      stringBuilder.append(" scrollPosition=");
      stringBuilder.append(this.h);
      stringBuilder.append("}");
      return stringBuilder.toString();
    }
    
    public void writeToParcel(Parcel param1Parcel, int param1Int) {
      super.writeToParcel(param1Parcel, param1Int);
      param1Parcel.writeInt(this.h);
    }
    
    public class a implements Parcelable.Creator<c> {
      public Object createFromParcel(Parcel param2Parcel) {
        return new NestedScrollView.c(param2Parcel);
      }
      
      public Object[] newArray(int param2Int) {
        return (Object[])new NestedScrollView.c[param2Int];
      }
    }
  }
  
  public class a implements Parcelable.Creator<c> {
    public Object createFromParcel(Parcel param1Parcel) {
      return new NestedScrollView.c(param1Parcel);
    }
    
    public Object[] newArray(int param1Int) {
      return (Object[])new NestedScrollView.c[param1Int];
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Luxury Logo Maker_ Logo Design-dex2jar.jar!\androidx\core\widget\NestedScrollView.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */