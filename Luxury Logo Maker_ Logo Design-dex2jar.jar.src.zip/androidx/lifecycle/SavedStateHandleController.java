package androidx.lifecycle;

import androidx.savedstate.c;

final class SavedStateHandleController implements g {
  public boolean h;
  
  public void c(i parami, e.b paramb) {
    if (paramb == e.b.ON_DESTROY) {
      this.h = false;
      j j = (j)parami.a();
      j.c("removeObserver");
      j.a.j(this);
    } 
  }
  
  public static final class a implements androidx.savedstate.a.a {
    public void a(c param1c) {
      // Byte code:
      //   0: aload_1
      //   1: instanceof androidx/lifecycle/a0
      //   4: ifeq -> 208
      //   7: aload_1
      //   8: checkcast androidx/lifecycle/a0
      //   11: invokeinterface j : ()Landroidx/lifecycle/z;
      //   16: astore #4
      //   18: aload_1
      //   19: invokeinterface d : ()Landroidx/savedstate/a;
      //   24: astore #5
      //   26: aload #4
      //   28: invokestatic requireNonNull : (Ljava/lang/Object;)Ljava/lang/Object;
      //   31: pop
      //   32: new java/util/HashSet
      //   35: dup
      //   36: aload #4
      //   38: getfield a : Ljava/util/HashMap;
      //   41: invokevirtual keySet : ()Ljava/util/Set;
      //   44: invokespecial <init> : (Ljava/util/Collection;)V
      //   47: invokevirtual iterator : ()Ljava/util/Iterator;
      //   50: astore #6
      //   52: aload #6
      //   54: invokeinterface hasNext : ()Z
      //   59: ifeq -> 179
      //   62: aload #6
      //   64: invokeinterface next : ()Ljava/lang/Object;
      //   69: checkcast java/lang/String
      //   72: astore_3
      //   73: aload #4
      //   75: getfield a : Ljava/util/HashMap;
      //   78: aload_3
      //   79: invokevirtual get : (Ljava/lang/Object;)Ljava/lang/Object;
      //   82: checkcast androidx/lifecycle/v
      //   85: astore_3
      //   86: aload_1
      //   87: invokeinterface a : ()Landroidx/lifecycle/e;
      //   92: astore #7
      //   94: aload_3
      //   95: getfield a : Ljava/util/Map;
      //   98: astore #8
      //   100: aload #8
      //   102: ifnonnull -> 110
      //   105: aconst_null
      //   106: astore_3
      //   107: goto -> 128
      //   110: aload #8
      //   112: monitorenter
      //   113: aload_3
      //   114: getfield a : Ljava/util/Map;
      //   117: ldc 'androidx.lifecycle.savedstate.vm.tag'
      //   119: invokeinterface get : (Ljava/lang/Object;)Ljava/lang/Object;
      //   124: astore_3
      //   125: aload #8
      //   127: monitorexit
      //   128: aload_3
      //   129: checkcast androidx/lifecycle/SavedStateHandleController
      //   132: astore_3
      //   133: aload_3
      //   134: ifnull -> 52
      //   137: aload_3
      //   138: getfield h : Z
      //   141: istore_2
      //   142: iload_2
      //   143: ifne -> 52
      //   146: iload_2
      //   147: ifeq -> 160
      //   150: new java/lang/IllegalStateException
      //   153: dup
      //   154: ldc 'Already attached to lifecycleOwner'
      //   156: invokespecial <init> : (Ljava/lang/String;)V
      //   159: athrow
      //   160: aload_3
      //   161: iconst_1
      //   162: putfield h : Z
      //   165: aload #7
      //   167: aload_3
      //   168: invokevirtual a : (Landroidx/lifecycle/h;)V
      //   171: aconst_null
      //   172: athrow
      //   173: astore_1
      //   174: aload #8
      //   176: monitorexit
      //   177: aload_1
      //   178: athrow
      //   179: new java/util/HashSet
      //   182: dup
      //   183: aload #4
      //   185: getfield a : Ljava/util/HashMap;
      //   188: invokevirtual keySet : ()Ljava/util/Set;
      //   191: invokespecial <init> : (Ljava/util/Collection;)V
      //   194: invokevirtual isEmpty : ()Z
      //   197: ifne -> 207
      //   200: aload #5
      //   202: ldc androidx/lifecycle/SavedStateHandleController$a
      //   204: invokevirtual c : (Ljava/lang/Class;)V
      //   207: return
      //   208: new java/lang/IllegalStateException
      //   211: dup
      //   212: ldc 'Internal error: OnRecreation should be registered only on componentsthat implement ViewModelStoreOwner'
      //   214: invokespecial <init> : (Ljava/lang/String;)V
      //   217: athrow
      // Exception table:
      //   from	to	target	type
      //   113	128	173	finally
      //   174	177	173	finally
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Luxury Logo Maker_ Logo Design-dex2jar.jar!\androidx\lifecycle\SavedStateHandleController.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */