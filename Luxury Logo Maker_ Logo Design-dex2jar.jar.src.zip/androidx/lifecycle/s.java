package androidx.lifecycle;

import android.app.Activity;
import android.os.Bundle;

public class s extends b {
  public s(r paramr) {}
  
  public void onActivityCreated(Activity paramActivity, Bundle paramBundle) {
    int i = t.i;
    ((t)paramActivity.getFragmentManager().findFragmentByTag("androidx.lifecycle.LifecycleDispatcher.report_fragment_tag")).h = this.h.o;
  }
  
  public void onActivityPaused(Activity paramActivity) {
    r r1 = this.h;
    int i = r1.i - 1;
    r1.i = i;
    if (i == 0)
      r1.l.postDelayed(r1.n, 700L); 
  }
  
  public void onActivityStopped(Activity paramActivity) {
    r r1 = this.h;
    int i = r1.h - 1;
    r1.h = i;
    if (i == 0 && r1.j) {
      r1.m.d(e.b.ON_STOP);
      r1.k = true;
    } 
  }
}


/* Location:              C:\soft\dex2jar-2.0\Luxury Logo Maker_ Logo Design-dex2jar.jar!\androidx\lifecycle\s.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */