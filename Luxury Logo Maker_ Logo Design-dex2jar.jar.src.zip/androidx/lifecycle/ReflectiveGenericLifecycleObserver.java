package androidx.lifecycle;

class ReflectiveGenericLifecycleObserver implements g {
  public final Object h;
  
  public final a.a i;
  
  public ReflectiveGenericLifecycleObserver(Object paramObject) {
    this.h = paramObject;
    this.i = a.c.b(paramObject.getClass());
  }
  
  public void c(i parami, e.b paramb) {
    a.a a1 = this.i;
    Object object = this.h;
    a.a.a(a1.a.get(paramb), parami, paramb, object);
    a.a.a(a1.a.get(e.b.ON_ANY), parami, paramb, object);
  }
}


/* Location:              C:\soft\dex2jar-2.0\Luxury Logo Maker_ Logo Design-dex2jar.jar!\androidx\lifecycle\ReflectiveGenericLifecycleObserver.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */