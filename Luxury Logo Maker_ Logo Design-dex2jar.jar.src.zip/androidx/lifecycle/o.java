package androidx.lifecycle;

public class o<T> extends LiveData<T> {
  public void h(T paramT) {
    LiveData.a("setValue");
    this.g++;
    this.e = paramT;
    c(null);
  }
}


/* Location:              C:\soft\dex2jar-2.0\Luxury Logo Maker_ Logo Design-dex2jar.jar!\androidx\lifecycle\o.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */