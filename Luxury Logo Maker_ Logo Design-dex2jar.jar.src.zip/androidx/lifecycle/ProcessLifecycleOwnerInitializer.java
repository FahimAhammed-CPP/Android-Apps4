package androidx.lifecycle;

import android.app.Application;
import android.content.ContentProvider;
import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.net.Uri;
import android.os.Handler;
import java.util.Objects;

public class ProcessLifecycleOwnerInitializer extends ContentProvider {
  public int delete(Uri paramUri, String paramString, String[] paramArrayOfString) {
    return 0;
  }
  
  public String getType(Uri paramUri) {
    return null;
  }
  
  public Uri insert(Uri paramUri, ContentValues paramContentValues) {
    return null;
  }
  
  public boolean onCreate() {
    Context context = getContext();
    if (!f.a.getAndSet(true))
      ((Application)context.getApplicationContext()).registerActivityLifecycleCallbacks(new f.a()); 
    context = getContext();
    r r = r.p;
    Objects.requireNonNull(r);
    r.l = new Handler();
    r.m.d(e.b.ON_CREATE);
    ((Application)context.getApplicationContext()).registerActivityLifecycleCallbacks(new s(r));
    return true;
  }
  
  public Cursor query(Uri paramUri, String[] paramArrayOfString1, String paramString1, String[] paramArrayOfString2, String paramString2) {
    return null;
  }
  
  public int update(Uri paramUri, ContentValues paramContentValues, String paramString, String[] paramArrayOfString) {
    return 0;
  }
}


/* Location:              C:\soft\dex2jar-2.0\Luxury Logo Maker_ Logo Design-dex2jar.jar!\androidx\lifecycle\ProcessLifecycleOwnerInitializer.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */