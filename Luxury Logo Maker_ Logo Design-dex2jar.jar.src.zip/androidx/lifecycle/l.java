package androidx.lifecycle;

import android.app.Service;
import android.content.Intent;
import android.os.IBinder;

public class l extends Service implements i {
  public final u h = new u(this);
  
  public e a() {
    return this.h.a;
  }
  
  public IBinder onBind(Intent paramIntent) {
    this.h.a(e.b.ON_START);
    return null;
  }
  
  public void onCreate() {
    this.h.a(e.b.ON_CREATE);
    super.onCreate();
  }
  
  public void onDestroy() {
    u u1 = this.h;
    u1.a(e.b.ON_STOP);
    u1.a(e.b.ON_DESTROY);
    super.onDestroy();
  }
  
  public void onStart(Intent paramIntent, int paramInt) {
    this.h.a(e.b.ON_START);
    super.onStart(paramIntent, paramInt);
  }
  
  public int onStartCommand(Intent paramIntent, int paramInt1, int paramInt2) {
    return super.onStartCommand(paramIntent, paramInt1, paramInt2);
  }
}


/* Location:              C:\soft\dex2jar-2.0\Luxury Logo Maker_ Logo Design-dex2jar.jar!\androidx\lifecycle\l.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */