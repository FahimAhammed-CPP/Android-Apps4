package androidx.lifecycle;

import java.lang.reflect.Constructor;
import java.lang.reflect.InvocationTargetException;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class m {
  public static Map<Class<?>, Integer> a = new HashMap<Class<?>, Integer>();
  
  public static Map<Class<?>, List<Constructor<? extends d>>> b = new HashMap<Class<?>, List<Constructor<? extends d>>>();
  
  public static d a(Constructor<? extends d> paramConstructor, Object paramObject) {
    try {
      return paramConstructor.newInstance(new Object[] { paramObject });
    } catch (IllegalAccessException illegalAccessException) {
      throw new RuntimeException(illegalAccessException);
    } catch (InstantiationException instantiationException) {
      throw new RuntimeException(instantiationException);
    } catch (InvocationTargetException invocationTargetException) {
      throw new RuntimeException(invocationTargetException);
    } 
  }
  
  public static String b(String paramString) {
    StringBuilder stringBuilder = new StringBuilder();
    stringBuilder.append(paramString.replace(".", "_"));
    stringBuilder.append("_LifecycleAdapter");
    return stringBuilder.toString();
  }
  
  public static int c(Class<?> paramClass) {
    // Byte code:
    //   0: getstatic androidx/lifecycle/m.a : Ljava/util/Map;
    //   3: checkcast java/util/HashMap
    //   6: aload_0
    //   7: invokevirtual get : (Ljava/lang/Object;)Ljava/lang/Object;
    //   10: checkcast java/lang/Integer
    //   13: astore #6
    //   15: aload #6
    //   17: ifnull -> 26
    //   20: aload #6
    //   22: invokevirtual intValue : ()I
    //   25: ireturn
    //   26: aload_0
    //   27: invokevirtual getCanonicalName : ()Ljava/lang/String;
    //   30: astore #6
    //   32: iconst_1
    //   33: istore_3
    //   34: aload #6
    //   36: ifnonnull -> 44
    //   39: iload_3
    //   40: istore_1
    //   41: goto -> 589
    //   44: aconst_null
    //   45: astore #8
    //   47: aload_0
    //   48: invokevirtual getPackage : ()Ljava/lang/Package;
    //   51: astore #6
    //   53: aload_0
    //   54: invokevirtual getCanonicalName : ()Ljava/lang/String;
    //   57: astore #7
    //   59: aload #6
    //   61: ifnull -> 623
    //   64: aload #6
    //   66: invokevirtual getName : ()Ljava/lang/String;
    //   69: astore #6
    //   71: goto -> 74
    //   74: aload #6
    //   76: invokevirtual isEmpty : ()Z
    //   79: ifeq -> 85
    //   82: goto -> 99
    //   85: aload #7
    //   87: aload #6
    //   89: invokevirtual length : ()I
    //   92: iconst_1
    //   93: iadd
    //   94: invokevirtual substring : (I)Ljava/lang/String;
    //   97: astore #7
    //   99: aload #7
    //   101: invokestatic b : (Ljava/lang/String;)Ljava/lang/String;
    //   104: astore #7
    //   106: aload #6
    //   108: invokevirtual isEmpty : ()Z
    //   111: ifeq -> 121
    //   114: aload #7
    //   116: astore #6
    //   118: goto -> 161
    //   121: new java/lang/StringBuilder
    //   124: dup
    //   125: invokespecial <init> : ()V
    //   128: astore #9
    //   130: aload #9
    //   132: aload #6
    //   134: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   137: pop
    //   138: aload #9
    //   140: ldc '.'
    //   142: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   145: pop
    //   146: aload #9
    //   148: aload #7
    //   150: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   153: pop
    //   154: aload #9
    //   156: invokevirtual toString : ()Ljava/lang/String;
    //   159: astore #6
    //   161: aload #6
    //   163: invokestatic forName : (Ljava/lang/String;)Ljava/lang/Class;
    //   166: iconst_1
    //   167: anewarray java/lang/Class
    //   170: dup
    //   171: iconst_0
    //   172: aload_0
    //   173: aastore
    //   174: invokevirtual getDeclaredConstructor : ([Ljava/lang/Class;)Ljava/lang/reflect/Constructor;
    //   177: astore #7
    //   179: aload #7
    //   181: astore #6
    //   183: aload #7
    //   185: invokevirtual isAccessible : ()Z
    //   188: ifne -> 217
    //   191: aload #7
    //   193: iconst_1
    //   194: invokevirtual setAccessible : (Z)V
    //   197: aload #7
    //   199: astore #6
    //   201: goto -> 217
    //   204: astore_0
    //   205: new java/lang/RuntimeException
    //   208: dup
    //   209: aload_0
    //   210: invokespecial <init> : (Ljava/lang/Throwable;)V
    //   213: athrow
    //   214: aconst_null
    //   215: astore #6
    //   217: aload #6
    //   219: ifnull -> 245
    //   222: getstatic androidx/lifecycle/m.b : Ljava/util/Map;
    //   225: astore #7
    //   227: aload #6
    //   229: invokestatic singletonList : (Ljava/lang/Object;)Ljava/util/List;
    //   232: astore #8
    //   234: aload #7
    //   236: astore #6
    //   238: aload #8
    //   240: astore #7
    //   242: goto -> 575
    //   245: getstatic androidx/lifecycle/a.c : Landroidx/lifecycle/a;
    //   248: astore #6
    //   250: aload #6
    //   252: getfield b : Ljava/util/Map;
    //   255: aload_0
    //   256: invokeinterface get : (Ljava/lang/Object;)Ljava/lang/Object;
    //   261: checkcast java/lang/Boolean
    //   264: astore #7
    //   266: aload #7
    //   268: ifnull -> 281
    //   271: aload #7
    //   273: invokevirtual booleanValue : ()Z
    //   276: istore #5
    //   278: goto -> 353
    //   281: aload_0
    //   282: invokevirtual getDeclaredMethods : ()[Ljava/lang/reflect/Method;
    //   285: astore #7
    //   287: aload #7
    //   289: arraylength
    //   290: istore_2
    //   291: iconst_0
    //   292: istore_1
    //   293: iload_1
    //   294: iload_2
    //   295: if_icmpge -> 335
    //   298: aload #7
    //   300: iload_1
    //   301: aaload
    //   302: ldc androidx/lifecycle/q
    //   304: invokevirtual getAnnotation : (Ljava/lang/Class;)Ljava/lang/annotation/Annotation;
    //   307: checkcast androidx/lifecycle/q
    //   310: ifnull -> 328
    //   313: aload #6
    //   315: aload_0
    //   316: aload #7
    //   318: invokevirtual a : (Ljava/lang/Class;[Ljava/lang/reflect/Method;)Landroidx/lifecycle/a$a;
    //   321: pop
    //   322: iconst_1
    //   323: istore #5
    //   325: goto -> 353
    //   328: iload_1
    //   329: iconst_1
    //   330: iadd
    //   331: istore_1
    //   332: goto -> 293
    //   335: aload #6
    //   337: getfield b : Ljava/util/Map;
    //   340: aload_0
    //   341: getstatic java/lang/Boolean.FALSE : Ljava/lang/Boolean;
    //   344: invokeinterface put : (Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    //   349: pop
    //   350: iconst_0
    //   351: istore #5
    //   353: iload #5
    //   355: ifeq -> 363
    //   358: iload_3
    //   359: istore_1
    //   360: goto -> 589
    //   363: aload_0
    //   364: invokevirtual getSuperclass : ()Ljava/lang/Class;
    //   367: astore #7
    //   369: aload #7
    //   371: ifnull -> 389
    //   374: ldc androidx/lifecycle/h
    //   376: aload #7
    //   378: invokevirtual isAssignableFrom : (Ljava/lang/Class;)Z
    //   381: ifeq -> 389
    //   384: iconst_1
    //   385: istore_1
    //   386: goto -> 391
    //   389: iconst_0
    //   390: istore_1
    //   391: aload #8
    //   393: astore #6
    //   395: iload_1
    //   396: ifeq -> 436
    //   399: aload #7
    //   401: invokestatic c : (Ljava/lang/Class;)I
    //   404: iconst_1
    //   405: if_icmpne -> 413
    //   408: iload_3
    //   409: istore_1
    //   410: goto -> 589
    //   413: new java/util/ArrayList
    //   416: dup
    //   417: getstatic androidx/lifecycle/m.b : Ljava/util/Map;
    //   420: checkcast java/util/HashMap
    //   423: aload #7
    //   425: invokevirtual get : (Ljava/lang/Object;)Ljava/lang/Object;
    //   428: checkcast java/util/Collection
    //   431: invokespecial <init> : (Ljava/util/Collection;)V
    //   434: astore #6
    //   436: aload_0
    //   437: invokevirtual getInterfaces : ()[Ljava/lang/Class;
    //   440: astore #8
    //   442: aload #8
    //   444: arraylength
    //   445: istore #4
    //   447: iconst_0
    //   448: istore_1
    //   449: iload_1
    //   450: iload #4
    //   452: if_icmpge -> 555
    //   455: aload #8
    //   457: iload_1
    //   458: aaload
    //   459: astore #9
    //   461: aload #9
    //   463: ifnull -> 481
    //   466: ldc androidx/lifecycle/h
    //   468: aload #9
    //   470: invokevirtual isAssignableFrom : (Ljava/lang/Class;)Z
    //   473: ifeq -> 481
    //   476: iconst_1
    //   477: istore_2
    //   478: goto -> 483
    //   481: iconst_0
    //   482: istore_2
    //   483: iload_2
    //   484: ifne -> 490
    //   487: goto -> 548
    //   490: aload #9
    //   492: invokestatic c : (Ljava/lang/Class;)I
    //   495: iconst_1
    //   496: if_icmpne -> 504
    //   499: iload_3
    //   500: istore_1
    //   501: goto -> 589
    //   504: aload #6
    //   506: astore #7
    //   508: aload #6
    //   510: ifnonnull -> 522
    //   513: new java/util/ArrayList
    //   516: dup
    //   517: invokespecial <init> : ()V
    //   520: astore #7
    //   522: aload #7
    //   524: getstatic androidx/lifecycle/m.b : Ljava/util/Map;
    //   527: checkcast java/util/HashMap
    //   530: aload #9
    //   532: invokevirtual get : (Ljava/lang/Object;)Ljava/lang/Object;
    //   535: checkcast java/util/Collection
    //   538: invokeinterface addAll : (Ljava/util/Collection;)Z
    //   543: pop
    //   544: aload #7
    //   546: astore #6
    //   548: iload_1
    //   549: iconst_1
    //   550: iadd
    //   551: istore_1
    //   552: goto -> 449
    //   555: iload_3
    //   556: istore_1
    //   557: aload #6
    //   559: ifnull -> 589
    //   562: getstatic androidx/lifecycle/m.b : Ljava/util/Map;
    //   565: astore #8
    //   567: aload #6
    //   569: astore #7
    //   571: aload #8
    //   573: astore #6
    //   575: aload #6
    //   577: checkcast java/util/HashMap
    //   580: aload_0
    //   581: aload #7
    //   583: invokevirtual put : (Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    //   586: pop
    //   587: iconst_2
    //   588: istore_1
    //   589: getstatic androidx/lifecycle/m.a : Ljava/util/Map;
    //   592: checkcast java/util/HashMap
    //   595: aload_0
    //   596: iload_1
    //   597: invokestatic valueOf : (I)Ljava/lang/Integer;
    //   600: invokevirtual put : (Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    //   603: pop
    //   604: iload_1
    //   605: ireturn
    //   606: astore_0
    //   607: new java/lang/IllegalArgumentException
    //   610: dup
    //   611: ldc 'The observer class has some methods that use newer APIs which are not available in the current OS version. Lifecycles cannot access even other methods so you should make sure that your observer classes only access framework classes that are available in your min API level OR use lifecycle:compiler annotation processor.'
    //   613: aload_0
    //   614: invokespecial <init> : (Ljava/lang/String;Ljava/lang/Throwable;)V
    //   617: athrow
    //   618: astore #6
    //   620: goto -> 214
    //   623: ldc ''
    //   625: astore #6
    //   627: goto -> 74
    // Exception table:
    //   from	to	target	type
    //   47	59	618	java/lang/ClassNotFoundException
    //   47	59	204	java/lang/NoSuchMethodException
    //   64	71	618	java/lang/ClassNotFoundException
    //   64	71	204	java/lang/NoSuchMethodException
    //   74	82	618	java/lang/ClassNotFoundException
    //   74	82	204	java/lang/NoSuchMethodException
    //   85	99	618	java/lang/ClassNotFoundException
    //   85	99	204	java/lang/NoSuchMethodException
    //   99	114	618	java/lang/ClassNotFoundException
    //   99	114	204	java/lang/NoSuchMethodException
    //   121	161	618	java/lang/ClassNotFoundException
    //   121	161	204	java/lang/NoSuchMethodException
    //   161	179	618	java/lang/ClassNotFoundException
    //   161	179	204	java/lang/NoSuchMethodException
    //   183	197	618	java/lang/ClassNotFoundException
    //   183	197	204	java/lang/NoSuchMethodException
    //   281	287	606	java/lang/NoClassDefFoundError
  }
}


/* Location:              C:\soft\dex2jar-2.0\Luxury Logo Maker_ Logo Design-dex2jar.jar!\androidx\lifecycle\m.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */