package androidx.lifecycle;

import android.os.Handler;

public class r implements i {
  public static final r p = new r();
  
  public int h = 0;
  
  public int i = 0;
  
  public boolean j = true;
  
  public boolean k = true;
  
  public Handler l;
  
  public final j m = new j(this);
  
  public Runnable n = new a(this);
  
  public t.a o = new b(this);
  
  public e a() {
    return this.m;
  }
  
  public class a implements Runnable {
    public a(r this$0) {}
    
    public void run() {
      r r1 = this.h;
      if (r1.i == 0) {
        r1.j = true;
        r1.m.d(e.b.ON_PAUSE);
      } 
      r1 = this.h;
      if (r1.h == 0 && r1.j) {
        r1.m.d(e.b.ON_STOP);
        r1.k = true;
      } 
    }
  }
  
  public class b implements t.a {
    public b(r this$0) {}
  }
}


/* Location:              C:\soft\dex2jar-2.0\Luxury Logo Maker_ Logo Design-dex2jar.jar!\androidx\lifecycle\r.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */