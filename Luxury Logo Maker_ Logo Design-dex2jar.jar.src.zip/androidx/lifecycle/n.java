package androidx.lifecycle;

import e4.ay1;
import e4.uy1;
import java.util.HashMap;
import n3.k0;

public class n implements ay1 {
  public Object h = new HashMap<Object, Object>();
  
  public uy1 zza() {
    k0 k0 = (k0)this.h;
    return k0.z3(k0.j, null, "BANNER", null, null).a();
  }
}


/* Location:              C:\soft\dex2jar-2.0\Luxury Logo Maker_ Logo Design-dex2jar.jar!\androidx\lifecycle\n.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */