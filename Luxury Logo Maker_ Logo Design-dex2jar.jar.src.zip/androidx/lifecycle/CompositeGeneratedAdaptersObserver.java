package androidx.lifecycle;

class CompositeGeneratedAdaptersObserver implements g {
  public final d[] h;
  
  public CompositeGeneratedAdaptersObserver(d[] paramArrayOfd) {
    this.h = paramArrayOfd;
  }
  
  public void c(i parami, e.b paramb) {
    n n = new n();
    d[] arrayOfD = this.h;
    int k = arrayOfD.length;
    boolean bool = false;
    int j;
    for (j = 0; j < k; j++)
      arrayOfD[j].a(parami, paramb, false, n); 
    arrayOfD = this.h;
    k = arrayOfD.length;
    for (j = bool; j < k; j++)
      arrayOfD[j].a(parami, paramb, true, n); 
  }
}


/* Location:              C:\soft\dex2jar-2.0\Luxury Logo Maker_ Logo Design-dex2jar.jar!\androidx\lifecycle\CompositeGeneratedAdaptersObserver.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */