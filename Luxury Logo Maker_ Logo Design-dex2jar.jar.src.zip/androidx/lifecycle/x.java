package androidx.lifecycle;

public abstract class x extends y implements w {
  public abstract <T extends v> T a(String paramString, Class<T> paramClass);
}


/* Location:              C:\soft\dex2jar-2.0\Luxury Logo Maker_ Logo Design-dex2jar.jar!\androidx\lifecycle\x.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */