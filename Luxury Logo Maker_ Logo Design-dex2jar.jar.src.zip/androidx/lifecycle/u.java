package androidx.lifecycle;

import android.os.Handler;

public class u {
  public final j a;
  
  public final Handler b;
  
  public a c;
  
  public u(i parami) {
    this.a = new j(parami);
    this.b = new Handler();
  }
  
  public final void a(e.b paramb) {
    a a2 = this.c;
    if (a2 != null)
      a2.run(); 
    a a1 = new a(this.a, paramb);
    this.c = a1;
    this.b.postAtFrontOfQueue(a1);
  }
  
  public static class a implements Runnable {
    public final j h;
    
    public final e.b i;
    
    public boolean j = false;
    
    public a(j param1j, e.b param1b) {
      this.h = param1j;
      this.i = param1b;
    }
    
    public void run() {
      if (!this.j) {
        this.h.d(this.i);
        this.j = true;
      } 
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Luxury Logo Maker_ Logo Design-dex2jar.jar!\androidx\lifecycl\\u.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */