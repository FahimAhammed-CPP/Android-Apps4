package androidx.lifecycle;

import androidx.savedstate.a;

class SavedStateHandleController$1 implements g {
  public void c(i parami, e.b paramb) {
    if (paramb == e.b.ON_START) {
      j j = (j)this.h;
      j.c("removeObserver");
      j.a.j(this);
      this.i.c(SavedStateHandleController.a.class);
    } 
  }
}


/* Location:              C:\soft\dex2jar-2.0\Luxury Logo Maker_ Logo Design-dex2jar.jar!\androidx\lifecycle\SavedStateHandleController$1.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */