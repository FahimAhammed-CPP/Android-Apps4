package androidx.lifecycle;

class SingleGeneratedAdapterObserver implements g {
  public final d h;
  
  public SingleGeneratedAdapterObserver(d paramd) {
    this.h = paramd;
  }
  
  public void c(i parami, e.b paramb) {
    this.h.a(parami, paramb, false, null);
    this.h.a(parami, paramb, true, null);
  }
}


/* Location:              C:\soft\dex2jar-2.0\Luxury Logo Maker_ Logo Design-dex2jar.jar!\androidx\lifecycle\SingleGeneratedAdapterObserver.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */