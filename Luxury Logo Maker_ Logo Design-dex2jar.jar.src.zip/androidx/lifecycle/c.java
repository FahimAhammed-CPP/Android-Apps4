package androidx.lifecycle;

public interface c extends h {
  void a(i parami);
  
  void b(i parami);
  
  void d(i parami);
  
  void onDestroy(i parami);
  
  void onStart(i parami);
  
  void onStop(i parami);
}


/* Location:              C:\soft\dex2jar-2.0\Luxury Logo Maker_ Logo Design-dex2jar.jar!\androidx\lifecycle\c.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */