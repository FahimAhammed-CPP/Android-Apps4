package androidx.lifecycle;

class FullLifecycleObserverAdapter implements g {
  public final c h;
  
  public final g i;
  
  public FullLifecycleObserverAdapter(c paramc, g paramg) {
    this.h = paramc;
    this.i = paramg;
  }
  
  public void c(i parami, e.b paramb) {
    switch (a.a[paramb.ordinal()]) {
      case 7:
        throw new IllegalArgumentException("ON_ANY must not been send by anybody");
      case 6:
        this.h.onDestroy(parami);
        break;
      case 5:
        this.h.onStop(parami);
        break;
      case 4:
        this.h.d(parami);
        break;
      case 3:
        this.h.a(parami);
        break;
      case 2:
        this.h.onStart(parami);
        break;
      case 1:
        this.h.b(parami);
        break;
    } 
    g g1 = this.i;
    if (g1 != null)
      g1.c(parami, paramb); 
  }
}


/* Location:              C:\soft\dex2jar-2.0\Luxury Logo Maker_ Logo Design-dex2jar.jar!\androidx\lifecycle\FullLifecycleObserverAdapter.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */