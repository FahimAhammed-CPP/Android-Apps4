package androidx.lifecycle;

import android.app.Activity;
import android.app.Application;
import android.app.Fragment;
import android.app.FragmentManager;
import android.os.Build;
import android.os.Bundle;

public class t extends Fragment {
  public a h;
  
  public static void a(Activity paramActivity, e.b paramb) {
    j j;
    if (paramActivity instanceof k) {
      j = ((k)paramActivity).a();
      j.c("handleLifecycleEvent");
      j.f(paramb.a());
      return;
    } 
    if (j instanceof i) {
      e e = ((i)j).a();
      if (e instanceof j) {
        e = e;
        e.c("handleLifecycleEvent");
        e.f(paramb.a());
      } 
    } 
  }
  
  public static void c(Activity paramActivity) {
    if (Build.VERSION.SDK_INT >= 29)
      b.registerIn(paramActivity); 
    FragmentManager fragmentManager = paramActivity.getFragmentManager();
    if (fragmentManager.findFragmentByTag("androidx.lifecycle.LifecycleDispatcher.report_fragment_tag") == null) {
      fragmentManager.beginTransaction().add(new t(), "androidx.lifecycle.LifecycleDispatcher.report_fragment_tag").commit();
      fragmentManager.executePendingTransactions();
    } 
  }
  
  public final void b(e.b paramb) {
    if (Build.VERSION.SDK_INT < 29)
      a(getActivity(), paramb); 
  }
  
  public void onActivityCreated(Bundle paramBundle) {
    super.onActivityCreated(paramBundle);
    b(e.b.ON_CREATE);
  }
  
  public void onDestroy() {
    super.onDestroy();
    b(e.b.ON_DESTROY);
    this.h = null;
  }
  
  public void onPause() {
    super.onPause();
    b(e.b.ON_PAUSE);
  }
  
  public void onResume() {
    super.onResume();
    a a1 = this.h;
    if (a1 != null) {
      r r = ((r.b)a1).a;
      int i = r.i + 1;
      r.i = i;
      if (i == 1)
        if (r.j) {
          r.m.d(e.b.ON_RESUME);
          r.j = false;
        } else {
          r.l.removeCallbacks(r.n);
        }  
    } 
    b(e.b.ON_RESUME);
  }
  
  public void onStart() {
    super.onStart();
    a a1 = this.h;
    if (a1 != null) {
      r r = ((r.b)a1).a;
      int i = r.h + 1;
      r.h = i;
      if (i == 1 && r.k) {
        r.m.d(e.b.ON_START);
        r.k = false;
      } 
    } 
    b(e.b.ON_START);
  }
  
  public void onStop() {
    super.onStop();
    b(e.b.ON_STOP);
  }
  
  public static interface a {}
  
  public static class b implements Application.ActivityLifecycleCallbacks {
    public static void registerIn(Activity param1Activity) {
      param1Activity.registerActivityLifecycleCallbacks(new b());
    }
    
    public void onActivityCreated(Activity param1Activity, Bundle param1Bundle) {}
    
    public void onActivityDestroyed(Activity param1Activity) {}
    
    public void onActivityPaused(Activity param1Activity) {}
    
    public void onActivityPostCreated(Activity param1Activity, Bundle param1Bundle) {
      t.a(param1Activity, e.b.ON_CREATE);
    }
    
    public void onActivityPostResumed(Activity param1Activity) {
      t.a(param1Activity, e.b.ON_RESUME);
    }
    
    public void onActivityPostStarted(Activity param1Activity) {
      t.a(param1Activity, e.b.ON_START);
    }
    
    public void onActivityPreDestroyed(Activity param1Activity) {
      t.a(param1Activity, e.b.ON_DESTROY);
    }
    
    public void onActivityPrePaused(Activity param1Activity) {
      t.a(param1Activity, e.b.ON_PAUSE);
    }
    
    public void onActivityPreStopped(Activity param1Activity) {
      t.a(param1Activity, e.b.ON_STOP);
    }
    
    public void onActivityResumed(Activity param1Activity) {}
    
    public void onActivitySaveInstanceState(Activity param1Activity, Bundle param1Bundle) {}
    
    public void onActivityStarted(Activity param1Activity) {}
    
    public void onActivityStopped(Activity param1Activity) {}
  }
}


/* Location:              C:\soft\dex2jar-2.0\Luxury Logo Maker_ Logo Design-dex2jar.jar!\androidx\lifecycle\t.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */