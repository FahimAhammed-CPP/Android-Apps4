package androidx.lifecycle;

import java.util.HashMap;

public class z {
  public final HashMap<String, v> a = new HashMap<String, v>();
  
  public final void a() {
    // Byte code:
    //   0: aload_0
    //   1: getfield a : Ljava/util/HashMap;
    //   4: invokevirtual values : ()Ljava/util/Collection;
    //   7: invokeinterface iterator : ()Ljava/util/Iterator;
    //   12: astore_3
    //   13: aload_3
    //   14: invokeinterface hasNext : ()Z
    //   19: ifeq -> 132
    //   22: aload_3
    //   23: invokeinterface next : ()Ljava/lang/Object;
    //   28: checkcast androidx/lifecycle/v
    //   31: astore #4
    //   33: aload #4
    //   35: getfield a : Ljava/util/Map;
    //   38: astore_2
    //   39: aload_2
    //   40: ifnull -> 124
    //   43: aload_2
    //   44: monitorenter
    //   45: aload #4
    //   47: getfield a : Ljava/util/Map;
    //   50: invokeinterface values : ()Ljava/util/Collection;
    //   55: invokeinterface iterator : ()Ljava/util/Iterator;
    //   60: astore #5
    //   62: aload #5
    //   64: invokeinterface hasNext : ()Z
    //   69: ifeq -> 114
    //   72: aload #5
    //   74: invokeinterface next : ()Ljava/lang/Object;
    //   79: astore #6
    //   81: aload #6
    //   83: instanceof java/io/Closeable
    //   86: istore_1
    //   87: iload_1
    //   88: ifeq -> 62
    //   91: aload #6
    //   93: checkcast java/io/Closeable
    //   96: invokeinterface close : ()V
    //   101: goto -> 62
    //   104: astore_3
    //   105: new java/lang/RuntimeException
    //   108: dup
    //   109: aload_3
    //   110: invokespecial <init> : (Ljava/lang/Throwable;)V
    //   113: athrow
    //   114: aload_2
    //   115: monitorexit
    //   116: goto -> 124
    //   119: astore_3
    //   120: aload_2
    //   121: monitorexit
    //   122: aload_3
    //   123: athrow
    //   124: aload #4
    //   126: invokevirtual a : ()V
    //   129: goto -> 13
    //   132: aload_0
    //   133: getfield a : Ljava/util/HashMap;
    //   136: invokevirtual clear : ()V
    //   139: return
    // Exception table:
    //   from	to	target	type
    //   45	62	119	finally
    //   62	87	119	finally
    //   91	101	104	java/io/IOException
    //   91	101	119	finally
    //   105	114	119	finally
    //   114	116	119	finally
    //   120	122	119	finally
  }
}


/* Location:              C:\soft\dex2jar-2.0\Luxury Logo Maker_ Logo Design-dex2jar.jar!\androidx\lifecycle\z.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */