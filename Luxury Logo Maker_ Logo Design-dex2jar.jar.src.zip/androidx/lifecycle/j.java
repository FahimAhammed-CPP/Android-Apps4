package androidx.lifecycle;

import android.annotation.SuppressLint;
import android.support.v4.media.c;
import d0.c;
import java.lang.ref.WeakReference;
import java.lang.reflect.Constructor;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import m.b;

public class j extends e {
  public m.a<h, a> a = new m.a();
  
  public e.c b;
  
  public final WeakReference<i> c;
  
  public int d = 0;
  
  public boolean e = false;
  
  public boolean f = false;
  
  public ArrayList<e.c> g = new ArrayList<e.c>();
  
  public final boolean h;
  
  public j(i parami) {
    this.c = new WeakReference<i>(parami);
    this.b = e.c.i;
    this.h = true;
  }
  
  public static e.c e(e.c paramc1, e.c paramc2) {
    e.c c1 = paramc1;
    if (paramc2 != null) {
      c1 = paramc1;
      if (paramc2.compareTo(paramc1) < 0)
        c1 = paramc2; 
    } 
    return c1;
  }
  
  public void a(h paramh) {
    boolean bool;
    c("addObserver");
    e.c c2 = this.b;
    e.c c1 = e.c.h;
    if (c2 != c1)
      c1 = e.c.i; 
    a a1 = new a(paramh, c1);
    if ((a)this.a.i(paramh, a1) != null)
      return; 
    i i = this.c.get();
    if (i == null)
      return; 
    if (this.d != 0 || this.e) {
      bool = true;
    } else {
      bool = false;
    } 
    c1 = b(paramh);
    this.d++;
    while (a1.a.compareTo(c1) < 0 && this.a.l.containsKey(paramh)) {
      c1 = a1.a;
      this.g.add(c1);
      e.b b = e.b.d(a1.a);
      if (b != null) {
        a1.a(i, b);
        g();
        e.c c3 = b(paramh);
        continue;
      } 
      StringBuilder stringBuilder = c.a("no event up from ");
      stringBuilder.append(a1.a);
      throw new IllegalStateException(stringBuilder.toString());
    } 
    if (!bool)
      h(); 
    this.d--;
  }
  
  public final e.c b(h paramh) {
    e.c c1;
    m.a<h, a> a1 = this.a;
    boolean bool = a1.l.containsKey(paramh);
    ArrayList<e.c> arrayList = null;
    if (bool) {
      b.c c2 = ((b.c)a1.l.get(paramh)).k;
    } else {
      paramh = null;
    } 
    if (paramh != null) {
      e.c c2 = ((a)((b.c)paramh).i).a;
    } else {
      paramh = null;
    } 
    if (!this.g.isEmpty()) {
      arrayList = this.g;
      c1 = arrayList.get(arrayList.size() - 1);
    } 
    return e(e(this.b, (e.c)paramh), c1);
  }
  
  @SuppressLint({"RestrictedApi"})
  public final void c(String paramString) {
    if (this.h) {
      if (l.a.t().c())
        return; 
      throw new IllegalStateException(c.a("Method ", paramString, " must be called on the main thread"));
    } 
  }
  
  public void d(e.b paramb) {
    c("handleLifecycleEvent");
    f(paramb.a());
  }
  
  public final void f(e.c paramc) {
    if (this.b == paramc)
      return; 
    this.b = paramc;
    if (this.e || this.d != 0) {
      this.f = true;
      return;
    } 
    this.e = true;
    h();
    this.e = false;
  }
  
  public final void g() {
    ArrayList<e.c> arrayList = this.g;
    arrayList.remove(arrayList.size() - 1);
  }
  
  public final void h() {
    i i = this.c.get();
    if (i != null) {
      while (true) {
        m.a<h, a> a1 = this.a;
        int m = ((b)a1).k;
        int k = 1;
        if (m != 0) {
          e.c c1 = ((a)((b)a1).h.i).a;
          e.c c2 = ((a)((b)a1).i.i).a;
          if (c1 != c2 || this.b != c2)
            k = 0; 
        } 
        this.f = false;
        if (!k) {
          if (this.b.compareTo(((a)((b)a1).h.i).a) < 0) {
            a1 = this.a;
            b.b b = new b.b(((b)a1).i, ((b)a1).h);
            ((b)a1).j.put(b, Boolean.FALSE);
            while (b.hasNext() && !this.f) {
              Map.Entry entry = (Map.Entry)b.next();
              a a2 = (a)entry.getValue();
              while (a2.a.compareTo(this.b) > 0 && !this.f && this.a.contains(entry.getKey())) {
                e.b b1;
                k = a2.a.ordinal();
                if (k != 2) {
                  if (k != 3) {
                    if (k != 4) {
                      a1 = null;
                    } else {
                      b1 = e.b.ON_PAUSE;
                    } 
                  } else {
                    b1 = e.b.ON_STOP;
                  } 
                } else {
                  b1 = e.b.ON_DESTROY;
                } 
                if (b1 != null) {
                  e.c c2 = b1.a();
                  this.g.add(c2);
                  a2.a(i, b1);
                  g();
                  continue;
                } 
                StringBuilder stringBuilder = c.a("no event down from ");
                stringBuilder.append(a2.a);
                throw new IllegalStateException(stringBuilder.toString());
              } 
            } 
          } 
          b.c c1 = ((b)this.a).i;
          if (!this.f && c1 != null && this.b.compareTo(((a)c1.i).a) > 0) {
            b.d d = this.a.g();
            while (d.hasNext() && !this.f) {
              Map.Entry entry = (Map.Entry)d.next();
              a a2 = (a)entry.getValue();
              while (a2.a.compareTo(this.b) < 0 && !this.f && this.a.contains(entry.getKey())) {
                e.c c2 = a2.a;
                this.g.add(c2);
                e.b b = e.b.d(a2.a);
                if (b != null) {
                  a2.a(i, b);
                  g();
                  continue;
                } 
                StringBuilder stringBuilder = c.a("no event up from ");
                stringBuilder.append(a2.a);
                throw new IllegalStateException(stringBuilder.toString());
              } 
            } 
          } 
          continue;
        } 
        break;
      } 
      return;
    } 
    throw new IllegalStateException("LifecycleOwner of this LifecycleRegistry is alreadygarbage collected. It is too late to change lifecycle state.");
  }
  
  public static class a {
    public e.c a;
    
    public g b;
    
    public a(h param1h, e.c param1c) {
      Map<Class<?>, Integer> map = m.a;
      boolean bool1 = param1h instanceof g;
      boolean bool2 = param1h instanceof c;
      if (bool1 && bool2) {
        param1h = new FullLifecycleObserverAdapter((c)param1h, (g)param1h);
      } else if (bool2) {
        param1h = new FullLifecycleObserverAdapter((c)param1h, null);
      } else if (bool1) {
        param1h = param1h;
      } else {
        Class<?> clazz = param1h.getClass();
        if (m.c(clazz) == 2) {
          List<Constructor<? extends d>> list = (List)((HashMap)m.b).get(clazz);
          int j = list.size();
          int i = 0;
          if (j == 1) {
            param1h = new SingleGeneratedAdapterObserver(m.a(list.get(0), param1h));
          } else {
            d[] arrayOfD = new d[list.size()];
            while (i < list.size()) {
              arrayOfD[i] = m.a(list.get(i), param1h);
              i++;
            } 
            param1h = new CompositeGeneratedAdaptersObserver(arrayOfD);
          } 
        } else {
          param1h = new ReflectiveGenericLifecycleObserver(param1h);
        } 
      } 
      this.b = (g)param1h;
      this.a = param1c;
    }
    
    public void a(i param1i, e.b param1b) {
      e.c c1 = param1b.a();
      this.a = j.e(this.a, c1);
      this.b.c(param1i, param1b);
      this.a = c1;
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Luxury Logo Maker_ Logo Design-dex2jar.jar!\androidx\lifecycle\j.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */