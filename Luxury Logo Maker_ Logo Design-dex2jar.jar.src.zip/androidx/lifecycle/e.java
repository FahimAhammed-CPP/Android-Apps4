package androidx.lifecycle;

import java.util.concurrent.atomic.AtomicReference;

public abstract class e {
  public e() {
    new AtomicReference();
  }
  
  public abstract void a(h paramh);
  
  public enum b {
    ON_ANY, ON_CREATE, ON_DESTROY, ON_PAUSE, ON_RESUME, ON_START, ON_STOP;
    
    static {
      b b1 = new b("ON_CREATE", 0);
      ON_CREATE = b1;
      b b2 = new b("ON_START", 1);
      ON_START = b2;
      b b3 = new b("ON_RESUME", 2);
      ON_RESUME = b3;
      b b4 = new b("ON_PAUSE", 3);
      ON_PAUSE = b4;
      b b5 = new b("ON_STOP", 4);
      ON_STOP = b5;
      b b6 = new b("ON_DESTROY", 5);
      ON_DESTROY = b6;
      b b7 = new b("ON_ANY", 6);
      ON_ANY = b7;
      $VALUES = new b[] { b1, b2, b3, b4, b5, b6, b7 };
    }
    
    public static b d(e.c param1c) {
      int i = param1c.ordinal();
      return (i != 1) ? ((i != 2) ? ((i != 3) ? null : ON_RESUME) : ON_START) : ON_CREATE;
    }
    
    public e.c a() {
      StringBuilder stringBuilder;
      switch (e.a.b[ordinal()]) {
        default:
          stringBuilder = new StringBuilder();
          stringBuilder.append(this);
          stringBuilder.append(" has no target state");
          throw new IllegalArgumentException(stringBuilder.toString());
        case 6:
          return e.c.h;
        case 5:
          return e.c.l;
        case 3:
        case 4:
          return e.c.k;
        case 1:
        case 2:
          break;
      } 
      return e.c.j;
    }
  }
  
  public enum c {
    h, i, j, k, l;
    
    static {
      c c1 = new c("DESTROYED", 0);
      h = c1;
      c c2 = new c("INITIALIZED", 1);
      i = c2;
      c c3 = new c("CREATED", 2);
      j = c3;
      c c4 = new c("STARTED", 3);
      k = c4;
      c c5 = new c("RESUMED", 4);
      l = c5;
      m = new c[] { c1, c2, c3, c4, c5 };
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Luxury Logo Maker_ Logo Design-dex2jar.jar!\androidx\lifecycle\e.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */