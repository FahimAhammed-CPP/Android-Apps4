package androidx.lifecycle;

import java.util.HashMap;
import java.util.Map;

public abstract class v {
  public final Map<String, Object> a = new HashMap<String, Object>();
  
  public void a() {}
}


/* Location:              C:\soft\dex2jar-2.0\Luxury Logo Maker_ Logo Design-dex2jar.jar!\androidx\lifecycle\v.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */