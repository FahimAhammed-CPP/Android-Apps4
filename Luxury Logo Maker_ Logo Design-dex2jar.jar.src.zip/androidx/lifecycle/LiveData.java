package androidx.lifecycle;

import android.util.Log;
import android.view.View;
import androidx.fragment.app.d0;
import androidx.fragment.app.m;
import java.util.Map;
import java.util.Objects;

public abstract class LiveData<T> {
  public static final Object k = new Object();
  
  public final Object a = new Object();
  
  public m.b<p<? super T>, c> b = new m.b();
  
  public int c = 0;
  
  public boolean d;
  
  public volatile Object e;
  
  public volatile Object f;
  
  public int g;
  
  public boolean h;
  
  public boolean i;
  
  public final Runnable j;
  
  public LiveData() {
    Object object = k;
    this.f = object;
    this.j = new a(this);
    this.e = object;
    this.g = -1;
  }
  
  public static void a(String paramString) {
    if (l.a.t().c())
      return; 
    throw new IllegalStateException(d0.c.a("Cannot invoke ", paramString, " on a background thread"));
  }
  
  public final void b(c paramc) {
    if (!paramc.i)
      return; 
    if (!paramc.g()) {
      paramc.e(false);
      return;
    } 
    int i = paramc.j;
    int j = this.g;
    if (i >= j)
      return; 
    paramc.j = j;
    p<? super T> p = paramc.h;
    Object object = this.e;
    m.d d = (m.d)p;
    Objects.requireNonNull(d);
    if ((i)object != null) {
      object = d.a;
      if (((m)object).g0) {
        object = object.Y();
        if (object.getParent() == null) {
          if (d.a.k0 != null) {
            if (d0.O(3)) {
              StringBuilder stringBuilder = new StringBuilder();
              stringBuilder.append("DialogFragment ");
              stringBuilder.append(d);
              stringBuilder.append(" setting the content view on ");
              stringBuilder.append(d.a.k0);
              Log.d("FragmentManager", stringBuilder.toString());
            } 
            d.a.k0.setContentView((View)object);
            return;
          } 
        } else {
          throw new IllegalStateException("DialogFragment can not be attached to a container view");
        } 
      } 
    } 
  }
  
  public void c(c paramc) {
    if (this.h) {
      this.i = true;
      return;
    } 
    this.h = true;
    while (true) {
      c c1;
      this.i = false;
      if (paramc != null) {
        b(paramc);
        c1 = null;
      } else {
        m.b.d d = this.b.g();
        while (true) {
          c1 = paramc;
          if (d.hasNext()) {
            b((c)((Map.Entry)d.next()).getValue());
            if (this.i) {
              c1 = paramc;
              break;
            } 
            continue;
          } 
          break;
        } 
      } 
      paramc = c1;
      if (!this.i) {
        this.h = false;
        return;
      } 
    } 
  }
  
  public void d(p<? super T> paramp) {
    a("observeForever");
    b b1 = new b(this, paramp);
    c c = (c)this.b.i(paramp, b1);
    if (!(c instanceof LifecycleBoundObserver)) {
      if (c != null)
        return; 
      b1.e(true);
      return;
    } 
    throw new IllegalArgumentException("Cannot add the same observer with different lifecycles");
  }
  
  public void e() {}
  
  public void f() {}
  
  public void g(p<? super T> paramp) {
    a("removeObserver");
    c c = (c)this.b.j(paramp);
    if (c == null)
      return; 
    c.f();
    c.e(false);
  }
  
  public abstract void h(T paramT);
  
  public class LifecycleBoundObserver extends c implements g {
    public final i l;
    
    public void c(i param1i, e.b param1b) {
      e.c c1 = ((j)this.l.a()).b;
      if (c1 == e.c.h) {
        this.m.g(this.h);
        return;
      } 
      param1b = null;
      while (param1b != c1) {
        e(g());
        e.c c3 = ((j)this.l.a()).b;
        e.c c2 = c1;
        c1 = c3;
      } 
    }
    
    public void f() {
      j j = (j)this.l.a();
      j.c("removeObserver");
      j.a.j(this);
    }
    
    public boolean g() {
      return (((j)this.l.a()).b.compareTo(e.c.k) >= 0);
    }
  }
  
  public class a implements Runnable {
    public a(LiveData this$0) {}
    
    public void run() {
      synchronized (this.h.a) {
        Object object = this.h.f;
        this.h.f = LiveData.k;
        this.h.h(object);
        return;
      } 
    }
  }
  
  public class b extends c {
    public b(LiveData this$0, p<? super T> param1p) {
      super(this$0, param1p);
    }
    
    public boolean g() {
      return true;
    }
  }
  
  public abstract class c {
    public final p<? super T> h;
    
    public boolean i;
    
    public int j = -1;
    
    public c(LiveData this$0, p<? super T> param1p) {
      this.h = param1p;
    }
    
    public void e(boolean param1Boolean) {
      byte b;
      if (param1Boolean == this.i)
        return; 
      this.i = param1Boolean;
      LiveData liveData = this.k;
      if (param1Boolean) {
        b = 1;
      } else {
        b = -1;
      } 
      int i = liveData.c;
      liveData.c = b + i;
      if (!liveData.d) {
        liveData.d = true;
        while (true) {
          int j;
          try {
            j = liveData.c;
          } finally {
            liveData.d = false;
          } 
          if (i > 0 && j == 0) {
            i = 1;
          } else {
            i = 0;
          } 
          if (b != 0) {
            liveData.e();
          } else if (i != 0) {
            liveData.f();
          } 
          i = j;
        } 
      } 
      if (this.i)
        this.k.c(this); 
    }
    
    public void f() {}
    
    public abstract boolean g();
  }
}


/* Location:              C:\soft\dex2jar-2.0\Luxury Logo Maker_ Logo Design-dex2jar.jar!\androidx\lifecycle\LiveData.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */