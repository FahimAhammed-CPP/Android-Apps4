package androidx.lifecycle;

public class y {}


/* Location:              C:\soft\dex2jar-2.0\Luxury Logo Maker_ Logo Design-dex2jar.jar!\androidx\lifecycle\y.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */