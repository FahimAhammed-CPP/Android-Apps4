package androidx.activity;

import a0.e;
import android.annotation.SuppressLint;
import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.content.IntentSender;
import android.os.Build;
import android.os.Bundle;
import android.os.Trace;
import android.text.TextUtils;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import androidx.activity.result.e;
import androidx.activity.result.f;
import androidx.lifecycle.a0;
import androidx.lifecycle.g;
import androidx.lifecycle.h;
import androidx.lifecycle.i;
import androidx.lifecycle.j;
import androidx.lifecycle.t;
import androidx.lifecycle.z;
import androidx.savedstate.c;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.Objects;
import java.util.Random;
import java.util.concurrent.atomic.AtomicInteger;

public class ComponentActivity extends e implements a0, c, c, f {
  public final c.a i;
  
  public final j j;
  
  public final androidx.savedstate.b k;
  
  public z l;
  
  public final OnBackPressedDispatcher m;
  
  public final e n;
  
  public ComponentActivity() {
    c.a a1 = new c.a();
    this.i = a1;
    j j1 = new j(this);
    this.j = j1;
    androidx.savedstate.b b1 = new androidx.savedstate.b(this);
    this.k = b1;
    this.m = new OnBackPressedDispatcher(new a(this));
    new AtomicInteger();
    this.n = new b(this);
    int i = Build.VERSION.SDK_INT;
    j1.a((h)new g(this) {
          public void c(i param1i, androidx.lifecycle.e.b param1b) {
            if (param1b == androidx.lifecycle.e.b.ON_STOP) {
              Window window = this.h.getWindow();
              if (window != null) {
                View view = window.peekDecorView();
              } else {
                window = null;
              } 
              if (window != null)
                window.cancelPendingInputEvents(); 
            } 
          }
        });
    j1.a((h)new g(this) {
          public void c(i param1i, androidx.lifecycle.e.b param1b) {
            if (param1b == androidx.lifecycle.e.b.ON_DESTROY) {
              this.h.i.b = null;
              if (!this.h.isChangingConfigurations())
                this.h.j().a(); 
            } 
          }
        });
    j1.a((h)new g(this) {
          public void c(i param1i, androidx.lifecycle.e.b param1b) {
            this.h.l();
            j j = this.h.j;
            j.c("removeObserver");
            j.a.j(this);
          }
        });
    if (i <= 23)
      j1.a((h)new ImmLeaksCleaner((Activity)this)); 
    b1.b.b("android:support:activity-result", new c(this));
    d d = new d(this);
    if (a1.b != null)
      d.a(a1.b); 
    a1.a.add(d);
  }
  
  public androidx.lifecycle.e a() {
    return (androidx.lifecycle.e)this.j;
  }
  
  public void addContentView(@SuppressLint({"UnknownNullness", "MissingNullability"}) View paramView, @SuppressLint({"UnknownNullness", "MissingNullability"}) ViewGroup.LayoutParams paramLayoutParams) {
    m();
    super.addContentView(paramView, paramLayoutParams);
  }
  
  public final OnBackPressedDispatcher c() {
    return this.m;
  }
  
  public final androidx.savedstate.a d() {
    return this.k.b;
  }
  
  public final e h() {
    return this.n;
  }
  
  public z j() {
    if (getApplication() != null) {
      l();
      return this.l;
    } 
    throw new IllegalStateException("Your activity is not yet attached to the Application instance. You can't request ViewModel before onCreate call.");
  }
  
  public void l() {
    if (this.l == null) {
      e e1 = (e)getLastNonConfigurationInstance();
      if (e1 != null)
        this.l = e1.a; 
      if (this.l == null)
        this.l = new z(); 
    } 
  }
  
  public final void m() {
    getWindow().getDecorView().setTag(2131362471, this);
    getWindow().getDecorView().setTag(2131362473, this);
    getWindow().getDecorView().setTag(2131362472, this);
  }
  
  @Deprecated
  public void onActivityResult(int paramInt1, int paramInt2, Intent paramIntent) {
    if (!this.n.a(paramInt1, paramInt2, paramIntent))
      super.onActivityResult(paramInt1, paramInt2, paramIntent); 
  }
  
  public void onBackPressed() {
    this.m.b();
  }
  
  public void onCreate(Bundle paramBundle) {
    this.k.a(paramBundle);
    c.a a1 = this.i;
    a1.b = (Context)this;
    Iterator<c.b> iterator = a1.a.iterator();
    while (iterator.hasNext())
      ((c.b)iterator.next()).a((Context)this); 
    super.onCreate(paramBundle);
    t.c((Activity)this);
  }
  
  @Deprecated
  public void onRequestPermissionsResult(int paramInt, String[] paramArrayOfString, int[] paramArrayOfint) {
    if (!this.n.a(paramInt, -1, (new Intent()).putExtra("androidx.activity.result.contract.extra.PERMISSIONS", paramArrayOfString).putExtra("androidx.activity.result.contract.extra.PERMISSION_GRANT_RESULTS", paramArrayOfint)) && Build.VERSION.SDK_INT >= 23)
      super.onRequestPermissionsResult(paramInt, paramArrayOfString, paramArrayOfint); 
  }
  
  public final Object onRetainNonConfigurationInstance() {
    z z2 = this.l;
    z z1 = z2;
    if (z2 == null) {
      e e2 = (e)getLastNonConfigurationInstance();
      z1 = z2;
      if (e2 != null)
        z1 = e2.a; 
    } 
    if (z1 == null)
      return null; 
    e e1 = new e();
    e1.a = z1;
    return e1;
  }
  
  public void onSaveInstanceState(Bundle paramBundle) {
    j j1 = this.j;
    if (j1 instanceof j) {
      androidx.lifecycle.e.c c1 = androidx.lifecycle.e.c.j;
      j1.c("setCurrentState");
      j1.f(c1);
    } 
    super.onSaveInstanceState(paramBundle);
    this.k.b(paramBundle);
  }
  
  public void reportFullyDrawn() {
    try {
      if (d1.a.a()) {
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("reportFullyDrawn() for ");
        stringBuilder.append(getComponentName());
        Trace.beginSection(stringBuilder.toString());
      } 
      super.reportFullyDrawn();
      return;
    } finally {
      Trace.endSection();
    } 
  }
  
  public void setContentView(int paramInt) {
    m();
    super.setContentView(paramInt);
  }
  
  public void setContentView(@SuppressLint({"UnknownNullness", "MissingNullability"}) View paramView) {
    m();
    super.setContentView(paramView);
  }
  
  public void setContentView(@SuppressLint({"UnknownNullness", "MissingNullability"}) View paramView, @SuppressLint({"UnknownNullness", "MissingNullability"}) ViewGroup.LayoutParams paramLayoutParams) {
    m();
    super.setContentView(paramView, paramLayoutParams);
  }
  
  @Deprecated
  public void startActivityForResult(@SuppressLint({"UnknownNullness"}) Intent paramIntent, int paramInt) {
    super.startActivityForResult(paramIntent, paramInt);
  }
  
  @Deprecated
  public void startActivityForResult(@SuppressLint({"UnknownNullness"}) Intent paramIntent, int paramInt, Bundle paramBundle) {
    super.startActivityForResult(paramIntent, paramInt, paramBundle);
  }
  
  @Deprecated
  public void startIntentSenderForResult(@SuppressLint({"UnknownNullness"}) IntentSender paramIntentSender, int paramInt1, Intent paramIntent, int paramInt2, int paramInt3, int paramInt4) {
    super.startIntentSenderForResult(paramIntentSender, paramInt1, paramIntent, paramInt2, paramInt3, paramInt4);
  }
  
  @Deprecated
  public void startIntentSenderForResult(@SuppressLint({"UnknownNullness"}) IntentSender paramIntentSender, int paramInt1, Intent paramIntent, int paramInt2, int paramInt3, int paramInt4, Bundle paramBundle) {
    super.startIntentSenderForResult(paramIntentSender, paramInt1, paramIntent, paramInt2, paramInt3, paramInt4, paramBundle);
  }
  
  public class a implements Runnable {
    public a(ComponentActivity this$0) {}
    
    public void run() {
      try {
        ComponentActivity.k(this.h);
        return;
      } catch (IllegalStateException illegalStateException) {
        if (TextUtils.equals(illegalStateException.getMessage(), "Can not perform this action after onSaveInstanceState"))
          return; 
        throw illegalStateException;
      } 
    }
  }
  
  public class b extends e {
    public b(ComponentActivity this$0) {}
  }
  
  public class c implements androidx.savedstate.a.b {
    public c(ComponentActivity this$0) {}
    
    @SuppressLint({"SyntheticAccessor"})
    public Bundle a() {
      Bundle bundle = new Bundle();
      e e = this.a.n;
      Objects.requireNonNull(e);
      bundle.putIntegerArrayList("KEY_COMPONENT_ACTIVITY_REGISTERED_RCS", new ArrayList(e.c.values()));
      bundle.putStringArrayList("KEY_COMPONENT_ACTIVITY_REGISTERED_KEYS", new ArrayList(e.c.keySet()));
      bundle.putStringArrayList("KEY_COMPONENT_ACTIVITY_LAUNCHED_KEYS", new ArrayList(e.e));
      bundle.putBundle("KEY_COMPONENT_ACTIVITY_PENDING_RESULT", (Bundle)e.h.clone());
      bundle.putSerializable("KEY_COMPONENT_ACTIVITY_RANDOM_OBJECT", e.a);
      return bundle;
    }
  }
  
  public class d implements c.b {
    public d(ComponentActivity this$0) {}
    
    @SuppressLint({"SyntheticAccessor"})
    public void a(Context param1Context) {
      Bundle bundle = this.a.k.b.a("android:support:activity-result");
      if (bundle != null) {
        e e = this.a.n;
        Objects.requireNonNull(e);
        ArrayList<Integer> arrayList = bundle.getIntegerArrayList("KEY_COMPONENT_ACTIVITY_REGISTERED_RCS");
        ArrayList<String> arrayList1 = bundle.getStringArrayList("KEY_COMPONENT_ACTIVITY_REGISTERED_KEYS");
        if (arrayList1 != null) {
          if (arrayList == null)
            return; 
          e.e = bundle.getStringArrayList("KEY_COMPONENT_ACTIVITY_LAUNCHED_KEYS");
          e.a = (Random)bundle.getSerializable("KEY_COMPONENT_ACTIVITY_RANDOM_OBJECT");
          e.h.putAll(bundle.getBundle("KEY_COMPONENT_ACTIVITY_PENDING_RESULT"));
          for (int i = 0; i < arrayList1.size(); i++) {
            String str = arrayList1.get(i);
            if (e.c.containsKey(str)) {
              Integer integer = (Integer)e.c.remove(str);
              if (!e.h.containsKey(str))
                e.b.remove(integer); 
            } 
            int j = ((Integer)arrayList.get(i)).intValue();
            str = arrayList1.get(i);
            e.b.put(Integer.valueOf(j), str);
            e.c.put(str, Integer.valueOf(j));
          } 
        } 
      } 
    }
  }
  
  public static final class e {
    public z a;
  }
}


/* Location:              C:\soft\dex2jar-2.0\Luxury Logo Maker_ Logo Design-dex2jar.jar!\androidx\activity\ComponentActivity.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */