package androidx.activity;

import android.annotation.SuppressLint;
import androidx.lifecycle.e;
import androidx.lifecycle.g;
import androidx.lifecycle.h;
import androidx.lifecycle.i;
import androidx.lifecycle.j;
import java.util.ArrayDeque;
import java.util.Iterator;

public final class OnBackPressedDispatcher {
  public final Runnable a;
  
  public final ArrayDeque<b> b = new ArrayDeque<b>();
  
  public OnBackPressedDispatcher(Runnable paramRunnable) {
    this.a = paramRunnable;
  }
  
  @SuppressLint({"LambdaLast"})
  public void a(i parami, b paramb) {
    e e = parami.a();
    if (((j)e).b == e.c.h)
      return; 
    LifecycleOnBackPressedCancellable lifecycleOnBackPressedCancellable = new LifecycleOnBackPressedCancellable(this, e, paramb);
    paramb.b.add(lifecycleOnBackPressedCancellable);
  }
  
  public void b() {
    Iterator<b> iterator = this.b.descendingIterator();
    while (iterator.hasNext()) {
      b b = iterator.next();
      if (b.a) {
        b.a();
        return;
      } 
    } 
    Runnable runnable = this.a;
    if (runnable != null)
      runnable.run(); 
  }
  
  public class LifecycleOnBackPressedCancellable implements g, a {
    public final e h;
    
    public final b i;
    
    public a j;
    
    public LifecycleOnBackPressedCancellable(OnBackPressedDispatcher this$0, e param1e, b param1b) {
      this.h = param1e;
      this.i = param1b;
      param1e.a((h)this);
    }
    
    public void c(i param1i, e.b param1b) {
      OnBackPressedDispatcher.a a1;
      if (param1b == e.b.ON_START) {
        OnBackPressedDispatcher onBackPressedDispatcher = this.k;
        b b1 = this.i;
        onBackPressedDispatcher.b.add(b1);
        a1 = new OnBackPressedDispatcher.a(onBackPressedDispatcher, b1);
        b1.b.add(a1);
        this.j = a1;
        return;
      } 
      if (a1 == e.b.ON_STOP) {
        a a2 = this.j;
        if (a2 != null) {
          a2.cancel();
          return;
        } 
      } else if (a1 == e.b.ON_DESTROY) {
        cancel();
      } 
    }
    
    public void cancel() {
      j j = (j)this.h;
      j.c("removeObserver");
      j.a.j(this);
      this.i.b.remove(this);
      a a1 = this.j;
      if (a1 != null) {
        a1.cancel();
        this.j = null;
      } 
    }
  }
  
  public class a implements a {
    public final b h;
    
    public a(OnBackPressedDispatcher this$0, b param1b) {
      this.h = param1b;
    }
    
    public void cancel() {
      this.i.b.remove(this.h);
      this.h.b.remove(this);
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Luxury Logo Maker_ Logo Design-dex2jar.jar!\androidx\activity\OnBackPressedDispatcher.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */