package androidx.activity;

import android.app.Activity;
import android.view.View;
import android.view.inputmethod.InputMethodManager;
import androidx.lifecycle.e;
import androidx.lifecycle.g;
import androidx.lifecycle.i;
import java.lang.reflect.Field;

final class ImmLeaksCleaner implements g {
  public static int i;
  
  public static Field j;
  
  public static Field k;
  
  public static Field l;
  
  public Activity h;
  
  public ImmLeaksCleaner(Activity paramActivity) {
    this.h = paramActivity;
  }
  
  public void c(i parami, e.b paramb) {
    if (paramb != e.b.ON_DESTROY)
      return; 
    if (i == 0)
      try {
        i = 2;
        Field field = InputMethodManager.class.getDeclaredField("mServedView");
        k = field;
        field.setAccessible(true);
        field = InputMethodManager.class.getDeclaredField("mNextServedView");
        l = field;
        field.setAccessible(true);
        field = InputMethodManager.class.getDeclaredField("mH");
        j = field;
        field.setAccessible(true);
        i = 1;
      } catch (NoSuchFieldException noSuchFieldException) {} 
    if (i == 1) {
      InputMethodManager inputMethodManager = (InputMethodManager)this.h.getSystemService("input_method");
      try {
        Object object = j.get(inputMethodManager);
        if (object == null)
          return; 
        /* monitor enter ClassFileLocalVariableReferenceExpression{type=ObjectType{java/lang/Object}, name=null} */
        try {
          View view = (View)k.get(inputMethodManager);
          if (view == null) {
            /* monitor exit ClassFileLocalVariableReferenceExpression{type=ObjectType{java/lang/Object}, name=null} */
            return;
          } 
          if (view.isAttachedToWindow()) {
            /* monitor exit ClassFileLocalVariableReferenceExpression{type=ObjectType{java/lang/Object}, name=null} */
            return;
          } 
          try {
            l.set(inputMethodManager, null);
            /* monitor exit ClassFileLocalVariableReferenceExpression{type=ObjectType{java/lang/Object}, name=null} */
            inputMethodManager.isActive();
            return;
          } catch (IllegalAccessException illegalAccessException) {
            /* monitor exit ClassFileLocalVariableReferenceExpression{type=ObjectType{java/lang/Object}, name=null} */
            return;
          } 
        } catch (IllegalAccessException illegalAccessException) {
          /* monitor exit ClassFileLocalVariableReferenceExpression{type=ObjectType{java/lang/Object}, name=null} */
          return;
        } catch (ClassCastException classCastException) {
          /* monitor exit ClassFileLocalVariableReferenceExpression{type=ObjectType{java/lang/Object}, name=null} */
          return;
        } finally {}
        /* monitor exit ClassFileLocalVariableReferenceExpression{type=ObjectType{java/lang/Object}, name=null} */
        throw inputMethodManager;
      } catch (IllegalAccessException illegalAccessException) {
        return;
      } 
    } 
  }
}


/* Location:              C:\soft\dex2jar-2.0\Luxury Logo Maker_ Logo Design-dex2jar.jar!\androidx\activity\ImmLeaksCleaner.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */