package androidx.activity.result;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;
import java.util.Random;

public abstract class e {
  public Random a = new Random();
  
  public final Map<Integer, String> b = new HashMap<Integer, String>();
  
  public final Map<String, Integer> c = new HashMap<String, Integer>();
  
  public final Map<String, c> d = new HashMap<String, c>();
  
  public ArrayList<String> e = new ArrayList<String>();
  
  public final transient Map<String, b<?>> f = new HashMap<String, b<?>>();
  
  public final Map<String, Object> g = new HashMap<String, Object>();
  
  public final Bundle h = new Bundle();
  
  public final boolean a(int paramInt1, int paramInt2, Intent paramIntent) {
    String str = this.b.get(Integer.valueOf(paramInt1));
    if (str == null)
      return false; 
    this.e.remove(str);
    b b = this.f.get(str);
    if (b != null) {
      b<Object> b1 = b.a;
      if (b1 != null) {
        b1.a(b.b.a(paramInt2, paramIntent));
        return true;
      } 
    } 
    this.g.remove(str);
    this.h.putParcelable(str, new a(paramInt2, paramIntent));
    return true;
  }
  
  public final <I, O> c<I> b(String paramString, d.a<I, O> parama, b<O> paramb) {
    // Byte code:
    //   0: aload_0
    //   1: getfield c : Ljava/util/Map;
    //   4: aload_1
    //   5: invokeinterface get : (Ljava/lang/Object;)Ljava/lang/Object;
    //   10: checkcast java/lang/Integer
    //   13: astore #5
    //   15: aload #5
    //   17: ifnull -> 30
    //   20: aload #5
    //   22: invokevirtual intValue : ()I
    //   25: istore #4
    //   27: goto -> 111
    //   30: aload_0
    //   31: getfield a : Ljava/util/Random;
    //   34: ldc 2147418112
    //   36: invokevirtual nextInt : (I)I
    //   39: istore #4
    //   41: iload #4
    //   43: ldc 65536
    //   45: iadd
    //   46: istore #4
    //   48: aload_0
    //   49: getfield b : Ljava/util/Map;
    //   52: iload #4
    //   54: invokestatic valueOf : (I)Ljava/lang/Integer;
    //   57: invokeinterface containsKey : (Ljava/lang/Object;)Z
    //   62: ifeq -> 79
    //   65: aload_0
    //   66: getfield a : Ljava/util/Random;
    //   69: ldc 2147418112
    //   71: invokevirtual nextInt : (I)I
    //   74: istore #4
    //   76: goto -> 41
    //   79: aload_0
    //   80: getfield b : Ljava/util/Map;
    //   83: iload #4
    //   85: invokestatic valueOf : (I)Ljava/lang/Integer;
    //   88: aload_1
    //   89: invokeinterface put : (Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    //   94: pop
    //   95: aload_0
    //   96: getfield c : Ljava/util/Map;
    //   99: aload_1
    //   100: iload #4
    //   102: invokestatic valueOf : (I)Ljava/lang/Integer;
    //   105: invokeinterface put : (Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    //   110: pop
    //   111: aload_0
    //   112: getfield f : Ljava/util/Map;
    //   115: aload_1
    //   116: new androidx/activity/result/e$b
    //   119: dup
    //   120: aload_3
    //   121: aload_2
    //   122: invokespecial <init> : (Landroidx/activity/result/b;Ld/a;)V
    //   125: invokeinterface put : (Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    //   130: pop
    //   131: aload_0
    //   132: getfield g : Ljava/util/Map;
    //   135: aload_1
    //   136: invokeinterface containsKey : (Ljava/lang/Object;)Z
    //   141: ifeq -> 175
    //   144: aload_0
    //   145: getfield g : Ljava/util/Map;
    //   148: aload_1
    //   149: invokeinterface get : (Ljava/lang/Object;)Ljava/lang/Object;
    //   154: astore #5
    //   156: aload_0
    //   157: getfield g : Ljava/util/Map;
    //   160: aload_1
    //   161: invokeinterface remove : (Ljava/lang/Object;)Ljava/lang/Object;
    //   166: pop
    //   167: aload_3
    //   168: aload #5
    //   170: invokeinterface a : (Ljava/lang/Object;)V
    //   175: aload_0
    //   176: getfield h : Landroid/os/Bundle;
    //   179: aload_1
    //   180: invokevirtual getParcelable : (Ljava/lang/String;)Landroid/os/Parcelable;
    //   183: checkcast androidx/activity/result/a
    //   186: astore #5
    //   188: aload #5
    //   190: ifnull -> 221
    //   193: aload_0
    //   194: getfield h : Landroid/os/Bundle;
    //   197: aload_1
    //   198: invokevirtual remove : (Ljava/lang/String;)V
    //   201: aload_3
    //   202: aload_2
    //   203: aload #5
    //   205: getfield h : I
    //   208: aload #5
    //   210: getfield i : Landroid/content/Intent;
    //   213: invokevirtual a : (ILandroid/content/Intent;)Ljava/lang/Object;
    //   216: invokeinterface a : (Ljava/lang/Object;)V
    //   221: new androidx/activity/result/e$a
    //   224: dup
    //   225: aload_0
    //   226: aload_1
    //   227: iload #4
    //   229: aload_2
    //   230: invokespecial <init> : (Landroidx/activity/result/e;Ljava/lang/String;ILd/a;)V
    //   233: areturn
  }
  
  public final void c(String paramString) {
    if (!this.e.contains(paramString)) {
      Integer integer = this.c.remove(paramString);
      if (integer != null)
        this.b.remove(integer); 
    } 
    this.f.remove(paramString);
    if (this.g.containsKey(paramString)) {
      StringBuilder stringBuilder = d.a("Dropping pending result for request ", paramString, ": ");
      stringBuilder.append(this.g.get(paramString));
      Log.w("ActivityResultRegistry", stringBuilder.toString());
      this.g.remove(paramString);
    } 
    if (this.h.containsKey(paramString)) {
      StringBuilder stringBuilder = d.a("Dropping pending result for request ", paramString, ": ");
      stringBuilder.append(this.h.getParcelable(paramString));
      Log.w("ActivityResultRegistry", stringBuilder.toString());
      this.h.remove(paramString);
    } 
    if ((c)this.d.get(paramString) == null)
      return; 
    throw null;
  }
  
  public class a extends c<I> {
    public a(e this$0, String param1String, int param1Int, d.a param1a) {}
    
    public void a() {
      this.d.c(this.a);
    }
  }
  
  public static class b<O> {
    public final b<O> a;
    
    public final d.a<?, O> b;
    
    public b(b<O> param1b, d.a<?, O> param1a) {
      this.a = param1b;
      this.b = param1a;
    }
  }
  
  public static class c {}
}


/* Location:              C:\soft\dex2jar-2.0\Luxury Logo Maker_ Logo Design-dex2jar.jar!\androidx\activity\result\e.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */