package androidx.activity.result;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.os.Parcel;
import android.os.Parcelable;
import android.support.v4.media.c;

@SuppressLint({"BanParcelableUsage"})
public final class a implements Parcelable {
  public static final Parcelable.Creator<a> CREATOR = new a();
  
  public final int h;
  
  public final Intent i;
  
  public a(int paramInt, Intent paramIntent) {
    this.h = paramInt;
    this.i = paramIntent;
  }
  
  public a(Parcel paramParcel) {
    Intent intent;
    this.h = paramParcel.readInt();
    if (paramParcel.readInt() == 0) {
      paramParcel = null;
    } else {
      intent = (Intent)Intent.CREATOR.createFromParcel(paramParcel);
    } 
    this.i = intent;
  }
  
  public int describeContents() {
    return 0;
  }
  
  public String toString() {
    String str;
    StringBuilder stringBuilder = c.a("ActivityResult{resultCode=");
    int i = this.h;
    if (i != -1) {
      if (i != 0) {
        str = String.valueOf(i);
      } else {
        str = "RESULT_CANCELED";
      } 
    } else {
      str = "RESULT_OK";
    } 
    stringBuilder.append(str);
    stringBuilder.append(", data=");
    stringBuilder.append(this.i);
    stringBuilder.append('}');
    return stringBuilder.toString();
  }
  
  public void writeToParcel(Parcel paramParcel, int paramInt) {
    boolean bool;
    paramParcel.writeInt(this.h);
    if (this.i == null) {
      bool = false;
    } else {
      bool = true;
    } 
    paramParcel.writeInt(bool);
    Intent intent = this.i;
    if (intent != null)
      intent.writeToParcel(paramParcel, paramInt); 
  }
  
  public class a implements Parcelable.Creator<a> {
    public Object createFromParcel(Parcel param1Parcel) {
      return new a(param1Parcel);
    }
    
    public Object[] newArray(int param1Int) {
      return (Object[])new a[param1Int];
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Luxury Logo Maker_ Logo Design-dex2jar.jar!\androidx\activity\result\a.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */