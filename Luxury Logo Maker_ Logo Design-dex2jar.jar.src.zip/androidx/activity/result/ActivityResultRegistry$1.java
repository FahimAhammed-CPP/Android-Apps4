package androidx.activity.result;

import androidx.lifecycle.e;
import androidx.lifecycle.g;
import androidx.lifecycle.i;

class ActivityResultRegistry$1 implements g {
  public void c(i parami, e.b paramb) {
    if (!e.b.ON_START.equals(paramb)) {
      if (!e.b.ON_STOP.equals(paramb)) {
        if (!e.b.ON_DESTROY.equals(paramb))
          return; 
        throw null;
      } 
      throw null;
    } 
    throw null;
  }
}


/* Location:              C:\soft\dex2jar-2.0\Luxury Logo Maker_ Logo Design-dex2jar.jar!\androidx\activity\result\ActivityResultRegistry$1.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */