package androidx.savedstate;

import androidx.lifecycle.e;
import androidx.lifecycle.g;
import androidx.lifecycle.i;

class SavedStateRegistry$1 implements g {
  public SavedStateRegistry$1(a parama) {}
  
  public void c(i parami, e.b paramb) {
    a a1;
    boolean bool;
    if (paramb == e.b.ON_START) {
      a1 = this.h;
      bool = true;
    } else if (paramb == e.b.ON_STOP) {
      a1 = this.h;
      bool = false;
    } else {
      return;
    } 
    a1.e = bool;
  }
}


/* Location:              C:\soft\dex2jar-2.0\Luxury Logo Maker_ Logo Design-dex2jar.jar!\androidx\savedstate\SavedStateRegistry$1.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */