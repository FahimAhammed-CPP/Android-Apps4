package androidx.savedstate;

import android.os.Bundle;
import androidx.lifecycle.e;
import androidx.lifecycle.h;
import androidx.lifecycle.j;
import java.util.Map;
import java.util.Objects;

public final class b {
  public final c a;
  
  public final a b;
  
  public b(c paramc) {
    this.a = paramc;
    this.b = new a();
  }
  
  public void a(Bundle paramBundle) {
    e e = this.a.a();
    if (((j)e).b == e.c.i) {
      e.a((h)new Recreator(this.a));
      a a1 = this.b;
      if (!a1.c) {
        if (paramBundle != null)
          a1.b = paramBundle.getBundle("androidx.lifecycle.BundlableSavedStateRegistry.key"); 
        e.a((h)new SavedStateRegistry$1(a1));
        a1.c = true;
        return;
      } 
      throw new IllegalStateException("SavedStateRegistry was already restored.");
    } 
    throw new IllegalStateException("Restarter must be created only during owner's initialization stage");
  }
  
  public void b(Bundle paramBundle) {
    a a1 = this.b;
    Objects.requireNonNull(a1);
    Bundle bundle1 = new Bundle();
    Bundle bundle2 = a1.b;
    if (bundle2 != null)
      bundle1.putAll(bundle2); 
    m.b.d d = a1.a.g();
    while (d.hasNext()) {
      Map.Entry entry = (Map.Entry)d.next();
      bundle1.putBundle((String)entry.getKey(), ((a.b)entry.getValue()).a());
    } 
    paramBundle.putBundle("androidx.lifecycle.BundlableSavedStateRegistry.key", bundle1);
  }
}


/* Location:              C:\soft\dex2jar-2.0\Luxury Logo Maker_ Logo Design-dex2jar.jar!\androidx\savedstate\b.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */