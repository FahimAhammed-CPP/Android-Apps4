package androidx.cardview.widget;

import android.content.Context;
import android.content.res.ColorStateList;
import android.content.res.Resources;
import android.content.res.TypedArray;
import android.graphics.Color;
import android.graphics.Rect;
import android.graphics.drawable.Drawable;
import android.util.AttributeSet;
import android.widget.FrameLayout;
import q.b;
import q.c;
import w.d;

public class CardView extends FrameLayout {
  public static final int[] o = new int[] { 16842801 };
  
  public static final b p = (b)new d();
  
  public boolean h;
  
  public boolean i;
  
  public int j;
  
  public int k;
  
  public final Rect l;
  
  public final Rect m;
  
  public final q.a n;
  
  public CardView(Context paramContext, AttributeSet paramAttributeSet) {
    super(paramContext, paramAttributeSet, 2130968708);
    ColorStateList colorStateList;
    Rect rect = new Rect();
    this.l = rect;
    this.m = new Rect();
    a a1 = new a(this);
    this.n = a1;
    TypedArray typedArray = paramContext.obtainStyledAttributes(paramAttributeSet, p.a.a, 2130968708, 2131886315);
    if (typedArray.hasValue(2)) {
      colorStateList = typedArray.getColorStateList(2);
    } else {
      Resources resources;
      TypedArray typedArray1 = getContext().obtainStyledAttributes(o);
      int j = typedArray1.getColor(0, 0);
      typedArray1.recycle();
      float[] arrayOfFloat = new float[3];
      Color.colorToHSV(j, arrayOfFloat);
      if (arrayOfFloat[2] > 0.5F) {
        resources = getResources();
        j = 2131099699;
      } else {
        resources = getResources();
        j = 2131099698;
      } 
      colorStateList = ColorStateList.valueOf(resources.getColor(j));
    } 
    float f4 = typedArray.getDimension(3, 0.0F);
    float f2 = typedArray.getDimension(4, 0.0F);
    float f3 = typedArray.getDimension(5, 0.0F);
    this.h = typedArray.getBoolean(7, false);
    this.i = typedArray.getBoolean(6, true);
    int i = typedArray.getDimensionPixelSize(8, 0);
    rect.left = typedArray.getDimensionPixelSize(10, i);
    rect.top = typedArray.getDimensionPixelSize(12, i);
    rect.right = typedArray.getDimensionPixelSize(11, i);
    rect.bottom = typedArray.getDimensionPixelSize(9, i);
    float f1 = f3;
    if (f2 > f3)
      f1 = f2; 
    this.j = typedArray.getDimensionPixelSize(0, 0);
    this.k = typedArray.getDimensionPixelSize(1, 0);
    typedArray.recycle();
    d d = (d)p;
    c c = new c(colorStateList, f4);
    a1.a = (Drawable)c;
    setBackgroundDrawable((Drawable)c);
    setClipToOutline(true);
    setElevation(f2);
    d.i(a1, f1);
  }
  
  public ColorStateList getCardBackgroundColor() {
    b b1 = p;
    q.a a1 = this.n;
    return (((d)b1).e(a1)).h;
  }
  
  public float getCardElevation() {
    return ((a)this.n).b.getElevation();
  }
  
  public int getContentPaddingBottom() {
    return this.l.bottom;
  }
  
  public int getContentPaddingLeft() {
    return this.l.left;
  }
  
  public int getContentPaddingRight() {
    return this.l.right;
  }
  
  public int getContentPaddingTop() {
    return this.l.top;
  }
  
  public float getMaxCardElevation() {
    b b1 = p;
    q.a a1 = this.n;
    return ((d)b1).f(a1);
  }
  
  public boolean getPreventCornerOverlap() {
    return this.i;
  }
  
  public float getRadius() {
    b b1 = p;
    q.a a1 = this.n;
    return ((d)b1).g(a1);
  }
  
  public boolean getUseCompatPadding() {
    return this.h;
  }
  
  public void onMeasure(int paramInt1, int paramInt2) {
    super.onMeasure(paramInt1, paramInt2);
  }
  
  public void setCardBackgroundColor(int paramInt) {
    b b1 = p;
    q.a a1 = this.n;
    ColorStateList colorStateList = ColorStateList.valueOf(paramInt);
    c c = ((d)b1).e(a1);
    c.b(colorStateList);
    c.invalidateSelf();
  }
  
  public void setCardBackgroundColor(ColorStateList paramColorStateList) {
    b b1 = p;
    q.a a1 = this.n;
    c c = ((d)b1).e(a1);
    c.b(paramColorStateList);
    c.invalidateSelf();
  }
  
  public void setCardElevation(float paramFloat) {
    ((a)this.n).b.setElevation(paramFloat);
  }
  
  public void setMaxCardElevation(float paramFloat) {
    b b1 = p;
    q.a a1 = this.n;
    ((d)b1).i(a1, paramFloat);
  }
  
  public void setMinimumHeight(int paramInt) {
    this.k = paramInt;
    super.setMinimumHeight(paramInt);
  }
  
  public void setMinimumWidth(int paramInt) {
    this.j = paramInt;
    super.setMinimumWidth(paramInt);
  }
  
  public void setPadding(int paramInt1, int paramInt2, int paramInt3, int paramInt4) {}
  
  public void setPaddingRelative(int paramInt1, int paramInt2, int paramInt3, int paramInt4) {}
  
  public void setPreventCornerOverlap(boolean paramBoolean) {
    if (paramBoolean != this.i) {
      this.i = paramBoolean;
      b b1 = p;
      q.a a1 = this.n;
      d d = (d)b1;
      d.i(a1, (d.e(a1)).e);
    } 
  }
  
  public void setRadius(float paramFloat) {
    b b1 = p;
    q.a a1 = this.n;
    c c = ((d)b1).e(a1);
    if (paramFloat == c.a)
      return; 
    c.a = paramFloat;
    c.c(null);
    c.invalidateSelf();
  }
  
  public void setUseCompatPadding(boolean paramBoolean) {
    if (this.h != paramBoolean) {
      this.h = paramBoolean;
      b b1 = p;
      q.a a1 = this.n;
      d d = (d)b1;
      d.i(a1, (d.e(a1)).e);
    } 
  }
  
  public class a implements q.a {
    public Drawable a;
    
    public a(CardView this$0) {}
    
    public boolean a() {
      return this.b.getPreventCornerOverlap();
    }
    
    public void b(int param1Int1, int param1Int2, int param1Int3, int param1Int4) {
      this.b.m.set(param1Int1, param1Int2, param1Int3, param1Int4);
      CardView cardView = this.b;
      Rect rect = cardView.l;
      CardView.c(cardView, param1Int1 + rect.left, param1Int2 + rect.top, param1Int3 + rect.right, param1Int4 + rect.bottom);
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Luxury Logo Maker_ Logo Design-dex2jar.jar!\androidx\cardview\widget\CardView.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */