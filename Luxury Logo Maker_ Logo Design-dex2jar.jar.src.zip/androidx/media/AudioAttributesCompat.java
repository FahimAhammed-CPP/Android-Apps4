package androidx.media;

import android.util.SparseIntArray;
import g1.c;

public class AudioAttributesCompat implements c {
  public AudioAttributesImpl a;
  
  static {
    SparseIntArray sparseIntArray = new SparseIntArray();
    sparseIntArray.put(5, 1);
    sparseIntArray.put(6, 2);
    sparseIntArray.put(7, 2);
    sparseIntArray.put(8, 1);
    sparseIntArray.put(9, 1);
    sparseIntArray.put(10, 1);
  }
  
  public boolean equals(Object paramObject) {
    boolean bool1 = paramObject instanceof AudioAttributesCompat;
    boolean bool = false;
    if (!bool1)
      return false; 
    AudioAttributesCompat audioAttributesCompat = (AudioAttributesCompat)paramObject;
    paramObject = this.a;
    AudioAttributesImpl audioAttributesImpl = audioAttributesCompat.a;
    if (paramObject == null) {
      if (audioAttributesImpl == null)
        bool = true; 
      return bool;
    } 
    return paramObject.equals(audioAttributesImpl);
  }
  
  public int hashCode() {
    return this.a.hashCode();
  }
  
  public String toString() {
    return this.a.toString();
  }
}


/* Location:              C:\soft\dex2jar-2.0\Luxury Logo Maker_ Logo Design-dex2jar.jar!\androidx\media\AudioAttributesCompat.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */