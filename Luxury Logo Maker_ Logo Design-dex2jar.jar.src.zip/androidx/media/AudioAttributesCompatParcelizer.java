package androidx.media;

import g1.a;
import g1.c;
import java.util.Objects;

public final class AudioAttributesCompatParcelizer {
  public static AudioAttributesCompat read(a parama) {
    c c;
    AudioAttributesCompat audioAttributesCompat = new AudioAttributesCompat();
    AudioAttributesImpl audioAttributesImpl = audioAttributesCompat.a;
    if (!parama.i(1)) {
      c = audioAttributesImpl;
    } else {
      c = c.o();
    } 
    audioAttributesCompat.a = (AudioAttributesImpl)c;
    return audioAttributesCompat;
  }
  
  public static void write(AudioAttributesCompat paramAudioAttributesCompat, a parama) {
    Objects.requireNonNull(parama);
    AudioAttributesImpl audioAttributesImpl = paramAudioAttributesCompat.a;
    parama.p(1);
    parama.w(audioAttributesImpl);
  }
}


/* Location:              C:\soft\dex2jar-2.0\Luxury Logo Maker_ Logo Design-dex2jar.jar!\androidx\media\AudioAttributesCompatParcelizer.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */