package androidx.work;

import h1.g;
import java.util.Collections;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

public final class OverwritingInputMerger extends g {
  public b a(List<b> paramList) {
    b.a a = new b.a();
    HashMap<Object, Object> hashMap = new HashMap<Object, Object>();
    Iterator<b> iterator = paramList.iterator();
    while (iterator.hasNext())
      hashMap.putAll(Collections.unmodifiableMap(((b)iterator.next()).a)); 
    a.b((Map)hashMap);
    return a.a();
  }
}


/* Location:              C:\soft\dex2jar-2.0\Luxury Logo Maker_ Logo Design-dex2jar.jar!\androidx\work\OverwritingInputMerger.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */