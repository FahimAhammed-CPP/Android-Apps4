package androidx.work;

import android.annotation.SuppressLint;
import android.content.Context;
import android.net.Network;
import android.net.Uri;
import androidx.annotation.Keep;
import h1.e;
import h1.f;
import h1.m;
import h1.r;
import java.util.List;
import java.util.Objects;
import java.util.Set;
import java.util.UUID;
import java.util.concurrent.Executor;
import r1.o;
import r1.p;
import r1.q;

public abstract class ListenableWorker {
  public Context h;
  
  public WorkerParameters i;
  
  public volatile boolean j;
  
  public boolean k;
  
  public boolean l;
  
  @SuppressLint({"BanKeepAnnotation"})
  @Keep
  public ListenableWorker(Context paramContext, WorkerParameters paramWorkerParameters) {
    if (paramContext != null) {
      if (paramWorkerParameters != null) {
        this.h = paramContext;
        this.i = paramWorkerParameters;
        return;
      } 
      throw new IllegalArgumentException("WorkerParameters is null");
    } 
    throw new IllegalArgumentException("Application Context is null");
  }
  
  public final Context getApplicationContext() {
    return this.h;
  }
  
  public Executor getBackgroundExecutor() {
    return this.i.f;
  }
  
  public r5.a<e> getForegroundInfoAsync() {
    s1.c c = new s1.c();
    c.l(new IllegalStateException("Expedited WorkRequests require a ListenableWorker to provide an implementation for `getForegroundInfoAsync()`"));
    return (r5.a<e>)c;
  }
  
  public final UUID getId() {
    return this.i.a;
  }
  
  public final b getInputData() {
    return this.i.b;
  }
  
  public final Network getNetwork() {
    return this.i.d.c;
  }
  
  public final int getRunAttemptCount() {
    return this.i.e;
  }
  
  public final Set<String> getTags() {
    return this.i.c;
  }
  
  public t1.a getTaskExecutor() {
    return this.i.g;
  }
  
  public final List<String> getTriggeredContentAuthorities() {
    return this.i.d.a;
  }
  
  public final List<Uri> getTriggeredContentUris() {
    return this.i.d.b;
  }
  
  public r getWorkerFactory() {
    return this.i.h;
  }
  
  public boolean isRunInForeground() {
    return this.l;
  }
  
  public final boolean isStopped() {
    return this.j;
  }
  
  public final boolean isUsed() {
    return this.k;
  }
  
  public void onStopped() {}
  
  public final r5.a<Void> setForegroundAsync(e parame) {
    this.l = true;
    f f = this.i.j;
    Context context = getApplicationContext();
    UUID uUID = getId();
    return ((o)f).a(context, uUID, parame);
  }
  
  public r5.a<Void> setProgressAsync(b paramb) {
    m m = this.i.i;
    getApplicationContext();
    UUID uUID = getId();
    q q = (q)m;
    Objects.requireNonNull(q);
    s1.c c = new s1.c();
    t1.a a = q.b;
    p p = new p(q, uUID, paramb, c);
    ((t1.b)a).a.execute((Runnable)p);
    return (r5.a<Void>)c;
  }
  
  public void setRunInForeground(boolean paramBoolean) {
    this.l = paramBoolean;
  }
  
  public final void setUsed() {
    this.k = true;
  }
  
  public abstract r5.a<a> startWork();
  
  public final void stop() {
    this.j = true;
    onStopped();
  }
  
  public static abstract class a {
    public static final class a extends a {
      public final b a;
      
      public a() {
        this.a = b1;
      }
      
      public boolean equals(Object param2Object) {
        if (this == param2Object)
          return true; 
        if (param2Object == null || a.class != param2Object.getClass())
          return false; 
        param2Object = param2Object;
        return this.a.equals(((a)param2Object).a);
      }
      
      public int hashCode() {
        int i = a.class.getName().hashCode();
        return this.a.hashCode() + i * 31;
      }
      
      public String toString() {
        StringBuilder stringBuilder = android.support.v4.media.c.a("Failure {mOutputData=");
        stringBuilder.append(this.a);
        stringBuilder.append('}');
        return stringBuilder.toString();
      }
    }
    
    public static final class b extends a {
      public boolean equals(Object param2Object) {
        return (this == param2Object) ? true : ((param2Object != null && b.class == param2Object.getClass()));
      }
      
      public int hashCode() {
        return b.class.getName().hashCode();
      }
      
      public String toString() {
        return "Retry";
      }
    }
    
    public static final class c extends a {
      public final b a;
      
      public c() {
        this.a = b1;
      }
      
      public c(b param2b) {
        this.a = param2b;
      }
      
      public boolean equals(Object param2Object) {
        if (this == param2Object)
          return true; 
        if (param2Object == null || c.class != param2Object.getClass())
          return false; 
        param2Object = param2Object;
        return this.a.equals(((c)param2Object).a);
      }
      
      public int hashCode() {
        int i = c.class.getName().hashCode();
        return this.a.hashCode() + i * 31;
      }
      
      public String toString() {
        StringBuilder stringBuilder = android.support.v4.media.c.a("Success {mOutputData=");
        stringBuilder.append(this.a);
        stringBuilder.append('}');
        return stringBuilder.toString();
      }
    }
  }
  
  public static final class a extends a {
    public final b a;
    
    public a() {
      this.a = b1;
    }
    
    public boolean equals(Object param1Object) {
      if (this == param1Object)
        return true; 
      if (param1Object == null || a.class != param1Object.getClass())
        return false; 
      param1Object = param1Object;
      return this.a.equals(((a)param1Object).a);
    }
    
    public int hashCode() {
      int i = a.class.getName().hashCode();
      return this.a.hashCode() + i * 31;
    }
    
    public String toString() {
      StringBuilder stringBuilder = android.support.v4.media.c.a("Failure {mOutputData=");
      stringBuilder.append(this.a);
      stringBuilder.append('}');
      return stringBuilder.toString();
    }
  }
  
  public static final class b extends a {
    public boolean equals(Object param1Object) {
      return (this == param1Object) ? true : ((param1Object != null && b.class == param1Object.getClass()));
    }
    
    public int hashCode() {
      return b.class.getName().hashCode();
    }
    
    public String toString() {
      return "Retry";
    }
  }
  
  public static final class c extends a {
    public final b a;
    
    public c() {
      this.a = b1;
    }
    
    public c(b param1b) {
      this.a = param1b;
    }
    
    public boolean equals(Object param1Object) {
      if (this == param1Object)
        return true; 
      if (param1Object == null || c.class != param1Object.getClass())
        return false; 
      param1Object = param1Object;
      return this.a.equals(((c)param1Object).a);
    }
    
    public int hashCode() {
      int i = c.class.getName().hashCode();
      return this.a.hashCode() + i * 31;
    }
    
    public String toString() {
      StringBuilder stringBuilder = android.support.v4.media.c.a("Success {mOutputData=");
      stringBuilder.append(this.a);
      stringBuilder.append('}');
      return stringBuilder.toString();
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Luxury Logo Maker_ Logo Design-dex2jar.jar!\androidx\work\ListenableWorker.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */