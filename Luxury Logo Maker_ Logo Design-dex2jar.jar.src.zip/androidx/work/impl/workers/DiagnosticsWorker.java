package androidx.work.impl.workers;

import android.content.Context;
import android.database.Cursor;
import android.os.Build;
import android.text.TextUtils;
import androidx.work.ListenableWorker;
import androidx.work.Worker;
import androidx.work.WorkerParameters;
import androidx.work.b;
import androidx.work.impl.WorkDatabase;
import b2.a;
import h1.c;
import h1.i;
import i1.k;
import java.util.ArrayList;
import java.util.List;
import java.util.Objects;
import java.util.concurrent.TimeUnit;
import q1.g;
import q1.h;
import q1.i;
import q1.k;
import q1.l;
import q1.p;
import q1.q;
import q1.r;
import q1.t;
import q1.u;
import q1.v;
import w0.h;
import y0.b;
import z0.e;

public class DiagnosticsWorker extends Worker {
  public static final String n = i.e("DiagnosticsWrkr");
  
  public DiagnosticsWorker(Context paramContext, WorkerParameters paramWorkerParameters) {
    super(paramContext, paramWorkerParameters);
  }
  
  public static String a(k paramk, t paramt, h paramh, List<p> paramList) {
    String str;
    StringBuilder stringBuilder = new StringBuilder();
    if (Build.VERSION.SDK_INT >= 23) {
      str = "Job Id";
    } else {
      str = "Alarm Id";
    } 
    stringBuilder.append(String.format("\n Id \t Class Name\t %s\t State\t Unique Name\t Tags\t", new Object[] { str }));
    for (p p : paramList) {
      ArrayList<String> arrayList;
      String str1 = p.a;
      g g = ((i)paramh).a(str1);
      if (g != null) {
        Integer integer = Integer.valueOf(g.b);
      } else {
        g = null;
      } 
      String str5 = p.a;
      l l = (l)paramk;
      Objects.requireNonNull(l);
      h h1 = h.a("SELECT name FROM workname WHERE work_spec_id=?", 1);
      if (str5 == null) {
        h1.f(1);
      } else {
        h1.g(1, str5);
      } 
      l.a.b();
      Cursor cursor = b.a(l.a, (e)h1, false, null);
      try {
        arrayList = new ArrayList(cursor.getCount());
        while (cursor.moveToNext())
          arrayList.add(cursor.getString(0)); 
      } finally {}
      cursor.close();
      h1.h();
      String str3 = p.a;
      List list = ((u)paramt).a(str3);
      String str4 = TextUtils.join(",", arrayList);
      String str2 = TextUtils.join(",", list);
      stringBuilder.append(String.format("\n%s\t %s\t %s\t %s\t %s\t %s\t", new Object[] { p.a, p.c, g, p.b.name(), str4, str2 }));
    } 
    return stringBuilder.toString();
  }
  
  public ListenableWorker.a doWork() {
    List<p> list;
    String str;
    WorkDatabase workDatabase = (k.b(getApplicationContext())).c;
    q q = workDatabase.q();
    k k = workDatabase.o();
    t t = workDatabase.r();
    h h = workDatabase.n();
    long l1 = System.currentTimeMillis();
    long l2 = TimeUnit.DAYS.toMillis(1L);
    r r = (r)q;
    Objects.requireNonNull(r);
    h h1 = h.a("SELECT `required_network_type`, `requires_charging`, `requires_device_idle`, `requires_battery_not_low`, `requires_storage_not_low`, `trigger_content_update_delay`, `trigger_max_content_delay`, `content_uri_triggers`, `WorkSpec`.`id` AS `id`, `WorkSpec`.`state` AS `state`, `WorkSpec`.`worker_class_name` AS `worker_class_name`, `WorkSpec`.`input_merger_class_name` AS `input_merger_class_name`, `WorkSpec`.`input` AS `input`, `WorkSpec`.`output` AS `output`, `WorkSpec`.`initial_delay` AS `initial_delay`, `WorkSpec`.`interval_duration` AS `interval_duration`, `WorkSpec`.`flex_duration` AS `flex_duration`, `WorkSpec`.`run_attempt_count` AS `run_attempt_count`, `WorkSpec`.`backoff_policy` AS `backoff_policy`, `WorkSpec`.`backoff_delay_duration` AS `backoff_delay_duration`, `WorkSpec`.`period_start_time` AS `period_start_time`, `WorkSpec`.`minimum_retention_duration` AS `minimum_retention_duration`, `WorkSpec`.`schedule_requested_at` AS `schedule_requested_at`, `WorkSpec`.`run_in_foreground` AS `run_in_foreground`, `WorkSpec`.`out_of_quota_policy` AS `out_of_quota_policy` FROM workspec WHERE period_start_time >= ? AND state IN (2, 3, 5) ORDER BY period_start_time DESC", 1);
    h1.d(1, l1 - l2);
    r.a.b();
    Cursor cursor = b.a(r.a, (e)h1, false, null);
    try {
      int n = a.e(cursor, "required_network_type");
      int j = a.e(cursor, "requires_charging");
      int i = a.e(cursor, "requires_device_idle");
      int i5 = a.e(cursor, "requires_battery_not_low");
      int i6 = a.e(cursor, "requires_storage_not_low");
      int i7 = a.e(cursor, "trigger_content_update_delay");
      int i8 = a.e(cursor, "trigger_max_content_delay");
      int i9 = a.e(cursor, "content_uri_triggers");
      int m = a.e(cursor, "id");
      int i10 = a.e(cursor, "state");
      int i2 = a.e(cursor, "worker_class_name");
      int i1 = a.e(cursor, "input_merger_class_name");
      int i3 = a.e(cursor, "input");
      int i4 = a.e(cursor, "output");
      try {
        int i17 = a.e(cursor, "initial_delay");
        int i16 = a.e(cursor, "interval_duration");
        int i21 = a.e(cursor, "flex_duration");
        int i14 = a.e(cursor, "run_attempt_count");
        int i11 = a.e(cursor, "backoff_policy");
        int i12 = a.e(cursor, "backoff_delay_duration");
        int i20 = a.e(cursor, "period_start_time");
        int i13 = a.e(cursor, "minimum_retention_duration");
        int i18 = a.e(cursor, "schedule_requested_at");
        int i15 = a.e(cursor, "run_in_foreground");
        int i19 = a.e(cursor, "out_of_quota_policy");
        ArrayList<p> arrayList = new ArrayList(cursor.getCount());
        while (true) {
          if (cursor.moveToNext()) {
            boolean bool;
            String str1 = cursor.getString(m);
            String str2 = cursor.getString(i2);
            c c = new c();
            c.a = v.c(cursor.getInt(n));
            if (cursor.getInt(j) != 0) {
              bool = true;
            } else {
              bool = false;
            } 
            c.b = bool;
            if (cursor.getInt(i) != 0) {
              bool = true;
            } else {
              bool = false;
            } 
            c.c = bool;
            if (cursor.getInt(i5) != 0) {
              bool = true;
            } else {
              bool = false;
            } 
            c.d = bool;
            if (cursor.getInt(i6) != 0) {
              bool = true;
            } else {
              bool = false;
            } 
            c.e = bool;
            c.f = cursor.getLong(i7);
            c.g = cursor.getLong(i8);
            c.h = v.a(cursor.getBlob(i9));
            p p = new p(str1, str2);
            p.b = v.e(cursor.getInt(i10));
            p.d = cursor.getString(i1);
            p.e = b.a(cursor.getBlob(i3));
            p.f = b.a(cursor.getBlob(i4));
            p.g = cursor.getLong(i17);
            p.h = cursor.getLong(i16);
            p.i = cursor.getLong(i21);
            p.k = cursor.getInt(i14);
            p.l = v.b(cursor.getInt(i11));
            p.m = cursor.getLong(i12);
            p.n = cursor.getLong(i20);
            p.o = cursor.getLong(i13);
            p.p = cursor.getLong(i18);
            if (cursor.getInt(i15) != 0) {
              bool = true;
            } else {
              bool = false;
            } 
            p.q = bool;
            p.r = v.d(cursor.getInt(i19));
            p.j = c;
            arrayList.add(p);
            continue;
          } 
          cursor.close();
          h1.h();
          List<p> list1 = r.d();
          list = r.b(200);
          if (!arrayList.isEmpty()) {
            i i22 = i.c();
            String str1 = n;
            i22.d(str1, "Recently completed work:\n\n", new Throwable[0]);
            i.c().d(str1, a(k, t, h, arrayList), new Throwable[0]);
          } 
          if (!((ArrayList)list1).isEmpty()) {
            i i22 = i.c();
            String str1 = n;
            i22.d(str1, "Running work:\n\n", new Throwable[0]);
            i.c().d(str1, a(k, t, h, list1), new Throwable[0]);
          } 
          if (!((ArrayList)list).isEmpty()) {
            i i22 = i.c();
            str = n;
            i22.d(str, "Enqueued work:\n\n", new Throwable[0]);
            i.c().d(str, a(k, t, h, list), new Throwable[0]);
          } 
          return (ListenableWorker.a)new ListenableWorker.a.c();
        } 
      } finally {}
    } finally {}
    str.close();
    list.h();
    throw k;
  }
}


/* Location:              C:\soft\dex2jar-2.0\Luxury Logo Maker_ Logo Design-dex2jar.jar!\androidx\work\impl\workers\DiagnosticsWorker.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */