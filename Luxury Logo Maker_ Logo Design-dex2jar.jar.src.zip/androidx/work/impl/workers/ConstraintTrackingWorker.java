package androidx.work.impl.workers;

import android.content.Context;
import android.text.TextUtils;
import androidx.work.ListenableWorker;
import androidx.work.WorkerParameters;
import h1.i;
import i1.k;
import java.util.Collections;
import java.util.List;
import m1.c;
import m1.d;
import q1.p;
import q1.q;
import q1.r;
import s1.c;

public class ConstraintTrackingWorker extends ListenableWorker implements c {
  public static final String r = i.e("ConstraintTrkngWrkr");
  
  public WorkerParameters m;
  
  public final Object n;
  
  public volatile boolean o;
  
  public c<ListenableWorker.a> p;
  
  public ListenableWorker q;
  
  public ConstraintTrackingWorker(Context paramContext, WorkerParameters paramWorkerParameters) {
    super(paramContext, paramWorkerParameters);
    this.m = paramWorkerParameters;
    this.n = new Object();
    this.o = false;
    this.p = new c();
  }
  
  public void a() {
    this.p.k(new ListenableWorker.a.a());
  }
  
  public void b() {
    this.p.k(new ListenableWorker.a.b());
  }
  
  public void c(List<String> paramList) {
    i.c().a(r, String.format("Constraints changed for %s", new Object[] { paramList }), new Throwable[0]);
    synchronized (this.n) {
      this.o = true;
      return;
    } 
  }
  
  public void e(List<String> paramList) {}
  
  public t1.a getTaskExecutor() {
    return (k.b(getApplicationContext())).d;
  }
  
  public boolean isRunInForeground() {
    ListenableWorker listenableWorker = this.q;
    return (listenableWorker != null && listenableWorker.isRunInForeground());
  }
  
  public void onStopped() {
    super.onStopped();
    ListenableWorker listenableWorker = this.q;
    if (listenableWorker != null && !listenableWorker.isStopped())
      this.q.stop(); 
  }
  
  public r5.a<ListenableWorker.a> startWork() {
    getBackgroundExecutor().execute(new a(this));
    return (r5.a<ListenableWorker.a>)this.p;
  }
  
  public class a implements Runnable {
    public a(ConstraintTrackingWorker this$0) {}
    
    public void run() {
      ConstraintTrackingWorker constraintTrackingWorker = this.h;
      String str = constraintTrackingWorker.getInputData().b("androidx.work.impl.workers.ConstraintTrackingWorker.ARGUMENT_CLASS_NAME");
      if (TextUtils.isEmpty(str)) {
        i.c().b(ConstraintTrackingWorker.r, "No worker to delegate to.", new Throwable[0]);
      } else {
        ListenableWorker listenableWorker = constraintTrackingWorker.getWorkerFactory().a(constraintTrackingWorker.getApplicationContext(), str, constraintTrackingWorker.m);
        constraintTrackingWorker.q = listenableWorker;
        if (listenableWorker == null) {
          i.c().a(ConstraintTrackingWorker.r, "No worker to delegate to.", new Throwable[0]);
        } else {
          q q = (k.b(constraintTrackingWorker.getApplicationContext())).c.q();
          String str1 = constraintTrackingWorker.getId().toString();
          p p = ((r)q).i(str1);
          if (p != null) {
            d d = new d(constraintTrackingWorker.getApplicationContext(), constraintTrackingWorker.getTaskExecutor(), constraintTrackingWorker);
            d.b(Collections.singletonList(p));
            if (d.a(constraintTrackingWorker.getId().toString())) {
              i.c().a(ConstraintTrackingWorker.r, String.format("Constraints met for delegate %s", new Object[] { str }), new Throwable[0]);
              try {
                return;
              } finally {
                d = null;
                i i = i.c();
                String str2 = ConstraintTrackingWorker.r;
                i.a(str2, String.format("Delegated worker %s threw exception in startWork.", new Object[] { str }), new Throwable[] { (Throwable)d });
              } 
            } 
            i.c().a(ConstraintTrackingWorker.r, String.format("Constraints not met for delegate %s. Requesting retry.", new Object[] { str }), new Throwable[0]);
            constraintTrackingWorker.b();
            return;
          } 
        } 
      } 
      constraintTrackingWorker.a();
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Luxury Logo Maker_ Logo Design-dex2jar.jar!\androidx\work\impl\workers\ConstraintTrackingWorker.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */