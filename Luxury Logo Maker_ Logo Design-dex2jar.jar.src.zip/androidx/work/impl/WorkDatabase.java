package androidx.work.impl;

import java.util.concurrent.TimeUnit;
import q1.b;
import q1.e;
import q1.h;
import q1.k;
import q1.n;
import q1.q;
import q1.t;
import w0.f;

public abstract class WorkDatabase extends f {
  public static final long j = TimeUnit.DAYS.toMillis(1L);
  
  public abstract b l();
  
  public abstract e m();
  
  public abstract h n();
  
  public abstract k o();
  
  public abstract n p();
  
  public abstract q q();
  
  public abstract t r();
}


/* Location:              C:\soft\dex2jar-2.0\Luxury Logo Maker_ Logo Design-dex2jar.jar!\androidx\work\impl\WorkDatabase.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */