package androidx.work.impl.background.systemalarm;

import android.content.Context;
import android.content.Intent;
import android.os.PowerManager;
import androidx.lifecycle.l;
import h1.i;
import java.util.HashMap;
import java.util.WeakHashMap;
import r1.m;

public class SystemAlarmService extends l implements d.c {
  public static final String k = i.e("SystemAlarmService");
  
  public d i;
  
  public boolean j;
  
  public final void b() {
    d d1 = new d((Context)this);
    this.i = d1;
    if (d1.q != null) {
      i.c().b(d.r, "A completion listener for SystemAlarmDispatcher already exists.", new Throwable[0]);
      return;
    } 
    d1.q = this;
  }
  
  public void e() {
    this.j = true;
    i.c().a(k, "All commands completed in dispatcher", new Throwable[0]);
    String str = m.a;
    null = new HashMap<Object, Object>();
    synchronized (m.b) {
      null.putAll(null);
      for (PowerManager.WakeLock wakeLock : null.keySet()) {
        if (wakeLock != null && wakeLock.isHeld()) {
          String str1 = String.format("WakeLock held for %s", new Object[] { null.get(wakeLock) });
          i.c().f(m.a, str1, new Throwable[0]);
        } 
      } 
      stopSelf();
      return;
    } 
  }
  
  public void onCreate() {
    super.onCreate();
    b();
    this.j = false;
  }
  
  public void onDestroy() {
    super.onDestroy();
    this.j = true;
    this.i.d();
  }
  
  public int onStartCommand(Intent paramIntent, int paramInt1, int paramInt2) {
    super.onStartCommand(paramIntent, paramInt1, paramInt2);
    if (this.j) {
      i.c().d(k, "Re-initializing SystemAlarmDispatcher after a request to shut-down.", new Throwable[0]);
      this.i.d();
      b();
      this.j = false;
    } 
    if (paramIntent != null)
      this.i.b(paramIntent, paramInt2); 
    return 3;
  }
}


/* Location:              C:\soft\dex2jar-2.0\Luxury Logo Maker_ Logo Design-dex2jar.jar!\androidx\work\impl\background\systemalarm\SystemAlarmService.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */