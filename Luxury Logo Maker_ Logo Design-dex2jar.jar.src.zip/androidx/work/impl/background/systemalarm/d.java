package androidx.work.impl.background.systemalarm;

import android.content.Context;
import android.content.Intent;
import android.os.Handler;
import android.os.Looper;
import android.os.PowerManager;
import h1.i;
import i1.b;
import i1.k;
import java.util.ArrayList;
import java.util.List;
import r1.m;
import r1.r;

public class d implements b {
  public static final String r = i.e("SystemAlarmDispatcher");
  
  public final Context h;
  
  public final t1.a i;
  
  public final r j;
  
  public final i1.d k;
  
  public final k l;
  
  public final a m;
  
  public final Handler n;
  
  public final List<Intent> o;
  
  public Intent p;
  
  public c q;
  
  public d(Context paramContext) {
    Context context = paramContext.getApplicationContext();
    this.h = context;
    this.m = new a(context);
    this.j = new r();
    k k1 = k.b(paramContext);
    this.l = k1;
    i1.d d1 = k1.f;
    this.k = d1;
    this.i = k1.d;
    d1.b(this);
    this.o = new ArrayList<Intent>();
    this.p = null;
    this.n = new Handler(Looper.getMainLooper());
  }
  
  public void a(String paramString, boolean paramBoolean) {
    Context context = this.h;
    String str = a.k;
    Intent intent = new Intent(context, SystemAlarmService.class);
    intent.setAction("ACTION_EXECUTION_COMPLETED");
    intent.putExtra("KEY_WORKSPEC_ID", paramString);
    intent.putExtra("KEY_NEEDS_RESCHEDULE", paramBoolean);
    b b1 = new b(this, intent, 0);
    this.n.post(b1);
  }
  
  public boolean b(Intent paramIntent, int paramInt) {
    // Byte code:
    //   0: invokestatic c : ()Lh1/i;
    //   3: astore #6
    //   5: getstatic androidx/work/impl/background/systemalarm/d.r : Ljava/lang/String;
    //   8: astore #5
    //   10: iconst_0
    //   11: istore #4
    //   13: aload #6
    //   15: aload #5
    //   17: ldc 'Adding command %s (%s)'
    //   19: iconst_2
    //   20: anewarray java/lang/Object
    //   23: dup
    //   24: iconst_0
    //   25: aload_1
    //   26: aastore
    //   27: dup
    //   28: iconst_1
    //   29: iload_2
    //   30: invokestatic valueOf : (I)Ljava/lang/Integer;
    //   33: aastore
    //   34: invokestatic format : (Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/String;
    //   37: iconst_0
    //   38: anewarray java/lang/Throwable
    //   41: invokevirtual a : (Ljava/lang/String;Ljava/lang/String;[Ljava/lang/Throwable;)V
    //   44: aload_0
    //   45: invokevirtual c : ()V
    //   48: aload_1
    //   49: invokevirtual getAction : ()Ljava/lang/String;
    //   52: astore #6
    //   54: aload #6
    //   56: invokestatic isEmpty : (Ljava/lang/CharSequence;)Z
    //   59: ifeq -> 78
    //   62: invokestatic c : ()Lh1/i;
    //   65: aload #5
    //   67: ldc 'Unknown command. Ignoring'
    //   69: iconst_0
    //   70: anewarray java/lang/Throwable
    //   73: invokevirtual f : (Ljava/lang/String;Ljava/lang/String;[Ljava/lang/Throwable;)V
    //   76: iconst_0
    //   77: ireturn
    //   78: ldc 'ACTION_CONSTRAINTS_CHANGED'
    //   80: aload #6
    //   82: invokevirtual equals : (Ljava/lang/Object;)Z
    //   85: ifeq -> 165
    //   88: aload_0
    //   89: invokevirtual c : ()V
    //   92: aload_0
    //   93: getfield o : Ljava/util/List;
    //   96: astore #5
    //   98: aload #5
    //   100: monitorenter
    //   101: aload_0
    //   102: getfield o : Ljava/util/List;
    //   105: invokeinterface iterator : ()Ljava/util/Iterator;
    //   110: astore #6
    //   112: aload #6
    //   114: invokeinterface hasNext : ()Z
    //   119: ifeq -> 151
    //   122: ldc 'ACTION_CONSTRAINTS_CHANGED'
    //   124: aload #6
    //   126: invokeinterface next : ()Ljava/lang/Object;
    //   131: checkcast android/content/Intent
    //   134: invokevirtual getAction : ()Ljava/lang/String;
    //   137: invokevirtual equals : (Ljava/lang/Object;)Z
    //   140: ifeq -> 112
    //   143: aload #5
    //   145: monitorexit
    //   146: iconst_1
    //   147: istore_3
    //   148: goto -> 229
    //   151: aload #5
    //   153: monitorexit
    //   154: iconst_0
    //   155: istore_3
    //   156: goto -> 229
    //   159: astore_1
    //   160: aload #5
    //   162: monitorexit
    //   163: aload_1
    //   164: athrow
    //   165: aload_1
    //   166: ldc 'KEY_START_ID'
    //   168: iload_2
    //   169: invokevirtual putExtra : (Ljava/lang/String;I)Landroid/content/Intent;
    //   172: pop
    //   173: aload_0
    //   174: getfield o : Ljava/util/List;
    //   177: astore #5
    //   179: aload #5
    //   181: monitorenter
    //   182: iload #4
    //   184: istore_2
    //   185: aload_0
    //   186: getfield o : Ljava/util/List;
    //   189: invokeinterface isEmpty : ()Z
    //   194: ifne -> 199
    //   197: iconst_1
    //   198: istore_2
    //   199: aload_0
    //   200: getfield o : Ljava/util/List;
    //   203: aload_1
    //   204: invokeinterface add : (Ljava/lang/Object;)Z
    //   209: pop
    //   210: iload_2
    //   211: ifne -> 218
    //   214: aload_0
    //   215: invokevirtual e : ()V
    //   218: aload #5
    //   220: monitorexit
    //   221: iconst_1
    //   222: ireturn
    //   223: astore_1
    //   224: aload #5
    //   226: monitorexit
    //   227: aload_1
    //   228: athrow
    //   229: iload_3
    //   230: ifeq -> 165
    //   233: iconst_0
    //   234: ireturn
    // Exception table:
    //   from	to	target	type
    //   101	112	159	finally
    //   112	146	159	finally
    //   151	154	159	finally
    //   160	163	159	finally
    //   185	197	223	finally
    //   199	210	223	finally
    //   214	218	223	finally
    //   218	221	223	finally
    //   224	227	223	finally
  }
  
  public final void c() {
    if (this.n.getLooper().getThread() == Thread.currentThread())
      return; 
    throw new IllegalStateException("Needs to be invoked on the main thread.");
  }
  
  public void d() {
    i.c().a(r, "Destroying SystemAlarmDispatcher", new Throwable[0]);
    this.k.e(this);
    r r1 = this.j;
    if (!r1.a.isShutdown())
      r1.a.shutdownNow(); 
    this.q = null;
  }
  
  public final void e() {
    c();
    PowerManager.WakeLock wakeLock = m.a(this.h, "ProcessCommand");
    try {
      wakeLock.acquire();
      t1.a a1 = this.l.d;
      a a2 = new a(this);
      ((t1.b)a1).a.execute(a2);
      return;
    } finally {
      wakeLock.release();
    } 
  }
  
  public class a implements Runnable {
    public a(d this$0) {}
    
    public void run() {
      List<Intent> list;
      d d1;
      synchronized (this.h.o) {
        d d2 = this.h;
        d2.p = d2.o.get(0);
        Intent intent = this.h.p;
        if (intent != null) {
          d.d d3;
          String str1 = intent.getAction();
          int i = this.h.p.getIntExtra("KEY_START_ID", 0);
          i i1 = i.c();
          String str2 = d.r;
          i1.a(str2, String.format("Processing command %s, %s", new Object[] { this.h.p, Integer.valueOf(i) }), new Throwable[0]);
          PowerManager.WakeLock wakeLock = m.a(this.h.h, String.format("%s (%s)", new Object[] { str1, Integer.valueOf(i) }));
          try {
            i.c().a(str2, String.format("Acquiring operation wake lock (%s) %s", new Object[] { str1, wakeLock }), new Throwable[0]);
            wakeLock.acquire();
            d d4 = this.h;
            d4.m.e(d4.p, i, d4);
            i.c().a(str2, String.format("Releasing operation wake lock (%s) %s", new Object[] { str1, wakeLock }), new Throwable[0]);
            wakeLock.release();
            d1 = this.h;
            d3 = new d.d(d1);
            return;
          } finally {
            str2 = null;
          } 
        } 
        return;
      } 
    }
  }
  
  public static class b implements Runnable {
    public final d h;
    
    public final Intent i;
    
    public final int j;
    
    public b(d param1d, Intent param1Intent, int param1Int) {
      this.h = param1d;
      this.i = param1Intent;
      this.j = param1Int;
    }
    
    public void run() {
      this.h.b(this.i, this.j);
    }
  }
  
  public static interface c {}
  
  public static class d implements Runnable {
    public final d h;
    
    public d(d param1d) {
      this.h = param1d;
    }
    
    public void run() {
      // Byte code:
      //   0: aload_0
      //   1: getfield h : Landroidx/work/impl/background/systemalarm/d;
      //   4: astore #4
      //   6: aload #4
      //   8: invokestatic requireNonNull : (Ljava/lang/Object;)Ljava/lang/Object;
      //   11: pop
      //   12: invokestatic c : ()Lh1/i;
      //   15: astore_3
      //   16: getstatic androidx/work/impl/background/systemalarm/d.r : Ljava/lang/String;
      //   19: astore #5
      //   21: aload_3
      //   22: aload #5
      //   24: ldc 'Checking if commands are complete.'
      //   26: iconst_0
      //   27: anewarray java/lang/Throwable
      //   30: invokevirtual a : (Ljava/lang/String;Ljava/lang/String;[Ljava/lang/Throwable;)V
      //   33: aload #4
      //   35: invokevirtual c : ()V
      //   38: aload #4
      //   40: getfield o : Ljava/util/List;
      //   43: astore_3
      //   44: aload_3
      //   45: monitorenter
      //   46: aload #4
      //   48: getfield p : Landroid/content/Intent;
      //   51: astore #6
      //   53: iconst_1
      //   54: istore_2
      //   55: aload #6
      //   57: ifnull -> 133
      //   60: invokestatic c : ()Lh1/i;
      //   63: aload #5
      //   65: ldc 'Removing command %s'
      //   67: iconst_1
      //   68: anewarray java/lang/Object
      //   71: dup
      //   72: iconst_0
      //   73: aload #4
      //   75: getfield p : Landroid/content/Intent;
      //   78: aastore
      //   79: invokestatic format : (Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/String;
      //   82: iconst_0
      //   83: anewarray java/lang/Throwable
      //   86: invokevirtual a : (Ljava/lang/String;Ljava/lang/String;[Ljava/lang/Throwable;)V
      //   89: aload #4
      //   91: getfield o : Ljava/util/List;
      //   94: iconst_0
      //   95: invokeinterface remove : (I)Ljava/lang/Object;
      //   100: checkcast android/content/Intent
      //   103: aload #4
      //   105: getfield p : Landroid/content/Intent;
      //   108: invokevirtual equals : (Ljava/lang/Object;)Z
      //   111: ifeq -> 123
      //   114: aload #4
      //   116: aconst_null
      //   117: putfield p : Landroid/content/Intent;
      //   120: goto -> 133
      //   123: new java/lang/IllegalStateException
      //   126: dup
      //   127: ldc 'Dequeue-d command is not the first.'
      //   129: invokespecial <init> : (Ljava/lang/String;)V
      //   132: athrow
      //   133: aload #4
      //   135: getfield i : Lt1/a;
      //   138: checkcast t1/b
      //   141: getfield a : Lr1/j;
      //   144: astore #6
      //   146: aload #4
      //   148: getfield m : Landroidx/work/impl/background/systemalarm/a;
      //   151: astore #8
      //   153: aload #8
      //   155: getfield j : Ljava/lang/Object;
      //   158: astore #7
      //   160: aload #7
      //   162: monitorenter
      //   163: aload #8
      //   165: getfield i : Ljava/util/Map;
      //   168: invokeinterface isEmpty : ()Z
      //   173: ifne -> 315
      //   176: iconst_1
      //   177: istore_1
      //   178: goto -> 181
      //   181: aload #7
      //   183: monitorexit
      //   184: iload_1
      //   185: ifne -> 279
      //   188: aload #4
      //   190: getfield o : Ljava/util/List;
      //   193: invokeinterface isEmpty : ()Z
      //   198: ifeq -> 279
      //   201: aload #6
      //   203: getfield j : Ljava/lang/Object;
      //   206: astore #7
      //   208: aload #7
      //   210: monitorenter
      //   211: aload #6
      //   213: getfield h : Ljava/util/ArrayDeque;
      //   216: invokevirtual isEmpty : ()Z
      //   219: ifne -> 320
      //   222: iload_2
      //   223: istore_1
      //   224: goto -> 227
      //   227: aload #7
      //   229: monitorexit
      //   230: iload_1
      //   231: ifne -> 279
      //   234: invokestatic c : ()Lh1/i;
      //   237: aload #5
      //   239: ldc 'No more commands & intents.'
      //   241: iconst_0
      //   242: anewarray java/lang/Throwable
      //   245: invokevirtual a : (Ljava/lang/String;Ljava/lang/String;[Ljava/lang/Throwable;)V
      //   248: aload #4
      //   250: getfield q : Landroidx/work/impl/background/systemalarm/d$c;
      //   253: astore #4
      //   255: aload #4
      //   257: ifnull -> 297
      //   260: aload #4
      //   262: checkcast androidx/work/impl/background/systemalarm/SystemAlarmService
      //   265: invokevirtual e : ()V
      //   268: goto -> 297
      //   271: astore #4
      //   273: aload #7
      //   275: monitorexit
      //   276: aload #4
      //   278: athrow
      //   279: aload #4
      //   281: getfield o : Ljava/util/List;
      //   284: invokeinterface isEmpty : ()Z
      //   289: ifne -> 297
      //   292: aload #4
      //   294: invokevirtual e : ()V
      //   297: aload_3
      //   298: monitorexit
      //   299: return
      //   300: astore #4
      //   302: aload #7
      //   304: monitorexit
      //   305: aload #4
      //   307: athrow
      //   308: astore #4
      //   310: aload_3
      //   311: monitorexit
      //   312: aload #4
      //   314: athrow
      //   315: iconst_0
      //   316: istore_1
      //   317: goto -> 181
      //   320: iconst_0
      //   321: istore_1
      //   322: goto -> 227
      // Exception table:
      //   from	to	target	type
      //   46	53	308	finally
      //   60	120	308	finally
      //   123	133	308	finally
      //   133	163	308	finally
      //   163	176	300	finally
      //   181	184	300	finally
      //   188	211	308	finally
      //   211	222	271	finally
      //   227	230	271	finally
      //   234	255	308	finally
      //   260	268	308	finally
      //   273	276	271	finally
      //   276	279	308	finally
      //   279	297	308	finally
      //   297	299	308	finally
      //   302	305	300	finally
      //   305	308	308	finally
      //   310	312	308	finally
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Luxury Logo Maker_ Logo Design-dex2jar.jar!\androidx\work\impl\background\systemalarm\d.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */