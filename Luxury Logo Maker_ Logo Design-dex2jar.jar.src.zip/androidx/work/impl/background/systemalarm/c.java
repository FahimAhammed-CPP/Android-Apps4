package androidx.work.impl.background.systemalarm;

import android.content.Context;
import android.content.Intent;
import android.os.PowerManager;
import h1.i;
import i1.b;
import java.util.Collections;
import java.util.List;
import m1.c;
import m1.d;
import q1.p;
import q1.q;
import q1.r;
import r1.m;
import r1.r;

public class c implements c, b, r.b {
  public static final String q = i.e("DelayMetCommandHandler");
  
  public final Context h;
  
  public final int i;
  
  public final String j;
  
  public final d k;
  
  public final d l;
  
  public final Object m;
  
  public int n;
  
  public PowerManager.WakeLock o;
  
  public boolean p;
  
  public c(Context paramContext, int paramInt, String paramString, d paramd) {
    this.h = paramContext;
    this.i = paramInt;
    this.k = paramd;
    this.j = paramString;
    this.l = new d(paramContext, paramd.i, this);
    this.p = false;
    this.n = 0;
    this.m = new Object();
  }
  
  public void a(String paramString, boolean paramBoolean) {
    i.c().a(q, String.format("onExecuted %s, %s", new Object[] { paramString, Boolean.valueOf(paramBoolean) }), new Throwable[0]);
    d();
    if (paramBoolean) {
      Intent intent = a.d(this.h, this.j);
      d d1 = this.k;
      d.b b1 = new d.b(d1, intent, this.i);
      d1.n.post(b1);
    } 
    if (this.p) {
      Intent intent = a.b(this.h);
      d d1 = this.k;
      d.b b1 = new d.b(d1, intent, this.i);
      d1.n.post(b1);
    } 
  }
  
  public void b(String paramString) {
    i.c().a(q, String.format("Exceeded time limits on execution for %s", new Object[] { paramString }), new Throwable[0]);
    g();
  }
  
  public void c(List<String> paramList) {
    g();
  }
  
  public final void d() {
    synchronized (this.m) {
      this.l.c();
      this.k.j.b(this.j);
      PowerManager.WakeLock wakeLock = this.o;
      if (wakeLock != null && wakeLock.isHeld()) {
        i.c().a(q, String.format("Releasing wakelock %s for WorkSpec %s", new Object[] { this.o, this.j }), new Throwable[0]);
        this.o.release();
      } 
      return;
    } 
  }
  
  public void e(List<String> paramList) {
    if (!paramList.contains(this.j))
      return; 
    synchronized (this.m) {
      if (this.n == 0) {
        this.n = 1;
        i.c().a(q, String.format("onAllConstraintsMet for %s", new Object[] { this.j }), new Throwable[0]);
        if (this.k.k.g(this.j, null)) {
          this.k.j.a(this.j, 600000L, this);
        } else {
          d();
        } 
      } else {
        i.c().a(q, String.format("Already started work for %s", new Object[] { this.j }), new Throwable[0]);
      } 
      return;
    } 
  }
  
  public void f() {
    this.o = m.a(this.h, String.format("%s (%s)", new Object[] { this.j, Integer.valueOf(this.i) }));
    i i = i.c();
    String str1 = q;
    i.a(str1, String.format("Acquiring wakelock %s for WorkSpec %s", new Object[] { this.o, this.j }), new Throwable[0]);
    this.o.acquire();
    q q = this.k.l.c.q();
    String str2 = this.j;
    p p = ((r)q).i(str2);
    if (p == null) {
      g();
      return;
    } 
    boolean bool = p.b();
    this.p = bool;
    if (!bool) {
      i.c().a(str1, String.format("No constraints for %s", new Object[] { this.j }), new Throwable[0]);
      e(Collections.singletonList(this.j));
      return;
    } 
    this.l.b(Collections.singletonList(p));
  }
  
  public final void g() {
    synchronized (this.m) {
      if (this.n < 2) {
        d d1;
        this.n = 2;
        i i = i.c();
        String str1 = q;
        i.a(str1, String.format("Stopping work for WorkSpec %s", new Object[] { this.j }), new Throwable[0]);
        Context context = this.h;
        String str2 = this.j;
        Intent intent = new Intent(context, SystemAlarmService.class);
        intent.setAction("ACTION_STOP_WORK");
        intent.putExtra("KEY_WORKSPEC_ID", str2);
        d d2 = this.k;
        d.b b1 = new d.b(d2, intent, this.i);
        d2.n.post(b1);
        if (this.k.k.d(this.j)) {
          i.c().a(str1, String.format("WorkSpec %s needs to be rescheduled", new Object[] { this.j }), new Throwable[0]);
          Intent intent1 = a.d(this.h, this.j);
          d1 = this.k;
          d.b b2 = new d.b(d1, intent1, this.i);
          d1.n.post(b2);
        } else {
          i.c().a((String)d1, String.format("Processor does not have WorkSpec %s. No need to reschedule ", new Object[] { this.j }), new Throwable[0]);
        } 
      } else {
        i.c().a(q, String.format("Already stopped work for %s", new Object[] { this.j }), new Throwable[0]);
      } 
      return;
    } 
  }
}


/* Location:              C:\soft\dex2jar-2.0\Luxury Logo Maker_ Logo Design-dex2jar.jar!\androidx\work\impl\background\systemalarm\c.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */