package androidx.work.impl.foreground;

import android.app.Notification;
import android.app.NotificationManager;
import android.content.Intent;
import android.os.Build;
import android.os.Handler;
import android.os.Looper;
import android.text.TextUtils;
import androidx.lifecycle.l;
import androidx.work.impl.WorkDatabase;
import h1.i;
import i1.k;
import java.util.Objects;
import java.util.UUID;
import p1.b;
import t1.b;

public class SystemForegroundService extends l implements a.a {
  public static final String m = i.e("SystemFgService");
  
  public Handler i;
  
  public boolean j;
  
  public a k;
  
  public NotificationManager l;
  
  public final void b() {
    this.i = new Handler(Looper.getMainLooper());
    this.l = (NotificationManager)getApplicationContext().getSystemService("notification");
    a a1 = new a(getApplicationContext());
    this.k = a1;
    if (a1.q != null) {
      i.c().b(a.r, "A callback already exists.", new Throwable[0]);
      return;
    } 
    a1.q = this;
  }
  
  public void e(int paramInt1, int paramInt2, Notification paramNotification) {
    this.i.post(new a(this, paramInt1, paramNotification, paramInt2));
  }
  
  public void onCreate() {
    super.onCreate();
    b();
  }
  
  public void onDestroy() {
    super.onDestroy();
    this.k.g();
  }
  
  public int onStartCommand(Intent paramIntent, int paramInt1, int paramInt2) {
    a.a a1;
    r1.a a2;
    super.onStartCommand(paramIntent, paramInt1, paramInt2);
    if (this.j) {
      i.c().d(m, "Re-initializing SystemForegroundService after a request to shut-down.", new Throwable[0]);
      this.k.g();
      b();
      this.j = false;
    } 
    if (paramIntent != null) {
      t1.a a4;
      a a3 = this.k;
      Objects.requireNonNull(a3);
      String str = paramIntent.getAction();
      if ("ACTION_START_FOREGROUND".equals(str)) {
        i.c().d(a.r, String.format("Started foreground service %s", new Object[] { paramIntent }), new Throwable[0]);
        String str1 = paramIntent.getStringExtra("KEY_WORKSPEC_ID");
        WorkDatabase workDatabase = a3.i.c;
        a4 = a3.j;
        b b = new b(a3, workDatabase, str1);
        ((b)a4).a.execute((Runnable)b);
      } else {
        String str1;
        if ("ACTION_NOTIFY".equals(a4)) {
          a3.f(paramIntent);
          return 3;
        } 
        if ("ACTION_CANCEL_WORK".equals(a4)) {
          i.c().d(a.r, String.format("Stopping foreground work for %s", new Object[] { paramIntent }), new Throwable[0]);
          str1 = paramIntent.getStringExtra("KEY_WORKSPEC_ID");
          if (str1 != null && !TextUtils.isEmpty(str1)) {
            k k = a3.i;
            UUID uUID = UUID.fromString(str1);
            Objects.requireNonNull(k);
            a2 = new r1.a(k, uUID);
            ((b)k.d).a.execute((Runnable)a2);
          } 
        } else if ("ACTION_STOP_FOREGROUND".equals(str1)) {
          i.c().d(a.r, "Stopping foreground service", new Throwable[0]);
          a1 = ((a)a2).q;
          if (a1 != null) {
            a1 = a1;
            ((SystemForegroundService)a1).j = true;
            i.c().a(m, "All commands completed.", new Throwable[0]);
            if (Build.VERSION.SDK_INT >= 26)
              a1.stopForeground(true); 
            a1.stopSelf();
          } 
        } 
        return 3;
      } 
    } else {
      return 3;
    } 
    a2.f((Intent)a1);
    return 3;
  }
  
  public class a implements Runnable {
    public a(SystemForegroundService this$0, int param1Int1, Notification param1Notification, int param1Int2) {}
    
    public void run() {
      if (Build.VERSION.SDK_INT >= 29) {
        this.k.startForeground(this.h, this.i, this.j);
        return;
      } 
      this.k.startForeground(this.h, this.i);
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Luxury Logo Maker_ Logo Design-dex2jar.jar!\androidx\work\impl\foreground\SystemForegroundService.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */