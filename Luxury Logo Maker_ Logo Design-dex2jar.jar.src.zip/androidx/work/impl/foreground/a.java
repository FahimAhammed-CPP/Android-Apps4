package androidx.work.impl.foreground;

import android.app.Notification;
import android.content.Context;
import android.content.Intent;
import android.os.Build;
import android.os.Parcelable;
import android.text.TextUtils;
import h1.e;
import h1.i;
import i1.b;
import i1.k;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;
import m1.c;
import m1.d;
import p1.c;
import p1.d;
import q1.p;
import r1.l;
import t1.b;

public class a implements c, b {
  public static final String r = i.e("SystemFgDispatcher");
  
  public Context h;
  
  public k i;
  
  public final t1.a j;
  
  public final Object k;
  
  public String l;
  
  public final Map<String, e> m;
  
  public final Map<String, p> n;
  
  public final Set<p> o;
  
  public final d p;
  
  public a q;
  
  public a(Context paramContext) {
    this.h = paramContext;
    this.k = new Object();
    k k1 = k.b(paramContext);
    this.i = k1;
    t1.a a1 = k1.d;
    this.j = a1;
    this.l = null;
    this.m = new LinkedHashMap<String, e>();
    this.o = new HashSet<p>();
    this.n = new HashMap<String, p>();
    this.p = new d(this.h, a1, this);
    this.i.f.b(this);
  }
  
  public static Intent b(Context paramContext, String paramString, e parame) {
    Intent intent = new Intent(paramContext, SystemForegroundService.class);
    intent.setAction("ACTION_NOTIFY");
    intent.putExtra("KEY_NOTIFICATION_ID", parame.a);
    intent.putExtra("KEY_FOREGROUND_SERVICE_TYPE", parame.b);
    intent.putExtra("KEY_NOTIFICATION", (Parcelable)parame.c);
    intent.putExtra("KEY_WORKSPEC_ID", paramString);
    return intent;
  }
  
  public static Intent d(Context paramContext, String paramString, e parame) {
    Intent intent = new Intent(paramContext, SystemForegroundService.class);
    intent.setAction("ACTION_START_FOREGROUND");
    intent.putExtra("KEY_WORKSPEC_ID", paramString);
    intent.putExtra("KEY_NOTIFICATION_ID", parame.a);
    intent.putExtra("KEY_FOREGROUND_SERVICE_TYPE", parame.b);
    intent.putExtra("KEY_NOTIFICATION", (Parcelable)parame.c);
    intent.putExtra("KEY_WORKSPEC_ID", paramString);
    return intent;
  }
  
  public void a(String paramString, boolean paramBoolean) {
    synchronized (this.k) {
      p p = this.n.remove(paramString);
      if (p != null) {
        paramBoolean = this.o.remove(p);
      } else {
        paramBoolean = false;
      } 
      if (paramBoolean)
        this.p.b(this.o); 
      null = this.m.remove(paramString);
      if (paramString.equals(this.l) && this.m.size() > 0) {
        Iterator<Map.Entry> iterator = this.m.entrySet().iterator();
        while (true) {
          Map.Entry entry = iterator.next();
          if (iterator.hasNext())
            continue; 
          this.l = (String)entry.getKey();
          if (this.q != null) {
            e e = (e)entry.getValue();
            a a2 = this.q;
            int i = e.a;
            int j = e.b;
            Notification notification = e.c;
            ((SystemForegroundService)a2).e(i, j, notification);
            a2 = this.q;
            i = e.a;
            SystemForegroundService systemForegroundService = (SystemForegroundService)a2;
            systemForegroundService.i.post((Runnable)new d(systemForegroundService, i));
          } 
          break;
        } 
      } 
      a a1 = this.q;
      if (null != null && a1 != null) {
        i.c().a(r, String.format("Removing Notification (id: %s, workSpecId: %s ,notificationType: %s)", new Object[] { Integer.valueOf(((e)null).a), paramString, Integer.valueOf(((e)null).b) }), new Throwable[0]);
        int i = ((e)null).a;
        SystemForegroundService systemForegroundService = (SystemForegroundService)a1;
        systemForegroundService.i.post((Runnable)new d(systemForegroundService, i));
      } 
      return;
    } 
  }
  
  public void c(List<String> paramList) {
    if (!paramList.isEmpty())
      for (String str : paramList) {
        i.c().a(r, String.format("Constraints unmet for WorkSpec %s", new Object[] { str }), new Throwable[0]);
        k k1 = this.i;
        t1.a a1 = k1.d;
        l l = new l(k1, str, true);
        ((b)a1).a.execute((Runnable)l);
      }  
  }
  
  public void e(List<String> paramList) {}
  
  public final void f(Intent paramIntent) {
    int i = 0;
    int j = paramIntent.getIntExtra("KEY_NOTIFICATION_ID", 0);
    int m = paramIntent.getIntExtra("KEY_FOREGROUND_SERVICE_TYPE", 0);
    String str = paramIntent.getStringExtra("KEY_WORKSPEC_ID");
    Notification notification = (Notification)paramIntent.getParcelableExtra("KEY_NOTIFICATION");
    i.c().a(r, String.format("Notifying with (id: %s, workSpecId: %s, notificationType: %s)", new Object[] { Integer.valueOf(j), str, Integer.valueOf(m) }), new Throwable[0]);
    if (notification != null && this.q != null) {
      e e = new e(j, notification, m);
      this.m.put(str, e);
      if (TextUtils.isEmpty(this.l)) {
        this.l = str;
        ((SystemForegroundService)this.q).e(j, m, notification);
        return;
      } 
      SystemForegroundService systemForegroundService = (SystemForegroundService)this.q;
      systemForegroundService.i.post((Runnable)new c(systemForegroundService, j, notification));
      if (m != 0 && Build.VERSION.SDK_INT >= 29) {
        Iterator iterator = this.m.entrySet().iterator();
        while (iterator.hasNext())
          i |= ((e)((Map.Entry)iterator.next()).getValue()).b; 
        e e1 = this.m.get(this.l);
        if (e1 != null) {
          a a1 = this.q;
          j = e1.a;
          Notification notification1 = e1.c;
          ((SystemForegroundService)a1).e(j, i, notification1);
        } 
      } 
    } 
  }
  
  public void g() {
    this.q = null;
    synchronized (this.k) {
      this.p.c();
      this.i.f.e(this);
      return;
    } 
  }
  
  public static interface a {}
}


/* Location:              C:\soft\dex2jar-2.0\Luxury Logo Maker_ Logo Design-dex2jar.jar!\androidx\work\impl\foreground\a.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */