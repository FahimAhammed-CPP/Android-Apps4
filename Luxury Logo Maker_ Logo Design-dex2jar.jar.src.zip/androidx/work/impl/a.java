package androidx.work.impl;

import android.content.Context;
import android.os.Build;

public class a {
  public static x0.a a = new a(1, 2);
  
  public static x0.a b = new b(3, 4);
  
  public static x0.a c = new c(4, 5);
  
  public static x0.a d = new d(6, 7);
  
  public static x0.a e = new e(7, 8);
  
  public static x0.a f = new f(8, 9);
  
  public static x0.a g = new g(11, 12);
  
  public class a extends x0.a {
    public a(a this$0, int param1Int1) {
      super(this$0, param1Int1);
    }
    
    public void a(z0.b param1b) {
      ((a1.a)param1b).h.execSQL("CREATE TABLE IF NOT EXISTS `SystemIdInfo` (`work_spec_id` TEXT NOT NULL, `system_id` INTEGER NOT NULL, PRIMARY KEY(`work_spec_id`), FOREIGN KEY(`work_spec_id`) REFERENCES `WorkSpec`(`id`) ON UPDATE CASCADE ON DELETE CASCADE )");
      a1.a a1 = (a1.a)param1b;
      a1.h.execSQL("INSERT INTO SystemIdInfo(work_spec_id, system_id) SELECT work_spec_id, alarm_id AS system_id FROM alarmInfo");
      a1.h.execSQL("DROP TABLE IF EXISTS alarmInfo");
      a1.h.execSQL("INSERT OR IGNORE INTO worktag(tag, work_spec_id) SELECT worker_class_name AS tag, id AS work_spec_id FROM workspec");
    }
  }
  
  public class b extends x0.a {
    public b(a this$0, int param1Int1) {
      super(this$0, param1Int1);
    }
    
    public void a(z0.b param1b) {
      if (Build.VERSION.SDK_INT >= 23)
        ((a1.a)param1b).h.execSQL("UPDATE workspec SET schedule_requested_at=0 WHERE state NOT IN (2, 3, 5) AND schedule_requested_at=-1 AND interval_duration<>0"); 
    }
  }
  
  public class c extends x0.a {
    public c(a this$0, int param1Int1) {
      super(this$0, param1Int1);
    }
    
    public void a(z0.b param1b) {
      ((a1.a)param1b).h.execSQL("ALTER TABLE workspec ADD COLUMN `trigger_content_update_delay` INTEGER NOT NULL DEFAULT -1");
      ((a1.a)param1b).h.execSQL("ALTER TABLE workspec ADD COLUMN `trigger_max_content_delay` INTEGER NOT NULL DEFAULT -1");
    }
  }
  
  public class d extends x0.a {
    public d(a this$0, int param1Int1) {
      super(this$0, param1Int1);
    }
    
    public void a(z0.b param1b) {
      ((a1.a)param1b).h.execSQL("CREATE TABLE IF NOT EXISTS `WorkProgress` (`work_spec_id` TEXT NOT NULL, `progress` BLOB NOT NULL, PRIMARY KEY(`work_spec_id`), FOREIGN KEY(`work_spec_id`) REFERENCES `WorkSpec`(`id`) ON UPDATE CASCADE ON DELETE CASCADE )");
    }
  }
  
  public class e extends x0.a {
    public e(a this$0, int param1Int1) {
      super(this$0, param1Int1);
    }
    
    public void a(z0.b param1b) {
      ((a1.a)param1b).h.execSQL("CREATE INDEX IF NOT EXISTS `index_WorkSpec_period_start_time` ON `workspec` (`period_start_time`)");
    }
  }
  
  public class f extends x0.a {
    public f(a this$0, int param1Int1) {
      super(this$0, param1Int1);
    }
    
    public void a(z0.b param1b) {
      ((a1.a)param1b).h.execSQL("ALTER TABLE workspec ADD COLUMN `run_in_foreground` INTEGER NOT NULL DEFAULT 0");
    }
  }
  
  public class g extends x0.a {
    public g(a this$0, int param1Int1) {
      super(this$0, param1Int1);
    }
    
    public void a(z0.b param1b) {
      ((a1.a)param1b).h.execSQL("ALTER TABLE workspec ADD COLUMN `out_of_quota_policy` INTEGER NOT NULL DEFAULT 0");
    }
  }
  
  public static class h extends x0.a {
    public final Context c;
    
    public h(Context param1Context, int param1Int1, int param1Int2) {
      super(param1Int1, param1Int2);
      this.c = param1Context;
    }
    
    public void a(z0.b param1b) {
      if (this.b >= 10) {
        ((a1.a)param1b).h.execSQL("INSERT OR REPLACE INTO `Preference` (`key`, `long_value`) VALUES (@key, @long_value)", new Object[] { "reschedule_needed", Integer.valueOf(1) });
        return;
      } 
      this.c.getSharedPreferences("androidx.work.util.preferences", 0).edit().putBoolean("reschedule_needed", true).apply();
    }
  }
  
  public static class i extends x0.a {
    public final Context c;
    
    public i(Context param1Context) {
      super(9, 10);
      this.c = param1Context;
    }
    
    public void a(z0.b param1b) {
      // Byte code:
      //   0: aload_1
      //   1: checkcast a1/a
      //   4: getfield h : Landroid/database/sqlite/SQLiteDatabase;
      //   7: ldc 'CREATE TABLE IF NOT EXISTS `Preference` (`key` TEXT NOT NULL, `long_value` INTEGER, PRIMARY KEY(`key`))'
      //   9: invokevirtual execSQL : (Ljava/lang/String;)V
      //   12: aload_0
      //   13: getfield c : Landroid/content/Context;
      //   16: ldc 'androidx.work.util.preferences'
      //   18: iconst_0
      //   19: invokevirtual getSharedPreferences : (Ljava/lang/String;I)Landroid/content/SharedPreferences;
      //   22: astore #9
      //   24: aload #9
      //   26: ldc 'reschedule_needed'
      //   28: invokeinterface contains : (Ljava/lang/String;)Z
      //   33: ifne -> 48
      //   36: aload #9
      //   38: ldc 'last_cancel_all_time_ms'
      //   40: invokeinterface contains : (Ljava/lang/String;)Z
      //   45: ifeq -> 186
      //   48: lconst_0
      //   49: lstore #4
      //   51: aload #9
      //   53: ldc 'last_cancel_all_time_ms'
      //   55: lconst_0
      //   56: invokeinterface getLong : (Ljava/lang/String;J)J
      //   61: lstore #6
      //   63: aload #9
      //   65: ldc 'reschedule_needed'
      //   67: iconst_0
      //   68: invokeinterface getBoolean : (Ljava/lang/String;Z)Z
      //   73: ifeq -> 79
      //   76: lconst_1
      //   77: lstore #4
      //   79: aload_1
      //   80: checkcast a1/a
      //   83: astore #8
      //   85: aload #8
      //   87: getfield h : Landroid/database/sqlite/SQLiteDatabase;
      //   90: invokevirtual beginTransaction : ()V
      //   93: aload_1
      //   94: checkcast a1/a
      //   97: getfield h : Landroid/database/sqlite/SQLiteDatabase;
      //   100: ldc 'INSERT OR REPLACE INTO `Preference` (`key`, `long_value`) VALUES (@key, @long_value)'
      //   102: iconst_2
      //   103: anewarray java/lang/Object
      //   106: dup
      //   107: iconst_0
      //   108: ldc 'last_cancel_all_time_ms'
      //   110: aastore
      //   111: dup
      //   112: iconst_1
      //   113: lload #6
      //   115: invokestatic valueOf : (J)Ljava/lang/Long;
      //   118: aastore
      //   119: invokevirtual execSQL : (Ljava/lang/String;[Ljava/lang/Object;)V
      //   122: aload_1
      //   123: checkcast a1/a
      //   126: getfield h : Landroid/database/sqlite/SQLiteDatabase;
      //   129: ldc 'INSERT OR REPLACE INTO `Preference` (`key`, `long_value`) VALUES (@key, @long_value)'
      //   131: iconst_2
      //   132: anewarray java/lang/Object
      //   135: dup
      //   136: iconst_0
      //   137: ldc 'reschedule_needed'
      //   139: aastore
      //   140: dup
      //   141: iconst_1
      //   142: lload #4
      //   144: invokestatic valueOf : (J)Ljava/lang/Long;
      //   147: aastore
      //   148: invokevirtual execSQL : (Ljava/lang/String;[Ljava/lang/Object;)V
      //   151: aload #9
      //   153: invokeinterface edit : ()Landroid/content/SharedPreferences$Editor;
      //   158: invokeinterface clear : ()Landroid/content/SharedPreferences$Editor;
      //   163: invokeinterface apply : ()V
      //   168: aload_1
      //   169: checkcast a1/a
      //   172: getfield h : Landroid/database/sqlite/SQLiteDatabase;
      //   175: invokevirtual setTransactionSuccessful : ()V
      //   178: aload #8
      //   180: getfield h : Landroid/database/sqlite/SQLiteDatabase;
      //   183: invokevirtual endTransaction : ()V
      //   186: aload_0
      //   187: getfield c : Landroid/content/Context;
      //   190: ldc 'androidx.work.util.id'
      //   192: iconst_0
      //   193: invokevirtual getSharedPreferences : (Ljava/lang/String;I)Landroid/content/SharedPreferences;
      //   196: astore #9
      //   198: aload #9
      //   200: ldc 'next_job_scheduler_id'
      //   202: invokeinterface contains : (Ljava/lang/String;)Z
      //   207: ifne -> 222
      //   210: aload #9
      //   212: ldc 'next_job_scheduler_id'
      //   214: invokeinterface contains : (Ljava/lang/String;)Z
      //   219: ifeq -> 349
      //   222: aload #9
      //   224: ldc 'next_job_scheduler_id'
      //   226: iconst_0
      //   227: invokeinterface getInt : (Ljava/lang/String;I)I
      //   232: istore_2
      //   233: aload #9
      //   235: ldc 'next_alarm_manager_id'
      //   237: iconst_0
      //   238: invokeinterface getInt : (Ljava/lang/String;I)I
      //   243: istore_3
      //   244: aload_1
      //   245: checkcast a1/a
      //   248: astore #8
      //   250: aload #8
      //   252: getfield h : Landroid/database/sqlite/SQLiteDatabase;
      //   255: invokevirtual beginTransaction : ()V
      //   258: aload_1
      //   259: checkcast a1/a
      //   262: getfield h : Landroid/database/sqlite/SQLiteDatabase;
      //   265: ldc 'INSERT OR REPLACE INTO `Preference` (`key`, `long_value`) VALUES (@key, @long_value)'
      //   267: iconst_2
      //   268: anewarray java/lang/Object
      //   271: dup
      //   272: iconst_0
      //   273: ldc 'next_job_scheduler_id'
      //   275: aastore
      //   276: dup
      //   277: iconst_1
      //   278: iload_2
      //   279: invokestatic valueOf : (I)Ljava/lang/Integer;
      //   282: aastore
      //   283: invokevirtual execSQL : (Ljava/lang/String;[Ljava/lang/Object;)V
      //   286: aload_1
      //   287: checkcast a1/a
      //   290: getfield h : Landroid/database/sqlite/SQLiteDatabase;
      //   293: ldc 'INSERT OR REPLACE INTO `Preference` (`key`, `long_value`) VALUES (@key, @long_value)'
      //   295: iconst_2
      //   296: anewarray java/lang/Object
      //   299: dup
      //   300: iconst_0
      //   301: ldc 'next_alarm_manager_id'
      //   303: aastore
      //   304: dup
      //   305: iconst_1
      //   306: iload_3
      //   307: invokestatic valueOf : (I)Ljava/lang/Integer;
      //   310: aastore
      //   311: invokevirtual execSQL : (Ljava/lang/String;[Ljava/lang/Object;)V
      //   314: aload #9
      //   316: invokeinterface edit : ()Landroid/content/SharedPreferences$Editor;
      //   321: invokeinterface clear : ()Landroid/content/SharedPreferences$Editor;
      //   326: invokeinterface apply : ()V
      //   331: aload_1
      //   332: checkcast a1/a
      //   335: getfield h : Landroid/database/sqlite/SQLiteDatabase;
      //   338: invokevirtual setTransactionSuccessful : ()V
      //   341: aload #8
      //   343: getfield h : Landroid/database/sqlite/SQLiteDatabase;
      //   346: invokevirtual endTransaction : ()V
      //   349: return
      //   350: astore_1
      //   351: aload #8
      //   353: getfield h : Landroid/database/sqlite/SQLiteDatabase;
      //   356: invokevirtual endTransaction : ()V
      //   359: aload_1
      //   360: athrow
      //   361: astore_1
      //   362: aload #8
      //   364: getfield h : Landroid/database/sqlite/SQLiteDatabase;
      //   367: invokevirtual endTransaction : ()V
      //   370: aload_1
      //   371: athrow
      // Exception table:
      //   from	to	target	type
      //   93	178	361	finally
      //   258	341	350	finally
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Luxury Logo Maker_ Logo Design-dex2jar.jar!\androidx\work\impl\a.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */