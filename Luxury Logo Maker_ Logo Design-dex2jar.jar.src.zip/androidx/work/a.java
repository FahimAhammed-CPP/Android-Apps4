package androidx.work;

import h1.h;
import h1.q;
import h1.r;
import java.util.concurrent.Executor;
import java.util.concurrent.Executors;
import java.util.concurrent.ThreadFactory;

public final class a {
  public final Executor a = a(false);
  
  public final Executor b = a(true);
  
  public final r c;
  
  public final android.support.v4.media.b d;
  
  public final i1.a e;
  
  public final int f;
  
  public final int g;
  
  public final int h;
  
  public a(a parama) {
    String str = r.a;
    this.c = (r)new q();
    this.d = (android.support.v4.media.b)new h();
    this.e = new i1.a(0);
    this.f = 4;
    this.g = Integer.MAX_VALUE;
    this.h = 20;
  }
  
  public final Executor a(boolean paramBoolean) {
    return Executors.newFixedThreadPool(Math.max(2, Math.min(Runtime.getRuntime().availableProcessors() - 1, 4)), (ThreadFactory)new h1.b(this, paramBoolean));
  }
  
  public static final class a {}
  
  public static interface b {
    a a();
  }
}


/* Location:              C:\soft\dex2jar-2.0\Luxury Logo Maker_ Logo Design-dex2jar.jar!\androidx\work\a.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */