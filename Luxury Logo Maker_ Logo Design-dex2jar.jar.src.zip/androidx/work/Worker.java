package androidx.work;

import android.annotation.SuppressLint;
import android.content.Context;
import androidx.annotation.Keep;
import s1.c;

public abstract class Worker extends ListenableWorker {
  public c<ListenableWorker.a> m;
  
  @SuppressLint({"BanKeepAnnotation"})
  @Keep
  public Worker(Context paramContext, WorkerParameters paramWorkerParameters) {
    super(paramContext, paramWorkerParameters);
  }
  
  public abstract ListenableWorker.a doWork();
  
  public final r5.a<ListenableWorker.a> startWork() {
    this.m = new c();
    getBackgroundExecutor().execute(new a(this));
    return (r5.a<ListenableWorker.a>)this.m;
  }
  
  public class a implements Runnable {
    public a(Worker this$0) {}
    
    public void run() {
      try {
        return;
      } finally {
        Exception exception = null;
        this.h.m.l(exception);
      } 
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Luxury Logo Maker_ Logo Design-dex2jar.jar!\androidx\work\Worker.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */