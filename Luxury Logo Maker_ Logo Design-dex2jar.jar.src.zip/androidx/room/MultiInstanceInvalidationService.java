package androidx.room;

import android.app.Service;
import android.content.Intent;
import android.os.IBinder;
import android.os.IInterface;
import android.os.RemoteCallbackList;
import android.os.RemoteException;
import android.util.Log;
import java.util.HashMap;
import w0.c;
import w0.d;

public class MultiInstanceInvalidationService extends Service {
  public int h = 0;
  
  public final HashMap<Integer, String> i = new HashMap<Integer, String>();
  
  public final RemoteCallbackList<c> j = new a(this);
  
  public final d k = new b(this);
  
  public IBinder onBind(Intent paramIntent) {
    return (IBinder)this.k;
  }
  
  public class a extends RemoteCallbackList<c> {
    public a(MultiInstanceInvalidationService this$0) {}
    
    public void onCallbackDied(IInterface param1IInterface, Object param1Object) {
      c c = (c)param1IInterface;
      this.a.i.remove(Integer.valueOf(((Integer)param1Object).intValue()));
    }
  }
  
  public class b extends d {
    public b(MultiInstanceInvalidationService this$0) {}
    
    public void I(int param1Int, String[] param1ArrayOfString) {
      synchronized (this.h.j) {
        String str = this.h.i.get(Integer.valueOf(param1Int));
        if (str == null) {
          Log.w("ROOM", "Remote invalidation client ID not registered");
          return;
        } 
        int j = this.h.j.beginBroadcast();
        int i = 0;
        while (i < j) {
          try {
            int k = ((Integer)this.h.j.getBroadcastCookie(i)).intValue();
            String str1 = this.h.i.get(Integer.valueOf(k));
            if (param1Int != k) {
              boolean bool = str.equals(str1);
              if (bool)
                try {
                  ((c)this.h.j.getBroadcastItem(i)).f1(param1ArrayOfString);
                } catch (RemoteException remoteException) {
                  Log.w("ROOM", "Error invoking a remote callback", (Throwable)remoteException);
                }  
            } 
          } finally {
            this.h.j.finishBroadcast();
          } 
        } 
        this.h.j.finishBroadcast();
        return;
      } 
    }
    
    public int f0(c param1c, String param1String) {
      if (param1String == null)
        return 0; 
      synchronized (this.h.j) {
        MultiInstanceInvalidationService multiInstanceInvalidationService2 = this.h;
        int i = multiInstanceInvalidationService2.h + 1;
        multiInstanceInvalidationService2.h = i;
        if (multiInstanceInvalidationService2.j.register((IInterface)param1c, Integer.valueOf(i))) {
          this.h.i.put(Integer.valueOf(i), param1String);
          return i;
        } 
        MultiInstanceInvalidationService multiInstanceInvalidationService1 = this.h;
        multiInstanceInvalidationService1.h--;
        return 0;
      } 
    }
    
    public void h0(c param1c, int param1Int) {
      synchronized (this.h.j) {
        this.h.j.unregister((IInterface)param1c);
        this.h.i.remove(Integer.valueOf(param1Int));
        return;
      } 
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Luxury Logo Maker_ Logo Design-dex2jar.jar!\androidx\room\MultiInstanceInvalidationService.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */