package androidx.swiperefreshlayout.widget;

import android.content.Context;
import android.content.res.TypedArray;
import android.graphics.drawable.Drawable;
import android.util.AttributeSet;
import android.util.DisplayMetrics;
import android.util.Log;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewConfiguration;
import android.view.ViewGroup;
import android.view.animation.Animation;
import android.view.animation.DecelerateInterpolator;
import android.view.animation.Interpolator;
import android.view.animation.Transformation;
import android.widget.ListView;
import i6.d0;
import java.util.Objects;
import java.util.WeakHashMap;
import k0.e;
import k0.i;
import k0.l;
import photofiesta.luxury.logomaker.FrameWorking.FrameActivity;

public class SwipeRefreshLayout extends ViewGroup implements e {
  public static final int[] Q = new int[] { 16842766 };
  
  public int A = -1;
  
  public int B;
  
  public int C;
  
  public int D;
  
  public int E;
  
  public c1.d F;
  
  public Animation G;
  
  public Animation H;
  
  public Animation I;
  
  public Animation J;
  
  public boolean K;
  
  public int L;
  
  public g M;
  
  public Animation.AnimationListener N = new a(this);
  
  public final Animation O = new e(this);
  
  public final Animation P = new f(this);
  
  public View h;
  
  public h i;
  
  public boolean j = false;
  
  public int k;
  
  public float l = -1.0F;
  
  public float m;
  
  public final i n;
  
  public final k0.f o;
  
  public final int[] p = new int[2];
  
  public final int[] q = new int[2];
  
  public boolean r;
  
  public int s;
  
  public int t;
  
  public float u;
  
  public float v;
  
  public boolean w;
  
  public int x = -1;
  
  public final DecelerateInterpolator y;
  
  public c1.a z;
  
  public SwipeRefreshLayout(Context paramContext, AttributeSet paramAttributeSet) {
    super(paramContext, paramAttributeSet);
    this.k = ViewConfiguration.get(paramContext).getScaledTouchSlop();
    this.s = getResources().getInteger(17694721);
    setWillNotDraw(false);
    this.y = new DecelerateInterpolator(2.0F);
    DisplayMetrics displayMetrics = getResources().getDisplayMetrics();
    this.L = (int)(displayMetrics.density * 40.0F);
    this.z = new c1.a(getContext(), -328966);
    c1.d d1 = new c1.d(getContext());
    this.F = d1;
    d1.c(1);
    this.z.setImageDrawable((Drawable)this.F);
    this.z.setVisibility(8);
    addView((View)this.z);
    setChildrenDrawingOrderEnabled(true);
    int j = (int)(displayMetrics.density * 64.0F);
    this.D = j;
    this.l = j;
    this.n = new i();
    this.o = new k0.f((View)this);
    setNestedScrollingEnabled(true);
    j = -this.L;
    this.t = j;
    this.C = j;
    f(1.0F);
    TypedArray typedArray = paramContext.obtainStyledAttributes(paramAttributeSet, Q);
    setEnabled(typedArray.getBoolean(0, true));
    typedArray.recycle();
  }
  
  private void setColorViewAlpha(int paramInt) {
    this.z.getBackground().setAlpha(paramInt);
    c1.d d1 = this.F;
    d1.h.t = paramInt;
    d1.invalidateSelf();
  }
  
  public boolean a() {
    g g1 = this.M;
    if (g1 != null)
      return g1.a(this, this.h); 
    View view = this.h;
    return (view instanceof ListView) ? ((ListView)view).canScrollList(-1) : view.canScrollVertically(-1);
  }
  
  public final void b() {
    if (this.h == null)
      for (int j = 0; j < getChildCount(); j++) {
        View view = getChildAt(j);
        if (!view.equals(this.z)) {
          this.h = view;
          return;
        } 
      }  
  }
  
  public final void c(float paramFloat) {
    if (paramFloat > this.l) {
      i(true, true);
      return;
    } 
    this.j = false;
    c1.d d3 = this.F;
    c1.d.a a3 = d3.h;
    a3.e = 0.0F;
    a3.f = 0.0F;
    d3.invalidateSelf();
    d d2 = new d(this);
    this.B = this.t;
    this.P.reset();
    this.P.setDuration(200L);
    this.P.setInterpolator((Interpolator)this.y);
    c1.a a2 = this.z;
    a2.h = d2;
    a2.clearAnimation();
    this.z.startAnimation(this.P);
    c1.d d1 = this.F;
    c1.d.a a1 = d1.h;
    if (a1.n)
      a1.n = false; 
    d1.invalidateSelf();
  }
  
  public final boolean d(Animation paramAnimation) {
    return (paramAnimation != null && paramAnimation.hasStarted() && !paramAnimation.hasEnded());
  }
  
  public boolean dispatchNestedFling(float paramFloat1, float paramFloat2, boolean paramBoolean) {
    return this.o.a(paramFloat1, paramFloat2, paramBoolean);
  }
  
  public boolean dispatchNestedPreFling(float paramFloat1, float paramFloat2) {
    return this.o.b(paramFloat1, paramFloat2);
  }
  
  public boolean dispatchNestedPreScroll(int paramInt1, int paramInt2, int[] paramArrayOfint1, int[] paramArrayOfint2) {
    return this.o.c(paramInt1, paramInt2, paramArrayOfint1, paramArrayOfint2, 0);
  }
  
  public boolean dispatchNestedScroll(int paramInt1, int paramInt2, int paramInt3, int paramInt4, int[] paramArrayOfint) {
    return this.o.e(paramInt1, paramInt2, paramInt3, paramInt4, paramArrayOfint);
  }
  
  public final void e(float paramFloat) {
    c1.d d2 = this.F;
    c1.d.a a1 = d2.h;
    if (a1.n != true)
      a1.n = true; 
    d2.invalidateSelf();
    float f2 = Math.min(1.0F, Math.abs(paramFloat / this.l));
    float f1 = (float)Math.max(f2 - 0.4D, 0.0D) * 5.0F / 3.0F;
    float f4 = Math.abs(paramFloat);
    float f5 = this.l;
    int j = this.E;
    if (j <= 0)
      j = this.D; 
    float f3 = j;
    double d1 = (Math.max(0.0F, Math.min(f4 - f5, f3 * 2.0F) / f3) / 4.0F);
    f4 = (float)(d1 - Math.pow(d1, 2.0D)) * 2.0F;
    j = this.C;
    int k = (int)(f3 * f2 + f3 * f4 * 2.0F);
    if (this.z.getVisibility() != 0)
      this.z.setVisibility(0); 
    this.z.setScaleX(1.0F);
    this.z.setScaleY(1.0F);
    if (paramFloat < this.l) {
      if (this.F.h.t > 76 && !d(this.I))
        this.I = j(this.F.h.t, 76); 
    } else if (this.F.h.t < 255 && !d(this.J)) {
      this.J = j(this.F.h.t, 255);
    } 
    d2 = this.F;
    paramFloat = Math.min(0.8F, f1 * 0.8F);
    a1 = d2.h;
    a1.e = 0.0F;
    a1.f = paramFloat;
    d2.invalidateSelf();
    d2 = this.F;
    paramFloat = Math.min(1.0F, f1);
    a1 = d2.h;
    if (paramFloat != a1.p)
      a1.p = paramFloat; 
    d2.invalidateSelf();
    d2 = this.F;
    d2.h.g = (f4 * 2.0F + f1 * 0.4F - 0.25F) * 0.5F;
    d2.invalidateSelf();
    setTargetOffsetTopAndBottom(j + k - this.t);
  }
  
  public void f(float paramFloat) {
    int j = this.B;
    setTargetOffsetTopAndBottom(j + (int)((this.C - j) * paramFloat) - this.z.getTop());
  }
  
  public final void g(MotionEvent paramMotionEvent) {
    int j = paramMotionEvent.getActionIndex();
    if (paramMotionEvent.getPointerId(j) == this.x) {
      if (j == 0) {
        j = 1;
      } else {
        j = 0;
      } 
      this.x = paramMotionEvent.getPointerId(j);
    } 
  }
  
  public int getChildDrawingOrder(int paramInt1, int paramInt2) {
    int j = this.A;
    if (j < 0)
      return paramInt2; 
    if (paramInt2 == paramInt1 - 1)
      return j; 
    paramInt1 = paramInt2;
    if (paramInt2 >= j)
      paramInt1 = paramInt2 + 1; 
    return paramInt1;
  }
  
  public int getNestedScrollAxes() {
    return this.n.a();
  }
  
  public int getProgressCircleDiameter() {
    return this.L;
  }
  
  public int getProgressViewEndOffset() {
    return this.D;
  }
  
  public int getProgressViewStartOffset() {
    return this.C;
  }
  
  public void h() {
    this.z.clearAnimation();
    this.F.stop();
    this.z.setVisibility(8);
    setColorViewAlpha(255);
    setTargetOffsetTopAndBottom(this.C - this.t);
    this.t = this.z.getTop();
  }
  
  public boolean hasNestedScrollingParent() {
    return this.o.h(0);
  }
  
  public final void i(boolean paramBoolean1, boolean paramBoolean2) {
    if (this.j != paramBoolean1) {
      this.K = paramBoolean2;
      b();
      this.j = paramBoolean1;
      if (paramBoolean1) {
        int j = this.t;
        Animation.AnimationListener animationListener = this.N;
        this.B = j;
        this.O.reset();
        this.O.setDuration(200L);
        this.O.setInterpolator((Interpolator)this.y);
        if (animationListener != null)
          this.z.h = animationListener; 
        this.z.clearAnimation();
        this.z.startAnimation(this.O);
        return;
      } 
      l(this.N);
    } 
  }
  
  public boolean isNestedScrollingEnabled() {
    return this.o.d;
  }
  
  public final Animation j(int paramInt1, int paramInt2) {
    c c = new c(this, paramInt1, paramInt2);
    c.setDuration(300L);
    c1.a a1 = this.z;
    a1.h = null;
    a1.clearAnimation();
    this.z.startAnimation(c);
    return c;
  }
  
  public final void k(float paramFloat) {
    float f1 = this.v;
    int j = this.k;
    if (paramFloat - f1 > j && !this.w) {
      this.u = f1 + j;
      this.w = true;
      this.F.setAlpha(76);
    } 
  }
  
  public void l(Animation.AnimationListener paramAnimationListener) {
    b b = new b(this);
    this.H = b;
    b.setDuration(150L);
    c1.a a1 = this.z;
    a1.h = paramAnimationListener;
    a1.clearAnimation();
    this.z.startAnimation(this.H);
  }
  
  public void onDetachedFromWindow() {
    super.onDetachedFromWindow();
    h();
  }
  
  public boolean onInterceptTouchEvent(MotionEvent paramMotionEvent) {
    b();
    int j = paramMotionEvent.getActionMasked();
    if (isEnabled() && !a() && !this.j) {
      if (this.r)
        return false; 
      if (j != 0) {
        if (j != 1)
          if (j != 2) {
            if (j != 3) {
              if (j == 6)
                g(paramMotionEvent); 
              return this.w;
            } 
          } else {
            j = this.x;
            if (j == -1) {
              Log.e("SwipeRefreshLayout", "Got ACTION_MOVE event but don't have an active pointer id.");
              return false;
            } 
            j = paramMotionEvent.findPointerIndex(j);
            if (j < 0)
              return false; 
            k(paramMotionEvent.getY(j));
            return this.w;
          }  
        this.w = false;
        this.x = -1;
      } else {
        setTargetOffsetTopAndBottom(this.C - this.z.getTop());
        j = paramMotionEvent.getPointerId(0);
        this.x = j;
        this.w = false;
        j = paramMotionEvent.findPointerIndex(j);
        if (j < 0)
          return false; 
        this.v = paramMotionEvent.getY(j);
      } 
      return this.w;
    } 
    return false;
  }
  
  public void onLayout(boolean paramBoolean, int paramInt1, int paramInt2, int paramInt3, int paramInt4) {
    paramInt1 = getMeasuredWidth();
    paramInt2 = getMeasuredHeight();
    if (getChildCount() == 0)
      return; 
    if (this.h == null)
      b(); 
    View view = this.h;
    if (view == null)
      return; 
    paramInt3 = getPaddingLeft();
    paramInt4 = getPaddingTop();
    view.layout(paramInt3, paramInt4, paramInt1 - getPaddingLeft() - getPaddingRight() + paramInt3, paramInt2 - getPaddingTop() - getPaddingBottom() + paramInt4);
    paramInt3 = this.z.getMeasuredWidth();
    paramInt2 = this.z.getMeasuredHeight();
    c1.a a1 = this.z;
    paramInt1 /= 2;
    paramInt3 /= 2;
    paramInt4 = this.t;
    a1.layout(paramInt1 - paramInt3, paramInt4, paramInt1 + paramInt3, paramInt2 + paramInt4);
  }
  
  public void onMeasure(int paramInt1, int paramInt2) {
    super.onMeasure(paramInt1, paramInt2);
    if (this.h == null)
      b(); 
    View view = this.h;
    if (view == null)
      return; 
    view.measure(View.MeasureSpec.makeMeasureSpec(getMeasuredWidth() - getPaddingLeft() - getPaddingRight(), 1073741824), View.MeasureSpec.makeMeasureSpec(getMeasuredHeight() - getPaddingTop() - getPaddingBottom(), 1073741824));
    this.z.measure(View.MeasureSpec.makeMeasureSpec(this.L, 1073741824), View.MeasureSpec.makeMeasureSpec(this.L, 1073741824));
    this.A = -1;
    for (paramInt1 = 0; paramInt1 < getChildCount(); paramInt1++) {
      if (getChildAt(paramInt1) == this.z) {
        this.A = paramInt1;
        return;
      } 
    } 
  }
  
  public boolean onNestedFling(View paramView, float paramFloat1, float paramFloat2, boolean paramBoolean) {
    return dispatchNestedFling(paramFloat1, paramFloat2, paramBoolean);
  }
  
  public boolean onNestedPreFling(View paramView, float paramFloat1, float paramFloat2) {
    return dispatchNestedPreFling(paramFloat1, paramFloat2);
  }
  
  public void onNestedPreScroll(View paramView, int paramInt1, int paramInt2, int[] paramArrayOfint) {
    if (paramInt2 > 0) {
      float f1 = this.m;
      if (f1 > 0.0F) {
        float f2 = paramInt2;
        if (f2 > f1) {
          paramArrayOfint[1] = paramInt2 - (int)f1;
          this.m = 0.0F;
        } else {
          this.m = f1 - f2;
          paramArrayOfint[1] = paramInt2;
        } 
        e(this.m);
      } 
    } 
    int[] arrayOfInt = this.p;
    if (dispatchNestedPreScroll(paramInt1 - paramArrayOfint[0], paramInt2 - paramArrayOfint[1], arrayOfInt, null)) {
      paramArrayOfint[0] = paramArrayOfint[0] + arrayOfInt[0];
      paramArrayOfint[1] = paramArrayOfint[1] + arrayOfInt[1];
    } 
  }
  
  public void onNestedScroll(View paramView, int paramInt1, int paramInt2, int paramInt3, int paramInt4) {
    dispatchNestedScroll(paramInt1, paramInt2, paramInt3, paramInt4, this.q);
    paramInt1 = paramInt4 + this.q[1];
    if (paramInt1 < 0 && !a()) {
      float f1 = this.m + Math.abs(paramInt1);
      this.m = f1;
      e(f1);
    } 
  }
  
  public void onNestedScrollAccepted(View paramView1, View paramView2, int paramInt) {
    this.n.a = paramInt;
    startNestedScroll(paramInt & 0x2);
    this.m = 0.0F;
    this.r = true;
  }
  
  public boolean onStartNestedScroll(View paramView1, View paramView2, int paramInt) {
    return (isEnabled() && !this.j && (paramInt & 0x2) != 0);
  }
  
  public void onStopNestedScroll(View paramView) {
    this.n.b(0);
    this.r = false;
    float f1 = this.m;
    if (f1 > 0.0F) {
      c(f1);
      this.m = 0.0F;
    } 
    stopNestedScroll();
  }
  
  public boolean onTouchEvent(MotionEvent paramMotionEvent) {
    int j = paramMotionEvent.getActionMasked();
    if (isEnabled() && !a() && !this.j) {
      if (this.r)
        return false; 
      if (j != 0) {
        if (j != 1) {
          if (j != 2) {
            if (j != 3) {
              if (j != 5) {
                if (j != 6)
                  return true; 
                g(paramMotionEvent);
                return true;
              } 
              j = paramMotionEvent.getActionIndex();
              if (j < 0) {
                Log.e("SwipeRefreshLayout", "Got ACTION_POINTER_DOWN event but have an invalid action index.");
                return false;
              } 
              this.x = paramMotionEvent.getPointerId(j);
              return true;
            } 
            return false;
          } 
          j = paramMotionEvent.findPointerIndex(this.x);
          if (j < 0) {
            Log.e("SwipeRefreshLayout", "Got ACTION_MOVE event but have an invalid active pointer id.");
            return false;
          } 
          float f1 = paramMotionEvent.getY(j);
          k(f1);
          if (this.w) {
            f1 = (f1 - this.u) * 0.5F;
            if (f1 > 0.0F) {
              e(f1);
              return true;
            } 
            return false;
          } 
        } else {
          j = paramMotionEvent.findPointerIndex(this.x);
          if (j < 0) {
            Log.e("SwipeRefreshLayout", "Got ACTION_UP event but don't have an active pointer id.");
            return false;
          } 
          if (this.w) {
            float f1 = paramMotionEvent.getY(j);
            float f2 = this.u;
            this.w = false;
            c((f1 - f2) * 0.5F);
          } 
          this.x = -1;
          return false;
        } 
      } else {
        this.x = paramMotionEvent.getPointerId(0);
        this.w = false;
      } 
      return true;
    } 
    return false;
  }
  
  public void requestDisallowInterceptTouchEvent(boolean paramBoolean) {
    View view = this.h;
    if (view != null) {
      WeakHashMap weakHashMap = l.a;
      if (!view.isNestedScrollingEnabled())
        return; 
    } 
    super.requestDisallowInterceptTouchEvent(paramBoolean);
  }
  
  public void setAnimationProgress(float paramFloat) {
    this.z.setScaleX(paramFloat);
    this.z.setScaleY(paramFloat);
  }
  
  @Deprecated
  public void setColorScheme(int... paramVarArgs) {
    setColorSchemeResources(paramVarArgs);
  }
  
  public void setColorSchemeColors(int... paramVarArgs) {
    b();
    c1.d d1 = this.F;
    c1.d.a a1 = d1.h;
    a1.i = paramVarArgs;
    a1.a(0);
    d1.h.a(0);
    d1.invalidateSelf();
  }
  
  public void setColorSchemeResources(int... paramVarArgs) {
    Context context = getContext();
    int[] arrayOfInt = new int[paramVarArgs.length];
    for (int j = 0; j < paramVarArgs.length; j++)
      arrayOfInt[j] = b0.a.b(context, paramVarArgs[j]); 
    setColorSchemeColors(arrayOfInt);
  }
  
  public void setDistanceToTriggerSync(int paramInt) {
    this.l = paramInt;
  }
  
  public void setEnabled(boolean paramBoolean) {
    super.setEnabled(paramBoolean);
    if (!paramBoolean)
      h(); 
  }
  
  public void setNestedScrollingEnabled(boolean paramBoolean) {
    k0.f f1 = this.o;
    if (f1.d) {
      View view = f1.c;
      WeakHashMap weakHashMap = l.a;
      view.stopNestedScroll();
    } 
    f1.d = paramBoolean;
  }
  
  public void setOnChildScrollUpCallback(g paramg) {
    this.M = paramg;
  }
  
  public void setOnRefreshListener(h paramh) {
    this.i = paramh;
  }
  
  @Deprecated
  public void setProgressBackgroundColor(int paramInt) {
    setProgressBackgroundColorSchemeResource(paramInt);
  }
  
  public void setProgressBackgroundColorSchemeColor(int paramInt) {
    this.z.setBackgroundColor(paramInt);
  }
  
  public void setProgressBackgroundColorSchemeResource(int paramInt) {
    setProgressBackgroundColorSchemeColor(b0.a.b(getContext(), paramInt));
  }
  
  public void setRefreshing(boolean paramBoolean) {
    if (paramBoolean && this.j != paramBoolean) {
      this.j = paramBoolean;
      setTargetOffsetTopAndBottom(this.D + this.C - this.t);
      this.K = false;
      Animation.AnimationListener animationListener = this.N;
      this.z.setVisibility(0);
      this.F.setAlpha(255);
      c1.e e1 = new c1.e(this);
      this.G = (Animation)e1;
      e1.setDuration(this.s);
      if (animationListener != null)
        this.z.h = animationListener; 
      this.z.clearAnimation();
      this.z.startAnimation(this.G);
      return;
    } 
    i(paramBoolean, false);
  }
  
  public void setSize(int paramInt) {
    float f1;
    if (paramInt != 0 && paramInt != 1)
      return; 
    DisplayMetrics displayMetrics = getResources().getDisplayMetrics();
    if (paramInt == 0) {
      f1 = 56.0F;
    } else {
      f1 = 40.0F;
    } 
    this.L = (int)(displayMetrics.density * f1);
    this.z.setImageDrawable(null);
    this.F.c(paramInt);
    this.z.setImageDrawable((Drawable)this.F);
  }
  
  public void setSlingshotDistance(int paramInt) {
    this.E = paramInt;
  }
  
  public void setTargetOffsetTopAndBottom(int paramInt) {
    this.z.bringToFront();
    l.n((View)this.z, paramInt);
    this.t = this.z.getTop();
  }
  
  public boolean startNestedScroll(int paramInt) {
    return this.o.i(paramInt, 0);
  }
  
  public void stopNestedScroll() {
    this.o.j(0);
  }
  
  public class a implements Animation.AnimationListener {
    public a(SwipeRefreshLayout this$0) {}
    
    public void onAnimationEnd(Animation param1Animation) {
      SwipeRefreshLayout swipeRefreshLayout = this.a;
      if (swipeRefreshLayout.j) {
        swipeRefreshLayout.F.setAlpha(255);
        this.a.F.start();
        swipeRefreshLayout = this.a;
        if (swipeRefreshLayout.K) {
          SwipeRefreshLayout.h h = swipeRefreshLayout.i;
          if (h != null) {
            FrameActivity frameActivity = ((d0)h).a;
            frameActivity.t(frameActivity.B);
            frameActivity.x.setRefreshing(false);
          } 
        } 
        swipeRefreshLayout = this.a;
        swipeRefreshLayout.t = swipeRefreshLayout.z.getTop();
        return;
      } 
      swipeRefreshLayout.h();
    }
    
    public void onAnimationRepeat(Animation param1Animation) {}
    
    public void onAnimationStart(Animation param1Animation) {}
  }
  
  public class b extends Animation {
    public b(SwipeRefreshLayout this$0) {}
    
    public void applyTransformation(float param1Float, Transformation param1Transformation) {
      this.h.setAnimationProgress(1.0F - param1Float);
    }
  }
  
  public class c extends Animation {
    public c(SwipeRefreshLayout this$0, int param1Int1, int param1Int2) {}
    
    public void applyTransformation(float param1Float, Transformation param1Transformation) {
      c1.d d = this.j.F;
      int i = this.h;
      float f = i;
      d.setAlpha((int)((this.i - i) * param1Float + f));
    }
  }
  
  public class d implements Animation.AnimationListener {
    public d(SwipeRefreshLayout this$0) {}
    
    public void onAnimationEnd(Animation param1Animation) {
      Objects.requireNonNull(this.a);
      this.a.l(null);
    }
    
    public void onAnimationRepeat(Animation param1Animation) {}
    
    public void onAnimationStart(Animation param1Animation) {}
  }
  
  public class e extends Animation {
    public e(SwipeRefreshLayout this$0) {}
    
    public void applyTransformation(float param1Float, Transformation param1Transformation) {
      Objects.requireNonNull(this.h);
      SwipeRefreshLayout swipeRefreshLayout = this.h;
      int j = swipeRefreshLayout.D;
      int k = Math.abs(swipeRefreshLayout.C);
      swipeRefreshLayout = this.h;
      int i = swipeRefreshLayout.B;
      j = (int)((j - k - i) * param1Float);
      k = swipeRefreshLayout.z.getTop();
      this.h.setTargetOffsetTopAndBottom(i + j - k);
      c1.d d = this.h.F;
      param1Float = 1.0F - param1Float;
      c1.d.a a = d.h;
      if (param1Float != a.p)
        a.p = param1Float; 
      d.invalidateSelf();
    }
  }
  
  public class f extends Animation {
    public f(SwipeRefreshLayout this$0) {}
    
    public void applyTransformation(float param1Float, Transformation param1Transformation) {
      this.h.f(param1Float);
    }
  }
  
  public static interface g {
    boolean a(SwipeRefreshLayout param1SwipeRefreshLayout, View param1View);
  }
  
  public static interface h {}
}


/* Location:              C:\soft\dex2jar-2.0\Luxury Logo Maker_ Logo Design-dex2jar.jar!\androidx\swiperefreshlayout\widget\SwipeRefreshLayout.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */