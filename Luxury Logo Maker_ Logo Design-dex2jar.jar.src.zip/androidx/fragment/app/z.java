package androidx.fragment.app;

import d0.c;
import r.g;

public class z {
  public static final g<ClassLoader, g<String, Class<?>>> a = new g();
  
  public static Class<?> b(ClassLoader paramClassLoader, String paramString) {
    g<ClassLoader, g<String, Class<?>>> g3 = a;
    g g2 = (g)g3.getOrDefault(paramClassLoader, null);
    g g1 = g2;
    if (g2 == null) {
      g1 = new g();
      g3.put(paramClassLoader, g1);
    } 
    Class<?> clazz2 = (Class)g1.getOrDefault(paramString, null);
    Class<?> clazz1 = clazz2;
    if (clazz2 == null) {
      clazz1 = Class.forName(paramString, false, paramClassLoader);
      g1.put(paramString, clazz1);
    } 
    return clazz1;
  }
  
  public static Class<? extends o> c(ClassLoader paramClassLoader, String paramString) {
    try {
      return (Class)b(paramClassLoader, paramString);
    } catch (ClassNotFoundException classNotFoundException) {
      throw new o.c(c.a("Unable to instantiate fragment ", paramString, ": make sure class name exists"), classNotFoundException);
    } catch (ClassCastException classCastException) {
      throw new o.c(c.a("Unable to instantiate fragment ", paramString, ": make sure class is a valid subclass of Fragment"), classCastException);
    } 
  }
  
  public o a(ClassLoader paramClassLoader, String paramString) {
    throw null;
  }
}


/* Location:              C:\soft\dex2jar-2.0\Luxury Logo Maker_ Logo Design-dex2jar.jar!\androidx\fragment\app\z.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */