package androidx.fragment.app;

import android.content.Context;
import android.os.Bundle;
import android.view.View;
import java.util.Iterator;
import java.util.Objects;
import java.util.concurrent.CopyOnWriteArrayList;

public class c0 {
  public final CopyOnWriteArrayList<a> a = new CopyOnWriteArrayList<a>();
  
  public final d0 b;
  
  public c0(d0 paramd0) {
    this.b = paramd0;
  }
  
  public void a(o paramo, Bundle paramBundle, boolean paramBoolean) {
    o o1 = this.b.s;
    if (o1 != null)
      (o1.r()).n.a(paramo, paramBundle, true); 
    Iterator<a> iterator = this.a.iterator();
    while (iterator.hasNext()) {
      Objects.requireNonNull(iterator.next());
      if (paramBoolean)
        continue; 
      throw null;
    } 
  }
  
  public void b(o paramo, boolean paramBoolean) {
    d0 d01 = this.b;
    Context context = d01.q.i;
    o o1 = d01.s;
    if (o1 != null)
      (o1.r()).n.b(paramo, true); 
    Iterator<a> iterator = this.a.iterator();
    while (iterator.hasNext()) {
      Objects.requireNonNull(iterator.next());
      if (paramBoolean)
        continue; 
      throw null;
    } 
  }
  
  public void c(o paramo, Bundle paramBundle, boolean paramBoolean) {
    o o1 = this.b.s;
    if (o1 != null)
      (o1.r()).n.c(paramo, paramBundle, true); 
    Iterator<a> iterator = this.a.iterator();
    while (iterator.hasNext()) {
      Objects.requireNonNull(iterator.next());
      if (paramBoolean)
        continue; 
      throw null;
    } 
  }
  
  public void d(o paramo, boolean paramBoolean) {
    o o1 = this.b.s;
    if (o1 != null)
      (o1.r()).n.d(paramo, true); 
    Iterator<a> iterator = this.a.iterator();
    while (iterator.hasNext()) {
      Objects.requireNonNull(iterator.next());
      if (paramBoolean)
        continue; 
      throw null;
    } 
  }
  
  public void e(o paramo, boolean paramBoolean) {
    o o1 = this.b.s;
    if (o1 != null)
      (o1.r()).n.e(paramo, true); 
    Iterator<a> iterator = this.a.iterator();
    while (iterator.hasNext()) {
      Objects.requireNonNull(iterator.next());
      if (paramBoolean)
        continue; 
      throw null;
    } 
  }
  
  public void f(o paramo, boolean paramBoolean) {
    o o1 = this.b.s;
    if (o1 != null)
      (o1.r()).n.f(paramo, true); 
    Iterator<a> iterator = this.a.iterator();
    while (iterator.hasNext()) {
      Objects.requireNonNull(iterator.next());
      if (paramBoolean)
        continue; 
      throw null;
    } 
  }
  
  public void g(o paramo, boolean paramBoolean) {
    d0 d01 = this.b;
    Context context = d01.q.i;
    o o1 = d01.s;
    if (o1 != null)
      (o1.r()).n.g(paramo, true); 
    Iterator<a> iterator = this.a.iterator();
    while (iterator.hasNext()) {
      Objects.requireNonNull(iterator.next());
      if (paramBoolean)
        continue; 
      throw null;
    } 
  }
  
  public void h(o paramo, Bundle paramBundle, boolean paramBoolean) {
    o o1 = this.b.s;
    if (o1 != null)
      (o1.r()).n.h(paramo, paramBundle, true); 
    Iterator<a> iterator = this.a.iterator();
    while (iterator.hasNext()) {
      Objects.requireNonNull(iterator.next());
      if (paramBoolean)
        continue; 
      throw null;
    } 
  }
  
  public void i(o paramo, boolean paramBoolean) {
    o o1 = this.b.s;
    if (o1 != null)
      (o1.r()).n.i(paramo, true); 
    Iterator<a> iterator = this.a.iterator();
    while (iterator.hasNext()) {
      Objects.requireNonNull(iterator.next());
      if (paramBoolean)
        continue; 
      throw null;
    } 
  }
  
  public void j(o paramo, Bundle paramBundle, boolean paramBoolean) {
    o o1 = this.b.s;
    if (o1 != null)
      (o1.r()).n.j(paramo, paramBundle, true); 
    Iterator<a> iterator = this.a.iterator();
    while (iterator.hasNext()) {
      Objects.requireNonNull(iterator.next());
      if (paramBoolean)
        continue; 
      throw null;
    } 
  }
  
  public void k(o paramo, boolean paramBoolean) {
    o o1 = this.b.s;
    if (o1 != null)
      (o1.r()).n.k(paramo, true); 
    Iterator<a> iterator = this.a.iterator();
    while (iterator.hasNext()) {
      Objects.requireNonNull(iterator.next());
      if (paramBoolean)
        continue; 
      throw null;
    } 
  }
  
  public void l(o paramo, boolean paramBoolean) {
    o o1 = this.b.s;
    if (o1 != null)
      (o1.r()).n.l(paramo, true); 
    Iterator<a> iterator = this.a.iterator();
    while (iterator.hasNext()) {
      Objects.requireNonNull(iterator.next());
      if (paramBoolean)
        continue; 
      throw null;
    } 
  }
  
  public void m(o paramo, View paramView, Bundle paramBundle, boolean paramBoolean) {
    o o1 = this.b.s;
    if (o1 != null)
      (o1.r()).n.m(paramo, paramView, paramBundle, true); 
    Iterator<a> iterator = this.a.iterator();
    while (iterator.hasNext()) {
      Objects.requireNonNull(iterator.next());
      if (paramBoolean)
        continue; 
      throw null;
    } 
  }
  
  public void n(o paramo, boolean paramBoolean) {
    o o1 = this.b.s;
    if (o1 != null)
      (o1.r()).n.n(paramo, true); 
    Iterator<a> iterator = this.a.iterator();
    while (iterator.hasNext()) {
      Objects.requireNonNull(iterator.next());
      if (paramBoolean)
        continue; 
      throw null;
    } 
  }
  
  public static final class a {}
}


/* Location:              C:\soft\dex2jar-2.0\Luxury Logo Maker_ Logo Design-dex2jar.jar!\androidx\fragment\app\c0.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */