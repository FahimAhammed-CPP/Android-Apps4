package androidx.fragment.app;

import android.annotation.SuppressLint;
import android.os.Bundle;
import android.os.Parcel;
import android.os.Parcelable;
import java.util.ArrayList;

@SuppressLint({"BanParcelableUsage"})
public final class f0 implements Parcelable {
  public static final Parcelable.Creator<f0> CREATOR = new a();
  
  public ArrayList<i0> h;
  
  public ArrayList<String> i;
  
  public c[] j;
  
  public int k;
  
  public String l = null;
  
  public ArrayList<String> m = new ArrayList<String>();
  
  public ArrayList<Bundle> n = new ArrayList<Bundle>();
  
  public ArrayList<d0.k> o;
  
  public f0() {}
  
  public f0(Parcel paramParcel) {
    this.h = paramParcel.createTypedArrayList(i0.CREATOR);
    this.i = paramParcel.createStringArrayList();
    this.j = (c[])paramParcel.createTypedArray(c.CREATOR);
    this.k = paramParcel.readInt();
    this.l = paramParcel.readString();
    this.m = paramParcel.createStringArrayList();
    this.n = paramParcel.createTypedArrayList(Bundle.CREATOR);
    this.o = paramParcel.createTypedArrayList(d0.k.CREATOR);
  }
  
  public int describeContents() {
    return 0;
  }
  
  public void writeToParcel(Parcel paramParcel, int paramInt) {
    paramParcel.writeTypedList(this.h);
    paramParcel.writeStringList(this.i);
    paramParcel.writeTypedArray((Parcelable[])this.j, paramInt);
    paramParcel.writeInt(this.k);
    paramParcel.writeString(this.l);
    paramParcel.writeStringList(this.m);
    paramParcel.writeTypedList(this.n);
    paramParcel.writeTypedList(this.o);
  }
  
  public class a implements Parcelable.Creator<f0> {
    public Object createFromParcel(Parcel param1Parcel) {
      return new f0(param1Parcel);
    }
    
    public Object[] newArray(int param1Int) {
      return (Object[])new f0[param1Int];
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Luxury Logo Maker_ Logo Design-dex2jar.jar!\androidx\fragment\app\f0.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */