package androidx.fragment.app;

import android.graphics.Rect;
import android.view.View;
import r.a;

public class q0 implements Runnable {
  public q0(o paramo1, o paramo2, boolean paramBoolean, a parama, View paramView, u0 paramu0, Rect paramRect) {}
  
  public void run() {
    s0.c(this.h, this.i, this.j, this.k, false);
    View view = this.l;
    if (view != null)
      this.m.j(view, this.n); 
  }
}


/* Location:              C:\soft\dex2jar-2.0\Luxury Logo Maker_ Logo Design-dex2jar.jar!\androidx\fragment\app\q0.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */