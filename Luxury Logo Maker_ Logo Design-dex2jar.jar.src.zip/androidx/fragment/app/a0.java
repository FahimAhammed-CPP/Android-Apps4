package androidx.fragment.app;

import android.app.Activity;
import android.content.Context;
import android.os.Handler;
import android.view.LayoutInflater;
import w.d;

public abstract class a0<E> extends w {
  public final Activity h;
  
  public final Context i;
  
  public final Handler j;
  
  public final d0 k = new e0();
  
  public a0(r paramr) {
    this.h = (Activity)paramr;
    d.c(paramr, "context == null");
    this.i = (Context)paramr;
    this.j = handler;
  }
  
  public abstract E g();
  
  public abstract LayoutInflater i();
  
  public abstract boolean k(o paramo);
  
  public abstract void l();
}


/* Location:              C:\soft\dex2jar-2.0\Luxury Logo Maker_ Logo Design-dex2jar.jar!\androidx\fragment\app\a0.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */