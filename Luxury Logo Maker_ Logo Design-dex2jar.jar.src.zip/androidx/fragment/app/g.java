package androidx.fragment.app;

import android.view.View;
import android.view.ViewGroup;
import android.view.animation.Animation;

public class g implements Animation.AnimationListener {
  public g(d paramd, ViewGroup paramViewGroup, View paramView, d.b paramb) {}
  
  public void onAnimationEnd(Animation paramAnimation) {
    this.a.post(new a(this));
  }
  
  public void onAnimationRepeat(Animation paramAnimation) {}
  
  public void onAnimationStart(Animation paramAnimation) {}
  
  public class a implements Runnable {
    public a(g this$0) {}
    
    public void run() {
      g g1 = this.h;
      g1.a.endViewTransition(g1.b);
      this.h.c.a();
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Luxury Logo Maker_ Logo Design-dex2jar.jar!\androidx\fragment\app\g.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */