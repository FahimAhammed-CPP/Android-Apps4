package androidx.fragment.app;

import android.util.Log;
import androidx.lifecycle.v;
import androidx.lifecycle.w;
import androidx.lifecycle.z;
import java.util.HashMap;
import java.util.Iterator;

public final class g0 extends v {
  public static final w h = new a();
  
  public final HashMap<String, o> b = new HashMap<String, o>();
  
  public final HashMap<String, g0> c = new HashMap<String, g0>();
  
  public final HashMap<String, z> d = new HashMap<String, z>();
  
  public final boolean e;
  
  public boolean f = false;
  
  public boolean g = false;
  
  public g0(boolean paramBoolean) {
    this.e = paramBoolean;
  }
  
  public void a() {
    if (d0.O(3)) {
      StringBuilder stringBuilder = new StringBuilder();
      stringBuilder.append("onCleared called for ");
      stringBuilder.append(this);
      Log.d("FragmentManager", stringBuilder.toString());
    } 
    this.f = true;
  }
  
  public void b(o paramo) {
    boolean bool;
    if (this.g) {
      if (d0.O(2))
        Log.v("FragmentManager", "Ignoring removeRetainedFragment as the state is already saved"); 
      return;
    } 
    if (this.b.remove(paramo.l) != null) {
      bool = true;
    } else {
      bool = false;
    } 
    if (bool && d0.O(2)) {
      StringBuilder stringBuilder = new StringBuilder();
      stringBuilder.append("Updating retained Fragments: Removed ");
      stringBuilder.append(paramo);
      Log.v("FragmentManager", stringBuilder.toString());
    } 
  }
  
  public boolean c(o paramo) {
    return !this.b.containsKey(paramo.l) ? true : (this.e ? this.f : true);
  }
  
  public boolean equals(Object paramObject) {
    if (this == paramObject)
      return true; 
    if (paramObject != null) {
      if (g0.class != paramObject.getClass())
        return false; 
      paramObject = paramObject;
      return (this.b.equals(((g0)paramObject).b) && this.c.equals(((g0)paramObject).c) && this.d.equals(((g0)paramObject).d));
    } 
    return false;
  }
  
  public int hashCode() {
    int i = this.b.hashCode();
    int j = this.c.hashCode();
    return this.d.hashCode() + (j + i * 31) * 31;
  }
  
  public String toString() {
    StringBuilder stringBuilder = new StringBuilder("FragmentManagerViewModel{");
    stringBuilder.append(Integer.toHexString(System.identityHashCode(this)));
    stringBuilder.append("} Fragments (");
    Iterator<String> iterator = this.b.values().iterator();
    while (iterator.hasNext()) {
      stringBuilder.append(iterator.next());
      if (iterator.hasNext())
        stringBuilder.append(", "); 
    } 
    stringBuilder.append(") Child Non Config (");
    iterator = this.c.keySet().iterator();
    while (iterator.hasNext()) {
      stringBuilder.append(iterator.next());
      if (iterator.hasNext())
        stringBuilder.append(", "); 
    } 
    stringBuilder.append(") ViewModelStores (");
    iterator = this.d.keySet().iterator();
    while (iterator.hasNext()) {
      stringBuilder.append(iterator.next());
      if (iterator.hasNext())
        stringBuilder.append(", "); 
    } 
    stringBuilder.append(')');
    return stringBuilder.toString();
  }
  
  public class a implements w {
    public <T extends v> T a(Class<T> param1Class) {
      return (T)new g0(true);
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Luxury Logo Maker_ Logo Design-dex2jar.jar!\androidx\fragment\app\g0.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */