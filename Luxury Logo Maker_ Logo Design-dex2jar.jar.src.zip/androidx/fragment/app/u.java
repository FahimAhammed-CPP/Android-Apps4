package androidx.fragment.app;

import android.animation.Animator;
import android.animation.AnimatorListenerAdapter;
import android.view.View;
import android.view.ViewGroup;
import g0.b;

public class u extends AnimatorListenerAdapter {
  public u(ViewGroup paramViewGroup, View paramView, o paramo, s0.a parama, b paramb) {}
  
  public void onAnimationEnd(Animator paramAnimator) {
    Animator animator;
    this.a.endViewTransition(this.b);
    o o1 = this.c;
    o.b b1 = o1.O;
    if (b1 == null) {
      b1 = null;
    } else {
      animator = b1.b;
    } 
    o1.b0(null);
    if (animator != null && this.a.indexOfChild(this.b) < 0) {
      s0.a a1 = this.d;
      o1 = this.c;
      b b2 = this.e;
      ((d0.d)a1).a(o1, b2);
    } 
  }
}


/* Location:              C:\soft\dex2jar-2.0\Luxury Logo Maker_ Logo Design-dex2jar.jar!\androidx\fragment\ap\\u.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */