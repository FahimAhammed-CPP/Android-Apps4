package androidx.fragment.app;

import android.util.Log;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;

public class k0 {
  public final ArrayList<o> a = new ArrayList<o>();
  
  public final HashMap<String, j0> b = new HashMap<String, j0>();
  
  public g0 c;
  
  public void a(o paramo) {
    if (!this.a.contains(paramo))
      synchronized (this.a) {
        this.a.add(paramo);
        paramo.r = true;
        return;
      }  
    StringBuilder stringBuilder = new StringBuilder();
    stringBuilder.append("Fragment already added: ");
    stringBuilder.append(paramo);
    throw new IllegalStateException(stringBuilder.toString());
  }
  
  public void b() {
    this.b.values().removeAll(Collections.singleton(null));
  }
  
  public boolean c(String paramString) {
    return (this.b.get(paramString) != null);
  }
  
  public o d(String paramString) {
    j0 j0 = this.b.get(paramString);
    return (j0 != null) ? j0.c : null;
  }
  
  public o e(String paramString) {
    for (j0 j0 : this.b.values()) {
      if (j0 != null) {
        o o = j0.c;
        if (!paramString.equals(o.l))
          o = o.A.c.e(paramString); 
        if (o != null)
          return o; 
      } 
    } 
    return null;
  }
  
  public List<j0> f() {
    ArrayList<j0> arrayList = new ArrayList();
    for (j0 j0 : this.b.values()) {
      if (j0 != null)
        arrayList.add(j0); 
    } 
    return arrayList;
  }
  
  public List<o> g() {
    ArrayList<j0> arrayList = new ArrayList();
    for (j0 j0 : this.b.values()) {
      if (j0 != null) {
        o o = j0.c;
      } else {
        j0 = null;
      } 
      arrayList.add(j0);
    } 
    return (List)arrayList;
  }
  
  public j0 h(String paramString) {
    return this.b.get(paramString);
  }
  
  public List<o> i() {
    if (this.a.isEmpty())
      return Collections.emptyList(); 
    synchronized (this.a) {
      return new ArrayList<o>(this.a);
    } 
  }
  
  public void j(j0 paramj0) {
    o o = paramj0.c;
    if (c(o.l))
      return; 
    this.b.put(o.l, paramj0);
    if (d0.O(2)) {
      StringBuilder stringBuilder = new StringBuilder();
      stringBuilder.append("Added fragment to active set ");
      stringBuilder.append(o);
      Log.v("FragmentManager", stringBuilder.toString());
    } 
  }
  
  public void k(j0 paramj0) {
    o o = paramj0.c;
    if (o.H)
      this.c.b(o); 
    if ((j0)this.b.put(o.l, null) == null)
      return; 
    if (d0.O(2)) {
      StringBuilder stringBuilder = new StringBuilder();
      stringBuilder.append("Removed fragment from active set ");
      stringBuilder.append(o);
      Log.v("FragmentManager", stringBuilder.toString());
    } 
  }
  
  public void l(o paramo) {
    synchronized (this.a) {
      this.a.remove(paramo);
      paramo.r = false;
      return;
    } 
  }
}


/* Location:              C:\soft\dex2jar-2.0\Luxury Logo Maker_ Logo Design-dex2jar.jar!\androidx\fragment\app\k0.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */