package androidx.fragment.app;

import android.os.Bundle;
import android.os.Parcelable;
import androidx.lifecycle.e;
import androidx.savedstate.a;

public class p implements a.b {
  public p(r paramr) {}
  
  public Bundle a() {
    Bundle bundle = new Bundle();
    r r1 = this.a;
    do {
    
    } while (r.o(r1.n(), e.c.j));
    this.a.p.d(e.b.ON_STOP);
    Parcelable parcelable = this.a.o.a.k.b0();
    if (parcelable != null)
      bundle.putParcelable("android:support:fragments", parcelable); 
    return bundle;
  }
}


/* Location:              C:\soft\dex2jar-2.0\Luxury Logo Maker_ Logo Design-dex2jar.jar!\androidx\fragment\app\p.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */