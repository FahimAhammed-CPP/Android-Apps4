package androidx.fragment.app;

import g0.b;

public class o0 implements Runnable {
  public o0(s0.a parama, o paramo, b paramb) {}
  
  public void run() {
    s0.a a1 = this.h;
    o o1 = this.i;
    b b1 = this.j;
    ((d0.d)a1).a(o1, b1);
  }
}


/* Location:              C:\soft\dex2jar-2.0\Luxury Logo Maker_ Logo Design-dex2jar.jar!\androidx\fragment\app\o0.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */