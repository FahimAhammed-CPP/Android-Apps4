package androidx.fragment.app;

import android.view.View;
import java.util.ArrayList;
import java.util.Map;
import java.util.WeakHashMap;
import k0.l;

public class w0 implements Runnable {
  public w0(u0 paramu0, ArrayList paramArrayList, Map paramMap) {}
  
  public void run() {
    int j = this.h.size();
    for (int i = 0; i < j; i++) {
      View view = this.h.get(i);
      WeakHashMap weakHashMap = l.a;
      String str = view.getTransitionName();
      view.setTransitionName((String)this.i.get(str));
    } 
  }
}


/* Location:              C:\soft\dex2jar-2.0\Luxury Logo Maker_ Logo Design-dex2jar.jar!\androidx\fragment\app\w0.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */