package androidx.fragment.app;

public class a1 implements Runnable {
  public a1(b1 paramb1, b1.a parama) {}
  
  public void run() {
    this.i.b.remove(this.h);
    this.i.c.remove(this.h);
  }
}


/* Location:              C:\soft\dex2jar-2.0\Luxury Logo Maker_ Logo Design-dex2jar.jar!\androidx\fragment\app\a1.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */