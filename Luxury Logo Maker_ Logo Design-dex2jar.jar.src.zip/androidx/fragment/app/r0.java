package androidx.fragment.app;

import android.graphics.Rect;
import android.view.View;
import java.util.ArrayList;
import r.a;

public class r0 implements Runnable {
  public r0(u0 paramu0, a parama, Object paramObject1, s0.b paramb, ArrayList paramArrayList1, View paramView, o paramo1, o paramo2, boolean paramBoolean, ArrayList paramArrayList2, Object paramObject2, Rect paramRect) {}
  
  public void run() {
    a<String, View> a1 = s0.e(this.h, this.i, this.j, this.k);
    if (a1 != null) {
      this.l.addAll(a1.values());
      this.l.add(this.m);
    } 
    s0.c(this.n, this.o, this.p, a1, false);
    Object object = this.j;
    if (object != null) {
      this.h.x(object, this.q, this.l);
      View view = s0.k(a1, this.k, this.r, this.p);
      if (view != null)
        this.h.j(view, this.s); 
    } 
  }
}


/* Location:              C:\soft\dex2jar-2.0\Luxury Logo Maker_ Logo Design-dex2jar.jar!\androidx\fragment\app\r0.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */