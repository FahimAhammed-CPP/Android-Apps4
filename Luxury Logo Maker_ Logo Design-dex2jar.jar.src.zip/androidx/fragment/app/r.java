package androidx.fragment.app;

import a0.a;
import android.annotation.SuppressLint;
import android.content.Context;
import android.content.Intent;
import android.content.res.Configuration;
import android.os.Bundle;
import android.util.AttributeSet;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.Window;
import androidx.activity.ComponentActivity;
import androidx.activity.OnBackPressedDispatcher;
import androidx.activity.c;
import androidx.activity.result.e;
import androidx.activity.result.f;
import androidx.lifecycle.a0;
import androidx.lifecycle.e;
import androidx.lifecycle.i;
import androidx.lifecycle.j;
import androidx.lifecycle.z;
import java.io.FileDescriptor;
import java.io.PrintWriter;
import java.util.Iterator;
import java.util.Objects;

public class r extends ComponentActivity implements a.b, a.c {
  public final y o = new y(new a(this));
  
  public final j p = new j((i)this);
  
  public boolean q;
  
  public boolean r;
  
  public boolean s = true;
  
  public r() {
    this.k.b.b("android:support:fragments", new p(this));
    q q = new q(this);
    c.a a = this.i;
    if (a.b != null)
      q.a(a.b); 
    a.a.add(q);
  }
  
  public static boolean o(d0 paramd0, e.c paramc) {
    e.c c1 = e.c.k;
    Iterator<o> iterator = paramd0.L().iterator();
    boolean bool = false;
    while (iterator.hasNext()) {
      boolean bool1;
      o o = iterator.next();
      if (o == null)
        continue; 
      a0<?> a0 = o.z;
      if (a0 == null) {
        a0 = null;
      } else {
        a0 = (a0<?>)a0.g();
      } 
      boolean bool2 = bool;
      if (a0 != null)
        bool2 = bool | o(o.h(), paramc); 
      x0 x0 = o.U;
      bool = bool2;
      if (x0 != null) {
        x0.e();
        if (x0.i.b.compareTo(c1) >= 0) {
          bool1 = true;
        } else {
          bool1 = false;
        } 
        bool = bool2;
        if (bool1) {
          j j1 = o.U.i;
          j1.c("setCurrentState");
          j1.f(paramc);
          bool = true;
        } 
      } 
      if (o.T.b.compareTo(c1) >= 0) {
        bool1 = true;
      } else {
        bool1 = false;
      } 
      if (bool1) {
        j j1 = o.T;
        j1.c("setCurrentState");
        j1.f(paramc);
        bool = true;
      } 
    } 
    return bool;
  }
  
  @Deprecated
  public final void b(int paramInt) {}
  
  public void dump(String paramString, FileDescriptor paramFileDescriptor, PrintWriter paramPrintWriter, String[] paramArrayOfString) {
    super.dump(paramString, paramFileDescriptor, paramPrintWriter, paramArrayOfString);
    paramPrintWriter.print(paramString);
    paramPrintWriter.print("Local FragmentActivity ");
    paramPrintWriter.print(Integer.toHexString(System.identityHashCode(this)));
    paramPrintWriter.println(" State:");
    StringBuilder stringBuilder = new StringBuilder();
    stringBuilder.append(paramString);
    stringBuilder.append("  ");
    String str = stringBuilder.toString();
    paramPrintWriter.print(str);
    paramPrintWriter.print("mCreated=");
    paramPrintWriter.print(this.q);
    paramPrintWriter.print(" mResumed=");
    paramPrintWriter.print(this.r);
    paramPrintWriter.print(" mStopped=");
    paramPrintWriter.print(this.s);
    if (getApplication() != null)
      t0.a.b((i)this).a(str, paramFileDescriptor, paramPrintWriter, paramArrayOfString); 
    this.o.a.k.y(paramString, paramFileDescriptor, paramPrintWriter, paramArrayOfString);
  }
  
  public d0 n() {
    return this.o.a.k;
  }
  
  public void onActivityResult(int paramInt1, int paramInt2, Intent paramIntent) {
    this.o.a();
    super.onActivityResult(paramInt1, paramInt2, paramIntent);
  }
  
  public void onConfigurationChanged(Configuration paramConfiguration) {
    this.o.a();
    super.onConfigurationChanged(paramConfiguration);
    this.o.a.k.k(paramConfiguration);
  }
  
  public void onCreate(Bundle paramBundle) {
    super.onCreate(paramBundle);
    this.p.d(e.b.ON_CREATE);
    this.o.a.k.m();
  }
  
  public boolean onCreatePanelMenu(int paramInt, Menu paramMenu) {
    if (paramInt == 0) {
      boolean bool = super.onCreatePanelMenu(paramInt, paramMenu);
      y y1 = this.o;
      MenuInflater menuInflater = getMenuInflater();
      return bool | y1.a.k.n(paramMenu, menuInflater);
    } 
    return super.onCreatePanelMenu(paramInt, paramMenu);
  }
  
  public View onCreateView(View paramView, String paramString, Context paramContext, AttributeSet paramAttributeSet) {
    View view = this.o.a.k.f.onCreateView(paramView, paramString, paramContext, paramAttributeSet);
    return (view == null) ? super.onCreateView(paramView, paramString, paramContext, paramAttributeSet) : view;
  }
  
  public View onCreateView(String paramString, Context paramContext, AttributeSet paramAttributeSet) {
    View view = this.o.a.k.f.onCreateView(null, paramString, paramContext, paramAttributeSet);
    return (view == null) ? super.onCreateView(paramString, paramContext, paramAttributeSet) : view;
  }
  
  public void onDestroy() {
    super.onDestroy();
    this.o.a.k.o();
    this.p.d(e.b.ON_DESTROY);
  }
  
  public void onLowMemory() {
    super.onLowMemory();
    this.o.a.k.p();
  }
  
  public boolean onMenuItemSelected(int paramInt, MenuItem paramMenuItem) {
    return super.onMenuItemSelected(paramInt, paramMenuItem) ? true : ((paramInt != 0) ? ((paramInt != 6) ? false : this.o.a.k.l(paramMenuItem)) : this.o.a.k.r(paramMenuItem));
  }
  
  public void onMultiWindowModeChanged(boolean paramBoolean) {
    this.o.a.k.q(paramBoolean);
  }
  
  public void onNewIntent(@SuppressLint({"UnknownNullness"}) Intent paramIntent) {
    this.o.a();
    super.onNewIntent(paramIntent);
  }
  
  public void onPanelClosed(int paramInt, Menu paramMenu) {
    if (paramInt == 0)
      this.o.a.k.s(paramMenu); 
    super.onPanelClosed(paramInt, paramMenu);
  }
  
  public void onPause() {
    super.onPause();
    this.r = false;
    this.o.a.k.w(5);
    this.p.d(e.b.ON_PAUSE);
  }
  
  public void onPictureInPictureModeChanged(boolean paramBoolean) {
    this.o.a.k.u(paramBoolean);
  }
  
  public void onPostResume() {
    super.onPostResume();
    this.p.d(e.b.ON_RESUME);
    d0 d0 = this.o.a.k;
    d0.B = false;
    d0.C = false;
    d0.J.g = false;
    d0.w(7);
  }
  
  public boolean onPreparePanel(int paramInt, View paramView, Menu paramMenu) {
    return (paramInt == 0) ? (super.onPreparePanel(0, paramView, paramMenu) | this.o.a.k.v(paramMenu)) : super.onPreparePanel(paramInt, paramView, paramMenu);
  }
  
  public void onRequestPermissionsResult(int paramInt, String[] paramArrayOfString, int[] paramArrayOfint) {
    this.o.a();
    super.onRequestPermissionsResult(paramInt, paramArrayOfString, paramArrayOfint);
  }
  
  public void onResume() {
    this.o.a();
    super.onResume();
    this.r = true;
    this.o.a.k.C(true);
  }
  
  public void onStart() {
    this.o.a();
    super.onStart();
    this.s = false;
    if (!this.q) {
      this.q = true;
      d0 d01 = this.o.a.k;
      d01.B = false;
      d01.C = false;
      d01.J.g = false;
      d01.w(4);
    } 
    this.o.a.k.C(true);
    this.p.d(e.b.ON_START);
    d0 d0 = this.o.a.k;
    d0.B = false;
    d0.C = false;
    d0.J.g = false;
    d0.w(5);
  }
  
  public void onStateNotSaved() {
    this.o.a();
  }
  
  public void onStop() {
    super.onStop();
    this.s = true;
    do {
    
    } while (o(n(), e.c.j));
    d0 d0 = this.o.a.k;
    d0.C = true;
    d0.J.g = true;
    d0.w(4);
    this.p.d(e.b.ON_STOP);
  }
  
  @Deprecated
  public void p() {
    invalidateOptionsMenu();
  }
  
  public class a extends a0<r> implements a0, c, f, h0 {
    public a(r this$0) {
      super(this$0);
    }
    
    public e a() {
      return (e)this.l.p;
    }
    
    public void b(d0 param1d0, o param1o) {
      Objects.requireNonNull(this.l);
    }
    
    public OnBackPressedDispatcher c() {
      return this.l.m;
    }
    
    public View e(int param1Int) {
      return this.l.findViewById(param1Int);
    }
    
    public boolean f() {
      Window window = this.l.getWindow();
      return (window != null && window.peekDecorView() != null);
    }
    
    public Object g() {
      return this.l;
    }
    
    public e h() {
      return this.l.n;
    }
    
    public LayoutInflater i() {
      return this.l.getLayoutInflater().cloneInContext((Context)this.l);
    }
    
    public z j() {
      return this.l.j();
    }
    
    public boolean k(o param1o) {
      return this.l.isFinishing() ^ true;
    }
    
    public void l() {
      this.l.p();
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Luxury Logo Maker_ Logo Design-dex2jar.jar!\androidx\fragment\app\r.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */