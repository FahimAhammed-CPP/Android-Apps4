package androidx.fragment.app;

import android.animation.Animator;
import android.animation.AnimatorListenerAdapter;
import android.view.View;
import android.view.ViewGroup;

public class e extends AnimatorListenerAdapter {
  public e(d paramd, ViewGroup paramViewGroup, View paramView, boolean paramBoolean, b1.b paramb, d.b paramb1) {}
  
  public void onAnimationEnd(Animator paramAnimator) {
    this.a.endViewTransition(this.b);
    if (this.c)
      e1.a(this.d.a, this.b); 
    this.e.a();
  }
}


/* Location:              C:\soft\dex2jar-2.0\Luxury Logo Maker_ Logo Design-dex2jar.jar!\androidx\fragment\app\e.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */