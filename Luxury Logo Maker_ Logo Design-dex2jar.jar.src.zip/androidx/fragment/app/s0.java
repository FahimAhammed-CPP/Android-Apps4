package androidx.fragment.app;

import android.content.Context;
import android.util.SparseArray;
import android.view.View;
import e1.d;
import java.util.ArrayList;
import java.util.Collection;
import java.util.List;
import java.util.Map;
import java.util.WeakHashMap;
import k0.l;
import r.f;
import r.g;

public class s0 {
  public static final int[] a = new int[] { 
      0, 3, 0, 1, 5, 4, 7, 6, 9, 8, 
      10 };
  
  public static final u0 b = new t0();
  
  public static final u0 c;
  
  static {
    try {
      u0 u01 = d.class.getDeclaredConstructor(new Class[0]).newInstance(new Object[0]);
    } catch (Exception exception) {
      exception = null;
    } 
    c = (u0)exception;
  }
  
  public static void a(ArrayList<View> paramArrayList, r.a<String, View> parama, Collection<String> paramCollection) {
    for (int i = ((g)parama).j - 1; i >= 0; i--) {
      View view = (View)parama.l(i);
      WeakHashMap weakHashMap = l.a;
      if (paramCollection.contains(view.getTransitionName()))
        paramArrayList.add(view); 
    } 
  }
  
  public static void b(b paramb, l0.a parama, SparseArray<b> paramSparseArray, boolean paramBoolean1, boolean paramBoolean2) {
    // Byte code:
    //   0: aload_1
    //   1: getfield b : Landroidx/fragment/app/o;
    //   4: astore #13
    //   6: aload #13
    //   8: ifnonnull -> 12
    //   11: return
    //   12: aload #13
    //   14: getfield D : I
    //   17: istore #9
    //   19: iload #9
    //   21: ifne -> 25
    //   24: return
    //   25: iload_3
    //   26: ifeq -> 42
    //   29: getstatic androidx/fragment/app/s0.a : [I
    //   32: aload_1
    //   33: getfield a : I
    //   36: iaload
    //   37: istore #5
    //   39: goto -> 48
    //   42: aload_1
    //   43: getfield a : I
    //   46: istore #5
    //   48: iconst_1
    //   49: istore #7
    //   51: iconst_1
    //   52: istore #6
    //   54: iconst_0
    //   55: istore #10
    //   57: iload #5
    //   59: iconst_1
    //   60: if_icmpeq -> 288
    //   63: iload #5
    //   65: iconst_3
    //   66: if_icmpeq -> 201
    //   69: iload #5
    //   71: iconst_4
    //   72: if_icmpeq -> 150
    //   75: iload #5
    //   77: iconst_5
    //   78: if_icmpeq -> 104
    //   81: iload #5
    //   83: bipush #6
    //   85: if_icmpeq -> 201
    //   88: iload #5
    //   90: bipush #7
    //   92: if_icmpeq -> 288
    //   95: iconst_0
    //   96: istore #10
    //   98: iconst_0
    //   99: istore #5
    //   101: goto -> 326
    //   104: iload #4
    //   106: ifeq -> 136
    //   109: aload #13
    //   111: getfield P : Z
    //   114: ifeq -> 293
    //   117: aload #13
    //   119: getfield F : Z
    //   122: ifne -> 293
    //   125: aload #13
    //   127: getfield r : Z
    //   130: ifeq -> 293
    //   133: goto -> 319
    //   136: aload #13
    //   138: getfield F : Z
    //   141: istore #10
    //   143: iload #6
    //   145: istore #5
    //   147: goto -> 326
    //   150: iload #4
    //   152: ifeq -> 182
    //   155: aload #13
    //   157: getfield P : Z
    //   160: ifeq -> 267
    //   163: aload #13
    //   165: getfield r : Z
    //   168: ifeq -> 267
    //   171: aload #13
    //   173: getfield F : Z
    //   176: ifeq -> 267
    //   179: goto -> 261
    //   182: aload #13
    //   184: getfield r : Z
    //   187: ifeq -> 267
    //   190: aload #13
    //   192: getfield F : Z
    //   195: ifne -> 267
    //   198: goto -> 261
    //   201: aload #13
    //   203: getfield r : Z
    //   206: istore #11
    //   208: iload #4
    //   210: ifeq -> 248
    //   213: iload #11
    //   215: ifne -> 267
    //   218: aload #13
    //   220: getfield L : Landroid/view/View;
    //   223: astore_1
    //   224: aload_1
    //   225: ifnull -> 267
    //   228: aload_1
    //   229: invokevirtual getVisibility : ()I
    //   232: ifne -> 267
    //   235: aload #13
    //   237: getfield Q : F
    //   240: fconst_0
    //   241: fcmpl
    //   242: iflt -> 267
    //   245: goto -> 261
    //   248: iload #11
    //   250: ifeq -> 267
    //   253: aload #13
    //   255: getfield F : Z
    //   258: ifne -> 267
    //   261: iconst_1
    //   262: istore #5
    //   264: goto -> 270
    //   267: iconst_0
    //   268: istore #5
    //   270: iload #5
    //   272: istore #6
    //   274: iconst_0
    //   275: istore #8
    //   277: iload #7
    //   279: istore #5
    //   281: iload #8
    //   283: istore #7
    //   285: goto -> 340
    //   288: iload #4
    //   290: ifeq -> 303
    //   293: iconst_0
    //   294: istore #10
    //   296: iload #6
    //   298: istore #5
    //   300: goto -> 326
    //   303: aload #13
    //   305: getfield r : Z
    //   308: ifne -> 293
    //   311: aload #13
    //   313: getfield F : Z
    //   316: ifne -> 293
    //   319: iconst_1
    //   320: istore #10
    //   322: iload #6
    //   324: istore #5
    //   326: iconst_0
    //   327: istore #8
    //   329: iconst_0
    //   330: istore #6
    //   332: iload #5
    //   334: istore #7
    //   336: iload #8
    //   338: istore #5
    //   340: aload_2
    //   341: iload #9
    //   343: invokevirtual get : (I)Ljava/lang/Object;
    //   346: checkcast androidx/fragment/app/s0$b
    //   349: astore #12
    //   351: aload #12
    //   353: astore_1
    //   354: iload #10
    //   356: ifeq -> 398
    //   359: aload #12
    //   361: astore_1
    //   362: aload #12
    //   364: ifnonnull -> 382
    //   367: new androidx/fragment/app/s0$b
    //   370: dup
    //   371: invokespecial <init> : ()V
    //   374: astore_1
    //   375: aload_2
    //   376: iload #9
    //   378: aload_1
    //   379: invokevirtual put : (ILjava/lang/Object;)V
    //   382: aload_1
    //   383: aload #13
    //   385: putfield a : Landroidx/fragment/app/o;
    //   388: aload_1
    //   389: iload_3
    //   390: putfield b : Z
    //   393: aload_1
    //   394: aload_0
    //   395: putfield c : Landroidx/fragment/app/b;
    //   398: iload #4
    //   400: ifne -> 470
    //   403: iload #7
    //   405: ifeq -> 470
    //   408: aload_1
    //   409: ifnull -> 426
    //   412: aload_1
    //   413: getfield d : Landroidx/fragment/app/o;
    //   416: aload #13
    //   418: if_acmpne -> 426
    //   421: aload_1
    //   422: aconst_null
    //   423: putfield d : Landroidx/fragment/app/o;
    //   426: aload_0
    //   427: getfield o : Z
    //   430: ifne -> 470
    //   433: aload_0
    //   434: getfield p : Landroidx/fragment/app/d0;
    //   437: astore #12
    //   439: aload #12
    //   441: aload #13
    //   443: invokevirtual h : (Landroidx/fragment/app/o;)Landroidx/fragment/app/j0;
    //   446: astore #14
    //   448: aload #12
    //   450: getfield c : Landroidx/fragment/app/k0;
    //   453: aload #14
    //   455: invokevirtual j : (Landroidx/fragment/app/j0;)V
    //   458: aload #12
    //   460: aload #13
    //   462: aload #12
    //   464: getfield p : I
    //   467: invokevirtual U : (Landroidx/fragment/app/o;I)V
    //   470: aload_1
    //   471: astore #12
    //   473: iload #6
    //   475: ifeq -> 535
    //   478: aload_1
    //   479: ifnull -> 492
    //   482: aload_1
    //   483: astore #12
    //   485: aload_1
    //   486: getfield d : Landroidx/fragment/app/o;
    //   489: ifnonnull -> 535
    //   492: aload_1
    //   493: astore #12
    //   495: aload_1
    //   496: ifnonnull -> 516
    //   499: new androidx/fragment/app/s0$b
    //   502: dup
    //   503: invokespecial <init> : ()V
    //   506: astore #12
    //   508: aload_2
    //   509: iload #9
    //   511: aload #12
    //   513: invokevirtual put : (ILjava/lang/Object;)V
    //   516: aload #12
    //   518: aload #13
    //   520: putfield d : Landroidx/fragment/app/o;
    //   523: aload #12
    //   525: iload_3
    //   526: putfield e : Z
    //   529: aload #12
    //   531: aload_0
    //   532: putfield f : Landroidx/fragment/app/b;
    //   535: iload #4
    //   537: ifne -> 566
    //   540: iload #5
    //   542: ifeq -> 566
    //   545: aload #12
    //   547: ifnull -> 566
    //   550: aload #12
    //   552: getfield a : Landroidx/fragment/app/o;
    //   555: aload #13
    //   557: if_acmpne -> 566
    //   560: aload #12
    //   562: aconst_null
    //   563: putfield a : Landroidx/fragment/app/o;
    //   566: return
  }
  
  public static void c(o paramo1, o paramo2, boolean paramBoolean1, r.a<String, View> parama, boolean paramBoolean2) {
    if (paramBoolean1) {
      paramo2.m();
      return;
    } 
    paramo1.m();
  }
  
  public static boolean d(u0 paramu0, List<Object> paramList) {
    int j = paramList.size();
    for (int i = 0; i < j; i++) {
      if (!paramu0.e(paramList.get(i)))
        return false; 
    } 
    return true;
  }
  
  public static r.a<String, View> e(u0 paramu0, r.a<String, String> parama, Object paramObject, b paramb) {
    ArrayList<String> arrayList;
    o o = paramb.a;
    View view = o.L;
    if (parama.isEmpty() || paramObject == null || view == null) {
      parama.clear();
      return null;
    } 
    paramObject = new r.a();
    paramu0.i((Map<String, View>)paramObject, view);
    b b1 = paramb.c;
    if (paramb.b) {
      o.p();
      arrayList = b1.m;
    } else {
      o.m();
      arrayList = ((l0)arrayList).n;
    } 
    if (arrayList != null) {
      f.k((Map)paramObject, arrayList);
      f.k((Map)paramObject, parama.values());
    } 
    m(parama, (r.a<String, View>)paramObject);
    return (r.a<String, View>)paramObject;
  }
  
  public static r.a<String, View> f(u0 paramu0, r.a<String, String> parama, Object paramObject, b paramb) {
    ArrayList<String> arrayList;
    if (parama.isEmpty() || paramObject == null) {
      parama.clear();
      return null;
    } 
    o o = paramb.d;
    paramObject = new r.a();
    paramu0.i((Map<String, View>)paramObject, o.Y());
    b b1 = paramb.f;
    if (paramb.e) {
      o.m();
      arrayList = b1.n;
    } else {
      o.p();
      arrayList = ((l0)arrayList).m;
    } 
    if (arrayList != null)
      f.k((Map)paramObject, arrayList); 
    f.k((Map)parama, paramObject.keySet());
    return (r.a<String, View>)paramObject;
  }
  
  public static u0 g(o paramo1, o paramo2) {
    ArrayList<Object> arrayList = new ArrayList();
    if (paramo1 != null) {
      paramo1.o();
      Object object2 = paramo1.x();
      if (object2 != null)
        arrayList.add(object2); 
      Object object1 = paramo1.z();
      if (object1 != null)
        arrayList.add(object1); 
    } 
    if (paramo2 != null) {
      paramo2.l();
      Object object = paramo2.v();
      if (object != null)
        arrayList.add(object); 
      paramo2.y();
    } 
    if (arrayList.isEmpty())
      return null; 
    u0 u01 = b;
    if (d(u01, arrayList))
      return u01; 
    u01 = c;
    if (u01 != null && d(u01, arrayList))
      return u01; 
    throw new IllegalArgumentException("Invalid Transition types");
  }
  
  public static ArrayList<View> h(u0 paramu0, Object paramObject, o paramo, ArrayList<View> paramArrayList, View paramView) {
    if (paramObject != null) {
      ArrayList<View> arrayList2 = new ArrayList();
      View view = paramo.L;
      if (view != null)
        paramu0.f(arrayList2, view); 
      if (paramArrayList != null)
        arrayList2.removeAll(paramArrayList); 
      ArrayList<View> arrayList1 = arrayList2;
      if (!arrayList2.isEmpty()) {
        arrayList2.add(paramView);
        paramu0.b(paramObject, arrayList2);
        return arrayList2;
      } 
    } else {
      paramo = null;
    } 
    return (ArrayList<View>)paramo;
  }
  
  public static Object i(u0 paramu0, o paramo, boolean paramBoolean) {
    Object object;
    Object object1 = null;
    if (paramo == null)
      return null; 
    if (paramBoolean) {
      object = paramo.v();
    } else {
      object.l();
      object = object1;
    } 
    return paramu0.g(object);
  }
  
  public static Object j(u0 paramu0, o paramo, boolean paramBoolean) {
    Object object;
    Object object1 = null;
    if (paramo == null)
      return null; 
    if (paramBoolean) {
      object = paramo.x();
    } else {
      object.o();
      object = object1;
    } 
    return paramu0.g(object);
  }
  
  public static View k(r.a<String, View> parama, b paramb, Object<String> paramObject, boolean paramBoolean) {
    b b1 = paramb.c;
    if (paramObject != null && parama != null) {
      paramObject = (Object<String>)b1.m;
      if (paramObject != null && !paramObject.isEmpty()) {
        ArrayList<String> arrayList;
        if (paramBoolean) {
          arrayList = b1.m;
        } else {
          arrayList = ((l0)arrayList).n;
        } 
        return (View)parama.get(arrayList.get(0));
      } 
    } 
    return null;
  }
  
  public static Object l(u0 paramu0, o paramo1, o paramo2, boolean paramBoolean) {
    Object object;
    if (paramBoolean) {
      object = paramo2.z();
    } else {
      object.y();
      object = null;
    } 
    return paramu0.y(paramu0.g(object));
  }
  
  public static void m(r.a<String, String> parama, r.a<String, View> parama1) {
    int i = ((g)parama).j;
    while (true) {
      int j = i - 1;
      if (j >= 0) {
        i = j;
        if (!parama1.containsKey(parama.l(j))) {
          parama.j(j);
          i = j;
        } 
        continue;
      } 
      break;
    } 
  }
  
  public static void n(u0 paramu0, Object paramObject1, Object paramObject2, r.a<String, View> parama, boolean paramBoolean, b paramb) {
    ArrayList<String> arrayList = paramb.m;
    if (arrayList != null && !arrayList.isEmpty()) {
      ArrayList<String> arrayList1;
      if (paramBoolean) {
        arrayList1 = paramb.n;
      } else {
        arrayList1 = ((l0)arrayList1).m;
      } 
      View view = (View)parama.get(arrayList1.get(0));
      paramu0.t(paramObject1, view);
      if (paramObject2 != null)
        paramu0.t(paramObject2, view); 
    } 
  }
  
  public static void o(ArrayList<View> paramArrayList, int paramInt) {
    if (paramArrayList == null)
      return; 
    for (int i = paramArrayList.size() - 1; i >= 0; i--)
      ((View)paramArrayList.get(i)).setVisibility(paramInt); 
  }
  
  public static void p(Context paramContext, w paramw, ArrayList<b> paramArrayList, ArrayList<Boolean> paramArrayList1, int paramInt1, int paramInt2, boolean paramBoolean, a parama) {
    boolean bool = paramBoolean;
    SparseArray<b> sparseArray = new SparseArray();
    int i;
    for (i = paramInt1; i < paramInt2; i++) {
      b b = paramArrayList.get(i);
      if (((Boolean)paramArrayList1.get(i)).booleanValue()) {
        if (b.p.r.f()) {
          int j;
          for (j = b.a.size() - 1; j >= 0; j--)
            b(b, b.a.get(j), sparseArray, true, bool); 
        } 
      } else {
        int k = b.a.size();
        int j;
        for (j = 0; j < k; j++)
          b(b, b.a.get(j), sparseArray, false, bool); 
      } 
    } 
    if (sparseArray.size() != 0) {
      View view = new View(paramContext);
      i = sparseArray.size();
      int j = 0;
      while (j < i) {
        int m = sparseArray.keyAt(j);
        r.a a1 = new r.a();
        int k = paramInt2 - 1;
        while (true) {
          boolean bool1 = false;
          j++;
        } 
      } 
    } 
  }
  
  public static interface a {}
  
  public static class b {
    public o a;
    
    public boolean b;
    
    public b c;
    
    public o d;
    
    public boolean e;
    
    public b f;
  }
}


/* Location:              C:\soft\dex2jar-2.0\Luxury Logo Maker_ Logo Design-dex2jar.jar!\androidx\fragment\app\s0.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */