package androidx.fragment.app;

import android.view.View;
import android.view.ViewGroup;
import g0.b;

public class h implements b.a {
  public h(d paramd, View paramView, ViewGroup paramViewGroup, d.b paramb) {}
  
  public void a() {
    this.a.clearAnimation();
    this.b.endViewTransition(this.a);
    this.c.a();
  }
}


/* Location:              C:\soft\dex2jar-2.0\Luxury Logo Maker_ Logo Design-dex2jar.jar!\androidx\fragment\app\h.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */