package androidx.fragment.app;

import java.util.ArrayList;
import java.util.Map;

public class v0 implements Runnable {
  public v0(u0 paramu0, ArrayList paramArrayList, Map paramMap) {}
  
  public void run() {
    // Byte code:
    //   0: aload_0
    //   1: getfield h : Ljava/util/ArrayList;
    //   4: invokevirtual size : ()I
    //   7: istore_2
    //   8: iconst_0
    //   9: istore_1
    //   10: iload_1
    //   11: iload_2
    //   12: if_icmpge -> 123
    //   15: aload_0
    //   16: getfield h : Ljava/util/ArrayList;
    //   19: iload_1
    //   20: invokevirtual get : (I)Ljava/lang/Object;
    //   23: checkcast android/view/View
    //   26: astore #4
    //   28: getstatic k0/l.a : Ljava/util/WeakHashMap;
    //   31: astore_3
    //   32: aload #4
    //   34: invokevirtual getTransitionName : ()Ljava/lang/String;
    //   37: astore_3
    //   38: aload_3
    //   39: ifnull -> 116
    //   42: aload_0
    //   43: getfield i : Ljava/util/Map;
    //   46: invokeinterface entrySet : ()Ljava/util/Set;
    //   51: invokeinterface iterator : ()Ljava/util/Iterator;
    //   56: astore #5
    //   58: aload #5
    //   60: invokeinterface hasNext : ()Z
    //   65: ifeq -> 108
    //   68: aload #5
    //   70: invokeinterface next : ()Ljava/lang/Object;
    //   75: checkcast java/util/Map$Entry
    //   78: astore #6
    //   80: aload_3
    //   81: aload #6
    //   83: invokeinterface getValue : ()Ljava/lang/Object;
    //   88: invokevirtual equals : (Ljava/lang/Object;)Z
    //   91: ifeq -> 58
    //   94: aload #6
    //   96: invokeinterface getKey : ()Ljava/lang/Object;
    //   101: checkcast java/lang/String
    //   104: astore_3
    //   105: goto -> 110
    //   108: aconst_null
    //   109: astore_3
    //   110: aload #4
    //   112: aload_3
    //   113: invokevirtual setTransitionName : (Ljava/lang/String;)V
    //   116: iload_1
    //   117: iconst_1
    //   118: iadd
    //   119: istore_1
    //   120: goto -> 10
    //   123: return
  }
}


/* Location:              C:\soft\dex2jar-2.0\Luxury Logo Maker_ Logo Design-dex2jar.jar!\androidx\fragment\app\v0.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */