package androidx.fragment.app;

import g0.b;

public class c1 implements b.a {
  public c1(b1.b paramb) {}
  
  public void a() {
    this.a.a();
  }
}


/* Location:              C:\soft\dex2jar-2.0\Luxury Logo Maker_ Logo Design-dex2jar.jar!\androidx\fragment\app\c1.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */