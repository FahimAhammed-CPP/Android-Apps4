package androidx.fragment.app;

import android.support.v4.media.c;
import android.util.Log;
import android.view.View;
import android.view.ViewGroup;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Objects;
import java.util.WeakHashMap;
import k0.l;

public abstract class b1 {
  public final ViewGroup a;
  
  public final ArrayList<b> b = new ArrayList<b>();
  
  public final ArrayList<b> c = new ArrayList<b>();
  
  public boolean d = false;
  
  public boolean e = false;
  
  public b1(ViewGroup paramViewGroup) {
    this.a = paramViewGroup;
  }
  
  public static b1 f(ViewGroup paramViewGroup, d0 paramd0) {
    return g(paramViewGroup, paramd0.M());
  }
  
  public static b1 g(ViewGroup paramViewGroup, f1 paramf1) {
    Object object = paramViewGroup.getTag(2131362339);
    if (object instanceof b1)
      return (b1)object; 
    Objects.requireNonNull((d0.f)paramf1);
    d d = new d(paramViewGroup);
    paramViewGroup.setTag(2131362339, d);
    return d;
  }
  
  public final void a(int paramInt1, int paramInt2, j0 paramj0) {
    synchronized (this.b) {
      g0.b b = new g0.b();
      b b2 = d(paramj0.c);
      if (b2 != null) {
        b2.c(paramInt1, paramInt2);
        return;
      } 
      a a = new a(paramInt1, paramInt2, paramj0, b);
      this.b.add(a);
      z0 z0 = new z0(this, a);
      a.d.add(z0);
      a1 a1 = new a1(this, a);
      a.d.add(a1);
      return;
    } 
  }
  
  public abstract void b(List<b> paramList, boolean paramBoolean);
  
  public void c() {
    if (this.e)
      return; 
    ViewGroup viewGroup = this.a;
    null = l.a;
    if (!viewGroup.isAttachedToWindow()) {
      e();
      this.d = false;
      return;
    } 
    synchronized (this.b) {
      if (!this.b.isEmpty()) {
        ArrayList<b> arrayList = new ArrayList<b>(this.c);
        this.c.clear();
        for (b b : arrayList) {
          if (d0.O(2)) {
            StringBuilder stringBuilder = new StringBuilder();
            stringBuilder.append("SpecialEffectsController: Cancelling operation ");
            stringBuilder.append(b);
            Log.v("FragmentManager", stringBuilder.toString());
          } 
          b.a();
          if (!b.g)
            this.c.add(b); 
        } 
        i();
        arrayList = new ArrayList<b>(this.b);
        this.b.clear();
        this.c.addAll(arrayList);
        Iterator<b> iterator = arrayList.iterator();
        while (iterator.hasNext())
          ((b)iterator.next()).d(); 
        b(arrayList, this.d);
        this.d = false;
      } 
      return;
    } 
  }
  
  public final b d(o paramo) {
    for (b b : this.b) {
      if (b.c.equals(paramo) && !b.f)
        return b; 
    } 
    return null;
  }
  
  public void e() {
    null = this.a;
    WeakHashMap weakHashMap = l.a;
    boolean bool = null.isAttachedToWindow();
    synchronized (this.b) {
      i();
      Iterator<b> iterator = this.b.iterator();
      while (iterator.hasNext())
        ((b)iterator.next()).d(); 
      for (b b : new ArrayList(this.c)) {
        if (d0.O(2)) {
          String str;
          StringBuilder stringBuilder = new StringBuilder();
          stringBuilder.append("SpecialEffectsController: ");
          if (bool) {
            str = "";
          } else {
            StringBuilder stringBuilder1 = new StringBuilder();
            stringBuilder1.append("Container ");
            stringBuilder1.append(this.a);
            stringBuilder1.append(" is not attached to window. ");
            str = stringBuilder1.toString();
          } 
          stringBuilder.append(str);
          stringBuilder.append("Cancelling running operation ");
          stringBuilder.append(b);
          Log.v("FragmentManager", stringBuilder.toString());
        } 
        b.a();
      } 
      for (b b : new ArrayList(this.b)) {
        if (d0.O(2)) {
          String str;
          StringBuilder stringBuilder = new StringBuilder();
          stringBuilder.append("SpecialEffectsController: ");
          if (bool) {
            str = "";
          } else {
            StringBuilder stringBuilder1 = new StringBuilder();
            stringBuilder1.append("Container ");
            stringBuilder1.append(this.a);
            stringBuilder1.append(" is not attached to window. ");
            str = stringBuilder1.toString();
          } 
          stringBuilder.append(str);
          stringBuilder.append("Cancelling pending operation ");
          stringBuilder.append(b);
          Log.v("FragmentManager", stringBuilder.toString());
        } 
        b.a();
      } 
      return;
    } 
  }
  
  public void h() {
    synchronized (this.b) {
      i();
      this.e = false;
      int i = this.b.size();
      while (true) {
        int j = i - 1;
        if (j >= 0) {
          b b = this.b.get(j);
          int k = e1.c(b.c.L);
          i = j;
          if (b.a == 2) {
            i = j;
            if (k != 2) {
              Objects.requireNonNull(b.c);
              this.e = false;
              break;
            } 
          } 
          continue;
        } 
        break;
      } 
      return;
    } 
  }
  
  public final void i() {
    for (b b : this.b) {
      if (b.b == 2)
        b.c(e1.b(b.c.Y().getVisibility()), 1); 
    } 
  }
  
  public static class a extends b {
    public final j0 h;
    
    public a(int param1Int1, int param1Int2, j0 param1j0, g0.b param1b) {
      super(param1Int1, param1Int2, param1j0.c, param1b);
      this.h = param1j0;
    }
    
    public void b() {
      super.b();
      this.h.k();
    }
    
    public void d() {
      if (this.b == 2) {
        float f;
        o o = this.h.c;
        View view = o.L.findFocus();
        if (view != null) {
          (o.f()).o = view;
          if (d0.O(2)) {
            StringBuilder stringBuilder = new StringBuilder();
            stringBuilder.append("requestFocus: Saved focused view ");
            stringBuilder.append(view);
            stringBuilder.append(" for Fragment ");
            stringBuilder.append(o);
            Log.v("FragmentManager", stringBuilder.toString());
          } 
        } 
        view = this.c.Y();
        if (view.getParent() == null) {
          this.h.b();
          view.setAlpha(0.0F);
        } 
        if (view.getAlpha() == 0.0F && view.getVisibility() == 0)
          view.setVisibility(4); 
        o.b b1 = o.O;
        if (b1 == null) {
          f = 1.0F;
        } else {
          f = b1.n;
        } 
        view.setAlpha(f);
      } 
    }
  }
  
  public static class b {
    public int a;
    
    public int b;
    
    public final o c;
    
    public final List<Runnable> d = new ArrayList<Runnable>();
    
    public final HashSet<g0.b> e = new HashSet<g0.b>();
    
    public boolean f = false;
    
    public boolean g = false;
    
    public b(int param1Int1, int param1Int2, o param1o, g0.b param1b) {
      this.a = param1Int1;
      this.b = param1Int2;
      this.c = param1o;
      param1b.b(new c1(this));
    }
    
    public final void a() {
      if (this.f)
        return; 
      this.f = true;
      if (this.e.isEmpty()) {
        b();
        return;
      } 
      Iterator<?> iterator = (new ArrayList(this.e)).iterator();
      while (iterator.hasNext())
        ((g0.b)iterator.next()).a(); 
    }
    
    public void b() {
      if (this.g)
        return; 
      if (d0.O(2)) {
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("SpecialEffectsController: ");
        stringBuilder.append(this);
        stringBuilder.append(" has called complete.");
        Log.v("FragmentManager", stringBuilder.toString());
      } 
      this.g = true;
      Iterator<Runnable> iterator = this.d.iterator();
      while (iterator.hasNext())
        ((Runnable)iterator.next()).run(); 
    }
    
    public final void c(int param1Int1, int param1Int2) {
      if (param1Int2 != 0) {
        if (--param1Int2 != 0) {
          if (param1Int2 != 1) {
            if (param1Int2 != 2)
              return; 
            if (d0.O(2)) {
              StringBuilder stringBuilder = c.a("SpecialEffectsController: For fragment ");
              stringBuilder.append(this.c);
              stringBuilder.append(" mFinalState = ");
              stringBuilder.append(e1.d(this.a));
              stringBuilder.append(" -> REMOVED. mLifecycleImpact  = ");
              stringBuilder.append(d1.a(this.b));
              stringBuilder.append(" to REMOVING.");
              Log.v("FragmentManager", stringBuilder.toString());
            } 
            this.a = 1;
            this.b = 3;
            return;
          } 
          if (this.a == 1) {
            if (d0.O(2)) {
              StringBuilder stringBuilder = c.a("SpecialEffectsController: For fragment ");
              stringBuilder.append(this.c);
              stringBuilder.append(" mFinalState = REMOVED -> VISIBLE. mLifecycleImpact = ");
              stringBuilder.append(d1.a(this.b));
              stringBuilder.append(" to ADDING.");
              Log.v("FragmentManager", stringBuilder.toString());
            } 
            this.a = 2;
            this.b = 2;
            return;
          } 
        } else if (this.a != 1) {
          if (d0.O(2)) {
            StringBuilder stringBuilder = c.a("SpecialEffectsController: For fragment ");
            stringBuilder.append(this.c);
            stringBuilder.append(" mFinalState = ");
            stringBuilder.append(e1.d(this.a));
            stringBuilder.append(" -> ");
            stringBuilder.append(e1.d(param1Int1));
            stringBuilder.append(". ");
            Log.v("FragmentManager", stringBuilder.toString());
          } 
          this.a = param1Int1;
        } 
        return;
      } 
      throw null;
    }
    
    public void d() {}
    
    public String toString() {
      StringBuilder stringBuilder = new StringBuilder();
      stringBuilder.append("Operation ");
      stringBuilder.append("{");
      stringBuilder.append(Integer.toHexString(System.identityHashCode(this)));
      stringBuilder.append("} ");
      stringBuilder.append("{");
      stringBuilder.append("mFinalState = ");
      stringBuilder.append(e1.d(this.a));
      stringBuilder.append("} ");
      stringBuilder.append("{");
      stringBuilder.append("mLifecycleImpact = ");
      stringBuilder.append(d1.a(this.b));
      stringBuilder.append("} ");
      stringBuilder.append("{");
      stringBuilder.append("mFragment = ");
      stringBuilder.append(this.c);
      stringBuilder.append("}");
      return stringBuilder.toString();
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Luxury Logo Maker_ Logo Design-dex2jar.jar!\androidx\fragment\app\b1.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */