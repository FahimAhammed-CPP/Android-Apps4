package androidx.fragment.app;

import android.util.Log;
import java.io.Writer;

public final class y0 extends Writer {
  public final String h;
  
  public StringBuilder i = new StringBuilder(128);
  
  public y0(String paramString) {
    this.h = paramString;
  }
  
  public final void a() {
    if (this.i.length() > 0) {
      Log.d(this.h, this.i.toString());
      StringBuilder stringBuilder = this.i;
      stringBuilder.delete(0, stringBuilder.length());
    } 
  }
  
  public void close() {
    a();
  }
  
  public void flush() {
    a();
  }
  
  public void write(char[] paramArrayOfchar, int paramInt1, int paramInt2) {
    int i;
    for (i = 0; i < paramInt2; i++) {
      char c = paramArrayOfchar[paramInt1 + i];
      if (c == '\n') {
        a();
      } else {
        this.i.append(c);
      } 
    } 
  }
}


/* Location:              C:\soft\dex2jar-2.0\Luxury Logo Maker_ Logo Design-dex2jar.jar!\androidx\fragment\app\y0.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */