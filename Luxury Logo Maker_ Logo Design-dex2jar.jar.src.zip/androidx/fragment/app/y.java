package androidx.fragment.app;

public class y {
  public final a0<?> a;
  
  public y(a0<?> parama0) {
    this.a = parama0;
  }
  
  public void a() {
    this.a.k.V();
  }
}


/* Location:              C:\soft\dex2jar-2.0\Luxury Logo Maker_ Logo Design-dex2jar.jar!\androidx\fragment\app\y.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */