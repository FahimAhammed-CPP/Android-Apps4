package androidx.fragment.app;

import android.annotation.SuppressLint;
import android.content.Context;
import android.content.Intent;
import android.content.res.Configuration;
import android.os.Bundle;
import android.os.Looper;
import android.os.Parcel;
import android.os.Parcelable;
import android.util.Log;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import androidx.activity.OnBackPressedDispatcher;
import java.io.FileDescriptor;
import java.io.PrintWriter;
import java.lang.reflect.InvocationTargetException;
import java.util.ArrayDeque;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.Set;
import java.util.concurrent.CopyOnWriteArrayList;
import java.util.concurrent.atomic.AtomicInteger;

public abstract class d0 {
  public boolean A;
  
  public boolean B;
  
  public boolean C;
  
  public boolean D;
  
  public boolean E;
  
  public ArrayList<b> F;
  
  public ArrayList<Boolean> G;
  
  public ArrayList<o> H;
  
  public ArrayList<n> I;
  
  public g0 J;
  
  public Runnable K = new g(this);
  
  public final ArrayList<l> a = new ArrayList<l>();
  
  public boolean b;
  
  public final k0 c = new k0();
  
  public ArrayList<b> d;
  
  public ArrayList<o> e;
  
  public final b0 f = new b0(this);
  
  public OnBackPressedDispatcher g;
  
  public final androidx.activity.b h = new c(this, false);
  
  public final AtomicInteger i = new AtomicInteger();
  
  public final Map<String, Bundle> j = Collections.synchronizedMap(new HashMap<String, Bundle>());
  
  public final Map<String, Object> k = Collections.synchronizedMap(new HashMap<String, Object>());
  
  public Map<o, HashSet<g0.b>> l = Collections.synchronizedMap(new HashMap<o, HashSet<g0.b>>());
  
  public final s0.a m = new d(this);
  
  public final c0 n = new c0(this);
  
  public final CopyOnWriteArrayList<h0> o = new CopyOnWriteArrayList<h0>();
  
  public int p = -1;
  
  public a0<?> q;
  
  public w r;
  
  public o s;
  
  public o t;
  
  public z u = new e(this);
  
  public f1 v = new f(this);
  
  public androidx.activity.result.c<Intent> w;
  
  public androidx.activity.result.c<Object> x;
  
  public androidx.activity.result.c<String[]> y;
  
  public ArrayDeque<k> z = new ArrayDeque<k>();
  
  public static boolean O(int paramInt) {
    return Log.isLoggable("FragmentManager", paramInt);
  }
  
  public void A(l paraml, boolean paramBoolean) {
    if (!paramBoolean) {
      if (this.q == null) {
        if (this.D)
          throw new IllegalStateException("FragmentManager has been destroyed"); 
        throw new IllegalStateException("FragmentManager has not been attached to a host.");
      } 
      if (S())
        throw new IllegalStateException("Can not perform this action after onSaveInstanceState"); 
    } 
    synchronized (this.a) {
      if (this.q == null) {
        if (paramBoolean)
          return; 
        throw new IllegalStateException("Activity has been destroyed");
      } 
      this.a.add(paraml);
      c0();
      return;
    } 
  }
  
  public final void B(boolean paramBoolean) {
    if (!this.b) {
      if (this.q == null) {
        if (this.D)
          throw new IllegalStateException("FragmentManager has been destroyed"); 
        throw new IllegalStateException("FragmentManager has not been attached to a host.");
      } 
      if (Looper.myLooper() == this.q.j.getLooper()) {
        if (paramBoolean || !S()) {
          if (this.F == null) {
            this.F = new ArrayList<b>();
            this.G = new ArrayList<Boolean>();
          } 
          this.b = true;
          try {
            F(null, null);
            return;
          } finally {
            this.b = false;
          } 
        } 
        throw new IllegalStateException("Can not perform this action after onSaveInstanceState");
      } 
      throw new IllegalStateException("Must be called from main thread of fragment host");
    } 
    throw new IllegalStateException("FragmentManager is already executing transactions");
  }
  
  public boolean C(boolean paramBoolean) {
    B(paramBoolean);
    paramBoolean = false;
    while (true) {
      null = this.F;
      ArrayList<Boolean> arrayList = this.G;
      synchronized (this.a) {
        boolean bool;
        if (this.a.isEmpty()) {
          bool = false;
        } else {
          int j = this.a.size();
          int i = 0;
          bool = false;
          while (i < j) {
            bool |= ((l)this.a.get(i)).a(null, arrayList);
            i++;
          } 
          this.a.clear();
          this.q.j.removeCallbacks(this.K);
        } 
        if (bool) {
          this.b = true;
          try {
            Z(this.F, this.G);
            e();
          } finally {
            e();
          } 
          continue;
        } 
        j0();
        x();
        this.c.b();
        return paramBoolean;
      } 
    } 
  }
  
  public void D(l paraml, boolean paramBoolean) {
    if (paramBoolean && (this.q == null || this.D))
      return; 
    B(paramBoolean);
    ArrayList<b> arrayList = this.F;
    ArrayList<Boolean> arrayList1 = this.G;
    ((b)paraml).a(arrayList, arrayList1);
    this.b = true;
    try {
      Z(this.F, this.G);
      e();
      j0();
      x();
      return;
    } finally {
      e();
    } 
  }
  
  public final void E(ArrayList<b> paramArrayList, ArrayList<Boolean> paramArrayList1, int paramInt1, int paramInt2) {
    // Byte code:
    //   0: aload_1
    //   1: iload_3
    //   2: invokevirtual get : (I)Ljava/lang/Object;
    //   5: checkcast androidx/fragment/app/b
    //   8: getfield o : Z
    //   11: istore #11
    //   13: aload_0
    //   14: getfield H : Ljava/util/ArrayList;
    //   17: astore #12
    //   19: aload #12
    //   21: ifnonnull -> 38
    //   24: aload_0
    //   25: new java/util/ArrayList
    //   28: dup
    //   29: invokespecial <init> : ()V
    //   32: putfield H : Ljava/util/ArrayList;
    //   35: goto -> 43
    //   38: aload #12
    //   40: invokevirtual clear : ()V
    //   43: aload_0
    //   44: getfield H : Ljava/util/ArrayList;
    //   47: aload_0
    //   48: getfield c : Landroidx/fragment/app/k0;
    //   51: invokevirtual i : ()Ljava/util/List;
    //   54: invokevirtual addAll : (Ljava/util/Collection;)Z
    //   57: pop
    //   58: aload_0
    //   59: getfield t : Landroidx/fragment/app/o;
    //   62: astore #12
    //   64: iload_3
    //   65: istore #7
    //   67: iconst_0
    //   68: istore #8
    //   70: iload #7
    //   72: iload #4
    //   74: if_icmpge -> 780
    //   77: aload_1
    //   78: iload #7
    //   80: invokevirtual get : (I)Ljava/lang/Object;
    //   83: checkcast androidx/fragment/app/b
    //   86: astore #14
    //   88: aload_2
    //   89: iload #7
    //   91: invokevirtual get : (I)Ljava/lang/Object;
    //   94: checkcast java/lang/Boolean
    //   97: invokevirtual booleanValue : ()Z
    //   100: ifne -> 574
    //   103: aload_0
    //   104: getfield H : Ljava/util/ArrayList;
    //   107: astore #15
    //   109: iconst_0
    //   110: istore #5
    //   112: aload #12
    //   114: astore #13
    //   116: iload #5
    //   118: aload #14
    //   120: getfield a : Ljava/util/ArrayList;
    //   123: invokevirtual size : ()I
    //   126: if_icmpge -> 738
    //   129: aload #14
    //   131: getfield a : Ljava/util/ArrayList;
    //   134: iload #5
    //   136: invokevirtual get : (I)Ljava/lang/Object;
    //   139: checkcast androidx/fragment/app/l0$a
    //   142: astore #13
    //   144: aload #13
    //   146: getfield a : I
    //   149: istore #6
    //   151: iload #6
    //   153: iconst_1
    //   154: if_icmpeq -> 554
    //   157: iload #6
    //   159: iconst_2
    //   160: if_icmpeq -> 304
    //   163: iload #6
    //   165: iconst_3
    //   166: if_icmpeq -> 238
    //   169: iload #6
    //   171: bipush #6
    //   173: if_icmpeq -> 238
    //   176: iload #6
    //   178: bipush #7
    //   180: if_icmpeq -> 554
    //   183: iload #6
    //   185: bipush #8
    //   187: if_icmpeq -> 201
    //   190: aload #12
    //   192: astore #13
    //   194: iload #5
    //   196: istore #6
    //   198: goto -> 526
    //   201: aload #14
    //   203: getfield a : Ljava/util/ArrayList;
    //   206: iload #5
    //   208: new androidx/fragment/app/l0$a
    //   211: dup
    //   212: bipush #9
    //   214: aload #12
    //   216: invokespecial <init> : (ILandroidx/fragment/app/o;)V
    //   219: invokevirtual add : (ILjava/lang/Object;)V
    //   222: iload #5
    //   224: iconst_1
    //   225: iadd
    //   226: istore #6
    //   228: aload #13
    //   230: getfield b : Landroidx/fragment/app/o;
    //   233: astore #13
    //   235: goto -> 526
    //   238: aload #15
    //   240: aload #13
    //   242: getfield b : Landroidx/fragment/app/o;
    //   245: invokevirtual remove : (Ljava/lang/Object;)Z
    //   248: pop
    //   249: aload #13
    //   251: getfield b : Landroidx/fragment/app/o;
    //   254: astore #16
    //   256: aload #12
    //   258: astore #13
    //   260: iload #5
    //   262: istore #6
    //   264: aload #16
    //   266: aload #12
    //   268: if_acmpne -> 526
    //   271: aload #14
    //   273: getfield a : Ljava/util/ArrayList;
    //   276: iload #5
    //   278: new androidx/fragment/app/l0$a
    //   281: dup
    //   282: bipush #9
    //   284: aload #16
    //   286: invokespecial <init> : (ILandroidx/fragment/app/o;)V
    //   289: invokevirtual add : (ILjava/lang/Object;)V
    //   292: iload #5
    //   294: iconst_1
    //   295: iadd
    //   296: istore #5
    //   298: aconst_null
    //   299: astore #12
    //   301: goto -> 565
    //   304: aload #13
    //   306: getfield b : Landroidx/fragment/app/o;
    //   309: astore #16
    //   311: aload #16
    //   313: getfield D : I
    //   316: istore #6
    //   318: aload #15
    //   320: invokevirtual size : ()I
    //   323: iconst_1
    //   324: isub
    //   325: istore #9
    //   327: iconst_0
    //   328: istore #10
    //   330: iload #9
    //   332: iflt -> 500
    //   335: aload #15
    //   337: iload #9
    //   339: invokevirtual get : (I)Ljava/lang/Object;
    //   342: checkcast androidx/fragment/app/o
    //   345: astore #17
    //   347: aload #17
    //   349: getfield D : I
    //   352: iload #6
    //   354: if_icmpne -> 491
    //   357: aload #17
    //   359: aload #16
    //   361: if_acmpne -> 370
    //   364: iconst_1
    //   365: istore #10
    //   367: goto -> 491
    //   370: aload #17
    //   372: aload #12
    //   374: if_acmpne -> 410
    //   377: aload #14
    //   379: getfield a : Ljava/util/ArrayList;
    //   382: iload #5
    //   384: new androidx/fragment/app/l0$a
    //   387: dup
    //   388: bipush #9
    //   390: aload #17
    //   392: invokespecial <init> : (ILandroidx/fragment/app/o;)V
    //   395: invokevirtual add : (ILjava/lang/Object;)V
    //   398: iload #5
    //   400: iconst_1
    //   401: iadd
    //   402: istore #5
    //   404: aconst_null
    //   405: astore #12
    //   407: goto -> 410
    //   410: new androidx/fragment/app/l0$a
    //   413: dup
    //   414: iconst_3
    //   415: aload #17
    //   417: invokespecial <init> : (ILandroidx/fragment/app/o;)V
    //   420: astore #18
    //   422: aload #18
    //   424: aload #13
    //   426: getfield c : I
    //   429: putfield c : I
    //   432: aload #18
    //   434: aload #13
    //   436: getfield e : I
    //   439: putfield e : I
    //   442: aload #18
    //   444: aload #13
    //   446: getfield d : I
    //   449: putfield d : I
    //   452: aload #18
    //   454: aload #13
    //   456: getfield f : I
    //   459: putfield f : I
    //   462: aload #14
    //   464: getfield a : Ljava/util/ArrayList;
    //   467: iload #5
    //   469: aload #18
    //   471: invokevirtual add : (ILjava/lang/Object;)V
    //   474: aload #15
    //   476: aload #17
    //   478: invokevirtual remove : (Ljava/lang/Object;)Z
    //   481: pop
    //   482: iload #5
    //   484: iconst_1
    //   485: iadd
    //   486: istore #5
    //   488: goto -> 491
    //   491: iload #9
    //   493: iconst_1
    //   494: isub
    //   495: istore #9
    //   497: goto -> 330
    //   500: iload #10
    //   502: ifeq -> 537
    //   505: aload #14
    //   507: getfield a : Ljava/util/ArrayList;
    //   510: iload #5
    //   512: invokevirtual remove : (I)Ljava/lang/Object;
    //   515: pop
    //   516: iload #5
    //   518: iconst_1
    //   519: isub
    //   520: istore #6
    //   522: aload #12
    //   524: astore #13
    //   526: aload #13
    //   528: astore #12
    //   530: iload #6
    //   532: istore #5
    //   534: goto -> 565
    //   537: aload #13
    //   539: iconst_1
    //   540: putfield a : I
    //   543: aload #15
    //   545: aload #16
    //   547: invokevirtual add : (Ljava/lang/Object;)Z
    //   550: pop
    //   551: goto -> 565
    //   554: aload #15
    //   556: aload #13
    //   558: getfield b : Landroidx/fragment/app/o;
    //   561: invokevirtual add : (Ljava/lang/Object;)Z
    //   564: pop
    //   565: iload #5
    //   567: iconst_1
    //   568: iadd
    //   569: istore #5
    //   571: goto -> 112
    //   574: aload_0
    //   575: getfield H : Ljava/util/ArrayList;
    //   578: astore #15
    //   580: aload #14
    //   582: getfield a : Ljava/util/ArrayList;
    //   585: invokevirtual size : ()I
    //   588: iconst_1
    //   589: isub
    //   590: istore #5
    //   592: aload #12
    //   594: astore #13
    //   596: iload #5
    //   598: iflt -> 738
    //   601: aload #14
    //   603: getfield a : Ljava/util/ArrayList;
    //   606: iload #5
    //   608: invokevirtual get : (I)Ljava/lang/Object;
    //   611: checkcast androidx/fragment/app/l0$a
    //   614: astore #13
    //   616: aload #13
    //   618: getfield a : I
    //   621: istore #6
    //   623: iload #6
    //   625: iconst_1
    //   626: if_icmpeq -> 718
    //   629: iload #6
    //   631: iconst_3
    //   632: if_icmpeq -> 704
    //   635: iload #6
    //   637: tableswitch default -> 672, 6 -> 704, 7 -> 718, 8 -> 698, 9 -> 688, 10 -> 675
    //   672: goto -> 729
    //   675: aload #13
    //   677: aload #13
    //   679: getfield g : Landroidx/lifecycle/e$c;
    //   682: putfield h : Landroidx/lifecycle/e$c;
    //   685: goto -> 729
    //   688: aload #13
    //   690: getfield b : Landroidx/fragment/app/o;
    //   693: astore #12
    //   695: goto -> 729
    //   698: aconst_null
    //   699: astore #12
    //   701: goto -> 729
    //   704: aload #15
    //   706: aload #13
    //   708: getfield b : Landroidx/fragment/app/o;
    //   711: invokevirtual add : (Ljava/lang/Object;)Z
    //   714: pop
    //   715: goto -> 729
    //   718: aload #15
    //   720: aload #13
    //   722: getfield b : Landroidx/fragment/app/o;
    //   725: invokevirtual remove : (Ljava/lang/Object;)Z
    //   728: pop
    //   729: iload #5
    //   731: iconst_1
    //   732: isub
    //   733: istore #5
    //   735: goto -> 592
    //   738: iload #8
    //   740: ifne -> 760
    //   743: aload #14
    //   745: getfield g : Z
    //   748: ifeq -> 754
    //   751: goto -> 760
    //   754: iconst_0
    //   755: istore #5
    //   757: goto -> 763
    //   760: iconst_1
    //   761: istore #5
    //   763: iload #7
    //   765: iconst_1
    //   766: iadd
    //   767: istore #7
    //   769: aload #13
    //   771: astore #12
    //   773: iload #5
    //   775: istore #8
    //   777: goto -> 70
    //   780: aload_0
    //   781: getfield H : Ljava/util/ArrayList;
    //   784: invokevirtual clear : ()V
    //   787: iload #11
    //   789: ifne -> 894
    //   792: aload_0
    //   793: getfield p : I
    //   796: iconst_1
    //   797: if_icmplt -> 894
    //   800: iload_3
    //   801: istore #5
    //   803: iload #5
    //   805: iload #4
    //   807: if_icmpge -> 894
    //   810: aload_1
    //   811: iload #5
    //   813: invokevirtual get : (I)Ljava/lang/Object;
    //   816: checkcast androidx/fragment/app/b
    //   819: getfield a : Ljava/util/ArrayList;
    //   822: invokevirtual iterator : ()Ljava/util/Iterator;
    //   825: astore #12
    //   827: aload #12
    //   829: invokeinterface hasNext : ()Z
    //   834: ifeq -> 885
    //   837: aload #12
    //   839: invokeinterface next : ()Ljava/lang/Object;
    //   844: checkcast androidx/fragment/app/l0$a
    //   847: getfield b : Landroidx/fragment/app/o;
    //   850: astore #13
    //   852: aload #13
    //   854: ifnull -> 827
    //   857: aload #13
    //   859: getfield y : Landroidx/fragment/app/d0;
    //   862: ifnull -> 827
    //   865: aload_0
    //   866: aload #13
    //   868: invokevirtual h : (Landroidx/fragment/app/o;)Landroidx/fragment/app/j0;
    //   871: astore #13
    //   873: aload_0
    //   874: getfield c : Landroidx/fragment/app/k0;
    //   877: aload #13
    //   879: invokevirtual j : (Landroidx/fragment/app/j0;)V
    //   882: goto -> 827
    //   885: iload #5
    //   887: iconst_1
    //   888: iadd
    //   889: istore #5
    //   891: goto -> 803
    //   894: iload_3
    //   895: istore #5
    //   897: iload #5
    //   899: iload #4
    //   901: if_icmpge -> 984
    //   904: aload_1
    //   905: iload #5
    //   907: invokevirtual get : (I)Ljava/lang/Object;
    //   910: checkcast androidx/fragment/app/b
    //   913: astore #12
    //   915: aload_2
    //   916: iload #5
    //   918: invokevirtual get : (I)Ljava/lang/Object;
    //   921: checkcast java/lang/Boolean
    //   924: invokevirtual booleanValue : ()Z
    //   927: ifeq -> 964
    //   930: aload #12
    //   932: iconst_m1
    //   933: invokevirtual e : (I)V
    //   936: iload #5
    //   938: iload #4
    //   940: iconst_1
    //   941: isub
    //   942: if_icmpne -> 951
    //   945: iconst_1
    //   946: istore #11
    //   948: goto -> 954
    //   951: iconst_0
    //   952: istore #11
    //   954: aload #12
    //   956: iload #11
    //   958: invokevirtual k : (Z)V
    //   961: goto -> 975
    //   964: aload #12
    //   966: iconst_1
    //   967: invokevirtual e : (I)V
    //   970: aload #12
    //   972: invokevirtual j : ()V
    //   975: iload #5
    //   977: iconst_1
    //   978: iadd
    //   979: istore #5
    //   981: goto -> 897
    //   984: aload_2
    //   985: iload #4
    //   987: iconst_1
    //   988: isub
    //   989: invokevirtual get : (I)Ljava/lang/Object;
    //   992: checkcast java/lang/Boolean
    //   995: invokevirtual booleanValue : ()Z
    //   998: istore #11
    //   1000: iload_3
    //   1001: istore #5
    //   1003: iload #5
    //   1005: iload #4
    //   1007: if_icmpge -> 1145
    //   1010: aload_1
    //   1011: iload #5
    //   1013: invokevirtual get : (I)Ljava/lang/Object;
    //   1016: checkcast androidx/fragment/app/b
    //   1019: astore #12
    //   1021: iload #11
    //   1023: ifeq -> 1084
    //   1026: aload #12
    //   1028: getfield a : Ljava/util/ArrayList;
    //   1031: invokevirtual size : ()I
    //   1034: iconst_1
    //   1035: isub
    //   1036: istore #6
    //   1038: iload #6
    //   1040: iflt -> 1136
    //   1043: aload #12
    //   1045: getfield a : Ljava/util/ArrayList;
    //   1048: iload #6
    //   1050: invokevirtual get : (I)Ljava/lang/Object;
    //   1053: checkcast androidx/fragment/app/l0$a
    //   1056: getfield b : Landroidx/fragment/app/o;
    //   1059: astore #13
    //   1061: aload #13
    //   1063: ifnull -> 1075
    //   1066: aload_0
    //   1067: aload #13
    //   1069: invokevirtual h : (Landroidx/fragment/app/o;)Landroidx/fragment/app/j0;
    //   1072: invokevirtual k : ()V
    //   1075: iload #6
    //   1077: iconst_1
    //   1078: isub
    //   1079: istore #6
    //   1081: goto -> 1038
    //   1084: aload #12
    //   1086: getfield a : Ljava/util/ArrayList;
    //   1089: invokevirtual iterator : ()Ljava/util/Iterator;
    //   1092: astore #12
    //   1094: aload #12
    //   1096: invokeinterface hasNext : ()Z
    //   1101: ifeq -> 1136
    //   1104: aload #12
    //   1106: invokeinterface next : ()Ljava/lang/Object;
    //   1111: checkcast androidx/fragment/app/l0$a
    //   1114: getfield b : Landroidx/fragment/app/o;
    //   1117: astore #13
    //   1119: aload #13
    //   1121: ifnull -> 1094
    //   1124: aload_0
    //   1125: aload #13
    //   1127: invokevirtual h : (Landroidx/fragment/app/o;)Landroidx/fragment/app/j0;
    //   1130: invokevirtual k : ()V
    //   1133: goto -> 1094
    //   1136: iload #5
    //   1138: iconst_1
    //   1139: iadd
    //   1140: istore #5
    //   1142: goto -> 1003
    //   1145: aload_0
    //   1146: aload_0
    //   1147: getfield p : I
    //   1150: iconst_1
    //   1151: invokevirtual T : (IZ)V
    //   1154: new java/util/HashSet
    //   1157: dup
    //   1158: invokespecial <init> : ()V
    //   1161: astore #12
    //   1163: iload_3
    //   1164: istore #5
    //   1166: iload #5
    //   1168: iload #4
    //   1170: if_icmpge -> 1259
    //   1173: aload_1
    //   1174: iload #5
    //   1176: invokevirtual get : (I)Ljava/lang/Object;
    //   1179: checkcast androidx/fragment/app/b
    //   1182: getfield a : Ljava/util/ArrayList;
    //   1185: invokevirtual iterator : ()Ljava/util/Iterator;
    //   1188: astore #13
    //   1190: aload #13
    //   1192: invokeinterface hasNext : ()Z
    //   1197: ifeq -> 1250
    //   1200: aload #13
    //   1202: invokeinterface next : ()Ljava/lang/Object;
    //   1207: checkcast androidx/fragment/app/l0$a
    //   1210: getfield b : Landroidx/fragment/app/o;
    //   1213: astore #14
    //   1215: aload #14
    //   1217: ifnull -> 1190
    //   1220: aload #14
    //   1222: getfield K : Landroid/view/ViewGroup;
    //   1225: astore #14
    //   1227: aload #14
    //   1229: ifnull -> 1190
    //   1232: aload #12
    //   1234: aload #14
    //   1236: aload_0
    //   1237: invokevirtual M : ()Landroidx/fragment/app/f1;
    //   1240: invokestatic g : (Landroid/view/ViewGroup;Landroidx/fragment/app/f1;)Landroidx/fragment/app/b1;
    //   1243: invokevirtual add : (Ljava/lang/Object;)Z
    //   1246: pop
    //   1247: goto -> 1190
    //   1250: iload #5
    //   1252: iconst_1
    //   1253: iadd
    //   1254: istore #5
    //   1256: goto -> 1166
    //   1259: aload #12
    //   1261: invokevirtual iterator : ()Ljava/util/Iterator;
    //   1264: astore #12
    //   1266: aload #12
    //   1268: invokeinterface hasNext : ()Z
    //   1273: ifeq -> 1308
    //   1276: aload #12
    //   1278: invokeinterface next : ()Ljava/lang/Object;
    //   1283: checkcast androidx/fragment/app/b1
    //   1286: astore #13
    //   1288: aload #13
    //   1290: iload #11
    //   1292: putfield d : Z
    //   1295: aload #13
    //   1297: invokevirtual h : ()V
    //   1300: aload #13
    //   1302: invokevirtual c : ()V
    //   1305: goto -> 1266
    //   1308: iload_3
    //   1309: iload #4
    //   1311: if_icmpge -> 1368
    //   1314: aload_1
    //   1315: iload_3
    //   1316: invokevirtual get : (I)Ljava/lang/Object;
    //   1319: checkcast androidx/fragment/app/b
    //   1322: astore #12
    //   1324: aload_2
    //   1325: iload_3
    //   1326: invokevirtual get : (I)Ljava/lang/Object;
    //   1329: checkcast java/lang/Boolean
    //   1332: invokevirtual booleanValue : ()Z
    //   1335: ifeq -> 1355
    //   1338: aload #12
    //   1340: getfield r : I
    //   1343: iflt -> 1355
    //   1346: aload #12
    //   1348: iconst_m1
    //   1349: putfield r : I
    //   1352: goto -> 1355
    //   1355: aload #12
    //   1357: invokestatic requireNonNull : (Ljava/lang/Object;)Ljava/lang/Object;
    //   1360: pop
    //   1361: iload_3
    //   1362: iconst_1
    //   1363: iadd
    //   1364: istore_3
    //   1365: goto -> 1308
    //   1368: return
  }
  
  public final void F(ArrayList<b> paramArrayList, ArrayList<Boolean> paramArrayList1) {
    // Byte code:
    //   0: aload_0
    //   1: getfield I : Ljava/util/ArrayList;
    //   4: astore #7
    //   6: aload #7
    //   8: ifnonnull -> 17
    //   11: iconst_0
    //   12: istore #4
    //   14: goto -> 24
    //   17: aload #7
    //   19: invokevirtual size : ()I
    //   22: istore #4
    //   24: iconst_0
    //   25: istore_3
    //   26: iload #4
    //   28: istore #6
    //   30: iload_3
    //   31: iload #6
    //   33: if_icmpge -> 286
    //   36: aload_0
    //   37: getfield I : Ljava/util/ArrayList;
    //   40: iload_3
    //   41: invokevirtual get : (I)Ljava/lang/Object;
    //   44: checkcast androidx/fragment/app/d0$n
    //   47: astore #7
    //   49: aload_1
    //   50: ifnull -> 120
    //   53: aload #7
    //   55: getfield a : Z
    //   58: ifne -> 120
    //   61: aload_1
    //   62: aload #7
    //   64: getfield b : Landroidx/fragment/app/b;
    //   67: invokevirtual indexOf : (Ljava/lang/Object;)I
    //   70: istore #4
    //   72: iload #4
    //   74: iconst_m1
    //   75: if_icmpeq -> 120
    //   78: aload_2
    //   79: ifnull -> 120
    //   82: aload_2
    //   83: iload #4
    //   85: invokevirtual get : (I)Ljava/lang/Object;
    //   88: checkcast java/lang/Boolean
    //   91: invokevirtual booleanValue : ()Z
    //   94: ifeq -> 120
    //   97: aload_0
    //   98: getfield I : Ljava/util/ArrayList;
    //   101: iload_3
    //   102: invokevirtual remove : (I)Ljava/lang/Object;
    //   105: pop
    //   106: iload_3
    //   107: iconst_1
    //   108: isub
    //   109: istore #5
    //   111: iload #6
    //   113: iconst_1
    //   114: isub
    //   115: istore #4
    //   117: goto -> 242
    //   120: aload #7
    //   122: getfield c : I
    //   125: ifne -> 134
    //   128: iconst_1
    //   129: istore #4
    //   131: goto -> 137
    //   134: iconst_0
    //   135: istore #4
    //   137: iload #4
    //   139: ifne -> 177
    //   142: iload #6
    //   144: istore #4
    //   146: iload_3
    //   147: istore #5
    //   149: aload_1
    //   150: ifnull -> 274
    //   153: iload #6
    //   155: istore #4
    //   157: iload_3
    //   158: istore #5
    //   160: aload #7
    //   162: getfield b : Landroidx/fragment/app/b;
    //   165: aload_1
    //   166: iconst_0
    //   167: aload_1
    //   168: invokevirtual size : ()I
    //   171: invokevirtual m : (Ljava/util/ArrayList;II)Z
    //   174: ifeq -> 274
    //   177: aload_0
    //   178: getfield I : Ljava/util/ArrayList;
    //   181: iload_3
    //   182: invokevirtual remove : (I)Ljava/lang/Object;
    //   185: pop
    //   186: iload_3
    //   187: iconst_1
    //   188: isub
    //   189: istore #5
    //   191: iload #6
    //   193: iconst_1
    //   194: isub
    //   195: istore #4
    //   197: aload_1
    //   198: ifnull -> 269
    //   201: aload #7
    //   203: getfield a : Z
    //   206: ifne -> 269
    //   209: aload_1
    //   210: aload #7
    //   212: getfield b : Landroidx/fragment/app/b;
    //   215: invokevirtual indexOf : (Ljava/lang/Object;)I
    //   218: istore_3
    //   219: iload_3
    //   220: iconst_m1
    //   221: if_icmpeq -> 269
    //   224: aload_2
    //   225: ifnull -> 269
    //   228: aload_2
    //   229: iload_3
    //   230: invokevirtual get : (I)Ljava/lang/Object;
    //   233: checkcast java/lang/Boolean
    //   236: invokevirtual booleanValue : ()Z
    //   239: ifeq -> 269
    //   242: aload #7
    //   244: getfield b : Landroidx/fragment/app/b;
    //   247: astore #8
    //   249: aload #8
    //   251: getfield p : Landroidx/fragment/app/d0;
    //   254: aload #8
    //   256: aload #7
    //   258: getfield a : Z
    //   261: iconst_0
    //   262: iconst_0
    //   263: invokevirtual g : (Landroidx/fragment/app/b;ZZZ)V
    //   266: goto -> 274
    //   269: aload #7
    //   271: invokevirtual a : ()V
    //   274: iload #5
    //   276: iconst_1
    //   277: iadd
    //   278: istore_3
    //   279: iload #4
    //   281: istore #6
    //   283: goto -> 30
    //   286: return
  }
  
  public o G(String paramString) {
    return this.c.d(paramString);
  }
  
  public o H(int paramInt) {
    k0 k01 = this.c;
    int i = k01.a.size();
    while (true) {
      int j = i - 1;
      if (j >= 0) {
        o o1 = k01.a.get(j);
        i = j;
        if (o1 != null) {
          i = j;
          if (o1.C == paramInt)
            return o1; 
        } 
        continue;
      } 
      for (j0 j0 : k01.b.values()) {
        if (j0 != null) {
          o o1 = j0.c;
          if (o1.C == paramInt)
            return o1; 
        } 
      } 
      return null;
    } 
  }
  
  public o I(String paramString) {
    k0 k01 = this.c;
    Objects.requireNonNull(k01);
    int i = k01.a.size();
    while (true) {
      int j = i - 1;
      if (j >= 0) {
        o o1 = k01.a.get(j);
        i = j;
        if (o1 != null) {
          i = j;
          if (paramString.equals(o1.E))
            return o1; 
        } 
        continue;
      } 
      for (j0 j0 : k01.b.values()) {
        if (j0 != null) {
          o o1 = j0.c;
          if (paramString.equals(o1.E))
            return o1; 
        } 
      } 
      return null;
    } 
  }
  
  public final ViewGroup J(o paramo) {
    ViewGroup viewGroup = paramo.K;
    if (viewGroup != null)
      return viewGroup; 
    if (paramo.D <= 0)
      return null; 
    if (this.r.f()) {
      View view = this.r.e(paramo.D);
      if (view instanceof ViewGroup)
        return (ViewGroup)view; 
    } 
    return null;
  }
  
  public z K() {
    o o1 = this.s;
    return (o1 != null) ? o1.y.K() : this.u;
  }
  
  public List<o> L() {
    return this.c.i();
  }
  
  public f1 M() {
    o o1 = this.s;
    return (o1 != null) ? o1.y.M() : this.v;
  }
  
  public void N(o paramo) {
    if (O(2)) {
      StringBuilder stringBuilder = new StringBuilder();
      stringBuilder.append("hide: ");
      stringBuilder.append(paramo);
      Log.v("FragmentManager", stringBuilder.toString());
    } 
    if (!paramo.F) {
      paramo.F = true;
      paramo.P = true ^ paramo.P;
      g0(paramo);
    } 
  }
  
  public final boolean P(o paramo) {
    boolean bool2;
    d0 d01 = paramo.A;
    Iterator<o> iterator = ((ArrayList)d01.c.g()).iterator();
    boolean bool3 = false;
    boolean bool1 = false;
    while (true) {
      bool2 = bool3;
      if (iterator.hasNext()) {
        o o1 = iterator.next();
        bool2 = bool1;
        if (o1 != null)
          bool2 = d01.P(o1); 
        bool1 = bool2;
        if (bool2) {
          bool2 = true;
          break;
        } 
        continue;
      } 
      break;
    } 
    return bool2;
  }
  
  public boolean Q(o paramo) {
    null = true;
    if (paramo == null)
      return true; 
    if (paramo.I) {
      d0 d01 = paramo.y;
      if (d01 != null) {
        if (d01.Q(paramo.B))
          return true; 
      } else {
        return null;
      } 
    } 
    return false;
  }
  
  public boolean R(o paramo) {
    if (paramo == null)
      return true; 
    d0 d01 = paramo.y;
    return (paramo.equals(d01.t) && R(d01.s));
  }
  
  public boolean S() {
    return (this.B || this.C);
  }
  
  public void T(int paramInt, boolean paramBoolean) {
    if (this.q != null || paramInt == -1) {
      if (!paramBoolean && paramInt == this.p)
        return; 
      this.p = paramInt;
      k0 k01 = this.c;
      for (o o1 : k01.a) {
        j0 j0 = k01.b.get(o1.l);
        if (j0 != null)
          j0.k(); 
      } 
      Iterator<j0> iterator = k01.b.values().iterator();
      while (true) {
        paramBoolean = iterator.hasNext();
        boolean bool = false;
        if (paramBoolean) {
          j0 j0 = iterator.next();
          if (j0 != null) {
            j0.k();
            o o1 = j0.c;
            paramInt = bool;
            if (o1.s) {
              paramInt = bool;
              if (!o1.B())
                paramInt = 1; 
            } 
            if (paramInt != 0)
              k01.k(j0); 
          } 
          continue;
        } 
        i0();
        if (this.A) {
          a0<?> a01 = this.q;
          if (a01 != null && this.p == 7) {
            a01.l();
            this.A = false;
          } 
        } 
        return;
      } 
    } 
    throw new IllegalStateException("No activity");
  }
  
  public void U(o paramo, int paramInt) {
    // Byte code:
    //   0: aload_0
    //   1: getfield c : Landroidx/fragment/app/k0;
    //   4: aload_1
    //   5: getfield l : Ljava/lang/String;
    //   8: invokevirtual h : (Ljava/lang/String;)Landroidx/fragment/app/j0;
    //   11: astore #6
    //   13: aload #6
    //   15: astore #5
    //   17: aload #6
    //   19: ifnonnull -> 46
    //   22: new androidx/fragment/app/j0
    //   25: dup
    //   26: aload_0
    //   27: getfield n : Landroidx/fragment/app/c0;
    //   30: aload_0
    //   31: getfield c : Landroidx/fragment/app/k0;
    //   34: aload_1
    //   35: invokespecial <init> : (Landroidx/fragment/app/c0;Landroidx/fragment/app/k0;Landroidx/fragment/app/o;)V
    //   38: astore #5
    //   40: aload #5
    //   42: iconst_1
    //   43: putfield e : I
    //   46: aload_1
    //   47: getfield t : Z
    //   50: ifeq -> 77
    //   53: aload_1
    //   54: getfield u : Z
    //   57: ifeq -> 77
    //   60: aload_1
    //   61: getfield h : I
    //   64: iconst_2
    //   65: if_icmpne -> 77
    //   68: iload_2
    //   69: iconst_2
    //   70: invokestatic max : (II)I
    //   73: istore_2
    //   74: goto -> 77
    //   77: iload_2
    //   78: aload #5
    //   80: invokevirtual d : ()I
    //   83: invokestatic min : (II)I
    //   86: istore_2
    //   87: aload_1
    //   88: getfield h : I
    //   91: istore #4
    //   93: iload #4
    //   95: iload_2
    //   96: if_icmpgt -> 237
    //   99: iload #4
    //   101: iload_2
    //   102: if_icmpge -> 122
    //   105: aload_0
    //   106: getfield l : Ljava/util/Map;
    //   109: invokeinterface isEmpty : ()Z
    //   114: ifne -> 122
    //   117: aload_0
    //   118: aload_1
    //   119: invokevirtual d : (Landroidx/fragment/app/o;)V
    //   122: aload_1
    //   123: getfield h : I
    //   126: istore_3
    //   127: iload_3
    //   128: iconst_m1
    //   129: if_icmpeq -> 161
    //   132: iload_3
    //   133: ifeq -> 171
    //   136: iload_3
    //   137: iconst_1
    //   138: if_icmpeq -> 180
    //   141: iload_3
    //   142: iconst_2
    //   143: if_icmpeq -> 200
    //   146: iload_3
    //   147: iconst_4
    //   148: if_icmpeq -> 210
    //   151: iload_3
    //   152: iconst_5
    //   153: if_icmpeq -> 220
    //   156: iload_2
    //   157: istore_3
    //   158: goto -> 840
    //   161: iload_2
    //   162: iconst_m1
    //   163: if_icmple -> 171
    //   166: aload #5
    //   168: invokevirtual c : ()V
    //   171: iload_2
    //   172: ifle -> 180
    //   175: aload #5
    //   177: invokevirtual e : ()V
    //   180: iload_2
    //   181: iconst_m1
    //   182: if_icmple -> 190
    //   185: aload #5
    //   187: invokevirtual j : ()V
    //   190: iload_2
    //   191: iconst_1
    //   192: if_icmple -> 200
    //   195: aload #5
    //   197: invokevirtual f : ()V
    //   200: iload_2
    //   201: iconst_2
    //   202: if_icmple -> 210
    //   205: aload #5
    //   207: invokevirtual a : ()V
    //   210: iload_2
    //   211: iconst_4
    //   212: if_icmple -> 220
    //   215: aload #5
    //   217: invokevirtual p : ()V
    //   220: iload_2
    //   221: istore_3
    //   222: iload_2
    //   223: iconst_5
    //   224: if_icmple -> 840
    //   227: aload #5
    //   229: invokevirtual n : ()V
    //   232: iload_2
    //   233: istore_3
    //   234: goto -> 840
    //   237: iload_2
    //   238: istore_3
    //   239: iload #4
    //   241: iload_2
    //   242: if_icmple -> 840
    //   245: iload #4
    //   247: ifeq -> 829
    //   250: iload #4
    //   252: iconst_1
    //   253: if_icmpeq -> 801
    //   256: iload #4
    //   258: iconst_2
    //   259: if_icmpeq -> 385
    //   262: iload #4
    //   264: iconst_4
    //   265: if_icmpeq -> 307
    //   268: iload #4
    //   270: iconst_5
    //   271: if_icmpeq -> 297
    //   274: iload #4
    //   276: bipush #7
    //   278: if_icmpeq -> 286
    //   281: iload_2
    //   282: istore_3
    //   283: goto -> 840
    //   286: iload_2
    //   287: bipush #7
    //   289: if_icmpge -> 297
    //   292: aload #5
    //   294: invokevirtual l : ()V
    //   297: iload_2
    //   298: iconst_5
    //   299: if_icmpge -> 307
    //   302: aload #5
    //   304: invokevirtual q : ()V
    //   307: iload_2
    //   308: iconst_4
    //   309: if_icmpge -> 385
    //   312: iconst_3
    //   313: invokestatic O : (I)Z
    //   316: ifeq -> 355
    //   319: new java/lang/StringBuilder
    //   322: dup
    //   323: invokespecial <init> : ()V
    //   326: astore #6
    //   328: aload #6
    //   330: ldc_w 'movefrom ACTIVITY_CREATED: '
    //   333: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   336: pop
    //   337: aload #6
    //   339: aload_1
    //   340: invokevirtual append : (Ljava/lang/Object;)Ljava/lang/StringBuilder;
    //   343: pop
    //   344: ldc 'FragmentManager'
    //   346: aload #6
    //   348: invokevirtual toString : ()Ljava/lang/String;
    //   351: invokestatic d : (Ljava/lang/String;Ljava/lang/String;)I
    //   354: pop
    //   355: aload_1
    //   356: getfield L : Landroid/view/View;
    //   359: ifnull -> 385
    //   362: aload_0
    //   363: getfield q : Landroidx/fragment/app/a0;
    //   366: aload_1
    //   367: invokevirtual k : (Landroidx/fragment/app/o;)Z
    //   370: ifeq -> 385
    //   373: aload_1
    //   374: getfield j : Landroid/util/SparseArray;
    //   377: ifnonnull -> 385
    //   380: aload #5
    //   382: invokevirtual o : ()V
    //   385: iload_2
    //   386: iconst_2
    //   387: if_icmpge -> 801
    //   390: aconst_null
    //   391: astore #7
    //   393: aload_1
    //   394: getfield L : Landroid/view/View;
    //   397: astore #6
    //   399: aload #6
    //   401: ifnull -> 783
    //   404: aload_1
    //   405: getfield K : Landroid/view/ViewGroup;
    //   408: astore #8
    //   410: aload #8
    //   412: ifnull -> 783
    //   415: aload #8
    //   417: aload #6
    //   419: invokevirtual endViewTransition : (Landroid/view/View;)V
    //   422: aload_1
    //   423: getfield L : Landroid/view/View;
    //   426: invokevirtual clearAnimation : ()V
    //   429: aload_1
    //   430: invokevirtual D : ()Z
    //   433: ifne -> 783
    //   436: aload #7
    //   438: astore #6
    //   440: aload_0
    //   441: getfield p : I
    //   444: iconst_m1
    //   445: if_icmple -> 504
    //   448: aload #7
    //   450: astore #6
    //   452: aload_0
    //   453: getfield D : Z
    //   456: ifne -> 504
    //   459: aload #7
    //   461: astore #6
    //   463: aload_1
    //   464: getfield L : Landroid/view/View;
    //   467: invokevirtual getVisibility : ()I
    //   470: ifne -> 504
    //   473: aload #7
    //   475: astore #6
    //   477: aload_1
    //   478: getfield Q : F
    //   481: fconst_0
    //   482: fcmpl
    //   483: iflt -> 504
    //   486: aload_0
    //   487: getfield q : Landroidx/fragment/app/a0;
    //   490: getfield i : Landroid/content/Context;
    //   493: aload_1
    //   494: iconst_0
    //   495: aload_1
    //   496: invokevirtual s : ()Z
    //   499: invokestatic a : (Landroid/content/Context;Landroidx/fragment/app/o;ZZ)Landroidx/fragment/app/v$a;
    //   502: astore #6
    //   504: aload_1
    //   505: fconst_0
    //   506: putfield Q : F
    //   509: aload_1
    //   510: getfield K : Landroid/view/ViewGroup;
    //   513: astore #7
    //   515: aload_1
    //   516: getfield L : Landroid/view/View;
    //   519: astore #8
    //   521: aload #6
    //   523: ifnull -> 689
    //   526: aload_0
    //   527: getfield m : Landroidx/fragment/app/s0$a;
    //   530: astore #10
    //   532: aload #7
    //   534: aload #8
    //   536: invokevirtual startViewTransition : (Landroid/view/View;)V
    //   539: new g0/b
    //   542: dup
    //   543: invokespecial <init> : ()V
    //   546: astore #9
    //   548: aload #9
    //   550: new androidx/fragment/app/s
    //   553: dup
    //   554: aload_1
    //   555: invokespecial <init> : (Landroidx/fragment/app/o;)V
    //   558: invokevirtual b : (Lg0/b$a;)V
    //   561: aload #10
    //   563: checkcast androidx/fragment/app/d0$d
    //   566: astore #10
    //   568: aload #10
    //   570: aload_1
    //   571: aload #9
    //   573: invokevirtual b : (Landroidx/fragment/app/o;Lg0/b;)V
    //   576: aload #6
    //   578: getfield a : Landroid/view/animation/Animation;
    //   581: ifnull -> 641
    //   584: new androidx/fragment/app/v$b
    //   587: dup
    //   588: aload #6
    //   590: getfield a : Landroid/view/animation/Animation;
    //   593: aload #7
    //   595: aload #8
    //   597: invokespecial <init> : (Landroid/view/animation/Animation;Landroid/view/ViewGroup;Landroid/view/View;)V
    //   600: astore #6
    //   602: aload_1
    //   603: aload_1
    //   604: getfield L : Landroid/view/View;
    //   607: invokevirtual Z : (Landroid/view/View;)V
    //   610: aload #6
    //   612: new androidx/fragment/app/t
    //   615: dup
    //   616: aload #7
    //   618: aload_1
    //   619: aload #10
    //   621: aload #9
    //   623: invokespecial <init> : (Landroid/view/ViewGroup;Landroidx/fragment/app/o;Landroidx/fragment/app/s0$a;Lg0/b;)V
    //   626: invokevirtual setAnimationListener : (Landroid/view/animation/Animation$AnimationListener;)V
    //   629: aload_1
    //   630: getfield L : Landroid/view/View;
    //   633: aload #6
    //   635: invokevirtual startAnimation : (Landroid/view/animation/Animation;)V
    //   638: goto -> 689
    //   641: aload #6
    //   643: getfield b : Landroid/animation/Animator;
    //   646: astore #6
    //   648: aload_1
    //   649: aload #6
    //   651: invokevirtual b0 : (Landroid/animation/Animator;)V
    //   654: aload #6
    //   656: new androidx/fragment/app/u
    //   659: dup
    //   660: aload #7
    //   662: aload #8
    //   664: aload_1
    //   665: aload #10
    //   667: aload #9
    //   669: invokespecial <init> : (Landroid/view/ViewGroup;Landroid/view/View;Landroidx/fragment/app/o;Landroidx/fragment/app/s0$a;Lg0/b;)V
    //   672: invokevirtual addListener : (Landroid/animation/Animator$AnimatorListener;)V
    //   675: aload #6
    //   677: aload_1
    //   678: getfield L : Landroid/view/View;
    //   681: invokevirtual setTarget : (Ljava/lang/Object;)V
    //   684: aload #6
    //   686: invokevirtual start : ()V
    //   689: aload #7
    //   691: aload #8
    //   693: invokevirtual removeView : (Landroid/view/View;)V
    //   696: iconst_2
    //   697: invokestatic O : (I)Z
    //   700: ifeq -> 773
    //   703: new java/lang/StringBuilder
    //   706: dup
    //   707: invokespecial <init> : ()V
    //   710: astore #6
    //   712: aload #6
    //   714: ldc_w 'Removing view '
    //   717: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   720: pop
    //   721: aload #6
    //   723: aload #8
    //   725: invokevirtual append : (Ljava/lang/Object;)Ljava/lang/StringBuilder;
    //   728: pop
    //   729: aload #6
    //   731: ldc_w ' for fragment '
    //   734: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   737: pop
    //   738: aload #6
    //   740: aload_1
    //   741: invokevirtual append : (Ljava/lang/Object;)Ljava/lang/StringBuilder;
    //   744: pop
    //   745: aload #6
    //   747: ldc_w ' from container '
    //   750: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   753: pop
    //   754: aload #6
    //   756: aload #7
    //   758: invokevirtual append : (Ljava/lang/Object;)Ljava/lang/StringBuilder;
    //   761: pop
    //   762: ldc 'FragmentManager'
    //   764: aload #6
    //   766: invokevirtual toString : ()Ljava/lang/String;
    //   769: invokestatic v : (Ljava/lang/String;Ljava/lang/String;)I
    //   772: pop
    //   773: aload #7
    //   775: aload_1
    //   776: getfield K : Landroid/view/ViewGroup;
    //   779: if_acmpeq -> 783
    //   782: return
    //   783: aload_0
    //   784: getfield l : Ljava/util/Map;
    //   787: aload_1
    //   788: invokeinterface get : (Ljava/lang/Object;)Ljava/lang/Object;
    //   793: ifnonnull -> 801
    //   796: aload #5
    //   798: invokevirtual h : ()V
    //   801: iload_2
    //   802: iconst_1
    //   803: if_icmpge -> 829
    //   806: aload_0
    //   807: getfield l : Ljava/util/Map;
    //   810: aload_1
    //   811: invokeinterface get : (Ljava/lang/Object;)Ljava/lang/Object;
    //   816: ifnull -> 824
    //   819: iconst_1
    //   820: istore_2
    //   821: goto -> 829
    //   824: aload #5
    //   826: invokevirtual g : ()V
    //   829: iload_2
    //   830: ifge -> 838
    //   833: aload #5
    //   835: invokevirtual i : ()V
    //   838: iload_2
    //   839: istore_3
    //   840: aload_1
    //   841: getfield h : I
    //   844: iload_3
    //   845: if_icmpeq -> 931
    //   848: iconst_3
    //   849: invokestatic O : (I)Z
    //   852: ifeq -> 926
    //   855: new java/lang/StringBuilder
    //   858: dup
    //   859: invokespecial <init> : ()V
    //   862: astore #5
    //   864: aload #5
    //   866: ldc_w 'moveToState: Fragment state for '
    //   869: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   872: pop
    //   873: aload #5
    //   875: aload_1
    //   876: invokevirtual append : (Ljava/lang/Object;)Ljava/lang/StringBuilder;
    //   879: pop
    //   880: aload #5
    //   882: ldc_w ' not updated inline; expected state '
    //   885: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   888: pop
    //   889: aload #5
    //   891: iload_3
    //   892: invokevirtual append : (I)Ljava/lang/StringBuilder;
    //   895: pop
    //   896: aload #5
    //   898: ldc_w ' found '
    //   901: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   904: pop
    //   905: aload #5
    //   907: aload_1
    //   908: getfield h : I
    //   911: invokevirtual append : (I)Ljava/lang/StringBuilder;
    //   914: pop
    //   915: ldc 'FragmentManager'
    //   917: aload #5
    //   919: invokevirtual toString : ()Ljava/lang/String;
    //   922: invokestatic d : (Ljava/lang/String;Ljava/lang/String;)I
    //   925: pop
    //   926: aload_1
    //   927: iload_3
    //   928: putfield h : I
    //   931: return
  }
  
  public void V() {
    if (this.q == null)
      return; 
    this.B = false;
    this.C = false;
    this.J.g = false;
    for (o o1 : this.c.i()) {
      if (o1 != null)
        o1.A.V(); 
    } 
  }
  
  public boolean W() {
    C(false);
    B(true);
    o o1 = this.t;
    if (o1 != null && o1.h().W())
      return true; 
    boolean bool = X(this.F, this.G, null, -1, 0);
    if (bool) {
      this.b = true;
      try {
        Z(this.F, this.G);
      } finally {
        e();
      } 
    } 
    j0();
    x();
    this.c.b();
    return bool;
  }
  
  public boolean X(ArrayList<b> paramArrayList, ArrayList<Boolean> paramArrayList1, String paramString, int paramInt1, int paramInt2) {
    // Byte code:
    //   0: aload_0
    //   1: getfield d : Ljava/util/ArrayList;
    //   4: astore #8
    //   6: aload #8
    //   8: ifnonnull -> 13
    //   11: iconst_0
    //   12: ireturn
    //   13: aload_3
    //   14: ifnonnull -> 69
    //   17: iload #4
    //   19: ifge -> 69
    //   22: iload #5
    //   24: iconst_1
    //   25: iand
    //   26: ifne -> 69
    //   29: aload #8
    //   31: invokevirtual size : ()I
    //   34: iconst_1
    //   35: isub
    //   36: istore #4
    //   38: iload #4
    //   40: ifge -> 45
    //   43: iconst_0
    //   44: ireturn
    //   45: aload_1
    //   46: aload_0
    //   47: getfield d : Ljava/util/ArrayList;
    //   50: iload #4
    //   52: invokevirtual remove : (I)Ljava/lang/Object;
    //   55: invokevirtual add : (Ljava/lang/Object;)Z
    //   58: pop
    //   59: aload_2
    //   60: getstatic java/lang/Boolean.TRUE : Ljava/lang/Boolean;
    //   63: invokevirtual add : (Ljava/lang/Object;)Z
    //   66: pop
    //   67: iconst_1
    //   68: ireturn
    //   69: iconst_m1
    //   70: istore #6
    //   72: aload_3
    //   73: ifnonnull -> 81
    //   76: iload #4
    //   78: iflt -> 256
    //   81: aload #8
    //   83: invokevirtual size : ()I
    //   86: iconst_1
    //   87: isub
    //   88: istore #6
    //   90: iload #6
    //   92: iflt -> 155
    //   95: aload_0
    //   96: getfield d : Ljava/util/ArrayList;
    //   99: iload #6
    //   101: invokevirtual get : (I)Ljava/lang/Object;
    //   104: checkcast androidx/fragment/app/b
    //   107: astore #8
    //   109: aload_3
    //   110: ifnull -> 128
    //   113: aload_3
    //   114: aload #8
    //   116: getfield h : Ljava/lang/String;
    //   119: invokevirtual equals : (Ljava/lang/Object;)Z
    //   122: ifeq -> 128
    //   125: goto -> 155
    //   128: iload #4
    //   130: iflt -> 146
    //   133: iload #4
    //   135: aload #8
    //   137: getfield r : I
    //   140: if_icmpne -> 146
    //   143: goto -> 155
    //   146: iload #6
    //   148: iconst_1
    //   149: isub
    //   150: istore #6
    //   152: goto -> 90
    //   155: iload #6
    //   157: ifge -> 162
    //   160: iconst_0
    //   161: ireturn
    //   162: iload #6
    //   164: istore #7
    //   166: iload #5
    //   168: iconst_1
    //   169: iand
    //   170: ifeq -> 252
    //   173: iload #6
    //   175: iconst_1
    //   176: isub
    //   177: istore #5
    //   179: iload #5
    //   181: istore #7
    //   183: iload #5
    //   185: iflt -> 252
    //   188: aload_0
    //   189: getfield d : Ljava/util/ArrayList;
    //   192: iload #5
    //   194: invokevirtual get : (I)Ljava/lang/Object;
    //   197: checkcast androidx/fragment/app/b
    //   200: astore #8
    //   202: aload_3
    //   203: ifnull -> 222
    //   206: iload #5
    //   208: istore #6
    //   210: aload_3
    //   211: aload #8
    //   213: getfield h : Ljava/lang/String;
    //   216: invokevirtual equals : (Ljava/lang/Object;)Z
    //   219: ifne -> 173
    //   222: iload #5
    //   224: istore #7
    //   226: iload #4
    //   228: iflt -> 252
    //   231: iload #5
    //   233: istore #7
    //   235: iload #4
    //   237: aload #8
    //   239: getfield r : I
    //   242: if_icmpne -> 252
    //   245: iload #5
    //   247: istore #6
    //   249: goto -> 173
    //   252: iload #7
    //   254: istore #6
    //   256: iload #6
    //   258: aload_0
    //   259: getfield d : Ljava/util/ArrayList;
    //   262: invokevirtual size : ()I
    //   265: iconst_1
    //   266: isub
    //   267: if_icmpne -> 272
    //   270: iconst_0
    //   271: ireturn
    //   272: aload_0
    //   273: getfield d : Ljava/util/ArrayList;
    //   276: invokevirtual size : ()I
    //   279: iconst_1
    //   280: isub
    //   281: istore #4
    //   283: iload #4
    //   285: iload #6
    //   287: if_icmple -> 321
    //   290: aload_1
    //   291: aload_0
    //   292: getfield d : Ljava/util/ArrayList;
    //   295: iload #4
    //   297: invokevirtual remove : (I)Ljava/lang/Object;
    //   300: invokevirtual add : (Ljava/lang/Object;)Z
    //   303: pop
    //   304: aload_2
    //   305: getstatic java/lang/Boolean.TRUE : Ljava/lang/Boolean;
    //   308: invokevirtual add : (Ljava/lang/Object;)Z
    //   311: pop
    //   312: iload #4
    //   314: iconst_1
    //   315: isub
    //   316: istore #4
    //   318: goto -> 283
    //   321: iconst_1
    //   322: ireturn
  }
  
  public void Y(o paramo) {
    if (O(2)) {
      StringBuilder stringBuilder = new StringBuilder();
      stringBuilder.append("remove: ");
      stringBuilder.append(paramo);
      stringBuilder.append(" nesting=");
      stringBuilder.append(paramo.x);
      Log.v("FragmentManager", stringBuilder.toString());
    } 
    boolean bool = paramo.B();
    if (!paramo.G || (bool ^ true) != 0) {
      this.c.l(paramo);
      if (P(paramo))
        this.A = true; 
      paramo.s = true;
      g0(paramo);
    } 
  }
  
  public final void Z(ArrayList<b> paramArrayList, ArrayList<Boolean> paramArrayList1) {
    if (paramArrayList.isEmpty())
      return; 
    if (paramArrayList.size() == paramArrayList1.size()) {
      F(paramArrayList, paramArrayList1);
      int k = paramArrayList.size();
      int i = 0;
      int j;
      for (j = 0; i < k; j = m) {
        int n = i;
        int m = j;
        if (!((b)paramArrayList.get(i)).o) {
          if (j != i)
            E(paramArrayList, paramArrayList1, j, i); 
          j = i + 1;
          m = j;
          if (((Boolean)paramArrayList1.get(i)).booleanValue())
            while (true) {
              m = j;
              if (j < k) {
                m = j;
                if (((Boolean)paramArrayList1.get(j)).booleanValue()) {
                  m = j;
                  if (!((b)paramArrayList.get(j)).o) {
                    j++;
                    continue;
                  } 
                } 
              } 
              break;
            }  
          E(paramArrayList, paramArrayList1, i, m);
          n = m - 1;
        } 
        i = n + 1;
      } 
      if (j != k)
        E(paramArrayList, paramArrayList1, j, k); 
      return;
    } 
    throw new IllegalStateException("Internal error with the back stack records");
  }
  
  public j0 a(o paramo) {
    if (O(2)) {
      StringBuilder stringBuilder = new StringBuilder();
      stringBuilder.append("add: ");
      stringBuilder.append(paramo);
      Log.v("FragmentManager", stringBuilder.toString());
    } 
    j0 j0 = h(paramo);
    paramo.y = this;
    this.c.j(j0);
    if (!paramo.G) {
      this.c.a(paramo);
      paramo.s = false;
      if (paramo.L == null)
        paramo.P = false; 
      if (P(paramo))
        this.A = true; 
    } 
    return j0;
  }
  
  public void a0(Parcelable paramParcelable) {
    if (paramParcelable == null)
      return; 
    f0 f0 = (f0)paramParcelable;
    if (f0.h == null)
      return; 
    this.c.b.clear();
    for (Parcelable paramParcelable : f0.h) {
      if (paramParcelable != null) {
        j0 j0;
        g0 g02 = this.J;
        String str1 = ((i0)paramParcelable).i;
        o o1 = g02.b.get(str1);
        if (o1 != null) {
          if (O(2)) {
            StringBuilder stringBuilder = new StringBuilder();
            stringBuilder.append("restoreSaveState: re-attaching retained ");
            stringBuilder.append(o1);
            Log.v("FragmentManager", stringBuilder.toString());
          } 
          j0 = new j0(this.n, this.c, o1, (i0)paramParcelable);
        } else {
          j0 = new j0(this.n, this.c, this.q.i.getClassLoader(), K(), (i0)j0);
        } 
        o1 = j0.c;
        o1.y = this;
        if (O(2)) {
          StringBuilder stringBuilder = android.support.v4.media.c.a("restoreSaveState: active (");
          stringBuilder.append(o1.l);
          stringBuilder.append("): ");
          stringBuilder.append(o1);
          Log.v("FragmentManager", stringBuilder.toString());
        } 
        j0.m(this.q.i.getClassLoader());
        this.c.j(j0);
        j0.e = this.p;
      } 
    } 
    g0 g01 = this.J;
    Objects.requireNonNull(g01);
    for (o o1 : new ArrayList(g01.b.values())) {
      if (!this.c.c(o1.l)) {
        if (O(2)) {
          StringBuilder stringBuilder = new StringBuilder();
          stringBuilder.append("Discarding retained Fragment ");
          stringBuilder.append(o1);
          stringBuilder.append(" that was not found in the set of active Fragments ");
          stringBuilder.append(f0.h);
          Log.v("FragmentManager", stringBuilder.toString());
        } 
        this.J.b(o1);
        o1.y = this;
        j0 j0 = new j0(this.n, this.c, o1);
        j0.e = 1;
        j0.k();
        o1.s = true;
        j0.k();
      } 
    } 
    k0 k01 = this.c;
    ArrayList<String> arrayList2 = f0.i;
    k01.a.clear();
    if (arrayList2 != null)
      for (String str1 : arrayList2) {
        o o1 = k01.d(str1);
        if (o1 != null) {
          if (O(2)) {
            StringBuilder stringBuilder = new StringBuilder();
            stringBuilder.append("restoreSaveState: added (");
            stringBuilder.append(str1);
            stringBuilder.append("): ");
            stringBuilder.append(o1);
            Log.v("FragmentManager", stringBuilder.toString());
          } 
          k01.a(o1);
          continue;
        } 
        throw new IllegalStateException(d0.c.a("No instantiated fragment for (", str1, ")"));
      }  
    c[] arrayOfC = f0.j;
    byte b1 = 0;
    if (arrayOfC != null) {
      this.d = new ArrayList<b>(f0.j.length);
      int i = 0;
      while (true) {
        arrayOfC = f0.j;
        if (i < arrayOfC.length) {
          c c1 = arrayOfC[i];
          Objects.requireNonNull(c1);
          b b2 = new b(this);
          int k = 0;
          int j = 0;
          while (true) {
            int[] arrayOfInt = c1.h;
            if (k < arrayOfInt.length) {
              l0.a a1 = new l0.a();
              int n = k + 1;
              a1.a = arrayOfInt[k];
              if (O(2)) {
                StringBuilder stringBuilder = new StringBuilder();
                stringBuilder.append("Instantiate ");
                stringBuilder.append(b2);
                stringBuilder.append(" op #");
                stringBuilder.append(j);
                stringBuilder.append(" base fragment #");
                stringBuilder.append(c1.h[n]);
                Log.v("FragmentManager", stringBuilder.toString());
              } 
              String str1 = c1.i.get(j);
              if (str1 != null) {
                o o1 = this.c.d(str1);
              } else {
                str1 = null;
              } 
              a1.b = (o)str1;
              a1.g = androidx.lifecycle.e.c.values()[c1.j[j]];
              a1.h = androidx.lifecycle.e.c.values()[c1.k[j]];
              int[] arrayOfInt1 = c1.h;
              int m = n + 1;
              k = arrayOfInt1[n];
              a1.c = k;
              int i1 = m + 1;
              n = arrayOfInt1[m];
              a1.d = n;
              m = i1 + 1;
              i1 = arrayOfInt1[i1];
              a1.e = i1;
              int i2 = arrayOfInt1[m];
              a1.f = i2;
              b2.b = k;
              b2.c = n;
              b2.d = i1;
              b2.e = i2;
              b2.b(a1);
              j++;
              k = m + 1;
              continue;
            } 
            b2.f = c1.l;
            b2.h = c1.m;
            b2.r = c1.n;
            b2.g = true;
            b2.i = c1.o;
            b2.j = c1.p;
            b2.k = c1.q;
            b2.l = c1.r;
            b2.m = c1.s;
            b2.n = c1.t;
            b2.o = c1.u;
            b2.e(1);
            if (O(2)) {
              StringBuilder stringBuilder = new StringBuilder();
              stringBuilder.append("restoreAllState: back stack #");
              stringBuilder.append(i);
              stringBuilder.append(" (index ");
              stringBuilder.append(b2.r);
              stringBuilder.append("): ");
              stringBuilder.append(b2);
              Log.v("FragmentManager", stringBuilder.toString());
              PrintWriter printWriter = new PrintWriter(new y0("FragmentManager"));
              b2.i("  ", printWriter, false);
              printWriter.close();
            } 
            break;
          } 
          this.d.add(b2);
          i++;
          continue;
        } 
        break;
      } 
    } else {
      this.d = null;
    } 
    this.i.set(f0.k);
    String str = f0.l;
    if (str != null) {
      o o1 = G(str);
      this.t = o1;
      t(o1);
    } 
    ArrayList<String> arrayList1 = f0.m;
    if (arrayList1 != null)
      for (int i = b1; i < arrayList1.size(); i++) {
        Bundle bundle = f0.n.get(i);
        bundle.setClassLoader(this.q.i.getClassLoader());
        this.j.put(arrayList1.get(i), bundle);
      }  
    this.z = new ArrayDeque<k>(f0.o);
  }
  
  @SuppressLint({"SyntheticAccessor"})
  public void b(a0<?> parama0, w paramw, o paramo) {
    // Byte code:
    //   0: aload_0
    //   1: getfield q : Landroidx/fragment/app/a0;
    //   4: ifnonnull -> 553
    //   7: aload_0
    //   8: aload_1
    //   9: putfield q : Landroidx/fragment/app/a0;
    //   12: aload_0
    //   13: aload_2
    //   14: putfield r : Landroidx/fragment/app/w;
    //   17: aload_0
    //   18: aload_3
    //   19: putfield s : Landroidx/fragment/app/o;
    //   22: aload_3
    //   23: ifnull -> 39
    //   26: new androidx/fragment/app/d0$h
    //   29: dup
    //   30: aload_0
    //   31: aload_3
    //   32: invokespecial <init> : (Landroidx/fragment/app/d0;Landroidx/fragment/app/o;)V
    //   35: astore_2
    //   36: goto -> 51
    //   39: aload_1
    //   40: instanceof androidx/fragment/app/h0
    //   43: ifeq -> 60
    //   46: aload_1
    //   47: checkcast androidx/fragment/app/h0
    //   50: astore_2
    //   51: aload_0
    //   52: getfield o : Ljava/util/concurrent/CopyOnWriteArrayList;
    //   55: aload_2
    //   56: invokevirtual add : (Ljava/lang/Object;)Z
    //   59: pop
    //   60: aload_0
    //   61: getfield s : Landroidx/fragment/app/o;
    //   64: ifnull -> 71
    //   67: aload_0
    //   68: invokevirtual j0 : ()V
    //   71: aload_1
    //   72: instanceof androidx/activity/c
    //   75: ifeq -> 113
    //   78: aload_1
    //   79: checkcast androidx/activity/c
    //   82: astore_2
    //   83: aload_2
    //   84: invokeinterface c : ()Landroidx/activity/OnBackPressedDispatcher;
    //   89: astore #4
    //   91: aload_0
    //   92: aload #4
    //   94: putfield g : Landroidx/activity/OnBackPressedDispatcher;
    //   97: aload_3
    //   98: ifnull -> 103
    //   101: aload_3
    //   102: astore_2
    //   103: aload #4
    //   105: aload_2
    //   106: aload_0
    //   107: getfield h : Landroidx/activity/b;
    //   110: invokevirtual a : (Landroidx/lifecycle/i;Landroidx/activity/b;)V
    //   113: aload_3
    //   114: ifnull -> 183
    //   117: aload_3
    //   118: getfield y : Landroidx/fragment/app/d0;
    //   121: getfield J : Landroidx/fragment/app/g0;
    //   124: astore #4
    //   126: aload #4
    //   128: getfield c : Ljava/util/HashMap;
    //   131: aload_3
    //   132: getfield l : Ljava/lang/String;
    //   135: invokevirtual get : (Ljava/lang/Object;)Ljava/lang/Object;
    //   138: checkcast androidx/fragment/app/g0
    //   141: astore_2
    //   142: aload_2
    //   143: astore_1
    //   144: aload_2
    //   145: ifnonnull -> 175
    //   148: new androidx/fragment/app/g0
    //   151: dup
    //   152: aload #4
    //   154: getfield e : Z
    //   157: invokespecial <init> : (Z)V
    //   160: astore_1
    //   161: aload #4
    //   163: getfield c : Ljava/util/HashMap;
    //   166: aload_3
    //   167: getfield l : Ljava/lang/String;
    //   170: aload_1
    //   171: invokevirtual put : (Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    //   174: pop
    //   175: aload_0
    //   176: aload_1
    //   177: putfield J : Landroidx/fragment/app/g0;
    //   180: goto -> 369
    //   183: aload_1
    //   184: instanceof androidx/lifecycle/a0
    //   187: ifeq -> 357
    //   190: aload_1
    //   191: checkcast androidx/lifecycle/a0
    //   194: invokeinterface j : ()Landroidx/lifecycle/z;
    //   199: astore_2
    //   200: getstatic androidx/fragment/app/g0.h : Landroidx/lifecycle/w;
    //   203: astore #5
    //   205: ldc_w androidx/fragment/app/g0
    //   208: invokevirtual getCanonicalName : ()Ljava/lang/String;
    //   211: astore_1
    //   212: aload_1
    //   213: ifnull -> 346
    //   216: ldc_w 'androidx.lifecycle.ViewModelProvider.DefaultKey:'
    //   219: aload_1
    //   220: invokestatic a : (Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;
    //   223: astore #4
    //   225: aload_2
    //   226: getfield a : Ljava/util/HashMap;
    //   229: aload #4
    //   231: invokevirtual get : (Ljava/lang/Object;)Ljava/lang/Object;
    //   234: checkcast androidx/lifecycle/v
    //   237: astore_1
    //   238: ldc_w androidx/fragment/app/g0
    //   241: aload_1
    //   242: invokevirtual isInstance : (Ljava/lang/Object;)Z
    //   245: ifeq -> 269
    //   248: aload_1
    //   249: astore_2
    //   250: aload #5
    //   252: instanceof androidx/lifecycle/y
    //   255: ifeq -> 335
    //   258: aload #5
    //   260: checkcast androidx/lifecycle/y
    //   263: astore_2
    //   264: aload_1
    //   265: astore_2
    //   266: goto -> 335
    //   269: aload #5
    //   271: instanceof androidx/lifecycle/x
    //   274: ifeq -> 294
    //   277: aload #5
    //   279: checkcast androidx/lifecycle/x
    //   282: aload #4
    //   284: ldc_w androidx/fragment/app/g0
    //   287: invokevirtual a : (Ljava/lang/String;Ljava/lang/Class;)Landroidx/lifecycle/v;
    //   290: astore_1
    //   291: goto -> 306
    //   294: aload #5
    //   296: checkcast androidx/fragment/app/g0$a
    //   299: ldc_w androidx/fragment/app/g0
    //   302: invokevirtual a : (Ljava/lang/Class;)Landroidx/lifecycle/v;
    //   305: astore_1
    //   306: aload_2
    //   307: getfield a : Ljava/util/HashMap;
    //   310: aload #4
    //   312: aload_1
    //   313: invokevirtual put : (Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    //   316: checkcast androidx/lifecycle/v
    //   319: astore #4
    //   321: aload_1
    //   322: astore_2
    //   323: aload #4
    //   325: ifnull -> 335
    //   328: aload #4
    //   330: invokevirtual a : ()V
    //   333: aload_1
    //   334: astore_2
    //   335: aload_0
    //   336: aload_2
    //   337: checkcast androidx/fragment/app/g0
    //   340: putfield J : Landroidx/fragment/app/g0;
    //   343: goto -> 369
    //   346: new java/lang/IllegalArgumentException
    //   349: dup
    //   350: ldc_w 'Local and anonymous classes can not be ViewModels'
    //   353: invokespecial <init> : (Ljava/lang/String;)V
    //   356: athrow
    //   357: aload_0
    //   358: new androidx/fragment/app/g0
    //   361: dup
    //   362: iconst_0
    //   363: invokespecial <init> : (Z)V
    //   366: putfield J : Landroidx/fragment/app/g0;
    //   369: aload_0
    //   370: getfield J : Landroidx/fragment/app/g0;
    //   373: aload_0
    //   374: invokevirtual S : ()Z
    //   377: putfield g : Z
    //   380: aload_0
    //   381: getfield c : Landroidx/fragment/app/k0;
    //   384: aload_0
    //   385: getfield J : Landroidx/fragment/app/g0;
    //   388: putfield c : Landroidx/fragment/app/g0;
    //   391: aload_0
    //   392: getfield q : Landroidx/fragment/app/a0;
    //   395: astore_1
    //   396: aload_1
    //   397: instanceof androidx/activity/result/f
    //   400: ifeq -> 552
    //   403: aload_1
    //   404: checkcast androidx/activity/result/f
    //   407: invokeinterface h : ()Landroidx/activity/result/e;
    //   412: astore_2
    //   413: aload_3
    //   414: ifnull -> 450
    //   417: new java/lang/StringBuilder
    //   420: dup
    //   421: invokespecial <init> : ()V
    //   424: astore_1
    //   425: aload_1
    //   426: aload_3
    //   427: getfield l : Ljava/lang/String;
    //   430: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   433: pop
    //   434: aload_1
    //   435: ldc_w ':'
    //   438: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   441: pop
    //   442: aload_1
    //   443: invokevirtual toString : ()Ljava/lang/String;
    //   446: astore_1
    //   447: goto -> 454
    //   450: ldc_w ''
    //   453: astore_1
    //   454: ldc_w 'FragmentManager:'
    //   457: aload_1
    //   458: invokestatic a : (Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;
    //   461: astore_1
    //   462: aload_0
    //   463: aload_2
    //   464: aload_1
    //   465: ldc_w 'StartActivityForResult'
    //   468: invokestatic a : (Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;
    //   471: new d/c
    //   474: dup
    //   475: invokespecial <init> : ()V
    //   478: new androidx/fragment/app/d0$i
    //   481: dup
    //   482: aload_0
    //   483: invokespecial <init> : (Landroidx/fragment/app/d0;)V
    //   486: invokevirtual b : (Ljava/lang/String;Ld/a;Landroidx/activity/result/b;)Landroidx/activity/result/c;
    //   489: putfield w : Landroidx/activity/result/c;
    //   492: aload_0
    //   493: aload_2
    //   494: aload_1
    //   495: ldc_w 'StartIntentSenderForResult'
    //   498: invokestatic a : (Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;
    //   501: new androidx/fragment/app/d0$j
    //   504: dup
    //   505: invokespecial <init> : ()V
    //   508: new androidx/fragment/app/d0$a
    //   511: dup
    //   512: aload_0
    //   513: invokespecial <init> : (Landroidx/fragment/app/d0;)V
    //   516: invokevirtual b : (Ljava/lang/String;Ld/a;Landroidx/activity/result/b;)Landroidx/activity/result/c;
    //   519: putfield x : Landroidx/activity/result/c;
    //   522: aload_0
    //   523: aload_2
    //   524: aload_1
    //   525: ldc_w 'RequestPermissions'
    //   528: invokestatic a : (Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;
    //   531: new d/b
    //   534: dup
    //   535: invokespecial <init> : ()V
    //   538: new androidx/fragment/app/d0$b
    //   541: dup
    //   542: aload_0
    //   543: invokespecial <init> : (Landroidx/fragment/app/d0;)V
    //   546: invokevirtual b : (Ljava/lang/String;Ld/a;Landroidx/activity/result/b;)Landroidx/activity/result/c;
    //   549: putfield y : Landroidx/activity/result/c;
    //   552: return
    //   553: new java/lang/IllegalStateException
    //   556: dup
    //   557: ldc_w 'Already attached'
    //   560: invokespecial <init> : (Ljava/lang/String;)V
    //   563: athrow
  }
  
  public Parcelable b0() {
    // Byte code:
    //   0: aload_0
    //   1: invokevirtual f : ()Ljava/util/Set;
    //   4: checkcast java/util/HashSet
    //   7: invokevirtual iterator : ()Ljava/util/Iterator;
    //   10: astore #4
    //   12: aload #4
    //   14: invokeinterface hasNext : ()Z
    //   19: istore_3
    //   20: iconst_0
    //   21: istore_1
    //   22: iload_3
    //   23: ifeq -> 60
    //   26: aload #4
    //   28: invokeinterface next : ()Ljava/lang/Object;
    //   33: checkcast androidx/fragment/app/b1
    //   36: astore #5
    //   38: aload #5
    //   40: getfield e : Z
    //   43: ifeq -> 12
    //   46: aload #5
    //   48: iconst_0
    //   49: putfield e : Z
    //   52: aload #5
    //   54: invokevirtual c : ()V
    //   57: goto -> 12
    //   60: aload_0
    //   61: invokevirtual z : ()V
    //   64: aload_0
    //   65: iconst_1
    //   66: invokevirtual C : (Z)Z
    //   69: pop
    //   70: aload_0
    //   71: iconst_1
    //   72: putfield B : Z
    //   75: aload_0
    //   76: getfield J : Landroidx/fragment/app/g0;
    //   79: iconst_1
    //   80: putfield g : Z
    //   83: aload_0
    //   84: getfield c : Landroidx/fragment/app/k0;
    //   87: astore #4
    //   89: aload #4
    //   91: invokestatic requireNonNull : (Ljava/lang/Object;)Ljava/lang/Object;
    //   94: pop
    //   95: new java/util/ArrayList
    //   98: dup
    //   99: aload #4
    //   101: getfield b : Ljava/util/HashMap;
    //   104: invokevirtual size : ()I
    //   107: invokespecial <init> : (I)V
    //   110: astore #7
    //   112: aload #4
    //   114: getfield b : Ljava/util/HashMap;
    //   117: invokevirtual values : ()Ljava/util/Collection;
    //   120: invokeinterface iterator : ()Ljava/util/Iterator;
    //   125: astore #8
    //   127: aload #8
    //   129: invokeinterface hasNext : ()Z
    //   134: istore_3
    //   135: aconst_null
    //   136: astore #6
    //   138: aconst_null
    //   139: astore #5
    //   141: iload_3
    //   142: ifeq -> 623
    //   145: aload #8
    //   147: invokeinterface next : ()Ljava/lang/Object;
    //   152: checkcast androidx/fragment/app/j0
    //   155: astore #10
    //   157: aload #10
    //   159: ifnull -> 127
    //   162: aload #10
    //   164: getfield c : Landroidx/fragment/app/o;
    //   167: astore #6
    //   169: new androidx/fragment/app/i0
    //   172: dup
    //   173: aload #6
    //   175: invokespecial <init> : (Landroidx/fragment/app/o;)V
    //   178: astore #9
    //   180: aload #10
    //   182: getfield c : Landroidx/fragment/app/o;
    //   185: astore #4
    //   187: aload #4
    //   189: getfield h : I
    //   192: iconst_m1
    //   193: if_icmple -> 538
    //   196: aload #9
    //   198: getfield t : Landroid/os/Bundle;
    //   201: ifnonnull -> 538
    //   204: new android/os/Bundle
    //   207: dup
    //   208: invokespecial <init> : ()V
    //   211: astore #4
    //   213: aload #10
    //   215: getfield c : Landroidx/fragment/app/o;
    //   218: astore #11
    //   220: aload #11
    //   222: aload #4
    //   224: invokevirtual O : (Landroid/os/Bundle;)V
    //   227: aload #11
    //   229: getfield W : Landroidx/savedstate/b;
    //   232: aload #4
    //   234: invokevirtual b : (Landroid/os/Bundle;)V
    //   237: aload #11
    //   239: getfield A : Landroidx/fragment/app/d0;
    //   242: invokevirtual b0 : ()Landroid/os/Parcelable;
    //   245: astore #11
    //   247: aload #11
    //   249: ifnull -> 262
    //   252: aload #4
    //   254: ldc_w 'android:support:fragments'
    //   257: aload #11
    //   259: invokevirtual putParcelable : (Ljava/lang/String;Landroid/os/Parcelable;)V
    //   262: aload #10
    //   264: getfield a : Landroidx/fragment/app/c0;
    //   267: aload #10
    //   269: getfield c : Landroidx/fragment/app/o;
    //   272: aload #4
    //   274: iconst_0
    //   275: invokevirtual j : (Landroidx/fragment/app/o;Landroid/os/Bundle;Z)V
    //   278: aload #4
    //   280: invokevirtual isEmpty : ()Z
    //   283: ifeq -> 289
    //   286: goto -> 293
    //   289: aload #4
    //   291: astore #5
    //   293: aload #10
    //   295: getfield c : Landroidx/fragment/app/o;
    //   298: getfield L : Landroid/view/View;
    //   301: ifnull -> 309
    //   304: aload #10
    //   306: invokevirtual o : ()V
    //   309: aload #5
    //   311: astore #4
    //   313: aload #10
    //   315: getfield c : Landroidx/fragment/app/o;
    //   318: getfield j : Landroid/util/SparseArray;
    //   321: ifnull -> 358
    //   324: aload #5
    //   326: astore #4
    //   328: aload #5
    //   330: ifnonnull -> 342
    //   333: new android/os/Bundle
    //   336: dup
    //   337: invokespecial <init> : ()V
    //   340: astore #4
    //   342: aload #4
    //   344: ldc_w 'android:view_state'
    //   347: aload #10
    //   349: getfield c : Landroidx/fragment/app/o;
    //   352: getfield j : Landroid/util/SparseArray;
    //   355: invokevirtual putSparseParcelableArray : (Ljava/lang/String;Landroid/util/SparseArray;)V
    //   358: aload #4
    //   360: astore #5
    //   362: aload #10
    //   364: getfield c : Landroidx/fragment/app/o;
    //   367: getfield k : Landroid/os/Bundle;
    //   370: ifnull -> 407
    //   373: aload #4
    //   375: astore #5
    //   377: aload #4
    //   379: ifnonnull -> 391
    //   382: new android/os/Bundle
    //   385: dup
    //   386: invokespecial <init> : ()V
    //   389: astore #5
    //   391: aload #5
    //   393: ldc_w 'android:view_registry_state'
    //   396: aload #10
    //   398: getfield c : Landroidx/fragment/app/o;
    //   401: getfield k : Landroid/os/Bundle;
    //   404: invokevirtual putBundle : (Ljava/lang/String;Landroid/os/Bundle;)V
    //   407: aload #5
    //   409: astore #4
    //   411: aload #10
    //   413: getfield c : Landroidx/fragment/app/o;
    //   416: getfield N : Z
    //   419: ifne -> 456
    //   422: aload #5
    //   424: astore #4
    //   426: aload #5
    //   428: ifnonnull -> 440
    //   431: new android/os/Bundle
    //   434: dup
    //   435: invokespecial <init> : ()V
    //   438: astore #4
    //   440: aload #4
    //   442: ldc_w 'android:user_visible_hint'
    //   445: aload #10
    //   447: getfield c : Landroidx/fragment/app/o;
    //   450: getfield N : Z
    //   453: invokevirtual putBoolean : (Ljava/lang/String;Z)V
    //   456: aload #9
    //   458: aload #4
    //   460: putfield t : Landroid/os/Bundle;
    //   463: aload #10
    //   465: getfield c : Landroidx/fragment/app/o;
    //   468: getfield o : Ljava/lang/String;
    //   471: ifnull -> 548
    //   474: aload #4
    //   476: ifnonnull -> 491
    //   479: aload #9
    //   481: new android/os/Bundle
    //   484: dup
    //   485: invokespecial <init> : ()V
    //   488: putfield t : Landroid/os/Bundle;
    //   491: aload #9
    //   493: getfield t : Landroid/os/Bundle;
    //   496: ldc_w 'android:target_state'
    //   499: aload #10
    //   501: getfield c : Landroidx/fragment/app/o;
    //   504: getfield o : Ljava/lang/String;
    //   507: invokevirtual putString : (Ljava/lang/String;Ljava/lang/String;)V
    //   510: aload #10
    //   512: getfield c : Landroidx/fragment/app/o;
    //   515: getfield p : I
    //   518: istore_2
    //   519: iload_2
    //   520: ifeq -> 548
    //   523: aload #9
    //   525: getfield t : Landroid/os/Bundle;
    //   528: ldc_w 'android:target_req_state'
    //   531: iload_2
    //   532: invokevirtual putInt : (Ljava/lang/String;I)V
    //   535: goto -> 548
    //   538: aload #9
    //   540: aload #4
    //   542: getfield i : Landroid/os/Bundle;
    //   545: putfield t : Landroid/os/Bundle;
    //   548: aload #7
    //   550: aload #9
    //   552: invokevirtual add : (Ljava/lang/Object;)Z
    //   555: pop
    //   556: iconst_2
    //   557: invokestatic O : (I)Z
    //   560: ifeq -> 127
    //   563: new java/lang/StringBuilder
    //   566: dup
    //   567: invokespecial <init> : ()V
    //   570: astore #4
    //   572: aload #4
    //   574: ldc_w 'Saved state of '
    //   577: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   580: pop
    //   581: aload #4
    //   583: aload #6
    //   585: invokevirtual append : (Ljava/lang/Object;)Ljava/lang/StringBuilder;
    //   588: pop
    //   589: aload #4
    //   591: ldc_w ': '
    //   594: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   597: pop
    //   598: aload #4
    //   600: aload #9
    //   602: getfield t : Landroid/os/Bundle;
    //   605: invokevirtual append : (Ljava/lang/Object;)Ljava/lang/StringBuilder;
    //   608: pop
    //   609: ldc 'FragmentManager'
    //   611: aload #4
    //   613: invokevirtual toString : ()Ljava/lang/String;
    //   616: invokestatic v : (Ljava/lang/String;Ljava/lang/String;)I
    //   619: pop
    //   620: goto -> 127
    //   623: aload #7
    //   625: invokevirtual isEmpty : ()Z
    //   628: ifeq -> 649
    //   631: iconst_2
    //   632: invokestatic O : (I)Z
    //   635: ifeq -> 647
    //   638: ldc 'FragmentManager'
    //   640: ldc_w 'saveAllState: no fragments!'
    //   643: invokestatic v : (Ljava/lang/String;Ljava/lang/String;)I
    //   646: pop
    //   647: aconst_null
    //   648: areturn
    //   649: aload_0
    //   650: getfield c : Landroidx/fragment/app/k0;
    //   653: astore #8
    //   655: aload #8
    //   657: getfield a : Ljava/util/ArrayList;
    //   660: astore #5
    //   662: aload #5
    //   664: monitorenter
    //   665: aload #8
    //   667: getfield a : Ljava/util/ArrayList;
    //   670: invokevirtual isEmpty : ()Z
    //   673: ifeq -> 685
    //   676: aload #5
    //   678: monitorexit
    //   679: aconst_null
    //   680: astore #4
    //   682: goto -> 815
    //   685: new java/util/ArrayList
    //   688: dup
    //   689: aload #8
    //   691: getfield a : Ljava/util/ArrayList;
    //   694: invokevirtual size : ()I
    //   697: invokespecial <init> : (I)V
    //   700: astore #4
    //   702: aload #8
    //   704: getfield a : Ljava/util/ArrayList;
    //   707: invokevirtual iterator : ()Ljava/util/Iterator;
    //   710: astore #8
    //   712: aload #8
    //   714: invokeinterface hasNext : ()Z
    //   719: ifeq -> 812
    //   722: aload #8
    //   724: invokeinterface next : ()Ljava/lang/Object;
    //   729: checkcast androidx/fragment/app/o
    //   732: astore #9
    //   734: aload #4
    //   736: aload #9
    //   738: getfield l : Ljava/lang/String;
    //   741: invokevirtual add : (Ljava/lang/Object;)Z
    //   744: pop
    //   745: iconst_2
    //   746: invokestatic O : (I)Z
    //   749: ifeq -> 712
    //   752: new java/lang/StringBuilder
    //   755: dup
    //   756: invokespecial <init> : ()V
    //   759: astore #10
    //   761: aload #10
    //   763: ldc_w 'saveAllState: adding fragment ('
    //   766: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   769: pop
    //   770: aload #10
    //   772: aload #9
    //   774: getfield l : Ljava/lang/String;
    //   777: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   780: pop
    //   781: aload #10
    //   783: ldc_w '): '
    //   786: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   789: pop
    //   790: aload #10
    //   792: aload #9
    //   794: invokevirtual append : (Ljava/lang/Object;)Ljava/lang/StringBuilder;
    //   797: pop
    //   798: ldc 'FragmentManager'
    //   800: aload #10
    //   802: invokevirtual toString : ()Ljava/lang/String;
    //   805: invokestatic v : (Ljava/lang/String;Ljava/lang/String;)I
    //   808: pop
    //   809: goto -> 712
    //   812: aload #5
    //   814: monitorexit
    //   815: aload_0
    //   816: getfield d : Ljava/util/ArrayList;
    //   819: astore #8
    //   821: aload #6
    //   823: astore #5
    //   825: aload #8
    //   827: ifnull -> 954
    //   830: aload #8
    //   832: invokevirtual size : ()I
    //   835: istore_2
    //   836: aload #6
    //   838: astore #5
    //   840: iload_2
    //   841: ifle -> 954
    //   844: iload_2
    //   845: anewarray androidx/fragment/app/c
    //   848: astore #6
    //   850: aload #6
    //   852: astore #5
    //   854: iload_1
    //   855: iload_2
    //   856: if_icmpge -> 954
    //   859: aload #6
    //   861: iload_1
    //   862: new androidx/fragment/app/c
    //   865: dup
    //   866: aload_0
    //   867: getfield d : Ljava/util/ArrayList;
    //   870: iload_1
    //   871: invokevirtual get : (I)Ljava/lang/Object;
    //   874: checkcast androidx/fragment/app/b
    //   877: invokespecial <init> : (Landroidx/fragment/app/b;)V
    //   880: aastore
    //   881: iconst_2
    //   882: invokestatic O : (I)Z
    //   885: ifeq -> 947
    //   888: new java/lang/StringBuilder
    //   891: dup
    //   892: invokespecial <init> : ()V
    //   895: astore #5
    //   897: aload #5
    //   899: ldc_w 'saveAllState: adding back stack #'
    //   902: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   905: pop
    //   906: aload #5
    //   908: iload_1
    //   909: invokevirtual append : (I)Ljava/lang/StringBuilder;
    //   912: pop
    //   913: aload #5
    //   915: ldc_w ': '
    //   918: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   921: pop
    //   922: aload #5
    //   924: aload_0
    //   925: getfield d : Ljava/util/ArrayList;
    //   928: iload_1
    //   929: invokevirtual get : (I)Ljava/lang/Object;
    //   932: invokevirtual append : (Ljava/lang/Object;)Ljava/lang/StringBuilder;
    //   935: pop
    //   936: ldc 'FragmentManager'
    //   938: aload #5
    //   940: invokevirtual toString : ()Ljava/lang/String;
    //   943: invokestatic v : (Ljava/lang/String;Ljava/lang/String;)I
    //   946: pop
    //   947: iload_1
    //   948: iconst_1
    //   949: iadd
    //   950: istore_1
    //   951: goto -> 850
    //   954: new androidx/fragment/app/f0
    //   957: dup
    //   958: invokespecial <init> : ()V
    //   961: astore #6
    //   963: aload #6
    //   965: aload #7
    //   967: putfield h : Ljava/util/ArrayList;
    //   970: aload #6
    //   972: aload #4
    //   974: putfield i : Ljava/util/ArrayList;
    //   977: aload #6
    //   979: aload #5
    //   981: putfield j : [Landroidx/fragment/app/c;
    //   984: aload #6
    //   986: aload_0
    //   987: getfield i : Ljava/util/concurrent/atomic/AtomicInteger;
    //   990: invokevirtual get : ()I
    //   993: putfield k : I
    //   996: aload_0
    //   997: getfield t : Landroidx/fragment/app/o;
    //   1000: astore #4
    //   1002: aload #4
    //   1004: ifnull -> 1017
    //   1007: aload #6
    //   1009: aload #4
    //   1011: getfield l : Ljava/lang/String;
    //   1014: putfield l : Ljava/lang/String;
    //   1017: aload #6
    //   1019: getfield m : Ljava/util/ArrayList;
    //   1022: aload_0
    //   1023: getfield j : Ljava/util/Map;
    //   1026: invokeinterface keySet : ()Ljava/util/Set;
    //   1031: invokevirtual addAll : (Ljava/util/Collection;)Z
    //   1034: pop
    //   1035: aload #6
    //   1037: getfield n : Ljava/util/ArrayList;
    //   1040: aload_0
    //   1041: getfield j : Ljava/util/Map;
    //   1044: invokeinterface values : ()Ljava/util/Collection;
    //   1049: invokevirtual addAll : (Ljava/util/Collection;)Z
    //   1052: pop
    //   1053: aload #6
    //   1055: new java/util/ArrayList
    //   1058: dup
    //   1059: aload_0
    //   1060: getfield z : Ljava/util/ArrayDeque;
    //   1063: invokespecial <init> : (Ljava/util/Collection;)V
    //   1066: putfield o : Ljava/util/ArrayList;
    //   1069: aload #6
    //   1071: areturn
    //   1072: astore #4
    //   1074: aload #5
    //   1076: monitorexit
    //   1077: aload #4
    //   1079: athrow
    // Exception table:
    //   from	to	target	type
    //   665	679	1072	finally
    //   685	712	1072	finally
    //   712	809	1072	finally
    //   812	815	1072	finally
    //   1074	1077	1072	finally
  }
  
  public void c(o paramo) {
    if (O(2)) {
      StringBuilder stringBuilder = new StringBuilder();
      stringBuilder.append("attach: ");
      stringBuilder.append(paramo);
      Log.v("FragmentManager", stringBuilder.toString());
    } 
    if (paramo.G) {
      paramo.G = false;
      if (!paramo.r) {
        this.c.a(paramo);
        if (O(2)) {
          StringBuilder stringBuilder = new StringBuilder();
          stringBuilder.append("add from attach: ");
          stringBuilder.append(paramo);
          Log.v("FragmentManager", stringBuilder.toString());
        } 
        if (P(paramo))
          this.A = true; 
      } 
    } 
  }
  
  public void c0() {
    boolean bool1;
    boolean bool2;
    synchronized (this.a) {
      ArrayList<n> arrayList = this.I;
      bool2 = false;
      if (arrayList != null && !arrayList.isEmpty()) {
        bool1 = true;
      } else {
        bool1 = false;
      } 
      if (this.a.size() == 1)
        bool2 = true; 
    } 
    if (bool1 || bool2) {
      this.q.j.removeCallbacks(this.K);
      this.q.j.post(this.K);
      j0();
    } 
    /* monitor exit ClassFileLocalVariableReferenceExpression{type=ObjectType{java/lang/Object}, name=SYNTHETIC_LOCAL_VARIABLE_3} */
  }
  
  public final void d(o paramo) {
    HashSet hashSet = this.l.get(paramo);
    if (hashSet != null) {
      Iterator<g0.b> iterator = hashSet.iterator();
      while (iterator.hasNext())
        ((g0.b)iterator.next()).a(); 
      hashSet.clear();
      i(paramo);
      this.l.remove(paramo);
    } 
  }
  
  public void d0(o paramo, boolean paramBoolean) {
    ViewGroup viewGroup = J(paramo);
    if (viewGroup != null && viewGroup instanceof x)
      ((x)viewGroup).setDrawDisappearingViewsLast(paramBoolean ^ true); 
  }
  
  public final void e() {
    this.b = false;
    this.G.clear();
    this.F.clear();
  }
  
  public void e0(o paramo, androidx.lifecycle.e.c paramc) {
    if (paramo.equals(G(paramo.l)) && (paramo.z == null || paramo.y == this)) {
      paramo.S = paramc;
      return;
    } 
    StringBuilder stringBuilder = new StringBuilder();
    stringBuilder.append("Fragment ");
    stringBuilder.append(paramo);
    stringBuilder.append(" is not an active fragment of FragmentManager ");
    stringBuilder.append(this);
    throw new IllegalArgumentException(stringBuilder.toString());
  }
  
  public final Set<b1> f() {
    HashSet<b1> hashSet = new HashSet();
    Iterator iterator = ((ArrayList)this.c.f()).iterator();
    while (iterator.hasNext()) {
      ViewGroup viewGroup = ((j0)iterator.next()).c.K;
      if (viewGroup != null)
        hashSet.add(b1.g(viewGroup, M())); 
    } 
    return hashSet;
  }
  
  public void f0(o paramo) {
    if (paramo == null || (paramo.equals(G(paramo.l)) && (paramo.z == null || paramo.y == this))) {
      o o1 = this.t;
      this.t = paramo;
      t(o1);
      t(this.t);
      return;
    } 
    StringBuilder stringBuilder = new StringBuilder();
    stringBuilder.append("Fragment ");
    stringBuilder.append(paramo);
    stringBuilder.append(" is not an active fragment of FragmentManager ");
    stringBuilder.append(this);
    throw new IllegalArgumentException(stringBuilder.toString());
  }
  
  public void g(b paramb, boolean paramBoolean1, boolean paramBoolean2, boolean paramBoolean3) {
    if (paramBoolean1) {
      paramb.k(paramBoolean3);
    } else {
      paramb.j();
    } 
    ArrayList<b> arrayList = new ArrayList(1);
    ArrayList<Boolean> arrayList1 = new ArrayList(1);
    arrayList.add(paramb);
    arrayList1.add(Boolean.valueOf(paramBoolean1));
    if (paramBoolean2 && this.p >= 1)
      s0.p(this.q.i, this.r, arrayList, arrayList1, 0, 1, true, this.m); 
    if (paramBoolean3)
      T(this.p, true); 
    for (o o1 : this.c.g()) {
      if (o1 != null)
        View view = o1.L; 
    } 
  }
  
  public final void g0(o paramo) {
    ViewGroup viewGroup = J(paramo);
    if (viewGroup != null) {
      int i = paramo.k();
      int j = paramo.n();
      int k = paramo.t();
      if (paramo.u() + k + j + i > 0) {
        if (viewGroup.getTag(2131362475) == null)
          viewGroup.setTag(2131362475, paramo); 
        ((o)viewGroup.getTag(2131362475)).g0(paramo.s());
      } 
    } 
  }
  
  public j0 h(o paramo) {
    j0 j02 = this.c.h(paramo.l);
    if (j02 != null)
      return j02; 
    j0 j01 = new j0(this.n, this.c, paramo);
    j01.m(this.q.i.getClassLoader());
    j01.e = this.p;
    return j01;
  }
  
  public void h0(o paramo) {
    if (O(2)) {
      StringBuilder stringBuilder = new StringBuilder();
      stringBuilder.append("show: ");
      stringBuilder.append(paramo);
      Log.v("FragmentManager", stringBuilder.toString());
    } 
    if (paramo.F) {
      paramo.F = false;
      paramo.P ^= 0x1;
    } 
  }
  
  public final void i(o paramo) {
    paramo.U();
    this.n.n(paramo, false);
    paramo.K = null;
    paramo.L = null;
    paramo.U = null;
    paramo.V.h(null);
    paramo.u = false;
  }
  
  public final void i0() {
    for (j0 j0 : this.c.f()) {
      o o1 = j0.c;
      if (o1.M) {
        if (this.b) {
          this.E = true;
          continue;
        } 
        o1.M = false;
        j0.k();
      } 
    } 
  }
  
  public void j(o paramo) {
    if (O(2)) {
      StringBuilder stringBuilder = new StringBuilder();
      stringBuilder.append("detach: ");
      stringBuilder.append(paramo);
      Log.v("FragmentManager", stringBuilder.toString());
    } 
    if (!paramo.G) {
      paramo.G = true;
      if (paramo.r) {
        if (O(2)) {
          StringBuilder stringBuilder = new StringBuilder();
          stringBuilder.append("remove from detach: ");
          stringBuilder.append(paramo);
          Log.v("FragmentManager", stringBuilder.toString());
        } 
        this.c.l(paramo);
        if (P(paramo))
          this.A = true; 
        g0(paramo);
      } 
    } 
  }
  
  public final void j0() {
    ArrayList<l> arrayList;
    androidx.activity.b b1;
    synchronized (this.a) {
      boolean bool1;
      boolean bool = this.a.isEmpty();
      boolean bool2 = true;
      if (!bool) {
        this.h.a = true;
        return;
      } 
      b1 = this.h;
      ArrayList<b> arrayList1 = this.d;
      if (arrayList1 != null) {
        bool1 = arrayList1.size();
      } else {
        bool1 = false;
      } 
      if (!bool1 || !R(this.s))
        bool2 = false; 
      b1.a = bool2;
      return;
    } 
  }
  
  public void k(Configuration paramConfiguration) {
    for (o o1 : this.c.i()) {
      if (o1 != null) {
        o1.onConfigurationChanged(paramConfiguration);
        o1.A.k(paramConfiguration);
      } 
    } 
  }
  
  public boolean l(MenuItem paramMenuItem) {
    if (this.p < 1)
      return false; 
    for (o o1 : this.c.i()) {
      if (o1 != null) {
        boolean bool;
        if (!o1.F) {
          bool = o1.A.l(paramMenuItem);
        } else {
          bool = false;
        } 
        if (bool)
          return true; 
      } 
    } 
    return false;
  }
  
  public void m() {
    this.B = false;
    this.C = false;
    this.J.g = false;
    w(1);
  }
  
  public boolean n(Menu paramMenu, MenuInflater paramMenuInflater) {
    int i = this.p;
    boolean bool1 = false;
    if (i < 1)
      return false; 
    ArrayList<o> arrayList = null;
    Iterator<o> iterator = this.c.i().iterator();
    boolean bool2 = false;
    while (iterator.hasNext()) {
      o o1 = iterator.next();
      if (o1 != null && Q(o1)) {
        if (!o1.F) {
          i = o1.A.n(paramMenu, paramMenuInflater) | false;
        } else {
          i = 0;
        } 
        if (i != 0) {
          ArrayList<o> arrayList1 = arrayList;
          if (arrayList == null)
            arrayList1 = new ArrayList(); 
          arrayList1.add(o1);
          bool2 = true;
          arrayList = arrayList1;
        } 
      } 
    } 
    if (this.e != null)
      for (i = bool1; i < this.e.size(); i++) {
        o o1 = this.e.get(i);
        if (arrayList == null || !arrayList.contains(o1))
          Objects.requireNonNull(o1); 
      }  
    this.e = arrayList;
    return bool2;
  }
  
  public void o() {
    this.D = true;
    C(true);
    z();
    w(-1);
    this.q = null;
    this.r = null;
    this.s = null;
    if (this.g != null) {
      Iterator<androidx.activity.a> iterator = this.h.b.iterator();
      while (iterator.hasNext())
        ((androidx.activity.a)iterator.next()).cancel(); 
      this.g = null;
    } 
    androidx.activity.result.c<Intent> c1 = this.w;
    if (c1 != null) {
      c1.a();
      this.x.a();
      this.y.a();
    } 
  }
  
  public void p() {
    for (o o1 : this.c.i()) {
      if (o1 != null)
        o1.V(); 
    } 
  }
  
  public void q(boolean paramBoolean) {
    for (o o1 : this.c.i()) {
      if (o1 != null)
        o1.A.q(paramBoolean); 
    } 
  }
  
  public boolean r(MenuItem paramMenuItem) {
    if (this.p < 1)
      return false; 
    for (o o1 : this.c.i()) {
      if (o1 != null) {
        boolean bool;
        if (!o1.F) {
          bool = o1.A.r(paramMenuItem);
        } else {
          bool = false;
        } 
        if (bool)
          return true; 
      } 
    } 
    return false;
  }
  
  public void s(Menu paramMenu) {
    if (this.p < 1)
      return; 
    for (o o1 : this.c.i()) {
      if (o1 != null && !o1.F)
        o1.A.s(paramMenu); 
    } 
  }
  
  public final void t(o paramo) {
    if (paramo != null && paramo.equals(G(paramo.l))) {
      boolean bool = paramo.y.R(paramo);
      Boolean bool1 = paramo.q;
      if (bool1 == null || bool1.booleanValue() != bool) {
        paramo.q = Boolean.valueOf(bool);
        d0 d01 = paramo.A;
        d01.j0();
        d01.t(d01.t);
      } 
    } 
  }
  
  public String toString() {
    a0<?> a01;
    StringBuilder stringBuilder = new StringBuilder(128);
    stringBuilder.append("FragmentManager{");
    stringBuilder.append(Integer.toHexString(System.identityHashCode(this)));
    stringBuilder.append(" in ");
    o o1 = this.s;
    if (o1 != null) {
      stringBuilder.append(o1.getClass().getSimpleName());
      stringBuilder.append("{");
      o1 = this.s;
    } else {
      a01 = this.q;
      if (a01 != null) {
        stringBuilder.append(a01.getClass().getSimpleName());
        stringBuilder.append("{");
        a01 = this.q;
      } else {
        stringBuilder.append("null");
        stringBuilder.append("}}");
        return stringBuilder.toString();
      } 
    } 
    stringBuilder.append(Integer.toHexString(System.identityHashCode(a01)));
    stringBuilder.append("}");
    stringBuilder.append("}}");
    return stringBuilder.toString();
  }
  
  public void u(boolean paramBoolean) {
    for (o o1 : this.c.i()) {
      if (o1 != null)
        o1.A.u(paramBoolean); 
    } 
  }
  
  public boolean v(Menu paramMenu) {
    int i = this.p;
    boolean bool = false;
    if (i < 1)
      return false; 
    for (o o1 : this.c.i()) {
      if (o1 != null && Q(o1) && o1.W(paramMenu))
        bool = true; 
    } 
    return bool;
  }
  
  public final void w(int paramInt) {
    try {
      this.b = true;
      for (j0 j0 : this.c.b.values()) {
        if (j0 != null)
          j0.e = paramInt; 
      } 
      T(paramInt, false);
      Iterator<b1> iterator = ((HashSet)f()).iterator();
      while (iterator.hasNext())
        ((b1)iterator.next()).e(); 
      this.b = false;
      return;
    } finally {
      this.b = false;
    } 
  }
  
  public final void x() {
    if (this.E) {
      this.E = false;
      i0();
    } 
  }
  
  public void y(String paramString, FileDescriptor paramFileDescriptor, PrintWriter paramPrintWriter, String[] paramArrayOfString) {
    String str1 = j.f.a(paramString, "    ");
    k0 k01 = this.c;
    Objects.requireNonNull(k01);
    StringBuilder stringBuilder2 = new StringBuilder();
    stringBuilder2.append(paramString);
    stringBuilder2.append("    ");
    String str2 = stringBuilder2.toString();
    if (!k01.b.isEmpty()) {
      paramPrintWriter.print(paramString);
      paramPrintWriter.println("Active Fragments:");
      for (j0 j0 : k01.b.values()) {
        paramPrintWriter.print(paramString);
        if (j0 != null) {
          o o1 = j0.c;
          paramPrintWriter.println(o1);
          o1.e(str2, paramFileDescriptor, paramPrintWriter, paramArrayOfString);
          continue;
        } 
        paramPrintWriter.println("null");
      } 
    } 
    int i = k01.a.size();
    byte b1 = 0;
    if (i > 0) {
      paramPrintWriter.print(paramString);
      paramPrintWriter.println("Added Fragments:");
      int j;
      for (j = 0; j < i; j++) {
        o o1 = k01.a.get(j);
        paramPrintWriter.print(paramString);
        paramPrintWriter.print("  #");
        paramPrintWriter.print(j);
        paramPrintWriter.print(": ");
        paramPrintWriter.println(o1.toString());
      } 
    } 
    ArrayList<o> arrayList1 = this.e;
    if (arrayList1 != null) {
      i = arrayList1.size();
      if (i > 0) {
        paramPrintWriter.print(paramString);
        paramPrintWriter.println("Fragments Created Menus:");
        int j;
        for (j = 0; j < i; j++) {
          o o1 = this.e.get(j);
          paramPrintWriter.print(paramString);
          paramPrintWriter.print("  #");
          paramPrintWriter.print(j);
          paramPrintWriter.print(": ");
          paramPrintWriter.println(o1.toString());
        } 
      } 
    } 
    ArrayList<b> arrayList = this.d;
    if (arrayList != null) {
      i = arrayList.size();
      if (i > 0) {
        paramPrintWriter.print(paramString);
        paramPrintWriter.println("Back Stack:");
        int j;
        for (j = 0; j < i; j++) {
          b b2 = this.d.get(j);
          paramPrintWriter.print(paramString);
          paramPrintWriter.print("  #");
          paramPrintWriter.print(j);
          paramPrintWriter.print(": ");
          paramPrintWriter.println(b2.toString());
          b2.i(str1, paramPrintWriter, true);
        } 
      } 
    } 
    paramPrintWriter.print(paramString);
    StringBuilder stringBuilder1 = new StringBuilder();
    stringBuilder1.append("Back Stack Index: ");
    stringBuilder1.append(this.i.get());
    paramPrintWriter.println(stringBuilder1.toString());
    synchronized (this.a) {
      i = this.a.size();
      if (i > 0) {
        paramPrintWriter.print(paramString);
        paramPrintWriter.println("Pending Actions:");
        int j;
        for (j = b1; j < i; j++) {
          l l = this.a.get(j);
          paramPrintWriter.print(paramString);
          paramPrintWriter.print("  #");
          paramPrintWriter.print(j);
          paramPrintWriter.print(": ");
          paramPrintWriter.println(l);
        } 
      } 
      paramPrintWriter.print(paramString);
      paramPrintWriter.println("FragmentManager misc state:");
      paramPrintWriter.print(paramString);
      paramPrintWriter.print("  mHost=");
      paramPrintWriter.println(this.q);
      paramPrintWriter.print(paramString);
      paramPrintWriter.print("  mContainer=");
      paramPrintWriter.println(this.r);
      if (this.s != null) {
        paramPrintWriter.print(paramString);
        paramPrintWriter.print("  mParent=");
        paramPrintWriter.println(this.s);
      } 
      paramPrintWriter.print(paramString);
      paramPrintWriter.print("  mCurState=");
      paramPrintWriter.print(this.p);
      paramPrintWriter.print(" mStateSaved=");
      paramPrintWriter.print(this.B);
      paramPrintWriter.print(" mStopped=");
      paramPrintWriter.print(this.C);
      paramPrintWriter.print(" mDestroyed=");
      paramPrintWriter.println(this.D);
      if (this.A) {
        paramPrintWriter.print(paramString);
        paramPrintWriter.print("  mNeedMenuInvalidate=");
        paramPrintWriter.println(this.A);
      } 
      return;
    } 
  }
  
  public final void z() {
    Iterator<b1> iterator = ((HashSet)f()).iterator();
    while (iterator.hasNext())
      ((b1)iterator.next()).e(); 
  }
  
  public class a implements androidx.activity.result.b<androidx.activity.result.a> {
    public a(d0 this$0) {}
    
    public void a(Object param1Object) {
      param1Object = param1Object;
      d0.k k = this.a.z.pollFirst();
      if (k == null) {
        param1Object = new StringBuilder();
        param1Object.append("No IntentSenders were started for ");
        param1Object.append(this);
      } else {
        String str = k.h;
        int i = k.i;
        o o = this.a.c.e(str);
        if (o == null) {
          param1Object = new StringBuilder();
          param1Object.append("Intent Sender result delivered for unknown Fragment ");
          param1Object.append(str);
        } else {
          o.E(i, ((androidx.activity.result.a)param1Object).h, ((androidx.activity.result.a)param1Object).i);
          return;
        } 
      } 
      Log.w("FragmentManager", param1Object.toString());
    }
  }
  
  public class b implements androidx.activity.result.b<Map<String, Boolean>> {
    public b(d0 this$0) {}
    
    @SuppressLint({"SyntheticAccessor"})
    public void a(Object param1Object) {
      param1Object = param1Object;
      String[] arrayOfString = (String[])param1Object.keySet().toArray((Object[])new String[0]);
      param1Object = new ArrayList(param1Object.values());
      int[] arrayOfInt = new int[param1Object.size()];
      for (int i = 0; i < param1Object.size(); i++) {
        byte b1;
        if (((Boolean)param1Object.get(i)).booleanValue()) {
          b1 = 0;
        } else {
          b1 = -1;
        } 
        arrayOfInt[i] = b1;
      } 
      param1Object = this.a.z.pollFirst();
      if (param1Object == null) {
        param1Object = new StringBuilder();
        param1Object.append("No permissions were requested for ");
        param1Object.append(this);
        param1Object = param1Object.toString();
      } else {
        param1Object = ((d0.k)param1Object).h;
        if (this.a.c.e((String)param1Object) == null) {
          param1Object = j.f.a("Permission request result delivered for unknown Fragment ", (String)param1Object);
        } else {
          return;
        } 
      } 
      Log.w("FragmentManager", (String)param1Object);
    }
  }
  
  public class c extends androidx.activity.b {
    public c(d0 this$0, boolean param1Boolean) {
      super(param1Boolean);
    }
    
    public void a() {
      d0 d01 = this.c;
      d01.C(true);
      if (d01.h.a) {
        d01.W();
        return;
      } 
      d01.g.b();
    }
  }
  
  public class d implements s0.a {
    public d(d0 this$0) {}
    
    public void a(o param1o, g0.b param1b) {
      // Byte code:
      //   0: aload_2
      //   1: monitorenter
      //   2: aload_2
      //   3: getfield a : Z
      //   6: istore_3
      //   7: aload_2
      //   8: monitorexit
      //   9: iload_3
      //   10: ifne -> 94
      //   13: aload_0
      //   14: getfield a : Landroidx/fragment/app/d0;
      //   17: astore #4
      //   19: aload #4
      //   21: getfield l : Ljava/util/Map;
      //   24: aload_1
      //   25: invokeinterface get : (Ljava/lang/Object;)Ljava/lang/Object;
      //   30: checkcast java/util/HashSet
      //   33: astore #5
      //   35: aload #5
      //   37: ifnull -> 94
      //   40: aload #5
      //   42: aload_2
      //   43: invokevirtual remove : (Ljava/lang/Object;)Z
      //   46: ifeq -> 94
      //   49: aload #5
      //   51: invokevirtual isEmpty : ()Z
      //   54: ifeq -> 94
      //   57: aload #4
      //   59: getfield l : Ljava/util/Map;
      //   62: aload_1
      //   63: invokeinterface remove : (Ljava/lang/Object;)Ljava/lang/Object;
      //   68: pop
      //   69: aload_1
      //   70: getfield h : I
      //   73: iconst_5
      //   74: if_icmpge -> 94
      //   77: aload #4
      //   79: aload_1
      //   80: invokevirtual i : (Landroidx/fragment/app/o;)V
      //   83: aload #4
      //   85: aload_1
      //   86: aload #4
      //   88: getfield p : I
      //   91: invokevirtual U : (Landroidx/fragment/app/o;I)V
      //   94: return
      //   95: astore_1
      //   96: aload_2
      //   97: monitorexit
      //   98: aload_1
      //   99: athrow
      // Exception table:
      //   from	to	target	type
      //   2	9	95	finally
      //   96	98	95	finally
    }
    
    public void b(o param1o, g0.b param1b) {
      d0 d01 = this.a;
      if (d01.l.get(param1o) == null)
        d01.l.put(param1o, new HashSet<g0.b>()); 
      ((HashSet<g0.b>)d01.l.get(param1o)).add(param1b);
    }
  }
  
  public class e extends z {
    public e(d0 this$0) {}
    
    public o a(ClassLoader param1ClassLoader, String param1String) {
      a0<?> a0 = this.b.q;
      Context context = a0.i;
      Objects.requireNonNull(a0);
      Object object = o.Y;
      try {
        return z.c(context.getClassLoader(), param1String).getConstructor(new Class[0]).newInstance(new Object[0]);
      } catch (InstantiationException instantiationException) {
        throw new o.c(d0.c.a("Unable to instantiate fragment ", param1String, ": make sure class name exists, is public, and has an empty constructor that is public"), instantiationException);
      } catch (IllegalAccessException illegalAccessException) {
        throw new o.c(d0.c.a("Unable to instantiate fragment ", param1String, ": make sure class name exists, is public, and has an empty constructor that is public"), illegalAccessException);
      } catch (NoSuchMethodException noSuchMethodException) {
        throw new o.c(d0.c.a("Unable to instantiate fragment ", param1String, ": could not find Fragment constructor"), noSuchMethodException);
      } catch (InvocationTargetException invocationTargetException) {
        throw new o.c(d0.c.a("Unable to instantiate fragment ", param1String, ": calling Fragment constructor caused an exception"), invocationTargetException);
      } 
    }
  }
  
  public class f implements f1 {
    public f(d0 this$0) {}
  }
  
  public class g implements Runnable {
    public g(d0 this$0) {}
    
    public void run() {
      this.h.C(true);
    }
  }
  
  public class h implements h0 {
    public h(d0 this$0, o param1o) {}
    
    public void b(d0 param1d0, o param1o) {
      Objects.requireNonNull(this.h);
    }
  }
  
  public class i implements androidx.activity.result.b<androidx.activity.result.a> {
    public i(d0 this$0) {}
    
    public void a(Object param1Object) {
      param1Object = param1Object;
      d0.k k = this.a.z.pollFirst();
      if (k == null) {
        param1Object = new StringBuilder();
        param1Object.append("No Activities were started for result for ");
        param1Object.append(this);
      } else {
        String str = k.h;
        int j = k.i;
        o o = this.a.c.e(str);
        if (o == null) {
          param1Object = new StringBuilder();
          param1Object.append("Activity result delivered for unknown Fragment ");
          param1Object.append(str);
        } else {
          o.E(j, ((androidx.activity.result.a)param1Object).h, ((androidx.activity.result.a)param1Object).i);
          return;
        } 
      } 
      Log.w("FragmentManager", param1Object.toString());
    }
  }
  
  public static class j extends d.a<Object, androidx.activity.result.a> {
    public Object a(int param1Int, Intent param1Intent) {
      return new androidx.activity.result.a(param1Int, param1Intent);
    }
  }
  
  @SuppressLint({"BanParcelableUsage"})
  public static class k implements Parcelable {
    public static final Parcelable.Creator<k> CREATOR = new a();
    
    public String h;
    
    public int i;
    
    public k(Parcel param1Parcel) {
      this.h = param1Parcel.readString();
      this.i = param1Parcel.readInt();
    }
    
    public int describeContents() {
      return 0;
    }
    
    public void writeToParcel(Parcel param1Parcel, int param1Int) {
      param1Parcel.writeString(this.h);
      param1Parcel.writeInt(this.i);
    }
    
    public class a implements Parcelable.Creator<k> {
      public Object createFromParcel(Parcel param2Parcel) {
        return new d0.k(param2Parcel);
      }
      
      public Object[] newArray(int param2Int) {
        return (Object[])new d0.k[param2Int];
      }
    }
  }
  
  public class a implements Parcelable.Creator<k> {
    public Object createFromParcel(Parcel param1Parcel) {
      return new d0.k(param1Parcel);
    }
    
    public Object[] newArray(int param1Int) {
      return (Object[])new d0.k[param1Int];
    }
  }
  
  public static interface l {
    boolean a(ArrayList<b> param1ArrayList, ArrayList<Boolean> param1ArrayList1);
  }
  
  public class m implements l {
    public final int a;
    
    public final int b;
    
    public m(d0 this$0, String param1String, int param1Int1, int param1Int2) {
      this.a = param1Int1;
      this.b = param1Int2;
    }
    
    public boolean a(ArrayList<b> param1ArrayList, ArrayList<Boolean> param1ArrayList1) {
      o o = this.c.t;
      return (o != null && this.a < 0 && o.h().W()) ? false : this.c.X(param1ArrayList, param1ArrayList1, null, this.a, this.b);
    }
  }
  
  public static class n implements o.e {
    public final boolean a;
    
    public final b b;
    
    public int c;
    
    public void a() {
      boolean bool;
      if (this.c > 0) {
        bool = true;
      } else {
        bool = false;
      } 
      for (o o : this.b.p.L()) {
        o.f0(null);
        if (bool && o.C())
          o.i0(); 
      } 
      b b1 = this.b;
      b1.p.g(b1, this.a, bool ^ true, true);
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Luxury Logo Maker_ Logo Design-dex2jar.jar!\androidx\fragment\app\d0.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */