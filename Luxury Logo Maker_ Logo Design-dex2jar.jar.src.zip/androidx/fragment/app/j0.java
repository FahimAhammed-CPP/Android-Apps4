package androidx.fragment.app;

import android.app.Activity;
import android.content.Context;
import android.content.res.Resources;
import android.os.Bundle;
import android.os.Parcelable;
import android.support.v4.media.c;
import android.util.Log;
import android.util.SparseArray;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import androidx.lifecycle.e;
import androidx.lifecycle.h;
import androidx.lifecycle.j;
import androidx.lifecycle.z;
import androidx.savedstate.b;
import java.util.Iterator;
import java.util.Objects;
import java.util.UUID;
import java.util.WeakHashMap;
import k0.l;

public class j0 {
  public final c0 a;
  
  public final k0 b;
  
  public final o c;
  
  public boolean d = false;
  
  public int e = -1;
  
  public j0(c0 paramc0, k0 paramk0, o paramo) {
    this.a = paramc0;
    this.b = paramk0;
    this.c = paramo;
  }
  
  public j0(c0 paramc0, k0 paramk0, o paramo, i0 parami0) {
    this.a = paramc0;
    this.b = paramk0;
    this.c = paramo;
    paramo.j = null;
    paramo.k = null;
    paramo.x = 0;
    paramo.u = false;
    paramo.r = false;
    o o1 = paramo.n;
    if (o1 != null) {
      String str = o1.l;
    } else {
      o1 = null;
    } 
    paramo.o = (String)o1;
    paramo.n = null;
    Bundle bundle = parami0.t;
    if (bundle == null)
      bundle = new Bundle(); 
    paramo.i = bundle;
  }
  
  public j0(c0 paramc0, k0 paramk0, ClassLoader paramClassLoader, z paramz, i0 parami0) {
    this.a = paramc0;
    this.b = paramk0;
    o o1 = paramz.a(paramClassLoader, parami0.h);
    this.c = o1;
    Bundle bundle = parami0.q;
    if (bundle != null)
      bundle.setClassLoader(paramClassLoader); 
    o1.c0(parami0.q);
    o1.l = parami0.i;
    o1.t = parami0.j;
    o1.v = true;
    o1.C = parami0.k;
    o1.D = parami0.l;
    o1.E = parami0.m;
    o1.H = parami0.n;
    o1.s = parami0.o;
    o1.G = parami0.p;
    o1.F = parami0.r;
    o1.S = e.c.values()[parami0.s];
    bundle = parami0.t;
    if (bundle == null)
      bundle = new Bundle(); 
    o1.i = bundle;
    if (d0.O(2)) {
      StringBuilder stringBuilder = new StringBuilder();
      stringBuilder.append("Instantiated fragment ");
      stringBuilder.append(o1);
      Log.v("FragmentManager", stringBuilder.toString());
    } 
  }
  
  public void a() {
    if (d0.O(3)) {
      StringBuilder stringBuilder = c.a("moveto ACTIVITY_CREATED: ");
      stringBuilder.append(this.c);
      Log.d("FragmentManager", stringBuilder.toString());
    } 
    o o1 = this.c;
    Bundle bundle = o1.i;
    o1.A.V();
    o1.h = 3;
    o1.J = false;
    o1.J = true;
    if (d0.O(3)) {
      StringBuilder stringBuilder = new StringBuilder();
      stringBuilder.append("moveto RESTORE_VIEW_STATE: ");
      stringBuilder.append(o1);
      Log.d("FragmentManager", stringBuilder.toString());
    } 
    View view = o1.L;
    if (view != null) {
      bundle = o1.i;
      SparseArray<Parcelable> sparseArray = o1.j;
      if (sparseArray != null) {
        view.restoreHierarchyState(sparseArray);
        o1.j = null;
      } 
      if (o1.L != null) {
        x0 x0 = o1.U;
        Bundle bundle1 = o1.k;
        x0.j.a(bundle1);
        o1.k = null;
      } 
      o1.J = false;
      o1.S(bundle);
      if (o1.J) {
        if (o1.L != null)
          o1.U.b(e.b.ON_CREATE); 
      } else {
        throw new g1(n.b("Fragment ", o1, " did not call through to super.onViewStateRestored()"));
      } 
    } 
    o1.i = null;
    d0 d0 = o1.A;
    d0.B = false;
    d0.C = false;
    d0.J.g = false;
    d0.w(4);
    c0 c01 = this.a;
    o o2 = this.c;
    c01.a(o2, o2.i, false);
  }
  
  public void b() {
    int i;
    k0 k01 = this.b;
    o o2 = this.c;
    Objects.requireNonNull(k01);
    ViewGroup viewGroup = o2.K;
    byte b = -1;
    if (viewGroup == null) {
      i = b;
    } else {
      int k = k01.a.indexOf(o2);
      int j = k - 1;
      while (true) {
        i = k;
        if (j >= 0) {
          o2 = k01.a.get(j);
          if (o2.K == viewGroup) {
            View view = o2.L;
            if (view != null) {
              i = viewGroup.indexOfChild(view) + 1;
              break;
            } 
          } 
          j--;
          continue;
        } 
        while (true) {
          j = i + 1;
          i = b;
          if (j < k01.a.size()) {
            o2 = k01.a.get(j);
            i = j;
            if (o2.K == viewGroup) {
              View view = o2.L;
              i = j;
              if (view != null) {
                i = viewGroup.indexOfChild(view);
                break;
              } 
            } 
            continue;
          } 
          break;
        } 
        break;
      } 
    } 
    o o1 = this.c;
    o1.K.addView(o1.L, i);
  }
  
  public void c() {
    StringBuilder stringBuilder;
    d0 d01;
    if (d0.O(3)) {
      stringBuilder = c.a("moveto ATTACHED: ");
      stringBuilder.append(this.c);
      Log.d("FragmentManager", stringBuilder.toString());
    } 
    o o2 = this.c;
    o o3 = o2.n;
    j0 j01 = null;
    if (o3 != null) {
      j01 = this.b.h(o3.l);
      if (j01 != null) {
        o2 = this.c;
        o2.o = o2.n.l;
        o2.n = null;
      } else {
        stringBuilder = c.a("Fragment ");
        stringBuilder.append(this.c);
        stringBuilder.append(" declared target fragment ");
        stringBuilder.append(this.c.n);
        stringBuilder.append(" that does not belong to this FragmentManager!");
        throw new IllegalStateException(stringBuilder.toString());
      } 
    } else {
      String str = o2.o;
      if (str != null) {
        j01 = this.b.h(str);
        if (j01 == null) {
          stringBuilder = c.a("Fragment ");
          stringBuilder.append(this.c);
          stringBuilder.append(" declared target fragment ");
          stringBuilder.append(this.c.o);
          stringBuilder.append(" that does not belong to this FragmentManager!");
          throw new IllegalStateException(stringBuilder.toString());
        } 
      } 
    } 
    if (stringBuilder != null)
      stringBuilder.k(); 
    o o1 = this.c;
    d0 d02 = o1.y;
    o1.z = d02.q;
    o1.B = d02.s;
    this.a.g(o1, false);
    o1 = this.c;
    Iterator<o.d> iterator = o1.X.iterator();
    while (iterator.hasNext())
      ((o.d)iterator.next()).a(); 
    o1.X.clear();
    o1.A.b(o1.z, o1.b(), o1);
    o1.h = 0;
    o1.J = false;
    o1.F(o1.z.i);
    if (o1.J) {
      d0 d0 = o1.y;
      Iterator<h0> iterator1 = d0.o.iterator();
      while (iterator1.hasNext())
        ((h0)iterator1.next()).b(d0, o1); 
      d01 = o1.A;
      d01.B = false;
      d01.C = false;
      d01.J.g = false;
      d01.w(0);
      this.a.b(this.c, false);
      return;
    } 
    throw new g1(n.b("Fragment ", d01, " did not call through to super.onAttach()"));
  }
  
  public int d() {
    // Byte code:
    //   0: aload_0
    //   1: getfield c : Landroidx/fragment/app/o;
    //   4: astore #6
    //   6: aload #6
    //   8: getfield y : Landroidx/fragment/app/d0;
    //   11: ifnonnull -> 20
    //   14: aload #6
    //   16: getfield h : I
    //   19: ireturn
    //   20: aload_0
    //   21: getfield e : I
    //   24: istore_2
    //   25: aload #6
    //   27: getfield S : Landroidx/lifecycle/e$c;
    //   30: invokevirtual ordinal : ()I
    //   33: istore_3
    //   34: iconst_0
    //   35: istore #5
    //   37: iconst_0
    //   38: istore #4
    //   40: iload_3
    //   41: iconst_1
    //   42: if_icmpeq -> 89
    //   45: iload_3
    //   46: iconst_2
    //   47: if_icmpeq -> 80
    //   50: iload_3
    //   51: iconst_3
    //   52: if_icmpeq -> 71
    //   55: iload_2
    //   56: istore_1
    //   57: iload_3
    //   58: iconst_4
    //   59: if_icmpeq -> 95
    //   62: iload_2
    //   63: iconst_m1
    //   64: invokestatic min : (II)I
    //   67: istore_1
    //   68: goto -> 95
    //   71: iload_2
    //   72: iconst_5
    //   73: invokestatic min : (II)I
    //   76: istore_1
    //   77: goto -> 95
    //   80: iload_2
    //   81: iconst_1
    //   82: invokestatic min : (II)I
    //   85: istore_1
    //   86: goto -> 95
    //   89: iload_2
    //   90: iconst_0
    //   91: invokestatic min : (II)I
    //   94: istore_1
    //   95: aload_0
    //   96: getfield c : Landroidx/fragment/app/o;
    //   99: astore #6
    //   101: iload_1
    //   102: istore_2
    //   103: aload #6
    //   105: getfield t : Z
    //   108: ifeq -> 190
    //   111: aload #6
    //   113: getfield u : Z
    //   116: ifeq -> 163
    //   119: aload_0
    //   120: getfield e : I
    //   123: iconst_2
    //   124: invokestatic max : (II)I
    //   127: istore_1
    //   128: aload_0
    //   129: getfield c : Landroidx/fragment/app/o;
    //   132: getfield L : Landroid/view/View;
    //   135: astore #6
    //   137: iload_1
    //   138: istore_2
    //   139: aload #6
    //   141: ifnull -> 190
    //   144: iload_1
    //   145: istore_2
    //   146: aload #6
    //   148: invokevirtual getParent : ()Landroid/view/ViewParent;
    //   151: ifnonnull -> 190
    //   154: iload_1
    //   155: iconst_2
    //   156: invokestatic min : (II)I
    //   159: istore_2
    //   160: goto -> 190
    //   163: aload_0
    //   164: getfield e : I
    //   167: iconst_4
    //   168: if_icmpge -> 184
    //   171: iload_1
    //   172: aload #6
    //   174: getfield h : I
    //   177: invokestatic min : (II)I
    //   180: istore_2
    //   181: goto -> 190
    //   184: iload_1
    //   185: iconst_1
    //   186: invokestatic min : (II)I
    //   189: istore_2
    //   190: iload_2
    //   191: istore_3
    //   192: aload_0
    //   193: getfield c : Landroidx/fragment/app/o;
    //   196: getfield r : Z
    //   199: ifne -> 208
    //   202: iload_2
    //   203: iconst_1
    //   204: invokestatic min : (II)I
    //   207: istore_3
    //   208: aload_0
    //   209: getfield c : Landroidx/fragment/app/o;
    //   212: astore #6
    //   214: aload #6
    //   216: getfield K : Landroid/view/ViewGroup;
    //   219: astore #8
    //   221: aconst_null
    //   222: astore #7
    //   224: iload #5
    //   226: istore_1
    //   227: aload #8
    //   229: ifnull -> 365
    //   232: aload #8
    //   234: aload #6
    //   236: invokevirtual r : ()Landroidx/fragment/app/d0;
    //   239: invokevirtual M : ()Landroidx/fragment/app/f1;
    //   242: invokestatic g : (Landroid/view/ViewGroup;Landroidx/fragment/app/f1;)Landroidx/fragment/app/b1;
    //   245: astore #6
    //   247: aload #6
    //   249: invokestatic requireNonNull : (Ljava/lang/Object;)Ljava/lang/Object;
    //   252: pop
    //   253: aload #6
    //   255: aload_0
    //   256: getfield c : Landroidx/fragment/app/o;
    //   259: invokevirtual d : (Landroidx/fragment/app/o;)Landroidx/fragment/app/b1$b;
    //   262: astore #8
    //   264: iload #4
    //   266: istore_2
    //   267: aload #8
    //   269: ifnull -> 278
    //   272: aload #8
    //   274: getfield b : I
    //   277: istore_2
    //   278: aload_0
    //   279: getfield c : Landroidx/fragment/app/o;
    //   282: astore #8
    //   284: aload #6
    //   286: getfield c : Ljava/util/ArrayList;
    //   289: invokevirtual iterator : ()Ljava/util/Iterator;
    //   292: astore #9
    //   294: aload #7
    //   296: astore #6
    //   298: aload #9
    //   300: invokeinterface hasNext : ()Z
    //   305: ifeq -> 341
    //   308: aload #9
    //   310: invokeinterface next : ()Ljava/lang/Object;
    //   315: checkcast androidx/fragment/app/b1$b
    //   318: astore #6
    //   320: aload #6
    //   322: getfield c : Landroidx/fragment/app/o;
    //   325: aload #8
    //   327: invokevirtual equals : (Ljava/lang/Object;)Z
    //   330: ifeq -> 294
    //   333: aload #6
    //   335: getfield f : Z
    //   338: ifne -> 294
    //   341: iload_2
    //   342: istore_1
    //   343: aload #6
    //   345: ifnull -> 365
    //   348: iload_2
    //   349: ifeq -> 359
    //   352: iload_2
    //   353: istore_1
    //   354: iload_2
    //   355: iconst_1
    //   356: if_icmpne -> 365
    //   359: aload #6
    //   361: getfield b : I
    //   364: istore_1
    //   365: iload_1
    //   366: iconst_2
    //   367: if_icmpne -> 380
    //   370: iload_3
    //   371: bipush #6
    //   373: invokestatic min : (II)I
    //   376: istore_1
    //   377: goto -> 433
    //   380: iload_1
    //   381: iconst_3
    //   382: if_icmpne -> 394
    //   385: iload_3
    //   386: iconst_3
    //   387: invokestatic max : (II)I
    //   390: istore_1
    //   391: goto -> 433
    //   394: aload_0
    //   395: getfield c : Landroidx/fragment/app/o;
    //   398: astore #6
    //   400: iload_3
    //   401: istore_1
    //   402: aload #6
    //   404: getfield s : Z
    //   407: ifeq -> 433
    //   410: aload #6
    //   412: invokevirtual B : ()Z
    //   415: ifeq -> 427
    //   418: iload_3
    //   419: iconst_1
    //   420: invokestatic min : (II)I
    //   423: istore_1
    //   424: goto -> 433
    //   427: iload_3
    //   428: iconst_m1
    //   429: invokestatic min : (II)I
    //   432: istore_1
    //   433: aload_0
    //   434: getfield c : Landroidx/fragment/app/o;
    //   437: astore #6
    //   439: iload_1
    //   440: istore_2
    //   441: aload #6
    //   443: getfield M : Z
    //   446: ifeq -> 466
    //   449: iload_1
    //   450: istore_2
    //   451: aload #6
    //   453: getfield h : I
    //   456: iconst_5
    //   457: if_icmpge -> 466
    //   460: iload_1
    //   461: iconst_4
    //   462: invokestatic min : (II)I
    //   465: istore_2
    //   466: iconst_2
    //   467: invokestatic O : (I)Z
    //   470: ifeq -> 528
    //   473: new java/lang/StringBuilder
    //   476: dup
    //   477: invokespecial <init> : ()V
    //   480: astore #6
    //   482: aload #6
    //   484: ldc_w 'computeExpectedState() of '
    //   487: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   490: pop
    //   491: aload #6
    //   493: iload_2
    //   494: invokevirtual append : (I)Ljava/lang/StringBuilder;
    //   497: pop
    //   498: aload #6
    //   500: ldc_w ' for '
    //   503: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   506: pop
    //   507: aload #6
    //   509: aload_0
    //   510: getfield c : Landroidx/fragment/app/o;
    //   513: invokevirtual append : (Ljava/lang/Object;)Ljava/lang/StringBuilder;
    //   516: pop
    //   517: ldc 'FragmentManager'
    //   519: aload #6
    //   521: invokevirtual toString : ()Ljava/lang/String;
    //   524: invokestatic v : (Ljava/lang/String;Ljava/lang/String;)I
    //   527: pop
    //   528: iload_2
    //   529: ireturn
  }
  
  public void e() {
    c0 c01;
    if (d0.O(3)) {
      StringBuilder stringBuilder = c.a("moveto CREATED: ");
      stringBuilder.append(this.c);
      Log.d("FragmentManager", stringBuilder.toString());
    } 
    o o1 = this.c;
    if (!o1.R) {
      this.a.h(o1, o1.i, false);
      o1 = this.c;
      Bundle bundle1 = o1.i;
      o1.A.V();
      o1.h = 1;
      o1.J = false;
      o1.T.a((h)new Fragment$5(o1));
      o1.W.a(bundle1);
      o1.G(bundle1);
      o1.R = true;
      if (o1.J) {
        o1.T.d(e.b.ON_CREATE);
        c01 = this.a;
        o o2 = this.c;
        c01.c(o2, o2.i, false);
        return;
      } 
      throw new g1(n.b("Fragment ", c01, " did not call through to super.onCreate()"));
    } 
    Bundle bundle = ((o)c01).i;
    if (bundle != null) {
      Parcelable parcelable = bundle.getParcelable("android:support:fragments");
      if (parcelable != null) {
        ((o)c01).A.a0(parcelable);
        ((o)c01).A.m();
      } 
    } 
    this.c.h = 1;
  }
  
  public void f() {
    StringBuilder stringBuilder;
    if (this.c.t)
      return; 
    if (d0.O(3)) {
      stringBuilder = c.a("moveto CREATE_VIEW: ");
      stringBuilder.append(this.c);
      Log.d("FragmentManager", stringBuilder.toString());
    } 
    o o1 = this.c;
    LayoutInflater layoutInflater = o1.L(o1.i);
    o1 = null;
    o o3 = this.c;
    ViewGroup viewGroup = o3.K;
    if (viewGroup != null) {
      ViewGroup viewGroup1 = viewGroup;
    } else {
      int i = o3.D;
      if (i != 0)
        if (i != -1) {
          viewGroup = (ViewGroup)o3.y.r.e(i);
          ViewGroup viewGroup1 = viewGroup;
          if (viewGroup == null) {
            ViewGroup viewGroup2;
            o o4 = this.c;
            if (o4.v) {
              viewGroup2 = viewGroup;
            } else {
              String str;
              try {
                str = viewGroup2.w().getResourceName(this.c.D);
              } catch (android.content.res.Resources.NotFoundException notFoundException) {
                str = "unknown";
              } 
              StringBuilder stringBuilder1 = c.a("No view found for id 0x");
              stringBuilder1.append(Integer.toHexString(this.c.D));
              stringBuilder1.append(" (");
              stringBuilder1.append(str);
              stringBuilder1.append(") for fragment ");
              stringBuilder1.append(this.c);
              throw new IllegalArgumentException(stringBuilder1.toString());
            } 
          } 
        } else {
          stringBuilder = c.a("Cannot create fragment ");
          stringBuilder.append(this.c);
          stringBuilder.append(" for a container view with no id");
          throw new IllegalArgumentException(stringBuilder.toString());
        }  
    } 
    o o2 = this.c;
    o2.K = (ViewGroup)stringBuilder;
    o2.T(layoutInflater, (ViewGroup)stringBuilder, o2.i);
    View view = this.c.L;
    if (view != null) {
      view.setSaveFromParentEnabled(false);
      o o8 = this.c;
      o8.L.setTag(2131362069, o8);
      if (stringBuilder != null)
        b(); 
      o o6 = this.c;
      if (o6.F)
        o6.L.setVisibility(8); 
      View view1 = this.c.L;
      WeakHashMap weakHashMap = l.a;
      if (view1.isAttachedToWindow()) {
        this.c.L.requestApplyInsets();
      } else {
        view1 = this.c.L;
        view1.addOnAttachStateChangeListener(new a(this, view1));
      } 
      o o5 = this.c;
      o5.R(o5.L, o5.i);
      o5.A.w(2);
      c0 c01 = this.a;
      o o7 = this.c;
      c01.m(o7, o7.L, o7.i, false);
      int i = this.c.L.getVisibility();
      float f = this.c.L.getAlpha();
      (this.c.f()).n = f;
      o o4 = this.c;
      if (o4.K != null && i == 0) {
        View view2 = o4.L.findFocus();
        if (view2 != null) {
          (this.c.f()).o = view2;
          if (d0.O(2)) {
            StringBuilder stringBuilder1 = new StringBuilder();
            stringBuilder1.append("requestFocus: Saved focused view ");
            stringBuilder1.append(view2);
            stringBuilder1.append(" for Fragment ");
            stringBuilder1.append(this.c);
            Log.v("FragmentManager", stringBuilder1.toString());
          } 
        } 
        this.c.L.setAlpha(0.0F);
      } 
    } 
    this.c.h = 2;
  }
  
  public void g() {
    boolean bool1;
    boolean bool2;
    if (d0.O(3)) {
      StringBuilder stringBuilder = c.a("movefrom CREATED: ");
      stringBuilder.append(this.c);
      Log.d("FragmentManager", stringBuilder.toString());
    } 
    o o1 = this.c;
    boolean bool4 = o1.s;
    boolean bool3 = true;
    if (bool4 && !o1.B()) {
      bool1 = true;
    } else {
      bool1 = false;
    } 
    if (bool1 || this.b.c.c(this.c)) {
      bool2 = true;
    } else {
      bool2 = false;
    } 
    if (bool2) {
      int i;
      a0<?> a0 = this.c.z;
      if (a0 instanceof androidx.lifecycle.a0) {
        bool3 = this.b.c.f;
      } else {
        Context context = a0.i;
        if (context instanceof Activity)
          i = true ^ ((Activity)context).isChangingConfigurations(); 
      } 
      if (bool1 || i != 0) {
        g0 g01 = this.b.c;
        o o3 = this.c;
        Objects.requireNonNull(g01);
        if (d0.O(3)) {
          StringBuilder stringBuilder = new StringBuilder();
          stringBuilder.append("Clearing non-config state for ");
          stringBuilder.append(o3);
          Log.d("FragmentManager", stringBuilder.toString());
        } 
        g0 g02 = g01.c.get(o3.l);
        if (g02 != null) {
          g02.a();
          g01.c.remove(o3.l);
        } 
        z z = g01.d.get(o3.l);
        if (z != null) {
          z.a();
          g01.d.remove(o3.l);
        } 
      } 
      o o2 = this.c;
      o2.A.o();
      o2.T.d(e.b.ON_DESTROY);
      o2.h = 0;
      o2.J = false;
      o2.R = false;
      o2.I();
      if (o2.J) {
        this.a.d(this.c, false);
        for (j0 j01 : this.b.f()) {
          if (j01 != null) {
            o o3 = j01.c;
            if (this.c.l.equals(o3.o)) {
              o3.n = this.c;
              o3.o = null;
            } 
          } 
        } 
        o2 = this.c;
        String str1 = o2.o;
        if (str1 != null)
          o2.n = this.b.d(str1); 
        this.b.k(this);
        return;
      } 
      throw new g1(n.b("Fragment ", o2, " did not call through to super.onDestroy()"));
    } 
    String str = this.c.o;
    if (str != null) {
      o o2 = this.b.d(str);
      if (o2 != null && o2.H)
        this.c.n = o2; 
    } 
    this.c.h = 0;
  }
  
  public void h() {
    if (d0.O(3)) {
      StringBuilder stringBuilder = c.a("movefrom CREATE_VIEW: ");
      stringBuilder.append(this.c);
      Log.d("FragmentManager", stringBuilder.toString());
    } 
    o o2 = this.c;
    ViewGroup viewGroup = o2.K;
    if (viewGroup != null) {
      View view = o2.L;
      if (view != null)
        viewGroup.removeView(view); 
    } 
    this.c.U();
    this.a.n(this.c, false);
    o o1 = this.c;
    o1.K = null;
    o1.L = null;
    o1.U = null;
    o1.V.h(null);
    this.c.u = false;
  }
  
  public void i() {
    if (d0.O(3)) {
      StringBuilder stringBuilder = c.a("movefrom ATTACHED: ");
      stringBuilder.append(this.c);
      Log.d("FragmentManager", stringBuilder.toString());
    } 
    o o1 = this.c;
    o1.h = -1;
    o1.J = false;
    o1.K();
    if (o1.J) {
      boolean bool;
      d0 d0 = o1.A;
      if (!d0.D) {
        d0.o();
        o1.A = new e0();
      } 
      this.a.e(this.c, false);
      o1 = this.c;
      o1.h = -1;
      o1.z = null;
      o1.B = null;
      o1.y = null;
      if (o1.s && !o1.B()) {
        bool = true;
      } else {
        bool = false;
      } 
      if (bool || this.b.c.c(this.c)) {
        if (d0.O(3)) {
          StringBuilder stringBuilder = c.a("initState called for fragment: ");
          stringBuilder.append(this.c);
          Log.d("FragmentManager", stringBuilder.toString());
        } 
        o1 = this.c;
        Objects.requireNonNull(o1);
        o1.T = new j(o1);
        o1.W = new b(o1);
        o1.l = UUID.randomUUID().toString();
        o1.r = false;
        o1.s = false;
        o1.t = false;
        o1.u = false;
        o1.v = false;
        o1.x = 0;
        o1.y = null;
        o1.A = new e0();
        o1.z = null;
        o1.C = 0;
        o1.D = 0;
        o1.E = null;
        o1.F = false;
        o1.G = false;
      } 
      return;
    } 
    throw new g1(n.b("Fragment ", o1, " did not call through to super.onDetach()"));
  }
  
  public void j() {
    o o1 = this.c;
    if (o1.t && o1.u && !o1.w) {
      if (d0.O(3)) {
        StringBuilder stringBuilder = c.a("moveto CREATE_VIEW: ");
        stringBuilder.append(this.c);
        Log.d("FragmentManager", stringBuilder.toString());
      } 
      o1 = this.c;
      o1.T(o1.L(o1.i), null, this.c.i);
      View view = this.c.L;
      if (view != null) {
        view.setSaveFromParentEnabled(false);
        o o2 = this.c;
        o2.L.setTag(2131362069, o2);
        o2 = this.c;
        if (o2.F)
          o2.L.setVisibility(8); 
        o2 = this.c;
        o2.R(o2.L, o2.i);
        o2.A.w(2);
        c0 c01 = this.a;
        o o3 = this.c;
        c01.m(o3, o3.L, o3.i, false);
        this.c.h = 2;
      } 
    } 
  }
  
  public void k() {
    if (this.d) {
      if (d0.O(2)) {
        StringBuilder stringBuilder = c.a("Ignoring re-entrant call to moveToExpectedState() for ");
        stringBuilder.append(this.c);
        Log.v("FragmentManager", stringBuilder.toString());
      } 
      return;
    } 
    try {
      this.d = true;
      while (true) {
        b1 b12;
        o o1;
        b1 b11;
        int i = d();
        o o2 = this.c;
        int j = o2.h;
        if (i != j) {
          if (i > j) {
            switch (j + 1) {
              case 7:
                n();
                continue;
              case 6:
                o2.h = 6;
                continue;
              case 5:
                p();
                continue;
              case 4:
                if (o2.L != null) {
                  ViewGroup viewGroup = o2.K;
                  if (viewGroup != null) {
                    b12 = b1.g(viewGroup, o2.r().M());
                    i = e1.b(this.c.L.getVisibility());
                    Objects.requireNonNull(b12);
                    if (d0.O(2)) {
                      StringBuilder stringBuilder = new StringBuilder();
                      stringBuilder.append("SpecialEffectsController: Enqueuing add operation for fragment ");
                      stringBuilder.append(this.c);
                      Log.v("FragmentManager", stringBuilder.toString());
                    } 
                    b12.a(i, 2, this);
                  } 
                } 
                this.c.h = 4;
                continue;
              case 3:
                a();
                continue;
              case 2:
                j();
                f();
                continue;
              case 1:
                e();
                continue;
              case 0:
                c();
                continue;
            } 
            continue;
          } 
        } else {
          if (((o)b12).P) {
            if (((o)b12).L != null) {
              ViewGroup viewGroup = ((o)b12).K;
              if (viewGroup != null) {
                b12 = b1.g(viewGroup, b12.r().M());
                if (this.c.F) {
                  Objects.requireNonNull(b12);
                  if (d0.O(2)) {
                    StringBuilder stringBuilder = new StringBuilder();
                    stringBuilder.append("SpecialEffectsController: Enqueuing hide operation for fragment ");
                    stringBuilder.append(this.c);
                    Log.v("FragmentManager", stringBuilder.toString());
                  } 
                  b12.a(3, 1, this);
                } else {
                  Objects.requireNonNull(b12);
                  if (d0.O(2)) {
                    StringBuilder stringBuilder = new StringBuilder();
                    stringBuilder.append("SpecialEffectsController: Enqueuing show operation for fragment ");
                    stringBuilder.append(this.c);
                    Log.v("FragmentManager", stringBuilder.toString());
                  } 
                  b12.a(2, 1, this);
                } 
              } 
            } 
            o1 = this.c;
            d0 d0 = o1.y;
            if (d0 != null && o1.r && d0.P(o1))
              d0.A = true; 
            this.c.P = false;
          } 
          return;
        } 
        switch (j - 1) {
          case 6:
            l();
          case 5:
            o1.h = 5;
          case 4:
            q();
          case 3:
            if (d0.O(3)) {
              StringBuilder stringBuilder = new StringBuilder();
              stringBuilder.append("movefrom ACTIVITY_CREATED: ");
              stringBuilder.append(this.c);
              Log.d("FragmentManager", stringBuilder.toString());
            } 
            o1 = this.c;
            if (o1.L != null && o1.j == null)
              o(); 
            o1 = this.c;
            if (o1.L != null) {
              ViewGroup viewGroup = o1.K;
              if (viewGroup != null) {
                b11 = b1.g(viewGroup, o1.r().M());
                Objects.requireNonNull(b11);
                if (d0.O(2)) {
                  StringBuilder stringBuilder = new StringBuilder();
                  stringBuilder.append("SpecialEffectsController: Enqueuing remove operation for fragment ");
                  stringBuilder.append(this.c);
                  Log.v("FragmentManager", stringBuilder.toString());
                } 
                b11.a(1, 3, this);
              } 
            } 
            this.c.h = 3;
          case 2:
            ((o)b11).u = false;
            ((o)b11).h = 2;
          case 1:
            h();
            this.c.h = 1;
          case 0:
            g();
          case -1:
            i();
        } 
      } 
    } finally {
      this.d = false;
    } 
  }
  
  public void l() {
    if (d0.O(3)) {
      StringBuilder stringBuilder = c.a("movefrom RESUMED: ");
      stringBuilder.append(this.c);
      Log.d("FragmentManager", stringBuilder.toString());
    } 
    o o1 = this.c;
    o1.A.w(5);
    if (o1.L != null)
      o1.U.b(e.b.ON_PAUSE); 
    o1.T.d(e.b.ON_PAUSE);
    o1.h = 6;
    o1.J = false;
    o1.J = true;
    this.a.f(this.c, false);
  }
  
  public void m(ClassLoader paramClassLoader) {
    Bundle bundle = this.c.i;
    if (bundle == null)
      return; 
    bundle.setClassLoader(paramClassLoader);
    o o1 = this.c;
    o1.j = o1.i.getSparseParcelableArray("android:view_state");
    o1 = this.c;
    o1.k = o1.i.getBundle("android:view_registry_state");
    o1 = this.c;
    o1.o = o1.i.getString("android:target_state");
    o1 = this.c;
    if (o1.o != null)
      o1.p = o1.i.getInt("android:target_req_state", 0); 
    o1 = this.c;
    Objects.requireNonNull(o1);
    o1.N = o1.i.getBoolean("android:user_visible_hint", true);
    o1 = this.c;
    if (!o1.N)
      o1.M = true; 
  }
  
  public void n() {
    // Byte code:
    //   0: iconst_3
    //   1: invokestatic O : (I)Z
    //   4: ifeq -> 33
    //   7: ldc_w 'moveto RESUMED: '
    //   10: invokestatic a : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   13: astore_3
    //   14: aload_3
    //   15: aload_0
    //   16: getfield c : Landroidx/fragment/app/o;
    //   19: invokevirtual append : (Ljava/lang/Object;)Ljava/lang/StringBuilder;
    //   22: pop
    //   23: ldc 'FragmentManager'
    //   25: aload_3
    //   26: invokevirtual toString : ()Ljava/lang/String;
    //   29: invokestatic d : (Ljava/lang/String;Ljava/lang/String;)I
    //   32: pop
    //   33: aload_0
    //   34: getfield c : Landroidx/fragment/app/o;
    //   37: astore #4
    //   39: aload #4
    //   41: getfield O : Landroidx/fragment/app/o$b;
    //   44: astore_3
    //   45: aload_3
    //   46: ifnonnull -> 54
    //   49: aconst_null
    //   50: astore_3
    //   51: goto -> 59
    //   54: aload_3
    //   55: getfield o : Landroid/view/View;
    //   58: astore_3
    //   59: aload_3
    //   60: ifnull -> 244
    //   63: aload_3
    //   64: aload #4
    //   66: getfield L : Landroid/view/View;
    //   69: if_acmpne -> 75
    //   72: goto -> 98
    //   75: aload_3
    //   76: invokevirtual getParent : ()Landroid/view/ViewParent;
    //   79: astore #4
    //   81: aload #4
    //   83: ifnull -> 115
    //   86: aload #4
    //   88: aload_0
    //   89: getfield c : Landroidx/fragment/app/o;
    //   92: getfield L : Landroid/view/View;
    //   95: if_acmpne -> 103
    //   98: iconst_1
    //   99: istore_1
    //   100: goto -> 117
    //   103: aload #4
    //   105: invokeinterface getParent : ()Landroid/view/ViewParent;
    //   110: astore #4
    //   112: goto -> 81
    //   115: iconst_0
    //   116: istore_1
    //   117: iload_1
    //   118: ifeq -> 244
    //   121: aload_3
    //   122: invokevirtual requestFocus : ()Z
    //   125: istore_2
    //   126: iconst_2
    //   127: invokestatic O : (I)Z
    //   130: ifeq -> 244
    //   133: new java/lang/StringBuilder
    //   136: dup
    //   137: invokespecial <init> : ()V
    //   140: astore #4
    //   142: aload #4
    //   144: ldc_w 'requestFocus: Restoring focused view '
    //   147: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   150: pop
    //   151: aload #4
    //   153: aload_3
    //   154: invokevirtual append : (Ljava/lang/Object;)Ljava/lang/StringBuilder;
    //   157: pop
    //   158: aload #4
    //   160: ldc_w ' '
    //   163: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   166: pop
    //   167: iload_2
    //   168: ifeq -> 178
    //   171: ldc_w 'succeeded'
    //   174: astore_3
    //   175: goto -> 182
    //   178: ldc_w 'failed'
    //   181: astore_3
    //   182: aload #4
    //   184: aload_3
    //   185: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   188: pop
    //   189: aload #4
    //   191: ldc_w ' on Fragment '
    //   194: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   197: pop
    //   198: aload #4
    //   200: aload_0
    //   201: getfield c : Landroidx/fragment/app/o;
    //   204: invokevirtual append : (Ljava/lang/Object;)Ljava/lang/StringBuilder;
    //   207: pop
    //   208: aload #4
    //   210: ldc_w ' resulting in focused view '
    //   213: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   216: pop
    //   217: aload #4
    //   219: aload_0
    //   220: getfield c : Landroidx/fragment/app/o;
    //   223: getfield L : Landroid/view/View;
    //   226: invokevirtual findFocus : ()Landroid/view/View;
    //   229: invokevirtual append : (Ljava/lang/Object;)Ljava/lang/StringBuilder;
    //   232: pop
    //   233: ldc 'FragmentManager'
    //   235: aload #4
    //   237: invokevirtual toString : ()Ljava/lang/String;
    //   240: invokestatic v : (Ljava/lang/String;Ljava/lang/String;)I
    //   243: pop
    //   244: aload_0
    //   245: getfield c : Landroidx/fragment/app/o;
    //   248: aconst_null
    //   249: invokevirtual d0 : (Landroid/view/View;)V
    //   252: aload_0
    //   253: getfield c : Landroidx/fragment/app/o;
    //   256: astore_3
    //   257: aload_3
    //   258: getfield A : Landroidx/fragment/app/d0;
    //   261: invokevirtual V : ()V
    //   264: aload_3
    //   265: getfield A : Landroidx/fragment/app/d0;
    //   268: iconst_1
    //   269: invokevirtual C : (Z)Z
    //   272: pop
    //   273: aload_3
    //   274: bipush #7
    //   276: putfield h : I
    //   279: aload_3
    //   280: iconst_0
    //   281: putfield J : Z
    //   284: aload_3
    //   285: invokevirtual N : ()V
    //   288: aload_3
    //   289: getfield J : Z
    //   292: ifeq -> 391
    //   295: aload_3
    //   296: getfield T : Landroidx/lifecycle/j;
    //   299: astore #4
    //   301: getstatic androidx/lifecycle/e$b.ON_RESUME : Landroidx/lifecycle/e$b;
    //   304: astore #5
    //   306: aload #4
    //   308: aload #5
    //   310: invokevirtual d : (Landroidx/lifecycle/e$b;)V
    //   313: aload_3
    //   314: getfield L : Landroid/view/View;
    //   317: ifnull -> 329
    //   320: aload_3
    //   321: getfield U : Landroidx/fragment/app/x0;
    //   324: aload #5
    //   326: invokevirtual b : (Landroidx/lifecycle/e$b;)V
    //   329: aload_3
    //   330: getfield A : Landroidx/fragment/app/d0;
    //   333: astore_3
    //   334: aload_3
    //   335: iconst_0
    //   336: putfield B : Z
    //   339: aload_3
    //   340: iconst_0
    //   341: putfield C : Z
    //   344: aload_3
    //   345: getfield J : Landroidx/fragment/app/g0;
    //   348: iconst_0
    //   349: putfield g : Z
    //   352: aload_3
    //   353: bipush #7
    //   355: invokevirtual w : (I)V
    //   358: aload_0
    //   359: getfield a : Landroidx/fragment/app/c0;
    //   362: aload_0
    //   363: getfield c : Landroidx/fragment/app/o;
    //   366: iconst_0
    //   367: invokevirtual i : (Landroidx/fragment/app/o;Z)V
    //   370: aload_0
    //   371: getfield c : Landroidx/fragment/app/o;
    //   374: astore_3
    //   375: aload_3
    //   376: aconst_null
    //   377: putfield i : Landroid/os/Bundle;
    //   380: aload_3
    //   381: aconst_null
    //   382: putfield j : Landroid/util/SparseArray;
    //   385: aload_3
    //   386: aconst_null
    //   387: putfield k : Landroid/os/Bundle;
    //   390: return
    //   391: new androidx/fragment/app/g1
    //   394: dup
    //   395: ldc 'Fragment '
    //   397: aload_3
    //   398: ldc_w ' did not call through to super.onResume()'
    //   401: invokestatic b : (Ljava/lang/String;Landroidx/fragment/app/o;Ljava/lang/String;)Ljava/lang/String;
    //   404: invokespecial <init> : (Ljava/lang/String;)V
    //   407: athrow
  }
  
  public void o() {
    if (this.c.L == null)
      return; 
    SparseArray<Parcelable> sparseArray = new SparseArray();
    this.c.L.saveHierarchyState(sparseArray);
    if (sparseArray.size() > 0)
      this.c.j = sparseArray; 
    Bundle bundle = new Bundle();
    this.c.U.j.b(bundle);
    if (!bundle.isEmpty())
      this.c.k = bundle; 
  }
  
  public void p() {
    d0 d0;
    if (d0.O(3)) {
      StringBuilder stringBuilder = c.a("moveto STARTED: ");
      stringBuilder.append(this.c);
      Log.d("FragmentManager", stringBuilder.toString());
    } 
    o o1 = this.c;
    o1.A.V();
    o1.A.C(true);
    o1.h = 5;
    o1.J = false;
    o1.P();
    if (o1.J) {
      j j = o1.T;
      e.b b = e.b.ON_START;
      j.d(b);
      if (o1.L != null)
        o1.U.b(b); 
      d0 = o1.A;
      d0.B = false;
      d0.C = false;
      d0.J.g = false;
      d0.w(5);
      this.a.k(this.c, false);
      return;
    } 
    throw new g1(n.b("Fragment ", d0, " did not call through to super.onStart()"));
  }
  
  public void q() {
    if (d0.O(3)) {
      StringBuilder stringBuilder = c.a("movefrom STARTED: ");
      stringBuilder.append(this.c);
      Log.d("FragmentManager", stringBuilder.toString());
    } 
    o o1 = this.c;
    d0 d0 = o1.A;
    d0.C = true;
    d0.J.g = true;
    d0.w(4);
    if (o1.L != null)
      o1.U.b(e.b.ON_STOP); 
    o1.T.d(e.b.ON_STOP);
    o1.h = 4;
    o1.J = false;
    o1.Q();
    if (o1.J) {
      this.a.l(this.c, false);
      return;
    } 
    throw new g1(n.b("Fragment ", o1, " did not call through to super.onStop()"));
  }
  
  public class a implements View.OnAttachStateChangeListener {
    public a(j0 this$0, View param1View) {}
    
    public void onViewAttachedToWindow(View param1View) {
      this.h.removeOnAttachStateChangeListener(this);
      param1View = this.h;
      WeakHashMap weakHashMap = l.a;
      param1View.requestApplyInsets();
    }
    
    public void onViewDetachedFromWindow(View param1View) {}
  }
}


/* Location:              C:\soft\dex2jar-2.0\Luxury Logo Maker_ Logo Design-dex2jar.jar!\androidx\fragment\app\j0.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */