package androidx.fragment.app;

import android.view.View;

public abstract class w {
  public abstract View e(int paramInt);
  
  public abstract boolean f();
}


/* Location:              C:\soft\dex2jar-2.0\Luxury Logo Maker_ Logo Design-dex2jar.jar!\androidx\fragment\app\w.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */