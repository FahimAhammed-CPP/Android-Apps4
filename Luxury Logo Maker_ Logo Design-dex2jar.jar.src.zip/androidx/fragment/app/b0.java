package androidx.fragment.app;

import android.content.Context;
import android.util.AttributeSet;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

public class b0 implements LayoutInflater.Factory2 {
  public final d0 h;
  
  public b0(d0 paramd0) {
    this.h = paramd0;
  }
  
  public View onCreateView(View paramView, String paramString, Context paramContext, AttributeSet paramAttributeSet) {
    // Byte code:
    //   0: ldc androidx/fragment/app/x
    //   2: invokevirtual getName : ()Ljava/lang/String;
    //   5: aload_2
    //   6: invokevirtual equals : (Ljava/lang/Object;)Z
    //   9: ifeq -> 27
    //   12: new androidx/fragment/app/x
    //   15: dup
    //   16: aload_3
    //   17: aload #4
    //   19: aload_0
    //   20: getfield h : Landroidx/fragment/app/d0;
    //   23: invokespecial <init> : (Landroid/content/Context;Landroid/util/AttributeSet;Landroidx/fragment/app/d0;)V
    //   26: areturn
    //   27: ldc 'fragment'
    //   29: aload_2
    //   30: invokevirtual equals : (Ljava/lang/Object;)Z
    //   33: istore #8
    //   35: aconst_null
    //   36: astore_2
    //   37: iload #8
    //   39: ifne -> 44
    //   42: aconst_null
    //   43: areturn
    //   44: aload #4
    //   46: aconst_null
    //   47: ldc 'class'
    //   49: invokeinterface getAttributeValue : (Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;
    //   54: astore #9
    //   56: aload_3
    //   57: aload #4
    //   59: getstatic com/bumptech/glide/manager/i.p : [I
    //   62: invokevirtual obtainStyledAttributes : (Landroid/util/AttributeSet;[I)Landroid/content/res/TypedArray;
    //   65: astore #11
    //   67: iconst_0
    //   68: istore #5
    //   70: aload #9
    //   72: astore #10
    //   74: aload #9
    //   76: ifnonnull -> 87
    //   79: aload #11
    //   81: iconst_0
    //   82: invokevirtual getString : (I)Ljava/lang/String;
    //   85: astore #10
    //   87: aload #11
    //   89: iconst_1
    //   90: iconst_m1
    //   91: invokevirtual getResourceId : (II)I
    //   94: istore #7
    //   96: aload #11
    //   98: iconst_2
    //   99: invokevirtual getString : (I)Ljava/lang/String;
    //   102: astore #12
    //   104: aload #11
    //   106: invokevirtual recycle : ()V
    //   109: aload #10
    //   111: ifnull -> 783
    //   114: aload_3
    //   115: invokevirtual getClassLoader : ()Ljava/lang/ClassLoader;
    //   118: astore #9
    //   120: getstatic androidx/fragment/app/z.a : Lr/g;
    //   123: astore #11
    //   125: ldc androidx/fragment/app/o
    //   127: aload #9
    //   129: aload #10
    //   131: invokestatic b : (Ljava/lang/ClassLoader;Ljava/lang/String;)Ljava/lang/Class;
    //   134: invokevirtual isAssignableFrom : (Ljava/lang/Class;)Z
    //   137: istore #8
    //   139: goto -> 145
    //   142: iconst_0
    //   143: istore #8
    //   145: iload #8
    //   147: ifne -> 152
    //   150: aconst_null
    //   151: areturn
    //   152: aload_1
    //   153: ifnull -> 162
    //   156: aload_1
    //   157: invokevirtual getId : ()I
    //   160: istore #5
    //   162: iload #5
    //   164: iconst_m1
    //   165: if_icmpne -> 228
    //   168: iload #7
    //   170: iconst_m1
    //   171: if_icmpne -> 228
    //   174: aload #12
    //   176: ifnull -> 182
    //   179: goto -> 228
    //   182: new java/lang/StringBuilder
    //   185: dup
    //   186: invokespecial <init> : ()V
    //   189: astore_1
    //   190: aload_1
    //   191: aload #4
    //   193: invokeinterface getPositionDescription : ()Ljava/lang/String;
    //   198: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   201: pop
    //   202: aload_1
    //   203: ldc ': Must specify unique android:id, android:tag, or have a parent with an id for '
    //   205: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   208: pop
    //   209: aload_1
    //   210: aload #10
    //   212: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   215: pop
    //   216: new java/lang/IllegalArgumentException
    //   219: dup
    //   220: aload_1
    //   221: invokevirtual toString : ()Ljava/lang/String;
    //   224: invokespecial <init> : (Ljava/lang/String;)V
    //   227: athrow
    //   228: iload #7
    //   230: iconst_m1
    //   231: if_icmpeq -> 244
    //   234: aload_0
    //   235: getfield h : Landroidx/fragment/app/d0;
    //   238: iload #7
    //   240: invokevirtual H : (I)Landroidx/fragment/app/o;
    //   243: astore_2
    //   244: aload_2
    //   245: astore #9
    //   247: aload_2
    //   248: ifnonnull -> 270
    //   251: aload_2
    //   252: astore #9
    //   254: aload #12
    //   256: ifnull -> 270
    //   259: aload_0
    //   260: getfield h : Landroidx/fragment/app/d0;
    //   263: aload #12
    //   265: invokevirtual I : (Ljava/lang/String;)Landroidx/fragment/app/o;
    //   268: astore #9
    //   270: aload #9
    //   272: astore_2
    //   273: aload #9
    //   275: ifnonnull -> 297
    //   278: aload #9
    //   280: astore_2
    //   281: iload #5
    //   283: iconst_m1
    //   284: if_icmpeq -> 297
    //   287: aload_0
    //   288: getfield h : Landroidx/fragment/app/d0;
    //   291: iload #5
    //   293: invokevirtual H : (I)Landroidx/fragment/app/o;
    //   296: astore_2
    //   297: aload_2
    //   298: ifnonnull -> 453
    //   301: aload_0
    //   302: getfield h : Landroidx/fragment/app/d0;
    //   305: invokevirtual K : ()Landroidx/fragment/app/z;
    //   308: aload_3
    //   309: invokevirtual getClassLoader : ()Ljava/lang/ClassLoader;
    //   312: aload #10
    //   314: invokevirtual a : (Ljava/lang/ClassLoader;Ljava/lang/String;)Landroidx/fragment/app/o;
    //   317: astore_2
    //   318: aload_2
    //   319: iconst_1
    //   320: putfield t : Z
    //   323: iload #7
    //   325: ifeq -> 335
    //   328: iload #7
    //   330: istore #6
    //   332: goto -> 339
    //   335: iload #5
    //   337: istore #6
    //   339: aload_2
    //   340: iload #6
    //   342: putfield C : I
    //   345: aload_2
    //   346: iload #5
    //   348: putfield D : I
    //   351: aload_2
    //   352: aload #12
    //   354: putfield E : Ljava/lang/String;
    //   357: aload_2
    //   358: iconst_1
    //   359: putfield u : Z
    //   362: aload_0
    //   363: getfield h : Landroidx/fragment/app/d0;
    //   366: astore_3
    //   367: aload_2
    //   368: aload_3
    //   369: putfield y : Landroidx/fragment/app/d0;
    //   372: aload_3
    //   373: getfield q : Landroidx/fragment/app/a0;
    //   376: astore_3
    //   377: aload_2
    //   378: aload_3
    //   379: putfield z : Landroidx/fragment/app/a0;
    //   382: aload_2
    //   383: aload_3
    //   384: getfield i : Landroid/content/Context;
    //   387: aload #4
    //   389: aload_2
    //   390: getfield i : Landroid/os/Bundle;
    //   393: invokevirtual M : (Landroid/content/Context;Landroid/util/AttributeSet;Landroid/os/Bundle;)V
    //   396: aload_0
    //   397: getfield h : Landroidx/fragment/app/d0;
    //   400: aload_2
    //   401: invokevirtual a : (Landroidx/fragment/app/o;)Landroidx/fragment/app/j0;
    //   404: astore #9
    //   406: aload_2
    //   407: astore #4
    //   409: aload #9
    //   411: astore_3
    //   412: iconst_2
    //   413: invokestatic O : (I)Z
    //   416: ifeq -> 586
    //   419: new java/lang/StringBuilder
    //   422: dup
    //   423: invokespecial <init> : ()V
    //   426: astore #11
    //   428: aload #11
    //   430: ldc 'Fragment '
    //   432: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   435: pop
    //   436: aload #11
    //   438: aload_2
    //   439: invokevirtual append : (Ljava/lang/Object;)Ljava/lang/StringBuilder;
    //   442: pop
    //   443: ldc ' has been inflated via the <fragment> tag: id=0x'
    //   445: astore #4
    //   447: aload #9
    //   449: astore_3
    //   450: goto -> 553
    //   453: aload_2
    //   454: getfield u : Z
    //   457: ifne -> 685
    //   460: aload_2
    //   461: iconst_1
    //   462: putfield u : Z
    //   465: aload_0
    //   466: getfield h : Landroidx/fragment/app/d0;
    //   469: astore_3
    //   470: aload_2
    //   471: aload_3
    //   472: putfield y : Landroidx/fragment/app/d0;
    //   475: aload_3
    //   476: getfield q : Landroidx/fragment/app/a0;
    //   479: astore_3
    //   480: aload_2
    //   481: aload_3
    //   482: putfield z : Landroidx/fragment/app/a0;
    //   485: aload_2
    //   486: aload_3
    //   487: getfield i : Landroid/content/Context;
    //   490: aload #4
    //   492: aload_2
    //   493: getfield i : Landroid/os/Bundle;
    //   496: invokevirtual M : (Landroid/content/Context;Landroid/util/AttributeSet;Landroid/os/Bundle;)V
    //   499: aload_0
    //   500: getfield h : Landroidx/fragment/app/d0;
    //   503: aload_2
    //   504: invokevirtual h : (Landroidx/fragment/app/o;)Landroidx/fragment/app/j0;
    //   507: astore #9
    //   509: aload_2
    //   510: astore #4
    //   512: aload #9
    //   514: astore_3
    //   515: iconst_2
    //   516: invokestatic O : (I)Z
    //   519: ifeq -> 586
    //   522: new java/lang/StringBuilder
    //   525: dup
    //   526: invokespecial <init> : ()V
    //   529: astore #11
    //   531: aload #11
    //   533: ldc 'Retained Fragment '
    //   535: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   538: pop
    //   539: aload #11
    //   541: aload_2
    //   542: invokevirtual append : (Ljava/lang/Object;)Ljava/lang/StringBuilder;
    //   545: pop
    //   546: ldc ' has been re-attached via the <fragment> tag: id=0x'
    //   548: astore #4
    //   550: aload #9
    //   552: astore_3
    //   553: aload #11
    //   555: aload #4
    //   557: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   560: pop
    //   561: aload #11
    //   563: iload #7
    //   565: invokestatic toHexString : (I)Ljava/lang/String;
    //   568: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   571: pop
    //   572: ldc 'FragmentManager'
    //   574: aload #11
    //   576: invokevirtual toString : ()Ljava/lang/String;
    //   579: invokestatic v : (Ljava/lang/String;Ljava/lang/String;)I
    //   582: pop
    //   583: aload_2
    //   584: astore #4
    //   586: aload #4
    //   588: aload_1
    //   589: checkcast android/view/ViewGroup
    //   592: putfield K : Landroid/view/ViewGroup;
    //   595: aload_3
    //   596: invokevirtual k : ()V
    //   599: aload_3
    //   600: invokevirtual j : ()V
    //   603: aload #4
    //   605: getfield L : Landroid/view/View;
    //   608: astore_1
    //   609: aload_1
    //   610: ifnull -> 668
    //   613: iload #7
    //   615: ifeq -> 624
    //   618: aload_1
    //   619: iload #7
    //   621: invokevirtual setId : (I)V
    //   624: aload #4
    //   626: getfield L : Landroid/view/View;
    //   629: invokevirtual getTag : ()Ljava/lang/Object;
    //   632: ifnonnull -> 645
    //   635: aload #4
    //   637: getfield L : Landroid/view/View;
    //   640: aload #12
    //   642: invokevirtual setTag : (Ljava/lang/Object;)V
    //   645: aload #4
    //   647: getfield L : Landroid/view/View;
    //   650: new androidx/fragment/app/b0$a
    //   653: dup
    //   654: aload_0
    //   655: aload_3
    //   656: invokespecial <init> : (Landroidx/fragment/app/b0;Landroidx/fragment/app/j0;)V
    //   659: invokevirtual addOnAttachStateChangeListener : (Landroid/view/View$OnAttachStateChangeListener;)V
    //   662: aload #4
    //   664: getfield L : Landroid/view/View;
    //   667: areturn
    //   668: new java/lang/IllegalStateException
    //   671: dup
    //   672: ldc 'Fragment '
    //   674: aload #10
    //   676: ldc ' did not create a view.'
    //   678: invokestatic a : (Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;
    //   681: invokespecial <init> : (Ljava/lang/String;)V
    //   684: athrow
    //   685: new java/lang/StringBuilder
    //   688: dup
    //   689: invokespecial <init> : ()V
    //   692: astore_1
    //   693: aload_1
    //   694: aload #4
    //   696: invokeinterface getPositionDescription : ()Ljava/lang/String;
    //   701: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   704: pop
    //   705: aload_1
    //   706: ldc_w ': Duplicate id 0x'
    //   709: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   712: pop
    //   713: aload_1
    //   714: iload #7
    //   716: invokestatic toHexString : (I)Ljava/lang/String;
    //   719: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   722: pop
    //   723: aload_1
    //   724: ldc_w ', tag '
    //   727: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   730: pop
    //   731: aload_1
    //   732: aload #12
    //   734: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   737: pop
    //   738: aload_1
    //   739: ldc_w ', or parent id 0x'
    //   742: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   745: pop
    //   746: aload_1
    //   747: iload #5
    //   749: invokestatic toHexString : (I)Ljava/lang/String;
    //   752: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   755: pop
    //   756: aload_1
    //   757: ldc_w ' with another fragment for '
    //   760: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   763: pop
    //   764: aload_1
    //   765: aload #10
    //   767: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   770: pop
    //   771: new java/lang/IllegalArgumentException
    //   774: dup
    //   775: aload_1
    //   776: invokevirtual toString : ()Ljava/lang/String;
    //   779: invokespecial <init> : (Ljava/lang/String;)V
    //   782: athrow
    //   783: aconst_null
    //   784: areturn
    //   785: astore #9
    //   787: goto -> 142
    // Exception table:
    //   from	to	target	type
    //   125	139	785	java/lang/ClassNotFoundException
  }
  
  public View onCreateView(String paramString, Context paramContext, AttributeSet paramAttributeSet) {
    return onCreateView(null, paramString, paramContext, paramAttributeSet);
  }
  
  public class a implements View.OnAttachStateChangeListener {
    public a(b0 this$0, j0 param1j0) {}
    
    public void onViewAttachedToWindow(View param1View) {
      j0 j01 = this.h;
      o o = j01.c;
      j01.k();
      b1.f((ViewGroup)o.L.getParent(), this.i.h).e();
    }
    
    public void onViewDetachedFromWindow(View param1View) {}
  }
}


/* Location:              C:\soft\dex2jar-2.0\Luxury Logo Maker_ Logo Design-dex2jar.jar!\androidx\fragment\app\b0.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */