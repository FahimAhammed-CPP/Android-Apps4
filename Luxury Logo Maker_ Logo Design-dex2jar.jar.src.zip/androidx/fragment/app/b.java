package androidx.fragment.app;

import android.support.v4.media.c;
import android.util.Log;
import java.io.PrintWriter;
import java.lang.reflect.Modifier;
import java.util.ArrayList;

public final class b extends l0 implements d0.l {
  public final d0 p;
  
  public boolean q;
  
  public int r = -1;
  
  public b(d0 paramd0) {
    super(z, (ClassLoader)a0);
    this.p = paramd0;
  }
  
  public boolean a(ArrayList<b> paramArrayList, ArrayList<Boolean> paramArrayList1) {
    if (d0.O(2)) {
      StringBuilder stringBuilder = new StringBuilder();
      stringBuilder.append("Run: ");
      stringBuilder.append(this);
      Log.v("FragmentManager", stringBuilder.toString());
    } 
    paramArrayList.add(this);
    paramArrayList1.add(Boolean.FALSE);
    if (this.g) {
      d0 d01 = this.p;
      if (d01.d == null)
        d01.d = new ArrayList<b>(); 
      d01.d.add(this);
    } 
    return true;
  }
  
  public void c(int paramInt1, o paramo, String paramString, int paramInt2) {
    StringBuilder stringBuilder2;
    Class<?> clazz = paramo.getClass();
    int i = clazz.getModifiers();
    if (!clazz.isAnonymousClass() && Modifier.isPublic(i) && (!clazz.isMemberClass() || Modifier.isStatic(i))) {
      if (paramString != null) {
        String str = paramo.E;
        if (str == null || paramString.equals(str)) {
          paramo.E = paramString;
        } else {
          stringBuilder2 = new StringBuilder();
          stringBuilder2.append("Can't change tag of fragment ");
          stringBuilder2.append(paramo);
          stringBuilder2.append(": was ");
          throw new IllegalStateException(a.a(stringBuilder2, paramo.E, " now ", paramString));
        } 
      } 
      if (paramInt1 != 0) {
        StringBuilder stringBuilder;
        if (paramInt1 != -1) {
          i = paramo.C;
          if (i == 0 || i == paramInt1) {
            paramo.C = paramInt1;
            paramo.D = paramInt1;
          } else {
            stringBuilder = new StringBuilder();
            stringBuilder.append("Can't change container ID of fragment ");
            stringBuilder.append(paramo);
            stringBuilder.append(": was ");
            stringBuilder.append(paramo.C);
            stringBuilder.append(" now ");
            stringBuilder.append(paramInt1);
            throw new IllegalStateException(stringBuilder.toString());
          } 
        } else {
          stringBuilder2 = new StringBuilder();
          stringBuilder2.append("Can't add fragment ");
          stringBuilder2.append(paramo);
          stringBuilder2.append(" with tag ");
          stringBuilder2.append((String)stringBuilder);
          stringBuilder2.append(" to container view with no id");
          throw new IllegalArgumentException(stringBuilder2.toString());
        } 
      } 
      b(new l0.a(paramInt2, paramo));
      paramo.y = this.p;
      return;
    } 
    StringBuilder stringBuilder1 = c.a("Fragment ");
    stringBuilder1.append(stringBuilder2.getCanonicalName());
    stringBuilder1.append(" must be a public static class to be  properly recreated from instance state.");
    throw new IllegalStateException(stringBuilder1.toString());
  }
  
  public void e(int paramInt) {
    if (!this.g)
      return; 
    if (d0.O(2)) {
      StringBuilder stringBuilder = new StringBuilder();
      stringBuilder.append("Bump nesting in ");
      stringBuilder.append(this);
      stringBuilder.append(" by ");
      stringBuilder.append(paramInt);
      Log.v("FragmentManager", stringBuilder.toString());
    } 
    int j = this.a.size();
    for (int i = 0; i < j; i++) {
      l0.a a = this.a.get(i);
      o o = a.b;
      if (o != null) {
        o.x += paramInt;
        if (d0.O(2)) {
          StringBuilder stringBuilder = c.a("Bump nesting of ");
          stringBuilder.append(a.b);
          stringBuilder.append(" to ");
          stringBuilder.append(a.b.x);
          Log.v("FragmentManager", stringBuilder.toString());
        } 
      } 
    } 
  }
  
  public int f() {
    return h(false);
  }
  
  public int g() {
    return h(true);
  }
  
  public int h(boolean paramBoolean) {
    if (!this.q) {
      byte b1;
      if (d0.O(2)) {
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("Commit: ");
        stringBuilder.append(this);
        Log.v("FragmentManager", stringBuilder.toString());
        PrintWriter printWriter = new PrintWriter(new y0("FragmentManager"));
        i("  ", printWriter, true);
        printWriter.close();
      } 
      this.q = true;
      if (this.g) {
        b1 = this.p.i.getAndIncrement();
      } else {
        b1 = -1;
      } 
      this.r = b1;
      this.p.A(this, paramBoolean);
      return this.r;
    } 
    throw new IllegalStateException("commit already called");
  }
  
  public void i(String paramString, PrintWriter paramPrintWriter, boolean paramBoolean) {
    if (paramBoolean) {
      paramPrintWriter.print(paramString);
      paramPrintWriter.print("mName=");
      paramPrintWriter.print(this.h);
      paramPrintWriter.print(" mIndex=");
      paramPrintWriter.print(this.r);
      paramPrintWriter.print(" mCommitted=");
      paramPrintWriter.println(this.q);
      if (this.f != 0) {
        paramPrintWriter.print(paramString);
        paramPrintWriter.print("mTransition=#");
        paramPrintWriter.print(Integer.toHexString(this.f));
      } 
      if (this.b != 0 || this.c != 0) {
        paramPrintWriter.print(paramString);
        paramPrintWriter.print("mEnterAnim=#");
        paramPrintWriter.print(Integer.toHexString(this.b));
        paramPrintWriter.print(" mExitAnim=#");
        paramPrintWriter.println(Integer.toHexString(this.c));
      } 
      if (this.d != 0 || this.e != 0) {
        paramPrintWriter.print(paramString);
        paramPrintWriter.print("mPopEnterAnim=#");
        paramPrintWriter.print(Integer.toHexString(this.d));
        paramPrintWriter.print(" mPopExitAnim=#");
        paramPrintWriter.println(Integer.toHexString(this.e));
      } 
      if (this.i != 0 || this.j != null) {
        paramPrintWriter.print(paramString);
        paramPrintWriter.print("mBreadCrumbTitleRes=#");
        paramPrintWriter.print(Integer.toHexString(this.i));
        paramPrintWriter.print(" mBreadCrumbTitleText=");
        paramPrintWriter.println(this.j);
      } 
      if (this.k != 0 || this.l != null) {
        paramPrintWriter.print(paramString);
        paramPrintWriter.print("mBreadCrumbShortTitleRes=#");
        paramPrintWriter.print(Integer.toHexString(this.k));
        paramPrintWriter.print(" mBreadCrumbShortTitleText=");
        paramPrintWriter.println(this.l);
      } 
    } 
    if (!this.a.isEmpty()) {
      paramPrintWriter.print(paramString);
      paramPrintWriter.println("Operations:");
      int j = this.a.size();
      int i;
      for (i = 0; i < j; i++) {
        StringBuilder stringBuilder;
        String str;
        l0.a a = this.a.get(i);
        switch (a.a) {
          default:
            stringBuilder = c.a("cmd=");
            stringBuilder.append(a.a);
            str = stringBuilder.toString();
            break;
          case 10:
            str = "OP_SET_MAX_LIFECYCLE";
            break;
          case 9:
            str = "UNSET_PRIMARY_NAV";
            break;
          case 8:
            str = "SET_PRIMARY_NAV";
            break;
          case 7:
            str = "ATTACH";
            break;
          case 6:
            str = "DETACH";
            break;
          case 5:
            str = "SHOW";
            break;
          case 4:
            str = "HIDE";
            break;
          case 3:
            str = "REMOVE";
            break;
          case 2:
            str = "REPLACE";
            break;
          case 1:
            str = "ADD";
            break;
          case 0:
            str = "NULL";
            break;
        } 
        paramPrintWriter.print(paramString);
        paramPrintWriter.print("  Op #");
        paramPrintWriter.print(i);
        paramPrintWriter.print(": ");
        paramPrintWriter.print(str);
        paramPrintWriter.print(" ");
        paramPrintWriter.println(a.b);
        if (paramBoolean) {
          if (a.c != 0 || a.d != 0) {
            paramPrintWriter.print(paramString);
            paramPrintWriter.print("enterAnim=#");
            paramPrintWriter.print(Integer.toHexString(a.c));
            paramPrintWriter.print(" exitAnim=#");
            paramPrintWriter.println(Integer.toHexString(a.d));
          } 
          if (a.e != 0 || a.f != 0) {
            paramPrintWriter.print(paramString);
            paramPrintWriter.print("popEnterAnim=#");
            paramPrintWriter.print(Integer.toHexString(a.e));
            paramPrintWriter.print(" popExitAnim=#");
            paramPrintWriter.println(Integer.toHexString(a.f));
          } 
        } 
      } 
    } 
  }
  
  public void j() {
    int j = this.a.size();
    for (int i = 0; i < j; i++) {
      d0 d01;
      StringBuilder stringBuilder;
      l0.a a = this.a.get(i);
      o o = a.b;
      if (o != null) {
        o.g0(false);
        int k = this.f;
        if (o.O != null || k != 0) {
          o.f();
          o.O.h = k;
        } 
        ArrayList<String> arrayList1 = this.m;
        ArrayList<String> arrayList2 = this.n;
        o.f();
        o.b b1 = o.O;
        b1.i = arrayList1;
        b1.j = arrayList2;
      } 
      switch (a.a) {
        default:
          stringBuilder = c.a("Unknown cmd: ");
          stringBuilder.append(a.a);
          throw new IllegalArgumentException(stringBuilder.toString());
        case 10:
          this.p.e0((o)stringBuilder, a.h);
          break;
        case 9:
          d01 = this.p;
          stringBuilder = null;
          d01.f0((o)stringBuilder);
          break;
        case 8:
          d01 = this.p;
          d01.f0((o)stringBuilder);
          break;
        case 7:
          stringBuilder.a0(((l0.a)d01).c, ((l0.a)d01).d, ((l0.a)d01).e, ((l0.a)d01).f);
          this.p.d0((o)stringBuilder, false);
          this.p.c((o)stringBuilder);
          break;
        case 6:
          stringBuilder.a0(((l0.a)d01).c, ((l0.a)d01).d, ((l0.a)d01).e, ((l0.a)d01).f);
          this.p.j((o)stringBuilder);
          break;
        case 5:
          stringBuilder.a0(((l0.a)d01).c, ((l0.a)d01).d, ((l0.a)d01).e, ((l0.a)d01).f);
          this.p.d0((o)stringBuilder, false);
          this.p.h0((o)stringBuilder);
          break;
        case 4:
          stringBuilder.a0(((l0.a)d01).c, ((l0.a)d01).d, ((l0.a)d01).e, ((l0.a)d01).f);
          this.p.N((o)stringBuilder);
          break;
        case 3:
          stringBuilder.a0(((l0.a)d01).c, ((l0.a)d01).d, ((l0.a)d01).e, ((l0.a)d01).f);
          this.p.Y((o)stringBuilder);
          break;
        case 1:
          stringBuilder.a0(((l0.a)d01).c, ((l0.a)d01).d, ((l0.a)d01).e, ((l0.a)d01).f);
          this.p.d0((o)stringBuilder, false);
          this.p.a((o)stringBuilder);
          break;
      } 
    } 
  }
  
  public void k(boolean paramBoolean) {
    for (int i = this.a.size() - 1; i >= 0; i--) {
      d0 d01;
      StringBuilder stringBuilder;
      l0.a a = this.a.get(i);
      o o = a.b;
      if (o != null) {
        o.g0(true);
        int j = this.f;
        char c = ' ';
        if (j != 4097)
          if (j != 4099) {
            if (j != 8194) {
              c = Character.MIN_VALUE;
            } else {
              c = 'ခ';
            } 
          } else {
            c = 'ဃ';
          }  
        if (o.O != null || c != '\000') {
          o.f();
          o.O.h = c;
        } 
        ArrayList<String> arrayList1 = this.n;
        ArrayList<String> arrayList2 = this.m;
        o.f();
        o.b b1 = o.O;
        b1.i = arrayList1;
        b1.j = arrayList2;
      } 
      switch (a.a) {
        default:
          stringBuilder = c.a("Unknown cmd: ");
          stringBuilder.append(a.a);
          throw new IllegalArgumentException(stringBuilder.toString());
        case 10:
          this.p.e0((o)stringBuilder, a.g);
          break;
        case 9:
          d01 = this.p;
          d01.f0((o)stringBuilder);
          break;
        case 8:
          d01 = this.p;
          stringBuilder = null;
          d01.f0((o)stringBuilder);
          break;
        case 7:
          stringBuilder.a0(((l0.a)d01).c, ((l0.a)d01).d, ((l0.a)d01).e, ((l0.a)d01).f);
          this.p.d0((o)stringBuilder, true);
          this.p.j((o)stringBuilder);
          break;
        case 6:
          stringBuilder.a0(((l0.a)d01).c, ((l0.a)d01).d, ((l0.a)d01).e, ((l0.a)d01).f);
          this.p.c((o)stringBuilder);
          break;
        case 5:
          stringBuilder.a0(((l0.a)d01).c, ((l0.a)d01).d, ((l0.a)d01).e, ((l0.a)d01).f);
          this.p.d0((o)stringBuilder, true);
          this.p.N((o)stringBuilder);
          break;
        case 4:
          stringBuilder.a0(((l0.a)d01).c, ((l0.a)d01).d, ((l0.a)d01).e, ((l0.a)d01).f);
          this.p.h0((o)stringBuilder);
          break;
        case 3:
          stringBuilder.a0(((l0.a)d01).c, ((l0.a)d01).d, ((l0.a)d01).e, ((l0.a)d01).f);
          this.p.a((o)stringBuilder);
          break;
        case 1:
          stringBuilder.a0(((l0.a)d01).c, ((l0.a)d01).d, ((l0.a)d01).e, ((l0.a)d01).f);
          this.p.d0((o)stringBuilder, true);
          this.p.Y((o)stringBuilder);
          break;
      } 
    } 
  }
  
  public boolean l(int paramInt) {
    int j = this.a.size();
    for (int i = 0; i < j; i++) {
      int k;
      o o = ((l0.a)this.a.get(i)).b;
      if (o != null) {
        k = o.D;
      } else {
        k = 0;
      } 
      if (k && k == paramInt)
        return true; 
    } 
    return false;
  }
  
  public boolean m(ArrayList<b> paramArrayList, int paramInt1, int paramInt2) {
    if (paramInt2 == paramInt1)
      return false; 
    int k = this.a.size();
    int j = -1;
    int i = 0;
    while (i < k) {
      int m;
      o o = ((l0.a)this.a.get(i)).b;
      if (o != null) {
        m = o.D;
      } else {
        m = 0;
      } 
      int n = j;
      if (m) {
        n = j;
        if (m != j) {
          for (j = paramInt1; j < paramInt2; j++) {
            b b1 = paramArrayList.get(j);
            int i1 = b1.a.size();
            for (n = 0; n < i1; n++) {
              int i2;
              o o1 = ((l0.a)b1.a.get(n)).b;
              if (o1 != null) {
                i2 = o1.D;
              } else {
                i2 = 0;
              } 
              if (i2 == m)
                return true; 
            } 
          } 
          n = m;
        } 
      } 
      i++;
      j = n;
    } 
    return false;
  }
  
  public l0 n(o paramo) {
    d0 d01 = paramo.y;
    if (d01 == null || d01 == this.p) {
      b(new l0.a(3, paramo));
      return this;
    } 
    StringBuilder stringBuilder = c.a("Cannot remove Fragment attached to a different FragmentManager. Fragment ");
    stringBuilder.append(paramo.toString());
    stringBuilder.append(" is already attached to a FragmentManager.");
    throw new IllegalStateException(stringBuilder.toString());
  }
  
  public String toString() {
    StringBuilder stringBuilder = new StringBuilder(128);
    stringBuilder.append("BackStackEntry{");
    stringBuilder.append(Integer.toHexString(System.identityHashCode(this)));
    if (this.r >= 0) {
      stringBuilder.append(" #");
      stringBuilder.append(this.r);
    } 
    if (this.h != null) {
      stringBuilder.append(" ");
      stringBuilder.append(this.h);
    } 
    stringBuilder.append("}");
    return stringBuilder.toString();
  }
}


/* Location:              C:\soft\dex2jar-2.0\Luxury Logo Maker_ Logo Design-dex2jar.jar!\androidx\fragment\app\b.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */