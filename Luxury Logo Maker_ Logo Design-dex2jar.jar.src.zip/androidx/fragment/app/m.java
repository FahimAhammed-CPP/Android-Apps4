package androidx.fragment.app;

import android.annotation.SuppressLint;
import android.app.Dialog;
import android.content.Context;
import android.content.DialogInterface;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import androidx.appcompat.widget.y;
import androidx.lifecycle.i;
import androidx.lifecycle.p;

public class m extends o implements DialogInterface.OnCancelListener, DialogInterface.OnDismissListener {
  public Handler Z;
  
  public Runnable a0 = new a(this);
  
  public DialogInterface.OnCancelListener b0 = new b(this);
  
  public DialogInterface.OnDismissListener c0 = new c(this);
  
  public int d0 = 0;
  
  public int e0 = 0;
  
  public boolean f0 = true;
  
  public boolean g0 = true;
  
  public int h0 = -1;
  
  public boolean i0;
  
  public p<i> j0 = new d(this);
  
  public Dialog k0;
  
  public boolean l0;
  
  public boolean m0;
  
  public boolean n0;
  
  public boolean o0 = false;
  
  public void F(Context paramContext) {
    super.F(paramContext);
    this.V.d(this.j0);
    if (!this.n0)
      this.m0 = false; 
  }
  
  public void G(Bundle paramBundle) {
    boolean bool;
    super.G(paramBundle);
    this.Z = new Handler();
    if (this.D == 0) {
      bool = true;
    } else {
      bool = false;
    } 
    this.g0 = bool;
    if (paramBundle != null) {
      this.d0 = paramBundle.getInt("android:style", 0);
      this.e0 = paramBundle.getInt("android:theme", 0);
      this.f0 = paramBundle.getBoolean("android:cancelable", true);
      this.g0 = paramBundle.getBoolean("android:showsDialog", this.g0);
      this.h0 = paramBundle.getInt("android:backStackId", -1);
    } 
  }
  
  public void J() {
    this.J = true;
    Dialog dialog = this.k0;
    if (dialog != null) {
      this.l0 = true;
      dialog.setOnDismissListener(null);
      this.k0.dismiss();
      if (!this.m0)
        onDismiss((DialogInterface)this.k0); 
      this.k0 = null;
      this.o0 = false;
    } 
  }
  
  public void K() {
    this.J = true;
    if (!this.n0 && !this.m0)
      this.m0 = true; 
    this.V.g(this.j0);
  }
  
  public LayoutInflater L(Bundle paramBundle) {
    // Byte code:
    //   0: aload_0
    //   1: aload_1
    //   2: invokespecial L : (Landroid/os/Bundle;)Landroid/view/LayoutInflater;
    //   5: astore #5
    //   7: aload_0
    //   8: getfield g0 : Z
    //   11: istore_3
    //   12: iload_3
    //   13: ifeq -> 267
    //   16: aload_0
    //   17: getfield i0 : Z
    //   20: ifeq -> 26
    //   23: goto -> 267
    //   26: iload_3
    //   27: ifne -> 33
    //   30: goto -> 195
    //   33: aload_0
    //   34: getfield o0 : Z
    //   37: ifne -> 195
    //   40: aload_0
    //   41: iconst_1
    //   42: putfield i0 : Z
    //   45: aload_0
    //   46: aload_1
    //   47: invokevirtual k0 : (Landroid/os/Bundle;)Landroid/app/Dialog;
    //   50: astore_1
    //   51: aload_0
    //   52: aload_1
    //   53: putfield k0 : Landroid/app/Dialog;
    //   56: aload_0
    //   57: getfield g0 : Z
    //   60: ifeq -> 174
    //   63: aload_0
    //   64: getfield d0 : I
    //   67: istore_2
    //   68: iload_2
    //   69: iconst_1
    //   70: if_icmpeq -> 104
    //   73: iload_2
    //   74: iconst_2
    //   75: if_icmpeq -> 104
    //   78: iload_2
    //   79: iconst_3
    //   80: if_icmpeq -> 86
    //   83: goto -> 110
    //   86: aload_1
    //   87: invokevirtual getWindow : ()Landroid/view/Window;
    //   90: astore #4
    //   92: aload #4
    //   94: ifnull -> 104
    //   97: aload #4
    //   99: bipush #24
    //   101: invokevirtual addFlags : (I)V
    //   104: aload_1
    //   105: iconst_1
    //   106: invokevirtual requestWindowFeature : (I)Z
    //   109: pop
    //   110: aload_0
    //   111: invokevirtual i : ()Landroid/content/Context;
    //   114: astore_1
    //   115: aload_1
    //   116: instanceof android/app/Activity
    //   119: ifeq -> 133
    //   122: aload_0
    //   123: getfield k0 : Landroid/app/Dialog;
    //   126: aload_1
    //   127: checkcast android/app/Activity
    //   130: invokevirtual setOwnerActivity : (Landroid/app/Activity;)V
    //   133: aload_0
    //   134: getfield k0 : Landroid/app/Dialog;
    //   137: aload_0
    //   138: getfield f0 : Z
    //   141: invokevirtual setCancelable : (Z)V
    //   144: aload_0
    //   145: getfield k0 : Landroid/app/Dialog;
    //   148: aload_0
    //   149: getfield b0 : Landroid/content/DialogInterface$OnCancelListener;
    //   152: invokevirtual setOnCancelListener : (Landroid/content/DialogInterface$OnCancelListener;)V
    //   155: aload_0
    //   156: getfield k0 : Landroid/app/Dialog;
    //   159: aload_0
    //   160: getfield c0 : Landroid/content/DialogInterface$OnDismissListener;
    //   163: invokevirtual setOnDismissListener : (Landroid/content/DialogInterface$OnDismissListener;)V
    //   166: aload_0
    //   167: iconst_1
    //   168: putfield o0 : Z
    //   171: goto -> 179
    //   174: aload_0
    //   175: aconst_null
    //   176: putfield k0 : Landroid/app/Dialog;
    //   179: aload_0
    //   180: iconst_0
    //   181: putfield i0 : Z
    //   184: goto -> 195
    //   187: astore_1
    //   188: aload_0
    //   189: iconst_0
    //   190: putfield i0 : Z
    //   193: aload_1
    //   194: athrow
    //   195: iconst_2
    //   196: invokestatic O : (I)Z
    //   199: ifeq -> 240
    //   202: new java/lang/StringBuilder
    //   205: dup
    //   206: invokespecial <init> : ()V
    //   209: astore_1
    //   210: aload_1
    //   211: ldc 'get layout inflater for DialogFragment '
    //   213: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   216: pop
    //   217: aload_1
    //   218: aload_0
    //   219: invokevirtual append : (Ljava/lang/Object;)Ljava/lang/StringBuilder;
    //   222: pop
    //   223: aload_1
    //   224: ldc ' from dialog context'
    //   226: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   229: pop
    //   230: ldc 'FragmentManager'
    //   232: aload_1
    //   233: invokevirtual toString : ()Ljava/lang/String;
    //   236: invokestatic d : (Ljava/lang/String;Ljava/lang/String;)I
    //   239: pop
    //   240: aload_0
    //   241: getfield k0 : Landroid/app/Dialog;
    //   244: astore #4
    //   246: aload #5
    //   248: astore_1
    //   249: aload #4
    //   251: ifnull -> 265
    //   254: aload #5
    //   256: aload #4
    //   258: invokevirtual getContext : ()Landroid/content/Context;
    //   261: invokevirtual cloneInContext : (Landroid/content/Context;)Landroid/view/LayoutInflater;
    //   264: astore_1
    //   265: aload_1
    //   266: areturn
    //   267: iconst_2
    //   268: invokestatic O : (I)Z
    //   271: ifeq -> 359
    //   274: new java/lang/StringBuilder
    //   277: dup
    //   278: invokespecial <init> : ()V
    //   281: astore_1
    //   282: aload_1
    //   283: ldc 'getting layout inflater for DialogFragment '
    //   285: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   288: pop
    //   289: aload_1
    //   290: aload_0
    //   291: invokevirtual append : (Ljava/lang/Object;)Ljava/lang/StringBuilder;
    //   294: pop
    //   295: aload_1
    //   296: invokevirtual toString : ()Ljava/lang/String;
    //   299: astore #6
    //   301: aload_0
    //   302: getfield g0 : Z
    //   305: ifne -> 323
    //   308: new java/lang/StringBuilder
    //   311: dup
    //   312: invokespecial <init> : ()V
    //   315: astore_1
    //   316: ldc 'mShowsDialog = false: '
    //   318: astore #4
    //   320: goto -> 335
    //   323: new java/lang/StringBuilder
    //   326: dup
    //   327: invokespecial <init> : ()V
    //   330: astore_1
    //   331: ldc 'mCreatingDialog = true: '
    //   333: astore #4
    //   335: aload_1
    //   336: aload #4
    //   338: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   341: pop
    //   342: aload_1
    //   343: aload #6
    //   345: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   348: pop
    //   349: ldc 'FragmentManager'
    //   351: aload_1
    //   352: invokevirtual toString : ()Ljava/lang/String;
    //   355: invokestatic d : (Ljava/lang/String;Ljava/lang/String;)I
    //   358: pop
    //   359: aload #5
    //   361: areturn
    // Exception table:
    //   from	to	target	type
    //   40	68	187	finally
    //   86	92	187	finally
    //   97	104	187	finally
    //   104	110	187	finally
    //   110	133	187	finally
    //   133	171	187	finally
    //   174	179	187	finally
  }
  
  public void O(Bundle paramBundle) {
    Dialog dialog = this.k0;
    if (dialog != null) {
      Bundle bundle = dialog.onSaveInstanceState();
      bundle.putBoolean("android:dialogShowing", false);
      paramBundle.putBundle("android:savedDialogState", bundle);
    } 
    int i = this.d0;
    if (i != 0)
      paramBundle.putInt("android:style", i); 
    i = this.e0;
    if (i != 0)
      paramBundle.putInt("android:theme", i); 
    boolean bool = this.f0;
    if (!bool)
      paramBundle.putBoolean("android:cancelable", bool); 
    bool = this.g0;
    if (!bool)
      paramBundle.putBoolean("android:showsDialog", bool); 
    i = this.h0;
    if (i != -1)
      paramBundle.putInt("android:backStackId", i); 
  }
  
  public void P() {
    this.J = true;
    Dialog dialog = this.k0;
    if (dialog != null) {
      this.l0 = false;
      dialog.show();
      View view = this.k0.getWindow().getDecorView();
      view.setTag(2131362471, this);
      view.setTag(2131362473, this);
      view.setTag(2131362472, this);
    } 
  }
  
  public void Q() {
    this.J = true;
    Dialog dialog = this.k0;
    if (dialog != null)
      dialog.hide(); 
  }
  
  public void S(Bundle paramBundle) {
    this.J = true;
    if (this.k0 != null && paramBundle != null) {
      paramBundle = paramBundle.getBundle("android:savedDialogState");
      if (paramBundle != null)
        this.k0.onRestoreInstanceState(paramBundle); 
    } 
  }
  
  public void T(LayoutInflater paramLayoutInflater, ViewGroup paramViewGroup, Bundle paramBundle) {
    super.T(paramLayoutInflater, paramViewGroup, paramBundle);
    if (this.L == null && this.k0 != null && paramBundle != null) {
      Bundle bundle = paramBundle.getBundle("android:savedDialogState");
      if (bundle != null)
        this.k0.onRestoreInstanceState(bundle); 
    } 
  }
  
  public w b() {
    return new e(this, new o.a(this));
  }
  
  public final void j0(boolean paramBoolean1, boolean paramBoolean2) {
    if (this.m0)
      return; 
    this.m0 = true;
    this.n0 = false;
    Dialog dialog = this.k0;
    if (dialog != null) {
      dialog.setOnDismissListener(null);
      this.k0.dismiss();
      if (!paramBoolean2)
        if (Looper.myLooper() == this.Z.getLooper()) {
          onDismiss((DialogInterface)this.k0);
        } else {
          this.Z.post(this.a0);
        }  
    } 
    this.l0 = true;
    if (this.h0 >= 0) {
      d0 d0 = r();
      int i = this.h0;
      if (i >= 0) {
        d0.A(new d0.m(d0, null, i, 1), false);
        this.h0 = -1;
        return;
      } 
      throw new IllegalArgumentException(y.a("Bad id: ", i));
    } 
    b b = new b(r());
    b.n(this);
    if (paramBoolean1) {
      b.g();
      return;
    } 
    b.f();
  }
  
  public Dialog k0(Bundle paramBundle) {
    if (d0.O(3)) {
      StringBuilder stringBuilder = new StringBuilder();
      stringBuilder.append("onCreateDialog called for DialogFragment ");
      stringBuilder.append(this);
      Log.d("FragmentManager", stringBuilder.toString());
    } 
    return new Dialog(X(), this.e0);
  }
  
  public final Dialog l0() {
    Dialog dialog = this.k0;
    if (dialog != null)
      return dialog; 
    StringBuilder stringBuilder = new StringBuilder();
    stringBuilder.append("DialogFragment ");
    stringBuilder.append(this);
    stringBuilder.append(" does not have a Dialog.");
    throw new IllegalStateException(stringBuilder.toString());
  }
  
  public void onCancel(DialogInterface paramDialogInterface) {}
  
  public void onDismiss(DialogInterface paramDialogInterface) {
    if (!this.l0) {
      if (d0.O(3)) {
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("onDismiss called for DialogFragment ");
        stringBuilder.append(this);
        Log.d("FragmentManager", stringBuilder.toString());
      } 
      j0(true, true);
    } 
  }
  
  public class a implements Runnable {
    public a(m this$0) {}
    
    @SuppressLint({"SyntheticAccessor"})
    public void run() {
      m m1 = this.h;
      m1.c0.onDismiss((DialogInterface)m1.k0);
    }
  }
  
  public class b implements DialogInterface.OnCancelListener {
    public b(m this$0) {}
    
    @SuppressLint({"SyntheticAccessor"})
    public void onCancel(DialogInterface param1DialogInterface) {
      m m1 = this.h;
      Dialog dialog = m1.k0;
      if (dialog != null)
        m1.onCancel((DialogInterface)dialog); 
    }
  }
  
  public class c implements DialogInterface.OnDismissListener {
    public c(m this$0) {}
    
    @SuppressLint({"SyntheticAccessor"})
    public void onDismiss(DialogInterface param1DialogInterface) {
      m m1 = this.h;
      Dialog dialog = m1.k0;
      if (dialog != null)
        m1.onDismiss((DialogInterface)dialog); 
    }
  }
  
  public class d implements p<i> {
    public d(m this$0) {}
  }
  
  public class e extends w {
    public e(m this$0, w param1w) {}
    
    public View e(int param1Int) {
      if (this.a.f())
        return this.a.e(param1Int); 
      Dialog dialog = this.b.k0;
      return (dialog != null) ? dialog.findViewById(param1Int) : null;
    }
    
    public boolean f() {
      return (this.a.f() || this.b.o0);
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Luxury Logo Maker_ Logo Design-dex2jar.jar!\androidx\fragment\app\m.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */