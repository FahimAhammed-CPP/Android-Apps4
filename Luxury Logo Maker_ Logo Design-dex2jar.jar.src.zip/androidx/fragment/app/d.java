package androidx.fragment.app;

import android.content.Context;
import android.view.View;
import android.view.ViewGroup;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.WeakHashMap;
import k0.l;
import r.f;

public class d extends b1 {
  public d(ViewGroup paramViewGroup) {
    super(paramViewGroup);
  }
  
  public void b(List<b1.b> paramList, boolean paramBoolean) {
    // Byte code:
    //   0: iload_2
    //   1: istore #7
    //   3: aload_1
    //   4: invokeinterface iterator : ()Ljava/util/Iterator;
    //   9: astore #10
    //   11: aconst_null
    //   12: astore #11
    //   14: aconst_null
    //   15: astore #9
    //   17: aload #10
    //   19: invokeinterface hasNext : ()Z
    //   24: ifeq -> 116
    //   27: aload #10
    //   29: invokeinterface next : ()Ljava/lang/Object;
    //   34: checkcast androidx/fragment/app/b1$b
    //   37: astore #8
    //   39: aload #8
    //   41: getfield c : Landroidx/fragment/app/o;
    //   44: getfield L : Landroid/view/View;
    //   47: invokestatic c : (Landroid/view/View;)I
    //   50: istore_3
    //   51: aload #8
    //   53: getfield a : I
    //   56: invokestatic a : (I)I
    //   59: istore #4
    //   61: iload #4
    //   63: ifeq -> 99
    //   66: iload #4
    //   68: iconst_1
    //   69: if_icmpeq -> 87
    //   72: iload #4
    //   74: iconst_2
    //   75: if_icmpeq -> 99
    //   78: iload #4
    //   80: iconst_3
    //   81: if_icmpeq -> 99
    //   84: goto -> 17
    //   87: iload_3
    //   88: iconst_2
    //   89: if_icmpeq -> 17
    //   92: aload #8
    //   94: astore #9
    //   96: goto -> 17
    //   99: iload_3
    //   100: iconst_2
    //   101: if_icmpne -> 17
    //   104: aload #11
    //   106: ifnonnull -> 17
    //   109: aload #8
    //   111: astore #11
    //   113: goto -> 17
    //   116: new java/util/ArrayList
    //   119: dup
    //   120: invokespecial <init> : ()V
    //   123: astore #27
    //   125: new java/util/ArrayList
    //   128: dup
    //   129: invokespecial <init> : ()V
    //   132: astore #20
    //   134: new java/util/ArrayList
    //   137: dup
    //   138: aload_1
    //   139: invokespecial <init> : (Ljava/util/Collection;)V
    //   142: astore #12
    //   144: aload_1
    //   145: invokeinterface iterator : ()Ljava/util/Iterator;
    //   150: astore_1
    //   151: aload_1
    //   152: invokeinterface hasNext : ()Z
    //   157: ifeq -> 322
    //   160: aload_1
    //   161: invokeinterface next : ()Ljava/lang/Object;
    //   166: checkcast androidx/fragment/app/b1$b
    //   169: astore #8
    //   171: new g0/b
    //   174: dup
    //   175: invokespecial <init> : ()V
    //   178: astore #10
    //   180: aload #8
    //   182: invokevirtual d : ()V
    //   185: aload #8
    //   187: getfield e : Ljava/util/HashSet;
    //   190: aload #10
    //   192: invokevirtual add : (Ljava/lang/Object;)Z
    //   195: pop
    //   196: aload #27
    //   198: new androidx/fragment/app/d$b
    //   201: dup
    //   202: aload #8
    //   204: aload #10
    //   206: iload #7
    //   208: invokespecial <init> : (Landroidx/fragment/app/b1$b;Lg0/b;Z)V
    //   211: invokevirtual add : (Ljava/lang/Object;)Z
    //   214: pop
    //   215: new g0/b
    //   218: dup
    //   219: invokespecial <init> : ()V
    //   222: astore #10
    //   224: aload #8
    //   226: invokevirtual d : ()V
    //   229: aload #8
    //   231: getfield e : Ljava/util/HashSet;
    //   234: aload #10
    //   236: invokevirtual add : (Ljava/lang/Object;)Z
    //   239: pop
    //   240: iload #7
    //   242: ifeq -> 255
    //   245: aload #8
    //   247: aload #11
    //   249: if_acmpne -> 268
    //   252: goto -> 262
    //   255: aload #8
    //   257: aload #9
    //   259: if_acmpne -> 268
    //   262: iconst_1
    //   263: istore #6
    //   265: goto -> 271
    //   268: iconst_0
    //   269: istore #6
    //   271: aload #20
    //   273: new androidx/fragment/app/d$d
    //   276: dup
    //   277: aload #8
    //   279: aload #10
    //   281: iload #7
    //   283: iload #6
    //   285: invokespecial <init> : (Landroidx/fragment/app/b1$b;Lg0/b;ZZ)V
    //   288: invokevirtual add : (Ljava/lang/Object;)Z
    //   291: pop
    //   292: new androidx/fragment/app/d$a
    //   295: dup
    //   296: aload_0
    //   297: aload #12
    //   299: aload #8
    //   301: invokespecial <init> : (Landroidx/fragment/app/d;Ljava/util/List;Landroidx/fragment/app/b1$b;)V
    //   304: astore #10
    //   306: aload #8
    //   308: getfield d : Ljava/util/List;
    //   311: aload #10
    //   313: invokeinterface add : (Ljava/lang/Object;)Z
    //   318: pop
    //   319: goto -> 151
    //   322: new java/util/HashMap
    //   325: dup
    //   326: invokespecial <init> : ()V
    //   329: astore #10
    //   331: aload #20
    //   333: invokevirtual iterator : ()Ljava/util/Iterator;
    //   336: astore #14
    //   338: aconst_null
    //   339: astore_1
    //   340: aload #14
    //   342: invokeinterface hasNext : ()Z
    //   347: ifeq -> 573
    //   350: aload #14
    //   352: invokeinterface next : ()Ljava/lang/Object;
    //   357: checkcast androidx/fragment/app/d$d
    //   360: astore #15
    //   362: aload #15
    //   364: invokevirtual b : ()Z
    //   367: ifeq -> 373
    //   370: goto -> 340
    //   373: aload #15
    //   375: aload #15
    //   377: getfield c : Ljava/lang/Object;
    //   380: invokevirtual c : (Ljava/lang/Object;)Landroidx/fragment/app/u0;
    //   383: astore #8
    //   385: aload #15
    //   387: aload #15
    //   389: getfield e : Ljava/lang/Object;
    //   392: invokevirtual c : (Ljava/lang/Object;)Landroidx/fragment/app/u0;
    //   395: astore #13
    //   397: aload #8
    //   399: ifnull -> 482
    //   402: aload #13
    //   404: ifnull -> 482
    //   407: aload #8
    //   409: aload #13
    //   411: if_acmpne -> 417
    //   414: goto -> 482
    //   417: ldc 'Mixing framework transitions and AndroidX transitions is not allowed. Fragment '
    //   419: invokestatic a : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   422: astore_1
    //   423: aload_1
    //   424: aload #15
    //   426: getfield a : Landroidx/fragment/app/b1$b;
    //   429: getfield c : Landroidx/fragment/app/o;
    //   432: invokevirtual append : (Ljava/lang/Object;)Ljava/lang/StringBuilder;
    //   435: pop
    //   436: aload_1
    //   437: ldc ' returned Transition '
    //   439: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   442: pop
    //   443: aload_1
    //   444: aload #15
    //   446: getfield c : Ljava/lang/Object;
    //   449: invokevirtual append : (Ljava/lang/Object;)Ljava/lang/StringBuilder;
    //   452: pop
    //   453: aload_1
    //   454: ldc ' which uses a different Transition  type than its shared element transition '
    //   456: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   459: pop
    //   460: aload_1
    //   461: aload #15
    //   463: getfield e : Ljava/lang/Object;
    //   466: invokevirtual append : (Ljava/lang/Object;)Ljava/lang/StringBuilder;
    //   469: pop
    //   470: new java/lang/IllegalArgumentException
    //   473: dup
    //   474: aload_1
    //   475: invokevirtual toString : ()Ljava/lang/String;
    //   478: invokespecial <init> : (Ljava/lang/String;)V
    //   481: athrow
    //   482: aload #8
    //   484: ifnull -> 490
    //   487: goto -> 494
    //   490: aload #13
    //   492: astore #8
    //   494: aload_1
    //   495: ifnonnull -> 504
    //   498: aload #8
    //   500: astore_1
    //   501: goto -> 340
    //   504: aload #8
    //   506: ifnull -> 340
    //   509: aload_1
    //   510: aload #8
    //   512: if_acmpne -> 518
    //   515: goto -> 340
    //   518: ldc 'Mixing framework transitions and AndroidX transitions is not allowed. Fragment '
    //   520: invokestatic a : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   523: astore_1
    //   524: aload_1
    //   525: aload #15
    //   527: getfield a : Landroidx/fragment/app/b1$b;
    //   530: getfield c : Landroidx/fragment/app/o;
    //   533: invokevirtual append : (Ljava/lang/Object;)Ljava/lang/StringBuilder;
    //   536: pop
    //   537: aload_1
    //   538: ldc ' returned Transition '
    //   540: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   543: pop
    //   544: aload_1
    //   545: aload #15
    //   547: getfield c : Ljava/lang/Object;
    //   550: invokevirtual append : (Ljava/lang/Object;)Ljava/lang/StringBuilder;
    //   553: pop
    //   554: aload_1
    //   555: ldc ' which uses a different Transition  type than other Fragments.'
    //   557: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   560: pop
    //   561: new java/lang/IllegalArgumentException
    //   564: dup
    //   565: aload_1
    //   566: invokevirtual toString : ()Ljava/lang/String;
    //   569: invokespecial <init> : (Ljava/lang/String;)V
    //   572: athrow
    //   573: ldc 'FragmentManager'
    //   575: astore #14
    //   577: aload_1
    //   578: ifnonnull -> 643
    //   581: aload #20
    //   583: invokevirtual iterator : ()Ljava/util/Iterator;
    //   586: astore_1
    //   587: aload_1
    //   588: invokeinterface hasNext : ()Z
    //   593: ifeq -> 629
    //   596: aload_1
    //   597: invokeinterface next : ()Ljava/lang/Object;
    //   602: checkcast androidx/fragment/app/d$d
    //   605: astore #8
    //   607: aload #10
    //   609: aload #8
    //   611: getfield a : Landroidx/fragment/app/b1$b;
    //   614: getstatic java/lang/Boolean.FALSE : Ljava/lang/Boolean;
    //   617: invokevirtual put : (Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    //   620: pop
    //   621: aload #8
    //   623: invokevirtual a : ()V
    //   626: goto -> 587
    //   629: aload #12
    //   631: astore_1
    //   632: aload #10
    //   634: astore #8
    //   636: ldc 'FragmentManager'
    //   638: astore #9
    //   640: goto -> 2301
    //   643: new android/view/View
    //   646: dup
    //   647: aload_0
    //   648: getfield a : Landroid/view/ViewGroup;
    //   651: invokevirtual getContext : ()Landroid/content/Context;
    //   654: invokespecial <init> : (Landroid/content/Context;)V
    //   657: astore #15
    //   659: new android/graphics/Rect
    //   662: dup
    //   663: invokespecial <init> : ()V
    //   666: astore #21
    //   668: new java/util/ArrayList
    //   671: dup
    //   672: invokespecial <init> : ()V
    //   675: astore #24
    //   677: new java/util/ArrayList
    //   680: dup
    //   681: invokespecial <init> : ()V
    //   684: astore #13
    //   686: new r/a
    //   689: dup
    //   690: invokespecial <init> : ()V
    //   693: astore #19
    //   695: aload #20
    //   697: invokevirtual iterator : ()Ljava/util/Iterator;
    //   700: astore #28
    //   702: aconst_null
    //   703: astore #23
    //   705: aload #11
    //   707: astore #22
    //   709: aconst_null
    //   710: astore #16
    //   712: iconst_0
    //   713: istore_3
    //   714: aload #9
    //   716: astore #17
    //   718: aload_1
    //   719: astore #18
    //   721: aload #12
    //   723: astore #8
    //   725: aload #16
    //   727: astore_1
    //   728: aload #11
    //   730: astore #16
    //   732: aload #24
    //   734: astore #11
    //   736: aload #23
    //   738: astore #12
    //   740: iload_2
    //   741: istore #6
    //   743: aload #28
    //   745: invokeinterface hasNext : ()Z
    //   750: ifeq -> 1520
    //   753: aload #28
    //   755: invokeinterface next : ()Ljava/lang/Object;
    //   760: checkcast androidx/fragment/app/d$d
    //   763: getfield e : Ljava/lang/Object;
    //   766: astore #23
    //   768: aload #23
    //   770: ifnull -> 779
    //   773: iconst_1
    //   774: istore #4
    //   776: goto -> 782
    //   779: iconst_0
    //   780: istore #4
    //   782: iload #4
    //   784: ifeq -> 1514
    //   787: aload #22
    //   789: ifnull -> 1514
    //   792: aload #17
    //   794: ifnull -> 1514
    //   797: aload #18
    //   799: aload #18
    //   801: aload #23
    //   803: invokevirtual g : (Ljava/lang/Object;)Ljava/lang/Object;
    //   806: invokevirtual y : (Ljava/lang/Object;)Ljava/lang/Object;
    //   809: astore #25
    //   811: aload #17
    //   813: getfield c : Landroidx/fragment/app/o;
    //   816: getfield O : Landroidx/fragment/app/o$b;
    //   819: astore #12
    //   821: aload #12
    //   823: ifnull -> 842
    //   826: aload #12
    //   828: getfield i : Ljava/util/ArrayList;
    //   831: astore #12
    //   833: aload #12
    //   835: astore #23
    //   837: aload #12
    //   839: ifnonnull -> 851
    //   842: new java/util/ArrayList
    //   845: dup
    //   846: invokespecial <init> : ()V
    //   849: astore #23
    //   851: aload #22
    //   853: getfield c : Landroidx/fragment/app/o;
    //   856: getfield O : Landroidx/fragment/app/o$b;
    //   859: astore #12
    //   861: aload #12
    //   863: ifnull -> 882
    //   866: aload #12
    //   868: getfield i : Ljava/util/ArrayList;
    //   871: astore #12
    //   873: aload #12
    //   875: astore #24
    //   877: aload #12
    //   879: ifnonnull -> 891
    //   882: new java/util/ArrayList
    //   885: dup
    //   886: invokespecial <init> : ()V
    //   889: astore #24
    //   891: aload #22
    //   893: getfield c : Landroidx/fragment/app/o;
    //   896: getfield O : Landroidx/fragment/app/o$b;
    //   899: astore #12
    //   901: aload #12
    //   903: ifnull -> 922
    //   906: aload #12
    //   908: getfield j : Ljava/util/ArrayList;
    //   911: astore #26
    //   913: aload #26
    //   915: astore #12
    //   917: aload #26
    //   919: ifnonnull -> 931
    //   922: new java/util/ArrayList
    //   925: dup
    //   926: invokespecial <init> : ()V
    //   929: astore #12
    //   931: iconst_0
    //   932: istore #4
    //   934: iload #4
    //   936: aload #12
    //   938: invokevirtual size : ()I
    //   941: if_icmpge -> 988
    //   944: aload #23
    //   946: aload #12
    //   948: iload #4
    //   950: invokevirtual get : (I)Ljava/lang/Object;
    //   953: invokevirtual indexOf : (Ljava/lang/Object;)I
    //   956: istore #5
    //   958: iload #5
    //   960: iconst_m1
    //   961: if_icmpeq -> 979
    //   964: aload #23
    //   966: iload #5
    //   968: aload #24
    //   970: iload #4
    //   972: invokevirtual get : (I)Ljava/lang/Object;
    //   975: invokevirtual set : (ILjava/lang/Object;)Ljava/lang/Object;
    //   978: pop
    //   979: iload #4
    //   981: iconst_1
    //   982: iadd
    //   983: istore #4
    //   985: goto -> 934
    //   988: aload #17
    //   990: getfield c : Landroidx/fragment/app/o;
    //   993: getfield O : Landroidx/fragment/app/o$b;
    //   996: astore #12
    //   998: aload #12
    //   1000: ifnull -> 1019
    //   1003: aload #12
    //   1005: getfield j : Ljava/util/ArrayList;
    //   1008: astore #24
    //   1010: aload #24
    //   1012: astore #12
    //   1014: aload #24
    //   1016: ifnonnull -> 1028
    //   1019: new java/util/ArrayList
    //   1022: dup
    //   1023: invokespecial <init> : ()V
    //   1026: astore #12
    //   1028: iload #6
    //   1030: ifne -> 1052
    //   1033: aload #22
    //   1035: getfield c : Landroidx/fragment/app/o;
    //   1038: invokevirtual p : ()V
    //   1041: aload #17
    //   1043: getfield c : Landroidx/fragment/app/o;
    //   1046: invokevirtual m : ()V
    //   1049: goto -> 1068
    //   1052: aload #22
    //   1054: getfield c : Landroidx/fragment/app/o;
    //   1057: invokevirtual m : ()V
    //   1060: aload #17
    //   1062: getfield c : Landroidx/fragment/app/o;
    //   1065: invokevirtual p : ()V
    //   1068: aload #23
    //   1070: invokevirtual size : ()I
    //   1073: istore #4
    //   1075: iconst_0
    //   1076: istore #5
    //   1078: iload #5
    //   1080: iload #4
    //   1082: if_icmpge -> 1120
    //   1085: aload #19
    //   1087: aload #23
    //   1089: iload #5
    //   1091: invokevirtual get : (I)Ljava/lang/Object;
    //   1094: checkcast java/lang/String
    //   1097: aload #12
    //   1099: iload #5
    //   1101: invokevirtual get : (I)Ljava/lang/Object;
    //   1104: checkcast java/lang/String
    //   1107: invokevirtual put : (Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    //   1110: pop
    //   1111: iload #5
    //   1113: iconst_1
    //   1114: iadd
    //   1115: istore #5
    //   1117: goto -> 1078
    //   1120: new r/a
    //   1123: dup
    //   1124: invokespecial <init> : ()V
    //   1127: astore #26
    //   1129: aload_0
    //   1130: aload #26
    //   1132: aload #22
    //   1134: getfield c : Landroidx/fragment/app/o;
    //   1137: getfield L : Landroid/view/View;
    //   1140: invokevirtual k : (Ljava/util/Map;Landroid/view/View;)V
    //   1143: aload #26
    //   1145: aload #23
    //   1147: invokestatic k : (Ljava/util/Map;Ljava/util/Collection;)Z
    //   1150: pop
    //   1151: aload #19
    //   1153: aload #26
    //   1155: invokevirtual keySet : ()Ljava/util/Set;
    //   1158: invokestatic k : (Ljava/util/Map;Ljava/util/Collection;)Z
    //   1161: pop
    //   1162: new r/a
    //   1165: dup
    //   1166: invokespecial <init> : ()V
    //   1169: astore #24
    //   1171: aload_0
    //   1172: aload #24
    //   1174: aload #17
    //   1176: getfield c : Landroidx/fragment/app/o;
    //   1179: getfield L : Landroid/view/View;
    //   1182: invokevirtual k : (Ljava/util/Map;Landroid/view/View;)V
    //   1185: aload #24
    //   1187: aload #12
    //   1189: invokestatic k : (Ljava/util/Map;Ljava/util/Collection;)Z
    //   1192: pop
    //   1193: aload #24
    //   1195: aload #19
    //   1197: invokevirtual values : ()Ljava/util/Collection;
    //   1200: invokestatic k : (Ljava/util/Map;Ljava/util/Collection;)Z
    //   1203: pop
    //   1204: aload #19
    //   1206: aload #24
    //   1208: invokestatic m : (Lr/a;Lr/a;)V
    //   1211: aload_0
    //   1212: aload #26
    //   1214: aload #19
    //   1216: invokevirtual keySet : ()Ljava/util/Set;
    //   1219: invokevirtual l : (Lr/a;Ljava/util/Collection;)V
    //   1222: aload_0
    //   1223: aload #24
    //   1225: aload #19
    //   1227: invokevirtual values : ()Ljava/util/Collection;
    //   1230: invokevirtual l : (Lr/a;Ljava/util/Collection;)V
    //   1233: aload #19
    //   1235: invokevirtual isEmpty : ()Z
    //   1238: ifeq -> 1257
    //   1241: aload #11
    //   1243: invokevirtual clear : ()V
    //   1246: aload #13
    //   1248: invokevirtual clear : ()V
    //   1251: aconst_null
    //   1252: astore #12
    //   1254: goto -> 1517
    //   1257: aload #17
    //   1259: getfield c : Landroidx/fragment/app/o;
    //   1262: aload #22
    //   1264: getfield c : Landroidx/fragment/app/o;
    //   1267: iload #6
    //   1269: aload #26
    //   1271: iconst_1
    //   1272: invokestatic c : (Landroidx/fragment/app/o;Landroidx/fragment/app/o;ZLr/a;Z)V
    //   1275: aload_0
    //   1276: getfield a : Landroid/view/ViewGroup;
    //   1279: astore #29
    //   1281: aload #13
    //   1283: astore #17
    //   1285: aload #11
    //   1287: astore #22
    //   1289: aload #29
    //   1291: new androidx/fragment/app/i
    //   1294: dup
    //   1295: aload_0
    //   1296: aload #9
    //   1298: aload #16
    //   1300: iload_2
    //   1301: aload #24
    //   1303: invokespecial <init> : (Landroidx/fragment/app/d;Landroidx/fragment/app/b1$b;Landroidx/fragment/app/b1$b;ZLr/a;)V
    //   1306: invokestatic a : (Landroid/view/View;Ljava/lang/Runnable;)Lk0/k;
    //   1309: pop
    //   1310: aload #22
    //   1312: aload #26
    //   1314: invokevirtual values : ()Ljava/util/Collection;
    //   1317: invokevirtual addAll : (Ljava/util/Collection;)Z
    //   1320: pop
    //   1321: aload #23
    //   1323: invokevirtual isEmpty : ()Z
    //   1326: ifne -> 1358
    //   1329: aload #26
    //   1331: aload #23
    //   1333: iconst_0
    //   1334: invokevirtual get : (I)Ljava/lang/Object;
    //   1337: checkcast java/lang/String
    //   1340: invokevirtual get : (Ljava/lang/Object;)Ljava/lang/Object;
    //   1343: checkcast android/view/View
    //   1346: astore_1
    //   1347: aload #18
    //   1349: aload #25
    //   1351: aload_1
    //   1352: invokevirtual t : (Ljava/lang/Object;Landroid/view/View;)V
    //   1355: goto -> 1358
    //   1358: aload #17
    //   1360: aload #24
    //   1362: invokevirtual values : ()Ljava/util/Collection;
    //   1365: invokevirtual addAll : (Ljava/util/Collection;)Z
    //   1368: pop
    //   1369: aload #12
    //   1371: invokevirtual isEmpty : ()Z
    //   1374: ifne -> 1428
    //   1377: aload #24
    //   1379: aload #12
    //   1381: iconst_0
    //   1382: invokevirtual get : (I)Ljava/lang/Object;
    //   1385: checkcast java/lang/String
    //   1388: invokevirtual get : (Ljava/lang/Object;)Ljava/lang/Object;
    //   1391: checkcast android/view/View
    //   1394: astore #12
    //   1396: aload #12
    //   1398: ifnull -> 1428
    //   1401: aload_0
    //   1402: getfield a : Landroid/view/ViewGroup;
    //   1405: new androidx/fragment/app/j
    //   1408: dup
    //   1409: aload_0
    //   1410: aload #18
    //   1412: aload #12
    //   1414: aload #21
    //   1416: invokespecial <init> : (Landroidx/fragment/app/d;Landroidx/fragment/app/u0;Landroid/view/View;Landroid/graphics/Rect;)V
    //   1419: invokestatic a : (Landroid/view/View;Ljava/lang/Runnable;)Lk0/k;
    //   1422: pop
    //   1423: iconst_1
    //   1424: istore_3
    //   1425: goto -> 1428
    //   1428: aload #18
    //   1430: aload #25
    //   1432: aload #15
    //   1434: aload #22
    //   1436: invokevirtual w : (Ljava/lang/Object;Landroid/view/View;Ljava/util/ArrayList;)V
    //   1439: aload #18
    //   1441: aload #25
    //   1443: aconst_null
    //   1444: aconst_null
    //   1445: aconst_null
    //   1446: aconst_null
    //   1447: aload #25
    //   1449: aload #17
    //   1451: invokevirtual r : (Ljava/lang/Object;Ljava/lang/Object;Ljava/util/ArrayList;Ljava/lang/Object;Ljava/util/ArrayList;Ljava/lang/Object;Ljava/util/ArrayList;)V
    //   1454: getstatic java/lang/Boolean.TRUE : Ljava/lang/Boolean;
    //   1457: astore #23
    //   1459: aload #10
    //   1461: astore #22
    //   1463: aload #16
    //   1465: astore #17
    //   1467: aload #22
    //   1469: aload #17
    //   1471: aload #23
    //   1473: invokevirtual put : (Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    //   1476: pop
    //   1477: aload #9
    //   1479: astore #12
    //   1481: aload #22
    //   1483: aload #12
    //   1485: aload #23
    //   1487: invokevirtual put : (Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    //   1490: pop
    //   1491: aload #25
    //   1493: astore #22
    //   1495: aload #12
    //   1497: astore #23
    //   1499: aload #22
    //   1501: astore #12
    //   1503: aload #17
    //   1505: astore #22
    //   1507: aload #23
    //   1509: astore #17
    //   1511: goto -> 1517
    //   1514: goto -> 1254
    //   1517: goto -> 740
    //   1520: aload #10
    //   1522: astore #16
    //   1524: aload #14
    //   1526: astore #10
    //   1528: aload #15
    //   1530: astore #25
    //   1532: aload #11
    //   1534: astore #14
    //   1536: new java/util/ArrayList
    //   1539: dup
    //   1540: invokespecial <init> : ()V
    //   1543: astore #28
    //   1545: aload #20
    //   1547: invokevirtual iterator : ()Ljava/util/Iterator;
    //   1550: astore #23
    //   1552: aconst_null
    //   1553: astore #11
    //   1555: aconst_null
    //   1556: astore #24
    //   1558: aload_1
    //   1559: astore #15
    //   1561: aload #24
    //   1563: astore_1
    //   1564: aload #17
    //   1566: astore #24
    //   1568: aload #25
    //   1570: astore #17
    //   1572: aload #23
    //   1574: invokeinterface hasNext : ()Z
    //   1579: ifeq -> 1975
    //   1582: aload #23
    //   1584: invokeinterface next : ()Ljava/lang/Object;
    //   1589: checkcast androidx/fragment/app/d$d
    //   1592: astore #29
    //   1594: aload #29
    //   1596: invokevirtual b : ()Z
    //   1599: ifeq -> 1624
    //   1602: aload #16
    //   1604: aload #29
    //   1606: getfield a : Landroidx/fragment/app/b1$b;
    //   1609: getstatic java/lang/Boolean.FALSE : Ljava/lang/Boolean;
    //   1612: invokevirtual put : (Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    //   1615: pop
    //   1616: aload #29
    //   1618: invokevirtual a : ()V
    //   1621: goto -> 1972
    //   1624: aload #18
    //   1626: aload #29
    //   1628: getfield c : Ljava/lang/Object;
    //   1631: invokevirtual g : (Ljava/lang/Object;)Ljava/lang/Object;
    //   1634: astore #26
    //   1636: aload #29
    //   1638: getfield a : Landroidx/fragment/app/b1$b;
    //   1641: astore #25
    //   1643: aload #12
    //   1645: ifnull -> 1668
    //   1648: aload #25
    //   1650: aload #22
    //   1652: if_acmpeq -> 1662
    //   1655: aload #25
    //   1657: aload #24
    //   1659: if_acmpne -> 1668
    //   1662: iconst_1
    //   1663: istore #4
    //   1665: goto -> 1671
    //   1668: iconst_0
    //   1669: istore #4
    //   1671: aload #26
    //   1673: ifnonnull -> 1700
    //   1676: iload #4
    //   1678: ifne -> 1697
    //   1681: aload #16
    //   1683: aload #25
    //   1685: getstatic java/lang/Boolean.FALSE : Ljava/lang/Boolean;
    //   1688: invokevirtual put : (Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    //   1691: pop
    //   1692: aload #29
    //   1694: invokevirtual a : ()V
    //   1697: goto -> 1968
    //   1700: new java/util/ArrayList
    //   1703: dup
    //   1704: invokespecial <init> : ()V
    //   1707: astore #30
    //   1709: aload_0
    //   1710: aload #30
    //   1712: aload #25
    //   1714: getfield c : Landroidx/fragment/app/o;
    //   1717: getfield L : Landroid/view/View;
    //   1720: invokevirtual j : (Ljava/util/ArrayList;Landroid/view/View;)V
    //   1723: iload #4
    //   1725: ifeq -> 1754
    //   1728: aload #25
    //   1730: aload #22
    //   1732: if_acmpne -> 1746
    //   1735: aload #30
    //   1737: aload #14
    //   1739: invokevirtual removeAll : (Ljava/util/Collection;)Z
    //   1742: pop
    //   1743: goto -> 1754
    //   1746: aload #30
    //   1748: aload #13
    //   1750: invokevirtual removeAll : (Ljava/util/Collection;)Z
    //   1753: pop
    //   1754: aload #30
    //   1756: invokevirtual isEmpty : ()Z
    //   1759: ifeq -> 1774
    //   1762: aload #18
    //   1764: aload #26
    //   1766: aload #17
    //   1768: invokevirtual a : (Ljava/lang/Object;Landroid/view/View;)V
    //   1771: goto -> 1882
    //   1774: aload #18
    //   1776: aload #26
    //   1778: aload #30
    //   1780: invokevirtual b : (Ljava/lang/Object;Ljava/util/ArrayList;)V
    //   1783: aload #25
    //   1785: astore #24
    //   1787: aload #18
    //   1789: aload #26
    //   1791: aload #26
    //   1793: aload #30
    //   1795: aconst_null
    //   1796: aconst_null
    //   1797: aconst_null
    //   1798: aconst_null
    //   1799: invokevirtual r : (Ljava/lang/Object;Ljava/lang/Object;Ljava/util/ArrayList;Ljava/lang/Object;Ljava/util/ArrayList;Ljava/lang/Object;Ljava/util/ArrayList;)V
    //   1802: aload #24
    //   1804: getfield a : I
    //   1807: iconst_3
    //   1808: if_icmpne -> 1882
    //   1811: aload #8
    //   1813: aload #24
    //   1815: invokevirtual remove : (Ljava/lang/Object;)Z
    //   1818: pop
    //   1819: new java/util/ArrayList
    //   1822: dup
    //   1823: aload #30
    //   1825: invokespecial <init> : (Ljava/util/Collection;)V
    //   1828: astore #31
    //   1830: aload #31
    //   1832: aload #24
    //   1834: getfield c : Landroidx/fragment/app/o;
    //   1837: getfield L : Landroid/view/View;
    //   1840: invokevirtual remove : (Ljava/lang/Object;)Z
    //   1843: pop
    //   1844: aload #18
    //   1846: aload #26
    //   1848: aload #24
    //   1850: getfield c : Landroidx/fragment/app/o;
    //   1853: getfield L : Landroid/view/View;
    //   1856: aload #31
    //   1858: invokevirtual q : (Ljava/lang/Object;Landroid/view/View;Ljava/util/ArrayList;)V
    //   1861: aload_0
    //   1862: getfield a : Landroid/view/ViewGroup;
    //   1865: new androidx/fragment/app/k
    //   1868: dup
    //   1869: aload_0
    //   1870: aload #30
    //   1872: invokespecial <init> : (Landroidx/fragment/app/d;Ljava/util/ArrayList;)V
    //   1875: invokestatic a : (Landroid/view/View;Ljava/lang/Runnable;)Lk0/k;
    //   1878: pop
    //   1879: goto -> 1882
    //   1882: aload #25
    //   1884: getfield a : I
    //   1887: iconst_2
    //   1888: if_icmpne -> 1915
    //   1891: aload #28
    //   1893: aload #30
    //   1895: invokevirtual addAll : (Ljava/util/Collection;)Z
    //   1898: pop
    //   1899: iload_3
    //   1900: ifeq -> 1912
    //   1903: aload #18
    //   1905: aload #26
    //   1907: aload #21
    //   1909: invokevirtual s : (Ljava/lang/Object;Landroid/graphics/Rect;)V
    //   1912: goto -> 1924
    //   1915: aload #18
    //   1917: aload #26
    //   1919: aload #15
    //   1921: invokevirtual t : (Ljava/lang/Object;Landroid/view/View;)V
    //   1924: aload #16
    //   1926: aload #25
    //   1928: getstatic java/lang/Boolean.TRUE : Ljava/lang/Boolean;
    //   1931: invokevirtual put : (Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    //   1934: pop
    //   1935: aload #29
    //   1937: getfield d : Z
    //   1940: ifeq -> 1956
    //   1943: aload #18
    //   1945: aload_1
    //   1946: aload #26
    //   1948: aconst_null
    //   1949: invokevirtual m : (Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    //   1952: astore_1
    //   1953: goto -> 1968
    //   1956: aload #18
    //   1958: aload #11
    //   1960: aload #26
    //   1962: aconst_null
    //   1963: invokevirtual m : (Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    //   1966: astore #11
    //   1968: aload #9
    //   1970: astore #24
    //   1972: goto -> 1572
    //   1975: aload #18
    //   1977: aload_1
    //   1978: aload #11
    //   1980: aload #12
    //   1982: invokevirtual l : (Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    //   1985: astore #11
    //   1987: aload #20
    //   1989: invokevirtual iterator : ()Ljava/util/Iterator;
    //   1992: astore #15
    //   1994: aload #10
    //   1996: astore_1
    //   1997: aload #15
    //   1999: invokeinterface hasNext : ()Z
    //   2004: ifeq -> 2200
    //   2007: aload #15
    //   2009: invokeinterface next : ()Ljava/lang/Object;
    //   2014: checkcast androidx/fragment/app/d$d
    //   2017: astore #10
    //   2019: aload #10
    //   2021: invokevirtual b : ()Z
    //   2024: ifeq -> 2030
    //   2027: goto -> 1997
    //   2030: aload #10
    //   2032: getfield c : Ljava/lang/Object;
    //   2035: astore #20
    //   2037: aload #10
    //   2039: getfield a : Landroidx/fragment/app/b1$b;
    //   2042: astore #17
    //   2044: aload #12
    //   2046: ifnull -> 2068
    //   2049: aload #17
    //   2051: aload #22
    //   2053: if_acmpeq -> 2063
    //   2056: aload #17
    //   2058: aload #9
    //   2060: if_acmpne -> 2068
    //   2063: iconst_1
    //   2064: istore_3
    //   2065: goto -> 2070
    //   2068: iconst_0
    //   2069: istore_3
    //   2070: aload #20
    //   2072: ifnonnull -> 2085
    //   2075: iload_3
    //   2076: ifeq -> 2082
    //   2079: goto -> 2085
    //   2082: goto -> 2197
    //   2085: aload_0
    //   2086: getfield a : Landroid/view/ViewGroup;
    //   2089: astore #20
    //   2091: getstatic k0/l.a : Ljava/util/WeakHashMap;
    //   2094: astore #21
    //   2096: aload #20
    //   2098: invokevirtual isLaidOut : ()Z
    //   2101: ifne -> 2167
    //   2104: iconst_2
    //   2105: invokestatic O : (I)Z
    //   2108: ifeq -> 2159
    //   2111: ldc_w 'SpecialEffectsController: Container '
    //   2114: invokestatic a : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   2117: astore #20
    //   2119: aload #20
    //   2121: aload_0
    //   2122: getfield a : Landroid/view/ViewGroup;
    //   2125: invokevirtual append : (Ljava/lang/Object;)Ljava/lang/StringBuilder;
    //   2128: pop
    //   2129: aload #20
    //   2131: ldc_w ' has not been laid out. Completing operation '
    //   2134: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   2137: pop
    //   2138: aload #20
    //   2140: aload #17
    //   2142: invokevirtual append : (Ljava/lang/Object;)Ljava/lang/StringBuilder;
    //   2145: pop
    //   2146: aload_1
    //   2147: aload #20
    //   2149: invokevirtual toString : ()Ljava/lang/String;
    //   2152: invokestatic v : (Ljava/lang/String;Ljava/lang/String;)I
    //   2155: pop
    //   2156: goto -> 2159
    //   2159: aload #10
    //   2161: invokevirtual a : ()V
    //   2164: goto -> 2197
    //   2167: aload #18
    //   2169: aload #10
    //   2171: getfield a : Landroidx/fragment/app/b1$b;
    //   2174: getfield c : Landroidx/fragment/app/o;
    //   2177: aload #11
    //   2179: aload #10
    //   2181: getfield b : Lg0/b;
    //   2184: new androidx/fragment/app/l
    //   2187: dup
    //   2188: aload_0
    //   2189: aload #10
    //   2191: invokespecial <init> : (Landroidx/fragment/app/d;Landroidx/fragment/app/d$d;)V
    //   2194: invokevirtual u : (Landroidx/fragment/app/o;Ljava/lang/Object;Lg0/b;Ljava/lang/Runnable;)V
    //   2197: goto -> 1997
    //   2200: aload_1
    //   2201: astore #9
    //   2203: aload_0
    //   2204: getfield a : Landroid/view/ViewGroup;
    //   2207: astore_1
    //   2208: getstatic k0/l.a : Ljava/util/WeakHashMap;
    //   2211: astore #10
    //   2213: aload_1
    //   2214: invokevirtual isLaidOut : ()Z
    //   2217: ifne -> 2230
    //   2220: aload #8
    //   2222: astore_1
    //   2223: aload #16
    //   2225: astore #8
    //   2227: goto -> 2301
    //   2230: aload #28
    //   2232: iconst_4
    //   2233: invokestatic o : (Ljava/util/ArrayList;I)V
    //   2236: aload #18
    //   2238: aload #13
    //   2240: invokevirtual n : (Ljava/util/ArrayList;)Ljava/util/ArrayList;
    //   2243: astore #10
    //   2245: aload #18
    //   2247: aload_0
    //   2248: getfield a : Landroid/view/ViewGroup;
    //   2251: aload #11
    //   2253: invokevirtual c : (Landroid/view/ViewGroup;Ljava/lang/Object;)V
    //   2256: aload_0
    //   2257: getfield a : Landroid/view/ViewGroup;
    //   2260: astore #11
    //   2262: aload #8
    //   2264: astore_1
    //   2265: aload #18
    //   2267: aload #11
    //   2269: aload #14
    //   2271: aload #13
    //   2273: aload #10
    //   2275: aload #19
    //   2277: invokevirtual v : (Landroid/view/View;Ljava/util/ArrayList;Ljava/util/ArrayList;Ljava/util/ArrayList;Ljava/util/Map;)V
    //   2280: aload #28
    //   2282: iconst_0
    //   2283: invokestatic o : (Ljava/util/ArrayList;I)V
    //   2286: aload #18
    //   2288: aload #12
    //   2290: aload #14
    //   2292: aload #13
    //   2294: invokevirtual x : (Ljava/lang/Object;Ljava/util/ArrayList;Ljava/util/ArrayList;)V
    //   2297: aload #16
    //   2299: astore #8
    //   2301: aload #8
    //   2303: getstatic java/lang/Boolean.TRUE : Ljava/lang/Boolean;
    //   2306: invokevirtual containsValue : (Ljava/lang/Object;)Z
    //   2309: istore #6
    //   2311: aload_0
    //   2312: getfield a : Landroid/view/ViewGroup;
    //   2315: astore #11
    //   2317: aload #11
    //   2319: invokevirtual getContext : ()Landroid/content/Context;
    //   2322: astore #12
    //   2324: new java/util/ArrayList
    //   2327: dup
    //   2328: invokespecial <init> : ()V
    //   2331: astore #13
    //   2333: aload #27
    //   2335: invokevirtual iterator : ()Ljava/util/Iterator;
    //   2338: astore #10
    //   2340: iconst_0
    //   2341: istore_3
    //   2342: aload #10
    //   2344: invokeinterface hasNext : ()Z
    //   2349: ifeq -> 2604
    //   2352: aload #10
    //   2354: invokeinterface next : ()Ljava/lang/Object;
    //   2359: checkcast androidx/fragment/app/d$b
    //   2362: astore #14
    //   2364: aload #14
    //   2366: invokevirtual b : ()Z
    //   2369: ifeq -> 2375
    //   2372: goto -> 2498
    //   2375: aload #14
    //   2377: aload #12
    //   2379: invokevirtual c : (Landroid/content/Context;)Landroidx/fragment/app/v$a;
    //   2382: astore #15
    //   2384: aload #15
    //   2386: ifnonnull -> 2392
    //   2389: goto -> 2498
    //   2392: aload #15
    //   2394: getfield b : Landroid/animation/Animator;
    //   2397: astore #15
    //   2399: aload #15
    //   2401: ifnonnull -> 2415
    //   2404: aload #13
    //   2406: aload #14
    //   2408: invokevirtual add : (Ljava/lang/Object;)Z
    //   2411: pop
    //   2412: goto -> 2342
    //   2415: aload #14
    //   2417: getfield a : Landroidx/fragment/app/b1$b;
    //   2420: astore #16
    //   2422: aload #16
    //   2424: getfield c : Landroidx/fragment/app/o;
    //   2427: astore #17
    //   2429: getstatic java/lang/Boolean.TRUE : Ljava/lang/Boolean;
    //   2432: aload #8
    //   2434: aload #16
    //   2436: invokevirtual get : (Ljava/lang/Object;)Ljava/lang/Object;
    //   2439: invokevirtual equals : (Ljava/lang/Object;)Z
    //   2442: ifeq -> 2506
    //   2445: iconst_2
    //   2446: invokestatic O : (I)Z
    //   2449: ifeq -> 2498
    //   2452: new java/lang/StringBuilder
    //   2455: dup
    //   2456: invokespecial <init> : ()V
    //   2459: astore #15
    //   2461: aload #15
    //   2463: ldc_w 'Ignoring Animator set on '
    //   2466: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   2469: pop
    //   2470: aload #15
    //   2472: aload #17
    //   2474: invokevirtual append : (Ljava/lang/Object;)Ljava/lang/StringBuilder;
    //   2477: pop
    //   2478: aload #15
    //   2480: ldc_w ' as this Fragment was involved in a Transition.'
    //   2483: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   2486: pop
    //   2487: aload #9
    //   2489: aload #15
    //   2491: invokevirtual toString : ()Ljava/lang/String;
    //   2494: invokestatic v : (Ljava/lang/String;Ljava/lang/String;)I
    //   2497: pop
    //   2498: aload #14
    //   2500: invokevirtual a : ()V
    //   2503: goto -> 2342
    //   2506: aload #16
    //   2508: getfield a : I
    //   2511: iconst_3
    //   2512: if_icmpne -> 2520
    //   2515: iconst_1
    //   2516: istore_2
    //   2517: goto -> 2522
    //   2520: iconst_0
    //   2521: istore_2
    //   2522: iload_2
    //   2523: ifeq -> 2533
    //   2526: aload_1
    //   2527: aload #16
    //   2529: invokevirtual remove : (Ljava/lang/Object;)Z
    //   2532: pop
    //   2533: aload #17
    //   2535: getfield L : Landroid/view/View;
    //   2538: astore #17
    //   2540: aload #11
    //   2542: aload #17
    //   2544: invokevirtual startViewTransition : (Landroid/view/View;)V
    //   2547: aload #15
    //   2549: new androidx/fragment/app/e
    //   2552: dup
    //   2553: aload_0
    //   2554: aload #11
    //   2556: aload #17
    //   2558: iload_2
    //   2559: aload #16
    //   2561: aload #14
    //   2563: invokespecial <init> : (Landroidx/fragment/app/d;Landroid/view/ViewGroup;Landroid/view/View;ZLandroidx/fragment/app/b1$b;Landroidx/fragment/app/d$b;)V
    //   2566: invokevirtual addListener : (Landroid/animation/Animator$AnimatorListener;)V
    //   2569: aload #15
    //   2571: aload #17
    //   2573: invokevirtual setTarget : (Ljava/lang/Object;)V
    //   2576: aload #15
    //   2578: invokevirtual start : ()V
    //   2581: aload #14
    //   2583: getfield b : Lg0/b;
    //   2586: new androidx/fragment/app/f
    //   2589: dup
    //   2590: aload_0
    //   2591: aload #15
    //   2593: invokespecial <init> : (Landroidx/fragment/app/d;Landroid/animation/Animator;)V
    //   2596: invokevirtual b : (Lg0/b$a;)V
    //   2599: iconst_1
    //   2600: istore_3
    //   2601: goto -> 2342
    //   2604: aload #13
    //   2606: invokevirtual iterator : ()Ljava/util/Iterator;
    //   2609: astore #13
    //   2611: aload #13
    //   2613: invokeinterface hasNext : ()Z
    //   2618: ifeq -> 2894
    //   2621: aload #13
    //   2623: invokeinterface next : ()Ljava/lang/Object;
    //   2628: checkcast androidx/fragment/app/d$b
    //   2631: astore #14
    //   2633: aload #14
    //   2635: getfield a : Landroidx/fragment/app/b1$b;
    //   2638: astore #8
    //   2640: aload #8
    //   2642: getfield c : Landroidx/fragment/app/o;
    //   2645: astore #10
    //   2647: iload #6
    //   2649: ifeq -> 2693
    //   2652: iconst_2
    //   2653: invokestatic O : (I)Z
    //   2656: ifeq -> 2754
    //   2659: new java/lang/StringBuilder
    //   2662: dup
    //   2663: invokespecial <init> : ()V
    //   2666: astore #8
    //   2668: aload #8
    //   2670: ldc_w 'Ignoring Animation set on '
    //   2673: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   2676: pop
    //   2677: aload #8
    //   2679: aload #10
    //   2681: invokevirtual append : (Ljava/lang/Object;)Ljava/lang/StringBuilder;
    //   2684: pop
    //   2685: ldc_w ' as Animations cannot run alongside Transitions.'
    //   2688: astore #10
    //   2690: goto -> 2735
    //   2693: iload_3
    //   2694: ifeq -> 2762
    //   2697: iconst_2
    //   2698: invokestatic O : (I)Z
    //   2701: ifeq -> 2754
    //   2704: new java/lang/StringBuilder
    //   2707: dup
    //   2708: invokespecial <init> : ()V
    //   2711: astore #8
    //   2713: aload #8
    //   2715: ldc_w 'Ignoring Animation set on '
    //   2718: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   2721: pop
    //   2722: aload #8
    //   2724: aload #10
    //   2726: invokevirtual append : (Ljava/lang/Object;)Ljava/lang/StringBuilder;
    //   2729: pop
    //   2730: ldc_w ' as Animations cannot run alongside Animators.'
    //   2733: astore #10
    //   2735: aload #8
    //   2737: aload #10
    //   2739: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   2742: pop
    //   2743: aload #9
    //   2745: aload #8
    //   2747: invokevirtual toString : ()Ljava/lang/String;
    //   2750: invokestatic v : (Ljava/lang/String;Ljava/lang/String;)I
    //   2753: pop
    //   2754: aload #14
    //   2756: invokevirtual a : ()V
    //   2759: goto -> 2611
    //   2762: aload #10
    //   2764: getfield L : Landroid/view/View;
    //   2767: astore #10
    //   2769: aload #14
    //   2771: aload #12
    //   2773: invokevirtual c : (Landroid/content/Context;)Landroidx/fragment/app/v$a;
    //   2776: astore #15
    //   2778: aload #15
    //   2780: invokestatic requireNonNull : (Ljava/lang/Object;)Ljava/lang/Object;
    //   2783: pop
    //   2784: aload #15
    //   2786: getfield a : Landroid/view/animation/Animation;
    //   2789: astore #15
    //   2791: aload #15
    //   2793: invokestatic requireNonNull : (Ljava/lang/Object;)Ljava/lang/Object;
    //   2796: pop
    //   2797: aload #8
    //   2799: getfield a : I
    //   2802: iconst_1
    //   2803: if_icmpeq -> 2821
    //   2806: aload #10
    //   2808: aload #15
    //   2810: invokevirtual startAnimation : (Landroid/view/animation/Animation;)V
    //   2813: aload #14
    //   2815: invokevirtual a : ()V
    //   2818: goto -> 2869
    //   2821: aload #11
    //   2823: aload #10
    //   2825: invokevirtual startViewTransition : (Landroid/view/View;)V
    //   2828: new androidx/fragment/app/v$b
    //   2831: dup
    //   2832: aload #15
    //   2834: aload #11
    //   2836: aload #10
    //   2838: invokespecial <init> : (Landroid/view/animation/Animation;Landroid/view/ViewGroup;Landroid/view/View;)V
    //   2841: astore #8
    //   2843: aload #8
    //   2845: new androidx/fragment/app/g
    //   2848: dup
    //   2849: aload_0
    //   2850: aload #11
    //   2852: aload #10
    //   2854: aload #14
    //   2856: invokespecial <init> : (Landroidx/fragment/app/d;Landroid/view/ViewGroup;Landroid/view/View;Landroidx/fragment/app/d$b;)V
    //   2859: invokevirtual setAnimationListener : (Landroid/view/animation/Animation$AnimationListener;)V
    //   2862: aload #10
    //   2864: aload #8
    //   2866: invokevirtual startAnimation : (Landroid/view/animation/Animation;)V
    //   2869: aload #14
    //   2871: getfield b : Lg0/b;
    //   2874: new androidx/fragment/app/h
    //   2877: dup
    //   2878: aload_0
    //   2879: aload #10
    //   2881: aload #11
    //   2883: aload #14
    //   2885: invokespecial <init> : (Landroidx/fragment/app/d;Landroid/view/View;Landroid/view/ViewGroup;Landroidx/fragment/app/d$b;)V
    //   2888: invokevirtual b : (Lg0/b$a;)V
    //   2891: goto -> 2611
    //   2894: aload_1
    //   2895: invokevirtual iterator : ()Ljava/util/Iterator;
    //   2898: astore #8
    //   2900: aload #8
    //   2902: invokeinterface hasNext : ()Z
    //   2907: ifeq -> 2945
    //   2910: aload #8
    //   2912: invokeinterface next : ()Ljava/lang/Object;
    //   2917: checkcast androidx/fragment/app/b1$b
    //   2920: astore #9
    //   2922: aload #9
    //   2924: getfield c : Landroidx/fragment/app/o;
    //   2927: getfield L : Landroid/view/View;
    //   2930: astore #10
    //   2932: aload #9
    //   2934: getfield a : I
    //   2937: aload #10
    //   2939: invokestatic a : (ILandroid/view/View;)V
    //   2942: goto -> 2900
    //   2945: aload_1
    //   2946: invokevirtual clear : ()V
    //   2949: return
  }
  
  public void j(ArrayList<View> paramArrayList, View paramView) {
    if (paramView instanceof ViewGroup) {
      ViewGroup viewGroup = (ViewGroup)paramView;
      if (viewGroup.isTransitionGroup()) {
        if (!paramArrayList.contains(paramView)) {
          paramArrayList.add(viewGroup);
          return;
        } 
      } else {
        int j = viewGroup.getChildCount();
        for (int i = 0; i < j; i++) {
          paramView = viewGroup.getChildAt(i);
          if (paramView.getVisibility() == 0)
            j(paramArrayList, paramView); 
        } 
      } 
    } else if (!paramArrayList.contains(paramView)) {
      paramArrayList.add(paramView);
    } 
  }
  
  public void k(Map<String, View> paramMap, View paramView) {
    WeakHashMap weakHashMap = l.a;
    String str = paramView.getTransitionName();
    if (str != null)
      paramMap.put(str, paramView); 
    if (paramView instanceof ViewGroup) {
      ViewGroup viewGroup = (ViewGroup)paramView;
      int j = viewGroup.getChildCount();
      for (int i = 0; i < j; i++) {
        View view = viewGroup.getChildAt(i);
        if (view.getVisibility() == 0)
          k(paramMap, view); 
      } 
    } 
  }
  
  public void l(r.a<String, View> parama, Collection<String> paramCollection) {
    Iterator iterator = ((f.b)parama.entrySet()).iterator();
    while (true) {
      f.d d1 = (f.d)iterator;
      if (d1.hasNext()) {
        d1.next();
        View view = (View)((Map.Entry)d1).getValue();
        WeakHashMap weakHashMap = l.a;
        if (!paramCollection.contains(view.getTransitionName()))
          d1.remove(); 
        continue;
      } 
      break;
    } 
  }
  
  public class a implements Runnable {
    public a(d this$0, List param1List, b1.b param1b) {}
    
    public void run() {
      if (this.h.contains(this.i)) {
        this.h.remove(this.i);
        d d1 = this.j;
        b1.b b1 = this.i;
        Objects.requireNonNull(d1);
        View view = b1.c.L;
        e1.a(b1.a, view);
      } 
    }
  }
  
  public static class b extends c {
    public boolean c;
    
    public boolean d = false;
    
    public v.a e;
    
    public b(b1.b param1b, g0.b param1b1, boolean param1Boolean) {
      super(param1b, param1b1);
      this.c = param1Boolean;
    }
    
    public v.a c(Context param1Context) {
      boolean bool;
      if (this.d)
        return this.e; 
      b1.b b1 = this.a;
      o o = b1.c;
      if (b1.a == 2) {
        bool = true;
      } else {
        bool = false;
      } 
      v.a a1 = v.a(param1Context, o, bool, this.c);
      this.e = a1;
      this.d = true;
      return a1;
    }
  }
  
  public static class c {
    public final b1.b a;
    
    public final g0.b b;
    
    public c(b1.b param1b, g0.b param1b1) {
      this.a = param1b;
      this.b = param1b1;
    }
    
    public void a() {
      b1.b b1 = this.a;
      g0.b b2 = this.b;
      if (b1.e.remove(b2) && b1.e.isEmpty())
        b1.b(); 
    }
    
    public boolean b() {
      int i = e1.c(this.a.c.L);
      int j = this.a.a;
      return (i == j || (i != 2 && j != 2));
    }
  }
  
  public static class d extends c {
    public final Object c;
    
    public final boolean d;
    
    public final Object e;
    
    public d(b1.b param1b, g0.b param1b1, boolean param1Boolean1, boolean param1Boolean2) {
      super(param1b, param1b1);
      if (param1b.a == 2) {
        if (param1Boolean1) {
          Object object = param1b.c.v();
        } else {
          param1b.c.l();
          param1b1 = null;
        } 
        this.c = param1b1;
        if (param1Boolean1) {
          o.b b1 = param1b.c.O;
        } else {
          o.b b1 = param1b.c.O;
        } 
      } else {
        if (param1Boolean1) {
          Object object = param1b.c.x();
        } else {
          param1b.c.o();
          param1b1 = null;
        } 
        this.c = param1b1;
      } 
      this.d = true;
      if (param1Boolean2) {
        if (param1Boolean1) {
          this.e = param1b.c.z();
          return;
        } 
        param1b.c.y();
      } 
      this.e = null;
    }
    
    public final u0 c(Object param1Object) {
      if (param1Object == null)
        return null; 
      u0 u0 = s0.b;
      if (param1Object instanceof android.transition.Transition)
        return u0; 
      u0 = s0.c;
      if (u0 != null && u0.e(param1Object))
        return u0; 
      StringBuilder stringBuilder = new StringBuilder();
      stringBuilder.append("Transition ");
      stringBuilder.append(param1Object);
      stringBuilder.append(" for fragment ");
      stringBuilder.append(this.a.c);
      stringBuilder.append(" is not a valid framework Transition or AndroidX Transition");
      throw new IllegalArgumentException(stringBuilder.toString());
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Luxury Logo Maker_ Logo Design-dex2jar.jar!\androidx\fragment\app\d.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */