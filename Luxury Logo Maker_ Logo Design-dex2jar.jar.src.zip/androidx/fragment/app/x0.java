package androidx.fragment.app;

import androidx.lifecycle.a0;
import androidx.lifecycle.e;
import androidx.lifecycle.i;
import androidx.lifecycle.j;
import androidx.lifecycle.z;
import androidx.savedstate.a;
import androidx.savedstate.b;
import androidx.savedstate.c;

public class x0 implements c, a0 {
  public final z h;
  
  public j i = null;
  
  public b j = null;
  
  public x0(o paramo, z paramz) {
    this.h = paramz;
  }
  
  public e a() {
    e();
    return (e)this.i;
  }
  
  public void b(e.b paramb) {
    j j1 = this.i;
    j1.c("handleLifecycleEvent");
    j1.f(paramb.a());
  }
  
  public a d() {
    e();
    return this.j.b;
  }
  
  public void e() {
    if (this.i == null) {
      this.i = new j((i)this);
      this.j = new b(this);
    } 
  }
  
  public z j() {
    e();
    return this.h;
  }
}


/* Location:              C:\soft\dex2jar-2.0\Luxury Logo Maker_ Logo Design-dex2jar.jar!\androidx\fragment\app\x0.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */