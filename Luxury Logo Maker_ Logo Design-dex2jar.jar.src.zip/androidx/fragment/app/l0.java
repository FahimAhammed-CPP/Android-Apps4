package androidx.fragment.app;

import androidx.lifecycle.e;
import java.util.ArrayList;

public abstract class l0 {
  public ArrayList<a> a = new ArrayList<a>();
  
  public int b;
  
  public int c;
  
  public int d;
  
  public int e;
  
  public int f;
  
  public boolean g;
  
  public String h;
  
  public int i;
  
  public CharSequence j;
  
  public int k;
  
  public CharSequence l;
  
  public ArrayList<String> m;
  
  public ArrayList<String> n;
  
  public boolean o = false;
  
  public l0(z paramz, ClassLoader paramClassLoader) {}
  
  public void b(a parama) {
    this.a.add(parama);
    parama.c = this.b;
    parama.d = this.c;
    parama.e = this.d;
    parama.f = this.e;
  }
  
  public abstract void c(int paramInt1, o paramo, String paramString, int paramInt2);
  
  public l0 d(int paramInt, o paramo) {
    if (paramInt != 0) {
      c(paramInt, paramo, null, 2);
      return this;
    } 
    throw new IllegalArgumentException("Must use non-zero containerViewId");
  }
  
  public static final class a {
    public int a;
    
    public o b;
    
    public int c;
    
    public int d;
    
    public int e;
    
    public int f;
    
    public e.c g;
    
    public e.c h;
    
    public a() {}
    
    public a(int param1Int, o param1o) {
      this.a = param1Int;
      this.b = param1o;
      e.c c1 = e.c.l;
      this.g = c1;
      this.h = c1;
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Luxury Logo Maker_ Logo Design-dex2jar.jar!\androidx\fragment\app\l0.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */