package androidx.fragment.app;

import android.content.Context;
import android.os.Bundle;
import android.os.Parcelable;
import c.b;

public class q implements b {
  public q(r paramr) {}
  
  public void a(Context paramContext) {
    a0<?> a0 = this.a.o.a;
    a0.k.b(a0, a0, null);
    Bundle bundle = this.a.k.b.a("android:support:fragments");
    if (bundle != null) {
      Parcelable parcelable = bundle.getParcelable("android:support:fragments");
      a0<?> a01 = this.a.o.a;
      if (a01 instanceof androidx.lifecycle.a0) {
        a01.k.a0(parcelable);
        return;
      } 
      throw new IllegalStateException("Your FragmentHostCallback must implement ViewModelStoreOwner to call restoreSaveState(). Call restoreAllState()  if you're still using retainNestedNonConfig().");
    } 
  }
}


/* Location:              C:\soft\dex2jar-2.0\Luxury Logo Maker_ Logo Design-dex2jar.jar!\androidx\fragment\app\q.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */