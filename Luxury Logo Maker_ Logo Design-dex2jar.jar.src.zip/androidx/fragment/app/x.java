package androidx.fragment.app;

import android.animation.LayoutTransition;
import android.content.Context;
import android.content.res.TypedArray;
import android.graphics.Canvas;
import android.util.AttributeSet;
import android.view.View;
import android.view.ViewGroup;
import android.view.WindowInsets;
import android.widget.FrameLayout;
import com.bumptech.glide.manager.i;
import d0.c;
import j.f;
import java.util.ArrayList;
import k0.l;
import k0.r;

public final class x extends FrameLayout {
  public ArrayList<View> h;
  
  public ArrayList<View> i;
  
  public View.OnApplyWindowInsetsListener j;
  
  public boolean k = true;
  
  public x(Context paramContext, AttributeSet paramAttributeSet, d0 paramd0) {
    super(paramContext, paramAttributeSet);
    String str2 = paramAttributeSet.getClassAttribute();
    TypedArray typedArray = paramContext.obtainStyledAttributes(paramAttributeSet, i.q);
    String str1 = str2;
    if (str2 == null)
      str1 = typedArray.getString(0); 
    str2 = typedArray.getString(1);
    typedArray.recycle();
    int i = getId();
    o o = paramd0.H(i);
    if (str1 != null && o == null) {
      String str;
      if (i <= 0) {
        if (str2 != null) {
          str = f.a(" with tag ", str2);
        } else {
          str = "";
        } 
        throw new IllegalStateException(c.a("FragmentContainerView must have an android:id to add Fragment ", str1, str));
      } 
      o o1 = paramd0.K().a(str.getClassLoader(), str1);
      o1.M((Context)str, paramAttributeSet, null);
      b b = new b(paramd0);
      b.o = true;
      o1.K = (ViewGroup)this;
      b.c(getId(), o1, str2, 1);
      if (!b.g) {
        b.p.D(b, true);
      } else {
        throw new IllegalStateException("This transaction is already being added to the back stack");
      } 
    } 
    for (j0 j0 : paramd0.c.f()) {
      o o1 = j0.c;
      if (o1.D == getId()) {
        View view = o1.L;
        if (view != null && view.getParent() == null) {
          o1.K = (ViewGroup)this;
          j0.b();
        } 
      } 
    } 
  }
  
  public final void a(View paramView) {
    ArrayList<View> arrayList = this.i;
    if (arrayList != null && arrayList.contains(paramView)) {
      if (this.h == null)
        this.h = new ArrayList<View>(); 
      this.h.add(paramView);
    } 
  }
  
  public void addView(View paramView, int paramInt, ViewGroup.LayoutParams paramLayoutParams) {
    Object object = paramView.getTag(2131362069);
    if (object instanceof o) {
      object = object;
    } else {
      object = null;
    } 
    if (object != null) {
      super.addView(paramView, paramInt, paramLayoutParams);
      return;
    } 
    StringBuilder stringBuilder = new StringBuilder();
    stringBuilder.append("Views added to a FragmentContainerView must be associated with a Fragment. View ");
    stringBuilder.append(paramView);
    stringBuilder.append(" is not associated with a Fragment.");
    throw new IllegalStateException(stringBuilder.toString());
  }
  
  public boolean addViewInLayout(View paramView, int paramInt, ViewGroup.LayoutParams paramLayoutParams, boolean paramBoolean) {
    Object object = paramView.getTag(2131362069);
    if (object instanceof o) {
      object = object;
    } else {
      object = null;
    } 
    if (object != null)
      return super.addViewInLayout(paramView, paramInt, paramLayoutParams, paramBoolean); 
    StringBuilder stringBuilder = new StringBuilder();
    stringBuilder.append("Views added to a FragmentContainerView must be associated with a Fragment. View ");
    stringBuilder.append(paramView);
    stringBuilder.append(" is not associated with a Fragment.");
    throw new IllegalStateException(stringBuilder.toString());
  }
  
  public WindowInsets dispatchApplyWindowInsets(WindowInsets paramWindowInsets) {
    r r = r.i(paramWindowInsets, null);
    View.OnApplyWindowInsetsListener onApplyWindowInsetsListener = this.j;
    if (onApplyWindowInsetsListener != null) {
      r = r.h(onApplyWindowInsetsListener.onApplyWindowInsets((View)this, paramWindowInsets));
    } else {
      r = l.o((View)this, r);
    } 
    if (!r.f()) {
      int j = getChildCount();
      for (int i = 0; i < j; i++)
        l.e(getChildAt(i), r); 
    } 
    return paramWindowInsets;
  }
  
  public void dispatchDraw(Canvas paramCanvas) {
    if (this.k && this.h != null)
      for (int i = 0; i < this.h.size(); i++)
        super.drawChild(paramCanvas, this.h.get(i), getDrawingTime());  
    super.dispatchDraw(paramCanvas);
  }
  
  public boolean drawChild(Canvas paramCanvas, View paramView, long paramLong) {
    if (this.k) {
      ArrayList<View> arrayList = this.h;
      if (arrayList != null && arrayList.size() > 0 && this.h.contains(paramView))
        return false; 
    } 
    return super.drawChild(paramCanvas, paramView, paramLong);
  }
  
  public void endViewTransition(View paramView) {
    ArrayList<View> arrayList = this.i;
    if (arrayList != null) {
      arrayList.remove(paramView);
      arrayList = this.h;
      if (arrayList != null && arrayList.remove(paramView))
        this.k = true; 
    } 
    super.endViewTransition(paramView);
  }
  
  public WindowInsets onApplyWindowInsets(WindowInsets paramWindowInsets) {
    return paramWindowInsets;
  }
  
  public void removeAllViewsInLayout() {
    for (int i = getChildCount() - 1; i >= 0; i--)
      a(getChildAt(i)); 
    super.removeAllViewsInLayout();
  }
  
  public void removeDetachedView(View paramView, boolean paramBoolean) {
    if (paramBoolean)
      a(paramView); 
    super.removeDetachedView(paramView, paramBoolean);
  }
  
  public void removeView(View paramView) {
    a(paramView);
    super.removeView(paramView);
  }
  
  public void removeViewAt(int paramInt) {
    a(getChildAt(paramInt));
    super.removeViewAt(paramInt);
  }
  
  public void removeViewInLayout(View paramView) {
    a(paramView);
    super.removeViewInLayout(paramView);
  }
  
  public void removeViews(int paramInt1, int paramInt2) {
    for (int i = paramInt1; i < paramInt1 + paramInt2; i++)
      a(getChildAt(i)); 
    super.removeViews(paramInt1, paramInt2);
  }
  
  public void removeViewsInLayout(int paramInt1, int paramInt2) {
    for (int i = paramInt1; i < paramInt1 + paramInt2; i++)
      a(getChildAt(i)); 
    super.removeViewsInLayout(paramInt1, paramInt2);
  }
  
  public void setDrawDisappearingViewsLast(boolean paramBoolean) {
    this.k = paramBoolean;
  }
  
  public void setLayoutTransition(LayoutTransition paramLayoutTransition) {
    throw new UnsupportedOperationException("FragmentContainerView does not support Layout Transitions or animateLayoutChanges=\"true\".");
  }
  
  public void setOnApplyWindowInsetsListener(View.OnApplyWindowInsetsListener paramOnApplyWindowInsetsListener) {
    this.j = paramOnApplyWindowInsetsListener;
  }
  
  public void startViewTransition(View paramView) {
    if (paramView.getParent() == this) {
      if (this.i == null)
        this.i = new ArrayList<View>(); 
      this.i.add(paramView);
    } 
    super.startViewTransition(paramView);
  }
}


/* Location:              C:\soft\dex2jar-2.0\Luxury Logo Maker_ Logo Design-dex2jar.jar!\androidx\fragment\app\x.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */