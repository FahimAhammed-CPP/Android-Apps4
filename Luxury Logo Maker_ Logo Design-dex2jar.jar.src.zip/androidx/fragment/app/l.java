package androidx.fragment.app;

public class l implements Runnable {
  public l(d paramd, d.d paramd1) {}
  
  public void run() {
    this.h.a();
  }
}


/* Location:              C:\soft\dex2jar-2.0\Luxury Logo Maker_ Logo Design-dex2jar.jar!\androidx\fragment\app\l.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */