package androidx.fragment.app;

import android.view.View;
import g0.b;

public class s implements b.a {
  public s(o paramo) {}
  
  public void a() {
    if (this.a.g() != null) {
      View view = this.a.g();
      this.a.Z(null);
      view.clearAnimation();
    } 
    this.a.b0(null);
  }
}


/* Location:              C:\soft\dex2jar-2.0\Luxury Logo Maker_ Logo Design-dex2jar.jar!\androidx\fragment\app\s.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */