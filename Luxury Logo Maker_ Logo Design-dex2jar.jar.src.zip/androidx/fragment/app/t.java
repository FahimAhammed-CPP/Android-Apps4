package androidx.fragment.app;

import android.view.ViewGroup;
import android.view.animation.Animation;
import g0.b;

public class t implements Animation.AnimationListener {
  public t(ViewGroup paramViewGroup, o paramo, s0.a parama, b paramb) {}
  
  public void onAnimationEnd(Animation paramAnimation) {
    this.a.post(new a(this));
  }
  
  public void onAnimationRepeat(Animation paramAnimation) {}
  
  public void onAnimationStart(Animation paramAnimation) {}
  
  public class a implements Runnable {
    public a(t this$0) {}
    
    public void run() {
      if (this.h.b.g() != null) {
        this.h.b.Z(null);
        t t1 = this.h;
        s0.a a1 = t1.c;
        o o = t1.b;
        b b = t1.d;
        ((d0.d)a1).a(o, b);
      } 
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Luxury Logo Maker_ Logo Design-dex2jar.jar!\androidx\fragment\app\t.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */