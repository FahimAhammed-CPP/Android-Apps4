package androidx.fragment.app;

import android.animation.Animator;
import g0.b;

public class f implements b.a {
  public f(d paramd, Animator paramAnimator) {}
  
  public void a() {
    this.a.end();
  }
}


/* Location:              C:\soft\dex2jar-2.0\Luxury Logo Maker_ Logo Design-dex2jar.jar!\androidx\fragment\app\f.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */