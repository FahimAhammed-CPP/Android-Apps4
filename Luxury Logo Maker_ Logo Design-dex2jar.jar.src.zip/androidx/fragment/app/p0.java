package androidx.fragment.app;

import android.view.View;
import java.util.ArrayList;
import java.util.Collection;

public class p0 implements Runnable {
  public p0(Object paramObject1, u0 paramu0, View paramView, o paramo, ArrayList paramArrayList1, ArrayList paramArrayList2, ArrayList paramArrayList3, Object paramObject2) {}
  
  public void run() {
    Object<View> object = (Object<View>)this.h;
    if (object != null) {
      this.i.o(object, this.j);
      object = (Object<View>)s0.h(this.i, this.h, this.k, this.l, this.j);
      this.m.addAll((Collection<? extends View>)object);
    } 
    if (this.n != null) {
      if (this.o != null) {
        object = (Object<View>)new ArrayList();
        object.add(this.j);
        this.i.p(this.o, this.n, (ArrayList<View>)object);
      } 
      this.n.clear();
      this.n.add(this.j);
    } 
  }
}


/* Location:              C:\soft\dex2jar-2.0\Luxury Logo Maker_ Logo Design-dex2jar.jar!\androidx\fragment\app\p0.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */