package androidx.fragment.app;

import android.animation.Animator;
import android.annotation.SuppressLint;
import android.app.Activity;
import android.content.ComponentCallbacks;
import android.content.Context;
import android.content.Intent;
import android.content.res.Configuration;
import android.content.res.Resources;
import android.os.Bundle;
import android.os.Parcelable;
import android.util.AttributeSet;
import android.util.Log;
import android.util.SparseArray;
import android.view.ContextMenu;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.View;
import android.view.ViewGroup;
import androidx.lifecycle.a0;
import androidx.lifecycle.i;
import androidx.lifecycle.j;
import androidx.lifecycle.z;
import androidx.savedstate.c;
import java.io.FileDescriptor;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.Objects;
import java.util.UUID;
import java.util.concurrent.atomic.AtomicInteger;

public class o implements ComponentCallbacks, View.OnCreateContextMenuListener, i, a0, c {
  public static final Object Y = new Object();
  
  public d0 A = new e0();
  
  public o B;
  
  public int C;
  
  public int D;
  
  public String E;
  
  public boolean F;
  
  public boolean G;
  
  public boolean H;
  
  public boolean I = true;
  
  public boolean J;
  
  public ViewGroup K;
  
  public View L;
  
  public boolean M;
  
  public boolean N = true;
  
  public b O;
  
  public boolean P;
  
  public float Q;
  
  public boolean R;
  
  public androidx.lifecycle.e.c S = androidx.lifecycle.e.c.l;
  
  public j T;
  
  public x0 U;
  
  public androidx.lifecycle.o<i> V = new androidx.lifecycle.o();
  
  public androidx.savedstate.b W;
  
  public final ArrayList<d> X;
  
  public int h = -1;
  
  public Bundle i;
  
  public SparseArray<Parcelable> j;
  
  public Bundle k;
  
  public String l = UUID.randomUUID().toString();
  
  public Bundle m;
  
  public o n;
  
  public String o = null;
  
  public int p;
  
  public Boolean q = null;
  
  public boolean r;
  
  public boolean s;
  
  public boolean t;
  
  public boolean u;
  
  public boolean v;
  
  public boolean w;
  
  public int x;
  
  public d0 y;
  
  public a0<?> z;
  
  public o() {
    new AtomicInteger();
    this.X = new ArrayList<d>();
    this.T = new j(this);
    this.W = new androidx.savedstate.b(this);
  }
  
  public final String A(int paramInt) {
    return w().getString(paramInt);
  }
  
  public final boolean B() {
    return (this.x > 0);
  }
  
  public boolean C() {
    return false;
  }
  
  public final boolean D() {
    o o1 = this.B;
    return (o1 != null && (o1.s || o1.D()));
  }
  
  @Deprecated
  public void E(int paramInt1, int paramInt2, Intent paramIntent) {
    if (d0.O(2)) {
      StringBuilder stringBuilder = new StringBuilder();
      stringBuilder.append("Fragment ");
      stringBuilder.append(this);
      stringBuilder.append(" received the following in onActivityResult(): requestCode: ");
      stringBuilder.append(paramInt1);
      stringBuilder.append(" resultCode: ");
      stringBuilder.append(paramInt2);
      stringBuilder.append(" data: ");
      stringBuilder.append(paramIntent);
      Log.v("FragmentManager", stringBuilder.toString());
    } 
  }
  
  public void F(Context paramContext) {
    Activity activity;
    this.J = true;
    a0<?> a01 = this.z;
    if (a01 == null) {
      a01 = null;
    } else {
      activity = a01.h;
    } 
    if (activity != null) {
      this.J = false;
      this.J = true;
    } 
  }
  
  public void G(Bundle paramBundle) {
    boolean bool = true;
    this.J = true;
    if (paramBundle != null) {
      Parcelable parcelable = paramBundle.getParcelable("android:support:fragments");
      if (parcelable != null) {
        this.A.a0(parcelable);
        this.A.m();
      } 
    } 
    d0 d01 = this.A;
    if (d01.p < 1)
      bool = false; 
    if (!bool)
      d01.m(); 
  }
  
  public View H(LayoutInflater paramLayoutInflater, ViewGroup paramViewGroup, Bundle paramBundle) {
    return null;
  }
  
  public void I() {
    this.J = true;
  }
  
  public void J() {
    this.J = true;
  }
  
  public void K() {
    this.J = true;
  }
  
  public LayoutInflater L(Bundle paramBundle) {
    a0<?> a01 = this.z;
    if (a01 != null) {
      LayoutInflater layoutInflater = a01.i();
      layoutInflater.setFactory2(this.A.f);
      return layoutInflater;
    } 
    throw new IllegalStateException("onGetLayoutInflater() cannot be executed until the Fragment is attached to the FragmentManager.");
  }
  
  public void M(Context paramContext, AttributeSet paramAttributeSet, Bundle paramBundle) {
    Activity activity;
    this.J = true;
    a0<?> a01 = this.z;
    if (a01 == null) {
      a01 = null;
    } else {
      activity = a01.h;
    } 
    if (activity != null) {
      this.J = false;
      this.J = true;
    } 
  }
  
  public void N() {
    this.J = true;
  }
  
  public void O(Bundle paramBundle) {}
  
  public void P() {
    this.J = true;
  }
  
  public void Q() {
    this.J = true;
  }
  
  public void R(View paramView, Bundle paramBundle) {}
  
  public void S(Bundle paramBundle) {
    this.J = true;
  }
  
  public void T(LayoutInflater paramLayoutInflater, ViewGroup paramViewGroup, Bundle paramBundle) {
    this.A.V();
    boolean bool = true;
    this.w = true;
    this.U = new x0(this, j());
    View view = H(paramLayoutInflater, paramViewGroup, paramBundle);
    this.L = view;
    if (view != null) {
      this.U.e();
      this.L.setTag(2131362471, this.U);
      this.L.setTag(2131362473, this.U);
      this.L.setTag(2131362472, this.U);
      this.V.h(this.U);
      return;
    } 
    if (this.U.i == null)
      bool = false; 
    if (!bool) {
      this.U = null;
      return;
    } 
    throw new IllegalStateException("Called getViewLifecycleOwner() but onCreateView() returned null");
  }
  
  public void U() {
    this.A.w(1);
    if (this.L != null) {
      boolean bool;
      x0 x01 = this.U;
      x01.e();
      if (x01.i.b.compareTo(androidx.lifecycle.e.c.j) >= 0) {
        bool = true;
      } else {
        bool = false;
      } 
      if (bool)
        this.U.b(androidx.lifecycle.e.b.ON_DESTROY); 
    } 
    this.h = 1;
    this.J = false;
    J();
    if (this.J) {
      t0.b.b b1 = ((t0.b)t0.a.b(this)).b;
      int m = b1.b.g();
      for (int k = 0; k < m; k++)
        Objects.requireNonNull((t0.b.a)b1.b.h(k)); 
      this.w = false;
      return;
    } 
    throw new g1(n.b("Fragment ", this, " did not call through to super.onDestroyView()"));
  }
  
  public void V() {
    onLowMemory();
    this.A.p();
  }
  
  public boolean W(Menu paramMenu) {
    boolean bool = this.F;
    int k = 0;
    if (!bool)
      k = false | this.A.v(paramMenu); 
    return k;
  }
  
  public final Context X() {
    Context context = i();
    if (context != null)
      return context; 
    throw new IllegalStateException(n.b("Fragment ", this, " not attached to a context."));
  }
  
  public final View Y() {
    View view = this.L;
    if (view != null)
      return view; 
    throw new IllegalStateException(n.b("Fragment ", this, " did not return a View from onCreateView() or this was called before onCreateView()."));
  }
  
  public void Z(View paramView) {
    (f()).a = paramView;
  }
  
  public androidx.lifecycle.e a() {
    return (androidx.lifecycle.e)this.T;
  }
  
  public void a0(int paramInt1, int paramInt2, int paramInt3, int paramInt4) {
    if (this.O == null && paramInt1 == 0 && paramInt2 == 0 && paramInt3 == 0 && paramInt4 == 0)
      return; 
    (f()).d = paramInt1;
    (f()).e = paramInt2;
    (f()).f = paramInt3;
    (f()).g = paramInt4;
  }
  
  public w b() {
    return new a(this);
  }
  
  public void b0(Animator paramAnimator) {
    (f()).b = paramAnimator;
  }
  
  public void c0(Bundle paramBundle) {
    d0 d01 = this.y;
    if (d01 != null) {
      boolean bool;
      if (d01 == null) {
        bool = false;
      } else {
        bool = d01.S();
      } 
      if (bool)
        throw new IllegalStateException("Fragment already added and state has been saved"); 
    } 
    this.m = paramBundle;
  }
  
  public final androidx.savedstate.a d() {
    return this.W.b;
  }
  
  public void d0(View paramView) {
    (f()).o = null;
  }
  
  public void e(String paramString, FileDescriptor paramFileDescriptor, PrintWriter paramPrintWriter, String[] paramArrayOfString) {
    // Byte code:
    //   0: aload_3
    //   1: aload_1
    //   2: invokevirtual print : (Ljava/lang/String;)V
    //   5: aload_3
    //   6: ldc_w 'mFragmentId=#'
    //   9: invokevirtual print : (Ljava/lang/String;)V
    //   12: aload_3
    //   13: aload_0
    //   14: getfield C : I
    //   17: invokestatic toHexString : (I)Ljava/lang/String;
    //   20: invokevirtual print : (Ljava/lang/String;)V
    //   23: aload_3
    //   24: ldc_w ' mContainerId=#'
    //   27: invokevirtual print : (Ljava/lang/String;)V
    //   30: aload_3
    //   31: aload_0
    //   32: getfield D : I
    //   35: invokestatic toHexString : (I)Ljava/lang/String;
    //   38: invokevirtual print : (Ljava/lang/String;)V
    //   41: aload_3
    //   42: ldc_w ' mTag='
    //   45: invokevirtual print : (Ljava/lang/String;)V
    //   48: aload_3
    //   49: aload_0
    //   50: getfield E : Ljava/lang/String;
    //   53: invokevirtual println : (Ljava/lang/String;)V
    //   56: aload_3
    //   57: aload_1
    //   58: invokevirtual print : (Ljava/lang/String;)V
    //   61: aload_3
    //   62: ldc_w 'mState='
    //   65: invokevirtual print : (Ljava/lang/String;)V
    //   68: aload_3
    //   69: aload_0
    //   70: getfield h : I
    //   73: invokevirtual print : (I)V
    //   76: aload_3
    //   77: ldc_w ' mWho='
    //   80: invokevirtual print : (Ljava/lang/String;)V
    //   83: aload_3
    //   84: aload_0
    //   85: getfield l : Ljava/lang/String;
    //   88: invokevirtual print : (Ljava/lang/String;)V
    //   91: aload_3
    //   92: ldc_w ' mBackStackNesting='
    //   95: invokevirtual print : (Ljava/lang/String;)V
    //   98: aload_3
    //   99: aload_0
    //   100: getfield x : I
    //   103: invokevirtual println : (I)V
    //   106: aload_3
    //   107: aload_1
    //   108: invokevirtual print : (Ljava/lang/String;)V
    //   111: aload_3
    //   112: ldc_w 'mAdded='
    //   115: invokevirtual print : (Ljava/lang/String;)V
    //   118: aload_3
    //   119: aload_0
    //   120: getfield r : Z
    //   123: invokevirtual print : (Z)V
    //   126: aload_3
    //   127: ldc_w ' mRemoving='
    //   130: invokevirtual print : (Ljava/lang/String;)V
    //   133: aload_3
    //   134: aload_0
    //   135: getfield s : Z
    //   138: invokevirtual print : (Z)V
    //   141: aload_3
    //   142: ldc_w ' mFromLayout='
    //   145: invokevirtual print : (Ljava/lang/String;)V
    //   148: aload_3
    //   149: aload_0
    //   150: getfield t : Z
    //   153: invokevirtual print : (Z)V
    //   156: aload_3
    //   157: ldc_w ' mInLayout='
    //   160: invokevirtual print : (Ljava/lang/String;)V
    //   163: aload_3
    //   164: aload_0
    //   165: getfield u : Z
    //   168: invokevirtual println : (Z)V
    //   171: aload_3
    //   172: aload_1
    //   173: invokevirtual print : (Ljava/lang/String;)V
    //   176: aload_3
    //   177: ldc_w 'mHidden='
    //   180: invokevirtual print : (Ljava/lang/String;)V
    //   183: aload_3
    //   184: aload_0
    //   185: getfield F : Z
    //   188: invokevirtual print : (Z)V
    //   191: aload_3
    //   192: ldc_w ' mDetached='
    //   195: invokevirtual print : (Ljava/lang/String;)V
    //   198: aload_3
    //   199: aload_0
    //   200: getfield G : Z
    //   203: invokevirtual print : (Z)V
    //   206: aload_3
    //   207: ldc_w ' mMenuVisible='
    //   210: invokevirtual print : (Ljava/lang/String;)V
    //   213: aload_3
    //   214: aload_0
    //   215: getfield I : Z
    //   218: invokevirtual print : (Z)V
    //   221: aload_3
    //   222: ldc_w ' mHasMenu='
    //   225: invokevirtual print : (Ljava/lang/String;)V
    //   228: aload_3
    //   229: iconst_0
    //   230: invokevirtual println : (Z)V
    //   233: aload_3
    //   234: aload_1
    //   235: invokevirtual print : (Ljava/lang/String;)V
    //   238: aload_3
    //   239: ldc_w 'mRetainInstance='
    //   242: invokevirtual print : (Ljava/lang/String;)V
    //   245: aload_3
    //   246: aload_0
    //   247: getfield H : Z
    //   250: invokevirtual print : (Z)V
    //   253: aload_3
    //   254: ldc_w ' mUserVisibleHint='
    //   257: invokevirtual print : (Ljava/lang/String;)V
    //   260: aload_3
    //   261: aload_0
    //   262: getfield N : Z
    //   265: invokevirtual println : (Z)V
    //   268: aload_0
    //   269: getfield y : Landroidx/fragment/app/d0;
    //   272: ifnull -> 295
    //   275: aload_3
    //   276: aload_1
    //   277: invokevirtual print : (Ljava/lang/String;)V
    //   280: aload_3
    //   281: ldc_w 'mFragmentManager='
    //   284: invokevirtual print : (Ljava/lang/String;)V
    //   287: aload_3
    //   288: aload_0
    //   289: getfield y : Landroidx/fragment/app/d0;
    //   292: invokevirtual println : (Ljava/lang/Object;)V
    //   295: aload_0
    //   296: getfield z : Landroidx/fragment/app/a0;
    //   299: ifnull -> 322
    //   302: aload_3
    //   303: aload_1
    //   304: invokevirtual print : (Ljava/lang/String;)V
    //   307: aload_3
    //   308: ldc_w 'mHost='
    //   311: invokevirtual print : (Ljava/lang/String;)V
    //   314: aload_3
    //   315: aload_0
    //   316: getfield z : Landroidx/fragment/app/a0;
    //   319: invokevirtual println : (Ljava/lang/Object;)V
    //   322: aload_0
    //   323: getfield B : Landroidx/fragment/app/o;
    //   326: ifnull -> 349
    //   329: aload_3
    //   330: aload_1
    //   331: invokevirtual print : (Ljava/lang/String;)V
    //   334: aload_3
    //   335: ldc_w 'mParentFragment='
    //   338: invokevirtual print : (Ljava/lang/String;)V
    //   341: aload_3
    //   342: aload_0
    //   343: getfield B : Landroidx/fragment/app/o;
    //   346: invokevirtual println : (Ljava/lang/Object;)V
    //   349: aload_0
    //   350: getfield m : Landroid/os/Bundle;
    //   353: ifnull -> 376
    //   356: aload_3
    //   357: aload_1
    //   358: invokevirtual print : (Ljava/lang/String;)V
    //   361: aload_3
    //   362: ldc_w 'mArguments='
    //   365: invokevirtual print : (Ljava/lang/String;)V
    //   368: aload_3
    //   369: aload_0
    //   370: getfield m : Landroid/os/Bundle;
    //   373: invokevirtual println : (Ljava/lang/Object;)V
    //   376: aload_0
    //   377: getfield i : Landroid/os/Bundle;
    //   380: ifnull -> 403
    //   383: aload_3
    //   384: aload_1
    //   385: invokevirtual print : (Ljava/lang/String;)V
    //   388: aload_3
    //   389: ldc_w 'mSavedFragmentState='
    //   392: invokevirtual print : (Ljava/lang/String;)V
    //   395: aload_3
    //   396: aload_0
    //   397: getfield i : Landroid/os/Bundle;
    //   400: invokevirtual println : (Ljava/lang/Object;)V
    //   403: aload_0
    //   404: getfield j : Landroid/util/SparseArray;
    //   407: ifnull -> 430
    //   410: aload_3
    //   411: aload_1
    //   412: invokevirtual print : (Ljava/lang/String;)V
    //   415: aload_3
    //   416: ldc_w 'mSavedViewState='
    //   419: invokevirtual print : (Ljava/lang/String;)V
    //   422: aload_3
    //   423: aload_0
    //   424: getfield j : Landroid/util/SparseArray;
    //   427: invokevirtual println : (Ljava/lang/Object;)V
    //   430: aload_0
    //   431: getfield k : Landroid/os/Bundle;
    //   434: ifnull -> 457
    //   437: aload_3
    //   438: aload_1
    //   439: invokevirtual print : (Ljava/lang/String;)V
    //   442: aload_3
    //   443: ldc_w 'mSavedViewRegistryState='
    //   446: invokevirtual print : (Ljava/lang/String;)V
    //   449: aload_3
    //   450: aload_0
    //   451: getfield k : Landroid/os/Bundle;
    //   454: invokevirtual println : (Ljava/lang/Object;)V
    //   457: aload_0
    //   458: getfield n : Landroidx/fragment/app/o;
    //   461: astore #5
    //   463: aload #5
    //   465: ifnull -> 471
    //   468: goto -> 508
    //   471: aload_0
    //   472: getfield y : Landroidx/fragment/app/d0;
    //   475: astore #5
    //   477: aload #5
    //   479: ifnull -> 505
    //   482: aload_0
    //   483: getfield o : Ljava/lang/String;
    //   486: astore #6
    //   488: aload #6
    //   490: ifnull -> 505
    //   493: aload #5
    //   495: aload #6
    //   497: invokevirtual G : (Ljava/lang/String;)Landroidx/fragment/app/o;
    //   500: astore #5
    //   502: goto -> 508
    //   505: aconst_null
    //   506: astore #5
    //   508: aload #5
    //   510: ifnull -> 546
    //   513: aload_3
    //   514: aload_1
    //   515: invokevirtual print : (Ljava/lang/String;)V
    //   518: aload_3
    //   519: ldc_w 'mTarget='
    //   522: invokevirtual print : (Ljava/lang/String;)V
    //   525: aload_3
    //   526: aload #5
    //   528: invokevirtual print : (Ljava/lang/Object;)V
    //   531: aload_3
    //   532: ldc_w ' mTargetRequestCode='
    //   535: invokevirtual print : (Ljava/lang/String;)V
    //   538: aload_3
    //   539: aload_0
    //   540: getfield p : I
    //   543: invokevirtual println : (I)V
    //   546: aload_3
    //   547: aload_1
    //   548: invokevirtual print : (Ljava/lang/String;)V
    //   551: aload_3
    //   552: ldc_w 'mPopDirection='
    //   555: invokevirtual print : (Ljava/lang/String;)V
    //   558: aload_3
    //   559: aload_0
    //   560: invokevirtual s : ()Z
    //   563: invokevirtual println : (Z)V
    //   566: aload_0
    //   567: invokevirtual k : ()I
    //   570: ifeq -> 593
    //   573: aload_3
    //   574: aload_1
    //   575: invokevirtual print : (Ljava/lang/String;)V
    //   578: aload_3
    //   579: ldc_w 'getEnterAnim='
    //   582: invokevirtual print : (Ljava/lang/String;)V
    //   585: aload_3
    //   586: aload_0
    //   587: invokevirtual k : ()I
    //   590: invokevirtual println : (I)V
    //   593: aload_0
    //   594: invokevirtual n : ()I
    //   597: ifeq -> 620
    //   600: aload_3
    //   601: aload_1
    //   602: invokevirtual print : (Ljava/lang/String;)V
    //   605: aload_3
    //   606: ldc_w 'getExitAnim='
    //   609: invokevirtual print : (Ljava/lang/String;)V
    //   612: aload_3
    //   613: aload_0
    //   614: invokevirtual n : ()I
    //   617: invokevirtual println : (I)V
    //   620: aload_0
    //   621: invokevirtual t : ()I
    //   624: ifeq -> 647
    //   627: aload_3
    //   628: aload_1
    //   629: invokevirtual print : (Ljava/lang/String;)V
    //   632: aload_3
    //   633: ldc_w 'getPopEnterAnim='
    //   636: invokevirtual print : (Ljava/lang/String;)V
    //   639: aload_3
    //   640: aload_0
    //   641: invokevirtual t : ()I
    //   644: invokevirtual println : (I)V
    //   647: aload_0
    //   648: invokevirtual u : ()I
    //   651: ifeq -> 674
    //   654: aload_3
    //   655: aload_1
    //   656: invokevirtual print : (Ljava/lang/String;)V
    //   659: aload_3
    //   660: ldc_w 'getPopExitAnim='
    //   663: invokevirtual print : (Ljava/lang/String;)V
    //   666: aload_3
    //   667: aload_0
    //   668: invokevirtual u : ()I
    //   671: invokevirtual println : (I)V
    //   674: aload_0
    //   675: getfield K : Landroid/view/ViewGroup;
    //   678: ifnull -> 701
    //   681: aload_3
    //   682: aload_1
    //   683: invokevirtual print : (Ljava/lang/String;)V
    //   686: aload_3
    //   687: ldc_w 'mContainer='
    //   690: invokevirtual print : (Ljava/lang/String;)V
    //   693: aload_3
    //   694: aload_0
    //   695: getfield K : Landroid/view/ViewGroup;
    //   698: invokevirtual println : (Ljava/lang/Object;)V
    //   701: aload_0
    //   702: getfield L : Landroid/view/View;
    //   705: ifnull -> 728
    //   708: aload_3
    //   709: aload_1
    //   710: invokevirtual print : (Ljava/lang/String;)V
    //   713: aload_3
    //   714: ldc_w 'mView='
    //   717: invokevirtual print : (Ljava/lang/String;)V
    //   720: aload_3
    //   721: aload_0
    //   722: getfield L : Landroid/view/View;
    //   725: invokevirtual println : (Ljava/lang/Object;)V
    //   728: aload_0
    //   729: invokevirtual g : ()Landroid/view/View;
    //   732: ifnull -> 755
    //   735: aload_3
    //   736: aload_1
    //   737: invokevirtual print : (Ljava/lang/String;)V
    //   740: aload_3
    //   741: ldc_w 'mAnimatingAway='
    //   744: invokevirtual print : (Ljava/lang/String;)V
    //   747: aload_3
    //   748: aload_0
    //   749: invokevirtual g : ()Landroid/view/View;
    //   752: invokevirtual println : (Ljava/lang/Object;)V
    //   755: aload_0
    //   756: invokevirtual i : ()Landroid/content/Context;
    //   759: ifnull -> 774
    //   762: aload_0
    //   763: invokestatic b : (Landroidx/lifecycle/i;)Lt0/a;
    //   766: aload_1
    //   767: aload_2
    //   768: aload_3
    //   769: aload #4
    //   771: invokevirtual a : (Ljava/lang/String;Ljava/io/FileDescriptor;Ljava/io/PrintWriter;[Ljava/lang/String;)V
    //   774: aload_3
    //   775: aload_1
    //   776: invokevirtual print : (Ljava/lang/String;)V
    //   779: new java/lang/StringBuilder
    //   782: dup
    //   783: invokespecial <init> : ()V
    //   786: astore #5
    //   788: aload #5
    //   790: ldc_w 'Child '
    //   793: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   796: pop
    //   797: aload #5
    //   799: aload_0
    //   800: getfield A : Landroidx/fragment/app/d0;
    //   803: invokevirtual append : (Ljava/lang/Object;)Ljava/lang/StringBuilder;
    //   806: pop
    //   807: aload #5
    //   809: ldc_w ':'
    //   812: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   815: pop
    //   816: aload_3
    //   817: aload #5
    //   819: invokevirtual toString : ()Ljava/lang/String;
    //   822: invokevirtual println : (Ljava/lang/String;)V
    //   825: aload_0
    //   826: getfield A : Landroidx/fragment/app/d0;
    //   829: aload_1
    //   830: ldc_w '  '
    //   833: invokestatic a : (Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;
    //   836: aload_2
    //   837: aload_3
    //   838: aload #4
    //   840: invokevirtual y : (Ljava/lang/String;Ljava/io/FileDescriptor;Ljava/io/PrintWriter;[Ljava/lang/String;)V
    //   843: return
  }
  
  public void e0(boolean paramBoolean) {
    (f()).q = paramBoolean;
  }
  
  public final boolean equals(Object paramObject) {
    return super.equals(paramObject);
  }
  
  public final b f() {
    if (this.O == null)
      this.O = new b(); 
    return this.O;
  }
  
  public void f0(e parame) {
    f();
    e e1 = this.O.p;
    if (parame == e1)
      return; 
    if (parame == null || e1 == null) {
      if (parame != null) {
        parame = parame;
        ((d0.n)parame).c++;
      } 
      return;
    } 
    StringBuilder stringBuilder = new StringBuilder();
    stringBuilder.append("Trying to set a replacement startPostponedEnterTransition on ");
    stringBuilder.append(this);
    throw new IllegalStateException(stringBuilder.toString());
  }
  
  public View g() {
    b b1 = this.O;
    return (b1 == null) ? null : b1.a;
  }
  
  public void g0(boolean paramBoolean) {
    if (this.O == null)
      return; 
    (f()).c = paramBoolean;
  }
  
  public final d0 h() {
    if (this.z != null)
      return this.A; 
    throw new IllegalStateException(n.b("Fragment ", this, " has not been attached yet."));
  }
  
  public void h0(@SuppressLint({"UnknownNullness"}) Intent paramIntent) {
    a0<?> a01 = this.z;
    if (a01 != null) {
      Context context = a01.i;
      Object object = b0.a.a;
      b0.a.a.b(context, paramIntent, null);
      return;
    } 
    throw new IllegalStateException(n.b("Fragment ", this, " not attached to Activity"));
  }
  
  public final int hashCode() {
    return super.hashCode();
  }
  
  public Context i() {
    a0<?> a01 = this.z;
    return (a01 == null) ? null : a01.i;
  }
  
  public void i0() {
    if (this.O != null)
      Objects.requireNonNull(f()); 
  }
  
  public z j() {
    if (this.y != null) {
      if (q() != 1) {
        g0 g0 = this.y.J;
        z z2 = g0.d.get(this.l);
        z z1 = z2;
        if (z2 == null) {
          z1 = new z();
          g0.d.put(this.l, z1);
        } 
        return z1;
      } 
      throw new IllegalStateException("Calling getViewModelStore() before a Fragment reaches onCreate() when using setMaxLifecycle(INITIALIZED) is not supported");
    } 
    throw new IllegalStateException("Can't access ViewModels from detached fragment");
  }
  
  public int k() {
    b b1 = this.O;
    return (b1 == null) ? 0 : b1.d;
  }
  
  public Object l() {
    b b1 = this.O;
    if (b1 == null)
      return null; 
    Objects.requireNonNull(b1);
    return null;
  }
  
  public void m() {
    b b1 = this.O;
    if (b1 == null)
      return; 
    Objects.requireNonNull(b1);
  }
  
  public int n() {
    b b1 = this.O;
    return (b1 == null) ? 0 : b1.e;
  }
  
  public Object o() {
    b b1 = this.O;
    if (b1 == null)
      return null; 
    Objects.requireNonNull(b1);
    return null;
  }
  
  public void onConfigurationChanged(Configuration paramConfiguration) {
    this.J = true;
  }
  
  public void onCreateContextMenu(ContextMenu paramContextMenu, View paramView, ContextMenu.ContextMenuInfo paramContextMenuInfo) {
    r r;
    a0<?> a01 = this.z;
    if (a01 == null) {
      a01 = null;
    } else {
      r = (r)a01.h;
    } 
    if (r != null) {
      r.onCreateContextMenu(paramContextMenu, paramView, paramContextMenuInfo);
      return;
    } 
    throw new IllegalStateException(n.b("Fragment ", this, " not attached to an activity."));
  }
  
  public void onLowMemory() {
    this.J = true;
  }
  
  public void p() {
    b b1 = this.O;
    if (b1 == null)
      return; 
    Objects.requireNonNull(b1);
  }
  
  public final int q() {
    androidx.lifecycle.e.c c1 = this.S;
    return (c1 == androidx.lifecycle.e.c.i || this.B == null) ? c1.ordinal() : Math.min(c1.ordinal(), this.B.q());
  }
  
  public final d0 r() {
    d0 d01 = this.y;
    if (d01 != null)
      return d01; 
    throw new IllegalStateException(n.b("Fragment ", this, " not associated with a fragment manager."));
  }
  
  public boolean s() {
    b b1 = this.O;
    return (b1 == null) ? false : b1.c;
  }
  
  public int t() {
    b b1 = this.O;
    return (b1 == null) ? 0 : b1.f;
  }
  
  public String toString() {
    StringBuilder stringBuilder = new StringBuilder(128);
    stringBuilder.append(getClass().getSimpleName());
    stringBuilder.append("{");
    stringBuilder.append(Integer.toHexString(System.identityHashCode(this)));
    stringBuilder.append("}");
    stringBuilder.append(" (");
    stringBuilder.append(this.l);
    if (this.C != 0) {
      stringBuilder.append(" id=0x");
      stringBuilder.append(Integer.toHexString(this.C));
    } 
    if (this.E != null) {
      stringBuilder.append(" tag=");
      stringBuilder.append(this.E);
    } 
    stringBuilder.append(")");
    return stringBuilder.toString();
  }
  
  public int u() {
    b b1 = this.O;
    return (b1 == null) ? 0 : b1.g;
  }
  
  public Object v() {
    b b1 = this.O;
    if (b1 == null)
      return null; 
    Object object = b1.l;
    if (object == Y) {
      o();
      return null;
    } 
    return object;
  }
  
  public final Resources w() {
    return X().getResources();
  }
  
  public Object x() {
    b b1 = this.O;
    if (b1 == null)
      return null; 
    Object object = b1.k;
    if (object == Y) {
      l();
      return null;
    } 
    return object;
  }
  
  public Object y() {
    b b1 = this.O;
    if (b1 == null)
      return null; 
    Objects.requireNonNull(b1);
    return null;
  }
  
  public Object z() {
    b b1 = this.O;
    if (b1 == null)
      return null; 
    Object object = b1.m;
    if (object == Y) {
      y();
      return null;
    } 
    return object;
  }
  
  public class a extends w {
    public a(o this$0) {}
    
    public View e(int param1Int) {
      View view = this.a.L;
      if (view != null)
        return view.findViewById(param1Int); 
      StringBuilder stringBuilder = android.support.v4.media.c.a("Fragment ");
      stringBuilder.append(this.a);
      stringBuilder.append(" does not have a view");
      throw new IllegalStateException(stringBuilder.toString());
    }
    
    public boolean f() {
      return (this.a.L != null);
    }
  }
  
  public static class b {
    public View a;
    
    public Animator b;
    
    public boolean c;
    
    public int d;
    
    public int e;
    
    public int f;
    
    public int g;
    
    public int h;
    
    public ArrayList<String> i;
    
    public ArrayList<String> j;
    
    public Object k;
    
    public Object l;
    
    public Object m;
    
    public float n;
    
    public View o;
    
    public o.e p;
    
    public boolean q;
    
    public b() {
      Object object = o.Y;
      this.k = object;
      this.l = object;
      this.m = object;
      this.n = 1.0F;
      this.o = null;
    }
  }
  
  public static class c extends RuntimeException {
    public c(String param1String, Exception param1Exception) {
      super(param1String, param1Exception);
    }
  }
  
  public static abstract class d {
    public abstract void a();
  }
  
  public static interface e {}
}


/* Location:              C:\soft\dex2jar-2.0\Luxury Logo Maker_ Logo Design-dex2jar.jar!\androidx\fragment\app\o.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */