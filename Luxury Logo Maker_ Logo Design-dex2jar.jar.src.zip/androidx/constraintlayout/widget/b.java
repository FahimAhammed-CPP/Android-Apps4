package androidx.constraintlayout.widget;

import android.content.Context;
import android.content.res.TypedArray;
import android.content.res.XmlResourceParser;
import android.graphics.drawable.ColorDrawable;
import android.util.AttributeSet;
import android.util.SparseIntArray;
import android.util.Xml;
import android.view.View;
import e4.k6;
import java.io.IOException;
import java.lang.reflect.InvocationTargetException;
import java.util.Arrays;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Objects;
import org.xmlpull.v1.XmlPullParser;
import org.xmlpull.v1.XmlPullParserException;

public class b {
  public static final int[] d = new int[] { 0, 4, 8 };
  
  public static SparseIntArray e;
  
  public HashMap<String, w.a> a = new HashMap<String, w.a>();
  
  public boolean b = true;
  
  public HashMap<Integer, a> c = new HashMap<Integer, a>();
  
  static {
    SparseIntArray sparseIntArray = new SparseIntArray();
    e = sparseIntArray;
    sparseIntArray.append(77, 25);
    e.append(78, 26);
    e.append(80, 29);
    e.append(81, 30);
    e.append(87, 36);
    e.append(86, 35);
    e.append(59, 4);
    e.append(58, 3);
    e.append(56, 1);
    e.append(95, 6);
    e.append(96, 7);
    e.append(66, 17);
    e.append(67, 18);
    e.append(68, 19);
    e.append(0, 27);
    e.append(82, 32);
    e.append(83, 33);
    e.append(65, 10);
    e.append(64, 9);
    e.append(99, 13);
    e.append(102, 16);
    e.append(100, 14);
    e.append(97, 11);
    e.append(101, 15);
    e.append(98, 12);
    e.append(90, 40);
    e.append(75, 39);
    e.append(74, 41);
    e.append(89, 42);
    e.append(73, 20);
    e.append(88, 37);
    e.append(63, 5);
    e.append(76, 82);
    e.append(85, 82);
    e.append(79, 82);
    e.append(57, 82);
    e.append(55, 82);
    e.append(5, 24);
    e.append(7, 28);
    e.append(23, 31);
    e.append(24, 8);
    e.append(6, 34);
    e.append(8, 2);
    e.append(3, 23);
    e.append(4, 21);
    e.append(2, 22);
    e.append(13, 43);
    e.append(26, 44);
    e.append(21, 45);
    e.append(22, 46);
    e.append(20, 60);
    e.append(18, 47);
    e.append(19, 48);
    e.append(14, 49);
    e.append(15, 50);
    e.append(16, 51);
    e.append(17, 52);
    e.append(25, 53);
    e.append(91, 54);
    e.append(69, 55);
    e.append(92, 56);
    e.append(70, 57);
    e.append(93, 58);
    e.append(71, 59);
    e.append(60, 61);
    e.append(62, 62);
    e.append(61, 63);
    e.append(27, 64);
    e.append(107, 65);
    e.append(34, 66);
    e.append(108, 67);
    e.append(104, 79);
    e.append(1, 38);
    e.append(103, 68);
    e.append(94, 69);
    e.append(72, 70);
    e.append(31, 71);
    e.append(29, 72);
    e.append(30, 73);
    e.append(32, 74);
    e.append(28, 75);
    e.append(105, 76);
    e.append(84, 77);
    e.append(109, 78);
    e.append(54, 80);
    e.append(53, 81);
  }
  
  public void a(ConstraintLayout paramConstraintLayout, boolean paramBoolean) {
    // Byte code:
    //   0: aload_1
    //   1: invokevirtual getChildCount : ()I
    //   4: istore_3
    //   5: new java/util/HashSet
    //   8: dup
    //   9: aload_0
    //   10: getfield c : Ljava/util/HashMap;
    //   13: invokevirtual keySet : ()Ljava/util/Set;
    //   16: invokespecial <init> : (Ljava/util/Collection;)V
    //   19: astore #10
    //   21: iconst_0
    //   22: istore #5
    //   24: iload #5
    //   26: iload_3
    //   27: if_icmpge -> 1326
    //   30: aload_1
    //   31: iload #5
    //   33: invokevirtual getChildAt : (I)Landroid/view/View;
    //   36: astore #11
    //   38: aload #11
    //   40: invokevirtual getId : ()I
    //   43: istore #4
    //   45: aload_0
    //   46: getfield c : Ljava/util/HashMap;
    //   49: iload #4
    //   51: invokestatic valueOf : (I)Ljava/lang/Integer;
    //   54: invokevirtual containsKey : (Ljava/lang/Object;)Z
    //   57: ifne -> 114
    //   60: ldc 'id unknown '
    //   62: invokestatic a : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   65: astore #8
    //   67: aload #11
    //   69: invokevirtual getContext : ()Landroid/content/Context;
    //   72: invokevirtual getResources : ()Landroid/content/res/Resources;
    //   75: aload #11
    //   77: invokevirtual getId : ()I
    //   80: invokevirtual getResourceEntryName : (I)Ljava/lang/String;
    //   83: astore #7
    //   85: goto -> 92
    //   88: ldc 'UNKNOWN'
    //   90: astore #7
    //   92: aload #8
    //   94: aload #7
    //   96: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   99: pop
    //   100: ldc 'ConstraintSet'
    //   102: aload #8
    //   104: invokevirtual toString : ()Ljava/lang/String;
    //   107: invokestatic w : (Ljava/lang/String;Ljava/lang/String;)I
    //   110: pop
    //   111: goto -> 146
    //   114: aload_0
    //   115: getfield b : Z
    //   118: ifeq -> 140
    //   121: iload #4
    //   123: iconst_m1
    //   124: if_icmpeq -> 130
    //   127: goto -> 140
    //   130: new java/lang/RuntimeException
    //   133: dup
    //   134: ldc 'All children of ConstraintLayout must have ids to use ConstraintSet'
    //   136: invokespecial <init> : (Ljava/lang/String;)V
    //   139: athrow
    //   140: iload #4
    //   142: iconst_m1
    //   143: if_icmpne -> 149
    //   146: goto -> 1317
    //   149: aload_0
    //   150: getfield c : Ljava/util/HashMap;
    //   153: iload #4
    //   155: invokestatic valueOf : (I)Ljava/lang/Integer;
    //   158: invokevirtual containsKey : (Ljava/lang/Object;)Z
    //   161: ifeq -> 1280
    //   164: aload #10
    //   166: iload #4
    //   168: invokestatic valueOf : (I)Ljava/lang/Integer;
    //   171: invokevirtual remove : (Ljava/lang/Object;)Z
    //   174: pop
    //   175: aload_0
    //   176: getfield c : Ljava/util/HashMap;
    //   179: iload #4
    //   181: invokestatic valueOf : (I)Ljava/lang/Integer;
    //   184: invokevirtual get : (Ljava/lang/Object;)Ljava/lang/Object;
    //   187: checkcast androidx/constraintlayout/widget/b$a
    //   190: astore #12
    //   192: aload #11
    //   194: instanceof androidx/constraintlayout/widget/Barrier
    //   197: ifeq -> 209
    //   200: aload #12
    //   202: getfield d : Landroidx/constraintlayout/widget/b$b;
    //   205: iconst_1
    //   206: putfield d0 : I
    //   209: aload #12
    //   211: getfield d : Landroidx/constraintlayout/widget/b$b;
    //   214: getfield d0 : I
    //   217: istore #6
    //   219: iload #6
    //   221: iconst_m1
    //   222: if_icmpeq -> 354
    //   225: iload #6
    //   227: iconst_1
    //   228: if_icmpeq -> 234
    //   231: goto -> 354
    //   234: aload #11
    //   236: checkcast androidx/constraintlayout/widget/Barrier
    //   239: astore #7
    //   241: aload #7
    //   243: iload #4
    //   245: invokevirtual setId : (I)V
    //   248: aload #7
    //   250: aload #12
    //   252: getfield d : Landroidx/constraintlayout/widget/b$b;
    //   255: getfield b0 : I
    //   258: invokevirtual setType : (I)V
    //   261: aload #7
    //   263: aload #12
    //   265: getfield d : Landroidx/constraintlayout/widget/b$b;
    //   268: getfield c0 : I
    //   271: invokevirtual setMargin : (I)V
    //   274: aload #7
    //   276: aload #12
    //   278: getfield d : Landroidx/constraintlayout/widget/b$b;
    //   281: getfield j0 : Z
    //   284: invokevirtual setAllowsGoneWidget : (Z)V
    //   287: aload #12
    //   289: getfield d : Landroidx/constraintlayout/widget/b$b;
    //   292: astore #8
    //   294: aload #8
    //   296: getfield e0 : [I
    //   299: astore #9
    //   301: aload #9
    //   303: ifnull -> 316
    //   306: aload #7
    //   308: aload #9
    //   310: invokevirtual setReferencedIds : ([I)V
    //   313: goto -> 354
    //   316: aload #8
    //   318: getfield f0 : Ljava/lang/String;
    //   321: astore #9
    //   323: aload #9
    //   325: ifnull -> 354
    //   328: aload #8
    //   330: aload_0
    //   331: aload #7
    //   333: aload #9
    //   335: invokevirtual c : (Landroid/view/View;Ljava/lang/String;)[I
    //   338: putfield e0 : [I
    //   341: aload #7
    //   343: aload #12
    //   345: getfield d : Landroidx/constraintlayout/widget/b$b;
    //   348: getfield e0 : [I
    //   351: invokevirtual setReferencedIds : ([I)V
    //   354: aload #11
    //   356: invokevirtual getLayoutParams : ()Landroid/view/ViewGroup$LayoutParams;
    //   359: checkcast androidx/constraintlayout/widget/ConstraintLayout$a
    //   362: astore #13
    //   364: aload #13
    //   366: invokevirtual a : ()V
    //   369: aload #12
    //   371: aload #13
    //   373: invokevirtual a : (Landroidx/constraintlayout/widget/ConstraintLayout$a;)V
    //   376: iload_3
    //   377: istore #4
    //   379: iload_2
    //   380: ifeq -> 1043
    //   383: aload #12
    //   385: getfield f : Ljava/util/HashMap;
    //   388: astore #8
    //   390: aload #11
    //   392: invokevirtual getClass : ()Ljava/lang/Class;
    //   395: astore #14
    //   397: aload #8
    //   399: invokevirtual keySet : ()Ljava/util/Set;
    //   402: invokeinterface iterator : ()Ljava/util/Iterator;
    //   407: astore #7
    //   409: iload_3
    //   410: istore #4
    //   412: aload #7
    //   414: invokeinterface hasNext : ()Z
    //   419: ifeq -> 1043
    //   422: aload #7
    //   424: invokeinterface next : ()Ljava/lang/Object;
    //   429: checkcast java/lang/String
    //   432: astore #15
    //   434: aload #8
    //   436: aload #15
    //   438: invokevirtual get : (Ljava/lang/Object;)Ljava/lang/Object;
    //   441: checkcast w/a
    //   444: astore #9
    //   446: ldc 'set'
    //   448: aload #15
    //   450: invokestatic a : (Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;
    //   453: astore #16
    //   455: aload #9
    //   457: getfield b : I
    //   460: invokestatic a : (I)I
    //   463: istore #4
    //   465: iload #4
    //   467: tableswitch default -> 508, 0 -> 771, 1 -> 730, 2 -> 689, 3 -> 631, 4 -> 593, 5 -> 552, 6 -> 511
    //   508: goto -> 1040
    //   511: aload #14
    //   513: aload #16
    //   515: iconst_1
    //   516: anewarray java/lang/Class
    //   519: dup
    //   520: iconst_0
    //   521: getstatic java/lang/Float.TYPE : Ljava/lang/Class;
    //   524: aastore
    //   525: invokevirtual getMethod : (Ljava/lang/String;[Ljava/lang/Class;)Ljava/lang/reflect/Method;
    //   528: aload #11
    //   530: iconst_1
    //   531: anewarray java/lang/Object
    //   534: dup
    //   535: iconst_0
    //   536: aload #9
    //   538: getfield d : F
    //   541: invokestatic valueOf : (F)Ljava/lang/Float;
    //   544: aastore
    //   545: invokevirtual invoke : (Ljava/lang/Object;[Ljava/lang/Object;)Ljava/lang/Object;
    //   548: pop
    //   549: goto -> 1040
    //   552: aload #14
    //   554: aload #16
    //   556: iconst_1
    //   557: anewarray java/lang/Class
    //   560: dup
    //   561: iconst_0
    //   562: getstatic java/lang/Boolean.TYPE : Ljava/lang/Class;
    //   565: aastore
    //   566: invokevirtual getMethod : (Ljava/lang/String;[Ljava/lang/Class;)Ljava/lang/reflect/Method;
    //   569: aload #11
    //   571: iconst_1
    //   572: anewarray java/lang/Object
    //   575: dup
    //   576: iconst_0
    //   577: aload #9
    //   579: getfield f : Z
    //   582: invokestatic valueOf : (Z)Ljava/lang/Boolean;
    //   585: aastore
    //   586: invokevirtual invoke : (Ljava/lang/Object;[Ljava/lang/Object;)Ljava/lang/Object;
    //   589: pop
    //   590: goto -> 1040
    //   593: aload #14
    //   595: aload #16
    //   597: iconst_1
    //   598: anewarray java/lang/Class
    //   601: dup
    //   602: iconst_0
    //   603: ldc_w java/lang/CharSequence
    //   606: aastore
    //   607: invokevirtual getMethod : (Ljava/lang/String;[Ljava/lang/Class;)Ljava/lang/reflect/Method;
    //   610: aload #11
    //   612: iconst_1
    //   613: anewarray java/lang/Object
    //   616: dup
    //   617: iconst_0
    //   618: aload #9
    //   620: getfield e : Ljava/lang/String;
    //   623: aastore
    //   624: invokevirtual invoke : (Ljava/lang/Object;[Ljava/lang/Object;)Ljava/lang/Object;
    //   627: pop
    //   628: goto -> 1040
    //   631: aload #14
    //   633: aload #16
    //   635: iconst_1
    //   636: anewarray java/lang/Class
    //   639: dup
    //   640: iconst_0
    //   641: ldc_w android/graphics/drawable/Drawable
    //   644: aastore
    //   645: invokevirtual getMethod : (Ljava/lang/String;[Ljava/lang/Class;)Ljava/lang/reflect/Method;
    //   648: astore #17
    //   650: new android/graphics/drawable/ColorDrawable
    //   653: dup
    //   654: invokespecial <init> : ()V
    //   657: astore #18
    //   659: aload #18
    //   661: aload #9
    //   663: getfield g : I
    //   666: invokevirtual setColor : (I)V
    //   669: aload #17
    //   671: aload #11
    //   673: iconst_1
    //   674: anewarray java/lang/Object
    //   677: dup
    //   678: iconst_0
    //   679: aload #18
    //   681: aastore
    //   682: invokevirtual invoke : (Ljava/lang/Object;[Ljava/lang/Object;)Ljava/lang/Object;
    //   685: pop
    //   686: goto -> 1040
    //   689: aload #14
    //   691: aload #16
    //   693: iconst_1
    //   694: anewarray java/lang/Class
    //   697: dup
    //   698: iconst_0
    //   699: getstatic java/lang/Integer.TYPE : Ljava/lang/Class;
    //   702: aastore
    //   703: invokevirtual getMethod : (Ljava/lang/String;[Ljava/lang/Class;)Ljava/lang/reflect/Method;
    //   706: aload #11
    //   708: iconst_1
    //   709: anewarray java/lang/Object
    //   712: dup
    //   713: iconst_0
    //   714: aload #9
    //   716: getfield g : I
    //   719: invokestatic valueOf : (I)Ljava/lang/Integer;
    //   722: aastore
    //   723: invokevirtual invoke : (Ljava/lang/Object;[Ljava/lang/Object;)Ljava/lang/Object;
    //   726: pop
    //   727: goto -> 1040
    //   730: aload #14
    //   732: aload #16
    //   734: iconst_1
    //   735: anewarray java/lang/Class
    //   738: dup
    //   739: iconst_0
    //   740: getstatic java/lang/Float.TYPE : Ljava/lang/Class;
    //   743: aastore
    //   744: invokevirtual getMethod : (Ljava/lang/String;[Ljava/lang/Class;)Ljava/lang/reflect/Method;
    //   747: aload #11
    //   749: iconst_1
    //   750: anewarray java/lang/Object
    //   753: dup
    //   754: iconst_0
    //   755: aload #9
    //   757: getfield d : F
    //   760: invokestatic valueOf : (F)Ljava/lang/Float;
    //   763: aastore
    //   764: invokevirtual invoke : (Ljava/lang/Object;[Ljava/lang/Object;)Ljava/lang/Object;
    //   767: pop
    //   768: goto -> 1040
    //   771: aload #14
    //   773: aload #16
    //   775: iconst_1
    //   776: anewarray java/lang/Class
    //   779: dup
    //   780: iconst_0
    //   781: getstatic java/lang/Integer.TYPE : Ljava/lang/Class;
    //   784: aastore
    //   785: invokevirtual getMethod : (Ljava/lang/String;[Ljava/lang/Class;)Ljava/lang/reflect/Method;
    //   788: aload #11
    //   790: iconst_1
    //   791: anewarray java/lang/Object
    //   794: dup
    //   795: iconst_0
    //   796: aload #9
    //   798: getfield c : I
    //   801: invokestatic valueOf : (I)Ljava/lang/Integer;
    //   804: aastore
    //   805: invokevirtual invoke : (Ljava/lang/Object;[Ljava/lang/Object;)Ljava/lang/Object;
    //   808: pop
    //   809: goto -> 1040
    //   812: astore #9
    //   814: goto -> 829
    //   817: astore #9
    //   819: goto -> 875
    //   822: astore #9
    //   824: goto -> 921
    //   827: astore #9
    //   829: ldc_w ' Custom Attribute "'
    //   832: aload #15
    //   834: ldc_w '" not found on '
    //   837: invokestatic a : (Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   840: astore #15
    //   842: aload #15
    //   844: aload #14
    //   846: invokevirtual getName : ()Ljava/lang/String;
    //   849: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   852: pop
    //   853: ldc_w 'TransitionLayout'
    //   856: aload #15
    //   858: invokevirtual toString : ()Ljava/lang/String;
    //   861: invokestatic e : (Ljava/lang/String;Ljava/lang/String;)I
    //   864: pop
    //   865: aload #9
    //   867: invokevirtual printStackTrace : ()V
    //   870: goto -> 1040
    //   873: astore #9
    //   875: ldc_w ' Custom Attribute "'
    //   878: aload #15
    //   880: ldc_w '" not found on '
    //   883: invokestatic a : (Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   886: astore #15
    //   888: aload #15
    //   890: aload #14
    //   892: invokevirtual getName : ()Ljava/lang/String;
    //   895: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   898: pop
    //   899: ldc_w 'TransitionLayout'
    //   902: aload #15
    //   904: invokevirtual toString : ()Ljava/lang/String;
    //   907: invokestatic e : (Ljava/lang/String;Ljava/lang/String;)I
    //   910: pop
    //   911: aload #9
    //   913: invokevirtual printStackTrace : ()V
    //   916: goto -> 1040
    //   919: astore #9
    //   921: ldc_w 'TransitionLayout'
    //   924: aload #9
    //   926: invokevirtual getMessage : ()Ljava/lang/String;
    //   929: invokestatic e : (Ljava/lang/String;Ljava/lang/String;)I
    //   932: pop
    //   933: new java/lang/StringBuilder
    //   936: dup
    //   937: invokespecial <init> : ()V
    //   940: astore #9
    //   942: aload #9
    //   944: ldc_w ' Custom Attribute "'
    //   947: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   950: pop
    //   951: aload #9
    //   953: aload #15
    //   955: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   958: pop
    //   959: aload #9
    //   961: ldc_w '" not found on '
    //   964: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   967: pop
    //   968: aload #9
    //   970: aload #14
    //   972: invokevirtual getName : ()Ljava/lang/String;
    //   975: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   978: pop
    //   979: ldc_w 'TransitionLayout'
    //   982: aload #9
    //   984: invokevirtual toString : ()Ljava/lang/String;
    //   987: invokestatic e : (Ljava/lang/String;Ljava/lang/String;)I
    //   990: pop
    //   991: new java/lang/StringBuilder
    //   994: dup
    //   995: invokespecial <init> : ()V
    //   998: astore #9
    //   1000: aload #9
    //   1002: aload #14
    //   1004: invokevirtual getName : ()Ljava/lang/String;
    //   1007: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   1010: pop
    //   1011: aload #9
    //   1013: ldc_w ' must have a method '
    //   1016: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   1019: pop
    //   1020: aload #9
    //   1022: aload #16
    //   1024: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   1027: pop
    //   1028: ldc_w 'TransitionLayout'
    //   1031: aload #9
    //   1033: invokevirtual toString : ()Ljava/lang/String;
    //   1036: invokestatic e : (Ljava/lang/String;Ljava/lang/String;)I
    //   1039: pop
    //   1040: goto -> 409
    //   1043: aload #11
    //   1045: aload #13
    //   1047: invokevirtual setLayoutParams : (Landroid/view/ViewGroup$LayoutParams;)V
    //   1050: aload #12
    //   1052: getfield b : Landroidx/constraintlayout/widget/b$d;
    //   1055: astore #7
    //   1057: aload #7
    //   1059: getfield c : I
    //   1062: ifne -> 1075
    //   1065: aload #11
    //   1067: aload #7
    //   1069: getfield b : I
    //   1072: invokevirtual setVisibility : (I)V
    //   1075: aload #11
    //   1077: aload #12
    //   1079: getfield b : Landroidx/constraintlayout/widget/b$d;
    //   1082: getfield d : F
    //   1085: invokevirtual setAlpha : (F)V
    //   1088: aload #11
    //   1090: aload #12
    //   1092: getfield e : Landroidx/constraintlayout/widget/b$e;
    //   1095: getfield b : F
    //   1098: invokevirtual setRotation : (F)V
    //   1101: aload #11
    //   1103: aload #12
    //   1105: getfield e : Landroidx/constraintlayout/widget/b$e;
    //   1108: getfield c : F
    //   1111: invokevirtual setRotationX : (F)V
    //   1114: aload #11
    //   1116: aload #12
    //   1118: getfield e : Landroidx/constraintlayout/widget/b$e;
    //   1121: getfield d : F
    //   1124: invokevirtual setRotationY : (F)V
    //   1127: aload #11
    //   1129: aload #12
    //   1131: getfield e : Landroidx/constraintlayout/widget/b$e;
    //   1134: getfield e : F
    //   1137: invokevirtual setScaleX : (F)V
    //   1140: aload #11
    //   1142: aload #12
    //   1144: getfield e : Landroidx/constraintlayout/widget/b$e;
    //   1147: getfield f : F
    //   1150: invokevirtual setScaleY : (F)V
    //   1153: aload #12
    //   1155: getfield e : Landroidx/constraintlayout/widget/b$e;
    //   1158: getfield g : F
    //   1161: invokestatic isNaN : (F)Z
    //   1164: ifne -> 1180
    //   1167: aload #11
    //   1169: aload #12
    //   1171: getfield e : Landroidx/constraintlayout/widget/b$e;
    //   1174: getfield g : F
    //   1177: invokevirtual setPivotX : (F)V
    //   1180: aload #12
    //   1182: getfield e : Landroidx/constraintlayout/widget/b$e;
    //   1185: getfield h : F
    //   1188: invokestatic isNaN : (F)Z
    //   1191: ifne -> 1207
    //   1194: aload #11
    //   1196: aload #12
    //   1198: getfield e : Landroidx/constraintlayout/widget/b$e;
    //   1201: getfield h : F
    //   1204: invokevirtual setPivotY : (F)V
    //   1207: aload #11
    //   1209: aload #12
    //   1211: getfield e : Landroidx/constraintlayout/widget/b$e;
    //   1214: getfield i : F
    //   1217: invokevirtual setTranslationX : (F)V
    //   1220: aload #11
    //   1222: aload #12
    //   1224: getfield e : Landroidx/constraintlayout/widget/b$e;
    //   1227: getfield j : F
    //   1230: invokevirtual setTranslationY : (F)V
    //   1233: aload #11
    //   1235: aload #12
    //   1237: getfield e : Landroidx/constraintlayout/widget/b$e;
    //   1240: getfield k : F
    //   1243: invokevirtual setTranslationZ : (F)V
    //   1246: aload #12
    //   1248: getfield e : Landroidx/constraintlayout/widget/b$e;
    //   1251: astore #7
    //   1253: iload #4
    //   1255: istore_3
    //   1256: aload #7
    //   1258: getfield l : Z
    //   1261: ifeq -> 1317
    //   1264: aload #11
    //   1266: aload #7
    //   1268: getfield m : F
    //   1271: invokevirtual setElevation : (F)V
    //   1274: iload #4
    //   1276: istore_3
    //   1277: goto -> 1317
    //   1280: new java/lang/StringBuilder
    //   1283: dup
    //   1284: invokespecial <init> : ()V
    //   1287: astore #7
    //   1289: aload #7
    //   1291: ldc_w 'WARNING NO CONSTRAINTS for view '
    //   1294: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   1297: pop
    //   1298: aload #7
    //   1300: iload #4
    //   1302: invokevirtual append : (I)Ljava/lang/StringBuilder;
    //   1305: pop
    //   1306: ldc 'ConstraintSet'
    //   1308: aload #7
    //   1310: invokevirtual toString : ()Ljava/lang/String;
    //   1313: invokestatic v : (Ljava/lang/String;Ljava/lang/String;)I
    //   1316: pop
    //   1317: iload #5
    //   1319: iconst_1
    //   1320: iadd
    //   1321: istore #5
    //   1323: goto -> 24
    //   1326: aload #10
    //   1328: invokevirtual iterator : ()Ljava/util/Iterator;
    //   1331: astore #7
    //   1333: aload #7
    //   1335: invokeinterface hasNext : ()Z
    //   1340: ifeq -> 1591
    //   1343: aload #7
    //   1345: invokeinterface next : ()Ljava/lang/Object;
    //   1350: checkcast java/lang/Integer
    //   1353: astore #9
    //   1355: aload_0
    //   1356: getfield c : Ljava/util/HashMap;
    //   1359: aload #9
    //   1361: invokevirtual get : (Ljava/lang/Object;)Ljava/lang/Object;
    //   1364: checkcast androidx/constraintlayout/widget/b$a
    //   1367: astore #8
    //   1369: aload #8
    //   1371: getfield d : Landroidx/constraintlayout/widget/b$b;
    //   1374: getfield d0 : I
    //   1377: istore_3
    //   1378: iload_3
    //   1379: iconst_m1
    //   1380: if_icmpeq -> 1533
    //   1383: iload_3
    //   1384: iconst_1
    //   1385: if_icmpeq -> 1391
    //   1388: goto -> 1533
    //   1391: new androidx/constraintlayout/widget/Barrier
    //   1394: dup
    //   1395: aload_1
    //   1396: invokevirtual getContext : ()Landroid/content/Context;
    //   1399: invokespecial <init> : (Landroid/content/Context;)V
    //   1402: astore #10
    //   1404: aload #10
    //   1406: aload #9
    //   1408: invokevirtual intValue : ()I
    //   1411: invokevirtual setId : (I)V
    //   1414: aload #8
    //   1416: getfield d : Landroidx/constraintlayout/widget/b$b;
    //   1419: astore #11
    //   1421: aload #11
    //   1423: getfield e0 : [I
    //   1426: astore #12
    //   1428: aload #12
    //   1430: ifnull -> 1443
    //   1433: aload #10
    //   1435: aload #12
    //   1437: invokevirtual setReferencedIds : ([I)V
    //   1440: goto -> 1481
    //   1443: aload #11
    //   1445: getfield f0 : Ljava/lang/String;
    //   1448: astore #12
    //   1450: aload #12
    //   1452: ifnull -> 1481
    //   1455: aload #11
    //   1457: aload_0
    //   1458: aload #10
    //   1460: aload #12
    //   1462: invokevirtual c : (Landroid/view/View;Ljava/lang/String;)[I
    //   1465: putfield e0 : [I
    //   1468: aload #10
    //   1470: aload #8
    //   1472: getfield d : Landroidx/constraintlayout/widget/b$b;
    //   1475: getfield e0 : [I
    //   1478: invokevirtual setReferencedIds : ([I)V
    //   1481: aload #10
    //   1483: aload #8
    //   1485: getfield d : Landroidx/constraintlayout/widget/b$b;
    //   1488: getfield b0 : I
    //   1491: invokevirtual setType : (I)V
    //   1494: aload #10
    //   1496: aload #8
    //   1498: getfield d : Landroidx/constraintlayout/widget/b$b;
    //   1501: getfield c0 : I
    //   1504: invokevirtual setMargin : (I)V
    //   1507: aload_1
    //   1508: invokevirtual b : ()Landroidx/constraintlayout/widget/ConstraintLayout$a;
    //   1511: astore #11
    //   1513: aload #10
    //   1515: invokevirtual h : ()V
    //   1518: aload #8
    //   1520: aload #11
    //   1522: invokevirtual a : (Landroidx/constraintlayout/widget/ConstraintLayout$a;)V
    //   1525: aload_1
    //   1526: aload #10
    //   1528: aload #11
    //   1530: invokevirtual addView : (Landroid/view/View;Landroid/view/ViewGroup$LayoutParams;)V
    //   1533: aload #8
    //   1535: getfield d : Landroidx/constraintlayout/widget/b$b;
    //   1538: getfield a : Z
    //   1541: ifeq -> 1333
    //   1544: new androidx/constraintlayout/widget/Guideline
    //   1547: dup
    //   1548: aload_1
    //   1549: invokevirtual getContext : ()Landroid/content/Context;
    //   1552: invokespecial <init> : (Landroid/content/Context;)V
    //   1555: astore #10
    //   1557: aload #10
    //   1559: aload #9
    //   1561: invokevirtual intValue : ()I
    //   1564: invokevirtual setId : (I)V
    //   1567: aload_1
    //   1568: invokevirtual b : ()Landroidx/constraintlayout/widget/ConstraintLayout$a;
    //   1571: astore #9
    //   1573: aload #8
    //   1575: aload #9
    //   1577: invokevirtual a : (Landroidx/constraintlayout/widget/ConstraintLayout$a;)V
    //   1580: aload_1
    //   1581: aload #10
    //   1583: aload #9
    //   1585: invokevirtual addView : (Landroid/view/View;Landroid/view/ViewGroup$LayoutParams;)V
    //   1588: goto -> 1333
    //   1591: return
    //   1592: astore #7
    //   1594: goto -> 88
    // Exception table:
    //   from	to	target	type
    //   67	85	1592	java/lang/Exception
    //   455	465	919	java/lang/NoSuchMethodException
    //   455	465	873	java/lang/IllegalAccessException
    //   455	465	827	java/lang/reflect/InvocationTargetException
    //   511	549	822	java/lang/NoSuchMethodException
    //   511	549	817	java/lang/IllegalAccessException
    //   511	549	812	java/lang/reflect/InvocationTargetException
    //   552	590	822	java/lang/NoSuchMethodException
    //   552	590	817	java/lang/IllegalAccessException
    //   552	590	812	java/lang/reflect/InvocationTargetException
    //   593	628	822	java/lang/NoSuchMethodException
    //   593	628	817	java/lang/IllegalAccessException
    //   593	628	812	java/lang/reflect/InvocationTargetException
    //   631	686	822	java/lang/NoSuchMethodException
    //   631	686	817	java/lang/IllegalAccessException
    //   631	686	812	java/lang/reflect/InvocationTargetException
    //   689	727	822	java/lang/NoSuchMethodException
    //   689	727	817	java/lang/IllegalAccessException
    //   689	727	812	java/lang/reflect/InvocationTargetException
    //   730	768	822	java/lang/NoSuchMethodException
    //   730	768	817	java/lang/IllegalAccessException
    //   730	768	812	java/lang/reflect/InvocationTargetException
    //   771	809	822	java/lang/NoSuchMethodException
    //   771	809	817	java/lang/IllegalAccessException
    //   771	809	812	java/lang/reflect/InvocationTargetException
  }
  
  public void b(ConstraintLayout paramConstraintLayout) {
    int j = paramConstraintLayout.getChildCount();
    this.c.clear();
    int i = 0;
    while (true) {
      b b1 = this;
      if (i < j) {
        View view = paramConstraintLayout.getChildAt(i);
        ConstraintLayout.a a = (ConstraintLayout.a)view.getLayoutParams();
        int k = view.getId();
        if (!b1.b || k != -1) {
          if (!b1.c.containsKey(Integer.valueOf(k)))
            b1.c.put(Integer.valueOf(k), new a()); 
          a a1 = b1.c.get(Integer.valueOf(k));
          HashMap<String, w.a> hashMap = b1.a;
          HashMap<Object, Object> hashMap1 = new HashMap<Object, Object>();
          Class<?> clazz = view.getClass();
          Iterator<String> iterator = hashMap.keySet().iterator();
          while (true) {
            if (iterator.hasNext()) {
              String str = iterator.next();
              w.a a2 = hashMap.get(str);
              try {
                if (str.equals("BackgroundColor")) {
                  a2 = new w.a(a2, Integer.valueOf(((ColorDrawable)view.getBackground()).getColor()));
                } else {
                  StringBuilder stringBuilder = new StringBuilder();
                  stringBuilder.append("getMap");
                  stringBuilder.append(str);
                  String str1 = stringBuilder.toString();
                  try {
                    a2 = new w.a(a2, clazz.getMethod(str1, new Class[0]).invoke(view, new Object[0]));
                    hashMap1.put(str, a2);
                    continue;
                  } catch (NoSuchMethodException noSuchMethodException) {
                  
                  } catch (IllegalAccessException illegalAccessException) {
                  
                  } catch (InvocationTargetException null) {}
                  invocationTargetException.printStackTrace();
                } 
                hashMap1.put(str, invocationTargetException);
                continue;
              } catch (NoSuchMethodException noSuchMethodException) {
              
              } catch (IllegalAccessException illegalAccessException) {
                illegalAccessException.printStackTrace();
                continue;
              } catch (InvocationTargetException invocationTargetException) {
                invocationTargetException.printStackTrace();
                continue;
              } 
            } else {
              break;
            } 
            invocationTargetException.printStackTrace();
          } 
          a1.f = (HashMap)hashMap1;
          a1.b(k, a);
          a1.b.b = view.getVisibility();
          a1.b.d = view.getAlpha();
          a1.e.b = view.getRotation();
          a1.e.c = view.getRotationX();
          a1.e.d = view.getRotationY();
          a1.e.e = view.getScaleX();
          a1.e.f = view.getScaleY();
          float f1 = view.getPivotX();
          float f2 = view.getPivotY();
          if (f1 != 0.0D || f2 != 0.0D) {
            e e1 = a1.e;
            e1.g = f1;
            e1.h = f2;
          } 
          a1.e.i = view.getTranslationX();
          a1.e.j = view.getTranslationY();
          a1.e.k = view.getTranslationZ();
          e e = a1.e;
          if (e.l)
            e.m = view.getElevation(); 
          if (view instanceof Barrier) {
            Barrier barrier = (Barrier)view;
            b b2 = a1.d;
            b2.j0 = barrier.q.o0;
            b2.e0 = barrier.getReferencedIds();
            a1.d.b0 = barrier.getType();
            a1.d.c0 = barrier.getMargin();
          } 
          i++;
          continue;
        } 
        throw new RuntimeException("All children of ConstraintLayout must have ids to use ConstraintSet");
      } 
      break;
    } 
  }
  
  public final int[] c(View paramView, String paramString) {
    String[] arrayOfString = paramString.split(",");
    Context context = paramView.getContext();
    int[] arrayOfInt = new int[arrayOfString.length];
    int j = 0;
    int i = 0;
    while (true) {
      if (j < arrayOfString.length) {
        String str = arrayOfString[j].trim();
        try {
          m = w.d.class.getField(str).getInt(null);
        } catch (Exception exception) {
          m = 0;
        } 
        int k = m;
        if (!m)
          k = context.getResources().getIdentifier(str, "id", context.getPackageName()); 
        int m = k;
        if (k == 0) {
          m = k;
          if (paramView.isInEditMode()) {
            m = k;
            if (paramView.getParent() instanceof ConstraintLayout) {
              Object object = ((ConstraintLayout)paramView.getParent()).c(0, str);
              m = k;
              if (object != null) {
                m = k;
                if (object instanceof Integer)
                  m = ((Integer)object).intValue(); 
              } 
            } 
          } 
        } 
        arrayOfInt[i] = m;
        j++;
        i++;
        continue;
      } 
      int[] arrayOfInt1 = arrayOfInt;
      if (i != arrayOfString.length)
        arrayOfInt1 = Arrays.copyOf(arrayOfInt, i); 
      return arrayOfInt1;
    } 
  }
  
  public final a d(Context paramContext, AttributeSet paramAttributeSet) {
    // Byte code:
    //   0: new androidx/constraintlayout/widget/b$a
    //   3: dup
    //   4: invokespecial <init> : ()V
    //   7: astore #8
    //   9: aload_1
    //   10: aload_2
    //   11: getstatic u5/b.h : [I
    //   14: invokevirtual obtainStyledAttributes : (Landroid/util/AttributeSet;[I)Landroid/content/res/TypedArray;
    //   17: astore #9
    //   19: aload #9
    //   21: invokevirtual getIndexCount : ()I
    //   24: istore #6
    //   26: iconst_0
    //   27: istore_3
    //   28: iload_3
    //   29: iload #6
    //   31: if_icmpge -> 2844
    //   34: aload #9
    //   36: iload_3
    //   37: invokevirtual getIndex : (I)I
    //   40: istore #7
    //   42: iload #7
    //   44: iconst_1
    //   45: if_icmpeq -> 98
    //   48: bipush #23
    //   50: iload #7
    //   52: if_icmpeq -> 98
    //   55: bipush #24
    //   57: iload #7
    //   59: if_icmpeq -> 98
    //   62: aload #8
    //   64: getfield c : Landroidx/constraintlayout/widget/b$c;
    //   67: iconst_1
    //   68: putfield a : Z
    //   71: aload #8
    //   73: getfield d : Landroidx/constraintlayout/widget/b$b;
    //   76: iconst_1
    //   77: putfield b : Z
    //   80: aload #8
    //   82: getfield b : Landroidx/constraintlayout/widget/b$d;
    //   85: iconst_1
    //   86: putfield a : Z
    //   89: aload #8
    //   91: getfield e : Landroidx/constraintlayout/widget/b$e;
    //   94: iconst_1
    //   95: putfield a : Z
    //   98: getstatic androidx/constraintlayout/widget/b.e : Landroid/util/SparseIntArray;
    //   101: iload #7
    //   103: invokevirtual get : (I)I
    //   106: tableswitch default -> 448, 1 -> 2742, 2 -> 2718, 3 -> 2670, 4 -> 2622, 5 -> 2604, 6 -> 2580, 7 -> 2556, 8 -> 2532, 9 -> 2484, 10 -> 2436, 11 -> 2412, 12 -> 2388, 13 -> 2364, 14 -> 2340, 15 -> 2316, 16 -> 2292, 17 -> 2268, 18 -> 2244, 19 -> 2220, 20 -> 2196, 21 -> 2172, 22 -> 2130, 23 -> 2106, 24 -> 2082, 25 -> 2034, 26 -> 1986, 27 -> 1962, 28 -> 1938, 29 -> 1890, 30 -> 1842, 31 -> 1818, 32 -> 1770, 33 -> 1722, 34 -> 1698, 35 -> 1650, 36 -> 1602, 37 -> 1578, 38 -> 1558, 39 -> 1534, 40 -> 1510, 41 -> 1486, 42 -> 1462, 43 -> 1438, 44 -> 1409, 45 -> 1385, 46 -> 1361, 47 -> 1337, 48 -> 1313, 49 -> 1289, 50 -> 1265, 51 -> 1241, 52 -> 1217, 53 -> 1193, 54 -> 1169, 55 -> 1145, 56 -> 1121, 57 -> 1097, 58 -> 1073, 59 -> 1049, 60 -> 1025, 61 -> 977, 62 -> 953, 63 -> 929, 64 -> 881, 65 -> 823, 66 -> 804, 67 -> 780, 68 -> 756, 69 -> 737, 70 -> 718, 71 -> 706, 72 -> 682, 73 -> 658, 74 -> 640, 75 -> 616, 76 -> 592, 77 -> 574, 78 -> 550, 79 -> 526, 80 -> 502, 81 -> 478, 82 -> 463
    //   448: new java/lang/StringBuilder
    //   451: dup
    //   452: invokespecial <init> : ()V
    //   455: astore_1
    //   456: ldc_w 'Unknown attribute 0x'
    //   459: astore_2
    //   460: goto -> 2790
    //   463: new java/lang/StringBuilder
    //   466: dup
    //   467: invokespecial <init> : ()V
    //   470: astore_1
    //   471: ldc_w 'unused attribute 0x'
    //   474: astore_2
    //   475: goto -> 2790
    //   478: aload #8
    //   480: getfield d : Landroidx/constraintlayout/widget/b$b;
    //   483: astore_1
    //   484: aload_1
    //   485: aload #9
    //   487: iload #7
    //   489: aload_1
    //   490: getfield i0 : Z
    //   493: invokevirtual getBoolean : (IZ)Z
    //   496: putfield i0 : Z
    //   499: goto -> 2837
    //   502: aload #8
    //   504: getfield d : Landroidx/constraintlayout/widget/b$b;
    //   507: astore_1
    //   508: aload_1
    //   509: aload #9
    //   511: iload #7
    //   513: aload_1
    //   514: getfield h0 : Z
    //   517: invokevirtual getBoolean : (IZ)Z
    //   520: putfield h0 : Z
    //   523: goto -> 2837
    //   526: aload #8
    //   528: getfield c : Landroidx/constraintlayout/widget/b$c;
    //   531: astore_1
    //   532: aload_1
    //   533: aload #9
    //   535: iload #7
    //   537: aload_1
    //   538: getfield f : F
    //   541: invokevirtual getFloat : (IF)F
    //   544: putfield f : F
    //   547: goto -> 2837
    //   550: aload #8
    //   552: getfield b : Landroidx/constraintlayout/widget/b$d;
    //   555: astore_1
    //   556: aload_1
    //   557: aload #9
    //   559: iload #7
    //   561: aload_1
    //   562: getfield c : I
    //   565: invokevirtual getInt : (II)I
    //   568: putfield c : I
    //   571: goto -> 2837
    //   574: aload #8
    //   576: getfield d : Landroidx/constraintlayout/widget/b$b;
    //   579: aload #9
    //   581: iload #7
    //   583: invokevirtual getString : (I)Ljava/lang/String;
    //   586: putfield g0 : Ljava/lang/String;
    //   589: goto -> 2837
    //   592: aload #8
    //   594: getfield c : Landroidx/constraintlayout/widget/b$c;
    //   597: astore_1
    //   598: aload_1
    //   599: aload #9
    //   601: iload #7
    //   603: aload_1
    //   604: getfield d : I
    //   607: invokevirtual getInt : (II)I
    //   610: putfield d : I
    //   613: goto -> 2837
    //   616: aload #8
    //   618: getfield d : Landroidx/constraintlayout/widget/b$b;
    //   621: astore_1
    //   622: aload_1
    //   623: aload #9
    //   625: iload #7
    //   627: aload_1
    //   628: getfield j0 : Z
    //   631: invokevirtual getBoolean : (IZ)Z
    //   634: putfield j0 : Z
    //   637: goto -> 2837
    //   640: aload #8
    //   642: getfield d : Landroidx/constraintlayout/widget/b$b;
    //   645: aload #9
    //   647: iload #7
    //   649: invokevirtual getString : (I)Ljava/lang/String;
    //   652: putfield f0 : Ljava/lang/String;
    //   655: goto -> 2837
    //   658: aload #8
    //   660: getfield d : Landroidx/constraintlayout/widget/b$b;
    //   663: astore_1
    //   664: aload_1
    //   665: aload #9
    //   667: iload #7
    //   669: aload_1
    //   670: getfield c0 : I
    //   673: invokevirtual getDimensionPixelSize : (II)I
    //   676: putfield c0 : I
    //   679: goto -> 2837
    //   682: aload #8
    //   684: getfield d : Landroidx/constraintlayout/widget/b$b;
    //   687: astore_1
    //   688: aload_1
    //   689: aload #9
    //   691: iload #7
    //   693: aload_1
    //   694: getfield b0 : I
    //   697: invokevirtual getInt : (II)I
    //   700: putfield b0 : I
    //   703: goto -> 2837
    //   706: ldc 'ConstraintSet'
    //   708: ldc_w 'CURRENTLY UNSUPPORTED'
    //   711: invokestatic e : (Ljava/lang/String;Ljava/lang/String;)I
    //   714: pop
    //   715: goto -> 2837
    //   718: aload #8
    //   720: getfield d : Landroidx/constraintlayout/widget/b$b;
    //   723: aload #9
    //   725: iload #7
    //   727: fconst_1
    //   728: invokevirtual getFloat : (IF)F
    //   731: putfield a0 : F
    //   734: goto -> 2837
    //   737: aload #8
    //   739: getfield d : Landroidx/constraintlayout/widget/b$b;
    //   742: aload #9
    //   744: iload #7
    //   746: fconst_1
    //   747: invokevirtual getFloat : (IF)F
    //   750: putfield Z : F
    //   753: goto -> 2837
    //   756: aload #8
    //   758: getfield b : Landroidx/constraintlayout/widget/b$d;
    //   761: astore_1
    //   762: aload_1
    //   763: aload #9
    //   765: iload #7
    //   767: aload_1
    //   768: getfield e : F
    //   771: invokevirtual getFloat : (IF)F
    //   774: putfield e : F
    //   777: goto -> 2837
    //   780: aload #8
    //   782: getfield c : Landroidx/constraintlayout/widget/b$c;
    //   785: astore_1
    //   786: aload_1
    //   787: aload #9
    //   789: iload #7
    //   791: aload_1
    //   792: getfield g : F
    //   795: invokevirtual getFloat : (IF)F
    //   798: putfield g : F
    //   801: goto -> 2837
    //   804: aload #8
    //   806: getfield c : Landroidx/constraintlayout/widget/b$c;
    //   809: aload #9
    //   811: iload #7
    //   813: iconst_0
    //   814: invokevirtual getInt : (II)I
    //   817: putfield e : I
    //   820: goto -> 2837
    //   823: aload #9
    //   825: iload #7
    //   827: invokevirtual peekValue : (I)Landroid/util/TypedValue;
    //   830: getfield type : I
    //   833: iconst_3
    //   834: if_icmpne -> 854
    //   837: aload #8
    //   839: getfield c : Landroidx/constraintlayout/widget/b$c;
    //   842: astore_2
    //   843: aload #9
    //   845: iload #7
    //   847: invokevirtual getString : (I)Ljava/lang/String;
    //   850: astore_1
    //   851: goto -> 873
    //   854: aload #8
    //   856: getfield c : Landroidx/constraintlayout/widget/b$c;
    //   859: astore_2
    //   860: getstatic e4/k6.k : [Ljava/lang/String;
    //   863: aload #9
    //   865: iload #7
    //   867: iconst_0
    //   868: invokevirtual getInteger : (II)I
    //   871: aaload
    //   872: astore_1
    //   873: aload_2
    //   874: aload_1
    //   875: putfield c : Ljava/lang/String;
    //   878: goto -> 2837
    //   881: aload #8
    //   883: getfield c : Landroidx/constraintlayout/widget/b$c;
    //   886: astore_1
    //   887: aload #9
    //   889: iload #7
    //   891: aload_1
    //   892: getfield b : I
    //   895: invokevirtual getResourceId : (II)I
    //   898: istore #5
    //   900: iload #5
    //   902: istore #4
    //   904: iload #5
    //   906: iconst_m1
    //   907: if_icmpne -> 920
    //   910: aload #9
    //   912: iload #7
    //   914: iconst_m1
    //   915: invokevirtual getInt : (II)I
    //   918: istore #4
    //   920: aload_1
    //   921: iload #4
    //   923: putfield b : I
    //   926: goto -> 2837
    //   929: aload #8
    //   931: getfield d : Landroidx/constraintlayout/widget/b$b;
    //   934: astore_1
    //   935: aload_1
    //   936: aload #9
    //   938: iload #7
    //   940: aload_1
    //   941: getfield z : F
    //   944: invokevirtual getFloat : (IF)F
    //   947: putfield z : F
    //   950: goto -> 2837
    //   953: aload #8
    //   955: getfield d : Landroidx/constraintlayout/widget/b$b;
    //   958: astore_1
    //   959: aload_1
    //   960: aload #9
    //   962: iload #7
    //   964: aload_1
    //   965: getfield y : I
    //   968: invokevirtual getDimensionPixelSize : (II)I
    //   971: putfield y : I
    //   974: goto -> 2837
    //   977: aload #8
    //   979: getfield d : Landroidx/constraintlayout/widget/b$b;
    //   982: astore_1
    //   983: aload #9
    //   985: iload #7
    //   987: aload_1
    //   988: getfield x : I
    //   991: invokevirtual getResourceId : (II)I
    //   994: istore #5
    //   996: iload #5
    //   998: istore #4
    //   1000: iload #5
    //   1002: iconst_m1
    //   1003: if_icmpne -> 1016
    //   1006: aload #9
    //   1008: iload #7
    //   1010: iconst_m1
    //   1011: invokevirtual getInt : (II)I
    //   1014: istore #4
    //   1016: aload_1
    //   1017: iload #4
    //   1019: putfield x : I
    //   1022: goto -> 2837
    //   1025: aload #8
    //   1027: getfield e : Landroidx/constraintlayout/widget/b$e;
    //   1030: astore_1
    //   1031: aload_1
    //   1032: aload #9
    //   1034: iload #7
    //   1036: aload_1
    //   1037: getfield b : F
    //   1040: invokevirtual getFloat : (IF)F
    //   1043: putfield b : F
    //   1046: goto -> 2837
    //   1049: aload #8
    //   1051: getfield d : Landroidx/constraintlayout/widget/b$b;
    //   1054: astore_1
    //   1055: aload_1
    //   1056: aload #9
    //   1058: iload #7
    //   1060: aload_1
    //   1061: getfield Y : I
    //   1064: invokevirtual getDimensionPixelSize : (II)I
    //   1067: putfield Y : I
    //   1070: goto -> 2837
    //   1073: aload #8
    //   1075: getfield d : Landroidx/constraintlayout/widget/b$b;
    //   1078: astore_1
    //   1079: aload_1
    //   1080: aload #9
    //   1082: iload #7
    //   1084: aload_1
    //   1085: getfield X : I
    //   1088: invokevirtual getDimensionPixelSize : (II)I
    //   1091: putfield X : I
    //   1094: goto -> 2837
    //   1097: aload #8
    //   1099: getfield d : Landroidx/constraintlayout/widget/b$b;
    //   1102: astore_1
    //   1103: aload_1
    //   1104: aload #9
    //   1106: iload #7
    //   1108: aload_1
    //   1109: getfield W : I
    //   1112: invokevirtual getDimensionPixelSize : (II)I
    //   1115: putfield W : I
    //   1118: goto -> 2837
    //   1121: aload #8
    //   1123: getfield d : Landroidx/constraintlayout/widget/b$b;
    //   1126: astore_1
    //   1127: aload_1
    //   1128: aload #9
    //   1130: iload #7
    //   1132: aload_1
    //   1133: getfield V : I
    //   1136: invokevirtual getDimensionPixelSize : (II)I
    //   1139: putfield V : I
    //   1142: goto -> 2837
    //   1145: aload #8
    //   1147: getfield d : Landroidx/constraintlayout/widget/b$b;
    //   1150: astore_1
    //   1151: aload_1
    //   1152: aload #9
    //   1154: iload #7
    //   1156: aload_1
    //   1157: getfield U : I
    //   1160: invokevirtual getInt : (II)I
    //   1163: putfield U : I
    //   1166: goto -> 2837
    //   1169: aload #8
    //   1171: getfield d : Landroidx/constraintlayout/widget/b$b;
    //   1174: astore_1
    //   1175: aload_1
    //   1176: aload #9
    //   1178: iload #7
    //   1180: aload_1
    //   1181: getfield T : I
    //   1184: invokevirtual getInt : (II)I
    //   1187: putfield T : I
    //   1190: goto -> 2837
    //   1193: aload #8
    //   1195: getfield e : Landroidx/constraintlayout/widget/b$e;
    //   1198: astore_1
    //   1199: aload_1
    //   1200: aload #9
    //   1202: iload #7
    //   1204: aload_1
    //   1205: getfield k : F
    //   1208: invokevirtual getDimension : (IF)F
    //   1211: putfield k : F
    //   1214: goto -> 2837
    //   1217: aload #8
    //   1219: getfield e : Landroidx/constraintlayout/widget/b$e;
    //   1222: astore_1
    //   1223: aload_1
    //   1224: aload #9
    //   1226: iload #7
    //   1228: aload_1
    //   1229: getfield j : F
    //   1232: invokevirtual getDimension : (IF)F
    //   1235: putfield j : F
    //   1238: goto -> 2837
    //   1241: aload #8
    //   1243: getfield e : Landroidx/constraintlayout/widget/b$e;
    //   1246: astore_1
    //   1247: aload_1
    //   1248: aload #9
    //   1250: iload #7
    //   1252: aload_1
    //   1253: getfield i : F
    //   1256: invokevirtual getDimension : (IF)F
    //   1259: putfield i : F
    //   1262: goto -> 2837
    //   1265: aload #8
    //   1267: getfield e : Landroidx/constraintlayout/widget/b$e;
    //   1270: astore_1
    //   1271: aload_1
    //   1272: aload #9
    //   1274: iload #7
    //   1276: aload_1
    //   1277: getfield h : F
    //   1280: invokevirtual getDimension : (IF)F
    //   1283: putfield h : F
    //   1286: goto -> 2837
    //   1289: aload #8
    //   1291: getfield e : Landroidx/constraintlayout/widget/b$e;
    //   1294: astore_1
    //   1295: aload_1
    //   1296: aload #9
    //   1298: iload #7
    //   1300: aload_1
    //   1301: getfield g : F
    //   1304: invokevirtual getDimension : (IF)F
    //   1307: putfield g : F
    //   1310: goto -> 2837
    //   1313: aload #8
    //   1315: getfield e : Landroidx/constraintlayout/widget/b$e;
    //   1318: astore_1
    //   1319: aload_1
    //   1320: aload #9
    //   1322: iload #7
    //   1324: aload_1
    //   1325: getfield f : F
    //   1328: invokevirtual getFloat : (IF)F
    //   1331: putfield f : F
    //   1334: goto -> 2837
    //   1337: aload #8
    //   1339: getfield e : Landroidx/constraintlayout/widget/b$e;
    //   1342: astore_1
    //   1343: aload_1
    //   1344: aload #9
    //   1346: iload #7
    //   1348: aload_1
    //   1349: getfield e : F
    //   1352: invokevirtual getFloat : (IF)F
    //   1355: putfield e : F
    //   1358: goto -> 2837
    //   1361: aload #8
    //   1363: getfield e : Landroidx/constraintlayout/widget/b$e;
    //   1366: astore_1
    //   1367: aload_1
    //   1368: aload #9
    //   1370: iload #7
    //   1372: aload_1
    //   1373: getfield d : F
    //   1376: invokevirtual getFloat : (IF)F
    //   1379: putfield d : F
    //   1382: goto -> 2837
    //   1385: aload #8
    //   1387: getfield e : Landroidx/constraintlayout/widget/b$e;
    //   1390: astore_1
    //   1391: aload_1
    //   1392: aload #9
    //   1394: iload #7
    //   1396: aload_1
    //   1397: getfield c : F
    //   1400: invokevirtual getFloat : (IF)F
    //   1403: putfield c : F
    //   1406: goto -> 2837
    //   1409: aload #8
    //   1411: getfield e : Landroidx/constraintlayout/widget/b$e;
    //   1414: astore_1
    //   1415: aload_1
    //   1416: iconst_1
    //   1417: putfield l : Z
    //   1420: aload_1
    //   1421: aload #9
    //   1423: iload #7
    //   1425: aload_1
    //   1426: getfield m : F
    //   1429: invokevirtual getDimension : (IF)F
    //   1432: putfield m : F
    //   1435: goto -> 2837
    //   1438: aload #8
    //   1440: getfield b : Landroidx/constraintlayout/widget/b$d;
    //   1443: astore_1
    //   1444: aload_1
    //   1445: aload #9
    //   1447: iload #7
    //   1449: aload_1
    //   1450: getfield d : F
    //   1453: invokevirtual getFloat : (IF)F
    //   1456: putfield d : F
    //   1459: goto -> 2837
    //   1462: aload #8
    //   1464: getfield d : Landroidx/constraintlayout/widget/b$b;
    //   1467: astore_1
    //   1468: aload_1
    //   1469: aload #9
    //   1471: iload #7
    //   1473: aload_1
    //   1474: getfield S : I
    //   1477: invokevirtual getInt : (II)I
    //   1480: putfield S : I
    //   1483: goto -> 2837
    //   1486: aload #8
    //   1488: getfield d : Landroidx/constraintlayout/widget/b$b;
    //   1491: astore_1
    //   1492: aload_1
    //   1493: aload #9
    //   1495: iload #7
    //   1497: aload_1
    //   1498: getfield R : I
    //   1501: invokevirtual getInt : (II)I
    //   1504: putfield R : I
    //   1507: goto -> 2837
    //   1510: aload #8
    //   1512: getfield d : Landroidx/constraintlayout/widget/b$b;
    //   1515: astore_1
    //   1516: aload_1
    //   1517: aload #9
    //   1519: iload #7
    //   1521: aload_1
    //   1522: getfield P : F
    //   1525: invokevirtual getFloat : (IF)F
    //   1528: putfield P : F
    //   1531: goto -> 2837
    //   1534: aload #8
    //   1536: getfield d : Landroidx/constraintlayout/widget/b$b;
    //   1539: astore_1
    //   1540: aload_1
    //   1541: aload #9
    //   1543: iload #7
    //   1545: aload_1
    //   1546: getfield Q : F
    //   1549: invokevirtual getFloat : (IF)F
    //   1552: putfield Q : F
    //   1555: goto -> 2837
    //   1558: aload #8
    //   1560: aload #9
    //   1562: iload #7
    //   1564: aload #8
    //   1566: getfield a : I
    //   1569: invokevirtual getResourceId : (II)I
    //   1572: putfield a : I
    //   1575: goto -> 2837
    //   1578: aload #8
    //   1580: getfield d : Landroidx/constraintlayout/widget/b$b;
    //   1583: astore_1
    //   1584: aload_1
    //   1585: aload #9
    //   1587: iload #7
    //   1589: aload_1
    //   1590: getfield v : F
    //   1593: invokevirtual getFloat : (IF)F
    //   1596: putfield v : F
    //   1599: goto -> 2837
    //   1602: aload #8
    //   1604: getfield d : Landroidx/constraintlayout/widget/b$b;
    //   1607: astore_1
    //   1608: aload #9
    //   1610: iload #7
    //   1612: aload_1
    //   1613: getfield l : I
    //   1616: invokevirtual getResourceId : (II)I
    //   1619: istore #5
    //   1621: iload #5
    //   1623: istore #4
    //   1625: iload #5
    //   1627: iconst_m1
    //   1628: if_icmpne -> 1641
    //   1631: aload #9
    //   1633: iload #7
    //   1635: iconst_m1
    //   1636: invokevirtual getInt : (II)I
    //   1639: istore #4
    //   1641: aload_1
    //   1642: iload #4
    //   1644: putfield l : I
    //   1647: goto -> 2837
    //   1650: aload #8
    //   1652: getfield d : Landroidx/constraintlayout/widget/b$b;
    //   1655: astore_1
    //   1656: aload #9
    //   1658: iload #7
    //   1660: aload_1
    //   1661: getfield m : I
    //   1664: invokevirtual getResourceId : (II)I
    //   1667: istore #5
    //   1669: iload #5
    //   1671: istore #4
    //   1673: iload #5
    //   1675: iconst_m1
    //   1676: if_icmpne -> 1689
    //   1679: aload #9
    //   1681: iload #7
    //   1683: iconst_m1
    //   1684: invokevirtual getInt : (II)I
    //   1687: istore #4
    //   1689: aload_1
    //   1690: iload #4
    //   1692: putfield m : I
    //   1695: goto -> 2837
    //   1698: aload #8
    //   1700: getfield d : Landroidx/constraintlayout/widget/b$b;
    //   1703: astore_1
    //   1704: aload_1
    //   1705: aload #9
    //   1707: iload #7
    //   1709: aload_1
    //   1710: getfield F : I
    //   1713: invokevirtual getDimensionPixelSize : (II)I
    //   1716: putfield F : I
    //   1719: goto -> 2837
    //   1722: aload #8
    //   1724: getfield d : Landroidx/constraintlayout/widget/b$b;
    //   1727: astore_1
    //   1728: aload #9
    //   1730: iload #7
    //   1732: aload_1
    //   1733: getfield r : I
    //   1736: invokevirtual getResourceId : (II)I
    //   1739: istore #5
    //   1741: iload #5
    //   1743: istore #4
    //   1745: iload #5
    //   1747: iconst_m1
    //   1748: if_icmpne -> 1761
    //   1751: aload #9
    //   1753: iload #7
    //   1755: iconst_m1
    //   1756: invokevirtual getInt : (II)I
    //   1759: istore #4
    //   1761: aload_1
    //   1762: iload #4
    //   1764: putfield r : I
    //   1767: goto -> 2837
    //   1770: aload #8
    //   1772: getfield d : Landroidx/constraintlayout/widget/b$b;
    //   1775: astore_1
    //   1776: aload #9
    //   1778: iload #7
    //   1780: aload_1
    //   1781: getfield q : I
    //   1784: invokevirtual getResourceId : (II)I
    //   1787: istore #5
    //   1789: iload #5
    //   1791: istore #4
    //   1793: iload #5
    //   1795: iconst_m1
    //   1796: if_icmpne -> 1809
    //   1799: aload #9
    //   1801: iload #7
    //   1803: iconst_m1
    //   1804: invokevirtual getInt : (II)I
    //   1807: istore #4
    //   1809: aload_1
    //   1810: iload #4
    //   1812: putfield q : I
    //   1815: goto -> 2837
    //   1818: aload #8
    //   1820: getfield d : Landroidx/constraintlayout/widget/b$b;
    //   1823: astore_1
    //   1824: aload_1
    //   1825: aload #9
    //   1827: iload #7
    //   1829: aload_1
    //   1830: getfield I : I
    //   1833: invokevirtual getDimensionPixelSize : (II)I
    //   1836: putfield I : I
    //   1839: goto -> 2837
    //   1842: aload #8
    //   1844: getfield d : Landroidx/constraintlayout/widget/b$b;
    //   1847: astore_1
    //   1848: aload #9
    //   1850: iload #7
    //   1852: aload_1
    //   1853: getfield k : I
    //   1856: invokevirtual getResourceId : (II)I
    //   1859: istore #5
    //   1861: iload #5
    //   1863: istore #4
    //   1865: iload #5
    //   1867: iconst_m1
    //   1868: if_icmpne -> 1881
    //   1871: aload #9
    //   1873: iload #7
    //   1875: iconst_m1
    //   1876: invokevirtual getInt : (II)I
    //   1879: istore #4
    //   1881: aload_1
    //   1882: iload #4
    //   1884: putfield k : I
    //   1887: goto -> 2837
    //   1890: aload #8
    //   1892: getfield d : Landroidx/constraintlayout/widget/b$b;
    //   1895: astore_1
    //   1896: aload #9
    //   1898: iload #7
    //   1900: aload_1
    //   1901: getfield j : I
    //   1904: invokevirtual getResourceId : (II)I
    //   1907: istore #5
    //   1909: iload #5
    //   1911: istore #4
    //   1913: iload #5
    //   1915: iconst_m1
    //   1916: if_icmpne -> 1929
    //   1919: aload #9
    //   1921: iload #7
    //   1923: iconst_m1
    //   1924: invokevirtual getInt : (II)I
    //   1927: istore #4
    //   1929: aload_1
    //   1930: iload #4
    //   1932: putfield j : I
    //   1935: goto -> 2837
    //   1938: aload #8
    //   1940: getfield d : Landroidx/constraintlayout/widget/b$b;
    //   1943: astore_1
    //   1944: aload_1
    //   1945: aload #9
    //   1947: iload #7
    //   1949: aload_1
    //   1950: getfield E : I
    //   1953: invokevirtual getDimensionPixelSize : (II)I
    //   1956: putfield E : I
    //   1959: goto -> 2837
    //   1962: aload #8
    //   1964: getfield d : Landroidx/constraintlayout/widget/b$b;
    //   1967: astore_1
    //   1968: aload_1
    //   1969: aload #9
    //   1971: iload #7
    //   1973: aload_1
    //   1974: getfield C : I
    //   1977: invokevirtual getInt : (II)I
    //   1980: putfield C : I
    //   1983: goto -> 2837
    //   1986: aload #8
    //   1988: getfield d : Landroidx/constraintlayout/widget/b$b;
    //   1991: astore_1
    //   1992: aload #9
    //   1994: iload #7
    //   1996: aload_1
    //   1997: getfield i : I
    //   2000: invokevirtual getResourceId : (II)I
    //   2003: istore #5
    //   2005: iload #5
    //   2007: istore #4
    //   2009: iload #5
    //   2011: iconst_m1
    //   2012: if_icmpne -> 2025
    //   2015: aload #9
    //   2017: iload #7
    //   2019: iconst_m1
    //   2020: invokevirtual getInt : (II)I
    //   2023: istore #4
    //   2025: aload_1
    //   2026: iload #4
    //   2028: putfield i : I
    //   2031: goto -> 2837
    //   2034: aload #8
    //   2036: getfield d : Landroidx/constraintlayout/widget/b$b;
    //   2039: astore_1
    //   2040: aload #9
    //   2042: iload #7
    //   2044: aload_1
    //   2045: getfield h : I
    //   2048: invokevirtual getResourceId : (II)I
    //   2051: istore #5
    //   2053: iload #5
    //   2055: istore #4
    //   2057: iload #5
    //   2059: iconst_m1
    //   2060: if_icmpne -> 2073
    //   2063: aload #9
    //   2065: iload #7
    //   2067: iconst_m1
    //   2068: invokevirtual getInt : (II)I
    //   2071: istore #4
    //   2073: aload_1
    //   2074: iload #4
    //   2076: putfield h : I
    //   2079: goto -> 2837
    //   2082: aload #8
    //   2084: getfield d : Landroidx/constraintlayout/widget/b$b;
    //   2087: astore_1
    //   2088: aload_1
    //   2089: aload #9
    //   2091: iload #7
    //   2093: aload_1
    //   2094: getfield D : I
    //   2097: invokevirtual getDimensionPixelSize : (II)I
    //   2100: putfield D : I
    //   2103: goto -> 2837
    //   2106: aload #8
    //   2108: getfield d : Landroidx/constraintlayout/widget/b$b;
    //   2111: astore_1
    //   2112: aload_1
    //   2113: aload #9
    //   2115: iload #7
    //   2117: aload_1
    //   2118: getfield c : I
    //   2121: invokevirtual getLayoutDimension : (II)I
    //   2124: putfield c : I
    //   2127: goto -> 2837
    //   2130: aload #8
    //   2132: getfield b : Landroidx/constraintlayout/widget/b$d;
    //   2135: astore_1
    //   2136: aload_1
    //   2137: aload #9
    //   2139: iload #7
    //   2141: aload_1
    //   2142: getfield b : I
    //   2145: invokevirtual getInt : (II)I
    //   2148: putfield b : I
    //   2151: aload #8
    //   2153: getfield b : Landroidx/constraintlayout/widget/b$d;
    //   2156: astore_1
    //   2157: aload_1
    //   2158: getstatic androidx/constraintlayout/widget/b.d : [I
    //   2161: aload_1
    //   2162: getfield b : I
    //   2165: iaload
    //   2166: putfield b : I
    //   2169: goto -> 2837
    //   2172: aload #8
    //   2174: getfield d : Landroidx/constraintlayout/widget/b$b;
    //   2177: astore_1
    //   2178: aload_1
    //   2179: aload #9
    //   2181: iload #7
    //   2183: aload_1
    //   2184: getfield d : I
    //   2187: invokevirtual getLayoutDimension : (II)I
    //   2190: putfield d : I
    //   2193: goto -> 2837
    //   2196: aload #8
    //   2198: getfield d : Landroidx/constraintlayout/widget/b$b;
    //   2201: astore_1
    //   2202: aload_1
    //   2203: aload #9
    //   2205: iload #7
    //   2207: aload_1
    //   2208: getfield u : F
    //   2211: invokevirtual getFloat : (IF)F
    //   2214: putfield u : F
    //   2217: goto -> 2837
    //   2220: aload #8
    //   2222: getfield d : Landroidx/constraintlayout/widget/b$b;
    //   2225: astore_1
    //   2226: aload_1
    //   2227: aload #9
    //   2229: iload #7
    //   2231: aload_1
    //   2232: getfield g : F
    //   2235: invokevirtual getFloat : (IF)F
    //   2238: putfield g : F
    //   2241: goto -> 2837
    //   2244: aload #8
    //   2246: getfield d : Landroidx/constraintlayout/widget/b$b;
    //   2249: astore_1
    //   2250: aload_1
    //   2251: aload #9
    //   2253: iload #7
    //   2255: aload_1
    //   2256: getfield f : I
    //   2259: invokevirtual getDimensionPixelOffset : (II)I
    //   2262: putfield f : I
    //   2265: goto -> 2837
    //   2268: aload #8
    //   2270: getfield d : Landroidx/constraintlayout/widget/b$b;
    //   2273: astore_1
    //   2274: aload_1
    //   2275: aload #9
    //   2277: iload #7
    //   2279: aload_1
    //   2280: getfield e : I
    //   2283: invokevirtual getDimensionPixelOffset : (II)I
    //   2286: putfield e : I
    //   2289: goto -> 2837
    //   2292: aload #8
    //   2294: getfield d : Landroidx/constraintlayout/widget/b$b;
    //   2297: astore_1
    //   2298: aload_1
    //   2299: aload #9
    //   2301: iload #7
    //   2303: aload_1
    //   2304: getfield K : I
    //   2307: invokevirtual getDimensionPixelSize : (II)I
    //   2310: putfield K : I
    //   2313: goto -> 2837
    //   2316: aload #8
    //   2318: getfield d : Landroidx/constraintlayout/widget/b$b;
    //   2321: astore_1
    //   2322: aload_1
    //   2323: aload #9
    //   2325: iload #7
    //   2327: aload_1
    //   2328: getfield O : I
    //   2331: invokevirtual getDimensionPixelSize : (II)I
    //   2334: putfield O : I
    //   2337: goto -> 2837
    //   2340: aload #8
    //   2342: getfield d : Landroidx/constraintlayout/widget/b$b;
    //   2345: astore_1
    //   2346: aload_1
    //   2347: aload #9
    //   2349: iload #7
    //   2351: aload_1
    //   2352: getfield L : I
    //   2355: invokevirtual getDimensionPixelSize : (II)I
    //   2358: putfield L : I
    //   2361: goto -> 2837
    //   2364: aload #8
    //   2366: getfield d : Landroidx/constraintlayout/widget/b$b;
    //   2369: astore_1
    //   2370: aload_1
    //   2371: aload #9
    //   2373: iload #7
    //   2375: aload_1
    //   2376: getfield J : I
    //   2379: invokevirtual getDimensionPixelSize : (II)I
    //   2382: putfield J : I
    //   2385: goto -> 2837
    //   2388: aload #8
    //   2390: getfield d : Landroidx/constraintlayout/widget/b$b;
    //   2393: astore_1
    //   2394: aload_1
    //   2395: aload #9
    //   2397: iload #7
    //   2399: aload_1
    //   2400: getfield N : I
    //   2403: invokevirtual getDimensionPixelSize : (II)I
    //   2406: putfield N : I
    //   2409: goto -> 2837
    //   2412: aload #8
    //   2414: getfield d : Landroidx/constraintlayout/widget/b$b;
    //   2417: astore_1
    //   2418: aload_1
    //   2419: aload #9
    //   2421: iload #7
    //   2423: aload_1
    //   2424: getfield M : I
    //   2427: invokevirtual getDimensionPixelSize : (II)I
    //   2430: putfield M : I
    //   2433: goto -> 2837
    //   2436: aload #8
    //   2438: getfield d : Landroidx/constraintlayout/widget/b$b;
    //   2441: astore_1
    //   2442: aload #9
    //   2444: iload #7
    //   2446: aload_1
    //   2447: getfield s : I
    //   2450: invokevirtual getResourceId : (II)I
    //   2453: istore #5
    //   2455: iload #5
    //   2457: istore #4
    //   2459: iload #5
    //   2461: iconst_m1
    //   2462: if_icmpne -> 2475
    //   2465: aload #9
    //   2467: iload #7
    //   2469: iconst_m1
    //   2470: invokevirtual getInt : (II)I
    //   2473: istore #4
    //   2475: aload_1
    //   2476: iload #4
    //   2478: putfield s : I
    //   2481: goto -> 2837
    //   2484: aload #8
    //   2486: getfield d : Landroidx/constraintlayout/widget/b$b;
    //   2489: astore_1
    //   2490: aload #9
    //   2492: iload #7
    //   2494: aload_1
    //   2495: getfield t : I
    //   2498: invokevirtual getResourceId : (II)I
    //   2501: istore #5
    //   2503: iload #5
    //   2505: istore #4
    //   2507: iload #5
    //   2509: iconst_m1
    //   2510: if_icmpne -> 2523
    //   2513: aload #9
    //   2515: iload #7
    //   2517: iconst_m1
    //   2518: invokevirtual getInt : (II)I
    //   2521: istore #4
    //   2523: aload_1
    //   2524: iload #4
    //   2526: putfield t : I
    //   2529: goto -> 2837
    //   2532: aload #8
    //   2534: getfield d : Landroidx/constraintlayout/widget/b$b;
    //   2537: astore_1
    //   2538: aload_1
    //   2539: aload #9
    //   2541: iload #7
    //   2543: aload_1
    //   2544: getfield H : I
    //   2547: invokevirtual getDimensionPixelSize : (II)I
    //   2550: putfield H : I
    //   2553: goto -> 2837
    //   2556: aload #8
    //   2558: getfield d : Landroidx/constraintlayout/widget/b$b;
    //   2561: astore_1
    //   2562: aload_1
    //   2563: aload #9
    //   2565: iload #7
    //   2567: aload_1
    //   2568: getfield B : I
    //   2571: invokevirtual getDimensionPixelOffset : (II)I
    //   2574: putfield B : I
    //   2577: goto -> 2837
    //   2580: aload #8
    //   2582: getfield d : Landroidx/constraintlayout/widget/b$b;
    //   2585: astore_1
    //   2586: aload_1
    //   2587: aload #9
    //   2589: iload #7
    //   2591: aload_1
    //   2592: getfield A : I
    //   2595: invokevirtual getDimensionPixelOffset : (II)I
    //   2598: putfield A : I
    //   2601: goto -> 2837
    //   2604: aload #8
    //   2606: getfield d : Landroidx/constraintlayout/widget/b$b;
    //   2609: aload #9
    //   2611: iload #7
    //   2613: invokevirtual getString : (I)Ljava/lang/String;
    //   2616: putfield w : Ljava/lang/String;
    //   2619: goto -> 2837
    //   2622: aload #8
    //   2624: getfield d : Landroidx/constraintlayout/widget/b$b;
    //   2627: astore_1
    //   2628: aload #9
    //   2630: iload #7
    //   2632: aload_1
    //   2633: getfield n : I
    //   2636: invokevirtual getResourceId : (II)I
    //   2639: istore #5
    //   2641: iload #5
    //   2643: istore #4
    //   2645: iload #5
    //   2647: iconst_m1
    //   2648: if_icmpne -> 2661
    //   2651: aload #9
    //   2653: iload #7
    //   2655: iconst_m1
    //   2656: invokevirtual getInt : (II)I
    //   2659: istore #4
    //   2661: aload_1
    //   2662: iload #4
    //   2664: putfield n : I
    //   2667: goto -> 2837
    //   2670: aload #8
    //   2672: getfield d : Landroidx/constraintlayout/widget/b$b;
    //   2675: astore_1
    //   2676: aload #9
    //   2678: iload #7
    //   2680: aload_1
    //   2681: getfield o : I
    //   2684: invokevirtual getResourceId : (II)I
    //   2687: istore #5
    //   2689: iload #5
    //   2691: istore #4
    //   2693: iload #5
    //   2695: iconst_m1
    //   2696: if_icmpne -> 2709
    //   2699: aload #9
    //   2701: iload #7
    //   2703: iconst_m1
    //   2704: invokevirtual getInt : (II)I
    //   2707: istore #4
    //   2709: aload_1
    //   2710: iload #4
    //   2712: putfield o : I
    //   2715: goto -> 2837
    //   2718: aload #8
    //   2720: getfield d : Landroidx/constraintlayout/widget/b$b;
    //   2723: astore_1
    //   2724: aload_1
    //   2725: aload #9
    //   2727: iload #7
    //   2729: aload_1
    //   2730: getfield G : I
    //   2733: invokevirtual getDimensionPixelSize : (II)I
    //   2736: putfield G : I
    //   2739: goto -> 2837
    //   2742: aload #8
    //   2744: getfield d : Landroidx/constraintlayout/widget/b$b;
    //   2747: astore_1
    //   2748: aload #9
    //   2750: iload #7
    //   2752: aload_1
    //   2753: getfield p : I
    //   2756: invokevirtual getResourceId : (II)I
    //   2759: istore #5
    //   2761: iload #5
    //   2763: istore #4
    //   2765: iload #5
    //   2767: iconst_m1
    //   2768: if_icmpne -> 2781
    //   2771: aload #9
    //   2773: iload #7
    //   2775: iconst_m1
    //   2776: invokevirtual getInt : (II)I
    //   2779: istore #4
    //   2781: aload_1
    //   2782: iload #4
    //   2784: putfield p : I
    //   2787: goto -> 2837
    //   2790: aload_1
    //   2791: aload_2
    //   2792: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   2795: pop
    //   2796: aload_1
    //   2797: iload #7
    //   2799: invokestatic toHexString : (I)Ljava/lang/String;
    //   2802: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   2805: pop
    //   2806: aload_1
    //   2807: ldc_w '   '
    //   2810: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   2813: pop
    //   2814: aload_1
    //   2815: getstatic androidx/constraintlayout/widget/b.e : Landroid/util/SparseIntArray;
    //   2818: iload #7
    //   2820: invokevirtual get : (I)I
    //   2823: invokevirtual append : (I)Ljava/lang/StringBuilder;
    //   2826: pop
    //   2827: ldc 'ConstraintSet'
    //   2829: aload_1
    //   2830: invokevirtual toString : ()Ljava/lang/String;
    //   2833: invokestatic w : (Ljava/lang/String;Ljava/lang/String;)I
    //   2836: pop
    //   2837: iload_3
    //   2838: iconst_1
    //   2839: iadd
    //   2840: istore_3
    //   2841: goto -> 28
    //   2844: aload #9
    //   2846: invokevirtual recycle : ()V
    //   2849: aload #8
    //   2851: areturn
  }
  
  public void e(Context paramContext, int paramInt) {
    XmlResourceParser xmlResourceParser = paramContext.getResources().getXml(paramInt);
    try {
      paramInt = xmlResourceParser.getEventType();
    } catch (XmlPullParserException xmlPullParserException) {
      xmlPullParserException.printStackTrace();
      return;
    } catch (IOException iOException) {
      iOException.printStackTrace();
      return;
    } 
    while (true) {
      if (paramInt != 1) {
        if (paramInt != 0) {
          if (paramInt == 2) {
            String str = xmlResourceParser.getName();
            a a = d((Context)iOException, Xml.asAttributeSet((XmlPullParser)xmlResourceParser));
            if (str.equalsIgnoreCase("Guideline"))
              a.d.a = true; 
            this.c.put(Integer.valueOf(a.a), a);
          } 
        } else {
          xmlResourceParser.getName();
        } 
        paramInt = xmlResourceParser.next();
        continue;
      } 
      return;
    } 
  }
  
  public static class a {
    public int a;
    
    public final b.d b = new b.d();
    
    public final b.c c = new b.c();
    
    public final b.b d = new b.b();
    
    public final b.e e = new b.e();
    
    public HashMap<String, w.a> f = new HashMap<String, w.a>();
    
    public void a(ConstraintLayout.a param1a) {
      b.b b1 = this.d;
      param1a.d = b1.h;
      param1a.e = b1.i;
      param1a.f = b1.j;
      param1a.g = b1.k;
      param1a.h = b1.l;
      param1a.i = b1.m;
      param1a.j = b1.n;
      param1a.k = b1.o;
      param1a.l = b1.p;
      param1a.p = b1.q;
      param1a.q = b1.r;
      param1a.r = b1.s;
      param1a.s = b1.t;
      param1a.leftMargin = b1.D;
      param1a.rightMargin = b1.E;
      param1a.topMargin = b1.F;
      param1a.bottomMargin = b1.G;
      param1a.x = b1.O;
      param1a.y = b1.N;
      param1a.u = b1.K;
      param1a.w = b1.M;
      param1a.z = b1.u;
      param1a.A = b1.v;
      param1a.m = b1.x;
      param1a.n = b1.y;
      param1a.o = b1.z;
      param1a.B = b1.w;
      param1a.P = b1.A;
      param1a.Q = b1.B;
      param1a.E = b1.P;
      param1a.D = b1.Q;
      param1a.G = b1.S;
      param1a.F = b1.R;
      param1a.S = b1.h0;
      param1a.T = b1.i0;
      param1a.H = b1.T;
      param1a.I = b1.U;
      param1a.L = b1.V;
      param1a.M = b1.W;
      param1a.J = b1.X;
      param1a.K = b1.Y;
      param1a.N = b1.Z;
      param1a.O = b1.a0;
      param1a.R = b1.C;
      param1a.c = b1.g;
      param1a.a = b1.e;
      param1a.b = b1.f;
      param1a.width = b1.c;
      param1a.height = b1.d;
      String str = b1.g0;
      if (str != null)
        param1a.U = str; 
      param1a.setMarginStart(b1.I);
      param1a.setMarginEnd(this.d.H);
      param1a.a();
    }
    
    public final void b(int param1Int, ConstraintLayout.a param1a) {
      this.a = param1Int;
      b.b b1 = this.d;
      b1.h = param1a.d;
      b1.i = param1a.e;
      b1.j = param1a.f;
      b1.k = param1a.g;
      b1.l = param1a.h;
      b1.m = param1a.i;
      b1.n = param1a.j;
      b1.o = param1a.k;
      b1.p = param1a.l;
      b1.q = param1a.p;
      b1.r = param1a.q;
      b1.s = param1a.r;
      b1.t = param1a.s;
      b1.u = param1a.z;
      b1.v = param1a.A;
      b1.w = param1a.B;
      b1.x = param1a.m;
      b1.y = param1a.n;
      b1.z = param1a.o;
      b1.A = param1a.P;
      b1.B = param1a.Q;
      b1.C = param1a.R;
      b1.g = param1a.c;
      b1.e = param1a.a;
      b1.f = param1a.b;
      b1.c = param1a.width;
      b1.d = param1a.height;
      b1.D = param1a.leftMargin;
      b1.E = param1a.rightMargin;
      b1.F = param1a.topMargin;
      b1.G = param1a.bottomMargin;
      b1.P = param1a.E;
      b1.Q = param1a.D;
      b1.S = param1a.G;
      b1.R = param1a.F;
      b1.h0 = param1a.S;
      b1.i0 = param1a.T;
      b1.T = param1a.H;
      b1.U = param1a.I;
      b1.V = param1a.L;
      b1.W = param1a.M;
      b1.X = param1a.J;
      b1.Y = param1a.K;
      b1.Z = param1a.N;
      b1.a0 = param1a.O;
      b1.g0 = param1a.U;
      b1.K = param1a.u;
      b1.M = param1a.w;
      b1.J = param1a.t;
      b1.L = param1a.v;
      b1.O = param1a.x;
      b1.N = param1a.y;
      b1.H = param1a.getMarginEnd();
      this.d.I = param1a.getMarginStart();
    }
    
    public final void c(int param1Int, c.a param1a) {
      b(param1Int, param1a);
      this.b.d = param1a.m0;
      b.e e1 = this.e;
      e1.b = param1a.p0;
      e1.c = param1a.q0;
      e1.d = param1a.r0;
      e1.e = param1a.s0;
      e1.f = param1a.t0;
      e1.g = param1a.u0;
      e1.h = param1a.v0;
      e1.i = param1a.w0;
      e1.j = param1a.x0;
      e1.k = param1a.y0;
      e1.m = param1a.o0;
      e1.l = param1a.n0;
    }
    
    public Object clone() {
      a a1 = new a();
      b.b b1 = a1.d;
      b.b b2 = this.d;
      Objects.requireNonNull(b1);
      b1.a = b2.a;
      b1.c = b2.c;
      b1.b = b2.b;
      b1.d = b2.d;
      b1.e = b2.e;
      b1.f = b2.f;
      b1.g = b2.g;
      b1.h = b2.h;
      b1.i = b2.i;
      b1.j = b2.j;
      b1.k = b2.k;
      b1.l = b2.l;
      b1.m = b2.m;
      b1.n = b2.n;
      b1.o = b2.o;
      b1.p = b2.p;
      b1.q = b2.q;
      b1.r = b2.r;
      b1.s = b2.s;
      b1.t = b2.t;
      b1.u = b2.u;
      b1.v = b2.v;
      b1.w = b2.w;
      b1.x = b2.x;
      b1.y = b2.y;
      b1.z = b2.z;
      b1.A = b2.A;
      b1.B = b2.B;
      b1.C = b2.C;
      b1.D = b2.D;
      b1.E = b2.E;
      b1.F = b2.F;
      b1.G = b2.G;
      b1.H = b2.H;
      b1.I = b2.I;
      b1.J = b2.J;
      b1.K = b2.K;
      b1.L = b2.L;
      b1.M = b2.M;
      b1.N = b2.N;
      b1.O = b2.O;
      b1.P = b2.P;
      b1.Q = b2.Q;
      b1.R = b2.R;
      b1.S = b2.S;
      b1.T = b2.T;
      b1.U = b2.U;
      b1.V = b2.V;
      b1.W = b2.W;
      b1.X = b2.X;
      b1.Y = b2.Y;
      b1.Z = b2.Z;
      b1.a0 = b2.a0;
      b1.b0 = b2.b0;
      b1.c0 = b2.c0;
      b1.d0 = b2.d0;
      b1.g0 = b2.g0;
      int[] arrayOfInt = b2.e0;
      if (arrayOfInt != null) {
        b1.e0 = Arrays.copyOf(arrayOfInt, arrayOfInt.length);
      } else {
        b1.e0 = null;
      } 
      b1.f0 = b2.f0;
      b1.h0 = b2.h0;
      b1.i0 = b2.i0;
      b1.j0 = b2.j0;
      b.c c1 = a1.c;
      b.c c2 = this.c;
      Objects.requireNonNull(c1);
      c1.a = c2.a;
      c1.b = c2.b;
      c1.c = c2.c;
      c1.d = c2.d;
      c1.e = c2.e;
      c1.g = c2.g;
      c1.f = c2.f;
      b.d d1 = a1.b;
      b.d d2 = this.b;
      Objects.requireNonNull(d1);
      d1.a = d2.a;
      d1.b = d2.b;
      d1.d = d2.d;
      d1.e = d2.e;
      d1.c = d2.c;
      b.e e1 = a1.e;
      b.e e2 = this.e;
      Objects.requireNonNull(e1);
      e1.a = e2.a;
      e1.b = e2.b;
      e1.c = e2.c;
      e1.d = e2.d;
      e1.e = e2.e;
      e1.f = e2.f;
      e1.g = e2.g;
      e1.h = e2.h;
      e1.i = e2.i;
      e1.j = e2.j;
      e1.k = e2.k;
      e1.l = e2.l;
      e1.m = e2.m;
      a1.a = this.a;
      return a1;
    }
  }
  
  public static class b {
    public static SparseIntArray k0;
    
    public int A = -1;
    
    public int B = -1;
    
    public int C = -1;
    
    public int D = -1;
    
    public int E = -1;
    
    public int F = -1;
    
    public int G = -1;
    
    public int H = -1;
    
    public int I = -1;
    
    public int J = -1;
    
    public int K = -1;
    
    public int L = -1;
    
    public int M = -1;
    
    public int N = -1;
    
    public int O = -1;
    
    public float P = -1.0F;
    
    public float Q = -1.0F;
    
    public int R = 0;
    
    public int S = 0;
    
    public int T = 0;
    
    public int U = 0;
    
    public int V = -1;
    
    public int W = -1;
    
    public int X = -1;
    
    public int Y = -1;
    
    public float Z = 1.0F;
    
    public boolean a = false;
    
    public float a0 = 1.0F;
    
    public boolean b = false;
    
    public int b0 = -1;
    
    public int c;
    
    public int c0 = 0;
    
    public int d;
    
    public int d0 = -1;
    
    public int e = -1;
    
    public int[] e0;
    
    public int f = -1;
    
    public String f0;
    
    public float g = -1.0F;
    
    public String g0;
    
    public int h = -1;
    
    public boolean h0 = false;
    
    public int i = -1;
    
    public boolean i0 = false;
    
    public int j = -1;
    
    public boolean j0 = true;
    
    public int k = -1;
    
    public int l = -1;
    
    public int m = -1;
    
    public int n = -1;
    
    public int o = -1;
    
    public int p = -1;
    
    public int q = -1;
    
    public int r = -1;
    
    public int s = -1;
    
    public int t = -1;
    
    public float u = 0.5F;
    
    public float v = 0.5F;
    
    public String w = null;
    
    public int x = -1;
    
    public int y = 0;
    
    public float z = 0.0F;
    
    static {
      SparseIntArray sparseIntArray = new SparseIntArray();
      k0 = sparseIntArray;
      sparseIntArray.append(39, 24);
      k0.append(40, 25);
      k0.append(42, 28);
      k0.append(43, 29);
      k0.append(48, 35);
      k0.append(47, 34);
      k0.append(21, 4);
      k0.append(20, 3);
      k0.append(18, 1);
      k0.append(56, 6);
      k0.append(57, 7);
      k0.append(28, 17);
      k0.append(29, 18);
      k0.append(30, 19);
      k0.append(0, 26);
      k0.append(44, 31);
      k0.append(45, 32);
      k0.append(27, 10);
      k0.append(26, 9);
      k0.append(60, 13);
      k0.append(63, 16);
      k0.append(61, 14);
      k0.append(58, 11);
      k0.append(62, 15);
      k0.append(59, 12);
      k0.append(51, 38);
      k0.append(37, 37);
      k0.append(36, 39);
      k0.append(50, 40);
      k0.append(35, 20);
      k0.append(49, 36);
      k0.append(25, 5);
      k0.append(38, 76);
      k0.append(46, 76);
      k0.append(41, 76);
      k0.append(19, 76);
      k0.append(17, 76);
      k0.append(3, 23);
      k0.append(5, 27);
      k0.append(7, 30);
      k0.append(8, 8);
      k0.append(4, 33);
      k0.append(6, 2);
      k0.append(1, 22);
      k0.append(2, 21);
      k0.append(22, 61);
      k0.append(24, 62);
      k0.append(23, 63);
      k0.append(55, 69);
      k0.append(34, 70);
      k0.append(12, 71);
      k0.append(10, 72);
      k0.append(11, 73);
      k0.append(13, 74);
      k0.append(9, 75);
    }
    
    public void a(Context param1Context, AttributeSet param1AttributeSet) {
      // Byte code:
      //   0: aload_1
      //   1: aload_2
      //   2: getstatic u5/b.l : [I
      //   5: invokevirtual obtainStyledAttributes : (Landroid/util/AttributeSet;[I)Landroid/content/res/TypedArray;
      //   8: astore #8
      //   10: aload_0
      //   11: iconst_1
      //   12: putfield b : Z
      //   15: aload #8
      //   17: invokevirtual getIndexCount : ()I
      //   20: istore #6
      //   22: iconst_0
      //   23: istore_3
      //   24: iload_3
      //   25: iload #6
      //   27: if_icmpge -> 1931
      //   30: aload #8
      //   32: iload_3
      //   33: invokevirtual getIndex : (I)I
      //   36: istore #7
      //   38: getstatic androidx/constraintlayout/widget/b$b.k0 : Landroid/util/SparseIntArray;
      //   41: iload #7
      //   43: invokevirtual get : (I)I
      //   46: istore #4
      //   48: iload #4
      //   50: bipush #80
      //   52: if_icmpeq -> 1909
      //   55: iload #4
      //   57: bipush #81
      //   59: if_icmpeq -> 1891
      //   62: iload #4
      //   64: tableswitch default -> 240, 1 -> 1456, 2 -> 1438, 3 -> 1388, 4 -> 1338, 5 -> 1324, 6 -> 1306, 7 -> 1288, 8 -> 1270, 9 -> 1220, 10 -> 1170, 11 -> 1152, 12 -> 1134, 13 -> 1116, 14 -> 1098, 15 -> 1080, 16 -> 1062, 17 -> 1044, 18 -> 1026, 19 -> 1008, 20 -> 990, 21 -> 972, 22 -> 954, 23 -> 936, 24 -> 886, 25 -> 836, 26 -> 818, 27 -> 800, 28 -> 750, 29 -> 700, 30 -> 682, 31 -> 632, 32 -> 582, 33 -> 564, 34 -> 514, 35 -> 464, 36 -> 446, 37 -> 428, 38 -> 410, 39 -> 392, 40 -> 374
      //   240: iload #4
      //   242: tableswitch default -> 280, 54 -> 1596, 55 -> 1578, 56 -> 1560, 57 -> 1542, 58 -> 1524, 59 -> 1506
      //   280: iload #4
      //   282: tableswitch default -> 308, 61 -> 1650, 62 -> 1632, 63 -> 1614
      //   308: iload #4
      //   310: tableswitch default -> 360, 69 -> 1825, 70 -> 1810, 71 -> 1797, 72 -> 1779, 73 -> 1761, 74 -> 1747, 75 -> 1729, 76 -> 1714, 77 -> 1700
      //   360: new java/lang/StringBuilder
      //   363: dup
      //   364: invokespecial <init> : ()V
      //   367: astore_1
      //   368: ldc 'Unknown attribute 0x'
      //   370: astore_2
      //   371: goto -> 1840
      //   374: aload_0
      //   375: aload #8
      //   377: iload #7
      //   379: aload_0
      //   380: getfield S : I
      //   383: invokevirtual getInt : (II)I
      //   386: putfield S : I
      //   389: goto -> 1924
      //   392: aload_0
      //   393: aload #8
      //   395: iload #7
      //   397: aload_0
      //   398: getfield R : I
      //   401: invokevirtual getInt : (II)I
      //   404: putfield R : I
      //   407: goto -> 1924
      //   410: aload_0
      //   411: aload #8
      //   413: iload #7
      //   415: aload_0
      //   416: getfield P : F
      //   419: invokevirtual getFloat : (IF)F
      //   422: putfield P : F
      //   425: goto -> 1924
      //   428: aload_0
      //   429: aload #8
      //   431: iload #7
      //   433: aload_0
      //   434: getfield Q : F
      //   437: invokevirtual getFloat : (IF)F
      //   440: putfield Q : F
      //   443: goto -> 1924
      //   446: aload_0
      //   447: aload #8
      //   449: iload #7
      //   451: aload_0
      //   452: getfield v : F
      //   455: invokevirtual getFloat : (IF)F
      //   458: putfield v : F
      //   461: goto -> 1924
      //   464: aload_0
      //   465: getfield l : I
      //   468: istore #4
      //   470: getstatic androidx/constraintlayout/widget/b.d : [I
      //   473: astore_1
      //   474: aload #8
      //   476: iload #7
      //   478: iload #4
      //   480: invokevirtual getResourceId : (II)I
      //   483: istore #5
      //   485: iload #5
      //   487: istore #4
      //   489: iload #5
      //   491: iconst_m1
      //   492: if_icmpne -> 505
      //   495: aload #8
      //   497: iload #7
      //   499: iconst_m1
      //   500: invokevirtual getInt : (II)I
      //   503: istore #4
      //   505: aload_0
      //   506: iload #4
      //   508: putfield l : I
      //   511: goto -> 1924
      //   514: aload_0
      //   515: getfield m : I
      //   518: istore #4
      //   520: getstatic androidx/constraintlayout/widget/b.d : [I
      //   523: astore_1
      //   524: aload #8
      //   526: iload #7
      //   528: iload #4
      //   530: invokevirtual getResourceId : (II)I
      //   533: istore #5
      //   535: iload #5
      //   537: istore #4
      //   539: iload #5
      //   541: iconst_m1
      //   542: if_icmpne -> 555
      //   545: aload #8
      //   547: iload #7
      //   549: iconst_m1
      //   550: invokevirtual getInt : (II)I
      //   553: istore #4
      //   555: aload_0
      //   556: iload #4
      //   558: putfield m : I
      //   561: goto -> 1924
      //   564: aload_0
      //   565: aload #8
      //   567: iload #7
      //   569: aload_0
      //   570: getfield F : I
      //   573: invokevirtual getDimensionPixelSize : (II)I
      //   576: putfield F : I
      //   579: goto -> 1924
      //   582: aload_0
      //   583: getfield r : I
      //   586: istore #4
      //   588: getstatic androidx/constraintlayout/widget/b.d : [I
      //   591: astore_1
      //   592: aload #8
      //   594: iload #7
      //   596: iload #4
      //   598: invokevirtual getResourceId : (II)I
      //   601: istore #5
      //   603: iload #5
      //   605: istore #4
      //   607: iload #5
      //   609: iconst_m1
      //   610: if_icmpne -> 623
      //   613: aload #8
      //   615: iload #7
      //   617: iconst_m1
      //   618: invokevirtual getInt : (II)I
      //   621: istore #4
      //   623: aload_0
      //   624: iload #4
      //   626: putfield r : I
      //   629: goto -> 1924
      //   632: aload_0
      //   633: getfield q : I
      //   636: istore #4
      //   638: getstatic androidx/constraintlayout/widget/b.d : [I
      //   641: astore_1
      //   642: aload #8
      //   644: iload #7
      //   646: iload #4
      //   648: invokevirtual getResourceId : (II)I
      //   651: istore #5
      //   653: iload #5
      //   655: istore #4
      //   657: iload #5
      //   659: iconst_m1
      //   660: if_icmpne -> 673
      //   663: aload #8
      //   665: iload #7
      //   667: iconst_m1
      //   668: invokevirtual getInt : (II)I
      //   671: istore #4
      //   673: aload_0
      //   674: iload #4
      //   676: putfield q : I
      //   679: goto -> 1924
      //   682: aload_0
      //   683: aload #8
      //   685: iload #7
      //   687: aload_0
      //   688: getfield I : I
      //   691: invokevirtual getDimensionPixelSize : (II)I
      //   694: putfield I : I
      //   697: goto -> 1924
      //   700: aload_0
      //   701: getfield k : I
      //   704: istore #4
      //   706: getstatic androidx/constraintlayout/widget/b.d : [I
      //   709: astore_1
      //   710: aload #8
      //   712: iload #7
      //   714: iload #4
      //   716: invokevirtual getResourceId : (II)I
      //   719: istore #5
      //   721: iload #5
      //   723: istore #4
      //   725: iload #5
      //   727: iconst_m1
      //   728: if_icmpne -> 741
      //   731: aload #8
      //   733: iload #7
      //   735: iconst_m1
      //   736: invokevirtual getInt : (II)I
      //   739: istore #4
      //   741: aload_0
      //   742: iload #4
      //   744: putfield k : I
      //   747: goto -> 1924
      //   750: aload_0
      //   751: getfield j : I
      //   754: istore #4
      //   756: getstatic androidx/constraintlayout/widget/b.d : [I
      //   759: astore_1
      //   760: aload #8
      //   762: iload #7
      //   764: iload #4
      //   766: invokevirtual getResourceId : (II)I
      //   769: istore #5
      //   771: iload #5
      //   773: istore #4
      //   775: iload #5
      //   777: iconst_m1
      //   778: if_icmpne -> 791
      //   781: aload #8
      //   783: iload #7
      //   785: iconst_m1
      //   786: invokevirtual getInt : (II)I
      //   789: istore #4
      //   791: aload_0
      //   792: iload #4
      //   794: putfield j : I
      //   797: goto -> 1924
      //   800: aload_0
      //   801: aload #8
      //   803: iload #7
      //   805: aload_0
      //   806: getfield E : I
      //   809: invokevirtual getDimensionPixelSize : (II)I
      //   812: putfield E : I
      //   815: goto -> 1924
      //   818: aload_0
      //   819: aload #8
      //   821: iload #7
      //   823: aload_0
      //   824: getfield C : I
      //   827: invokevirtual getInt : (II)I
      //   830: putfield C : I
      //   833: goto -> 1924
      //   836: aload_0
      //   837: getfield i : I
      //   840: istore #4
      //   842: getstatic androidx/constraintlayout/widget/b.d : [I
      //   845: astore_1
      //   846: aload #8
      //   848: iload #7
      //   850: iload #4
      //   852: invokevirtual getResourceId : (II)I
      //   855: istore #5
      //   857: iload #5
      //   859: istore #4
      //   861: iload #5
      //   863: iconst_m1
      //   864: if_icmpne -> 877
      //   867: aload #8
      //   869: iload #7
      //   871: iconst_m1
      //   872: invokevirtual getInt : (II)I
      //   875: istore #4
      //   877: aload_0
      //   878: iload #4
      //   880: putfield i : I
      //   883: goto -> 1924
      //   886: aload_0
      //   887: getfield h : I
      //   890: istore #4
      //   892: getstatic androidx/constraintlayout/widget/b.d : [I
      //   895: astore_1
      //   896: aload #8
      //   898: iload #7
      //   900: iload #4
      //   902: invokevirtual getResourceId : (II)I
      //   905: istore #5
      //   907: iload #5
      //   909: istore #4
      //   911: iload #5
      //   913: iconst_m1
      //   914: if_icmpne -> 927
      //   917: aload #8
      //   919: iload #7
      //   921: iconst_m1
      //   922: invokevirtual getInt : (II)I
      //   925: istore #4
      //   927: aload_0
      //   928: iload #4
      //   930: putfield h : I
      //   933: goto -> 1924
      //   936: aload_0
      //   937: aload #8
      //   939: iload #7
      //   941: aload_0
      //   942: getfield D : I
      //   945: invokevirtual getDimensionPixelSize : (II)I
      //   948: putfield D : I
      //   951: goto -> 1924
      //   954: aload_0
      //   955: aload #8
      //   957: iload #7
      //   959: aload_0
      //   960: getfield c : I
      //   963: invokevirtual getLayoutDimension : (II)I
      //   966: putfield c : I
      //   969: goto -> 1924
      //   972: aload_0
      //   973: aload #8
      //   975: iload #7
      //   977: aload_0
      //   978: getfield d : I
      //   981: invokevirtual getLayoutDimension : (II)I
      //   984: putfield d : I
      //   987: goto -> 1924
      //   990: aload_0
      //   991: aload #8
      //   993: iload #7
      //   995: aload_0
      //   996: getfield u : F
      //   999: invokevirtual getFloat : (IF)F
      //   1002: putfield u : F
      //   1005: goto -> 1924
      //   1008: aload_0
      //   1009: aload #8
      //   1011: iload #7
      //   1013: aload_0
      //   1014: getfield g : F
      //   1017: invokevirtual getFloat : (IF)F
      //   1020: putfield g : F
      //   1023: goto -> 1924
      //   1026: aload_0
      //   1027: aload #8
      //   1029: iload #7
      //   1031: aload_0
      //   1032: getfield f : I
      //   1035: invokevirtual getDimensionPixelOffset : (II)I
      //   1038: putfield f : I
      //   1041: goto -> 1924
      //   1044: aload_0
      //   1045: aload #8
      //   1047: iload #7
      //   1049: aload_0
      //   1050: getfield e : I
      //   1053: invokevirtual getDimensionPixelOffset : (II)I
      //   1056: putfield e : I
      //   1059: goto -> 1924
      //   1062: aload_0
      //   1063: aload #8
      //   1065: iload #7
      //   1067: aload_0
      //   1068: getfield K : I
      //   1071: invokevirtual getDimensionPixelSize : (II)I
      //   1074: putfield K : I
      //   1077: goto -> 1924
      //   1080: aload_0
      //   1081: aload #8
      //   1083: iload #7
      //   1085: aload_0
      //   1086: getfield O : I
      //   1089: invokevirtual getDimensionPixelSize : (II)I
      //   1092: putfield O : I
      //   1095: goto -> 1924
      //   1098: aload_0
      //   1099: aload #8
      //   1101: iload #7
      //   1103: aload_0
      //   1104: getfield L : I
      //   1107: invokevirtual getDimensionPixelSize : (II)I
      //   1110: putfield L : I
      //   1113: goto -> 1924
      //   1116: aload_0
      //   1117: aload #8
      //   1119: iload #7
      //   1121: aload_0
      //   1122: getfield J : I
      //   1125: invokevirtual getDimensionPixelSize : (II)I
      //   1128: putfield J : I
      //   1131: goto -> 1924
      //   1134: aload_0
      //   1135: aload #8
      //   1137: iload #7
      //   1139: aload_0
      //   1140: getfield N : I
      //   1143: invokevirtual getDimensionPixelSize : (II)I
      //   1146: putfield N : I
      //   1149: goto -> 1924
      //   1152: aload_0
      //   1153: aload #8
      //   1155: iload #7
      //   1157: aload_0
      //   1158: getfield M : I
      //   1161: invokevirtual getDimensionPixelSize : (II)I
      //   1164: putfield M : I
      //   1167: goto -> 1924
      //   1170: aload_0
      //   1171: getfield s : I
      //   1174: istore #4
      //   1176: getstatic androidx/constraintlayout/widget/b.d : [I
      //   1179: astore_1
      //   1180: aload #8
      //   1182: iload #7
      //   1184: iload #4
      //   1186: invokevirtual getResourceId : (II)I
      //   1189: istore #5
      //   1191: iload #5
      //   1193: istore #4
      //   1195: iload #5
      //   1197: iconst_m1
      //   1198: if_icmpne -> 1211
      //   1201: aload #8
      //   1203: iload #7
      //   1205: iconst_m1
      //   1206: invokevirtual getInt : (II)I
      //   1209: istore #4
      //   1211: aload_0
      //   1212: iload #4
      //   1214: putfield s : I
      //   1217: goto -> 1924
      //   1220: aload_0
      //   1221: getfield t : I
      //   1224: istore #4
      //   1226: getstatic androidx/constraintlayout/widget/b.d : [I
      //   1229: astore_1
      //   1230: aload #8
      //   1232: iload #7
      //   1234: iload #4
      //   1236: invokevirtual getResourceId : (II)I
      //   1239: istore #5
      //   1241: iload #5
      //   1243: istore #4
      //   1245: iload #5
      //   1247: iconst_m1
      //   1248: if_icmpne -> 1261
      //   1251: aload #8
      //   1253: iload #7
      //   1255: iconst_m1
      //   1256: invokevirtual getInt : (II)I
      //   1259: istore #4
      //   1261: aload_0
      //   1262: iload #4
      //   1264: putfield t : I
      //   1267: goto -> 1924
      //   1270: aload_0
      //   1271: aload #8
      //   1273: iload #7
      //   1275: aload_0
      //   1276: getfield H : I
      //   1279: invokevirtual getDimensionPixelSize : (II)I
      //   1282: putfield H : I
      //   1285: goto -> 1924
      //   1288: aload_0
      //   1289: aload #8
      //   1291: iload #7
      //   1293: aload_0
      //   1294: getfield B : I
      //   1297: invokevirtual getDimensionPixelOffset : (II)I
      //   1300: putfield B : I
      //   1303: goto -> 1924
      //   1306: aload_0
      //   1307: aload #8
      //   1309: iload #7
      //   1311: aload_0
      //   1312: getfield A : I
      //   1315: invokevirtual getDimensionPixelOffset : (II)I
      //   1318: putfield A : I
      //   1321: goto -> 1924
      //   1324: aload_0
      //   1325: aload #8
      //   1327: iload #7
      //   1329: invokevirtual getString : (I)Ljava/lang/String;
      //   1332: putfield w : Ljava/lang/String;
      //   1335: goto -> 1924
      //   1338: aload_0
      //   1339: getfield n : I
      //   1342: istore #4
      //   1344: getstatic androidx/constraintlayout/widget/b.d : [I
      //   1347: astore_1
      //   1348: aload #8
      //   1350: iload #7
      //   1352: iload #4
      //   1354: invokevirtual getResourceId : (II)I
      //   1357: istore #5
      //   1359: iload #5
      //   1361: istore #4
      //   1363: iload #5
      //   1365: iconst_m1
      //   1366: if_icmpne -> 1379
      //   1369: aload #8
      //   1371: iload #7
      //   1373: iconst_m1
      //   1374: invokevirtual getInt : (II)I
      //   1377: istore #4
      //   1379: aload_0
      //   1380: iload #4
      //   1382: putfield n : I
      //   1385: goto -> 1924
      //   1388: aload_0
      //   1389: getfield o : I
      //   1392: istore #4
      //   1394: getstatic androidx/constraintlayout/widget/b.d : [I
      //   1397: astore_1
      //   1398: aload #8
      //   1400: iload #7
      //   1402: iload #4
      //   1404: invokevirtual getResourceId : (II)I
      //   1407: istore #5
      //   1409: iload #5
      //   1411: istore #4
      //   1413: iload #5
      //   1415: iconst_m1
      //   1416: if_icmpne -> 1429
      //   1419: aload #8
      //   1421: iload #7
      //   1423: iconst_m1
      //   1424: invokevirtual getInt : (II)I
      //   1427: istore #4
      //   1429: aload_0
      //   1430: iload #4
      //   1432: putfield o : I
      //   1435: goto -> 1924
      //   1438: aload_0
      //   1439: aload #8
      //   1441: iload #7
      //   1443: aload_0
      //   1444: getfield G : I
      //   1447: invokevirtual getDimensionPixelSize : (II)I
      //   1450: putfield G : I
      //   1453: goto -> 1924
      //   1456: aload_0
      //   1457: getfield p : I
      //   1460: istore #4
      //   1462: getstatic androidx/constraintlayout/widget/b.d : [I
      //   1465: astore_1
      //   1466: aload #8
      //   1468: iload #7
      //   1470: iload #4
      //   1472: invokevirtual getResourceId : (II)I
      //   1475: istore #5
      //   1477: iload #5
      //   1479: istore #4
      //   1481: iload #5
      //   1483: iconst_m1
      //   1484: if_icmpne -> 1497
      //   1487: aload #8
      //   1489: iload #7
      //   1491: iconst_m1
      //   1492: invokevirtual getInt : (II)I
      //   1495: istore #4
      //   1497: aload_0
      //   1498: iload #4
      //   1500: putfield p : I
      //   1503: goto -> 1924
      //   1506: aload_0
      //   1507: aload #8
      //   1509: iload #7
      //   1511: aload_0
      //   1512: getfield Y : I
      //   1515: invokevirtual getDimensionPixelSize : (II)I
      //   1518: putfield Y : I
      //   1521: goto -> 1924
      //   1524: aload_0
      //   1525: aload #8
      //   1527: iload #7
      //   1529: aload_0
      //   1530: getfield X : I
      //   1533: invokevirtual getDimensionPixelSize : (II)I
      //   1536: putfield X : I
      //   1539: goto -> 1924
      //   1542: aload_0
      //   1543: aload #8
      //   1545: iload #7
      //   1547: aload_0
      //   1548: getfield W : I
      //   1551: invokevirtual getDimensionPixelSize : (II)I
      //   1554: putfield W : I
      //   1557: goto -> 1924
      //   1560: aload_0
      //   1561: aload #8
      //   1563: iload #7
      //   1565: aload_0
      //   1566: getfield V : I
      //   1569: invokevirtual getDimensionPixelSize : (II)I
      //   1572: putfield V : I
      //   1575: goto -> 1924
      //   1578: aload_0
      //   1579: aload #8
      //   1581: iload #7
      //   1583: aload_0
      //   1584: getfield U : I
      //   1587: invokevirtual getInt : (II)I
      //   1590: putfield U : I
      //   1593: goto -> 1924
      //   1596: aload_0
      //   1597: aload #8
      //   1599: iload #7
      //   1601: aload_0
      //   1602: getfield T : I
      //   1605: invokevirtual getInt : (II)I
      //   1608: putfield T : I
      //   1611: goto -> 1924
      //   1614: aload_0
      //   1615: aload #8
      //   1617: iload #7
      //   1619: aload_0
      //   1620: getfield z : F
      //   1623: invokevirtual getFloat : (IF)F
      //   1626: putfield z : F
      //   1629: goto -> 1924
      //   1632: aload_0
      //   1633: aload #8
      //   1635: iload #7
      //   1637: aload_0
      //   1638: getfield y : I
      //   1641: invokevirtual getDimensionPixelSize : (II)I
      //   1644: putfield y : I
      //   1647: goto -> 1924
      //   1650: aload_0
      //   1651: getfield x : I
      //   1654: istore #4
      //   1656: getstatic androidx/constraintlayout/widget/b.d : [I
      //   1659: astore_1
      //   1660: aload #8
      //   1662: iload #7
      //   1664: iload #4
      //   1666: invokevirtual getResourceId : (II)I
      //   1669: istore #5
      //   1671: iload #5
      //   1673: istore #4
      //   1675: iload #5
      //   1677: iconst_m1
      //   1678: if_icmpne -> 1691
      //   1681: aload #8
      //   1683: iload #7
      //   1685: iconst_m1
      //   1686: invokevirtual getInt : (II)I
      //   1689: istore #4
      //   1691: aload_0
      //   1692: iload #4
      //   1694: putfield x : I
      //   1697: goto -> 1924
      //   1700: aload_0
      //   1701: aload #8
      //   1703: iload #7
      //   1705: invokevirtual getString : (I)Ljava/lang/String;
      //   1708: putfield g0 : Ljava/lang/String;
      //   1711: goto -> 1924
      //   1714: new java/lang/StringBuilder
      //   1717: dup
      //   1718: invokespecial <init> : ()V
      //   1721: astore_1
      //   1722: ldc_w 'unused attribute 0x'
      //   1725: astore_2
      //   1726: goto -> 1840
      //   1729: aload_0
      //   1730: aload #8
      //   1732: iload #7
      //   1734: aload_0
      //   1735: getfield j0 : Z
      //   1738: invokevirtual getBoolean : (IZ)Z
      //   1741: putfield j0 : Z
      //   1744: goto -> 1924
      //   1747: aload_0
      //   1748: aload #8
      //   1750: iload #7
      //   1752: invokevirtual getString : (I)Ljava/lang/String;
      //   1755: putfield f0 : Ljava/lang/String;
      //   1758: goto -> 1924
      //   1761: aload_0
      //   1762: aload #8
      //   1764: iload #7
      //   1766: aload_0
      //   1767: getfield c0 : I
      //   1770: invokevirtual getDimensionPixelSize : (II)I
      //   1773: putfield c0 : I
      //   1776: goto -> 1924
      //   1779: aload_0
      //   1780: aload #8
      //   1782: iload #7
      //   1784: aload_0
      //   1785: getfield b0 : I
      //   1788: invokevirtual getInt : (II)I
      //   1791: putfield b0 : I
      //   1794: goto -> 1924
      //   1797: ldc_w 'ConstraintSet'
      //   1800: ldc_w 'CURRENTLY UNSUPPORTED'
      //   1803: invokestatic e : (Ljava/lang/String;Ljava/lang/String;)I
      //   1806: pop
      //   1807: goto -> 1924
      //   1810: aload_0
      //   1811: aload #8
      //   1813: iload #7
      //   1815: fconst_1
      //   1816: invokevirtual getFloat : (IF)F
      //   1819: putfield a0 : F
      //   1822: goto -> 1924
      //   1825: aload_0
      //   1826: aload #8
      //   1828: iload #7
      //   1830: fconst_1
      //   1831: invokevirtual getFloat : (IF)F
      //   1834: putfield Z : F
      //   1837: goto -> 1924
      //   1840: aload_1
      //   1841: aload_2
      //   1842: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
      //   1845: pop
      //   1846: aload_1
      //   1847: iload #7
      //   1849: invokestatic toHexString : (I)Ljava/lang/String;
      //   1852: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
      //   1855: pop
      //   1856: aload_1
      //   1857: ldc_w '   '
      //   1860: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
      //   1863: pop
      //   1864: aload_1
      //   1865: getstatic androidx/constraintlayout/widget/b$b.k0 : Landroid/util/SparseIntArray;
      //   1868: iload #7
      //   1870: invokevirtual get : (I)I
      //   1873: invokevirtual append : (I)Ljava/lang/StringBuilder;
      //   1876: pop
      //   1877: ldc_w 'ConstraintSet'
      //   1880: aload_1
      //   1881: invokevirtual toString : ()Ljava/lang/String;
      //   1884: invokestatic w : (Ljava/lang/String;Ljava/lang/String;)I
      //   1887: pop
      //   1888: goto -> 1924
      //   1891: aload_0
      //   1892: aload #8
      //   1894: iload #7
      //   1896: aload_0
      //   1897: getfield i0 : Z
      //   1900: invokevirtual getBoolean : (IZ)Z
      //   1903: putfield i0 : Z
      //   1906: goto -> 1924
      //   1909: aload_0
      //   1910: aload #8
      //   1912: iload #7
      //   1914: aload_0
      //   1915: getfield h0 : Z
      //   1918: invokevirtual getBoolean : (IZ)Z
      //   1921: putfield h0 : Z
      //   1924: iload_3
      //   1925: iconst_1
      //   1926: iadd
      //   1927: istore_3
      //   1928: goto -> 24
      //   1931: aload #8
      //   1933: invokevirtual recycle : ()V
      //   1936: return
    }
  }
  
  public static class c {
    public static SparseIntArray h;
    
    public boolean a = false;
    
    public int b = -1;
    
    public String c = null;
    
    public int d = -1;
    
    public int e = 0;
    
    public float f = Float.NaN;
    
    public float g = Float.NaN;
    
    static {
      SparseIntArray sparseIntArray = new SparseIntArray();
      h = sparseIntArray;
      sparseIntArray.append(2, 1);
      h.append(4, 2);
      h.append(5, 3);
      h.append(1, 4);
      h.append(0, 5);
      h.append(3, 6);
    }
    
    public void a(Context param1Context, AttributeSet param1AttributeSet) {
      TypedArray typedArray = param1Context.obtainStyledAttributes(param1AttributeSet, u5.b.m);
      this.a = true;
      int j = typedArray.getIndexCount();
      for (int i = 0; i < j; i++) {
        int[] arrayOfInt;
        String str;
        int k;
        int m;
        int n = typedArray.getIndex(i);
        switch (h.get(n)) {
          case 6:
            this.f = typedArray.getFloat(n, this.f);
            break;
          case 5:
            k = this.b;
            arrayOfInt = b.d;
            m = typedArray.getResourceId(n, k);
            k = m;
            if (m == -1)
              k = typedArray.getInt(n, -1); 
            this.b = k;
            break;
          case 4:
            this.e = typedArray.getInt(n, 0);
            break;
          case 3:
            if ((typedArray.peekValue(n)).type == 3) {
              str = typedArray.getString(n);
            } else {
              str = k6.k[typedArray.getInteger(n, 0)];
            } 
            this.c = str;
            break;
          case 2:
            this.d = typedArray.getInt(n, this.d);
            break;
          case 1:
            this.g = typedArray.getFloat(n, this.g);
            break;
        } 
      } 
      typedArray.recycle();
    }
  }
  
  public static class d {
    public boolean a = false;
    
    public int b = 0;
    
    public int c = 0;
    
    public float d = 1.0F;
    
    public float e = Float.NaN;
    
    public void a(Context param1Context, AttributeSet param1AttributeSet) {
      TypedArray typedArray = param1Context.obtainStyledAttributes(param1AttributeSet, u5.b.n);
      this.a = true;
      int j = typedArray.getIndexCount();
      for (int i = 0; i < j; i++) {
        int k = typedArray.getIndex(i);
        if (k == 1) {
          this.d = typedArray.getFloat(k, this.d);
        } else if (k == 0) {
          k = typedArray.getInt(k, this.b);
          this.b = k;
          int[] arrayOfInt = b.d;
          this.b = b.d[k];
        } else if (k == 4) {
          this.c = typedArray.getInt(k, this.c);
        } else if (k == 3) {
          this.e = typedArray.getFloat(k, this.e);
        } 
      } 
      typedArray.recycle();
    }
  }
  
  public static class e {
    public static SparseIntArray n;
    
    public boolean a = false;
    
    public float b = 0.0F;
    
    public float c = 0.0F;
    
    public float d = 0.0F;
    
    public float e = 1.0F;
    
    public float f = 1.0F;
    
    public float g = Float.NaN;
    
    public float h = Float.NaN;
    
    public float i = 0.0F;
    
    public float j = 0.0F;
    
    public float k = 0.0F;
    
    public boolean l = false;
    
    public float m = 0.0F;
    
    static {
      SparseIntArray sparseIntArray = new SparseIntArray();
      n = sparseIntArray;
      sparseIntArray.append(6, 1);
      n.append(7, 2);
      n.append(8, 3);
      n.append(4, 4);
      n.append(5, 5);
      n.append(0, 6);
      n.append(1, 7);
      n.append(2, 8);
      n.append(3, 9);
      n.append(9, 10);
      n.append(10, 11);
    }
    
    public void a(Context param1Context, AttributeSet param1AttributeSet) {
      TypedArray typedArray = param1Context.obtainStyledAttributes(param1AttributeSet, u5.b.p);
      this.a = true;
      int j = typedArray.getIndexCount();
      for (int i = 0; i < j; i++) {
        int k = typedArray.getIndex(i);
        switch (n.get(k)) {
          case 11:
            this.l = true;
            this.m = typedArray.getDimension(k, this.m);
            break;
          case 10:
            this.k = typedArray.getDimension(k, this.k);
            break;
          case 9:
            this.j = typedArray.getDimension(k, this.j);
            break;
          case 8:
            this.i = typedArray.getDimension(k, this.i);
            break;
          case 7:
            this.h = typedArray.getDimension(k, this.h);
            break;
          case 6:
            this.g = typedArray.getDimension(k, this.g);
            break;
          case 5:
            this.f = typedArray.getFloat(k, this.f);
            break;
          case 4:
            this.e = typedArray.getFloat(k, this.e);
            break;
          case 3:
            this.d = typedArray.getFloat(k, this.d);
            break;
          case 2:
            this.c = typedArray.getFloat(k, this.c);
            break;
          case 1:
            this.b = typedArray.getFloat(k, this.b);
            break;
        } 
      } 
      typedArray.recycle();
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Luxury Logo Maker_ Logo Design-dex2jar.jar!\androidx\constraintlayout\widget\b.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */