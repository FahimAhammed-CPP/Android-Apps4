package androidx.constraintlayout.widget;

import android.content.Context;
import android.content.res.TypedArray;
import android.util.AttributeSet;
import android.view.View;
import android.view.ViewGroup;
import java.util.Objects;
import u5.b;

public class c extends ViewGroup {
  public b h;
  
  public ViewGroup.LayoutParams generateDefaultLayoutParams() {
    return (ViewGroup.LayoutParams)new a(-2, -2);
  }
  
  public ViewGroup.LayoutParams generateLayoutParams(AttributeSet paramAttributeSet) {
    return (ViewGroup.LayoutParams)new a(getContext(), paramAttributeSet);
  }
  
  public ViewGroup.LayoutParams generateLayoutParams(ViewGroup.LayoutParams paramLayoutParams) {
    return (ViewGroup.LayoutParams)new ConstraintLayout.a(paramLayoutParams);
  }
  
  public b getConstraintSet() {
    if (this.h == null)
      this.h = new b(); 
    b b1 = this.h;
    Objects.requireNonNull(b1);
    int j = getChildCount();
    b1.c.clear();
    int i = 0;
    while (i < j) {
      View view = getChildAt(i);
      a a = (a)view.getLayoutParams();
      int k = view.getId();
      if (!b1.b || k != -1) {
        if (!b1.c.containsKey(Integer.valueOf(k)))
          b1.c.put(Integer.valueOf(k), new b.a()); 
        b.a a1 = b1.c.get(Integer.valueOf(k));
        if (view instanceof a) {
          a a2 = (a)view;
          a1.c(k, a);
          if (a2 instanceof Barrier) {
            b.b b2 = a1.d;
            b2.d0 = 1;
            a2 = a2;
            b2.b0 = a2.getType();
            a1.d.e0 = a2.getReferencedIds();
            a1.d.c0 = a2.getMargin();
          } 
        } 
        a1.c(k, a);
        i++;
        continue;
      } 
      throw new RuntimeException("All children of ConstraintLayout must have ids to use ConstraintSet");
    } 
    return this.h;
  }
  
  public void onLayout(boolean paramBoolean, int paramInt1, int paramInt2, int paramInt3, int paramInt4) {}
  
  public static class a extends ConstraintLayout.a {
    public float m0 = 1.0F;
    
    public boolean n0;
    
    public float o0;
    
    public float p0;
    
    public float q0;
    
    public float r0;
    
    public float s0;
    
    public float t0;
    
    public float u0;
    
    public float v0;
    
    public float w0;
    
    public float x0;
    
    public float y0;
    
    public a(int param1Int1, int param1Int2) {
      super(param1Int1, param1Int2);
      this.n0 = false;
      this.o0 = 0.0F;
      this.p0 = 0.0F;
      this.q0 = 0.0F;
      this.r0 = 0.0F;
      this.s0 = 1.0F;
      this.t0 = 1.0F;
      this.u0 = 0.0F;
      this.v0 = 0.0F;
      this.w0 = 0.0F;
      this.x0 = 0.0F;
      this.y0 = 0.0F;
    }
    
    public a(Context param1Context, AttributeSet param1AttributeSet) {
      super(param1Context, param1AttributeSet);
      int i = 0;
      this.n0 = false;
      this.o0 = 0.0F;
      this.p0 = 0.0F;
      this.q0 = 0.0F;
      this.r0 = 0.0F;
      this.s0 = 1.0F;
      this.t0 = 1.0F;
      this.u0 = 0.0F;
      this.v0 = 0.0F;
      this.w0 = 0.0F;
      this.x0 = 0.0F;
      this.y0 = 0.0F;
      TypedArray typedArray = param1Context.obtainStyledAttributes(param1AttributeSet, b.j);
      int j = typedArray.getIndexCount();
      while (i < j) {
        int k = typedArray.getIndex(i);
        if (k == 15) {
          this.m0 = typedArray.getFloat(k, this.m0);
        } else if (k == 28) {
          this.o0 = typedArray.getFloat(k, this.o0);
          this.n0 = true;
        } else if (k == 23) {
          this.q0 = typedArray.getFloat(k, this.q0);
        } else if (k == 24) {
          this.r0 = typedArray.getFloat(k, this.r0);
        } else if (k == 22) {
          this.p0 = typedArray.getFloat(k, this.p0);
        } else if (k == 20) {
          this.s0 = typedArray.getFloat(k, this.s0);
        } else if (k == 21) {
          this.t0 = typedArray.getFloat(k, this.t0);
        } else if (k == 16) {
          this.u0 = typedArray.getFloat(k, this.u0);
        } else if (k == 17) {
          this.v0 = typedArray.getFloat(k, this.v0);
        } else if (k == 18) {
          this.w0 = typedArray.getFloat(k, this.w0);
        } else if (k == 19) {
          this.x0 = typedArray.getFloat(k, this.x0);
        } else if (k == 27) {
          this.y0 = typedArray.getFloat(k, this.y0);
        } 
        i++;
      } 
      typedArray.recycle();
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Luxury Logo Maker_ Logo Design-dex2jar.jar!\androidx\constraintlayout\widget\c.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */