package androidx.constraintlayout.widget;

import android.content.Context;
import android.content.res.Resources;
import android.content.res.TypedArray;
import android.graphics.Canvas;
import android.support.v4.media.c;
import android.util.AttributeSet;
import android.util.Log;
import android.view.View;
import android.view.ViewGroup;
import android.view.ViewParent;
import java.util.Arrays;
import java.util.HashMap;
import u.d;
import u.g;
import u5.b;
import w.d;

public abstract class a extends View {
  public int[] h = new int[32];
  
  public int i;
  
  public Context j;
  
  public g k;
  
  public String l;
  
  public String m;
  
  public HashMap<Integer, String> n = new HashMap<Integer, String>();
  
  public a(Context paramContext) {
    super(paramContext);
    this.j = paramContext;
    f(null);
  }
  
  public a(Context paramContext, AttributeSet paramAttributeSet) {
    super(paramContext, paramAttributeSet);
    this.j = paramContext;
    f(paramAttributeSet);
  }
  
  public final void a(String paramString) {
    if (paramString != null) {
      if (paramString.length() == 0)
        return; 
      if (this.j == null)
        return; 
      String str = paramString.trim();
      if (getParent() instanceof ConstraintLayout)
        ConstraintLayout constraintLayout = (ConstraintLayout)getParent(); 
      if (getParent() instanceof ConstraintLayout) {
        ConstraintLayout constraintLayout = (ConstraintLayout)getParent();
      } else {
        paramString = null;
      } 
      boolean bool = isInEditMode();
      int i = 0;
      int j = i;
      if (bool) {
        j = i;
        if (paramString != null) {
          Object object = paramString.c(0, str);
          j = i;
          if (object instanceof Integer)
            j = ((Integer)object).intValue(); 
        } 
      } 
      i = j;
      if (j == 0) {
        i = j;
        if (paramString != null)
          i = e((ConstraintLayout)paramString, str); 
      } 
      j = i;
      if (i == 0)
        try {
          j = d.class.getField(str).getInt(null);
        } catch (Exception exception) {
          j = i;
        }  
      i = j;
      if (j == 0)
        i = this.j.getResources().getIdentifier(str, "id", this.j.getPackageName()); 
      if (i != 0) {
        this.n.put(Integer.valueOf(i), str);
        b(i);
        return;
      } 
      StringBuilder stringBuilder = new StringBuilder();
      stringBuilder.append("Could not find id of \"");
      stringBuilder.append(str);
      stringBuilder.append("\"");
      Log.w("ConstraintHelper", stringBuilder.toString());
    } 
  }
  
  public final void b(int paramInt) {
    if (paramInt == getId())
      return; 
    int i = this.i;
    int[] arrayOfInt = this.h;
    if (i + 1 > arrayOfInt.length)
      this.h = Arrays.copyOf(arrayOfInt, arrayOfInt.length * 2); 
    arrayOfInt = this.h;
    i = this.i;
    arrayOfInt[i] = paramInt;
    this.i = i + 1;
  }
  
  public final void c(String paramString) {
    if (paramString != null) {
      ConstraintLayout constraintLayout;
      if (paramString.length() == 0)
        return; 
      if (this.j == null)
        return; 
      String str = paramString.trim();
      paramString = null;
      if (getParent() instanceof ConstraintLayout)
        constraintLayout = (ConstraintLayout)getParent(); 
      if (constraintLayout == null) {
        Log.w("ConstraintHelper", "Parent not a ConstraintLayout");
        return;
      } 
      int j = constraintLayout.getChildCount();
      for (int i = 0; i < j; i++) {
        View view = constraintLayout.getChildAt(i);
        ViewGroup.LayoutParams layoutParams = view.getLayoutParams();
        if (layoutParams instanceof ConstraintLayout.a && str.equals(((ConstraintLayout.a)layoutParams).U))
          if (view.getId() == -1) {
            StringBuilder stringBuilder = c.a("to use ConstraintTag view ");
            stringBuilder.append(view.getClass().getSimpleName());
            stringBuilder.append(" must have an ID");
            Log.w("ConstraintHelper", stringBuilder.toString());
          } else {
            b(view.getId());
          }  
      } 
    } 
  }
  
  public void d() {
    ViewParent viewParent = getParent();
    if (viewParent != null && viewParent instanceof ConstraintLayout) {
      ConstraintLayout constraintLayout = (ConstraintLayout)viewParent;
      int j = getVisibility();
      float f = getElevation();
      for (int i = 0; i < this.i; i++) {
        View view = constraintLayout.d(this.h[i]);
        if (view != null) {
          view.setVisibility(j);
          if (f > 0.0F)
            view.setTranslationZ(view.getTranslationZ() + f); 
        } 
      } 
    } 
  }
  
  public final int e(ConstraintLayout paramConstraintLayout, String paramString) {
    if (paramString != null) {
      Resources resources = this.j.getResources();
      if (resources == null)
        return 0; 
      int j = paramConstraintLayout.getChildCount();
      int i = 0;
      while (true) {
        if (i < j) {
          View view = paramConstraintLayout.getChildAt(i);
          if (view.getId() != -1) {
            String str = null;
            try {
              String str1 = resources.getResourceEntryName(view.getId());
              str = str1;
            } catch (android.content.res.Resources.NotFoundException notFoundException) {}
            if (paramString.equals(str))
              return view.getId(); 
          } 
          i++;
          continue;
        } 
        return 0;
      } 
    } 
    return 0;
  }
  
  public void f(AttributeSet paramAttributeSet) {
    if (paramAttributeSet != null) {
      TypedArray typedArray = getContext().obtainStyledAttributes(paramAttributeSet, b.i);
      int j = typedArray.getIndexCount();
      for (int i = 0; i < j; i++) {
        int k = typedArray.getIndex(i);
        if (k == 19) {
          String str = typedArray.getString(k);
          this.l = str;
          setIds(str);
        } else if (k == 20) {
          String str = typedArray.getString(k);
          this.m = str;
          setReferenceTags(str);
        } 
      } 
      typedArray.recycle();
    } 
  }
  
  public void g(d paramd, boolean paramBoolean) {}
  
  public int[] getReferencedIds() {
    return Arrays.copyOf(this.h, this.i);
  }
  
  public void h() {
    if (this.k == null)
      return; 
    ViewGroup.LayoutParams layoutParams = getLayoutParams();
    if (layoutParams instanceof ConstraintLayout.a)
      ((ConstraintLayout.a)layoutParams).l0 = (d)this.k; 
  }
  
  public void onAttachedToWindow() {
    super.onAttachedToWindow();
    String str = this.l;
    if (str != null)
      setIds(str); 
    str = this.m;
    if (str != null)
      setReferenceTags(str); 
  }
  
  public void onDraw(Canvas paramCanvas) {}
  
  public void onMeasure(int paramInt1, int paramInt2) {
    setMeasuredDimension(0, 0);
  }
  
  public void setIds(String paramString) {
    this.l = paramString;
    if (paramString == null)
      return; 
    int i = 0;
    this.i = 0;
    while (true) {
      int j = paramString.indexOf(',', i);
      if (j == -1) {
        a(paramString.substring(i));
        return;
      } 
      a(paramString.substring(i, j));
      i = j + 1;
    } 
  }
  
  public void setReferenceTags(String paramString) {
    this.m = paramString;
    if (paramString == null)
      return; 
    int i = 0;
    this.i = 0;
    while (true) {
      int j = paramString.indexOf(',', i);
      if (j == -1) {
        c(paramString.substring(i));
        return;
      } 
      c(paramString.substring(i, j));
      i = j + 1;
    } 
  }
  
  public void setReferencedIds(int[] paramArrayOfint) {
    this.l = null;
    int i = 0;
    this.i = 0;
    while (i < paramArrayOfint.length) {
      b(paramArrayOfint[i]);
      i++;
    } 
  }
  
  public void setTag(int paramInt, Object paramObject) {
    super.setTag(paramInt, paramObject);
    if (paramObject == null && this.l == null)
      b(paramInt); 
  }
}


/* Location:              C:\soft\dex2jar-2.0\Luxury Logo Maker_ Logo Design-dex2jar.jar!\androidx\constraintlayout\widget\a.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */