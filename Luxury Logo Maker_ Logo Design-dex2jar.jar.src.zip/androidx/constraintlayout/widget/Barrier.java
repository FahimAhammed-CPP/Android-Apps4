package androidx.constraintlayout.widget;

import android.content.Context;
import android.content.res.TypedArray;
import android.util.AttributeSet;
import u.a;
import u.d;
import u.g;
import u5.b;

public class Barrier extends a {
  public int o;
  
  public int p;
  
  public a q;
  
  public Barrier(Context paramContext) {
    super(paramContext);
    setVisibility(8);
  }
  
  public Barrier(Context paramContext, AttributeSet paramAttributeSet) {
    super(paramContext, paramAttributeSet);
    setVisibility(8);
  }
  
  public void f(AttributeSet paramAttributeSet) {
    super.f(paramAttributeSet);
    this.q = new a();
    if (paramAttributeSet != null) {
      TypedArray typedArray = getContext().obtainStyledAttributes(paramAttributeSet, b.i);
      int j = typedArray.getIndexCount();
      for (int i = 0; i < j; i++) {
        int k = typedArray.getIndex(i);
        if (k == 15) {
          setType(typedArray.getInt(k, 0));
        } else if (k == 14) {
          this.q.o0 = typedArray.getBoolean(k, true);
        } else if (k == 16) {
          k = typedArray.getDimensionPixelSize(k, 0);
          this.q.p0 = k;
        } 
      } 
      typedArray.recycle();
    } 
    this.k = (g)this.q;
    h();
  }
  
  public void g(d paramd, boolean paramBoolean) {
    // Byte code:
    //   0: aload_0
    //   1: getfield o : I
    //   4: istore_3
    //   5: aload_0
    //   6: iload_3
    //   7: putfield p : I
    //   10: iload_2
    //   11: ifeq -> 31
    //   14: iload_3
    //   15: iconst_5
    //   16: if_icmpne -> 22
    //   19: goto -> 52
    //   22: iload_3
    //   23: bipush #6
    //   25: if_icmpne -> 57
    //   28: goto -> 36
    //   31: iload_3
    //   32: iconst_5
    //   33: if_icmpne -> 46
    //   36: iconst_0
    //   37: istore_3
    //   38: aload_0
    //   39: iload_3
    //   40: putfield p : I
    //   43: goto -> 57
    //   46: iload_3
    //   47: bipush #6
    //   49: if_icmpne -> 57
    //   52: iconst_1
    //   53: istore_3
    //   54: goto -> 38
    //   57: aload_1
    //   58: instanceof u/a
    //   61: ifeq -> 75
    //   64: aload_1
    //   65: checkcast u/a
    //   68: aload_0
    //   69: getfield p : I
    //   72: putfield n0 : I
    //   75: return
  }
  
  public int getMargin() {
    return this.q.p0;
  }
  
  public int getType() {
    return this.o;
  }
  
  public void setAllowsGoneWidget(boolean paramBoolean) {
    this.q.o0 = paramBoolean;
  }
  
  public void setDpMargin(int paramInt) {
    float f = (getResources().getDisplayMetrics()).density;
    paramInt = (int)(paramInt * f + 0.5F);
    this.q.p0 = paramInt;
  }
  
  public void setMargin(int paramInt) {
    this.q.p0 = paramInt;
  }
  
  public void setType(int paramInt) {
    this.o = paramInt;
  }
}


/* Location:              C:\soft\dex2jar-2.0\Luxury Logo Maker_ Logo Design-dex2jar.jar!\androidx\constraintlayout\widget\Barrier.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */