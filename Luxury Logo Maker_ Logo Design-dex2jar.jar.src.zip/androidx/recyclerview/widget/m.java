package androidx.recyclerview.widget;

import android.annotation.SuppressLint;
import android.os.Trace;
import g0.g;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.Comparator;

public final class m implements Runnable {
  public static final ThreadLocal<m> l = new ThreadLocal<m>();
  
  public static Comparator<c> m = new a();
  
  public ArrayList<RecyclerView> h = new ArrayList<RecyclerView>();
  
  public long i;
  
  public long j;
  
  public ArrayList<c> k = new ArrayList<c>();
  
  public void a(RecyclerView paramRecyclerView, int paramInt1, int paramInt2) {
    if (paramRecyclerView.isAttachedToWindow() && this.i == 0L) {
      this.i = paramRecyclerView.getNanoTime();
      paramRecyclerView.post(this);
    } 
    b b = paramRecyclerView.m0;
    b.a = paramInt1;
    b.b = paramInt2;
  }
  
  public void b(long paramLong) {
    int k = this.h.size();
    int i = 0;
    int j;
    for (j = 0; i < k; j = n) {
      RecyclerView recyclerView = this.h.get(i);
      int n = j;
      if (recyclerView.getWindowVisibility() == 0) {
        recyclerView.m0.b(recyclerView, false);
        n = j + recyclerView.m0.d;
      } 
      i++;
    } 
    this.k.ensureCapacity(j);
    j = 0;
    for (i = 0; j < k; i = n) {
      int n;
      RecyclerView recyclerView = this.h.get(j);
      if (recyclerView.getWindowVisibility() != 0) {
        n = i;
      } else {
        b b = recyclerView.m0;
        int i1 = Math.abs(b.a);
        int i2 = Math.abs(b.b) + i1;
        i1 = 0;
        while (true) {
          n = i;
          if (i1 < b.d * 2) {
            boolean bool;
            c c;
            if (i >= this.k.size()) {
              c = new c();
              this.k.add(c);
            } else {
              c = this.k.get(i);
            } 
            int[] arrayOfInt = b.c;
            n = arrayOfInt[i1 + 1];
            if (n <= i2) {
              bool = true;
            } else {
              bool = false;
            } 
            c.a = bool;
            c.b = i2;
            c.c = n;
            c.d = recyclerView;
            c.e = arrayOfInt[i1];
            i++;
            i1 += 2;
            continue;
          } 
          break;
        } 
      } 
      j++;
    } 
    Collections.sort(this.k, m);
    for (i = 0; i < this.k.size(); i++) {
      long l;
      c c = this.k.get(i);
      RecyclerView recyclerView = c.d;
      if (recyclerView == null)
        return; 
      if (c.a) {
        l = Long.MAX_VALUE;
      } else {
        l = paramLong;
      } 
      RecyclerView.a0 a0 = c(recyclerView, c.e, l);
      if (a0 != null && a0.i != null && a0.t() && !a0.u()) {
        RecyclerView recyclerView1 = a0.i.get();
        if (recyclerView1 != null) {
          if (recyclerView1.J && recyclerView1.l.h() != 0)
            recyclerView1.Z(); 
          b b = recyclerView1.m0;
          b.b(recyclerView1, true);
          if (b.d != 0)
            try {
              j = g.a;
              Trace.beginSection("RV Nested Prefetch");
              RecyclerView.x x = recyclerView1.n0;
              RecyclerView.e e = recyclerView1.s;
              x.d = 1;
              x.e = e.a();
              x.g = false;
              x.h = false;
              x.i = false;
            } finally {
              i = g.a;
              Trace.endSection();
            }  
        } 
      } 
      c.a = false;
      c.b = 0;
      c.c = 0;
      c.d = null;
      c.e = 0;
    } 
  }
  
  public final RecyclerView.a0 c(RecyclerView paramRecyclerView, int paramInt, long paramLong) {
    int j = paramRecyclerView.l.h();
    int i = 0;
    while (true) {
      if (i < j) {
        RecyclerView.a0 a0 = RecyclerView.K(paramRecyclerView.l.g(i));
        if (a0.j == paramInt && !a0.u()) {
          i = 1;
          break;
        } 
        i++;
        continue;
      } 
      i = 0;
      break;
    } 
    if (i != 0)
      return null; 
    null = paramRecyclerView.i;
    try {
      paramRecyclerView.S();
      RecyclerView.a0 a0 = null.j(paramInt, false, paramLong);
      if (a0 != null)
        if (a0.t() && !a0.u()) {
          null.g(a0.h);
        } else {
          null.a(a0, false);
        }  
      return a0;
    } finally {
      paramRecyclerView.T(false);
    } 
  }
  
  public void run() {
    try {
      int i = g.a;
      Trace.beginSection("RV Prefetch");
      boolean bool = this.h.isEmpty();
      if (bool)
        return; 
      int j = this.h.size();
      i = 0;
      long l;
      for (l = 0L; i < j; l = l1) {
        RecyclerView recyclerView = this.h.get(i);
        long l1 = l;
        if (recyclerView.getWindowVisibility() == 0)
          l1 = Math.max(recyclerView.getDrawingTime(), l); 
        i++;
      } 
      if (l == 0L)
        return; 
      return;
    } finally {
      this.i = 0L;
      int i = g.a;
      Trace.endSection();
    } 
  }
  
  public class a implements Comparator<c> {
    public int compare(Object param1Object1, Object param1Object2) {
      int i;
      param1Object1 = param1Object1;
      param1Object2 = param1Object2;
      RecyclerView recyclerView = ((m.c)param1Object1).d;
      byte b = 1;
      boolean bool = false;
      if (recyclerView == null) {
        null = 1;
      } else {
        null = 0;
      } 
      if (((m.c)param1Object2).d == null) {
        i = 1;
      } else {
        i = 0;
      } 
      if (null != i) {
        if (recyclerView == null)
          return b; 
      } else {
        boolean bool1 = ((m.c)param1Object1).a;
        if (bool1 != ((m.c)param1Object2).a) {
          null = b;
          return bool1 ? -1 : null;
        } 
        null = ((m.c)param1Object2).b - ((m.c)param1Object1).b;
        if (null != 0)
          return null; 
        i = ((m.c)param1Object1).c - ((m.c)param1Object2).c;
        null = bool;
        if (i != 0)
          null = i; 
        return null;
      } 
      return -1;
    }
  }
  
  @SuppressLint({"VisibleForTests"})
  public static class b implements RecyclerView.m.c {
    public int a;
    
    public int b;
    
    public int[] c;
    
    public int d;
    
    public void a(int param1Int1, int param1Int2) {
      if (param1Int1 >= 0) {
        if (param1Int2 >= 0) {
          int i = this.d * 2;
          int[] arrayOfInt = this.c;
          if (arrayOfInt == null) {
            arrayOfInt = new int[4];
            this.c = arrayOfInt;
            Arrays.fill(arrayOfInt, -1);
          } else if (i >= arrayOfInt.length) {
            int[] arrayOfInt1 = new int[i * 2];
            this.c = arrayOfInt1;
            System.arraycopy(arrayOfInt, 0, arrayOfInt1, 0, arrayOfInt.length);
          } 
          arrayOfInt = this.c;
          arrayOfInt[i] = param1Int1;
          arrayOfInt[i + 1] = param1Int2;
          this.d++;
          return;
        } 
        throw new IllegalArgumentException("Pixel distance must be non-negative");
      } 
      throw new IllegalArgumentException("Layout positions must be non-negative");
    }
    
    public void b(RecyclerView param1RecyclerView, boolean param1Boolean) {
      this.d = 0;
      int[] arrayOfInt = this.c;
      if (arrayOfInt != null)
        Arrays.fill(arrayOfInt, -1); 
      RecyclerView.m m = param1RecyclerView.t;
      if (param1RecyclerView.s != null && m != null && m.i) {
        if (param1Boolean) {
          if (!param1RecyclerView.k.g())
            m.j(param1RecyclerView.s.a(), this); 
        } else if (!param1RecyclerView.M()) {
          m.i(this.a, this.b, param1RecyclerView.n0, this);
        } 
        int i = this.d;
        if (i > m.j) {
          m.j = i;
          m.k = param1Boolean;
          param1RecyclerView.i.l();
        } 
      } 
    }
    
    public boolean c(int param1Int) {
      if (this.c != null) {
        int j = this.d;
        for (int i = 0; i < j * 2; i += 2) {
          if (this.c[i] == param1Int)
            return true; 
        } 
      } 
      return false;
    }
  }
  
  public static class c {
    public boolean a;
    
    public int b;
    
    public int c;
    
    public RecyclerView d;
    
    public int e;
  }
}


/* Location:              C:\soft\dex2jar-2.0\Luxury Logo Maker_ Logo Design-dex2jar.jar!\androidx\recyclerview\widget\m.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */