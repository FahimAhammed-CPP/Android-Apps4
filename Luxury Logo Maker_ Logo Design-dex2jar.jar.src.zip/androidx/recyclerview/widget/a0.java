package androidx.recyclerview.widget;

import android.view.View;

public abstract class a0 extends RecyclerView.o {
  public RecyclerView a;
  
  public final RecyclerView.q b = new a(this);
  
  public abstract int[] a(RecyclerView.m paramm, View paramView);
  
  public void b() {
    RecyclerView recyclerView = this.a;
    if (recyclerView == null)
      return; 
    RecyclerView.m m = recyclerView.getLayoutManager();
    if (m == null)
      return; 
    u u = (u)this;
    if (m.f()) {
      s s = u.f(m);
    } else if (m.e()) {
      s s = u.e(m);
    } else {
      recyclerView = null;
      if (recyclerView == null)
        return; 
    } 
    View view = u.d(m, (s)recyclerView);
    if (view == null)
      return; 
  }
  
  public class a extends RecyclerView.q {
    public boolean a = false;
    
    public a(a0 this$0) {}
    
    public void a(RecyclerView param1RecyclerView, int param1Int) {
      if (param1Int == 0 && this.a) {
        this.a = false;
        this.b.b();
      } 
    }
    
    public void b(RecyclerView param1RecyclerView, int param1Int1, int param1Int2) {
      if (param1Int1 != 0 || param1Int2 != 0)
        this.a = true; 
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Luxury Logo Maker_ Logo Design-dex2jar.jar!\androidx\recyclerview\widget\a0.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */