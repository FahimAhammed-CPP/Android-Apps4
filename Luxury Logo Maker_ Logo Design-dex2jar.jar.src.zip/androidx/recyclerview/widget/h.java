package androidx.recyclerview.widget;

import android.animation.Animator;
import android.animation.AnimatorListenerAdapter;
import android.view.View;
import android.view.ViewPropertyAnimator;
import java.util.Objects;

public class h extends AnimatorListenerAdapter {
  public h(k paramk, RecyclerView.a0 parama0, int paramInt1, View paramView, int paramInt2, ViewPropertyAnimator paramViewPropertyAnimator) {}
  
  public void onAnimationCancel(Animator paramAnimator) {
    if (this.b != 0)
      this.c.setTranslationX(0.0F); 
    if (this.d != 0)
      this.c.setTranslationY(0.0F); 
  }
  
  public void onAnimationEnd(Animator paramAnimator) {
    this.e.setListener(null);
    this.f.c(this.a);
    this.f.p.remove(this.a);
    this.f.k();
  }
  
  public void onAnimationStart(Animator paramAnimator) {
    Objects.requireNonNull(this.f);
  }
}


/* Location:              C:\soft\dex2jar-2.0\Luxury Logo Maker_ Logo Design-dex2jar.jar!\androidx\recyclerview\widget\h.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */