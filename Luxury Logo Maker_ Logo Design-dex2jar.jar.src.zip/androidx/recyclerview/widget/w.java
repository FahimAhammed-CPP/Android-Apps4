package androidx.recyclerview.widget;

import android.view.View;

public class w implements a.a {
  public w(RecyclerView paramRecyclerView) {}
  
  public void a(a.b paramb) {
    int i = paramb.a;
    if (i != 1) {
      if (i != 2) {
        if (i != 4) {
          if (i != 8)
            return; 
          RecyclerView recyclerView3 = this.a;
          recyclerView3.t.h0(recyclerView3, paramb.b, paramb.d, 1);
          return;
        } 
        RecyclerView recyclerView2 = this.a;
        recyclerView2.t.j0(recyclerView2, paramb.b, paramb.d, paramb.c);
        return;
      } 
      RecyclerView recyclerView1 = this.a;
      recyclerView1.t.i0(recyclerView1, paramb.b, paramb.d);
      return;
    } 
    RecyclerView recyclerView = this.a;
    recyclerView.t.f0(recyclerView, paramb.b, paramb.d);
  }
  
  public RecyclerView.a0 b(int paramInt) {
    RecyclerView.a0 a02;
    RecyclerView recyclerView = this.a;
    int j = recyclerView.l.h();
    int i = 0;
    RecyclerView.a0 a01 = null;
    while (true) {
      a02 = a01;
      if (i < j) {
        a02 = RecyclerView.K(recyclerView.l.g(i));
        RecyclerView.a0 a0 = a01;
        if (a02 != null) {
          a0 = a01;
          if (!a02.w())
            if (a02.j != paramInt) {
              a0 = a01;
            } else if (recyclerView.l.k(a02.h)) {
              a0 = a02;
            } else {
              break;
            }  
        } 
        i++;
        a01 = a0;
        continue;
      } 
      break;
    } 
    return (a02 == null) ? null : (this.a.l.k(a02.h) ? null : a02);
  }
  
  public void c(int paramInt1, int paramInt2, Object paramObject) {
    RecyclerView recyclerView = this.a;
    int i = recyclerView.l.h();
    int j = paramInt2 + paramInt1;
    for (paramInt2 = 0; paramInt2 < i; paramInt2++) {
      View view = recyclerView.l.g(paramInt2);
      RecyclerView.a0 a0 = RecyclerView.K(view);
      if (a0 != null && !a0.E()) {
        int k = a0.j;
        if (k >= paramInt1 && k < j) {
          a0.b(2);
          a0.a(paramObject);
          ((RecyclerView.n)view.getLayoutParams()).c = true;
        } 
      } 
    } 
    paramObject = recyclerView.i;
    paramInt2 = ((RecyclerView.s)paramObject).c.size();
    while (true) {
      i = paramInt2 - 1;
      if (i >= 0) {
        RecyclerView.a0 a0 = ((RecyclerView.s)paramObject).c.get(i);
        if (a0 == null) {
          paramInt2 = i;
          continue;
        } 
        int k = a0.j;
        paramInt2 = i;
        if (k >= paramInt1) {
          paramInt2 = i;
          if (k < j) {
            a0.b(2);
            paramObject.f(i);
            paramInt2 = i;
          } 
        } 
        continue;
      } 
      this.a.r0 = true;
      return;
    } 
  }
  
  public void d(int paramInt1, int paramInt2) {
    RecyclerView recyclerView = this.a;
    int j = recyclerView.l.h();
    boolean bool = false;
    int i;
    for (i = 0; i < j; i++) {
      RecyclerView.a0 a0 = RecyclerView.K(recyclerView.l.g(i));
      if (a0 != null && !a0.E() && a0.j >= paramInt1) {
        a0.A(paramInt2, false);
        recyclerView.n0.f = true;
      } 
    } 
    RecyclerView.s s = recyclerView.i;
    j = s.c.size();
    for (i = bool; i < j; i++) {
      RecyclerView.a0 a0 = s.c.get(i);
      if (a0 != null && a0.j >= paramInt1)
        a0.A(paramInt2, true); 
    } 
    recyclerView.requestLayout();
    this.a.q0 = true;
  }
  
  public void e(int paramInt1, int paramInt2) {
    int i;
    int j;
    int k;
    RecyclerView recyclerView = this.a;
    int i1 = recyclerView.l.h();
    int n = -1;
    if (paramInt1 < paramInt2) {
      i = paramInt1;
      j = paramInt2;
      k = -1;
    } else {
      j = paramInt1;
      i = paramInt2;
      k = 1;
    } 
    int m;
    for (m = 0; m < i1; m++) {
      RecyclerView.a0 a0 = RecyclerView.K(recyclerView.l.g(m));
      if (a0 != null) {
        int i2 = a0.j;
        if (i2 >= i && i2 <= j) {
          if (i2 == paramInt1) {
            a0.A(paramInt2 - paramInt1, false);
          } else {
            a0.A(k, false);
          } 
          recyclerView.n0.f = true;
        } 
      } 
    } 
    RecyclerView.s s = recyclerView.i;
    if (paramInt1 < paramInt2) {
      j = paramInt1;
      k = paramInt2;
      i = n;
    } else {
      k = paramInt1;
      j = paramInt2;
      i = 1;
    } 
    n = s.c.size();
    for (m = 0; m < n; m++) {
      RecyclerView.a0 a0 = s.c.get(m);
      if (a0 != null) {
        i1 = a0.j;
        if (i1 >= j && i1 <= k)
          if (i1 == paramInt1) {
            a0.A(paramInt2 - paramInt1, false);
          } else {
            a0.A(i, false);
          }  
      } 
    } 
    recyclerView.requestLayout();
    this.a.q0 = true;
  }
}


/* Location:              C:\soft\dex2jar-2.0\Luxury Logo Maker_ Logo Design-dex2jar.jar!\androidx\recyclerview\widget\w.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */