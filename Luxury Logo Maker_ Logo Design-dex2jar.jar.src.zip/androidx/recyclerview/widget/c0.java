package androidx.recyclerview.widget;

import j0.c;
import j0.d;
import r.d;
import r.g;

public class c0 {
  public final g<RecyclerView.a0, a> a = new g();
  
  public final d<RecyclerView.a0> b = new d();
  
  public void a(RecyclerView.a0 parama0) {
    a a2 = (a)this.a.getOrDefault(parama0, null);
    a a1 = a2;
    if (a2 == null) {
      a1 = a.a();
      this.a.put(parama0, a1);
    } 
    a1.a |= 0x1;
  }
  
  public void b(RecyclerView.a0 parama0, RecyclerView.j.c paramc) {
    a a2 = (a)this.a.getOrDefault(parama0, null);
    a a1 = a2;
    if (a2 == null) {
      a1 = a.a();
      this.a.put(parama0, a1);
    } 
    a1.c = paramc;
    a1.a |= 0x8;
  }
  
  public void c(RecyclerView.a0 parama0, RecyclerView.j.c paramc) {
    a a2 = (a)this.a.getOrDefault(parama0, null);
    a a1 = a2;
    if (a2 == null) {
      a1 = a.a();
      this.a.put(parama0, a1);
    } 
    a1.b = paramc;
    a1.a |= 0x4;
  }
  
  public boolean d(RecyclerView.a0 parama0) {
    a a = (a)this.a.getOrDefault(parama0, null);
    return (a != null && (a.a & 0x1) != 0);
  }
  
  public final RecyclerView.j.c e(RecyclerView.a0 parama0, int paramInt) {
    int i = this.a.e(parama0);
    if (i < 0)
      return null; 
    a a = (a)this.a.l(i);
    if (a != null) {
      int j = a.a;
      if ((j & paramInt) != 0) {
        RecyclerView.j.c c;
        j = paramInt & j;
        a.a = j;
        if (paramInt == 4) {
          c = a.b;
        } else if (paramInt == 8) {
          c = a.c;
        } else {
          throw new IllegalArgumentException("Must provide flag PRE or POST");
        } 
        if ((j & 0xC) == 0) {
          this.a.j(i);
          a.b(a);
        } 
        return c;
      } 
    } 
    return null;
  }
  
  public void f(RecyclerView.a0 parama0) {
    a a = (a)this.a.getOrDefault(parama0, null);
    if (a == null)
      return; 
    a.a &= 0xFFFFFFFE;
  }
  
  public void g(RecyclerView.a0 parama0) {
    for (int i = this.b.h() - 1; i >= 0; i--) {
      if (parama0 == this.b.i(i)) {
        d<RecyclerView.a0> d1 = this.b;
        Object[] arrayOfObject = d1.j;
        Object object1 = arrayOfObject[i];
        Object object2 = d.l;
        if (object1 != object2) {
          arrayOfObject[i] = object2;
          d1.h = true;
        } 
        break;
      } 
    } 
    a a = (a)this.a.remove(parama0);
    if (a != null)
      a.b(a); 
  }
  
  public static class a {
    public static c<a> d = (c<a>)new d(20);
    
    public int a;
    
    public RecyclerView.j.c b;
    
    public RecyclerView.j.c c;
    
    public static a a() {
      a a2 = (a)((d)d).b();
      a a1 = a2;
      if (a2 == null)
        a1 = new a(); 
      return a1;
    }
    
    public static void b(a param1a) {
      param1a.a = 0;
      param1a.b = null;
      param1a.c = null;
      ((d)d).a(param1a);
    }
  }
  
  public static interface b {}
}


/* Location:              C:\soft\dex2jar-2.0\Luxury Logo Maker_ Logo Design-dex2jar.jar!\androidx\recyclerview\widget\c0.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */