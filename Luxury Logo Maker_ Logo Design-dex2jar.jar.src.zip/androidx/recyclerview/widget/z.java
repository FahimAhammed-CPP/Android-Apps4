package androidx.recyclerview.widget;

public abstract class z extends RecyclerView.j {
  public boolean g = true;
  
  public boolean a(RecyclerView.a0 parama01, RecyclerView.a0 parama02, RecyclerView.j.c paramc1, RecyclerView.j.c paramc2) {
    int i;
    int m;
    int n = paramc1.a;
    int i1 = paramc1.b;
    if (parama02.E()) {
      i = paramc1.a;
      m = paramc1.b;
    } else {
      i = paramc2.a;
      m = paramc2.b;
    } 
    k k = (k)this;
    if (parama01 == parama02)
      return k.i(parama01, n, i1, i, m); 
    float f1 = parama01.h.getTranslationX();
    float f2 = parama01.h.getTranslationY();
    float f3 = parama01.h.getAlpha();
    k.n(parama01);
    int i2 = (int)((i - n) - f1);
    int i3 = (int)((m - i1) - f2);
    parama01.h.setTranslationX(f1);
    parama01.h.setTranslationY(f2);
    parama01.h.setAlpha(f3);
    k.n(parama02);
    parama02.h.setTranslationX(-i2);
    parama02.h.setTranslationY(-i3);
    parama02.h.setAlpha(0.0F);
    k.k.add(new k.a(parama01, parama02, n, i1, i, m));
    return true;
  }
  
  public abstract boolean i(RecyclerView.a0 parama0, int paramInt1, int paramInt2, int paramInt3, int paramInt4);
}


/* Location:              C:\soft\dex2jar-2.0\Luxury Logo Maker_ Logo Design-dex2jar.jar!\androidx\recyclerview\widget\z.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */