package androidx.recyclerview.widget;

import android.animation.Animator;
import android.view.View;
import android.view.ViewPropertyAnimator;
import java.util.ArrayList;
import java.util.Objects;

public class e implements Runnable {
  public e(k paramk, ArrayList paramArrayList) {}
  
  public void run() {
    for (RecyclerView.a0 a0 : this.h) {
      k k1 = this.i;
      Objects.requireNonNull(k1);
      View view = a0.h;
      ViewPropertyAnimator viewPropertyAnimator = view.animate();
      k1.o.add(a0);
      viewPropertyAnimator.alpha(1.0F).setDuration(k1.c).setListener((Animator.AnimatorListener)new g(k1, a0, view, viewPropertyAnimator)).start();
    } 
    this.h.clear();
    this.i.l.remove(this.h);
  }
}


/* Location:              C:\soft\dex2jar-2.0\Luxury Logo Maker_ Logo Design-dex2jar.jar!\androidx\recyclerview\widget\e.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */