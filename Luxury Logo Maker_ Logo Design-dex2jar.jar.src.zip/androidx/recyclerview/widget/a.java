package androidx.recyclerview.widget;

import j0.c;
import j0.d;
import java.util.ArrayList;
import java.util.List;

public final class a implements p.a {
  public c<b> a = (c<b>)new d(30);
  
  public final ArrayList<b> b = new ArrayList<b>();
  
  public final ArrayList<b> c = new ArrayList<b>();
  
  public final a d;
  
  public final p e;
  
  public int f = 0;
  
  public a(a parama) {
    this.d = parama;
    this.e = new p(this);
  }
  
  public final boolean a(int paramInt) {
    int j = this.c.size();
    for (int i = 0; i < j; i++) {
      b b = this.c.get(i);
      int k = b.a;
      if (k == 8) {
        if (f(b.d, i + 1) == paramInt)
          return true; 
      } else if (k == 1) {
        int m = b.b;
        int n = b.d;
        for (k = m; k < n + m; k++) {
          if (f(k, i + 1) == paramInt)
            return true; 
        } 
      } 
    } 
    return false;
  }
  
  public void b() {
    int j = this.c.size();
    for (int i = 0; i < j; i++) {
      a a1 = this.d;
      b b = this.c.get(i);
      ((w)a1).a(b);
    } 
    l(this.c);
    this.f = 0;
  }
  
  public void c() {
    b();
    int j = this.b.size();
    for (int i = 0; i < j; i++) {
      Object object = this.b.get(i);
      int k = ((b)object).a;
      if (k != 1) {
        if (k != 2) {
          if (k != 4) {
            if (k == 8) {
              ((w)this.d).a((b)object);
              a a1 = this.d;
              k = ((b)object).b;
              int m = ((b)object).d;
              ((w)a1).e(k, m);
            } 
          } else {
            ((w)this.d).a((b)object);
            a a1 = this.d;
            k = ((b)object).b;
            int m = ((b)object).d;
            object = ((b)object).c;
            ((w)a1).c(k, m, object);
          } 
        } else {
          ((w)this.d).a((b)object);
          a a1 = this.d;
          k = ((b)object).b;
          int m = ((b)object).d;
          object = a1;
          ((w)object).a.R(k, m, true);
          object = ((w)object).a;
          ((RecyclerView)object).q0 = true;
          object = ((RecyclerView)object).n0;
          ((RecyclerView.x)object).c += m;
        } 
      } else {
        ((w)this.d).a((b)object);
        a a1 = this.d;
        k = ((b)object).b;
        int m = ((b)object).d;
        ((w)a1).d(k, m);
      } 
    } 
    l(this.b);
    this.f = 0;
  }
  
  public final void d(b paramb) {
    int i = paramb.a;
    if (i != 1 && i != 8) {
      byte b1;
      int k = m(paramb.b, i);
      i = paramb.b;
      int j = paramb.a;
      if (j != 2) {
        if (j == 4) {
          b1 = 1;
        } else {
          StringBuilder stringBuilder = new StringBuilder();
          stringBuilder.append("op should be remove or update.");
          stringBuilder.append(paramb);
          throw new IllegalArgumentException(stringBuilder.toString());
        } 
      } else {
        b1 = 0;
      } 
      int m = 1;
      j = 1;
      while (m < paramb.d) {
        int n;
        int i1 = m(b1 * m + paramb.b, paramb.a);
        int i2 = paramb.a;
        if ((i2 != 2) ? (i2 == 4 && i1 == k + 1) : (i1 == k)) {
          n = 1;
        } else {
          n = 0;
        } 
        if (n) {
          j++;
        } else {
          b b2 = h(i2, k, j, paramb.c);
          e(b2, i);
          k(b2);
          k = i;
          if (paramb.a == 4)
            k = i + j; 
          n = i1;
          j = 1;
          i = k;
          k = n;
        } 
        m++;
      } 
      Object object = paramb.c;
      k(paramb);
      if (j > 0) {
        paramb = h(paramb.a, k, j, object);
        e(paramb, i);
        k(paramb);
      } 
      return;
    } 
    throw new IllegalArgumentException("should not dispatch add or move for pre layout");
  }
  
  public void e(b paramb, int paramInt) {
    ((w)this.d).a(paramb);
    int i = paramb.a;
    if (i != 2) {
      if (i == 4) {
        a a2 = this.d;
        i = paramb.d;
        object = paramb.c;
        ((w)a2).c(paramInt, i, object);
        return;
      } 
      throw new IllegalArgumentException("only remove and update ops can be dispatched in first pass");
    } 
    a a1 = this.d;
    i = ((b)object).d;
    Object object = a1;
    ((w)object).a.R(paramInt, i, true);
    object = ((w)object).a;
    ((RecyclerView)object).q0 = true;
    object = ((RecyclerView)object).n0;
    ((RecyclerView.x)object).c += i;
  }
  
  public int f(int paramInt1, int paramInt2) {
    int j = this.c.size();
    int i = paramInt2;
    for (paramInt2 = paramInt1; i < j; paramInt2 = paramInt1) {
      b b = this.c.get(i);
      int k = b.a;
      if (k == 8) {
        paramInt1 = b.b;
        if (paramInt1 == paramInt2) {
          paramInt1 = b.d;
        } else {
          int m = paramInt2;
          if (paramInt1 < paramInt2)
            m = paramInt2 - 1; 
          paramInt1 = m;
          if (b.d <= m)
            paramInt1 = m + 1; 
        } 
      } else {
        int m = b.b;
        paramInt1 = paramInt2;
        if (m <= paramInt2)
          if (k == 2) {
            paramInt1 = b.d;
            if (paramInt2 < m + paramInt1)
              return -1; 
            paramInt1 = paramInt2 - paramInt1;
          } else {
            paramInt1 = paramInt2;
            if (k == 1)
              paramInt1 = paramInt2 + b.d; 
          }  
      } 
      i++;
    } 
    return paramInt2;
  }
  
  public boolean g() {
    return (this.b.size() > 0);
  }
  
  public b h(int paramInt1, int paramInt2, int paramInt3, Object paramObject) {
    b b = (b)this.a.b();
    if (b == null)
      return new b(paramInt1, paramInt2, paramInt3, paramObject); 
    b.a = paramInt1;
    b.b = paramInt2;
    b.d = paramInt3;
    b.c = paramObject;
    return b;
  }
  
  public final void i(b paramb) {
    Object object;
    this.c.add(paramb);
    int i = paramb.a;
    if (i != 1) {
      if (i != 2) {
        if (i != 4) {
          if (i == 8) {
            a a4 = this.d;
            i = paramb.b;
            int n = paramb.d;
            ((w)a4).e(i, n);
            return;
          } 
          StringBuilder stringBuilder = new StringBuilder();
          stringBuilder.append("Unknown update op type for ");
          stringBuilder.append(paramb);
          throw new IllegalArgumentException(stringBuilder.toString());
        } 
        a a3 = this.d;
        i = paramb.b;
        int m = paramb.d;
        object = paramb.c;
        ((w)a3).c(i, m, object);
        return;
      } 
      a a2 = this.d;
      i = ((b)object).b;
      int k = ((b)object).d;
      object = a2;
      ((w)object).a.R(i, k, false);
      ((w)object).a.q0 = true;
      return;
    } 
    a a1 = this.d;
    i = ((b)object).b;
    int j = ((b)object).d;
    ((w)a1).d(i, j);
  }
  
  public void j() {
    // Byte code:
    //   0: aload_0
    //   1: getfield e : Landroidx/recyclerview/widget/p;
    //   4: astore #14
    //   6: aload_0
    //   7: getfield b : Ljava/util/ArrayList;
    //   10: astore #15
    //   12: aload #14
    //   14: invokestatic requireNonNull : (Ljava/lang/Object;)Ljava/lang/Object;
    //   17: pop
    //   18: aload #15
    //   20: invokeinterface size : ()I
    //   25: iconst_1
    //   26: isub
    //   27: istore_1
    //   28: iconst_0
    //   29: istore_2
    //   30: iload_1
    //   31: iflt -> 75
    //   34: aload #15
    //   36: iload_1
    //   37: invokeinterface get : (I)Ljava/lang/Object;
    //   42: checkcast androidx/recyclerview/widget/a$b
    //   45: getfield a : I
    //   48: bipush #8
    //   50: if_icmpne -> 64
    //   53: iload_2
    //   54: istore_3
    //   55: iload_2
    //   56: ifeq -> 66
    //   59: iload_1
    //   60: istore_3
    //   61: goto -> 77
    //   64: iconst_1
    //   65: istore_3
    //   66: iload_1
    //   67: iconst_1
    //   68: isub
    //   69: istore_1
    //   70: iload_3
    //   71: istore_2
    //   72: goto -> 30
    //   75: iconst_m1
    //   76: istore_3
    //   77: aconst_null
    //   78: astore #12
    //   80: aconst_null
    //   81: astore #13
    //   83: iload_3
    //   84: iconst_m1
    //   85: if_icmpeq -> 1141
    //   88: iload_3
    //   89: iconst_1
    //   90: iadd
    //   91: istore #4
    //   93: aload #15
    //   95: iload_3
    //   96: invokeinterface get : (I)Ljava/lang/Object;
    //   101: checkcast androidx/recyclerview/widget/a$b
    //   104: astore #16
    //   106: aload #15
    //   108: iload #4
    //   110: invokeinterface get : (I)Ljava/lang/Object;
    //   115: checkcast androidx/recyclerview/widget/a$b
    //   118: astore #17
    //   120: aload #17
    //   122: getfield a : I
    //   125: istore_1
    //   126: iload_1
    //   127: iconst_1
    //   128: if_icmpeq -> 1014
    //   131: iload_1
    //   132: iconst_2
    //   133: if_icmpeq -> 414
    //   136: iload_1
    //   137: iconst_4
    //   138: if_icmpeq -> 144
    //   141: goto -> 18
    //   144: aload #16
    //   146: getfield d : I
    //   149: istore_1
    //   150: aload #17
    //   152: getfield b : I
    //   155: istore_2
    //   156: iload_1
    //   157: iload_2
    //   158: if_icmpge -> 172
    //   161: aload #17
    //   163: iload_2
    //   164: iconst_1
    //   165: isub
    //   166: putfield b : I
    //   169: goto -> 234
    //   172: aload #17
    //   174: getfield d : I
    //   177: istore #5
    //   179: iload_1
    //   180: iload_2
    //   181: iload #5
    //   183: iadd
    //   184: if_icmpge -> 234
    //   187: aload #17
    //   189: iload #5
    //   191: iconst_1
    //   192: isub
    //   193: putfield d : I
    //   196: aload #14
    //   198: getfield a : Landroidx/recyclerview/widget/p$a;
    //   201: astore #12
    //   203: aload #16
    //   205: getfield b : I
    //   208: istore_1
    //   209: aload #17
    //   211: getfield c : Ljava/lang/Object;
    //   214: astore #18
    //   216: aload #12
    //   218: checkcast androidx/recyclerview/widget/a
    //   221: iconst_4
    //   222: iload_1
    //   223: iconst_1
    //   224: aload #18
    //   226: invokevirtual h : (IIILjava/lang/Object;)Landroidx/recyclerview/widget/a$b;
    //   229: astore #12
    //   231: goto -> 237
    //   234: aconst_null
    //   235: astore #12
    //   237: aload #16
    //   239: getfield b : I
    //   242: istore_1
    //   243: aload #17
    //   245: getfield b : I
    //   248: istore_2
    //   249: iload_1
    //   250: iload_2
    //   251: if_icmpgt -> 265
    //   254: aload #17
    //   256: iload_2
    //   257: iconst_1
    //   258: iadd
    //   259: putfield b : I
    //   262: goto -> 325
    //   265: iload_2
    //   266: aload #17
    //   268: getfield d : I
    //   271: iadd
    //   272: istore_2
    //   273: iload_1
    //   274: iload_2
    //   275: if_icmpge -> 325
    //   278: iload_2
    //   279: iload_1
    //   280: isub
    //   281: istore_2
    //   282: aload #14
    //   284: getfield a : Landroidx/recyclerview/widget/p$a;
    //   287: astore #13
    //   289: aload #17
    //   291: getfield c : Ljava/lang/Object;
    //   294: astore #18
    //   296: aload #13
    //   298: checkcast androidx/recyclerview/widget/a
    //   301: iconst_4
    //   302: iload_1
    //   303: iconst_1
    //   304: iadd
    //   305: iload_2
    //   306: aload #18
    //   308: invokevirtual h : (IIILjava/lang/Object;)Landroidx/recyclerview/widget/a$b;
    //   311: astore #13
    //   313: aload #17
    //   315: aload #17
    //   317: getfield d : I
    //   320: iload_2
    //   321: isub
    //   322: putfield d : I
    //   325: aload #15
    //   327: iload #4
    //   329: aload #16
    //   331: invokeinterface set : (ILjava/lang/Object;)Ljava/lang/Object;
    //   336: pop
    //   337: aload #17
    //   339: getfield d : I
    //   342: ifle -> 359
    //   345: aload #15
    //   347: iload_3
    //   348: aload #17
    //   350: invokeinterface set : (ILjava/lang/Object;)Ljava/lang/Object;
    //   355: pop
    //   356: goto -> 381
    //   359: aload #15
    //   361: iload_3
    //   362: invokeinterface remove : (I)Ljava/lang/Object;
    //   367: pop
    //   368: aload #14
    //   370: getfield a : Landroidx/recyclerview/widget/p$a;
    //   373: checkcast androidx/recyclerview/widget/a
    //   376: aload #17
    //   378: invokevirtual k : (Landroidx/recyclerview/widget/a$b;)V
    //   381: aload #12
    //   383: ifnull -> 396
    //   386: aload #15
    //   388: iload_3
    //   389: aload #12
    //   391: invokeinterface add : (ILjava/lang/Object;)V
    //   396: aload #13
    //   398: ifnull -> 18
    //   401: aload #15
    //   403: iload_3
    //   404: aload #13
    //   406: invokeinterface add : (ILjava/lang/Object;)V
    //   411: goto -> 18
    //   414: aload #16
    //   416: getfield b : I
    //   419: istore_1
    //   420: aload #16
    //   422: getfield d : I
    //   425: istore #5
    //   427: aload #17
    //   429: getfield b : I
    //   432: istore #6
    //   434: iload_1
    //   435: iload #5
    //   437: if_icmpge -> 470
    //   440: iload #6
    //   442: iload_1
    //   443: if_icmpne -> 463
    //   446: aload #17
    //   448: getfield d : I
    //   451: iload #5
    //   453: iload_1
    //   454: isub
    //   455: if_icmpne -> 463
    //   458: iconst_0
    //   459: istore_1
    //   460: goto -> 493
    //   463: iconst_0
    //   464: istore_1
    //   465: iconst_0
    //   466: istore_2
    //   467: goto -> 504
    //   470: iload #6
    //   472: iload #5
    //   474: iconst_1
    //   475: iadd
    //   476: if_icmpne -> 500
    //   479: aload #17
    //   481: getfield d : I
    //   484: iload_1
    //   485: iload #5
    //   487: isub
    //   488: if_icmpne -> 500
    //   491: iconst_1
    //   492: istore_1
    //   493: iload_1
    //   494: istore_2
    //   495: iconst_1
    //   496: istore_1
    //   497: goto -> 504
    //   500: iconst_0
    //   501: istore_1
    //   502: iconst_1
    //   503: istore_2
    //   504: iload #5
    //   506: iload #6
    //   508: if_icmpge -> 523
    //   511: aload #17
    //   513: iload #6
    //   515: iconst_1
    //   516: isub
    //   517: putfield b : I
    //   520: goto -> 595
    //   523: aload #17
    //   525: getfield d : I
    //   528: istore #7
    //   530: iload #5
    //   532: iload #6
    //   534: iload #7
    //   536: iadd
    //   537: if_icmpge -> 595
    //   540: aload #17
    //   542: iload #7
    //   544: iconst_1
    //   545: isub
    //   546: putfield d : I
    //   549: aload #16
    //   551: iconst_2
    //   552: putfield a : I
    //   555: aload #16
    //   557: iconst_1
    //   558: putfield d : I
    //   561: aload #17
    //   563: getfield d : I
    //   566: ifne -> 18
    //   569: aload #15
    //   571: iload #4
    //   573: invokeinterface remove : (I)Ljava/lang/Object;
    //   578: pop
    //   579: aload #14
    //   581: getfield a : Landroidx/recyclerview/widget/p$a;
    //   584: checkcast androidx/recyclerview/widget/a
    //   587: aload #17
    //   589: invokevirtual k : (Landroidx/recyclerview/widget/a$b;)V
    //   592: goto -> 18
    //   595: aload #16
    //   597: getfield b : I
    //   600: istore #5
    //   602: aload #17
    //   604: getfield b : I
    //   607: istore #6
    //   609: iload #5
    //   611: iload #6
    //   613: if_icmpgt -> 628
    //   616: aload #17
    //   618: iload #6
    //   620: iconst_1
    //   621: iadd
    //   622: putfield b : I
    //   625: goto -> 685
    //   628: iload #6
    //   630: aload #17
    //   632: getfield d : I
    //   635: iadd
    //   636: istore #6
    //   638: iload #5
    //   640: iload #6
    //   642: if_icmpge -> 685
    //   645: aload #14
    //   647: getfield a : Landroidx/recyclerview/widget/p$a;
    //   650: checkcast androidx/recyclerview/widget/a
    //   653: iconst_2
    //   654: iload #5
    //   656: iconst_1
    //   657: iadd
    //   658: iload #6
    //   660: iload #5
    //   662: isub
    //   663: aconst_null
    //   664: invokevirtual h : (IIILjava/lang/Object;)Landroidx/recyclerview/widget/a$b;
    //   667: astore #12
    //   669: aload #17
    //   671: aload #16
    //   673: getfield b : I
    //   676: aload #17
    //   678: getfield b : I
    //   681: isub
    //   682: putfield d : I
    //   685: iload_1
    //   686: ifeq -> 726
    //   689: aload #15
    //   691: iload_3
    //   692: aload #17
    //   694: invokeinterface set : (ILjava/lang/Object;)Ljava/lang/Object;
    //   699: pop
    //   700: aload #15
    //   702: iload #4
    //   704: invokeinterface remove : (I)Ljava/lang/Object;
    //   709: pop
    //   710: aload #14
    //   712: getfield a : Landroidx/recyclerview/widget/p$a;
    //   715: checkcast androidx/recyclerview/widget/a
    //   718: aload #16
    //   720: invokevirtual k : (Landroidx/recyclerview/widget/a$b;)V
    //   723: goto -> 18
    //   726: iload_2
    //   727: ifeq -> 834
    //   730: aload #12
    //   732: ifnull -> 789
    //   735: aload #16
    //   737: getfield b : I
    //   740: istore_1
    //   741: iload_1
    //   742: aload #12
    //   744: getfield b : I
    //   747: if_icmple -> 762
    //   750: aload #16
    //   752: iload_1
    //   753: aload #12
    //   755: getfield d : I
    //   758: isub
    //   759: putfield b : I
    //   762: aload #16
    //   764: getfield d : I
    //   767: istore_1
    //   768: iload_1
    //   769: aload #12
    //   771: getfield b : I
    //   774: if_icmple -> 789
    //   777: aload #16
    //   779: iload_1
    //   780: aload #12
    //   782: getfield d : I
    //   785: isub
    //   786: putfield d : I
    //   789: aload #16
    //   791: getfield b : I
    //   794: istore_1
    //   795: iload_1
    //   796: aload #17
    //   798: getfield b : I
    //   801: if_icmple -> 816
    //   804: aload #16
    //   806: iload_1
    //   807: aload #17
    //   809: getfield d : I
    //   812: isub
    //   813: putfield b : I
    //   816: aload #16
    //   818: getfield d : I
    //   821: istore_1
    //   822: iload_1
    //   823: aload #17
    //   825: getfield b : I
    //   828: if_icmple -> 947
    //   831: goto -> 935
    //   834: aload #12
    //   836: ifnull -> 893
    //   839: aload #16
    //   841: getfield b : I
    //   844: istore_1
    //   845: iload_1
    //   846: aload #12
    //   848: getfield b : I
    //   851: if_icmplt -> 866
    //   854: aload #16
    //   856: iload_1
    //   857: aload #12
    //   859: getfield d : I
    //   862: isub
    //   863: putfield b : I
    //   866: aload #16
    //   868: getfield d : I
    //   871: istore_1
    //   872: iload_1
    //   873: aload #12
    //   875: getfield b : I
    //   878: if_icmplt -> 893
    //   881: aload #16
    //   883: iload_1
    //   884: aload #12
    //   886: getfield d : I
    //   889: isub
    //   890: putfield d : I
    //   893: aload #16
    //   895: getfield b : I
    //   898: istore_1
    //   899: iload_1
    //   900: aload #17
    //   902: getfield b : I
    //   905: if_icmplt -> 920
    //   908: aload #16
    //   910: iload_1
    //   911: aload #17
    //   913: getfield d : I
    //   916: isub
    //   917: putfield b : I
    //   920: aload #16
    //   922: getfield d : I
    //   925: istore_1
    //   926: iload_1
    //   927: aload #17
    //   929: getfield b : I
    //   932: if_icmplt -> 947
    //   935: aload #16
    //   937: iload_1
    //   938: aload #17
    //   940: getfield d : I
    //   943: isub
    //   944: putfield d : I
    //   947: aload #15
    //   949: iload_3
    //   950: aload #17
    //   952: invokeinterface set : (ILjava/lang/Object;)Ljava/lang/Object;
    //   957: pop
    //   958: aload #16
    //   960: getfield b : I
    //   963: aload #16
    //   965: getfield d : I
    //   968: if_icmpeq -> 986
    //   971: aload #15
    //   973: iload #4
    //   975: aload #16
    //   977: invokeinterface set : (ILjava/lang/Object;)Ljava/lang/Object;
    //   982: pop
    //   983: goto -> 996
    //   986: aload #15
    //   988: iload #4
    //   990: invokeinterface remove : (I)Ljava/lang/Object;
    //   995: pop
    //   996: aload #12
    //   998: ifnull -> 18
    //   1001: aload #15
    //   1003: iload_3
    //   1004: aload #12
    //   1006: invokeinterface add : (ILjava/lang/Object;)V
    //   1011: goto -> 18
    //   1014: aload #16
    //   1016: getfield d : I
    //   1019: istore #5
    //   1021: aload #17
    //   1023: getfield b : I
    //   1026: istore #6
    //   1028: iload #5
    //   1030: iload #6
    //   1032: if_icmpge -> 1040
    //   1035: iconst_m1
    //   1036: istore_1
    //   1037: goto -> 1042
    //   1040: iconst_0
    //   1041: istore_1
    //   1042: aload #16
    //   1044: getfield b : I
    //   1047: istore #7
    //   1049: iload_1
    //   1050: istore_2
    //   1051: iload #7
    //   1053: iload #6
    //   1055: if_icmpge -> 1062
    //   1058: iload_1
    //   1059: iconst_1
    //   1060: iadd
    //   1061: istore_2
    //   1062: iload #6
    //   1064: iload #7
    //   1066: if_icmpgt -> 1082
    //   1069: aload #16
    //   1071: iload #7
    //   1073: aload #17
    //   1075: getfield d : I
    //   1078: iadd
    //   1079: putfield b : I
    //   1082: aload #17
    //   1084: getfield b : I
    //   1087: istore_1
    //   1088: iload_1
    //   1089: iload #5
    //   1091: if_icmpgt -> 1107
    //   1094: aload #16
    //   1096: iload #5
    //   1098: aload #17
    //   1100: getfield d : I
    //   1103: iadd
    //   1104: putfield d : I
    //   1107: aload #17
    //   1109: iload_1
    //   1110: iload_2
    //   1111: iadd
    //   1112: putfield b : I
    //   1115: aload #15
    //   1117: iload_3
    //   1118: aload #17
    //   1120: invokeinterface set : (ILjava/lang/Object;)Ljava/lang/Object;
    //   1125: pop
    //   1126: aload #15
    //   1128: iload #4
    //   1130: aload #16
    //   1132: invokeinterface set : (ILjava/lang/Object;)Ljava/lang/Object;
    //   1137: pop
    //   1138: goto -> 18
    //   1141: aload_0
    //   1142: getfield b : Ljava/util/ArrayList;
    //   1145: invokevirtual size : ()I
    //   1148: istore #10
    //   1150: iconst_0
    //   1151: istore #7
    //   1153: iload #7
    //   1155: iload #10
    //   1157: if_icmpge -> 1661
    //   1160: aload_0
    //   1161: getfield b : Ljava/util/ArrayList;
    //   1164: iload #7
    //   1166: invokevirtual get : (I)Ljava/lang/Object;
    //   1169: checkcast androidx/recyclerview/widget/a$b
    //   1172: astore #12
    //   1174: aload #12
    //   1176: getfield a : I
    //   1179: istore_1
    //   1180: iload_1
    //   1181: iconst_1
    //   1182: if_icmpeq -> 1646
    //   1185: iload_1
    //   1186: iconst_2
    //   1187: if_icmpeq -> 1436
    //   1190: iload_1
    //   1191: iconst_4
    //   1192: if_icmpeq -> 1213
    //   1195: iload_1
    //   1196: bipush #8
    //   1198: if_icmpeq -> 1204
    //   1201: goto -> 1652
    //   1204: aload_0
    //   1205: aload #12
    //   1207: invokevirtual i : (Landroidx/recyclerview/widget/a$b;)V
    //   1210: goto -> 1652
    //   1213: aload #12
    //   1215: getfield b : I
    //   1218: istore #8
    //   1220: aload #12
    //   1222: getfield d : I
    //   1225: istore #11
    //   1227: iload #8
    //   1229: istore_1
    //   1230: iconst_0
    //   1231: istore_2
    //   1232: iconst_m1
    //   1233: istore #9
    //   1235: iload #8
    //   1237: istore_3
    //   1238: iload_3
    //   1239: iload #11
    //   1241: iload #8
    //   1243: iadd
    //   1244: if_icmpge -> 1376
    //   1247: aload_0
    //   1248: getfield d : Landroidx/recyclerview/widget/a$a;
    //   1251: checkcast androidx/recyclerview/widget/w
    //   1254: iload_3
    //   1255: invokevirtual b : (I)Landroidx/recyclerview/widget/RecyclerView$a0;
    //   1258: ifnonnull -> 1321
    //   1261: aload_0
    //   1262: iload_3
    //   1263: invokevirtual a : (I)Z
    //   1266: ifeq -> 1272
    //   1269: goto -> 1321
    //   1272: iload_1
    //   1273: istore #5
    //   1275: iload_2
    //   1276: istore #4
    //   1278: iload #9
    //   1280: iconst_1
    //   1281: if_icmpne -> 1306
    //   1284: aload_0
    //   1285: aload_0
    //   1286: iconst_4
    //   1287: iload_1
    //   1288: iload_2
    //   1289: aload #12
    //   1291: getfield c : Ljava/lang/Object;
    //   1294: invokevirtual h : (IIILjava/lang/Object;)Landroidx/recyclerview/widget/a$b;
    //   1297: invokevirtual i : (Landroidx/recyclerview/widget/a$b;)V
    //   1300: iload_3
    //   1301: istore #5
    //   1303: iconst_0
    //   1304: istore #4
    //   1306: iconst_0
    //   1307: istore_2
    //   1308: iload #5
    //   1310: istore_1
    //   1311: iload #4
    //   1313: istore #6
    //   1315: iload_2
    //   1316: istore #4
    //   1318: goto -> 1360
    //   1321: iload_1
    //   1322: istore #5
    //   1324: iload_2
    //   1325: istore #6
    //   1327: iload #9
    //   1329: ifne -> 1354
    //   1332: aload_0
    //   1333: aload_0
    //   1334: iconst_4
    //   1335: iload_1
    //   1336: iload_2
    //   1337: aload #12
    //   1339: getfield c : Ljava/lang/Object;
    //   1342: invokevirtual h : (IIILjava/lang/Object;)Landroidx/recyclerview/widget/a$b;
    //   1345: invokevirtual d : (Landroidx/recyclerview/widget/a$b;)V
    //   1348: iload_3
    //   1349: istore #5
    //   1351: iconst_0
    //   1352: istore #6
    //   1354: iconst_1
    //   1355: istore #4
    //   1357: iload #5
    //   1359: istore_1
    //   1360: iload #6
    //   1362: iconst_1
    //   1363: iadd
    //   1364: istore_2
    //   1365: iload_3
    //   1366: iconst_1
    //   1367: iadd
    //   1368: istore_3
    //   1369: iload #4
    //   1371: istore #9
    //   1373: goto -> 1238
    //   1376: aload #12
    //   1378: astore #13
    //   1380: iload_2
    //   1381: aload #12
    //   1383: getfield d : I
    //   1386: if_icmpeq -> 1413
    //   1389: aload #12
    //   1391: getfield c : Ljava/lang/Object;
    //   1394: astore #13
    //   1396: aload_0
    //   1397: aload #12
    //   1399: invokevirtual k : (Landroidx/recyclerview/widget/a$b;)V
    //   1402: aload_0
    //   1403: iconst_4
    //   1404: iload_1
    //   1405: iload_2
    //   1406: aload #13
    //   1408: invokevirtual h : (IIILjava/lang/Object;)Landroidx/recyclerview/widget/a$b;
    //   1411: astore #13
    //   1413: iload #9
    //   1415: ifne -> 1427
    //   1418: aload_0
    //   1419: aload #13
    //   1421: invokevirtual d : (Landroidx/recyclerview/widget/a$b;)V
    //   1424: goto -> 1652
    //   1427: aload_0
    //   1428: aload #13
    //   1430: invokevirtual i : (Landroidx/recyclerview/widget/a$b;)V
    //   1433: goto -> 1652
    //   1436: aload #12
    //   1438: getfield b : I
    //   1441: istore #6
    //   1443: aload #12
    //   1445: getfield d : I
    //   1448: iload #6
    //   1450: iadd
    //   1451: istore #4
    //   1453: iload #6
    //   1455: istore_1
    //   1456: iconst_0
    //   1457: istore #5
    //   1459: iconst_m1
    //   1460: istore_2
    //   1461: iload_1
    //   1462: iload #4
    //   1464: if_icmpge -> 1592
    //   1467: aload_0
    //   1468: getfield d : Landroidx/recyclerview/widget/a$a;
    //   1471: checkcast androidx/recyclerview/widget/w
    //   1474: iload_1
    //   1475: invokevirtual b : (I)Landroidx/recyclerview/widget/RecyclerView$a0;
    //   1478: ifnonnull -> 1529
    //   1481: aload_0
    //   1482: iload_1
    //   1483: invokevirtual a : (I)Z
    //   1486: ifeq -> 1492
    //   1489: goto -> 1529
    //   1492: iload_2
    //   1493: iconst_1
    //   1494: if_icmpne -> 1516
    //   1497: aload_0
    //   1498: aload_0
    //   1499: iconst_2
    //   1500: iload #6
    //   1502: iload #5
    //   1504: aconst_null
    //   1505: invokevirtual h : (IIILjava/lang/Object;)Landroidx/recyclerview/widget/a$b;
    //   1508: invokevirtual i : (Landroidx/recyclerview/widget/a$b;)V
    //   1511: iconst_1
    //   1512: istore_2
    //   1513: goto -> 1518
    //   1516: iconst_0
    //   1517: istore_2
    //   1518: iconst_0
    //   1519: istore #8
    //   1521: iload_2
    //   1522: istore_3
    //   1523: iload #8
    //   1525: istore_2
    //   1526: goto -> 1556
    //   1529: iload_2
    //   1530: ifne -> 1552
    //   1533: aload_0
    //   1534: aload_0
    //   1535: iconst_2
    //   1536: iload #6
    //   1538: iload #5
    //   1540: aconst_null
    //   1541: invokevirtual h : (IIILjava/lang/Object;)Landroidx/recyclerview/widget/a$b;
    //   1544: invokevirtual d : (Landroidx/recyclerview/widget/a$b;)V
    //   1547: iconst_1
    //   1548: istore_3
    //   1549: goto -> 1554
    //   1552: iconst_0
    //   1553: istore_3
    //   1554: iconst_1
    //   1555: istore_2
    //   1556: iload_3
    //   1557: ifeq -> 1577
    //   1560: iload_1
    //   1561: iload #5
    //   1563: isub
    //   1564: istore_1
    //   1565: iload #4
    //   1567: iload #5
    //   1569: isub
    //   1570: istore #4
    //   1572: iconst_1
    //   1573: istore_3
    //   1574: goto -> 1582
    //   1577: iload #5
    //   1579: iconst_1
    //   1580: iadd
    //   1581: istore_3
    //   1582: iload_1
    //   1583: iconst_1
    //   1584: iadd
    //   1585: istore_1
    //   1586: iload_3
    //   1587: istore #5
    //   1589: goto -> 1461
    //   1592: aload #12
    //   1594: astore #13
    //   1596: iload #5
    //   1598: aload #12
    //   1600: getfield d : I
    //   1603: if_icmpeq -> 1624
    //   1606: aload_0
    //   1607: aload #12
    //   1609: invokevirtual k : (Landroidx/recyclerview/widget/a$b;)V
    //   1612: aload_0
    //   1613: iconst_2
    //   1614: iload #6
    //   1616: iload #5
    //   1618: aconst_null
    //   1619: invokevirtual h : (IIILjava/lang/Object;)Landroidx/recyclerview/widget/a$b;
    //   1622: astore #13
    //   1624: iload_2
    //   1625: ifne -> 1637
    //   1628: aload_0
    //   1629: aload #13
    //   1631: invokevirtual d : (Landroidx/recyclerview/widget/a$b;)V
    //   1634: goto -> 1652
    //   1637: aload_0
    //   1638: aload #13
    //   1640: invokevirtual i : (Landroidx/recyclerview/widget/a$b;)V
    //   1643: goto -> 1652
    //   1646: aload_0
    //   1647: aload #12
    //   1649: invokevirtual i : (Landroidx/recyclerview/widget/a$b;)V
    //   1652: iload #7
    //   1654: iconst_1
    //   1655: iadd
    //   1656: istore #7
    //   1658: goto -> 1153
    //   1661: aload_0
    //   1662: getfield b : Ljava/util/ArrayList;
    //   1665: invokevirtual clear : ()V
    //   1668: return
  }
  
  public void k(b paramb) {
    paramb.c = null;
    this.a.a(paramb);
  }
  
  public void l(List<b> paramList) {
    int j = paramList.size();
    for (int i = 0; i < j; i++)
      k(paramList.get(i)); 
    paramList.clear();
  }
  
  public final int m(int paramInt1, int paramInt2) {
    // Byte code:
    //   0: aload_0
    //   1: getfield c : Ljava/util/ArrayList;
    //   4: invokevirtual size : ()I
    //   7: iconst_1
    //   8: isub
    //   9: istore #4
    //   11: iload_1
    //   12: istore_3
    //   13: iload #4
    //   15: iflt -> 345
    //   18: aload_0
    //   19: getfield c : Ljava/util/ArrayList;
    //   22: iload #4
    //   24: invokevirtual get : (I)Ljava/lang/Object;
    //   27: checkcast androidx/recyclerview/widget/a$b
    //   30: astore #9
    //   32: aload #9
    //   34: getfield a : I
    //   37: istore #5
    //   39: iload #5
    //   41: bipush #8
    //   43: if_icmpne -> 249
    //   46: aload #9
    //   48: getfield b : I
    //   51: istore #5
    //   53: aload #9
    //   55: getfield d : I
    //   58: istore #6
    //   60: iload #5
    //   62: iload #6
    //   64: if_icmpge -> 80
    //   67: iload #5
    //   69: istore #7
    //   71: iload #6
    //   73: istore_1
    //   74: iload_1
    //   75: istore #8
    //   77: goto -> 90
    //   80: iload #5
    //   82: istore #8
    //   84: iload #6
    //   86: istore_1
    //   87: iload_1
    //   88: istore #7
    //   90: iload_3
    //   91: iload #7
    //   93: if_icmplt -> 187
    //   96: iload_3
    //   97: iload #8
    //   99: if_icmpgt -> 187
    //   102: iload #7
    //   104: iload #5
    //   106: if_icmpne -> 148
    //   109: iload_2
    //   110: iconst_1
    //   111: if_icmpne -> 128
    //   114: iload #6
    //   116: iconst_1
    //   117: iadd
    //   118: istore_1
    //   119: aload #9
    //   121: iload_1
    //   122: putfield d : I
    //   125: goto -> 141
    //   128: iload_2
    //   129: iconst_2
    //   130: if_icmpne -> 141
    //   133: iload #6
    //   135: iconst_1
    //   136: isub
    //   137: istore_1
    //   138: goto -> 119
    //   141: iload_3
    //   142: iconst_1
    //   143: iadd
    //   144: istore_1
    //   145: goto -> 334
    //   148: iload_2
    //   149: iconst_1
    //   150: if_icmpne -> 167
    //   153: iload #5
    //   155: iconst_1
    //   156: iadd
    //   157: istore_1
    //   158: aload #9
    //   160: iload_1
    //   161: putfield b : I
    //   164: goto -> 180
    //   167: iload_2
    //   168: iconst_2
    //   169: if_icmpne -> 180
    //   172: iload #5
    //   174: iconst_1
    //   175: isub
    //   176: istore_1
    //   177: goto -> 158
    //   180: iload_3
    //   181: iconst_1
    //   182: isub
    //   183: istore_1
    //   184: goto -> 334
    //   187: iload_3
    //   188: istore_1
    //   189: iload_3
    //   190: iload #5
    //   192: if_icmpge -> 334
    //   195: iload_2
    //   196: iconst_1
    //   197: if_icmpne -> 225
    //   200: aload #9
    //   202: iload #5
    //   204: iconst_1
    //   205: iadd
    //   206: putfield b : I
    //   209: iload #6
    //   211: iconst_1
    //   212: iadd
    //   213: istore_1
    //   214: aload #9
    //   216: iload_1
    //   217: putfield d : I
    //   220: iload_3
    //   221: istore_1
    //   222: goto -> 334
    //   225: iload_3
    //   226: istore_1
    //   227: iload_2
    //   228: iconst_2
    //   229: if_icmpne -> 334
    //   232: aload #9
    //   234: iload #5
    //   236: iconst_1
    //   237: isub
    //   238: putfield b : I
    //   241: iload #6
    //   243: iconst_1
    //   244: isub
    //   245: istore_1
    //   246: goto -> 214
    //   249: aload #9
    //   251: getfield b : I
    //   254: istore #6
    //   256: iload #6
    //   258: iload_3
    //   259: if_icmpgt -> 298
    //   262: iload #5
    //   264: iconst_1
    //   265: if_icmpne -> 279
    //   268: iload_3
    //   269: aload #9
    //   271: getfield d : I
    //   274: isub
    //   275: istore_1
    //   276: goto -> 334
    //   279: iload_3
    //   280: istore_1
    //   281: iload #5
    //   283: iconst_2
    //   284: if_icmpne -> 334
    //   287: iload_3
    //   288: aload #9
    //   290: getfield d : I
    //   293: iadd
    //   294: istore_1
    //   295: goto -> 334
    //   298: iload_2
    //   299: iconst_1
    //   300: if_icmpne -> 319
    //   303: iload #6
    //   305: iconst_1
    //   306: iadd
    //   307: istore_1
    //   308: aload #9
    //   310: iload_1
    //   311: putfield b : I
    //   314: iload_3
    //   315: istore_1
    //   316: goto -> 334
    //   319: iload_3
    //   320: istore_1
    //   321: iload_2
    //   322: iconst_2
    //   323: if_icmpne -> 334
    //   326: iload #6
    //   328: iconst_1
    //   329: isub
    //   330: istore_1
    //   331: goto -> 308
    //   334: iload #4
    //   336: iconst_1
    //   337: isub
    //   338: istore #4
    //   340: iload_1
    //   341: istore_3
    //   342: goto -> 13
    //   345: aload_0
    //   346: getfield c : Ljava/util/ArrayList;
    //   349: invokevirtual size : ()I
    //   352: iconst_1
    //   353: isub
    //   354: istore_1
    //   355: iload_1
    //   356: iflt -> 434
    //   359: aload_0
    //   360: getfield c : Ljava/util/ArrayList;
    //   363: iload_1
    //   364: invokevirtual get : (I)Ljava/lang/Object;
    //   367: checkcast androidx/recyclerview/widget/a$b
    //   370: astore #9
    //   372: aload #9
    //   374: getfield a : I
    //   377: bipush #8
    //   379: if_icmpne -> 404
    //   382: aload #9
    //   384: getfield d : I
    //   387: istore_2
    //   388: iload_2
    //   389: aload #9
    //   391: getfield b : I
    //   394: if_icmpeq -> 412
    //   397: iload_2
    //   398: ifge -> 427
    //   401: goto -> 412
    //   404: aload #9
    //   406: getfield d : I
    //   409: ifgt -> 427
    //   412: aload_0
    //   413: getfield c : Ljava/util/ArrayList;
    //   416: iload_1
    //   417: invokevirtual remove : (I)Ljava/lang/Object;
    //   420: pop
    //   421: aload_0
    //   422: aload #9
    //   424: invokevirtual k : (Landroidx/recyclerview/widget/a$b;)V
    //   427: iload_1
    //   428: iconst_1
    //   429: isub
    //   430: istore_1
    //   431: goto -> 355
    //   434: iload_3
    //   435: ireturn
  }
  
  public static interface a {}
  
  public static final class b {
    public int a;
    
    public int b;
    
    public Object c;
    
    public int d;
    
    public b(int param1Int1, int param1Int2, int param1Int3, Object param1Object) {
      this.a = param1Int1;
      this.b = param1Int2;
      this.d = param1Int3;
      this.c = param1Object;
    }
    
    public boolean equals(Object param1Object) {
      if (this == param1Object)
        return true; 
      if (!(param1Object instanceof b))
        return false; 
      b b1 = (b)param1Object;
      int i = this.a;
      if (i != b1.a)
        return false; 
      if (i == 8 && Math.abs(this.d - this.b) == 1 && this.d == b1.b && this.b == b1.d)
        return true; 
      if (this.d != b1.d)
        return false; 
      if (this.b != b1.b)
        return false; 
      param1Object = this.c;
      Object object = b1.c;
      if (param1Object != null) {
        if (!param1Object.equals(object))
          return false; 
      } else if (object != null) {
        return false;
      } 
      return true;
    }
    
    public int hashCode() {
      return (this.a * 31 + this.b) * 31 + this.d;
    }
    
    public String toString() {
      String str;
      StringBuilder stringBuilder = new StringBuilder();
      stringBuilder.append(Integer.toHexString(System.identityHashCode(this)));
      stringBuilder.append("[");
      int i = this.a;
      if (i != 1) {
        if (i != 2) {
          if (i != 4) {
            if (i != 8) {
              str = "??";
            } else {
              str = "mv";
            } 
          } else {
            str = "up";
          } 
        } else {
          str = "rm";
        } 
      } else {
        str = "add";
      } 
      stringBuilder.append(str);
      stringBuilder.append(",s:");
      stringBuilder.append(this.b);
      stringBuilder.append("c:");
      stringBuilder.append(this.d);
      stringBuilder.append(",p:");
      stringBuilder.append(this.c);
      stringBuilder.append("]");
      return stringBuilder.toString();
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Luxury Logo Maker_ Logo Design-dex2jar.jar!\androidx\recyclerview\widget\a.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */