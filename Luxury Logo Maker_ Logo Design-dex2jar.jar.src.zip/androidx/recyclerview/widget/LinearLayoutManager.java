package androidx.recyclerview.widget;

import android.annotation.SuppressLint;
import android.content.Context;
import android.graphics.PointF;
import android.graphics.Rect;
import android.os.Parcel;
import android.os.Parcelable;
import android.util.AttributeSet;
import android.view.View;
import android.view.ViewGroup;
import android.view.accessibility.AccessibilityEvent;
import androidx.appcompat.widget.y;
import java.util.List;

public class LinearLayoutManager extends RecyclerView.m implements RecyclerView.w.b {
  public final a A = new a();
  
  public final b B = new b();
  
  public int C = 2;
  
  public int[] D = new int[2];
  
  public int p = 1;
  
  public c q;
  
  public s r;
  
  public boolean s;
  
  public boolean t = false;
  
  public boolean u = false;
  
  public boolean v = false;
  
  public boolean w = true;
  
  public int x = -1;
  
  public int y = Integer.MIN_VALUE;
  
  public d z = null;
  
  public LinearLayoutManager(int paramInt, boolean paramBoolean) {
    l1(paramInt);
    d(null);
    if (paramBoolean == this.t)
      return; 
    this.t = paramBoolean;
    v0();
  }
  
  public LinearLayoutManager(Context paramContext, AttributeSet paramAttributeSet, int paramInt1, int paramInt2) {
    RecyclerView.m.d d1 = RecyclerView.m.R(paramContext, paramAttributeSet, paramInt1, paramInt2);
    l1(d1.a);
    boolean bool = d1.c;
    d(null);
    if (bool != this.t) {
      this.t = bool;
      v0();
    } 
    m1(d1.d);
  }
  
  public boolean F0() {
    if (this.m != 1073741824 && this.l != 1073741824) {
      int j = x();
      int i = 0;
      while (true) {
        if (i < j) {
          ViewGroup.LayoutParams layoutParams = w(i).getLayoutParams();
          if (layoutParams.width < 0 && layoutParams.height < 0) {
            i = 1;
            break;
          } 
          i++;
          continue;
        } 
        i = 0;
        break;
      } 
      if (i != 0)
        return true; 
    } 
    return false;
  }
  
  public void H0(RecyclerView paramRecyclerView, RecyclerView.x paramx, int paramInt) {
    o o = new o(paramRecyclerView.getContext());
    o.a = paramInt;
    I0(o);
  }
  
  public boolean J0() {
    return (this.z == null && this.s == this.v);
  }
  
  public void K0(RecyclerView.x paramx, int[] paramArrayOfint) {
    int i;
    int j;
    boolean bool;
    if (paramx.a != -1) {
      i = 1;
    } else {
      i = 0;
    } 
    if (i) {
      i = this.r.l();
    } else {
      i = 0;
    } 
    if (this.q.f == -1) {
      j = 0;
      bool = i;
    } else {
      bool = false;
      j = i;
    } 
    paramArrayOfint[0] = bool;
    paramArrayOfint[1] = j;
  }
  
  public void L0(RecyclerView.x paramx, c paramc, RecyclerView.m.c paramc1) {
    int i = paramc.d;
    if (i >= 0 && i < paramx.b()) {
      int j = Math.max(0, paramc.g);
      ((m.b)paramc1).a(i, j);
    } 
  }
  
  public final int M0(RecyclerView.x paramx) {
    if (x() == 0)
      return 0; 
    Q0();
    return y.a(paramx, this.r, T0(this.w ^ true, true), S0(this.w ^ true, true), this, this.w);
  }
  
  public final int N0(RecyclerView.x paramx) {
    if (x() == 0)
      return 0; 
    Q0();
    return y.b(paramx, this.r, T0(this.w ^ true, true), S0(this.w ^ true, true), this, this.w, this.u);
  }
  
  public final int O0(RecyclerView.x paramx) {
    if (x() == 0)
      return 0; 
    Q0();
    return y.c(paramx, this.r, T0(this.w ^ true, true), S0(this.w ^ true, true), this, this.w);
  }
  
  public int P0(int paramInt) {
    return (paramInt != 1) ? ((paramInt != 2) ? ((paramInt != 17) ? ((paramInt != 33) ? ((paramInt != 66) ? ((paramInt != 130) ? Integer.MIN_VALUE : ((this.p == 1) ? 1 : Integer.MIN_VALUE)) : ((this.p == 0) ? 1 : Integer.MIN_VALUE)) : ((this.p == 1) ? -1 : Integer.MIN_VALUE)) : ((this.p == 0) ? -1 : Integer.MIN_VALUE)) : ((this.p == 1) ? 1 : (d1() ? -1 : 1))) : ((this.p == 1) ? -1 : (d1() ? 1 : -1));
  }
  
  public void Q0() {
    if (this.q == null)
      this.q = new c(); 
  }
  
  public int R0(RecyclerView.s params, c paramc, RecyclerView.x paramx, boolean paramBoolean) {
    int k = paramc.c;
    int i = paramc.g;
    if (i != Integer.MIN_VALUE) {
      if (k < 0)
        paramc.g = i + k; 
      g1(params, paramc);
    } 
    int j = paramc.c + paramc.h;
    b b1 = this.B;
    while (true) {
      while (true)
        break; 
      if (paramBoolean) {
        j = i;
        if (b1.d)
          break; 
      } 
    } 
    return k - paramc.c;
  }
  
  public View S0(boolean paramBoolean1, boolean paramBoolean2) {
    if (this.u) {
      boolean bool = false;
      int j = x();
      return X0(bool, j, paramBoolean1, paramBoolean2);
    } 
    int i = x() - 1;
    byte b1 = -1;
    return X0(i, b1, paramBoolean1, paramBoolean2);
  }
  
  public View T0(boolean paramBoolean1, boolean paramBoolean2) {
    if (this.u) {
      int j = x() - 1;
      byte b1 = -1;
      return X0(j, b1, paramBoolean1, paramBoolean2);
    } 
    boolean bool = false;
    int i = x();
    return X0(bool, i, paramBoolean1, paramBoolean2);
  }
  
  public boolean U() {
    return true;
  }
  
  public int U0() {
    View view = X0(0, x(), false, true);
    return (view == null) ? -1 : Q(view);
  }
  
  public int V0() {
    View view = X0(x() - 1, -1, false, true);
    return (view == null) ? -1 : Q(view);
  }
  
  public View W0(int paramInt1, int paramInt2) {
    char c1;
    char c2;
    b0 b0;
    Q0();
    if (paramInt2 > paramInt1) {
      c1 = '\001';
    } else if (paramInt2 < paramInt1) {
      c1 = '￿';
    } else {
      c1 = Character.MIN_VALUE;
    } 
    if (!c1)
      return w(paramInt1); 
    if (this.r.e(w(paramInt1)) < this.r.k()) {
      c1 = '䄄';
      c2 = '䀄';
    } else {
      c1 = '၁';
      c2 = 'ခ';
    } 
    if (this.p == 0) {
      b0 = this.c;
    } else {
      b0 = this.d;
    } 
    return b0.a(paramInt1, paramInt2, c1, c2);
  }
  
  public View X0(int paramInt1, int paramInt2, boolean paramBoolean1, boolean paramBoolean2) {
    char c1;
    b0 b0;
    Q0();
    char c2 = 'ŀ';
    if (paramBoolean1) {
      c1 = '怃';
    } else {
      c1 = 'ŀ';
    } 
    if (!paramBoolean2)
      c2 = Character.MIN_VALUE; 
    if (this.p == 0) {
      b0 = this.c;
    } else {
      b0 = this.d;
    } 
    return b0.a(paramInt1, paramInt2, c1, c2);
  }
  
  public View Y0(RecyclerView.s params, RecyclerView.x paramx, boolean paramBoolean1, boolean paramBoolean2) {
    // Byte code:
    //   0: aload_0
    //   1: invokevirtual Q0 : ()V
    //   4: aload_0
    //   5: invokevirtual x : ()I
    //   8: istore #5
    //   10: iconst_m1
    //   11: istore #6
    //   13: iload #4
    //   15: ifeq -> 32
    //   18: aload_0
    //   19: invokevirtual x : ()I
    //   22: iconst_1
    //   23: isub
    //   24: istore #5
    //   26: iconst_m1
    //   27: istore #7
    //   29: goto -> 42
    //   32: iload #5
    //   34: istore #6
    //   36: iconst_0
    //   37: istore #5
    //   39: iconst_1
    //   40: istore #7
    //   42: aload_2
    //   43: invokevirtual b : ()I
    //   46: istore #10
    //   48: aload_0
    //   49: getfield r : Landroidx/recyclerview/widget/s;
    //   52: invokevirtual k : ()I
    //   55: istore #11
    //   57: aload_0
    //   58: getfield r : Landroidx/recyclerview/widget/s;
    //   61: invokevirtual g : ()I
    //   64: istore #12
    //   66: aconst_null
    //   67: astore #15
    //   69: aconst_null
    //   70: astore #14
    //   72: aload #14
    //   74: astore_2
    //   75: iload #5
    //   77: iload #6
    //   79: if_icmpeq -> 349
    //   82: aload_0
    //   83: iload #5
    //   85: invokevirtual w : (I)Landroid/view/View;
    //   88: astore_1
    //   89: aload_0
    //   90: aload_1
    //   91: invokevirtual Q : (Landroid/view/View;)I
    //   94: istore #8
    //   96: aload_0
    //   97: getfield r : Landroidx/recyclerview/widget/s;
    //   100: aload_1
    //   101: invokevirtual e : (Landroid/view/View;)I
    //   104: istore #9
    //   106: aload_0
    //   107: getfield r : Landroidx/recyclerview/widget/s;
    //   110: aload_1
    //   111: invokevirtual b : (Landroid/view/View;)I
    //   114: istore #13
    //   116: aload #15
    //   118: astore #16
    //   120: aload #14
    //   122: astore #17
    //   124: aload_2
    //   125: astore #18
    //   127: iload #8
    //   129: iflt -> 328
    //   132: aload #15
    //   134: astore #16
    //   136: aload #14
    //   138: astore #17
    //   140: aload_2
    //   141: astore #18
    //   143: iload #8
    //   145: iload #10
    //   147: if_icmpge -> 328
    //   150: aload_1
    //   151: invokevirtual getLayoutParams : ()Landroid/view/ViewGroup$LayoutParams;
    //   154: checkcast androidx/recyclerview/widget/RecyclerView$n
    //   157: invokevirtual c : ()Z
    //   160: ifeq -> 192
    //   163: aload #15
    //   165: astore #16
    //   167: aload #14
    //   169: astore #17
    //   171: aload_2
    //   172: astore #18
    //   174: aload_2
    //   175: ifnonnull -> 328
    //   178: aload #15
    //   180: astore #16
    //   182: aload #14
    //   184: astore #17
    //   186: aload_1
    //   187: astore #18
    //   189: goto -> 328
    //   192: iload #13
    //   194: iload #11
    //   196: if_icmpgt -> 212
    //   199: iload #9
    //   201: iload #11
    //   203: if_icmpge -> 212
    //   206: iconst_1
    //   207: istore #8
    //   209: goto -> 215
    //   212: iconst_0
    //   213: istore #8
    //   215: iload #9
    //   217: iload #12
    //   219: if_icmplt -> 235
    //   222: iload #13
    //   224: iload #12
    //   226: if_icmple -> 235
    //   229: iconst_1
    //   230: istore #9
    //   232: goto -> 238
    //   235: iconst_0
    //   236: istore #9
    //   238: iload #8
    //   240: ifne -> 253
    //   243: iload #9
    //   245: ifeq -> 251
    //   248: goto -> 253
    //   251: aload_1
    //   252: areturn
    //   253: iload_3
    //   254: ifeq -> 284
    //   257: iload #9
    //   259: ifeq -> 265
    //   262: goto -> 289
    //   265: aload #15
    //   267: astore #16
    //   269: aload #14
    //   271: astore #17
    //   273: aload_2
    //   274: astore #18
    //   276: aload #15
    //   278: ifnonnull -> 328
    //   281: goto -> 318
    //   284: iload #8
    //   286: ifeq -> 302
    //   289: aload #15
    //   291: astore #16
    //   293: aload_1
    //   294: astore #17
    //   296: aload_2
    //   297: astore #18
    //   299: goto -> 328
    //   302: aload #15
    //   304: astore #16
    //   306: aload #14
    //   308: astore #17
    //   310: aload_2
    //   311: astore #18
    //   313: aload #15
    //   315: ifnonnull -> 328
    //   318: aload_2
    //   319: astore #18
    //   321: aload #14
    //   323: astore #17
    //   325: aload_1
    //   326: astore #16
    //   328: iload #5
    //   330: iload #7
    //   332: iadd
    //   333: istore #5
    //   335: aload #16
    //   337: astore #15
    //   339: aload #17
    //   341: astore #14
    //   343: aload #18
    //   345: astore_2
    //   346: goto -> 75
    //   349: aload #15
    //   351: ifnull -> 357
    //   354: aload #15
    //   356: areturn
    //   357: aload #14
    //   359: ifnull -> 365
    //   362: aload #14
    //   364: areturn
    //   365: aload_2
    //   366: areturn
  }
  
  public final int Z0(int paramInt, RecyclerView.s params, RecyclerView.x paramx, boolean paramBoolean) {
    int i = this.r.g() - paramInt;
    if (i > 0) {
      i = -k1(-i, params, paramx);
      if (paramBoolean) {
        paramInt = this.r.g() - paramInt + i;
        if (paramInt > 0) {
          this.r.p(paramInt);
          return paramInt + i;
        } 
      } 
      return i;
    } 
    return 0;
  }
  
  public PointF a(int paramInt) {
    if (x() == 0)
      return null; 
    boolean bool1 = false;
    int i = Q(w(0));
    boolean bool = true;
    if (paramInt < i)
      bool1 = true; 
    paramInt = bool;
    if (bool1 != this.u)
      paramInt = -1; 
    return (this.p == 0) ? new PointF(paramInt, 0.0F) : new PointF(0.0F, paramInt);
  }
  
  public void a0(RecyclerView paramRecyclerView, RecyclerView.s params) {}
  
  public final int a1(int paramInt, RecyclerView.s params, RecyclerView.x paramx, boolean paramBoolean) {
    int i = paramInt - this.r.k();
    if (i > 0) {
      int j = -k1(i, params, paramx);
      i = j;
      if (paramBoolean) {
        paramInt = paramInt + j - this.r.k();
        i = j;
        if (paramInt > 0) {
          this.r.p(-paramInt);
          i = j - paramInt;
        } 
      } 
      return i;
    } 
    return 0;
  }
  
  public View b0(View paramView, int paramInt, RecyclerView.s params, RecyclerView.x paramx) {
    View view1;
    View view2;
    j1();
    if (x() == 0)
      return null; 
    paramInt = P0(paramInt);
    if (paramInt == Integer.MIN_VALUE)
      return null; 
    Q0();
    n1(paramInt, (int)(this.r.l() * 0.33333334F), false, paramx);
    c c1 = this.q;
    c1.g = Integer.MIN_VALUE;
    c1.a = false;
    R0(params, c1, paramx, true);
    if (paramInt == -1) {
      if (this.u) {
        view1 = W0(x() - 1, -1);
      } else {
        view1 = W0(0, x());
      } 
    } else if (this.u) {
      view1 = W0(0, x());
    } else {
      view1 = W0(x() - 1, -1);
    } 
    if (paramInt == -1) {
      view2 = c1();
    } else {
      view2 = b1();
    } 
    return view2.hasFocusable() ? ((view1 == null) ? null : view2) : view1;
  }
  
  public final View b1() {
    int i;
    if (this.u) {
      i = 0;
    } else {
      i = x() - 1;
    } 
    return w(i);
  }
  
  public void c0(AccessibilityEvent paramAccessibilityEvent) {
    super.c0(paramAccessibilityEvent);
    if (x() > 0) {
      paramAccessibilityEvent.setFromIndex(U0());
      paramAccessibilityEvent.setToIndex(V0());
    } 
  }
  
  public final View c1() {
    boolean bool;
    if (this.u) {
      bool = x() - 1;
    } else {
      bool = false;
    } 
    return w(bool);
  }
  
  public void d(String paramString) {
    if (this.z == null) {
      RecyclerView recyclerView = this.b;
      if (recyclerView != null)
        recyclerView.i(paramString); 
    } 
  }
  
  public boolean d1() {
    return (J() == 1);
  }
  
  public boolean e() {
    return (this.p == 0);
  }
  
  public void e1(RecyclerView.s params, RecyclerView.x paramx, c paramc, b paramb) {
    View view = paramc.c(params);
    if (view == null) {
      paramb.b = true;
      return;
    } 
    RecyclerView.n n1 = (RecyclerView.n)view.getLayoutParams();
    if (paramc.k == null) {
      boolean bool1;
      boolean bool2 = this.u;
      if (paramc.f == -1) {
        bool1 = true;
      } else {
        bool1 = false;
      } 
      if (bool2 == bool1) {
        c(view, -1, false);
      } else {
        c(view, 0, false);
      } 
    } else {
      boolean bool1;
      boolean bool2 = this.u;
      if (paramc.f == -1) {
        bool1 = true;
      } else {
        bool1 = false;
      } 
      if (bool2 == bool1) {
        c(view, -1, true);
      } else {
        c(view, 0, true);
      } 
    } 
    RecyclerView.n n2 = (RecyclerView.n)view.getLayoutParams();
    Rect rect = this.b.L(view);
    int k = rect.left;
    int n = rect.right;
    int i = rect.top;
    int j = rect.bottom;
    int i1 = this.n;
    int i2 = this.l;
    int i3 = N();
    k = RecyclerView.m.y(i1, i2, O() + i3 + n2.leftMargin + n2.rightMargin + k + n + 0, n2.width, e());
    n = this.o;
    i1 = this.m;
    i2 = P();
    i = RecyclerView.m.y(n, i1, M() + i2 + n2.topMargin + n2.bottomMargin + i + j + 0, n2.height, f());
    if (E0(view, k, i, n2))
      view.measure(k, i); 
    paramb.a = this.r.c(view);
    if (this.p == 1) {
      if (d1()) {
        i = this.n - O();
        j = i - this.r.d(view);
      } else {
        j = N();
        i = this.r.d(view) + j;
      } 
      n = paramc.f;
      k = paramc.b;
      if (n == -1) {
        n = paramb.a;
        i1 = k;
        i2 = i;
        i = k - n;
        n = j;
        j = i2;
        k = i1;
      } else {
        n = paramb.a;
        i1 = k;
        i2 = i;
        k = n + k;
        n = j;
        i = i1;
        j = i2;
      } 
    } else {
      n = P();
      j = this.r.d(view) + n;
      k = paramc.f;
      i = paramc.b;
      if (k == -1) {
        i3 = paramb.a;
        k = i;
        i2 = n;
        i1 = j;
        n = i - i3;
        i = i2;
        j = k;
        k = i1;
      } else {
        k = paramb.a;
        i2 = k + i;
        i1 = i;
        k = j;
        j = i2;
        i = n;
        n = i1;
      } 
    } 
    W(view, n, i, j, k);
    if (n1.c() || n1.b())
      paramb.c = true; 
    paramb.d = view.hasFocusable();
  }
  
  public boolean f() {
    return (this.p == 1);
  }
  
  public void f1(RecyclerView.s params, RecyclerView.x paramx, a parama, int paramInt) {}
  
  public final void g1(RecyclerView.s params, c paramc) {
    if (paramc.a) {
      if (paramc.l)
        return; 
      int i = paramc.g;
      int j = paramc.i;
      if (paramc.f == -1) {
        int k = x();
        if (i < 0)
          return; 
        j = this.r.f() - i + j;
        if (this.u) {
          for (i = 0; i < k; i++) {
            View view = w(i);
            if (this.r.e(view) < j || this.r.o(view) < j) {
              h1(params, 0, i);
              return;
            } 
          } 
        } else {
          for (i = --k; i >= 0; i--) {
            View view = w(i);
            if (this.r.e(view) < j || this.r.o(view) < j) {
              h1(params, k, i);
              return;
            } 
          } 
        } 
      } else {
        if (i < 0)
          return; 
        j = i - j;
        int k = x();
        if (this.u) {
          for (i = --k; i >= 0; i--) {
            View view = w(i);
            if (this.r.b(view) > j || this.r.n(view) > j) {
              h1(params, k, i);
              return;
            } 
          } 
        } else {
          for (i = 0; i < k; i++) {
            View view = w(i);
            if (this.r.b(view) > j || this.r.n(view) > j) {
              h1(params, 0, i);
              break;
            } 
          } 
        } 
      } 
    } 
  }
  
  public final void h1(RecyclerView.s params, int paramInt1, int paramInt2) {
    if (paramInt1 == paramInt2)
      return; 
    int i = paramInt1;
    if (paramInt2 > paramInt1) {
      while (--paramInt2 >= paramInt1) {
        s0(paramInt2, params);
        paramInt2--;
      } 
    } else {
      while (i > paramInt2) {
        s0(i, params);
        i--;
      } 
    } 
  }
  
  public void i(int paramInt1, int paramInt2, RecyclerView.x paramx, RecyclerView.m.c paramc) {
    if (this.p != 0)
      paramInt1 = paramInt2; 
    if (x() != 0) {
      if (paramInt1 == 0)
        return; 
      Q0();
      if (paramInt1 > 0) {
        paramInt2 = 1;
      } else {
        paramInt2 = -1;
      } 
      n1(paramInt2, Math.abs(paramInt1), true, paramx);
      L0(paramx, this.q, paramc);
    } 
  }
  
  public boolean i1() {
    return (this.r.i() == 0 && this.r.f() == 0);
  }
  
  public void j(int paramInt, RecyclerView.m.c paramc) {
    int i;
    boolean bool;
    d d1 = this.z;
    byte b1 = -1;
    if (d1 != null && d1.b()) {
      d1 = this.z;
      bool = d1.j;
      i = d1.h;
    } else {
      j1();
      boolean bool1 = this.u;
      int k = this.x;
      i = k;
      bool = bool1;
      if (k == -1)
        if (bool1) {
          i = paramInt - 1;
          bool = bool1;
        } else {
          i = 0;
          bool = bool1;
        }  
    } 
    if (!bool)
      b1 = 1; 
    int j;
    for (j = 0; j < this.C && i >= 0 && i < paramInt; j++) {
      ((m.b)paramc).a(i, 0);
      i += b1;
    } 
  }
  
  public final void j1() {
    int i;
    if (this.p == 1 || !d1()) {
      boolean bool = this.t;
    } else {
      i = this.t ^ true;
    } 
    this.u = i;
  }
  
  public int k(RecyclerView.x paramx) {
    return M0(paramx);
  }
  
  public void k0(RecyclerView.s params, RecyclerView.x paramx) {
    // Byte code:
    //   0: aload_0
    //   1: getfield z : Landroidx/recyclerview/widget/LinearLayoutManager$d;
    //   4: ifnonnull -> 15
    //   7: aload_0
    //   8: getfield x : I
    //   11: iconst_m1
    //   12: if_icmpeq -> 28
    //   15: aload_2
    //   16: invokevirtual b : ()I
    //   19: ifne -> 28
    //   22: aload_0
    //   23: aload_1
    //   24: invokevirtual p0 : (Landroidx/recyclerview/widget/RecyclerView$s;)V
    //   27: return
    //   28: aload_0
    //   29: getfield z : Landroidx/recyclerview/widget/LinearLayoutManager$d;
    //   32: astore #14
    //   34: aload #14
    //   36: ifnull -> 58
    //   39: aload #14
    //   41: invokevirtual b : ()Z
    //   44: ifeq -> 58
    //   47: aload_0
    //   48: aload_0
    //   49: getfield z : Landroidx/recyclerview/widget/LinearLayoutManager$d;
    //   52: getfield h : I
    //   55: putfield x : I
    //   58: aload_0
    //   59: invokevirtual Q0 : ()V
    //   62: aload_0
    //   63: getfield q : Landroidx/recyclerview/widget/LinearLayoutManager$c;
    //   66: iconst_0
    //   67: putfield a : Z
    //   70: aload_0
    //   71: invokevirtual j1 : ()V
    //   74: aload_0
    //   75: invokevirtual H : ()Landroid/view/View;
    //   78: astore #14
    //   80: aload_0
    //   81: getfield A : Landroidx/recyclerview/widget/LinearLayoutManager$a;
    //   84: astore #15
    //   86: aload #15
    //   88: getfield e : Z
    //   91: ifeq -> 173
    //   94: aload_0
    //   95: getfield x : I
    //   98: iconst_m1
    //   99: if_icmpne -> 173
    //   102: aload_0
    //   103: getfield z : Landroidx/recyclerview/widget/LinearLayoutManager$d;
    //   106: ifnull -> 112
    //   109: goto -> 173
    //   112: aload #14
    //   114: ifnull -> 977
    //   117: aload_0
    //   118: getfield r : Landroidx/recyclerview/widget/s;
    //   121: aload #14
    //   123: invokevirtual e : (Landroid/view/View;)I
    //   126: aload_0
    //   127: getfield r : Landroidx/recyclerview/widget/s;
    //   130: invokevirtual g : ()I
    //   133: if_icmpge -> 155
    //   136: aload_0
    //   137: getfield r : Landroidx/recyclerview/widget/s;
    //   140: aload #14
    //   142: invokevirtual b : (Landroid/view/View;)I
    //   145: aload_0
    //   146: getfield r : Landroidx/recyclerview/widget/s;
    //   149: invokevirtual k : ()I
    //   152: if_icmpgt -> 977
    //   155: aload_0
    //   156: getfield A : Landroidx/recyclerview/widget/LinearLayoutManager$a;
    //   159: aload #14
    //   161: aload_0
    //   162: aload #14
    //   164: invokevirtual Q : (Landroid/view/View;)I
    //   167: invokevirtual c : (Landroid/view/View;I)V
    //   170: goto -> 977
    //   173: aload #15
    //   175: invokevirtual d : ()V
    //   178: aload_0
    //   179: getfield A : Landroidx/recyclerview/widget/LinearLayoutManager$a;
    //   182: astore #14
    //   184: aload #14
    //   186: aload_0
    //   187: getfield u : Z
    //   190: aload_0
    //   191: getfield v : Z
    //   194: ixor
    //   195: putfield d : Z
    //   198: aload_2
    //   199: getfield g : Z
    //   202: ifne -> 648
    //   205: aload_0
    //   206: getfield x : I
    //   209: istore_3
    //   210: iload_3
    //   211: iconst_m1
    //   212: if_icmpne -> 218
    //   215: goto -> 648
    //   218: iload_3
    //   219: iflt -> 637
    //   222: iload_3
    //   223: aload_2
    //   224: invokevirtual b : ()I
    //   227: if_icmplt -> 233
    //   230: goto -> 637
    //   233: aload #14
    //   235: aload_0
    //   236: getfield x : I
    //   239: putfield b : I
    //   242: aload_0
    //   243: getfield z : Landroidx/recyclerview/widget/LinearLayoutManager$d;
    //   246: astore #15
    //   248: aload #15
    //   250: ifnull -> 322
    //   253: aload #15
    //   255: invokevirtual b : ()Z
    //   258: ifeq -> 322
    //   261: aload_0
    //   262: getfield z : Landroidx/recyclerview/widget/LinearLayoutManager$d;
    //   265: getfield j : Z
    //   268: istore #12
    //   270: aload #14
    //   272: iload #12
    //   274: putfield d : Z
    //   277: iload #12
    //   279: ifeq -> 302
    //   282: aload_0
    //   283: getfield r : Landroidx/recyclerview/widget/s;
    //   286: invokevirtual g : ()I
    //   289: istore_3
    //   290: aload_0
    //   291: getfield z : Landroidx/recyclerview/widget/LinearLayoutManager$d;
    //   294: getfield i : I
    //   297: istore #4
    //   299: goto -> 599
    //   302: aload_0
    //   303: getfield r : Landroidx/recyclerview/widget/s;
    //   306: invokevirtual k : ()I
    //   309: istore_3
    //   310: aload_0
    //   311: getfield z : Landroidx/recyclerview/widget/LinearLayoutManager$d;
    //   314: getfield i : I
    //   317: istore #4
    //   319: goto -> 621
    //   322: aload_0
    //   323: getfield y : I
    //   326: ldc -2147483648
    //   328: if_icmpne -> 567
    //   331: aload_0
    //   332: aload_0
    //   333: getfield x : I
    //   336: invokevirtual s : (I)Landroid/view/View;
    //   339: astore #15
    //   341: aload #15
    //   343: ifnull -> 500
    //   346: aload_0
    //   347: getfield r : Landroidx/recyclerview/widget/s;
    //   350: aload #15
    //   352: invokevirtual c : (Landroid/view/View;)I
    //   355: aload_0
    //   356: getfield r : Landroidx/recyclerview/widget/s;
    //   359: invokevirtual l : ()I
    //   362: if_icmple -> 368
    //   365: goto -> 559
    //   368: aload_0
    //   369: getfield r : Landroidx/recyclerview/widget/s;
    //   372: aload #15
    //   374: invokevirtual e : (Landroid/view/View;)I
    //   377: aload_0
    //   378: getfield r : Landroidx/recyclerview/widget/s;
    //   381: invokevirtual k : ()I
    //   384: isub
    //   385: ifge -> 409
    //   388: aload #14
    //   390: aload_0
    //   391: getfield r : Landroidx/recyclerview/widget/s;
    //   394: invokevirtual k : ()I
    //   397: putfield c : I
    //   400: aload #14
    //   402: iconst_0
    //   403: putfield d : Z
    //   406: goto -> 632
    //   409: aload_0
    //   410: getfield r : Landroidx/recyclerview/widget/s;
    //   413: invokevirtual g : ()I
    //   416: aload_0
    //   417: getfield r : Landroidx/recyclerview/widget/s;
    //   420: aload #15
    //   422: invokevirtual b : (Landroid/view/View;)I
    //   425: isub
    //   426: ifge -> 450
    //   429: aload #14
    //   431: aload_0
    //   432: getfield r : Landroidx/recyclerview/widget/s;
    //   435: invokevirtual g : ()I
    //   438: putfield c : I
    //   441: aload #14
    //   443: iconst_1
    //   444: putfield d : Z
    //   447: goto -> 632
    //   450: aload #14
    //   452: getfield d : Z
    //   455: ifeq -> 481
    //   458: aload_0
    //   459: getfield r : Landroidx/recyclerview/widget/s;
    //   462: aload #15
    //   464: invokevirtual b : (Landroid/view/View;)I
    //   467: istore_3
    //   468: aload_0
    //   469: getfield r : Landroidx/recyclerview/widget/s;
    //   472: invokevirtual m : ()I
    //   475: iload_3
    //   476: iadd
    //   477: istore_3
    //   478: goto -> 491
    //   481: aload_0
    //   482: getfield r : Landroidx/recyclerview/widget/s;
    //   485: aload #15
    //   487: invokevirtual e : (Landroid/view/View;)I
    //   490: istore_3
    //   491: aload #14
    //   493: iload_3
    //   494: putfield c : I
    //   497: goto -> 632
    //   500: aload_0
    //   501: invokevirtual x : ()I
    //   504: ifle -> 559
    //   507: aload_0
    //   508: aload_0
    //   509: iconst_0
    //   510: invokevirtual w : (I)Landroid/view/View;
    //   513: invokevirtual Q : (Landroid/view/View;)I
    //   516: istore_3
    //   517: aload_0
    //   518: getfield x : I
    //   521: iload_3
    //   522: if_icmpge -> 531
    //   525: iconst_1
    //   526: istore #12
    //   528: goto -> 534
    //   531: iconst_0
    //   532: istore #12
    //   534: iload #12
    //   536: aload_0
    //   537: getfield u : Z
    //   540: if_icmpne -> 549
    //   543: iconst_1
    //   544: istore #12
    //   546: goto -> 552
    //   549: iconst_0
    //   550: istore #12
    //   552: aload #14
    //   554: iload #12
    //   556: putfield d : Z
    //   559: aload #14
    //   561: invokevirtual a : ()V
    //   564: goto -> 632
    //   567: aload_0
    //   568: getfield u : Z
    //   571: istore #12
    //   573: aload #14
    //   575: iload #12
    //   577: putfield d : Z
    //   580: iload #12
    //   582: ifeq -> 607
    //   585: aload_0
    //   586: getfield r : Landroidx/recyclerview/widget/s;
    //   589: invokevirtual g : ()I
    //   592: istore_3
    //   593: aload_0
    //   594: getfield y : I
    //   597: istore #4
    //   599: iload_3
    //   600: iload #4
    //   602: isub
    //   603: istore_3
    //   604: goto -> 626
    //   607: aload_0
    //   608: getfield r : Landroidx/recyclerview/widget/s;
    //   611: invokevirtual k : ()I
    //   614: istore_3
    //   615: aload_0
    //   616: getfield y : I
    //   619: istore #4
    //   621: iload_3
    //   622: iload #4
    //   624: iadd
    //   625: istore_3
    //   626: aload #14
    //   628: iload_3
    //   629: putfield c : I
    //   632: iconst_1
    //   633: istore_3
    //   634: goto -> 650
    //   637: aload_0
    //   638: iconst_m1
    //   639: putfield x : I
    //   642: aload_0
    //   643: ldc -2147483648
    //   645: putfield y : I
    //   648: iconst_0
    //   649: istore_3
    //   650: iload_3
    //   651: ifeq -> 657
    //   654: goto -> 969
    //   657: aload_0
    //   658: invokevirtual x : ()I
    //   661: ifne -> 667
    //   664: goto -> 930
    //   667: aload_0
    //   668: invokevirtual H : ()Landroid/view/View;
    //   671: astore #15
    //   673: aload #15
    //   675: ifnull -> 743
    //   678: aload #15
    //   680: invokevirtual getLayoutParams : ()Landroid/view/ViewGroup$LayoutParams;
    //   683: checkcast androidx/recyclerview/widget/RecyclerView$n
    //   686: astore #16
    //   688: aload #16
    //   690: invokevirtual c : ()Z
    //   693: ifne -> 721
    //   696: aload #16
    //   698: invokevirtual a : ()I
    //   701: iflt -> 721
    //   704: aload #16
    //   706: invokevirtual a : ()I
    //   709: aload_2
    //   710: invokevirtual b : ()I
    //   713: if_icmpge -> 721
    //   716: iconst_1
    //   717: istore_3
    //   718: goto -> 723
    //   721: iconst_0
    //   722: istore_3
    //   723: iload_3
    //   724: ifeq -> 743
    //   727: aload #14
    //   729: aload #15
    //   731: aload_0
    //   732: aload #15
    //   734: invokevirtual Q : (Landroid/view/View;)I
    //   737: invokevirtual c : (Landroid/view/View;I)V
    //   740: goto -> 925
    //   743: aload_0
    //   744: getfield s : Z
    //   747: istore #12
    //   749: aload_0
    //   750: getfield v : Z
    //   753: istore #13
    //   755: iload #12
    //   757: iload #13
    //   759: if_icmpeq -> 765
    //   762: goto -> 930
    //   765: aload_0
    //   766: aload_1
    //   767: aload_2
    //   768: aload #14
    //   770: getfield d : Z
    //   773: iload #13
    //   775: invokevirtual Y0 : (Landroidx/recyclerview/widget/RecyclerView$s;Landroidx/recyclerview/widget/RecyclerView$x;ZZ)Landroid/view/View;
    //   778: astore #15
    //   780: aload #15
    //   782: ifnull -> 930
    //   785: aload #14
    //   787: aload #15
    //   789: aload_0
    //   790: aload #15
    //   792: invokevirtual Q : (Landroid/view/View;)I
    //   795: invokevirtual b : (Landroid/view/View;I)V
    //   798: aload_2
    //   799: getfield g : Z
    //   802: ifne -> 925
    //   805: aload_0
    //   806: invokevirtual J0 : ()Z
    //   809: ifeq -> 925
    //   812: aload_0
    //   813: getfield r : Landroidx/recyclerview/widget/s;
    //   816: aload #15
    //   818: invokevirtual e : (Landroid/view/View;)I
    //   821: istore #4
    //   823: aload_0
    //   824: getfield r : Landroidx/recyclerview/widget/s;
    //   827: aload #15
    //   829: invokevirtual b : (Landroid/view/View;)I
    //   832: istore #7
    //   834: aload_0
    //   835: getfield r : Landroidx/recyclerview/widget/s;
    //   838: invokevirtual k : ()I
    //   841: istore #6
    //   843: aload_0
    //   844: getfield r : Landroidx/recyclerview/widget/s;
    //   847: invokevirtual g : ()I
    //   850: istore #5
    //   852: iload #7
    //   854: iload #6
    //   856: if_icmpgt -> 871
    //   859: iload #4
    //   861: iload #6
    //   863: if_icmpge -> 871
    //   866: iconst_1
    //   867: istore_3
    //   868: goto -> 873
    //   871: iconst_0
    //   872: istore_3
    //   873: iload #4
    //   875: iload #5
    //   877: if_icmplt -> 893
    //   880: iload #7
    //   882: iload #5
    //   884: if_icmple -> 893
    //   887: iconst_1
    //   888: istore #4
    //   890: goto -> 896
    //   893: iconst_0
    //   894: istore #4
    //   896: iload_3
    //   897: ifne -> 905
    //   900: iload #4
    //   902: ifeq -> 925
    //   905: iload #6
    //   907: istore_3
    //   908: aload #14
    //   910: getfield d : Z
    //   913: ifeq -> 919
    //   916: iload #5
    //   918: istore_3
    //   919: aload #14
    //   921: iload_3
    //   922: putfield c : I
    //   925: iconst_1
    //   926: istore_3
    //   927: goto -> 932
    //   930: iconst_0
    //   931: istore_3
    //   932: iload_3
    //   933: ifeq -> 939
    //   936: goto -> 969
    //   939: aload #14
    //   941: invokevirtual a : ()V
    //   944: aload_0
    //   945: getfield v : Z
    //   948: ifeq -> 961
    //   951: aload_2
    //   952: invokevirtual b : ()I
    //   955: iconst_1
    //   956: isub
    //   957: istore_3
    //   958: goto -> 963
    //   961: iconst_0
    //   962: istore_3
    //   963: aload #14
    //   965: iload_3
    //   966: putfield b : I
    //   969: aload_0
    //   970: getfield A : Landroidx/recyclerview/widget/LinearLayoutManager$a;
    //   973: iconst_1
    //   974: putfield e : Z
    //   977: aload_0
    //   978: getfield q : Landroidx/recyclerview/widget/LinearLayoutManager$c;
    //   981: astore #14
    //   983: aload #14
    //   985: getfield j : I
    //   988: iflt -> 996
    //   991: iconst_1
    //   992: istore_3
    //   993: goto -> 998
    //   996: iconst_m1
    //   997: istore_3
    //   998: aload #14
    //   1000: iload_3
    //   1001: putfield f : I
    //   1004: aload_0
    //   1005: getfield D : [I
    //   1008: astore #14
    //   1010: aload #14
    //   1012: iconst_0
    //   1013: iconst_0
    //   1014: iastore
    //   1015: aload #14
    //   1017: iconst_1
    //   1018: iconst_0
    //   1019: iastore
    //   1020: aload_0
    //   1021: aload_2
    //   1022: aload #14
    //   1024: invokevirtual K0 : (Landroidx/recyclerview/widget/RecyclerView$x;[I)V
    //   1027: iconst_0
    //   1028: aload_0
    //   1029: getfield D : [I
    //   1032: iconst_0
    //   1033: iaload
    //   1034: invokestatic max : (II)I
    //   1037: istore_3
    //   1038: aload_0
    //   1039: getfield r : Landroidx/recyclerview/widget/s;
    //   1042: invokevirtual k : ()I
    //   1045: iload_3
    //   1046: iadd
    //   1047: istore #5
    //   1049: iconst_0
    //   1050: aload_0
    //   1051: getfield D : [I
    //   1054: iconst_1
    //   1055: iaload
    //   1056: invokestatic max : (II)I
    //   1059: istore_3
    //   1060: aload_0
    //   1061: getfield r : Landroidx/recyclerview/widget/s;
    //   1064: invokevirtual h : ()I
    //   1067: iload_3
    //   1068: iadd
    //   1069: istore #6
    //   1071: iload #5
    //   1073: istore_3
    //   1074: iload #6
    //   1076: istore #4
    //   1078: aload_2
    //   1079: getfield g : Z
    //   1082: ifeq -> 1228
    //   1085: aload_0
    //   1086: getfield x : I
    //   1089: istore #7
    //   1091: iload #5
    //   1093: istore_3
    //   1094: iload #6
    //   1096: istore #4
    //   1098: iload #7
    //   1100: iconst_m1
    //   1101: if_icmpeq -> 1228
    //   1104: iload #5
    //   1106: istore_3
    //   1107: iload #6
    //   1109: istore #4
    //   1111: aload_0
    //   1112: getfield y : I
    //   1115: ldc -2147483648
    //   1117: if_icmpeq -> 1228
    //   1120: aload_0
    //   1121: iload #7
    //   1123: invokevirtual s : (I)Landroid/view/View;
    //   1126: astore #14
    //   1128: iload #5
    //   1130: istore_3
    //   1131: iload #6
    //   1133: istore #4
    //   1135: aload #14
    //   1137: ifnull -> 1228
    //   1140: aload_0
    //   1141: getfield u : Z
    //   1144: ifeq -> 1174
    //   1147: aload_0
    //   1148: getfield r : Landroidx/recyclerview/widget/s;
    //   1151: invokevirtual g : ()I
    //   1154: aload_0
    //   1155: getfield r : Landroidx/recyclerview/widget/s;
    //   1158: aload #14
    //   1160: invokevirtual b : (Landroid/view/View;)I
    //   1163: isub
    //   1164: istore #4
    //   1166: aload_0
    //   1167: getfield y : I
    //   1170: istore_3
    //   1171: goto -> 1198
    //   1174: aload_0
    //   1175: getfield r : Landroidx/recyclerview/widget/s;
    //   1178: aload #14
    //   1180: invokevirtual e : (Landroid/view/View;)I
    //   1183: aload_0
    //   1184: getfield r : Landroidx/recyclerview/widget/s;
    //   1187: invokevirtual k : ()I
    //   1190: isub
    //   1191: istore_3
    //   1192: aload_0
    //   1193: getfield y : I
    //   1196: istore #4
    //   1198: iload #4
    //   1200: iload_3
    //   1201: isub
    //   1202: istore_3
    //   1203: iload_3
    //   1204: ifle -> 1219
    //   1207: iload #5
    //   1209: iload_3
    //   1210: iadd
    //   1211: istore_3
    //   1212: iload #6
    //   1214: istore #4
    //   1216: goto -> 1228
    //   1219: iload #6
    //   1221: iload_3
    //   1222: isub
    //   1223: istore #4
    //   1225: iload #5
    //   1227: istore_3
    //   1228: aload_0
    //   1229: getfield A : Landroidx/recyclerview/widget/LinearLayoutManager$a;
    //   1232: astore #14
    //   1234: aload #14
    //   1236: getfield d : Z
    //   1239: ifeq -> 1252
    //   1242: aload_0
    //   1243: getfield u : Z
    //   1246: ifeq -> 1259
    //   1249: goto -> 1265
    //   1252: aload_0
    //   1253: getfield u : Z
    //   1256: ifeq -> 1265
    //   1259: iconst_m1
    //   1260: istore #5
    //   1262: goto -> 1268
    //   1265: iconst_1
    //   1266: istore #5
    //   1268: aload_0
    //   1269: aload_1
    //   1270: aload_2
    //   1271: aload #14
    //   1273: iload #5
    //   1275: invokevirtual f1 : (Landroidx/recyclerview/widget/RecyclerView$s;Landroidx/recyclerview/widget/RecyclerView$x;Landroidx/recyclerview/widget/LinearLayoutManager$a;I)V
    //   1278: aload_0
    //   1279: aload_1
    //   1280: invokevirtual q : (Landroidx/recyclerview/widget/RecyclerView$s;)V
    //   1283: aload_0
    //   1284: getfield q : Landroidx/recyclerview/widget/LinearLayoutManager$c;
    //   1287: aload_0
    //   1288: invokevirtual i1 : ()Z
    //   1291: putfield l : Z
    //   1294: aload_0
    //   1295: getfield q : Landroidx/recyclerview/widget/LinearLayoutManager$c;
    //   1298: invokestatic requireNonNull : (Ljava/lang/Object;)Ljava/lang/Object;
    //   1301: pop
    //   1302: aload_0
    //   1303: getfield q : Landroidx/recyclerview/widget/LinearLayoutManager$c;
    //   1306: iconst_0
    //   1307: putfield i : I
    //   1310: aload_0
    //   1311: getfield A : Landroidx/recyclerview/widget/LinearLayoutManager$a;
    //   1314: astore #14
    //   1316: aload #14
    //   1318: getfield d : Z
    //   1321: ifeq -> 1537
    //   1324: aload_0
    //   1325: aload #14
    //   1327: getfield b : I
    //   1330: aload #14
    //   1332: getfield c : I
    //   1335: invokevirtual p1 : (II)V
    //   1338: aload_0
    //   1339: getfield q : Landroidx/recyclerview/widget/LinearLayoutManager$c;
    //   1342: astore #14
    //   1344: aload #14
    //   1346: iload_3
    //   1347: putfield h : I
    //   1350: aload_0
    //   1351: aload_1
    //   1352: aload #14
    //   1354: aload_2
    //   1355: iconst_0
    //   1356: invokevirtual R0 : (Landroidx/recyclerview/widget/RecyclerView$s;Landroidx/recyclerview/widget/LinearLayoutManager$c;Landroidx/recyclerview/widget/RecyclerView$x;Z)I
    //   1359: pop
    //   1360: aload_0
    //   1361: getfield q : Landroidx/recyclerview/widget/LinearLayoutManager$c;
    //   1364: astore #14
    //   1366: aload #14
    //   1368: getfield b : I
    //   1371: istore #5
    //   1373: aload #14
    //   1375: getfield d : I
    //   1378: istore #7
    //   1380: aload #14
    //   1382: getfield c : I
    //   1385: istore #6
    //   1387: iload #4
    //   1389: istore_3
    //   1390: iload #6
    //   1392: ifle -> 1401
    //   1395: iload #4
    //   1397: iload #6
    //   1399: iadd
    //   1400: istore_3
    //   1401: aload_0
    //   1402: getfield A : Landroidx/recyclerview/widget/LinearLayoutManager$a;
    //   1405: astore #14
    //   1407: aload_0
    //   1408: aload #14
    //   1410: getfield b : I
    //   1413: aload #14
    //   1415: getfield c : I
    //   1418: invokevirtual o1 : (II)V
    //   1421: aload_0
    //   1422: getfield q : Landroidx/recyclerview/widget/LinearLayoutManager$c;
    //   1425: astore #14
    //   1427: aload #14
    //   1429: iload_3
    //   1430: putfield h : I
    //   1433: aload #14
    //   1435: aload #14
    //   1437: getfield d : I
    //   1440: aload #14
    //   1442: getfield e : I
    //   1445: iadd
    //   1446: putfield d : I
    //   1449: aload_0
    //   1450: aload_1
    //   1451: aload #14
    //   1453: aload_2
    //   1454: iconst_0
    //   1455: invokevirtual R0 : (Landroidx/recyclerview/widget/RecyclerView$s;Landroidx/recyclerview/widget/LinearLayoutManager$c;Landroidx/recyclerview/widget/RecyclerView$x;Z)I
    //   1458: pop
    //   1459: aload_0
    //   1460: getfield q : Landroidx/recyclerview/widget/LinearLayoutManager$c;
    //   1463: astore #14
    //   1465: aload #14
    //   1467: getfield b : I
    //   1470: istore #6
    //   1472: aload #14
    //   1474: getfield c : I
    //   1477: istore #8
    //   1479: iload #5
    //   1481: istore #4
    //   1483: iload #6
    //   1485: istore_3
    //   1486: iload #8
    //   1488: ifle -> 1749
    //   1491: aload_0
    //   1492: iload #7
    //   1494: iload #5
    //   1496: invokevirtual p1 : (II)V
    //   1499: aload_0
    //   1500: getfield q : Landroidx/recyclerview/widget/LinearLayoutManager$c;
    //   1503: astore #14
    //   1505: aload #14
    //   1507: iload #8
    //   1509: putfield h : I
    //   1512: aload_0
    //   1513: aload_1
    //   1514: aload #14
    //   1516: aload_2
    //   1517: iconst_0
    //   1518: invokevirtual R0 : (Landroidx/recyclerview/widget/RecyclerView$s;Landroidx/recyclerview/widget/LinearLayoutManager$c;Landroidx/recyclerview/widget/RecyclerView$x;Z)I
    //   1521: pop
    //   1522: aload_0
    //   1523: getfield q : Landroidx/recyclerview/widget/LinearLayoutManager$c;
    //   1526: getfield b : I
    //   1529: istore #4
    //   1531: iload #6
    //   1533: istore_3
    //   1534: goto -> 1749
    //   1537: aload_0
    //   1538: aload #14
    //   1540: getfield b : I
    //   1543: aload #14
    //   1545: getfield c : I
    //   1548: invokevirtual o1 : (II)V
    //   1551: aload_0
    //   1552: getfield q : Landroidx/recyclerview/widget/LinearLayoutManager$c;
    //   1555: astore #14
    //   1557: aload #14
    //   1559: iload #4
    //   1561: putfield h : I
    //   1564: aload_0
    //   1565: aload_1
    //   1566: aload #14
    //   1568: aload_2
    //   1569: iconst_0
    //   1570: invokevirtual R0 : (Landroidx/recyclerview/widget/RecyclerView$s;Landroidx/recyclerview/widget/LinearLayoutManager$c;Landroidx/recyclerview/widget/RecyclerView$x;Z)I
    //   1573: pop
    //   1574: aload_0
    //   1575: getfield q : Landroidx/recyclerview/widget/LinearLayoutManager$c;
    //   1578: astore #14
    //   1580: aload #14
    //   1582: getfield b : I
    //   1585: istore #5
    //   1587: aload #14
    //   1589: getfield d : I
    //   1592: istore #7
    //   1594: aload #14
    //   1596: getfield c : I
    //   1599: istore #6
    //   1601: iload_3
    //   1602: istore #4
    //   1604: iload #6
    //   1606: ifle -> 1615
    //   1609: iload_3
    //   1610: iload #6
    //   1612: iadd
    //   1613: istore #4
    //   1615: aload_0
    //   1616: getfield A : Landroidx/recyclerview/widget/LinearLayoutManager$a;
    //   1619: astore #14
    //   1621: aload_0
    //   1622: aload #14
    //   1624: getfield b : I
    //   1627: aload #14
    //   1629: getfield c : I
    //   1632: invokevirtual p1 : (II)V
    //   1635: aload_0
    //   1636: getfield q : Landroidx/recyclerview/widget/LinearLayoutManager$c;
    //   1639: astore #14
    //   1641: aload #14
    //   1643: iload #4
    //   1645: putfield h : I
    //   1648: aload #14
    //   1650: aload #14
    //   1652: getfield d : I
    //   1655: aload #14
    //   1657: getfield e : I
    //   1660: iadd
    //   1661: putfield d : I
    //   1664: aload_0
    //   1665: aload_1
    //   1666: aload #14
    //   1668: aload_2
    //   1669: iconst_0
    //   1670: invokevirtual R0 : (Landroidx/recyclerview/widget/RecyclerView$s;Landroidx/recyclerview/widget/LinearLayoutManager$c;Landroidx/recyclerview/widget/RecyclerView$x;Z)I
    //   1673: pop
    //   1674: aload_0
    //   1675: getfield q : Landroidx/recyclerview/widget/LinearLayoutManager$c;
    //   1678: astore #14
    //   1680: aload #14
    //   1682: getfield b : I
    //   1685: istore #6
    //   1687: aload #14
    //   1689: getfield c : I
    //   1692: istore #8
    //   1694: iload #6
    //   1696: istore #4
    //   1698: iload #5
    //   1700: istore_3
    //   1701: iload #8
    //   1703: ifle -> 1749
    //   1706: aload_0
    //   1707: iload #7
    //   1709: iload #5
    //   1711: invokevirtual o1 : (II)V
    //   1714: aload_0
    //   1715: getfield q : Landroidx/recyclerview/widget/LinearLayoutManager$c;
    //   1718: astore #14
    //   1720: aload #14
    //   1722: iload #8
    //   1724: putfield h : I
    //   1727: aload_0
    //   1728: aload_1
    //   1729: aload #14
    //   1731: aload_2
    //   1732: iconst_0
    //   1733: invokevirtual R0 : (Landroidx/recyclerview/widget/RecyclerView$s;Landroidx/recyclerview/widget/LinearLayoutManager$c;Landroidx/recyclerview/widget/RecyclerView$x;Z)I
    //   1736: pop
    //   1737: aload_0
    //   1738: getfield q : Landroidx/recyclerview/widget/LinearLayoutManager$c;
    //   1741: getfield b : I
    //   1744: istore_3
    //   1745: iload #6
    //   1747: istore #4
    //   1749: iload #4
    //   1751: istore #6
    //   1753: iload_3
    //   1754: istore #5
    //   1756: aload_0
    //   1757: invokevirtual x : ()I
    //   1760: ifle -> 1857
    //   1763: aload_0
    //   1764: getfield u : Z
    //   1767: aload_0
    //   1768: getfield v : Z
    //   1771: ixor
    //   1772: ifeq -> 1811
    //   1775: aload_0
    //   1776: iload_3
    //   1777: aload_1
    //   1778: aload_2
    //   1779: iconst_1
    //   1780: invokevirtual Z0 : (ILandroidx/recyclerview/widget/RecyclerView$s;Landroidx/recyclerview/widget/RecyclerView$x;Z)I
    //   1783: istore #6
    //   1785: iload #4
    //   1787: iload #6
    //   1789: iadd
    //   1790: istore #5
    //   1792: iload_3
    //   1793: iload #6
    //   1795: iadd
    //   1796: istore #4
    //   1798: aload_0
    //   1799: iload #5
    //   1801: aload_1
    //   1802: aload_2
    //   1803: iconst_0
    //   1804: invokevirtual a1 : (ILandroidx/recyclerview/widget/RecyclerView$s;Landroidx/recyclerview/widget/RecyclerView$x;Z)I
    //   1807: istore_3
    //   1808: goto -> 1845
    //   1811: aload_0
    //   1812: iload #4
    //   1814: aload_1
    //   1815: aload_2
    //   1816: iconst_1
    //   1817: invokevirtual a1 : (ILandroidx/recyclerview/widget/RecyclerView$s;Landroidx/recyclerview/widget/RecyclerView$x;Z)I
    //   1820: istore #6
    //   1822: iload #4
    //   1824: iload #6
    //   1826: iadd
    //   1827: istore #5
    //   1829: iload_3
    //   1830: iload #6
    //   1832: iadd
    //   1833: istore #4
    //   1835: aload_0
    //   1836: iload #4
    //   1838: aload_1
    //   1839: aload_2
    //   1840: iconst_0
    //   1841: invokevirtual Z0 : (ILandroidx/recyclerview/widget/RecyclerView$s;Landroidx/recyclerview/widget/RecyclerView$x;Z)I
    //   1844: istore_3
    //   1845: iload #5
    //   1847: iload_3
    //   1848: iadd
    //   1849: istore #6
    //   1851: iload #4
    //   1853: iload_3
    //   1854: iadd
    //   1855: istore #5
    //   1857: aload_2
    //   1858: getfield k : Z
    //   1861: ifeq -> 2162
    //   1864: aload_0
    //   1865: invokevirtual x : ()I
    //   1868: ifeq -> 2162
    //   1871: aload_2
    //   1872: getfield g : Z
    //   1875: ifne -> 2162
    //   1878: aload_0
    //   1879: invokevirtual J0 : ()Z
    //   1882: ifne -> 1888
    //   1885: goto -> 2162
    //   1888: aload_1
    //   1889: getfield d : Ljava/util/List;
    //   1892: astore #14
    //   1894: aload #14
    //   1896: invokeinterface size : ()I
    //   1901: istore #9
    //   1903: aload_0
    //   1904: aload_0
    //   1905: iconst_0
    //   1906: invokevirtual w : (I)Landroid/view/View;
    //   1909: invokevirtual Q : (Landroid/view/View;)I
    //   1912: istore #10
    //   1914: iconst_0
    //   1915: istore_3
    //   1916: iconst_0
    //   1917: istore #7
    //   1919: iconst_0
    //   1920: istore #4
    //   1922: iload_3
    //   1923: iload #9
    //   1925: if_icmpge -> 2033
    //   1928: aload #14
    //   1930: iload_3
    //   1931: invokeinterface get : (I)Ljava/lang/Object;
    //   1936: checkcast androidx/recyclerview/widget/RecyclerView$a0
    //   1939: astore #15
    //   1941: aload #15
    //   1943: invokevirtual w : ()Z
    //   1946: ifeq -> 1952
    //   1949: goto -> 2026
    //   1952: aload #15
    //   1954: invokevirtual p : ()I
    //   1957: iload #10
    //   1959: if_icmpge -> 1968
    //   1962: iconst_1
    //   1963: istore #12
    //   1965: goto -> 1971
    //   1968: iconst_0
    //   1969: istore #12
    //   1971: iload #12
    //   1973: aload_0
    //   1974: getfield u : Z
    //   1977: if_icmpeq -> 1986
    //   1980: iconst_m1
    //   1981: istore #8
    //   1983: goto -> 1989
    //   1986: iconst_1
    //   1987: istore #8
    //   1989: aload_0
    //   1990: getfield r : Landroidx/recyclerview/widget/s;
    //   1993: aload #15
    //   1995: getfield h : Landroid/view/View;
    //   1998: invokevirtual c : (Landroid/view/View;)I
    //   2001: istore #11
    //   2003: iload #8
    //   2005: iconst_m1
    //   2006: if_icmpne -> 2019
    //   2009: iload #7
    //   2011: iload #11
    //   2013: iadd
    //   2014: istore #7
    //   2016: goto -> 2026
    //   2019: iload #4
    //   2021: iload #11
    //   2023: iadd
    //   2024: istore #4
    //   2026: iload_3
    //   2027: iconst_1
    //   2028: iadd
    //   2029: istore_3
    //   2030: goto -> 1922
    //   2033: aload_0
    //   2034: getfield q : Landroidx/recyclerview/widget/LinearLayoutManager$c;
    //   2037: aload #14
    //   2039: putfield k : Ljava/util/List;
    //   2042: iload #7
    //   2044: ifle -> 2098
    //   2047: aload_0
    //   2048: aload_0
    //   2049: aload_0
    //   2050: invokevirtual c1 : ()Landroid/view/View;
    //   2053: invokevirtual Q : (Landroid/view/View;)I
    //   2056: iload #6
    //   2058: invokevirtual p1 : (II)V
    //   2061: aload_0
    //   2062: getfield q : Landroidx/recyclerview/widget/LinearLayoutManager$c;
    //   2065: astore #14
    //   2067: aload #14
    //   2069: iload #7
    //   2071: putfield h : I
    //   2074: aload #14
    //   2076: iconst_0
    //   2077: putfield c : I
    //   2080: aload #14
    //   2082: aconst_null
    //   2083: invokevirtual a : (Landroid/view/View;)V
    //   2086: aload_0
    //   2087: aload_1
    //   2088: aload_0
    //   2089: getfield q : Landroidx/recyclerview/widget/LinearLayoutManager$c;
    //   2092: aload_2
    //   2093: iconst_0
    //   2094: invokevirtual R0 : (Landroidx/recyclerview/widget/RecyclerView$s;Landroidx/recyclerview/widget/LinearLayoutManager$c;Landroidx/recyclerview/widget/RecyclerView$x;Z)I
    //   2097: pop
    //   2098: iload #4
    //   2100: ifle -> 2154
    //   2103: aload_0
    //   2104: aload_0
    //   2105: aload_0
    //   2106: invokevirtual b1 : ()Landroid/view/View;
    //   2109: invokevirtual Q : (Landroid/view/View;)I
    //   2112: iload #5
    //   2114: invokevirtual o1 : (II)V
    //   2117: aload_0
    //   2118: getfield q : Landroidx/recyclerview/widget/LinearLayoutManager$c;
    //   2121: astore #14
    //   2123: aload #14
    //   2125: iload #4
    //   2127: putfield h : I
    //   2130: aload #14
    //   2132: iconst_0
    //   2133: putfield c : I
    //   2136: aload #14
    //   2138: aconst_null
    //   2139: invokevirtual a : (Landroid/view/View;)V
    //   2142: aload_0
    //   2143: aload_1
    //   2144: aload_0
    //   2145: getfield q : Landroidx/recyclerview/widget/LinearLayoutManager$c;
    //   2148: aload_2
    //   2149: iconst_0
    //   2150: invokevirtual R0 : (Landroidx/recyclerview/widget/RecyclerView$s;Landroidx/recyclerview/widget/LinearLayoutManager$c;Landroidx/recyclerview/widget/RecyclerView$x;Z)I
    //   2153: pop
    //   2154: aload_0
    //   2155: getfield q : Landroidx/recyclerview/widget/LinearLayoutManager$c;
    //   2158: aconst_null
    //   2159: putfield k : Ljava/util/List;
    //   2162: aload_2
    //   2163: getfield g : Z
    //   2166: ifne -> 2185
    //   2169: aload_0
    //   2170: getfield r : Landroidx/recyclerview/widget/s;
    //   2173: astore_1
    //   2174: aload_1
    //   2175: aload_1
    //   2176: invokevirtual l : ()I
    //   2179: putfield b : I
    //   2182: goto -> 2192
    //   2185: aload_0
    //   2186: getfield A : Landroidx/recyclerview/widget/LinearLayoutManager$a;
    //   2189: invokevirtual d : ()V
    //   2192: aload_0
    //   2193: aload_0
    //   2194: getfield v : Z
    //   2197: putfield s : Z
    //   2200: return
  }
  
  public int k1(int paramInt, RecyclerView.s params, RecyclerView.x paramx) {
    if (x() != 0) {
      byte b1;
      if (paramInt == 0)
        return 0; 
      Q0();
      this.q.a = true;
      if (paramInt > 0) {
        b1 = 1;
      } else {
        b1 = -1;
      } 
      int i = Math.abs(paramInt);
      n1(b1, i, true, paramx);
      c c1 = this.q;
      int j = c1.g;
      j = R0(params, c1, paramx, false) + j;
      if (j < 0)
        return 0; 
      if (i > j)
        paramInt = b1 * j; 
      this.r.p(-paramInt);
      this.q.j = paramInt;
      return paramInt;
    } 
    return 0;
  }
  
  public int l(RecyclerView.x paramx) {
    return N0(paramx);
  }
  
  public void l0(RecyclerView.x paramx) {
    this.z = null;
    this.x = -1;
    this.y = Integer.MIN_VALUE;
    this.A.d();
  }
  
  public void l1(int paramInt) {
    if (paramInt == 0 || paramInt == 1) {
      d(null);
      if (paramInt != this.p || this.r == null) {
        s s1 = s.a(this, paramInt);
        this.r = s1;
        this.A.a = s1;
        this.p = paramInt;
        v0();
      } 
      return;
    } 
    throw new IllegalArgumentException(y.a("invalid orientation:", paramInt));
  }
  
  public int m(RecyclerView.x paramx) {
    return O0(paramx);
  }
  
  public void m0(Parcelable paramParcelable) {
    if (paramParcelable instanceof d) {
      paramParcelable = paramParcelable;
      this.z = (d)paramParcelable;
      if (this.x != -1)
        ((d)paramParcelable).h = -1; 
      v0();
    } 
  }
  
  public void m1(boolean paramBoolean) {
    d(null);
    if (this.v == paramBoolean)
      return; 
    this.v = paramBoolean;
    v0();
  }
  
  public int n(RecyclerView.x paramx) {
    return M0(paramx);
  }
  
  public Parcelable n0() {
    d d1 = this.z;
    if (d1 != null)
      return new d(d1); 
    d1 = new d();
    if (x() > 0) {
      Q0();
      int i = this.s ^ this.u;
      d1.j = i;
      if (i != 0) {
        View view1 = b1();
        d1.i = this.r.g() - this.r.b(view1);
        d1.h = Q(view1);
        return d1;
      } 
      View view = c1();
      d1.h = Q(view);
      d1.i = this.r.e(view) - this.r.k();
      return d1;
    } 
    d1.h = -1;
    return d1;
  }
  
  public final void n1(int paramInt1, int paramInt2, boolean paramBoolean, RecyclerView.x paramx) {
    this.q.l = i1();
    this.q.f = paramInt1;
    int[] arrayOfInt = this.D;
    boolean bool1 = false;
    arrayOfInt[0] = 0;
    boolean bool2 = true;
    boolean bool3 = true;
    arrayOfInt[1] = 0;
    K0(paramx, arrayOfInt);
    int i = Math.max(0, this.D[0]);
    int j = Math.max(0, this.D[1]);
    if (paramInt1 == 1)
      bool1 = true; 
    c c1 = this.q;
    if (bool1) {
      paramInt1 = j;
    } else {
      paramInt1 = i;
    } 
    c1.h = paramInt1;
    if (!bool1)
      i = j; 
    c1.i = i;
    if (bool1) {
      c1.h = this.r.h() + paramInt1;
      View view = b1();
      c c2 = this.q;
      paramInt1 = bool3;
      if (this.u)
        paramInt1 = -1; 
      c2.e = paramInt1;
      paramInt1 = Q(view);
      c c3 = this.q;
      c2.d = paramInt1 + c3.e;
      c3.b = this.r.b(view);
      paramInt1 = this.r.b(view) - this.r.g();
    } else {
      View view = c1();
      c c2 = this.q;
      paramInt1 = c2.h;
      c2.h = this.r.k() + paramInt1;
      c2 = this.q;
      if (this.u) {
        paramInt1 = bool2;
      } else {
        paramInt1 = -1;
      } 
      c2.e = paramInt1;
      paramInt1 = Q(view);
      c c3 = this.q;
      c2.d = paramInt1 + c3.e;
      c3.b = this.r.e(view);
      paramInt1 = -this.r.e(view) + this.r.k();
    } 
    c1 = this.q;
    c1.c = paramInt2;
    if (paramBoolean)
      c1.c = paramInt2 - paramInt1; 
    c1.g = paramInt1;
  }
  
  public int o(RecyclerView.x paramx) {
    return N0(paramx);
  }
  
  public final void o1(int paramInt1, int paramInt2) {
    boolean bool;
    this.q.c = this.r.g() - paramInt2;
    c c1 = this.q;
    if (this.u) {
      bool = true;
    } else {
      bool = true;
    } 
    c1.e = bool;
    c1.d = paramInt1;
    c1.f = 1;
    c1.b = paramInt2;
    c1.g = Integer.MIN_VALUE;
  }
  
  public int p(RecyclerView.x paramx) {
    return O0(paramx);
  }
  
  public final void p1(int paramInt1, int paramInt2) {
    this.q.c = paramInt2 - this.r.k();
    c c1 = this.q;
    c1.d = paramInt1;
    if (this.u) {
      paramInt1 = 1;
    } else {
      paramInt1 = -1;
    } 
    c1.e = paramInt1;
    c1.f = -1;
    c1.b = paramInt2;
    c1.g = Integer.MIN_VALUE;
  }
  
  public View s(int paramInt) {
    int i = x();
    if (i == 0)
      return null; 
    int j = paramInt - Q(w(0));
    if (j >= 0 && j < i) {
      View view = w(j);
      if (Q(view) == paramInt)
        return view; 
    } 
    return super.s(paramInt);
  }
  
  public RecyclerView.n t() {
    return new RecyclerView.n(-2, -2);
  }
  
  public int w0(int paramInt, RecyclerView.s params, RecyclerView.x paramx) {
    return (this.p == 1) ? 0 : k1(paramInt, params, paramx);
  }
  
  public void x0(int paramInt) {
    this.x = paramInt;
    this.y = Integer.MIN_VALUE;
    d d1 = this.z;
    if (d1 != null)
      d1.h = -1; 
    v0();
  }
  
  public int y0(int paramInt, RecyclerView.s params, RecyclerView.x paramx) {
    return (this.p == 0) ? 0 : k1(paramInt, params, paramx);
  }
  
  public static class a {
    public s a;
    
    public int b;
    
    public int c;
    
    public boolean d;
    
    public boolean e;
    
    public a() {
      d();
    }
    
    public void a() {
      int i;
      if (this.d) {
        i = this.a.g();
      } else {
        i = this.a.k();
      } 
      this.c = i;
    }
    
    public void b(View param1View, int param1Int) {
      if (this.d) {
        int i = this.a.b(param1View);
        this.c = this.a.m() + i;
      } else {
        this.c = this.a.e(param1View);
      } 
      this.b = param1Int;
    }
    
    public void c(View param1View, int param1Int) {
      int i = this.a.m();
      if (i >= 0) {
        b(param1View, param1Int);
        return;
      } 
      this.b = param1Int;
      if (this.d) {
        param1Int = this.a.g() - i - this.a.b(param1View);
        this.c = this.a.g() - param1Int;
        if (param1Int > 0) {
          i = this.a.c(param1View);
          int j = this.c;
          int k = this.a.k();
          i = j - i - Math.min(this.a.e(param1View) - k, 0) + k;
          if (i < 0) {
            j = this.c;
            param1Int = Math.min(param1Int, -i) + j;
          } else {
            return;
          } 
        } else {
          return;
        } 
      } else {
        int j = this.a.e(param1View);
        param1Int = j - this.a.k();
        this.c = j;
        if (param1Int > 0) {
          int k = this.a.c(param1View);
          int m = this.a.g();
          int n = this.a.b(param1View);
          i = this.a.g() - Math.min(0, m - i - n) - k + j;
          if (i < 0) {
            param1Int = this.c - Math.min(param1Int, -i);
          } else {
            return;
          } 
        } else {
          return;
        } 
      } 
      this.c = param1Int;
    }
    
    public void d() {
      this.b = -1;
      this.c = Integer.MIN_VALUE;
      this.d = false;
      this.e = false;
    }
    
    public String toString() {
      StringBuilder stringBuilder = android.support.v4.media.c.a("AnchorInfo{mPosition=");
      stringBuilder.append(this.b);
      stringBuilder.append(", mCoordinate=");
      stringBuilder.append(this.c);
      stringBuilder.append(", mLayoutFromEnd=");
      stringBuilder.append(this.d);
      stringBuilder.append(", mValid=");
      stringBuilder.append(this.e);
      stringBuilder.append('}');
      return stringBuilder.toString();
    }
  }
  
  public static class b {
    public int a;
    
    public boolean b;
    
    public boolean c;
    
    public boolean d;
  }
  
  public static class c {
    public boolean a = true;
    
    public int b;
    
    public int c;
    
    public int d;
    
    public int e;
    
    public int f;
    
    public int g;
    
    public int h = 0;
    
    public int i = 0;
    
    public int j;
    
    public List<RecyclerView.a0> k = null;
    
    public boolean l;
    
    public void a(View param1View) {
      View view2;
      int k = this.k.size();
      View view1 = null;
      int j = Integer.MAX_VALUE;
      int i = 0;
      while (true) {
        view2 = view1;
        if (i < k) {
          View view = ((RecyclerView.a0)this.k.get(i)).h;
          RecyclerView.n n = (RecyclerView.n)view.getLayoutParams();
          view2 = view1;
          int m = j;
          if (view != param1View)
            if (n.c()) {
              view2 = view1;
              m = j;
            } else {
              int i1 = (n.a() - this.d) * this.e;
              if (i1 < 0) {
                view2 = view1;
                m = j;
              } else {
                view2 = view1;
                m = j;
                if (i1 < j) {
                  view1 = view;
                  if (i1 == 0) {
                    view2 = view1;
                    break;
                  } 
                  m = i1;
                  view2 = view1;
                } 
              } 
            }  
          i++;
          view1 = view2;
          j = m;
          continue;
        } 
        break;
      } 
      if (view2 == null) {
        i = -1;
      } else {
        i = ((RecyclerView.n)view2.getLayoutParams()).a();
      } 
      this.d = i;
    }
    
    public boolean b(RecyclerView.x param1x) {
      int i = this.d;
      return (i >= 0 && i < param1x.b());
    }
    
    public View c(RecyclerView.s param1s) {
      List<RecyclerView.a0> list = this.k;
      int i = 0;
      if (list != null) {
        int j = list.size();
        while (i < j) {
          view = ((RecyclerView.a0)this.k.get(i)).h;
          RecyclerView.n n = (RecyclerView.n)view.getLayoutParams();
          if (!n.c() && this.d == n.a()) {
            a(view);
            return view;
          } 
          i++;
        } 
        return null;
      } 
      View view = (view.j(this.d, false, Long.MAX_VALUE)).h;
      this.d += this.e;
      return view;
    }
  }
  
  @SuppressLint({"BanParcelableUsage"})
  public static class d implements Parcelable {
    public static final Parcelable.Creator<d> CREATOR = new a();
    
    public int h;
    
    public int i;
    
    public boolean j;
    
    public d() {}
    
    public d(Parcel param1Parcel) {
      this.h = param1Parcel.readInt();
      this.i = param1Parcel.readInt();
      int i = param1Parcel.readInt();
      boolean bool = true;
      if (i != 1)
        bool = false; 
      this.j = bool;
    }
    
    public d(d param1d) {
      this.h = param1d.h;
      this.i = param1d.i;
      this.j = param1d.j;
    }
    
    public boolean b() {
      return (this.h >= 0);
    }
    
    public int describeContents() {
      return 0;
    }
    
    public void writeToParcel(Parcel param1Parcel, int param1Int) {
      throw new RuntimeException("d2j fail translate: java.lang.RuntimeException: can not merge I and Z\r\n\tat com.googlecode.dex2jar.ir.TypeClass.merge(TypeClass.java:100)\r\n\tat com.googlecode.dex2jar.ir.ts.TypeTransformer$TypeRef.updateTypeClass(TypeTransformer.java:174)\r\n\tat com.googlecode.dex2jar.ir.ts.TypeTransformer$TypeAnalyze.provideAs(TypeTransformer.java:780)\r\n\tat com.googlecode.dex2jar.ir.ts.TypeTransformer$TypeAnalyze.e1expr(TypeTransformer.java:496)\r\n\tat com.googlecode.dex2jar.ir.ts.TypeTransformer$TypeAnalyze.exExpr(TypeTransformer.java:713)\r\n\tat com.googlecode.dex2jar.ir.ts.TypeTransformer$TypeAnalyze.exExpr(TypeTransformer.java:703)\r\n\tat com.googlecode.dex2jar.ir.ts.TypeTransformer$TypeAnalyze.enexpr(TypeTransformer.java:698)\r\n\tat com.googlecode.dex2jar.ir.ts.TypeTransformer$TypeAnalyze.exExpr(TypeTransformer.java:719)\r\n\tat com.googlecode.dex2jar.ir.ts.TypeTransformer$TypeAnalyze.exExpr(TypeTransformer.java:703)\r\n\tat com.googlecode.dex2jar.ir.ts.TypeTransformer$TypeAnalyze.s1stmt(TypeTransformer.java:810)\r\n\tat com.googlecode.dex2jar.ir.ts.TypeTransformer$TypeAnalyze.sxStmt(TypeTransformer.java:840)\r\n\tat com.googlecode.dex2jar.ir.ts.TypeTransformer$TypeAnalyze.analyze(TypeTransformer.java:206)\r\n\tat com.googlecode.dex2jar.ir.ts.TypeTransformer.transform(TypeTransformer.java:44)\r\n\tat com.googlecode.d2j.dex.Dex2jar$2.optimize(Dex2jar.java:162)\r\n\tat com.googlecode.d2j.dex.Dex2Asm.convertCode(Dex2Asm.java:414)\r\n\tat com.googlecode.d2j.dex.ExDex2Asm.convertCode(ExDex2Asm.java:42)\r\n\tat com.googlecode.d2j.dex.Dex2jar$2.convertCode(Dex2jar.java:128)\r\n\tat com.googlecode.d2j.dex.Dex2Asm.convertMethod(Dex2Asm.java:509)\r\n\tat com.googlecode.d2j.dex.Dex2Asm.convertClass(Dex2Asm.java:406)\r\n\tat com.googlecode.d2j.dex.Dex2Asm.convertDex(Dex2Asm.java:422)\r\n\tat com.googlecode.d2j.dex.Dex2jar.doTranslate(Dex2jar.java:172)\r\n\tat com.googlecode.d2j.dex.Dex2jar.to(Dex2jar.java:272)\r\n\tat com.googlecode.dex2jar.tools.Dex2jarCmd.doCommandLine(Dex2jarCmd.java:108)\r\n\tat com.googlecode.dex2jar.tools.BaseCmd.doMain(BaseCmd.java:288)\r\n\tat com.googlecode.dex2jar.tools.Dex2jarCmd.main(Dex2jarCmd.java:32)\r\n");
    }
    
    public class a implements Parcelable.Creator<d> {
      public Object createFromParcel(Parcel param2Parcel) {
        return new LinearLayoutManager.d(param2Parcel);
      }
      
      public Object[] newArray(int param2Int) {
        return (Object[])new LinearLayoutManager.d[param2Int];
      }
    }
  }
  
  public class a implements Parcelable.Creator<d> {
    public Object createFromParcel(Parcel param1Parcel) {
      return new LinearLayoutManager.d(param1Parcel);
    }
    
    public Object[] newArray(int param1Int) {
      return (Object[])new LinearLayoutManager.d[param1Int];
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Luxury Logo Maker_ Logo Design-dex2jar.jar!\androidx\recyclerview\widget\LinearLayoutManager.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */