package androidx.recyclerview.widget;

import android.annotation.SuppressLint;
import android.content.Context;
import android.graphics.PointF;
import android.graphics.Rect;
import android.os.Parcel;
import android.os.Parcelable;
import android.util.AttributeSet;
import android.view.View;
import android.view.ViewGroup;
import android.view.accessibility.AccessibilityEvent;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.BitSet;
import java.util.List;
import java.util.Objects;

public class StaggeredGridLayoutManager extends RecyclerView.m implements RecyclerView.w.b {
  public int A = Integer.MIN_VALUE;
  
  public d B = new d();
  
  public int C = 2;
  
  public boolean D;
  
  public boolean E;
  
  public e F;
  
  public final Rect G = new Rect();
  
  public final b H = new b(this);
  
  public boolean I = true;
  
  public int[] J;
  
  public final Runnable K = new a(this);
  
  public int p = -1;
  
  public f[] q;
  
  public s r;
  
  public s s;
  
  public int t;
  
  public int u;
  
  public final n v;
  
  public boolean w = false;
  
  public boolean x = false;
  
  public BitSet y;
  
  public int z = -1;
  
  public StaggeredGridLayoutManager(int paramInt1, int paramInt2) {
    this.t = paramInt2;
    l1(paramInt1);
    this.v = new n();
    this.r = s.a(this, this.t);
    this.s = s.a(this, 1 - this.t);
  }
  
  public StaggeredGridLayoutManager(Context paramContext, AttributeSet paramAttributeSet, int paramInt1, int paramInt2) {
    RecyclerView.m.d d1 = RecyclerView.m.R(paramContext, paramAttributeSet, paramInt1, paramInt2);
    paramInt1 = d1.a;
    if (paramInt1 == 0 || paramInt1 == 1) {
      d(null);
      if (paramInt1 != this.t) {
        this.t = paramInt1;
        s s1 = this.r;
        this.r = this.s;
        this.s = s1;
        v0();
      } 
      l1(d1.b);
      boolean bool = d1.c;
      d(null);
      e e1 = this.F;
      if (e1 != null && e1.o != bool)
        e1.o = bool; 
      this.w = bool;
      v0();
      this.v = new n();
      this.r = s.a(this, this.t);
      this.s = s.a(this, 1 - this.t);
      return;
    } 
    throw new IllegalArgumentException("invalid orientation.");
  }
  
  public void B0(Rect paramRect, int paramInt1, int paramInt2) {
    int i = N();
    i = O() + i;
    int j = P();
    j = M() + j;
    if (this.t == 1) {
      paramInt2 = RecyclerView.m.h(paramInt2, paramRect.height() + j, K());
      i = RecyclerView.m.h(paramInt1, this.u * this.p + i, L());
      paramInt1 = paramInt2;
      paramInt2 = i;
    } else {
      paramInt1 = RecyclerView.m.h(paramInt1, paramRect.width() + i, L());
      i = RecyclerView.m.h(paramInt2, this.u * this.p + j, K());
      paramInt2 = paramInt1;
      paramInt1 = i;
    } 
    RecyclerView.e(this.b, paramInt2, paramInt1);
  }
  
  public void H0(RecyclerView paramRecyclerView, RecyclerView.x paramx, int paramInt) {
    o o = new o(paramRecyclerView.getContext());
    o.a = paramInt;
    I0(o);
  }
  
  public boolean J0() {
    return (this.F == null);
  }
  
  public final int K0(int paramInt) {
    boolean bool;
    int i = x();
    byte b1 = -1;
    if (i == 0) {
      paramInt = b1;
      if (this.x)
        paramInt = 1; 
      return paramInt;
    } 
    if (paramInt < U0()) {
      bool = true;
    } else {
      bool = false;
    } 
    return (bool != this.x) ? -1 : 1;
  }
  
  public boolean L0() {
    if (x() != 0 && this.C != 0) {
      int i;
      if (!this.g)
        return false; 
      if (this.x) {
        i = V0();
        U0();
      } else {
        i = U0();
        V0();
      } 
      if (i == 0 && Z0() != null) {
        this.B.a();
        this.f = true;
        v0();
        return true;
      } 
    } 
    return false;
  }
  
  public final int M0(RecyclerView.x paramx) {
    return (x() == 0) ? 0 : y.a(paramx, this.r, R0(this.I ^ true), Q0(this.I ^ true), this, this.I);
  }
  
  public final int N0(RecyclerView.x paramx) {
    return (x() == 0) ? 0 : y.b(paramx, this.r, R0(this.I ^ true), Q0(this.I ^ true), this, this.I, this.x);
  }
  
  public final int O0(RecyclerView.x paramx) {
    return (x() == 0) ? 0 : y.c(paramx, this.r, R0(this.I ^ true), Q0(this.I ^ true), this, this.I);
  }
  
  public final int P0(RecyclerView.s params, n paramn, RecyclerView.x paramx) {
    int j;
    int k;
    this.y.set(0, this.p, true);
    if (this.v.i) {
      if (paramn.e == 1) {
        j = Integer.MAX_VALUE;
      } else {
        j = Integer.MIN_VALUE;
      } 
    } else {
      int i1;
      if (paramn.e == 1) {
        i1 = paramn.g + paramn.b;
      } else {
        i1 = paramn.f - paramn.b;
      } 
      j = i1;
    } 
    m1(paramn.e, j);
    if (this.x) {
      k = this.r.g();
    } else {
      k = this.r.k();
    } 
    int i = 0;
    while (true) {
      int i1 = paramn.c;
      if (i1 >= 0 && i1 < paramx.b()) {
        i1 = 1;
      } else {
        i1 = 0;
      } 
      if (i1 != 0 && (this.v.i || !this.y.isEmpty())) {
        int i3;
        f f2;
        View view = (params.j(paramn.c, false, Long.MAX_VALUE)).h;
        paramn.c += paramn.d;
        c c = (c)view.getLayoutParams();
        int i4 = c.a();
        int[] arrayOfInt = this.B.a;
        if (arrayOfInt == null || i4 >= arrayOfInt.length) {
          i = -1;
        } else {
          i = arrayOfInt[i4];
        } 
        if (i == -1) {
          i1 = 1;
        } else {
          i1 = 0;
        } 
        if (i1 != 0) {
          byte b1;
          if (d1(paramn.e)) {
            i = this.p - 1;
            i1 = -1;
            b1 = -1;
          } else {
            i1 = this.p;
            i = 0;
            b1 = 1;
          } 
          i3 = paramn.e;
          int[] arrayOfInt1 = null;
          arrayOfInt = null;
          if (i3 == 1) {
            int i5 = this.r.k();
            i3 = Integer.MAX_VALUE;
            while (true) {
              arrayOfInt1 = arrayOfInt;
              if (i != i1) {
                f2 = this.q[i];
                int i7 = f2.h(i5);
                int i6 = i3;
                if (i7 < i3) {
                  f f3 = f2;
                  i6 = i7;
                } 
                i += b1;
                i3 = i6;
                continue;
              } 
              break;
            } 
          } else {
            int i5 = this.r.g();
            i3 = Integer.MIN_VALUE;
            f f3 = f2;
            while (true) {
              f2 = f3;
              if (i != i1) {
                f2 = this.q[i];
                int i7 = f2.k(i5);
                int i6 = i3;
                if (i7 > i3) {
                  f3 = f2;
                  i6 = i7;
                } 
                i += b1;
                i3 = i6;
                continue;
              } 
              break;
            } 
          } 
          d d1 = this.B;
          d1.b(i4);
          d1.a[i4] = f2.e;
        } else {
          f2 = this.q[i];
        } 
        c.e = f2;
        if (paramn.e == 1) {
          c(view, -1, false);
        } else {
          c(view, 0, false);
        } 
        if (this.t == 1) {
          i = RecyclerView.m.y(this.u, this.l, 0, c.width, false);
          i1 = this.o;
          int i5 = this.m;
          i3 = P();
          i1 = RecyclerView.m.y(i1, i5, M() + i3, c.height, true);
        } else {
          i = this.n;
          i1 = this.l;
          int i5 = N();
          i = RecyclerView.m.y(i, i1, O() + i5, c.width, true);
          i1 = RecyclerView.m.y(this.u, this.m, 0, c.height, false);
        } 
        b1(view, i, i1, false);
        if (paramn.e == 1) {
          i = f2.h(k);
          i1 = this.r.c(view) + i;
        } else {
          i1 = f2.k(k);
          i = i1 - this.r.c(view);
        } 
        int i2 = paramn.e;
        f f1 = c.e;
        if (i2 == 1) {
          f1.a(view);
        } else {
          f1.n(view);
        } 
        if (a1() && this.t == 1) {
          i3 = this.s.g() - (this.p - 1 - f2.e) * this.u;
          i2 = i3 - this.s.c(view);
        } else {
          i2 = f2.e;
          i3 = this.u;
          i2 = this.s.k() + i2 * i3;
          i3 = this.s.c(view) + i2;
        } 
        if (this.t == 1) {
          int i5 = i;
          i = i2;
          i2 = i5;
        } else {
          int i5 = i1;
          i1 = i3;
          i3 = i5;
        } 
        W(view, i, i2, i3, i1);
        o1(f2, this.v.e, j);
        f1(params, this.v);
        if (this.v.h && view.hasFocusable())
          this.y.set(f2.e, false); 
        i = 1;
        continue;
      } 
      break;
    } 
    if (i == 0)
      f1(params, this.v); 
    if (this.v.e == -1) {
      i = X0(this.r.k());
      i = this.r.k() - i;
    } else {
      i = W0(this.r.g()) - this.r.g();
    } 
    return (i > 0) ? Math.min(paramn.b, i) : 0;
  }
  
  public View Q0(boolean paramBoolean) {
    int j = this.r.k();
    int k = this.r.g();
    int i = x() - 1;
    View view;
    for (view = null; i >= 0; view = view1) {
      View view2 = w(i);
      int i1 = this.r.e(view2);
      int i2 = this.r.b(view2);
      View view1 = view;
      if (i2 > j)
        if (i1 >= k) {
          view1 = view;
        } else if (i2 > k) {
          if (!paramBoolean)
            return view2; 
          view1 = view;
          if (view == null)
            view1 = view2; 
        } else {
          return view2;
        }  
      i--;
    } 
    return view;
  }
  
  public View R0(boolean paramBoolean) {
    int j = this.r.k();
    int k = this.r.g();
    int i1 = x();
    View view = null;
    int i = 0;
    while (i < i1) {
      View view2 = w(i);
      int i2 = this.r.e(view2);
      View view1 = view;
      if (this.r.b(view2) > j)
        if (i2 >= k) {
          view1 = view;
        } else if (i2 < j) {
          if (!paramBoolean)
            return view2; 
          view1 = view;
          if (view == null)
            view1 = view2; 
        } else {
          return view2;
        }  
      i++;
      view = view1;
    } 
    return view;
  }
  
  public final void S0(RecyclerView.s params, RecyclerView.x paramx, boolean paramBoolean) {
    int i = W0(-2147483648);
    if (i == Integer.MIN_VALUE)
      return; 
    i = this.r.g() - i;
    if (i > 0) {
      i -= -j1(-i, params, paramx);
      if (paramBoolean && i > 0)
        this.r.p(i); 
    } 
  }
  
  public final void T0(RecyclerView.s params, RecyclerView.x paramx, boolean paramBoolean) {
    int i = X0(2147483647);
    if (i == Integer.MAX_VALUE)
      return; 
    i -= this.r.k();
    if (i > 0) {
      i -= j1(i, params, paramx);
      if (paramBoolean && i > 0)
        this.r.p(-i); 
    } 
  }
  
  public boolean U() {
    return (this.C != 0);
  }
  
  public int U0() {
    return (x() == 0) ? 0 : Q(w(0));
  }
  
  public int V0() {
    int i = x();
    return (i == 0) ? 0 : Q(w(i - 1));
  }
  
  public final int W0(int paramInt) {
    int j = this.q[0].h(paramInt);
    int i = 1;
    while (i < this.p) {
      int i1 = this.q[i].h(paramInt);
      int k = j;
      if (i1 > j)
        k = i1; 
      i++;
      j = k;
    } 
    return j;
  }
  
  public void X(int paramInt) {
    super.X(paramInt);
    for (int i = 0; i < this.p; i++) {
      f f1 = this.q[i];
      int j = f1.b;
      if (j != Integer.MIN_VALUE)
        f1.b = j + paramInt; 
      j = f1.c;
      if (j != Integer.MIN_VALUE)
        f1.c = j + paramInt; 
    } 
  }
  
  public final int X0(int paramInt) {
    int j = this.q[0].k(paramInt);
    int i = 1;
    while (i < this.p) {
      int i1 = this.q[i].k(paramInt);
      int k = j;
      if (i1 < j)
        k = i1; 
      i++;
      j = k;
    } 
    return j;
  }
  
  public void Y(int paramInt) {
    super.Y(paramInt);
    for (int i = 0; i < this.p; i++) {
      f f1 = this.q[i];
      int j = f1.b;
      if (j != Integer.MIN_VALUE)
        f1.b = j + paramInt; 
      j = f1.c;
      if (j != Integer.MIN_VALUE)
        f1.c = j + paramInt; 
    } 
  }
  
  public final void Y0(int paramInt1, int paramInt2, int paramInt3) {
    if (this.x) {
      int j = V0();
    } else {
      int j = U0();
    } 
    if (paramInt3 == 8) {
      if (paramInt1 < paramInt2) {
        int j = paramInt2 + 1;
      } else {
        int j = paramInt1 + 1;
        int k = paramInt2;
        this.B.d(k);
      } 
    } else {
      int j = paramInt1 + paramInt2;
    } 
    int i = paramInt1;
    this.B.d(i);
  }
  
  public void Z(RecyclerView.e parame1, RecyclerView.e parame2) {
    this.B.a();
    for (int i = 0; i < this.p; i++)
      this.q[i].d(); 
  }
  
  public View Z0() {
    // Byte code:
    //   0: aload_0
    //   1: invokevirtual x : ()I
    //   4: iconst_1
    //   5: isub
    //   6: istore_1
    //   7: new java/util/BitSet
    //   10: dup
    //   11: aload_0
    //   12: getfield p : I
    //   15: invokespecial <init> : (I)V
    //   18: astore #8
    //   20: aload #8
    //   22: iconst_0
    //   23: aload_0
    //   24: getfield p : I
    //   27: iconst_1
    //   28: invokevirtual set : (IIZ)V
    //   31: aload_0
    //   32: getfield t : I
    //   35: istore_2
    //   36: iconst_m1
    //   37: istore #5
    //   39: iload_2
    //   40: iconst_1
    //   41: if_icmpne -> 56
    //   44: aload_0
    //   45: invokevirtual a1 : ()Z
    //   48: ifeq -> 56
    //   51: iconst_1
    //   52: istore_2
    //   53: goto -> 58
    //   56: iconst_m1
    //   57: istore_2
    //   58: aload_0
    //   59: getfield x : Z
    //   62: ifeq -> 70
    //   65: iconst_m1
    //   66: istore_3
    //   67: goto -> 76
    //   70: iload_1
    //   71: iconst_1
    //   72: iadd
    //   73: istore_3
    //   74: iconst_0
    //   75: istore_1
    //   76: iload_1
    //   77: istore #4
    //   79: iload_1
    //   80: iload_3
    //   81: if_icmpge -> 90
    //   84: iconst_1
    //   85: istore #5
    //   87: iload_1
    //   88: istore #4
    //   90: iload #4
    //   92: iload_3
    //   93: if_icmpeq -> 474
    //   96: aload_0
    //   97: iload #4
    //   99: invokevirtual w : (I)Landroid/view/View;
    //   102: astore #9
    //   104: aload #9
    //   106: invokevirtual getLayoutParams : ()Landroid/view/ViewGroup$LayoutParams;
    //   109: checkcast androidx/recyclerview/widget/StaggeredGridLayoutManager$c
    //   112: astore #10
    //   114: aload #8
    //   116: aload #10
    //   118: getfield e : Landroidx/recyclerview/widget/StaggeredGridLayoutManager$f;
    //   121: getfield e : I
    //   124: invokevirtual get : (I)Z
    //   127: ifeq -> 294
    //   130: aload #10
    //   132: getfield e : Landroidx/recyclerview/widget/StaggeredGridLayoutManager$f;
    //   135: astore #11
    //   137: aload_0
    //   138: getfield x : Z
    //   141: ifeq -> 205
    //   144: aload #11
    //   146: getfield c : I
    //   149: istore_1
    //   150: iload_1
    //   151: ldc -2147483648
    //   153: if_icmpeq -> 159
    //   156: goto -> 170
    //   159: aload #11
    //   161: invokevirtual b : ()V
    //   164: aload #11
    //   166: getfield c : I
    //   169: istore_1
    //   170: iload_1
    //   171: aload_0
    //   172: getfield r : Landroidx/recyclerview/widget/s;
    //   175: invokevirtual g : ()I
    //   178: if_icmpge -> 272
    //   181: aload #11
    //   183: getfield a : Ljava/util/ArrayList;
    //   186: astore #7
    //   188: aload #7
    //   190: aload #7
    //   192: invokevirtual size : ()I
    //   195: iconst_1
    //   196: isub
    //   197: invokevirtual get : (I)Ljava/lang/Object;
    //   200: astore #7
    //   202: goto -> 253
    //   205: aload #11
    //   207: getfield b : I
    //   210: istore_1
    //   211: iload_1
    //   212: ldc -2147483648
    //   214: if_icmpeq -> 220
    //   217: goto -> 231
    //   220: aload #11
    //   222: invokevirtual c : ()V
    //   225: aload #11
    //   227: getfield b : I
    //   230: istore_1
    //   231: iload_1
    //   232: aload_0
    //   233: getfield r : Landroidx/recyclerview/widget/s;
    //   236: invokevirtual k : ()I
    //   239: if_icmple -> 272
    //   242: aload #11
    //   244: getfield a : Ljava/util/ArrayList;
    //   247: iconst_0
    //   248: invokevirtual get : (I)Ljava/lang/Object;
    //   251: astore #7
    //   253: aload #11
    //   255: aload #7
    //   257: checkcast android/view/View
    //   260: invokevirtual j : (Landroid/view/View;)Landroidx/recyclerview/widget/StaggeredGridLayoutManager$c;
    //   263: invokestatic requireNonNull : (Ljava/lang/Object;)Ljava/lang/Object;
    //   266: pop
    //   267: iconst_1
    //   268: istore_1
    //   269: goto -> 274
    //   272: iconst_0
    //   273: istore_1
    //   274: iload_1
    //   275: ifeq -> 281
    //   278: aload #9
    //   280: areturn
    //   281: aload #8
    //   283: aload #10
    //   285: getfield e : Landroidx/recyclerview/widget/StaggeredGridLayoutManager$f;
    //   288: getfield e : I
    //   291: invokevirtual clear : (I)V
    //   294: iload #4
    //   296: iload #5
    //   298: iadd
    //   299: istore_1
    //   300: iload_1
    //   301: iload_3
    //   302: if_icmpeq -> 464
    //   305: aload_0
    //   306: iload_1
    //   307: invokevirtual w : (I)Landroid/view/View;
    //   310: astore #7
    //   312: aload_0
    //   313: getfield x : Z
    //   316: ifeq -> 358
    //   319: aload_0
    //   320: getfield r : Landroidx/recyclerview/widget/s;
    //   323: aload #9
    //   325: invokevirtual b : (Landroid/view/View;)I
    //   328: istore_1
    //   329: aload_0
    //   330: getfield r : Landroidx/recyclerview/widget/s;
    //   333: aload #7
    //   335: invokevirtual b : (Landroid/view/View;)I
    //   338: istore #6
    //   340: iload_1
    //   341: iload #6
    //   343: if_icmpge -> 349
    //   346: aload #9
    //   348: areturn
    //   349: iload_1
    //   350: iload #6
    //   352: if_icmpne -> 399
    //   355: goto -> 394
    //   358: aload_0
    //   359: getfield r : Landroidx/recyclerview/widget/s;
    //   362: aload #9
    //   364: invokevirtual e : (Landroid/view/View;)I
    //   367: istore_1
    //   368: aload_0
    //   369: getfield r : Landroidx/recyclerview/widget/s;
    //   372: aload #7
    //   374: invokevirtual e : (Landroid/view/View;)I
    //   377: istore #6
    //   379: iload_1
    //   380: iload #6
    //   382: if_icmple -> 388
    //   385: aload #9
    //   387: areturn
    //   388: iload_1
    //   389: iload #6
    //   391: if_icmpne -> 399
    //   394: iconst_1
    //   395: istore_1
    //   396: goto -> 401
    //   399: iconst_0
    //   400: istore_1
    //   401: iload_1
    //   402: ifeq -> 464
    //   405: aload #7
    //   407: invokevirtual getLayoutParams : ()Landroid/view/ViewGroup$LayoutParams;
    //   410: checkcast androidx/recyclerview/widget/StaggeredGridLayoutManager$c
    //   413: astore #7
    //   415: aload #10
    //   417: getfield e : Landroidx/recyclerview/widget/StaggeredGridLayoutManager$f;
    //   420: getfield e : I
    //   423: aload #7
    //   425: getfield e : Landroidx/recyclerview/widget/StaggeredGridLayoutManager$f;
    //   428: getfield e : I
    //   431: isub
    //   432: ifge -> 440
    //   435: iconst_1
    //   436: istore_1
    //   437: goto -> 442
    //   440: iconst_0
    //   441: istore_1
    //   442: iload_2
    //   443: ifge -> 452
    //   446: iconst_1
    //   447: istore #6
    //   449: goto -> 455
    //   452: iconst_0
    //   453: istore #6
    //   455: iload_1
    //   456: iload #6
    //   458: if_icmpeq -> 464
    //   461: aload #9
    //   463: areturn
    //   464: iload #4
    //   466: iload #5
    //   468: iadd
    //   469: istore #4
    //   471: goto -> 90
    //   474: aconst_null
    //   475: areturn
  }
  
  public PointF a(int paramInt) {
    paramInt = K0(paramInt);
    PointF pointF = new PointF();
    if (paramInt == 0)
      return null; 
    if (this.t == 0) {
      pointF.x = paramInt;
      pointF.y = 0.0F;
      return pointF;
    } 
    pointF.x = 0.0F;
    pointF.y = paramInt;
    return pointF;
  }
  
  public void a0(RecyclerView paramRecyclerView, RecyclerView.s params) {
    Runnable runnable = this.K;
    RecyclerView recyclerView = this.b;
    if (recyclerView != null)
      recyclerView.removeCallbacks(runnable); 
    for (int i = 0; i < this.p; i++)
      this.q[i].d(); 
    paramRecyclerView.requestLayout();
  }
  
  public boolean a1() {
    return (J() == 1);
  }
  
  public View b0(View paramView, int paramInt, RecyclerView.s params, RecyclerView.x paramx) {
    // Byte code:
    //   0: aload_0
    //   1: invokevirtual x : ()I
    //   4: ifne -> 9
    //   7: aconst_null
    //   8: areturn
    //   9: aload_0
    //   10: aload_1
    //   11: invokevirtual r : (Landroid/view/View;)Landroid/view/View;
    //   14: astore_1
    //   15: aload_1
    //   16: ifnonnull -> 21
    //   19: aconst_null
    //   20: areturn
    //   21: aload_0
    //   22: invokevirtual i1 : ()V
    //   25: iload_2
    //   26: iconst_1
    //   27: if_icmpeq -> 132
    //   30: iload_2
    //   31: iconst_2
    //   32: if_icmpeq -> 111
    //   35: iload_2
    //   36: bipush #17
    //   38: if_icmpeq -> 95
    //   41: iload_2
    //   42: bipush #33
    //   44: if_icmpeq -> 84
    //   47: iload_2
    //   48: bipush #66
    //   50: if_icmpeq -> 74
    //   53: iload_2
    //   54: sipush #130
    //   57: if_icmpeq -> 63
    //   60: goto -> 105
    //   63: aload_0
    //   64: getfield t : I
    //   67: iconst_1
    //   68: if_icmpne -> 105
    //   71: goto -> 150
    //   74: aload_0
    //   75: getfield t : I
    //   78: ifne -> 105
    //   81: goto -> 150
    //   84: aload_0
    //   85: getfield t : I
    //   88: iconst_1
    //   89: if_icmpne -> 105
    //   92: goto -> 155
    //   95: aload_0
    //   96: getfield t : I
    //   99: ifne -> 105
    //   102: goto -> 155
    //   105: ldc -2147483648
    //   107: istore_2
    //   108: goto -> 157
    //   111: aload_0
    //   112: getfield t : I
    //   115: iconst_1
    //   116: if_icmpne -> 122
    //   119: goto -> 150
    //   122: aload_0
    //   123: invokevirtual a1 : ()Z
    //   126: ifeq -> 150
    //   129: goto -> 155
    //   132: aload_0
    //   133: getfield t : I
    //   136: iconst_1
    //   137: if_icmpne -> 143
    //   140: goto -> 155
    //   143: aload_0
    //   144: invokevirtual a1 : ()Z
    //   147: ifeq -> 155
    //   150: iconst_1
    //   151: istore_2
    //   152: goto -> 157
    //   155: iconst_m1
    //   156: istore_2
    //   157: iload_2
    //   158: ldc -2147483648
    //   160: if_icmpne -> 165
    //   163: aconst_null
    //   164: areturn
    //   165: aload_1
    //   166: invokevirtual getLayoutParams : ()Landroid/view/ViewGroup$LayoutParams;
    //   169: checkcast androidx/recyclerview/widget/StaggeredGridLayoutManager$c
    //   172: astore #9
    //   174: aload #9
    //   176: invokestatic requireNonNull : (Ljava/lang/Object;)Ljava/lang/Object;
    //   179: pop
    //   180: aload #9
    //   182: getfield e : Landroidx/recyclerview/widget/StaggeredGridLayoutManager$f;
    //   185: astore #9
    //   187: iload_2
    //   188: iconst_1
    //   189: if_icmpne -> 201
    //   192: aload_0
    //   193: invokevirtual V0 : ()I
    //   196: istore #5
    //   198: goto -> 207
    //   201: aload_0
    //   202: invokevirtual U0 : ()I
    //   205: istore #5
    //   207: aload_0
    //   208: iload #5
    //   210: aload #4
    //   212: invokevirtual n1 : (ILandroidx/recyclerview/widget/RecyclerView$x;)V
    //   215: aload_0
    //   216: iload_2
    //   217: invokevirtual k1 : (I)V
    //   220: aload_0
    //   221: getfield v : Landroidx/recyclerview/widget/n;
    //   224: astore #10
    //   226: aload #10
    //   228: aload #10
    //   230: getfield d : I
    //   233: iload #5
    //   235: iadd
    //   236: putfield c : I
    //   239: aload #10
    //   241: aload_0
    //   242: getfield r : Landroidx/recyclerview/widget/s;
    //   245: invokevirtual l : ()I
    //   248: i2f
    //   249: ldc_w 0.33333334
    //   252: fmul
    //   253: f2i
    //   254: putfield b : I
    //   257: aload_0
    //   258: getfield v : Landroidx/recyclerview/widget/n;
    //   261: astore #10
    //   263: aload #10
    //   265: iconst_1
    //   266: putfield h : Z
    //   269: iconst_0
    //   270: istore #7
    //   272: aload #10
    //   274: iconst_0
    //   275: putfield a : Z
    //   278: aload_0
    //   279: aload_3
    //   280: aload #10
    //   282: aload #4
    //   284: invokevirtual P0 : (Landroidx/recyclerview/widget/RecyclerView$s;Landroidx/recyclerview/widget/n;Landroidx/recyclerview/widget/RecyclerView$x;)I
    //   287: pop
    //   288: aload_0
    //   289: aload_0
    //   290: getfield x : Z
    //   293: putfield D : Z
    //   296: aload #9
    //   298: iload #5
    //   300: iload_2
    //   301: invokevirtual i : (II)Landroid/view/View;
    //   304: astore_3
    //   305: aload_3
    //   306: ifnull -> 316
    //   309: aload_3
    //   310: aload_1
    //   311: if_acmpeq -> 316
    //   314: aload_3
    //   315: areturn
    //   316: aload_0
    //   317: iload_2
    //   318: invokevirtual d1 : (I)Z
    //   321: ifeq -> 371
    //   324: aload_0
    //   325: getfield p : I
    //   328: iconst_1
    //   329: isub
    //   330: istore #6
    //   332: iload #6
    //   334: iflt -> 417
    //   337: aload_0
    //   338: getfield q : [Landroidx/recyclerview/widget/StaggeredGridLayoutManager$f;
    //   341: iload #6
    //   343: aaload
    //   344: iload #5
    //   346: iload_2
    //   347: invokevirtual i : (II)Landroid/view/View;
    //   350: astore_3
    //   351: aload_3
    //   352: ifnull -> 362
    //   355: aload_3
    //   356: aload_1
    //   357: if_acmpeq -> 362
    //   360: aload_3
    //   361: areturn
    //   362: iload #6
    //   364: iconst_1
    //   365: isub
    //   366: istore #6
    //   368: goto -> 332
    //   371: iconst_0
    //   372: istore #6
    //   374: iload #6
    //   376: aload_0
    //   377: getfield p : I
    //   380: if_icmpge -> 417
    //   383: aload_0
    //   384: getfield q : [Landroidx/recyclerview/widget/StaggeredGridLayoutManager$f;
    //   387: iload #6
    //   389: aaload
    //   390: iload #5
    //   392: iload_2
    //   393: invokevirtual i : (II)Landroid/view/View;
    //   396: astore_3
    //   397: aload_3
    //   398: ifnull -> 408
    //   401: aload_3
    //   402: aload_1
    //   403: if_acmpeq -> 408
    //   406: aload_3
    //   407: areturn
    //   408: iload #6
    //   410: iconst_1
    //   411: iadd
    //   412: istore #6
    //   414: goto -> 374
    //   417: aload_0
    //   418: getfield w : Z
    //   421: istore #8
    //   423: iload_2
    //   424: iconst_m1
    //   425: if_icmpne -> 434
    //   428: iconst_1
    //   429: istore #5
    //   431: goto -> 437
    //   434: iconst_0
    //   435: istore #5
    //   437: iload #8
    //   439: iconst_1
    //   440: ixor
    //   441: iload #5
    //   443: if_icmpne -> 452
    //   446: iconst_1
    //   447: istore #5
    //   449: goto -> 455
    //   452: iconst_0
    //   453: istore #5
    //   455: iload #5
    //   457: ifeq -> 470
    //   460: aload #9
    //   462: invokevirtual e : ()I
    //   465: istore #6
    //   467: goto -> 477
    //   470: aload #9
    //   472: invokevirtual f : ()I
    //   475: istore #6
    //   477: aload_0
    //   478: iload #6
    //   480: invokevirtual s : (I)Landroid/view/View;
    //   483: astore_3
    //   484: aload_3
    //   485: ifnull -> 495
    //   488: aload_3
    //   489: aload_1
    //   490: if_acmpeq -> 495
    //   493: aload_3
    //   494: areturn
    //   495: iload #7
    //   497: istore #6
    //   499: aload_0
    //   500: iload_2
    //   501: invokevirtual d1 : (I)Z
    //   504: ifeq -> 584
    //   507: aload_0
    //   508: getfield p : I
    //   511: iconst_1
    //   512: isub
    //   513: istore_2
    //   514: iload_2
    //   515: iflt -> 648
    //   518: iload_2
    //   519: aload #9
    //   521: getfield e : I
    //   524: if_icmpne -> 530
    //   527: goto -> 577
    //   530: aload_0
    //   531: getfield q : [Landroidx/recyclerview/widget/StaggeredGridLayoutManager$f;
    //   534: astore_3
    //   535: iload #5
    //   537: ifeq -> 551
    //   540: aload_3
    //   541: iload_2
    //   542: aaload
    //   543: invokevirtual e : ()I
    //   546: istore #6
    //   548: goto -> 559
    //   551: aload_3
    //   552: iload_2
    //   553: aaload
    //   554: invokevirtual f : ()I
    //   557: istore #6
    //   559: aload_0
    //   560: iload #6
    //   562: invokevirtual s : (I)Landroid/view/View;
    //   565: astore_3
    //   566: aload_3
    //   567: ifnull -> 577
    //   570: aload_3
    //   571: aload_1
    //   572: if_acmpeq -> 577
    //   575: aload_3
    //   576: areturn
    //   577: iload_2
    //   578: iconst_1
    //   579: isub
    //   580: istore_2
    //   581: goto -> 514
    //   584: iload #6
    //   586: aload_0
    //   587: getfield p : I
    //   590: if_icmpge -> 648
    //   593: aload_0
    //   594: getfield q : [Landroidx/recyclerview/widget/StaggeredGridLayoutManager$f;
    //   597: astore_3
    //   598: iload #5
    //   600: ifeq -> 614
    //   603: aload_3
    //   604: iload #6
    //   606: aaload
    //   607: invokevirtual e : ()I
    //   610: istore_2
    //   611: goto -> 622
    //   614: aload_3
    //   615: iload #6
    //   617: aaload
    //   618: invokevirtual f : ()I
    //   621: istore_2
    //   622: aload_0
    //   623: iload_2
    //   624: invokevirtual s : (I)Landroid/view/View;
    //   627: astore_3
    //   628: aload_3
    //   629: ifnull -> 639
    //   632: aload_3
    //   633: aload_1
    //   634: if_acmpeq -> 639
    //   637: aload_3
    //   638: areturn
    //   639: iload #6
    //   641: iconst_1
    //   642: iadd
    //   643: istore #6
    //   645: goto -> 584
    //   648: aconst_null
    //   649: areturn
  }
  
  public final void b1(View paramView, int paramInt1, int paramInt2, boolean paramBoolean) {
    Rect rect1 = this.G;
    RecyclerView recyclerView = this.b;
    if (recyclerView == null) {
      rect1.set(0, 0, 0, 0);
    } else {
      rect1.set(recyclerView.L(paramView));
    } 
    c c = (c)paramView.getLayoutParams();
    int i = c.leftMargin;
    Rect rect2 = this.G;
    paramInt1 = p1(paramInt1, i + rect2.left, c.rightMargin + rect2.right);
    i = c.topMargin;
    rect2 = this.G;
    paramInt2 = p1(paramInt2, i + rect2.top, c.bottomMargin + rect2.bottom);
    if (paramBoolean) {
      paramBoolean = G0(paramView, paramInt1, paramInt2, c);
    } else {
      paramBoolean = E0(paramView, paramInt1, paramInt2, c);
    } 
    if (paramBoolean)
      paramView.measure(paramInt1, paramInt2); 
  }
  
  public void c0(AccessibilityEvent paramAccessibilityEvent) {
    super.c0(paramAccessibilityEvent);
    if (x() > 0) {
      View view1 = R0(false);
      View view2 = Q0(false);
      if (view1 != null) {
        if (view2 == null)
          return; 
        int i = Q(view1);
        int j = Q(view2);
        if (i < j) {
          paramAccessibilityEvent.setFromIndex(i);
          paramAccessibilityEvent.setToIndex(j);
          return;
        } 
        paramAccessibilityEvent.setFromIndex(j);
        paramAccessibilityEvent.setToIndex(i);
      } 
    } 
  }
  
  public final void c1(RecyclerView.s params, RecyclerView.x paramx, boolean paramBoolean) {
    // Byte code:
    //   0: aload_0
    //   1: getfield H : Landroidx/recyclerview/widget/StaggeredGridLayoutManager$b;
    //   4: astore #14
    //   6: aload_0
    //   7: getfield F : Landroidx/recyclerview/widget/StaggeredGridLayoutManager$e;
    //   10: ifnonnull -> 21
    //   13: aload_0
    //   14: getfield z : I
    //   17: iconst_m1
    //   18: if_icmpeq -> 39
    //   21: aload_2
    //   22: invokevirtual b : ()I
    //   25: ifne -> 39
    //   28: aload_0
    //   29: aload_1
    //   30: invokevirtual p0 : (Landroidx/recyclerview/widget/RecyclerView$s;)V
    //   33: aload #14
    //   35: invokevirtual b : ()V
    //   38: return
    //   39: aload #14
    //   41: getfield e : Z
    //   44: istore #13
    //   46: iconst_1
    //   47: istore #9
    //   49: iload #13
    //   51: ifeq -> 78
    //   54: aload_0
    //   55: getfield z : I
    //   58: iconst_m1
    //   59: if_icmpne -> 78
    //   62: aload_0
    //   63: getfield F : Landroidx/recyclerview/widget/StaggeredGridLayoutManager$e;
    //   66: ifnull -> 72
    //   69: goto -> 78
    //   72: iconst_0
    //   73: istore #7
    //   75: goto -> 81
    //   78: iconst_1
    //   79: istore #7
    //   81: iload #7
    //   83: ifeq -> 1092
    //   86: aload #14
    //   88: invokevirtual b : ()V
    //   91: aload_0
    //   92: getfield F : Landroidx/recyclerview/widget/StaggeredGridLayoutManager$e;
    //   95: astore #15
    //   97: aload #15
    //   99: ifnull -> 435
    //   102: aload #15
    //   104: getfield j : I
    //   107: istore #6
    //   109: iload #6
    //   111: ifle -> 280
    //   114: iload #6
    //   116: aload_0
    //   117: getfield p : I
    //   120: if_icmpne -> 240
    //   123: iconst_0
    //   124: istore #6
    //   126: iload #6
    //   128: aload_0
    //   129: getfield p : I
    //   132: if_icmpge -> 280
    //   135: aload_0
    //   136: getfield q : [Landroidx/recyclerview/widget/StaggeredGridLayoutManager$f;
    //   139: iload #6
    //   141: aaload
    //   142: invokevirtual d : ()V
    //   145: aload_0
    //   146: getfield F : Landroidx/recyclerview/widget/StaggeredGridLayoutManager$e;
    //   149: astore #15
    //   151: aload #15
    //   153: getfield k : [I
    //   156: iload #6
    //   158: iaload
    //   159: istore #10
    //   161: iload #10
    //   163: istore #8
    //   165: iload #10
    //   167: ldc -2147483648
    //   169: if_icmpeq -> 208
    //   172: aload #15
    //   174: getfield p : Z
    //   177: ifeq -> 192
    //   180: aload_0
    //   181: getfield r : Landroidx/recyclerview/widget/s;
    //   184: invokevirtual g : ()I
    //   187: istore #8
    //   189: goto -> 201
    //   192: aload_0
    //   193: getfield r : Landroidx/recyclerview/widget/s;
    //   196: invokevirtual k : ()I
    //   199: istore #8
    //   201: iload #10
    //   203: iload #8
    //   205: iadd
    //   206: istore #8
    //   208: aload_0
    //   209: getfield q : [Landroidx/recyclerview/widget/StaggeredGridLayoutManager$f;
    //   212: iload #6
    //   214: aaload
    //   215: astore #15
    //   217: aload #15
    //   219: iload #8
    //   221: putfield b : I
    //   224: aload #15
    //   226: iload #8
    //   228: putfield c : I
    //   231: iload #6
    //   233: iconst_1
    //   234: iadd
    //   235: istore #6
    //   237: goto -> 126
    //   240: aload #15
    //   242: aconst_null
    //   243: putfield k : [I
    //   246: aload #15
    //   248: iconst_0
    //   249: putfield j : I
    //   252: aload #15
    //   254: iconst_0
    //   255: putfield l : I
    //   258: aload #15
    //   260: aconst_null
    //   261: putfield m : [I
    //   264: aload #15
    //   266: aconst_null
    //   267: putfield n : Ljava/util/List;
    //   270: aload #15
    //   272: aload #15
    //   274: getfield i : I
    //   277: putfield h : I
    //   280: aload_0
    //   281: getfield F : Landroidx/recyclerview/widget/StaggeredGridLayoutManager$e;
    //   284: astore #15
    //   286: aload_0
    //   287: aload #15
    //   289: getfield q : Z
    //   292: putfield E : Z
    //   295: aload #15
    //   297: getfield o : Z
    //   300: istore #13
    //   302: aload_0
    //   303: aconst_null
    //   304: invokevirtual d : (Ljava/lang/String;)V
    //   307: aload_0
    //   308: getfield F : Landroidx/recyclerview/widget/StaggeredGridLayoutManager$e;
    //   311: astore #15
    //   313: aload #15
    //   315: ifnull -> 335
    //   318: aload #15
    //   320: getfield o : Z
    //   323: iload #13
    //   325: if_icmpeq -> 335
    //   328: aload #15
    //   330: iload #13
    //   332: putfield o : Z
    //   335: aload_0
    //   336: iload #13
    //   338: putfield w : Z
    //   341: aload_0
    //   342: invokevirtual v0 : ()V
    //   345: aload_0
    //   346: invokevirtual i1 : ()V
    //   349: aload_0
    //   350: getfield F : Landroidx/recyclerview/widget/StaggeredGridLayoutManager$e;
    //   353: astore #15
    //   355: aload #15
    //   357: getfield h : I
    //   360: istore #6
    //   362: iload #6
    //   364: iconst_m1
    //   365: if_icmpeq -> 384
    //   368: aload_0
    //   369: iload #6
    //   371: putfield z : I
    //   374: aload #15
    //   376: getfield p : Z
    //   379: istore #13
    //   381: goto -> 390
    //   384: aload_0
    //   385: getfield x : Z
    //   388: istore #13
    //   390: aload #14
    //   392: iload #13
    //   394: putfield c : Z
    //   397: aload #15
    //   399: getfield l : I
    //   402: iconst_1
    //   403: if_icmple -> 448
    //   406: aload_0
    //   407: getfield B : Landroidx/recyclerview/widget/StaggeredGridLayoutManager$d;
    //   410: astore #16
    //   412: aload #16
    //   414: aload #15
    //   416: getfield m : [I
    //   419: putfield a : [I
    //   422: aload #16
    //   424: aload #15
    //   426: getfield n : Ljava/util/List;
    //   429: putfield b : Ljava/util/List;
    //   432: goto -> 448
    //   435: aload_0
    //   436: invokevirtual i1 : ()V
    //   439: aload #14
    //   441: aload_0
    //   442: getfield x : Z
    //   445: putfield c : Z
    //   448: aload_2
    //   449: getfield g : Z
    //   452: ifne -> 929
    //   455: aload_0
    //   456: getfield z : I
    //   459: istore #6
    //   461: iload #6
    //   463: iconst_m1
    //   464: if_icmpne -> 470
    //   467: goto -> 929
    //   470: iload #6
    //   472: iflt -> 918
    //   475: iload #6
    //   477: aload_2
    //   478: invokevirtual b : ()I
    //   481: if_icmplt -> 487
    //   484: goto -> 918
    //   487: aload_0
    //   488: getfield F : Landroidx/recyclerview/widget/StaggeredGridLayoutManager$e;
    //   491: astore #15
    //   493: aload #15
    //   495: ifnull -> 538
    //   498: aload #15
    //   500: getfield h : I
    //   503: iconst_m1
    //   504: if_icmpeq -> 538
    //   507: aload #15
    //   509: getfield j : I
    //   512: iconst_1
    //   513: if_icmpge -> 519
    //   516: goto -> 538
    //   519: aload #14
    //   521: ldc -2147483648
    //   523: putfield b : I
    //   526: aload #14
    //   528: aload_0
    //   529: getfield z : I
    //   532: putfield a : I
    //   535: goto -> 912
    //   538: aload_0
    //   539: aload_0
    //   540: getfield z : I
    //   543: invokevirtual s : (I)Landroid/view/View;
    //   546: astore #15
    //   548: aload #15
    //   550: ifnull -> 796
    //   553: aload_0
    //   554: getfield x : Z
    //   557: ifeq -> 569
    //   560: aload_0
    //   561: invokevirtual V0 : ()I
    //   564: istore #6
    //   566: goto -> 575
    //   569: aload_0
    //   570: invokevirtual U0 : ()I
    //   573: istore #6
    //   575: aload #14
    //   577: iload #6
    //   579: putfield a : I
    //   582: aload_0
    //   583: getfield A : I
    //   586: ldc -2147483648
    //   588: if_icmpeq -> 662
    //   591: aload #14
    //   593: getfield c : Z
    //   596: ifeq -> 627
    //   599: aload_0
    //   600: getfield r : Landroidx/recyclerview/widget/s;
    //   603: invokevirtual g : ()I
    //   606: aload_0
    //   607: getfield A : I
    //   610: isub
    //   611: istore #8
    //   613: aload_0
    //   614: getfield r : Landroidx/recyclerview/widget/s;
    //   617: aload #15
    //   619: invokevirtual b : (Landroid/view/View;)I
    //   622: istore #6
    //   624: goto -> 652
    //   627: aload_0
    //   628: getfield r : Landroidx/recyclerview/widget/s;
    //   631: invokevirtual k : ()I
    //   634: aload_0
    //   635: getfield A : I
    //   638: iadd
    //   639: istore #8
    //   641: aload_0
    //   642: getfield r : Landroidx/recyclerview/widget/s;
    //   645: aload #15
    //   647: invokevirtual e : (Landroid/view/View;)I
    //   650: istore #6
    //   652: iload #8
    //   654: iload #6
    //   656: isub
    //   657: istore #6
    //   659: goto -> 776
    //   662: aload_0
    //   663: getfield r : Landroidx/recyclerview/widget/s;
    //   666: aload #15
    //   668: invokevirtual c : (Landroid/view/View;)I
    //   671: aload_0
    //   672: getfield r : Landroidx/recyclerview/widget/s;
    //   675: invokevirtual l : ()I
    //   678: if_icmple -> 713
    //   681: aload #14
    //   683: getfield c : Z
    //   686: ifeq -> 701
    //   689: aload_0
    //   690: getfield r : Landroidx/recyclerview/widget/s;
    //   693: invokevirtual g : ()I
    //   696: istore #6
    //   698: goto -> 742
    //   701: aload_0
    //   702: getfield r : Landroidx/recyclerview/widget/s;
    //   705: invokevirtual k : ()I
    //   708: istore #6
    //   710: goto -> 742
    //   713: aload_0
    //   714: getfield r : Landroidx/recyclerview/widget/s;
    //   717: aload #15
    //   719: invokevirtual e : (Landroid/view/View;)I
    //   722: aload_0
    //   723: getfield r : Landroidx/recyclerview/widget/s;
    //   726: invokevirtual k : ()I
    //   729: isub
    //   730: istore #6
    //   732: iload #6
    //   734: ifge -> 752
    //   737: iload #6
    //   739: ineg
    //   740: istore #6
    //   742: aload #14
    //   744: iload #6
    //   746: putfield b : I
    //   749: goto -> 912
    //   752: aload_0
    //   753: getfield r : Landroidx/recyclerview/widget/s;
    //   756: invokevirtual g : ()I
    //   759: aload_0
    //   760: getfield r : Landroidx/recyclerview/widget/s;
    //   763: aload #15
    //   765: invokevirtual b : (Landroid/view/View;)I
    //   768: isub
    //   769: istore #6
    //   771: iload #6
    //   773: ifge -> 786
    //   776: aload #14
    //   778: iload #6
    //   780: putfield b : I
    //   783: goto -> 912
    //   786: aload #14
    //   788: ldc -2147483648
    //   790: putfield b : I
    //   793: goto -> 912
    //   796: aload_0
    //   797: getfield z : I
    //   800: istore #6
    //   802: aload #14
    //   804: iload #6
    //   806: putfield a : I
    //   809: aload_0
    //   810: getfield A : I
    //   813: istore #8
    //   815: iload #8
    //   817: ldc -2147483648
    //   819: if_icmpne -> 856
    //   822: aload_0
    //   823: iload #6
    //   825: invokevirtual K0 : (I)I
    //   828: iconst_1
    //   829: if_icmpne -> 838
    //   832: iconst_1
    //   833: istore #13
    //   835: goto -> 841
    //   838: iconst_0
    //   839: istore #13
    //   841: aload #14
    //   843: iload #13
    //   845: putfield c : Z
    //   848: aload #14
    //   850: invokevirtual a : ()V
    //   853: goto -> 906
    //   856: aload #14
    //   858: getfield c : Z
    //   861: ifeq -> 883
    //   864: aload #14
    //   866: getfield g : Landroidx/recyclerview/widget/StaggeredGridLayoutManager;
    //   869: getfield r : Landroidx/recyclerview/widget/s;
    //   872: invokevirtual g : ()I
    //   875: iload #8
    //   877: isub
    //   878: istore #6
    //   880: goto -> 899
    //   883: aload #14
    //   885: getfield g : Landroidx/recyclerview/widget/StaggeredGridLayoutManager;
    //   888: getfield r : Landroidx/recyclerview/widget/s;
    //   891: invokevirtual k : ()I
    //   894: iload #8
    //   896: iadd
    //   897: istore #6
    //   899: aload #14
    //   901: iload #6
    //   903: putfield b : I
    //   906: aload #14
    //   908: iconst_1
    //   909: putfield d : Z
    //   912: iconst_1
    //   913: istore #6
    //   915: goto -> 932
    //   918: aload_0
    //   919: iconst_m1
    //   920: putfield z : I
    //   923: aload_0
    //   924: ldc -2147483648
    //   926: putfield A : I
    //   929: iconst_0
    //   930: istore #6
    //   932: iload #6
    //   934: ifeq -> 940
    //   937: goto -> 1086
    //   940: aload_0
    //   941: getfield D : Z
    //   944: istore #13
    //   946: aload_2
    //   947: invokevirtual b : ()I
    //   950: istore #11
    //   952: iload #13
    //   954: ifeq -> 1013
    //   957: aload_0
    //   958: invokevirtual x : ()I
    //   961: istore #6
    //   963: iload #6
    //   965: iconst_1
    //   966: isub
    //   967: istore #8
    //   969: iload #8
    //   971: iflt -> 1069
    //   974: aload_0
    //   975: aload_0
    //   976: iload #8
    //   978: invokevirtual w : (I)Landroid/view/View;
    //   981: invokevirtual Q : (Landroid/view/View;)I
    //   984: istore #10
    //   986: iload #8
    //   988: istore #6
    //   990: iload #10
    //   992: iflt -> 963
    //   995: iload #8
    //   997: istore #6
    //   999: iload #10
    //   1001: iload #11
    //   1003: if_icmpge -> 963
    //   1006: iload #10
    //   1008: istore #6
    //   1010: goto -> 1072
    //   1013: aload_0
    //   1014: invokevirtual x : ()I
    //   1017: istore #10
    //   1019: iconst_0
    //   1020: istore #6
    //   1022: iload #6
    //   1024: iload #10
    //   1026: if_icmpge -> 1069
    //   1029: aload_0
    //   1030: aload_0
    //   1031: iload #6
    //   1033: invokevirtual w : (I)Landroid/view/View;
    //   1036: invokevirtual Q : (Landroid/view/View;)I
    //   1039: istore #8
    //   1041: iload #8
    //   1043: iflt -> 1060
    //   1046: iload #8
    //   1048: iload #11
    //   1050: if_icmpge -> 1060
    //   1053: iload #8
    //   1055: istore #6
    //   1057: goto -> 1072
    //   1060: iload #6
    //   1062: iconst_1
    //   1063: iadd
    //   1064: istore #6
    //   1066: goto -> 1022
    //   1069: iconst_0
    //   1070: istore #6
    //   1072: aload #14
    //   1074: iload #6
    //   1076: putfield a : I
    //   1079: aload #14
    //   1081: ldc -2147483648
    //   1083: putfield b : I
    //   1086: aload #14
    //   1088: iconst_1
    //   1089: putfield e : Z
    //   1092: aload_0
    //   1093: getfield F : Landroidx/recyclerview/widget/StaggeredGridLayoutManager$e;
    //   1096: ifnonnull -> 1143
    //   1099: aload_0
    //   1100: getfield z : I
    //   1103: iconst_m1
    //   1104: if_icmpne -> 1143
    //   1107: aload #14
    //   1109: getfield c : Z
    //   1112: aload_0
    //   1113: getfield D : Z
    //   1116: if_icmpne -> 1130
    //   1119: aload_0
    //   1120: invokevirtual a1 : ()Z
    //   1123: aload_0
    //   1124: getfield E : Z
    //   1127: if_icmpeq -> 1143
    //   1130: aload_0
    //   1131: getfield B : Landroidx/recyclerview/widget/StaggeredGridLayoutManager$d;
    //   1134: invokevirtual a : ()V
    //   1137: aload #14
    //   1139: iconst_1
    //   1140: putfield d : Z
    //   1143: aload_0
    //   1144: invokevirtual x : ()I
    //   1147: ifle -> 1582
    //   1150: aload_0
    //   1151: getfield F : Landroidx/recyclerview/widget/StaggeredGridLayoutManager$e;
    //   1154: astore #15
    //   1156: aload #15
    //   1158: ifnull -> 1170
    //   1161: aload #15
    //   1163: getfield j : I
    //   1166: iconst_1
    //   1167: if_icmpge -> 1582
    //   1170: aload #14
    //   1172: getfield d : Z
    //   1175: ifeq -> 1246
    //   1178: iconst_0
    //   1179: istore #6
    //   1181: iload #6
    //   1183: aload_0
    //   1184: getfield p : I
    //   1187: if_icmpge -> 1582
    //   1190: aload_0
    //   1191: getfield q : [Landroidx/recyclerview/widget/StaggeredGridLayoutManager$f;
    //   1194: iload #6
    //   1196: aaload
    //   1197: invokevirtual d : ()V
    //   1200: aload #14
    //   1202: getfield b : I
    //   1205: istore #7
    //   1207: iload #7
    //   1209: ldc -2147483648
    //   1211: if_icmpeq -> 1237
    //   1214: aload_0
    //   1215: getfield q : [Landroidx/recyclerview/widget/StaggeredGridLayoutManager$f;
    //   1218: iload #6
    //   1220: aaload
    //   1221: astore #15
    //   1223: aload #15
    //   1225: iload #7
    //   1227: putfield b : I
    //   1230: aload #15
    //   1232: iload #7
    //   1234: putfield c : I
    //   1237: iload #6
    //   1239: iconst_1
    //   1240: iadd
    //   1241: istore #6
    //   1243: goto -> 1181
    //   1246: iload #7
    //   1248: ifne -> 1325
    //   1251: aload_0
    //   1252: getfield H : Landroidx/recyclerview/widget/StaggeredGridLayoutManager$b;
    //   1255: getfield f : [I
    //   1258: ifnonnull -> 1264
    //   1261: goto -> 1325
    //   1264: iconst_0
    //   1265: istore #6
    //   1267: iload #6
    //   1269: aload_0
    //   1270: getfield p : I
    //   1273: if_icmpge -> 1582
    //   1276: aload_0
    //   1277: getfield q : [Landroidx/recyclerview/widget/StaggeredGridLayoutManager$f;
    //   1280: iload #6
    //   1282: aaload
    //   1283: astore #15
    //   1285: aload #15
    //   1287: invokevirtual d : ()V
    //   1290: aload_0
    //   1291: getfield H : Landroidx/recyclerview/widget/StaggeredGridLayoutManager$b;
    //   1294: getfield f : [I
    //   1297: iload #6
    //   1299: iaload
    //   1300: istore #7
    //   1302: aload #15
    //   1304: iload #7
    //   1306: putfield b : I
    //   1309: aload #15
    //   1311: iload #7
    //   1313: putfield c : I
    //   1316: iload #6
    //   1318: iconst_1
    //   1319: iadd
    //   1320: istore #6
    //   1322: goto -> 1267
    //   1325: iconst_0
    //   1326: istore #7
    //   1328: iload #7
    //   1330: aload_0
    //   1331: getfield p : I
    //   1334: if_icmpge -> 1486
    //   1337: aload_0
    //   1338: getfield q : [Landroidx/recyclerview/widget/StaggeredGridLayoutManager$f;
    //   1341: iload #7
    //   1343: aaload
    //   1344: astore #15
    //   1346: aload_0
    //   1347: getfield x : Z
    //   1350: istore #13
    //   1352: aload #14
    //   1354: getfield b : I
    //   1357: istore #10
    //   1359: iload #13
    //   1361: ifeq -> 1376
    //   1364: aload #15
    //   1366: ldc -2147483648
    //   1368: invokevirtual h : (I)I
    //   1371: istore #6
    //   1373: goto -> 1385
    //   1376: aload #15
    //   1378: ldc -2147483648
    //   1380: invokevirtual k : (I)I
    //   1383: istore #6
    //   1385: aload #15
    //   1387: invokevirtual d : ()V
    //   1390: iload #6
    //   1392: ldc -2147483648
    //   1394: if_icmpne -> 1400
    //   1397: goto -> 1477
    //   1400: iload #13
    //   1402: ifeq -> 1421
    //   1405: iload #6
    //   1407: aload #15
    //   1409: getfield f : Landroidx/recyclerview/widget/StaggeredGridLayoutManager;
    //   1412: getfield r : Landroidx/recyclerview/widget/s;
    //   1415: invokevirtual g : ()I
    //   1418: if_icmplt -> 1477
    //   1421: iload #13
    //   1423: ifne -> 1445
    //   1426: iload #6
    //   1428: aload #15
    //   1430: getfield f : Landroidx/recyclerview/widget/StaggeredGridLayoutManager;
    //   1433: getfield r : Landroidx/recyclerview/widget/s;
    //   1436: invokevirtual k : ()I
    //   1439: if_icmple -> 1445
    //   1442: goto -> 1477
    //   1445: iload #6
    //   1447: istore #8
    //   1449: iload #10
    //   1451: ldc -2147483648
    //   1453: if_icmpeq -> 1463
    //   1456: iload #6
    //   1458: iload #10
    //   1460: iadd
    //   1461: istore #8
    //   1463: aload #15
    //   1465: iload #8
    //   1467: putfield c : I
    //   1470: aload #15
    //   1472: iload #8
    //   1474: putfield b : I
    //   1477: iload #7
    //   1479: iconst_1
    //   1480: iadd
    //   1481: istore #7
    //   1483: goto -> 1328
    //   1486: aload_0
    //   1487: getfield H : Landroidx/recyclerview/widget/StaggeredGridLayoutManager$b;
    //   1490: astore #15
    //   1492: aload_0
    //   1493: getfield q : [Landroidx/recyclerview/widget/StaggeredGridLayoutManager$f;
    //   1496: astore #16
    //   1498: aload #15
    //   1500: invokestatic requireNonNull : (Ljava/lang/Object;)Ljava/lang/Object;
    //   1503: pop
    //   1504: aload #16
    //   1506: arraylength
    //   1507: istore #7
    //   1509: aload #15
    //   1511: getfield f : [I
    //   1514: astore #17
    //   1516: aload #17
    //   1518: ifnull -> 1529
    //   1521: aload #17
    //   1523: arraylength
    //   1524: iload #7
    //   1526: if_icmpge -> 1545
    //   1529: aload #15
    //   1531: aload #15
    //   1533: getfield g : Landroidx/recyclerview/widget/StaggeredGridLayoutManager;
    //   1536: getfield q : [Landroidx/recyclerview/widget/StaggeredGridLayoutManager$f;
    //   1539: arraylength
    //   1540: newarray int
    //   1542: putfield f : [I
    //   1545: iconst_0
    //   1546: istore #6
    //   1548: iload #6
    //   1550: iload #7
    //   1552: if_icmpge -> 1582
    //   1555: aload #15
    //   1557: getfield f : [I
    //   1560: iload #6
    //   1562: aload #16
    //   1564: iload #6
    //   1566: aaload
    //   1567: ldc -2147483648
    //   1569: invokevirtual k : (I)I
    //   1572: iastore
    //   1573: iload #6
    //   1575: iconst_1
    //   1576: iadd
    //   1577: istore #6
    //   1579: goto -> 1548
    //   1582: aload_0
    //   1583: aload_1
    //   1584: invokevirtual q : (Landroidx/recyclerview/widget/RecyclerView$s;)V
    //   1587: aload_0
    //   1588: getfield v : Landroidx/recyclerview/widget/n;
    //   1591: iconst_0
    //   1592: putfield a : Z
    //   1595: aload_0
    //   1596: getfield s : Landroidx/recyclerview/widget/s;
    //   1599: invokevirtual l : ()I
    //   1602: istore #6
    //   1604: aload_0
    //   1605: iload #6
    //   1607: aload_0
    //   1608: getfield p : I
    //   1611: idiv
    //   1612: putfield u : I
    //   1615: iload #6
    //   1617: aload_0
    //   1618: getfield s : Landroidx/recyclerview/widget/s;
    //   1621: invokevirtual i : ()I
    //   1624: invokestatic makeMeasureSpec : (II)I
    //   1627: pop
    //   1628: aload_0
    //   1629: aload #14
    //   1631: getfield a : I
    //   1634: aload_2
    //   1635: invokevirtual n1 : (ILandroidx/recyclerview/widget/RecyclerView$x;)V
    //   1638: aload #14
    //   1640: getfield c : Z
    //   1643: ifeq -> 1670
    //   1646: aload_0
    //   1647: iconst_m1
    //   1648: invokevirtual k1 : (I)V
    //   1651: aload_0
    //   1652: aload_1
    //   1653: aload_0
    //   1654: getfield v : Landroidx/recyclerview/widget/n;
    //   1657: aload_2
    //   1658: invokevirtual P0 : (Landroidx/recyclerview/widget/RecyclerView$s;Landroidx/recyclerview/widget/n;Landroidx/recyclerview/widget/RecyclerView$x;)I
    //   1661: pop
    //   1662: aload_0
    //   1663: iconst_1
    //   1664: invokevirtual k1 : (I)V
    //   1667: goto -> 1691
    //   1670: aload_0
    //   1671: iconst_1
    //   1672: invokevirtual k1 : (I)V
    //   1675: aload_0
    //   1676: aload_1
    //   1677: aload_0
    //   1678: getfield v : Landroidx/recyclerview/widget/n;
    //   1681: aload_2
    //   1682: invokevirtual P0 : (Landroidx/recyclerview/widget/RecyclerView$s;Landroidx/recyclerview/widget/n;Landroidx/recyclerview/widget/RecyclerView$x;)I
    //   1685: pop
    //   1686: aload_0
    //   1687: iconst_m1
    //   1688: invokevirtual k1 : (I)V
    //   1691: aload_0
    //   1692: getfield v : Landroidx/recyclerview/widget/n;
    //   1695: astore #15
    //   1697: aload #15
    //   1699: aload #14
    //   1701: getfield a : I
    //   1704: aload #15
    //   1706: getfield d : I
    //   1709: iadd
    //   1710: putfield c : I
    //   1713: aload_0
    //   1714: aload_1
    //   1715: aload #15
    //   1717: aload_2
    //   1718: invokevirtual P0 : (Landroidx/recyclerview/widget/RecyclerView$s;Landroidx/recyclerview/widget/n;Landroidx/recyclerview/widget/RecyclerView$x;)I
    //   1721: pop
    //   1722: aload_0
    //   1723: getfield s : Landroidx/recyclerview/widget/s;
    //   1726: invokevirtual i : ()I
    //   1729: ldc_w 1073741824
    //   1732: if_icmpne -> 1738
    //   1735: goto -> 2068
    //   1738: fconst_0
    //   1739: fstore #4
    //   1741: aload_0
    //   1742: invokevirtual x : ()I
    //   1745: istore #8
    //   1747: iconst_0
    //   1748: istore #6
    //   1750: iload #6
    //   1752: iload #8
    //   1754: if_icmpge -> 1818
    //   1757: aload_0
    //   1758: iload #6
    //   1760: invokevirtual w : (I)Landroid/view/View;
    //   1763: astore #15
    //   1765: aload_0
    //   1766: getfield s : Landroidx/recyclerview/widget/s;
    //   1769: aload #15
    //   1771: invokevirtual c : (Landroid/view/View;)I
    //   1774: i2f
    //   1775: fstore #5
    //   1777: fload #5
    //   1779: fload #4
    //   1781: fcmpg
    //   1782: ifge -> 1788
    //   1785: goto -> 1809
    //   1788: aload #15
    //   1790: invokevirtual getLayoutParams : ()Landroid/view/ViewGroup$LayoutParams;
    //   1793: checkcast androidx/recyclerview/widget/StaggeredGridLayoutManager$c
    //   1796: invokestatic requireNonNull : (Ljava/lang/Object;)Ljava/lang/Object;
    //   1799: pop
    //   1800: fload #4
    //   1802: fload #5
    //   1804: invokestatic max : (FF)F
    //   1807: fstore #4
    //   1809: iload #6
    //   1811: iconst_1
    //   1812: iadd
    //   1813: istore #6
    //   1815: goto -> 1750
    //   1818: aload_0
    //   1819: getfield u : I
    //   1822: istore #10
    //   1824: fload #4
    //   1826: aload_0
    //   1827: getfield p : I
    //   1830: i2f
    //   1831: fmul
    //   1832: invokestatic round : (F)I
    //   1835: istore #7
    //   1837: iload #7
    //   1839: istore #6
    //   1841: aload_0
    //   1842: getfield s : Landroidx/recyclerview/widget/s;
    //   1845: invokevirtual i : ()I
    //   1848: ldc -2147483648
    //   1850: if_icmpne -> 1867
    //   1853: iload #7
    //   1855: aload_0
    //   1856: getfield s : Landroidx/recyclerview/widget/s;
    //   1859: invokevirtual l : ()I
    //   1862: invokestatic min : (II)I
    //   1865: istore #6
    //   1867: aload_0
    //   1868: iload #6
    //   1870: aload_0
    //   1871: getfield p : I
    //   1874: idiv
    //   1875: putfield u : I
    //   1878: iload #6
    //   1880: aload_0
    //   1881: getfield s : Landroidx/recyclerview/widget/s;
    //   1884: invokevirtual i : ()I
    //   1887: invokestatic makeMeasureSpec : (II)I
    //   1890: pop
    //   1891: aload_0
    //   1892: getfield u : I
    //   1895: iload #10
    //   1897: if_icmpne -> 1903
    //   1900: goto -> 2068
    //   1903: iconst_0
    //   1904: istore #6
    //   1906: iload #6
    //   1908: iload #8
    //   1910: if_icmpge -> 2068
    //   1913: aload_0
    //   1914: iload #6
    //   1916: invokevirtual w : (I)Landroid/view/View;
    //   1919: astore #15
    //   1921: aload #15
    //   1923: invokevirtual getLayoutParams : ()Landroid/view/ViewGroup$LayoutParams;
    //   1926: checkcast androidx/recyclerview/widget/StaggeredGridLayoutManager$c
    //   1929: astore #16
    //   1931: aload #16
    //   1933: invokestatic requireNonNull : (Ljava/lang/Object;)Ljava/lang/Object;
    //   1936: pop
    //   1937: aload_0
    //   1938: invokevirtual a1 : ()Z
    //   1941: ifeq -> 2001
    //   1944: aload_0
    //   1945: getfield t : I
    //   1948: iconst_1
    //   1949: if_icmpne -> 2001
    //   1952: aload_0
    //   1953: getfield p : I
    //   1956: istore #7
    //   1958: aload #16
    //   1960: getfield e : Landroidx/recyclerview/widget/StaggeredGridLayoutManager$f;
    //   1963: getfield e : I
    //   1966: istore #11
    //   1968: aload #15
    //   1970: iload #7
    //   1972: iconst_1
    //   1973: isub
    //   1974: iload #11
    //   1976: isub
    //   1977: ineg
    //   1978: aload_0
    //   1979: getfield u : I
    //   1982: imul
    //   1983: iload #7
    //   1985: iconst_1
    //   1986: isub
    //   1987: iload #11
    //   1989: isub
    //   1990: ineg
    //   1991: iload #10
    //   1993: imul
    //   1994: isub
    //   1995: invokevirtual offsetLeftAndRight : (I)V
    //   1998: goto -> 2059
    //   2001: aload #16
    //   2003: getfield e : Landroidx/recyclerview/widget/StaggeredGridLayoutManager$f;
    //   2006: getfield e : I
    //   2009: istore #11
    //   2011: aload_0
    //   2012: getfield u : I
    //   2015: istore #12
    //   2017: aload_0
    //   2018: getfield t : I
    //   2021: istore #7
    //   2023: iload #12
    //   2025: iload #11
    //   2027: imul
    //   2028: iload #11
    //   2030: iload #10
    //   2032: imul
    //   2033: isub
    //   2034: istore #11
    //   2036: iload #7
    //   2038: iconst_1
    //   2039: if_icmpne -> 2052
    //   2042: aload #15
    //   2044: iload #11
    //   2046: invokevirtual offsetLeftAndRight : (I)V
    //   2049: goto -> 2059
    //   2052: aload #15
    //   2054: iload #11
    //   2056: invokevirtual offsetTopAndBottom : (I)V
    //   2059: iload #6
    //   2061: iconst_1
    //   2062: iadd
    //   2063: istore #6
    //   2065: goto -> 1906
    //   2068: aload_0
    //   2069: invokevirtual x : ()I
    //   2072: ifle -> 2113
    //   2075: aload_0
    //   2076: getfield x : Z
    //   2079: ifeq -> 2099
    //   2082: aload_0
    //   2083: aload_1
    //   2084: aload_2
    //   2085: iconst_1
    //   2086: invokevirtual S0 : (Landroidx/recyclerview/widget/RecyclerView$s;Landroidx/recyclerview/widget/RecyclerView$x;Z)V
    //   2089: aload_0
    //   2090: aload_1
    //   2091: aload_2
    //   2092: iconst_0
    //   2093: invokevirtual T0 : (Landroidx/recyclerview/widget/RecyclerView$s;Landroidx/recyclerview/widget/RecyclerView$x;Z)V
    //   2096: goto -> 2113
    //   2099: aload_0
    //   2100: aload_1
    //   2101: aload_2
    //   2102: iconst_1
    //   2103: invokevirtual T0 : (Landroidx/recyclerview/widget/RecyclerView$s;Landroidx/recyclerview/widget/RecyclerView$x;Z)V
    //   2106: aload_0
    //   2107: aload_1
    //   2108: aload_2
    //   2109: iconst_0
    //   2110: invokevirtual S0 : (Landroidx/recyclerview/widget/RecyclerView$s;Landroidx/recyclerview/widget/RecyclerView$x;Z)V
    //   2113: iload_3
    //   2114: ifeq -> 2198
    //   2117: aload_2
    //   2118: getfield g : Z
    //   2121: ifne -> 2198
    //   2124: aload_0
    //   2125: getfield C : I
    //   2128: ifeq -> 2151
    //   2131: aload_0
    //   2132: invokevirtual x : ()I
    //   2135: ifle -> 2151
    //   2138: aload_0
    //   2139: invokevirtual Z0 : ()Landroid/view/View;
    //   2142: ifnull -> 2151
    //   2145: iconst_1
    //   2146: istore #6
    //   2148: goto -> 2154
    //   2151: iconst_0
    //   2152: istore #6
    //   2154: iload #6
    //   2156: ifeq -> 2198
    //   2159: aload_0
    //   2160: getfield K : Ljava/lang/Runnable;
    //   2163: astore #15
    //   2165: aload_0
    //   2166: getfield b : Landroidx/recyclerview/widget/RecyclerView;
    //   2169: astore #16
    //   2171: aload #16
    //   2173: ifnull -> 2184
    //   2176: aload #16
    //   2178: aload #15
    //   2180: invokevirtual removeCallbacks : (Ljava/lang/Runnable;)Z
    //   2183: pop
    //   2184: aload_0
    //   2185: invokevirtual L0 : ()Z
    //   2188: ifeq -> 2198
    //   2191: iload #9
    //   2193: istore #6
    //   2195: goto -> 2201
    //   2198: iconst_0
    //   2199: istore #6
    //   2201: aload_2
    //   2202: getfield g : Z
    //   2205: ifeq -> 2215
    //   2208: aload_0
    //   2209: getfield H : Landroidx/recyclerview/widget/StaggeredGridLayoutManager$b;
    //   2212: invokevirtual b : ()V
    //   2215: aload_0
    //   2216: aload #14
    //   2218: getfield c : Z
    //   2221: putfield D : Z
    //   2224: aload_0
    //   2225: aload_0
    //   2226: invokevirtual a1 : ()Z
    //   2229: putfield E : Z
    //   2232: iload #6
    //   2234: ifeq -> 2251
    //   2237: aload_0
    //   2238: getfield H : Landroidx/recyclerview/widget/StaggeredGridLayoutManager$b;
    //   2241: invokevirtual b : ()V
    //   2244: aload_0
    //   2245: aload_1
    //   2246: aload_2
    //   2247: iconst_0
    //   2248: invokevirtual c1 : (Landroidx/recyclerview/widget/RecyclerView$s;Landroidx/recyclerview/widget/RecyclerView$x;Z)V
    //   2251: return
  }
  
  public void d(String paramString) {
    if (this.F == null) {
      RecyclerView recyclerView = this.b;
      if (recyclerView != null)
        recyclerView.i(paramString); 
    } 
  }
  
  public final boolean d1(int paramInt) {
    boolean bool;
    if (this.t == 0) {
      if (paramInt == -1) {
        bool = true;
      } else {
        bool = false;
      } 
      return (bool != this.x);
    } 
    if (paramInt == -1) {
      bool = true;
    } else {
      bool = false;
    } 
    if (bool == this.x) {
      bool = true;
    } else {
      bool = false;
    } 
    return (bool == a1());
  }
  
  public boolean e() {
    return (this.t == 0);
  }
  
  public void e1(int paramInt, RecyclerView.x paramx) {
    int i;
    byte b1;
    if (paramInt > 0) {
      i = V0();
      b1 = 1;
    } else {
      i = U0();
      b1 = -1;
    } 
    this.v.a = true;
    n1(i, paramx);
    k1(b1);
    n n1 = this.v;
    n1.c = i + n1.d;
    n1.b = Math.abs(paramInt);
  }
  
  public boolean f() {
    return (this.t == 1);
  }
  
  public void f0(RecyclerView paramRecyclerView, int paramInt1, int paramInt2) {
    Y0(paramInt1, paramInt2, 1);
  }
  
  public final void f1(RecyclerView.s params, n paramn) {
    // Byte code:
    //   0: aload_2
    //   1: getfield a : Z
    //   4: ifeq -> 276
    //   7: aload_2
    //   8: getfield i : Z
    //   11: ifeq -> 15
    //   14: return
    //   15: aload_2
    //   16: getfield b : I
    //   19: ifne -> 54
    //   22: aload_2
    //   23: getfield e : I
    //   26: iconst_m1
    //   27: if_icmpne -> 42
    //   30: aload_2
    //   31: getfield g : I
    //   34: istore_3
    //   35: aload_0
    //   36: aload_1
    //   37: iload_3
    //   38: invokevirtual g1 : (Landroidx/recyclerview/widget/RecyclerView$s;I)V
    //   41: return
    //   42: aload_2
    //   43: getfield f : I
    //   46: istore_3
    //   47: aload_0
    //   48: aload_1
    //   49: iload_3
    //   50: invokevirtual h1 : (Landroidx/recyclerview/widget/RecyclerView$s;I)V
    //   53: return
    //   54: aload_2
    //   55: getfield e : I
    //   58: istore #5
    //   60: iconst_1
    //   61: istore #4
    //   63: iconst_1
    //   64: istore_3
    //   65: iload #5
    //   67: iconst_m1
    //   68: if_icmpne -> 167
    //   71: aload_2
    //   72: getfield f : I
    //   75: istore #7
    //   77: aload_0
    //   78: getfield q : [Landroidx/recyclerview/widget/StaggeredGridLayoutManager$f;
    //   81: iconst_0
    //   82: aaload
    //   83: iload #7
    //   85: invokevirtual k : (I)I
    //   88: istore #4
    //   90: iload_3
    //   91: aload_0
    //   92: getfield p : I
    //   95: if_icmpge -> 137
    //   98: aload_0
    //   99: getfield q : [Landroidx/recyclerview/widget/StaggeredGridLayoutManager$f;
    //   102: iload_3
    //   103: aaload
    //   104: iload #7
    //   106: invokevirtual k : (I)I
    //   109: istore #6
    //   111: iload #4
    //   113: istore #5
    //   115: iload #6
    //   117: iload #4
    //   119: if_icmple -> 126
    //   122: iload #6
    //   124: istore #5
    //   126: iload_3
    //   127: iconst_1
    //   128: iadd
    //   129: istore_3
    //   130: iload #5
    //   132: istore #4
    //   134: goto -> 90
    //   137: iload #7
    //   139: iload #4
    //   141: isub
    //   142: istore_3
    //   143: iload_3
    //   144: ifge -> 150
    //   147: goto -> 30
    //   150: aload_2
    //   151: getfield g : I
    //   154: iload_3
    //   155: aload_2
    //   156: getfield b : I
    //   159: invokestatic min : (II)I
    //   162: isub
    //   163: istore_3
    //   164: goto -> 35
    //   167: aload_2
    //   168: getfield g : I
    //   171: istore #7
    //   173: aload_0
    //   174: getfield q : [Landroidx/recyclerview/widget/StaggeredGridLayoutManager$f;
    //   177: iconst_0
    //   178: aaload
    //   179: iload #7
    //   181: invokevirtual h : (I)I
    //   184: istore #5
    //   186: iload #4
    //   188: istore_3
    //   189: iload #5
    //   191: istore #4
    //   193: iload_3
    //   194: aload_0
    //   195: getfield p : I
    //   198: if_icmpge -> 240
    //   201: aload_0
    //   202: getfield q : [Landroidx/recyclerview/widget/StaggeredGridLayoutManager$f;
    //   205: iload_3
    //   206: aaload
    //   207: iload #7
    //   209: invokevirtual h : (I)I
    //   212: istore #6
    //   214: iload #4
    //   216: istore #5
    //   218: iload #6
    //   220: iload #4
    //   222: if_icmpge -> 229
    //   225: iload #6
    //   227: istore #5
    //   229: iload_3
    //   230: iconst_1
    //   231: iadd
    //   232: istore_3
    //   233: iload #5
    //   235: istore #4
    //   237: goto -> 193
    //   240: iload #4
    //   242: aload_2
    //   243: getfield g : I
    //   246: isub
    //   247: istore_3
    //   248: iload_3
    //   249: ifge -> 255
    //   252: goto -> 42
    //   255: aload_2
    //   256: getfield f : I
    //   259: istore #4
    //   261: iload_3
    //   262: aload_2
    //   263: getfield b : I
    //   266: invokestatic min : (II)I
    //   269: iload #4
    //   271: iadd
    //   272: istore_3
    //   273: goto -> 47
    //   276: return
  }
  
  public boolean g(RecyclerView.n paramn) {
    return paramn instanceof c;
  }
  
  public void g0(RecyclerView paramRecyclerView) {
    this.B.a();
    v0();
  }
  
  public final void g1(RecyclerView.s params, int paramInt) {
    int i = x() - 1;
    while (i >= 0) {
      View view = w(i);
      if (this.r.e(view) >= paramInt && this.r.o(view) >= paramInt) {
        c c = (c)view.getLayoutParams();
        Objects.requireNonNull(c);
        if (c.e.a.size() == 1)
          return; 
        c.e.l();
        r0(view, params);
        i--;
      } 
    } 
  }
  
  public void h0(RecyclerView paramRecyclerView, int paramInt1, int paramInt2, int paramInt3) {
    Y0(paramInt1, paramInt2, 8);
  }
  
  public final void h1(RecyclerView.s params, int paramInt) {
    while (x() > 0) {
      View view = w(0);
      if (this.r.b(view) <= paramInt && this.r.n(view) <= paramInt) {
        c c = (c)view.getLayoutParams();
        Objects.requireNonNull(c);
        if (c.e.a.size() == 1)
          return; 
        c.e.m();
        r0(view, params);
      } 
    } 
  }
  
  public void i(int paramInt1, int paramInt2, RecyclerView.x paramx, RecyclerView.m.c paramc) {
    if (this.t != 0)
      paramInt1 = paramInt2; 
    if (x() != 0) {
      if (paramInt1 == 0)
        return; 
      e1(paramInt1, paramx);
      int[] arrayOfInt = this.J;
      if (arrayOfInt == null || arrayOfInt.length < this.p)
        this.J = new int[this.p]; 
      paramInt2 = 0;
      for (paramInt1 = 0; paramInt2 < this.p; paramInt1 = i) {
        n n1 = this.v;
        if (n1.d == -1) {
          i = n1.f;
          j = this.q[paramInt2].k(i);
        } else {
          i = this.q[paramInt2].h(n1.g);
          j = this.v.g;
        } 
        int j = i - j;
        int i = paramInt1;
        if (j >= 0) {
          this.J[paramInt1] = j;
          i = paramInt1 + 1;
        } 
        paramInt2++;
      } 
      Arrays.sort(this.J, 0, paramInt1);
      paramInt2 = 0;
      while (paramInt2 < paramInt1) {
        int i = this.v.c;
        if (i >= 0 && i < paramx.b()) {
          i = 1;
        } else {
          i = 0;
        } 
        if (i != 0) {
          i = this.v.c;
          int j = this.J[paramInt2];
          ((m.b)paramc).a(i, j);
          n n1 = this.v;
          n1.c += n1.d;
          paramInt2++;
        } 
      } 
    } 
  }
  
  public void i0(RecyclerView paramRecyclerView, int paramInt1, int paramInt2) {
    Y0(paramInt1, paramInt2, 2);
  }
  
  public final void i1() {
    int i;
    if (this.t == 1 || !a1()) {
      boolean bool = this.w;
    } else {
      i = this.w ^ true;
    } 
    this.x = i;
  }
  
  public void j0(RecyclerView paramRecyclerView, int paramInt1, int paramInt2, Object paramObject) {
    Y0(paramInt1, paramInt2, 4);
  }
  
  public int j1(int paramInt, RecyclerView.s params, RecyclerView.x paramx) {
    if (x() != 0) {
      if (paramInt == 0)
        return 0; 
      e1(paramInt, paramx);
      int i = P0(params, this.v, paramx);
      if (this.v.b >= i)
        if (paramInt < 0) {
          paramInt = -i;
        } else {
          paramInt = i;
        }  
      this.r.p(-paramInt);
      this.D = this.x;
      n n1 = this.v;
      n1.b = 0;
      f1(params, n1);
      return paramInt;
    } 
    return 0;
  }
  
  public int k(RecyclerView.x paramx) {
    return M0(paramx);
  }
  
  public void k0(RecyclerView.s params, RecyclerView.x paramx) {
    c1(params, paramx, true);
  }
  
  public final void k1(int paramInt) {
    boolean bool1;
    n n1 = this.v;
    n1.e = paramInt;
    boolean bool2 = this.x;
    boolean bool = true;
    if (paramInt == -1) {
      bool1 = true;
    } else {
      bool1 = false;
    } 
    if (bool2 == bool1) {
      paramInt = bool;
    } else {
      paramInt = -1;
    } 
    n1.d = paramInt;
  }
  
  public int l(RecyclerView.x paramx) {
    return N0(paramx);
  }
  
  public void l0(RecyclerView.x paramx) {
    this.z = -1;
    this.A = Integer.MIN_VALUE;
    this.F = null;
    this.H.b();
  }
  
  public void l1(int paramInt) {
    d(null);
    if (paramInt != this.p) {
      this.B.a();
      v0();
      this.p = paramInt;
      this.y = new BitSet(this.p);
      this.q = new f[this.p];
      for (paramInt = 0; paramInt < this.p; paramInt++)
        this.q[paramInt] = new f(this, paramInt); 
      v0();
    } 
  }
  
  public int m(RecyclerView.x paramx) {
    return O0(paramx);
  }
  
  public void m0(Parcelable paramParcelable) {
    if (paramParcelable instanceof e) {
      paramParcelable = paramParcelable;
      this.F = (e)paramParcelable;
      if (this.z != -1) {
        ((e)paramParcelable).k = null;
        ((e)paramParcelable).j = 0;
        ((e)paramParcelable).h = -1;
        ((e)paramParcelable).i = -1;
        ((e)paramParcelable).k = null;
        ((e)paramParcelable).j = 0;
        ((e)paramParcelable).l = 0;
        ((e)paramParcelable).m = null;
        ((e)paramParcelable).n = null;
      } 
      v0();
    } 
  }
  
  public final void m1(int paramInt1, int paramInt2) {
    for (int i = 0; i < this.p; i++) {
      if (!(this.q[i]).a.isEmpty())
        o1(this.q[i], paramInt1, paramInt2); 
    } 
  }
  
  public int n(RecyclerView.x paramx) {
    return M0(paramx);
  }
  
  public Parcelable n0() {
    // Byte code:
    //   0: aload_0
    //   1: getfield F : Landroidx/recyclerview/widget/StaggeredGridLayoutManager$e;
    //   4: astore #4
    //   6: aload #4
    //   8: ifnull -> 21
    //   11: new androidx/recyclerview/widget/StaggeredGridLayoutManager$e
    //   14: dup
    //   15: aload #4
    //   17: invokespecial <init> : (Landroidx/recyclerview/widget/StaggeredGridLayoutManager$e;)V
    //   20: areturn
    //   21: new androidx/recyclerview/widget/StaggeredGridLayoutManager$e
    //   24: dup
    //   25: invokespecial <init> : ()V
    //   28: astore #5
    //   30: aload #5
    //   32: aload_0
    //   33: getfield w : Z
    //   36: putfield o : Z
    //   39: aload #5
    //   41: aload_0
    //   42: getfield D : Z
    //   45: putfield p : Z
    //   48: aload #5
    //   50: aload_0
    //   51: getfield E : Z
    //   54: putfield q : Z
    //   57: aload_0
    //   58: getfield B : Landroidx/recyclerview/widget/StaggeredGridLayoutManager$d;
    //   61: astore #4
    //   63: iconst_0
    //   64: istore_2
    //   65: aload #4
    //   67: ifnull -> 110
    //   70: aload #4
    //   72: getfield a : [I
    //   75: astore #6
    //   77: aload #6
    //   79: ifnull -> 110
    //   82: aload #5
    //   84: aload #6
    //   86: putfield m : [I
    //   89: aload #5
    //   91: aload #6
    //   93: arraylength
    //   94: putfield l : I
    //   97: aload #5
    //   99: aload #4
    //   101: getfield b : Ljava/util/List;
    //   104: putfield n : Ljava/util/List;
    //   107: goto -> 116
    //   110: aload #5
    //   112: iconst_0
    //   113: putfield l : I
    //   116: aload_0
    //   117: invokevirtual x : ()I
    //   120: istore_1
    //   121: iconst_m1
    //   122: istore_3
    //   123: iload_1
    //   124: ifle -> 312
    //   127: aload_0
    //   128: getfield D : Z
    //   131: ifeq -> 142
    //   134: aload_0
    //   135: invokevirtual V0 : ()I
    //   138: istore_1
    //   139: goto -> 147
    //   142: aload_0
    //   143: invokevirtual U0 : ()I
    //   146: istore_1
    //   147: aload #5
    //   149: iload_1
    //   150: putfield h : I
    //   153: aload_0
    //   154: getfield x : Z
    //   157: ifeq -> 170
    //   160: aload_0
    //   161: iconst_1
    //   162: invokevirtual Q0 : (Z)Landroid/view/View;
    //   165: astore #4
    //   167: goto -> 177
    //   170: aload_0
    //   171: iconst_1
    //   172: invokevirtual R0 : (Z)Landroid/view/View;
    //   175: astore #4
    //   177: aload #4
    //   179: ifnonnull -> 187
    //   182: iload_3
    //   183: istore_1
    //   184: goto -> 194
    //   187: aload_0
    //   188: aload #4
    //   190: invokevirtual Q : (Landroid/view/View;)I
    //   193: istore_1
    //   194: aload #5
    //   196: iload_1
    //   197: putfield i : I
    //   200: aload_0
    //   201: getfield p : I
    //   204: istore_1
    //   205: aload #5
    //   207: iload_1
    //   208: putfield j : I
    //   211: aload #5
    //   213: iload_1
    //   214: newarray int
    //   216: putfield k : [I
    //   219: iload_2
    //   220: aload_0
    //   221: getfield p : I
    //   224: if_icmpge -> 330
    //   227: aload_0
    //   228: getfield D : Z
    //   231: ifeq -> 265
    //   234: aload_0
    //   235: getfield q : [Landroidx/recyclerview/widget/StaggeredGridLayoutManager$f;
    //   238: iload_2
    //   239: aaload
    //   240: ldc -2147483648
    //   242: invokevirtual h : (I)I
    //   245: istore_3
    //   246: iload_3
    //   247: istore_1
    //   248: iload_3
    //   249: ldc -2147483648
    //   251: if_icmpeq -> 297
    //   254: aload_0
    //   255: getfield r : Landroidx/recyclerview/widget/s;
    //   258: invokevirtual g : ()I
    //   261: istore_1
    //   262: goto -> 293
    //   265: aload_0
    //   266: getfield q : [Landroidx/recyclerview/widget/StaggeredGridLayoutManager$f;
    //   269: iload_2
    //   270: aaload
    //   271: ldc -2147483648
    //   273: invokevirtual k : (I)I
    //   276: istore_3
    //   277: iload_3
    //   278: istore_1
    //   279: iload_3
    //   280: ldc -2147483648
    //   282: if_icmpeq -> 297
    //   285: aload_0
    //   286: getfield r : Landroidx/recyclerview/widget/s;
    //   289: invokevirtual k : ()I
    //   292: istore_1
    //   293: iload_3
    //   294: iload_1
    //   295: isub
    //   296: istore_1
    //   297: aload #5
    //   299: getfield k : [I
    //   302: iload_2
    //   303: iload_1
    //   304: iastore
    //   305: iload_2
    //   306: iconst_1
    //   307: iadd
    //   308: istore_2
    //   309: goto -> 219
    //   312: aload #5
    //   314: iconst_m1
    //   315: putfield h : I
    //   318: aload #5
    //   320: iconst_m1
    //   321: putfield i : I
    //   324: aload #5
    //   326: iconst_0
    //   327: putfield j : I
    //   330: aload #5
    //   332: areturn
  }
  
  public final void n1(int paramInt, RecyclerView.x paramx) {
    // Byte code:
    //   0: aload_0
    //   1: getfield v : Landroidx/recyclerview/widget/n;
    //   4: astore #8
    //   6: iconst_0
    //   7: istore #6
    //   9: aload #8
    //   11: iconst_0
    //   12: putfield b : I
    //   15: aload #8
    //   17: iload_1
    //   18: putfield c : I
    //   21: aload_0
    //   22: getfield e : Landroidx/recyclerview/widget/RecyclerView$w;
    //   25: astore #8
    //   27: aload #8
    //   29: ifnull -> 45
    //   32: aload #8
    //   34: getfield e : Z
    //   37: ifeq -> 45
    //   40: iconst_1
    //   41: istore_3
    //   42: goto -> 47
    //   45: iconst_0
    //   46: istore_3
    //   47: iload_3
    //   48: ifeq -> 112
    //   51: aload_2
    //   52: getfield a : I
    //   55: istore_3
    //   56: iload_3
    //   57: iconst_m1
    //   58: if_icmpeq -> 112
    //   61: aload_0
    //   62: getfield x : Z
    //   65: istore #7
    //   67: iload_3
    //   68: iload_1
    //   69: if_icmpge -> 78
    //   72: iconst_1
    //   73: istore #5
    //   75: goto -> 81
    //   78: iconst_0
    //   79: istore #5
    //   81: iload #7
    //   83: iload #5
    //   85: if_icmpne -> 99
    //   88: aload_0
    //   89: getfield r : Landroidx/recyclerview/widget/s;
    //   92: invokevirtual l : ()I
    //   95: istore_1
    //   96: goto -> 114
    //   99: aload_0
    //   100: getfield r : Landroidx/recyclerview/widget/s;
    //   103: invokevirtual l : ()I
    //   106: istore_3
    //   107: iconst_0
    //   108: istore_1
    //   109: goto -> 116
    //   112: iconst_0
    //   113: istore_1
    //   114: iconst_0
    //   115: istore_3
    //   116: aload_0
    //   117: getfield b : Landroidx/recyclerview/widget/RecyclerView;
    //   120: astore_2
    //   121: aload_2
    //   122: ifnull -> 138
    //   125: aload_2
    //   126: getfield n : Z
    //   129: ifeq -> 138
    //   132: iconst_1
    //   133: istore #4
    //   135: goto -> 141
    //   138: iconst_0
    //   139: istore #4
    //   141: iload #4
    //   143: ifeq -> 181
    //   146: aload_0
    //   147: getfield v : Landroidx/recyclerview/widget/n;
    //   150: aload_0
    //   151: getfield r : Landroidx/recyclerview/widget/s;
    //   154: invokevirtual k : ()I
    //   157: iload_3
    //   158: isub
    //   159: putfield f : I
    //   162: aload_0
    //   163: getfield v : Landroidx/recyclerview/widget/n;
    //   166: aload_0
    //   167: getfield r : Landroidx/recyclerview/widget/s;
    //   170: invokevirtual g : ()I
    //   173: iload_1
    //   174: iadd
    //   175: putfield g : I
    //   178: goto -> 206
    //   181: aload_0
    //   182: getfield v : Landroidx/recyclerview/widget/n;
    //   185: aload_0
    //   186: getfield r : Landroidx/recyclerview/widget/s;
    //   189: invokevirtual f : ()I
    //   192: iload_1
    //   193: iadd
    //   194: putfield g : I
    //   197: aload_0
    //   198: getfield v : Landroidx/recyclerview/widget/n;
    //   201: iload_3
    //   202: ineg
    //   203: putfield f : I
    //   206: aload_0
    //   207: getfield v : Landroidx/recyclerview/widget/n;
    //   210: astore_2
    //   211: aload_2
    //   212: iconst_0
    //   213: putfield h : Z
    //   216: aload_2
    //   217: iconst_1
    //   218: putfield a : Z
    //   221: iload #6
    //   223: istore #5
    //   225: aload_0
    //   226: getfield r : Landroidx/recyclerview/widget/s;
    //   229: invokevirtual i : ()I
    //   232: ifne -> 252
    //   235: iload #6
    //   237: istore #5
    //   239: aload_0
    //   240: getfield r : Landroidx/recyclerview/widget/s;
    //   243: invokevirtual f : ()I
    //   246: ifne -> 252
    //   249: iconst_1
    //   250: istore #5
    //   252: aload_2
    //   253: iload #5
    //   255: putfield i : Z
    //   258: return
  }
  
  public int o(RecyclerView.x paramx) {
    return N0(paramx);
  }
  
  public void o0(int paramInt) {
    if (paramInt == 0)
      L0(); 
  }
  
  public final void o1(f paramf, int paramInt1, int paramInt2) {
    int i = paramf.d;
    if (paramInt1 == -1) {
      paramInt1 = paramf.b;
      if (paramInt1 == Integer.MIN_VALUE) {
        paramf.c();
        paramInt1 = paramf.b;
      } 
      if (paramInt1 + i <= paramInt2) {
        this.y.set(paramf.e, false);
        return;
      } 
    } else {
      paramInt1 = paramf.c;
      if (paramInt1 == Integer.MIN_VALUE) {
        paramf.b();
        paramInt1 = paramf.c;
      } 
      if (paramInt1 - i >= paramInt2) {
        this.y.set(paramf.e, false);
        return;
      } 
    } 
  }
  
  public int p(RecyclerView.x paramx) {
    return O0(paramx);
  }
  
  public final int p1(int paramInt1, int paramInt2, int paramInt3) {
    if (paramInt2 == 0 && paramInt3 == 0)
      return paramInt1; 
    int i = View.MeasureSpec.getMode(paramInt1);
    return (i == Integer.MIN_VALUE || i == 1073741824) ? View.MeasureSpec.makeMeasureSpec(Math.max(0, View.MeasureSpec.getSize(paramInt1) - paramInt2 - paramInt3), i) : paramInt1;
  }
  
  public RecyclerView.n t() {
    return (this.t == 0) ? new c(-2, -1) : new c(-1, -2);
  }
  
  public RecyclerView.n u(Context paramContext, AttributeSet paramAttributeSet) {
    return new c(paramContext, paramAttributeSet);
  }
  
  public RecyclerView.n v(ViewGroup.LayoutParams paramLayoutParams) {
    return (paramLayoutParams instanceof ViewGroup.MarginLayoutParams) ? new c((ViewGroup.MarginLayoutParams)paramLayoutParams) : new c(paramLayoutParams);
  }
  
  public int w0(int paramInt, RecyclerView.s params, RecyclerView.x paramx) {
    return j1(paramInt, params, paramx);
  }
  
  public void x0(int paramInt) {
    e e1 = this.F;
    if (e1 != null && e1.h != paramInt) {
      e1.k = null;
      e1.j = 0;
      e1.h = -1;
      e1.i = -1;
    } 
    this.z = paramInt;
    this.A = Integer.MIN_VALUE;
    v0();
  }
  
  public int y0(int paramInt, RecyclerView.s params, RecyclerView.x paramx) {
    return j1(paramInt, params, paramx);
  }
  
  public class a implements Runnable {
    public a(StaggeredGridLayoutManager this$0) {}
    
    public void run() {
      this.h.L0();
    }
  }
  
  public class b {
    public int a;
    
    public int b;
    
    public boolean c;
    
    public boolean d;
    
    public boolean e;
    
    public int[] f;
    
    public b(StaggeredGridLayoutManager this$0) {
      b();
    }
    
    public void a() {
      int i;
      if (this.c) {
        i = this.g.r.g();
      } else {
        i = this.g.r.k();
      } 
      this.b = i;
    }
    
    public void b() {
      this.a = -1;
      this.b = Integer.MIN_VALUE;
      this.c = false;
      this.d = false;
      this.e = false;
      int[] arrayOfInt = this.f;
      if (arrayOfInt != null)
        Arrays.fill(arrayOfInt, -1); 
    }
  }
  
  public static class c extends RecyclerView.n {
    public StaggeredGridLayoutManager.f e;
    
    public c(int param1Int1, int param1Int2) {
      super(param1Int1, param1Int2);
    }
    
    public c(Context param1Context, AttributeSet param1AttributeSet) {
      super(param1Context, param1AttributeSet);
    }
    
    public c(ViewGroup.LayoutParams param1LayoutParams) {
      super(param1LayoutParams);
    }
    
    public c(ViewGroup.MarginLayoutParams param1MarginLayoutParams) {
      super(param1MarginLayoutParams);
    }
  }
  
  public static class d {
    public int[] a;
    
    public List<a> b;
    
    public void a() {
      int[] arrayOfInt = this.a;
      if (arrayOfInt != null)
        Arrays.fill(arrayOfInt, -1); 
      this.b = null;
    }
    
    public void b(int param1Int) {
      int[] arrayOfInt = this.a;
      if (arrayOfInt == null) {
        arrayOfInt = new int[Math.max(param1Int, 10) + 1];
        this.a = arrayOfInt;
        Arrays.fill(arrayOfInt, -1);
        return;
      } 
      if (param1Int >= arrayOfInt.length) {
        int i;
        for (i = arrayOfInt.length; i <= param1Int; i *= 2);
        int[] arrayOfInt1 = new int[i];
        this.a = arrayOfInt1;
        System.arraycopy(arrayOfInt, 0, arrayOfInt1, 0, arrayOfInt.length);
        arrayOfInt1 = this.a;
        Arrays.fill(arrayOfInt1, arrayOfInt.length, arrayOfInt1.length, -1);
      } 
    }
    
    public a c(int param1Int) {
      List<a> list = this.b;
      if (list == null)
        return null; 
      for (int i = list.size() - 1; i >= 0; i--) {
        a a = this.b.get(i);
        if (a.h == param1Int)
          return a; 
      } 
      return null;
    }
    
    public int d(int param1Int) {
      // Byte code:
      //   0: aload_0
      //   1: getfield a : [I
      //   4: astore #4
      //   6: aload #4
      //   8: ifnonnull -> 13
      //   11: iconst_m1
      //   12: ireturn
      //   13: iload_1
      //   14: aload #4
      //   16: arraylength
      //   17: if_icmplt -> 22
      //   20: iconst_m1
      //   21: ireturn
      //   22: aload_0
      //   23: getfield b : Ljava/util/List;
      //   26: ifnonnull -> 34
      //   29: iconst_m1
      //   30: istore_2
      //   31: goto -> 144
      //   34: aload_0
      //   35: iload_1
      //   36: invokevirtual c : (I)Landroidx/recyclerview/widget/StaggeredGridLayoutManager$d$a;
      //   39: astore #4
      //   41: aload #4
      //   43: ifnull -> 58
      //   46: aload_0
      //   47: getfield b : Ljava/util/List;
      //   50: aload #4
      //   52: invokeinterface remove : (Ljava/lang/Object;)Z
      //   57: pop
      //   58: aload_0
      //   59: getfield b : Ljava/util/List;
      //   62: invokeinterface size : ()I
      //   67: istore_3
      //   68: iconst_0
      //   69: istore_2
      //   70: iload_2
      //   71: iload_3
      //   72: if_icmpge -> 105
      //   75: aload_0
      //   76: getfield b : Ljava/util/List;
      //   79: iload_2
      //   80: invokeinterface get : (I)Ljava/lang/Object;
      //   85: checkcast androidx/recyclerview/widget/StaggeredGridLayoutManager$d$a
      //   88: getfield h : I
      //   91: iload_1
      //   92: if_icmplt -> 98
      //   95: goto -> 107
      //   98: iload_2
      //   99: iconst_1
      //   100: iadd
      //   101: istore_2
      //   102: goto -> 70
      //   105: iconst_m1
      //   106: istore_2
      //   107: iload_2
      //   108: iconst_m1
      //   109: if_icmpeq -> 29
      //   112: aload_0
      //   113: getfield b : Ljava/util/List;
      //   116: iload_2
      //   117: invokeinterface get : (I)Ljava/lang/Object;
      //   122: checkcast androidx/recyclerview/widget/StaggeredGridLayoutManager$d$a
      //   125: astore #4
      //   127: aload_0
      //   128: getfield b : Ljava/util/List;
      //   131: iload_2
      //   132: invokeinterface remove : (I)Ljava/lang/Object;
      //   137: pop
      //   138: aload #4
      //   140: getfield h : I
      //   143: istore_2
      //   144: iload_2
      //   145: iconst_m1
      //   146: if_icmpne -> 171
      //   149: aload_0
      //   150: getfield a : [I
      //   153: astore #4
      //   155: aload #4
      //   157: iload_1
      //   158: aload #4
      //   160: arraylength
      //   161: iconst_m1
      //   162: invokestatic fill : ([IIII)V
      //   165: aload_0
      //   166: getfield a : [I
      //   169: arraylength
      //   170: ireturn
      //   171: iload_2
      //   172: iconst_1
      //   173: iadd
      //   174: aload_0
      //   175: getfield a : [I
      //   178: arraylength
      //   179: invokestatic min : (II)I
      //   182: istore_2
      //   183: aload_0
      //   184: getfield a : [I
      //   187: iload_1
      //   188: iload_2
      //   189: iconst_m1
      //   190: invokestatic fill : ([IIII)V
      //   193: iload_2
      //   194: ireturn
    }
    
    public void e(int param1Int1, int param1Int2) {
      int[] arrayOfInt = this.a;
      if (arrayOfInt != null) {
        if (param1Int1 >= arrayOfInt.length)
          return; 
        int i = param1Int1 + param1Int2;
        b(i);
        arrayOfInt = this.a;
        System.arraycopy(arrayOfInt, param1Int1, arrayOfInt, i, arrayOfInt.length - param1Int1 - param1Int2);
        Arrays.fill(this.a, param1Int1, i, -1);
        List<a> list = this.b;
        if (list == null)
          return; 
        for (i = list.size() - 1; i >= 0; i--) {
          a a = this.b.get(i);
          int j = a.h;
          if (j >= param1Int1)
            a.h = j + param1Int2; 
        } 
      } 
    }
    
    public void f(int param1Int1, int param1Int2) {
      int[] arrayOfInt = this.a;
      if (arrayOfInt != null) {
        if (param1Int1 >= arrayOfInt.length)
          return; 
        int j = param1Int1 + param1Int2;
        b(j);
        arrayOfInt = this.a;
        System.arraycopy(arrayOfInt, j, arrayOfInt, param1Int1, arrayOfInt.length - param1Int1 - param1Int2);
        arrayOfInt = this.a;
        Arrays.fill(arrayOfInt, arrayOfInt.length - param1Int2, arrayOfInt.length, -1);
        List<a> list = this.b;
        if (list == null)
          return; 
        for (int i = list.size() - 1; i >= 0; i--) {
          a a = this.b.get(i);
          int k = a.h;
          if (k >= param1Int1)
            if (k < j) {
              this.b.remove(i);
            } else {
              a.h = k - param1Int2;
            }  
        } 
      } 
    }
    
    @SuppressLint({"BanParcelableUsage"})
    public static class a implements Parcelable {
      public static final Parcelable.Creator<a> CREATOR = new a();
      
      public int h;
      
      public int i;
      
      public int[] j;
      
      public boolean k;
      
      public a() {}
      
      public a(Parcel param2Parcel) {
        this.h = param2Parcel.readInt();
        this.i = param2Parcel.readInt();
        int i = param2Parcel.readInt();
        boolean bool = true;
        if (i != 1)
          bool = false; 
        this.k = bool;
        i = param2Parcel.readInt();
        if (i > 0) {
          int[] arrayOfInt = new int[i];
          this.j = arrayOfInt;
          param2Parcel.readIntArray(arrayOfInt);
        } 
      }
      
      public int describeContents() {
        return 0;
      }
      
      public String toString() {
        StringBuilder stringBuilder = android.support.v4.media.c.a("FullSpanItem{mPosition=");
        stringBuilder.append(this.h);
        stringBuilder.append(", mGapDir=");
        stringBuilder.append(this.i);
        stringBuilder.append(", mHasUnwantedGapAfter=");
        stringBuilder.append(this.k);
        stringBuilder.append(", mGapPerSpan=");
        stringBuilder.append(Arrays.toString(this.j));
        stringBuilder.append('}');
        return stringBuilder.toString();
      }
      
      public void writeToParcel(Parcel param2Parcel, int param2Int) {
        throw new RuntimeException("d2j fail translate: java.lang.RuntimeException: can not merge I and Z\r\n\tat com.googlecode.dex2jar.ir.TypeClass.merge(TypeClass.java:100)\r\n\tat com.googlecode.dex2jar.ir.ts.TypeTransformer$TypeRef.updateTypeClass(TypeTransformer.java:174)\r\n\tat com.googlecode.dex2jar.ir.ts.TypeTransformer$TypeAnalyze.provideAs(TypeTransformer.java:780)\r\n\tat com.googlecode.dex2jar.ir.ts.TypeTransformer$TypeAnalyze.e1expr(TypeTransformer.java:496)\r\n\tat com.googlecode.dex2jar.ir.ts.TypeTransformer$TypeAnalyze.exExpr(TypeTransformer.java:713)\r\n\tat com.googlecode.dex2jar.ir.ts.TypeTransformer$TypeAnalyze.exExpr(TypeTransformer.java:703)\r\n\tat com.googlecode.dex2jar.ir.ts.TypeTransformer$TypeAnalyze.enexpr(TypeTransformer.java:698)\r\n\tat com.googlecode.dex2jar.ir.ts.TypeTransformer$TypeAnalyze.exExpr(TypeTransformer.java:719)\r\n\tat com.googlecode.dex2jar.ir.ts.TypeTransformer$TypeAnalyze.exExpr(TypeTransformer.java:703)\r\n\tat com.googlecode.dex2jar.ir.ts.TypeTransformer$TypeAnalyze.s1stmt(TypeTransformer.java:810)\r\n\tat com.googlecode.dex2jar.ir.ts.TypeTransformer$TypeAnalyze.sxStmt(TypeTransformer.java:840)\r\n\tat com.googlecode.dex2jar.ir.ts.TypeTransformer$TypeAnalyze.analyze(TypeTransformer.java:206)\r\n\tat com.googlecode.dex2jar.ir.ts.TypeTransformer.transform(TypeTransformer.java:44)\r\n\tat com.googlecode.d2j.dex.Dex2jar$2.optimize(Dex2jar.java:162)\r\n\tat com.googlecode.d2j.dex.Dex2Asm.convertCode(Dex2Asm.java:414)\r\n\tat com.googlecode.d2j.dex.ExDex2Asm.convertCode(ExDex2Asm.java:42)\r\n\tat com.googlecode.d2j.dex.Dex2jar$2.convertCode(Dex2jar.java:128)\r\n\tat com.googlecode.d2j.dex.Dex2Asm.convertMethod(Dex2Asm.java:509)\r\n\tat com.googlecode.d2j.dex.Dex2Asm.convertClass(Dex2Asm.java:406)\r\n\tat com.googlecode.d2j.dex.Dex2Asm.convertDex(Dex2Asm.java:422)\r\n\tat com.googlecode.d2j.dex.Dex2jar.doTranslate(Dex2jar.java:172)\r\n\tat com.googlecode.d2j.dex.Dex2jar.to(Dex2jar.java:272)\r\n\tat com.googlecode.dex2jar.tools.Dex2jarCmd.doCommandLine(Dex2jarCmd.java:108)\r\n\tat com.googlecode.dex2jar.tools.BaseCmd.doMain(BaseCmd.java:288)\r\n\tat com.googlecode.dex2jar.tools.Dex2jarCmd.main(Dex2jarCmd.java:32)\r\n");
      }
      
      public class a implements Parcelable.Creator<a> {
        public Object createFromParcel(Parcel param3Parcel) {
          return new StaggeredGridLayoutManager.d.a(param3Parcel);
        }
        
        public Object[] newArray(int param3Int) {
          return (Object[])new StaggeredGridLayoutManager.d.a[param3Int];
        }
      }
    }
    
    public class a implements Parcelable.Creator<a> {
      public Object createFromParcel(Parcel param2Parcel) {
        return new StaggeredGridLayoutManager.d.a(param2Parcel);
      }
      
      public Object[] newArray(int param2Int) {
        return (Object[])new StaggeredGridLayoutManager.d.a[param2Int];
      }
    }
  }
  
  @SuppressLint({"BanParcelableUsage"})
  public static class a implements Parcelable {
    public static final Parcelable.Creator<a> CREATOR = new a();
    
    public int h;
    
    public int i;
    
    public int[] j;
    
    public boolean k;
    
    public a() {}
    
    public a(Parcel param1Parcel) {
      this.h = param1Parcel.readInt();
      this.i = param1Parcel.readInt();
      int i = param1Parcel.readInt();
      boolean bool = true;
      if (i != 1)
        bool = false; 
      this.k = bool;
      i = param1Parcel.readInt();
      if (i > 0) {
        int[] arrayOfInt = new int[i];
        this.j = arrayOfInt;
        param1Parcel.readIntArray(arrayOfInt);
      } 
    }
    
    public int describeContents() {
      return 0;
    }
    
    public String toString() {
      StringBuilder stringBuilder = android.support.v4.media.c.a("FullSpanItem{mPosition=");
      stringBuilder.append(this.h);
      stringBuilder.append(", mGapDir=");
      stringBuilder.append(this.i);
      stringBuilder.append(", mHasUnwantedGapAfter=");
      stringBuilder.append(this.k);
      stringBuilder.append(", mGapPerSpan=");
      stringBuilder.append(Arrays.toString(this.j));
      stringBuilder.append('}');
      return stringBuilder.toString();
    }
    
    public void writeToParcel(Parcel param1Parcel, int param1Int) {
      throw new RuntimeException("d2j fail translate: java.lang.RuntimeException: can not merge I and Z\r\n\tat com.googlecode.dex2jar.ir.TypeClass.merge(TypeClass.java:100)\r\n\tat com.googlecode.dex2jar.ir.ts.TypeTransformer$TypeRef.updateTypeClass(TypeTransformer.java:174)\r\n\tat com.googlecode.dex2jar.ir.ts.TypeTransformer$TypeAnalyze.provideAs(TypeTransformer.java:780)\r\n\tat com.googlecode.dex2jar.ir.ts.TypeTransformer$TypeAnalyze.e1expr(TypeTransformer.java:496)\r\n\tat com.googlecode.dex2jar.ir.ts.TypeTransformer$TypeAnalyze.exExpr(TypeTransformer.java:713)\r\n\tat com.googlecode.dex2jar.ir.ts.TypeTransformer$TypeAnalyze.exExpr(TypeTransformer.java:703)\r\n\tat com.googlecode.dex2jar.ir.ts.TypeTransformer$TypeAnalyze.enexpr(TypeTransformer.java:698)\r\n\tat com.googlecode.dex2jar.ir.ts.TypeTransformer$TypeAnalyze.exExpr(TypeTransformer.java:719)\r\n\tat com.googlecode.dex2jar.ir.ts.TypeTransformer$TypeAnalyze.exExpr(TypeTransformer.java:703)\r\n\tat com.googlecode.dex2jar.ir.ts.TypeTransformer$TypeAnalyze.s1stmt(TypeTransformer.java:810)\r\n\tat com.googlecode.dex2jar.ir.ts.TypeTransformer$TypeAnalyze.sxStmt(TypeTransformer.java:840)\r\n\tat com.googlecode.dex2jar.ir.ts.TypeTransformer$TypeAnalyze.analyze(TypeTransformer.java:206)\r\n\tat com.googlecode.dex2jar.ir.ts.TypeTransformer.transform(TypeTransformer.java:44)\r\n\tat com.googlecode.d2j.dex.Dex2jar$2.optimize(Dex2jar.java:162)\r\n\tat com.googlecode.d2j.dex.Dex2Asm.convertCode(Dex2Asm.java:414)\r\n\tat com.googlecode.d2j.dex.ExDex2Asm.convertCode(ExDex2Asm.java:42)\r\n\tat com.googlecode.d2j.dex.Dex2jar$2.convertCode(Dex2jar.java:128)\r\n\tat com.googlecode.d2j.dex.Dex2Asm.convertMethod(Dex2Asm.java:509)\r\n\tat com.googlecode.d2j.dex.Dex2Asm.convertClass(Dex2Asm.java:406)\r\n\tat com.googlecode.d2j.dex.Dex2Asm.convertDex(Dex2Asm.java:422)\r\n\tat com.googlecode.d2j.dex.Dex2jar.doTranslate(Dex2jar.java:172)\r\n\tat com.googlecode.d2j.dex.Dex2jar.to(Dex2jar.java:272)\r\n\tat com.googlecode.dex2jar.tools.Dex2jarCmd.doCommandLine(Dex2jarCmd.java:108)\r\n\tat com.googlecode.dex2jar.tools.BaseCmd.doMain(BaseCmd.java:288)\r\n\tat com.googlecode.dex2jar.tools.Dex2jarCmd.main(Dex2jarCmd.java:32)\r\n");
    }
    
    public class a implements Parcelable.Creator<a> {
      public Object createFromParcel(Parcel param3Parcel) {
        return new StaggeredGridLayoutManager.d.a(param3Parcel);
      }
      
      public Object[] newArray(int param3Int) {
        return (Object[])new StaggeredGridLayoutManager.d.a[param3Int];
      }
    }
  }
  
  public class a implements Parcelable.Creator<d.a> {
    public Object createFromParcel(Parcel param1Parcel) {
      return new StaggeredGridLayoutManager.d.a(param1Parcel);
    }
    
    public Object[] newArray(int param1Int) {
      return (Object[])new StaggeredGridLayoutManager.d.a[param1Int];
    }
  }
  
  @SuppressLint({"BanParcelableUsage"})
  public static class e implements Parcelable {
    public static final Parcelable.Creator<e> CREATOR = new a();
    
    public int h;
    
    public int i;
    
    public int j;
    
    public int[] k;
    
    public int l;
    
    public int[] m;
    
    public List<StaggeredGridLayoutManager.d.a> n;
    
    public boolean o;
    
    public boolean p;
    
    public boolean q;
    
    public e() {}
    
    public e(Parcel param1Parcel) {
      this.h = param1Parcel.readInt();
      this.i = param1Parcel.readInt();
      int i = param1Parcel.readInt();
      this.j = i;
      if (i > 0) {
        int[] arrayOfInt = new int[i];
        this.k = arrayOfInt;
        param1Parcel.readIntArray(arrayOfInt);
      } 
      i = param1Parcel.readInt();
      this.l = i;
      if (i > 0) {
        int[] arrayOfInt = new int[i];
        this.m = arrayOfInt;
        param1Parcel.readIntArray(arrayOfInt);
      } 
      i = param1Parcel.readInt();
      boolean bool2 = false;
      if (i == 1) {
        bool1 = true;
      } else {
        bool1 = false;
      } 
      this.o = bool1;
      if (param1Parcel.readInt() == 1) {
        bool1 = true;
      } else {
        bool1 = false;
      } 
      this.p = bool1;
      boolean bool1 = bool2;
      if (param1Parcel.readInt() == 1)
        bool1 = true; 
      this.q = bool1;
      this.n = param1Parcel.readArrayList(StaggeredGridLayoutManager.d.a.class.getClassLoader());
    }
    
    public e(e param1e) {
      this.j = param1e.j;
      this.h = param1e.h;
      this.i = param1e.i;
      this.k = param1e.k;
      this.l = param1e.l;
      this.m = param1e.m;
      this.o = param1e.o;
      this.p = param1e.p;
      this.q = param1e.q;
      this.n = param1e.n;
    }
    
    public int describeContents() {
      return 0;
    }
    
    public void writeToParcel(Parcel param1Parcel, int param1Int) {
      throw new RuntimeException("d2j fail translate: java.lang.RuntimeException: can not merge I and Z\r\n\tat com.googlecode.dex2jar.ir.TypeClass.merge(TypeClass.java:100)\r\n\tat com.googlecode.dex2jar.ir.ts.TypeTransformer$TypeRef.updateTypeClass(TypeTransformer.java:174)\r\n\tat com.googlecode.dex2jar.ir.ts.TypeTransformer$TypeAnalyze.provideAs(TypeTransformer.java:780)\r\n\tat com.googlecode.dex2jar.ir.ts.TypeTransformer$TypeAnalyze.e1expr(TypeTransformer.java:496)\r\n\tat com.googlecode.dex2jar.ir.ts.TypeTransformer$TypeAnalyze.exExpr(TypeTransformer.java:713)\r\n\tat com.googlecode.dex2jar.ir.ts.TypeTransformer$TypeAnalyze.exExpr(TypeTransformer.java:703)\r\n\tat com.googlecode.dex2jar.ir.ts.TypeTransformer$TypeAnalyze.enexpr(TypeTransformer.java:698)\r\n\tat com.googlecode.dex2jar.ir.ts.TypeTransformer$TypeAnalyze.exExpr(TypeTransformer.java:719)\r\n\tat com.googlecode.dex2jar.ir.ts.TypeTransformer$TypeAnalyze.exExpr(TypeTransformer.java:703)\r\n\tat com.googlecode.dex2jar.ir.ts.TypeTransformer$TypeAnalyze.s1stmt(TypeTransformer.java:810)\r\n\tat com.googlecode.dex2jar.ir.ts.TypeTransformer$TypeAnalyze.sxStmt(TypeTransformer.java:840)\r\n\tat com.googlecode.dex2jar.ir.ts.TypeTransformer$TypeAnalyze.analyze(TypeTransformer.java:206)\r\n\tat com.googlecode.dex2jar.ir.ts.TypeTransformer.transform(TypeTransformer.java:44)\r\n\tat com.googlecode.d2j.dex.Dex2jar$2.optimize(Dex2jar.java:162)\r\n\tat com.googlecode.d2j.dex.Dex2Asm.convertCode(Dex2Asm.java:414)\r\n\tat com.googlecode.d2j.dex.ExDex2Asm.convertCode(ExDex2Asm.java:42)\r\n\tat com.googlecode.d2j.dex.Dex2jar$2.convertCode(Dex2jar.java:128)\r\n\tat com.googlecode.d2j.dex.Dex2Asm.convertMethod(Dex2Asm.java:509)\r\n\tat com.googlecode.d2j.dex.Dex2Asm.convertClass(Dex2Asm.java:406)\r\n\tat com.googlecode.d2j.dex.Dex2Asm.convertDex(Dex2Asm.java:422)\r\n\tat com.googlecode.d2j.dex.Dex2jar.doTranslate(Dex2jar.java:172)\r\n\tat com.googlecode.d2j.dex.Dex2jar.to(Dex2jar.java:272)\r\n\tat com.googlecode.dex2jar.tools.Dex2jarCmd.doCommandLine(Dex2jarCmd.java:108)\r\n\tat com.googlecode.dex2jar.tools.BaseCmd.doMain(BaseCmd.java:288)\r\n\tat com.googlecode.dex2jar.tools.Dex2jarCmd.main(Dex2jarCmd.java:32)\r\n");
    }
    
    public class a implements Parcelable.Creator<e> {
      public Object createFromParcel(Parcel param2Parcel) {
        return new StaggeredGridLayoutManager.e(param2Parcel);
      }
      
      public Object[] newArray(int param2Int) {
        return (Object[])new StaggeredGridLayoutManager.e[param2Int];
      }
    }
  }
  
  public class a implements Parcelable.Creator<e> {
    public Object createFromParcel(Parcel param1Parcel) {
      return new StaggeredGridLayoutManager.e(param1Parcel);
    }
    
    public Object[] newArray(int param1Int) {
      return (Object[])new StaggeredGridLayoutManager.e[param1Int];
    }
  }
  
  public class f {
    public ArrayList<View> a = new ArrayList<View>();
    
    public int b = Integer.MIN_VALUE;
    
    public int c = Integer.MIN_VALUE;
    
    public int d = 0;
    
    public final int e;
    
    public f(StaggeredGridLayoutManager this$0, int param1Int) {
      this.e = param1Int;
    }
    
    public void a(View param1View) {
      StaggeredGridLayoutManager.c c = j(param1View);
      c.e = this;
      this.a.add(param1View);
      this.c = Integer.MIN_VALUE;
      if (this.a.size() == 1)
        this.b = Integer.MIN_VALUE; 
      if (c.c() || c.b()) {
        int i = this.d;
        this.d = this.f.r.c(param1View) + i;
      } 
    }
    
    public void b() {
      ArrayList<View> arrayList = this.a;
      View view = arrayList.get(arrayList.size() - 1);
      StaggeredGridLayoutManager.c c = j(view);
      this.c = this.f.r.b(view);
      Objects.requireNonNull(c);
    }
    
    public void c() {
      View view = this.a.get(0);
      StaggeredGridLayoutManager.c c = j(view);
      this.b = this.f.r.e(view);
      Objects.requireNonNull(c);
    }
    
    public void d() {
      this.a.clear();
      this.b = Integer.MIN_VALUE;
      this.c = Integer.MIN_VALUE;
      this.d = 0;
    }
    
    public int e() {
      boolean bool;
      int i;
      if (this.f.w) {
        bool = this.a.size() - 1;
        i = -1;
      } else {
        bool = false;
        i = this.a.size();
      } 
      return g(bool, i, true);
    }
    
    public int f() {
      int i;
      byte b;
      if (this.f.w) {
        i = 0;
        b = this.a.size();
      } else {
        i = this.a.size() - 1;
        b = -1;
      } 
      return g(i, b, true);
    }
    
    public int g(int param1Int1, int param1Int2, boolean param1Boolean) {
      byte b;
      int i = this.f.r.k();
      int j = this.f.r.g();
      if (param1Int2 > param1Int1) {
        b = 1;
      } else {
        b = -1;
      } 
      while (param1Int1 != param1Int2) {
        boolean bool1;
        View view = this.a.get(param1Int1);
        int k = this.f.r.e(view);
        int m = this.f.r.b(view);
        boolean bool2 = false;
        if (param1Boolean ? (k <= j) : (k < j)) {
          bool1 = true;
        } else {
          bool1 = false;
        } 
        if (param1Boolean ? (m >= i) : (m > i))
          bool2 = true; 
        if (bool1 && bool2 && (k < i || m > j))
          return this.f.Q(view); 
        param1Int1 += b;
      } 
      return -1;
    }
    
    public int h(int param1Int) {
      int i = this.c;
      if (i != Integer.MIN_VALUE)
        return i; 
      if (this.a.size() == 0)
        return param1Int; 
      b();
      return this.c;
    }
    
    public View i(int param1Int1, int param1Int2) {
      // Byte code:
      //   0: aconst_null
      //   1: astore #5
      //   3: aconst_null
      //   4: astore #4
      //   6: iload_2
      //   7: iconst_m1
      //   8: if_icmpne -> 123
      //   11: aload_0
      //   12: getfield a : Ljava/util/ArrayList;
      //   15: invokevirtual size : ()I
      //   18: istore_3
      //   19: iconst_0
      //   20: istore_2
      //   21: aload #4
      //   23: astore #5
      //   25: iload_2
      //   26: iload_3
      //   27: if_icmpge -> 238
      //   30: aload_0
      //   31: getfield a : Ljava/util/ArrayList;
      //   34: iload_2
      //   35: invokevirtual get : (I)Ljava/lang/Object;
      //   38: checkcast android/view/View
      //   41: astore #6
      //   43: aload_0
      //   44: getfield f : Landroidx/recyclerview/widget/StaggeredGridLayoutManager;
      //   47: astore #7
      //   49: aload #7
      //   51: getfield w : Z
      //   54: ifeq -> 72
      //   57: aload #4
      //   59: astore #5
      //   61: aload #7
      //   63: aload #6
      //   65: invokevirtual Q : (Landroid/view/View;)I
      //   68: iload_1
      //   69: if_icmple -> 238
      //   72: aload_0
      //   73: getfield f : Landroidx/recyclerview/widget/StaggeredGridLayoutManager;
      //   76: astore #5
      //   78: aload #5
      //   80: getfield w : Z
      //   83: ifne -> 100
      //   86: aload #5
      //   88: aload #6
      //   90: invokevirtual Q : (Landroid/view/View;)I
      //   93: iload_1
      //   94: if_icmplt -> 100
      //   97: aload #4
      //   99: areturn
      //   100: aload #4
      //   102: astore #5
      //   104: aload #6
      //   106: invokevirtual hasFocusable : ()Z
      //   109: ifeq -> 238
      //   112: iload_2
      //   113: iconst_1
      //   114: iadd
      //   115: istore_2
      //   116: aload #6
      //   118: astore #4
      //   120: goto -> 21
      //   123: aload_0
      //   124: getfield a : Ljava/util/ArrayList;
      //   127: invokevirtual size : ()I
      //   130: iconst_1
      //   131: isub
      //   132: istore_2
      //   133: aload #5
      //   135: astore #4
      //   137: aload #4
      //   139: astore #5
      //   141: iload_2
      //   142: iflt -> 238
      //   145: aload_0
      //   146: getfield a : Ljava/util/ArrayList;
      //   149: iload_2
      //   150: invokevirtual get : (I)Ljava/lang/Object;
      //   153: checkcast android/view/View
      //   156: astore #6
      //   158: aload_0
      //   159: getfield f : Landroidx/recyclerview/widget/StaggeredGridLayoutManager;
      //   162: astore #7
      //   164: aload #7
      //   166: getfield w : Z
      //   169: ifeq -> 187
      //   172: aload #4
      //   174: astore #5
      //   176: aload #7
      //   178: aload #6
      //   180: invokevirtual Q : (Landroid/view/View;)I
      //   183: iload_1
      //   184: if_icmpge -> 238
      //   187: aload_0
      //   188: getfield f : Landroidx/recyclerview/widget/StaggeredGridLayoutManager;
      //   191: astore #5
      //   193: aload #5
      //   195: getfield w : Z
      //   198: ifne -> 215
      //   201: aload #5
      //   203: aload #6
      //   205: invokevirtual Q : (Landroid/view/View;)I
      //   208: iload_1
      //   209: if_icmpgt -> 215
      //   212: aload #4
      //   214: areturn
      //   215: aload #4
      //   217: astore #5
      //   219: aload #6
      //   221: invokevirtual hasFocusable : ()Z
      //   224: ifeq -> 238
      //   227: iload_2
      //   228: iconst_1
      //   229: isub
      //   230: istore_2
      //   231: aload #6
      //   233: astore #4
      //   235: goto -> 137
      //   238: aload #5
      //   240: areturn
    }
    
    public StaggeredGridLayoutManager.c j(View param1View) {
      return (StaggeredGridLayoutManager.c)param1View.getLayoutParams();
    }
    
    public int k(int param1Int) {
      int i = this.b;
      if (i != Integer.MIN_VALUE)
        return i; 
      if (this.a.size() == 0)
        return param1Int; 
      c();
      return this.b;
    }
    
    public void l() {
      int i = this.a.size();
      View view = this.a.remove(i - 1);
      StaggeredGridLayoutManager.c c = j(view);
      c.e = null;
      if (c.c() || c.b())
        this.d -= this.f.r.c(view); 
      if (i == 1)
        this.b = Integer.MIN_VALUE; 
      this.c = Integer.MIN_VALUE;
    }
    
    public void m() {
      View view = this.a.remove(0);
      StaggeredGridLayoutManager.c c = j(view);
      c.e = null;
      if (this.a.size() == 0)
        this.c = Integer.MIN_VALUE; 
      if (c.c() || c.b())
        this.d -= this.f.r.c(view); 
      this.b = Integer.MIN_VALUE;
    }
    
    public void n(View param1View) {
      StaggeredGridLayoutManager.c c = j(param1View);
      c.e = this;
      this.a.add(0, param1View);
      this.b = Integer.MIN_VALUE;
      if (this.a.size() == 1)
        this.c = Integer.MIN_VALUE; 
      if (c.c() || c.b()) {
        int i = this.d;
        this.d = this.f.r.c(param1View) + i;
      } 
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Luxury Logo Maker_ Logo Design-dex2jar.jar!\androidx\recyclerview\widget\StaggeredGridLayoutManager.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */