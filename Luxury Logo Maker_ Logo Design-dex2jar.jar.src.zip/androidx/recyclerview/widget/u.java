package androidx.recyclerview.widget;

import android.view.View;

public class u extends a0 {
  public s c;
  
  public s d;
  
  public int[] a(RecyclerView.m paramm, View paramView) {
    int[] arrayOfInt = new int[2];
    if (paramm.e()) {
      arrayOfInt[0] = c(paramView, e(paramm));
    } else {
      arrayOfInt[0] = 0;
    } 
    if (paramm.f()) {
      arrayOfInt[1] = c(paramView, f(paramm));
      return arrayOfInt;
    } 
    arrayOfInt[1] = 0;
    return arrayOfInt;
  }
  
  public final int c(View paramView, s params) {
    int i = params.e(paramView);
    int j = params.c(paramView) / 2;
    int k = params.k();
    return j + i - params.l() / 2 + k;
  }
  
  public final View d(RecyclerView.m paramm, s params) {
    int k = paramm.x();
    View view = null;
    if (k == 0)
      return null; 
    int n = params.k();
    int i1 = params.l() / 2;
    int j = Integer.MAX_VALUE;
    int i = 0;
    while (i < k) {
      View view1 = paramm.w(i);
      int i2 = params.e(view1);
      int i3 = Math.abs(params.c(view1) / 2 + i2 - i1 + n);
      i2 = j;
      if (i3 < j) {
        view = view1;
        i2 = i3;
      } 
      i++;
      j = i2;
    } 
    return view;
  }
  
  public final s e(RecyclerView.m paramm) {
    s s1 = this.d;
    if (s1 == null || s1.a != paramm)
      this.d = new q(paramm); 
    return this.d;
  }
  
  public final s f(RecyclerView.m paramm) {
    s s1 = this.c;
    if (s1 == null || s1.a != paramm)
      this.c = new r(paramm); 
    return this.c;
  }
}


/* Location:              C:\soft\dex2jar-2.0\Luxury Logo Maker_ Logo Design-dex2jar.jar!\androidx\recyclerview\widge\\u.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */