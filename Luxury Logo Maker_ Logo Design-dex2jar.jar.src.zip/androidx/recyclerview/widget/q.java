package androidx.recyclerview.widget;

import android.view.View;

public class q extends s {
  public q(RecyclerView.m paramm) {
    super(paramm, null);
  }
  
  public int b(View paramView) {
    RecyclerView.n n = (RecyclerView.n)paramView.getLayoutParams();
    return this.a.F(paramView) + n.rightMargin;
  }
  
  public int c(View paramView) {
    RecyclerView.n n = (RecyclerView.n)paramView.getLayoutParams();
    return this.a.E(paramView) + n.leftMargin + n.rightMargin;
  }
  
  public int d(View paramView) {
    RecyclerView.n n = (RecyclerView.n)paramView.getLayoutParams();
    return this.a.D(paramView) + n.topMargin + n.bottomMargin;
  }
  
  public int e(View paramView) {
    RecyclerView.n n = (RecyclerView.n)paramView.getLayoutParams();
    return this.a.C(paramView) - n.leftMargin;
  }
  
  public int f() {
    return this.a.n;
  }
  
  public int g() {
    RecyclerView.m m = this.a;
    return m.n - m.O();
  }
  
  public int h() {
    return this.a.O();
  }
  
  public int i() {
    return this.a.l;
  }
  
  public int j() {
    return this.a.m;
  }
  
  public int k() {
    return this.a.N();
  }
  
  public int l() {
    RecyclerView.m m = this.a;
    return m.n - m.N() - this.a.O();
  }
  
  public int n(View paramView) {
    this.a.T(paramView, true, this.c);
    return this.c.right;
  }
  
  public int o(View paramView) {
    this.a.T(paramView, true, this.c);
    return this.c.left;
  }
  
  public void p(int paramInt) {
    this.a.X(paramInt);
  }
}


/* Location:              C:\soft\dex2jar-2.0\Luxury Logo Maker_ Logo Design-dex2jar.jar!\androidx\recyclerview\widget\q.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */