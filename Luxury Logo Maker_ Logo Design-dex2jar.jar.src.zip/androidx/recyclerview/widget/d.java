package androidx.recyclerview.widget;

import android.animation.Animator;
import android.view.View;
import android.view.ViewPropertyAnimator;
import java.util.ArrayList;
import java.util.Objects;

public class d implements Runnable {
  public d(k paramk, ArrayList paramArrayList) {}
  
  public void run() {
    for (k.a a : this.h) {
      View view1;
      k k1 = this.i;
      Objects.requireNonNull(k1);
      RecyclerView.a0 a01 = a.a;
      View view2 = null;
      if (a01 == null) {
        a01 = null;
      } else {
        view1 = a01.h;
      } 
      RecyclerView.a0 a02 = a.b;
      if (a02 != null)
        view2 = a02.h; 
      if (view1 != null) {
        ViewPropertyAnimator viewPropertyAnimator = view1.animate().setDuration(k1.f);
        k1.r.add(a.a);
        viewPropertyAnimator.translationX((a.e - a.c));
        viewPropertyAnimator.translationY((a.f - a.d));
        viewPropertyAnimator.alpha(0.0F).setListener((Animator.AnimatorListener)new i(k1, a, viewPropertyAnimator, view1)).start();
      } 
      if (view2 != null) {
        ViewPropertyAnimator viewPropertyAnimator = view2.animate();
        k1.r.add(a.b);
        viewPropertyAnimator.translationX(0.0F).translationY(0.0F).setDuration(k1.f).alpha(1.0F).setListener((Animator.AnimatorListener)new j(k1, a, viewPropertyAnimator, view2)).start();
      } 
    } 
    this.h.clear();
    this.i.n.remove(this.h);
  }
}


/* Location:              C:\soft\dex2jar-2.0\Luxury Logo Maker_ Logo Design-dex2jar.jar!\androidx\recyclerview\widget\d.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */