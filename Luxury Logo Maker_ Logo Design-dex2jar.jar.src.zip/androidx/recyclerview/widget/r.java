package androidx.recyclerview.widget;

import android.view.View;

public class r extends s {
  public r(RecyclerView.m paramm) {
    super(paramm, null);
  }
  
  public int b(View paramView) {
    RecyclerView.n n = (RecyclerView.n)paramView.getLayoutParams();
    return this.a.A(paramView) + n.bottomMargin;
  }
  
  public int c(View paramView) {
    RecyclerView.n n = (RecyclerView.n)paramView.getLayoutParams();
    return this.a.D(paramView) + n.topMargin + n.bottomMargin;
  }
  
  public int d(View paramView) {
    RecyclerView.n n = (RecyclerView.n)paramView.getLayoutParams();
    return this.a.E(paramView) + n.leftMargin + n.rightMargin;
  }
  
  public int e(View paramView) {
    RecyclerView.n n = (RecyclerView.n)paramView.getLayoutParams();
    return this.a.G(paramView) - n.topMargin;
  }
  
  public int f() {
    return this.a.o;
  }
  
  public int g() {
    RecyclerView.m m = this.a;
    return m.o - m.M();
  }
  
  public int h() {
    return this.a.M();
  }
  
  public int i() {
    return this.a.m;
  }
  
  public int j() {
    return this.a.l;
  }
  
  public int k() {
    return this.a.P();
  }
  
  public int l() {
    RecyclerView.m m = this.a;
    return m.o - m.P() - this.a.M();
  }
  
  public int n(View paramView) {
    this.a.T(paramView, true, this.c);
    return this.c.bottom;
  }
  
  public int o(View paramView) {
    this.a.T(paramView, true, this.c);
    return this.c.top;
  }
  
  public void p(int paramInt) {
    this.a.Y(paramInt);
  }
}


/* Location:              C:\soft\dex2jar-2.0\Luxury Logo Maker_ Logo Design-dex2jar.jar!\androidx\recyclerview\widget\r.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */