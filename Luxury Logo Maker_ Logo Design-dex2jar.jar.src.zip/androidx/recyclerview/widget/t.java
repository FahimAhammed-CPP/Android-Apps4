package androidx.recyclerview.widget;

import android.content.Context;
import android.util.DisplayMetrics;
import android.view.View;
import android.view.animation.Interpolator;

public class t extends o {
  public t(u paramu, Context paramContext) {
    super(paramContext);
  }
  
  public void c(View paramView, RecyclerView.x paramx, RecyclerView.w.a parama) {
    u u1 = this.q;
    int[] arrayOfInt = u1.a(u1.a.getLayoutManager(), paramView);
    int i = arrayOfInt[0];
    int j = arrayOfInt[1];
    int k = (int)Math.ceil(g(Math.max(Math.abs(i), Math.abs(j))) / 0.3356D);
    if (k > 0)
      parama.b(i, j, k, (Interpolator)this.j); 
  }
  
  public float f(DisplayMetrics paramDisplayMetrics) {
    return 100.0F / paramDisplayMetrics.densityDpi;
  }
  
  public int g(int paramInt) {
    return Math.min(100, super.g(paramInt));
  }
}


/* Location:              C:\soft\dex2jar-2.0\Luxury Logo Maker_ Logo Design-dex2jar.jar!\androidx\recyclerview\widget\t.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */