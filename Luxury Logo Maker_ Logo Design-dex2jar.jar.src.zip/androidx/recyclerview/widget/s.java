package androidx.recyclerview.widget;

import android.graphics.Rect;
import android.view.View;

public abstract class s {
  public final RecyclerView.m a;
  
  public int b = Integer.MIN_VALUE;
  
  public final Rect c = new Rect();
  
  public s(RecyclerView.m paramm, q paramq) {
    this.a = paramm;
  }
  
  public static s a(RecyclerView.m paramm, int paramInt) {
    if (paramInt != 0) {
      if (paramInt == 1)
        return new r(paramm); 
      throw new IllegalArgumentException("invalid orientation");
    } 
    return new q(paramm);
  }
  
  public abstract int b(View paramView);
  
  public abstract int c(View paramView);
  
  public abstract int d(View paramView);
  
  public abstract int e(View paramView);
  
  public abstract int f();
  
  public abstract int g();
  
  public abstract int h();
  
  public abstract int i();
  
  public abstract int j();
  
  public abstract int k();
  
  public abstract int l();
  
  public int m() {
    return (Integer.MIN_VALUE == this.b) ? 0 : (l() - this.b);
  }
  
  public abstract int n(View paramView);
  
  public abstract int o(View paramView);
  
  public abstract void p(int paramInt);
}


/* Location:              C:\soft\dex2jar-2.0\Luxury Logo Maker_ Logo Design-dex2jar.jar!\androidx\recyclerview\widget\s.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */