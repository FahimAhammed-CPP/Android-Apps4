package androidx.appcompat.app;

import android.content.Context;
import android.content.DialogInterface;
import android.graphics.drawable.Drawable;
import android.os.Bundle;
import android.util.TypedValue;
import android.view.ContextThemeWrapper;
import android.view.KeyEvent;
import android.view.View;
import android.widget.ImageView;
import android.widget.ListAdapter;
import android.widget.TextView;
import androidx.core.widget.NestedScrollView;
import f.n;
import java.util.Objects;

public class b extends n {
  public final AlertController j = new AlertController(getContext(), this, getWindow());
  
  public b(Context paramContext, int paramInt) {
    super(paramContext, c(paramContext, paramInt));
  }
  
  public static int c(Context paramContext, int paramInt) {
    if ((paramInt >>> 24 & 0xFF) >= 1)
      return paramInt; 
    TypedValue typedValue = new TypedValue();
    paramContext.getTheme().resolveAttribute(2130968617, typedValue, true);
    return typedValue.resourceId;
  }
  
  public void onCreate(Bundle paramBundle) {
    // Byte code:
    //   0: aload_0
    //   1: aload_1
    //   2: invokespecial onCreate : (Landroid/os/Bundle;)V
    //   5: aload_0
    //   6: getfield j : Landroidx/appcompat/app/AlertController;
    //   9: astore #12
    //   11: aload #12
    //   13: getfield K : I
    //   16: istore_2
    //   17: aload #12
    //   19: getfield J : I
    //   22: istore_2
    //   23: aload #12
    //   25: getfield b : Lf/n;
    //   28: iload_2
    //   29: invokevirtual setContentView : (I)V
    //   32: aload #12
    //   34: getfield c : Landroid/view/Window;
    //   37: ldc 2131362238
    //   39: invokevirtual findViewById : (I)Landroid/view/View;
    //   42: astore_1
    //   43: aload_1
    //   44: ldc 2131362452
    //   46: invokevirtual findViewById : (I)Landroid/view/View;
    //   49: astore #11
    //   51: aload_1
    //   52: ldc 2131361985
    //   54: invokevirtual findViewById : (I)Landroid/view/View;
    //   57: astore #13
    //   59: aload_1
    //   60: ldc 2131361950
    //   62: invokevirtual findViewById : (I)Landroid/view/View;
    //   65: astore #14
    //   67: aload_1
    //   68: ldc 2131361994
    //   70: invokevirtual findViewById : (I)Landroid/view/View;
    //   73: checkcast android/view/ViewGroup
    //   76: astore #10
    //   78: aload #12
    //   80: getfield h : Landroid/view/View;
    //   83: astore_1
    //   84: iconst_0
    //   85: istore #7
    //   87: aload_1
    //   88: ifnull -> 94
    //   91: goto -> 127
    //   94: aload #12
    //   96: getfield i : I
    //   99: ifeq -> 125
    //   102: aload #12
    //   104: getfield a : Landroid/content/Context;
    //   107: invokestatic from : (Landroid/content/Context;)Landroid/view/LayoutInflater;
    //   110: aload #12
    //   112: getfield i : I
    //   115: aload #10
    //   117: iconst_0
    //   118: invokevirtual inflate : (ILandroid/view/ViewGroup;Z)Landroid/view/View;
    //   121: astore_1
    //   122: goto -> 127
    //   125: aconst_null
    //   126: astore_1
    //   127: aload_1
    //   128: ifnull -> 136
    //   131: iconst_1
    //   132: istore_2
    //   133: goto -> 138
    //   136: iconst_0
    //   137: istore_2
    //   138: iload_2
    //   139: ifeq -> 149
    //   142: aload_1
    //   143: invokestatic a : (Landroid/view/View;)Z
    //   146: ifne -> 161
    //   149: aload #12
    //   151: getfield c : Landroid/view/Window;
    //   154: ldc 131072
    //   156: ldc 131072
    //   158: invokevirtual setFlags : (II)V
    //   161: iload_2
    //   162: ifeq -> 251
    //   165: aload #12
    //   167: getfield c : Landroid/view/Window;
    //   170: ldc 2131361992
    //   172: invokevirtual findViewById : (I)Landroid/view/View;
    //   175: checkcast android/widget/FrameLayout
    //   178: astore #15
    //   180: aload #15
    //   182: aload_1
    //   183: new android/view/ViewGroup$LayoutParams
    //   186: dup
    //   187: iconst_m1
    //   188: iconst_m1
    //   189: invokespecial <init> : (II)V
    //   192: invokevirtual addView : (Landroid/view/View;Landroid/view/ViewGroup$LayoutParams;)V
    //   195: aload #12
    //   197: getfield n : Z
    //   200: ifeq -> 228
    //   203: aload #15
    //   205: aload #12
    //   207: getfield j : I
    //   210: aload #12
    //   212: getfield k : I
    //   215: aload #12
    //   217: getfield l : I
    //   220: aload #12
    //   222: getfield m : I
    //   225: invokevirtual setPadding : (IIII)V
    //   228: aload #12
    //   230: getfield g : Landroid/widget/ListView;
    //   233: ifnull -> 258
    //   236: aload #10
    //   238: invokevirtual getLayoutParams : ()Landroid/view/ViewGroup$LayoutParams;
    //   241: checkcast androidx/appcompat/widget/j0$a
    //   244: fconst_0
    //   245: putfield a : F
    //   248: goto -> 258
    //   251: aload #10
    //   253: bipush #8
    //   255: invokevirtual setVisibility : (I)V
    //   258: aload #10
    //   260: ldc 2131362452
    //   262: invokevirtual findViewById : (I)Landroid/view/View;
    //   265: astore #16
    //   267: aload #10
    //   269: ldc 2131361985
    //   271: invokevirtual findViewById : (I)Landroid/view/View;
    //   274: astore #15
    //   276: aload #10
    //   278: ldc 2131361950
    //   280: invokevirtual findViewById : (I)Landroid/view/View;
    //   283: astore_1
    //   284: aload #12
    //   286: aload #16
    //   288: aload #11
    //   290: invokevirtual d : (Landroid/view/View;Landroid/view/View;)Landroid/view/ViewGroup;
    //   293: astore #11
    //   295: aload #12
    //   297: aload #15
    //   299: aload #13
    //   301: invokevirtual d : (Landroid/view/View;Landroid/view/View;)Landroid/view/ViewGroup;
    //   304: astore #13
    //   306: aload #12
    //   308: aload_1
    //   309: aload #14
    //   311: invokevirtual d : (Landroid/view/View;Landroid/view/View;)Landroid/view/ViewGroup;
    //   314: astore #14
    //   316: aload #12
    //   318: getfield c : Landroid/view/Window;
    //   321: ldc 2131362303
    //   323: invokevirtual findViewById : (I)Landroid/view/View;
    //   326: checkcast androidx/core/widget/NestedScrollView
    //   329: astore_1
    //   330: aload #12
    //   332: aload_1
    //   333: putfield A : Landroidx/core/widget/NestedScrollView;
    //   336: aload_1
    //   337: iconst_0
    //   338: invokevirtual setFocusable : (Z)V
    //   341: aload #12
    //   343: getfield A : Landroidx/core/widget/NestedScrollView;
    //   346: iconst_0
    //   347: invokevirtual setNestedScrollingEnabled : (Z)V
    //   350: aload #13
    //   352: ldc 16908299
    //   354: invokevirtual findViewById : (I)Landroid/view/View;
    //   357: checkcast android/widget/TextView
    //   360: astore_1
    //   361: aload #12
    //   363: aload_1
    //   364: putfield F : Landroid/widget/TextView;
    //   367: aload_1
    //   368: ifnonnull -> 374
    //   371: goto -> 478
    //   374: aload #12
    //   376: getfield f : Ljava/lang/CharSequence;
    //   379: astore #15
    //   381: aload #15
    //   383: ifnull -> 395
    //   386: aload_1
    //   387: aload #15
    //   389: invokevirtual setText : (Ljava/lang/CharSequence;)V
    //   392: goto -> 478
    //   395: aload_1
    //   396: bipush #8
    //   398: invokevirtual setVisibility : (I)V
    //   401: aload #12
    //   403: getfield A : Landroidx/core/widget/NestedScrollView;
    //   406: aload #12
    //   408: getfield F : Landroid/widget/TextView;
    //   411: invokevirtual removeView : (Landroid/view/View;)V
    //   414: aload #12
    //   416: getfield g : Landroid/widget/ListView;
    //   419: ifnull -> 471
    //   422: aload #12
    //   424: getfield A : Landroidx/core/widget/NestedScrollView;
    //   427: invokevirtual getParent : ()Landroid/view/ViewParent;
    //   430: checkcast android/view/ViewGroup
    //   433: astore_1
    //   434: aload_1
    //   435: aload #12
    //   437: getfield A : Landroidx/core/widget/NestedScrollView;
    //   440: invokevirtual indexOfChild : (Landroid/view/View;)I
    //   443: istore_2
    //   444: aload_1
    //   445: iload_2
    //   446: invokevirtual removeViewAt : (I)V
    //   449: aload_1
    //   450: aload #12
    //   452: getfield g : Landroid/widget/ListView;
    //   455: iload_2
    //   456: new android/view/ViewGroup$LayoutParams
    //   459: dup
    //   460: iconst_m1
    //   461: iconst_m1
    //   462: invokespecial <init> : (II)V
    //   465: invokevirtual addView : (Landroid/view/View;ILandroid/view/ViewGroup$LayoutParams;)V
    //   468: goto -> 478
    //   471: aload #13
    //   473: bipush #8
    //   475: invokevirtual setVisibility : (I)V
    //   478: aload #14
    //   480: ldc 16908313
    //   482: invokevirtual findViewById : (I)Landroid/view/View;
    //   485: checkcast android/widget/Button
    //   488: astore_1
    //   489: aload #12
    //   491: aload_1
    //   492: putfield o : Landroid/widget/Button;
    //   495: aload_1
    //   496: aload #12
    //   498: getfield R : Landroid/view/View$OnClickListener;
    //   501: invokevirtual setOnClickListener : (Landroid/view/View$OnClickListener;)V
    //   504: aload #12
    //   506: getfield p : Ljava/lang/CharSequence;
    //   509: invokestatic isEmpty : (Ljava/lang/CharSequence;)Z
    //   512: ifeq -> 538
    //   515: aload #12
    //   517: getfield r : Landroid/graphics/drawable/Drawable;
    //   520: ifnonnull -> 538
    //   523: aload #12
    //   525: getfield o : Landroid/widget/Button;
    //   528: bipush #8
    //   530: invokevirtual setVisibility : (I)V
    //   533: iconst_0
    //   534: istore_2
    //   535: goto -> 602
    //   538: aload #12
    //   540: getfield o : Landroid/widget/Button;
    //   543: aload #12
    //   545: getfield p : Ljava/lang/CharSequence;
    //   548: invokevirtual setText : (Ljava/lang/CharSequence;)V
    //   551: aload #12
    //   553: getfield r : Landroid/graphics/drawable/Drawable;
    //   556: astore_1
    //   557: aload_1
    //   558: ifnull -> 591
    //   561: aload #12
    //   563: getfield d : I
    //   566: istore_2
    //   567: aload_1
    //   568: iconst_0
    //   569: iconst_0
    //   570: iload_2
    //   571: iload_2
    //   572: invokevirtual setBounds : (IIII)V
    //   575: aload #12
    //   577: getfield o : Landroid/widget/Button;
    //   580: aload #12
    //   582: getfield r : Landroid/graphics/drawable/Drawable;
    //   585: aconst_null
    //   586: aconst_null
    //   587: aconst_null
    //   588: invokevirtual setCompoundDrawables : (Landroid/graphics/drawable/Drawable;Landroid/graphics/drawable/Drawable;Landroid/graphics/drawable/Drawable;Landroid/graphics/drawable/Drawable;)V
    //   591: aload #12
    //   593: getfield o : Landroid/widget/Button;
    //   596: iconst_0
    //   597: invokevirtual setVisibility : (I)V
    //   600: iconst_1
    //   601: istore_2
    //   602: aload #14
    //   604: ldc_w 16908314
    //   607: invokevirtual findViewById : (I)Landroid/view/View;
    //   610: checkcast android/widget/Button
    //   613: astore_1
    //   614: aload #12
    //   616: aload_1
    //   617: putfield s : Landroid/widget/Button;
    //   620: aload_1
    //   621: aload #12
    //   623: getfield R : Landroid/view/View$OnClickListener;
    //   626: invokevirtual setOnClickListener : (Landroid/view/View$OnClickListener;)V
    //   629: aload #12
    //   631: getfield t : Ljava/lang/CharSequence;
    //   634: invokestatic isEmpty : (Ljava/lang/CharSequence;)Z
    //   637: ifeq -> 661
    //   640: aload #12
    //   642: getfield v : Landroid/graphics/drawable/Drawable;
    //   645: ifnonnull -> 661
    //   648: aload #12
    //   650: getfield s : Landroid/widget/Button;
    //   653: bipush #8
    //   655: invokevirtual setVisibility : (I)V
    //   658: goto -> 727
    //   661: aload #12
    //   663: getfield s : Landroid/widget/Button;
    //   666: aload #12
    //   668: getfield t : Ljava/lang/CharSequence;
    //   671: invokevirtual setText : (Ljava/lang/CharSequence;)V
    //   674: aload #12
    //   676: getfield v : Landroid/graphics/drawable/Drawable;
    //   679: astore_1
    //   680: aload_1
    //   681: ifnull -> 714
    //   684: aload #12
    //   686: getfield d : I
    //   689: istore_3
    //   690: aload_1
    //   691: iconst_0
    //   692: iconst_0
    //   693: iload_3
    //   694: iload_3
    //   695: invokevirtual setBounds : (IIII)V
    //   698: aload #12
    //   700: getfield s : Landroid/widget/Button;
    //   703: aload #12
    //   705: getfield v : Landroid/graphics/drawable/Drawable;
    //   708: aconst_null
    //   709: aconst_null
    //   710: aconst_null
    //   711: invokevirtual setCompoundDrawables : (Landroid/graphics/drawable/Drawable;Landroid/graphics/drawable/Drawable;Landroid/graphics/drawable/Drawable;Landroid/graphics/drawable/Drawable;)V
    //   714: aload #12
    //   716: getfield s : Landroid/widget/Button;
    //   719: iconst_0
    //   720: invokevirtual setVisibility : (I)V
    //   723: iload_2
    //   724: iconst_2
    //   725: ior
    //   726: istore_2
    //   727: aload #14
    //   729: ldc_w 16908315
    //   732: invokevirtual findViewById : (I)Landroid/view/View;
    //   735: checkcast android/widget/Button
    //   738: astore_1
    //   739: aload #12
    //   741: aload_1
    //   742: putfield w : Landroid/widget/Button;
    //   745: aload_1
    //   746: aload #12
    //   748: getfield R : Landroid/view/View$OnClickListener;
    //   751: invokevirtual setOnClickListener : (Landroid/view/View$OnClickListener;)V
    //   754: aload #12
    //   756: getfield x : Ljava/lang/CharSequence;
    //   759: invokestatic isEmpty : (Ljava/lang/CharSequence;)Z
    //   762: ifeq -> 786
    //   765: aload #12
    //   767: getfield z : Landroid/graphics/drawable/Drawable;
    //   770: ifnonnull -> 786
    //   773: aload #12
    //   775: getfield w : Landroid/widget/Button;
    //   778: bipush #8
    //   780: invokevirtual setVisibility : (I)V
    //   783: goto -> 855
    //   786: aload #12
    //   788: getfield w : Landroid/widget/Button;
    //   791: aload #12
    //   793: getfield x : Ljava/lang/CharSequence;
    //   796: invokevirtual setText : (Ljava/lang/CharSequence;)V
    //   799: aload #12
    //   801: getfield z : Landroid/graphics/drawable/Drawable;
    //   804: astore_1
    //   805: aload_1
    //   806: ifnull -> 842
    //   809: aload #12
    //   811: getfield d : I
    //   814: istore_3
    //   815: aload_1
    //   816: iconst_0
    //   817: iconst_0
    //   818: iload_3
    //   819: iload_3
    //   820: invokevirtual setBounds : (IIII)V
    //   823: aload #12
    //   825: getfield w : Landroid/widget/Button;
    //   828: aload #12
    //   830: getfield z : Landroid/graphics/drawable/Drawable;
    //   833: aconst_null
    //   834: aconst_null
    //   835: aconst_null
    //   836: invokevirtual setCompoundDrawables : (Landroid/graphics/drawable/Drawable;Landroid/graphics/drawable/Drawable;Landroid/graphics/drawable/Drawable;Landroid/graphics/drawable/Drawable;)V
    //   839: goto -> 842
    //   842: aload #12
    //   844: getfield w : Landroid/widget/Button;
    //   847: iconst_0
    //   848: invokevirtual setVisibility : (I)V
    //   851: iload_2
    //   852: iconst_4
    //   853: ior
    //   854: istore_2
    //   855: aload #12
    //   857: getfield a : Landroid/content/Context;
    //   860: astore_1
    //   861: new android/util/TypedValue
    //   864: dup
    //   865: invokespecial <init> : ()V
    //   868: astore #15
    //   870: aload_1
    //   871: invokevirtual getTheme : ()Landroid/content/res/Resources$Theme;
    //   874: ldc_w 2130968615
    //   877: aload #15
    //   879: iconst_1
    //   880: invokevirtual resolveAttribute : (ILandroid/util/TypedValue;Z)Z
    //   883: pop
    //   884: aload #15
    //   886: getfield data : I
    //   889: ifeq -> 897
    //   892: iconst_1
    //   893: istore_3
    //   894: goto -> 899
    //   897: iconst_0
    //   898: istore_3
    //   899: iload_3
    //   900: ifeq -> 948
    //   903: iload_2
    //   904: iconst_1
    //   905: if_icmpne -> 917
    //   908: aload #12
    //   910: getfield o : Landroid/widget/Button;
    //   913: astore_1
    //   914: goto -> 942
    //   917: iload_2
    //   918: iconst_2
    //   919: if_icmpne -> 931
    //   922: aload #12
    //   924: getfield s : Landroid/widget/Button;
    //   927: astore_1
    //   928: goto -> 942
    //   931: iload_2
    //   932: iconst_4
    //   933: if_icmpne -> 948
    //   936: aload #12
    //   938: getfield w : Landroid/widget/Button;
    //   941: astore_1
    //   942: aload #12
    //   944: aload_1
    //   945: invokevirtual b : (Landroid/widget/Button;)V
    //   948: iload_2
    //   949: ifeq -> 957
    //   952: iconst_1
    //   953: istore_2
    //   954: goto -> 959
    //   957: iconst_0
    //   958: istore_2
    //   959: iload_2
    //   960: ifne -> 970
    //   963: aload #14
    //   965: bipush #8
    //   967: invokevirtual setVisibility : (I)V
    //   970: aload #12
    //   972: getfield G : Landroid/view/View;
    //   975: ifnull -> 1020
    //   978: new android/view/ViewGroup$LayoutParams
    //   981: dup
    //   982: iconst_m1
    //   983: bipush #-2
    //   985: invokespecial <init> : (II)V
    //   988: astore_1
    //   989: aload #11
    //   991: aload #12
    //   993: getfield G : Landroid/view/View;
    //   996: iconst_0
    //   997: aload_1
    //   998: invokevirtual addView : (Landroid/view/View;ILandroid/view/ViewGroup$LayoutParams;)V
    //   1001: aload #12
    //   1003: getfield c : Landroid/view/Window;
    //   1006: ldc_w 2131362444
    //   1009: invokevirtual findViewById : (I)Landroid/view/View;
    //   1012: bipush #8
    //   1014: invokevirtual setVisibility : (I)V
    //   1017: goto -> 1220
    //   1020: aload #12
    //   1022: aload #12
    //   1024: getfield c : Landroid/view/Window;
    //   1027: ldc_w 16908294
    //   1030: invokevirtual findViewById : (I)Landroid/view/View;
    //   1033: checkcast android/widget/ImageView
    //   1036: putfield D : Landroid/widget/ImageView;
    //   1039: aload #12
    //   1041: getfield e : Ljava/lang/CharSequence;
    //   1044: invokestatic isEmpty : (Ljava/lang/CharSequence;)Z
    //   1047: iconst_1
    //   1048: ixor
    //   1049: ifeq -> 1187
    //   1052: aload #12
    //   1054: getfield P : Z
    //   1057: ifeq -> 1187
    //   1060: aload #12
    //   1062: getfield c : Landroid/view/Window;
    //   1065: ldc_w 2131361885
    //   1068: invokevirtual findViewById : (I)Landroid/view/View;
    //   1071: checkcast android/widget/TextView
    //   1074: astore_1
    //   1075: aload #12
    //   1077: aload_1
    //   1078: putfield E : Landroid/widget/TextView;
    //   1081: aload_1
    //   1082: aload #12
    //   1084: getfield e : Ljava/lang/CharSequence;
    //   1087: invokevirtual setText : (Ljava/lang/CharSequence;)V
    //   1090: aload #12
    //   1092: getfield B : I
    //   1095: istore_2
    //   1096: iload_2
    //   1097: ifeq -> 1112
    //   1100: aload #12
    //   1102: getfield D : Landroid/widget/ImageView;
    //   1105: iload_2
    //   1106: invokevirtual setImageResource : (I)V
    //   1109: goto -> 1220
    //   1112: aload #12
    //   1114: getfield C : Landroid/graphics/drawable/Drawable;
    //   1117: astore_1
    //   1118: aload_1
    //   1119: ifnull -> 1134
    //   1122: aload #12
    //   1124: getfield D : Landroid/widget/ImageView;
    //   1127: aload_1
    //   1128: invokevirtual setImageDrawable : (Landroid/graphics/drawable/Drawable;)V
    //   1131: goto -> 1220
    //   1134: aload #12
    //   1136: getfield E : Landroid/widget/TextView;
    //   1139: aload #12
    //   1141: getfield D : Landroid/widget/ImageView;
    //   1144: invokevirtual getPaddingLeft : ()I
    //   1147: aload #12
    //   1149: getfield D : Landroid/widget/ImageView;
    //   1152: invokevirtual getPaddingTop : ()I
    //   1155: aload #12
    //   1157: getfield D : Landroid/widget/ImageView;
    //   1160: invokevirtual getPaddingRight : ()I
    //   1163: aload #12
    //   1165: getfield D : Landroid/widget/ImageView;
    //   1168: invokevirtual getPaddingBottom : ()I
    //   1171: invokevirtual setPadding : (IIII)V
    //   1174: aload #12
    //   1176: getfield D : Landroid/widget/ImageView;
    //   1179: bipush #8
    //   1181: invokevirtual setVisibility : (I)V
    //   1184: goto -> 1220
    //   1187: aload #12
    //   1189: getfield c : Landroid/view/Window;
    //   1192: ldc_w 2131362444
    //   1195: invokevirtual findViewById : (I)Landroid/view/View;
    //   1198: bipush #8
    //   1200: invokevirtual setVisibility : (I)V
    //   1203: aload #12
    //   1205: getfield D : Landroid/widget/ImageView;
    //   1208: bipush #8
    //   1210: invokevirtual setVisibility : (I)V
    //   1213: aload #11
    //   1215: bipush #8
    //   1217: invokevirtual setVisibility : (I)V
    //   1220: aload #10
    //   1222: invokevirtual getVisibility : ()I
    //   1225: bipush #8
    //   1227: if_icmpeq -> 1235
    //   1230: iconst_1
    //   1231: istore_2
    //   1232: goto -> 1237
    //   1235: iconst_0
    //   1236: istore_2
    //   1237: aload #11
    //   1239: ifnull -> 1257
    //   1242: aload #11
    //   1244: invokevirtual getVisibility : ()I
    //   1247: bipush #8
    //   1249: if_icmpeq -> 1257
    //   1252: iconst_1
    //   1253: istore_3
    //   1254: goto -> 1259
    //   1257: iconst_0
    //   1258: istore_3
    //   1259: aload #14
    //   1261: invokevirtual getVisibility : ()I
    //   1264: bipush #8
    //   1266: if_icmpeq -> 1275
    //   1269: iconst_1
    //   1270: istore #4
    //   1272: goto -> 1278
    //   1275: iconst_0
    //   1276: istore #4
    //   1278: iload #4
    //   1280: ifne -> 1301
    //   1283: aload #13
    //   1285: ldc_w 2131362426
    //   1288: invokevirtual findViewById : (I)Landroid/view/View;
    //   1291: astore_1
    //   1292: aload_1
    //   1293: ifnull -> 1301
    //   1296: aload_1
    //   1297: iconst_0
    //   1298: invokevirtual setVisibility : (I)V
    //   1301: iload_3
    //   1302: ifeq -> 1360
    //   1305: aload #12
    //   1307: getfield A : Landroidx/core/widget/NestedScrollView;
    //   1310: astore_1
    //   1311: aload_1
    //   1312: ifnull -> 1320
    //   1315: aload_1
    //   1316: iconst_1
    //   1317: invokevirtual setClipToPadding : (Z)V
    //   1320: aload #12
    //   1322: getfield f : Ljava/lang/CharSequence;
    //   1325: ifnonnull -> 1344
    //   1328: aload #12
    //   1330: getfield g : Landroid/widget/ListView;
    //   1333: ifnull -> 1339
    //   1336: goto -> 1344
    //   1339: aconst_null
    //   1340: astore_1
    //   1341: goto -> 1353
    //   1344: aload #11
    //   1346: ldc_w 2131362443
    //   1349: invokevirtual findViewById : (I)Landroid/view/View;
    //   1352: astore_1
    //   1353: aload_1
    //   1354: ifnull -> 1378
    //   1357: goto -> 1373
    //   1360: aload #13
    //   1362: ldc_w 2131362427
    //   1365: invokevirtual findViewById : (I)Landroid/view/View;
    //   1368: astore_1
    //   1369: aload_1
    //   1370: ifnull -> 1378
    //   1373: aload_1
    //   1374: iconst_0
    //   1375: invokevirtual setVisibility : (I)V
    //   1378: aload #12
    //   1380: getfield g : Landroid/widget/ListView;
    //   1383: astore_1
    //   1384: aload_1
    //   1385: instanceof androidx/appcompat/app/AlertController$RecycleListView
    //   1388: ifeq -> 1473
    //   1391: aload_1
    //   1392: checkcast androidx/appcompat/app/AlertController$RecycleListView
    //   1395: astore_1
    //   1396: aload_1
    //   1397: invokestatic requireNonNull : (Ljava/lang/Object;)Ljava/lang/Object;
    //   1400: pop
    //   1401: iload #4
    //   1403: ifeq -> 1410
    //   1406: iload_3
    //   1407: ifne -> 1473
    //   1410: aload_1
    //   1411: invokevirtual getPaddingLeft : ()I
    //   1414: istore #8
    //   1416: iload_3
    //   1417: ifeq -> 1429
    //   1420: aload_1
    //   1421: invokevirtual getPaddingTop : ()I
    //   1424: istore #5
    //   1426: goto -> 1435
    //   1429: aload_1
    //   1430: getfield h : I
    //   1433: istore #5
    //   1435: aload_1
    //   1436: invokevirtual getPaddingRight : ()I
    //   1439: istore #9
    //   1441: iload #4
    //   1443: ifeq -> 1455
    //   1446: aload_1
    //   1447: invokevirtual getPaddingBottom : ()I
    //   1450: istore #6
    //   1452: goto -> 1461
    //   1455: aload_1
    //   1456: getfield i : I
    //   1459: istore #6
    //   1461: aload_1
    //   1462: iload #8
    //   1464: iload #5
    //   1466: iload #9
    //   1468: iload #6
    //   1470: invokevirtual setPadding : (IIII)V
    //   1473: iload_2
    //   1474: ifne -> 1776
    //   1477: aload #12
    //   1479: getfield g : Landroid/widget/ListView;
    //   1482: astore #10
    //   1484: aload #10
    //   1486: ifnull -> 1492
    //   1489: goto -> 1499
    //   1492: aload #12
    //   1494: getfield A : Landroidx/core/widget/NestedScrollView;
    //   1497: astore #10
    //   1499: aload #10
    //   1501: ifnull -> 1776
    //   1504: iload #7
    //   1506: istore_2
    //   1507: iload #4
    //   1509: ifeq -> 1514
    //   1512: iconst_2
    //   1513: istore_2
    //   1514: iload_3
    //   1515: iload_2
    //   1516: ior
    //   1517: istore_2
    //   1518: aload #12
    //   1520: getfield c : Landroid/view/Window;
    //   1523: ldc_w 2131362302
    //   1526: invokevirtual findViewById : (I)Landroid/view/View;
    //   1529: astore #11
    //   1531: aload #12
    //   1533: getfield c : Landroid/view/Window;
    //   1536: ldc_w 2131362301
    //   1539: invokevirtual findViewById : (I)Landroid/view/View;
    //   1542: astore_1
    //   1543: getstatic android/os/Build$VERSION.SDK_INT : I
    //   1546: istore_3
    //   1547: iload_3
    //   1548: bipush #23
    //   1550: if_icmplt -> 1590
    //   1553: getstatic k0/l.a : Ljava/util/WeakHashMap;
    //   1556: astore #14
    //   1558: iload_3
    //   1559: bipush #23
    //   1561: if_icmplt -> 1571
    //   1564: aload #10
    //   1566: iload_2
    //   1567: iconst_3
    //   1568: invokevirtual setScrollIndicators : (II)V
    //   1571: aload #11
    //   1573: ifnull -> 1583
    //   1576: aload #13
    //   1578: aload #11
    //   1580: invokevirtual removeView : (Landroid/view/View;)V
    //   1583: aload_1
    //   1584: ifnull -> 1776
    //   1587: goto -> 1770
    //   1590: aload #11
    //   1592: astore #10
    //   1594: aload #11
    //   1596: ifnull -> 1619
    //   1599: aload #11
    //   1601: astore #10
    //   1603: iload_2
    //   1604: iconst_1
    //   1605: iand
    //   1606: ifne -> 1619
    //   1609: aload #13
    //   1611: aload #11
    //   1613: invokevirtual removeView : (Landroid/view/View;)V
    //   1616: aconst_null
    //   1617: astore #10
    //   1619: aload_1
    //   1620: ifnull -> 1640
    //   1623: iload_2
    //   1624: iconst_2
    //   1625: iand
    //   1626: ifne -> 1640
    //   1629: aload #13
    //   1631: aload_1
    //   1632: invokevirtual removeView : (Landroid/view/View;)V
    //   1635: aconst_null
    //   1636: astore_1
    //   1637: goto -> 1640
    //   1640: aload #10
    //   1642: ifnonnull -> 1649
    //   1645: aload_1
    //   1646: ifnull -> 1776
    //   1649: aload #12
    //   1651: getfield f : Ljava/lang/CharSequence;
    //   1654: ifnull -> 1701
    //   1657: aload #12
    //   1659: getfield A : Landroidx/core/widget/NestedScrollView;
    //   1662: new f/b
    //   1665: dup
    //   1666: aload #12
    //   1668: aload #10
    //   1670: aload_1
    //   1671: invokespecial <init> : (Landroidx/appcompat/app/AlertController;Landroid/view/View;Landroid/view/View;)V
    //   1674: invokevirtual setOnScrollChangeListener : (Landroidx/core/widget/NestedScrollView$b;)V
    //   1677: aload #12
    //   1679: getfield A : Landroidx/core/widget/NestedScrollView;
    //   1682: new f/c
    //   1685: dup
    //   1686: aload #12
    //   1688: aload #10
    //   1690: aload_1
    //   1691: invokespecial <init> : (Landroidx/appcompat/app/AlertController;Landroid/view/View;Landroid/view/View;)V
    //   1694: invokevirtual post : (Ljava/lang/Runnable;)Z
    //   1697: pop
    //   1698: goto -> 1776
    //   1701: aload #12
    //   1703: getfield g : Landroid/widget/ListView;
    //   1706: astore #11
    //   1708: aload #11
    //   1710: ifnull -> 1754
    //   1713: aload #11
    //   1715: new f/d
    //   1718: dup
    //   1719: aload #12
    //   1721: aload #10
    //   1723: aload_1
    //   1724: invokespecial <init> : (Landroidx/appcompat/app/AlertController;Landroid/view/View;Landroid/view/View;)V
    //   1727: invokevirtual setOnScrollListener : (Landroid/widget/AbsListView$OnScrollListener;)V
    //   1730: aload #12
    //   1732: getfield g : Landroid/widget/ListView;
    //   1735: new f/e
    //   1738: dup
    //   1739: aload #12
    //   1741: aload #10
    //   1743: aload_1
    //   1744: invokespecial <init> : (Landroidx/appcompat/app/AlertController;Landroid/view/View;Landroid/view/View;)V
    //   1747: invokevirtual post : (Ljava/lang/Runnable;)Z
    //   1750: pop
    //   1751: goto -> 1776
    //   1754: aload #10
    //   1756: ifnull -> 1766
    //   1759: aload #13
    //   1761: aload #10
    //   1763: invokevirtual removeView : (Landroid/view/View;)V
    //   1766: aload_1
    //   1767: ifnull -> 1776
    //   1770: aload #13
    //   1772: aload_1
    //   1773: invokevirtual removeView : (Landroid/view/View;)V
    //   1776: aload #12
    //   1778: getfield g : Landroid/widget/ListView;
    //   1781: astore_1
    //   1782: aload_1
    //   1783: ifnull -> 1826
    //   1786: aload #12
    //   1788: getfield H : Landroid/widget/ListAdapter;
    //   1791: astore #10
    //   1793: aload #10
    //   1795: ifnull -> 1826
    //   1798: aload_1
    //   1799: aload #10
    //   1801: invokevirtual setAdapter : (Landroid/widget/ListAdapter;)V
    //   1804: aload #12
    //   1806: getfield I : I
    //   1809: istore_2
    //   1810: iload_2
    //   1811: iconst_m1
    //   1812: if_icmple -> 1826
    //   1815: aload_1
    //   1816: iload_2
    //   1817: iconst_1
    //   1818: invokevirtual setItemChecked : (IZ)V
    //   1821: aload_1
    //   1822: iload_2
    //   1823: invokevirtual setSelection : (I)V
    //   1826: return
  }
  
  public boolean onKeyDown(int paramInt, KeyEvent paramKeyEvent) {
    boolean bool;
    NestedScrollView nestedScrollView = this.j.A;
    if (nestedScrollView != null && nestedScrollView.l(paramKeyEvent)) {
      bool = true;
    } else {
      bool = false;
    } 
    return bool ? true : super.onKeyDown(paramInt, paramKeyEvent);
  }
  
  public boolean onKeyUp(int paramInt, KeyEvent paramKeyEvent) {
    boolean bool;
    NestedScrollView nestedScrollView = this.j.A;
    if (nestedScrollView != null && nestedScrollView.l(paramKeyEvent)) {
      bool = true;
    } else {
      bool = false;
    } 
    return bool ? true : super.onKeyUp(paramInt, paramKeyEvent);
  }
  
  public void setTitle(CharSequence paramCharSequence) {
    super.setTitle(paramCharSequence);
    AlertController alertController = this.j;
    alertController.e = paramCharSequence;
    TextView textView = alertController.E;
    if (textView != null)
      textView.setText(paramCharSequence); 
  }
  
  public static class a {
    public final AlertController.b a;
    
    public final int b;
    
    public a(Context param1Context) {
      this.a = new AlertController.b((Context)new ContextThemeWrapper(param1Context, b.c(param1Context, i)));
      this.b = i;
    }
    
    public b a() {
      b b1 = new b(this.a.a, this.b);
      AlertController.b b2 = this.a;
      AlertController alertController = b1.j;
      View view = b2.e;
      if (view != null) {
        alertController.G = view;
      } else {
        CharSequence charSequence = b2.d;
        if (charSequence != null) {
          alertController.e = charSequence;
          TextView textView = alertController.E;
          if (textView != null)
            textView.setText(charSequence); 
        } 
        Drawable drawable = b2.c;
        if (drawable != null) {
          alertController.C = drawable;
          alertController.B = 0;
          ImageView imageView = alertController.D;
          if (imageView != null) {
            imageView.setVisibility(0);
            alertController.D.setImageDrawable(drawable);
          } 
        } 
      } 
      if (b2.g != null) {
        int i;
        AlertController.d d;
        AlertController.RecycleListView recycleListView = (AlertController.RecycleListView)b2.b.inflate(alertController.L, null);
        if (b2.i) {
          i = alertController.N;
        } else {
          i = alertController.O;
        } 
        ListAdapter listAdapter = b2.g;
        if (listAdapter == null)
          d = new AlertController.d(b2.a, i, 16908308, null); 
        alertController.H = (ListAdapter)d;
        alertController.I = b2.j;
        if (b2.h != null)
          recycleListView.setOnItemClickListener(new a(b2, alertController)); 
        if (b2.i)
          recycleListView.setChoiceMode(1); 
        alertController.g = recycleListView;
      } 
      Objects.requireNonNull(this.a);
      b1.setCancelable(true);
      Objects.requireNonNull(this.a);
      b1.setCanceledOnTouchOutside(true);
      Objects.requireNonNull(this.a);
      b1.setOnCancelListener(null);
      Objects.requireNonNull(this.a);
      b1.setOnDismissListener(null);
      DialogInterface.OnKeyListener onKeyListener = this.a.f;
      if (onKeyListener != null)
        b1.setOnKeyListener(onKeyListener); 
      return b1;
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Luxury Logo Maker_ Logo Design-dex2jar.jar!\androidx\appcompat\app\b.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */