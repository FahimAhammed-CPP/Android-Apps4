package androidx.appcompat.view.menu;

import android.content.Context;
import android.content.res.Configuration;
import android.content.res.Resources;
import android.content.res.TypedArray;
import android.graphics.drawable.Drawable;
import android.os.Parcelable;
import android.text.TextUtils;
import android.util.AttributeSet;
import android.view.MotionEvent;
import android.view.View;
import androidx.appcompat.widget.ActionMenuView;
import androidx.appcompat.widget.a0;
import androidx.appcompat.widget.c;
import androidx.appcompat.widget.i0;
import k.d;
import k.f;

public class ActionMenuItemView extends a0 implements j.a, View.OnClickListener, ActionMenuView.a {
  public g l;
  
  public CharSequence m;
  
  public Drawable n;
  
  public e.b o;
  
  public i0 p;
  
  public b q;
  
  public boolean r;
  
  public boolean s;
  
  public int t;
  
  public int u;
  
  public int v;
  
  public ActionMenuItemView(Context paramContext, AttributeSet paramAttributeSet) {
    super(paramContext, paramAttributeSet, 0);
    Resources resources = paramContext.getResources();
    this.r = h();
    TypedArray typedArray = paramContext.obtainStyledAttributes(paramAttributeSet, com.bumptech.glide.manager.b.j, 0, 0);
    this.t = typedArray.getDimensionPixelSize(0, 0);
    typedArray.recycle();
    this.v = (int)((resources.getDisplayMetrics()).density * 32.0F + 0.5F);
    setOnClickListener(this);
    this.u = -1;
    setSaveEnabled(false);
  }
  
  public boolean a() {
    return c();
  }
  
  public boolean b() {
    return (c() && this.l.getIcon() == null);
  }
  
  public boolean c() {
    return TextUtils.isEmpty(getText()) ^ true;
  }
  
  public void f(g paramg, int paramInt) {
    this.l = paramg;
    setIcon(paramg.getIcon());
    setTitle(paramg.getTitleCondensed());
    setId(paramg.a);
    if (paramg.isVisible()) {
      paramInt = 0;
    } else {
      paramInt = 8;
    } 
    setVisibility(paramInt);
    setEnabled(paramg.isEnabled());
    if (paramg.hasSubMenu() && this.p == null)
      this.p = new a(this); 
  }
  
  public g getItemData() {
    return this.l;
  }
  
  public final boolean h() {
    Configuration configuration = getContext().getResources().getConfiguration();
    int i = configuration.screenWidthDp;
    int j = configuration.screenHeightDp;
    return (i >= 480 || (i >= 640 && j >= 480) || configuration.orientation == 2);
  }
  
  public void onClick(View paramView) {
    e.b b1 = this.o;
    if (b1 != null)
      b1.a(this.l); 
  }
  
  public void onConfigurationChanged(Configuration paramConfiguration) {
    super.onConfigurationChanged(paramConfiguration);
    this.r = h();
    p();
  }
  
  public void onMeasure(int paramInt1, int paramInt2) {
    boolean bool = c();
    if (bool) {
      int k = this.u;
      if (k >= 0)
        super.setPadding(k, getPaddingTop(), getPaddingRight(), getPaddingBottom()); 
    } 
    super.onMeasure(paramInt1, paramInt2);
    int i = View.MeasureSpec.getMode(paramInt1);
    paramInt1 = View.MeasureSpec.getSize(paramInt1);
    int j = getMeasuredWidth();
    if (i == Integer.MIN_VALUE) {
      paramInt1 = Math.min(paramInt1, this.t);
    } else {
      paramInt1 = this.t;
    } 
    if (i != 1073741824 && this.t > 0 && j < paramInt1)
      super.onMeasure(View.MeasureSpec.makeMeasureSpec(paramInt1, 1073741824), paramInt2); 
    if (!bool && this.n != null)
      super.setPadding((getMeasuredWidth() - this.n.getBounds().width()) / 2, getPaddingTop(), getPaddingRight(), getPaddingBottom()); 
  }
  
  public void onRestoreInstanceState(Parcelable paramParcelable) {
    super.onRestoreInstanceState(null);
  }
  
  public boolean onTouchEvent(MotionEvent paramMotionEvent) {
    if (this.l.hasSubMenu()) {
      i0 i01 = this.p;
      if (i01 != null && i01.onTouch((View)this, paramMotionEvent))
        return true; 
    } 
    return super.onTouchEvent(paramMotionEvent);
  }
  
  public final void p() {
    // Byte code:
    //   0: aload_0
    //   1: getfield m : Ljava/lang/CharSequence;
    //   4: invokestatic isEmpty : (Ljava/lang/CharSequence;)Z
    //   7: istore_3
    //   8: iconst_1
    //   9: istore_2
    //   10: iload_2
    //   11: istore_1
    //   12: aload_0
    //   13: getfield n : Landroid/graphics/drawable/Drawable;
    //   16: ifnull -> 66
    //   19: aload_0
    //   20: getfield l : Landroidx/appcompat/view/menu/g;
    //   23: getfield y : I
    //   26: iconst_4
    //   27: iand
    //   28: iconst_4
    //   29: if_icmpne -> 37
    //   32: iconst_1
    //   33: istore_1
    //   34: goto -> 39
    //   37: iconst_0
    //   38: istore_1
    //   39: iload_1
    //   40: ifeq -> 64
    //   43: iload_2
    //   44: istore_1
    //   45: aload_0
    //   46: getfield r : Z
    //   49: ifne -> 66
    //   52: aload_0
    //   53: getfield s : Z
    //   56: ifeq -> 64
    //   59: iload_2
    //   60: istore_1
    //   61: goto -> 66
    //   64: iconst_0
    //   65: istore_1
    //   66: iload_3
    //   67: iconst_1
    //   68: ixor
    //   69: iload_1
    //   70: iand
    //   71: istore_1
    //   72: aconst_null
    //   73: astore #5
    //   75: iload_1
    //   76: ifeq -> 88
    //   79: aload_0
    //   80: getfield m : Ljava/lang/CharSequence;
    //   83: astore #4
    //   85: goto -> 91
    //   88: aconst_null
    //   89: astore #4
    //   91: aload_0
    //   92: aload #4
    //   94: invokevirtual setText : (Ljava/lang/CharSequence;)V
    //   97: aload_0
    //   98: getfield l : Landroidx/appcompat/view/menu/g;
    //   101: getfield q : Ljava/lang/CharSequence;
    //   104: astore #6
    //   106: aload #6
    //   108: astore #4
    //   110: aload #6
    //   112: invokestatic isEmpty : (Ljava/lang/CharSequence;)Z
    //   115: ifeq -> 137
    //   118: iload_1
    //   119: ifeq -> 128
    //   122: aconst_null
    //   123: astore #4
    //   125: goto -> 137
    //   128: aload_0
    //   129: getfield l : Landroidx/appcompat/view/menu/g;
    //   132: getfield e : Ljava/lang/CharSequence;
    //   135: astore #4
    //   137: aload_0
    //   138: aload #4
    //   140: invokevirtual setContentDescription : (Ljava/lang/CharSequence;)V
    //   143: aload_0
    //   144: getfield l : Landroidx/appcompat/view/menu/g;
    //   147: getfield r : Ljava/lang/CharSequence;
    //   150: astore #4
    //   152: aload #4
    //   154: invokestatic isEmpty : (Ljava/lang/CharSequence;)Z
    //   157: ifeq -> 187
    //   160: iload_1
    //   161: ifeq -> 171
    //   164: aload #5
    //   166: astore #4
    //   168: goto -> 180
    //   171: aload_0
    //   172: getfield l : Landroidx/appcompat/view/menu/g;
    //   175: getfield e : Ljava/lang/CharSequence;
    //   178: astore #4
    //   180: aload_0
    //   181: aload #4
    //   183: invokestatic a : (Landroid/view/View;Ljava/lang/CharSequence;)V
    //   186: return
    //   187: aload_0
    //   188: aload #4
    //   190: invokestatic a : (Landroid/view/View;Ljava/lang/CharSequence;)V
    //   193: return
  }
  
  public void setCheckable(boolean paramBoolean) {}
  
  public void setChecked(boolean paramBoolean) {}
  
  public void setExpandedFormat(boolean paramBoolean) {
    if (this.s != paramBoolean) {
      this.s = paramBoolean;
      g g1 = this.l;
      if (g1 != null) {
        e e = g1.n;
        e.k = true;
        e.p(true);
      } 
    } 
  }
  
  public void setIcon(Drawable paramDrawable) {
    this.n = paramDrawable;
    if (paramDrawable != null) {
      int m = paramDrawable.getIntrinsicWidth();
      int n = paramDrawable.getIntrinsicHeight();
      int k = this.v;
      int i = m;
      int j = n;
      if (m > k) {
        float f = k / m;
        j = (int)(n * f);
        i = k;
      } 
      if (j > k) {
        float f = k / j;
        i = (int)(i * f);
      } else {
        k = j;
      } 
      paramDrawable.setBounds(0, 0, i, k);
    } 
    setCompoundDrawables(paramDrawable, null, null, null);
    p();
  }
  
  public void setItemInvoker(e.b paramb) {
    this.o = paramb;
  }
  
  public void setPadding(int paramInt1, int paramInt2, int paramInt3, int paramInt4) {
    this.u = paramInt1;
    super.setPadding(paramInt1, paramInt2, paramInt3, paramInt4);
  }
  
  public void setPopupCallback(b paramb) {
    this.q = paramb;
  }
  
  public void setTitle(CharSequence paramCharSequence) {
    this.m = paramCharSequence;
    p();
  }
  
  public class a extends i0 {
    public a(ActionMenuItemView this$0) {
      super((View)this$0);
    }
    
    public f b() {
      ActionMenuItemView.b b = this.q.q;
      d d2 = null;
      d d1 = d2;
      if (b != null) {
        c.a a1 = ((c.b)b).a.A;
        d1 = d2;
        if (a1 != null)
          d1 = a1.a(); 
      } 
      return (f)d1;
    }
    
    public boolean c() {
      ActionMenuItemView actionMenuItemView = this.q;
      e.b b = actionMenuItemView.o;
      boolean bool2 = false;
      boolean bool1 = bool2;
      if (b != null) {
        bool1 = bool2;
        if (b.a(actionMenuItemView.l)) {
          f f = b();
          bool1 = bool2;
          if (f != null) {
            bool1 = bool2;
            if (f.b())
              bool1 = true; 
          } 
        } 
      } 
      return bool1;
    }
  }
  
  public static abstract class b {}
}


/* Location:              C:\soft\dex2jar-2.0\Luxury Logo Maker_ Logo Design-dex2jar.jar!\androidx\appcompat\view\menu\ActionMenuItemView.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */