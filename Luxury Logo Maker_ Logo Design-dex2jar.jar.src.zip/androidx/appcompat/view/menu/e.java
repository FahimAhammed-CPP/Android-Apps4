package androidx.appcompat.view.menu;

import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.content.pm.ActivityInfo;
import android.content.pm.PackageManager;
import android.content.pm.ResolveInfo;
import android.content.res.Resources;
import android.graphics.drawable.Drawable;
import android.os.Build;
import android.os.Bundle;
import android.util.SparseArray;
import android.view.KeyCharacterMap;
import android.view.KeyEvent;
import android.view.MenuItem;
import android.view.SubMenu;
import android.view.View;
import android.view.ViewConfiguration;
import f0.a;
import java.lang.ref.WeakReference;
import java.lang.reflect.Method;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.concurrent.CopyOnWriteArrayList;
import k0.m;

public class e implements a {
  public static final int[] y = new int[] { 1, 4, 5, 3, 2, 0 };
  
  public final Context a;
  
  public final Resources b;
  
  public boolean c;
  
  public boolean d;
  
  public a e;
  
  public ArrayList<g> f;
  
  public ArrayList<g> g;
  
  public boolean h;
  
  public ArrayList<g> i;
  
  public ArrayList<g> j;
  
  public boolean k;
  
  public int l;
  
  public CharSequence m;
  
  public Drawable n;
  
  public View o;
  
  public boolean p;
  
  public boolean q;
  
  public boolean r;
  
  public boolean s;
  
  public ArrayList<g> t;
  
  public CopyOnWriteArrayList<WeakReference<i>> u;
  
  public g v;
  
  public boolean w;
  
  public boolean x;
  
  public e(Context paramContext) {
    boolean bool2 = false;
    this.l = 0;
    this.p = false;
    this.q = false;
    this.r = false;
    this.s = false;
    this.t = new ArrayList<g>();
    this.u = new CopyOnWriteArrayList<WeakReference<i>>();
    this.w = false;
    this.a = paramContext;
    Resources resources = paramContext.getResources();
    this.b = resources;
    this.f = new ArrayList<g>();
    this.g = new ArrayList<g>();
    this.h = true;
    this.i = new ArrayList<g>();
    this.j = new ArrayList<g>();
    this.k = true;
    boolean bool1 = bool2;
    if ((resources.getConfiguration()).keyboard != 1) {
      boolean bool;
      ViewConfiguration viewConfiguration = ViewConfiguration.get(paramContext);
      Method method = m.a;
      if (Build.VERSION.SDK_INT >= 28) {
        bool = viewConfiguration.shouldShowMenuShortcutsWhenKeyboardPresent();
      } else {
        Resources resources1 = paramContext.getResources();
        int i = resources1.getIdentifier("config_showMenuShortcutsWhenKeyboardPresent", "bool", "android");
        if (i != 0 && resources1.getBoolean(i)) {
          bool = true;
        } else {
          bool = false;
        } 
      } 
      bool1 = bool2;
      if (bool)
        bool1 = true; 
    } 
    this.d = bool1;
  }
  
  public MenuItem a(int paramInt1, int paramInt2, int paramInt3, CharSequence paramCharSequence) {
    int i = (0xFFFF0000 & paramInt3) >> 16;
    if (i >= 0) {
      int[] arrayOfInt = y;
      if (i < arrayOfInt.length) {
        i = arrayOfInt[i] << 16 | 0xFFFF & paramInt3;
        g g1 = new g(this, paramInt1, paramInt2, paramInt3, i, paramCharSequence, this.l);
        ArrayList<g> arrayList = this.f;
        paramInt1 = arrayList.size();
        while (true) {
          paramInt2 = paramInt1 - 1;
          if (paramInt2 >= 0) {
            paramInt1 = paramInt2;
            if (((g)arrayList.get(paramInt2)).d <= i) {
              paramInt1 = paramInt2 + 1;
              arrayList.add(paramInt1, g1);
              p(true);
              return (MenuItem)g1;
            } 
            continue;
          } 
          paramInt1 = 0;
          arrayList.add(paramInt1, g1);
          p(true);
          return (MenuItem)g1;
        } 
      } 
    } 
    throw new IllegalArgumentException("order does not contain a valid category.");
  }
  
  public MenuItem add(int paramInt) {
    return a(0, 0, 0, this.b.getString(paramInt));
  }
  
  public MenuItem add(int paramInt1, int paramInt2, int paramInt3, int paramInt4) {
    return a(paramInt1, paramInt2, paramInt3, this.b.getString(paramInt4));
  }
  
  public MenuItem add(int paramInt1, int paramInt2, int paramInt3, CharSequence paramCharSequence) {
    return a(paramInt1, paramInt2, paramInt3, paramCharSequence);
  }
  
  public MenuItem add(CharSequence paramCharSequence) {
    return a(0, 0, 0, paramCharSequence);
  }
  
  public int addIntentOptions(int paramInt1, int paramInt2, int paramInt3, ComponentName paramComponentName, Intent[] paramArrayOfIntent, Intent paramIntent, int paramInt4, MenuItem[] paramArrayOfMenuItem) {
    byte b1;
    PackageManager packageManager = this.a.getPackageManager();
    byte b2 = 0;
    List<ResolveInfo> list = packageManager.queryIntentActivityOptions(paramComponentName, paramArrayOfIntent, paramIntent, 0);
    if (list != null) {
      b1 = list.size();
    } else {
      b1 = 0;
    } 
    int i = b2;
    if ((paramInt4 & 0x1) == 0) {
      removeGroup(paramInt1);
      i = b2;
    } 
    while (i < b1) {
      ResolveInfo resolveInfo = list.get(i);
      paramInt4 = resolveInfo.specificIndex;
      if (paramInt4 < 0) {
        intent = paramIntent;
      } else {
        intent = paramArrayOfIntent[paramInt4];
      } 
      Intent intent = new Intent(intent);
      ActivityInfo activityInfo = resolveInfo.activityInfo;
      intent.setComponent(new ComponentName(activityInfo.applicationInfo.packageName, activityInfo.name));
      MenuItem menuItem = a(paramInt1, paramInt2, paramInt3, resolveInfo.loadLabel(packageManager));
      Drawable drawable = resolveInfo.loadIcon(packageManager);
      g g1 = (g)menuItem;
      g1.setIcon(drawable);
      g1.setIntent(intent);
      if (paramArrayOfMenuItem != null) {
        paramInt4 = resolveInfo.specificIndex;
        if (paramInt4 >= 0)
          paramArrayOfMenuItem[paramInt4] = (MenuItem)g1; 
      } 
      i++;
    } 
    return b1;
  }
  
  public SubMenu addSubMenu(int paramInt) {
    return addSubMenu(0, 0, 0, this.b.getString(paramInt));
  }
  
  public SubMenu addSubMenu(int paramInt1, int paramInt2, int paramInt3, int paramInt4) {
    return addSubMenu(paramInt1, paramInt2, paramInt3, this.b.getString(paramInt4));
  }
  
  public SubMenu addSubMenu(int paramInt1, int paramInt2, int paramInt3, CharSequence paramCharSequence) {
    g g1 = (g)a(paramInt1, paramInt2, paramInt3, paramCharSequence);
    l l = new l(this.a, this, g1);
    g1.o = l;
    l.setHeaderTitle(g1.e);
    return l;
  }
  
  public SubMenu addSubMenu(CharSequence paramCharSequence) {
    return addSubMenu(0, 0, 0, paramCharSequence);
  }
  
  public void b(i parami, Context paramContext) {
    this.u.add(new WeakReference<i>(parami));
    parami.c(paramContext, this);
    this.k = true;
  }
  
  public final void c(boolean paramBoolean) {
    if (this.s)
      return; 
    this.s = true;
    for (WeakReference<i> weakReference : this.u) {
      i i = weakReference.get();
      if (i == null) {
        this.u.remove(weakReference);
        continue;
      } 
      i.a(this, paramBoolean);
    } 
    this.s = false;
  }
  
  public void clear() {
    g g1 = this.v;
    if (g1 != null)
      d(g1); 
    this.f.clear();
    p(true);
  }
  
  public void clearHeader() {
    this.n = null;
    this.m = null;
    this.o = null;
    p(false);
  }
  
  public void close() {
    c(true);
  }
  
  public boolean d(g paramg) {
    boolean bool3 = this.u.isEmpty();
    boolean bool1 = false;
    boolean bool2 = false;
    if (!bool3) {
      if (this.v != paramg)
        return false; 
      y();
      Iterator<WeakReference<i>> iterator = this.u.iterator();
      bool1 = bool2;
      while (true) {
        bool2 = bool1;
        if (iterator.hasNext()) {
          WeakReference<i> weakReference = iterator.next();
          i i = weakReference.get();
          if (i == null) {
            this.u.remove(weakReference);
            continue;
          } 
          bool2 = i.i(this, paramg);
          bool1 = bool2;
          if (bool2)
            break; 
          continue;
        } 
        break;
      } 
      x();
      bool1 = bool2;
      if (bool2) {
        this.v = null;
        bool1 = bool2;
      } 
    } 
    return bool1;
  }
  
  public boolean e(e parame, MenuItem paramMenuItem) {
    a a1 = this.e;
    return (a1 != null && a1.a(parame, paramMenuItem));
  }
  
  public boolean f(g paramg) {
    boolean bool2 = this.u.isEmpty();
    boolean bool1 = false;
    if (bool2)
      return false; 
    y();
    Iterator<WeakReference<i>> iterator = this.u.iterator();
    while (true) {
      bool2 = bool1;
      if (iterator.hasNext()) {
        WeakReference<i> weakReference = iterator.next();
        i i = weakReference.get();
        if (i == null) {
          this.u.remove(weakReference);
          continue;
        } 
        bool2 = i.j(this, paramg);
        bool1 = bool2;
        if (bool2)
          break; 
        continue;
      } 
      break;
    } 
    x();
    if (bool2)
      this.v = paramg; 
    return bool2;
  }
  
  public MenuItem findItem(int paramInt) {
    int j = size();
    for (int i = 0; i < j; i++) {
      g g1 = this.f.get(i);
      if (g1.a == paramInt)
        return (MenuItem)g1; 
      if (g1.hasSubMenu()) {
        MenuItem menuItem = g1.o.findItem(paramInt);
        if (menuItem != null)
          return menuItem; 
      } 
    } 
    return null;
  }
  
  public g g(int paramInt, KeyEvent paramKeyEvent) {
    ArrayList<g> arrayList = this.t;
    arrayList.clear();
    h(arrayList, paramInt, paramKeyEvent);
    if (arrayList.isEmpty())
      return null; 
    int j = paramKeyEvent.getMetaState();
    KeyCharacterMap.KeyData keyData = new KeyCharacterMap.KeyData();
    paramKeyEvent.getKeyData(keyData);
    int k = arrayList.size();
    if (k == 1)
      return arrayList.get(0); 
    boolean bool = n();
    for (int i = 0; i < k; i++) {
      char c;
      g g1 = arrayList.get(i);
      if (bool) {
        c = g1.j;
      } else {
        c = g1.h;
      } 
      char[] arrayOfChar = keyData.meta;
      if ((c == arrayOfChar[0] && (j & 0x2) == 0) || (c == arrayOfChar[2] && (j & 0x2) != 0) || (bool && c == '\b' && paramInt == 67))
        return g1; 
    } 
    return null;
  }
  
  public MenuItem getItem(int paramInt) {
    return (MenuItem)this.f.get(paramInt);
  }
  
  public void h(List<g> paramList, int paramInt, KeyEvent paramKeyEvent) {
    boolean bool = n();
    int j = paramKeyEvent.getModifiers();
    KeyCharacterMap.KeyData keyData = new KeyCharacterMap.KeyData();
    if (!paramKeyEvent.getKeyData(keyData) && paramInt != 67)
      return; 
    int k = this.f.size();
    int i;
    for (i = 0; i < k; i++) {
      char c;
      int m;
      g g1 = this.f.get(i);
      if (g1.hasSubMenu())
        g1.o.h(paramList, paramInt, paramKeyEvent); 
      if (bool) {
        c = g1.j;
      } else {
        c = g1.h;
      } 
      if (bool) {
        m = g1.k;
      } else {
        m = g1.i;
      } 
      if ((j & 0x1100F) == (m & 0x1100F)) {
        m = 1;
      } else {
        m = 0;
      } 
      if (m != 0 && c != '\000') {
        char[] arrayOfChar = keyData.meta;
        if ((c == arrayOfChar[0] || c == arrayOfChar[2] || (bool && c == '\b' && paramInt == 67)) && g1.isEnabled())
          paramList.add(g1); 
      } 
    } 
  }
  
  public boolean hasVisibleItems() {
    if (this.x)
      return true; 
    int j = size();
    for (int i = 0; i < j; i++) {
      if (((g)this.f.get(i)).isVisible())
        return true; 
    } 
    return false;
  }
  
  public void i() {
    ArrayList<g> arrayList = l();
    if (!this.k)
      return; 
    Iterator<WeakReference<i>> iterator = this.u.iterator();
    boolean bool;
    for (bool = false; iterator.hasNext(); bool |= i.h()) {
      WeakReference<i> weakReference = iterator.next();
      i i = weakReference.get();
      if (i == null) {
        this.u.remove(weakReference);
        continue;
      } 
    } 
    if (bool) {
      this.i.clear();
      this.j.clear();
      int i = arrayList.size();
      bool = false;
      while (bool < i) {
        ArrayList<g> arrayList1;
        g g1 = arrayList.get(bool);
        if (g1.g()) {
          arrayList1 = this.i;
        } else {
          arrayList1 = this.j;
        } 
        arrayList1.add(g1);
        int j = bool + 1;
      } 
    } else {
      this.i.clear();
      this.j.clear();
      this.j.addAll(l());
    } 
    this.k = false;
  }
  
  public boolean isShortcutKey(int paramInt, KeyEvent paramKeyEvent) {
    return (g(paramInt, paramKeyEvent) != null);
  }
  
  public String j() {
    return "android:menu:actionviewstates";
  }
  
  public e k() {
    return this;
  }
  
  public ArrayList<g> l() {
    if (!this.h)
      return this.g; 
    this.g.clear();
    int j = this.f.size();
    for (int i = 0; i < j; i++) {
      g g1 = this.f.get(i);
      if (g1.isVisible())
        this.g.add(g1); 
    } 
    this.h = false;
    this.k = true;
    return this.g;
  }
  
  public boolean m() {
    return this.w;
  }
  
  public boolean n() {
    return this.c;
  }
  
  public boolean o() {
    return this.d;
  }
  
  public void p(boolean paramBoolean) {
    if (!this.p) {
      if (paramBoolean) {
        this.h = true;
        this.k = true;
      } 
      if (this.u.isEmpty())
        return; 
      y();
      for (WeakReference<i> weakReference : this.u) {
        i i = weakReference.get();
        if (i == null) {
          this.u.remove(weakReference);
          continue;
        } 
        i.f(paramBoolean);
      } 
      x();
      return;
    } 
    this.q = true;
    if (paramBoolean)
      this.r = true; 
  }
  
  public boolean performIdentifierAction(int paramInt1, int paramInt2) {
    return q(findItem(paramInt1), paramInt2);
  }
  
  public boolean performShortcut(int paramInt1, KeyEvent paramKeyEvent, int paramInt2) {
    boolean bool;
    g g1 = g(paramInt1, paramKeyEvent);
    if (g1 != null) {
      bool = r((MenuItem)g1, null, paramInt2);
    } else {
      bool = false;
    } 
    if ((paramInt2 & 0x2) != 0)
      c(true); 
    return bool;
  }
  
  public boolean q(MenuItem paramMenuItem, int paramInt) {
    return r(paramMenuItem, null, paramInt);
  }
  
  public boolean r(MenuItem paramMenuItem, i parami, int paramInt) {
    // Byte code:
    //   0: aload_1
    //   1: checkcast androidx/appcompat/view/menu/g
    //   4: astore_1
    //   5: iconst_0
    //   6: istore #7
    //   8: iconst_0
    //   9: istore #6
    //   11: aload_1
    //   12: ifnull -> 418
    //   15: aload_1
    //   16: invokevirtual isEnabled : ()Z
    //   19: ifne -> 24
    //   22: iconst_0
    //   23: ireturn
    //   24: aload_1
    //   25: getfield p : Landroid/view/MenuItem$OnMenuItemClickListener;
    //   28: astore #8
    //   30: aload #8
    //   32: ifnull -> 49
    //   35: aload #8
    //   37: aload_1
    //   38: invokeinterface onMenuItemClick : (Landroid/view/MenuItem;)Z
    //   43: ifeq -> 49
    //   46: goto -> 128
    //   49: aload_1
    //   50: getfield n : Landroidx/appcompat/view/menu/e;
    //   53: astore #8
    //   55: aload #8
    //   57: aload #8
    //   59: aload_1
    //   60: invokevirtual e : (Landroidx/appcompat/view/menu/e;Landroid/view/MenuItem;)Z
    //   63: ifeq -> 69
    //   66: goto -> 128
    //   69: aload_1
    //   70: getfield g : Landroid/content/Intent;
    //   73: astore #8
    //   75: aload #8
    //   77: ifnull -> 109
    //   80: aload_1
    //   81: getfield n : Landroidx/appcompat/view/menu/e;
    //   84: getfield a : Landroid/content/Context;
    //   87: aload #8
    //   89: invokevirtual startActivity : (Landroid/content/Intent;)V
    //   92: goto -> 128
    //   95: astore #8
    //   97: ldc_w 'MenuItemImpl'
    //   100: ldc_w 'Can't find activity to handle intent; ignoring'
    //   103: aload #8
    //   105: invokestatic e : (Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)I
    //   108: pop
    //   109: aload_1
    //   110: getfield A : Lk0/b;
    //   113: astore #8
    //   115: aload #8
    //   117: ifnull -> 134
    //   120: aload #8
    //   122: invokevirtual e : ()Z
    //   125: ifeq -> 134
    //   128: iconst_1
    //   129: istore #5
    //   131: goto -> 137
    //   134: iconst_0
    //   135: istore #5
    //   137: aload_1
    //   138: getfield A : Lk0/b;
    //   141: astore #8
    //   143: aload #8
    //   145: ifnull -> 162
    //   148: aload #8
    //   150: invokevirtual a : ()Z
    //   153: ifeq -> 162
    //   156: iconst_1
    //   157: istore #4
    //   159: goto -> 165
    //   162: iconst_0
    //   163: istore #4
    //   165: aload_1
    //   166: invokevirtual f : ()Z
    //   169: ifeq -> 193
    //   172: iload #5
    //   174: aload_1
    //   175: invokevirtual expandActionView : ()Z
    //   178: ior
    //   179: istore #5
    //   181: iload #5
    //   183: istore #6
    //   185: iload #5
    //   187: ifeq -> 415
    //   190: goto -> 406
    //   193: aload_1
    //   194: invokevirtual hasSubMenu : ()Z
    //   197: ifne -> 221
    //   200: iload #4
    //   202: ifeq -> 208
    //   205: goto -> 221
    //   208: iload #5
    //   210: istore #6
    //   212: iload_3
    //   213: iconst_1
    //   214: iand
    //   215: ifne -> 415
    //   218: goto -> 406
    //   221: iload_3
    //   222: iconst_4
    //   223: iand
    //   224: ifne -> 232
    //   227: aload_0
    //   228: iconst_0
    //   229: invokevirtual c : (Z)V
    //   232: aload_1
    //   233: invokevirtual hasSubMenu : ()Z
    //   236: ifne -> 270
    //   239: new androidx/appcompat/view/menu/l
    //   242: dup
    //   243: aload_0
    //   244: getfield a : Landroid/content/Context;
    //   247: aload_0
    //   248: aload_1
    //   249: invokespecial <init> : (Landroid/content/Context;Landroidx/appcompat/view/menu/e;Landroidx/appcompat/view/menu/g;)V
    //   252: astore #9
    //   254: aload_1
    //   255: aload #9
    //   257: putfield o : Landroidx/appcompat/view/menu/l;
    //   260: aload #9
    //   262: aload_1
    //   263: getfield e : Ljava/lang/CharSequence;
    //   266: invokevirtual setHeaderTitle : (Ljava/lang/CharSequence;)Landroid/view/SubMenu;
    //   269: pop
    //   270: aload_1
    //   271: getfield o : Landroidx/appcompat/view/menu/l;
    //   274: astore_1
    //   275: iload #4
    //   277: ifeq -> 286
    //   280: aload #8
    //   282: aload_1
    //   283: invokevirtual f : (Landroid/view/SubMenu;)V
    //   286: aload_0
    //   287: getfield u : Ljava/util/concurrent/CopyOnWriteArrayList;
    //   290: invokevirtual isEmpty : ()Z
    //   293: ifeq -> 299
    //   296: goto -> 390
    //   299: aload_2
    //   300: ifnull -> 312
    //   303: aload_2
    //   304: aload_1
    //   305: invokeinterface e : (Landroidx/appcompat/view/menu/l;)Z
    //   310: istore #6
    //   312: aload_0
    //   313: getfield u : Ljava/util/concurrent/CopyOnWriteArrayList;
    //   316: invokevirtual iterator : ()Ljava/util/Iterator;
    //   319: astore_2
    //   320: iload #6
    //   322: istore #7
    //   324: aload_2
    //   325: invokeinterface hasNext : ()Z
    //   330: ifeq -> 390
    //   333: aload_2
    //   334: invokeinterface next : ()Ljava/lang/Object;
    //   339: checkcast java/lang/ref/WeakReference
    //   342: astore #8
    //   344: aload #8
    //   346: invokevirtual get : ()Ljava/lang/Object;
    //   349: checkcast androidx/appcompat/view/menu/i
    //   352: astore #9
    //   354: aload #9
    //   356: ifnonnull -> 372
    //   359: aload_0
    //   360: getfield u : Ljava/util/concurrent/CopyOnWriteArrayList;
    //   363: aload #8
    //   365: invokevirtual remove : (Ljava/lang/Object;)Z
    //   368: pop
    //   369: goto -> 320
    //   372: iload #6
    //   374: ifne -> 320
    //   377: aload #9
    //   379: aload_1
    //   380: invokeinterface e : (Landroidx/appcompat/view/menu/l;)Z
    //   385: istore #6
    //   387: goto -> 320
    //   390: iload #5
    //   392: iload #7
    //   394: ior
    //   395: istore #5
    //   397: iload #5
    //   399: istore #6
    //   401: iload #5
    //   403: ifne -> 415
    //   406: aload_0
    //   407: iconst_1
    //   408: invokevirtual c : (Z)V
    //   411: iload #5
    //   413: istore #6
    //   415: iload #6
    //   417: ireturn
    //   418: iconst_0
    //   419: ireturn
    // Exception table:
    //   from	to	target	type
    //   80	92	95	android/content/ActivityNotFoundException
  }
  
  public void removeGroup(int paramInt) {
    // Byte code:
    //   0: aload_0
    //   1: invokevirtual size : ()I
    //   4: istore_3
    //   5: iconst_0
    //   6: istore_2
    //   7: iload_2
    //   8: iload_3
    //   9: if_icmpge -> 40
    //   12: aload_0
    //   13: getfield f : Ljava/util/ArrayList;
    //   16: iload_2
    //   17: invokevirtual get : (I)Ljava/lang/Object;
    //   20: checkcast androidx/appcompat/view/menu/g
    //   23: getfield b : I
    //   26: iload_1
    //   27: if_icmpne -> 33
    //   30: goto -> 42
    //   33: iload_2
    //   34: iconst_1
    //   35: iadd
    //   36: istore_2
    //   37: goto -> 7
    //   40: iconst_m1
    //   41: istore_2
    //   42: iload_2
    //   43: iflt -> 101
    //   46: aload_0
    //   47: getfield f : Ljava/util/ArrayList;
    //   50: invokevirtual size : ()I
    //   53: istore #4
    //   55: iconst_0
    //   56: istore_3
    //   57: iload_3
    //   58: iload #4
    //   60: iload_2
    //   61: isub
    //   62: if_icmpge -> 96
    //   65: aload_0
    //   66: getfield f : Ljava/util/ArrayList;
    //   69: iload_2
    //   70: invokevirtual get : (I)Ljava/lang/Object;
    //   73: checkcast androidx/appcompat/view/menu/g
    //   76: getfield b : I
    //   79: iload_1
    //   80: if_icmpne -> 96
    //   83: aload_0
    //   84: iload_2
    //   85: iconst_0
    //   86: invokevirtual s : (IZ)V
    //   89: iload_3
    //   90: iconst_1
    //   91: iadd
    //   92: istore_3
    //   93: goto -> 57
    //   96: aload_0
    //   97: iconst_1
    //   98: invokevirtual p : (Z)V
    //   101: return
  }
  
  public void removeItem(int paramInt) {
    // Byte code:
    //   0: aload_0
    //   1: invokevirtual size : ()I
    //   4: istore_3
    //   5: iconst_0
    //   6: istore_2
    //   7: iload_2
    //   8: iload_3
    //   9: if_icmpge -> 40
    //   12: aload_0
    //   13: getfield f : Ljava/util/ArrayList;
    //   16: iload_2
    //   17: invokevirtual get : (I)Ljava/lang/Object;
    //   20: checkcast androidx/appcompat/view/menu/g
    //   23: getfield a : I
    //   26: iload_1
    //   27: if_icmpne -> 33
    //   30: goto -> 42
    //   33: iload_2
    //   34: iconst_1
    //   35: iadd
    //   36: istore_2
    //   37: goto -> 7
    //   40: iconst_m1
    //   41: istore_2
    //   42: aload_0
    //   43: iload_2
    //   44: iconst_1
    //   45: invokevirtual s : (IZ)V
    //   48: return
  }
  
  public final void s(int paramInt, boolean paramBoolean) {
    if (paramInt >= 0) {
      if (paramInt >= this.f.size())
        return; 
      this.f.remove(paramInt);
      if (paramBoolean)
        p(true); 
    } 
  }
  
  public void setGroupCheckable(int paramInt, boolean paramBoolean1, boolean paramBoolean2) {
    int j = this.f.size();
    int i;
    for (i = 0; i < j; i++) {
      g g1 = this.f.get(i);
      if (g1.b == paramInt) {
        boolean bool;
        int k = g1.x;
        if (paramBoolean2) {
          bool = true;
        } else {
          bool = false;
        } 
        g1.x = k & 0xFFFFFFFB | bool;
        g1.setCheckable(paramBoolean1);
      } 
    } 
  }
  
  public void setGroupDividerEnabled(boolean paramBoolean) {
    this.w = paramBoolean;
  }
  
  public void setGroupEnabled(int paramInt, boolean paramBoolean) {
    int j = this.f.size();
    for (int i = 0; i < j; i++) {
      g g1 = this.f.get(i);
      if (g1.b == paramInt)
        g1.setEnabled(paramBoolean); 
    } 
  }
  
  public void setGroupVisible(int paramInt, boolean paramBoolean) {
    int j = this.f.size();
    int i = 0;
    boolean bool;
    for (bool = false; i < j; bool = bool1) {
      g g1 = this.f.get(i);
      boolean bool1 = bool;
      if (g1.b == paramInt) {
        bool1 = bool;
        if (g1.l(paramBoolean))
          bool1 = true; 
      } 
      i++;
    } 
    if (bool)
      p(true); 
  }
  
  public void setQwertyMode(boolean paramBoolean) {
    this.c = paramBoolean;
    p(false);
  }
  
  public int size() {
    return this.f.size();
  }
  
  public void t(i parami) {
    for (WeakReference<i> weakReference : this.u) {
      i i1 = weakReference.get();
      if (i1 == null || i1 == parami)
        this.u.remove(weakReference); 
    } 
  }
  
  public void u(Bundle paramBundle) {
    if (paramBundle == null)
      return; 
    SparseArray sparseArray = paramBundle.getSparseParcelableArray(j());
    int j = size();
    int i;
    for (i = 0; i < j; i++) {
      MenuItem menuItem = getItem(i);
      View view = menuItem.getActionView();
      if (view != null && view.getId() != -1)
        view.restoreHierarchyState(sparseArray); 
      if (menuItem.hasSubMenu())
        ((l)menuItem.getSubMenu()).u(paramBundle); 
    } 
    i = paramBundle.getInt("android:menu:expandedactionview");
    if (i > 0) {
      MenuItem menuItem = findItem(i);
      if (menuItem != null)
        menuItem.expandActionView(); 
    } 
  }
  
  public void v(Bundle paramBundle) {
    int j = size();
    SparseArray sparseArray = null;
    int i = 0;
    while (i < j) {
      MenuItem menuItem = getItem(i);
      View view = menuItem.getActionView();
      SparseArray sparseArray1 = sparseArray;
      if (view != null) {
        sparseArray1 = sparseArray;
        if (view.getId() != -1) {
          SparseArray sparseArray2 = sparseArray;
          if (sparseArray == null)
            sparseArray2 = new SparseArray(); 
          view.saveHierarchyState(sparseArray2);
          sparseArray1 = sparseArray2;
          if (menuItem.isActionViewExpanded()) {
            paramBundle.putInt("android:menu:expandedactionview", menuItem.getItemId());
            sparseArray1 = sparseArray2;
          } 
        } 
      } 
      if (menuItem.hasSubMenu())
        ((l)menuItem.getSubMenu()).v(paramBundle); 
      i++;
      sparseArray = sparseArray1;
    } 
    if (sparseArray != null)
      paramBundle.putSparseParcelableArray(j(), sparseArray); 
  }
  
  public final void w(int paramInt1, CharSequence paramCharSequence, int paramInt2, Drawable paramDrawable, View paramView) {
    Resources resources = this.b;
    if (paramView != null) {
      this.o = paramView;
      this.m = null;
      this.n = null;
    } else {
      Object object;
      if (paramInt1 > 0) {
        this.m = resources.getText(paramInt1);
      } else if (paramCharSequence != null) {
        this.m = paramCharSequence;
      } 
      if (paramInt2 > 0) {
        Context context = this.a;
        object = b0.a.a;
        this.n = b0.a.c.b(context, paramInt2);
      } else if (object != null) {
        this.n = (Drawable)object;
      } 
      this.o = null;
    } 
    p(false);
  }
  
  public void x() {
    this.p = false;
    if (this.q) {
      this.q = false;
      p(this.r);
    } 
  }
  
  public void y() {
    if (!this.p) {
      this.p = true;
      this.q = false;
      this.r = false;
    } 
  }
  
  public static interface a {
    boolean a(e param1e, MenuItem param1MenuItem);
    
    void b(e param1e);
  }
  
  public static interface b {
    boolean a(g param1g);
  }
}


/* Location:              C:\soft\dex2jar-2.0\Luxury Logo Maker_ Logo Design-dex2jar.jar!\androidx\appcompat\view\menu\e.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */