package androidx.appcompat.view.menu;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import java.util.ArrayList;

public class d extends BaseAdapter {
  public e h;
  
  public int i = -1;
  
  public boolean j;
  
  public final boolean k;
  
  public final LayoutInflater l;
  
  public final int m;
  
  public d(e parame, LayoutInflater paramLayoutInflater, boolean paramBoolean, int paramInt) {
    this.k = paramBoolean;
    this.l = paramLayoutInflater;
    this.h = parame;
    this.m = paramInt;
    a();
  }
  
  public void a() {
    e e1 = this.h;
    g g = e1.v;
    if (g != null) {
      e1.i();
      ArrayList<g> arrayList = e1.j;
      int j = arrayList.size();
      for (int i = 0; i < j; i++) {
        if ((g)arrayList.get(i) == g) {
          this.i = i;
          return;
        } 
      } 
    } 
    this.i = -1;
  }
  
  public g b(int paramInt) {
    ArrayList<g> arrayList;
    if (this.k) {
      e e1 = this.h;
      e1.i();
      arrayList = e1.j;
    } else {
      arrayList = this.h.l();
    } 
    int j = this.i;
    int i = paramInt;
    if (j >= 0) {
      i = paramInt;
      if (paramInt >= j)
        i = paramInt + 1; 
    } 
    return arrayList.get(i);
  }
  
  public int getCount() {
    ArrayList<g> arrayList;
    if (this.k) {
      e e1 = this.h;
      e1.i();
      arrayList = e1.j;
    } else {
      arrayList = this.h.l();
    } 
    int i = this.i;
    int j = arrayList.size();
    return (i < 0) ? j : (j - 1);
  }
  
  public long getItemId(int paramInt) {
    return paramInt;
  }
  
  public View getView(int paramInt, View paramView, ViewGroup paramViewGroup) {
    boolean bool;
    View view = paramView;
    if (paramView == null)
      view = this.l.inflate(this.m, paramViewGroup, false); 
    int j = (b(paramInt)).b;
    int i = paramInt - 1;
    if (i >= 0) {
      i = (b(i)).b;
    } else {
      i = j;
    } 
    ListMenuItemView listMenuItemView = (ListMenuItemView)view;
    if (this.h.m() && j != i) {
      bool = true;
    } else {
      bool = false;
    } 
    listMenuItemView.setGroupDividerEnabled(bool);
    j.a a = (j.a)view;
    if (this.j)
      listMenuItemView.setForceShowIcon(true); 
    a.f(b(paramInt), 0);
    return view;
  }
  
  public void notifyDataSetChanged() {
    a();
    super.notifyDataSetChanged();
  }
}


/* Location:              C:\soft\dex2jar-2.0\Luxury Logo Maker_ Logo Design-dex2jar.jar!\androidx\appcompat\view\menu\d.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */