package androidx.appcompat.view.menu;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.view.WindowManager;
import android.widget.AdapterView;
import android.widget.BaseAdapter;
import android.widget.ListAdapter;
import androidx.appcompat.app.AlertController;
import androidx.appcompat.app.b;
import java.util.ArrayList;
import java.util.Objects;

public class c implements i, AdapterView.OnItemClickListener {
  public Context h;
  
  public LayoutInflater i;
  
  public e j;
  
  public ExpandedMenuView k;
  
  public i.a l;
  
  public a m;
  
  public c(Context paramContext, int paramInt) {
    this.h = paramContext;
    this.i = LayoutInflater.from(paramContext);
  }
  
  public void a(e parame, boolean paramBoolean) {
    i.a a1 = this.l;
    if (a1 != null)
      a1.a(parame, paramBoolean); 
  }
  
  public ListAdapter b() {
    if (this.m == null)
      this.m = new a(this); 
    return (ListAdapter)this.m;
  }
  
  public void c(Context paramContext, e parame) {
    if (this.h != null) {
      this.h = paramContext;
      if (this.i == null)
        this.i = LayoutInflater.from(paramContext); 
    } 
    this.j = parame;
    a a1 = this.m;
    if (a1 != null)
      a1.notifyDataSetChanged(); 
  }
  
  public boolean e(l paraml) {
    if (!paraml.hasVisibleItems())
      return false; 
    f f = new f(paraml);
    b.a a2 = new b.a(paraml.a);
    c c1 = new c(a2.a.a, 2131558416);
    f.j = c1;
    c1.l = f;
    e e1 = f.h;
    e1.b(c1, e1.a);
    ListAdapter listAdapter = f.j.b();
    AlertController.b b1 = a2.a;
    b1.g = listAdapter;
    b1.h = f;
    View view = paraml.o;
    if (view != null) {
      b1.e = view;
    } else {
      b1.c = paraml.n;
      b1.d = paraml.m;
    } 
    b1.f = f;
    b b = a2.a();
    f.i = b;
    b.setOnDismissListener(f);
    WindowManager.LayoutParams layoutParams = f.i.getWindow().getAttributes();
    layoutParams.type = 1003;
    layoutParams.flags |= 0x20000;
    f.i.show();
    i.a a1 = this.l;
    if (a1 != null)
      a1.b(paraml); 
    return true;
  }
  
  public void f(boolean paramBoolean) {
    a a1 = this.m;
    if (a1 != null)
      a1.notifyDataSetChanged(); 
  }
  
  public boolean h() {
    return false;
  }
  
  public boolean i(e parame, g paramg) {
    return false;
  }
  
  public boolean j(e parame, g paramg) {
    return false;
  }
  
  public void k(i.a parama) {
    this.l = parama;
  }
  
  public void onItemClick(AdapterView<?> paramAdapterView, View paramView, int paramInt, long paramLong) {
    this.j.r((MenuItem)this.m.b(paramInt), this, 0);
  }
  
  public class a extends BaseAdapter {
    public int h = -1;
    
    public a(c this$0) {
      a();
    }
    
    public void a() {
      e e = this.i.j;
      g g = e.v;
      if (g != null) {
        e.i();
        ArrayList<g> arrayList = e.j;
        int j = arrayList.size();
        for (int i = 0; i < j; i++) {
          if ((g)arrayList.get(i) == g) {
            this.h = i;
            return;
          } 
        } 
      } 
      this.h = -1;
    }
    
    public g b(int param1Int) {
      e e = this.i.j;
      e.i();
      ArrayList<g> arrayList = e.j;
      Objects.requireNonNull(this.i);
      int i = param1Int + 0;
      int j = this.h;
      param1Int = i;
      if (j >= 0) {
        param1Int = i;
        if (i >= j)
          param1Int = i + 1; 
      } 
      return arrayList.get(param1Int);
    }
    
    public int getCount() {
      e e = this.i.j;
      e.i();
      int i = e.j.size();
      Objects.requireNonNull(this.i);
      i += 0;
      return (this.h < 0) ? i : (i - 1);
    }
    
    public long getItemId(int param1Int) {
      return param1Int;
    }
    
    public View getView(int param1Int, View param1View, ViewGroup param1ViewGroup) {
      View view = param1View;
      if (param1View == null)
        view = this.i.i.inflate(2131558416, param1ViewGroup, false); 
      ((j.a)view).f(b(param1Int), 0);
      return view;
    }
    
    public void notifyDataSetChanged() {
      a();
      super.notifyDataSetChanged();
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Luxury Logo Maker_ Logo Design-dex2jar.jar!\androidx\appcompat\view\menu\c.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */