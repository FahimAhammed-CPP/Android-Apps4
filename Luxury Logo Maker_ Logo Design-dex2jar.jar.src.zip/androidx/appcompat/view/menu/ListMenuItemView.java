package androidx.appcompat.view.menu;

import android.content.Context;
import android.content.res.Resources;
import android.content.res.TypedArray;
import android.graphics.Rect;
import android.graphics.drawable.Drawable;
import android.util.AttributeSet;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewConfiguration;
import android.view.ViewGroup;
import android.widget.AbsListView;
import android.widget.CheckBox;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.RadioButton;
import android.widget.TextView;
import androidx.appcompat.widget.z0;
import com.bumptech.glide.manager.b;
import java.util.Objects;
import java.util.WeakHashMap;
import k0.l;

public class ListMenuItemView extends LinearLayout implements j.a, AbsListView.SelectionBoundsAdjuster {
  public g h;
  
  public ImageView i;
  
  public RadioButton j;
  
  public TextView k;
  
  public CheckBox l;
  
  public TextView m;
  
  public ImageView n;
  
  public ImageView o;
  
  public LinearLayout p;
  
  public Drawable q;
  
  public int r;
  
  public Context s;
  
  public boolean t;
  
  public Drawable u;
  
  public boolean v;
  
  public LayoutInflater w;
  
  public boolean x;
  
  public ListMenuItemView(Context paramContext, AttributeSet paramAttributeSet) {
    super(paramContext, paramAttributeSet);
    z0 z0 = z0.q(getContext(), paramAttributeSet, b.y, 2130969114, 0);
    this.q = z0.g(5);
    this.r = z0.l(1, -1);
    this.t = z0.a(7, false);
    this.s = paramContext;
    this.u = z0.g(8);
    TypedArray typedArray = paramContext.getTheme().obtainStyledAttributes(null, new int[] { 16843049 }, 2130968872, 0);
    this.v = typedArray.hasValue(0);
    z0.b.recycle();
    typedArray.recycle();
  }
  
  private LayoutInflater getInflater() {
    if (this.w == null)
      this.w = LayoutInflater.from(getContext()); 
    return this.w;
  }
  
  private void setSubMenuArrowVisible(boolean paramBoolean) {
    ImageView imageView = this.n;
    if (imageView != null) {
      byte b;
      if (paramBoolean) {
        b = 0;
      } else {
        b = 8;
      } 
      imageView.setVisibility(b);
    } 
  }
  
  public final void a() {
    CheckBox checkBox = (CheckBox)getInflater().inflate(2131558414, (ViewGroup)this, false);
    this.l = checkBox;
    LinearLayout linearLayout = this.p;
    if (linearLayout != null) {
      linearLayout.addView((View)checkBox, -1);
      return;
    } 
    addView((View)checkBox, -1);
  }
  
  public void adjustListItemSelectionBounds(Rect paramRect) {
    ImageView imageView = this.o;
    if (imageView != null && imageView.getVisibility() == 0) {
      LinearLayout.LayoutParams layoutParams = (LinearLayout.LayoutParams)this.o.getLayoutParams();
      int i = paramRect.top;
      paramRect.top = this.o.getHeight() + layoutParams.topMargin + layoutParams.bottomMargin + i;
    } 
  }
  
  public final void b() {
    RadioButton radioButton = (RadioButton)getInflater().inflate(2131558417, (ViewGroup)this, false);
    this.j = radioButton;
    LinearLayout linearLayout = this.p;
    if (linearLayout != null) {
      linearLayout.addView((View)radioButton, -1);
      return;
    } 
    addView((View)radioButton, -1);
  }
  
  public void f(g paramg, int paramInt) {
    this.h = paramg;
    boolean bool = paramg.isVisible();
    byte b = 0;
    if (bool) {
      paramInt = 0;
    } else {
      paramInt = 8;
    } 
    setVisibility(paramInt);
    setTitle(paramg.e);
    setCheckable(paramg.isCheckable());
    bool = paramg.m();
    paramg.e();
    if (!bool || !this.h.m())
      b = 8; 
    if (b == 0) {
      String str;
      TextView textView = this.m;
      g g1 = this.h;
      char c = g1.e();
      if (c == '\000') {
        str = "";
      } else {
        Resources resources = ((g)str).n.a.getResources();
        StringBuilder stringBuilder = new StringBuilder();
        if (ViewConfiguration.get(((g)str).n.a).hasPermanentMenuKey())
          stringBuilder.append(resources.getString(2131820562)); 
        if (((g)str).n.n()) {
          paramInt = ((g)str).k;
        } else {
          paramInt = ((g)str).i;
        } 
        g.c(stringBuilder, paramInt, 65536, resources.getString(2131820558));
        g.c(stringBuilder, paramInt, 4096, resources.getString(2131820554));
        g.c(stringBuilder, paramInt, 2, resources.getString(2131820553));
        g.c(stringBuilder, paramInt, 1, resources.getString(2131820559));
        g.c(stringBuilder, paramInt, 4, resources.getString(2131820561));
        g.c(stringBuilder, paramInt, 8, resources.getString(2131820557));
        if (c != '\b') {
          if (c != '\n') {
            if (c != ' ') {
              stringBuilder.append(c);
            } else {
              paramInt = 2131820560;
              stringBuilder.append(resources.getString(paramInt));
            } 
          } else {
            paramInt = 2131820556;
            stringBuilder.append(resources.getString(paramInt));
          } 
        } else {
          paramInt = 2131820555;
          stringBuilder.append(resources.getString(paramInt));
        } 
        str = stringBuilder.toString();
      } 
      textView.setText(str);
    } 
    if (this.m.getVisibility() != b)
      this.m.setVisibility(b); 
    setIcon(paramg.getIcon());
    setEnabled(paramg.isEnabled());
    setSubMenuArrowVisible(paramg.hasSubMenu());
    setContentDescription(paramg.q);
  }
  
  public g getItemData() {
    return this.h;
  }
  
  public void onFinishInflate() {
    super.onFinishInflate();
    Drawable drawable = this.q;
    WeakHashMap weakHashMap = l.a;
    setBackground(drawable);
    TextView textView = (TextView)findViewById(2131362442);
    this.k = textView;
    int i = this.r;
    if (i != -1)
      textView.setTextAppearance(this.s, i); 
    this.m = (TextView)findViewById(2131362325);
    ImageView imageView = (ImageView)findViewById(2131362384);
    this.n = imageView;
    if (imageView != null)
      imageView.setImageDrawable(this.u); 
    this.o = (ImageView)findViewById(2131362089);
    this.p = (LinearLayout)findViewById(2131361984);
  }
  
  public void onMeasure(int paramInt1, int paramInt2) {
    if (this.i != null && this.t) {
      ViewGroup.LayoutParams layoutParams = getLayoutParams();
      LinearLayout.LayoutParams layoutParams1 = (LinearLayout.LayoutParams)this.i.getLayoutParams();
      int i = layoutParams.height;
      if (i > 0 && layoutParams1.width <= 0)
        layoutParams1.width = i; 
    } 
    super.onMeasure(paramInt1, paramInt2);
  }
  
  public void setCheckable(boolean paramBoolean) {
    CheckBox checkBox;
    RadioButton radioButton;
    if (!paramBoolean && this.j == null && this.l == null)
      return; 
    if (this.h.h()) {
      if (this.j == null)
        b(); 
      RadioButton radioButton1 = this.j;
      CheckBox checkBox1 = this.l;
    } else {
      if (this.l == null)
        a(); 
      checkBox = this.l;
      radioButton = this.j;
    } 
    if (paramBoolean) {
      checkBox.setChecked(this.h.isChecked());
      if (checkBox.getVisibility() != 0)
        checkBox.setVisibility(0); 
      if (radioButton != null && radioButton.getVisibility() != 8) {
        radioButton.setVisibility(8);
        return;
      } 
    } else {
      checkBox = this.l;
      if (checkBox != null)
        checkBox.setVisibility(8); 
      RadioButton radioButton1 = this.j;
      if (radioButton1 != null)
        radioButton1.setVisibility(8); 
    } 
  }
  
  public void setChecked(boolean paramBoolean) {
    CheckBox checkBox;
    if (this.h.h()) {
      if (this.j == null)
        b(); 
      RadioButton radioButton = this.j;
    } else {
      if (this.l == null)
        a(); 
      checkBox = this.l;
    } 
    checkBox.setChecked(paramBoolean);
  }
  
  public void setForceShowIcon(boolean paramBoolean) {
    this.x = paramBoolean;
    this.t = paramBoolean;
  }
  
  public void setGroupDividerEnabled(boolean paramBoolean) {
    ImageView imageView = this.o;
    if (imageView != null) {
      byte b;
      if (!this.v && paramBoolean) {
        b = 0;
      } else {
        b = 8;
      } 
      imageView.setVisibility(b);
    } 
  }
  
  public void setIcon(Drawable paramDrawable) {
    boolean bool;
    Objects.requireNonNull(this.h.n);
    if (this.x) {
      bool = true;
    } else {
      bool = false;
    } 
    if (!bool && !this.t)
      return; 
    ImageView imageView = this.i;
    if (imageView == null && paramDrawable == null && !this.t)
      return; 
    if (imageView == null) {
      imageView = (ImageView)getInflater().inflate(2131558415, (ViewGroup)this, false);
      this.i = imageView;
      LinearLayout linearLayout = this.p;
      if (linearLayout != null) {
        linearLayout.addView((View)imageView, 0);
      } else {
        addView((View)imageView, 0);
      } 
    } 
    if (paramDrawable != null || this.t) {
      imageView = this.i;
      if (!bool)
        paramDrawable = null; 
      imageView.setImageDrawable(paramDrawable);
      if (this.i.getVisibility() != 0)
        this.i.setVisibility(0); 
      return;
    } 
    this.i.setVisibility(8);
  }
  
  public void setTitle(CharSequence paramCharSequence) {
    TextView textView;
    byte b;
    if (paramCharSequence != null) {
      this.k.setText(paramCharSequence);
      if (this.k.getVisibility() != 0) {
        textView = this.k;
        b = 0;
      } else {
        return;
      } 
    } else {
      int i = this.k.getVisibility();
      b = 8;
      if (i != 8) {
        textView = this.k;
      } else {
        return;
      } 
    } 
    textView.setVisibility(b);
  }
}


/* Location:              C:\soft\dex2jar-2.0\Luxury Logo Maker_ Logo Design-dex2jar.jar!\androidx\appcompat\view\menu\ListMenuItemView.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */