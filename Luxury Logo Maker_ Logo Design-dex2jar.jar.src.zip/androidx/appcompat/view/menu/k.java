package androidx.appcompat.view.menu;

import android.content.Context;
import android.content.res.Resources;
import android.graphics.Rect;
import android.view.KeyEvent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.ViewTreeObserver;
import android.widget.AdapterView;
import android.widget.FrameLayout;
import android.widget.ListAdapter;
import android.widget.ListView;
import android.widget.PopupWindow;
import android.widget.TextView;
import androidx.appcompat.widget.g0;
import androidx.appcompat.widget.l0;
import androidx.appcompat.widget.n0;
import java.util.Objects;
import k.d;

public final class k extends d implements PopupWindow.OnDismissListener, View.OnKeyListener {
  public int A = 0;
  
  public boolean B;
  
  public final Context i;
  
  public final e j;
  
  public final d k;
  
  public final boolean l;
  
  public final int m;
  
  public final int n;
  
  public final int o;
  
  public final n0 p;
  
  public final ViewTreeObserver.OnGlobalLayoutListener q = new a(this);
  
  public final View.OnAttachStateChangeListener r = new b(this);
  
  public PopupWindow.OnDismissListener s;
  
  public View t;
  
  public View u;
  
  public i.a v;
  
  public ViewTreeObserver w;
  
  public boolean x;
  
  public boolean y;
  
  public int z;
  
  public k(Context paramContext, e parame, View paramView, int paramInt1, int paramInt2, boolean paramBoolean) {
    this.i = paramContext;
    this.j = parame;
    this.l = paramBoolean;
    this.k = new d(parame, LayoutInflater.from(paramContext), paramBoolean, 2131558419);
    this.n = paramInt1;
    this.o = paramInt2;
    Resources resources = paramContext.getResources();
    this.m = Math.max((resources.getDisplayMetrics()).widthPixels / 2, resources.getDimensionPixelSize(2131165925));
    this.t = paramView;
    this.p = new n0(paramContext, null, paramInt1, paramInt2);
    parame.b((i)this, paramContext);
  }
  
  public void a(e parame, boolean paramBoolean) {
    if (parame != this.j)
      return; 
    dismiss();
    i.a a1 = this.v;
    if (a1 != null)
      a1.a(parame, paramBoolean); 
  }
  
  public boolean b() {
    return (!this.x && this.p.b());
  }
  
  public void d() {
    boolean bool = b();
    boolean bool2 = false;
    if (!bool) {
      boolean bool3 = bool2;
      if (!this.x) {
        View view = this.t;
        if (view == null) {
          bool3 = bool2;
        } else {
          this.u = view;
          ((l0)this.p).F.setOnDismissListener(this);
          n0 n01 = this.p;
          ((l0)n01).w = (AdapterView.OnItemClickListener)this;
          n01.s(true);
          View view1 = this.u;
          if (this.w == null) {
            bool3 = true;
          } else {
            bool3 = false;
          } 
          ViewTreeObserver viewTreeObserver = view1.getViewTreeObserver();
          this.w = viewTreeObserver;
          if (bool3)
            viewTreeObserver.addOnGlobalLayoutListener(this.q); 
          view1.addOnAttachStateChangeListener(this.r);
          n0 n02 = this.p;
          ((l0)n02).v = view1;
          ((l0)n02).s = this.A;
          if (!this.y) {
            this.z = d.m((ListAdapter)this.k, null, this.i, this.m);
            this.y = true;
          } 
          this.p.r(this.z);
          ((l0)this.p).F.setInputMethodMode(2);
          n02 = this.p;
          Rect rect = this.h;
          Objects.requireNonNull(n02);
          if (rect != null) {
            rect = new Rect(rect);
          } else {
            rect = null;
          } 
          ((l0)n02).D = rect;
          this.p.d();
          g0 g0 = ((l0)this.p).j;
          g0.setOnKeyListener(this);
          if (this.B && this.j.m != null) {
            FrameLayout frameLayout = (FrameLayout)LayoutInflater.from(this.i).inflate(2131558418, (ViewGroup)g0, false);
            TextView textView = (TextView)frameLayout.findViewById(16908310);
            if (textView != null)
              textView.setText(this.j.m); 
            frameLayout.setEnabled(false);
            g0.addHeaderView((View)frameLayout, null, false);
          } 
          this.p.p((ListAdapter)this.k);
          this.p.d();
          bool3 = true;
        } 
      } 
      if (bool3)
        return; 
      throw new IllegalStateException("StandardMenuPopup cannot be used without an anchor");
    } 
    boolean bool1 = true;
  }
  
  public void dismiss() {
    if (b())
      this.p.dismiss(); 
  }
  
  public boolean e(l paraml) {
    // Byte code:
    //   0: aload_1
    //   1: invokevirtual hasVisibleItems : ()Z
    //   4: ifeq -> 241
    //   7: new androidx/appcompat/view/menu/h
    //   10: dup
    //   11: aload_0
    //   12: getfield i : Landroid/content/Context;
    //   15: aload_1
    //   16: aload_0
    //   17: getfield u : Landroid/view/View;
    //   20: aload_0
    //   21: getfield l : Z
    //   24: aload_0
    //   25: getfield n : I
    //   28: aload_0
    //   29: getfield o : I
    //   32: invokespecial <init> : (Landroid/content/Context;Landroidx/appcompat/view/menu/e;Landroid/view/View;ZII)V
    //   35: astore #7
    //   37: aload #7
    //   39: aload_0
    //   40: getfield v : Landroidx/appcompat/view/menu/i$a;
    //   43: invokevirtual d : (Landroidx/appcompat/view/menu/i$a;)V
    //   46: aload_1
    //   47: invokestatic u : (Landroidx/appcompat/view/menu/e;)Z
    //   50: istore #6
    //   52: aload #7
    //   54: iload #6
    //   56: putfield h : Z
    //   59: aload #7
    //   61: getfield j : Lk/d;
    //   64: astore #8
    //   66: aload #8
    //   68: ifnull -> 78
    //   71: aload #8
    //   73: iload #6
    //   75: invokevirtual o : (Z)V
    //   78: aload #7
    //   80: aload_0
    //   81: getfield s : Landroid/widget/PopupWindow$OnDismissListener;
    //   84: putfield k : Landroid/widget/PopupWindow$OnDismissListener;
    //   87: aload_0
    //   88: aconst_null
    //   89: putfield s : Landroid/widget/PopupWindow$OnDismissListener;
    //   92: aload_0
    //   93: getfield j : Landroidx/appcompat/view/menu/e;
    //   96: iconst_0
    //   97: invokevirtual c : (Z)V
    //   100: aload_0
    //   101: getfield p : Landroidx/appcompat/widget/n0;
    //   104: astore #8
    //   106: aload #8
    //   108: getfield m : I
    //   111: istore #4
    //   113: aload #8
    //   115: getfield p : Z
    //   118: ifne -> 126
    //   121: iconst_0
    //   122: istore_2
    //   123: goto -> 132
    //   126: aload #8
    //   128: getfield n : I
    //   131: istore_2
    //   132: aload_0
    //   133: getfield A : I
    //   136: istore #5
    //   138: aload_0
    //   139: getfield t : Landroid/view/View;
    //   142: astore #8
    //   144: getstatic k0/l.a : Ljava/util/WeakHashMap;
    //   147: astore #9
    //   149: iload #4
    //   151: istore_3
    //   152: iload #5
    //   154: aload #8
    //   156: invokevirtual getLayoutDirection : ()I
    //   159: invokestatic getAbsoluteGravity : (II)I
    //   162: bipush #7
    //   164: iand
    //   165: iconst_5
    //   166: if_icmpne -> 180
    //   169: iload #4
    //   171: aload_0
    //   172: getfield t : Landroid/view/View;
    //   175: invokevirtual getWidth : ()I
    //   178: iadd
    //   179: istore_3
    //   180: aload #7
    //   182: invokevirtual b : ()Z
    //   185: ifeq -> 191
    //   188: goto -> 213
    //   191: aload #7
    //   193: getfield f : Landroid/view/View;
    //   196: ifnonnull -> 204
    //   199: iconst_0
    //   200: istore_2
    //   201: goto -> 215
    //   204: aload #7
    //   206: iload_3
    //   207: iload_2
    //   208: iconst_1
    //   209: iconst_1
    //   210: invokevirtual e : (IIZZ)V
    //   213: iconst_1
    //   214: istore_2
    //   215: iload_2
    //   216: ifeq -> 241
    //   219: aload_0
    //   220: getfield v : Landroidx/appcompat/view/menu/i$a;
    //   223: astore #7
    //   225: aload #7
    //   227: ifnull -> 239
    //   230: aload #7
    //   232: aload_1
    //   233: invokeinterface b : (Landroidx/appcompat/view/menu/e;)Z
    //   238: pop
    //   239: iconst_1
    //   240: ireturn
    //   241: iconst_0
    //   242: ireturn
  }
  
  public void f(boolean paramBoolean) {
    this.y = false;
    d d1 = this.k;
    if (d1 != null)
      d1.notifyDataSetChanged(); 
  }
  
  public ListView g() {
    return (ListView)((l0)this.p).j;
  }
  
  public boolean h() {
    return false;
  }
  
  public void k(i.a parama) {
    this.v = parama;
  }
  
  public void l(e parame) {}
  
  public void n(View paramView) {
    this.t = paramView;
  }
  
  public void o(boolean paramBoolean) {
    this.k.j = paramBoolean;
  }
  
  public void onDismiss() {
    this.x = true;
    this.j.c(true);
    ViewTreeObserver viewTreeObserver = this.w;
    if (viewTreeObserver != null) {
      if (!viewTreeObserver.isAlive())
        this.w = this.u.getViewTreeObserver(); 
      this.w.removeGlobalOnLayoutListener(this.q);
      this.w = null;
    } 
    this.u.removeOnAttachStateChangeListener(this.r);
    PopupWindow.OnDismissListener onDismissListener = this.s;
    if (onDismissListener != null)
      onDismissListener.onDismiss(); 
  }
  
  public boolean onKey(View paramView, int paramInt, KeyEvent paramKeyEvent) {
    if (paramKeyEvent.getAction() == 1 && paramInt == 82) {
      dismiss();
      return true;
    } 
    return false;
  }
  
  public void p(int paramInt) {
    this.A = paramInt;
  }
  
  public void q(int paramInt) {
    ((l0)this.p).m = paramInt;
  }
  
  public void r(PopupWindow.OnDismissListener paramOnDismissListener) {
    this.s = paramOnDismissListener;
  }
  
  public void s(boolean paramBoolean) {
    this.B = paramBoolean;
  }
  
  public void t(int paramInt) {
    n0 n01 = this.p;
    ((l0)n01).n = paramInt;
    ((l0)n01).p = true;
  }
  
  public class a implements ViewTreeObserver.OnGlobalLayoutListener {
    public a(k this$0) {}
    
    public void onGlobalLayout() {
      if (this.h.b()) {
        k k1 = this.h;
        if (!((l0)k1.p).E) {
          View view = k1.u;
          if (view == null || !view.isShown()) {
            this.h.dismiss();
            return;
          } 
          this.h.p.d();
          return;
        } 
      } 
    }
  }
  
  public class b implements View.OnAttachStateChangeListener {
    public b(k this$0) {}
    
    public void onViewAttachedToWindow(View param1View) {}
    
    public void onViewDetachedFromWindow(View param1View) {
      ViewTreeObserver viewTreeObserver = this.h.w;
      if (viewTreeObserver != null) {
        if (!viewTreeObserver.isAlive())
          this.h.w = param1View.getViewTreeObserver(); 
        k k1 = this.h;
        k1.w.removeGlobalOnLayoutListener(k1.q);
      } 
      param1View.removeOnAttachStateChangeListener(this);
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Luxury Logo Maker_ Logo Design-dex2jar.jar!\androidx\appcompat\view\menu\k.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */