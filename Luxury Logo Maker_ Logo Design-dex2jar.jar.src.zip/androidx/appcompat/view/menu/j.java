package androidx.appcompat.view.menu;

public interface j {
  void b(e parame);
  
  public static interface a {
    void f(g param1g, int param1Int);
    
    g getItemData();
  }
}


/* Location:              C:\soft\dex2jar-2.0\Luxury Logo Maker_ Logo Design-dex2jar.jar!\androidx\appcompat\view\menu\j.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */