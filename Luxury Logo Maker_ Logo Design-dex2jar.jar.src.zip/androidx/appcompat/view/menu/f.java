package androidx.appcompat.view.menu;

import android.content.DialogInterface;
import android.view.KeyEvent;
import android.view.MenuItem;
import android.view.View;
import android.view.Window;
import androidx.appcompat.app.b;

public class f implements DialogInterface.OnKeyListener, DialogInterface.OnClickListener, DialogInterface.OnDismissListener, i.a {
  public e h;
  
  public b i;
  
  public c j;
  
  public f(e parame) {
    this.h = parame;
  }
  
  public void a(e parame, boolean paramBoolean) {
    if (paramBoolean || parame == this.h) {
      b b1 = this.i;
      if (b1 != null)
        b1.dismiss(); 
    } 
  }
  
  public boolean b(e parame) {
    return false;
  }
  
  public void onClick(DialogInterface paramDialogInterface, int paramInt) {
    this.h.q((MenuItem)((c.a)this.j.b()).b(paramInt), 0);
  }
  
  public void onDismiss(DialogInterface paramDialogInterface) {
    c c1 = this.j;
    e e1 = this.h;
    i.a a1 = c1.l;
    if (a1 != null)
      a1.a(e1, true); 
  }
  
  public boolean onKey(DialogInterface paramDialogInterface, int paramInt, KeyEvent paramKeyEvent) {
    if (paramInt == 82 || paramInt == 4) {
      KeyEvent.DispatcherState dispatcherState;
      if (paramKeyEvent.getAction() == 0 && paramKeyEvent.getRepeatCount() == 0) {
        Window window = this.i.getWindow();
        if (window != null) {
          View view = window.getDecorView();
          if (view != null) {
            dispatcherState = view.getKeyDispatcherState();
            if (dispatcherState != null) {
              dispatcherState.startTracking(paramKeyEvent, this);
              return true;
            } 
          } 
        } 
      } else if (paramKeyEvent.getAction() == 1 && !paramKeyEvent.isCanceled()) {
        Window window = this.i.getWindow();
        if (window != null) {
          View view = window.getDecorView();
          if (view != null) {
            KeyEvent.DispatcherState dispatcherState1 = view.getKeyDispatcherState();
            if (dispatcherState1 != null && dispatcherState1.isTracking(paramKeyEvent)) {
              this.h.c(true);
              dispatcherState.dismiss();
              return true;
            } 
          } 
        } 
      } 
    } 
    return this.h.performShortcut(paramInt, paramKeyEvent, 0);
  }
}


/* Location:              C:\soft\dex2jar-2.0\Luxury Logo Maker_ Logo Design-dex2jar.jar!\androidx\appcompat\view\menu\f.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */