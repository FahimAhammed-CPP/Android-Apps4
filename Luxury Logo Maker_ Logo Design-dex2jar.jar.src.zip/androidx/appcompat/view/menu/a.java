package androidx.appcompat.view.menu;

import android.content.Context;
import android.view.LayoutInflater;

public abstract class a implements i {
  public Context h;
  
  public Context i;
  
  public e j;
  
  public LayoutInflater k;
  
  public i.a l;
  
  public int m;
  
  public int n;
  
  public j o;
  
  public a(Context paramContext, int paramInt1, int paramInt2) {
    this.h = paramContext;
    this.k = LayoutInflater.from(paramContext);
    this.m = paramInt1;
    this.n = paramInt2;
  }
  
  public boolean i(e parame, g paramg) {
    return false;
  }
  
  public boolean j(e parame, g paramg) {
    return false;
  }
  
  public void k(i.a parama) {
    this.l = parama;
  }
}


/* Location:              C:\soft\dex2jar-2.0\Luxury Logo Maker_ Logo Design-dex2jar.jar!\androidx\appcompat\view\menu\a.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */