package androidx.appcompat.widget;

import android.annotation.SuppressLint;
import android.content.Context;
import android.content.res.ColorStateList;
import android.graphics.PorterDuff;
import android.graphics.drawable.Drawable;
import android.util.AttributeSet;
import android.view.ActionMode;
import android.view.View;
import android.view.accessibility.AccessibilityEvent;
import android.view.accessibility.AccessibilityNodeInfo;
import android.widget.Button;
import android.widget.TextView;
import m0.b;
import m0.g;

public class f extends Button implements b, g {
  public final e h;
  
  public final z i;
  
  public f(Context paramContext, AttributeSet paramAttributeSet) {
    this(paramContext, paramAttributeSet, 2130968697);
  }
  
  public f(Context paramContext, AttributeSet paramAttributeSet, int paramInt) {
    super(paramContext, paramAttributeSet, paramInt);
    u0.a((View)this, getContext());
    e e1 = new e((View)this);
    this.h = e1;
    e1.d(paramAttributeSet, paramInt);
    z z1 = new z((TextView)this);
    this.i = z1;
    z1.e(paramAttributeSet, paramInt);
    z1.b();
  }
  
  public void drawableStateChanged() {
    super.drawableStateChanged();
    e e1 = this.h;
    if (e1 != null)
      e1.a(); 
    z z1 = this.i;
    if (z1 != null)
      z1.b(); 
  }
  
  public int getAutoSizeMaxTextSize() {
    if (b.g)
      return super.getAutoSizeMaxTextSize(); 
    z z1 = this.i;
    return (z1 != null) ? Math.round(z1.i.e) : -1;
  }
  
  public int getAutoSizeMinTextSize() {
    if (b.g)
      return super.getAutoSizeMinTextSize(); 
    z z1 = this.i;
    return (z1 != null) ? Math.round(z1.i.d) : -1;
  }
  
  public int getAutoSizeStepGranularity() {
    if (b.g)
      return super.getAutoSizeStepGranularity(); 
    z z1 = this.i;
    return (z1 != null) ? Math.round(z1.i.c) : -1;
  }
  
  public int[] getAutoSizeTextAvailableSizes() {
    if (b.g)
      return super.getAutoSizeTextAvailableSizes(); 
    z z1 = this.i;
    return (z1 != null) ? z1.i.f : new int[0];
  }
  
  @SuppressLint({"WrongConstant"})
  public int getAutoSizeTextType() {
    boolean bool1 = b.g;
    boolean bool = false;
    if (bool1) {
      if (super.getAutoSizeTextType() == 1)
        bool = true; 
      return bool;
    } 
    z z1 = this.i;
    return (z1 != null) ? z1.i.a : 0;
  }
  
  public ColorStateList getSupportBackgroundTintList() {
    e e1 = this.h;
    return (e1 != null) ? e1.b() : null;
  }
  
  public PorterDuff.Mode getSupportBackgroundTintMode() {
    e e1 = this.h;
    return (e1 != null) ? e1.c() : null;
  }
  
  public ColorStateList getSupportCompoundDrawablesTintList() {
    x0 x0 = this.i.h;
    return (x0 != null) ? x0.a : null;
  }
  
  public PorterDuff.Mode getSupportCompoundDrawablesTintMode() {
    x0 x0 = this.i.h;
    return (x0 != null) ? x0.b : null;
  }
  
  public void onInitializeAccessibilityEvent(AccessibilityEvent paramAccessibilityEvent) {
    super.onInitializeAccessibilityEvent(paramAccessibilityEvent);
    paramAccessibilityEvent.setClassName(Button.class.getName());
  }
  
  public void onInitializeAccessibilityNodeInfo(AccessibilityNodeInfo paramAccessibilityNodeInfo) {
    super.onInitializeAccessibilityNodeInfo(paramAccessibilityNodeInfo);
    paramAccessibilityNodeInfo.setClassName(Button.class.getName());
  }
  
  public void onLayout(boolean paramBoolean, int paramInt1, int paramInt2, int paramInt3, int paramInt4) {
    super.onLayout(paramBoolean, paramInt1, paramInt2, paramInt3, paramInt4);
    z z1 = this.i;
    if (z1 != null && !b.g)
      z1.i.a(); 
  }
  
  public void onTextChanged(CharSequence paramCharSequence, int paramInt1, int paramInt2, int paramInt3) {
    super.onTextChanged(paramCharSequence, paramInt1, paramInt2, paramInt3);
    z z1 = this.i;
    if (z1 != null && !b.g && z1.d())
      this.i.i.a(); 
  }
  
  public void setAutoSizeTextTypeUniformWithConfiguration(int paramInt1, int paramInt2, int paramInt3, int paramInt4) {
    if (b.g) {
      super.setAutoSizeTextTypeUniformWithConfiguration(paramInt1, paramInt2, paramInt3, paramInt4);
      return;
    } 
    z z1 = this.i;
    if (z1 != null)
      z1.g(paramInt1, paramInt2, paramInt3, paramInt4); 
  }
  
  public void setAutoSizeTextTypeUniformWithPresetSizes(int[] paramArrayOfint, int paramInt) {
    if (b.g) {
      super.setAutoSizeTextTypeUniformWithPresetSizes(paramArrayOfint, paramInt);
      return;
    } 
    z z1 = this.i;
    if (z1 != null)
      z1.h(paramArrayOfint, paramInt); 
  }
  
  public void setAutoSizeTextTypeWithDefaults(int paramInt) {
    if (b.g) {
      super.setAutoSizeTextTypeWithDefaults(paramInt);
      return;
    } 
    z z1 = this.i;
    if (z1 != null)
      z1.i(paramInt); 
  }
  
  public void setBackgroundDrawable(Drawable paramDrawable) {
    super.setBackgroundDrawable(paramDrawable);
    e e1 = this.h;
    if (e1 != null)
      e1.e(); 
  }
  
  public void setBackgroundResource(int paramInt) {
    super.setBackgroundResource(paramInt);
    e e1 = this.h;
    if (e1 != null)
      e1.f(paramInt); 
  }
  
  public void setCustomSelectionActionModeCallback(ActionMode.Callback paramCallback) {
    super.setCustomSelectionActionModeCallback(m0.f.g((TextView)this, paramCallback));
  }
  
  public void setSupportAllCaps(boolean paramBoolean) {
    z z1 = this.i;
    if (z1 != null)
      z1.a.setAllCaps(paramBoolean); 
  }
  
  public void setSupportBackgroundTintList(ColorStateList paramColorStateList) {
    e e1 = this.h;
    if (e1 != null)
      e1.h(paramColorStateList); 
  }
  
  public void setSupportBackgroundTintMode(PorterDuff.Mode paramMode) {
    e e1 = this.h;
    if (e1 != null)
      e1.i(paramMode); 
  }
  
  public void setSupportCompoundDrawablesTintList(ColorStateList paramColorStateList) {
    this.i.j(paramColorStateList);
    this.i.b();
  }
  
  public void setSupportCompoundDrawablesTintMode(PorterDuff.Mode paramMode) {
    this.i.k(paramMode);
    this.i.b();
  }
  
  public void setTextAppearance(Context paramContext, int paramInt) {
    super.setTextAppearance(paramContext, paramInt);
    z z1 = this.i;
    if (z1 != null)
      z1.f(paramContext, paramInt); 
  }
  
  public void setTextSize(int paramInt, float paramFloat) {
    boolean bool = b.g;
    if (bool) {
      super.setTextSize(paramInt, paramFloat);
      return;
    } 
    z z1 = this.i;
    if (z1 != null && !bool && !z1.d())
      z1.i.f(paramInt, paramFloat); 
  }
}


/* Location:              C:\soft\dex2jar-2.0\Luxury Logo Maker_ Logo Design-dex2jar.jar!\androidx\appcompat\widget\f.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */