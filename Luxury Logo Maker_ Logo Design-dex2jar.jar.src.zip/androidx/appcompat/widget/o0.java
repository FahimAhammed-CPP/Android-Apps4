package androidx.appcompat.widget;

import android.content.Context;
import android.content.res.ColorStateList;
import android.content.res.Resources;
import android.content.res.XmlResourceParser;
import android.graphics.PorterDuff;
import android.graphics.PorterDuffColorFilter;
import android.graphics.drawable.Drawable;
import android.graphics.drawable.LayerDrawable;
import android.util.AttributeSet;
import android.util.Log;
import android.util.TypedValue;
import android.util.Xml;
import java.lang.ref.WeakReference;
import java.util.WeakHashMap;
import org.xmlpull.v1.XmlPullParser;
import org.xmlpull.v1.XmlPullParserException;
import r.g;
import r.h;

public final class o0 {
  public static final PorterDuff.Mode h = PorterDuff.Mode.SRC_IN;
  
  public static o0 i;
  
  public static final c j = new c(6);
  
  public WeakHashMap<Context, h<ColorStateList>> a;
  
  public g<String, d> b;
  
  public h<String> c;
  
  public final WeakHashMap<Context, r.d<WeakReference<Drawable.ConstantState>>> d = new WeakHashMap<Context, r.d<WeakReference<Drawable.ConstantState>>>(0);
  
  public TypedValue e;
  
  public boolean f;
  
  public e g;
  
  public static o0 d() {
    // Byte code:
    //   0: ldc androidx/appcompat/widget/o0
    //   2: monitorenter
    //   3: getstatic androidx/appcompat/widget/o0.i : Landroidx/appcompat/widget/o0;
    //   6: ifnonnull -> 68
    //   9: new androidx/appcompat/widget/o0
    //   12: dup
    //   13: invokespecial <init> : ()V
    //   16: astore_0
    //   17: aload_0
    //   18: putstatic androidx/appcompat/widget/o0.i : Landroidx/appcompat/widget/o0;
    //   21: getstatic android/os/Build$VERSION.SDK_INT : I
    //   24: bipush #24
    //   26: if_icmpge -> 68
    //   29: aload_0
    //   30: ldc 'vector'
    //   32: new androidx/appcompat/widget/o0$f
    //   35: dup
    //   36: invokespecial <init> : ()V
    //   39: invokevirtual a : (Ljava/lang/String;Landroidx/appcompat/widget/o0$d;)V
    //   42: aload_0
    //   43: ldc 'animated-vector'
    //   45: new androidx/appcompat/widget/o0$b
    //   48: dup
    //   49: invokespecial <init> : ()V
    //   52: invokevirtual a : (Ljava/lang/String;Landroidx/appcompat/widget/o0$d;)V
    //   55: aload_0
    //   56: ldc 'animated-selector'
    //   58: new androidx/appcompat/widget/o0$a
    //   61: dup
    //   62: invokespecial <init> : ()V
    //   65: invokevirtual a : (Ljava/lang/String;Landroidx/appcompat/widget/o0$d;)V
    //   68: getstatic androidx/appcompat/widget/o0.i : Landroidx/appcompat/widget/o0;
    //   71: astore_0
    //   72: ldc androidx/appcompat/widget/o0
    //   74: monitorexit
    //   75: aload_0
    //   76: areturn
    //   77: astore_0
    //   78: ldc androidx/appcompat/widget/o0
    //   80: monitorexit
    //   81: aload_0
    //   82: athrow
    // Exception table:
    //   from	to	target	type
    //   3	68	77	finally
    //   68	72	77	finally
  }
  
  public static PorterDuffColorFilter h(int paramInt, PorterDuff.Mode paramMode) {
    // Byte code:
    //   0: ldc androidx/appcompat/widget/o0
    //   2: monitorenter
    //   3: getstatic androidx/appcompat/widget/o0.j : Landroidx/appcompat/widget/o0$c;
    //   6: astore #5
    //   8: aload #5
    //   10: invokestatic requireNonNull : (Ljava/lang/Object;)Ljava/lang/Object;
    //   13: pop
    //   14: iload_0
    //   15: bipush #31
    //   17: iadd
    //   18: bipush #31
    //   20: imul
    //   21: istore_2
    //   22: aload #5
    //   24: aload_1
    //   25: invokevirtual hashCode : ()I
    //   28: iload_2
    //   29: iadd
    //   30: invokestatic valueOf : (I)Ljava/lang/Integer;
    //   33: invokevirtual a : (Ljava/lang/Object;)Ljava/lang/Object;
    //   36: checkcast android/graphics/PorterDuffColorFilter
    //   39: astore #4
    //   41: aload #4
    //   43: astore_3
    //   44: aload #4
    //   46: ifnonnull -> 84
    //   49: new android/graphics/PorterDuffColorFilter
    //   52: dup
    //   53: iload_0
    //   54: aload_1
    //   55: invokespecial <init> : (ILandroid/graphics/PorterDuff$Mode;)V
    //   58: astore_3
    //   59: aload #5
    //   61: invokestatic requireNonNull : (Ljava/lang/Object;)Ljava/lang/Object;
    //   64: pop
    //   65: aload #5
    //   67: aload_1
    //   68: invokevirtual hashCode : ()I
    //   71: iload_2
    //   72: iadd
    //   73: invokestatic valueOf : (I)Ljava/lang/Integer;
    //   76: aload_3
    //   77: invokevirtual b : (Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    //   80: checkcast android/graphics/PorterDuffColorFilter
    //   83: astore_1
    //   84: ldc androidx/appcompat/widget/o0
    //   86: monitorexit
    //   87: aload_3
    //   88: areturn
    //   89: astore_1
    //   90: ldc androidx/appcompat/widget/o0
    //   92: monitorexit
    //   93: aload_1
    //   94: athrow
    // Exception table:
    //   from	to	target	type
    //   3	14	89	finally
    //   22	41	89	finally
    //   49	84	89	finally
  }
  
  public final void a(String paramString, d paramd) {
    if (this.b == null)
      this.b = new g(); 
    this.b.put(paramString, paramd);
  }
  
  public final boolean b(Context paramContext, long paramLong, Drawable paramDrawable) {
    // Byte code:
    //   0: aload_0
    //   1: monitorenter
    //   2: aload #4
    //   4: invokevirtual getConstantState : ()Landroid/graphics/drawable/Drawable$ConstantState;
    //   7: astore #7
    //   9: aload #7
    //   11: ifnull -> 77
    //   14: aload_0
    //   15: getfield d : Ljava/util/WeakHashMap;
    //   18: aload_1
    //   19: invokevirtual get : (Ljava/lang/Object;)Ljava/lang/Object;
    //   22: checkcast r/d
    //   25: astore #6
    //   27: aload #6
    //   29: astore #4
    //   31: aload #6
    //   33: ifnonnull -> 56
    //   36: new r/d
    //   39: dup
    //   40: invokespecial <init> : ()V
    //   43: astore #4
    //   45: aload_0
    //   46: getfield d : Ljava/util/WeakHashMap;
    //   49: aload_1
    //   50: aload #4
    //   52: invokevirtual put : (Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    //   55: pop
    //   56: aload #4
    //   58: lload_2
    //   59: new java/lang/ref/WeakReference
    //   62: dup
    //   63: aload #7
    //   65: invokespecial <init> : (Ljava/lang/Object;)V
    //   68: invokevirtual g : (JLjava/lang/Object;)V
    //   71: iconst_1
    //   72: istore #5
    //   74: goto -> 80
    //   77: iconst_0
    //   78: istore #5
    //   80: aload_0
    //   81: monitorexit
    //   82: iload #5
    //   84: ireturn
    //   85: astore_1
    //   86: aload_0
    //   87: monitorexit
    //   88: aload_1
    //   89: athrow
    // Exception table:
    //   from	to	target	type
    //   2	9	85	finally
    //   14	27	85	finally
    //   36	56	85	finally
    //   56	71	85	finally
  }
  
  public final Drawable c(Context paramContext, int paramInt) {
    LayerDrawable layerDrawable;
    if (this.e == null)
      this.e = new TypedValue(); 
    TypedValue typedValue = this.e;
    paramContext.getResources().getValue(paramInt, typedValue, true);
    long l = typedValue.assetCookie << 32L | typedValue.data;
    Drawable drawable = e(paramContext, l);
    if (drawable != null)
      return drawable; 
    e e1 = this.g;
    drawable = null;
    if (e1 != null && paramInt == 2131230743)
      layerDrawable = new LayerDrawable(new Drawable[] { f(paramContext, 2131230742), f(paramContext, 2131230744) }); 
    if (layerDrawable != null) {
      layerDrawable.setChangingConfigurations(typedValue.changingConfigurations);
      b(paramContext, l, (Drawable)layerDrawable);
    } 
    return (Drawable)layerDrawable;
  }
  
  public final Drawable e(Context paramContext, long paramLong) {
    // Byte code:
    //   0: aload_0
    //   1: monitorenter
    //   2: aload_0
    //   3: getfield d : Ljava/util/WeakHashMap;
    //   6: aload_1
    //   7: invokevirtual get : (Ljava/lang/Object;)Ljava/lang/Object;
    //   10: checkcast r/d
    //   13: astore #5
    //   15: aload #5
    //   17: ifnonnull -> 24
    //   20: aload_0
    //   21: monitorexit
    //   22: aconst_null
    //   23: areturn
    //   24: aload #5
    //   26: lload_2
    //   27: aconst_null
    //   28: invokevirtual f : (JLjava/lang/Object;)Ljava/lang/Object;
    //   31: checkcast java/lang/ref/WeakReference
    //   34: astore #6
    //   36: aload #6
    //   38: ifnull -> 127
    //   41: aload #6
    //   43: invokevirtual get : ()Ljava/lang/Object;
    //   46: checkcast android/graphics/drawable/Drawable$ConstantState
    //   49: astore #6
    //   51: aload #6
    //   53: ifnull -> 70
    //   56: aload #6
    //   58: aload_1
    //   59: invokevirtual getResources : ()Landroid/content/res/Resources;
    //   62: invokevirtual newDrawable : (Landroid/content/res/Resources;)Landroid/graphics/drawable/Drawable;
    //   65: astore_1
    //   66: aload_0
    //   67: monitorexit
    //   68: aload_1
    //   69: areturn
    //   70: aload #5
    //   72: getfield i : [J
    //   75: aload #5
    //   77: getfield k : I
    //   80: lload_2
    //   81: invokestatic c : ([JIJ)I
    //   84: istore #4
    //   86: iload #4
    //   88: iflt -> 127
    //   91: aload #5
    //   93: getfield j : [Ljava/lang/Object;
    //   96: astore_1
    //   97: aload_1
    //   98: iload #4
    //   100: aaload
    //   101: astore #6
    //   103: getstatic r/d.l : Ljava/lang/Object;
    //   106: astore #7
    //   108: aload #6
    //   110: aload #7
    //   112: if_acmpeq -> 127
    //   115: aload_1
    //   116: iload #4
    //   118: aload #7
    //   120: aastore
    //   121: aload #5
    //   123: iconst_1
    //   124: putfield h : Z
    //   127: aload_0
    //   128: monitorexit
    //   129: aconst_null
    //   130: areturn
    //   131: astore_1
    //   132: aload_0
    //   133: monitorexit
    //   134: aload_1
    //   135: athrow
    // Exception table:
    //   from	to	target	type
    //   2	15	131	finally
    //   24	36	131	finally
    //   41	51	131	finally
    //   56	66	131	finally
    //   70	86	131	finally
    //   91	97	131	finally
    //   103	108	131	finally
    //   121	127	131	finally
  }
  
  public Drawable f(Context paramContext, int paramInt) {
    // Byte code:
    //   0: aload_0
    //   1: monitorenter
    //   2: aload_0
    //   3: aload_1
    //   4: iload_2
    //   5: iconst_0
    //   6: invokevirtual g : (Landroid/content/Context;IZ)Landroid/graphics/drawable/Drawable;
    //   9: astore_1
    //   10: aload_0
    //   11: monitorexit
    //   12: aload_1
    //   13: areturn
    //   14: astore_1
    //   15: aload_0
    //   16: monitorexit
    //   17: aload_1
    //   18: athrow
    // Exception table:
    //   from	to	target	type
    //   2	10	14	finally
  }
  
  public Drawable g(Context paramContext, int paramInt, boolean paramBoolean) {
    // Byte code:
    //   0: aload_0
    //   1: monitorenter
    //   2: aload_0
    //   3: getfield f : Z
    //   6: ifeq -> 12
    //   9: goto -> 69
    //   12: iconst_1
    //   13: istore #5
    //   15: aload_0
    //   16: iconst_1
    //   17: putfield f : Z
    //   20: aload_0
    //   21: aload_1
    //   22: ldc 2131230812
    //   24: invokevirtual f : (Landroid/content/Context;I)Landroid/graphics/drawable/Drawable;
    //   27: astore #6
    //   29: aload #6
    //   31: ifnull -> 154
    //   34: iload #5
    //   36: istore #4
    //   38: aload #6
    //   40: instanceof f1/f
    //   43: ifne -> 177
    //   46: ldc 'android.graphics.drawable.VectorDrawable'
    //   48: aload #6
    //   50: invokevirtual getClass : ()Ljava/lang/Class;
    //   53: invokevirtual getName : ()Ljava/lang/String;
    //   56: invokevirtual equals : (Ljava/lang/Object;)Z
    //   59: ifeq -> 174
    //   62: iload #5
    //   64: istore #4
    //   66: goto -> 177
    //   69: aload_0
    //   70: aload_1
    //   71: iload_2
    //   72: invokevirtual j : (Landroid/content/Context;I)Landroid/graphics/drawable/Drawable;
    //   75: astore #7
    //   77: aload #7
    //   79: astore #6
    //   81: aload #7
    //   83: ifnonnull -> 94
    //   86: aload_0
    //   87: aload_1
    //   88: iload_2
    //   89: invokevirtual c : (Landroid/content/Context;I)Landroid/graphics/drawable/Drawable;
    //   92: astore #6
    //   94: aload #6
    //   96: astore #7
    //   98: aload #6
    //   100: ifnonnull -> 115
    //   103: getstatic b0/a.a : Ljava/lang/Object;
    //   106: astore #6
    //   108: aload_1
    //   109: iload_2
    //   110: invokestatic b : (Landroid/content/Context;I)Landroid/graphics/drawable/Drawable;
    //   113: astore #7
    //   115: aload #7
    //   117: astore #6
    //   119: aload #7
    //   121: ifnull -> 135
    //   124: aload_0
    //   125: aload_1
    //   126: iload_2
    //   127: iload_3
    //   128: aload #7
    //   130: invokevirtual k : (Landroid/content/Context;IZLandroid/graphics/drawable/Drawable;)Landroid/graphics/drawable/Drawable;
    //   133: astore #6
    //   135: aload #6
    //   137: ifnull -> 145
    //   140: aload #6
    //   142: invokestatic b : (Landroid/graphics/drawable/Drawable;)V
    //   145: aload_0
    //   146: monitorexit
    //   147: aload #6
    //   149: areturn
    //   150: astore_1
    //   151: goto -> 170
    //   154: aload_0
    //   155: iconst_0
    //   156: putfield f : Z
    //   159: new java/lang/IllegalStateException
    //   162: dup
    //   163: ldc_w 'This app has been built with an incorrect configuration. Please configure your build for VectorDrawableCompat.'
    //   166: invokespecial <init> : (Ljava/lang/String;)V
    //   169: athrow
    //   170: aload_0
    //   171: monitorexit
    //   172: aload_1
    //   173: athrow
    //   174: iconst_0
    //   175: istore #4
    //   177: iload #4
    //   179: ifeq -> 154
    //   182: goto -> 69
    // Exception table:
    //   from	to	target	type
    //   2	9	150	finally
    //   15	29	150	finally
    //   38	62	150	finally
    //   69	77	150	finally
    //   86	94	150	finally
    //   103	115	150	finally
    //   124	135	150	finally
    //   140	145	150	finally
    //   154	170	150	finally
  }
  
  public ColorStateList i(Context paramContext, int paramInt) {
    // Byte code:
    //   0: aload_0
    //   1: monitorenter
    //   2: aload_0
    //   3: getfield a : Ljava/util/WeakHashMap;
    //   6: astore_3
    //   7: aconst_null
    //   8: astore #5
    //   10: aload_3
    //   11: ifnull -> 162
    //   14: aload_3
    //   15: aload_1
    //   16: invokevirtual get : (Ljava/lang/Object;)Ljava/lang/Object;
    //   19: checkcast r/h
    //   22: astore_3
    //   23: aload_3
    //   24: ifnull -> 162
    //   27: aload_3
    //   28: iload_2
    //   29: aconst_null
    //   30: invokevirtual d : (ILjava/lang/Object;)Ljava/lang/Object;
    //   33: checkcast android/content/res/ColorStateList
    //   36: astore_3
    //   37: goto -> 40
    //   40: aload_3
    //   41: astore #4
    //   43: aload_3
    //   44: ifnonnull -> 153
    //   47: aload_0
    //   48: getfield g : Landroidx/appcompat/widget/o0$e;
    //   51: astore_3
    //   52: aload_3
    //   53: ifnonnull -> 62
    //   56: aload #5
    //   58: astore_3
    //   59: goto -> 72
    //   62: aload_3
    //   63: checkcast androidx/appcompat/widget/j$a
    //   66: aload_1
    //   67: iload_2
    //   68: invokevirtual c : (Landroid/content/Context;I)Landroid/content/res/ColorStateList;
    //   71: astore_3
    //   72: aload_3
    //   73: ifnull -> 143
    //   76: aload_0
    //   77: getfield a : Ljava/util/WeakHashMap;
    //   80: ifnonnull -> 94
    //   83: aload_0
    //   84: new java/util/WeakHashMap
    //   87: dup
    //   88: invokespecial <init> : ()V
    //   91: putfield a : Ljava/util/WeakHashMap;
    //   94: aload_0
    //   95: getfield a : Ljava/util/WeakHashMap;
    //   98: aload_1
    //   99: invokevirtual get : (Ljava/lang/Object;)Ljava/lang/Object;
    //   102: checkcast r/h
    //   105: astore #5
    //   107: aload #5
    //   109: astore #4
    //   111: aload #5
    //   113: ifnonnull -> 136
    //   116: new r/h
    //   119: dup
    //   120: invokespecial <init> : ()V
    //   123: astore #4
    //   125: aload_0
    //   126: getfield a : Ljava/util/WeakHashMap;
    //   129: aload_1
    //   130: aload #4
    //   132: invokevirtual put : (Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    //   135: pop
    //   136: aload #4
    //   138: iload_2
    //   139: aload_3
    //   140: invokevirtual a : (ILjava/lang/Object;)V
    //   143: aload_3
    //   144: astore #4
    //   146: goto -> 153
    //   149: astore_1
    //   150: goto -> 158
    //   153: aload_0
    //   154: monitorexit
    //   155: aload #4
    //   157: areturn
    //   158: aload_0
    //   159: monitorexit
    //   160: aload_1
    //   161: athrow
    //   162: aconst_null
    //   163: astore_3
    //   164: goto -> 40
    // Exception table:
    //   from	to	target	type
    //   2	7	149	finally
    //   14	23	149	finally
    //   27	37	149	finally
    //   47	52	149	finally
    //   62	72	149	finally
    //   76	94	149	finally
    //   94	107	149	finally
    //   116	136	149	finally
    //   136	143	149	finally
  }
  
  public final Drawable j(Context paramContext, int paramInt) {
    g<String, d> g1 = this.b;
    if (g1 != null && !g1.isEmpty()) {
      h<String> h1 = this.c;
      if (h1 != null) {
        String str = (String)h1.d(paramInt, null);
        if ("appcompat_skip_skip".equals(str) || (str != null && this.b.getOrDefault(str, null) == null))
          return null; 
      } else {
        this.c = new h();
      } 
      if (this.e == null)
        this.e = new TypedValue(); 
      TypedValue typedValue = this.e;
      Resources resources = paramContext.getResources();
      resources.getValue(paramInt, typedValue, true);
      long l = typedValue.assetCookie << 32L | typedValue.data;
      Drawable drawable1 = e(paramContext, l);
      if (drawable1 != null)
        return drawable1; 
      CharSequence charSequence = typedValue.string;
      Drawable drawable2 = drawable1;
      if (charSequence != null) {
        drawable2 = drawable1;
        if (charSequence.toString().endsWith(".xml")) {
          drawable2 = drawable1;
          try {
            int i;
            XmlResourceParser xmlResourceParser = resources.getXml(paramInt);
            drawable2 = drawable1;
            AttributeSet attributeSet = Xml.asAttributeSet((XmlPullParser)xmlResourceParser);
            while (true) {
              drawable2 = drawable1;
              i = xmlResourceParser.next();
              if (i != 2 && i != 1)
                continue; 
              break;
            } 
            if (i == 2) {
              drawable2 = drawable1;
              String str = xmlResourceParser.getName();
              drawable2 = drawable1;
              this.c.a(paramInt, str);
              drawable2 = drawable1;
              d d = (d)this.b.get(str);
              Drawable drawable = drawable1;
              if (d != null) {
                drawable2 = drawable1;
                drawable = d.a(paramContext, (XmlPullParser)xmlResourceParser, attributeSet, paramContext.getTheme());
              } 
              drawable2 = drawable;
              if (drawable != null) {
                drawable2 = drawable;
                drawable.setChangingConfigurations(typedValue.changingConfigurations);
                drawable2 = drawable;
                b(paramContext, l, drawable);
                drawable2 = drawable;
              } 
            } else {
              drawable2 = drawable1;
              throw new XmlPullParserException("No start tag found");
            } 
          } catch (Exception exception) {
            Log.e("ResourceManagerInternal", "Exception while inflating drawable", exception);
          } 
        } 
      } 
      if (drawable2 == null)
        this.c.a(paramInt, "appcompat_skip_skip"); 
      return drawable2;
    } 
    return null;
  }
  
  public final Drawable k(Context paramContext, int paramInt, boolean paramBoolean, Drawable paramDrawable) {
    PorterDuff.Mode mode;
    ColorStateList colorStateList = i(paramContext, paramInt);
    Drawable drawable = null;
    if (colorStateList != null) {
      Drawable drawable1 = paramDrawable;
      if (f0.a(paramDrawable))
        drawable1 = paramDrawable.mutate(); 
      paramDrawable = e0.a.g(drawable1);
      paramDrawable.setTintList(colorStateList);
      if (this.g == null) {
        drawable1 = drawable;
      } else {
        drawable1 = drawable;
        if (paramInt == 2131230796)
          mode = PorterDuff.Mode.MULTIPLY; 
      } 
      drawable = paramDrawable;
      if (mode != null) {
        paramDrawable.setTintMode(mode);
        return paramDrawable;
      } 
    } else {
      e e1 = this.g;
      if (e1 != null) {
        e1 = e1;
        boolean bool = true;
        if (paramInt == 2131230793) {
          LayerDrawable layerDrawable = (LayerDrawable)paramDrawable;
          Drawable drawable1 = layerDrawable.findDrawableByLayerId(16908288);
          int i = u0.c((Context)mode, 2130968768);
          PorterDuff.Mode mode1 = j.b;
          e1.d(drawable1, i, mode1);
          e1.d(layerDrawable.findDrawableByLayerId(16908303), u0.c((Context)mode, 2130968768), mode1);
          e1.d(layerDrawable.findDrawableByLayerId(16908301), u0.c((Context)mode, 2130968766), mode1);
        } else if (paramInt == 2131230784 || paramInt == 2131230783 || paramInt == 2131230785) {
          LayerDrawable layerDrawable = (LayerDrawable)paramDrawable;
          Drawable drawable1 = layerDrawable.findDrawableByLayerId(16908288);
          int i = u0.b((Context)mode, 2130968768);
          PorterDuff.Mode mode1 = j.b;
          e1.d(drawable1, i, mode1);
          e1.d(layerDrawable.findDrawableByLayerId(16908303), u0.c((Context)mode, 2130968766), mode1);
          e1.d(layerDrawable.findDrawableByLayerId(16908301), u0.c((Context)mode, 2130968766), mode1);
        } else {
          bool = false;
        } 
        if (bool)
          return paramDrawable; 
      } 
      drawable = paramDrawable;
      if (!l((Context)mode, paramInt, paramDrawable)) {
        drawable = paramDrawable;
        if (paramBoolean)
          drawable = null; 
      } 
    } 
    return drawable;
  }
  
  public boolean l(Context paramContext, int paramInt, Drawable paramDrawable) {
    // Byte code:
    //   0: aload_0
    //   1: getfield g : Landroidx/appcompat/widget/o0$e;
    //   4: astore #7
    //   6: aload #7
    //   8: ifnull -> 216
    //   11: aload #7
    //   13: checkcast androidx/appcompat/widget/j$a
    //   16: astore #8
    //   18: aload #8
    //   20: invokestatic requireNonNull : (Ljava/lang/Object;)Ljava/lang/Object;
    //   23: pop
    //   24: getstatic androidx/appcompat/widget/j.b : Landroid/graphics/PorterDuff$Mode;
    //   27: astore #7
    //   29: aload #8
    //   31: aload #8
    //   33: getfield a : [I
    //   36: iload_2
    //   37: invokevirtual a : ([II)Z
    //   40: istore #6
    //   42: ldc_w 16842801
    //   45: istore #4
    //   47: iload #6
    //   49: ifeq -> 59
    //   52: ldc_w 2130968768
    //   55: istore_2
    //   56: goto -> 137
    //   59: aload #8
    //   61: aload #8
    //   63: getfield c : [I
    //   66: iload_2
    //   67: invokevirtual a : ([II)Z
    //   70: ifeq -> 80
    //   73: ldc_w 2130968766
    //   76: istore_2
    //   77: goto -> 137
    //   80: aload #8
    //   82: aload #8
    //   84: getfield d : [I
    //   87: iload_2
    //   88: invokevirtual a : ([II)Z
    //   91: ifeq -> 105
    //   94: getstatic android/graphics/PorterDuff$Mode.MULTIPLY : Landroid/graphics/PorterDuff$Mode;
    //   97: astore #7
    //   99: iload #4
    //   101: istore_2
    //   102: goto -> 137
    //   105: iload_2
    //   106: ldc_w 2131230770
    //   109: if_icmpne -> 127
    //   112: ldc_w 16842800
    //   115: istore_2
    //   116: ldc_w 40.8
    //   119: invokestatic round : (F)I
    //   122: istore #4
    //   124: goto -> 140
    //   127: iload_2
    //   128: ldc_w 2131230746
    //   131: if_icmpne -> 146
    //   134: iload #4
    //   136: istore_2
    //   137: iconst_m1
    //   138: istore #4
    //   140: iconst_1
    //   141: istore #5
    //   143: goto -> 154
    //   146: iconst_0
    //   147: istore_2
    //   148: iconst_m1
    //   149: istore #4
    //   151: iconst_0
    //   152: istore #5
    //   154: iload #5
    //   156: ifeq -> 208
    //   159: aload_3
    //   160: astore #8
    //   162: aload_3
    //   163: invokestatic a : (Landroid/graphics/drawable/Drawable;)Z
    //   166: ifeq -> 175
    //   169: aload_3
    //   170: invokevirtual mutate : ()Landroid/graphics/drawable/Drawable;
    //   173: astore #8
    //   175: aload #8
    //   177: aload_1
    //   178: iload_2
    //   179: invokestatic c : (Landroid/content/Context;I)I
    //   182: aload #7
    //   184: invokestatic c : (ILandroid/graphics/PorterDuff$Mode;)Landroid/graphics/PorterDuffColorFilter;
    //   187: invokevirtual setColorFilter : (Landroid/graphics/ColorFilter;)V
    //   190: iload #4
    //   192: iconst_m1
    //   193: if_icmpeq -> 203
    //   196: aload #8
    //   198: iload #4
    //   200: invokevirtual setAlpha : (I)V
    //   203: iconst_1
    //   204: istore_2
    //   205: goto -> 210
    //   208: iconst_0
    //   209: istore_2
    //   210: iload_2
    //   211: ifeq -> 216
    //   214: iconst_1
    //   215: ireturn
    //   216: iconst_0
    //   217: ireturn
  }
  
  public static class a implements d {
    public Drawable a(Context param1Context, XmlPullParser param1XmlPullParser, AttributeSet param1AttributeSet, Resources.Theme param1Theme) {
      try {
        return (Drawable)h.a.g(param1Context, param1Context.getResources(), param1XmlPullParser, param1AttributeSet, param1Theme);
      } catch (Exception exception) {
        Log.e("AsldcInflateDelegate", "Exception while inflating <animated-selector>", exception);
        return null;
      } 
    }
  }
  
  public static class b implements d {
    public Drawable a(Context param1Context, XmlPullParser param1XmlPullParser, AttributeSet param1AttributeSet, Resources.Theme param1Theme) {
      try {
        Resources resources = param1Context.getResources();
        f1.b b1 = new f1.b(param1Context, null, null);
        b1.inflate(resources, param1XmlPullParser, param1AttributeSet, param1Theme);
        return (Drawable)b1;
      } catch (Exception exception) {
        Log.e("AvdcInflateDelegate", "Exception while inflating <animated-vector>", exception);
        return null;
      } 
    }
  }
  
  public static class c extends r.e<Integer, PorterDuffColorFilter> {
    public c(int param1Int) {
      super(param1Int);
    }
  }
  
  public static interface d {
    Drawable a(Context param1Context, XmlPullParser param1XmlPullParser, AttributeSet param1AttributeSet, Resources.Theme param1Theme);
  }
  
  public static interface e {}
  
  public static class f implements d {
    public Drawable a(Context param1Context, XmlPullParser param1XmlPullParser, AttributeSet param1AttributeSet, Resources.Theme param1Theme) {
      try {
        return (Drawable)f1.f.a(param1Context.getResources(), param1XmlPullParser, param1AttributeSet, param1Theme);
      } catch (Exception exception) {
        Log.e("VdcInflateDelegate", "Exception while inflating <vector>", exception);
        return null;
      } 
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Luxury Logo Maker_ Logo Design-dex2jar.jar!\androidx\appcompat\widget\o0.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */