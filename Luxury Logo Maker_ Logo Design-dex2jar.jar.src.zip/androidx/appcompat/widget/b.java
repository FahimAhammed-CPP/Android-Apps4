package androidx.appcompat.widget;

import android.graphics.Canvas;
import android.graphics.ColorFilter;
import android.graphics.Outline;
import android.graphics.drawable.Drawable;

public class b extends Drawable {
  public final ActionBarContainer a;
  
  public b(ActionBarContainer paramActionBarContainer) {
    this.a = paramActionBarContainer;
  }
  
  public void draw(Canvas paramCanvas) {
    Drawable drawable;
    ActionBarContainer actionBarContainer = this.a;
    if (actionBarContainer.o) {
      drawable = actionBarContainer.n;
      if (drawable != null) {
        drawable.draw(paramCanvas);
        return;
      } 
    } else {
      drawable = ((ActionBarContainer)drawable).l;
      if (drawable != null)
        drawable.draw(paramCanvas); 
      ActionBarContainer actionBarContainer1 = this.a;
      Drawable drawable1 = actionBarContainer1.m;
      if (drawable1 != null && actionBarContainer1.p)
        drawable1.draw(paramCanvas); 
    } 
  }
  
  public int getOpacity() {
    return 0;
  }
  
  public void getOutline(Outline paramOutline) {
    Drawable drawable;
    ActionBarContainer actionBarContainer = this.a;
    if (actionBarContainer.o) {
      drawable = actionBarContainer.n;
      if (drawable != null) {
        drawable.getOutline(paramOutline);
        return;
      } 
    } else {
      drawable = ((ActionBarContainer)drawable).l;
      if (drawable != null) {
        drawable.getOutline(paramOutline);
        return;
      } 
    } 
  }
  
  public void setAlpha(int paramInt) {}
  
  public void setColorFilter(ColorFilter paramColorFilter) {}
}


/* Location:              C:\soft\dex2jar-2.0\Luxury Logo Maker_ Logo Design-dex2jar.jar!\androidx\appcompat\widget\b.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */