package androidx.appcompat.widget;

import android.content.Context;
import android.content.res.ColorStateList;
import android.graphics.Canvas;
import android.graphics.PorterDuff;
import android.graphics.drawable.Drawable;
import android.util.AttributeSet;
import android.view.View;
import android.widget.ProgressBar;
import android.widget.SeekBar;
import com.bumptech.glide.manager.b;
import e0.a;
import java.util.WeakHashMap;
import k0.l;

public class u extends q {
  public final SeekBar d;
  
  public Drawable e;
  
  public ColorStateList f = null;
  
  public PorterDuff.Mode g = null;
  
  public boolean h = false;
  
  public boolean i = false;
  
  public u(SeekBar paramSeekBar) {
    super((ProgressBar)paramSeekBar);
    this.d = paramSeekBar;
  }
  
  public void a(AttributeSet paramAttributeSet, int paramInt) {
    super.a(paramAttributeSet, paramInt);
    Context context = this.d.getContext();
    int[] arrayOfInt = b.n;
    z0 z0 = z0.q(context, paramAttributeSet, arrayOfInt, paramInt, 0);
    SeekBar seekBar = this.d;
    l.r((View)seekBar, seekBar.getContext(), arrayOfInt, paramAttributeSet, z0.b, paramInt, 0);
    Drawable drawable1 = z0.h(0);
    if (drawable1 != null)
      this.d.setThumb(drawable1); 
    drawable1 = z0.g(1);
    Drawable drawable2 = this.e;
    if (drawable2 != null)
      drawable2.setCallback(null); 
    this.e = drawable1;
    if (drawable1 != null) {
      drawable1.setCallback((Drawable.Callback)this.d);
      SeekBar seekBar1 = this.d;
      WeakHashMap weakHashMap = l.a;
      a.c(drawable1, seekBar1.getLayoutDirection());
      if (drawable1.isStateful())
        drawable1.setState(this.d.getDrawableState()); 
      c();
    } 
    this.d.invalidate();
    if (z0.o(3)) {
      this.g = f0.c(z0.j(3, -1), this.g);
      this.i = true;
    } 
    if (z0.o(2)) {
      this.f = z0.c(2);
      this.h = true;
    } 
    z0.b.recycle();
    c();
  }
  
  public final void c() {
    Drawable drawable = this.e;
    if (drawable != null && (this.h || this.i)) {
      drawable = a.g(drawable.mutate());
      this.e = drawable;
      if (this.h)
        drawable.setTintList(this.f); 
      if (this.i)
        this.e.setTintMode(this.g); 
      if (this.e.isStateful())
        this.e.setState(this.d.getDrawableState()); 
    } 
  }
  
  public void d(Canvas paramCanvas) {
    if (this.e != null) {
      int j = this.d.getMax();
      int i = 1;
      if (j > 1) {
        int k = this.e.getIntrinsicWidth();
        int m = this.e.getIntrinsicHeight();
        if (k >= 0) {
          k /= 2;
        } else {
          k = 1;
        } 
        if (m >= 0)
          i = m / 2; 
        this.e.setBounds(-k, -i, k, i);
        float f = (this.d.getWidth() - this.d.getPaddingLeft() - this.d.getPaddingRight()) / j;
        i = paramCanvas.save();
        paramCanvas.translate(this.d.getPaddingLeft(), (this.d.getHeight() / 2));
        for (k = 0; k <= j; k++) {
          this.e.draw(paramCanvas);
          paramCanvas.translate(f, 0.0F);
        } 
        paramCanvas.restoreToCount(i);
      } 
    } 
  }
}


/* Location:              C:\soft\dex2jar-2.0\Luxury Logo Maker_ Logo Design-dex2jar.jar!\androidx\appcompat\widge\\u.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */