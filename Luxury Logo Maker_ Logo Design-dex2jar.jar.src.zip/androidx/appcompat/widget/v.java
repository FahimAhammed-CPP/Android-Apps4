package androidx.appcompat.widget;

import android.annotation.SuppressLint;
import android.view.View;
import k.f;

public class v extends i0 {
  public v(w paramw, View paramView, w.d paramd) {
    super(paramView);
  }
  
  public f b() {
    return this.q;
  }
  
  @SuppressLint({"SyntheticAccessor"})
  public boolean c() {
    if (!this.r.getInternalPopup().b())
      this.r.b(); 
    return true;
  }
}


/* Location:              C:\soft\dex2jar-2.0\Luxury Logo Maker_ Logo Design-dex2jar.jar!\androidx\appcompat\widget\v.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */