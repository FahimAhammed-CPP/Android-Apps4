package androidx.appcompat.widget;

import android.content.Context;
import android.content.res.TypedArray;
import android.database.DataSetObserver;
import android.graphics.Rect;
import android.graphics.drawable.Drawable;
import android.os.Build;
import android.os.Handler;
import android.util.AttributeSet;
import android.util.Log;
import android.view.MotionEvent;
import android.view.View;
import android.widget.AbsListView;
import android.widget.AdapterView;
import android.widget.ListAdapter;
import android.widget.ListView;
import android.widget.PopupWindow;
import java.lang.reflect.Method;
import java.util.WeakHashMap;
import k.f;
import k0.l;

public class l0 implements f {
  public static Method G;
  
  public static Method H;
  
  public static Method I;
  
  public final a A = new a(this);
  
  public final Handler B;
  
  public final Rect C = new Rect();
  
  public Rect D;
  
  public boolean E;
  
  public PopupWindow F;
  
  public Context h;
  
  public ListAdapter i;
  
  public g0 j;
  
  public int k = -2;
  
  public int l = -2;
  
  public int m;
  
  public int n;
  
  public int o = 1002;
  
  public boolean p;
  
  public boolean q;
  
  public boolean r;
  
  public int s = 0;
  
  public int t = Integer.MAX_VALUE;
  
  public DataSetObserver u;
  
  public View v;
  
  public AdapterView.OnItemClickListener w;
  
  public final e x = new e(this);
  
  public final d y = new d(this);
  
  public final c z = new c(this);
  
  static {
    if (Build.VERSION.SDK_INT <= 28) {
      try {
        G = PopupWindow.class.getDeclaredMethod("setClipToScreenEnabled", new Class[] { boolean.class });
      } catch (NoSuchMethodException noSuchMethodException) {
        Log.i("ListPopupWindow", "Could not find method setClipToScreenEnabled() on PopupWindow. Oh well.");
      } 
      try {
        I = PopupWindow.class.getDeclaredMethod("setEpicenterBounds", new Class[] { Rect.class });
      } catch (NoSuchMethodException noSuchMethodException) {
        Log.i("ListPopupWindow", "Could not find method setEpicenterBounds(Rect) on PopupWindow. Oh well.");
      } 
    } 
    if (Build.VERSION.SDK_INT <= 23)
      try {
        H = PopupWindow.class.getDeclaredMethod("getMaxAvailableHeight", new Class[] { View.class, int.class, boolean.class });
        return;
      } catch (NoSuchMethodException noSuchMethodException) {
        Log.i("ListPopupWindow", "Could not find method getMaxAvailableHeight(View, int, boolean) on PopupWindow. Oh well.");
      }  
  }
  
  public l0(Context paramContext, AttributeSet paramAttributeSet, int paramInt1, int paramInt2) {
    this.h = paramContext;
    this.B = new Handler(paramContext.getMainLooper());
    TypedArray typedArray = paramContext.obtainStyledAttributes(paramAttributeSet, com.bumptech.glide.manager.b.v, paramInt1, paramInt2);
    this.m = typedArray.getDimensionPixelOffset(0, 0);
    int i = typedArray.getDimensionPixelOffset(1, 0);
    this.n = i;
    if (i != 0)
      this.p = true; 
    typedArray.recycle();
    p p = new p(paramContext, paramAttributeSet, paramInt1, paramInt2);
    this.F = p;
    p.setInputMethodMode(1);
  }
  
  public boolean b() {
    return this.F.isShowing();
  }
  
  public int c() {
    return this.m;
  }
  
  public void d() {
    // Byte code:
    //   0: aload_0
    //   1: getfield j : Landroidx/appcompat/widget/g0;
    //   4: ifnonnull -> 109
    //   7: aload_0
    //   8: aload_0
    //   9: getfield h : Landroid/content/Context;
    //   12: aload_0
    //   13: getfield E : Z
    //   16: iconst_1
    //   17: ixor
    //   18: invokevirtual q : (Landroid/content/Context;Z)Landroidx/appcompat/widget/g0;
    //   21: astore #7
    //   23: aload_0
    //   24: aload #7
    //   26: putfield j : Landroidx/appcompat/widget/g0;
    //   29: aload #7
    //   31: aload_0
    //   32: getfield i : Landroid/widget/ListAdapter;
    //   35: invokevirtual setAdapter : (Landroid/widget/ListAdapter;)V
    //   38: aload_0
    //   39: getfield j : Landroidx/appcompat/widget/g0;
    //   42: aload_0
    //   43: getfield w : Landroid/widget/AdapterView$OnItemClickListener;
    //   46: invokevirtual setOnItemClickListener : (Landroid/widget/AdapterView$OnItemClickListener;)V
    //   49: aload_0
    //   50: getfield j : Landroidx/appcompat/widget/g0;
    //   53: iconst_1
    //   54: invokevirtual setFocusable : (Z)V
    //   57: aload_0
    //   58: getfield j : Landroidx/appcompat/widget/g0;
    //   61: iconst_1
    //   62: invokevirtual setFocusableInTouchMode : (Z)V
    //   65: aload_0
    //   66: getfield j : Landroidx/appcompat/widget/g0;
    //   69: new androidx/appcompat/widget/k0
    //   72: dup
    //   73: aload_0
    //   74: invokespecial <init> : (Landroidx/appcompat/widget/l0;)V
    //   77: invokevirtual setOnItemSelectedListener : (Landroid/widget/AdapterView$OnItemSelectedListener;)V
    //   80: aload_0
    //   81: getfield j : Landroidx/appcompat/widget/g0;
    //   84: aload_0
    //   85: getfield z : Landroidx/appcompat/widget/l0$c;
    //   88: invokevirtual setOnScrollListener : (Landroid/widget/AbsListView$OnScrollListener;)V
    //   91: aload_0
    //   92: getfield j : Landroidx/appcompat/widget/g0;
    //   95: astore #7
    //   97: aload_0
    //   98: getfield F : Landroid/widget/PopupWindow;
    //   101: aload #7
    //   103: invokevirtual setContentView : (Landroid/view/View;)V
    //   106: goto -> 121
    //   109: aload_0
    //   110: getfield F : Landroid/widget/PopupWindow;
    //   113: invokevirtual getContentView : ()Landroid/view/View;
    //   116: checkcast android/view/ViewGroup
    //   119: astore #7
    //   121: aload_0
    //   122: getfield F : Landroid/widget/PopupWindow;
    //   125: invokevirtual getBackground : ()Landroid/graphics/drawable/Drawable;
    //   128: astore #7
    //   130: iconst_0
    //   131: istore #5
    //   133: aload #7
    //   135: ifnull -> 188
    //   138: aload #7
    //   140: aload_0
    //   141: getfield C : Landroid/graphics/Rect;
    //   144: invokevirtual getPadding : (Landroid/graphics/Rect;)Z
    //   147: pop
    //   148: aload_0
    //   149: getfield C : Landroid/graphics/Rect;
    //   152: astore #7
    //   154: aload #7
    //   156: getfield top : I
    //   159: istore_2
    //   160: aload #7
    //   162: getfield bottom : I
    //   165: iload_2
    //   166: iadd
    //   167: istore_1
    //   168: iload_1
    //   169: istore_3
    //   170: aload_0
    //   171: getfield p : Z
    //   174: ifne -> 197
    //   177: aload_0
    //   178: iload_2
    //   179: ineg
    //   180: putfield n : I
    //   183: iload_1
    //   184: istore_3
    //   185: goto -> 197
    //   188: aload_0
    //   189: getfield C : Landroid/graphics/Rect;
    //   192: invokevirtual setEmpty : ()V
    //   195: iconst_0
    //   196: istore_3
    //   197: aload_0
    //   198: getfield F : Landroid/widget/PopupWindow;
    //   201: invokevirtual getInputMethodMode : ()I
    //   204: iconst_2
    //   205: if_icmpne -> 214
    //   208: iconst_1
    //   209: istore #6
    //   211: goto -> 217
    //   214: iconst_0
    //   215: istore #6
    //   217: aload_0
    //   218: getfield v : Landroid/view/View;
    //   221: astore #7
    //   223: aload_0
    //   224: getfield n : I
    //   227: istore_2
    //   228: getstatic android/os/Build$VERSION.SDK_INT : I
    //   231: bipush #23
    //   233: if_icmpgt -> 312
    //   236: getstatic androidx/appcompat/widget/l0.H : Ljava/lang/reflect/Method;
    //   239: astore #8
    //   241: aload #8
    //   243: ifnull -> 298
    //   246: aload #8
    //   248: aload_0
    //   249: getfield F : Landroid/widget/PopupWindow;
    //   252: iconst_3
    //   253: anewarray java/lang/Object
    //   256: dup
    //   257: iconst_0
    //   258: aload #7
    //   260: aastore
    //   261: dup
    //   262: iconst_1
    //   263: iload_2
    //   264: invokestatic valueOf : (I)Ljava/lang/Integer;
    //   267: aastore
    //   268: dup
    //   269: iconst_2
    //   270: iload #6
    //   272: invokestatic valueOf : (Z)Ljava/lang/Boolean;
    //   275: aastore
    //   276: invokevirtual invoke : (Ljava/lang/Object;[Ljava/lang/Object;)Ljava/lang/Object;
    //   279: checkcast java/lang/Integer
    //   282: invokevirtual intValue : ()I
    //   285: istore_1
    //   286: goto -> 325
    //   289: ldc 'ListPopupWindow'
    //   291: ldc_w 'Could not call getMaxAvailableHeightMethod(View, int, boolean) on PopupWindow. Using the public version.'
    //   294: invokestatic i : (Ljava/lang/String;Ljava/lang/String;)I
    //   297: pop
    //   298: aload_0
    //   299: getfield F : Landroid/widget/PopupWindow;
    //   302: aload #7
    //   304: iload_2
    //   305: invokevirtual getMaxAvailableHeight : (Landroid/view/View;I)I
    //   308: istore_1
    //   309: goto -> 325
    //   312: aload_0
    //   313: getfield F : Landroid/widget/PopupWindow;
    //   316: aload #7
    //   318: iload_2
    //   319: iload #6
    //   321: invokevirtual getMaxAvailableHeight : (Landroid/view/View;IZ)I
    //   324: istore_1
    //   325: aload_0
    //   326: getfield k : I
    //   329: iconst_m1
    //   330: if_icmpne -> 340
    //   333: iload_1
    //   334: iload_3
    //   335: iadd
    //   336: istore_1
    //   337: goto -> 495
    //   340: aload_0
    //   341: getfield l : I
    //   344: istore_2
    //   345: iload_2
    //   346: bipush #-2
    //   348: if_icmpeq -> 401
    //   351: ldc_w 1073741824
    //   354: istore #4
    //   356: iload_2
    //   357: iconst_m1
    //   358: if_icmpeq -> 364
    //   361: goto -> 440
    //   364: aload_0
    //   365: getfield h : Landroid/content/Context;
    //   368: invokevirtual getResources : ()Landroid/content/res/Resources;
    //   371: invokevirtual getDisplayMetrics : ()Landroid/util/DisplayMetrics;
    //   374: getfield widthPixels : I
    //   377: istore_2
    //   378: aload_0
    //   379: getfield C : Landroid/graphics/Rect;
    //   382: astore #7
    //   384: iload_2
    //   385: aload #7
    //   387: getfield left : I
    //   390: aload #7
    //   392: getfield right : I
    //   395: iadd
    //   396: isub
    //   397: istore_2
    //   398: goto -> 440
    //   401: aload_0
    //   402: getfield h : Landroid/content/Context;
    //   405: invokevirtual getResources : ()Landroid/content/res/Resources;
    //   408: invokevirtual getDisplayMetrics : ()Landroid/util/DisplayMetrics;
    //   411: getfield widthPixels : I
    //   414: istore_2
    //   415: aload_0
    //   416: getfield C : Landroid/graphics/Rect;
    //   419: astore #7
    //   421: iload_2
    //   422: aload #7
    //   424: getfield left : I
    //   427: aload #7
    //   429: getfield right : I
    //   432: iadd
    //   433: isub
    //   434: istore_2
    //   435: ldc_w -2147483648
    //   438: istore #4
    //   440: iload_2
    //   441: iload #4
    //   443: invokestatic makeMeasureSpec : (II)I
    //   446: istore_2
    //   447: aload_0
    //   448: getfield j : Landroidx/appcompat/widget/g0;
    //   451: iload_2
    //   452: iload_1
    //   453: iconst_0
    //   454: isub
    //   455: iconst_m1
    //   456: invokevirtual a : (III)I
    //   459: istore_2
    //   460: iload_2
    //   461: ifle -> 489
    //   464: aload_0
    //   465: getfield j : Landroidx/appcompat/widget/g0;
    //   468: invokevirtual getPaddingTop : ()I
    //   471: istore_1
    //   472: aload_0
    //   473: getfield j : Landroidx/appcompat/widget/g0;
    //   476: invokevirtual getPaddingBottom : ()I
    //   479: iload_1
    //   480: iadd
    //   481: iload_3
    //   482: iadd
    //   483: iconst_0
    //   484: iadd
    //   485: istore_1
    //   486: goto -> 491
    //   489: iconst_0
    //   490: istore_1
    //   491: iload_2
    //   492: iload_1
    //   493: iadd
    //   494: istore_1
    //   495: aload_0
    //   496: getfield F : Landroid/widget/PopupWindow;
    //   499: invokevirtual getInputMethodMode : ()I
    //   502: iconst_2
    //   503: if_icmpne -> 511
    //   506: iconst_1
    //   507: istore_3
    //   508: goto -> 513
    //   511: iconst_0
    //   512: istore_3
    //   513: aload_0
    //   514: getfield F : Landroid/widget/PopupWindow;
    //   517: aload_0
    //   518: getfield o : I
    //   521: invokestatic b : (Landroid/widget/PopupWindow;I)V
    //   524: aload_0
    //   525: getfield F : Landroid/widget/PopupWindow;
    //   528: invokevirtual isShowing : ()Z
    //   531: ifeq -> 763
    //   534: aload_0
    //   535: getfield v : Landroid/view/View;
    //   538: astore #7
    //   540: getstatic k0/l.a : Ljava/util/WeakHashMap;
    //   543: astore #8
    //   545: aload #7
    //   547: invokevirtual isAttachedToWindow : ()Z
    //   550: ifne -> 554
    //   553: return
    //   554: aload_0
    //   555: getfield l : I
    //   558: istore #4
    //   560: iload #4
    //   562: iconst_m1
    //   563: if_icmpne -> 571
    //   566: iconst_m1
    //   567: istore_2
    //   568: goto -> 589
    //   571: iload #4
    //   573: istore_2
    //   574: iload #4
    //   576: bipush #-2
    //   578: if_icmpne -> 589
    //   581: aload_0
    //   582: getfield v : Landroid/view/View;
    //   585: invokevirtual getWidth : ()I
    //   588: istore_2
    //   589: aload_0
    //   590: getfield k : I
    //   593: istore #4
    //   595: iload #4
    //   597: iconst_m1
    //   598: if_icmpne -> 688
    //   601: iload_3
    //   602: ifeq -> 608
    //   605: goto -> 610
    //   608: iconst_m1
    //   609: istore_1
    //   610: iload_3
    //   611: ifeq -> 652
    //   614: aload_0
    //   615: getfield F : Landroid/widget/PopupWindow;
    //   618: astore #7
    //   620: aload_0
    //   621: getfield l : I
    //   624: iconst_m1
    //   625: if_icmpne -> 633
    //   628: iconst_m1
    //   629: istore_3
    //   630: goto -> 635
    //   633: iconst_0
    //   634: istore_3
    //   635: aload #7
    //   637: iload_3
    //   638: invokevirtual setWidth : (I)V
    //   641: aload_0
    //   642: getfield F : Landroid/widget/PopupWindow;
    //   645: iconst_0
    //   646: invokevirtual setHeight : (I)V
    //   649: goto -> 701
    //   652: aload_0
    //   653: getfield F : Landroid/widget/PopupWindow;
    //   656: astore #7
    //   658: iload #5
    //   660: istore_3
    //   661: aload_0
    //   662: getfield l : I
    //   665: iconst_m1
    //   666: if_icmpne -> 671
    //   669: iconst_m1
    //   670: istore_3
    //   671: aload #7
    //   673: iload_3
    //   674: invokevirtual setWidth : (I)V
    //   677: aload_0
    //   678: getfield F : Landroid/widget/PopupWindow;
    //   681: iconst_m1
    //   682: invokevirtual setHeight : (I)V
    //   685: goto -> 701
    //   688: iload #4
    //   690: bipush #-2
    //   692: if_icmpne -> 698
    //   695: goto -> 701
    //   698: iload #4
    //   700: istore_1
    //   701: aload_0
    //   702: getfield F : Landroid/widget/PopupWindow;
    //   705: iconst_1
    //   706: invokevirtual setOutsideTouchable : (Z)V
    //   709: aload_0
    //   710: getfield F : Landroid/widget/PopupWindow;
    //   713: astore #7
    //   715: aload_0
    //   716: getfield v : Landroid/view/View;
    //   719: astore #8
    //   721: aload_0
    //   722: getfield m : I
    //   725: istore_3
    //   726: aload_0
    //   727: getfield n : I
    //   730: istore #4
    //   732: iload_2
    //   733: ifge -> 741
    //   736: iconst_m1
    //   737: istore_2
    //   738: goto -> 741
    //   741: iload_1
    //   742: ifge -> 750
    //   745: iconst_m1
    //   746: istore_1
    //   747: goto -> 750
    //   750: aload #7
    //   752: aload #8
    //   754: iload_3
    //   755: iload #4
    //   757: iload_2
    //   758: iload_1
    //   759: invokevirtual update : (Landroid/view/View;IIII)V
    //   762: return
    //   763: aload_0
    //   764: getfield l : I
    //   767: istore_3
    //   768: iload_3
    //   769: iconst_m1
    //   770: if_icmpne -> 778
    //   773: iconst_m1
    //   774: istore_2
    //   775: goto -> 794
    //   778: iload_3
    //   779: istore_2
    //   780: iload_3
    //   781: bipush #-2
    //   783: if_icmpne -> 794
    //   786: aload_0
    //   787: getfield v : Landroid/view/View;
    //   790: invokevirtual getWidth : ()I
    //   793: istore_2
    //   794: aload_0
    //   795: getfield k : I
    //   798: istore_3
    //   799: iload_3
    //   800: iconst_m1
    //   801: if_icmpne -> 809
    //   804: iconst_m1
    //   805: istore_1
    //   806: goto -> 820
    //   809: iload_3
    //   810: bipush #-2
    //   812: if_icmpne -> 818
    //   815: goto -> 820
    //   818: iload_3
    //   819: istore_1
    //   820: aload_0
    //   821: getfield F : Landroid/widget/PopupWindow;
    //   824: iload_2
    //   825: invokevirtual setWidth : (I)V
    //   828: aload_0
    //   829: getfield F : Landroid/widget/PopupWindow;
    //   832: iload_1
    //   833: invokevirtual setHeight : (I)V
    //   836: getstatic android/os/Build$VERSION.SDK_INT : I
    //   839: bipush #28
    //   841: if_icmpgt -> 889
    //   844: getstatic androidx/appcompat/widget/l0.G : Ljava/lang/reflect/Method;
    //   847: astore #7
    //   849: aload #7
    //   851: ifnull -> 897
    //   854: aload #7
    //   856: aload_0
    //   857: getfield F : Landroid/widget/PopupWindow;
    //   860: iconst_1
    //   861: anewarray java/lang/Object
    //   864: dup
    //   865: iconst_0
    //   866: getstatic java/lang/Boolean.TRUE : Ljava/lang/Boolean;
    //   869: aastore
    //   870: invokevirtual invoke : (Ljava/lang/Object;[Ljava/lang/Object;)Ljava/lang/Object;
    //   873: pop
    //   874: goto -> 897
    //   877: ldc 'ListPopupWindow'
    //   879: ldc_w 'Could not call setClipToScreenEnabled() on PopupWindow. Oh well.'
    //   882: invokestatic i : (Ljava/lang/String;Ljava/lang/String;)I
    //   885: pop
    //   886: goto -> 897
    //   889: aload_0
    //   890: getfield F : Landroid/widget/PopupWindow;
    //   893: iconst_1
    //   894: invokevirtual setIsClippedToScreen : (Z)V
    //   897: aload_0
    //   898: getfield F : Landroid/widget/PopupWindow;
    //   901: iconst_1
    //   902: invokevirtual setOutsideTouchable : (Z)V
    //   905: aload_0
    //   906: getfield F : Landroid/widget/PopupWindow;
    //   909: aload_0
    //   910: getfield y : Landroidx/appcompat/widget/l0$d;
    //   913: invokevirtual setTouchInterceptor : (Landroid/view/View$OnTouchListener;)V
    //   916: aload_0
    //   917: getfield r : Z
    //   920: ifeq -> 934
    //   923: aload_0
    //   924: getfield F : Landroid/widget/PopupWindow;
    //   927: aload_0
    //   928: getfield q : Z
    //   931: invokestatic a : (Landroid/widget/PopupWindow;Z)V
    //   934: getstatic android/os/Build$VERSION.SDK_INT : I
    //   937: bipush #28
    //   939: if_icmpgt -> 992
    //   942: getstatic androidx/appcompat/widget/l0.I : Ljava/lang/reflect/Method;
    //   945: astore #7
    //   947: aload #7
    //   949: ifnull -> 1003
    //   952: aload #7
    //   954: aload_0
    //   955: getfield F : Landroid/widget/PopupWindow;
    //   958: iconst_1
    //   959: anewarray java/lang/Object
    //   962: dup
    //   963: iconst_0
    //   964: aload_0
    //   965: getfield D : Landroid/graphics/Rect;
    //   968: aastore
    //   969: invokevirtual invoke : (Ljava/lang/Object;[Ljava/lang/Object;)Ljava/lang/Object;
    //   972: pop
    //   973: goto -> 1003
    //   976: astore #7
    //   978: ldc 'ListPopupWindow'
    //   980: ldc_w 'Could not invoke setEpicenterBounds on PopupWindow'
    //   983: aload #7
    //   985: invokestatic e : (Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)I
    //   988: pop
    //   989: goto -> 1003
    //   992: aload_0
    //   993: getfield F : Landroid/widget/PopupWindow;
    //   996: aload_0
    //   997: getfield D : Landroid/graphics/Rect;
    //   1000: invokevirtual setEpicenterBounds : (Landroid/graphics/Rect;)V
    //   1003: aload_0
    //   1004: getfield F : Landroid/widget/PopupWindow;
    //   1007: aload_0
    //   1008: getfield v : Landroid/view/View;
    //   1011: aload_0
    //   1012: getfield m : I
    //   1015: aload_0
    //   1016: getfield n : I
    //   1019: aload_0
    //   1020: getfield s : I
    //   1023: invokevirtual showAsDropDown : (Landroid/view/View;III)V
    //   1026: aload_0
    //   1027: getfield j : Landroidx/appcompat/widget/g0;
    //   1030: iconst_m1
    //   1031: invokevirtual setSelection : (I)V
    //   1034: aload_0
    //   1035: getfield E : Z
    //   1038: ifeq -> 1051
    //   1041: aload_0
    //   1042: getfield j : Landroidx/appcompat/widget/g0;
    //   1045: invokevirtual isInTouchMode : ()Z
    //   1048: ifeq -> 1073
    //   1051: aload_0
    //   1052: getfield j : Landroidx/appcompat/widget/g0;
    //   1055: astore #7
    //   1057: aload #7
    //   1059: ifnull -> 1073
    //   1062: aload #7
    //   1064: iconst_1
    //   1065: invokevirtual setListSelectionHidden : (Z)V
    //   1068: aload #7
    //   1070: invokevirtual requestLayout : ()V
    //   1073: aload_0
    //   1074: getfield E : Z
    //   1077: ifne -> 1092
    //   1080: aload_0
    //   1081: getfield B : Landroid/os/Handler;
    //   1084: aload_0
    //   1085: getfield A : Landroidx/appcompat/widget/l0$a;
    //   1088: invokevirtual post : (Ljava/lang/Runnable;)Z
    //   1091: pop
    //   1092: return
    //   1093: astore #8
    //   1095: goto -> 289
    //   1098: astore #7
    //   1100: goto -> 877
    // Exception table:
    //   from	to	target	type
    //   246	286	1093	java/lang/Exception
    //   854	874	1098	java/lang/Exception
    //   952	973	976	java/lang/Exception
  }
  
  public void dismiss() {
    this.F.dismiss();
    this.F.setContentView(null);
    this.j = null;
    this.B.removeCallbacks(this.x);
  }
  
  public Drawable f() {
    return this.F.getBackground();
  }
  
  public ListView g() {
    return this.j;
  }
  
  public void i(Drawable paramDrawable) {
    this.F.setBackgroundDrawable(paramDrawable);
  }
  
  public void j(int paramInt) {
    this.n = paramInt;
    this.p = true;
  }
  
  public void l(int paramInt) {
    this.m = paramInt;
  }
  
  public int n() {
    return !this.p ? 0 : this.n;
  }
  
  public void p(ListAdapter paramListAdapter) {
    DataSetObserver dataSetObserver = this.u;
    if (dataSetObserver == null) {
      this.u = new b(this);
    } else {
      ListAdapter listAdapter = this.i;
      if (listAdapter != null)
        listAdapter.unregisterDataSetObserver(dataSetObserver); 
    } 
    this.i = paramListAdapter;
    if (paramListAdapter != null)
      paramListAdapter.registerDataSetObserver(this.u); 
    g0 g01 = this.j;
    if (g01 != null)
      g01.setAdapter(this.i); 
  }
  
  public g0 q(Context paramContext, boolean paramBoolean) {
    return new g0(paramContext, paramBoolean);
  }
  
  public void r(int paramInt) {
    Drawable drawable = this.F.getBackground();
    if (drawable != null) {
      drawable.getPadding(this.C);
      Rect rect = this.C;
      this.l = rect.left + rect.right + paramInt;
      return;
    } 
    this.l = paramInt;
  }
  
  public void s(boolean paramBoolean) {
    this.E = paramBoolean;
    this.F.setFocusable(paramBoolean);
  }
  
  public class a implements Runnable {
    public a(l0 this$0) {}
    
    public void run() {
      g0 g0 = this.h.j;
      if (g0 != null) {
        g0.setListSelectionHidden(true);
        g0.requestLayout();
      } 
    }
  }
  
  public class b extends DataSetObserver {
    public b(l0 this$0) {}
    
    public void onChanged() {
      if (this.a.b())
        this.a.d(); 
    }
    
    public void onInvalidated() {
      this.a.dismiss();
    }
  }
  
  public class c implements AbsListView.OnScrollListener {
    public c(l0 this$0) {}
    
    public void onScroll(AbsListView param1AbsListView, int param1Int1, int param1Int2, int param1Int3) {}
    
    public void onScrollStateChanged(AbsListView param1AbsListView, int param1Int) {
      boolean bool = true;
      if (param1Int == 1) {
        if (this.a.F.getInputMethodMode() == 2) {
          param1Int = bool;
        } else {
          param1Int = 0;
        } 
        if (param1Int == 0 && this.a.F.getContentView() != null) {
          l0 l01 = this.a;
          l01.B.removeCallbacks(l01.x);
          this.a.x.run();
        } 
      } 
    }
  }
  
  public class d implements View.OnTouchListener {
    public d(l0 this$0) {}
    
    public boolean onTouch(View param1View, MotionEvent param1MotionEvent) {
      int i = param1MotionEvent.getAction();
      int j = (int)param1MotionEvent.getX();
      int k = (int)param1MotionEvent.getY();
      if (i == 0) {
        PopupWindow popupWindow = this.h.F;
        if (popupWindow != null && popupWindow.isShowing() && j >= 0 && j < this.h.F.getWidth() && k >= 0 && k < this.h.F.getHeight()) {
          l0 l01 = this.h;
          l01.B.postDelayed(l01.x, 250L);
          return false;
        } 
      } 
      if (i == 1) {
        l0 l01 = this.h;
        l01.B.removeCallbacks(l01.x);
      } 
      return false;
    }
  }
  
  public class e implements Runnable {
    public e(l0 this$0) {}
    
    public void run() {
      g0 g0 = this.h.j;
      if (g0 != null) {
        WeakHashMap weakHashMap = l.a;
        if (g0.isAttachedToWindow() && this.h.j.getCount() > this.h.j.getChildCount()) {
          int i = this.h.j.getChildCount();
          l0 l01 = this.h;
          if (i <= l01.t) {
            l01.F.setInputMethodMode(2);
            this.h.d();
          } 
        } 
      } 
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Luxury Logo Maker_ Logo Design-dex2jar.jar!\androidx\appcompat\widget\l0.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */