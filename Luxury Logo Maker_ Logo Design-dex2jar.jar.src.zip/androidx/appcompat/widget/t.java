package androidx.appcompat.widget;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.drawable.Drawable;
import android.util.AttributeSet;
import android.view.View;
import android.widget.SeekBar;

public class t extends SeekBar {
  public final u h;
  
  public t(Context paramContext, AttributeSet paramAttributeSet) {
    super(paramContext, paramAttributeSet, 2130969281);
    u0.a((View)this, getContext());
    u u1 = new u(this);
    this.h = u1;
    u1.a(paramAttributeSet, 2130969281);
  }
  
  public void drawableStateChanged() {
    super.drawableStateChanged();
    u u1 = this.h;
    Drawable drawable = u1.e;
    if (drawable != null && drawable.isStateful() && drawable.setState(u1.d.getDrawableState()))
      u1.d.invalidateDrawable(drawable); 
  }
  
  public void jumpDrawablesToCurrentState() {
    super.jumpDrawablesToCurrentState();
    Drawable drawable = this.h.e;
    if (drawable != null)
      drawable.jumpToCurrentState(); 
  }
  
  public void onDraw(Canvas paramCanvas) {
    // Byte code:
    //   0: aload_0
    //   1: monitorenter
    //   2: aload_0
    //   3: aload_1
    //   4: invokespecial onDraw : (Landroid/graphics/Canvas;)V
    //   7: aload_0
    //   8: getfield h : Landroidx/appcompat/widget/u;
    //   11: aload_1
    //   12: invokevirtual d : (Landroid/graphics/Canvas;)V
    //   15: aload_0
    //   16: monitorexit
    //   17: return
    //   18: astore_1
    //   19: aload_0
    //   20: monitorexit
    //   21: aload_1
    //   22: athrow
    // Exception table:
    //   from	to	target	type
    //   2	15	18	finally
  }
}


/* Location:              C:\soft\dex2jar-2.0\Luxury Logo Maker_ Logo Design-dex2jar.jar!\androidx\appcompat\widget\t.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */