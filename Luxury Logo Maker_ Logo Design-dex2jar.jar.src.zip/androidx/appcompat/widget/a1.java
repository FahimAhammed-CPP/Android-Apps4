package androidx.appcompat.widget;

import android.view.MenuItem;
import android.view.View;
import android.view.Window;
import k.a;

public class a1 implements View.OnClickListener {
  public final a h;
  
  public a1(b1 paramb1) {
    this.h = new a(paramb1.a.getContext(), 0, 16908332, 0, paramb1.i);
  }
  
  public void onClick(View paramView) {
    b1 b11 = this.i;
    Window.Callback callback = b11.l;
    if (callback != null && b11.m)
      callback.onMenuItemSelected(0, (MenuItem)this.h); 
  }
}


/* Location:              C:\soft\dex2jar-2.0\Luxury Logo Maker_ Logo Design-dex2jar.jar!\androidx\appcompat\widget\a1.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */