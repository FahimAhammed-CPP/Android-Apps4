package androidx.appcompat.widget;

import android.annotation.SuppressLint;
import android.app.SearchableInfo;
import android.content.Context;
import android.content.pm.PackageManager;
import android.content.res.ColorStateList;
import android.content.res.Resources;
import android.database.Cursor;
import android.graphics.drawable.Drawable;
import android.net.Uri;
import android.os.Bundle;
import android.text.TextUtils;
import android.util.Log;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;
import java.io.FileNotFoundException;
import java.util.List;
import java.util.WeakHashMap;
import n0.c;

@SuppressLint({"RestrictedAPI"})
public class t0 extends c implements View.OnClickListener {
  public int A = -1;
  
  public int B = -1;
  
  public int C = -1;
  
  public int D = -1;
  
  public int E = -1;
  
  public final SearchView s;
  
  public final SearchableInfo t;
  
  public final Context u;
  
  public final WeakHashMap<String, Drawable.ConstantState> v;
  
  public final int w;
  
  public int x = 1;
  
  public ColorStateList y;
  
  public int z = -1;
  
  public t0(Context paramContext, SearchView paramSearchView, SearchableInfo paramSearchableInfo, WeakHashMap<String, Drawable.ConstantState> paramWeakHashMap) {
    super(paramContext, paramSearchView.getSuggestionRowLayout(), null, true);
    this.s = paramSearchView;
    this.t = paramSearchableInfo;
    this.w = paramSearchView.getSuggestionCommitIconResId();
    this.u = paramContext;
    this.v = paramWeakHashMap;
  }
  
  public static String r(Cursor paramCursor, int paramInt) {
    if (paramInt == -1)
      return null; 
    try {
      return paramCursor.getString(paramInt);
    } catch (Exception exception) {
      Log.e("SuggestionsAdapter", "unexpected error retrieving valid column from cursor, did the remote process die?", exception);
      return null;
    } 
  }
  
  public void a(View paramView, Context paramContext, Cursor paramCursor) {
    // Byte code:
    //   0: aload_1
    //   1: invokevirtual getTag : ()Ljava/lang/Object;
    //   4: checkcast androidx/appcompat/widget/t0$a
    //   7: astore #7
    //   9: aload_0
    //   10: getfield E : I
    //   13: istore #4
    //   15: iload #4
    //   17: iconst_m1
    //   18: if_icmpeq -> 34
    //   21: aload_3
    //   22: iload #4
    //   24: invokeinterface getInt : (I)I
    //   29: istore #4
    //   31: goto -> 37
    //   34: iconst_0
    //   35: istore #4
    //   37: aload #7
    //   39: getfield a : Landroid/widget/TextView;
    //   42: ifnull -> 88
    //   45: aload_3
    //   46: aload_0
    //   47: getfield z : I
    //   50: invokestatic r : (Landroid/database/Cursor;I)Ljava/lang/String;
    //   53: astore_1
    //   54: aload #7
    //   56: getfield a : Landroid/widget/TextView;
    //   59: astore_2
    //   60: aload_2
    //   61: aload_1
    //   62: invokevirtual setText : (Ljava/lang/CharSequence;)V
    //   65: aload_1
    //   66: invokestatic isEmpty : (Ljava/lang/CharSequence;)Z
    //   69: ifeq -> 79
    //   72: bipush #8
    //   74: istore #5
    //   76: goto -> 82
    //   79: iconst_0
    //   80: istore #5
    //   82: aload_2
    //   83: iload #5
    //   85: invokevirtual setVisibility : (I)V
    //   88: aload #7
    //   90: getfield b : Landroid/widget/TextView;
    //   93: ifnull -> 296
    //   96: aload_3
    //   97: aload_0
    //   98: getfield B : I
    //   101: invokestatic r : (Landroid/database/Cursor;I)Ljava/lang/String;
    //   104: astore_2
    //   105: aload_2
    //   106: ifnull -> 195
    //   109: aload_0
    //   110: getfield y : Landroid/content/res/ColorStateList;
    //   113: ifnonnull -> 157
    //   116: new android/util/TypedValue
    //   119: dup
    //   120: invokespecial <init> : ()V
    //   123: astore_1
    //   124: aload_0
    //   125: getfield k : Landroid/content/Context;
    //   128: invokevirtual getTheme : ()Landroid/content/res/Resources$Theme;
    //   131: ldc 2130969426
    //   133: aload_1
    //   134: iconst_1
    //   135: invokevirtual resolveAttribute : (ILandroid/util/TypedValue;Z)Z
    //   138: pop
    //   139: aload_0
    //   140: aload_0
    //   141: getfield k : Landroid/content/Context;
    //   144: invokevirtual getResources : ()Landroid/content/res/Resources;
    //   147: aload_1
    //   148: getfield resourceId : I
    //   151: invokevirtual getColorStateList : (I)Landroid/content/res/ColorStateList;
    //   154: putfield y : Landroid/content/res/ColorStateList;
    //   157: new android/text/SpannableString
    //   160: dup
    //   161: aload_2
    //   162: invokespecial <init> : (Ljava/lang/CharSequence;)V
    //   165: astore_1
    //   166: aload_1
    //   167: new android/text/style/TextAppearanceSpan
    //   170: dup
    //   171: aconst_null
    //   172: iconst_0
    //   173: iconst_0
    //   174: aload_0
    //   175: getfield y : Landroid/content/res/ColorStateList;
    //   178: aconst_null
    //   179: invokespecial <init> : (Ljava/lang/String;IILandroid/content/res/ColorStateList;Landroid/content/res/ColorStateList;)V
    //   182: iconst_0
    //   183: aload_2
    //   184: invokevirtual length : ()I
    //   187: bipush #33
    //   189: invokevirtual setSpan : (Ljava/lang/Object;III)V
    //   192: goto -> 204
    //   195: aload_3
    //   196: aload_0
    //   197: getfield A : I
    //   200: invokestatic r : (Landroid/database/Cursor;I)Ljava/lang/String;
    //   203: astore_1
    //   204: aload_1
    //   205: invokestatic isEmpty : (Ljava/lang/CharSequence;)Z
    //   208: ifeq -> 238
    //   211: aload #7
    //   213: getfield a : Landroid/widget/TextView;
    //   216: astore_2
    //   217: aload_2
    //   218: ifnull -> 262
    //   221: aload_2
    //   222: iconst_0
    //   223: invokevirtual setSingleLine : (Z)V
    //   226: aload #7
    //   228: getfield a : Landroid/widget/TextView;
    //   231: iconst_2
    //   232: invokevirtual setMaxLines : (I)V
    //   235: goto -> 262
    //   238: aload #7
    //   240: getfield a : Landroid/widget/TextView;
    //   243: astore_2
    //   244: aload_2
    //   245: ifnull -> 262
    //   248: aload_2
    //   249: iconst_1
    //   250: invokevirtual setSingleLine : (Z)V
    //   253: aload #7
    //   255: getfield a : Landroid/widget/TextView;
    //   258: iconst_1
    //   259: invokevirtual setMaxLines : (I)V
    //   262: aload #7
    //   264: getfield b : Landroid/widget/TextView;
    //   267: astore_2
    //   268: aload_2
    //   269: aload_1
    //   270: invokevirtual setText : (Ljava/lang/CharSequence;)V
    //   273: aload_1
    //   274: invokestatic isEmpty : (Ljava/lang/CharSequence;)Z
    //   277: ifeq -> 287
    //   280: bipush #8
    //   282: istore #5
    //   284: goto -> 290
    //   287: iconst_0
    //   288: istore #5
    //   290: aload_2
    //   291: iload #5
    //   293: invokevirtual setVisibility : (I)V
    //   296: aload #7
    //   298: getfield c : Landroid/widget/ImageView;
    //   301: astore #8
    //   303: aconst_null
    //   304: astore #6
    //   306: aload #8
    //   308: ifnull -> 613
    //   311: aload_0
    //   312: getfield C : I
    //   315: istore #5
    //   317: iload #5
    //   319: iconst_m1
    //   320: if_icmpne -> 328
    //   323: aconst_null
    //   324: astore_1
    //   325: goto -> 574
    //   328: aload_0
    //   329: aload_3
    //   330: iload #5
    //   332: invokeinterface getString : (I)Ljava/lang/String;
    //   337: invokevirtual p : (Ljava/lang/String;)Landroid/graphics/drawable/Drawable;
    //   340: astore_1
    //   341: aload_1
    //   342: ifnull -> 348
    //   345: goto -> 574
    //   348: aload_0
    //   349: getfield t : Landroid/app/SearchableInfo;
    //   352: invokevirtual getSearchActivity : ()Landroid/content/ComponentName;
    //   355: astore #10
    //   357: aload #10
    //   359: invokevirtual flattenToShortString : ()Ljava/lang/String;
    //   362: astore #9
    //   364: aload_0
    //   365: getfield v : Ljava/util/WeakHashMap;
    //   368: aload #9
    //   370: invokevirtual containsKey : (Ljava/lang/Object;)Z
    //   373: ifeq -> 413
    //   376: aload_0
    //   377: getfield v : Ljava/util/WeakHashMap;
    //   380: aload #9
    //   382: invokevirtual get : (Ljava/lang/Object;)Ljava/lang/Object;
    //   385: checkcast android/graphics/drawable/Drawable$ConstantState
    //   388: astore_1
    //   389: aload_1
    //   390: ifnonnull -> 398
    //   393: aconst_null
    //   394: astore_1
    //   395: goto -> 556
    //   398: aload_1
    //   399: aload_0
    //   400: getfield u : Landroid/content/Context;
    //   403: invokevirtual getResources : ()Landroid/content/res/Resources;
    //   406: invokevirtual newDrawable : (Landroid/content/res/Resources;)Landroid/graphics/drawable/Drawable;
    //   409: astore_1
    //   410: goto -> 556
    //   413: aload_0
    //   414: getfield k : Landroid/content/Context;
    //   417: invokevirtual getPackageManager : ()Landroid/content/pm/PackageManager;
    //   420: astore_1
    //   421: aload_1
    //   422: aload #10
    //   424: sipush #128
    //   427: invokevirtual getActivityInfo : (Landroid/content/ComponentName;I)Landroid/content/pm/ActivityInfo;
    //   430: astore_2
    //   431: aload_2
    //   432: invokevirtual getIconResource : ()I
    //   435: istore #5
    //   437: iload #5
    //   439: ifne -> 445
    //   442: goto -> 529
    //   445: aload_1
    //   446: aload #10
    //   448: invokevirtual getPackageName : ()Ljava/lang/String;
    //   451: iload #5
    //   453: aload_2
    //   454: getfield applicationInfo : Landroid/content/pm/ApplicationInfo;
    //   457: invokevirtual getDrawable : (Ljava/lang/String;ILandroid/content/pm/ApplicationInfo;)Landroid/graphics/drawable/Drawable;
    //   460: astore_2
    //   461: aload_2
    //   462: astore_1
    //   463: aload_2
    //   464: ifnonnull -> 531
    //   467: new java/lang/StringBuilder
    //   470: dup
    //   471: invokespecial <init> : ()V
    //   474: astore_1
    //   475: aload_1
    //   476: ldc_w 'Invalid icon resource '
    //   479: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   482: pop
    //   483: aload_1
    //   484: iload #5
    //   486: invokevirtual append : (I)Ljava/lang/StringBuilder;
    //   489: pop
    //   490: aload_1
    //   491: ldc_w ' for '
    //   494: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   497: pop
    //   498: aload_1
    //   499: aload #10
    //   501: invokevirtual flattenToShortString : ()Ljava/lang/String;
    //   504: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   507: pop
    //   508: aload_1
    //   509: invokevirtual toString : ()Ljava/lang/String;
    //   512: astore_1
    //   513: goto -> 522
    //   516: astore_1
    //   517: aload_1
    //   518: invokevirtual toString : ()Ljava/lang/String;
    //   521: astore_1
    //   522: ldc 'SuggestionsAdapter'
    //   524: aload_1
    //   525: invokestatic w : (Ljava/lang/String;Ljava/lang/String;)I
    //   528: pop
    //   529: aconst_null
    //   530: astore_1
    //   531: aload_1
    //   532: ifnonnull -> 540
    //   535: aconst_null
    //   536: astore_2
    //   537: goto -> 545
    //   540: aload_1
    //   541: invokevirtual getConstantState : ()Landroid/graphics/drawable/Drawable$ConstantState;
    //   544: astore_2
    //   545: aload_0
    //   546: getfield v : Ljava/util/WeakHashMap;
    //   549: aload #9
    //   551: aload_2
    //   552: invokevirtual put : (Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    //   555: pop
    //   556: aload_1
    //   557: ifnull -> 563
    //   560: goto -> 574
    //   563: aload_0
    //   564: getfield k : Landroid/content/Context;
    //   567: invokevirtual getPackageManager : ()Landroid/content/pm/PackageManager;
    //   570: invokevirtual getDefaultActivityIcon : ()Landroid/graphics/drawable/Drawable;
    //   573: astore_1
    //   574: aload #8
    //   576: aload_1
    //   577: invokevirtual setImageDrawable : (Landroid/graphics/drawable/Drawable;)V
    //   580: aload_1
    //   581: ifnonnull -> 593
    //   584: aload #8
    //   586: iconst_4
    //   587: invokevirtual setVisibility : (I)V
    //   590: goto -> 613
    //   593: aload #8
    //   595: iconst_0
    //   596: invokevirtual setVisibility : (I)V
    //   599: aload_1
    //   600: iconst_0
    //   601: iconst_0
    //   602: invokevirtual setVisible : (ZZ)Z
    //   605: pop
    //   606: aload_1
    //   607: iconst_1
    //   608: iconst_0
    //   609: invokevirtual setVisible : (ZZ)Z
    //   612: pop
    //   613: aload #7
    //   615: getfield d : Landroid/widget/ImageView;
    //   618: astore_2
    //   619: aload_2
    //   620: ifnull -> 691
    //   623: aload_0
    //   624: getfield D : I
    //   627: istore #5
    //   629: iload #5
    //   631: iconst_m1
    //   632: if_icmpne -> 641
    //   635: aload #6
    //   637: astore_1
    //   638: goto -> 654
    //   641: aload_0
    //   642: aload_3
    //   643: iload #5
    //   645: invokeinterface getString : (I)Ljava/lang/String;
    //   650: invokevirtual p : (Ljava/lang/String;)Landroid/graphics/drawable/Drawable;
    //   653: astore_1
    //   654: aload_2
    //   655: aload_1
    //   656: invokevirtual setImageDrawable : (Landroid/graphics/drawable/Drawable;)V
    //   659: aload_1
    //   660: ifnonnull -> 672
    //   663: aload_2
    //   664: bipush #8
    //   666: invokevirtual setVisibility : (I)V
    //   669: goto -> 691
    //   672: aload_2
    //   673: iconst_0
    //   674: invokevirtual setVisibility : (I)V
    //   677: aload_1
    //   678: iconst_0
    //   679: iconst_0
    //   680: invokevirtual setVisible : (ZZ)Z
    //   683: pop
    //   684: aload_1
    //   685: iconst_1
    //   686: iconst_0
    //   687: invokevirtual setVisible : (ZZ)Z
    //   690: pop
    //   691: aload_0
    //   692: getfield x : I
    //   695: istore #5
    //   697: iload #5
    //   699: iconst_2
    //   700: if_icmpeq -> 730
    //   703: iload #5
    //   705: iconst_1
    //   706: if_icmpne -> 719
    //   709: iload #4
    //   711: iconst_1
    //   712: iand
    //   713: ifeq -> 719
    //   716: goto -> 730
    //   719: aload #7
    //   721: getfield e : Landroid/widget/ImageView;
    //   724: bipush #8
    //   726: invokevirtual setVisibility : (I)V
    //   729: return
    //   730: aload #7
    //   732: getfield e : Landroid/widget/ImageView;
    //   735: iconst_0
    //   736: invokevirtual setVisibility : (I)V
    //   739: aload #7
    //   741: getfield e : Landroid/widget/ImageView;
    //   744: aload #7
    //   746: getfield a : Landroid/widget/TextView;
    //   749: invokevirtual getText : ()Ljava/lang/CharSequence;
    //   752: invokevirtual setTag : (Ljava/lang/Object;)V
    //   755: aload #7
    //   757: getfield e : Landroid/widget/ImageView;
    //   760: aload_0
    //   761: invokevirtual setOnClickListener : (Landroid/view/View$OnClickListener;)V
    //   764: return
    // Exception table:
    //   from	to	target	type
    //   421	431	516	android/content/pm/PackageManager$NameNotFoundException
  }
  
  public void b(Cursor paramCursor) {
    try {
      super.b(paramCursor);
      if (paramCursor != null) {
        this.z = paramCursor.getColumnIndex("suggest_text_1");
        this.A = paramCursor.getColumnIndex("suggest_text_2");
        this.B = paramCursor.getColumnIndex("suggest_text_2_url");
        this.C = paramCursor.getColumnIndex("suggest_icon_1");
        this.D = paramCursor.getColumnIndex("suggest_icon_2");
        this.E = paramCursor.getColumnIndex("suggest_flags");
        return;
      } 
    } catch (Exception exception) {
      Log.e("SuggestionsAdapter", "error changing cursor and caching columns", exception);
    } 
  }
  
  public CharSequence c(Cursor paramCursor) {
    if (paramCursor == null)
      return null; 
    String str = r(paramCursor, paramCursor.getColumnIndex("suggest_intent_query"));
    if (str != null)
      return str; 
    if (this.t.shouldRewriteQueryFromData()) {
      str = r(paramCursor, paramCursor.getColumnIndex("suggest_intent_data"));
      if (str != null)
        return str; 
    } 
    if (this.t.shouldRewriteQueryFromText()) {
      String str1 = r(paramCursor, paramCursor.getColumnIndex("suggest_text_1"));
      if (str1 != null)
        return str1; 
    } 
    return null;
  }
  
  public View f(Context paramContext, Cursor paramCursor, ViewGroup paramViewGroup) {
    View view = this.r.inflate(this.p, paramViewGroup, false);
    view.setTag(new a(view));
    ((ImageView)view.findViewById(2131362032)).setImageResource(this.w);
    return view;
  }
  
  public View getDropDownView(int paramInt, View paramView, ViewGroup paramViewGroup) {
    try {
      return super.getDropDownView(paramInt, paramView, paramViewGroup);
    } catch (RuntimeException runtimeException) {
      Log.w("SuggestionsAdapter", "Search suggestions cursor threw exception.", runtimeException);
      View view = this.r.inflate(this.q, paramViewGroup, false);
      if (view != null)
        ((a)view.getTag()).a.setText(runtimeException.toString()); 
      return view;
    } 
  }
  
  public View getView(int paramInt, View paramView, ViewGroup paramViewGroup) {
    try {
      return super.getView(paramInt, paramView, paramViewGroup);
    } catch (RuntimeException runtimeException) {
      Log.w("SuggestionsAdapter", "Search suggestions cursor threw exception.", runtimeException);
      View view = f(((n0.a)this).k, ((n0.a)this).j, paramViewGroup);
      ((a)view.getTag()).a.setText(runtimeException.toString());
      return view;
    } 
  }
  
  public Drawable h(Uri paramUri) {
    String str = paramUri.getAuthority();
    if (!TextUtils.isEmpty(str))
      try {
        int i;
        Resources resources = ((n0.a)this).k.getPackageManager().getResourcesForApplication(str);
        List<String> list = paramUri.getPathSegments();
        if (list != null) {
          i = list.size();
          if (i == 1)
            try {
              i = Integer.parseInt(list.get(0));
              if (i != 0)
                return resources.getDrawable(i); 
              throw new FileNotFoundException(s0.a("No resource found for: ", paramUri));
            } catch (NumberFormatException numberFormatException) {
              throw new FileNotFoundException(s0.a("Single path segment is not a resource ID: ", paramUri));
            }  
          if (i == 2) {
            i = resources.getIdentifier(list.get(1), list.get(0), (String)numberFormatException);
          } else {
            throw new FileNotFoundException(s0.a("More than two path segments: ", paramUri));
          } 
        } else {
          throw new FileNotFoundException(s0.a("No path: ", paramUri));
        } 
        if (i != 0)
          return resources.getDrawable(i); 
        throw new FileNotFoundException(s0.a("No resource found for: ", paramUri));
      } catch (android.content.pm.PackageManager.NameNotFoundException nameNotFoundException) {
        throw new FileNotFoundException(s0.a("No package found for authority: ", paramUri));
      }  
    throw new FileNotFoundException(s0.a("No authority: ", paramUri));
  }
  
  public boolean hasStableIds() {
    return false;
  }
  
  public void notifyDataSetChanged() {
    super.notifyDataSetChanged();
    Cursor cursor = ((n0.a)this).j;
    if (cursor != null) {
      Bundle bundle = cursor.getExtras();
    } else {
      cursor = null;
    } 
    if (cursor != null)
      cursor.getBoolean("in_progress"); 
  }
  
  public void notifyDataSetInvalidated() {
    super.notifyDataSetInvalidated();
    Cursor cursor = ((n0.a)this).j;
    if (cursor != null) {
      Bundle bundle = cursor.getExtras();
    } else {
      cursor = null;
    } 
    if (cursor != null)
      cursor.getBoolean("in_progress"); 
  }
  
  public void onClick(View paramView) {
    Object object = paramView.getTag();
    if (object instanceof CharSequence)
      this.s.s((CharSequence)object); 
  }
  
  public final Drawable p(String paramString) {
    // Byte code:
    //   0: aconst_null
    //   1: astore #4
    //   3: aconst_null
    //   4: astore #6
    //   6: aload #4
    //   8: astore #5
    //   10: aload_1
    //   11: ifnull -> 584
    //   14: aload #4
    //   16: astore #5
    //   18: aload_1
    //   19: invokevirtual isEmpty : ()Z
    //   22: ifne -> 584
    //   25: ldc_w '0'
    //   28: aload_1
    //   29: invokevirtual equals : (Ljava/lang/Object;)Z
    //   32: ifeq -> 37
    //   35: aconst_null
    //   36: areturn
    //   37: aload_1
    //   38: invokestatic parseInt : (Ljava/lang/String;)I
    //   41: istore_2
    //   42: new java/lang/StringBuilder
    //   45: dup
    //   46: invokespecial <init> : ()V
    //   49: astore #4
    //   51: aload #4
    //   53: ldc_w 'android.resource://'
    //   56: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   59: pop
    //   60: aload #4
    //   62: aload_0
    //   63: getfield u : Landroid/content/Context;
    //   66: invokevirtual getPackageName : ()Ljava/lang/String;
    //   69: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   72: pop
    //   73: aload #4
    //   75: ldc_w '/'
    //   78: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   81: pop
    //   82: aload #4
    //   84: iload_2
    //   85: invokevirtual append : (I)Ljava/lang/StringBuilder;
    //   88: pop
    //   89: aload #4
    //   91: invokevirtual toString : ()Ljava/lang/String;
    //   94: astore #5
    //   96: aload_0
    //   97: getfield v : Ljava/util/WeakHashMap;
    //   100: aload #5
    //   102: invokevirtual get : (Ljava/lang/Object;)Ljava/lang/Object;
    //   105: checkcast android/graphics/drawable/Drawable$ConstantState
    //   108: astore #4
    //   110: aload #4
    //   112: ifnonnull -> 121
    //   115: aconst_null
    //   116: astore #4
    //   118: goto -> 602
    //   121: aload #4
    //   123: invokevirtual newDrawable : ()Landroid/graphics/drawable/Drawable;
    //   126: astore #4
    //   128: goto -> 602
    //   131: aload_0
    //   132: getfield u : Landroid/content/Context;
    //   135: astore #4
    //   137: getstatic b0/a.a : Ljava/lang/Object;
    //   140: astore #7
    //   142: aload #4
    //   144: iload_2
    //   145: invokestatic b : (Landroid/content/Context;I)Landroid/graphics/drawable/Drawable;
    //   148: astore #4
    //   150: aload #4
    //   152: ifnull -> 170
    //   155: aload_0
    //   156: getfield v : Ljava/util/WeakHashMap;
    //   159: aload #5
    //   161: aload #4
    //   163: invokevirtual getConstantState : ()Landroid/graphics/drawable/Drawable$ConstantState;
    //   166: invokevirtual put : (Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    //   169: pop
    //   170: aload #4
    //   172: areturn
    //   173: new java/lang/StringBuilder
    //   176: dup
    //   177: invokespecial <init> : ()V
    //   180: astore #4
    //   182: aload #4
    //   184: ldc_w 'Icon resource not found: '
    //   187: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   190: pop
    //   191: aload #4
    //   193: aload_1
    //   194: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   197: pop
    //   198: ldc 'SuggestionsAdapter'
    //   200: aload #4
    //   202: invokevirtual toString : ()Ljava/lang/String;
    //   205: invokestatic w : (Ljava/lang/String;Ljava/lang/String;)I
    //   208: pop
    //   209: aconst_null
    //   210: areturn
    //   211: aload_0
    //   212: getfield v : Ljava/util/WeakHashMap;
    //   215: aload_1
    //   216: invokevirtual get : (Ljava/lang/Object;)Ljava/lang/Object;
    //   219: checkcast android/graphics/drawable/Drawable$ConstantState
    //   222: astore #4
    //   224: aload #4
    //   226: ifnonnull -> 235
    //   229: aconst_null
    //   230: astore #4
    //   232: goto -> 242
    //   235: aload #4
    //   237: invokevirtual newDrawable : ()Landroid/graphics/drawable/Drawable;
    //   240: astore #4
    //   242: aload #4
    //   244: ifnull -> 250
    //   247: aload #4
    //   249: areturn
    //   250: aload_1
    //   251: invokestatic parse : (Ljava/lang/String;)Landroid/net/Uri;
    //   254: astore #5
    //   256: ldc_w 'android.resource'
    //   259: aload #5
    //   261: invokevirtual getScheme : ()Ljava/lang/String;
    //   264: invokevirtual equals : (Ljava/lang/Object;)Z
    //   267: istore_3
    //   268: iload_3
    //   269: ifeq -> 322
    //   272: aload_0
    //   273: aload #5
    //   275: invokevirtual h : (Landroid/net/Uri;)Landroid/graphics/drawable/Drawable;
    //   278: astore #4
    //   280: goto -> 557
    //   283: new java/lang/StringBuilder
    //   286: dup
    //   287: invokespecial <init> : ()V
    //   290: astore #4
    //   292: aload #4
    //   294: ldc_w 'Resource does not exist: '
    //   297: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   300: pop
    //   301: aload #4
    //   303: aload #5
    //   305: invokevirtual append : (Ljava/lang/Object;)Ljava/lang/StringBuilder;
    //   308: pop
    //   309: new java/io/FileNotFoundException
    //   312: dup
    //   313: aload #4
    //   315: invokevirtual toString : ()Ljava/lang/String;
    //   318: invokespecial <init> : (Ljava/lang/String;)V
    //   321: athrow
    //   322: aload_0
    //   323: getfield u : Landroid/content/Context;
    //   326: invokevirtual getContentResolver : ()Landroid/content/ContentResolver;
    //   329: aload #5
    //   331: invokevirtual openInputStream : (Landroid/net/Uri;)Ljava/io/InputStream;
    //   334: astore #7
    //   336: aload #7
    //   338: ifnull -> 455
    //   341: aload #7
    //   343: aconst_null
    //   344: invokestatic createFromStream : (Ljava/io/InputStream;Ljava/lang/String;)Landroid/graphics/drawable/Drawable;
    //   347: astore #4
    //   349: aload #7
    //   351: invokevirtual close : ()V
    //   354: goto -> 398
    //   357: astore #7
    //   359: new java/lang/StringBuilder
    //   362: dup
    //   363: invokespecial <init> : ()V
    //   366: astore #8
    //   368: aload #8
    //   370: ldc_w 'Error closing icon stream for '
    //   373: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   376: pop
    //   377: aload #8
    //   379: aload #5
    //   381: invokevirtual append : (Ljava/lang/Object;)Ljava/lang/StringBuilder;
    //   384: pop
    //   385: ldc 'SuggestionsAdapter'
    //   387: aload #8
    //   389: invokevirtual toString : ()Ljava/lang/String;
    //   392: aload #7
    //   394: invokestatic e : (Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)I
    //   397: pop
    //   398: goto -> 557
    //   401: astore #4
    //   403: aload #7
    //   405: invokevirtual close : ()V
    //   408: goto -> 452
    //   411: astore #7
    //   413: new java/lang/StringBuilder
    //   416: dup
    //   417: invokespecial <init> : ()V
    //   420: astore #8
    //   422: aload #8
    //   424: ldc_w 'Error closing icon stream for '
    //   427: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   430: pop
    //   431: aload #8
    //   433: aload #5
    //   435: invokevirtual append : (Ljava/lang/Object;)Ljava/lang/StringBuilder;
    //   438: pop
    //   439: ldc 'SuggestionsAdapter'
    //   441: aload #8
    //   443: invokevirtual toString : ()Ljava/lang/String;
    //   446: aload #7
    //   448: invokestatic e : (Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)I
    //   451: pop
    //   452: aload #4
    //   454: athrow
    //   455: new java/lang/StringBuilder
    //   458: dup
    //   459: invokespecial <init> : ()V
    //   462: astore #4
    //   464: aload #4
    //   466: ldc_w 'Failed to open '
    //   469: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   472: pop
    //   473: aload #4
    //   475: aload #5
    //   477: invokevirtual append : (Ljava/lang/Object;)Ljava/lang/StringBuilder;
    //   480: pop
    //   481: new java/io/FileNotFoundException
    //   484: dup
    //   485: aload #4
    //   487: invokevirtual toString : ()Ljava/lang/String;
    //   490: invokespecial <init> : (Ljava/lang/String;)V
    //   493: athrow
    //   494: astore #4
    //   496: new java/lang/StringBuilder
    //   499: dup
    //   500: invokespecial <init> : ()V
    //   503: astore #7
    //   505: aload #7
    //   507: ldc_w 'Icon not found: '
    //   510: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   513: pop
    //   514: aload #7
    //   516: aload #5
    //   518: invokevirtual append : (Ljava/lang/Object;)Ljava/lang/StringBuilder;
    //   521: pop
    //   522: aload #7
    //   524: ldc_w ', '
    //   527: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   530: pop
    //   531: aload #7
    //   533: aload #4
    //   535: invokevirtual getMessage : ()Ljava/lang/String;
    //   538: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   541: pop
    //   542: ldc 'SuggestionsAdapter'
    //   544: aload #7
    //   546: invokevirtual toString : ()Ljava/lang/String;
    //   549: invokestatic w : (Ljava/lang/String;Ljava/lang/String;)I
    //   552: pop
    //   553: aload #6
    //   555: astore #4
    //   557: aload #4
    //   559: astore #5
    //   561: aload #4
    //   563: ifnull -> 584
    //   566: aload_0
    //   567: getfield v : Ljava/util/WeakHashMap;
    //   570: aload_1
    //   571: aload #4
    //   573: invokevirtual getConstantState : ()Landroid/graphics/drawable/Drawable$ConstantState;
    //   576: invokevirtual put : (Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    //   579: pop
    //   580: aload #4
    //   582: astore #5
    //   584: aload #5
    //   586: areturn
    //   587: astore #4
    //   589: goto -> 211
    //   592: astore #4
    //   594: goto -> 173
    //   597: astore #4
    //   599: goto -> 283
    //   602: aload #4
    //   604: ifnull -> 131
    //   607: aload #4
    //   609: areturn
    // Exception table:
    //   from	to	target	type
    //   37	110	587	java/lang/NumberFormatException
    //   37	110	592	android/content/res/Resources$NotFoundException
    //   121	128	587	java/lang/NumberFormatException
    //   121	128	592	android/content/res/Resources$NotFoundException
    //   131	150	587	java/lang/NumberFormatException
    //   131	150	592	android/content/res/Resources$NotFoundException
    //   155	170	587	java/lang/NumberFormatException
    //   155	170	592	android/content/res/Resources$NotFoundException
    //   256	268	494	java/io/FileNotFoundException
    //   272	280	597	android/content/res/Resources$NotFoundException
    //   272	280	494	java/io/FileNotFoundException
    //   283	322	494	java/io/FileNotFoundException
    //   322	336	494	java/io/FileNotFoundException
    //   341	349	401	finally
    //   349	354	357	java/io/IOException
    //   359	398	494	java/io/FileNotFoundException
    //   403	408	411	java/io/IOException
    //   413	452	494	java/io/FileNotFoundException
    //   452	455	494	java/io/FileNotFoundException
    //   455	494	494	java/io/FileNotFoundException
  }
  
  public Cursor q(SearchableInfo paramSearchableInfo, String paramString, int paramInt) {
    SearchableInfo searchableInfo = null;
    if (paramSearchableInfo == null)
      return null; 
    String str1 = paramSearchableInfo.getSuggestAuthority();
    if (str1 == null)
      return null; 
    Uri.Builder builder = (new Uri.Builder()).scheme("content").authority(str1).query("").fragment("");
    String str2 = paramSearchableInfo.getSuggestPath();
    if (str2 != null)
      builder.appendEncodedPath(str2); 
    builder.appendPath("search_suggest_query");
    str2 = paramSearchableInfo.getSuggestSelection();
    if (str2 != null) {
      String[] arrayOfString = new String[1];
      arrayOfString[0] = paramString;
    } else {
      builder.appendPath(paramString);
      paramSearchableInfo = searchableInfo;
    } 
    if (paramInt > 0)
      builder.appendQueryParameter("limit", String.valueOf(paramInt)); 
    Uri uri = builder.build();
    return ((n0.a)this).k.getContentResolver().query(uri, null, str2, (String[])paramSearchableInfo, null);
  }
  
  public static final class a {
    public final TextView a;
    
    public final TextView b;
    
    public final ImageView c;
    
    public final ImageView d;
    
    public final ImageView e;
    
    public a(View param1View) {
      this.a = (TextView)param1View.findViewById(16908308);
      this.b = (TextView)param1View.findViewById(16908309);
      this.c = (ImageView)param1View.findViewById(16908295);
      this.d = (ImageView)param1View.findViewById(16908296);
      this.e = (ImageView)param1View.findViewById(2131362032);
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Luxury Logo Maker_ Logo Design-dex2jar.jar!\androidx\appcompat\widget\t0.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */