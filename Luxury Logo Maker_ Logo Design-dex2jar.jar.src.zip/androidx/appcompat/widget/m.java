package androidx.appcompat.widget;

import android.content.Context;
import android.content.res.ColorStateList;
import android.graphics.PorterDuff;
import android.graphics.drawable.Drawable;
import android.os.Build;
import android.util.AttributeSet;
import android.view.View;
import android.widget.ImageView;
import com.bumptech.glide.manager.b;
import g.a;
import k0.l;

public class m {
  public final ImageView a;
  
  public x0 b;
  
  public x0 c;
  
  public m(ImageView paramImageView) {
    this.a = paramImageView;
  }
  
  public void a() {
    Drawable drawable = this.a.getDrawable();
    if (drawable != null)
      f0.b(drawable); 
    if (drawable != null) {
      int i = Build.VERSION.SDK_INT;
      boolean bool = true;
      if (i <= 21 && i == 21) {
        i = 1;
      } else {
        i = 0;
      } 
      if (i != 0) {
        if (this.c == null)
          this.c = new x0(); 
        x0 x02 = this.c;
        x02.a = null;
        x02.d = false;
        x02.b = null;
        x02.c = false;
        ColorStateList colorStateList = this.a.getImageTintList();
        if (colorStateList != null) {
          x02.d = true;
          x02.a = colorStateList;
        } 
        PorterDuff.Mode mode = this.a.getImageTintMode();
        if (mode != null) {
          x02.c = true;
          x02.b = mode;
        } 
        if (x02.d || x02.c) {
          j.f(drawable, x02, this.a.getDrawableState());
          i = bool;
        } else {
          i = 0;
        } 
        if (i != 0)
          return; 
      } 
      x0 x01 = this.b;
      if (x01 != null)
        j.f(drawable, x01, this.a.getDrawableState()); 
    } 
  }
  
  public void b(AttributeSet paramAttributeSet, int paramInt) {
    Context context = this.a.getContext();
    int[] arrayOfInt = b.m;
    z0 z0 = z0.q(context, paramAttributeSet, arrayOfInt, paramInt, 0);
    ImageView imageView = this.a;
    l.r((View)imageView, imageView.getContext(), arrayOfInt, paramAttributeSet, z0.b, paramInt, 0);
    try {
      Drawable drawable2 = this.a.getDrawable();
      Drawable drawable1 = drawable2;
      if (drawable2 == null) {
        paramInt = z0.l(1, -1);
        drawable1 = drawable2;
        if (paramInt != -1) {
          drawable2 = a.b(this.a.getContext(), paramInt);
          drawable1 = drawable2;
          if (drawable2 != null) {
            this.a.setImageDrawable(drawable2);
            drawable1 = drawable2;
          } 
        } 
      } 
      if (drawable1 != null)
        f0.b(drawable1); 
      if (z0.o(2)) {
        ImageView imageView1 = this.a;
        ColorStateList colorStateList = z0.c(2);
        paramInt = Build.VERSION.SDK_INT;
        imageView1.setImageTintList(colorStateList);
        if (paramInt == 21) {
          Drawable drawable = imageView1.getDrawable();
          if (drawable != null && imageView1.getImageTintList() != null) {
            if (drawable.isStateful())
              drawable.setState(imageView1.getDrawableState()); 
            imageView1.setImageDrawable(drawable);
          } 
        } 
      } 
      if (z0.o(3)) {
        ImageView imageView1 = this.a;
        PorterDuff.Mode mode = f0.c(z0.j(3, -1), null);
        paramInt = Build.VERSION.SDK_INT;
        imageView1.setImageTintMode(mode);
        if (paramInt == 21) {
          Drawable drawable = imageView1.getDrawable();
          if (drawable != null && imageView1.getImageTintList() != null) {
            if (drawable.isStateful())
              drawable.setState(imageView1.getDrawableState()); 
            imageView1.setImageDrawable(drawable);
          } 
        } 
      } 
      return;
    } finally {
      z0.b.recycle();
    } 
  }
  
  public void c(int paramInt) {
    if (paramInt != 0) {
      Drawable drawable = a.b(this.a.getContext(), paramInt);
      if (drawable != null)
        f0.b(drawable); 
      this.a.setImageDrawable(drawable);
    } else {
      this.a.setImageDrawable(null);
    } 
    a();
  }
  
  public void d(ColorStateList paramColorStateList) {
    if (this.b == null)
      this.b = new x0(); 
    x0 x01 = this.b;
    x01.a = paramColorStateList;
    x01.d = true;
    a();
  }
  
  public void e(PorterDuff.Mode paramMode) {
    if (this.b == null)
      this.b = new x0(); 
    x0 x01 = this.b;
    x01.b = paramMode;
    x01.c = true;
    a();
  }
}


/* Location:              C:\soft\dex2jar-2.0\Luxury Logo Maker_ Logo Design-dex2jar.jar!\androidx\appcompat\widget\m.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */