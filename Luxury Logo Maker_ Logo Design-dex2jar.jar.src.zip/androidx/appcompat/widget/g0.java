package androidx.appcompat.widget;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Rect;
import android.graphics.drawable.Drawable;
import android.os.Build;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AbsListView;
import android.widget.ListAdapter;
import android.widget.ListView;
import h.c;
import java.lang.reflect.Field;
import m0.d;

public class g0 extends ListView {
  public final Rect h = new Rect();
  
  public int i = 0;
  
  public int j = 0;
  
  public int k = 0;
  
  public int l = 0;
  
  public int m;
  
  public Field n;
  
  public a o;
  
  public boolean p;
  
  public boolean q;
  
  public boolean r;
  
  public d s;
  
  public b t;
  
  public g0(Context paramContext, boolean paramBoolean) {
    super(paramContext, null, 2130968872);
    this.q = paramBoolean;
    setCacheColorHint(0);
    try {
      Field field = AbsListView.class.getDeclaredField("mIsChildViewEnabled");
      this.n = field;
      field.setAccessible(true);
      return;
    } catch (NoSuchFieldException noSuchFieldException) {
      noSuchFieldException.printStackTrace();
      return;
    } 
  }
  
  private void setSelectorEnabled(boolean paramBoolean) {
    a a1 = this.o;
    if (a1 != null)
      a1.i = paramBoolean; 
  }
  
  public int a(int paramInt1, int paramInt2, int paramInt3) {
    int i = getListPaddingTop();
    int j = getListPaddingBottom();
    int k = getDividerHeight();
    Drawable drawable = getDivider();
    ListAdapter listAdapter = getAdapter();
    j = i + j;
    if (listAdapter == null)
      return j; 
    if (k <= 0 || drawable == null)
      k = 0; 
    int i1 = listAdapter.getCount();
    drawable = null;
    int m = 0;
    int n = 0;
    for (i = 0; m < i1; i = i3) {
      int i3 = listAdapter.getItemViewType(m);
      int i2 = n;
      if (i3 != n) {
        drawable = null;
        i2 = i3;
      } 
      View view2 = listAdapter.getView(m, (View)drawable, (ViewGroup)this);
      ViewGroup.LayoutParams layoutParams2 = view2.getLayoutParams();
      ViewGroup.LayoutParams layoutParams1 = layoutParams2;
      if (layoutParams2 == null) {
        layoutParams1 = generateDefaultLayoutParams();
        view2.setLayoutParams(layoutParams1);
      } 
      n = layoutParams1.height;
      if (n > 0) {
        n = View.MeasureSpec.makeMeasureSpec(n, 1073741824);
      } else {
        n = View.MeasureSpec.makeMeasureSpec(0, 0);
      } 
      view2.measure(paramInt1, n);
      view2.forceLayout();
      n = j;
      if (m > 0)
        n = j + k; 
      j = n + view2.getMeasuredHeight();
      if (j >= paramInt2) {
        paramInt1 = paramInt2;
        if (paramInt3 >= 0) {
          paramInt1 = paramInt2;
          if (m > paramInt3) {
            paramInt1 = paramInt2;
            if (i > 0) {
              paramInt1 = paramInt2;
              if (j != paramInt2)
                paramInt1 = i; 
            } 
          } 
        } 
        return paramInt1;
      } 
      i3 = i;
      if (paramInt3 >= 0) {
        i3 = i;
        if (m >= paramInt3)
          i3 = j; 
      } 
      m++;
      n = i2;
      View view1 = view2;
    } 
    return j;
  }
  
  public boolean b(MotionEvent paramMotionEvent, int paramInt) {
    // Byte code:
    //   0: aload_1
    //   1: invokevirtual getActionMasked : ()I
    //   4: istore #8
    //   6: iconst_1
    //   7: istore #7
    //   9: iload #8
    //   11: iconst_1
    //   12: if_icmpeq -> 36
    //   15: iload #8
    //   17: iconst_2
    //   18: if_icmpeq -> 30
    //   21: iload #8
    //   23: iconst_3
    //   24: if_icmpeq -> 51
    //   27: goto -> 542
    //   30: iconst_1
    //   31: istore #11
    //   33: goto -> 39
    //   36: iconst_0
    //   37: istore #11
    //   39: aload_1
    //   40: iload_2
    //   41: invokevirtual findPointerIndex : (I)I
    //   44: istore #9
    //   46: iload #9
    //   48: ifge -> 57
    //   51: iconst_0
    //   52: istore #11
    //   54: goto -> 545
    //   57: aload_1
    //   58: iload #9
    //   60: invokevirtual getX : (I)F
    //   63: f2i
    //   64: istore_2
    //   65: aload_1
    //   66: iload #9
    //   68: invokevirtual getY : (I)F
    //   71: f2i
    //   72: istore #10
    //   74: aload_0
    //   75: iload_2
    //   76: iload #10
    //   78: invokevirtual pointToPosition : (II)I
    //   81: istore #9
    //   83: iload #9
    //   85: iconst_m1
    //   86: if_icmpne -> 95
    //   89: iload #7
    //   91: istore_2
    //   92: goto -> 547
    //   95: aload_0
    //   96: iload #9
    //   98: aload_0
    //   99: invokevirtual getFirstVisiblePosition : ()I
    //   102: isub
    //   103: invokevirtual getChildAt : (I)Landroid/view/View;
    //   106: astore #13
    //   108: iload_2
    //   109: i2f
    //   110: fstore_3
    //   111: iload #10
    //   113: i2f
    //   114: fstore #4
    //   116: aload_0
    //   117: iconst_1
    //   118: putfield r : Z
    //   121: aload_0
    //   122: fload_3
    //   123: fload #4
    //   125: invokevirtual drawableHotspotChanged : (FF)V
    //   128: aload_0
    //   129: invokevirtual isPressed : ()Z
    //   132: ifne -> 140
    //   135: aload_0
    //   136: iconst_1
    //   137: invokevirtual setPressed : (Z)V
    //   140: aload_0
    //   141: invokevirtual layoutChildren : ()V
    //   144: aload_0
    //   145: getfield m : I
    //   148: istore_2
    //   149: iload_2
    //   150: iconst_m1
    //   151: if_icmpeq -> 192
    //   154: aload_0
    //   155: iload_2
    //   156: aload_0
    //   157: invokevirtual getFirstVisiblePosition : ()I
    //   160: isub
    //   161: invokevirtual getChildAt : (I)Landroid/view/View;
    //   164: astore #14
    //   166: aload #14
    //   168: ifnull -> 192
    //   171: aload #14
    //   173: aload #13
    //   175: if_acmpeq -> 192
    //   178: aload #14
    //   180: invokevirtual isPressed : ()Z
    //   183: ifeq -> 192
    //   186: aload #14
    //   188: iconst_0
    //   189: invokevirtual setPressed : (Z)V
    //   192: aload_0
    //   193: iload #9
    //   195: putfield m : I
    //   198: aload #13
    //   200: fload_3
    //   201: aload #13
    //   203: invokevirtual getLeft : ()I
    //   206: i2f
    //   207: fsub
    //   208: fload #4
    //   210: aload #13
    //   212: invokevirtual getTop : ()I
    //   215: i2f
    //   216: fsub
    //   217: invokevirtual drawableHotspotChanged : (FF)V
    //   220: aload #13
    //   222: invokevirtual isPressed : ()Z
    //   225: ifne -> 234
    //   228: aload #13
    //   230: iconst_1
    //   231: invokevirtual setPressed : (Z)V
    //   234: aload_0
    //   235: invokevirtual getSelector : ()Landroid/graphics/drawable/Drawable;
    //   238: astore #14
    //   240: aload #14
    //   242: ifnull -> 256
    //   245: iload #9
    //   247: iconst_m1
    //   248: if_icmpeq -> 256
    //   251: iconst_1
    //   252: istore_2
    //   253: goto -> 258
    //   256: iconst_0
    //   257: istore_2
    //   258: iload_2
    //   259: ifeq -> 270
    //   262: aload #14
    //   264: iconst_0
    //   265: iconst_0
    //   266: invokevirtual setVisible : (ZZ)Z
    //   269: pop
    //   270: aload_0
    //   271: getfield h : Landroid/graphics/Rect;
    //   274: astore #15
    //   276: aload #15
    //   278: aload #13
    //   280: invokevirtual getLeft : ()I
    //   283: aload #13
    //   285: invokevirtual getTop : ()I
    //   288: aload #13
    //   290: invokevirtual getRight : ()I
    //   293: aload #13
    //   295: invokevirtual getBottom : ()I
    //   298: invokevirtual set : (IIII)V
    //   301: aload #15
    //   303: aload #15
    //   305: getfield left : I
    //   308: aload_0
    //   309: getfield i : I
    //   312: isub
    //   313: putfield left : I
    //   316: aload #15
    //   318: aload #15
    //   320: getfield top : I
    //   323: aload_0
    //   324: getfield j : I
    //   327: isub
    //   328: putfield top : I
    //   331: aload #15
    //   333: aload #15
    //   335: getfield right : I
    //   338: aload_0
    //   339: getfield k : I
    //   342: iadd
    //   343: putfield right : I
    //   346: aload #15
    //   348: aload #15
    //   350: getfield bottom : I
    //   353: aload_0
    //   354: getfield l : I
    //   357: iadd
    //   358: putfield bottom : I
    //   361: aload_0
    //   362: getfield n : Ljava/lang/reflect/Field;
    //   365: aload_0
    //   366: invokevirtual getBoolean : (Ljava/lang/Object;)Z
    //   369: istore #11
    //   371: aload #13
    //   373: invokevirtual isEnabled : ()Z
    //   376: iload #11
    //   378: if_icmpeq -> 429
    //   381: aload_0
    //   382: getfield n : Ljava/lang/reflect/Field;
    //   385: astore #15
    //   387: iload #11
    //   389: ifne -> 678
    //   392: iconst_1
    //   393: istore #11
    //   395: goto -> 398
    //   398: aload #15
    //   400: aload_0
    //   401: iload #11
    //   403: invokestatic valueOf : (Z)Ljava/lang/Boolean;
    //   406: invokevirtual set : (Ljava/lang/Object;Ljava/lang/Object;)V
    //   409: iload #9
    //   411: iconst_m1
    //   412: if_icmpeq -> 429
    //   415: aload_0
    //   416: invokevirtual refreshDrawableState : ()V
    //   419: goto -> 429
    //   422: astore #15
    //   424: aload #15
    //   426: invokevirtual printStackTrace : ()V
    //   429: iload_2
    //   430: ifeq -> 487
    //   433: aload_0
    //   434: getfield h : Landroid/graphics/Rect;
    //   437: astore #15
    //   439: aload #15
    //   441: invokevirtual exactCenterX : ()F
    //   444: fstore #5
    //   446: aload #15
    //   448: invokevirtual exactCenterY : ()F
    //   451: fstore #6
    //   453: aload_0
    //   454: invokevirtual getVisibility : ()I
    //   457: ifne -> 466
    //   460: iconst_1
    //   461: istore #11
    //   463: goto -> 469
    //   466: iconst_0
    //   467: istore #11
    //   469: aload #14
    //   471: iload #11
    //   473: iconst_0
    //   474: invokevirtual setVisible : (ZZ)Z
    //   477: pop
    //   478: aload #14
    //   480: fload #5
    //   482: fload #6
    //   484: invokevirtual setHotspot : (FF)V
    //   487: aload_0
    //   488: invokevirtual getSelector : ()Landroid/graphics/drawable/Drawable;
    //   491: astore #14
    //   493: aload #14
    //   495: ifnull -> 512
    //   498: iload #9
    //   500: iconst_m1
    //   501: if_icmpeq -> 512
    //   504: aload #14
    //   506: fload_3
    //   507: fload #4
    //   509: invokevirtual setHotspot : (FF)V
    //   512: aload_0
    //   513: iconst_0
    //   514: invokespecial setSelectorEnabled : (Z)V
    //   517: aload_0
    //   518: invokevirtual refreshDrawableState : ()V
    //   521: iload #8
    //   523: iconst_1
    //   524: if_icmpne -> 542
    //   527: aload_0
    //   528: aload #13
    //   530: iload #9
    //   532: aload_0
    //   533: iload #9
    //   535: invokevirtual getItemIdAtPosition : (I)J
    //   538: invokevirtual performItemClick : (Landroid/view/View;IJ)Z
    //   541: pop
    //   542: iconst_1
    //   543: istore #11
    //   545: iconst_0
    //   546: istore_2
    //   547: iload #11
    //   549: ifeq -> 556
    //   552: iload_2
    //   553: ifeq -> 596
    //   556: aload_0
    //   557: iconst_0
    //   558: putfield r : Z
    //   561: aload_0
    //   562: iconst_0
    //   563: invokevirtual setPressed : (Z)V
    //   566: aload_0
    //   567: invokevirtual drawableStateChanged : ()V
    //   570: aload_0
    //   571: aload_0
    //   572: getfield m : I
    //   575: aload_0
    //   576: invokevirtual getFirstVisiblePosition : ()I
    //   579: isub
    //   580: invokevirtual getChildAt : (I)Landroid/view/View;
    //   583: astore #13
    //   585: aload #13
    //   587: ifnull -> 596
    //   590: aload #13
    //   592: iconst_0
    //   593: invokevirtual setPressed : (Z)V
    //   596: iload #11
    //   598: ifeq -> 650
    //   601: aload_0
    //   602: getfield s : Lm0/d;
    //   605: ifnonnull -> 620
    //   608: aload_0
    //   609: new m0/d
    //   612: dup
    //   613: aload_0
    //   614: invokespecial <init> : (Landroid/widget/ListView;)V
    //   617: putfield s : Lm0/d;
    //   620: aload_0
    //   621: getfield s : Lm0/d;
    //   624: astore #13
    //   626: aload #13
    //   628: getfield w : Z
    //   631: istore #12
    //   633: aload #13
    //   635: iconst_1
    //   636: putfield w : Z
    //   639: aload #13
    //   641: aload_0
    //   642: aload_1
    //   643: invokevirtual onTouch : (Landroid/view/View;Landroid/view/MotionEvent;)Z
    //   646: pop
    //   647: iload #11
    //   649: ireturn
    //   650: aload_0
    //   651: getfield s : Lm0/d;
    //   654: astore_1
    //   655: aload_1
    //   656: ifnull -> 675
    //   659: aload_1
    //   660: getfield w : Z
    //   663: ifeq -> 670
    //   666: aload_1
    //   667: invokevirtual f : ()V
    //   670: aload_1
    //   671: iconst_0
    //   672: putfield w : Z
    //   675: iload #11
    //   677: ireturn
    //   678: iconst_0
    //   679: istore #11
    //   681: goto -> 398
    // Exception table:
    //   from	to	target	type
    //   361	387	422	java/lang/IllegalAccessException
    //   398	409	422	java/lang/IllegalAccessException
    //   415	419	422	java/lang/IllegalAccessException
  }
  
  public final void c() {
    Drawable drawable = getSelector();
    if (drawable != null && this.r && isPressed())
      drawable.setState(getDrawableState()); 
  }
  
  public void dispatchDraw(Canvas paramCanvas) {
    if (!this.h.isEmpty()) {
      Drawable drawable = getSelector();
      if (drawable != null) {
        drawable.setBounds(this.h);
        drawable.draw(paramCanvas);
      } 
    } 
    super.dispatchDraw(paramCanvas);
  }
  
  public void drawableStateChanged() {
    if (this.t != null)
      return; 
    super.drawableStateChanged();
    setSelectorEnabled(true);
    c();
  }
  
  public boolean hasFocus() {
    return (this.q || super.hasFocus());
  }
  
  public boolean hasWindowFocus() {
    return (this.q || super.hasWindowFocus());
  }
  
  public boolean isFocused() {
    return (this.q || super.isFocused());
  }
  
  public boolean isInTouchMode() {
    return ((this.q && this.p) || super.isInTouchMode());
  }
  
  public void onDetachedFromWindow() {
    this.t = null;
    super.onDetachedFromWindow();
  }
  
  public boolean onHoverEvent(MotionEvent paramMotionEvent) {
    if (Build.VERSION.SDK_INT < 26)
      return super.onHoverEvent(paramMotionEvent); 
    int i = paramMotionEvent.getActionMasked();
    if (i == 10 && this.t == null) {
      b b1 = new b(this);
      this.t = b1;
      post(b1);
    } 
    boolean bool = super.onHoverEvent(paramMotionEvent);
    if (i == 9 || i == 7) {
      i = pointToPosition((int)paramMotionEvent.getX(), (int)paramMotionEvent.getY());
      if (i != -1 && i != getSelectedItemPosition()) {
        View view = getChildAt(i - getFirstVisiblePosition());
        if (view.isEnabled())
          setSelectionFromTop(i, view.getTop() - getTop()); 
        c();
      } 
      return bool;
    } 
    setSelection(-1);
    return bool;
  }
  
  public boolean onTouchEvent(MotionEvent paramMotionEvent) {
    if (paramMotionEvent.getAction() == 0)
      this.m = pointToPosition((int)paramMotionEvent.getX(), (int)paramMotionEvent.getY()); 
    b b1 = this.t;
    if (b1 != null) {
      g0 g01 = b1.h;
      g01.t = null;
      g01.removeCallbacks(b1);
    } 
    return super.onTouchEvent(paramMotionEvent);
  }
  
  public void setListSelectionHidden(boolean paramBoolean) {
    this.p = paramBoolean;
  }
  
  public void setSelector(Drawable paramDrawable) {
    a a1;
    if (paramDrawable != null) {
      a1 = new a(paramDrawable);
    } else {
      a1 = null;
    } 
    this.o = a1;
    super.setSelector((Drawable)a1);
    Rect rect = new Rect();
    if (paramDrawable != null)
      paramDrawable.getPadding(rect); 
    this.i = rect.left;
    this.j = rect.top;
    this.k = rect.right;
    this.l = rect.bottom;
  }
  
  public static class a extends c {
    public boolean i = true;
    
    public a(Drawable param1Drawable) {
      super(param1Drawable);
    }
    
    public void draw(Canvas param1Canvas) {
      if (this.i)
        this.h.draw(param1Canvas); 
    }
    
    public void setHotspot(float param1Float1, float param1Float2) {
      if (this.i)
        this.h.setHotspot(param1Float1, param1Float2); 
    }
    
    public void setHotspotBounds(int param1Int1, int param1Int2, int param1Int3, int param1Int4) {
      if (this.i)
        this.h.setHotspotBounds(param1Int1, param1Int2, param1Int3, param1Int4); 
    }
    
    public boolean setState(int[] param1ArrayOfint) {
      return this.i ? this.h.setState(param1ArrayOfint) : false;
    }
    
    public boolean setVisible(boolean param1Boolean1, boolean param1Boolean2) {
      return this.i ? super.setVisible(param1Boolean1, param1Boolean2) : false;
    }
  }
  
  public class b implements Runnable {
    public b(g0 this$0) {}
    
    public void run() {
      g0 g01 = this.h;
      g01.t = null;
      g01.drawableStateChanged();
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Luxury Logo Maker_ Logo Design-dex2jar.jar!\androidx\appcompat\widget\g0.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */