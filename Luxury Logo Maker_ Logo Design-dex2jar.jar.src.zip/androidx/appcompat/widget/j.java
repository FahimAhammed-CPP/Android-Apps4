package androidx.appcompat.widget;

import android.content.Context;
import android.content.res.ColorStateList;
import android.graphics.ColorFilter;
import android.graphics.PorterDuff;
import android.graphics.PorterDuffColorFilter;
import android.graphics.drawable.Drawable;
import android.os.Build;
import android.util.Log;

public final class j {
  public static final PorterDuff.Mode b = PorterDuff.Mode.SRC_IN;
  
  public static j c;
  
  public o0 a;
  
  public static j a() {
    // Byte code:
    //   0: ldc androidx/appcompat/widget/j
    //   2: monitorenter
    //   3: getstatic androidx/appcompat/widget/j.c : Landroidx/appcompat/widget/j;
    //   6: ifnonnull -> 12
    //   9: invokestatic e : ()V
    //   12: getstatic androidx/appcompat/widget/j.c : Landroidx/appcompat/widget/j;
    //   15: astore_0
    //   16: ldc androidx/appcompat/widget/j
    //   18: monitorexit
    //   19: aload_0
    //   20: areturn
    //   21: astore_0
    //   22: ldc androidx/appcompat/widget/j
    //   24: monitorexit
    //   25: aload_0
    //   26: athrow
    // Exception table:
    //   from	to	target	type
    //   3	12	21	finally
    //   12	16	21	finally
  }
  
  public static PorterDuffColorFilter c(int paramInt, PorterDuff.Mode paramMode) {
    // Byte code:
    //   0: ldc androidx/appcompat/widget/j
    //   2: monitorenter
    //   3: iload_0
    //   4: aload_1
    //   5: invokestatic h : (ILandroid/graphics/PorterDuff$Mode;)Landroid/graphics/PorterDuffColorFilter;
    //   8: astore_1
    //   9: ldc androidx/appcompat/widget/j
    //   11: monitorexit
    //   12: aload_1
    //   13: areturn
    //   14: astore_1
    //   15: ldc androidx/appcompat/widget/j
    //   17: monitorexit
    //   18: aload_1
    //   19: athrow
    // Exception table:
    //   from	to	target	type
    //   3	9	14	finally
  }
  
  public static void e() {
    // Byte code:
    //   0: ldc androidx/appcompat/widget/j
    //   2: monitorenter
    //   3: getstatic androidx/appcompat/widget/j.c : Landroidx/appcompat/widget/j;
    //   6: ifnonnull -> 60
    //   9: new androidx/appcompat/widget/j
    //   12: dup
    //   13: invokespecial <init> : ()V
    //   16: astore_0
    //   17: aload_0
    //   18: putstatic androidx/appcompat/widget/j.c : Landroidx/appcompat/widget/j;
    //   21: aload_0
    //   22: invokestatic d : ()Landroidx/appcompat/widget/o0;
    //   25: putfield a : Landroidx/appcompat/widget/o0;
    //   28: getstatic androidx/appcompat/widget/j.c : Landroidx/appcompat/widget/j;
    //   31: getfield a : Landroidx/appcompat/widget/o0;
    //   34: astore_0
    //   35: new androidx/appcompat/widget/j$a
    //   38: dup
    //   39: invokespecial <init> : ()V
    //   42: astore_1
    //   43: aload_0
    //   44: monitorenter
    //   45: aload_0
    //   46: aload_1
    //   47: putfield g : Landroidx/appcompat/widget/o0$e;
    //   50: aload_0
    //   51: monitorexit
    //   52: goto -> 60
    //   55: astore_1
    //   56: aload_0
    //   57: monitorexit
    //   58: aload_1
    //   59: athrow
    //   60: ldc androidx/appcompat/widget/j
    //   62: monitorexit
    //   63: return
    //   64: astore_0
    //   65: ldc androidx/appcompat/widget/j
    //   67: monitorexit
    //   68: aload_0
    //   69: athrow
    // Exception table:
    //   from	to	target	type
    //   3	45	64	finally
    //   45	50	55	finally
    //   50	52	64	finally
    //   56	60	64	finally
  }
  
  public static void f(Drawable paramDrawable, x0 paramx0, int[] paramArrayOfint) {
    PorterDuff.Mode mode = o0.h;
    if (f0.a(paramDrawable) && paramDrawable.mutate() != paramDrawable) {
      Log.d("ResourceManagerInternal", "Mutated drawable is not the same instance as the input.");
      return;
    } 
    boolean bool = paramx0.d;
    if (bool || paramx0.c) {
      PorterDuff.Mode mode1;
      PorterDuffColorFilter porterDuffColorFilter2 = null;
      if (bool) {
        ColorStateList colorStateList = paramx0.a;
      } else {
        mode = null;
      } 
      if (paramx0.c) {
        mode1 = paramx0.b;
      } else {
        mode1 = o0.h;
      } 
      PorterDuffColorFilter porterDuffColorFilter1 = porterDuffColorFilter2;
      if (mode != null)
        if (mode1 == null) {
          porterDuffColorFilter1 = porterDuffColorFilter2;
        } else {
          porterDuffColorFilter1 = o0.h(mode.getColorForState(paramArrayOfint, 0), mode1);
        }  
      paramDrawable.setColorFilter((ColorFilter)porterDuffColorFilter1);
    } else {
      paramDrawable.clearColorFilter();
    } 
    if (Build.VERSION.SDK_INT <= 23)
      paramDrawable.invalidateSelf(); 
  }
  
  public Drawable b(Context paramContext, int paramInt) {
    // Byte code:
    //   0: aload_0
    //   1: monitorenter
    //   2: aload_0
    //   3: getfield a : Landroidx/appcompat/widget/o0;
    //   6: aload_1
    //   7: iload_2
    //   8: invokevirtual f : (Landroid/content/Context;I)Landroid/graphics/drawable/Drawable;
    //   11: astore_1
    //   12: aload_0
    //   13: monitorexit
    //   14: aload_1
    //   15: areturn
    //   16: astore_1
    //   17: aload_0
    //   18: monitorexit
    //   19: aload_1
    //   20: athrow
    // Exception table:
    //   from	to	target	type
    //   2	12	16	finally
  }
  
  public ColorStateList d(Context paramContext, int paramInt) {
    // Byte code:
    //   0: aload_0
    //   1: monitorenter
    //   2: aload_0
    //   3: getfield a : Landroidx/appcompat/widget/o0;
    //   6: aload_1
    //   7: iload_2
    //   8: invokevirtual i : (Landroid/content/Context;I)Landroid/content/res/ColorStateList;
    //   11: astore_1
    //   12: aload_0
    //   13: monitorexit
    //   14: aload_1
    //   15: areturn
    //   16: astore_1
    //   17: aload_0
    //   18: monitorexit
    //   19: aload_1
    //   20: athrow
    // Exception table:
    //   from	to	target	type
    //   2	12	16	finally
  }
  
  public class a implements o0.e {
    public final int[] a = new int[] { 2131230810, 2131230808, 2131230727 };
    
    public final int[] b = new int[] { 2131230751, 2131230792, 2131230758, 2131230753, 2131230754, 2131230757, 2131230756 };
    
    public final int[] c = new int[] { 2131230807, 2131230809, 2131230744, 2131230800, 2131230801, 2131230803, 2131230805, 2131230802, 2131230804, 2131230806 };
    
    public final int[] d = new int[] { 2131230782, 2131230742, 2131230781 };
    
    public final int[] e = new int[] { 2131230798, 2131230811 };
    
    public final int[] f = new int[] { 2131230730, 2131230736, 2131230731, 2131230737 };
    
    public final boolean a(int[] param1ArrayOfint, int param1Int) {
      int j = param1ArrayOfint.length;
      for (int i = 0; i < j; i++) {
        if (param1ArrayOfint[i] == param1Int)
          return true; 
      } 
      return false;
    }
    
    public final ColorStateList b(Context param1Context, int param1Int) {
      int k = u0.c(param1Context, 2130968767);
      int i = u0.b(param1Context, 2130968765);
      int[] arrayOfInt1 = u0.b;
      int[] arrayOfInt2 = u0.d;
      int j = d0.a.a(k, param1Int);
      int[] arrayOfInt3 = u0.c;
      k = d0.a.a(k, param1Int);
      return new ColorStateList(new int[][] { arrayOfInt1, arrayOfInt2, arrayOfInt3, u0.f }, new int[] { i, j, k, param1Int });
    }
    
    public ColorStateList c(Context param1Context, int param1Int) {
      if (param1Int == 2131230747)
        return g.a.a(param1Context, 2131099669); 
      if (param1Int == 2131230797)
        return g.a.a(param1Context, 2131099672); 
      if (param1Int == 2131230796) {
        int[][] arrayOfInt = new int[3][];
        int[] arrayOfInt1 = new int[3];
        ColorStateList colorStateList = u0.d(param1Context, 2130968784);
        if (colorStateList != null && colorStateList.isStateful()) {
          arrayOfInt[0] = u0.b;
          arrayOfInt1[0] = colorStateList.getColorForState(arrayOfInt[0], 0);
          arrayOfInt[1] = u0.e;
          arrayOfInt1[1] = u0.c(param1Context, 2130968766);
          arrayOfInt[2] = u0.f;
          arrayOfInt1[2] = colorStateList.getDefaultColor();
        } else {
          arrayOfInt[0] = u0.b;
          arrayOfInt1[0] = u0.b(param1Context, 2130968784);
          arrayOfInt[1] = u0.e;
          arrayOfInt1[1] = u0.c(param1Context, 2130968766);
          arrayOfInt[2] = u0.f;
          arrayOfInt1[2] = u0.c(param1Context, 2130968784);
        } 
        return new ColorStateList(arrayOfInt, arrayOfInt1);
      } 
      return (param1Int == 2131230735) ? b(param1Context, u0.c(param1Context, 2130968765)) : ((param1Int == 2131230729) ? b(param1Context, 0) : ((param1Int == 2131230734) ? b(param1Context, u0.c(param1Context, 2130968763)) : ((param1Int == 2131230794 || param1Int == 2131230795) ? g.a.a(param1Context, 2131099671) : (a(this.b, param1Int) ? u0.d(param1Context, 2130968768) : (a(this.e, param1Int) ? g.a.a(param1Context, 2131099668) : (a(this.f, param1Int) ? g.a.a(param1Context, 2131099667) : ((param1Int == 2131230791) ? g.a.a(param1Context, 2131099670) : null)))))));
    }
    
    public final void d(Drawable param1Drawable, int param1Int, PorterDuff.Mode param1Mode) {
      Drawable drawable = param1Drawable;
      if (f0.a(param1Drawable))
        drawable = param1Drawable.mutate(); 
      PorterDuff.Mode mode = param1Mode;
      if (param1Mode == null)
        mode = j.b; 
      drawable.setColorFilter((ColorFilter)j.c(param1Int, mode));
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Luxury Logo Maker_ Logo Design-dex2jar.jar!\androidx\appcompat\widget\j.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */