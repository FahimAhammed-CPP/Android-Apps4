package androidx.appcompat.widget;

import android.content.Context;
import android.content.res.ColorStateList;
import android.graphics.Bitmap;
import android.graphics.PorterDuff;
import android.graphics.drawable.Drawable;
import android.net.Uri;
import android.util.AttributeSet;
import android.view.View;
import android.widget.ImageButton;
import android.widget.ImageView;

public class l extends ImageButton {
  public final e h;
  
  public final m i;
  
  public l(Context paramContext, AttributeSet paramAttributeSet) {
    this(paramContext, paramAttributeSet, 2130968993);
  }
  
  public l(Context paramContext, AttributeSet paramAttributeSet, int paramInt) {
    super(paramContext, paramAttributeSet, paramInt);
    u0.a((View)this, getContext());
    e e1 = new e((View)this);
    this.h = e1;
    e1.d(paramAttributeSet, paramInt);
    m m1 = new m((ImageView)this);
    this.i = m1;
    m1.b(paramAttributeSet, paramInt);
  }
  
  public void drawableStateChanged() {
    super.drawableStateChanged();
    e e1 = this.h;
    if (e1 != null)
      e1.a(); 
    m m1 = this.i;
    if (m1 != null)
      m1.a(); 
  }
  
  public ColorStateList getSupportBackgroundTintList() {
    e e1 = this.h;
    return (e1 != null) ? e1.b() : null;
  }
  
  public PorterDuff.Mode getSupportBackgroundTintMode() {
    e e1 = this.h;
    return (e1 != null) ? e1.c() : null;
  }
  
  public ColorStateList getSupportImageTintList() {
    m m1 = this.i;
    if (m1 != null) {
      x0 x0 = m1.b;
      if (x0 != null)
        return x0.a; 
    } 
    return null;
  }
  
  public PorterDuff.Mode getSupportImageTintMode() {
    m m1 = this.i;
    if (m1 != null) {
      x0 x0 = m1.b;
      if (x0 != null)
        return x0.b; 
    } 
    return null;
  }
  
  public boolean hasOverlappingRendering() {
    return ((this.i.a.getBackground() instanceof android.graphics.drawable.RippleDrawable ^ true) != 0 && super.hasOverlappingRendering());
  }
  
  public void setBackgroundDrawable(Drawable paramDrawable) {
    super.setBackgroundDrawable(paramDrawable);
    e e1 = this.h;
    if (e1 != null)
      e1.e(); 
  }
  
  public void setBackgroundResource(int paramInt) {
    super.setBackgroundResource(paramInt);
    e e1 = this.h;
    if (e1 != null)
      e1.f(paramInt); 
  }
  
  public void setImageBitmap(Bitmap paramBitmap) {
    super.setImageBitmap(paramBitmap);
    m m1 = this.i;
    if (m1 != null)
      m1.a(); 
  }
  
  public void setImageDrawable(Drawable paramDrawable) {
    super.setImageDrawable(paramDrawable);
    m m1 = this.i;
    if (m1 != null)
      m1.a(); 
  }
  
  public void setImageResource(int paramInt) {
    this.i.c(paramInt);
  }
  
  public void setImageURI(Uri paramUri) {
    super.setImageURI(paramUri);
    m m1 = this.i;
    if (m1 != null)
      m1.a(); 
  }
  
  public void setSupportBackgroundTintList(ColorStateList paramColorStateList) {
    e e1 = this.h;
    if (e1 != null)
      e1.h(paramColorStateList); 
  }
  
  public void setSupportBackgroundTintMode(PorterDuff.Mode paramMode) {
    e e1 = this.h;
    if (e1 != null)
      e1.i(paramMode); 
  }
  
  public void setSupportImageTintList(ColorStateList paramColorStateList) {
    m m1 = this.i;
    if (m1 != null)
      m1.d(paramColorStateList); 
  }
  
  public void setSupportImageTintMode(PorterDuff.Mode paramMode) {
    m m1 = this.i;
    if (m1 != null)
      m1.e(paramMode); 
  }
}


/* Location:              C:\soft\dex2jar-2.0\Luxury Logo Maker_ Logo Design-dex2jar.jar!\androidx\appcompat\widget\l.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */