package androidx.appcompat.widget;

import android.content.res.ColorStateList;
import android.graphics.PorterDuff;
import android.graphics.drawable.Drawable;
import android.os.Build;
import android.util.AttributeSet;
import android.view.View;
import java.util.WeakHashMap;
import k0.l;

public class e {
  public final View a;
  
  public final j b;
  
  public int c = -1;
  
  public x0 d;
  
  public x0 e;
  
  public x0 f;
  
  public e(View paramView) {
    this.a = paramView;
    this.b = j.a();
  }
  
  public void a() {
    Drawable drawable = this.a.getBackground();
    if (drawable != null) {
      int i = Build.VERSION.SDK_INT;
      boolean bool = true;
      if ((i > 21) ? (this.d != null) : (i == 21)) {
        i = 1;
      } else {
        i = 0;
      } 
      if (i != 0) {
        if (this.f == null)
          this.f = new x0(); 
        x0 x02 = this.f;
        x02.a = null;
        x02.d = false;
        x02.b = null;
        x02.c = false;
        View view = this.a;
        WeakHashMap weakHashMap = l.a;
        ColorStateList colorStateList = view.getBackgroundTintList();
        if (colorStateList != null) {
          x02.d = true;
          x02.a = colorStateList;
        } 
        PorterDuff.Mode mode = this.a.getBackgroundTintMode();
        if (mode != null) {
          x02.c = true;
          x02.b = mode;
        } 
        if (x02.d || x02.c) {
          j.f(drawable, x02, this.a.getDrawableState());
          i = bool;
        } else {
          i = 0;
        } 
        if (i != 0)
          return; 
      } 
      x0 x01 = this.e;
      if (x01 != null) {
        j.f(drawable, x01, this.a.getDrawableState());
        return;
      } 
      x01 = this.d;
      if (x01 != null)
        j.f(drawable, x01, this.a.getDrawableState()); 
    } 
  }
  
  public ColorStateList b() {
    x0 x01 = this.e;
    return (x01 != null) ? x01.a : null;
  }
  
  public PorterDuff.Mode c() {
    x0 x01 = this.e;
    return (x01 != null) ? x01.b : null;
  }
  
  public void d(AttributeSet paramAttributeSet, int paramInt) {
    // Byte code:
    //   0: aload_0
    //   1: getfield a : Landroid/view/View;
    //   4: invokevirtual getContext : ()Landroid/content/Context;
    //   7: astore #4
    //   9: getstatic com/bumptech/glide/manager/b.G : [I
    //   12: astore #5
    //   14: iconst_0
    //   15: istore_3
    //   16: aload #4
    //   18: aload_1
    //   19: aload #5
    //   21: iload_2
    //   22: iconst_0
    //   23: invokestatic q : (Landroid/content/Context;Landroid/util/AttributeSet;[III)Landroidx/appcompat/widget/z0;
    //   26: astore #4
    //   28: aload_0
    //   29: getfield a : Landroid/view/View;
    //   32: astore #6
    //   34: aload #6
    //   36: aload #6
    //   38: invokevirtual getContext : ()Landroid/content/Context;
    //   41: aload #5
    //   43: aload_1
    //   44: aload #4
    //   46: getfield b : Landroid/content/res/TypedArray;
    //   49: iload_2
    //   50: iconst_0
    //   51: invokestatic r : (Landroid/view/View;Landroid/content/Context;[ILandroid/util/AttributeSet;Landroid/content/res/TypedArray;II)V
    //   54: aload #4
    //   56: iconst_0
    //   57: invokevirtual o : (I)Z
    //   60: ifeq -> 102
    //   63: aload_0
    //   64: aload #4
    //   66: iconst_0
    //   67: iconst_m1
    //   68: invokevirtual l : (II)I
    //   71: putfield c : I
    //   74: aload_0
    //   75: getfield b : Landroidx/appcompat/widget/j;
    //   78: aload_0
    //   79: getfield a : Landroid/view/View;
    //   82: invokevirtual getContext : ()Landroid/content/Context;
    //   85: aload_0
    //   86: getfield c : I
    //   89: invokevirtual d : (Landroid/content/Context;I)Landroid/content/res/ColorStateList;
    //   92: astore_1
    //   93: aload_1
    //   94: ifnull -> 102
    //   97: aload_0
    //   98: aload_1
    //   99: invokevirtual g : (Landroid/content/res/ColorStateList;)V
    //   102: aload #4
    //   104: iconst_1
    //   105: invokevirtual o : (I)Z
    //   108: ifeq -> 199
    //   111: aload_0
    //   112: getfield a : Landroid/view/View;
    //   115: astore_1
    //   116: aload #4
    //   118: iconst_1
    //   119: invokevirtual c : (I)Landroid/content/res/ColorStateList;
    //   122: astore #5
    //   124: getstatic android/os/Build$VERSION.SDK_INT : I
    //   127: istore_2
    //   128: aload_1
    //   129: aload #5
    //   131: invokevirtual setBackgroundTintList : (Landroid/content/res/ColorStateList;)V
    //   134: iload_2
    //   135: bipush #21
    //   137: if_icmpne -> 199
    //   140: aload_1
    //   141: invokevirtual getBackground : ()Landroid/graphics/drawable/Drawable;
    //   144: astore #5
    //   146: aload_1
    //   147: invokevirtual getBackgroundTintList : ()Landroid/content/res/ColorStateList;
    //   150: ifnonnull -> 324
    //   153: aload_1
    //   154: invokevirtual getBackgroundTintMode : ()Landroid/graphics/PorterDuff$Mode;
    //   157: ifnull -> 319
    //   160: goto -> 324
    //   163: aload #5
    //   165: ifnull -> 199
    //   168: iload_2
    //   169: ifeq -> 199
    //   172: aload #5
    //   174: invokevirtual isStateful : ()Z
    //   177: ifeq -> 193
    //   180: aload #5
    //   182: aload_1
    //   183: invokevirtual getDrawableState : ()[I
    //   186: invokevirtual setState : ([I)Z
    //   189: pop
    //   190: goto -> 193
    //   193: aload_1
    //   194: aload #5
    //   196: invokevirtual setBackground : (Landroid/graphics/drawable/Drawable;)V
    //   199: aload #4
    //   201: iconst_2
    //   202: invokevirtual o : (I)Z
    //   205: ifeq -> 300
    //   208: aload_0
    //   209: getfield a : Landroid/view/View;
    //   212: astore_1
    //   213: aload #4
    //   215: iconst_2
    //   216: iconst_m1
    //   217: invokevirtual j : (II)I
    //   220: aconst_null
    //   221: invokestatic c : (ILandroid/graphics/PorterDuff$Mode;)Landroid/graphics/PorterDuff$Mode;
    //   224: astore #5
    //   226: getstatic android/os/Build$VERSION.SDK_INT : I
    //   229: istore_2
    //   230: aload_1
    //   231: aload #5
    //   233: invokevirtual setBackgroundTintMode : (Landroid/graphics/PorterDuff$Mode;)V
    //   236: iload_2
    //   237: bipush #21
    //   239: if_icmpne -> 300
    //   242: aload_1
    //   243: invokevirtual getBackground : ()Landroid/graphics/drawable/Drawable;
    //   246: astore #5
    //   248: aload_1
    //   249: invokevirtual getBackgroundTintList : ()Landroid/content/res/ColorStateList;
    //   252: ifnonnull -> 333
    //   255: iload_3
    //   256: istore_2
    //   257: aload_1
    //   258: invokevirtual getBackgroundTintMode : ()Landroid/graphics/PorterDuff$Mode;
    //   261: ifnull -> 267
    //   264: goto -> 333
    //   267: aload #5
    //   269: ifnull -> 300
    //   272: iload_2
    //   273: ifeq -> 300
    //   276: aload #5
    //   278: invokevirtual isStateful : ()Z
    //   281: ifeq -> 294
    //   284: aload #5
    //   286: aload_1
    //   287: invokevirtual getDrawableState : ()[I
    //   290: invokevirtual setState : ([I)Z
    //   293: pop
    //   294: aload_1
    //   295: aload #5
    //   297: invokevirtual setBackground : (Landroid/graphics/drawable/Drawable;)V
    //   300: aload #4
    //   302: getfield b : Landroid/content/res/TypedArray;
    //   305: invokevirtual recycle : ()V
    //   308: return
    //   309: aload #4
    //   311: getfield b : Landroid/content/res/TypedArray;
    //   314: invokevirtual recycle : ()V
    //   317: aload_1
    //   318: athrow
    //   319: iconst_0
    //   320: istore_2
    //   321: goto -> 163
    //   324: iconst_1
    //   325: istore_2
    //   326: goto -> 163
    //   329: astore_1
    //   330: goto -> 309
    //   333: iconst_1
    //   334: istore_2
    //   335: goto -> 267
    // Exception table:
    //   from	to	target	type
    //   54	93	329	finally
    //   97	102	329	finally
    //   102	134	329	finally
    //   140	160	329	finally
    //   172	190	329	finally
    //   193	199	329	finally
    //   199	236	329	finally
    //   242	255	329	finally
    //   257	264	329	finally
    //   276	294	329	finally
    //   294	300	329	finally
  }
  
  public void e() {
    this.c = -1;
    g(null);
    a();
  }
  
  public void f(int paramInt) {
    this.c = paramInt;
    j j1 = this.b;
    if (j1 != null) {
      ColorStateList colorStateList = j1.d(this.a.getContext(), paramInt);
    } else {
      j1 = null;
    } 
    g((ColorStateList)j1);
    a();
  }
  
  public void g(ColorStateList paramColorStateList) {
    if (paramColorStateList != null) {
      if (this.d == null)
        this.d = new x0(); 
      x0 x01 = this.d;
      x01.a = paramColorStateList;
      x01.d = true;
    } else {
      this.d = null;
    } 
    a();
  }
  
  public void h(ColorStateList paramColorStateList) {
    if (this.e == null)
      this.e = new x0(); 
    x0 x01 = this.e;
    x01.a = paramColorStateList;
    x01.d = true;
    a();
  }
  
  public void i(PorterDuff.Mode paramMode) {
    if (this.e == null)
      this.e = new x0(); 
    x0 x01 = this.e;
    x01.b = paramMode;
    x01.c = true;
    a();
  }
}


/* Location:              C:\soft\dex2jar-2.0\Luxury Logo Maker_ Logo Design-dex2jar.jar!\androidx\appcompat\widget\e.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */