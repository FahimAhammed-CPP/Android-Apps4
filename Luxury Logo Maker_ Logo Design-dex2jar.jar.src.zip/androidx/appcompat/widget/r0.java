package androidx.appcompat.widget;

import android.content.Context;
import android.content.res.Configuration;
import android.content.res.Resources;
import android.content.res.TypedArray;
import android.view.View;
import android.view.accessibility.AccessibilityEvent;
import android.view.accessibility.AccessibilityNodeInfo;
import android.view.animation.DecelerateInterpolator;
import android.widget.AdapterView;
import android.widget.HorizontalScrollView;
import android.widget.LinearLayout;
import com.bumptech.glide.manager.b;
import java.util.Objects;

public class r0 extends HorizontalScrollView implements AdapterView.OnItemSelectedListener {
  public int h;
  
  public int i;
  
  static {
    new DecelerateInterpolator();
  }
  
  public void onAttachedToWindow() {
    super.onAttachedToWindow();
  }
  
  public void onConfigurationChanged(Configuration paramConfiguration) {
    super.onConfigurationChanged(paramConfiguration);
    Context context = getContext();
    TypedArray typedArray = context.obtainStyledAttributes(null, b.h, 2130968581, 0);
    int j = typedArray.getLayoutDimension(13, 0);
    Resources resources = context.getResources();
    int i = j;
    if (!context.getResources().getBoolean(2131034112))
      i = Math.min(j, resources.getDimensionPixelSize(2131165911)); 
    typedArray.recycle();
    setContentHeight(i);
    context.getResources().getDimensionPixelSize(2131165912);
  }
  
  public void onDetachedFromWindow() {
    super.onDetachedFromWindow();
  }
  
  public void onItemSelected(AdapterView<?> paramAdapterView, View paramView, int paramInt, long paramLong) {
    ((a)paramView).h.a();
  }
  
  public void onMeasure(int paramInt1, int paramInt2) {
    boolean bool;
    if (View.MeasureSpec.getMode(paramInt1) == 1073741824) {
      bool = true;
    } else {
      bool = false;
    } 
    setFillViewport(bool);
    throw null;
  }
  
  public void onNothingSelected(AdapterView<?> paramAdapterView) {}
  
  public void setAllowCollapse(boolean paramBoolean) {}
  
  public void setContentHeight(int paramInt) {
    this.h = paramInt;
    requestLayout();
  }
  
  public void setTabSelected(int paramInt) {
    this.i = paramInt;
    throw null;
  }
  
  public class a extends LinearLayout {
    public f.a.c h;
    
    public void onInitializeAccessibilityEvent(AccessibilityEvent param1AccessibilityEvent) {
      super.onInitializeAccessibilityEvent(param1AccessibilityEvent);
      param1AccessibilityEvent.setClassName("androidx.appcompat.app.ActionBar$Tab");
    }
    
    public void onInitializeAccessibilityNodeInfo(AccessibilityNodeInfo param1AccessibilityNodeInfo) {
      super.onInitializeAccessibilityNodeInfo(param1AccessibilityNodeInfo);
      param1AccessibilityNodeInfo.setClassName("androidx.appcompat.app.ActionBar$Tab");
    }
    
    public void onMeasure(int param1Int1, int param1Int2) {
      super.onMeasure(param1Int1, param1Int2);
      Objects.requireNonNull(this.i);
    }
    
    public void setSelected(boolean param1Boolean) {
      boolean bool;
      if (isSelected() != param1Boolean) {
        bool = true;
      } else {
        bool = false;
      } 
      super.setSelected(param1Boolean);
      if (bool && param1Boolean)
        sendAccessibilityEvent(4); 
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Luxury Logo Maker_ Logo Design-dex2jar.jar!\androidx\appcompat\widget\r0.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */