package androidx.appcompat.widget;

import android.content.Context;
import android.content.res.ColorStateList;
import android.graphics.PorterDuff;
import android.graphics.drawable.Drawable;
import android.util.AttributeSet;
import android.view.View;
import android.widget.CheckBox;
import android.widget.CompoundButton;
import android.widget.TextView;
import g.a;

public class g extends CheckBox {
  public final i h;
  
  public final e i;
  
  public final z j;
  
  public g(Context paramContext, AttributeSet paramAttributeSet) {
    this(paramContext, paramAttributeSet, 2130968710);
  }
  
  public g(Context paramContext, AttributeSet paramAttributeSet, int paramInt) {
    super(paramContext, paramAttributeSet, paramInt);
    u0.a((View)this, getContext());
    i i1 = new i((CompoundButton)this);
    this.h = i1;
    i1.b(paramAttributeSet, paramInt);
    e e1 = new e((View)this);
    this.i = e1;
    e1.d(paramAttributeSet, paramInt);
    z z1 = new z((TextView)this);
    this.j = z1;
    z1.e(paramAttributeSet, paramInt);
  }
  
  public void drawableStateChanged() {
    super.drawableStateChanged();
    e e1 = this.i;
    if (e1 != null)
      e1.a(); 
    z z1 = this.j;
    if (z1 != null)
      z1.b(); 
  }
  
  public int getCompoundPaddingLeft() {
    return super.getCompoundPaddingLeft();
  }
  
  public ColorStateList getSupportBackgroundTintList() {
    e e1 = this.i;
    return (e1 != null) ? e1.b() : null;
  }
  
  public PorterDuff.Mode getSupportBackgroundTintMode() {
    e e1 = this.i;
    return (e1 != null) ? e1.c() : null;
  }
  
  public ColorStateList getSupportButtonTintList() {
    i i1 = this.h;
    return (i1 != null) ? i1.b : null;
  }
  
  public PorterDuff.Mode getSupportButtonTintMode() {
    i i1 = this.h;
    return (i1 != null) ? i1.c : null;
  }
  
  public void setBackgroundDrawable(Drawable paramDrawable) {
    super.setBackgroundDrawable(paramDrawable);
    e e1 = this.i;
    if (e1 != null)
      e1.e(); 
  }
  
  public void setBackgroundResource(int paramInt) {
    super.setBackgroundResource(paramInt);
    e e1 = this.i;
    if (e1 != null)
      e1.f(paramInt); 
  }
  
  public void setButtonDrawable(int paramInt) {
    setButtonDrawable(a.b(getContext(), paramInt));
  }
  
  public void setButtonDrawable(Drawable paramDrawable) {
    super.setButtonDrawable(paramDrawable);
    i i1 = this.h;
    if (i1 != null) {
      if (i1.f) {
        i1.f = false;
        return;
      } 
      i1.f = true;
      i1.a();
    } 
  }
  
  public void setSupportBackgroundTintList(ColorStateList paramColorStateList) {
    e e1 = this.i;
    if (e1 != null)
      e1.h(paramColorStateList); 
  }
  
  public void setSupportBackgroundTintMode(PorterDuff.Mode paramMode) {
    e e1 = this.i;
    if (e1 != null)
      e1.i(paramMode); 
  }
  
  public void setSupportButtonTintList(ColorStateList paramColorStateList) {
    i i1 = this.h;
    if (i1 != null) {
      i1.b = paramColorStateList;
      i1.d = true;
      i1.a();
    } 
  }
  
  public void setSupportButtonTintMode(PorterDuff.Mode paramMode) {
    i i1 = this.h;
    if (i1 != null) {
      i1.c = paramMode;
      i1.e = true;
      i1.a();
    } 
  }
}


/* Location:              C:\soft\dex2jar-2.0\Luxury Logo Maker_ Logo Design-dex2jar.jar!\androidx\appcompat\widget\g.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */