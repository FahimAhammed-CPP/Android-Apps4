package androidx.appcompat.widget;

import android.content.Context;
import android.content.res.ColorStateList;
import android.graphics.PorterDuff;
import android.graphics.drawable.Drawable;
import android.util.AttributeSet;
import android.view.View;
import android.view.inputmethod.EditorInfo;
import android.view.inputmethod.InputConnection;
import android.widget.MultiAutoCompleteTextView;
import android.widget.TextView;
import b4.a;
import g.a;

public class o extends MultiAutoCompleteTextView {
  public static final int[] j = new int[] { 16843126 };
  
  public final e h;
  
  public final z i;
  
  public o(Context paramContext, AttributeSet paramAttributeSet) {
    super(paramContext, paramAttributeSet, 2130968630);
    u0.a((View)this, getContext());
    z0 z0 = z0.q(getContext(), paramAttributeSet, j, 2130968630, 0);
    if (z0.o(0))
      setDropDownBackgroundDrawable(z0.g(0)); 
    z0.b.recycle();
    e e1 = new e((View)this);
    this.h = e1;
    e1.d(paramAttributeSet, 2130968630);
    z z1 = new z((TextView)this);
    this.i = z1;
    z1.e(paramAttributeSet, 2130968630);
    z1.b();
  }
  
  public void drawableStateChanged() {
    super.drawableStateChanged();
    e e1 = this.h;
    if (e1 != null)
      e1.a(); 
    z z1 = this.i;
    if (z1 != null)
      z1.b(); 
  }
  
  public ColorStateList getSupportBackgroundTintList() {
    e e1 = this.h;
    return (e1 != null) ? e1.b() : null;
  }
  
  public PorterDuff.Mode getSupportBackgroundTintMode() {
    e e1 = this.h;
    return (e1 != null) ? e1.c() : null;
  }
  
  public InputConnection onCreateInputConnection(EditorInfo paramEditorInfo) {
    InputConnection inputConnection = super.onCreateInputConnection(paramEditorInfo);
    a.c(inputConnection, paramEditorInfo, (View)this);
    return inputConnection;
  }
  
  public void setBackgroundDrawable(Drawable paramDrawable) {
    super.setBackgroundDrawable(paramDrawable);
    e e1 = this.h;
    if (e1 != null)
      e1.e(); 
  }
  
  public void setBackgroundResource(int paramInt) {
    super.setBackgroundResource(paramInt);
    e e1 = this.h;
    if (e1 != null)
      e1.f(paramInt); 
  }
  
  public void setDropDownBackgroundResource(int paramInt) {
    setDropDownBackgroundDrawable(a.b(getContext(), paramInt));
  }
  
  public void setSupportBackgroundTintList(ColorStateList paramColorStateList) {
    e e1 = this.h;
    if (e1 != null)
      e1.h(paramColorStateList); 
  }
  
  public void setSupportBackgroundTintMode(PorterDuff.Mode paramMode) {
    e e1 = this.h;
    if (e1 != null)
      e1.i(paramMode); 
  }
  
  public void setTextAppearance(Context paramContext, int paramInt) {
    super.setTextAppearance(paramContext, paramInt);
    z z1 = this.i;
    if (z1 != null)
      z1.f(paramContext, paramInt); 
  }
}


/* Location:              C:\soft\dex2jar-2.0\Luxury Logo Maker_ Logo Design-dex2jar.jar!\androidx\appcompat\widget\o.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */