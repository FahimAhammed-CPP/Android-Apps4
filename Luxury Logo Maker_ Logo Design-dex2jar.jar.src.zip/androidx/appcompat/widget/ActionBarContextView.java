package androidx.appcompat.widget;

import android.content.Context;
import android.text.TextUtils;
import android.util.AttributeSet;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.accessibility.AccessibilityEvent;
import android.widget.LinearLayout;
import android.widget.TextView;

public class ActionBarContextView extends a {
  public CharSequence p;
  
  public CharSequence q;
  
  public View r;
  
  public View s;
  
  public LinearLayout t;
  
  public TextView u;
  
  public TextView v;
  
  public int w;
  
  public int x;
  
  public boolean y;
  
  public int z;
  
  public ActionBarContextView(Context paramContext, AttributeSet paramAttributeSet) {
    // Byte code:
    //   0: aload_0
    //   1: aload_1
    //   2: aload_2
    //   3: ldc 2130968603
    //   5: invokespecial <init> : (Landroid/content/Context;Landroid/util/AttributeSet;I)V
    //   8: aload_1
    //   9: aload_2
    //   10: getstatic com/bumptech/glide/manager/b.k : [I
    //   13: ldc 2130968603
    //   15: iconst_0
    //   16: invokevirtual obtainStyledAttributes : (Landroid/util/AttributeSet;[III)Landroid/content/res/TypedArray;
    //   19: astore_2
    //   20: aload_2
    //   21: iconst_0
    //   22: invokevirtual hasValue : (I)Z
    //   25: ifeq -> 48
    //   28: aload_2
    //   29: iconst_0
    //   30: iconst_0
    //   31: invokevirtual getResourceId : (II)I
    //   34: istore_3
    //   35: iload_3
    //   36: ifeq -> 48
    //   39: aload_1
    //   40: iload_3
    //   41: invokestatic b : (Landroid/content/Context;I)Landroid/graphics/drawable/Drawable;
    //   44: astore_1
    //   45: goto -> 54
    //   48: aload_2
    //   49: iconst_0
    //   50: invokevirtual getDrawable : (I)Landroid/graphics/drawable/Drawable;
    //   53: astore_1
    //   54: getstatic k0/l.a : Ljava/util/WeakHashMap;
    //   57: astore #4
    //   59: aload_0
    //   60: aload_1
    //   61: invokevirtual setBackground : (Landroid/graphics/drawable/Drawable;)V
    //   64: aload_0
    //   65: aload_2
    //   66: iconst_5
    //   67: iconst_0
    //   68: invokevirtual getResourceId : (II)I
    //   71: putfield w : I
    //   74: aload_0
    //   75: aload_2
    //   76: iconst_4
    //   77: iconst_0
    //   78: invokevirtual getResourceId : (II)I
    //   81: putfield x : I
    //   84: aload_0
    //   85: aload_2
    //   86: iconst_3
    //   87: iconst_0
    //   88: invokevirtual getLayoutDimension : (II)I
    //   91: putfield l : I
    //   94: aload_0
    //   95: aload_2
    //   96: iconst_2
    //   97: ldc 2131558405
    //   99: invokevirtual getResourceId : (II)I
    //   102: putfield z : I
    //   105: aload_2
    //   106: invokevirtual recycle : ()V
    //   109: return
  }
  
  public void f(j.a parama) {
    // Byte code:
    //   0: aload_0
    //   1: getfield r : Landroid/view/View;
    //   4: astore_2
    //   5: aload_2
    //   6: ifnonnull -> 34
    //   9: aload_0
    //   10: invokevirtual getContext : ()Landroid/content/Context;
    //   13: invokestatic from : (Landroid/content/Context;)Landroid/view/LayoutInflater;
    //   16: aload_0
    //   17: getfield z : I
    //   20: aload_0
    //   21: iconst_0
    //   22: invokevirtual inflate : (ILandroid/view/ViewGroup;Z)Landroid/view/View;
    //   25: astore_2
    //   26: aload_0
    //   27: aload_2
    //   28: putfield r : Landroid/view/View;
    //   31: goto -> 46
    //   34: aload_2
    //   35: invokevirtual getParent : ()Landroid/view/ViewParent;
    //   38: ifnonnull -> 51
    //   41: aload_0
    //   42: getfield r : Landroid/view/View;
    //   45: astore_2
    //   46: aload_0
    //   47: aload_2
    //   48: invokevirtual addView : (Landroid/view/View;)V
    //   51: aload_0
    //   52: getfield r : Landroid/view/View;
    //   55: ldc 2131361856
    //   57: invokevirtual findViewById : (I)Landroid/view/View;
    //   60: new androidx/appcompat/widget/ActionBarContextView$a
    //   63: dup
    //   64: aload_0
    //   65: aload_1
    //   66: invokespecial <init> : (Landroidx/appcompat/widget/ActionBarContextView;Lj/a;)V
    //   69: invokevirtual setOnClickListener : (Landroid/view/View$OnClickListener;)V
    //   72: aload_1
    //   73: invokevirtual e : ()Landroid/view/Menu;
    //   76: checkcast androidx/appcompat/view/menu/e
    //   79: astore_2
    //   80: aload_0
    //   81: getfield k : Landroidx/appcompat/widget/c;
    //   84: astore_1
    //   85: aload_1
    //   86: ifnull -> 94
    //   89: aload_1
    //   90: invokevirtual b : ()Z
    //   93: pop
    //   94: new androidx/appcompat/widget/c
    //   97: dup
    //   98: aload_0
    //   99: invokevirtual getContext : ()Landroid/content/Context;
    //   102: invokespecial <init> : (Landroid/content/Context;)V
    //   105: astore_1
    //   106: aload_0
    //   107: aload_1
    //   108: putfield k : Landroidx/appcompat/widget/c;
    //   111: aload_1
    //   112: iconst_1
    //   113: putfield s : Z
    //   116: aload_1
    //   117: iconst_1
    //   118: putfield t : Z
    //   121: new android/view/ViewGroup$LayoutParams
    //   124: dup
    //   125: bipush #-2
    //   127: iconst_m1
    //   128: invokespecial <init> : (II)V
    //   131: astore_1
    //   132: aload_2
    //   133: aload_0
    //   134: getfield k : Landroidx/appcompat/widget/c;
    //   137: aload_0
    //   138: getfield i : Landroid/content/Context;
    //   141: invokevirtual b : (Landroidx/appcompat/view/menu/i;Landroid/content/Context;)V
    //   144: aload_0
    //   145: getfield k : Landroidx/appcompat/widget/c;
    //   148: astore_2
    //   149: aload_2
    //   150: getfield o : Landroidx/appcompat/view/menu/j;
    //   153: astore_3
    //   154: aload_3
    //   155: ifnonnull -> 198
    //   158: aload_2
    //   159: getfield k : Landroid/view/LayoutInflater;
    //   162: aload_2
    //   163: getfield m : I
    //   166: aload_0
    //   167: iconst_0
    //   168: invokevirtual inflate : (ILandroid/view/ViewGroup;Z)Landroid/view/View;
    //   171: checkcast androidx/appcompat/view/menu/j
    //   174: astore #4
    //   176: aload_2
    //   177: aload #4
    //   179: putfield o : Landroidx/appcompat/view/menu/j;
    //   182: aload #4
    //   184: aload_2
    //   185: getfield j : Landroidx/appcompat/view/menu/e;
    //   188: invokeinterface b : (Landroidx/appcompat/view/menu/e;)V
    //   193: aload_2
    //   194: iconst_1
    //   195: invokevirtual f : (Z)V
    //   198: aload_2
    //   199: getfield o : Landroidx/appcompat/view/menu/j;
    //   202: astore #4
    //   204: aload_3
    //   205: aload #4
    //   207: if_acmpeq -> 219
    //   210: aload #4
    //   212: checkcast androidx/appcompat/widget/ActionMenuView
    //   215: aload_2
    //   216: invokevirtual setPresenter : (Landroidx/appcompat/widget/c;)V
    //   219: aload #4
    //   221: checkcast androidx/appcompat/widget/ActionMenuView
    //   224: astore_2
    //   225: aload_0
    //   226: aload_2
    //   227: putfield j : Landroidx/appcompat/widget/ActionMenuView;
    //   230: getstatic k0/l.a : Ljava/util/WeakHashMap;
    //   233: astore_3
    //   234: aload_2
    //   235: aconst_null
    //   236: invokevirtual setBackground : (Landroid/graphics/drawable/Drawable;)V
    //   239: aload_0
    //   240: aload_0
    //   241: getfield j : Landroidx/appcompat/widget/ActionMenuView;
    //   244: aload_1
    //   245: invokevirtual addView : (Landroid/view/View;Landroid/view/ViewGroup$LayoutParams;)V
    //   248: return
  }
  
  public final void g() {
    if (this.t == null) {
      LayoutInflater.from(getContext()).inflate(2131558400, this);
      LinearLayout linearLayout1 = (LinearLayout)getChildAt(getChildCount() - 1);
      this.t = linearLayout1;
      this.u = (TextView)linearLayout1.findViewById(2131361847);
      this.v = (TextView)this.t.findViewById(2131361846);
      if (this.w != 0)
        this.u.setTextAppearance(getContext(), this.w); 
      if (this.x != 0)
        this.v.setTextAppearance(getContext(), this.x); 
    } 
    this.u.setText(this.p);
    this.v.setText(this.q);
    boolean bool1 = TextUtils.isEmpty(this.p);
    int i = TextUtils.isEmpty(this.q) ^ true;
    TextView textView = this.v;
    boolean bool = false;
    if (i != 0) {
      b = 0;
    } else {
      b = 8;
    } 
    textView.setVisibility(b);
    LinearLayout linearLayout = this.t;
    byte b = bool;
    if ((bool1 ^ true) == 0)
      if (i != 0) {
        b = bool;
      } else {
        b = 8;
      }  
    linearLayout.setVisibility(b);
    if (this.t.getParent() == null)
      addView((View)this.t); 
  }
  
  public ViewGroup.LayoutParams generateDefaultLayoutParams() {
    return (ViewGroup.LayoutParams)new ViewGroup.MarginLayoutParams(-1, -2);
  }
  
  public ViewGroup.LayoutParams generateLayoutParams(AttributeSet paramAttributeSet) {
    return (ViewGroup.LayoutParams)new ViewGroup.MarginLayoutParams(getContext(), paramAttributeSet);
  }
  
  public CharSequence getSubtitle() {
    return this.q;
  }
  
  public CharSequence getTitle() {
    return this.p;
  }
  
  public void h() {
    removeAllViews();
    this.s = null;
    this.j = null;
  }
  
  public void onDetachedFromWindow() {
    super.onDetachedFromWindow();
    c c = this.k;
    if (c != null) {
      c.g();
      this.k.l();
    } 
  }
  
  public void onInitializeAccessibilityEvent(AccessibilityEvent paramAccessibilityEvent) {
    if (paramAccessibilityEvent.getEventType() == 32) {
      paramAccessibilityEvent.setSource((View)this);
      paramAccessibilityEvent.setClassName(getClass().getName());
      paramAccessibilityEvent.setPackageName(getContext().getPackageName());
      paramAccessibilityEvent.setContentDescription(this.p);
      return;
    } 
    super.onInitializeAccessibilityEvent(paramAccessibilityEvent);
  }
  
  public void onLayout(boolean paramBoolean, int paramInt1, int paramInt2, int paramInt3, int paramInt4) {
    int i;
    paramBoolean = g1.b((View)this);
    if (paramBoolean) {
      i = paramInt3 - paramInt1 - getPaddingRight();
    } else {
      i = getPaddingLeft();
    } 
    int j = getPaddingTop();
    int k = paramInt4 - paramInt2 - getPaddingTop() - getPaddingBottom();
    View view2 = this.r;
    paramInt2 = i;
    if (view2 != null) {
      paramInt2 = i;
      if (view2.getVisibility() != 8) {
        ViewGroup.MarginLayoutParams marginLayoutParams = (ViewGroup.MarginLayoutParams)this.r.getLayoutParams();
        if (paramBoolean) {
          paramInt4 = marginLayoutParams.rightMargin;
        } else {
          paramInt4 = marginLayoutParams.leftMargin;
        } 
        if (paramBoolean) {
          paramInt2 = marginLayoutParams.leftMargin;
        } else {
          paramInt2 = marginLayoutParams.rightMargin;
        } 
        if (paramBoolean) {
          paramInt4 = i - paramInt4;
        } else {
          paramInt4 = i + paramInt4;
        } 
        paramInt4 += d(this.r, paramInt4, j, k, paramBoolean);
        if (paramBoolean) {
          paramInt2 = paramInt4 - paramInt2;
        } else {
          paramInt2 = paramInt4 + paramInt2;
        } 
      } 
    } 
    LinearLayout linearLayout = this.t;
    paramInt4 = paramInt2;
    if (linearLayout != null) {
      paramInt4 = paramInt2;
      if (this.s == null) {
        paramInt4 = paramInt2;
        if (linearLayout.getVisibility() != 8)
          paramInt4 = paramInt2 + d((View)this.t, paramInt2, j, k, paramBoolean); 
      } 
    } 
    View view1 = this.s;
    if (view1 != null)
      d(view1, paramInt4, j, k, paramBoolean); 
    if (paramBoolean) {
      paramInt1 = getPaddingLeft();
    } else {
      paramInt1 = paramInt3 - paramInt1 - getPaddingRight();
    } 
    ActionMenuView actionMenuView = this.j;
    if (actionMenuView != null)
      d((View)actionMenuView, paramInt1, j, k, paramBoolean ^ true); 
  }
  
  public void onMeasure(int paramInt1, int paramInt2) {
    int i = View.MeasureSpec.getMode(paramInt1);
    int j = 1073741824;
    if (i == 1073741824) {
      if (View.MeasureSpec.getMode(paramInt2) != 0) {
        int n = View.MeasureSpec.getSize(paramInt1);
        i = this.l;
        if (i <= 0)
          i = View.MeasureSpec.getSize(paramInt2); 
        paramInt1 = getPaddingTop();
        int i1 = getPaddingBottom() + paramInt1;
        paramInt1 = n - getPaddingLeft() - getPaddingRight();
        int m = i - i1;
        int k = View.MeasureSpec.makeMeasureSpec(m, -2147483648);
        View view2 = this.r;
        boolean bool = false;
        paramInt2 = paramInt1;
        if (view2 != null) {
          paramInt1 = c(view2, paramInt1, k, 0);
          ViewGroup.MarginLayoutParams marginLayoutParams = (ViewGroup.MarginLayoutParams)this.r.getLayoutParams();
          paramInt2 = paramInt1 - marginLayoutParams.leftMargin + marginLayoutParams.rightMargin;
        } 
        ActionMenuView actionMenuView = this.j;
        paramInt1 = paramInt2;
        if (actionMenuView != null) {
          paramInt1 = paramInt2;
          if (actionMenuView.getParent() == this)
            paramInt1 = c((View)this.j, paramInt2, k, 0); 
        } 
        LinearLayout linearLayout = this.t;
        paramInt2 = paramInt1;
        if (linearLayout != null) {
          paramInt2 = paramInt1;
          if (this.s == null)
            if (this.y) {
              paramInt2 = View.MeasureSpec.makeMeasureSpec(0, 0);
              this.t.measure(paramInt2, k);
              int i2 = this.t.getMeasuredWidth();
              if (i2 <= paramInt1) {
                k = 1;
              } else {
                k = 0;
              } 
              paramInt2 = paramInt1;
              if (k != 0)
                paramInt2 = paramInt1 - i2; 
              linearLayout = this.t;
              if (k != 0) {
                paramInt1 = 0;
              } else {
                paramInt1 = 8;
              } 
              linearLayout.setVisibility(paramInt1);
            } else {
              paramInt2 = c((View)linearLayout, paramInt1, k, 0);
            }  
        } 
        View view1 = this.s;
        if (view1 != null) {
          ViewGroup.LayoutParams layoutParams = view1.getLayoutParams();
          int i2 = layoutParams.width;
          if (i2 != -2) {
            paramInt1 = 1073741824;
          } else {
            paramInt1 = Integer.MIN_VALUE;
          } 
          k = paramInt2;
          if (i2 >= 0)
            k = Math.min(i2, paramInt2); 
          i2 = layoutParams.height;
          if (i2 != -2) {
            paramInt2 = j;
          } else {
            paramInt2 = Integer.MIN_VALUE;
          } 
          j = m;
          if (i2 >= 0)
            j = Math.min(i2, m); 
          this.s.measure(View.MeasureSpec.makeMeasureSpec(k, paramInt1), View.MeasureSpec.makeMeasureSpec(j, paramInt2));
        } 
        if (this.l <= 0) {
          j = getChildCount();
          paramInt1 = 0;
          paramInt2 = bool;
          while (true) {
            i = paramInt1;
            if (paramInt2 < j) {
              k = getChildAt(paramInt2).getMeasuredHeight() + i1;
              i = paramInt1;
              if (k > paramInt1)
                i = k; 
              paramInt2++;
              paramInt1 = i;
              continue;
            } 
            break;
          } 
        } 
        setMeasuredDimension(n, i);
        return;
      } 
      StringBuilder stringBuilder1 = new StringBuilder();
      stringBuilder1.append(getClass().getSimpleName());
      stringBuilder1.append(" can only be used with android:layout_height=\"wrap_content\"");
      throw new IllegalStateException(stringBuilder1.toString());
    } 
    StringBuilder stringBuilder = new StringBuilder();
    stringBuilder.append(getClass().getSimpleName());
    stringBuilder.append(" can only be used with android:layout_width=\"match_parent\" (or fill_parent)");
    throw new IllegalStateException(stringBuilder.toString());
  }
  
  public void setContentHeight(int paramInt) {
    this.l = paramInt;
  }
  
  public void setCustomView(View paramView) {
    View view = this.s;
    if (view != null)
      removeView(view); 
    this.s = paramView;
    if (paramView != null) {
      LinearLayout linearLayout = this.t;
      if (linearLayout != null) {
        removeView((View)linearLayout);
        this.t = null;
      } 
    } 
    if (paramView != null)
      addView(paramView); 
    requestLayout();
  }
  
  public void setSubtitle(CharSequence paramCharSequence) {
    this.q = paramCharSequence;
    g();
  }
  
  public void setTitle(CharSequence paramCharSequence) {
    this.p = paramCharSequence;
    g();
  }
  
  public void setTitleOptional(boolean paramBoolean) {
    if (paramBoolean != this.y)
      requestLayout(); 
    this.y = paramBoolean;
  }
  
  public boolean shouldDelayChildPressedState() {
    return false;
  }
  
  public class a implements View.OnClickListener {
    public a(ActionBarContextView this$0, j.a param1a) {}
    
    public void onClick(View param1View) {
      this.h.c();
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Luxury Logo Maker_ Logo Design-dex2jar.jar!\androidx\appcompat\widget\ActionBarContextView.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */