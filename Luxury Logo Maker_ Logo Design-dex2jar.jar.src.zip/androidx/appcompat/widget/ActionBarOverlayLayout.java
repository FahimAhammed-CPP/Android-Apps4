package androidx.appcompat.widget;

import android.animation.Animator;
import android.animation.AnimatorListenerAdapter;
import android.annotation.SuppressLint;
import android.content.Context;
import android.content.res.Configuration;
import android.content.res.TypedArray;
import android.graphics.Canvas;
import android.graphics.Rect;
import android.graphics.drawable.Drawable;
import android.os.Build;
import android.util.AttributeSet;
import android.view.Menu;
import android.view.View;
import android.view.ViewGroup;
import android.view.ViewPropertyAnimator;
import android.view.Window;
import android.view.WindowInsets;
import android.widget.OverScroller;
import androidx.appcompat.view.menu.i;
import f.s;
import j.h;
import java.util.Objects;
import java.util.WeakHashMap;
import k0.g;
import k0.h;
import k0.i;
import k0.l;
import k0.r;

@SuppressLint({"UnknownNullness"})
public class ActionBarOverlayLayout extends ViewGroup implements d0, g, h {
  public static final int[] I = new int[] { 2130968579, 16842841 };
  
  public r A;
  
  public d B;
  
  public OverScroller C;
  
  public ViewPropertyAnimator D;
  
  public final AnimatorListenerAdapter E;
  
  public final Runnable F;
  
  public final Runnable G;
  
  public final i H;
  
  public int h;
  
  public int i = 0;
  
  public ContentFrameLayout j;
  
  public ActionBarContainer k;
  
  public e0 l;
  
  public Drawable m;
  
  public boolean n;
  
  public boolean o;
  
  public boolean p;
  
  public boolean q;
  
  public boolean r;
  
  public int s;
  
  public int t;
  
  public final Rect u = new Rect();
  
  public final Rect v = new Rect();
  
  public final Rect w = new Rect();
  
  public r x;
  
  public r y;
  
  public r z;
  
  public ActionBarOverlayLayout(Context paramContext, AttributeSet paramAttributeSet) {
    super(paramContext, paramAttributeSet);
    new Rect();
    new Rect();
    new Rect();
    new Rect();
    r r1 = r.b;
    this.x = r1;
    this.y = r1;
    this.z = r1;
    this.A = r1;
    this.E = new a(this);
    this.F = new b(this);
    this.G = new c(this);
    r(paramContext);
    this.H = new i();
  }
  
  public void a(Menu paramMenu, i.a parama) {
    s();
    this.l.a(paramMenu, parama);
  }
  
  public boolean b() {
    s();
    return this.l.b();
  }
  
  public void c() {
    s();
    this.l.c();
  }
  
  public boolean checkLayoutParams(ViewGroup.LayoutParams paramLayoutParams) {
    return paramLayoutParams instanceof e;
  }
  
  public boolean d() {
    s();
    return this.l.d();
  }
  
  public void draw(Canvas paramCanvas) {
    super.draw(paramCanvas);
    if (this.m != null && !this.n) {
      byte b;
      if (this.k.getVisibility() == 0) {
        float f = this.k.getBottom();
        b = (int)(this.k.getTranslationY() + f + 0.5F);
      } else {
        b = 0;
      } 
      this.m.setBounds(0, b, getWidth(), this.m.getIntrinsicHeight() + b);
      this.m.draw(paramCanvas);
    } 
  }
  
  public boolean e() {
    s();
    return this.l.e();
  }
  
  public boolean f() {
    s();
    return this.l.f();
  }
  
  public boolean fitSystemWindows(Rect paramRect) {
    return super.fitSystemWindows(paramRect);
  }
  
  public boolean g() {
    s();
    return this.l.g();
  }
  
  public ViewGroup.LayoutParams generateDefaultLayoutParams() {
    return (ViewGroup.LayoutParams)new e(-1, -1);
  }
  
  public ViewGroup.LayoutParams generateLayoutParams(AttributeSet paramAttributeSet) {
    return (ViewGroup.LayoutParams)new e(getContext(), paramAttributeSet);
  }
  
  public ViewGroup.LayoutParams generateLayoutParams(ViewGroup.LayoutParams paramLayoutParams) {
    return (ViewGroup.LayoutParams)new e(paramLayoutParams);
  }
  
  public int getActionBarHideOffset() {
    ActionBarContainer actionBarContainer = this.k;
    return (actionBarContainer != null) ? -((int)actionBarContainer.getTranslationY()) : 0;
  }
  
  public int getNestedScrollAxes() {
    return this.H.a();
  }
  
  public CharSequence getTitle() {
    s();
    return this.l.getTitle();
  }
  
  public void h(View paramView1, View paramView2, int paramInt1, int paramInt2) {
    if (paramInt2 == 0)
      onNestedScrollAccepted(paramView1, paramView2, paramInt1); 
  }
  
  public void i(View paramView, int paramInt) {
    if (paramInt == 0)
      onStopNestedScroll(paramView); 
  }
  
  public void j(View paramView, int paramInt1, int paramInt2, int[] paramArrayOfint, int paramInt3) {
    if (paramInt3 == 0)
      onNestedPreScroll(paramView, paramInt1, paramInt2, paramArrayOfint); 
  }
  
  public void k(int paramInt) {
    s();
    if (paramInt != 2) {
      if (paramInt != 5) {
        if (paramInt != 109)
          return; 
        setOverlayMode(true);
        return;
      } 
      this.l.t();
      return;
    } 
    this.l.s();
  }
  
  public void l() {
    s();
    this.l.h();
  }
  
  public void m(View paramView, int paramInt1, int paramInt2, int paramInt3, int paramInt4, int paramInt5, int[] paramArrayOfint) {
    if (paramInt5 == 0)
      onNestedScroll(paramView, paramInt1, paramInt2, paramInt3, paramInt4); 
  }
  
  public void n(View paramView, int paramInt1, int paramInt2, int paramInt3, int paramInt4, int paramInt5) {
    if (paramInt5 == 0)
      onNestedScroll(paramView, paramInt1, paramInt2, paramInt3, paramInt4); 
  }
  
  public boolean o(View paramView1, View paramView2, int paramInt1, int paramInt2) {
    return (paramInt2 == 0 && onStartNestedScroll(paramView1, paramView2, paramInt1));
  }
  
  public WindowInsets onApplyWindowInsets(WindowInsets paramWindowInsets) {
    s();
    r r1 = r.i(paramWindowInsets, null);
    Rect rect = new Rect(r1.b(), r1.d(), r1.c(), r1.a());
    boolean bool1 = p((View)this.k, rect, true, true, false, true);
    rect = this.u;
    WeakHashMap weakHashMap = l.a;
    l.a.b((View)this, r1, rect);
    rect = this.u;
    int j = rect.left;
    int k = rect.top;
    int m = rect.right;
    int n = rect.bottom;
    r r2 = r1.a.i(j, k, m, n);
    this.x = r2;
    boolean bool2 = this.y.equals(r2);
    boolean bool = true;
    if (!bool2) {
      this.y = this.x;
      bool1 = true;
    } 
    if (!this.v.equals(this.u)) {
      this.v.set(this.u);
      bool1 = bool;
    } 
    if (bool1)
      requestLayout(); 
    return ((r1.a.a()).a.c()).a.b().g();
  }
  
  public void onConfigurationChanged(Configuration paramConfiguration) {
    super.onConfigurationChanged(paramConfiguration);
    r(getContext());
    WeakHashMap weakHashMap = l.a;
    requestApplyInsets();
  }
  
  public void onDetachedFromWindow() {
    super.onDetachedFromWindow();
    q();
  }
  
  public void onLayout(boolean paramBoolean, int paramInt1, int paramInt2, int paramInt3, int paramInt4) {
    paramInt2 = getChildCount();
    paramInt3 = getPaddingLeft();
    paramInt4 = getPaddingTop();
    for (paramInt1 = 0; paramInt1 < paramInt2; paramInt1++) {
      View view = getChildAt(paramInt1);
      if (view.getVisibility() != 8) {
        e e = (e)view.getLayoutParams();
        int j = view.getMeasuredWidth();
        int k = view.getMeasuredHeight();
        int m = e.leftMargin + paramInt3;
        int n = e.topMargin + paramInt4;
        view.layout(m, n, j + m, k + n);
      } 
    } 
  }
  
  public void onMeasure(int paramInt1, int paramInt2) {
    s();
    measureChildWithMargins((View)this.k, paramInt1, 0, paramInt2, 0);
    e e2 = (e)this.k.getLayoutParams();
    int i2 = Math.max(0, this.k.getMeasuredWidth() + e2.leftMargin + e2.rightMargin);
    int i1 = Math.max(0, this.k.getMeasuredHeight() + e2.topMargin + e2.bottomMargin);
    int n = View.combineMeasuredStates(0, this.k.getMeasuredState());
    WeakHashMap weakHashMap = l.a;
    if ((getWindowSystemUiVisibility() & 0x100) != 0) {
      k = 1;
    } else {
      k = 0;
    } 
    if (k) {
      int i3 = this.h;
      j = i3;
      if (this.p) {
        j = i3;
        if (this.k.getTabContainer() != null)
          j = i3 + this.h; 
      } 
    } else if (this.k.getVisibility() != 8) {
      j = this.k.getMeasuredHeight();
    } else {
      j = 0;
    } 
    this.w.set(this.u);
    r r1 = this.x;
    this.z = r1;
    if (!this.o && !k) {
      Rect rect = this.w;
      rect.top += j;
      rect.bottom += 0;
      r1 = r1.a.i(0, j, 0, 0);
    } else {
      r.d d1;
      r.b b;
      d0.b b1 = d0.b.a(r1.b(), this.z.d() + j, this.z.c(), this.z.a() + 0);
      r1 = this.z;
      j = Build.VERSION.SDK_INT;
      if (j >= 30) {
        d1 = new r.d(r1);
      } else {
        r.c c;
        if (j >= 29) {
          c = new r.c((r)d1);
        } else {
          b = new r.b((r)c);
        } 
      } 
      b.d(b1);
      r1 = b.b();
    } 
    this.z = r1;
    p((View)this.j, this.w, true, true, true, true);
    if (!this.A.equals(this.z)) {
      r1 = this.z;
      this.A = r1;
      l.e((View)this.j, r1);
    } 
    measureChildWithMargins((View)this.j, paramInt1, 0, paramInt2, 0);
    e e1 = (e)this.j.getLayoutParams();
    int j = Math.max(i2, this.j.getMeasuredWidth() + e1.leftMargin + e1.rightMargin);
    int k = Math.max(i1, this.j.getMeasuredHeight() + e1.topMargin + e1.bottomMargin);
    int m = View.combineMeasuredStates(n, this.j.getMeasuredState());
    n = getPaddingLeft();
    i1 = getPaddingRight();
    i2 = getPaddingTop();
    k = Math.max(getPaddingBottom() + i2 + k, getSuggestedMinimumHeight());
    setMeasuredDimension(View.resolveSizeAndState(Math.max(i1 + n + j, getSuggestedMinimumWidth()), paramInt1, m), View.resolveSizeAndState(k, paramInt2, m << 16));
  }
  
  public boolean onNestedFling(View paramView, float paramFloat1, float paramFloat2, boolean paramBoolean) {
    boolean bool1 = this.q;
    boolean bool = false;
    if (bool1) {
      if (!paramBoolean)
        return false; 
      this.C.fling(0, 0, 0, (int)paramFloat2, 0, 0, -2147483648, 2147483647);
      if (this.C.getFinalY() > this.k.getHeight())
        bool = true; 
      if (bool) {
        q();
        this.G.run();
      } else {
        q();
        this.F.run();
      } 
      this.r = true;
      return true;
    } 
    return false;
  }
  
  public boolean onNestedPreFling(View paramView, float paramFloat1, float paramFloat2) {
    return false;
  }
  
  public void onNestedPreScroll(View paramView, int paramInt1, int paramInt2, int[] paramArrayOfint) {}
  
  public void onNestedScroll(View paramView, int paramInt1, int paramInt2, int paramInt3, int paramInt4) {
    paramInt1 = this.s + paramInt2;
    this.s = paramInt1;
    setActionBarHideOffset(paramInt1);
  }
  
  public void onNestedScrollAccepted(View paramView1, View paramView2, int paramInt) {
    this.H.a = paramInt;
    this.s = getActionBarHideOffset();
    q();
    d d1 = this.B;
    if (d1 != null) {
      s s = (s)d1;
      h h1 = s.t;
      if (h1 != null) {
        h1.a();
        s.t = null;
      } 
    } 
  }
  
  public boolean onStartNestedScroll(View paramView1, View paramView2, int paramInt) {
    return ((paramInt & 0x2) == 0 || this.k.getVisibility() != 0) ? false : this.q;
  }
  
  public void onStopNestedScroll(View paramView) {
    if (this.q && !this.r)
      if (this.s <= this.k.getHeight()) {
        q();
        postDelayed(this.F, 600L);
      } else {
        q();
        postDelayed(this.G, 600L);
      }  
    d d1 = this.B;
    if (d1 != null)
      Objects.requireNonNull(d1); 
  }
  
  public void onWindowSystemUiVisibilityChanged(int paramInt) {
    boolean bool1;
    boolean bool2;
    super.onWindowSystemUiVisibilityChanged(paramInt);
    s();
    int j = this.t;
    this.t = paramInt;
    if ((paramInt & 0x4) == 0) {
      bool1 = true;
    } else {
      bool1 = false;
    } 
    if ((paramInt & 0x100) != 0) {
      bool2 = true;
    } else {
      bool2 = false;
    } 
    d d1 = this.B;
    if (d1 != null) {
      s s;
      ((s)d1).p = bool2 ^ true;
      if (bool1 || !bool2) {
        s = (s)d1;
        if (s.q) {
          s.q = false;
          s.g(true);
        } 
      } else {
        s = s;
        if (!s.q) {
          s.q = true;
          s.g(true);
        } 
      } 
    } 
    if (((j ^ paramInt) & 0x100) != 0 && this.B != null) {
      WeakHashMap weakHashMap = l.a;
      requestApplyInsets();
    } 
  }
  
  public void onWindowVisibilityChanged(int paramInt) {
    super.onWindowVisibilityChanged(paramInt);
    this.i = paramInt;
    d d1 = this.B;
    if (d1 != null)
      ((s)d1).o = paramInt; 
  }
  
  public final boolean p(View paramView, Rect paramRect, boolean paramBoolean1, boolean paramBoolean2, boolean paramBoolean3, boolean paramBoolean4) {
    // Byte code:
    //   0: aload_1
    //   1: invokevirtual getLayoutParams : ()Landroid/view/ViewGroup$LayoutParams;
    //   4: checkcast androidx/appcompat/widget/ActionBarOverlayLayout$e
    //   7: astore_1
    //   8: iload_3
    //   9: ifeq -> 43
    //   12: aload_1
    //   13: getfield leftMargin : I
    //   16: istore #7
    //   18: aload_2
    //   19: getfield left : I
    //   22: istore #8
    //   24: iload #7
    //   26: iload #8
    //   28: if_icmpeq -> 43
    //   31: aload_1
    //   32: iload #8
    //   34: putfield leftMargin : I
    //   37: iconst_1
    //   38: istore #9
    //   40: goto -> 46
    //   43: iconst_0
    //   44: istore #9
    //   46: iload #9
    //   48: istore_3
    //   49: iload #4
    //   51: ifeq -> 84
    //   54: aload_1
    //   55: getfield topMargin : I
    //   58: istore #7
    //   60: aload_2
    //   61: getfield top : I
    //   64: istore #8
    //   66: iload #9
    //   68: istore_3
    //   69: iload #7
    //   71: iload #8
    //   73: if_icmpeq -> 84
    //   76: aload_1
    //   77: iload #8
    //   79: putfield topMargin : I
    //   82: iconst_1
    //   83: istore_3
    //   84: iload_3
    //   85: istore #4
    //   87: iload #6
    //   89: ifeq -> 123
    //   92: aload_1
    //   93: getfield rightMargin : I
    //   96: istore #7
    //   98: aload_2
    //   99: getfield right : I
    //   102: istore #8
    //   104: iload_3
    //   105: istore #4
    //   107: iload #7
    //   109: iload #8
    //   111: if_icmpeq -> 123
    //   114: aload_1
    //   115: iload #8
    //   117: putfield rightMargin : I
    //   120: iconst_1
    //   121: istore #4
    //   123: iload #5
    //   125: ifeq -> 155
    //   128: aload_1
    //   129: getfield bottomMargin : I
    //   132: istore #7
    //   134: aload_2
    //   135: getfield bottom : I
    //   138: istore #8
    //   140: iload #7
    //   142: iload #8
    //   144: if_icmpeq -> 155
    //   147: aload_1
    //   148: iload #8
    //   150: putfield bottomMargin : I
    //   153: iconst_1
    //   154: ireturn
    //   155: iload #4
    //   157: ireturn
  }
  
  public void q() {
    removeCallbacks(this.F);
    removeCallbacks(this.G);
    ViewPropertyAnimator viewPropertyAnimator = this.D;
    if (viewPropertyAnimator != null)
      viewPropertyAnimator.cancel(); 
  }
  
  public final void r(Context paramContext) {
    TypedArray typedArray = getContext().getTheme().obtainStyledAttributes(I);
    boolean bool2 = false;
    this.h = typedArray.getDimensionPixelSize(0, 0);
    Drawable drawable = typedArray.getDrawable(1);
    this.m = drawable;
    if (drawable == null) {
      bool1 = true;
    } else {
      bool1 = false;
    } 
    setWillNotDraw(bool1);
    typedArray.recycle();
    boolean bool1 = bool2;
    if ((paramContext.getApplicationInfo()).targetSdkVersion < 19)
      bool1 = true; 
    this.n = bool1;
    this.C = new OverScroller(paramContext);
  }
  
  public void s() {
    if (this.j == null) {
      e0 e01;
      this.j = (ContentFrameLayout)findViewById(2131361842);
      this.k = (ActionBarContainer)findViewById(2131361843);
      View view = findViewById(2131361841);
      if (view instanceof e0) {
        e01 = (e0)view;
      } else if (e01 instanceof Toolbar) {
        e01 = ((Toolbar)e01).getWrapper();
      } else {
        StringBuilder stringBuilder = android.support.v4.media.c.a("Can't make a decor toolbar out of ");
        stringBuilder.append(e01.getClass().getSimpleName());
        throw new IllegalStateException(stringBuilder.toString());
      } 
      this.l = e01;
      return;
    } 
  }
  
  public void setActionBarHideOffset(int paramInt) {
    q();
    paramInt = Math.max(0, Math.min(paramInt, this.k.getHeight()));
    this.k.setTranslationY(-paramInt);
  }
  
  public void setActionBarVisibilityCallback(d paramd) {
    this.B = paramd;
    if (getWindowToken() != null) {
      paramd = this.B;
      int j = this.i;
      ((s)paramd).o = j;
      j = this.t;
      if (j != 0) {
        onWindowSystemUiVisibilityChanged(j);
        WeakHashMap weakHashMap = l.a;
        requestApplyInsets();
      } 
    } 
  }
  
  public void setHasNonEmbeddedTabs(boolean paramBoolean) {
    this.p = paramBoolean;
  }
  
  public void setHideOnContentScrollEnabled(boolean paramBoolean) {
    if (paramBoolean != this.q) {
      this.q = paramBoolean;
      if (!paramBoolean) {
        q();
        setActionBarHideOffset(0);
      } 
    } 
  }
  
  public void setIcon(int paramInt) {
    s();
    this.l.setIcon(paramInt);
  }
  
  public void setIcon(Drawable paramDrawable) {
    s();
    this.l.setIcon(paramDrawable);
  }
  
  public void setLogo(int paramInt) {
    s();
    this.l.p(paramInt);
  }
  
  public void setOverlayMode(boolean paramBoolean) {
    this.o = paramBoolean;
    if (paramBoolean && (getContext().getApplicationInfo()).targetSdkVersion < 19) {
      paramBoolean = true;
    } else {
      paramBoolean = false;
    } 
    this.n = paramBoolean;
  }
  
  public void setShowingForActionMode(boolean paramBoolean) {}
  
  public void setUiOptions(int paramInt) {}
  
  public void setWindowCallback(Window.Callback paramCallback) {
    s();
    this.l.setWindowCallback(paramCallback);
  }
  
  public void setWindowTitle(CharSequence paramCharSequence) {
    s();
    this.l.setWindowTitle(paramCharSequence);
  }
  
  public boolean shouldDelayChildPressedState() {
    return false;
  }
  
  public class a extends AnimatorListenerAdapter {
    public a(ActionBarOverlayLayout this$0) {}
    
    public void onAnimationCancel(Animator param1Animator) {
      ActionBarOverlayLayout actionBarOverlayLayout = this.a;
      actionBarOverlayLayout.D = null;
      actionBarOverlayLayout.r = false;
    }
    
    public void onAnimationEnd(Animator param1Animator) {
      ActionBarOverlayLayout actionBarOverlayLayout = this.a;
      actionBarOverlayLayout.D = null;
      actionBarOverlayLayout.r = false;
    }
  }
  
  public class b implements Runnable {
    public b(ActionBarOverlayLayout this$0) {}
    
    public void run() {
      this.h.q();
      ActionBarOverlayLayout actionBarOverlayLayout = this.h;
      actionBarOverlayLayout.D = actionBarOverlayLayout.k.animate().translationY(0.0F).setListener((Animator.AnimatorListener)this.h.E);
    }
  }
  
  public class c implements Runnable {
    public c(ActionBarOverlayLayout this$0) {}
    
    public void run() {
      this.h.q();
      ActionBarOverlayLayout actionBarOverlayLayout = this.h;
      actionBarOverlayLayout.D = actionBarOverlayLayout.k.animate().translationY(-this.h.k.getHeight()).setListener((Animator.AnimatorListener)this.h.E);
    }
  }
  
  public static interface d {}
  
  public static class e extends ViewGroup.MarginLayoutParams {
    public e(int param1Int1, int param1Int2) {
      super(param1Int1, param1Int2);
    }
    
    public e(Context param1Context, AttributeSet param1AttributeSet) {
      super(param1Context, param1AttributeSet);
    }
    
    public e(ViewGroup.LayoutParams param1LayoutParams) {
      super(param1LayoutParams);
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Luxury Logo Maker_ Logo Design-dex2jar.jar!\androidx\appcompat\widget\ActionBarOverlayLayout.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */