package androidx.appcompat.widget;

import android.content.Context;
import android.graphics.drawable.Drawable;
import android.text.TextUtils;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.View;
import android.view.ViewGroup;
import android.view.ViewParent;
import android.view.Window;
import android.widget.TextView;
import androidx.appcompat.view.menu.e;
import androidx.appcompat.view.menu.g;
import androidx.appcompat.view.menu.i;
import com.bumptech.glide.manager.b;
import java.util.Objects;
import k0.l;
import k0.n;
import k0.o;
import k0.p;

public class b1 implements e0 {
  public Toolbar a;
  
  public int b;
  
  public View c;
  
  public View d;
  
  public Drawable e;
  
  public Drawable f;
  
  public Drawable g;
  
  public boolean h;
  
  public CharSequence i;
  
  public CharSequence j;
  
  public CharSequence k;
  
  public Window.Callback l;
  
  public boolean m;
  
  public c n;
  
  public int o;
  
  public Drawable p;
  
  public b1(Toolbar paramToolbar, boolean paramBoolean) {
    boolean bool;
    this.o = 0;
    this.a = paramToolbar;
    this.i = paramToolbar.getTitle();
    this.j = paramToolbar.getSubtitle();
    if (this.i != null) {
      bool = true;
    } else {
      bool = false;
    } 
    this.h = bool;
    this.g = paramToolbar.getNavigationIcon();
    Context context = paramToolbar.getContext();
    int[] arrayOfInt = b.h;
    paramToolbar = null;
    z0 z0 = z0.q(context, null, arrayOfInt, 2130968581, 0);
    int i = 15;
    this.p = z0.g(15);
    if (paramBoolean) {
      CharSequence charSequence = z0.n(27);
      if (!TextUtils.isEmpty(charSequence)) {
        this.h = true;
        this.i = charSequence;
        if ((this.b & 0x8) != 0)
          this.a.setTitle(charSequence); 
      } 
      charSequence = z0.n(25);
      if (!TextUtils.isEmpty(charSequence)) {
        this.j = charSequence;
        if ((this.b & 0x8) != 0)
          this.a.setSubtitle(charSequence); 
      } 
      Drawable drawable = z0.g(20);
      if (drawable != null) {
        this.f = drawable;
        x();
      } 
      drawable = z0.g(17);
      if (drawable != null) {
        this.e = drawable;
        x();
      } 
      if (this.g == null) {
        drawable = this.p;
        if (drawable != null) {
          this.g = drawable;
          w();
        } 
      } 
      n(z0.j(10, 0));
      i = z0.l(9, 0);
      if (i != 0) {
        View view1 = LayoutInflater.from(this.a.getContext()).inflate(i, this.a, false);
        View view2 = this.d;
        if (view2 != null && (this.b & 0x10) != 0)
          this.a.removeView(view2); 
        this.d = view1;
        if (view1 != null && (this.b & 0x10) != 0)
          this.a.addView(view1); 
        n(this.b | 0x10);
      } 
      i = z0.k(13, 0);
      if (i > 0) {
        ViewGroup.LayoutParams layoutParams = this.a.getLayoutParams();
        layoutParams.height = i;
        this.a.setLayoutParams(layoutParams);
      } 
      int j = z0.e(7, -1);
      i = z0.e(3, -1);
      if (j >= 0 || i >= 0) {
        Toolbar toolbar = this.a;
        j = Math.max(j, 0);
        i = Math.max(i, 0);
        toolbar.d();
        toolbar.A.a(j, i);
      } 
      i = z0.l(28, 0);
      if (i != 0) {
        Toolbar toolbar = this.a;
        Context context1 = toolbar.getContext();
        toolbar.s = i;
        TextView textView = toolbar.i;
        if (textView != null)
          textView.setTextAppearance(context1, i); 
      } 
      i = z0.l(26, 0);
      if (i != 0) {
        Toolbar toolbar = this.a;
        Context context1 = toolbar.getContext();
        toolbar.t = i;
        TextView textView = toolbar.j;
        if (textView != null)
          textView.setTextAppearance(context1, i); 
      } 
      i = z0.l(22, 0);
      if (i != 0)
        this.a.setPopupTheme(i); 
    } else {
      if (this.a.getNavigationIcon() != null) {
        this.p = this.a.getNavigationIcon();
      } else {
        i = 11;
      } 
      this.b = i;
    } 
    z0.b.recycle();
    if (2131820546 != this.o) {
      this.o = 2131820546;
      if (TextUtils.isEmpty(this.a.getNavigationContentDescription())) {
        String str;
        i = this.o;
        if (i != 0)
          str = getContext().getString(i); 
        this.k = str;
        v();
      } 
    } 
    this.k = this.a.getNavigationContentDescription();
    this.a.setNavigationOnClickListener(new a1(this));
  }
  
  public void a(Menu paramMenu, i.a parama) {
    if (this.n == null) {
      c c2 = new c(this.a.getContext());
      this.n = c2;
      Objects.requireNonNull(c2);
    } 
    c c1 = this.n;
    c1.l = parama;
    Toolbar toolbar = this.a;
    e e1 = (e)paramMenu;
    if (e1 == null && toolbar.h == null)
      return; 
    toolbar.f();
    e e2 = toolbar.h.w;
    if (e2 == e1)
      return; 
    if (e2 != null) {
      e2.t((i)toolbar.Q);
      e2.t(toolbar.R);
    } 
    if (toolbar.R == null)
      toolbar.R = new Toolbar.d(toolbar); 
    c1.x = true;
    if (e1 != null) {
      e1.b((i)c1, toolbar.q);
      e1.b(toolbar.R, toolbar.q);
    } else {
      c1.c(toolbar.q, null);
      Toolbar.d d = toolbar.R;
      e2 = d.h;
      if (e2 != null) {
        g g = d.i;
        if (g != null)
          e2.d(g); 
      } 
      d.h = null;
      c1.f(true);
      toolbar.R.f(true);
    } 
    toolbar.h.setPopupTheme(toolbar.r);
    toolbar.h.setPresenter(c1);
    toolbar.Q = c1;
  }
  
  public boolean b() {
    return this.a.p();
  }
  
  public void c() {
    this.m = true;
  }
  
  public void collapseActionView() {
    g g;
    Toolbar.d d = this.a.R;
    if (d == null) {
      d = null;
    } else {
      g = d.i;
    } 
    if (g != null)
      g.collapseActionView(); 
  }
  
  public boolean d() {
    // Byte code:
    //   0: aload_0
    //   1: getfield a : Landroidx/appcompat/widget/Toolbar;
    //   4: getfield h : Landroidx/appcompat/widget/ActionMenuView;
    //   7: astore #4
    //   9: iconst_0
    //   10: istore_3
    //   11: iload_3
    //   12: istore_2
    //   13: aload #4
    //   15: ifnull -> 75
    //   18: aload #4
    //   20: getfield A : Landroidx/appcompat/widget/c;
    //   23: astore #4
    //   25: aload #4
    //   27: ifnull -> 65
    //   30: aload #4
    //   32: getfield B : Landroidx/appcompat/widget/c$c;
    //   35: ifnonnull -> 54
    //   38: aload #4
    //   40: invokevirtual m : ()Z
    //   43: ifeq -> 49
    //   46: goto -> 54
    //   49: iconst_0
    //   50: istore_1
    //   51: goto -> 56
    //   54: iconst_1
    //   55: istore_1
    //   56: iload_1
    //   57: ifeq -> 65
    //   60: iconst_1
    //   61: istore_1
    //   62: goto -> 67
    //   65: iconst_0
    //   66: istore_1
    //   67: iload_3
    //   68: istore_2
    //   69: iload_1
    //   70: ifeq -> 75
    //   73: iconst_1
    //   74: istore_2
    //   75: iload_2
    //   76: ireturn
  }
  
  public boolean e() {
    ActionMenuView actionMenuView = this.a.h;
    boolean bool2 = false;
    boolean bool1 = bool2;
    if (actionMenuView != null) {
      boolean bool;
      c c1 = actionMenuView.A;
      if (c1 != null && c1.g()) {
        bool = true;
      } else {
        bool = false;
      } 
      bool1 = bool2;
      if (bool)
        bool1 = true; 
    } 
    return bool1;
  }
  
  public boolean f() {
    return this.a.v();
  }
  
  public boolean g() {
    Toolbar toolbar = this.a;
    if (toolbar.getVisibility() == 0) {
      ActionMenuView actionMenuView = toolbar.h;
      if (actionMenuView != null && actionMenuView.z)
        return true; 
    } 
    return false;
  }
  
  public Context getContext() {
    return this.a.getContext();
  }
  
  public CharSequence getTitle() {
    return this.a.getTitle();
  }
  
  public void h() {
    ActionMenuView actionMenuView = this.a.h;
    if (actionMenuView != null) {
      c c1 = actionMenuView.A;
      if (c1 != null)
        c1.b(); 
    } 
  }
  
  public void i(int paramInt) {
    this.a.setVisibility(paramInt);
  }
  
  public void j(r0 paramr0) {
    View view = this.c;
    if (view != null) {
      ViewParent viewParent = view.getParent();
      Toolbar toolbar = this.a;
      if (viewParent == toolbar)
        toolbar.removeView(this.c); 
    } 
    this.c = null;
  }
  
  public ViewGroup k() {
    return this.a;
  }
  
  public void l(boolean paramBoolean) {}
  
  public boolean m() {
    Toolbar.d d = this.a.R;
    return (d != null && d.i != null);
  }
  
  public void n(int paramInt) {
    int i = this.b ^ paramInt;
    this.b = paramInt;
    if (i != 0) {
      if ((i & 0x4) != 0) {
        if ((paramInt & 0x4) != 0)
          v(); 
        w();
      } 
      if ((i & 0x3) != 0)
        x(); 
      if ((i & 0x8) != 0) {
        Toolbar toolbar;
        CharSequence charSequence;
        if ((paramInt & 0x8) != 0) {
          this.a.setTitle(this.i);
          toolbar = this.a;
          charSequence = this.j;
        } else {
          toolbar = this.a;
          charSequence = null;
          toolbar.setTitle((CharSequence)null);
          toolbar = this.a;
        } 
        toolbar.setSubtitle(charSequence);
      } 
      if ((i & 0x10) != 0) {
        View view = this.d;
        if (view != null) {
          if ((paramInt & 0x10) != 0) {
            this.a.addView(view);
            return;
          } 
          this.a.removeView(view);
        } 
      } 
    } 
  }
  
  public int o() {
    return this.b;
  }
  
  public void p(int paramInt) {
    Drawable drawable;
    if (paramInt != 0) {
      drawable = g.a.b(getContext(), paramInt);
    } else {
      drawable = null;
    } 
    this.f = drawable;
    x();
  }
  
  public int q() {
    return 0;
  }
  
  public n r(int paramInt, long paramLong) {
    float f;
    n n = l.b((View)this.a);
    if (paramInt == 0) {
      f = 1.0F;
    } else {
      f = 0.0F;
    } 
    n.a(f);
    n.c(paramLong);
    a a = new a(this, paramInt);
    View view = n.a.get();
    if (view != null)
      n.e(view, (o)a); 
    return n;
  }
  
  public void s() {
    Log.i("ToolbarWidgetWrapper", "Progress display unsupported");
  }
  
  public void setIcon(int paramInt) {
    Drawable drawable;
    if (paramInt != 0) {
      drawable = g.a.b(getContext(), paramInt);
    } else {
      drawable = null;
    } 
    this.e = drawable;
    x();
  }
  
  public void setIcon(Drawable paramDrawable) {
    this.e = paramDrawable;
    x();
  }
  
  public void setWindowCallback(Window.Callback paramCallback) {
    this.l = paramCallback;
  }
  
  public void setWindowTitle(CharSequence paramCharSequence) {
    if (!this.h) {
      this.i = paramCharSequence;
      if ((this.b & 0x8) != 0)
        this.a.setTitle(paramCharSequence); 
    } 
  }
  
  public void t() {
    Log.i("ToolbarWidgetWrapper", "Progress display unsupported");
  }
  
  public void u(boolean paramBoolean) {
    this.a.setCollapsible(paramBoolean);
  }
  
  public final void v() {
    if ((this.b & 0x4) != 0) {
      if (TextUtils.isEmpty(this.k)) {
        this.a.setNavigationContentDescription(this.o);
        return;
      } 
      this.a.setNavigationContentDescription(this.k);
    } 
  }
  
  public final void w() {
    Drawable drawable;
    Toolbar toolbar;
    if ((this.b & 0x4) != 0) {
      toolbar = this.a;
      drawable = this.g;
      if (drawable == null)
        drawable = this.p; 
    } else {
      toolbar = this.a;
      drawable = null;
    } 
    toolbar.setNavigationIcon(drawable);
  }
  
  public final void x() {
    Drawable drawable;
    int i = this.b;
    if ((i & 0x2) != 0) {
      if ((i & 0x1) != 0) {
        Drawable drawable1 = this.f;
        if (drawable1 != null) {
          this.a.setLogo(drawable1);
          return;
        } 
      } 
      drawable = this.e;
    } else {
      drawable = null;
    } 
    this.a.setLogo(drawable);
  }
  
  public class a extends p {
    public boolean a = false;
    
    public a(b1 this$0, int param1Int) {}
    
    public void a(View param1View) {
      this.a = true;
    }
    
    public void b(View param1View) {
      if (!this.a)
        this.c.a.setVisibility(this.b); 
    }
    
    public void c(View param1View) {
      this.c.a.setVisibility(0);
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Luxury Logo Maker_ Logo Design-dex2jar.jar!\androidx\appcompat\widget\b1.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */