package androidx.appcompat.widget;

import android.content.Context;
import android.content.res.ColorStateList;
import android.graphics.drawable.Drawable;
import android.os.Parcel;
import android.os.Parcelable;
import android.text.TextUtils;
import android.util.AttributeSet;
import android.view.ContextThemeWrapper;
import android.view.Gravity;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.view.ViewParent;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.TextView;
import androidx.appcompat.view.menu.i;
import androidx.appcompat.view.menu.l;
import java.util.ArrayList;
import java.util.List;
import java.util.WeakHashMap;
import k0.l;

public class Toolbar extends ViewGroup {
  public q0 A;
  
  public int B;
  
  public int C;
  
  public int D = 8388627;
  
  public CharSequence E;
  
  public CharSequence F;
  
  public ColorStateList G;
  
  public ColorStateList H;
  
  public boolean I;
  
  public boolean J;
  
  public final ArrayList<View> K = new ArrayList<View>();
  
  public final ArrayList<View> L = new ArrayList<View>();
  
  public final int[] M = new int[2];
  
  public f N;
  
  public final ActionMenuView.e O = new a(this);
  
  public b1 P;
  
  public c Q;
  
  public d R;
  
  public boolean S;
  
  public final Runnable T = new b(this);
  
  public ActionMenuView h;
  
  public TextView i;
  
  public TextView j;
  
  public ImageButton k;
  
  public ImageView l;
  
  public Drawable m;
  
  public CharSequence n;
  
  public ImageButton o;
  
  public View p;
  
  public Context q;
  
  public int r;
  
  public int s;
  
  public int t;
  
  public int u;
  
  public int v;
  
  public int w;
  
  public int x;
  
  public int y;
  
  public int z;
  
  public Toolbar(Context paramContext, AttributeSet paramAttributeSet) {
    this(paramContext, paramAttributeSet, 2130969467);
  }
  
  public Toolbar(Context paramContext, AttributeSet paramAttributeSet, int paramInt) {
    super(paramContext, paramAttributeSet, paramInt);
    Context context = getContext();
    int[] arrayOfInt = com.bumptech.glide.manager.b.E;
    z0 z0 = z0.q(context, paramAttributeSet, arrayOfInt, paramInt, 0);
    l.r((View)this, paramContext, arrayOfInt, paramAttributeSet, z0.b, paramInt, 0);
    this.s = z0.l(28, 0);
    this.t = z0.l(19, 0);
    paramInt = this.D;
    this.D = z0.b.getInteger(0, paramInt);
    this.u = z0.b.getInteger(2, 48);
    int i = z0.e(22, 0);
    paramInt = i;
    if (z0.o(27))
      paramInt = z0.e(27, i); 
    this.z = paramInt;
    this.y = paramInt;
    this.x = paramInt;
    this.w = paramInt;
    paramInt = z0.e(25, -1);
    if (paramInt >= 0)
      this.w = paramInt; 
    paramInt = z0.e(24, -1);
    if (paramInt >= 0)
      this.x = paramInt; 
    paramInt = z0.e(26, -1);
    if (paramInt >= 0)
      this.y = paramInt; 
    paramInt = z0.e(23, -1);
    if (paramInt >= 0)
      this.z = paramInt; 
    this.v = z0.f(13, -1);
    paramInt = z0.e(9, -2147483648);
    i = z0.e(5, -2147483648);
    int j = z0.f(7, 0);
    int k = z0.f(8, 0);
    d();
    q0 q01 = this.A;
    q01.h = false;
    if (j != Integer.MIN_VALUE) {
      q01.e = j;
      q01.a = j;
    } 
    if (k != Integer.MIN_VALUE) {
      q01.f = k;
      q01.b = k;
    } 
    if (paramInt != Integer.MIN_VALUE || i != Integer.MIN_VALUE)
      q01.a(paramInt, i); 
    this.B = z0.e(10, -2147483648);
    this.C = z0.e(6, -2147483648);
    this.m = z0.g(4);
    this.n = z0.n(3);
    CharSequence charSequence3 = z0.n(21);
    if (!TextUtils.isEmpty(charSequence3))
      setTitle(charSequence3); 
    charSequence3 = z0.n(18);
    if (!TextUtils.isEmpty(charSequence3))
      setSubtitle(charSequence3); 
    this.q = getContext();
    setPopupTheme(z0.l(17, 0));
    Drawable drawable2 = z0.g(16);
    if (drawable2 != null)
      setNavigationIcon(drawable2); 
    CharSequence charSequence2 = z0.n(15);
    if (!TextUtils.isEmpty(charSequence2))
      setNavigationContentDescription(charSequence2); 
    Drawable drawable1 = z0.g(11);
    if (drawable1 != null)
      setLogo(drawable1); 
    CharSequence charSequence1 = z0.n(12);
    if (!TextUtils.isEmpty(charSequence1))
      setLogoDescription(charSequence1); 
    if (z0.o(29))
      setTitleTextColor(z0.c(29)); 
    if (z0.o(20))
      setSubtitleTextColor(z0.c(20)); 
    if (z0.o(14)) {
      paramInt = z0.l(14, 0);
      getMenuInflater().inflate(paramInt, getMenu());
    } 
    z0.b.recycle();
  }
  
  private MenuInflater getMenuInflater() {
    return (MenuInflater)new j.g(getContext());
  }
  
  public final void a(List<View> paramList, int paramInt) {
    WeakHashMap weakHashMap = l.a;
    int i = getLayoutDirection();
    boolean bool = false;
    if (i == 1) {
      i = 1;
    } else {
      i = 0;
    } 
    int k = getChildCount();
    int j = Gravity.getAbsoluteGravity(paramInt, getLayoutDirection());
    paramList.clear();
    paramInt = bool;
    if (i != 0) {
      for (paramInt = k - 1; paramInt >= 0; paramInt--) {
        View view = getChildAt(paramInt);
        e e1 = (e)view.getLayoutParams();
        if (e1.b == 0 && u(view) && j(e1.a) == j)
          paramList.add(view); 
      } 
    } else {
      while (paramInt < k) {
        View view = getChildAt(paramInt);
        e e1 = (e)view.getLayoutParams();
        if (e1.b == 0 && u(view) && j(e1.a) == j)
          paramList.add(view); 
        paramInt++;
      } 
    } 
  }
  
  public final void b(View paramView, boolean paramBoolean) {
    e e1;
    ViewGroup.LayoutParams layoutParams = paramView.getLayoutParams();
    if (layoutParams == null) {
      e1 = h();
    } else if (!checkLayoutParams((ViewGroup.LayoutParams)e1)) {
      e1 = i((ViewGroup.LayoutParams)e1);
    } else {
      e1 = e1;
    } 
    e1.b = 1;
    if (paramBoolean && this.p != null) {
      paramView.setLayoutParams((ViewGroup.LayoutParams)e1);
      this.L.add(paramView);
      return;
    } 
    addView(paramView, (ViewGroup.LayoutParams)e1);
  }
  
  public void c() {
    if (this.o == null) {
      l l = new l(getContext(), null, 2130969466);
      this.o = l;
      l.setImageDrawable(this.m);
      this.o.setContentDescription(this.n);
      e e1 = h();
      e1.a = 0x800003 | this.u & 0x70;
      e1.b = 2;
      this.o.setLayoutParams((ViewGroup.LayoutParams)e1);
      this.o.setOnClickListener(new c(this));
    } 
  }
  
  public boolean checkLayoutParams(ViewGroup.LayoutParams paramLayoutParams) {
    return (super.checkLayoutParams(paramLayoutParams) && paramLayoutParams instanceof e);
  }
  
  public final void d() {
    if (this.A == null)
      this.A = new q0(); 
  }
  
  public final void e() {
    f();
    ActionMenuView actionMenuView = this.h;
    if (actionMenuView.w == null) {
      androidx.appcompat.view.menu.e e1 = (androidx.appcompat.view.menu.e)actionMenuView.getMenu();
      if (this.R == null)
        this.R = new d(this); 
      this.h.setExpandedActionViewsExclusive(true);
      e1.b(this.R, this.q);
    } 
  }
  
  public final void f() {
    if (this.h == null) {
      ActionMenuView actionMenuView = new ActionMenuView(getContext(), null);
      this.h = actionMenuView;
      actionMenuView.setPopupTheme(this.r);
      this.h.setOnMenuItemClickListener(this.O);
      actionMenuView = this.h;
      actionMenuView.B = null;
      actionMenuView.C = null;
      e e1 = h();
      e1.a = 0x800005 | this.u & 0x70;
      this.h.setLayoutParams((ViewGroup.LayoutParams)e1);
      b((View)this.h, false);
    } 
  }
  
  public final void g() {
    if (this.k == null) {
      this.k = new l(getContext(), null, 2130969466);
      e e1 = h();
      e1.a = 0x800003 | this.u & 0x70;
      this.k.setLayoutParams((ViewGroup.LayoutParams)e1);
    } 
  }
  
  public ViewGroup.LayoutParams generateLayoutParams(AttributeSet paramAttributeSet) {
    return (ViewGroup.LayoutParams)new e(getContext(), paramAttributeSet);
  }
  
  public CharSequence getCollapseContentDescription() {
    ImageButton imageButton = this.o;
    return (imageButton != null) ? imageButton.getContentDescription() : null;
  }
  
  public Drawable getCollapseIcon() {
    ImageButton imageButton = this.o;
    return (imageButton != null) ? imageButton.getDrawable() : null;
  }
  
  public int getContentInsetEnd() {
    q0 q01 = this.A;
    return (q01 != null) ? (q01.g ? q01.a : q01.b) : 0;
  }
  
  public int getContentInsetEndWithActions() {
    int i = this.C;
    return (i != Integer.MIN_VALUE) ? i : getContentInsetEnd();
  }
  
  public int getContentInsetLeft() {
    q0 q01 = this.A;
    return (q01 != null) ? q01.a : 0;
  }
  
  public int getContentInsetRight() {
    q0 q01 = this.A;
    return (q01 != null) ? q01.b : 0;
  }
  
  public int getContentInsetStart() {
    q0 q01 = this.A;
    return (q01 != null) ? (q01.g ? q01.b : q01.a) : 0;
  }
  
  public int getContentInsetStartWithNavigation() {
    int i = this.B;
    return (i != Integer.MIN_VALUE) ? i : getContentInsetStart();
  }
  
  public int getCurrentContentInsetEnd() {
    // Byte code:
    //   0: aload_0
    //   1: getfield h : Landroidx/appcompat/widget/ActionMenuView;
    //   4: astore_2
    //   5: aload_2
    //   6: ifnull -> 30
    //   9: aload_2
    //   10: getfield w : Landroidx/appcompat/view/menu/e;
    //   13: astore_2
    //   14: aload_2
    //   15: ifnull -> 30
    //   18: aload_2
    //   19: invokevirtual hasVisibleItems : ()Z
    //   22: ifeq -> 30
    //   25: iconst_1
    //   26: istore_1
    //   27: goto -> 32
    //   30: iconst_0
    //   31: istore_1
    //   32: iload_1
    //   33: ifeq -> 52
    //   36: aload_0
    //   37: invokevirtual getContentInsetEnd : ()I
    //   40: aload_0
    //   41: getfield C : I
    //   44: iconst_0
    //   45: invokestatic max : (II)I
    //   48: invokestatic max : (II)I
    //   51: ireturn
    //   52: aload_0
    //   53: invokevirtual getContentInsetEnd : ()I
    //   56: ireturn
  }
  
  public int getCurrentContentInsetLeft() {
    WeakHashMap weakHashMap = l.a;
    return (getLayoutDirection() == 1) ? getCurrentContentInsetEnd() : getCurrentContentInsetStart();
  }
  
  public int getCurrentContentInsetRight() {
    WeakHashMap weakHashMap = l.a;
    return (getLayoutDirection() == 1) ? getCurrentContentInsetStart() : getCurrentContentInsetEnd();
  }
  
  public int getCurrentContentInsetStart() {
    return (getNavigationIcon() != null) ? Math.max(getContentInsetStart(), Math.max(this.B, 0)) : getContentInsetStart();
  }
  
  public Drawable getLogo() {
    ImageView imageView = this.l;
    return (imageView != null) ? imageView.getDrawable() : null;
  }
  
  public CharSequence getLogoDescription() {
    ImageView imageView = this.l;
    return (imageView != null) ? imageView.getContentDescription() : null;
  }
  
  public Menu getMenu() {
    e();
    return this.h.getMenu();
  }
  
  public CharSequence getNavigationContentDescription() {
    ImageButton imageButton = this.k;
    return (imageButton != null) ? imageButton.getContentDescription() : null;
  }
  
  public Drawable getNavigationIcon() {
    ImageButton imageButton = this.k;
    return (imageButton != null) ? imageButton.getDrawable() : null;
  }
  
  public c getOuterActionMenuPresenter() {
    return this.Q;
  }
  
  public Drawable getOverflowIcon() {
    e();
    return this.h.getOverflowIcon();
  }
  
  Context getPopupContext() {
    return this.q;
  }
  
  public int getPopupTheme() {
    return this.r;
  }
  
  public CharSequence getSubtitle() {
    return this.F;
  }
  
  public final TextView getSubtitleTextView() {
    return this.j;
  }
  
  public CharSequence getTitle() {
    return this.E;
  }
  
  public int getTitleMarginBottom() {
    return this.z;
  }
  
  public int getTitleMarginEnd() {
    return this.x;
  }
  
  public int getTitleMarginStart() {
    return this.w;
  }
  
  public int getTitleMarginTop() {
    return this.y;
  }
  
  public final TextView getTitleTextView() {
    return this.i;
  }
  
  public e0 getWrapper() {
    if (this.P == null)
      this.P = new b1(this, true); 
    return this.P;
  }
  
  public e h() {
    return new e(-2, -2);
  }
  
  public e i(ViewGroup.LayoutParams paramLayoutParams) {
    return (paramLayoutParams instanceof e) ? new e((e)paramLayoutParams) : ((paramLayoutParams instanceof f.a.a) ? new e((f.a.a)paramLayoutParams) : ((paramLayoutParams instanceof ViewGroup.MarginLayoutParams) ? new e((ViewGroup.MarginLayoutParams)paramLayoutParams) : new e(paramLayoutParams)));
  }
  
  public final int j(int paramInt) {
    WeakHashMap weakHashMap = l.a;
    int i = getLayoutDirection();
    int j = Gravity.getAbsoluteGravity(paramInt, i) & 0x7;
    if (j != 1) {
      paramInt = 3;
      if (j != 3 && j != 5) {
        if (i == 1)
          paramInt = 5; 
        return paramInt;
      } 
    } 
    return j;
  }
  
  public final int k(View paramView, int paramInt) {
    e e1 = (e)paramView.getLayoutParams();
    int k = paramView.getMeasuredHeight();
    if (paramInt > 0) {
      paramInt = (k - paramInt) / 2;
    } else {
      paramInt = 0;
    } 
    int j = e1.a & 0x70;
    int i = j;
    if (j != 16) {
      i = j;
      if (j != 48) {
        i = j;
        if (j != 80)
          i = this.D & 0x70; 
      } 
    } 
    if (i != 48) {
      if (i != 80) {
        j = getPaddingTop();
        int m = getPaddingBottom();
        int n = getHeight();
        i = (n - j - m - k) / 2;
        paramInt = ((ViewGroup.MarginLayoutParams)e1).topMargin;
        if (i >= paramInt) {
          k = n - m - k - i - j;
          m = ((ViewGroup.MarginLayoutParams)e1).bottomMargin;
          paramInt = i;
          if (k < m)
            paramInt = Math.max(0, i - m - k); 
        } 
        return j + paramInt;
      } 
      return getHeight() - getPaddingBottom() - k - ((ViewGroup.MarginLayoutParams)e1).bottomMargin - paramInt;
    } 
    return getPaddingTop() - paramInt;
  }
  
  public final int l(View paramView) {
    ViewGroup.MarginLayoutParams marginLayoutParams = (ViewGroup.MarginLayoutParams)paramView.getLayoutParams();
    return marginLayoutParams.getMarginStart() + marginLayoutParams.getMarginEnd();
  }
  
  public final int m(View paramView) {
    ViewGroup.MarginLayoutParams marginLayoutParams = (ViewGroup.MarginLayoutParams)paramView.getLayoutParams();
    return marginLayoutParams.topMargin + marginLayoutParams.bottomMargin;
  }
  
  public void n(int paramInt) {
    getMenuInflater().inflate(paramInt, getMenu());
  }
  
  public final boolean o(View paramView) {
    return (paramView.getParent() == this || this.L.contains(paramView));
  }
  
  public void onDetachedFromWindow() {
    super.onDetachedFromWindow();
    removeCallbacks(this.T);
  }
  
  public boolean onHoverEvent(MotionEvent paramMotionEvent) {
    int i = paramMotionEvent.getActionMasked();
    if (i == 9)
      this.J = false; 
    if (!this.J) {
      boolean bool = super.onHoverEvent(paramMotionEvent);
      if (i == 9 && !bool)
        this.J = true; 
    } 
    if (i == 10 || i == 3)
      this.J = false; 
    return true;
  }
  
  public void onLayout(boolean paramBoolean, int paramInt1, int paramInt2, int paramInt3, int paramInt4) {
    WeakHashMap weakHashMap = l.a;
    if (getLayoutDirection() == 1) {
      k = 1;
    } else {
      k = 0;
    } 
    int n = getWidth();
    int i3 = getHeight();
    paramInt3 = getPaddingLeft();
    int i1 = getPaddingRight();
    int i2 = getPaddingTop();
    int i4 = getPaddingBottom();
    int m = n - i1;
    int[] arrayOfInt = this.M;
    arrayOfInt[1] = 0;
    arrayOfInt[0] = 0;
    paramInt1 = getMinimumHeight();
    if (paramInt1 >= 0) {
      paramInt4 = Math.min(paramInt1, paramInt4 - paramInt2);
    } else {
      paramInt4 = 0;
    } 
    if (u((View)this.k)) {
      ImageButton imageButton = this.k;
      if (k) {
        j = r((View)imageButton, m, arrayOfInt, paramInt4);
        i = paramInt3;
      } else {
        i = q((View)imageButton, paramInt3, arrayOfInt, paramInt4);
        j = m;
      } 
    } else {
      i = paramInt3;
      j = m;
    } 
    paramInt1 = i;
    paramInt2 = j;
    if (u((View)this.o)) {
      ImageButton imageButton = this.o;
      if (k) {
        paramInt2 = r((View)imageButton, j, arrayOfInt, paramInt4);
        paramInt1 = i;
      } else {
        paramInt1 = q((View)imageButton, i, arrayOfInt, paramInt4);
        paramInt2 = j;
      } 
    } 
    int j = paramInt1;
    int i = paramInt2;
    if (u((View)this.h)) {
      ActionMenuView actionMenuView = this.h;
      if (k) {
        j = q((View)actionMenuView, paramInt1, arrayOfInt, paramInt4);
        i = paramInt2;
      } else {
        i = r((View)actionMenuView, paramInt2, arrayOfInt, paramInt4);
        j = paramInt1;
      } 
    } 
    paramInt2 = getCurrentContentInsetLeft();
    paramInt1 = getCurrentContentInsetRight();
    arrayOfInt[0] = Math.max(0, paramInt2 - j);
    arrayOfInt[1] = Math.max(0, paramInt1 - m - i);
    paramInt2 = Math.max(j, paramInt2);
    i = Math.min(i, m - paramInt1);
    paramInt1 = paramInt2;
    j = i;
    if (u(this.p)) {
      View view = this.p;
      if (k) {
        j = r(view, i, arrayOfInt, paramInt4);
        paramInt1 = paramInt2;
      } else {
        paramInt1 = q(view, paramInt2, arrayOfInt, paramInt4);
        j = i;
      } 
    } 
    paramInt2 = paramInt1;
    i = j;
    if (u((View)this.l)) {
      ImageView imageView = this.l;
      if (k) {
        i = r((View)imageView, j, arrayOfInt, paramInt4);
        paramInt2 = paramInt1;
      } else {
        paramInt2 = q((View)imageView, paramInt1, arrayOfInt, paramInt4);
        i = j;
      } 
    } 
    paramBoolean = u((View)this.i);
    boolean bool = u((View)this.j);
    if (paramBoolean) {
      e e1 = (e)this.i.getLayoutParams();
      paramInt1 = ((ViewGroup.MarginLayoutParams)e1).topMargin;
      paramInt1 = this.i.getMeasuredHeight() + paramInt1 + ((ViewGroup.MarginLayoutParams)e1).bottomMargin + 0;
    } else {
      paramInt1 = 0;
    } 
    if (bool) {
      e e1 = (e)this.j.getLayoutParams();
      j = ((ViewGroup.MarginLayoutParams)e1).topMargin;
      paramInt1 += this.j.getMeasuredHeight() + j + ((ViewGroup.MarginLayoutParams)e1).bottomMargin;
    } 
    if (paramBoolean || bool) {
      TextView textView1;
      TextView textView2;
      if (paramBoolean) {
        textView1 = this.i;
      } else {
        textView1 = this.j;
      } 
      if (bool) {
        textView2 = this.j;
      } else {
        textView2 = this.i;
      } 
      e e1 = (e)textView1.getLayoutParams();
      e e2 = (e)textView2.getLayoutParams();
      if ((paramBoolean && this.i.getMeasuredWidth() > 0) || (bool && this.j.getMeasuredWidth() > 0)) {
        j = 1;
      } else {
        j = 0;
      } 
      m = this.D & 0x70;
      if (m != 48) {
        if (m != 80) {
          m = (i3 - i2 - i4 - paramInt1) / 2;
          int i5 = ((ViewGroup.MarginLayoutParams)e1).topMargin;
          int i6 = this.y;
          if (m < i5 + i6) {
            paramInt1 = i5 + i6;
          } else {
            i3 = i3 - i4 - paramInt1 - m - i2;
            i4 = ((ViewGroup.MarginLayoutParams)e1).bottomMargin;
            i5 = this.z;
            paramInt1 = m;
            if (i3 < i4 + i5)
              paramInt1 = Math.max(0, m - ((ViewGroup.MarginLayoutParams)e2).bottomMargin + i5 - i3); 
          } 
          paramInt1 = i2 + paramInt1;
        } else {
          paramInt1 = i3 - i4 - ((ViewGroup.MarginLayoutParams)e2).bottomMargin - this.z - paramInt1;
        } 
      } else {
        paramInt1 = getPaddingTop() + ((ViewGroup.MarginLayoutParams)e1).topMargin + this.y;
      } 
      m = paramInt2;
      if (k) {
        if (j != 0) {
          paramInt2 = this.w;
        } else {
          paramInt2 = 0;
        } 
        k = paramInt2 - arrayOfInt[1];
        paramInt2 = i - Math.max(0, k);
        arrayOfInt[1] = Math.max(0, -k);
        if (paramBoolean) {
          e1 = (e)this.i.getLayoutParams();
          k = paramInt2 - this.i.getMeasuredWidth();
          i = this.i.getMeasuredHeight() + paramInt1;
          this.i.layout(k, paramInt1, paramInt2, i);
          paramInt1 = k - this.x;
          k = i + ((ViewGroup.MarginLayoutParams)e1).bottomMargin;
        } else {
          i = paramInt2;
          k = paramInt1;
          paramInt1 = i;
        } 
        if (bool) {
          i = k + ((ViewGroup.MarginLayoutParams)this.j.getLayoutParams()).topMargin;
          k = this.j.getMeasuredWidth();
          i2 = this.j.getMeasuredHeight();
          this.j.layout(paramInt2 - k, i, paramInt2, i2 + i);
          i = paramInt2 - this.x;
        } else {
          i = paramInt2;
        } 
        if (j != 0)
          paramInt2 = Math.min(paramInt1, i); 
        paramInt1 = m;
        i = paramInt2;
      } else {
        if (j != 0) {
          paramInt2 = this.w;
        } else {
          paramInt2 = 0;
        } 
        k = paramInt2 - arrayOfInt[0];
        paramInt2 = Math.max(0, k) + m;
        arrayOfInt[0] = Math.max(0, -k);
        if (paramBoolean) {
          e1 = (e)this.i.getLayoutParams();
          m = this.i.getMeasuredWidth() + paramInt2;
          k = this.i.getMeasuredHeight() + paramInt1;
          this.i.layout(paramInt2, paramInt1, m, k);
          paramInt1 = m + this.x;
          m = k + ((ViewGroup.MarginLayoutParams)e1).bottomMargin;
        } else {
          k = paramInt2;
          m = paramInt1;
          paramInt1 = k;
        } 
        if (bool) {
          k = m + ((ViewGroup.MarginLayoutParams)this.j.getLayoutParams()).topMargin;
          m = this.j.getMeasuredWidth() + paramInt2;
          i2 = this.j.getMeasuredHeight();
          this.j.layout(paramInt2, k, m, i2 + k);
          k = m + this.x;
        } else {
          k = paramInt2;
        } 
        if (j != 0) {
          paramInt1 = Math.max(paramInt1, k);
        } else {
          paramInt1 = paramInt2;
        } 
      } 
    } else {
      paramInt1 = paramInt2;
    } 
    int k = paramInt4;
    m = paramInt3;
    a(this.K, 3);
    paramInt3 = this.K.size();
    for (paramInt2 = 0; paramInt2 < paramInt3; paramInt2++)
      paramInt1 = q(this.K.get(paramInt2), paramInt1, arrayOfInt, k); 
    a(this.K, 5);
    paramInt3 = this.K.size();
    for (paramInt2 = 0; paramInt2 < paramInt3; paramInt2++)
      i = r(this.K.get(paramInt2), i, arrayOfInt, k); 
    a(this.K, 1);
    ArrayList<View> arrayList = this.K;
    j = arrayOfInt[0];
    paramInt4 = arrayOfInt[1];
    i2 = arrayList.size();
    paramInt3 = 0;
    paramInt2 = 0;
    while (paramInt3 < i2) {
      View view = arrayList.get(paramInt3);
      e e1 = (e)view.getLayoutParams();
      j = ((ViewGroup.MarginLayoutParams)e1).leftMargin - j;
      paramInt4 = ((ViewGroup.MarginLayoutParams)e1).rightMargin - paramInt4;
      i3 = Math.max(0, j);
      i4 = Math.max(0, paramInt4);
      j = Math.max(0, -j);
      paramInt4 = Math.max(0, -paramInt4);
      paramInt2 += view.getMeasuredWidth() + i3 + i4;
      paramInt3++;
    } 
    paramInt3 = (n - m - i1) / 2 + m - paramInt2 / 2;
    paramInt2 += paramInt3;
    if (paramInt3 >= paramInt1)
      if (paramInt2 > i) {
        paramInt1 = paramInt3 - paramInt2 - i;
      } else {
        paramInt1 = paramInt3;
      }  
    paramInt3 = this.K.size();
    paramInt2 = paramInt1;
    for (paramInt1 = 0; paramInt1 < paramInt3; paramInt1++)
      paramInt2 = q(this.K.get(paramInt1), paramInt2, arrayOfInt, k); 
    this.K.clear();
  }
  
  public void onMeasure(int paramInt1, int paramInt2) {
    throw new RuntimeException("d2j fail translate: java.lang.RuntimeException: can not merge I and Z\r\n\tat com.googlecode.dex2jar.ir.TypeClass.merge(TypeClass.java:100)\r\n\tat com.googlecode.dex2jar.ir.ts.TypeTransformer$TypeRef.updateTypeClass(TypeTransformer.java:174)\r\n\tat com.googlecode.dex2jar.ir.ts.TypeTransformer$TypeAnalyze.copyTypes(TypeTransformer.java:311)\r\n\tat com.googlecode.dex2jar.ir.ts.TypeTransformer$TypeAnalyze.fixTypes(TypeTransformer.java:226)\r\n\tat com.googlecode.dex2jar.ir.ts.TypeTransformer$TypeAnalyze.analyze(TypeTransformer.java:207)\r\n\tat com.googlecode.dex2jar.ir.ts.TypeTransformer.transform(TypeTransformer.java:44)\r\n\tat com.googlecode.d2j.dex.Dex2jar$2.optimize(Dex2jar.java:162)\r\n\tat com.googlecode.d2j.dex.Dex2Asm.convertCode(Dex2Asm.java:414)\r\n\tat com.googlecode.d2j.dex.ExDex2Asm.convertCode(ExDex2Asm.java:42)\r\n\tat com.googlecode.d2j.dex.Dex2jar$2.convertCode(Dex2jar.java:128)\r\n\tat com.googlecode.d2j.dex.Dex2Asm.convertMethod(Dex2Asm.java:509)\r\n\tat com.googlecode.d2j.dex.Dex2Asm.convertClass(Dex2Asm.java:406)\r\n\tat com.googlecode.d2j.dex.Dex2Asm.convertDex(Dex2Asm.java:422)\r\n\tat com.googlecode.d2j.dex.Dex2jar.doTranslate(Dex2jar.java:172)\r\n\tat com.googlecode.d2j.dex.Dex2jar.to(Dex2jar.java:272)\r\n\tat com.googlecode.dex2jar.tools.Dex2jarCmd.doCommandLine(Dex2jarCmd.java:108)\r\n\tat com.googlecode.dex2jar.tools.BaseCmd.doMain(BaseCmd.java:288)\r\n\tat com.googlecode.dex2jar.tools.Dex2jarCmd.main(Dex2jarCmd.java:32)\r\n");
  }
  
  public void onRestoreInstanceState(Parcelable paramParcelable) {
    if (!(paramParcelable instanceof g)) {
      super.onRestoreInstanceState(paramParcelable);
      return;
    } 
    g g = (g)paramParcelable;
    super.onRestoreInstanceState(g.h);
    ActionMenuView actionMenuView = this.h;
    if (actionMenuView != null) {
      androidx.appcompat.view.menu.e e1 = actionMenuView.w;
    } else {
      actionMenuView = null;
    } 
    int i = g.j;
    if (i != 0 && this.R != null && actionMenuView != null) {
      MenuItem menuItem = actionMenuView.findItem(i);
      if (menuItem != null)
        menuItem.expandActionView(); 
    } 
    if (g.k) {
      removeCallbacks(this.T);
      post(this.T);
    } 
  }
  
  public void onRtlPropertiesChanged(int paramInt) {
    super.onRtlPropertiesChanged(paramInt);
    d();
    q0 q01 = this.A;
    boolean bool = true;
    if (paramInt != 1)
      bool = false; 
    if (bool == q01.g)
      return; 
    q01.g = bool;
    if (q01.h) {
      if (bool) {
        paramInt = q01.d;
        if (paramInt == Integer.MIN_VALUE)
          paramInt = q01.e; 
        q01.a = paramInt;
        paramInt = q01.c;
        if (paramInt != Integer.MIN_VALUE) {
          q01.b = paramInt;
          return;
        } 
      } else {
        paramInt = q01.c;
        if (paramInt == Integer.MIN_VALUE)
          paramInt = q01.e; 
        q01.a = paramInt;
        paramInt = q01.d;
        if (paramInt != Integer.MIN_VALUE) {
          q01.b = paramInt;
          return;
        } 
      } 
    } else {
      q01.a = q01.e;
    } 
    paramInt = q01.f;
    q01.b = paramInt;
  }
  
  public Parcelable onSaveInstanceState() {
    g g = new g(super.onSaveInstanceState());
    d d1 = this.R;
    if (d1 != null) {
      androidx.appcompat.view.menu.g g1 = d1.i;
      if (g1 != null)
        g.j = g1.a; 
    } 
    g.k = p();
    return (Parcelable)g;
  }
  
  public boolean onTouchEvent(MotionEvent paramMotionEvent) {
    int i = paramMotionEvent.getActionMasked();
    if (i == 0)
      this.I = false; 
    if (!this.I) {
      boolean bool = super.onTouchEvent(paramMotionEvent);
      if (i == 0 && !bool)
        this.I = true; 
    } 
    if (i == 1 || i == 3)
      this.I = false; 
    return true;
  }
  
  public boolean p() {
    ActionMenuView actionMenuView = this.h;
    if (actionMenuView != null) {
      boolean bool;
      c c1 = actionMenuView.A;
      if (c1 != null && c1.m()) {
        bool = true;
      } else {
        bool = false;
      } 
      if (bool)
        return true; 
    } 
    return false;
  }
  
  public final int q(View paramView, int paramInt1, int[] paramArrayOfint, int paramInt2) {
    e e1 = (e)paramView.getLayoutParams();
    int i = ((ViewGroup.MarginLayoutParams)e1).leftMargin - paramArrayOfint[0];
    paramInt1 = Math.max(0, i) + paramInt1;
    paramArrayOfint[0] = Math.max(0, -i);
    paramInt2 = k(paramView, paramInt2);
    i = paramView.getMeasuredWidth();
    paramView.layout(paramInt1, paramInt2, paramInt1 + i, paramView.getMeasuredHeight() + paramInt2);
    return i + ((ViewGroup.MarginLayoutParams)e1).rightMargin + paramInt1;
  }
  
  public final int r(View paramView, int paramInt1, int[] paramArrayOfint, int paramInt2) {
    e e1 = (e)paramView.getLayoutParams();
    int i = ((ViewGroup.MarginLayoutParams)e1).rightMargin - paramArrayOfint[1];
    paramInt1 -= Math.max(0, i);
    paramArrayOfint[1] = Math.max(0, -i);
    paramInt2 = k(paramView, paramInt2);
    i = paramView.getMeasuredWidth();
    paramView.layout(paramInt1 - i, paramInt2, paramInt1, paramView.getMeasuredHeight() + paramInt2);
    return paramInt1 - i + ((ViewGroup.MarginLayoutParams)e1).leftMargin;
  }
  
  public final int s(View paramView, int paramInt1, int paramInt2, int paramInt3, int paramInt4, int[] paramArrayOfint) {
    ViewGroup.MarginLayoutParams marginLayoutParams = (ViewGroup.MarginLayoutParams)paramView.getLayoutParams();
    int j = marginLayoutParams.leftMargin - paramArrayOfint[0];
    int k = marginLayoutParams.rightMargin - paramArrayOfint[1];
    int i = Math.max(0, j);
    i = Math.max(0, k) + i;
    paramArrayOfint[0] = Math.max(0, -j);
    paramArrayOfint[1] = Math.max(0, -k);
    j = getPaddingLeft();
    paramInt1 = ViewGroup.getChildMeasureSpec(paramInt1, getPaddingRight() + j + i + paramInt2, marginLayoutParams.width);
    paramInt2 = getPaddingTop();
    paramView.measure(paramInt1, ViewGroup.getChildMeasureSpec(paramInt3, getPaddingBottom() + paramInt2 + marginLayoutParams.topMargin + marginLayoutParams.bottomMargin + paramInt4, marginLayoutParams.height));
    return paramView.getMeasuredWidth() + i;
  }
  
  public void setCollapseContentDescription(int paramInt) {
    CharSequence charSequence;
    if (paramInt != 0) {
      charSequence = getContext().getText(paramInt);
    } else {
      charSequence = null;
    } 
    setCollapseContentDescription(charSequence);
  }
  
  public void setCollapseContentDescription(CharSequence paramCharSequence) {
    if (!TextUtils.isEmpty(paramCharSequence))
      c(); 
    ImageButton imageButton = this.o;
    if (imageButton != null)
      imageButton.setContentDescription(paramCharSequence); 
  }
  
  public void setCollapseIcon(int paramInt) {
    setCollapseIcon(g.a.b(getContext(), paramInt));
  }
  
  public void setCollapseIcon(Drawable paramDrawable) {
    if (paramDrawable != null) {
      c();
      this.o.setImageDrawable(paramDrawable);
      return;
    } 
    ImageButton imageButton = this.o;
    if (imageButton != null)
      imageButton.setImageDrawable(this.m); 
  }
  
  public void setCollapsible(boolean paramBoolean) {
    this.S = paramBoolean;
    requestLayout();
  }
  
  public void setContentInsetEndWithActions(int paramInt) {
    int i = paramInt;
    if (paramInt < 0)
      i = Integer.MIN_VALUE; 
    if (i != this.C) {
      this.C = i;
      if (getNavigationIcon() != null)
        requestLayout(); 
    } 
  }
  
  public void setContentInsetStartWithNavigation(int paramInt) {
    int i = paramInt;
    if (paramInt < 0)
      i = Integer.MIN_VALUE; 
    if (i != this.B) {
      this.B = i;
      if (getNavigationIcon() != null)
        requestLayout(); 
    } 
  }
  
  public void setLogo(int paramInt) {
    setLogo(g.a.b(getContext(), paramInt));
  }
  
  public void setLogo(Drawable paramDrawable) {
    if (paramDrawable != null) {
      if (this.l == null)
        this.l = new n(getContext(), null, 0); 
      if (!o((View)this.l))
        b((View)this.l, true); 
    } else {
      ImageView imageView1 = this.l;
      if (imageView1 != null && o((View)imageView1)) {
        removeView((View)this.l);
        this.L.remove(this.l);
      } 
    } 
    ImageView imageView = this.l;
    if (imageView != null)
      imageView.setImageDrawable(paramDrawable); 
  }
  
  public void setLogoDescription(int paramInt) {
    setLogoDescription(getContext().getText(paramInt));
  }
  
  public void setLogoDescription(CharSequence paramCharSequence) {
    if (!TextUtils.isEmpty(paramCharSequence) && this.l == null)
      this.l = new n(getContext(), null, 0); 
    ImageView imageView = this.l;
    if (imageView != null)
      imageView.setContentDescription(paramCharSequence); 
  }
  
  public void setNavigationContentDescription(int paramInt) {
    CharSequence charSequence;
    if (paramInt != 0) {
      charSequence = getContext().getText(paramInt);
    } else {
      charSequence = null;
    } 
    setNavigationContentDescription(charSequence);
  }
  
  public void setNavigationContentDescription(CharSequence paramCharSequence) {
    if (!TextUtils.isEmpty(paramCharSequence))
      g(); 
    ImageButton imageButton = this.k;
    if (imageButton != null)
      imageButton.setContentDescription(paramCharSequence); 
  }
  
  public void setNavigationIcon(int paramInt) {
    setNavigationIcon(g.a.b(getContext(), paramInt));
  }
  
  public void setNavigationIcon(Drawable paramDrawable) {
    if (paramDrawable != null) {
      g();
      if (!o((View)this.k))
        b((View)this.k, true); 
    } else {
      ImageButton imageButton1 = this.k;
      if (imageButton1 != null && o((View)imageButton1)) {
        removeView((View)this.k);
        this.L.remove(this.k);
      } 
    } 
    ImageButton imageButton = this.k;
    if (imageButton != null)
      imageButton.setImageDrawable(paramDrawable); 
  }
  
  public void setNavigationOnClickListener(View.OnClickListener paramOnClickListener) {
    g();
    this.k.setOnClickListener(paramOnClickListener);
  }
  
  public void setOnMenuItemClickListener(f paramf) {
    this.N = paramf;
  }
  
  public void setOverflowIcon(Drawable paramDrawable) {
    e();
    this.h.setOverflowIcon(paramDrawable);
  }
  
  public void setPopupTheme(int paramInt) {
    if (this.r != paramInt) {
      this.r = paramInt;
      if (paramInt == 0) {
        this.q = getContext();
        return;
      } 
      this.q = (Context)new ContextThemeWrapper(getContext(), paramInt);
    } 
  }
  
  public void setSubtitle(int paramInt) {
    setSubtitle(getContext().getText(paramInt));
  }
  
  public void setSubtitle(CharSequence paramCharSequence) {
    if (!TextUtils.isEmpty(paramCharSequence)) {
      if (this.j == null) {
        Context context = getContext();
        a0 a0 = new a0(context, null);
        this.j = a0;
        a0.setSingleLine();
        this.j.setEllipsize(TextUtils.TruncateAt.END);
        int i = this.t;
        if (i != 0)
          this.j.setTextAppearance(context, i); 
        ColorStateList colorStateList = this.H;
        if (colorStateList != null)
          this.j.setTextColor(colorStateList); 
      } 
      if (!o((View)this.j))
        b((View)this.j, true); 
    } else {
      TextView textView1 = this.j;
      if (textView1 != null && o((View)textView1)) {
        removeView((View)this.j);
        this.L.remove(this.j);
      } 
    } 
    TextView textView = this.j;
    if (textView != null)
      textView.setText(paramCharSequence); 
    this.F = paramCharSequence;
  }
  
  public void setSubtitleTextColor(int paramInt) {
    setSubtitleTextColor(ColorStateList.valueOf(paramInt));
  }
  
  public void setSubtitleTextColor(ColorStateList paramColorStateList) {
    this.H = paramColorStateList;
    TextView textView = this.j;
    if (textView != null)
      textView.setTextColor(paramColorStateList); 
  }
  
  public void setTitle(int paramInt) {
    setTitle(getContext().getText(paramInt));
  }
  
  public void setTitle(CharSequence paramCharSequence) {
    if (!TextUtils.isEmpty(paramCharSequence)) {
      if (this.i == null) {
        Context context = getContext();
        a0 a0 = new a0(context, null);
        this.i = a0;
        a0.setSingleLine();
        this.i.setEllipsize(TextUtils.TruncateAt.END);
        int i = this.s;
        if (i != 0)
          this.i.setTextAppearance(context, i); 
        ColorStateList colorStateList = this.G;
        if (colorStateList != null)
          this.i.setTextColor(colorStateList); 
      } 
      if (!o((View)this.i))
        b((View)this.i, true); 
    } else {
      TextView textView1 = this.i;
      if (textView1 != null && o((View)textView1)) {
        removeView((View)this.i);
        this.L.remove(this.i);
      } 
    } 
    TextView textView = this.i;
    if (textView != null)
      textView.setText(paramCharSequence); 
    this.E = paramCharSequence;
  }
  
  public void setTitleMarginBottom(int paramInt) {
    this.z = paramInt;
    requestLayout();
  }
  
  public void setTitleMarginEnd(int paramInt) {
    this.x = paramInt;
    requestLayout();
  }
  
  public void setTitleMarginStart(int paramInt) {
    this.w = paramInt;
    requestLayout();
  }
  
  public void setTitleMarginTop(int paramInt) {
    this.y = paramInt;
    requestLayout();
  }
  
  public void setTitleTextColor(int paramInt) {
    setTitleTextColor(ColorStateList.valueOf(paramInt));
  }
  
  public void setTitleTextColor(ColorStateList paramColorStateList) {
    this.G = paramColorStateList;
    TextView textView = this.i;
    if (textView != null)
      textView.setTextColor(paramColorStateList); 
  }
  
  public final void t(View paramView, int paramInt1, int paramInt2, int paramInt3, int paramInt4, int paramInt5) {
    ViewGroup.MarginLayoutParams marginLayoutParams = (ViewGroup.MarginLayoutParams)paramView.getLayoutParams();
    int i = getPaddingLeft();
    i = ViewGroup.getChildMeasureSpec(paramInt1, getPaddingRight() + i + marginLayoutParams.leftMargin + marginLayoutParams.rightMargin + paramInt2, marginLayoutParams.width);
    paramInt1 = getPaddingTop();
    paramInt2 = ViewGroup.getChildMeasureSpec(paramInt3, getPaddingBottom() + paramInt1 + marginLayoutParams.topMargin + marginLayoutParams.bottomMargin + paramInt4, marginLayoutParams.height);
    paramInt3 = View.MeasureSpec.getMode(paramInt2);
    paramInt1 = paramInt2;
    if (paramInt3 != 1073741824) {
      paramInt1 = paramInt2;
      if (paramInt5 >= 0) {
        paramInt1 = paramInt5;
        if (paramInt3 != 0)
          paramInt1 = Math.min(View.MeasureSpec.getSize(paramInt2), paramInt5); 
        paramInt1 = View.MeasureSpec.makeMeasureSpec(paramInt1, 1073741824);
      } 
    } 
    paramView.measure(i, paramInt1);
  }
  
  public final boolean u(View paramView) {
    return (paramView != null && paramView.getParent() == this && paramView.getVisibility() != 8);
  }
  
  public boolean v() {
    ActionMenuView actionMenuView = this.h;
    if (actionMenuView != null) {
      boolean bool;
      c c1 = actionMenuView.A;
      if (c1 != null && c1.n()) {
        bool = true;
      } else {
        bool = false;
      } 
      if (bool)
        return true; 
    } 
    return false;
  }
  
  public class a implements ActionMenuView.e {
    public a(Toolbar this$0) {}
  }
  
  public class b implements Runnable {
    public b(Toolbar this$0) {}
    
    public void run() {
      this.h.v();
    }
  }
  
  public class c implements View.OnClickListener {
    public c(Toolbar this$0) {}
    
    public void onClick(View param1View) {
      androidx.appcompat.view.menu.g g;
      Toolbar.d d = this.h.R;
      if (d == null) {
        d = null;
      } else {
        g = d.i;
      } 
      if (g != null)
        g.collapseActionView(); 
    }
  }
  
  public class d implements i {
    public androidx.appcompat.view.menu.e h;
    
    public androidx.appcompat.view.menu.g i;
    
    public d(Toolbar this$0) {}
    
    public void a(androidx.appcompat.view.menu.e param1e, boolean param1Boolean) {}
    
    public void c(Context param1Context, androidx.appcompat.view.menu.e param1e) {
      androidx.appcompat.view.menu.e e1 = this.h;
      if (e1 != null) {
        androidx.appcompat.view.menu.g g1 = this.i;
        if (g1 != null)
          e1.d(g1); 
      } 
      this.h = param1e;
    }
    
    public boolean e(l param1l) {
      return false;
    }
    
    public void f(boolean param1Boolean) {
      if (this.i != null) {
        androidx.appcompat.view.menu.e e1 = this.h;
        boolean bool2 = false;
        boolean bool1 = bool2;
        if (e1 != null) {
          int k = e1.size();
          int j = 0;
          while (true) {
            bool1 = bool2;
            if (j < k) {
              if (this.h.getItem(j) == this.i) {
                bool1 = true;
                break;
              } 
              j++;
              continue;
            } 
            break;
          } 
        } 
        if (!bool1)
          i(this.h, this.i); 
      } 
    }
    
    public boolean h() {
      return false;
    }
    
    public boolean i(androidx.appcompat.view.menu.e param1e, androidx.appcompat.view.menu.g param1g) {
      View view = this.j.p;
      if (view instanceof j.b)
        ((j.b)view).d(); 
      Toolbar toolbar = this.j;
      toolbar.removeView(toolbar.p);
      toolbar = this.j;
      toolbar.removeView((View)toolbar.o);
      toolbar = this.j;
      toolbar.p = null;
      int j = toolbar.L.size();
      while (true) {
        if (--j >= 0) {
          toolbar.addView(toolbar.L.get(j));
          continue;
        } 
        toolbar.L.clear();
        this.i = null;
        this.j.requestLayout();
        param1g.C = false;
        param1g.n.p(false);
        return true;
      } 
    }
    
    public boolean j(androidx.appcompat.view.menu.e param1e, androidx.appcompat.view.menu.g param1g) {
      this.j.c();
      ViewParent viewParent = this.j.o.getParent();
      Toolbar toolbar2 = this.j;
      if (viewParent != toolbar2) {
        if (viewParent instanceof ViewGroup)
          ((ViewGroup)viewParent).removeView((View)toolbar2.o); 
        Toolbar toolbar = this.j;
        toolbar.addView((View)toolbar.o);
      } 
      this.j.p = param1g.getActionView();
      this.i = param1g;
      viewParent = this.j.p.getParent();
      toolbar2 = this.j;
      if (viewParent != toolbar2) {
        if (viewParent instanceof ViewGroup)
          ((ViewGroup)viewParent).removeView(toolbar2.p); 
        Toolbar.e e1 = this.j.h();
        toolbar2 = this.j;
        e1.a = 0x800003 | toolbar2.u & 0x70;
        e1.b = 2;
        toolbar2.p.setLayoutParams((ViewGroup.LayoutParams)e1);
        Toolbar toolbar = this.j;
        toolbar.addView(toolbar.p);
      } 
      Toolbar toolbar1 = this.j;
      int j = toolbar1.getChildCount();
      while (true) {
        int k = j - 1;
        if (k >= 0) {
          View view1 = toolbar1.getChildAt(k);
          j = k;
          if (((Toolbar.e)view1.getLayoutParams()).b != 2) {
            j = k;
            if (view1 != toolbar1.h) {
              toolbar1.removeViewAt(k);
              toolbar1.L.add(view1);
              j = k;
            } 
          } 
          continue;
        } 
        this.j.requestLayout();
        param1g.C = true;
        param1g.n.p(false);
        View view = this.j.p;
        if (view instanceof j.b)
          ((j.b)view).c(); 
        return true;
      } 
    }
  }
  
  public static class e extends f.a.a {
    public int b = 0;
    
    public e(int param1Int1, int param1Int2) {
      super(param1Int1, param1Int2);
      this.a = 8388627;
    }
    
    public e(Context param1Context, AttributeSet param1AttributeSet) {
      super(param1Context, param1AttributeSet);
    }
    
    public e(ViewGroup.LayoutParams param1LayoutParams) {
      super(param1LayoutParams);
    }
    
    public e(ViewGroup.MarginLayoutParams param1MarginLayoutParams) {
      super((ViewGroup.LayoutParams)param1MarginLayoutParams);
      ((ViewGroup.MarginLayoutParams)this).leftMargin = param1MarginLayoutParams.leftMargin;
      ((ViewGroup.MarginLayoutParams)this).topMargin = param1MarginLayoutParams.topMargin;
      ((ViewGroup.MarginLayoutParams)this).rightMargin = param1MarginLayoutParams.rightMargin;
      ((ViewGroup.MarginLayoutParams)this).bottomMargin = param1MarginLayoutParams.bottomMargin;
    }
    
    public e(e param1e) {
      super(param1e);
      this.b = param1e.b;
    }
    
    public e(f.a.a param1a) {
      super(param1a);
    }
  }
  
  public static interface f {
    boolean onMenuItemClick(MenuItem param1MenuItem);
  }
  
  public static class g extends o0.a {
    public static final Parcelable.Creator<g> CREATOR = (Parcelable.Creator<g>)new a();
    
    public int j;
    
    public boolean k;
    
    public g(Parcel param1Parcel, ClassLoader param1ClassLoader) {
      super(param1Parcel, param1ClassLoader);
      boolean bool;
      this.j = param1Parcel.readInt();
      if (param1Parcel.readInt() != 0) {
        bool = true;
      } else {
        bool = false;
      } 
      this.k = bool;
    }
    
    public g(Parcelable param1Parcelable) {
      super(param1Parcelable);
    }
    
    public void writeToParcel(Parcel param1Parcel, int param1Int) {
      throw new RuntimeException("d2j fail translate: java.lang.RuntimeException: can not merge I and Z\r\n\tat com.googlecode.dex2jar.ir.TypeClass.merge(TypeClass.java:100)\r\n\tat com.googlecode.dex2jar.ir.ts.TypeTransformer$TypeRef.updateTypeClass(TypeTransformer.java:174)\r\n\tat com.googlecode.dex2jar.ir.ts.TypeTransformer$TypeAnalyze.provideAs(TypeTransformer.java:780)\r\n\tat com.googlecode.dex2jar.ir.ts.TypeTransformer$TypeAnalyze.e1expr(TypeTransformer.java:496)\r\n\tat com.googlecode.dex2jar.ir.ts.TypeTransformer$TypeAnalyze.exExpr(TypeTransformer.java:713)\r\n\tat com.googlecode.dex2jar.ir.ts.TypeTransformer$TypeAnalyze.exExpr(TypeTransformer.java:703)\r\n\tat com.googlecode.dex2jar.ir.ts.TypeTransformer$TypeAnalyze.enexpr(TypeTransformer.java:698)\r\n\tat com.googlecode.dex2jar.ir.ts.TypeTransformer$TypeAnalyze.exExpr(TypeTransformer.java:719)\r\n\tat com.googlecode.dex2jar.ir.ts.TypeTransformer$TypeAnalyze.exExpr(TypeTransformer.java:703)\r\n\tat com.googlecode.dex2jar.ir.ts.TypeTransformer$TypeAnalyze.s1stmt(TypeTransformer.java:810)\r\n\tat com.googlecode.dex2jar.ir.ts.TypeTransformer$TypeAnalyze.sxStmt(TypeTransformer.java:840)\r\n\tat com.googlecode.dex2jar.ir.ts.TypeTransformer$TypeAnalyze.analyze(TypeTransformer.java:206)\r\n\tat com.googlecode.dex2jar.ir.ts.TypeTransformer.transform(TypeTransformer.java:44)\r\n\tat com.googlecode.d2j.dex.Dex2jar$2.optimize(Dex2jar.java:162)\r\n\tat com.googlecode.d2j.dex.Dex2Asm.convertCode(Dex2Asm.java:414)\r\n\tat com.googlecode.d2j.dex.ExDex2Asm.convertCode(ExDex2Asm.java:42)\r\n\tat com.googlecode.d2j.dex.Dex2jar$2.convertCode(Dex2jar.java:128)\r\n\tat com.googlecode.d2j.dex.Dex2Asm.convertMethod(Dex2Asm.java:509)\r\n\tat com.googlecode.d2j.dex.Dex2Asm.convertClass(Dex2Asm.java:406)\r\n\tat com.googlecode.d2j.dex.Dex2Asm.convertDex(Dex2Asm.java:422)\r\n\tat com.googlecode.d2j.dex.Dex2jar.doTranslate(Dex2jar.java:172)\r\n\tat com.googlecode.d2j.dex.Dex2jar.to(Dex2jar.java:272)\r\n\tat com.googlecode.dex2jar.tools.Dex2jarCmd.doCommandLine(Dex2jarCmd.java:108)\r\n\tat com.googlecode.dex2jar.tools.BaseCmd.doMain(BaseCmd.java:288)\r\n\tat com.googlecode.dex2jar.tools.Dex2jarCmd.main(Dex2jarCmd.java:32)\r\n");
    }
    
    public class a implements Parcelable.ClassLoaderCreator<g> {
      public Object createFromParcel(Parcel param2Parcel) {
        return new Toolbar.g(param2Parcel, null);
      }
      
      public Object createFromParcel(Parcel param2Parcel, ClassLoader param2ClassLoader) {
        return new Toolbar.g(param2Parcel, param2ClassLoader);
      }
      
      public Object[] newArray(int param2Int) {
        return (Object[])new Toolbar.g[param2Int];
      }
    }
  }
  
  public class a implements Parcelable.ClassLoaderCreator<g> {
    public Object createFromParcel(Parcel param1Parcel) {
      return new Toolbar.g(param1Parcel, null);
    }
    
    public Object createFromParcel(Parcel param1Parcel, ClassLoader param1ClassLoader) {
      return new Toolbar.g(param1Parcel, param1ClassLoader);
    }
    
    public Object[] newArray(int param1Int) {
      return (Object[])new Toolbar.g[param1Int];
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Luxury Logo Maker_ Logo Design-dex2jar.jar!\androidx\appcompat\widget\Toolbar.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */