package androidx.appcompat.widget;

import android.content.Context;
import android.content.ContextWrapper;

public class w0 extends ContextWrapper {
  public static final Object a = new Object();
  
  public static Context a(Context paramContext) {
    if (!(paramContext instanceof w0) && !(paramContext.getResources() instanceof y0)) {
      paramContext.getResources();
      int i = f1.a;
    } 
    return paramContext;
  }
}


/* Location:              C:\soft\dex2jar-2.0\Luxury Logo Maker_ Logo Design-dex2jar.jar!\androidx\appcompat\widget\w0.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */