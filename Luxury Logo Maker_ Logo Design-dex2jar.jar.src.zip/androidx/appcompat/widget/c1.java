package androidx.appcompat.widget;

import android.os.Build;
import android.text.TextUtils;
import android.view.View;

public class c1 {
  public static void a(View paramView, CharSequence paramCharSequence) {
    d1 d11;
    if (Build.VERSION.SDK_INT >= 26) {
      paramView.setTooltipText(paramCharSequence);
      return;
    } 
    d1 d12 = d1.q;
    if (d12 != null && d12.h == paramView)
      d1.c(null); 
    if (TextUtils.isEmpty(paramCharSequence)) {
      d11 = d1.r;
      if (d11 != null && d11.h == paramView)
        d11.b(); 
      paramView.setOnLongClickListener(null);
      paramView.setLongClickable(false);
      paramView.setOnHoverListener(null);
      return;
    } 
    new d1(paramView, (CharSequence)d11);
  }
}


/* Location:              C:\soft\dex2jar-2.0\Luxury Logo Maker_ Logo Design-dex2jar.jar!\androidx\appcompat\widget\c1.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */