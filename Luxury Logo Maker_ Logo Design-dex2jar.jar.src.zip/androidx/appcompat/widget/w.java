package androidx.appcompat.widget;

import android.content.Context;
import android.content.DialogInterface;
import android.content.res.ColorStateList;
import android.content.res.Resources;
import android.database.DataSetObserver;
import android.graphics.PorterDuff;
import android.graphics.Rect;
import android.graphics.drawable.Drawable;
import android.os.Build;
import android.os.Parcel;
import android.os.Parcelable;
import android.util.AttributeSet;
import android.util.Log;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.view.ViewTreeObserver;
import android.widget.Adapter;
import android.widget.AdapterView;
import android.widget.ListAdapter;
import android.widget.ListView;
import android.widget.PopupWindow;
import android.widget.Spinner;
import android.widget.SpinnerAdapter;
import android.widget.ThemedSpinnerAdapter;
import androidx.appcompat.app.AlertController;
import java.util.Objects;
import java.util.WeakHashMap;
import k0.l;

public class w extends Spinner {
  public static final int[] p = new int[] { 16843505 };
  
  public final e h;
  
  public final Context i;
  
  public i0 j;
  
  public SpinnerAdapter k;
  
  public final boolean l;
  
  public f m;
  
  public int n;
  
  public final Rect o;
  
  public w(Context paramContext, AttributeSet paramAttributeSet, int paramInt) {
    // Byte code:
    //   0: aload_0
    //   1: aload_1
    //   2: aload_2
    //   3: iload_3
    //   4: invokespecial <init> : (Landroid/content/Context;Landroid/util/AttributeSet;I)V
    //   7: aload_0
    //   8: new android/graphics/Rect
    //   11: dup
    //   12: invokespecial <init> : ()V
    //   15: putfield o : Landroid/graphics/Rect;
    //   18: aload_0
    //   19: aload_0
    //   20: invokevirtual getContext : ()Landroid/content/Context;
    //   23: invokestatic a : (Landroid/view/View;Landroid/content/Context;)V
    //   26: aload_1
    //   27: aload_2
    //   28: getstatic com/bumptech/glide/manager/b.C : [I
    //   31: iload_3
    //   32: iconst_0
    //   33: invokevirtual obtainStyledAttributes : (Landroid/util/AttributeSet;[III)Landroid/content/res/TypedArray;
    //   36: astore #9
    //   38: aload_0
    //   39: new androidx/appcompat/widget/e
    //   42: dup
    //   43: aload_0
    //   44: invokespecial <init> : (Landroid/view/View;)V
    //   47: putfield h : Landroidx/appcompat/widget/e;
    //   50: aload #9
    //   52: iconst_4
    //   53: iconst_0
    //   54: invokevirtual getResourceId : (II)I
    //   57: istore #4
    //   59: iload #4
    //   61: ifeq -> 81
    //   64: aload_0
    //   65: new j/c
    //   68: dup
    //   69: aload_1
    //   70: iload #4
    //   72: invokespecial <init> : (Landroid/content/Context;I)V
    //   75: putfield i : Landroid/content/Context;
    //   78: goto -> 86
    //   81: aload_0
    //   82: aload_1
    //   83: putfield i : Landroid/content/Context;
    //   86: aconst_null
    //   87: astore #7
    //   89: iconst_m1
    //   90: istore #5
    //   92: aload_1
    //   93: aload_2
    //   94: getstatic androidx/appcompat/widget/w.p : [I
    //   97: iload_3
    //   98: iconst_0
    //   99: invokevirtual obtainStyledAttributes : (Landroid/util/AttributeSet;[III)Landroid/content/res/TypedArray;
    //   102: astore #6
    //   104: aload #6
    //   106: astore #7
    //   108: iload #5
    //   110: istore #4
    //   112: aload #6
    //   114: astore #8
    //   116: aload #6
    //   118: iconst_0
    //   119: invokevirtual hasValue : (I)Z
    //   122: ifeq -> 200
    //   125: aload #6
    //   127: astore #7
    //   129: aload #6
    //   131: iconst_0
    //   132: iconst_0
    //   133: invokevirtual getInt : (II)I
    //   136: istore #4
    //   138: aload #6
    //   140: astore #8
    //   142: goto -> 200
    //   145: astore_2
    //   146: aload #7
    //   148: astore_1
    //   149: goto -> 426
    //   152: astore #8
    //   154: goto -> 169
    //   157: astore_2
    //   158: aload #7
    //   160: astore_1
    //   161: goto -> 426
    //   164: astore #8
    //   166: aconst_null
    //   167: astore #6
    //   169: aload #6
    //   171: astore #7
    //   173: ldc 'AppCompatSpinner'
    //   175: ldc 'Could not read android:spinnerMode'
    //   177: aload #8
    //   179: invokestatic i : (Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)I
    //   182: pop
    //   183: iload #5
    //   185: istore #4
    //   187: aload #6
    //   189: ifnull -> 205
    //   192: aload #6
    //   194: astore #8
    //   196: iload #5
    //   198: istore #4
    //   200: aload #8
    //   202: invokevirtual recycle : ()V
    //   205: iload #4
    //   207: ifeq -> 323
    //   210: iload #4
    //   212: iconst_1
    //   213: if_icmpeq -> 219
    //   216: goto -> 350
    //   219: new androidx/appcompat/widget/w$d
    //   222: dup
    //   223: aload_0
    //   224: aload_0
    //   225: getfield i : Landroid/content/Context;
    //   228: aload_2
    //   229: iload_3
    //   230: invokespecial <init> : (Landroidx/appcompat/widget/w;Landroid/content/Context;Landroid/util/AttributeSet;I)V
    //   233: astore #6
    //   235: aload_0
    //   236: getfield i : Landroid/content/Context;
    //   239: aload_2
    //   240: getstatic com/bumptech/glide/manager/b.C : [I
    //   243: iload_3
    //   244: iconst_0
    //   245: invokestatic q : (Landroid/content/Context;Landroid/util/AttributeSet;[III)Landroidx/appcompat/widget/z0;
    //   248: astore #7
    //   250: aload_0
    //   251: aload #7
    //   253: iconst_3
    //   254: bipush #-2
    //   256: invokevirtual k : (II)I
    //   259: putfield n : I
    //   262: aload #7
    //   264: iconst_1
    //   265: invokevirtual g : (I)Landroid/graphics/drawable/Drawable;
    //   268: astore #8
    //   270: aload #6
    //   272: getfield F : Landroid/widget/PopupWindow;
    //   275: aload #8
    //   277: invokevirtual setBackgroundDrawable : (Landroid/graphics/drawable/Drawable;)V
    //   280: aload #6
    //   282: aload #9
    //   284: iconst_2
    //   285: invokevirtual getString : (I)Ljava/lang/String;
    //   288: putfield J : Ljava/lang/CharSequence;
    //   291: aload #7
    //   293: getfield b : Landroid/content/res/TypedArray;
    //   296: invokevirtual recycle : ()V
    //   299: aload_0
    //   300: aload #6
    //   302: putfield m : Landroidx/appcompat/widget/w$f;
    //   305: aload_0
    //   306: new androidx/appcompat/widget/v
    //   309: dup
    //   310: aload_0
    //   311: aload_0
    //   312: aload #6
    //   314: invokespecial <init> : (Landroidx/appcompat/widget/w;Landroid/view/View;Landroidx/appcompat/widget/w$d;)V
    //   317: putfield j : Landroidx/appcompat/widget/i0;
    //   320: goto -> 350
    //   323: new androidx/appcompat/widget/w$b
    //   326: dup
    //   327: aload_0
    //   328: invokespecial <init> : (Landroidx/appcompat/widget/w;)V
    //   331: astore #6
    //   333: aload_0
    //   334: aload #6
    //   336: putfield m : Landroidx/appcompat/widget/w$f;
    //   339: aload #6
    //   341: aload #9
    //   343: iconst_2
    //   344: invokevirtual getString : (I)Ljava/lang/String;
    //   347: invokevirtual h : (Ljava/lang/CharSequence;)V
    //   350: aload #9
    //   352: iconst_0
    //   353: invokevirtual getTextArray : (I)[Ljava/lang/CharSequence;
    //   356: astore #6
    //   358: aload #6
    //   360: ifnull -> 387
    //   363: new android/widget/ArrayAdapter
    //   366: dup
    //   367: aload_1
    //   368: ldc 17367048
    //   370: aload #6
    //   372: invokespecial <init> : (Landroid/content/Context;I[Ljava/lang/Object;)V
    //   375: astore_1
    //   376: aload_1
    //   377: ldc 2131558563
    //   379: invokevirtual setDropDownViewResource : (I)V
    //   382: aload_0
    //   383: aload_1
    //   384: invokevirtual setAdapter : (Landroid/widget/SpinnerAdapter;)V
    //   387: aload #9
    //   389: invokevirtual recycle : ()V
    //   392: aload_0
    //   393: iconst_1
    //   394: putfield l : Z
    //   397: aload_0
    //   398: getfield k : Landroid/widget/SpinnerAdapter;
    //   401: astore_1
    //   402: aload_1
    //   403: ifnull -> 416
    //   406: aload_0
    //   407: aload_1
    //   408: invokevirtual setAdapter : (Landroid/widget/SpinnerAdapter;)V
    //   411: aload_0
    //   412: aconst_null
    //   413: putfield k : Landroid/widget/SpinnerAdapter;
    //   416: aload_0
    //   417: getfield h : Landroidx/appcompat/widget/e;
    //   420: aload_2
    //   421: iload_3
    //   422: invokevirtual d : (Landroid/util/AttributeSet;I)V
    //   425: return
    //   426: aload_1
    //   427: ifnull -> 434
    //   430: aload_1
    //   431: invokevirtual recycle : ()V
    //   434: aload_2
    //   435: athrow
    // Exception table:
    //   from	to	target	type
    //   92	104	164	java/lang/Exception
    //   92	104	157	finally
    //   116	125	152	java/lang/Exception
    //   116	125	145	finally
    //   129	138	152	java/lang/Exception
    //   129	138	145	finally
    //   173	183	145	finally
  }
  
  public int a(SpinnerAdapter paramSpinnerAdapter, Drawable paramDrawable) {
    int k = 0;
    if (paramSpinnerAdapter == null)
      return 0; 
    int m = View.MeasureSpec.makeMeasureSpec(getMeasuredWidth(), 0);
    int n = View.MeasureSpec.makeMeasureSpec(getMeasuredHeight(), 0);
    int i = Math.max(0, getSelectedItemPosition());
    int i1 = Math.min(paramSpinnerAdapter.getCount(), i + 15);
    int j = Math.max(0, i - 15 - i1 - i);
    View view = null;
    i = 0;
    while (j < i1) {
      int i3 = paramSpinnerAdapter.getItemViewType(j);
      int i2 = k;
      if (i3 != k) {
        view = null;
        i2 = i3;
      } 
      view = paramSpinnerAdapter.getView(j, view, (ViewGroup)this);
      if (view.getLayoutParams() == null)
        view.setLayoutParams(new ViewGroup.LayoutParams(-2, -2)); 
      view.measure(m, n);
      i = Math.max(i, view.getMeasuredWidth());
      j++;
      k = i2;
    } 
    j = i;
    if (paramDrawable != null) {
      paramDrawable.getPadding(this.o);
      Rect rect = this.o;
      j = i + rect.left + rect.right;
    } 
    return j;
  }
  
  public void b() {
    this.m.m(getTextDirection(), getTextAlignment());
  }
  
  public void drawableStateChanged() {
    super.drawableStateChanged();
    e e1 = this.h;
    if (e1 != null)
      e1.a(); 
  }
  
  public int getDropDownHorizontalOffset() {
    f f1 = this.m;
    return (f1 != null) ? f1.c() : super.getDropDownHorizontalOffset();
  }
  
  public int getDropDownVerticalOffset() {
    f f1 = this.m;
    return (f1 != null) ? f1.n() : super.getDropDownVerticalOffset();
  }
  
  public int getDropDownWidth() {
    return (this.m != null) ? this.n : super.getDropDownWidth();
  }
  
  public final f getInternalPopup() {
    return this.m;
  }
  
  public Drawable getPopupBackground() {
    f f1 = this.m;
    return (f1 != null) ? f1.f() : super.getPopupBackground();
  }
  
  public Context getPopupContext() {
    return this.i;
  }
  
  public CharSequence getPrompt() {
    f f1 = this.m;
    return (f1 != null) ? f1.o() : super.getPrompt();
  }
  
  public ColorStateList getSupportBackgroundTintList() {
    e e1 = this.h;
    return (e1 != null) ? e1.b() : null;
  }
  
  public PorterDuff.Mode getSupportBackgroundTintMode() {
    e e1 = this.h;
    return (e1 != null) ? e1.c() : null;
  }
  
  public void onDetachedFromWindow() {
    super.onDetachedFromWindow();
    f f1 = this.m;
    if (f1 != null && f1.b())
      this.m.dismiss(); 
  }
  
  public void onMeasure(int paramInt1, int paramInt2) {
    super.onMeasure(paramInt1, paramInt2);
    if (this.m != null && View.MeasureSpec.getMode(paramInt1) == Integer.MIN_VALUE)
      setMeasuredDimension(Math.min(Math.max(getMeasuredWidth(), a(getAdapter(), getBackground())), View.MeasureSpec.getSize(paramInt1)), getMeasuredHeight()); 
  }
  
  public void onRestoreInstanceState(Parcelable paramParcelable) {
    e e1 = (e)paramParcelable;
    super.onRestoreInstanceState(e1.getSuperState());
    if (e1.h) {
      ViewTreeObserver viewTreeObserver = getViewTreeObserver();
      if (viewTreeObserver != null)
        viewTreeObserver.addOnGlobalLayoutListener(new a(this)); 
    } 
  }
  
  public Parcelable onSaveInstanceState() {
    boolean bool;
    e e1 = new e(super.onSaveInstanceState());
    f f1 = this.m;
    if (f1 != null && f1.b()) {
      bool = true;
    } else {
      bool = false;
    } 
    e1.h = bool;
    return (Parcelable)e1;
  }
  
  public boolean onTouchEvent(MotionEvent paramMotionEvent) {
    i0 i01 = this.j;
    return (i01 != null && i01.onTouch((View)this, paramMotionEvent)) ? true : super.onTouchEvent(paramMotionEvent);
  }
  
  public boolean performClick() {
    f f1 = this.m;
    if (f1 != null) {
      if (!f1.b())
        b(); 
      return true;
    } 
    return super.performClick();
  }
  
  public void setAdapter(SpinnerAdapter paramSpinnerAdapter) {
    if (!this.l) {
      this.k = paramSpinnerAdapter;
      return;
    } 
    super.setAdapter(paramSpinnerAdapter);
    if (this.m != null) {
      Context context2 = this.i;
      Context context1 = context2;
      if (context2 == null)
        context1 = getContext(); 
      this.m.p(new c(paramSpinnerAdapter, context1.getTheme()));
    } 
  }
  
  public void setBackgroundDrawable(Drawable paramDrawable) {
    super.setBackgroundDrawable(paramDrawable);
    e e1 = this.h;
    if (e1 != null)
      e1.e(); 
  }
  
  public void setBackgroundResource(int paramInt) {
    super.setBackgroundResource(paramInt);
    e e1 = this.h;
    if (e1 != null)
      e1.f(paramInt); 
  }
  
  public void setDropDownHorizontalOffset(int paramInt) {
    f f1 = this.m;
    if (f1 != null) {
      f1.k(paramInt);
      this.m.l(paramInt);
      return;
    } 
    super.setDropDownHorizontalOffset(paramInt);
  }
  
  public void setDropDownVerticalOffset(int paramInt) {
    f f1 = this.m;
    if (f1 != null) {
      f1.j(paramInt);
      return;
    } 
    super.setDropDownVerticalOffset(paramInt);
  }
  
  public void setDropDownWidth(int paramInt) {
    if (this.m != null) {
      this.n = paramInt;
      return;
    } 
    super.setDropDownWidth(paramInt);
  }
  
  public void setPopupBackgroundDrawable(Drawable paramDrawable) {
    f f1 = this.m;
    if (f1 != null) {
      f1.i(paramDrawable);
      return;
    } 
    super.setPopupBackgroundDrawable(paramDrawable);
  }
  
  public void setPopupBackgroundResource(int paramInt) {
    setPopupBackgroundDrawable(g.a.b(getPopupContext(), paramInt));
  }
  
  public void setPrompt(CharSequence paramCharSequence) {
    f f1 = this.m;
    if (f1 != null) {
      f1.h(paramCharSequence);
      return;
    } 
    super.setPrompt(paramCharSequence);
  }
  
  public void setSupportBackgroundTintList(ColorStateList paramColorStateList) {
    e e1 = this.h;
    if (e1 != null)
      e1.h(paramColorStateList); 
  }
  
  public void setSupportBackgroundTintMode(PorterDuff.Mode paramMode) {
    e e1 = this.h;
    if (e1 != null)
      e1.i(paramMode); 
  }
  
  public class a implements ViewTreeObserver.OnGlobalLayoutListener {
    public a(w this$0) {}
    
    public void onGlobalLayout() {
      if (!this.h.getInternalPopup().b())
        this.h.b(); 
      ViewTreeObserver viewTreeObserver = this.h.getViewTreeObserver();
      if (viewTreeObserver != null)
        viewTreeObserver.removeOnGlobalLayoutListener(this); 
    }
  }
  
  public class b implements f, DialogInterface.OnClickListener {
    public androidx.appcompat.app.b h;
    
    public ListAdapter i;
    
    public CharSequence j;
    
    public b(w this$0) {}
    
    public boolean b() {
      androidx.appcompat.app.b b1 = this.h;
      return (b1 != null) ? b1.isShowing() : false;
    }
    
    public int c() {
      return 0;
    }
    
    public void dismiss() {
      androidx.appcompat.app.b b1 = this.h;
      if (b1 != null) {
        b1.dismiss();
        this.h = null;
      } 
    }
    
    public Drawable f() {
      return null;
    }
    
    public void h(CharSequence param1CharSequence) {
      this.j = param1CharSequence;
    }
    
    public void i(Drawable param1Drawable) {
      Log.e("AppCompatSpinner", "Cannot set popup background for MODE_DIALOG, ignoring");
    }
    
    public void j(int param1Int) {
      Log.e("AppCompatSpinner", "Cannot set vertical offset for MODE_DIALOG, ignoring");
    }
    
    public void k(int param1Int) {
      Log.e("AppCompatSpinner", "Cannot set horizontal (original) offset for MODE_DIALOG, ignoring");
    }
    
    public void l(int param1Int) {
      Log.e("AppCompatSpinner", "Cannot set horizontal offset for MODE_DIALOG, ignoring");
    }
    
    public void m(int param1Int1, int param1Int2) {
      if (this.i == null)
        return; 
      androidx.appcompat.app.b.a a = new androidx.appcompat.app.b.a(this.k.getPopupContext());
      CharSequence charSequence = this.j;
      if (charSequence != null)
        a.a.d = charSequence; 
      ListAdapter listAdapter = this.i;
      int i = this.k.getSelectedItemPosition();
      AlertController.b b2 = a.a;
      b2.g = listAdapter;
      b2.h = this;
      b2.j = i;
      b2.i = true;
      androidx.appcompat.app.b b1 = a.a();
      this.h = b1;
      ListView listView = b1.j.g;
      listView.setTextDirection(param1Int1);
      listView.setTextAlignment(param1Int2);
      this.h.show();
    }
    
    public int n() {
      return 0;
    }
    
    public CharSequence o() {
      return this.j;
    }
    
    public void onClick(DialogInterface param1DialogInterface, int param1Int) {
      this.k.setSelection(param1Int);
      if (this.k.getOnItemClickListener() != null)
        this.k.performItemClick(null, param1Int, this.i.getItemId(param1Int)); 
      androidx.appcompat.app.b b1 = this.h;
      if (b1 != null) {
        b1.dismiss();
        this.h = null;
      } 
    }
    
    public void p(ListAdapter param1ListAdapter) {
      this.i = param1ListAdapter;
    }
  }
  
  public static class c implements ListAdapter, SpinnerAdapter {
    public SpinnerAdapter h;
    
    public ListAdapter i;
    
    public c(SpinnerAdapter param1SpinnerAdapter, Resources.Theme param1Theme) {
      this.h = param1SpinnerAdapter;
      if (param1SpinnerAdapter instanceof ListAdapter)
        this.i = (ListAdapter)param1SpinnerAdapter; 
      if (param1Theme != null) {
        ThemedSpinnerAdapter themedSpinnerAdapter;
        if (Build.VERSION.SDK_INT >= 23 && param1SpinnerAdapter instanceof ThemedSpinnerAdapter) {
          themedSpinnerAdapter = (ThemedSpinnerAdapter)param1SpinnerAdapter;
          if (themedSpinnerAdapter.getDropDownViewTheme() != param1Theme) {
            themedSpinnerAdapter.setDropDownViewTheme(param1Theme);
            return;
          } 
        } else if (themedSpinnerAdapter instanceof v0) {
          v0 v0 = (v0)themedSpinnerAdapter;
          if (v0.getDropDownViewTheme() == null)
            v0.setDropDownViewTheme(param1Theme); 
        } 
      } 
    }
    
    public boolean areAllItemsEnabled() {
      ListAdapter listAdapter = this.i;
      return (listAdapter != null) ? listAdapter.areAllItemsEnabled() : true;
    }
    
    public int getCount() {
      SpinnerAdapter spinnerAdapter = this.h;
      return (spinnerAdapter == null) ? 0 : spinnerAdapter.getCount();
    }
    
    public View getDropDownView(int param1Int, View param1View, ViewGroup param1ViewGroup) {
      SpinnerAdapter spinnerAdapter = this.h;
      return (spinnerAdapter == null) ? null : spinnerAdapter.getDropDownView(param1Int, param1View, param1ViewGroup);
    }
    
    public Object getItem(int param1Int) {
      SpinnerAdapter spinnerAdapter = this.h;
      return (spinnerAdapter == null) ? null : spinnerAdapter.getItem(param1Int);
    }
    
    public long getItemId(int param1Int) {
      SpinnerAdapter spinnerAdapter = this.h;
      return (spinnerAdapter == null) ? -1L : spinnerAdapter.getItemId(param1Int);
    }
    
    public int getItemViewType(int param1Int) {
      return 0;
    }
    
    public View getView(int param1Int, View param1View, ViewGroup param1ViewGroup) {
      SpinnerAdapter spinnerAdapter = this.h;
      return (spinnerAdapter == null) ? null : spinnerAdapter.getDropDownView(param1Int, param1View, param1ViewGroup);
    }
    
    public int getViewTypeCount() {
      return 1;
    }
    
    public boolean hasStableIds() {
      SpinnerAdapter spinnerAdapter = this.h;
      return (spinnerAdapter != null && spinnerAdapter.hasStableIds());
    }
    
    public boolean isEmpty() {
      return (getCount() == 0);
    }
    
    public boolean isEnabled(int param1Int) {
      ListAdapter listAdapter = this.i;
      return (listAdapter != null) ? listAdapter.isEnabled(param1Int) : true;
    }
    
    public void registerDataSetObserver(DataSetObserver param1DataSetObserver) {
      SpinnerAdapter spinnerAdapter = this.h;
      if (spinnerAdapter != null)
        spinnerAdapter.registerDataSetObserver(param1DataSetObserver); 
    }
    
    public void unregisterDataSetObserver(DataSetObserver param1DataSetObserver) {
      SpinnerAdapter spinnerAdapter = this.h;
      if (spinnerAdapter != null)
        spinnerAdapter.unregisterDataSetObserver(param1DataSetObserver); 
    }
  }
  
  public class d extends l0 implements f {
    public CharSequence J;
    
    public ListAdapter K;
    
    public final Rect L = new Rect();
    
    public int M;
    
    public d(w this$0, Context param1Context, AttributeSet param1AttributeSet, int param1Int) {
      super(param1Context, param1AttributeSet, param1Int, 0);
      this.v = (View)this$0;
      s(true);
      this.w = new a(this, this$0);
    }
    
    public void h(CharSequence param1CharSequence) {
      this.J = param1CharSequence;
    }
    
    public void k(int param1Int) {
      this.M = param1Int;
    }
    
    public void m(int param1Int1, int param1Int2) {
      boolean bool = b();
      t();
      this.F.setInputMethodMode(2);
      d();
      g0 g0 = this.j;
      g0.setChoiceMode(1);
      g0.setTextDirection(param1Int1);
      g0.setTextAlignment(param1Int2);
      param1Int1 = this.N.getSelectedItemPosition();
      g0 = this.j;
      if (b() && g0 != null) {
        g0.setListSelectionHidden(false);
        g0.setSelection(param1Int1);
        if (g0.getChoiceMode() != 0)
          g0.setItemChecked(param1Int1, true); 
      } 
      if (bool)
        return; 
      ViewTreeObserver viewTreeObserver = this.N.getViewTreeObserver();
      if (viewTreeObserver != null) {
        b b = new b(this);
        viewTreeObserver.addOnGlobalLayoutListener(b);
        c c = new c(this, b);
        this.F.setOnDismissListener(c);
      } 
    }
    
    public CharSequence o() {
      return this.J;
    }
    
    public void p(ListAdapter param1ListAdapter) {
      super.p(param1ListAdapter);
      this.K = param1ListAdapter;
    }
    
    public void t() {
      // Byte code:
      //   0: aload_0
      //   1: invokevirtual f : ()Landroid/graphics/drawable/Drawable;
      //   4: astore #8
      //   6: iconst_0
      //   7: istore_1
      //   8: aload #8
      //   10: ifnull -> 65
      //   13: aload #8
      //   15: aload_0
      //   16: getfield N : Landroidx/appcompat/widget/w;
      //   19: getfield o : Landroid/graphics/Rect;
      //   22: invokevirtual getPadding : (Landroid/graphics/Rect;)Z
      //   25: pop
      //   26: aload_0
      //   27: getfield N : Landroidx/appcompat/widget/w;
      //   30: invokestatic b : (Landroid/view/View;)Z
      //   33: ifeq -> 50
      //   36: aload_0
      //   37: getfield N : Landroidx/appcompat/widget/w;
      //   40: getfield o : Landroid/graphics/Rect;
      //   43: getfield right : I
      //   46: istore_1
      //   47: goto -> 62
      //   50: aload_0
      //   51: getfield N : Landroidx/appcompat/widget/w;
      //   54: getfield o : Landroid/graphics/Rect;
      //   57: getfield left : I
      //   60: ineg
      //   61: istore_1
      //   62: goto -> 86
      //   65: aload_0
      //   66: getfield N : Landroidx/appcompat/widget/w;
      //   69: getfield o : Landroid/graphics/Rect;
      //   72: astore #8
      //   74: aload #8
      //   76: iconst_0
      //   77: putfield right : I
      //   80: aload #8
      //   82: iconst_0
      //   83: putfield left : I
      //   86: aload_0
      //   87: getfield N : Landroidx/appcompat/widget/w;
      //   90: invokevirtual getPaddingLeft : ()I
      //   93: istore #5
      //   95: aload_0
      //   96: getfield N : Landroidx/appcompat/widget/w;
      //   99: invokevirtual getPaddingRight : ()I
      //   102: istore #6
      //   104: aload_0
      //   105: getfield N : Landroidx/appcompat/widget/w;
      //   108: invokevirtual getWidth : ()I
      //   111: istore #7
      //   113: aload_0
      //   114: getfield N : Landroidx/appcompat/widget/w;
      //   117: astore #8
      //   119: aload #8
      //   121: getfield n : I
      //   124: istore_2
      //   125: iload_2
      //   126: bipush #-2
      //   128: if_icmpne -> 216
      //   131: aload #8
      //   133: aload_0
      //   134: getfield K : Landroid/widget/ListAdapter;
      //   137: checkcast android/widget/SpinnerAdapter
      //   140: aload_0
      //   141: invokevirtual f : ()Landroid/graphics/drawable/Drawable;
      //   144: invokevirtual a : (Landroid/widget/SpinnerAdapter;Landroid/graphics/drawable/Drawable;)I
      //   147: istore_3
      //   148: aload_0
      //   149: getfield N : Landroidx/appcompat/widget/w;
      //   152: invokevirtual getContext : ()Landroid/content/Context;
      //   155: invokevirtual getResources : ()Landroid/content/res/Resources;
      //   158: invokevirtual getDisplayMetrics : ()Landroid/util/DisplayMetrics;
      //   161: getfield widthPixels : I
      //   164: istore_2
      //   165: aload_0
      //   166: getfield N : Landroidx/appcompat/widget/w;
      //   169: getfield o : Landroid/graphics/Rect;
      //   172: astore #8
      //   174: iload_2
      //   175: aload #8
      //   177: getfield left : I
      //   180: isub
      //   181: aload #8
      //   183: getfield right : I
      //   186: isub
      //   187: istore #4
      //   189: iload_3
      //   190: istore_2
      //   191: iload_3
      //   192: iload #4
      //   194: if_icmple -> 200
      //   197: iload #4
      //   199: istore_2
      //   200: iload_2
      //   201: iload #7
      //   203: iload #5
      //   205: isub
      //   206: iload #6
      //   208: isub
      //   209: invokestatic max : (II)I
      //   212: istore_2
      //   213: goto -> 230
      //   216: iload_2
      //   217: iconst_m1
      //   218: if_icmpne -> 238
      //   221: iload #7
      //   223: iload #5
      //   225: isub
      //   226: iload #6
      //   228: isub
      //   229: istore_2
      //   230: aload_0
      //   231: iload_2
      //   232: invokevirtual r : (I)V
      //   235: goto -> 243
      //   238: aload_0
      //   239: iload_2
      //   240: invokevirtual r : (I)V
      //   243: aload_0
      //   244: getfield N : Landroidx/appcompat/widget/w;
      //   247: invokestatic b : (Landroid/view/View;)Z
      //   250: ifeq -> 274
      //   253: iload #7
      //   255: iload #6
      //   257: isub
      //   258: aload_0
      //   259: getfield l : I
      //   262: isub
      //   263: aload_0
      //   264: getfield M : I
      //   267: isub
      //   268: iload_1
      //   269: iadd
      //   270: istore_1
      //   271: goto -> 284
      //   274: iload #5
      //   276: aload_0
      //   277: getfield M : I
      //   280: iadd
      //   281: iload_1
      //   282: iadd
      //   283: istore_1
      //   284: aload_0
      //   285: iload_1
      //   286: putfield m : I
      //   289: return
    }
    
    public class a implements AdapterView.OnItemClickListener {
      public a(w.d this$0, w param2w) {}
      
      public void onItemClick(AdapterView<?> param2AdapterView, View param2View, int param2Int, long param2Long) {
        this.h.N.setSelection(param2Int);
        if (this.h.N.getOnItemClickListener() != null) {
          w.d d1 = this.h;
          d1.N.performItemClick(param2View, param2Int, d1.K.getItemId(param2Int));
        } 
        this.h.dismiss();
      }
    }
    
    public class b implements ViewTreeObserver.OnGlobalLayoutListener {
      public b(w.d this$0) {}
      
      public void onGlobalLayout() {
        boolean bool;
        w.d d1 = this.h;
        w w = d1.N;
        Objects.requireNonNull(d1);
        WeakHashMap weakHashMap = l.a;
        if (w.isAttachedToWindow() && w.getGlobalVisibleRect(d1.L)) {
          bool = true;
        } else {
          bool = false;
        } 
        if (!bool) {
          this.h.dismiss();
          return;
        } 
        this.h.t();
        this.h.d();
      }
    }
    
    public class c implements PopupWindow.OnDismissListener {
      public c(w.d this$0, ViewTreeObserver.OnGlobalLayoutListener param2OnGlobalLayoutListener) {}
      
      public void onDismiss() {
        ViewTreeObserver viewTreeObserver = this.i.N.getViewTreeObserver();
        if (viewTreeObserver != null)
          viewTreeObserver.removeGlobalOnLayoutListener(this.h); 
      }
    }
  }
  
  public class a implements AdapterView.OnItemClickListener {
    public a(w this$0, w param1w) {}
    
    public void onItemClick(AdapterView<?> param1AdapterView, View param1View, int param1Int, long param1Long) {
      this.h.N.setSelection(param1Int);
      if (this.h.N.getOnItemClickListener() != null) {
        w.d d1 = this.h;
        d1.N.performItemClick(param1View, param1Int, d1.K.getItemId(param1Int));
      } 
      this.h.dismiss();
    }
  }
  
  public class b implements ViewTreeObserver.OnGlobalLayoutListener {
    public b(w this$0) {}
    
    public void onGlobalLayout() {
      boolean bool;
      w.d d1 = this.h;
      w w = d1.N;
      Objects.requireNonNull(d1);
      WeakHashMap weakHashMap = l.a;
      if (w.isAttachedToWindow() && w.getGlobalVisibleRect(d1.L)) {
        bool = true;
      } else {
        bool = false;
      } 
      if (!bool) {
        this.h.dismiss();
        return;
      } 
      this.h.t();
      this.h.d();
    }
  }
  
  public class c implements PopupWindow.OnDismissListener {
    public c(w this$0, ViewTreeObserver.OnGlobalLayoutListener param1OnGlobalLayoutListener) {}
    
    public void onDismiss() {
      ViewTreeObserver viewTreeObserver = this.i.N.getViewTreeObserver();
      if (viewTreeObserver != null)
        viewTreeObserver.removeGlobalOnLayoutListener(this.h); 
    }
  }
  
  public static class e extends View.BaseSavedState {
    public static final Parcelable.Creator<e> CREATOR = new a();
    
    public boolean h;
    
    public e(Parcel param1Parcel) {
      super(param1Parcel);
      boolean bool;
      if (param1Parcel.readByte() != 0) {
        bool = true;
      } else {
        bool = false;
      } 
      this.h = bool;
    }
    
    public e(Parcelable param1Parcelable) {
      super(param1Parcelable);
    }
    
    public void writeToParcel(Parcel param1Parcel, int param1Int) {
      super.writeToParcel(param1Parcel, param1Int);
      param1Parcel.writeByte((byte)this.h);
    }
    
    public class a implements Parcelable.Creator<e> {
      public Object createFromParcel(Parcel param2Parcel) {
        return new w.e(param2Parcel);
      }
      
      public Object[] newArray(int param2Int) {
        return (Object[])new w.e[param2Int];
      }
    }
  }
  
  public class a implements Parcelable.Creator<e> {
    public Object createFromParcel(Parcel param1Parcel) {
      return new w.e(param1Parcel);
    }
    
    public Object[] newArray(int param1Int) {
      return (Object[])new w.e[param1Int];
    }
  }
  
  public static interface f {
    boolean b();
    
    int c();
    
    void dismiss();
    
    Drawable f();
    
    void h(CharSequence param1CharSequence);
    
    void i(Drawable param1Drawable);
    
    void j(int param1Int);
    
    void k(int param1Int);
    
    void l(int param1Int);
    
    void m(int param1Int1, int param1Int2);
    
    int n();
    
    CharSequence o();
    
    void p(ListAdapter param1ListAdapter);
  }
}


/* Location:              C:\soft\dex2jar-2.0\Luxury Logo Maker_ Logo Design-dex2jar.jar!\androidx\appcompat\widget\w.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */