package androidx.appcompat.widget;

import android.content.Context;
import android.graphics.drawable.Drawable;
import android.view.Menu;
import android.view.ViewGroup;
import android.view.Window;
import androidx.appcompat.view.menu.i;
import k0.n;

public interface e0 {
  void a(Menu paramMenu, i.a parama);
  
  boolean b();
  
  void c();
  
  void collapseActionView();
  
  boolean d();
  
  boolean e();
  
  boolean f();
  
  boolean g();
  
  Context getContext();
  
  CharSequence getTitle();
  
  void h();
  
  void i(int paramInt);
  
  void j(r0 paramr0);
  
  ViewGroup k();
  
  void l(boolean paramBoolean);
  
  boolean m();
  
  void n(int paramInt);
  
  int o();
  
  void p(int paramInt);
  
  int q();
  
  n r(int paramInt, long paramLong);
  
  void s();
  
  void setIcon(int paramInt);
  
  void setIcon(Drawable paramDrawable);
  
  void setWindowCallback(Window.Callback paramCallback);
  
  void setWindowTitle(CharSequence paramCharSequence);
  
  void t();
  
  void u(boolean paramBoolean);
}


/* Location:              C:\soft\dex2jar-2.0\Luxury Logo Maker_ Logo Design-dex2jar.jar!\androidx\appcompat\widget\e0.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */