package androidx.appcompat.widget;

import android.content.Context;
import android.content.res.TypedArray;
import android.graphics.Canvas;
import android.graphics.drawable.Drawable;
import android.support.v4.media.c;
import android.util.AttributeSet;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.view.accessibility.AccessibilityEvent;
import android.view.accessibility.AccessibilityNodeInfo;
import com.bumptech.glide.manager.b;
import java.util.WeakHashMap;
import k0.l;

public class j0 extends ViewGroup {
  public boolean h;
  
  public int i;
  
  public int j;
  
  public int k;
  
  public int l;
  
  public int m;
  
  public float n;
  
  public boolean o;
  
  public int[] p;
  
  public int[] q;
  
  public Drawable r;
  
  public int s;
  
  public int t;
  
  public int u;
  
  public int v;
  
  public j0(Context paramContext) {
    this(paramContext, null);
  }
  
  public j0(Context paramContext, AttributeSet paramAttributeSet) {
    this(paramContext, paramAttributeSet, 0);
  }
  
  public j0(Context paramContext, AttributeSet paramAttributeSet, int paramInt) {
    // Byte code:
    //   0: aload_0
    //   1: aload_1
    //   2: aload_2
    //   3: iload_3
    //   4: invokespecial <init> : (Landroid/content/Context;Landroid/util/AttributeSet;I)V
    //   7: aload_0
    //   8: iconst_1
    //   9: putfield h : Z
    //   12: aload_0
    //   13: iconst_m1
    //   14: putfield i : I
    //   17: aload_0
    //   18: iconst_0
    //   19: putfield j : I
    //   22: aload_0
    //   23: ldc 8388659
    //   25: putfield l : I
    //   28: getstatic com/bumptech/glide/manager/b.t : [I
    //   31: astore #6
    //   33: aload_1
    //   34: aload_2
    //   35: aload #6
    //   37: iload_3
    //   38: iconst_0
    //   39: invokevirtual obtainStyledAttributes : (Landroid/util/AttributeSet;[III)Landroid/content/res/TypedArray;
    //   42: astore #5
    //   44: aload_0
    //   45: aload_1
    //   46: aload #6
    //   48: aload_2
    //   49: aload #5
    //   51: iload_3
    //   52: iconst_0
    //   53: invokestatic r : (Landroid/view/View;Landroid/content/Context;[ILandroid/util/AttributeSet;Landroid/content/res/TypedArray;II)V
    //   56: aload #5
    //   58: iconst_1
    //   59: iconst_m1
    //   60: invokevirtual getInt : (II)I
    //   63: istore_3
    //   64: iload_3
    //   65: iflt -> 73
    //   68: aload_0
    //   69: iload_3
    //   70: invokevirtual setOrientation : (I)V
    //   73: aload #5
    //   75: iconst_0
    //   76: iconst_m1
    //   77: invokevirtual getInt : (II)I
    //   80: istore_3
    //   81: iload_3
    //   82: iflt -> 90
    //   85: aload_0
    //   86: iload_3
    //   87: invokevirtual setGravity : (I)V
    //   90: aload #5
    //   92: iconst_2
    //   93: iconst_1
    //   94: invokevirtual getBoolean : (IZ)Z
    //   97: istore #4
    //   99: iload #4
    //   101: ifne -> 110
    //   104: aload_0
    //   105: iload #4
    //   107: invokevirtual setBaselineAligned : (Z)V
    //   110: aload_0
    //   111: aload #5
    //   113: iconst_4
    //   114: ldc -1.0
    //   116: invokevirtual getFloat : (IF)F
    //   119: putfield n : F
    //   122: aload_0
    //   123: aload #5
    //   125: iconst_3
    //   126: iconst_m1
    //   127: invokevirtual getInt : (II)I
    //   130: putfield i : I
    //   133: aload_0
    //   134: aload #5
    //   136: bipush #7
    //   138: iconst_0
    //   139: invokevirtual getBoolean : (IZ)Z
    //   142: putfield o : Z
    //   145: aload #5
    //   147: iconst_5
    //   148: invokevirtual hasValue : (I)Z
    //   151: ifeq -> 175
    //   154: aload #5
    //   156: iconst_5
    //   157: iconst_0
    //   158: invokevirtual getResourceId : (II)I
    //   161: istore_3
    //   162: iload_3
    //   163: ifeq -> 175
    //   166: aload_1
    //   167: iload_3
    //   168: invokestatic b : (Landroid/content/Context;I)Landroid/graphics/drawable/Drawable;
    //   171: astore_1
    //   172: goto -> 182
    //   175: aload #5
    //   177: iconst_5
    //   178: invokevirtual getDrawable : (I)Landroid/graphics/drawable/Drawable;
    //   181: astore_1
    //   182: aload_0
    //   183: aload_1
    //   184: invokevirtual setDividerDrawable : (Landroid/graphics/drawable/Drawable;)V
    //   187: aload_0
    //   188: aload #5
    //   190: bipush #8
    //   192: iconst_0
    //   193: invokevirtual getInt : (II)I
    //   196: putfield u : I
    //   199: aload_0
    //   200: aload #5
    //   202: bipush #6
    //   204: iconst_0
    //   205: invokevirtual getDimensionPixelSize : (II)I
    //   208: putfield v : I
    //   211: aload #5
    //   213: invokevirtual recycle : ()V
    //   216: return
  }
  
  public boolean checkLayoutParams(ViewGroup.LayoutParams paramLayoutParams) {
    return paramLayoutParams instanceof a;
  }
  
  public void e(Canvas paramCanvas, int paramInt) {
    this.r.setBounds(getPaddingLeft() + this.v, paramInt, getWidth() - getPaddingRight() - this.v, this.t + paramInt);
    this.r.draw(paramCanvas);
  }
  
  public void g(Canvas paramCanvas, int paramInt) {
    this.r.setBounds(paramInt, getPaddingTop() + this.v, this.s + paramInt, getHeight() - getPaddingBottom() - this.v);
    this.r.draw(paramCanvas);
  }
  
  public int getBaseline() {
    if (this.i < 0)
      return super.getBaseline(); 
    int i = getChildCount();
    int j = this.i;
    if (i > j) {
      View view = getChildAt(j);
      int k = view.getBaseline();
      if (k == -1) {
        if (this.i == 0)
          return -1; 
        throw new RuntimeException("mBaselineAlignedChildIndex of LinearLayout points to a View that doesn't know how to get its baseline.");
      } 
      j = this.j;
      i = j;
      if (this.k == 1) {
        int m = this.l & 0x70;
        i = j;
        if (m != 48)
          if (m != 16) {
            if (m != 80) {
              i = j;
            } else {
              i = getBottom() - getTop() - getPaddingBottom() - this.m;
            } 
          } else {
            i = j + (getBottom() - getTop() - getPaddingTop() - getPaddingBottom() - this.m) / 2;
          }  
      } 
      return i + ((a)view.getLayoutParams()).topMargin + k;
    } 
    throw new RuntimeException("mBaselineAlignedChildIndex of LinearLayout set to an index that is out of bounds.");
  }
  
  public int getBaselineAlignedChildIndex() {
    return this.i;
  }
  
  public Drawable getDividerDrawable() {
    return this.r;
  }
  
  public int getDividerPadding() {
    return this.v;
  }
  
  public int getDividerWidth() {
    return this.s;
  }
  
  public int getGravity() {
    return this.l;
  }
  
  public int getOrientation() {
    return this.k;
  }
  
  public int getShowDividers() {
    return this.u;
  }
  
  public int getVirtualChildCount() {
    return getChildCount();
  }
  
  public float getWeightSum() {
    return this.n;
  }
  
  public a h() {
    int i = this.k;
    return (i == 0) ? new a(-2, -2) : ((i == 1) ? new a(-1, -2) : null);
  }
  
  public a i(AttributeSet paramAttributeSet) {
    return new a(getContext(), paramAttributeSet);
  }
  
  public a j(ViewGroup.LayoutParams paramLayoutParams) {
    return new a(paramLayoutParams);
  }
  
  public boolean k(int paramInt) {
    boolean bool2 = false;
    boolean bool1 = false;
    if (paramInt == 0) {
      if ((this.u & 0x1) != 0)
        bool1 = true; 
      return bool1;
    } 
    if (paramInt == getChildCount()) {
      bool1 = bool2;
      if ((this.u & 0x4) != 0)
        bool1 = true; 
      return bool1;
    } 
    if ((this.u & 0x2) != 0)
      while (--paramInt >= 0) {
        if (getChildAt(paramInt).getVisibility() != 8)
          return true; 
        paramInt--;
      }  
    return false;
  }
  
  public void onDraw(Canvas paramCanvas) {
    if (this.r == null)
      return; 
    int k = this.k;
    int j = 0;
    int i = 0;
    if (k == 1) {
      j = getVirtualChildCount();
      while (i < j) {
        View view = getChildAt(i);
        if (view != null && view.getVisibility() != 8 && k(i)) {
          a a = (a)view.getLayoutParams();
          e(paramCanvas, view.getTop() - a.topMargin - this.t);
        } 
        i++;
      } 
      if (k(j)) {
        View view = getChildAt(j - 1);
        if (view == null) {
          i = getHeight() - getPaddingBottom() - this.t;
        } else {
          a a = (a)view.getLayoutParams();
          i = view.getBottom() + a.bottomMargin;
        } 
        e(paramCanvas, i);
        return;
      } 
    } else {
      k = getVirtualChildCount();
      boolean bool = g1.b((View)this);
      for (i = j; i < k; i++) {
        View view = getChildAt(i);
        if (view != null && view.getVisibility() != 8 && k(i)) {
          a a = (a)view.getLayoutParams();
          if (bool) {
            j = view.getRight() + a.rightMargin;
          } else {
            j = view.getLeft() - a.leftMargin - this.s;
          } 
          g(paramCanvas, j);
        } 
      } 
      if (k(k)) {
        View view = getChildAt(k - 1);
        if (view == null) {
          if (bool) {
            i = getPaddingLeft();
          } else {
            i = getWidth();
            j = getPaddingRight();
            i = i - j - this.s;
          } 
        } else {
          a a = (a)view.getLayoutParams();
          if (bool) {
            i = view.getLeft();
            j = a.leftMargin;
          } else {
            i = view.getRight() + a.rightMargin;
            g(paramCanvas, i);
          } 
          i = i - j - this.s;
        } 
      } else {
        return;
      } 
      g(paramCanvas, i);
    } 
  }
  
  public void onInitializeAccessibilityEvent(AccessibilityEvent paramAccessibilityEvent) {
    super.onInitializeAccessibilityEvent(paramAccessibilityEvent);
    paramAccessibilityEvent.setClassName("androidx.appcompat.widget.LinearLayoutCompat");
  }
  
  public void onInitializeAccessibilityNodeInfo(AccessibilityNodeInfo paramAccessibilityNodeInfo) {
    super.onInitializeAccessibilityNodeInfo(paramAccessibilityNodeInfo);
    paramAccessibilityNodeInfo.setClassName("androidx.appcompat.widget.LinearLayoutCompat");
  }
  
  public void onLayout(boolean paramBoolean, int paramInt1, int paramInt2, int paramInt3, int paramInt4) {
    if (this.k == 1) {
      int i = getPaddingLeft();
      int j = paramInt3 - paramInt1;
      int k = getPaddingRight();
      int m = getPaddingRight();
      int n = getVirtualChildCount();
      int i1 = this.l;
      paramInt1 = i1 & 0x70;
      if (paramInt1 != 16) {
        if (paramInt1 != 80) {
          paramInt1 = getPaddingTop();
        } else {
          paramInt1 = getPaddingTop() + paramInt4 - paramInt2 - this.m;
        } 
      } else {
        paramInt1 = getPaddingTop() + (paramInt4 - paramInt2 - this.m) / 2;
      } 
      paramInt2 = 0;
      while (paramInt2 < n) {
        View view = getChildAt(paramInt2);
        if (view == null) {
          paramInt3 = paramInt1 + 0;
          paramInt4 = paramInt2;
        } else {
          paramInt3 = paramInt1;
          paramInt4 = paramInt2;
          if (view.getVisibility() != 8) {
            int i3 = view.getMeasuredWidth();
            int i2 = view.getMeasuredHeight();
            a a = (a)view.getLayoutParams();
            paramInt4 = a.b;
            paramInt3 = paramInt4;
            if (paramInt4 < 0)
              paramInt3 = 0x800007 & i1; 
            WeakHashMap weakHashMap = l.a;
            paramInt3 = Gravity.getAbsoluteGravity(paramInt3, getLayoutDirection()) & 0x7;
            if (paramInt3 != 1) {
              if (paramInt3 != 5) {
                paramInt3 = a.leftMargin + i;
              } else {
                paramInt3 = j - k - i3;
                paramInt3 -= a.rightMargin;
              } 
            } else {
              paramInt3 = (j - i - m - i3) / 2 + i + a.leftMargin;
              paramInt3 -= a.rightMargin;
            } 
            paramInt4 = paramInt1;
            if (k(paramInt2))
              paramInt4 = paramInt1 + this.t; 
            paramInt1 = paramInt4 + a.topMargin;
            paramInt4 = paramInt1 + 0;
            view.layout(paramInt3, paramInt4, i3 + paramInt3, i2 + paramInt4);
            paramInt3 = a.bottomMargin;
            paramInt4 = paramInt2 + 0;
            paramInt3 = i2 + paramInt3 + 0 + paramInt1;
          } 
        } 
        paramInt2 = paramInt4 + 1;
        paramInt1 = paramInt3;
      } 
    } else {
      byte b;
      boolean bool = g1.b((View)this);
      int k = getPaddingTop();
      int m = paramInt4 - paramInt2;
      int n = getPaddingBottom();
      int i1 = getPaddingBottom();
      int i = getVirtualChildCount();
      paramInt2 = this.l;
      int j = paramInt2 & 0x70;
      paramBoolean = this.h;
      int[] arrayOfInt1 = this.p;
      int[] arrayOfInt2 = this.q;
      WeakHashMap weakHashMap = l.a;
      paramInt2 = Gravity.getAbsoluteGravity(0x800007 & paramInt2, getLayoutDirection());
      if (paramInt2 != 1) {
        if (paramInt2 != 5) {
          paramInt2 = getPaddingLeft();
        } else {
          paramInt2 = getPaddingLeft() + paramInt3 - paramInt1 - this.m;
        } 
      } else {
        paramInt2 = getPaddingLeft() + (paramInt3 - paramInt1 - this.m) / 2;
      } 
      if (bool) {
        paramInt1 = i - 1;
        b = -1;
      } else {
        paramInt1 = 0;
        b = 1;
      } 
      paramInt4 = 0;
      paramInt3 = j;
      j = paramInt1;
      while (paramInt4 < i) {
        int i2 = b * paramInt4 + j;
        View view = getChildAt(i2);
        if (view == null) {
          paramInt1 = paramInt2 + 0;
        } else {
          paramInt1 = paramInt2;
          if (view.getVisibility() != 8) {
            int i5 = view.getMeasuredWidth();
            int i6 = view.getMeasuredHeight();
            a a = (a)view.getLayoutParams();
            if (paramBoolean && a.height != -1) {
              i3 = view.getBaseline();
            } else {
              i3 = -1;
            } 
            int i4 = a.b;
            paramInt1 = i4;
            if (i4 < 0)
              paramInt1 = paramInt3; 
            paramInt1 &= 0x70;
            if (paramInt1 != 16) {
              if (paramInt1 != 48) {
                if (paramInt1 != 80) {
                  paramInt1 = k;
                } else {
                  i4 = m - n - i6 - a.bottomMargin;
                  paramInt1 = i4;
                  if (i3 != -1) {
                    paramInt1 = view.getMeasuredHeight();
                    paramInt1 = i4 - arrayOfInt2[2] - paramInt1 - i3;
                  } 
                } 
              } else {
                paramInt1 = a.topMargin + k;
                if (i3 != -1)
                  paramInt1 = arrayOfInt1[1] - i3 + paramInt1; 
              } 
            } else {
              paramInt1 = (m - k - i1 - i6) / 2 + k + a.topMargin - a.bottomMargin;
            } 
            int i3 = paramInt2;
            if (k(i2))
              i3 = paramInt2 + this.s; 
            paramInt2 = i3 + a.leftMargin;
            i3 = paramInt2 + 0;
            view.layout(i3, paramInt1, i5 + i3, i6 + paramInt1);
            paramInt1 = a.rightMargin;
            paramInt4 += 0;
            paramInt2 = i5 + paramInt1 + 0 + paramInt2;
            continue;
          } 
        } 
        paramInt2 = paramInt1;
        continue;
        paramInt4++;
      } 
    } 
  }
  
  public void onMeasure(int paramInt1, int paramInt2) {
    // Byte code:
    //   0: aload_0
    //   1: getfield k : I
    //   4: iconst_1
    //   5: if_icmpne -> 1607
    //   8: aload_0
    //   9: iconst_0
    //   10: putfield m : I
    //   13: aload_0
    //   14: invokevirtual getVirtualChildCount : ()I
    //   17: istore #17
    //   19: iload_1
    //   20: invokestatic getMode : (I)I
    //   23: istore #20
    //   25: iload_2
    //   26: invokestatic getMode : (I)I
    //   29: istore #5
    //   31: aload_0
    //   32: getfield i : I
    //   35: istore #21
    //   37: aload_0
    //   38: getfield o : Z
    //   41: istore #24
    //   43: fconst_0
    //   44: fstore_3
    //   45: iconst_0
    //   46: istore #13
    //   48: iconst_1
    //   49: istore #6
    //   51: iconst_0
    //   52: istore #9
    //   54: iconst_0
    //   55: istore #16
    //   57: iconst_0
    //   58: istore #12
    //   60: iconst_0
    //   61: istore #8
    //   63: iconst_0
    //   64: istore #11
    //   66: iconst_0
    //   67: istore #7
    //   69: iconst_0
    //   70: istore #10
    //   72: iload #11
    //   74: iload #17
    //   76: if_icmpge -> 649
    //   79: aload_0
    //   80: iload #11
    //   82: invokevirtual getChildAt : (I)Landroid/view/View;
    //   85: astore #28
    //   87: aload #28
    //   89: ifnonnull -> 105
    //   92: aload_0
    //   93: aload_0
    //   94: getfield m : I
    //   97: iconst_0
    //   98: iadd
    //   99: putfield m : I
    //   102: goto -> 121
    //   105: aload #28
    //   107: invokevirtual getVisibility : ()I
    //   110: bipush #8
    //   112: if_icmpne -> 128
    //   115: iload #11
    //   117: iconst_0
    //   118: iadd
    //   119: istore #11
    //   121: iload #11
    //   123: istore #15
    //   125: goto -> 640
    //   128: aload_0
    //   129: iload #11
    //   131: invokevirtual k : (I)Z
    //   134: ifeq -> 150
    //   137: aload_0
    //   138: aload_0
    //   139: getfield m : I
    //   142: aload_0
    //   143: getfield t : I
    //   146: iadd
    //   147: putfield m : I
    //   150: aload #28
    //   152: invokevirtual getLayoutParams : ()Landroid/view/ViewGroup$LayoutParams;
    //   155: checkcast androidx/appcompat/widget/j0$a
    //   158: astore #26
    //   160: aload #26
    //   162: getfield a : F
    //   165: fstore #4
    //   167: fload_3
    //   168: fload #4
    //   170: fadd
    //   171: fstore_3
    //   172: iload #5
    //   174: ldc_w 1073741824
    //   177: if_icmpne -> 234
    //   180: aload #26
    //   182: getfield height : I
    //   185: ifne -> 234
    //   188: fload #4
    //   190: fconst_0
    //   191: fcmpl
    //   192: ifle -> 234
    //   195: aload_0
    //   196: getfield m : I
    //   199: istore #13
    //   201: aload_0
    //   202: iload #13
    //   204: aload #26
    //   206: getfield topMargin : I
    //   209: iload #13
    //   211: iadd
    //   212: aload #26
    //   214: getfield bottomMargin : I
    //   217: iadd
    //   218: invokestatic max : (II)I
    //   221: putfield m : I
    //   224: iconst_1
    //   225: istore #15
    //   227: iload #12
    //   229: istore #14
    //   231: goto -> 382
    //   234: aload #26
    //   236: getfield height : I
    //   239: ifne -> 262
    //   242: fload #4
    //   244: fconst_0
    //   245: fcmpl
    //   246: ifle -> 262
    //   249: aload #26
    //   251: bipush #-2
    //   253: putfield height : I
    //   256: iconst_0
    //   257: istore #14
    //   259: goto -> 267
    //   262: ldc_w -2147483648
    //   265: istore #14
    //   267: fload_3
    //   268: fconst_0
    //   269: fcmpl
    //   270: ifne -> 282
    //   273: aload_0
    //   274: getfield m : I
    //   277: istore #15
    //   279: goto -> 285
    //   282: iconst_0
    //   283: istore #15
    //   285: aload #26
    //   287: astore #27
    //   289: aload_0
    //   290: aload #28
    //   292: iload_1
    //   293: iconst_0
    //   294: iload_2
    //   295: iload #15
    //   297: invokevirtual measureChildWithMargins : (Landroid/view/View;IIII)V
    //   300: iload #14
    //   302: ldc_w -2147483648
    //   305: if_icmpeq -> 315
    //   308: aload #27
    //   310: iload #14
    //   312: putfield height : I
    //   315: aload #28
    //   317: invokevirtual getMeasuredHeight : ()I
    //   320: istore #18
    //   322: aload_0
    //   323: getfield m : I
    //   326: istore #14
    //   328: aload_0
    //   329: iload #14
    //   331: iload #14
    //   333: iload #18
    //   335: iadd
    //   336: aload #27
    //   338: getfield topMargin : I
    //   341: iadd
    //   342: aload #27
    //   344: getfield bottomMargin : I
    //   347: iadd
    //   348: iconst_0
    //   349: iadd
    //   350: invokestatic max : (II)I
    //   353: putfield m : I
    //   356: iload #12
    //   358: istore #14
    //   360: iload #13
    //   362: istore #15
    //   364: iload #24
    //   366: ifeq -> 382
    //   369: iload #18
    //   371: iload #12
    //   373: invokestatic max : (II)I
    //   376: istore #14
    //   378: iload #13
    //   380: istore #15
    //   382: iload #21
    //   384: iflt -> 404
    //   387: iload #21
    //   389: iload #11
    //   391: iconst_1
    //   392: iadd
    //   393: if_icmpne -> 404
    //   396: aload_0
    //   397: aload_0
    //   398: getfield m : I
    //   401: putfield j : I
    //   404: iload #11
    //   406: iload #21
    //   408: if_icmpge -> 435
    //   411: aload #26
    //   413: getfield a : F
    //   416: fconst_0
    //   417: fcmpl
    //   418: ifgt -> 424
    //   421: goto -> 435
    //   424: new java/lang/RuntimeException
    //   427: dup
    //   428: ldc_w 'A child of LinearLayout with index less than mBaselineAlignedChildIndex has weight > 0, which won't work.  Either remove the weight, or don't set mBaselineAlignedChildIndex.'
    //   431: invokespecial <init> : (Ljava/lang/String;)V
    //   434: athrow
    //   435: iload #20
    //   437: ldc_w 1073741824
    //   440: if_icmpeq -> 461
    //   443: aload #26
    //   445: getfield width : I
    //   448: iconst_m1
    //   449: if_icmpne -> 461
    //   452: iconst_1
    //   453: istore #12
    //   455: iconst_1
    //   456: istore #9
    //   458: goto -> 464
    //   461: iconst_0
    //   462: istore #12
    //   464: aload #26
    //   466: getfield leftMargin : I
    //   469: aload #26
    //   471: getfield rightMargin : I
    //   474: iadd
    //   475: istore #13
    //   477: aload #28
    //   479: invokevirtual getMeasuredWidth : ()I
    //   482: iload #13
    //   484: iadd
    //   485: istore #18
    //   487: iload #16
    //   489: iload #18
    //   491: invokestatic max : (II)I
    //   494: istore #19
    //   496: iload #8
    //   498: aload #28
    //   500: invokevirtual getMeasuredState : ()I
    //   503: invokestatic combineMeasuredStates : (II)I
    //   506: istore #16
    //   508: iload #6
    //   510: ifeq -> 528
    //   513: aload #26
    //   515: getfield width : I
    //   518: iconst_m1
    //   519: if_icmpne -> 528
    //   522: iconst_1
    //   523: istore #6
    //   525: goto -> 531
    //   528: iconst_0
    //   529: istore #6
    //   531: aload #26
    //   533: getfield a : F
    //   536: fconst_0
    //   537: fcmpl
    //   538: ifle -> 573
    //   541: iload #12
    //   543: ifeq -> 549
    //   546: goto -> 553
    //   549: iload #18
    //   551: istore #13
    //   553: iload #10
    //   555: iload #13
    //   557: invokestatic max : (II)I
    //   560: istore #10
    //   562: iload #7
    //   564: istore #8
    //   566: iload #10
    //   568: istore #7
    //   570: goto -> 598
    //   573: iload #12
    //   575: ifeq -> 581
    //   578: goto -> 585
    //   581: iload #18
    //   583: istore #13
    //   585: iload #7
    //   587: iload #13
    //   589: invokestatic max : (II)I
    //   592: istore #8
    //   594: iload #10
    //   596: istore #7
    //   598: iload #11
    //   600: iconst_0
    //   601: iadd
    //   602: istore #18
    //   604: iload #19
    //   606: istore #11
    //   608: iload #16
    //   610: istore #12
    //   612: iload #15
    //   614: istore #13
    //   616: iload #7
    //   618: istore #10
    //   620: iload #8
    //   622: istore #7
    //   624: iload #18
    //   626: istore #15
    //   628: iload #12
    //   630: istore #8
    //   632: iload #14
    //   634: istore #12
    //   636: iload #11
    //   638: istore #16
    //   640: iload #15
    //   642: iconst_1
    //   643: iadd
    //   644: istore #11
    //   646: goto -> 72
    //   649: aload_0
    //   650: getfield m : I
    //   653: ifle -> 678
    //   656: aload_0
    //   657: iload #17
    //   659: invokevirtual k : (I)Z
    //   662: ifeq -> 678
    //   665: aload_0
    //   666: aload_0
    //   667: getfield m : I
    //   670: aload_0
    //   671: getfield t : I
    //   674: iadd
    //   675: putfield m : I
    //   678: iload #24
    //   680: ifeq -> 813
    //   683: iload #5
    //   685: istore #11
    //   687: iload #11
    //   689: ldc_w -2147483648
    //   692: if_icmpeq -> 700
    //   695: iload #11
    //   697: ifne -> 813
    //   700: aload_0
    //   701: iconst_0
    //   702: putfield m : I
    //   705: iconst_0
    //   706: istore #11
    //   708: iload #11
    //   710: iload #17
    //   712: if_icmpge -> 813
    //   715: aload_0
    //   716: iload #11
    //   718: invokevirtual getChildAt : (I)Landroid/view/View;
    //   721: astore #26
    //   723: aload #26
    //   725: ifnonnull -> 741
    //   728: aload_0
    //   729: aload_0
    //   730: getfield m : I
    //   733: iconst_0
    //   734: iadd
    //   735: putfield m : I
    //   738: goto -> 804
    //   741: aload #26
    //   743: invokevirtual getVisibility : ()I
    //   746: bipush #8
    //   748: if_icmpne -> 760
    //   751: iload #11
    //   753: iconst_0
    //   754: iadd
    //   755: istore #11
    //   757: goto -> 804
    //   760: aload #26
    //   762: invokevirtual getLayoutParams : ()Landroid/view/ViewGroup$LayoutParams;
    //   765: checkcast androidx/appcompat/widget/j0$a
    //   768: astore #26
    //   770: aload_0
    //   771: getfield m : I
    //   774: istore #14
    //   776: aload_0
    //   777: iload #14
    //   779: iload #14
    //   781: iload #12
    //   783: iadd
    //   784: aload #26
    //   786: getfield topMargin : I
    //   789: iadd
    //   790: aload #26
    //   792: getfield bottomMargin : I
    //   795: iadd
    //   796: iconst_0
    //   797: iadd
    //   798: invokestatic max : (II)I
    //   801: putfield m : I
    //   804: iload #11
    //   806: iconst_1
    //   807: iadd
    //   808: istore #11
    //   810: goto -> 708
    //   813: iload #5
    //   815: istore #14
    //   817: aload_0
    //   818: getfield m : I
    //   821: istore #5
    //   823: aload_0
    //   824: invokevirtual getPaddingTop : ()I
    //   827: istore #11
    //   829: aload_0
    //   830: invokevirtual getPaddingBottom : ()I
    //   833: iload #11
    //   835: iadd
    //   836: iload #5
    //   838: iadd
    //   839: istore #5
    //   841: aload_0
    //   842: iload #5
    //   844: putfield m : I
    //   847: iload #5
    //   849: aload_0
    //   850: invokevirtual getSuggestedMinimumHeight : ()I
    //   853: invokestatic max : (II)I
    //   856: iload_2
    //   857: iconst_0
    //   858: invokestatic resolveSizeAndState : (III)I
    //   861: istore #18
    //   863: ldc_w 16777215
    //   866: iload #18
    //   868: iand
    //   869: aload_0
    //   870: getfield m : I
    //   873: isub
    //   874: istore #15
    //   876: iload #13
    //   878: ifne -> 1013
    //   881: iload #15
    //   883: ifeq -> 895
    //   886: fload_3
    //   887: fconst_0
    //   888: fcmpl
    //   889: ifle -> 895
    //   892: goto -> 1013
    //   895: iload #7
    //   897: iload #10
    //   899: invokestatic max : (II)I
    //   902: istore #10
    //   904: iload #24
    //   906: ifeq -> 1002
    //   909: iload #14
    //   911: ldc_w 1073741824
    //   914: if_icmpeq -> 1002
    //   917: iconst_0
    //   918: istore #5
    //   920: iload #5
    //   922: iload #17
    //   924: if_icmpge -> 1002
    //   927: aload_0
    //   928: iload #5
    //   930: invokevirtual getChildAt : (I)Landroid/view/View;
    //   933: astore #26
    //   935: aload #26
    //   937: ifnull -> 993
    //   940: aload #26
    //   942: invokevirtual getVisibility : ()I
    //   945: bipush #8
    //   947: if_icmpne -> 953
    //   950: goto -> 993
    //   953: aload #26
    //   955: invokevirtual getLayoutParams : ()Landroid/view/ViewGroup$LayoutParams;
    //   958: checkcast androidx/appcompat/widget/j0$a
    //   961: getfield a : F
    //   964: fconst_0
    //   965: fcmpl
    //   966: ifle -> 993
    //   969: aload #26
    //   971: aload #26
    //   973: invokevirtual getMeasuredWidth : ()I
    //   976: ldc_w 1073741824
    //   979: invokestatic makeMeasureSpec : (II)I
    //   982: iload #12
    //   984: ldc_w 1073741824
    //   987: invokestatic makeMeasureSpec : (II)I
    //   990: invokevirtual measure : (II)V
    //   993: iload #5
    //   995: iconst_1
    //   996: iadd
    //   997: istore #5
    //   999: goto -> 920
    //   1002: iload #16
    //   1004: istore #7
    //   1006: iload #10
    //   1008: istore #5
    //   1010: goto -> 1449
    //   1013: aload_0
    //   1014: getfield n : F
    //   1017: fstore #4
    //   1019: fload #4
    //   1021: fconst_0
    //   1022: fcmpl
    //   1023: ifle -> 1029
    //   1026: fload #4
    //   1028: fstore_3
    //   1029: iconst_0
    //   1030: istore #11
    //   1032: aload_0
    //   1033: iconst_0
    //   1034: putfield m : I
    //   1037: iload #8
    //   1039: istore #5
    //   1041: iload #16
    //   1043: istore #8
    //   1045: iload #15
    //   1047: istore #10
    //   1049: iload #11
    //   1051: iload #17
    //   1053: if_icmpge -> 1407
    //   1056: aload_0
    //   1057: iload #11
    //   1059: invokevirtual getChildAt : (I)Landroid/view/View;
    //   1062: astore #26
    //   1064: aload #26
    //   1066: invokevirtual getVisibility : ()I
    //   1069: bipush #8
    //   1071: if_icmpne -> 1077
    //   1074: goto -> 1398
    //   1077: aload #26
    //   1079: invokevirtual getLayoutParams : ()Landroid/view/ViewGroup$LayoutParams;
    //   1082: checkcast androidx/appcompat/widget/j0$a
    //   1085: astore #27
    //   1087: aload #27
    //   1089: getfield a : F
    //   1092: fstore #4
    //   1094: fload #4
    //   1096: fconst_0
    //   1097: fcmpl
    //   1098: ifle -> 1251
    //   1101: iload #10
    //   1103: i2f
    //   1104: fload #4
    //   1106: fmul
    //   1107: fload_3
    //   1108: fdiv
    //   1109: f2i
    //   1110: istore #13
    //   1112: fload_3
    //   1113: fload #4
    //   1115: fsub
    //   1116: fstore_3
    //   1117: iload #10
    //   1119: iload #13
    //   1121: isub
    //   1122: istore #12
    //   1124: aload_0
    //   1125: invokevirtual getPaddingLeft : ()I
    //   1128: istore #10
    //   1130: iload_1
    //   1131: aload_0
    //   1132: invokevirtual getPaddingRight : ()I
    //   1135: iload #10
    //   1137: iadd
    //   1138: aload #27
    //   1140: getfield leftMargin : I
    //   1143: iadd
    //   1144: aload #27
    //   1146: getfield rightMargin : I
    //   1149: iadd
    //   1150: aload #27
    //   1152: getfield width : I
    //   1155: invokestatic getChildMeasureSpec : (III)I
    //   1158: istore #15
    //   1160: aload #27
    //   1162: getfield height : I
    //   1165: ifne -> 1191
    //   1168: iload #14
    //   1170: ldc_w 1073741824
    //   1173: if_icmpeq -> 1179
    //   1176: goto -> 1191
    //   1179: iload #13
    //   1181: ifle -> 1210
    //   1184: iload #13
    //   1186: istore #10
    //   1188: goto -> 1213
    //   1191: iload #13
    //   1193: aload #26
    //   1195: invokevirtual getMeasuredHeight : ()I
    //   1198: iadd
    //   1199: istore #13
    //   1201: iload #13
    //   1203: istore #10
    //   1205: iload #13
    //   1207: ifge -> 1213
    //   1210: iconst_0
    //   1211: istore #10
    //   1213: aload #26
    //   1215: iload #15
    //   1217: iload #10
    //   1219: ldc_w 1073741824
    //   1222: invokestatic makeMeasureSpec : (II)I
    //   1225: invokevirtual measure : (II)V
    //   1228: iload #5
    //   1230: aload #26
    //   1232: invokevirtual getMeasuredState : ()I
    //   1235: sipush #-256
    //   1238: iand
    //   1239: invokestatic combineMeasuredStates : (II)I
    //   1242: istore #5
    //   1244: iload #12
    //   1246: istore #10
    //   1248: goto -> 1251
    //   1251: aload #27
    //   1253: getfield leftMargin : I
    //   1256: aload #27
    //   1258: getfield rightMargin : I
    //   1261: iadd
    //   1262: istore #13
    //   1264: aload #26
    //   1266: invokevirtual getMeasuredWidth : ()I
    //   1269: iload #13
    //   1271: iadd
    //   1272: istore #15
    //   1274: iload #8
    //   1276: iload #15
    //   1278: invokestatic max : (II)I
    //   1281: istore #12
    //   1283: iload #20
    //   1285: ldc_w 1073741824
    //   1288: if_icmpeq -> 1306
    //   1291: aload #27
    //   1293: getfield width : I
    //   1296: iconst_m1
    //   1297: if_icmpne -> 1306
    //   1300: iconst_1
    //   1301: istore #8
    //   1303: goto -> 1309
    //   1306: iconst_0
    //   1307: istore #8
    //   1309: iload #8
    //   1311: ifeq -> 1321
    //   1314: iload #13
    //   1316: istore #8
    //   1318: goto -> 1325
    //   1321: iload #15
    //   1323: istore #8
    //   1325: iload #7
    //   1327: iload #8
    //   1329: invokestatic max : (II)I
    //   1332: istore #7
    //   1334: iload #6
    //   1336: ifeq -> 1354
    //   1339: aload #27
    //   1341: getfield width : I
    //   1344: iconst_m1
    //   1345: if_icmpne -> 1354
    //   1348: iconst_1
    //   1349: istore #6
    //   1351: goto -> 1357
    //   1354: iconst_0
    //   1355: istore #6
    //   1357: aload_0
    //   1358: getfield m : I
    //   1361: istore #8
    //   1363: aload_0
    //   1364: iload #8
    //   1366: aload #26
    //   1368: invokevirtual getMeasuredHeight : ()I
    //   1371: iload #8
    //   1373: iadd
    //   1374: aload #27
    //   1376: getfield topMargin : I
    //   1379: iadd
    //   1380: aload #27
    //   1382: getfield bottomMargin : I
    //   1385: iadd
    //   1386: iconst_0
    //   1387: iadd
    //   1388: invokestatic max : (II)I
    //   1391: putfield m : I
    //   1394: iload #12
    //   1396: istore #8
    //   1398: iload #11
    //   1400: iconst_1
    //   1401: iadd
    //   1402: istore #11
    //   1404: goto -> 1049
    //   1407: aload_0
    //   1408: getfield m : I
    //   1411: istore #10
    //   1413: aload_0
    //   1414: invokevirtual getPaddingTop : ()I
    //   1417: istore #11
    //   1419: aload_0
    //   1420: aload_0
    //   1421: invokevirtual getPaddingBottom : ()I
    //   1424: iload #11
    //   1426: iadd
    //   1427: iload #10
    //   1429: iadd
    //   1430: putfield m : I
    //   1433: iload #8
    //   1435: istore #10
    //   1437: iload #5
    //   1439: istore #8
    //   1441: iload #7
    //   1443: istore #5
    //   1445: iload #10
    //   1447: istore #7
    //   1449: iload #6
    //   1451: ifne -> 1465
    //   1454: iload #20
    //   1456: ldc_w 1073741824
    //   1459: if_icmpeq -> 1465
    //   1462: goto -> 1469
    //   1465: iload #7
    //   1467: istore #5
    //   1469: aload_0
    //   1470: invokevirtual getPaddingLeft : ()I
    //   1473: istore #6
    //   1475: aload_0
    //   1476: aload_0
    //   1477: invokevirtual getPaddingRight : ()I
    //   1480: iload #6
    //   1482: iadd
    //   1483: iload #5
    //   1485: iadd
    //   1486: aload_0
    //   1487: invokevirtual getSuggestedMinimumWidth : ()I
    //   1490: invokestatic max : (II)I
    //   1493: iload_1
    //   1494: iload #8
    //   1496: invokestatic resolveSizeAndState : (III)I
    //   1499: iload #18
    //   1501: invokevirtual setMeasuredDimension : (II)V
    //   1504: iload #9
    //   1506: ifeq -> 3914
    //   1509: aload_0
    //   1510: invokevirtual getMeasuredWidth : ()I
    //   1513: ldc_w 1073741824
    //   1516: invokestatic makeMeasureSpec : (II)I
    //   1519: istore #5
    //   1521: iconst_0
    //   1522: istore_1
    //   1523: iload_1
    //   1524: iload #17
    //   1526: if_icmpge -> 3914
    //   1529: aload_0
    //   1530: iload_1
    //   1531: invokevirtual getChildAt : (I)Landroid/view/View;
    //   1534: astore #26
    //   1536: aload #26
    //   1538: invokevirtual getVisibility : ()I
    //   1541: bipush #8
    //   1543: if_icmpeq -> 1600
    //   1546: aload #26
    //   1548: invokevirtual getLayoutParams : ()Landroid/view/ViewGroup$LayoutParams;
    //   1551: checkcast androidx/appcompat/widget/j0$a
    //   1554: astore #27
    //   1556: aload #27
    //   1558: getfield width : I
    //   1561: iconst_m1
    //   1562: if_icmpne -> 1600
    //   1565: aload #27
    //   1567: getfield height : I
    //   1570: istore #6
    //   1572: aload #27
    //   1574: aload #26
    //   1576: invokevirtual getMeasuredHeight : ()I
    //   1579: putfield height : I
    //   1582: aload_0
    //   1583: aload #26
    //   1585: iload #5
    //   1587: iconst_0
    //   1588: iload_2
    //   1589: iconst_0
    //   1590: invokevirtual measureChildWithMargins : (Landroid/view/View;IIII)V
    //   1593: aload #27
    //   1595: iload #6
    //   1597: putfield height : I
    //   1600: iload_1
    //   1601: iconst_1
    //   1602: iadd
    //   1603: istore_1
    //   1604: goto -> 1523
    //   1607: aload_0
    //   1608: iconst_0
    //   1609: putfield m : I
    //   1612: aload_0
    //   1613: invokevirtual getVirtualChildCount : ()I
    //   1616: istore #17
    //   1618: iload_1
    //   1619: invokestatic getMode : (I)I
    //   1622: istore #9
    //   1624: iload_2
    //   1625: invokestatic getMode : (I)I
    //   1628: istore #22
    //   1630: aload_0
    //   1631: getfield p : [I
    //   1634: ifnull -> 1644
    //   1637: aload_0
    //   1638: getfield q : [I
    //   1641: ifnonnull -> 1658
    //   1644: aload_0
    //   1645: iconst_4
    //   1646: newarray int
    //   1648: putfield p : [I
    //   1651: aload_0
    //   1652: iconst_4
    //   1653: newarray int
    //   1655: putfield q : [I
    //   1658: aload_0
    //   1659: getfield p : [I
    //   1662: astore #29
    //   1664: aload_0
    //   1665: getfield q : [I
    //   1668: astore #30
    //   1670: aload #29
    //   1672: iconst_3
    //   1673: iconst_m1
    //   1674: iastore
    //   1675: aload #29
    //   1677: iconst_2
    //   1678: iconst_m1
    //   1679: iastore
    //   1680: aload #29
    //   1682: iconst_1
    //   1683: iconst_m1
    //   1684: iastore
    //   1685: aload #29
    //   1687: iconst_0
    //   1688: iconst_m1
    //   1689: iastore
    //   1690: aload #30
    //   1692: iconst_3
    //   1693: iconst_m1
    //   1694: iastore
    //   1695: aload #30
    //   1697: iconst_2
    //   1698: iconst_m1
    //   1699: iastore
    //   1700: aload #30
    //   1702: iconst_1
    //   1703: iconst_m1
    //   1704: iastore
    //   1705: aload #30
    //   1707: iconst_0
    //   1708: iconst_m1
    //   1709: iastore
    //   1710: aload_0
    //   1711: getfield h : Z
    //   1714: istore #25
    //   1716: aload_0
    //   1717: getfield o : Z
    //   1720: istore #24
    //   1722: iload #9
    //   1724: ldc_w 1073741824
    //   1727: if_icmpne -> 1736
    //   1730: iconst_1
    //   1731: istore #16
    //   1733: goto -> 1739
    //   1736: iconst_0
    //   1737: istore #16
    //   1739: fconst_0
    //   1740: fstore_3
    //   1741: iconst_0
    //   1742: istore #13
    //   1744: iconst_1
    //   1745: istore #8
    //   1747: iconst_0
    //   1748: istore #10
    //   1750: iconst_0
    //   1751: istore #6
    //   1753: iconst_0
    //   1754: istore #7
    //   1756: iconst_0
    //   1757: istore #5
    //   1759: iconst_0
    //   1760: istore #11
    //   1762: iconst_0
    //   1763: istore #12
    //   1765: iconst_0
    //   1766: istore #14
    //   1768: iload #7
    //   1770: iload #17
    //   1772: if_icmpge -> 2481
    //   1775: aload_0
    //   1776: iload #7
    //   1778: invokevirtual getChildAt : (I)Landroid/view/View;
    //   1781: astore #27
    //   1783: aload #27
    //   1785: ifnonnull -> 1801
    //   1788: aload_0
    //   1789: aload_0
    //   1790: getfield m : I
    //   1793: iconst_0
    //   1794: iadd
    //   1795: putfield m : I
    //   1798: goto -> 1829
    //   1801: iload #6
    //   1803: istore #18
    //   1805: aload #27
    //   1807: invokevirtual getVisibility : ()I
    //   1810: istore #19
    //   1812: iload #5
    //   1814: istore #15
    //   1816: iload #19
    //   1818: bipush #8
    //   1820: if_icmpne -> 1836
    //   1823: iload #7
    //   1825: iconst_0
    //   1826: iadd
    //   1827: istore #7
    //   1829: iload #8
    //   1831: istore #15
    //   1833: goto -> 2468
    //   1836: aload_0
    //   1837: iload #7
    //   1839: invokevirtual k : (I)Z
    //   1842: ifeq -> 1858
    //   1845: aload_0
    //   1846: aload_0
    //   1847: getfield m : I
    //   1850: aload_0
    //   1851: getfield s : I
    //   1854: iadd
    //   1855: putfield m : I
    //   1858: aload #27
    //   1860: invokevirtual getLayoutParams : ()Landroid/view/ViewGroup$LayoutParams;
    //   1863: checkcast androidx/appcompat/widget/j0$a
    //   1866: astore #26
    //   1868: aload #26
    //   1870: getfield a : F
    //   1873: fstore #4
    //   1875: fload_3
    //   1876: fload #4
    //   1878: fadd
    //   1879: fstore_3
    //   1880: iload #9
    //   1882: ldc_w 1073741824
    //   1885: if_icmpne -> 2006
    //   1888: aload #26
    //   1890: getfield width : I
    //   1893: ifne -> 2006
    //   1896: fload #4
    //   1898: fconst_0
    //   1899: fcmpl
    //   1900: ifle -> 2006
    //   1903: iload #16
    //   1905: ifeq -> 1935
    //   1908: aload_0
    //   1909: getfield m : I
    //   1912: istore #15
    //   1914: aload_0
    //   1915: aload #26
    //   1917: getfield leftMargin : I
    //   1920: aload #26
    //   1922: getfield rightMargin : I
    //   1925: iadd
    //   1926: iload #15
    //   1928: iadd
    //   1929: putfield m : I
    //   1932: goto -> 1964
    //   1935: aload_0
    //   1936: getfield m : I
    //   1939: istore #15
    //   1941: aload_0
    //   1942: iload #15
    //   1944: aload #26
    //   1946: getfield leftMargin : I
    //   1949: iload #15
    //   1951: iadd
    //   1952: aload #26
    //   1954: getfield rightMargin : I
    //   1957: iadd
    //   1958: invokestatic max : (II)I
    //   1961: putfield m : I
    //   1964: iload #25
    //   1966: ifeq -> 1992
    //   1969: iconst_0
    //   1970: iconst_0
    //   1971: invokestatic makeMeasureSpec : (II)I
    //   1974: istore #15
    //   1976: aload #27
    //   1978: iload #15
    //   1980: iload #15
    //   1982: invokevirtual measure : (II)V
    //   1985: iload #7
    //   1987: istore #15
    //   1989: goto -> 2189
    //   1992: iconst_1
    //   1993: istore #13
    //   1995: iload #18
    //   1997: istore #6
    //   1999: iload #7
    //   2001: istore #15
    //   2003: goto -> 2197
    //   2006: aload #26
    //   2008: getfield width : I
    //   2011: ifne -> 2034
    //   2014: fload #4
    //   2016: fconst_0
    //   2017: fcmpl
    //   2018: ifle -> 2034
    //   2021: aload #26
    //   2023: bipush #-2
    //   2025: putfield width : I
    //   2028: iconst_0
    //   2029: istore #15
    //   2031: goto -> 2039
    //   2034: ldc_w -2147483648
    //   2037: istore #15
    //   2039: fload_3
    //   2040: fconst_0
    //   2041: fcmpl
    //   2042: ifne -> 2054
    //   2045: aload_0
    //   2046: getfield m : I
    //   2049: istore #19
    //   2051: goto -> 2057
    //   2054: iconst_0
    //   2055: istore #19
    //   2057: aload_0
    //   2058: aload #27
    //   2060: iload_1
    //   2061: iload #19
    //   2063: iload_2
    //   2064: iconst_0
    //   2065: invokevirtual measureChildWithMargins : (Landroid/view/View;IIII)V
    //   2068: iload #15
    //   2070: ldc_w -2147483648
    //   2073: if_icmpeq -> 2086
    //   2076: aload #26
    //   2078: iload #15
    //   2080: putfield width : I
    //   2083: goto -> 2086
    //   2086: aload #26
    //   2088: astore #28
    //   2090: aload #27
    //   2092: invokevirtual getMeasuredWidth : ()I
    //   2095: istore #19
    //   2097: iload #16
    //   2099: ifeq -> 2134
    //   2102: aload_0
    //   2103: getfield m : I
    //   2106: istore #15
    //   2108: aload_0
    //   2109: aload #28
    //   2111: getfield leftMargin : I
    //   2114: iload #19
    //   2116: iadd
    //   2117: aload #28
    //   2119: getfield rightMargin : I
    //   2122: iadd
    //   2123: iconst_0
    //   2124: iadd
    //   2125: iload #15
    //   2127: iadd
    //   2128: putfield m : I
    //   2131: goto -> 2168
    //   2134: aload_0
    //   2135: getfield m : I
    //   2138: istore #15
    //   2140: aload_0
    //   2141: iload #15
    //   2143: iload #15
    //   2145: iload #19
    //   2147: iadd
    //   2148: aload #28
    //   2150: getfield leftMargin : I
    //   2153: iadd
    //   2154: aload #28
    //   2156: getfield rightMargin : I
    //   2159: iadd
    //   2160: iconst_0
    //   2161: iadd
    //   2162: invokestatic max : (II)I
    //   2165: putfield m : I
    //   2168: iload #7
    //   2170: istore #15
    //   2172: iload #24
    //   2174: ifeq -> 2189
    //   2177: iload #19
    //   2179: iload #18
    //   2181: invokestatic max : (II)I
    //   2184: istore #6
    //   2186: goto -> 2193
    //   2189: iload #15
    //   2191: istore #7
    //   2193: iload #7
    //   2195: istore #15
    //   2197: iload #5
    //   2199: istore #7
    //   2201: iload #22
    //   2203: ldc_w 1073741824
    //   2206: if_icmpeq -> 2227
    //   2209: aload #26
    //   2211: getfield height : I
    //   2214: iconst_m1
    //   2215: if_icmpne -> 2227
    //   2218: iconst_1
    //   2219: istore #18
    //   2221: iconst_1
    //   2222: istore #10
    //   2224: goto -> 2230
    //   2227: iconst_0
    //   2228: istore #18
    //   2230: aload #26
    //   2232: getfield topMargin : I
    //   2235: aload #26
    //   2237: getfield bottomMargin : I
    //   2240: iadd
    //   2241: istore #19
    //   2243: aload #27
    //   2245: invokevirtual getMeasuredHeight : ()I
    //   2248: iload #19
    //   2250: iadd
    //   2251: istore #20
    //   2253: iload #14
    //   2255: aload #27
    //   2257: invokevirtual getMeasuredState : ()I
    //   2260: invokestatic combineMeasuredStates : (II)I
    //   2263: istore #14
    //   2265: iload #25
    //   2267: ifeq -> 2355
    //   2270: aload #27
    //   2272: invokevirtual getBaseline : ()I
    //   2275: istore #23
    //   2277: iload #23
    //   2279: iconst_m1
    //   2280: if_icmpeq -> 2355
    //   2283: aload #26
    //   2285: getfield b : I
    //   2288: istore #21
    //   2290: iload #21
    //   2292: istore #5
    //   2294: iload #21
    //   2296: ifge -> 2305
    //   2299: aload_0
    //   2300: getfield l : I
    //   2303: istore #5
    //   2305: iload #5
    //   2307: bipush #112
    //   2309: iand
    //   2310: iconst_4
    //   2311: ishr
    //   2312: bipush #-2
    //   2314: iand
    //   2315: iconst_1
    //   2316: ishr
    //   2317: istore #5
    //   2319: aload #29
    //   2321: iload #5
    //   2323: aload #29
    //   2325: iload #5
    //   2327: iaload
    //   2328: iload #23
    //   2330: invokestatic max : (II)I
    //   2333: iastore
    //   2334: aload #30
    //   2336: iload #5
    //   2338: aload #30
    //   2340: iload #5
    //   2342: iaload
    //   2343: iload #20
    //   2345: iload #23
    //   2347: isub
    //   2348: invokestatic max : (II)I
    //   2351: iastore
    //   2352: goto -> 2355
    //   2355: iload #12
    //   2357: iload #20
    //   2359: invokestatic max : (II)I
    //   2362: istore #12
    //   2364: iload #8
    //   2366: ifeq -> 2384
    //   2369: aload #26
    //   2371: getfield height : I
    //   2374: iconst_m1
    //   2375: if_icmpne -> 2384
    //   2378: iconst_1
    //   2379: istore #5
    //   2381: goto -> 2387
    //   2384: iconst_0
    //   2385: istore #5
    //   2387: aload #26
    //   2389: getfield a : F
    //   2392: fconst_0
    //   2393: fcmpl
    //   2394: ifle -> 2421
    //   2397: iload #18
    //   2399: ifeq -> 2405
    //   2402: goto -> 2409
    //   2405: iload #20
    //   2407: istore #19
    //   2409: iload #11
    //   2411: iload #19
    //   2413: invokestatic max : (II)I
    //   2416: istore #8
    //   2418: goto -> 2446
    //   2421: iload #18
    //   2423: ifeq -> 2429
    //   2426: goto -> 2433
    //   2429: iload #20
    //   2431: istore #19
    //   2433: iload #7
    //   2435: iload #19
    //   2437: invokestatic max : (II)I
    //   2440: istore #7
    //   2442: iload #11
    //   2444: istore #8
    //   2446: iload #15
    //   2448: iconst_0
    //   2449: iadd
    //   2450: istore #18
    //   2452: iload #5
    //   2454: istore #15
    //   2456: iload #8
    //   2458: istore #11
    //   2460: iload #7
    //   2462: istore #5
    //   2464: iload #18
    //   2466: istore #7
    //   2468: iload #7
    //   2470: iconst_1
    //   2471: iadd
    //   2472: istore #7
    //   2474: iload #15
    //   2476: istore #8
    //   2478: goto -> 1768
    //   2481: iload #5
    //   2483: istore #15
    //   2485: aload_0
    //   2486: getfield m : I
    //   2489: ifle -> 2514
    //   2492: aload_0
    //   2493: iload #17
    //   2495: invokevirtual k : (I)Z
    //   2498: ifeq -> 2514
    //   2501: aload_0
    //   2502: aload_0
    //   2503: getfield m : I
    //   2506: aload_0
    //   2507: getfield s : I
    //   2510: iadd
    //   2511: putfield m : I
    //   2514: aload #29
    //   2516: iconst_1
    //   2517: iaload
    //   2518: iconst_m1
    //   2519: if_icmpne -> 2552
    //   2522: aload #29
    //   2524: iconst_0
    //   2525: iaload
    //   2526: iconst_m1
    //   2527: if_icmpne -> 2552
    //   2530: aload #29
    //   2532: iconst_2
    //   2533: iaload
    //   2534: iconst_m1
    //   2535: if_icmpne -> 2552
    //   2538: aload #29
    //   2540: iconst_3
    //   2541: iaload
    //   2542: iconst_m1
    //   2543: if_icmpeq -> 2549
    //   2546: goto -> 2552
    //   2549: goto -> 2614
    //   2552: aload #29
    //   2554: iconst_3
    //   2555: iaload
    //   2556: aload #29
    //   2558: iconst_0
    //   2559: iaload
    //   2560: aload #29
    //   2562: iconst_1
    //   2563: iaload
    //   2564: aload #29
    //   2566: iconst_2
    //   2567: iaload
    //   2568: invokestatic max : (II)I
    //   2571: invokestatic max : (II)I
    //   2574: invokestatic max : (II)I
    //   2577: istore #5
    //   2579: iload #12
    //   2581: aload #30
    //   2583: iconst_3
    //   2584: iaload
    //   2585: aload #30
    //   2587: iconst_0
    //   2588: iaload
    //   2589: aload #30
    //   2591: iconst_1
    //   2592: iaload
    //   2593: aload #30
    //   2595: iconst_2
    //   2596: iaload
    //   2597: invokestatic max : (II)I
    //   2600: invokestatic max : (II)I
    //   2603: invokestatic max : (II)I
    //   2606: iload #5
    //   2608: iadd
    //   2609: invokestatic max : (II)I
    //   2612: istore #12
    //   2614: iload #24
    //   2616: ifeq -> 2780
    //   2619: iload #9
    //   2621: istore #5
    //   2623: iload #5
    //   2625: ldc_w -2147483648
    //   2628: if_icmpeq -> 2636
    //   2631: iload #5
    //   2633: ifne -> 2780
    //   2636: aload_0
    //   2637: iconst_0
    //   2638: putfield m : I
    //   2641: iconst_0
    //   2642: istore #5
    //   2644: iload #5
    //   2646: iload #17
    //   2648: if_icmpge -> 2780
    //   2651: aload_0
    //   2652: iload #5
    //   2654: invokevirtual getChildAt : (I)Landroid/view/View;
    //   2657: astore #26
    //   2659: aload #26
    //   2661: ifnonnull -> 2677
    //   2664: aload_0
    //   2665: aload_0
    //   2666: getfield m : I
    //   2669: iconst_0
    //   2670: iadd
    //   2671: putfield m : I
    //   2674: goto -> 2771
    //   2677: aload #26
    //   2679: invokevirtual getVisibility : ()I
    //   2682: bipush #8
    //   2684: if_icmpne -> 2696
    //   2687: iload #5
    //   2689: iconst_0
    //   2690: iadd
    //   2691: istore #5
    //   2693: goto -> 2771
    //   2696: aload #26
    //   2698: invokevirtual getLayoutParams : ()Landroid/view/ViewGroup$LayoutParams;
    //   2701: checkcast androidx/appcompat/widget/j0$a
    //   2704: astore #26
    //   2706: aload_0
    //   2707: getfield m : I
    //   2710: istore #7
    //   2712: iload #16
    //   2714: ifeq -> 2743
    //   2717: aload_0
    //   2718: aload #26
    //   2720: getfield leftMargin : I
    //   2723: iload #6
    //   2725: iadd
    //   2726: aload #26
    //   2728: getfield rightMargin : I
    //   2731: iadd
    //   2732: iconst_0
    //   2733: iadd
    //   2734: iload #7
    //   2736: iadd
    //   2737: putfield m : I
    //   2740: goto -> 2674
    //   2743: aload_0
    //   2744: iload #7
    //   2746: iload #7
    //   2748: iload #6
    //   2750: iadd
    //   2751: aload #26
    //   2753: getfield leftMargin : I
    //   2756: iadd
    //   2757: aload #26
    //   2759: getfield rightMargin : I
    //   2762: iadd
    //   2763: iconst_0
    //   2764: iadd
    //   2765: invokestatic max : (II)I
    //   2768: putfield m : I
    //   2771: iload #5
    //   2773: iconst_1
    //   2774: iadd
    //   2775: istore #5
    //   2777: goto -> 2644
    //   2780: iload #9
    //   2782: istore #18
    //   2784: aload_0
    //   2785: getfield m : I
    //   2788: istore #5
    //   2790: aload_0
    //   2791: invokevirtual getPaddingLeft : ()I
    //   2794: istore #7
    //   2796: aload_0
    //   2797: invokevirtual getPaddingRight : ()I
    //   2800: iload #7
    //   2802: iadd
    //   2803: iload #5
    //   2805: iadd
    //   2806: istore #5
    //   2808: aload_0
    //   2809: iload #5
    //   2811: putfield m : I
    //   2814: iload #5
    //   2816: aload_0
    //   2817: invokevirtual getSuggestedMinimumWidth : ()I
    //   2820: invokestatic max : (II)I
    //   2823: iload_1
    //   2824: iconst_0
    //   2825: invokestatic resolveSizeAndState : (III)I
    //   2828: istore #9
    //   2830: ldc_w 16777215
    //   2833: iload #9
    //   2835: iand
    //   2836: aload_0
    //   2837: getfield m : I
    //   2840: isub
    //   2841: istore #7
    //   2843: iload #13
    //   2845: ifne -> 2984
    //   2848: iload #7
    //   2850: ifeq -> 2862
    //   2853: fload_3
    //   2854: fconst_0
    //   2855: fcmpl
    //   2856: ifle -> 2862
    //   2859: goto -> 2984
    //   2862: iload #15
    //   2864: iload #11
    //   2866: invokestatic max : (II)I
    //   2869: istore #7
    //   2871: iload #24
    //   2873: ifeq -> 2969
    //   2876: iload #18
    //   2878: ldc_w 1073741824
    //   2881: if_icmpeq -> 2969
    //   2884: iconst_0
    //   2885: istore #5
    //   2887: iload #5
    //   2889: iload #17
    //   2891: if_icmpge -> 2969
    //   2894: aload_0
    //   2895: iload #5
    //   2897: invokevirtual getChildAt : (I)Landroid/view/View;
    //   2900: astore #26
    //   2902: aload #26
    //   2904: ifnull -> 2960
    //   2907: aload #26
    //   2909: invokevirtual getVisibility : ()I
    //   2912: bipush #8
    //   2914: if_icmpne -> 2920
    //   2917: goto -> 2960
    //   2920: aload #26
    //   2922: invokevirtual getLayoutParams : ()Landroid/view/ViewGroup$LayoutParams;
    //   2925: checkcast androidx/appcompat/widget/j0$a
    //   2928: getfield a : F
    //   2931: fconst_0
    //   2932: fcmpl
    //   2933: ifle -> 2960
    //   2936: aload #26
    //   2938: iload #6
    //   2940: ldc_w 1073741824
    //   2943: invokestatic makeMeasureSpec : (II)I
    //   2946: aload #26
    //   2948: invokevirtual getMeasuredHeight : ()I
    //   2951: ldc_w 1073741824
    //   2954: invokestatic makeMeasureSpec : (II)I
    //   2957: invokevirtual measure : (II)V
    //   2960: iload #5
    //   2962: iconst_1
    //   2963: iadd
    //   2964: istore #5
    //   2966: goto -> 2887
    //   2969: iload #9
    //   2971: istore #6
    //   2973: iload #17
    //   2975: istore #11
    //   2977: iload #14
    //   2979: istore #5
    //   2981: goto -> 3665
    //   2984: aload_0
    //   2985: getfield n : F
    //   2988: fstore #4
    //   2990: fload #4
    //   2992: fconst_0
    //   2993: fcmpl
    //   2994: ifle -> 3000
    //   2997: fload #4
    //   2999: fstore_3
    //   3000: aload #29
    //   3002: iconst_3
    //   3003: iconst_m1
    //   3004: iastore
    //   3005: aload #29
    //   3007: iconst_2
    //   3008: iconst_m1
    //   3009: iastore
    //   3010: aload #29
    //   3012: iconst_1
    //   3013: iconst_m1
    //   3014: iastore
    //   3015: aload #29
    //   3017: iconst_0
    //   3018: iconst_m1
    //   3019: iastore
    //   3020: aload #30
    //   3022: iconst_3
    //   3023: iconst_m1
    //   3024: iastore
    //   3025: aload #30
    //   3027: iconst_2
    //   3028: iconst_m1
    //   3029: iastore
    //   3030: aload #30
    //   3032: iconst_1
    //   3033: iconst_m1
    //   3034: iastore
    //   3035: aload #30
    //   3037: iconst_0
    //   3038: iconst_m1
    //   3039: iastore
    //   3040: aload_0
    //   3041: iconst_0
    //   3042: putfield m : I
    //   3045: iconst_m1
    //   3046: istore #13
    //   3048: iconst_0
    //   3049: istore #6
    //   3051: iload #14
    //   3053: istore #5
    //   3055: iload #6
    //   3057: istore #14
    //   3059: iload #17
    //   3061: istore #11
    //   3063: iload #15
    //   3065: istore #6
    //   3067: iload #9
    //   3069: istore #12
    //   3071: iload #14
    //   3073: iload #11
    //   3075: if_icmpge -> 3592
    //   3078: aload_0
    //   3079: iload #14
    //   3081: invokevirtual getChildAt : (I)Landroid/view/View;
    //   3084: astore #26
    //   3086: aload #26
    //   3088: ifnull -> 3559
    //   3091: aload #26
    //   3093: invokevirtual getVisibility : ()I
    //   3096: bipush #8
    //   3098: if_icmpne -> 3104
    //   3101: goto -> 3559
    //   3104: aload #26
    //   3106: invokevirtual getLayoutParams : ()Landroid/view/ViewGroup$LayoutParams;
    //   3109: checkcast androidx/appcompat/widget/j0$a
    //   3112: astore #27
    //   3114: aload #27
    //   3116: getfield a : F
    //   3119: fstore #4
    //   3121: fload #4
    //   3123: fconst_0
    //   3124: fcmpl
    //   3125: ifle -> 3274
    //   3128: iload #7
    //   3130: i2f
    //   3131: fload #4
    //   3133: fmul
    //   3134: fload_3
    //   3135: fdiv
    //   3136: f2i
    //   3137: istore #15
    //   3139: aload_0
    //   3140: invokevirtual getPaddingTop : ()I
    //   3143: istore #9
    //   3145: iload_2
    //   3146: aload_0
    //   3147: invokevirtual getPaddingBottom : ()I
    //   3150: iload #9
    //   3152: iadd
    //   3153: aload #27
    //   3155: getfield topMargin : I
    //   3158: iadd
    //   3159: aload #27
    //   3161: getfield bottomMargin : I
    //   3164: iadd
    //   3165: aload #27
    //   3167: getfield height : I
    //   3170: invokestatic getChildMeasureSpec : (III)I
    //   3173: istore #19
    //   3175: aload #27
    //   3177: getfield width : I
    //   3180: ifne -> 3206
    //   3183: iload #18
    //   3185: ldc_w 1073741824
    //   3188: if_icmpeq -> 3194
    //   3191: goto -> 3206
    //   3194: iload #15
    //   3196: ifle -> 3225
    //   3199: iload #15
    //   3201: istore #9
    //   3203: goto -> 3228
    //   3206: iload #15
    //   3208: aload #26
    //   3210: invokevirtual getMeasuredWidth : ()I
    //   3213: iadd
    //   3214: istore #17
    //   3216: iload #17
    //   3218: istore #9
    //   3220: iload #17
    //   3222: ifge -> 3228
    //   3225: iconst_0
    //   3226: istore #9
    //   3228: aload #26
    //   3230: iload #9
    //   3232: ldc_w 1073741824
    //   3235: invokestatic makeMeasureSpec : (II)I
    //   3238: iload #19
    //   3240: invokevirtual measure : (II)V
    //   3243: iload #5
    //   3245: aload #26
    //   3247: invokevirtual getMeasuredState : ()I
    //   3250: ldc_w -16777216
    //   3253: iand
    //   3254: invokestatic combineMeasuredStates : (II)I
    //   3257: istore #5
    //   3259: fload_3
    //   3260: fload #4
    //   3262: fsub
    //   3263: fstore_3
    //   3264: iload #7
    //   3266: iload #15
    //   3268: isub
    //   3269: istore #7
    //   3271: goto -> 3274
    //   3274: iload #16
    //   3276: ifeq -> 3314
    //   3279: aload_0
    //   3280: getfield m : I
    //   3283: istore #9
    //   3285: aload_0
    //   3286: aload #26
    //   3288: invokevirtual getMeasuredWidth : ()I
    //   3291: aload #27
    //   3293: getfield leftMargin : I
    //   3296: iadd
    //   3297: aload #27
    //   3299: getfield rightMargin : I
    //   3302: iadd
    //   3303: iconst_0
    //   3304: iadd
    //   3305: iload #9
    //   3307: iadd
    //   3308: putfield m : I
    //   3311: goto -> 3351
    //   3314: aload_0
    //   3315: getfield m : I
    //   3318: istore #9
    //   3320: aload_0
    //   3321: iload #9
    //   3323: aload #26
    //   3325: invokevirtual getMeasuredWidth : ()I
    //   3328: iload #9
    //   3330: iadd
    //   3331: aload #27
    //   3333: getfield leftMargin : I
    //   3336: iadd
    //   3337: aload #27
    //   3339: getfield rightMargin : I
    //   3342: iadd
    //   3343: iconst_0
    //   3344: iadd
    //   3345: invokestatic max : (II)I
    //   3348: putfield m : I
    //   3351: iload #22
    //   3353: ldc_w 1073741824
    //   3356: if_icmpeq -> 3374
    //   3359: aload #27
    //   3361: getfield height : I
    //   3364: iconst_m1
    //   3365: if_icmpne -> 3374
    //   3368: iconst_1
    //   3369: istore #9
    //   3371: goto -> 3377
    //   3374: iconst_0
    //   3375: istore #9
    //   3377: aload #27
    //   3379: getfield topMargin : I
    //   3382: aload #27
    //   3384: getfield bottomMargin : I
    //   3387: iadd
    //   3388: istore #17
    //   3390: aload #26
    //   3392: invokevirtual getMeasuredHeight : ()I
    //   3395: iload #17
    //   3397: iadd
    //   3398: istore #15
    //   3400: iload #13
    //   3402: iload #15
    //   3404: invokestatic max : (II)I
    //   3407: istore #13
    //   3409: iload #9
    //   3411: ifeq -> 3421
    //   3414: iload #17
    //   3416: istore #9
    //   3418: goto -> 3425
    //   3421: iload #15
    //   3423: istore #9
    //   3425: iload #6
    //   3427: iload #9
    //   3429: invokestatic max : (II)I
    //   3432: istore #9
    //   3434: iload #8
    //   3436: ifeq -> 3454
    //   3439: aload #27
    //   3441: getfield height : I
    //   3444: iconst_m1
    //   3445: if_icmpne -> 3454
    //   3448: iconst_1
    //   3449: istore #6
    //   3451: goto -> 3457
    //   3454: iconst_0
    //   3455: istore #6
    //   3457: iload #25
    //   3459: ifeq -> 3544
    //   3462: aload #26
    //   3464: invokevirtual getBaseline : ()I
    //   3467: istore #19
    //   3469: iload #19
    //   3471: iconst_m1
    //   3472: if_icmpeq -> 3544
    //   3475: aload #27
    //   3477: getfield b : I
    //   3480: istore #17
    //   3482: iload #17
    //   3484: istore #8
    //   3486: iload #17
    //   3488: ifge -> 3497
    //   3491: aload_0
    //   3492: getfield l : I
    //   3495: istore #8
    //   3497: iload #8
    //   3499: bipush #112
    //   3501: iand
    //   3502: iconst_4
    //   3503: ishr
    //   3504: bipush #-2
    //   3506: iand
    //   3507: iconst_1
    //   3508: ishr
    //   3509: istore #8
    //   3511: aload #29
    //   3513: iload #8
    //   3515: aload #29
    //   3517: iload #8
    //   3519: iaload
    //   3520: iload #19
    //   3522: invokestatic max : (II)I
    //   3525: iastore
    //   3526: aload #30
    //   3528: iload #8
    //   3530: aload #30
    //   3532: iload #8
    //   3534: iaload
    //   3535: iload #15
    //   3537: iload #19
    //   3539: isub
    //   3540: invokestatic max : (II)I
    //   3543: iastore
    //   3544: iload #6
    //   3546: istore #8
    //   3548: iload #7
    //   3550: istore #6
    //   3552: iload #9
    //   3554: istore #7
    //   3556: goto -> 3571
    //   3559: iload #7
    //   3561: istore #9
    //   3563: iload #6
    //   3565: istore #7
    //   3567: iload #9
    //   3569: istore #6
    //   3571: iload #14
    //   3573: iconst_1
    //   3574: iadd
    //   3575: istore #14
    //   3577: iload #6
    //   3579: istore #9
    //   3581: iload #7
    //   3583: istore #6
    //   3585: iload #9
    //   3587: istore #7
    //   3589: goto -> 3071
    //   3592: aload_0
    //   3593: getfield m : I
    //   3596: istore #7
    //   3598: aload_0
    //   3599: invokevirtual getPaddingLeft : ()I
    //   3602: istore #9
    //   3604: aload_0
    //   3605: aload_0
    //   3606: invokevirtual getPaddingRight : ()I
    //   3609: iload #9
    //   3611: iadd
    //   3612: iload #7
    //   3614: iadd
    //   3615: putfield m : I
    //   3618: aload #29
    //   3620: iconst_1
    //   3621: iaload
    //   3622: iconst_m1
    //   3623: if_icmpne -> 3672
    //   3626: aload #29
    //   3628: iconst_0
    //   3629: iaload
    //   3630: iconst_m1
    //   3631: if_icmpne -> 3672
    //   3634: aload #29
    //   3636: iconst_2
    //   3637: iaload
    //   3638: iconst_m1
    //   3639: if_icmpne -> 3672
    //   3642: aload #29
    //   3644: iconst_3
    //   3645: iaload
    //   3646: iconst_m1
    //   3647: if_icmpeq -> 3653
    //   3650: goto -> 3672
    //   3653: iload #6
    //   3655: istore #7
    //   3657: iload #12
    //   3659: istore #6
    //   3661: iload #13
    //   3663: istore #12
    //   3665: iload #6
    //   3667: istore #9
    //   3669: goto -> 3746
    //   3672: aload #29
    //   3674: iconst_3
    //   3675: iaload
    //   3676: aload #29
    //   3678: iconst_0
    //   3679: iaload
    //   3680: aload #29
    //   3682: iconst_1
    //   3683: iaload
    //   3684: aload #29
    //   3686: iconst_2
    //   3687: iaload
    //   3688: invokestatic max : (II)I
    //   3691: invokestatic max : (II)I
    //   3694: invokestatic max : (II)I
    //   3697: istore #7
    //   3699: iload #13
    //   3701: aload #30
    //   3703: iconst_3
    //   3704: iaload
    //   3705: aload #30
    //   3707: iconst_0
    //   3708: iaload
    //   3709: aload #30
    //   3711: iconst_1
    //   3712: iaload
    //   3713: aload #30
    //   3715: iconst_2
    //   3716: iaload
    //   3717: invokestatic max : (II)I
    //   3720: invokestatic max : (II)I
    //   3723: invokestatic max : (II)I
    //   3726: iload #7
    //   3728: iadd
    //   3729: invokestatic max : (II)I
    //   3732: istore #7
    //   3734: iload #12
    //   3736: istore #9
    //   3738: iload #7
    //   3740: istore #12
    //   3742: iload #6
    //   3744: istore #7
    //   3746: iload #8
    //   3748: ifne -> 3762
    //   3751: iload #22
    //   3753: ldc_w 1073741824
    //   3756: if_icmpeq -> 3762
    //   3759: goto -> 3766
    //   3762: iload #12
    //   3764: istore #7
    //   3766: aload_0
    //   3767: invokevirtual getPaddingTop : ()I
    //   3770: istore #6
    //   3772: aload_0
    //   3773: ldc_w -16777216
    //   3776: iload #5
    //   3778: iand
    //   3779: iload #9
    //   3781: ior
    //   3782: aload_0
    //   3783: invokevirtual getPaddingBottom : ()I
    //   3786: iload #6
    //   3788: iadd
    //   3789: iload #7
    //   3791: iadd
    //   3792: aload_0
    //   3793: invokevirtual getSuggestedMinimumHeight : ()I
    //   3796: invokestatic max : (II)I
    //   3799: iload_2
    //   3800: iload #5
    //   3802: bipush #16
    //   3804: ishl
    //   3805: invokestatic resolveSizeAndState : (III)I
    //   3808: invokevirtual setMeasuredDimension : (II)V
    //   3811: iload #10
    //   3813: ifeq -> 3914
    //   3816: aload_0
    //   3817: invokevirtual getMeasuredHeight : ()I
    //   3820: ldc_w 1073741824
    //   3823: invokestatic makeMeasureSpec : (II)I
    //   3826: istore #5
    //   3828: iconst_0
    //   3829: istore_2
    //   3830: iload_2
    //   3831: iload #11
    //   3833: if_icmpge -> 3914
    //   3836: aload_0
    //   3837: iload_2
    //   3838: invokevirtual getChildAt : (I)Landroid/view/View;
    //   3841: astore #26
    //   3843: aload #26
    //   3845: invokevirtual getVisibility : ()I
    //   3848: bipush #8
    //   3850: if_icmpeq -> 3907
    //   3853: aload #26
    //   3855: invokevirtual getLayoutParams : ()Landroid/view/ViewGroup$LayoutParams;
    //   3858: checkcast androidx/appcompat/widget/j0$a
    //   3861: astore #27
    //   3863: aload #27
    //   3865: getfield height : I
    //   3868: iconst_m1
    //   3869: if_icmpne -> 3907
    //   3872: aload #27
    //   3874: getfield width : I
    //   3877: istore #6
    //   3879: aload #27
    //   3881: aload #26
    //   3883: invokevirtual getMeasuredWidth : ()I
    //   3886: putfield width : I
    //   3889: aload_0
    //   3890: aload #26
    //   3892: iload_1
    //   3893: iconst_0
    //   3894: iload #5
    //   3896: iconst_0
    //   3897: invokevirtual measureChildWithMargins : (Landroid/view/View;IIII)V
    //   3900: aload #27
    //   3902: iload #6
    //   3904: putfield width : I
    //   3907: iload_2
    //   3908: iconst_1
    //   3909: iadd
    //   3910: istore_2
    //   3911: goto -> 3830
    //   3914: return
  }
  
  public void setBaselineAligned(boolean paramBoolean) {
    this.h = paramBoolean;
  }
  
  public void setBaselineAlignedChildIndex(int paramInt) {
    if (paramInt >= 0 && paramInt < getChildCount()) {
      this.i = paramInt;
      return;
    } 
    StringBuilder stringBuilder = c.a("base aligned child index out of range (0, ");
    stringBuilder.append(getChildCount());
    stringBuilder.append(")");
    throw new IllegalArgumentException(stringBuilder.toString());
  }
  
  public void setDividerDrawable(Drawable paramDrawable) {
    if (paramDrawable == this.r)
      return; 
    this.r = paramDrawable;
    boolean bool = false;
    if (paramDrawable != null) {
      this.s = paramDrawable.getIntrinsicWidth();
      this.t = paramDrawable.getIntrinsicHeight();
    } else {
      this.s = 0;
      this.t = 0;
    } 
    if (paramDrawable == null)
      bool = true; 
    setWillNotDraw(bool);
    requestLayout();
  }
  
  public void setDividerPadding(int paramInt) {
    this.v = paramInt;
  }
  
  public void setGravity(int paramInt) {
    if (this.l != paramInt) {
      int i = paramInt;
      if ((0x800007 & paramInt) == 0)
        i = paramInt | 0x800003; 
      paramInt = i;
      if ((i & 0x70) == 0)
        paramInt = i | 0x30; 
      this.l = paramInt;
      requestLayout();
    } 
  }
  
  public void setHorizontalGravity(int paramInt) {
    paramInt &= 0x800007;
    int i = this.l;
    if ((0x800007 & i) != paramInt) {
      this.l = paramInt | 0xFF7FFFF8 & i;
      requestLayout();
    } 
  }
  
  public void setMeasureWithLargestChildEnabled(boolean paramBoolean) {
    this.o = paramBoolean;
  }
  
  public void setOrientation(int paramInt) {
    if (this.k != paramInt) {
      this.k = paramInt;
      requestLayout();
    } 
  }
  
  public void setShowDividers(int paramInt) {
    if (paramInt != this.u)
      requestLayout(); 
    this.u = paramInt;
  }
  
  public void setVerticalGravity(int paramInt) {
    paramInt &= 0x70;
    int i = this.l;
    if ((i & 0x70) != paramInt) {
      this.l = paramInt | i & 0xFFFFFF8F;
      requestLayout();
    } 
  }
  
  public void setWeightSum(float paramFloat) {
    this.n = Math.max(0.0F, paramFloat);
  }
  
  public boolean shouldDelayChildPressedState() {
    return false;
  }
  
  public static class a extends ViewGroup.MarginLayoutParams {
    public float a;
    
    public int b = -1;
    
    public a(int param1Int1, int param1Int2) {
      super(param1Int1, param1Int2);
      this.a = 0.0F;
    }
    
    public a(Context param1Context, AttributeSet param1AttributeSet) {
      super(param1Context, param1AttributeSet);
      TypedArray typedArray = param1Context.obtainStyledAttributes(param1AttributeSet, b.u);
      this.a = typedArray.getFloat(3, 0.0F);
      this.b = typedArray.getInt(0, -1);
      typedArray.recycle();
    }
    
    public a(ViewGroup.LayoutParams param1LayoutParams) {
      super(param1LayoutParams);
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Luxury Logo Maker_ Logo Design-dex2jar.jar!\androidx\appcompat\widget\j0.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */