package androidx.appcompat.widget;

import android.annotation.SuppressLint;
import android.content.Context;
import android.content.res.ColorStateList;
import android.content.res.TypedArray;
import android.graphics.PorterDuff;
import android.graphics.Typeface;
import android.graphics.drawable.Drawable;
import android.os.Build;
import android.support.v4.media.c;
import android.util.AttributeSet;
import android.util.DisplayMetrics;
import android.util.TypedValue;
import android.widget.TextView;
import c0.e;
import com.bumptech.glide.manager.b;
import java.lang.ref.WeakReference;
import java.util.Arrays;

public class z {
  public final TextView a;
  
  public x0 b;
  
  public x0 c;
  
  public x0 d;
  
  public x0 e;
  
  public x0 f;
  
  public x0 g;
  
  public x0 h;
  
  public final b0 i;
  
  public int j = 0;
  
  public int k = -1;
  
  public Typeface l;
  
  public boolean m;
  
  public z(TextView paramTextView) {
    this.a = paramTextView;
    this.i = new b0(paramTextView);
  }
  
  public static x0 c(Context paramContext, j paramj, int paramInt) {
    ColorStateList colorStateList = paramj.d(paramContext, paramInt);
    if (colorStateList != null) {
      x0 x01 = new x0();
      x01.d = true;
      x01.a = colorStateList;
      return x01;
    } 
    return null;
  }
  
  public final void a(Drawable paramDrawable, x0 paramx0) {
    if (paramDrawable != null && paramx0 != null)
      j.f(paramDrawable, paramx0, this.a.getDrawableState()); 
  }
  
  public void b() {
    if (this.b != null || this.c != null || this.d != null || this.e != null) {
      Drawable[] arrayOfDrawable = this.a.getCompoundDrawables();
      a(arrayOfDrawable[0], this.b);
      a(arrayOfDrawable[1], this.c);
      a(arrayOfDrawable[2], this.d);
      a(arrayOfDrawable[3], this.e);
    } 
    if (this.f != null || this.g != null) {
      Drawable[] arrayOfDrawable = this.a.getCompoundDrawablesRelative();
      a(arrayOfDrawable[0], this.f);
      a(arrayOfDrawable[2], this.g);
    } 
  }
  
  public boolean d() {
    b0 b01 = this.i;
    return (b01.i() && b01.a != 0);
  }
  
  @SuppressLint({"NewApi"})
  public void e(AttributeSet paramAttributeSet, int paramInt) {
    // Byte code:
    //   0: aload_0
    //   1: getfield a : Landroid/widget/TextView;
    //   4: invokevirtual getContext : ()Landroid/content/Context;
    //   7: astore #22
    //   9: invokestatic a : ()Landroidx/appcompat/widget/j;
    //   12: astore #21
    //   14: getstatic com/bumptech/glide/manager/b.o : [I
    //   17: astore #13
    //   19: aload #22
    //   21: aload_1
    //   22: aload #13
    //   24: iload_2
    //   25: iconst_0
    //   26: invokestatic q : (Landroid/content/Context;Landroid/util/AttributeSet;[III)Landroidx/appcompat/widget/z0;
    //   29: astore #14
    //   31: aload_0
    //   32: getfield a : Landroid/widget/TextView;
    //   35: astore #15
    //   37: aload #15
    //   39: aload #15
    //   41: invokevirtual getContext : ()Landroid/content/Context;
    //   44: aload #13
    //   46: aload_1
    //   47: aload #14
    //   49: getfield b : Landroid/content/res/TypedArray;
    //   52: iload_2
    //   53: iconst_0
    //   54: invokestatic r : (Landroid/view/View;Landroid/content/Context;[ILandroid/util/AttributeSet;Landroid/content/res/TypedArray;II)V
    //   57: aload #14
    //   59: iconst_0
    //   60: iconst_m1
    //   61: invokevirtual l : (II)I
    //   64: istore #7
    //   66: aload #14
    //   68: iconst_3
    //   69: invokevirtual o : (I)Z
    //   72: ifeq -> 93
    //   75: aload_0
    //   76: aload #22
    //   78: aload #21
    //   80: aload #14
    //   82: iconst_3
    //   83: iconst_0
    //   84: invokevirtual l : (II)I
    //   87: invokestatic c : (Landroid/content/Context;Landroidx/appcompat/widget/j;I)Landroidx/appcompat/widget/x0;
    //   90: putfield b : Landroidx/appcompat/widget/x0;
    //   93: aload #14
    //   95: iconst_1
    //   96: invokevirtual o : (I)Z
    //   99: ifeq -> 120
    //   102: aload_0
    //   103: aload #22
    //   105: aload #21
    //   107: aload #14
    //   109: iconst_1
    //   110: iconst_0
    //   111: invokevirtual l : (II)I
    //   114: invokestatic c : (Landroid/content/Context;Landroidx/appcompat/widget/j;I)Landroidx/appcompat/widget/x0;
    //   117: putfield c : Landroidx/appcompat/widget/x0;
    //   120: aload #14
    //   122: iconst_4
    //   123: invokevirtual o : (I)Z
    //   126: ifeq -> 147
    //   129: aload_0
    //   130: aload #22
    //   132: aload #21
    //   134: aload #14
    //   136: iconst_4
    //   137: iconst_0
    //   138: invokevirtual l : (II)I
    //   141: invokestatic c : (Landroid/content/Context;Landroidx/appcompat/widget/j;I)Landroidx/appcompat/widget/x0;
    //   144: putfield d : Landroidx/appcompat/widget/x0;
    //   147: aload #14
    //   149: iconst_2
    //   150: invokevirtual o : (I)Z
    //   153: ifeq -> 174
    //   156: aload_0
    //   157: aload #22
    //   159: aload #21
    //   161: aload #14
    //   163: iconst_2
    //   164: iconst_0
    //   165: invokevirtual l : (II)I
    //   168: invokestatic c : (Landroid/content/Context;Landroidx/appcompat/widget/j;I)Landroidx/appcompat/widget/x0;
    //   171: putfield e : Landroidx/appcompat/widget/x0;
    //   174: getstatic android/os/Build$VERSION.SDK_INT : I
    //   177: istore #9
    //   179: aload #14
    //   181: iconst_5
    //   182: invokevirtual o : (I)Z
    //   185: ifeq -> 206
    //   188: aload_0
    //   189: aload #22
    //   191: aload #21
    //   193: aload #14
    //   195: iconst_5
    //   196: iconst_0
    //   197: invokevirtual l : (II)I
    //   200: invokestatic c : (Landroid/content/Context;Landroidx/appcompat/widget/j;I)Landroidx/appcompat/widget/x0;
    //   203: putfield f : Landroidx/appcompat/widget/x0;
    //   206: aload #14
    //   208: bipush #6
    //   210: invokevirtual o : (I)Z
    //   213: ifeq -> 235
    //   216: aload_0
    //   217: aload #22
    //   219: aload #21
    //   221: aload #14
    //   223: bipush #6
    //   225: iconst_0
    //   226: invokevirtual l : (II)I
    //   229: invokestatic c : (Landroid/content/Context;Landroidx/appcompat/widget/j;I)Landroidx/appcompat/widget/x0;
    //   232: putfield g : Landroidx/appcompat/widget/x0;
    //   235: aload #14
    //   237: getfield b : Landroid/content/res/TypedArray;
    //   240: invokevirtual recycle : ()V
    //   243: aload_0
    //   244: getfield a : Landroid/widget/TextView;
    //   247: invokevirtual getTransformationMethod : ()Landroid/text/method/TransformationMethod;
    //   250: instanceof android/text/method/PasswordTransformationMethod
    //   253: istore #12
    //   255: iload #7
    //   257: iconst_m1
    //   258: if_icmpeq -> 506
    //   261: aload #22
    //   263: iload #7
    //   265: getstatic com/bumptech/glide/manager/b.D : [I
    //   268: invokevirtual obtainStyledAttributes : (I[I)Landroid/content/res/TypedArray;
    //   271: astore #19
    //   273: new androidx/appcompat/widget/z0
    //   276: dup
    //   277: aload #22
    //   279: aload #19
    //   281: invokespecial <init> : (Landroid/content/Context;Landroid/content/res/TypedArray;)V
    //   284: astore #20
    //   286: iload #12
    //   288: ifne -> 317
    //   291: aload #20
    //   293: bipush #14
    //   295: invokevirtual o : (I)Z
    //   298: ifeq -> 317
    //   301: aload #20
    //   303: bipush #14
    //   305: iconst_0
    //   306: invokevirtual a : (IZ)Z
    //   309: istore #10
    //   311: iconst_1
    //   312: istore #7
    //   314: goto -> 323
    //   317: iconst_0
    //   318: istore #10
    //   320: iconst_0
    //   321: istore #7
    //   323: aload_0
    //   324: aload #22
    //   326: aload #20
    //   328: invokevirtual l : (Landroid/content/Context;Landroidx/appcompat/widget/z0;)V
    //   331: iload #9
    //   333: bipush #23
    //   335: if_icmpge -> 420
    //   338: aload #20
    //   340: iconst_3
    //   341: invokevirtual o : (I)Z
    //   344: ifeq -> 358
    //   347: aload #20
    //   349: iconst_3
    //   350: invokevirtual c : (I)Landroid/content/res/ColorStateList;
    //   353: astore #13
    //   355: goto -> 361
    //   358: aconst_null
    //   359: astore #13
    //   361: aload #20
    //   363: iconst_4
    //   364: invokevirtual o : (I)Z
    //   367: ifeq -> 381
    //   370: aload #20
    //   372: iconst_4
    //   373: invokevirtual c : (I)Landroid/content/res/ColorStateList;
    //   376: astore #14
    //   378: goto -> 384
    //   381: aconst_null
    //   382: astore #14
    //   384: aload #13
    //   386: astore #16
    //   388: aload #14
    //   390: astore #15
    //   392: aload #20
    //   394: iconst_5
    //   395: invokevirtual o : (I)Z
    //   398: ifeq -> 426
    //   401: aload #20
    //   403: iconst_5
    //   404: invokevirtual c : (I)Landroid/content/res/ColorStateList;
    //   407: astore #17
    //   409: aload #13
    //   411: astore #16
    //   413: aload #14
    //   415: astore #13
    //   417: goto -> 433
    //   420: aconst_null
    //   421: astore #16
    //   423: aconst_null
    //   424: astore #15
    //   426: aconst_null
    //   427: astore #17
    //   429: aload #15
    //   431: astore #13
    //   433: aload #20
    //   435: bipush #15
    //   437: invokevirtual o : (I)Z
    //   440: ifeq -> 455
    //   443: aload #20
    //   445: bipush #15
    //   447: invokevirtual m : (I)Ljava/lang/String;
    //   450: astore #18
    //   452: goto -> 458
    //   455: aconst_null
    //   456: astore #18
    //   458: iload #9
    //   460: bipush #26
    //   462: if_icmplt -> 487
    //   465: aload #20
    //   467: bipush #13
    //   469: invokevirtual o : (I)Z
    //   472: ifeq -> 487
    //   475: aload #20
    //   477: bipush #13
    //   479: invokevirtual m : (I)Ljava/lang/String;
    //   482: astore #15
    //   484: goto -> 490
    //   487: aconst_null
    //   488: astore #15
    //   490: aload #19
    //   492: invokevirtual recycle : ()V
    //   495: aload #16
    //   497: astore #14
    //   499: aload #18
    //   501: astore #16
    //   503: goto -> 527
    //   506: iconst_0
    //   507: istore #10
    //   509: aconst_null
    //   510: astore #15
    //   512: iconst_0
    //   513: istore #7
    //   515: aconst_null
    //   516: astore #14
    //   518: aconst_null
    //   519: astore #13
    //   521: aconst_null
    //   522: astore #17
    //   524: aconst_null
    //   525: astore #16
    //   527: aload #22
    //   529: aload_1
    //   530: getstatic com/bumptech/glide/manager/b.D : [I
    //   533: iload_2
    //   534: iconst_0
    //   535: invokevirtual obtainStyledAttributes : (Landroid/util/AttributeSet;[III)Landroid/content/res/TypedArray;
    //   538: astore #24
    //   540: new androidx/appcompat/widget/z0
    //   543: dup
    //   544: aload #22
    //   546: aload #24
    //   548: invokespecial <init> : (Landroid/content/Context;Landroid/content/res/TypedArray;)V
    //   551: astore #23
    //   553: iload #10
    //   555: istore #11
    //   557: iload #7
    //   559: istore #8
    //   561: iload #12
    //   563: ifne -> 597
    //   566: iload #10
    //   568: istore #11
    //   570: iload #7
    //   572: istore #8
    //   574: aload #23
    //   576: bipush #14
    //   578: invokevirtual o : (I)Z
    //   581: ifeq -> 597
    //   584: aload #23
    //   586: bipush #14
    //   588: iconst_0
    //   589: invokevirtual a : (IZ)Z
    //   592: istore #11
    //   594: iconst_1
    //   595: istore #8
    //   597: aload #14
    //   599: astore #18
    //   601: aload #13
    //   603: astore #19
    //   605: aload #17
    //   607: astore #20
    //   609: iload #9
    //   611: bipush #23
    //   613: if_icmpge -> 687
    //   616: aload #23
    //   618: iconst_3
    //   619: invokevirtual o : (I)Z
    //   622: ifeq -> 633
    //   625: aload #23
    //   627: iconst_3
    //   628: invokevirtual c : (I)Landroid/content/res/ColorStateList;
    //   631: astore #14
    //   633: aload #23
    //   635: iconst_4
    //   636: invokevirtual o : (I)Z
    //   639: ifeq -> 650
    //   642: aload #23
    //   644: iconst_4
    //   645: invokevirtual c : (I)Landroid/content/res/ColorStateList;
    //   648: astore #13
    //   650: aload #14
    //   652: astore #18
    //   654: aload #13
    //   656: astore #19
    //   658: aload #17
    //   660: astore #20
    //   662: aload #23
    //   664: iconst_5
    //   665: invokevirtual o : (I)Z
    //   668: ifeq -> 687
    //   671: aload #23
    //   673: iconst_5
    //   674: invokevirtual c : (I)Landroid/content/res/ColorStateList;
    //   677: astore #20
    //   679: aload #13
    //   681: astore #19
    //   683: aload #14
    //   685: astore #18
    //   687: aload #23
    //   689: bipush #15
    //   691: invokevirtual o : (I)Z
    //   694: ifeq -> 706
    //   697: aload #23
    //   699: bipush #15
    //   701: invokevirtual m : (I)Ljava/lang/String;
    //   704: astore #16
    //   706: iload #9
    //   708: bipush #26
    //   710: if_icmplt -> 735
    //   713: aload #23
    //   715: bipush #13
    //   717: invokevirtual o : (I)Z
    //   720: ifeq -> 735
    //   723: aload #23
    //   725: bipush #13
    //   727: invokevirtual m : (I)Ljava/lang/String;
    //   730: astore #15
    //   732: goto -> 735
    //   735: iload #9
    //   737: bipush #28
    //   739: if_icmplt -> 773
    //   742: aload #23
    //   744: iconst_0
    //   745: invokevirtual o : (I)Z
    //   748: ifeq -> 773
    //   751: aload #23
    //   753: iconst_0
    //   754: iconst_m1
    //   755: invokevirtual f : (II)I
    //   758: ifne -> 773
    //   761: aload_0
    //   762: getfield a : Landroid/widget/TextView;
    //   765: iconst_0
    //   766: fconst_0
    //   767: invokevirtual setTextSize : (IF)V
    //   770: goto -> 773
    //   773: aload #21
    //   775: astore #13
    //   777: aload_0
    //   778: aload #22
    //   780: aload #23
    //   782: invokevirtual l : (Landroid/content/Context;Landroidx/appcompat/widget/z0;)V
    //   785: aload #24
    //   787: invokevirtual recycle : ()V
    //   790: aload #18
    //   792: ifnull -> 804
    //   795: aload_0
    //   796: getfield a : Landroid/widget/TextView;
    //   799: aload #18
    //   801: invokevirtual setTextColor : (Landroid/content/res/ColorStateList;)V
    //   804: aload #19
    //   806: ifnull -> 818
    //   809: aload_0
    //   810: getfield a : Landroid/widget/TextView;
    //   813: aload #19
    //   815: invokevirtual setHintTextColor : (Landroid/content/res/ColorStateList;)V
    //   818: aload #20
    //   820: ifnull -> 832
    //   823: aload_0
    //   824: getfield a : Landroid/widget/TextView;
    //   827: aload #20
    //   829: invokevirtual setLinkTextColor : (Landroid/content/res/ColorStateList;)V
    //   832: iload #12
    //   834: ifne -> 851
    //   837: iload #8
    //   839: ifeq -> 851
    //   842: aload_0
    //   843: getfield a : Landroid/widget/TextView;
    //   846: iload #11
    //   848: invokevirtual setAllCaps : (Z)V
    //   851: aload_0
    //   852: getfield l : Landroid/graphics/Typeface;
    //   855: astore #14
    //   857: aload #14
    //   859: ifnull -> 895
    //   862: aload_0
    //   863: getfield k : I
    //   866: iconst_m1
    //   867: if_icmpne -> 886
    //   870: aload_0
    //   871: getfield a : Landroid/widget/TextView;
    //   874: aload #14
    //   876: aload_0
    //   877: getfield j : I
    //   880: invokevirtual setTypeface : (Landroid/graphics/Typeface;I)V
    //   883: goto -> 895
    //   886: aload_0
    //   887: getfield a : Landroid/widget/TextView;
    //   890: aload #14
    //   892: invokevirtual setTypeface : (Landroid/graphics/Typeface;)V
    //   895: aload #15
    //   897: ifnull -> 910
    //   900: aload_0
    //   901: getfield a : Landroid/widget/TextView;
    //   904: aload #15
    //   906: invokevirtual setFontVariationSettings : (Ljava/lang/String;)Z
    //   909: pop
    //   910: aload #16
    //   912: ifnull -> 967
    //   915: iload #9
    //   917: bipush #24
    //   919: if_icmplt -> 937
    //   922: aload_0
    //   923: getfield a : Landroid/widget/TextView;
    //   926: aload #16
    //   928: invokestatic forLanguageTags : (Ljava/lang/String;)Landroid/os/LocaleList;
    //   931: invokevirtual setTextLocales : (Landroid/os/LocaleList;)V
    //   934: goto -> 967
    //   937: aload #16
    //   939: iconst_0
    //   940: aload #16
    //   942: bipush #44
    //   944: invokevirtual indexOf : (I)I
    //   947: invokevirtual substring : (II)Ljava/lang/String;
    //   950: astore #14
    //   952: aload_0
    //   953: getfield a : Landroid/widget/TextView;
    //   956: aload #14
    //   958: invokestatic forLanguageTag : (Ljava/lang/String;)Ljava/util/Locale;
    //   961: invokevirtual setTextLocale : (Ljava/util/Locale;)V
    //   964: goto -> 967
    //   967: aload_0
    //   968: getfield i : Landroidx/appcompat/widget/b0;
    //   971: astore #14
    //   973: aload #14
    //   975: getfield j : Landroid/content/Context;
    //   978: astore #15
    //   980: getstatic com/bumptech/glide/manager/b.p : [I
    //   983: astore #16
    //   985: aload #15
    //   987: aload_1
    //   988: aload #16
    //   990: iload_2
    //   991: iconst_0
    //   992: invokevirtual obtainStyledAttributes : (Landroid/util/AttributeSet;[III)Landroid/content/res/TypedArray;
    //   995: astore #15
    //   997: aload #14
    //   999: getfield i : Landroid/widget/TextView;
    //   1002: astore #17
    //   1004: aload #17
    //   1006: aload #17
    //   1008: invokevirtual getContext : ()Landroid/content/Context;
    //   1011: aload #16
    //   1013: aload_1
    //   1014: aload #15
    //   1016: iload_2
    //   1017: iconst_0
    //   1018: invokestatic r : (Landroid/view/View;Landroid/content/Context;[ILandroid/util/AttributeSet;Landroid/content/res/TypedArray;II)V
    //   1021: aload #15
    //   1023: iconst_5
    //   1024: invokevirtual hasValue : (I)Z
    //   1027: ifeq -> 1042
    //   1030: aload #14
    //   1032: aload #15
    //   1034: iconst_5
    //   1035: iconst_0
    //   1036: invokevirtual getInt : (II)I
    //   1039: putfield a : I
    //   1042: aload #15
    //   1044: iconst_4
    //   1045: invokevirtual hasValue : (I)Z
    //   1048: ifeq -> 1063
    //   1051: aload #15
    //   1053: iconst_4
    //   1054: ldc -1.0
    //   1056: invokevirtual getDimension : (IF)F
    //   1059: fstore_3
    //   1060: goto -> 1066
    //   1063: ldc -1.0
    //   1065: fstore_3
    //   1066: aload #15
    //   1068: iconst_2
    //   1069: invokevirtual hasValue : (I)Z
    //   1072: ifeq -> 1088
    //   1075: aload #15
    //   1077: iconst_2
    //   1078: ldc -1.0
    //   1080: invokevirtual getDimension : (IF)F
    //   1083: fstore #4
    //   1085: goto -> 1092
    //   1088: ldc -1.0
    //   1090: fstore #4
    //   1092: aload #15
    //   1094: iconst_1
    //   1095: invokevirtual hasValue : (I)Z
    //   1098: ifeq -> 1114
    //   1101: aload #15
    //   1103: iconst_1
    //   1104: ldc -1.0
    //   1106: invokevirtual getDimension : (IF)F
    //   1109: fstore #5
    //   1111: goto -> 1118
    //   1114: ldc -1.0
    //   1116: fstore #5
    //   1118: aload #15
    //   1120: iconst_3
    //   1121: invokevirtual hasValue : (I)Z
    //   1124: ifeq -> 1217
    //   1127: aload #15
    //   1129: iconst_3
    //   1130: iconst_0
    //   1131: invokevirtual getResourceId : (II)I
    //   1134: istore_2
    //   1135: iload_2
    //   1136: ifle -> 1217
    //   1139: aload #15
    //   1141: invokevirtual getResources : ()Landroid/content/res/Resources;
    //   1144: iload_2
    //   1145: invokevirtual obtainTypedArray : (I)Landroid/content/res/TypedArray;
    //   1148: astore #16
    //   1150: aload #16
    //   1152: invokevirtual length : ()I
    //   1155: istore #7
    //   1157: iload #7
    //   1159: newarray int
    //   1161: astore #17
    //   1163: iload #7
    //   1165: ifle -> 1212
    //   1168: iconst_0
    //   1169: istore_2
    //   1170: iload_2
    //   1171: iload #7
    //   1173: if_icmpge -> 1194
    //   1176: aload #17
    //   1178: iload_2
    //   1179: aload #16
    //   1181: iload_2
    //   1182: iconst_m1
    //   1183: invokevirtual getDimensionPixelSize : (II)I
    //   1186: iastore
    //   1187: iload_2
    //   1188: iconst_1
    //   1189: iadd
    //   1190: istore_2
    //   1191: goto -> 1170
    //   1194: aload #14
    //   1196: aload #14
    //   1198: aload #17
    //   1200: invokevirtual b : ([I)[I
    //   1203: putfield f : [I
    //   1206: aload #14
    //   1208: invokevirtual h : ()Z
    //   1211: pop
    //   1212: aload #16
    //   1214: invokevirtual recycle : ()V
    //   1217: aload #15
    //   1219: invokevirtual recycle : ()V
    //   1222: aload #14
    //   1224: invokevirtual i : ()Z
    //   1227: ifeq -> 1339
    //   1230: aload #14
    //   1232: getfield a : I
    //   1235: iconst_1
    //   1236: if_icmpne -> 1345
    //   1239: aload #14
    //   1241: getfield g : Z
    //   1244: ifne -> 1330
    //   1247: aload #14
    //   1249: getfield j : Landroid/content/Context;
    //   1252: invokevirtual getResources : ()Landroid/content/res/Resources;
    //   1255: invokevirtual getDisplayMetrics : ()Landroid/util/DisplayMetrics;
    //   1258: astore #15
    //   1260: fload #4
    //   1262: fstore #6
    //   1264: fload #4
    //   1266: ldc -1.0
    //   1268: fcmpl
    //   1269: ifne -> 1283
    //   1272: iconst_2
    //   1273: ldc_w 12.0
    //   1276: aload #15
    //   1278: invokestatic applyDimension : (IFLandroid/util/DisplayMetrics;)F
    //   1281: fstore #6
    //   1283: fload #5
    //   1285: fstore #4
    //   1287: fload #5
    //   1289: ldc -1.0
    //   1291: fcmpl
    //   1292: ifne -> 1306
    //   1295: iconst_2
    //   1296: ldc_w 112.0
    //   1299: aload #15
    //   1301: invokestatic applyDimension : (IFLandroid/util/DisplayMetrics;)F
    //   1304: fstore #4
    //   1306: fload_3
    //   1307: fstore #5
    //   1309: fload_3
    //   1310: ldc -1.0
    //   1312: fcmpl
    //   1313: ifne -> 1319
    //   1316: fconst_1
    //   1317: fstore #5
    //   1319: aload #14
    //   1321: fload #6
    //   1323: fload #4
    //   1325: fload #5
    //   1327: invokevirtual j : (FFF)V
    //   1330: aload #14
    //   1332: invokevirtual g : ()Z
    //   1335: pop
    //   1336: goto -> 1345
    //   1339: aload #14
    //   1341: iconst_0
    //   1342: putfield a : I
    //   1345: getstatic m0/b.g : Z
    //   1348: ifeq -> 1443
    //   1351: aload_0
    //   1352: getfield i : Landroidx/appcompat/widget/b0;
    //   1355: astore #14
    //   1357: aload #14
    //   1359: getfield a : I
    //   1362: ifeq -> 1443
    //   1365: aload #14
    //   1367: getfield f : [I
    //   1370: astore #14
    //   1372: aload #14
    //   1374: arraylength
    //   1375: ifle -> 1443
    //   1378: aload_0
    //   1379: getfield a : Landroid/widget/TextView;
    //   1382: invokevirtual getAutoSizeStepGranularity : ()I
    //   1385: i2f
    //   1386: ldc -1.0
    //   1388: fcmpl
    //   1389: ifeq -> 1433
    //   1392: aload_0
    //   1393: getfield a : Landroid/widget/TextView;
    //   1396: aload_0
    //   1397: getfield i : Landroidx/appcompat/widget/b0;
    //   1400: getfield d : F
    //   1403: invokestatic round : (F)I
    //   1406: aload_0
    //   1407: getfield i : Landroidx/appcompat/widget/b0;
    //   1410: getfield e : F
    //   1413: invokestatic round : (F)I
    //   1416: aload_0
    //   1417: getfield i : Landroidx/appcompat/widget/b0;
    //   1420: getfield c : F
    //   1423: invokestatic round : (F)I
    //   1426: iconst_0
    //   1427: invokevirtual setAutoSizeTextTypeUniformWithConfiguration : (IIII)V
    //   1430: goto -> 1443
    //   1433: aload_0
    //   1434: getfield a : Landroid/widget/TextView;
    //   1437: aload #14
    //   1439: iconst_0
    //   1440: invokevirtual setAutoSizeTextTypeUniformWithPresetSizes : ([II)V
    //   1443: aload #22
    //   1445: aload_1
    //   1446: getstatic com/bumptech/glide/manager/b.p : [I
    //   1449: invokevirtual obtainStyledAttributes : (Landroid/util/AttributeSet;[I)Landroid/content/res/TypedArray;
    //   1452: astore #18
    //   1454: aload #18
    //   1456: bipush #8
    //   1458: iconst_m1
    //   1459: invokevirtual getResourceId : (II)I
    //   1462: istore_2
    //   1463: iload_2
    //   1464: iconst_m1
    //   1465: if_icmpeq -> 1481
    //   1468: aload #13
    //   1470: aload #22
    //   1472: iload_2
    //   1473: invokevirtual b : (Landroid/content/Context;I)Landroid/graphics/drawable/Drawable;
    //   1476: astore #14
    //   1478: goto -> 1484
    //   1481: aconst_null
    //   1482: astore #14
    //   1484: aload #13
    //   1486: astore #16
    //   1488: aload #18
    //   1490: bipush #13
    //   1492: iconst_m1
    //   1493: invokevirtual getResourceId : (II)I
    //   1496: istore_2
    //   1497: iload_2
    //   1498: iconst_m1
    //   1499: if_icmpeq -> 1515
    //   1502: aload #16
    //   1504: aload #22
    //   1506: iload_2
    //   1507: invokevirtual b : (Landroid/content/Context;I)Landroid/graphics/drawable/Drawable;
    //   1510: astore #13
    //   1512: goto -> 1518
    //   1515: aconst_null
    //   1516: astore #13
    //   1518: aload #18
    //   1520: bipush #9
    //   1522: iconst_m1
    //   1523: invokevirtual getResourceId : (II)I
    //   1526: istore_2
    //   1527: iload_2
    //   1528: iconst_m1
    //   1529: if_icmpeq -> 1545
    //   1532: aload #16
    //   1534: aload #22
    //   1536: iload_2
    //   1537: invokevirtual b : (Landroid/content/Context;I)Landroid/graphics/drawable/Drawable;
    //   1540: astore #15
    //   1542: goto -> 1548
    //   1545: aconst_null
    //   1546: astore #15
    //   1548: aload #18
    //   1550: bipush #6
    //   1552: iconst_m1
    //   1553: invokevirtual getResourceId : (II)I
    //   1556: istore_2
    //   1557: iload_2
    //   1558: iconst_m1
    //   1559: if_icmpeq -> 1574
    //   1562: aload #16
    //   1564: aload #22
    //   1566: iload_2
    //   1567: invokevirtual b : (Landroid/content/Context;I)Landroid/graphics/drawable/Drawable;
    //   1570: astore_1
    //   1571: goto -> 1576
    //   1574: aconst_null
    //   1575: astore_1
    //   1576: aload #18
    //   1578: bipush #10
    //   1580: iconst_m1
    //   1581: invokevirtual getResourceId : (II)I
    //   1584: istore_2
    //   1585: iload_2
    //   1586: iconst_m1
    //   1587: if_icmpeq -> 1603
    //   1590: aload #16
    //   1592: aload #22
    //   1594: iload_2
    //   1595: invokevirtual b : (Landroid/content/Context;I)Landroid/graphics/drawable/Drawable;
    //   1598: astore #17
    //   1600: goto -> 1606
    //   1603: aconst_null
    //   1604: astore #17
    //   1606: aload #18
    //   1608: bipush #7
    //   1610: iconst_m1
    //   1611: invokevirtual getResourceId : (II)I
    //   1614: istore_2
    //   1615: iload_2
    //   1616: iconst_m1
    //   1617: if_icmpeq -> 1633
    //   1620: aload #16
    //   1622: aload #22
    //   1624: iload_2
    //   1625: invokevirtual b : (Landroid/content/Context;I)Landroid/graphics/drawable/Drawable;
    //   1628: astore #16
    //   1630: goto -> 1636
    //   1633: aconst_null
    //   1634: astore #16
    //   1636: aload #17
    //   1638: ifnonnull -> 1837
    //   1641: aload #16
    //   1643: ifnull -> 1649
    //   1646: goto -> 1837
    //   1649: aload #14
    //   1651: ifnonnull -> 1668
    //   1654: aload #13
    //   1656: ifnonnull -> 1668
    //   1659: aload #15
    //   1661: ifnonnull -> 1668
    //   1664: aload_1
    //   1665: ifnull -> 1918
    //   1668: aload_0
    //   1669: getfield a : Landroid/widget/TextView;
    //   1672: invokevirtual getCompoundDrawablesRelative : ()[Landroid/graphics/drawable/Drawable;
    //   1675: astore #16
    //   1677: aload #16
    //   1679: iconst_0
    //   1680: aaload
    //   1681: ifnonnull -> 1778
    //   1684: aload #16
    //   1686: iconst_2
    //   1687: aaload
    //   1688: ifnull -> 1694
    //   1691: goto -> 1778
    //   1694: aload_0
    //   1695: getfield a : Landroid/widget/TextView;
    //   1698: invokevirtual getCompoundDrawables : ()[Landroid/graphics/drawable/Drawable;
    //   1701: astore #17
    //   1703: aload_0
    //   1704: getfield a : Landroid/widget/TextView;
    //   1707: astore #16
    //   1709: aload #14
    //   1711: ifnull -> 1717
    //   1714: goto -> 1723
    //   1717: aload #17
    //   1719: iconst_0
    //   1720: aaload
    //   1721: astore #14
    //   1723: aload #13
    //   1725: ifnull -> 1731
    //   1728: goto -> 1737
    //   1731: aload #17
    //   1733: iconst_1
    //   1734: aaload
    //   1735: astore #13
    //   1737: aload #15
    //   1739: ifnull -> 1745
    //   1742: goto -> 1751
    //   1745: aload #17
    //   1747: iconst_2
    //   1748: aaload
    //   1749: astore #15
    //   1751: aload_1
    //   1752: ifnull -> 1758
    //   1755: goto -> 1763
    //   1758: aload #17
    //   1760: iconst_3
    //   1761: aaload
    //   1762: astore_1
    //   1763: aload #16
    //   1765: aload #14
    //   1767: aload #13
    //   1769: aload #15
    //   1771: aload_1
    //   1772: invokevirtual setCompoundDrawablesWithIntrinsicBounds : (Landroid/graphics/drawable/Drawable;Landroid/graphics/drawable/Drawable;Landroid/graphics/drawable/Drawable;Landroid/graphics/drawable/Drawable;)V
    //   1775: goto -> 1918
    //   1778: aload_0
    //   1779: getfield a : Landroid/widget/TextView;
    //   1782: astore #14
    //   1784: aload #16
    //   1786: iconst_0
    //   1787: aaload
    //   1788: astore #15
    //   1790: aload #13
    //   1792: ifnull -> 1798
    //   1795: goto -> 1804
    //   1798: aload #16
    //   1800: iconst_1
    //   1801: aaload
    //   1802: astore #13
    //   1804: aload #16
    //   1806: iconst_2
    //   1807: aaload
    //   1808: astore #17
    //   1810: aload_1
    //   1811: ifnull -> 1817
    //   1814: goto -> 1822
    //   1817: aload #16
    //   1819: iconst_3
    //   1820: aaload
    //   1821: astore_1
    //   1822: aload #14
    //   1824: aload #15
    //   1826: aload #13
    //   1828: aload #17
    //   1830: aload_1
    //   1831: invokevirtual setCompoundDrawablesRelativeWithIntrinsicBounds : (Landroid/graphics/drawable/Drawable;Landroid/graphics/drawable/Drawable;Landroid/graphics/drawable/Drawable;Landroid/graphics/drawable/Drawable;)V
    //   1834: goto -> 1918
    //   1837: aload_0
    //   1838: getfield a : Landroid/widget/TextView;
    //   1841: invokevirtual getCompoundDrawablesRelative : ()[Landroid/graphics/drawable/Drawable;
    //   1844: astore #15
    //   1846: aload_0
    //   1847: getfield a : Landroid/widget/TextView;
    //   1850: astore #14
    //   1852: aload #17
    //   1854: ifnull -> 1860
    //   1857: goto -> 1866
    //   1860: aload #15
    //   1862: iconst_0
    //   1863: aaload
    //   1864: astore #17
    //   1866: aload #13
    //   1868: ifnull -> 1874
    //   1871: goto -> 1880
    //   1874: aload #15
    //   1876: iconst_1
    //   1877: aaload
    //   1878: astore #13
    //   1880: aload #16
    //   1882: ifnull -> 1888
    //   1885: goto -> 1894
    //   1888: aload #15
    //   1890: iconst_2
    //   1891: aaload
    //   1892: astore #16
    //   1894: aload_1
    //   1895: ifnull -> 1901
    //   1898: goto -> 1906
    //   1901: aload #15
    //   1903: iconst_3
    //   1904: aaload
    //   1905: astore_1
    //   1906: aload #14
    //   1908: aload #17
    //   1910: aload #13
    //   1912: aload #16
    //   1914: aload_1
    //   1915: invokevirtual setCompoundDrawablesRelativeWithIntrinsicBounds : (Landroid/graphics/drawable/Drawable;Landroid/graphics/drawable/Drawable;Landroid/graphics/drawable/Drawable;Landroid/graphics/drawable/Drawable;)V
    //   1918: aload #18
    //   1920: bipush #11
    //   1922: invokevirtual hasValue : (I)Z
    //   1925: ifeq -> 2021
    //   1928: aload #18
    //   1930: bipush #11
    //   1932: invokevirtual hasValue : (I)Z
    //   1935: ifeq -> 1965
    //   1938: aload #18
    //   1940: bipush #11
    //   1942: iconst_0
    //   1943: invokevirtual getResourceId : (II)I
    //   1946: istore_2
    //   1947: iload_2
    //   1948: ifeq -> 1965
    //   1951: aload #22
    //   1953: iload_2
    //   1954: invokestatic a : (Landroid/content/Context;I)Landroid/content/res/ColorStateList;
    //   1957: astore_1
    //   1958: aload_1
    //   1959: ifnull -> 1965
    //   1962: goto -> 1973
    //   1965: aload #18
    //   1967: bipush #11
    //   1969: invokevirtual getColorStateList : (I)Landroid/content/res/ColorStateList;
    //   1972: astore_1
    //   1973: aload_0
    //   1974: getfield a : Landroid/widget/TextView;
    //   1977: astore #13
    //   1979: aload #13
    //   1981: invokestatic requireNonNull : (Ljava/lang/Object;)Ljava/lang/Object;
    //   1984: pop
    //   1985: getstatic android/os/Build$VERSION.SDK_INT : I
    //   1988: bipush #24
    //   1990: if_icmplt -> 2002
    //   1993: aload #13
    //   1995: aload_1
    //   1996: invokevirtual setCompoundDrawableTintList : (Landroid/content/res/ColorStateList;)V
    //   1999: goto -> 2021
    //   2002: aload #13
    //   2004: instanceof m0/g
    //   2007: ifeq -> 2021
    //   2010: aload #13
    //   2012: checkcast m0/g
    //   2015: aload_1
    //   2016: invokeinterface setSupportCompoundDrawablesTintList : (Landroid/content/res/ColorStateList;)V
    //   2021: aload #18
    //   2023: bipush #12
    //   2025: invokevirtual hasValue : (I)Z
    //   2028: ifeq -> 2092
    //   2031: aload #18
    //   2033: bipush #12
    //   2035: iconst_m1
    //   2036: invokevirtual getInt : (II)I
    //   2039: aconst_null
    //   2040: invokestatic c : (ILandroid/graphics/PorterDuff$Mode;)Landroid/graphics/PorterDuff$Mode;
    //   2043: astore_1
    //   2044: aload_0
    //   2045: getfield a : Landroid/widget/TextView;
    //   2048: astore #13
    //   2050: aload #13
    //   2052: invokestatic requireNonNull : (Ljava/lang/Object;)Ljava/lang/Object;
    //   2055: pop
    //   2056: getstatic android/os/Build$VERSION.SDK_INT : I
    //   2059: bipush #24
    //   2061: if_icmplt -> 2073
    //   2064: aload #13
    //   2066: aload_1
    //   2067: invokevirtual setCompoundDrawableTintMode : (Landroid/graphics/PorterDuff$Mode;)V
    //   2070: goto -> 2092
    //   2073: aload #13
    //   2075: instanceof m0/g
    //   2078: ifeq -> 2092
    //   2081: aload #13
    //   2083: checkcast m0/g
    //   2086: aload_1
    //   2087: invokeinterface setSupportCompoundDrawablesTintMode : (Landroid/graphics/PorterDuff$Mode;)V
    //   2092: aload #18
    //   2094: bipush #14
    //   2096: iconst_m1
    //   2097: invokevirtual getDimensionPixelSize : (II)I
    //   2100: istore_2
    //   2101: aload #18
    //   2103: bipush #17
    //   2105: iconst_m1
    //   2106: invokevirtual getDimensionPixelSize : (II)I
    //   2109: istore #7
    //   2111: aload #18
    //   2113: bipush #18
    //   2115: iconst_m1
    //   2116: invokevirtual getDimensionPixelSize : (II)I
    //   2119: istore #8
    //   2121: aload #18
    //   2123: invokevirtual recycle : ()V
    //   2126: iload_2
    //   2127: iconst_m1
    //   2128: if_icmpeq -> 2139
    //   2131: aload_0
    //   2132: getfield a : Landroid/widget/TextView;
    //   2135: iload_2
    //   2136: invokestatic b : (Landroid/widget/TextView;I)V
    //   2139: iload #7
    //   2141: iconst_m1
    //   2142: if_icmpeq -> 2154
    //   2145: aload_0
    //   2146: getfield a : Landroid/widget/TextView;
    //   2149: iload #7
    //   2151: invokestatic c : (Landroid/widget/TextView;I)V
    //   2154: iload #8
    //   2156: iconst_m1
    //   2157: if_icmpeq -> 2169
    //   2160: aload_0
    //   2161: getfield a : Landroid/widget/TextView;
    //   2164: iload #8
    //   2166: invokestatic d : (Landroid/widget/TextView;I)V
    //   2169: return
  }
  
  public void f(Context paramContext, int paramInt) {
    TypedArray typedArray = paramContext.obtainStyledAttributes(paramInt, b.D);
    z0 z0 = new z0(paramContext, typedArray);
    if (z0.o(14)) {
      boolean bool = z0.a(14, false);
      this.a.setAllCaps(bool);
    } 
    paramInt = Build.VERSION.SDK_INT;
    if (paramInt < 23 && z0.o(3)) {
      ColorStateList colorStateList = z0.c(3);
      if (colorStateList != null)
        this.a.setTextColor(colorStateList); 
    } 
    if (z0.o(0) && z0.f(0, -1) == 0)
      this.a.setTextSize(0, 0.0F); 
    l(paramContext, z0);
    if (paramInt >= 26 && z0.o(13)) {
      String str = z0.m(13);
      if (str != null)
        this.a.setFontVariationSettings(str); 
    } 
    typedArray.recycle();
    Typeface typeface = this.l;
    if (typeface != null)
      this.a.setTypeface(typeface, this.j); 
  }
  
  public void g(int paramInt1, int paramInt2, int paramInt3, int paramInt4) {
    b0 b01 = this.i;
    if (b01.i()) {
      DisplayMetrics displayMetrics = b01.j.getResources().getDisplayMetrics();
      b01.j(TypedValue.applyDimension(paramInt4, paramInt1, displayMetrics), TypedValue.applyDimension(paramInt4, paramInt2, displayMetrics), TypedValue.applyDimension(paramInt4, paramInt3, displayMetrics));
      if (b01.g())
        b01.a(); 
    } 
  }
  
  public void h(int[] paramArrayOfint, int paramInt) {
    b0 b01 = this.i;
    if (b01.i()) {
      int j = paramArrayOfint.length;
      int i = 0;
      if (j > 0) {
        int[] arrayOfInt1;
        int[] arrayOfInt2 = new int[j];
        if (paramInt == 0) {
          arrayOfInt1 = Arrays.copyOf(paramArrayOfint, j);
        } else {
          DisplayMetrics displayMetrics = b01.j.getResources().getDisplayMetrics();
          while (true) {
            arrayOfInt1 = arrayOfInt2;
            if (i < j) {
              arrayOfInt2[i] = Math.round(TypedValue.applyDimension(paramInt, paramArrayOfint[i], displayMetrics));
              i++;
              continue;
            } 
            break;
          } 
        } 
        b01.f = b01.b(arrayOfInt1);
        if (!b01.h()) {
          StringBuilder stringBuilder = c.a("None of the preset sizes is valid: ");
          stringBuilder.append(Arrays.toString(paramArrayOfint));
          throw new IllegalArgumentException(stringBuilder.toString());
        } 
      } else {
        b01.g = false;
      } 
      if (b01.g())
        b01.a(); 
    } 
  }
  
  public void i(int paramInt) {
    b0 b01 = this.i;
    if (b01.i())
      if (paramInt != 0) {
        if (paramInt == 1) {
          DisplayMetrics displayMetrics = b01.j.getResources().getDisplayMetrics();
          b01.j(TypedValue.applyDimension(2, 12.0F, displayMetrics), TypedValue.applyDimension(2, 112.0F, displayMetrics), 1.0F);
          if (b01.g()) {
            b01.a();
            return;
          } 
        } else {
          throw new IllegalArgumentException(y.a("Unknown auto-size text type: ", paramInt));
        } 
      } else {
        b01.a = 0;
        b01.d = -1.0F;
        b01.e = -1.0F;
        b01.c = -1.0F;
        b01.f = new int[0];
        b01.b = false;
      }  
  }
  
  public void j(ColorStateList paramColorStateList) {
    boolean bool;
    if (this.h == null)
      this.h = new x0(); 
    x0 x01 = this.h;
    x01.a = paramColorStateList;
    if (paramColorStateList != null) {
      bool = true;
    } else {
      bool = false;
    } 
    x01.d = bool;
    this.b = x01;
    this.c = x01;
    this.d = x01;
    this.e = x01;
    this.f = x01;
    this.g = x01;
  }
  
  public void k(PorterDuff.Mode paramMode) {
    boolean bool;
    if (this.h == null)
      this.h = new x0(); 
    x0 x01 = this.h;
    x01.b = paramMode;
    if (paramMode != null) {
      bool = true;
    } else {
      bool = false;
    } 
    x01.c = bool;
    this.b = x01;
    this.c = x01;
    this.d = x01;
    this.e = x01;
    this.f = x01;
    this.g = x01;
  }
  
  public final void l(Context paramContext, z0 paramz0) {
    this.j = paramz0.j(2, this.j);
    int j = Build.VERSION.SDK_INT;
    boolean bool = false;
    if (j >= 28) {
      int k = paramz0.j(11, -1);
      this.k = k;
      if (k != -1)
        this.j = this.j & 0x2 | 0x0; 
    } 
    int i = 10;
    if (paramz0.o(10) || paramz0.o(12)) {
      this.l = null;
      if (paramz0.o(12))
        i = 12; 
      int k = this.k;
      int m = this.j;
      if (!paramContext.isRestricted()) {
        a a = new a(this, k, m, new WeakReference<TextView>(this.a));
        try {
          boolean bool1;
          Typeface typeface = paramz0.i(i, this.j, a);
          if (typeface != null) {
            Typeface typeface1 = typeface;
            if (j >= 28) {
              typeface1 = typeface;
              if (this.k != -1) {
                typeface1 = Typeface.create(typeface, 0);
                j = this.k;
                if ((this.j & 0x2) != 0) {
                  bool1 = true;
                } else {
                  bool1 = false;
                } 
                typeface1 = Typeface.create(typeface1, j, bool1);
              } 
            } 
            this.l = typeface1;
          } 
          if (this.l == null) {
            bool1 = true;
          } else {
            bool1 = false;
          } 
          this.m = bool1;
        } catch (UnsupportedOperationException|android.content.res.Resources.NotFoundException unsupportedOperationException) {}
      } 
      if (this.l == null) {
        String str = paramz0.m(i);
        if (str != null) {
          Typeface typeface;
          if (Build.VERSION.SDK_INT >= 28 && this.k != -1) {
            typeface = Typeface.create(str, 0);
            i = this.k;
            boolean bool1 = bool;
            if ((this.j & 0x2) != 0)
              bool1 = true; 
            typeface = Typeface.create(typeface, i, bool1);
          } else {
            typeface = Typeface.create((String)typeface, this.j);
          } 
          this.l = typeface;
        } 
      } 
      return;
    } 
    if (paramz0.o(1)) {
      Typeface typeface;
      this.m = false;
      i = paramz0.j(1, 1);
      if (i != 1) {
        if (i != 2) {
          if (i != 3)
            return; 
          typeface = Typeface.MONOSPACE;
        } else {
          typeface = Typeface.SERIF;
        } 
      } else {
        typeface = Typeface.SANS_SERIF;
      } 
      this.l = typeface;
    } 
  }
  
  public class a extends e.c {
    public a(z this$0, int param1Int1, int param1Int2, WeakReference param1WeakReference) {}
    
    public void d(int param1Int) {}
    
    public void e(Typeface param1Typeface) {
      Typeface typeface = param1Typeface;
      if (Build.VERSION.SDK_INT >= 28) {
        int i = this.a;
        typeface = param1Typeface;
        if (i != -1) {
          boolean bool;
          if ((this.b & 0x2) != 0) {
            bool = true;
          } else {
            bool = false;
          } 
          typeface = Typeface.create(param1Typeface, i, bool);
        } 
      } 
      z z1 = this.d;
      WeakReference<TextView> weakReference = this.c;
      if (z1.m) {
        z1.l = typeface;
        TextView textView = weakReference.get();
        if (textView != null)
          textView.setTypeface(typeface, z1.j); 
      } 
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Luxury Logo Maker_ Logo Design-dex2jar.jar!\androidx\appcompat\widget\z.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */