package androidx.appcompat.widget;

import android.content.Context;
import android.content.res.Configuration;
import android.content.res.TypedArray;
import android.util.AttributeSet;
import android.util.TypedValue;
import android.view.ContextThemeWrapper;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import androidx.appcompat.view.menu.e;
import com.bumptech.glide.manager.b;
import k0.l;
import k0.n;
import k0.o;

public abstract class a extends ViewGroup {
  public final a h = new a(this);
  
  public final Context i;
  
  public ActionMenuView j;
  
  public c k;
  
  public int l;
  
  public n m;
  
  public boolean n;
  
  public boolean o;
  
  public a(Context paramContext, AttributeSet paramAttributeSet) {
    this(paramContext, paramAttributeSet, 0);
  }
  
  public a(Context paramContext, AttributeSet paramAttributeSet, int paramInt) {
    super(paramContext, paramAttributeSet, paramInt);
    TypedValue typedValue = new TypedValue();
    if (paramContext.getTheme().resolveAttribute(2130968578, typedValue, true) && typedValue.resourceId != 0) {
      this.i = (Context)new ContextThemeWrapper(paramContext, typedValue.resourceId);
      return;
    } 
    this.i = paramContext;
  }
  
  public int c(View paramView, int paramInt1, int paramInt2, int paramInt3) {
    paramView.measure(View.MeasureSpec.makeMeasureSpec(paramInt1, -2147483648), paramInt2);
    return Math.max(0, paramInt1 - paramView.getMeasuredWidth() - paramInt3);
  }
  
  public int d(View paramView, int paramInt1, int paramInt2, int paramInt3, boolean paramBoolean) {
    int i = paramView.getMeasuredWidth();
    int j = paramView.getMeasuredHeight();
    paramInt2 = (paramInt3 - j) / 2 + paramInt2;
    if (paramBoolean) {
      paramView.layout(paramInt1 - i, paramInt2, paramInt1, j + paramInt2);
    } else {
      paramView.layout(paramInt1, paramInt2, paramInt1 + i, j + paramInt2);
    } 
    paramInt1 = i;
    if (paramBoolean)
      paramInt1 = -i; 
    return paramInt1;
  }
  
  public n e(int paramInt, long paramLong) {
    n n1 = this.m;
    if (n1 != null)
      n1.b(); 
    if (paramInt == 0) {
      if (getVisibility() != 0)
        setAlpha(0.0F); 
      n1 = l.b((View)this);
      n1.a(1.0F);
      n1.c(paramLong);
      a a2 = this.h;
      a2.c.m = n1;
      a2.b = paramInt;
      View view1 = n1.a.get();
      if (view1 != null)
        n1.e(view1, a2); 
      return n1;
    } 
    n1 = l.b((View)this);
    n1.a(0.0F);
    n1.c(paramLong);
    a a1 = this.h;
    a1.c.m = n1;
    a1.b = paramInt;
    View view = n1.a.get();
    if (view != null)
      n1.e(view, a1); 
    return n1;
  }
  
  public int getAnimatedVisibility() {
    return (this.m != null) ? this.h.b : getVisibility();
  }
  
  public int getContentHeight() {
    return this.l;
  }
  
  public void onConfigurationChanged(Configuration paramConfiguration) {
    super.onConfigurationChanged(paramConfiguration);
    TypedArray typedArray = getContext().obtainStyledAttributes(null, b.h, 2130968581, 0);
    setContentHeight(typedArray.getLayoutDimension(13, 0));
    typedArray.recycle();
    c c1 = this.k;
    if (c1 != null) {
      Configuration configuration = c1.i.getResources().getConfiguration();
      int i = configuration.screenWidthDp;
      int j = configuration.screenHeightDp;
      if (configuration.smallestScreenWidthDp > 600 || i > 600 || (i > 960 && j > 720) || (i > 720 && j > 960)) {
        i = 5;
      } else if (i >= 500 || (i > 640 && j > 480) || (i > 480 && j > 640)) {
        i = 4;
      } else if (i >= 360) {
        i = 3;
      } else {
        i = 2;
      } 
      c1.w = i;
      e e = c1.j;
      if (e != null)
        e.p(true); 
    } 
  }
  
  public boolean onHoverEvent(MotionEvent paramMotionEvent) {
    int i = paramMotionEvent.getActionMasked();
    if (i == 9)
      this.o = false; 
    if (!this.o) {
      boolean bool = super.onHoverEvent(paramMotionEvent);
      if (i == 9 && !bool)
        this.o = true; 
    } 
    if (i == 10 || i == 3)
      this.o = false; 
    return true;
  }
  
  public boolean onTouchEvent(MotionEvent paramMotionEvent) {
    int i = paramMotionEvent.getActionMasked();
    if (i == 0)
      this.n = false; 
    if (!this.n) {
      boolean bool = super.onTouchEvent(paramMotionEvent);
      if (i == 0 && !bool)
        this.n = true; 
    } 
    if (i == 1 || i == 3)
      this.n = false; 
    return true;
  }
  
  public void setContentHeight(int paramInt) {
    this.l = paramInt;
    requestLayout();
  }
  
  public void setVisibility(int paramInt) {
    if (paramInt != getVisibility()) {
      n n1 = this.m;
      if (n1 != null)
        n1.b(); 
      super.setVisibility(paramInt);
    } 
  }
  
  public class a implements o {
    public boolean a = false;
    
    public int b;
    
    public a(a this$0) {}
    
    public void a(View param1View) {
      this.a = true;
    }
    
    public void b(View param1View) {
      if (this.a)
        return; 
      a a1 = this.c;
      a1.m = null;
      a.b(a1, this.b);
    }
    
    public void c(View param1View) {
      a.a(this.c, 0);
      this.a = false;
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Luxury Logo Maker_ Logo Design-dex2jar.jar!\androidx\appcompat\widget\a.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */