package androidx.appcompat.widget;

import android.app.Activity;
import android.content.Context;
import android.content.ContextWrapper;
import android.content.res.Resources;
import android.graphics.Rect;
import android.os.Build;
import android.util.DisplayMetrics;
import android.util.Log;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewConfiguration;
import android.view.ViewGroup;
import android.view.WindowManager;
import android.view.accessibility.AccessibilityManager;
import java.lang.reflect.Method;
import java.util.WeakHashMap;
import k0.l;
import k0.m;

public class d1 implements View.OnLongClickListener, View.OnHoverListener, View.OnAttachStateChangeListener {
  public static d1 q;
  
  public static d1 r;
  
  public final View h;
  
  public final CharSequence i;
  
  public final int j;
  
  public final Runnable k;
  
  public final Runnable l;
  
  public int m;
  
  public int n;
  
  public e1 o;
  
  public boolean p;
  
  public d1(View paramView, CharSequence paramCharSequence) {
    int i;
    this.k = new a(this);
    this.l = new b(this);
    this.h = paramView;
    this.i = paramCharSequence;
    ViewConfiguration viewConfiguration = ViewConfiguration.get(paramView.getContext());
    Method method = m.a;
    if (Build.VERSION.SDK_INT >= 28) {
      i = viewConfiguration.getScaledHoverSlop();
    } else {
      i = viewConfiguration.getScaledTouchSlop() / 2;
    } 
    this.j = i;
    a();
    paramView.setOnLongClickListener(this);
    paramView.setOnHoverListener(this);
  }
  
  public static void c(d1 paramd1) {
    d1 d11 = q;
    if (d11 != null)
      d11.h.removeCallbacks(d11.k); 
    q = paramd1;
    if (paramd1 != null)
      paramd1.h.postDelayed(paramd1.k, ViewConfiguration.getLongPressTimeout()); 
  }
  
  public final void a() {
    this.m = Integer.MAX_VALUE;
    this.n = Integer.MAX_VALUE;
  }
  
  public void b() {
    if (r == this) {
      r = null;
      e1 e11 = this.o;
      if (e11 != null) {
        e11.a();
        this.o = null;
        a();
        this.h.removeOnAttachStateChangeListener(this);
      } else {
        Log.e("TooltipCompatHandler", "sActiveHandler.mPopup == null");
      } 
    } 
    if (q == this)
      c(null); 
    this.h.removeCallbacks(this.l);
  }
  
  public void d(boolean paramBoolean) {
    int i;
    long l;
    View view1;
    View view2 = this.h;
    WeakHashMap weakHashMap = l.a;
    if (!view2.isAttachedToWindow())
      return; 
    c(null);
    d1 d11 = r;
    if (d11 != null)
      d11.b(); 
    r = this;
    this.p = paramBoolean;
    e1 e11 = new e1(this.h.getContext());
    this.o = e11;
    View view4 = this.h;
    int j = this.m;
    int k = this.n;
    paramBoolean = this.p;
    CharSequence charSequence = this.i;
    if (e11.b.getParent() != null) {
      i = 1;
    } else {
      i = 0;
    } 
    if (i)
      e11.a(); 
    e11.c.setText(charSequence);
    WindowManager.LayoutParams layoutParams1 = e11.d;
    layoutParams1.token = view4.getApplicationWindowToken();
    int m = e11.a.getResources().getDimensionPixelOffset(2131166360);
    if (view4.getWidth() >= m) {
      i = j;
    } else {
      i = view4.getWidth() / 2;
    } 
    if (view4.getHeight() >= m) {
      m = e11.a.getResources().getDimensionPixelOffset(2131166359);
      j = k + m;
      k -= m;
    } else {
      j = view4.getHeight();
      k = 0;
    } 
    layoutParams1.gravity = 49;
    Resources resources = e11.a.getResources();
    if (paramBoolean) {
      m = 2131166363;
    } else {
      m = 2131166362;
    } 
    int n = resources.getDimensionPixelOffset(m);
    View view3 = view4.getRootView();
    ViewGroup.LayoutParams layoutParams = view3.getLayoutParams();
    if (layoutParams instanceof WindowManager.LayoutParams && ((WindowManager.LayoutParams)layoutParams).type == 2) {
      view1 = view3;
    } else {
      Context context = view4.getContext();
      while (true) {
        view1 = view3;
        if (context instanceof ContextWrapper) {
          if (context instanceof Activity) {
            view1 = ((Activity)context).getWindow().getDecorView();
            break;
          } 
          context = ((ContextWrapper)context).getBaseContext();
          continue;
        } 
        break;
      } 
    } 
    if (view1 == null) {
      Log.e("TooltipPopup", "Cannot find app view");
    } else {
      view1.getWindowVisibleDisplayFrame(e11.e);
      Rect rect = e11.e;
      if (rect.left < 0 && rect.top < 0) {
        Resources resources1 = e11.a.getResources();
        m = resources1.getIdentifier("status_bar_height", "dimen", "android");
        if (m != 0) {
          m = resources1.getDimensionPixelSize(m);
        } else {
          m = 0;
        } 
        DisplayMetrics displayMetrics = resources1.getDisplayMetrics();
        e11.e.set(0, m, displayMetrics.widthPixels, displayMetrics.heightPixels);
      } 
      view1.getLocationOnScreen(e11.g);
      view4.getLocationOnScreen(e11.f);
      int[] arrayOfInt2 = e11.f;
      m = arrayOfInt2[0];
      int[] arrayOfInt3 = e11.g;
      arrayOfInt2[0] = m - arrayOfInt3[0];
      arrayOfInt2[1] = arrayOfInt2[1] - arrayOfInt3[1];
      layoutParams1.x = arrayOfInt2[0] + i - view1.getWidth() / 2;
      i = View.MeasureSpec.makeMeasureSpec(0, 0);
      e11.b.measure(i, i);
      i = e11.b.getMeasuredHeight();
      int[] arrayOfInt1 = e11.f;
      k = arrayOfInt1[1] + k - n - i;
      j = arrayOfInt1[1] + j + n;
      if (paramBoolean ? (k >= 0) : (i + j > e11.e.height())) {
        layoutParams1.y = k;
      } else {
        layoutParams1.y = j;
      } 
    } 
    ((WindowManager)e11.a.getSystemService("window")).addView(e11.b, (ViewGroup.LayoutParams)e11.d);
    this.h.addOnAttachStateChangeListener(this);
    if (this.p) {
      l = 2500L;
    } else {
      if ((this.h.getWindowSystemUiVisibility() & 0x1) == 1) {
        l = 3000L;
      } else {
        l = 15000L;
      } 
      l -= ViewConfiguration.getLongPressTimeout();
    } 
    this.h.removeCallbacks(this.l);
    this.h.postDelayed(this.l, l);
  }
  
  public boolean onHover(View paramView, MotionEvent paramMotionEvent) {
    if (this.o != null && this.p)
      return false; 
    AccessibilityManager accessibilityManager = (AccessibilityManager)this.h.getContext().getSystemService("accessibility");
    if (accessibilityManager.isEnabled() && accessibilityManager.isTouchExplorationEnabled())
      return false; 
    int i = paramMotionEvent.getAction();
    if (i != 7) {
      if (i != 10)
        return false; 
      a();
      b();
      return false;
    } 
    if (this.h.isEnabled() && this.o == null) {
      i = (int)paramMotionEvent.getX();
      int j = (int)paramMotionEvent.getY();
      if (Math.abs(i - this.m) <= this.j && Math.abs(j - this.n) <= this.j) {
        i = 0;
      } else {
        this.m = i;
        this.n = j;
        i = 1;
      } 
      if (i != 0)
        c(this); 
    } 
    return false;
  }
  
  public boolean onLongClick(View paramView) {
    this.m = paramView.getWidth() / 2;
    this.n = paramView.getHeight() / 2;
    d(true);
    return true;
  }
  
  public void onViewAttachedToWindow(View paramView) {}
  
  public void onViewDetachedFromWindow(View paramView) {
    b();
  }
  
  public class a implements Runnable {
    public a(d1 this$0) {}
    
    public void run() {
      this.h.d(false);
    }
  }
  
  public class b implements Runnable {
    public b(d1 this$0) {}
    
    public void run() {
      this.h.b();
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Luxury Logo Maker_ Logo Design-dex2jar.jar!\androidx\appcompat\widget\d1.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */