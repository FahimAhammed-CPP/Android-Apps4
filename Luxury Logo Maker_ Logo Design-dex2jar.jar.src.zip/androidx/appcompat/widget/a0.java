package androidx.appcompat.widget;

import android.annotation.SuppressLint;
import android.content.Context;
import android.content.res.ColorStateList;
import android.graphics.PorterDuff;
import android.graphics.Typeface;
import android.graphics.drawable.Drawable;
import android.os.Build;
import android.text.TextDirectionHeuristic;
import android.text.TextDirectionHeuristics;
import android.util.AttributeSet;
import android.view.ActionMode;
import android.view.View;
import android.view.inputmethod.EditorInfo;
import android.view.inputmethod.InputConnection;
import android.view.textclassifier.TextClassifier;
import android.widget.TextView;
import b4.a;
import d0.e;
import d0.k;
import g.a;
import i0.b;
import java.util.concurrent.Future;
import m0.b;
import m0.f;
import m0.g;

public class a0 extends TextView implements g, b {
  public final e h;
  
  public final z i;
  
  public final x j;
  
  public Future<b> k;
  
  public a0(Context paramContext, AttributeSet paramAttributeSet) {
    this(paramContext, paramAttributeSet, 16842884);
  }
  
  public a0(Context paramContext, AttributeSet paramAttributeSet, int paramInt) {
    super(paramContext, paramAttributeSet, paramInt);
    u0.a((View)this, getContext());
    e e1 = new e((View)this);
    this.h = e1;
    e1.d(paramAttributeSet, paramInt);
    z z1 = new z(this);
    this.i = z1;
    z1.e(paramAttributeSet, paramInt);
    z1.b();
    this.j = new x(this);
  }
  
  public void drawableStateChanged() {
    super.drawableStateChanged();
    e e1 = this.h;
    if (e1 != null)
      e1.a(); 
    z z1 = this.i;
    if (z1 != null)
      z1.b(); 
  }
  
  public int getAutoSizeMaxTextSize() {
    if (b.g)
      return super.getAutoSizeMaxTextSize(); 
    z z1 = this.i;
    return (z1 != null) ? Math.round(z1.i.e) : -1;
  }
  
  public int getAutoSizeMinTextSize() {
    if (b.g)
      return super.getAutoSizeMinTextSize(); 
    z z1 = this.i;
    return (z1 != null) ? Math.round(z1.i.d) : -1;
  }
  
  public int getAutoSizeStepGranularity() {
    if (b.g)
      return super.getAutoSizeStepGranularity(); 
    z z1 = this.i;
    return (z1 != null) ? Math.round(z1.i.c) : -1;
  }
  
  public int[] getAutoSizeTextAvailableSizes() {
    if (b.g)
      return super.getAutoSizeTextAvailableSizes(); 
    z z1 = this.i;
    return (z1 != null) ? z1.i.f : new int[0];
  }
  
  @SuppressLint({"WrongConstant"})
  public int getAutoSizeTextType() {
    boolean bool1 = b.g;
    boolean bool = false;
    if (bool1) {
      if (super.getAutoSizeTextType() == 1)
        bool = true; 
      return bool;
    } 
    z z1 = this.i;
    return (z1 != null) ? z1.i.a : 0;
  }
  
  public int getFirstBaselineToTopHeight() {
    return getPaddingTop() - (getPaint().getFontMetricsInt()).top;
  }
  
  public int getLastBaselineToBottomHeight() {
    return getPaddingBottom() + (getPaint().getFontMetricsInt()).bottom;
  }
  
  public ColorStateList getSupportBackgroundTintList() {
    e e1 = this.h;
    return (e1 != null) ? e1.b() : null;
  }
  
  public PorterDuff.Mode getSupportBackgroundTintMode() {
    e e1 = this.h;
    return (e1 != null) ? e1.c() : null;
  }
  
  public ColorStateList getSupportCompoundDrawablesTintList() {
    x0 x0 = this.i.h;
    return (x0 != null) ? x0.a : null;
  }
  
  public PorterDuff.Mode getSupportCompoundDrawablesTintMode() {
    x0 x0 = this.i.h;
    return (x0 != null) ? x0.b : null;
  }
  
  public CharSequence getText() {
    Future<b> future = this.k;
    if (future != null)
      try {
        this.k = null;
        f.e(this, future.get());
      } catch (InterruptedException|java.util.concurrent.ExecutionException interruptedException) {} 
    return super.getText();
  }
  
  public TextClassifier getTextClassifier() {
    if (Build.VERSION.SDK_INT < 28) {
      x x1 = this.j;
      if (x1 != null)
        return x1.a(); 
    } 
    return super.getTextClassifier();
  }
  
  public b.a getTextMetricsParamsCompat() {
    return f.a(this);
  }
  
  public InputConnection onCreateInputConnection(EditorInfo paramEditorInfo) {
    InputConnection inputConnection = super.onCreateInputConnection(paramEditorInfo);
    a.c(inputConnection, paramEditorInfo, (View)this);
    return inputConnection;
  }
  
  public void onLayout(boolean paramBoolean, int paramInt1, int paramInt2, int paramInt3, int paramInt4) {
    super.onLayout(paramBoolean, paramInt1, paramInt2, paramInt3, paramInt4);
    z z1 = this.i;
    if (z1 != null && !b.g)
      z1.i.a(); 
  }
  
  public void onMeasure(int paramInt1, int paramInt2) {
    Future<b> future = this.k;
    if (future != null)
      try {
        this.k = null;
        f.e(this, future.get());
      } catch (InterruptedException|java.util.concurrent.ExecutionException interruptedException) {} 
    super.onMeasure(paramInt1, paramInt2);
  }
  
  public void onTextChanged(CharSequence paramCharSequence, int paramInt1, int paramInt2, int paramInt3) {
    super.onTextChanged(paramCharSequence, paramInt1, paramInt2, paramInt3);
    z z1 = this.i;
    if (z1 != null && !b.g && z1.d())
      this.i.i.a(); 
  }
  
  public void setAutoSizeTextTypeUniformWithConfiguration(int paramInt1, int paramInt2, int paramInt3, int paramInt4) {
    if (b.g) {
      super.setAutoSizeTextTypeUniformWithConfiguration(paramInt1, paramInt2, paramInt3, paramInt4);
      return;
    } 
    z z1 = this.i;
    if (z1 != null)
      z1.g(paramInt1, paramInt2, paramInt3, paramInt4); 
  }
  
  public void setAutoSizeTextTypeUniformWithPresetSizes(int[] paramArrayOfint, int paramInt) {
    if (b.g) {
      super.setAutoSizeTextTypeUniformWithPresetSizes(paramArrayOfint, paramInt);
      return;
    } 
    z z1 = this.i;
    if (z1 != null)
      z1.h(paramArrayOfint, paramInt); 
  }
  
  public void setAutoSizeTextTypeWithDefaults(int paramInt) {
    if (b.g) {
      super.setAutoSizeTextTypeWithDefaults(paramInt);
      return;
    } 
    z z1 = this.i;
    if (z1 != null)
      z1.i(paramInt); 
  }
  
  public void setBackgroundDrawable(Drawable paramDrawable) {
    super.setBackgroundDrawable(paramDrawable);
    e e1 = this.h;
    if (e1 != null)
      e1.e(); 
  }
  
  public void setBackgroundResource(int paramInt) {
    super.setBackgroundResource(paramInt);
    e e1 = this.h;
    if (e1 != null)
      e1.f(paramInt); 
  }
  
  public void setCompoundDrawables(Drawable paramDrawable1, Drawable paramDrawable2, Drawable paramDrawable3, Drawable paramDrawable4) {
    super.setCompoundDrawables(paramDrawable1, paramDrawable2, paramDrawable3, paramDrawable4);
    z z1 = this.i;
    if (z1 != null)
      z1.b(); 
  }
  
  public void setCompoundDrawablesRelative(Drawable paramDrawable1, Drawable paramDrawable2, Drawable paramDrawable3, Drawable paramDrawable4) {
    super.setCompoundDrawablesRelative(paramDrawable1, paramDrawable2, paramDrawable3, paramDrawable4);
    z z1 = this.i;
    if (z1 != null)
      z1.b(); 
  }
  
  public void setCompoundDrawablesRelativeWithIntrinsicBounds(int paramInt1, int paramInt2, int paramInt3, int paramInt4) {
    Drawable drawable1;
    Drawable drawable2;
    Drawable drawable3;
    Context context = getContext();
    Drawable drawable4 = null;
    if (paramInt1 != 0) {
      drawable1 = a.b(context, paramInt1);
    } else {
      drawable1 = null;
    } 
    if (paramInt2 != 0) {
      drawable2 = a.b(context, paramInt2);
    } else {
      drawable2 = null;
    } 
    if (paramInt3 != 0) {
      drawable3 = a.b(context, paramInt3);
    } else {
      drawable3 = null;
    } 
    if (paramInt4 != 0)
      drawable4 = a.b(context, paramInt4); 
    setCompoundDrawablesRelativeWithIntrinsicBounds(drawable1, drawable2, drawable3, drawable4);
    z z1 = this.i;
    if (z1 != null)
      z1.b(); 
  }
  
  public void setCompoundDrawablesRelativeWithIntrinsicBounds(Drawable paramDrawable1, Drawable paramDrawable2, Drawable paramDrawable3, Drawable paramDrawable4) {
    super.setCompoundDrawablesRelativeWithIntrinsicBounds(paramDrawable1, paramDrawable2, paramDrawable3, paramDrawable4);
    z z1 = this.i;
    if (z1 != null)
      z1.b(); 
  }
  
  public void setCompoundDrawablesWithIntrinsicBounds(int paramInt1, int paramInt2, int paramInt3, int paramInt4) {
    Drawable drawable1;
    Drawable drawable2;
    Drawable drawable3;
    Context context = getContext();
    Drawable drawable4 = null;
    if (paramInt1 != 0) {
      drawable1 = a.b(context, paramInt1);
    } else {
      drawable1 = null;
    } 
    if (paramInt2 != 0) {
      drawable2 = a.b(context, paramInt2);
    } else {
      drawable2 = null;
    } 
    if (paramInt3 != 0) {
      drawable3 = a.b(context, paramInt3);
    } else {
      drawable3 = null;
    } 
    if (paramInt4 != 0)
      drawable4 = a.b(context, paramInt4); 
    setCompoundDrawablesWithIntrinsicBounds(drawable1, drawable2, drawable3, drawable4);
    z z1 = this.i;
    if (z1 != null)
      z1.b(); 
  }
  
  public void setCompoundDrawablesWithIntrinsicBounds(Drawable paramDrawable1, Drawable paramDrawable2, Drawable paramDrawable3, Drawable paramDrawable4) {
    super.setCompoundDrawablesWithIntrinsicBounds(paramDrawable1, paramDrawable2, paramDrawable3, paramDrawable4);
    z z1 = this.i;
    if (z1 != null)
      z1.b(); 
  }
  
  public void setCustomSelectionActionModeCallback(ActionMode.Callback paramCallback) {
    super.setCustomSelectionActionModeCallback(f.g(this, paramCallback));
  }
  
  public void setFirstBaselineToTopHeight(int paramInt) {
    if (Build.VERSION.SDK_INT >= 28) {
      super.setFirstBaselineToTopHeight(paramInt);
      return;
    } 
    f.b(this, paramInt);
  }
  
  public void setLastBaselineToBottomHeight(int paramInt) {
    if (Build.VERSION.SDK_INT >= 28) {
      super.setLastBaselineToBottomHeight(paramInt);
      return;
    } 
    f.c(this, paramInt);
  }
  
  public void setLineHeight(int paramInt) {
    f.d(this, paramInt);
  }
  
  public void setPrecomputedText(b paramb) {
    f.e(this, paramb);
  }
  
  public void setSupportBackgroundTintList(ColorStateList paramColorStateList) {
    e e1 = this.h;
    if (e1 != null)
      e1.h(paramColorStateList); 
  }
  
  public void setSupportBackgroundTintMode(PorterDuff.Mode paramMode) {
    e e1 = this.h;
    if (e1 != null)
      e1.i(paramMode); 
  }
  
  public void setSupportCompoundDrawablesTintList(ColorStateList paramColorStateList) {
    this.i.j(paramColorStateList);
    this.i.b();
  }
  
  public void setSupportCompoundDrawablesTintMode(PorterDuff.Mode paramMode) {
    this.i.k(paramMode);
    this.i.b();
  }
  
  public void setTextAppearance(Context paramContext, int paramInt) {
    super.setTextAppearance(paramContext, paramInt);
    z z1 = this.i;
    if (z1 != null)
      z1.f(paramContext, paramInt); 
  }
  
  public void setTextClassifier(TextClassifier paramTextClassifier) {
    if (Build.VERSION.SDK_INT < 28) {
      x x1 = this.j;
      if (x1 != null) {
        x1.b = paramTextClassifier;
        return;
      } 
    } 
    super.setTextClassifier(paramTextClassifier);
  }
  
  public void setTextFuture(Future<b> paramFuture) {
    this.k = paramFuture;
    if (paramFuture != null)
      requestLayout(); 
  }
  
  public void setTextMetricsParamsCompat(b.a parama) {
    int i = Build.VERSION.SDK_INT;
    TextDirectionHeuristic textDirectionHeuristic1 = parama.b;
    TextDirectionHeuristic textDirectionHeuristic2 = TextDirectionHeuristics.FIRSTSTRONG_RTL;
    byte b1 = 1;
    if (textDirectionHeuristic1 != textDirectionHeuristic2 && textDirectionHeuristic1 != TextDirectionHeuristics.FIRSTSTRONG_LTR)
      if (textDirectionHeuristic1 == TextDirectionHeuristics.ANYRTL_LTR) {
        b1 = 2;
      } else if (textDirectionHeuristic1 == TextDirectionHeuristics.LTR) {
        b1 = 3;
      } else if (textDirectionHeuristic1 == TextDirectionHeuristics.RTL) {
        b1 = 4;
      } else if (textDirectionHeuristic1 == TextDirectionHeuristics.LOCALE) {
        b1 = 5;
      } else if (textDirectionHeuristic1 == TextDirectionHeuristics.FIRSTSTRONG_LTR) {
        b1 = 6;
      } else if (textDirectionHeuristic1 == TextDirectionHeuristics.FIRSTSTRONG_RTL) {
        b1 = 7;
      }  
    setTextDirection(b1);
    if (i < 23) {
      float f = parama.a.getTextScaleX();
      getPaint().set(parama.a);
      if (f == getTextScaleX())
        setTextScaleX(f / 2.0F + 1.0F); 
      setTextScaleX(f);
      return;
    } 
    getPaint().set(parama.a);
    setBreakStrategy(parama.c);
    setHyphenationFrequency(parama.d);
  }
  
  public void setTextSize(int paramInt, float paramFloat) {
    boolean bool = b.g;
    if (bool) {
      super.setTextSize(paramInt, paramFloat);
      return;
    } 
    z z1 = this.i;
    if (z1 != null && !bool && !z1.d())
      z1.i.f(paramInt, paramFloat); 
  }
  
  public void setTypeface(Typeface paramTypeface, int paramInt) {
    Typeface typeface;
    if (paramTypeface != null && paramInt > 0) {
      typeface = (Typeface)getContext();
      k k = e.a;
      if (typeface != null) {
        Typeface typeface1 = Typeface.create(paramTypeface, paramInt);
      } else {
        throw new IllegalArgumentException("Context cannot be null");
      } 
    } else {
      typeface = null;
    } 
    if (typeface != null)
      paramTypeface = typeface; 
    super.setTypeface(paramTypeface, paramInt);
  }
}


/* Location:              C:\soft\dex2jar-2.0\Luxury Logo Maker_ Logo Design-dex2jar.jar!\androidx\appcompat\widget\a0.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */