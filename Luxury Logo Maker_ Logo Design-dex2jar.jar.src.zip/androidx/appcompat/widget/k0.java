package androidx.appcompat.widget;

import android.view.View;
import android.widget.AdapterView;

public class k0 implements AdapterView.OnItemSelectedListener {
  public k0(l0 paraml0) {}
  
  public void onItemSelected(AdapterView<?> paramAdapterView, View paramView, int paramInt, long paramLong) {
    if (paramInt != -1) {
      g0 g0 = this.h.j;
      if (g0 != null)
        g0.setListSelectionHidden(false); 
    } 
  }
  
  public void onNothingSelected(AdapterView<?> paramAdapterView) {}
}


/* Location:              C:\soft\dex2jar-2.0\Luxury Logo Maker_ Logo Design-dex2jar.jar!\androidx\appcompat\widget\k0.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */