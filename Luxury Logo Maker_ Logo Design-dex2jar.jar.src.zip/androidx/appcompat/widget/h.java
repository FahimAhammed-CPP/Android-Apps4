package androidx.appcompat.widget;

import android.content.Context;
import android.util.AttributeSet;
import android.view.ActionMode;
import android.view.View;
import android.view.inputmethod.EditorInfo;
import android.view.inputmethod.InputConnection;
import android.widget.CheckedTextView;
import android.widget.TextView;
import b4.a;
import g.a;
import m0.f;

public class h extends CheckedTextView {
  public static final int[] i = new int[] { 16843016 };
  
  public final z h;
  
  public h(Context paramContext, AttributeSet paramAttributeSet) {
    super(paramContext, paramAttributeSet, 16843720);
    u0.a((View)this, getContext());
    z z1 = new z((TextView)this);
    this.h = z1;
    z1.e(paramAttributeSet, 16843720);
    z1.b();
    z0 z0 = z0.q(getContext(), paramAttributeSet, i, 16843720, 0);
    setCheckMarkDrawable(z0.g(0));
    z0.b.recycle();
  }
  
  public void drawableStateChanged() {
    super.drawableStateChanged();
    z z1 = this.h;
    if (z1 != null)
      z1.b(); 
  }
  
  public InputConnection onCreateInputConnection(EditorInfo paramEditorInfo) {
    InputConnection inputConnection = super.onCreateInputConnection(paramEditorInfo);
    a.c(inputConnection, paramEditorInfo, (View)this);
    return inputConnection;
  }
  
  public void setCheckMarkDrawable(int paramInt) {
    setCheckMarkDrawable(a.b(getContext(), paramInt));
  }
  
  public void setCustomSelectionActionModeCallback(ActionMode.Callback paramCallback) {
    super.setCustomSelectionActionModeCallback(f.g((TextView)this, paramCallback));
  }
  
  public void setTextAppearance(Context paramContext, int paramInt) {
    super.setTextAppearance(paramContext, paramInt);
    z z1 = this.h;
    if (z1 != null)
      z1.f(paramContext, paramInt); 
  }
}


/* Location:              C:\soft\dex2jar-2.0\Luxury Logo Maker_ Logo Design-dex2jar.jar!\androidx\appcompat\widget\h.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */