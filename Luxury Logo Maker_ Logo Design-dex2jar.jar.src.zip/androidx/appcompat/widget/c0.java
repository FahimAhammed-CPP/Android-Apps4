package androidx.appcompat.widget;

import android.content.Context;
import android.util.AttributeSet;
import android.view.View;
import android.widget.TextView;
import android.widget.ToggleButton;

public class c0 extends ToggleButton {
  public c0(Context paramContext, AttributeSet paramAttributeSet) {
    super(paramContext, paramAttributeSet, 16842827);
    u0.a((View)this, getContext());
    (new z((TextView)this)).e(paramAttributeSet, 16842827);
  }
}


/* Location:              C:\soft\dex2jar-2.0\Luxury Logo Maker_ Logo Design-dex2jar.jar!\androidx\appcompat\widget\c0.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */