package androidx.appcompat.widget;

import android.annotation.SuppressLint;
import android.app.PendingIntent;
import android.app.SearchableInfo;
import android.content.ActivityNotFoundException;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.content.res.Configuration;
import android.content.res.Resources;
import android.content.res.TypedArray;
import android.database.Cursor;
import android.graphics.Rect;
import android.graphics.drawable.Drawable;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Parcel;
import android.os.Parcelable;
import android.text.Editable;
import android.text.SpannableStringBuilder;
import android.text.TextUtils;
import android.text.TextWatcher;
import android.text.style.ImageSpan;
import android.util.AttributeSet;
import android.util.DisplayMetrics;
import android.util.Log;
import android.util.TypedValue;
import android.view.KeyEvent;
import android.view.LayoutInflater;
import android.view.MotionEvent;
import android.view.TouchDelegate;
import android.view.View;
import android.view.ViewConfiguration;
import android.view.ViewGroup;
import android.view.inputmethod.EditorInfo;
import android.view.inputmethod.InputConnection;
import android.view.inputmethod.InputMethodManager;
import android.widget.AdapterView;
import android.widget.AutoCompleteTextView;
import android.widget.ImageView;
import android.widget.ListAdapter;
import android.widget.TextView;
import j.b;
import java.lang.reflect.Method;
import java.util.Objects;
import java.util.WeakHashMap;

public class SearchView extends j0 implements b {
  public static final n t0;
  
  public final ImageView A;
  
  public final ImageView B;
  
  public final ImageView C;
  
  public final ImageView D;
  
  public final View E;
  
  public p F;
  
  public Rect G = new Rect();
  
  public Rect H = new Rect();
  
  public int[] I = new int[2];
  
  public int[] J = new int[2];
  
  public final ImageView K;
  
  public final Drawable L;
  
  public final int M;
  
  public final int N;
  
  public final Intent O;
  
  public final Intent P;
  
  public final CharSequence Q;
  
  public l R;
  
  public k S;
  
  public View.OnFocusChangeListener T;
  
  public m U;
  
  public View.OnClickListener V;
  
  public boolean W;
  
  public boolean a0;
  
  public n0.a b0;
  
  public boolean c0;
  
  public CharSequence d0;
  
  public boolean e0;
  
  public boolean f0;
  
  public int g0;
  
  public boolean h0;
  
  public CharSequence i0;
  
  public CharSequence j0;
  
  public boolean k0;
  
  public int l0;
  
  public SearchableInfo m0;
  
  public Bundle n0;
  
  public final Runnable o0 = new b(this);
  
  public Runnable p0 = new c(this);
  
  public final WeakHashMap<String, Drawable.ConstantState> q0 = new WeakHashMap<String, Drawable.ConstantState>();
  
  public View.OnKeyListener r0;
  
  public TextWatcher s0;
  
  public final SearchAutoComplete w;
  
  public final View x;
  
  public final View y;
  
  public final View z;
  
  static {
    n n1;
    if (Build.VERSION.SDK_INT < 29) {
      n1 = new n();
    } else {
      n1 = null;
    } 
    t0 = n1;
  }
  
  public SearchView(Context paramContext) {
    this(paramContext, null);
  }
  
  public SearchView(Context paramContext, AttributeSet paramAttributeSet) {
    this(paramContext, paramAttributeSet, 2130969280);
  }
  
  public SearchView(Context paramContext, AttributeSet paramAttributeSet, int paramInt) {
    super(paramContext, paramAttributeSet, paramInt);
    f f = new f(this);
    this.r0 = new g(this);
    h h = new h(this);
    i i = new i(this);
    j j = new j(this);
    this.s0 = new a(this);
    TypedArray typedArray = paramContext.obtainStyledAttributes(paramAttributeSet, com.bumptech.glide.manager.b.B, paramInt, 0);
    z0 z0 = new z0(paramContext, typedArray);
    LayoutInflater.from(paramContext).inflate(z0.l(9, 2131558425), this, true);
    SearchAutoComplete searchAutoComplete = (SearchAutoComplete)findViewById(2131362313);
    this.w = searchAutoComplete;
    searchAutoComplete.setSearchView(this);
    this.x = findViewById(2131362309);
    View view2 = findViewById(2131362312);
    this.y = view2;
    View view3 = findViewById(2131362385);
    this.z = view3;
    ImageView imageView1 = (ImageView)findViewById(2131362307);
    this.A = imageView1;
    ImageView imageView2 = (ImageView)findViewById(2131362310);
    this.B = imageView2;
    ImageView imageView3 = (ImageView)findViewById(2131362308);
    this.C = imageView3;
    ImageView imageView4 = (ImageView)findViewById(2131362314);
    this.D = imageView4;
    ImageView imageView5 = (ImageView)findViewById(2131362311);
    this.K = imageView5;
    Drawable drawable = z0.g(10);
    WeakHashMap weakHashMap = k0.l.a;
    view2.setBackground(drawable);
    view3.setBackground(z0.g(14));
    imageView1.setImageDrawable(z0.g(13));
    imageView2.setImageDrawable(z0.g(7));
    imageView3.setImageDrawable(z0.g(4));
    imageView4.setImageDrawable(z0.g(16));
    imageView5.setImageDrawable(z0.g(13));
    this.L = z0.g(12);
    c1.a((View)imageView1, getResources().getString(2131820566));
    this.M = z0.l(15, 2131558424);
    this.N = z0.l(5, 0);
    imageView1.setOnClickListener(f);
    imageView3.setOnClickListener(f);
    imageView2.setOnClickListener(f);
    imageView4.setOnClickListener(f);
    searchAutoComplete.setOnClickListener(f);
    searchAutoComplete.addTextChangedListener(this.s0);
    searchAutoComplete.setOnEditorActionListener(h);
    searchAutoComplete.setOnItemClickListener(i);
    searchAutoComplete.setOnItemSelectedListener(j);
    searchAutoComplete.setOnKeyListener(this.r0);
    searchAutoComplete.setOnFocusChangeListener(new d(this));
    setIconifiedByDefault(z0.a(8, true));
    paramInt = z0.f(1, -1);
    if (paramInt != -1)
      setMaxWidth(paramInt); 
    this.Q = z0.n(6);
    this.d0 = z0.n(11);
    paramInt = z0.j(3, -1);
    if (paramInt != -1)
      setImeOptions(paramInt); 
    paramInt = z0.j(2, -1);
    if (paramInt != -1)
      setInputType(paramInt); 
    setFocusable(z0.a(0, true));
    typedArray.recycle();
    Intent intent = new Intent("android.speech.action.WEB_SEARCH");
    this.O = intent;
    intent.addFlags(268435456);
    intent.putExtra("android.speech.extra.LANGUAGE_MODEL", "web_search");
    intent = new Intent("android.speech.action.RECOGNIZE_SPEECH");
    this.P = intent;
    intent.addFlags(268435456);
    View view1 = findViewById(searchAutoComplete.getDropDownAnchor());
    this.E = view1;
    if (view1 != null)
      view1.addOnLayoutChangeListener(new e(this)); 
    A(this.W);
    x();
  }
  
  private int getPreferredHeight() {
    return getContext().getResources().getDimensionPixelSize(2131165956);
  }
  
  private int getPreferredWidth() {
    return getContext().getResources().getDimensionPixelSize(2131165957);
  }
  
  private void setQuery(CharSequence paramCharSequence) {
    int i;
    this.w.setText(paramCharSequence);
    SearchAutoComplete searchAutoComplete = this.w;
    if (TextUtils.isEmpty(paramCharSequence)) {
      i = 0;
    } else {
      i = paramCharSequence.length();
    } 
    searchAutoComplete.setSelection(i);
  }
  
  public final void A(boolean paramBoolean) {
    // Byte code:
    //   0: aload_0
    //   1: iload_1
    //   2: putfield a0 : Z
    //   5: iconst_0
    //   6: istore_3
    //   7: iload_1
    //   8: ifeq -> 16
    //   11: iconst_0
    //   12: istore_2
    //   13: goto -> 19
    //   16: bipush #8
    //   18: istore_2
    //   19: aload_0
    //   20: getfield w : Landroidx/appcompat/widget/SearchView$SearchAutoComplete;
    //   23: invokevirtual getText : ()Landroid/text/Editable;
    //   26: invokestatic isEmpty : (Ljava/lang/CharSequence;)Z
    //   29: iconst_1
    //   30: ixor
    //   31: istore #4
    //   33: aload_0
    //   34: getfield A : Landroid/widget/ImageView;
    //   37: iload_2
    //   38: invokevirtual setVisibility : (I)V
    //   41: aload_0
    //   42: iload #4
    //   44: invokevirtual z : (Z)V
    //   47: aload_0
    //   48: getfield x : Landroid/view/View;
    //   51: astore #5
    //   53: iload_1
    //   54: ifeq -> 63
    //   57: bipush #8
    //   59: istore_2
    //   60: goto -> 65
    //   63: iconst_0
    //   64: istore_2
    //   65: aload #5
    //   67: iload_2
    //   68: invokevirtual setVisibility : (I)V
    //   71: aload_0
    //   72: getfield K : Landroid/widget/ImageView;
    //   75: invokevirtual getDrawable : ()Landroid/graphics/drawable/Drawable;
    //   78: ifnull -> 90
    //   81: iload_3
    //   82: istore_2
    //   83: aload_0
    //   84: getfield W : Z
    //   87: ifeq -> 93
    //   90: bipush #8
    //   92: istore_2
    //   93: aload_0
    //   94: getfield K : Landroid/widget/ImageView;
    //   97: iload_2
    //   98: invokevirtual setVisibility : (I)V
    //   101: aload_0
    //   102: invokevirtual v : ()V
    //   105: aload_0
    //   106: iload #4
    //   108: iconst_1
    //   109: ixor
    //   110: invokevirtual B : (Z)V
    //   113: aload_0
    //   114: invokevirtual y : ()V
    //   117: return
  }
  
  public final void B(boolean paramBoolean) {
    boolean bool = this.h0;
    byte b2 = 8;
    byte b1 = b2;
    if (bool) {
      b1 = b2;
      if (!this.a0) {
        b1 = b2;
        if (paramBoolean) {
          this.B.setVisibility(8);
          b1 = 0;
        } 
      } 
    } 
    this.D.setVisibility(b1);
  }
  
  public void c() {
    if (this.k0)
      return; 
    this.k0 = true;
    int i = this.w.getImeOptions();
    this.l0 = i;
    this.w.setImeOptions(i | 0x2000000);
    this.w.setText("");
    setIconified(false);
  }
  
  public void clearFocus() {
    this.f0 = true;
    super.clearFocus();
    this.w.clearFocus();
    this.w.setImeVisibility(false);
    this.f0 = false;
  }
  
  public void d() {
    this.w.setText("");
    SearchAutoComplete searchAutoComplete = this.w;
    searchAutoComplete.setSelection(searchAutoComplete.length());
    this.j0 = "";
    clearFocus();
    A(true);
    this.w.setImeOptions(this.l0);
    this.k0 = false;
  }
  
  public int getImeOptions() {
    return this.w.getImeOptions();
  }
  
  public int getInputType() {
    return this.w.getInputType();
  }
  
  public int getMaxWidth() {
    return this.g0;
  }
  
  public CharSequence getQuery() {
    return (CharSequence)this.w.getText();
  }
  
  public CharSequence getQueryHint() {
    CharSequence charSequence = this.d0;
    if (charSequence != null)
      return charSequence; 
    SearchableInfo searchableInfo = this.m0;
    return (searchableInfo != null && searchableInfo.getHintId() != 0) ? getContext().getText(this.m0.getHintId()) : this.Q;
  }
  
  public int getSuggestionCommitIconResId() {
    return this.N;
  }
  
  public int getSuggestionRowLayout() {
    return this.M;
  }
  
  public n0.a getSuggestionsAdapter() {
    return this.b0;
  }
  
  public final Intent l(String paramString1, Uri paramUri, String paramString2, String paramString3, int paramInt, String paramString4) {
    Intent intent = new Intent(paramString1);
    intent.addFlags(268435456);
    if (paramUri != null)
      intent.setData(paramUri); 
    intent.putExtra("user_query", this.j0);
    if (paramString3 != null)
      intent.putExtra("query", paramString3); 
    if (paramString2 != null)
      intent.putExtra("intent_extra_data_key", paramString2); 
    Bundle bundle = this.n0;
    if (bundle != null)
      intent.putExtra("app_data", bundle); 
    if (paramInt != 0) {
      intent.putExtra("action_key", paramInt);
      intent.putExtra("action_msg", paramString4);
    } 
    intent.setComponent(this.m0.getSearchActivity());
    return intent;
  }
  
  public final Intent m(Intent paramIntent, SearchableInfo paramSearchableInfo) {
    String str1;
    ComponentName componentName = paramSearchableInfo.getSearchActivity();
    Intent intent1 = new Intent("android.intent.action.SEARCH");
    intent1.setComponent(componentName);
    PendingIntent pendingIntent = PendingIntent.getActivity(getContext(), 0, intent1, 1073741824);
    Bundle bundle2 = new Bundle();
    Bundle bundle1 = this.n0;
    if (bundle1 != null)
      bundle2.putParcelable("app_data", (Parcelable)bundle1); 
    Intent intent2 = new Intent(paramIntent);
    int i = 1;
    Resources resources = getResources();
    if (paramSearchableInfo.getVoiceLanguageModeId() != 0) {
      str1 = resources.getString(paramSearchableInfo.getVoiceLanguageModeId());
    } else {
      str1 = "free_form";
    } 
    int j = paramSearchableInfo.getVoicePromptTextId();
    String str2 = null;
    if (j != 0) {
      String str = resources.getString(paramSearchableInfo.getVoicePromptTextId());
    } else {
      bundle1 = null;
    } 
    if (paramSearchableInfo.getVoiceLanguageId() != 0) {
      String str = resources.getString(paramSearchableInfo.getVoiceLanguageId());
    } else {
      resources = null;
    } 
    if (paramSearchableInfo.getVoiceMaxResults() != 0)
      i = paramSearchableInfo.getVoiceMaxResults(); 
    intent2.putExtra("android.speech.extra.LANGUAGE_MODEL", str1);
    intent2.putExtra("android.speech.extra.PROMPT", (String)bundle1);
    intent2.putExtra("android.speech.extra.LANGUAGE", (String)resources);
    intent2.putExtra("android.speech.extra.MAX_RESULTS", i);
    if (componentName == null) {
      str1 = str2;
    } else {
      str1 = componentName.flattenToShortString();
    } 
    intent2.putExtra("calling_package", str1);
    intent2.putExtra("android.speech.extra.RESULTS_PENDINGINTENT", (Parcelable)pendingIntent);
    intent2.putExtra("android.speech.extra.RESULTS_PENDINGINTENT_BUNDLE", bundle2);
    return intent2;
  }
  
  public void n() {
    if (Build.VERSION.SDK_INT >= 29) {
      this.w.refreshAutoCompleteResults();
      return;
    } 
    n n2 = t0;
    SearchAutoComplete searchAutoComplete = this.w;
    Objects.requireNonNull(n2);
    n.a();
    Method method2 = n2.a;
    if (method2 != null)
      try {
        method2.invoke(searchAutoComplete, new Object[0]);
      } catch (Exception exception) {} 
    n n1 = t0;
    searchAutoComplete = this.w;
    Objects.requireNonNull(n1);
    n.a();
    Method method1 = n1.b;
    if (method1 != null)
      try {
        method1.invoke(searchAutoComplete, new Object[0]);
        return;
      } catch (Exception exception) {
        return;
      }  
  }
  
  public void o(int paramInt, String paramString1, String paramString2) {
    Intent intent = l("android.intent.action.SEARCH", null, null, paramString2, paramInt, null);
    getContext().startActivity(intent);
  }
  
  public void onDetachedFromWindow() {
    removeCallbacks(this.o0);
    post(this.p0);
    super.onDetachedFromWindow();
  }
  
  public void onLayout(boolean paramBoolean, int paramInt1, int paramInt2, int paramInt3, int paramInt4) {
    super.onLayout(paramBoolean, paramInt1, paramInt2, paramInt3, paramInt4);
    if (paramBoolean) {
      SearchAutoComplete searchAutoComplete = this.w;
      Rect rect2 = this.G;
      searchAutoComplete.getLocationInWindow(this.I);
      getLocationInWindow(this.J);
      int[] arrayOfInt1 = this.I;
      paramInt1 = arrayOfInt1[1];
      int[] arrayOfInt2 = this.J;
      paramInt1 -= arrayOfInt2[1];
      paramInt3 = arrayOfInt1[0] - arrayOfInt2[0];
      rect2.set(paramInt3, paramInt1, searchAutoComplete.getWidth() + paramInt3, searchAutoComplete.getHeight() + paramInt1);
      Rect rect1 = this.H;
      rect2 = this.G;
      rect1.set(rect2.left, 0, rect2.right, paramInt4 - paramInt2);
      p p1 = this.F;
      if (p1 == null) {
        p1 = new p(this.H, this.G, (View)this.w);
        this.F = p1;
        setTouchDelegate(p1);
        return;
      } 
      p1.a(this.H, this.G);
    } 
  }
  
  public void onMeasure(int paramInt1, int paramInt2) {
    // Byte code:
    //   0: aload_0
    //   1: getfield a0 : Z
    //   4: ifeq -> 14
    //   7: aload_0
    //   8: iload_1
    //   9: iload_2
    //   10: invokespecial onMeasure : (II)V
    //   13: return
    //   14: iload_1
    //   15: invokestatic getMode : (I)I
    //   18: istore #4
    //   20: iload_1
    //   21: invokestatic getSize : (I)I
    //   24: istore_3
    //   25: iload #4
    //   27: ldc_w -2147483648
    //   30: if_icmpeq -> 90
    //   33: iload #4
    //   35: ifeq -> 70
    //   38: iload #4
    //   40: ldc_w 1073741824
    //   43: if_icmpeq -> 51
    //   46: iload_3
    //   47: istore_1
    //   48: goto -> 113
    //   51: aload_0
    //   52: getfield g0 : I
    //   55: istore #4
    //   57: iload_3
    //   58: istore_1
    //   59: iload #4
    //   61: ifle -> 113
    //   64: iload #4
    //   66: istore_1
    //   67: goto -> 99
    //   70: aload_0
    //   71: getfield g0 : I
    //   74: istore_1
    //   75: iload_1
    //   76: ifle -> 82
    //   79: goto -> 113
    //   82: aload_0
    //   83: invokespecial getPreferredWidth : ()I
    //   86: istore_1
    //   87: goto -> 113
    //   90: aload_0
    //   91: getfield g0 : I
    //   94: istore_1
    //   95: iload_1
    //   96: ifle -> 102
    //   99: goto -> 107
    //   102: aload_0
    //   103: invokespecial getPreferredWidth : ()I
    //   106: istore_1
    //   107: iload_1
    //   108: iload_3
    //   109: invokestatic min : (II)I
    //   112: istore_1
    //   113: iload_2
    //   114: invokestatic getMode : (I)I
    //   117: istore_3
    //   118: iload_2
    //   119: invokestatic getSize : (I)I
    //   122: istore_2
    //   123: iload_3
    //   124: ldc_w -2147483648
    //   127: if_icmpeq -> 145
    //   130: iload_3
    //   131: ifeq -> 137
    //   134: goto -> 154
    //   137: aload_0
    //   138: invokespecial getPreferredHeight : ()I
    //   141: istore_2
    //   142: goto -> 154
    //   145: aload_0
    //   146: invokespecial getPreferredHeight : ()I
    //   149: iload_2
    //   150: invokestatic min : (II)I
    //   153: istore_2
    //   154: aload_0
    //   155: iload_1
    //   156: ldc_w 1073741824
    //   159: invokestatic makeMeasureSpec : (II)I
    //   162: iload_2
    //   163: ldc_w 1073741824
    //   166: invokestatic makeMeasureSpec : (II)I
    //   169: invokespecial onMeasure : (II)V
    //   172: return
  }
  
  public void onRestoreInstanceState(Parcelable paramParcelable) {
    if (!(paramParcelable instanceof o)) {
      super.onRestoreInstanceState(paramParcelable);
      return;
    } 
    o o = (o)paramParcelable;
    super.onRestoreInstanceState(o.h);
    A(o.j);
    requestLayout();
  }
  
  public Parcelable onSaveInstanceState() {
    o o = new o(super.onSaveInstanceState());
    o.j = this.a0;
    return (Parcelable)o;
  }
  
  public void onWindowFocusChanged(boolean paramBoolean) {
    super.onWindowFocusChanged(paramBoolean);
    post(this.o0);
  }
  
  public void p() {
    if (TextUtils.isEmpty((CharSequence)this.w.getText())) {
      if (this.W) {
        k k1 = this.S;
        if (k1 == null || !k1.a()) {
          clearFocus();
          A(true);
          return;
        } 
      } 
    } else {
      this.w.setText("");
      this.w.requestFocus();
      this.w.setImeVisibility(true);
    } 
  }
  
  public boolean q(int paramInt) {
    Intent intent;
    m m1 = this.U;
    if (m1 == null || !m1.b(paramInt)) {
      Uri uri;
      String str2;
      Cursor cursor = this.b0.j;
      if (cursor != null && cursor.moveToPosition(paramInt)) {
        RuntimeException runtimeException = null;
        try {
          paramInt = t0.F;
          str2 = t0.r(cursor, cursor.getColumnIndex("suggest_intent_action"));
          String str = str2;
          if (str2 == null)
            str = this.m0.getSuggestIntentAction(); 
        } catch (RuntimeException runtimeException1) {
          try {
            paramInt = cursor.getPosition();
          } catch (RuntimeException runtimeException3) {
            paramInt = -1;
          } 
          StringBuilder stringBuilder = new StringBuilder();
          stringBuilder.append("Search suggestions cursor at row ");
          stringBuilder.append(paramInt);
          stringBuilder.append(" returned exception.");
          Log.w("SearchView", stringBuilder.toString(), runtimeException1);
          runtimeException1 = runtimeException;
          if (runtimeException1 != null)
            try {
              getContext().startActivity((Intent)runtimeException1);
            } catch (RuntimeException runtimeException3) {
              StringBuilder stringBuilder1 = new StringBuilder();
              stringBuilder1.append("Failed launch activity: ");
              stringBuilder1.append(runtimeException1);
              Log.e("SearchView", stringBuilder1.toString(), runtimeException3);
            }  
          this.w.setImeVisibility(false);
          this.w.dismissDropDown();
          return true;
        } 
      } else {
        this.w.setImeVisibility(false);
        this.w.dismissDropDown();
        return true;
      } 
      RuntimeException runtimeException2 = runtimeException1;
      if (runtimeException1 == null)
        str2 = "android.intent.action.SEARCH"; 
      String str3 = t0.r(cursor, cursor.getColumnIndex("suggest_intent_data"));
      String str1 = str3;
      if (str3 == null)
        str1 = this.m0.getSuggestIntentData(); 
      str3 = str1;
      if (str1 != null) {
        String str = t0.r(cursor, cursor.getColumnIndex("suggest_intent_data_id"));
        str3 = str1;
        if (str != null) {
          StringBuilder stringBuilder = new StringBuilder();
          stringBuilder.append(str1);
          stringBuilder.append("/");
          stringBuilder.append(Uri.encode(str));
          str3 = stringBuilder.toString();
        } 
      } 
      if (str3 == null) {
        str1 = null;
      } else {
        uri = Uri.parse(str3);
      } 
      str3 = t0.r(cursor, cursor.getColumnIndex("suggest_intent_query"));
      intent = l(str2, uri, t0.r(cursor, cursor.getColumnIndex("suggest_intent_extra_data")), str3, 0, null);
    } else {
      return false;
    } 
    if (intent != null)
      try {
        getContext().startActivity(intent);
      } catch (RuntimeException runtimeException) {
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("Failed launch activity: ");
        stringBuilder.append(intent);
        Log.e("SearchView", stringBuilder.toString(), runtimeException);
      }  
    this.w.setImeVisibility(false);
    this.w.dismissDropDown();
    return true;
  }
  
  public boolean r(int paramInt) {
    m m1 = this.U;
    if (m1 == null || !m1.a(paramInt)) {
      Editable editable = this.w.getText();
      Cursor cursor = this.b0.j;
      if (cursor != null) {
        if (cursor.moveToPosition(paramInt)) {
          CharSequence charSequence = this.b0.c(cursor);
          if (charSequence != null) {
            setQuery(charSequence);
            return true;
          } 
        } 
        setQuery((CharSequence)editable);
      } 
      return true;
    } 
    return false;
  }
  
  public boolean requestFocus(int paramInt, Rect paramRect) {
    if (this.f0)
      return false; 
    if (!isFocusable())
      return false; 
    if (!this.a0) {
      boolean bool = this.w.requestFocus(paramInt, paramRect);
      if (bool)
        A(false); 
      return bool;
    } 
    return super.requestFocus(paramInt, paramRect);
  }
  
  public void s(CharSequence paramCharSequence) {
    setQuery(paramCharSequence);
  }
  
  public void setAppSearchData(Bundle paramBundle) {
    this.n0 = paramBundle;
  }
  
  public void setIconified(boolean paramBoolean) {
    if (paramBoolean) {
      p();
      return;
    } 
    t();
  }
  
  public void setIconifiedByDefault(boolean paramBoolean) {
    if (this.W == paramBoolean)
      return; 
    this.W = paramBoolean;
    A(paramBoolean);
    x();
  }
  
  public void setImeOptions(int paramInt) {
    this.w.setImeOptions(paramInt);
  }
  
  public void setInputType(int paramInt) {
    this.w.setInputType(paramInt);
  }
  
  public void setMaxWidth(int paramInt) {
    this.g0 = paramInt;
    requestLayout();
  }
  
  public void setOnCloseListener(k paramk) {
    this.S = paramk;
  }
  
  public void setOnQueryTextFocusChangeListener(View.OnFocusChangeListener paramOnFocusChangeListener) {
    this.T = paramOnFocusChangeListener;
  }
  
  public void setOnQueryTextListener(l paraml) {
    this.R = paraml;
  }
  
  public void setOnSearchClickListener(View.OnClickListener paramOnClickListener) {
    this.V = paramOnClickListener;
  }
  
  public void setOnSuggestionListener(m paramm) {
    this.U = paramm;
  }
  
  public void setQueryHint(CharSequence paramCharSequence) {
    this.d0 = paramCharSequence;
    x();
  }
  
  public void setQueryRefinementEnabled(boolean paramBoolean) {
    this.e0 = paramBoolean;
    n0.a a1 = this.b0;
    if (a1 instanceof t0) {
      boolean bool;
      t0 t0 = (t0)a1;
      if (paramBoolean) {
        bool = true;
      } else {
        bool = true;
      } 
      t0.x = bool;
    } 
  }
  
  public void setSearchableInfo(SearchableInfo paramSearchableInfo) {
    // Byte code:
    //   0: aload_0
    //   1: aload_1
    //   2: putfield m0 : Landroid/app/SearchableInfo;
    //   5: iconst_1
    //   6: istore #4
    //   8: aconst_null
    //   9: astore #5
    //   11: aload_1
    //   12: ifnull -> 183
    //   15: aload_0
    //   16: getfield w : Landroidx/appcompat/widget/SearchView$SearchAutoComplete;
    //   19: aload_1
    //   20: invokevirtual getSuggestThreshold : ()I
    //   23: invokevirtual setThreshold : (I)V
    //   26: aload_0
    //   27: getfield w : Landroidx/appcompat/widget/SearchView$SearchAutoComplete;
    //   30: aload_0
    //   31: getfield m0 : Landroid/app/SearchableInfo;
    //   34: invokevirtual getImeOptions : ()I
    //   37: invokevirtual setImeOptions : (I)V
    //   40: aload_0
    //   41: getfield m0 : Landroid/app/SearchableInfo;
    //   44: invokevirtual getInputType : ()I
    //   47: istore_3
    //   48: iload_3
    //   49: istore_2
    //   50: iload_3
    //   51: bipush #15
    //   53: iand
    //   54: iconst_1
    //   55: if_icmpne -> 86
    //   58: iload_3
    //   59: ldc_w -65537
    //   62: iand
    //   63: istore_3
    //   64: iload_3
    //   65: istore_2
    //   66: aload_0
    //   67: getfield m0 : Landroid/app/SearchableInfo;
    //   70: invokevirtual getSuggestAuthority : ()Ljava/lang/String;
    //   73: ifnull -> 86
    //   76: iload_3
    //   77: ldc_w 65536
    //   80: ior
    //   81: ldc_w 524288
    //   84: ior
    //   85: istore_2
    //   86: aload_0
    //   87: getfield w : Landroidx/appcompat/widget/SearchView$SearchAutoComplete;
    //   90: iload_2
    //   91: invokevirtual setInputType : (I)V
    //   94: aload_0
    //   95: getfield b0 : Ln0/a;
    //   98: astore_1
    //   99: aload_1
    //   100: ifnull -> 108
    //   103: aload_1
    //   104: aconst_null
    //   105: invokevirtual b : (Landroid/database/Cursor;)V
    //   108: aload_0
    //   109: getfield m0 : Landroid/app/SearchableInfo;
    //   112: invokevirtual getSuggestAuthority : ()Ljava/lang/String;
    //   115: ifnull -> 179
    //   118: new androidx/appcompat/widget/t0
    //   121: dup
    //   122: aload_0
    //   123: invokevirtual getContext : ()Landroid/content/Context;
    //   126: aload_0
    //   127: aload_0
    //   128: getfield m0 : Landroid/app/SearchableInfo;
    //   131: aload_0
    //   132: getfield q0 : Ljava/util/WeakHashMap;
    //   135: invokespecial <init> : (Landroid/content/Context;Landroidx/appcompat/widget/SearchView;Landroid/app/SearchableInfo;Ljava/util/WeakHashMap;)V
    //   138: astore_1
    //   139: aload_0
    //   140: aload_1
    //   141: putfield b0 : Ln0/a;
    //   144: aload_0
    //   145: getfield w : Landroidx/appcompat/widget/SearchView$SearchAutoComplete;
    //   148: aload_1
    //   149: invokevirtual setAdapter : (Landroid/widget/ListAdapter;)V
    //   152: aload_0
    //   153: getfield b0 : Ln0/a;
    //   156: checkcast androidx/appcompat/widget/t0
    //   159: astore_1
    //   160: aload_0
    //   161: getfield e0 : Z
    //   164: ifeq -> 172
    //   167: iconst_2
    //   168: istore_2
    //   169: goto -> 174
    //   172: iconst_1
    //   173: istore_2
    //   174: aload_1
    //   175: iload_2
    //   176: putfield x : I
    //   179: aload_0
    //   180: invokevirtual x : ()V
    //   183: aload_0
    //   184: getfield m0 : Landroid/app/SearchableInfo;
    //   187: astore_1
    //   188: aload_1
    //   189: ifnull -> 259
    //   192: aload_1
    //   193: invokevirtual getVoiceSearchEnabled : ()Z
    //   196: ifeq -> 259
    //   199: aload_0
    //   200: getfield m0 : Landroid/app/SearchableInfo;
    //   203: invokevirtual getVoiceSearchLaunchWebSearch : ()Z
    //   206: ifeq -> 217
    //   209: aload_0
    //   210: getfield O : Landroid/content/Intent;
    //   213: astore_1
    //   214: goto -> 235
    //   217: aload #5
    //   219: astore_1
    //   220: aload_0
    //   221: getfield m0 : Landroid/app/SearchableInfo;
    //   224: invokevirtual getVoiceSearchLaunchRecognizer : ()Z
    //   227: ifeq -> 235
    //   230: aload_0
    //   231: getfield P : Landroid/content/Intent;
    //   234: astore_1
    //   235: aload_1
    //   236: ifnull -> 259
    //   239: aload_0
    //   240: invokevirtual getContext : ()Landroid/content/Context;
    //   243: invokevirtual getPackageManager : ()Landroid/content/pm/PackageManager;
    //   246: aload_1
    //   247: ldc_w 65536
    //   250: invokevirtual resolveActivity : (Landroid/content/Intent;I)Landroid/content/pm/ResolveInfo;
    //   253: ifnull -> 259
    //   256: goto -> 262
    //   259: iconst_0
    //   260: istore #4
    //   262: aload_0
    //   263: iload #4
    //   265: putfield h0 : Z
    //   268: iload #4
    //   270: ifeq -> 283
    //   273: aload_0
    //   274: getfield w : Landroidx/appcompat/widget/SearchView$SearchAutoComplete;
    //   277: ldc_w 'nm'
    //   280: invokevirtual setPrivateImeOptions : (Ljava/lang/String;)V
    //   283: aload_0
    //   284: aload_0
    //   285: getfield a0 : Z
    //   288: invokevirtual A : (Z)V
    //   291: return
  }
  
  public void setSubmitButtonEnabled(boolean paramBoolean) {
    this.c0 = paramBoolean;
    A(this.a0);
  }
  
  public void setSuggestionsAdapter(n0.a parama) {
    this.b0 = parama;
    this.w.setAdapter((ListAdapter)parama);
  }
  
  public void t() {
    A(false);
    this.w.requestFocus();
    this.w.setImeVisibility(true);
    View.OnClickListener onClickListener = this.V;
    if (onClickListener != null)
      onClickListener.onClick((View)this); 
  }
  
  public void u() {
    Editable editable = this.w.getText();
    if (editable != null && TextUtils.getTrimmedLength((CharSequence)editable) > 0) {
      l l1 = this.R;
      if (l1 == null || !l1.b(editable.toString())) {
        if (this.m0 != null)
          o(0, null, editable.toString()); 
        this.w.setImeVisibility(false);
        this.w.dismissDropDown();
      } 
    } 
  }
  
  public final void v() {
    boolean bool = TextUtils.isEmpty((CharSequence)this.w.getText());
    byte b3 = 1;
    int i = bool ^ true;
    byte b2 = 0;
    byte b1 = b3;
    if (i == 0)
      if (this.W && !this.k0) {
        b1 = b3;
      } else {
        b1 = 0;
      }  
    ImageView imageView = this.C;
    if (b1) {
      b1 = b2;
    } else {
      b1 = 8;
    } 
    imageView.setVisibility(b1);
    Drawable drawable = this.C.getDrawable();
    if (drawable != null) {
      int[] arrayOfInt;
      if (i != 0) {
        arrayOfInt = ViewGroup.ENABLED_STATE_SET;
      } else {
        arrayOfInt = ViewGroup.EMPTY_STATE_SET;
      } 
      drawable.setState(arrayOfInt);
    } 
  }
  
  public void w() {
    int[] arrayOfInt;
    if (this.w.hasFocus()) {
      arrayOfInt = ViewGroup.FOCUSED_STATE_SET;
    } else {
      arrayOfInt = ViewGroup.EMPTY_STATE_SET;
    } 
    Drawable drawable = this.y.getBackground();
    if (drawable != null)
      drawable.setState(arrayOfInt); 
    drawable = this.z.getBackground();
    if (drawable != null)
      drawable.setState(arrayOfInt); 
    invalidate();
  }
  
  public final void x() {
    SpannableStringBuilder spannableStringBuilder;
    CharSequence charSequence2 = getQueryHint();
    SearchAutoComplete searchAutoComplete = this.w;
    CharSequence charSequence1 = charSequence2;
    if (charSequence2 == null)
      charSequence1 = ""; 
    charSequence2 = charSequence1;
    if (this.W)
      if (this.L == null) {
        charSequence2 = charSequence1;
      } else {
        int i = (int)(searchAutoComplete.getTextSize() * 1.25D);
        this.L.setBounds(0, 0, i, i);
        spannableStringBuilder = new SpannableStringBuilder("   ");
        spannableStringBuilder.setSpan(new ImageSpan(this.L), 1, 2, 33);
        spannableStringBuilder.append(charSequence1);
      }  
    searchAutoComplete.setHint((CharSequence)spannableStringBuilder);
  }
  
  public final void y() {
    // Byte code:
    //   0: aload_0
    //   1: getfield c0 : Z
    //   4: istore_3
    //   5: iconst_0
    //   6: istore_2
    //   7: iload_3
    //   8: ifne -> 18
    //   11: aload_0
    //   12: getfield h0 : Z
    //   15: ifeq -> 30
    //   18: aload_0
    //   19: getfield a0 : Z
    //   22: ifne -> 30
    //   25: iconst_1
    //   26: istore_1
    //   27: goto -> 32
    //   30: iconst_0
    //   31: istore_1
    //   32: iload_1
    //   33: ifeq -> 63
    //   36: iload_2
    //   37: istore_1
    //   38: aload_0
    //   39: getfield B : Landroid/widget/ImageView;
    //   42: invokevirtual getVisibility : ()I
    //   45: ifeq -> 66
    //   48: aload_0
    //   49: getfield D : Landroid/widget/ImageView;
    //   52: invokevirtual getVisibility : ()I
    //   55: ifne -> 63
    //   58: iload_2
    //   59: istore_1
    //   60: goto -> 66
    //   63: bipush #8
    //   65: istore_1
    //   66: aload_0
    //   67: getfield z : Landroid/view/View;
    //   70: iload_1
    //   71: invokevirtual setVisibility : (I)V
    //   74: return
  }
  
  public final void z(boolean paramBoolean) {
    // Byte code:
    //   0: aload_0
    //   1: getfield c0 : Z
    //   4: istore #4
    //   6: iconst_0
    //   7: istore_3
    //   8: iload #4
    //   10: ifeq -> 68
    //   13: iload #4
    //   15: ifne -> 25
    //   18: aload_0
    //   19: getfield h0 : Z
    //   22: ifeq -> 37
    //   25: aload_0
    //   26: getfield a0 : Z
    //   29: ifne -> 37
    //   32: iconst_1
    //   33: istore_2
    //   34: goto -> 39
    //   37: iconst_0
    //   38: istore_2
    //   39: iload_2
    //   40: ifeq -> 68
    //   43: aload_0
    //   44: invokevirtual hasFocus : ()Z
    //   47: ifeq -> 68
    //   50: iload_3
    //   51: istore_2
    //   52: iload_1
    //   53: ifne -> 71
    //   56: aload_0
    //   57: getfield h0 : Z
    //   60: ifne -> 68
    //   63: iload_3
    //   64: istore_2
    //   65: goto -> 71
    //   68: bipush #8
    //   70: istore_2
    //   71: aload_0
    //   72: getfield B : Landroid/widget/ImageView;
    //   75: iload_2
    //   76: invokevirtual setVisibility : (I)V
    //   79: return
  }
  
  public static class SearchAutoComplete extends d {
    public int k = getThreshold();
    
    public SearchView l;
    
    public boolean m;
    
    public final Runnable n = new a(this);
    
    public SearchAutoComplete(Context param1Context, AttributeSet param1AttributeSet) {
      super(param1Context, param1AttributeSet, 2130968630);
    }
    
    private int getSearchViewTextMinWidthDp() {
      Configuration configuration = getResources().getConfiguration();
      int i = configuration.screenWidthDp;
      int j = configuration.screenHeightDp;
      return (i >= 960 && j >= 720 && configuration.orientation == 2) ? 256 : ((i >= 600 || (i >= 640 && j >= 480)) ? 192 : 160);
    }
    
    public void a() {
      if (Build.VERSION.SDK_INT >= 29) {
        setInputMethodMode(1);
        if (enoughToFilter()) {
          showDropDown();
          return;
        } 
      } else {
        SearchView.n n = SearchView.t0;
        Objects.requireNonNull(n);
        SearchView.n.a();
        Method method = n.c;
        if (method != null)
          try {
            method.invoke(this, new Object[] { Boolean.TRUE });
            return;
          } catch (Exception exception) {
            return;
          }  
      } 
    }
    
    public boolean enoughToFilter() {
      return (this.k <= 0 || super.enoughToFilter());
    }
    
    public InputConnection onCreateInputConnection(EditorInfo param1EditorInfo) {
      InputConnection inputConnection = super.onCreateInputConnection(param1EditorInfo);
      if (this.m) {
        removeCallbacks(this.n);
        post(this.n);
      } 
      return inputConnection;
    }
    
    public void onFinishInflate() {
      super.onFinishInflate();
      DisplayMetrics displayMetrics = getResources().getDisplayMetrics();
      setMinWidth((int)TypedValue.applyDimension(1, getSearchViewTextMinWidthDp(), displayMetrics));
    }
    
    public void onFocusChanged(boolean param1Boolean, int param1Int, Rect param1Rect) {
      super.onFocusChanged(param1Boolean, param1Int, param1Rect);
      SearchView searchView = this.l;
      searchView.A(searchView.a0);
      searchView.post(searchView.o0);
      if (searchView.w.hasFocus())
        searchView.n(); 
    }
    
    public boolean onKeyPreIme(int param1Int, KeyEvent param1KeyEvent) {
      if (param1Int == 4) {
        if (param1KeyEvent.getAction() == 0 && param1KeyEvent.getRepeatCount() == 0) {
          KeyEvent.DispatcherState dispatcherState = getKeyDispatcherState();
          if (dispatcherState != null)
            dispatcherState.startTracking(param1KeyEvent, this); 
          return true;
        } 
        if (param1KeyEvent.getAction() == 1) {
          KeyEvent.DispatcherState dispatcherState = getKeyDispatcherState();
          if (dispatcherState != null)
            dispatcherState.handleUpEvent(param1KeyEvent); 
          if (param1KeyEvent.isTracking() && !param1KeyEvent.isCanceled()) {
            this.l.clearFocus();
            setImeVisibility(false);
            return true;
          } 
        } 
      } 
      return super.onKeyPreIme(param1Int, param1KeyEvent);
    }
    
    public void onWindowFocusChanged(boolean param1Boolean) {
      super.onWindowFocusChanged(param1Boolean);
      if (param1Boolean && this.l.hasFocus() && getVisibility() == 0) {
        boolean bool = true;
        this.m = true;
        Context context = getContext();
        SearchView.n n = SearchView.t0;
        if ((context.getResources().getConfiguration()).orientation != 2)
          bool = false; 
        if (bool)
          a(); 
      } 
    }
    
    public void performCompletion() {}
    
    public void replaceText(CharSequence param1CharSequence) {}
    
    public void setImeVisibility(boolean param1Boolean) {
      InputMethodManager inputMethodManager = (InputMethodManager)getContext().getSystemService("input_method");
      if (!param1Boolean) {
        this.m = false;
        removeCallbacks(this.n);
        inputMethodManager.hideSoftInputFromWindow(getWindowToken(), 0);
        return;
      } 
      if (inputMethodManager.isActive((View)this)) {
        this.m = false;
        removeCallbacks(this.n);
        inputMethodManager.showSoftInput((View)this, 0);
        return;
      } 
      this.m = true;
    }
    
    public void setSearchView(SearchView param1SearchView) {
      this.l = param1SearchView;
    }
    
    public void setThreshold(int param1Int) {
      super.setThreshold(param1Int);
      this.k = param1Int;
    }
    
    public class a implements Runnable {
      public a(SearchView.SearchAutoComplete this$0) {}
      
      public void run() {
        SearchView.SearchAutoComplete searchAutoComplete = this.h;
        if (searchAutoComplete.m) {
          ((InputMethodManager)searchAutoComplete.getContext().getSystemService("input_method")).showSoftInput((View)searchAutoComplete, 0);
          searchAutoComplete.m = false;
        } 
      }
    }
  }
  
  public class a implements Runnable {
    public a(SearchView this$0) {}
    
    public void run() {
      SearchView.SearchAutoComplete searchAutoComplete = this.h;
      if (searchAutoComplete.m) {
        ((InputMethodManager)searchAutoComplete.getContext().getSystemService("input_method")).showSoftInput((View)searchAutoComplete, 0);
        searchAutoComplete.m = false;
      } 
    }
  }
  
  public class a implements TextWatcher {
    public a(SearchView this$0) {}
    
    public void afterTextChanged(Editable param1Editable) {}
    
    public void beforeTextChanged(CharSequence param1CharSequence, int param1Int1, int param1Int2, int param1Int3) {}
    
    public void onTextChanged(CharSequence param1CharSequence, int param1Int1, int param1Int2, int param1Int3) {
      SearchView searchView = this.h;
      Editable editable = searchView.w.getText();
      searchView.j0 = (CharSequence)editable;
      int i = TextUtils.isEmpty((CharSequence)editable) ^ true;
      searchView.z(i);
      searchView.B(i ^ 0x1);
      searchView.v();
      searchView.y();
      if (searchView.R != null && !TextUtils.equals(param1CharSequence, searchView.i0))
        searchView.R.a(param1CharSequence.toString()); 
      searchView.i0 = param1CharSequence.toString();
    }
  }
  
  public class b implements Runnable {
    public b(SearchView this$0) {}
    
    public void run() {
      this.h.w();
    }
  }
  
  public class c implements Runnable {
    public c(SearchView this$0) {}
    
    public void run() {
      n0.a a = this.h.b0;
      if (a instanceof t0)
        a.b(null); 
    }
  }
  
  public class d implements View.OnFocusChangeListener {
    public d(SearchView this$0) {}
    
    public void onFocusChange(View param1View, boolean param1Boolean) {
      SearchView searchView = this.a;
      View.OnFocusChangeListener onFocusChangeListener = searchView.T;
      if (onFocusChangeListener != null)
        onFocusChangeListener.onFocusChange((View)searchView, param1Boolean); 
    }
  }
  
  public class e implements View.OnLayoutChangeListener {
    public e(SearchView this$0) {}
    
    public void onLayoutChange(View param1View, int param1Int1, int param1Int2, int param1Int3, int param1Int4, int param1Int5, int param1Int6, int param1Int7, int param1Int8) {
      SearchView searchView = this.a;
      if (searchView.E.getWidth() > 1) {
        Resources resources = searchView.getContext().getResources();
        param1Int3 = searchView.y.getPaddingLeft();
        Rect rect = new Rect();
        boolean bool = g1.b((View)searchView);
        if (searchView.W) {
          param1Int1 = resources.getDimensionPixelSize(2131165943);
          param1Int1 = resources.getDimensionPixelSize(2131165944) + param1Int1;
        } else {
          param1Int1 = 0;
        } 
        searchView.w.getDropDownBackground().getPadding(rect);
        if (bool) {
          param1Int2 = -rect.left;
        } else {
          param1Int2 = param1Int3 - rect.left + param1Int1;
        } 
        searchView.w.setDropDownHorizontalOffset(param1Int2);
        param1Int2 = searchView.E.getWidth();
        param1Int4 = rect.left;
        param1Int5 = rect.right;
        searchView.w.setDropDownWidth(param1Int2 + param1Int4 + param1Int5 + param1Int1 - param1Int3);
      } 
    }
  }
  
  public class f implements View.OnClickListener {
    public f(SearchView this$0) {}
    
    public void onClick(View param1View) {
      SearchView searchView = this.h;
      if (param1View == searchView.A) {
        searchView.t();
        return;
      } 
      if (param1View == searchView.C) {
        searchView.p();
        return;
      } 
      if (param1View == searchView.B) {
        searchView.u();
        return;
      } 
      if (param1View == searchView.D) {
        SearchableInfo searchableInfo = searchView.m0;
        if (searchableInfo == null)
          return; 
        try {
          String str;
          if (searchableInfo.getVoiceSearchLaunchWebSearch()) {
            Intent intent = new Intent(searchView.O);
            ComponentName componentName = searchableInfo.getSearchActivity();
            if (componentName == null) {
              componentName = null;
            } else {
              str = componentName.flattenToShortString();
            } 
            intent.putExtra("calling_package", str);
            searchView.getContext().startActivity(intent);
            return;
          } 
          if (str.getVoiceSearchLaunchRecognizer()) {
            Intent intent = searchView.m(searchView.P, (SearchableInfo)str);
            searchView.getContext().startActivity(intent);
            return;
          } 
          return;
        } catch (ActivityNotFoundException activityNotFoundException) {
          Log.w("SearchView", "Could not find voice search activity");
          return;
        } 
      } 
      if (activityNotFoundException == searchView.w)
        searchView.n(); 
    }
  }
  
  public class g implements View.OnKeyListener {
    public g(SearchView this$0) {}
    
    public boolean onKey(View param1View, int param1Int, KeyEvent param1KeyEvent) {
      SearchView searchView1;
      boolean bool;
      SearchView searchView2 = this.h;
      SearchableInfo searchableInfo = searchView2.m0;
      boolean bool1 = false;
      if (searchableInfo == null)
        return false; 
      if (searchView2.w.isPopupShowing() && this.h.w.getListSelection() != -1) {
        searchView1 = this.h;
        if (searchView1.m0 == null)
          return false; 
        if (searchView1.b0 == null)
          return false; 
        boolean bool2 = bool1;
        if (param1KeyEvent.getAction() == 0) {
          bool2 = bool1;
          if (param1KeyEvent.hasNoModifiers()) {
            if (param1Int == 66 || param1Int == 84 || param1Int == 61)
              return searchView1.q(searchView1.w.getListSelection()); 
            if (param1Int == 21 || param1Int == 22) {
              if (param1Int == 21) {
                param1Int = 0;
              } else {
                param1Int = searchView1.w.length();
              } 
              searchView1.w.setSelection(param1Int);
              searchView1.w.setListSelection(0);
              searchView1.w.clearListSelection();
              searchView1.w.a();
              return true;
            } 
            bool2 = bool1;
            if (param1Int == 19) {
              searchView1.w.getListSelection();
              return false;
            } 
          } 
        } 
        return bool2;
      } 
      if (TextUtils.getTrimmedLength((CharSequence)this.h.w.getText()) == 0) {
        bool = true;
      } else {
        bool = false;
      } 
      if (!bool && param1KeyEvent.hasNoModifiers() && param1KeyEvent.getAction() == 1 && param1Int == 66) {
        searchView1.cancelLongPress();
        searchView1 = this.h;
        searchView1.o(0, null, searchView1.w.getText().toString());
        return true;
      } 
      return false;
    }
  }
  
  public class h implements TextView.OnEditorActionListener {
    public h(SearchView this$0) {}
    
    public boolean onEditorAction(TextView param1TextView, int param1Int, KeyEvent param1KeyEvent) {
      this.a.u();
      return true;
    }
  }
  
  public class i implements AdapterView.OnItemClickListener {
    public i(SearchView this$0) {}
    
    public void onItemClick(AdapterView<?> param1AdapterView, View param1View, int param1Int, long param1Long) {
      this.h.q(param1Int);
    }
  }
  
  public class j implements AdapterView.OnItemSelectedListener {
    public j(SearchView this$0) {}
    
    public void onItemSelected(AdapterView<?> param1AdapterView, View param1View, int param1Int, long param1Long) {
      this.h.r(param1Int);
    }
    
    public void onNothingSelected(AdapterView<?> param1AdapterView) {}
  }
  
  public static interface k {
    boolean a();
  }
  
  public static interface l {
    boolean a(String param1String);
    
    boolean b(String param1String);
  }
  
  public static interface m {
    boolean a(int param1Int);
    
    boolean b(int param1Int);
  }
  
  public static class n {
    public Method a = null;
    
    public Method b = null;
    
    public Method c = null;
    
    @SuppressLint({"DiscouragedPrivateApi", "SoonBlockedPrivateApi"})
    public n() {
      a();
      try {
        Method method = AutoCompleteTextView.class.getDeclaredMethod("doBeforeTextChanged", new Class[0]);
        this.a = method;
        method.setAccessible(true);
      } catch (NoSuchMethodException noSuchMethodException) {}
      try {
        Method method = AutoCompleteTextView.class.getDeclaredMethod("doAfterTextChanged", new Class[0]);
        this.b = method;
        method.setAccessible(true);
        try {
          method = AutoCompleteTextView.class.getMethod("ensureImeVisible", new Class[] { boolean.class });
          this.c = method;
          method.setAccessible(true);
          return;
        } catch (NoSuchMethodException noSuchMethodException) {}
      } catch (NoSuchMethodException noSuchMethodException) {
        try {
          Method method = AutoCompleteTextView.class.getMethod("ensureImeVisible", new Class[] { boolean.class });
          this.c = method;
          method.setAccessible(true);
          return;
        } catch (NoSuchMethodException noSuchMethodException1) {}
      } 
    }
    
    public static void a() {
      if (Build.VERSION.SDK_INT < 29)
        return; 
      throw new UnsupportedClassVersionError("This function can only be used for API Level < 29.");
    }
  }
  
  public static class o extends o0.a {
    public static final Parcelable.Creator<o> CREATOR = (Parcelable.Creator<o>)new a();
    
    public boolean j;
    
    public o(Parcel param1Parcel, ClassLoader param1ClassLoader) {
      super(param1Parcel, param1ClassLoader);
      this.j = ((Boolean)param1Parcel.readValue(null)).booleanValue();
    }
    
    public o(Parcelable param1Parcelable) {
      super(param1Parcelable);
    }
    
    public String toString() {
      StringBuilder stringBuilder = android.support.v4.media.c.a("SearchView.SavedState{");
      stringBuilder.append(Integer.toHexString(System.identityHashCode(this)));
      stringBuilder.append(" isIconified=");
      stringBuilder.append(this.j);
      stringBuilder.append("}");
      return stringBuilder.toString();
    }
    
    public void writeToParcel(Parcel param1Parcel, int param1Int) {
      param1Parcel.writeParcelable(this.h, param1Int);
      param1Parcel.writeValue(Boolean.valueOf(this.j));
    }
    
    public class a implements Parcelable.ClassLoaderCreator<o> {
      public Object createFromParcel(Parcel param2Parcel) {
        return new SearchView.o(param2Parcel, null);
      }
      
      public Object createFromParcel(Parcel param2Parcel, ClassLoader param2ClassLoader) {
        return new SearchView.o(param2Parcel, param2ClassLoader);
      }
      
      public Object[] newArray(int param2Int) {
        return (Object[])new SearchView.o[param2Int];
      }
    }
  }
  
  public class a implements Parcelable.ClassLoaderCreator<o> {
    public Object createFromParcel(Parcel param1Parcel) {
      return new SearchView.o(param1Parcel, null);
    }
    
    public Object createFromParcel(Parcel param1Parcel, ClassLoader param1ClassLoader) {
      return new SearchView.o(param1Parcel, param1ClassLoader);
    }
    
    public Object[] newArray(int param1Int) {
      return (Object[])new SearchView.o[param1Int];
    }
  }
  
  public static class p extends TouchDelegate {
    public final View a;
    
    public final Rect b;
    
    public final Rect c;
    
    public final Rect d;
    
    public final int e;
    
    public boolean f;
    
    public p(Rect param1Rect1, Rect param1Rect2, View param1View) {
      super(param1Rect1, param1View);
      this.e = ViewConfiguration.get(param1View.getContext()).getScaledTouchSlop();
      this.b = new Rect();
      this.d = new Rect();
      this.c = new Rect();
      a(param1Rect1, param1Rect2);
      this.a = param1View;
    }
    
    public void a(Rect param1Rect1, Rect param1Rect2) {
      this.b.set(param1Rect1);
      this.d.set(param1Rect1);
      param1Rect1 = this.d;
      int i = this.e;
      param1Rect1.inset(-i, -i);
      this.c.set(param1Rect2);
    }
    
    public boolean onTouchEvent(MotionEvent param1MotionEvent) {
      // Byte code:
      //   0: aload_1
      //   1: invokevirtual getX : ()F
      //   4: f2i
      //   5: istore #4
      //   7: aload_1
      //   8: invokevirtual getY : ()F
      //   11: f2i
      //   12: istore #5
      //   14: aload_1
      //   15: invokevirtual getAction : ()I
      //   18: istore_3
      //   19: iconst_1
      //   20: istore #6
      //   22: iconst_0
      //   23: istore #8
      //   25: iload_3
      //   26: ifeq -> 108
      //   29: iload_3
      //   30: iconst_1
      //   31: if_icmpeq -> 61
      //   34: iload_3
      //   35: iconst_2
      //   36: if_icmpeq -> 61
      //   39: iload_3
      //   40: iconst_3
      //   41: if_icmpeq -> 47
      //   44: goto -> 130
      //   47: aload_0
      //   48: getfield f : Z
      //   51: istore #6
      //   53: aload_0
      //   54: iconst_0
      //   55: putfield f : Z
      //   58: goto -> 103
      //   61: aload_0
      //   62: getfield f : Z
      //   65: istore #7
      //   67: iload #7
      //   69: istore #6
      //   71: iload #7
      //   73: ifeq -> 103
      //   76: iload #7
      //   78: istore #6
      //   80: aload_0
      //   81: getfield d : Landroid/graphics/Rect;
      //   84: iload #4
      //   86: iload #5
      //   88: invokevirtual contains : (II)Z
      //   91: ifne -> 103
      //   94: iload #7
      //   96: istore #6
      //   98: iconst_0
      //   99: istore_3
      //   100: goto -> 135
      //   103: iconst_1
      //   104: istore_3
      //   105: goto -> 135
      //   108: aload_0
      //   109: getfield b : Landroid/graphics/Rect;
      //   112: iload #4
      //   114: iload #5
      //   116: invokevirtual contains : (II)Z
      //   119: ifeq -> 130
      //   122: aload_0
      //   123: iconst_1
      //   124: putfield f : Z
      //   127: goto -> 103
      //   130: iconst_1
      //   131: istore_3
      //   132: iconst_0
      //   133: istore #6
      //   135: iload #8
      //   137: istore #7
      //   139: iload #6
      //   141: ifeq -> 228
      //   144: iload_3
      //   145: ifeq -> 186
      //   148: aload_0
      //   149: getfield c : Landroid/graphics/Rect;
      //   152: iload #4
      //   154: iload #5
      //   156: invokevirtual contains : (II)Z
      //   159: ifne -> 186
      //   162: aload_0
      //   163: getfield a : Landroid/view/View;
      //   166: invokevirtual getWidth : ()I
      //   169: iconst_2
      //   170: idiv
      //   171: i2f
      //   172: fstore_2
      //   173: aload_0
      //   174: getfield a : Landroid/view/View;
      //   177: invokevirtual getHeight : ()I
      //   180: iconst_2
      //   181: idiv
      //   182: istore_3
      //   183: goto -> 211
      //   186: aload_0
      //   187: getfield c : Landroid/graphics/Rect;
      //   190: astore #9
      //   192: iload #4
      //   194: aload #9
      //   196: getfield left : I
      //   199: isub
      //   200: i2f
      //   201: fstore_2
      //   202: iload #5
      //   204: aload #9
      //   206: getfield top : I
      //   209: isub
      //   210: istore_3
      //   211: aload_1
      //   212: fload_2
      //   213: iload_3
      //   214: i2f
      //   215: invokevirtual setLocation : (FF)V
      //   218: aload_0
      //   219: getfield a : Landroid/view/View;
      //   222: aload_1
      //   223: invokevirtual dispatchTouchEvent : (Landroid/view/MotionEvent;)Z
      //   226: istore #7
      //   228: iload #7
      //   230: ireturn
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Luxury Logo Maker_ Logo Design-dex2jar.jar!\androidx\appcompat\widget\SearchView.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */