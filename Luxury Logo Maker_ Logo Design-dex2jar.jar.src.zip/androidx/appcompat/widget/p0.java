package androidx.appcompat.widget;

import android.content.res.Resources;

public class p0 extends Resources {}


/* Location:              C:\soft\dex2jar-2.0\Luxury Logo Maker_ Logo Design-dex2jar.jar!\androidx\appcompat\widget\p0.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */