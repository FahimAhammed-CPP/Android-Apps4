package androidx.appcompat.widget;

import android.content.Context;
import android.graphics.drawable.Drawable;
import android.os.Build;
import android.util.AttributeSet;
import android.util.Log;
import android.view.KeyEvent;
import android.view.MenuItem;
import android.view.MotionEvent;
import android.view.View;
import android.widget.HeaderViewListAdapter;
import android.widget.ListAdapter;
import android.widget.PopupWindow;
import androidx.appcompat.view.menu.ListMenuItemView;
import androidx.appcompat.view.menu.d;
import androidx.appcompat.view.menu.e;
import androidx.appcompat.view.menu.g;
import java.lang.reflect.Method;

public class n0 extends l0 implements m0 {
  public static Method K;
  
  public m0 J;
  
  static {
    try {
      if (Build.VERSION.SDK_INT <= 28) {
        K = PopupWindow.class.getDeclaredMethod("setTouchModal", new Class[] { boolean.class });
        return;
      } 
    } catch (NoSuchMethodException noSuchMethodException) {
      Log.i("MenuPopupWindow", "Could not find method setTouchModal() on PopupWindow. Oh well.");
    } 
  }
  
  public n0(Context paramContext, AttributeSet paramAttributeSet, int paramInt1, int paramInt2) {
    super(paramContext, null, paramInt1, paramInt2);
  }
  
  public void a(e parame, MenuItem paramMenuItem) {
    m0 m01 = this.J;
    if (m01 != null)
      m01.a(parame, paramMenuItem); 
  }
  
  public void e(e parame, MenuItem paramMenuItem) {
    m0 m01 = this.J;
    if (m01 != null)
      m01.e(parame, paramMenuItem); 
  }
  
  public g0 q(Context paramContext, boolean paramBoolean) {
    a a = new a(paramContext, paramBoolean);
    a.setHoverListener(this);
    return a;
  }
  
  public static class a extends g0 {
    public final int u;
    
    public final int v;
    
    public m0 w;
    
    public MenuItem x;
    
    public a(Context param1Context, boolean param1Boolean) {
      super(param1Context, param1Boolean);
      if (1 == param1Context.getResources().getConfiguration().getLayoutDirection()) {
        this.u = 21;
        this.v = 22;
        return;
      } 
      this.u = 22;
      this.v = 21;
    }
    
    public boolean onHoverEvent(MotionEvent param1MotionEvent) {
      if (this.w != null) {
        int i;
        g g;
        ListAdapter listAdapter1 = getAdapter();
        if (listAdapter1 instanceof HeaderViewListAdapter) {
          HeaderViewListAdapter headerViewListAdapter = (HeaderViewListAdapter)listAdapter1;
          i = headerViewListAdapter.getHeadersCount();
          listAdapter1 = headerViewListAdapter.getWrappedAdapter();
        } else {
          i = 0;
        } 
        d d = (d)listAdapter1;
        ListAdapter listAdapter2 = null;
        listAdapter1 = listAdapter2;
        if (param1MotionEvent.getAction() != 10) {
          int j = pointToPosition((int)param1MotionEvent.getX(), (int)param1MotionEvent.getY());
          listAdapter1 = listAdapter2;
          if (j != -1) {
            i = j - i;
            listAdapter1 = listAdapter2;
            if (i >= 0) {
              listAdapter1 = listAdapter2;
              if (i < d.getCount())
                g = d.b(i); 
            } 
          } 
        } 
        MenuItem menuItem = this.x;
        if (menuItem != g) {
          e e = d.h;
          if (menuItem != null)
            this.w.e(e, menuItem); 
          this.x = (MenuItem)g;
          if (g != null)
            this.w.a(e, (MenuItem)g); 
        } 
      } 
      return super.onHoverEvent(param1MotionEvent);
    }
    
    public boolean onKeyDown(int param1Int, KeyEvent param1KeyEvent) {
      ListMenuItemView listMenuItemView = (ListMenuItemView)getSelectedView();
      if (listMenuItemView != null && param1Int == this.u) {
        if (listMenuItemView.isEnabled() && listMenuItemView.getItemData().hasSubMenu())
          performItemClick((View)listMenuItemView, getSelectedItemPosition(), getSelectedItemId()); 
        return true;
      } 
      if (listMenuItemView != null && param1Int == this.v) {
        setSelection(-1);
        ((d)getAdapter()).h.c(false);
        return true;
      } 
      return super.onKeyDown(param1Int, param1KeyEvent);
    }
    
    public void setHoverListener(m0 param1m0) {
      this.w = param1m0;
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Luxury Logo Maker_ Logo Design-dex2jar.jar!\androidx\appcompat\widget\n0.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */