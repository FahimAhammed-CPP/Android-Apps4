package android.support.v4.media;

import android.graphics.Bitmap;
import android.media.MediaDescription;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Parcel;
import android.os.Parcelable;
import android.support.v4.media.session.MediaSessionCompat;

public final class MediaDescriptionCompat implements Parcelable {
  public static final Parcelable.Creator<MediaDescriptionCompat> CREATOR = new a();
  
  public final String h;
  
  public final CharSequence i;
  
  public final CharSequence j;
  
  public final CharSequence k;
  
  public final Bitmap l;
  
  public final Uri m;
  
  public final Bundle n;
  
  public final Uri o;
  
  public Object p;
  
  public MediaDescriptionCompat(String paramString, CharSequence paramCharSequence1, CharSequence paramCharSequence2, CharSequence paramCharSequence3, Bitmap paramBitmap, Uri paramUri1, Bundle paramBundle, Uri paramUri2) {
    this.h = paramString;
    this.i = paramCharSequence1;
    this.j = paramCharSequence2;
    this.k = paramCharSequence3;
    this.l = paramBitmap;
    this.m = paramUri1;
    this.n = paramBundle;
    this.o = paramUri2;
  }
  
  public static MediaDescriptionCompat b(Object paramObject) {
    MediaDescriptionCompat mediaDescriptionCompat;
    Uri uri1 = null;
    Uri uri2 = null;
    if (paramObject != null) {
      int i = Build.VERSION.SDK_INT;
      MediaDescription mediaDescription = (MediaDescription)paramObject;
      String str = mediaDescription.getMediaId();
      CharSequence charSequence1 = mediaDescription.getTitle();
      CharSequence charSequence2 = mediaDescription.getSubtitle();
      CharSequence charSequence3 = mediaDescription.getDescription();
      Bitmap bitmap = mediaDescription.getIconBitmap();
      Uri uri = mediaDescription.getIconUri();
      Bundle bundle = mediaDescription.getExtras();
      if (bundle != null) {
        MediaSessionCompat.a(bundle);
        uri1 = (Uri)bundle.getParcelable("android.support.v4.media.description.MEDIA_URI");
      } else {
        uri1 = null;
      } 
      if (uri1 != null)
        if (bundle.containsKey("android.support.v4.media.description.NULL_BUNDLE_FLAG") && bundle.size() == 2) {
          bundle = null;
        } else {
          bundle.remove("android.support.v4.media.description.MEDIA_URI");
          bundle.remove("android.support.v4.media.description.NULL_BUNDLE_FLAG");
        }  
      if (uri1 == null) {
        uri1 = uri2;
        if (i >= 23)
          uri1 = mediaDescription.getMediaUri(); 
      } 
      mediaDescriptionCompat = new MediaDescriptionCompat(str, charSequence1, charSequence2, charSequence3, bitmap, uri, bundle, uri1);
      mediaDescriptionCompat.p = paramObject;
    } 
    return mediaDescriptionCompat;
  }
  
  public int describeContents() {
    return 0;
  }
  
  public String toString() {
    StringBuilder stringBuilder = new StringBuilder();
    stringBuilder.append(this.i);
    stringBuilder.append(", ");
    stringBuilder.append(this.j);
    stringBuilder.append(", ");
    stringBuilder.append(this.k);
    return stringBuilder.toString();
  }
  
  public void writeToParcel(Parcel paramParcel, int paramInt) {
    int i = Build.VERSION.SDK_INT;
    Object object2 = this.p;
    Object object1 = object2;
    if (object2 == null) {
      MediaDescription.Builder builder = new MediaDescription.Builder();
      builder.setMediaId(this.h);
      builder.setTitle(this.i);
      builder.setSubtitle(this.j);
      builder.setDescription(this.k);
      builder.setIconBitmap(this.l);
      builder.setIconUri(this.m);
      object2 = this.n;
      object1 = object2;
      if (i < 23) {
        object1 = object2;
        if (this.o != null) {
          object1 = object2;
          if (object2 == null) {
            object1 = new Bundle();
            object1.putBoolean("android.support.v4.media.description.NULL_BUNDLE_FLAG", true);
          } 
          object1.putParcelable("android.support.v4.media.description.MEDIA_URI", (Parcelable)this.o);
        } 
      } 
      builder.setExtras((Bundle)object1);
      if (i >= 23)
        builder.setMediaUri(this.o); 
      object1 = builder.build();
      this.p = object1;
    } 
    ((MediaDescription)object1).writeToParcel(paramParcel, paramInt);
  }
  
  public static final class a implements Parcelable.Creator<MediaDescriptionCompat> {
    public Object createFromParcel(Parcel param1Parcel) {
      return MediaDescriptionCompat.b(MediaDescription.CREATOR.createFromParcel(param1Parcel));
    }
    
    public Object[] newArray(int param1Int) {
      return (Object[])new MediaDescriptionCompat[param1Int];
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Luxury Logo Maker_ Logo Design-dex2jar.jar!\android\support\v4\media\MediaDescriptionCompat.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */