package android.support.v4.media;

import android.os.Parcel;
import android.os.Parcelable;

public final class RatingCompat implements Parcelable {
  public static final Parcelable.Creator<RatingCompat> CREATOR = new a();
  
  public final int h;
  
  public final float i;
  
  public RatingCompat(int paramInt, float paramFloat) {
    this.h = paramInt;
    this.i = paramFloat;
  }
  
  public int describeContents() {
    return this.h;
  }
  
  public String toString() {
    String str;
    StringBuilder stringBuilder = c.a("Rating:style=");
    stringBuilder.append(this.h);
    stringBuilder.append(" rating=");
    float f = this.i;
    if (f < 0.0F) {
      str = "unrated";
    } else {
      str = String.valueOf(f);
    } 
    stringBuilder.append(str);
    return stringBuilder.toString();
  }
  
  public void writeToParcel(Parcel paramParcel, int paramInt) {
    paramParcel.writeInt(this.h);
    paramParcel.writeFloat(this.i);
  }
  
  public static final class a implements Parcelable.Creator<RatingCompat> {
    public Object createFromParcel(Parcel param1Parcel) {
      return new RatingCompat(param1Parcel.readInt(), param1Parcel.readFloat());
    }
    
    public Object[] newArray(int param1Int) {
      return (Object[])new RatingCompat[param1Int];
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Luxury Logo Maker_ Logo Design-dex2jar.jar!\android\support\v4\media\RatingCompat.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */