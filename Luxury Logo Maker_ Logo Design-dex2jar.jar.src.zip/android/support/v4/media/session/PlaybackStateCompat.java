package android.support.v4.media.session;

import android.os.Bundle;
import android.os.Parcel;
import android.os.Parcelable;
import android.support.v4.media.c;
import android.text.TextUtils;
import java.util.List;

public final class PlaybackStateCompat implements Parcelable {
  public static final Parcelable.Creator<PlaybackStateCompat> CREATOR = new a();
  
  public final int h;
  
  public final long i;
  
  public final long j;
  
  public final float k;
  
  public final long l;
  
  public final int m;
  
  public final CharSequence n;
  
  public final long o;
  
  public List<CustomAction> p;
  
  public final long q;
  
  public final Bundle r;
  
  public PlaybackStateCompat(Parcel paramParcel) {
    this.h = paramParcel.readInt();
    this.i = paramParcel.readLong();
    this.k = paramParcel.readFloat();
    this.o = paramParcel.readLong();
    this.j = paramParcel.readLong();
    this.l = paramParcel.readLong();
    this.n = (CharSequence)TextUtils.CHAR_SEQUENCE_CREATOR.createFromParcel(paramParcel);
    this.p = paramParcel.createTypedArrayList(CustomAction.CREATOR);
    this.q = paramParcel.readLong();
    this.r = paramParcel.readBundle(MediaSessionCompat.class.getClassLoader());
    this.m = paramParcel.readInt();
  }
  
  public int describeContents() {
    return 0;
  }
  
  public String toString() {
    StringBuilder stringBuilder = new StringBuilder("PlaybackState {");
    stringBuilder.append("state=");
    stringBuilder.append(this.h);
    stringBuilder.append(", position=");
    stringBuilder.append(this.i);
    stringBuilder.append(", buffered position=");
    stringBuilder.append(this.j);
    stringBuilder.append(", speed=");
    stringBuilder.append(this.k);
    stringBuilder.append(", updated=");
    stringBuilder.append(this.o);
    stringBuilder.append(", actions=");
    stringBuilder.append(this.l);
    stringBuilder.append(", error code=");
    stringBuilder.append(this.m);
    stringBuilder.append(", error message=");
    stringBuilder.append(this.n);
    stringBuilder.append(", custom actions=");
    stringBuilder.append(this.p);
    stringBuilder.append(", active item id=");
    stringBuilder.append(this.q);
    stringBuilder.append("}");
    return stringBuilder.toString();
  }
  
  public void writeToParcel(Parcel paramParcel, int paramInt) {
    paramParcel.writeInt(this.h);
    paramParcel.writeLong(this.i);
    paramParcel.writeFloat(this.k);
    paramParcel.writeLong(this.o);
    paramParcel.writeLong(this.j);
    paramParcel.writeLong(this.l);
    TextUtils.writeToParcel(this.n, paramParcel, paramInt);
    paramParcel.writeTypedList(this.p);
    paramParcel.writeLong(this.q);
    paramParcel.writeBundle(this.r);
    paramParcel.writeInt(this.m);
  }
  
  public static final class CustomAction implements Parcelable {
    public static final Parcelable.Creator<CustomAction> CREATOR = new a();
    
    public final String h;
    
    public final CharSequence i;
    
    public final int j;
    
    public final Bundle k;
    
    public CustomAction(Parcel param1Parcel) {
      this.h = param1Parcel.readString();
      this.i = (CharSequence)TextUtils.CHAR_SEQUENCE_CREATOR.createFromParcel(param1Parcel);
      this.j = param1Parcel.readInt();
      this.k = param1Parcel.readBundle(MediaSessionCompat.class.getClassLoader());
    }
    
    public int describeContents() {
      return 0;
    }
    
    public String toString() {
      StringBuilder stringBuilder = c.a("Action:mName='");
      stringBuilder.append(this.i);
      stringBuilder.append(", mIcon=");
      stringBuilder.append(this.j);
      stringBuilder.append(", mExtras=");
      stringBuilder.append(this.k);
      return stringBuilder.toString();
    }
    
    public void writeToParcel(Parcel param1Parcel, int param1Int) {
      param1Parcel.writeString(this.h);
      TextUtils.writeToParcel(this.i, param1Parcel, param1Int);
      param1Parcel.writeInt(this.j);
      param1Parcel.writeBundle(this.k);
    }
    
    public static final class a implements Parcelable.Creator<CustomAction> {
      public Object createFromParcel(Parcel param2Parcel) {
        return new PlaybackStateCompat.CustomAction(param2Parcel);
      }
      
      public Object[] newArray(int param2Int) {
        return (Object[])new PlaybackStateCompat.CustomAction[param2Int];
      }
    }
  }
  
  public static final class a implements Parcelable.Creator<CustomAction> {
    public Object createFromParcel(Parcel param1Parcel) {
      return new PlaybackStateCompat.CustomAction(param1Parcel);
    }
    
    public Object[] newArray(int param1Int) {
      return (Object[])new PlaybackStateCompat.CustomAction[param1Int];
    }
  }
  
  public static final class a implements Parcelable.Creator<PlaybackStateCompat> {
    public Object createFromParcel(Parcel param1Parcel) {
      return new PlaybackStateCompat(param1Parcel);
    }
    
    public Object[] newArray(int param1Int) {
      return (Object[])new PlaybackStateCompat[param1Int];
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Luxury Logo Maker_ Logo Design-dex2jar.jar!\android\support\v4\media\session\PlaybackStateCompat.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */