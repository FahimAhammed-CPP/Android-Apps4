package android.support.v4.media.session;

import android.os.Bundle;
import android.os.Parcel;
import android.os.Parcelable;
import android.os.ResultReceiver;
import android.support.v4.media.MediaDescriptionCompat;
import android.support.v4.media.c;

public class MediaSessionCompat {
  public static void a(Bundle paramBundle) {
    if (paramBundle != null)
      paramBundle.setClassLoader(MediaSessionCompat.class.getClassLoader()); 
  }
  
  public static final class QueueItem implements Parcelable {
    public static final Parcelable.Creator<QueueItem> CREATOR = new a();
    
    public final MediaDescriptionCompat h;
    
    public final long i;
    
    public QueueItem(Parcel param1Parcel) {
      this.h = (MediaDescriptionCompat)MediaDescriptionCompat.CREATOR.createFromParcel(param1Parcel);
      this.i = param1Parcel.readLong();
    }
    
    public int describeContents() {
      return 0;
    }
    
    public String toString() {
      StringBuilder stringBuilder = c.a("MediaSession.QueueItem {Description=");
      stringBuilder.append(this.h);
      stringBuilder.append(", Id=");
      stringBuilder.append(this.i);
      stringBuilder.append(" }");
      return stringBuilder.toString();
    }
    
    public void writeToParcel(Parcel param1Parcel, int param1Int) {
      this.h.writeToParcel(param1Parcel, param1Int);
      param1Parcel.writeLong(this.i);
    }
    
    public static final class a implements Parcelable.Creator<QueueItem> {
      public Object createFromParcel(Parcel param2Parcel) {
        return new MediaSessionCompat.QueueItem(param2Parcel);
      }
      
      public Object[] newArray(int param2Int) {
        return (Object[])new MediaSessionCompat.QueueItem[param2Int];
      }
    }
  }
  
  public static final class a implements Parcelable.Creator<QueueItem> {
    public Object createFromParcel(Parcel param1Parcel) {
      return new MediaSessionCompat.QueueItem(param1Parcel);
    }
    
    public Object[] newArray(int param1Int) {
      return (Object[])new MediaSessionCompat.QueueItem[param1Int];
    }
  }
  
  public static final class ResultReceiverWrapper implements Parcelable {
    public static final Parcelable.Creator<ResultReceiverWrapper> CREATOR = new a();
    
    public ResultReceiver h;
    
    public ResultReceiverWrapper(Parcel param1Parcel) {
      this.h = (ResultReceiver)ResultReceiver.CREATOR.createFromParcel(param1Parcel);
    }
    
    public int describeContents() {
      return 0;
    }
    
    public void writeToParcel(Parcel param1Parcel, int param1Int) {
      this.h.writeToParcel(param1Parcel, param1Int);
    }
    
    public static final class a implements Parcelable.Creator<ResultReceiverWrapper> {
      public Object createFromParcel(Parcel param2Parcel) {
        return new MediaSessionCompat.ResultReceiverWrapper(param2Parcel);
      }
      
      public Object[] newArray(int param2Int) {
        return (Object[])new MediaSessionCompat.ResultReceiverWrapper[param2Int];
      }
    }
  }
  
  public static final class a implements Parcelable.Creator<ResultReceiverWrapper> {
    public Object createFromParcel(Parcel param1Parcel) {
      return new MediaSessionCompat.ResultReceiverWrapper(param1Parcel);
    }
    
    public Object[] newArray(int param1Int) {
      return (Object[])new MediaSessionCompat.ResultReceiverWrapper[param1Int];
    }
  }
  
  public static final class Token implements Parcelable {
    public static final Parcelable.Creator<Token> CREATOR = new a();
    
    public final Object h;
    
    public a i;
    
    public Token(Object param1Object) {
      this.h = param1Object;
      this.i = null;
    }
    
    public int describeContents() {
      return 0;
    }
    
    public boolean equals(Object param1Object) {
      if (this == param1Object)
        return true; 
      if (!(param1Object instanceof Token))
        return false; 
      Token token = (Token)param1Object;
      param1Object = this.h;
      Object object = token.h;
      return (param1Object == null) ? ((object == null)) : ((object == null) ? false : param1Object.equals(object));
    }
    
    public int hashCode() {
      Object object = this.h;
      return (object == null) ? 0 : object.hashCode();
    }
    
    public void writeToParcel(Parcel param1Parcel, int param1Int) {
      param1Parcel.writeParcelable((Parcelable)this.h, param1Int);
    }
    
    public static final class a implements Parcelable.Creator<Token> {
      public Object createFromParcel(Parcel param2Parcel) {
        return new MediaSessionCompat.Token(param2Parcel.readParcelable(null));
      }
      
      public Object[] newArray(int param2Int) {
        return (Object[])new MediaSessionCompat.Token[param2Int];
      }
    }
  }
  
  public static final class a implements Parcelable.Creator<Token> {
    public Object createFromParcel(Parcel param1Parcel) {
      return new MediaSessionCompat.Token(param1Parcel.readParcelable(null));
    }
    
    public Object[] newArray(int param1Int) {
      return (Object[])new MediaSessionCompat.Token[param1Int];
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Luxury Logo Maker_ Logo Design-dex2jar.jar!\android\support\v4\media\session\MediaSessionCompat.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */