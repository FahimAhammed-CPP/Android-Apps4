package android.support.v4.media;

import a6.a;
import android.graphics.Path;
import android.graphics.Typeface;
import e4.xd2;
import e4.yd2;
import o3.a;
import z2.a;
import z2.i;

public abstract class b {
  public static b a;
  
  public static b q(Class paramClass) {
    return (b)(System.getProperty("java.vm.name").equalsIgnoreCase("Dalvik") ? new xd2(paramClass.getSimpleName()) : new yd2(paramClass.getSimpleName()));
  }
  
  public static int s(int paramInt1, int paramInt2) {
    int i = paramInt1 + (paramInt1 >> 1) + 1;
    paramInt1 = i;
    if (i < paramInt2) {
      paramInt1 = Integer.highestOneBit(paramInt2 - 1);
      paramInt1 += paramInt1;
    } 
    paramInt2 = paramInt1;
    if (paramInt1 < 0)
      paramInt2 = Integer.MAX_VALUE; 
    return paramInt2;
  }
  
  public abstract void a(Runnable paramRunnable);
  
  public abstract Path b(float paramFloat1, float paramFloat2, float paramFloat3, float paramFloat4);
  
  public abstract boolean c();
  
  public abstract void d();
  
  public abstract void e(i parami);
  
  public void f(a parama) {}
  
  public abstract void g(Object paramObject);
  
  public abstract void h();
  
  public abstract void i(String paramString);
  
  public abstract void j(int paramInt);
  
  public abstract void k(Typeface paramTypeface, boolean paramBoolean);
  
  public abstract void l(a parama);
  
  public abstract void m(Runnable paramRunnable);
  
  public abstract void n(a parama);
  
  public abstract void o(String paramString);
  
  public abstract void p(byte[] paramArrayOfbyte, int paramInt1, int paramInt2);
  
  public abstract b r(Object paramObject);
}


/* Location:              C:\soft\dex2jar-2.0\Luxury Logo Maker_ Logo Design-dex2jar.jar!\android\support\v4\media\b.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */