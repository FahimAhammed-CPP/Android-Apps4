package c3;

import android.graphics.drawable.Drawable;
import android.net.Uri;

@Deprecated
public abstract class c {
  public abstract Drawable a();
  
  public abstract double b();
  
  public abstract Uri c();
  
  public int d() {
    return -1;
  }
  
  public int e() {
    return -1;
  }
}


/* Location:              C:\soft\dex2jar-2.0\Luxury Logo Maker_ Logo Design-dex2jar.jar!\c3\c.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */