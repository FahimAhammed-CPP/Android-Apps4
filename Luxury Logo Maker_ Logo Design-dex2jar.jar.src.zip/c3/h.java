package c3;

import android.content.Context;
import android.widget.RelativeLayout;

@Deprecated
public final class h extends RelativeLayout {
  public h(Context paramContext) {
    super(paramContext);
  }
}


/* Location:              C:\soft\dex2jar-2.0\Luxury Logo Maker_ Logo Design-dex2jar.jar!\c3\h.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */