package c3;

import android.content.Context;
import android.widget.FrameLayout;
import android.widget.ImageView;
import z2.j;

@Deprecated
public class b extends FrameLayout {
  public b(Context paramContext) {
    super(paramContext);
  }
  
  public void setImageScaleType(ImageView.ScaleType paramScaleType) {}
  
  public void setMediaContent(j paramj) {}
}


/* Location:              C:\soft\dex2jar-2.0\Luxury Logo Maker_ Logo Design-dex2jar.jar!\c3\b.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */