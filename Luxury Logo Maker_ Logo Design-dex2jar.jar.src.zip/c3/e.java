package c3;

@Deprecated
public interface e {
  public static interface a {}
  
  public static interface b {}
}


/* Location:              C:\soft\dex2jar-2.0\Luxury Logo Maker_ Logo Design-dex2jar.jar!\c3\e.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */