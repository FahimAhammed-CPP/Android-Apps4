package c3;

import android.os.IBinder;
import android.os.Parcel;
import android.os.Parcelable;
import x3.b;

public final class i implements Parcelable.Creator {
  public final Object createFromParcel(Parcel paramParcel) {
    int j = b.r(paramParcel);
    boolean bool = false;
    IBinder iBinder = null;
    while (paramParcel.dataPosition() < j) {
      int k = paramParcel.readInt();
      char c = (char)k;
      if (c != '\001') {
        if (c != '\002') {
          b.q(paramParcel, k);
          continue;
        } 
        iBinder = b.m(paramParcel, k);
        continue;
      } 
      bool = b.k(paramParcel, k);
    } 
    b.j(paramParcel, j);
    return new a(bool, iBinder);
  }
}


/* Location:              C:\soft\dex2jar-2.0\Luxury Logo Maker_ Logo Design-dex2jar.jar!\c3\i.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */