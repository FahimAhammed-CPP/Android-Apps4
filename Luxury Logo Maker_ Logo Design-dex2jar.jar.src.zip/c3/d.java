package c3;

import z2.o;

@Deprecated
public final class d {
  public final boolean a;
  
  public final int b;
  
  public final int c;
  
  public final boolean d;
  
  public final int e;
  
  public final o f;
  
  public final boolean g;
  
  public static final class a {
    public boolean a = false;
    
    public int b = -1;
    
    public int c = 0;
    
    public boolean d = false;
    
    public o e;
    
    public int f = 1;
    
    public boolean g = false;
  }
}


/* Location:              C:\soft\dex2jar-2.0\Luxury Logo Maker_ Logo Design-dex2jar.jar!\c3\d.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */