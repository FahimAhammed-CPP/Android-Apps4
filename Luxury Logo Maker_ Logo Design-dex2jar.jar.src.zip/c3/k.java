package c3;

import android.os.IBinder;
import android.os.Parcel;
import android.os.Parcelable;
import x3.b;

public final class k implements Parcelable.Creator {
  public final Object createFromParcel(Parcel paramParcel) {
    int i = b.r(paramParcel);
    IBinder iBinder2 = null;
    IBinder iBinder1 = null;
    boolean bool;
    for (bool = false; paramParcel.dataPosition() < i; bool = b.k(paramParcel, j)) {
      int j = paramParcel.readInt();
      char c = (char)j;
      if (c != '\001') {
        if (c != '\002') {
          if (c != '\003') {
            b.q(paramParcel, j);
            continue;
          } 
          iBinder1 = b.m(paramParcel, j);
          continue;
        } 
        iBinder2 = b.m(paramParcel, j);
        continue;
      } 
    } 
    b.j(paramParcel, i);
    return new f(bool, iBinder2, iBinder1);
  }
}


/* Location:              C:\soft\dex2jar-2.0\Luxury Logo Maker_ Logo Design-dex2jar.jar!\c3\k.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */