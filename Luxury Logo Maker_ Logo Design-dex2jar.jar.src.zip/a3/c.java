package a3;

public interface c {
  void a(String paramString1, String paramString2);
}


/* Location:              C:\soft\dex2jar-2.0\Luxury Logo Maker_ Logo Design-dex2jar.jar!\a3\c.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */