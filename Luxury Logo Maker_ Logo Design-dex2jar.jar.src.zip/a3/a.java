package a3;

import android.os.RemoteException;
import e4.a80;
import f3.d2;
import f3.f0;
import f3.y2;
import z2.f;
import z2.h;
import z2.n;
import z2.o;

public final class a extends h {
  public f[] getAdSizes() {
    return this.h.g;
  }
  
  public c getAppEventListener() {
    return this.h.h;
  }
  
  public n getVideoController() {
    return this.h.c;
  }
  
  public o getVideoOptions() {
    return this.h.j;
  }
  
  public void setAdSizes(f... paramVarArgs) {
    if (paramVarArgs != null && paramVarArgs.length > 0) {
      this.h.f(paramVarArgs);
      return;
    } 
    throw new IllegalArgumentException("The supported ad sizes must contain at least one valid ad size.");
  }
  
  public void setAppEventListener(c paramc) {
    this.h.g(paramc);
  }
  
  public void setManualImpressionsEnabled(boolean paramBoolean) {
    d2 d2 = this.h;
    d2.n = paramBoolean;
    try {
      f0 f0 = d2.i;
      if (f0 != null) {
        f0.l3(paramBoolean);
        return;
      } 
    } catch (RemoteException remoteException) {
      a80.i("#007 Could not call remote method.", (Throwable)remoteException);
    } 
  }
  
  public void setVideoOptions(o paramo) {
    d2 d2 = this.h;
    d2.j = paramo;
    try {
      f0 f0 = d2.i;
      if (f0 != null) {
        y2 y2;
        if (paramo == null) {
          paramo = null;
        } else {
          y2 = new y2(paramo);
        } 
        f0.J1(y2);
        return;
      } 
    } catch (RemoteException remoteException) {
      a80.i("#007 Could not call remote method.", (Throwable)remoteException);
    } 
  }
}


/* Location:              C:\soft\dex2jar-2.0\Luxury Logo Maker_ Logo Design-dex2jar.jar!\a3\a.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */