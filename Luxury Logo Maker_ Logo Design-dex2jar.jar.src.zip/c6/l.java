package c6;

import android.opengl.GLES20;

public class l implements Runnable {
  public l(i parami, int paramInt, float[] paramArrayOffloat) {}
  
  public void run() {
    GLES20.glUniformMatrix3fv(this.h, 1, false, this.i, 0);
  }
}


/* Location:              C:\soft\dex2jar-2.0\Luxury Logo Maker_ Logo Design-dex2jar.jar!\c6\l.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */