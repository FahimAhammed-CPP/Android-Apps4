package c6;

import android.app.ActivityManager;
import android.content.Context;
import android.graphics.Bitmap;

public class b {
  public final q a;
  
  public i b;
  
  public Bitmap c;
  
  public b(Context paramContext) {
    boolean bool;
    if ((((ActivityManager)paramContext.getSystemService("activity")).getDeviceConfigurationInfo()).reqGlEsVersion >= 131072) {
      bool = true;
    } else {
      bool = false;
    } 
    if (bool) {
      i i1 = new i();
      this.b = i1;
      this.a = new q(i1);
      return;
    } 
    throw new IllegalStateException("OpenGL ES 2.0 is not supported on this phone.");
  }
  
  public Bitmap a() {
    // Byte code:
    //   0: aload_0
    //   1: getfield c : Landroid/graphics/Bitmap;
    //   4: astore #6
    //   6: new c6/q
    //   9: dup
    //   10: aload_0
    //   11: getfield b : Lc6/i;
    //   14: invokespecial <init> : (Lc6/i;)V
    //   17: astore #9
    //   19: aload_0
    //   20: getfield a : Lc6/q;
    //   23: astore #7
    //   25: aload #7
    //   27: getfield n : Z
    //   30: istore #4
    //   32: aload #7
    //   34: getfield o : Z
    //   37: istore #5
    //   39: aload #9
    //   41: iload #4
    //   43: putfield n : Z
    //   46: aload #9
    //   48: iload #5
    //   50: putfield o : Z
    //   53: aload #9
    //   55: iconst_1
    //   56: putfield m : I
    //   59: aload #9
    //   61: invokevirtual b : ()V
    //   64: aload #9
    //   66: iconst_2
    //   67: putfield p : I
    //   70: new c6/c0
    //   73: dup
    //   74: aload #6
    //   76: invokevirtual getWidth : ()I
    //   79: aload #6
    //   81: invokevirtual getHeight : ()I
    //   84: invokespecial <init> : (II)V
    //   87: astore #8
    //   89: aload #8
    //   91: aload #9
    //   93: putfield a : Landroid/opengl/GLSurfaceView$Renderer;
    //   96: invokestatic currentThread : ()Ljava/lang/Thread;
    //   99: invokevirtual getName : ()Ljava/lang/String;
    //   102: aload #8
    //   104: getfield l : Ljava/lang/String;
    //   107: invokevirtual equals : (Ljava/lang/Object;)Z
    //   110: ifne -> 124
    //   113: ldc 'PixelBuffer'
    //   115: ldc 'setRenderer: This thread does not own the OpenGL context.'
    //   117: invokestatic e : (Ljava/lang/String;Ljava/lang/String;)I
    //   120: pop
    //   121: goto -> 169
    //   124: aload #8
    //   126: getfield a : Landroid/opengl/GLSurfaceView$Renderer;
    //   129: aload #8
    //   131: getfield k : Ljavax/microedition/khronos/opengles/GL10;
    //   134: aload #8
    //   136: getfield h : Ljavax/microedition/khronos/egl/EGLConfig;
    //   139: invokeinterface onSurfaceCreated : (Ljavax/microedition/khronos/opengles/GL10;Ljavax/microedition/khronos/egl/EGLConfig;)V
    //   144: aload #8
    //   146: getfield a : Landroid/opengl/GLSurfaceView$Renderer;
    //   149: aload #8
    //   151: getfield k : Ljavax/microedition/khronos/opengles/GL10;
    //   154: aload #8
    //   156: getfield b : I
    //   159: aload #8
    //   161: getfield c : I
    //   164: invokeinterface onSurfaceChanged : (Ljavax/microedition/khronos/opengles/GL10;II)V
    //   169: aload #9
    //   171: aload #6
    //   173: iconst_0
    //   174: invokevirtual e : (Landroid/graphics/Bitmap;Z)V
    //   177: aload #8
    //   179: getfield a : Landroid/opengl/GLSurfaceView$Renderer;
    //   182: astore #6
    //   184: aconst_null
    //   185: astore #7
    //   187: aload #6
    //   189: ifnonnull -> 199
    //   192: ldc 'getBitmap: Renderer was not set.'
    //   194: astore #6
    //   196: goto -> 220
    //   199: invokestatic currentThread : ()Ljava/lang/Thread;
    //   202: invokevirtual getName : ()Ljava/lang/String;
    //   205: aload #8
    //   207: getfield l : Ljava/lang/String;
    //   210: invokevirtual equals : (Ljava/lang/Object;)Z
    //   213: ifne -> 235
    //   216: ldc 'getBitmap: This thread does not own the OpenGL context.'
    //   218: astore #6
    //   220: ldc 'PixelBuffer'
    //   222: aload #6
    //   224: invokestatic e : (Ljava/lang/String;Ljava/lang/String;)I
    //   227: pop
    //   228: aload #7
    //   230: astore #6
    //   232: goto -> 427
    //   235: aload #8
    //   237: getfield a : Landroid/opengl/GLSurfaceView$Renderer;
    //   240: aload #8
    //   242: getfield k : Ljavax/microedition/khronos/opengles/GL10;
    //   245: invokeinterface onDrawFrame : (Ljavax/microedition/khronos/opengles/GL10;)V
    //   250: aload #8
    //   252: getfield a : Landroid/opengl/GLSurfaceView$Renderer;
    //   255: aload #8
    //   257: getfield k : Ljavax/microedition/khronos/opengles/GL10;
    //   260: invokeinterface onDrawFrame : (Ljavax/microedition/khronos/opengles/GL10;)V
    //   265: aload #8
    //   267: getfield b : I
    //   270: aload #8
    //   272: getfield c : I
    //   275: imul
    //   276: istore_1
    //   277: iload_1
    //   278: newarray int
    //   280: astore #6
    //   282: iload_1
    //   283: invokestatic allocate : (I)Ljava/nio/IntBuffer;
    //   286: astore #7
    //   288: aload #8
    //   290: getfield k : Ljavax/microedition/khronos/opengles/GL10;
    //   293: iconst_0
    //   294: iconst_0
    //   295: aload #8
    //   297: getfield b : I
    //   300: aload #8
    //   302: getfield c : I
    //   305: sipush #6408
    //   308: sipush #5121
    //   311: aload #7
    //   313: invokeinterface glReadPixels : (IIIIIILjava/nio/Buffer;)V
    //   318: aload #7
    //   320: invokevirtual array : ()[I
    //   323: astore #7
    //   325: iconst_0
    //   326: istore_1
    //   327: aload #8
    //   329: getfield c : I
    //   332: istore_2
    //   333: iload_1
    //   334: iload_2
    //   335: if_icmpge -> 389
    //   338: iconst_0
    //   339: istore_2
    //   340: aload #8
    //   342: getfield b : I
    //   345: istore_3
    //   346: iload_2
    //   347: iload_3
    //   348: if_icmpge -> 382
    //   351: aload #6
    //   353: aload #8
    //   355: getfield c : I
    //   358: iload_1
    //   359: isub
    //   360: iconst_1
    //   361: isub
    //   362: iload_3
    //   363: imul
    //   364: iload_2
    //   365: iadd
    //   366: aload #7
    //   368: iload_3
    //   369: iload_1
    //   370: imul
    //   371: iload_2
    //   372: iadd
    //   373: iaload
    //   374: iastore
    //   375: iload_2
    //   376: iconst_1
    //   377: iadd
    //   378: istore_2
    //   379: goto -> 340
    //   382: iload_1
    //   383: iconst_1
    //   384: iadd
    //   385: istore_1
    //   386: goto -> 327
    //   389: aload #8
    //   391: getfield b : I
    //   394: iload_2
    //   395: getstatic android/graphics/Bitmap$Config.ARGB_8888 : Landroid/graphics/Bitmap$Config;
    //   398: invokestatic createBitmap : (IILandroid/graphics/Bitmap$Config;)Landroid/graphics/Bitmap;
    //   401: astore #7
    //   403: aload #8
    //   405: aload #7
    //   407: putfield d : Landroid/graphics/Bitmap;
    //   410: aload #7
    //   412: aload #6
    //   414: invokestatic wrap : ([I)Ljava/nio/IntBuffer;
    //   417: invokevirtual copyPixelsFromBuffer : (Ljava/nio/Buffer;)V
    //   420: aload #8
    //   422: getfield d : Landroid/graphics/Bitmap;
    //   425: astore #6
    //   427: aload_0
    //   428: getfield b : Lc6/i;
    //   431: invokevirtual a : ()V
    //   434: aload #9
    //   436: new c6/s
    //   439: dup
    //   440: aload #9
    //   442: invokespecial <init> : (Lc6/q;)V
    //   445: invokevirtual d : (Ljava/lang/Runnable;)V
    //   448: aload #8
    //   450: getfield a : Landroid/opengl/GLSurfaceView$Renderer;
    //   453: aload #8
    //   455: getfield k : Ljavax/microedition/khronos/opengles/GL10;
    //   458: invokeinterface onDrawFrame : (Ljavax/microedition/khronos/opengles/GL10;)V
    //   463: aload #8
    //   465: getfield a : Landroid/opengl/GLSurfaceView$Renderer;
    //   468: aload #8
    //   470: getfield k : Ljavax/microedition/khronos/opengles/GL10;
    //   473: invokeinterface onDrawFrame : (Ljavax/microedition/khronos/opengles/GL10;)V
    //   478: aload #8
    //   480: getfield e : Ljavax/microedition/khronos/egl/EGL10;
    //   483: astore #7
    //   485: aload #8
    //   487: getfield f : Ljavax/microedition/khronos/egl/EGLDisplay;
    //   490: astore #9
    //   492: getstatic javax/microedition/khronos/egl/EGL10.EGL_NO_SURFACE : Ljavax/microedition/khronos/egl/EGLSurface;
    //   495: astore #10
    //   497: aload #7
    //   499: aload #9
    //   501: aload #10
    //   503: aload #10
    //   505: getstatic javax/microedition/khronos/egl/EGL10.EGL_NO_CONTEXT : Ljavax/microedition/khronos/egl/EGLContext;
    //   508: invokeinterface eglMakeCurrent : (Ljavax/microedition/khronos/egl/EGLDisplay;Ljavax/microedition/khronos/egl/EGLSurface;Ljavax/microedition/khronos/egl/EGLSurface;Ljavax/microedition/khronos/egl/EGLContext;)Z
    //   513: pop
    //   514: aload #8
    //   516: getfield e : Ljavax/microedition/khronos/egl/EGL10;
    //   519: aload #8
    //   521: getfield f : Ljavax/microedition/khronos/egl/EGLDisplay;
    //   524: aload #8
    //   526: getfield j : Ljavax/microedition/khronos/egl/EGLSurface;
    //   529: invokeinterface eglDestroySurface : (Ljavax/microedition/khronos/egl/EGLDisplay;Ljavax/microedition/khronos/egl/EGLSurface;)Z
    //   534: pop
    //   535: aload #8
    //   537: getfield e : Ljavax/microedition/khronos/egl/EGL10;
    //   540: aload #8
    //   542: getfield f : Ljavax/microedition/khronos/egl/EGLDisplay;
    //   545: aload #8
    //   547: getfield i : Ljavax/microedition/khronos/egl/EGLContext;
    //   550: invokeinterface eglDestroyContext : (Ljavax/microedition/khronos/egl/EGLDisplay;Ljavax/microedition/khronos/egl/EGLContext;)Z
    //   555: pop
    //   556: aload #8
    //   558: getfield e : Ljavax/microedition/khronos/egl/EGL10;
    //   561: aload #8
    //   563: getfield f : Ljavax/microedition/khronos/egl/EGLDisplay;
    //   566: invokeinterface eglTerminate : (Ljavax/microedition/khronos/egl/EGLDisplay;)Z
    //   571: pop
    //   572: aload_0
    //   573: getfield a : Lc6/q;
    //   576: astore #7
    //   578: aload_0
    //   579: getfield b : Lc6/i;
    //   582: astore #8
    //   584: aload #7
    //   586: invokestatic requireNonNull : (Ljava/lang/Object;)Ljava/lang/Object;
    //   589: pop
    //   590: aload #7
    //   592: new c6/r
    //   595: dup
    //   596: aload #7
    //   598: aload #8
    //   600: invokespecial <init> : (Lc6/q;Lc6/i;)V
    //   603: invokevirtual d : (Ljava/lang/Runnable;)V
    //   606: aload_0
    //   607: getfield c : Landroid/graphics/Bitmap;
    //   610: astore #7
    //   612: aload #7
    //   614: ifnull -> 627
    //   617: aload_0
    //   618: getfield a : Lc6/q;
    //   621: aload #7
    //   623: iconst_0
    //   624: invokevirtual e : (Landroid/graphics/Bitmap;Z)V
    //   627: aload #6
    //   629: areturn
  }
}


/* Location:              C:\soft\dex2jar-2.0\Luxury Logo Maker_ Logo Design-dex2jar.jar!\c6\b.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */