package c6;

import android.opengl.GLES20;

public class z extends n {
  public z(String paramString1, String paramString2, String paramString3, String paramString4) {
    super(null);
    i i = new i(paramString1, paramString2);
    this.k.add(i);
    l();
    i = new i(paramString3, paramString4);
    this.k.add(i);
    l();
  }
  
  public void e() {
    super.e();
    m();
  }
  
  public void g(int paramInt1, int paramInt2) {
    super.g(paramInt1, paramInt2);
    m();
  }
  
  public void m() {
    c c = (c)this;
    float f = c.r;
    i i2 = this.k.get(0);
    int i = GLES20.glGetUniformLocation(i2.d, "texelWidthOffset");
    int j = GLES20.glGetUniformLocation(i2.d, "texelHeightOffset");
    i2.j(i, f / this.h);
    i2.j(j, 0.0F);
    f = c.r;
    i i1 = this.k.get(1);
    i = GLES20.glGetUniformLocation(i1.d, "texelWidthOffset");
    j = GLES20.glGetUniformLocation(i1.d, "texelHeightOffset");
    i1.j(i, 0.0F);
    i1.j(j, f / this.i);
  }
}


/* Location:              C:\soft\dex2jar-2.0\Luxury Logo Maker_ Logo Design-dex2jar.jar!\c6\z.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */