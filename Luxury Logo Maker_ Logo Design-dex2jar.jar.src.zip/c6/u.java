package c6;

import android.opengl.GLES20;

public class u extends i {
  public float k = 1.0F;
  
  public float[] l = new float[] { 
      0.3588F, 0.7044F, 0.1368F, 0.0F, 0.299F, 0.587F, 0.114F, 0.0F, 0.2392F, 0.4696F, 
      0.0912F, 0.0F, 0.0F, 0.0F, 0.0F, 1.0F };
  
  public int m;
  
  public int n;
  
  public u() {
    super("attribute vec4 position;\nattribute vec4 inputTextureCoordinate;\n \nvarying vec2 textureCoordinate;\n \nvoid main()\n{\n    gl_Position = position;\n    textureCoordinate = inputTextureCoordinate.xy;\n}", "varying highp vec2 textureCoordinate;\n\nuniform sampler2D inputImageTexture;\n\nuniform lowp mat4 colorMatrix;\nuniform lowp float intensity;\n\nvoid main()\n{\n    lowp vec4 textureColor = texture2D(inputImageTexture, textureCoordinate);\n    lowp vec4 outputColor = textureColor * colorMatrix;\n    \n    gl_FragColor = (intensity * outputColor) + ((1.0 - intensity) * textureColor);\n}");
  }
  
  public void e() {
    super.e();
    this.m = GLES20.glGetUniformLocation(this.d, "colorMatrix");
    this.n = GLES20.glGetUniformLocation(this.d, "intensity");
  }
  
  public void f() {
    float f = this.k;
    this.k = f;
    j(this.n, f);
    float[] arrayOfFloat = this.l;
    this.l = arrayOfFloat;
    h(new m(this, this.m, arrayOfFloat));
  }
}


/* Location:              C:\soft\dex2jar-2.0\Luxury Logo Maker_ Logo Design-dex2jar.jar!\c\\u.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */