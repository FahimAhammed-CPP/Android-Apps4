package c6;

import android.annotation.SuppressLint;
import android.opengl.GLES20;
import d6.a;
import java.nio.ByteBuffer;
import java.nio.ByteOrder;
import java.nio.FloatBuffer;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

public class n extends i {
  public List<i> k = null;
  
  public List<i> l;
  
  public int[] m;
  
  public int[] n;
  
  public final FloatBuffer o;
  
  public final FloatBuffer p;
  
  public final FloatBuffer q;
  
  public n() {
    this(null);
  }
  
  public n(List<i> paramList) {
    this.k = new ArrayList<i>();
    float[] arrayOfFloat = q.q;
    FloatBuffer floatBuffer = ByteBuffer.allocateDirect(arrayOfFloat.length * 4).order(ByteOrder.nativeOrder()).asFloatBuffer();
    this.o = floatBuffer;
    floatBuffer.put(arrayOfFloat).position(0);
    arrayOfFloat = a.h;
    floatBuffer = ByteBuffer.allocateDirect(arrayOfFloat.length * 4).order(ByteOrder.nativeOrder()).asFloatBuffer();
    this.p = floatBuffer;
    floatBuffer.put(arrayOfFloat).position(0);
    arrayOfFloat = a.c(1, false, true);
    floatBuffer = ByteBuffer.allocateDirect(arrayOfFloat.length * 4).order(ByteOrder.nativeOrder()).asFloatBuffer();
    this.q = floatBuffer;
    floatBuffer.put(arrayOfFloat).position(0);
  }
  
  public void c() {
    k();
    Iterator<i> iterator = this.k.iterator();
    while (iterator.hasNext())
      ((i)iterator.next()).a(); 
  }
  
  @SuppressLint({"WrongCall"})
  public void d(int paramInt, FloatBuffer paramFloatBuffer1, FloatBuffer paramFloatBuffer2) {
    // Byte code:
    //   0: aload_0
    //   1: invokevirtual i : ()V
    //   4: aload_0
    //   5: getfield j : Z
    //   8: ifeq -> 225
    //   11: aload_0
    //   12: getfield m : [I
    //   15: ifnull -> 225
    //   18: aload_0
    //   19: getfield n : [I
    //   22: ifnonnull -> 26
    //   25: return
    //   26: aload_0
    //   27: getfield l : Ljava/util/List;
    //   30: astore #8
    //   32: aload #8
    //   34: ifnull -> 225
    //   37: aload #8
    //   39: invokeinterface size : ()I
    //   44: istore #6
    //   46: iconst_0
    //   47: istore #5
    //   49: iload_1
    //   50: istore #4
    //   52: iload #5
    //   54: istore_1
    //   55: iload_1
    //   56: iload #6
    //   58: if_icmpge -> 225
    //   61: aload_0
    //   62: getfield l : Ljava/util/List;
    //   65: iload_1
    //   66: invokeinterface get : (I)Ljava/lang/Object;
    //   71: checkcast c6/i
    //   74: astore #11
    //   76: iload #6
    //   78: iconst_1
    //   79: isub
    //   80: istore #7
    //   82: iload_1
    //   83: iload #7
    //   85: if_icmpge -> 94
    //   88: iconst_1
    //   89: istore #5
    //   91: goto -> 97
    //   94: iconst_0
    //   95: istore #5
    //   97: iload #5
    //   99: ifeq -> 120
    //   102: ldc 36160
    //   104: aload_0
    //   105: getfield m : [I
    //   108: iload_1
    //   109: iaload
    //   110: invokestatic glBindFramebuffer : (II)V
    //   113: fconst_0
    //   114: fconst_0
    //   115: fconst_0
    //   116: fconst_0
    //   117: invokestatic glClearColor : (FFFF)V
    //   120: iload_1
    //   121: ifne -> 136
    //   124: aload #11
    //   126: iload #4
    //   128: aload_2
    //   129: aload_3
    //   130: invokevirtual d : (ILjava/nio/FloatBuffer;Ljava/nio/FloatBuffer;)V
    //   133: goto -> 199
    //   136: iload_1
    //   137: iload #7
    //   139: if_icmpne -> 176
    //   142: aload_0
    //   143: getfield o : Ljava/nio/FloatBuffer;
    //   146: astore #9
    //   148: aload #9
    //   150: astore #8
    //   152: iload #6
    //   154: iconst_2
    //   155: irem
    //   156: ifne -> 182
    //   159: aload_0
    //   160: getfield q : Ljava/nio/FloatBuffer;
    //   163: astore #10
    //   165: aload #9
    //   167: astore #8
    //   169: aload #10
    //   171: astore #9
    //   173: goto -> 188
    //   176: aload_0
    //   177: getfield o : Ljava/nio/FloatBuffer;
    //   180: astore #8
    //   182: aload_0
    //   183: getfield p : Ljava/nio/FloatBuffer;
    //   186: astore #9
    //   188: aload #11
    //   190: iload #4
    //   192: aload #8
    //   194: aload #9
    //   196: invokevirtual d : (ILjava/nio/FloatBuffer;Ljava/nio/FloatBuffer;)V
    //   199: iload #5
    //   201: ifeq -> 218
    //   204: ldc 36160
    //   206: iconst_0
    //   207: invokestatic glBindFramebuffer : (II)V
    //   210: aload_0
    //   211: getfield n : [I
    //   214: iload_1
    //   215: iaload
    //   216: istore #4
    //   218: iload_1
    //   219: iconst_1
    //   220: iadd
    //   221: istore_1
    //   222: goto -> 55
    //   225: return
  }
  
  public void e() {
    super.e();
    Iterator<i> iterator = this.k.iterator();
    while (iterator.hasNext())
      ((i)iterator.next()).b(); 
  }
  
  public void g(int paramInt1, int paramInt2) {
    this.h = paramInt1;
    this.i = paramInt2;
    if (this.m != null)
      k(); 
    int k = this.k.size();
    int j;
    for (j = 0; j < k; j++)
      ((i)this.k.get(j)).g(paramInt1, paramInt2); 
    List<i> list = this.l;
    if (list != null && list.size() > 0) {
      k = this.l.size() - 1;
      this.m = new int[k];
      this.n = new int[k];
      for (j = 0; j < k; j++) {
        GLES20.glGenFramebuffers(1, this.m, j);
        GLES20.glGenTextures(1, this.n, j);
        GLES20.glBindTexture(3553, this.n[j]);
        GLES20.glTexImage2D(3553, 0, 6408, paramInt1, paramInt2, 0, 6408, 5121, null);
        GLES20.glTexParameterf(3553, 10240, 9729.0F);
        GLES20.glTexParameterf(3553, 10241, 9729.0F);
        GLES20.glTexParameterf(3553, 10242, 33071.0F);
        GLES20.glTexParameterf(3553, 10243, 33071.0F);
        GLES20.glBindFramebuffer(36160, this.m[j]);
        GLES20.glFramebufferTexture2D(36160, 36064, 3553, this.n[j], 0);
        GLES20.glBindTexture(3553, 0);
        GLES20.glBindFramebuffer(36160, 0);
      } 
    } 
  }
  
  public final void k() {
    int[] arrayOfInt = this.n;
    if (arrayOfInt != null) {
      GLES20.glDeleteTextures(arrayOfInt.length, arrayOfInt, 0);
      this.n = null;
    } 
    arrayOfInt = this.m;
    if (arrayOfInt != null) {
      GLES20.glDeleteFramebuffers(arrayOfInt.length, arrayOfInt, 0);
      this.m = null;
    } 
  }
  
  public void l() {
    if (this.k == null)
      return; 
    List<i> list = this.l;
    if (list == null) {
      this.l = new ArrayList<i>();
    } else {
      list.clear();
    } 
    for (i i1 : this.k) {
      List<i> list1;
      if (i1 instanceof n) {
        i1 = i1;
        i1.l();
        list1 = ((n)i1).l;
        if (list1 == null || list1.isEmpty())
          continue; 
        this.l.addAll(list1);
        continue;
      } 
      this.l.add(list1);
    } 
  }
}


/* Location:              C:\soft\dex2jar-2.0\Luxury Logo Maker_ Logo Design-dex2jar.jar!\c6\n.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */