package c6;

import android.opengl.GLES20;

public class a extends i {
  public int k;
  
  public int l;
  
  public float m;
  
  public float n;
  
  public float o = 1.0F;
  
  public a(String paramString) {
    super("attribute vec4 position;\nattribute vec4 inputTextureCoordinate;\n\nuniform highp float texelWidth; \nuniform highp float texelHeight; \n\nvarying vec2 textureCoordinate;\nvarying vec2 leftTextureCoordinate;\nvarying vec2 rightTextureCoordinate;\n\nvarying vec2 topTextureCoordinate;\nvarying vec2 topLeftTextureCoordinate;\nvarying vec2 topRightTextureCoordinate;\n\nvarying vec2 bottomTextureCoordinate;\nvarying vec2 bottomLeftTextureCoordinate;\nvarying vec2 bottomRightTextureCoordinate;\n\nvoid main()\n{\n    gl_Position = position;\n\n    vec2 widthStep = vec2(texelWidth, 0.0);\n    vec2 heightStep = vec2(0.0, texelHeight);\n    vec2 widthHeightStep = vec2(texelWidth, texelHeight);\n    vec2 widthNegativeHeightStep = vec2(texelWidth, -texelHeight);\n\n    textureCoordinate = inputTextureCoordinate.xy;\n    leftTextureCoordinate = inputTextureCoordinate.xy - widthStep;\n    rightTextureCoordinate = inputTextureCoordinate.xy + widthStep;\n\n    topTextureCoordinate = inputTextureCoordinate.xy - heightStep;\n    topLeftTextureCoordinate = inputTextureCoordinate.xy - widthHeightStep;\n    topRightTextureCoordinate = inputTextureCoordinate.xy + widthNegativeHeightStep;\n\n    bottomTextureCoordinate = inputTextureCoordinate.xy + heightStep;\n    bottomLeftTextureCoordinate = inputTextureCoordinate.xy - widthNegativeHeightStep;\n    bottomRightTextureCoordinate = inputTextureCoordinate.xy + widthHeightStep;\n}", paramString);
  }
  
  public void e() {
    super.e();
    this.k = GLES20.glGetUniformLocation(this.d, "texelWidth");
    this.l = GLES20.glGetUniformLocation(this.d, "texelHeight");
    float f = this.m;
    if (f != 0.0F) {
      j(this.k, f);
      j(this.l, this.n);
    } 
  }
  
  public void g(int paramInt1, int paramInt2) {
    this.h = paramInt1;
    this.i = paramInt2;
    float f1 = this.o;
    this.o = f1;
    float f2 = f1 / paramInt1;
    this.m = f2;
    this.n = f1 / paramInt2;
    j(this.k, f2);
    j(this.l, this.n);
  }
}


/* Location:              C:\soft\dex2jar-2.0\Luxury Logo Maker_ Logo Design-dex2jar.jar!\c6\a.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */