package c6;

import android.opengl.GLES20;
import java.nio.FloatBuffer;

public class j implements Runnable {
  public j(i parami, int paramInt, float[] paramArrayOffloat) {}
  
  public void run() {
    GLES20.glUniform3fv(this.h, 1, FloatBuffer.wrap(this.i));
  }
}


/* Location:              C:\soft\dex2jar-2.0\Luxury Logo Maker_ Logo Design-dex2jar.jar!\c6\j.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */