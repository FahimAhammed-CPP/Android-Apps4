package c6;

import android.annotation.TargetApi;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.hardware.Camera;
import android.opengl.GLES20;
import android.opengl.GLSurfaceView;
import android.opengl.GLUtils;
import java.nio.ByteBuffer;
import java.nio.ByteOrder;
import java.nio.FloatBuffer;
import java.nio.IntBuffer;
import java.util.LinkedList;
import java.util.Objects;
import java.util.Queue;
import javax.microedition.khronos.egl.EGLConfig;
import javax.microedition.khronos.opengles.GL10;
import jp.co.cyberagent.android.gpuimage.GPUImageNativeLibrary;

@TargetApi(11)
public class q implements GLSurfaceView.Renderer, Camera.PreviewCallback {
  public static final float[] q = new float[] { -1.0F, -1.0F, 1.0F, -1.0F, -1.0F, 1.0F, 1.0F, 1.0F };
  
  public i a;
  
  public final Object b = new Object();
  
  public int c = -1;
  
  public final FloatBuffer d;
  
  public final FloatBuffer e;
  
  public IntBuffer f;
  
  public int g;
  
  public int h;
  
  public int i;
  
  public int j;
  
  public final Queue<Runnable> k;
  
  public final Queue<Runnable> l;
  
  public int m;
  
  public boolean n;
  
  public boolean o;
  
  public int p = 2;
  
  public q(i parami) {
    this.a = parami;
    this.k = new LinkedList<Runnable>();
    this.l = new LinkedList<Runnable>();
    float[] arrayOfFloat = q;
    FloatBuffer floatBuffer = ByteBuffer.allocateDirect(arrayOfFloat.length * 4).order(ByteOrder.nativeOrder()).asFloatBuffer();
    this.d = floatBuffer;
    floatBuffer.put(arrayOfFloat).position(0);
    this.e = ByteBuffer.allocateDirect(d6.a.h.length * 4).order(ByteOrder.nativeOrder()).asFloatBuffer();
    this.n = false;
    this.o = false;
    this.m = 1;
    b();
  }
  
  public final float a(float paramFloat1, float paramFloat2) {
    return (paramFloat1 == 0.0F) ? paramFloat2 : (1.0F - paramFloat2);
  }
  
  public final void b() {
    // Byte code:
    //   0: aload_0
    //   1: getfield g : I
    //   4: i2f
    //   5: fstore #4
    //   7: aload_0
    //   8: getfield h : I
    //   11: i2f
    //   12: fstore_2
    //   13: aload_0
    //   14: getfield m : I
    //   17: istore #5
    //   19: iload #5
    //   21: iconst_4
    //   22: if_icmpeq -> 36
    //   25: fload #4
    //   27: fstore_3
    //   28: fload_2
    //   29: fstore_1
    //   30: iload #5
    //   32: iconst_2
    //   33: if_icmpne -> 41
    //   36: fload #4
    //   38: fstore_1
    //   39: fload_2
    //   40: fstore_3
    //   41: fload_3
    //   42: aload_0
    //   43: getfield i : I
    //   46: i2f
    //   47: fdiv
    //   48: fload_1
    //   49: aload_0
    //   50: getfield j : I
    //   53: i2f
    //   54: fdiv
    //   55: invokestatic max : (FF)F
    //   58: fstore_2
    //   59: aload_0
    //   60: getfield i : I
    //   63: i2f
    //   64: fload_2
    //   65: fmul
    //   66: invokestatic round : (F)I
    //   69: istore #5
    //   71: aload_0
    //   72: getfield j : I
    //   75: i2f
    //   76: fload_2
    //   77: fmul
    //   78: invokestatic round : (F)I
    //   81: istore #6
    //   83: iload #5
    //   85: i2f
    //   86: fload_3
    //   87: fdiv
    //   88: fstore_2
    //   89: iload #6
    //   91: i2f
    //   92: fload_1
    //   93: fdiv
    //   94: fstore_1
    //   95: getstatic c6/q.q : [F
    //   98: astore #7
    //   100: aload_0
    //   101: getfield m : I
    //   104: aload_0
    //   105: getfield n : Z
    //   108: aload_0
    //   109: getfield o : Z
    //   112: invokestatic c : (IZZ)[F
    //   115: astore #8
    //   117: aload_0
    //   118: getfield p : I
    //   121: iconst_2
    //   122: if_icmpne -> 250
    //   125: fconst_1
    //   126: fconst_1
    //   127: fload_2
    //   128: fdiv
    //   129: fsub
    //   130: fconst_2
    //   131: fdiv
    //   132: fstore_2
    //   133: fconst_1
    //   134: fconst_1
    //   135: fload_1
    //   136: fdiv
    //   137: fsub
    //   138: fconst_2
    //   139: fdiv
    //   140: fstore_1
    //   141: bipush #8
    //   143: newarray float
    //   145: dup
    //   146: iconst_0
    //   147: aload_0
    //   148: aload #8
    //   150: iconst_0
    //   151: faload
    //   152: fload_2
    //   153: invokevirtual a : (FF)F
    //   156: fastore
    //   157: dup
    //   158: iconst_1
    //   159: aload_0
    //   160: aload #8
    //   162: iconst_1
    //   163: faload
    //   164: fload_1
    //   165: invokevirtual a : (FF)F
    //   168: fastore
    //   169: dup
    //   170: iconst_2
    //   171: aload_0
    //   172: aload #8
    //   174: iconst_2
    //   175: faload
    //   176: fload_2
    //   177: invokevirtual a : (FF)F
    //   180: fastore
    //   181: dup
    //   182: iconst_3
    //   183: aload_0
    //   184: aload #8
    //   186: iconst_3
    //   187: faload
    //   188: fload_1
    //   189: invokevirtual a : (FF)F
    //   192: fastore
    //   193: dup
    //   194: iconst_4
    //   195: aload_0
    //   196: aload #8
    //   198: iconst_4
    //   199: faload
    //   200: fload_2
    //   201: invokevirtual a : (FF)F
    //   204: fastore
    //   205: dup
    //   206: iconst_5
    //   207: aload_0
    //   208: aload #8
    //   210: iconst_5
    //   211: faload
    //   212: fload_1
    //   213: invokevirtual a : (FF)F
    //   216: fastore
    //   217: dup
    //   218: bipush #6
    //   220: aload_0
    //   221: aload #8
    //   223: bipush #6
    //   225: faload
    //   226: fload_2
    //   227: invokevirtual a : (FF)F
    //   230: fastore
    //   231: dup
    //   232: bipush #7
    //   234: aload_0
    //   235: aload #8
    //   237: bipush #7
    //   239: faload
    //   240: fload_1
    //   241: invokevirtual a : (FF)F
    //   244: fastore
    //   245: astore #8
    //   247: goto -> 332
    //   250: bipush #8
    //   252: newarray float
    //   254: dup
    //   255: iconst_0
    //   256: aload #7
    //   258: iconst_0
    //   259: faload
    //   260: fload_1
    //   261: fdiv
    //   262: fastore
    //   263: dup
    //   264: iconst_1
    //   265: aload #7
    //   267: iconst_1
    //   268: faload
    //   269: fload_2
    //   270: fdiv
    //   271: fastore
    //   272: dup
    //   273: iconst_2
    //   274: aload #7
    //   276: iconst_2
    //   277: faload
    //   278: fload_1
    //   279: fdiv
    //   280: fastore
    //   281: dup
    //   282: iconst_3
    //   283: aload #7
    //   285: iconst_3
    //   286: faload
    //   287: fload_2
    //   288: fdiv
    //   289: fastore
    //   290: dup
    //   291: iconst_4
    //   292: aload #7
    //   294: iconst_4
    //   295: faload
    //   296: fload_1
    //   297: fdiv
    //   298: fastore
    //   299: dup
    //   300: iconst_5
    //   301: aload #7
    //   303: iconst_5
    //   304: faload
    //   305: fload_2
    //   306: fdiv
    //   307: fastore
    //   308: dup
    //   309: bipush #6
    //   311: aload #7
    //   313: bipush #6
    //   315: faload
    //   316: fload_1
    //   317: fdiv
    //   318: fastore
    //   319: dup
    //   320: bipush #7
    //   322: aload #7
    //   324: bipush #7
    //   326: faload
    //   327: fload_2
    //   328: fdiv
    //   329: fastore
    //   330: astore #7
    //   332: aload_0
    //   333: getfield d : Ljava/nio/FloatBuffer;
    //   336: invokevirtual clear : ()Ljava/nio/Buffer;
    //   339: pop
    //   340: aload_0
    //   341: getfield d : Ljava/nio/FloatBuffer;
    //   344: aload #7
    //   346: invokevirtual put : ([F)Ljava/nio/FloatBuffer;
    //   349: iconst_0
    //   350: invokevirtual position : (I)Ljava/nio/Buffer;
    //   353: pop
    //   354: aload_0
    //   355: getfield e : Ljava/nio/FloatBuffer;
    //   358: invokevirtual clear : ()Ljava/nio/Buffer;
    //   361: pop
    //   362: aload_0
    //   363: getfield e : Ljava/nio/FloatBuffer;
    //   366: aload #8
    //   368: invokevirtual put : ([F)Ljava/nio/FloatBuffer;
    //   371: iconst_0
    //   372: invokevirtual position : (I)Ljava/nio/Buffer;
    //   375: pop
    //   376: return
  }
  
  public final void c(Queue<Runnable> paramQueue) {
    // Byte code:
    //   0: aload_1
    //   1: monitorenter
    //   2: aload_1
    //   3: invokeinterface isEmpty : ()Z
    //   8: ifne -> 28
    //   11: aload_1
    //   12: invokeinterface poll : ()Ljava/lang/Object;
    //   17: checkcast java/lang/Runnable
    //   20: invokeinterface run : ()V
    //   25: goto -> 2
    //   28: aload_1
    //   29: monitorexit
    //   30: return
    //   31: astore_2
    //   32: aload_1
    //   33: monitorexit
    //   34: aload_2
    //   35: athrow
    // Exception table:
    //   from	to	target	type
    //   2	25	31	finally
    //   28	30	31	finally
    //   32	34	31	finally
  }
  
  public void d(Runnable paramRunnable) {
    synchronized (this.k) {
      this.k.add(paramRunnable);
      return;
    } 
  }
  
  public void e(Bitmap paramBitmap, boolean paramBoolean) {
    if (paramBitmap == null)
      return; 
    d(new b(this, paramBitmap, paramBoolean));
  }
  
  public void onDrawFrame(GL10 paramGL10) {
    GLES20.glClear(16640);
    c(this.k);
    this.a.d(this.c, this.d, this.e);
    c(this.l);
  }
  
  public void onPreviewFrame(byte[] paramArrayOfbyte, Camera paramCamera) {
    Camera.Size size = paramCamera.getParameters().getPreviewSize();
    if (this.f == null)
      this.f = IntBuffer.allocate(size.width * size.height); 
    if (this.k.isEmpty())
      d(new a(this, paramArrayOfbyte, size, paramCamera)); 
  }
  
  public void onSurfaceChanged(GL10 paramGL10, int paramInt1, int paramInt2) {
    this.g = paramInt1;
    this.h = paramInt2;
    GLES20.glViewport(0, 0, paramInt1, paramInt2);
    GLES20.glUseProgram(this.a.d);
    this.a.g(paramInt1, paramInt2);
    b();
    synchronized (this.b) {
      this.b.notifyAll();
      return;
    } 
  }
  
  public void onSurfaceCreated(GL10 paramGL10, EGLConfig paramEGLConfig) {
    GLES20.glClearColor(0.0F, 0.0F, 0.0F, 1.0F);
    GLES20.glDisable(2929);
    this.a.b();
  }
  
  public class a implements Runnable {
    public a(q this$0, byte[] param1ArrayOfbyte, Camera.Size param1Size, Camera param1Camera) {}
    
    public void run() {
      byte[] arrayOfByte = this.h;
      Camera.Size size2 = this.i;
      GPUImageNativeLibrary.YUVtoRBGA(arrayOfByte, size2.width, size2.height, this.k.f.array());
      q q1 = this.k;
      IntBuffer intBuffer = q1.f;
      Camera.Size size3 = this.i;
      int i = q1.c;
      int[] arrayOfInt = new int[1];
      if (i == -1) {
        GLES20.glGenTextures(1, arrayOfInt, 0);
        GLES20.glBindTexture(3553, arrayOfInt[0]);
        GLES20.glTexParameterf(3553, 10240, 9729.0F);
        GLES20.glTexParameterf(3553, 10241, 9729.0F);
        GLES20.glTexParameterf(3553, 10242, 33071.0F);
        GLES20.glTexParameterf(3553, 10243, 33071.0F);
        GLES20.glTexImage2D(3553, 0, 6408, size3.width, size3.height, 0, 6408, 5121, intBuffer);
      } else {
        GLES20.glBindTexture(3553, i);
        GLES20.glTexSubImage2D(3553, 0, 0, 0, size3.width, size3.height, 6408, 5121, intBuffer);
        arrayOfInt[0] = i;
      } 
      q1.c = arrayOfInt[0];
      this.j.addCallbackBuffer(this.h);
      q1 = this.k;
      i = q1.i;
      Camera.Size size1 = this.i;
      int j = size1.width;
      if (i != j) {
        q1.i = j;
        q1.j = size1.height;
        q1.b();
      } 
    }
  }
  
  public class b implements Runnable {
    public b(q this$0, Bitmap param1Bitmap, boolean param1Boolean) {}
    
    public void run() {
      Bitmap bitmap2;
      int i = this.h.getWidth();
      Bitmap bitmap1 = null;
      if (i % 2 == 1) {
        bitmap1 = Bitmap.createBitmap(this.h.getWidth() + 1, this.h.getHeight(), Bitmap.Config.ARGB_8888);
        Canvas canvas = new Canvas(bitmap1);
        canvas.drawARGB(0, 0, 0, 0);
        canvas.drawBitmap(this.h, 0.0F, 0.0F, null);
        Objects.requireNonNull(this.j);
      } else {
        Objects.requireNonNull(this.j);
      } 
      q q1 = this.j;
      if (bitmap1 != null) {
        bitmap2 = bitmap1;
      } else {
        bitmap2 = this.h;
      } 
      i = q1.c;
      boolean bool = this.i;
      int[] arrayOfInt = new int[1];
      if (i == -1) {
        GLES20.glGenTextures(1, arrayOfInt, 0);
        GLES20.glBindTexture(3553, arrayOfInt[0]);
        GLES20.glTexParameterf(3553, 10240, 9729.0F);
        GLES20.glTexParameterf(3553, 10241, 9729.0F);
        GLES20.glTexParameterf(3553, 10242, 33071.0F);
        GLES20.glTexParameterf(3553, 10243, 33071.0F);
        GLUtils.texImage2D(3553, 0, bitmap2, 0);
      } else {
        GLES20.glBindTexture(3553, i);
        GLUtils.texSubImage2D(3553, 0, 0, 0, bitmap2);
        arrayOfInt[0] = i;
      } 
      if (bool)
        bitmap2.recycle(); 
      q1.c = arrayOfInt[0];
      if (bitmap1 != null)
        bitmap1.recycle(); 
      this.j.i = this.h.getWidth();
      this.j.j = this.h.getHeight();
      this.j.b();
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Luxury Logo Maker_ Logo Design-dex2jar.jar!\c6\q.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */