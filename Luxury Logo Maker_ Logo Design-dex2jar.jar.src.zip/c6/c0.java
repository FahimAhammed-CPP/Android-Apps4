package c6;

import android.graphics.Bitmap;
import android.opengl.GLSurfaceView;
import javax.microedition.khronos.egl.EGL10;
import javax.microedition.khronos.egl.EGLConfig;
import javax.microedition.khronos.egl.EGLContext;
import javax.microedition.khronos.egl.EGLDisplay;
import javax.microedition.khronos.egl.EGLSurface;
import javax.microedition.khronos.opengles.GL10;

public class c0 {
  public GLSurfaceView.Renderer a;
  
  public int b;
  
  public int c;
  
  public Bitmap d;
  
  public EGL10 e;
  
  public EGLDisplay f;
  
  public EGLConfig[] g;
  
  public EGLConfig h;
  
  public EGLContext i;
  
  public EGLSurface j;
  
  public GL10 k;
  
  public String l;
  
  public c0(int paramInt1, int paramInt2) {
    this.b = paramInt1;
    this.c = paramInt2;
    int[] arrayOfInt1 = new int[2];
    EGL10 eGL10 = (EGL10)EGLContext.getEGL();
    this.e = eGL10;
    EGLDisplay eGLDisplay = eGL10.eglGetDisplay(EGL10.EGL_DEFAULT_DISPLAY);
    this.f = eGLDisplay;
    this.e.eglInitialize(eGLDisplay, arrayOfInt1);
    arrayOfInt1 = new int[15];
    arrayOfInt1[0] = 12325;
    arrayOfInt1[1] = 0;
    arrayOfInt1[2] = 12326;
    arrayOfInt1[3] = 0;
    arrayOfInt1[4] = 12324;
    arrayOfInt1[5] = 8;
    arrayOfInt1[6] = 12323;
    arrayOfInt1[7] = 8;
    arrayOfInt1[8] = 12322;
    arrayOfInt1[9] = 8;
    arrayOfInt1[10] = 12321;
    arrayOfInt1[11] = 8;
    arrayOfInt1[12] = 12352;
    arrayOfInt1[13] = 4;
    arrayOfInt1[14] = 12344;
    int[] arrayOfInt2 = new int[1];
    this.e.eglChooseConfig(this.f, arrayOfInt1, null, 0, arrayOfInt2);
    int i = arrayOfInt2[0];
    EGLConfig[] arrayOfEGLConfig = new EGLConfig[i];
    this.g = arrayOfEGLConfig;
    this.e.eglChooseConfig(this.f, arrayOfInt1, arrayOfEGLConfig, i, arrayOfInt2);
    EGLConfig eGLConfig = this.g[0];
    this.h = eGLConfig;
    this.i = this.e.eglCreateContext(this.f, eGLConfig, EGL10.EGL_NO_CONTEXT, new int[] { 12440, 2, 12344 });
    EGLSurface eGLSurface = this.e.eglCreatePbufferSurface(this.f, this.h, new int[] { 12375, paramInt1, 12374, paramInt2, 12344 });
    this.j = eGLSurface;
    this.e.eglMakeCurrent(this.f, eGLSurface, eGLSurface, this.i);
    this.k = (GL10)this.i.getGL();
    this.l = Thread.currentThread().getName();
  }
}


/* Location:              C:\soft\dex2jar-2.0\Luxury Logo Maker_ Logo Design-dex2jar.jar!\c6\c0.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */