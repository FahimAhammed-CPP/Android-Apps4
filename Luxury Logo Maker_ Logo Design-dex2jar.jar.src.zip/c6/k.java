package c6;

import android.graphics.PointF;
import android.opengl.GLES20;

public class k implements Runnable {
  public k(i parami, PointF paramPointF, int paramInt) {}
  
  public void run() {
    PointF pointF = this.h;
    float f1 = pointF.x;
    float f2 = pointF.y;
    GLES20.glUniform2fv(this.i, 1, new float[] { f1, f2 }, 0);
  }
}


/* Location:              C:\soft\dex2jar-2.0\Luxury Logo Maker_ Logo Design-dex2jar.jar!\c6\k.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */