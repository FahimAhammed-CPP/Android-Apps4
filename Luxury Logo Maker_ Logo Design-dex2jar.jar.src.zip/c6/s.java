package c6;

import android.opengl.GLES20;

public class s implements Runnable {
  public s(q paramq) {}
  
  public void run() {
    GLES20.glDeleteTextures(1, new int[] { this.h.c }, 0);
    this.h.c = -1;
  }
}


/* Location:              C:\soft\dex2jar-2.0\Luxury Logo Maker_ Logo Design-dex2jar.jar!\c6\s.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */