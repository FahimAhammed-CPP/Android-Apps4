package c6;

import android.opengl.GLES20;
import android.support.v4.media.c;
import android.util.Log;

public class b0 {
  public static int a(String paramString, int paramInt) {
    int[] arrayOfInt = new int[1];
    paramInt = GLES20.glCreateShader(paramInt);
    GLES20.glShaderSource(paramInt, paramString);
    GLES20.glCompileShader(paramInt);
    GLES20.glGetShaderiv(paramInt, 35713, arrayOfInt, 0);
    if (arrayOfInt[0] == 0) {
      StringBuilder stringBuilder = c.a("Compilation\n");
      stringBuilder.append(GLES20.glGetShaderInfoLog(paramInt));
      Log.d("Load Shader Failed", stringBuilder.toString());
      return 0;
    } 
    return paramInt;
  }
}


/* Location:              C:\soft\dex2jar-2.0\Luxury Logo Maker_ Logo Design-dex2jar.jar!\c6\b0.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */