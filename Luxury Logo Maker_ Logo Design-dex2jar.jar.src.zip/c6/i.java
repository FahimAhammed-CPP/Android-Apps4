package c6;

import android.opengl.GLES20;
import android.util.Log;
import java.nio.FloatBuffer;
import java.util.LinkedList;

public class i {
  public final LinkedList<Runnable> a = new LinkedList<Runnable>();
  
  public final String b = "attribute vec4 position;\nattribute vec4 inputTextureCoordinate;\n \nvarying vec2 textureCoordinate;\n \nvoid main()\n{\n    gl_Position = position;\n    textureCoordinate = inputTextureCoordinate.xy;\n}";
  
  public final String c = "varying highp vec2 textureCoordinate;\n \nuniform sampler2D inputImageTexture;\n \nvoid main()\n{\n     gl_FragColor = texture2D(inputImageTexture, textureCoordinate);\n}";
  
  public int d;
  
  public int e;
  
  public int f;
  
  public int g;
  
  public int h;
  
  public int i;
  
  public boolean j;
  
  public i() {}
  
  public i(String paramString1, String paramString2) {}
  
  public final void a() {
    this.j = false;
    GLES20.glDeleteProgram(this.d);
    c();
  }
  
  public final void b() {
    e();
    this.j = true;
    f();
  }
  
  public void c() {}
  
  public void d(int paramInt, FloatBuffer paramFloatBuffer1, FloatBuffer paramFloatBuffer2) {
    GLES20.glUseProgram(this.d);
    i();
    if (!this.j)
      return; 
    paramFloatBuffer1.position(0);
    GLES20.glVertexAttribPointer(this.e, 2, 5126, false, 0, paramFloatBuffer1);
    GLES20.glEnableVertexAttribArray(this.e);
    paramFloatBuffer2.position(0);
    GLES20.glVertexAttribPointer(this.g, 2, 5126, false, 0, paramFloatBuffer2);
    GLES20.glEnableVertexAttribArray(this.g);
    if (paramInt != -1) {
      GLES20.glActiveTexture(33984);
      GLES20.glBindTexture(3553, paramInt);
      GLES20.glUniform1i(this.f, 0);
    } 
    GLES20.glDrawArrays(5, 0, 4);
    GLES20.glDisableVertexAttribArray(this.e);
    GLES20.glDisableVertexAttribArray(this.g);
    GLES20.glBindTexture(3553, 0);
  }
  
  public void e() {
    String str1 = this.b;
    String str2 = this.c;
    int[] arrayOfInt = new int[1];
    int k = b0.a(str1, 35633);
    int j = 0;
    if (k == 0) {
      str1 = "Vertex Shader Failed";
    } else {
      int m = b0.a(str2, 35632);
      if (m == 0) {
        str1 = "Fragment Shader Failed";
      } else {
        int n = GLES20.glCreateProgram();
        GLES20.glAttachShader(n, k);
        GLES20.glAttachShader(n, m);
        GLES20.glLinkProgram(n);
        GLES20.glGetProgramiv(n, 35714, arrayOfInt, 0);
        if (arrayOfInt[0] <= 0) {
          str1 = "Linking Failed";
        } else {
          GLES20.glDeleteShader(k);
          GLES20.glDeleteShader(m);
          j = n;
          this.d = j;
          this.e = GLES20.glGetAttribLocation(j, "position");
          this.f = GLES20.glGetUniformLocation(this.d, "inputImageTexture");
          this.g = GLES20.glGetAttribLocation(this.d, "inputTextureCoordinate");
          this.j = true;
        } 
      } 
    } 
    Log.d("Load Program", str1);
    this.d = j;
    this.e = GLES20.glGetAttribLocation(j, "position");
    this.f = GLES20.glGetUniformLocation(this.d, "inputImageTexture");
    this.g = GLES20.glGetAttribLocation(this.d, "inputTextureCoordinate");
    this.j = true;
  }
  
  public void f() {}
  
  public void g(int paramInt1, int paramInt2) {
    this.h = paramInt1;
    this.i = paramInt2;
  }
  
  public void h(Runnable paramRunnable) {
    synchronized (this.a) {
      this.a.addLast(paramRunnable);
      return;
    } 
  }
  
  public void i() {
    while (!this.a.isEmpty())
      ((Runnable)this.a.removeFirst()).run(); 
  }
  
  public void j(int paramInt, float paramFloat) {
    h(new a(this, paramInt, paramFloat));
  }
  
  public class a implements Runnable {
    public a(i this$0, int param1Int, float param1Float) {}
    
    public void run() {
      GLES20.glUniform1f(this.h, this.i);
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Luxury Logo Maker_ Logo Design-dex2jar.jar!\c6\i.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */