package c6;

import android.opengl.GLES20;

public class g extends i {
  public float k = 0.03F;
  
  public int l;
  
  public float m = 0.003F;
  
  public int n;
  
  public g() {
    super("attribute vec4 position;\nattribute vec4 inputTextureCoordinate;\n \nvarying vec2 textureCoordinate;\n \nvoid main()\n{\n    gl_Position = position;\n    textureCoordinate = inputTextureCoordinate.xy;\n}", "varying highp vec2 textureCoordinate;\nuniform sampler2D inputImageTexture;\nuniform highp float crossHatchSpacing;\nuniform highp float lineWidth;\nconst highp vec3 W = vec3(0.2125, 0.7154, 0.0721);\nvoid main()\n{\nhighp float luminance = dot(texture2D(inputImageTexture, textureCoordinate).rgb, W);\nlowp vec4 colorToDisplay = vec4(1.0, 1.0, 1.0, 1.0);\nif (luminance < 1.00)\n{\nif (mod(textureCoordinate.x + textureCoordinate.y, crossHatchSpacing) <= lineWidth)\n{\ncolorToDisplay = vec4(0.0, 0.0, 0.0, 1.0);\n}\n}\nif (luminance < 0.75)\n{\nif (mod(textureCoordinate.x - textureCoordinate.y, crossHatchSpacing) <= lineWidth)\n{\ncolorToDisplay = vec4(0.0, 0.0, 0.0, 1.0);\n}\n}\nif (luminance < 0.50)\n{\nif (mod(textureCoordinate.x + textureCoordinate.y - (crossHatchSpacing / 2.0), crossHatchSpacing) <= lineWidth)\n{\ncolorToDisplay = vec4(0.0, 0.0, 0.0, 1.0);\n}\n}\nif (luminance < 0.3)\n{\nif (mod(textureCoordinate.x - textureCoordinate.y - (crossHatchSpacing / 2.0), crossHatchSpacing) <= lineWidth)\n{\ncolorToDisplay = vec4(0.0, 0.0, 0.0, 1.0);\n}\n}\ngl_FragColor = colorToDisplay;\n}\n");
  }
  
  public void e() {
    super.e();
    this.l = GLES20.glGetUniformLocation(this.d, "crossHatchSpacing");
    this.n = GLES20.glGetUniformLocation(this.d, "lineWidth");
  }
  
  public void f() {
    float f2 = this.k;
    int j = this.h;
    if (j != 0) {
      f1 = 1.0F / j;
    } else {
      f1 = 4.8828125E-4F;
    } 
    if (f2 < f1) {
      this.k = f1;
    } else {
      this.k = f2;
    } 
    j(this.l, this.k);
    float f1 = this.m;
    this.m = f1;
    j(this.n, f1);
  }
}


/* Location:              C:\soft\dex2jar-2.0\Luxury Logo Maker_ Logo Design-dex2jar.jar!\c6\g.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */