package c6;

import android.opengl.GLES20;

public class r implements Runnable {
  public r(q paramq, i parami) {}
  
  public void run() {
    q q1 = this.i;
    i i1 = q1.a;
    q1.a = this.h;
    if (i1 != null)
      i1.a(); 
    this.i.a.b();
    GLES20.glUseProgram(this.i.a.d);
    q1 = this.i;
    q1.a.g(q1.g, q1.h);
  }
}


/* Location:              C:\soft\dex2jar-2.0\Luxury Logo Maker_ Logo Design-dex2jar.jar!\c6\r.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */