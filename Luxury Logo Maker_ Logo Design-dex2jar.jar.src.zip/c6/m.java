package c6;

import android.opengl.GLES20;

public class m implements Runnable {
  public m(i parami, int paramInt, float[] paramArrayOffloat) {}
  
  public void run() {
    GLES20.glUniformMatrix4fv(this.h, 1, false, this.i, 0);
  }
}


/* Location:              C:\soft\dex2jar-2.0\Luxury Logo Maker_ Logo Design-dex2jar.jar!\c6\m.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */