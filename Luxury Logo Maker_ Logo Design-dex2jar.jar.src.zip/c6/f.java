package c6;

import android.opengl.GLES20;

public class f extends i {
  public int k;
  
  public float l = 1.2F;
  
  public f() {
    super("attribute vec4 position;\nattribute vec4 inputTextureCoordinate;\n \nvarying vec2 textureCoordinate;\n \nvoid main()\n{\n    gl_Position = position;\n    textureCoordinate = inputTextureCoordinate.xy;\n}", "varying highp vec2 textureCoordinate;\n \n uniform sampler2D inputImageTexture;\n uniform lowp float contrast;\n \n void main()\n {\n     lowp vec4 textureColor = texture2D(inputImageTexture, textureCoordinate);\n     \n     gl_FragColor = vec4(((textureColor.rgb - vec3(0.5)) * contrast + vec3(0.5)), textureColor.w);\n }");
  }
  
  public void e() {
    super.e();
    this.k = GLES20.glGetUniformLocation(this.d, "contrast");
  }
  
  public void f() {
    float f1 = this.l;
    this.l = f1;
    j(this.k, f1);
  }
}


/* Location:              C:\soft\dex2jar-2.0\Luxury Logo Maker_ Logo Design-dex2jar.jar!\c6\f.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */