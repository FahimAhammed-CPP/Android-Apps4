package c6;

import android.graphics.PointF;
import android.opengl.GLES20;

public class a0 extends i {
  public int k;
  
  public PointF l;
  
  public int m;
  
  public float[] n;
  
  public int o;
  
  public float p;
  
  public int q;
  
  public float r;
  
  public a0() {
    super("attribute vec4 position;\nattribute vec4 inputTextureCoordinate;\n \nvarying vec2 textureCoordinate;\n \nvoid main()\n{\n    gl_Position = position;\n    textureCoordinate = inputTextureCoordinate.xy;\n}", " uniform sampler2D inputImageTexture;\n varying highp vec2 textureCoordinate;\n \n uniform lowp vec2 vignetteCenter;\n uniform lowp vec3 vignetteColor;\n uniform highp float vignetteStart;\n uniform highp float vignetteEnd;\n \n void main()\n {\n     /*\n     lowp vec3 rgb = texture2D(inputImageTexture, textureCoordinate).rgb;\n     lowp float d = distance(textureCoordinate, vec2(0.5,0.5));\n     rgb *= (1.0 - smoothstep(vignetteStart, vignetteEnd, d));\n     gl_FragColor = vec4(vec3(rgb),1.0);\n      */\n     \n     lowp vec3 rgb = texture2D(inputImageTexture, textureCoordinate).rgb;\n     lowp float d = distance(textureCoordinate, vec2(vignetteCenter.x, vignetteCenter.y));\n     lowp float percent = smoothstep(vignetteStart, vignetteEnd, d);\n     gl_FragColor = vec4(mix(rgb.x, vignetteColor.x, percent), mix(rgb.y, vignetteColor.y, percent), mix(rgb.z, vignetteColor.z, percent), 1.0);\n }");
    this.l = pointF;
    this.n = new float[] { 0.0F, 0.0F, 0.0F };
    this.p = 0.3F;
    this.r = 0.75F;
  }
  
  public void e() {
    super.e();
    this.k = GLES20.glGetUniformLocation(this.d, "vignetteCenter");
    this.m = GLES20.glGetUniformLocation(this.d, "vignetteColor");
    this.o = GLES20.glGetUniformLocation(this.d, "vignetteStart");
    this.q = GLES20.glGetUniformLocation(this.d, "vignetteEnd");
    PointF pointF = this.l;
    this.l = pointF;
    h(new k(this, pointF, this.k));
    float[] arrayOfFloat = this.n;
    this.n = arrayOfFloat;
    h(new j(this, this.m, arrayOfFloat));
    float f = this.p;
    this.p = f;
    j(this.o, f);
    f = this.r;
    this.r = f;
    j(this.q, f);
  }
}


/* Location:              C:\soft\dex2jar-2.0\Luxury Logo Maker_ Logo Design-dex2jar.jar!\c6\a0.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */