package a0;

import android.app.Activity;
import android.content.pm.PackageManager;
import android.os.Build;
import android.os.Handler;
import android.os.Looper;
import android.text.TextUtils;
import b0.a;
import java.util.Arrays;

public class a extends a {
  public static void c(Activity paramActivity, String[] paramArrayOfString, int paramInt) {
    StringBuilder stringBuilder;
    int j = paramArrayOfString.length;
    int i = 0;
    while (i < j) {
      if (!TextUtils.isEmpty(paramArrayOfString[i])) {
        i++;
        continue;
      } 
      stringBuilder = android.support.v4.media.c.a("Permission request for permissions ");
      stringBuilder.append(Arrays.toString((Object[])paramArrayOfString));
      stringBuilder.append(" must not contain null or empty values");
      throw new IllegalArgumentException(stringBuilder.toString());
    } 
    if (Build.VERSION.SDK_INT >= 23) {
      if (stringBuilder instanceof c)
        ((c)stringBuilder).b(paramInt); 
      stringBuilder.requestPermissions(paramArrayOfString, paramInt);
      return;
    } 
    if (stringBuilder instanceof b)
      (new Handler(Looper.getMainLooper())).post(new a(paramArrayOfString, (Activity)stringBuilder, paramInt)); 
  }
  
  public class a implements Runnable {
    public a(a this$0, Activity param1Activity, int param1Int) {}
    
    public void run() {
      int[] arrayOfInt = new int[this.h.length];
      PackageManager packageManager = this.i.getPackageManager();
      String str = this.i.getPackageName();
      int j = this.h.length;
      for (int i = 0; i < j; i++)
        arrayOfInt[i] = packageManager.checkPermission(this.h[i], str); 
      ((a.b)this.i).onRequestPermissionsResult(this.j, this.h, arrayOfInt);
    }
  }
  
  public static interface b {
    void onRequestPermissionsResult(int param1Int, String[] param1ArrayOfString, int[] param1ArrayOfint);
  }
  
  public static interface c {
    void b(int param1Int);
  }
}


/* Location:              C:\soft\dex2jar-2.0\Luxury Logo Maker_ Logo Design-dex2jar.jar!\a0\a.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */