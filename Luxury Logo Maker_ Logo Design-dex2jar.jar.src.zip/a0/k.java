package a0;

import android.app.Notification;
import android.app.Person;
import android.app.RemoteInput;
import android.graphics.drawable.Icon;
import android.os.Build;
import android.os.Bundle;
import android.os.Parcelable;
import android.text.TextUtils;
import androidx.core.graphics.drawable.IconCompat;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Iterator;
import java.util.List;
import java.util.Objects;
import r.c;

public class k {
  public final Notification.Builder a;
  
  public final i b;
  
  public final List<Bundle> c;
  
  public final Bundle d;
  
  public k(i parami) {
    o o;
    boolean bool1;
    Notification.Builder builder1;
    List<String> list;
    this.c = new ArrayList<Bundle>();
    this.d = new Bundle();
    this.b = parami;
    if (Build.VERSION.SDK_INT >= 26) {
      builder1 = new Notification.Builder(parami.a, parami.m);
    } else {
      builder1 = new Notification.Builder(parami.a);
    } 
    this.a = builder1;
    Notification notification = parami.o;
    Notification.Builder builder2 = builder1.setWhen(notification.when).setSmallIcon(notification.icon, notification.iconLevel).setContent(notification.contentView).setTicker(notification.tickerText, null).setVibrate(notification.vibrate).setLights(notification.ledARGB, notification.ledOnMS, notification.ledOffMS);
    int j = notification.flags;
    boolean bool2 = true;
    if ((j & 0x2) != 0) {
      bool1 = true;
    } else {
      bool1 = false;
    } 
    builder2 = builder2.setOngoing(bool1);
    if ((notification.flags & 0x8) != 0) {
      bool1 = true;
    } else {
      bool1 = false;
    } 
    builder2 = builder2.setOnlyAlertOnce(bool1);
    if ((notification.flags & 0x10) != 0) {
      bool1 = true;
    } else {
      bool1 = false;
    } 
    builder2 = builder2.setAutoCancel(bool1).setDefaults(notification.defaults).setContentTitle(parami.e).setContentText(parami.f).setContentInfo(null).setContentIntent(parami.g).setDeleteIntent(notification.deleteIntent);
    if ((notification.flags & 0x80) != 0) {
      bool1 = bool2;
    } else {
      bool1 = false;
    } 
    builder2.setFullScreenIntent(null, bool1).setLargeIcon(null).setNumber(0).setProgress(0, 0, false);
    builder1.setSubText(null).setUsesChronometer(false).setPriority(parami.h);
    for (g g : parami.b) {
      Notification.Action.Builder builder;
      Bundle bundle1;
      j = Build.VERSION.SDK_INT;
      IconCompat iconCompat = g.a();
      if (j >= 23) {
        if (iconCompat != null) {
          Icon icon = iconCompat.e();
        } else {
          iconCompat = null;
        } 
        builder = new Notification.Action.Builder((Icon)iconCompat, g.j, g.k);
      } else {
        if (builder != null) {
          j = builder.c();
        } else {
          j = 0;
        } 
        builder = new Notification.Action.Builder(j, g.j, g.k);
      } 
      o[] arrayOfO = g.c;
      if (arrayOfO != null) {
        int m = arrayOfO.length;
        RemoteInput[] arrayOfRemoteInput = new RemoteInput[m];
        if (arrayOfO.length <= 0) {
          for (j = 0; j < m; j++)
            builder.addRemoteInput(arrayOfRemoteInput[j]); 
        } else {
          o = arrayOfO[0];
          throw null;
        } 
      } 
      if (g.a != null) {
        bundle1 = new Bundle(g.a);
      } else {
        bundle1 = new Bundle();
      } 
      bundle1.putBoolean("android.support.allowGeneratedReplies", g.e);
      j = Build.VERSION.SDK_INT;
      if (j >= 24)
        builder.setAllowGeneratedReplies(g.e); 
      bundle1.putInt("android.support.action.semanticAction", g.g);
      if (j >= 28)
        builder.setSemanticAction(g.g); 
      if (j >= 29)
        builder.setContextual(g.h); 
      bundle1.putBoolean("android.support.action.showsUserInterface", g.f);
      builder.addExtras(bundle1);
      this.a.addAction(builder.build());
    } 
    Bundle bundle = ((i)o).l;
    if (bundle != null)
      this.d.putAll(bundle); 
    j = Build.VERSION.SDK_INT;
    this.a.setShowWhen(((i)o).i);
    this.a.setLocalOnly(((i)o).k).setGroup(null).setGroupSummary(false).setSortKey(null);
    this.a.setCategory(null).setColor(0).setVisibility(0).setPublicVersion(null).setSound(notification.sound, notification.audioAttributes);
    if (j < 28) {
      list = a(b(((i)o).c), ((i)o).p);
    } else {
      list = ((i)o).p;
    } 
    if (list != null && !list.isEmpty())
      for (String str : list)
        this.a.addPerson(str);  
    if (((i)o).d.size() > 0) {
      if (((i)o).l == null)
        ((i)o).l = new Bundle(); 
      Bundle bundle2 = ((i)o).l.getBundle("android.car.EXTENSIONS");
      Bundle bundle1 = bundle2;
      if (bundle2 == null)
        bundle1 = new Bundle(); 
      Bundle bundle3 = new Bundle(bundle1);
      Bundle bundle4 = new Bundle();
      for (j = 0; j < ((i)o).d.size(); j++) {
        boolean bool;
        String str = Integer.toString(j);
        g g = ((i)o).d.get(j);
        Object object = l.a;
        Bundle bundle5 = new Bundle();
        object = g.a();
        if (object != null) {
          bool = object.c();
        } else {
          bool = false;
        } 
        bundle5.putInt("icon", bool);
        bundle5.putCharSequence("title", g.j);
        bundle5.putParcelable("actionIntent", (Parcelable)g.k);
        if (g.a != null) {
          object = new Bundle(g.a);
        } else {
          object = new Bundle();
        } 
        object.putBoolean("android.support.allowGeneratedReplies", g.e);
        bundle5.putBundle("extras", (Bundle)object);
        bundle5.putParcelableArray("remoteInputs", (Parcelable[])l.a(g.c));
        bundle5.putBoolean("showsUserInterface", g.f);
        bundle5.putInt("semanticAction", g.g);
        bundle4.putBundle(str, bundle5);
      } 
      bundle1.putBundle("invisible_actions", bundle4);
      bundle3.putBundle("invisible_actions", bundle4);
      if (((i)o).l == null)
        ((i)o).l = new Bundle(); 
      ((i)o).l.putBundle("android.car.EXTENSIONS", bundle1);
      this.d.putBundle("android.car.EXTENSIONS", bundle3);
    } 
    j = Build.VERSION.SDK_INT;
    if (j >= 24)
      this.a.setExtras(((i)o).l).setRemoteInputHistory(null); 
    if (j >= 26) {
      this.a.setBadgeIconType(0).setSettingsText(null).setShortcutId(null).setTimeoutAfter(0L).setGroupAlertBehavior(0);
      if (!TextUtils.isEmpty(((i)o).m))
        this.a.setSound(null).setDefaults(0).setLights(0, 0, 0).setVibrate(null); 
    } 
    if (j >= 28)
      for (n n : ((i)o).c) {
        Notification.Builder builder = this.a;
        Objects.requireNonNull(n);
        builder.addPerson((new Person.Builder()).setName(null).setIcon(null).setUri(null).setKey(null).setBot(false).setImportant(false).build());
      }  
    if (Build.VERSION.SDK_INT >= 29) {
      this.a.setAllowSystemGeneratedContextualActions(((i)o).n);
      this.a.setBubbleMetadata(null);
    } 
  }
  
  public static List<String> a(List<String> paramList1, List<String> paramList2) {
    if (paramList1 == null)
      return paramList2; 
    if (paramList2 == null)
      return paramList1; 
    int j = paramList1.size();
    c c = new c(paramList2.size() + j);
    c.addAll(paramList1);
    c.addAll(paramList2);
    return new ArrayList<String>((Collection<? extends String>)c);
  }
  
  public static List<String> b(List<n> paramList) {
    if (paramList == null)
      return null; 
    ArrayList<String> arrayList = new ArrayList(paramList.size());
    Iterator<n> iterator = paramList.iterator();
    while (iterator.hasNext()) {
      Objects.requireNonNull(iterator.next());
      arrayList.add("");
    } 
    return arrayList;
  }
}


/* Location:              C:\soft\dex2jar-2.0\Luxury Logo Maker_ Logo Design-dex2jar.jar!\a0\k.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */