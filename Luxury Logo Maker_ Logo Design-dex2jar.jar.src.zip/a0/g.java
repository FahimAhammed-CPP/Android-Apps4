package a0;

import android.app.PendingIntent;
import android.graphics.drawable.Icon;
import android.os.Build;
import android.os.Bundle;
import android.util.Log;
import androidx.core.graphics.drawable.IconCompat;
import java.lang.reflect.InvocationTargetException;

public class g {
  public final Bundle a;
  
  public IconCompat b;
  
  public final o[] c;
  
  public final o[] d;
  
  public boolean e;
  
  public boolean f;
  
  public final int g;
  
  public final boolean h;
  
  @Deprecated
  public int i;
  
  public CharSequence j;
  
  public PendingIntent k;
  
  public g(int paramInt, CharSequence paramCharSequence, PendingIntent paramPendingIntent) {
    IconCompat iconCompat;
    this.f = true;
    this.b = iconCompat;
    if (iconCompat != null) {
      int i = iconCompat.a;
      paramInt = i;
      if (i == -1) {
        int j = Build.VERSION.SDK_INT;
        paramInt = i;
        if (j >= 23) {
          Icon icon = (Icon)iconCompat.b;
          if (j >= 28) {
            paramInt = icon.getType();
          } else {
            try {
              paramInt = ((Integer)icon.getClass().getMethod("getType", new Class[0]).invoke(icon, new Object[0])).intValue();
            } catch (IllegalAccessException illegalAccessException) {
              StringBuilder stringBuilder = new StringBuilder();
              stringBuilder.append("Unable to get icon type ");
              stringBuilder.append(icon);
              Log.e("IconCompat", stringBuilder.toString(), illegalAccessException);
              paramInt = -1;
            } catch (InvocationTargetException invocationTargetException) {
              StringBuilder stringBuilder = new StringBuilder();
            } catch (NoSuchMethodException noSuchMethodException) {
              StringBuilder stringBuilder = new StringBuilder();
            } 
          } 
        } 
      } 
      if (paramInt == 2)
        this.i = iconCompat.c(); 
    } 
    this.j = i.b(paramCharSequence);
    this.k = paramPendingIntent;
    this.a = bundle;
    this.c = null;
    this.d = null;
    this.e = true;
    this.g = 0;
    this.f = true;
    this.h = false;
  }
  
  public IconCompat a() {
    if (this.b == null) {
      int i = this.i;
      if (i != 0)
        this.b = IconCompat.b(null, "", i); 
    } 
    return this.b;
  }
}


/* Location:              C:\soft\dex2jar-2.0\Luxury Logo Maker_ Logo Design-dex2jar.jar!\a0\g.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */