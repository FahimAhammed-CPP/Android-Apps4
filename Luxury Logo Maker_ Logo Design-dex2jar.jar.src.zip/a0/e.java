package a0;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.os.Bundle;
import android.view.KeyEvent;
import android.view.View;
import android.view.Window;
import androidx.lifecycle.i;
import androidx.lifecycle.j;
import androidx.lifecycle.t;
import k0.d;

public class e extends Activity implements i, d.a {
  public j h = new j(this);
  
  public androidx.lifecycle.e a() {
    return (androidx.lifecycle.e)this.h;
  }
  
  public boolean dispatchKeyEvent(KeyEvent paramKeyEvent) {
    View view = getWindow().getDecorView();
    return (view != null && d.a(view, paramKeyEvent)) ? true : d.b(this, view, (Window.Callback)this, paramKeyEvent);
  }
  
  public boolean dispatchKeyShortcutEvent(KeyEvent paramKeyEvent) {
    View view = getWindow().getDecorView();
    return (view != null && d.a(view, paramKeyEvent)) ? true : super.dispatchKeyShortcutEvent(paramKeyEvent);
  }
  
  public boolean e(KeyEvent paramKeyEvent) {
    return super.dispatchKeyEvent(paramKeyEvent);
  }
  
  @SuppressLint({"RestrictedApi"})
  public void onCreate(Bundle paramBundle) {
    super.onCreate(paramBundle);
    t.c(this);
  }
  
  public void onSaveInstanceState(Bundle paramBundle) {
    j j1 = this.h;
    androidx.lifecycle.e.c c = androidx.lifecycle.e.c.j;
    j1.c("markState");
    j1.c("setCurrentState");
    j1.f(c);
    super.onSaveInstanceState(paramBundle);
  }
}


/* Location:              C:\soft\dex2jar-2.0\Luxury Logo Maker_ Logo Design-dex2jar.jar!\a0\e.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */