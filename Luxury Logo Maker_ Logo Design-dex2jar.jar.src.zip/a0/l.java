package a0;

import android.os.Bundle;

public class l {
  public static final Object a = new Object();
  
  public static Bundle[] a(o[] paramArrayOfo) {
    if (paramArrayOfo == null)
      return null; 
    Bundle[] arrayOfBundle = new Bundle[paramArrayOfo.length];
    if (paramArrayOfo.length <= 0)
      return arrayOfBundle; 
    o o1 = paramArrayOfo[0];
    new Bundle();
    throw null;
  }
}


/* Location:              C:\soft\dex2jar-2.0\Luxury Logo Maker_ Logo Design-dex2jar.jar!\a0\l.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */