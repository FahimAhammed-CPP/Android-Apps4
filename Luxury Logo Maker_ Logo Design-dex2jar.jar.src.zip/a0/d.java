package a0;

import android.util.Log;
import java.lang.reflect.Method;

public class d implements Runnable {
  public d(Object paramObject1, Object paramObject2) {}
  
  public void run() {
    try {
      Method method = c.d;
      return;
    } catch (RuntimeException runtimeException) {
      return;
    } finally {
      Exception exception = null;
      Log.e("ActivityRecreator", "Exception while invoking performStopActivity", exception);
    } 
  }
}


/* Location:              C:\soft\dex2jar-2.0\Luxury Logo Maker_ Logo Design-dex2jar.jar!\a0\d.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */