package a0;

import android.app.Notification;
import android.app.PendingIntent;
import android.content.Context;
import android.os.Build;
import android.os.Bundle;
import java.util.ArrayList;
import java.util.Objects;

public class i {
  public Context a;
  
  public ArrayList<g> b = new ArrayList<g>();
  
  public ArrayList<n> c = new ArrayList<n>();
  
  public ArrayList<g> d = new ArrayList<g>();
  
  public CharSequence e;
  
  public CharSequence f;
  
  public PendingIntent g;
  
  public int h;
  
  public boolean i = true;
  
  public j j;
  
  public boolean k = false;
  
  public Bundle l;
  
  public String m;
  
  public boolean n;
  
  public Notification o;
  
  @Deprecated
  public ArrayList<String> p;
  
  public i(Context paramContext, String paramString) {
    Notification notification = new Notification();
    this.o = notification;
    this.a = paramContext;
    this.m = paramString;
    notification.when = System.currentTimeMillis();
    this.o.audioStreamType = -1;
    this.h = 0;
    this.p = new ArrayList<String>();
    this.n = true;
  }
  
  public static CharSequence b(CharSequence paramCharSequence) {
    if (paramCharSequence == null)
      return paramCharSequence; 
    CharSequence charSequence = paramCharSequence;
    if (paramCharSequence.length() > 5120)
      charSequence = paramCharSequence.subSequence(0, 5120); 
    return charSequence;
  }
  
  public Notification a() {
    k k1 = new k(this);
    j j1 = k1.b.j;
    if (j1 != null) {
      h h = (h)j1;
      (new Notification.BigTextStyle(k1.a)).setBigContentTitle(null).bigText(h.b);
    } 
    int k = Build.VERSION.SDK_INT;
    if (k < 26 && k < 24)
      k1.a.setExtras(k1.d); 
    Notification notification = k1.a.build();
    Objects.requireNonNull(k1.b);
    if (j1 != null)
      Objects.requireNonNull(k1.b.j); 
    if (j1 != null) {
      Bundle bundle = notification.extras;
      if (bundle != null)
        bundle.putString("androidx.core.app.extra.COMPAT_TEMPLATE", "androidx.core.app.NotificationCompat$BigTextStyle"); 
    } 
    return notification;
  }
  
  public i c(boolean paramBoolean) {
    int k;
    Notification notification;
    if (paramBoolean) {
      notification = this.o;
      k = notification.flags | 0x10;
    } else {
      notification = this.o;
      k = notification.flags & 0xFFFFFFEF;
    } 
    notification.flags = k;
    return this;
  }
  
  public i d(j paramj) {
    if (this.j != paramj) {
      this.j = paramj;
      if (paramj.a != this) {
        paramj.a = this;
        d(paramj);
      } 
    } 
    return this;
  }
}


/* Location:              C:\soft\dex2jar-2.0\Luxury Logo Maker_ Logo Design-dex2jar.jar!\a0\i.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */