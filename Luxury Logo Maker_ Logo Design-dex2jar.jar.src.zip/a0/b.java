package a0;

import android.app.Activity;

public class b implements Runnable {
  public b(Activity paramActivity) {}
  
  public void run() {
    if (!this.h.isFinishing() && !c.b(this.h))
      this.h.recreate(); 
  }
}


/* Location:              C:\soft\dex2jar-2.0\Luxury Logo Maker_ Logo Design-dex2jar.jar!\a0\b.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */