package a2;

public enum c {
  h, i, j;
  
  static {
    c c1 = new c("SOURCE", 0);
    h = c1;
    c c2 = new c("TRANSFORMED", 1);
    i = c2;
    c c3 = new c("NONE", 2);
    j = c3;
    k = new c[] { c1, c2, c3 };
  }
}


/* Location:              C:\soft\dex2jar-2.0\Luxury Logo Maker_ Logo Design-dex2jar.jar!\a2\c.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */