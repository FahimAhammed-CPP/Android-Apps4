package a2;

import android.support.v4.media.c;
import java.security.MessageDigest;
import r.a;
import r.g;
import v2.b;

public final class h implements f {
  public final a<g<?>, Object> b = (a<g<?>, Object>)new b();
  
  public void a(MessageDigest paramMessageDigest) {
    int i = 0;
    while (true) {
      a<g<?>, Object> a1 = this.b;
      if (i < ((g)a1).j) {
        g g = (g)a1.h(i);
        Object object = this.b.l(i);
        g.b<Object> b = g.b;
        if (g.d == null)
          g.d = g.c.getBytes(f.a); 
        b.a(g.d, object, paramMessageDigest);
        i++;
        continue;
      } 
      break;
    } 
  }
  
  public <T> T c(g<T> paramg) {
    boolean bool;
    if (this.b.e(paramg) >= 0) {
      bool = true;
    } else {
      bool = false;
    } 
    return (T)(bool ? this.b.getOrDefault(paramg, null) : (Object)paramg.a);
  }
  
  public void d(h paramh) {
    this.b.i((g)paramh.b);
  }
  
  public boolean equals(Object paramObject) {
    if (paramObject instanceof h) {
      paramObject = paramObject;
      return this.b.equals(((h)paramObject).b);
    } 
    return false;
  }
  
  public int hashCode() {
    return this.b.hashCode();
  }
  
  public String toString() {
    StringBuilder stringBuilder = c.a("Options{values=");
    stringBuilder.append(this.b);
    stringBuilder.append('}');
    return stringBuilder.toString();
  }
}


/* Location:              C:\soft\dex2jar-2.0\Luxury Logo Maker_ Logo Design-dex2jar.jar!\a2\h.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */