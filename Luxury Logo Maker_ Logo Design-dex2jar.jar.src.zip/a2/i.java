package a2;

public enum i {
  h;
  
  static {
    i i1 = new i("SRGB", 0);
    i i2 = new i("DISPLAY_P3", 1);
    h = i2;
    i = new i[] { i1, i2 };
  }
}


/* Location:              C:\soft\dex2jar-2.0\Luxury Logo Maker_ Logo Design-dex2jar.jar!\a2\i.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */