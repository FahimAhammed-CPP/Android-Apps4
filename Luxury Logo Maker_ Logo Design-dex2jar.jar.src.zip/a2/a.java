package a2;

public enum a {
  h, i, j, k, l;
  
  static {
    a a1 = new a("LOCAL", 0);
    h = a1;
    a a2 = new a("REMOTE", 1);
    i = a2;
    a a3 = new a("DATA_DISK_CACHE", 2);
    j = a3;
    a a4 = new a("RESOURCE_DISK_CACHE", 3);
    k = a4;
    a a5 = new a("MEMORY_CACHE", 4);
    l = a5;
    m = new a[] { a1, a2, a3, a4, a5 };
  }
}


/* Location:              C:\soft\dex2jar-2.0\Luxury Logo Maker_ Logo Design-dex2jar.jar!\a2\a.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */