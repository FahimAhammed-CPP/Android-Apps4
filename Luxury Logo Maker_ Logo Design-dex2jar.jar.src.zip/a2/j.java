package a2;

import c2.x;

public interface j<T, Z> {
  x<Z> a(T paramT, int paramInt1, int paramInt2, h paramh);
  
  boolean b(T paramT, h paramh);
}


/* Location:              C:\soft\dex2jar-2.0\Luxury Logo Maker_ Logo Design-dex2jar.jar!\a2\j.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */