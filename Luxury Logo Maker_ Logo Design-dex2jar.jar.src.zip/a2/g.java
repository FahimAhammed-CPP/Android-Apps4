package a2;

import android.support.v4.media.c;
import android.text.TextUtils;
import java.security.MessageDigest;
import java.util.Objects;

public final class g<T> {
  public static final b<Object> e = new a();
  
  public final T a;
  
  public final b<T> b;
  
  public final String c;
  
  public volatile byte[] d;
  
  public g(String paramString, T paramT, b<T> paramb) {
    if (!TextUtils.isEmpty(paramString)) {
      this.c = paramString;
      this.a = paramT;
      Objects.requireNonNull(paramb, "Argument must not be null");
      this.b = paramb;
      return;
    } 
    throw new IllegalArgumentException("Must not be null or empty");
  }
  
  public static <T> g<T> a(String paramString) {
    return new g<T>(paramString, null, (b)e);
  }
  
  public static <T> g<T> b(String paramString, T paramT) {
    return new g<T>(paramString, paramT, (b)e);
  }
  
  public boolean equals(Object paramObject) {
    if (paramObject instanceof g) {
      paramObject = paramObject;
      return this.c.equals(((g)paramObject).c);
    } 
    return false;
  }
  
  public int hashCode() {
    return this.c.hashCode();
  }
  
  public String toString() {
    StringBuilder stringBuilder = c.a("Option{key='");
    stringBuilder.append(this.c);
    stringBuilder.append('\'');
    stringBuilder.append('}');
    return stringBuilder.toString();
  }
  
  public class a implements b<Object> {
    public void a(byte[] param1ArrayOfbyte, Object param1Object, MessageDigest param1MessageDigest) {}
  }
  
  public static interface b<T> {
    void a(byte[] param1ArrayOfbyte, T param1T, MessageDigest param1MessageDigest);
  }
}


/* Location:              C:\soft\dex2jar-2.0\Luxury Logo Maker_ Logo Design-dex2jar.jar!\a2\g.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */