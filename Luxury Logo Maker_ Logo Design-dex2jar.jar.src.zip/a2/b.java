package a2;

public enum b {
  h, i;
  
  static {
    b b1 = new b("PREFER_ARGB_8888", 0);
    h = b1;
    b b2 = new b("PREFER_RGB_565", 1);
    i = b2;
    j = new b[] { b1, b2 };
  }
}


/* Location:              C:\soft\dex2jar-2.0\Luxury Logo Maker_ Logo Design-dex2jar.jar!\a2\b.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */