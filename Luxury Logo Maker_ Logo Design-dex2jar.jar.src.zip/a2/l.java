package a2;

import android.content.Context;
import c2.x;

public interface l<T> extends f {
  x<T> b(Context paramContext, x<T> paramx, int paramInt1, int paramInt2);
}


/* Location:              C:\soft\dex2jar-2.0\Luxury Logo Maker_ Logo Design-dex2jar.jar!\a2\l.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */