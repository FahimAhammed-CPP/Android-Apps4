package c1;

import android.animation.Animator;

public class c implements Animator.AnimatorListener {
  public c(d paramd, d.a parama) {}
  
  public void onAnimationCancel(Animator paramAnimator) {}
  
  public void onAnimationEnd(Animator paramAnimator) {}
  
  public void onAnimationRepeat(Animator paramAnimator) {
    this.b.a(1.0F, this.a, true);
    d.a a1 = this.a;
    a1.k = a1.e;
    a1.l = a1.f;
    a1.m = a1.g;
    a1.a((a1.j + 1) % a1.i.length);
    d d1 = this.b;
    if (d1.m) {
      d1.m = false;
      paramAnimator.cancel();
      paramAnimator.setDuration(1332L);
      paramAnimator.start();
      this.a.b(false);
      return;
    } 
    d1.l++;
  }
  
  public void onAnimationStart(Animator paramAnimator) {
    this.b.l = 0.0F;
  }
}


/* Location:              C:\soft\dex2jar-2.0\Luxury Logo Maker_ Logo Design-dex2jar.jar!\c1\c.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */