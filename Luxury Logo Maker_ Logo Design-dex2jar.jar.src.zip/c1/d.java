package c1;

import android.animation.Animator;
import android.animation.TimeInterpolator;
import android.animation.ValueAnimator;
import android.content.Context;
import android.content.res.Resources;
import android.graphics.Canvas;
import android.graphics.ColorFilter;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.Rect;
import android.graphics.RectF;
import android.graphics.drawable.Animatable;
import android.graphics.drawable.Drawable;
import android.view.animation.Interpolator;
import android.view.animation.LinearInterpolator;
import f3.o0;
import java.util.Objects;
import s0.b;

public class d extends Drawable implements Animatable {
  public static final Interpolator n = (Interpolator)new LinearInterpolator();
  
  public static final Interpolator o = (Interpolator)new b();
  
  public static final int[] p = new int[] { -16777216 };
  
  public final a h;
  
  public float i;
  
  public Resources j;
  
  public Animator k;
  
  public float l;
  
  public boolean m;
  
  public d(Context paramContext) {
    Objects.requireNonNull(paramContext);
    this.j = paramContext.getResources();
    a a1 = new a();
    this.h = a1;
    a1.i = p;
    a1.a(0);
    a1.h = 2.5F;
    a1.b.setStrokeWidth(2.5F);
    invalidateSelf();
    ValueAnimator valueAnimator = ValueAnimator.ofFloat(new float[] { 0.0F, 1.0F });
    valueAnimator.addUpdateListener(new b(this, a1));
    valueAnimator.setRepeatCount(-1);
    valueAnimator.setRepeatMode(1);
    valueAnimator.setInterpolator((TimeInterpolator)n);
    valueAnimator.addListener(new c(this, a1));
    this.k = (Animator)valueAnimator;
  }
  
  public void a(float paramFloat, a parama, boolean paramBoolean) {
    if (this.m) {
      d(paramFloat, parama);
      float f1 = (float)(Math.floor((parama.m / 0.8F)) + 1.0D);
      float f2 = parama.k;
      float f3 = parama.l;
      parama.e = (f3 - 0.01F - f2) * paramFloat + f2;
      parama.f = f3;
      f2 = parama.m;
      parama.g = o0.a(f1, f2, paramFloat, f2);
      return;
    } 
    if (paramFloat != 1.0F || paramBoolean) {
      float f1;
      float f2;
      float f3 = parama.m;
      if (paramFloat < 0.5F) {
        f1 = paramFloat / 0.5F;
        f2 = parama.k;
        f1 = ((s0.d)o).getInterpolation(f1) * 0.79F + 0.01F + f2;
      } else {
        f2 = (paramFloat - 0.5F) / 0.5F;
        f1 = parama.k + 0.79F;
        f2 = f1 - (1.0F - ((s0.d)o).getInterpolation(f2)) * 0.79F + 0.01F;
      } 
      float f4 = this.l;
      parama.e = f2;
      parama.f = f1;
      parama.g = 0.20999998F * paramFloat + f3;
      this.i = (paramFloat + f4) * 216.0F;
    } 
  }
  
  public final void b(float paramFloat1, float paramFloat2, float paramFloat3, float paramFloat4) {
    a a1 = this.h;
    float f = (this.j.getDisplayMetrics()).density;
    paramFloat2 *= f;
    a1.h = paramFloat2;
    a1.b.setStrokeWidth(paramFloat2);
    a1.q = paramFloat1 * f;
    a1.a(0);
    a1.r = (int)(paramFloat3 * f);
    a1.s = (int)(paramFloat4 * f);
  }
  
  public void c(int paramInt) {
    float f1;
    float f2;
    float f3;
    float f4;
    if (paramInt == 0) {
      f4 = 11.0F;
      f1 = 3.0F;
      f2 = 12.0F;
      f3 = 6.0F;
    } else {
      f4 = 7.5F;
      f1 = 2.5F;
      f2 = 10.0F;
      f3 = 5.0F;
    } 
    b(f4, f1, f2, f3);
    invalidateSelf();
  }
  
  public void d(float paramFloat, a parama) {
    int i;
    if (paramFloat > 0.75F) {
      paramFloat = (paramFloat - 0.75F) / 0.25F;
      int[] arrayOfInt = parama.i;
      int j = parama.j;
      i = arrayOfInt[j];
      j = arrayOfInt[(j + 1) % arrayOfInt.length];
      int k = i >> 24 & 0xFF;
      int m = i >> 16 & 0xFF;
      int n = i >> 8 & 0xFF;
      i &= 0xFF;
      i = k + (int)(((j >> 24 & 0xFF) - k) * paramFloat) << 24 | m + (int)(((j >> 16 & 0xFF) - m) * paramFloat) << 16 | n + (int)(((j >> 8 & 0xFF) - n) * paramFloat) << 8 | i + (int)(paramFloat * ((j & 0xFF) - i));
    } else {
      i = parama.i[parama.j];
    } 
    parama.u = i;
  }
  
  public void draw(Canvas paramCanvas) {
    Rect rect = getBounds();
    paramCanvas.save();
    paramCanvas.rotate(this.i, rect.exactCenterX(), rect.exactCenterY());
    a a1 = this.h;
    RectF rectF = a1.a;
    float f2 = a1.q;
    float f1 = a1.h / 2.0F + f2;
    if (f2 <= 0.0F)
      f1 = Math.min(rect.width(), rect.height()) / 2.0F - Math.max(a1.r * a1.p / 2.0F, a1.h / 2.0F); 
    rectF.set(rect.centerX() - f1, rect.centerY() - f1, rect.centerX() + f1, rect.centerY() + f1);
    f1 = a1.e;
    f2 = a1.g;
    f1 = (f1 + f2) * 360.0F;
    f2 = (a1.f + f2) * 360.0F - f1;
    a1.b.setColor(a1.u);
    a1.b.setAlpha(a1.t);
    float f3 = a1.h / 2.0F;
    rectF.inset(f3, f3);
    paramCanvas.drawCircle(rectF.centerX(), rectF.centerY(), rectF.width() / 2.0F, a1.d);
    f3 = -f3;
    rectF.inset(f3, f3);
    paramCanvas.drawArc(rectF, f1, f2, false, a1.b);
    if (a1.n) {
      Path path = a1.o;
      if (path == null) {
        path = new Path();
        a1.o = path;
        path.setFillType(Path.FillType.EVEN_ODD);
      } else {
        path.reset();
      } 
      f3 = Math.min(rectF.width(), rectF.height()) / 2.0F;
      float f4 = a1.r * a1.p / 2.0F;
      a1.o.moveTo(0.0F, 0.0F);
      a1.o.lineTo(a1.r * a1.p, 0.0F);
      path = a1.o;
      float f5 = a1.r;
      float f6 = a1.p;
      path.lineTo(f5 * f6 / 2.0F, a1.s * f6);
      path = a1.o;
      f5 = rectF.centerX();
      f6 = rectF.centerY();
      path.offset(f5 + f3 - f4, a1.h / 2.0F + f6);
      a1.o.close();
      a1.c.setColor(a1.u);
      a1.c.setAlpha(a1.t);
      paramCanvas.save();
      paramCanvas.rotate(f1 + f2, rectF.centerX(), rectF.centerY());
      paramCanvas.drawPath(a1.o, a1.c);
      paramCanvas.restore();
    } 
    paramCanvas.restore();
  }
  
  public int getAlpha() {
    return this.h.t;
  }
  
  public int getOpacity() {
    return -3;
  }
  
  public boolean isRunning() {
    return this.k.isRunning();
  }
  
  public void setAlpha(int paramInt) {
    this.h.t = paramInt;
    invalidateSelf();
  }
  
  public void setColorFilter(ColorFilter paramColorFilter) {
    this.h.b.setColorFilter(paramColorFilter);
    invalidateSelf();
  }
  
  public void start() {
    long l;
    Animator animator;
    this.k.cancel();
    a a1 = this.h;
    float f1 = a1.e;
    a1.k = f1;
    float f2 = a1.f;
    a1.l = f2;
    a1.m = a1.g;
    if (f2 != f1) {
      this.m = true;
      animator = this.k;
      l = 666L;
    } else {
      animator.a(0);
      a a2 = this.h;
      a2.k = 0.0F;
      a2.l = 0.0F;
      a2.m = 0.0F;
      a2.e = 0.0F;
      a2.f = 0.0F;
      a2.g = 0.0F;
      animator = this.k;
      l = 1332L;
    } 
    animator.setDuration(l);
    this.k.start();
  }
  
  public void stop() {
    this.k.cancel();
    this.i = 0.0F;
    this.h.b(false);
    this.h.a(0);
    a a1 = this.h;
    a1.k = 0.0F;
    a1.l = 0.0F;
    a1.m = 0.0F;
    a1.e = 0.0F;
    a1.f = 0.0F;
    a1.g = 0.0F;
    invalidateSelf();
  }
  
  public static class a {
    public final RectF a = new RectF();
    
    public final Paint b;
    
    public final Paint c;
    
    public final Paint d;
    
    public float e;
    
    public float f;
    
    public float g;
    
    public float h;
    
    public int[] i;
    
    public int j;
    
    public float k;
    
    public float l;
    
    public float m;
    
    public boolean n;
    
    public Path o;
    
    public float p;
    
    public float q;
    
    public int r;
    
    public int s;
    
    public int t;
    
    public int u;
    
    public a() {
      Paint paint1 = new Paint();
      this.b = paint1;
      Paint paint2 = new Paint();
      this.c = paint2;
      Paint paint3 = new Paint();
      this.d = paint3;
      this.e = 0.0F;
      this.f = 0.0F;
      this.g = 0.0F;
      this.h = 5.0F;
      this.p = 1.0F;
      this.t = 255;
      paint1.setStrokeCap(Paint.Cap.SQUARE);
      paint1.setAntiAlias(true);
      paint1.setStyle(Paint.Style.STROKE);
      paint2.setStyle(Paint.Style.FILL);
      paint2.setAntiAlias(true);
      paint3.setColor(0);
    }
    
    public void a(int param1Int) {
      this.j = param1Int;
      this.u = this.i[param1Int];
    }
    
    public void b(boolean param1Boolean) {
      if (this.n != param1Boolean)
        this.n = param1Boolean; 
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Luxury Logo Maker_ Logo Design-dex2jar.jar!\c1\d.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */