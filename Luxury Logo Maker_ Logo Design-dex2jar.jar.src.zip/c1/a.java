package c1;

import android.content.Context;
import android.graphics.drawable.Drawable;
import android.graphics.drawable.ShapeDrawable;
import android.graphics.drawable.shapes.OvalShape;
import android.graphics.drawable.shapes.Shape;
import android.view.animation.Animation;
import android.widget.ImageView;
import java.util.WeakHashMap;
import k0.l;

public class a extends ImageView {
  public Animation.AnimationListener h;
  
  public int i;
  
  public a(Context paramContext, int paramInt) {
    super(paramContext);
    float f = (getContext().getResources().getDisplayMetrics()).density;
    this.i = (int)(3.5F * f);
    ShapeDrawable shapeDrawable = new ShapeDrawable((Shape)new OvalShape());
    WeakHashMap weakHashMap = l.a;
    setElevation(f * 4.0F);
    shapeDrawable.getPaint().setColor(paramInt);
    setBackground((Drawable)shapeDrawable);
  }
  
  public void onAnimationEnd() {
    super.onAnimationEnd();
    Animation.AnimationListener animationListener = this.h;
    if (animationListener != null)
      animationListener.onAnimationEnd(getAnimation()); 
  }
  
  public void onAnimationStart() {
    super.onAnimationStart();
    Animation.AnimationListener animationListener = this.h;
    if (animationListener != null)
      animationListener.onAnimationStart(getAnimation()); 
  }
  
  public void onMeasure(int paramInt1, int paramInt2) {
    super.onMeasure(paramInt1, paramInt2);
  }
  
  public void setBackgroundColor(int paramInt) {
    if (getBackground() instanceof ShapeDrawable)
      ((ShapeDrawable)getBackground()).getPaint().setColor(paramInt); 
  }
}


/* Location:              C:\soft\dex2jar-2.0\Luxury Logo Maker_ Logo Design-dex2jar.jar!\c1\a.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */