package c1;

import android.view.animation.Animation;
import android.view.animation.Transformation;
import androidx.swiperefreshlayout.widget.SwipeRefreshLayout;

public class e extends Animation {
  public e(SwipeRefreshLayout paramSwipeRefreshLayout) {}
  
  public void applyTransformation(float paramFloat, Transformation paramTransformation) {
    this.h.setAnimationProgress(paramFloat);
  }
}


/* Location:              C:\soft\dex2jar-2.0\Luxury Logo Maker_ Logo Design-dex2jar.jar!\c1\e.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */