package c2;

import a2.h;
import android.support.v4.media.c;
import com.bumptech.glide.load.data.e;
import j0.c;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Objects;

public class v<Data, ResourceType, Transcode> {
  public final c<List<Throwable>> a;
  
  public final List<? extends k<Data, ResourceType, Transcode>> b;
  
  public final String c;
  
  public v(Class<Data> paramClass, Class<ResourceType> paramClass1, Class<Transcode> paramClass2, List<k<Data, ResourceType, Transcode>> paramList, c<List<Throwable>> paramc) {
    this.a = paramc;
    if (!paramList.isEmpty()) {
      this.b = paramList;
      StringBuilder stringBuilder = c.a("Failed LoadPath{");
      stringBuilder.append(paramClass.getSimpleName());
      stringBuilder.append("->");
      stringBuilder.append(paramClass1.getSimpleName());
      stringBuilder.append("->");
      stringBuilder.append(paramClass2.getSimpleName());
      stringBuilder.append("}");
      this.c = stringBuilder.toString();
      return;
    } 
    throw new IllegalArgumentException("Must not be empty.");
  }
  
  public x<Transcode> a(e<Data> parame, h paramh, int paramInt1, int paramInt2, k.a<ResourceType> parama) {
    Object object = this.a.b();
    Objects.requireNonNull(object, "Argument must not be null");
    List<s> list = (List)object;
    try {
      Object object1;
      int j = this.b.size();
      object = null;
      int i = 0;
      while (true) {
        object1 = object;
        if (i < j) {
          object1 = this.b.get(i);
          try {
            object1 = object1.a(parame, paramInt1, paramInt2, paramh, parama);
            object = object1;
          } catch (s s) {
            list.add(s);
          } 
          if (object != null) {
            object1 = object;
            break;
          } 
          i++;
          continue;
        } 
        break;
      } 
      if (object1 != null)
        return (x<Transcode>)object1; 
      throw new s(this.c, new ArrayList(list));
    } finally {
      this.a.a(list);
    } 
  }
  
  public String toString() {
    StringBuilder stringBuilder = c.a("LoadPath{decodePaths=");
    stringBuilder.append(Arrays.toString(this.b.toArray()));
    stringBuilder.append('}');
    return stringBuilder.toString();
  }
}


/* Location:              C:\soft\dex2jar-2.0\Luxury Logo Maker_ Logo Design-dex2jar.jar!\c2\v.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */