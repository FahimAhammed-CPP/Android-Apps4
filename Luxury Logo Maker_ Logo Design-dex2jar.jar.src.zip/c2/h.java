package c2;

import a2.d;
import a2.f;
import a2.j;
import a2.l;
import com.bumptech.glide.d;
import com.bumptech.glide.f;
import com.bumptech.glide.g;
import e2.a;
import e4.aw;
import g2.n;
import g2.p;
import i2.b;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.concurrent.atomic.AtomicReference;
import o2.d;
import o2.e;
import q2.c;
import q2.d;
import q2.e;
import r.a;
import v2.k;

public final class h<Transcode> {
  public final List<n.a<?>> a = new ArrayList<n.a<?>>();
  
  public final List<f> b = new ArrayList<f>();
  
  public d c;
  
  public Object d;
  
  public int e;
  
  public int f;
  
  public Class<?> g;
  
  public i.d h;
  
  public a2.h i;
  
  public Map<Class<?>, l<?>> j;
  
  public Class<Transcode> k;
  
  public boolean l;
  
  public boolean m;
  
  public f n;
  
  public f o;
  
  public l p;
  
  public boolean q;
  
  public boolean r;
  
  public List<f> a() {
    if (!this.m) {
      this.m = true;
      this.b.clear();
      List<n.a<?>> list = c();
      int j = list.size();
      for (int i = 0; i < j; i++) {
        n.a a = list.get(i);
        if (!this.b.contains(a.a))
          this.b.add(a.a); 
        for (int k = 0; k < a.b.size(); k++) {
          if (!this.b.contains(a.b.get(k)))
            this.b.add(a.b.get(k)); 
        } 
      } 
    } 
    return this.b;
  }
  
  public a b() {
    return ((m.c)this.h).a();
  }
  
  public List<n.a<?>> c() {
    if (!this.l) {
      this.l = true;
      this.a.clear();
      List<n> list = this.c.a().f(this.d);
      int i = 0;
      int j = list.size();
      while (i < j) {
        n.a<?> a = ((n)list.get(i)).a(this.d, this.e, this.f, this.i);
        if (a != null)
          this.a.add(a); 
        i++;
      } 
    } 
    return this.a;
  }
  
  public <Data> v<Data, ?, Transcode> d(Class<Data> paramClass) {
    g g = this.c.a();
    Class<?> clazz = this.g;
    Class<Transcode> clazz1 = this.k;
    c c = g.i;
    k k2 = c.b.getAndSet(null);
    k k1 = k2;
    if (k2 == null)
      k1 = new k(); 
    k1.a = paramClass;
    k1.b = clazz;
    k1.c = clazz1;
    synchronized (c.a) {
      ArrayList<k<Data, ?, Transcode>> arrayList;
      v v = (v)c.a.getOrDefault(k1, null);
      c.b.set(k1);
      Objects.requireNonNull(g.i);
      if (c.c.equals(v))
        return null; 
      if (v == null) {
        v<Data, Object, Transcode> v1;
        arrayList = new ArrayList();
        for (Class<?> clazz2 : (Iterable<Class<?>>)g.c.b(paramClass, clazz)) {
          for (Class<?> clazz3 : (Iterable<Class<?>>)g.f.a(clazz2, clazz1)) {
            e e;
            d<?, ?> d1;
            synchronized (g.c) {
              ArrayList<j> arrayList1 = new ArrayList();
              for (String str : e.a) {
                List list = (List)e.b.get(str);
                if (list == null)
                  continue; 
                for (e.a a : list) {
                  if (a.a(paramClass, clazz2))
                    arrayList1.add(a.c); 
                } 
              } 
              synchronized (g.f) {
                StringBuilder stringBuilder;
                if (clazz3.isAssignableFrom(clazz2)) {
                  aw aw = aw.s;
                } else {
                  Iterator<e.a> iterator = null.a.iterator();
                  while (iterator.hasNext()) {
                    e.a a = iterator.next();
                    if (a.a(clazz2, clazz3)) {
                      d1 = a.c;
                      continue;
                    } 
                  } 
                  stringBuilder = new StringBuilder();
                  stringBuilder.append("No transcoder registered to transcode from ");
                  stringBuilder.append(clazz2);
                  stringBuilder.append(" to ");
                  stringBuilder.append(clazz3);
                  throw new IllegalArgumentException(stringBuilder.toString());
                } 
                arrayList.add(new k<Object, Object, Object>((Class<?>)stringBuilder, clazz2, clazz3, (List)arrayList1, d1, g.j));
              } 
            } 
          } 
        } 
        if (arrayList.isEmpty()) {
          k1 = null;
        } else {
          v1 = new v<Data, Object, Transcode>(paramClass, clazz, clazz1, arrayList, g.j);
        } 
        c c1 = g.i;
        synchronized (c1.a) {
          v v2;
          a a = c1.a;
          k k = new k(paramClass, clazz, clazz1);
          if (v1 != null) {
            v2 = v1;
          } else {
            v2 = c.c;
          } 
          a.put(k, v2);
          return v1;
        } 
      } 
      return (v)arrayList;
    } 
  }
  
  public List<Class<?>> e() {
    a a;
    List<Class<?>> list;
    g g = this.c.a();
    Class<?> clazz1 = this.d.getClass();
    Class<?> clazz2 = this.g;
    Class<Transcode> clazz = this.k;
    d d1 = g.h;
    null = ((AtomicReference<k>)d1.h).getAndSet(null);
    if (null == null) {
      null = new k(clazz1, clazz2, clazz);
    } else {
      null.a = clazz1;
      null.b = clazz2;
      null.c = clazz;
    } 
    synchronized ((a)d1.i) {
      List list1 = (List)((a)d1.i).getOrDefault(null, null);
      ((AtomicReference<k>)d1.h).set(null);
      if (list1 == null) {
        p p;
        d d2;
        null = new ArrayList();
        synchronized (g.a) {
          list = p.a.d(clazz1);
          for (Class clazz4 : list) {
            for (Class<?> clazz3 : (Iterable<Class<?>>)g.c.b(clazz4, clazz2)) {
              if (!((ArrayList)g.f.a(clazz3, clazz)).isEmpty() && !null.contains(clazz3))
                null.add(clazz3); 
            } 
          } 
          d2 = g.h;
          list = Collections.unmodifiableList(null);
          synchronized ((a)d2.i) {
            ((a)d2.i).put(new k(clazz1, clazz2, clazz), list);
            return null;
          } 
        } 
      } 
      return (List)clazz3;
    } 
  }
  
  public <X> d<X> f(X paramX) {
    // Byte code:
    //   0: aload_0
    //   1: getfield c : Lcom/bumptech/glide/d;
    //   4: invokevirtual a : ()Lcom/bumptech/glide/g;
    //   7: getfield b : Lq2/a;
    //   10: astore_3
    //   11: aload_1
    //   12: invokevirtual getClass : ()Ljava/lang/Class;
    //   15: astore_2
    //   16: aload_3
    //   17: monitorenter
    //   18: aload_3
    //   19: getfield a : Ljava/util/List;
    //   22: invokeinterface iterator : ()Ljava/util/Iterator;
    //   27: astore #4
    //   29: aload #4
    //   31: invokeinterface hasNext : ()Z
    //   36: ifeq -> 72
    //   39: aload #4
    //   41: invokeinterface next : ()Ljava/lang/Object;
    //   46: checkcast q2/a$a
    //   49: astore #5
    //   51: aload #5
    //   53: getfield a : Ljava/lang/Class;
    //   56: aload_2
    //   57: invokevirtual isAssignableFrom : (Ljava/lang/Class;)Z
    //   60: ifeq -> 29
    //   63: aload #5
    //   65: getfield b : La2/d;
    //   68: astore_2
    //   69: goto -> 74
    //   72: aconst_null
    //   73: astore_2
    //   74: aload_3
    //   75: monitorexit
    //   76: aload_2
    //   77: ifnull -> 82
    //   80: aload_2
    //   81: areturn
    //   82: new com/bumptech/glide/g$e
    //   85: dup
    //   86: aload_1
    //   87: invokevirtual getClass : ()Ljava/lang/Class;
    //   90: invokespecial <init> : (Ljava/lang/Class;)V
    //   93: athrow
    //   94: astore_1
    //   95: aload_3
    //   96: monitorexit
    //   97: aload_1
    //   98: athrow
    // Exception table:
    //   from	to	target	type
    //   18	29	94	finally
    //   29	69	94	finally
  }
  
  public <Z> l<Z> g(Class<Z> paramClass) {
    StringBuilder stringBuilder;
    l l2 = this.j.get(paramClass);
    l l1 = l2;
    if (l2 == null) {
      Iterator<Map.Entry> iterator = this.j.entrySet().iterator();
      while (true) {
        l1 = l2;
        if (iterator.hasNext()) {
          Map.Entry entry = iterator.next();
          if (((Class)entry.getKey()).isAssignableFrom(paramClass)) {
            l1 = (l)entry.getValue();
            break;
          } 
          continue;
        } 
        break;
      } 
    } 
    if (l1 == null) {
      if (!this.j.isEmpty() || !this.q)
        return b.b; 
      stringBuilder = new StringBuilder();
      stringBuilder.append("Missing transformation for ");
      stringBuilder.append(paramClass);
      stringBuilder.append(". If you wish to ignore unknown resource types, use the optional transformation methods.");
      throw new IllegalArgumentException(stringBuilder.toString());
    } 
    return (l<Z>)stringBuilder;
  }
  
  public boolean h(Class<?> paramClass) {
    return (d(paramClass) != null);
  }
}


/* Location:              C:\soft\dex2jar-2.0\Luxury Logo Maker_ Logo Design-dex2jar.jar!\c2\h.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */