package c2;

import a2.f;
import java.util.Objects;

public class r<Z> implements x<Z> {
  public final boolean h;
  
  public final boolean i;
  
  public final x<Z> j;
  
  public final a k;
  
  public final f l;
  
  public int m;
  
  public boolean n;
  
  public r(x<Z> paramx, boolean paramBoolean1, boolean paramBoolean2, f paramf, a parama) {
    Objects.requireNonNull(paramx, "Argument must not be null");
    this.j = paramx;
    this.h = paramBoolean1;
    this.i = paramBoolean2;
    this.l = paramf;
    Objects.requireNonNull(parama, "Argument must not be null");
    this.k = parama;
  }
  
  public void a() {
    // Byte code:
    //   0: aload_0
    //   1: monitorenter
    //   2: aload_0
    //   3: getfield n : Z
    //   6: ifne -> 22
    //   9: aload_0
    //   10: aload_0
    //   11: getfield m : I
    //   14: iconst_1
    //   15: iadd
    //   16: putfield m : I
    //   19: aload_0
    //   20: monitorexit
    //   21: return
    //   22: new java/lang/IllegalStateException
    //   25: dup
    //   26: ldc 'Cannot acquire a recycled resource'
    //   28: invokespecial <init> : (Ljava/lang/String;)V
    //   31: athrow
    //   32: astore_1
    //   33: aload_0
    //   34: monitorexit
    //   35: aload_1
    //   36: athrow
    // Exception table:
    //   from	to	target	type
    //   2	19	32	finally
    //   22	32	32	finally
  }
  
  public int b() {
    return this.j.b();
  }
  
  public Class<Z> c() {
    return this.j.c();
  }
  
  public void d() {
    // Byte code:
    //   0: aload_0
    //   1: monitorenter
    //   2: aload_0
    //   3: getfield m : I
    //   6: ifgt -> 50
    //   9: aload_0
    //   10: getfield n : Z
    //   13: ifne -> 40
    //   16: aload_0
    //   17: iconst_1
    //   18: putfield n : Z
    //   21: aload_0
    //   22: getfield i : Z
    //   25: ifeq -> 37
    //   28: aload_0
    //   29: getfield j : Lc2/x;
    //   32: invokeinterface d : ()V
    //   37: aload_0
    //   38: monitorexit
    //   39: return
    //   40: new java/lang/IllegalStateException
    //   43: dup
    //   44: ldc 'Cannot recycle a resource that has already been recycled'
    //   46: invokespecial <init> : (Ljava/lang/String;)V
    //   49: athrow
    //   50: new java/lang/IllegalStateException
    //   53: dup
    //   54: ldc 'Cannot recycle a resource while it is still acquired'
    //   56: invokespecial <init> : (Ljava/lang/String;)V
    //   59: athrow
    //   60: astore_1
    //   61: aload_0
    //   62: monitorexit
    //   63: aload_1
    //   64: athrow
    // Exception table:
    //   from	to	target	type
    //   2	37	60	finally
    //   40	50	60	finally
    //   50	60	60	finally
  }
  
  public void e() {
    // Byte code:
    //   0: aload_0
    //   1: monitorenter
    //   2: aload_0
    //   3: getfield m : I
    //   6: istore_2
    //   7: iload_2
    //   8: ifle -> 50
    //   11: iconst_1
    //   12: istore_1
    //   13: iload_2
    //   14: iconst_1
    //   15: isub
    //   16: istore_2
    //   17: aload_0
    //   18: iload_2
    //   19: putfield m : I
    //   22: iload_2
    //   23: ifne -> 65
    //   26: goto -> 29
    //   29: aload_0
    //   30: monitorexit
    //   31: iload_1
    //   32: ifeq -> 49
    //   35: aload_0
    //   36: getfield k : Lc2/r$a;
    //   39: aload_0
    //   40: getfield l : La2/f;
    //   43: aload_0
    //   44: invokeinterface a : (La2/f;Lc2/r;)V
    //   49: return
    //   50: new java/lang/IllegalStateException
    //   53: dup
    //   54: ldc 'Cannot release a recycled or not yet acquired resource'
    //   56: invokespecial <init> : (Ljava/lang/String;)V
    //   59: athrow
    //   60: astore_3
    //   61: aload_0
    //   62: monitorexit
    //   63: aload_3
    //   64: athrow
    //   65: iconst_0
    //   66: istore_1
    //   67: goto -> 29
    // Exception table:
    //   from	to	target	type
    //   2	7	60	finally
    //   17	22	60	finally
    //   29	31	60	finally
    //   50	60	60	finally
    //   61	63	60	finally
  }
  
  public Z get() {
    return this.j.get();
  }
  
  public String toString() {
    // Byte code:
    //   0: aload_0
    //   1: monitorenter
    //   2: new java/lang/StringBuilder
    //   5: dup
    //   6: invokespecial <init> : ()V
    //   9: astore_1
    //   10: aload_1
    //   11: ldc 'EngineResource{isMemoryCacheable='
    //   13: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   16: pop
    //   17: aload_1
    //   18: aload_0
    //   19: getfield h : Z
    //   22: invokevirtual append : (Z)Ljava/lang/StringBuilder;
    //   25: pop
    //   26: aload_1
    //   27: ldc ', listener='
    //   29: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   32: pop
    //   33: aload_1
    //   34: aload_0
    //   35: getfield k : Lc2/r$a;
    //   38: invokevirtual append : (Ljava/lang/Object;)Ljava/lang/StringBuilder;
    //   41: pop
    //   42: aload_1
    //   43: ldc ', key='
    //   45: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   48: pop
    //   49: aload_1
    //   50: aload_0
    //   51: getfield l : La2/f;
    //   54: invokevirtual append : (Ljava/lang/Object;)Ljava/lang/StringBuilder;
    //   57: pop
    //   58: aload_1
    //   59: ldc ', acquired='
    //   61: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   64: pop
    //   65: aload_1
    //   66: aload_0
    //   67: getfield m : I
    //   70: invokevirtual append : (I)Ljava/lang/StringBuilder;
    //   73: pop
    //   74: aload_1
    //   75: ldc ', isRecycled='
    //   77: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   80: pop
    //   81: aload_1
    //   82: aload_0
    //   83: getfield n : Z
    //   86: invokevirtual append : (Z)Ljava/lang/StringBuilder;
    //   89: pop
    //   90: aload_1
    //   91: ldc ', resource='
    //   93: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   96: pop
    //   97: aload_1
    //   98: aload_0
    //   99: getfield j : Lc2/x;
    //   102: invokevirtual append : (Ljava/lang/Object;)Ljava/lang/StringBuilder;
    //   105: pop
    //   106: aload_1
    //   107: bipush #125
    //   109: invokevirtual append : (C)Ljava/lang/StringBuilder;
    //   112: pop
    //   113: aload_1
    //   114: invokevirtual toString : ()Ljava/lang/String;
    //   117: astore_1
    //   118: aload_0
    //   119: monitorexit
    //   120: aload_1
    //   121: areturn
    //   122: astore_1
    //   123: aload_0
    //   124: monitorexit
    //   125: aload_1
    //   126: athrow
    // Exception table:
    //   from	to	target	type
    //   2	118	122	finally
  }
  
  public static interface a {
    void a(f param1f, r<?> param1r);
  }
}


/* Location:              C:\soft\dex2jar-2.0\Luxury Logo Maker_ Logo Design-dex2jar.jar!\c2\r.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */