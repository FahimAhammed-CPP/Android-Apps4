package c2;

import a2.c;
import a2.f;
import a2.h;
import a2.j;
import a2.l;
import android.content.Context;
import android.support.v4.media.c;
import android.util.Log;
import com.bumptech.glide.g;
import com.bumptech.glide.load.data.e;
import g2.n;
import j0.c;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.Objects;
import o2.d;

public class k<DataType, ResourceType, Transcode> {
  public final Class<DataType> a;
  
  public final List<? extends j<DataType, ResourceType>> b;
  
  public final d<ResourceType, Transcode> c;
  
  public final c<List<Throwable>> d;
  
  public final String e;
  
  public k(Class<DataType> paramClass, Class<ResourceType> paramClass1, Class<Transcode> paramClass2, List<? extends j<DataType, ResourceType>> paramList, d<ResourceType, Transcode> paramd, c<List<Throwable>> paramc) {
    this.a = paramClass;
    this.b = paramList;
    this.c = paramd;
    this.d = paramc;
    StringBuilder stringBuilder = c.a("Failed DecodePath{");
    stringBuilder.append(paramClass.getSimpleName());
    stringBuilder.append("->");
    stringBuilder.append(paramClass1.getSimpleName());
    stringBuilder.append("->");
    stringBuilder.append(paramClass2.getSimpleName());
    stringBuilder.append("}");
    this.e = stringBuilder.toString();
  }
  
  public x<Transcode> a(e<DataType> parame, int paramInt1, int paramInt2, h paramh, a<ResourceType> parama) {
    c c1;
    Object<ResourceType> object = (Object<ResourceType>)this.d.b();
    Objects.requireNonNull(object, "Argument must not be null");
    List<Throwable> list = (List)object;
    try {
      Object<ResourceType> object1;
      object = (Object<ResourceType>)b(parame, paramInt1, paramInt2, paramh, list);
      this.d.a(list);
      i.b b = (i.b)parama;
      i i1 = b.b;
      a2.a a2 = b.a;
      Objects.requireNonNull(i1);
      Class<?> clazz = object.get().getClass();
      a2.a a1 = a2.a.k;
      a2.k k2 = null;
      if (a2 != a1) {
        l l = i1.h.g(clazz);
        x x = l.b((Context)i1.o, (x)object, i1.s, i1.t);
      } else {
        object1 = object;
        parama = null;
      } 
      if (!object.equals(object1))
        object.d(); 
      a2.k k1 = (i1.h.c.a()).d.a(object1.c());
      boolean bool = false;
      if (k1 != null) {
        paramInt1 = 1;
      } else {
        paramInt1 = 0;
      } 
      if (paramInt1 != 0) {
        k1 = (i1.h.c.a()).d.a(object1.c());
        if (k1 != null) {
          c1 = k1.c(i1.v);
        } else {
          throw new g.d(object1.c());
        } 
      } else {
        c1 = c.j;
        k1 = k2;
      } 
      h h1 = i1.h;
      f f = i1.E;
      List<n.a<?>> list1 = h1.c();
      int i = list1.size();
      paramInt1 = 0;
      while (true) {
        paramInt2 = bool;
        if (paramInt1 < i) {
          if (((n.a)list1.get(paramInt1)).a.equals(f)) {
            paramInt2 = 1;
            break;
          } 
          paramInt1++;
          continue;
        } 
        break;
      } 
      Object<ResourceType> object2 = object1;
      return this.c.a((x)object2, paramh);
    } finally {
      this.d.a(c1);
    } 
  }
  
  public final x<ResourceType> b(e<DataType> parame, int paramInt1, int paramInt2, h paramh, List<Throwable> paramList) {
    int j = this.b.size();
    x x = null;
    int i = 0;
    while (true) {
      x x1 = x;
      if (i < j) {
        j j1 = this.b.get(i);
        x1 = x;
        try {
          if (j1.b(parame.a(), paramh))
            x1 = j1.a(parame.a(), paramInt1, paramInt2, paramh); 
        } catch (IOException iOException) {
          if (Log.isLoggable("DecodePath", 2)) {
            StringBuilder stringBuilder = new StringBuilder();
            stringBuilder.append("Failed to decode data for ");
            stringBuilder.append(j1);
            Log.v("DecodePath", stringBuilder.toString(), iOException);
          } 
          paramList.add(iOException);
          x x2 = x;
        } catch (RuntimeException runtimeException) {
        
        } catch (OutOfMemoryError outOfMemoryError) {}
        if (outOfMemoryError != null)
          break; 
        i++;
        OutOfMemoryError outOfMemoryError1 = outOfMemoryError;
        continue;
      } 
      break;
    } 
    if (outOfMemoryError != null)
      return (x<ResourceType>)outOfMemoryError; 
    throw new s(this.e, new ArrayList(paramList));
  }
  
  public String toString() {
    StringBuilder stringBuilder = c.a("DecodePath{ dataClass=");
    stringBuilder.append(this.a);
    stringBuilder.append(", decoders=");
    stringBuilder.append(this.b);
    stringBuilder.append(", transcoder=");
    stringBuilder.append(this.c);
    stringBuilder.append('}');
    return stringBuilder.toString();
  }
  
  public static interface a<ResourceType> {}
}


/* Location:              C:\soft\dex2jar-2.0\Luxury Logo Maker_ Logo Design-dex2jar.jar!\c2\k.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */