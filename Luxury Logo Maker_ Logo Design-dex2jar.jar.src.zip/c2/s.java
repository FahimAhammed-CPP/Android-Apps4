package c2;

import a2.f;
import android.support.v4.media.c;
import android.util.Log;
import java.io.IOException;
import java.io.PrintStream;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

public final class s extends Exception {
  public static final StackTraceElement[] m = new StackTraceElement[0];
  
  public final List<Throwable> h;
  
  public f i;
  
  public a2.a j;
  
  public Class<?> k;
  
  public String l;
  
  public s(String paramString) {
    this.l = paramString;
    setStackTrace(m);
    this.h = (List)list;
  }
  
  public s(String paramString, Throwable paramThrowable) {
    this.l = paramString;
    setStackTrace(m);
    this.h = list;
  }
  
  public s(String paramString, List<Throwable> paramList) {
    this.l = paramString;
    setStackTrace(m);
    this.h = paramList;
  }
  
  public static void b(List<Throwable> paramList, Appendable paramAppendable) {
    try {
      c(paramList, paramAppendable);
      return;
    } catch (IOException iOException) {
      throw new RuntimeException(iOException);
    } 
  }
  
  public static void c(List<Throwable> paramList, Appendable paramAppendable) {
    int j = paramList.size();
    for (int i = 0; i < j; i = k) {
      Appendable appendable = paramAppendable.append("Cause (");
      int k = i + 1;
      appendable.append(String.valueOf(k)).append(" of ").append(String.valueOf(j)).append("): ");
      Throwable throwable = paramList.get(i);
      if (throwable instanceof s) {
        ((s)throwable).f(paramAppendable);
      } else {
        d(throwable, paramAppendable);
      } 
    } 
  }
  
  public static void d(Throwable paramThrowable, Appendable paramAppendable) {
    try {
      paramAppendable.append(paramThrowable.getClass().toString()).append(": ").append(paramThrowable.getMessage()).append('\n');
      return;
    } catch (IOException iOException) {
      throw new RuntimeException(paramThrowable);
    } 
  }
  
  public final void a(Throwable paramThrowable, List<Throwable> paramList) {
    Iterator<Throwable> iterator;
    if (paramThrowable instanceof s) {
      iterator = ((s)paramThrowable).h.iterator();
      while (iterator.hasNext())
        a(iterator.next(), paramList); 
    } else {
      paramList.add(iterator);
    } 
  }
  
  public void e(String paramString) {
    ArrayList<Throwable> arrayList = new ArrayList();
    a(this, arrayList);
    int j = arrayList.size();
    for (int i = 0; i < j; i = k) {
      StringBuilder stringBuilder = c.a("Root cause (");
      int k = i + 1;
      stringBuilder.append(k);
      stringBuilder.append(" of ");
      stringBuilder.append(j);
      stringBuilder.append(")");
      Log.i(paramString, stringBuilder.toString(), arrayList.get(i));
    } 
  }
  
  public final void f(Appendable paramAppendable) {
    d(this, paramAppendable);
    b(this.h, new a(paramAppendable));
  }
  
  public Throwable fillInStackTrace() {
    return this;
  }
  
  public String getMessage() {
    StringBuilder stringBuilder = new StringBuilder(71);
    stringBuilder.append(this.l);
    Class<?> clazz = this.k;
    String str2 = "";
    if (clazz != null) {
      StringBuilder stringBuilder1 = c.a(", ");
      stringBuilder1.append(this.k);
      str1 = stringBuilder1.toString();
    } else {
      str1 = "";
    } 
    stringBuilder.append(str1);
    if (this.j != null) {
      StringBuilder stringBuilder1 = c.a(", ");
      stringBuilder1.append(this.j);
      String str = stringBuilder1.toString();
    } else {
      str1 = "";
    } 
    stringBuilder.append(str1);
    String str1 = str2;
    if (this.i != null) {
      StringBuilder stringBuilder1 = c.a(", ");
      stringBuilder1.append(this.i);
      str1 = stringBuilder1.toString();
    } 
    stringBuilder.append(str1);
    ArrayList<Throwable> arrayList = new ArrayList();
    a(this, arrayList);
    if (arrayList.isEmpty())
      return stringBuilder.toString(); 
    if (arrayList.size() == 1) {
      str1 = "\nThere was 1 root cause:";
    } else {
      stringBuilder.append("\nThere were ");
      stringBuilder.append(arrayList.size());
      str1 = " root causes:";
    } 
    stringBuilder.append(str1);
    for (Throwable throwable : arrayList) {
      stringBuilder.append('\n');
      stringBuilder.append(throwable.getClass().getName());
      stringBuilder.append('(');
      stringBuilder.append(throwable.getMessage());
      stringBuilder.append(')');
    } 
    stringBuilder.append("\n call GlideException#logRootCauses(String) for more detail");
    return stringBuilder.toString();
  }
  
  public void printStackTrace() {
    f(System.err);
  }
  
  public void printStackTrace(PrintStream paramPrintStream) {
    f(paramPrintStream);
  }
  
  public void printStackTrace(PrintWriter paramPrintWriter) {
    f(paramPrintWriter);
  }
  
  public static final class a implements Appendable {
    public final Appendable h;
    
    public boolean i = true;
    
    public a(Appendable param1Appendable) {
      this.h = param1Appendable;
    }
    
    public Appendable append(char param1Char) {
      boolean bool1 = this.i;
      boolean bool = false;
      if (bool1) {
        this.i = false;
        this.h.append("  ");
      } 
      if (param1Char == '\n')
        bool = true; 
      this.i = bool;
      this.h.append(param1Char);
      return this;
    }
    
    public Appendable append(CharSequence param1CharSequence) {
      CharSequence charSequence = param1CharSequence;
      if (param1CharSequence == null)
        charSequence = ""; 
      append(charSequence, 0, charSequence.length());
      return this;
    }
    
    public Appendable append(CharSequence param1CharSequence, int param1Int1, int param1Int2) {
      CharSequence charSequence = param1CharSequence;
      if (param1CharSequence == null)
        charSequence = ""; 
      boolean bool = this.i;
      boolean bool1 = false;
      if (bool) {
        this.i = false;
        this.h.append("  ");
      } 
      bool = bool1;
      if (charSequence.length() > 0) {
        bool = bool1;
        if (charSequence.charAt(param1Int2 - 1) == '\n')
          bool = true; 
      } 
      this.i = bool;
      this.h.append(charSequence, param1Int1, param1Int2);
      return this;
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Luxury Logo Maker_ Logo Design-dex2jar.jar!\c2\s.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */