package c2;

import a2.f;
import android.os.Process;
import java.lang.ref.ReferenceQueue;
import java.lang.ref.WeakReference;
import java.util.HashMap;
import java.util.Map;
import java.util.Objects;
import java.util.concurrent.Executor;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.ThreadFactory;

public final class a {
  public final boolean a;
  
  public final Executor b;
  
  public final Map<f, b> c = new HashMap<f, b>();
  
  public final ReferenceQueue<r<?>> d = new ReferenceQueue<r<?>>();
  
  public r.a e;
  
  public a(boolean paramBoolean) {
    this.a = paramBoolean;
    this.b = executorService;
    executorService.execute(new b(this));
  }
  
  public void a(f paramf, r<?> paramr) {
    // Byte code:
    //   0: aload_0
    //   1: monitorenter
    //   2: new c2/a$b
    //   5: dup
    //   6: aload_1
    //   7: aload_2
    //   8: aload_0
    //   9: getfield d : Ljava/lang/ref/ReferenceQueue;
    //   12: aload_0
    //   13: getfield a : Z
    //   16: invokespecial <init> : (La2/f;Lc2/r;Ljava/lang/ref/ReferenceQueue;Z)V
    //   19: astore_2
    //   20: aload_0
    //   21: getfield c : Ljava/util/Map;
    //   24: aload_1
    //   25: aload_2
    //   26: invokeinterface put : (Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    //   31: checkcast c2/a$b
    //   34: astore_1
    //   35: aload_1
    //   36: ifnull -> 48
    //   39: aload_1
    //   40: aconst_null
    //   41: putfield c : Lc2/x;
    //   44: aload_1
    //   45: invokevirtual clear : ()V
    //   48: aload_0
    //   49: monitorexit
    //   50: return
    //   51: astore_1
    //   52: aload_0
    //   53: monitorexit
    //   54: aload_1
    //   55: athrow
    // Exception table:
    //   from	to	target	type
    //   2	35	51	finally
    //   39	48	51	finally
  }
  
  public void b(b paramb) {
    // Byte code:
    //   0: aload_0
    //   1: monitorenter
    //   2: aload_0
    //   3: getfield c : Ljava/util/Map;
    //   6: aload_1
    //   7: getfield a : La2/f;
    //   10: invokeinterface remove : (Ljava/lang/Object;)Ljava/lang/Object;
    //   15: pop
    //   16: aload_1
    //   17: getfield b : Z
    //   20: ifeq -> 71
    //   23: aload_1
    //   24: getfield c : Lc2/x;
    //   27: astore_2
    //   28: aload_2
    //   29: ifnonnull -> 35
    //   32: goto -> 71
    //   35: aload_0
    //   36: monitorexit
    //   37: new c2/r
    //   40: dup
    //   41: aload_2
    //   42: iconst_1
    //   43: iconst_0
    //   44: aload_1
    //   45: getfield a : La2/f;
    //   48: aload_0
    //   49: getfield e : Lc2/r$a;
    //   52: invokespecial <init> : (Lc2/x;ZZLa2/f;Lc2/r$a;)V
    //   55: astore_2
    //   56: aload_0
    //   57: getfield e : Lc2/r$a;
    //   60: aload_1
    //   61: getfield a : La2/f;
    //   64: aload_2
    //   65: invokeinterface a : (La2/f;Lc2/r;)V
    //   70: return
    //   71: aload_0
    //   72: monitorexit
    //   73: return
    //   74: astore_1
    //   75: aload_0
    //   76: monitorexit
    //   77: aload_1
    //   78: athrow
    // Exception table:
    //   from	to	target	type
    //   2	28	74	finally
    //   35	37	74	finally
    //   71	73	74	finally
    //   75	77	74	finally
  }
  
  public class a implements ThreadFactory {
    public Thread newThread(Runnable param1Runnable) {
      return new Thread(new a(this, param1Runnable), "glide-active-resources");
    }
    
    public class a implements Runnable {
      public a(a.a this$0, Runnable param2Runnable) {}
      
      public void run() {
        Process.setThreadPriority(10);
        this.h.run();
      }
    }
  }
  
  public class a implements Runnable {
    public a(a this$0, Runnable param1Runnable) {}
    
    public void run() {
      Process.setThreadPriority(10);
      this.h.run();
    }
  }
  
  public static final class b extends WeakReference<r<?>> {
    public final f a;
    
    public final boolean b;
    
    public x<?> c;
    
    public b(f param1f, r<?> param1r, ReferenceQueue<? super r<?>> param1ReferenceQueue, boolean param1Boolean) {
      super(param1r, param1ReferenceQueue);
      Objects.requireNonNull(param1f, "Argument must not be null");
      this.a = param1f;
      if (param1r.h && param1Boolean) {
        x<?> x1 = param1r.j;
        Objects.requireNonNull(x1, "Argument must not be null");
      } else {
        param1f = null;
      } 
      this.c = (x<?>)param1f;
      this.b = param1r.h;
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Luxury Logo Maker_ Logo Design-dex2jar.jar!\c2\a.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */