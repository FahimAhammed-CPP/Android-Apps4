package c2;

import a2.f;
import com.bumptech.glide.load.data.d;
import g2.n;

public class b0 implements d.a<Object> {
  public b0(c0 paramc0, n.a parama) {}
  
  public void c(Exception paramException) {
    boolean bool;
    c0 c01 = this.i;
    n.a<?> a1 = this.h;
    n.a<?> a2 = c01.m;
    if (a2 != null && a2 == a1) {
      bool = true;
    } else {
      bool = false;
    } 
    if (bool) {
      c0 c02 = this.i;
      a2 = this.h;
      g.a a3 = c02.i;
      e e = c02.n;
      d<?> d = a2.c;
      a3.d(e, paramException, d, d.e());
    } 
  }
  
  public void d(Object paramObject) {
    boolean bool;
    c0 c01 = this.i;
    n.a<?> a1 = this.h;
    n.a<?> a2 = c01.m;
    if (a2 != null && a2 == a1) {
      bool = true;
    } else {
      bool = false;
    } 
    if (bool) {
      c0 c02 = this.i;
      a2 = this.h;
      l l = c02.h.p;
      if (paramObject != null && l.c(a2.c.e())) {
        c02.l = paramObject;
        c02.i.a();
        return;
      } 
      g.a a3 = c02.i;
      f f = a2.a;
      d<?> d = a2.c;
      a3.e(f, paramObject, d, d.e(), c02.n);
    } 
  }
}


/* Location:              C:\soft\dex2jar-2.0\Luxury Logo Maker_ Logo Design-dex2jar.jar!\c2\b0.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */