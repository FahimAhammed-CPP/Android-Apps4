package c2;

import a2.f;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.concurrent.Executor;
import java.util.concurrent.atomic.AtomicInteger;
import r2.h;
import r2.i;
import w2.a;

public class n<R> implements i.a<R>, a.d {
  public static final c G = new c();
  
  public s A;
  
  public boolean B;
  
  public r<?> C;
  
  public i<R> D;
  
  public volatile boolean E;
  
  public boolean F;
  
  public final e h = new e();
  
  public final w2.d i = (w2.d)new w2.d.b();
  
  public final r.a j;
  
  public final j0.c<n<?>> k;
  
  public final c l;
  
  public final o m;
  
  public final f2.a n;
  
  public final f2.a o;
  
  public final f2.a p;
  
  public final f2.a q;
  
  public final AtomicInteger r = new AtomicInteger();
  
  public f s;
  
  public boolean t;
  
  public boolean u;
  
  public boolean v;
  
  public boolean w;
  
  public x<?> x;
  
  public a2.a y;
  
  public boolean z;
  
  public n(f2.a parama1, f2.a parama2, f2.a parama3, f2.a parama4, o paramo, r.a parama, j0.c<n<?>> paramc) {
    this.n = parama1;
    this.o = parama2;
    this.p = parama3;
    this.q = parama4;
    this.m = paramo;
    this.j = parama;
    this.k = paramc;
    this.l = c1;
  }
  
  public void a(h paramh, Executor paramExecutor) {
    // Byte code:
    //   0: aload_0
    //   1: monitorenter
    //   2: aload_0
    //   3: getfield i : Lw2/d;
    //   6: invokevirtual a : ()V
    //   9: aload_0
    //   10: getfield h : Lc2/n$e;
    //   13: getfield h : Ljava/util/List;
    //   16: new c2/n$d
    //   19: dup
    //   20: aload_1
    //   21: aload_2
    //   22: invokespecial <init> : (Lr2/h;Ljava/util/concurrent/Executor;)V
    //   25: invokeinterface add : (Ljava/lang/Object;)Z
    //   30: pop
    //   31: aload_0
    //   32: getfield z : Z
    //   35: istore #4
    //   37: iconst_1
    //   38: istore_3
    //   39: iload #4
    //   41: ifeq -> 62
    //   44: aload_0
    //   45: iconst_1
    //   46: invokevirtual d : (I)V
    //   49: new c2/n$b
    //   52: dup
    //   53: aload_0
    //   54: aload_1
    //   55: invokespecial <init> : (Lc2/n;Lr2/h;)V
    //   58: astore_1
    //   59: goto -> 84
    //   62: aload_0
    //   63: getfield B : Z
    //   66: ifeq -> 94
    //   69: aload_0
    //   70: iconst_1
    //   71: invokevirtual d : (I)V
    //   74: new c2/n$a
    //   77: dup
    //   78: aload_0
    //   79: aload_1
    //   80: invokespecial <init> : (Lc2/n;Lr2/h;)V
    //   83: astore_1
    //   84: aload_2
    //   85: aload_1
    //   86: invokeinterface execute : (Ljava/lang/Runnable;)V
    //   91: goto -> 110
    //   94: aload_0
    //   95: getfield E : Z
    //   98: ifne -> 118
    //   101: goto -> 104
    //   104: iload_3
    //   105: ldc 'Cannot add callbacks to a cancelled EngineJob'
    //   107: invokestatic a : (ZLjava/lang/String;)V
    //   110: aload_0
    //   111: monitorexit
    //   112: return
    //   113: astore_1
    //   114: aload_0
    //   115: monitorexit
    //   116: aload_1
    //   117: athrow
    //   118: iconst_0
    //   119: istore_3
    //   120: goto -> 104
    // Exception table:
    //   from	to	target	type
    //   2	37	113	finally
    //   44	59	113	finally
    //   62	84	113	finally
    //   84	91	113	finally
    //   94	101	113	finally
    //   104	110	113	finally
  }
  
  public void b() {
    if (e())
      return; 
    this.E = true;
    i<R> i1 = this.D;
    i1.L = true;
    g g = i1.J;
    if (g != null)
      g.cancel(); 
    null = this.m;
    null = this.s;
    synchronized ((m)null) {
      u u = ((m)null).a;
      Objects.requireNonNull(u);
      Map map = u.a(this.w);
      if (equals(map.get(null)))
        map.remove(null); 
      return;
    } 
  }
  
  public void c() {
    // Byte code:
    //   0: aload_0
    //   1: monitorenter
    //   2: aload_0
    //   3: getfield i : Lw2/d;
    //   6: invokevirtual a : ()V
    //   9: aload_0
    //   10: invokevirtual e : ()Z
    //   13: ldc 'Not yet complete!'
    //   15: invokestatic a : (ZLjava/lang/String;)V
    //   18: aload_0
    //   19: getfield r : Ljava/util/concurrent/atomic/AtomicInteger;
    //   22: invokevirtual decrementAndGet : ()I
    //   25: istore_1
    //   26: iload_1
    //   27: iflt -> 73
    //   30: iconst_1
    //   31: istore_2
    //   32: goto -> 35
    //   35: iload_2
    //   36: ldc 'Can't decrement below 0'
    //   38: invokestatic a : (ZLjava/lang/String;)V
    //   41: iload_1
    //   42: ifne -> 78
    //   45: aload_0
    //   46: getfield C : Lc2/r;
    //   49: astore_3
    //   50: aload_0
    //   51: invokevirtual g : ()V
    //   54: goto -> 57
    //   57: aload_0
    //   58: monitorexit
    //   59: aload_3
    //   60: ifnull -> 67
    //   63: aload_3
    //   64: invokevirtual e : ()V
    //   67: return
    //   68: astore_3
    //   69: aload_0
    //   70: monitorexit
    //   71: aload_3
    //   72: athrow
    //   73: iconst_0
    //   74: istore_2
    //   75: goto -> 35
    //   78: aconst_null
    //   79: astore_3
    //   80: goto -> 57
    // Exception table:
    //   from	to	target	type
    //   2	26	68	finally
    //   35	41	68	finally
    //   45	54	68	finally
    //   57	59	68	finally
    //   69	71	68	finally
  }
  
  public void d(int paramInt) {
    // Byte code:
    //   0: aload_0
    //   1: monitorenter
    //   2: aload_0
    //   3: invokevirtual e : ()Z
    //   6: ldc 'Not yet complete!'
    //   8: invokestatic a : (ZLjava/lang/String;)V
    //   11: aload_0
    //   12: getfield r : Ljava/util/concurrent/atomic/AtomicInteger;
    //   15: iload_1
    //   16: invokevirtual getAndAdd : (I)I
    //   19: ifne -> 35
    //   22: aload_0
    //   23: getfield C : Lc2/r;
    //   26: astore_2
    //   27: aload_2
    //   28: ifnull -> 35
    //   31: aload_2
    //   32: invokevirtual a : ()V
    //   35: aload_0
    //   36: monitorexit
    //   37: return
    //   38: astore_2
    //   39: aload_0
    //   40: monitorexit
    //   41: aload_2
    //   42: athrow
    // Exception table:
    //   from	to	target	type
    //   2	27	38	finally
    //   31	35	38	finally
  }
  
  public final boolean e() {
    return (this.B || this.z || this.E);
  }
  
  public w2.d f() {
    return this.i;
  }
  
  public final void g() {
    // Byte code:
    //   0: aload_0
    //   1: monitorenter
    //   2: aload_0
    //   3: getfield s : La2/f;
    //   6: ifnull -> 123
    //   9: aload_0
    //   10: getfield h : Lc2/n$e;
    //   13: getfield h : Ljava/util/List;
    //   16: invokeinterface clear : ()V
    //   21: aload_0
    //   22: aconst_null
    //   23: putfield s : La2/f;
    //   26: aload_0
    //   27: aconst_null
    //   28: putfield C : Lc2/r;
    //   31: aload_0
    //   32: aconst_null
    //   33: putfield x : Lc2/x;
    //   36: aload_0
    //   37: iconst_0
    //   38: putfield B : Z
    //   41: aload_0
    //   42: iconst_0
    //   43: putfield E : Z
    //   46: aload_0
    //   47: iconst_0
    //   48: putfield z : Z
    //   51: aload_0
    //   52: iconst_0
    //   53: putfield F : Z
    //   56: aload_0
    //   57: getfield D : Lc2/i;
    //   60: astore_3
    //   61: aload_3
    //   62: getfield n : Lc2/i$e;
    //   65: astore_2
    //   66: aload_2
    //   67: monitorenter
    //   68: aload_2
    //   69: iconst_1
    //   70: putfield a : Z
    //   73: aload_2
    //   74: iconst_0
    //   75: invokevirtual a : (Z)Z
    //   78: istore_1
    //   79: aload_2
    //   80: monitorexit
    //   81: iload_1
    //   82: ifeq -> 89
    //   85: aload_3
    //   86: invokevirtual o : ()V
    //   89: aload_0
    //   90: aconst_null
    //   91: putfield D : Lc2/i;
    //   94: aload_0
    //   95: aconst_null
    //   96: putfield A : Lc2/s;
    //   99: aload_0
    //   100: aconst_null
    //   101: putfield y : La2/a;
    //   104: aload_0
    //   105: getfield k : Lj0/c;
    //   108: aload_0
    //   109: invokeinterface a : (Ljava/lang/Object;)Z
    //   114: pop
    //   115: aload_0
    //   116: monitorexit
    //   117: return
    //   118: astore_3
    //   119: aload_2
    //   120: monitorexit
    //   121: aload_3
    //   122: athrow
    //   123: new java/lang/IllegalArgumentException
    //   126: dup
    //   127: invokespecial <init> : ()V
    //   130: athrow
    //   131: astore_2
    //   132: aload_0
    //   133: monitorexit
    //   134: aload_2
    //   135: athrow
    // Exception table:
    //   from	to	target	type
    //   2	68	131	finally
    //   68	79	118	finally
    //   79	81	131	finally
    //   85	89	131	finally
    //   89	115	131	finally
    //   119	123	131	finally
    //   123	131	131	finally
  }
  
  public void h(h paramh) {
    // Byte code:
    //   0: aload_0
    //   1: monitorenter
    //   2: aload_0
    //   3: getfield i : Lw2/d;
    //   6: invokevirtual a : ()V
    //   9: aload_0
    //   10: getfield h : Lc2/n$e;
    //   13: getfield h : Ljava/util/List;
    //   16: new c2/n$d
    //   19: dup
    //   20: aload_1
    //   21: getstatic v2/e.b : Ljava/util/concurrent/Executor;
    //   24: invokespecial <init> : (Lr2/h;Ljava/util/concurrent/Executor;)V
    //   27: invokeinterface remove : (Ljava/lang/Object;)Z
    //   32: pop
    //   33: aload_0
    //   34: getfield h : Lc2/n$e;
    //   37: invokevirtual isEmpty : ()Z
    //   40: ifeq -> 82
    //   43: aload_0
    //   44: invokevirtual b : ()V
    //   47: aload_0
    //   48: getfield z : Z
    //   51: ifne -> 95
    //   54: aload_0
    //   55: getfield B : Z
    //   58: ifeq -> 90
    //   61: goto -> 95
    //   64: iload_2
    //   65: ifeq -> 82
    //   68: aload_0
    //   69: getfield r : Ljava/util/concurrent/atomic/AtomicInteger;
    //   72: invokevirtual get : ()I
    //   75: ifne -> 82
    //   78: aload_0
    //   79: invokevirtual g : ()V
    //   82: aload_0
    //   83: monitorexit
    //   84: return
    //   85: astore_1
    //   86: aload_0
    //   87: monitorexit
    //   88: aload_1
    //   89: athrow
    //   90: iconst_0
    //   91: istore_2
    //   92: goto -> 64
    //   95: iconst_1
    //   96: istore_2
    //   97: goto -> 64
    // Exception table:
    //   from	to	target	type
    //   2	61	85	finally
    //   68	82	85	finally
  }
  
  public class a implements Runnable {
    public final h h;
    
    public a(n this$0, h param1h) {
      this.h = param1h;
    }
    
    public void run() {
      i i = (i)this.h;
      i.b.a();
      synchronized (i.c) {
        synchronized (this.i) {
          n.e e = this.i.h;
          h h1 = this.h;
          if (e.h.contains(new n.d(h1, v2.e.b))) {
            n n1 = this.i;
            h h2 = this.h;
            Objects.requireNonNull(n1);
          } 
          this.i.c();
          return;
        } 
      } 
    }
  }
  
  public class b implements Runnable {
    public final h h;
    
    public b(n this$0, h param1h) {
      this.h = param1h;
    }
    
    public void run() {
      i i = (i)this.h;
      i.b.a();
      synchronized (i.c) {
        synchronized (this.i) {
          n.e e = this.i.h;
          h h1 = this.h;
          if (e.h.contains(new n.d(h1, v2.e.b))) {
            this.i.C.a();
            n n1 = this.i;
            h1 = this.h;
            Objects.requireNonNull(n1);
            try {
              r<?> r = n1.C;
              a2.a a = n1.y;
              boolean bool = n1.F;
              ((i)h1).p(r, a, bool);
            } finally {
              n1 = null;
            } 
          } 
          this.i.c();
          return;
        } 
      } 
    }
  }
  
  public static class c {}
  
  public static final class d {
    public final h a;
    
    public final Executor b;
    
    public d(h param1h, Executor param1Executor) {
      this.a = param1h;
      this.b = param1Executor;
    }
    
    public boolean equals(Object param1Object) {
      if (param1Object instanceof d) {
        param1Object = param1Object;
        return this.a.equals(((d)param1Object).a);
      } 
      return false;
    }
    
    public int hashCode() {
      return this.a.hashCode();
    }
  }
  
  public static final class e implements Iterable<d> {
    public final List<n.d> h;
    
    public e() {
      this.h = arrayList;
    }
    
    public boolean isEmpty() {
      return this.h.isEmpty();
    }
    
    public Iterator<n.d> iterator() {
      return this.h.iterator();
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Luxury Logo Maker_ Logo Design-dex2jar.jar!\c2\n.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */