package c2;

import a2.f;
import a2.h;
import a2.l;
import android.support.v4.media.c;
import java.security.MessageDigest;
import java.util.Map;
import java.util.Objects;

public class p implements f {
  public final Object b;
  
  public final int c;
  
  public final int d;
  
  public final Class<?> e;
  
  public final Class<?> f;
  
  public final f g;
  
  public final Map<Class<?>, l<?>> h;
  
  public final h i;
  
  public int j;
  
  public p(Object paramObject, f paramf, int paramInt1, int paramInt2, Map<Class<?>, l<?>> paramMap, Class<?> paramClass1, Class<?> paramClass2, h paramh) {
    Objects.requireNonNull(paramObject, "Argument must not be null");
    this.b = paramObject;
    Objects.requireNonNull(paramf, "Signature must not be null");
    this.g = paramf;
    this.c = paramInt1;
    this.d = paramInt2;
    Objects.requireNonNull(paramMap, "Argument must not be null");
    this.h = paramMap;
    Objects.requireNonNull(paramClass1, "Resource class must not be null");
    this.e = paramClass1;
    Objects.requireNonNull(paramClass2, "Transcode class must not be null");
    this.f = paramClass2;
    Objects.requireNonNull(paramh, "Argument must not be null");
    this.i = paramh;
  }
  
  public void a(MessageDigest paramMessageDigest) {
    throw new UnsupportedOperationException();
  }
  
  public boolean equals(Object paramObject) {
    boolean bool = paramObject instanceof p;
    boolean bool2 = false;
    boolean bool1 = bool2;
    if (bool) {
      paramObject = paramObject;
      bool1 = bool2;
      if (this.b.equals(((p)paramObject).b)) {
        bool1 = bool2;
        if (this.g.equals(((p)paramObject).g)) {
          bool1 = bool2;
          if (this.d == ((p)paramObject).d) {
            bool1 = bool2;
            if (this.c == ((p)paramObject).c) {
              bool1 = bool2;
              if (this.h.equals(((p)paramObject).h)) {
                bool1 = bool2;
                if (this.e.equals(((p)paramObject).e)) {
                  bool1 = bool2;
                  if (this.f.equals(((p)paramObject).f)) {
                    bool1 = bool2;
                    if (this.i.equals(((p)paramObject).i))
                      bool1 = true; 
                  } 
                } 
              } 
            } 
          } 
        } 
      } 
    } 
    return bool1;
  }
  
  public int hashCode() {
    if (this.j == 0) {
      int i = this.b.hashCode();
      this.j = i;
      i = this.g.hashCode() + i * 31;
      this.j = i;
      i = i * 31 + this.c;
      this.j = i;
      i = i * 31 + this.d;
      this.j = i;
      i = this.h.hashCode() + i * 31;
      this.j = i;
      i = this.e.hashCode() + i * 31;
      this.j = i;
      i = this.f.hashCode() + i * 31;
      this.j = i;
      this.j = this.i.hashCode() + i * 31;
    } 
    return this.j;
  }
  
  public String toString() {
    StringBuilder stringBuilder = c.a("EngineKey{model=");
    stringBuilder.append(this.b);
    stringBuilder.append(", width=");
    stringBuilder.append(this.c);
    stringBuilder.append(", height=");
    stringBuilder.append(this.d);
    stringBuilder.append(", resourceClass=");
    stringBuilder.append(this.e);
    stringBuilder.append(", transcodeClass=");
    stringBuilder.append(this.f);
    stringBuilder.append(", signature=");
    stringBuilder.append(this.g);
    stringBuilder.append(", hashCode=");
    stringBuilder.append(this.j);
    stringBuilder.append(", transformations=");
    stringBuilder.append(this.h);
    stringBuilder.append(", options=");
    stringBuilder.append(this.i);
    stringBuilder.append('}');
    return stringBuilder.toString();
  }
}


/* Location:              C:\soft\dex2jar-2.0\Luxury Logo Maker_ Logo Design-dex2jar.jar!\c2\p.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */