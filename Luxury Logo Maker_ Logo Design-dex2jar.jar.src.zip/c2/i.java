package c2;

import a2.f;
import a2.h;
import a2.k;
import android.os.SystemClock;
import android.util.Log;
import androidx.appcompat.widget.s0;
import com.bumptech.glide.f;
import j.f;
import java.util.ArrayList;
import java.util.List;
import t.g;
import v2.h;
import w2.a;

public class i<R> implements g.a, Runnable, Comparable<i<?>>, a.d {
  public long A;
  
  public boolean B;
  
  public Object C;
  
  public Thread D;
  
  public f E;
  
  public f F;
  
  public Object G;
  
  public a2.a H;
  
  public com.bumptech.glide.load.data.d<?> I;
  
  public volatile g J;
  
  public volatile boolean K;
  
  public volatile boolean L;
  
  public boolean M;
  
  public final h<R> h = new h<R>();
  
  public final List<Throwable> i = new ArrayList<Throwable>();
  
  public final w2.d j = (w2.d)new w2.d.b();
  
  public final d k;
  
  public final j0.c<i<?>> l;
  
  public final c<?> m = new c();
  
  public final e n = new e();
  
  public com.bumptech.glide.d o;
  
  public f p;
  
  public f q;
  
  public p r;
  
  public int s;
  
  public int t;
  
  public l u;
  
  public h v;
  
  public a<R> w;
  
  public int x;
  
  public int y;
  
  public int z;
  
  public i(d paramd, j0.c<i<?>> paramc) {
    this.k = paramd;
    this.l = paramc;
  }
  
  public void a() {
    p(2);
  }
  
  public int compareTo(Object paramObject) {
    paramObject = paramObject;
    int k = this.q.ordinal() - ((i)paramObject).q.ordinal();
    int j = k;
    if (k == 0)
      j = this.x - ((i)paramObject).x; 
    return j;
  }
  
  public void d(f paramf, Exception paramException, com.bumptech.glide.load.data.d<?> paramd, a2.a parama) {
    paramd.b();
    paramException = new s("Fetching data failed", paramException);
    Class<?> clazz = paramd.a();
    ((s)paramException).i = paramf;
    ((s)paramException).j = parama;
    ((s)paramException).k = clazz;
    this.i.add(paramException);
    if (Thread.currentThread() != this.D) {
      p(2);
      return;
    } 
    q();
  }
  
  public void e(f paramf1, Object<f> paramObject, com.bumptech.glide.load.data.d<?> paramd, a2.a parama, f paramf2) {
    this.E = paramf1;
    this.G = paramObject;
    this.I = paramd;
    this.H = parama;
    this.F = paramf2;
    paramObject = (Object<f>)this.h.a();
    boolean bool = false;
    if (paramf1 != paramObject.get(0))
      bool = true; 
    this.M = bool;
    if (Thread.currentThread() != this.D) {
      p(3);
      return;
    } 
    try {
      i();
      return;
    } finally {}
  }
  
  public w2.d f() {
    return this.j;
  }
  
  public final <Data> x<R> g(com.bumptech.glide.load.data.d<?> paramd, Data paramData, a2.a parama) {
    if (paramData == null) {
      paramd.b();
      return null;
    } 
    try {
      int j = h.b;
      long l1 = SystemClock.elapsedRealtimeNanos();
      x<?> x = h(paramData, parama);
      if (Log.isLoggable("DecodeJob", 2)) {
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("Decoded result ");
        stringBuilder.append(x);
        l(stringBuilder.toString(), l1, null);
      } 
      return (x)x;
    } finally {
      paramd.b();
    } 
  }
  
  public final <Data> x<R> h(Data paramData, a2.a parama) {
    // Byte code:
    //   0: aload_0
    //   1: getfield h : Lc2/h;
    //   4: aload_1
    //   5: invokevirtual getClass : ()Ljava/lang/Class;
    //   8: invokevirtual d : (Ljava/lang/Class;)Lc2/v;
    //   11: astore #6
    //   13: aload_0
    //   14: getfield v : La2/h;
    //   17: astore #5
    //   19: getstatic android/os/Build$VERSION.SDK_INT : I
    //   22: bipush #26
    //   24: if_icmpge -> 34
    //   27: aload #5
    //   29: astore #4
    //   31: goto -> 103
    //   34: aload_2
    //   35: getstatic a2/a.k : La2/a;
    //   38: if_acmpeq -> 59
    //   41: aload_0
    //   42: getfield h : Lc2/h;
    //   45: getfield r : Z
    //   48: ifeq -> 54
    //   51: goto -> 59
    //   54: iconst_0
    //   55: istore_3
    //   56: goto -> 61
    //   59: iconst_1
    //   60: istore_3
    //   61: getstatic j2/m.i : La2/g;
    //   64: astore #7
    //   66: aload #5
    //   68: aload #7
    //   70: invokevirtual c : (La2/g;)Ljava/lang/Object;
    //   73: checkcast java/lang/Boolean
    //   76: astore #8
    //   78: aload #8
    //   80: ifnull -> 106
    //   83: aload #5
    //   85: astore #4
    //   87: aload #8
    //   89: invokevirtual booleanValue : ()Z
    //   92: ifeq -> 103
    //   95: iload_3
    //   96: ifeq -> 106
    //   99: aload #5
    //   101: astore #4
    //   103: goto -> 142
    //   106: new a2/h
    //   109: dup
    //   110: invokespecial <init> : ()V
    //   113: astore #4
    //   115: aload #4
    //   117: aload_0
    //   118: getfield v : La2/h;
    //   121: invokevirtual d : (La2/h;)V
    //   124: aload #4
    //   126: getfield b : Lr/a;
    //   129: aload #7
    //   131: iload_3
    //   132: invokestatic valueOf : (Z)Ljava/lang/Boolean;
    //   135: invokevirtual put : (Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    //   138: pop
    //   139: goto -> 103
    //   142: aload_0
    //   143: getfield o : Lcom/bumptech/glide/d;
    //   146: invokevirtual a : ()Lcom/bumptech/glide/g;
    //   149: aload_1
    //   150: invokevirtual g : (Ljava/lang/Object;)Lcom/bumptech/glide/load/data/e;
    //   153: astore_1
    //   154: aload #6
    //   156: aload_1
    //   157: aload #4
    //   159: aload_0
    //   160: getfield s : I
    //   163: aload_0
    //   164: getfield t : I
    //   167: new c2/i$b
    //   170: dup
    //   171: aload_0
    //   172: aload_2
    //   173: invokespecial <init> : (Lc2/i;La2/a;)V
    //   176: invokevirtual a : (Lcom/bumptech/glide/load/data/e;La2/h;IILc2/k$a;)Lc2/x;
    //   179: astore_2
    //   180: aload_1
    //   181: invokeinterface b : ()V
    //   186: aload_2
    //   187: areturn
    //   188: astore_2
    //   189: aload_1
    //   190: invokeinterface b : ()V
    //   195: aload_2
    //   196: athrow
    // Exception table:
    //   from	to	target	type
    //   154	180	188	finally
  }
  
  public final void i() {
    if (Log.isLoggable("DecodeJob", 2)) {
      long l1 = this.A;
      StringBuilder stringBuilder = android.support.v4.media.c.a("data: ");
      stringBuilder.append(this.G);
      stringBuilder.append(", cache key: ");
      stringBuilder.append(this.E);
      stringBuilder.append(", fetcher: ");
      stringBuilder.append(this.I);
      l("Retrieved data", l1, stringBuilder.toString());
    } 
    w<?> w = null;
    try {
      x<?> x = g(this.I, this.G, this.H);
    } catch (s s) {
      f f1 = this.F;
      a2.a a1 = this.H;
      s.i = f1;
      s.j = a1;
      s.k = null;
      this.i.add(s);
      s = null;
    } 
    if (s != null) {
      a2.a a1 = this.H;
      boolean bool = this.M;
      try {
        boolean bool1;
        w<?> w1;
        if (s instanceof t)
          ((t)s).a(); 
        if (this.m.c != null) {
          bool1 = true;
        } else {
          bool1 = false;
        } 
        s s1 = s;
        if (bool1) {
          w = w.a((x<?>)s);
          w1 = w;
        } 
        m((x)w1, a1, bool);
        this.y = 5;
      } finally {}
    } else {
      q();
    } 
  }
  
  public final g j() {
    int j = g.a(this.y);
    if (j != 1) {
      if (j != 2) {
        if (j != 3) {
          if (j == 5)
            return null; 
          StringBuilder stringBuilder = android.support.v4.media.c.a("Unrecognized stage: ");
          stringBuilder.append(s0.b(this.y));
          throw new IllegalStateException(stringBuilder.toString());
        } 
        return new c0(this.h, this);
      } 
      return new d(this.h, this);
    } 
    return new y(this.h, this);
  }
  
  public final int k(int paramInt) {
    if (paramInt != 0) {
      int j = paramInt - 1;
      if (j != 0) {
        if (j != 1) {
          if (j != 2) {
            if (j != 3) {
              if (j == 5)
                return 6; 
              StringBuilder stringBuilder = new StringBuilder();
              stringBuilder.append("Unrecognized stage: ");
              stringBuilder.append(s0.b(paramInt));
              throw new IllegalArgumentException(stringBuilder.toString());
            } 
            return 6;
          } 
          return this.B ? 6 : 4;
        } 
        return this.u.a() ? 3 : k(3);
      } 
      return this.u.b() ? 2 : k(2);
    } 
    throw null;
  }
  
  public final void l(String paramString1, long paramLong, String paramString2) {
    StringBuilder stringBuilder = new StringBuilder();
    stringBuilder.append(paramString1);
    stringBuilder.append(" in ");
    stringBuilder.append(h.a(paramLong));
    stringBuilder.append(", load key: ");
    stringBuilder.append(this.r);
    if (paramString2 != null) {
      paramString1 = f.a(", ", paramString2);
    } else {
      paramString1 = "";
    } 
    stringBuilder.append(paramString1);
    stringBuilder.append(", thread: ");
    stringBuilder.append(Thread.currentThread().getName());
    Log.v("DecodeJob", stringBuilder.toString());
  }
  
  public final void m(x<R> paramx, a2.a parama, boolean paramBoolean) {
    // Byte code:
    //   0: aload_0
    //   1: invokevirtual s : ()V
    //   4: aload_0
    //   5: getfield w : Lc2/i$a;
    //   8: checkcast c2/n
    //   11: astore #4
    //   13: aload #4
    //   15: monitorenter
    //   16: aload #4
    //   18: aload_1
    //   19: putfield x : Lc2/x;
    //   22: aload #4
    //   24: aload_2
    //   25: putfield y : La2/a;
    //   28: aload #4
    //   30: iload_3
    //   31: putfield F : Z
    //   34: aload #4
    //   36: monitorexit
    //   37: aload #4
    //   39: monitorenter
    //   40: aload #4
    //   42: getfield i : Lw2/d;
    //   45: invokevirtual a : ()V
    //   48: aload #4
    //   50: getfield E : Z
    //   53: ifeq -> 75
    //   56: aload #4
    //   58: getfield x : Lc2/x;
    //   61: invokeinterface d : ()V
    //   66: aload #4
    //   68: invokevirtual g : ()V
    //   71: aload #4
    //   73: monitorexit
    //   74: return
    //   75: aload #4
    //   77: getfield h : Lc2/n$e;
    //   80: invokevirtual isEmpty : ()Z
    //   83: ifne -> 288
    //   86: aload #4
    //   88: getfield z : Z
    //   91: ifne -> 277
    //   94: aload #4
    //   96: getfield l : Lc2/n$c;
    //   99: astore_1
    //   100: aload #4
    //   102: getfield x : Lc2/x;
    //   105: astore_2
    //   106: aload #4
    //   108: getfield t : Z
    //   111: istore_3
    //   112: aload #4
    //   114: getfield s : La2/f;
    //   117: astore #5
    //   119: aload #4
    //   121: getfield j : Lc2/r$a;
    //   124: astore #6
    //   126: aload_1
    //   127: invokestatic requireNonNull : (Ljava/lang/Object;)Ljava/lang/Object;
    //   130: pop
    //   131: aload #4
    //   133: new c2/r
    //   136: dup
    //   137: aload_2
    //   138: iload_3
    //   139: iconst_1
    //   140: aload #5
    //   142: aload #6
    //   144: invokespecial <init> : (Lc2/x;ZZLa2/f;Lc2/r$a;)V
    //   147: putfield C : Lc2/r;
    //   150: aload #4
    //   152: iconst_1
    //   153: putfield z : Z
    //   156: aload #4
    //   158: getfield h : Lc2/n$e;
    //   161: astore_1
    //   162: aload_1
    //   163: invokestatic requireNonNull : (Ljava/lang/Object;)Ljava/lang/Object;
    //   166: pop
    //   167: new java/util/ArrayList
    //   170: dup
    //   171: aload_1
    //   172: getfield h : Ljava/util/List;
    //   175: invokespecial <init> : (Ljava/util/Collection;)V
    //   178: astore_1
    //   179: aload #4
    //   181: aload_1
    //   182: invokevirtual size : ()I
    //   185: iconst_1
    //   186: iadd
    //   187: invokevirtual d : (I)V
    //   190: aload #4
    //   192: getfield s : La2/f;
    //   195: astore_2
    //   196: aload #4
    //   198: getfield C : Lc2/r;
    //   201: astore #5
    //   203: aload #4
    //   205: monitorexit
    //   206: aload #4
    //   208: getfield m : Lc2/o;
    //   211: checkcast c2/m
    //   214: aload #4
    //   216: aload_2
    //   217: aload #5
    //   219: invokevirtual e : (Lc2/n;La2/f;Lc2/r;)V
    //   222: aload_1
    //   223: invokevirtual iterator : ()Ljava/util/Iterator;
    //   226: astore_1
    //   227: aload_1
    //   228: invokeinterface hasNext : ()Z
    //   233: ifeq -> 271
    //   236: aload_1
    //   237: invokeinterface next : ()Ljava/lang/Object;
    //   242: checkcast c2/n$d
    //   245: astore_2
    //   246: aload_2
    //   247: getfield b : Ljava/util/concurrent/Executor;
    //   250: new c2/n$b
    //   253: dup
    //   254: aload #4
    //   256: aload_2
    //   257: getfield a : Lr2/h;
    //   260: invokespecial <init> : (Lc2/n;Lr2/h;)V
    //   263: invokeinterface execute : (Ljava/lang/Runnable;)V
    //   268: goto -> 227
    //   271: aload #4
    //   273: invokevirtual c : ()V
    //   276: return
    //   277: new java/lang/IllegalStateException
    //   280: dup
    //   281: ldc_w 'Already have resource'
    //   284: invokespecial <init> : (Ljava/lang/String;)V
    //   287: athrow
    //   288: new java/lang/IllegalStateException
    //   291: dup
    //   292: ldc_w 'Received a resource without any callbacks to notify'
    //   295: invokespecial <init> : (Ljava/lang/String;)V
    //   298: athrow
    //   299: astore_1
    //   300: aload #4
    //   302: monitorexit
    //   303: aload_1
    //   304: athrow
    //   305: astore_1
    //   306: aload #4
    //   308: monitorexit
    //   309: aload_1
    //   310: athrow
    // Exception table:
    //   from	to	target	type
    //   16	37	305	finally
    //   40	74	299	finally
    //   75	206	299	finally
    //   277	288	299	finally
    //   288	299	299	finally
    //   300	303	299	finally
    //   306	309	305	finally
  }
  
  public final void n() {
    // Byte code:
    //   0: aload_0
    //   1: invokevirtual s : ()V
    //   4: new c2/s
    //   7: dup
    //   8: ldc_w 'Failed to load resource'
    //   11: new java/util/ArrayList
    //   14: dup
    //   15: aload_0
    //   16: getfield i : Ljava/util/List;
    //   19: invokespecial <init> : (Ljava/util/Collection;)V
    //   22: invokespecial <init> : (Ljava/lang/String;Ljava/util/List;)V
    //   25: astore_3
    //   26: aload_0
    //   27: getfield w : Lc2/i$a;
    //   30: checkcast c2/n
    //   33: astore_2
    //   34: aload_2
    //   35: monitorenter
    //   36: aload_2
    //   37: aload_3
    //   38: putfield A : Lc2/s;
    //   41: aload_2
    //   42: monitorexit
    //   43: aload_2
    //   44: monitorenter
    //   45: aload_2
    //   46: getfield i : Lw2/d;
    //   49: invokevirtual a : ()V
    //   52: aload_2
    //   53: getfield E : Z
    //   56: ifeq -> 68
    //   59: aload_2
    //   60: invokevirtual g : ()V
    //   63: aload_2
    //   64: monitorexit
    //   65: goto -> 203
    //   68: aload_2
    //   69: getfield h : Lc2/n$e;
    //   72: invokevirtual isEmpty : ()Z
    //   75: ifne -> 248
    //   78: aload_2
    //   79: getfield B : Z
    //   82: ifne -> 237
    //   85: aload_2
    //   86: iconst_1
    //   87: putfield B : Z
    //   90: aload_2
    //   91: getfield s : La2/f;
    //   94: astore_3
    //   95: aload_2
    //   96: getfield h : Lc2/n$e;
    //   99: astore #4
    //   101: aload #4
    //   103: invokestatic requireNonNull : (Ljava/lang/Object;)Ljava/lang/Object;
    //   106: pop
    //   107: new java/util/ArrayList
    //   110: dup
    //   111: aload #4
    //   113: getfield h : Ljava/util/List;
    //   116: invokespecial <init> : (Ljava/util/Collection;)V
    //   119: astore #4
    //   121: aload_2
    //   122: aload #4
    //   124: invokevirtual size : ()I
    //   127: iconst_1
    //   128: iadd
    //   129: invokevirtual d : (I)V
    //   132: aload_2
    //   133: monitorexit
    //   134: aload_2
    //   135: getfield m : Lc2/o;
    //   138: checkcast c2/m
    //   141: aload_2
    //   142: aload_3
    //   143: aconst_null
    //   144: invokevirtual e : (Lc2/n;La2/f;Lc2/r;)V
    //   147: aload #4
    //   149: invokevirtual iterator : ()Ljava/util/Iterator;
    //   152: astore_3
    //   153: aload_3
    //   154: invokeinterface hasNext : ()Z
    //   159: ifeq -> 199
    //   162: aload_3
    //   163: invokeinterface next : ()Ljava/lang/Object;
    //   168: checkcast c2/n$d
    //   171: astore #4
    //   173: aload #4
    //   175: getfield b : Ljava/util/concurrent/Executor;
    //   178: new c2/n$a
    //   181: dup
    //   182: aload_2
    //   183: aload #4
    //   185: getfield a : Lr2/h;
    //   188: invokespecial <init> : (Lc2/n;Lr2/h;)V
    //   191: invokeinterface execute : (Ljava/lang/Runnable;)V
    //   196: goto -> 153
    //   199: aload_2
    //   200: invokevirtual c : ()V
    //   203: aload_0
    //   204: getfield n : Lc2/i$e;
    //   207: astore_2
    //   208: aload_2
    //   209: monitorenter
    //   210: aload_2
    //   211: iconst_1
    //   212: putfield c : Z
    //   215: aload_2
    //   216: iconst_0
    //   217: invokevirtual a : (Z)Z
    //   220: istore_1
    //   221: aload_2
    //   222: monitorexit
    //   223: iload_1
    //   224: ifeq -> 231
    //   227: aload_0
    //   228: invokevirtual o : ()V
    //   231: return
    //   232: astore_3
    //   233: aload_2
    //   234: monitorexit
    //   235: aload_3
    //   236: athrow
    //   237: new java/lang/IllegalStateException
    //   240: dup
    //   241: ldc_w 'Already failed once'
    //   244: invokespecial <init> : (Ljava/lang/String;)V
    //   247: athrow
    //   248: new java/lang/IllegalStateException
    //   251: dup
    //   252: ldc_w 'Received an exception without any callbacks to notify'
    //   255: invokespecial <init> : (Ljava/lang/String;)V
    //   258: athrow
    //   259: astore_3
    //   260: aload_2
    //   261: monitorexit
    //   262: aload_3
    //   263: athrow
    //   264: astore_3
    //   265: aload_2
    //   266: monitorexit
    //   267: aload_3
    //   268: athrow
    // Exception table:
    //   from	to	target	type
    //   36	43	264	finally
    //   45	65	259	finally
    //   68	134	259	finally
    //   210	221	232	finally
    //   237	248	259	finally
    //   248	259	259	finally
    //   260	262	259	finally
    //   265	267	264	finally
  }
  
  public final void o() {
    e e1;
    h<R> h1;
    synchronized (this.n) {
      e1.b = false;
      e1.a = false;
      e1.c = false;
      c<?> c1 = this.m;
      c1.a = null;
      c1.b = null;
      c1.c = null;
      h1 = this.h;
      h1.c = null;
      h1.d = null;
      h1.n = null;
      h1.g = null;
      h1.k = null;
      h1.i = null;
      h1.o = null;
      h1.j = null;
      h1.p = null;
      h1.a.clear();
      h1.l = false;
      h1.b.clear();
      h1.m = false;
      this.K = false;
      this.o = null;
      this.p = null;
      this.v = null;
      this.q = null;
      this.r = null;
      this.w = null;
      this.y = 0;
      this.J = null;
      this.D = null;
      this.E = null;
      this.G = null;
      this.H = null;
      this.I = null;
      this.A = 0L;
      this.L = false;
      this.C = null;
      this.i.clear();
      this.l.a(this);
      return;
    } 
  }
  
  public final void p(int paramInt) {
    f2.a a1;
    this.z = paramInt;
    n n = (n)this.w;
    if (n.u) {
      a1 = n.p;
    } else if (((n)a1).v) {
      a1 = ((n)a1).q;
    } else {
      a1 = ((n)a1).o;
    } 
    a1.h.execute(this);
  }
  
  public final void q() {
    boolean bool2;
    this.D = Thread.currentThread();
    int j = h.b;
    this.A = SystemClock.elapsedRealtimeNanos();
    boolean bool1 = false;
    while (true) {
      bool2 = bool1;
      if (!this.L) {
        bool2 = bool1;
        if (this.J != null) {
          bool1 = this.J.b();
          bool2 = bool1;
          if (!bool1) {
            this.y = k(this.y);
            this.J = j();
            if (this.y == 4) {
              p(2);
              return;
            } 
            continue;
          } 
        } 
      } 
      break;
    } 
    if ((this.y == 6 || this.L) && !bool2)
      n(); 
  }
  
  public final void r() {
    int j = g.a(this.z);
    if (j != 0) {
      if (j != 1) {
        if (j == 2) {
          i();
          return;
        } 
        StringBuilder stringBuilder = android.support.v4.media.c.a("Unrecognized run reason: ");
        stringBuilder.append(j.a(this.z));
        throw new IllegalStateException(stringBuilder.toString());
      } 
    } else {
      this.y = k(1);
      this.J = j();
    } 
    q();
  }
  
  public void run() {
    com.bumptech.glide.load.data.d<?> d1 = this.I;
    try {
      if (this.L) {
        n();
        if (d1 != null)
          d1.b(); 
        return;
      } 
    } catch (c c1) {
    
    } finally {
      Exception exception;
    } 
    r();
    if (d1 != null)
      d1.b(); 
  }
  
  public final void s() {
    this.j.a();
    if (this.K) {
      Throwable throwable;
      if (this.i.isEmpty()) {
        throwable = null;
      } else {
        List<Throwable> list = this.i;
        throwable = list.get(list.size() - 1);
      } 
      throw new IllegalStateException("Already notified", throwable);
    } 
    this.K = true;
  }
  
  public static interface a<R> {}
  
  public final class b<Z> implements k.a<Z> {
    public final a2.a a;
    
    public b(i this$0, a2.a param1a) {
      this.a = param1a;
    }
  }
  
  public static class c<Z> {
    public f a;
    
    public k<Z> b;
    
    public w<Z> c;
  }
  
  public static interface d {}
  
  public static class e {
    public boolean a;
    
    public boolean b;
    
    public boolean c;
    
    public final boolean a(boolean param1Boolean) {
      return ((this.c || param1Boolean || this.b) && this.a);
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Luxury Logo Maker_ Logo Design-dex2jar.jar!\c2\i.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */