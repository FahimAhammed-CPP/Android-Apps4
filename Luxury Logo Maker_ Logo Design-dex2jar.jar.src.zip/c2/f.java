package c2;

import a2.d;
import a2.h;
import e2.a;

public class f<DataType> implements a.b {
  public final d<DataType> a;
  
  public final DataType b;
  
  public final h c;
  
  public f(d<DataType> paramd, DataType paramDataType, h paramh) {
    this.a = paramd;
    this.b = paramDataType;
    this.c = paramh;
  }
}


/* Location:              C:\soft\dex2jar-2.0\Luxury Logo Maker_ Logo Design-dex2jar.jar!\c2\f.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */