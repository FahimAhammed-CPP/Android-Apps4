package c2;

import a2.a;
import a2.d;
import a2.f;
import android.os.SystemClock;
import android.util.Log;
import com.bumptech.glide.load.data.d;
import com.bumptech.glide.load.data.e;
import e2.a;
import g2.n;
import java.io.IOException;
import java.util.Collections;
import java.util.List;
import v2.h;

public class c0 implements g, g.a {
  public final h<?> h;
  
  public final g.a i;
  
  public volatile int j;
  
  public volatile d k;
  
  public volatile Object l;
  
  public volatile n.a<?> m;
  
  public volatile e n;
  
  public c0(h<?> paramh, g.a parama) {
    this.h = paramh;
    this.i = parama;
  }
  
  public void a() {
    throw new UnsupportedOperationException();
  }
  
  public boolean b() {
    if (this.l != null) {
      Object object = this.l;
      this.l = null;
      try {
        boolean bool1 = c(object);
        if (!bool1)
          return true; 
      } catch (IOException iOException) {
        if (Log.isLoggable("SourceGenerator", 3))
          Log.d("SourceGenerator", "Failed to properly rewind or write data to cache", iOException); 
      } 
    } 
    if (this.k != null && this.k.b())
      return true; 
    this.k = null;
    this.m = null;
    boolean bool = false;
    while (!bool) {
      int i;
      if (this.j < this.h.c().size()) {
        i = 1;
      } else {
        i = 0;
      } 
      if (i) {
        List<n.a<?>> list = this.h.c();
        i = this.j;
        this.j = i + 1;
        this.m = list.get(i);
        if (this.m != null && (this.h.p.c(this.m.c.e()) || this.h.h(this.m.c.a()))) {
          n.a<?> a1 = this.m;
          this.m.c.f(this.h.o, new b0(this, a1));
          bool = true;
        } 
      } 
    } 
    return bool;
  }
  
  public final boolean c(Object paramObject) {
    int i = h.b;
    long l = SystemClock.elapsedRealtimeNanos();
    i = 0;
    try {
      e e1 = this.h.c.a().g(paramObject);
      Object object = e1.a();
      d d1 = this.h.f(object);
      object = new f(d1, object, this.h.i);
      f f = this.m.a;
      h<?> h1 = this.h;
      f = new e(f, h1.n);
      a a1 = h1.b();
      a1.b(f, (a.b)object);
      boolean bool = Log.isLoggable("SourceGenerator", 2);
      if (bool) {
        object = new StringBuilder();
        object.append("Finished encoding source to cache, key: ");
        object.append(f);
        object.append(", data: ");
        object.append(paramObject);
        object.append(", encoder: ");
        object.append(d1);
        object.append(", duration: ");
        object.append(h.a(l));
        Log.v("SourceGenerator", object.toString());
      } 
      if (a1.a(f) != null) {
        this.n = (e)f;
        this.k = new d(Collections.singletonList(this.m.a), this.h, this);
        this.m.c.b();
        return true;
      } 
      if (Log.isLoggable("SourceGenerator", 3)) {
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("Attempt to write: ");
        stringBuilder.append(this.n);
        stringBuilder.append(", data: ");
        stringBuilder.append(paramObject);
        stringBuilder.append(" to the disk cache failed, maybe the disk cache is disabled? Trying to decode the data directly...");
        Log.d("SourceGenerator", stringBuilder.toString());
      } 
      try {
        return false;
      } finally {
        paramObject = null;
      } 
    } finally {}
    if (i == 0)
      this.m.c.b(); 
    throw paramObject;
  }
  
  public void cancel() {
    n.a<?> a1 = this.m;
    if (a1 != null)
      a1.c.cancel(); 
  }
  
  public void d(f paramf, Exception paramException, d<?> paramd, a parama) {
    this.i.d(paramf, paramException, paramd, this.m.c.e());
  }
  
  public void e(f paramf1, Object paramObject, d<?> paramd, a parama, f paramf2) {
    this.i.e(paramf1, paramObject, paramd, this.m.c.e(), paramf1);
  }
}


/* Location:              C:\soft\dex2jar-2.0\Luxury Logo Maker_ Logo Design-dex2jar.jar!\c2\c0.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */