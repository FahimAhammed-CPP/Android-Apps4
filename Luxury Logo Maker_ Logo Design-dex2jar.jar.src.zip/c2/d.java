package c2;

import a2.a;
import a2.f;
import com.bumptech.glide.load.data.d;
import g2.n;
import java.io.File;
import java.util.List;

public class d implements g, d.a<Object> {
  public final List<f> h;
  
  public final h<?> i;
  
  public final g.a j;
  
  public int k = -1;
  
  public f l;
  
  public List<n<File, ?>> m;
  
  public int n;
  
  public volatile n.a<?> o;
  
  public File p;
  
  public d(h<?> paramh, g.a parama) {
    this.h = list;
    this.i = paramh;
    this.j = parama;
  }
  
  public d(List<f> paramList, h<?> paramh, g.a parama) {
    this.h = paramList;
    this.i = paramh;
    this.j = parama;
  }
  
  public boolean b() {
    while (true) {
      while (true)
        break; 
      if (SYNTHETIC_LOCAL_VARIABLE_4 != null) {
        this.l = (f)SYNTHETIC_LOCAL_VARIABLE_3;
        this.m = this.i.c.a().f(SYNTHETIC_LOCAL_VARIABLE_4);
        this.n = 0;
      } 
    } 
    return SYNTHETIC_LOCAL_VARIABLE_2;
  }
  
  public void c(Exception paramException) {
    this.j.d(this.l, paramException, this.o.c, a.j);
  }
  
  public void cancel() {
    n.a<?> a1 = this.o;
    if (a1 != null)
      a1.c.cancel(); 
  }
  
  public void d(Object paramObject) {
    this.j.e(this.l, paramObject, this.o.c, a.j, this.l);
  }
}


/* Location:              C:\soft\dex2jar-2.0\Luxury Logo Maker_ Logo Design-dex2jar.jar!\c2\d.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */