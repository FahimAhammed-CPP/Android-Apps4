package c2;

import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.pm.ActivityInfo;
import android.content.pm.PackageManager;
import android.content.pm.ResolveInfo;
import android.graphics.Color;
import android.net.Uri;
import android.text.TextUtils;
import android.util.Log;
import android.util.TypedValue;
import android.view.View;
import d0.a;
import e4.ag;
import e4.aq0;
import e4.ig0;
import e4.jf;
import e4.mw;
import e4.n01;
import e4.oa0;
import e4.sr2;
import e4.uy;
import e4.ye;
import e4.z30;
import e4.ze;
import i5.b;
import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.ConcurrentHashMap;
import org.json.JSONObject;
import u5.o;

public class q implements ze, aq0, uy, o {
  public static String h;
  
  public static final ig0 k = new ig0(1);
  
  public static int c(int paramInt1, int paramInt2, int paramInt3) {
    return (paramInt1 < paramInt2) ? paramInt2 : ((paramInt1 > paramInt3) ? paramInt3 : paramInt1);
  }
  
  public static int e(Context paramContext, int paramInt1, int paramInt2) {
    TypedValue typedValue = b.a(paramContext, paramInt1);
    return (typedValue != null) ? typedValue.data : paramInt2;
  }
  
  public static int f(View paramView, int paramInt) {
    return b.c(paramView.getContext(), paramInt, paramView.getClass().getCanonicalName());
  }
  
  public static int g(int paramInt1, int paramInt2, float paramFloat) {
    return a.a(a.c(paramInt2, Math.round(Color.alpha(paramInt2) * paramFloat)), paramInt1);
  }
  
  public static String h(Context paramContext) {
    String str = h;
    if (str != null)
      return str; 
    PackageManager packageManager = paramContext.getPackageManager();
    Intent intent = new Intent("android.intent.action.VIEW", Uri.parse("http://www.example.com"));
    ResolveInfo resolveInfo = packageManager.resolveActivity(intent, 0);
    if (resolveInfo != null) {
      String str1 = resolveInfo.activityInfo.packageName;
    } else {
      resolveInfo = null;
    } 
    List list = packageManager.queryIntentActivities(intent, 0);
    ArrayList<String> arrayList = new ArrayList();
    for (ResolveInfo resolveInfo1 : list) {
      Intent intent1 = new Intent();
      intent1.setAction("android.support.customtabs.action.CustomTabsService");
      intent1.setPackage(resolveInfo1.activityInfo.packageName);
      if (packageManager.resolveService(intent1, 0) != null)
        arrayList.add(resolveInfo1.activityInfo.packageName); 
    } 
    if (arrayList.isEmpty()) {
      h = null;
    } else {
      String str1;
      if (arrayList.size() == 1) {
        str1 = arrayList.get(0);
      } else {
        if (!TextUtils.isEmpty((CharSequence)resolveInfo)) {
          try {
            List list1 = str1.getPackageManager().queryIntentActivities(intent, 64);
            if (list1 != null && list1.size() != 0)
              for (ResolveInfo resolveInfo1 : list1) {
                IntentFilter intentFilter = resolveInfo1.filter;
                if (intentFilter != null && intentFilter.countDataAuthorities() != 0 && intentFilter.countDataPaths() != 0) {
                  ActivityInfo activityInfo = resolveInfo1.activityInfo;
                  if (activityInfo != null)
                    // Byte code: goto -> 322 
                } 
              }  
          } catch (RuntimeException runtimeException) {
            Log.e("CustomTabsHelper", "Runtime exception while getting specialized handlers");
          } 
          if (arrayList.contains(resolveInfo)) {
            h = (String)resolveInfo;
            return h;
          } 
        } 
        str1 = "com.android.chrome";
        if (arrayList.contains("com.android.chrome"))
          h = str1; 
        str1 = "com.chrome.beta";
        if (arrayList.contains("com.chrome.beta"))
          h = str1; 
        str1 = "com.chrome.dev";
        if (arrayList.contains("com.chrome.dev"))
          h = str1; 
        str1 = "com.google.android.apps.chrome";
        if (arrayList.contains("com.google.android.apps.chrome"))
          h = str1; 
        return h;
      } 
      h = str1;
    } 
    return h;
  }
  
  public static void i(long paramLong, n01 paramn01, sr2[] paramArrayOfsr2) {
    while (true) {
      int i = paramn01.i();
      boolean bool = true;
      if (i > 1) {
        int j = k(paramn01);
        int k = k(paramn01);
        int m = paramn01.b + k;
        if (k == -1 || k > paramn01.i()) {
          Log.w("CeaUtil", "Skipping remainder of malformed SEI NAL unit.");
          i = paramn01.c;
        } else {
          i = m;
          if (j == 4) {
            i = m;
            if (k >= 8) {
              int n = paramn01.p();
              i = paramn01.s();
              if (i == 49) {
                j = paramn01.k();
                i = 49;
              } else {
                j = 0;
              } 
              int i1 = paramn01.p();
              k = i;
              if (i == 47) {
                paramn01.g(1);
                k = 47;
              } 
              if (n == 181 && (k == 49 || k == 47) && i1 == 3) {
                i = 1;
              } else {
                i = 0;
              } 
              n = i;
              if (k == 49) {
                if (j == 1195456820) {
                  j = bool;
                } else {
                  j = 0;
                } 
                n = i & j;
              } 
              i = m;
              if (n != 0) {
                j(paramLong, paramn01, paramArrayOfsr2);
                i = m;
              } 
            } 
          } 
        } 
        paramn01.f(i);
        continue;
      } 
      break;
    } 
  }
  
  public static void j(long paramLong, n01 paramn01, sr2[] paramArrayOfsr2) {
    int i = paramn01.p();
    if ((i & 0x40) != 0) {
      paramn01.g(1);
      int j = (i & 0x1F) * 3;
      int k = paramn01.b;
      int m = paramArrayOfsr2.length;
      for (i = 0; i < m; i++) {
        sr2 sr21 = paramArrayOfsr2[i];
        paramn01.f(k);
        sr21.c(paramn01, j);
        if (paramLong != -9223372036854775807L)
          sr21.b(paramLong, 1, j, 0, null); 
      } 
    } 
  }
  
  public static int k(n01 paramn01) {
    int i = 0;
    while (true) {
      if (paramn01.i() == 0)
        return -1; 
      int k = paramn01.p();
      int j = i + k;
      i = j;
      if (k != 255)
        return j; 
    } 
  }
  
  public Object a(JSONObject paramJSONObject) {
    return new z30(paramJSONObject);
  }
  
  public Object b() {
    return new ConcurrentHashMap<Object, Object>();
  }
  
  public void d(Object paramObject) {
    ((mw)paramObject).c();
  }
  
  public ye[] zza() {
    int i = oa0.D;
    return new ye[] { (ye)new ag(), (ye)new jf(0) };
  }
}


/* Location:              C:\soft\dex2jar-2.0\Luxury Logo Maker_ Logo Design-dex2jar.jar!\c2\q.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */