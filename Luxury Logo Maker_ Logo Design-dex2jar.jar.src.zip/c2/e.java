package c2;

import a2.f;
import android.support.v4.media.c;
import java.security.MessageDigest;

public final class e implements f {
  public final f b;
  
  public final f c;
  
  public e(f paramf1, f paramf2) {
    this.b = paramf1;
    this.c = paramf2;
  }
  
  public void a(MessageDigest paramMessageDigest) {
    this.b.a(paramMessageDigest);
    this.c.a(paramMessageDigest);
  }
  
  public boolean equals(Object paramObject) {
    boolean bool = paramObject instanceof e;
    boolean bool2 = false;
    boolean bool1 = bool2;
    if (bool) {
      paramObject = paramObject;
      bool1 = bool2;
      if (this.b.equals(((e)paramObject).b)) {
        bool1 = bool2;
        if (this.c.equals(((e)paramObject).c))
          bool1 = true; 
      } 
    } 
    return bool1;
  }
  
  public int hashCode() {
    int i = this.b.hashCode();
    return this.c.hashCode() + i * 31;
  }
  
  public String toString() {
    StringBuilder stringBuilder = c.a("DataCacheKey{sourceKey=");
    stringBuilder.append(this.b);
    stringBuilder.append(", signature=");
    stringBuilder.append(this.c);
    stringBuilder.append('}');
    return stringBuilder.toString();
  }
}


/* Location:              C:\soft\dex2jar-2.0\Luxury Logo Maker_ Logo Design-dex2jar.jar!\c2\e.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */