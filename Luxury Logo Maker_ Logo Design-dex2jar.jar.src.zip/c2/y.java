package c2;

import a2.a;
import a2.f;
import com.bumptech.glide.load.data.d;
import g2.n;
import java.io.File;
import java.util.List;

public class y implements g, d.a<Object> {
  public final g.a h;
  
  public final h<?> i;
  
  public int j;
  
  public int k = -1;
  
  public f l;
  
  public List<n<File, ?>> m;
  
  public int n;
  
  public volatile n.a<?> o;
  
  public File p;
  
  public z q;
  
  public y(h<?> paramh, g.a parama) {
    this.i = paramh;
    this.h = parama;
  }
  
  public boolean b() {
    try {
      List<f> list = this.i.a();
      if (list.isEmpty())
        return false; 
      List<Class<?>> list1 = this.i.e();
      if (list1.isEmpty()) {
        if (File.class.equals(this.i.k))
          return false; 
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("Failed to find any load path from ");
        stringBuilder.append(this.i.d.getClass());
        stringBuilder.append(" to ");
        stringBuilder.append(this.i.k);
        throw new IllegalStateException(stringBuilder.toString());
      } 
      while (true) {
        List<n<File, ?>> list2;
        while (true) {
          list2 = this.m;
          break;
        } 
        if (SYNTHETIC_LOCAL_VARIABLE_6 != null) {
          this.l = (f)list2;
          this.m = this.i.c.a().f(SYNTHETIC_LOCAL_VARIABLE_6);
          this.n = 0;
        } 
      } 
    } finally {}
    return SYNTHETIC_LOCAL_VARIABLE_2;
  }
  
  public void c(Exception paramException) {
    this.h.d(this.q, paramException, this.o.c, a.k);
  }
  
  public void cancel() {
    n.a<?> a1 = this.o;
    if (a1 != null)
      a1.c.cancel(); 
  }
  
  public void d(Object paramObject) {
    this.h.e(this.l, paramObject, this.o.c, a.k, this.q);
  }
}


/* Location:              C:\soft\dex2jar-2.0\Luxury Logo Maker_ Logo Design-dex2jar.jar!\c2\y.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */