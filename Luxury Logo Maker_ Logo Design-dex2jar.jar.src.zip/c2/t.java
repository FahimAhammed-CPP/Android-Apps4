package c2;

public interface t {
  void a();
}


/* Location:              C:\soft\dex2jar-2.0\Luxury Logo Maker_ Logo Design-dex2jar.jar!\c2\t.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */