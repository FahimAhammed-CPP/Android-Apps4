package c2;

import java.util.Objects;

public class b implements Runnable {
  public b(a parama) {}
  
  public void run() {
    a a1 = this.h;
    Objects.requireNonNull(a1);
    while (true) {
      try {
        while (true)
          a1.b((a.b)a1.d.remove()); 
        break;
      } catch (InterruptedException interruptedException) {
        Thread.currentThread().interrupt();
      } 
    } 
  }
}


/* Location:              C:\soft\dex2jar-2.0\Luxury Logo Maker_ Logo Design-dex2jar.jar!\c2\b.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */