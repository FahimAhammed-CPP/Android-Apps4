package c2;

import j0.c;
import java.util.Objects;
import w2.a;
import w2.d;

public final class w<Z> implements x<Z>, a.d {
  public static final c<w<?>> l = a.a(20, new a());
  
  public final d h = (d)new d.b();
  
  public x<Z> i;
  
  public boolean j;
  
  public boolean k;
  
  public static <Z> w<Z> a(x<Z> paramx) {
    w<Z> w1 = (w)((a.c)l).b();
    Objects.requireNonNull(w1, "Argument must not be null");
    w1.k = false;
    w1.j = true;
    w1.i = paramx;
    return w1;
  }
  
  public int b() {
    return this.i.b();
  }
  
  public Class<Z> c() {
    return this.i.c();
  }
  
  public void d() {
    // Byte code:
    //   0: aload_0
    //   1: monitorenter
    //   2: aload_0
    //   3: getfield h : Lw2/d;
    //   6: invokevirtual a : ()V
    //   9: aload_0
    //   10: iconst_1
    //   11: putfield k : Z
    //   14: aload_0
    //   15: getfield j : Z
    //   18: ifne -> 46
    //   21: aload_0
    //   22: getfield i : Lc2/x;
    //   25: invokeinterface d : ()V
    //   30: aload_0
    //   31: aconst_null
    //   32: putfield i : Lc2/x;
    //   35: getstatic c2/w.l : Lj0/c;
    //   38: checkcast w2/a$c
    //   41: aload_0
    //   42: invokevirtual a : (Ljava/lang/Object;)Z
    //   45: pop
    //   46: aload_0
    //   47: monitorexit
    //   48: return
    //   49: astore_1
    //   50: aload_0
    //   51: monitorexit
    //   52: aload_1
    //   53: athrow
    // Exception table:
    //   from	to	target	type
    //   2	46	49	finally
  }
  
  public void e() {
    // Byte code:
    //   0: aload_0
    //   1: monitorenter
    //   2: aload_0
    //   3: getfield h : Lw2/d;
    //   6: invokevirtual a : ()V
    //   9: aload_0
    //   10: getfield j : Z
    //   13: ifeq -> 35
    //   16: aload_0
    //   17: iconst_0
    //   18: putfield j : Z
    //   21: aload_0
    //   22: getfield k : Z
    //   25: ifeq -> 32
    //   28: aload_0
    //   29: invokevirtual d : ()V
    //   32: aload_0
    //   33: monitorexit
    //   34: return
    //   35: new java/lang/IllegalStateException
    //   38: dup
    //   39: ldc 'Already unlocked'
    //   41: invokespecial <init> : (Ljava/lang/String;)V
    //   44: athrow
    //   45: astore_1
    //   46: aload_0
    //   47: monitorexit
    //   48: aload_1
    //   49: athrow
    // Exception table:
    //   from	to	target	type
    //   2	32	45	finally
    //   35	45	45	finally
  }
  
  public d f() {
    return this.h;
  }
  
  public Z get() {
    return this.i.get();
  }
  
  public class a implements a.b<w<?>> {
    public Object a() {
      return new w();
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Luxury Logo Maker_ Logo Design-dex2jar.jar!\c2\w.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */