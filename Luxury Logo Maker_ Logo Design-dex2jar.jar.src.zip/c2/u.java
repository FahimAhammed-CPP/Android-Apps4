package c2;

import e4.ay1;
import e4.uy1;
import e4.xp1;
import e4.y60;
import i1.a;
import java.util.Map;
import n3.k0;

public final class u implements ay1 {
  public final Object h;
  
  public final Object i;
  
  public u(int paramInt) {
    xp1 xp1 = new xp1();
    this.h = xp1;
    this.i = new a(xp1, 8);
  }
  
  public Map a(boolean paramBoolean) {
    Object object;
    if (paramBoolean) {
      object = this.i;
    } else {
      object = this.h;
    } 
    return (Map)object;
  }
  
  public uy1 zza() {
    k0 k0 = (k0)this.h;
    y60 y60 = (y60)this.i;
    return k0.z3(k0.j, y60.h, y60.i, y60.j, y60.k).a();
  }
}


/* Location:              C:\soft\dex2jar-2.0\Luxury Logo Maker_ Logo Design-dex2jar.jar!\c\\u.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */