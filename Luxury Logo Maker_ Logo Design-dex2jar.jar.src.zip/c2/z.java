package c2;

import a2.f;
import a2.h;
import a2.l;
import android.support.v4.media.c;
import d2.b;
import java.nio.ByteBuffer;
import java.security.MessageDigest;
import v2.i;
import v2.l;

public final class z implements f {
  public static final i<Class<?>, byte[]> j = new i(50L);
  
  public final b b;
  
  public final f c;
  
  public final f d;
  
  public final int e;
  
  public final int f;
  
  public final Class<?> g;
  
  public final h h;
  
  public final l<?> i;
  
  public z(b paramb, f paramf1, f paramf2, int paramInt1, int paramInt2, l<?> paraml, Class<?> paramClass, h paramh) {
    this.b = paramb;
    this.c = paramf1;
    this.d = paramf2;
    this.e = paramInt1;
    this.f = paramInt2;
    this.i = paraml;
    this.g = paramClass;
    this.h = paramh;
  }
  
  public void a(MessageDigest paramMessageDigest) {
    byte[] arrayOfByte3 = (byte[])this.b.c(8, byte[].class);
    ByteBuffer.wrap(arrayOfByte3).putInt(this.e).putInt(this.f).array();
    this.d.a(paramMessageDigest);
    this.c.a(paramMessageDigest);
    paramMessageDigest.update(arrayOfByte3);
    l<?> l1 = this.i;
    if (l1 != null)
      l1.a(paramMessageDigest); 
    this.h.a(paramMessageDigest);
    i<Class<?>, byte[]> i1 = j;
    byte[] arrayOfByte2 = (byte[])i1.a(this.g);
    byte[] arrayOfByte1 = arrayOfByte2;
    if (arrayOfByte2 == null) {
      arrayOfByte1 = this.g.getName().getBytes(f.a);
      i1.d(this.g, arrayOfByte1);
    } 
    paramMessageDigest.update(arrayOfByte1);
    this.b.d(arrayOfByte3);
  }
  
  public boolean equals(Object paramObject) {
    boolean bool = paramObject instanceof z;
    boolean bool2 = false;
    boolean bool1 = bool2;
    if (bool) {
      paramObject = paramObject;
      bool1 = bool2;
      if (this.f == ((z)paramObject).f) {
        bool1 = bool2;
        if (this.e == ((z)paramObject).e) {
          bool1 = bool2;
          if (l.b(this.i, ((z)paramObject).i)) {
            bool1 = bool2;
            if (this.g.equals(((z)paramObject).g)) {
              bool1 = bool2;
              if (this.c.equals(((z)paramObject).c)) {
                bool1 = bool2;
                if (this.d.equals(((z)paramObject).d)) {
                  bool1 = bool2;
                  if (this.h.equals(((z)paramObject).h))
                    bool1 = true; 
                } 
              } 
            } 
          } 
        } 
      } 
    } 
    return bool1;
  }
  
  public int hashCode() {
    int j = this.c.hashCode();
    int k = ((this.d.hashCode() + j * 31) * 31 + this.e) * 31 + this.f;
    l<?> l1 = this.i;
    j = k;
    if (l1 != null)
      j = k * 31 + l1.hashCode(); 
    k = this.g.hashCode();
    return this.h.hashCode() + (k + j * 31) * 31;
  }
  
  public String toString() {
    StringBuilder stringBuilder = c.a("ResourceCacheKey{sourceKey=");
    stringBuilder.append(this.c);
    stringBuilder.append(", signature=");
    stringBuilder.append(this.d);
    stringBuilder.append(", width=");
    stringBuilder.append(this.e);
    stringBuilder.append(", height=");
    stringBuilder.append(this.f);
    stringBuilder.append(", decodedResourceClass=");
    stringBuilder.append(this.g);
    stringBuilder.append(", transformation='");
    stringBuilder.append(this.i);
    stringBuilder.append('\'');
    stringBuilder.append(", options=");
    stringBuilder.append(this.h);
    stringBuilder.append('}');
    return stringBuilder.toString();
  }
}


/* Location:              C:\soft\dex2jar-2.0\Luxury Logo Maker_ Logo Design-dex2jar.jar!\c2\z.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */