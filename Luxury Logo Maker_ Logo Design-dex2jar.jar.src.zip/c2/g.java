package c2;

import a2.f;
import com.bumptech.glide.load.data.d;

public interface g {
  boolean b();
  
  void cancel();
  
  public static interface a {
    void a();
    
    void d(f param1f, Exception param1Exception, d<?> param1d, a2.a param1a);
    
    void e(f param1f1, Object param1Object, d<?> param1d, a2.a param1a, f param1f2);
  }
}


/* Location:              C:\soft\dex2jar-2.0\Luxury Logo Maker_ Logo Design-dex2jar.jar!\c2\g.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */