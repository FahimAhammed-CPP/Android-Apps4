package c2;

public abstract class l {
  public static final l a = new a();
  
  public static final l b = new b();
  
  public static final l c = new c();
  
  public abstract boolean a();
  
  public abstract boolean b();
  
  public abstract boolean c(a2.a parama);
  
  public abstract boolean d(boolean paramBoolean, a2.a parama, a2.c paramc);
  
  public class a extends l {
    public boolean a() {
      return false;
    }
    
    public boolean b() {
      return false;
    }
    
    public boolean c(a2.a param1a) {
      return false;
    }
    
    public boolean d(boolean param1Boolean, a2.a param1a, a2.c param1c) {
      return false;
    }
  }
  
  public class b extends l {
    public boolean a() {
      return true;
    }
    
    public boolean b() {
      return false;
    }
    
    public boolean c(a2.a param1a) {
      return (param1a != a2.a.j && param1a != a2.a.l);
    }
    
    public boolean d(boolean param1Boolean, a2.a param1a, a2.c param1c) {
      return false;
    }
  }
  
  public class c extends l {
    public boolean a() {
      return true;
    }
    
    public boolean b() {
      return true;
    }
    
    public boolean c(a2.a param1a) {
      return (param1a == a2.a.i);
    }
    
    public boolean d(boolean param1Boolean, a2.a param1a, a2.c param1c) {
      return (((param1Boolean && param1a == a2.a.j) || param1a == a2.a.h) && param1c == a2.c.i);
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Luxury Logo Maker_ Logo Design-dex2jar.jar!\c2\l.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */