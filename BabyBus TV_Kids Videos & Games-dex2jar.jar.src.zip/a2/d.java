package a2;

public class d extends f.a {
  private static f<d> e;
  
  public double c;
  
  public double d;
  
  static {
    f<d> f1 = f.a(64, new d(0.0D, 0.0D));
    e = f1;
    f1.g(0.5F);
  }
  
  private d(double paramDouble1, double paramDouble2) {
    this.c = paramDouble1;
    this.d = paramDouble2;
  }
  
  public static d b(double paramDouble1, double paramDouble2) {
    d d1 = e.b();
    d1.c = paramDouble1;
    d1.d = paramDouble2;
    return d1;
  }
  
  public static void c(d paramd) {
    e.c(paramd);
  }
  
  protected f.a a() {
    return new d(0.0D, 0.0D);
  }
  
  public String toString() {
    StringBuilder stringBuilder = new StringBuilder();
    stringBuilder.append("MPPointD, x: ");
    stringBuilder.append(this.c);
    stringBuilder.append(", y: ");
    stringBuilder.append(this.d);
    return stringBuilder.toString();
  }
}


/* Location:              C:\soft\dex2jar-2.0\BabyBus TV_Kids Videos & Games-dex2jar.jar!\a2\d.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */