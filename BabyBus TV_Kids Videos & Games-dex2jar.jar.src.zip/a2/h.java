package a2;

public class h extends g {
  public h(j paramj) {
    super(paramj);
  }
  
  public void l(boolean paramBoolean) {
    this.b.reset();
    if (!paramBoolean) {
      this.b.postTranslate(this.c.G(), this.c.l() - this.c.F());
      return;
    } 
    this.b.setTranslate(-(this.c.m() - this.c.H()), this.c.l() - this.c.F());
    this.b.postScale(-1.0F, 1.0F);
  }
}


/* Location:              C:\soft\dex2jar-2.0\BabyBus TV_Kids Videos & Games-dex2jar.jar!\a2\h.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */