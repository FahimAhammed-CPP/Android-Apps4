package a2;

import android.os.Parcel;
import android.os.Parcelable;

public class e extends f.a {
  private static f<e> e;
  
  public static final Parcelable.Creator<e> f = new a();
  
  public float c;
  
  public float d;
  
  public e() {}
  
  public e(float paramFloat1, float paramFloat2) {
    this.c = paramFloat1;
    this.d = paramFloat2;
  }
  
  public static e b() {
    return e.b();
  }
  
  public static e c(float paramFloat1, float paramFloat2) {
    e e1 = e.b();
    e1.c = paramFloat1;
    e1.d = paramFloat2;
    return e1;
  }
  
  public static e d(e parame) {
    e e1 = e.b();
    e1.c = parame.c;
    e1.d = parame.d;
    return e1;
  }
  
  public static void f(e parame) {
    e.c(parame);
  }
  
  protected f.a a() {
    return new e(0.0F, 0.0F);
  }
  
  public void e(Parcel paramParcel) {
    this.c = paramParcel.readFloat();
    this.d = paramParcel.readFloat();
  }
  
  static {
    f<e> f1 = f.a(32, new e(0.0F, 0.0F));
    e = f1;
    f1.g(0.5F);
  }
  
  static final class a implements Parcelable.Creator<e> {
    public e a(Parcel param1Parcel) {
      e e = new e(0.0F, 0.0F);
      e.e(param1Parcel);
      return e;
    }
    
    public e[] b(int param1Int) {
      return new e[param1Int];
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\BabyBus TV_Kids Videos & Games-dex2jar.jar!\a2\e.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */