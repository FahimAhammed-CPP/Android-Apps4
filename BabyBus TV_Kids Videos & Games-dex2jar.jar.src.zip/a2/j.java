package a2;

import android.graphics.Matrix;
import android.graphics.RectF;
import android.view.View;

public class j {
  protected final Matrix a = new Matrix();
  
  protected RectF b = new RectF();
  
  protected float c = 0.0F;
  
  protected float d = 0.0F;
  
  private float e = 1.0F;
  
  private float f = Float.MAX_VALUE;
  
  private float g = 1.0F;
  
  private float h = Float.MAX_VALUE;
  
  private float i = 1.0F;
  
  private float j = 1.0F;
  
  private float k = 0.0F;
  
  private float l = 0.0F;
  
  private float m = 0.0F;
  
  private float n = 0.0F;
  
  protected float[] o = new float[9];
  
  protected Matrix p = new Matrix();
  
  protected final float[] q = new float[9];
  
  public boolean A(float paramFloat) {
    paramFloat = (int)(paramFloat * 100.0F) / 100.0F;
    return (this.b.right >= paramFloat - 1.0F);
  }
  
  public boolean B(float paramFloat) {
    return (this.b.top <= paramFloat);
  }
  
  public boolean C(float paramFloat) {
    return (z(paramFloat) && A(paramFloat));
  }
  
  public boolean D(float paramFloat) {
    return (B(paramFloat) && y(paramFloat));
  }
  
  public void E(Matrix paramMatrix, RectF paramRectF) {
    paramMatrix.getValues(this.q);
    float[] arrayOfFloat2 = this.q;
    float f3 = arrayOfFloat2[2];
    float f1 = arrayOfFloat2[0];
    float f4 = arrayOfFloat2[5];
    float f2 = arrayOfFloat2[4];
    this.i = Math.min(Math.max(this.g, f1), this.h);
    this.j = Math.min(Math.max(this.e, f2), this.f);
    f1 = 0.0F;
    if (paramRectF != null) {
      f1 = paramRectF.width();
      f2 = paramRectF.height();
    } else {
      f2 = 0.0F;
    } 
    this.k = Math.min(Math.max(f3, -f1 * (this.i - 1.0F) - this.m), this.m);
    f1 = Math.max(Math.min(f4, f2 * (this.j - 1.0F) + this.n), -this.n);
    this.l = f1;
    float[] arrayOfFloat1 = this.q;
    arrayOfFloat1[2] = this.k;
    arrayOfFloat1[0] = this.i;
    arrayOfFloat1[5] = f1;
    arrayOfFloat1[4] = this.j;
    paramMatrix.setValues(arrayOfFloat1);
  }
  
  public float F() {
    return this.d - this.b.bottom;
  }
  
  public float G() {
    return this.b.left;
  }
  
  public float H() {
    return this.c - this.b.right;
  }
  
  public float I() {
    return this.b.top;
  }
  
  public Matrix J(Matrix paramMatrix, View paramView, boolean paramBoolean) {
    this.a.set(paramMatrix);
    E(this.a, this.b);
    if (paramBoolean)
      paramView.invalidate(); 
    paramMatrix.set(this.a);
    return paramMatrix;
  }
  
  public void K(float paramFloat1, float paramFloat2, float paramFloat3, float paramFloat4) {
    this.b.set(paramFloat1, paramFloat2, this.c - paramFloat3, this.d - paramFloat4);
  }
  
  public void L(float paramFloat1, float paramFloat2) {
    float f1 = G();
    float f2 = I();
    float f3 = H();
    float f4 = F();
    this.d = paramFloat2;
    this.c = paramFloat1;
    K(f1, f2, f3, f4);
  }
  
  public void M(float paramFloat) {
    this.m = i.e(paramFloat);
  }
  
  public void N(float paramFloat) {
    this.n = i.e(paramFloat);
  }
  
  public void O(float paramFloat) {
    float f = paramFloat;
    if (paramFloat == 0.0F)
      f = Float.MAX_VALUE; 
    this.h = f;
    E(this.a, this.b);
  }
  
  public void P(float paramFloat) {
    float f = paramFloat;
    if (paramFloat == 0.0F)
      f = Float.MAX_VALUE; 
    this.f = f;
    E(this.a, this.b);
  }
  
  public void Q(float paramFloat) {
    float f = paramFloat;
    if (paramFloat < 1.0F)
      f = 1.0F; 
    this.g = f;
    E(this.a, this.b);
  }
  
  public void R(float paramFloat) {
    float f = paramFloat;
    if (paramFloat < 1.0F)
      f = 1.0F; 
    this.e = f;
    E(this.a, this.b);
  }
  
  public void S(float paramFloat1, float paramFloat2, float paramFloat3, float paramFloat4, Matrix paramMatrix) {
    paramMatrix.reset();
    paramMatrix.set(this.a);
    paramMatrix.postScale(paramFloat1, paramFloat2, paramFloat3, paramFloat4);
  }
  
  public boolean a() {
    return (this.i < this.h);
  }
  
  public boolean b() {
    return (this.j < this.f);
  }
  
  public boolean c() {
    return (this.i > this.g);
  }
  
  public boolean d() {
    return (this.j > this.e);
  }
  
  public void e(float[] paramArrayOffloat, View paramView) {
    Matrix matrix = this.p;
    matrix.reset();
    matrix.set(this.a);
    float f1 = paramArrayOffloat[0];
    float f2 = G();
    float f3 = paramArrayOffloat[1];
    float f4 = I();
    matrix.postTranslate(-(f1 - f2), -(f3 - f4));
    J(matrix, paramView, true);
  }
  
  public float f() {
    return this.b.bottom;
  }
  
  public float g() {
    return this.b.height();
  }
  
  public float h() {
    return this.b.left;
  }
  
  public float i() {
    return this.b.right;
  }
  
  public float j() {
    return this.b.top;
  }
  
  public float k() {
    return this.b.width();
  }
  
  public float l() {
    return this.d;
  }
  
  public float m() {
    return this.c;
  }
  
  public e n() {
    return e.c(this.b.centerX(), this.b.centerY());
  }
  
  public RectF o() {
    return this.b;
  }
  
  public Matrix p() {
    return this.a;
  }
  
  public float q() {
    return this.i;
  }
  
  public float r() {
    return this.j;
  }
  
  public float s() {
    return Math.min(this.b.width(), this.b.height());
  }
  
  public boolean t() {
    return (this.m <= 0.0F && this.n <= 0.0F);
  }
  
  public boolean u() {
    return (v() && w());
  }
  
  public boolean v() {
    float f1 = this.i;
    float f2 = this.g;
    return (f1 <= f2 && f2 <= 1.0F);
  }
  
  public boolean w() {
    float f1 = this.j;
    float f2 = this.e;
    return (f1 <= f2 && f2 <= 1.0F);
  }
  
  public boolean x(float paramFloat1, float paramFloat2) {
    return (C(paramFloat1) && D(paramFloat2));
  }
  
  public boolean y(float paramFloat) {
    paramFloat = (int)(paramFloat * 100.0F) / 100.0F;
    return (this.b.bottom >= paramFloat);
  }
  
  public boolean z(float paramFloat) {
    return (this.b.left <= paramFloat + 1.0F);
  }
}


/* Location:              C:\soft\dex2jar-2.0\BabyBus TV_Kids Videos & Games-dex2jar.jar!\a2\j.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */