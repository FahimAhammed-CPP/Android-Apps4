package a2;

import android.annotation.SuppressLint;
import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.Rect;
import android.graphics.drawable.Drawable;
import android.os.Build;
import android.util.DisplayMetrics;
import android.util.Log;
import android.view.MotionEvent;
import android.view.VelocityTracker;
import android.view.View;
import android.view.ViewConfiguration;
import s1.b;
import s1.d;

public abstract class i {
  private static DisplayMetrics a;
  
  private static int b = 50;
  
  private static int c = 8000;
  
  public static final double d = Double.longBitsToDouble(1L);
  
  public static final float e = Float.intBitsToFloat(1);
  
  private static Rect f = new Rect();
  
  private static Paint.FontMetrics g = new Paint.FontMetrics();
  
  private static Rect h = new Rect();
  
  private static final int[] i = new int[] { 1, 10, 100, 1000, 10000, 100000, 1000000, 10000000, 100000000, 1000000000 };
  
  private static d j = h();
  
  private static Rect k = new Rect();
  
  private static Rect l = new Rect();
  
  private static Paint.FontMetrics m = new Paint.FontMetrics();
  
  public static int a(Paint paramPaint, String paramString) {
    Rect rect = f;
    rect.set(0, 0, 0, 0);
    paramPaint.getTextBounds(paramString, 0, paramString.length(), rect);
    return rect.height();
  }
  
  public static b b(Paint paramPaint, String paramString) {
    b b = b.b(0.0F, 0.0F);
    c(paramPaint, paramString, b);
    return b;
  }
  
  public static void c(Paint paramPaint, String paramString, b paramb) {
    Rect rect = h;
    rect.set(0, 0, 0, 0);
    paramPaint.getTextBounds(paramString, 0, paramString.length(), rect);
    paramb.c = rect.width();
    paramb.d = rect.height();
  }
  
  public static int d(Paint paramPaint, String paramString) {
    return (int)paramPaint.measureText(paramString);
  }
  
  public static float e(float paramFloat) {
    DisplayMetrics displayMetrics = a;
    if (displayMetrics == null) {
      Log.e("MPChartLib-Utils", "Utils NOT INITIALIZED. You need to call Utils.init(...) at least once before calling Utils.convertDpToPixel(...). Otherwise conversion does not take place.");
      return paramFloat;
    } 
    return paramFloat * displayMetrics.density;
  }
  
  public static void f(Canvas paramCanvas, Drawable paramDrawable, int paramInt1, int paramInt2, int paramInt3, int paramInt4) {
    e e = e.b();
    e.c = (paramInt1 - paramInt3 / 2);
    e.d = (paramInt2 - paramInt4 / 2);
    paramDrawable.copyBounds(k);
    Rect rect = k;
    paramInt1 = rect.left;
    paramInt2 = rect.top;
    paramDrawable.setBounds(paramInt1, paramInt2, paramInt1 + paramInt3, paramInt3 + paramInt2);
    paramInt1 = paramCanvas.save();
    paramCanvas.translate(e.c, e.d);
    paramDrawable.draw(paramCanvas);
    paramCanvas.restoreToCount(paramInt1);
  }
  
  public static void g(Canvas paramCanvas, String paramString, float paramFloat1, float paramFloat2, Paint paramPaint, e parame, float paramFloat3) {
    // Byte code:
    //   0: aload #4
    //   2: getstatic a2/i.m : Landroid/graphics/Paint$FontMetrics;
    //   5: invokevirtual getFontMetrics : (Landroid/graphics/Paint$FontMetrics;)F
    //   8: fstore #11
    //   10: aload #4
    //   12: aload_1
    //   13: iconst_0
    //   14: aload_1
    //   15: invokevirtual length : ()I
    //   18: getstatic a2/i.l : Landroid/graphics/Rect;
    //   21: invokevirtual getTextBounds : (Ljava/lang/String;IILandroid/graphics/Rect;)V
    //   24: fconst_0
    //   25: getstatic a2/i.l : Landroid/graphics/Rect;
    //   28: getfield left : I
    //   31: i2f
    //   32: fsub
    //   33: fstore #10
    //   35: getstatic a2/i.m : Landroid/graphics/Paint$FontMetrics;
    //   38: getfield ascent : F
    //   41: fneg
    //   42: fconst_0
    //   43: fadd
    //   44: fstore #9
    //   46: aload #4
    //   48: invokevirtual getTextAlign : ()Landroid/graphics/Paint$Align;
    //   51: astore #13
    //   53: aload #4
    //   55: getstatic android/graphics/Paint$Align.LEFT : Landroid/graphics/Paint$Align;
    //   58: invokevirtual setTextAlign : (Landroid/graphics/Paint$Align;)V
    //   61: fload #6
    //   63: fconst_0
    //   64: fcmpl
    //   65: ifeq -> 211
    //   68: getstatic a2/i.l : Landroid/graphics/Rect;
    //   71: invokevirtual width : ()I
    //   74: i2f
    //   75: fstore #12
    //   77: aload #5
    //   79: getfield c : F
    //   82: ldc 0.5
    //   84: fcmpl
    //   85: ifne -> 105
    //   88: fload_2
    //   89: fstore #8
    //   91: fload_3
    //   92: fstore #7
    //   94: aload #5
    //   96: getfield d : F
    //   99: ldc 0.5
    //   101: fcmpl
    //   102: ifeq -> 162
    //   105: getstatic a2/i.l : Landroid/graphics/Rect;
    //   108: invokevirtual width : ()I
    //   111: i2f
    //   112: fload #11
    //   114: fload #6
    //   116: invokestatic t : (FFF)La2/b;
    //   119: astore #14
    //   121: fload_2
    //   122: aload #14
    //   124: getfield c : F
    //   127: aload #5
    //   129: getfield c : F
    //   132: ldc 0.5
    //   134: fsub
    //   135: fmul
    //   136: fsub
    //   137: fstore #8
    //   139: fload_3
    //   140: aload #14
    //   142: getfield d : F
    //   145: aload #5
    //   147: getfield d : F
    //   150: ldc 0.5
    //   152: fsub
    //   153: fmul
    //   154: fsub
    //   155: fstore #7
    //   157: aload #14
    //   159: invokestatic c : (La2/b;)V
    //   162: aload_0
    //   163: invokevirtual save : ()I
    //   166: pop
    //   167: aload_0
    //   168: fload #8
    //   170: fload #7
    //   172: invokevirtual translate : (FF)V
    //   175: aload_0
    //   176: fload #6
    //   178: invokevirtual rotate : (F)V
    //   181: aload_0
    //   182: aload_1
    //   183: fload #10
    //   185: fload #12
    //   187: ldc 0.5
    //   189: fmul
    //   190: fsub
    //   191: fload #9
    //   193: fload #11
    //   195: ldc 0.5
    //   197: fmul
    //   198: fsub
    //   199: aload #4
    //   201: invokevirtual drawText : (Ljava/lang/String;FFLandroid/graphics/Paint;)V
    //   204: aload_0
    //   205: invokevirtual restore : ()V
    //   208: goto -> 285
    //   211: aload #5
    //   213: getfield c : F
    //   216: fconst_0
    //   217: fcmpl
    //   218: ifne -> 239
    //   221: fload #10
    //   223: fstore #7
    //   225: fload #9
    //   227: fstore #6
    //   229: aload #5
    //   231: getfield d : F
    //   234: fconst_0
    //   235: fcmpl
    //   236: ifeq -> 270
    //   239: fload #10
    //   241: getstatic a2/i.l : Landroid/graphics/Rect;
    //   244: invokevirtual width : ()I
    //   247: i2f
    //   248: aload #5
    //   250: getfield c : F
    //   253: fmul
    //   254: fsub
    //   255: fstore #7
    //   257: fload #9
    //   259: fload #11
    //   261: aload #5
    //   263: getfield d : F
    //   266: fmul
    //   267: fsub
    //   268: fstore #6
    //   270: aload_0
    //   271: aload_1
    //   272: fload #7
    //   274: fload_2
    //   275: fadd
    //   276: fload #6
    //   278: fload_3
    //   279: fadd
    //   280: aload #4
    //   282: invokevirtual drawText : (Ljava/lang/String;FFLandroid/graphics/Paint;)V
    //   285: aload #4
    //   287: aload #13
    //   289: invokevirtual setTextAlign : (Landroid/graphics/Paint$Align;)V
    //   292: return
  }
  
  private static d h() {
    return (d)new b(1);
  }
  
  public static int i(float paramFloat) {
    paramFloat = y(paramFloat);
    return Float.isInfinite(paramFloat) ? 0 : ((int)Math.ceil(-Math.log10(paramFloat)) + 2);
  }
  
  public static d j() {
    return j;
  }
  
  public static float k(Paint paramPaint) {
    return l(paramPaint, g);
  }
  
  public static float l(Paint paramPaint, Paint.FontMetrics paramFontMetrics) {
    paramPaint.getFontMetrics(paramFontMetrics);
    return paramFontMetrics.descent - paramFontMetrics.ascent;
  }
  
  public static float m(Paint paramPaint) {
    return n(paramPaint, g);
  }
  
  public static float n(Paint paramPaint, Paint.FontMetrics paramFontMetrics) {
    paramPaint.getFontMetrics(paramFontMetrics);
    return paramFontMetrics.ascent - paramFontMetrics.top + paramFontMetrics.bottom;
  }
  
  public static int o() {
    return c;
  }
  
  public static int p() {
    return b;
  }
  
  public static float q(float paramFloat) {
    while (paramFloat < 0.0F)
      paramFloat += 360.0F; 
    return paramFloat % 360.0F;
  }
  
  public static void r(e parame1, float paramFloat1, float paramFloat2, e parame2) {
    double d1 = parame1.c;
    double d2 = paramFloat1;
    double d3 = paramFloat2;
    parame2.c = (float)(d1 + Math.cos(Math.toRadians(d3)) * d2);
    parame2.d = (float)(parame1.d + d2 * Math.sin(Math.toRadians(d3)));
  }
  
  public static int s() {
    return Build.VERSION.SDK_INT;
  }
  
  public static b t(float paramFloat1, float paramFloat2, float paramFloat3) {
    return u(paramFloat1, paramFloat2, paramFloat3 * 0.017453292F);
  }
  
  public static b u(float paramFloat1, float paramFloat2, float paramFloat3) {
    double d1 = paramFloat3;
    return b.b(Math.abs((float)Math.cos(d1) * paramFloat1) + Math.abs((float)Math.sin(d1) * paramFloat2), Math.abs(paramFloat1 * (float)Math.sin(d1)) + Math.abs(paramFloat2 * (float)Math.cos(d1)));
  }
  
  public static void v(Context paramContext) {
    if (paramContext == null) {
      b = ViewConfiguration.getMinimumFlingVelocity();
      c = ViewConfiguration.getMaximumFlingVelocity();
      Log.e("MPChartLib-Utils", "Utils.init(...) PROVIDED CONTEXT OBJECT IS NULL");
      return;
    } 
    ViewConfiguration viewConfiguration = ViewConfiguration.get(paramContext);
    b = viewConfiguration.getScaledMinimumFlingVelocity();
    c = viewConfiguration.getScaledMaximumFlingVelocity();
    a = paramContext.getResources().getDisplayMetrics();
  }
  
  public static double w(double paramDouble) {
    long l1;
    if (paramDouble == Double.POSITIVE_INFINITY)
      return paramDouble; 
    paramDouble += 0.0D;
    long l2 = Double.doubleToRawLongBits(paramDouble);
    if (paramDouble >= 0.0D) {
      l1 = 1L;
    } else {
      l1 = -1L;
    } 
    return Double.longBitsToDouble(l2 + l1);
  }
  
  @SuppressLint({"NewApi"})
  public static void x(View paramView) {
    paramView.postInvalidateOnAnimation();
  }
  
  public static float y(double paramDouble) {
    double d1;
    if (Double.isInfinite(paramDouble) || Double.isNaN(paramDouble) || paramDouble == 0.0D)
      return 0.0F; 
    if (paramDouble < 0.0D) {
      d1 = -paramDouble;
    } else {
      d1 = paramDouble;
    } 
    float f = (float)Math.pow(10.0D, (1 - (int)(float)Math.ceil((float)Math.log10(d1))));
    return (float)Math.round(paramDouble * f) / f;
  }
  
  public static void z(MotionEvent paramMotionEvent, VelocityTracker paramVelocityTracker) {
    paramVelocityTracker.computeCurrentVelocity(1000, c);
    int k = paramMotionEvent.getActionIndex();
    int j = paramMotionEvent.getPointerId(k);
    float f1 = paramVelocityTracker.getXVelocity(j);
    float f2 = paramVelocityTracker.getYVelocity(j);
    int m = paramMotionEvent.getPointerCount();
    for (j = 0; j < m; j++) {
      if (j != k) {
        int n = paramMotionEvent.getPointerId(j);
        if (paramVelocityTracker.getXVelocity(n) * f1 + paramVelocityTracker.getYVelocity(n) * f2 < 0.0F) {
          paramVelocityTracker.clear();
          return;
        } 
      } 
    } 
  }
}


/* Location:              C:\soft\dex2jar-2.0\BabyBus TV_Kids Videos & Games-dex2jar.jar!\a2\i.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */