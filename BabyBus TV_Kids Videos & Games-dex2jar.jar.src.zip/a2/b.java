package a2;

public final class b extends f.a {
  private static f<b> e;
  
  public float c;
  
  public float d;
  
  static {
    f<b> f1 = f.a(256, new b(0.0F, 0.0F));
    e = f1;
    f1.g(0.5F);
  }
  
  public b() {}
  
  public b(float paramFloat1, float paramFloat2) {
    this.c = paramFloat1;
    this.d = paramFloat2;
  }
  
  public static b b(float paramFloat1, float paramFloat2) {
    b b1 = e.b();
    b1.c = paramFloat1;
    b1.d = paramFloat2;
    return b1;
  }
  
  public static void c(b paramb) {
    e.c(paramb);
  }
  
  protected f.a a() {
    return new b(0.0F, 0.0F);
  }
  
  public boolean equals(Object paramObject) {
    boolean bool2 = false;
    if (paramObject == null)
      return false; 
    if (this == paramObject)
      return true; 
    boolean bool1 = bool2;
    if (paramObject instanceof b) {
      paramObject = paramObject;
      bool1 = bool2;
      if (this.c == ((b)paramObject).c) {
        bool1 = bool2;
        if (this.d == ((b)paramObject).d)
          bool1 = true; 
      } 
    } 
    return bool1;
  }
  
  public int hashCode() {
    return Float.floatToIntBits(this.c) ^ Float.floatToIntBits(this.d);
  }
  
  public String toString() {
    StringBuilder stringBuilder = new StringBuilder();
    stringBuilder.append(this.c);
    stringBuilder.append("x");
    stringBuilder.append(this.d);
    return stringBuilder.toString();
  }
}


/* Location:              C:\soft\dex2jar-2.0\BabyBus TV_Kids Videos & Games-dex2jar.jar!\a2\b.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */