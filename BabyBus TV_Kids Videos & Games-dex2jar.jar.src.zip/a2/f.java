package a2;

public class f<T extends f.a> {
  private static int g;
  
  private int a;
  
  private int b;
  
  private Object[] c;
  
  private int d;
  
  private T e;
  
  private float f;
  
  private f(int paramInt, T paramT) {
    if (paramInt > 0) {
      this.b = paramInt;
      this.c = new Object[paramInt];
      this.d = 0;
      this.e = paramT;
      this.f = 1.0F;
      d();
      return;
    } 
    throw new IllegalArgumentException("Object Pool must be instantiated with a capacity greater than 0!");
  }
  
  public static f a(int paramInt, a parama) {
    // Byte code:
    //   0: ldc a2/f
    //   2: monitorenter
    //   3: new a2/f
    //   6: dup
    //   7: iload_0
    //   8: aload_1
    //   9: invokespecial <init> : (ILa2/f$a;)V
    //   12: astore_1
    //   13: getstatic a2/f.g : I
    //   16: istore_0
    //   17: aload_1
    //   18: iload_0
    //   19: putfield a : I
    //   22: iload_0
    //   23: iconst_1
    //   24: iadd
    //   25: putstatic a2/f.g : I
    //   28: ldc a2/f
    //   30: monitorexit
    //   31: aload_1
    //   32: areturn
    //   33: astore_1
    //   34: ldc a2/f
    //   36: monitorexit
    //   37: aload_1
    //   38: athrow
    // Exception table:
    //   from	to	target	type
    //   3	28	33	finally
  }
  
  private void d() {
    e(this.f);
  }
  
  private void e(float paramFloat) {
    int i = this.b;
    int j = (int)(i * paramFloat);
    if (j < 1) {
      i = 1;
    } else if (j <= i) {
      i = j;
    } 
    for (j = 0; j < i; j++)
      this.c[j] = this.e.a(); 
    this.d = i - 1;
  }
  
  private void f() {
    int j = this.b;
    int i = j * 2;
    this.b = i;
    Object[] arrayOfObject = new Object[i];
    for (i = 0; i < j; i++)
      arrayOfObject[i] = this.c[i]; 
    this.c = arrayOfObject;
  }
  
  public T b() {
    // Byte code:
    //   0: aload_0
    //   1: monitorenter
    //   2: aload_0
    //   3: getfield d : I
    //   6: iconst_m1
    //   7: if_icmpne -> 23
    //   10: aload_0
    //   11: getfield f : F
    //   14: fconst_0
    //   15: fcmpl
    //   16: ifle -> 23
    //   19: aload_0
    //   20: invokespecial d : ()V
    //   23: aload_0
    //   24: getfield c : [Ljava/lang/Object;
    //   27: astore_2
    //   28: aload_0
    //   29: getfield d : I
    //   32: istore_1
    //   33: aload_2
    //   34: iload_1
    //   35: aaload
    //   36: checkcast a2/f$a
    //   39: astore_2
    //   40: aload_2
    //   41: getstatic a2/f$a.b : I
    //   44: putfield a : I
    //   47: aload_0
    //   48: iload_1
    //   49: iconst_1
    //   50: isub
    //   51: putfield d : I
    //   54: aload_0
    //   55: monitorexit
    //   56: aload_2
    //   57: areturn
    //   58: astore_2
    //   59: aload_0
    //   60: monitorexit
    //   61: aload_2
    //   62: athrow
    // Exception table:
    //   from	to	target	type
    //   2	23	58	finally
    //   23	54	58	finally
  }
  
  public void c(T paramT) {
    // Byte code:
    //   0: aload_0
    //   1: monitorenter
    //   2: aload_1
    //   3: getfield a : I
    //   6: istore_2
    //   7: iload_2
    //   8: getstatic a2/f$a.b : I
    //   11: if_icmpeq -> 75
    //   14: iload_2
    //   15: aload_0
    //   16: getfield a : I
    //   19: if_icmpne -> 32
    //   22: new java/lang/IllegalArgumentException
    //   25: dup
    //   26: ldc 'The object passed is already stored in this pool!'
    //   28: invokespecial <init> : (Ljava/lang/String;)V
    //   31: athrow
    //   32: new java/lang/StringBuilder
    //   35: dup
    //   36: invokespecial <init> : ()V
    //   39: astore_3
    //   40: aload_3
    //   41: ldc 'The object to recycle already belongs to poolId '
    //   43: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   46: pop
    //   47: aload_3
    //   48: aload_1
    //   49: getfield a : I
    //   52: invokevirtual append : (I)Ljava/lang/StringBuilder;
    //   55: pop
    //   56: aload_3
    //   57: ldc '.  Object cannot belong to two different pool instances simultaneously!'
    //   59: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   62: pop
    //   63: new java/lang/IllegalArgumentException
    //   66: dup
    //   67: aload_3
    //   68: invokevirtual toString : ()Ljava/lang/String;
    //   71: invokespecial <init> : (Ljava/lang/String;)V
    //   74: athrow
    //   75: aload_0
    //   76: getfield d : I
    //   79: iconst_1
    //   80: iadd
    //   81: istore_2
    //   82: aload_0
    //   83: iload_2
    //   84: putfield d : I
    //   87: iload_2
    //   88: aload_0
    //   89: getfield c : [Ljava/lang/Object;
    //   92: arraylength
    //   93: if_icmplt -> 100
    //   96: aload_0
    //   97: invokespecial f : ()V
    //   100: aload_1
    //   101: aload_0
    //   102: getfield a : I
    //   105: putfield a : I
    //   108: aload_0
    //   109: getfield c : [Ljava/lang/Object;
    //   112: aload_0
    //   113: getfield d : I
    //   116: aload_1
    //   117: aastore
    //   118: aload_0
    //   119: monitorexit
    //   120: return
    //   121: astore_1
    //   122: aload_0
    //   123: monitorexit
    //   124: aload_1
    //   125: athrow
    // Exception table:
    //   from	to	target	type
    //   2	32	121	finally
    //   32	75	121	finally
    //   75	100	121	finally
    //   100	118	121	finally
  }
  
  public void g(float paramFloat) {
    float f1;
    if (paramFloat > 1.0F) {
      f1 = 1.0F;
    } else {
      f1 = paramFloat;
      if (paramFloat < 0.0F)
        f1 = 0.0F; 
    } 
    this.f = f1;
  }
  
  public static abstract class a {
    public static int b = -1;
    
    int a = b;
    
    protected abstract a a();
  }
}


/* Location:              C:\soft\dex2jar-2.0\BabyBus TV_Kids Videos & Games-dex2jar.jar!\a2\f.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */