package a0;

import androidx.annotation.NonNull;
import com.bumptech.glide.load.engine.v;
import java.io.File;
import java.io.IOException;
import r.i;
import r.k;

public class a implements k<File, File> {
  public v<File> a(@NonNull File paramFile, int paramInt1, int paramInt2, @NonNull i parami) {
    return (v<File>)new b(paramFile);
  }
  
  public boolean b(@NonNull File paramFile, @NonNull i parami) {
    return true;
  }
}


/* Location:              C:\soft\dex2jar-2.0\BabyBus TV_Kids Videos & Games-dex2jar.jar!\a0\a.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */