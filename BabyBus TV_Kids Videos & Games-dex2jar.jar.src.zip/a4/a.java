package a4;

final class a {}


/* Location:              C:\soft\dex2jar-2.0\BabyBus TV_Kids Videos & Games-dex2jar.jar!\a4\a.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */