package a4;

import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.text.Spannable;
import android.text.SpannableStringBuilder;
import android.util.Base64;
import android.util.Pair;
import androidx.annotation.Nullable;
import com.google.android.exoplayer2.util.a;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.TreeMap;
import java.util.TreeSet;
import t3.a;

final class d {
  @Nullable
  public final String a;
  
  @Nullable
  public final String b;
  
  public final boolean c;
  
  public final long d;
  
  public final long e;
  
  @Nullable
  public final g f;
  
  @Nullable
  private final String[] g;
  
  public final String h;
  
  @Nullable
  public final String i;
  
  @Nullable
  public final d j;
  
  private final HashMap<String, Integer> k;
  
  private final HashMap<String, Integer> l;
  
  private List<d> m;
  
  private d(@Nullable String paramString1, @Nullable String paramString2, long paramLong1, long paramLong2, @Nullable g paramg, @Nullable String[] paramArrayOfString, String paramString3, @Nullable String paramString4, @Nullable d paramd) {
    boolean bool;
    this.a = paramString1;
    this.b = paramString2;
    this.i = paramString4;
    this.f = paramg;
    this.g = paramArrayOfString;
    if (paramString2 != null) {
      bool = true;
    } else {
      bool = false;
    } 
    this.c = bool;
    this.d = paramLong1;
    this.e = paramLong2;
    this.h = (String)a.e(paramString3);
    this.j = paramd;
    this.k = new HashMap<String, Integer>();
    this.l = new HashMap<String, Integer>();
  }
  
  private void b(Map<String, g> paramMap, a.b paramb, int paramInt1, int paramInt2, int paramInt3) {
    g g1 = f.f(this.f, this.g, paramMap);
    SpannableStringBuilder spannableStringBuilder2 = (SpannableStringBuilder)paramb.e();
    SpannableStringBuilder spannableStringBuilder1 = spannableStringBuilder2;
    if (spannableStringBuilder2 == null) {
      spannableStringBuilder1 = new SpannableStringBuilder();
      paramb.o((CharSequence)spannableStringBuilder1);
    } 
    if (g1 != null) {
      f.a((Spannable)spannableStringBuilder1, paramInt1, paramInt2, g1, this.j, paramMap, paramInt3);
      if ("p".equals(this.a)) {
        if (g1.k() != Float.MAX_VALUE)
          paramb.m(g1.k() * -90.0F / 100.0F); 
        if (g1.m() != null)
          paramb.p(g1.m()); 
        if (g1.h() != null)
          paramb.j(g1.h()); 
      } 
    } 
  }
  
  public static d c(@Nullable String paramString1, long paramLong1, long paramLong2, @Nullable g paramg, @Nullable String[] paramArrayOfString, String paramString2, @Nullable String paramString3, @Nullable d paramd) {
    return new d(paramString1, null, paramLong1, paramLong2, paramg, paramArrayOfString, paramString2, paramString3, paramd);
  }
  
  public static d d(String paramString) {
    return new d(null, f.b(paramString), -9223372036854775807L, -9223372036854775807L, null, null, "", null, null);
  }
  
  private static void e(SpannableStringBuilder paramSpannableStringBuilder) {
    null = paramSpannableStringBuilder.length();
    boolean bool = false;
    for (a a : (a[])paramSpannableStringBuilder.getSpans(0, null, a.class))
      paramSpannableStringBuilder.replace(paramSpannableStringBuilder.getSpanStart(a), paramSpannableStringBuilder.getSpanEnd(a), ""); 
    int i;
    for (i = 0; i < paramSpannableStringBuilder.length(); i++) {
      if (paramSpannableStringBuilder.charAt(i) == ' ') {
        int k = i + 1;
        int j;
        for (j = k; j < paramSpannableStringBuilder.length() && paramSpannableStringBuilder.charAt(j) == ' '; j++);
        j -= k;
        if (j > 0)
          paramSpannableStringBuilder.delete(i, j + i); 
      } 
    } 
    if (paramSpannableStringBuilder.length() > 0 && paramSpannableStringBuilder.charAt(0) == ' ')
      paramSpannableStringBuilder.delete(0, 1); 
    for (i = 0; i < paramSpannableStringBuilder.length() - 1; i++) {
      if (paramSpannableStringBuilder.charAt(i) == '\n') {
        int j = i + 1;
        if (paramSpannableStringBuilder.charAt(j) == ' ')
          paramSpannableStringBuilder.delete(j, i + 2); 
      } 
    } 
    i = bool;
    if (paramSpannableStringBuilder.length() > 0) {
      i = bool;
      if (paramSpannableStringBuilder.charAt(paramSpannableStringBuilder.length() - 1) == ' ') {
        paramSpannableStringBuilder.delete(paramSpannableStringBuilder.length() - 1, paramSpannableStringBuilder.length());
        i = bool;
      } 
    } 
    while (i < paramSpannableStringBuilder.length() - 1) {
      if (paramSpannableStringBuilder.charAt(i) == ' ') {
        int j = i + 1;
        if (paramSpannableStringBuilder.charAt(j) == '\n')
          paramSpannableStringBuilder.delete(i, j); 
      } 
      i++;
    } 
    if (paramSpannableStringBuilder.length() > 0 && paramSpannableStringBuilder.charAt(paramSpannableStringBuilder.length() - 1) == '\n')
      paramSpannableStringBuilder.delete(paramSpannableStringBuilder.length() - 1, paramSpannableStringBuilder.length()); 
  }
  
  private void i(TreeSet<Long> paramTreeSet, boolean paramBoolean) {
    boolean bool2 = "p".equals(this.a);
    boolean bool1 = "div".equals(this.a);
    if (paramBoolean || bool2 || (bool1 && this.i != null)) {
      long l = this.d;
      if (l != -9223372036854775807L)
        paramTreeSet.add(Long.valueOf(l)); 
      l = this.e;
      if (l != -9223372036854775807L)
        paramTreeSet.add(Long.valueOf(l)); 
    } 
    if (this.m == null)
      return; 
    for (int i = 0; i < this.m.size(); i++) {
      d d1 = this.m.get(i);
      if (paramBoolean || bool2) {
        bool1 = true;
      } else {
        bool1 = false;
      } 
      d1.i(paramTreeSet, bool1);
    } 
  }
  
  private static SpannableStringBuilder k(String paramString, Map<String, a.b> paramMap) {
    if (!paramMap.containsKey(paramString)) {
      a.b b = new a.b();
      b.o((CharSequence)new SpannableStringBuilder());
      paramMap.put(paramString, b);
    } 
    return (SpannableStringBuilder)a.e(((a.b)paramMap.get(paramString)).e());
  }
  
  private void n(long paramLong, String paramString, List<Pair<String, String>> paramList) {
    if (!"".equals(this.h))
      paramString = this.h; 
    if (m(paramLong) && "div".equals(this.a) && this.i != null) {
      paramList.add(new Pair(paramString, this.i));
      return;
    } 
    int i;
    for (i = 0; i < g(); i++)
      f(i).n(paramLong, paramString, paramList); 
  }
  
  private void o(long paramLong, Map<String, g> paramMap, Map<String, e> paramMap1, String paramString, Map<String, a.b> paramMap2) {
    int i;
    if (!m(paramLong))
      return; 
    if (!"".equals(this.h))
      paramString = this.h; 
    Iterator<Map.Entry> iterator = this.l.entrySet().iterator();
    while (true) {
      boolean bool = iterator.hasNext();
      i = 0;
      if (bool) {
        Map.Entry entry = iterator.next();
        String str = (String)entry.getKey();
        if (this.k.containsKey(str)) {
          i = ((Integer)this.k.get(str)).intValue();
        } else {
          i = 0;
        } 
        int j = ((Integer)entry.getValue()).intValue();
        if (i != j)
          b(paramMap, (a.b)a.e(paramMap2.get(str)), i, j, ((e)a.e((e)paramMap1.get(paramString))).j); 
        continue;
      } 
      break;
    } 
    while (i < g()) {
      f(i).o(paramLong, paramMap, paramMap1, paramString, paramMap2);
      i++;
    } 
  }
  
  private void p(long paramLong, boolean paramBoolean, String paramString, Map<String, a.b> paramMap) {
    this.k.clear();
    this.l.clear();
    if ("metadata".equals(this.a))
      return; 
    if (!"".equals(this.h))
      paramString = this.h; 
    if (this.c && paramBoolean) {
      k(paramString, paramMap).append((CharSequence)a.e(this.b));
      return;
    } 
    if ("br".equals(this.a) && paramBoolean) {
      k(paramString, paramMap).append('\n');
      return;
    } 
    if (m(paramLong)) {
      for (Map.Entry<String, a.b> entry : paramMap.entrySet())
        this.k.put((String)entry.getKey(), Integer.valueOf(((CharSequence)a.e(((a.b)entry.getValue()).e())).length())); 
      boolean bool = "p".equals(this.a);
      int i;
      for (i = 0; i < g(); i++) {
        boolean bool1;
        d d1 = f(i);
        if (paramBoolean || bool) {
          bool1 = true;
        } else {
          bool1 = false;
        } 
        d1.p(paramLong, bool1, paramString, paramMap);
      } 
      if (bool)
        f.c(k(paramString, paramMap)); 
      for (Map.Entry<String, a.b> entry : paramMap.entrySet())
        this.l.put((String)entry.getKey(), Integer.valueOf(((CharSequence)a.e(((a.b)entry.getValue()).e())).length())); 
    } 
  }
  
  public void a(d paramd) {
    if (this.m == null)
      this.m = new ArrayList<d>(); 
    this.m.add(paramd);
  }
  
  public d f(int paramInt) {
    List<d> list = this.m;
    if (list != null)
      return list.get(paramInt); 
    throw new IndexOutOfBoundsException();
  }
  
  public int g() {
    List<d> list = this.m;
    return (list == null) ? 0 : list.size();
  }
  
  public List<a> h(long paramLong, Map<String, g> paramMap, Map<String, e> paramMap1, Map<String, String> paramMap2) {
    ArrayList<Pair<String, String>> arrayList1 = new ArrayList();
    n(paramLong, this.h, arrayList1);
    TreeMap<Object, Object> treeMap = new TreeMap<Object, Object>();
    p(paramLong, false, this.h, (Map)treeMap);
    o(paramLong, paramMap, paramMap1, this.h, (Map)treeMap);
    ArrayList<a> arrayList = new ArrayList();
    for (Pair<String, String> pair : arrayList1) {
      String str = paramMap2.get(pair.second);
      if (str == null)
        continue; 
      byte[] arrayOfByte = Base64.decode(str, 0);
      Bitmap bitmap = BitmapFactory.decodeByteArray(arrayOfByte, 0, arrayOfByte.length);
      e e = (e)a.e(paramMap1.get(pair.first));
      arrayList.add((new a.b()).f(bitmap).k(e.b).l(0).h(e.c, 0).i(e.e).n(e.f).g(e.g).r(e.j).a());
    } 
    for (Map.Entry<Object, Object> entry : treeMap.entrySet()) {
      e e = (e)a.e(paramMap1.get(entry.getKey()));
      a.b b = (a.b)entry.getValue();
      e((SpannableStringBuilder)a.e(b.e()));
      b.h(e.c, e.d);
      b.i(e.e);
      b.k(e.b);
      b.n(e.f);
      b.q(e.i, e.h);
      b.r(e.j);
      arrayList.add(b.a());
    } 
    return arrayList;
  }
  
  public long[] j() {
    TreeSet<Long> treeSet = new TreeSet();
    int i = 0;
    i(treeSet, false);
    long[] arrayOfLong = new long[treeSet.size()];
    Iterator<Long> iterator = treeSet.iterator();
    while (iterator.hasNext()) {
      arrayOfLong[i] = ((Long)iterator.next()).longValue();
      i++;
    } 
    return arrayOfLong;
  }
  
  @Nullable
  public String[] l() {
    return this.g;
  }
  
  public boolean m(long paramLong) {
    long l = this.d;
    return ((l == -9223372036854775807L && this.e == -9223372036854775807L) || (l <= paramLong && this.e == -9223372036854775807L) || (l == -9223372036854775807L && paramLong < this.e) || (l <= paramLong && paramLong < this.e));
  }
}


/* Location:              C:\soft\dex2jar-2.0\BabyBus TV_Kids Videos & Games-dex2jar.jar!\a4\d.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */