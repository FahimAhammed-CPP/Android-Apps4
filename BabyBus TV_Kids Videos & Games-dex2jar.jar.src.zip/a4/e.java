package a4;

final class e {
  public final String a;
  
  public final float b;
  
  public final float c;
  
  public final int d;
  
  public final int e;
  
  public final float f;
  
  public final float g;
  
  public final int h;
  
  public final float i;
  
  public final int j;
  
  public e(String paramString) {
    this(paramString, -3.4028235E38F, -3.4028235E38F, -2147483648, -2147483648, -3.4028235E38F, -3.4028235E38F, -2147483648, -3.4028235E38F, -2147483648);
  }
  
  public e(String paramString, float paramFloat1, float paramFloat2, int paramInt1, int paramInt2, float paramFloat3, float paramFloat4, int paramInt3, float paramFloat5, int paramInt4) {
    this.a = paramString;
    this.b = paramFloat1;
    this.c = paramFloat2;
    this.d = paramInt1;
    this.e = paramInt2;
    this.f = paramFloat3;
    this.g = paramFloat4;
    this.h = paramInt3;
    this.i = paramFloat5;
    this.j = paramInt4;
  }
}


/* Location:              C:\soft\dex2jar-2.0\BabyBus TV_Kids Videos & Games-dex2jar.jar!\a4\e.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */