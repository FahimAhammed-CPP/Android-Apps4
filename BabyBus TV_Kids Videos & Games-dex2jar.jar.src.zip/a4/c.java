package a4;

import android.text.Layout;
import androidx.annotation.Nullable;
import com.google.android.exoplayer2.util.r;
import com.google.android.exoplayer2.util.r0;
import com.google.android.exoplayer2.util.s0;
import java.io.ByteArrayInputStream;
import java.io.IOException;
import java.util.ArrayDeque;
import java.util.HashMap;
import java.util.Map;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import org.xmlpull.v1.XmlPullParser;
import org.xmlpull.v1.XmlPullParserException;
import org.xmlpull.v1.XmlPullParserFactory;
import t3.c;
import t3.e;
import t3.g;

public final class c extends c {
  private static final Pattern p = Pattern.compile("^([0-9][0-9]+):([0-9][0-9]):([0-9][0-9])(?:(\\.[0-9]+)|:([0-9][0-9])(?:\\.([0-9]+))?)?$");
  
  private static final Pattern q = Pattern.compile("^([0-9]+(?:\\.[0-9]+)?)(h|m|s|ms|f|t)$");
  
  private static final Pattern r = Pattern.compile("^(([0-9]*.)?[0-9]+)(px|em|%)$");
  
  static final Pattern s = Pattern.compile("^([-+]?\\d+\\.?\\d*?)%$");
  
  static final Pattern t = Pattern.compile("^(\\d+\\.?\\d*?)% (\\d+\\.?\\d*?)%$");
  
  private static final Pattern u = Pattern.compile("^(\\d+\\.?\\d*?)px (\\d+\\.?\\d*?)px$");
  
  private static final Pattern v = Pattern.compile("^(\\d+) (\\d+)$");
  
  private static final b w = new b(30.0F, 1, 1);
  
  private static final a x = new a(32, 15);
  
  private final XmlPullParserFactory o;
  
  public c() {
    super("TtmlDecoder");
    try {
      XmlPullParserFactory xmlPullParserFactory = XmlPullParserFactory.newInstance();
      this.o = xmlPullParserFactory;
      xmlPullParserFactory.setNamespaceAware(true);
      return;
    } catch (XmlPullParserException xmlPullParserException) {
      throw new RuntimeException("Couldn't create XmlPullParserFactory instance", xmlPullParserException);
    } 
  }
  
  private static g B(@Nullable g paramg) {
    g g1 = paramg;
    if (paramg == null)
      g1 = new g(); 
    return g1;
  }
  
  private static boolean C(String paramString) {
    return (paramString.equals("tt") || paramString.equals("head") || paramString.equals("body") || paramString.equals("div") || paramString.equals("p") || paramString.equals("span") || paramString.equals("br") || paramString.equals("style") || paramString.equals("styling") || paramString.equals("layout") || paramString.equals("region") || paramString.equals("metadata") || paramString.equals("image") || paramString.equals("data") || paramString.equals("information"));
  }
  
  @Nullable
  private static Layout.Alignment D(String paramString) {
    paramString = com.google.common.base.b.e(paramString);
    paramString.hashCode();
    int i = paramString.hashCode();
    byte b1 = -1;
    switch (i) {
      case 109757538:
        if (!paramString.equals("start"))
          break; 
        b1 = 4;
        break;
      case 108511772:
        if (!paramString.equals("right"))
          break; 
        b1 = 3;
        break;
      case 3317767:
        if (!paramString.equals("left"))
          break; 
        b1 = 2;
        break;
      case 100571:
        if (!paramString.equals("end"))
          break; 
        b1 = 1;
        break;
      case -1364013995:
        if (!paramString.equals("center"))
          break; 
        b1 = 0;
        break;
    } 
    switch (b1) {
      default:
        return null;
      case 2:
      case 4:
        return Layout.Alignment.ALIGN_NORMAL;
      case 1:
      case 3:
        return Layout.Alignment.ALIGN_OPPOSITE;
      case 0:
        break;
    } 
    return Layout.Alignment.ALIGN_CENTER;
  }
  
  private static a E(XmlPullParser paramXmlPullParser, a parama) throws g {
    String str = paramXmlPullParser.getAttributeValue("http://www.w3.org/ns/ttml#parameter", "cellResolution");
    if (str == null)
      return parama; 
    Matcher matcher = v.matcher(str);
    if (!matcher.matches()) {
      if (str.length() != 0) {
        str = "Ignoring malformed cell resolution: ".concat(str);
      } else {
        str = new String("Ignoring malformed cell resolution: ");
      } 
      r.h("TtmlDecoder", str);
      return parama;
    } 
    try {
      int i = Integer.parseInt((String)com.google.android.exoplayer2.util.a.e(matcher.group(1)));
      int j = Integer.parseInt((String)com.google.android.exoplayer2.util.a.e(matcher.group(2)));
      if (i != 0 && j != 0)
        return new a(i, j); 
      StringBuilder stringBuilder = new StringBuilder(47);
      stringBuilder.append("Invalid cell resolution ");
      stringBuilder.append(i);
      stringBuilder.append(" ");
      stringBuilder.append(j);
      throw new g(stringBuilder.toString());
    } catch (NumberFormatException numberFormatException) {
      if (str.length() != 0) {
        str = "Ignoring malformed cell resolution: ".concat(str);
      } else {
        str = new String("Ignoring malformed cell resolution: ");
      } 
      r.h("TtmlDecoder", str);
      return parama;
    } 
  }
  
  private static void F(String paramString, g paramg) throws g {
    Matcher matcher;
    String[] arrayOfString = r0.I0(paramString, "\\s+");
    if (arrayOfString.length == 1) {
      matcher = r.matcher(paramString);
    } else if (matcher.length == 2) {
      matcher = r.matcher((CharSequence)matcher[1]);
      r.h("TtmlDecoder", "Multiple values in fontSize attribute. Picking the second value for vertical font size and ignoring the first.");
    } else {
      int i = matcher.length;
      StringBuilder stringBuilder1 = new StringBuilder(52);
      stringBuilder1.append("Invalid number of entries for fontSize: ");
      stringBuilder1.append(i);
      stringBuilder1.append(".");
      throw new g(stringBuilder1.toString());
    } 
    if (matcher.matches()) {
      StringBuilder stringBuilder1;
      paramString = (String)com.google.android.exoplayer2.util.a.e(matcher.group(3));
      paramString.hashCode();
      byte b1 = -1;
      switch (paramString.hashCode()) {
        case 3592:
          if (!paramString.equals("px"))
            break; 
          b1 = 2;
          break;
        case 3240:
          if (!paramString.equals("em"))
            break; 
          b1 = 1;
          break;
        case 37:
          if (!paramString.equals("%"))
            break; 
          b1 = 0;
          break;
      } 
      switch (b1) {
        default:
          stringBuilder1 = new StringBuilder(paramString.length() + 30);
          stringBuilder1.append("Invalid unit for fontSize: '");
          stringBuilder1.append(paramString);
          stringBuilder1.append("'.");
          throw new g(stringBuilder1.toString());
        case 2:
          stringBuilder1.z(1);
          break;
        case 1:
          stringBuilder1.z(2);
          break;
        case 0:
          stringBuilder1.z(3);
          break;
      } 
      stringBuilder1.y(Float.parseFloat((String)com.google.android.exoplayer2.util.a.e(matcher.group(1))));
      return;
    } 
    StringBuilder stringBuilder = new StringBuilder(String.valueOf(paramString).length() + 36);
    stringBuilder.append("Invalid expression for fontSize: '");
    stringBuilder.append(paramString);
    stringBuilder.append("'.");
    throw new g(stringBuilder.toString());
  }
  
  private static b G(XmlPullParser paramXmlPullParser) throws g {
    byte b1;
    String str2 = paramXmlPullParser.getAttributeValue("http://www.w3.org/ns/ttml#parameter", "frameRate");
    if (str2 != null) {
      b1 = Integer.parseInt(str2);
    } else {
      b1 = 30;
    } 
    float f = 1.0F;
    str2 = paramXmlPullParser.getAttributeValue("http://www.w3.org/ns/ttml#parameter", "frameRateMultiplier");
    if (str2 != null) {
      String[] arrayOfString = r0.I0(str2, " ");
      if (arrayOfString.length == 2) {
        f = Integer.parseInt(arrayOfString[0]) / Integer.parseInt(arrayOfString[1]);
      } else {
        throw new g("frameRateMultiplier doesn't have 2 parts");
      } 
    } 
    b b2 = w;
    int i = b2.b;
    String str3 = paramXmlPullParser.getAttributeValue("http://www.w3.org/ns/ttml#parameter", "subFrameRate");
    if (str3 != null)
      i = Integer.parseInt(str3); 
    int j = b2.c;
    String str1 = paramXmlPullParser.getAttributeValue("http://www.w3.org/ns/ttml#parameter", "tickRate");
    if (str1 != null)
      j = Integer.parseInt(str1); 
    return new b(b1 * f, i, j);
  }
  
  private static Map<String, g> H(XmlPullParser paramXmlPullParser, Map<String, g> paramMap, a parama, @Nullable c paramc, Map<String, e> paramMap1, Map<String, String> paramMap2) throws IOException, XmlPullParserException {
    while (true) {
      paramXmlPullParser.next();
      if (s0.f(paramXmlPullParser, "style")) {
        String str = s0.a(paramXmlPullParser, "style");
        g g = M(paramXmlPullParser, new g());
        if (str != null) {
          String[] arrayOfString = N(str);
          int j = arrayOfString.length;
          int i;
          for (i = 0; i < j; i++)
            g.a(paramMap.get(arrayOfString[i])); 
        } 
        str = g.g();
        if (str != null)
          paramMap.put(str, g); 
      } else if (s0.f(paramXmlPullParser, "region")) {
        e e = K(paramXmlPullParser, parama, paramc);
        if (e != null)
          paramMap1.put(e.a, e); 
      } else if (s0.f(paramXmlPullParser, "metadata")) {
        I(paramXmlPullParser, paramMap2);
      } 
      if (s0.d(paramXmlPullParser, "head"))
        return paramMap; 
    } 
  }
  
  private static void I(XmlPullParser paramXmlPullParser, Map<String, String> paramMap) throws IOException, XmlPullParserException {
    do {
      paramXmlPullParser.next();
      if (!s0.f(paramXmlPullParser, "image"))
        continue; 
      String str = s0.a(paramXmlPullParser, "id");
      if (str == null)
        continue; 
      paramMap.put(str, paramXmlPullParser.nextText());
    } while (!s0.d(paramXmlPullParser, "metadata"));
  }
  
  private static d J(XmlPullParser paramXmlPullParser, @Nullable d paramd, Map<String, e> paramMap, b paramb) throws g {
    long l4;
    long l5;
    String[] arrayOfString;
    int j = paramXmlPullParser.getAttributeCount();
    g g = M(paramXmlPullParser, null);
    String str1 = null;
    String str3 = "";
    long l1 = -9223372036854775807L;
    long l2 = -9223372036854775807L;
    long l3 = -9223372036854775807L;
    String str2 = str1;
    int i = 0;
    while (i < j) {
      byte b1;
      long l;
      String str5;
      String[] arrayOfString1;
      String str4 = paramXmlPullParser.getAttributeName(i);
      String str6 = paramXmlPullParser.getAttributeValue(i);
      str4.hashCode();
      switch (str4.hashCode()) {
        default:
          b1 = -1;
          break;
        case 1292595405:
          if (str4.equals("backgroundImage")) {
            b1 = 5;
            break;
          } 
        case 109780401:
          if (str4.equals("style")) {
            b1 = 4;
            break;
          } 
        case 93616297:
          if (str4.equals("begin")) {
            b1 = 3;
            break;
          } 
        case 100571:
          if (str4.equals("end")) {
            b1 = 2;
            break;
          } 
        case 99841:
          if (str4.equals("dur")) {
            b1 = 1;
            break;
          } 
        case -934795532:
          if (str4.equals("region")) {
            b1 = 0;
            break;
          } 
      } 
      switch (b1) {
        default:
          str5 = str2;
          str4 = str1;
          l5 = l1;
          l = l2;
          l4 = l3;
          break;
        case 5:
          str5 = str2;
          str4 = str1;
          l5 = l1;
          l = l2;
          l4 = l3;
          if (str6.startsWith("#")) {
            str4 = str6.substring(1);
            str5 = str2;
            l5 = l1;
            l = l2;
            l4 = l3;
          } 
          break;
        case 4:
          arrayOfString1 = N(str6);
          str5 = str2;
          str4 = str1;
          l5 = l1;
          l = l2;
          l4 = l3;
          if (arrayOfString1.length > 0) {
            String[] arrayOfString2 = arrayOfString1;
            str4 = str1;
            l5 = l1;
            l = l2;
            l4 = l3;
          } 
          break;
        case 3:
          l5 = O((String)arrayOfString1, paramb);
          l4 = l3;
          l = l2;
          str4 = str1;
          str5 = str2;
          break;
        case 2:
          l = O((String)arrayOfString1, paramb);
          str5 = str2;
          str4 = str1;
          l5 = l1;
          l4 = l3;
          break;
        case 1:
          l4 = O((String)arrayOfString1, paramb);
          str5 = str2;
          str4 = str1;
          l5 = l1;
          l = l2;
          break;
        case 0:
          str5 = str2;
          str4 = str1;
          l5 = l1;
          l = l2;
          l4 = l3;
          if (paramMap.containsKey(arrayOfString1)) {
            arrayOfString = arrayOfString1;
            l4 = l3;
            l = l2;
            l5 = l1;
            str4 = str1;
            str5 = str2;
          } 
          break;
      } 
      i++;
      str2 = str5;
      str1 = str4;
      l1 = l5;
      l2 = l;
      l3 = l4;
    } 
    if (paramd != null) {
      long l = paramd.d;
      l5 = l1;
      l4 = l2;
      if (l != -9223372036854775807L) {
        long l6 = l1;
        if (l1 != -9223372036854775807L)
          l6 = l1 + l; 
        l5 = l6;
        l4 = l2;
        if (l2 != -9223372036854775807L) {
          l4 = l2 + l;
          l5 = l6;
        } 
      } 
    } else {
      l4 = l2;
      l5 = l1;
    } 
    if (l4 == -9223372036854775807L) {
      if (l3 != -9223372036854775807L) {
        l1 = l5 + l3;
      } else {
        if (paramd != null) {
          l1 = paramd.e;
          if (l1 != -9223372036854775807L)
            return d.c(paramXmlPullParser.getName(), l5, l1, g, (String[])str2, (String)arrayOfString, str1, paramd); 
        } 
        l1 = l4;
      } 
      return d.c(paramXmlPullParser.getName(), l5, l1, g, (String[])str2, (String)arrayOfString, str1, paramd);
    } 
    l1 = l4;
  }
  
  @Nullable
  private static e K(XmlPullParser paramXmlPullParser, a parama, @Nullable c paramc) {
    // Byte code:
    //   0: aload_0
    //   1: ldc_w 'id'
    //   4: invokestatic a : (Lorg/xmlpull/v1/XmlPullParser;Ljava/lang/String;)Ljava/lang/String;
    //   7: astore #10
    //   9: aload #10
    //   11: ifnonnull -> 16
    //   14: aconst_null
    //   15: areturn
    //   16: aload_0
    //   17: ldc_w 'origin'
    //   20: invokestatic a : (Lorg/xmlpull/v1/XmlPullParser;Ljava/lang/String;)Ljava/lang/String;
    //   23: astore #11
    //   25: aload #11
    //   27: ifnull -> 943
    //   30: getstatic a4/c.t : Ljava/util/regex/Pattern;
    //   33: astore #13
    //   35: aload #13
    //   37: aload #11
    //   39: invokevirtual matcher : (Ljava/lang/CharSequence;)Ljava/util/regex/Matcher;
    //   42: astore #14
    //   44: getstatic a4/c.u : Ljava/util/regex/Pattern;
    //   47: astore #12
    //   49: aload #12
    //   51: aload #11
    //   53: invokevirtual matcher : (Ljava/lang/CharSequence;)Ljava/util/regex/Matcher;
    //   56: astore #15
    //   58: aload #14
    //   60: invokevirtual matches : ()Z
    //   63: ifeq -> 151
    //   66: aload #14
    //   68: iconst_1
    //   69: invokevirtual group : (I)Ljava/lang/String;
    //   72: invokestatic e : (Ljava/lang/Object;)Ljava/lang/Object;
    //   75: checkcast java/lang/String
    //   78: invokestatic parseFloat : (Ljava/lang/String;)F
    //   81: ldc_w 100.0
    //   84: fdiv
    //   85: fstore #4
    //   87: aload #14
    //   89: iconst_2
    //   90: invokevirtual group : (I)Ljava/lang/String;
    //   93: invokestatic e : (Ljava/lang/Object;)Ljava/lang/Object;
    //   96: checkcast java/lang/String
    //   99: invokestatic parseFloat : (Ljava/lang/String;)F
    //   102: fstore_3
    //   103: fload_3
    //   104: ldc_w 100.0
    //   107: fdiv
    //   108: fstore_3
    //   109: goto -> 263
    //   112: aload #11
    //   114: invokevirtual length : ()I
    //   117: ifeq -> 132
    //   120: ldc_w 'Ignoring region with malformed origin: '
    //   123: aload #11
    //   125: invokevirtual concat : (Ljava/lang/String;)Ljava/lang/String;
    //   128: astore_0
    //   129: goto -> 143
    //   132: new java/lang/String
    //   135: dup
    //   136: ldc_w 'Ignoring region with malformed origin: '
    //   139: invokespecial <init> : (Ljava/lang/String;)V
    //   142: astore_0
    //   143: ldc 'TtmlDecoder'
    //   145: aload_0
    //   146: invokestatic h : (Ljava/lang/String;Ljava/lang/String;)V
    //   149: aconst_null
    //   150: areturn
    //   151: aload #15
    //   153: invokevirtual matches : ()Z
    //   156: ifeq -> 904
    //   159: aload_2
    //   160: ifnonnull -> 202
    //   163: aload #11
    //   165: invokevirtual length : ()I
    //   168: ifeq -> 183
    //   171: ldc_w 'Ignoring region with missing tts:extent: '
    //   174: aload #11
    //   176: invokevirtual concat : (Ljava/lang/String;)Ljava/lang/String;
    //   179: astore_0
    //   180: goto -> 194
    //   183: new java/lang/String
    //   186: dup
    //   187: ldc_w 'Ignoring region with missing tts:extent: '
    //   190: invokespecial <init> : (Ljava/lang/String;)V
    //   193: astore_0
    //   194: ldc 'TtmlDecoder'
    //   196: aload_0
    //   197: invokestatic h : (Ljava/lang/String;Ljava/lang/String;)V
    //   200: aconst_null
    //   201: areturn
    //   202: aload #15
    //   204: iconst_1
    //   205: invokevirtual group : (I)Ljava/lang/String;
    //   208: invokestatic e : (Ljava/lang/Object;)Ljava/lang/Object;
    //   211: checkcast java/lang/String
    //   214: invokestatic parseInt : (Ljava/lang/String;)I
    //   217: istore #8
    //   219: aload #15
    //   221: iconst_2
    //   222: invokevirtual group : (I)Ljava/lang/String;
    //   225: invokestatic e : (Ljava/lang/Object;)Ljava/lang/Object;
    //   228: checkcast java/lang/String
    //   231: invokestatic parseInt : (Ljava/lang/String;)I
    //   234: istore #9
    //   236: iload #8
    //   238: i2f
    //   239: aload_2
    //   240: getfield a : I
    //   243: i2f
    //   244: fdiv
    //   245: fstore #4
    //   247: iload #9
    //   249: i2f
    //   250: fstore_3
    //   251: aload_2
    //   252: getfield b : I
    //   255: istore #8
    //   257: fload_3
    //   258: iload #8
    //   260: i2f
    //   261: fdiv
    //   262: fstore_3
    //   263: aload_0
    //   264: ldc_w 'extent'
    //   267: invokestatic a : (Lorg/xmlpull/v1/XmlPullParser;Ljava/lang/String;)Ljava/lang/String;
    //   270: astore #14
    //   272: aload #14
    //   274: ifnull -> 855
    //   277: aload #13
    //   279: aload #14
    //   281: invokevirtual matcher : (Ljava/lang/CharSequence;)Ljava/util/regex/Matcher;
    //   284: astore #13
    //   286: aload #12
    //   288: aload #14
    //   290: invokevirtual matcher : (Ljava/lang/CharSequence;)Ljava/util/regex/Matcher;
    //   293: astore #12
    //   295: aload #13
    //   297: invokevirtual matches : ()Z
    //   300: ifeq -> 391
    //   303: aload #13
    //   305: iconst_1
    //   306: invokevirtual group : (I)Ljava/lang/String;
    //   309: invokestatic e : (Ljava/lang/Object;)Ljava/lang/Object;
    //   312: checkcast java/lang/String
    //   315: invokestatic parseFloat : (Ljava/lang/String;)F
    //   318: ldc_w 100.0
    //   321: fdiv
    //   322: fstore #5
    //   324: aload #13
    //   326: iconst_2
    //   327: invokevirtual group : (I)Ljava/lang/String;
    //   330: invokestatic e : (Ljava/lang/Object;)Ljava/lang/Object;
    //   333: checkcast java/lang/String
    //   336: invokestatic parseFloat : (Ljava/lang/String;)F
    //   339: fstore #6
    //   341: fload #6
    //   343: ldc_w 100.0
    //   346: fdiv
    //   347: fstore #6
    //   349: goto -> 506
    //   352: aload #11
    //   354: invokevirtual length : ()I
    //   357: ifeq -> 372
    //   360: ldc_w 'Ignoring region with malformed extent: '
    //   363: aload #11
    //   365: invokevirtual concat : (Ljava/lang/String;)Ljava/lang/String;
    //   368: astore_0
    //   369: goto -> 383
    //   372: new java/lang/String
    //   375: dup
    //   376: ldc_w 'Ignoring region with malformed extent: '
    //   379: invokespecial <init> : (Ljava/lang/String;)V
    //   382: astore_0
    //   383: ldc 'TtmlDecoder'
    //   385: aload_0
    //   386: invokestatic h : (Ljava/lang/String;Ljava/lang/String;)V
    //   389: aconst_null
    //   390: areturn
    //   391: aload #12
    //   393: invokevirtual matches : ()Z
    //   396: ifeq -> 816
    //   399: aload_2
    //   400: ifnonnull -> 442
    //   403: aload #11
    //   405: invokevirtual length : ()I
    //   408: ifeq -> 423
    //   411: ldc_w 'Ignoring region with missing tts:extent: '
    //   414: aload #11
    //   416: invokevirtual concat : (Ljava/lang/String;)Ljava/lang/String;
    //   419: astore_0
    //   420: goto -> 434
    //   423: new java/lang/String
    //   426: dup
    //   427: ldc_w 'Ignoring region with missing tts:extent: '
    //   430: invokespecial <init> : (Ljava/lang/String;)V
    //   433: astore_0
    //   434: ldc 'TtmlDecoder'
    //   436: aload_0
    //   437: invokestatic h : (Ljava/lang/String;Ljava/lang/String;)V
    //   440: aconst_null
    //   441: areturn
    //   442: aload #12
    //   444: iconst_1
    //   445: invokevirtual group : (I)Ljava/lang/String;
    //   448: invokestatic e : (Ljava/lang/Object;)Ljava/lang/Object;
    //   451: checkcast java/lang/String
    //   454: invokestatic parseInt : (Ljava/lang/String;)I
    //   457: istore #8
    //   459: aload #12
    //   461: iconst_2
    //   462: invokevirtual group : (I)Ljava/lang/String;
    //   465: invokestatic e : (Ljava/lang/Object;)Ljava/lang/Object;
    //   468: checkcast java/lang/String
    //   471: invokestatic parseInt : (Ljava/lang/String;)I
    //   474: istore #9
    //   476: iload #8
    //   478: i2f
    //   479: aload_2
    //   480: getfield a : I
    //   483: i2f
    //   484: fdiv
    //   485: fstore #5
    //   487: iload #9
    //   489: i2f
    //   490: fstore #6
    //   492: aload_2
    //   493: getfield b : I
    //   496: istore #8
    //   498: fload #6
    //   500: iload #8
    //   502: i2f
    //   503: fdiv
    //   504: fstore #6
    //   506: aload_0
    //   507: ldc_w 'displayAlign'
    //   510: invokestatic a : (Lorg/xmlpull/v1/XmlPullParser;Ljava/lang/String;)Ljava/lang/String;
    //   513: astore_2
    //   514: iconst_0
    //   515: istore #8
    //   517: aload_2
    //   518: ifnull -> 577
    //   521: aload_2
    //   522: invokestatic e : (Ljava/lang/String;)Ljava/lang/String;
    //   525: astore_2
    //   526: aload_2
    //   527: invokevirtual hashCode : ()I
    //   530: pop
    //   531: aload_2
    //   532: ldc 'center'
    //   534: invokevirtual equals : (Ljava/lang/Object;)Z
    //   537: ifne -> 564
    //   540: aload_2
    //   541: ldc_w 'after'
    //   544: invokevirtual equals : (Ljava/lang/Object;)Z
    //   547: ifne -> 553
    //   550: goto -> 577
    //   553: fload_3
    //   554: fload #6
    //   556: fadd
    //   557: fstore_3
    //   558: iconst_2
    //   559: istore #9
    //   561: goto -> 580
    //   564: fload_3
    //   565: fload #6
    //   567: fconst_2
    //   568: fdiv
    //   569: fadd
    //   570: fstore_3
    //   571: iconst_1
    //   572: istore #9
    //   574: goto -> 580
    //   577: iconst_0
    //   578: istore #9
    //   580: fconst_1
    //   581: aload_1
    //   582: getfield b : I
    //   585: i2f
    //   586: fdiv
    //   587: fstore #7
    //   589: aload_0
    //   590: ldc_w 'writingMode'
    //   593: invokestatic a : (Lorg/xmlpull/v1/XmlPullParser;Ljava/lang/String;)Ljava/lang/String;
    //   596: astore_0
    //   597: aload_0
    //   598: ifnull -> 747
    //   601: aload_0
    //   602: invokestatic e : (Ljava/lang/String;)Ljava/lang/String;
    //   605: astore_0
    //   606: aload_0
    //   607: invokevirtual hashCode : ()I
    //   610: pop
    //   611: aload_0
    //   612: invokevirtual hashCode : ()I
    //   615: lookupswitch default -> 648, 3694 -> 692, 3553396 -> 673, 3553576 -> 654
    //   648: iconst_m1
    //   649: istore #8
    //   651: goto -> 705
    //   654: aload_0
    //   655: ldc_w 'tbrl'
    //   658: invokevirtual equals : (Ljava/lang/Object;)Z
    //   661: ifne -> 667
    //   664: goto -> 648
    //   667: iconst_2
    //   668: istore #8
    //   670: goto -> 705
    //   673: aload_0
    //   674: ldc_w 'tblr'
    //   677: invokevirtual equals : (Ljava/lang/Object;)Z
    //   680: ifne -> 686
    //   683: goto -> 648
    //   686: iconst_1
    //   687: istore #8
    //   689: goto -> 705
    //   692: aload_0
    //   693: ldc_w 'tb'
    //   696: invokevirtual equals : (Ljava/lang/Object;)Z
    //   699: ifne -> 705
    //   702: goto -> 648
    //   705: iload #8
    //   707: tableswitch default -> 732, 0 -> 741, 1 -> 741, 2 -> 735
    //   732: goto -> 747
    //   735: iconst_1
    //   736: istore #8
    //   738: goto -> 752
    //   741: iconst_2
    //   742: istore #8
    //   744: goto -> 752
    //   747: ldc_w -2147483648
    //   750: istore #8
    //   752: new a4/e
    //   755: dup
    //   756: aload #10
    //   758: fload #4
    //   760: fload_3
    //   761: iconst_0
    //   762: iload #9
    //   764: fload #5
    //   766: fload #6
    //   768: iconst_1
    //   769: fload #7
    //   771: iload #8
    //   773: invokespecial <init> : (Ljava/lang/String;FFIIFFIFI)V
    //   776: areturn
    //   777: aload #11
    //   779: invokevirtual length : ()I
    //   782: ifeq -> 797
    //   785: ldc_w 'Ignoring region with malformed extent: '
    //   788: aload #11
    //   790: invokevirtual concat : (Ljava/lang/String;)Ljava/lang/String;
    //   793: astore_0
    //   794: goto -> 808
    //   797: new java/lang/String
    //   800: dup
    //   801: ldc_w 'Ignoring region with malformed extent: '
    //   804: invokespecial <init> : (Ljava/lang/String;)V
    //   807: astore_0
    //   808: ldc 'TtmlDecoder'
    //   810: aload_0
    //   811: invokestatic h : (Ljava/lang/String;Ljava/lang/String;)V
    //   814: aconst_null
    //   815: areturn
    //   816: aload #11
    //   818: invokevirtual length : ()I
    //   821: ifeq -> 836
    //   824: ldc_w 'Ignoring region with unsupported extent: '
    //   827: aload #11
    //   829: invokevirtual concat : (Ljava/lang/String;)Ljava/lang/String;
    //   832: astore_0
    //   833: goto -> 847
    //   836: new java/lang/String
    //   839: dup
    //   840: ldc_w 'Ignoring region with unsupported extent: '
    //   843: invokespecial <init> : (Ljava/lang/String;)V
    //   846: astore_0
    //   847: ldc 'TtmlDecoder'
    //   849: aload_0
    //   850: invokestatic h : (Ljava/lang/String;Ljava/lang/String;)V
    //   853: aconst_null
    //   854: areturn
    //   855: ldc 'TtmlDecoder'
    //   857: ldc_w 'Ignoring region without an extent'
    //   860: invokestatic h : (Ljava/lang/String;Ljava/lang/String;)V
    //   863: aconst_null
    //   864: areturn
    //   865: aload #11
    //   867: invokevirtual length : ()I
    //   870: ifeq -> 885
    //   873: ldc_w 'Ignoring region with malformed origin: '
    //   876: aload #11
    //   878: invokevirtual concat : (Ljava/lang/String;)Ljava/lang/String;
    //   881: astore_0
    //   882: goto -> 896
    //   885: new java/lang/String
    //   888: dup
    //   889: ldc_w 'Ignoring region with malformed origin: '
    //   892: invokespecial <init> : (Ljava/lang/String;)V
    //   895: astore_0
    //   896: ldc 'TtmlDecoder'
    //   898: aload_0
    //   899: invokestatic h : (Ljava/lang/String;Ljava/lang/String;)V
    //   902: aconst_null
    //   903: areturn
    //   904: aload #11
    //   906: invokevirtual length : ()I
    //   909: ifeq -> 924
    //   912: ldc_w 'Ignoring region with unsupported origin: '
    //   915: aload #11
    //   917: invokevirtual concat : (Ljava/lang/String;)Ljava/lang/String;
    //   920: astore_0
    //   921: goto -> 935
    //   924: new java/lang/String
    //   927: dup
    //   928: ldc_w 'Ignoring region with unsupported origin: '
    //   931: invokespecial <init> : (Ljava/lang/String;)V
    //   934: astore_0
    //   935: ldc 'TtmlDecoder'
    //   937: aload_0
    //   938: invokestatic h : (Ljava/lang/String;Ljava/lang/String;)V
    //   941: aconst_null
    //   942: areturn
    //   943: ldc 'TtmlDecoder'
    //   945: ldc_w 'Ignoring region without an origin'
    //   948: invokestatic h : (Ljava/lang/String;Ljava/lang/String;)V
    //   951: aconst_null
    //   952: areturn
    //   953: astore_0
    //   954: goto -> 112
    //   957: astore_0
    //   958: goto -> 865
    //   961: astore_0
    //   962: goto -> 352
    //   965: astore_0
    //   966: goto -> 777
    // Exception table:
    //   from	to	target	type
    //   66	103	953	java/lang/NumberFormatException
    //   202	247	957	java/lang/NumberFormatException
    //   251	257	957	java/lang/NumberFormatException
    //   303	341	961	java/lang/NumberFormatException
    //   442	487	965	java/lang/NumberFormatException
    //   492	498	965	java/lang/NumberFormatException
  }
  
  private static float L(String paramString) {
    Matcher matcher = s.matcher(paramString);
    if (!matcher.matches()) {
      paramString = String.valueOf(paramString);
      if (paramString.length() != 0) {
        paramString = "Invalid value for shear: ".concat(paramString);
      } else {
        paramString = new String("Invalid value for shear: ");
      } 
      r.h("TtmlDecoder", paramString);
      return Float.MAX_VALUE;
    } 
    try {
      return Math.min(100.0F, Math.max(-100.0F, Float.parseFloat((String)com.google.android.exoplayer2.util.a.e(matcher.group(1)))));
    } catch (NumberFormatException numberFormatException) {
      paramString = String.valueOf(paramString);
      if (paramString.length() != 0) {
        paramString = "Failed to parse shear: ".concat(paramString);
      } else {
        paramString = new String("Failed to parse shear: ");
      } 
      r.i("TtmlDecoder", paramString, numberFormatException);
      return Float.MAX_VALUE;
    } 
  }
  
  private static g M(XmlPullParser paramXmlPullParser, g paramg) {
    // Byte code:
    //   0: aload_0
    //   1: invokeinterface getAttributeCount : ()I
    //   6: istore #6
    //   8: iconst_0
    //   9: istore_3
    //   10: aload_1
    //   11: astore #7
    //   13: iload_3
    //   14: iload #6
    //   16: if_icmpge -> 1568
    //   19: aload_0
    //   20: iload_3
    //   21: invokeinterface getAttributeValue : (I)Ljava/lang/String;
    //   26: astore #8
    //   28: aload_0
    //   29: iload_3
    //   30: invokeinterface getAttributeName : (I)Ljava/lang/String;
    //   35: astore_1
    //   36: aload_1
    //   37: invokevirtual hashCode : ()I
    //   40: pop
    //   41: aload_1
    //   42: invokevirtual hashCode : ()I
    //   45: istore_2
    //   46: iconst_5
    //   47: istore #4
    //   49: iconst_m1
    //   50: istore #5
    //   52: iload_2
    //   53: lookupswitch default -> 184, -1550943582 -> 450, -1224696685 -> 432, -1065511464 -> 414, -879295043 -> 396, -734428249 -> 378, 3355 -> 360, 3511770 -> 341, 94842723 -> 322, 109403361 -> 303, 110138194 -> 284, 365601008 -> 265, 921125321 -> 246, 1115953443 -> 227, 1287124693 -> 208, 1754920356 -> 189
    //   184: iconst_m1
    //   185: istore_2
    //   186: goto -> 465
    //   189: aload_1
    //   190: ldc_w 'multiRowAlign'
    //   193: invokevirtual equals : (Ljava/lang/Object;)Z
    //   196: ifne -> 202
    //   199: goto -> 184
    //   202: bipush #14
    //   204: istore_2
    //   205: goto -> 465
    //   208: aload_1
    //   209: ldc_w 'backgroundColor'
    //   212: invokevirtual equals : (Ljava/lang/Object;)Z
    //   215: ifne -> 221
    //   218: goto -> 184
    //   221: bipush #13
    //   223: istore_2
    //   224: goto -> 465
    //   227: aload_1
    //   228: ldc_w 'rubyPosition'
    //   231: invokevirtual equals : (Ljava/lang/Object;)Z
    //   234: ifne -> 240
    //   237: goto -> 184
    //   240: bipush #12
    //   242: istore_2
    //   243: goto -> 465
    //   246: aload_1
    //   247: ldc_w 'textEmphasis'
    //   250: invokevirtual equals : (Ljava/lang/Object;)Z
    //   253: ifne -> 259
    //   256: goto -> 184
    //   259: bipush #11
    //   261: istore_2
    //   262: goto -> 465
    //   265: aload_1
    //   266: ldc_w 'fontSize'
    //   269: invokevirtual equals : (Ljava/lang/Object;)Z
    //   272: ifne -> 278
    //   275: goto -> 184
    //   278: bipush #10
    //   280: istore_2
    //   281: goto -> 465
    //   284: aload_1
    //   285: ldc_w 'textCombine'
    //   288: invokevirtual equals : (Ljava/lang/Object;)Z
    //   291: ifne -> 297
    //   294: goto -> 184
    //   297: bipush #9
    //   299: istore_2
    //   300: goto -> 465
    //   303: aload_1
    //   304: ldc_w 'shear'
    //   307: invokevirtual equals : (Ljava/lang/Object;)Z
    //   310: ifne -> 316
    //   313: goto -> 184
    //   316: bipush #8
    //   318: istore_2
    //   319: goto -> 465
    //   322: aload_1
    //   323: ldc_w 'color'
    //   326: invokevirtual equals : (Ljava/lang/Object;)Z
    //   329: ifne -> 335
    //   332: goto -> 184
    //   335: bipush #7
    //   337: istore_2
    //   338: goto -> 465
    //   341: aload_1
    //   342: ldc_w 'ruby'
    //   345: invokevirtual equals : (Ljava/lang/Object;)Z
    //   348: ifne -> 354
    //   351: goto -> 184
    //   354: bipush #6
    //   356: istore_2
    //   357: goto -> 465
    //   360: aload_1
    //   361: ldc_w 'id'
    //   364: invokevirtual equals : (Ljava/lang/Object;)Z
    //   367: ifne -> 373
    //   370: goto -> 184
    //   373: iconst_5
    //   374: istore_2
    //   375: goto -> 465
    //   378: aload_1
    //   379: ldc_w 'fontWeight'
    //   382: invokevirtual equals : (Ljava/lang/Object;)Z
    //   385: ifne -> 391
    //   388: goto -> 184
    //   391: iconst_4
    //   392: istore_2
    //   393: goto -> 465
    //   396: aload_1
    //   397: ldc_w 'textDecoration'
    //   400: invokevirtual equals : (Ljava/lang/Object;)Z
    //   403: ifne -> 409
    //   406: goto -> 184
    //   409: iconst_3
    //   410: istore_2
    //   411: goto -> 465
    //   414: aload_1
    //   415: ldc_w 'textAlign'
    //   418: invokevirtual equals : (Ljava/lang/Object;)Z
    //   421: ifne -> 427
    //   424: goto -> 184
    //   427: iconst_2
    //   428: istore_2
    //   429: goto -> 465
    //   432: aload_1
    //   433: ldc_w 'fontFamily'
    //   436: invokevirtual equals : (Ljava/lang/Object;)Z
    //   439: ifne -> 445
    //   442: goto -> 184
    //   445: iconst_1
    //   446: istore_2
    //   447: goto -> 465
    //   450: aload_1
    //   451: ldc_w 'fontStyle'
    //   454: invokevirtual equals : (Ljava/lang/Object;)Z
    //   457: ifne -> 463
    //   460: goto -> 184
    //   463: iconst_0
    //   464: istore_2
    //   465: iload_2
    //   466: tableswitch default -> 540, 0 -> 1541, 1 -> 1527, 2 -> 1510, 3 -> 1273, 4 -> 1253, 5 -> 1222, 6 -> 941, 7 -> 870, 8 -> 853, 9 -> 790, 10 -> 714, 11 -> 697, 12 -> 634, 13 -> 563, 14 -> 546
    //   540: aload #7
    //   542: astore_1
    //   543: goto -> 1558
    //   546: aload #7
    //   548: invokestatic B : (La4/g;)La4/g;
    //   551: aload #8
    //   553: invokestatic D : (Ljava/lang/String;)Landroid/text/Layout$Alignment;
    //   556: invokevirtual D : (Landroid/text/Layout$Alignment;)La4/g;
    //   559: astore_1
    //   560: goto -> 1558
    //   563: aload #7
    //   565: invokestatic B : (La4/g;)La4/g;
    //   568: astore #7
    //   570: aload #7
    //   572: aload #8
    //   574: invokestatic c : (Ljava/lang/String;)I
    //   577: invokevirtual u : (I)La4/g;
    //   580: pop
    //   581: aload #7
    //   583: astore_1
    //   584: goto -> 1558
    //   587: aload #8
    //   589: invokestatic valueOf : (Ljava/lang/Object;)Ljava/lang/String;
    //   592: astore_1
    //   593: aload_1
    //   594: invokevirtual length : ()I
    //   597: ifeq -> 611
    //   600: ldc_w 'Failed parsing background value: '
    //   603: aload_1
    //   604: invokevirtual concat : (Ljava/lang/String;)Ljava/lang/String;
    //   607: astore_1
    //   608: goto -> 622
    //   611: new java/lang/String
    //   614: dup
    //   615: ldc_w 'Failed parsing background value: '
    //   618: invokespecial <init> : (Ljava/lang/String;)V
    //   621: astore_1
    //   622: ldc 'TtmlDecoder'
    //   624: aload_1
    //   625: invokestatic h : (Ljava/lang/String;Ljava/lang/String;)V
    //   628: aload #7
    //   630: astore_1
    //   631: goto -> 1558
    //   634: aload #8
    //   636: invokestatic e : (Ljava/lang/String;)Ljava/lang/String;
    //   639: astore_1
    //   640: aload_1
    //   641: invokevirtual hashCode : ()I
    //   644: pop
    //   645: aload_1
    //   646: ldc_w 'before'
    //   649: invokevirtual equals : (Ljava/lang/Object;)Z
    //   652: ifne -> 684
    //   655: aload_1
    //   656: ldc_w 'after'
    //   659: invokevirtual equals : (Ljava/lang/Object;)Z
    //   662: ifne -> 671
    //   665: aload #7
    //   667: astore_1
    //   668: goto -> 1558
    //   671: aload #7
    //   673: invokestatic B : (La4/g;)La4/g;
    //   676: iconst_2
    //   677: invokevirtual E : (I)La4/g;
    //   680: astore_1
    //   681: goto -> 1558
    //   684: aload #7
    //   686: invokestatic B : (La4/g;)La4/g;
    //   689: iconst_1
    //   690: invokevirtual E : (I)La4/g;
    //   693: astore_1
    //   694: goto -> 1558
    //   697: aload #7
    //   699: invokestatic B : (La4/g;)La4/g;
    //   702: aload #8
    //   704: invokestatic a : (Ljava/lang/String;)La4/b;
    //   707: invokevirtual J : (La4/b;)La4/g;
    //   710: astore_1
    //   711: goto -> 1558
    //   714: aload #7
    //   716: astore_1
    //   717: aload #7
    //   719: invokestatic B : (La4/g;)La4/g;
    //   722: astore #7
    //   724: aload #7
    //   726: astore_1
    //   727: aload #8
    //   729: aload #7
    //   731: invokestatic F : (Ljava/lang/String;La4/g;)V
    //   734: aload #7
    //   736: astore_1
    //   737: goto -> 1558
    //   740: aload #8
    //   742: invokestatic valueOf : (Ljava/lang/Object;)Ljava/lang/String;
    //   745: astore #7
    //   747: aload #7
    //   749: invokevirtual length : ()I
    //   752: ifeq -> 768
    //   755: ldc_w 'Failed parsing fontSize value: '
    //   758: aload #7
    //   760: invokevirtual concat : (Ljava/lang/String;)Ljava/lang/String;
    //   763: astore #7
    //   765: goto -> 780
    //   768: new java/lang/String
    //   771: dup
    //   772: ldc_w 'Failed parsing fontSize value: '
    //   775: invokespecial <init> : (Ljava/lang/String;)V
    //   778: astore #7
    //   780: ldc 'TtmlDecoder'
    //   782: aload #7
    //   784: invokestatic h : (Ljava/lang/String;Ljava/lang/String;)V
    //   787: goto -> 1558
    //   790: aload #8
    //   792: invokestatic e : (Ljava/lang/String;)Ljava/lang/String;
    //   795: astore_1
    //   796: aload_1
    //   797: invokevirtual hashCode : ()I
    //   800: pop
    //   801: aload_1
    //   802: ldc_w 'all'
    //   805: invokevirtual equals : (Ljava/lang/Object;)Z
    //   808: ifne -> 840
    //   811: aload_1
    //   812: ldc_w 'none'
    //   815: invokevirtual equals : (Ljava/lang/Object;)Z
    //   818: ifne -> 827
    //   821: aload #7
    //   823: astore_1
    //   824: goto -> 1558
    //   827: aload #7
    //   829: invokestatic B : (La4/g;)La4/g;
    //   832: iconst_0
    //   833: invokevirtual I : (Z)La4/g;
    //   836: astore_1
    //   837: goto -> 1558
    //   840: aload #7
    //   842: invokestatic B : (La4/g;)La4/g;
    //   845: iconst_1
    //   846: invokevirtual I : (Z)La4/g;
    //   849: astore_1
    //   850: goto -> 1558
    //   853: aload #7
    //   855: invokestatic B : (La4/g;)La4/g;
    //   858: aload #8
    //   860: invokestatic L : (Ljava/lang/String;)F
    //   863: invokevirtual G : (F)La4/g;
    //   866: astore_1
    //   867: goto -> 1558
    //   870: aload #7
    //   872: invokestatic B : (La4/g;)La4/g;
    //   875: astore #7
    //   877: aload #7
    //   879: aload #8
    //   881: invokestatic c : (Ljava/lang/String;)I
    //   884: invokevirtual w : (I)La4/g;
    //   887: pop
    //   888: aload #7
    //   890: astore_1
    //   891: goto -> 1558
    //   894: aload #8
    //   896: invokestatic valueOf : (Ljava/lang/Object;)Ljava/lang/String;
    //   899: astore_1
    //   900: aload_1
    //   901: invokevirtual length : ()I
    //   904: ifeq -> 918
    //   907: ldc_w 'Failed parsing color value: '
    //   910: aload_1
    //   911: invokevirtual concat : (Ljava/lang/String;)Ljava/lang/String;
    //   914: astore_1
    //   915: goto -> 929
    //   918: new java/lang/String
    //   921: dup
    //   922: ldc_w 'Failed parsing color value: '
    //   925: invokespecial <init> : (Ljava/lang/String;)V
    //   928: astore_1
    //   929: ldc 'TtmlDecoder'
    //   931: aload_1
    //   932: invokestatic h : (Ljava/lang/String;Ljava/lang/String;)V
    //   935: aload #7
    //   937: astore_1
    //   938: goto -> 1558
    //   941: aload #8
    //   943: invokestatic e : (Ljava/lang/String;)Ljava/lang/String;
    //   946: astore_1
    //   947: aload_1
    //   948: invokevirtual hashCode : ()I
    //   951: pop
    //   952: aload_1
    //   953: invokevirtual hashCode : ()I
    //   956: lookupswitch default -> 1016, -618561360 -> 1109, -410956671 -> 1091, -250518009 -> 1073, -136074796 -> 1055, 3016401 -> 1037, 3556653 -> 1021
    //   1016: iconst_m1
    //   1017: istore_2
    //   1018: goto -> 1124
    //   1021: iload #4
    //   1023: istore_2
    //   1024: aload_1
    //   1025: ldc_w 'text'
    //   1028: invokevirtual equals : (Ljava/lang/Object;)Z
    //   1031: ifne -> 1124
    //   1034: goto -> 1016
    //   1037: aload_1
    //   1038: ldc_w 'base'
    //   1041: invokevirtual equals : (Ljava/lang/Object;)Z
    //   1044: ifne -> 1050
    //   1047: goto -> 1016
    //   1050: iconst_4
    //   1051: istore_2
    //   1052: goto -> 1124
    //   1055: aload_1
    //   1056: ldc_w 'textContainer'
    //   1059: invokevirtual equals : (Ljava/lang/Object;)Z
    //   1062: ifne -> 1068
    //   1065: goto -> 1016
    //   1068: iconst_3
    //   1069: istore_2
    //   1070: goto -> 1124
    //   1073: aload_1
    //   1074: ldc_w 'delimiter'
    //   1077: invokevirtual equals : (Ljava/lang/Object;)Z
    //   1080: ifne -> 1086
    //   1083: goto -> 1016
    //   1086: iconst_2
    //   1087: istore_2
    //   1088: goto -> 1124
    //   1091: aload_1
    //   1092: ldc_w 'container'
    //   1095: invokevirtual equals : (Ljava/lang/Object;)Z
    //   1098: ifne -> 1104
    //   1101: goto -> 1016
    //   1104: iconst_1
    //   1105: istore_2
    //   1106: goto -> 1124
    //   1109: aload_1
    //   1110: ldc_w 'baseContainer'
    //   1113: invokevirtual equals : (Ljava/lang/Object;)Z
    //   1116: ifne -> 1122
    //   1119: goto -> 1016
    //   1122: iconst_0
    //   1123: istore_2
    //   1124: iload_2
    //   1125: tableswitch default -> 1164, 0 -> 1209, 1 -> 1196, 2 -> 1183, 3 -> 1170, 4 -> 1209, 5 -> 1170
    //   1164: aload #7
    //   1166: astore_1
    //   1167: goto -> 1558
    //   1170: aload #7
    //   1172: invokestatic B : (La4/g;)La4/g;
    //   1175: iconst_3
    //   1176: invokevirtual F : (I)La4/g;
    //   1179: astore_1
    //   1180: goto -> 1558
    //   1183: aload #7
    //   1185: invokestatic B : (La4/g;)La4/g;
    //   1188: iconst_4
    //   1189: invokevirtual F : (I)La4/g;
    //   1192: astore_1
    //   1193: goto -> 1558
    //   1196: aload #7
    //   1198: invokestatic B : (La4/g;)La4/g;
    //   1201: iconst_1
    //   1202: invokevirtual F : (I)La4/g;
    //   1205: astore_1
    //   1206: goto -> 1558
    //   1209: aload #7
    //   1211: invokestatic B : (La4/g;)La4/g;
    //   1214: iconst_2
    //   1215: invokevirtual F : (I)La4/g;
    //   1218: astore_1
    //   1219: goto -> 1558
    //   1222: aload #7
    //   1224: astore_1
    //   1225: ldc 'style'
    //   1227: aload_0
    //   1228: invokeinterface getName : ()Ljava/lang/String;
    //   1233: invokevirtual equals : (Ljava/lang/Object;)Z
    //   1236: ifeq -> 1558
    //   1239: aload #7
    //   1241: invokestatic B : (La4/g;)La4/g;
    //   1244: aload #8
    //   1246: invokevirtual A : (Ljava/lang/String;)La4/g;
    //   1249: astore_1
    //   1250: goto -> 1558
    //   1253: aload #7
    //   1255: invokestatic B : (La4/g;)La4/g;
    //   1258: ldc_w 'bold'
    //   1261: aload #8
    //   1263: invokevirtual equalsIgnoreCase : (Ljava/lang/String;)Z
    //   1266: invokevirtual v : (Z)La4/g;
    //   1269: astore_1
    //   1270: goto -> 1558
    //   1273: aload #8
    //   1275: invokestatic e : (Ljava/lang/String;)Ljava/lang/String;
    //   1278: astore_1
    //   1279: aload_1
    //   1280: invokevirtual hashCode : ()I
    //   1283: pop
    //   1284: aload_1
    //   1285: invokevirtual hashCode : ()I
    //   1288: lookupswitch default -> 1332, -1461280213 -> 1401, -1026963764 -> 1380, 913457136 -> 1359, 1679736913 -> 1338
    //   1332: iload #5
    //   1334: istore_2
    //   1335: goto -> 1419
    //   1338: aload_1
    //   1339: ldc_w 'linethrough'
    //   1342: invokevirtual equals : (Ljava/lang/Object;)Z
    //   1345: ifne -> 1354
    //   1348: iload #5
    //   1350: istore_2
    //   1351: goto -> 1419
    //   1354: iconst_3
    //   1355: istore_2
    //   1356: goto -> 1419
    //   1359: aload_1
    //   1360: ldc_w 'nolinethrough'
    //   1363: invokevirtual equals : (Ljava/lang/Object;)Z
    //   1366: ifne -> 1375
    //   1369: iload #5
    //   1371: istore_2
    //   1372: goto -> 1419
    //   1375: iconst_2
    //   1376: istore_2
    //   1377: goto -> 1419
    //   1380: aload_1
    //   1381: ldc_w 'underline'
    //   1384: invokevirtual equals : (Ljava/lang/Object;)Z
    //   1387: ifne -> 1396
    //   1390: iload #5
    //   1392: istore_2
    //   1393: goto -> 1419
    //   1396: iconst_1
    //   1397: istore_2
    //   1398: goto -> 1419
    //   1401: aload_1
    //   1402: ldc_w 'nounderline'
    //   1405: invokevirtual equals : (Ljava/lang/Object;)Z
    //   1408: ifne -> 1417
    //   1411: iload #5
    //   1413: istore_2
    //   1414: goto -> 1419
    //   1417: iconst_0
    //   1418: istore_2
    //   1419: iload_2
    //   1420: tableswitch default -> 1452, 0 -> 1497, 1 -> 1484, 2 -> 1471, 3 -> 1458
    //   1452: aload #7
    //   1454: astore_1
    //   1455: goto -> 1558
    //   1458: aload #7
    //   1460: invokestatic B : (La4/g;)La4/g;
    //   1463: iconst_1
    //   1464: invokevirtual C : (Z)La4/g;
    //   1467: astore_1
    //   1468: goto -> 1558
    //   1471: aload #7
    //   1473: invokestatic B : (La4/g;)La4/g;
    //   1476: iconst_0
    //   1477: invokevirtual C : (Z)La4/g;
    //   1480: astore_1
    //   1481: goto -> 1558
    //   1484: aload #7
    //   1486: invokestatic B : (La4/g;)La4/g;
    //   1489: iconst_1
    //   1490: invokevirtual K : (Z)La4/g;
    //   1493: astore_1
    //   1494: goto -> 1558
    //   1497: aload #7
    //   1499: invokestatic B : (La4/g;)La4/g;
    //   1502: iconst_0
    //   1503: invokevirtual K : (Z)La4/g;
    //   1506: astore_1
    //   1507: goto -> 1558
    //   1510: aload #7
    //   1512: invokestatic B : (La4/g;)La4/g;
    //   1515: aload #8
    //   1517: invokestatic D : (Ljava/lang/String;)Landroid/text/Layout$Alignment;
    //   1520: invokevirtual H : (Landroid/text/Layout$Alignment;)La4/g;
    //   1523: astore_1
    //   1524: goto -> 1558
    //   1527: aload #7
    //   1529: invokestatic B : (La4/g;)La4/g;
    //   1532: aload #8
    //   1534: invokevirtual x : (Ljava/lang/String;)La4/g;
    //   1537: astore_1
    //   1538: goto -> 1558
    //   1541: aload #7
    //   1543: invokestatic B : (La4/g;)La4/g;
    //   1546: ldc_w 'italic'
    //   1549: aload #8
    //   1551: invokevirtual equalsIgnoreCase : (Ljava/lang/String;)Z
    //   1554: invokevirtual B : (Z)La4/g;
    //   1557: astore_1
    //   1558: iload_3
    //   1559: iconst_1
    //   1560: iadd
    //   1561: istore_3
    //   1562: aload_1
    //   1563: astore #7
    //   1565: goto -> 13
    //   1568: aload #7
    //   1570: areturn
    //   1571: astore_1
    //   1572: goto -> 587
    //   1575: astore #7
    //   1577: goto -> 740
    //   1580: astore_1
    //   1581: goto -> 894
    // Exception table:
    //   from	to	target	type
    //   570	581	1571	java/lang/IllegalArgumentException
    //   717	724	1575	t3/g
    //   727	734	1575	t3/g
    //   877	888	1580	java/lang/IllegalArgumentException
  }
  
  private static String[] N(String paramString) {
    paramString = paramString.trim();
    return paramString.isEmpty() ? new String[0] : r0.I0(paramString, "\\s+");
  }
  
  private static long O(String paramString, b paramb) throws g {
    // Byte code:
    //   0: getstatic a4/c.p : Ljava/util/regex/Pattern;
    //   3: aload_0
    //   4: invokevirtual matcher : (Ljava/lang/CharSequence;)Ljava/util/regex/Matcher;
    //   7: astore #16
    //   9: aload #16
    //   11: invokevirtual matches : ()Z
    //   14: istore #15
    //   16: iconst_4
    //   17: istore #14
    //   19: iload #15
    //   21: ifeq -> 193
    //   24: aload #16
    //   26: iconst_1
    //   27: invokevirtual group : (I)Ljava/lang/String;
    //   30: invokestatic e : (Ljava/lang/Object;)Ljava/lang/Object;
    //   33: checkcast java/lang/String
    //   36: invokestatic parseLong : (Ljava/lang/String;)J
    //   39: ldc2_w 3600
    //   42: lmul
    //   43: l2d
    //   44: dstore #8
    //   46: aload #16
    //   48: iconst_2
    //   49: invokevirtual group : (I)Ljava/lang/String;
    //   52: invokestatic e : (Ljava/lang/Object;)Ljava/lang/Object;
    //   55: checkcast java/lang/String
    //   58: invokestatic parseLong : (Ljava/lang/String;)J
    //   61: ldc2_w 60
    //   64: lmul
    //   65: l2d
    //   66: dstore #10
    //   68: aload #16
    //   70: iconst_3
    //   71: invokevirtual group : (I)Ljava/lang/String;
    //   74: invokestatic e : (Ljava/lang/Object;)Ljava/lang/Object;
    //   77: checkcast java/lang/String
    //   80: invokestatic parseLong : (Ljava/lang/String;)J
    //   83: l2d
    //   84: dstore #12
    //   86: aload #16
    //   88: iconst_4
    //   89: invokevirtual group : (I)Ljava/lang/String;
    //   92: astore_0
    //   93: dconst_0
    //   94: dstore #6
    //   96: aload_0
    //   97: ifnull -> 108
    //   100: aload_0
    //   101: invokestatic parseDouble : (Ljava/lang/String;)D
    //   104: dstore_2
    //   105: goto -> 110
    //   108: dconst_0
    //   109: dstore_2
    //   110: aload #16
    //   112: iconst_5
    //   113: invokevirtual group : (I)Ljava/lang/String;
    //   116: astore_0
    //   117: aload_0
    //   118: ifnull -> 137
    //   121: aload_0
    //   122: invokestatic parseLong : (Ljava/lang/String;)J
    //   125: l2f
    //   126: aload_1
    //   127: getfield a : F
    //   130: fdiv
    //   131: f2d
    //   132: dstore #4
    //   134: goto -> 140
    //   137: dconst_0
    //   138: dstore #4
    //   140: aload #16
    //   142: bipush #6
    //   144: invokevirtual group : (I)Ljava/lang/String;
    //   147: astore_0
    //   148: aload_0
    //   149: ifnull -> 171
    //   152: aload_0
    //   153: invokestatic parseLong : (Ljava/lang/String;)J
    //   156: l2d
    //   157: aload_1
    //   158: getfield b : I
    //   161: i2d
    //   162: ddiv
    //   163: aload_1
    //   164: getfield a : F
    //   167: f2d
    //   168: ddiv
    //   169: dstore #6
    //   171: dload #8
    //   173: dload #10
    //   175: dadd
    //   176: dload #12
    //   178: dadd
    //   179: dload_2
    //   180: dadd
    //   181: dload #4
    //   183: dadd
    //   184: dload #6
    //   186: dadd
    //   187: ldc2_w 1000000.0
    //   190: dmul
    //   191: d2l
    //   192: lreturn
    //   193: getstatic a4/c.q : Ljava/util/regex/Pattern;
    //   196: aload_0
    //   197: invokevirtual matcher : (Ljava/lang/CharSequence;)Ljava/util/regex/Matcher;
    //   200: astore #16
    //   202: aload #16
    //   204: invokevirtual matches : ()Z
    //   207: ifeq -> 490
    //   210: aload #16
    //   212: iconst_1
    //   213: invokevirtual group : (I)Ljava/lang/String;
    //   216: invokestatic e : (Ljava/lang/Object;)Ljava/lang/Object;
    //   219: checkcast java/lang/String
    //   222: invokestatic parseDouble : (Ljava/lang/String;)D
    //   225: dstore #4
    //   227: aload #16
    //   229: iconst_2
    //   230: invokevirtual group : (I)Ljava/lang/String;
    //   233: invokestatic e : (Ljava/lang/Object;)Ljava/lang/Object;
    //   236: checkcast java/lang/String
    //   239: astore_0
    //   240: aload_0
    //   241: invokevirtual hashCode : ()I
    //   244: pop
    //   245: aload_0
    //   246: invokevirtual hashCode : ()I
    //   249: lookupswitch default -> 300, 102 -> 376, 104 -> 357, 109 -> 338, 116 -> 319, 3494 -> 306
    //   300: iconst_m1
    //   301: istore #14
    //   303: goto -> 392
    //   306: aload_0
    //   307: ldc_w 'ms'
    //   310: invokevirtual equals : (Ljava/lang/Object;)Z
    //   313: ifne -> 392
    //   316: goto -> 300
    //   319: aload_0
    //   320: ldc_w 't'
    //   323: invokevirtual equals : (Ljava/lang/Object;)Z
    //   326: ifne -> 332
    //   329: goto -> 300
    //   332: iconst_3
    //   333: istore #14
    //   335: goto -> 392
    //   338: aload_0
    //   339: ldc_w 'm'
    //   342: invokevirtual equals : (Ljava/lang/Object;)Z
    //   345: ifne -> 351
    //   348: goto -> 300
    //   351: iconst_2
    //   352: istore #14
    //   354: goto -> 392
    //   357: aload_0
    //   358: ldc_w 'h'
    //   361: invokevirtual equals : (Ljava/lang/Object;)Z
    //   364: ifne -> 370
    //   367: goto -> 300
    //   370: iconst_1
    //   371: istore #14
    //   373: goto -> 392
    //   376: aload_0
    //   377: ldc_w 'f'
    //   380: invokevirtual equals : (Ljava/lang/Object;)Z
    //   383: ifne -> 389
    //   386: goto -> 300
    //   389: iconst_0
    //   390: istore #14
    //   392: iload #14
    //   394: tableswitch default -> 428, 0 -> 474, 1 -> 462, 2 -> 455, 3 -> 446, 4 -> 434
    //   428: dload #4
    //   430: dstore_2
    //   431: goto -> 483
    //   434: ldc2_w 1000.0
    //   437: dstore_2
    //   438: dload #4
    //   440: dload_2
    //   441: ddiv
    //   442: dstore_2
    //   443: goto -> 483
    //   446: aload_1
    //   447: getfield c : I
    //   450: i2d
    //   451: dstore_2
    //   452: goto -> 438
    //   455: ldc2_w 60.0
    //   458: dstore_2
    //   459: goto -> 466
    //   462: ldc2_w 3600.0
    //   465: dstore_2
    //   466: dload #4
    //   468: dload_2
    //   469: dmul
    //   470: dstore_2
    //   471: goto -> 483
    //   474: aload_1
    //   475: getfield a : F
    //   478: f2d
    //   479: dstore_2
    //   480: goto -> 438
    //   483: dload_2
    //   484: ldc2_w 1000000.0
    //   487: dmul
    //   488: d2l
    //   489: lreturn
    //   490: aload_0
    //   491: invokestatic valueOf : (Ljava/lang/Object;)Ljava/lang/String;
    //   494: astore_0
    //   495: aload_0
    //   496: invokevirtual length : ()I
    //   499: ifeq -> 513
    //   502: ldc_w 'Malformed time expression: '
    //   505: aload_0
    //   506: invokevirtual concat : (Ljava/lang/String;)Ljava/lang/String;
    //   509: astore_0
    //   510: goto -> 524
    //   513: new java/lang/String
    //   516: dup
    //   517: ldc_w 'Malformed time expression: '
    //   520: invokespecial <init> : (Ljava/lang/String;)V
    //   523: astore_0
    //   524: new t3/g
    //   527: dup
    //   528: aload_0
    //   529: invokespecial <init> : (Ljava/lang/String;)V
    //   532: athrow
  }
  
  @Nullable
  private static c P(XmlPullParser paramXmlPullParser) {
    String str = s0.a(paramXmlPullParser, "extent");
    if (str == null)
      return null; 
    Matcher matcher = u.matcher(str);
    if (!matcher.matches()) {
      if (str.length() != 0) {
        str = "Ignoring non-pixel tts extent: ".concat(str);
      } else {
        str = new String("Ignoring non-pixel tts extent: ");
      } 
      r.h("TtmlDecoder", str);
      return null;
    } 
    try {
      return new c(Integer.parseInt((String)com.google.android.exoplayer2.util.a.e(matcher.group(1))), Integer.parseInt((String)com.google.android.exoplayer2.util.a.e(matcher.group(2))));
    } catch (NumberFormatException numberFormatException) {
      if (str.length() != 0) {
        str = "Ignoring malformed tts extent: ".concat(str);
      } else {
        str = new String("Ignoring malformed tts extent: ");
      } 
      r.h("TtmlDecoder", str);
      return null;
    } 
  }
  
  protected e z(byte[] paramArrayOfbyte, int paramInt, boolean paramBoolean) throws g {
    h h;
    try {
      XmlPullParser xmlPullParser = this.o.newPullParser();
      HashMap<Object, Object> hashMap1 = new HashMap<Object, Object>();
      HashMap<Object, Object> hashMap2 = new HashMap<Object, Object>();
      HashMap<Object, Object> hashMap3 = new HashMap<Object, Object>();
      hashMap2.put("", new e(""));
      ByteArrayInputStream byteArrayInputStream = new ByteArrayInputStream(paramArrayOfbyte, 0, paramInt);
      c c1 = null;
      xmlPullParser.setInput(byteArrayInputStream, null);
      ArrayDeque<d> arrayDeque = new ArrayDeque();
      int j = xmlPullParser.getEventType();
      b b1 = w;
      a a1 = x;
      h = null;
      int i = 0;
      while (true) {
        if (j != 1) {
          d d = arrayDeque.peek();
          if (!i) {
            c c3;
            String str = xmlPullParser.getName();
            if (j == 2) {
              String str1;
              if ("tt".equals(str)) {
                b1 = G(xmlPullParser);
                a1 = E(xmlPullParser, x);
                c1 = P(xmlPullParser);
              } 
              paramBoolean = C(str);
              if (!paramBoolean) {
                str1 = String.valueOf(xmlPullParser.getName());
                if (str1.length() != 0) {
                  str1 = "Ignoring unsupported tag: ".concat(str1);
                } else {
                  str1 = new String("Ignoring unsupported tag: ");
                } 
                r.f("TtmlDecoder", str1);
                paramInt = i + 1;
              } else if ("head".equals(str)) {
                H(xmlPullParser, (Map)hashMap1, a1, c1, (Map)hashMap2, (Map)hashMap3);
                paramInt = i;
              } else {
                b b3;
                a a3;
                h h2;
                try {
                  d d1 = J(xmlPullParser, (d)str1, (Map)hashMap2, b1);
                  arrayDeque.push(d1);
                  paramInt = i;
                  if (str1 != null) {
                    str1.a(d1);
                    paramInt = i;
                  } 
                  c3 = c1;
                  b3 = b1;
                  a3 = a1;
                  h2 = h;
                } catch (g g) {
                  r.i("TtmlDecoder", "Suppressing parser error", (Throwable)g);
                  paramInt = i + 1;
                  c3 = c1;
                  b3 = b1;
                  a3 = a1;
                  h2 = h;
                } 
                xmlPullParser.next();
                j = xmlPullParser.getEventType();
                c1 = c3;
                b1 = b3;
                a1 = a3;
                i = paramInt;
                h = h2;
              } 
            } else {
              b b3;
              a a3;
              h h2;
              if (j == 4) {
                ((d)com.google.android.exoplayer2.util.a.e(c3)).a(d.d(xmlPullParser.getText()));
                c3 = c1;
                b3 = b1;
                a3 = a1;
                paramInt = i;
                h2 = h;
              } else {
                c3 = c1;
                b3 = b1;
                a3 = a1;
                paramInt = i;
                h2 = h;
                if (j == 3) {
                  if (xmlPullParser.getName().equals("tt"))
                    h = new h((d)com.google.android.exoplayer2.util.a.e(arrayDeque.peek()), (Map)hashMap1, (Map)hashMap2, (Map)hashMap3); 
                  arrayDeque.pop();
                  c3 = c1;
                  b3 = b1;
                  a3 = a1;
                  paramInt = i;
                  h2 = h;
                } 
              } 
              xmlPullParser.next();
              j = xmlPullParser.getEventType();
              c1 = c3;
              b1 = b3;
              a1 = a3;
              i = paramInt;
              h = h2;
            } 
          } else {
            c c3;
            b b3;
            a a3;
            h h2;
            if (j == 2) {
              paramInt = i + 1;
              c3 = c1;
              b3 = b1;
              a3 = a1;
              h2 = h;
            } else {
              c3 = c1;
              b3 = b1;
              a3 = a1;
              paramInt = i;
              h2 = h;
              if (j == 3) {
                paramInt = i - 1;
                c3 = c1;
                b3 = b1;
                a3 = a1;
                h2 = h;
              } 
            } 
            xmlPullParser.next();
            j = xmlPullParser.getEventType();
            c1 = c3;
            b1 = b3;
            a1 = a3;
            i = paramInt;
            h = h2;
          } 
        } else {
          break;
        } 
        c c2 = c1;
        b b2 = b1;
        a a2 = a1;
        h h1 = h;
      } 
    } catch (XmlPullParserException xmlPullParserException) {
      throw new g("Unable to decode source", xmlPullParserException);
    } catch (IOException iOException) {
      throw new IllegalStateException("Unexpected error when reading input.", iOException);
    } 
    if (h != null)
      return h; 
    throw new g("No TTML subtitles found");
  }
  
  private static final class a {
    final int a;
    
    final int b;
    
    a(int param1Int1, int param1Int2) {
      this.a = param1Int1;
      this.b = param1Int2;
    }
  }
  
  private static final class b {
    final float a;
    
    final int b;
    
    final int c;
    
    b(float param1Float, int param1Int1, int param1Int2) {
      this.a = param1Float;
      this.b = param1Int1;
      this.c = param1Int2;
    }
  }
  
  private static final class c {
    final int a;
    
    final int b;
    
    c(int param1Int1, int param1Int2) {
      this.a = param1Int1;
      this.b = param1Int2;
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\BabyBus TV_Kids Videos & Games-dex2jar.jar!\a4\c.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */