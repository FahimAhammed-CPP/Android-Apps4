package a4;

import com.google.android.exoplayer2.util.r0;
import java.util.Collections;
import java.util.List;
import java.util.Map;
import t3.a;
import t3.e;

final class h implements e {
  private final d a;
  
  private final long[] d;
  
  private final Map<String, g> h;
  
  private final Map<String, e> l;
  
  private final Map<String, String> s;
  
  public h(d paramd, Map<String, g> paramMap, Map<String, e> paramMap1, Map<String, String> paramMap2) {
    this.a = paramd;
    this.l = paramMap1;
    this.s = paramMap2;
    if (paramMap != null) {
      paramMap = Collections.unmodifiableMap(paramMap);
    } else {
      paramMap = Collections.emptyMap();
    } 
    this.h = paramMap;
    this.d = paramd.j();
  }
  
  public int b(long paramLong) {
    int i = r0.e(this.d, paramLong, false, false);
    return (i < this.d.length) ? i : -1;
  }
  
  public List<a> c(long paramLong) {
    return this.a.h(paramLong, this.h, this.l, this.s);
  }
  
  public long d(int paramInt) {
    return this.d[paramInt];
  }
  
  public int e() {
    return this.d.length;
  }
}


/* Location:              C:\soft\dex2jar-2.0\BabyBus TV_Kids Videos & Games-dex2jar.jar!\a4\h.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */