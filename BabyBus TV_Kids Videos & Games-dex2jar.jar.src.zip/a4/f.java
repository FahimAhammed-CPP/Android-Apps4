package a4;

import android.text.Spannable;
import android.text.SpannableStringBuilder;
import android.text.style.AbsoluteSizeSpan;
import android.text.style.BackgroundColorSpan;
import android.text.style.ForegroundColorSpan;
import android.text.style.RelativeSizeSpan;
import android.text.style.StrikethroughSpan;
import android.text.style.StyleSpan;
import android.text.style.TypefaceSpan;
import android.text.style.UnderlineSpan;
import androidx.annotation.Nullable;
import com.google.android.exoplayer2.util.a;
import com.google.android.exoplayer2.util.r;
import com.google.android.exoplayer2.util.r0;
import java.util.ArrayDeque;
import java.util.Map;
import x3.a;
import x3.c;
import x3.d;
import x3.e;

final class f {
  public static void a(Spannable paramSpannable, int paramInt1, int paramInt2, g paramg, @Nullable d paramd, Map<String, g> paramMap, int paramInt3) {
    if (paramg.l() != -1)
      paramSpannable.setSpan(new StyleSpan(paramg.l()), paramInt1, paramInt2, 33); 
    if (paramg.s())
      paramSpannable.setSpan(new StrikethroughSpan(), paramInt1, paramInt2, 33); 
    if (paramg.t())
      paramSpannable.setSpan(new UnderlineSpan(), paramInt1, paramInt2, 33); 
    if (paramg.q())
      d.a(paramSpannable, new ForegroundColorSpan(paramg.c()), paramInt1, paramInt2, 33); 
    if (paramg.p())
      d.a(paramSpannable, new BackgroundColorSpan(paramg.b()), paramInt1, paramInt2, 33); 
    if (paramg.d() != null)
      d.a(paramSpannable, new TypefaceSpan(paramg.d()), paramInt1, paramInt2, 33); 
    if (paramg.o() != null) {
      int i;
      b b = (b)a.e(paramg.o());
      int j = b.a;
      if (j == -1) {
        if (paramInt3 == 2 || paramInt3 == 1) {
          paramInt3 = 3;
        } else {
          paramInt3 = 1;
        } 
        i = 1;
      } else {
        i = b.b;
        paramInt3 = j;
      } 
      int k = b.c;
      j = k;
      if (k == -2)
        j = 1; 
      d.a(paramSpannable, new e(paramInt3, i, j), paramInt1, paramInt2, 33);
    } 
    paramInt3 = paramg.j();
    if (paramInt3 != 2) {
      if (paramInt3 == 3 || paramInt3 == 4)
        paramSpannable.setSpan(new a(), paramInt1, paramInt2, 33); 
    } else {
      d d1 = d(paramd, paramMap);
      if (d1 != null) {
        d d2 = e(d1, paramMap);
        if (d2 != null)
          if (d2.g() == 1 && (d2.f(0)).b != null) {
            String str = (String)r0.j((d2.f(0)).b);
            g g1 = f(d2.f, d2.l(), paramMap);
            if (g1 != null) {
              paramInt3 = g1.i();
            } else {
              paramInt3 = -1;
            } 
            int i = paramInt3;
            if (paramInt3 == -1) {
              g g2 = f(d1.f, d1.l(), paramMap);
              i = paramInt3;
              if (g2 != null)
                i = g2.i(); 
            } 
            paramSpannable.setSpan(new c(str, i), paramInt1, paramInt2, 33);
          } else {
            r.f("TtmlRenderUtil", "Skipping rubyText node without exactly one text child.");
          }  
      } 
    } 
    if (paramg.n())
      d.a(paramSpannable, new a(), paramInt1, paramInt2, 33); 
    paramInt3 = paramg.f();
    if (paramInt3 != 1) {
      if (paramInt3 != 2) {
        if (paramInt3 != 3)
          return; 
        d.a(paramSpannable, new RelativeSizeSpan(paramg.e() / 100.0F), paramInt1, paramInt2, 33);
        return;
      } 
      d.a(paramSpannable, new RelativeSizeSpan(paramg.e()), paramInt1, paramInt2, 33);
      return;
    } 
    d.a(paramSpannable, new AbsoluteSizeSpan((int)paramg.e(), true), paramInt1, paramInt2, 33);
  }
  
  static String b(String paramString) {
    return paramString.replaceAll("\r\n", "\n").replaceAll(" *\n *", "\n").replaceAll("\n", " ").replaceAll("[ \t\\x0B\f\r]+", " ");
  }
  
  static void c(SpannableStringBuilder paramSpannableStringBuilder) {
    int i;
    for (i = paramSpannableStringBuilder.length() - 1; i >= 0 && paramSpannableStringBuilder.charAt(i) == ' '; i--);
    if (i >= 0 && paramSpannableStringBuilder.charAt(i) != '\n')
      paramSpannableStringBuilder.append('\n'); 
  }
  
  @Nullable
  private static d d(@Nullable d paramd, Map<String, g> paramMap) {
    while (paramd != null) {
      g g = f(paramd.f, paramd.l(), paramMap);
      if (g != null && g.j() == 1)
        return paramd; 
      paramd = paramd.j;
    } 
    return null;
  }
  
  @Nullable
  private static d e(d paramd, Map<String, g> paramMap) {
    ArrayDeque<d> arrayDeque = new ArrayDeque();
    arrayDeque.push(paramd);
    while (!arrayDeque.isEmpty()) {
      paramd = arrayDeque.pop();
      g g = f(paramd.f, paramd.l(), paramMap);
      if (g != null && g.j() == 3)
        return paramd; 
      for (int i = paramd.g() - 1; i >= 0; i--)
        arrayDeque.push(paramd.f(i)); 
    } 
    return null;
  }
  
  @Nullable
  public static g f(@Nullable g paramg, @Nullable String[] paramArrayOfString, Map<String, g> paramMap) {
    int j = 0;
    int i = 0;
    if (paramg == null) {
      if (paramArrayOfString == null)
        return null; 
      if (paramArrayOfString.length == 1)
        return paramMap.get(paramArrayOfString[0]); 
      if (paramArrayOfString.length > 1) {
        paramg = new g();
        j = paramArrayOfString.length;
        while (i < j) {
          paramg.a(paramMap.get(paramArrayOfString[i]));
          i++;
        } 
        return paramg;
      } 
    } else {
      if (paramArrayOfString != null && paramArrayOfString.length == 1)
        return paramg.a(paramMap.get(paramArrayOfString[0])); 
      if (paramArrayOfString != null && paramArrayOfString.length > 1) {
        int k = paramArrayOfString.length;
        for (i = j; i < k; i++)
          paramg.a(paramMap.get(paramArrayOfString[i])); 
      } 
    } 
    return paramg;
  }
}


/* Location:              C:\soft\dex2jar-2.0\BabyBus TV_Kids Videos & Games-dex2jar.jar!\a4\f.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */