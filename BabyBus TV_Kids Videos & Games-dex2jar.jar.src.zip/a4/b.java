package a4;

import android.text.TextUtils;
import androidx.annotation.Nullable;
import com.google.common.collect.k0;
import java.util.regex.Pattern;

final class b {
  private static final Pattern d = Pattern.compile("\\s+");
  
  private static final k0<String> e = k0.of("auto", "none");
  
  private static final k0<String> f = k0.of("dot", "sesame", "circle");
  
  private static final k0<String> g = k0.of("filled", "open");
  
  private static final k0<String> h = k0.of("after", "before", "outside");
  
  public final int a;
  
  public final int b;
  
  public final int c;
  
  private b(int paramInt1, int paramInt2, int paramInt3) {
    this.a = paramInt1;
    this.b = paramInt2;
    this.c = paramInt3;
  }
  
  @Nullable
  public static b a(@Nullable String paramString) {
    if (paramString == null)
      return null; 
    paramString = com.google.common.base.b.e(paramString.trim());
    return paramString.isEmpty() ? null : b(k0.copyOf((Object[])TextUtils.split(paramString, d)));
  }
  
  private static b b(k0<String> paramk0) {
    // Byte code:
    //   0: getstatic a4/b.h : Lcom/google/common/collect/k0;
    //   3: aload_0
    //   4: invokestatic c : (Ljava/util/Set;Ljava/util/Set;)Lcom/google/common/collect/t1$c;
    //   7: ldc 'outside'
    //   9: invokestatic b : (Ljava/lang/Iterable;Ljava/lang/Object;)Ljava/lang/Object;
    //   12: checkcast java/lang/String
    //   15: astore #6
    //   17: aload #6
    //   19: invokevirtual hashCode : ()I
    //   22: istore_1
    //   23: iconst_2
    //   24: istore #5
    //   26: iconst_m1
    //   27: istore_3
    //   28: iconst_1
    //   29: istore #4
    //   31: iload_1
    //   32: ldc -1392885889
    //   34: if_icmpeq -> 82
    //   37: iload_1
    //   38: ldc -1106037339
    //   40: if_icmpeq -> 67
    //   43: iload_1
    //   44: ldc 92734940
    //   46: if_icmpeq -> 52
    //   49: goto -> 97
    //   52: aload #6
    //   54: ldc 'after'
    //   56: invokevirtual equals : (Ljava/lang/Object;)Z
    //   59: ifeq -> 97
    //   62: iconst_0
    //   63: istore_1
    //   64: goto -> 99
    //   67: aload #6
    //   69: ldc 'outside'
    //   71: invokevirtual equals : (Ljava/lang/Object;)Z
    //   74: ifeq -> 97
    //   77: iconst_1
    //   78: istore_1
    //   79: goto -> 99
    //   82: aload #6
    //   84: ldc 'before'
    //   86: invokevirtual equals : (Ljava/lang/Object;)Z
    //   89: ifeq -> 97
    //   92: iconst_2
    //   93: istore_1
    //   94: goto -> 99
    //   97: iconst_m1
    //   98: istore_1
    //   99: iload_1
    //   100: ifeq -> 119
    //   103: iload_1
    //   104: iconst_1
    //   105: if_icmpeq -> 113
    //   108: iconst_1
    //   109: istore_2
    //   110: goto -> 121
    //   113: bipush #-2
    //   115: istore_2
    //   116: goto -> 121
    //   119: iconst_2
    //   120: istore_2
    //   121: getstatic a4/b.e : Lcom/google/common/collect/k0;
    //   124: aload_0
    //   125: invokestatic c : (Ljava/util/Set;Ljava/util/Set;)Lcom/google/common/collect/t1$c;
    //   128: astore #6
    //   130: aload #6
    //   132: invokeinterface isEmpty : ()Z
    //   137: ifne -> 227
    //   140: aload #6
    //   142: invokeinterface iterator : ()Ljava/util/Iterator;
    //   147: invokeinterface next : ()Ljava/lang/Object;
    //   152: checkcast java/lang/String
    //   155: astore_0
    //   156: aload_0
    //   157: invokevirtual hashCode : ()I
    //   160: istore_1
    //   161: iload_1
    //   162: ldc 3005871
    //   164: if_icmpeq -> 190
    //   167: iload_1
    //   168: ldc 3387192
    //   170: if_icmpeq -> 176
    //   173: goto -> 205
    //   176: aload_0
    //   177: ldc 'none'
    //   179: invokevirtual equals : (Ljava/lang/Object;)Z
    //   182: ifeq -> 205
    //   185: iconst_0
    //   186: istore_1
    //   187: goto -> 207
    //   190: aload_0
    //   191: ldc 'auto'
    //   193: invokevirtual equals : (Ljava/lang/Object;)Z
    //   196: ifeq -> 205
    //   199: iload #4
    //   201: istore_1
    //   202: goto -> 207
    //   205: iconst_m1
    //   206: istore_1
    //   207: iload_1
    //   208: ifeq -> 214
    //   211: goto -> 216
    //   214: iconst_0
    //   215: istore_3
    //   216: new a4/b
    //   219: dup
    //   220: iload_3
    //   221: iconst_0
    //   222: iload_2
    //   223: invokespecial <init> : (III)V
    //   226: areturn
    //   227: getstatic a4/b.g : Lcom/google/common/collect/k0;
    //   230: aload_0
    //   231: invokestatic c : (Ljava/util/Set;Ljava/util/Set;)Lcom/google/common/collect/t1$c;
    //   234: astore #6
    //   236: getstatic a4/b.f : Lcom/google/common/collect/k0;
    //   239: aload_0
    //   240: invokestatic c : (Ljava/util/Set;Ljava/util/Set;)Lcom/google/common/collect/t1$c;
    //   243: astore_0
    //   244: aload #6
    //   246: invokeinterface isEmpty : ()Z
    //   251: ifeq -> 274
    //   254: aload_0
    //   255: invokeinterface isEmpty : ()Z
    //   260: ifeq -> 274
    //   263: new a4/b
    //   266: dup
    //   267: iconst_m1
    //   268: iconst_0
    //   269: iload_2
    //   270: invokespecial <init> : (III)V
    //   273: areturn
    //   274: aload #6
    //   276: ldc 'filled'
    //   278: invokestatic b : (Ljava/lang/Iterable;Ljava/lang/Object;)Ljava/lang/Object;
    //   281: checkcast java/lang/String
    //   284: astore #6
    //   286: aload #6
    //   288: invokevirtual hashCode : ()I
    //   291: istore_1
    //   292: iload_1
    //   293: ldc -1274499742
    //   295: if_icmpeq -> 322
    //   298: iload_1
    //   299: ldc 3417674
    //   301: if_icmpeq -> 307
    //   304: goto -> 337
    //   307: aload #6
    //   309: ldc 'open'
    //   311: invokevirtual equals : (Ljava/lang/Object;)Z
    //   314: ifeq -> 337
    //   317: iconst_0
    //   318: istore_1
    //   319: goto -> 339
    //   322: aload #6
    //   324: ldc 'filled'
    //   326: invokevirtual equals : (Ljava/lang/Object;)Z
    //   329: ifeq -> 337
    //   332: iconst_1
    //   333: istore_1
    //   334: goto -> 339
    //   337: iconst_m1
    //   338: istore_1
    //   339: iload_1
    //   340: ifeq -> 349
    //   343: iconst_1
    //   344: istore #4
    //   346: goto -> 352
    //   349: iconst_2
    //   350: istore #4
    //   352: aload_0
    //   353: ldc 'circle'
    //   355: invokestatic b : (Ljava/lang/Iterable;Ljava/lang/Object;)Ljava/lang/Object;
    //   358: checkcast java/lang/String
    //   361: astore_0
    //   362: aload_0
    //   363: invokevirtual hashCode : ()I
    //   366: istore_1
    //   367: iload_1
    //   368: ldc -1360216880
    //   370: if_icmpeq -> 422
    //   373: iload_1
    //   374: ldc -905816648
    //   376: if_icmpeq -> 406
    //   379: iload_1
    //   380: ldc 99657
    //   382: if_icmpeq -> 390
    //   385: iload_3
    //   386: istore_1
    //   387: goto -> 435
    //   390: iload_3
    //   391: istore_1
    //   392: aload_0
    //   393: ldc 'dot'
    //   395: invokevirtual equals : (Ljava/lang/Object;)Z
    //   398: ifeq -> 435
    //   401: iconst_0
    //   402: istore_1
    //   403: goto -> 435
    //   406: iload_3
    //   407: istore_1
    //   408: aload_0
    //   409: ldc 'sesame'
    //   411: invokevirtual equals : (Ljava/lang/Object;)Z
    //   414: ifeq -> 435
    //   417: iconst_1
    //   418: istore_1
    //   419: goto -> 435
    //   422: iload_3
    //   423: istore_1
    //   424: aload_0
    //   425: ldc 'circle'
    //   427: invokevirtual equals : (Ljava/lang/Object;)Z
    //   430: ifeq -> 435
    //   433: iconst_2
    //   434: istore_1
    //   435: iload #5
    //   437: istore_3
    //   438: iload_1
    //   439: ifeq -> 454
    //   442: iload_1
    //   443: iconst_1
    //   444: if_icmpeq -> 452
    //   447: iconst_1
    //   448: istore_3
    //   449: goto -> 454
    //   452: iconst_3
    //   453: istore_3
    //   454: new a4/b
    //   457: dup
    //   458: iload_3
    //   459: iload #4
    //   461: iload_2
    //   462: invokespecial <init> : (III)V
    //   465: areturn
  }
}


/* Location:              C:\soft\dex2jar-2.0\BabyBus TV_Kids Videos & Games-dex2jar.jar!\a4\b.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */