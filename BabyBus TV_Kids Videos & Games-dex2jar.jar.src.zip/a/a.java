package a;

import android.graphics.Rect;
import android.view.MotionEvent;
import android.view.ViewParent;

public interface a {
  boolean a(MotionEvent paramMotionEvent);
  
  boolean getGlobalVisibleRect(Rect paramRect);
  
  int getHeight();
  
  ViewParent getParent();
  
  int getWidth();
  
  void postInvalidate();
}


/* Location:              C:\soft\dex2jar-2.0\BabyBus TV_Kids Videos & Games-dex2jar.jar!\a\a.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */