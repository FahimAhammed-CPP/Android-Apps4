package a3;

import androidx.annotation.Nullable;
import androidx.annotation.VisibleForTesting;
import com.google.android.exoplayer2.Format;
import com.google.android.exoplayer2.metadata.Metadata;
import com.google.android.exoplayer2.metadata.id3.ApicFrame;
import com.google.android.exoplayer2.metadata.id3.CommentFrame;
import com.google.android.exoplayer2.metadata.id3.Id3Frame;
import com.google.android.exoplayer2.metadata.id3.InternalFrame;
import com.google.android.exoplayer2.metadata.id3.TextInformationFrame;
import com.google.android.exoplayer2.metadata.mp4.MdtaMetadataEntry;
import com.google.android.exoplayer2.util.b0;
import com.google.android.exoplayer2.util.r;
import t2.u;

final class h {
  @VisibleForTesting
  static final String[] a = new String[] { 
      "Blues", "Classic Rock", "Country", "Dance", "Disco", "Funk", "Grunge", "Hip-Hop", "Jazz", "Metal", 
      "New Age", "Oldies", "Other", "Pop", "R&B", "Rap", "Reggae", "Rock", "Techno", "Industrial", 
      "Alternative", "Ska", "Death Metal", "Pranks", "Soundtrack", "Euro-Techno", "Ambient", "Trip-Hop", "Vocal", "Jazz+Funk", 
      "Fusion", "Trance", "Classical", "Instrumental", "Acid", "House", "Game", "Sound Clip", "Gospel", "Noise", 
      "AlternRock", "Bass", "Soul", "Punk", "Space", "Meditative", "Instrumental Pop", "Instrumental Rock", "Ethnic", "Gothic", 
      "Darkwave", "Techno-Industrial", "Electronic", "Pop-Folk", "Eurodance", "Dream", "Southern Rock", "Comedy", "Cult", "Gangsta", 
      "Top 40", "Christian Rap", "Pop/Funk", "Jungle", "Native American", "Cabaret", "New Wave", "Psychadelic", "Rave", "Showtunes", 
      "Trailer", "Lo-Fi", "Tribal", "Acid Punk", "Acid Jazz", "Polka", "Retro", "Musical", "Rock & Roll", "Hard Rock", 
      "Folk", "Folk-Rock", "National Folk", "Swing", "Fast Fusion", "Bebob", "Latin", "Revival", "Celtic", "Bluegrass", 
      "Avantgarde", "Gothic Rock", "Progressive Rock", "Psychedelic Rock", "Symphonic Rock", "Slow Rock", "Big Band", "Chorus", "Easy Listening", "Acoustic", 
      "Humour", "Speech", "Chanson", "Opera", "Chamber Music", "Sonata", "Symphony", "Booty Bass", "Primus", "Porn Groove", 
      "Satire", "Slow Jam", "Club", "Tango", "Samba", "Folklore", "Ballad", "Power Ballad", "Rhythmic Soul", "Freestyle", 
      "Duet", "Punk Rock", "Drum Solo", "A capella", "Euro-House", "Dance Hall", "Goa", "Drum & Bass", "Club-House", "Hardcore", 
      "Terror", "Indie", "BritPop", "Afro-Punk", "Polsk Punk", "Beat", "Christian Gangsta Rap", "Heavy Metal", "Black Metal", "Crossover", 
      "Contemporary Christian", "Christian Rock", "Merengue", "Salsa", "Thrash Metal", "Anime", "Jpop", "Synthpop", "Abstract", "Art Rock", 
      "Baroque", "Bhangra", "Big beat", "Breakbeat", "Chillout", "Downtempo", "Dub", "EBM", "Eclectic", "Electro", 
      "Electroclash", "Emo", "Experimental", "Garage", "Global", "IDM", "Illbient", "Industro-Goth", "Jam Band", "Krautrock", 
      "Leftfield", "Lounge", "Math Rock", "New Romantic", "Nu-Breakz", "Post-Punk", "Post-Rock", "Psytrance", "Shoegaze", "Space Rock", 
      "Trop Rock", "World Music", "Neoclassical", "Audiobook", "Audio theatre", "Neue Deutsche Welle", "Podcast", "Indie-Rock", "G-Funk", "Dubstep", 
      "Garage Rock", "Psybient" };
  
  @Nullable
  private static CommentFrame a(int paramInt, b0 paramb0) {
    int i = paramb0.n();
    if (paramb0.n() == 1684108385) {
      paramb0.Q(8);
      String str1 = paramb0.y(i - 16);
      return new CommentFrame("und", str1, str1);
    } 
    String str = String.valueOf(a.a(paramInt));
    if (str.length() != 0) {
      str = "Failed to parse comment attribute: ".concat(str);
    } else {
      str = new String("Failed to parse comment attribute: ");
    } 
    r.h("MetadataUtil", str);
    return null;
  }
  
  @Nullable
  private static ApicFrame b(b0 paramb0) {
    int i = paramb0.n();
    if (paramb0.n() == 1684108385) {
      StringBuilder stringBuilder;
      String str;
      int j = a.b(paramb0.n());
      if (j == 13) {
        str = "image/jpeg";
      } else if (j == 14) {
        str = "image/png";
      } else {
        str = null;
      } 
      if (str == null) {
        stringBuilder = new StringBuilder(41);
        stringBuilder.append("Unrecognized cover art flags: ");
        stringBuilder.append(j);
        r.h("MetadataUtil", stringBuilder.toString());
        return null;
      } 
      stringBuilder.Q(4);
      i -= 16;
      byte[] arrayOfByte = new byte[i];
      stringBuilder.j(arrayOfByte, 0, i);
      return new ApicFrame(str, null, 3, arrayOfByte);
    } 
    r.h("MetadataUtil", "Failed to parse cover art attribute");
    return null;
  }
  
  @Nullable
  public static Metadata.Entry c(b0 paramb0) {
    int i = paramb0.e() + paramb0.n();
    int j = paramb0.n();
    int k = j >> 24 & 0xFF;
    if (k == 169 || k == 253) {
      k = 0xFFFFFF & j;
      if (k == 6516084) {
        CommentFrame commentFrame = a(j, paramb0);
        paramb0.P(i);
        return (Metadata.Entry)commentFrame;
      } 
      if (k == 7233901 || k == 7631467) {
        TextInformationFrame textInformationFrame = h(j, "TIT2", paramb0);
        paramb0.P(i);
        return (Metadata.Entry)textInformationFrame;
      } 
      if (k == 6516589 || k == 7828084) {
        TextInformationFrame textInformationFrame = h(j, "TCOM", paramb0);
        paramb0.P(i);
        return (Metadata.Entry)textInformationFrame;
      } 
      if (k == 6578553) {
        TextInformationFrame textInformationFrame = h(j, "TDRC", paramb0);
        paramb0.P(i);
        return (Metadata.Entry)textInformationFrame;
      } 
      if (k == 4280916) {
        TextInformationFrame textInformationFrame = h(j, "TPE1", paramb0);
        paramb0.P(i);
        return (Metadata.Entry)textInformationFrame;
      } 
      if (k == 7630703) {
        TextInformationFrame textInformationFrame = h(j, "TSSE", paramb0);
        paramb0.P(i);
        return (Metadata.Entry)textInformationFrame;
      } 
      if (k == 6384738) {
        TextInformationFrame textInformationFrame = h(j, "TALB", paramb0);
        paramb0.P(i);
        return (Metadata.Entry)textInformationFrame;
      } 
      if (k == 7108978) {
        TextInformationFrame textInformationFrame = h(j, "USLT", paramb0);
        paramb0.P(i);
        return (Metadata.Entry)textInformationFrame;
      } 
      if (k == 6776174) {
        TextInformationFrame textInformationFrame = h(j, "TCON", paramb0);
        paramb0.P(i);
        return (Metadata.Entry)textInformationFrame;
      } 
      if (k == 6779504) {
        TextInformationFrame textInformationFrame = h(j, "TIT1", paramb0);
        paramb0.P(i);
        return (Metadata.Entry)textInformationFrame;
      } 
    } else {
      if (j == 1735291493)
        try {
          return (Metadata.Entry)g(paramb0);
        } finally {
          paramb0.P(i);
        }  
      if (j == 1684632427) {
        TextInformationFrame textInformationFrame = d(j, "TPOS", paramb0);
        paramb0.P(i);
        return (Metadata.Entry)textInformationFrame;
      } 
      if (j == 1953655662) {
        TextInformationFrame textInformationFrame = d(j, "TRCK", paramb0);
        paramb0.P(i);
        return (Metadata.Entry)textInformationFrame;
      } 
      if (j == 1953329263) {
        Id3Frame id3Frame = i(j, "TBPM", paramb0, true, false);
        paramb0.P(i);
        return (Metadata.Entry)id3Frame;
      } 
      if (j == 1668311404) {
        Id3Frame id3Frame = i(j, "TCMP", paramb0, true, true);
        paramb0.P(i);
        return (Metadata.Entry)id3Frame;
      } 
      if (j == 1668249202) {
        ApicFrame apicFrame = b(paramb0);
        paramb0.P(i);
        return (Metadata.Entry)apicFrame;
      } 
      if (j == 1631670868) {
        TextInformationFrame textInformationFrame = h(j, "TPE2", paramb0);
        paramb0.P(i);
        return (Metadata.Entry)textInformationFrame;
      } 
      if (j == 1936682605) {
        TextInformationFrame textInformationFrame = h(j, "TSOT", paramb0);
        paramb0.P(i);
        return (Metadata.Entry)textInformationFrame;
      } 
      if (j == 1936679276) {
        TextInformationFrame textInformationFrame = h(j, "TSO2", paramb0);
        paramb0.P(i);
        return (Metadata.Entry)textInformationFrame;
      } 
      if (j == 1936679282) {
        TextInformationFrame textInformationFrame = h(j, "TSOA", paramb0);
        paramb0.P(i);
        return (Metadata.Entry)textInformationFrame;
      } 
      if (j == 1936679265) {
        TextInformationFrame textInformationFrame = h(j, "TSOP", paramb0);
        paramb0.P(i);
        return (Metadata.Entry)textInformationFrame;
      } 
      if (j == 1936679791) {
        TextInformationFrame textInformationFrame = h(j, "TSOC", paramb0);
        paramb0.P(i);
        return (Metadata.Entry)textInformationFrame;
      } 
      if (j == 1920233063) {
        Id3Frame id3Frame = i(j, "ITUNESADVISORY", paramb0, false, false);
        paramb0.P(i);
        return (Metadata.Entry)id3Frame;
      } 
      if (j == 1885823344) {
        Id3Frame id3Frame = i(j, "ITUNESGAPLESS", paramb0, false, true);
        paramb0.P(i);
        return (Metadata.Entry)id3Frame;
      } 
      if (j == 1936683886) {
        TextInformationFrame textInformationFrame = h(j, "TVSHOWSORT", paramb0);
        paramb0.P(i);
        return (Metadata.Entry)textInformationFrame;
      } 
      if (j == 1953919848) {
        TextInformationFrame textInformationFrame = h(j, "TVSHOW", paramb0);
        paramb0.P(i);
        return (Metadata.Entry)textInformationFrame;
      } 
      if (j == 757935405) {
        Id3Frame id3Frame = e(paramb0, i);
        paramb0.P(i);
        return (Metadata.Entry)id3Frame;
      } 
    } 
    String str = String.valueOf(a.a(j));
    if (str.length() != 0) {
      str = "Skipped unknown metadata entry: ".concat(str);
    } else {
      str = new String("Skipped unknown metadata entry: ");
    } 
    r.b("MetadataUtil", str);
    paramb0.P(i);
    return null;
  }
  
  @Nullable
  private static TextInformationFrame d(int paramInt, String paramString, b0 paramb0) {
    int i = paramb0.n();
    if (paramb0.n() == 1684108385 && i >= 22) {
      paramb0.Q(10);
      i = paramb0.J();
      if (i > 0) {
        StringBuilder stringBuilder = new StringBuilder(11);
        stringBuilder.append(i);
        String str2 = stringBuilder.toString();
        paramInt = paramb0.J();
        String str1 = str2;
        if (paramInt > 0) {
          str1 = String.valueOf(str2);
          StringBuilder stringBuilder1 = new StringBuilder(str1.length() + 12);
          stringBuilder1.append(str1);
          stringBuilder1.append("/");
          stringBuilder1.append(paramInt);
          str1 = stringBuilder1.toString();
        } 
        return new TextInformationFrame(paramString, null, str1);
      } 
    } 
    paramString = String.valueOf(a.a(paramInt));
    if (paramString.length() != 0) {
      paramString = "Failed to parse index/count attribute: ".concat(paramString);
    } else {
      paramString = new String("Failed to parse index/count attribute: ");
    } 
    r.h("MetadataUtil", paramString);
    return null;
  }
  
  @Nullable
  private static Id3Frame e(b0 paramb0, int paramInt) {
    String str2 = null;
    String str1 = str2;
    int j = -1;
    int i = -1;
    while (paramb0.e() < paramInt) {
      int m = paramb0.e();
      int k = paramb0.n();
      int n = paramb0.n();
      paramb0.Q(4);
      if (n == 1835360622) {
        str2 = paramb0.y(k - 12);
        continue;
      } 
      if (n == 1851878757) {
        str1 = paramb0.y(k - 12);
        continue;
      } 
      if (n == 1684108385) {
        j = m;
        i = k;
      } 
      paramb0.Q(k - 12);
    } 
    if (str2 != null && str1 != null) {
      if (j == -1)
        return null; 
      paramb0.P(j);
      paramb0.Q(16);
      return (Id3Frame)new InternalFrame(str2, str1, paramb0.y(i - 16));
    } 
    return null;
  }
  
  @Nullable
  public static MdtaMetadataEntry f(b0 paramb0, int paramInt, String paramString) {
    while (true) {
      int i = paramb0.e();
      if (i < paramInt) {
        int j = paramb0.n();
        if (paramb0.n() == 1684108385) {
          paramInt = paramb0.n();
          i = paramb0.n();
          j -= 16;
          byte[] arrayOfByte = new byte[j];
          paramb0.j(arrayOfByte, 0, j);
          return new MdtaMetadataEntry(paramString, arrayOfByte, i, paramInt);
        } 
        paramb0.P(i + j);
        continue;
      } 
      return null;
    } 
  }
  
  @Nullable
  private static TextInformationFrame g(b0 paramb0) {
    // Byte code:
    //   0: aload_0
    //   1: invokestatic j : (Lcom/google/android/exoplayer2/util/b0;)I
    //   4: istore_1
    //   5: iload_1
    //   6: ifle -> 28
    //   9: getstatic a3/h.a : [Ljava/lang/String;
    //   12: astore_0
    //   13: iload_1
    //   14: aload_0
    //   15: arraylength
    //   16: if_icmpgt -> 28
    //   19: aload_0
    //   20: iload_1
    //   21: iconst_1
    //   22: isub
    //   23: aaload
    //   24: astore_0
    //   25: goto -> 30
    //   28: aconst_null
    //   29: astore_0
    //   30: aload_0
    //   31: ifnull -> 47
    //   34: new com/google/android/exoplayer2/metadata/id3/TextInformationFrame
    //   37: dup
    //   38: ldc_w 'TCON'
    //   41: aconst_null
    //   42: aload_0
    //   43: invokespecial <init> : (Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)V
    //   46: areturn
    //   47: ldc_w 'MetadataUtil'
    //   50: ldc_w 'Failed to parse standard genre code'
    //   53: invokestatic h : (Ljava/lang/String;Ljava/lang/String;)V
    //   56: aconst_null
    //   57: areturn
  }
  
  @Nullable
  private static TextInformationFrame h(int paramInt, String paramString, b0 paramb0) {
    int i = paramb0.n();
    if (paramb0.n() == 1684108385) {
      paramb0.Q(8);
      return new TextInformationFrame(paramString, null, paramb0.y(i - 16));
    } 
    paramString = String.valueOf(a.a(paramInt));
    if (paramString.length() != 0) {
      paramString = "Failed to parse text attribute: ".concat(paramString);
    } else {
      paramString = new String("Failed to parse text attribute: ");
    } 
    r.h("MetadataUtil", paramString);
    return null;
  }
  
  @Nullable
  private static Id3Frame i(int paramInt, String paramString, b0 paramb0, boolean paramBoolean1, boolean paramBoolean2) {
    int j = j(paramb0);
    int i = j;
    if (paramBoolean2)
      i = Math.min(1, j); 
    if (i >= 0)
      return (Id3Frame)(paramBoolean1 ? new TextInformationFrame(paramString, null, Integer.toString(i)) : new CommentFrame("und", paramString, Integer.toString(i))); 
    paramString = String.valueOf(a.a(paramInt));
    if (paramString.length() != 0) {
      paramString = "Failed to parse uint8 attribute: ".concat(paramString);
    } else {
      paramString = new String("Failed to parse uint8 attribute: ");
    } 
    r.h("MetadataUtil", paramString);
    return null;
  }
  
  private static int j(b0 paramb0) {
    paramb0.Q(4);
    if (paramb0.n() == 1684108385) {
      paramb0.Q(8);
      return paramb0.D();
    } 
    r.h("MetadataUtil", "Failed to parse uint8 attribute value");
    return -1;
  }
  
  public static void k(int paramInt, u paramu, Format.b paramb) {
    if (paramInt == 1 && paramu.a())
      paramb.M(paramu.a).N(paramu.b); 
  }
  
  public static void l(int paramInt, @Nullable Metadata paramMetadata1, @Nullable Metadata paramMetadata2, Format.b paramb, Metadata... paramVarArgs) {
    // Byte code:
    //   0: iconst_0
    //   1: istore #5
    //   3: new com/google/android/exoplayer2/metadata/Metadata
    //   6: dup
    //   7: iconst_0
    //   8: anewarray com/google/android/exoplayer2/metadata/Metadata$Entry
    //   11: invokespecial <init> : ([Lcom/google/android/exoplayer2/metadata/Metadata$Entry;)V
    //   14: astore #7
    //   16: iload_0
    //   17: iconst_1
    //   18: if_icmpne -> 28
    //   21: aload_1
    //   22: ifnull -> 104
    //   25: goto -> 107
    //   28: iload_0
    //   29: iconst_2
    //   30: if_icmpne -> 104
    //   33: aload_2
    //   34: ifnull -> 104
    //   37: iconst_0
    //   38: istore_0
    //   39: iload_0
    //   40: aload_2
    //   41: invokevirtual d : ()I
    //   44: if_icmpge -> 104
    //   47: aload_2
    //   48: iload_0
    //   49: invokevirtual c : (I)Lcom/google/android/exoplayer2/metadata/Metadata$Entry;
    //   52: astore_1
    //   53: aload_1
    //   54: instanceof com/google/android/exoplayer2/metadata/mp4/MdtaMetadataEntry
    //   57: ifeq -> 97
    //   60: aload_1
    //   61: checkcast com/google/android/exoplayer2/metadata/mp4/MdtaMetadataEntry
    //   64: astore_1
    //   65: ldc_w 'com.android.capture.fps'
    //   68: aload_1
    //   69: getfield a : Ljava/lang/String;
    //   72: invokevirtual equals : (Ljava/lang/Object;)Z
    //   75: ifeq -> 97
    //   78: new com/google/android/exoplayer2/metadata/Metadata
    //   81: dup
    //   82: iconst_1
    //   83: anewarray com/google/android/exoplayer2/metadata/Metadata$Entry
    //   86: dup
    //   87: iconst_0
    //   88: aload_1
    //   89: aastore
    //   90: invokespecial <init> : ([Lcom/google/android/exoplayer2/metadata/Metadata$Entry;)V
    //   93: astore_1
    //   94: goto -> 107
    //   97: iload_0
    //   98: iconst_1
    //   99: iadd
    //   100: istore_0
    //   101: goto -> 39
    //   104: aload #7
    //   106: astore_1
    //   107: aload #4
    //   109: arraylength
    //   110: istore #6
    //   112: iload #5
    //   114: istore_0
    //   115: iload_0
    //   116: iload #6
    //   118: if_icmpge -> 137
    //   121: aload_1
    //   122: aload #4
    //   124: iload_0
    //   125: aaload
    //   126: invokevirtual b : (Lcom/google/android/exoplayer2/metadata/Metadata;)Lcom/google/android/exoplayer2/metadata/Metadata;
    //   129: astore_1
    //   130: iload_0
    //   131: iconst_1
    //   132: iadd
    //   133: istore_0
    //   134: goto -> 115
    //   137: aload_1
    //   138: invokevirtual d : ()I
    //   141: ifle -> 150
    //   144: aload_3
    //   145: aload_1
    //   146: invokevirtual X : (Lcom/google/android/exoplayer2/metadata/Metadata;)Lcom/google/android/exoplayer2/Format$b;
    //   149: pop
    //   150: return
  }
}


/* Location:              C:\soft\dex2jar-2.0\BabyBus TV_Kids Videos & Games-dex2jar.jar!\a3\h.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */