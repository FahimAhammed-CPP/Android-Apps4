package a3;

import android.util.Pair;
import android.util.SparseArray;
import androidx.annotation.Nullable;
import com.google.android.exoplayer2.Format;
import com.google.android.exoplayer2.drm.DrmInitData;
import com.google.android.exoplayer2.k1;
import com.google.android.exoplayer2.metadata.emsg.EventMessage;
import com.google.android.exoplayer2.util.b0;
import com.google.android.exoplayer2.util.n0;
import com.google.android.exoplayer2.util.r;
import com.google.android.exoplayer2.util.r0;
import com.google.android.exoplayer2.util.w;
import java.io.IOException;
import java.util.ArrayDeque;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;
import java.util.UUID;
import t2.b0;
import t2.d;
import t2.i;
import t2.j;
import t2.k;
import t2.o;
import t2.u;
import t2.x;
import t2.y;

public class g implements i {
  public static final o I = f.b;
  
  private static final byte[] J = new byte[] { 
      -94, 57, 79, 82, 90, -101, 79, 20, -94, 68, 
      108, 66, 124, 100, -115, -12 };
  
  private static final Format K = (new Format.b()).e0("application/x-emsg").E();
  
  private int A;
  
  private int B;
  
  private int C;
  
  private boolean D;
  
  private k E;
  
  private b0[] F;
  
  private b0[] G;
  
  private boolean H;
  
  private final int a;
  
  @Nullable
  private final o b;
  
  private final List<Format> c;
  
  private final SparseArray<b> d;
  
  private final b0 e;
  
  private final b0 f;
  
  private final b0 g;
  
  private final byte[] h;
  
  private final b0 i;
  
  @Nullable
  private final n0 j;
  
  private final h3.b k;
  
  private final b0 l;
  
  private final ArrayDeque<a.a> m;
  
  private final ArrayDeque<a> n;
  
  @Nullable
  private final b0 o;
  
  private int p;
  
  private int q;
  
  private long r;
  
  private int s;
  
  @Nullable
  private b0 t;
  
  private long u;
  
  private int v;
  
  private long w;
  
  private long x;
  
  private long y;
  
  @Nullable
  private b z;
  
  public g() {
    this(0);
  }
  
  public g(int paramInt) {
    this(paramInt, null);
  }
  
  public g(int paramInt, @Nullable n0 paramn0) {
    this(paramInt, paramn0, null, Collections.emptyList());
  }
  
  public g(int paramInt, @Nullable n0 paramn0, @Nullable o paramo, List<Format> paramList) {
    this(paramInt, paramn0, paramo, paramList, null);
  }
  
  public g(int paramInt, @Nullable n0 paramn0, @Nullable o paramo, List<Format> paramList, @Nullable b0 paramb0) {
    this.a = paramInt;
    this.j = paramn0;
    this.b = paramo;
    this.c = Collections.unmodifiableList(paramList);
    this.o = paramb0;
    this.k = new h3.b();
    this.l = new b0(16);
    this.e = new b0(w.a);
    this.f = new b0(5);
    this.g = new b0();
    byte[] arrayOfByte = new byte[16];
    this.h = arrayOfByte;
    this.i = new b0(arrayOfByte);
    this.m = new ArrayDeque<a.a>();
    this.n = new ArrayDeque<a>();
    this.d = new SparseArray();
    this.x = -9223372036854775807L;
    this.w = -9223372036854775807L;
    this.y = -9223372036854775807L;
    this.E = k.r;
    this.F = new b0[0];
    this.G = new b0[0];
  }
  
  private static Pair<Long, d> A(b0 paramb0, long paramLong) throws k1 {
    long l1;
    paramb0.P(8);
    int j = a.c(paramb0.n());
    paramb0.Q(4);
    long l4 = paramb0.F();
    if (j == 0) {
      l1 = paramb0.F();
      l2 = paramb0.F();
    } else {
      l1 = paramb0.I();
      l2 = paramb0.I();
    } 
    paramLong += l2;
    long l3 = r0.G0(l1, 1000000L, l4);
    paramb0.Q(2);
    j = paramb0.J();
    int[] arrayOfInt = new int[j];
    long[] arrayOfLong1 = new long[j];
    long[] arrayOfLong2 = new long[j];
    long[] arrayOfLong3 = new long[j];
    long l2 = l3;
    int m = 0;
    while (m < j) {
      int n = paramb0.n();
      if ((n & Integer.MIN_VALUE) == 0) {
        long l = paramb0.F();
        arrayOfInt[m] = n & Integer.MAX_VALUE;
        arrayOfLong1[m] = paramLong;
        arrayOfLong3[m] = l2;
        l1 += l;
        l2 = r0.G0(l1, 1000000L, l4);
        arrayOfLong2[m] = l2 - arrayOfLong3[m];
        paramb0.Q(4);
        paramLong += arrayOfInt[m];
        m++;
        continue;
      } 
      throw k1.createForMalformedContainer("Unhandled indirect reference", null);
    } 
    return Pair.create(Long.valueOf(l3), new d(arrayOfInt, arrayOfLong1, arrayOfLong2, arrayOfLong3));
  }
  
  private static long B(b0 paramb0) {
    paramb0.P(8);
    return (a.c(paramb0.n()) == 1) ? paramb0.I() : paramb0.F();
  }
  
  @Nullable
  private static b C(b0 paramb0, SparseArray<b> paramSparseArray, boolean paramBoolean) {
    int m;
    int n;
    paramb0.P(8);
    int i1 = a.b(paramb0.n());
    int j = paramb0.n();
    if (paramBoolean) {
      object = paramSparseArray.valueAt(0);
    } else {
      object = object.get(j);
    } 
    Object object = object;
    if (object == null)
      return null; 
    if ((i1 & 0x1) != 0) {
      long l = paramb0.I();
      q q = ((b)object).b;
      q.c = l;
      q.d = l;
    } 
    c c = ((b)object).e;
    if ((i1 & 0x2) != 0) {
      j = paramb0.n() - 1;
    } else {
      j = c.a;
    } 
    if ((i1 & 0x8) != 0) {
      m = paramb0.n();
    } else {
      m = c.b;
    } 
    if ((i1 & 0x10) != 0) {
      n = paramb0.n();
    } else {
      n = c.c;
    } 
    if ((i1 & 0x20) != 0) {
      i1 = paramb0.n();
    } else {
      i1 = c.d;
    } 
    ((b)object).b.a = new c(j, m, n, i1);
    return (b)object;
  }
  
  private static void D(a.a parama, SparseArray<b> paramSparseArray, boolean paramBoolean, int paramInt, byte[] paramArrayOfbyte) throws k1 {
    b b1 = C(((a.b)com.google.android.exoplayer2.util.a.e(parama.g(1952868452))).b, paramSparseArray, paramBoolean);
    if (b1 == null)
      return; 
    q q = b1.b;
    long l = q.r;
    paramBoolean = q.s;
    b1.k();
    b.b(b1, true);
    a.b b2 = parama.g(1952867444);
    if (b2 != null && (paramInt & 0x2) == 0) {
      q.r = B(b2.b);
      q.s = true;
    } else {
      q.r = l;
      q.s = paramBoolean;
    } 
    G(parama, b1, paramInt);
    p p = b1.d.a.a(((c)com.google.android.exoplayer2.util.a.e(q.a)).a);
    b2 = parama.g(1935763834);
    if (b2 != null)
      w((p)com.google.android.exoplayer2.util.a.e(p), b2.b, q); 
    b2 = parama.g(1935763823);
    if (b2 != null)
      v(b2.b, q); 
    b2 = parama.g(1936027235);
    if (b2 != null)
      z(b2.b, q); 
    if (p != null) {
      String str = p.b;
    } else {
      p = null;
    } 
    x(parama, (String)p, q);
    int j = parama.c.size();
    for (paramInt = 0; paramInt < j; paramInt++) {
      a.b b3 = parama.c.get(paramInt);
      if (b3.a == 1970628964)
        H(b3.b, q, paramArrayOfbyte); 
    } 
  }
  
  private static Pair<Integer, c> E(b0 paramb0) {
    paramb0.P(12);
    return Pair.create(Integer.valueOf(paramb0.n()), new c(paramb0.n() - 1, paramb0.n(), paramb0.n(), paramb0.n()));
  }
  
  private static int F(b paramb, int paramInt1, int paramInt2, b0 paramb0, int paramInt3) throws k1 {
    boolean bool1;
    boolean bool2;
    boolean bool3;
    boolean bool4;
    long l1;
    b b1 = paramb;
    paramb0.P(8);
    int m = a.b(paramb0.n());
    o o1 = b1.d.a;
    q q = b1.b;
    c c = (c)r0.j(q.a);
    q.h[paramInt1] = paramb0.H();
    long[] arrayOfLong1 = q.g;
    arrayOfLong1[paramInt1] = q.c;
    if ((m & 0x1) != 0)
      arrayOfLong1[paramInt1] = arrayOfLong1[paramInt1] + paramb0.n(); 
    if ((m & 0x4) != 0) {
      bool1 = true;
    } else {
      bool1 = false;
    } 
    int j = c.d;
    if (bool1)
      j = paramb0.n(); 
    if ((m & 0x100) != 0) {
      bool2 = true;
    } else {
      bool2 = false;
    } 
    if ((m & 0x200) != 0) {
      bool3 = true;
    } else {
      bool3 = false;
    } 
    if ((m & 0x400) != 0) {
      bool4 = true;
    } else {
      bool4 = false;
    } 
    if ((m & 0x800) != 0) {
      m = 1;
    } else {
      m = 0;
    } 
    arrayOfLong1 = o1.h;
    if (arrayOfLong1 != null && arrayOfLong1.length == 1 && arrayOfLong1[0] == 0L) {
      l1 = r0.G0(((long[])r0.j(o1.i))[0], 1000000L, o1.c);
    } else {
      l1 = 0L;
    } 
    int[] arrayOfInt1 = q.i;
    int[] arrayOfInt2 = q.j;
    long[] arrayOfLong2 = q.k;
    boolean[] arrayOfBoolean = q.l;
    if (o1.b == 2 && (paramInt2 & 0x1) != 0) {
      paramInt2 = 1;
    } else {
      paramInt2 = 0;
    } 
    int n = paramInt3 + q.h[paramInt1];
    long l2 = o1.c;
    long l3 = q.r;
    while (paramInt3 < n) {
      boolean bool;
      if (bool2) {
        paramInt1 = paramb0.n();
      } else {
        paramInt1 = c.b;
      } 
      int i1 = e(paramInt1);
      if (bool3) {
        paramInt1 = paramb0.n();
      } else {
        paramInt1 = c.c;
      } 
      int i2 = e(paramInt1);
      if (bool4) {
        paramInt1 = paramb0.n();
      } else if (paramInt3 == 0 && bool1) {
        paramInt1 = j;
      } else {
        paramInt1 = c.d;
      } 
      if (m != 0) {
        arrayOfInt2[paramInt3] = (int)(paramb0.n() * 1000000L / l2);
      } else {
        arrayOfInt2[paramInt3] = 0;
      } 
      arrayOfLong2[paramInt3] = r0.G0(l3, 1000000L, l2) - l1;
      if (!q.s)
        arrayOfLong2[paramInt3] = arrayOfLong2[paramInt3] + paramb.d.h; 
      arrayOfInt1[paramInt3] = i2;
      if ((paramInt1 >> 16 & 0x1) == 0 && (paramInt2 == 0 || paramInt3 == 0)) {
        bool = true;
      } else {
        bool = false;
      } 
      arrayOfBoolean[paramInt3] = bool;
      l3 += i1;
      paramInt3++;
    } 
    q.r = l3;
    return n;
  }
  
  private static void G(a.a parama, b paramb, int paramInt) throws k1 {
    List<a.b> list = parama.c;
    int i1 = list.size();
    boolean bool = false;
    int j = 0;
    int m = 0;
    int n;
    for (n = 0; j < i1; n = i2) {
      a.b b1 = list.get(j);
      int i3 = m;
      int i2 = n;
      if (b1.a == 1953658222) {
        b0 b01 = b1.b;
        b01.P(12);
        int i4 = b01.H();
        i3 = m;
        i2 = n;
        if (i4 > 0) {
          i2 = n + i4;
          i3 = m + 1;
        } 
      } 
      j++;
      m = i3;
    } 
    paramb.h = 0;
    paramb.g = 0;
    paramb.f = 0;
    paramb.b.e(m, n);
    m = 0;
    n = 0;
    j = bool;
    while (j < i1) {
      a.b b1 = list.get(j);
      int i3 = m;
      int i2 = n;
      if (b1.a == 1953658222) {
        i2 = F(paramb, m, paramInt, b1.b, n);
        i3 = m + 1;
      } 
      j++;
      m = i3;
      n = i2;
    } 
  }
  
  private static void H(b0 paramb0, q paramq, byte[] paramArrayOfbyte) throws k1 {
    paramb0.P(8);
    paramb0.j(paramArrayOfbyte, 0, 16);
    if (!Arrays.equals(paramArrayOfbyte, J))
      return; 
    y(paramb0, 16, paramq);
  }
  
  private void I(long paramLong) throws k1 {
    while (!this.m.isEmpty() && ((a.a)this.m.peek()).b == paramLong)
      n(this.m.pop()); 
    g();
  }
  
  private boolean J(j paramj) throws IOException {
    if (this.s == 0) {
      if (!paramj.e(this.l.d(), 0, 8, true))
        return false; 
      this.s = 8;
      this.l.P(0);
      this.r = this.l.F();
      this.q = this.l.n();
    } 
    long l = this.r;
    if (l == 1L) {
      paramj.readFully(this.l.d(), 8, 8);
      this.s += 8;
      this.r = this.l.I();
    } else if (l == 0L) {
      long l1 = paramj.getLength();
      l = l1;
      if (l1 == -1L) {
        l = l1;
        if (!this.m.isEmpty())
          l = ((a.a)this.m.peek()).b; 
      } 
      if (l != -1L)
        this.r = l - paramj.getPosition() + this.s; 
    } 
    if (this.r >= this.s) {
      l = paramj.getPosition() - this.s;
      int m = this.q;
      if ((m == 1836019558 || m == 1835295092) && !this.H) {
        this.E.g((y)new y.b(this.x, l));
        this.H = true;
      } 
      if (this.q == 1836019558) {
        int n = this.d.size();
        for (m = 0; m < n; m++) {
          q q = ((b)this.d.valueAt(m)).b;
          q.b = l;
          q.d = l;
          q.c = l;
        } 
      } 
      m = this.q;
      if (m == 1835295092) {
        this.z = null;
        this.u = l + this.r;
        this.p = 2;
        return true;
      } 
      if (N(m)) {
        l = paramj.getPosition() + this.r - 8L;
        this.m.push(new a.a(this.q, l));
        if (this.r == this.s) {
          I(l);
          return true;
        } 
        g();
        return true;
      } 
      if (O(this.q)) {
        if (this.s == 8) {
          l = this.r;
          if (l <= 2147483647L) {
            b0 b01 = new b0((int)l);
            System.arraycopy(this.l.d(), 0, b01.d(), 0, 8);
            this.t = b01;
            this.p = 1;
            return true;
          } 
          throw k1.createForUnsupportedContainerFeature("Leaf atom with length > 2147483647 (unsupported).");
        } 
        throw k1.createForUnsupportedContainerFeature("Leaf atom defines extended atom size (unsupported).");
      } 
      if (this.r <= 2147483647L) {
        this.t = null;
        this.p = 1;
        return true;
      } 
      throw k1.createForUnsupportedContainerFeature("Skipping atom with length > 2147483647 (unsupported).");
    } 
    throw k1.createForUnsupportedContainerFeature("Atom size less than header length (unsupported).");
  }
  
  private void K(j paramj) throws IOException {
    int m = (int)this.r - this.s;
    b0 b01 = this.t;
    if (b01 != null) {
      paramj.readFully(b01.d(), 8, m);
      p(new a.b(this.q, b01), paramj.getPosition());
    } else {
      paramj.k(m);
    } 
    I(paramj.getPosition());
  }
  
  private void L(j paramj) throws IOException {
    int n = this.d.size();
    long l = Long.MAX_VALUE;
    int m = 0;
    b b1;
    for (b1 = null; m < n; b1 = b2) {
      q q = ((b)this.d.valueAt(m)).b;
      long l1 = l;
      b b2 = b1;
      if (q.q) {
        long l2 = q.d;
        l1 = l;
        b2 = b1;
        if (l2 < l) {
          b2 = (b)this.d.valueAt(m);
          l1 = l2;
        } 
      } 
      m++;
      l = l1;
    } 
    if (b1 == null) {
      this.p = 3;
      return;
    } 
    m = (int)(l - paramj.getPosition());
    if (m >= 0) {
      paramj.k(m);
      b1.b.b(paramj);
      return;
    } 
    throw k1.createForMalformedContainer("Offset to encryption data was negative.", null);
  }
  
  private boolean M(j paramj) throws IOException {
    throw new RuntimeException("d2j fail translate: java.lang.RuntimeException: can not merge I and Z\r\n\tat com.googlecode.dex2jar.ir.TypeClass.merge(TypeClass.java:100)\r\n\tat com.googlecode.dex2jar.ir.ts.TypeTransformer$TypeRef.updateTypeClass(TypeTransformer.java:174)\r\n\tat com.googlecode.dex2jar.ir.ts.TypeTransformer$TypeAnalyze.provideAs(TypeTransformer.java:780)\r\n\tat com.googlecode.dex2jar.ir.ts.TypeTransformer$TypeAnalyze.enexpr(TypeTransformer.java:659)\r\n\tat com.googlecode.dex2jar.ir.ts.TypeTransformer$TypeAnalyze.exExpr(TypeTransformer.java:719)\r\n\tat com.googlecode.dex2jar.ir.ts.TypeTransformer$TypeAnalyze.exExpr(TypeTransformer.java:703)\r\n\tat com.googlecode.dex2jar.ir.ts.TypeTransformer$TypeAnalyze.enexpr(TypeTransformer.java:698)\r\n\tat com.googlecode.dex2jar.ir.ts.TypeTransformer$TypeAnalyze.exExpr(TypeTransformer.java:719)\r\n\tat com.googlecode.dex2jar.ir.ts.TypeTransformer$TypeAnalyze.exExpr(TypeTransformer.java:703)\r\n\tat com.googlecode.dex2jar.ir.ts.TypeTransformer$TypeAnalyze.s1stmt(TypeTransformer.java:810)\r\n\tat com.googlecode.dex2jar.ir.ts.TypeTransformer$TypeAnalyze.sxStmt(TypeTransformer.java:840)\r\n\tat com.googlecode.dex2jar.ir.ts.TypeTransformer$TypeAnalyze.analyze(TypeTransformer.java:206)\r\n\tat com.googlecode.dex2jar.ir.ts.TypeTransformer.transform(TypeTransformer.java:44)\r\n\tat com.googlecode.d2j.dex.Dex2jar$2.optimize(Dex2jar.java:162)\r\n\tat com.googlecode.d2j.dex.Dex2Asm.convertCode(Dex2Asm.java:414)\r\n\tat com.googlecode.d2j.dex.ExDex2Asm.convertCode(ExDex2Asm.java:42)\r\n\tat com.googlecode.d2j.dex.Dex2jar$2.convertCode(Dex2jar.java:128)\r\n\tat com.googlecode.d2j.dex.Dex2Asm.convertMethod(Dex2Asm.java:509)\r\n\tat com.googlecode.d2j.dex.Dex2Asm.convertClass(Dex2Asm.java:406)\r\n\tat com.googlecode.d2j.dex.Dex2Asm.convertDex(Dex2Asm.java:422)\r\n\tat com.googlecode.d2j.dex.Dex2jar.doTranslate(Dex2jar.java:172)\r\n\tat com.googlecode.d2j.dex.Dex2jar.to(Dex2jar.java:272)\r\n\tat com.googlecode.dex2jar.tools.Dex2jarCmd.doCommandLine(Dex2jarCmd.java:108)\r\n\tat com.googlecode.dex2jar.tools.BaseCmd.doMain(BaseCmd.java:288)\r\n\tat com.googlecode.dex2jar.tools.Dex2jarCmd.main(Dex2jarCmd.java:32)\r\n");
  }
  
  private static boolean N(int paramInt) {
    return (paramInt == 1836019574 || paramInt == 1953653099 || paramInt == 1835297121 || paramInt == 1835626086 || paramInt == 1937007212 || paramInt == 1836019558 || paramInt == 1953653094 || paramInt == 1836475768 || paramInt == 1701082227);
  }
  
  private static boolean O(int paramInt) {
    return (paramInt == 1751411826 || paramInt == 1835296868 || paramInt == 1836476516 || paramInt == 1936286840 || paramInt == 1937011556 || paramInt == 1937011827 || paramInt == 1668576371 || paramInt == 1937011555 || paramInt == 1937011578 || paramInt == 1937013298 || paramInt == 1937007471 || paramInt == 1668232756 || paramInt == 1937011571 || paramInt == 1952867444 || paramInt == 1952868452 || paramInt == 1953196132 || paramInt == 1953654136 || paramInt == 1953658222 || paramInt == 1886614376 || paramInt == 1935763834 || paramInt == 1935763823 || paramInt == 1936027235 || paramInt == 1970628964 || paramInt == 1935828848 || paramInt == 1936158820 || paramInt == 1701606260 || paramInt == 1835362404 || paramInt == 1701671783);
  }
  
  private static int e(int paramInt) throws k1 {
    if (paramInt >= 0)
      return paramInt; 
    StringBuilder stringBuilder = new StringBuilder(38);
    stringBuilder.append("Unexpected negative value: ");
    stringBuilder.append(paramInt);
    throw k1.createForMalformedContainer(stringBuilder.toString(), null);
  }
  
  private void g() {
    this.p = 0;
    this.s = 0;
  }
  
  private c h(SparseArray<c> paramSparseArray, int paramInt) {
    return (paramSparseArray.size() == 1) ? (c)paramSparseArray.valueAt(0) : (c)com.google.android.exoplayer2.util.a.e(paramSparseArray.get(paramInt));
  }
  
  @Nullable
  private static DrmInitData i(List<a.b> paramList) {
    int m = paramList.size();
    int j = 0;
    ArrayList<DrmInitData.SchemeData> arrayList;
    for (arrayList = null; j < m; arrayList = arrayList1) {
      a.b b1 = paramList.get(j);
      ArrayList<DrmInitData.SchemeData> arrayList1 = arrayList;
      if (b1.a == 1886614376) {
        arrayList1 = arrayList;
        if (arrayList == null)
          arrayList1 = new ArrayList(); 
        byte[] arrayOfByte = b1.b.d();
        UUID uUID = l.f(arrayOfByte);
        if (uUID == null) {
          r.h("FragmentedMp4Extractor", "Skipped pssh atom (failed to extract uuid)");
        } else {
          arrayList1.add(new DrmInitData.SchemeData(uUID, "video/mp4", arrayOfByte));
        } 
      } 
      j++;
    } 
    return (arrayList == null) ? null : new DrmInitData(arrayList);
  }
  
  @Nullable
  private static b j(SparseArray<b> paramSparseArray) {
    // Byte code:
    //   0: aload_0
    //   1: invokevirtual size : ()I
    //   4: istore_2
    //   5: aconst_null
    //   6: astore #9
    //   8: ldc2_w 9223372036854775807
    //   11: lstore_3
    //   12: iconst_0
    //   13: istore_1
    //   14: iload_1
    //   15: iload_2
    //   16: if_icmpge -> 137
    //   19: aload_0
    //   20: iload_1
    //   21: invokevirtual valueAt : (I)Ljava/lang/Object;
    //   24: checkcast a3/g$b
    //   27: astore #11
    //   29: aload #11
    //   31: invokestatic a : (La3/g$b;)Z
    //   34: ifne -> 60
    //   37: aload #9
    //   39: astore #10
    //   41: lload_3
    //   42: lstore #5
    //   44: aload #11
    //   46: getfield f : I
    //   49: aload #11
    //   51: getfield d : La3/r;
    //   54: getfield b : I
    //   57: if_icmpeq -> 123
    //   60: aload #11
    //   62: invokestatic a : (La3/g$b;)Z
    //   65: ifeq -> 94
    //   68: aload #11
    //   70: getfield h : I
    //   73: aload #11
    //   75: getfield b : La3/q;
    //   78: getfield e : I
    //   81: if_icmpne -> 94
    //   84: aload #9
    //   86: astore #10
    //   88: lload_3
    //   89: lstore #5
    //   91: goto -> 123
    //   94: aload #11
    //   96: invokevirtual d : ()J
    //   99: lstore #7
    //   101: aload #9
    //   103: astore #10
    //   105: lload_3
    //   106: lstore #5
    //   108: lload #7
    //   110: lload_3
    //   111: lcmp
    //   112: ifge -> 123
    //   115: aload #11
    //   117: astore #10
    //   119: lload #7
    //   121: lstore #5
    //   123: iload_1
    //   124: iconst_1
    //   125: iadd
    //   126: istore_1
    //   127: aload #10
    //   129: astore #9
    //   131: lload #5
    //   133: lstore_3
    //   134: goto -> 14
    //   137: aload #9
    //   139: areturn
  }
  
  private void k() {
    b0[] arrayOfB0 = new b0[2];
    this.F = arrayOfB0;
    b0 b01 = this.o;
    boolean bool = false;
    if (b01 != null) {
      arrayOfB0[0] = b01;
      m = 1;
    } else {
      m = 0;
    } 
    int i1 = this.a;
    int j = 100;
    int n = m;
    if ((i1 & 0x4) != 0) {
      arrayOfB0[m] = this.E.e(100, 5);
      n = m + 1;
      j = 101;
    } 
    arrayOfB0 = (b0[])r0.z0((Object[])this.F, n);
    this.F = arrayOfB0;
    n = arrayOfB0.length;
    int m;
    for (m = 0; m < n; m++)
      arrayOfB0[m].c(K); 
    this.G = new b0[this.c.size()];
    m = bool;
    while (m < this.G.length) {
      b0 b02 = this.E.e(j, 3);
      b02.c(this.c.get(m));
      this.G[m] = b02;
      m++;
      j++;
    } 
  }
  
  private void n(a.a parama) throws k1 {
    int j = parama.a;
    if (j == 1836019574) {
      r(parama);
      return;
    } 
    if (j == 1836019558) {
      q(parama);
      return;
    } 
    if (!this.m.isEmpty())
      ((a.a)this.m.peek()).d(parama); 
  }
  
  private void o(b0 paramb0) {
    StringBuilder stringBuilder;
    long l1;
    long l3;
    long l4;
    String str1;
    String str2;
    if (this.F.length == 0)
      return; 
    paramb0.P(8);
    null = a.c(paramb0.n());
    if (null != 0) {
      if (null != 1) {
        stringBuilder = new StringBuilder(46);
        stringBuilder.append("Skipping unsupported emsg version: ");
        stringBuilder.append(null);
        r.h("FragmentedMp4Extractor", stringBuilder.toString());
        return;
      } 
      l2 = stringBuilder.F();
      l1 = r0.G0(stringBuilder.I(), 1000000L, l2);
      l2 = r0.G0(stringBuilder.F(), 1000L, l2);
      l3 = stringBuilder.F();
      str1 = (String)com.google.android.exoplayer2.util.a.e(stringBuilder.x());
      str2 = (String)com.google.android.exoplayer2.util.a.e(stringBuilder.x());
      l4 = -9223372036854775807L;
    } else {
      str1 = (String)com.google.android.exoplayer2.util.a.e(stringBuilder.x());
      str2 = (String)com.google.android.exoplayer2.util.a.e(stringBuilder.x());
      l2 = stringBuilder.F();
      l4 = r0.G0(stringBuilder.F(), 1000000L, l2);
      l1 = this.y;
      if (l1 != -9223372036854775807L) {
        l1 += l4;
      } else {
        l1 = -9223372036854775807L;
      } 
      l2 = r0.G0(stringBuilder.F(), 1000L, l2);
      l3 = stringBuilder.F();
    } 
    byte[] arrayOfByte = new byte[stringBuilder.a()];
    null = stringBuilder.a();
    byte b1 = 0;
    stringBuilder.j(arrayOfByte, 0, null);
    EventMessage eventMessage = new EventMessage(str1, str2, l2, l3, arrayOfByte);
    b0 b01 = new b0(this.k.a(eventMessage));
    int m = b01.a();
    for (b0 b02 : this.F) {
      b01.P(0);
      b02.b(b01, m);
    } 
    if (l1 == -9223372036854775807L) {
      this.n.addLast(new a(l4, m));
      this.v += m;
      return;
    } 
    n0 n01 = this.j;
    long l2 = l1;
    if (n01 != null)
      l2 = n01.a(l1); 
    b0[] arrayOfB0 = this.F;
    int n = arrayOfB0.length;
    for (int j = b1; j < n; j++)
      arrayOfB0[j].d(l2, 1, m, 0, null); 
  }
  
  private void p(a.b paramb, long paramLong) throws k1 {
    Pair<Long, d> pair;
    if (!this.m.isEmpty()) {
      ((a.a)this.m.peek()).e(paramb);
      return;
    } 
    int j = paramb.a;
    if (j == 1936286840) {
      pair = A(paramb.b, paramLong);
      this.y = ((Long)pair.first).longValue();
      this.E.g((y)pair.second);
      this.H = true;
      return;
    } 
    if (j == 1701671783)
      o(((a.b)pair).b); 
  }
  
  private void q(a.a parama) throws k1 {
    boolean bool;
    SparseArray<b> sparseArray = this.d;
    o o1 = this.b;
    byte b1 = 0;
    if (o1 != null) {
      bool = true;
    } else {
      bool = false;
    } 
    u(parama, sparseArray, bool, this.a, this.h);
    DrmInitData drmInitData = i(parama.c);
    if (drmInitData != null) {
      int m = this.d.size();
      for (int j = 0; j < m; j++)
        ((b)this.d.valueAt(j)).n(drmInitData); 
    } 
    if (this.w != -9223372036854775807L) {
      int m = this.d.size();
      for (int j = b1; j < m; j++)
        ((b)this.d.valueAt(j)).l(this.w); 
      this.w = -9223372036854775807L;
    } 
  }
  
  private void r(a.a parama) throws k1 {
    boolean bool3;
    o o1 = this.b;
    boolean bool4 = true;
    boolean bool2 = false;
    boolean bool1 = false;
    if (o1 == null) {
      bool3 = true;
    } else {
      bool3 = false;
    } 
    com.google.android.exoplayer2.util.a.h(bool3, "Unexpected moov box.");
    DrmInitData drmInitData = i(parama.c);
    a.a a1 = (a.a)com.google.android.exoplayer2.util.a.e(parama.f(1836475768));
    SparseArray<c> sparseArray = new SparseArray();
    int m = a1.c.size();
    long l = -9223372036854775807L;
    int j;
    for (j = 0; j < m; j++) {
      Pair<Integer, c> pair;
      a.b b1 = a1.c.get(j);
      int n = b1.a;
      if (n == 1953654136) {
        pair = E(b1.b);
        sparseArray.put(((Integer)pair.first).intValue(), pair.second);
      } else if (n == 1835362404) {
        l = t(((a.b)pair).b);
      } 
    } 
    u u = new u();
    if ((this.a & 0x10) != 0) {
      bool3 = true;
    } else {
      bool3 = false;
    } 
    List<r> list = b.z(parama, u, l, drmInitData, bool3, false, new e(this));
    m = list.size();
    if (this.d.size() == 0) {
      for (j = bool1; j < m; j++) {
        r r = list.get(j);
        o o2 = r.a;
        b b1 = new b(this.E.e(j, o2.b), r, h(sparseArray, o2.a));
        this.d.put(o2.a, b1);
        this.x = Math.max(this.x, o2.e);
      } 
      this.E.q();
      return;
    } 
    if (this.d.size() == m) {
      bool3 = bool4;
    } else {
      bool3 = false;
    } 
    com.google.android.exoplayer2.util.a.g(bool3);
    for (j = bool2; j < m; j++) {
      r r = list.get(j);
      o o2 = r.a;
      ((b)this.d.get(o2.a)).j(r, h(sparseArray, o2.a));
    } 
  }
  
  private void s(long paramLong) {
    while (!this.n.isEmpty()) {
      a a = this.n.removeFirst();
      this.v -= a.b;
      long l2 = a.a + paramLong;
      n0 n01 = this.j;
      long l1 = l2;
      if (n01 != null)
        l1 = n01.a(l2); 
      b0[] arrayOfB0 = this.F;
      int m = arrayOfB0.length;
      for (int j = 0; j < m; j++)
        arrayOfB0[j].d(l1, 1, a.b, this.v, null); 
    } 
  }
  
  private static long t(b0 paramb0) {
    paramb0.P(8);
    return (a.c(paramb0.n()) == 0) ? paramb0.F() : paramb0.I();
  }
  
  private static void u(a.a parama, SparseArray<b> paramSparseArray, boolean paramBoolean, int paramInt, byte[] paramArrayOfbyte) throws k1 {
    int m = parama.d.size();
    int j;
    for (j = 0; j < m; j++) {
      a.a a1 = parama.d.get(j);
      if (a1.a == 1953653094)
        D(a1, paramSparseArray, paramBoolean, paramInt, paramArrayOfbyte); 
    } 
  }
  
  private static void v(b0 paramb0, q paramq) throws k1 {
    paramb0.P(8);
    int j = paramb0.n();
    if ((a.b(j) & 0x1) == 1)
      paramb0.Q(8); 
    int m = paramb0.H();
    if (m == 1) {
      long l1;
      j = a.c(j);
      long l2 = paramq.d;
      if (j == 0) {
        l1 = paramb0.F();
      } else {
        l1 = paramb0.I();
      } 
      paramq.d = l2 + l1;
      return;
    } 
    StringBuilder stringBuilder = new StringBuilder(40);
    stringBuilder.append("Unexpected saio entry count: ");
    stringBuilder.append(m);
    throw k1.createForMalformedContainer(stringBuilder.toString(), null);
  }
  
  private static void w(p paramp, b0 paramb0, q paramq) throws k1 {
    int n = paramp.d;
    paramb0.P(8);
    int j = a.b(paramb0.n());
    boolean bool = true;
    if ((j & 0x1) == 1)
      paramb0.Q(8); 
    j = paramb0.D();
    int i1 = paramb0.H();
    int m = paramq.f;
    if (i1 <= m) {
      int i2;
      if (j == 0) {
        boolean[] arrayOfBoolean = paramq.n;
        m = 0;
        j = 0;
        while (true) {
          i2 = j;
          if (m < i1) {
            i2 = paramb0.D();
            j += i2;
            if (i2 > n) {
              bool = true;
            } else {
              bool = false;
            } 
            arrayOfBoolean[m] = bool;
            m++;
            continue;
          } 
          break;
        } 
      } else {
        if (j <= n)
          bool = false; 
        i2 = j * i1 + 0;
        Arrays.fill(paramq.n, 0, i1, bool);
      } 
      Arrays.fill(paramq.n, i1, paramq.f, false);
      if (i2 > 0)
        paramq.d(i2); 
      return;
    } 
    StringBuilder stringBuilder = new StringBuilder(78);
    stringBuilder.append("Saiz sample count ");
    stringBuilder.append(i1);
    stringBuilder.append(" is greater than fragment sample count");
    stringBuilder.append(m);
    throw k1.createForMalformedContainer(stringBuilder.toString(), null);
  }
  
  private static void x(a.a parama, @Nullable String paramString, q paramq) throws k1 {
    b0 b01;
    a.a a1 = null;
    a.b b2 = null;
    a.b b1 = b2;
    int j = 0;
    while (j < parama.c.size()) {
      b0 b03;
      a.b b3 = parama.c.get(j);
      b0 b02 = b3.b;
      int m = b3.a;
      if (m == 1935828848) {
        b02.P(12);
        b3 = b2;
        a.b b4 = b1;
        if (b02.n() == 1936025959) {
          b0 b04 = b02;
          b4 = b1;
        } 
      } else {
        b3 = b2;
        a.b b4 = b1;
        if (m == 1936158820) {
          b02.P(12);
          b3 = b2;
          b4 = b1;
          if (b02.n() == 1936025959) {
            b03 = b02;
            b3 = b2;
          } 
        } 
      } 
      j++;
      b2 = b3;
      b01 = b03;
    } 
    if (b2 != null) {
      if (b01 == null)
        return; 
      b2.P(8);
      j = a.c(b2.n());
      b2.Q(4);
      if (j == 1)
        b2.Q(4); 
      if (b2.n() == 1) {
        b01.P(8);
        j = a.c(b01.n());
        b01.Q(4);
        if (j == 1) {
          if (b01.F() == 0L)
            throw k1.createForUnsupportedContainerFeature("Variable length description in sgpd found (unsupported)"); 
        } else if (j >= 2) {
          b01.Q(4);
        } 
        if (b01.F() == 1L) {
          byte[] arrayOfByte1;
          boolean bool;
          b01.Q(1);
          j = b01.D();
          if (b01.D() == 1) {
            bool = true;
          } else {
            bool = false;
          } 
          if (!bool)
            return; 
          int m = b01.D();
          byte[] arrayOfByte2 = new byte[16];
          b01.j(arrayOfByte2, 0, 16);
          parama = a1;
          if (m == 0) {
            int n = b01.D();
            arrayOfByte1 = new byte[n];
            b01.j(arrayOfByte1, 0, n);
          } 
          paramq.m = true;
          paramq.o = new p(bool, paramString, m, arrayOfByte2, (j & 0xF0) >> 4, j & 0xF, arrayOfByte1);
          return;
        } 
        throw k1.createForUnsupportedContainerFeature("Entry count in sgpd != 1 (unsupported).");
      } 
      throw k1.createForUnsupportedContainerFeature("Entry count in sbgp != 1 (unsupported).");
    } 
  }
  
  private static void y(b0 paramb0, int paramInt, q paramq) throws k1 {
    paramb0.P(paramInt + 8);
    paramInt = a.b(paramb0.n());
    if ((paramInt & 0x1) == 0) {
      boolean bool;
      if ((paramInt & 0x2) != 0) {
        bool = true;
      } else {
        bool = false;
      } 
      paramInt = paramb0.H();
      if (paramInt == 0) {
        Arrays.fill(paramq.n, 0, paramq.f, false);
        return;
      } 
      int j = paramq.f;
      if (paramInt == j) {
        Arrays.fill(paramq.n, 0, paramInt, bool);
        paramq.d(paramb0.a());
        paramq.a(paramb0);
        return;
      } 
      StringBuilder stringBuilder = new StringBuilder(80);
      stringBuilder.append("Senc sample count ");
      stringBuilder.append(paramInt);
      stringBuilder.append(" is different from fragment sample count");
      stringBuilder.append(j);
      throw k1.createForMalformedContainer(stringBuilder.toString(), null);
    } 
    throw k1.createForUnsupportedContainerFeature("Overriding TrackEncryptionBox parameters is unsupported.");
  }
  
  private static void z(b0 paramb0, q paramq) throws k1 {
    y(paramb0, 0, paramq);
  }
  
  public void a(long paramLong1, long paramLong2) {
    int m = this.d.size();
    int j;
    for (j = 0; j < m; j++)
      ((b)this.d.valueAt(j)).k(); 
    this.n.clear();
    this.v = 0;
    this.w = paramLong2;
    this.m.clear();
    g();
  }
  
  public void b(k paramk) {
    this.E = paramk;
    g();
    k();
    o o1 = this.b;
    if (o1 != null) {
      b b1 = new b(paramk.e(0, o1.b), new r(this.b, new long[0], new int[0], 0, new long[0], new int[0], 0L), new c(0, 0, 0, 0));
      this.d.put(0, b1);
      this.E.q();
    } 
  }
  
  public boolean d(j paramj) throws IOException {
    return n.b(paramj);
  }
  
  public int f(j paramj, x paramx) throws IOException {
    while (true) {
      int m = this.p;
      if (m != 0) {
        if (m != 1) {
          if (m != 2) {
            if (M(paramj))
              return 0; 
            continue;
          } 
          L(paramj);
          continue;
        } 
        K(paramj);
        continue;
      } 
      if (!J(paramj))
        return -1; 
    } 
  }
  
  @Nullable
  protected o m(@Nullable o paramo) {
    return paramo;
  }
  
  public void release() {}
  
  private static final class a {
    public final long a;
    
    public final int b;
    
    public a(long param1Long, int param1Int) {
      this.a = param1Long;
      this.b = param1Int;
    }
  }
  
  private static final class b {
    public final b0 a;
    
    public final q b;
    
    public final b0 c;
    
    public r d;
    
    public c e;
    
    public int f;
    
    public int g;
    
    public int h;
    
    public int i;
    
    private final b0 j;
    
    private final b0 k;
    
    private boolean l;
    
    public b(b0 param1b0, r param1r, c param1c) {
      this.a = param1b0;
      this.d = param1r;
      this.e = param1c;
      this.b = new q();
      this.c = new b0();
      this.j = new b0(1);
      this.k = new b0();
      j(param1r, param1c);
    }
    
    public int c() {
      byte b1;
      if (!this.l) {
        b1 = this.d.g[this.f];
      } else if (this.b.l[this.f]) {
        b1 = 1;
      } else {
        b1 = 0;
      } 
      int i = b1;
      if (g() != null)
        i = b1 | 0x40000000; 
      return i;
    }
    
    public long d() {
      return !this.l ? this.d.c[this.f] : this.b.g[this.h];
    }
    
    public long e() {
      return !this.l ? this.d.f[this.f] : this.b.c(this.f);
    }
    
    public int f() {
      return !this.l ? this.d.d[this.f] : this.b.i[this.f];
    }
    
    @Nullable
    public p g() {
      boolean bool = this.l;
      p p3 = null;
      if (!bool)
        return null; 
      int i = ((c)r0.j(this.b.a)).a;
      p p1 = this.b.o;
      if (p1 == null)
        p1 = this.d.a.a(i); 
      p p2 = p3;
      if (p1 != null) {
        p2 = p3;
        if (p1.a)
          p2 = p1; 
      } 
      return p2;
    }
    
    public boolean h() {
      this.f++;
      if (!this.l)
        return false; 
      int i = this.g + 1;
      this.g = i;
      int[] arrayOfInt = this.b.h;
      int j = this.h;
      if (i == arrayOfInt[j]) {
        this.h = j + 1;
        this.g = 0;
        return false;
      } 
      return true;
    }
    
    public int i(int param1Int1, int param1Int2) {
      boolean bool;
      int j;
      p p = g();
      if (p == null)
        return 0; 
      int i = p.d;
      if (i != 0) {
        b01 = this.b.p;
      } else {
        byte[] arrayOfByte1 = (byte[])r0.j(((p)b01).e);
        this.k.N(arrayOfByte1, arrayOfByte1.length);
        b01 = this.k;
        i = arrayOfByte1.length;
      } 
      boolean bool1 = this.b.g(this.f);
      if (bool1 || param1Int2 != 0) {
        bool = true;
      } else {
        bool = false;
      } 
      byte[] arrayOfByte = this.j.d();
      if (bool) {
        j = 128;
      } else {
        j = 0;
      } 
      arrayOfByte[0] = (byte)(j | i);
      this.j.P(0);
      this.a.f(this.j, 1, 1);
      this.a.f(b01, i, 1);
      if (!bool)
        return i + 1; 
      if (!bool1) {
        this.c.L(8);
        byte[] arrayOfByte1 = this.c.d();
        arrayOfByte1[0] = 0;
        arrayOfByte1[1] = 1;
        arrayOfByte1[2] = (byte)(param1Int2 >> 8 & 0xFF);
        arrayOfByte1[3] = (byte)(param1Int2 & 0xFF);
        arrayOfByte1[4] = (byte)(param1Int1 >> 24 & 0xFF);
        arrayOfByte1[5] = (byte)(param1Int1 >> 16 & 0xFF);
        arrayOfByte1[6] = (byte)(param1Int1 >> 8 & 0xFF);
        arrayOfByte1[7] = (byte)(param1Int1 & 0xFF);
        this.a.f(this.c, 8, 1);
        return i + 1 + 8;
      } 
      b0 b02 = this.b.p;
      param1Int1 = b02.J();
      b02.Q(-2);
      param1Int1 = param1Int1 * 6 + 2;
      b0 b01 = b02;
      if (param1Int2 != 0) {
        this.c.L(param1Int1);
        byte[] arrayOfByte1 = this.c.d();
        b02.j(arrayOfByte1, 0, param1Int1);
        param1Int2 = ((arrayOfByte1[2] & 0xFF) << 8 | arrayOfByte1[3] & 0xFF) + param1Int2;
        arrayOfByte1[2] = (byte)(param1Int2 >> 8 & 0xFF);
        arrayOfByte1[3] = (byte)(param1Int2 & 0xFF);
        b01 = this.c;
      } 
      this.a.f(b01, param1Int1, 1);
      return i + 1 + param1Int1;
    }
    
    public void j(r param1r, c param1c) {
      this.d = param1r;
      this.e = param1c;
      this.a.c(param1r.a.f);
      k();
    }
    
    public void k() {
      this.b.f();
      this.f = 0;
      this.h = 0;
      this.g = 0;
      this.i = 0;
      this.l = false;
    }
    
    public void l(long param1Long) {
      int i = this.f;
      while (true) {
        q q1 = this.b;
        if (i < q1.f && q1.c(i) < param1Long) {
          if (this.b.l[i])
            this.i = i; 
          i++;
          continue;
        } 
        break;
      } 
    }
    
    public void m() {
      p p = g();
      if (p == null)
        return; 
      b0 b01 = this.b.p;
      int i = p.d;
      if (i != 0)
        b01.Q(i); 
      if (this.b.g(this.f))
        b01.Q(b01.J() * 6); 
    }
    
    public void n(DrmInitData param1DrmInitData) {
      p p = this.d.a.a(((c)r0.j(this.b.a)).a);
      if (p != null) {
        String str = p.b;
      } else {
        p = null;
      } 
      param1DrmInitData = param1DrmInitData.c((String)p);
      Format format = this.d.a.f.a().L(param1DrmInitData).E();
      this.a.c(format);
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\BabyBus TV_Kids Videos & Games-dex2jar.jar!\a3\g.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */