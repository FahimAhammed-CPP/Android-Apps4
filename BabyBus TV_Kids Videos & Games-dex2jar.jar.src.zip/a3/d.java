package a3;

import com.google.android.exoplayer2.util.r0;

final class d {
  public static b a(int paramInt, long[] paramArrayOflong, int[] paramArrayOfint, long paramLong) {
    int i1 = 8192 / paramInt;
    int m = paramArrayOfint.length;
    int k = 0;
    int i = 0;
    int j = 0;
    while (i < m) {
      j += r0.l(paramArrayOfint[i], i1);
      i++;
    } 
    long[] arrayOfLong1 = new long[j];
    int[] arrayOfInt1 = new int[j];
    long[] arrayOfLong2 = new long[j];
    int[] arrayOfInt2 = new int[j];
    m = 0;
    j = 0;
    int n = 0;
    i = k;
    k = m;
    while (i < paramArrayOfint.length) {
      m = paramArrayOfint[i];
      long l = paramArrayOflong[i];
      while (m > 0) {
        int i2 = Math.min(i1, m);
        arrayOfLong1[j] = l;
        arrayOfInt1[j] = paramInt * i2;
        n = Math.max(n, arrayOfInt1[j]);
        arrayOfLong2[j] = k * paramLong;
        arrayOfInt2[j] = 1;
        l += arrayOfInt1[j];
        k += i2;
        m -= i2;
        j++;
      } 
      i++;
    } 
    return new b(arrayOfLong1, arrayOfInt1, n, arrayOfLong2, arrayOfInt2, paramLong * k, null);
  }
  
  public static final class b {
    public final long[] a;
    
    public final int[] b;
    
    public final int c;
    
    public final long[] d;
    
    public final int[] e;
    
    public final long f;
    
    private b(long[] param1ArrayOflong1, int[] param1ArrayOfint1, int param1Int, long[] param1ArrayOflong2, int[] param1ArrayOfint2, long param1Long) {
      this.a = param1ArrayOflong1;
      this.b = param1ArrayOfint1;
      this.c = param1Int;
      this.d = param1ArrayOflong2;
      this.e = param1ArrayOfint2;
      this.f = param1Long;
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\BabyBus TV_Kids Videos & Games-dex2jar.jar!\a3\d.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */