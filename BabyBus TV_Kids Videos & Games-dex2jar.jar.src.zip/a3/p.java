package a3;

import androidx.annotation.Nullable;
import com.google.android.exoplayer2.util.a;
import com.google.android.exoplayer2.util.r;
import t2.b0;

public final class p {
  public final boolean a;
  
  @Nullable
  public final String b;
  
  public final b0.a c;
  
  public final int d;
  
  @Nullable
  public final byte[] e;
  
  public p(boolean paramBoolean, @Nullable String paramString, int paramInt1, byte[] paramArrayOfbyte1, int paramInt2, int paramInt3, @Nullable byte[] paramArrayOfbyte2) {
    boolean bool1;
    boolean bool2 = true;
    if (paramInt1 == 0) {
      bool1 = true;
    } else {
      bool1 = false;
    } 
    if (paramArrayOfbyte2 != null)
      bool2 = false; 
    a.a(bool2 ^ bool1);
    this.a = paramBoolean;
    this.b = paramString;
    this.d = paramInt1;
    this.e = paramArrayOfbyte2;
    this.c = new b0.a(a(paramString), paramArrayOfbyte1, paramInt2, paramInt3);
  }
  
  private static int a(@Nullable String paramString) {
    StringBuilder stringBuilder;
    if (paramString == null)
      return 1; 
    byte b = -1;
    switch (paramString.hashCode()) {
      case 3049895:
        if (!paramString.equals("cens"))
          break; 
        b = 3;
        break;
      case 3049879:
        if (!paramString.equals("cenc"))
          break; 
        b = 2;
        break;
      case 3046671:
        if (!paramString.equals("cbcs"))
          break; 
        b = 1;
        break;
      case 3046605:
        if (!paramString.equals("cbc1"))
          break; 
        b = 0;
        break;
    } 
    switch (b) {
      default:
        stringBuilder = new StringBuilder(paramString.length() + 68);
        stringBuilder.append("Unsupported protection scheme type '");
        stringBuilder.append(paramString);
        stringBuilder.append("'. Assuming AES-CTR crypto mode.");
        r.h("TrackEncryptionBox", stringBuilder.toString());
      case 2:
      case 3:
        return 1;
      case 0:
      case 1:
        break;
    } 
    return 2;
  }
}


/* Location:              C:\soft\dex2jar-2.0\BabyBus TV_Kids Videos & Games-dex2jar.jar!\a3\p.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */