package a3;

import java.io.IOException;
import t2.j;

final class n {
  private static final int[] a = new int[] { 
      1769172845, 1769172786, 1769172787, 1769172788, 1769172789, 1769172790, 1769172793, 1635148593, 1752589105, 1751479857, 
      1635135537, 1836069937, 1836069938, 862401121, 862401122, 862417462, 862417718, 862414134, 862414646, 1295275552, 
      1295270176, 1714714144, 1801741417, 1295275600, 1903435808, 1297305174, 1684175153, 1769172332, 1885955686 };
  
  private static boolean a(int paramInt, boolean paramBoolean) {
    if (paramInt >>> 8 == 3368816)
      return true; 
    if (paramInt == 1751476579 && paramBoolean)
      return true; 
    int[] arrayOfInt = a;
    int j = arrayOfInt.length;
    for (int i = 0; i < j; i++) {
      if (arrayOfInt[i] == paramInt)
        return true; 
    } 
    return false;
  }
  
  public static boolean b(j paramj) throws IOException {
    return c(paramj, true, false);
  }
  
  private static boolean c(j paramj, boolean paramBoolean1, boolean paramBoolean2) throws IOException {
    // Byte code:
    //   0: aload_0
    //   1: invokeinterface getLength : ()J
    //   6: lstore #12
    //   8: ldc2_w 4096
    //   11: lstore #14
    //   13: lload #12
    //   15: ldc2_w -1
    //   18: lcmp
    //   19: istore #8
    //   21: lload #14
    //   23: lstore #10
    //   25: iload #8
    //   27: ifeq -> 50
    //   30: lload #12
    //   32: ldc2_w 4096
    //   35: lcmp
    //   36: ifle -> 46
    //   39: lload #14
    //   41: lstore #10
    //   43: goto -> 50
    //   46: lload #12
    //   48: lstore #10
    //   50: lload #10
    //   52: l2i
    //   53: istore #5
    //   55: new com/google/android/exoplayer2/util/b0
    //   58: dup
    //   59: bipush #64
    //   61: invokespecial <init> : (I)V
    //   64: astore #18
    //   66: iconst_0
    //   67: istore #4
    //   69: iconst_0
    //   70: istore_3
    //   71: iload #4
    //   73: iload #5
    //   75: if_icmpge -> 480
    //   78: aload #18
    //   80: bipush #8
    //   82: invokevirtual L : (I)V
    //   85: aload_0
    //   86: aload #18
    //   88: invokevirtual d : ()[B
    //   91: iconst_0
    //   92: bipush #8
    //   94: iconst_1
    //   95: invokeinterface a : ([BIIZ)Z
    //   100: ifne -> 106
    //   103: goto -> 480
    //   106: aload #18
    //   108: invokevirtual F : ()J
    //   111: lstore #14
    //   113: aload #18
    //   115: invokevirtual n : ()I
    //   118: istore #9
    //   120: bipush #16
    //   122: istore #6
    //   124: lload #14
    //   126: lconst_1
    //   127: lcmp
    //   128: ifne -> 163
    //   131: aload_0
    //   132: aload #18
    //   134: invokevirtual d : ()[B
    //   137: bipush #8
    //   139: bipush #8
    //   141: invokeinterface n : ([BII)V
    //   146: aload #18
    //   148: bipush #16
    //   150: invokevirtual O : (I)V
    //   153: aload #18
    //   155: invokevirtual w : ()J
    //   158: lstore #10
    //   160: goto -> 214
    //   163: lload #14
    //   165: lstore #10
    //   167: lload #14
    //   169: lconst_0
    //   170: lcmp
    //   171: ifne -> 210
    //   174: aload_0
    //   175: invokeinterface getLength : ()J
    //   180: lstore #16
    //   182: lload #14
    //   184: lstore #10
    //   186: lload #16
    //   188: ldc2_w -1
    //   191: lcmp
    //   192: ifeq -> 210
    //   195: lload #16
    //   197: aload_0
    //   198: invokeinterface g : ()J
    //   203: lsub
    //   204: bipush #8
    //   206: i2l
    //   207: ladd
    //   208: lstore #10
    //   210: bipush #8
    //   212: istore #6
    //   214: iload #6
    //   216: i2l
    //   217: lstore #14
    //   219: lload #10
    //   221: lload #14
    //   223: lcmp
    //   224: ifge -> 229
    //   227: iconst_0
    //   228: ireturn
    //   229: iload #4
    //   231: iload #6
    //   233: iadd
    //   234: istore #6
    //   236: iload #9
    //   238: ldc 1836019574
    //   240: if_icmpne -> 289
    //   243: iload #5
    //   245: lload #10
    //   247: l2i
    //   248: iadd
    //   249: istore #5
    //   251: iload #5
    //   253: istore #4
    //   255: iload #8
    //   257: ifeq -> 278
    //   260: iload #5
    //   262: istore #4
    //   264: iload #5
    //   266: i2l
    //   267: lload #12
    //   269: lcmp
    //   270: ifle -> 278
    //   273: lload #12
    //   275: l2i
    //   276: istore #4
    //   278: iload #4
    //   280: istore #5
    //   282: iload #6
    //   284: istore #4
    //   286: goto -> 71
    //   289: iload #9
    //   291: ldc 1836019558
    //   293: if_icmpeq -> 475
    //   296: iload #9
    //   298: ldc 1836475768
    //   300: if_icmpne -> 306
    //   303: goto -> 475
    //   306: iload #6
    //   308: i2l
    //   309: lload #10
    //   311: ladd
    //   312: lload #14
    //   314: lsub
    //   315: iload #5
    //   317: i2l
    //   318: lcmp
    //   319: iflt -> 325
    //   322: goto -> 480
    //   325: lload #10
    //   327: lload #14
    //   329: lsub
    //   330: l2i
    //   331: istore #4
    //   333: iload #6
    //   335: iload #4
    //   337: iadd
    //   338: istore #7
    //   340: iload #9
    //   342: ldc 1718909296
    //   344: if_icmpne -> 446
    //   347: iload #4
    //   349: bipush #8
    //   351: if_icmpge -> 356
    //   354: iconst_0
    //   355: ireturn
    //   356: aload #18
    //   358: iload #4
    //   360: invokevirtual L : (I)V
    //   363: aload_0
    //   364: aload #18
    //   366: invokevirtual d : ()[B
    //   369: iconst_0
    //   370: iload #4
    //   372: invokeinterface n : ([BII)V
    //   377: iload #4
    //   379: iconst_4
    //   380: idiv
    //   381: istore #6
    //   383: iconst_0
    //   384: istore #4
    //   386: iload #4
    //   388: iload #6
    //   390: if_icmpge -> 434
    //   393: iload #4
    //   395: iconst_1
    //   396: if_icmpne -> 408
    //   399: aload #18
    //   401: iconst_4
    //   402: invokevirtual Q : (I)V
    //   405: goto -> 425
    //   408: aload #18
    //   410: invokevirtual n : ()I
    //   413: iload_2
    //   414: invokestatic a : (IZ)Z
    //   417: ifeq -> 425
    //   420: iconst_1
    //   421: istore_3
    //   422: goto -> 434
    //   425: iload #4
    //   427: iconst_1
    //   428: iadd
    //   429: istore #4
    //   431: goto -> 386
    //   434: iload_3
    //   435: ifne -> 440
    //   438: iconst_0
    //   439: ireturn
    //   440: iload_3
    //   441: istore #6
    //   443: goto -> 465
    //   446: iload_3
    //   447: istore #6
    //   449: iload #4
    //   451: ifeq -> 465
    //   454: aload_0
    //   455: iload #4
    //   457: invokeinterface h : (I)V
    //   462: iload_3
    //   463: istore #6
    //   465: iload #7
    //   467: istore #4
    //   469: iload #6
    //   471: istore_3
    //   472: goto -> 71
    //   475: iconst_1
    //   476: istore_2
    //   477: goto -> 482
    //   480: iconst_0
    //   481: istore_2
    //   482: iload_3
    //   483: ifeq -> 493
    //   486: iload_1
    //   487: iload_2
    //   488: if_icmpne -> 493
    //   491: iconst_1
    //   492: ireturn
    //   493: iconst_0
    //   494: ireturn
  }
  
  public static boolean d(j paramj, boolean paramBoolean) throws IOException {
    return c(paramj, false, paramBoolean);
  }
}


/* Location:              C:\soft\dex2jar-2.0\BabyBus TV_Kids Videos & Games-dex2jar.jar!\a3\n.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */