package a3;

import androidx.annotation.Nullable;
import com.google.android.exoplayer2.util.b0;
import com.google.android.exoplayer2.util.r;
import java.nio.ByteBuffer;
import java.util.UUID;

public final class l {
  public static byte[] a(UUID paramUUID, @Nullable byte[] paramArrayOfbyte) {
    return b(paramUUID, null, paramArrayOfbyte);
  }
  
  public static byte[] b(UUID paramUUID, @Nullable UUID[] paramArrayOfUUID, @Nullable byte[] paramArrayOfbyte) {
    boolean bool = false;
    if (paramArrayOfbyte != null) {
      i = paramArrayOfbyte.length;
    } else {
      i = 0;
    } 
    int j = i + 32;
    int i = j;
    if (paramArrayOfUUID != null)
      i = j + paramArrayOfUUID.length * 16 + 4; 
    ByteBuffer byteBuffer = ByteBuffer.allocate(i);
    byteBuffer.putInt(i);
    byteBuffer.putInt(1886614376);
    if (paramArrayOfUUID != null) {
      i = 16777216;
    } else {
      i = 0;
    } 
    byteBuffer.putInt(i);
    byteBuffer.putLong(paramUUID.getMostSignificantBits());
    byteBuffer.putLong(paramUUID.getLeastSignificantBits());
    if (paramArrayOfUUID != null) {
      byteBuffer.putInt(paramArrayOfUUID.length);
      j = paramArrayOfUUID.length;
      for (i = bool; i < j; i++) {
        paramUUID = paramArrayOfUUID[i];
        byteBuffer.putLong(paramUUID.getMostSignificantBits());
        byteBuffer.putLong(paramUUID.getLeastSignificantBits());
      } 
    } 
    if (paramArrayOfbyte != null && paramArrayOfbyte.length != 0) {
      byteBuffer.putInt(paramArrayOfbyte.length);
      byteBuffer.put(paramArrayOfbyte);
    } 
    return byteBuffer.array();
  }
  
  public static boolean c(byte[] paramArrayOfbyte) {
    return (d(paramArrayOfbyte) != null);
  }
  
  @Nullable
  private static a d(byte[] paramArrayOfbyte) {
    StringBuilder stringBuilder;
    b0 b0 = new b0(paramArrayOfbyte);
    if (b0.f() < 32)
      return null; 
    b0.P(0);
    if (b0.n() != b0.a() + 4)
      return null; 
    if (b0.n() != 1886614376)
      return null; 
    int i = a.c(b0.n());
    if (i > 1) {
      stringBuilder = new StringBuilder(37);
      stringBuilder.append("Unsupported pssh version: ");
      stringBuilder.append(i);
      r.h("PsshAtomUtil", stringBuilder.toString());
      return null;
    } 
    UUID uUID = new UUID(stringBuilder.w(), stringBuilder.w());
    if (i == 1)
      stringBuilder.Q(stringBuilder.H() * 16); 
    int j = stringBuilder.H();
    if (j != stringBuilder.a())
      return null; 
    byte[] arrayOfByte = new byte[j];
    stringBuilder.j(arrayOfByte, 0, j);
    return new a(uUID, i, arrayOfByte);
  }
  
  @Nullable
  public static byte[] e(byte[] paramArrayOfbyte, UUID paramUUID) {
    StringBuilder stringBuilder;
    a a = d(paramArrayOfbyte);
    if (a == null)
      return null; 
    if (!paramUUID.equals(a.a(a))) {
      String str1 = String.valueOf(paramUUID);
      String str2 = String.valueOf(a.a(a));
      stringBuilder = new StringBuilder(str1.length() + 33 + str2.length());
      stringBuilder.append("UUID mismatch. Expected: ");
      stringBuilder.append(str1);
      stringBuilder.append(", got: ");
      stringBuilder.append(str2);
      stringBuilder.append(".");
      r.h("PsshAtomUtil", stringBuilder.toString());
      return null;
    } 
    return a.c((a)stringBuilder);
  }
  
  @Nullable
  public static UUID f(byte[] paramArrayOfbyte) {
    a a = d(paramArrayOfbyte);
    return (a == null) ? null : a.a(a);
  }
  
  public static int g(byte[] paramArrayOfbyte) {
    a a = d(paramArrayOfbyte);
    return (a == null) ? -1 : a.b(a);
  }
  
  private static class a {
    private final UUID a;
    
    private final int b;
    
    private final byte[] c;
    
    public a(UUID param1UUID, int param1Int, byte[] param1ArrayOfbyte) {
      this.a = param1UUID;
      this.b = param1Int;
      this.c = param1ArrayOfbyte;
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\BabyBus TV_Kids Videos & Games-dex2jar.jar!\a3\l.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */