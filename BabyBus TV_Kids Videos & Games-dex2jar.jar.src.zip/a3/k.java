package a3;

import android.util.Pair;
import androidx.annotation.Nullable;
import com.google.android.exoplayer2.Format;
import com.google.android.exoplayer2.audio.c;
import com.google.android.exoplayer2.k1;
import com.google.android.exoplayer2.metadata.Metadata;
import com.google.android.exoplayer2.metadata.mp4.MotionPhotoMetadata;
import com.google.android.exoplayer2.util.b0;
import com.google.android.exoplayer2.util.r0;
import com.google.android.exoplayer2.util.w;
import e4.i;
import java.io.IOException;
import java.util.ArrayDeque;
import java.util.ArrayList;
import java.util.List;
import org.checkerframework.checker.nullness.qual.RequiresNonNull;
import t2.b0;
import t2.i;
import t2.j;
import t2.o;
import t2.u;
import t2.x;
import t2.y;

public final class k implements i, y {
  public static final o y = j.b;
  
  private final int a;
  
  private final b0 b;
  
  private final b0 c;
  
  private final b0 d;
  
  private final b0 e;
  
  private final ArrayDeque<a.a> f;
  
  private final m g;
  
  private final List<Metadata.Entry> h;
  
  private int i;
  
  private int j;
  
  private long k;
  
  private int l;
  
  @Nullable
  private b0 m;
  
  private int n;
  
  private int o;
  
  private int p;
  
  private int q;
  
  private t2.k r;
  
  private a[] s;
  
  private long[][] t;
  
  private int u;
  
  private long v;
  
  private int w;
  
  @Nullable
  private MotionPhotoMetadata x;
  
  public k() {
    this(0);
  }
  
  public k(int paramInt) {
    this.a = paramInt;
    if ((paramInt & 0x4) != 0) {
      paramInt = 3;
    } else {
      paramInt = 0;
    } 
    this.i = paramInt;
    this.g = new m();
    this.h = new ArrayList<Metadata.Entry>();
    this.e = new b0(16);
    this.f = new ArrayDeque<a.a>();
    this.b = new b0(w.a);
    this.c = new b0(4);
    this.d = new b0();
    this.n = -1;
  }
  
  private boolean A(j paramj, x paramx) throws IOException {
    long l1 = this.k - this.l;
    long l2 = paramj.getPosition();
    b0 b01 = this.m;
    if (b01 != null) {
      paramj.readFully(b01.d(), this.l, (int)l1);
      if (this.j == 1718909296) {
        this.w = w(b01);
      } else if (!this.f.isEmpty()) {
        ((a.a)this.f.peek()).e(new a.b(this.j, b01));
      } 
    } else if (l1 < 262144L) {
      paramj.k((int)l1);
    } else {
      paramx.a = paramj.getPosition() + l1;
      boolean bool1 = true;
      u(l2 + l1);
    } 
    boolean bool = false;
    u(l2 + l1);
  }
  
  private int B(j paramj, x paramx) throws IOException {
    byte[] arrayOfByte;
    int i2;
    long l2 = paramj.getPosition();
    if (this.n == -1) {
      int i4 = p(l2);
      this.n = i4;
      if (i4 == -1)
        return -1; 
    } 
    a a1 = ((a[])r0.j(this.s))[this.n];
    b0 b01 = a1.c;
    int i3 = a1.d;
    r r2 = a1.b;
    long l1 = r2.c[i3];
    int i1 = r2.d[i3];
    l2 = l1 - l2 + this.o;
    if (l2 < 0L || l2 >= 262144L) {
      paramx.a = l1;
      return 1;
    } 
    l1 = l2;
    int n = i1;
    if (a1.a.g == 1) {
      l1 = l2 + 8L;
      n = i1 - 8;
    } 
    paramj.k((int)l1);
    o o1 = a1.a;
    if (o1.j != 0) {
      arrayOfByte = this.c.d();
      arrayOfByte[0] = 0;
      arrayOfByte[1] = 0;
      arrayOfByte[2] = 0;
      i1 = a1.a.j;
      int i4 = 4 - i1;
      while (true) {
        i2 = n;
        if (this.p < n) {
          i2 = this.q;
          if (i2 == 0) {
            paramj.readFully(arrayOfByte, i4, i1);
            this.o += i1;
            this.c.P(0);
            i2 = this.c.n();
            if (i2 >= 0) {
              this.q = i2;
              this.b.P(0);
              b01.b(this.b, 4);
              this.p += 4;
              n += i4;
              continue;
            } 
            throw k1.createForMalformedContainer("Invalid NAL length", null);
          } 
          i2 = b01.e((i)paramj, i2, false);
          this.o += i2;
          this.p += i2;
          this.q -= i2;
          continue;
        } 
        break;
      } 
    } else {
      i1 = n;
      if ("audio/ac4".equals(((o)arrayOfByte).f.z)) {
        if (this.p == 0) {
          c.a(n, this.d);
          b01.b(this.d, 7);
          this.p += 7;
        } 
        i1 = n + 7;
      } 
      while (true) {
        n = this.p;
        i2 = i1;
        if (n < i1) {
          n = b01.e((i)paramj, i1 - n, false);
          this.o += n;
          this.p += n;
          this.q -= n;
          continue;
        } 
        break;
      } 
    } 
    r r1 = a1.b;
    b01.d(r1.f[i3], r1.g[i3], i2, 0, null);
    a1.d++;
    this.n = -1;
    this.o = 0;
    this.p = 0;
    this.q = 0;
    return 0;
  }
  
  private int C(j paramj, x paramx) throws IOException {
    int n = this.g.c(paramj, paramx, this.h);
    if (n == 1 && paramx.a == 0L)
      n(); 
    return n;
  }
  
  private static boolean D(int paramInt) {
    return (paramInt == 1836019574 || paramInt == 1953653099 || paramInt == 1835297121 || paramInt == 1835626086 || paramInt == 1937007212 || paramInt == 1701082227 || paramInt == 1835365473);
  }
  
  private static boolean E(int paramInt) {
    return (paramInt == 1835296868 || paramInt == 1836476516 || paramInt == 1751411826 || paramInt == 1937011556 || paramInt == 1937011827 || paramInt == 1937011571 || paramInt == 1668576371 || paramInt == 1701606260 || paramInt == 1937011555 || paramInt == 1937011578 || paramInt == 1937013298 || paramInt == 1937007471 || paramInt == 1668232756 || paramInt == 1953196132 || paramInt == 1718909296 || paramInt == 1969517665 || paramInt == 1801812339 || paramInt == 1768715124);
  }
  
  @RequiresNonNull({"tracks"})
  private void F(long paramLong) {
    for (a a1 : this.s) {
      r r = a1.b;
      int n = r.a(paramLong);
      int j = n;
      if (n == -1)
        j = r.b(paramLong); 
      a1.d = j;
    } 
  }
  
  private static int l(int paramInt) {
    return (paramInt != 1751476579) ? ((paramInt != 1903435808) ? 0 : 1) : 2;
  }
  
  private static long[][] m(a[] paramArrayOfa) {
    long[][] arrayOfLong = new long[paramArrayOfa.length][];
    int[] arrayOfInt = new int[paramArrayOfa.length];
    long[] arrayOfLong1 = new long[paramArrayOfa.length];
    boolean[] arrayOfBoolean = new boolean[paramArrayOfa.length];
    int j;
    for (j = 0; j < paramArrayOfa.length; j++) {
      arrayOfLong[j] = new long[(paramArrayOfa[j]).b.b];
      arrayOfLong1[j] = (paramArrayOfa[j]).b.f[0];
    } 
    long l = 0L;
    for (int n = 0; n < paramArrayOfa.length; n++) {
      long l1 = Long.MAX_VALUE;
      int i1 = -1;
      j = 0;
      while (j < paramArrayOfa.length) {
        long l2 = l1;
        int i2 = i1;
        if (!arrayOfBoolean[j]) {
          l2 = l1;
          i2 = i1;
          if (arrayOfLong1[j] <= l1) {
            l2 = arrayOfLong1[j];
            i2 = j;
          } 
        } 
        j++;
        l1 = l2;
        i1 = i2;
      } 
      j = arrayOfInt[i1];
      arrayOfLong[i1][j] = l;
      l += (paramArrayOfa[i1]).b.d[j];
      arrayOfInt[i1] = ++j;
      if (j < (arrayOfLong[i1]).length) {
        arrayOfLong1[i1] = (paramArrayOfa[i1]).b.f[j];
        continue;
      } 
      arrayOfBoolean[i1] = true;
    } 
    return arrayOfLong;
  }
  
  private void n() {
    this.i = 0;
    this.l = 0;
  }
  
  private static int o(r paramr, long paramLong) {
    int n = paramr.a(paramLong);
    int j = n;
    if (n == -1)
      j = paramr.b(paramLong); 
    return j;
  }
  
  private int p(long paramLong) {
    // Byte code:
    //   0: iconst_m1
    //   1: istore #7
    //   3: iconst_m1
    //   4: istore #4
    //   6: iconst_0
    //   7: istore_3
    //   8: ldc2_w 9223372036854775807
    //   11: lstore #19
    //   13: iconst_1
    //   14: istore #10
    //   16: ldc2_w 9223372036854775807
    //   19: lstore #15
    //   21: iconst_1
    //   22: istore #6
    //   24: ldc2_w 9223372036854775807
    //   27: lstore #11
    //   29: iload_3
    //   30: aload_0
    //   31: getfield s : [La3/k$a;
    //   34: invokestatic j : (Ljava/lang/Object;)Ljava/lang/Object;
    //   37: checkcast [La3/k$a;
    //   40: arraylength
    //   41: if_icmpge -> 282
    //   44: aload_0
    //   45: getfield s : [La3/k$a;
    //   48: iload_3
    //   49: aaload
    //   50: astore #25
    //   52: aload #25
    //   54: getfield d : I
    //   57: istore #5
    //   59: aload #25
    //   61: getfield b : La3/r;
    //   64: astore #25
    //   66: iload #5
    //   68: aload #25
    //   70: getfield b : I
    //   73: if_icmpne -> 83
    //   76: lload #19
    //   78: lstore #23
    //   80: goto -> 271
    //   83: aload #25
    //   85: getfield c : [J
    //   88: iload #5
    //   90: laload
    //   91: lstore #13
    //   93: aload_0
    //   94: getfield t : [[J
    //   97: invokestatic j : (Ljava/lang/Object;)Ljava/lang/Object;
    //   100: checkcast [[J
    //   103: iload_3
    //   104: aaload
    //   105: iload #5
    //   107: laload
    //   108: lstore #21
    //   110: lload #13
    //   112: lload_1
    //   113: lsub
    //   114: lstore #23
    //   116: lload #23
    //   118: lconst_0
    //   119: lcmp
    //   120: iflt -> 141
    //   123: lload #23
    //   125: ldc2_w 262144
    //   128: lcmp
    //   129: iflt -> 135
    //   132: goto -> 141
    //   135: iconst_0
    //   136: istore #5
    //   138: goto -> 144
    //   141: iconst_1
    //   142: istore #5
    //   144: iload #5
    //   146: ifne -> 154
    //   149: iload #6
    //   151: ifne -> 201
    //   154: iload #4
    //   156: istore #9
    //   158: lload #15
    //   160: lstore #17
    //   162: iload #6
    //   164: istore #8
    //   166: lload #11
    //   168: lstore #13
    //   170: iload #5
    //   172: iload #6
    //   174: if_icmpne -> 216
    //   177: iload #4
    //   179: istore #9
    //   181: lload #15
    //   183: lstore #17
    //   185: iload #6
    //   187: istore #8
    //   189: lload #11
    //   191: lstore #13
    //   193: lload #23
    //   195: lload #11
    //   197: lcmp
    //   198: ifge -> 216
    //   201: iload #5
    //   203: istore #8
    //   205: lload #23
    //   207: lstore #13
    //   209: iload_3
    //   210: istore #9
    //   212: lload #21
    //   214: lstore #17
    //   216: iload #9
    //   218: istore #4
    //   220: lload #19
    //   222: lstore #23
    //   224: lload #17
    //   226: lstore #15
    //   228: iload #8
    //   230: istore #6
    //   232: lload #13
    //   234: lstore #11
    //   236: lload #21
    //   238: lload #19
    //   240: lcmp
    //   241: ifge -> 271
    //   244: iload_3
    //   245: istore #7
    //   247: lload #13
    //   249: lstore #11
    //   251: iload #8
    //   253: istore #6
    //   255: lload #17
    //   257: lstore #15
    //   259: iload #5
    //   261: istore #10
    //   263: lload #21
    //   265: lstore #23
    //   267: iload #9
    //   269: istore #4
    //   271: iload_3
    //   272: iconst_1
    //   273: iadd
    //   274: istore_3
    //   275: lload #23
    //   277: lstore #19
    //   279: goto -> 29
    //   282: lload #19
    //   284: ldc2_w 9223372036854775807
    //   287: lcmp
    //   288: ifeq -> 308
    //   291: iload #10
    //   293: ifeq -> 308
    //   296: lload #15
    //   298: lload #19
    //   300: ldc2_w 10485760
    //   303: ladd
    //   304: lcmp
    //   305: ifge -> 312
    //   308: iload #4
    //   310: istore #7
    //   312: iload #7
    //   314: ireturn
  }
  
  private static long s(r paramr, long paramLong1, long paramLong2) {
    int j = o(paramr, paramLong1);
    return (j == -1) ? paramLong2 : Math.min(paramr.c[j], paramLong2);
  }
  
  private void t(j paramj) throws IOException {
    this.d.L(8);
    paramj.n(this.d.d(), 0, 8);
    b.d(this.d);
    paramj.k(this.d.e());
    paramj.c();
  }
  
  private void u(long paramLong) throws k1 {
    while (!this.f.isEmpty() && ((a.a)this.f.peek()).b == paramLong) {
      a.a a1 = this.f.pop();
      if (a1.a == 1836019574) {
        x(a1);
        this.f.clear();
        this.i = 2;
        continue;
      } 
      if (!this.f.isEmpty())
        ((a.a)this.f.peek()).d(a1); 
    } 
    if (this.i != 2)
      n(); 
  }
  
  private void v() {
    if (this.w == 2 && (this.a & 0x2) != 0) {
      Metadata metadata;
      t2.k k1 = (t2.k)com.google.android.exoplayer2.util.a.e(this.r);
      b0 b01 = k1.e(0, 4);
      if (this.x == null) {
        metadata = null;
      } else {
        metadata = new Metadata(new Metadata.Entry[] { (Metadata.Entry)this.x });
      } 
      b01.c((new Format.b()).X(metadata).E());
      k1.q();
      k1.g((y)new y.b(-9223372036854775807L));
    } 
  }
  
  private static int w(b0 paramb0) {
    paramb0.P(8);
    int j = l(paramb0.n());
    if (j != 0)
      return j; 
    paramb0.Q(4);
    while (paramb0.a() > 0) {
      j = l(paramb0.n());
      if (j != 0)
        return j; 
    } 
    return 0;
  }
  
  private void x(a.a parama) throws k1 {
    boolean bool1;
    boolean bool2;
    Metadata metadata;
    ArrayList<a> arrayList2 = new ArrayList();
    if (this.w == 1) {
      bool1 = true;
    } else {
      bool1 = false;
    } 
    u u = new u();
    a.b b = parama.g(1969517665);
    if (b != null) {
      Pair<Metadata, Metadata> pair = b.A(b);
      metadata = (Metadata)pair.first;
      Metadata metadata1 = (Metadata)pair.second;
      if (metadata != null)
        u.c(metadata); 
    } else {
      b = null;
      metadata = null;
    } 
    a.a a1 = parama.f(1835365473);
    if (a1 != null) {
      Metadata metadata1 = b.m(a1);
    } else {
      a1 = null;
    } 
    if ((this.a & 0x1) != 0) {
      bool2 = true;
    } else {
      bool2 = false;
    } 
    List<r> list2 = b.z(parama, u, -9223372036854775807L, null, bool2, bool1, i.a);
    t2.k k1 = (t2.k)com.google.android.exoplayer2.util.a.e(this.r);
    int n = list2.size();
    int i1 = 0;
    int j = -1;
    long l = -9223372036854775807L;
    ArrayList<a> arrayList1 = arrayList2;
    List<r> list1 = list2;
    while (i1 < n) {
      r r = list1.get(i1);
      if (r.b != 0) {
        Metadata metadata1;
        o o1 = r.a;
        ArrayList<a> arrayList = arrayList1;
        long l1 = o1.e;
        if (l1 == -9223372036854775807L)
          l1 = r.h; 
        l = Math.max(l, l1);
        a a2 = new a(o1, r, k1.e(i1, o1.b));
        int i2 = r.e;
        Format.b b1 = o1.f.a();
        b1.W(i2 + 30);
        if (o1.b == 2 && l1 > 0L) {
          i2 = r.b;
          if (i2 > 1)
            b1.P(i2 / (float)l1 / 1000000.0F); 
        } 
        h.k(o1.b, u, b1);
        i2 = o1.b;
        if (this.h.isEmpty()) {
          r = null;
        } else {
          metadata1 = new Metadata(this.h);
        } 
        h.l(i2, metadata, (Metadata)a1, b1, new Metadata[] { (Metadata)b, metadata1 });
        a2.c.c(b1.E());
        if (o1.b == 2 && j == -1)
          j = arrayList.size(); 
        arrayList.add(a2);
      } 
      i1++;
    } 
    this.u = j;
    this.v = l;
    a[] arrayOfA = arrayList1.<a>toArray(new a[0]);
    this.s = arrayOfA;
    this.t = m(arrayOfA);
    k1.q();
    k1.g(this);
  }
  
  private void y(long paramLong) {
    if (this.j == 1836086884) {
      int j = this.l;
      this.x = new MotionPhotoMetadata(0L, paramLong, -9223372036854775807L, paramLong + j, this.k - j);
    } 
  }
  
  private boolean z(j paramj) throws IOException {
    if (this.l == 0) {
      if (!paramj.e(this.e.d(), 0, 8, true)) {
        v();
        return false;
      } 
      this.l = 8;
      this.e.P(0);
      this.k = this.e.F();
      this.j = this.e.n();
    } 
    long l = this.k;
    if (l == 1L) {
      paramj.readFully(this.e.d(), 8, 8);
      this.l += 8;
      this.k = this.e.I();
    } else if (l == 0L) {
      long l1 = paramj.getLength();
      l = l1;
      if (l1 == -1L) {
        a.a a1 = this.f.peek();
        l = l1;
        if (a1 != null)
          l = a1.b; 
      } 
      if (l != -1L)
        this.k = l - paramj.getPosition() + this.l; 
    } 
    if (this.k >= this.l) {
      b0 b01;
      if (D(this.j)) {
        long l1 = paramj.getPosition();
        l = this.k;
        int n = this.l;
        l1 = l1 + l - n;
        if (l != n && this.j == 1835365473)
          t(paramj); 
        this.f.push(new a.a(this.j, l1));
        if (this.k == this.l) {
          u(l1);
          return true;
        } 
        n();
        return true;
      } 
      if (E(this.j)) {
        boolean bool;
        if (this.l == 8) {
          bool = true;
        } else {
          bool = false;
        } 
        com.google.android.exoplayer2.util.a.g(bool);
        if (this.k <= 2147483647L) {
          bool = true;
        } else {
          bool = false;
        } 
        com.google.android.exoplayer2.util.a.g(bool);
        b01 = new b0((int)this.k);
        System.arraycopy(this.e.d(), 0, b01.d(), 0, 8);
        this.m = b01;
        this.i = 1;
        return true;
      } 
      y(b01.getPosition() - this.l);
      this.m = null;
      this.i = 1;
      return true;
    } 
    throw k1.createForUnsupportedContainerFeature("Atom size less than header length (unsupported).");
  }
  
  public void a(long paramLong1, long paramLong2) {
    this.f.clear();
    this.l = 0;
    this.n = -1;
    this.o = 0;
    this.p = 0;
    this.q = 0;
    if (paramLong1 == 0L) {
      if (this.i != 3) {
        n();
        return;
      } 
      this.g.g();
      this.h.clear();
      return;
    } 
    if (this.s != null)
      F(paramLong2); 
  }
  
  public void b(t2.k paramk) {
    this.r = paramk;
  }
  
  public boolean d(j paramj) throws IOException {
    boolean bool;
    if ((this.a & 0x2) != 0) {
      bool = true;
    } else {
      bool = false;
    } 
    return n.d(paramj, bool);
  }
  
  public y.a e(long paramLong) {
    // Byte code:
    //   0: aload_0
    //   1: getfield s : [La3/k$a;
    //   4: invokestatic e : (Ljava/lang/Object;)Ljava/lang/Object;
    //   7: checkcast [La3/k$a;
    //   10: arraylength
    //   11: ifne -> 25
    //   14: new t2/y$a
    //   17: dup
    //   18: getstatic t2/z.c : Lt2/z;
    //   21: invokespecial <init> : (Lt2/z;)V
    //   24: areturn
    //   25: aload_0
    //   26: getfield u : I
    //   29: istore_3
    //   30: iload_3
    //   31: iconst_m1
    //   32: if_icmpeq -> 169
    //   35: aload_0
    //   36: getfield s : [La3/k$a;
    //   39: iload_3
    //   40: aaload
    //   41: getfield b : La3/r;
    //   44: astore #15
    //   46: aload #15
    //   48: lload_1
    //   49: invokestatic o : (La3/r;J)I
    //   52: istore_3
    //   53: iload_3
    //   54: iconst_m1
    //   55: if_icmpne -> 69
    //   58: new t2/y$a
    //   61: dup
    //   62: getstatic t2/z.c : Lt2/z;
    //   65: invokespecial <init> : (Lt2/z;)V
    //   68: areturn
    //   69: aload #15
    //   71: getfield f : [J
    //   74: iload_3
    //   75: laload
    //   76: lstore #9
    //   78: aload #15
    //   80: getfield c : [J
    //   83: iload_3
    //   84: laload
    //   85: lstore #11
    //   87: lload #9
    //   89: lload_1
    //   90: lcmp
    //   91: ifge -> 147
    //   94: iload_3
    //   95: aload #15
    //   97: getfield b : I
    //   100: iconst_1
    //   101: isub
    //   102: if_icmpge -> 147
    //   105: aload #15
    //   107: lload_1
    //   108: invokevirtual b : (J)I
    //   111: istore #4
    //   113: iload #4
    //   115: iconst_m1
    //   116: if_icmpeq -> 147
    //   119: iload #4
    //   121: iload_3
    //   122: if_icmpeq -> 147
    //   125: aload #15
    //   127: getfield f : [J
    //   130: iload #4
    //   132: laload
    //   133: lstore_1
    //   134: aload #15
    //   136: getfield c : [J
    //   139: iload #4
    //   141: laload
    //   142: lstore #5
    //   144: goto -> 156
    //   147: ldc2_w -1
    //   150: lstore #5
    //   152: ldc2_w -9223372036854775807
    //   155: lstore_1
    //   156: lload_1
    //   157: lstore #7
    //   159: lload #5
    //   161: lstore_1
    //   162: lload #11
    //   164: lstore #5
    //   166: goto -> 190
    //   169: ldc2_w 9223372036854775807
    //   172: lstore #5
    //   174: ldc2_w -1
    //   177: lstore #11
    //   179: ldc2_w -9223372036854775807
    //   182: lstore #7
    //   184: lload_1
    //   185: lstore #9
    //   187: lload #11
    //   189: lstore_1
    //   190: iconst_0
    //   191: istore_3
    //   192: aload_0
    //   193: getfield s : [La3/k$a;
    //   196: astore #15
    //   198: iload_3
    //   199: aload #15
    //   201: arraylength
    //   202: if_icmpge -> 280
    //   205: lload_1
    //   206: lstore #13
    //   208: lload #5
    //   210: lstore #11
    //   212: iload_3
    //   213: aload_0
    //   214: getfield u : I
    //   217: if_icmpeq -> 266
    //   220: aload #15
    //   222: iload_3
    //   223: aaload
    //   224: getfield b : La3/r;
    //   227: astore #15
    //   229: aload #15
    //   231: lload #9
    //   233: lload #5
    //   235: invokestatic s : (La3/r;JJ)J
    //   238: lstore #11
    //   240: lload_1
    //   241: lstore #5
    //   243: lload #7
    //   245: ldc2_w -9223372036854775807
    //   248: lcmp
    //   249: ifeq -> 262
    //   252: aload #15
    //   254: lload #7
    //   256: lload_1
    //   257: invokestatic s : (La3/r;JJ)J
    //   260: lstore #5
    //   262: lload #5
    //   264: lstore #13
    //   266: iload_3
    //   267: iconst_1
    //   268: iadd
    //   269: istore_3
    //   270: lload #13
    //   272: lstore_1
    //   273: lload #11
    //   275: lstore #5
    //   277: goto -> 192
    //   280: new t2/z
    //   283: dup
    //   284: lload #9
    //   286: lload #5
    //   288: invokespecial <init> : (JJ)V
    //   291: astore #15
    //   293: lload #7
    //   295: ldc2_w -9223372036854775807
    //   298: lcmp
    //   299: ifne -> 312
    //   302: new t2/y$a
    //   305: dup
    //   306: aload #15
    //   308: invokespecial <init> : (Lt2/z;)V
    //   311: areturn
    //   312: new t2/y$a
    //   315: dup
    //   316: aload #15
    //   318: new t2/z
    //   321: dup
    //   322: lload #7
    //   324: lload_1
    //   325: invokespecial <init> : (JJ)V
    //   328: invokespecial <init> : (Lt2/z;Lt2/z;)V
    //   331: areturn
  }
  
  public int f(j paramj, x paramx) throws IOException {
    while (true) {
      int n = this.i;
      if (n != 0) {
        if (n != 1) {
          if (n != 2) {
            if (n == 3)
              return C(paramj, paramx); 
            throw new IllegalStateException();
          } 
          return B(paramj, paramx);
        } 
        if (A(paramj, paramx))
          return 1; 
        continue;
      } 
      if (!z(paramj))
        return -1; 
    } 
  }
  
  public boolean h() {
    return true;
  }
  
  public long i() {
    return this.v;
  }
  
  public void release() {}
  
  private static final class a {
    public final o a;
    
    public final r b;
    
    public final b0 c;
    
    public int d;
    
    public a(o param1o, r param1r, b0 param1b0) {
      this.a = param1o;
      this.b = param1r;
      this.c = param1b0;
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\BabyBus TV_Kids Videos & Games-dex2jar.jar!\a3\k.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */