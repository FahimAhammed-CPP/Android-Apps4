package a3;

final class c {
  public final int a;
  
  public final int b;
  
  public final int c;
  
  public final int d;
  
  public c(int paramInt1, int paramInt2, int paramInt3, int paramInt4) {
    this.a = paramInt1;
    this.b = paramInt2;
    this.c = paramInt3;
    this.d = paramInt4;
  }
}


/* Location:              C:\soft\dex2jar-2.0\BabyBus TV_Kids Videos & Games-dex2jar.jar!\a3\c.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */