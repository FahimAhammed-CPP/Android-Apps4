package a3;

import com.google.android.exoplayer2.k1;
import com.google.android.exoplayer2.metadata.Metadata;
import com.google.android.exoplayer2.metadata.mp4.SlowMotionData;
import com.google.android.exoplayer2.util.b0;
import com.google.common.base.n;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import t2.j;
import t2.x;

final class m {
  private static final n d = n.d(':');
  
  private static final n e = n.d('*');
  
  private final List<a> a = new ArrayList<a>();
  
  private int b = 0;
  
  private int c;
  
  private void a(j paramj, x paramx) throws IOException {
    b0 b0 = new b0(8);
    paramj.readFully(b0.d(), 0, 8);
    this.c = b0.q() + 8;
    if (b0.n() != 1397048916) {
      paramx.a = 0L;
      return;
    } 
    paramx.a = paramj.getPosition() - (this.c - 12);
    this.b = 2;
  }
  
  private static int b(String paramString) throws k1 {
    paramString.hashCode();
    int i = paramString.hashCode();
    byte b = -1;
    switch (i) {
      case 1760745220:
        if (!paramString.equals("Super_SlowMotion_BGM"))
          break; 
        b = 4;
        break;
      case -830665521:
        if (!paramString.equals("Super_SlowMotion_Deflickering_On"))
          break; 
        b = 3;
        break;
      case -1251387154:
        if (!paramString.equals("Super_SlowMotion_Data"))
          break; 
        b = 2;
        break;
      case -1332107749:
        if (!paramString.equals("Super_SlowMotion_Edit_Data"))
          break; 
        b = 1;
        break;
      case -1711564334:
        if (!paramString.equals("SlowMotion_Data"))
          break; 
        b = 0;
        break;
    } 
    switch (b) {
      default:
        throw k1.createForMalformedContainer("Invalid SEF name", null);
      case 4:
        return 2817;
      case 3:
        return 2820;
      case 2:
        return 2816;
      case 1:
        return 2819;
      case 0:
        break;
    } 
    return 2192;
  }
  
  private void d(j paramj, x paramx) throws IOException {
    long l = paramj.getLength();
    int k = this.c - 12 - 8;
    b0 b0 = new b0(k);
    paramj.readFully(b0.d(), 0, k);
    for (int i = 0; i < k / 12; i++) {
      b0.Q(2);
      short s = b0.s();
      if (s != 2192 && s != 2816 && s != 2817 && s != 2819 && s != 2820) {
        b0.Q(8);
      } else {
        long l1 = this.c;
        long l2 = b0.q();
        int i1 = b0.q();
        this.a.add(new a(s, l - l1 - l2, i1));
      } 
    } 
    if (this.a.isEmpty()) {
      paramx.a = 0L;
      return;
    } 
    this.b = 3;
    paramx.a = ((a)this.a.get(0)).b;
  }
  
  private void e(j paramj, List<Metadata.Entry> paramList) throws IOException {
    long l = paramj.getPosition();
    int k = (int)(paramj.getLength() - paramj.getPosition() - this.c);
    b0 b0 = new b0(k);
    byte[] arrayOfByte = b0.d();
    int i = 0;
    paramj.readFully(arrayOfByte, 0, k);
    while (i < this.a.size()) {
      a a = this.a.get(i);
      b0.P((int)(a.b - l));
      b0.Q(4);
      k = b0.q();
      int i1 = b(b0.A(k));
      int i2 = a.c;
      if (i1 != 2192) {
        if (i1 != 2816 && i1 != 2817 && i1 != 2819 && i1 != 2820)
          throw new IllegalStateException(); 
      } else {
        paramList.add(f(b0, i2 - k + 8));
      } 
      i++;
    } 
  }
  
  private static SlowMotionData f(b0 paramb0, int paramInt) throws k1 {
    ArrayList<SlowMotionData.Segment> arrayList = new ArrayList();
    String str = paramb0.A(paramInt);
    List<CharSequence> list = e.f(str);
    paramInt = 0;
    while (paramInt < list.size()) {
      List<String> list1 = d.f(list.get(paramInt));
      if (list1.size() == 3) {
        try {
          arrayList.add(new SlowMotionData.Segment(Long.parseLong(list1.get(0)), Long.parseLong(list1.get(1)), 1 << Integer.parseInt(list1.get(2)) - 1));
          paramInt++;
        } catch (NumberFormatException numberFormatException) {
          throw k1.createForMalformedContainer(null, numberFormatException);
        } 
        continue;
      } 
      throw k1.createForMalformedContainer(null, null);
    } 
    return new SlowMotionData(arrayList);
  }
  
  public int c(j paramj, x paramx, List<Metadata.Entry> paramList) throws IOException {
    int i = this.b;
    long l2 = 0L;
    if (i != 0) {
      if (i != 1) {
        if (i != 2) {
          if (i == 3) {
            e(paramj, paramList);
            paramx.a = 0L;
            return 1;
          } 
          throw new IllegalStateException();
        } 
        d(paramj, paramx);
        return 1;
      } 
      a(paramj, paramx);
      return 1;
    } 
    long l3 = paramj.getLength();
    long l1 = l2;
    if (l3 != -1L)
      if (l3 < 8L) {
        l1 = l2;
      } else {
        l1 = l3 - 8L;
      }  
    paramx.a = l1;
    this.b = 1;
    return 1;
  }
  
  public void g() {
    this.a.clear();
    this.b = 0;
  }
  
  private static final class a {
    public final int a;
    
    public final long b;
    
    public final int c;
    
    public a(int param1Int1, long param1Long, int param1Int2) {
      this.a = param1Int1;
      this.b = param1Long;
      this.c = param1Int2;
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\BabyBus TV_Kids Videos & Games-dex2jar.jar!\a3\m.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */