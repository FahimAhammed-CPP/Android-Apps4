package a3;

import androidx.annotation.Nullable;
import com.google.android.exoplayer2.util.b0;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

abstract class a {
  public final int a;
  
  public a(int paramInt) {
    this.a = paramInt;
  }
  
  public static String a(int paramInt) {
    char c1 = (char)(paramInt >> 24 & 0xFF);
    char c2 = (char)(paramInt >> 16 & 0xFF);
    char c3 = (char)(paramInt >> 8 & 0xFF);
    char c4 = (char)(paramInt & 0xFF);
    StringBuilder stringBuilder = new StringBuilder(4);
    stringBuilder.append(c1);
    stringBuilder.append(c2);
    stringBuilder.append(c3);
    stringBuilder.append(c4);
    return stringBuilder.toString();
  }
  
  public static int b(int paramInt) {
    return paramInt & 0xFFFFFF;
  }
  
  public static int c(int paramInt) {
    return paramInt >> 24 & 0xFF;
  }
  
  public String toString() {
    return a(this.a);
  }
  
  static final class a extends a {
    public final long b;
    
    public final List<a.b> c;
    
    public final List<a> d;
    
    public a(int param1Int, long param1Long) {
      super(param1Int);
      this.b = param1Long;
      this.c = new ArrayList<a.b>();
      this.d = new ArrayList<a>();
    }
    
    public void d(a param1a) {
      this.d.add(param1a);
    }
    
    public void e(a.b param1b) {
      this.c.add(param1b);
    }
    
    @Nullable
    public a f(int param1Int) {
      int j = this.d.size();
      for (int i = 0; i < j; i++) {
        a a1 = this.d.get(i);
        if (a1.a == param1Int)
          return a1; 
      } 
      return null;
    }
    
    @Nullable
    public a.b g(int param1Int) {
      int j = this.c.size();
      for (int i = 0; i < j; i++) {
        a.b b = this.c.get(i);
        if (b.a == param1Int)
          return b; 
      } 
      return null;
    }
    
    public String toString() {
      String str1 = a.a(this.a);
      String str2 = Arrays.toString(this.c.toArray());
      String str3 = Arrays.toString(this.d.toArray());
      StringBuilder stringBuilder = new StringBuilder(String.valueOf(str1).length() + 22 + String.valueOf(str2).length() + String.valueOf(str3).length());
      stringBuilder.append(str1);
      stringBuilder.append(" leaves: ");
      stringBuilder.append(str2);
      stringBuilder.append(" containers: ");
      stringBuilder.append(str3);
      return stringBuilder.toString();
    }
  }
  
  static final class b extends a {
    public final b0 b;
    
    public b(int param1Int, b0 param1b0) {
      super(param1Int);
      this.b = param1b0;
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\BabyBus TV_Kids Videos & Games-dex2jar.jar!\a3\a.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */