package a3;

import androidx.annotation.Nullable;
import com.google.android.exoplayer2.Format;

public final class o {
  public final int a;
  
  public final int b;
  
  public final long c;
  
  public final long d;
  
  public final long e;
  
  public final Format f;
  
  public final int g;
  
  @Nullable
  public final long[] h;
  
  @Nullable
  public final long[] i;
  
  public final int j;
  
  @Nullable
  private final p[] k;
  
  public o(int paramInt1, int paramInt2, long paramLong1, long paramLong2, long paramLong3, Format paramFormat, int paramInt3, @Nullable p[] paramArrayOfp, int paramInt4, @Nullable long[] paramArrayOflong1, @Nullable long[] paramArrayOflong2) {
    this.a = paramInt1;
    this.b = paramInt2;
    this.c = paramLong1;
    this.d = paramLong2;
    this.e = paramLong3;
    this.f = paramFormat;
    this.g = paramInt3;
    this.k = paramArrayOfp;
    this.j = paramInt4;
    this.h = paramArrayOflong1;
    this.i = paramArrayOflong2;
  }
  
  @Nullable
  public p a(int paramInt) {
    p[] arrayOfP = this.k;
    return (arrayOfP == null) ? null : arrayOfP[paramInt];
  }
}


/* Location:              C:\soft\dex2jar-2.0\BabyBus TV_Kids Videos & Games-dex2jar.jar!\a3\o.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */