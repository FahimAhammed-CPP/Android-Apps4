package a3;

import android.util.Pair;
import androidx.annotation.Nullable;
import com.google.android.exoplayer2.Format;
import com.google.android.exoplayer2.drm.DrmInitData;
import com.google.android.exoplayer2.k1;
import com.google.android.exoplayer2.metadata.Metadata;
import com.google.android.exoplayer2.metadata.mp4.MdtaMetadataEntry;
import com.google.android.exoplayer2.metadata.mp4.SmtaMetadataEntry;
import com.google.android.exoplayer2.util.b0;
import com.google.android.exoplayer2.util.r;
import com.google.android.exoplayer2.util.r0;
import com.google.android.exoplayer2.util.v;
import com.google.android.exoplayer2.video.ColorInfo;
import com.google.common.base.g;
import com.google.common.collect.b0;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import t2.l;
import t2.u;

final class b {
  private static final byte[] a = r0.h0("OpusHead");
  
  public static Pair<Metadata, Metadata> A(a.b paramb) {
    b0 b0 = paramb.b;
    b0.P(8);
    paramb = null;
    Metadata metadata = null;
    while (b0.a() >= 8) {
      a.b b1;
      int i = b0.e();
      int j = b0.n();
      int k = b0.n();
      if (k == 1835365473) {
        b0.P(i);
        Metadata metadata1 = B(b0, i + j);
      } else {
        b1 = paramb;
        if (k == 1936553057) {
          b0.P(i);
          metadata = t(b0, i + j);
          b1 = paramb;
        } 
      } 
      b0.P(i + j);
      paramb = b1;
    } 
    return Pair.create(paramb, metadata);
  }
  
  @Nullable
  private static Metadata B(b0 paramb0, int paramInt) {
    paramb0.Q(8);
    d(paramb0);
    while (paramb0.e() < paramInt) {
      int i = paramb0.e();
      int j = paramb0.n();
      if (paramb0.n() == 1768715124) {
        paramb0.P(i);
        return k(paramb0, i + j);
      } 
      paramb0.P(i + j);
    } 
    return null;
  }
  
  private static void C(b0 paramb0, int paramInt1, int paramInt2, int paramInt3, int paramInt4, int paramInt5, @Nullable DrmInitData paramDrmInitData, c paramc, int paramInt6) throws k1 {
    b0 b01;
    Object object1;
    b0 b02 = paramb0;
    int j = paramInt2;
    b02.P(j + 8 + 8);
    b02.Q(16);
    int m = paramb0.J();
    int n = paramb0.J();
    b02.Q(50);
    int k = paramb0.e();
    DrmInitData drmInitData1 = paramDrmInitData;
    int i = paramInt1;
    if (paramInt1 == 1701733238) {
      Pair<Integer, p> pair = r(b02, j, paramInt3);
      drmInitData1 = paramDrmInitData;
      if (pair != null) {
        paramInt1 = ((Integer)pair.first).intValue();
        if (paramDrmInitData == null) {
          drmInitData1 = null;
        } else {
          drmInitData1 = paramDrmInitData.c(((p)pair.second).b);
        } 
        paramc.a[paramInt6] = (p)pair.second;
      } 
      b02.P(k);
      i = paramInt1;
    } 
    String str = "video/3gpp";
    if (i == 1831958048) {
      String str1 = "video/mpeg";
    } else if (i == 1211250227) {
      String str1 = "video/3gpp";
    } else {
      b02 = null;
    } 
    paramInt6 = -1;
    float f = 1.0F;
    Object object2 = null;
    paramDrmInitData = null;
    Object object3 = null;
    Object object4 = null;
    j = 0;
    b0 b03 = b02;
    DrmInitData drmInitData2 = drmInitData1;
    while (true) {
      int i1 = paramInt3;
      paramInt1 = paramInt2;
      b0 b04 = paramb0;
      if (k - paramInt1 < i1) {
        boolean bool;
        Object object7;
        b04.P(k);
        int i3 = paramb0.e();
        int i2 = paramb0.n();
        if (i2 == 0 && paramb0.e() - paramInt1 == i1)
          break; 
        if (i2 > 0) {
          bool = true;
        } else {
          bool = false;
        } 
        l.a(bool, "childAtomSize must be positive");
        i1 = paramb0.n();
        if (i1 == 1635148611) {
          if (b03 == null) {
            bool = true;
          } else {
            bool = false;
          } 
          l.a(bool, null);
          b04.P(i3 + 8);
          f4.a a = f4.a.b(paramb0);
          List list = a.a;
          paramc.c = a.b;
          if (object1 == null)
            f = a.e; 
          object2 = a.f;
          String str1 = "video/avc";
        } else {
          List list;
          if (i1 == 1752589123) {
            if (b03 == null) {
              bool = true;
            } else {
              bool = false;
            } 
            l.a(bool, null);
            b04.P(i3 + 8);
            f4.d d = f4.d.a(paramb0);
            list = d.a;
            paramc.c = d.b;
            object2 = d.c;
            String str1 = "video/hevc";
          } else {
            Object object;
            f4.b b1;
            if (i1 == 1685480259 || i1 == 1685485123) {
              b1 = f4.b.a(paramb0);
              b02 = b03;
              paramInt1 = paramInt6;
              float f2 = f;
              List list1 = list;
              Object object9 = object3;
              Object object10 = object4;
              object = object1;
              if (b1 != null) {
                object2 = b1.c;
                String str1 = "video/dolby-vision";
                object = object1;
                object10 = object4;
                object9 = object3;
                list1 = list;
                f2 = f;
                paramInt1 = paramInt6;
              } 
              continue;
            } 
            if (object == 1987076931) {
              if (b03 == null) {
                bool = true;
              } else {
                bool = false;
              } 
              l.a(bool, null);
              if (i == 1987063864) {
                String str1 = "video/x-vnd.on2.vp8";
              } else {
                String str1 = "video/x-vnd.on2.vp9";
              } 
            } else {
              if (object == 1635135811) {
                if (b03 == null) {
                  bool = true;
                } else {
                  bool = false;
                } 
                l.a(bool, null);
                String str1 = "video/av01";
                paramInt1 = paramInt6;
                float f2 = f;
                List list1 = list;
                Object object10 = object3;
                object9 = object4;
                object = object1;
                continue;
              } 
              if (object == 1681012275) {
                if (b03 == null) {
                  bool = true;
                } else {
                  bool = false;
                } 
                l.a(bool, null);
                String str1 = str;
                paramInt1 = paramInt6;
                float f2 = f;
                List list1 = list;
                Object object10 = object3;
                object9 = object4;
                object = object1;
                continue;
              } 
              if (object == 1702061171) {
                if (b03 == null) {
                  bool = true;
                } else {
                  bool = false;
                } 
                l.a(bool, null);
                Pair<String, byte[]> pair = h((b0)b1, i3);
                String str1 = (String)pair.first;
                byte[] arrayOfByte = (byte[])pair.second;
                if (arrayOfByte != null)
                  b01 = b0.of(arrayOfByte); 
                paramInt1 = paramInt6;
                object9 = object2;
                float f2 = f;
                b0 b06 = b01;
                Object object10 = object3;
              } else {
                int i4;
                if (object == 1885434736) {
                  float f2 = p((b0)b1, i3);
                  i4 = 1;
                  b02 = b03;
                  paramInt1 = paramInt6;
                  b0 b06 = b01;
                  Object object10 = object3;
                  object9 = object4;
                  continue;
                } 
                if (i4 == 1937126244) {
                  byte[] arrayOfByte = q((b0)b1, i3, i2);
                  b02 = b03;
                  paramInt1 = paramInt6;
                  object9 = object2;
                  float f2 = f;
                  b0 b06 = b01;
                } else if (i4 == 1936995172) {
                  i4 = paramb0.D();
                  b1.Q(3);
                  b02 = b03;
                  paramInt1 = paramInt6;
                  object9 = object2;
                  float f2 = f;
                  b0 b06 = b01;
                  Object object10 = object3;
                  if (i4 == 0) {
                    paramInt1 = paramb0.D();
                    if (paramInt1 != 0) {
                      if (paramInt1 != 1) {
                        if (paramInt1 != 2) {
                          if (paramInt1 != 3) {
                            b02 = b03;
                            paramInt1 = paramInt6;
                            object9 = object2;
                            f2 = f;
                            b06 = b01;
                            object10 = object3;
                          } else {
                            paramInt1 = 3;
                            b02 = b03;
                            object9 = object2;
                            f2 = f;
                            b06 = b01;
                            object10 = object3;
                          } 
                        } else {
                          paramInt1 = 2;
                          b02 = b03;
                          object9 = object2;
                          f2 = f;
                          b06 = b01;
                          object10 = object3;
                        } 
                      } else {
                        paramInt1 = 1;
                        b02 = b03;
                        object9 = object2;
                        f2 = f;
                        b06 = b01;
                        object10 = object3;
                      } 
                    } else {
                      paramInt1 = 0;
                      b02 = b03;
                      object9 = object2;
                      f2 = f;
                      b06 = b01;
                      object10 = object3;
                    } 
                  } 
                } else {
                  b02 = b03;
                  paramInt1 = paramInt6;
                  object9 = object2;
                  float f2 = f;
                  b0 b06 = b01;
                  Object object10 = object3;
                  if (i4 == 1668246642) {
                    Object object11;
                    i4 = paramb0.n();
                    if (i4 == 1852009592) {
                      paramInt1 = 1;
                    } else {
                      paramInt1 = 0;
                    } 
                    if (paramInt1 != 0 || i4 == 1852009571) {
                      i3 = paramb0.J();
                      i4 = paramb0.J();
                      b1.Q(2);
                      if (paramInt1 != 0 && (paramb0.D() & 0x80) != 0) {
                        paramInt1 = 1;
                      } else {
                        paramInt1 = 0;
                      } 
                      i3 = ColorInfo.a(i3);
                      if (paramInt1 != 0) {
                        paramInt1 = 1;
                      } else {
                        paramInt1 = 2;
                      } 
                      ColorInfo colorInfo = new ColorInfo(i3, paramInt1, ColorInfo.b(i4), null);
                      b02 = b03;
                      paramInt1 = paramInt6;
                      f2 = f;
                      b06 = b01;
                      object10 = object3;
                      object11 = object1;
                    } else {
                      String str1 = String.valueOf(a.a(object11));
                      if (str1.length() != 0) {
                        str1 = "Unsupported color type: ".concat(str1);
                      } else {
                        str1 = new String("Unsupported color type: ");
                      } 
                      r.h("AtomParsers", str1);
                      b0 b07 = b03;
                      paramInt1 = paramInt6;
                      object9 = object2;
                      f2 = f;
                      b06 = b01;
                      object10 = object3;
                      object2 = object9;
                      object9 = object4;
                      object11 = object1;
                    } 
                    continue;
                  } 
                } 
              } 
              object7 = object9;
              Object object9 = object4;
              object = object1;
            } 
          } 
        } 
        Object object8 = object3;
        b0 b05 = b01;
        float f1 = f;
        object6 = object7;
        paramInt1 = paramInt6;
      } else {
        break;
      } 
      object2 = object6;
      Object object6 = object4;
      Object object5 = object1;
      k += SYNTHETIC_LOCAL_VARIABLE_17;
      b03 = b02;
      paramInt6 = paramInt1;
      object = SYNTHETIC_LOCAL_VARIABLE_10;
      paramDrmInitData = drmInitData1;
      object3 = SYNTHETIC_LOCAL_VARIABLE_26;
      object4 = SYNTHETIC_LOCAL_VARIABLE_27;
      object1 = SYNTHETIC_LOCAL_VARIABLE_14;
    } 
    if (b03 == null)
      return; 
    paramc.b = (new Format.b()).R(paramInt4).e0((String)b03).I((String)object2).j0(m).Q(n).a0(f).d0(paramInt5).b0((byte[])object3).h0(paramInt6).T((List)b01).L(drmInitData2).J((ColorInfo)object4).E();
  }
  
  private static boolean a(long[] paramArrayOflong, long paramLong1, long paramLong2, long paramLong3) {
    int j = paramArrayOflong.length - 1;
    int i = r0.r(4, 0, j);
    j = r0.r(paramArrayOflong.length - 4, 0, j);
    return (paramArrayOflong[0] <= paramLong2 && paramLong2 < paramArrayOflong[i] && paramArrayOflong[j] < paramLong3 && paramLong3 <= paramLong1);
  }
  
  private static int b(b0 paramb0, int paramInt1, int paramInt2) throws k1 {
    for (int i = paramb0.e(); i - paramInt1 < paramInt2; i += j) {
      boolean bool;
      paramb0.P(i);
      int j = paramb0.n();
      if (j > 0) {
        bool = true;
      } else {
        bool = false;
      } 
      l.a(bool, "childAtomSize must be positive");
      if (paramb0.n() == 1702061171)
        return i; 
    } 
    return -1;
  }
  
  private static int c(int paramInt) {
    return (paramInt == 1936684398) ? 1 : ((paramInt == 1986618469) ? 2 : ((paramInt == 1952807028 || paramInt == 1935832172 || paramInt == 1937072756 || paramInt == 1668047728) ? 3 : ((paramInt == 1835365473) ? 5 : -1)));
  }
  
  public static void d(b0 paramb0) {
    int j = paramb0.e();
    paramb0.Q(4);
    int i = j;
    if (paramb0.n() != 1751411826)
      i = j + 4; 
    paramb0.P(i);
  }
  
  private static void e(b0 paramb0, int paramInt1, int paramInt2, int paramInt3, int paramInt4, String paramString, boolean paramBoolean, @Nullable DrmInitData paramDrmInitData, c paramc, int paramInt5) throws k1 {
    int i;
    int j = paramInt2;
    paramb0.P(j + 8 + 8);
    if (paramBoolean) {
      i = paramb0.J();
      paramb0.Q(6);
    } else {
      paramb0.Q(8);
      i = 0;
    } 
    if (!i || i == 1) {
      int n = paramb0.J();
      paramb0.Q(6);
      int m = paramb0.E();
      if (i == 1)
        paramb0.Q(16); 
      i = n;
    } else if (i == 2) {
      paramb0.Q(16);
      int m = (int)Math.round(paramb0.l());
      i = paramb0.H();
      paramb0.Q(20);
    } else {
      return;
    } 
    int k = paramb0.e();
    if (paramInt1 == 1701733217) {
      Pair<Integer, p> pair = r(paramb0, j, paramInt3);
      if (pair != null) {
        paramInt1 = ((Integer)pair.first).intValue();
        if (paramDrmInitData == null) {
          paramDrmInitData = null;
        } else {
          paramDrmInitData = paramDrmInitData.c(((p)pair.second).b);
        } 
        paramc.a[paramInt5] = (p)pair.second;
      } 
      paramb0.P(k);
      DrmInitData drmInitData = paramDrmInitData;
    } else {
      DrmInitData drmInitData = paramDrmInitData;
    } 
    String str = "audio/raw";
    if (paramInt1 == 1633889587) {
      str = "audio/ac3";
    } else if (paramInt1 == 1700998451) {
      str = "audio/eac3";
    } else if (paramInt1 == 1633889588) {
      str = "audio/ac4";
    } else if (paramInt1 == 1685353315) {
      str = "audio/vnd.dts";
    } else if (paramInt1 == 1685353320 || paramInt1 == 1685353324) {
      str = "audio/vnd.dts.hd";
    } else if (paramInt1 == 1685353317) {
      str = "audio/vnd.dts.hd;profile=lbr";
    } else if (paramInt1 == 1685353336) {
      str = "audio/vnd.dts.uhd";
    } else if (paramInt1 == 1935764850) {
      str = "audio/3gpp";
    } else if (paramInt1 == 1935767394) {
      str = "audio/amr-wb";
    } else {
      if (paramInt1 == 1819304813 || paramInt1 == 1936684916) {
        paramInt1 = 2;
      } else if (paramInt1 == 1953984371) {
        paramInt1 = 268435456;
      } else {
        if (paramInt1 == 778924082 || paramInt1 == 778924083) {
          str = "audio/mpeg";
        } else if (paramInt1 == 1835557169) {
          str = "audio/mha1";
        } else if (paramInt1 == 1835560241) {
          str = "audio/mhm1";
        } else if (paramInt1 == 1634492771) {
          str = "audio/alac";
        } else if (paramInt1 == 1634492791) {
          str = "audio/g711-alaw";
        } else if (paramInt1 == 1970037111) {
          str = "audio/g711-mlaw";
        } else if (paramInt1 == 1332770163) {
          str = "audio/opus";
        } else if (paramInt1 == 1716281667) {
          str = "audio/flac";
        } else {
          paramInt1 = -1;
          str = null;
          Object object3 = null;
          Object object4 = null;
          String str2 = str;
          paramInt5 = k;
        } 
        paramInt1 = -1;
      } 
      Object object1 = null;
      Object object2 = null;
      String str1 = str;
      paramInt5 = k;
    } 
    paramInt1 = -1;
  }
  
  @Nullable
  static Pair<Integer, p> f(b0 paramb0, int paramInt1, int paramInt2) throws k1 {
    int i = paramInt1 + 8;
    boolean bool = false;
    String str2 = null;
    String str1 = str2;
    int k = -1;
    int j = 0;
    while (i - paramInt1 < paramInt2) {
      String str3;
      String str4;
      paramb0.P(i);
      int m = paramb0.n();
      int n = paramb0.n();
      if (n == 1718775137) {
        str4 = (String)Integer.valueOf(paramb0.n());
        str3 = str2;
      } else if (n == 1935894637) {
        paramb0.Q(4);
        str3 = paramb0.A(4);
        str4 = str1;
      } else {
        str3 = str2;
        str4 = str1;
        if (n == 1935894633) {
          k = i;
          j = m;
          str4 = str1;
          str3 = str2;
        } 
      } 
      i += m;
      str2 = str3;
      str1 = str4;
    } 
    if ("cenc".equals(str2) || "cbc1".equals(str2) || "cens".equals(str2) || "cbcs".equals(str2)) {
      if (str1 != null) {
        bool1 = true;
      } else {
        bool1 = false;
      } 
      l.a(bool1, "frma atom is mandatory");
      if (k != -1) {
        bool1 = true;
      } else {
        bool1 = false;
      } 
      l.a(bool1, "schi atom is mandatory");
      p p = s(paramb0, k, j, str2);
      boolean bool1 = bool;
      if (p != null)
        bool1 = true; 
      l.a(bool1, "tenc atom is mandatory");
      return Pair.create(str1, r0.j(p));
    } 
    return null;
  }
  
  @Nullable
  private static Pair<long[], long[]> g(a.a parama) {
    a.b b1 = parama.g(1701606260);
    if (b1 == null)
      return null; 
    b0 b0 = b1.b;
    b0.P(8);
    int j = a.c(b0.n());
    int k = b0.H();
    long[] arrayOfLong1 = new long[k];
    long[] arrayOfLong2 = new long[k];
    int i = 0;
    while (i < k) {
      long l;
      if (j == 1) {
        l = b0.I();
      } else {
        l = b0.F();
      } 
      arrayOfLong1[i] = l;
      if (j == 1) {
        l = b0.w();
      } else {
        l = b0.n();
      } 
      arrayOfLong2[i] = l;
      if (b0.z() == 1) {
        b0.Q(2);
        i++;
        continue;
      } 
      throw new IllegalArgumentException("Unsupported media rate.");
    } 
    return Pair.create(arrayOfLong1, arrayOfLong2);
  }
  
  private static Pair<String, byte[]> h(b0 paramb0, int paramInt) {
    paramb0.P(paramInt + 8 + 4);
    paramb0.Q(1);
    i(paramb0);
    paramb0.Q(2);
    paramInt = paramb0.D();
    if ((paramInt & 0x80) != 0)
      paramb0.Q(2); 
    if ((paramInt & 0x40) != 0)
      paramb0.Q(paramb0.J()); 
    if ((paramInt & 0x20) != 0)
      paramb0.Q(2); 
    paramb0.Q(1);
    i(paramb0);
    String str = v.h(paramb0.D());
    if ("audio/mpeg".equals(str) || "audio/vnd.dts".equals(str) || "audio/vnd.dts.hd".equals(str))
      return Pair.create(str, null); 
    paramb0.Q(12);
    paramb0.Q(1);
    paramInt = i(paramb0);
    byte[] arrayOfByte = new byte[paramInt];
    paramb0.j(arrayOfByte, 0, paramInt);
    return Pair.create(str, arrayOfByte);
  }
  
  private static int i(b0 paramb0) {
    int j = paramb0.D();
    int i;
    for (i = j & 0x7F; (j & 0x80) == 128; i = i << 7 | j & 0x7F)
      j = paramb0.D(); 
    return i;
  }
  
  private static int j(b0 paramb0) {
    paramb0.P(16);
    return paramb0.n();
  }
  
  @Nullable
  private static Metadata k(b0 paramb0, int paramInt) {
    paramb0.Q(8);
    ArrayList<Metadata.Entry> arrayList = new ArrayList();
    while (paramb0.e() < paramInt) {
      Metadata.Entry entry = h.c(paramb0);
      if (entry != null)
        arrayList.add(entry); 
    } 
    return arrayList.isEmpty() ? null : new Metadata(arrayList);
  }
  
  private static Pair<Long, String> l(b0 paramb0) {
    byte b1 = 8;
    paramb0.P(8);
    int j = a.c(paramb0.n());
    if (j == 0) {
      i = 8;
    } else {
      i = 16;
    } 
    paramb0.Q(i);
    long l = paramb0.F();
    int i = b1;
    if (j == 0)
      i = 4; 
    paramb0.Q(i);
    i = paramb0.J();
    char c1 = (char)((i >> 10 & 0x1F) + 96);
    char c2 = (char)((i >> 5 & 0x1F) + 96);
    char c3 = (char)((i & 0x1F) + 96);
    StringBuilder stringBuilder = new StringBuilder(3);
    stringBuilder.append(c1);
    stringBuilder.append(c2);
    stringBuilder.append(c3);
    return Pair.create(Long.valueOf(l), stringBuilder.toString());
  }
  
  @Nullable
  public static Metadata m(a.a parama) {
    Metadata metadata;
    a.b b2 = parama.g(1751411826);
    a.b b3 = parama.g(1801812339);
    a.b b1 = parama.g(1768715124);
    a.a a1 = null;
    parama = a1;
    if (b2 != null) {
      parama = a1;
      if (b3 != null) {
        parama = a1;
        if (b1 != null) {
          if (j(b2.b) != 1835299937)
            return null; 
          b0 b0 = b3.b;
          b0.P(12);
          int j = b0.n();
          String[] arrayOfString = new String[j];
          int i;
          for (i = 0; i < j; i++) {
            int k = b0.n();
            b0.Q(4);
            arrayOfString[i] = b0.A(k - 8);
          } 
          b0 = b1.b;
          b0.P(8);
          ArrayList<MdtaMetadataEntry> arrayList = new ArrayList();
          while (b0.a() > 8) {
            i = b0.e();
            int k = b0.n();
            int m = b0.n() - 1;
            if (m >= 0 && m < j) {
              MdtaMetadataEntry mdtaMetadataEntry = h.f(b0, i + k, arrayOfString[m]);
              if (mdtaMetadataEntry != null)
                arrayList.add(mdtaMetadataEntry); 
            } else {
              StringBuilder stringBuilder = new StringBuilder(52);
              stringBuilder.append("Skipped metadata with unknown key index: ");
              stringBuilder.append(m);
              r.h("AtomParsers", stringBuilder.toString());
            } 
            b0.P(i + k);
          } 
          if (arrayList.isEmpty())
            return null; 
          metadata = new Metadata(arrayList);
        } 
      } 
    } 
    return metadata;
  }
  
  private static void n(b0 paramb0, int paramInt1, int paramInt2, int paramInt3, c paramc) {
    paramb0.P(paramInt2 + 8 + 8);
    if (paramInt1 == 1835365492) {
      paramb0.x();
      String str = paramb0.x();
      if (str != null)
        paramc.b = (new Format.b()).R(paramInt3).e0(str).E(); 
    } 
  }
  
  private static long o(b0 paramb0) {
    byte b1 = 8;
    paramb0.P(8);
    if (a.c(paramb0.n()) != 0)
      b1 = 16; 
    paramb0.Q(b1);
    return paramb0.F();
  }
  
  private static float p(b0 paramb0, int paramInt) {
    paramb0.P(paramInt + 8);
    paramInt = paramb0.H();
    int i = paramb0.H();
    return paramInt / i;
  }
  
  @Nullable
  private static byte[] q(b0 paramb0, int paramInt1, int paramInt2) {
    for (int i = paramInt1 + 8; i - paramInt1 < paramInt2; i += j) {
      paramb0.P(i);
      int j = paramb0.n();
      if (paramb0.n() == 1886547818)
        return Arrays.copyOfRange(paramb0.d(), i, j + i); 
    } 
    return null;
  }
  
  @Nullable
  private static Pair<Integer, p> r(b0 paramb0, int paramInt1, int paramInt2) throws k1 {
    for (int i = paramb0.e(); i - paramInt1 < paramInt2; i += j) {
      boolean bool;
      paramb0.P(i);
      int j = paramb0.n();
      if (j > 0) {
        bool = true;
      } else {
        bool = false;
      } 
      l.a(bool, "childAtomSize must be positive");
      if (paramb0.n() == 1936289382) {
        Pair<Integer, p> pair = f(paramb0, i, j);
        if (pair != null)
          return pair; 
      } 
    } 
    return null;
  }
  
  @Nullable
  private static p s(b0 paramb0, int paramInt1, int paramInt2, String paramString) {
    int i = paramInt1 + 8;
    while (true) {
      byte[] arrayOfByte = null;
      if (i - paramInt1 < paramInt2) {
        paramb0.P(i);
        int j = paramb0.n();
        if (paramb0.n() == 1952804451) {
          boolean bool;
          paramInt1 = a.c(paramb0.n());
          paramb0.Q(1);
          if (paramInt1 == 0) {
            paramb0.Q(1);
            paramInt1 = 0;
            paramInt2 = 0;
          } else {
            paramInt1 = paramb0.D();
            paramInt2 = paramInt1 & 0xF;
            paramInt1 = (paramInt1 & 0xF0) >> 4;
          } 
          if (paramb0.D() == 1) {
            bool = true;
          } else {
            bool = false;
          } 
          i = paramb0.D();
          byte[] arrayOfByte2 = new byte[16];
          paramb0.j(arrayOfByte2, 0, 16);
          byte[] arrayOfByte1 = arrayOfByte;
          if (bool) {
            arrayOfByte1 = arrayOfByte;
            if (i == 0) {
              j = paramb0.D();
              arrayOfByte1 = new byte[j];
              paramb0.j(arrayOfByte1, 0, j);
            } 
          } 
          return new p(bool, paramString, i, arrayOfByte2, paramInt1, paramInt2, arrayOfByte1);
        } 
        i += j;
        continue;
      } 
      return null;
    } 
  }
  
  @Nullable
  private static Metadata t(b0 paramb0, int paramInt) {
    paramb0.Q(12);
    while (paramb0.e() < paramInt) {
      int i = paramb0.e();
      int j = paramb0.n();
      if (paramb0.n() == 1935766900) {
        float f;
        if (j < 14)
          return null; 
        paramb0.Q(5);
        paramInt = paramb0.D();
        if (paramInt != 12 && paramInt != 13)
          return null; 
        if (paramInt == 12) {
          f = 240.0F;
        } else {
          f = 120.0F;
        } 
        paramb0.Q(1);
        return new Metadata(new Metadata.Entry[] { (Metadata.Entry)new SmtaMetadataEntry(f, paramb0.D()) });
      } 
      paramb0.P(i + j);
    } 
    return null;
  }
  
  private static r u(o paramo, a.a parama, u paramu) throws k1 {
    long[] arrayOfLong1;
    int i;
    int k;
    boolean bool;
    long l1;
    long[] arrayOfLong2;
    e e;
    int[] arrayOfInt2;
    int[] arrayOfInt3;
    b0 b02;
    d.b b3;
    a.b b2 = parama.g(1937011578);
    if (b2 != null) {
      d d = new d(b2, paramo.f);
    } else {
      b2 = parama.g(1937013298);
      if (b2 != null) {
        e = new e(b2);
      } else {
        throw k1.createForMalformedContainer("Track has no sample table size information", null);
      } 
    } 
    int i2 = e.c();
    if (i2 == 0)
      return new r(paramo, new long[0], new int[0], 0, new long[0], new int[0], 0L); 
    b2 = parama.g(1937007471);
    if (b2 == null) {
      b2 = (a.b)com.google.android.exoplayer2.util.a.e(parama.g(1668232756));
      bool = true;
    } else {
      bool = false;
    } 
    b0 b01 = b2.b;
    b0 b03 = ((a.b)com.google.android.exoplayer2.util.a.e(parama.g(1937011555))).b;
    b0 b04 = ((a.b)com.google.android.exoplayer2.util.a.e(parama.g(1937011827))).b;
    b2 = parama.g(1937011571);
    if (b2 != null) {
      b0 b0 = b2.b;
    } else {
      b2 = null;
    } 
    a.b b1 = parama.g(1668576371);
    if (b1 != null) {
      b02 = b1.b;
    } else {
      b02 = null;
    } 
    a a1 = new a(b03, b01, bool);
    b04.P(12);
    int i1 = b04.H() - 1;
    int n = b04.H();
    int i4 = b04.H();
    if (b02 != null) {
      b02.P(12);
      i = b02.H();
    } else {
      i = 0;
    } 
    if (b2 != null) {
      b2.P(12);
      j = b2.H();
      if (j > 0) {
        k = b2.H() - 1;
      } else {
        b2 = null;
        k = -1;
      } 
    } else {
      j = 0;
      k = -1;
    } 
    int i3 = e.b();
    String str = paramo.f.z;
    if (i3 != -1 && ("audio/raw".equals(str) || "audio/g711-mlaw".equals(str) || "audio/g711-alaw".equals(str)) && i1 == 0 && !i && !j) {
      m = 1;
    } else {
      m = 0;
    } 
    if (m) {
      i = a1.a;
      arrayOfLong1 = new long[i];
      int[] arrayOfInt = new int[i];
      while (a1.a()) {
        i = a1.b;
        arrayOfLong1[i] = a1.d;
        arrayOfInt[i] = a1.c;
      } 
      b3 = d.a(i3, arrayOfLong1, arrayOfInt, i4);
      arrayOfLong1 = b3.a;
      arrayOfInt2 = b3.b;
      i = b3.c;
      arrayOfLong2 = b3.d;
      arrayOfInt3 = b3.e;
      l1 = b3.f;
      k = i2;
    } else {
      int i10;
      int[] arrayOfInt6;
      long[] arrayOfLong5 = new long[i2];
      int[] arrayOfInt7 = new int[i2];
      arrayOfLong1 = new long[i2];
      int[] arrayOfInt8 = new int[i2];
      int i6 = k;
      int i8 = 0;
      i3 = 0;
      k = 0;
      int i9 = 0;
      int i5 = 0;
      long l = 0L;
      l1 = 0L;
      m = n;
      int i7 = j;
      n = i9;
      j = k;
      k = i2;
      i2 = i8;
      while (true) {
        if (i2 < k) {
          boolean bool1;
          int[] arrayOfInt9;
          int[] arrayOfInt10;
          bool = true;
          while (true) {
            bool1 = bool;
            if (n == 0) {
              bool = a1.a();
              bool1 = bool;
              if (bool) {
                l1 = a1.d;
                n = a1.c;
                continue;
              } 
            } 
            break;
          } 
          int i11 = m;
          if (!bool1) {
            r.h("AtomParsers", "Unexpected end of chunk data");
            arrayOfLong5 = Arrays.copyOf(arrayOfLong5, i2);
            arrayOfInt10 = Arrays.copyOf(arrayOfInt7, i2);
            arrayOfLong1 = Arrays.copyOf(arrayOfLong1, i2);
            arrayOfInt9 = Arrays.copyOf(arrayOfInt8, i2);
            k = i2;
            m = n;
            break;
          } 
          i9 = i;
          m = j;
          i8 = i5;
          if (b3 != null) {
            while (!i5 && i > 0) {
              i5 = b3.H();
              j = b3.n();
              i--;
            } 
            i8 = i5 - 1;
            m = j;
            i9 = i;
          } 
          arrayOfLong5[i2] = l1;
          arrayOfInt7[i2] = arrayOfInt10.a();
          i5 = i3;
          if (arrayOfInt7[i2] > i3)
            i5 = arrayOfInt7[i2]; 
          arrayOfLong1[i2] = l + m;
          if (arrayOfInt9 == null) {
            i = 1;
          } else {
            i = 0;
          } 
          arrayOfInt8[i2] = i;
          i = i6;
          int i12 = i7;
          if (i2 == i6) {
            arrayOfInt8[i2] = 1;
            j = i7 - 1;
            i = i6;
            i12 = j;
            if (j > 0) {
              i = ((b0)com.google.android.exoplayer2.util.a.e(arrayOfInt9)).H() - 1;
              i12 = j;
            } 
          } 
          l += i4;
          j = i11 - 1;
          if (j == 0 && i1 > 0) {
            j = b04.H();
            i3 = b04.n();
            i1--;
          } else {
            i3 = i4;
          } 
          long l3 = arrayOfInt7[i2];
          i11 = n - 1;
          i2++;
          l1 += l3;
          i4 = i3;
          n = m;
          i6 = i;
          i7 = i12;
          i3 = i5;
          m = j;
          i = i9;
          j = n;
          n = i11;
          i5 = i8;
          continue;
        } 
        i10 = m;
        m = n;
        arrayOfInt6 = arrayOfInt8;
        arrayOfInt2 = arrayOfInt7;
        break;
      } 
      l1 = j;
      if (b3 != null)
        while (i > 0) {
          if (b3.H() != 0) {
            i = 0;
            // Byte code: goto -> 1078
          } 
          b3.n();
          i--;
        }  
      i = 1;
      if (i7 != 0 || i10 != 0 || m != 0 || i1 != 0 || i5 != 0 || i == 0) {
        String str1;
        j = paramo.a;
        if (i == 0) {
          str1 = ", ctts invalid";
        } else {
          str1 = "";
        } 
        StringBuilder stringBuilder = new StringBuilder(str1.length() + 262);
        stringBuilder.append("Inconsistent stbl box for track ");
        stringBuilder.append(j);
        stringBuilder.append(": remainingSynchronizationSamples ");
        stringBuilder.append(i7);
        stringBuilder.append(", remainingSamplesAtTimestampDelta ");
        stringBuilder.append(i10);
        stringBuilder.append(", remainingSamplesInChunk ");
        stringBuilder.append(m);
        stringBuilder.append(", remainingTimestampDeltaChanges ");
        stringBuilder.append(i1);
        stringBuilder.append(", remainingSamplesAtTimestampOffset ");
        stringBuilder.append(i5);
        stringBuilder.append(str1);
        r.h("AtomParsers", stringBuilder.toString());
      } 
      long[] arrayOfLong6 = arrayOfLong5;
      i = i3;
      l1 = l + l1;
      arrayOfInt3 = arrayOfInt6;
      arrayOfLong2 = arrayOfLong1;
      arrayOfLong1 = arrayOfLong6;
    } 
    o o1 = paramo;
    long l2 = r0.G0(l1, 1000000L, o1.c);
    long[] arrayOfLong4 = o1.h;
    if (arrayOfLong4 == null) {
      r0.H0(arrayOfLong2, 1000000L, o1.c);
      return new r(paramo, arrayOfLong1, arrayOfInt2, i, arrayOfLong2, arrayOfInt3, l2);
    } 
    if (arrayOfLong4.length == 1 && o1.b == 1 && arrayOfLong2.length >= 2) {
      long l = ((long[])com.google.android.exoplayer2.util.a.e(o1.i))[0];
      l2 = l + r0.G0(o1.h[0], o1.c, o1.d);
      if (a(arrayOfLong2, l1, l, l2)) {
        l = r0.G0(l - arrayOfLong2[0], o1.f.N, o1.c);
        l2 = r0.G0(l1 - l2, o1.f.N, o1.c);
        if ((l != 0L || l2 != 0L) && l <= 2147483647L && l2 <= 2147483647L) {
          paramu.a = (int)l;
          paramu.b = (int)l2;
          r0.H0(arrayOfLong2, 1000000L, o1.c);
          return new r(paramo, arrayOfLong1, arrayOfInt2, i, arrayOfLong2, arrayOfInt3, r0.G0(o1.h[0], 1000000L, o1.d));
        } 
      } 
    } 
    int[] arrayOfInt1 = arrayOfInt3;
    long[] arrayOfLong3 = o1.h;
    if (arrayOfLong3.length == 1 && arrayOfLong3[0] == 0L) {
      l2 = ((long[])com.google.android.exoplayer2.util.a.e(o1.i))[0];
      for (j = 0; j < arrayOfLong2.length; j++)
        arrayOfLong2[j] = r0.G0(arrayOfLong2[j] - l2, 1000000L, o1.c); 
      return new r(paramo, arrayOfLong1, arrayOfInt2, i, arrayOfLong2, arrayOfInt1, r0.G0(l1 - l2, 1000000L, o1.c));
    } 
    if (o1.b == 1) {
      bool = true;
    } else {
      bool = false;
    } 
    int[] arrayOfInt4 = new int[arrayOfLong3.length];
    int[] arrayOfInt5 = new int[arrayOfLong3.length];
    arrayOfLong3 = (long[])com.google.android.exoplayer2.util.a.e(o1.i);
    i1 = 0;
    int m = 0;
    n = 0;
    int j = 0;
    while (true) {
      int[] arrayOfInt6;
      int[] arrayOfInt7;
      arrayOfLong4 = o1.h;
      if (i1 < arrayOfLong4.length) {
        l1 = arrayOfLong3[i1];
        if (l1 != -1L) {
          l2 = r0.G0(arrayOfLong4[i1], o1.c, o1.d);
          arrayOfInt4[i1] = r0.i(arrayOfLong2, l1, true, true);
          arrayOfInt5[i1] = r0.e(arrayOfLong2, l1 + l2, bool, false);
          while (arrayOfInt4[i1] < arrayOfInt5[i1] && (arrayOfInt1[arrayOfInt4[i1]] & 0x1) == 0)
            arrayOfInt4[i1] = arrayOfInt4[i1] + 1; 
          n += arrayOfInt5[i1] - arrayOfInt4[i1];
          if (j != arrayOfInt4[i1]) {
            j = 1;
          } else {
            j = 0;
          } 
          i2 = arrayOfInt5[i1];
          m = j | m;
          j = i2;
        } 
        i1++;
        continue;
      } 
      i1 = 0;
      j = 1;
      if (n == k)
        j = 0; 
      i2 = m | j;
      if (i2 != 0) {
        arrayOfLong3 = new long[n];
      } else {
        arrayOfLong3 = arrayOfLong1;
      } 
      if (i2 != 0) {
        arrayOfInt6 = new int[n];
      } else {
        arrayOfInt6 = arrayOfInt2;
      } 
      j = i;
      if (i2 != 0)
        j = 0; 
      if (i2 != 0) {
        arrayOfInt7 = new int[n];
      } else {
        arrayOfInt7 = arrayOfInt1;
      } 
      long[] arrayOfLong6 = new long[n];
      l1 = 0L;
      m = 0;
      i = i1;
      long[] arrayOfLong5 = arrayOfLong1;
      while (i < o1.h.length) {
        l2 = o1.i[i];
        k = arrayOfInt4[i];
        i1 = arrayOfInt5[i];
        if (i2 != 0) {
          n = i1 - k;
          System.arraycopy(arrayOfLong5, k, arrayOfLong3, m, n);
          System.arraycopy(arrayOfInt2, k, arrayOfInt6, m, n);
          System.arraycopy(arrayOfInt1, k, arrayOfInt7, m, n);
        } 
        int[] arrayOfInt = arrayOfInt1;
        n = j;
        j = m;
        m = i;
        for (i = n; k < i1; i = n) {
          arrayOfLong6[j] = r0.G0(l1, 1000000L, o1.d) + r0.G0(Math.max(0L, arrayOfLong2[k] - l2), 1000000L, o1.c);
          n = i;
          if (i2 != 0) {
            n = i;
            if (arrayOfInt6[j] > i)
              n = arrayOfInt2[k]; 
          } 
          j++;
          k++;
        } 
        l1 += o1.h[m];
        m++;
        k = i;
        i = m;
        m = j;
        j = k;
        arrayOfInt1 = arrayOfInt;
      } 
      return new r(paramo, arrayOfLong3, arrayOfInt6, j, arrayOfLong6, arrayOfInt7, r0.G0(l1, 1000000L, o1.d));
    } 
  }
  
  private static c v(b0 paramb0, int paramInt1, int paramInt2, String paramString, @Nullable DrmInitData paramDrmInitData, boolean paramBoolean) throws k1 {
    paramb0.P(12);
    int j = paramb0.n();
    c c = new c(j);
    int i;
    for (i = 0; i < j; i++) {
      boolean bool;
      int k = paramb0.e();
      int m = paramb0.n();
      if (m > 0) {
        bool = true;
      } else {
        bool = false;
      } 
      l.a(bool, "childAtomSize must be positive");
      int n = paramb0.n();
      if (n == 1635148593 || n == 1635148595 || n == 1701733238 || n == 1831958048 || n == 1836070006 || n == 1752589105 || n == 1751479857 || n == 1932670515 || n == 1211250227 || n == 1987063864 || n == 1987063865 || n == 1635135537 || n == 1685479798 || n == 1685479729 || n == 1685481573 || n == 1685481521) {
        C(paramb0, n, k, m, paramInt1, paramInt2, paramDrmInitData, c, i);
      } else if (n == 1836069985 || n == 1701733217 || n == 1633889587 || n == 1700998451 || n == 1633889588 || n == 1685353315 || n == 1685353317 || n == 1685353320 || n == 1685353324 || n == 1685353336 || n == 1935764850 || n == 1935767394 || n == 1819304813 || n == 1936684916 || n == 1953984371 || n == 778924082 || n == 778924083 || n == 1835557169 || n == 1835560241 || n == 1634492771 || n == 1634492791 || n == 1970037111 || n == 1332770163 || n == 1716281667) {
        e(paramb0, n, k, m, paramInt1, paramString, paramBoolean, paramDrmInitData, c, i);
      } else if (n == 1414810956 || n == 1954034535 || n == 2004251764 || n == 1937010800 || n == 1664495672) {
        w(paramb0, n, k, m, paramInt1, paramString, c);
      } else if (n == 1835365492) {
        n(paramb0, n, k, paramInt1, c);
      } else if (n == 1667329389) {
        c.b = (new Format.b()).R(paramInt1).e0("application/x-camera-motion").E();
      } 
      paramb0.P(k + m);
    } 
    return c;
  }
  
  private static void w(b0 paramb0, int paramInt1, int paramInt2, int paramInt3, int paramInt4, String paramString, c paramc) {
    String str1;
    b0 b01;
    paramb0.P(paramInt2 + 8 + 8);
    String str2 = "application/ttml+xml";
    byte[] arrayOfByte = null;
    long l = Long.MAX_VALUE;
    if (paramInt1 == 1414810956) {
      str1 = str2;
    } else if (paramInt1 == 1954034535) {
      paramInt1 = paramInt3 - 8 - 8;
      arrayOfByte = new byte[paramInt1];
      str1.j(arrayOfByte, 0, paramInt1);
      b01 = b0.of(arrayOfByte);
      str1 = "application/x-quicktime-tx3g";
    } else if (paramInt1 == 2004251764) {
      str1 = "application/x-mp4-vtt";
    } else if (paramInt1 == 1937010800) {
      l = 0L;
      str1 = str2;
    } else if (paramInt1 == 1664495672) {
      paramc.d = 1;
      str1 = "application/x-mp4-cea-608";
    } else {
      throw new IllegalStateException();
    } 
    paramc.b = (new Format.b()).R(paramInt4).e0(str1).V(paramString).i0(l).T((List)b01).E();
  }
  
  private static f x(b0 paramb0) {
    long l1;
    int j = 8;
    paramb0.P(8);
    int m = a.c(paramb0.n());
    if (m == 0) {
      i = 8;
    } else {
      i = 16;
    } 
    paramb0.Q(i);
    int k = paramb0.n();
    paramb0.Q(4);
    int n = paramb0.e();
    int i = j;
    if (m == 0)
      i = 4; 
    boolean bool = false;
    j = 0;
    while (true) {
      if (j < i) {
        if (paramb0.d()[n + j] != -1) {
          j = 0;
          break;
        } 
        j++;
        continue;
      } 
      j = 1;
      break;
    } 
    long l2 = -9223372036854775807L;
    if (j != 0) {
      paramb0.Q(i);
      l1 = l2;
    } else {
      if (m == 0) {
        l1 = paramb0.F();
      } else {
        l1 = paramb0.I();
      } 
      if (l1 == 0L)
        l1 = l2; 
    } 
    paramb0.Q(16);
    j = paramb0.n();
    m = paramb0.n();
    paramb0.Q(4);
    n = paramb0.n();
    int i1 = paramb0.n();
    if (j == 0 && m == 65536 && n == -65536 && i1 == 0) {
      i = 90;
    } else if (j == 0 && m == -65536 && n == 65536 && i1 == 0) {
      i = 270;
    } else {
      i = bool;
      if (j == -65536) {
        i = bool;
        if (m == 0) {
          i = bool;
          if (n == 0) {
            i = bool;
            if (i1 == -65536)
              i = 180; 
          } 
        } 
      } 
    } 
    return new f(k, l1, i);
  }
  
  @Nullable
  private static o y(a.a parama, a.b paramb, long paramLong, @Nullable DrmInitData paramDrmInitData, boolean paramBoolean1, boolean paramBoolean2) throws k1 {
    // Byte code:
    //   0: aload_0
    //   1: ldc_w 1835297121
    //   4: invokevirtual f : (I)La3/a$a;
    //   7: invokestatic e : (Ljava/lang/Object;)Ljava/lang/Object;
    //   10: checkcast a3/a$a
    //   13: astore #13
    //   15: aload #13
    //   17: ldc_w 1751411826
    //   20: invokevirtual g : (I)La3/a$b;
    //   23: invokestatic e : (Ljava/lang/Object;)Ljava/lang/Object;
    //   26: checkcast a3/a$b
    //   29: getfield b : Lcom/google/android/exoplayer2/util/b0;
    //   32: invokestatic j : (Lcom/google/android/exoplayer2/util/b0;)I
    //   35: invokestatic c : (I)I
    //   38: istore #7
    //   40: iload #7
    //   42: iconst_m1
    //   43: if_icmpne -> 48
    //   46: aconst_null
    //   47: areturn
    //   48: aload_0
    //   49: ldc_w 1953196132
    //   52: invokevirtual g : (I)La3/a$b;
    //   55: invokestatic e : (Ljava/lang/Object;)Ljava/lang/Object;
    //   58: checkcast a3/a$b
    //   61: getfield b : Lcom/google/android/exoplayer2/util/b0;
    //   64: invokestatic x : (Lcom/google/android/exoplayer2/util/b0;)La3/b$f;
    //   67: astore #12
    //   69: ldc2_w -9223372036854775807
    //   72: lstore #8
    //   74: lload_2
    //   75: ldc2_w -9223372036854775807
    //   78: lcmp
    //   79: ifne -> 91
    //   82: aload #12
    //   84: invokestatic a : (La3/b$f;)J
    //   87: lstore_2
    //   88: goto -> 91
    //   91: aload_1
    //   92: getfield b : Lcom/google/android/exoplayer2/util/b0;
    //   95: invokestatic o : (Lcom/google/android/exoplayer2/util/b0;)J
    //   98: lstore #10
    //   100: lload_2
    //   101: ldc2_w -9223372036854775807
    //   104: lcmp
    //   105: ifne -> 114
    //   108: lload #8
    //   110: lstore_2
    //   111: goto -> 124
    //   114: lload_2
    //   115: ldc2_w 1000000
    //   118: lload #10
    //   120: invokestatic G0 : (JJJ)J
    //   123: lstore_2
    //   124: aload #13
    //   126: ldc_w 1835626086
    //   129: invokevirtual f : (I)La3/a$a;
    //   132: invokestatic e : (Ljava/lang/Object;)Ljava/lang/Object;
    //   135: checkcast a3/a$a
    //   138: ldc_w 1937007212
    //   141: invokevirtual f : (I)La3/a$a;
    //   144: invokestatic e : (Ljava/lang/Object;)Ljava/lang/Object;
    //   147: checkcast a3/a$a
    //   150: astore_1
    //   151: aload #13
    //   153: ldc_w 1835296868
    //   156: invokevirtual g : (I)La3/a$b;
    //   159: invokestatic e : (Ljava/lang/Object;)Ljava/lang/Object;
    //   162: checkcast a3/a$b
    //   165: getfield b : Lcom/google/android/exoplayer2/util/b0;
    //   168: invokestatic l : (Lcom/google/android/exoplayer2/util/b0;)Landroid/util/Pair;
    //   171: astore #13
    //   173: aload_1
    //   174: ldc_w 1937011556
    //   177: invokevirtual g : (I)La3/a$b;
    //   180: invokestatic e : (Ljava/lang/Object;)Ljava/lang/Object;
    //   183: checkcast a3/a$b
    //   186: getfield b : Lcom/google/android/exoplayer2/util/b0;
    //   189: aload #12
    //   191: invokestatic b : (La3/b$f;)I
    //   194: aload #12
    //   196: invokestatic c : (La3/b$f;)I
    //   199: aload #13
    //   201: getfield second : Ljava/lang/Object;
    //   204: checkcast java/lang/String
    //   207: aload #4
    //   209: iload #6
    //   211: invokestatic v : (Lcom/google/android/exoplayer2/util/b0;IILjava/lang/String;Lcom/google/android/exoplayer2/drm/DrmInitData;Z)La3/b$c;
    //   214: astore #4
    //   216: iload #5
    //   218: ifne -> 261
    //   221: aload_0
    //   222: ldc_w 1701082227
    //   225: invokevirtual f : (I)La3/a$a;
    //   228: astore_0
    //   229: aload_0
    //   230: ifnull -> 261
    //   233: aload_0
    //   234: invokestatic g : (La3/a$a;)Landroid/util/Pair;
    //   237: astore_1
    //   238: aload_1
    //   239: ifnull -> 261
    //   242: aload_1
    //   243: getfield first : Ljava/lang/Object;
    //   246: checkcast [J
    //   249: astore_0
    //   250: aload_1
    //   251: getfield second : Ljava/lang/Object;
    //   254: checkcast [J
    //   257: astore_1
    //   258: goto -> 265
    //   261: aconst_null
    //   262: astore_0
    //   263: aload_0
    //   264: astore_1
    //   265: aload #4
    //   267: getfield b : Lcom/google/android/exoplayer2/Format;
    //   270: ifnonnull -> 275
    //   273: aconst_null
    //   274: areturn
    //   275: new a3/o
    //   278: dup
    //   279: aload #12
    //   281: invokestatic b : (La3/b$f;)I
    //   284: iload #7
    //   286: aload #13
    //   288: getfield first : Ljava/lang/Object;
    //   291: checkcast java/lang/Long
    //   294: invokevirtual longValue : ()J
    //   297: lload #10
    //   299: lload_2
    //   300: aload #4
    //   302: getfield b : Lcom/google/android/exoplayer2/Format;
    //   305: aload #4
    //   307: getfield d : I
    //   310: aload #4
    //   312: getfield a : [La3/p;
    //   315: aload #4
    //   317: getfield c : I
    //   320: aload_0
    //   321: aload_1
    //   322: invokespecial <init> : (IIJJJLcom/google/android/exoplayer2/Format;I[La3/p;I[J[J)V
    //   325: areturn
  }
  
  public static List<r> z(a.a parama, u paramu, long paramLong, @Nullable DrmInitData paramDrmInitData, boolean paramBoolean1, boolean paramBoolean2, g<o, o> paramg) throws k1 {
    ArrayList<r> arrayList = new ArrayList();
    int i;
    for (i = 0; i < parama.d.size(); i++) {
      a.a a1 = parama.d.get(i);
      if (a1.a == 1953653099) {
        o o = (o)paramg.apply(y(a1, (a.b)com.google.android.exoplayer2.util.a.e(parama.g(1836476516)), paramLong, paramDrmInitData, paramBoolean1, paramBoolean2));
        if (o != null)
          arrayList.add(u(o, (a.a)com.google.android.exoplayer2.util.a.e(((a.a)com.google.android.exoplayer2.util.a.e(((a.a)com.google.android.exoplayer2.util.a.e(a1.f(1835297121))).f(1835626086))).f(1937007212)), paramu)); 
      } 
    } 
    return arrayList;
  }
  
  private static final class a {
    public final int a;
    
    public int b;
    
    public int c;
    
    public long d;
    
    private final boolean e;
    
    private final b0 f;
    
    private final b0 g;
    
    private int h;
    
    private int i;
    
    public a(b0 param1b01, b0 param1b02, boolean param1Boolean) throws k1 {
      this.g = param1b01;
      this.f = param1b02;
      this.e = param1Boolean;
      param1b02.P(12);
      this.a = param1b02.H();
      param1b01.P(12);
      this.i = param1b01.H();
      int i = param1b01.n();
      param1Boolean = true;
      if (i != 1)
        param1Boolean = false; 
      l.a(param1Boolean, "first_chunk must be 1");
      this.b = -1;
    }
    
    public boolean a() {
      long l;
      int i = this.b + 1;
      this.b = i;
      if (i == this.a)
        return false; 
      if (this.e) {
        l = this.f.I();
      } else {
        l = this.f.F();
      } 
      this.d = l;
      if (this.b == this.h) {
        this.c = this.g.H();
        this.g.Q(4);
        i = this.i - 1;
        this.i = i;
        if (i > 0) {
          i = this.g.H() - 1;
        } else {
          i = -1;
        } 
        this.h = i;
      } 
      return true;
    }
  }
  
  private static interface b {
    int a();
    
    int b();
    
    int c();
  }
  
  private static final class c {
    public final p[] a;
    
    @Nullable
    public Format b;
    
    public int c;
    
    public int d;
    
    public c(int param1Int) {
      this.a = new p[param1Int];
      this.d = 0;
    }
  }
  
  static final class d implements b {
    private final int a;
    
    private final int b;
    
    private final b0 c;
    
    public d(a.b param1b, Format param1Format) {
      // Byte code:
      //   0: aload_0
      //   1: invokespecial <init> : ()V
      //   4: aload_1
      //   5: getfield b : Lcom/google/android/exoplayer2/util/b0;
      //   8: astore_1
      //   9: aload_0
      //   10: aload_1
      //   11: putfield c : Lcom/google/android/exoplayer2/util/b0;
      //   14: aload_1
      //   15: bipush #12
      //   17: invokevirtual P : (I)V
      //   20: aload_1
      //   21: invokevirtual H : ()I
      //   24: istore #4
      //   26: iload #4
      //   28: istore_3
      //   29: ldc 'audio/raw'
      //   31: aload_2
      //   32: getfield z : Ljava/lang/String;
      //   35: invokevirtual equals : (Ljava/lang/Object;)Z
      //   38: ifeq -> 120
      //   41: aload_2
      //   42: getfield O : I
      //   45: aload_2
      //   46: getfield M : I
      //   49: invokestatic Y : (II)I
      //   52: istore #5
      //   54: iload #4
      //   56: ifeq -> 70
      //   59: iload #4
      //   61: istore_3
      //   62: iload #4
      //   64: iload #5
      //   66: irem
      //   67: ifeq -> 120
      //   70: new java/lang/StringBuilder
      //   73: dup
      //   74: bipush #88
      //   76: invokespecial <init> : (I)V
      //   79: astore_2
      //   80: aload_2
      //   81: ldc 'Audio sample size mismatch. stsd sample size: '
      //   83: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
      //   86: pop
      //   87: aload_2
      //   88: iload #5
      //   90: invokevirtual append : (I)Ljava/lang/StringBuilder;
      //   93: pop
      //   94: aload_2
      //   95: ldc ', stsz sample size: '
      //   97: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
      //   100: pop
      //   101: aload_2
      //   102: iload #4
      //   104: invokevirtual append : (I)Ljava/lang/StringBuilder;
      //   107: pop
      //   108: ldc 'AtomParsers'
      //   110: aload_2
      //   111: invokevirtual toString : ()Ljava/lang/String;
      //   114: invokestatic h : (Ljava/lang/String;Ljava/lang/String;)V
      //   117: iload #5
      //   119: istore_3
      //   120: iload_3
      //   121: istore #4
      //   123: iload_3
      //   124: ifne -> 130
      //   127: iconst_m1
      //   128: istore #4
      //   130: aload_0
      //   131: iload #4
      //   133: putfield a : I
      //   136: aload_0
      //   137: aload_1
      //   138: invokevirtual H : ()I
      //   141: putfield b : I
      //   144: return
    }
    
    public int a() {
      int j = this.a;
      int i = j;
      if (j == -1)
        i = this.c.H(); 
      return i;
    }
    
    public int b() {
      return this.a;
    }
    
    public int c() {
      return this.b;
    }
  }
  
  static final class e implements b {
    private final b0 a;
    
    private final int b;
    
    private final int c;
    
    private int d;
    
    private int e;
    
    public e(a.b param1b) {
      b0 b01 = param1b.b;
      this.a = b01;
      b01.P(12);
      this.c = b01.H() & 0xFF;
      this.b = b01.H();
    }
    
    public int a() {
      int i = this.c;
      if (i == 8)
        return this.a.D(); 
      if (i == 16)
        return this.a.J(); 
      i = this.d;
      this.d = i + 1;
      if (i % 2 == 0) {
        i = this.a.D();
        this.e = i;
        return (i & 0xF0) >> 4;
      } 
      return this.e & 0xF;
    }
    
    public int b() {
      return -1;
    }
    
    public int c() {
      return this.b;
    }
  }
  
  private static final class f {
    private final int a;
    
    private final long b;
    
    private final int c;
    
    public f(int param1Int1, long param1Long, int param1Int2) {
      this.a = param1Int1;
      this.b = param1Long;
      this.c = param1Int2;
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\BabyBus TV_Kids Videos & Games-dex2jar.jar!\a3\b.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */