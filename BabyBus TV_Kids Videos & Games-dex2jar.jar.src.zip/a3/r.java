package a3;

import com.google.android.exoplayer2.util.a;
import com.google.android.exoplayer2.util.r0;

final class r {
  public final o a;
  
  public final int b;
  
  public final long[] c;
  
  public final int[] d;
  
  public final int e;
  
  public final long[] f;
  
  public final int[] g;
  
  public final long h;
  
  public r(o paramo, long[] paramArrayOflong1, int[] paramArrayOfint1, int paramInt, long[] paramArrayOflong2, int[] paramArrayOfint2, long paramLong) {
    int i = paramArrayOfint1.length;
    int j = paramArrayOflong2.length;
    boolean bool2 = false;
    if (i == j) {
      bool1 = true;
    } else {
      bool1 = false;
    } 
    a.a(bool1);
    if (paramArrayOflong1.length == paramArrayOflong2.length) {
      bool1 = true;
    } else {
      bool1 = false;
    } 
    a.a(bool1);
    boolean bool1 = bool2;
    if (paramArrayOfint2.length == paramArrayOflong2.length)
      bool1 = true; 
    a.a(bool1);
    this.a = paramo;
    this.c = paramArrayOflong1;
    this.d = paramArrayOfint1;
    this.e = paramInt;
    this.f = paramArrayOflong2;
    this.g = paramArrayOfint2;
    this.h = paramLong;
    this.b = paramArrayOflong1.length;
    if (paramArrayOfint2.length > 0) {
      paramInt = paramArrayOfint2.length - 1;
      paramArrayOfint2[paramInt] = paramArrayOfint2[paramInt] | 0x20000000;
    } 
  }
  
  public int a(long paramLong) {
    for (int i = r0.i(this.f, paramLong, true, false); i >= 0; i--) {
      if ((this.g[i] & 0x1) != 0)
        return i; 
    } 
    return -1;
  }
  
  public int b(long paramLong) {
    for (int i = r0.e(this.f, paramLong, true, false); i < this.f.length; i++) {
      if ((this.g[i] & 0x1) != 0)
        return i; 
    } 
    return -1;
  }
}


/* Location:              C:\soft\dex2jar-2.0\BabyBus TV_Kids Videos & Games-dex2jar.jar!\a3\r.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */