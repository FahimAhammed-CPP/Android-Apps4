package a9;

import com.sinyee.android.analysis.sharjah.network.head.SharjahAESHeader;
import java.util.Map;
import org.aspectj.lang.JoinPoint;
import org.aspectj.lang.NoAspectBoundException;
import org.aspectj.lang.annotation.After;
import org.aspectj.lang.annotation.Aspect;

@Aspect
public class a {
  static {
    try {
      return;
    } finally {
      Exception exception = null;
      a = exception;
    } 
  }
  
  public static a c() {
    a a1 = b;
    if (a1 != null)
      return a1; 
    throw new NoAspectBoundException("com.sinyee.android.analysis.sharjah.network.head.SharjahAESHeaderAspect", a);
  }
  
  @After("callMethod()")
  public void a(JoinPoint paramJoinPoint) {
    Object[] arrayOfObject = paramJoinPoint.getArgs();
    if (arrayOfObject[0] != null)
      try {
        (new SharjahAESHeader()).headerInject((Map)arrayOfObject[0]);
        return;
      } catch (Exception exception) {
        exception.printStackTrace();
      }  
  }
}


/* Location:              C:\soft\dex2jar-2.0\BabyBus TV_Kids Videos & Games-dex2jar.jar!\a9\a.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */