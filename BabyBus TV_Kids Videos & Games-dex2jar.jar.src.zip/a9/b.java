package a9;

import com.sinyee.android.analysis.sharjah.network.head.SharjahHeader;
import java.util.Map;
import org.aspectj.lang.JoinPoint;
import org.aspectj.lang.NoAspectBoundException;
import org.aspectj.lang.annotation.After;
import org.aspectj.lang.annotation.Aspect;

@Aspect
public class b {
  static {
    try {
      return;
    } finally {
      Exception exception = null;
      a = exception;
    } 
  }
  
  public static b c() {
    b b1 = b;
    if (b1 != null)
      return b1; 
    throw new NoAspectBoundException("com.sinyee.android.analysis.sharjah.network.head.SharjahHeaderAspect", a);
  }
  
  @After("callMethod()")
  public void a(JoinPoint paramJoinPoint) {
    Object[] arrayOfObject = paramJoinPoint.getArgs();
    if (arrayOfObject[0] != null)
      try {
        (new SharjahHeader()).headerInject((Map)arrayOfObject[0]);
        return;
      } catch (Exception exception) {
        exception.printStackTrace();
      }  
  }
}


/* Location:              C:\soft\dex2jar-2.0\BabyBus TV_Kids Videos & Games-dex2jar.jar!\a9\b.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */