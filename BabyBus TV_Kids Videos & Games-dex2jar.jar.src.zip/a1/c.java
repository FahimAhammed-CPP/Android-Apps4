package a1;

import android.net.Uri;
import javax.annotation.Nullable;

public interface c {
  c a(Uri paramUri);
  
  c b(@Nullable a parama);
  
  a build();
}


/* Location:              C:\soft\dex2jar-2.0\BabyBus TV_Kids Videos & Games-dex2jar.jar!\a1\c.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */