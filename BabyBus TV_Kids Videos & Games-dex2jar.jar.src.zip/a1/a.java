package a1;

import android.view.MotionEvent;
import javax.annotation.Nullable;
import javax.annotation.concurrent.ThreadSafe;

@ThreadSafe
public interface a {
  void a(@Nullable b paramb);
  
  void b();
  
  void c();
  
  @Nullable
  b d();
  
  boolean onTouchEvent(MotionEvent paramMotionEvent);
}


/* Location:              C:\soft\dex2jar-2.0\BabyBus TV_Kids Videos & Games-dex2jar.jar!\a1\a.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */