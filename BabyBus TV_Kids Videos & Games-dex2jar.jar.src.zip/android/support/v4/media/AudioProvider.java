package android.support.v4.media;

import com.alibaba.android.arouter.facade.annotation.Autowired;
import com.sinyee.android.util.GsonUtils;
import com.sinyee.babybus.core.service.a;
import com.sinyee.babybus.core.service.audio.bean.AudioBelongPlayQueueBean;
import com.sinyee.babybus.core.service.audio.provider.AudioProviderBean;
import com.sinyee.babybus.core.service.audio.provider.IAudioProvider;
import f9.a;
import io.reactivex.disposables.b;
import java.util.Iterator;
import java.util.List;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.ConcurrentMap;
import java.util.concurrent.CopyOnWriteArrayList;

public class AudioProvider {
  public static final String BUNDLE_KEY_AUDIO_DETAIL = "bundle_key_audio_detail";
  
  public static final String BUNDLE_KEY_DOWNLOAD_CACHE_ALBUM_TYPE = "bundle_key_download_cache_album_type";
  
  public static final String BUNDLE_KEY_IS_REENTER_PLAY_LAST_RECORD = "bundle_key_is_reenter_play_last_record";
  
  public static final String BUNDLE_KEY_IS_RETAKE_QUEUE = "bundle_key_is_retake_queue";
  
  public static final String BUNDLE_KEY_QUEUE_TYPE = "bundle_key_queue_type";
  
  public static final String BUNDLE_KEY_RECOMMEND_ALBUM_IMAGE = "bundle_key_recommend_album_image";
  
  public static final String MEDIA_ID_EMPTY_ROOT = "__EMPTY_ROOT__";
  
  public static final String MEDIA_ID_ROOT = "__ROOT__";
  
  public static final String PAGE_CACHE = "page_cache";
  
  public static final int PAGE_CACHE_LIST = 2;
  
  public static final int PAGE_CODE_COLLECTION_SING_AUDIO = 257;
  
  public static final String PAGE_COLLECTION_SINGLE = "page_collection_single";
  
  public static final String PAGE_DOWNLOAD = "page_download";
  
  public static final int PAGE_DOWNLOAD_LIST = 1;
  
  public static final String PAGE_HEART = "page_heart";
  
  public static final String PAGE_HOME_COLUMN = "page_home_column";
  
  public static final String PAGE_MORNING = "page_morning";
  
  public static final String PAGE_NIGHT = "page_night";
  
  public static final int PAGE_OFFLINE_LIST = 0;
  
  public static final String PAGE_ONLY_MONITOR_PLAY = "page_only_monitor_play";
  
  public static final String PAGE_PLAY = "page_play";
  
  public static final String PAGE_RADIO = "page_radio";
  
  public static final String PAGE_RECENT = "page_recent";
  
  public static final String PAGE_RECORD = "page_record";
  
  public static final String PAGE_SEARCH = "page_search";
  
  private String TAG = AudioProvider.class.getSimpleName();
  
  @Autowired(name = "/audio/albumdetail/audioprovider")
  IAudioProvider albumDetailAudioProvider;
  
  @Autowired(name = "/mytab/cache/audioprovider")
  IAudioProvider cacheAudioProvider;
  
  private List<b> disposableList;
  
  @Autowired(name = "/mytab/download/audioprovider")
  IAudioProvider downloadAudioProvider;
  
  private ConcurrentMap<String, List<MediaMetadataCompat>> mMusicByQueueType;
  
  private ConcurrentMap<String, MediaMetadataCompat> mMusicListByAudioToken;
  
  @Autowired(name = "/audio/playpage/audioprovider")
  IAudioProvider playPageAudioProvider;
  
  @Autowired(name = "/audio/recent/audioprovider")
  IAudioProvider recentAudioProvider;
  
  @Autowired(name = "/mytab/videorecord/audioprovider")
  IAudioProvider recordAudioProvider;
  
  private AudioProvider() {
    a.b().d(this);
    this.mMusicListByAudioToken = new ConcurrentHashMap<String, MediaMetadataCompat>();
    this.mMusicByQueueType = new ConcurrentHashMap<String, List<MediaMetadataCompat>>();
    this.disposableList = new CopyOnWriteArrayList<b>();
  }
  
  public static AudioProvider getInstance() {
    return AudioProviderHolder.INSTANCE;
  }
  
  public MediaMetadataCompat getMediaMetadataCompatByAudioToken(String paramString) {
    return this.mMusicListByAudioToken.get(paramString);
  }
  
  public void getQueueList(final String queueType, boolean paramBoolean, int paramInt, AudioProviderBean paramAudioProviderBean, final Callback callback) {
    if (callback == null)
      return; 
    AudioBelongPlayQueueBean audioBelongPlayQueueBean = (AudioBelongPlayQueueBean)GsonUtils.fromJson(queueType, AudioBelongPlayQueueBean.class);
    if (paramBoolean || this.mMusicByQueueType.get(queueType) == null) {
      StringBuilder stringBuilder;
      if ("page_record".equals(audioBelongPlayQueueBean.getAudioBelongPage()) && "page_home_column".equals(audioBelongPlayQueueBean.getAudioSourceType())) {
        if (this.albumDetailAudioProvider == null) {
          a.f("AudioProvide", new Object[] { "arouter 初始化失败，重新赋值" });
          this.albumDetailAudioProvider = (IAudioProvider)a.b().a("/audio/albumdetail/audioprovider").navigation();
        } 
        this.albumDetailAudioProvider.q0(queueType, new IAudioProvider.a() {
              public void ready() {
                callback.onMusicCatalogReady((List<MediaMetadataCompat>)AudioProvider.this.mMusicByQueueType.get(queueType));
              }
            },  paramAudioProviderBean);
        return;
      } 
      if ("page_morning".equals(audioBelongPlayQueueBean.getAudioBelongPage()) || "page_heart".equals(audioBelongPlayQueueBean.getAudioBelongPage()) || "page_night".equals(audioBelongPlayQueueBean.getAudioBelongPage())) {
        if (this.albumDetailAudioProvider == null) {
          a.f("AudioProvide", new Object[] { "arouter 初始化失败，重新赋值" });
          this.albumDetailAudioProvider = (IAudioProvider)a.b().a("/audio/albumdetail/audioprovider").navigation();
        } 
        this.albumDetailAudioProvider.q0(queueType, new IAudioProvider.a() {
              public void ready() {
                callback.onMusicCatalogReady((List<MediaMetadataCompat>)AudioProvider.this.mMusicByQueueType.get(queueType));
              }
            },  paramAudioProviderBean);
        return;
      } 
      if ("page_record".equals(audioBelongPlayQueueBean.getAudioBelongPage()) && "page_play".equals(audioBelongPlayQueueBean.getAudioSourceType())) {
        if (this.playPageAudioProvider == null) {
          a.f("AudioProvide", new Object[] { "arouter 初始化失败，重新赋值" });
          this.playPageAudioProvider = (IAudioProvider)a.b().a("/audio/playpage/audioprovider").navigation();
        } 
        this.playPageAudioProvider.q0(queueType, new IAudioProvider.a() {
              public void ready() {
                callback.onMusicCatalogReady((List<MediaMetadataCompat>)AudioProvider.this.mMusicByQueueType.get(queueType));
              }
            },  paramAudioProviderBean);
        return;
      } 
      if ("page_download".equals(audioBelongPlayQueueBean.getAudioBelongPage())) {
        if (this.downloadAudioProvider == null)
          this.downloadAudioProvider = (IAudioProvider)a.b().a("/mytab/download/audioprovider").navigation(); 
        if (paramInt == 1) {
          this.downloadAudioProvider.E(queueType, paramInt, new IAudioProvider.a() {
                public void ready() {
                  callback.onMusicCatalogReady((List<MediaMetadataCompat>)AudioProvider.this.mMusicByQueueType.get(queueType));
                }
              });
          return;
        } 
        this.downloadAudioProvider.I0(queueType, new IAudioProvider.a() {
              public void ready() {
                callback.onMusicCatalogReady((List<MediaMetadataCompat>)AudioProvider.this.mMusicByQueueType.get(queueType));
              }
            });
        return;
      } 
      if ("page_recent".equals(audioBelongPlayQueueBean.getAudioBelongPage())) {
        if (this.recentAudioProvider == null) {
          a.f("AudioProvide", new Object[] { "arouter 初始化失败，重新赋值" });
          this.recentAudioProvider = (IAudioProvider)a.b().a("/audio/recent/audioprovider").navigation();
        } 
        this.recentAudioProvider.I0(queueType, new IAudioProvider.a() {
              public void ready() {
                callback.onMusicCatalogReady((List<MediaMetadataCompat>)AudioProvider.this.mMusicByQueueType.get(queueType));
              }
            });
        return;
      } 
      if ("page_home_column".equals(audioBelongPlayQueueBean.getAudioBelongPage())) {
        if (this.albumDetailAudioProvider == null) {
          a.f("AudioProvide", new Object[] { "arouter 初始化失败，重新赋值" });
          this.albumDetailAudioProvider = (IAudioProvider)a.b().a("/audio/albumdetail/audioprovider").navigation();
        } 
        this.albumDetailAudioProvider.q0(queueType, new IAudioProvider.a() {
              public void ready() {
                callback.onMusicCatalogReady((List<MediaMetadataCompat>)AudioProvider.this.mMusicByQueueType.get(queueType));
              }
            },  paramAudioProviderBean);
        return;
      } 
      if ("page_record".equals(audioBelongPlayQueueBean.getAudioBelongPage())) {
        if (this.recordAudioProvider == null)
          this.recordAudioProvider = (IAudioProvider)a.b().a("/mytab/videorecord/audioprovider").navigation(); 
        this.recordAudioProvider.I0(queueType, new IAudioProvider.a() {
              public void ready() {
                callback.onMusicCatalogReady((List<MediaMetadataCompat>)AudioProvider.this.mMusicByQueueType.get(queueType));
              }
            });
        return;
      } 
      if ("page_cache".equals(audioBelongPlayQueueBean.getAudioBelongPage())) {
        if (this.cacheAudioProvider == null) {
          a.f("AudioProvide", new Object[] { "arouter 初始化失败，重新赋值" });
          this.cacheAudioProvider = (IAudioProvider)a.b().a("/mytab/cache/audioprovider").navigation();
        } 
        if (paramInt == 2) {
          this.cacheAudioProvider.E(queueType, paramInt, new IAudioProvider.a() {
                public void ready() {
                  callback.onMusicCatalogReady((List<MediaMetadataCompat>)AudioProvider.this.mMusicByQueueType.get(queueType));
                }
              });
          return;
        } 
        stringBuilder = new StringBuilder();
        stringBuilder.append(" cacheAudioProvider 222 ");
        stringBuilder.append(this.cacheAudioProvider);
        a.f("asd", new Object[] { stringBuilder.toString() });
        this.cacheAudioProvider.I0(queueType, new IAudioProvider.a() {
              public void ready() {
                callback.onMusicCatalogReady((List<MediaMetadataCompat>)AudioProvider.this.mMusicByQueueType.get(queueType));
              }
            });
        return;
      } 
      if ("page_play".equals(audioBelongPlayQueueBean.getAudioBelongPage())) {
        if (this.playPageAudioProvider == null) {
          a.f("AudioProvide", new Object[] { "arouter 初始化失败，重新赋值" });
          this.playPageAudioProvider = (IAudioProvider)a.b().a("/audio/playpage/audioprovider").navigation();
        } 
        this.playPageAudioProvider.q0(queueType, new IAudioProvider.a() {
              public void ready() {
                callback.onMusicCatalogReady((List<MediaMetadataCompat>)AudioProvider.this.mMusicByQueueType.get(queueType));
              }
            },  (AudioProviderBean)stringBuilder);
      } 
      return;
    } 
    callback.onMusicCatalogReady(this.mMusicByQueueType.get(queueType));
  }
  
  public void notify(IAudioProvider paramIAudioProvider) {
    if (paramIAudioProvider == null)
      return; 
    this.mMusicByQueueType.putAll(paramIAudioProvider.l());
    this.mMusicListByAudioToken.putAll(paramIAudioProvider.g());
  }
  
  public void release() {
    Iterator<b> iterator = this.disposableList.iterator();
    while (iterator.hasNext())
      ((b)iterator.next()).dispose(); 
  }
  
  private static class AudioProviderHolder {
    private static final AudioProvider INSTANCE = new AudioProvider();
  }
  
  public static interface Callback {
    void onMusicCatalogReady(List<MediaMetadataCompat> param1List);
  }
}


/* Location:              C:\soft\dex2jar-2.0\BabyBus TV_Kids Videos & Games-dex2jar.jar!\android\support\v4\media\AudioProvider.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */