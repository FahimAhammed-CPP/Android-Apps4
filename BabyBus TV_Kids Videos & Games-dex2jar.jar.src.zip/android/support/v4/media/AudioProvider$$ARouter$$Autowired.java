package android.support.v4.media;

import com.alibaba.android.arouter.facade.service.SerializationService;
import com.alibaba.android.arouter.facade.template.ISyringe;
import com.alibaba.android.arouter.launcher.ARouter;
import com.sinyee.babybus.core.service.audio.provider.IAudioProvider;

public class AudioProvider$$ARouter$$Autowired implements ISyringe {
  private SerializationService serializationService;
  
  public void inject(Object paramObject) {
    this.serializationService = (SerializationService)ARouter.getInstance().navigation(SerializationService.class);
    paramObject = paramObject;
    ((AudioProvider)paramObject).cacheAudioProvider = (IAudioProvider)ARouter.getInstance().build("/mytab/cache/audioprovider").navigation();
    ((AudioProvider)paramObject).downloadAudioProvider = (IAudioProvider)ARouter.getInstance().build("/mytab/download/audioprovider").navigation();
    ((AudioProvider)paramObject).recordAudioProvider = (IAudioProvider)ARouter.getInstance().build("/mytab/videorecord/audioprovider").navigation();
    ((AudioProvider)paramObject).recentAudioProvider = (IAudioProvider)ARouter.getInstance().build("/audio/recent/audioprovider").navigation();
    ((AudioProvider)paramObject).albumDetailAudioProvider = (IAudioProvider)ARouter.getInstance().build("/audio/albumdetail/audioprovider").navigation();
    ((AudioProvider)paramObject).playPageAudioProvider = (IAudioProvider)ARouter.getInstance().build("/audio/playpage/audioprovider").navigation();
  }
}


/* Location:              C:\soft\dex2jar-2.0\BabyBus TV_Kids Videos & Games-dex2jar.jar!\android\support\v4\media\AudioProvider$$ARouter$$Autowired.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */