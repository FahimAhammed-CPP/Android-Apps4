package androidx.collection;

import kotlin.jvm.internal.j;

public final class ArraySetKt {
  public static final <T> ArraySet<T> arraySetOf() {
    return new ArraySet<T>();
  }
  
  public static final <T> ArraySet<T> arraySetOf(T... paramVarArgs) {
    j.g(paramVarArgs, "values");
    ArraySet<T> arraySet = new ArraySet(paramVarArgs.length);
    int j = paramVarArgs.length;
    for (int i = 0; i < j; i++)
      arraySet.add(paramVarArgs[i]); 
    return arraySet;
  }
}


/* Location:              C:\soft\dex2jar-2.0\BabyBus TV_Kids Videos & Games-dex2jar.jar!\androidx\collection\ArraySetKt.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */