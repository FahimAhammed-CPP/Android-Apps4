package androidx.collection;

import fq.a;
import fq.p;
import java.util.Iterator;
import kotlin.collections.z;
import kotlin.jvm.internal.j;
import zp.x;

public final class LongSparseArrayKt {
  public static final <T> boolean contains(LongSparseArray<T> paramLongSparseArray, long paramLong) {
    j.g(paramLongSparseArray, "receiver$0");
    return paramLongSparseArray.containsKey(paramLong);
  }
  
  public static final <T> void forEach(LongSparseArray<T> paramLongSparseArray, p<? super Long, ? super T, x> paramp) {
    j.g(paramLongSparseArray, "receiver$0");
    j.g(paramp, "action");
    int j = paramLongSparseArray.size();
    for (int i = 0; i < j; i++)
      paramp.invoke(Long.valueOf(paramLongSparseArray.keyAt(i)), paramLongSparseArray.valueAt(i)); 
  }
  
  public static final <T> T getOrDefault(LongSparseArray<T> paramLongSparseArray, long paramLong, T paramT) {
    j.g(paramLongSparseArray, "receiver$0");
    return paramLongSparseArray.get(paramLong, paramT);
  }
  
  public static final <T> T getOrElse(LongSparseArray<T> paramLongSparseArray, long paramLong, a<? extends T> parama) {
    j.g(paramLongSparseArray, "receiver$0");
    j.g(parama, "defaultValue");
    paramLongSparseArray = (LongSparseArray<T>)paramLongSparseArray.get(paramLong);
    return (T)((paramLongSparseArray != null) ? paramLongSparseArray : parama.invoke());
  }
  
  public static final <T> int getSize(LongSparseArray<T> paramLongSparseArray) {
    j.g(paramLongSparseArray, "receiver$0");
    return paramLongSparseArray.size();
  }
  
  public static final <T> boolean isNotEmpty(LongSparseArray<T> paramLongSparseArray) {
    j.g(paramLongSparseArray, "receiver$0");
    return paramLongSparseArray.isEmpty() ^ true;
  }
  
  public static final <T> z keyIterator(LongSparseArray<T> paramLongSparseArray) {
    j.g(paramLongSparseArray, "receiver$0");
    return new LongSparseArrayKt$keyIterator$1(paramLongSparseArray);
  }
  
  public static final <T> LongSparseArray<T> plus(LongSparseArray<T> paramLongSparseArray1, LongSparseArray<T> paramLongSparseArray2) {
    j.g(paramLongSparseArray1, "receiver$0");
    j.g(paramLongSparseArray2, "other");
    LongSparseArray<T> longSparseArray = new LongSparseArray(paramLongSparseArray1.size() + paramLongSparseArray2.size());
    longSparseArray.putAll(paramLongSparseArray1);
    longSparseArray.putAll(paramLongSparseArray2);
    return longSparseArray;
  }
  
  public static final <T> boolean remove(LongSparseArray<T> paramLongSparseArray, long paramLong, T paramT) {
    j.g(paramLongSparseArray, "receiver$0");
    return paramLongSparseArray.remove(paramLong, paramT);
  }
  
  public static final <T> void set(LongSparseArray<T> paramLongSparseArray, long paramLong, T paramT) {
    j.g(paramLongSparseArray, "receiver$0");
    paramLongSparseArray.put(paramLong, paramT);
  }
  
  public static final <T> Iterator<T> valueIterator(LongSparseArray<T> paramLongSparseArray) {
    j.g(paramLongSparseArray, "receiver$0");
    return new LongSparseArrayKt$valueIterator$1(paramLongSparseArray);
  }
  
  public static final class LongSparseArrayKt$keyIterator$1 extends z {
    private int index;
    
    LongSparseArrayKt$keyIterator$1(LongSparseArray<T> param1LongSparseArray) {}
    
    public final int getIndex() {
      return this.index;
    }
    
    public boolean hasNext() {
      return (this.index < this.$this_keyIterator.size());
    }
    
    public long nextLong() {
      LongSparseArray longSparseArray = this.$this_keyIterator;
      int i = this.index;
      this.index = i + 1;
      return longSparseArray.keyAt(i);
    }
    
    public final void setIndex(int param1Int) {
      this.index = param1Int;
    }
  }
  
  public static final class LongSparseArrayKt$valueIterator$1 implements Iterator<T> {
    private int index;
    
    LongSparseArrayKt$valueIterator$1(LongSparseArray<T> param1LongSparseArray) {}
    
    public final int getIndex() {
      return this.index;
    }
    
    public boolean hasNext() {
      return (this.index < this.$this_valueIterator.size());
    }
    
    public T next() {
      LongSparseArray<T> longSparseArray = this.$this_valueIterator;
      int i = this.index;
      this.index = i + 1;
      return longSparseArray.valueAt(i);
    }
    
    public void remove() {
      throw new UnsupportedOperationException("Operation is not supported for read-only collection");
    }
    
    public final void setIndex(int param1Int) {
      this.index = param1Int;
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\BabyBus TV_Kids Videos & Games-dex2jar.jar!\androidx\collection\LongSparseArrayKt.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */