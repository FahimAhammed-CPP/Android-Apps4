package androidx.core.app;

import android.app.NotificationChannel;
import android.app.NotificationChannelGroup;
import android.os.Build;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.annotation.RequiresApi;
import androidx.core.util.Preconditions;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

public class NotificationChannelGroupCompat {
  private boolean mBlocked;
  
  private List<NotificationChannelCompat> mChannels = Collections.emptyList();
  
  String mDescription;
  
  final String mId;
  
  CharSequence mName;
  
  @RequiresApi(28)
  NotificationChannelGroupCompat(@NonNull NotificationChannelGroup paramNotificationChannelGroup) {
    this(paramNotificationChannelGroup, Collections.emptyList());
  }
  
  @RequiresApi(26)
  NotificationChannelGroupCompat(@NonNull NotificationChannelGroup paramNotificationChannelGroup, @NonNull List<NotificationChannel> paramList) {
    this(paramNotificationChannelGroup.getId());
    this.mName = paramNotificationChannelGroup.getName();
    int i = Build.VERSION.SDK_INT;
    if (i >= 28)
      this.mDescription = paramNotificationChannelGroup.getDescription(); 
    if (i >= 28) {
      this.mBlocked = paramNotificationChannelGroup.isBlocked();
      this.mChannels = getChannelsCompat(paramNotificationChannelGroup.getChannels());
      return;
    } 
    this.mChannels = getChannelsCompat(paramList);
  }
  
  NotificationChannelGroupCompat(@NonNull String paramString) {
    this.mId = (String)Preconditions.checkNotNull(paramString);
  }
  
  @RequiresApi(26)
  private List<NotificationChannelCompat> getChannelsCompat(List<NotificationChannel> paramList) {
    ArrayList<NotificationChannelCompat> arrayList = new ArrayList();
    for (NotificationChannel notificationChannel : paramList) {
      if (this.mId.equals(notificationChannel.getGroup()))
        arrayList.add(new NotificationChannelCompat(notificationChannel)); 
    } 
    return arrayList;
  }
  
  @NonNull
  public List<NotificationChannelCompat> getChannels() {
    return this.mChannels;
  }
  
  @Nullable
  public String getDescription() {
    return this.mDescription;
  }
  
  @NonNull
  public String getId() {
    return this.mId;
  }
  
  @Nullable
  public CharSequence getName() {
    return this.mName;
  }
  
  NotificationChannelGroup getNotificationChannelGroup() {
    int i = Build.VERSION.SDK_INT;
    if (i < 26)
      return null; 
    NotificationChannelGroup notificationChannelGroup = new NotificationChannelGroup(this.mId, this.mName);
    if (i >= 28)
      notificationChannelGroup.setDescription(this.mDescription); 
    return notificationChannelGroup;
  }
  
  public boolean isBlocked() {
    return this.mBlocked;
  }
  
  @NonNull
  public Builder toBuilder() {
    return (new Builder(this.mId)).setName(this.mName).setDescription(this.mDescription);
  }
  
  public static class Builder {
    final NotificationChannelGroupCompat mGroup;
    
    public Builder(@NonNull String param1String) {
      this.mGroup = new NotificationChannelGroupCompat(param1String);
    }
    
    @NonNull
    public NotificationChannelGroupCompat build() {
      return this.mGroup;
    }
    
    @NonNull
    public Builder setDescription(@Nullable String param1String) {
      this.mGroup.mDescription = param1String;
      return this;
    }
    
    @NonNull
    public Builder setName(@Nullable CharSequence param1CharSequence) {
      this.mGroup.mName = param1CharSequence;
      return this;
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\BabyBus TV_Kids Videos & Games-dex2jar.jar!\androidx\core\app\NotificationChannelGroupCompat.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */