package androidx.core.animation;

import android.animation.Animator;
import androidx.annotation.RequiresApi;
import fq.l;
import kotlin.jvm.internal.j;
import kotlin.jvm.internal.k;
import zp.x;

public final class AnimatorKt {
  public static final Animator.AnimatorListener addListener(Animator paramAnimator, l<? super Animator, x> paraml1, l<? super Animator, x> paraml2, l<? super Animator, x> paraml3, l<? super Animator, x> paraml4) {
    j.f(paramAnimator, "$this$addListener");
    j.f(paraml1, "onEnd");
    j.f(paraml2, "onStart");
    j.f(paraml3, "onCancel");
    j.f(paraml4, "onRepeat");
    AnimatorKt$addListener$listener$1 animatorKt$addListener$listener$1 = new AnimatorKt$addListener$listener$1(paraml4, paraml1, paraml3, paraml2);
    paramAnimator.addListener(animatorKt$addListener$listener$1);
    return animatorKt$addListener$listener$1;
  }
  
  @RequiresApi(19)
  public static final Animator.AnimatorPauseListener addPauseListener(Animator paramAnimator, l<? super Animator, x> paraml1, l<? super Animator, x> paraml2) {
    j.f(paramAnimator, "$this$addPauseListener");
    j.f(paraml1, "onResume");
    j.f(paraml2, "onPause");
    AnimatorKt$addPauseListener$listener$1 animatorKt$addPauseListener$listener$1 = new AnimatorKt$addPauseListener$listener$1(paraml2, paraml1);
    paramAnimator.addPauseListener(animatorKt$addPauseListener$listener$1);
    return animatorKt$addPauseListener$listener$1;
  }
  
  public static final Animator.AnimatorListener doOnCancel(Animator paramAnimator, l<? super Animator, x> paraml) {
    j.f(paramAnimator, "$this$doOnCancel");
    j.f(paraml, "action");
    AnimatorKt$doOnCancel$$inlined$addListener$1 animatorKt$doOnCancel$$inlined$addListener$1 = new AnimatorKt$doOnCancel$$inlined$addListener$1(paraml);
    paramAnimator.addListener(animatorKt$doOnCancel$$inlined$addListener$1);
    return animatorKt$doOnCancel$$inlined$addListener$1;
  }
  
  public static final Animator.AnimatorListener doOnEnd(Animator paramAnimator, l<? super Animator, x> paraml) {
    j.f(paramAnimator, "$this$doOnEnd");
    j.f(paraml, "action");
    AnimatorKt$doOnEnd$$inlined$addListener$1 animatorKt$doOnEnd$$inlined$addListener$1 = new AnimatorKt$doOnEnd$$inlined$addListener$1(paraml);
    paramAnimator.addListener(animatorKt$doOnEnd$$inlined$addListener$1);
    return animatorKt$doOnEnd$$inlined$addListener$1;
  }
  
  @RequiresApi(19)
  public static final Animator.AnimatorPauseListener doOnPause(Animator paramAnimator, l<? super Animator, x> paraml) {
    j.f(paramAnimator, "$this$doOnPause");
    j.f(paraml, "action");
    AnimatorKt$doOnPause$$inlined$addPauseListener$1 animatorKt$doOnPause$$inlined$addPauseListener$1 = new AnimatorKt$doOnPause$$inlined$addPauseListener$1(paraml);
    paramAnimator.addPauseListener(animatorKt$doOnPause$$inlined$addPauseListener$1);
    return animatorKt$doOnPause$$inlined$addPauseListener$1;
  }
  
  public static final Animator.AnimatorListener doOnRepeat(Animator paramAnimator, l<? super Animator, x> paraml) {
    j.f(paramAnimator, "$this$doOnRepeat");
    j.f(paraml, "action");
    AnimatorKt$doOnRepeat$$inlined$addListener$1 animatorKt$doOnRepeat$$inlined$addListener$1 = new AnimatorKt$doOnRepeat$$inlined$addListener$1(paraml);
    paramAnimator.addListener(animatorKt$doOnRepeat$$inlined$addListener$1);
    return animatorKt$doOnRepeat$$inlined$addListener$1;
  }
  
  @RequiresApi(19)
  public static final Animator.AnimatorPauseListener doOnResume(Animator paramAnimator, l<? super Animator, x> paraml) {
    j.f(paramAnimator, "$this$doOnResume");
    j.f(paraml, "action");
    AnimatorKt$doOnResume$$inlined$addPauseListener$1 animatorKt$doOnResume$$inlined$addPauseListener$1 = new AnimatorKt$doOnResume$$inlined$addPauseListener$1(paraml);
    paramAnimator.addPauseListener(animatorKt$doOnResume$$inlined$addPauseListener$1);
    return animatorKt$doOnResume$$inlined$addPauseListener$1;
  }
  
  public static final Animator.AnimatorListener doOnStart(Animator paramAnimator, l<? super Animator, x> paraml) {
    j.f(paramAnimator, "$this$doOnStart");
    j.f(paraml, "action");
    AnimatorKt$doOnStart$$inlined$addListener$1 animatorKt$doOnStart$$inlined$addListener$1 = new AnimatorKt$doOnStart$$inlined$addListener$1(paraml);
    paramAnimator.addListener(animatorKt$doOnStart$$inlined$addListener$1);
    return animatorKt$doOnStart$$inlined$addListener$1;
  }
  
  public static final class AnimatorKt$addListener$1 extends k implements l<Animator, x> {
    public static final AnimatorKt$addListener$1 INSTANCE = new AnimatorKt$addListener$1();
    
    public AnimatorKt$addListener$1() {
      super(1);
    }
    
    public final void invoke(Animator param1Animator) {
      j.f(param1Animator, "it");
    }
  }
  
  public static final class AnimatorKt$addListener$2 extends k implements l<Animator, x> {
    public static final AnimatorKt$addListener$2 INSTANCE = new AnimatorKt$addListener$2();
    
    public AnimatorKt$addListener$2() {
      super(1);
    }
    
    public final void invoke(Animator param1Animator) {
      j.f(param1Animator, "it");
    }
  }
  
  public static final class AnimatorKt$addListener$3 extends k implements l<Animator, x> {
    public static final AnimatorKt$addListener$3 INSTANCE = new AnimatorKt$addListener$3();
    
    public AnimatorKt$addListener$3() {
      super(1);
    }
    
    public final void invoke(Animator param1Animator) {
      j.f(param1Animator, "it");
    }
  }
  
  public static final class AnimatorKt$addListener$4 extends k implements l<Animator, x> {
    public static final AnimatorKt$addListener$4 INSTANCE = new AnimatorKt$addListener$4();
    
    public AnimatorKt$addListener$4() {
      super(1);
    }
    
    public final void invoke(Animator param1Animator) {
      j.f(param1Animator, "it");
    }
  }
  
  public static final class AnimatorKt$addListener$listener$1 implements Animator.AnimatorListener {
    public AnimatorKt$addListener$listener$1(l param1l1, l param1l2, l param1l3, l param1l4) {}
    
    public void onAnimationCancel(Animator param1Animator) {
      j.f(param1Animator, "animator");
      this.$onCancel.invoke(param1Animator);
    }
    
    public void onAnimationEnd(Animator param1Animator) {
      j.f(param1Animator, "animator");
      this.$onEnd.invoke(param1Animator);
    }
    
    public void onAnimationRepeat(Animator param1Animator) {
      j.f(param1Animator, "animator");
      this.$onRepeat.invoke(param1Animator);
    }
    
    public void onAnimationStart(Animator param1Animator) {
      j.f(param1Animator, "animator");
      this.$onStart.invoke(param1Animator);
    }
  }
  
  public static final class AnimatorKt$addPauseListener$1 extends k implements l<Animator, x> {
    public static final AnimatorKt$addPauseListener$1 INSTANCE = new AnimatorKt$addPauseListener$1();
    
    public AnimatorKt$addPauseListener$1() {
      super(1);
    }
    
    public final void invoke(Animator param1Animator) {
      j.f(param1Animator, "it");
    }
  }
  
  public static final class AnimatorKt$addPauseListener$2 extends k implements l<Animator, x> {
    public static final AnimatorKt$addPauseListener$2 INSTANCE = new AnimatorKt$addPauseListener$2();
    
    public AnimatorKt$addPauseListener$2() {
      super(1);
    }
    
    public final void invoke(Animator param1Animator) {
      j.f(param1Animator, "it");
    }
  }
  
  public static final class AnimatorKt$addPauseListener$listener$1 implements Animator.AnimatorPauseListener {
    public AnimatorKt$addPauseListener$listener$1(l param1l1, l param1l2) {}
    
    public void onAnimationPause(Animator param1Animator) {
      j.f(param1Animator, "animator");
      this.$onPause.invoke(param1Animator);
    }
    
    public void onAnimationResume(Animator param1Animator) {
      j.f(param1Animator, "animator");
      this.$onResume.invoke(param1Animator);
    }
  }
  
  public static final class AnimatorKt$doOnCancel$$inlined$addListener$1 implements Animator.AnimatorListener {
    public AnimatorKt$doOnCancel$$inlined$addListener$1(l param1l) {}
    
    public void onAnimationCancel(Animator param1Animator) {
      j.f(param1Animator, "animator");
      this.$onCancel.invoke(param1Animator);
    }
    
    public void onAnimationEnd(Animator param1Animator) {
      j.f(param1Animator, "animator");
    }
    
    public void onAnimationRepeat(Animator param1Animator) {
      j.f(param1Animator, "animator");
    }
    
    public void onAnimationStart(Animator param1Animator) {
      j.f(param1Animator, "animator");
    }
  }
  
  public static final class AnimatorKt$doOnEnd$$inlined$addListener$1 implements Animator.AnimatorListener {
    public AnimatorKt$doOnEnd$$inlined$addListener$1(l param1l) {}
    
    public void onAnimationCancel(Animator param1Animator) {
      j.f(param1Animator, "animator");
    }
    
    public void onAnimationEnd(Animator param1Animator) {
      j.f(param1Animator, "animator");
      this.$onEnd.invoke(param1Animator);
    }
    
    public void onAnimationRepeat(Animator param1Animator) {
      j.f(param1Animator, "animator");
    }
    
    public void onAnimationStart(Animator param1Animator) {
      j.f(param1Animator, "animator");
    }
  }
  
  public static final class AnimatorKt$doOnPause$$inlined$addPauseListener$1 implements Animator.AnimatorPauseListener {
    public AnimatorKt$doOnPause$$inlined$addPauseListener$1(l param1l) {}
    
    public void onAnimationPause(Animator param1Animator) {
      j.f(param1Animator, "animator");
      this.$onPause.invoke(param1Animator);
    }
    
    public void onAnimationResume(Animator param1Animator) {
      j.f(param1Animator, "animator");
    }
  }
  
  public static final class AnimatorKt$doOnRepeat$$inlined$addListener$1 implements Animator.AnimatorListener {
    public AnimatorKt$doOnRepeat$$inlined$addListener$1(l param1l) {}
    
    public void onAnimationCancel(Animator param1Animator) {
      j.f(param1Animator, "animator");
    }
    
    public void onAnimationEnd(Animator param1Animator) {
      j.f(param1Animator, "animator");
    }
    
    public void onAnimationRepeat(Animator param1Animator) {
      j.f(param1Animator, "animator");
      this.$onRepeat.invoke(param1Animator);
    }
    
    public void onAnimationStart(Animator param1Animator) {
      j.f(param1Animator, "animator");
    }
  }
  
  public static final class AnimatorKt$doOnResume$$inlined$addPauseListener$1 implements Animator.AnimatorPauseListener {
    public AnimatorKt$doOnResume$$inlined$addPauseListener$1(l param1l) {}
    
    public void onAnimationPause(Animator param1Animator) {
      j.f(param1Animator, "animator");
    }
    
    public void onAnimationResume(Animator param1Animator) {
      j.f(param1Animator, "animator");
      this.$onResume.invoke(param1Animator);
    }
  }
  
  public static final class AnimatorKt$doOnStart$$inlined$addListener$1 implements Animator.AnimatorListener {
    public AnimatorKt$doOnStart$$inlined$addListener$1(l param1l) {}
    
    public void onAnimationCancel(Animator param1Animator) {
      j.f(param1Animator, "animator");
    }
    
    public void onAnimationEnd(Animator param1Animator) {
      j.f(param1Animator, "animator");
    }
    
    public void onAnimationRepeat(Animator param1Animator) {
      j.f(param1Animator, "animator");
    }
    
    public void onAnimationStart(Animator param1Animator) {
      j.f(param1Animator, "animator");
      this.$onStart.invoke(param1Animator);
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\BabyBus TV_Kids Videos & Games-dex2jar.jar!\androidx\core\animation\AnimatorKt.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */