package androidx.activity;

import androidx.lifecycle.LifecycleOwner;
import fq.l;
import kotlin.jvm.internal.j;
import zp.x;

public final class OnBackPressedDispatcherKt {
  public static final OnBackPressedCallback addCallback(OnBackPressedDispatcher paramOnBackPressedDispatcher, LifecycleOwner paramLifecycleOwner, boolean paramBoolean, l<? super OnBackPressedCallback, x> paraml) {
    j.f(paramOnBackPressedDispatcher, "$this$addCallback");
    j.f(paraml, "onBackPressed");
    OnBackPressedDispatcherKt$addCallback$callback$1 onBackPressedDispatcherKt$addCallback$callback$1 = new OnBackPressedDispatcherKt$addCallback$callback$1(paraml, paramBoolean, paramBoolean);
    if (paramLifecycleOwner != null) {
      paramOnBackPressedDispatcher.addCallback(paramLifecycleOwner, onBackPressedDispatcherKt$addCallback$callback$1);
      return onBackPressedDispatcherKt$addCallback$callback$1;
    } 
    paramOnBackPressedDispatcher.addCallback(onBackPressedDispatcherKt$addCallback$callback$1);
    return onBackPressedDispatcherKt$addCallback$callback$1;
  }
  
  public static final class OnBackPressedDispatcherKt$addCallback$callback$1 extends OnBackPressedCallback {
    OnBackPressedDispatcherKt$addCallback$callback$1(l param1l, boolean param1Boolean1, boolean param1Boolean2) {
      super(param1Boolean2);
    }
    
    public void handleOnBackPressed() {
      this.$onBackPressed.invoke(this);
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\BabyBus TV_Kids Videos & Games-dex2jar.jar!\androidx\activity\OnBackPressedDispatcherKt.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */