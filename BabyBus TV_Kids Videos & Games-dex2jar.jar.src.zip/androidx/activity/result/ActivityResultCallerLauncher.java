package androidx.activity.result;

import android.content.Context;
import android.content.Intent;
import androidx.activity.result.contract.ActivityResultContract;
import androidx.core.app.ActivityOptionsCompat;
import fq.a;
import kotlin.jvm.internal.j;
import kotlin.jvm.internal.k;
import zp.i;
import zp.j;
import zp.x;

public final class ActivityResultCallerLauncher<I, O> extends ActivityResultLauncher<x> {
  private final ActivityResultContract<I, O> callerContract;
  
  private final I input;
  
  private final ActivityResultLauncher<I> launcher;
  
  private final i resultContract$delegate;
  
  public ActivityResultCallerLauncher(ActivityResultLauncher<I> paramActivityResultLauncher, ActivityResultContract<I, O> paramActivityResultContract, I paramI) {
    this.launcher = paramActivityResultLauncher;
    this.callerContract = paramActivityResultContract;
    this.input = paramI;
    this.resultContract$delegate = j.a(new ActivityResultCallerLauncher$resultContract$2());
  }
  
  public final ActivityResultContract<I, O> getCallerContract() {
    return this.callerContract;
  }
  
  public ActivityResultContract<x, O> getContract() {
    return getResultContract();
  }
  
  public final I getInput() {
    return this.input;
  }
  
  public final ActivityResultLauncher<I> getLauncher() {
    return this.launcher;
  }
  
  public final ActivityResultContract<x, O> getResultContract() {
    return (ActivityResultContract<x, O>)this.resultContract$delegate.getValue();
  }
  
  public void launch(x paramx, ActivityOptionsCompat paramActivityOptionsCompat) {
    this.launcher.launch(this.input, paramActivityOptionsCompat);
  }
  
  public void unregister() {
    this.launcher.unregister();
  }
  
  static final class ActivityResultCallerLauncher$resultContract$2 extends k implements a<ActivityResultCallerLauncher$resultContract$2.null> {
    ActivityResultCallerLauncher$resultContract$2() {
      super(0);
    }
    
    public final null invoke() {
      return (null)new ActivityResultContract<x, O>() {
          public Intent createIntent(Context param1Context, x param1x) {
            j.f(param1Context, "context");
            Intent intent = ActivityResultCallerLauncher.this.getCallerContract().createIntent(param1Context, ActivityResultCallerLauncher.this.getInput());
            j.e(intent, "callerContract.createIntent(context, input)");
            return intent;
          }
          
          public O parseResult(int param1Int, Intent param1Intent) {
            return (O)ActivityResultCallerLauncher.this.getCallerContract().parseResult(param1Int, param1Intent);
          }
        };
    }
  }
  
  public static final class null extends ActivityResultContract<x, O> {
    public Intent createIntent(Context param1Context, x param1x) {
      j.f(param1Context, "context");
      Intent intent = ActivityResultCallerLauncher.this.getCallerContract().createIntent(param1Context, ActivityResultCallerLauncher.this.getInput());
      j.e(intent, "callerContract.createIntent(context, input)");
      return intent;
    }
    
    public O parseResult(int param1Int, Intent param1Intent) {
      return (O)ActivityResultCallerLauncher.this.getCallerContract().parseResult(param1Int, param1Intent);
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\BabyBus TV_Kids Videos & Games-dex2jar.jar!\androidx\activity\result\ActivityResultCallerLauncher.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */