package androidx.activity.result;

import androidx.annotation.NonNull;

public interface ActivityResultRegistryOwner {
  @NonNull
  ActivityResultRegistry getActivityResultRegistry();
}


/* Location:              C:\soft\dex2jar-2.0\BabyBus TV_Kids Videos & Games-dex2jar.jar!\androidx\activity\result\ActivityResultRegistryOwner.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */