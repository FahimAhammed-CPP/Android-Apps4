package androidx.activity.result;

import androidx.activity.result.contract.ActivityResultContract;
import fq.l;
import kotlin.jvm.internal.j;
import zp.x;

public final class ActivityResultCallerKt {
  public static final <I, O> ActivityResultLauncher<x> registerForActivityResult(ActivityResultCaller paramActivityResultCaller, ActivityResultContract<I, O> paramActivityResultContract, I paramI, ActivityResultRegistry paramActivityResultRegistry, l<? super O, x> paraml) {
    j.f(paramActivityResultCaller, "$this$registerForActivityResult");
    j.f(paramActivityResultContract, "contract");
    j.f(paramActivityResultRegistry, "registry");
    j.f(paraml, "callback");
    ActivityResultLauncher<I> activityResultLauncher = paramActivityResultCaller.registerForActivityResult(paramActivityResultContract, paramActivityResultRegistry, new ActivityResultCallerKt$registerForActivityResult$resultLauncher$1<O>(paraml));
    j.e(activityResultLauncher, "registerForActivityResul…egistry) { callback(it) }");
    return new ActivityResultCallerLauncher<I, O>(activityResultLauncher, paramActivityResultContract, paramI);
  }
  
  public static final <I, O> ActivityResultLauncher<x> registerForActivityResult(ActivityResultCaller paramActivityResultCaller, ActivityResultContract<I, O> paramActivityResultContract, I paramI, l<? super O, x> paraml) {
    j.f(paramActivityResultCaller, "$this$registerForActivityResult");
    j.f(paramActivityResultContract, "contract");
    j.f(paraml, "callback");
    ActivityResultLauncher<I> activityResultLauncher = paramActivityResultCaller.registerForActivityResult(paramActivityResultContract, new ActivityResultCallerKt$registerForActivityResult$resultLauncher$2<O>(paraml));
    j.e(activityResultLauncher, "registerForActivityResul…ontract) { callback(it) }");
    return new ActivityResultCallerLauncher<I, O>(activityResultLauncher, paramActivityResultContract, paramI);
  }
  
  static final class ActivityResultCallerKt$registerForActivityResult$resultLauncher$1<O> implements ActivityResultCallback<O> {
    ActivityResultCallerKt$registerForActivityResult$resultLauncher$1(l param1l) {}
    
    public final void onActivityResult(O param1O) {
      this.$callback.invoke(param1O);
    }
  }
  
  static final class ActivityResultCallerKt$registerForActivityResult$resultLauncher$2<O> implements ActivityResultCallback<O> {
    ActivityResultCallerKt$registerForActivityResult$resultLauncher$2(l param1l) {}
    
    public final void onActivityResult(O param1O) {
      this.$callback.invoke(param1O);
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\BabyBus TV_Kids Videos & Games-dex2jar.jar!\androidx\activity\result\ActivityResultCallerKt.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */