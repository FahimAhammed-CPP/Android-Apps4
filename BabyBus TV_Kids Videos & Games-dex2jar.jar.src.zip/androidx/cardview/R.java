package androidx.cardview;

public final class R {
  public static final class attr {
    public static final int cardBackgroundColor = 2130968799;
    
    public static final int cardCornerRadius = 2130968800;
    
    public static final int cardElevation = 2130968801;
    
    public static final int cardMaxElevation = 2130968803;
    
    public static final int cardPreventCornerOverlap = 2130968804;
    
    public static final int cardUseCompatPadding = 2130968805;
    
    public static final int cardViewStyle = 2130968806;
    
    public static final int contentPadding = 2130968985;
    
    public static final int contentPaddingBottom = 2130968986;
    
    public static final int contentPaddingLeft = 2130968988;
    
    public static final int contentPaddingRight = 2130968989;
    
    public static final int contentPaddingTop = 2130968991;
  }
  
  public static final class color {
    public static final int cardview_dark_background = 2131099745;
    
    public static final int cardview_light_background = 2131099746;
    
    public static final int cardview_shadow_end_color = 2131099747;
    
    public static final int cardview_shadow_start_color = 2131099748;
  }
  
  public static final class dimen {
    public static final int cardview_compat_inset_shadow = 2131165284;
    
    public static final int cardview_default_elevation = 2131165285;
    
    public static final int cardview_default_radius = 2131165286;
  }
  
  public static final class style {
    public static final int Base_CardView = 2131820561;
    
    public static final int CardView = 2131820781;
    
    public static final int CardView_Dark = 2131820782;
    
    public static final int CardView_Light = 2131820783;
  }
  
  public static final class styleable {
    public static final int[] CardView = new int[] { 
        16843071, 16843072, 2130968799, 2130968800, 2130968801, 2130968803, 2130968804, 2130968805, 2130968985, 2130968986, 
        2130968988, 2130968989, 2130968991 };
    
    public static final int CardView_android_minHeight = 1;
    
    public static final int CardView_android_minWidth = 0;
    
    public static final int CardView_cardBackgroundColor = 2;
    
    public static final int CardView_cardCornerRadius = 3;
    
    public static final int CardView_cardElevation = 4;
    
    public static final int CardView_cardMaxElevation = 5;
    
    public static final int CardView_cardPreventCornerOverlap = 6;
    
    public static final int CardView_cardUseCompatPadding = 7;
    
    public static final int CardView_contentPadding = 8;
    
    public static final int CardView_contentPaddingBottom = 9;
    
    public static final int CardView_contentPaddingLeft = 10;
    
    public static final int CardView_contentPaddingRight = 11;
    
    public static final int CardView_contentPaddingTop = 12;
  }
}


/* Location:              C:\soft\dex2jar-2.0\BabyBus TV_Kids Videos & Games-dex2jar.jar!\androidx\cardview\R.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */