package androidx.appcompat.widget;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.drawable.Drawable;
import android.util.AttributeSet;
import android.view.View;
import android.view.ViewGroup;
import android.view.accessibility.AccessibilityEvent;
import android.view.accessibility.AccessibilityNodeInfo;
import android.widget.LinearLayout;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.annotation.RestrictTo;
import androidx.appcompat.R;
import androidx.core.view.GravityCompat;
import androidx.core.view.ViewCompat;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;

public class LinearLayoutCompat extends ViewGroup {
  private static final String ACCESSIBILITY_CLASS_NAME = "androidx.appcompat.widget.LinearLayoutCompat";
  
  public static final int HORIZONTAL = 0;
  
  private static final int INDEX_BOTTOM = 2;
  
  private static final int INDEX_CENTER_VERTICAL = 0;
  
  private static final int INDEX_FILL = 3;
  
  private static final int INDEX_TOP = 1;
  
  public static final int SHOW_DIVIDER_BEGINNING = 1;
  
  public static final int SHOW_DIVIDER_END = 4;
  
  public static final int SHOW_DIVIDER_MIDDLE = 2;
  
  public static final int SHOW_DIVIDER_NONE = 0;
  
  public static final int VERTICAL = 1;
  
  private static final int VERTICAL_GRAVITY_COUNT = 4;
  
  private boolean mBaselineAligned = true;
  
  private int mBaselineAlignedChildIndex = -1;
  
  private int mBaselineChildTop = 0;
  
  private Drawable mDivider;
  
  private int mDividerHeight;
  
  private int mDividerPadding;
  
  private int mDividerWidth;
  
  private int mGravity = 8388659;
  
  private int[] mMaxAscent;
  
  private int[] mMaxDescent;
  
  private int mOrientation;
  
  private int mShowDividers;
  
  private int mTotalLength;
  
  private boolean mUseLargestChild;
  
  private float mWeightSum;
  
  public LinearLayoutCompat(@NonNull Context paramContext) {
    this(paramContext, null);
  }
  
  public LinearLayoutCompat(@NonNull Context paramContext, @Nullable AttributeSet paramAttributeSet) {
    this(paramContext, paramAttributeSet, 0);
  }
  
  public LinearLayoutCompat(@NonNull Context paramContext, @Nullable AttributeSet paramAttributeSet, int paramInt) {
    super(paramContext, paramAttributeSet, paramInt);
    int[] arrayOfInt = R.styleable.LinearLayoutCompat;
    TintTypedArray tintTypedArray = TintTypedArray.obtainStyledAttributes(paramContext, paramAttributeSet, arrayOfInt, paramInt, 0);
    ViewCompat.saveAttributeDataForStyleable((View)this, paramContext, arrayOfInt, paramAttributeSet, tintTypedArray.getWrappedTypeArray(), paramInt, 0);
    paramInt = tintTypedArray.getInt(R.styleable.LinearLayoutCompat_android_orientation, -1);
    if (paramInt >= 0)
      setOrientation(paramInt); 
    paramInt = tintTypedArray.getInt(R.styleable.LinearLayoutCompat_android_gravity, -1);
    if (paramInt >= 0)
      setGravity(paramInt); 
    boolean bool = tintTypedArray.getBoolean(R.styleable.LinearLayoutCompat_android_baselineAligned, true);
    if (!bool)
      setBaselineAligned(bool); 
    this.mWeightSum = tintTypedArray.getFloat(R.styleable.LinearLayoutCompat_android_weightSum, -1.0F);
    this.mBaselineAlignedChildIndex = tintTypedArray.getInt(R.styleable.LinearLayoutCompat_android_baselineAlignedChildIndex, -1);
    this.mUseLargestChild = tintTypedArray.getBoolean(R.styleable.LinearLayoutCompat_measureWithLargestChild, false);
    setDividerDrawable(tintTypedArray.getDrawable(R.styleable.LinearLayoutCompat_divider));
    this.mShowDividers = tintTypedArray.getInt(R.styleable.LinearLayoutCompat_showDividers, 0);
    this.mDividerPadding = tintTypedArray.getDimensionPixelSize(R.styleable.LinearLayoutCompat_dividerPadding, 0);
    tintTypedArray.recycle();
  }
  
  private void forceUniformHeight(int paramInt1, int paramInt2) {
    int j = View.MeasureSpec.makeMeasureSpec(getMeasuredHeight(), 1073741824);
    for (int i = 0; i < paramInt1; i++) {
      View view = getVirtualChildAt(i);
      if (view.getVisibility() != 8) {
        LayoutParams layoutParams = (LayoutParams)view.getLayoutParams();
        if (layoutParams.height == -1) {
          int k = layoutParams.width;
          layoutParams.width = view.getMeasuredWidth();
          measureChildWithMargins(view, paramInt2, 0, j, 0);
          layoutParams.width = k;
        } 
      } 
    } 
  }
  
  private void forceUniformWidth(int paramInt1, int paramInt2) {
    int j = View.MeasureSpec.makeMeasureSpec(getMeasuredWidth(), 1073741824);
    for (int i = 0; i < paramInt1; i++) {
      View view = getVirtualChildAt(i);
      if (view.getVisibility() != 8) {
        LayoutParams layoutParams = (LayoutParams)view.getLayoutParams();
        if (layoutParams.width == -1) {
          int k = layoutParams.height;
          layoutParams.height = view.getMeasuredHeight();
          measureChildWithMargins(view, j, 0, paramInt2, 0);
          layoutParams.height = k;
        } 
      } 
    } 
  }
  
  private void setChildFrame(View paramView, int paramInt1, int paramInt2, int paramInt3, int paramInt4) {
    paramView.layout(paramInt1, paramInt2, paramInt3 + paramInt1, paramInt4 + paramInt2);
  }
  
  protected boolean checkLayoutParams(ViewGroup.LayoutParams paramLayoutParams) {
    return paramLayoutParams instanceof LayoutParams;
  }
  
  void drawDividersHorizontal(Canvas paramCanvas) {
    int j = getVirtualChildCount();
    boolean bool = ViewUtils.isLayoutRtl((View)this);
    int i;
    for (i = 0; i < j; i++) {
      View view = getVirtualChildAt(i);
      if (view != null && view.getVisibility() != 8 && hasDividerBeforeChildAt(i)) {
        int k;
        LayoutParams layoutParams = (LayoutParams)view.getLayoutParams();
        if (bool) {
          k = view.getRight() + layoutParams.rightMargin;
        } else {
          k = view.getLeft() - layoutParams.leftMargin - this.mDividerWidth;
        } 
        drawVerticalDivider(paramCanvas, k);
      } 
    } 
    if (hasDividerBeforeChildAt(j)) {
      View view = getVirtualChildAt(j - 1);
      if (view == null) {
        if (bool) {
          i = getPaddingLeft();
        } else {
          i = getWidth() - getPaddingRight();
          int k = this.mDividerWidth;
          i -= k;
        } 
      } else {
        int k;
        LayoutParams layoutParams = (LayoutParams)view.getLayoutParams();
        if (bool) {
          i = view.getLeft() - layoutParams.leftMargin;
          k = this.mDividerWidth;
        } else {
          i = view.getRight() + layoutParams.rightMargin;
          drawVerticalDivider(paramCanvas, i);
        } 
        i -= k;
      } 
    } else {
      return;
    } 
    drawVerticalDivider(paramCanvas, i);
  }
  
  void drawDividersVertical(Canvas paramCanvas) {
    int j = getVirtualChildCount();
    int i;
    for (i = 0; i < j; i++) {
      View view = getVirtualChildAt(i);
      if (view != null && view.getVisibility() != 8 && hasDividerBeforeChildAt(i)) {
        LayoutParams layoutParams = (LayoutParams)view.getLayoutParams();
        drawHorizontalDivider(paramCanvas, view.getTop() - layoutParams.topMargin - this.mDividerHeight);
      } 
    } 
    if (hasDividerBeforeChildAt(j)) {
      View view = getVirtualChildAt(j - 1);
      if (view == null) {
        i = getHeight() - getPaddingBottom() - this.mDividerHeight;
      } else {
        LayoutParams layoutParams = (LayoutParams)view.getLayoutParams();
        i = view.getBottom() + layoutParams.bottomMargin;
      } 
      drawHorizontalDivider(paramCanvas, i);
    } 
  }
  
  void drawHorizontalDivider(Canvas paramCanvas, int paramInt) {
    this.mDivider.setBounds(getPaddingLeft() + this.mDividerPadding, paramInt, getWidth() - getPaddingRight() - this.mDividerPadding, this.mDividerHeight + paramInt);
    this.mDivider.draw(paramCanvas);
  }
  
  void drawVerticalDivider(Canvas paramCanvas, int paramInt) {
    this.mDivider.setBounds(paramInt, getPaddingTop() + this.mDividerPadding, this.mDividerWidth + paramInt, getHeight() - getPaddingBottom() - this.mDividerPadding);
    this.mDivider.draw(paramCanvas);
  }
  
  protected LayoutParams generateDefaultLayoutParams() {
    int i = this.mOrientation;
    return (i == 0) ? new LayoutParams(-2, -2) : ((i == 1) ? new LayoutParams(-1, -2) : null);
  }
  
  public LayoutParams generateLayoutParams(AttributeSet paramAttributeSet) {
    return new LayoutParams(getContext(), paramAttributeSet);
  }
  
  protected LayoutParams generateLayoutParams(ViewGroup.LayoutParams paramLayoutParams) {
    return new LayoutParams(paramLayoutParams);
  }
  
  public int getBaseline() {
    if (this.mBaselineAlignedChildIndex < 0)
      return super.getBaseline(); 
    int i = getChildCount();
    int j = this.mBaselineAlignedChildIndex;
    if (i > j) {
      View view = getChildAt(j);
      int k = view.getBaseline();
      if (k == -1) {
        if (this.mBaselineAlignedChildIndex == 0)
          return -1; 
        throw new RuntimeException("mBaselineAlignedChildIndex of LinearLayout points to a View that doesn't know how to get its baseline.");
      } 
      j = this.mBaselineChildTop;
      i = j;
      if (this.mOrientation == 1) {
        int m = this.mGravity & 0x70;
        i = j;
        if (m != 48)
          if (m != 16) {
            if (m != 80) {
              i = j;
            } else {
              i = getBottom() - getTop() - getPaddingBottom() - this.mTotalLength;
            } 
          } else {
            i = j + (getBottom() - getTop() - getPaddingTop() - getPaddingBottom() - this.mTotalLength) / 2;
          }  
      } 
      return i + ((LayoutParams)view.getLayoutParams()).topMargin + k;
    } 
    throw new RuntimeException("mBaselineAlignedChildIndex of LinearLayout set to an index that is out of bounds.");
  }
  
  public int getBaselineAlignedChildIndex() {
    return this.mBaselineAlignedChildIndex;
  }
  
  int getChildrenSkipCount(View paramView, int paramInt) {
    return 0;
  }
  
  public Drawable getDividerDrawable() {
    return this.mDivider;
  }
  
  public int getDividerPadding() {
    return this.mDividerPadding;
  }
  
  @RestrictTo({RestrictTo.Scope.LIBRARY_GROUP_PREFIX})
  public int getDividerWidth() {
    return this.mDividerWidth;
  }
  
  public int getGravity() {
    return this.mGravity;
  }
  
  int getLocationOffset(View paramView) {
    return 0;
  }
  
  int getNextLocationOffset(View paramView) {
    return 0;
  }
  
  public int getOrientation() {
    return this.mOrientation;
  }
  
  public int getShowDividers() {
    return this.mShowDividers;
  }
  
  View getVirtualChildAt(int paramInt) {
    return getChildAt(paramInt);
  }
  
  int getVirtualChildCount() {
    return getChildCount();
  }
  
  public float getWeightSum() {
    return this.mWeightSum;
  }
  
  @RestrictTo({RestrictTo.Scope.LIBRARY})
  protected boolean hasDividerBeforeChildAt(int paramInt) {
    boolean bool2 = false;
    boolean bool1 = false;
    if (paramInt == 0) {
      if ((this.mShowDividers & 0x1) != 0)
        bool1 = true; 
      return bool1;
    } 
    if (paramInt == getChildCount()) {
      bool1 = bool2;
      if ((this.mShowDividers & 0x4) != 0)
        bool1 = true; 
      return bool1;
    } 
    if ((this.mShowDividers & 0x2) != 0)
      while (--paramInt >= 0) {
        if (getChildAt(paramInt).getVisibility() != 8)
          return true; 
        paramInt--;
      }  
    return false;
  }
  
  public boolean isBaselineAligned() {
    return this.mBaselineAligned;
  }
  
  public boolean isMeasureWithLargestChildEnabled() {
    return this.mUseLargestChild;
  }
  
  void layoutHorizontal(int paramInt1, int paramInt2, int paramInt3, int paramInt4) {
    byte b1;
    byte b2;
    boolean bool1 = ViewUtils.isLayoutRtl((View)this);
    int k = getPaddingTop();
    int m = paramInt4 - paramInt2;
    int n = getPaddingBottom();
    int i1 = getPaddingBottom();
    int j = getVirtualChildCount();
    paramInt2 = this.mGravity;
    paramInt4 = paramInt2 & 0x70;
    boolean bool2 = this.mBaselineAligned;
    int[] arrayOfInt1 = this.mMaxAscent;
    int[] arrayOfInt2 = this.mMaxDescent;
    paramInt2 = GravityCompat.getAbsoluteGravity(0x800007 & paramInt2, ViewCompat.getLayoutDirection((View)this));
    if (paramInt2 != 1) {
      if (paramInt2 != 5) {
        paramInt2 = getPaddingLeft();
      } else {
        paramInt2 = getPaddingLeft() + paramInt3 - paramInt1 - this.mTotalLength;
      } 
    } else {
      paramInt2 = getPaddingLeft() + (paramInt3 - paramInt1 - this.mTotalLength) / 2;
    } 
    if (bool1) {
      b1 = j - 1;
      b2 = -1;
    } else {
      b1 = 0;
      b2 = 1;
    } 
    int i = 0;
    paramInt3 = paramInt4;
    paramInt4 = k;
    while (i < j) {
      int i2 = b1 + b2 * i;
      View view = getVirtualChildAt(i2);
      if (view == null) {
        paramInt2 += measureNullChild(i2);
      } else if (view.getVisibility() != 8) {
        int i5 = view.getMeasuredWidth();
        int i6 = view.getMeasuredHeight();
        LayoutParams layoutParams = (LayoutParams)view.getLayoutParams();
        if (bool2 && layoutParams.height != -1) {
          i3 = view.getBaseline();
        } else {
          i3 = -1;
        } 
        int i4 = layoutParams.gravity;
        paramInt1 = i4;
        if (i4 < 0)
          paramInt1 = paramInt3; 
        paramInt1 &= 0x70;
        if (paramInt1 != 16) {
          if (paramInt1 != 48) {
            if (paramInt1 != 80) {
              paramInt1 = paramInt4;
            } else {
              i4 = m - n - i6 - layoutParams.bottomMargin;
              paramInt1 = i4;
              if (i3 != -1) {
                paramInt1 = view.getMeasuredHeight();
                paramInt1 = i4 - arrayOfInt2[2] - paramInt1 - i3;
              } 
            } 
          } else {
            i4 = layoutParams.topMargin + paramInt4;
            paramInt1 = i4;
            if (i3 != -1)
              paramInt1 = i4 + arrayOfInt1[1] - i3; 
          } 
        } else {
          paramInt1 = (m - k - i1 - i6) / 2 + paramInt4 + layoutParams.topMargin - layoutParams.bottomMargin;
        } 
        int i3 = paramInt2;
        if (hasDividerBeforeChildAt(i2))
          i3 = paramInt2 + this.mDividerWidth; 
        paramInt2 = layoutParams.leftMargin + i3;
        setChildFrame(view, paramInt2 + getLocationOffset(view), paramInt1, i5, i6);
        paramInt1 = layoutParams.rightMargin;
        i3 = getNextLocationOffset(view);
        i += getChildrenSkipCount(view, i2);
        paramInt2 += i5 + paramInt1 + i3;
      } 
      i++;
    } 
  }
  
  void layoutVertical(int paramInt1, int paramInt2, int paramInt3, int paramInt4) {
    int i = getPaddingLeft();
    int j = paramInt3 - paramInt1;
    int k = getPaddingRight();
    int m = getPaddingRight();
    int n = getVirtualChildCount();
    int i1 = this.mGravity;
    paramInt1 = i1 & 0x70;
    if (paramInt1 != 16) {
      if (paramInt1 != 80) {
        paramInt1 = getPaddingTop();
      } else {
        paramInt1 = getPaddingTop() + paramInt4 - paramInt2 - this.mTotalLength;
      } 
    } else {
      paramInt1 = getPaddingTop() + (paramInt4 - paramInt2 - this.mTotalLength) / 2;
    } 
    paramInt2 = 0;
    while (paramInt2 < n) {
      View view = getVirtualChildAt(paramInt2);
      if (view == null) {
        paramInt3 = paramInt1 + measureNullChild(paramInt2);
        paramInt4 = paramInt2;
      } else {
        paramInt3 = paramInt1;
        paramInt4 = paramInt2;
        if (view.getVisibility() != 8) {
          int i3 = view.getMeasuredWidth();
          int i2 = view.getMeasuredHeight();
          LayoutParams layoutParams = (LayoutParams)view.getLayoutParams();
          paramInt4 = layoutParams.gravity;
          paramInt3 = paramInt4;
          if (paramInt4 < 0)
            paramInt3 = i1 & 0x800007; 
          paramInt3 = GravityCompat.getAbsoluteGravity(paramInt3, ViewCompat.getLayoutDirection((View)this)) & 0x7;
          if (paramInt3 != 1) {
            if (paramInt3 != 5) {
              paramInt3 = layoutParams.leftMargin + i;
            } else {
              paramInt3 = j - k - i3;
              paramInt4 = layoutParams.rightMargin;
              paramInt3 -= paramInt4;
            } 
          } else {
            paramInt3 = (j - i - m - i3) / 2 + i + layoutParams.leftMargin;
            paramInt4 = layoutParams.rightMargin;
            paramInt3 -= paramInt4;
          } 
          paramInt4 = paramInt1;
          if (hasDividerBeforeChildAt(paramInt2))
            paramInt4 = paramInt1 + this.mDividerHeight; 
          paramInt1 = paramInt4 + layoutParams.topMargin;
          setChildFrame(view, paramInt3, paramInt1 + getLocationOffset(view), i3, i2);
          paramInt3 = layoutParams.bottomMargin;
          i3 = getNextLocationOffset(view);
          paramInt4 = paramInt2 + getChildrenSkipCount(view, paramInt2);
          paramInt3 = paramInt1 + i2 + paramInt3 + i3;
        } 
      } 
      paramInt2 = paramInt4 + 1;
      paramInt1 = paramInt3;
    } 
  }
  
  void measureChildBeforeLayout(View paramView, int paramInt1, int paramInt2, int paramInt3, int paramInt4, int paramInt5) {
    measureChildWithMargins(paramView, paramInt2, paramInt3, paramInt4, paramInt5);
  }
  
  void measureHorizontal(int paramInt1, int paramInt2) {
    // Byte code:
    //   0: aload_0
    //   1: iconst_0
    //   2: putfield mTotalLength : I
    //   5: aload_0
    //   6: invokevirtual getVirtualChildCount : ()I
    //   9: istore #16
    //   11: iload_1
    //   12: invokestatic getMode : (I)I
    //   15: istore #22
    //   17: iload_2
    //   18: invokestatic getMode : (I)I
    //   21: istore #21
    //   23: aload_0
    //   24: getfield mMaxAscent : [I
    //   27: ifnull -> 37
    //   30: aload_0
    //   31: getfield mMaxDescent : [I
    //   34: ifnonnull -> 51
    //   37: aload_0
    //   38: iconst_4
    //   39: newarray int
    //   41: putfield mMaxAscent : [I
    //   44: aload_0
    //   45: iconst_4
    //   46: newarray int
    //   48: putfield mMaxDescent : [I
    //   51: aload_0
    //   52: getfield mMaxAscent : [I
    //   55: astore #28
    //   57: aload_0
    //   58: getfield mMaxDescent : [I
    //   61: astore #26
    //   63: aload #28
    //   65: iconst_3
    //   66: iconst_m1
    //   67: iastore
    //   68: aload #28
    //   70: iconst_2
    //   71: iconst_m1
    //   72: iastore
    //   73: aload #28
    //   75: iconst_1
    //   76: iconst_m1
    //   77: iastore
    //   78: aload #28
    //   80: iconst_0
    //   81: iconst_m1
    //   82: iastore
    //   83: aload #26
    //   85: iconst_3
    //   86: iconst_m1
    //   87: iastore
    //   88: aload #26
    //   90: iconst_2
    //   91: iconst_m1
    //   92: iastore
    //   93: aload #26
    //   95: iconst_1
    //   96: iconst_m1
    //   97: iastore
    //   98: aload #26
    //   100: iconst_0
    //   101: iconst_m1
    //   102: iastore
    //   103: aload_0
    //   104: getfield mBaselineAligned : Z
    //   107: istore #24
    //   109: aload_0
    //   110: getfield mUseLargestChild : Z
    //   113: istore #25
    //   115: iload #22
    //   117: ldc 1073741824
    //   119: if_icmpne -> 128
    //   122: iconst_1
    //   123: istore #15
    //   125: goto -> 131
    //   128: iconst_0
    //   129: istore #15
    //   131: fconst_0
    //   132: fstore_3
    //   133: iconst_0
    //   134: istore #8
    //   136: iconst_0
    //   137: istore #7
    //   139: iconst_0
    //   140: istore #13
    //   142: iconst_0
    //   143: istore #6
    //   145: iconst_0
    //   146: istore #11
    //   148: iconst_0
    //   149: istore #12
    //   151: iconst_0
    //   152: istore #9
    //   154: iconst_1
    //   155: istore #5
    //   157: iconst_0
    //   158: istore #10
    //   160: iload #8
    //   162: iload #16
    //   164: if_icmpge -> 845
    //   167: aload_0
    //   168: iload #8
    //   170: invokevirtual getVirtualChildAt : (I)Landroid/view/View;
    //   173: astore #27
    //   175: aload #27
    //   177: ifnonnull -> 198
    //   180: aload_0
    //   181: aload_0
    //   182: getfield mTotalLength : I
    //   185: aload_0
    //   186: iload #8
    //   188: invokevirtual measureNullChild : (I)I
    //   191: iadd
    //   192: putfield mTotalLength : I
    //   195: goto -> 836
    //   198: aload #27
    //   200: invokevirtual getVisibility : ()I
    //   203: bipush #8
    //   205: if_icmpne -> 224
    //   208: iload #8
    //   210: aload_0
    //   211: aload #27
    //   213: iload #8
    //   215: invokevirtual getChildrenSkipCount : (Landroid/view/View;I)I
    //   218: iadd
    //   219: istore #8
    //   221: goto -> 195
    //   224: aload_0
    //   225: iload #8
    //   227: invokevirtual hasDividerBeforeChildAt : (I)Z
    //   230: ifeq -> 246
    //   233: aload_0
    //   234: aload_0
    //   235: getfield mTotalLength : I
    //   238: aload_0
    //   239: getfield mDividerWidth : I
    //   242: iadd
    //   243: putfield mTotalLength : I
    //   246: aload #27
    //   248: invokevirtual getLayoutParams : ()Landroid/view/ViewGroup$LayoutParams;
    //   251: checkcast androidx/appcompat/widget/LinearLayoutCompat$LayoutParams
    //   254: astore #29
    //   256: aload #29
    //   258: getfield weight : F
    //   261: fstore #4
    //   263: fload_3
    //   264: fload #4
    //   266: fadd
    //   267: fstore_3
    //   268: iload #22
    //   270: ldc 1073741824
    //   272: if_icmpne -> 381
    //   275: aload #29
    //   277: getfield width : I
    //   280: ifne -> 381
    //   283: fload #4
    //   285: fconst_0
    //   286: fcmpl
    //   287: ifle -> 381
    //   290: iload #15
    //   292: ifeq -> 318
    //   295: aload_0
    //   296: aload_0
    //   297: getfield mTotalLength : I
    //   300: aload #29
    //   302: getfield leftMargin : I
    //   305: aload #29
    //   307: getfield rightMargin : I
    //   310: iadd
    //   311: iadd
    //   312: putfield mTotalLength : I
    //   315: goto -> 347
    //   318: aload_0
    //   319: getfield mTotalLength : I
    //   322: istore #14
    //   324: aload_0
    //   325: iload #14
    //   327: aload #29
    //   329: getfield leftMargin : I
    //   332: iload #14
    //   334: iadd
    //   335: aload #29
    //   337: getfield rightMargin : I
    //   340: iadd
    //   341: invokestatic max : (II)I
    //   344: putfield mTotalLength : I
    //   347: iload #24
    //   349: ifeq -> 375
    //   352: iconst_0
    //   353: iconst_0
    //   354: invokestatic makeMeasureSpec : (II)I
    //   357: istore #14
    //   359: aload #27
    //   361: iload #14
    //   363: iload #14
    //   365: invokevirtual measure : (II)V
    //   368: iload #7
    //   370: istore #14
    //   372: goto -> 562
    //   375: iconst_1
    //   376: istore #12
    //   378: goto -> 566
    //   381: aload #29
    //   383: getfield width : I
    //   386: ifne -> 409
    //   389: fload #4
    //   391: fconst_0
    //   392: fcmpl
    //   393: ifle -> 409
    //   396: aload #29
    //   398: bipush #-2
    //   400: putfield width : I
    //   403: iconst_0
    //   404: istore #14
    //   406: goto -> 414
    //   409: ldc_w -2147483648
    //   412: istore #14
    //   414: fload_3
    //   415: fconst_0
    //   416: fcmpl
    //   417: ifne -> 429
    //   420: aload_0
    //   421: getfield mTotalLength : I
    //   424: istore #17
    //   426: goto -> 432
    //   429: iconst_0
    //   430: istore #17
    //   432: aload_0
    //   433: aload #27
    //   435: iload #8
    //   437: iload_1
    //   438: iload #17
    //   440: iload_2
    //   441: iconst_0
    //   442: invokevirtual measureChildBeforeLayout : (Landroid/view/View;IIIII)V
    //   445: iload #14
    //   447: ldc_w -2147483648
    //   450: if_icmpeq -> 460
    //   453: aload #29
    //   455: iload #14
    //   457: putfield width : I
    //   460: aload #27
    //   462: invokevirtual getMeasuredWidth : ()I
    //   465: istore #17
    //   467: iload #15
    //   469: ifeq -> 505
    //   472: aload_0
    //   473: aload_0
    //   474: getfield mTotalLength : I
    //   477: aload #29
    //   479: getfield leftMargin : I
    //   482: iload #17
    //   484: iadd
    //   485: aload #29
    //   487: getfield rightMargin : I
    //   490: iadd
    //   491: aload_0
    //   492: aload #27
    //   494: invokevirtual getNextLocationOffset : (Landroid/view/View;)I
    //   497: iadd
    //   498: iadd
    //   499: putfield mTotalLength : I
    //   502: goto -> 544
    //   505: aload_0
    //   506: getfield mTotalLength : I
    //   509: istore #14
    //   511: aload_0
    //   512: iload #14
    //   514: iload #14
    //   516: iload #17
    //   518: iadd
    //   519: aload #29
    //   521: getfield leftMargin : I
    //   524: iadd
    //   525: aload #29
    //   527: getfield rightMargin : I
    //   530: iadd
    //   531: aload_0
    //   532: aload #27
    //   534: invokevirtual getNextLocationOffset : (Landroid/view/View;)I
    //   537: iadd
    //   538: invokestatic max : (II)I
    //   541: putfield mTotalLength : I
    //   544: iload #7
    //   546: istore #14
    //   548: iload #25
    //   550: ifeq -> 562
    //   553: iload #17
    //   555: iload #7
    //   557: invokestatic max : (II)I
    //   560: istore #14
    //   562: iload #14
    //   564: istore #7
    //   566: iload #8
    //   568: istore #18
    //   570: iload #21
    //   572: ldc 1073741824
    //   574: if_icmpeq -> 595
    //   577: aload #29
    //   579: getfield height : I
    //   582: iconst_m1
    //   583: if_icmpne -> 595
    //   586: iconst_1
    //   587: istore #8
    //   589: iconst_1
    //   590: istore #10
    //   592: goto -> 598
    //   595: iconst_0
    //   596: istore #8
    //   598: aload #29
    //   600: getfield topMargin : I
    //   603: aload #29
    //   605: getfield bottomMargin : I
    //   608: iadd
    //   609: istore #14
    //   611: aload #27
    //   613: invokevirtual getMeasuredHeight : ()I
    //   616: iload #14
    //   618: iadd
    //   619: istore #17
    //   621: iload #9
    //   623: aload #27
    //   625: invokevirtual getMeasuredState : ()I
    //   628: invokestatic combineMeasuredStates : (II)I
    //   631: istore #19
    //   633: iload #24
    //   635: ifeq -> 720
    //   638: aload #27
    //   640: invokevirtual getBaseline : ()I
    //   643: istore #23
    //   645: iload #23
    //   647: iconst_m1
    //   648: if_icmpeq -> 720
    //   651: aload #29
    //   653: getfield gravity : I
    //   656: istore #20
    //   658: iload #20
    //   660: istore #9
    //   662: iload #20
    //   664: ifge -> 673
    //   667: aload_0
    //   668: getfield mGravity : I
    //   671: istore #9
    //   673: iload #9
    //   675: bipush #112
    //   677: iand
    //   678: iconst_4
    //   679: ishr
    //   680: bipush #-2
    //   682: iand
    //   683: iconst_1
    //   684: ishr
    //   685: istore #9
    //   687: aload #28
    //   689: iload #9
    //   691: aload #28
    //   693: iload #9
    //   695: iaload
    //   696: iload #23
    //   698: invokestatic max : (II)I
    //   701: iastore
    //   702: aload #26
    //   704: iload #9
    //   706: aload #26
    //   708: iload #9
    //   710: iaload
    //   711: iload #17
    //   713: iload #23
    //   715: isub
    //   716: invokestatic max : (II)I
    //   719: iastore
    //   720: iload #13
    //   722: iload #17
    //   724: invokestatic max : (II)I
    //   727: istore #13
    //   729: iload #5
    //   731: ifeq -> 749
    //   734: aload #29
    //   736: getfield height : I
    //   739: iconst_m1
    //   740: if_icmpne -> 749
    //   743: iconst_1
    //   744: istore #5
    //   746: goto -> 752
    //   749: iconst_0
    //   750: istore #5
    //   752: aload #29
    //   754: getfield weight : F
    //   757: fconst_0
    //   758: fcmpl
    //   759: ifle -> 786
    //   762: iload #8
    //   764: ifeq -> 770
    //   767: goto -> 774
    //   770: iload #17
    //   772: istore #14
    //   774: iload #11
    //   776: iload #14
    //   778: invokestatic max : (II)I
    //   781: istore #8
    //   783: goto -> 811
    //   786: iload #8
    //   788: ifeq -> 794
    //   791: goto -> 798
    //   794: iload #17
    //   796: istore #14
    //   798: iload #6
    //   800: iload #14
    //   802: invokestatic max : (II)I
    //   805: istore #6
    //   807: iload #11
    //   809: istore #8
    //   811: aload_0
    //   812: aload #27
    //   814: iload #18
    //   816: invokevirtual getChildrenSkipCount : (Landroid/view/View;I)I
    //   819: iload #18
    //   821: iadd
    //   822: istore #14
    //   824: iload #19
    //   826: istore #9
    //   828: iload #8
    //   830: istore #11
    //   832: iload #14
    //   834: istore #8
    //   836: iload #8
    //   838: iconst_1
    //   839: iadd
    //   840: istore #8
    //   842: goto -> 160
    //   845: aload_0
    //   846: getfield mTotalLength : I
    //   849: ifle -> 874
    //   852: aload_0
    //   853: iload #16
    //   855: invokevirtual hasDividerBeforeChildAt : (I)Z
    //   858: ifeq -> 874
    //   861: aload_0
    //   862: aload_0
    //   863: getfield mTotalLength : I
    //   866: aload_0
    //   867: getfield mDividerWidth : I
    //   870: iadd
    //   871: putfield mTotalLength : I
    //   874: aload #28
    //   876: iconst_1
    //   877: iaload
    //   878: iconst_m1
    //   879: if_icmpne -> 916
    //   882: aload #28
    //   884: iconst_0
    //   885: iaload
    //   886: iconst_m1
    //   887: if_icmpne -> 916
    //   890: aload #28
    //   892: iconst_2
    //   893: iaload
    //   894: iconst_m1
    //   895: if_icmpne -> 916
    //   898: aload #28
    //   900: iconst_3
    //   901: iaload
    //   902: iconst_m1
    //   903: if_icmpeq -> 909
    //   906: goto -> 916
    //   909: iload #13
    //   911: istore #8
    //   913: goto -> 974
    //   916: iload #13
    //   918: aload #28
    //   920: iconst_3
    //   921: iaload
    //   922: aload #28
    //   924: iconst_0
    //   925: iaload
    //   926: aload #28
    //   928: iconst_1
    //   929: iaload
    //   930: aload #28
    //   932: iconst_2
    //   933: iaload
    //   934: invokestatic max : (II)I
    //   937: invokestatic max : (II)I
    //   940: invokestatic max : (II)I
    //   943: aload #26
    //   945: iconst_3
    //   946: iaload
    //   947: aload #26
    //   949: iconst_0
    //   950: iaload
    //   951: aload #26
    //   953: iconst_1
    //   954: iaload
    //   955: aload #26
    //   957: iconst_2
    //   958: iaload
    //   959: invokestatic max : (II)I
    //   962: invokestatic max : (II)I
    //   965: invokestatic max : (II)I
    //   968: iadd
    //   969: invokestatic max : (II)I
    //   972: istore #8
    //   974: iload #9
    //   976: istore #13
    //   978: iload #8
    //   980: istore #14
    //   982: iload #25
    //   984: ifeq -> 1176
    //   987: iload #22
    //   989: ldc_w -2147483648
    //   992: if_icmpeq -> 1004
    //   995: iload #8
    //   997: istore #14
    //   999: iload #22
    //   1001: ifne -> 1176
    //   1004: aload_0
    //   1005: iconst_0
    //   1006: putfield mTotalLength : I
    //   1009: iconst_0
    //   1010: istore #9
    //   1012: iload #8
    //   1014: istore #14
    //   1016: iload #9
    //   1018: iload #16
    //   1020: if_icmpge -> 1176
    //   1023: aload_0
    //   1024: iload #9
    //   1026: invokevirtual getVirtualChildAt : (I)Landroid/view/View;
    //   1029: astore #27
    //   1031: aload #27
    //   1033: ifnonnull -> 1054
    //   1036: aload_0
    //   1037: aload_0
    //   1038: getfield mTotalLength : I
    //   1041: aload_0
    //   1042: iload #9
    //   1044: invokevirtual measureNullChild : (I)I
    //   1047: iadd
    //   1048: putfield mTotalLength : I
    //   1051: goto -> 1077
    //   1054: aload #27
    //   1056: invokevirtual getVisibility : ()I
    //   1059: bipush #8
    //   1061: if_icmpne -> 1080
    //   1064: iload #9
    //   1066: aload_0
    //   1067: aload #27
    //   1069: iload #9
    //   1071: invokevirtual getChildrenSkipCount : (Landroid/view/View;I)I
    //   1074: iadd
    //   1075: istore #9
    //   1077: goto -> 1167
    //   1080: aload #27
    //   1082: invokevirtual getLayoutParams : ()Landroid/view/ViewGroup$LayoutParams;
    //   1085: checkcast androidx/appcompat/widget/LinearLayoutCompat$LayoutParams
    //   1088: astore #29
    //   1090: iload #15
    //   1092: ifeq -> 1128
    //   1095: aload_0
    //   1096: aload_0
    //   1097: getfield mTotalLength : I
    //   1100: aload #29
    //   1102: getfield leftMargin : I
    //   1105: iload #7
    //   1107: iadd
    //   1108: aload #29
    //   1110: getfield rightMargin : I
    //   1113: iadd
    //   1114: aload_0
    //   1115: aload #27
    //   1117: invokevirtual getNextLocationOffset : (Landroid/view/View;)I
    //   1120: iadd
    //   1121: iadd
    //   1122: putfield mTotalLength : I
    //   1125: goto -> 1077
    //   1128: aload_0
    //   1129: getfield mTotalLength : I
    //   1132: istore #14
    //   1134: aload_0
    //   1135: iload #14
    //   1137: iload #14
    //   1139: iload #7
    //   1141: iadd
    //   1142: aload #29
    //   1144: getfield leftMargin : I
    //   1147: iadd
    //   1148: aload #29
    //   1150: getfield rightMargin : I
    //   1153: iadd
    //   1154: aload_0
    //   1155: aload #27
    //   1157: invokevirtual getNextLocationOffset : (Landroid/view/View;)I
    //   1160: iadd
    //   1161: invokestatic max : (II)I
    //   1164: putfield mTotalLength : I
    //   1167: iload #9
    //   1169: iconst_1
    //   1170: iadd
    //   1171: istore #9
    //   1173: goto -> 1012
    //   1176: aload_0
    //   1177: getfield mTotalLength : I
    //   1180: aload_0
    //   1181: invokevirtual getPaddingLeft : ()I
    //   1184: aload_0
    //   1185: invokevirtual getPaddingRight : ()I
    //   1188: iadd
    //   1189: iadd
    //   1190: istore #8
    //   1192: aload_0
    //   1193: iload #8
    //   1195: putfield mTotalLength : I
    //   1198: iload #8
    //   1200: aload_0
    //   1201: invokevirtual getSuggestedMinimumWidth : ()I
    //   1204: invokestatic max : (II)I
    //   1207: iload_1
    //   1208: iconst_0
    //   1209: invokestatic resolveSizeAndState : (III)I
    //   1212: istore #18
    //   1214: ldc_w 16777215
    //   1217: iload #18
    //   1219: iand
    //   1220: aload_0
    //   1221: getfield mTotalLength : I
    //   1224: isub
    //   1225: istore #17
    //   1227: iload #12
    //   1229: ifne -> 1365
    //   1232: iload #17
    //   1234: ifeq -> 1246
    //   1237: fload_3
    //   1238: fconst_0
    //   1239: fcmpl
    //   1240: ifle -> 1246
    //   1243: goto -> 1365
    //   1246: iload #6
    //   1248: iload #11
    //   1250: invokestatic max : (II)I
    //   1253: istore #9
    //   1255: iload #25
    //   1257: ifeq -> 1350
    //   1260: iload #22
    //   1262: ldc 1073741824
    //   1264: if_icmpeq -> 1350
    //   1267: iconst_0
    //   1268: istore #6
    //   1270: iload #6
    //   1272: iload #16
    //   1274: if_icmpge -> 1350
    //   1277: aload_0
    //   1278: iload #6
    //   1280: invokevirtual getVirtualChildAt : (I)Landroid/view/View;
    //   1283: astore #26
    //   1285: aload #26
    //   1287: ifnull -> 1341
    //   1290: aload #26
    //   1292: invokevirtual getVisibility : ()I
    //   1295: bipush #8
    //   1297: if_icmpne -> 1303
    //   1300: goto -> 1341
    //   1303: aload #26
    //   1305: invokevirtual getLayoutParams : ()Landroid/view/ViewGroup$LayoutParams;
    //   1308: checkcast androidx/appcompat/widget/LinearLayoutCompat$LayoutParams
    //   1311: getfield weight : F
    //   1314: fconst_0
    //   1315: fcmpl
    //   1316: ifle -> 1341
    //   1319: aload #26
    //   1321: iload #7
    //   1323: ldc 1073741824
    //   1325: invokestatic makeMeasureSpec : (II)I
    //   1328: aload #26
    //   1330: invokevirtual getMeasuredHeight : ()I
    //   1333: ldc 1073741824
    //   1335: invokestatic makeMeasureSpec : (II)I
    //   1338: invokevirtual measure : (II)V
    //   1341: iload #6
    //   1343: iconst_1
    //   1344: iadd
    //   1345: istore #6
    //   1347: goto -> 1270
    //   1350: iload #16
    //   1352: istore #8
    //   1354: iload #14
    //   1356: istore #7
    //   1358: iload #9
    //   1360: istore #6
    //   1362: goto -> 2106
    //   1365: aload_0
    //   1366: getfield mWeightSum : F
    //   1369: fstore #4
    //   1371: fload #4
    //   1373: fconst_0
    //   1374: fcmpl
    //   1375: ifle -> 1381
    //   1378: fload #4
    //   1380: fstore_3
    //   1381: aload #28
    //   1383: iconst_3
    //   1384: iconst_m1
    //   1385: iastore
    //   1386: aload #28
    //   1388: iconst_2
    //   1389: iconst_m1
    //   1390: iastore
    //   1391: aload #28
    //   1393: iconst_1
    //   1394: iconst_m1
    //   1395: iastore
    //   1396: aload #28
    //   1398: iconst_0
    //   1399: iconst_m1
    //   1400: iastore
    //   1401: aload #26
    //   1403: iconst_3
    //   1404: iconst_m1
    //   1405: iastore
    //   1406: aload #26
    //   1408: iconst_2
    //   1409: iconst_m1
    //   1410: iastore
    //   1411: aload #26
    //   1413: iconst_1
    //   1414: iconst_m1
    //   1415: iastore
    //   1416: aload #26
    //   1418: iconst_0
    //   1419: iconst_m1
    //   1420: iastore
    //   1421: aload_0
    //   1422: iconst_0
    //   1423: putfield mTotalLength : I
    //   1426: iload #13
    //   1428: istore #9
    //   1430: iconst_m1
    //   1431: istore #11
    //   1433: iconst_0
    //   1434: istore #13
    //   1436: iload #5
    //   1438: istore #8
    //   1440: iload #16
    //   1442: istore #7
    //   1444: iload #9
    //   1446: istore #5
    //   1448: iload #6
    //   1450: istore #9
    //   1452: iload #17
    //   1454: istore #6
    //   1456: iload #13
    //   1458: iload #7
    //   1460: if_icmpge -> 1968
    //   1463: aload_0
    //   1464: iload #13
    //   1466: invokevirtual getVirtualChildAt : (I)Landroid/view/View;
    //   1469: astore #27
    //   1471: aload #27
    //   1473: ifnull -> 1959
    //   1476: aload #27
    //   1478: invokevirtual getVisibility : ()I
    //   1481: bipush #8
    //   1483: if_icmpne -> 1489
    //   1486: goto -> 1959
    //   1489: aload #27
    //   1491: invokevirtual getLayoutParams : ()Landroid/view/ViewGroup$LayoutParams;
    //   1494: checkcast androidx/appcompat/widget/LinearLayoutCompat$LayoutParams
    //   1497: astore #29
    //   1499: aload #29
    //   1501: getfield weight : F
    //   1504: fstore #4
    //   1506: fload #4
    //   1508: fconst_0
    //   1509: fcmpl
    //   1510: ifle -> 1673
    //   1513: iload #6
    //   1515: i2f
    //   1516: fload #4
    //   1518: fmul
    //   1519: fload_3
    //   1520: fdiv
    //   1521: f2i
    //   1522: istore #14
    //   1524: iload_2
    //   1525: aload_0
    //   1526: invokevirtual getPaddingTop : ()I
    //   1529: aload_0
    //   1530: invokevirtual getPaddingBottom : ()I
    //   1533: iadd
    //   1534: aload #29
    //   1536: getfield topMargin : I
    //   1539: iadd
    //   1540: aload #29
    //   1542: getfield bottomMargin : I
    //   1545: iadd
    //   1546: aload #29
    //   1548: getfield height : I
    //   1551: invokestatic getChildMeasureSpec : (III)I
    //   1554: istore #17
    //   1556: aload #29
    //   1558: getfield width : I
    //   1561: ifne -> 1606
    //   1564: iload #22
    //   1566: ldc 1073741824
    //   1568: if_icmpeq -> 1574
    //   1571: goto -> 1606
    //   1574: iload #14
    //   1576: ifle -> 1586
    //   1579: iload #14
    //   1581: istore #12
    //   1583: goto -> 1589
    //   1586: iconst_0
    //   1587: istore #12
    //   1589: aload #27
    //   1591: iload #12
    //   1593: ldc 1073741824
    //   1595: invokestatic makeMeasureSpec : (II)I
    //   1598: iload #17
    //   1600: invokevirtual measure : (II)V
    //   1603: goto -> 1642
    //   1606: aload #27
    //   1608: invokevirtual getMeasuredWidth : ()I
    //   1611: iload #14
    //   1613: iadd
    //   1614: istore #16
    //   1616: iload #16
    //   1618: istore #12
    //   1620: iload #16
    //   1622: ifge -> 1628
    //   1625: iconst_0
    //   1626: istore #12
    //   1628: aload #27
    //   1630: iload #12
    //   1632: ldc 1073741824
    //   1634: invokestatic makeMeasureSpec : (II)I
    //   1637: iload #17
    //   1639: invokevirtual measure : (II)V
    //   1642: iload #5
    //   1644: aload #27
    //   1646: invokevirtual getMeasuredState : ()I
    //   1649: ldc_w -16777216
    //   1652: iand
    //   1653: invokestatic combineMeasuredStates : (II)I
    //   1656: istore #5
    //   1658: fload_3
    //   1659: fload #4
    //   1661: fsub
    //   1662: fstore_3
    //   1663: iload #6
    //   1665: iload #14
    //   1667: isub
    //   1668: istore #6
    //   1670: goto -> 1673
    //   1673: iload #15
    //   1675: ifeq -> 1714
    //   1678: aload_0
    //   1679: aload_0
    //   1680: getfield mTotalLength : I
    //   1683: aload #27
    //   1685: invokevirtual getMeasuredWidth : ()I
    //   1688: aload #29
    //   1690: getfield leftMargin : I
    //   1693: iadd
    //   1694: aload #29
    //   1696: getfield rightMargin : I
    //   1699: iadd
    //   1700: aload_0
    //   1701: aload #27
    //   1703: invokevirtual getNextLocationOffset : (Landroid/view/View;)I
    //   1706: iadd
    //   1707: iadd
    //   1708: putfield mTotalLength : I
    //   1711: goto -> 1756
    //   1714: aload_0
    //   1715: getfield mTotalLength : I
    //   1718: istore #12
    //   1720: aload_0
    //   1721: iload #12
    //   1723: aload #27
    //   1725: invokevirtual getMeasuredWidth : ()I
    //   1728: iload #12
    //   1730: iadd
    //   1731: aload #29
    //   1733: getfield leftMargin : I
    //   1736: iadd
    //   1737: aload #29
    //   1739: getfield rightMargin : I
    //   1742: iadd
    //   1743: aload_0
    //   1744: aload #27
    //   1746: invokevirtual getNextLocationOffset : (Landroid/view/View;)I
    //   1749: iadd
    //   1750: invokestatic max : (II)I
    //   1753: putfield mTotalLength : I
    //   1756: iload #21
    //   1758: ldc 1073741824
    //   1760: if_icmpeq -> 1778
    //   1763: aload #29
    //   1765: getfield height : I
    //   1768: iconst_m1
    //   1769: if_icmpne -> 1778
    //   1772: iconst_1
    //   1773: istore #12
    //   1775: goto -> 1781
    //   1778: iconst_0
    //   1779: istore #12
    //   1781: aload #29
    //   1783: getfield topMargin : I
    //   1786: aload #29
    //   1788: getfield bottomMargin : I
    //   1791: iadd
    //   1792: istore #17
    //   1794: aload #27
    //   1796: invokevirtual getMeasuredHeight : ()I
    //   1799: iload #17
    //   1801: iadd
    //   1802: istore #16
    //   1804: iload #11
    //   1806: iload #16
    //   1808: invokestatic max : (II)I
    //   1811: istore #14
    //   1813: iload #12
    //   1815: ifeq -> 1825
    //   1818: iload #17
    //   1820: istore #11
    //   1822: goto -> 1829
    //   1825: iload #16
    //   1827: istore #11
    //   1829: iload #9
    //   1831: iload #11
    //   1833: invokestatic max : (II)I
    //   1836: istore #11
    //   1838: iload #8
    //   1840: ifeq -> 1858
    //   1843: aload #29
    //   1845: getfield height : I
    //   1848: iconst_m1
    //   1849: if_icmpne -> 1858
    //   1852: iconst_1
    //   1853: istore #8
    //   1855: goto -> 1861
    //   1858: iconst_0
    //   1859: istore #8
    //   1861: iload #24
    //   1863: ifeq -> 1948
    //   1866: aload #27
    //   1868: invokevirtual getBaseline : ()I
    //   1871: istore #17
    //   1873: iload #17
    //   1875: iconst_m1
    //   1876: if_icmpeq -> 1948
    //   1879: aload #29
    //   1881: getfield gravity : I
    //   1884: istore #12
    //   1886: iload #12
    //   1888: istore #9
    //   1890: iload #12
    //   1892: ifge -> 1901
    //   1895: aload_0
    //   1896: getfield mGravity : I
    //   1899: istore #9
    //   1901: iload #9
    //   1903: bipush #112
    //   1905: iand
    //   1906: iconst_4
    //   1907: ishr
    //   1908: bipush #-2
    //   1910: iand
    //   1911: iconst_1
    //   1912: ishr
    //   1913: istore #9
    //   1915: aload #28
    //   1917: iload #9
    //   1919: aload #28
    //   1921: iload #9
    //   1923: iaload
    //   1924: iload #17
    //   1926: invokestatic max : (II)I
    //   1929: iastore
    //   1930: aload #26
    //   1932: iload #9
    //   1934: aload #26
    //   1936: iload #9
    //   1938: iaload
    //   1939: iload #16
    //   1941: iload #17
    //   1943: isub
    //   1944: invokestatic max : (II)I
    //   1947: iastore
    //   1948: iload #11
    //   1950: istore #9
    //   1952: iload #14
    //   1954: istore #11
    //   1956: goto -> 1959
    //   1959: iload #13
    //   1961: iconst_1
    //   1962: iadd
    //   1963: istore #13
    //   1965: goto -> 1456
    //   1968: aload_0
    //   1969: aload_0
    //   1970: getfield mTotalLength : I
    //   1973: aload_0
    //   1974: invokevirtual getPaddingLeft : ()I
    //   1977: aload_0
    //   1978: invokevirtual getPaddingRight : ()I
    //   1981: iadd
    //   1982: iadd
    //   1983: putfield mTotalLength : I
    //   1986: aload #28
    //   1988: iconst_1
    //   1989: iaload
    //   1990: iconst_m1
    //   1991: if_icmpne -> 2028
    //   1994: aload #28
    //   1996: iconst_0
    //   1997: iaload
    //   1998: iconst_m1
    //   1999: if_icmpne -> 2028
    //   2002: aload #28
    //   2004: iconst_2
    //   2005: iaload
    //   2006: iconst_m1
    //   2007: if_icmpne -> 2028
    //   2010: aload #28
    //   2012: iconst_3
    //   2013: iaload
    //   2014: iconst_m1
    //   2015: if_icmpeq -> 2021
    //   2018: goto -> 2028
    //   2021: iload #11
    //   2023: istore #6
    //   2025: goto -> 2086
    //   2028: iload #11
    //   2030: aload #28
    //   2032: iconst_3
    //   2033: iaload
    //   2034: aload #28
    //   2036: iconst_0
    //   2037: iaload
    //   2038: aload #28
    //   2040: iconst_1
    //   2041: iaload
    //   2042: aload #28
    //   2044: iconst_2
    //   2045: iaload
    //   2046: invokestatic max : (II)I
    //   2049: invokestatic max : (II)I
    //   2052: invokestatic max : (II)I
    //   2055: aload #26
    //   2057: iconst_3
    //   2058: iaload
    //   2059: aload #26
    //   2061: iconst_0
    //   2062: iaload
    //   2063: aload #26
    //   2065: iconst_1
    //   2066: iaload
    //   2067: aload #26
    //   2069: iconst_2
    //   2070: iaload
    //   2071: invokestatic max : (II)I
    //   2074: invokestatic max : (II)I
    //   2077: invokestatic max : (II)I
    //   2080: iadd
    //   2081: invokestatic max : (II)I
    //   2084: istore #6
    //   2086: iload #5
    //   2088: istore #13
    //   2090: iload #8
    //   2092: istore #5
    //   2094: iload #7
    //   2096: istore #8
    //   2098: iload #6
    //   2100: istore #7
    //   2102: iload #9
    //   2104: istore #6
    //   2106: iload #5
    //   2108: ifne -> 2121
    //   2111: iload #21
    //   2113: ldc 1073741824
    //   2115: if_icmpeq -> 2121
    //   2118: goto -> 2125
    //   2121: iload #7
    //   2123: istore #6
    //   2125: aload_0
    //   2126: iload #18
    //   2128: iload #13
    //   2130: ldc_w -16777216
    //   2133: iand
    //   2134: ior
    //   2135: iload #6
    //   2137: aload_0
    //   2138: invokevirtual getPaddingTop : ()I
    //   2141: aload_0
    //   2142: invokevirtual getPaddingBottom : ()I
    //   2145: iadd
    //   2146: iadd
    //   2147: aload_0
    //   2148: invokevirtual getSuggestedMinimumHeight : ()I
    //   2151: invokestatic max : (II)I
    //   2154: iload_2
    //   2155: iload #13
    //   2157: bipush #16
    //   2159: ishl
    //   2160: invokestatic resolveSizeAndState : (III)I
    //   2163: invokevirtual setMeasuredDimension : (II)V
    //   2166: iload #10
    //   2168: ifeq -> 2178
    //   2171: aload_0
    //   2172: iload #8
    //   2174: iload_1
    //   2175: invokespecial forceUniformHeight : (II)V
    //   2178: return
  }
  
  int measureNullChild(int paramInt) {
    return 0;
  }
  
  void measureVertical(int paramInt1, int paramInt2) {
    this.mTotalLength = 0;
    int i2 = getVirtualChildCount();
    int i7 = View.MeasureSpec.getMode(paramInt1);
    int i5 = View.MeasureSpec.getMode(paramInt2);
    int i8 = this.mBaselineAlignedChildIndex;
    boolean bool1 = this.mUseLargestChild;
    float f = 0.0F;
    int i = 0;
    int i4 = 0;
    int n = 0;
    int j = 0;
    int m = 0;
    int i1 = 0;
    int i3 = 0;
    int k = 1;
    boolean bool = false;
    while (i1 < i2) {
      View view = getVirtualChildAt(i1);
      if (view == null) {
        this.mTotalLength += measureNullChild(i1);
      } else if (view.getVisibility() == 8) {
        i1 += getChildrenSkipCount(view, i1);
      } else {
        if (hasDividerBeforeChildAt(i1))
          this.mTotalLength += this.mDividerHeight; 
        LayoutParams layoutParams = (LayoutParams)view.getLayoutParams();
        float f1 = layoutParams.weight;
        f += f1;
        if (i5 == 1073741824 && layoutParams.height == 0 && f1 > 0.0F) {
          i3 = this.mTotalLength;
          this.mTotalLength = Math.max(i3, layoutParams.topMargin + i3 + layoutParams.bottomMargin);
          i3 = 1;
        } else {
          if (layoutParams.height == 0 && f1 > 0.0F) {
            layoutParams.height = -2;
            i10 = 0;
          } else {
            i10 = Integer.MIN_VALUE;
          } 
          if (f == 0.0F) {
            i11 = this.mTotalLength;
          } else {
            i11 = 0;
          } 
          measureChildBeforeLayout(view, i1, paramInt1, 0, paramInt2, i11);
          if (i10 != Integer.MIN_VALUE)
            layoutParams.height = i10; 
          int i10 = view.getMeasuredHeight();
          int i11 = this.mTotalLength;
          this.mTotalLength = Math.max(i11, i11 + i10 + layoutParams.topMargin + layoutParams.bottomMargin + getNextLocationOffset(view));
          if (bool1)
            n = Math.max(i10, n); 
        } 
        int i9 = i1;
        if (i8 >= 0 && i8 == i9 + 1)
          this.mBaselineChildTop = this.mTotalLength; 
        if (i9 >= i8 || layoutParams.weight <= 0.0F) {
          if (i7 != 1073741824 && layoutParams.width == -1) {
            i1 = 1;
            bool = true;
          } else {
            i1 = 0;
          } 
          int i10 = layoutParams.leftMargin + layoutParams.rightMargin;
          int i11 = view.getMeasuredWidth() + i10;
          i4 = Math.max(i4, i11);
          int i12 = View.combineMeasuredStates(i, view.getMeasuredState());
          if (k && layoutParams.width == -1) {
            i = 1;
          } else {
            i = 0;
          } 
          if (layoutParams.weight > 0.0F) {
            if (i1 == 0)
              i10 = i11; 
            j = Math.max(j, i10);
            k = m;
          } else {
            if (i1 == 0)
              i10 = i11; 
            k = Math.max(m, i10);
          } 
          i1 = getChildrenSkipCount(view, i9);
          m = k;
          i10 = i12;
          i1 += i9;
          k = i;
          i = i10;
        } else {
          throw new RuntimeException("A child of LinearLayout with index less than mBaselineAlignedChildIndex has weight > 0, which won't work.  Either remove the weight, or don't set mBaselineAlignedChildIndex.");
        } 
      } 
      i1++;
    } 
    if (this.mTotalLength > 0 && hasDividerBeforeChildAt(i2))
      this.mTotalLength += this.mDividerHeight; 
    if (bool1 && (i5 == Integer.MIN_VALUE || i5 == 0)) {
      this.mTotalLength = 0;
      for (i1 = 0; i1 < i2; i1++) {
        View view = getVirtualChildAt(i1);
        if (view == null) {
          this.mTotalLength += measureNullChild(i1);
        } else if (view.getVisibility() == 8) {
          i1 += getChildrenSkipCount(view, i1);
        } else {
          LayoutParams layoutParams = (LayoutParams)view.getLayoutParams();
          int i9 = this.mTotalLength;
          this.mTotalLength = Math.max(i9, i9 + n + layoutParams.topMargin + layoutParams.bottomMargin + getNextLocationOffset(view));
        } 
      } 
    } 
    i1 = this.mTotalLength + getPaddingTop() + getPaddingBottom();
    this.mTotalLength = i1;
    int i6 = View.resolveSizeAndState(Math.max(i1, getSuggestedMinimumHeight()), paramInt2, 0);
    i1 = (0xFFFFFF & i6) - this.mTotalLength;
    if (i3 != 0 || (i1 != 0 && f > 0.0F)) {
      float f1 = this.mWeightSum;
      if (f1 > 0.0F)
        f = f1; 
      this.mTotalLength = 0;
      j = i1;
      i1 = 0;
      n = i4;
      while (i1 < i2) {
        View view = getVirtualChildAt(i1);
        if (view.getVisibility() != 8) {
          LayoutParams layoutParams = (LayoutParams)view.getLayoutParams();
          f1 = layoutParams.weight;
          if (f1 > 0.0F) {
            i4 = (int)(j * f1 / f);
            int i10 = getPaddingLeft();
            int i11 = getPaddingRight();
            int i12 = layoutParams.leftMargin;
            i8 = layoutParams.rightMargin;
            int i13 = layoutParams.width;
            i3 = j - i4;
            i10 = ViewGroup.getChildMeasureSpec(paramInt1, i10 + i11 + i12 + i8, i13);
            if (layoutParams.height != 0 || i5 != 1073741824) {
              i4 = view.getMeasuredHeight() + i4;
              j = i4;
              if (i4 < 0)
                j = 0; 
              view.measure(i10, View.MeasureSpec.makeMeasureSpec(j, 1073741824));
            } else {
              if (i4 > 0) {
                j = i4;
              } else {
                j = 0;
              } 
              view.measure(i10, View.MeasureSpec.makeMeasureSpec(j, 1073741824));
            } 
            i = View.combineMeasuredStates(i, view.getMeasuredState() & 0xFFFFFF00);
            f -= f1;
            j = i3;
          } 
          i4 = layoutParams.leftMargin + layoutParams.rightMargin;
          int i9 = view.getMeasuredWidth() + i4;
          i3 = Math.max(n, i9);
          if (i7 != 1073741824 && layoutParams.width == -1) {
            n = 1;
          } else {
            n = 0;
          } 
          if (n != 0) {
            n = i4;
          } else {
            n = i9;
          } 
          m = Math.max(m, n);
          if (k != 0 && layoutParams.width == -1) {
            k = 1;
          } else {
            k = 0;
          } 
          n = this.mTotalLength;
          this.mTotalLength = Math.max(n, view.getMeasuredHeight() + n + layoutParams.topMargin + layoutParams.bottomMargin + getNextLocationOffset(view));
          n = i3;
        } 
        i1++;
      } 
      this.mTotalLength += getPaddingTop() + getPaddingBottom();
      j = i;
      i = m;
    } else {
      m = Math.max(m, j);
      if (bool1 && i5 != 1073741824)
        for (j = 0; j < i2; j++) {
          View view = getVirtualChildAt(j);
          if (view != null && view.getVisibility() != 8 && ((LayoutParams)view.getLayoutParams()).weight > 0.0F)
            view.measure(View.MeasureSpec.makeMeasureSpec(view.getMeasuredWidth(), 1073741824), View.MeasureSpec.makeMeasureSpec(n, 1073741824)); 
        }  
      j = i;
      i = m;
      n = i4;
    } 
    if (k != 0 || i7 == 1073741824)
      i = n; 
    setMeasuredDimension(View.resolveSizeAndState(Math.max(i + getPaddingLeft() + getPaddingRight(), getSuggestedMinimumWidth()), paramInt1, j), i6);
    if (bool)
      forceUniformWidth(i2, paramInt2); 
  }
  
  protected void onDraw(Canvas paramCanvas) {
    if (this.mDivider == null)
      return; 
    if (this.mOrientation == 1) {
      drawDividersVertical(paramCanvas);
      return;
    } 
    drawDividersHorizontal(paramCanvas);
  }
  
  public void onInitializeAccessibilityEvent(AccessibilityEvent paramAccessibilityEvent) {
    super.onInitializeAccessibilityEvent(paramAccessibilityEvent);
    paramAccessibilityEvent.setClassName("androidx.appcompat.widget.LinearLayoutCompat");
  }
  
  public void onInitializeAccessibilityNodeInfo(AccessibilityNodeInfo paramAccessibilityNodeInfo) {
    super.onInitializeAccessibilityNodeInfo(paramAccessibilityNodeInfo);
    paramAccessibilityNodeInfo.setClassName("androidx.appcompat.widget.LinearLayoutCompat");
  }
  
  protected void onLayout(boolean paramBoolean, int paramInt1, int paramInt2, int paramInt3, int paramInt4) {
    if (this.mOrientation == 1) {
      layoutVertical(paramInt1, paramInt2, paramInt3, paramInt4);
      return;
    } 
    layoutHorizontal(paramInt1, paramInt2, paramInt3, paramInt4);
  }
  
  protected void onMeasure(int paramInt1, int paramInt2) {
    if (this.mOrientation == 1) {
      measureVertical(paramInt1, paramInt2);
      return;
    } 
    measureHorizontal(paramInt1, paramInt2);
  }
  
  public void setBaselineAligned(boolean paramBoolean) {
    this.mBaselineAligned = paramBoolean;
  }
  
  public void setBaselineAlignedChildIndex(int paramInt) {
    if (paramInt >= 0 && paramInt < getChildCount()) {
      this.mBaselineAlignedChildIndex = paramInt;
      return;
    } 
    StringBuilder stringBuilder = new StringBuilder();
    stringBuilder.append("base aligned child index out of range (0, ");
    stringBuilder.append(getChildCount());
    stringBuilder.append(")");
    throw new IllegalArgumentException(stringBuilder.toString());
  }
  
  public void setDividerDrawable(Drawable paramDrawable) {
    if (paramDrawable == this.mDivider)
      return; 
    this.mDivider = paramDrawable;
    boolean bool = false;
    if (paramDrawable != null) {
      this.mDividerWidth = paramDrawable.getIntrinsicWidth();
      this.mDividerHeight = paramDrawable.getIntrinsicHeight();
    } else {
      this.mDividerWidth = 0;
      this.mDividerHeight = 0;
    } 
    if (paramDrawable == null)
      bool = true; 
    setWillNotDraw(bool);
    requestLayout();
  }
  
  public void setDividerPadding(int paramInt) {
    this.mDividerPadding = paramInt;
  }
  
  public void setGravity(int paramInt) {
    if (this.mGravity != paramInt) {
      int i = paramInt;
      if ((0x800007 & paramInt) == 0)
        i = paramInt | 0x800003; 
      paramInt = i;
      if ((i & 0x70) == 0)
        paramInt = i | 0x30; 
      this.mGravity = paramInt;
      requestLayout();
    } 
  }
  
  public void setHorizontalGravity(int paramInt) {
    paramInt &= 0x800007;
    int i = this.mGravity;
    if ((0x800007 & i) != paramInt) {
      this.mGravity = paramInt | 0xFF7FFFF8 & i;
      requestLayout();
    } 
  }
  
  public void setMeasureWithLargestChildEnabled(boolean paramBoolean) {
    this.mUseLargestChild = paramBoolean;
  }
  
  public void setOrientation(int paramInt) {
    if (this.mOrientation != paramInt) {
      this.mOrientation = paramInt;
      requestLayout();
    } 
  }
  
  public void setShowDividers(int paramInt) {
    if (paramInt != this.mShowDividers)
      requestLayout(); 
    this.mShowDividers = paramInt;
  }
  
  public void setVerticalGravity(int paramInt) {
    paramInt &= 0x70;
    int i = this.mGravity;
    if ((i & 0x70) != paramInt) {
      this.mGravity = paramInt | i & 0xFFFFFF8F;
      requestLayout();
    } 
  }
  
  public void setWeightSum(float paramFloat) {
    this.mWeightSum = Math.max(0.0F, paramFloat);
  }
  
  public boolean shouldDelayChildPressedState() {
    return false;
  }
  
  @Retention(RetentionPolicy.SOURCE)
  @RestrictTo({RestrictTo.Scope.LIBRARY_GROUP_PREFIX})
  public static @interface DividerMode {}
  
  public static class LayoutParams extends LinearLayout.LayoutParams {
    public LayoutParams(int param1Int1, int param1Int2) {
      super(param1Int1, param1Int2);
    }
    
    public LayoutParams(int param1Int1, int param1Int2, float param1Float) {
      super(param1Int1, param1Int2, param1Float);
    }
    
    public LayoutParams(Context param1Context, AttributeSet param1AttributeSet) {
      super(param1Context, param1AttributeSet);
    }
    
    public LayoutParams(ViewGroup.LayoutParams param1LayoutParams) {
      super(param1LayoutParams);
    }
    
    public LayoutParams(ViewGroup.MarginLayoutParams param1MarginLayoutParams) {
      super(param1MarginLayoutParams);
    }
  }
  
  @Retention(RetentionPolicy.SOURCE)
  @RestrictTo({RestrictTo.Scope.LIBRARY_GROUP_PREFIX})
  public static @interface OrientationMode {}
}


/* Location:              C:\soft\dex2jar-2.0\BabyBus TV_Kids Videos & Games-dex2jar.jar!\androidx\appcompat\widget\LinearLayoutCompat.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */