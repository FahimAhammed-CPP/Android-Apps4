package androidx.constraintlayout.solver.widgets;

import androidx.constraintlayout.solver.LinearSystem;
import java.util.ArrayList;
import java.util.HashMap;

public class Flow extends VirtualLayout {
  public static final int HORIZONTAL_ALIGN_CENTER = 2;
  
  public static final int HORIZONTAL_ALIGN_END = 1;
  
  public static final int HORIZONTAL_ALIGN_START = 0;
  
  public static final int VERTICAL_ALIGN_BASELINE = 3;
  
  public static final int VERTICAL_ALIGN_BOTTOM = 1;
  
  public static final int VERTICAL_ALIGN_CENTER = 2;
  
  public static final int VERTICAL_ALIGN_TOP = 0;
  
  public static final int WRAP_ALIGNED = 2;
  
  public static final int WRAP_CHAIN = 1;
  
  public static final int WRAP_NONE = 0;
  
  private ConstraintWidget[] mAlignedBiggestElementsInCols = null;
  
  private ConstraintWidget[] mAlignedBiggestElementsInRows = null;
  
  private int[] mAlignedDimensions = null;
  
  private ArrayList<WidgetsList> mChainList = new ArrayList<WidgetsList>();
  
  private ConstraintWidget[] mDisplayedWidgets;
  
  private int mDisplayedWidgetsCount = 0;
  
  private float mFirstHorizontalBias = 0.5F;
  
  private int mFirstHorizontalStyle = -1;
  
  private float mFirstVerticalBias = 0.5F;
  
  private int mFirstVerticalStyle = -1;
  
  private int mHorizontalAlign = 2;
  
  private float mHorizontalBias = 0.5F;
  
  private int mHorizontalGap = 0;
  
  private int mHorizontalStyle = -1;
  
  private float mLastHorizontalBias = 0.5F;
  
  private int mLastHorizontalStyle = -1;
  
  private float mLastVerticalBias = 0.5F;
  
  private int mLastVerticalStyle = -1;
  
  private int mMaxElementsWrap = -1;
  
  private int mOrientation = 0;
  
  private int mVerticalAlign = 2;
  
  private float mVerticalBias = 0.5F;
  
  private int mVerticalGap = 0;
  
  private int mVerticalStyle = -1;
  
  private int mWrapMode = 0;
  
  private void createAlignedConstraints(boolean paramBoolean) {
    if (this.mAlignedDimensions != null && this.mAlignedBiggestElementsInCols != null) {
      ConstraintWidget constraintWidget;
      if (this.mAlignedBiggestElementsInRows == null)
        return; 
      int i;
      for (i = 0; i < this.mDisplayedWidgetsCount; i++)
        this.mDisplayedWidgets[i].resetAnchors(); 
      int[] arrayOfInt = this.mAlignedDimensions;
      int j = arrayOfInt[0];
      int k = arrayOfInt[1];
      arrayOfInt = null;
      i = 0;
      while (i < j) {
        int m;
        ConstraintWidget constraintWidget1;
        if (paramBoolean) {
          m = j - i - 1;
        } else {
          m = i;
        } 
        ConstraintWidget constraintWidget2 = this.mAlignedBiggestElementsInCols[m];
        int[] arrayOfInt1 = arrayOfInt;
        if (constraintWidget2 != null)
          if (constraintWidget2.getVisibility() == 8) {
            arrayOfInt1 = arrayOfInt;
          } else {
            if (i == 0) {
              constraintWidget2.connect(constraintWidget2.mLeft, this.mLeft, getPaddingLeft());
              constraintWidget2.setHorizontalChainStyle(this.mHorizontalStyle);
              constraintWidget2.setHorizontalBiasPercent(this.mHorizontalBias);
            } 
            if (i == j - 1)
              constraintWidget2.connect(constraintWidget2.mRight, this.mRight, getPaddingRight()); 
            if (i > 0) {
              constraintWidget2.connect(constraintWidget2.mLeft, ((ConstraintWidget)arrayOfInt).mRight, this.mHorizontalGap);
              arrayOfInt.connect(((ConstraintWidget)arrayOfInt).mRight, constraintWidget2.mLeft, 0);
            } 
            constraintWidget1 = constraintWidget2;
          }  
        i++;
        constraintWidget = constraintWidget1;
      } 
      i = 0;
      while (i < k) {
        ConstraintWidget constraintWidget2 = this.mAlignedBiggestElementsInRows[i];
        ConstraintWidget constraintWidget1 = constraintWidget;
        if (constraintWidget2 != null)
          if (constraintWidget2.getVisibility() == 8) {
            constraintWidget1 = constraintWidget;
          } else {
            if (i == 0) {
              constraintWidget2.connect(constraintWidget2.mTop, this.mTop, getPaddingTop());
              constraintWidget2.setVerticalChainStyle(this.mVerticalStyle);
              constraintWidget2.setVerticalBiasPercent(this.mVerticalBias);
            } 
            if (i == k - 1)
              constraintWidget2.connect(constraintWidget2.mBottom, this.mBottom, getPaddingBottom()); 
            if (i > 0) {
              constraintWidget2.connect(constraintWidget2.mTop, constraintWidget.mBottom, this.mVerticalGap);
              constraintWidget.connect(constraintWidget.mBottom, constraintWidget2.mTop, 0);
            } 
            constraintWidget1 = constraintWidget2;
          }  
        i++;
        constraintWidget = constraintWidget1;
      } 
      for (i = 0; i < j; i++) {
        for (int m = 0; m < k; m++) {
          int n = m * j + i;
          if (this.mOrientation == 1)
            n = i * k + m; 
          ConstraintWidget[] arrayOfConstraintWidget = this.mDisplayedWidgets;
          if (n < arrayOfConstraintWidget.length) {
            ConstraintWidget constraintWidget1 = arrayOfConstraintWidget[n];
            if (constraintWidget1 != null && constraintWidget1.getVisibility() != 8) {
              ConstraintWidget constraintWidget2 = this.mAlignedBiggestElementsInCols[i];
              ConstraintWidget constraintWidget3 = this.mAlignedBiggestElementsInRows[m];
              if (constraintWidget1 != constraintWidget2) {
                constraintWidget1.connect(constraintWidget1.mLeft, constraintWidget2.mLeft, 0);
                constraintWidget1.connect(constraintWidget1.mRight, constraintWidget2.mRight, 0);
              } 
              if (constraintWidget1 != constraintWidget3) {
                constraintWidget1.connect(constraintWidget1.mTop, constraintWidget3.mTop, 0);
                constraintWidget1.connect(constraintWidget1.mBottom, constraintWidget3.mBottom, 0);
              } 
            } 
          } 
        } 
      } 
    } 
  }
  
  private final int getWidgetHeight(ConstraintWidget paramConstraintWidget, int paramInt) {
    if (paramConstraintWidget == null)
      return 0; 
    if (paramConstraintWidget.getVerticalDimensionBehaviour() == ConstraintWidget.DimensionBehaviour.MATCH_CONSTRAINT) {
      int i = paramConstraintWidget.mMatchConstraintDefaultHeight;
      if (i == 0)
        return 0; 
      if (i == 2) {
        paramInt = (int)(paramConstraintWidget.mMatchConstraintPercentHeight * paramInt);
        if (paramInt != paramConstraintWidget.getHeight()) {
          paramConstraintWidget.setMeasureRequested(true);
          measure(paramConstraintWidget, paramConstraintWidget.getHorizontalDimensionBehaviour(), paramConstraintWidget.getWidth(), ConstraintWidget.DimensionBehaviour.FIXED, paramInt);
        } 
        return paramInt;
      } 
      if (i == 1)
        return paramConstraintWidget.getHeight(); 
      if (i == 3)
        return (int)(paramConstraintWidget.getWidth() * paramConstraintWidget.mDimensionRatio + 0.5F); 
    } 
    return paramConstraintWidget.getHeight();
  }
  
  private final int getWidgetWidth(ConstraintWidget paramConstraintWidget, int paramInt) {
    if (paramConstraintWidget == null)
      return 0; 
    if (paramConstraintWidget.getHorizontalDimensionBehaviour() == ConstraintWidget.DimensionBehaviour.MATCH_CONSTRAINT) {
      int i = paramConstraintWidget.mMatchConstraintDefaultWidth;
      if (i == 0)
        return 0; 
      if (i == 2) {
        paramInt = (int)(paramConstraintWidget.mMatchConstraintPercentWidth * paramInt);
        if (paramInt != paramConstraintWidget.getWidth()) {
          paramConstraintWidget.setMeasureRequested(true);
          measure(paramConstraintWidget, ConstraintWidget.DimensionBehaviour.FIXED, paramInt, paramConstraintWidget.getVerticalDimensionBehaviour(), paramConstraintWidget.getHeight());
        } 
        return paramInt;
      } 
      if (i == 1)
        return paramConstraintWidget.getWidth(); 
      if (i == 3)
        return (int)(paramConstraintWidget.getHeight() * paramConstraintWidget.mDimensionRatio + 0.5F); 
    } 
    return paramConstraintWidget.getWidth();
  }
  
  private void measureAligned(ConstraintWidget[] paramArrayOfConstraintWidget, int paramInt1, int paramInt2, int paramInt3, int[] paramArrayOfint) {
    // Byte code:
    //   0: iload_3
    //   1: ifne -> 126
    //   4: aload_0
    //   5: getfield mMaxElementsWrap : I
    //   8: istore #6
    //   10: iload #6
    //   12: istore #8
    //   14: iload #6
    //   16: ifgt -> 116
    //   19: iconst_0
    //   20: istore #6
    //   22: iconst_0
    //   23: istore #9
    //   25: iconst_0
    //   26: istore #7
    //   28: iload #6
    //   30: istore #8
    //   32: iload #9
    //   34: iload_2
    //   35: if_icmpge -> 116
    //   38: iload #7
    //   40: istore #8
    //   42: iload #9
    //   44: ifle -> 56
    //   47: iload #7
    //   49: aload_0
    //   50: getfield mHorizontalGap : I
    //   53: iadd
    //   54: istore #8
    //   56: aload_1
    //   57: iload #9
    //   59: aaload
    //   60: astore #13
    //   62: aload #13
    //   64: ifnonnull -> 74
    //   67: iload #8
    //   69: istore #7
    //   71: goto -> 107
    //   74: iload #8
    //   76: aload_0
    //   77: aload #13
    //   79: iload #4
    //   81: invokespecial getWidgetWidth : (Landroidx/constraintlayout/solver/widgets/ConstraintWidget;I)I
    //   84: iadd
    //   85: istore #7
    //   87: iload #7
    //   89: iload #4
    //   91: if_icmple -> 101
    //   94: iload #6
    //   96: istore #8
    //   98: goto -> 116
    //   101: iload #6
    //   103: iconst_1
    //   104: iadd
    //   105: istore #6
    //   107: iload #9
    //   109: iconst_1
    //   110: iadd
    //   111: istore #9
    //   113: goto -> 28
    //   116: iload #8
    //   118: istore #7
    //   120: iconst_0
    //   121: istore #6
    //   123: goto -> 245
    //   126: aload_0
    //   127: getfield mMaxElementsWrap : I
    //   130: istore #6
    //   132: iload #6
    //   134: istore #8
    //   136: iload #6
    //   138: ifgt -> 238
    //   141: iconst_0
    //   142: istore #6
    //   144: iconst_0
    //   145: istore #9
    //   147: iconst_0
    //   148: istore #7
    //   150: iload #6
    //   152: istore #8
    //   154: iload #9
    //   156: iload_2
    //   157: if_icmpge -> 238
    //   160: iload #7
    //   162: istore #8
    //   164: iload #9
    //   166: ifle -> 178
    //   169: iload #7
    //   171: aload_0
    //   172: getfield mVerticalGap : I
    //   175: iadd
    //   176: istore #8
    //   178: aload_1
    //   179: iload #9
    //   181: aaload
    //   182: astore #13
    //   184: aload #13
    //   186: ifnonnull -> 196
    //   189: iload #8
    //   191: istore #7
    //   193: goto -> 229
    //   196: iload #8
    //   198: aload_0
    //   199: aload #13
    //   201: iload #4
    //   203: invokespecial getWidgetHeight : (Landroidx/constraintlayout/solver/widgets/ConstraintWidget;I)I
    //   206: iadd
    //   207: istore #7
    //   209: iload #7
    //   211: iload #4
    //   213: if_icmple -> 223
    //   216: iload #6
    //   218: istore #8
    //   220: goto -> 238
    //   223: iload #6
    //   225: iconst_1
    //   226: iadd
    //   227: istore #6
    //   229: iload #9
    //   231: iconst_1
    //   232: iadd
    //   233: istore #9
    //   235: goto -> 150
    //   238: iconst_0
    //   239: istore #7
    //   241: iload #8
    //   243: istore #6
    //   245: aload_0
    //   246: getfield mAlignedDimensions : [I
    //   249: ifnonnull -> 259
    //   252: aload_0
    //   253: iconst_2
    //   254: newarray int
    //   256: putfield mAlignedDimensions : [I
    //   259: iload #6
    //   261: ifne -> 277
    //   264: iload #6
    //   266: istore #11
    //   268: iload #7
    //   270: istore #9
    //   272: iload_3
    //   273: iconst_1
    //   274: if_icmpeq -> 294
    //   277: iload #7
    //   279: ifne -> 308
    //   282: iload_3
    //   283: ifne -> 308
    //   286: iload #7
    //   288: istore #9
    //   290: iload #6
    //   292: istore #11
    //   294: iconst_1
    //   295: istore #12
    //   297: iload #11
    //   299: istore #6
    //   301: iload #9
    //   303: istore #7
    //   305: goto -> 311
    //   308: iconst_0
    //   309: istore #12
    //   311: iload #12
    //   313: ifne -> 850
    //   316: iload_3
    //   317: ifne -> 336
    //   320: iload_2
    //   321: i2f
    //   322: iload #7
    //   324: i2f
    //   325: fdiv
    //   326: f2d
    //   327: invokestatic ceil : (D)D
    //   330: d2i
    //   331: istore #6
    //   333: goto -> 349
    //   336: iload_2
    //   337: i2f
    //   338: iload #6
    //   340: i2f
    //   341: fdiv
    //   342: f2d
    //   343: invokestatic ceil : (D)D
    //   346: d2i
    //   347: istore #7
    //   349: aload_0
    //   350: getfield mAlignedBiggestElementsInCols : [Landroidx/constraintlayout/solver/widgets/ConstraintWidget;
    //   353: astore #13
    //   355: aload #13
    //   357: ifnull -> 380
    //   360: aload #13
    //   362: arraylength
    //   363: iload #7
    //   365: if_icmpge -> 371
    //   368: goto -> 380
    //   371: aload #13
    //   373: aconst_null
    //   374: invokestatic fill : ([Ljava/lang/Object;Ljava/lang/Object;)V
    //   377: goto -> 389
    //   380: aload_0
    //   381: iload #7
    //   383: anewarray androidx/constraintlayout/solver/widgets/ConstraintWidget
    //   386: putfield mAlignedBiggestElementsInCols : [Landroidx/constraintlayout/solver/widgets/ConstraintWidget;
    //   389: aload_0
    //   390: getfield mAlignedBiggestElementsInRows : [Landroidx/constraintlayout/solver/widgets/ConstraintWidget;
    //   393: astore #13
    //   395: aload #13
    //   397: ifnull -> 420
    //   400: aload #13
    //   402: arraylength
    //   403: iload #6
    //   405: if_icmpge -> 411
    //   408: goto -> 420
    //   411: aload #13
    //   413: aconst_null
    //   414: invokestatic fill : ([Ljava/lang/Object;Ljava/lang/Object;)V
    //   417: goto -> 429
    //   420: aload_0
    //   421: iload #6
    //   423: anewarray androidx/constraintlayout/solver/widgets/ConstraintWidget
    //   426: putfield mAlignedBiggestElementsInRows : [Landroidx/constraintlayout/solver/widgets/ConstraintWidget;
    //   429: iconst_0
    //   430: istore #8
    //   432: iload #8
    //   434: iload #7
    //   436: if_icmpge -> 608
    //   439: iconst_0
    //   440: istore #9
    //   442: iload #9
    //   444: iload #6
    //   446: if_icmpge -> 599
    //   449: iload #9
    //   451: iload #7
    //   453: imul
    //   454: iload #8
    //   456: iadd
    //   457: istore #10
    //   459: iload_3
    //   460: iconst_1
    //   461: if_icmpne -> 474
    //   464: iload #8
    //   466: iload #6
    //   468: imul
    //   469: iload #9
    //   471: iadd
    //   472: istore #10
    //   474: iload #10
    //   476: aload_1
    //   477: arraylength
    //   478: if_icmplt -> 484
    //   481: goto -> 590
    //   484: aload_1
    //   485: iload #10
    //   487: aaload
    //   488: astore #13
    //   490: aload #13
    //   492: ifnonnull -> 498
    //   495: goto -> 590
    //   498: aload_0
    //   499: aload #13
    //   501: iload #4
    //   503: invokespecial getWidgetWidth : (Landroidx/constraintlayout/solver/widgets/ConstraintWidget;I)I
    //   506: istore #10
    //   508: aload_0
    //   509: getfield mAlignedBiggestElementsInCols : [Landroidx/constraintlayout/solver/widgets/ConstraintWidget;
    //   512: astore #14
    //   514: aload #14
    //   516: iload #8
    //   518: aaload
    //   519: ifnull -> 535
    //   522: aload #14
    //   524: iload #8
    //   526: aaload
    //   527: invokevirtual getWidth : ()I
    //   530: iload #10
    //   532: if_icmpge -> 544
    //   535: aload_0
    //   536: getfield mAlignedBiggestElementsInCols : [Landroidx/constraintlayout/solver/widgets/ConstraintWidget;
    //   539: iload #8
    //   541: aload #13
    //   543: aastore
    //   544: aload_0
    //   545: aload #13
    //   547: iload #4
    //   549: invokespecial getWidgetHeight : (Landroidx/constraintlayout/solver/widgets/ConstraintWidget;I)I
    //   552: istore #10
    //   554: aload_0
    //   555: getfield mAlignedBiggestElementsInRows : [Landroidx/constraintlayout/solver/widgets/ConstraintWidget;
    //   558: astore #14
    //   560: aload #14
    //   562: iload #9
    //   564: aaload
    //   565: ifnull -> 581
    //   568: aload #14
    //   570: iload #9
    //   572: aaload
    //   573: invokevirtual getHeight : ()I
    //   576: iload #10
    //   578: if_icmpge -> 590
    //   581: aload_0
    //   582: getfield mAlignedBiggestElementsInRows : [Landroidx/constraintlayout/solver/widgets/ConstraintWidget;
    //   585: iload #9
    //   587: aload #13
    //   589: aastore
    //   590: iload #9
    //   592: iconst_1
    //   593: iadd
    //   594: istore #9
    //   596: goto -> 442
    //   599: iload #8
    //   601: iconst_1
    //   602: iadd
    //   603: istore #8
    //   605: goto -> 432
    //   608: iconst_0
    //   609: istore #9
    //   611: iconst_0
    //   612: istore #8
    //   614: iload #9
    //   616: iload #7
    //   618: if_icmpge -> 683
    //   621: aload_0
    //   622: getfield mAlignedBiggestElementsInCols : [Landroidx/constraintlayout/solver/widgets/ConstraintWidget;
    //   625: iload #9
    //   627: aaload
    //   628: astore #13
    //   630: iload #8
    //   632: istore #10
    //   634: aload #13
    //   636: ifnull -> 670
    //   639: iload #8
    //   641: istore #10
    //   643: iload #9
    //   645: ifle -> 657
    //   648: iload #8
    //   650: aload_0
    //   651: getfield mHorizontalGap : I
    //   654: iadd
    //   655: istore #10
    //   657: iload #10
    //   659: aload_0
    //   660: aload #13
    //   662: iload #4
    //   664: invokespecial getWidgetWidth : (Landroidx/constraintlayout/solver/widgets/ConstraintWidget;I)I
    //   667: iadd
    //   668: istore #10
    //   670: iload #9
    //   672: iconst_1
    //   673: iadd
    //   674: istore #9
    //   676: iload #10
    //   678: istore #8
    //   680: goto -> 614
    //   683: iconst_0
    //   684: istore #9
    //   686: iconst_0
    //   687: istore #10
    //   689: iload #9
    //   691: iload #6
    //   693: if_icmpge -> 758
    //   696: aload_0
    //   697: getfield mAlignedBiggestElementsInRows : [Landroidx/constraintlayout/solver/widgets/ConstraintWidget;
    //   700: iload #9
    //   702: aaload
    //   703: astore #13
    //   705: iload #10
    //   707: istore #11
    //   709: aload #13
    //   711: ifnull -> 745
    //   714: iload #10
    //   716: istore #11
    //   718: iload #9
    //   720: ifle -> 732
    //   723: iload #10
    //   725: aload_0
    //   726: getfield mVerticalGap : I
    //   729: iadd
    //   730: istore #11
    //   732: iload #11
    //   734: aload_0
    //   735: aload #13
    //   737: iload #4
    //   739: invokespecial getWidgetHeight : (Landroidx/constraintlayout/solver/widgets/ConstraintWidget;I)I
    //   742: iadd
    //   743: istore #11
    //   745: iload #9
    //   747: iconst_1
    //   748: iadd
    //   749: istore #9
    //   751: iload #11
    //   753: istore #10
    //   755: goto -> 689
    //   758: aload #5
    //   760: iconst_0
    //   761: iload #8
    //   763: iastore
    //   764: aload #5
    //   766: iconst_1
    //   767: iload #10
    //   769: iastore
    //   770: iload_3
    //   771: ifne -> 812
    //   774: iload #6
    //   776: istore #11
    //   778: iload #7
    //   780: istore #9
    //   782: iload #8
    //   784: iload #4
    //   786: if_icmple -> 294
    //   789: iload #6
    //   791: istore #11
    //   793: iload #7
    //   795: istore #9
    //   797: iload #7
    //   799: iconst_1
    //   800: if_icmple -> 294
    //   803: iload #7
    //   805: iconst_1
    //   806: isub
    //   807: istore #7
    //   809: goto -> 311
    //   812: iload #6
    //   814: istore #11
    //   816: iload #7
    //   818: istore #9
    //   820: iload #10
    //   822: iload #4
    //   824: if_icmple -> 294
    //   827: iload #6
    //   829: istore #11
    //   831: iload #7
    //   833: istore #9
    //   835: iload #6
    //   837: iconst_1
    //   838: if_icmple -> 294
    //   841: iload #6
    //   843: iconst_1
    //   844: isub
    //   845: istore #6
    //   847: goto -> 311
    //   850: aload_0
    //   851: getfield mAlignedDimensions : [I
    //   854: astore_1
    //   855: aload_1
    //   856: iconst_0
    //   857: iload #7
    //   859: iastore
    //   860: aload_1
    //   861: iconst_1
    //   862: iload #6
    //   864: iastore
    //   865: return
  }
  
  private void measureChainWrap(ConstraintWidget[] paramArrayOfConstraintWidget, int paramInt1, int paramInt2, int paramInt3, int[] paramArrayOfint) {
    ConstraintWidget constraintWidget;
    if (paramInt1 == 0)
      return; 
    this.mChainList.clear();
    WidgetsList widgetsList = new WidgetsList(paramInt2, this.mLeft, this.mTop, this.mRight, this.mBottom, paramInt3);
    this.mChainList.add(widgetsList);
    if (paramInt2 == 0) {
      Object object;
      boolean bool = false;
      int i3 = 0;
      int i4 = 0;
      while (true) {
        Object object1 = object;
        if (i4 < paramInt1) {
          boolean bool1;
          WidgetsList widgetsList1;
          constraintWidget = paramArrayOfConstraintWidget[i4];
          int i5 = getWidgetWidth(constraintWidget, paramInt3);
          object1 = object;
          if (constraintWidget.getHorizontalDimensionBehaviour() == ConstraintWidget.DimensionBehaviour.MATCH_CONSTRAINT)
            i = object + 1; 
          if ((i3 == paramInt3 || this.mHorizontalGap + i3 + i5 > paramInt3) && widgetsList.biggest != null) {
            bool1 = true;
          } else {
            bool1 = false;
          } 
          boolean bool2 = bool1;
          if (!bool1) {
            bool2 = bool1;
            if (i4 > 0) {
              int i6 = this.mMaxElementsWrap;
              bool2 = bool1;
              if (i6 > 0) {
                bool2 = bool1;
                if (i4 % i6 == 0)
                  bool2 = true; 
              } 
            } 
          } 
          if (bool2) {
            widgetsList1 = new WidgetsList(paramInt2, this.mLeft, this.mTop, this.mRight, this.mBottom, paramInt3);
            widgetsList1.setStartIndex(i4);
            this.mChainList.add(widgetsList1);
          } else {
            widgetsList1 = widgetsList;
            if (i4 > 0) {
              i3 += this.mHorizontalGap + i5;
              continue;
            } 
          } 
          i3 = i5;
          widgetsList = widgetsList1;
          continue;
        } 
        break;
        widgetsList.add((ConstraintWidget)SYNTHETIC_LOCAL_VARIABLE_16);
        i4++;
        object = SYNTHETIC_LOCAL_VARIABLE_7;
      } 
    } else {
      int i3 = 0;
      int i4 = 0;
      int i5 = 0;
      while (true) {
        i = i3;
        if (i5 < paramInt1) {
          WidgetsList widgetsList1;
          constraintWidget = paramArrayOfConstraintWidget[i5];
          int i7 = getWidgetHeight(constraintWidget, paramInt3);
          i = i3;
          if (constraintWidget.getVerticalDimensionBehaviour() == ConstraintWidget.DimensionBehaviour.MATCH_CONSTRAINT)
            i = i3 + 1; 
          if ((i4 == paramInt3 || this.mVerticalGap + i4 + i7 > paramInt3) && widgetsList.biggest != null) {
            i3 = 1;
          } else {
            i3 = 0;
          } 
          int i6 = i3;
          if (i3 == 0) {
            i6 = i3;
            if (i5 > 0) {
              int i8 = this.mMaxElementsWrap;
              i6 = i3;
              if (i8 > 0) {
                i6 = i3;
                if (i5 % i8 == 0)
                  i6 = 1; 
              } 
            } 
          } 
          if (i6 != 0) {
            widgetsList1 = new WidgetsList(paramInt2, this.mLeft, this.mTop, this.mRight, this.mBottom, paramInt3);
            widgetsList1.setStartIndex(i5);
            this.mChainList.add(widgetsList1);
          } else {
            widgetsList1 = widgetsList;
            if (i5 > 0) {
              i4 += this.mVerticalGap + i7;
              continue;
            } 
          } 
          i4 = i7;
          widgetsList = widgetsList1;
          continue;
        } 
        break;
        widgetsList.add(constraintWidget);
        i5++;
        i3 = i;
      } 
    } 
    int i2 = this.mChainList.size();
    ConstraintAnchor constraintAnchor1 = this.mLeft;
    ConstraintAnchor constraintAnchor4 = this.mTop;
    ConstraintAnchor constraintAnchor2 = this.mRight;
    ConstraintAnchor constraintAnchor3 = this.mBottom;
    int j = getPaddingLeft();
    int k = getPaddingTop();
    int n = getPaddingRight();
    int m = getPaddingBottom();
    ConstraintWidget.DimensionBehaviour dimensionBehaviour1 = getHorizontalDimensionBehaviour();
    ConstraintWidget.DimensionBehaviour dimensionBehaviour2 = ConstraintWidget.DimensionBehaviour.WRAP_CONTENT;
    if (dimensionBehaviour1 == dimensionBehaviour2 || getVerticalDimensionBehaviour() == dimensionBehaviour2) {
      paramInt1 = 1;
    } else {
      paramInt1 = 0;
    } 
    if (i > 0 && paramInt1 != 0)
      for (paramInt1 = 0; paramInt1 < i2; paramInt1++) {
        WidgetsList widgetsList1 = this.mChainList.get(paramInt1);
        if (paramInt2 == 0) {
          widgetsList1.measureMatchConstraints(paramInt3 - widgetsList1.getWidth());
        } else {
          widgetsList1.measureMatchConstraints(paramInt3 - widgetsList1.getHeight());
        } 
      }  
    int i = 0;
    int i1 = 0;
    paramInt1 = 0;
    while (paramInt1 < i2) {
      int i3;
      WidgetsList widgetsList1 = this.mChainList.get(paramInt1);
      if (paramInt2 == 0) {
        if (paramInt1 < i2 - 1) {
          constraintAnchor3 = ((WidgetsList)this.mChainList.get(paramInt1 + 1)).biggest.mTop;
          i3 = 0;
        } else {
          constraintAnchor3 = this.mBottom;
          i3 = getPaddingBottom();
        } 
        ConstraintAnchor constraintAnchor = widgetsList1.biggest.mBottom;
        widgetsList1.setup(paramInt2, constraintAnchor1, constraintAnchor4, constraintAnchor2, constraintAnchor3, j, k, n, i3, paramInt3);
        k = Math.max(i1, widgetsList1.getWidth());
        m = i + widgetsList1.getHeight();
        i = m;
        if (paramInt1 > 0)
          i = m + this.mVerticalGap; 
        constraintAnchor4 = constraintAnchor;
        i1 = 0;
        m = i3;
        i3 = k;
        k = i1;
      } else {
        n = paramInt1;
        if (n < i2 - 1) {
          constraintAnchor2 = ((WidgetsList)this.mChainList.get(n + 1)).biggest.mLeft;
          i3 = 0;
        } else {
          constraintAnchor2 = this.mRight;
          i3 = getPaddingRight();
        } 
        ConstraintAnchor constraintAnchor = widgetsList1.biggest.mRight;
        widgetsList1.setup(paramInt2, constraintAnchor1, constraintAnchor4, constraintAnchor2, constraintAnchor3, j, k, i3, m, paramInt3);
        j = i1 + widgetsList1.getWidth();
        i1 = Math.max(i, widgetsList1.getHeight());
        i = j;
        if (n > 0)
          i = j + this.mHorizontalGap; 
        j = i1;
        n = i3;
        constraintAnchor1 = constraintAnchor;
        i1 = 0;
        i3 = i;
        i = j;
        j = i1;
      } 
      paramInt1++;
      i1 = i3;
    } 
    paramArrayOfint[0] = i1;
    paramArrayOfint[1] = i;
  }
  
  private void measureNoWrap(ConstraintWidget[] paramArrayOfConstraintWidget, int paramInt1, int paramInt2, int paramInt3, int[] paramArrayOfint) {
    WidgetsList widgetsList;
    if (paramInt1 == 0)
      return; 
    if (this.mChainList.size() == 0) {
      widgetsList = new WidgetsList(paramInt2, this.mLeft, this.mTop, this.mRight, this.mBottom, paramInt3);
      this.mChainList.add(widgetsList);
    } else {
      widgetsList = this.mChainList.get(0);
      widgetsList.clear();
      ConstraintAnchor constraintAnchor1 = this.mLeft;
      ConstraintAnchor constraintAnchor2 = this.mTop;
      ConstraintAnchor constraintAnchor3 = this.mRight;
      ConstraintAnchor constraintAnchor4 = this.mBottom;
      int i = getPaddingLeft();
      int j = getPaddingTop();
      int k = getPaddingRight();
      int m = getPaddingBottom();
      widgetsList.setup(paramInt2, constraintAnchor1, constraintAnchor2, constraintAnchor3, constraintAnchor4, i, j, k, m, paramInt3);
    } 
    for (paramInt2 = 0; paramInt2 < paramInt1; paramInt2++)
      widgetsList.add(paramArrayOfConstraintWidget[paramInt2]); 
    paramArrayOfint[0] = widgetsList.getWidth();
    paramArrayOfint[1] = widgetsList.getHeight();
  }
  
  public void addToSolver(LinearSystem paramLinearSystem, boolean paramBoolean) {
    super.addToSolver(paramLinearSystem, paramBoolean);
    if (getParent() != null) {
      paramBoolean = ((ConstraintWidgetContainer)getParent()).isRtl();
    } else {
      paramBoolean = false;
    } 
    int i = this.mWrapMode;
    if (i != 0) {
      if (i != 1) {
        if (i == 2)
          createAlignedConstraints(paramBoolean); 
      } else {
        int j = this.mChainList.size();
        for (i = 0; i < j; i++) {
          boolean bool;
          WidgetsList widgetsList = this.mChainList.get(i);
          if (i == j - 1) {
            bool = true;
          } else {
            bool = false;
          } 
          widgetsList.createConstraints(paramBoolean, i, bool);
        } 
      } 
    } else if (this.mChainList.size() > 0) {
      ((WidgetsList)this.mChainList.get(0)).createConstraints(paramBoolean, 0, true);
    } 
    needsCallbackFromSolver(false);
  }
  
  public void copy(ConstraintWidget paramConstraintWidget, HashMap<ConstraintWidget, ConstraintWidget> paramHashMap) {
    super.copy(paramConstraintWidget, paramHashMap);
    paramConstraintWidget = paramConstraintWidget;
    this.mHorizontalStyle = ((Flow)paramConstraintWidget).mHorizontalStyle;
    this.mVerticalStyle = ((Flow)paramConstraintWidget).mVerticalStyle;
    this.mFirstHorizontalStyle = ((Flow)paramConstraintWidget).mFirstHorizontalStyle;
    this.mFirstVerticalStyle = ((Flow)paramConstraintWidget).mFirstVerticalStyle;
    this.mLastHorizontalStyle = ((Flow)paramConstraintWidget).mLastHorizontalStyle;
    this.mLastVerticalStyle = ((Flow)paramConstraintWidget).mLastVerticalStyle;
    this.mHorizontalBias = ((Flow)paramConstraintWidget).mHorizontalBias;
    this.mVerticalBias = ((Flow)paramConstraintWidget).mVerticalBias;
    this.mFirstHorizontalBias = ((Flow)paramConstraintWidget).mFirstHorizontalBias;
    this.mFirstVerticalBias = ((Flow)paramConstraintWidget).mFirstVerticalBias;
    this.mLastHorizontalBias = ((Flow)paramConstraintWidget).mLastHorizontalBias;
    this.mLastVerticalBias = ((Flow)paramConstraintWidget).mLastVerticalBias;
    this.mHorizontalGap = ((Flow)paramConstraintWidget).mHorizontalGap;
    this.mVerticalGap = ((Flow)paramConstraintWidget).mVerticalGap;
    this.mHorizontalAlign = ((Flow)paramConstraintWidget).mHorizontalAlign;
    this.mVerticalAlign = ((Flow)paramConstraintWidget).mVerticalAlign;
    this.mWrapMode = ((Flow)paramConstraintWidget).mWrapMode;
    this.mMaxElementsWrap = ((Flow)paramConstraintWidget).mMaxElementsWrap;
    this.mOrientation = ((Flow)paramConstraintWidget).mOrientation;
  }
  
  public void measure(int paramInt1, int paramInt2, int paramInt3, int paramInt4) {
    if (this.mWidgetsCount > 0 && !measureChildren()) {
      setMeasure(0, 0);
      needsCallbackFromSolver(false);
      return;
    } 
    int i1 = getPaddingLeft();
    int i2 = getPaddingRight();
    int m = getPaddingTop();
    int n = getPaddingBottom();
    int[] arrayOfInt = new int[2];
    int j = paramInt2 - i1 - i2;
    int i = this.mOrientation;
    if (i == 1)
      j = paramInt4 - m - n; 
    if (i == 0) {
      if (this.mHorizontalStyle == -1)
        this.mHorizontalStyle = 0; 
      if (this.mVerticalStyle == -1)
        this.mVerticalStyle = 0; 
    } else {
      if (this.mHorizontalStyle == -1)
        this.mHorizontalStyle = 0; 
      if (this.mVerticalStyle == -1)
        this.mVerticalStyle = 0; 
    } 
    ConstraintWidget[] arrayOfConstraintWidget = this.mWidgets;
    i = 0;
    int k = 0;
    while (true) {
      int i3 = this.mWidgetsCount;
      if (i < i3) {
        i3 = k;
        if (this.mWidgets[i].getVisibility() == 8)
          i3 = k + 1; 
        i++;
        k = i3;
        continue;
      } 
      if (k > 0) {
        arrayOfConstraintWidget = new ConstraintWidget[i3 - k];
        k = 0;
        for (i = 0; k < this.mWidgetsCount; i = i3) {
          ConstraintWidget constraintWidget = this.mWidgets[k];
          i3 = i;
          if (constraintWidget.getVisibility() != 8) {
            arrayOfConstraintWidget[i] = constraintWidget;
            i3 = i + 1;
          } 
          k++;
        } 
      } else {
        i = i3;
      } 
      this.mDisplayedWidgets = arrayOfConstraintWidget;
      this.mDisplayedWidgetsCount = i;
      k = this.mWrapMode;
      if (k != 0) {
        if (k != 1) {
          if (k == 2)
            measureAligned(arrayOfConstraintWidget, i, this.mOrientation, j, arrayOfInt); 
        } else {
          measureChainWrap(arrayOfConstraintWidget, i, this.mOrientation, j, arrayOfInt);
        } 
      } else {
        measureNoWrap(arrayOfConstraintWidget, i, this.mOrientation, j, arrayOfInt);
      } 
      boolean bool = true;
      j = arrayOfInt[0] + i1 + i2;
      i = arrayOfInt[1] + m + n;
      if (paramInt1 == 1073741824) {
        paramInt1 = paramInt2;
      } else if (paramInt1 == Integer.MIN_VALUE) {
        paramInt1 = Math.min(j, paramInt2);
      } else if (paramInt1 == 0) {
        paramInt1 = j;
      } else {
        paramInt1 = 0;
      } 
      if (paramInt3 == 1073741824) {
        paramInt2 = paramInt4;
      } else if (paramInt3 == Integer.MIN_VALUE) {
        paramInt2 = Math.min(i, paramInt4);
      } else if (paramInt3 == 0) {
        paramInt2 = i;
      } else {
        paramInt2 = 0;
      } 
      setMeasure(paramInt1, paramInt2);
      setWidth(paramInt1);
      setHeight(paramInt2);
      if (this.mWidgetsCount <= 0)
        bool = false; 
      needsCallbackFromSolver(bool);
      return;
    } 
  }
  
  public void setFirstHorizontalBias(float paramFloat) {
    this.mFirstHorizontalBias = paramFloat;
  }
  
  public void setFirstHorizontalStyle(int paramInt) {
    this.mFirstHorizontalStyle = paramInt;
  }
  
  public void setFirstVerticalBias(float paramFloat) {
    this.mFirstVerticalBias = paramFloat;
  }
  
  public void setFirstVerticalStyle(int paramInt) {
    this.mFirstVerticalStyle = paramInt;
  }
  
  public void setHorizontalAlign(int paramInt) {
    this.mHorizontalAlign = paramInt;
  }
  
  public void setHorizontalBias(float paramFloat) {
    this.mHorizontalBias = paramFloat;
  }
  
  public void setHorizontalGap(int paramInt) {
    this.mHorizontalGap = paramInt;
  }
  
  public void setHorizontalStyle(int paramInt) {
    this.mHorizontalStyle = paramInt;
  }
  
  public void setLastHorizontalBias(float paramFloat) {
    this.mLastHorizontalBias = paramFloat;
  }
  
  public void setLastHorizontalStyle(int paramInt) {
    this.mLastHorizontalStyle = paramInt;
  }
  
  public void setLastVerticalBias(float paramFloat) {
    this.mLastVerticalBias = paramFloat;
  }
  
  public void setLastVerticalStyle(int paramInt) {
    this.mLastVerticalStyle = paramInt;
  }
  
  public void setMaxElementsWrap(int paramInt) {
    this.mMaxElementsWrap = paramInt;
  }
  
  public void setOrientation(int paramInt) {
    this.mOrientation = paramInt;
  }
  
  public void setVerticalAlign(int paramInt) {
    this.mVerticalAlign = paramInt;
  }
  
  public void setVerticalBias(float paramFloat) {
    this.mVerticalBias = paramFloat;
  }
  
  public void setVerticalGap(int paramInt) {
    this.mVerticalGap = paramInt;
  }
  
  public void setVerticalStyle(int paramInt) {
    this.mVerticalStyle = paramInt;
  }
  
  public void setWrapMode(int paramInt) {
    this.mWrapMode = paramInt;
  }
  
  private class WidgetsList {
    private ConstraintWidget biggest = null;
    
    int biggestDimension = 0;
    
    private ConstraintAnchor mBottom;
    
    private int mCount = 0;
    
    private int mHeight = 0;
    
    private ConstraintAnchor mLeft;
    
    private int mMax = 0;
    
    private int mNbMatchConstraintsWidgets = 0;
    
    private int mOrientation;
    
    private int mPaddingBottom = 0;
    
    private int mPaddingLeft = 0;
    
    private int mPaddingRight = 0;
    
    private int mPaddingTop = 0;
    
    private ConstraintAnchor mRight;
    
    private int mStartIndex = 0;
    
    private ConstraintAnchor mTop;
    
    private int mWidth = 0;
    
    public WidgetsList(int param1Int1, ConstraintAnchor param1ConstraintAnchor1, ConstraintAnchor param1ConstraintAnchor2, ConstraintAnchor param1ConstraintAnchor3, ConstraintAnchor param1ConstraintAnchor4, int param1Int2) {
      this.mOrientation = param1Int1;
      this.mLeft = param1ConstraintAnchor1;
      this.mTop = param1ConstraintAnchor2;
      this.mRight = param1ConstraintAnchor3;
      this.mBottom = param1ConstraintAnchor4;
      this.mPaddingLeft = Flow.this.getPaddingLeft();
      this.mPaddingTop = Flow.this.getPaddingTop();
      this.mPaddingRight = Flow.this.getPaddingRight();
      this.mPaddingBottom = Flow.this.getPaddingBottom();
      this.mMax = param1Int2;
    }
    
    private void recomputeDimensions() {
      this.mWidth = 0;
      this.mHeight = 0;
      this.biggest = null;
      this.biggestDimension = 0;
      int j = this.mCount;
      for (int i = 0; i < j; i++) {
        if (this.mStartIndex + i >= Flow.this.mDisplayedWidgetsCount)
          return; 
        ConstraintWidget constraintWidget = Flow.this.mDisplayedWidgets[this.mStartIndex + i];
        if (this.mOrientation == 0) {
          int m = constraintWidget.getWidth();
          int k = Flow.this.mHorizontalGap;
          if (constraintWidget.getVisibility() == 8)
            k = 0; 
          this.mWidth += m + k;
          k = Flow.this.getWidgetHeight(constraintWidget, this.mMax);
          if (this.biggest == null || this.biggestDimension < k) {
            this.biggest = constraintWidget;
            this.biggestDimension = k;
            this.mHeight = k;
          } 
        } else {
          int m = Flow.this.getWidgetWidth(constraintWidget, this.mMax);
          int n = Flow.this.getWidgetHeight(constraintWidget, this.mMax);
          int k = Flow.this.mVerticalGap;
          if (constraintWidget.getVisibility() == 8)
            k = 0; 
          this.mHeight += n + k;
          if (this.biggest == null || this.biggestDimension < m) {
            this.biggest = constraintWidget;
            this.biggestDimension = m;
            this.mWidth = m;
          } 
        } 
      } 
    }
    
    public void add(ConstraintWidget param1ConstraintWidget) {
      int i = this.mOrientation;
      int j = 0;
      int k = 0;
      if (i == 0) {
        i = Flow.this.getWidgetWidth(param1ConstraintWidget, this.mMax);
        if (param1ConstraintWidget.getHorizontalDimensionBehaviour() == ConstraintWidget.DimensionBehaviour.MATCH_CONSTRAINT) {
          this.mNbMatchConstraintsWidgets++;
          i = 0;
        } 
        j = Flow.this.mHorizontalGap;
        if (param1ConstraintWidget.getVisibility() == 8)
          j = k; 
        this.mWidth += i + j;
        i = Flow.this.getWidgetHeight(param1ConstraintWidget, this.mMax);
        if (this.biggest == null || this.biggestDimension < i) {
          this.biggest = param1ConstraintWidget;
          this.biggestDimension = i;
          this.mHeight = i;
        } 
      } else {
        int m = Flow.this.getWidgetWidth(param1ConstraintWidget, this.mMax);
        i = Flow.this.getWidgetHeight(param1ConstraintWidget, this.mMax);
        if (param1ConstraintWidget.getVerticalDimensionBehaviour() == ConstraintWidget.DimensionBehaviour.MATCH_CONSTRAINT) {
          this.mNbMatchConstraintsWidgets++;
          i = 0;
        } 
        k = Flow.this.mVerticalGap;
        if (param1ConstraintWidget.getVisibility() != 8)
          j = k; 
        this.mHeight += i + j;
        if (this.biggest == null || this.biggestDimension < m) {
          this.biggest = param1ConstraintWidget;
          this.biggestDimension = m;
          this.mWidth = m;
        } 
      } 
      this.mCount++;
    }
    
    public void clear() {
      this.biggestDimension = 0;
      this.biggest = null;
      this.mWidth = 0;
      this.mHeight = 0;
      this.mStartIndex = 0;
      this.mCount = 0;
      this.mNbMatchConstraintsWidgets = 0;
    }
    
    public void createConstraints(boolean param1Boolean1, int param1Int, boolean param1Boolean2) {
      // Byte code:
      //   0: aload_0
      //   1: getfield mCount : I
      //   4: istore #13
      //   6: iconst_0
      //   7: istore #6
      //   9: iload #6
      //   11: iload #13
      //   13: if_icmpge -> 72
      //   16: aload_0
      //   17: getfield mStartIndex : I
      //   20: iload #6
      //   22: iadd
      //   23: aload_0
      //   24: getfield this$0 : Landroidx/constraintlayout/solver/widgets/Flow;
      //   27: invokestatic access$400 : (Landroidx/constraintlayout/solver/widgets/Flow;)I
      //   30: if_icmplt -> 36
      //   33: goto -> 72
      //   36: aload_0
      //   37: getfield this$0 : Landroidx/constraintlayout/solver/widgets/Flow;
      //   40: invokestatic access$500 : (Landroidx/constraintlayout/solver/widgets/Flow;)[Landroidx/constraintlayout/solver/widgets/ConstraintWidget;
      //   43: aload_0
      //   44: getfield mStartIndex : I
      //   47: iload #6
      //   49: iadd
      //   50: aaload
      //   51: astore #14
      //   53: aload #14
      //   55: ifnull -> 63
      //   58: aload #14
      //   60: invokevirtual resetAnchors : ()V
      //   63: iload #6
      //   65: iconst_1
      //   66: iadd
      //   67: istore #6
      //   69: goto -> 9
      //   72: iload #13
      //   74: ifeq -> 1677
      //   77: aload_0
      //   78: getfield biggest : Landroidx/constraintlayout/solver/widgets/ConstraintWidget;
      //   81: ifnonnull -> 85
      //   84: return
      //   85: iload_3
      //   86: ifeq -> 99
      //   89: iload_2
      //   90: ifne -> 99
      //   93: iconst_1
      //   94: istore #9
      //   96: goto -> 102
      //   99: iconst_0
      //   100: istore #9
      //   102: iconst_0
      //   103: istore #6
      //   105: iconst_m1
      //   106: istore #7
      //   108: iconst_m1
      //   109: istore #8
      //   111: iload #6
      //   113: iload #13
      //   115: if_icmpge -> 226
      //   118: iload_1
      //   119: ifeq -> 134
      //   122: iload #13
      //   124: iconst_1
      //   125: isub
      //   126: iload #6
      //   128: isub
      //   129: istore #12
      //   131: goto -> 138
      //   134: iload #6
      //   136: istore #12
      //   138: aload_0
      //   139: getfield mStartIndex : I
      //   142: iload #12
      //   144: iadd
      //   145: aload_0
      //   146: getfield this$0 : Landroidx/constraintlayout/solver/widgets/Flow;
      //   149: invokestatic access$400 : (Landroidx/constraintlayout/solver/widgets/Flow;)I
      //   152: if_icmplt -> 158
      //   155: goto -> 226
      //   158: iload #7
      //   160: istore #10
      //   162: iload #8
      //   164: istore #11
      //   166: aload_0
      //   167: getfield this$0 : Landroidx/constraintlayout/solver/widgets/Flow;
      //   170: invokestatic access$500 : (Landroidx/constraintlayout/solver/widgets/Flow;)[Landroidx/constraintlayout/solver/widgets/ConstraintWidget;
      //   173: aload_0
      //   174: getfield mStartIndex : I
      //   177: iload #12
      //   179: iadd
      //   180: aaload
      //   181: invokevirtual getVisibility : ()I
      //   184: ifne -> 209
      //   187: iload #7
      //   189: istore #8
      //   191: iload #7
      //   193: iconst_m1
      //   194: if_icmpne -> 201
      //   197: iload #6
      //   199: istore #8
      //   201: iload #6
      //   203: istore #11
      //   205: iload #8
      //   207: istore #10
      //   209: iload #6
      //   211: iconst_1
      //   212: iadd
      //   213: istore #6
      //   215: iload #10
      //   217: istore #7
      //   219: iload #11
      //   221: istore #8
      //   223: goto -> 111
      //   226: aconst_null
      //   227: astore #14
      //   229: aconst_null
      //   230: astore #15
      //   232: aload_0
      //   233: getfield mOrientation : I
      //   236: ifne -> 961
      //   239: aload_0
      //   240: getfield biggest : Landroidx/constraintlayout/solver/widgets/ConstraintWidget;
      //   243: astore #16
      //   245: aload #16
      //   247: aload_0
      //   248: getfield this$0 : Landroidx/constraintlayout/solver/widgets/Flow;
      //   251: invokestatic access$600 : (Landroidx/constraintlayout/solver/widgets/Flow;)I
      //   254: invokevirtual setVerticalChainStyle : (I)V
      //   257: aload_0
      //   258: getfield mPaddingTop : I
      //   261: istore #10
      //   263: iload #10
      //   265: istore #6
      //   267: iload_2
      //   268: ifle -> 283
      //   271: iload #10
      //   273: aload_0
      //   274: getfield this$0 : Landroidx/constraintlayout/solver/widgets/Flow;
      //   277: invokestatic access$100 : (Landroidx/constraintlayout/solver/widgets/Flow;)I
      //   280: iadd
      //   281: istore #6
      //   283: aload #16
      //   285: getfield mTop : Landroidx/constraintlayout/solver/widgets/ConstraintAnchor;
      //   288: aload_0
      //   289: getfield mTop : Landroidx/constraintlayout/solver/widgets/ConstraintAnchor;
      //   292: iload #6
      //   294: invokevirtual connect : (Landroidx/constraintlayout/solver/widgets/ConstraintAnchor;I)Z
      //   297: pop
      //   298: iload_3
      //   299: ifeq -> 319
      //   302: aload #16
      //   304: getfield mBottom : Landroidx/constraintlayout/solver/widgets/ConstraintAnchor;
      //   307: aload_0
      //   308: getfield mBottom : Landroidx/constraintlayout/solver/widgets/ConstraintAnchor;
      //   311: aload_0
      //   312: getfield mPaddingBottom : I
      //   315: invokevirtual connect : (Landroidx/constraintlayout/solver/widgets/ConstraintAnchor;I)Z
      //   318: pop
      //   319: iload_2
      //   320: ifle -> 343
      //   323: aload_0
      //   324: getfield mTop : Landroidx/constraintlayout/solver/widgets/ConstraintAnchor;
      //   327: getfield mOwner : Landroidx/constraintlayout/solver/widgets/ConstraintWidget;
      //   330: getfield mBottom : Landroidx/constraintlayout/solver/widgets/ConstraintAnchor;
      //   333: aload #16
      //   335: getfield mTop : Landroidx/constraintlayout/solver/widgets/ConstraintAnchor;
      //   338: iconst_0
      //   339: invokevirtual connect : (Landroidx/constraintlayout/solver/widgets/ConstraintAnchor;I)Z
      //   342: pop
      //   343: aload_0
      //   344: getfield this$0 : Landroidx/constraintlayout/solver/widgets/Flow;
      //   347: invokestatic access$700 : (Landroidx/constraintlayout/solver/widgets/Flow;)I
      //   350: iconst_3
      //   351: if_icmpne -> 443
      //   354: aload #16
      //   356: invokevirtual hasBaseline : ()Z
      //   359: ifne -> 443
      //   362: iconst_0
      //   363: istore_2
      //   364: iload_2
      //   365: iload #13
      //   367: if_icmpge -> 443
      //   370: iload_1
      //   371: ifeq -> 385
      //   374: iload #13
      //   376: iconst_1
      //   377: isub
      //   378: iload_2
      //   379: isub
      //   380: istore #6
      //   382: goto -> 388
      //   385: iload_2
      //   386: istore #6
      //   388: aload_0
      //   389: getfield mStartIndex : I
      //   392: iload #6
      //   394: iadd
      //   395: aload_0
      //   396: getfield this$0 : Landroidx/constraintlayout/solver/widgets/Flow;
      //   399: invokestatic access$400 : (Landroidx/constraintlayout/solver/widgets/Flow;)I
      //   402: if_icmplt -> 408
      //   405: goto -> 443
      //   408: aload_0
      //   409: getfield this$0 : Landroidx/constraintlayout/solver/widgets/Flow;
      //   412: invokestatic access$500 : (Landroidx/constraintlayout/solver/widgets/Flow;)[Landroidx/constraintlayout/solver/widgets/ConstraintWidget;
      //   415: aload_0
      //   416: getfield mStartIndex : I
      //   419: iload #6
      //   421: iadd
      //   422: aaload
      //   423: astore #14
      //   425: aload #14
      //   427: invokevirtual hasBaseline : ()Z
      //   430: ifeq -> 436
      //   433: goto -> 447
      //   436: iload_2
      //   437: iconst_1
      //   438: iadd
      //   439: istore_2
      //   440: goto -> 364
      //   443: aload #16
      //   445: astore #14
      //   447: iconst_0
      //   448: istore_2
      //   449: iload_2
      //   450: iload #13
      //   452: if_icmpge -> 1677
      //   455: iload_1
      //   456: ifeq -> 470
      //   459: iload #13
      //   461: iconst_1
      //   462: isub
      //   463: iload_2
      //   464: isub
      //   465: istore #6
      //   467: goto -> 473
      //   470: iload_2
      //   471: istore #6
      //   473: aload_0
      //   474: getfield mStartIndex : I
      //   477: iload #6
      //   479: iadd
      //   480: aload_0
      //   481: getfield this$0 : Landroidx/constraintlayout/solver/widgets/Flow;
      //   484: invokestatic access$400 : (Landroidx/constraintlayout/solver/widgets/Flow;)I
      //   487: if_icmplt -> 491
      //   490: return
      //   491: aload_0
      //   492: getfield this$0 : Landroidx/constraintlayout/solver/widgets/Flow;
      //   495: invokestatic access$500 : (Landroidx/constraintlayout/solver/widgets/Flow;)[Landroidx/constraintlayout/solver/widgets/ConstraintWidget;
      //   498: aload_0
      //   499: getfield mStartIndex : I
      //   502: iload #6
      //   504: iadd
      //   505: aaload
      //   506: astore #17
      //   508: iload_2
      //   509: ifne -> 530
      //   512: aload #17
      //   514: aload #17
      //   516: getfield mLeft : Landroidx/constraintlayout/solver/widgets/ConstraintAnchor;
      //   519: aload_0
      //   520: getfield mLeft : Landroidx/constraintlayout/solver/widgets/ConstraintAnchor;
      //   523: aload_0
      //   524: getfield mPaddingLeft : I
      //   527: invokevirtual connect : (Landroidx/constraintlayout/solver/widgets/ConstraintAnchor;Landroidx/constraintlayout/solver/widgets/ConstraintAnchor;I)V
      //   530: iload #6
      //   532: ifne -> 655
      //   535: aload_0
      //   536: getfield this$0 : Landroidx/constraintlayout/solver/widgets/Flow;
      //   539: invokestatic access$800 : (Landroidx/constraintlayout/solver/widgets/Flow;)I
      //   542: istore #10
      //   544: aload_0
      //   545: getfield this$0 : Landroidx/constraintlayout/solver/widgets/Flow;
      //   548: invokestatic access$900 : (Landroidx/constraintlayout/solver/widgets/Flow;)F
      //   551: fstore #5
      //   553: aload_0
      //   554: getfield mStartIndex : I
      //   557: ifne -> 592
      //   560: aload_0
      //   561: getfield this$0 : Landroidx/constraintlayout/solver/widgets/Flow;
      //   564: invokestatic access$1000 : (Landroidx/constraintlayout/solver/widgets/Flow;)I
      //   567: iconst_m1
      //   568: if_icmpeq -> 592
      //   571: aload_0
      //   572: getfield this$0 : Landroidx/constraintlayout/solver/widgets/Flow;
      //   575: invokestatic access$1000 : (Landroidx/constraintlayout/solver/widgets/Flow;)I
      //   578: istore #6
      //   580: aload_0
      //   581: getfield this$0 : Landroidx/constraintlayout/solver/widgets/Flow;
      //   584: invokestatic access$1100 : (Landroidx/constraintlayout/solver/widgets/Flow;)F
      //   587: fstore #4
      //   589: goto -> 641
      //   592: iload #10
      //   594: istore #6
      //   596: fload #5
      //   598: fstore #4
      //   600: iload_3
      //   601: ifeq -> 641
      //   604: iload #10
      //   606: istore #6
      //   608: fload #5
      //   610: fstore #4
      //   612: aload_0
      //   613: getfield this$0 : Landroidx/constraintlayout/solver/widgets/Flow;
      //   616: invokestatic access$1200 : (Landroidx/constraintlayout/solver/widgets/Flow;)I
      //   619: iconst_m1
      //   620: if_icmpeq -> 641
      //   623: aload_0
      //   624: getfield this$0 : Landroidx/constraintlayout/solver/widgets/Flow;
      //   627: invokestatic access$1200 : (Landroidx/constraintlayout/solver/widgets/Flow;)I
      //   630: istore #6
      //   632: aload_0
      //   633: getfield this$0 : Landroidx/constraintlayout/solver/widgets/Flow;
      //   636: invokestatic access$1300 : (Landroidx/constraintlayout/solver/widgets/Flow;)F
      //   639: fstore #4
      //   641: aload #17
      //   643: iload #6
      //   645: invokevirtual setHorizontalChainStyle : (I)V
      //   648: aload #17
      //   650: fload #4
      //   652: invokevirtual setHorizontalBiasPercent : (F)V
      //   655: iload_2
      //   656: iload #13
      //   658: iconst_1
      //   659: isub
      //   660: if_icmpne -> 681
      //   663: aload #17
      //   665: aload #17
      //   667: getfield mRight : Landroidx/constraintlayout/solver/widgets/ConstraintAnchor;
      //   670: aload_0
      //   671: getfield mRight : Landroidx/constraintlayout/solver/widgets/ConstraintAnchor;
      //   674: aload_0
      //   675: getfield mPaddingRight : I
      //   678: invokevirtual connect : (Landroidx/constraintlayout/solver/widgets/ConstraintAnchor;Landroidx/constraintlayout/solver/widgets/ConstraintAnchor;I)V
      //   681: aload #15
      //   683: ifnull -> 760
      //   686: aload #17
      //   688: getfield mLeft : Landroidx/constraintlayout/solver/widgets/ConstraintAnchor;
      //   691: aload #15
      //   693: getfield mRight : Landroidx/constraintlayout/solver/widgets/ConstraintAnchor;
      //   696: aload_0
      //   697: getfield this$0 : Landroidx/constraintlayout/solver/widgets/Flow;
      //   700: invokestatic access$000 : (Landroidx/constraintlayout/solver/widgets/Flow;)I
      //   703: invokevirtual connect : (Landroidx/constraintlayout/solver/widgets/ConstraintAnchor;I)Z
      //   706: pop
      //   707: iload_2
      //   708: iload #7
      //   710: if_icmpne -> 725
      //   713: aload #17
      //   715: getfield mLeft : Landroidx/constraintlayout/solver/widgets/ConstraintAnchor;
      //   718: aload_0
      //   719: getfield mPaddingLeft : I
      //   722: invokevirtual setGoneMargin : (I)V
      //   725: aload #15
      //   727: getfield mRight : Landroidx/constraintlayout/solver/widgets/ConstraintAnchor;
      //   730: aload #17
      //   732: getfield mLeft : Landroidx/constraintlayout/solver/widgets/ConstraintAnchor;
      //   735: iconst_0
      //   736: invokevirtual connect : (Landroidx/constraintlayout/solver/widgets/ConstraintAnchor;I)Z
      //   739: pop
      //   740: iload_2
      //   741: iload #8
      //   743: iconst_1
      //   744: iadd
      //   745: if_icmpne -> 760
      //   748: aload #15
      //   750: getfield mRight : Landroidx/constraintlayout/solver/widgets/ConstraintAnchor;
      //   753: aload_0
      //   754: getfield mPaddingRight : I
      //   757: invokevirtual setGoneMargin : (I)V
      //   760: aload #17
      //   762: aload #16
      //   764: if_acmpeq -> 950
      //   767: aload_0
      //   768: getfield this$0 : Landroidx/constraintlayout/solver/widgets/Flow;
      //   771: invokestatic access$700 : (Landroidx/constraintlayout/solver/widgets/Flow;)I
      //   774: iconst_3
      //   775: if_icmpne -> 819
      //   778: aload #14
      //   780: invokevirtual hasBaseline : ()Z
      //   783: ifeq -> 819
      //   786: aload #17
      //   788: aload #14
      //   790: if_acmpeq -> 819
      //   793: aload #17
      //   795: invokevirtual hasBaseline : ()Z
      //   798: ifeq -> 819
      //   801: aload #17
      //   803: getfield mBaseline : Landroidx/constraintlayout/solver/widgets/ConstraintAnchor;
      //   806: aload #14
      //   808: getfield mBaseline : Landroidx/constraintlayout/solver/widgets/ConstraintAnchor;
      //   811: iconst_0
      //   812: invokevirtual connect : (Landroidx/constraintlayout/solver/widgets/ConstraintAnchor;I)Z
      //   815: pop
      //   816: goto -> 950
      //   819: aload_0
      //   820: getfield this$0 : Landroidx/constraintlayout/solver/widgets/Flow;
      //   823: invokestatic access$700 : (Landroidx/constraintlayout/solver/widgets/Flow;)I
      //   826: istore #6
      //   828: iload #6
      //   830: ifeq -> 932
      //   833: iload #6
      //   835: iconst_1
      //   836: if_icmpeq -> 914
      //   839: iload #9
      //   841: ifeq -> 881
      //   844: aload #17
      //   846: getfield mTop : Landroidx/constraintlayout/solver/widgets/ConstraintAnchor;
      //   849: aload_0
      //   850: getfield mTop : Landroidx/constraintlayout/solver/widgets/ConstraintAnchor;
      //   853: aload_0
      //   854: getfield mPaddingTop : I
      //   857: invokevirtual connect : (Landroidx/constraintlayout/solver/widgets/ConstraintAnchor;I)Z
      //   860: pop
      //   861: aload #17
      //   863: getfield mBottom : Landroidx/constraintlayout/solver/widgets/ConstraintAnchor;
      //   866: aload_0
      //   867: getfield mBottom : Landroidx/constraintlayout/solver/widgets/ConstraintAnchor;
      //   870: aload_0
      //   871: getfield mPaddingBottom : I
      //   874: invokevirtual connect : (Landroidx/constraintlayout/solver/widgets/ConstraintAnchor;I)Z
      //   877: pop
      //   878: goto -> 950
      //   881: aload #17
      //   883: getfield mTop : Landroidx/constraintlayout/solver/widgets/ConstraintAnchor;
      //   886: aload #16
      //   888: getfield mTop : Landroidx/constraintlayout/solver/widgets/ConstraintAnchor;
      //   891: iconst_0
      //   892: invokevirtual connect : (Landroidx/constraintlayout/solver/widgets/ConstraintAnchor;I)Z
      //   895: pop
      //   896: aload #17
      //   898: getfield mBottom : Landroidx/constraintlayout/solver/widgets/ConstraintAnchor;
      //   901: aload #16
      //   903: getfield mBottom : Landroidx/constraintlayout/solver/widgets/ConstraintAnchor;
      //   906: iconst_0
      //   907: invokevirtual connect : (Landroidx/constraintlayout/solver/widgets/ConstraintAnchor;I)Z
      //   910: pop
      //   911: goto -> 950
      //   914: aload #17
      //   916: getfield mBottom : Landroidx/constraintlayout/solver/widgets/ConstraintAnchor;
      //   919: aload #16
      //   921: getfield mBottom : Landroidx/constraintlayout/solver/widgets/ConstraintAnchor;
      //   924: iconst_0
      //   925: invokevirtual connect : (Landroidx/constraintlayout/solver/widgets/ConstraintAnchor;I)Z
      //   928: pop
      //   929: goto -> 950
      //   932: aload #17
      //   934: getfield mTop : Landroidx/constraintlayout/solver/widgets/ConstraintAnchor;
      //   937: aload #16
      //   939: getfield mTop : Landroidx/constraintlayout/solver/widgets/ConstraintAnchor;
      //   942: iconst_0
      //   943: invokevirtual connect : (Landroidx/constraintlayout/solver/widgets/ConstraintAnchor;I)Z
      //   946: pop
      //   947: goto -> 950
      //   950: iload_2
      //   951: iconst_1
      //   952: iadd
      //   953: istore_2
      //   954: aload #17
      //   956: astore #15
      //   958: goto -> 449
      //   961: aload_0
      //   962: getfield biggest : Landroidx/constraintlayout/solver/widgets/ConstraintWidget;
      //   965: astore #16
      //   967: aload #16
      //   969: aload_0
      //   970: getfield this$0 : Landroidx/constraintlayout/solver/widgets/Flow;
      //   973: invokestatic access$800 : (Landroidx/constraintlayout/solver/widgets/Flow;)I
      //   976: invokevirtual setHorizontalChainStyle : (I)V
      //   979: aload_0
      //   980: getfield mPaddingLeft : I
      //   983: istore #10
      //   985: iload #10
      //   987: istore #6
      //   989: iload_2
      //   990: ifle -> 1005
      //   993: iload #10
      //   995: aload_0
      //   996: getfield this$0 : Landroidx/constraintlayout/solver/widgets/Flow;
      //   999: invokestatic access$000 : (Landroidx/constraintlayout/solver/widgets/Flow;)I
      //   1002: iadd
      //   1003: istore #6
      //   1005: iload_1
      //   1006: ifeq -> 1072
      //   1009: aload #16
      //   1011: getfield mRight : Landroidx/constraintlayout/solver/widgets/ConstraintAnchor;
      //   1014: aload_0
      //   1015: getfield mRight : Landroidx/constraintlayout/solver/widgets/ConstraintAnchor;
      //   1018: iload #6
      //   1020: invokevirtual connect : (Landroidx/constraintlayout/solver/widgets/ConstraintAnchor;I)Z
      //   1023: pop
      //   1024: iload_3
      //   1025: ifeq -> 1045
      //   1028: aload #16
      //   1030: getfield mLeft : Landroidx/constraintlayout/solver/widgets/ConstraintAnchor;
      //   1033: aload_0
      //   1034: getfield mLeft : Landroidx/constraintlayout/solver/widgets/ConstraintAnchor;
      //   1037: aload_0
      //   1038: getfield mPaddingRight : I
      //   1041: invokevirtual connect : (Landroidx/constraintlayout/solver/widgets/ConstraintAnchor;I)Z
      //   1044: pop
      //   1045: iload_2
      //   1046: ifle -> 1132
      //   1049: aload_0
      //   1050: getfield mRight : Landroidx/constraintlayout/solver/widgets/ConstraintAnchor;
      //   1053: getfield mOwner : Landroidx/constraintlayout/solver/widgets/ConstraintWidget;
      //   1056: getfield mLeft : Landroidx/constraintlayout/solver/widgets/ConstraintAnchor;
      //   1059: aload #16
      //   1061: getfield mRight : Landroidx/constraintlayout/solver/widgets/ConstraintAnchor;
      //   1064: iconst_0
      //   1065: invokevirtual connect : (Landroidx/constraintlayout/solver/widgets/ConstraintAnchor;I)Z
      //   1068: pop
      //   1069: goto -> 1132
      //   1072: aload #16
      //   1074: getfield mLeft : Landroidx/constraintlayout/solver/widgets/ConstraintAnchor;
      //   1077: aload_0
      //   1078: getfield mLeft : Landroidx/constraintlayout/solver/widgets/ConstraintAnchor;
      //   1081: iload #6
      //   1083: invokevirtual connect : (Landroidx/constraintlayout/solver/widgets/ConstraintAnchor;I)Z
      //   1086: pop
      //   1087: iload_3
      //   1088: ifeq -> 1108
      //   1091: aload #16
      //   1093: getfield mRight : Landroidx/constraintlayout/solver/widgets/ConstraintAnchor;
      //   1096: aload_0
      //   1097: getfield mRight : Landroidx/constraintlayout/solver/widgets/ConstraintAnchor;
      //   1100: aload_0
      //   1101: getfield mPaddingRight : I
      //   1104: invokevirtual connect : (Landroidx/constraintlayout/solver/widgets/ConstraintAnchor;I)Z
      //   1107: pop
      //   1108: iload_2
      //   1109: ifle -> 1132
      //   1112: aload_0
      //   1113: getfield mLeft : Landroidx/constraintlayout/solver/widgets/ConstraintAnchor;
      //   1116: getfield mOwner : Landroidx/constraintlayout/solver/widgets/ConstraintWidget;
      //   1119: getfield mRight : Landroidx/constraintlayout/solver/widgets/ConstraintAnchor;
      //   1122: aload #16
      //   1124: getfield mLeft : Landroidx/constraintlayout/solver/widgets/ConstraintAnchor;
      //   1127: iconst_0
      //   1128: invokevirtual connect : (Landroidx/constraintlayout/solver/widgets/ConstraintAnchor;I)Z
      //   1131: pop
      //   1132: iconst_0
      //   1133: istore #6
      //   1135: iload #6
      //   1137: iload #13
      //   1139: if_icmpge -> 1677
      //   1142: aload_0
      //   1143: getfield mStartIndex : I
      //   1146: iload #6
      //   1148: iadd
      //   1149: aload_0
      //   1150: getfield this$0 : Landroidx/constraintlayout/solver/widgets/Flow;
      //   1153: invokestatic access$400 : (Landroidx/constraintlayout/solver/widgets/Flow;)I
      //   1156: if_icmplt -> 1160
      //   1159: return
      //   1160: aload_0
      //   1161: getfield this$0 : Landroidx/constraintlayout/solver/widgets/Flow;
      //   1164: invokestatic access$500 : (Landroidx/constraintlayout/solver/widgets/Flow;)[Landroidx/constraintlayout/solver/widgets/ConstraintWidget;
      //   1167: aload_0
      //   1168: getfield mStartIndex : I
      //   1171: iload #6
      //   1173: iadd
      //   1174: aaload
      //   1175: astore #15
      //   1177: iload #6
      //   1179: ifne -> 1315
      //   1182: aload #15
      //   1184: aload #15
      //   1186: getfield mTop : Landroidx/constraintlayout/solver/widgets/ConstraintAnchor;
      //   1189: aload_0
      //   1190: getfield mTop : Landroidx/constraintlayout/solver/widgets/ConstraintAnchor;
      //   1193: aload_0
      //   1194: getfield mPaddingTop : I
      //   1197: invokevirtual connect : (Landroidx/constraintlayout/solver/widgets/ConstraintAnchor;Landroidx/constraintlayout/solver/widgets/ConstraintAnchor;I)V
      //   1200: aload_0
      //   1201: getfield this$0 : Landroidx/constraintlayout/solver/widgets/Flow;
      //   1204: invokestatic access$600 : (Landroidx/constraintlayout/solver/widgets/Flow;)I
      //   1207: istore #10
      //   1209: aload_0
      //   1210: getfield this$0 : Landroidx/constraintlayout/solver/widgets/Flow;
      //   1213: invokestatic access$1400 : (Landroidx/constraintlayout/solver/widgets/Flow;)F
      //   1216: fstore #5
      //   1218: aload_0
      //   1219: getfield mStartIndex : I
      //   1222: ifne -> 1256
      //   1225: aload_0
      //   1226: getfield this$0 : Landroidx/constraintlayout/solver/widgets/Flow;
      //   1229: invokestatic access$1500 : (Landroidx/constraintlayout/solver/widgets/Flow;)I
      //   1232: iconst_m1
      //   1233: if_icmpeq -> 1256
      //   1236: aload_0
      //   1237: getfield this$0 : Landroidx/constraintlayout/solver/widgets/Flow;
      //   1240: invokestatic access$1500 : (Landroidx/constraintlayout/solver/widgets/Flow;)I
      //   1243: istore_2
      //   1244: aload_0
      //   1245: getfield this$0 : Landroidx/constraintlayout/solver/widgets/Flow;
      //   1248: invokestatic access$1600 : (Landroidx/constraintlayout/solver/widgets/Flow;)F
      //   1251: fstore #4
      //   1253: goto -> 1302
      //   1256: iload #10
      //   1258: istore_2
      //   1259: fload #5
      //   1261: fstore #4
      //   1263: iload_3
      //   1264: ifeq -> 1302
      //   1267: iload #10
      //   1269: istore_2
      //   1270: fload #5
      //   1272: fstore #4
      //   1274: aload_0
      //   1275: getfield this$0 : Landroidx/constraintlayout/solver/widgets/Flow;
      //   1278: invokestatic access$1700 : (Landroidx/constraintlayout/solver/widgets/Flow;)I
      //   1281: iconst_m1
      //   1282: if_icmpeq -> 1302
      //   1285: aload_0
      //   1286: getfield this$0 : Landroidx/constraintlayout/solver/widgets/Flow;
      //   1289: invokestatic access$1700 : (Landroidx/constraintlayout/solver/widgets/Flow;)I
      //   1292: istore_2
      //   1293: aload_0
      //   1294: getfield this$0 : Landroidx/constraintlayout/solver/widgets/Flow;
      //   1297: invokestatic access$1800 : (Landroidx/constraintlayout/solver/widgets/Flow;)F
      //   1300: fstore #4
      //   1302: aload #15
      //   1304: iload_2
      //   1305: invokevirtual setVerticalChainStyle : (I)V
      //   1308: aload #15
      //   1310: fload #4
      //   1312: invokevirtual setVerticalBiasPercent : (F)V
      //   1315: iload #6
      //   1317: iload #13
      //   1319: iconst_1
      //   1320: isub
      //   1321: if_icmpne -> 1342
      //   1324: aload #15
      //   1326: aload #15
      //   1328: getfield mBottom : Landroidx/constraintlayout/solver/widgets/ConstraintAnchor;
      //   1331: aload_0
      //   1332: getfield mBottom : Landroidx/constraintlayout/solver/widgets/ConstraintAnchor;
      //   1335: aload_0
      //   1336: getfield mPaddingBottom : I
      //   1339: invokevirtual connect : (Landroidx/constraintlayout/solver/widgets/ConstraintAnchor;Landroidx/constraintlayout/solver/widgets/ConstraintAnchor;I)V
      //   1342: aload #14
      //   1344: ifnull -> 1423
      //   1347: aload #15
      //   1349: getfield mTop : Landroidx/constraintlayout/solver/widgets/ConstraintAnchor;
      //   1352: aload #14
      //   1354: getfield mBottom : Landroidx/constraintlayout/solver/widgets/ConstraintAnchor;
      //   1357: aload_0
      //   1358: getfield this$0 : Landroidx/constraintlayout/solver/widgets/Flow;
      //   1361: invokestatic access$100 : (Landroidx/constraintlayout/solver/widgets/Flow;)I
      //   1364: invokevirtual connect : (Landroidx/constraintlayout/solver/widgets/ConstraintAnchor;I)Z
      //   1367: pop
      //   1368: iload #6
      //   1370: iload #7
      //   1372: if_icmpne -> 1387
      //   1375: aload #15
      //   1377: getfield mTop : Landroidx/constraintlayout/solver/widgets/ConstraintAnchor;
      //   1380: aload_0
      //   1381: getfield mPaddingTop : I
      //   1384: invokevirtual setGoneMargin : (I)V
      //   1387: aload #14
      //   1389: getfield mBottom : Landroidx/constraintlayout/solver/widgets/ConstraintAnchor;
      //   1392: aload #15
      //   1394: getfield mTop : Landroidx/constraintlayout/solver/widgets/ConstraintAnchor;
      //   1397: iconst_0
      //   1398: invokevirtual connect : (Landroidx/constraintlayout/solver/widgets/ConstraintAnchor;I)Z
      //   1401: pop
      //   1402: iload #6
      //   1404: iload #8
      //   1406: iconst_1
      //   1407: iadd
      //   1408: if_icmpne -> 1423
      //   1411: aload #14
      //   1413: getfield mBottom : Landroidx/constraintlayout/solver/widgets/ConstraintAnchor;
      //   1416: aload_0
      //   1417: getfield mPaddingBottom : I
      //   1420: invokevirtual setGoneMargin : (I)V
      //   1423: aload #15
      //   1425: aload #16
      //   1427: if_acmpeq -> 1664
      //   1430: iload_1
      //   1431: ifeq -> 1528
      //   1434: aload_0
      //   1435: getfield this$0 : Landroidx/constraintlayout/solver/widgets/Flow;
      //   1438: invokestatic access$1900 : (Landroidx/constraintlayout/solver/widgets/Flow;)I
      //   1441: istore_2
      //   1442: iload_2
      //   1443: ifeq -> 1510
      //   1446: iload_2
      //   1447: iconst_1
      //   1448: if_icmpeq -> 1492
      //   1451: iload_2
      //   1452: iconst_2
      //   1453: if_icmpeq -> 1459
      //   1456: goto -> 1664
      //   1459: aload #15
      //   1461: getfield mLeft : Landroidx/constraintlayout/solver/widgets/ConstraintAnchor;
      //   1464: aload #16
      //   1466: getfield mLeft : Landroidx/constraintlayout/solver/widgets/ConstraintAnchor;
      //   1469: iconst_0
      //   1470: invokevirtual connect : (Landroidx/constraintlayout/solver/widgets/ConstraintAnchor;I)Z
      //   1473: pop
      //   1474: aload #15
      //   1476: getfield mRight : Landroidx/constraintlayout/solver/widgets/ConstraintAnchor;
      //   1479: aload #16
      //   1481: getfield mRight : Landroidx/constraintlayout/solver/widgets/ConstraintAnchor;
      //   1484: iconst_0
      //   1485: invokevirtual connect : (Landroidx/constraintlayout/solver/widgets/ConstraintAnchor;I)Z
      //   1488: pop
      //   1489: goto -> 1664
      //   1492: aload #15
      //   1494: getfield mLeft : Landroidx/constraintlayout/solver/widgets/ConstraintAnchor;
      //   1497: aload #16
      //   1499: getfield mLeft : Landroidx/constraintlayout/solver/widgets/ConstraintAnchor;
      //   1502: iconst_0
      //   1503: invokevirtual connect : (Landroidx/constraintlayout/solver/widgets/ConstraintAnchor;I)Z
      //   1506: pop
      //   1507: goto -> 1664
      //   1510: aload #15
      //   1512: getfield mRight : Landroidx/constraintlayout/solver/widgets/ConstraintAnchor;
      //   1515: aload #16
      //   1517: getfield mRight : Landroidx/constraintlayout/solver/widgets/ConstraintAnchor;
      //   1520: iconst_0
      //   1521: invokevirtual connect : (Landroidx/constraintlayout/solver/widgets/ConstraintAnchor;I)Z
      //   1524: pop
      //   1525: goto -> 1664
      //   1528: aload_0
      //   1529: getfield this$0 : Landroidx/constraintlayout/solver/widgets/Flow;
      //   1532: invokestatic access$1900 : (Landroidx/constraintlayout/solver/widgets/Flow;)I
      //   1535: istore_2
      //   1536: iload_2
      //   1537: ifeq -> 1646
      //   1540: iload_2
      //   1541: iconst_1
      //   1542: if_icmpeq -> 1628
      //   1545: iload_2
      //   1546: iconst_2
      //   1547: if_icmpeq -> 1553
      //   1550: goto -> 1664
      //   1553: iload #9
      //   1555: ifeq -> 1595
      //   1558: aload #15
      //   1560: getfield mLeft : Landroidx/constraintlayout/solver/widgets/ConstraintAnchor;
      //   1563: aload_0
      //   1564: getfield mLeft : Landroidx/constraintlayout/solver/widgets/ConstraintAnchor;
      //   1567: aload_0
      //   1568: getfield mPaddingLeft : I
      //   1571: invokevirtual connect : (Landroidx/constraintlayout/solver/widgets/ConstraintAnchor;I)Z
      //   1574: pop
      //   1575: aload #15
      //   1577: getfield mRight : Landroidx/constraintlayout/solver/widgets/ConstraintAnchor;
      //   1580: aload_0
      //   1581: getfield mRight : Landroidx/constraintlayout/solver/widgets/ConstraintAnchor;
      //   1584: aload_0
      //   1585: getfield mPaddingRight : I
      //   1588: invokevirtual connect : (Landroidx/constraintlayout/solver/widgets/ConstraintAnchor;I)Z
      //   1591: pop
      //   1592: goto -> 1664
      //   1595: aload #15
      //   1597: getfield mLeft : Landroidx/constraintlayout/solver/widgets/ConstraintAnchor;
      //   1600: aload #16
      //   1602: getfield mLeft : Landroidx/constraintlayout/solver/widgets/ConstraintAnchor;
      //   1605: iconst_0
      //   1606: invokevirtual connect : (Landroidx/constraintlayout/solver/widgets/ConstraintAnchor;I)Z
      //   1609: pop
      //   1610: aload #15
      //   1612: getfield mRight : Landroidx/constraintlayout/solver/widgets/ConstraintAnchor;
      //   1615: aload #16
      //   1617: getfield mRight : Landroidx/constraintlayout/solver/widgets/ConstraintAnchor;
      //   1620: iconst_0
      //   1621: invokevirtual connect : (Landroidx/constraintlayout/solver/widgets/ConstraintAnchor;I)Z
      //   1624: pop
      //   1625: goto -> 1664
      //   1628: aload #15
      //   1630: getfield mRight : Landroidx/constraintlayout/solver/widgets/ConstraintAnchor;
      //   1633: aload #16
      //   1635: getfield mRight : Landroidx/constraintlayout/solver/widgets/ConstraintAnchor;
      //   1638: iconst_0
      //   1639: invokevirtual connect : (Landroidx/constraintlayout/solver/widgets/ConstraintAnchor;I)Z
      //   1642: pop
      //   1643: goto -> 1664
      //   1646: aload #15
      //   1648: getfield mLeft : Landroidx/constraintlayout/solver/widgets/ConstraintAnchor;
      //   1651: aload #16
      //   1653: getfield mLeft : Landroidx/constraintlayout/solver/widgets/ConstraintAnchor;
      //   1656: iconst_0
      //   1657: invokevirtual connect : (Landroidx/constraintlayout/solver/widgets/ConstraintAnchor;I)Z
      //   1660: pop
      //   1661: goto -> 1664
      //   1664: iload #6
      //   1666: iconst_1
      //   1667: iadd
      //   1668: istore #6
      //   1670: aload #15
      //   1672: astore #14
      //   1674: goto -> 1135
      //   1677: return
    }
    
    public int getHeight() {
      return (this.mOrientation == 1) ? (this.mHeight - Flow.this.mVerticalGap) : this.mHeight;
    }
    
    public int getWidth() {
      return (this.mOrientation == 0) ? (this.mWidth - Flow.this.mHorizontalGap) : this.mWidth;
    }
    
    public void measureMatchConstraints(int param1Int) {
      int j = this.mNbMatchConstraintsWidgets;
      if (j == 0)
        return; 
      int i = this.mCount;
      j = param1Int / j;
      for (param1Int = 0; param1Int < i && this.mStartIndex + param1Int < Flow.this.mDisplayedWidgetsCount; param1Int++) {
        ConstraintWidget constraintWidget = Flow.this.mDisplayedWidgets[this.mStartIndex + param1Int];
        if (this.mOrientation == 0) {
          if (constraintWidget != null && constraintWidget.getHorizontalDimensionBehaviour() == ConstraintWidget.DimensionBehaviour.MATCH_CONSTRAINT && constraintWidget.mMatchConstraintDefaultWidth == 0)
            Flow.this.measure(constraintWidget, ConstraintWidget.DimensionBehaviour.FIXED, j, constraintWidget.getVerticalDimensionBehaviour(), constraintWidget.getHeight()); 
        } else if (constraintWidget != null && constraintWidget.getVerticalDimensionBehaviour() == ConstraintWidget.DimensionBehaviour.MATCH_CONSTRAINT && constraintWidget.mMatchConstraintDefaultHeight == 0) {
          Flow.this.measure(constraintWidget, constraintWidget.getHorizontalDimensionBehaviour(), constraintWidget.getWidth(), ConstraintWidget.DimensionBehaviour.FIXED, j);
        } 
      } 
      recomputeDimensions();
    }
    
    public void setStartIndex(int param1Int) {
      this.mStartIndex = param1Int;
    }
    
    public void setup(int param1Int1, ConstraintAnchor param1ConstraintAnchor1, ConstraintAnchor param1ConstraintAnchor2, ConstraintAnchor param1ConstraintAnchor3, ConstraintAnchor param1ConstraintAnchor4, int param1Int2, int param1Int3, int param1Int4, int param1Int5, int param1Int6) {
      this.mOrientation = param1Int1;
      this.mLeft = param1ConstraintAnchor1;
      this.mTop = param1ConstraintAnchor2;
      this.mRight = param1ConstraintAnchor3;
      this.mBottom = param1ConstraintAnchor4;
      this.mPaddingLeft = param1Int2;
      this.mPaddingTop = param1Int3;
      this.mPaddingRight = param1Int4;
      this.mPaddingBottom = param1Int5;
      this.mMax = param1Int6;
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\BabyBus TV_Kids Videos & Games-dex2jar.jar!\androidx\constraintlayout\solver\widgets\Flow.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */