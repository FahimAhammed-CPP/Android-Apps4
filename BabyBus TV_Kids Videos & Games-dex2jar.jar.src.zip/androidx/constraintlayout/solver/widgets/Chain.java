package androidx.constraintlayout.solver.widgets;

import androidx.constraintlayout.solver.LinearSystem;
import java.util.ArrayList;

public class Chain {
  private static final boolean DEBUG = false;
  
  public static final boolean USE_CHAIN_OPTIMIZATION = false;
  
  static void applyChainConstraints(ConstraintWidgetContainer paramConstraintWidgetContainer, LinearSystem paramLinearSystem, int paramInt1, int paramInt2, ChainHead paramChainHead) {
    // Byte code:
    //   0: aload #4
    //   2: getfield mFirst : Landroidx/constraintlayout/solver/widgets/ConstraintWidget;
    //   5: astore #21
    //   7: aload #4
    //   9: getfield mLast : Landroidx/constraintlayout/solver/widgets/ConstraintWidget;
    //   12: astore #27
    //   14: aload #4
    //   16: getfield mFirstVisibleWidget : Landroidx/constraintlayout/solver/widgets/ConstraintWidget;
    //   19: astore #20
    //   21: aload #4
    //   23: getfield mLastVisibleWidget : Landroidx/constraintlayout/solver/widgets/ConstraintWidget;
    //   26: astore #26
    //   28: aload #4
    //   30: getfield mHead : Landroidx/constraintlayout/solver/widgets/ConstraintWidget;
    //   33: astore #18
    //   35: aload #4
    //   37: getfield mTotalWeight : F
    //   40: fstore #5
    //   42: aload_0
    //   43: getfield mListDimensionBehaviors : [Landroidx/constraintlayout/solver/widgets/ConstraintWidget$DimensionBehaviour;
    //   46: iload_2
    //   47: aaload
    //   48: getstatic androidx/constraintlayout/solver/widgets/ConstraintWidget$DimensionBehaviour.WRAP_CONTENT : Landroidx/constraintlayout/solver/widgets/ConstraintWidget$DimensionBehaviour;
    //   51: if_acmpne -> 60
    //   54: iconst_1
    //   55: istore #12
    //   57: goto -> 63
    //   60: iconst_0
    //   61: istore #12
    //   63: iload_2
    //   64: ifne -> 120
    //   67: aload #18
    //   69: getfield mHorizontalChainStyle : I
    //   72: istore #13
    //   74: iload #13
    //   76: ifne -> 85
    //   79: iconst_1
    //   80: istore #8
    //   82: goto -> 88
    //   85: iconst_0
    //   86: istore #8
    //   88: iload #13
    //   90: iconst_1
    //   91: if_icmpne -> 100
    //   94: iconst_1
    //   95: istore #9
    //   97: goto -> 103
    //   100: iconst_0
    //   101: istore #9
    //   103: iload #8
    //   105: istore #10
    //   107: iload #9
    //   109: istore #11
    //   111: iload #13
    //   113: iconst_2
    //   114: if_icmpne -> 180
    //   117: goto -> 170
    //   120: aload #18
    //   122: getfield mVerticalChainStyle : I
    //   125: istore #13
    //   127: iload #13
    //   129: ifne -> 138
    //   132: iconst_1
    //   133: istore #8
    //   135: goto -> 141
    //   138: iconst_0
    //   139: istore #8
    //   141: iload #13
    //   143: iconst_1
    //   144: if_icmpne -> 153
    //   147: iconst_1
    //   148: istore #9
    //   150: goto -> 156
    //   153: iconst_0
    //   154: istore #9
    //   156: iload #8
    //   158: istore #10
    //   160: iload #9
    //   162: istore #11
    //   164: iload #13
    //   166: iconst_2
    //   167: if_icmpne -> 180
    //   170: iconst_1
    //   171: istore #13
    //   173: iload #8
    //   175: istore #10
    //   177: goto -> 187
    //   180: iconst_0
    //   181: istore #13
    //   183: iload #11
    //   185: istore #9
    //   187: aload #21
    //   189: astore #19
    //   191: iconst_0
    //   192: istore #8
    //   194: iload #9
    //   196: istore #11
    //   198: aconst_null
    //   199: astore #24
    //   201: aconst_null
    //   202: astore #22
    //   204: iload #8
    //   206: ifne -> 621
    //   209: aload #19
    //   211: getfield mListAnchors : [Landroidx/constraintlayout/solver/widgets/ConstraintAnchor;
    //   214: iload_3
    //   215: aaload
    //   216: astore #17
    //   218: iload #13
    //   220: ifeq -> 229
    //   223: iconst_1
    //   224: istore #9
    //   226: goto -> 232
    //   229: iconst_4
    //   230: istore #9
    //   232: aload #17
    //   234: invokevirtual getMargin : ()I
    //   237: istore #16
    //   239: aload #19
    //   241: getfield mListDimensionBehaviors : [Landroidx/constraintlayout/solver/widgets/ConstraintWidget$DimensionBehaviour;
    //   244: iload_2
    //   245: aaload
    //   246: astore #24
    //   248: getstatic androidx/constraintlayout/solver/widgets/ConstraintWidget$DimensionBehaviour.MATCH_CONSTRAINT : Landroidx/constraintlayout/solver/widgets/ConstraintWidget$DimensionBehaviour;
    //   251: astore #23
    //   253: aload #24
    //   255: aload #23
    //   257: if_acmpne -> 276
    //   260: aload #19
    //   262: getfield mResolvedMatchConstraintDefault : [I
    //   265: iload_2
    //   266: iaload
    //   267: ifne -> 276
    //   270: iconst_1
    //   271: istore #15
    //   273: goto -> 279
    //   276: iconst_0
    //   277: istore #15
    //   279: aload #17
    //   281: getfield mTarget : Landroidx/constraintlayout/solver/widgets/ConstraintAnchor;
    //   284: astore #24
    //   286: iload #16
    //   288: istore #14
    //   290: aload #24
    //   292: ifnull -> 316
    //   295: iload #16
    //   297: istore #14
    //   299: aload #19
    //   301: aload #21
    //   303: if_acmpeq -> 316
    //   306: iload #16
    //   308: aload #24
    //   310: invokevirtual getMargin : ()I
    //   313: iadd
    //   314: istore #14
    //   316: iload #13
    //   318: ifeq -> 342
    //   321: aload #19
    //   323: aload #21
    //   325: if_acmpeq -> 342
    //   328: aload #19
    //   330: aload #20
    //   332: if_acmpeq -> 342
    //   335: bipush #8
    //   337: istore #9
    //   339: goto -> 342
    //   342: aload #17
    //   344: getfield mTarget : Landroidx/constraintlayout/solver/widgets/ConstraintAnchor;
    //   347: astore #24
    //   349: aload #24
    //   351: ifnull -> 441
    //   354: aload #19
    //   356: aload #20
    //   358: if_acmpne -> 382
    //   361: aload_1
    //   362: aload #17
    //   364: getfield mSolverVariable : Landroidx/constraintlayout/solver/SolverVariable;
    //   367: aload #24
    //   369: getfield mSolverVariable : Landroidx/constraintlayout/solver/SolverVariable;
    //   372: iload #14
    //   374: bipush #6
    //   376: invokevirtual addGreaterThan : (Landroidx/constraintlayout/solver/SolverVariable;Landroidx/constraintlayout/solver/SolverVariable;II)V
    //   379: goto -> 400
    //   382: aload_1
    //   383: aload #17
    //   385: getfield mSolverVariable : Landroidx/constraintlayout/solver/SolverVariable;
    //   388: aload #24
    //   390: getfield mSolverVariable : Landroidx/constraintlayout/solver/SolverVariable;
    //   393: iload #14
    //   395: bipush #8
    //   397: invokevirtual addGreaterThan : (Landroidx/constraintlayout/solver/SolverVariable;Landroidx/constraintlayout/solver/SolverVariable;II)V
    //   400: iload #15
    //   402: ifeq -> 416
    //   405: iload #13
    //   407: ifne -> 416
    //   410: iconst_5
    //   411: istore #9
    //   413: goto -> 416
    //   416: aload_1
    //   417: aload #17
    //   419: getfield mSolverVariable : Landroidx/constraintlayout/solver/SolverVariable;
    //   422: aload #17
    //   424: getfield mTarget : Landroidx/constraintlayout/solver/widgets/ConstraintAnchor;
    //   427: getfield mSolverVariable : Landroidx/constraintlayout/solver/SolverVariable;
    //   430: iload #14
    //   432: iload #9
    //   434: invokevirtual addEquality : (Landroidx/constraintlayout/solver/SolverVariable;Landroidx/constraintlayout/solver/SolverVariable;II)Landroidx/constraintlayout/solver/ArrayRow;
    //   437: pop
    //   438: goto -> 441
    //   441: iload #12
    //   443: ifeq -> 526
    //   446: aload #19
    //   448: invokevirtual getVisibility : ()I
    //   451: bipush #8
    //   453: if_icmpeq -> 500
    //   456: aload #19
    //   458: getfield mListDimensionBehaviors : [Landroidx/constraintlayout/solver/widgets/ConstraintWidget$DimensionBehaviour;
    //   461: iload_2
    //   462: aaload
    //   463: aload #23
    //   465: if_acmpne -> 500
    //   468: aload #19
    //   470: getfield mListAnchors : [Landroidx/constraintlayout/solver/widgets/ConstraintAnchor;
    //   473: astore #17
    //   475: aload_1
    //   476: aload #17
    //   478: iload_3
    //   479: iconst_1
    //   480: iadd
    //   481: aaload
    //   482: getfield mSolverVariable : Landroidx/constraintlayout/solver/SolverVariable;
    //   485: aload #17
    //   487: iload_3
    //   488: aaload
    //   489: getfield mSolverVariable : Landroidx/constraintlayout/solver/SolverVariable;
    //   492: iconst_0
    //   493: iconst_5
    //   494: invokevirtual addGreaterThan : (Landroidx/constraintlayout/solver/SolverVariable;Landroidx/constraintlayout/solver/SolverVariable;II)V
    //   497: goto -> 500
    //   500: aload_1
    //   501: aload #19
    //   503: getfield mListAnchors : [Landroidx/constraintlayout/solver/widgets/ConstraintAnchor;
    //   506: iload_3
    //   507: aaload
    //   508: getfield mSolverVariable : Landroidx/constraintlayout/solver/SolverVariable;
    //   511: aload_0
    //   512: getfield mListAnchors : [Landroidx/constraintlayout/solver/widgets/ConstraintAnchor;
    //   515: iload_3
    //   516: aaload
    //   517: getfield mSolverVariable : Landroidx/constraintlayout/solver/SolverVariable;
    //   520: iconst_0
    //   521: bipush #8
    //   523: invokevirtual addGreaterThan : (Landroidx/constraintlayout/solver/SolverVariable;Landroidx/constraintlayout/solver/SolverVariable;II)V
    //   526: aload #19
    //   528: getfield mListAnchors : [Landroidx/constraintlayout/solver/widgets/ConstraintAnchor;
    //   531: iload_3
    //   532: iconst_1
    //   533: iadd
    //   534: aaload
    //   535: getfield mTarget : Landroidx/constraintlayout/solver/widgets/ConstraintAnchor;
    //   538: astore #23
    //   540: aload #22
    //   542: astore #17
    //   544: aload #23
    //   546: ifnull -> 603
    //   549: aload #23
    //   551: getfield mOwner : Landroidx/constraintlayout/solver/widgets/ConstraintWidget;
    //   554: astore #23
    //   556: aload #23
    //   558: getfield mListAnchors : [Landroidx/constraintlayout/solver/widgets/ConstraintAnchor;
    //   561: astore #24
    //   563: aload #22
    //   565: astore #17
    //   567: aload #24
    //   569: iload_3
    //   570: aaload
    //   571: getfield mTarget : Landroidx/constraintlayout/solver/widgets/ConstraintAnchor;
    //   574: ifnull -> 603
    //   577: aload #24
    //   579: iload_3
    //   580: aaload
    //   581: getfield mTarget : Landroidx/constraintlayout/solver/widgets/ConstraintAnchor;
    //   584: getfield mOwner : Landroidx/constraintlayout/solver/widgets/ConstraintWidget;
    //   587: aload #19
    //   589: if_acmpeq -> 599
    //   592: aload #22
    //   594: astore #17
    //   596: goto -> 603
    //   599: aload #23
    //   601: astore #17
    //   603: aload #17
    //   605: ifnull -> 615
    //   608: aload #17
    //   610: astore #19
    //   612: goto -> 618
    //   615: iconst_1
    //   616: istore #8
    //   618: goto -> 198
    //   621: aload #26
    //   623: ifnull -> 819
    //   626: aload #27
    //   628: getfield mListAnchors : [Landroidx/constraintlayout/solver/widgets/ConstraintAnchor;
    //   631: astore #17
    //   633: iload_3
    //   634: iconst_1
    //   635: iadd
    //   636: istore #9
    //   638: aload #17
    //   640: iload #9
    //   642: aaload
    //   643: getfield mTarget : Landroidx/constraintlayout/solver/widgets/ConstraintAnchor;
    //   646: ifnull -> 819
    //   649: aload #26
    //   651: getfield mListAnchors : [Landroidx/constraintlayout/solver/widgets/ConstraintAnchor;
    //   654: iload #9
    //   656: aaload
    //   657: astore #17
    //   659: aload #26
    //   661: getfield mListDimensionBehaviors : [Landroidx/constraintlayout/solver/widgets/ConstraintWidget$DimensionBehaviour;
    //   664: iload_2
    //   665: aaload
    //   666: getstatic androidx/constraintlayout/solver/widgets/ConstraintWidget$DimensionBehaviour.MATCH_CONSTRAINT : Landroidx/constraintlayout/solver/widgets/ConstraintWidget$DimensionBehaviour;
    //   669: if_acmpne -> 688
    //   672: aload #26
    //   674: getfield mResolvedMatchConstraintDefault : [I
    //   677: iload_2
    //   678: iaload
    //   679: ifne -> 688
    //   682: iconst_1
    //   683: istore #8
    //   685: goto -> 691
    //   688: iconst_0
    //   689: istore #8
    //   691: iload #8
    //   693: ifeq -> 742
    //   696: iload #13
    //   698: ifne -> 742
    //   701: aload #17
    //   703: getfield mTarget : Landroidx/constraintlayout/solver/widgets/ConstraintAnchor;
    //   706: astore #19
    //   708: aload #19
    //   710: getfield mOwner : Landroidx/constraintlayout/solver/widgets/ConstraintWidget;
    //   713: aload_0
    //   714: if_acmpne -> 742
    //   717: aload_1
    //   718: aload #17
    //   720: getfield mSolverVariable : Landroidx/constraintlayout/solver/SolverVariable;
    //   723: aload #19
    //   725: getfield mSolverVariable : Landroidx/constraintlayout/solver/SolverVariable;
    //   728: aload #17
    //   730: invokevirtual getMargin : ()I
    //   733: ineg
    //   734: iconst_5
    //   735: invokevirtual addEquality : (Landroidx/constraintlayout/solver/SolverVariable;Landroidx/constraintlayout/solver/SolverVariable;II)Landroidx/constraintlayout/solver/ArrayRow;
    //   738: pop
    //   739: goto -> 785
    //   742: iload #13
    //   744: ifeq -> 785
    //   747: aload #17
    //   749: getfield mTarget : Landroidx/constraintlayout/solver/widgets/ConstraintAnchor;
    //   752: astore #19
    //   754: aload #19
    //   756: getfield mOwner : Landroidx/constraintlayout/solver/widgets/ConstraintWidget;
    //   759: aload_0
    //   760: if_acmpne -> 785
    //   763: aload_1
    //   764: aload #17
    //   766: getfield mSolverVariable : Landroidx/constraintlayout/solver/SolverVariable;
    //   769: aload #19
    //   771: getfield mSolverVariable : Landroidx/constraintlayout/solver/SolverVariable;
    //   774: aload #17
    //   776: invokevirtual getMargin : ()I
    //   779: ineg
    //   780: iconst_4
    //   781: invokevirtual addEquality : (Landroidx/constraintlayout/solver/SolverVariable;Landroidx/constraintlayout/solver/SolverVariable;II)Landroidx/constraintlayout/solver/ArrayRow;
    //   784: pop
    //   785: aload_1
    //   786: aload #17
    //   788: getfield mSolverVariable : Landroidx/constraintlayout/solver/SolverVariable;
    //   791: aload #27
    //   793: getfield mListAnchors : [Landroidx/constraintlayout/solver/widgets/ConstraintAnchor;
    //   796: iload #9
    //   798: aaload
    //   799: getfield mTarget : Landroidx/constraintlayout/solver/widgets/ConstraintAnchor;
    //   802: getfield mSolverVariable : Landroidx/constraintlayout/solver/SolverVariable;
    //   805: aload #17
    //   807: invokevirtual getMargin : ()I
    //   810: ineg
    //   811: bipush #6
    //   813: invokevirtual addLowerThan : (Landroidx/constraintlayout/solver/SolverVariable;Landroidx/constraintlayout/solver/SolverVariable;II)V
    //   816: goto -> 819
    //   819: iload #12
    //   821: ifeq -> 872
    //   824: aload_0
    //   825: getfield mListAnchors : [Landroidx/constraintlayout/solver/widgets/ConstraintAnchor;
    //   828: astore_0
    //   829: iload_3
    //   830: iconst_1
    //   831: iadd
    //   832: istore #8
    //   834: aload_0
    //   835: iload #8
    //   837: aaload
    //   838: getfield mSolverVariable : Landroidx/constraintlayout/solver/SolverVariable;
    //   841: astore_0
    //   842: aload #27
    //   844: getfield mListAnchors : [Landroidx/constraintlayout/solver/widgets/ConstraintAnchor;
    //   847: astore #17
    //   849: aload_1
    //   850: aload_0
    //   851: aload #17
    //   853: iload #8
    //   855: aaload
    //   856: getfield mSolverVariable : Landroidx/constraintlayout/solver/SolverVariable;
    //   859: aload #17
    //   861: iload #8
    //   863: aaload
    //   864: invokevirtual getMargin : ()I
    //   867: bipush #8
    //   869: invokevirtual addGreaterThan : (Landroidx/constraintlayout/solver/SolverVariable;Landroidx/constraintlayout/solver/SolverVariable;II)V
    //   872: aload #4
    //   874: getfield mWeightedMatchConstraintsWidgets : Ljava/util/ArrayList;
    //   877: astore_0
    //   878: aload_0
    //   879: ifnull -> 1174
    //   882: aload_0
    //   883: invokevirtual size : ()I
    //   886: istore #9
    //   888: iload #9
    //   890: iconst_1
    //   891: if_icmple -> 1174
    //   894: aload #4
    //   896: getfield mHasUndefinedWeights : Z
    //   899: ifeq -> 921
    //   902: aload #4
    //   904: getfield mHasComplexMatchWeights : Z
    //   907: ifne -> 921
    //   910: aload #4
    //   912: getfield mWidgetsMatchCount : I
    //   915: i2f
    //   916: fstore #6
    //   918: goto -> 925
    //   921: fload #5
    //   923: fstore #6
    //   925: aconst_null
    //   926: astore #17
    //   928: iconst_0
    //   929: istore #8
    //   931: fconst_0
    //   932: fstore #7
    //   934: iload #8
    //   936: iload #9
    //   938: if_icmpge -> 1174
    //   941: aload_0
    //   942: iload #8
    //   944: invokevirtual get : (I)Ljava/lang/Object;
    //   947: checkcast androidx/constraintlayout/solver/widgets/ConstraintWidget
    //   950: astore #19
    //   952: aload #19
    //   954: getfield mWeight : [F
    //   957: iload_2
    //   958: faload
    //   959: fstore #5
    //   961: fload #5
    //   963: fconst_0
    //   964: fcmpg
    //   965: ifge -> 1015
    //   968: aload #4
    //   970: getfield mHasComplexMatchWeights : Z
    //   973: ifeq -> 1009
    //   976: aload #19
    //   978: getfield mListAnchors : [Landroidx/constraintlayout/solver/widgets/ConstraintAnchor;
    //   981: astore #19
    //   983: aload_1
    //   984: aload #19
    //   986: iload_3
    //   987: iconst_1
    //   988: iadd
    //   989: aaload
    //   990: getfield mSolverVariable : Landroidx/constraintlayout/solver/SolverVariable;
    //   993: aload #19
    //   995: iload_3
    //   996: aaload
    //   997: getfield mSolverVariable : Landroidx/constraintlayout/solver/SolverVariable;
    //   1000: iconst_0
    //   1001: iconst_4
    //   1002: invokevirtual addEquality : (Landroidx/constraintlayout/solver/SolverVariable;Landroidx/constraintlayout/solver/SolverVariable;II)Landroidx/constraintlayout/solver/ArrayRow;
    //   1005: pop
    //   1006: goto -> 1053
    //   1009: fconst_1
    //   1010: fstore #5
    //   1012: goto -> 1015
    //   1015: fload #5
    //   1017: fconst_0
    //   1018: fcmpl
    //   1019: ifne -> 1060
    //   1022: aload #19
    //   1024: getfield mListAnchors : [Landroidx/constraintlayout/solver/widgets/ConstraintAnchor;
    //   1027: astore #19
    //   1029: aload_1
    //   1030: aload #19
    //   1032: iload_3
    //   1033: iconst_1
    //   1034: iadd
    //   1035: aaload
    //   1036: getfield mSolverVariable : Landroidx/constraintlayout/solver/SolverVariable;
    //   1039: aload #19
    //   1041: iload_3
    //   1042: aaload
    //   1043: getfield mSolverVariable : Landroidx/constraintlayout/solver/SolverVariable;
    //   1046: iconst_0
    //   1047: bipush #8
    //   1049: invokevirtual addEquality : (Landroidx/constraintlayout/solver/SolverVariable;Landroidx/constraintlayout/solver/SolverVariable;II)Landroidx/constraintlayout/solver/ArrayRow;
    //   1052: pop
    //   1053: fload #7
    //   1055: fstore #5
    //   1057: goto -> 1161
    //   1060: aload #17
    //   1062: ifnull -> 1157
    //   1065: aload #17
    //   1067: getfield mListAnchors : [Landroidx/constraintlayout/solver/widgets/ConstraintAnchor;
    //   1070: astore #22
    //   1072: aload #22
    //   1074: iload_3
    //   1075: aaload
    //   1076: getfield mSolverVariable : Landroidx/constraintlayout/solver/SolverVariable;
    //   1079: astore #17
    //   1081: iload_3
    //   1082: iconst_1
    //   1083: iadd
    //   1084: istore #12
    //   1086: aload #22
    //   1088: iload #12
    //   1090: aaload
    //   1091: getfield mSolverVariable : Landroidx/constraintlayout/solver/SolverVariable;
    //   1094: astore #22
    //   1096: aload #19
    //   1098: getfield mListAnchors : [Landroidx/constraintlayout/solver/widgets/ConstraintAnchor;
    //   1101: astore #25
    //   1103: aload #25
    //   1105: iload_3
    //   1106: aaload
    //   1107: getfield mSolverVariable : Landroidx/constraintlayout/solver/SolverVariable;
    //   1110: astore #23
    //   1112: aload #25
    //   1114: iload #12
    //   1116: aaload
    //   1117: getfield mSolverVariable : Landroidx/constraintlayout/solver/SolverVariable;
    //   1120: astore #25
    //   1122: aload_1
    //   1123: invokevirtual createRow : ()Landroidx/constraintlayout/solver/ArrayRow;
    //   1126: astore #28
    //   1128: aload #28
    //   1130: fload #7
    //   1132: fload #6
    //   1134: fload #5
    //   1136: aload #17
    //   1138: aload #22
    //   1140: aload #23
    //   1142: aload #25
    //   1144: invokevirtual createRowEqualMatchDimensions : (FFFLandroidx/constraintlayout/solver/SolverVariable;Landroidx/constraintlayout/solver/SolverVariable;Landroidx/constraintlayout/solver/SolverVariable;Landroidx/constraintlayout/solver/SolverVariable;)Landroidx/constraintlayout/solver/ArrayRow;
    //   1147: pop
    //   1148: aload_1
    //   1149: aload #28
    //   1151: invokevirtual addConstraint : (Landroidx/constraintlayout/solver/ArrayRow;)V
    //   1154: goto -> 1157
    //   1157: aload #19
    //   1159: astore #17
    //   1161: iload #8
    //   1163: iconst_1
    //   1164: iadd
    //   1165: istore #8
    //   1167: fload #5
    //   1169: fstore #7
    //   1171: goto -> 934
    //   1174: aload #20
    //   1176: ifnull -> 1351
    //   1179: aload #20
    //   1181: aload #26
    //   1183: if_acmpeq -> 1191
    //   1186: iload #13
    //   1188: ifeq -> 1351
    //   1191: aload #21
    //   1193: getfield mListAnchors : [Landroidx/constraintlayout/solver/widgets/ConstraintAnchor;
    //   1196: iload_3
    //   1197: aaload
    //   1198: astore_0
    //   1199: aload #27
    //   1201: getfield mListAnchors : [Landroidx/constraintlayout/solver/widgets/ConstraintAnchor;
    //   1204: astore #4
    //   1206: iload_3
    //   1207: iconst_1
    //   1208: iadd
    //   1209: istore #8
    //   1211: aload #4
    //   1213: iload #8
    //   1215: aaload
    //   1216: astore #4
    //   1218: aload_0
    //   1219: getfield mTarget : Landroidx/constraintlayout/solver/widgets/ConstraintAnchor;
    //   1222: astore_0
    //   1223: aload_0
    //   1224: ifnull -> 1235
    //   1227: aload_0
    //   1228: getfield mSolverVariable : Landroidx/constraintlayout/solver/SolverVariable;
    //   1231: astore_0
    //   1232: goto -> 1237
    //   1235: aconst_null
    //   1236: astore_0
    //   1237: aload #4
    //   1239: getfield mTarget : Landroidx/constraintlayout/solver/widgets/ConstraintAnchor;
    //   1242: astore #4
    //   1244: aload #4
    //   1246: ifnull -> 1259
    //   1249: aload #4
    //   1251: getfield mSolverVariable : Landroidx/constraintlayout/solver/SolverVariable;
    //   1254: astore #4
    //   1256: goto -> 1262
    //   1259: aconst_null
    //   1260: astore #4
    //   1262: aload #20
    //   1264: getfield mListAnchors : [Landroidx/constraintlayout/solver/widgets/ConstraintAnchor;
    //   1267: iload_3
    //   1268: aaload
    //   1269: astore #17
    //   1271: aload #26
    //   1273: getfield mListAnchors : [Landroidx/constraintlayout/solver/widgets/ConstraintAnchor;
    //   1276: iload #8
    //   1278: aaload
    //   1279: astore #19
    //   1281: aload_0
    //   1282: ifnull -> 2417
    //   1285: aload #4
    //   1287: ifnull -> 2417
    //   1290: iload_2
    //   1291: ifne -> 1304
    //   1294: aload #18
    //   1296: getfield mHorizontalBiasPercent : F
    //   1299: fstore #5
    //   1301: goto -> 1311
    //   1304: aload #18
    //   1306: getfield mVerticalBiasPercent : F
    //   1309: fstore #5
    //   1311: aload #17
    //   1313: invokevirtual getMargin : ()I
    //   1316: istore_2
    //   1317: aload #19
    //   1319: invokevirtual getMargin : ()I
    //   1322: istore #8
    //   1324: aload_1
    //   1325: aload #17
    //   1327: getfield mSolverVariable : Landroidx/constraintlayout/solver/SolverVariable;
    //   1330: aload_0
    //   1331: iload_2
    //   1332: fload #5
    //   1334: aload #4
    //   1336: aload #19
    //   1338: getfield mSolverVariable : Landroidx/constraintlayout/solver/SolverVariable;
    //   1341: iload #8
    //   1343: bipush #7
    //   1345: invokevirtual addCentering : (Landroidx/constraintlayout/solver/SolverVariable;Landroidx/constraintlayout/solver/SolverVariable;IFLandroidx/constraintlayout/solver/SolverVariable;Landroidx/constraintlayout/solver/SolverVariable;II)V
    //   1348: goto -> 2417
    //   1351: iload #10
    //   1353: ifeq -> 1848
    //   1356: aload #20
    //   1358: ifnull -> 1848
    //   1361: aload #4
    //   1363: getfield mWidgetsMatchCount : I
    //   1366: istore #8
    //   1368: iload #8
    //   1370: ifle -> 1389
    //   1373: aload #4
    //   1375: getfield mWidgetsCount : I
    //   1378: iload #8
    //   1380: if_icmpne -> 1389
    //   1383: iconst_1
    //   1384: istore #12
    //   1386: goto -> 1392
    //   1389: iconst_0
    //   1390: istore #12
    //   1392: aload #20
    //   1394: astore #4
    //   1396: aload #4
    //   1398: astore #19
    //   1400: aload #4
    //   1402: ifnull -> 2417
    //   1405: aload #4
    //   1407: getfield mNextChainWidget : [Landroidx/constraintlayout/solver/widgets/ConstraintWidget;
    //   1410: iload_2
    //   1411: aaload
    //   1412: astore #17
    //   1414: aload #17
    //   1416: ifnull -> 1441
    //   1419: aload #17
    //   1421: invokevirtual getVisibility : ()I
    //   1424: bipush #8
    //   1426: if_icmpne -> 1441
    //   1429: aload #17
    //   1431: getfield mNextChainWidget : [Landroidx/constraintlayout/solver/widgets/ConstraintWidget;
    //   1434: iload_2
    //   1435: aaload
    //   1436: astore #17
    //   1438: goto -> 1414
    //   1441: aload #17
    //   1443: ifnonnull -> 1459
    //   1446: aload #4
    //   1448: aload #26
    //   1450: if_acmpne -> 1456
    //   1453: goto -> 1459
    //   1456: goto -> 1827
    //   1459: aload #4
    //   1461: getfield mListAnchors : [Landroidx/constraintlayout/solver/widgets/ConstraintAnchor;
    //   1464: iload_3
    //   1465: aaload
    //   1466: astore #22
    //   1468: aload #22
    //   1470: getfield mSolverVariable : Landroidx/constraintlayout/solver/SolverVariable;
    //   1473: astore #28
    //   1475: aload #22
    //   1477: getfield mTarget : Landroidx/constraintlayout/solver/widgets/ConstraintAnchor;
    //   1480: astore_0
    //   1481: aload_0
    //   1482: ifnull -> 1494
    //   1485: aload_0
    //   1486: getfield mSolverVariable : Landroidx/constraintlayout/solver/SolverVariable;
    //   1489: astore #18
    //   1491: goto -> 1497
    //   1494: aconst_null
    //   1495: astore #18
    //   1497: aload #19
    //   1499: aload #4
    //   1501: if_acmpeq -> 1520
    //   1504: aload #19
    //   1506: getfield mListAnchors : [Landroidx/constraintlayout/solver/widgets/ConstraintAnchor;
    //   1509: iload_3
    //   1510: iconst_1
    //   1511: iadd
    //   1512: aaload
    //   1513: getfield mSolverVariable : Landroidx/constraintlayout/solver/SolverVariable;
    //   1516: astore_0
    //   1517: goto -> 1570
    //   1520: aload #18
    //   1522: astore_0
    //   1523: aload #4
    //   1525: aload #20
    //   1527: if_acmpne -> 1570
    //   1530: aload #18
    //   1532: astore_0
    //   1533: aload #19
    //   1535: aload #4
    //   1537: if_acmpne -> 1570
    //   1540: aload #21
    //   1542: getfield mListAnchors : [Landroidx/constraintlayout/solver/widgets/ConstraintAnchor;
    //   1545: astore_0
    //   1546: aload_0
    //   1547: iload_3
    //   1548: aaload
    //   1549: getfield mTarget : Landroidx/constraintlayout/solver/widgets/ConstraintAnchor;
    //   1552: ifnull -> 1568
    //   1555: aload_0
    //   1556: iload_3
    //   1557: aaload
    //   1558: getfield mTarget : Landroidx/constraintlayout/solver/widgets/ConstraintAnchor;
    //   1561: getfield mSolverVariable : Landroidx/constraintlayout/solver/SolverVariable;
    //   1564: astore_0
    //   1565: goto -> 1570
    //   1568: aconst_null
    //   1569: astore_0
    //   1570: aload #22
    //   1572: invokevirtual getMargin : ()I
    //   1575: istore #13
    //   1577: aload #4
    //   1579: getfield mListAnchors : [Landroidx/constraintlayout/solver/widgets/ConstraintAnchor;
    //   1582: astore #18
    //   1584: iload_3
    //   1585: iconst_1
    //   1586: iadd
    //   1587: istore #14
    //   1589: aload #18
    //   1591: iload #14
    //   1593: aaload
    //   1594: invokevirtual getMargin : ()I
    //   1597: istore #9
    //   1599: aload #17
    //   1601: ifnull -> 1636
    //   1604: aload #17
    //   1606: getfield mListAnchors : [Landroidx/constraintlayout/solver/widgets/ConstraintAnchor;
    //   1609: iload_3
    //   1610: aaload
    //   1611: astore #18
    //   1613: aload #18
    //   1615: getfield mSolverVariable : Landroidx/constraintlayout/solver/SolverVariable;
    //   1618: astore #22
    //   1620: aload #4
    //   1622: getfield mListAnchors : [Landroidx/constraintlayout/solver/widgets/ConstraintAnchor;
    //   1625: iload #14
    //   1627: aaload
    //   1628: getfield mSolverVariable : Landroidx/constraintlayout/solver/SolverVariable;
    //   1631: astore #23
    //   1633: goto -> 1688
    //   1636: aload #27
    //   1638: getfield mListAnchors : [Landroidx/constraintlayout/solver/widgets/ConstraintAnchor;
    //   1641: iload #14
    //   1643: aaload
    //   1644: getfield mTarget : Landroidx/constraintlayout/solver/widgets/ConstraintAnchor;
    //   1647: astore #25
    //   1649: aload #25
    //   1651: ifnull -> 1664
    //   1654: aload #25
    //   1656: getfield mSolverVariable : Landroidx/constraintlayout/solver/SolverVariable;
    //   1659: astore #18
    //   1661: goto -> 1667
    //   1664: aconst_null
    //   1665: astore #18
    //   1667: aload #4
    //   1669: getfield mListAnchors : [Landroidx/constraintlayout/solver/widgets/ConstraintAnchor;
    //   1672: iload #14
    //   1674: aaload
    //   1675: getfield mSolverVariable : Landroidx/constraintlayout/solver/SolverVariable;
    //   1678: astore #23
    //   1680: aload #18
    //   1682: astore #22
    //   1684: aload #25
    //   1686: astore #18
    //   1688: iload #9
    //   1690: istore #8
    //   1692: aload #18
    //   1694: ifnull -> 1707
    //   1697: iload #9
    //   1699: aload #18
    //   1701: invokevirtual getMargin : ()I
    //   1704: iadd
    //   1705: istore #8
    //   1707: iload #13
    //   1709: istore #9
    //   1711: aload #19
    //   1713: ifnull -> 1732
    //   1716: iload #13
    //   1718: aload #19
    //   1720: getfield mListAnchors : [Landroidx/constraintlayout/solver/widgets/ConstraintAnchor;
    //   1723: iload #14
    //   1725: aaload
    //   1726: invokevirtual getMargin : ()I
    //   1729: iadd
    //   1730: istore #9
    //   1732: aload #28
    //   1734: ifnull -> 1456
    //   1737: aload_0
    //   1738: ifnull -> 1456
    //   1741: aload #22
    //   1743: ifnull -> 1456
    //   1746: aload #23
    //   1748: ifnull -> 1456
    //   1751: aload #4
    //   1753: aload #20
    //   1755: if_acmpne -> 1770
    //   1758: aload #20
    //   1760: getfield mListAnchors : [Landroidx/constraintlayout/solver/widgets/ConstraintAnchor;
    //   1763: iload_3
    //   1764: aaload
    //   1765: invokevirtual getMargin : ()I
    //   1768: istore #9
    //   1770: aload #4
    //   1772: aload #26
    //   1774: if_acmpne -> 1793
    //   1777: aload #26
    //   1779: getfield mListAnchors : [Landroidx/constraintlayout/solver/widgets/ConstraintAnchor;
    //   1782: iload #14
    //   1784: aaload
    //   1785: invokevirtual getMargin : ()I
    //   1788: istore #8
    //   1790: goto -> 1793
    //   1793: iload #12
    //   1795: ifeq -> 1805
    //   1798: bipush #8
    //   1800: istore #13
    //   1802: goto -> 1808
    //   1805: iconst_5
    //   1806: istore #13
    //   1808: aload_1
    //   1809: aload #28
    //   1811: aload_0
    //   1812: iload #9
    //   1814: ldc 0.5
    //   1816: aload #22
    //   1818: aload #23
    //   1820: iload #8
    //   1822: iload #13
    //   1824: invokevirtual addCentering : (Landroidx/constraintlayout/solver/SolverVariable;Landroidx/constraintlayout/solver/SolverVariable;IFLandroidx/constraintlayout/solver/SolverVariable;Landroidx/constraintlayout/solver/SolverVariable;II)V
    //   1827: aload #4
    //   1829: invokevirtual getVisibility : ()I
    //   1832: bipush #8
    //   1834: if_icmpeq -> 1841
    //   1837: aload #4
    //   1839: astore #19
    //   1841: aload #17
    //   1843: astore #4
    //   1845: goto -> 1400
    //   1848: iload #11
    //   1850: ifeq -> 2417
    //   1853: aload #20
    //   1855: ifnull -> 2417
    //   1858: aload #4
    //   1860: getfield mWidgetsMatchCount : I
    //   1863: istore #8
    //   1865: iload #8
    //   1867: ifle -> 1886
    //   1870: aload #4
    //   1872: getfield mWidgetsCount : I
    //   1875: iload #8
    //   1877: if_icmpne -> 1886
    //   1880: iconst_1
    //   1881: istore #8
    //   1883: goto -> 1889
    //   1886: iconst_0
    //   1887: istore #8
    //   1889: aload #20
    //   1891: astore #4
    //   1893: aload #4
    //   1895: astore #17
    //   1897: aload #4
    //   1899: ifnull -> 2257
    //   1902: aload #4
    //   1904: getfield mNextChainWidget : [Landroidx/constraintlayout/solver/widgets/ConstraintWidget;
    //   1907: iload_2
    //   1908: aaload
    //   1909: astore_0
    //   1910: aload_0
    //   1911: ifnull -> 1933
    //   1914: aload_0
    //   1915: invokevirtual getVisibility : ()I
    //   1918: bipush #8
    //   1920: if_icmpne -> 1933
    //   1923: aload_0
    //   1924: getfield mNextChainWidget : [Landroidx/constraintlayout/solver/widgets/ConstraintWidget;
    //   1927: iload_2
    //   1928: aaload
    //   1929: astore_0
    //   1930: goto -> 1910
    //   1933: aload #4
    //   1935: aload #20
    //   1937: if_acmpeq -> 2230
    //   1940: aload #4
    //   1942: aload #26
    //   1944: if_acmpeq -> 2230
    //   1947: aload_0
    //   1948: ifnull -> 2230
    //   1951: aload_0
    //   1952: aload #26
    //   1954: if_acmpne -> 1962
    //   1957: aconst_null
    //   1958: astore_0
    //   1959: goto -> 1962
    //   1962: aload #4
    //   1964: getfield mListAnchors : [Landroidx/constraintlayout/solver/widgets/ConstraintAnchor;
    //   1967: iload_3
    //   1968: aaload
    //   1969: astore #18
    //   1971: aload #18
    //   1973: getfield mSolverVariable : Landroidx/constraintlayout/solver/SolverVariable;
    //   1976: astore #25
    //   1978: aload #18
    //   1980: getfield mTarget : Landroidx/constraintlayout/solver/widgets/ConstraintAnchor;
    //   1983: astore #19
    //   1985: aload #19
    //   1987: ifnull -> 1997
    //   1990: aload #19
    //   1992: getfield mSolverVariable : Landroidx/constraintlayout/solver/SolverVariable;
    //   1995: astore #19
    //   1997: aload #17
    //   1999: getfield mListAnchors : [Landroidx/constraintlayout/solver/widgets/ConstraintAnchor;
    //   2002: astore #19
    //   2004: iload_3
    //   2005: iconst_1
    //   2006: iadd
    //   2007: istore #14
    //   2009: aload #19
    //   2011: iload #14
    //   2013: aaload
    //   2014: getfield mSolverVariable : Landroidx/constraintlayout/solver/SolverVariable;
    //   2017: astore #28
    //   2019: aload #18
    //   2021: invokevirtual getMargin : ()I
    //   2024: istore #13
    //   2026: aload #4
    //   2028: getfield mListAnchors : [Landroidx/constraintlayout/solver/widgets/ConstraintAnchor;
    //   2031: iload #14
    //   2033: aaload
    //   2034: invokevirtual getMargin : ()I
    //   2037: istore #12
    //   2039: aload_0
    //   2040: ifnull -> 2086
    //   2043: aload_0
    //   2044: getfield mListAnchors : [Landroidx/constraintlayout/solver/widgets/ConstraintAnchor;
    //   2047: iload_3
    //   2048: aaload
    //   2049: astore #19
    //   2051: aload #19
    //   2053: getfield mSolverVariable : Landroidx/constraintlayout/solver/SolverVariable;
    //   2056: astore #22
    //   2058: aload #19
    //   2060: getfield mTarget : Landroidx/constraintlayout/solver/widgets/ConstraintAnchor;
    //   2063: astore #18
    //   2065: aload #18
    //   2067: ifnull -> 2080
    //   2070: aload #18
    //   2072: getfield mSolverVariable : Landroidx/constraintlayout/solver/SolverVariable;
    //   2075: astore #18
    //   2077: goto -> 2134
    //   2080: aconst_null
    //   2081: astore #18
    //   2083: goto -> 2134
    //   2086: aload #26
    //   2088: getfield mListAnchors : [Landroidx/constraintlayout/solver/widgets/ConstraintAnchor;
    //   2091: iload_3
    //   2092: aaload
    //   2093: astore #23
    //   2095: aload #23
    //   2097: ifnull -> 2110
    //   2100: aload #23
    //   2102: getfield mSolverVariable : Landroidx/constraintlayout/solver/SolverVariable;
    //   2105: astore #19
    //   2107: goto -> 2113
    //   2110: aconst_null
    //   2111: astore #19
    //   2113: aload #4
    //   2115: getfield mListAnchors : [Landroidx/constraintlayout/solver/widgets/ConstraintAnchor;
    //   2118: iload #14
    //   2120: aaload
    //   2121: getfield mSolverVariable : Landroidx/constraintlayout/solver/SolverVariable;
    //   2124: astore #18
    //   2126: aload #19
    //   2128: astore #22
    //   2130: aload #23
    //   2132: astore #19
    //   2134: iload #12
    //   2136: istore #9
    //   2138: aload #19
    //   2140: ifnull -> 2153
    //   2143: iload #12
    //   2145: aload #19
    //   2147: invokevirtual getMargin : ()I
    //   2150: iadd
    //   2151: istore #9
    //   2153: aload #17
    //   2155: getfield mListAnchors : [Landroidx/constraintlayout/solver/widgets/ConstraintAnchor;
    //   2158: iload #14
    //   2160: aaload
    //   2161: invokevirtual getMargin : ()I
    //   2164: istore #14
    //   2166: iload #8
    //   2168: ifeq -> 2178
    //   2171: bipush #8
    //   2173: istore #12
    //   2175: goto -> 2181
    //   2178: iconst_4
    //   2179: istore #12
    //   2181: aload #25
    //   2183: ifnull -> 2227
    //   2186: aload #28
    //   2188: ifnull -> 2227
    //   2191: aload #22
    //   2193: ifnull -> 2227
    //   2196: aload #18
    //   2198: ifnull -> 2227
    //   2201: aload_1
    //   2202: aload #25
    //   2204: aload #28
    //   2206: iload #14
    //   2208: iload #13
    //   2210: iadd
    //   2211: ldc 0.5
    //   2213: aload #22
    //   2215: aload #18
    //   2217: iload #9
    //   2219: iload #12
    //   2221: invokevirtual addCentering : (Landroidx/constraintlayout/solver/SolverVariable;Landroidx/constraintlayout/solver/SolverVariable;IFLandroidx/constraintlayout/solver/SolverVariable;Landroidx/constraintlayout/solver/SolverVariable;II)V
    //   2224: goto -> 2227
    //   2227: goto -> 2230
    //   2230: aload #4
    //   2232: invokevirtual getVisibility : ()I
    //   2235: bipush #8
    //   2237: if_icmpeq -> 2243
    //   2240: goto -> 2247
    //   2243: aload #17
    //   2245: astore #4
    //   2247: aload #4
    //   2249: astore #17
    //   2251: aload_0
    //   2252: astore #4
    //   2254: goto -> 1897
    //   2257: aload #20
    //   2259: getfield mListAnchors : [Landroidx/constraintlayout/solver/widgets/ConstraintAnchor;
    //   2262: iload_3
    //   2263: aaload
    //   2264: astore_0
    //   2265: aload #21
    //   2267: getfield mListAnchors : [Landroidx/constraintlayout/solver/widgets/ConstraintAnchor;
    //   2270: iload_3
    //   2271: aaload
    //   2272: getfield mTarget : Landroidx/constraintlayout/solver/widgets/ConstraintAnchor;
    //   2275: astore #4
    //   2277: aload #26
    //   2279: getfield mListAnchors : [Landroidx/constraintlayout/solver/widgets/ConstraintAnchor;
    //   2282: astore #17
    //   2284: iload_3
    //   2285: iconst_1
    //   2286: iadd
    //   2287: istore_2
    //   2288: aload #17
    //   2290: iload_2
    //   2291: aaload
    //   2292: astore #17
    //   2294: aload #27
    //   2296: getfield mListAnchors : [Landroidx/constraintlayout/solver/widgets/ConstraintAnchor;
    //   2299: iload_2
    //   2300: aaload
    //   2301: getfield mTarget : Landroidx/constraintlayout/solver/widgets/ConstraintAnchor;
    //   2304: astore #18
    //   2306: aload #4
    //   2308: ifnull -> 2383
    //   2311: aload #20
    //   2313: aload #26
    //   2315: if_acmpeq -> 2340
    //   2318: aload_1
    //   2319: aload_0
    //   2320: getfield mSolverVariable : Landroidx/constraintlayout/solver/SolverVariable;
    //   2323: aload #4
    //   2325: getfield mSolverVariable : Landroidx/constraintlayout/solver/SolverVariable;
    //   2328: aload_0
    //   2329: invokevirtual getMargin : ()I
    //   2332: iconst_5
    //   2333: invokevirtual addEquality : (Landroidx/constraintlayout/solver/SolverVariable;Landroidx/constraintlayout/solver/SolverVariable;II)Landroidx/constraintlayout/solver/ArrayRow;
    //   2336: pop
    //   2337: goto -> 2383
    //   2340: aload #18
    //   2342: ifnull -> 2383
    //   2345: aload_1
    //   2346: aload_0
    //   2347: getfield mSolverVariable : Landroidx/constraintlayout/solver/SolverVariable;
    //   2350: aload #4
    //   2352: getfield mSolverVariable : Landroidx/constraintlayout/solver/SolverVariable;
    //   2355: aload_0
    //   2356: invokevirtual getMargin : ()I
    //   2359: ldc 0.5
    //   2361: aload #17
    //   2363: getfield mSolverVariable : Landroidx/constraintlayout/solver/SolverVariable;
    //   2366: aload #18
    //   2368: getfield mSolverVariable : Landroidx/constraintlayout/solver/SolverVariable;
    //   2371: aload #17
    //   2373: invokevirtual getMargin : ()I
    //   2376: iconst_5
    //   2377: invokevirtual addCentering : (Landroidx/constraintlayout/solver/SolverVariable;Landroidx/constraintlayout/solver/SolverVariable;IFLandroidx/constraintlayout/solver/SolverVariable;Landroidx/constraintlayout/solver/SolverVariable;II)V
    //   2380: goto -> 2383
    //   2383: aload #18
    //   2385: ifnull -> 2417
    //   2388: aload #20
    //   2390: aload #26
    //   2392: if_acmpeq -> 2417
    //   2395: aload_1
    //   2396: aload #17
    //   2398: getfield mSolverVariable : Landroidx/constraintlayout/solver/SolverVariable;
    //   2401: aload #18
    //   2403: getfield mSolverVariable : Landroidx/constraintlayout/solver/SolverVariable;
    //   2406: aload #17
    //   2408: invokevirtual getMargin : ()I
    //   2411: ineg
    //   2412: iconst_5
    //   2413: invokevirtual addEquality : (Landroidx/constraintlayout/solver/SolverVariable;Landroidx/constraintlayout/solver/SolverVariable;II)Landroidx/constraintlayout/solver/ArrayRow;
    //   2416: pop
    //   2417: iload #10
    //   2419: ifne -> 2427
    //   2422: iload #11
    //   2424: ifeq -> 2609
    //   2427: aload #20
    //   2429: ifnull -> 2609
    //   2432: aload #20
    //   2434: aload #26
    //   2436: if_acmpeq -> 2609
    //   2439: aload #20
    //   2441: getfield mListAnchors : [Landroidx/constraintlayout/solver/widgets/ConstraintAnchor;
    //   2444: astore #19
    //   2446: aload #19
    //   2448: iload_3
    //   2449: aaload
    //   2450: astore #17
    //   2452: aload #26
    //   2454: getfield mListAnchors : [Landroidx/constraintlayout/solver/widgets/ConstraintAnchor;
    //   2457: astore_0
    //   2458: iload_3
    //   2459: iconst_1
    //   2460: iadd
    //   2461: istore_2
    //   2462: aload_0
    //   2463: iload_2
    //   2464: aaload
    //   2465: astore #18
    //   2467: aload #17
    //   2469: getfield mTarget : Landroidx/constraintlayout/solver/widgets/ConstraintAnchor;
    //   2472: astore_0
    //   2473: aload_0
    //   2474: ifnull -> 2486
    //   2477: aload_0
    //   2478: getfield mSolverVariable : Landroidx/constraintlayout/solver/SolverVariable;
    //   2481: astore #4
    //   2483: goto -> 2489
    //   2486: aconst_null
    //   2487: astore #4
    //   2489: aload #18
    //   2491: getfield mTarget : Landroidx/constraintlayout/solver/widgets/ConstraintAnchor;
    //   2494: astore_0
    //   2495: aload_0
    //   2496: ifnull -> 2507
    //   2499: aload_0
    //   2500: getfield mSolverVariable : Landroidx/constraintlayout/solver/SolverVariable;
    //   2503: astore_0
    //   2504: goto -> 2509
    //   2507: aconst_null
    //   2508: astore_0
    //   2509: aload #27
    //   2511: aload #26
    //   2513: if_acmpeq -> 2542
    //   2516: aload #27
    //   2518: getfield mListAnchors : [Landroidx/constraintlayout/solver/widgets/ConstraintAnchor;
    //   2521: iload_2
    //   2522: aaload
    //   2523: getfield mTarget : Landroidx/constraintlayout/solver/widgets/ConstraintAnchor;
    //   2526: astore #21
    //   2528: aload #24
    //   2530: astore_0
    //   2531: aload #21
    //   2533: ifnull -> 2542
    //   2536: aload #21
    //   2538: getfield mSolverVariable : Landroidx/constraintlayout/solver/SolverVariable;
    //   2541: astore_0
    //   2542: aload #20
    //   2544: aload #26
    //   2546: if_acmpne -> 2561
    //   2549: aload #19
    //   2551: iload_3
    //   2552: aaload
    //   2553: astore #17
    //   2555: aload #19
    //   2557: iload_2
    //   2558: aaload
    //   2559: astore #18
    //   2561: aload #4
    //   2563: ifnull -> 2609
    //   2566: aload_0
    //   2567: ifnull -> 2609
    //   2570: aload #17
    //   2572: invokevirtual getMargin : ()I
    //   2575: istore_3
    //   2576: aload #26
    //   2578: getfield mListAnchors : [Landroidx/constraintlayout/solver/widgets/ConstraintAnchor;
    //   2581: iload_2
    //   2582: aaload
    //   2583: invokevirtual getMargin : ()I
    //   2586: istore_2
    //   2587: aload_1
    //   2588: aload #17
    //   2590: getfield mSolverVariable : Landroidx/constraintlayout/solver/SolverVariable;
    //   2593: aload #4
    //   2595: iload_3
    //   2596: ldc 0.5
    //   2598: aload_0
    //   2599: aload #18
    //   2601: getfield mSolverVariable : Landroidx/constraintlayout/solver/SolverVariable;
    //   2604: iload_2
    //   2605: iconst_5
    //   2606: invokevirtual addCentering : (Landroidx/constraintlayout/solver/SolverVariable;Landroidx/constraintlayout/solver/SolverVariable;IFLandroidx/constraintlayout/solver/SolverVariable;Landroidx/constraintlayout/solver/SolverVariable;II)V
    //   2609: return
  }
  
  public static void applyChainConstraints(ConstraintWidgetContainer paramConstraintWidgetContainer, LinearSystem paramLinearSystem, ArrayList<ConstraintWidget> paramArrayList, int paramInt) {
    int i;
    byte b;
    ChainHead[] arrayOfChainHead;
    int j = 0;
    if (paramInt == 0) {
      i = paramConstraintWidgetContainer.mHorizontalChainsSize;
      arrayOfChainHead = paramConstraintWidgetContainer.mHorizontalChainsArray;
      b = 0;
    } else {
      i = paramConstraintWidgetContainer.mVerticalChainsSize;
      arrayOfChainHead = paramConstraintWidgetContainer.mVerticalChainsArray;
      b = 2;
    } 
    while (j < i) {
      ChainHead chainHead = arrayOfChainHead[j];
      chainHead.define();
      if (paramArrayList == null || paramArrayList.contains(chainHead.mFirst))
        applyChainConstraints(paramConstraintWidgetContainer, paramLinearSystem, paramInt, b, chainHead); 
      j++;
    } 
  }
}


/* Location:              C:\soft\dex2jar-2.0\BabyBus TV_Kids Videos & Games-dex2jar.jar!\androidx\constraintlayout\solver\widgets\Chain.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */