package androidx.constraintlayout.solver.widgets.analyzer;

class BaselineDimensionDependency extends DimensionDependency {
  public BaselineDimensionDependency(WidgetRun paramWidgetRun) {
    super(paramWidgetRun);
  }
  
  public void update(DependencyNode paramDependencyNode) {
    WidgetRun widgetRun = this.run;
    ((VerticalWidgetRun)widgetRun).baseline.margin = widgetRun.widget.getBaselineDistance();
    this.resolved = true;
  }
}


/* Location:              C:\soft\dex2jar-2.0\BabyBus TV_Kids Videos & Games-dex2jar.jar!\androidx\constraintlayout\solver\widgets\analyzer\BaselineDimensionDependency.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */