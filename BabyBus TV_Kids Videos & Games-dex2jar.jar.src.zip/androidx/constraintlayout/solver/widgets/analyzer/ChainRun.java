package androidx.constraintlayout.solver.widgets.analyzer;

import androidx.constraintlayout.solver.widgets.ConstraintAnchor;
import androidx.constraintlayout.solver.widgets.ConstraintWidget;
import androidx.constraintlayout.solver.widgets.ConstraintWidgetContainer;
import java.util.ArrayList;
import java.util.Iterator;

public class ChainRun extends WidgetRun {
  private int chainStyle;
  
  ArrayList<WidgetRun> widgets = new ArrayList<WidgetRun>();
  
  public ChainRun(ConstraintWidget paramConstraintWidget, int paramInt) {
    super(paramConstraintWidget);
    this.orientation = paramInt;
    build();
  }
  
  private void build() {
    int i;
    ConstraintWidget constraintWidget2 = this.widget;
    ConstraintWidget constraintWidget1;
    for (constraintWidget1 = constraintWidget2.getPreviousChainMember(this.orientation); constraintWidget1 != null; constraintWidget1 = constraintWidget) {
      ConstraintWidget constraintWidget = constraintWidget1.getPreviousChainMember(this.orientation);
      constraintWidget2 = constraintWidget1;
    } 
    this.widget = constraintWidget2;
    this.widgets.add(constraintWidget2.getRun(this.orientation));
    for (constraintWidget1 = constraintWidget2.getNextChainMember(this.orientation); constraintWidget1 != null; constraintWidget1 = constraintWidget1.getNextChainMember(this.orientation))
      this.widgets.add(constraintWidget1.getRun(this.orientation)); 
    for (WidgetRun widgetRun : this.widgets) {
      i = this.orientation;
      if (i == 0) {
        widgetRun.widget.horizontalChainRun = this;
        continue;
      } 
      if (i == 1)
        widgetRun.widget.verticalChainRun = this; 
    } 
    if (this.orientation == 0 && ((ConstraintWidgetContainer)this.widget.getParent()).isRtl()) {
      i = 1;
    } else {
      i = 0;
    } 
    if (i && this.widgets.size() > 1) {
      ArrayList<WidgetRun> arrayList = this.widgets;
      this.widget = ((WidgetRun)arrayList.get(arrayList.size() - 1)).widget;
    } 
    if (this.orientation == 0) {
      i = this.widget.getHorizontalChainStyle();
    } else {
      i = this.widget.getVerticalChainStyle();
    } 
    this.chainStyle = i;
  }
  
  private ConstraintWidget getFirstVisibleWidget() {
    for (int i = 0; i < this.widgets.size(); i++) {
      WidgetRun widgetRun = this.widgets.get(i);
      if (widgetRun.widget.getVisibility() != 8)
        return widgetRun.widget; 
    } 
    return null;
  }
  
  private ConstraintWidget getLastVisibleWidget() {
    for (int i = this.widgets.size() - 1; i >= 0; i--) {
      WidgetRun widgetRun = this.widgets.get(i);
      if (widgetRun.widget.getVisibility() != 8)
        return widgetRun.widget; 
    } 
    return null;
  }
  
  void apply() {
    DependencyNode dependencyNode;
    Iterator<WidgetRun> iterator = this.widgets.iterator();
    while (iterator.hasNext())
      ((WidgetRun)iterator.next()).apply(); 
    int i = this.widgets.size();
    if (i < 1)
      return; 
    ConstraintWidget constraintWidget2 = ((WidgetRun)this.widgets.get(0)).widget;
    ConstraintWidget constraintWidget1 = ((WidgetRun)this.widgets.get(i - 1)).widget;
    if (this.orientation == 0) {
      ConstraintAnchor constraintAnchor2 = constraintWidget2.mLeft;
      ConstraintAnchor constraintAnchor1 = constraintWidget1.mRight;
      DependencyNode dependencyNode1 = getTarget(constraintAnchor2, 0);
      i = constraintAnchor2.getMargin();
      ConstraintWidget constraintWidget = getFirstVisibleWidget();
      if (constraintWidget != null)
        i = constraintWidget.mLeft.getMargin(); 
      if (dependencyNode1 != null)
        addTarget(this.start, dependencyNode1, i); 
      dependencyNode = getTarget(constraintAnchor1, 0);
      i = constraintAnchor1.getMargin();
      constraintWidget1 = getLastVisibleWidget();
      if (constraintWidget1 != null)
        i = constraintWidget1.mRight.getMargin(); 
      if (dependencyNode != null)
        addTarget(this.end, dependencyNode, -i); 
    } else {
      ConstraintAnchor constraintAnchor2 = ((ConstraintWidget)dependencyNode).mTop;
      ConstraintAnchor constraintAnchor1 = constraintWidget1.mBottom;
      DependencyNode dependencyNode2 = getTarget(constraintAnchor2, 1);
      i = constraintAnchor2.getMargin();
      ConstraintWidget constraintWidget4 = getFirstVisibleWidget();
      if (constraintWidget4 != null)
        i = constraintWidget4.mTop.getMargin(); 
      if (dependencyNode2 != null)
        addTarget(this.start, dependencyNode2, i); 
      DependencyNode dependencyNode1 = getTarget(constraintAnchor1, 1);
      i = constraintAnchor1.getMargin();
      ConstraintWidget constraintWidget3 = getLastVisibleWidget();
      if (constraintWidget3 != null)
        i = constraintWidget3.mBottom.getMargin(); 
      if (dependencyNode1 != null)
        addTarget(this.end, dependencyNode1, -i); 
    } 
    this.start.updateDelegate = this;
    this.end.updateDelegate = this;
  }
  
  public void applyToWidget() {
    for (int i = 0; i < this.widgets.size(); i++)
      ((WidgetRun)this.widgets.get(i)).applyToWidget(); 
  }
  
  void clear() {
    this.runGroup = null;
    Iterator<WidgetRun> iterator = this.widgets.iterator();
    while (iterator.hasNext())
      ((WidgetRun)iterator.next()).clear(); 
  }
  
  public long getWrapDimension() {
    int j = this.widgets.size();
    long l = 0L;
    for (int i = 0; i < j; i++) {
      WidgetRun widgetRun = this.widgets.get(i);
      l = l + widgetRun.start.margin + widgetRun.getWrapDimension() + widgetRun.end.margin;
    } 
    return l;
  }
  
  void reset() {
    this.start.resolved = false;
    this.end.resolved = false;
  }
  
  boolean supportsWrapComputation() {
    int j = this.widgets.size();
    for (int i = 0; i < j; i++) {
      if (!((WidgetRun)this.widgets.get(i)).supportsWrapComputation())
        return false; 
    } 
    return true;
  }
  
  public String toString() {
    StringBuilder stringBuilder = new StringBuilder();
    stringBuilder.append("ChainRun ");
    if (this.orientation == 0) {
      str = "horizontal : ";
    } else {
      str = "vertical : ";
    } 
    stringBuilder.append(str);
    String str = stringBuilder.toString();
    for (WidgetRun widgetRun : this.widgets) {
      StringBuilder stringBuilder2 = new StringBuilder();
      stringBuilder2.append(str);
      stringBuilder2.append("<");
      str = stringBuilder2.toString();
      stringBuilder2 = new StringBuilder();
      stringBuilder2.append(str);
      stringBuilder2.append(widgetRun);
      str = stringBuilder2.toString();
      StringBuilder stringBuilder1 = new StringBuilder();
      stringBuilder1.append(str);
      stringBuilder1.append("> ");
      str = stringBuilder1.toString();
    } 
    return str;
  }
  
  public void update(Dependency paramDependency) {
    // Byte code:
    //   0: aload_0
    //   1: getfield start : Landroidx/constraintlayout/solver/widgets/analyzer/DependencyNode;
    //   4: getfield resolved : Z
    //   7: ifeq -> 2492
    //   10: aload_0
    //   11: getfield end : Landroidx/constraintlayout/solver/widgets/analyzer/DependencyNode;
    //   14: getfield resolved : Z
    //   17: ifne -> 21
    //   20: return
    //   21: aload_0
    //   22: getfield widget : Landroidx/constraintlayout/solver/widgets/ConstraintWidget;
    //   25: invokevirtual getParent : ()Landroidx/constraintlayout/solver/widgets/ConstraintWidget;
    //   28: astore_1
    //   29: aload_1
    //   30: ifnull -> 52
    //   33: aload_1
    //   34: instanceof androidx/constraintlayout/solver/widgets/ConstraintWidgetContainer
    //   37: ifeq -> 52
    //   40: aload_1
    //   41: checkcast androidx/constraintlayout/solver/widgets/ConstraintWidgetContainer
    //   44: invokevirtual isRtl : ()Z
    //   47: istore #21
    //   49: goto -> 55
    //   52: iconst_0
    //   53: istore #21
    //   55: aload_0
    //   56: getfield end : Landroidx/constraintlayout/solver/widgets/analyzer/DependencyNode;
    //   59: getfield value : I
    //   62: aload_0
    //   63: getfield start : Landroidx/constraintlayout/solver/widgets/analyzer/DependencyNode;
    //   66: getfield value : I
    //   69: isub
    //   70: istore #20
    //   72: aload_0
    //   73: getfield widgets : Ljava/util/ArrayList;
    //   76: invokevirtual size : ()I
    //   79: istore #19
    //   81: iconst_0
    //   82: istore #5
    //   84: iconst_m1
    //   85: istore #6
    //   87: iload #5
    //   89: iload #19
    //   91: if_icmpge -> 130
    //   94: iload #5
    //   96: istore #14
    //   98: aload_0
    //   99: getfield widgets : Ljava/util/ArrayList;
    //   102: iload #5
    //   104: invokevirtual get : (I)Ljava/lang/Object;
    //   107: checkcast androidx/constraintlayout/solver/widgets/analyzer/WidgetRun
    //   110: getfield widget : Landroidx/constraintlayout/solver/widgets/ConstraintWidget;
    //   113: invokevirtual getVisibility : ()I
    //   116: bipush #8
    //   118: if_icmpne -> 133
    //   121: iload #5
    //   123: iconst_1
    //   124: iadd
    //   125: istore #5
    //   127: goto -> 84
    //   130: iconst_m1
    //   131: istore #14
    //   133: iload #19
    //   135: iconst_1
    //   136: isub
    //   137: istore #18
    //   139: iload #18
    //   141: istore #5
    //   143: iload #6
    //   145: istore #15
    //   147: iload #5
    //   149: iflt -> 188
    //   152: aload_0
    //   153: getfield widgets : Ljava/util/ArrayList;
    //   156: iload #5
    //   158: invokevirtual get : (I)Ljava/lang/Object;
    //   161: checkcast androidx/constraintlayout/solver/widgets/analyzer/WidgetRun
    //   164: getfield widget : Landroidx/constraintlayout/solver/widgets/ConstraintWidget;
    //   167: invokevirtual getVisibility : ()I
    //   170: bipush #8
    //   172: if_icmpne -> 184
    //   175: iload #5
    //   177: iconst_1
    //   178: isub
    //   179: istore #5
    //   181: goto -> 143
    //   184: iload #5
    //   186: istore #15
    //   188: iconst_0
    //   189: istore #9
    //   191: iload #9
    //   193: iconst_2
    //   194: if_icmpge -> 614
    //   197: iconst_0
    //   198: istore #10
    //   200: iconst_0
    //   201: istore #8
    //   203: iconst_0
    //   204: istore #5
    //   206: iconst_0
    //   207: istore #6
    //   209: fconst_0
    //   210: fstore_2
    //   211: iload #10
    //   213: iload #19
    //   215: if_icmpge -> 579
    //   218: aload_0
    //   219: getfield widgets : Ljava/util/ArrayList;
    //   222: iload #10
    //   224: invokevirtual get : (I)Ljava/lang/Object;
    //   227: checkcast androidx/constraintlayout/solver/widgets/analyzer/WidgetRun
    //   230: astore_1
    //   231: aload_1
    //   232: getfield widget : Landroidx/constraintlayout/solver/widgets/ConstraintWidget;
    //   235: invokevirtual getVisibility : ()I
    //   238: bipush #8
    //   240: if_icmpne -> 250
    //   243: iload #5
    //   245: istore #11
    //   247: goto -> 566
    //   250: iload #6
    //   252: iconst_1
    //   253: iadd
    //   254: istore #12
    //   256: iload #8
    //   258: istore #6
    //   260: iload #10
    //   262: ifle -> 288
    //   265: iload #8
    //   267: istore #6
    //   269: iload #10
    //   271: iload #14
    //   273: if_icmplt -> 288
    //   276: iload #8
    //   278: aload_1
    //   279: getfield start : Landroidx/constraintlayout/solver/widgets/analyzer/DependencyNode;
    //   282: getfield margin : I
    //   285: iadd
    //   286: istore #6
    //   288: aload_1
    //   289: getfield dimension : Landroidx/constraintlayout/solver/widgets/analyzer/DimensionDependency;
    //   292: astore #22
    //   294: aload #22
    //   296: getfield value : I
    //   299: istore #8
    //   301: aload_1
    //   302: getfield dimensionBehavior : Landroidx/constraintlayout/solver/widgets/ConstraintWidget$DimensionBehaviour;
    //   305: getstatic androidx/constraintlayout/solver/widgets/ConstraintWidget$DimensionBehaviour.MATCH_CONSTRAINT : Landroidx/constraintlayout/solver/widgets/ConstraintWidget$DimensionBehaviour;
    //   308: if_acmpeq -> 317
    //   311: iconst_1
    //   312: istore #7
    //   314: goto -> 320
    //   317: iconst_0
    //   318: istore #7
    //   320: iload #7
    //   322: ifeq -> 379
    //   325: aload_0
    //   326: getfield orientation : I
    //   329: istore #11
    //   331: iload #11
    //   333: ifne -> 353
    //   336: aload_1
    //   337: getfield widget : Landroidx/constraintlayout/solver/widgets/ConstraintWidget;
    //   340: getfield horizontalRun : Landroidx/constraintlayout/solver/widgets/analyzer/HorizontalWidgetRun;
    //   343: getfield dimension : Landroidx/constraintlayout/solver/widgets/analyzer/DimensionDependency;
    //   346: getfield resolved : Z
    //   349: ifne -> 353
    //   352: return
    //   353: iload #11
    //   355: iconst_1
    //   356: if_icmpne -> 376
    //   359: aload_1
    //   360: getfield widget : Landroidx/constraintlayout/solver/widgets/ConstraintWidget;
    //   363: getfield verticalRun : Landroidx/constraintlayout/solver/widgets/analyzer/VerticalWidgetRun;
    //   366: getfield dimension : Landroidx/constraintlayout/solver/widgets/analyzer/DimensionDependency;
    //   369: getfield resolved : Z
    //   372: ifne -> 376
    //   375: return
    //   376: goto -> 426
    //   379: aload_1
    //   380: getfield matchConstraintsType : I
    //   383: iconst_1
    //   384: if_icmpne -> 408
    //   387: iload #9
    //   389: ifne -> 408
    //   392: aload #22
    //   394: getfield wrapValue : I
    //   397: istore #7
    //   399: iload #5
    //   401: iconst_1
    //   402: iadd
    //   403: istore #5
    //   405: goto -> 420
    //   408: aload #22
    //   410: getfield resolved : Z
    //   413: ifeq -> 426
    //   416: iload #8
    //   418: istore #7
    //   420: iconst_1
    //   421: istore #11
    //   423: goto -> 434
    //   426: iload #7
    //   428: istore #11
    //   430: iload #8
    //   432: istore #7
    //   434: iload #11
    //   436: ifne -> 492
    //   439: iload #5
    //   441: iconst_1
    //   442: iadd
    //   443: istore #8
    //   445: aload_1
    //   446: getfield widget : Landroidx/constraintlayout/solver/widgets/ConstraintWidget;
    //   449: getfield mWeight : [F
    //   452: aload_0
    //   453: getfield orientation : I
    //   456: faload
    //   457: fstore #4
    //   459: iload #6
    //   461: istore #7
    //   463: iload #8
    //   465: istore #5
    //   467: fload_2
    //   468: fstore_3
    //   469: fload #4
    //   471: fconst_0
    //   472: fcmpl
    //   473: iflt -> 501
    //   476: fload_2
    //   477: fload #4
    //   479: fadd
    //   480: fstore_3
    //   481: iload #6
    //   483: istore #7
    //   485: iload #8
    //   487: istore #5
    //   489: goto -> 501
    //   492: iload #6
    //   494: iload #7
    //   496: iadd
    //   497: istore #7
    //   499: fload_2
    //   500: fstore_3
    //   501: iload #7
    //   503: istore #8
    //   505: iload #5
    //   507: istore #11
    //   509: iload #12
    //   511: istore #6
    //   513: fload_3
    //   514: fstore_2
    //   515: iload #10
    //   517: iload #18
    //   519: if_icmpge -> 566
    //   522: iload #7
    //   524: istore #8
    //   526: iload #5
    //   528: istore #11
    //   530: iload #12
    //   532: istore #6
    //   534: fload_3
    //   535: fstore_2
    //   536: iload #10
    //   538: iload #15
    //   540: if_icmpge -> 566
    //   543: iload #7
    //   545: aload_1
    //   546: getfield end : Landroidx/constraintlayout/solver/widgets/analyzer/DependencyNode;
    //   549: getfield margin : I
    //   552: ineg
    //   553: iadd
    //   554: istore #8
    //   556: fload_3
    //   557: fstore_2
    //   558: iload #12
    //   560: istore #6
    //   562: iload #5
    //   564: istore #11
    //   566: iload #10
    //   568: iconst_1
    //   569: iadd
    //   570: istore #10
    //   572: iload #11
    //   574: istore #5
    //   576: goto -> 211
    //   579: iload #8
    //   581: iload #20
    //   583: if_icmplt -> 603
    //   586: iload #5
    //   588: ifne -> 594
    //   591: goto -> 603
    //   594: iload #9
    //   596: iconst_1
    //   597: iadd
    //   598: istore #9
    //   600: goto -> 191
    //   603: iload #6
    //   605: istore #7
    //   607: iload #5
    //   609: istore #6
    //   611: goto -> 625
    //   614: iconst_0
    //   615: istore #7
    //   617: iconst_0
    //   618: istore #8
    //   620: iconst_0
    //   621: istore #6
    //   623: fconst_0
    //   624: fstore_2
    //   625: aload_0
    //   626: getfield start : Landroidx/constraintlayout/solver/widgets/analyzer/DependencyNode;
    //   629: getfield value : I
    //   632: istore #9
    //   634: iload #21
    //   636: ifeq -> 648
    //   639: aload_0
    //   640: getfield end : Landroidx/constraintlayout/solver/widgets/analyzer/DependencyNode;
    //   643: getfield value : I
    //   646: istore #9
    //   648: iload #9
    //   650: istore #5
    //   652: iload #8
    //   654: iload #20
    //   656: if_icmple -> 701
    //   659: iload #21
    //   661: ifeq -> 684
    //   664: iload #9
    //   666: iload #8
    //   668: iload #20
    //   670: isub
    //   671: i2f
    //   672: fconst_2
    //   673: fdiv
    //   674: ldc 0.5
    //   676: fadd
    //   677: f2i
    //   678: iadd
    //   679: istore #5
    //   681: goto -> 701
    //   684: iload #9
    //   686: iload #8
    //   688: iload #20
    //   690: isub
    //   691: i2f
    //   692: fconst_2
    //   693: fdiv
    //   694: ldc 0.5
    //   696: fadd
    //   697: f2i
    //   698: isub
    //   699: istore #5
    //   701: iload #6
    //   703: ifle -> 1259
    //   706: iload #20
    //   708: iload #8
    //   710: isub
    //   711: i2f
    //   712: fstore_3
    //   713: fload_3
    //   714: iload #6
    //   716: i2f
    //   717: fdiv
    //   718: ldc 0.5
    //   720: fadd
    //   721: f2i
    //   722: istore #11
    //   724: iconst_0
    //   725: istore #16
    //   727: iconst_0
    //   728: istore #10
    //   730: iload #8
    //   732: istore #9
    //   734: iload #10
    //   736: istore #8
    //   738: iload #5
    //   740: istore #10
    //   742: iload #16
    //   744: iload #19
    //   746: if_icmpge -> 1059
    //   749: aload_0
    //   750: getfield widgets : Ljava/util/ArrayList;
    //   753: iload #16
    //   755: invokevirtual get : (I)Ljava/lang/Object;
    //   758: checkcast androidx/constraintlayout/solver/widgets/analyzer/WidgetRun
    //   761: astore_1
    //   762: aload_1
    //   763: getfield widget : Landroidx/constraintlayout/solver/widgets/ConstraintWidget;
    //   766: invokevirtual getVisibility : ()I
    //   769: bipush #8
    //   771: if_icmpne -> 777
    //   774: goto -> 1050
    //   777: aload_1
    //   778: getfield dimensionBehavior : Landroidx/constraintlayout/solver/widgets/ConstraintWidget$DimensionBehaviour;
    //   781: getstatic androidx/constraintlayout/solver/widgets/ConstraintWidget$DimensionBehaviour.MATCH_CONSTRAINT : Landroidx/constraintlayout/solver/widgets/ConstraintWidget$DimensionBehaviour;
    //   784: if_acmpne -> 1050
    //   787: aload_1
    //   788: getfield dimension : Landroidx/constraintlayout/solver/widgets/analyzer/DimensionDependency;
    //   791: astore #22
    //   793: aload #22
    //   795: getfield resolved : Z
    //   798: ifne -> 1050
    //   801: fload_2
    //   802: fconst_0
    //   803: fcmpl
    //   804: ifle -> 832
    //   807: aload_1
    //   808: getfield widget : Landroidx/constraintlayout/solver/widgets/ConstraintWidget;
    //   811: getfield mWeight : [F
    //   814: aload_0
    //   815: getfield orientation : I
    //   818: faload
    //   819: fload_3
    //   820: fmul
    //   821: fload_2
    //   822: fdiv
    //   823: ldc 0.5
    //   825: fadd
    //   826: f2i
    //   827: istore #5
    //   829: goto -> 836
    //   832: iload #11
    //   834: istore #5
    //   836: aload_0
    //   837: getfield orientation : I
    //   840: ifne -> 935
    //   843: aload_1
    //   844: getfield widget : Landroidx/constraintlayout/solver/widgets/ConstraintWidget;
    //   847: astore #23
    //   849: aload #23
    //   851: getfield mMatchConstraintMaxWidth : I
    //   854: istore #17
    //   856: aload #23
    //   858: getfield mMatchConstraintMinWidth : I
    //   861: istore #13
    //   863: aload_1
    //   864: getfield matchConstraintsType : I
    //   867: iconst_1
    //   868: if_icmpne -> 886
    //   871: iload #5
    //   873: aload #22
    //   875: getfield wrapValue : I
    //   878: invokestatic min : (II)I
    //   881: istore #12
    //   883: goto -> 890
    //   886: iload #5
    //   888: istore #12
    //   890: iload #13
    //   892: iload #12
    //   894: invokestatic max : (II)I
    //   897: istore #13
    //   899: iload #13
    //   901: istore #12
    //   903: iload #17
    //   905: ifle -> 917
    //   908: iload #17
    //   910: iload #13
    //   912: invokestatic min : (II)I
    //   915: istore #12
    //   917: iload #5
    //   919: istore #17
    //   921: iload #8
    //   923: istore #13
    //   925: iload #12
    //   927: iload #5
    //   929: if_icmpeq -> 1034
    //   932: goto -> 1024
    //   935: aload_1
    //   936: getfield widget : Landroidx/constraintlayout/solver/widgets/ConstraintWidget;
    //   939: astore #23
    //   941: aload #23
    //   943: getfield mMatchConstraintMaxHeight : I
    //   946: istore #17
    //   948: aload #23
    //   950: getfield mMatchConstraintMinHeight : I
    //   953: istore #13
    //   955: aload_1
    //   956: getfield matchConstraintsType : I
    //   959: iconst_1
    //   960: if_icmpne -> 978
    //   963: iload #5
    //   965: aload #22
    //   967: getfield wrapValue : I
    //   970: invokestatic min : (II)I
    //   973: istore #12
    //   975: goto -> 982
    //   978: iload #5
    //   980: istore #12
    //   982: iload #13
    //   984: iload #12
    //   986: invokestatic max : (II)I
    //   989: istore #13
    //   991: iload #13
    //   993: istore #12
    //   995: iload #17
    //   997: ifle -> 1009
    //   1000: iload #17
    //   1002: iload #13
    //   1004: invokestatic min : (II)I
    //   1007: istore #12
    //   1009: iload #5
    //   1011: istore #17
    //   1013: iload #8
    //   1015: istore #13
    //   1017: iload #12
    //   1019: iload #5
    //   1021: if_icmpeq -> 1034
    //   1024: iload #8
    //   1026: iconst_1
    //   1027: iadd
    //   1028: istore #13
    //   1030: iload #12
    //   1032: istore #17
    //   1034: aload_1
    //   1035: getfield dimension : Landroidx/constraintlayout/solver/widgets/analyzer/DimensionDependency;
    //   1038: iload #17
    //   1040: invokevirtual resolve : (I)V
    //   1043: iload #13
    //   1045: istore #8
    //   1047: goto -> 1050
    //   1050: iload #16
    //   1052: iconst_1
    //   1053: iadd
    //   1054: istore #16
    //   1056: goto -> 742
    //   1059: iload #8
    //   1061: ifle -> 1207
    //   1064: iload #6
    //   1066: iload #8
    //   1068: isub
    //   1069: istore #11
    //   1071: iconst_0
    //   1072: istore #6
    //   1074: iconst_0
    //   1075: istore #5
    //   1077: iload #6
    //   1079: iload #19
    //   1081: if_icmpge -> 1200
    //   1084: aload_0
    //   1085: getfield widgets : Ljava/util/ArrayList;
    //   1088: iload #6
    //   1090: invokevirtual get : (I)Ljava/lang/Object;
    //   1093: checkcast androidx/constraintlayout/solver/widgets/analyzer/WidgetRun
    //   1096: astore_1
    //   1097: aload_1
    //   1098: getfield widget : Landroidx/constraintlayout/solver/widgets/ConstraintWidget;
    //   1101: invokevirtual getVisibility : ()I
    //   1104: bipush #8
    //   1106: if_icmpne -> 1112
    //   1109: goto -> 1191
    //   1112: iload #5
    //   1114: istore #9
    //   1116: iload #6
    //   1118: ifle -> 1144
    //   1121: iload #5
    //   1123: istore #9
    //   1125: iload #6
    //   1127: iload #14
    //   1129: if_icmplt -> 1144
    //   1132: iload #5
    //   1134: aload_1
    //   1135: getfield start : Landroidx/constraintlayout/solver/widgets/analyzer/DependencyNode;
    //   1138: getfield margin : I
    //   1141: iadd
    //   1142: istore #9
    //   1144: iload #9
    //   1146: aload_1
    //   1147: getfield dimension : Landroidx/constraintlayout/solver/widgets/analyzer/DimensionDependency;
    //   1150: getfield value : I
    //   1153: iadd
    //   1154: istore #9
    //   1156: iload #9
    //   1158: istore #5
    //   1160: iload #6
    //   1162: iload #18
    //   1164: if_icmpge -> 1191
    //   1167: iload #9
    //   1169: istore #5
    //   1171: iload #6
    //   1173: iload #15
    //   1175: if_icmpge -> 1191
    //   1178: iload #9
    //   1180: aload_1
    //   1181: getfield end : Landroidx/constraintlayout/solver/widgets/analyzer/DependencyNode;
    //   1184: getfield margin : I
    //   1187: ineg
    //   1188: iadd
    //   1189: istore #5
    //   1191: iload #6
    //   1193: iconst_1
    //   1194: iadd
    //   1195: istore #6
    //   1197: goto -> 1077
    //   1200: iload #11
    //   1202: istore #6
    //   1204: goto -> 1211
    //   1207: iload #9
    //   1209: istore #5
    //   1211: aload_0
    //   1212: getfield chainStyle : I
    //   1215: iconst_2
    //   1216: if_icmpne -> 1244
    //   1219: iload #8
    //   1221: ifne -> 1244
    //   1224: aload_0
    //   1225: iconst_0
    //   1226: putfield chainStyle : I
    //   1229: iload #5
    //   1231: istore #8
    //   1233: iload #6
    //   1235: istore #9
    //   1237: iload #10
    //   1239: istore #5
    //   1241: goto -> 1263
    //   1244: iload #5
    //   1246: istore #8
    //   1248: iload #6
    //   1250: istore #9
    //   1252: iload #10
    //   1254: istore #5
    //   1256: goto -> 1263
    //   1259: iload #6
    //   1261: istore #9
    //   1263: iload #8
    //   1265: iload #20
    //   1267: if_icmple -> 1275
    //   1270: aload_0
    //   1271: iconst_2
    //   1272: putfield chainStyle : I
    //   1275: iload #7
    //   1277: ifle -> 1297
    //   1280: iload #9
    //   1282: ifne -> 1297
    //   1285: iload #14
    //   1287: iload #15
    //   1289: if_icmpne -> 1297
    //   1292: aload_0
    //   1293: iconst_2
    //   1294: putfield chainStyle : I
    //   1297: aload_0
    //   1298: getfield chainStyle : I
    //   1301: istore #6
    //   1303: iload #6
    //   1305: iconst_1
    //   1306: if_icmpne -> 1725
    //   1309: iload #7
    //   1311: iconst_1
    //   1312: if_icmple -> 1330
    //   1315: iload #20
    //   1317: iload #8
    //   1319: isub
    //   1320: iload #7
    //   1322: iconst_1
    //   1323: isub
    //   1324: idiv
    //   1325: istore #6
    //   1327: goto -> 1351
    //   1330: iload #7
    //   1332: iconst_1
    //   1333: if_icmpne -> 1348
    //   1336: iload #20
    //   1338: iload #8
    //   1340: isub
    //   1341: iconst_2
    //   1342: idiv
    //   1343: istore #6
    //   1345: goto -> 1351
    //   1348: iconst_0
    //   1349: istore #6
    //   1351: iload #6
    //   1353: istore #8
    //   1355: iload #9
    //   1357: ifle -> 1363
    //   1360: iconst_0
    //   1361: istore #8
    //   1363: iconst_0
    //   1364: istore #6
    //   1366: iload #5
    //   1368: istore #7
    //   1370: iload #6
    //   1372: iload #19
    //   1374: if_icmpge -> 2492
    //   1377: iload #21
    //   1379: ifeq -> 1394
    //   1382: iload #19
    //   1384: iload #6
    //   1386: iconst_1
    //   1387: iadd
    //   1388: isub
    //   1389: istore #5
    //   1391: goto -> 1398
    //   1394: iload #6
    //   1396: istore #5
    //   1398: aload_0
    //   1399: getfield widgets : Ljava/util/ArrayList;
    //   1402: iload #5
    //   1404: invokevirtual get : (I)Ljava/lang/Object;
    //   1407: checkcast androidx/constraintlayout/solver/widgets/analyzer/WidgetRun
    //   1410: astore_1
    //   1411: aload_1
    //   1412: getfield widget : Landroidx/constraintlayout/solver/widgets/ConstraintWidget;
    //   1415: invokevirtual getVisibility : ()I
    //   1418: bipush #8
    //   1420: if_icmpne -> 1448
    //   1423: aload_1
    //   1424: getfield start : Landroidx/constraintlayout/solver/widgets/analyzer/DependencyNode;
    //   1427: iload #7
    //   1429: invokevirtual resolve : (I)V
    //   1432: aload_1
    //   1433: getfield end : Landroidx/constraintlayout/solver/widgets/analyzer/DependencyNode;
    //   1436: iload #7
    //   1438: invokevirtual resolve : (I)V
    //   1441: iload #7
    //   1443: istore #5
    //   1445: goto -> 1712
    //   1448: iload #7
    //   1450: istore #5
    //   1452: iload #6
    //   1454: ifle -> 1479
    //   1457: iload #21
    //   1459: ifeq -> 1472
    //   1462: iload #7
    //   1464: iload #8
    //   1466: isub
    //   1467: istore #5
    //   1469: goto -> 1479
    //   1472: iload #7
    //   1474: iload #8
    //   1476: iadd
    //   1477: istore #5
    //   1479: iload #5
    //   1481: istore #7
    //   1483: iload #6
    //   1485: ifle -> 1531
    //   1488: iload #5
    //   1490: istore #7
    //   1492: iload #6
    //   1494: iload #14
    //   1496: if_icmplt -> 1531
    //   1499: iload #21
    //   1501: ifeq -> 1519
    //   1504: iload #5
    //   1506: aload_1
    //   1507: getfield start : Landroidx/constraintlayout/solver/widgets/analyzer/DependencyNode;
    //   1510: getfield margin : I
    //   1513: isub
    //   1514: istore #7
    //   1516: goto -> 1531
    //   1519: iload #5
    //   1521: aload_1
    //   1522: getfield start : Landroidx/constraintlayout/solver/widgets/analyzer/DependencyNode;
    //   1525: getfield margin : I
    //   1528: iadd
    //   1529: istore #7
    //   1531: iload #21
    //   1533: ifeq -> 1548
    //   1536: aload_1
    //   1537: getfield end : Landroidx/constraintlayout/solver/widgets/analyzer/DependencyNode;
    //   1540: iload #7
    //   1542: invokevirtual resolve : (I)V
    //   1545: goto -> 1557
    //   1548: aload_1
    //   1549: getfield start : Landroidx/constraintlayout/solver/widgets/analyzer/DependencyNode;
    //   1552: iload #7
    //   1554: invokevirtual resolve : (I)V
    //   1557: aload_1
    //   1558: getfield dimension : Landroidx/constraintlayout/solver/widgets/analyzer/DimensionDependency;
    //   1561: astore #22
    //   1563: aload #22
    //   1565: getfield value : I
    //   1568: istore #9
    //   1570: iload #9
    //   1572: istore #5
    //   1574: aload_1
    //   1575: getfield dimensionBehavior : Landroidx/constraintlayout/solver/widgets/ConstraintWidget$DimensionBehaviour;
    //   1578: getstatic androidx/constraintlayout/solver/widgets/ConstraintWidget$DimensionBehaviour.MATCH_CONSTRAINT : Landroidx/constraintlayout/solver/widgets/ConstraintWidget$DimensionBehaviour;
    //   1581: if_acmpne -> 1603
    //   1584: iload #9
    //   1586: istore #5
    //   1588: aload_1
    //   1589: getfield matchConstraintsType : I
    //   1592: iconst_1
    //   1593: if_icmpne -> 1603
    //   1596: aload #22
    //   1598: getfield wrapValue : I
    //   1601: istore #5
    //   1603: iload #21
    //   1605: ifeq -> 1618
    //   1608: iload #7
    //   1610: iload #5
    //   1612: isub
    //   1613: istore #7
    //   1615: goto -> 1625
    //   1618: iload #7
    //   1620: iload #5
    //   1622: iadd
    //   1623: istore #7
    //   1625: iload #21
    //   1627: ifeq -> 1642
    //   1630: aload_1
    //   1631: getfield start : Landroidx/constraintlayout/solver/widgets/analyzer/DependencyNode;
    //   1634: iload #7
    //   1636: invokevirtual resolve : (I)V
    //   1639: goto -> 1651
    //   1642: aload_1
    //   1643: getfield end : Landroidx/constraintlayout/solver/widgets/analyzer/DependencyNode;
    //   1646: iload #7
    //   1648: invokevirtual resolve : (I)V
    //   1651: aload_1
    //   1652: iconst_1
    //   1653: putfield resolved : Z
    //   1656: iload #7
    //   1658: istore #5
    //   1660: iload #6
    //   1662: iload #18
    //   1664: if_icmpge -> 1712
    //   1667: iload #7
    //   1669: istore #5
    //   1671: iload #6
    //   1673: iload #15
    //   1675: if_icmpge -> 1712
    //   1678: iload #21
    //   1680: ifeq -> 1699
    //   1683: iload #7
    //   1685: aload_1
    //   1686: getfield end : Landroidx/constraintlayout/solver/widgets/analyzer/DependencyNode;
    //   1689: getfield margin : I
    //   1692: ineg
    //   1693: isub
    //   1694: istore #5
    //   1696: goto -> 1712
    //   1699: iload #7
    //   1701: aload_1
    //   1702: getfield end : Landroidx/constraintlayout/solver/widgets/analyzer/DependencyNode;
    //   1705: getfield margin : I
    //   1708: ineg
    //   1709: iadd
    //   1710: istore #5
    //   1712: iload #6
    //   1714: iconst_1
    //   1715: iadd
    //   1716: istore #6
    //   1718: iload #5
    //   1720: istore #7
    //   1722: goto -> 1370
    //   1725: iload #6
    //   1727: ifne -> 2091
    //   1730: iload #20
    //   1732: iload #8
    //   1734: isub
    //   1735: iload #7
    //   1737: iconst_1
    //   1738: iadd
    //   1739: idiv
    //   1740: istore #8
    //   1742: iload #9
    //   1744: ifle -> 1750
    //   1747: iconst_0
    //   1748: istore #8
    //   1750: iconst_0
    //   1751: istore #6
    //   1753: iload #6
    //   1755: iload #19
    //   1757: if_icmpge -> 2492
    //   1760: iload #21
    //   1762: ifeq -> 1777
    //   1765: iload #19
    //   1767: iload #6
    //   1769: iconst_1
    //   1770: iadd
    //   1771: isub
    //   1772: istore #7
    //   1774: goto -> 1781
    //   1777: iload #6
    //   1779: istore #7
    //   1781: aload_0
    //   1782: getfield widgets : Ljava/util/ArrayList;
    //   1785: iload #7
    //   1787: invokevirtual get : (I)Ljava/lang/Object;
    //   1790: checkcast androidx/constraintlayout/solver/widgets/analyzer/WidgetRun
    //   1793: astore_1
    //   1794: aload_1
    //   1795: getfield widget : Landroidx/constraintlayout/solver/widgets/ConstraintWidget;
    //   1798: invokevirtual getVisibility : ()I
    //   1801: bipush #8
    //   1803: if_icmpne -> 1827
    //   1806: aload_1
    //   1807: getfield start : Landroidx/constraintlayout/solver/widgets/analyzer/DependencyNode;
    //   1810: iload #5
    //   1812: invokevirtual resolve : (I)V
    //   1815: aload_1
    //   1816: getfield end : Landroidx/constraintlayout/solver/widgets/analyzer/DependencyNode;
    //   1819: iload #5
    //   1821: invokevirtual resolve : (I)V
    //   1824: goto -> 2082
    //   1827: iload #21
    //   1829: ifeq -> 1842
    //   1832: iload #5
    //   1834: iload #8
    //   1836: isub
    //   1837: istore #7
    //   1839: goto -> 1849
    //   1842: iload #5
    //   1844: iload #8
    //   1846: iadd
    //   1847: istore #7
    //   1849: iload #7
    //   1851: istore #5
    //   1853: iload #6
    //   1855: ifle -> 1901
    //   1858: iload #7
    //   1860: istore #5
    //   1862: iload #6
    //   1864: iload #14
    //   1866: if_icmplt -> 1901
    //   1869: iload #21
    //   1871: ifeq -> 1889
    //   1874: iload #7
    //   1876: aload_1
    //   1877: getfield start : Landroidx/constraintlayout/solver/widgets/analyzer/DependencyNode;
    //   1880: getfield margin : I
    //   1883: isub
    //   1884: istore #5
    //   1886: goto -> 1901
    //   1889: iload #7
    //   1891: aload_1
    //   1892: getfield start : Landroidx/constraintlayout/solver/widgets/analyzer/DependencyNode;
    //   1895: getfield margin : I
    //   1898: iadd
    //   1899: istore #5
    //   1901: iload #21
    //   1903: ifeq -> 1918
    //   1906: aload_1
    //   1907: getfield end : Landroidx/constraintlayout/solver/widgets/analyzer/DependencyNode;
    //   1910: iload #5
    //   1912: invokevirtual resolve : (I)V
    //   1915: goto -> 1927
    //   1918: aload_1
    //   1919: getfield start : Landroidx/constraintlayout/solver/widgets/analyzer/DependencyNode;
    //   1922: iload #5
    //   1924: invokevirtual resolve : (I)V
    //   1927: aload_1
    //   1928: getfield dimension : Landroidx/constraintlayout/solver/widgets/analyzer/DimensionDependency;
    //   1931: astore #22
    //   1933: aload #22
    //   1935: getfield value : I
    //   1938: istore #9
    //   1940: iload #9
    //   1942: istore #7
    //   1944: aload_1
    //   1945: getfield dimensionBehavior : Landroidx/constraintlayout/solver/widgets/ConstraintWidget$DimensionBehaviour;
    //   1948: getstatic androidx/constraintlayout/solver/widgets/ConstraintWidget$DimensionBehaviour.MATCH_CONSTRAINT : Landroidx/constraintlayout/solver/widgets/ConstraintWidget$DimensionBehaviour;
    //   1951: if_acmpne -> 1978
    //   1954: iload #9
    //   1956: istore #7
    //   1958: aload_1
    //   1959: getfield matchConstraintsType : I
    //   1962: iconst_1
    //   1963: if_icmpne -> 1978
    //   1966: iload #9
    //   1968: aload #22
    //   1970: getfield wrapValue : I
    //   1973: invokestatic min : (II)I
    //   1976: istore #7
    //   1978: iload #21
    //   1980: ifeq -> 1993
    //   1983: iload #5
    //   1985: iload #7
    //   1987: isub
    //   1988: istore #7
    //   1990: goto -> 2000
    //   1993: iload #5
    //   1995: iload #7
    //   1997: iadd
    //   1998: istore #7
    //   2000: iload #21
    //   2002: ifeq -> 2017
    //   2005: aload_1
    //   2006: getfield start : Landroidx/constraintlayout/solver/widgets/analyzer/DependencyNode;
    //   2009: iload #7
    //   2011: invokevirtual resolve : (I)V
    //   2014: goto -> 2026
    //   2017: aload_1
    //   2018: getfield end : Landroidx/constraintlayout/solver/widgets/analyzer/DependencyNode;
    //   2021: iload #7
    //   2023: invokevirtual resolve : (I)V
    //   2026: iload #7
    //   2028: istore #5
    //   2030: iload #6
    //   2032: iload #18
    //   2034: if_icmpge -> 2082
    //   2037: iload #7
    //   2039: istore #5
    //   2041: iload #6
    //   2043: iload #15
    //   2045: if_icmpge -> 2082
    //   2048: iload #21
    //   2050: ifeq -> 2069
    //   2053: iload #7
    //   2055: aload_1
    //   2056: getfield end : Landroidx/constraintlayout/solver/widgets/analyzer/DependencyNode;
    //   2059: getfield margin : I
    //   2062: ineg
    //   2063: isub
    //   2064: istore #5
    //   2066: goto -> 2082
    //   2069: iload #7
    //   2071: aload_1
    //   2072: getfield end : Landroidx/constraintlayout/solver/widgets/analyzer/DependencyNode;
    //   2075: getfield margin : I
    //   2078: ineg
    //   2079: iadd
    //   2080: istore #5
    //   2082: iload #6
    //   2084: iconst_1
    //   2085: iadd
    //   2086: istore #6
    //   2088: goto -> 1753
    //   2091: iload #6
    //   2093: iconst_2
    //   2094: if_icmpne -> 2492
    //   2097: aload_0
    //   2098: getfield orientation : I
    //   2101: ifne -> 2115
    //   2104: aload_0
    //   2105: getfield widget : Landroidx/constraintlayout/solver/widgets/ConstraintWidget;
    //   2108: invokevirtual getHorizontalBiasPercent : ()F
    //   2111: fstore_2
    //   2112: goto -> 2123
    //   2115: aload_0
    //   2116: getfield widget : Landroidx/constraintlayout/solver/widgets/ConstraintWidget;
    //   2119: invokevirtual getVerticalBiasPercent : ()F
    //   2122: fstore_2
    //   2123: fload_2
    //   2124: fstore_3
    //   2125: iload #21
    //   2127: ifeq -> 2134
    //   2130: fconst_1
    //   2131: fload_2
    //   2132: fsub
    //   2133: fstore_3
    //   2134: iload #20
    //   2136: iload #8
    //   2138: isub
    //   2139: i2f
    //   2140: fload_3
    //   2141: fmul
    //   2142: ldc 0.5
    //   2144: fadd
    //   2145: f2i
    //   2146: istore #6
    //   2148: iload #6
    //   2150: iflt -> 2158
    //   2153: iload #9
    //   2155: ifle -> 2161
    //   2158: iconst_0
    //   2159: istore #6
    //   2161: iload #21
    //   2163: ifeq -> 2176
    //   2166: iload #5
    //   2168: iload #6
    //   2170: isub
    //   2171: istore #5
    //   2173: goto -> 2183
    //   2176: iload #5
    //   2178: iload #6
    //   2180: iadd
    //   2181: istore #5
    //   2183: iconst_0
    //   2184: istore #6
    //   2186: iload #6
    //   2188: iload #19
    //   2190: if_icmpge -> 2492
    //   2193: iload #21
    //   2195: ifeq -> 2210
    //   2198: iload #19
    //   2200: iload #6
    //   2202: iconst_1
    //   2203: iadd
    //   2204: isub
    //   2205: istore #7
    //   2207: goto -> 2214
    //   2210: iload #6
    //   2212: istore #7
    //   2214: aload_0
    //   2215: getfield widgets : Ljava/util/ArrayList;
    //   2218: iload #7
    //   2220: invokevirtual get : (I)Ljava/lang/Object;
    //   2223: checkcast androidx/constraintlayout/solver/widgets/analyzer/WidgetRun
    //   2226: astore_1
    //   2227: aload_1
    //   2228: getfield widget : Landroidx/constraintlayout/solver/widgets/ConstraintWidget;
    //   2231: invokevirtual getVisibility : ()I
    //   2234: bipush #8
    //   2236: if_icmpne -> 2260
    //   2239: aload_1
    //   2240: getfield start : Landroidx/constraintlayout/solver/widgets/analyzer/DependencyNode;
    //   2243: iload #5
    //   2245: invokevirtual resolve : (I)V
    //   2248: aload_1
    //   2249: getfield end : Landroidx/constraintlayout/solver/widgets/analyzer/DependencyNode;
    //   2252: iload #5
    //   2254: invokevirtual resolve : (I)V
    //   2257: goto -> 2483
    //   2260: iload #5
    //   2262: istore #7
    //   2264: iload #6
    //   2266: ifle -> 2312
    //   2269: iload #5
    //   2271: istore #7
    //   2273: iload #6
    //   2275: iload #14
    //   2277: if_icmplt -> 2312
    //   2280: iload #21
    //   2282: ifeq -> 2300
    //   2285: iload #5
    //   2287: aload_1
    //   2288: getfield start : Landroidx/constraintlayout/solver/widgets/analyzer/DependencyNode;
    //   2291: getfield margin : I
    //   2294: isub
    //   2295: istore #7
    //   2297: goto -> 2312
    //   2300: iload #5
    //   2302: aload_1
    //   2303: getfield start : Landroidx/constraintlayout/solver/widgets/analyzer/DependencyNode;
    //   2306: getfield margin : I
    //   2309: iadd
    //   2310: istore #7
    //   2312: iload #21
    //   2314: ifeq -> 2329
    //   2317: aload_1
    //   2318: getfield end : Landroidx/constraintlayout/solver/widgets/analyzer/DependencyNode;
    //   2321: iload #7
    //   2323: invokevirtual resolve : (I)V
    //   2326: goto -> 2338
    //   2329: aload_1
    //   2330: getfield start : Landroidx/constraintlayout/solver/widgets/analyzer/DependencyNode;
    //   2333: iload #7
    //   2335: invokevirtual resolve : (I)V
    //   2338: aload_1
    //   2339: getfield dimension : Landroidx/constraintlayout/solver/widgets/analyzer/DimensionDependency;
    //   2342: astore #22
    //   2344: aload #22
    //   2346: getfield value : I
    //   2349: istore #5
    //   2351: aload_1
    //   2352: getfield dimensionBehavior : Landroidx/constraintlayout/solver/widgets/ConstraintWidget$DimensionBehaviour;
    //   2355: getstatic androidx/constraintlayout/solver/widgets/ConstraintWidget$DimensionBehaviour.MATCH_CONSTRAINT : Landroidx/constraintlayout/solver/widgets/ConstraintWidget$DimensionBehaviour;
    //   2358: if_acmpne -> 2379
    //   2361: aload_1
    //   2362: getfield matchConstraintsType : I
    //   2365: iconst_1
    //   2366: if_icmpne -> 2379
    //   2369: aload #22
    //   2371: getfield wrapValue : I
    //   2374: istore #5
    //   2376: goto -> 2379
    //   2379: iload #21
    //   2381: ifeq -> 2394
    //   2384: iload #7
    //   2386: iload #5
    //   2388: isub
    //   2389: istore #7
    //   2391: goto -> 2401
    //   2394: iload #7
    //   2396: iload #5
    //   2398: iadd
    //   2399: istore #7
    //   2401: iload #21
    //   2403: ifeq -> 2418
    //   2406: aload_1
    //   2407: getfield start : Landroidx/constraintlayout/solver/widgets/analyzer/DependencyNode;
    //   2410: iload #7
    //   2412: invokevirtual resolve : (I)V
    //   2415: goto -> 2427
    //   2418: aload_1
    //   2419: getfield end : Landroidx/constraintlayout/solver/widgets/analyzer/DependencyNode;
    //   2422: iload #7
    //   2424: invokevirtual resolve : (I)V
    //   2427: iload #7
    //   2429: istore #5
    //   2431: iload #6
    //   2433: iload #18
    //   2435: if_icmpge -> 2483
    //   2438: iload #7
    //   2440: istore #5
    //   2442: iload #6
    //   2444: iload #15
    //   2446: if_icmpge -> 2483
    //   2449: iload #21
    //   2451: ifeq -> 2470
    //   2454: iload #7
    //   2456: aload_1
    //   2457: getfield end : Landroidx/constraintlayout/solver/widgets/analyzer/DependencyNode;
    //   2460: getfield margin : I
    //   2463: ineg
    //   2464: isub
    //   2465: istore #5
    //   2467: goto -> 2483
    //   2470: iload #7
    //   2472: aload_1
    //   2473: getfield end : Landroidx/constraintlayout/solver/widgets/analyzer/DependencyNode;
    //   2476: getfield margin : I
    //   2479: ineg
    //   2480: iadd
    //   2481: istore #5
    //   2483: iload #6
    //   2485: iconst_1
    //   2486: iadd
    //   2487: istore #6
    //   2489: goto -> 2186
    //   2492: return
  }
}


/* Location:              C:\soft\dex2jar-2.0\BabyBus TV_Kids Videos & Games-dex2jar.jar!\androidx\constraintlayout\solver\widgets\analyzer\ChainRun.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */