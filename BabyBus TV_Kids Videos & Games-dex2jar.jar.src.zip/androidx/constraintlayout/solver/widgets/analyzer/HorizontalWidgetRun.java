package androidx.constraintlayout.solver.widgets.analyzer;

import androidx.constraintlayout.solver.widgets.ConstraintAnchor;
import androidx.constraintlayout.solver.widgets.ConstraintWidget;

public class HorizontalWidgetRun extends WidgetRun {
  private static int[] tempDimensions = new int[2];
  
  public HorizontalWidgetRun(ConstraintWidget paramConstraintWidget) {
    super(paramConstraintWidget);
    this.start.type = DependencyNode.Type.LEFT;
    this.end.type = DependencyNode.Type.RIGHT;
    this.orientation = 0;
  }
  
  private void computeInsetRatio(int[] paramArrayOfint, int paramInt1, int paramInt2, int paramInt3, int paramInt4, float paramFloat, int paramInt5) {
    paramInt1 = paramInt2 - paramInt1;
    paramInt2 = paramInt4 - paramInt3;
    if (paramInt5 != -1) {
      if (paramInt5 != 0) {
        if (paramInt5 != 1)
          return; 
        paramInt2 = (int)(paramInt1 * paramFloat + 0.5F);
        paramArrayOfint[0] = paramInt1;
        paramArrayOfint[1] = paramInt2;
        return;
      } 
      paramArrayOfint[0] = (int)(paramInt2 * paramFloat + 0.5F);
      paramArrayOfint[1] = paramInt2;
      return;
    } 
    paramInt3 = (int)(paramInt2 * paramFloat + 0.5F);
    paramInt4 = (int)(paramInt1 / paramFloat + 0.5F);
    if (paramInt3 <= paramInt1) {
      paramArrayOfint[0] = paramInt3;
      paramArrayOfint[1] = paramInt2;
      return;
    } 
    if (paramInt4 <= paramInt2) {
      paramArrayOfint[0] = paramInt1;
      paramArrayOfint[1] = paramInt4;
    } 
  }
  
  void apply() {
    DependencyNode dependencyNode2;
    ConstraintWidget constraintWidget2 = this.widget;
    if (constraintWidget2.measured)
      this.dimension.resolve(constraintWidget2.getWidth()); 
    if (!this.dimension.resolved) {
      ConstraintWidget.DimensionBehaviour dimensionBehaviour = this.widget.getHorizontalDimensionBehaviour();
      this.dimensionBehavior = dimensionBehaviour;
      if (dimensionBehaviour != ConstraintWidget.DimensionBehaviour.MATCH_CONSTRAINT) {
        ConstraintWidget.DimensionBehaviour dimensionBehaviour1 = ConstraintWidget.DimensionBehaviour.MATCH_PARENT;
        if (dimensionBehaviour == dimensionBehaviour1) {
          ConstraintWidget constraintWidget = this.widget.getParent();
          if ((constraintWidget != null && constraintWidget.getHorizontalDimensionBehaviour() == ConstraintWidget.DimensionBehaviour.FIXED) || constraintWidget.getHorizontalDimensionBehaviour() == dimensionBehaviour1) {
            int i = constraintWidget.getWidth();
            int j = this.widget.mLeft.getMargin();
            int k = this.widget.mRight.getMargin();
            addTarget(this.start, constraintWidget.horizontalRun.start, this.widget.mLeft.getMargin());
            addTarget(this.end, constraintWidget.horizontalRun.end, -this.widget.mRight.getMargin());
            this.dimension.resolve(i - j - k);
            return;
          } 
        } 
        if (this.dimensionBehavior == ConstraintWidget.DimensionBehaviour.FIXED)
          this.dimension.resolve(this.widget.getWidth()); 
      } 
    } else {
      ConstraintWidget.DimensionBehaviour dimensionBehaviour2 = this.dimensionBehavior;
      ConstraintWidget.DimensionBehaviour dimensionBehaviour1 = ConstraintWidget.DimensionBehaviour.MATCH_PARENT;
      if (dimensionBehaviour2 == dimensionBehaviour1) {
        ConstraintWidget constraintWidget = this.widget.getParent();
        if ((constraintWidget != null && constraintWidget.getHorizontalDimensionBehaviour() == ConstraintWidget.DimensionBehaviour.FIXED) || constraintWidget.getHorizontalDimensionBehaviour() == dimensionBehaviour1) {
          addTarget(this.start, constraintWidget.horizontalRun.start, this.widget.mLeft.getMargin());
          addTarget(this.end, constraintWidget.horizontalRun.end, -this.widget.mRight.getMargin());
          return;
        } 
      } 
    } 
    DependencyNode dependencyNode1 = this.dimension;
    if (dependencyNode1.resolved) {
      ConstraintWidget constraintWidget = this.widget;
      if (constraintWidget.measured) {
        ConstraintAnchor[] arrayOfConstraintAnchor1 = constraintWidget.mListAnchors;
        if ((arrayOfConstraintAnchor1[0]).mTarget != null && (arrayOfConstraintAnchor1[1]).mTarget != null) {
          if (constraintWidget.isInHorizontalChain()) {
            this.start.margin = this.widget.mListAnchors[0].getMargin();
            this.end.margin = -this.widget.mListAnchors[1].getMargin();
            return;
          } 
          dependencyNode1 = getTarget(this.widget.mListAnchors[0]);
          if (dependencyNode1 != null)
            addTarget(this.start, dependencyNode1, this.widget.mListAnchors[0].getMargin()); 
          dependencyNode1 = getTarget(this.widget.mListAnchors[1]);
          if (dependencyNode1 != null)
            addTarget(this.end, dependencyNode1, -this.widget.mListAnchors[1].getMargin()); 
          this.start.delegateToWidgetRun = true;
          this.end.delegateToWidgetRun = true;
          return;
        } 
        if (((ConstraintAnchor)dependencyNode1[0]).mTarget != null) {
          dependencyNode1 = getTarget((ConstraintAnchor)dependencyNode1[0]);
          if (dependencyNode1 != null) {
            addTarget(this.start, dependencyNode1, this.widget.mListAnchors[0].getMargin());
            addTarget(this.end, this.start, this.dimension.value);
            return;
          } 
        } else if (((ConstraintAnchor)dependencyNode1[1]).mTarget != null) {
          dependencyNode1 = getTarget((ConstraintAnchor)dependencyNode1[1]);
          if (dependencyNode1 != null) {
            addTarget(this.end, dependencyNode1, -this.widget.mListAnchors[1].getMargin());
            addTarget(this.start, this.end, -this.dimension.value);
            return;
          } 
        } else if (!(constraintWidget instanceof androidx.constraintlayout.solver.widgets.Helper) && constraintWidget.getParent() != null && (this.widget.getAnchor(ConstraintAnchor.Type.CENTER)).mTarget == null) {
          dependencyNode1 = (this.widget.getParent()).horizontalRun.start;
          addTarget(this.start, dependencyNode1, this.widget.getX());
          addTarget(this.end, this.start, this.dimension.value);
          return;
        } 
        return;
      } 
    } 
    if (this.dimensionBehavior == ConstraintWidget.DimensionBehaviour.MATCH_CONSTRAINT) {
      ConstraintWidget constraintWidget = this.widget;
      int i = constraintWidget.mMatchConstraintDefaultWidth;
      if (i != 2) {
        if (i == 3) {
          VerticalWidgetRun verticalWidgetRun;
          if (constraintWidget.mMatchConstraintDefaultHeight == 3) {
            this.start.updateDelegate = this;
            this.end.updateDelegate = this;
            VerticalWidgetRun verticalWidgetRun1 = constraintWidget.verticalRun;
            verticalWidgetRun1.start.updateDelegate = this;
            verticalWidgetRun1.end.updateDelegate = this;
            dependencyNode1.updateDelegate = this;
            if (constraintWidget.isInVerticalChain()) {
              this.dimension.targets.add(this.widget.verticalRun.dimension);
              this.widget.verticalRun.dimension.dependencies.add(this.dimension);
              verticalWidgetRun = this.widget.verticalRun;
              verticalWidgetRun.dimension.updateDelegate = this;
              this.dimension.targets.add(verticalWidgetRun.start);
              this.dimension.targets.add(this.widget.verticalRun.end);
              this.widget.verticalRun.start.dependencies.add(this.dimension);
              this.widget.verticalRun.end.dependencies.add(this.dimension);
            } else if (this.widget.isInHorizontalChain()) {
              this.widget.verticalRun.dimension.targets.add(this.dimension);
              this.dimension.dependencies.add(this.widget.verticalRun.dimension);
            } else {
              this.widget.verticalRun.dimension.targets.add(this.dimension);
            } 
          } else {
            dependencyNode2 = constraintWidget.verticalRun.dimension;
            ((DependencyNode)verticalWidgetRun).targets.add(dependencyNode2);
            dependencyNode2.dependencies.add(this.dimension);
            this.widget.verticalRun.start.dependencies.add(this.dimension);
            this.widget.verticalRun.end.dependencies.add(this.dimension);
            DimensionDependency dimensionDependency = this.dimension;
            dimensionDependency.delegateToWidgetRun = true;
            dimensionDependency.dependencies.add(this.start);
            this.dimension.dependencies.add(this.end);
            this.start.targets.add(this.dimension);
            this.end.targets.add(this.dimension);
          } 
        } 
      } else {
        ConstraintWidget constraintWidget3 = dependencyNode2.getParent();
        if (constraintWidget3 != null) {
          DimensionDependency dimensionDependency = constraintWidget3.verticalRun.dimension;
          this.dimension.targets.add(dimensionDependency);
          dimensionDependency.dependencies.add(this.dimension);
          dimensionDependency = this.dimension;
          dimensionDependency.delegateToWidgetRun = true;
          dimensionDependency.dependencies.add(this.start);
          this.dimension.dependencies.add(this.end);
        } 
      } 
    } 
    ConstraintWidget constraintWidget1 = this.widget;
    ConstraintAnchor[] arrayOfConstraintAnchor = constraintWidget1.mListAnchors;
    if ((arrayOfConstraintAnchor[0]).mTarget != null && (arrayOfConstraintAnchor[1]).mTarget != null) {
      if (constraintWidget1.isInHorizontalChain()) {
        this.start.margin = this.widget.mListAnchors[0].getMargin();
        this.end.margin = -this.widget.mListAnchors[1].getMargin();
        return;
      } 
      DependencyNode dependencyNode = getTarget(this.widget.mListAnchors[0]);
      dependencyNode2 = getTarget(this.widget.mListAnchors[1]);
      dependencyNode.addDependency(this);
      dependencyNode2.addDependency(this);
      this.mRunType = WidgetRun.RunType.CENTER;
      return;
    } 
    if (((ConstraintAnchor)dependencyNode2[0]).mTarget != null) {
      DependencyNode dependencyNode = getTarget((ConstraintAnchor)dependencyNode2[0]);
      if (dependencyNode != null) {
        addTarget(this.start, dependencyNode, this.widget.mListAnchors[0].getMargin());
        addTarget(this.end, this.start, 1, this.dimension);
        return;
      } 
    } else {
      DependencyNode dependencyNode;
      if (((ConstraintAnchor)dependencyNode2[1]).mTarget != null) {
        dependencyNode = getTarget((ConstraintAnchor)dependencyNode2[1]);
        if (dependencyNode != null) {
          addTarget(this.end, dependencyNode, -this.widget.mListAnchors[1].getMargin());
          addTarget(this.start, this.end, -1, this.dimension);
          return;
        } 
      } else if (!(dependencyNode instanceof androidx.constraintlayout.solver.widgets.Helper) && dependencyNode.getParent() != null) {
        dependencyNode = (this.widget.getParent()).horizontalRun.start;
        addTarget(this.start, dependencyNode, this.widget.getX());
        addTarget(this.end, this.start, 1, this.dimension);
      } 
    } 
  }
  
  public void applyToWidget() {
    DependencyNode dependencyNode = this.start;
    if (dependencyNode.resolved)
      this.widget.setX(dependencyNode.value); 
  }
  
  void clear() {
    this.runGroup = null;
    this.start.clear();
    this.end.clear();
    this.dimension.clear();
    this.resolved = false;
  }
  
  void reset() {
    this.resolved = false;
    this.start.clear();
    this.start.resolved = false;
    this.end.clear();
    this.end.resolved = false;
    this.dimension.resolved = false;
  }
  
  boolean supportsWrapComputation() {
    return (this.dimensionBehavior == ConstraintWidget.DimensionBehaviour.MATCH_CONSTRAINT) ? ((this.widget.mMatchConstraintDefaultWidth == 0)) : true;
  }
  
  public String toString() {
    StringBuilder stringBuilder = new StringBuilder();
    stringBuilder.append("HorizontalRun ");
    stringBuilder.append(this.widget.getDebugName());
    return stringBuilder.toString();
  }
  
  public void update(Dependency paramDependency) {
    int i = null.$SwitchMap$androidx$constraintlayout$solver$widgets$analyzer$WidgetRun$RunType[this.mRunType.ordinal()];
    if (i != 1) {
      if (i != 2) {
        if (i == 3) {
          ConstraintWidget constraintWidget = this.widget;
          updateRunCenter(paramDependency, constraintWidget.mLeft, constraintWidget.mRight, 0);
          return;
        } 
      } else {
        updateRunEnd(paramDependency);
      } 
    } else {
      updateRunStart(paramDependency);
    } 
    if (!this.dimension.resolved && this.dimensionBehavior == ConstraintWidget.DimensionBehaviour.MATCH_CONSTRAINT) {
      DependencyNode dependencyNode;
      ConstraintWidget constraintWidget = this.widget;
      i = constraintWidget.mMatchConstraintDefaultWidth;
      if (i != 2) {
        if (i == 3) {
          i = constraintWidget.mMatchConstraintDefaultHeight;
          if (i == 0 || i == 3) {
            int j;
            int k;
            int m;
            VerticalWidgetRun verticalWidgetRun = constraintWidget.verticalRun;
            paramDependency = verticalWidgetRun.start;
            DependencyNode dependencyNode1 = verticalWidgetRun.end;
            if (constraintWidget.mLeft.mTarget != null) {
              i = 1;
            } else {
              i = 0;
            } 
            if (constraintWidget.mTop.mTarget != null) {
              j = 1;
            } else {
              j = 0;
            } 
            if (constraintWidget.mRight.mTarget != null) {
              k = 1;
            } else {
              k = 0;
            } 
            if (constraintWidget.mBottom.mTarget != null) {
              m = 1;
            } else {
              m = 0;
            } 
            int n = constraintWidget.getDimensionRatioSide();
            if (i != 0 && j && k && m) {
              float f = this.widget.getDimensionRatio();
              if (((DependencyNode)paramDependency).resolved && dependencyNode1.resolved) {
                DependencyNode dependencyNode2 = this.start;
                if (dependencyNode2.readyToSolve) {
                  if (!this.end.readyToSolve)
                    return; 
                  i = ((DependencyNode)dependencyNode2.targets.get(0)).value;
                  j = this.start.margin;
                  k = ((DependencyNode)this.end.targets.get(0)).value;
                  m = this.end.margin;
                  int i1 = ((DependencyNode)paramDependency).value;
                  int i2 = ((DependencyNode)paramDependency).margin;
                  int i3 = dependencyNode1.value;
                  int i4 = dependencyNode1.margin;
                  computeInsetRatio(tempDimensions, i + j, k - m, i1 + i2, i3 - i4, f, n);
                  this.dimension.resolve(tempDimensions[0]);
                  this.widget.verticalRun.dimension.resolve(tempDimensions[1]);
                } 
                return;
              } 
              dependencyNode = this.start;
              if (dependencyNode.resolved) {
                DependencyNode dependencyNode2 = this.end;
                if (dependencyNode2.resolved)
                  if (((DependencyNode)paramDependency).readyToSolve) {
                    if (!dependencyNode1.readyToSolve)
                      return; 
                    i = dependencyNode.value;
                    j = dependencyNode.margin;
                    k = dependencyNode2.value;
                    m = dependencyNode2.margin;
                    int i1 = ((DependencyNode)((DependencyNode)paramDependency).targets.get(0)).value;
                    int i2 = ((DependencyNode)paramDependency).margin;
                    int i3 = ((DependencyNode)dependencyNode1.targets.get(0)).value;
                    int i4 = dependencyNode1.margin;
                    computeInsetRatio(tempDimensions, i + j, k - m, i1 + i2, i3 - i4, f, n);
                    this.dimension.resolve(tempDimensions[0]);
                    this.widget.verticalRun.dimension.resolve(tempDimensions[1]);
                  } else {
                    return;
                  }  
              } 
              dependencyNode = this.start;
              if (dependencyNode.readyToSolve && this.end.readyToSolve && ((DependencyNode)paramDependency).readyToSolve) {
                if (!dependencyNode1.readyToSolve)
                  return; 
                i = ((DependencyNode)dependencyNode.targets.get(0)).value;
                j = this.start.margin;
                k = ((DependencyNode)this.end.targets.get(0)).value;
                m = this.end.margin;
                int i1 = ((DependencyNode)((DependencyNode)paramDependency).targets.get(0)).value;
                int i2 = ((DependencyNode)paramDependency).margin;
                int i3 = ((DependencyNode)dependencyNode1.targets.get(0)).value;
                int i4 = dependencyNode1.margin;
                computeInsetRatio(tempDimensions, i + j, k - m, i1 + i2, i3 - i4, f, n);
                this.dimension.resolve(tempDimensions[0]);
                this.widget.verticalRun.dimension.resolve(tempDimensions[1]);
              } else {
                return;
              } 
            } else if (i != 0 && k != 0) {
              if (this.start.readyToSolve) {
                if (!this.end.readyToSolve)
                  return; 
                float f = this.widget.getDimensionRatio();
                i = ((DependencyNode)this.start.targets.get(0)).value + this.start.margin;
                j = ((DependencyNode)this.end.targets.get(0)).value - this.end.margin;
                if (n != -1 && n != 0) {
                  if (n == 1) {
                    i = getLimitedDimension(j - i, 0);
                    k = (int)(i / f + 0.5F);
                    j = getLimitedDimension(k, 1);
                    if (k != j)
                      i = (int)(j * f + 0.5F); 
                    this.dimension.resolve(i);
                    this.widget.verticalRun.dimension.resolve(j);
                  } 
                } else {
                  i = getLimitedDimension(j - i, 0);
                  k = (int)(i * f + 0.5F);
                  j = getLimitedDimension(k, 1);
                  if (k != j)
                    i = (int)(j / f + 0.5F); 
                  this.dimension.resolve(i);
                  this.widget.verticalRun.dimension.resolve(j);
                } 
              } else {
                return;
              } 
            } else if (j != 0 && m != 0) {
              if (((DependencyNode)paramDependency).readyToSolve) {
                if (!dependencyNode1.readyToSolve)
                  return; 
                float f = this.widget.getDimensionRatio();
                i = ((DependencyNode)((DependencyNode)paramDependency).targets.get(0)).value + ((DependencyNode)paramDependency).margin;
                j = ((DependencyNode)dependencyNode1.targets.get(0)).value - dependencyNode1.margin;
                if (n != -1)
                  if (n != 0) {
                    if (n != 1)
                      paramDependency = this.start; 
                  } else {
                    i = getLimitedDimension(j - i, 1);
                    k = (int)(i * f + 0.5F);
                    j = getLimitedDimension(k, 0);
                    if (k != j)
                      i = (int)(j / f + 0.5F); 
                    this.dimension.resolve(j);
                    this.widget.verticalRun.dimension.resolve(i);
                    paramDependency = this.start;
                  }  
                i = getLimitedDimension(j - i, 1);
                k = (int)(i / f + 0.5F);
                j = getLimitedDimension(k, 0);
                if (k != j)
                  i = (int)(j * f + 0.5F); 
                this.dimension.resolve(j);
                this.widget.verticalRun.dimension.resolve(i);
              } else {
                return;
              } 
            } 
          } else {
            i = dependencyNode.getDimensionRatioSide();
            if (i != -1) {
              if (i != 0) {
                if (i != 1) {
                  i = 0;
                } else {
                  ConstraintWidget constraintWidget1 = this.widget;
                  float f2 = constraintWidget1.verticalRun.dimension.value;
                  float f1 = constraintWidget1.getDimensionRatio();
                  f1 = f2 * f1;
                } 
              } else {
                ConstraintWidget constraintWidget1 = this.widget;
                float f = constraintWidget1.verticalRun.dimension.value / constraintWidget1.getDimensionRatio();
                i = (int)(f + 0.5F);
              } 
            } else {
              ConstraintWidget constraintWidget1 = this.widget;
              float f2 = constraintWidget1.verticalRun.dimension.value;
              float f1 = constraintWidget1.getDimensionRatio();
              f1 = f2 * f1;
            } 
            this.dimension.resolve(i);
          } 
        } 
      } else {
        ConstraintWidget constraintWidget1 = dependencyNode.getParent();
        if (constraintWidget1 != null) {
          DimensionDependency dimensionDependency = constraintWidget1.horizontalRun.dimension;
          if (dimensionDependency.resolved) {
            float f = this.widget.mMatchConstraintPercentWidth;
            i = (int)(dimensionDependency.value * f + 0.5F);
            this.dimension.resolve(i);
          } 
        } 
      } 
    } 
    paramDependency = this.start;
  }
}


/* Location:              C:\soft\dex2jar-2.0\BabyBus TV_Kids Videos & Games-dex2jar.jar!\androidx\constraintlayout\solver\widgets\analyzer\HorizontalWidgetRun.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */