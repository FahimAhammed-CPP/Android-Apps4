package androidx.constraintlayout.solver.widgets;

import androidx.constraintlayout.solver.widgets.analyzer.BasicMeasure;

public class VirtualLayout extends HelperWidget {
  protected BasicMeasure.Measure mMeasure = new BasicMeasure.Measure();
  
  private int mMeasuredHeight = 0;
  
  private int mMeasuredWidth = 0;
  
  BasicMeasure.Measurer mMeasurer = null;
  
  private boolean mNeedsCallFromSolver = false;
  
  private int mPaddingBottom = 0;
  
  private int mPaddingEnd = 0;
  
  private int mPaddingLeft = 0;
  
  private int mPaddingRight = 0;
  
  private int mPaddingStart = 0;
  
  private int mPaddingTop = 0;
  
  private int mResolvedPaddingLeft = 0;
  
  private int mResolvedPaddingRight = 0;
  
  public void applyRtl(boolean paramBoolean) {
    int i = this.mPaddingStart;
    if (i > 0 || this.mPaddingEnd > 0) {
      if (paramBoolean) {
        this.mResolvedPaddingLeft = this.mPaddingEnd;
        this.mResolvedPaddingRight = i;
        return;
      } 
      this.mResolvedPaddingLeft = i;
      this.mResolvedPaddingRight = this.mPaddingEnd;
    } 
  }
  
  public void captureWidgets() {
    for (int i = 0; i < this.mWidgetsCount; i++) {
      ConstraintWidget constraintWidget = this.mWidgets[i];
      if (constraintWidget != null)
        constraintWidget.setInVirtualLayout(true); 
    } 
  }
  
  public int getMeasuredHeight() {
    return this.mMeasuredHeight;
  }
  
  public int getMeasuredWidth() {
    return this.mMeasuredWidth;
  }
  
  public int getPaddingBottom() {
    return this.mPaddingBottom;
  }
  
  public int getPaddingLeft() {
    return this.mResolvedPaddingLeft;
  }
  
  public int getPaddingRight() {
    return this.mResolvedPaddingRight;
  }
  
  public int getPaddingTop() {
    return this.mPaddingTop;
  }
  
  public void measure(int paramInt1, int paramInt2, int paramInt3, int paramInt4) {}
  
  protected void measure(ConstraintWidget paramConstraintWidget, ConstraintWidget.DimensionBehaviour paramDimensionBehaviour1, int paramInt1, ConstraintWidget.DimensionBehaviour paramDimensionBehaviour2, int paramInt2) {
    while (this.mMeasurer == null && getParent() != null)
      this.mMeasurer = ((ConstraintWidgetContainer)getParent()).getMeasurer(); 
    BasicMeasure.Measure measure = this.mMeasure;
    measure.horizontalBehavior = paramDimensionBehaviour1;
    measure.verticalBehavior = paramDimensionBehaviour2;
    measure.horizontalDimension = paramInt1;
    measure.verticalDimension = paramInt2;
    this.mMeasurer.measure(paramConstraintWidget, measure);
    paramConstraintWidget.setWidth(this.mMeasure.measuredWidth);
    paramConstraintWidget.setHeight(this.mMeasure.measuredHeight);
    paramConstraintWidget.setHasBaseline(this.mMeasure.measuredHasBaseline);
    paramConstraintWidget.setBaselineDistance(this.mMeasure.measuredBaseline);
  }
  
  protected boolean measureChildren() {
    ConstraintWidget constraintWidget = this.mParent;
    if (constraintWidget != null) {
      BasicMeasure.Measurer measurer = ((ConstraintWidgetContainer)constraintWidget).getMeasurer();
    } else {
      constraintWidget = null;
    } 
    if (constraintWidget == null)
      return false; 
    int i = 0;
    while (true) {
      int j = this.mWidgetsCount;
      boolean bool = true;
      if (i < j) {
        ConstraintWidget constraintWidget1 = this.mWidgets[i];
        if (constraintWidget1 != null && !(constraintWidget1 instanceof Guideline)) {
          ConstraintWidget.DimensionBehaviour dimensionBehaviour1 = constraintWidget1.getDimensionBehaviour(0);
          ConstraintWidget.DimensionBehaviour dimensionBehaviour2 = constraintWidget1.getDimensionBehaviour(1);
          ConstraintWidget.DimensionBehaviour dimensionBehaviour3 = ConstraintWidget.DimensionBehaviour.MATCH_CONSTRAINT;
          if (dimensionBehaviour1 != dimensionBehaviour3 || constraintWidget1.mMatchConstraintDefaultWidth == 1 || dimensionBehaviour2 != dimensionBehaviour3 || constraintWidget1.mMatchConstraintDefaultHeight == 1)
            bool = false; 
          if (!bool) {
            ConstraintWidget.DimensionBehaviour dimensionBehaviour = dimensionBehaviour1;
            if (dimensionBehaviour1 == dimensionBehaviour3)
              dimensionBehaviour = ConstraintWidget.DimensionBehaviour.WRAP_CONTENT; 
            dimensionBehaviour1 = dimensionBehaviour2;
            if (dimensionBehaviour2 == dimensionBehaviour3)
              dimensionBehaviour1 = ConstraintWidget.DimensionBehaviour.WRAP_CONTENT; 
            BasicMeasure.Measure measure = this.mMeasure;
            measure.horizontalBehavior = dimensionBehaviour;
            measure.verticalBehavior = dimensionBehaviour1;
            measure.horizontalDimension = constraintWidget1.getWidth();
            this.mMeasure.verticalDimension = constraintWidget1.getHeight();
            constraintWidget.measure(constraintWidget1, this.mMeasure);
            constraintWidget1.setWidth(this.mMeasure.measuredWidth);
            constraintWidget1.setHeight(this.mMeasure.measuredHeight);
            constraintWidget1.setBaselineDistance(this.mMeasure.measuredBaseline);
          } 
        } 
        i++;
        continue;
      } 
      return true;
    } 
  }
  
  public boolean needSolverPass() {
    return this.mNeedsCallFromSolver;
  }
  
  protected void needsCallbackFromSolver(boolean paramBoolean) {
    this.mNeedsCallFromSolver = paramBoolean;
  }
  
  public void setMeasure(int paramInt1, int paramInt2) {
    this.mMeasuredWidth = paramInt1;
    this.mMeasuredHeight = paramInt2;
  }
  
  public void setPadding(int paramInt) {
    this.mPaddingLeft = paramInt;
    this.mPaddingTop = paramInt;
    this.mPaddingRight = paramInt;
    this.mPaddingBottom = paramInt;
    this.mPaddingStart = paramInt;
    this.mPaddingEnd = paramInt;
  }
  
  public void setPaddingBottom(int paramInt) {
    this.mPaddingBottom = paramInt;
  }
  
  public void setPaddingEnd(int paramInt) {
    this.mPaddingEnd = paramInt;
  }
  
  public void setPaddingLeft(int paramInt) {
    this.mPaddingLeft = paramInt;
    this.mResolvedPaddingLeft = paramInt;
  }
  
  public void setPaddingRight(int paramInt) {
    this.mPaddingRight = paramInt;
    this.mResolvedPaddingRight = paramInt;
  }
  
  public void setPaddingStart(int paramInt) {
    this.mPaddingStart = paramInt;
    this.mResolvedPaddingLeft = paramInt;
    this.mResolvedPaddingRight = paramInt;
  }
  
  public void setPaddingTop(int paramInt) {
    this.mPaddingTop = paramInt;
  }
  
  public void updateConstraints(ConstraintWidgetContainer paramConstraintWidgetContainer) {
    captureWidgets();
  }
}


/* Location:              C:\soft\dex2jar-2.0\BabyBus TV_Kids Videos & Games-dex2jar.jar!\androidx\constraintlayout\solver\widgets\VirtualLayout.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */