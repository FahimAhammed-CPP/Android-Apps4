package androidx.constraintlayout.solver;

import java.io.PrintStream;
import java.util.Arrays;

public class ArrayLinkedVariables implements ArrayRow.ArrayRowVariables {
  private static final boolean DEBUG = false;
  
  private static final boolean FULL_NEW_CHECK = false;
  
  static final int NONE = -1;
  
  private static float epsilon = 0.001F;
  
  private int ROW_SIZE = 8;
  
  private SolverVariable candidate = null;
  
  int currentSize = 0;
  
  private int[] mArrayIndices = new int[8];
  
  private int[] mArrayNextIndices = new int[8];
  
  private float[] mArrayValues = new float[8];
  
  protected final Cache mCache;
  
  private boolean mDidFillOnce = false;
  
  private int mHead = -1;
  
  private int mLast = -1;
  
  private final ArrayRow mRow;
  
  ArrayLinkedVariables(ArrayRow paramArrayRow, Cache paramCache) {
    this.mRow = paramArrayRow;
    this.mCache = paramCache;
  }
  
  public void add(SolverVariable paramSolverVariable, float paramFloat, boolean paramBoolean) {
    float f = epsilon;
    if (paramFloat > -f && paramFloat < f)
      return; 
    int i = this.mHead;
    if (i == -1) {
      this.mHead = 0;
      this.mArrayValues[0] = paramFloat;
      this.mArrayIndices[0] = paramSolverVariable.id;
      this.mArrayNextIndices[0] = -1;
      paramSolverVariable.usageInRowCount++;
      paramSolverVariable.addToRow(this.mRow);
      this.currentSize++;
      if (!this.mDidFillOnce) {
        i = this.mLast + 1;
        this.mLast = i;
        arrayOfInt1 = this.mArrayIndices;
        if (i >= arrayOfInt1.length) {
          this.mDidFillOnce = true;
          this.mLast = arrayOfInt1.length - 1;
        } 
      } 
      return;
    } 
    int j = 0;
    int k = -1;
    while (i != -1 && j < this.currentSize) {
      int[] arrayOfInt = this.mArrayIndices;
      int n = arrayOfInt[i];
      int m = ((SolverVariable)arrayOfInt1).id;
      if (n == m) {
        float[] arrayOfFloat = this.mArrayValues;
        f = arrayOfFloat[i] + paramFloat;
        float f1 = epsilon;
        paramFloat = f;
        if (f > -f1) {
          paramFloat = f;
          if (f < f1)
            paramFloat = 0.0F; 
        } 
        arrayOfFloat[i] = paramFloat;
        if (paramFloat == 0.0F) {
          if (i == this.mHead) {
            this.mHead = this.mArrayNextIndices[i];
          } else {
            arrayOfInt = this.mArrayNextIndices;
            arrayOfInt[k] = arrayOfInt[i];
          } 
          if (paramBoolean)
            arrayOfInt1.removeFromRow(this.mRow); 
          if (this.mDidFillOnce)
            this.mLast = i; 
          ((SolverVariable)arrayOfInt1).usageInRowCount--;
          this.currentSize--;
        } 
        return;
      } 
      if (arrayOfInt[i] < m)
        k = i; 
      i = this.mArrayNextIndices[i];
      j++;
    } 
    i = this.mLast;
    if (this.mDidFillOnce) {
      int[] arrayOfInt = this.mArrayIndices;
      if (arrayOfInt[i] != -1)
        i = arrayOfInt.length; 
    } else {
      i++;
    } 
    int[] arrayOfInt2 = this.mArrayIndices;
    j = i;
    if (i >= arrayOfInt2.length) {
      j = i;
      if (this.currentSize < arrayOfInt2.length) {
        int m = 0;
        while (true) {
          arrayOfInt2 = this.mArrayIndices;
          j = i;
          if (m < arrayOfInt2.length) {
            if (arrayOfInt2[m] == -1) {
              j = m;
              break;
            } 
            m++;
            continue;
          } 
          break;
        } 
      } 
    } 
    arrayOfInt2 = this.mArrayIndices;
    i = j;
    if (j >= arrayOfInt2.length) {
      i = arrayOfInt2.length;
      j = this.ROW_SIZE * 2;
      this.ROW_SIZE = j;
      this.mDidFillOnce = false;
      this.mLast = i - 1;
      this.mArrayValues = Arrays.copyOf(this.mArrayValues, j);
      this.mArrayIndices = Arrays.copyOf(this.mArrayIndices, this.ROW_SIZE);
      this.mArrayNextIndices = Arrays.copyOf(this.mArrayNextIndices, this.ROW_SIZE);
    } 
    this.mArrayIndices[i] = ((SolverVariable)arrayOfInt1).id;
    this.mArrayValues[i] = paramFloat;
    if (k != -1) {
      arrayOfInt2 = this.mArrayNextIndices;
      arrayOfInt2[i] = arrayOfInt2[k];
      arrayOfInt2[k] = i;
    } else {
      this.mArrayNextIndices[i] = this.mHead;
      this.mHead = i;
    } 
    ((SolverVariable)arrayOfInt1).usageInRowCount++;
    arrayOfInt1.addToRow(this.mRow);
    this.currentSize++;
    if (!this.mDidFillOnce)
      this.mLast++; 
    i = this.mLast;
    int[] arrayOfInt1 = this.mArrayIndices;
    if (i >= arrayOfInt1.length) {
      this.mDidFillOnce = true;
      this.mLast = arrayOfInt1.length - 1;
    } 
  }
  
  public final void clear() {
    int j = this.mHead;
    for (int i = 0; j != -1 && i < this.currentSize; i++) {
      SolverVariable solverVariable = this.mCache.mIndexedVariables[this.mArrayIndices[j]];
      if (solverVariable != null)
        solverVariable.removeFromRow(this.mRow); 
      j = this.mArrayNextIndices[j];
    } 
    this.mHead = -1;
    this.mLast = -1;
    this.mDidFillOnce = false;
    this.currentSize = 0;
  }
  
  public boolean contains(SolverVariable paramSolverVariable) {
    int j = this.mHead;
    if (j == -1)
      return false; 
    for (int i = 0; j != -1 && i < this.currentSize; i++) {
      if (this.mArrayIndices[j] == paramSolverVariable.id)
        return true; 
      j = this.mArrayNextIndices[j];
    } 
    return false;
  }
  
  public void display() {
    int j = this.currentSize;
    System.out.print("{ ");
    for (int i = 0; i < j; i++) {
      SolverVariable solverVariable = getVariable(i);
      if (solverVariable != null) {
        PrintStream printStream = System.out;
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append(solverVariable);
        stringBuilder.append(" = ");
        stringBuilder.append(getVariableValue(i));
        stringBuilder.append(" ");
        printStream.print(stringBuilder.toString());
      } 
    } 
    System.out.println(" }");
  }
  
  public void divideByAmount(float paramFloat) {
    int j = this.mHead;
    for (int i = 0; j != -1 && i < this.currentSize; i++) {
      float[] arrayOfFloat = this.mArrayValues;
      arrayOfFloat[j] = arrayOfFloat[j] / paramFloat;
      j = this.mArrayNextIndices[j];
    } 
  }
  
  public final float get(SolverVariable paramSolverVariable) {
    int j = this.mHead;
    for (int i = 0; j != -1 && i < this.currentSize; i++) {
      if (this.mArrayIndices[j] == paramSolverVariable.id)
        return this.mArrayValues[j]; 
      j = this.mArrayNextIndices[j];
    } 
    return 0.0F;
  }
  
  public int getCurrentSize() {
    return this.currentSize;
  }
  
  public int getHead() {
    return this.mHead;
  }
  
  public final int getId(int paramInt) {
    return this.mArrayIndices[paramInt];
  }
  
  public final int getNextIndice(int paramInt) {
    return this.mArrayNextIndices[paramInt];
  }
  
  SolverVariable getPivotCandidate() {
    // Byte code:
    //   0: aload_0
    //   1: getfield candidate : Landroidx/constraintlayout/solver/SolverVariable;
    //   4: astore_3
    //   5: aload_3
    //   6: ifnonnull -> 103
    //   9: aload_0
    //   10: getfield mHead : I
    //   13: istore_2
    //   14: iconst_0
    //   15: istore_1
    //   16: aconst_null
    //   17: astore_3
    //   18: iload_2
    //   19: iconst_m1
    //   20: if_icmpeq -> 101
    //   23: iload_1
    //   24: aload_0
    //   25: getfield currentSize : I
    //   28: if_icmpge -> 101
    //   31: aload_3
    //   32: astore #4
    //   34: aload_0
    //   35: getfield mArrayValues : [F
    //   38: iload_2
    //   39: faload
    //   40: fconst_0
    //   41: fcmpg
    //   42: ifge -> 84
    //   45: aload_0
    //   46: getfield mCache : Landroidx/constraintlayout/solver/Cache;
    //   49: getfield mIndexedVariables : [Landroidx/constraintlayout/solver/SolverVariable;
    //   52: aload_0
    //   53: getfield mArrayIndices : [I
    //   56: iload_2
    //   57: iaload
    //   58: aaload
    //   59: astore #5
    //   61: aload_3
    //   62: ifnull -> 80
    //   65: aload_3
    //   66: astore #4
    //   68: aload_3
    //   69: getfield strength : I
    //   72: aload #5
    //   74: getfield strength : I
    //   77: if_icmpge -> 84
    //   80: aload #5
    //   82: astore #4
    //   84: aload_0
    //   85: getfield mArrayNextIndices : [I
    //   88: iload_2
    //   89: iaload
    //   90: istore_2
    //   91: iload_1
    //   92: iconst_1
    //   93: iadd
    //   94: istore_1
    //   95: aload #4
    //   97: astore_3
    //   98: goto -> 18
    //   101: aload_3
    //   102: areturn
    //   103: aload_3
    //   104: areturn
  }
  
  public final float getValue(int paramInt) {
    return this.mArrayValues[paramInt];
  }
  
  public SolverVariable getVariable(int paramInt) {
    int j = this.mHead;
    for (int i = 0; j != -1 && i < this.currentSize; i++) {
      if (i == paramInt)
        return this.mCache.mIndexedVariables[this.mArrayIndices[j]]; 
      j = this.mArrayNextIndices[j];
    } 
    return null;
  }
  
  public float getVariableValue(int paramInt) {
    int j = this.mHead;
    for (int i = 0; j != -1 && i < this.currentSize; i++) {
      if (i == paramInt)
        return this.mArrayValues[j]; 
      j = this.mArrayNextIndices[j];
    } 
    return 0.0F;
  }
  
  boolean hasAtLeastOnePositiveVariable() {
    int j = this.mHead;
    for (int i = 0; j != -1 && i < this.currentSize; i++) {
      if (this.mArrayValues[j] > 0.0F)
        return true; 
      j = this.mArrayNextIndices[j];
    } 
    return false;
  }
  
  public int indexOf(SolverVariable paramSolverVariable) {
    int j = this.mHead;
    if (j == -1)
      return -1; 
    for (int i = 0; j != -1 && i < this.currentSize; i++) {
      if (this.mArrayIndices[j] == paramSolverVariable.id)
        return j; 
      j = this.mArrayNextIndices[j];
    } 
    return -1;
  }
  
  public void invert() {
    int j = this.mHead;
    for (int i = 0; j != -1 && i < this.currentSize; i++) {
      float[] arrayOfFloat = this.mArrayValues;
      arrayOfFloat[j] = arrayOfFloat[j] * -1.0F;
      j = this.mArrayNextIndices[j];
    } 
  }
  
  public final void put(SolverVariable paramSolverVariable, float paramFloat) {
    if (paramFloat == 0.0F) {
      remove(paramSolverVariable, true);
      return;
    } 
    int i = this.mHead;
    if (i == -1) {
      this.mHead = 0;
      this.mArrayValues[0] = paramFloat;
      this.mArrayIndices[0] = paramSolverVariable.id;
      this.mArrayNextIndices[0] = -1;
      paramSolverVariable.usageInRowCount++;
      paramSolverVariable.addToRow(this.mRow);
      this.currentSize++;
      if (!this.mDidFillOnce) {
        i = this.mLast + 1;
        this.mLast = i;
        arrayOfInt1 = this.mArrayIndices;
        if (i >= arrayOfInt1.length) {
          this.mDidFillOnce = true;
          this.mLast = arrayOfInt1.length - 1;
        } 
      } 
      return;
    } 
    int j = 0;
    int k = -1;
    while (i != -1 && j < this.currentSize) {
      int[] arrayOfInt = this.mArrayIndices;
      int n = arrayOfInt[i];
      int m = ((SolverVariable)arrayOfInt1).id;
      if (n == m) {
        this.mArrayValues[i] = paramFloat;
        return;
      } 
      if (arrayOfInt[i] < m)
        k = i; 
      i = this.mArrayNextIndices[i];
      j++;
    } 
    i = this.mLast;
    if (this.mDidFillOnce) {
      int[] arrayOfInt = this.mArrayIndices;
      if (arrayOfInt[i] != -1)
        i = arrayOfInt.length; 
    } else {
      i++;
    } 
    int[] arrayOfInt2 = this.mArrayIndices;
    j = i;
    if (i >= arrayOfInt2.length) {
      j = i;
      if (this.currentSize < arrayOfInt2.length) {
        int m = 0;
        while (true) {
          arrayOfInt2 = this.mArrayIndices;
          j = i;
          if (m < arrayOfInt2.length) {
            if (arrayOfInt2[m] == -1) {
              j = m;
              break;
            } 
            m++;
            continue;
          } 
          break;
        } 
      } 
    } 
    arrayOfInt2 = this.mArrayIndices;
    i = j;
    if (j >= arrayOfInt2.length) {
      i = arrayOfInt2.length;
      j = this.ROW_SIZE * 2;
      this.ROW_SIZE = j;
      this.mDidFillOnce = false;
      this.mLast = i - 1;
      this.mArrayValues = Arrays.copyOf(this.mArrayValues, j);
      this.mArrayIndices = Arrays.copyOf(this.mArrayIndices, this.ROW_SIZE);
      this.mArrayNextIndices = Arrays.copyOf(this.mArrayNextIndices, this.ROW_SIZE);
    } 
    this.mArrayIndices[i] = ((SolverVariable)arrayOfInt1).id;
    this.mArrayValues[i] = paramFloat;
    if (k != -1) {
      arrayOfInt2 = this.mArrayNextIndices;
      arrayOfInt2[i] = arrayOfInt2[k];
      arrayOfInt2[k] = i;
    } else {
      this.mArrayNextIndices[i] = this.mHead;
      this.mHead = i;
    } 
    ((SolverVariable)arrayOfInt1).usageInRowCount++;
    arrayOfInt1.addToRow(this.mRow);
    i = this.currentSize + 1;
    this.currentSize = i;
    if (!this.mDidFillOnce)
      this.mLast++; 
    int[] arrayOfInt1 = this.mArrayIndices;
    if (i >= arrayOfInt1.length)
      this.mDidFillOnce = true; 
    if (this.mLast >= arrayOfInt1.length) {
      this.mDidFillOnce = true;
      this.mLast = arrayOfInt1.length - 1;
    } 
  }
  
  public final float remove(SolverVariable paramSolverVariable, boolean paramBoolean) {
    if (this.candidate == paramSolverVariable)
      this.candidate = null; 
    int i = this.mHead;
    if (i == -1)
      return 0.0F; 
    int j = 0;
    int k = -1;
    while (i != -1 && j < this.currentSize) {
      if (this.mArrayIndices[i] == paramSolverVariable.id) {
        if (i == this.mHead) {
          this.mHead = this.mArrayNextIndices[i];
        } else {
          int[] arrayOfInt = this.mArrayNextIndices;
          arrayOfInt[k] = arrayOfInt[i];
        } 
        if (paramBoolean)
          paramSolverVariable.removeFromRow(this.mRow); 
        paramSolverVariable.usageInRowCount--;
        this.currentSize--;
        this.mArrayIndices[i] = -1;
        if (this.mDidFillOnce)
          this.mLast = i; 
        return this.mArrayValues[i];
      } 
      int m = this.mArrayNextIndices[i];
      j++;
      k = i;
      i = m;
    } 
    return 0.0F;
  }
  
  public int sizeInBytes() {
    return this.mArrayIndices.length * 4 * 3 + 0 + 36;
  }
  
  public String toString() {
    int j = this.mHead;
    String str = "";
    for (int i = 0; j != -1 && i < this.currentSize; i++) {
      StringBuilder stringBuilder = new StringBuilder();
      stringBuilder.append(str);
      stringBuilder.append(" -> ");
      str = stringBuilder.toString();
      stringBuilder = new StringBuilder();
      stringBuilder.append(str);
      stringBuilder.append(this.mArrayValues[j]);
      stringBuilder.append(" : ");
      str = stringBuilder.toString();
      stringBuilder = new StringBuilder();
      stringBuilder.append(str);
      stringBuilder.append(this.mCache.mIndexedVariables[this.mArrayIndices[j]]);
      str = stringBuilder.toString();
      j = this.mArrayNextIndices[j];
    } 
    return str;
  }
  
  public float use(ArrayRow paramArrayRow, boolean paramBoolean) {
    float f = get(paramArrayRow.variable);
    remove(paramArrayRow.variable, paramBoolean);
    ArrayRow.ArrayRowVariables arrayRowVariables = paramArrayRow.variables;
    int j = arrayRowVariables.getCurrentSize();
    int i;
    for (i = 0; i < j; i++) {
      SolverVariable solverVariable = arrayRowVariables.getVariable(i);
      add(solverVariable, arrayRowVariables.get(solverVariable) * f, paramBoolean);
    } 
    return f;
  }
}


/* Location:              C:\soft\dex2jar-2.0\BabyBus TV_Kids Videos & Games-dex2jar.jar!\androidx\constraintlayout\solver\ArrayLinkedVariables.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */