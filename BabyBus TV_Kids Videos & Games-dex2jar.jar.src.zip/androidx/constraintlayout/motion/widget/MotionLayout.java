package androidx.constraintlayout.motion.widget;

import android.content.Context;
import android.content.res.TypedArray;
import android.graphics.Canvas;
import android.graphics.DashPathEffect;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.PathEffect;
import android.graphics.Rect;
import android.graphics.RectF;
import android.os.Bundle;
import android.util.AttributeSet;
import android.util.Log;
import android.util.SparseArray;
import android.util.SparseIntArray;
import android.view.MotionEvent;
import android.view.VelocityTracker;
import android.view.View;
import android.view.ViewGroup;
import android.view.animation.Interpolator;
import android.widget.TextView;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.constraintlayout.motion.utils.StopLogic;
import androidx.constraintlayout.solver.widgets.Barrier;
import androidx.constraintlayout.solver.widgets.ConstraintAnchor;
import androidx.constraintlayout.solver.widgets.ConstraintWidget;
import androidx.constraintlayout.solver.widgets.ConstraintWidgetContainer;
import androidx.constraintlayout.solver.widgets.Flow;
import androidx.constraintlayout.solver.widgets.Guideline;
import androidx.constraintlayout.solver.widgets.Helper;
import androidx.constraintlayout.solver.widgets.HelperWidget;
import androidx.constraintlayout.solver.widgets.VirtualLayout;
import androidx.constraintlayout.widget.Barrier;
import androidx.constraintlayout.widget.ConstraintHelper;
import androidx.constraintlayout.widget.ConstraintLayout;
import androidx.constraintlayout.widget.ConstraintLayoutStates;
import androidx.constraintlayout.widget.ConstraintSet;
import androidx.constraintlayout.widget.Constraints;
import androidx.constraintlayout.widget.R;
import androidx.constraintlayout.widget.StateSet;
import androidx.core.view.NestedScrollingParent3;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;

public class MotionLayout extends ConstraintLayout implements NestedScrollingParent3 {
  private static final boolean DEBUG = false;
  
  public static final int DEBUG_SHOW_NONE = 0;
  
  public static final int DEBUG_SHOW_PATH = 2;
  
  public static final int DEBUG_SHOW_PROGRESS = 1;
  
  private static final float EPSILON = 1.0E-5F;
  
  public static boolean IS_IN_EDIT_MODE = false;
  
  static final int MAX_KEY_FRAMES = 50;
  
  static final String TAG = "MotionLayout";
  
  public static final int TOUCH_UP_COMPLETE = 0;
  
  public static final int TOUCH_UP_COMPLETE_TO_END = 2;
  
  public static final int TOUCH_UP_COMPLETE_TO_START = 1;
  
  public static final int TOUCH_UP_DECELERATE = 4;
  
  public static final int TOUCH_UP_DECELERATE_AND_COMPLETE = 5;
  
  public static final int TOUCH_UP_STOP = 3;
  
  public static final int VELOCITY_LAYOUT = 1;
  
  public static final int VELOCITY_POST_LAYOUT = 0;
  
  public static final int VELOCITY_STATIC_LAYOUT = 3;
  
  public static final int VELOCITY_STATIC_POST_LAYOUT = 2;
  
  boolean firstDown = true;
  
  private float lastPos;
  
  private float lastY;
  
  private long mAnimationStartTime = 0L;
  
  private int mBeginState = -1;
  
  private RectF mBoundsCheck = new RectF();
  
  int mCurrentState = -1;
  
  int mDebugPath = 0;
  
  private DecelerateInterpolator mDecelerateLogic = new DecelerateInterpolator();
  
  private DesignTool mDesignTool;
  
  DevModeDraw mDevModeDraw;
  
  private int mEndState = -1;
  
  int mEndWrapHeight;
  
  int mEndWrapWidth;
  
  HashMap<View, MotionController> mFrameArrayList = new HashMap<View, MotionController>();
  
  private int mFrames = 0;
  
  int mHeightMeasureMode;
  
  private boolean mInLayout = false;
  
  boolean mInTransition = false;
  
  boolean mIndirectTransition = false;
  
  private boolean mInteractionEnabled = true;
  
  Interpolator mInterpolator;
  
  boolean mIsAnimating = false;
  
  private boolean mKeepAnimating = false;
  
  private KeyCache mKeyCache = new KeyCache();
  
  private long mLastDrawTime = -1L;
  
  private float mLastFps = 0.0F;
  
  private int mLastHeightMeasureSpec = 0;
  
  int mLastLayoutHeight;
  
  int mLastLayoutWidth;
  
  float mLastVelocity = 0.0F;
  
  private int mLastWidthMeasureSpec = 0;
  
  private float mListenerPosition = 0.0F;
  
  private int mListenerState = 0;
  
  protected boolean mMeasureDuringTransition = false;
  
  Model mModel = new Model();
  
  private boolean mNeedsFireTransitionCompleted = false;
  
  int mOldHeight;
  
  int mOldWidth;
  
  private ArrayList<MotionHelper> mOnHideHelpers = null;
  
  private ArrayList<MotionHelper> mOnShowHelpers = null;
  
  float mPostInterpolationPosition;
  
  private View mRegionView = null;
  
  MotionScene mScene;
  
  float mScrollTargetDT;
  
  float mScrollTargetDX;
  
  float mScrollTargetDY;
  
  long mScrollTargetTime;
  
  int mStartWrapHeight;
  
  int mStartWrapWidth;
  
  private StateCache mStateCache;
  
  private StopLogic mStopLogic = new StopLogic();
  
  private boolean mTemporalInterpolator = false;
  
  ArrayList<Integer> mTransitionCompleted = new ArrayList<Integer>();
  
  private float mTransitionDuration = 1.0F;
  
  float mTransitionGoalPosition = 0.0F;
  
  private boolean mTransitionInstantly;
  
  float mTransitionLastPosition = 0.0F;
  
  private long mTransitionLastTime;
  
  private TransitionListener mTransitionListener;
  
  private ArrayList<TransitionListener> mTransitionListeners = null;
  
  float mTransitionPosition = 0.0F;
  
  TransitionState mTransitionState = TransitionState.UNDEFINED;
  
  boolean mUndergoingMotion = false;
  
  int mWidthMeasureMode;
  
  public MotionLayout(@NonNull Context paramContext) {
    super(paramContext);
    init(null);
  }
  
  public MotionLayout(@NonNull Context paramContext, @Nullable AttributeSet paramAttributeSet) {
    super(paramContext, paramAttributeSet);
    init(paramAttributeSet);
  }
  
  public MotionLayout(@NonNull Context paramContext, @Nullable AttributeSet paramAttributeSet, int paramInt) {
    super(paramContext, paramAttributeSet, paramInt);
    init(paramAttributeSet);
  }
  
  private void checkStructure() {
    MotionScene motionScene = this.mScene;
    if (motionScene == null) {
      Log.e("MotionLayout", "CHECK: motion scene not set! set \"app:layoutDescription=\"@xml/file\"");
      return;
    } 
    int i = motionScene.getStartId();
    motionScene = this.mScene;
    checkStructure(i, motionScene.getConstraintSet(motionScene.getStartId()));
    SparseIntArray sparseIntArray1 = new SparseIntArray();
    SparseIntArray sparseIntArray2 = new SparseIntArray();
    for (MotionScene.Transition transition : this.mScene.getDefinedTransitions()) {
      if (transition == this.mScene.mCurrentTransition)
        Log.v("MotionLayout", "CHECK: CURRENT"); 
      checkStructure(transition);
      i = transition.getStartConstraintSetId();
      int j = transition.getEndConstraintSetId();
      String str1 = Debug.getName(getContext(), i);
      String str2 = Debug.getName(getContext(), j);
      if (sparseIntArray1.get(i) == j) {
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("CHECK: two transitions with the same start and end ");
        stringBuilder.append(str1);
        stringBuilder.append("->");
        stringBuilder.append(str2);
        Log.e("MotionLayout", stringBuilder.toString());
      } 
      if (sparseIntArray2.get(j) == i) {
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("CHECK: you can't have reverse transitions");
        stringBuilder.append(str1);
        stringBuilder.append("->");
        stringBuilder.append(str2);
        Log.e("MotionLayout", stringBuilder.toString());
      } 
      sparseIntArray1.put(i, j);
      sparseIntArray2.put(j, i);
      if (this.mScene.getConstraintSet(i) == null) {
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append(" no such constraintSetStart ");
        stringBuilder.append(str1);
        Log.e("MotionLayout", stringBuilder.toString());
      } 
      if (this.mScene.getConstraintSet(j) == null) {
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append(" no such constraintSetEnd ");
        stringBuilder.append(str1);
        Log.e("MotionLayout", stringBuilder.toString());
      } 
    } 
  }
  
  private void checkStructure(int paramInt, ConstraintSet paramConstraintSet) {
    String str = Debug.getName(getContext(), paramInt);
    int j = getChildCount();
    int i = 0;
    for (paramInt = 0; paramInt < j; paramInt++) {
      View view = getChildAt(paramInt);
      int k = view.getId();
      if (k == -1) {
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("CHECK: ");
        stringBuilder.append(str);
        stringBuilder.append(" ALL VIEWS SHOULD HAVE ID's ");
        stringBuilder.append(view.getClass().getName());
        stringBuilder.append(" does not!");
        Log.w("MotionLayout", stringBuilder.toString());
      } 
      if (paramConstraintSet.getConstraint(k) == null) {
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("CHECK: ");
        stringBuilder.append(str);
        stringBuilder.append(" NO CONSTRAINTS for ");
        stringBuilder.append(Debug.getName(view));
        Log.w("MotionLayout", stringBuilder.toString());
      } 
    } 
    int[] arrayOfInt = paramConstraintSet.getKnownIds();
    for (paramInt = i; paramInt < arrayOfInt.length; paramInt++) {
      i = arrayOfInt[paramInt];
      String str1 = Debug.getName(getContext(), i);
      if (findViewById(arrayOfInt[paramInt]) == null) {
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("CHECK: ");
        stringBuilder.append(str);
        stringBuilder.append(" NO View matches id ");
        stringBuilder.append(str1);
        Log.w("MotionLayout", stringBuilder.toString());
      } 
      if (paramConstraintSet.getHeight(i) == -1) {
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("CHECK: ");
        stringBuilder.append(str);
        stringBuilder.append("(");
        stringBuilder.append(str1);
        stringBuilder.append(") no LAYOUT_HEIGHT");
        Log.w("MotionLayout", stringBuilder.toString());
      } 
      if (paramConstraintSet.getWidth(i) == -1) {
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("CHECK: ");
        stringBuilder.append(str);
        stringBuilder.append("(");
        stringBuilder.append(str1);
        stringBuilder.append(") no LAYOUT_HEIGHT");
        Log.w("MotionLayout", stringBuilder.toString());
      } 
    } 
  }
  
  private void checkStructure(MotionScene.Transition paramTransition) {
    StringBuilder stringBuilder = new StringBuilder();
    stringBuilder.append("CHECK: transition = ");
    stringBuilder.append(paramTransition.debugString(getContext()));
    Log.v("MotionLayout", stringBuilder.toString());
    stringBuilder = new StringBuilder();
    stringBuilder.append("CHECK: transition.setDuration = ");
    stringBuilder.append(paramTransition.getDuration());
    Log.v("MotionLayout", stringBuilder.toString());
    if (paramTransition.getStartConstraintSetId() == paramTransition.getEndConstraintSetId())
      Log.e("MotionLayout", "CHECK: start and end constraint set should not be the same!"); 
  }
  
  private void computeCurrentPositions() {
    int j = getChildCount();
    for (int i = 0; i < j; i++) {
      View view = getChildAt(i);
      MotionController motionController = this.mFrameArrayList.get(view);
      if (motionController != null)
        motionController.setStartCurrentState(view); 
    } 
  }
  
  private void debugPos() {
    for (int i = 0; i < getChildCount(); i++) {
      View view = getChildAt(i);
      StringBuilder stringBuilder = new StringBuilder();
      stringBuilder.append(" ");
      stringBuilder.append(Debug.getLocation());
      stringBuilder.append(" ");
      stringBuilder.append(Debug.getName((View)this));
      stringBuilder.append(" ");
      stringBuilder.append(Debug.getName(getContext(), this.mCurrentState));
      stringBuilder.append(" ");
      stringBuilder.append(Debug.getName(view));
      stringBuilder.append(view.getLeft());
      stringBuilder.append(" ");
      stringBuilder.append(view.getTop());
      Log.v("MotionLayout", stringBuilder.toString());
    } 
  }
  
  private void evaluateLayout() {
    // Byte code:
    //   0: aload_0
    //   1: getfield mTransitionGoalPosition : F
    //   4: aload_0
    //   5: getfield mTransitionLastPosition : F
    //   8: fsub
    //   9: invokestatic signum : (F)F
    //   12: fstore_3
    //   13: aload_0
    //   14: invokevirtual getNanoTime : ()J
    //   17: lstore #7
    //   19: aload_0
    //   20: getfield mInterpolator : Landroid/view/animation/Interpolator;
    //   23: astore #9
    //   25: aload #9
    //   27: instanceof androidx/constraintlayout/motion/utils/StopLogic
    //   30: ifne -> 56
    //   33: lload #7
    //   35: aload_0
    //   36: getfield mTransitionLastTime : J
    //   39: lsub
    //   40: l2f
    //   41: fload_3
    //   42: fmul
    //   43: ldc_w 1.0E-9
    //   46: fmul
    //   47: aload_0
    //   48: getfield mTransitionDuration : F
    //   51: fdiv
    //   52: fstore_1
    //   53: goto -> 58
    //   56: fconst_0
    //   57: fstore_1
    //   58: aload_0
    //   59: getfield mTransitionLastPosition : F
    //   62: fload_1
    //   63: fadd
    //   64: fstore_2
    //   65: aload_0
    //   66: getfield mTransitionInstantly : Z
    //   69: ifeq -> 77
    //   72: aload_0
    //   73: getfield mTransitionGoalPosition : F
    //   76: fstore_2
    //   77: iconst_0
    //   78: istore #5
    //   80: fload_3
    //   81: fconst_0
    //   82: fcmpl
    //   83: istore #6
    //   85: iload #6
    //   87: ifle -> 99
    //   90: fload_2
    //   91: aload_0
    //   92: getfield mTransitionGoalPosition : F
    //   95: fcmpl
    //   96: ifge -> 114
    //   99: fload_3
    //   100: fconst_0
    //   101: fcmpg
    //   102: ifgt -> 125
    //   105: fload_2
    //   106: aload_0
    //   107: getfield mTransitionGoalPosition : F
    //   110: fcmpg
    //   111: ifgt -> 125
    //   114: aload_0
    //   115: getfield mTransitionGoalPosition : F
    //   118: fstore_2
    //   119: iconst_1
    //   120: istore #4
    //   122: goto -> 128
    //   125: iconst_0
    //   126: istore #4
    //   128: fload_2
    //   129: fstore_1
    //   130: aload #9
    //   132: ifnull -> 181
    //   135: fload_2
    //   136: fstore_1
    //   137: iload #4
    //   139: ifne -> 181
    //   142: aload_0
    //   143: getfield mTemporalInterpolator : Z
    //   146: ifeq -> 172
    //   149: aload #9
    //   151: lload #7
    //   153: aload_0
    //   154: getfield mAnimationStartTime : J
    //   157: lsub
    //   158: l2f
    //   159: ldc_w 1.0E-9
    //   162: fmul
    //   163: invokeinterface getInterpolation : (F)F
    //   168: fstore_1
    //   169: goto -> 181
    //   172: aload #9
    //   174: fload_2
    //   175: invokeinterface getInterpolation : (F)F
    //   180: fstore_1
    //   181: iload #6
    //   183: ifle -> 195
    //   186: fload_1
    //   187: aload_0
    //   188: getfield mTransitionGoalPosition : F
    //   191: fcmpl
    //   192: ifge -> 214
    //   195: fload_1
    //   196: fstore_2
    //   197: fload_3
    //   198: fconst_0
    //   199: fcmpg
    //   200: ifgt -> 219
    //   203: fload_1
    //   204: fstore_2
    //   205: fload_1
    //   206: aload_0
    //   207: getfield mTransitionGoalPosition : F
    //   210: fcmpg
    //   211: ifgt -> 219
    //   214: aload_0
    //   215: getfield mTransitionGoalPosition : F
    //   218: fstore_2
    //   219: aload_0
    //   220: fload_2
    //   221: putfield mPostInterpolationPosition : F
    //   224: aload_0
    //   225: invokevirtual getChildCount : ()I
    //   228: istore #6
    //   230: aload_0
    //   231: invokevirtual getNanoTime : ()J
    //   234: lstore #7
    //   236: iload #5
    //   238: istore #4
    //   240: iload #4
    //   242: iload #6
    //   244: if_icmpge -> 298
    //   247: aload_0
    //   248: iload #4
    //   250: invokevirtual getChildAt : (I)Landroid/view/View;
    //   253: astore #9
    //   255: aload_0
    //   256: getfield mFrameArrayList : Ljava/util/HashMap;
    //   259: aload #9
    //   261: invokevirtual get : (Ljava/lang/Object;)Ljava/lang/Object;
    //   264: checkcast androidx/constraintlayout/motion/widget/MotionController
    //   267: astore #10
    //   269: aload #10
    //   271: ifnull -> 289
    //   274: aload #10
    //   276: aload #9
    //   278: fload_2
    //   279: lload #7
    //   281: aload_0
    //   282: getfield mKeyCache : Landroidx/constraintlayout/motion/widget/KeyCache;
    //   285: invokevirtual interpolate : (Landroid/view/View;FJLandroidx/constraintlayout/motion/widget/KeyCache;)Z
    //   288: pop
    //   289: iload #4
    //   291: iconst_1
    //   292: iadd
    //   293: istore #4
    //   295: goto -> 240
    //   298: aload_0
    //   299: getfield mMeasureDuringTransition : Z
    //   302: ifeq -> 309
    //   305: aload_0
    //   306: invokevirtual requestLayout : ()V
    //   309: return
  }
  
  private void fireTransitionChange() {
    // Byte code:
    //   0: aload_0
    //   1: getfield mTransitionListener : Landroidx/constraintlayout/motion/widget/MotionLayout$TransitionListener;
    //   4: ifnonnull -> 23
    //   7: aload_0
    //   8: getfield mTransitionListeners : Ljava/util/ArrayList;
    //   11: astore_2
    //   12: aload_2
    //   13: ifnull -> 219
    //   16: aload_2
    //   17: invokevirtual isEmpty : ()Z
    //   20: ifne -> 219
    //   23: aload_0
    //   24: getfield mListenerPosition : F
    //   27: aload_0
    //   28: getfield mTransitionPosition : F
    //   31: fcmpl
    //   32: ifeq -> 219
    //   35: aload_0
    //   36: getfield mListenerState : I
    //   39: iconst_m1
    //   40: if_icmpeq -> 121
    //   43: aload_0
    //   44: getfield mTransitionListener : Landroidx/constraintlayout/motion/widget/MotionLayout$TransitionListener;
    //   47: astore_2
    //   48: aload_2
    //   49: ifnull -> 67
    //   52: aload_2
    //   53: aload_0
    //   54: aload_0
    //   55: getfield mBeginState : I
    //   58: aload_0
    //   59: getfield mEndState : I
    //   62: invokeinterface onTransitionStarted : (Landroidx/constraintlayout/motion/widget/MotionLayout;II)V
    //   67: aload_0
    //   68: getfield mTransitionListeners : Ljava/util/ArrayList;
    //   71: astore_2
    //   72: aload_2
    //   73: ifnull -> 116
    //   76: aload_2
    //   77: invokevirtual iterator : ()Ljava/util/Iterator;
    //   80: astore_2
    //   81: aload_2
    //   82: invokeinterface hasNext : ()Z
    //   87: ifeq -> 116
    //   90: aload_2
    //   91: invokeinterface next : ()Ljava/lang/Object;
    //   96: checkcast androidx/constraintlayout/motion/widget/MotionLayout$TransitionListener
    //   99: aload_0
    //   100: aload_0
    //   101: getfield mBeginState : I
    //   104: aload_0
    //   105: getfield mEndState : I
    //   108: invokeinterface onTransitionStarted : (Landroidx/constraintlayout/motion/widget/MotionLayout;II)V
    //   113: goto -> 81
    //   116: aload_0
    //   117: iconst_1
    //   118: putfield mIsAnimating : Z
    //   121: aload_0
    //   122: iconst_m1
    //   123: putfield mListenerState : I
    //   126: aload_0
    //   127: getfield mTransitionPosition : F
    //   130: fstore_1
    //   131: aload_0
    //   132: fload_1
    //   133: putfield mListenerPosition : F
    //   136: aload_0
    //   137: getfield mTransitionListener : Landroidx/constraintlayout/motion/widget/MotionLayout$TransitionListener;
    //   140: astore_2
    //   141: aload_2
    //   142: ifnull -> 161
    //   145: aload_2
    //   146: aload_0
    //   147: aload_0
    //   148: getfield mBeginState : I
    //   151: aload_0
    //   152: getfield mEndState : I
    //   155: fload_1
    //   156: invokeinterface onTransitionChange : (Landroidx/constraintlayout/motion/widget/MotionLayout;IIF)V
    //   161: aload_0
    //   162: getfield mTransitionListeners : Ljava/util/ArrayList;
    //   165: astore_2
    //   166: aload_2
    //   167: ifnull -> 214
    //   170: aload_2
    //   171: invokevirtual iterator : ()Ljava/util/Iterator;
    //   174: astore_2
    //   175: aload_2
    //   176: invokeinterface hasNext : ()Z
    //   181: ifeq -> 214
    //   184: aload_2
    //   185: invokeinterface next : ()Ljava/lang/Object;
    //   190: checkcast androidx/constraintlayout/motion/widget/MotionLayout$TransitionListener
    //   193: aload_0
    //   194: aload_0
    //   195: getfield mBeginState : I
    //   198: aload_0
    //   199: getfield mEndState : I
    //   202: aload_0
    //   203: getfield mTransitionPosition : F
    //   206: invokeinterface onTransitionChange : (Landroidx/constraintlayout/motion/widget/MotionLayout;IIF)V
    //   211: goto -> 175
    //   214: aload_0
    //   215: iconst_1
    //   216: putfield mIsAnimating : Z
    //   219: return
  }
  
  private void fireTransitionStarted(MotionLayout paramMotionLayout, int paramInt1, int paramInt2) {
    TransitionListener transitionListener = this.mTransitionListener;
    if (transitionListener != null)
      transitionListener.onTransitionStarted(this, paramInt1, paramInt2); 
    ArrayList<TransitionListener> arrayList = this.mTransitionListeners;
    if (arrayList != null) {
      Iterator<TransitionListener> iterator = arrayList.iterator();
      while (iterator.hasNext())
        ((TransitionListener)iterator.next()).onTransitionStarted(paramMotionLayout, paramInt1, paramInt2); 
    } 
  }
  
  private boolean handlesTouchEvent(float paramFloat1, float paramFloat2, View paramView, MotionEvent paramMotionEvent) {
    if (paramView instanceof ViewGroup) {
      ViewGroup viewGroup = (ViewGroup)paramView;
      int j = viewGroup.getChildCount();
      int i;
      for (i = 0; i < j; i++) {
        View view = viewGroup.getChildAt(i);
        if (handlesTouchEvent(paramView.getLeft() + paramFloat1, paramView.getTop() + paramFloat2, view, paramMotionEvent))
          return true; 
      } 
    } 
    this.mBoundsCheck.set(paramView.getLeft() + paramFloat1, paramView.getTop() + paramFloat2, paramFloat1 + paramView.getRight(), paramFloat2 + paramView.getBottom());
    if (paramMotionEvent.getAction() == 0) {
      if (this.mBoundsCheck.contains(paramMotionEvent.getX(), paramMotionEvent.getY()) && paramView.onTouchEvent(paramMotionEvent))
        return true; 
    } else if (paramView.onTouchEvent(paramMotionEvent)) {
      return true;
    } 
    return false;
  }
  
  private void init(AttributeSet paramAttributeSet) {
    IS_IN_EDIT_MODE = isInEditMode();
    if (paramAttributeSet != null) {
      TypedArray typedArray = getContext().obtainStyledAttributes(paramAttributeSet, R.styleable.MotionLayout);
      int j = typedArray.getIndexCount();
      int i = 0;
      boolean bool;
      for (bool = true; i < j; bool = bool1) {
        boolean bool1;
        int k = typedArray.getIndex(i);
        if (k == R.styleable.MotionLayout_layoutDescription) {
          k = typedArray.getResourceId(k, -1);
          this.mScene = new MotionScene(getContext(), this, k);
          bool1 = bool;
        } else if (k == R.styleable.MotionLayout_currentState) {
          this.mCurrentState = typedArray.getResourceId(k, -1);
          bool1 = bool;
        } else if (k == R.styleable.MotionLayout_motionProgress) {
          this.mTransitionGoalPosition = typedArray.getFloat(k, 0.0F);
          this.mInTransition = true;
          bool1 = bool;
        } else if (k == R.styleable.MotionLayout_applyMotionScene) {
          bool1 = typedArray.getBoolean(k, bool);
        } else if (k == R.styleable.MotionLayout_showPaths) {
          bool1 = bool;
          if (this.mDebugPath == 0) {
            if (typedArray.getBoolean(k, false)) {
              k = 2;
            } else {
              k = 0;
            } 
            this.mDebugPath = k;
            bool1 = bool;
          } 
        } else {
          bool1 = bool;
          if (k == R.styleable.MotionLayout_motionDebug) {
            this.mDebugPath = typedArray.getInt(k, 0);
            bool1 = bool;
          } 
        } 
        i++;
      } 
      typedArray.recycle();
      if (this.mScene == null)
        Log.e("MotionLayout", "WARNING NO app:layoutDescription tag"); 
      if (!bool)
        this.mScene = null; 
    } 
    if (this.mDebugPath != 0)
      checkStructure(); 
    if (this.mCurrentState == -1) {
      MotionScene motionScene = this.mScene;
      if (motionScene != null) {
        this.mCurrentState = motionScene.getStartId();
        this.mBeginState = this.mScene.getStartId();
        this.mEndState = this.mScene.getEndId();
      } 
    } 
  }
  
  private void processTransitionCompleted() {
    if (this.mTransitionListener == null) {
      ArrayList<TransitionListener> arrayList = this.mTransitionListeners;
      if (arrayList == null || arrayList.isEmpty())
        return; 
    } 
    this.mIsAnimating = false;
    for (Integer integer : this.mTransitionCompleted) {
      TransitionListener transitionListener = this.mTransitionListener;
      if (transitionListener != null)
        transitionListener.onTransitionCompleted(this, integer.intValue()); 
      ArrayList<TransitionListener> arrayList = this.mTransitionListeners;
      if (arrayList != null) {
        Iterator<TransitionListener> iterator = arrayList.iterator();
        while (iterator.hasNext())
          ((TransitionListener)iterator.next()).onTransitionCompleted(this, integer.intValue()); 
      } 
    } 
    this.mTransitionCompleted.clear();
  }
  
  private void setupMotionViews() {
    int m = getChildCount();
    this.mModel.build();
    boolean bool = true;
    this.mInTransition = true;
    int j = getWidth();
    int n = getHeight();
    int i1 = this.mScene.gatPathMotionArc();
    int k = 0;
    byte b = 0;
    if (i1 != -1) {
      int i2;
      for (i2 = 0; i2 < m; i2++) {
        MotionController motionController = this.mFrameArrayList.get(getChildAt(i2));
        if (motionController != null)
          motionController.setPathMotionArc(i1); 
      } 
    } 
    int i;
    for (i = 0; i < m; i++) {
      MotionController motionController = this.mFrameArrayList.get(getChildAt(i));
      if (motionController != null) {
        this.mScene.getKeyFrames(motionController);
        motionController.setup(j, n, this.mTransitionDuration, getNanoTime());
      } 
    } 
    float f = this.mScene.getStaggered();
    if (f != 0.0F) {
      if (f < 0.0D) {
        i = 1;
      } else {
        i = 0;
      } 
      float f4 = Math.abs(f);
      float f2 = -3.4028235E38F;
      float f3 = Float.MAX_VALUE;
      j = 0;
      float f1 = Float.MAX_VALUE;
      f = -3.4028235E38F;
      while (true) {
        if (j < m) {
          MotionController motionController = this.mFrameArrayList.get(getChildAt(j));
          if (!Float.isNaN(motionController.mMotionStagger)) {
            j = bool;
            break;
          } 
          float f5 = motionController.getFinalX();
          float f6 = motionController.getFinalY();
          if (i != 0) {
            f5 = f6 - f5;
          } else {
            f5 = f6 + f5;
          } 
          f1 = Math.min(f1, f5);
          f = Math.max(f, f5);
          j++;
          continue;
        } 
        j = 0;
        break;
      } 
      if (j != 0) {
        j = 0;
        f1 = f3;
        f = f2;
        while (true) {
          k = b;
          if (j < m) {
            MotionController motionController = this.mFrameArrayList.get(getChildAt(j));
            f2 = f;
            float f5 = f1;
            if (!Float.isNaN(motionController.mMotionStagger)) {
              f5 = Math.min(f1, motionController.mMotionStagger);
              f2 = Math.max(f, motionController.mMotionStagger);
            } 
            j++;
            f = f2;
            f1 = f5;
            continue;
          } 
          break;
        } 
        while (k < m) {
          MotionController motionController = this.mFrameArrayList.get(getChildAt(k));
          if (!Float.isNaN(motionController.mMotionStagger)) {
            motionController.mStaggerScale = 1.0F / (1.0F - f4);
            if (i != 0) {
              motionController.mStaggerOffset = f4 - (f - motionController.mMotionStagger) / (f - f1) * f4;
            } else {
              motionController.mStaggerOffset = f4 - (motionController.mMotionStagger - f1) * f4 / (f - f1);
            } 
          } 
          k++;
        } 
      } else {
        while (k < m) {
          MotionController motionController = this.mFrameArrayList.get(getChildAt(k));
          float f5 = motionController.getFinalX();
          f2 = motionController.getFinalY();
          if (i != 0) {
            f5 = f2 - f5;
          } else {
            f5 = f2 + f5;
          } 
          motionController.mStaggerScale = 1.0F / (1.0F - f4);
          motionController.mStaggerOffset = f4 - (f5 - f1) * f4 / (f - f1);
          k++;
        } 
      } 
    } 
  }
  
  private static boolean willJump(float paramFloat1, float paramFloat2, float paramFloat3) {
    if (paramFloat1 > 0.0F) {
      float f1 = paramFloat1 / paramFloat3;
      return (paramFloat2 + paramFloat1 * f1 - paramFloat3 * f1 * f1 / 2.0F > 1.0F);
    } 
    float f = -paramFloat1 / paramFloat3;
    return (paramFloat2 + paramFloat1 * f + paramFloat3 * f * f / 2.0F < 0.0F);
  }
  
  public void addTransitionListener(TransitionListener paramTransitionListener) {
    if (this.mTransitionListeners == null)
      this.mTransitionListeners = new ArrayList<TransitionListener>(); 
    this.mTransitionListeners.add(paramTransitionListener);
  }
  
  void animateTo(float paramFloat) {
    MotionScene motionScene = this.mScene;
    if (motionScene == null)
      return; 
    float f1 = this.mTransitionLastPosition;
    float f2 = this.mTransitionPosition;
    if (f1 != f2 && this.mTransitionInstantly)
      this.mTransitionLastPosition = f2; 
    f1 = this.mTransitionLastPosition;
    if (f1 == paramFloat)
      return; 
    this.mTemporalInterpolator = false;
    this.mTransitionGoalPosition = paramFloat;
    this.mTransitionDuration = motionScene.getDuration() / 1000.0F;
    setProgress(this.mTransitionGoalPosition);
    this.mInterpolator = this.mScene.getInterpolator();
    this.mTransitionInstantly = false;
    this.mAnimationStartTime = getNanoTime();
    this.mInTransition = true;
    this.mTransitionPosition = f1;
    this.mTransitionLastPosition = f1;
    invalidate();
  }
  
  void disableAutoTransition(boolean paramBoolean) {
    MotionScene motionScene = this.mScene;
    if (motionScene == null)
      return; 
    motionScene.disableAutoTransition(paramBoolean);
  }
  
  protected void dispatchDraw(Canvas paramCanvas) {
    evaluate(false);
    super.dispatchDraw(paramCanvas);
    if (this.mScene == null)
      return; 
    if ((this.mDebugPath & 0x1) == 1 && !isInEditMode()) {
      this.mFrames++;
      long l1 = getNanoTime();
      long l2 = this.mLastDrawTime;
      if (l2 != -1L) {
        l2 = l1 - l2;
        if (l2 > 200000000L) {
          this.mLastFps = (int)(this.mFrames / (float)l2 * 1.0E-9F * 100.0F) / 100.0F;
          this.mFrames = 0;
          this.mLastDrawTime = l1;
        } 
      } else {
        this.mLastDrawTime = l1;
      } 
      Paint paint = new Paint();
      paint.setTextSize(42.0F);
      float f = (int)(getProgress() * 1000.0F) / 10.0F;
      StringBuilder stringBuilder1 = new StringBuilder();
      stringBuilder1.append(this.mLastFps);
      stringBuilder1.append(" fps ");
      stringBuilder1.append(Debug.getState(this, this.mBeginState));
      stringBuilder1.append(" -> ");
      String str = stringBuilder1.toString();
      StringBuilder stringBuilder2 = new StringBuilder();
      stringBuilder2.append(str);
      stringBuilder2.append(Debug.getState(this, this.mEndState));
      stringBuilder2.append(" (progress: ");
      stringBuilder2.append(f);
      stringBuilder2.append(" ) state=");
      int i = this.mCurrentState;
      if (i == -1) {
        str = "undefined";
      } else {
        str = Debug.getState(this, i);
      } 
      stringBuilder2.append(str);
      str = stringBuilder2.toString();
      paint.setColor(-16777216);
      paramCanvas.drawText(str, 11.0F, (getHeight() - 29), paint);
      paint.setColor(-7864184);
      paramCanvas.drawText(str, 10.0F, (getHeight() - 30), paint);
    } 
    if (this.mDebugPath > 1) {
      if (this.mDevModeDraw == null)
        this.mDevModeDraw = new DevModeDraw(); 
      this.mDevModeDraw.draw(paramCanvas, this.mFrameArrayList, this.mScene.getDuration(), this.mDebugPath);
    } 
  }
  
  public void enableTransition(int paramInt, boolean paramBoolean) {
    MotionScene.Transition transition = getTransition(paramInt);
    if (paramBoolean) {
      transition.setEnable(true);
      return;
    } 
    MotionScene motionScene = this.mScene;
    if (transition == motionScene.mCurrentTransition)
      for (MotionScene.Transition transition1 : motionScene.getTransitionsWithState(this.mCurrentState)) {
        if (transition1.isEnabled()) {
          this.mScene.mCurrentTransition = transition1;
          break;
        } 
      }  
    transition.setEnable(false);
  }
  
  void evaluate(boolean paramBoolean) {
    // Byte code:
    //   0: aload_0
    //   1: getfield mTransitionLastTime : J
    //   4: ldc2_w -1
    //   7: lcmp
    //   8: ifne -> 19
    //   11: aload_0
    //   12: aload_0
    //   13: invokevirtual getNanoTime : ()J
    //   16: putfield mTransitionLastTime : J
    //   19: aload_0
    //   20: getfield mTransitionLastPosition : F
    //   23: fstore_2
    //   24: fload_2
    //   25: fconst_0
    //   26: fcmpl
    //   27: ifle -> 41
    //   30: fload_2
    //   31: fconst_1
    //   32: fcmpg
    //   33: ifge -> 41
    //   36: aload_0
    //   37: iconst_m1
    //   38: putfield mCurrentState : I
    //   41: aload_0
    //   42: getfield mKeepAnimating : Z
    //   45: istore #15
    //   47: iconst_1
    //   48: istore #9
    //   50: iconst_1
    //   51: istore #10
    //   53: iconst_0
    //   54: istore #11
    //   56: iconst_0
    //   57: istore #8
    //   59: iload #15
    //   61: ifne -> 92
    //   64: iload #11
    //   66: istore #7
    //   68: aload_0
    //   69: getfield mInTransition : Z
    //   72: ifeq -> 993
    //   75: iload_1
    //   76: ifne -> 92
    //   79: iload #11
    //   81: istore #7
    //   83: aload_0
    //   84: getfield mTransitionGoalPosition : F
    //   87: fload_2
    //   88: fcmpl
    //   89: ifeq -> 993
    //   92: aload_0
    //   93: getfield mTransitionGoalPosition : F
    //   96: fload_2
    //   97: fsub
    //   98: invokestatic signum : (F)F
    //   101: fstore #5
    //   103: aload_0
    //   104: invokevirtual getNanoTime : ()J
    //   107: lstore #16
    //   109: aload_0
    //   110: getfield mInterpolator : Landroid/view/animation/Interpolator;
    //   113: astore #18
    //   115: aload #18
    //   117: instanceof androidx/constraintlayout/motion/widget/MotionInterpolator
    //   120: ifne -> 154
    //   123: lload #16
    //   125: aload_0
    //   126: getfield mTransitionLastTime : J
    //   129: lsub
    //   130: l2f
    //   131: fload #5
    //   133: fmul
    //   134: ldc_w 1.0E-9
    //   137: fmul
    //   138: aload_0
    //   139: getfield mTransitionDuration : F
    //   142: fdiv
    //   143: fstore #4
    //   145: aload_0
    //   146: fload #4
    //   148: putfield mLastVelocity : F
    //   151: goto -> 157
    //   154: fconst_0
    //   155: fstore #4
    //   157: aload_0
    //   158: getfield mTransitionLastPosition : F
    //   161: fload #4
    //   163: fadd
    //   164: fstore_3
    //   165: aload_0
    //   166: getfield mTransitionInstantly : Z
    //   169: ifeq -> 177
    //   172: aload_0
    //   173: getfield mTransitionGoalPosition : F
    //   176: fstore_3
    //   177: fload #5
    //   179: fconst_0
    //   180: fcmpl
    //   181: istore #11
    //   183: iload #11
    //   185: ifle -> 197
    //   188: fload_3
    //   189: aload_0
    //   190: getfield mTransitionGoalPosition : F
    //   193: fcmpl
    //   194: ifge -> 213
    //   197: fload #5
    //   199: fconst_0
    //   200: fcmpg
    //   201: ifgt -> 229
    //   204: fload_3
    //   205: aload_0
    //   206: getfield mTransitionGoalPosition : F
    //   209: fcmpg
    //   210: ifgt -> 229
    //   213: aload_0
    //   214: getfield mTransitionGoalPosition : F
    //   217: fstore_3
    //   218: aload_0
    //   219: iconst_0
    //   220: putfield mInTransition : Z
    //   223: iconst_1
    //   224: istore #7
    //   226: goto -> 232
    //   229: iconst_0
    //   230: istore #7
    //   232: aload_0
    //   233: fload_3
    //   234: putfield mTransitionLastPosition : F
    //   237: aload_0
    //   238: fload_3
    //   239: putfield mTransitionPosition : F
    //   242: aload_0
    //   243: lload #16
    //   245: putfield mTransitionLastTime : J
    //   248: fload_3
    //   249: fstore_2
    //   250: aload #18
    //   252: ifnull -> 481
    //   255: fload_3
    //   256: fstore_2
    //   257: iload #7
    //   259: ifne -> 481
    //   262: aload_0
    //   263: getfield mTemporalInterpolator : Z
    //   266: ifeq -> 420
    //   269: aload #18
    //   271: lload #16
    //   273: aload_0
    //   274: getfield mAnimationStartTime : J
    //   277: lsub
    //   278: l2f
    //   279: ldc_w 1.0E-9
    //   282: fmul
    //   283: invokeinterface getInterpolation : (F)F
    //   288: fstore #4
    //   290: aload_0
    //   291: fload #4
    //   293: putfield mTransitionLastPosition : F
    //   296: aload_0
    //   297: lload #16
    //   299: putfield mTransitionLastTime : J
    //   302: aload_0
    //   303: getfield mInterpolator : Landroid/view/animation/Interpolator;
    //   306: astore #18
    //   308: fload #4
    //   310: fstore_2
    //   311: aload #18
    //   313: instanceof androidx/constraintlayout/motion/widget/MotionInterpolator
    //   316: ifeq -> 481
    //   319: aload #18
    //   321: checkcast androidx/constraintlayout/motion/widget/MotionInterpolator
    //   324: invokevirtual getVelocity : ()F
    //   327: fstore #6
    //   329: aload_0
    //   330: fload #6
    //   332: putfield mLastVelocity : F
    //   335: fload #6
    //   337: invokestatic abs : (F)F
    //   340: aload_0
    //   341: getfield mTransitionDuration : F
    //   344: fmul
    //   345: ldc 1.0E-5
    //   347: fcmpg
    //   348: ifgt -> 356
    //   351: aload_0
    //   352: iconst_0
    //   353: putfield mInTransition : Z
    //   356: fload #4
    //   358: fstore_3
    //   359: fload #6
    //   361: fconst_0
    //   362: fcmpl
    //   363: ifle -> 388
    //   366: fload #4
    //   368: fstore_3
    //   369: fload #4
    //   371: fconst_1
    //   372: fcmpl
    //   373: iflt -> 388
    //   376: aload_0
    //   377: fconst_1
    //   378: putfield mTransitionLastPosition : F
    //   381: aload_0
    //   382: iconst_0
    //   383: putfield mInTransition : Z
    //   386: fconst_1
    //   387: fstore_3
    //   388: fload_3
    //   389: fstore_2
    //   390: fload #6
    //   392: fconst_0
    //   393: fcmpg
    //   394: ifge -> 481
    //   397: fload_3
    //   398: fstore_2
    //   399: fload_3
    //   400: fconst_0
    //   401: fcmpg
    //   402: ifgt -> 481
    //   405: aload_0
    //   406: fconst_0
    //   407: putfield mTransitionLastPosition : F
    //   410: aload_0
    //   411: iconst_0
    //   412: putfield mInTransition : Z
    //   415: fconst_0
    //   416: fstore_2
    //   417: goto -> 481
    //   420: aload #18
    //   422: fload_3
    //   423: invokeinterface getInterpolation : (F)F
    //   428: fstore_2
    //   429: aload_0
    //   430: getfield mInterpolator : Landroid/view/animation/Interpolator;
    //   433: astore #18
    //   435: aload #18
    //   437: instanceof androidx/constraintlayout/motion/widget/MotionInterpolator
    //   440: ifeq -> 458
    //   443: aload_0
    //   444: aload #18
    //   446: checkcast androidx/constraintlayout/motion/widget/MotionInterpolator
    //   449: invokevirtual getVelocity : ()F
    //   452: putfield mLastVelocity : F
    //   455: goto -> 481
    //   458: aload_0
    //   459: aload #18
    //   461: fload_3
    //   462: fload #4
    //   464: fadd
    //   465: invokeinterface getInterpolation : (F)F
    //   470: fload_2
    //   471: fsub
    //   472: fload #5
    //   474: fmul
    //   475: fload #4
    //   477: fdiv
    //   478: putfield mLastVelocity : F
    //   481: aload_0
    //   482: getfield mLastVelocity : F
    //   485: invokestatic abs : (F)F
    //   488: ldc 1.0E-5
    //   490: fcmpl
    //   491: ifle -> 501
    //   494: aload_0
    //   495: getstatic androidx/constraintlayout/motion/widget/MotionLayout$TransitionState.MOVING : Landroidx/constraintlayout/motion/widget/MotionLayout$TransitionState;
    //   498: invokevirtual setState : (Landroidx/constraintlayout/motion/widget/MotionLayout$TransitionState;)V
    //   501: iload #11
    //   503: ifle -> 515
    //   506: fload_2
    //   507: aload_0
    //   508: getfield mTransitionGoalPosition : F
    //   511: fcmpl
    //   512: ifge -> 535
    //   515: fload_2
    //   516: fstore_3
    //   517: fload #5
    //   519: fconst_0
    //   520: fcmpg
    //   521: ifgt -> 545
    //   524: fload_2
    //   525: fstore_3
    //   526: fload_2
    //   527: aload_0
    //   528: getfield mTransitionGoalPosition : F
    //   531: fcmpg
    //   532: ifgt -> 545
    //   535: aload_0
    //   536: getfield mTransitionGoalPosition : F
    //   539: fstore_3
    //   540: aload_0
    //   541: iconst_0
    //   542: putfield mInTransition : Z
    //   545: fload_3
    //   546: fconst_1
    //   547: fcmpl
    //   548: istore #12
    //   550: iload #12
    //   552: ifge -> 561
    //   555: fload_3
    //   556: fconst_0
    //   557: fcmpg
    //   558: ifgt -> 573
    //   561: aload_0
    //   562: iconst_0
    //   563: putfield mInTransition : Z
    //   566: aload_0
    //   567: getstatic androidx/constraintlayout/motion/widget/MotionLayout$TransitionState.FINISHED : Landroidx/constraintlayout/motion/widget/MotionLayout$TransitionState;
    //   570: invokevirtual setState : (Landroidx/constraintlayout/motion/widget/MotionLayout$TransitionState;)V
    //   573: aload_0
    //   574: invokevirtual getChildCount : ()I
    //   577: istore #13
    //   579: aload_0
    //   580: iconst_0
    //   581: putfield mKeepAnimating : Z
    //   584: aload_0
    //   585: invokevirtual getNanoTime : ()J
    //   588: lstore #16
    //   590: aload_0
    //   591: fload_3
    //   592: putfield mPostInterpolationPosition : F
    //   595: iconst_0
    //   596: istore #7
    //   598: iload #7
    //   600: iload #13
    //   602: if_icmpge -> 666
    //   605: aload_0
    //   606: iload #7
    //   608: invokevirtual getChildAt : (I)Landroid/view/View;
    //   611: astore #18
    //   613: aload_0
    //   614: getfield mFrameArrayList : Ljava/util/HashMap;
    //   617: aload #18
    //   619: invokevirtual get : (Ljava/lang/Object;)Ljava/lang/Object;
    //   622: checkcast androidx/constraintlayout/motion/widget/MotionController
    //   625: astore #19
    //   627: aload #19
    //   629: ifnull -> 657
    //   632: aload_0
    //   633: getfield mKeepAnimating : Z
    //   636: istore_1
    //   637: aload_0
    //   638: aload #19
    //   640: aload #18
    //   642: fload_3
    //   643: lload #16
    //   645: aload_0
    //   646: getfield mKeyCache : Landroidx/constraintlayout/motion/widget/KeyCache;
    //   649: invokevirtual interpolate : (Landroid/view/View;FJLandroidx/constraintlayout/motion/widget/KeyCache;)Z
    //   652: iload_1
    //   653: ior
    //   654: putfield mKeepAnimating : Z
    //   657: iload #7
    //   659: iconst_1
    //   660: iadd
    //   661: istore #7
    //   663: goto -> 598
    //   666: iload #11
    //   668: ifle -> 680
    //   671: fload_3
    //   672: aload_0
    //   673: getfield mTransitionGoalPosition : F
    //   676: fcmpl
    //   677: ifge -> 696
    //   680: fload #5
    //   682: fconst_0
    //   683: fcmpg
    //   684: ifgt -> 702
    //   687: fload_3
    //   688: aload_0
    //   689: getfield mTransitionGoalPosition : F
    //   692: fcmpg
    //   693: ifgt -> 702
    //   696: iconst_1
    //   697: istore #7
    //   699: goto -> 705
    //   702: iconst_0
    //   703: istore #7
    //   705: aload_0
    //   706: getfield mKeepAnimating : Z
    //   709: ifne -> 731
    //   712: aload_0
    //   713: getfield mInTransition : Z
    //   716: ifne -> 731
    //   719: iload #7
    //   721: ifeq -> 731
    //   724: aload_0
    //   725: getstatic androidx/constraintlayout/motion/widget/MotionLayout$TransitionState.FINISHED : Landroidx/constraintlayout/motion/widget/MotionLayout$TransitionState;
    //   728: invokevirtual setState : (Landroidx/constraintlayout/motion/widget/MotionLayout$TransitionState;)V
    //   731: aload_0
    //   732: getfield mMeasureDuringTransition : Z
    //   735: ifeq -> 742
    //   738: aload_0
    //   739: invokevirtual requestLayout : ()V
    //   742: aload_0
    //   743: iload #7
    //   745: iconst_1
    //   746: ixor
    //   747: aload_0
    //   748: getfield mKeepAnimating : Z
    //   751: ior
    //   752: putfield mKeepAnimating : Z
    //   755: iload #8
    //   757: istore #7
    //   759: fload_3
    //   760: fconst_0
    //   761: fcmpg
    //   762: ifgt -> 823
    //   765: aload_0
    //   766: getfield mBeginState : I
    //   769: istore #13
    //   771: iload #8
    //   773: istore #7
    //   775: iload #13
    //   777: iconst_m1
    //   778: if_icmpeq -> 823
    //   781: iload #8
    //   783: istore #7
    //   785: aload_0
    //   786: getfield mCurrentState : I
    //   789: iload #13
    //   791: if_icmpeq -> 823
    //   794: aload_0
    //   795: iload #13
    //   797: putfield mCurrentState : I
    //   800: aload_0
    //   801: getfield mScene : Landroidx/constraintlayout/motion/widget/MotionScene;
    //   804: iload #13
    //   806: invokevirtual getConstraintSet : (I)Landroidx/constraintlayout/widget/ConstraintSet;
    //   809: aload_0
    //   810: invokevirtual applyCustomAttributes : (Landroidx/constraintlayout/widget/ConstraintLayout;)V
    //   813: aload_0
    //   814: getstatic androidx/constraintlayout/motion/widget/MotionLayout$TransitionState.FINISHED : Landroidx/constraintlayout/motion/widget/MotionLayout$TransitionState;
    //   817: invokevirtual setState : (Landroidx/constraintlayout/motion/widget/MotionLayout$TransitionState;)V
    //   820: iconst_1
    //   821: istore #7
    //   823: iload #7
    //   825: istore #8
    //   827: fload_3
    //   828: f2d
    //   829: dconst_1
    //   830: dcmpl
    //   831: iflt -> 886
    //   834: aload_0
    //   835: getfield mCurrentState : I
    //   838: istore #13
    //   840: aload_0
    //   841: getfield mEndState : I
    //   844: istore #14
    //   846: iload #7
    //   848: istore #8
    //   850: iload #13
    //   852: iload #14
    //   854: if_icmpeq -> 886
    //   857: aload_0
    //   858: iload #14
    //   860: putfield mCurrentState : I
    //   863: aload_0
    //   864: getfield mScene : Landroidx/constraintlayout/motion/widget/MotionScene;
    //   867: iload #14
    //   869: invokevirtual getConstraintSet : (I)Landroidx/constraintlayout/widget/ConstraintSet;
    //   872: aload_0
    //   873: invokevirtual applyCustomAttributes : (Landroidx/constraintlayout/widget/ConstraintLayout;)V
    //   876: aload_0
    //   877: getstatic androidx/constraintlayout/motion/widget/MotionLayout$TransitionState.FINISHED : Landroidx/constraintlayout/motion/widget/MotionLayout$TransitionState;
    //   880: invokevirtual setState : (Landroidx/constraintlayout/motion/widget/MotionLayout$TransitionState;)V
    //   883: iconst_1
    //   884: istore #8
    //   886: aload_0
    //   887: getfield mKeepAnimating : Z
    //   890: ifne -> 936
    //   893: aload_0
    //   894: getfield mInTransition : Z
    //   897: ifeq -> 903
    //   900: goto -> 936
    //   903: iload #11
    //   905: ifle -> 913
    //   908: iload #12
    //   910: ifeq -> 926
    //   913: fload #5
    //   915: fconst_0
    //   916: fcmpg
    //   917: ifge -> 940
    //   920: fload_3
    //   921: fconst_0
    //   922: fcmpl
    //   923: ifne -> 940
    //   926: aload_0
    //   927: getstatic androidx/constraintlayout/motion/widget/MotionLayout$TransitionState.FINISHED : Landroidx/constraintlayout/motion/widget/MotionLayout$TransitionState;
    //   930: invokevirtual setState : (Landroidx/constraintlayout/motion/widget/MotionLayout$TransitionState;)V
    //   933: goto -> 940
    //   936: aload_0
    //   937: invokevirtual invalidate : ()V
    //   940: aload_0
    //   941: getfield mKeepAnimating : Z
    //   944: ifne -> 964
    //   947: aload_0
    //   948: getfield mInTransition : Z
    //   951: ifeq -> 964
    //   954: iload #11
    //   956: ifle -> 964
    //   959: iload #12
    //   961: ifeq -> 985
    //   964: iload #8
    //   966: istore #7
    //   968: fload #5
    //   970: fconst_0
    //   971: fcmpg
    //   972: ifge -> 993
    //   975: iload #8
    //   977: istore #7
    //   979: fload_3
    //   980: fconst_0
    //   981: fcmpl
    //   982: ifne -> 993
    //   985: aload_0
    //   986: invokevirtual onNewStateAttachHandlers : ()V
    //   989: iload #8
    //   991: istore #7
    //   993: aload_0
    //   994: getfield mTransitionLastPosition : F
    //   997: fstore_2
    //   998: fload_2
    //   999: fconst_1
    //   1000: fcmpl
    //   1001: iflt -> 1043
    //   1004: aload_0
    //   1005: getfield mCurrentState : I
    //   1008: istore #9
    //   1010: aload_0
    //   1011: getfield mEndState : I
    //   1014: istore #8
    //   1016: iload #9
    //   1018: iload #8
    //   1020: if_icmpeq -> 1030
    //   1023: iload #10
    //   1025: istore #7
    //   1027: goto -> 1030
    //   1030: aload_0
    //   1031: iload #8
    //   1033: putfield mCurrentState : I
    //   1036: iload #7
    //   1038: istore #8
    //   1040: goto -> 1088
    //   1043: iload #7
    //   1045: istore #8
    //   1047: fload_2
    //   1048: fconst_0
    //   1049: fcmpg
    //   1050: ifgt -> 1088
    //   1053: aload_0
    //   1054: getfield mCurrentState : I
    //   1057: istore #10
    //   1059: aload_0
    //   1060: getfield mBeginState : I
    //   1063: istore #8
    //   1065: iload #10
    //   1067: iload #8
    //   1069: if_icmpeq -> 1079
    //   1072: iload #9
    //   1074: istore #7
    //   1076: goto -> 1079
    //   1079: aload_0
    //   1080: iload #8
    //   1082: putfield mCurrentState : I
    //   1085: goto -> 1036
    //   1088: aload_0
    //   1089: aload_0
    //   1090: getfield mNeedsFireTransitionCompleted : Z
    //   1093: iload #8
    //   1095: ior
    //   1096: putfield mNeedsFireTransitionCompleted : Z
    //   1099: iload #8
    //   1101: ifeq -> 1115
    //   1104: aload_0
    //   1105: getfield mInLayout : Z
    //   1108: ifne -> 1115
    //   1111: aload_0
    //   1112: invokevirtual requestLayout : ()V
    //   1115: aload_0
    //   1116: aload_0
    //   1117: getfield mTransitionLastPosition : F
    //   1120: putfield mTransitionPosition : F
    //   1123: return
  }
  
  protected void fireTransitionCompleted() {
    // Byte code:
    //   0: aload_0
    //   1: getfield mTransitionListener : Landroidx/constraintlayout/motion/widget/MotionLayout$TransitionListener;
    //   4: ifnonnull -> 23
    //   7: aload_0
    //   8: getfield mTransitionListeners : Ljava/util/ArrayList;
    //   11: astore_3
    //   12: aload_3
    //   13: ifnull -> 103
    //   16: aload_3
    //   17: invokevirtual isEmpty : ()Z
    //   20: ifne -> 103
    //   23: aload_0
    //   24: getfield mListenerState : I
    //   27: iconst_m1
    //   28: if_icmpne -> 103
    //   31: aload_0
    //   32: aload_0
    //   33: getfield mCurrentState : I
    //   36: putfield mListenerState : I
    //   39: aload_0
    //   40: getfield mTransitionCompleted : Ljava/util/ArrayList;
    //   43: invokevirtual isEmpty : ()Z
    //   46: ifne -> 74
    //   49: aload_0
    //   50: getfield mTransitionCompleted : Ljava/util/ArrayList;
    //   53: astore_3
    //   54: aload_3
    //   55: aload_3
    //   56: invokevirtual size : ()I
    //   59: iconst_1
    //   60: isub
    //   61: invokevirtual get : (I)Ljava/lang/Object;
    //   64: checkcast java/lang/Integer
    //   67: invokevirtual intValue : ()I
    //   70: istore_1
    //   71: goto -> 76
    //   74: iconst_m1
    //   75: istore_1
    //   76: aload_0
    //   77: getfield mCurrentState : I
    //   80: istore_2
    //   81: iload_1
    //   82: iload_2
    //   83: if_icmpeq -> 103
    //   86: iload_2
    //   87: iconst_m1
    //   88: if_icmpeq -> 103
    //   91: aload_0
    //   92: getfield mTransitionCompleted : Ljava/util/ArrayList;
    //   95: iload_2
    //   96: invokestatic valueOf : (I)Ljava/lang/Integer;
    //   99: invokevirtual add : (Ljava/lang/Object;)Z
    //   102: pop
    //   103: aload_0
    //   104: invokespecial processTransitionCompleted : ()V
    //   107: return
  }
  
  public void fireTrigger(int paramInt, boolean paramBoolean, float paramFloat) {
    TransitionListener transitionListener = this.mTransitionListener;
    if (transitionListener != null)
      transitionListener.onTransitionTrigger(this, paramInt, paramBoolean, paramFloat); 
    ArrayList<TransitionListener> arrayList = this.mTransitionListeners;
    if (arrayList != null) {
      Iterator<TransitionListener> iterator = arrayList.iterator();
      while (iterator.hasNext())
        ((TransitionListener)iterator.next()).onTransitionTrigger(this, paramInt, paramBoolean, paramFloat); 
    } 
  }
  
  void getAnchorDpDt(int paramInt, float paramFloat1, float paramFloat2, float paramFloat3, float[] paramArrayOffloat) {
    String str;
    HashMap<View, MotionController> hashMap = this.mFrameArrayList;
    View view = getViewById(paramInt);
    MotionController motionController = hashMap.get(view);
    if (motionController != null) {
      motionController.getDpDt(paramFloat1, paramFloat2, paramFloat3, paramArrayOffloat);
      paramFloat2 = view.getY();
      this.lastPos = paramFloat1;
      this.lastY = paramFloat2;
      return;
    } 
    if (view == null) {
      StringBuilder stringBuilder1 = new StringBuilder();
      stringBuilder1.append("");
      stringBuilder1.append(paramInt);
      str = stringBuilder1.toString();
    } else {
      str = view.getContext().getResources().getResourceName(paramInt);
    } 
    StringBuilder stringBuilder = new StringBuilder();
    stringBuilder.append("WARNING could not find view id ");
    stringBuilder.append(str);
    Log.w("MotionLayout", stringBuilder.toString());
  }
  
  public ConstraintSet getConstraintSet(int paramInt) {
    MotionScene motionScene = this.mScene;
    return (motionScene == null) ? null : motionScene.getConstraintSet(paramInt);
  }
  
  public int[] getConstraintSetIds() {
    MotionScene motionScene = this.mScene;
    return (motionScene == null) ? null : motionScene.getConstraintSetIds();
  }
  
  String getConstraintSetNames(int paramInt) {
    MotionScene motionScene = this.mScene;
    return (motionScene == null) ? null : motionScene.lookUpConstraintName(paramInt);
  }
  
  public int getCurrentState() {
    return this.mCurrentState;
  }
  
  public void getDebugMode(boolean paramBoolean) {
    boolean bool;
    if (paramBoolean) {
      bool = true;
    } else {
      bool = true;
    } 
    this.mDebugPath = bool;
    invalidate();
  }
  
  public ArrayList<MotionScene.Transition> getDefinedTransitions() {
    MotionScene motionScene = this.mScene;
    return (motionScene == null) ? null : motionScene.getDefinedTransitions();
  }
  
  public DesignTool getDesignTool() {
    if (this.mDesignTool == null)
      this.mDesignTool = new DesignTool(this); 
    return this.mDesignTool;
  }
  
  public int getEndState() {
    return this.mEndState;
  }
  
  protected long getNanoTime() {
    return System.nanoTime();
  }
  
  public float getProgress() {
    return this.mTransitionLastPosition;
  }
  
  public int getStartState() {
    return this.mBeginState;
  }
  
  public float getTargetPosition() {
    return this.mTransitionGoalPosition;
  }
  
  public MotionScene.Transition getTransition(int paramInt) {
    return this.mScene.getTransitionById(paramInt);
  }
  
  public Bundle getTransitionState() {
    if (this.mStateCache == null)
      this.mStateCache = new StateCache(); 
    this.mStateCache.recordState();
    return this.mStateCache.getTransitionState();
  }
  
  public long getTransitionTimeMs() {
    MotionScene motionScene = this.mScene;
    if (motionScene != null)
      this.mTransitionDuration = motionScene.getDuration() / 1000.0F; 
    return (long)(this.mTransitionDuration * 1000.0F);
  }
  
  public float getVelocity() {
    return this.mLastVelocity;
  }
  
  public void getViewVelocity(View paramView, float paramFloat1, float paramFloat2, float[] paramArrayOffloat, int paramInt) {
    float f1 = this.mLastVelocity;
    float f2 = this.mTransitionLastPosition;
    if (this.mInterpolator != null) {
      f1 = Math.signum(this.mTransitionGoalPosition - f2);
      float f = this.mInterpolator.getInterpolation(this.mTransitionLastPosition + 1.0E-5F);
      f2 = this.mInterpolator.getInterpolation(this.mTransitionLastPosition);
      f1 = f1 * (f - f2) / 1.0E-5F / this.mTransitionDuration;
    } 
    Interpolator interpolator = this.mInterpolator;
    if (interpolator instanceof MotionInterpolator)
      f1 = ((MotionInterpolator)interpolator).getVelocity(); 
    MotionController motionController = this.mFrameArrayList.get(paramView);
    if ((paramInt & 0x1) == 0) {
      motionController.getPostLayoutDvDp(f2, paramView.getWidth(), paramView.getHeight(), paramFloat1, paramFloat2, paramArrayOffloat);
    } else {
      motionController.getDpDt(f2, paramFloat1, paramFloat2, paramArrayOffloat);
    } 
    if (paramInt < 2) {
      paramArrayOffloat[0] = paramArrayOffloat[0] * f1;
      paramArrayOffloat[1] = paramArrayOffloat[1] * f1;
    } 
  }
  
  public boolean isAttachedToWindow() {
    return super.isAttachedToWindow();
  }
  
  public boolean isInteractionEnabled() {
    return this.mInteractionEnabled;
  }
  
  public void loadLayoutDescription(int paramInt) {
    if (paramInt != 0) {
      try {
        this.mScene = new MotionScene(getContext(), this, paramInt);
        if (isAttachedToWindow()) {
          this.mScene.readFallback(this);
          this.mModel.initFrom(this.mLayoutWidget, this.mScene.getConstraintSet(this.mBeginState), this.mScene.getConstraintSet(this.mEndState));
          rebuildScene();
          this.mScene.setRtl(isRtl());
          return;
        } 
      } catch (Exception exception) {
        throw new IllegalArgumentException("unable to parse MotionScene file", exception);
      } 
    } else {
      this.mScene = null;
    } 
  }
  
  int lookUpConstraintId(String paramString) {
    MotionScene motionScene = this.mScene;
    return (motionScene == null) ? 0 : motionScene.lookUpConstraintId(paramString);
  }
  
  protected MotionTracker obtainVelocityTracker() {
    return MyTracker.obtain();
  }
  
  protected void onAttachedToWindow() {
    super.onAttachedToWindow();
    MotionScene motionScene2 = this.mScene;
    if (motionScene2 != null) {
      int i = this.mCurrentState;
      if (i != -1) {
        ConstraintSet constraintSet = motionScene2.getConstraintSet(i);
        this.mScene.readFallback(this);
        if (constraintSet != null)
          constraintSet.applyTo(this); 
        this.mBeginState = this.mCurrentState;
      } 
    } 
    onNewStateAttachHandlers();
    StateCache stateCache = this.mStateCache;
    if (stateCache != null) {
      stateCache.apply();
      return;
    } 
    MotionScene motionScene1 = this.mScene;
    if (motionScene1 != null) {
      MotionScene.Transition transition = motionScene1.mCurrentTransition;
      if (transition != null && transition.getAutoTransition() == 4) {
        transitionToEnd();
        setState(TransitionState.SETUP);
        setState(TransitionState.MOVING);
      } 
    } 
  }
  
  public boolean onInterceptTouchEvent(MotionEvent paramMotionEvent) {
    MotionScene motionScene = this.mScene;
    if (motionScene != null) {
      if (!this.mInteractionEnabled)
        return false; 
      MotionScene.Transition transition = motionScene.mCurrentTransition;
      if (transition != null && transition.isEnabled()) {
        TouchResponse touchResponse = transition.getTouchResponse();
        if (touchResponse != null) {
          if (paramMotionEvent.getAction() == 0) {
            RectF rectF = touchResponse.getTouchRegion((ViewGroup)this, new RectF());
            if (rectF != null && !rectF.contains(paramMotionEvent.getX(), paramMotionEvent.getY()))
              return false; 
          } 
          int i = touchResponse.getTouchRegionId();
          if (i != -1) {
            View view = this.mRegionView;
            if (view == null || view.getId() != i)
              this.mRegionView = findViewById(i); 
            view = this.mRegionView;
            if (view != null) {
              this.mBoundsCheck.set(view.getLeft(), this.mRegionView.getTop(), this.mRegionView.getRight(), this.mRegionView.getBottom());
              if (this.mBoundsCheck.contains(paramMotionEvent.getX(), paramMotionEvent.getY()) && !handlesTouchEvent(0.0F, 0.0F, this.mRegionView, paramMotionEvent))
                return onTouchEvent(paramMotionEvent); 
            } 
          } 
        } 
      } 
    } 
    return false;
  }
  
  protected void onLayout(boolean paramBoolean, int paramInt1, int paramInt2, int paramInt3, int paramInt4) {
    this.mInLayout = true;
    try {
      if (this.mScene == null) {
        super.onLayout(paramBoolean, paramInt1, paramInt2, paramInt3, paramInt4);
        return;
      } 
      paramInt1 = paramInt3 - paramInt1;
      paramInt2 = paramInt4 - paramInt2;
      if (this.mLastLayoutWidth != paramInt1 || this.mLastLayoutHeight != paramInt2) {
        rebuildScene();
        evaluate(true);
      } 
      this.mLastLayoutWidth = paramInt1;
      this.mLastLayoutHeight = paramInt2;
      this.mOldWidth = paramInt1;
      this.mOldHeight = paramInt2;
      return;
    } finally {
      this.mInLayout = false;
    } 
  }
  
  protected void onMeasure(int paramInt1, int paramInt2) {
    if (this.mScene == null) {
      super.onMeasure(paramInt1, paramInt2);
      return;
    } 
    int i = this.mLastWidthMeasureSpec;
    int j = 0;
    if (i != paramInt1 || this.mLastHeightMeasureSpec != paramInt2) {
      i = 1;
    } else {
      i = 0;
    } 
    if (this.mNeedsFireTransitionCompleted) {
      this.mNeedsFireTransitionCompleted = false;
      onNewStateAttachHandlers();
      processTransitionCompleted();
      i = 1;
    } 
    if (this.mDirtyHierarchy)
      i = 1; 
    this.mLastWidthMeasureSpec = paramInt1;
    this.mLastHeightMeasureSpec = paramInt2;
    int k = this.mScene.getStartId();
    int m = this.mScene.getEndId();
    if ((i != 0 || this.mModel.isNotConfiguredWith(k, m)) && this.mBeginState != -1) {
      super.onMeasure(paramInt1, paramInt2);
      this.mModel.initFrom(this.mLayoutWidget, this.mScene.getConstraintSet(k), this.mScene.getConstraintSet(m));
      this.mModel.reEvaluateState();
      this.mModel.setMeasuredId(k, m);
      paramInt1 = j;
    } else {
      paramInt1 = 1;
    } 
    if (this.mMeasureDuringTransition || paramInt1 != 0) {
      paramInt2 = getPaddingTop();
      i = getPaddingBottom();
      paramInt1 = getPaddingLeft();
      j = getPaddingRight();
      paramInt1 = this.mLayoutWidget.getWidth() + paramInt1 + j;
      paramInt2 = this.mLayoutWidget.getHeight() + paramInt2 + i;
      i = this.mWidthMeasureMode;
      if (i == Integer.MIN_VALUE || i == 0) {
        paramInt1 = this.mStartWrapWidth;
        paramInt1 = (int)(paramInt1 + this.mPostInterpolationPosition * (this.mEndWrapWidth - paramInt1));
        requestLayout();
      } 
      i = this.mHeightMeasureMode;
      if (i == Integer.MIN_VALUE || i == 0) {
        paramInt2 = this.mStartWrapHeight;
        paramInt2 = (int)(paramInt2 + this.mPostInterpolationPosition * (this.mEndWrapHeight - paramInt2));
        requestLayout();
      } 
      setMeasuredDimension(paramInt1, paramInt2);
    } 
    evaluateLayout();
  }
  
  public boolean onNestedFling(View paramView, float paramFloat1, float paramFloat2, boolean paramBoolean) {
    return false;
  }
  
  public boolean onNestedPreFling(View paramView, float paramFloat1, float paramFloat2) {
    return false;
  }
  
  public void onNestedPreScroll(final View target, int paramInt1, int paramInt2, int[] paramArrayOfint, int paramInt3) {
    MotionScene motionScene = this.mScene;
    if (motionScene != null) {
      MotionScene.Transition transition = motionScene.mCurrentTransition;
      if (transition == null)
        return; 
      if (!transition.isEnabled())
        return; 
      transition = this.mScene.mCurrentTransition;
      if (transition != null && transition.isEnabled()) {
        TouchResponse touchResponse = transition.getTouchResponse();
        if (touchResponse != null) {
          paramInt3 = touchResponse.getTouchRegionId();
          if (paramInt3 != -1 && target.getId() != paramInt3)
            return; 
        } 
      } 
      MotionScene motionScene1 = this.mScene;
      if (motionScene1 != null && motionScene1.getMoveWhenScrollAtTop()) {
        float f = this.mTransitionPosition;
        if ((f == 1.0F || f == 0.0F) && target.canScrollVertically(-1))
          return; 
      } 
      if (transition.getTouchResponse() != null && (this.mScene.mCurrentTransition.getTouchResponse().getFlags() & 0x1) != 0) {
        float f4 = this.mScene.getProgressDirection(paramInt1, paramInt2);
        float f5 = this.mTransitionLastPosition;
        if ((f5 <= 0.0F && f4 < 0.0F) || (f5 >= 1.0F && f4 > 0.0F)) {
          target.setNestedScrollingEnabled(false);
          target.post(new Runnable() {
                public void run() {
                  target.setNestedScrollingEnabled(true);
                }
              });
          return;
        } 
      } 
      float f1 = this.mTransitionPosition;
      long l = getNanoTime();
      float f2 = paramInt1;
      this.mScrollTargetDX = f2;
      float f3 = paramInt2;
      this.mScrollTargetDY = f3;
      this.mScrollTargetDT = (float)((l - this.mScrollTargetTime) * 1.0E-9D);
      this.mScrollTargetTime = l;
      this.mScene.processScrollMove(f2, f3);
      if (f1 != this.mTransitionPosition) {
        paramArrayOfint[0] = paramInt1;
        paramArrayOfint[1] = paramInt2;
      } 
      evaluate(false);
      if (paramArrayOfint[0] != 0 || paramArrayOfint[1] != 0)
        this.mUndergoingMotion = true; 
    } 
  }
  
  public void onNestedScroll(View paramView, int paramInt1, int paramInt2, int paramInt3, int paramInt4, int paramInt5) {}
  
  public void onNestedScroll(View paramView, int paramInt1, int paramInt2, int paramInt3, int paramInt4, int paramInt5, int[] paramArrayOfint) {
    if (this.mUndergoingMotion || paramInt1 != 0 || paramInt2 != 0) {
      paramArrayOfint[0] = paramArrayOfint[0] + paramInt3;
      paramArrayOfint[1] = paramArrayOfint[1] + paramInt4;
    } 
    this.mUndergoingMotion = false;
  }
  
  public void onNestedScrollAccepted(View paramView1, View paramView2, int paramInt1, int paramInt2) {}
  
  void onNewStateAttachHandlers() {
    MotionScene motionScene = this.mScene;
    if (motionScene == null)
      return; 
    if (motionScene.autoTransition(this, this.mCurrentState)) {
      requestLayout();
      return;
    } 
    int i = this.mCurrentState;
    if (i != -1)
      this.mScene.addOnClickListeners(this, i); 
    if (this.mScene.supportTouch())
      this.mScene.setupTouch(); 
  }
  
  public void onRtlPropertiesChanged(int paramInt) {
    MotionScene motionScene = this.mScene;
    if (motionScene != null)
      motionScene.setRtl(isRtl()); 
  }
  
  public boolean onStartNestedScroll(View paramView1, View paramView2, int paramInt1, int paramInt2) {
    MotionScene motionScene = this.mScene;
    if (motionScene != null) {
      MotionScene.Transition transition = motionScene.mCurrentTransition;
      if (transition != null && transition.getTouchResponse() != null && (this.mScene.mCurrentTransition.getTouchResponse().getFlags() & 0x2) == 0)
        return true; 
    } 
    return false;
  }
  
  public void onStopNestedScroll(View paramView, int paramInt) {
    MotionScene motionScene = this.mScene;
    if (motionScene == null)
      return; 
    float f1 = this.mScrollTargetDX;
    float f2 = this.mScrollTargetDT;
    motionScene.processScrollUp(f1 / f2, this.mScrollTargetDY / f2);
  }
  
  public boolean onTouchEvent(MotionEvent paramMotionEvent) {
    MotionScene motionScene = this.mScene;
    if (motionScene != null && this.mInteractionEnabled && motionScene.supportTouch()) {
      MotionScene.Transition transition = this.mScene.mCurrentTransition;
      if (transition != null && !transition.isEnabled())
        return super.onTouchEvent(paramMotionEvent); 
      this.mScene.processTouchEvent(paramMotionEvent, getCurrentState(), this);
      return true;
    } 
    return super.onTouchEvent(paramMotionEvent);
  }
  
  public void onViewAdded(View paramView) {
    super.onViewAdded(paramView);
    if (paramView instanceof MotionHelper) {
      MotionHelper motionHelper = (MotionHelper)paramView;
      if (this.mTransitionListeners == null)
        this.mTransitionListeners = new ArrayList<TransitionListener>(); 
      this.mTransitionListeners.add(motionHelper);
      if (motionHelper.isUsedOnShow()) {
        if (this.mOnShowHelpers == null)
          this.mOnShowHelpers = new ArrayList<MotionHelper>(); 
        this.mOnShowHelpers.add(motionHelper);
      } 
      if (motionHelper.isUseOnHide()) {
        if (this.mOnHideHelpers == null)
          this.mOnHideHelpers = new ArrayList<MotionHelper>(); 
        this.mOnHideHelpers.add(motionHelper);
      } 
    } 
  }
  
  public void onViewRemoved(View paramView) {
    super.onViewRemoved(paramView);
    ArrayList<MotionHelper> arrayList = this.mOnShowHelpers;
    if (arrayList != null)
      arrayList.remove(paramView); 
    arrayList = this.mOnHideHelpers;
    if (arrayList != null)
      arrayList.remove(paramView); 
  }
  
  protected void parseLayoutDescription(int paramInt) {
    this.mConstraintLayoutSpec = null;
  }
  
  @Deprecated
  public void rebuildMotion() {
    Log.e("MotionLayout", "This method is deprecated. Please call rebuildScene() instead.");
    rebuildScene();
  }
  
  public void rebuildScene() {
    this.mModel.reEvaluateState();
    invalidate();
  }
  
  public boolean removeTransitionListener(TransitionListener paramTransitionListener) {
    ArrayList<TransitionListener> arrayList = this.mTransitionListeners;
    return (arrayList == null) ? false : arrayList.remove(paramTransitionListener);
  }
  
  public void requestLayout() {
    if (!this.mMeasureDuringTransition && this.mCurrentState == -1) {
      MotionScene motionScene = this.mScene;
      if (motionScene != null) {
        MotionScene.Transition transition = motionScene.mCurrentTransition;
        if (transition != null && transition.getLayoutDuringTransition() == 0)
          return; 
      } 
    } 
    super.requestLayout();
  }
  
  public void setDebugMode(int paramInt) {
    this.mDebugPath = paramInt;
    invalidate();
  }
  
  public void setInteractionEnabled(boolean paramBoolean) {
    this.mInteractionEnabled = paramBoolean;
  }
  
  public void setInterpolatedProgress(float paramFloat) {
    if (this.mScene != null) {
      setState(TransitionState.MOVING);
      Interpolator interpolator = this.mScene.getInterpolator();
      if (interpolator != null) {
        setProgress(interpolator.getInterpolation(paramFloat));
        return;
      } 
    } 
    setProgress(paramFloat);
  }
  
  public void setOnHide(float paramFloat) {
    ArrayList<MotionHelper> arrayList = this.mOnHideHelpers;
    if (arrayList != null) {
      int j = arrayList.size();
      for (int i = 0; i < j; i++)
        ((MotionHelper)this.mOnHideHelpers.get(i)).setProgress(paramFloat); 
    } 
  }
  
  public void setOnShow(float paramFloat) {
    ArrayList<MotionHelper> arrayList = this.mOnShowHelpers;
    if (arrayList != null) {
      int j = arrayList.size();
      for (int i = 0; i < j; i++)
        ((MotionHelper)this.mOnShowHelpers.get(i)).setProgress(paramFloat); 
    } 
  }
  
  public void setProgress(float paramFloat) {
    int i = paramFloat cmp 0.0F;
    if (i < 0 || paramFloat > 1.0F)
      Log.w("MotionLayout", "Warning! Progress is defined for values between 0.0 and 1.0 inclusive"); 
    if (!isAttachedToWindow()) {
      if (this.mStateCache == null)
        this.mStateCache = new StateCache(); 
      this.mStateCache.setProgress(paramFloat);
      return;
    } 
    if (i <= 0) {
      this.mCurrentState = this.mBeginState;
      if (this.mTransitionLastPosition == 0.0F)
        setState(TransitionState.FINISHED); 
    } else if (paramFloat >= 1.0F) {
      this.mCurrentState = this.mEndState;
      if (this.mTransitionLastPosition == 1.0F)
        setState(TransitionState.FINISHED); 
    } else {
      this.mCurrentState = -1;
      setState(TransitionState.MOVING);
    } 
    if (this.mScene == null)
      return; 
    this.mTransitionInstantly = true;
    this.mTransitionGoalPosition = paramFloat;
    this.mTransitionPosition = paramFloat;
    this.mTransitionLastTime = -1L;
    this.mAnimationStartTime = -1L;
    this.mInterpolator = null;
    this.mInTransition = true;
    invalidate();
  }
  
  public void setProgress(float paramFloat1, float paramFloat2) {
    if (!isAttachedToWindow()) {
      if (this.mStateCache == null)
        this.mStateCache = new StateCache(); 
      this.mStateCache.setProgress(paramFloat1);
      this.mStateCache.setVelocity(paramFloat2);
      return;
    } 
    setProgress(paramFloat1);
    setState(TransitionState.MOVING);
    this.mLastVelocity = paramFloat2;
    animateTo(1.0F);
  }
  
  public void setScene(MotionScene paramMotionScene) {
    this.mScene = paramMotionScene;
    paramMotionScene.setRtl(isRtl());
    rebuildScene();
  }
  
  public void setState(int paramInt1, int paramInt2, int paramInt3) {
    setState(TransitionState.SETUP);
    this.mCurrentState = paramInt1;
    this.mBeginState = -1;
    this.mEndState = -1;
    ConstraintLayoutStates constraintLayoutStates = this.mConstraintLayoutSpec;
    if (constraintLayoutStates != null) {
      constraintLayoutStates.updateConstraints(paramInt1, paramInt2, paramInt3);
      return;
    } 
    MotionScene motionScene = this.mScene;
    if (motionScene != null)
      motionScene.getConstraintSet(paramInt1).applyTo(this); 
  }
  
  void setState(TransitionState paramTransitionState) {
    TransitionState transitionState1 = TransitionState.FINISHED;
    if (paramTransitionState == transitionState1 && this.mCurrentState == -1)
      return; 
    TransitionState transitionState2 = this.mTransitionState;
    this.mTransitionState = paramTransitionState;
    TransitionState transitionState3 = TransitionState.MOVING;
    if (transitionState2 == transitionState3 && paramTransitionState == transitionState3)
      fireTransitionChange(); 
    int i = null.$SwitchMap$androidx$constraintlayout$motion$widget$MotionLayout$TransitionState[transitionState2.ordinal()];
    if (i != 1 && i != 2) {
      if (i != 3)
        return; 
      if (paramTransitionState == transitionState1) {
        fireTransitionCompleted();
        return;
      } 
    } else {
      if (paramTransitionState == transitionState3)
        fireTransitionChange(); 
      if (paramTransitionState == transitionState1)
        fireTransitionCompleted(); 
    } 
  }
  
  public void setTransition(int paramInt) {
    if (this.mScene != null) {
      MotionScene.Transition transition = getTransition(paramInt);
      this.mBeginState = transition.getStartConstraintSetId();
      this.mEndState = transition.getEndConstraintSetId();
      if (!isAttachedToWindow()) {
        if (this.mStateCache == null)
          this.mStateCache = new StateCache(); 
        this.mStateCache.setStartState(this.mBeginState);
        this.mStateCache.setEndState(this.mEndState);
        return;
      } 
      float f1 = Float.NaN;
      paramInt = this.mCurrentState;
      int i = this.mBeginState;
      float f2 = 0.0F;
      if (paramInt == i) {
        f1 = 0.0F;
      } else if (paramInt == this.mEndState) {
        f1 = 1.0F;
      } 
      this.mScene.setTransition(transition);
      this.mModel.initFrom(this.mLayoutWidget, this.mScene.getConstraintSet(this.mBeginState), this.mScene.getConstraintSet(this.mEndState));
      rebuildScene();
      if (!Float.isNaN(f1))
        f2 = f1; 
      this.mTransitionLastPosition = f2;
      if (Float.isNaN(f1)) {
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append(Debug.getLocation());
        stringBuilder.append(" transitionToStart ");
        Log.v("MotionLayout", stringBuilder.toString());
        transitionToStart();
        return;
      } 
      setProgress(f1);
    } 
  }
  
  public void setTransition(int paramInt1, int paramInt2) {
    if (!isAttachedToWindow()) {
      if (this.mStateCache == null)
        this.mStateCache = new StateCache(); 
      this.mStateCache.setStartState(paramInt1);
      this.mStateCache.setEndState(paramInt2);
      return;
    } 
    MotionScene motionScene = this.mScene;
    if (motionScene != null) {
      this.mBeginState = paramInt1;
      this.mEndState = paramInt2;
      motionScene.setTransition(paramInt1, paramInt2);
      this.mModel.initFrom(this.mLayoutWidget, this.mScene.getConstraintSet(paramInt1), this.mScene.getConstraintSet(paramInt2));
      rebuildScene();
      this.mTransitionLastPosition = 0.0F;
      transitionToStart();
    } 
  }
  
  protected void setTransition(MotionScene.Transition paramTransition) {
    long l;
    this.mScene.setTransition(paramTransition);
    setState(TransitionState.SETUP);
    if (this.mCurrentState == this.mScene.getEndId()) {
      this.mTransitionLastPosition = 1.0F;
      this.mTransitionPosition = 1.0F;
      this.mTransitionGoalPosition = 1.0F;
    } else {
      this.mTransitionLastPosition = 0.0F;
      this.mTransitionPosition = 0.0F;
      this.mTransitionGoalPosition = 0.0F;
    } 
    if (paramTransition.isTransitionFlag(1)) {
      l = -1L;
    } else {
      l = getNanoTime();
    } 
    this.mTransitionLastTime = l;
    int i = this.mScene.getStartId();
    int j = this.mScene.getEndId();
    if (i == this.mBeginState && j == this.mEndState)
      return; 
    this.mBeginState = i;
    this.mEndState = j;
    this.mScene.setTransition(i, j);
    this.mModel.initFrom(this.mLayoutWidget, this.mScene.getConstraintSet(this.mBeginState), this.mScene.getConstraintSet(this.mEndState));
    this.mModel.setMeasuredId(this.mBeginState, this.mEndState);
    this.mModel.reEvaluateState();
    rebuildScene();
  }
  
  public void setTransitionDuration(int paramInt) {
    MotionScene motionScene = this.mScene;
    if (motionScene == null) {
      Log.e("MotionLayout", "MotionScene not defined");
      return;
    } 
    motionScene.setDuration(paramInt);
  }
  
  public void setTransitionListener(TransitionListener paramTransitionListener) {
    this.mTransitionListener = paramTransitionListener;
  }
  
  public void setTransitionState(Bundle paramBundle) {
    if (this.mStateCache == null)
      this.mStateCache = new StateCache(); 
    this.mStateCache.setTransitionState(paramBundle);
    if (isAttachedToWindow())
      this.mStateCache.apply(); 
  }
  
  public String toString() {
    Context context = getContext();
    StringBuilder stringBuilder = new StringBuilder();
    stringBuilder.append(Debug.getName(context, this.mBeginState));
    stringBuilder.append("->");
    stringBuilder.append(Debug.getName(context, this.mEndState));
    stringBuilder.append(" (pos:");
    stringBuilder.append(this.mTransitionLastPosition);
    stringBuilder.append(" Dpos/Dt:");
    stringBuilder.append(this.mLastVelocity);
    return stringBuilder.toString();
  }
  
  public void touchAnimateTo(int paramInt, float paramFloat1, float paramFloat2) {
    if (this.mScene == null)
      return; 
    if (this.mTransitionLastPosition == paramFloat1)
      return; 
    this.mTemporalInterpolator = true;
    this.mAnimationStartTime = getNanoTime();
    float f = this.mScene.getDuration() / 1000.0F;
    this.mTransitionDuration = f;
    this.mTransitionGoalPosition = paramFloat1;
    this.mInTransition = true;
    if (paramInt != 0 && paramInt != 1 && paramInt != 2) {
      if (paramInt != 4) {
        if (paramInt == 5)
          if (willJump(paramFloat2, this.mTransitionLastPosition, this.mScene.getMaxAcceleration())) {
            this.mDecelerateLogic.config(paramFloat2, this.mTransitionLastPosition, this.mScene.getMaxAcceleration());
            this.mInterpolator = this.mDecelerateLogic;
          } else {
            this.mStopLogic.config(this.mTransitionLastPosition, paramFloat1, paramFloat2, this.mTransitionDuration, this.mScene.getMaxAcceleration(), this.mScene.getMaxVelocity());
            this.mLastVelocity = 0.0F;
            paramInt = this.mCurrentState;
            this.mTransitionGoalPosition = paramFloat1;
            this.mCurrentState = paramInt;
            this.mInterpolator = (Interpolator)this.mStopLogic;
          }  
      } else {
        this.mDecelerateLogic.config(paramFloat2, this.mTransitionLastPosition, this.mScene.getMaxAcceleration());
        this.mInterpolator = this.mDecelerateLogic;
      } 
    } else {
      if (paramInt == 1) {
        paramFloat1 = 0.0F;
      } else if (paramInt == 2) {
        paramFloat1 = 1.0F;
      } 
      this.mStopLogic.config(this.mTransitionLastPosition, paramFloat1, paramFloat2, f, this.mScene.getMaxAcceleration(), this.mScene.getMaxVelocity());
      paramInt = this.mCurrentState;
      this.mTransitionGoalPosition = paramFloat1;
      this.mCurrentState = paramInt;
      this.mInterpolator = (Interpolator)this.mStopLogic;
    } 
    this.mTransitionInstantly = false;
    this.mAnimationStartTime = getNanoTime();
    invalidate();
  }
  
  public void transitionToEnd() {
    animateTo(1.0F);
  }
  
  public void transitionToStart() {
    animateTo(0.0F);
  }
  
  public void transitionToState(int paramInt) {
    if (!isAttachedToWindow()) {
      if (this.mStateCache == null)
        this.mStateCache = new StateCache(); 
      this.mStateCache.setEndState(paramInt);
      return;
    } 
    transitionToState(paramInt, -1, -1);
  }
  
  public void transitionToState(int paramInt1, int paramInt2, int paramInt3) {
    MotionScene motionScene = this.mScene;
    int i = paramInt1;
    if (motionScene != null) {
      StateSet stateSet = motionScene.mStateSet;
      i = paramInt1;
      if (stateSet != null) {
        paramInt2 = stateSet.convertToConstraintSet(this.mCurrentState, paramInt1, paramInt2, paramInt3);
        i = paramInt1;
        if (paramInt2 != -1)
          i = paramInt2; 
      } 
    } 
    paramInt1 = this.mCurrentState;
    if (paramInt1 == i)
      return; 
    if (this.mBeginState == i) {
      animateTo(0.0F);
      return;
    } 
    if (this.mEndState == i) {
      animateTo(1.0F);
      return;
    } 
    this.mEndState = i;
    if (paramInt1 != -1) {
      setTransition(paramInt1, i);
      animateTo(1.0F);
      this.mTransitionLastPosition = 0.0F;
      transitionToEnd();
      return;
    } 
    paramInt3 = 0;
    this.mTemporalInterpolator = false;
    this.mTransitionGoalPosition = 1.0F;
    this.mTransitionPosition = 0.0F;
    this.mTransitionLastPosition = 0.0F;
    this.mTransitionLastTime = getNanoTime();
    this.mAnimationStartTime = getNanoTime();
    this.mTransitionInstantly = false;
    this.mInterpolator = null;
    this.mTransitionDuration = this.mScene.getDuration() / 1000.0F;
    this.mBeginState = -1;
    this.mScene.setTransition(-1, this.mEndState);
    this.mScene.getStartId();
    int j = getChildCount();
    this.mFrameArrayList.clear();
    for (paramInt1 = 0; paramInt1 < j; paramInt1++) {
      View view = getChildAt(paramInt1);
      MotionController motionController = new MotionController(view);
      this.mFrameArrayList.put(view, motionController);
    } 
    this.mInTransition = true;
    this.mModel.initFrom(this.mLayoutWidget, null, this.mScene.getConstraintSet(i));
    rebuildScene();
    this.mModel.build();
    computeCurrentPositions();
    paramInt2 = getWidth();
    i = getHeight();
    for (paramInt1 = 0; paramInt1 < j; paramInt1++) {
      MotionController motionController = this.mFrameArrayList.get(getChildAt(paramInt1));
      this.mScene.getKeyFrames(motionController);
      motionController.setup(paramInt2, i, this.mTransitionDuration, getNanoTime());
    } 
    float f = this.mScene.getStaggered();
    if (f != 0.0F) {
      float f2 = Float.MAX_VALUE;
      float f1 = -3.4028235E38F;
      paramInt1 = 0;
      while (true) {
        paramInt2 = paramInt3;
        if (paramInt1 < j) {
          MotionController motionController = this.mFrameArrayList.get(getChildAt(paramInt1));
          float f3 = motionController.getFinalX();
          f3 = motionController.getFinalY() + f3;
          f2 = Math.min(f2, f3);
          f1 = Math.max(f1, f3);
          paramInt1++;
          continue;
        } 
        break;
      } 
      while (paramInt2 < j) {
        MotionController motionController = this.mFrameArrayList.get(getChildAt(paramInt2));
        float f3 = motionController.getFinalX();
        float f4 = motionController.getFinalY();
        motionController.mStaggerScale = 1.0F / (1.0F - f);
        motionController.mStaggerOffset = f - (f3 + f4 - f2) * f / (f1 - f2);
        paramInt2++;
      } 
    } 
    this.mTransitionPosition = 0.0F;
    this.mTransitionLastPosition = 0.0F;
    this.mInTransition = true;
    invalidate();
  }
  
  public void updateState() {
    this.mModel.initFrom(this.mLayoutWidget, this.mScene.getConstraintSet(this.mBeginState), this.mScene.getConstraintSet(this.mEndState));
    rebuildScene();
  }
  
  public void updateState(int paramInt, ConstraintSet paramConstraintSet) {
    MotionScene motionScene = this.mScene;
    if (motionScene != null)
      motionScene.setConstraintSet(paramInt, paramConstraintSet); 
    updateState();
    if (this.mCurrentState == paramInt)
      paramConstraintSet.applyTo(this); 
  }
  
  class DecelerateInterpolator extends MotionInterpolator {
    float currentP = 0.0F;
    
    float initalV = 0.0F;
    
    float maxA;
    
    public void config(float param1Float1, float param1Float2, float param1Float3) {
      this.initalV = param1Float1;
      this.currentP = param1Float2;
      this.maxA = param1Float3;
    }
    
    public float getInterpolation(float param1Float) {
      float f2 = this.initalV;
      if (f2 > 0.0F) {
        float f6 = this.maxA;
        float f5 = param1Float;
        if (f2 / f6 < param1Float)
          f5 = f2 / f6; 
        MotionLayout.this.mLastVelocity = f2 - f6 * f5;
        param1Float = f2 * f5 - f6 * f5 * f5 / 2.0F;
        f5 = this.currentP;
        return param1Float + f5;
      } 
      float f4 = -f2;
      float f3 = this.maxA;
      float f1 = param1Float;
      if (f4 / f3 < param1Float)
        f1 = -f2 / f3; 
      MotionLayout.this.mLastVelocity = f3 * f1 + f2;
      param1Float = f2 * f1 + f3 * f1 * f1 / 2.0F;
      f1 = this.currentP;
      return param1Float + f1;
    }
    
    public float getVelocity() {
      return MotionLayout.this.mLastVelocity;
    }
  }
  
  private class DevModeDraw {
    private static final int DEBUG_PATH_TICKS_PER_MS = 16;
    
    final int DIAMOND_SIZE = 10;
    
    final int GRAPH_COLOR = -13391360;
    
    final int KEYFRAME_COLOR = -2067046;
    
    final int RED_COLOR = -21965;
    
    final int SHADOW_COLOR = 1996488704;
    
    Rect mBounds = new Rect();
    
    DashPathEffect mDashPathEffect;
    
    Paint mFillPaint;
    
    int mKeyFrameCount;
    
    float[] mKeyFramePoints;
    
    Paint mPaint;
    
    Paint mPaintGraph;
    
    Paint mPaintKeyframes;
    
    Path mPath;
    
    int[] mPathMode;
    
    float[] mPoints;
    
    boolean mPresentationMode = false;
    
    private float[] mRectangle;
    
    int mShadowTranslate = 1;
    
    Paint mTextPaint;
    
    public DevModeDraw() {
      Paint paint2 = new Paint();
      this.mPaint = paint2;
      paint2.setAntiAlias(true);
      this.mPaint.setColor(-21965);
      this.mPaint.setStrokeWidth(2.0F);
      this.mPaint.setStyle(Paint.Style.STROKE);
      paint2 = new Paint();
      this.mPaintKeyframes = paint2;
      paint2.setAntiAlias(true);
      this.mPaintKeyframes.setColor(-2067046);
      this.mPaintKeyframes.setStrokeWidth(2.0F);
      this.mPaintKeyframes.setStyle(Paint.Style.STROKE);
      paint2 = new Paint();
      this.mPaintGraph = paint2;
      paint2.setAntiAlias(true);
      this.mPaintGraph.setColor(-13391360);
      this.mPaintGraph.setStrokeWidth(2.0F);
      this.mPaintGraph.setStyle(Paint.Style.STROKE);
      paint2 = new Paint();
      this.mTextPaint = paint2;
      paint2.setAntiAlias(true);
      this.mTextPaint.setColor(-13391360);
      this.mTextPaint.setTextSize((MotionLayout.this.getContext().getResources().getDisplayMetrics()).density * 12.0F);
      this.mRectangle = new float[8];
      Paint paint1 = new Paint();
      this.mFillPaint = paint1;
      paint1.setAntiAlias(true);
      DashPathEffect dashPathEffect = new DashPathEffect(new float[] { 4.0F, 8.0F }, 0.0F);
      this.mDashPathEffect = dashPathEffect;
      this.mPaintGraph.setPathEffect((PathEffect)dashPathEffect);
      this.mKeyFramePoints = new float[100];
      this.mPathMode = new int[50];
      if (this.mPresentationMode) {
        this.mPaint.setStrokeWidth(8.0F);
        this.mFillPaint.setStrokeWidth(8.0F);
        this.mPaintKeyframes.setStrokeWidth(8.0F);
        this.mShadowTranslate = 4;
      } 
    }
    
    private void drawBasicPath(Canvas param1Canvas) {
      param1Canvas.drawLines(this.mPoints, this.mPaint);
    }
    
    private void drawPathAsConfigured(Canvas param1Canvas) {
      int i = 0;
      boolean bool2 = false;
      boolean bool1 = false;
      while (i < this.mKeyFrameCount) {
        int[] arrayOfInt = this.mPathMode;
        if (arrayOfInt[i] == 1)
          bool2 = true; 
        if (arrayOfInt[i] == 2)
          bool1 = true; 
        i++;
      } 
      if (bool2)
        drawPathRelative(param1Canvas); 
      if (bool1)
        drawPathCartesian(param1Canvas); 
    }
    
    private void drawPathCartesian(Canvas param1Canvas) {
      float[] arrayOfFloat = this.mPoints;
      float f1 = arrayOfFloat[0];
      float f2 = arrayOfFloat[1];
      float f3 = arrayOfFloat[arrayOfFloat.length - 2];
      float f4 = arrayOfFloat[arrayOfFloat.length - 1];
      param1Canvas.drawLine(Math.min(f1, f3), Math.max(f2, f4), Math.max(f1, f3), Math.max(f2, f4), this.mPaintGraph);
      param1Canvas.drawLine(Math.min(f1, f3), Math.min(f2, f4), Math.min(f1, f3), Math.max(f2, f4), this.mPaintGraph);
    }
    
    private void drawPathCartesianTicks(Canvas param1Canvas, float param1Float1, float param1Float2) {
      float[] arrayOfFloat = this.mPoints;
      float f1 = arrayOfFloat[0];
      float f2 = arrayOfFloat[1];
      float f3 = arrayOfFloat[arrayOfFloat.length - 2];
      float f4 = arrayOfFloat[arrayOfFloat.length - 1];
      float f5 = Math.min(f1, f3);
      float f6 = Math.max(f2, f4);
      float f7 = param1Float1 - Math.min(f1, f3);
      float f8 = Math.max(f2, f4) - param1Float2;
      StringBuilder stringBuilder2 = new StringBuilder();
      stringBuilder2.append("");
      stringBuilder2.append((int)((f7 * 100.0F / Math.abs(f3 - f1)) + 0.5D) / 100.0F);
      String str2 = stringBuilder2.toString();
      getTextBounds(str2, this.mTextPaint);
      param1Canvas.drawText(str2, f7 / 2.0F - (this.mBounds.width() / 2) + f5, param1Float2 - 20.0F, this.mTextPaint);
      param1Canvas.drawLine(param1Float1, param1Float2, Math.min(f1, f3), param1Float2, this.mPaintGraph);
      StringBuilder stringBuilder1 = new StringBuilder();
      stringBuilder1.append("");
      stringBuilder1.append((int)((f8 * 100.0F / Math.abs(f4 - f2)) + 0.5D) / 100.0F);
      String str1 = stringBuilder1.toString();
      getTextBounds(str1, this.mTextPaint);
      param1Canvas.drawText(str1, param1Float1 + 5.0F, f6 - f8 / 2.0F - (this.mBounds.height() / 2), this.mTextPaint);
      param1Canvas.drawLine(param1Float1, param1Float2, param1Float1, Math.max(f2, f4), this.mPaintGraph);
    }
    
    private void drawPathRelative(Canvas param1Canvas) {
      float[] arrayOfFloat = this.mPoints;
      param1Canvas.drawLine(arrayOfFloat[0], arrayOfFloat[1], arrayOfFloat[arrayOfFloat.length - 2], arrayOfFloat[arrayOfFloat.length - 1], this.mPaintGraph);
    }
    
    private void drawPathRelativeTicks(Canvas param1Canvas, float param1Float1, float param1Float2) {
      float[] arrayOfFloat = this.mPoints;
      float f3 = arrayOfFloat[0];
      float f2 = arrayOfFloat[1];
      float f4 = arrayOfFloat[arrayOfFloat.length - 2];
      float f5 = arrayOfFloat[arrayOfFloat.length - 1];
      float f1 = (float)Math.hypot((f3 - f4), (f2 - f5));
      f4 -= f3;
      f5 -= f2;
      float f6 = ((param1Float1 - f3) * f4 + (param1Float2 - f2) * f5) / f1 * f1;
      f3 += f4 * f6;
      f2 += f6 * f5;
      Path path = new Path();
      path.moveTo(param1Float1, param1Float2);
      path.lineTo(f3, f2);
      f4 = (float)Math.hypot((f3 - param1Float1), (f2 - param1Float2));
      StringBuilder stringBuilder = new StringBuilder();
      stringBuilder.append("");
      stringBuilder.append((int)(f4 * 100.0F / f1) / 100.0F);
      String str = stringBuilder.toString();
      getTextBounds(str, this.mTextPaint);
      param1Canvas.drawTextOnPath(str, path, f4 / 2.0F - (this.mBounds.width() / 2), -20.0F, this.mTextPaint);
      param1Canvas.drawLine(param1Float1, param1Float2, f3, f2, this.mPaintGraph);
    }
    
    private void drawPathScreenTicks(Canvas param1Canvas, float param1Float1, float param1Float2, int param1Int1, int param1Int2) {
      StringBuilder stringBuilder2 = new StringBuilder();
      stringBuilder2.append("");
      stringBuilder2.append((int)(((param1Float1 - (param1Int1 / 2)) * 100.0F / (MotionLayout.this.getWidth() - param1Int1)) + 0.5D) / 100.0F);
      String str2 = stringBuilder2.toString();
      getTextBounds(str2, this.mTextPaint);
      param1Canvas.drawText(str2, param1Float1 / 2.0F - (this.mBounds.width() / 2) + 0.0F, param1Float2 - 20.0F, this.mTextPaint);
      param1Canvas.drawLine(param1Float1, param1Float2, Math.min(0.0F, 1.0F), param1Float2, this.mPaintGraph);
      StringBuilder stringBuilder1 = new StringBuilder();
      stringBuilder1.append("");
      stringBuilder1.append((int)(((param1Float2 - (param1Int2 / 2)) * 100.0F / (MotionLayout.this.getHeight() - param1Int2)) + 0.5D) / 100.0F);
      String str1 = stringBuilder1.toString();
      getTextBounds(str1, this.mTextPaint);
      param1Canvas.drawText(str1, param1Float1 + 5.0F, 0.0F - param1Float2 / 2.0F - (this.mBounds.height() / 2), this.mTextPaint);
      param1Canvas.drawLine(param1Float1, param1Float2, param1Float1, Math.max(0.0F, 1.0F), this.mPaintGraph);
    }
    
    private void drawRectangle(Canvas param1Canvas, MotionController param1MotionController) {
      this.mPath.reset();
      for (int i = 0; i <= 50; i++) {
        param1MotionController.buildRect(i / 50, this.mRectangle, 0);
        Path path = this.mPath;
        float[] arrayOfFloat = this.mRectangle;
        path.moveTo(arrayOfFloat[0], arrayOfFloat[1]);
        path = this.mPath;
        arrayOfFloat = this.mRectangle;
        path.lineTo(arrayOfFloat[2], arrayOfFloat[3]);
        path = this.mPath;
        arrayOfFloat = this.mRectangle;
        path.lineTo(arrayOfFloat[4], arrayOfFloat[5]);
        path = this.mPath;
        arrayOfFloat = this.mRectangle;
        path.lineTo(arrayOfFloat[6], arrayOfFloat[7]);
        this.mPath.close();
      } 
      this.mPaint.setColor(1140850688);
      param1Canvas.translate(2.0F, 2.0F);
      param1Canvas.drawPath(this.mPath, this.mPaint);
      param1Canvas.translate(-2.0F, -2.0F);
      this.mPaint.setColor(-65536);
      param1Canvas.drawPath(this.mPath, this.mPaint);
    }
    
    private void drawTicks(Canvas param1Canvas, int param1Int1, int param1Int2, MotionController param1MotionController) {
      boolean bool1;
      boolean bool2;
      View view = param1MotionController.mView;
      if (view != null) {
        bool1 = view.getWidth();
        bool2 = param1MotionController.mView.getHeight();
      } else {
        bool1 = false;
        bool2 = false;
      } 
      int i;
      for (i = 1; i < param1Int2 - 1; i++) {
        if (param1Int1 != 4 || this.mPathMode[i - 1] != 0) {
          float[] arrayOfFloat1 = this.mKeyFramePoints;
          int j = i * 2;
          float f2 = arrayOfFloat1[j];
          float f1 = arrayOfFloat1[j + 1];
          this.mPath.reset();
          this.mPath.moveTo(f2, f1 + 10.0F);
          this.mPath.lineTo(f2 + 10.0F, f1);
          this.mPath.lineTo(f2, f1 - 10.0F);
          this.mPath.lineTo(f2 - 10.0F, f1);
          this.mPath.close();
          j = i - 1;
          param1MotionController.getKeyFrame(j);
          if (param1Int1 == 4) {
            int[] arrayOfInt = this.mPathMode;
            if (arrayOfInt[j] == 1) {
              drawPathRelativeTicks(param1Canvas, f2 - 0.0F, f1 - 0.0F);
            } else if (arrayOfInt[j] == 2) {
              drawPathCartesianTicks(param1Canvas, f2 - 0.0F, f1 - 0.0F);
            } else if (arrayOfInt[j] == 3) {
              drawPathScreenTicks(param1Canvas, f2 - 0.0F, f1 - 0.0F, bool1, bool2);
            } 
            param1Canvas.drawPath(this.mPath, this.mFillPaint);
          } 
          if (param1Int1 == 2)
            drawPathRelativeTicks(param1Canvas, f2 - 0.0F, f1 - 0.0F); 
          if (param1Int1 == 3)
            drawPathCartesianTicks(param1Canvas, f2 - 0.0F, f1 - 0.0F); 
          if (param1Int1 == 6)
            drawPathScreenTicks(param1Canvas, f2 - 0.0F, f1 - 0.0F, bool1, bool2); 
          param1Canvas.drawPath(this.mPath, this.mFillPaint);
        } 
      } 
      float[] arrayOfFloat = this.mPoints;
      if (arrayOfFloat.length > 1) {
        param1Canvas.drawCircle(arrayOfFloat[0], arrayOfFloat[1], 8.0F, this.mPaintKeyframes);
        arrayOfFloat = this.mPoints;
        param1Canvas.drawCircle(arrayOfFloat[arrayOfFloat.length - 2], arrayOfFloat[arrayOfFloat.length - 1], 8.0F, this.mPaintKeyframes);
      } 
    }
    
    private void drawTranslation(Canvas param1Canvas, float param1Float1, float param1Float2, float param1Float3, float param1Float4) {
      param1Canvas.drawRect(param1Float1, param1Float2, param1Float3, param1Float4, this.mPaintGraph);
      param1Canvas.drawLine(param1Float1, param1Float2, param1Float3, param1Float4, this.mPaintGraph);
    }
    
    public void draw(Canvas param1Canvas, HashMap<View, MotionController> param1HashMap, int param1Int1, int param1Int2) {
      if (param1HashMap != null) {
        if (param1HashMap.size() == 0)
          return; 
        param1Canvas.save();
        if (!MotionLayout.this.isInEditMode() && (param1Int2 & 0x1) == 2) {
          StringBuilder stringBuilder = new StringBuilder();
          stringBuilder.append(MotionLayout.this.getContext().getResources().getResourceName(MotionLayout.this.mEndState));
          stringBuilder.append(":");
          stringBuilder.append(MotionLayout.this.getProgress());
          String str = stringBuilder.toString();
          param1Canvas.drawText(str, 10.0F, (MotionLayout.this.getHeight() - 30), this.mTextPaint);
          param1Canvas.drawText(str, 11.0F, (MotionLayout.this.getHeight() - 29), this.mPaint);
        } 
        for (MotionController motionController : param1HashMap.values()) {
          int j = motionController.getDrawPath();
          int i = j;
          if (param1Int2 > 0) {
            i = j;
            if (j == 0)
              i = 1; 
          } 
          if (i == 0)
            continue; 
          this.mKeyFrameCount = motionController.buildKeyFrames(this.mKeyFramePoints, this.mPathMode);
          if (i >= 1) {
            j = param1Int1 / 16;
            float[] arrayOfFloat = this.mPoints;
            if (arrayOfFloat == null || arrayOfFloat.length != j * 2) {
              this.mPoints = new float[j * 2];
              this.mPath = new Path();
            } 
            int k = this.mShadowTranslate;
            param1Canvas.translate(k, k);
            this.mPaint.setColor(1996488704);
            this.mFillPaint.setColor(1996488704);
            this.mPaintKeyframes.setColor(1996488704);
            this.mPaintGraph.setColor(1996488704);
            motionController.buildPath(this.mPoints, j);
            drawAll(param1Canvas, i, this.mKeyFrameCount, motionController);
            this.mPaint.setColor(-21965);
            this.mPaintKeyframes.setColor(-2067046);
            this.mFillPaint.setColor(-2067046);
            this.mPaintGraph.setColor(-13391360);
            j = this.mShadowTranslate;
            param1Canvas.translate(-j, -j);
            drawAll(param1Canvas, i, this.mKeyFrameCount, motionController);
            if (i == 5)
              drawRectangle(param1Canvas, motionController); 
          } 
        } 
        param1Canvas.restore();
      } 
    }
    
    public void drawAll(Canvas param1Canvas, int param1Int1, int param1Int2, MotionController param1MotionController) {
      if (param1Int1 == 4)
        drawPathAsConfigured(param1Canvas); 
      if (param1Int1 == 2)
        drawPathRelative(param1Canvas); 
      if (param1Int1 == 3)
        drawPathCartesian(param1Canvas); 
      drawBasicPath(param1Canvas);
      drawTicks(param1Canvas, param1Int1, param1Int2, param1MotionController);
    }
    
    void getTextBounds(String param1String, Paint param1Paint) {
      param1Paint.getTextBounds(param1String, 0, param1String.length(), this.mBounds);
    }
  }
  
  class Model {
    ConstraintSet mEnd = null;
    
    int mEndId;
    
    ConstraintWidgetContainer mLayoutEnd = new ConstraintWidgetContainer();
    
    ConstraintWidgetContainer mLayoutStart = new ConstraintWidgetContainer();
    
    ConstraintSet mStart = null;
    
    int mStartId;
    
    private void debugLayout(String param1String, ConstraintWidgetContainer param1ConstraintWidgetContainer) {
      View view = (View)param1ConstraintWidgetContainer.getCompanionWidget();
      StringBuilder stringBuilder2 = new StringBuilder();
      stringBuilder2.append(param1String);
      stringBuilder2.append(" ");
      stringBuilder2.append(Debug.getName(view));
      String str = stringBuilder2.toString();
      StringBuilder stringBuilder1 = new StringBuilder();
      stringBuilder1.append(str);
      stringBuilder1.append("  ========= ");
      stringBuilder1.append(param1ConstraintWidgetContainer);
      Log.v("MotionLayout", stringBuilder1.toString());
      int j = param1ConstraintWidgetContainer.getChildren().size();
      for (int i = 0; i < j; i++) {
        stringBuilder1 = new StringBuilder();
        stringBuilder1.append(str);
        stringBuilder1.append("[");
        stringBuilder1.append(i);
        stringBuilder1.append("] ");
        String str3 = stringBuilder1.toString();
        ConstraintWidget constraintWidget = param1ConstraintWidgetContainer.getChildren().get(i);
        StringBuilder stringBuilder4 = new StringBuilder();
        stringBuilder4.append("");
        ConstraintAnchor constraintAnchor = constraintWidget.mTop.mTarget;
        String str2 = "_";
        if (constraintAnchor != null) {
          str1 = "T";
        } else {
          str1 = "_";
        } 
        stringBuilder4.append(str1);
        String str1 = stringBuilder4.toString();
        stringBuilder4 = new StringBuilder();
        stringBuilder4.append(str1);
        if (constraintWidget.mBottom.mTarget != null) {
          str1 = "B";
        } else {
          str1 = "_";
        } 
        stringBuilder4.append(str1);
        str1 = stringBuilder4.toString();
        stringBuilder4 = new StringBuilder();
        stringBuilder4.append(str1);
        if (constraintWidget.mLeft.mTarget != null) {
          str1 = "L";
        } else {
          str1 = "_";
        } 
        stringBuilder4.append(str1);
        str1 = stringBuilder4.toString();
        stringBuilder4 = new StringBuilder();
        stringBuilder4.append(str1);
        str1 = str2;
        if (constraintWidget.mRight.mTarget != null)
          str1 = "R"; 
        stringBuilder4.append(str1);
        String str4 = stringBuilder4.toString();
        View view1 = (View)constraintWidget.getCompanionWidget();
        str2 = Debug.getName(view1);
        str1 = str2;
        if (view1 instanceof TextView) {
          StringBuilder stringBuilder = new StringBuilder();
          stringBuilder.append(str2);
          stringBuilder.append("(");
          stringBuilder.append(((TextView)view1).getText());
          stringBuilder.append(")");
          str1 = stringBuilder.toString();
        } 
        StringBuilder stringBuilder3 = new StringBuilder();
        stringBuilder3.append(str3);
        stringBuilder3.append("  ");
        stringBuilder3.append(str1);
        stringBuilder3.append(" ");
        stringBuilder3.append(constraintWidget);
        stringBuilder3.append(" ");
        stringBuilder3.append(str4);
        Log.v("MotionLayout", stringBuilder3.toString());
      } 
      stringBuilder1 = new StringBuilder();
      stringBuilder1.append(str);
      stringBuilder1.append(" done. ");
      Log.v("MotionLayout", stringBuilder1.toString());
    }
    
    private void debugLayoutParam(String param1String, ConstraintLayout.LayoutParams param1LayoutParams) {
      StringBuilder stringBuilder2 = new StringBuilder();
      stringBuilder2.append(" ");
      if (param1LayoutParams.startToStart != -1) {
        str2 = "SS";
      } else {
        str2 = "__";
      } 
      stringBuilder2.append(str2);
      String str2 = stringBuilder2.toString();
      StringBuilder stringBuilder3 = new StringBuilder();
      stringBuilder3.append(str2);
      int i = param1LayoutParams.startToEnd;
      String str3 = "|__";
      if (i != -1) {
        str2 = "|SE";
      } else {
        str2 = "|__";
      } 
      stringBuilder3.append(str2);
      str2 = stringBuilder3.toString();
      stringBuilder3 = new StringBuilder();
      stringBuilder3.append(str2);
      if (param1LayoutParams.endToStart != -1) {
        str2 = "|ES";
      } else {
        str2 = "|__";
      } 
      stringBuilder3.append(str2);
      str2 = stringBuilder3.toString();
      stringBuilder3 = new StringBuilder();
      stringBuilder3.append(str2);
      if (param1LayoutParams.endToEnd != -1) {
        str2 = "|EE";
      } else {
        str2 = "|__";
      } 
      stringBuilder3.append(str2);
      str2 = stringBuilder3.toString();
      stringBuilder3 = new StringBuilder();
      stringBuilder3.append(str2);
      if (param1LayoutParams.leftToLeft != -1) {
        str2 = "|LL";
      } else {
        str2 = "|__";
      } 
      stringBuilder3.append(str2);
      str2 = stringBuilder3.toString();
      stringBuilder3 = new StringBuilder();
      stringBuilder3.append(str2);
      if (param1LayoutParams.leftToRight != -1) {
        str2 = "|LR";
      } else {
        str2 = "|__";
      } 
      stringBuilder3.append(str2);
      str2 = stringBuilder3.toString();
      stringBuilder3 = new StringBuilder();
      stringBuilder3.append(str2);
      if (param1LayoutParams.rightToLeft != -1) {
        str2 = "|RL";
      } else {
        str2 = "|__";
      } 
      stringBuilder3.append(str2);
      str2 = stringBuilder3.toString();
      stringBuilder3 = new StringBuilder();
      stringBuilder3.append(str2);
      if (param1LayoutParams.rightToRight != -1) {
        str2 = "|RR";
      } else {
        str2 = "|__";
      } 
      stringBuilder3.append(str2);
      str2 = stringBuilder3.toString();
      stringBuilder3 = new StringBuilder();
      stringBuilder3.append(str2);
      if (param1LayoutParams.topToTop != -1) {
        str2 = "|TT";
      } else {
        str2 = "|__";
      } 
      stringBuilder3.append(str2);
      str2 = stringBuilder3.toString();
      stringBuilder3 = new StringBuilder();
      stringBuilder3.append(str2);
      if (param1LayoutParams.topToBottom != -1) {
        str2 = "|TB";
      } else {
        str2 = "|__";
      } 
      stringBuilder3.append(str2);
      str2 = stringBuilder3.toString();
      stringBuilder3 = new StringBuilder();
      stringBuilder3.append(str2);
      if (param1LayoutParams.bottomToTop != -1) {
        str2 = "|BT";
      } else {
        str2 = "|__";
      } 
      stringBuilder3.append(str2);
      str2 = stringBuilder3.toString();
      stringBuilder3 = new StringBuilder();
      stringBuilder3.append(str2);
      str2 = str3;
      if (param1LayoutParams.bottomToBottom != -1)
        str2 = "|BB"; 
      stringBuilder3.append(str2);
      String str1 = stringBuilder3.toString();
      StringBuilder stringBuilder1 = new StringBuilder();
      stringBuilder1.append(param1String);
      stringBuilder1.append(str1);
      Log.v("MotionLayout", stringBuilder1.toString());
    }
    
    private void debugWidget(String param1String, ConstraintWidget param1ConstraintWidget) {
      StringBuilder stringBuilder2 = new StringBuilder();
      stringBuilder2.append(" ");
      ConstraintAnchor constraintAnchor2 = param1ConstraintWidget.mTop.mTarget;
      String str4 = "B";
      String str3 = "__";
      if (constraintAnchor2 != null) {
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("T");
        if (param1ConstraintWidget.mTop.mTarget.mType == ConstraintAnchor.Type.TOP) {
          str2 = "T";
        } else {
          str2 = "B";
        } 
        stringBuilder.append(str2);
        str2 = stringBuilder.toString();
      } else {
        str2 = "__";
      } 
      stringBuilder2.append(str2);
      String str2 = stringBuilder2.toString();
      stringBuilder2 = new StringBuilder();
      stringBuilder2.append(str2);
      if (param1ConstraintWidget.mBottom.mTarget != null) {
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("B");
        str2 = str4;
        if (param1ConstraintWidget.mBottom.mTarget.mType == ConstraintAnchor.Type.TOP)
          str2 = "T"; 
        stringBuilder.append(str2);
        str2 = stringBuilder.toString();
      } else {
        str2 = "__";
      } 
      stringBuilder2.append(str2);
      str2 = stringBuilder2.toString();
      stringBuilder2 = new StringBuilder();
      stringBuilder2.append(str2);
      ConstraintAnchor constraintAnchor1 = param1ConstraintWidget.mLeft.mTarget;
      str4 = "R";
      if (constraintAnchor1 != null) {
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("L");
        if (param1ConstraintWidget.mLeft.mTarget.mType == ConstraintAnchor.Type.LEFT) {
          str1 = "L";
        } else {
          str1 = "R";
        } 
        stringBuilder.append(str1);
        str1 = stringBuilder.toString();
      } else {
        str1 = "__";
      } 
      stringBuilder2.append(str1);
      String str1 = stringBuilder2.toString();
      stringBuilder2 = new StringBuilder();
      stringBuilder2.append(str1);
      str1 = str3;
      if (param1ConstraintWidget.mRight.mTarget != null) {
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("R");
        str1 = str4;
        if (param1ConstraintWidget.mRight.mTarget.mType == ConstraintAnchor.Type.LEFT)
          str1 = "L"; 
        stringBuilder.append(str1);
        str1 = stringBuilder.toString();
      } 
      stringBuilder2.append(str1);
      str1 = stringBuilder2.toString();
      StringBuilder stringBuilder1 = new StringBuilder();
      stringBuilder1.append(param1String);
      stringBuilder1.append(str1);
      stringBuilder1.append(" ---  ");
      stringBuilder1.append(param1ConstraintWidget);
      Log.v("MotionLayout", stringBuilder1.toString());
    }
    
    private void setupConstraintWidget(ConstraintWidgetContainer param1ConstraintWidgetContainer, ConstraintSet param1ConstraintSet) {
      SparseArray sparseArray = new SparseArray();
      Constraints.LayoutParams layoutParams = new Constraints.LayoutParams(-2, -2);
      sparseArray.clear();
      sparseArray.put(0, param1ConstraintWidgetContainer);
      sparseArray.put(MotionLayout.this.getId(), param1ConstraintWidgetContainer);
      for (ConstraintWidget constraintWidget : param1ConstraintWidgetContainer.getChildren())
        sparseArray.put(((View)constraintWidget.getCompanionWidget()).getId(), constraintWidget); 
      for (ConstraintWidget constraintWidget : param1ConstraintWidgetContainer.getChildren()) {
        View view = (View)constraintWidget.getCompanionWidget();
        param1ConstraintSet.applyToLayoutParams(view.getId(), (ConstraintLayout.LayoutParams)layoutParams);
        constraintWidget.setWidth(param1ConstraintSet.getWidth(view.getId()));
        constraintWidget.setHeight(param1ConstraintSet.getHeight(view.getId()));
        if (view instanceof ConstraintHelper) {
          param1ConstraintSet.applyToHelper((ConstraintHelper)view, constraintWidget, (ConstraintLayout.LayoutParams)layoutParams, sparseArray);
          if (view instanceof Barrier)
            ((Barrier)view).validateParams(); 
        } 
        layoutParams.resolveLayoutDirection(MotionLayout.this.getLayoutDirection());
        MotionLayout.this.applyConstraintsFromLayoutParams(false, view, constraintWidget, (ConstraintLayout.LayoutParams)layoutParams, sparseArray);
        if (param1ConstraintSet.getVisibilityMode(view.getId()) == 1) {
          constraintWidget.setVisibility(view.getVisibility());
          continue;
        } 
        constraintWidget.setVisibility(param1ConstraintSet.getVisibility(view.getId()));
      } 
      for (ConstraintWidget constraintWidget : param1ConstraintWidgetContainer.getChildren()) {
        if (constraintWidget instanceof VirtualLayout) {
          ConstraintHelper constraintHelper = (ConstraintHelper)constraintWidget.getCompanionWidget();
          Helper helper = (Helper)constraintWidget;
          constraintHelper.updatePreLayout(param1ConstraintWidgetContainer, helper, sparseArray);
          ((VirtualLayout)helper).captureWidgets();
        } 
      } 
    }
    
    public void build() {
      int j;
      int k = MotionLayout.this.getChildCount();
      MotionLayout.this.mFrameArrayList.clear();
      byte b = 0;
      int i = 0;
      while (true) {
        j = b;
        if (i < k) {
          View view = MotionLayout.this.getChildAt(i);
          MotionController motionController = new MotionController(view);
          MotionLayout.this.mFrameArrayList.put(view, motionController);
          i++;
          continue;
        } 
        break;
      } 
      while (j < k) {
        View view = MotionLayout.this.getChildAt(j);
        MotionController motionController = MotionLayout.this.mFrameArrayList.get(view);
        if (motionController != null) {
          if (this.mStart != null) {
            ConstraintWidget constraintWidget = getWidget(this.mLayoutStart, view);
            if (constraintWidget != null) {
              motionController.setStartState(constraintWidget, this.mStart);
            } else if (MotionLayout.this.mDebugPath != 0) {
              StringBuilder stringBuilder = new StringBuilder();
              stringBuilder.append(Debug.getLocation());
              stringBuilder.append("no widget for  ");
              stringBuilder.append(Debug.getName(view));
              stringBuilder.append(" (");
              stringBuilder.append(view.getClass().getName());
              stringBuilder.append(")");
              Log.e("MotionLayout", stringBuilder.toString());
            } 
          } 
          if (this.mEnd != null) {
            ConstraintWidget constraintWidget = getWidget(this.mLayoutEnd, view);
            if (constraintWidget != null) {
              motionController.setEndState(constraintWidget, this.mEnd);
            } else if (MotionLayout.this.mDebugPath != 0) {
              StringBuilder stringBuilder = new StringBuilder();
              stringBuilder.append(Debug.getLocation());
              stringBuilder.append("no widget for  ");
              stringBuilder.append(Debug.getName(view));
              stringBuilder.append(" (");
              stringBuilder.append(view.getClass().getName());
              stringBuilder.append(")");
              Log.e("MotionLayout", stringBuilder.toString());
            } 
          } 
        } 
        j++;
      } 
    }
    
    void copy(ConstraintWidgetContainer param1ConstraintWidgetContainer1, ConstraintWidgetContainer param1ConstraintWidgetContainer2) {
      ArrayList arrayList = param1ConstraintWidgetContainer1.getChildren();
      HashMap<Object, Object> hashMap = new HashMap<Object, Object>();
      hashMap.put(param1ConstraintWidgetContainer1, param1ConstraintWidgetContainer2);
      param1ConstraintWidgetContainer2.getChildren().clear();
      param1ConstraintWidgetContainer2.copy((ConstraintWidget)param1ConstraintWidgetContainer1, hashMap);
      for (ConstraintWidget constraintWidget2 : arrayList) {
        ConstraintWidget constraintWidget1;
        if (constraintWidget2 instanceof Barrier) {
          Barrier barrier = new Barrier();
        } else if (constraintWidget2 instanceof Guideline) {
          Guideline guideline = new Guideline();
        } else if (constraintWidget2 instanceof Flow) {
          Flow flow = new Flow();
        } else if (constraintWidget2 instanceof Helper) {
          HelperWidget helperWidget = new HelperWidget();
        } else {
          constraintWidget1 = new ConstraintWidget();
        } 
        param1ConstraintWidgetContainer2.add(constraintWidget1);
        hashMap.put(constraintWidget2, constraintWidget1);
      } 
      for (ConstraintWidget constraintWidget : arrayList)
        ((ConstraintWidget)hashMap.get(constraintWidget)).copy(constraintWidget, hashMap); 
    }
    
    ConstraintWidget getWidget(ConstraintWidgetContainer param1ConstraintWidgetContainer, View param1View) {
      if (param1ConstraintWidgetContainer.getCompanionWidget() == param1View)
        return (ConstraintWidget)param1ConstraintWidgetContainer; 
      ArrayList<ConstraintWidget> arrayList = param1ConstraintWidgetContainer.getChildren();
      int j = arrayList.size();
      for (int i = 0; i < j; i++) {
        ConstraintWidget constraintWidget = arrayList.get(i);
        if (constraintWidget.getCompanionWidget() == param1View)
          return constraintWidget; 
      } 
      return null;
    }
    
    void initFrom(ConstraintWidgetContainer param1ConstraintWidgetContainer, ConstraintSet param1ConstraintSet1, ConstraintSet param1ConstraintSet2) {
      this.mStart = param1ConstraintSet1;
      this.mEnd = param1ConstraintSet2;
      this.mLayoutStart = new ConstraintWidgetContainer();
      this.mLayoutEnd = new ConstraintWidgetContainer();
      this.mLayoutStart.setMeasurer(MotionLayout.this.mLayoutWidget.getMeasurer());
      this.mLayoutEnd.setMeasurer(MotionLayout.this.mLayoutWidget.getMeasurer());
      this.mLayoutStart.removeAllChildren();
      this.mLayoutEnd.removeAllChildren();
      copy(MotionLayout.this.mLayoutWidget, this.mLayoutStart);
      copy(MotionLayout.this.mLayoutWidget, this.mLayoutEnd);
      if (MotionLayout.this.mTransitionLastPosition > 0.5D) {
        if (param1ConstraintSet1 != null)
          setupConstraintWidget(this.mLayoutStart, param1ConstraintSet1); 
        setupConstraintWidget(this.mLayoutEnd, param1ConstraintSet2);
      } else {
        setupConstraintWidget(this.mLayoutEnd, param1ConstraintSet2);
        if (param1ConstraintSet1 != null)
          setupConstraintWidget(this.mLayoutStart, param1ConstraintSet1); 
      } 
      this.mLayoutStart.setRtl(MotionLayout.this.isRtl());
      this.mLayoutStart.updateHierarchy();
      this.mLayoutEnd.setRtl(MotionLayout.this.isRtl());
      this.mLayoutEnd.updateHierarchy();
      ViewGroup.LayoutParams layoutParams = MotionLayout.this.getLayoutParams();
      if (layoutParams != null) {
        if (layoutParams.width == -2) {
          ConstraintWidgetContainer constraintWidgetContainer = this.mLayoutStart;
          ConstraintWidget.DimensionBehaviour dimensionBehaviour = ConstraintWidget.DimensionBehaviour.WRAP_CONTENT;
          constraintWidgetContainer.setHorizontalDimensionBehaviour(dimensionBehaviour);
          this.mLayoutEnd.setHorizontalDimensionBehaviour(dimensionBehaviour);
        } 
        if (layoutParams.height == -2) {
          ConstraintWidgetContainer constraintWidgetContainer = this.mLayoutStart;
          ConstraintWidget.DimensionBehaviour dimensionBehaviour = ConstraintWidget.DimensionBehaviour.WRAP_CONTENT;
          constraintWidgetContainer.setVerticalDimensionBehaviour(dimensionBehaviour);
          this.mLayoutEnd.setVerticalDimensionBehaviour(dimensionBehaviour);
        } 
      } 
    }
    
    public boolean isNotConfiguredWith(int param1Int1, int param1Int2) {
      return (param1Int1 != this.mStartId || param1Int2 != this.mEndId);
    }
    
    public void measure(int param1Int1, int param1Int2) {
      // Byte code:
      //   0: iload_1
      //   1: invokestatic getMode : (I)I
      //   4: istore #4
      //   6: iload_2
      //   7: invokestatic getMode : (I)I
      //   10: istore #5
      //   12: aload_0
      //   13: getfield this$0 : Landroidx/constraintlayout/motion/widget/MotionLayout;
      //   16: astore #9
      //   18: aload #9
      //   20: iload #4
      //   22: putfield mWidthMeasureMode : I
      //   25: aload #9
      //   27: iload #5
      //   29: putfield mHeightMeasureMode : I
      //   32: aload #9
      //   34: invokevirtual getOptimizationLevel : ()I
      //   37: istore #6
      //   39: aload_0
      //   40: getfield this$0 : Landroidx/constraintlayout/motion/widget/MotionLayout;
      //   43: astore #9
      //   45: aload #9
      //   47: getfield mCurrentState : I
      //   50: aload #9
      //   52: invokevirtual getStartState : ()I
      //   55: if_icmpne -> 98
      //   58: aload_0
      //   59: getfield this$0 : Landroidx/constraintlayout/motion/widget/MotionLayout;
      //   62: aload_0
      //   63: getfield mLayoutEnd : Landroidx/constraintlayout/solver/widgets/ConstraintWidgetContainer;
      //   66: iload #6
      //   68: iload_1
      //   69: iload_2
      //   70: invokestatic access$1200 : (Landroidx/constraintlayout/motion/widget/MotionLayout;Landroidx/constraintlayout/solver/widgets/ConstraintWidgetContainer;III)V
      //   73: aload_0
      //   74: getfield mStart : Landroidx/constraintlayout/widget/ConstraintSet;
      //   77: ifnull -> 135
      //   80: aload_0
      //   81: getfield this$0 : Landroidx/constraintlayout/motion/widget/MotionLayout;
      //   84: aload_0
      //   85: getfield mLayoutStart : Landroidx/constraintlayout/solver/widgets/ConstraintWidgetContainer;
      //   88: iload #6
      //   90: iload_1
      //   91: iload_2
      //   92: invokestatic access$1300 : (Landroidx/constraintlayout/motion/widget/MotionLayout;Landroidx/constraintlayout/solver/widgets/ConstraintWidgetContainer;III)V
      //   95: goto -> 135
      //   98: aload_0
      //   99: getfield mStart : Landroidx/constraintlayout/widget/ConstraintSet;
      //   102: ifnull -> 120
      //   105: aload_0
      //   106: getfield this$0 : Landroidx/constraintlayout/motion/widget/MotionLayout;
      //   109: aload_0
      //   110: getfield mLayoutStart : Landroidx/constraintlayout/solver/widgets/ConstraintWidgetContainer;
      //   113: iload #6
      //   115: iload_1
      //   116: iload_2
      //   117: invokestatic access$1400 : (Landroidx/constraintlayout/motion/widget/MotionLayout;Landroidx/constraintlayout/solver/widgets/ConstraintWidgetContainer;III)V
      //   120: aload_0
      //   121: getfield this$0 : Landroidx/constraintlayout/motion/widget/MotionLayout;
      //   124: aload_0
      //   125: getfield mLayoutEnd : Landroidx/constraintlayout/solver/widgets/ConstraintWidgetContainer;
      //   128: iload #6
      //   130: iload_1
      //   131: iload_2
      //   132: invokestatic access$1500 : (Landroidx/constraintlayout/motion/widget/MotionLayout;Landroidx/constraintlayout/solver/widgets/ConstraintWidgetContainer;III)V
      //   135: aload_0
      //   136: getfield this$0 : Landroidx/constraintlayout/motion/widget/MotionLayout;
      //   139: invokevirtual getParent : ()Landroid/view/ViewParent;
      //   142: instanceof androidx/constraintlayout/motion/widget/MotionLayout
      //   145: istore #7
      //   147: iconst_0
      //   148: istore #8
      //   150: iload #7
      //   152: ifeq -> 176
      //   155: iload #4
      //   157: ldc_w 1073741824
      //   160: if_icmpne -> 176
      //   163: iload #5
      //   165: ldc_w 1073741824
      //   168: if_icmpne -> 176
      //   171: iconst_0
      //   172: istore_3
      //   173: goto -> 178
      //   176: iconst_1
      //   177: istore_3
      //   178: iload_3
      //   179: ifeq -> 399
      //   182: aload_0
      //   183: getfield this$0 : Landroidx/constraintlayout/motion/widget/MotionLayout;
      //   186: astore #9
      //   188: aload #9
      //   190: iload #4
      //   192: putfield mWidthMeasureMode : I
      //   195: aload #9
      //   197: iload #5
      //   199: putfield mHeightMeasureMode : I
      //   202: aload #9
      //   204: getfield mCurrentState : I
      //   207: aload #9
      //   209: invokevirtual getStartState : ()I
      //   212: if_icmpne -> 255
      //   215: aload_0
      //   216: getfield this$0 : Landroidx/constraintlayout/motion/widget/MotionLayout;
      //   219: aload_0
      //   220: getfield mLayoutEnd : Landroidx/constraintlayout/solver/widgets/ConstraintWidgetContainer;
      //   223: iload #6
      //   225: iload_1
      //   226: iload_2
      //   227: invokestatic access$1600 : (Landroidx/constraintlayout/motion/widget/MotionLayout;Landroidx/constraintlayout/solver/widgets/ConstraintWidgetContainer;III)V
      //   230: aload_0
      //   231: getfield mStart : Landroidx/constraintlayout/widget/ConstraintSet;
      //   234: ifnull -> 292
      //   237: aload_0
      //   238: getfield this$0 : Landroidx/constraintlayout/motion/widget/MotionLayout;
      //   241: aload_0
      //   242: getfield mLayoutStart : Landroidx/constraintlayout/solver/widgets/ConstraintWidgetContainer;
      //   245: iload #6
      //   247: iload_1
      //   248: iload_2
      //   249: invokestatic access$1700 : (Landroidx/constraintlayout/motion/widget/MotionLayout;Landroidx/constraintlayout/solver/widgets/ConstraintWidgetContainer;III)V
      //   252: goto -> 292
      //   255: aload_0
      //   256: getfield mStart : Landroidx/constraintlayout/widget/ConstraintSet;
      //   259: ifnull -> 277
      //   262: aload_0
      //   263: getfield this$0 : Landroidx/constraintlayout/motion/widget/MotionLayout;
      //   266: aload_0
      //   267: getfield mLayoutStart : Landroidx/constraintlayout/solver/widgets/ConstraintWidgetContainer;
      //   270: iload #6
      //   272: iload_1
      //   273: iload_2
      //   274: invokestatic access$1800 : (Landroidx/constraintlayout/motion/widget/MotionLayout;Landroidx/constraintlayout/solver/widgets/ConstraintWidgetContainer;III)V
      //   277: aload_0
      //   278: getfield this$0 : Landroidx/constraintlayout/motion/widget/MotionLayout;
      //   281: aload_0
      //   282: getfield mLayoutEnd : Landroidx/constraintlayout/solver/widgets/ConstraintWidgetContainer;
      //   285: iload #6
      //   287: iload_1
      //   288: iload_2
      //   289: invokestatic access$1900 : (Landroidx/constraintlayout/motion/widget/MotionLayout;Landroidx/constraintlayout/solver/widgets/ConstraintWidgetContainer;III)V
      //   292: aload_0
      //   293: getfield this$0 : Landroidx/constraintlayout/motion/widget/MotionLayout;
      //   296: aload_0
      //   297: getfield mLayoutStart : Landroidx/constraintlayout/solver/widgets/ConstraintWidgetContainer;
      //   300: invokevirtual getWidth : ()I
      //   303: putfield mStartWrapWidth : I
      //   306: aload_0
      //   307: getfield this$0 : Landroidx/constraintlayout/motion/widget/MotionLayout;
      //   310: aload_0
      //   311: getfield mLayoutStart : Landroidx/constraintlayout/solver/widgets/ConstraintWidgetContainer;
      //   314: invokevirtual getHeight : ()I
      //   317: putfield mStartWrapHeight : I
      //   320: aload_0
      //   321: getfield this$0 : Landroidx/constraintlayout/motion/widget/MotionLayout;
      //   324: aload_0
      //   325: getfield mLayoutEnd : Landroidx/constraintlayout/solver/widgets/ConstraintWidgetContainer;
      //   328: invokevirtual getWidth : ()I
      //   331: putfield mEndWrapWidth : I
      //   334: aload_0
      //   335: getfield this$0 : Landroidx/constraintlayout/motion/widget/MotionLayout;
      //   338: aload_0
      //   339: getfield mLayoutEnd : Landroidx/constraintlayout/solver/widgets/ConstraintWidgetContainer;
      //   342: invokevirtual getHeight : ()I
      //   345: putfield mEndWrapHeight : I
      //   348: aload_0
      //   349: getfield this$0 : Landroidx/constraintlayout/motion/widget/MotionLayout;
      //   352: astore #9
      //   354: aload #9
      //   356: getfield mStartWrapWidth : I
      //   359: aload #9
      //   361: getfield mEndWrapWidth : I
      //   364: if_icmpne -> 389
      //   367: aload #9
      //   369: getfield mStartWrapHeight : I
      //   372: aload #9
      //   374: getfield mEndWrapHeight : I
      //   377: if_icmpeq -> 383
      //   380: goto -> 389
      //   383: iconst_0
      //   384: istore #7
      //   386: goto -> 392
      //   389: iconst_1
      //   390: istore #7
      //   392: aload #9
      //   394: iload #7
      //   396: putfield mMeasureDuringTransition : Z
      //   399: aload_0
      //   400: getfield this$0 : Landroidx/constraintlayout/motion/widget/MotionLayout;
      //   403: astore #9
      //   405: aload #9
      //   407: getfield mStartWrapWidth : I
      //   410: istore #4
      //   412: aload #9
      //   414: getfield mStartWrapHeight : I
      //   417: istore #5
      //   419: aload #9
      //   421: getfield mWidthMeasureMode : I
      //   424: istore #6
      //   426: iload #6
      //   428: ldc_w -2147483648
      //   431: if_icmpeq -> 442
      //   434: iload #4
      //   436: istore_3
      //   437: iload #6
      //   439: ifne -> 463
      //   442: iload #4
      //   444: i2f
      //   445: aload #9
      //   447: getfield mPostInterpolationPosition : F
      //   450: aload #9
      //   452: getfield mEndWrapWidth : I
      //   455: iload #4
      //   457: isub
      //   458: i2f
      //   459: fmul
      //   460: fadd
      //   461: f2i
      //   462: istore_3
      //   463: aload #9
      //   465: getfield mHeightMeasureMode : I
      //   468: istore #6
      //   470: iload #6
      //   472: ldc_w -2147483648
      //   475: if_icmpeq -> 487
      //   478: iload #5
      //   480: istore #4
      //   482: iload #6
      //   484: ifne -> 509
      //   487: iload #5
      //   489: i2f
      //   490: aload #9
      //   492: getfield mPostInterpolationPosition : F
      //   495: aload #9
      //   497: getfield mEndWrapHeight : I
      //   500: iload #5
      //   502: isub
      //   503: i2f
      //   504: fmul
      //   505: fadd
      //   506: f2i
      //   507: istore #4
      //   509: aload_0
      //   510: getfield mLayoutStart : Landroidx/constraintlayout/solver/widgets/ConstraintWidgetContainer;
      //   513: invokevirtual isWidthMeasuredTooSmall : ()Z
      //   516: ifne -> 538
      //   519: aload_0
      //   520: getfield mLayoutEnd : Landroidx/constraintlayout/solver/widgets/ConstraintWidgetContainer;
      //   523: invokevirtual isWidthMeasuredTooSmall : ()Z
      //   526: ifeq -> 532
      //   529: goto -> 538
      //   532: iconst_0
      //   533: istore #7
      //   535: goto -> 541
      //   538: iconst_1
      //   539: istore #7
      //   541: aload_0
      //   542: getfield mLayoutStart : Landroidx/constraintlayout/solver/widgets/ConstraintWidgetContainer;
      //   545: invokevirtual isHeightMeasuredTooSmall : ()Z
      //   548: ifne -> 561
      //   551: aload_0
      //   552: getfield mLayoutEnd : Landroidx/constraintlayout/solver/widgets/ConstraintWidgetContainer;
      //   555: invokevirtual isHeightMeasuredTooSmall : ()Z
      //   558: ifeq -> 564
      //   561: iconst_1
      //   562: istore #8
      //   564: aload_0
      //   565: getfield this$0 : Landroidx/constraintlayout/motion/widget/MotionLayout;
      //   568: iload_1
      //   569: iload_2
      //   570: iload_3
      //   571: iload #4
      //   573: iload #7
      //   575: iload #8
      //   577: invokestatic access$2000 : (Landroidx/constraintlayout/motion/widget/MotionLayout;IIIIZZ)V
      //   580: return
    }
    
    public void reEvaluateState() {
      measure(MotionLayout.this.mLastWidthMeasureSpec, MotionLayout.this.mLastHeightMeasureSpec);
      MotionLayout.this.setupMotionViews();
    }
    
    public void setMeasuredId(int param1Int1, int param1Int2) {
      this.mStartId = param1Int1;
      this.mEndId = param1Int2;
    }
  }
  
  protected static interface MotionTracker {
    void addMovement(MotionEvent param1MotionEvent);
    
    void clear();
    
    void computeCurrentVelocity(int param1Int);
    
    void computeCurrentVelocity(int param1Int, float param1Float);
    
    float getXVelocity();
    
    float getXVelocity(int param1Int);
    
    float getYVelocity();
    
    float getYVelocity(int param1Int);
    
    void recycle();
  }
  
  private static class MyTracker implements MotionTracker {
    private static MyTracker me = new MyTracker();
    
    VelocityTracker tracker;
    
    public static MyTracker obtain() {
      me.tracker = VelocityTracker.obtain();
      return me;
    }
    
    public void addMovement(MotionEvent param1MotionEvent) {
      VelocityTracker velocityTracker = this.tracker;
      if (velocityTracker != null)
        velocityTracker.addMovement(param1MotionEvent); 
    }
    
    public void clear() {
      VelocityTracker velocityTracker = this.tracker;
      if (velocityTracker != null)
        velocityTracker.clear(); 
    }
    
    public void computeCurrentVelocity(int param1Int) {
      VelocityTracker velocityTracker = this.tracker;
      if (velocityTracker != null)
        velocityTracker.computeCurrentVelocity(param1Int); 
    }
    
    public void computeCurrentVelocity(int param1Int, float param1Float) {
      VelocityTracker velocityTracker = this.tracker;
      if (velocityTracker != null)
        velocityTracker.computeCurrentVelocity(param1Int, param1Float); 
    }
    
    public float getXVelocity() {
      VelocityTracker velocityTracker = this.tracker;
      return (velocityTracker != null) ? velocityTracker.getXVelocity() : 0.0F;
    }
    
    public float getXVelocity(int param1Int) {
      VelocityTracker velocityTracker = this.tracker;
      return (velocityTracker != null) ? velocityTracker.getXVelocity(param1Int) : 0.0F;
    }
    
    public float getYVelocity() {
      VelocityTracker velocityTracker = this.tracker;
      return (velocityTracker != null) ? velocityTracker.getYVelocity() : 0.0F;
    }
    
    public float getYVelocity(int param1Int) {
      return (this.tracker != null) ? getYVelocity(param1Int) : 0.0F;
    }
    
    public void recycle() {
      VelocityTracker velocityTracker = this.tracker;
      if (velocityTracker != null) {
        velocityTracker.recycle();
        this.tracker = null;
      } 
    }
  }
  
  class StateCache {
    final String KeyEndState = "motion.EndState";
    
    final String KeyProgress = "motion.progress";
    
    final String KeyStartState = "motion.StartState";
    
    final String KeyVelocity = "motion.velocity";
    
    int endState = -1;
    
    float mProgress = Float.NaN;
    
    float mVelocity = Float.NaN;
    
    int startState = -1;
    
    void apply() {
      int i = this.startState;
      if (i != -1 || this.endState != -1) {
        if (i == -1) {
          MotionLayout.this.transitionToState(this.endState);
        } else {
          int j = this.endState;
          if (j == -1) {
            MotionLayout.this.setState(i, -1, -1);
          } else {
            MotionLayout.this.setTransition(i, j);
          } 
        } 
        MotionLayout.this.setState(MotionLayout.TransitionState.SETUP);
      } 
      if (Float.isNaN(this.mVelocity)) {
        if (Float.isNaN(this.mProgress))
          return; 
        MotionLayout.this.setProgress(this.mProgress);
        return;
      } 
      MotionLayout.this.setProgress(this.mProgress, this.mVelocity);
      this.mProgress = Float.NaN;
      this.mVelocity = Float.NaN;
      this.startState = -1;
      this.endState = -1;
    }
    
    public Bundle getTransitionState() {
      Bundle bundle = new Bundle();
      bundle.putFloat("motion.progress", this.mProgress);
      bundle.putFloat("motion.velocity", this.mVelocity);
      bundle.putInt("motion.StartState", this.startState);
      bundle.putInt("motion.EndState", this.endState);
      return bundle;
    }
    
    public void recordState() {
      this.endState = MotionLayout.this.mEndState;
      this.startState = MotionLayout.this.mBeginState;
      this.mVelocity = MotionLayout.this.getVelocity();
      this.mProgress = MotionLayout.this.getProgress();
    }
    
    public void setEndState(int param1Int) {
      this.endState = param1Int;
    }
    
    public void setProgress(float param1Float) {
      this.mProgress = param1Float;
    }
    
    public void setStartState(int param1Int) {
      this.startState = param1Int;
    }
    
    public void setTransitionState(Bundle param1Bundle) {
      this.mProgress = param1Bundle.getFloat("motion.progress");
      this.mVelocity = param1Bundle.getFloat("motion.velocity");
      this.startState = param1Bundle.getInt("motion.StartState");
      this.endState = param1Bundle.getInt("motion.EndState");
    }
    
    public void setVelocity(float param1Float) {
      this.mVelocity = param1Float;
    }
  }
  
  public static interface TransitionListener {
    void onTransitionChange(MotionLayout param1MotionLayout, int param1Int1, int param1Int2, float param1Float);
    
    void onTransitionCompleted(MotionLayout param1MotionLayout, int param1Int);
    
    void onTransitionStarted(MotionLayout param1MotionLayout, int param1Int1, int param1Int2);
    
    void onTransitionTrigger(MotionLayout param1MotionLayout, int param1Int, boolean param1Boolean, float param1Float);
  }
  
  enum TransitionState {
    FINISHED, MOVING, SETUP, UNDEFINED;
    
    static {
      TransitionState transitionState1 = new TransitionState("UNDEFINED", 0);
      UNDEFINED = transitionState1;
      TransitionState transitionState2 = new TransitionState("SETUP", 1);
      SETUP = transitionState2;
      TransitionState transitionState3 = new TransitionState("MOVING", 2);
      MOVING = transitionState3;
      TransitionState transitionState4 = new TransitionState("FINISHED", 3);
      FINISHED = transitionState4;
      $VALUES = new TransitionState[] { transitionState1, transitionState2, transitionState3, transitionState4 };
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\BabyBus TV_Kids Videos & Games-dex2jar.jar!\androidx\constraintlayout\motion\widget\MotionLayout.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */