package a5;

import android.content.Intent;
import androidx.annotation.NonNull;

public class d extends e {
  private final int zza;
  
  public d(int paramInt, @NonNull String paramString, @NonNull Intent paramIntent) {
    super(paramString, paramIntent);
    this.zza = paramInt;
  }
  
  public int getConnectionStatusCode() {
    return this.zza;
  }
}


/* Location:              C:\soft\dex2jar-2.0\BabyBus TV_Kids Videos & Games-dex2jar.jar!\a5\d.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */