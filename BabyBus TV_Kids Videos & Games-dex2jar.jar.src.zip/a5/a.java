package a5;

import android.content.ComponentName;
import android.content.ServiceConnection;
import android.os.IBinder;
import androidx.annotation.NonNull;
import com.google.android.gms.common.internal.m;
import java.util.concurrent.BlockingQueue;
import java.util.concurrent.LinkedBlockingQueue;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.TimeoutException;

public class a implements ServiceConnection {
  boolean a = false;
  
  private final BlockingQueue<IBinder> d = new LinkedBlockingQueue<IBinder>();
  
  @NonNull
  public IBinder a(long paramLong, @NonNull TimeUnit paramTimeUnit) throws InterruptedException, TimeoutException {
    m.h("BlockingServiceConnection.getServiceWithTimeout() called on main thread");
    if (!this.a) {
      this.a = true;
      IBinder iBinder = this.d.poll(paramLong, paramTimeUnit);
      if (iBinder != null)
        return iBinder; 
      throw new TimeoutException("Timed out waiting for the service connection");
    } 
    throw new IllegalStateException("Cannot call get on this connection more than once");
  }
  
  public final void onServiceConnected(@NonNull ComponentName paramComponentName, @NonNull IBinder paramIBinder) {
    this.d.add(paramIBinder);
  }
  
  public final void onServiceDisconnected(@NonNull ComponentName paramComponentName) {}
}


/* Location:              C:\soft\dex2jar-2.0\BabyBus TV_Kids Videos & Games-dex2jar.jar!\a5\a.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */