package a5;

import android.app.AlertDialog;
import android.app.Dialog;
import android.app.DialogFragment;
import android.app.FragmentManager;
import android.content.Context;
import android.content.DialogInterface;
import android.os.Bundle;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.annotation.RecentlyNonNull;
import com.google.android.gms.common.internal.m;

public class b extends DialogFragment {
  private Dialog a;
  
  private DialogInterface.OnCancelListener d;
  
  @Nullable
  private Dialog h;
  
  @NonNull
  public static b a(@RecentlyNonNull Dialog paramDialog, @Nullable DialogInterface.OnCancelListener paramOnCancelListener) {
    b b1 = new b();
    paramDialog = (Dialog)m.j(paramDialog, "Cannot display null dialog");
    paramDialog.setOnCancelListener(null);
    paramDialog.setOnDismissListener(null);
    b1.a = paramDialog;
    if (paramOnCancelListener != null)
      b1.d = paramOnCancelListener; 
    return b1;
  }
  
  public void onCancel(@RecentlyNonNull DialogInterface paramDialogInterface) {
    DialogInterface.OnCancelListener onCancelListener = this.d;
    if (onCancelListener != null)
      onCancelListener.onCancel(paramDialogInterface); 
  }
  
  @NonNull
  public Dialog onCreateDialog(@Nullable Bundle paramBundle) {
    Dialog dialog2 = this.a;
    Dialog dialog1 = dialog2;
    if (dialog2 == null) {
      setShowsDialog(false);
      if (this.h == null)
        this.h = (Dialog)(new AlertDialog.Builder((Context)getActivity())).create(); 
      dialog1 = this.h;
    } 
    return dialog1;
  }
  
  public void show(@RecentlyNonNull FragmentManager paramFragmentManager, @Nullable String paramString) {
    super.show(paramFragmentManager, paramString);
  }
}


/* Location:              C:\soft\dex2jar-2.0\BabyBus TV_Kids Videos & Games-dex2jar.jar!\a5\b.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */