package a5;

import android.os.Parcel;
import android.os.Parcelable;
import c5.a;
import com.google.android.gms.common.Feature;

public final class f implements Parcelable.Creator<Feature> {}


/* Location:              C:\soft\dex2jar-2.0\BabyBus TV_Kids Videos & Games-dex2jar.jar!\a5\f.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */