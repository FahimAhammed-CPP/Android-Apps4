package a1;

import java.util.concurrent.BlockingQueue;
import java.util.concurrent.Callable;
import java.util.concurrent.Future;
import java.util.concurrent.ThreadFactory;
import java.util.concurrent.ThreadPoolExecutor;
import java.util.concurrent.TimeUnit;
import u1.r;

public final class e extends ThreadPoolExecutor {
  public e(int paramInt1, int paramInt2, long paramLong, TimeUnit paramTimeUnit, BlockingQueue<Runnable> paramBlockingQueue, ThreadFactory paramThreadFactory) {
    super(paramInt1, paramInt2, paramLong, paramTimeUnit, paramBlockingQueue, paramThreadFactory);
    allowCoreThreadTimeOut(true);
  }
  
  public void execute(Runnable paramRunnable) {
    r.e(paramRunnable, "command");
    try {
      super.execute(paramRunnable);
      return;
    } catch (OutOfMemoryError outOfMemoryError) {
      return;
    } 
  }
  
  public final void execute(Runnable paramRunnable1, Runnable paramRunnable2) {
    r.e(paramRunnable1, "command");
    try {
      super.execute(paramRunnable1);
      return;
    } catch (OutOfMemoryError outOfMemoryError) {
      if (paramRunnable2 != null)
        paramRunnable2.run(); 
      return;
    } 
  }
  
  public Future<?> submit(Runnable paramRunnable) {
    r.e(paramRunnable, "task");
    try {
      Future<?> future = super.submit(paramRunnable);
      r.d(future, "{\n            super.submit(task)\n        }");
      return future;
    } catch (OutOfMemoryError outOfMemoryError) {
      return new b(null);
    } 
  }
  
  public <T> Future<T> submit(Runnable paramRunnable, T paramT) {
    r.e(paramRunnable, "task");
    try {
      Future<T> future = super.submit(paramRunnable, paramT);
      r.d(future, "{\n            super.submit(task, result)\n        }");
      return future;
    } catch (OutOfMemoryError outOfMemoryError) {
      return new b<T>(null);
    } 
  }
  
  public final Future<?> submit(Runnable paramRunnable1, Runnable paramRunnable2) {
    r.e(paramRunnable1, "task");
    try {
      Future<?> future = super.submit(paramRunnable1);
      r.d(future, "{\n            super.submit(task)\n        }");
      return future;
    } catch (OutOfMemoryError outOfMemoryError) {
      if (paramRunnable2 != null)
        paramRunnable2.run(); 
      return new b(null);
    } 
  }
  
  public <T> Future<T> submit(Callable<T> paramCallable) {
    r.e(paramCallable, "task");
    try {
      Future<T> future = super.submit(paramCallable);
      r.d(future, "{\n            super.submit(task)\n        }");
      return future;
    } catch (OutOfMemoryError outOfMemoryError) {
      return new b<T>(null);
    } 
  }
}


/* Location:              C:\soft\dex2jar-2.0\Hill race-dex2jar.jar!\a1\e.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */