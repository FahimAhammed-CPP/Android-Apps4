package a1;

import java.util.concurrent.LinkedBlockingQueue;
import java.util.concurrent.PriorityBlockingQueue;
import java.util.concurrent.TimeUnit;
import u1.j;

public final class d implements a {
  public static final a Companion = new a(null);
  
  private static final int IO_KEEP_ALIVE_TIME_SECONDS = 5;
  
  private static final int JOBS_KEEP_ALIVE_TIME_SECONDS = 1;
  
  private static final int SINGLE_CORE_POOL_SIZE = 1;
  
  private static final int VUNGLE_KEEP_ALIVE_TIME_SECONDS = 10;
  
  private e BACKGROUND_EXECUTOR;
  
  private e DOWNLOADER_EXECUTOR;
  
  private e IO_EXECUTOR;
  
  private e JOB_EXECUTOR;
  
  private e LOGGER_EXECUTOR;
  
  private final int NUMBER_OF_CORES;
  
  private e OFFLOAD_EXECUTOR;
  
  private e UA_EXECUTOR;
  
  public d() {
    int i = Runtime.getRuntime().availableProcessors();
    this.NUMBER_OF_CORES = i;
    TimeUnit timeUnit = TimeUnit.SECONDS;
    this.JOB_EXECUTOR = new e(i, i, 1L, timeUnit, new LinkedBlockingQueue<Runnable>(), new c("vng_jr"));
    this.IO_EXECUTOR = new e(1, 1, 5L, timeUnit, new LinkedBlockingQueue<Runnable>(), new c("vng_io"));
    this.LOGGER_EXECUTOR = new e(1, 1, 10L, timeUnit, new LinkedBlockingQueue<Runnable>(), new c("vng_logger"));
    this.BACKGROUND_EXECUTOR = new e(1, 1, 10L, timeUnit, new LinkedBlockingQueue<Runnable>(), new c("vng_background"));
    this.UA_EXECUTOR = new e(1, 1, 10L, timeUnit, new LinkedBlockingQueue<Runnable>(), new c("vng_ua"));
    this.DOWNLOADER_EXECUTOR = new e(4, 4, 1L, timeUnit, new PriorityBlockingQueue<Runnable>(), new c("vng_down"));
    this.OFFLOAD_EXECUTOR = new e(1, 1, 10L, timeUnit, new LinkedBlockingQueue<Runnable>(), new c("vng_ol"));
  }
  
  public e getBackgroundExecutor() {
    return this.BACKGROUND_EXECUTOR;
  }
  
  public e getDownloaderExecutor() {
    return this.DOWNLOADER_EXECUTOR;
  }
  
  public e getIoExecutor() {
    return this.IO_EXECUTOR;
  }
  
  public e getJobExecutor() {
    return this.JOB_EXECUTOR;
  }
  
  public e getLoggerExecutor() {
    return this.LOGGER_EXECUTOR;
  }
  
  public e getOffloadExecutor() {
    return this.OFFLOAD_EXECUTOR;
  }
  
  public e getUaExecutor() {
    return this.UA_EXECUTOR;
  }
  
  public static final class a {
    private a() {}
  }
}


/* Location:              C:\soft\dex2jar-2.0\Hill race-dex2jar.jar!\a1\d.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */