package a1;

import java.util.concurrent.Executors;
import java.util.concurrent.ThreadFactory;
import java.util.concurrent.atomic.AtomicInteger;
import u1.r;

public final class c implements ThreadFactory {
  private final AtomicInteger atomicInteger;
  
  private final String name;
  
  private final ThreadFactory threadFactory;
  
  public c(String paramString) {
    this.name = paramString;
    this.threadFactory = Executors.defaultThreadFactory();
    this.atomicInteger = new AtomicInteger(0);
  }
  
  public Thread newThread(Runnable paramRunnable) {
    r.e(paramRunnable, "r");
    paramRunnable = this.threadFactory.newThread(paramRunnable);
    String str = this.name;
    int i = this.atomicInteger.incrementAndGet();
    StringBuilder stringBuilder = new StringBuilder();
    stringBuilder.append(str);
    stringBuilder.append("-th-");
    stringBuilder.append(i);
    paramRunnable.setName(stringBuilder.toString());
    r.d(paramRunnable, "t");
    return (Thread)paramRunnable;
  }
}


/* Location:              C:\soft\dex2jar-2.0\Hill race-dex2jar.jar!\a1\c.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */