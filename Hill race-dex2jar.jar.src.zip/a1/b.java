package a1;

import android.util.Log;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.Future;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.TimeoutException;
import u1.j;
import u1.r;

public final class b<T> implements Future<T> {
  public static final a Companion = new a(null);
  
  private static final String TAG = b.class.getSimpleName();
  
  private final Future<T> future;
  
  public b(Future<T> paramFuture) {
    this.future = paramFuture;
  }
  
  public boolean cancel(boolean paramBoolean) {
    Future<T> future = this.future;
    return (future != null) ? future.cancel(paramBoolean) : false;
  }
  
  public T get() {
    try {
      Future<T> future = this.future;
      if (future != null)
        return future.get(); 
    } catch (InterruptedException interruptedException) {
      String str1 = TAG;
      String str2 = Thread.currentThread().getName();
      StringBuilder stringBuilder = new StringBuilder();
      stringBuilder.append("future.get() Interrupted on Thread ");
      stringBuilder.append(str2);
      Log.w(str1, stringBuilder.toString());
      Thread.currentThread().interrupt();
    } catch (ExecutionException executionException) {
      Log.e(TAG, "error on execution", executionException);
      return null;
    } 
    return null;
  }
  
  public T get(long paramLong, TimeUnit paramTimeUnit) {
    r.e(paramTimeUnit, "unit");
    try {
      Future<T> future = this.future;
      return (future != null) ? future.get(paramLong, paramTimeUnit) : null;
    } catch (InterruptedException interruptedException) {
      String str1 = TAG;
      String str2 = Thread.currentThread().getName();
      StringBuilder stringBuilder = new StringBuilder();
      stringBuilder.append("future.get() Interrupted on Thread ");
      stringBuilder.append(str2);
      Log.w(str1, stringBuilder.toString());
      Thread.currentThread().interrupt();
      return null;
    } catch (ExecutionException executionException) {
      Log.e(TAG, "error on execution", executionException);
      return null;
    } catch (TimeoutException timeoutException) {
      String str1 = TAG;
      String str2 = Thread.currentThread().getName();
      StringBuilder stringBuilder = new StringBuilder();
      stringBuilder.append("future.get() Timeout on Thread ");
      stringBuilder.append(str2);
      Log.w(str1, stringBuilder.toString());
      return null;
    } 
  }
  
  public final Future<T> getFuture() {
    return this.future;
  }
  
  public boolean isCancelled() {
    Future<T> future = this.future;
    return (future != null) ? future.isCancelled() : false;
  }
  
  public boolean isDone() {
    Future<T> future = this.future;
    return (future != null) ? future.isDone() : false;
  }
  
  public static final class a {
    private a() {}
    
    public final String getTAG() {
      return b.TAG;
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Hill race-dex2jar.jar!\a1\b.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */