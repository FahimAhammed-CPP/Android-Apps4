package a;

import android.net.Uri;
import android.os.Binder;
import android.os.Bundle;
import android.os.IBinder;
import android.os.IInterface;
import android.os.Parcel;
import android.os.RemoteException;

public interface a extends IInterface {
  Bundle c(String paramString, Bundle paramBundle) throws RemoteException;
  
  void g(String paramString, Bundle paramBundle) throws RemoteException;
  
  void h(int paramInt, Bundle paramBundle) throws RemoteException;
  
  void i(String paramString, Bundle paramBundle) throws RemoteException;
  
  void k(Bundle paramBundle) throws RemoteException;
  
  void l(int paramInt, Uri paramUri, boolean paramBoolean, Bundle paramBundle) throws RemoteException;
  
  public static abstract class a extends Binder implements a {
    public a() {
      attachInterface(this, "android.support.customtabs.ICustomTabsCallback");
    }
    
    public IBinder asBinder() {
      return (IBinder)this;
    }
    
    public boolean onTransact(int param1Int1, Parcel param1Parcel1, Parcel param1Parcel2, int param1Int2) throws RemoteException {
      if (param1Int1 != 1598968902) {
        Bundle bundle1;
        Bundle bundle3;
        String str1;
        boolean bool = false;
        String str2 = null;
        Bundle bundle4 = null;
        Bundle bundle6 = null;
        Bundle bundle5 = null;
        Bundle bundle7 = null;
        Bundle bundle2 = null;
        switch (param1Int1) {
          default:
            return super.onTransact(param1Int1, param1Parcel1, param1Parcel2, param1Int2);
          case 7:
            param1Parcel1.enforceInterface("android.support.customtabs.ICustomTabsCallback");
            str2 = param1Parcel1.readString();
            if (param1Parcel1.readInt() != 0)
              bundle2 = (Bundle)Bundle.CREATOR.createFromParcel(param1Parcel1); 
            bundle1 = c(str2, bundle2);
            param1Parcel2.writeNoException();
            if (bundle1 != null) {
              param1Parcel2.writeInt(1);
              bundle1.writeToParcel(param1Parcel2, 1);
              return true;
            } 
            param1Parcel2.writeInt(0);
            return true;
          case 6:
            bundle1.enforceInterface("android.support.customtabs.ICustomTabsCallback");
            param1Int1 = bundle1.readInt();
            if (bundle1.readInt() != 0) {
              Uri uri = (Uri)Uri.CREATOR.createFromParcel((Parcel)bundle1);
            } else {
              bundle2 = null;
            } 
            if (bundle1.readInt() != 0)
              bool = true; 
            if (bundle1.readInt() != 0)
              bundle3 = (Bundle)Bundle.CREATOR.createFromParcel((Parcel)bundle1); 
            l(param1Int1, (Uri)bundle2, bool, bundle3);
            param1Parcel2.writeNoException();
            return true;
          case 5:
            bundle1.enforceInterface("android.support.customtabs.ICustomTabsCallback");
            str1 = bundle1.readString();
            bundle2 = bundle4;
            if (bundle1.readInt() != 0)
              bundle2 = (Bundle)Bundle.CREATOR.createFromParcel((Parcel)bundle1); 
            i(str1, bundle2);
            param1Parcel2.writeNoException();
            return true;
          case 4:
            bundle1.enforceInterface("android.support.customtabs.ICustomTabsCallback");
            bundle2 = bundle6;
            if (bundle1.readInt() != 0)
              bundle2 = (Bundle)Bundle.CREATOR.createFromParcel((Parcel)bundle1); 
            k(bundle2);
            param1Parcel2.writeNoException();
            return true;
          case 3:
            bundle1.enforceInterface("android.support.customtabs.ICustomTabsCallback");
            str1 = bundle1.readString();
            bundle2 = bundle5;
            if (bundle1.readInt() != 0)
              bundle2 = (Bundle)Bundle.CREATOR.createFromParcel((Parcel)bundle1); 
            g(str1, bundle2);
            param1Parcel2.writeNoException();
            return true;
          case 2:
            break;
        } 
        bundle1.enforceInterface("android.support.customtabs.ICustomTabsCallback");
        param1Int1 = bundle1.readInt();
        bundle2 = bundle7;
        if (bundle1.readInt() != 0)
          bundle2 = (Bundle)Bundle.CREATOR.createFromParcel((Parcel)bundle1); 
        h(param1Int1, bundle2);
        param1Parcel2.writeNoException();
        return true;
      } 
      param1Parcel2.writeString("android.support.customtabs.ICustomTabsCallback");
      return true;
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Hill race-dex2jar.jar!\a\a.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */