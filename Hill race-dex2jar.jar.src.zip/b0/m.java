package b0;

import a0.p;
import android.content.Context;
import androidx.work.e;
import androidx.work.impl.WorkDatabase;
import androidx.work.impl.utils.futures.c;
import androidx.work.l;
import androidx.work.q;
import com.google.common.util.concurrent.ListenableFuture;
import java.util.UUID;

public class m implements q {
  static final String c = l.f("WorkProgressUpdater");
  
  final WorkDatabase a;
  
  final c0.a b;
  
  public m(WorkDatabase paramWorkDatabase, c0.a parama) {
    this.a = paramWorkDatabase;
    this.b = parama;
  }
  
  public ListenableFuture<Void> a(Context paramContext, UUID paramUUID, e parame) {
    c c = c.s();
    this.b.b(new a(this, paramUUID, parame, c));
    return (ListenableFuture<Void>)c;
  }
  
  class a implements Runnable {
    a(m this$0, UUID param1UUID, e param1e, c param1c) {}
    
    public void run() {
      String str1 = this.b.toString();
      l l = l.c();
      String str2 = m.c;
      l.a(str2, String.format("Updating progress for %s (%s)", new Object[] { this.b, this.c }), new Throwable[0]);
      this.e.a.c();
      try {
        p p = this.e.a.B().n(str1);
      } finally {
        str1 = null;
      } 
      this.e.a.g();
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Hill race-dex2jar.jar!\b0\m.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */