package b0;

import a0.d;
import android.content.Context;
import android.content.SharedPreferences;
import androidx.work.impl.WorkDatabase;
import m.b;

public class e {
  private final WorkDatabase a;
  
  public e(WorkDatabase paramWorkDatabase) {
    this.a = paramWorkDatabase;
  }
  
  public static void b(Context paramContext, b paramb) {
    SharedPreferences sharedPreferences = paramContext.getSharedPreferences("androidx.work.util.preferences", 0);
    if (sharedPreferences.contains("reschedule_needed") || sharedPreferences.contains("last_cancel_all_time_ms")) {
      long l1 = 0L;
      long l2 = sharedPreferences.getLong("last_cancel_all_time_ms", 0L);
      if (sharedPreferences.getBoolean("reschedule_needed", false))
        l1 = 1L; 
      paramb.D();
      try {
        paramb.S("INSERT OR REPLACE INTO `Preference` (`key`, `long_value`) VALUES (@key, @long_value)", new Object[] { "last_cancel_all_time_ms", Long.valueOf(l2) });
        paramb.S("INSERT OR REPLACE INTO `Preference` (`key`, `long_value`) VALUES (@key, @long_value)", new Object[] { "reschedule_needed", Long.valueOf(l1) });
        sharedPreferences.edit().clear().apply();
        paramb.Q();
        return;
      } finally {
        paramb.Y();
      } 
    } 
  }
  
  public boolean a() {
    Long long_ = this.a.x().a("reschedule_needed");
    return (long_ != null && long_.longValue() == 1L);
  }
  
  public void c(boolean paramBoolean) {
    d d = new d("reschedule_needed", paramBoolean);
    this.a.x().b(d);
  }
}


/* Location:              C:\soft\dex2jar-2.0\Hill race-dex2jar.jar!\b0\e.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */