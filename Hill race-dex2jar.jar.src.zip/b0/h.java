package b0;

import androidx.work.WorkerParameters;
import t.i;

public class h implements Runnable {
  private i b;
  
  private String c;
  
  private WorkerParameters.a d;
  
  public h(i parami, String paramString, WorkerParameters.a parama) {
    this.b = parami;
    this.c = paramString;
    this.d = parama;
  }
  
  public void run() {
    this.b.m().k(this.c, this.d);
  }
}


/* Location:              C:\soft\dex2jar-2.0\Hill race-dex2jar.jar!\b0\h.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */