package b0;

import a0.p;
import a0.q;
import android.text.TextUtils;
import androidx.work.c;
import androidx.work.e;
import androidx.work.f;
import androidx.work.impl.WorkDatabase;
import androidx.work.impl.workers.ConstraintTrackingWorker;
import androidx.work.l;
import androidx.work.o;
import androidx.work.u;
import androidx.work.w;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Iterator;
import java.util.List;
import java.util.Set;
import t.c;
import t.e;
import t.f;
import t.g;
import t.i;

public class b implements Runnable {
  private static final String d = l.f("EnqueueRunnable");
  
  private final g b;
  
  private final c c;
  
  public b(g paramg) {
    this.b = paramg;
    this.c = new c();
  }
  
  private static boolean c(g paramg) {
    Set set = g.l(paramg);
    boolean bool = d(paramg.g(), paramg.f(), (String[])set.toArray((Object[])new String[0]), paramg.d(), paramg.b());
    paramg.k();
    return bool;
  }
  
  private static boolean d(i parami, List<? extends w> paramList, String[] paramArrayOfString, String paramString, f paramf) {
    boolean bool1;
    Iterator iterator2;
    long l = System.currentTimeMillis();
    WorkDatabase workDatabase = parami.o();
    if (paramArrayOfString != null && paramArrayOfString.length > 0) {
      n = 1;
    } else {
      n = 0;
    } 
    if (n) {
      bool1 = paramArrayOfString.length;
      int i7 = 0;
      int i6 = 1;
      boolean bool = false;
      byte b1 = 0;
      while (true) {
        m = i6;
        k = bool;
        j = b1;
        if (i7 < bool1) {
          String str = paramArrayOfString[i7];
          p p = workDatabase.B().n(str);
          if (p == null) {
            l.c().b(d, String.format("Prerequisite %s doesn't exist; not enqueuing", new Object[] { str }), new Throwable[0]);
            return false;
          } 
          u u = p.b;
          if (u == u.d) {
            j = 1;
          } else {
            j = 0;
          } 
          i6 &= j;
          if (u == u.e) {
            j = 1;
          } else {
            j = b1;
            if (u == u.g) {
              bool = true;
              j = b1;
            } 
          } 
          i7++;
          b1 = j;
          continue;
        } 
        break;
      } 
    } else {
      m = 1;
      k = 0;
      j = 0;
    } 
    int i5 = TextUtils.isEmpty(paramString) ^ true;
    if (i5 != 0 && !n) {
      bool1 = true;
    } else {
      bool1 = false;
    } 
    String[] arrayOfString = paramArrayOfString;
    int i1 = n;
    int i2 = m;
    int i3 = k;
    int i4 = j;
    if (bool1) {
      List list = workDatabase.B().e(paramString);
      arrayOfString = paramArrayOfString;
      i1 = n;
      i2 = m;
      i3 = k;
      i4 = j;
      if (!list.isEmpty()) {
        List<?> list1;
        if (paramf == f.d || paramf == f.e) {
          a0.b b1 = workDatabase.t();
          ArrayList<String> arrayList = new ArrayList();
          for (p.b b2 : list) {
            if (!b1.d(b2.a)) {
              u u = b2.b;
              if (u == u.d) {
                i1 = 1;
              } else {
                i1 = 0;
              } 
              if (u == u.e) {
                j = 1;
                n = k;
                k = j;
              } else {
                n = k;
                k = j;
                if (u == u.g) {
                  n = 1;
                  k = j;
                } 
              } 
              arrayList.add(b2.a);
              m = i1 & m;
              j = k;
            } else {
              n = k;
            } 
            k = n;
          } 
          if (paramf == f.e && (k != 0 || j != 0)) {
            q q = workDatabase.B();
            iterator2 = q.e(paramString).iterator();
            while (iterator2.hasNext())
              q.a(((p.b)iterator2.next()).a); 
            list1 = Collections.emptyList();
            j = 0;
            k = 0;
          } else {
            list1 = arrayList;
          } 
          String[] arrayOfString1 = list1.<String>toArray(paramArrayOfString);
          if (arrayOfString1.length > 0) {
            i1 = 1;
          } else {
            i1 = 0;
          } 
          i4 = j;
          i3 = k;
          i2 = m;
        } else {
          if (list1 == f.c) {
            Iterator iterator3 = list.iterator();
            while (iterator3.hasNext()) {
              u u = ((p.b)iterator3.next()).b;
              if (u == u.b || u == u.c)
                return false; 
            } 
          } 
          a.c(paramString, parami, false).run();
          q q = workDatabase.B();
          iterator2 = list.iterator();
          while (iterator2.hasNext())
            q.a(((p.b)iterator2.next()).a); 
          boolean bool = true;
          iterator = paramList.iterator();
        } 
      } 
    } 
    boolean bool2 = false;
    int j = i4;
    int k = i3;
    int m = i2;
    int n = i1;
    Iterator iterator1 = iterator2;
    Iterator<? extends w> iterator = iterator.iterator();
  }
  
  private static boolean f(g paramg) {
    List list = paramg.e();
    boolean bool = false;
    if (list != null) {
      Iterator<g> iterator = list.iterator();
      bool = false;
      while (iterator.hasNext()) {
        g g1 = iterator.next();
        if (!g1.j()) {
          bool |= f(g1);
          continue;
        } 
        l.c().h(d, String.format("Already enqueued work ids (%s).", new Object[] { TextUtils.join(", ", g1.c()) }), new Throwable[0]);
      } 
    } 
    return c(paramg) | bool;
  }
  
  private static void h(p paramp) {
    c c1 = paramp.j;
    String str = paramp.c;
    if (!str.equals(ConstraintTrackingWorker.class.getName()) && (c1.f() || c1.i())) {
      e.a a = new e.a();
      a.c(paramp.e).e("androidx.work.impl.workers.ConstraintTrackingWorker.ARGUMENT_CLASS_NAME", str);
      paramp.c = ConstraintTrackingWorker.class.getName();
      paramp.e = a.a();
    } 
  }
  
  private static boolean i(i parami, String paramString) {
    try {
      Class<?> clazz = Class.forName(paramString);
      Iterator<e> iterator = parami.n().iterator();
      while (iterator.hasNext()) {
        boolean bool = clazz.isAssignableFrom(((e)iterator.next()).getClass());
        if (bool)
          return true; 
      } 
      return false;
    } catch (ClassNotFoundException classNotFoundException) {
      return false;
    } 
  }
  
  public boolean b() {
    WorkDatabase workDatabase = this.b.g().o();
    workDatabase.c();
    try {
      boolean bool = f(this.b);
      workDatabase.r();
      return bool;
    } finally {
      workDatabase.g();
    } 
  }
  
  public o e() {
    return (o)this.c;
  }
  
  public void g() {
    i i = this.b.g();
    f.b(i.i(), i.o(), i.n());
  }
  
  public void run() {
    try {
      if (!this.b.h())
        return; 
      throw new IllegalStateException(String.format("WorkContinuation has cycles (%s)", new Object[] { this.b }));
    } finally {
      Exception exception = null;
      this.c.a((o.b)new o.b.a(exception));
    } 
  }
}


/* Location:              C:\soft\dex2jar-2.0\Hill race-dex2jar.jar!\b0\b.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */