package b0;

import a0.q;
import androidx.work.impl.WorkDatabase;
import androidx.work.l;
import androidx.work.u;
import t.d;

public class i implements Runnable {
  private static final String e = l.f("StopWorkRunnable");
  
  private final t.i b;
  
  private final String c;
  
  private final boolean d;
  
  public i(t.i parami, String paramString, boolean paramBoolean) {
    this.b = parami;
    this.c = paramString;
    this.d = paramBoolean;
  }
  
  public void run() {
    WorkDatabase workDatabase = this.b.o();
    null = this.b.m();
    q q = workDatabase.B();
    workDatabase.c();
    try {
      boolean bool = null.h(this.c);
      if (this.d) {
        bool = this.b.m().n(this.c);
      } else {
        if (!bool && q.m(this.c) == u.c)
          q.c(u.b, new String[] { this.c }); 
        bool = this.b.m().o(this.c);
      } 
      l.c().a(e, String.format("StopWorkRunnable for %s; Processor.stopWork = %s", new Object[] { this.c, Boolean.valueOf(bool) }), new Throwable[0]);
      workDatabase.r();
      return;
    } finally {
      workDatabase.g();
    } 
  }
}


/* Location:              C:\soft\dex2jar-2.0\Hill race-dex2jar.jar!\b0\i.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */