package b0;

import a0.q;
import android.content.Context;
import androidx.work.g;
import androidx.work.h;
import androidx.work.impl.WorkDatabase;
import androidx.work.impl.utils.futures.c;
import com.google.common.util.concurrent.ListenableFuture;
import java.util.UUID;

public class l implements h {
  private static final String d = androidx.work.l.f("WMFgUpdater");
  
  private final c0.a a;
  
  final z.a b;
  
  final q c;
  
  public l(WorkDatabase paramWorkDatabase, z.a parama, c0.a parama1) {
    this.b = parama;
    this.a = parama1;
    this.c = paramWorkDatabase.B();
  }
  
  public ListenableFuture<Void> a(Context paramContext, UUID paramUUID, g paramg) {
    c c = c.s();
    this.a.b(new a(this, c, paramUUID, paramg, paramContext));
    return (ListenableFuture<Void>)c;
  }
  
  class a implements Runnable {
    a(l this$0, c param1c, UUID param1UUID, g param1g, Context param1Context) {}
    
    public void run() {
      try {
        return;
      } finally {
        Exception exception = null;
        this.b.p(exception);
      } 
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Hill race-dex2jar.jar!\b0\l.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */