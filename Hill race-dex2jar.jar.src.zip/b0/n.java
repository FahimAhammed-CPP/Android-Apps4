package b0;

import androidx.work.l;
import java.util.HashMap;
import java.util.Map;
import java.util.concurrent.Executors;
import java.util.concurrent.ScheduledExecutorService;
import java.util.concurrent.ThreadFactory;
import java.util.concurrent.TimeUnit;

public class n {
  private static final String f = l.f("WorkTimer");
  
  private final ThreadFactory a;
  
  private final ScheduledExecutorService b;
  
  final Map<String, c> c;
  
  final Map<String, b> d;
  
  final Object e;
  
  public n() {
    a a = new a(this);
    this.a = a;
    this.c = new HashMap<String, c>();
    this.d = new HashMap<String, b>();
    this.e = new Object();
    this.b = Executors.newSingleThreadScheduledExecutor(a);
  }
  
  public void a() {
    if (!this.b.isShutdown())
      this.b.shutdownNow(); 
  }
  
  public void b(String paramString, long paramLong, b paramb) {
    synchronized (this.e) {
      l.c().a(f, String.format("Starting timer for %s", new Object[] { paramString }), new Throwable[0]);
      c(paramString);
      c c = new c(this, paramString);
      this.c.put(paramString, c);
      this.d.put(paramString, paramb);
      this.b.schedule(c, paramLong, TimeUnit.MILLISECONDS);
      return;
    } 
  }
  
  public void c(String paramString) {
    synchronized (this.e) {
      if ((c)this.c.remove(paramString) != null) {
        l.c().a(f, String.format("Stopping timer for %s", new Object[] { paramString }), new Throwable[0]);
        this.d.remove(paramString);
      } 
      return;
    } 
  }
  
  class a implements ThreadFactory {
    private int a = 0;
    
    a(n this$0) {}
    
    public Thread newThread(Runnable param1Runnable) {
      param1Runnable = Executors.defaultThreadFactory().newThread(param1Runnable);
      StringBuilder stringBuilder = new StringBuilder();
      stringBuilder.append("WorkManager-WorkTimer-thread-");
      stringBuilder.append(this.a);
      param1Runnable.setName(stringBuilder.toString());
      this.a++;
      return (Thread)param1Runnable;
    }
  }
  
  public static interface b {
    void a(String param1String);
  }
  
  public static class c implements Runnable {
    private final n b;
    
    private final String c;
    
    c(n param1n, String param1String) {
      this.b = param1n;
      this.c = param1String;
    }
    
    public void run() {
      synchronized (this.b.e) {
        if ((c)this.b.c.remove(this.c) != null) {
          n.b b = this.b.d.remove(this.c);
          if (b != null)
            b.a(this.c); 
        } else {
          l.c().a("WrkTimerRunnable", String.format("Timer with %s is already marked as complete.", new Object[] { this.c }), new Throwable[0]);
        } 
        return;
      } 
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Hill race-dex2jar.jar!\b0\n.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */