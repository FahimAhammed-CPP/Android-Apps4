package b0;

import a0.d;
import android.content.Context;
import android.content.SharedPreferences;
import androidx.work.impl.WorkDatabase;
import m.b;

public class c {
  private final WorkDatabase a;
  
  public c(WorkDatabase paramWorkDatabase) {
    this.a = paramWorkDatabase;
  }
  
  public static void a(Context paramContext, b paramb) {
    SharedPreferences sharedPreferences = paramContext.getSharedPreferences("androidx.work.util.id", 0);
    if (sharedPreferences.contains("next_job_scheduler_id") || sharedPreferences.contains("next_job_scheduler_id")) {
      int i = sharedPreferences.getInt("next_job_scheduler_id", 0);
      int j = sharedPreferences.getInt("next_alarm_manager_id", 0);
      paramb.D();
      try {
        paramb.S("INSERT OR REPLACE INTO `Preference` (`key`, `long_value`) VALUES (@key, @long_value)", new Object[] { "next_job_scheduler_id", Integer.valueOf(i) });
        paramb.S("INSERT OR REPLACE INTO `Preference` (`key`, `long_value`) VALUES (@key, @long_value)", new Object[] { "next_alarm_manager_id", Integer.valueOf(j) });
        sharedPreferences.edit().clear().apply();
        paramb.Q();
        return;
      } finally {
        paramb.Y();
      } 
    } 
  }
  
  private int c(String paramString) {
    byte b;
    int i;
    this.a.c();
    try {
      Long long_ = this.a.x().a(paramString);
      i = 0;
    } finally {
      this.a.g();
    } 
    if (b != Integer.MAX_VALUE)
      i = b + 1; 
    e(paramString, i);
    this.a.r();
    this.a.g();
    return b;
  }
  
  private void e(String paramString, int paramInt) {
    this.a.x().b(new d(paramString, paramInt));
  }
  
  public int b() {
    // Byte code:
    //   0: ldc b0/c
    //   2: monitorenter
    //   3: aload_0
    //   4: ldc 'next_alarm_manager_id'
    //   6: invokespecial c : (Ljava/lang/String;)I
    //   9: istore_1
    //   10: ldc b0/c
    //   12: monitorexit
    //   13: iload_1
    //   14: ireturn
    //   15: astore_2
    //   16: ldc b0/c
    //   18: monitorexit
    //   19: aload_2
    //   20: athrow
    // Exception table:
    //   from	to	target	type
    //   3	13	15	finally
    //   16	19	15	finally
  }
  
  public int d(int paramInt1, int paramInt2) {
    // Byte code:
    //   0: ldc b0/c
    //   2: monitorenter
    //   3: aload_0
    //   4: ldc 'next_job_scheduler_id'
    //   6: invokespecial c : (Ljava/lang/String;)I
    //   9: istore_3
    //   10: iload_3
    //   11: iload_1
    //   12: if_icmplt -> 23
    //   15: iload_3
    //   16: iload_2
    //   17: if_icmple -> 45
    //   20: goto -> 23
    //   23: aload_0
    //   24: ldc 'next_job_scheduler_id'
    //   26: iload_1
    //   27: iconst_1
    //   28: iadd
    //   29: invokespecial e : (Ljava/lang/String;I)V
    //   32: ldc b0/c
    //   34: monitorexit
    //   35: iload_1
    //   36: ireturn
    //   37: astore #4
    //   39: ldc b0/c
    //   41: monitorexit
    //   42: aload #4
    //   44: athrow
    //   45: iload_3
    //   46: istore_1
    //   47: goto -> 32
    // Exception table:
    //   from	to	target	type
    //   3	10	37	finally
    //   23	32	37	finally
    //   32	35	37	finally
    //   39	42	37	finally
  }
}


/* Location:              C:\soft\dex2jar-2.0\Hill race-dex2jar.jar!\b0\c.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */