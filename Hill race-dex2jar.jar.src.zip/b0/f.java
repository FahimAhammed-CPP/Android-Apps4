package b0;

import android.annotation.SuppressLint;
import android.app.ActivityManager;
import android.app.Application;
import android.content.Context;
import android.os.Build;
import android.os.Process;
import android.text.TextUtils;
import androidx.work.b;
import androidx.work.l;
import java.lang.reflect.Method;
import java.util.List;

public class f {
  private static final String a = l.f("ProcessUtils");
  
  @SuppressLint({"PrivateApi", "DiscouragedPrivateApi"})
  public static String a(Context paramContext) {
    int i = Build.VERSION.SDK_INT;
    if (i >= 28)
      return Application.getProcessName(); 
    try {
      Object object;
      Class<?> clazz = Class.forName("android.app.ActivityThread", false, f.class.getClassLoader());
      if (i >= 18) {
        Method method = clazz.getDeclaredMethod("currentProcessName", new Class[0]);
        method.setAccessible(true);
        object = method.invoke(null, new Object[0]);
      } else {
        Method method1 = clazz.getDeclaredMethod("currentActivityThread", new Class[0]);
        method1.setAccessible(true);
        Method method2 = clazz.getDeclaredMethod("getProcessName", new Class[0]);
        method2.setAccessible(true);
        object = method2.invoke(method1.invoke(null, new Object[0]), new Object[0]);
      } 
    } finally {
      Exception exception = null;
    } 
    i = Process.myPid();
    ActivityManager activityManager = (ActivityManager)paramContext.getSystemService("activity");
    if (activityManager != null) {
      List list = activityManager.getRunningAppProcesses();
      if (list != null && !list.isEmpty())
        for (ActivityManager.RunningAppProcessInfo runningAppProcessInfo : list) {
          if (runningAppProcessInfo.pid == i)
            return runningAppProcessInfo.processName; 
        }  
    } 
    return null;
  }
  
  public static boolean b(Context paramContext, b paramb) {
    String str = a(paramContext);
    return !TextUtils.isEmpty(paramb.c()) ? TextUtils.equals(str, paramb.c()) : TextUtils.equals(str, (paramContext.getApplicationInfo()).processName);
  }
}


/* Location:              C:\soft\dex2jar-2.0\Hill race-dex2jar.jar!\b0\f.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */