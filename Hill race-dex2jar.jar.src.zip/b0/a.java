package b0;

import a0.q;
import androidx.work.impl.WorkDatabase;
import androidx.work.o;
import androidx.work.u;
import java.util.Iterator;
import java.util.LinkedList;
import java.util.UUID;
import t.e;
import t.f;
import t.i;

public abstract class a implements Runnable {
  private final t.c b = new t.c();
  
  public static a b(UUID paramUUID, i parami) {
    return new a(parami, paramUUID);
  }
  
  public static a c(String paramString, i parami, boolean paramBoolean) {
    return new c(parami, paramString, paramBoolean);
  }
  
  public static a d(String paramString, i parami) {
    return new b(parami, paramString);
  }
  
  private void f(WorkDatabase paramWorkDatabase, String paramString) {
    q q = paramWorkDatabase.B();
    a0.b b = paramWorkDatabase.t();
    LinkedList<String> linkedList = new LinkedList();
    linkedList.add(paramString);
    while (!linkedList.isEmpty()) {
      paramString = linkedList.remove();
      u u = q.m(paramString);
      if (u != u.d && u != u.e)
        q.c(u.g, new String[] { paramString }); 
      linkedList.addAll(b.b(paramString));
    } 
  }
  
  void a(i parami, String paramString) {
    f(parami.o(), paramString);
    parami.m().l(paramString);
    Iterator<e> iterator = parami.n().iterator();
    while (iterator.hasNext())
      ((e)iterator.next()).d(paramString); 
  }
  
  public o e() {
    return (o)this.b;
  }
  
  void g(i parami) {
    f.b(parami.i(), parami.o(), parami.n());
  }
  
  abstract void h();
  
  public void run() {
    try {
      return;
    } finally {
      Exception exception = null;
      this.b.a((o.b)new o.b.a(exception));
    } 
  }
  
  class a extends a {
    a(a this$0, UUID param1UUID) {}
    
    void h() {
      WorkDatabase workDatabase = this.c.o();
      workDatabase.c();
      try {
        a(this.c, this.d.toString());
        workDatabase.r();
        workDatabase.g();
        return;
      } finally {
        workDatabase.g();
      } 
    }
  }
  
  class b extends a {
    b(a this$0, String param1String) {}
    
    void h() {
      WorkDatabase workDatabase = this.c.o();
      workDatabase.c();
      try {
        for (String str : workDatabase.B().p(this.d))
          a(this.c, str); 
        workDatabase.r();
        workDatabase.g();
        return;
      } finally {
        workDatabase.g();
      } 
    }
  }
  
  class c extends a {
    c(a this$0, String param1String, boolean param1Boolean) {}
    
    void h() {
      WorkDatabase workDatabase = this.c.o();
      workDatabase.c();
      try {
        for (String str : workDatabase.B().l(this.d))
          a(this.c, str); 
        workDatabase.r();
        workDatabase.g();
        return;
      } finally {
        workDatabase.g();
      } 
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Hill race-dex2jar.jar!\b0\a.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */