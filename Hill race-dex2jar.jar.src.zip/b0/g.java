package b0;

import java.util.ArrayDeque;
import java.util.concurrent.Executor;

public class g implements Executor {
  private final ArrayDeque<a> b;
  
  private final Executor c;
  
  private final Object d;
  
  private volatile Runnable e;
  
  public g(Executor paramExecutor) {
    this.c = paramExecutor;
    this.b = new ArrayDeque<a>();
    this.d = new Object();
  }
  
  public boolean a() {
    synchronized (this.d) {
      if (!this.b.isEmpty())
        return true; 
    } 
    boolean bool = false;
    /* monitor exit ClassFileLocalVariableReferenceExpression{type=ObjectType{java/lang/Object}, name=SYNTHETIC_LOCAL_VARIABLE_2} */
    return bool;
  }
  
  void b() {
    synchronized (this.d) {
      Runnable runnable = this.b.poll();
      this.e = runnable;
      if (runnable != null)
        this.c.execute(this.e); 
      return;
    } 
  }
  
  public void execute(Runnable paramRunnable) {
    synchronized (this.d) {
      this.b.add(new a(this, paramRunnable));
      if (this.e == null)
        b(); 
      return;
    } 
  }
  
  static class a implements Runnable {
    final g b;
    
    final Runnable c;
    
    a(g param1g, Runnable param1Runnable) {
      this.b = param1g;
      this.c = param1Runnable;
    }
    
    public void run() {
      try {
        this.c.run();
        return;
      } finally {
        this.b.b();
      } 
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Hill race-dex2jar.jar!\b0\g.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */