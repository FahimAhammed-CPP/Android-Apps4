package b0;

import a0.p;
import android.annotation.SuppressLint;
import android.content.Context;
import androidx.work.ListenableWorker;
import androidx.work.g;
import androidx.work.h;
import androidx.work.impl.utils.futures.c;
import androidx.work.l;
import com.google.common.util.concurrent.ListenableFuture;

public class k implements Runnable {
  static final String h = l.f("WorkForegroundRunnable");
  
  final c<Void> b = c.s();
  
  final Context c;
  
  final p d;
  
  final ListenableWorker e;
  
  final h f;
  
  final c0.a g;
  
  @SuppressLint({"LambdaLast"})
  public k(Context paramContext, p paramp, ListenableWorker paramListenableWorker, h paramh, c0.a parama) {
    this.c = paramContext;
    this.d = paramp;
    this.e = paramListenableWorker;
    this.f = paramh;
    this.g = parama;
  }
  
  public ListenableFuture<Void> b() {
    return (ListenableFuture<Void>)this.b;
  }
  
  @SuppressLint({"UnsafeExperimentalUsageError"})
  public void run() {
    if (!this.d.q || androidx.core.os.a.b()) {
      this.b.o(null);
      return;
    } 
    c c1 = c.s();
    this.g.a().execute(new a(this, c1));
    c1.addListener(new b(this, c1), this.g.a());
  }
  
  class a implements Runnable {
    a(k this$0, c param1c) {}
    
    public void run() {
      this.b.q(this.c.e.getForegroundInfoAsync());
    }
  }
  
  class b implements Runnable {
    b(k this$0, c param1c) {}
    
    public void run() {
      try {
        g g = (g)this.b.get();
        if (g != null) {
          l.c().a(k.h, String.format("Updating notification for %s", new Object[] { this.c.d.c }), new Throwable[0]);
          this.c.e.setRunInForeground(true);
          return;
        } 
        throw new IllegalStateException(String.format("Worker was marked important (%s) but did not provide ForegroundInfo", new Object[] { this.c.d.c }));
      } finally {
        Exception exception = null;
        this.c.b.p(exception);
      } 
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Hill race-dex2jar.jar!\b0\k.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */