package c1;

import android.view.View;
import android.webkit.WebView;
import com.iab.omid.library.vungle.Omid;
import com.iab.omid.library.vungle.adsession.AdSession;
import com.iab.omid.library.vungle.adsession.AdSessionConfiguration;
import com.iab.omid.library.vungle.adsession.AdSessionContext;
import com.iab.omid.library.vungle.adsession.CreativeType;
import com.iab.omid.library.vungle.adsession.ImpressionType;
import com.iab.omid.library.vungle.adsession.Owner;
import com.iab.omid.library.vungle.adsession.Partner;
import java.util.concurrent.TimeUnit;
import u1.j;
import u1.r;

public final class c implements d {
  public static final a Companion = new a(null);
  
  private static final long DESTROY_DELAY_MS = TimeUnit.SECONDS.toMillis(1L);
  
  private AdSession adSession;
  
  private final boolean enabled;
  
  private boolean started;
  
  private c(boolean paramBoolean) {
    this.enabled = paramBoolean;
  }
  
  public void onPageFinished(WebView paramWebView) {
    r.e(paramWebView, "webView");
    if (this.started && this.adSession == null) {
      CreativeType creativeType = CreativeType.DEFINED_BY_JAVASCRIPT;
      ImpressionType impressionType = ImpressionType.DEFINED_BY_JAVASCRIPT;
      Owner owner = Owner.JAVASCRIPT;
      AdSession adSession2 = AdSession.createAdSession(AdSessionConfiguration.createAdSessionConfiguration(creativeType, impressionType, owner, owner, false), AdSessionContext.createHtmlAdSessionContext(Partner.createPartner("Vungle", "7.0.0"), paramWebView, null, null));
      this.adSession = adSession2;
      if (adSession2 != null)
        adSession2.registerAdView((View)paramWebView); 
      AdSession adSession1 = this.adSession;
      if (adSession1 != null)
        adSession1.start(); 
    } 
  }
  
  public final void start() {
    if (this.enabled && Omid.isActive())
      this.started = true; 
  }
  
  public final long stop() {
    if (this.started) {
      AdSession adSession = this.adSession;
      if (adSession != null) {
        if (adSession != null)
          adSession.finish(); 
        long l1 = DESTROY_DELAY_MS;
        this.started = false;
        this.adSession = null;
        return l1;
      } 
    } 
    long l = 0L;
    this.started = false;
    this.adSession = null;
    return l;
  }
  
  public static final class a {
    private a() {}
    
    public final long getDESTROY_DELAY_MS() {
      return c.DESTROY_DELAY_MS;
    }
  }
  
  public static final class b {
    public final c make(boolean param1Boolean) {
      return new c(param1Boolean, null);
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Hill race-dex2jar.jar!\c1\c.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */