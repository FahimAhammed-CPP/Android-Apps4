package c1;

import android.webkit.WebView;

public interface d {
  void onPageFinished(WebView paramWebView);
}


/* Location:              C:\soft\dex2jar-2.0\Hill race-dex2jar.jar!\c1\d.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */