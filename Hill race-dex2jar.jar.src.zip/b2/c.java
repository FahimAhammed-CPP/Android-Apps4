package b2;

public interface c<T> extends d<T> {
  d<T> a(int paramInt);
}


/* Location:              C:\soft\dex2jar-2.0\Hill race-dex2jar.jar!\b2\c.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */