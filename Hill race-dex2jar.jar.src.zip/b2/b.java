package b2;

import java.util.Iterator;

public final class b<T> implements d<T>, c<T> {
  private final d<T> a;
  
  private final int b;
  
  public b(d<? extends T> paramd, int paramInt) {
    boolean bool;
    this.a = (d)paramd;
    this.b = paramInt;
    if (paramInt >= 0) {
      bool = true;
    } else {
      bool = false;
    } 
    if (bool)
      return; 
    StringBuilder stringBuilder = new StringBuilder();
    stringBuilder.append("count must be non-negative, but was ");
    stringBuilder.append(paramInt);
    stringBuilder.append('.');
    throw new IllegalArgumentException(stringBuilder.toString().toString());
  }
  
  public d<T> a(int paramInt) {
    int i = this.b + paramInt;
    return (i < 0) ? new b(this, paramInt) : new b(this.a, i);
  }
  
  public Iterator<T> iterator() {
    return new a(this);
  }
  
  public static final class a implements Iterator<T>, v1.a {
    private final Iterator<T> b;
    
    private int c;
    
    a(b<T> param1b) {
      this.b = b.c(param1b).iterator();
      this.c = b.b(param1b);
    }
    
    private final void a() {
      while (this.c > 0 && this.b.hasNext()) {
        this.b.next();
        this.c--;
      } 
    }
    
    public boolean hasNext() {
      a();
      return this.b.hasNext();
    }
    
    public T next() {
      a();
      return this.b.next();
    }
    
    public void remove() {
      throw new UnsupportedOperationException("Operation is not supported for read-only collection");
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Hill race-dex2jar.jar!\b2\b.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */