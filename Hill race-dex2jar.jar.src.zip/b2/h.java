package b2;

import java.util.Iterator;
import u1.r;

class h extends g {
  public static <T> d<T> a(Iterator<? extends T> paramIterator) {
    r.e(paramIterator, "<this>");
    return b(new a(paramIterator));
  }
  
  public static final <T> d<T> b(d<? extends T> paramd) {
    r.e(paramd, "<this>");
    return (paramd instanceof a) ? paramd : new a<T>(paramd);
  }
  
  public static final class a implements d<T> {
    public a(Iterator param1Iterator) {}
    
    public Iterator<T> iterator() {
      return this.a;
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Hill race-dex2jar.jar!\b2\h.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */