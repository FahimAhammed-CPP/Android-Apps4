package b2;

import java.util.Iterator;
import t1.l;

public final class k<T, R> implements d<R> {
  private final d<T> a;
  
  private final l<T, R> b;
  
  public k(d<? extends T> paramd, l<? super T, ? extends R> paraml) {
    this.a = (d)paramd;
    this.b = (l)paraml;
  }
  
  public Iterator<R> iterator() {
    return new a(this);
  }
  
  public static final class a implements Iterator<R>, v1.a {
    private final Iterator<T> b;
    
    a(k<T, R> param1k) {
      this.b = k.b(param1k).iterator();
    }
    
    public boolean hasNext() {
      return this.b.hasNext();
    }
    
    public R next() {
      return (R)k.c(this.c).invoke(this.b.next());
    }
    
    public void remove() {
      throw new UnsupportedOperationException("Operation is not supported for read-only collection");
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Hill race-dex2jar.jar!\b2\k.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */