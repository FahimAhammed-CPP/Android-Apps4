package b2;

import java.util.Iterator;
import java.util.concurrent.atomic.AtomicReference;

public final class a<T> implements d<T> {
  private final AtomicReference<d<T>> a;
  
  public a(d<? extends T> paramd) {
    this.a = (AtomicReference)new AtomicReference<d<? extends T>>(paramd);
  }
  
  public Iterator<T> iterator() {
    d<T> d1 = this.a.getAndSet(null);
    if (d1 != null)
      return d1.iterator(); 
    throw new IllegalStateException("This sequence can be consumed only once.");
  }
}


/* Location:              C:\soft\dex2jar-2.0\Hill race-dex2jar.jar!\b2\a.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */