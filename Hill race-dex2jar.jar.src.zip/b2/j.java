package b2;

import c2.h;
import j1.o;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import t1.l;
import u1.r;

class j extends i {
  public static <T> Iterable<T> c(d<? extends T> paramd) {
    r.e(paramd, "<this>");
    return new a(paramd);
  }
  
  public static <T> d<T> d(d<? extends T> paramd, int paramInt) {
    boolean bool;
    r.e(paramd, "<this>");
    if (paramInt >= 0) {
      bool = true;
    } else {
      bool = false;
    } 
    if (bool)
      return (paramInt == 0) ? paramd : ((paramd instanceof c) ? ((c)paramd).a(paramInt) : new b<T>(paramd, paramInt)); 
    StringBuilder stringBuilder = new StringBuilder();
    stringBuilder.append("Requested element count ");
    stringBuilder.append(paramInt);
    stringBuilder.append(" is less than zero.");
    throw new IllegalArgumentException(stringBuilder.toString().toString());
  }
  
  public static final <T, A extends Appendable> A e(d<? extends T> paramd, A paramA, CharSequence paramCharSequence1, CharSequence paramCharSequence2, CharSequence paramCharSequence3, int paramInt, CharSequence paramCharSequence4, l<? super T, ? extends CharSequence> paraml) {
    int m;
    r.e(paramd, "<this>");
    r.e(paramA, "buffer");
    r.e(paramCharSequence1, "separator");
    r.e(paramCharSequence2, "prefix");
    r.e(paramCharSequence3, "postfix");
    r.e(paramCharSequence4, "truncated");
    paramA.append(paramCharSequence2);
    Iterator<? extends T> iterator = paramd.iterator();
    int k = 0;
    while (true) {
      m = k;
      if (iterator.hasNext()) {
        paramCharSequence2 = (CharSequence)iterator.next();
        if (++k > 1)
          paramA.append(paramCharSequence1); 
        if (paramInt >= 0) {
          m = k;
          if (k <= paramInt)
            continue; 
          break;
        } 
        continue;
      } 
      break;
      h.a((Appendable)paramA, paramCharSequence2, paraml);
    } 
    if (paramInt >= 0 && m > paramInt)
      paramA.append(paramCharSequence4); 
    paramA.append(paramCharSequence3);
    return paramA;
  }
  
  public static final <T> String f(d<? extends T> paramd, CharSequence paramCharSequence1, CharSequence paramCharSequence2, CharSequence paramCharSequence3, int paramInt, CharSequence paramCharSequence4, l<? super T, ? extends CharSequence> paraml) {
    r.e(paramd, "<this>");
    r.e(paramCharSequence1, "separator");
    r.e(paramCharSequence2, "prefix");
    r.e(paramCharSequence3, "postfix");
    r.e(paramCharSequence4, "truncated");
    String str = ((StringBuilder)e(paramd, new StringBuilder(), paramCharSequence1, paramCharSequence2, paramCharSequence3, paramInt, paramCharSequence4, paraml)).toString();
    r.d(str, "joinTo(StringBuilder(), …ed, transform).toString()");
    return str;
  }
  
  public static <T, R> d<R> h(d<? extends T> paramd, l<? super T, ? extends R> paraml) {
    r.e(paramd, "<this>");
    r.e(paraml, "transform");
    return new k<R, R>(paramd, paraml);
  }
  
  public static final <T, C extends java.util.Collection<? super T>> C i(d<? extends T> paramd, C paramC) {
    r.e(paramd, "<this>");
    r.e(paramC, "destination");
    Iterator<? extends T> iterator = paramd.iterator();
    while (iterator.hasNext())
      paramC.add(iterator.next()); 
    return paramC;
  }
  
  public static <T> List<T> j(d<? extends T> paramd) {
    r.e(paramd, "<this>");
    return o.k(k(paramd));
  }
  
  public static final <T> List<T> k(d<? extends T> paramd) {
    r.e(paramd, "<this>");
    return i(paramd, new ArrayList<T>());
  }
  
  public static final class a implements Iterable<T>, v1.a {
    public a(d param1d) {}
    
    public Iterator<T> iterator() {
      return this.b.iterator();
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Hill race-dex2jar.jar!\b2\j.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */