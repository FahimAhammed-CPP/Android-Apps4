package b2;

class g extends f {}


/* Location:              C:\soft\dex2jar-2.0\Hill race-dex2jar.jar!\b2\g.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */