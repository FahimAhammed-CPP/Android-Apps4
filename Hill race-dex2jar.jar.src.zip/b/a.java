package b;

import java.util.concurrent.Executor;

public class a extends c {
  private static volatile a c;
  
  private static final Executor d = new a();
  
  private static final Executor e = new b();
  
  private c a;
  
  private c b;
  
  private a() {
    b b = new b();
    this.b = b;
    this.a = b;
  }
  
  public static Executor d() {
    return e;
  }
  
  public static a e() {
    // Byte code:
    //   0: getstatic b/a.c : Lb/a;
    //   3: ifnull -> 10
    //   6: getstatic b/a.c : Lb/a;
    //   9: areturn
    //   10: ldc b/a
    //   12: monitorenter
    //   13: getstatic b/a.c : Lb/a;
    //   16: ifnonnull -> 29
    //   19: new b/a
    //   22: dup
    //   23: invokespecial <init> : ()V
    //   26: putstatic b/a.c : Lb/a;
    //   29: ldc b/a
    //   31: monitorexit
    //   32: getstatic b/a.c : Lb/a;
    //   35: areturn
    //   36: astore_0
    //   37: ldc b/a
    //   39: monitorexit
    //   40: aload_0
    //   41: athrow
    // Exception table:
    //   from	to	target	type
    //   13	29	36	finally
    //   29	32	36	finally
    //   37	40	36	finally
  }
  
  public void a(Runnable paramRunnable) {
    this.a.a(paramRunnable);
  }
  
  public boolean b() {
    return this.a.b();
  }
  
  public void c(Runnable paramRunnable) {
    this.a.c(paramRunnable);
  }
  
  static final class a implements Executor {
    public void execute(Runnable param1Runnable) {
      a.e().c(param1Runnable);
    }
  }
  
  static final class b implements Executor {
    public void execute(Runnable param1Runnable) {
      a.e().a(param1Runnable);
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Hill race-dex2jar.jar!\b\a.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */