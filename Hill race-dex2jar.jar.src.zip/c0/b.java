package c0;

import android.os.Handler;
import android.os.Looper;
import b0.g;
import java.util.concurrent.Executor;

public class b implements a {
  private final g a;
  
  private final Handler b = new Handler(Looper.getMainLooper());
  
  private final Executor c = new a(this);
  
  public b(Executor paramExecutor) {
    this.a = new g(paramExecutor);
  }
  
  public Executor a() {
    return this.c;
  }
  
  public void b(Runnable paramRunnable) {
    this.a.execute(paramRunnable);
  }
  
  public void c(Runnable paramRunnable) {
    this.b.post(paramRunnable);
  }
  
  public g getBackgroundExecutor() {
    return this.a;
  }
  
  class a implements Executor {
    a(b this$0) {}
    
    public void execute(Runnable param1Runnable) {
      this.b.c(param1Runnable);
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Hill race-dex2jar.jar!\c0\b.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */