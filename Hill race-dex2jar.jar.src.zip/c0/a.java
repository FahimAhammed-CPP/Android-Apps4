package c0;

import b0.g;
import java.util.concurrent.Executor;

public interface a {
  Executor a();
  
  void b(Runnable paramRunnable);
  
  g getBackgroundExecutor();
}


/* Location:              C:\soft\dex2jar-2.0\Hill race-dex2jar.jar!\c0\a.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */