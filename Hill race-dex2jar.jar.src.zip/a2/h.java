package a2;

import java.util.List;

public interface h {
  boolean a();
  
  List<i> b();
  
  c c();
}


/* Location:              C:\soft\dex2jar-2.0\Hill race-dex2jar.jar!\a2\h.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */