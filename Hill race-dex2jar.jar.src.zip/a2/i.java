package a2;

import i1.p;
import u1.j;
import u1.r;

public final class i {
  public static final a c = new a(null);
  
  public static final i d = new i(null, null);
  
  private final j a;
  
  private final h b;
  
  public i(j paramj, h paramh) {
    boolean bool1;
    boolean bool2;
    this.a = paramj;
    this.b = paramh;
    boolean bool3 = true;
    if (paramj == null) {
      bool1 = true;
    } else {
      bool1 = false;
    } 
    if (paramh == null) {
      bool2 = true;
    } else {
      bool2 = false;
    } 
    if (bool1 == bool2) {
      bool1 = bool3;
    } else {
      bool1 = false;
    } 
    if (!bool1) {
      String str;
      if (paramj == null) {
        str = "Star projection must have no type specified.";
      } else {
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("The projection variance ");
        stringBuilder.append(str);
        stringBuilder.append(" requires type to be specified.");
        str = stringBuilder.toString();
      } 
      throw new IllegalArgumentException(str.toString());
    } 
  }
  
  public final h a() {
    return this.b;
  }
  
  public final j b() {
    return this.a;
  }
  
  public boolean equals(Object paramObject) {
    if (this == paramObject)
      return true; 
    if (!(paramObject instanceof i))
      return false; 
    paramObject = paramObject;
    return (this.a != ((i)paramObject).a) ? false : (!!r.a(this.b, ((i)paramObject).b));
  }
  
  public int hashCode() {
    int k;
    j j1 = this.a;
    int m = 0;
    if (j1 == null) {
      k = 0;
    } else {
      k = j1.hashCode();
    } 
    h h1 = this.b;
    if (h1 != null)
      m = h1.hashCode(); 
    return k * 31 + m;
  }
  
  public String toString() {
    int k;
    j j1 = this.a;
    if (j1 == null) {
      k = -1;
    } else {
      k = b.a[j1.ordinal()];
    } 
    if (k != -1) {
      if (k != 1) {
        if (k != 2) {
          if (k == 3) {
            StringBuilder stringBuilder1 = new StringBuilder();
            stringBuilder1.append("out ");
            stringBuilder1.append(this.b);
            return stringBuilder1.toString();
          } 
          throw new p();
        } 
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("in ");
        stringBuilder.append(this.b);
        return stringBuilder.toString();
      } 
      return String.valueOf(this.b);
    } 
    return "*";
  }
  
  public static final class a {
    private a() {}
  }
}


/* Location:              C:\soft\dex2jar-2.0\Hill race-dex2jar.jar!\a2\i.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */