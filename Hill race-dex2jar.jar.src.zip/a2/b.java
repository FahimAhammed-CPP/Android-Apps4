package a2;

public interface b<T> extends d, c {
  String a();
}


/* Location:              C:\soft\dex2jar-2.0\Hill race-dex2jar.jar!\a2\b.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */