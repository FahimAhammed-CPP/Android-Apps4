package a2;

public interface g<V> extends a<V> {}


/* Location:              C:\soft\dex2jar-2.0\Hill race-dex2jar.jar!\a2\g.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */