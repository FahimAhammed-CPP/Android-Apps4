package a2;

import t1.a;

public interface f<V> extends g<V>, a<V> {
  V get();
}


/* Location:              C:\soft\dex2jar-2.0\Hill race-dex2jar.jar!\a2\f.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */