package com.adcolony.sdk;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

class c0 {
  private final JSONArray a;
  
  c0() {
    this(new JSONArray());
  }
  
  c0(String paramString) throws JSONException {
    this(new JSONArray(paramString));
  }
  
  c0(JSONArray paramJSONArray) throws NullPointerException {
    paramJSONArray.getClass();
    this.a = paramJSONArray;
  }
  
  c0 a(e0 parame0) {
    synchronized (this.a) {
      this.a.put(parame0.g());
      return this;
    } 
  }
  
  Object b(int paramInt) throws JSONException {
    return this.a.get(paramInt);
  }
  
  JSONArray c() {
    return this.a;
  }
  
  boolean d(String paramString) {
    // Byte code:
    //   0: aload_0
    //   1: getfield a : Lorg/json/JSONArray;
    //   4: astore #5
    //   6: aload #5
    //   8: monitorenter
    //   9: iconst_0
    //   10: istore #4
    //   12: iconst_0
    //   13: istore_2
    //   14: iload #4
    //   16: istore_3
    //   17: iload_2
    //   18: aload_0
    //   19: getfield a : Lorg/json/JSONArray;
    //   22: invokevirtual length : ()I
    //   25: if_icmpge -> 45
    //   28: aload_0
    //   29: iload_2
    //   30: invokevirtual j : (I)Ljava/lang/String;
    //   33: aload_1
    //   34: invokevirtual equals : (Ljava/lang/Object;)Z
    //   37: ifeq -> 56
    //   40: iconst_1
    //   41: istore_3
    //   42: goto -> 45
    //   45: aload #5
    //   47: monitorexit
    //   48: iload_3
    //   49: ireturn
    //   50: astore_1
    //   51: aload #5
    //   53: monitorexit
    //   54: aload_1
    //   55: athrow
    //   56: iload_2
    //   57: iconst_1
    //   58: iadd
    //   59: istore_2
    //   60: goto -> 14
    // Exception table:
    //   from	to	target	type
    //   17	40	50	finally
    //   45	48	50	finally
    //   51	54	50	finally
  }
  
  int e() {
    return this.a.length();
  }
  
  int f(int paramInt) throws JSONException {
    return this.a.getInt(paramInt);
  }
  
  c0 g(String paramString) {
    synchronized (this.a) {
      this.a.put(paramString);
      return this;
    } 
  }
  
  e0 h(int paramInt) {
    synchronized (this.a) {
      e0 e0;
      JSONObject jSONObject = this.a.optJSONObject(paramInt);
      if (jSONObject != null) {
        e0 = new e0(jSONObject);
      } else {
        e0 = new e0();
      } 
      return e0;
    } 
  }
  
  e0[] i() {
    synchronized (this.a) {
      e0[] arrayOfE0 = new e0[this.a.length()];
      for (int i = 0; i < this.a.length(); i++)
        arrayOfE0[i] = h(i); 
      return arrayOfE0;
    } 
  }
  
  String j(int paramInt) {
    synchronized (this.a) {
      return this.a.optString(paramInt);
    } 
  }
  
  String[] k() {
    synchronized (this.a) {
      String[] arrayOfString = new String[this.a.length()];
      for (int i = 0; i < this.a.length(); i++)
        arrayOfString[i] = j(i); 
      return arrayOfString;
    } 
  }
  
  String l(int paramInt) {
    synchronized (this.a) {
      if (!this.a.isNull(paramInt)) {
        Object object = this.a.opt(paramInt);
        if (object instanceof String) {
          object = object;
          return (String)object;
        } 
        if (object != null) {
          object = String.valueOf(object);
          return (String)object;
        } 
      } 
      return null;
    } 
  }
  
  c0 m(int paramInt) {
    synchronized (this.a) {
      this.a.put(paramInt);
      return this;
    } 
  }
  
  public String toString() {
    synchronized (this.a) {
      return this.a.toString();
    } 
  }
}


/* Location:              C:\soft\dex2jar-2.0\Hill race-dex2jar.jar!\com\adcolony\sdk\c0.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */