package com.adcolony.sdk;

import android.content.res.Configuration;
import android.os.Bundle;
import android.view.View;
import android.view.ViewGroup;
import android.view.ViewParent;

public class AdColonyAdViewActivity extends r {
  d k;
  
  public AdColonyAdViewActivity() {
    d d1;
    if (!q.k()) {
      d1 = null;
    } else {
      d1 = q.h().B0();
    } 
    this.k = d1;
  }
  
  void f() {
    ViewParent viewParent = this.b.getParent();
    if (viewParent != null)
      ((ViewGroup)viewParent).removeView((View)this.b); 
    this.k.b();
    q.h().y(null);
    finish();
  }
  
  void g() {
    this.k.d();
  }
  
  public void onBackPressed() {
    f();
  }
  
  public void onCreate(Bundle paramBundle) {
    if (q.k()) {
      d d1 = this.k;
      if (d1 != null) {
        this.c = d1.getOrientation();
        super.onCreate(paramBundle);
        this.k.d();
        e e = this.k.getListener();
        if (e != null)
          e.onOpened(this.k); 
        return;
      } 
    } 
    q.h().y(null);
    finish();
  }
}


/* Location:              C:\soft\dex2jar-2.0\Hill race-dex2jar.jar!\com\adcolony\sdk\AdColonyAdViewActivity.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */