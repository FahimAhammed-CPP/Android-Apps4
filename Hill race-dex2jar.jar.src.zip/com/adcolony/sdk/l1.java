package com.adcolony.sdk;

import android.content.ContentValues;
import android.content.Context;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteException;
import java.util.HashSet;
import java.util.Set;
import java.util.concurrent.Executor;
import java.util.concurrent.Executors;
import java.util.concurrent.RejectedExecutionException;

class l1 {
  private static l1 f;
  
  private final Executor a = Executors.newSingleThreadExecutor();
  
  private SQLiteDatabase b;
  
  private boolean c = false;
  
  private c d;
  
  private Set<String> e = new HashSet<String>();
  
  public static l1 b() {
    // Byte code:
    //   0: getstatic com/adcolony/sdk/l1.f : Lcom/adcolony/sdk/l1;
    //   3: ifnonnull -> 37
    //   6: ldc com/adcolony/sdk/l1
    //   8: monitorenter
    //   9: getstatic com/adcolony/sdk/l1.f : Lcom/adcolony/sdk/l1;
    //   12: ifnonnull -> 25
    //   15: new com/adcolony/sdk/l1
    //   18: dup
    //   19: invokespecial <init> : ()V
    //   22: putstatic com/adcolony/sdk/l1.f : Lcom/adcolony/sdk/l1;
    //   25: ldc com/adcolony/sdk/l1
    //   27: monitorexit
    //   28: goto -> 37
    //   31: astore_0
    //   32: ldc com/adcolony/sdk/l1
    //   34: monitorexit
    //   35: aload_0
    //   36: athrow
    //   37: getstatic com/adcolony/sdk/l1.f : Lcom/adcolony/sdk/l1;
    //   40: areturn
    // Exception table:
    //   from	to	target	type
    //   9	25	31	finally
    //   25	28	31	finally
    //   32	35	31	finally
  }
  
  private void e(w0 paramw0, q1<w0> paramq1, Context paramContext) {
    /* monitor enter ThisExpression{ObjectType{com/adcolony/sdk/l1}} */
    try {
      SQLiteDatabase sQLiteDatabase = this.b;
      boolean bool = false;
      if (sQLiteDatabase == null || !sQLiteDatabase.isOpen())
        this.b = paramContext.openOrCreateDatabase("adc_events_db", 0, null); 
      if (this.b.needUpgrade(paramw0.d())) {
        boolean bool1 = bool;
        if (j(paramw0)) {
          bool1 = bool;
          if (this.d != null)
            bool1 = true; 
        } 
        this.c = bool1;
        if (bool1)
          this.d.a(); 
      } else {
        this.c = true;
      } 
      if (this.c)
        paramq1.a(paramw0); 
    } catch (SQLiteException sQLiteException) {
      (new b0.a()).c("Database cannot be opened").c(sQLiteException.toString()).d(b0.g);
    } finally {}
    /* monitor exit ThisExpression{ObjectType{com/adcolony/sdk/l1}} */
  }
  
  private boolean j(w0 paramw0) {
    return (new v0(this.b, paramw0)).k();
  }
  
  private void l(String paramString, ContentValues paramContentValues) {
    // Byte code:
    //   0: aload_0
    //   1: monitorenter
    //   2: aload_1
    //   3: aload_2
    //   4: aload_0
    //   5: getfield b : Landroid/database/sqlite/SQLiteDatabase;
    //   8: invokestatic b : (Ljava/lang/String;Landroid/content/ContentValues;Landroid/database/sqlite/SQLiteDatabase;)V
    //   11: aload_0
    //   12: monitorexit
    //   13: return
    //   14: astore_1
    //   15: aload_0
    //   16: monitorexit
    //   17: aload_1
    //   18: athrow
    // Exception table:
    //   from	to	target	type
    //   2	11	14	finally
  }
  
  x0.b a(w0 paramw0, long paramLong) {
    return this.c ? x0.a(paramw0, this.b, this.a, paramLong) : null;
  }
  
  void c(e0 parame0, q1<w0> paramq1) {
    Context context;
    if (q.j()) {
      context = q.a().getApplicationContext();
    } else {
      context = null;
    } 
    if (context != null && parame0 != null)
      try {
        this.a.execute(new a(this, parame0, paramq1, context));
        return;
      } catch (RejectedExecutionException rejectedExecutionException) {
        b0.a a = new b0.a();
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("ADCEventsRepository.open failed with: ");
        stringBuilder.append(rejectedExecutionException.toString());
        a.c(stringBuilder.toString()).d(b0.i);
      }  
  }
  
  void d(w0.a parama, ContentValues paramContentValues) {
    if (parama != null && !this.e.contains(parama.h())) {
      this.e.add(parama.h());
      int i = parama.e();
      long l = -1L;
      w0.d d = parama.i();
      if (d != null) {
        l = paramContentValues.getAsLong(d.a()).longValue() - d.b();
        String str = d.a();
      } else {
        paramContentValues = null;
      } 
      a1.a(i, l, (String)paramContentValues, parama.h(), this.b);
    } 
  }
  
  void f(c paramc) {
    this.d = paramc;
  }
  
  void i(String paramString, ContentValues paramContentValues) {
    if (this.c)
      try {
        this.a.execute(new b(this, paramString, paramContentValues));
        return;
      } catch (RejectedExecutionException rejectedExecutionException) {
        b0.a a = new b0.a();
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("ADCEventsRepository.saveEvent failed with: ");
        stringBuilder.append(rejectedExecutionException.toString());
        a.c(stringBuilder.toString()).d(b0.i);
      }  
  }
  
  void k() {
    this.e.clear();
  }
  
  class a implements Runnable {
    a(l1 this$0, e0 param1e0, q1 param1q1, Context param1Context) {}
    
    public void run() {
      w0 w0 = w0.b(this.b);
      if (w0 != null)
        l1.g(this.e, w0, this.c, this.d); 
    }
  }
  
  class b implements Runnable {
    b(l1 this$0, String param1String, ContentValues param1ContentValues) {}
    
    public void run() {
      l1.h(this.d, this.b, this.c);
    }
  }
  
  static interface c {
    void a();
  }
}


/* Location:              C:\soft\dex2jar-2.0\Hill race-dex2jar.jar!\com\adcolony\sdk\l1.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */