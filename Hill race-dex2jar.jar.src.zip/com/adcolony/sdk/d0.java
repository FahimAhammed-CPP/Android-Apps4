package com.adcolony.sdk;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;

class d0 {
  static final SimpleDateFormat e = new SimpleDateFormat("yyyyMMdd'T'HHmmss.SSSZ", Locale.US);
  
  private Date a;
  
  private int b;
  
  private s c;
  
  protected String d;
  
  s b() {
    return this.c;
  }
  
  String f() {
    int i = this.b;
    return (i != -1) ? ((i != 0) ? ((i != 1) ? ((i != 2) ? ((i != 3) ? "UNKNOWN LOG LEVEL" : "Debug") : "Info") : "Warn") : "Error") : "Fatal";
  }
  
  String g() {
    return this.d;
  }
  
  String h() {
    return e.format(this.a);
  }
  
  public String toString() {
    StringBuilder stringBuilder = new StringBuilder();
    stringBuilder.append(h());
    stringBuilder.append(" ");
    stringBuilder.append(f());
    stringBuilder.append("/");
    stringBuilder.append(b().a());
    stringBuilder.append(": ");
    stringBuilder.append(g());
    return stringBuilder.toString();
  }
  
  static class a {
    protected d0 a = new d0();
    
    a a(int param1Int) {
      d0.a(this.a, param1Int);
      return this;
    }
    
    a b(s param1s) {
      d0.c(this.a, param1s);
      return this;
    }
    
    a c(String param1String) {
      this.a.d = param1String;
      return this;
    }
    
    d0 d() {
      if (d0.d(this.a) == null)
        d0.e(this.a, new Date(System.currentTimeMillis())); 
      return this.a;
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Hill race-dex2jar.jar!\com\adcolony\sdk\d0.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */