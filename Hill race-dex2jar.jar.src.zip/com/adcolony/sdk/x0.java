package com.adcolony.sdk;

import android.content.ContentValues;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.CountDownLatch;
import java.util.concurrent.Executor;
import java.util.concurrent.RejectedExecutionException;
import java.util.concurrent.TimeUnit;

class x0 {
  static b a(w0 paramw0, SQLiteDatabase paramSQLiteDatabase, Executor paramExecutor, long paramLong) {
    b b = new b(paramw0.d(), null);
    try {
      CountDownLatch countDownLatch = new CountDownLatch(1);
      paramExecutor.execute(new a(paramw0, paramSQLiteDatabase, b, countDownLatch));
      if (paramLong > 0L) {
        countDownLatch.await(paramLong, TimeUnit.MILLISECONDS);
        return b;
      } 
      countDownLatch.await();
      return b;
    } catch (RejectedExecutionException rejectedExecutionException) {
    
    } catch (InterruptedException interruptedException) {}
    b0.a a = new b0.a();
    StringBuilder stringBuilder = new StringBuilder();
    stringBuilder.append("ADCDbReader.calculateFeatureVectors failed with: ");
    stringBuilder.append(interruptedException.toString());
    a.c(stringBuilder.toString()).d(b0.i);
    return b;
  }
  
  static c b(String paramString, SQLiteDatabase paramSQLiteDatabase) {
    // Byte code:
    //   0: aconst_null
    //   1: astore #4
    //   3: aconst_null
    //   4: astore #5
    //   6: aconst_null
    //   7: astore #6
    //   9: aload_1
    //   10: aload_0
    //   11: aconst_null
    //   12: invokevirtual rawQuery : (Ljava/lang/String;[Ljava/lang/String;)Landroid/database/Cursor;
    //   15: astore #7
    //   17: aload #6
    //   19: astore_0
    //   20: aload #7
    //   22: ifnull -> 143
    //   25: aload #6
    //   27: astore_0
    //   28: aload #7
    //   30: invokeinterface moveToFirst : ()Z
    //   35: ifeq -> 143
    //   38: new com/adcolony/sdk/x0$c
    //   41: dup
    //   42: invokespecial <init> : ()V
    //   45: astore_0
    //   46: iconst_0
    //   47: istore_2
    //   48: iload_2
    //   49: aload #7
    //   51: invokeinterface getColumnCount : ()I
    //   56: if_icmpge -> 87
    //   59: aload_0
    //   60: iload_2
    //   61: aload #7
    //   63: iload_2
    //   64: invokeinterface getColumnName : (I)Ljava/lang/String;
    //   69: aload #7
    //   71: iload_2
    //   72: invokeinterface getType : (I)I
    //   77: invokestatic f : (Lcom/adcolony/sdk/x0$c;ILjava/lang/String;I)V
    //   80: iload_2
    //   81: iconst_1
    //   82: iadd
    //   83: istore_2
    //   84: goto -> 48
    //   87: aload_0
    //   88: aload #7
    //   90: invokestatic g : (Lcom/adcolony/sdk/x0$c;Landroid/database/Cursor;)V
    //   93: aload #7
    //   95: invokeinterface moveToNext : ()Z
    //   100: istore_3
    //   101: iload_3
    //   102: ifne -> 87
    //   105: goto -> 143
    //   108: astore_1
    //   109: goto -> 115
    //   112: astore_1
    //   113: aconst_null
    //   114: astore_0
    //   115: aload #7
    //   117: invokeinterface close : ()V
    //   122: goto -> 133
    //   125: astore #4
    //   127: aload_1
    //   128: aload #4
    //   130: invokevirtual addSuppressed : (Ljava/lang/Throwable;)V
    //   133: aload_1
    //   134: athrow
    //   135: astore_1
    //   136: goto -> 169
    //   139: astore_1
    //   140: goto -> 201
    //   143: aload_0
    //   144: astore_1
    //   145: aload #7
    //   147: ifnull -> 228
    //   150: aload_0
    //   151: astore #4
    //   153: aload_0
    //   154: astore #5
    //   156: aload #7
    //   158: invokeinterface close : ()V
    //   163: aload_0
    //   164: areturn
    //   165: astore_1
    //   166: aload #4
    //   168: astore_0
    //   169: new com/adcolony/sdk/b0$a
    //   172: dup
    //   173: invokespecial <init> : ()V
    //   176: ldc 'Error on execute query: '
    //   178: invokevirtual c : (Ljava/lang/String;)Lcom/adcolony/sdk/b0$a;
    //   181: aload_1
    //   182: invokevirtual toString : ()Ljava/lang/String;
    //   185: invokevirtual c : (Ljava/lang/String;)Lcom/adcolony/sdk/b0$a;
    //   188: getstatic com/adcolony/sdk/b0.i : Lcom/adcolony/sdk/b0;
    //   191: invokevirtual d : (Lcom/adcolony/sdk/b0;)V
    //   194: goto -> 226
    //   197: astore_1
    //   198: aload #5
    //   200: astore_0
    //   201: new com/adcolony/sdk/b0$a
    //   204: dup
    //   205: invokespecial <init> : ()V
    //   208: ldc 'SQLException on execute query: '
    //   210: invokevirtual c : (Ljava/lang/String;)Lcom/adcolony/sdk/b0$a;
    //   213: aload_1
    //   214: invokevirtual toString : ()Ljava/lang/String;
    //   217: invokevirtual c : (Ljava/lang/String;)Lcom/adcolony/sdk/b0$a;
    //   220: getstatic com/adcolony/sdk/b0.i : Lcom/adcolony/sdk/b0;
    //   223: invokevirtual d : (Lcom/adcolony/sdk/b0;)V
    //   226: aload_0
    //   227: astore_1
    //   228: aload_1
    //   229: areturn
    // Exception table:
    //   from	to	target	type
    //   9	17	197	android/database/SQLException
    //   9	17	165	finally
    //   28	46	112	finally
    //   48	80	108	finally
    //   87	101	108	finally
    //   115	122	125	finally
    //   127	133	139	android/database/SQLException
    //   127	133	135	finally
    //   133	135	139	android/database/SQLException
    //   133	135	135	finally
    //   156	163	197	android/database/SQLException
    //   156	163	165	finally
  }
  
  class a implements Runnable {
    a(x0 this$0, SQLiteDatabase param1SQLiteDatabase, x0.b param1b, CountDownLatch param1CountDownLatch) {}
    
    public void run() {
      for (w0.a a1 : this.b.c()) {
        for (Map.Entry<String, String> entry : a1.g().entrySet()) {
          x0.c c = x0.b((String)entry.getValue(), this.c);
          if (c != null)
            x0.b.b(this.d, a1.f(), (String)entry.getKey(), c); 
        } 
      } 
      y0.n().f(this.d);
      this.e.countDown();
    }
  }
  
  static class b {
    private final int a;
    
    private final Map<String, ArrayList<a>> b = new ConcurrentHashMap<String, ArrayList<a>>();
    
    private b(int param1Int) {
      this.a = param1Int;
    }
    
    private void c(String param1String1, String param1String2, x0.c param1c) {
      a a = new a(param1String2, param1c, null);
      if (this.b.containsKey(param1String1)) {
        ArrayList<a> arrayList = this.b.get(param1String1);
        if (arrayList != null) {
          arrayList.add(a);
          return;
        } 
      } 
      this.b.put(param1String1, new ArrayList<a>(Collections.singletonList(a)));
    }
    
    int a() {
      return this.a;
    }
    
    e0 d() {
      e0 e0 = v.q();
      v.u(e0, "version", a());
      for (Map.Entry<String, ArrayList<a>> entry : this.b.entrySet()) {
        e0 e01 = v.q();
        for (a a : entry.getValue()) {
          c0 c0 = v.c();
          Iterator<String> iterator = a.b().c(Character.valueOf(',')).iterator();
          while (iterator.hasNext())
            c0.g(iterator.next()); 
          v.l(e01, a.a(), c0);
        } 
        v.m(e0, (String)entry.getKey(), e01);
      } 
      return e0;
    }
    
    static class a {
      private final String a;
      
      private final x0.c b;
      
      private a(String param2String, x0.c param2c) {
        this.a = param2String;
        this.b = param2c;
      }
      
      String a() {
        return this.a;
      }
      
      x0.c b() {
        return this.b;
      }
    }
  }
  
  static class a {
    private final String a;
    
    private final x0.c b;
    
    private a(String param1String, x0.c param1c) {
      this.a = param1String;
      this.b = param1c;
    }
    
    String a() {
      return this.a;
    }
    
    x0.c b() {
      return this.b;
    }
  }
  
  static class c {
    private final List<a> a = new ArrayList<a>();
    
    private final List<ContentValues> b = new ArrayList<ContentValues>();
    
    private void d(int param1Int1, String param1String, int param1Int2) {
      this.a.add(new a(param1Int1, param1String, param1Int2, null));
    }
    
    private void e(Cursor param1Cursor) {
      ContentValues contentValues = new ContentValues();
      for (a a : this.a) {
        int i = a.b(a);
        if (i != 1) {
          if (i != 2) {
            if (i != 4) {
              contentValues.put(a.c(), param1Cursor.getString(a.a()));
              continue;
            } 
            contentValues.put(a.c(), param1Cursor.getBlob(a.a()));
            continue;
          } 
          contentValues.put(a.c(), Double.valueOf(param1Cursor.getDouble(a.a())));
          continue;
        } 
        contentValues.put(a.c(), Long.valueOf(param1Cursor.getLong(a.a())));
      } 
      this.b.add(contentValues);
    }
    
    String a(int param1Int) {
      return (param1Int >= 0 && param1Int < this.a.size()) ? ((a)this.a.get(param1Int)).c() : null;
    }
    
    String b(int param1Int, Character param1Character) {
      if (param1Int < 0 || param1Int >= this.b.size())
        return null; 
      ContentValues contentValues = this.b.get(param1Int);
      StringBuilder stringBuilder = new StringBuilder();
      for (param1Int = 0; param1Int < this.a.size(); param1Int++) {
        Character character;
        if (h(param1Int) == 3) {
          stringBuilder.append("\"");
          stringBuilder.append(contentValues.get(a(param1Int)));
          stringBuilder.append("\"");
        } else {
          stringBuilder.append(contentValues.getAsString(a(param1Int)));
        } 
        if (param1Int == this.a.size() - 1) {
          String str = "";
        } else {
          character = param1Character;
        } 
        stringBuilder.append(character);
      } 
      return stringBuilder.toString();
    }
    
    List<String> c(Character param1Character) {
      ArrayList<String> arrayList = new ArrayList();
      for (int i = 0; i < this.b.size(); i++)
        arrayList.add(b(i, param1Character)); 
      return arrayList;
    }
    
    int h(int param1Int) {
      return (param1Int >= 0 && param1Int < this.a.size()) ? ((a)this.a.get(param1Int)).e() : -1;
    }
    
    public String toString() {
      StringBuilder stringBuilder = new StringBuilder();
      int i = 0;
      while (true) {
        int j = this.a.size();
        String str = "\n";
        if (i < j) {
          stringBuilder.append(a.d(this.a.get(i)));
          if (i != this.a.size() - 1)
            str = " | "; 
          stringBuilder.append(str);
          i++;
          continue;
        } 
        for (ContentValues contentValues : this.b) {
          for (i = 0; i < this.a.size(); i++) {
            stringBuilder.append(contentValues.getAsString(a(i)));
            if (i == this.a.size() - 1) {
              str = "\n";
            } else {
              str = " | ";
            } 
            stringBuilder.append(str);
          } 
        } 
        return stringBuilder.toString();
      } 
    }
    
    static class a {
      private final int a;
      
      private final String b;
      
      private final int c;
      
      private a(int param2Int1, String param2String, int param2Int2) {
        this.a = param2Int1;
        this.b = param2String;
        this.c = param2Int2;
      }
      
      int a() {
        return this.a;
      }
      
      String c() {
        return this.b;
      }
      
      int e() {
        return this.c;
      }
    }
  }
  
  static class a {
    private final int a;
    
    private final String b;
    
    private final int c;
    
    private a(int param1Int1, String param1String, int param1Int2) {
      this.a = param1Int1;
      this.b = param1String;
      this.c = param1Int2;
    }
    
    int a() {
      return this.a;
    }
    
    String c() {
      return this.b;
    }
    
    int e() {
      return this.c;
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Hill race-dex2jar.jar!\com\adcolony\sdk\x0.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */