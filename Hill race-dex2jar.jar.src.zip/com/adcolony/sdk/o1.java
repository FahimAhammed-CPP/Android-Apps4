package com.adcolony.sdk;

import java.io.IOException;
import java.io.InputStream;

class o1 extends InputStream {
  InputStream b;
  
  int c;
  
  o1(InputStream paramInputStream, int paramInt1, int paramInt2) throws IOException {
    this.b = paramInputStream;
    while (paramInt1 > 0)
      paramInt1 -= (int)paramInputStream.skip(paramInt1); 
    this.c = paramInt2;
  }
  
  public int available() throws IOException {
    int i = this.b.available();
    int j = this.c;
    return (i <= j) ? i : j;
  }
  
  public void close() throws IOException {
    this.b.close();
  }
  
  public int read() throws IOException {
    int i = this.c;
    if (i == 0)
      return -1; 
    this.c = i - 1;
    return this.b.read();
  }
  
  public int read(byte[] paramArrayOfbyte) throws IOException {
    return read(paramArrayOfbyte, 0, paramArrayOfbyte.length);
  }
  
  public int read(byte[] paramArrayOfbyte, int paramInt1, int paramInt2) throws IOException {
    int j = this.c;
    if (j == 0)
      return -1; 
    int i = paramInt2;
    if (paramInt2 > j)
      i = j; 
    paramInt1 = this.b.read(paramArrayOfbyte, paramInt1, i);
    if (paramInt1 == -1)
      return -1; 
    this.c -= paramInt1;
    return paramInt1;
  }
  
  public long skip(long paramLong) throws IOException {
    int k = (int)paramLong;
    if (k <= 0)
      return 0L; 
    int j = this.c;
    int i = k;
    if (k > j)
      i = j; 
    this.c = j - i;
    while (i > 0)
      i -= (int)this.b.skip(paramLong); 
    return paramLong;
  }
}


/* Location:              C:\soft\dex2jar-2.0\Hill race-dex2jar.jar!\com\adcolony\sdk\o1.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */