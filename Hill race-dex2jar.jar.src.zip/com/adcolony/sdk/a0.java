package com.adcolony.sdk;

import android.content.Context;
import c2.d;
import c2.f;
import c2.h;
import java.io.FileInputStream;
import java.io.IOException;
import java.util.regex.Matcher;

public final class a0 extends n0 {
  private String H = "";
  
  private String I = "";
  
  public a0(Context paramContext, int paramInt, j0 paramj0) {
    super(paramContext, paramInt, paramj0);
  }
  
  private final void Y(Exception paramException) {
    (new b0.a()).c(paramException.getClass().toString()).c(" during metadata injection w/ metadata = ").c(v.E(getInfo(), "metadata")).d(b0.i);
    j j = q.h().Z().E().remove(v.E(getInfo(), "ad_session_id"));
    if (j == null)
      return; 
    j.L();
  }
  
  private final String Z() {
    int i;
    if (this.I.length() > 0) {
      i = 1;
    } else {
      i = 0;
    } 
    if (i) {
      f f = new f("script\\s*src\\s*=\\s*\"mraid.js\"");
      StringBuilder stringBuilder = new StringBuilder();
      stringBuilder.append("script src=\"file://");
      stringBuilder.append(getMraidFilepath());
      stringBuilder.append('"');
      String str = stringBuilder.toString();
      return f.c(this.I, str);
    } 
    FileInputStream fileInputStream = new FileInputStream(this.H);
    try {
      StringBuilder stringBuilder = new StringBuilder(fileInputStream.available());
      byte[] arrayOfByte = new byte[1024];
      while (true) {
        String str;
        i = fileInputStream.read(arrayOfByte, 0, 1024);
        if (i >= 0) {
          stringBuilder.append(new String(arrayOfByte, 0, i, d.b));
          continue;
        } 
        if (h.K(this.H, ".html", false, 2, null)) {
          str = stringBuilder.toString();
        } else {
          StringBuilder stringBuilder1 = new StringBuilder();
          stringBuilder1.append("<html><script>");
          stringBuilder1.append(str);
          stringBuilder1.append("</script></html>");
          str = stringBuilder1.toString();
        } 
        return str;
      } 
    } finally {
      Exception exception = null;
    } 
  }
  
  public void c() {
    if (!getDestroyed()) {
      long l;
      a a = new a(this);
      if (U()) {
        l = 1000L;
      } else {
        l = 0L;
      } 
      u1.r(a, l);
    } 
  }
  
  static final class a implements Runnable {
    a(a0 param1a0) {}
    
    public final void run() {
      a0.X(this.b);
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Hill race-dex2jar.jar!\com\adcolony\sdk\a0.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */