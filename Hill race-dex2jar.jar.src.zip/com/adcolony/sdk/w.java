package com.adcolony.sdk;

import android.annotation.SuppressLint;
import android.content.Context;
import android.content.Intent;
import android.graphics.Bitmap;
import android.net.Uri;
import android.os.Build;
import android.webkit.JavascriptInterface;
import android.webkit.WebMessage;
import android.webkit.WebMessagePort;
import android.webkit.WebResourceRequest;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import com.iab.omid.library.adcolony.ScriptInjector;
import i1.i0;
import java.io.IOException;
import java.util.List;
import u1.r;

public class w extends t implements q0 {
  private String A = "";
  
  private i B;
  
  private boolean C = true;
  
  private e0 D = v.q();
  
  private boolean E;
  
  private boolean F;
  
  private boolean w;
  
  private boolean x;
  
  private final Object y = new Object();
  
  private c0 z = v.c();
  
  static {
    new h(null);
  }
  
  public w(Context paramContext, int paramInt, j0 paramj0) {
    super(paramContext, paramInt, paramj0);
  }
  
  private final void G(e0 parame0) {
    q.h().P0().r(parame0);
  }
  
  private final void I(String paramString) {
    G(v.r(paramString));
  }
  
  private final void N(String paramString) {
    e0[] arrayOfE0 = v.e(paramString).i();
    int k = arrayOfE0.length;
    for (int j = 0; j < k; j++)
      G(arrayOfE0[j]); 
  }
  
  private final void R(String paramString) {
    if (this.B == null) {
      i i1 = new i(createWebMessageChannel());
      WebMessagePort webMessagePort = i1.b();
      if (webMessagePort != null)
        webMessagePort.setWebMessageCallback(new m(this)); 
      postWebMessage(new WebMessage("", new WebMessagePort[] { i1.a() }), Uri.parse(paramString));
      i0 i0 = i0.a;
      this.B = i1;
    } 
  }
  
  private final void S(e0 parame0) {
    // Byte code:
    //   0: aload_0
    //   1: getfield C : Z
    //   4: ifeq -> 82
    //   7: aload_0
    //   8: getfield B : Lcom/adcolony/sdk/w$i;
    //   11: astore_2
    //   12: aload_2
    //   13: ifnonnull -> 19
    //   16: goto -> 28
    //   19: aload_2
    //   20: invokevirtual b : ()Landroid/webkit/WebMessagePort;
    //   23: astore_2
    //   24: aload_2
    //   25: ifnonnull -> 33
    //   28: aconst_null
    //   29: astore_1
    //   30: goto -> 60
    //   33: invokestatic c : ()Lcom/adcolony/sdk/c0;
    //   36: astore_3
    //   37: aload_3
    //   38: aload_1
    //   39: invokevirtual a : (Lcom/adcolony/sdk/e0;)Lcom/adcolony/sdk/c0;
    //   42: pop
    //   43: aload_2
    //   44: new android/webkit/WebMessage
    //   47: dup
    //   48: aload_3
    //   49: invokevirtual toString : ()Ljava/lang/String;
    //   52: invokespecial <init> : (Ljava/lang/String;)V
    //   55: invokevirtual postMessage : (Landroid/webkit/WebMessage;)V
    //   58: aload_2
    //   59: astore_1
    //   60: aload_1
    //   61: ifnonnull -> 82
    //   64: new com/adcolony/sdk/b0$a
    //   67: dup
    //   68: invokespecial <init> : ()V
    //   71: ldc 'Sending message before event messaging is initialized'
    //   73: invokevirtual c : (Ljava/lang/String;)Lcom/adcolony/sdk/b0$a;
    //   76: getstatic com/adcolony/sdk/b0.g : Lcom/adcolony/sdk/b0;
    //   79: invokevirtual d : (Lcom/adcolony/sdk/b0;)V
    //   82: return
  }
  
  private final a T() {
    return (Build.VERSION.SDK_INT >= 23) ? new b(this) : new a(this);
  }
  
  private final void V() {
    // Byte code:
    //   0: ldc ''
    //   2: astore_2
    //   3: aload_0
    //   4: getfield y : Ljava/lang/Object;
    //   7: astore_3
    //   8: aload_3
    //   9: monitorenter
    //   10: aload_2
    //   11: astore_1
    //   12: aload_0
    //   13: getfield z : Lcom/adcolony/sdk/c0;
    //   16: invokevirtual e : ()I
    //   19: ifle -> 46
    //   22: aload_2
    //   23: astore_1
    //   24: aload_0
    //   25: invokevirtual getEnableMessages : ()Z
    //   28: ifeq -> 39
    //   31: aload_0
    //   32: getfield z : Lcom/adcolony/sdk/c0;
    //   35: invokevirtual toString : ()Ljava/lang/String;
    //   38: astore_1
    //   39: aload_0
    //   40: invokestatic c : ()Lcom/adcolony/sdk/c0;
    //   43: putfield z : Lcom/adcolony/sdk/c0;
    //   46: getstatic i1/i0.a : Li1/i0;
    //   49: astore_2
    //   50: aload_3
    //   51: monitorexit
    //   52: new com/adcolony/sdk/w$o
    //   55: dup
    //   56: aload_0
    //   57: aload_1
    //   58: invokespecial <init> : (Lcom/adcolony/sdk/w;Ljava/lang/String;)V
    //   61: invokestatic G : (Ljava/lang/Runnable;)Z
    //   64: pop
    //   65: return
    //   66: astore_1
    //   67: aload_3
    //   68: monitorexit
    //   69: aload_1
    //   70: athrow
    // Exception table:
    //   from	to	target	type
    //   12	22	66	finally
    //   24	39	66	finally
    //   39	46	66	finally
    //   46	50	66	finally
  }
  
  private final String getClickOverride() {
    String str;
    d d;
    j j = getInterstitial();
    if (j == null) {
      j = null;
    } else {
      str = j.q();
    } 
    if (str == null) {
      d = getAdView();
      return (d == null) ? null : d.getClickOverride();
    } 
    return (String)d;
  }
  
  public void a(e0 parame0) {
    synchronized (this.y) {
      i0 i0;
      if (this.x) {
        S(parame0);
        i0 = i0.a;
      } else {
        this.z.a((e0)i0);
      } 
      return;
    } 
  }
  
  public boolean a() {
    return (!this.w && !this.x);
  }
  
  public void b() {
    if (q.j() && this.E && !this.w && !this.x)
      V(); 
  }
  
  public void c() {
    if (!getDestroyed()) {
      x();
      u1.G(new n(this));
    } 
  }
  
  public int getAdcModuleId() {
    return getAdc3ModuleId();
  }
  
  public int getModuleId() {
    return getWebViewModuleId();
  }
  
  private class a {
    public a(w this$0) {}
    
    @JavascriptInterface
    public final void dispatch_messages(String param1String1, String param1String2) {
      if (r.a(param1String2, w.D(this.a)))
        w.E(this.a, param1String1); 
    }
    
    @JavascriptInterface
    public final void enable_reverse_messaging(String param1String) {
      if (r.a(param1String, w.D(this.a)))
        w.F(this.a, true); 
    }
    
    @JavascriptInterface
    public final String pull_messages(String param1String) {
      // Byte code:
      //   0: aload_1
      //   1: aload_0
      //   2: getfield a : Lcom/adcolony/sdk/w;
      //   5: invokestatic D : (Lcom/adcolony/sdk/w;)Ljava/lang/String;
      //   8: invokestatic a : (Ljava/lang/Object;Ljava/lang/Object;)Z
      //   11: ifeq -> 86
      //   14: ldc '[]'
      //   16: astore_2
      //   17: aload_0
      //   18: getfield a : Lcom/adcolony/sdk/w;
      //   21: invokestatic O : (Lcom/adcolony/sdk/w;)Ljava/lang/Object;
      //   24: astore_3
      //   25: aload_0
      //   26: getfield a : Lcom/adcolony/sdk/w;
      //   29: astore #4
      //   31: aload_3
      //   32: monitorenter
      //   33: aload_2
      //   34: astore_1
      //   35: aload #4
      //   37: invokestatic J : (Lcom/adcolony/sdk/w;)Lcom/adcolony/sdk/c0;
      //   40: invokevirtual e : ()I
      //   43: ifle -> 73
      //   46: aload_2
      //   47: astore_1
      //   48: aload #4
      //   50: invokevirtual getEnableMessages : ()Z
      //   53: ifeq -> 65
      //   56: aload #4
      //   58: invokestatic J : (Lcom/adcolony/sdk/w;)Lcom/adcolony/sdk/c0;
      //   61: invokevirtual toString : ()Ljava/lang/String;
      //   64: astore_1
      //   65: aload #4
      //   67: invokestatic c : ()Lcom/adcolony/sdk/c0;
      //   70: invokestatic A : (Lcom/adcolony/sdk/w;Lcom/adcolony/sdk/c0;)V
      //   73: getstatic i1/i0.a : Li1/i0;
      //   76: astore_2
      //   77: aload_3
      //   78: monitorexit
      //   79: aload_1
      //   80: areturn
      //   81: astore_1
      //   82: aload_3
      //   83: monitorexit
      //   84: aload_1
      //   85: athrow
      //   86: ldc '[]'
      //   88: areturn
      // Exception table:
      //   from	to	target	type
      //   35	46	81	finally
      //   48	65	81	finally
      //   65	73	81	finally
      //   73	77	81	finally
    }
    
    @JavascriptInterface
    public final void push_messages(String param1String1, String param1String2) {
      if (r.a(param1String2, w.D(this.a)))
        w.E(this.a, param1String1); 
    }
  }
  
  private final class b extends a {
    public b(w this$0) {
      super(this$0);
    }
    
    @JavascriptInterface
    public final void enable_event_messaging(String param1String) {
      if (r.a(param1String, w.D(this.b)))
        w.C(this.b, true); 
    }
  }
  
  protected class c extends t.b {
    public c(w this$0) {
      super(this$0);
    }
    
    public void onPageFinished(WebView param1WebView, String param1String) {
      super.onPageFinished(param1WebView, param1String);
      (new w.l(this.b)).a();
    }
    
    public void onPageStarted(WebView param1WebView, String param1String, Bitmap param1Bitmap) {
      (new w.l(this.b)).c();
    }
    
    public boolean shouldOverrideUrlLoading(WebView param1WebView, String param1String) {
      return (new w.l(this.b)).b(param1String);
    }
  }
  
  protected class d extends t.c {
    public d(w this$0) {
      super(this$0);
    }
    
    public void onPageFinished(WebView param1WebView, String param1String) {
      super.onPageFinished(param1WebView, param1String);
      (new w.l(this.c)).a();
    }
    
    public void onPageStarted(WebView param1WebView, String param1String, Bitmap param1Bitmap) {
      (new w.l(this.c)).c();
    }
    
    public boolean shouldOverrideUrlLoading(WebView param1WebView, String param1String) {
      return (new w.l(this.c)).b(param1String);
    }
  }
  
  protected class e extends t.d {
    public e(w this$0) {
      super(this$0);
    }
    
    public void onPageFinished(WebView param1WebView, String param1String) {
      super.onPageFinished(param1WebView, param1String);
      (new w.j(this.d)).a(param1String);
    }
    
    public void onPageStarted(WebView param1WebView, String param1String, Bitmap param1Bitmap) {
      (new w.l(this.d)).c();
    }
    
    public boolean shouldOverrideUrlLoading(WebView param1WebView, String param1String) {
      return (new w.l(this.d)).b(param1String);
    }
  }
  
  protected class f extends t.e {
    public f(w this$0) {
      super(this$0);
    }
    
    public void onPageFinished(WebView param1WebView, String param1String) {
      super.onPageFinished(param1WebView, param1String);
      (new w.j(this.d)).a(param1String);
    }
    
    public void onPageStarted(WebView param1WebView, String param1String, Bitmap param1Bitmap) {
      (new w.l(this.d)).c();
    }
    
    public boolean shouldOverrideUrlLoading(WebView param1WebView, WebResourceRequest param1WebResourceRequest) {
      return (new w.k(this.d)).a(param1WebResourceRequest);
    }
  }
  
  protected class g extends t.f {
    public g(w this$0) {
      super(this$0);
    }
    
    public void onPageFinished(WebView param1WebView, String param1String) {
      super.onPageFinished(param1WebView, param1String);
      (new w.j(this.e)).a(param1String);
    }
    
    public void onPageStarted(WebView param1WebView, String param1String, Bitmap param1Bitmap) {
      (new w.l(this.e)).c();
    }
    
    public boolean shouldOverrideUrlLoading(WebView param1WebView, WebResourceRequest param1WebResourceRequest) {
      return (new w.k(this.e)).a(param1WebResourceRequest);
    }
  }
  
  public static final class h {
    private h() {}
  }
  
  private static final class i {
    private final WebMessagePort[] a;
    
    public i(WebMessagePort[] param1ArrayOfWebMessagePort) {
      this.a = param1ArrayOfWebMessagePort;
    }
    
    public final WebMessagePort a() {
      return (WebMessagePort)j1.h.w((Object[])this.a, 1);
    }
    
    public final WebMessagePort b() {
      return (WebMessagePort)j1.h.w((Object[])this.a, 0);
    }
  }
  
  private final class j {
    public j(w this$0) {}
    
    public final void a(String param1String) {
      (new w.l(this.a)).a();
      if (param1String != null) {
        w.L(this.a, param1String);
        return;
      } 
      (new b0.a()).c("ADCWebViewModule: initializeEventMessaging failed due to url = null").d(b0.g);
    }
  }
  
  private final class k {
    public k(w this$0) {}
    
    public final boolean a(WebResourceRequest param1WebResourceRequest) {
      boolean bool = this.a.getModuleInitialized();
      byte b = 0;
      if (bool) {
        int i;
        if (param1WebResourceRequest != null && param1WebResourceRequest.isForMainFrame() == true) {
          i = 1;
        } else {
          i = 0;
        } 
        if (i) {
          Uri uri1;
          String str = w.y(this.a);
          if (str == null) {
            str = null;
          } else {
            uri1 = Uri.parse(str);
          } 
          Uri uri2 = uri1;
          if (uri1 == null)
            uri2 = param1WebResourceRequest.getUrl(); 
          if (uri2 != null) {
            u1.n(new Intent("android.intent.action.VIEW", uri2));
            e0 e0 = v.q();
            w w2 = this.a;
            v.n(e0, "url", uri2.toString());
            v.n(e0, "ad_session_id", w2.getAdSessionId());
            u u = this.a.getParentContainer();
            if (u == null) {
              i = b;
            } else {
              i = u.J();
            } 
            (new j0("WebView.redirect_detected", i, e0)).e();
            p1 p1 = q.h().a();
            w w1 = this.a;
            p1.b(w1.getAdSessionId());
            p1.h(w1.getAdSessionId());
            return true;
          } 
          (new b0.a()).c(r.m("shouldOverrideUrlLoading called with null request url, with ad id: ", this.a.t())).d(b0.i);
          return true;
        } 
      } 
      return false;
    }
  }
  
  private final class l {
    public l(w this$0) {}
    
    public final void a() {
      if (this.a.getEnableMessages() && !this.a.getModuleInitialized()) {
        w.Q(this.a, u1.i());
        e0 e0 = v.h(new e0[] { v.q(), this.a.getInfo() });
        v.n(e0, "message_key", w.D(this.a));
        w w1 = this.a;
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("ADC3_init(");
        stringBuilder.append(this.a.getAdcModuleId());
        stringBuilder.append(',');
        stringBuilder.append(e0);
        stringBuilder.append(");");
        w1.l(stringBuilder.toString());
        w.M(this.a, true);
      } 
    }
    
    public final boolean b(String param1String) {
      boolean bool = this.a.getModuleInitialized();
      int i = 0;
      if (bool) {
        String str = w.y(this.a);
        if (str != null)
          param1String = str; 
        if (param1String != null) {
          u1.n(new Intent("android.intent.action.VIEW", Uri.parse(param1String)));
          e0 e0 = v.q();
          w w2 = this.a;
          v.n(e0, "url", param1String);
          v.n(e0, "ad_session_id", w2.getAdSessionId());
          u u = this.a.getParentContainer();
          if (u != null)
            i = u.J(); 
          (new j0("WebView.redirect_detected", i, e0)).e();
          p1 p1 = q.h().a();
          w w1 = this.a;
          p1.b(w1.getAdSessionId());
          p1.h(w1.getAdSessionId());
        } else {
          (new b0.a()).c(r.m("shouldOverrideUrlLoading called with null request url, with ad id: ", this.a.t())).d(b0.i);
        } 
        return true;
      } 
      return false;
    }
    
    public final void c() {
      w.M(this.a, false);
    }
  }
  
  public static final class m extends WebMessagePort.WebMessageCallback {
    m(w param1w) {}
    
    public void onMessage(WebMessagePort param1WebMessagePort, WebMessage param1WebMessage) {
      if (param1WebMessage == null)
        return; 
      String str = param1WebMessage.getData();
      if (str == null)
        return; 
      w w1 = this.a;
      List<String> list = (new c2.f(":")).d(str, 2);
      if (list.size() == 2 && r.a(list.get(0), w.D(w1)))
        w.B(w1, list.get(1)); 
    }
  }
  
  static final class n implements Runnable {
    n(w param1w) {}
    
    public final void run() {
      this.b.removeJavascriptInterface("NativeLayer");
    }
  }
  
  static final class o implements Runnable {
    o(w param1w, String param1String) {}
    
    public final void run() {
      if (this.b.getEnableMessages()) {
        w w1 = this.b;
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("NativeLayer.dispatch_messages(ADC3_update(");
        stringBuilder.append(this.c);
        stringBuilder.append("), '");
        stringBuilder.append(w.D(this.b));
        stringBuilder.append("');");
        w1.l(stringBuilder.toString());
      } 
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Hill race-dex2jar.jar!\com\adcolony\sdk\w.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */