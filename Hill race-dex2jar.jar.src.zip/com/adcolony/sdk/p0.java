package com.adcolony.sdk;

import android.app.Activity;
import android.app.Application;
import android.content.Context;
import android.os.Build;
import android.os.Bundle;
import android.util.Log;
import com.iab.omid.library.adcolony.Omid;
import com.iab.omid.library.adcolony.adsession.Partner;
import java.io.File;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.Set;
import java.util.concurrent.ScheduledExecutorService;

class p0 {
  static String Z = "https://adc3-launch.adcolony.com/v4/launch";
  
  private static volatile String a0 = "";
  
  private boolean A;
  
  private boolean B;
  
  private boolean C;
  
  private f0 D = new f0();
  
  private boolean E;
  
  private boolean F;
  
  private boolean G;
  
  private boolean H;
  
  private boolean I;
  
  private boolean J;
  
  private boolean K;
  
  private boolean L;
  
  private int M;
  
  private int N = 1;
  
  private Application.ActivityLifecycleCallbacks O;
  
  private Partner P = null;
  
  private e0 Q = new e0();
  
  private long R = 500L;
  
  private long S = 500L;
  
  private boolean T;
  
  private long U = 20000L;
  
  private long V = 300000L;
  
  private long W = 15000L;
  
  private int X;
  
  private boolean Y = false;
  
  private l0 a;
  
  private h1 b;
  
  private i1 c;
  
  private x d;
  
  private d1 e;
  
  private n1 f;
  
  private p1 g;
  
  private m1 h;
  
  private h0 i;
  
  private b1 j;
  
  private u0 k;
  
  private u l;
  
  private t1 m;
  
  private d n;
  
  private j o;
  
  private m p;
  
  private HashMap<String, h> q = new HashMap<String, h>();
  
  private f r;
  
  private j0 s;
  
  private e0 t;
  
  private HashMap<String, n> u = new HashMap<String, n>();
  
  private HashMap<Integer, w> v = new HashMap<Integer, w>();
  
  private String w;
  
  private String x;
  
  private String y;
  
  private String z = "";
  
  private void E(j0 paramj0) {
    H(v.A(paramj0.a(), "id"));
  }
  
  private void G(f1 paramf1) {
    if (paramf1.o) {
      e0 e01 = v.g(paramf1.n, "Parsing launch response");
      v.n(e01, "sdkVersion", H0().i());
      StringBuilder stringBuilder = new StringBuilder();
      stringBuilder.append(this.h.c());
      stringBuilder.append("026ae9c9824b3e483fa6c71fa88f57ae27816141");
      v.G(e01, stringBuilder.toString());
      if (!c0(e01)) {
        if (!this.F) {
          (new b0.a()).c("Incomplete or disabled launch server response. ").c("Disabling AdColony until next launch.").d(b0.h);
          X(true);
        } 
        return;
      } 
      if (I(e01)) {
        e0 e02 = v.q();
        v.n(e02, "url", this.w);
        StringBuilder stringBuilder1 = new StringBuilder();
        stringBuilder1.append(this.h.c());
        stringBuilder1.append("7bf3a1e7bbd31e612eda3310c2cdb8075c43c6b5");
        v.n(e02, "filepath", stringBuilder1.toString());
        this.b.e(new f1(new j0("WebServices.download", 0, e02), new p(this)));
      } 
      this.t = e01;
      return;
    } 
    s();
  }
  
  private boolean I(e0 parame0) {
    if (!this.F)
      return true; 
    e0 e01 = this.t;
    if (e01 != null && v.E(v.C(e01, "controller"), "sha1").equals(v.E(v.C(parame0, "controller"), "sha1")))
      return false; 
    (new b0.a()).c("Controller sha1 does not match, downloading new controller.").d(b0.g);
    return true;
  }
  
  private boolean O(String paramString) {
    Context context = q.a();
    if (context != null) {
      StringBuilder stringBuilder = new StringBuilder();
      stringBuilder.append(context.getFilesDir().getAbsolutePath());
      stringBuilder.append("/adc3/");
      stringBuilder.append("7bf3a1e7bbd31e612eda3310c2cdb8075c43c6b5");
      File file = new File(stringBuilder.toString());
      if (file.exists())
        return u1.t(paramString, file); 
    } 
    return false;
  }
  
  private boolean P(boolean paramBoolean) {
    return Q(paramBoolean, false);
  }
  
  private boolean Q(boolean paramBoolean1, boolean paramBoolean2) {
    if (!q.j())
      return false; 
    this.I = paramBoolean2;
    this.F = paramBoolean1;
    if (paramBoolean1 && !paramBoolean2) {
      if (!l())
        return false; 
      this.I = true;
    } 
    k();
    return true;
  }
  
  private void S() {
    int i = this.X - 1;
    this.X = i;
    if (i == 0)
      p(); 
  }
  
  private void U(e0 parame0) {
    if (!r0.I) {
      e0 e02 = v.C(parame0, "logging");
      h0.h = v.a(e02, "send_level", 1);
      h0.f = v.t(e02, "log_private");
      h0.g = v.a(e02, "print_level", 3);
      this.i.n(v.d(e02, "modules"));
      this.i.p(v.B(e02, "included_fields"));
    } 
    e0 e01 = v.C(parame0, "metadata");
    H0().v(e01);
    Y0().b(v.A(e01, "session_timeout"));
    a0 = v.E(parame0, "pie");
    this.z = v.E(v.C(parame0, "controller"), "version");
    this.R = v.b(e01, "signals_timeout", this.R);
    this.S = v.b(e01, "calculate_odt_timeout", this.S);
    this.T = v.o(e01, "async_odt_query", this.T);
    this.U = v.b(e01, "ad_request_timeout", this.U);
    this.V = v.b(e01, "controller_heartbeat_interval", this.V);
    this.W = v.b(e01, "controller_heartbeat_timeout", this.W);
    this.Y = v.o(e01, "enable_compression", false);
    l1.b().c(e01.I("odt_config"), new t(this));
  }
  
  private void V(j0 paramj0) {
    e0 e01 = this.r.d();
    v.n(e01, "app_id", this.r.b());
    e0 e02 = v.q();
    v.m(e02, "options", e01);
    paramj0.b(e02).e();
  }
  
  private boolean c0(e0 parame0) {
    if (parame0 == null)
      return false; 
    try {
      e0 e01 = v.C(parame0, "controller");
      this.w = v.E(e01, "url");
      this.x = v.E(e01, "sha1");
      this.y = v.E(parame0, "status");
      U(parame0);
      if (i.b())
        i.c(); 
    } catch (Exception exception) {
      try {
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append(this.h.c());
        stringBuilder.append("026ae9c9824b3e483fa6c71fa88f57ae27816141");
        (new File(stringBuilder.toString())).delete();
      } catch (Exception exception1) {}
    } 
    if (this.y.equals("disable") && !r0.I) {
      try {
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append(this.h.c());
        stringBuilder.append("7bf3a1e7bbd31e612eda3310c2cdb8075c43c6b5");
        (new File(stringBuilder.toString())).delete();
      } catch (Exception exception) {}
      (new b0.a()).c("Launch server response with disabled status. Disabling AdColony ").c("until next launch.").d(b0.g);
      a.s();
      return false;
    } 
    if ((this.w.equals("") || this.y.equals("")) && !r0.I) {
      (new b0.a()).c("Missing controller status or URL. Disabling AdColony until next ").c("launch.").d(b0.i);
      return false;
    } 
    return true;
  }
  
  private boolean d0(j0 paramj0) {
    Context context = q.a();
    if (context == null)
      return false; 
    try {
      int i = paramj0.a().E("id");
      if (i > 0)
        H(i); 
      u1.G(new n(this, context, paramj0));
      return true;
    } catch (RuntimeException runtimeException) {
      b0.a a = new b0.a();
      StringBuilder stringBuilder = new StringBuilder();
      stringBuilder.append(runtimeException.toString());
      stringBuilder.append(": during WebView initialization.");
      a.c(stringBuilder.toString()).c(" Disabling AdColony.").d(b0.h);
      a.s();
      return false;
    } 
  }
  
  private void k() {
    (new Thread(new l(this))).start();
  }
  
  private boolean l() {
    this.a.d();
    return true;
  }
  
  private void m() {
    e0 e01 = v.q();
    v.n(e01, "type", "AdColony.on_configuration_completed");
    c0 c0 = new c0();
    Iterator<String> iterator = c().keySet().iterator();
    while (iterator.hasNext())
      c0.g(iterator.next()); 
    e0 e02 = v.q();
    v.l(e02, "zone_ids", c0);
    v.m(e01, "message", e02);
    (new j0("CustomMessage.controller_send", 0, e01)).e();
  }
  
  private void n() {
    if (!O(this.x) && !r0.I) {
      (new b0.a()).c("Downloaded controller sha1 does not match, retrying.").d(b0.f);
      s();
      return;
    } 
    if (!this.F && !this.I)
      u1.G(new q(this)); 
    if (this.F && this.I)
      q(); 
  }
  
  private void o() {
    Context context = q.a();
    if (context != null && this.O == null && Build.VERSION.SDK_INT > 14) {
      Application application;
      this.O = new v(this);
      if (context instanceof Application) {
        application = (Application)context;
      } else {
        application = ((Activity)application).getApplication();
      } 
      application.registerActivityLifecycleCallbacks(this.O);
    } 
  }
  
  private void r0(j0 paramj0) {
    n n;
    if (this.C)
      return; 
    String str = v.E(paramj0.a(), "zone_id");
    if (this.u.containsKey(str)) {
      n = this.u.get(str);
    } else {
      n = new n(str);
      this.u.put(str, n);
    } 
    n.e(paramj0);
  }
  
  private void s() {
    if (q.h().Y0().q()) {
      int i = this.M + 1;
      this.M = i;
      this.N = Math.min(this.N * i, 120);
      u1.r(new o(this), this.N * 1000L);
      return;
    } 
    (new b0.a()).c("Max launch server download attempts hit, or AdColony is no longer").c(" active.").d(b0.g);
  }
  
  void A(f paramf, boolean paramBoolean) {
    // Byte code:
    //   0: aload_0
    //   1: iload_2
    //   2: putfield C : Z
    //   5: aload_0
    //   6: aload_1
    //   7: putfield r : Lcom/adcolony/sdk/f;
    //   10: aload_0
    //   11: new com/adcolony/sdk/l0
    //   14: dup
    //   15: invokespecial <init> : ()V
    //   18: putfield a : Lcom/adcolony/sdk/l0;
    //   21: new com/adcolony/sdk/t0
    //   24: dup
    //   25: invokespecial <init> : ()V
    //   28: pop
    //   29: new com/adcolony/sdk/b1
    //   32: dup
    //   33: invokespecial <init> : ()V
    //   36: astore #5
    //   38: aload_0
    //   39: aload #5
    //   41: putfield j : Lcom/adcolony/sdk/b1;
    //   44: aload #5
    //   46: invokevirtual m : ()V
    //   49: new com/adcolony/sdk/h1
    //   52: dup
    //   53: invokespecial <init> : ()V
    //   56: astore #5
    //   58: aload_0
    //   59: aload #5
    //   61: putfield b : Lcom/adcolony/sdk/h1;
    //   64: aload #5
    //   66: invokevirtual b : ()V
    //   69: new com/adcolony/sdk/i1
    //   72: dup
    //   73: invokespecial <init> : ()V
    //   76: astore #5
    //   78: aload_0
    //   79: aload #5
    //   81: putfield c : Lcom/adcolony/sdk/i1;
    //   84: aload #5
    //   86: invokevirtual l : ()V
    //   89: new com/adcolony/sdk/x
    //   92: dup
    //   93: invokespecial <init> : ()V
    //   96: astore #5
    //   98: aload_0
    //   99: aload #5
    //   101: putfield d : Lcom/adcolony/sdk/x;
    //   104: aload #5
    //   106: invokevirtual K : ()V
    //   109: aload_0
    //   110: new com/adcolony/sdk/d1
    //   113: dup
    //   114: invokespecial <init> : ()V
    //   117: putfield e : Lcom/adcolony/sdk/d1;
    //   120: new com/adcolony/sdk/n1
    //   123: dup
    //   124: invokespecial <init> : ()V
    //   127: astore #5
    //   129: aload_0
    //   130: aload #5
    //   132: putfield f : Lcom/adcolony/sdk/n1;
    //   135: aload #5
    //   137: invokevirtual m : ()V
    //   140: new com/adcolony/sdk/h0
    //   143: dup
    //   144: invokespecial <init> : ()V
    //   147: astore #5
    //   149: aload_0
    //   150: aload #5
    //   152: putfield i : Lcom/adcolony/sdk/h0;
    //   155: aload #5
    //   157: invokevirtual o : ()V
    //   160: new com/adcolony/sdk/m1
    //   163: dup
    //   164: invokespecial <init> : ()V
    //   167: astore #5
    //   169: aload_0
    //   170: aload #5
    //   172: putfield h : Lcom/adcolony/sdk/m1;
    //   175: aload #5
    //   177: invokevirtual k : ()Z
    //   180: pop
    //   181: new com/adcolony/sdk/p1
    //   184: dup
    //   185: invokespecial <init> : ()V
    //   188: astore #5
    //   190: aload_0
    //   191: aload #5
    //   193: putfield g : Lcom/adcolony/sdk/p1;
    //   196: aload #5
    //   198: invokevirtual a : ()V
    //   201: aload_0
    //   202: new com/adcolony/sdk/u0
    //   205: dup
    //   206: invokespecial <init> : ()V
    //   209: putfield k : Lcom/adcolony/sdk/u0;
    //   212: aload_0
    //   213: new com/adcolony/sdk/t1
    //   216: dup
    //   217: invokespecial <init> : ()V
    //   220: putfield m : Lcom/adcolony/sdk/t1;
    //   223: aload_0
    //   224: getfield k : Lcom/adcolony/sdk/u0;
    //   227: invokevirtual c : ()V
    //   230: invokestatic a : ()Landroid/content/Context;
    //   233: aload_1
    //   234: invokestatic f : (Landroid/content/Context;Lcom/adcolony/sdk/f;)V
    //   237: iconst_0
    //   238: istore #4
    //   240: iload_2
    //   241: ifne -> 494
    //   244: new java/lang/StringBuilder
    //   247: dup
    //   248: invokespecial <init> : ()V
    //   251: astore_1
    //   252: aload_1
    //   253: aload_0
    //   254: getfield h : Lcom/adcolony/sdk/m1;
    //   257: invokevirtual c : ()Ljava/lang/String;
    //   260: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   263: pop
    //   264: aload_1
    //   265: ldc_w '026ae9c9824b3e483fa6c71fa88f57ae27816141'
    //   268: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   271: pop
    //   272: aload_0
    //   273: new java/io/File
    //   276: dup
    //   277: aload_1
    //   278: invokevirtual toString : ()Ljava/lang/String;
    //   281: invokespecial <init> : (Ljava/lang/String;)V
    //   284: invokevirtual exists : ()Z
    //   287: putfield G : Z
    //   290: new java/lang/StringBuilder
    //   293: dup
    //   294: invokespecial <init> : ()V
    //   297: astore_1
    //   298: aload_1
    //   299: aload_0
    //   300: getfield h : Lcom/adcolony/sdk/m1;
    //   303: invokevirtual c : ()Ljava/lang/String;
    //   306: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   309: pop
    //   310: aload_1
    //   311: ldc_w '7bf3a1e7bbd31e612eda3310c2cdb8075c43c6b5'
    //   314: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   317: pop
    //   318: new java/io/File
    //   321: dup
    //   322: aload_1
    //   323: invokevirtual toString : ()Ljava/lang/String;
    //   326: invokespecial <init> : (Ljava/lang/String;)V
    //   329: invokevirtual exists : ()Z
    //   332: istore_2
    //   333: aload_0
    //   334: iload_2
    //   335: putfield H : Z
    //   338: aload_0
    //   339: getfield G : Z
    //   342: ifeq -> 407
    //   345: iload_2
    //   346: ifeq -> 407
    //   349: new java/lang/StringBuilder
    //   352: dup
    //   353: invokespecial <init> : ()V
    //   356: astore_1
    //   357: aload_1
    //   358: aload_0
    //   359: getfield h : Lcom/adcolony/sdk/m1;
    //   362: invokevirtual c : ()Ljava/lang/String;
    //   365: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   368: pop
    //   369: aload_1
    //   370: ldc_w '026ae9c9824b3e483fa6c71fa88f57ae27816141'
    //   373: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   376: pop
    //   377: aload_1
    //   378: invokevirtual toString : ()Ljava/lang/String;
    //   381: invokestatic z : (Ljava/lang/String;)Lcom/adcolony/sdk/e0;
    //   384: ldc 'sdkVersion'
    //   386: invokestatic E : (Lcom/adcolony/sdk/e0;Ljava/lang/String;)Ljava/lang/String;
    //   389: aload_0
    //   390: getfield j : Lcom/adcolony/sdk/b1;
    //   393: invokevirtual i : ()Ljava/lang/String;
    //   396: invokevirtual equals : (Ljava/lang/Object;)Z
    //   399: ifeq -> 407
    //   402: iconst_1
    //   403: istore_2
    //   404: goto -> 409
    //   407: iconst_0
    //   408: istore_2
    //   409: aload_0
    //   410: iload_2
    //   411: putfield F : Z
    //   414: invokestatic b : ()Lcom/adcolony/sdk/l1;
    //   417: new com/adcolony/sdk/p0$m
    //   420: dup
    //   421: aload_0
    //   422: invokespecial <init> : (Lcom/adcolony/sdk/p0;)V
    //   425: invokevirtual f : (Lcom/adcolony/sdk/l1$c;)V
    //   428: aload_0
    //   429: getfield G : Z
    //   432: ifeq -> 481
    //   435: new java/lang/StringBuilder
    //   438: dup
    //   439: invokespecial <init> : ()V
    //   442: astore_1
    //   443: aload_1
    //   444: aload_0
    //   445: getfield h : Lcom/adcolony/sdk/m1;
    //   448: invokevirtual c : ()Ljava/lang/String;
    //   451: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   454: pop
    //   455: aload_1
    //   456: ldc_w '026ae9c9824b3e483fa6c71fa88f57ae27816141'
    //   459: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   462: pop
    //   463: aload_1
    //   464: invokevirtual toString : ()Ljava/lang/String;
    //   467: invokestatic z : (Ljava/lang/String;)Lcom/adcolony/sdk/e0;
    //   470: astore_1
    //   471: aload_0
    //   472: aload_1
    //   473: putfield t : Lcom/adcolony/sdk/e0;
    //   476: aload_0
    //   477: aload_1
    //   478: invokespecial U : (Lcom/adcolony/sdk/e0;)V
    //   481: aload_0
    //   482: aload_0
    //   483: getfield F : Z
    //   486: invokespecial P : (Z)Z
    //   489: pop
    //   490: aload_0
    //   491: invokespecial o : ()V
    //   494: ldc_w 'Module.load'
    //   497: new com/adcolony/sdk/p0$w
    //   500: dup
    //   501: aload_0
    //   502: invokespecial <init> : (Lcom/adcolony/sdk/p0;)V
    //   505: invokestatic g : (Ljava/lang/String;Lcom/adcolony/sdk/o0;)V
    //   508: ldc_w 'Module.unload'
    //   511: new com/adcolony/sdk/p0$x
    //   514: dup
    //   515: aload_0
    //   516: invokespecial <init> : (Lcom/adcolony/sdk/p0;)V
    //   519: invokestatic g : (Ljava/lang/String;Lcom/adcolony/sdk/o0;)V
    //   522: ldc_w 'AdColony.on_configured'
    //   525: new com/adcolony/sdk/p0$y
    //   528: dup
    //   529: aload_0
    //   530: invokespecial <init> : (Lcom/adcolony/sdk/p0;)V
    //   533: invokestatic g : (Ljava/lang/String;Lcom/adcolony/sdk/o0;)V
    //   536: ldc_w 'AdColony.get_app_info'
    //   539: new com/adcolony/sdk/p0$z
    //   542: dup
    //   543: aload_0
    //   544: invokespecial <init> : (Lcom/adcolony/sdk/p0;)V
    //   547: invokestatic g : (Ljava/lang/String;Lcom/adcolony/sdk/o0;)V
    //   550: ldc_w 'AdColony.v4vc_reward'
    //   553: new com/adcolony/sdk/p0$a0
    //   556: dup
    //   557: aload_0
    //   558: invokespecial <init> : (Lcom/adcolony/sdk/p0;)V
    //   561: invokestatic g : (Ljava/lang/String;Lcom/adcolony/sdk/o0;)V
    //   564: ldc_w 'AdColony.zone_info'
    //   567: new com/adcolony/sdk/p0$b0
    //   570: dup
    //   571: aload_0
    //   572: invokespecial <init> : (Lcom/adcolony/sdk/p0;)V
    //   575: invokestatic g : (Ljava/lang/String;Lcom/adcolony/sdk/o0;)V
    //   578: ldc_w 'AdColony.probe_launch_server'
    //   581: new com/adcolony/sdk/p0$a
    //   584: dup
    //   585: aload_0
    //   586: invokespecial <init> : (Lcom/adcolony/sdk/p0;)V
    //   589: invokestatic g : (Ljava/lang/String;Lcom/adcolony/sdk/o0;)V
    //   592: ldc_w 'Crypto.sha1'
    //   595: new com/adcolony/sdk/p0$c
    //   598: dup
    //   599: aload_0
    //   600: invokespecial <init> : (Lcom/adcolony/sdk/p0;)V
    //   603: invokestatic g : (Ljava/lang/String;Lcom/adcolony/sdk/o0;)V
    //   606: ldc_w 'Crypto.crc32'
    //   609: new com/adcolony/sdk/p0$b
    //   612: dup
    //   613: aload_0
    //   614: invokespecial <init> : (Lcom/adcolony/sdk/p0;)V
    //   617: invokestatic g : (Ljava/lang/String;Lcom/adcolony/sdk/o0;)V
    //   620: ldc_w 'Crypto.uuid'
    //   623: new com/adcolony/sdk/p0$d
    //   626: dup
    //   627: aload_0
    //   628: invokespecial <init> : (Lcom/adcolony/sdk/p0;)V
    //   631: invokestatic g : (Ljava/lang/String;Lcom/adcolony/sdk/o0;)V
    //   634: ldc_w 'Device.query_advertiser_info'
    //   637: new com/adcolony/sdk/p0$e
    //   640: dup
    //   641: aload_0
    //   642: invokespecial <init> : (Lcom/adcolony/sdk/p0;)V
    //   645: invokestatic g : (Ljava/lang/String;Lcom/adcolony/sdk/o0;)V
    //   648: ldc_w 'AdColony.controller_version'
    //   651: new com/adcolony/sdk/p0$f
    //   654: dup
    //   655: aload_0
    //   656: invokespecial <init> : (Lcom/adcolony/sdk/p0;)V
    //   659: invokestatic g : (Ljava/lang/String;Lcom/adcolony/sdk/o0;)V
    //   662: ldc_w 'AdColony.provide_signals'
    //   665: new com/adcolony/sdk/p0$g
    //   668: dup
    //   669: aload_0
    //   670: invokespecial <init> : (Lcom/adcolony/sdk/p0;)V
    //   673: invokestatic g : (Ljava/lang/String;Lcom/adcolony/sdk/o0;)V
    //   676: ldc_w 'AdColony.odt_calculate'
    //   679: new com/adcolony/sdk/p0$h
    //   682: dup
    //   683: aload_0
    //   684: invokespecial <init> : (Lcom/adcolony/sdk/p0;)V
    //   687: invokestatic g : (Ljava/lang/String;Lcom/adcolony/sdk/o0;)V
    //   690: ldc_w 'AdColony.odt_cache'
    //   693: new com/adcolony/sdk/p0$i
    //   696: dup
    //   697: aload_0
    //   698: invokespecial <init> : (Lcom/adcolony/sdk/p0;)V
    //   701: invokestatic g : (Ljava/lang/String;Lcom/adcolony/sdk/o0;)V
    //   704: ldc_w 'AdColony.heartbeat'
    //   707: new com/adcolony/sdk/p0$j
    //   710: dup
    //   711: aload_0
    //   712: invokespecial <init> : (Lcom/adcolony/sdk/p0;)V
    //   715: invokestatic g : (Ljava/lang/String;Lcom/adcolony/sdk/o0;)V
    //   718: aload_0
    //   719: getfield h : Lcom/adcolony/sdk/m1;
    //   722: invokestatic x : (Lcom/adcolony/sdk/m1;)I
    //   725: istore_3
    //   726: iload_3
    //   727: iconst_1
    //   728: if_icmpne -> 736
    //   731: iconst_1
    //   732: istore_2
    //   733: goto -> 738
    //   736: iconst_0
    //   737: istore_2
    //   738: aload_0
    //   739: iload_2
    //   740: putfield J : Z
    //   743: iload #4
    //   745: istore_2
    //   746: iload_3
    //   747: iconst_2
    //   748: if_icmpne -> 753
    //   751: iconst_1
    //   752: istore_2
    //   753: aload_0
    //   754: iload_2
    //   755: putfield K : Z
    //   758: new com/adcolony/sdk/p0$k
    //   761: dup
    //   762: aload_0
    //   763: invokespecial <init> : (Lcom/adcolony/sdk/p0;)V
    //   766: invokestatic G : (Ljava/lang/Runnable;)Z
    //   769: pop
    //   770: return
  }
  
  void B(j paramj) {
    this.o = paramj;
  }
  
  d B0() {
    return this.n;
  }
  
  void C(m paramm) {
    this.p = paramm;
  }
  
  void D(u paramu) {
    this.l = paramu;
  }
  
  u D0() {
    return this.l;
  }
  
  HashMap<String, h> F0() {
    return this.q;
  }
  
  boolean H(int paramInt) {
    this.v.remove(Integer.valueOf(paramInt));
    return this.a.o(paramInt);
  }
  
  b1 H0() {
    if (this.j == null) {
      b1 b11 = new b1();
      this.j = b11;
      b11.m();
    } 
    return this.j;
  }
  
  boolean J(q0 paramq0) {
    this.v.remove(Integer.valueOf(paramq0.getModuleId()));
    return this.a.p(paramq0);
  }
  
  d1 K0() {
    if (this.e == null)
      this.e = new d1(); 
    return this.e;
  }
  
  n1 L0() {
    if (this.f == null) {
      n1 n11 = new n1();
      this.f = n11;
      n11.m();
    } 
    return this.f;
  }
  
  h0 N0() {
    if (this.i == null) {
      h0 h01 = new h0();
      this.i = h01;
      h01.o();
    } 
    return this.i;
  }
  
  l0 P0() {
    if (this.a == null) {
      l0 l01 = new l0();
      this.a = l01;
      l01.d();
    } 
    return this.a;
  }
  
  u0 R0() {
    if (this.k == null)
      this.k = new u0(); 
    return this.k;
  }
  
  void T(f paramf) {
    this.r = paramf;
  }
  
  Partner T0() {
    return this.P;
  }
  
  f V0() {
    if (this.r == null)
      this.r = new f(); 
    return this.r;
  }
  
  String W0() {
    return a0;
  }
  
  void X(boolean paramBoolean) {
    this.D.b(false);
    this.C = paramBoolean;
  }
  
  m X0() {
    return this.p;
  }
  
  i1 Y0() {
    if (this.c == null) {
      i1 i11 = new i1();
      this.c = i11;
      i11.l();
    } 
    return this.c;
  }
  
  x Z() {
    if (this.d == null) {
      x x1 = new x();
      this.d = x1;
      x1.K();
    } 
    return this.d;
  }
  
  m1 Z0() {
    if (this.h == null) {
      m1 m11 = new m1();
      this.h = m11;
      m11.k();
    } 
    return this.h;
  }
  
  p1 a() {
    if (this.g == null) {
      p1 p11 = new p1();
      this.g = p11;
      p11.a();
    } 
    return this.g;
  }
  
  HashMap<Integer, w> b() {
    return this.v;
  }
  
  void b0(boolean paramBoolean) {
    this.B = paramBoolean;
  }
  
  HashMap<String, n> c() {
    return this.u;
  }
  
  boolean d() {
    return (this.r != null);
  }
  
  boolean e() {
    return this.B;
  }
  
  boolean f() {
    return this.C;
  }
  
  boolean g() {
    return this.T;
  }
  
  long g0() {
    return this.U;
  }
  
  boolean h() {
    return this.Y;
  }
  
  boolean i() {
    return this.D.c();
  }
  
  void i0(j0 paramj0) {
    this.s = paramj0;
  }
  
  boolean j() {
    return this.A;
  }
  
  void k0(boolean paramBoolean) {
    this.E = paramBoolean;
  }
  
  e0 l0() {
    return this.Q;
  }
  
  void o0(boolean paramBoolean) {
    this.A = paramBoolean;
  }
  
  void p() {
    this.D.b(false);
    this.d.p();
    Object object = this.r.j("force_ad_id");
    if (object instanceof String && !((String)object).isEmpty())
      r(); 
    a.f(q.a(), this.r);
    t();
    this.u.clear();
    this.a.d();
  }
  
  boolean p0(j0 paramj0) {
    if (this.p != null) {
      u1.G(new u(this, paramj0));
      return true;
    } 
    return false;
  }
  
  void q() {
    this.X = 0;
    for (j j1 : this.d.E().values()) {
      if (j1.I()) {
        this.X++;
        j1.f(new r(this));
      } 
    } 
    for (d d2 : this.d.w().values()) {
      this.X++;
      d2.setOnDestroyListenerOrCall(new s(this));
    } 
    if (this.X == 0)
      p(); 
  }
  
  String q0() {
    return this.z;
  }
  
  void r() {
    synchronized (this.d.E()) {
      Iterator<j> iterator = this.d.E().values().iterator();
      while (iterator.hasNext())
        ((j)iterator.next()).L(); 
      this.d.E().clear();
      return;
    } 
  }
  
  void t() {
    H(1);
    for (q0 q0 : this.v.values())
      this.a.p(q0); 
    this.v.clear();
  }
  
  long t0() {
    return this.S;
  }
  
  long v0() {
    return this.V;
  }
  
  void w() {
    this.d.c();
    p();
  }
  
  void x(long paramLong) {
    this.D.a(paramLong);
  }
  
  long x0() {
    return this.W;
  }
  
  void y(d paramd) {
    this.n = paramd;
  }
  
  void z(f paramf) {
    this.D.b(false);
    this.d.p();
    r();
    a.f(q.a(), paramf);
    t();
    this.u.clear();
    this.r = paramf;
    this.a.d();
    Q(true, true);
  }
  
  j z0() {
    return this.o;
  }
  
  class a implements o0 {
    a(p0 this$0) {}
    
    public void a(j0 param1j0) {
      p0.N(this.a, true, true);
    }
  }
  
  class a0 implements o0 {
    a0(p0 this$0) {}
    
    public void a(j0 param1j0) {
      this.a.p0(param1j0);
    }
  }
  
  class b implements o0 {
    b(p0 this$0) {}
    
    public void a(j0 param1j0) {
      e0 e0 = v.q();
      v.u(e0, "crc32", u1.e(v.E(param1j0.a(), "data")));
      param1j0.b(e0).e();
    }
  }
  
  class b0 implements o0 {
    b0(p0 this$0) {}
    
    public void a(j0 param1j0) {
      p0.n0(this.a, param1j0);
    }
  }
  
  class c implements o0 {
    c(p0 this$0) {}
    
    public void a(j0 param1j0) {
      e0 e0 = v.q();
      v.n(e0, "sha1", u1.D(v.E(param1j0.a(), "data")));
      param1j0.b(e0).e();
    }
  }
  
  class d implements o0 {
    d(p0 this$0) {}
    
    public void a(j0 param1j0) {
      int i = v.A(param1j0.a(), "number");
      e0 e0 = v.q();
      v.l(e0, "uuids", u1.g(i));
      param1j0.b(e0).e();
    }
  }
  
  class e implements o0 {
    e(p0 this$0) {}
    
    public void a(j0 param1j0) {
      this.a.H0().u(q.a(), new a(this, param1j0));
    }
    
    class a implements s1<String> {
      a(p0.e this$0, j0 param2j0) {}
      
      public void a(Throwable param2Throwable) {
        (new b0.a()).c("Device.query_advertiser_info").c(" failed with error: ").c(Log.getStackTraceString(param2Throwable)).d(b0.g);
      }
      
      public void b(String param2String) {
        e0 e0 = v.q();
        v.n(e0, "advertiser_id", this.b.a.H0().L());
        v.w(e0, "limit_ad_tracking", this.b.a.H0().a());
        this.a.b(e0).e();
      }
    }
  }
  
  class a implements s1<String> {
    a(p0 this$0, j0 param1j0) {}
    
    public void a(Throwable param1Throwable) {
      (new b0.a()).c("Device.query_advertiser_info").c(" failed with error: ").c(Log.getStackTraceString(param1Throwable)).d(b0.g);
    }
    
    public void b(String param1String) {
      e0 e0 = v.q();
      v.n(e0, "advertiser_id", this.b.a.H0().L());
      v.w(e0, "limit_ad_tracking", this.b.a.H0().a());
      this.a.b(e0).e();
    }
  }
  
  class f implements o0 {
    f(p0 this$0) {}
    
    public void a(j0 param1j0) {
      g1 g1 = this.a.N0().c();
      this.a.H0().H(v.E(param1j0.a(), "version"));
      if (g1 != null)
        g1.k(this.a.H0().U()); 
    }
  }
  
  class g implements o0 {
    g(p0 this$0) {}
    
    public void a(j0 param1j0) {
      p0.u(this.a, v.C(param1j0.a(), "signals"));
    }
  }
  
  class h implements o0 {
    h(p0 this$0) {}
    
    public void a(j0 param1j0) {
      if (this.a.g()) {
        y0.n().h(new a(this, param1j0), this.a.t0());
        return;
      } 
      x0.b b = y0.n().k();
      e0 e0 = v.q();
      if (b != null)
        v.m(e0, "odt", b.d()); 
      param1j0.b(e0).e();
    }
    
    class a implements q1<x0.b> {
      a(p0.h this$0, j0 param2j0) {}
      
      public void a(x0.b param2b) {
        e0 e0 = v.q();
        if (param2b != null)
          v.m(e0, "odt", param2b.d()); 
        this.a.b(e0).e();
      }
    }
  }
  
  class a implements q1<x0.b> {
    a(p0 this$0, j0 param1j0) {}
    
    public void a(x0.b param1b) {
      e0 e0 = v.q();
      if (param1b != null)
        v.m(e0, "odt", param1b.d()); 
      this.a.b(e0).e();
    }
  }
  
  class i implements o0 {
    i(p0 this$0) {}
    
    public void a(j0 param1j0) {
      y0.n().c();
    }
  }
  
  class j implements o0 {
    j(p0 this$0) {}
    
    public void a(j0 param1j0) {
      p0.S0(this.a).c(param1j0);
    }
  }
  
  class k implements Runnable {
    k(p0 this$0) {}
    
    public void run() {
      Context context = q.a();
      if (!p0.K(this.b) && context != null)
        try {
          Omid.activate(context.getApplicationContext());
          p0.M(this.b, true);
        } catch (IllegalArgumentException illegalArgumentException) {
          (new b0.a()).c("IllegalArgumentException when activating Omid").d(b0.i);
          p0.M(this.b, false);
        }  
      if (p0.K(this.b) && p0.R(this.b) == null)
        try {
          p0.v(this.b, Partner.createPartner("AdColony", "4.8.0"));
          return;
        } catch (IllegalArgumentException illegalArgumentException) {
          (new b0.a()).c("IllegalArgumentException when creating Omid Partner").d(b0.i);
          p0.M(this.b, false);
        }  
    }
  }
  
  class l implements Runnable {
    l(p0 this$0) {}
    
    public void run() {
      e0 e0 = v.q();
      v.n(e0, "url", p0.Z);
      v.n(e0, "content_type", "application/json");
      v.n(e0, "content", this.b.H0().Z().toString());
      v.n(e0, "url", p0.Z);
      if (p0.e0(this.b)) {
        e0 e01 = v.q();
        v.n(e01, "request", "la-req-01");
        v.n(e01, "response", "la-res-01");
        v.m(e0, "dictionaries_mapping", e01);
      } 
      p0.Q0(this.b).e(new f1(new j0("WebServices.post", 0, e0), new a(this)));
    }
    
    class a implements f1.a {
      a(p0.l this$0) {}
      
      public void a(f1 param2f1, j0 param2j0, Map<String, List<String>> param2Map) {
        p0.F(this.a.b, param2f1);
      }
    }
  }
  
  class a implements f1.a {
    a(p0 this$0) {}
    
    public void a(f1 param1f1, j0 param1j0, Map<String, List<String>> param1Map) {
      p0.F(this.a.b, param1f1);
    }
  }
  
  class m implements l1.c {
    m(p0 this$0) {}
    
    public void a() {
      y0.n().o();
    }
  }
  
  class n implements Runnable {
    n(p0 this$0, Context param1Context, j0 param1j0) {}
    
    public void run() {
      n0 n0 = n0.W(this.b.getApplicationContext(), this.c);
      p0.h0(this.d).put(Integer.valueOf(n0.getModuleId()), n0);
    }
  }
  
  class o implements Runnable {
    o(p0 this$0) {}
    
    public void run() {
      if (q.h().Y0().q())
        p0.m0(this.b); 
    }
  }
  
  class p implements f1.a {
    p(p0 this$0) {}
    
    public void a(f1 param1f1, j0 param1j0, Map<String, List<String>> param1Map) {
      p0.s0(this.a);
    }
  }
  
  class q implements Runnable {
    q(p0 this$0) {}
    
    public void run() {
      p0.u0(this.b);
    }
  }
  
  class r implements j.f {
    r(p0 this$0) {}
    
    public void a() {
      p0.y0(this.a);
    }
  }
  
  class s implements d.c {
    s(p0 this$0) {}
    
    public void a() {
      p0.y0(this.a);
    }
  }
  
  class t implements q1<w0> {
    t(p0 this$0) {}
    
    public void a(w0 param1w0) {
      y0.n().e(param1w0);
    }
  }
  
  class u implements Runnable {
    u(p0 this$0, j0 param1j0) {}
    
    public void run() {
      p0.A0(this.c).onReward(new l(this.b));
    }
  }
  
  class v implements Application.ActivityLifecycleCallbacks {
    private final Set<Integer> b = new HashSet<Integer>();
    
    v(p0 this$0) {}
    
    public void onActivityCreated(Activity param1Activity, Bundle param1Bundle) {
      if (!p0.C0(this.c).q())
        p0.C0(this.c).k(true); 
      q.c((Context)param1Activity);
    }
    
    public void onActivityDestroyed(Activity param1Activity) {}
    
    public void onActivityPaused(Activity param1Activity) {
      q.d = false;
      p0.C0(this.c).m(false);
    }
    
    public void onActivityResumed(Activity param1Activity) {
      this.b.add(Integer.valueOf(param1Activity.hashCode()));
      q.d = true;
      q.c((Context)param1Activity);
      g1 g1 = this.c.N0().c();
      Context context = q.a();
      if (context != null && p0.C0(this.c).o() && context instanceof r && !((r)context).e)
        return; 
      q.c((Context)param1Activity);
      if (p0.E0(this.c) != null) {
        if (!Objects.equals(v.E(p0.E0(this.c).a(), "m_origin"), ""))
          p0.E0(this.c).b(p0.E0(this.c).a()).e(); 
        p0.a0(this.c, null);
      } 
      p0.Y(this.c, false);
      p0.C0(this.c).r(false);
      if (p0.G0(this.c) && !p0.C0(this.c).q())
        p0.C0(this.c).k(true); 
      p0.C0(this.c).m(true);
      p0.I0(this.c).i();
      if (g1 != null) {
        ScheduledExecutorService scheduledExecutorService = g1.b;
        if (scheduledExecutorService == null || scheduledExecutorService.isShutdown() || g1.b.isTerminated()) {
          a.f((Context)param1Activity, p0.J0(q.h()));
          return;
        } 
        return;
      } 
      a.f((Context)param1Activity, p0.J0(q.h()));
    }
    
    public void onActivitySaveInstanceState(Activity param1Activity, Bundle param1Bundle) {}
    
    public void onActivityStarted(Activity param1Activity) {
      p0.C0(this.c).n(true);
    }
    
    public void onActivityStopped(Activity param1Activity) {
      this.b.remove(Integer.valueOf(param1Activity.hashCode()));
      if (this.b.isEmpty())
        p0.C0(this.c).n(false); 
    }
  }
  
  class w implements o0 {
    w(p0 this$0) {}
    
    public void a(j0 param1j0) {
      p0.L(this.a, param1j0);
    }
  }
  
  class x implements o0 {
    x(p0 this$0) {}
    
    public void a(j0 param1j0) {
      p0.W(this.a, param1j0);
    }
  }
  
  class y implements o0 {
    y(p0 this$0) {}
    
    public void a(j0 param1j0) {
      g1 g1 = this.a.N0().c();
      p0.w0(this.a).b(true);
      if (p0.M0(this.a)) {
        e0 e01 = v.q();
        e0 e02 = v.q();
        v.n(e02, "app_version", u1.J());
        v.m(e01, "app_bundle_info", e02);
        (new j0("AdColony.on_update", 1, e01)).e();
        p0.f0(this.a, false);
      } 
      if (p0.O0(this.a))
        (new j0("AdColony.on_install", 1)).e(); 
      e0 e0 = param1j0.a();
      if (g1 != null)
        g1.l(v.E(e0, "app_session_id")); 
      if (i.b())
        i.c(); 
      Integer integer = e0.D("base_download_threads");
      if (integer != null)
        p0.Q0(this.a).d(integer.intValue()); 
      integer = e0.D("concurrent_requests");
      if (integer != null)
        p0.Q0(this.a).g(integer.intValue()); 
      integer = e0.D("threads_keep_alive_time");
      if (integer != null)
        p0.Q0(this.a).h(integer.intValue()); 
      double d = e0.C("thread_pool_scaling_factor");
      if (!Double.isNaN(d))
        p0.Q0(this.a).c(d); 
      p0.S0(this.a).f();
      p0.U0(this.a);
    }
  }
  
  class z implements o0 {
    z(p0 this$0) {}
    
    public void a(j0 param1j0) {
      p0.j0(this.a, param1j0);
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Hill race-dex2jar.jar!\com\adcolony\sdk\p0.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */