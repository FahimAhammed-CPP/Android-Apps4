package com.adcolony.sdk;

import java.io.UnsupportedEncodingException;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;

class z {
  static String a(String paramString) throws NoSuchAlgorithmException, UnsupportedEncodingException {
    MessageDigest messageDigest = MessageDigest.getInstance("SHA-1");
    messageDigest.update(paramString.getBytes("iso-8859-1"), 0, paramString.length());
    return b(messageDigest.digest());
  }
  
  private static String b(byte[] paramArrayOfbyte) {
    StringBuilder stringBuilder = new StringBuilder();
    int j = paramArrayOfbyte.length;
    int i = 0;
    label18: while (i < j) {
      byte b = paramArrayOfbyte[i];
      int m = b >>> 4 & 0xF;
      for (int k = 0;; k++) {
        if (m >= 0 && m <= 9) {
          m += 48;
        } else {
          m = m - 10 + 97;
        } 
        stringBuilder.append((char)m);
        m = b & 0xF;
        if (k >= 1) {
          i++;
          continue label18;
        } 
      } 
    } 
    return stringBuilder.toString();
  }
}


/* Location:              C:\soft\dex2jar-2.0\Hill race-dex2jar.jar!\com\adcolony\sdk\z.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */