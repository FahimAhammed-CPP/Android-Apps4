package com.adcolony.sdk;

public abstract class e {
  String a = "";
  
  c b;
  
  z0 c;
  
  c a() {
    return this.b;
  }
  
  void a(c paramc) {
    this.b = paramc;
  }
  
  void a(z0 paramz0) {
    this.c = paramz0;
  }
  
  void a(String paramString) {
    this.a = paramString;
  }
  
  z0 b() {
    return this.c;
  }
  
  String c() {
    return this.a;
  }
  
  public void onClicked(d paramd) {}
  
  public void onClosed(d paramd) {}
  
  public void onLeftApplication(d paramd) {}
  
  public void onOpened(d paramd) {}
  
  public abstract void onRequestFilled(d paramd);
  
  public void onRequestNotFilled(n paramn) {}
  
  public void onShow(d paramd) {}
}


/* Location:              C:\soft\dex2jar-2.0\Hill race-dex2jar.jar!\com\adcolony\sdk\e.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */