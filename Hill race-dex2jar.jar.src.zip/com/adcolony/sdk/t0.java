package com.adcolony.sdk;

class t0 implements o0 {
  t0() {
    q.g("CustomMessage.controller_send", this);
  }
  
  public void a(j0 paramj0) {
    e0 e0 = paramj0.a();
    u1.G(new a(this, v.E(e0, "type"), v.E(e0, "message")));
  }
  
  class a implements Runnable {
    a(t0 this$0, String param1String1, String param1String2) {}
    
    public void run() {
      try {
        h h = q.h().F0().get(this.b);
        if (h != null)
          h.a(new g(this.b, this.c)); 
        return;
      } catch (RuntimeException runtimeException) {
        return;
      } 
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Hill race-dex2jar.jar!\com\adcolony\sdk\t0.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */