package com.adcolony.sdk;

import android.content.Context;
import android.content.Intent;
import android.graphics.Rect;
import android.graphics.drawable.Drawable;
import android.graphics.drawable.GradientDrawable;
import android.net.Uri;
import android.view.View;
import android.view.ViewGroup;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.AbsoluteLayout;
import android.widget.ImageView;
import com.iab.omid.library.adcolony.adsession.FriendlyObstructionPurpose;
import i1.i0;
import java.io.File;

public final class s0 extends w {
  private final int G;
  
  private ImageView H;
  
  private String I;
  
  private String J;
  
  private int K;
  
  private int L;
  
  private boolean M;
  
  private boolean N;
  
  public s0(Context paramContext, int paramInt1, j0 paramj0, int paramInt2) {
    super(paramContext, paramInt1, paramj0);
    this.G = paramInt2;
    this.I = "";
    this.J = "";
  }
  
  private final void Y() {
    Context context = q.a();
    if (context != null && getParentContainer() != null && !this.N) {
      GradientDrawable gradientDrawable = new GradientDrawable();
      gradientDrawable.setColor(-1);
      gradientDrawable.setShape(1);
      ImageView imageView = new ImageView(context);
      imageView.setImageURI(Uri.fromFile(new File(this.I)));
      imageView.setBackground((Drawable)gradientDrawable);
      imageView.setOnClickListener(new g(this));
      i0 i0 = i0.a;
      this.H = imageView;
      Z();
      addView((View)this.H);
    } 
  }
  
  private final void Z() {
    int i;
    int j;
    ImageView imageView = this.H;
    if (imageView == null)
      return; 
    Rect rect = q.h().H0().c0();
    if (this.M) {
      i = getCurrentX() + getCurrentWidth();
    } else {
      i = rect.width();
    } 
    if (this.M) {
      j = getCurrentY() + getCurrentHeight();
    } else {
      j = rect.height();
    } 
    float f = q.h().H0().Y();
    int k = (int)(this.K * f);
    int m = (int)(this.L * f);
    imageView.setLayoutParams((ViewGroup.LayoutParams)new AbsoluteLayout.LayoutParams(k, m, i - k, j - m));
  }
  
  public final void X() {
    ImageView imageView = this.H;
    if (imageView == null)
      return; 
    u u = getParentContainer();
    if (u == null)
      return; 
    u.g((View)imageView, FriendlyObstructionPurpose.OTHER);
  }
  
  private final class a extends w.c {
    public a(s0 this$0) {
      super(this$0);
    }
    
    public void onPageFinished(WebView param1WebView, String param1String) {
      (new s0.f(this.c)).a();
      super.onPageFinished(param1WebView, param1String);
    }
  }
  
  private final class b extends w.d {
    public b(s0 this$0) {
      super(this$0);
    }
    
    public void onPageFinished(WebView param1WebView, String param1String) {
      (new s0.f(this.d)).a();
      super.onPageFinished(param1WebView, param1String);
    }
  }
  
  private final class c extends w.e {
    public c(s0 this$0) {
      super(this$0);
    }
    
    public void onPageFinished(WebView param1WebView, String param1String) {
      (new s0.f(this.e)).a();
      super.onPageFinished(param1WebView, param1String);
    }
  }
  
  private final class d extends w.f {
    public d(s0 this$0) {
      super(this$0);
    }
    
    public void onPageFinished(WebView param1WebView, String param1String) {
      (new s0.f(this.e)).a();
      super.onPageFinished(param1WebView, param1String);
    }
  }
  
  private final class e extends w.g {
    public e(s0 this$0) {
      super(this$0);
    }
    
    public void onPageFinished(WebView param1WebView, String param1String) {
      (new s0.f(this.f)).a();
      super.onPageFinished(param1WebView, param1String);
    }
  }
  
  private final class f {
    public f(s0 this$0) {}
    
    public final void a() {
      if (!this.a.getModuleInitialized()) {
        float f1 = q.h().H0().Y();
        e0 e0 = this.a.getInfo();
        s0 s01 = this.a;
        v.u(e0, "app_orientation", u1.N(u1.U()));
        v.u(e0, "x", u1.d((View)s01));
        v.u(e0, "y", u1.w((View)s01));
        v.u(e0, "width", (int)(s01.getCurrentWidth() / f1));
        v.u(e0, "height", (int)(s01.getCurrentHeight() / f1));
        v.n(e0, "ad_session_id", s01.getAdSessionId());
      } 
    }
  }
  
  static final class g implements View.OnClickListener {
    g(s0 param1s0) {}
    
    public final void onClick(View param1View) {
      u1.n(new Intent("android.intent.action.VIEW", Uri.parse(s0.W(this.b))));
      q.h().a().h(this.b.getAdSessionId());
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Hill race-dex2jar.jar!\com\adcolony\sdk\s0.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */