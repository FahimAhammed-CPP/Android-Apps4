package com.adcolony.sdk;

import android.app.Activity;
import android.content.res.Configuration;
import android.graphics.Rect;
import android.os.Build;
import android.os.Bundle;
import android.view.View;
import android.view.ViewGroup;
import android.view.ViewParent;
import android.widget.FrameLayout;
import java.util.Iterator;
import java.util.Map;

class r extends Activity {
  u b;
  
  int c = -1;
  
  int d;
  
  boolean e;
  
  boolean f;
  
  boolean g;
  
  boolean h;
  
  boolean i;
  
  boolean j;
  
  void a() {
    Rect rect;
    p0 p0 = q.h();
    if (this.b == null)
      this.b = p0.D0(); 
    u u1 = this.b;
    if (u1 == null)
      return; 
    u1.v(false);
    if (u1.W())
      this.b.v(true); 
    if (this.h) {
      rect = p0.H0().d0();
    } else {
      rect = p0.H0().c0();
    } 
    if (rect.width() > 0 && rect.height() > 0) {
      e0 e01 = v.q();
      e0 e02 = v.q();
      float f = p0.H0().Y();
      v.u(e02, "width", (int)(rect.width() / f));
      v.u(e02, "height", (int)(rect.height() / f));
      v.u(e02, "app_orientation", u1.N(u1.U()));
      v.u(e02, "x", 0);
      v.u(e02, "y", 0);
      v.n(e02, "ad_session_id", this.b.b());
      v.u(e01, "screen_width", rect.width());
      v.u(e01, "screen_height", rect.height());
      v.n(e01, "ad_session_id", this.b.b());
      v.u(e01, "id", this.b.q());
      this.b.setLayoutParams((ViewGroup.LayoutParams)new FrameLayout.LayoutParams(rect.width(), rect.height()));
      this.b.n(rect.width());
      this.b.d(rect.height());
      (new j0("MRAID.on_size_change", this.b.J(), e02)).e();
      (new j0("AdContainer.on_orientation_change", this.b.J(), e01)).e();
    } 
  }
  
  void b(int paramInt) {
    if (paramInt != 0) {
      if (paramInt != 1) {
        setRequestedOrientation(4);
      } else {
        setRequestedOrientation(6);
      } 
    } else {
      setRequestedOrientation(7);
    } 
    this.c = paramInt;
  }
  
  void c(j0 paramj0) {
    int i = v.A(paramj0.a(), "status");
    if ((i != 5 && i != 0 && i != 6 && i != 1) || this.e)
      return; 
    p0 p0 = q.h();
    d1 d1 = p0.K0();
    p0.i0(paramj0);
    if (d1.a() != null) {
      d1.a().dismiss();
      d1.d(null);
    } 
    if (!this.g)
      finish(); 
    this.e = true;
    ((ViewGroup)getWindow().getDecorView()).removeAllViews();
    p0.o0(false);
    e0 e0 = v.q();
    v.n(e0, "id", this.b.b());
    (new j0("AdSession.on_close", this.b.J(), e0)).e();
    p0.D(null);
    p0.B(null);
    p0.y(null);
    q.h().Z().E().remove(this.b.b());
  }
  
  void d(boolean paramBoolean) {
    Iterator<Map.Entry> iterator = this.b.L().entrySet().iterator();
    while (iterator.hasNext() && !isFinishing()) {
      p p = (p)((Map.Entry)iterator.next()).getValue();
      if (!p.D() && p.j().isPlaying())
        p.H(); 
    } 
    j j = q.h().z0();
    if (j != null && j.D() && j.v().m() != null && paramBoolean && this.i)
      j.v().f("pause"); 
  }
  
  void e(boolean paramBoolean) {
    Iterator<Map.Entry> iterator = this.b.L().entrySet().iterator();
    while (iterator.hasNext()) {
      p p = (p)((Map.Entry)iterator.next()).getValue();
      if (!p.D() && !p.j().isPlaying() && !q.h().K0().h())
        p.I(); 
    } 
    j j = q.h().z0();
    if (j != null && j.D() && j.v().m() != null && (!paramBoolean || !this.i) && this.j)
      j.v().f("resume"); 
  }
  
  public void onBackPressed() {
    e0 e0 = v.q();
    v.n(e0, "id", this.b.b());
    (new j0("AdSession.on_back_button", this.b.J(), e0)).e();
  }
  
  public void onConfigurationChanged(Configuration paramConfiguration) {
    super.onConfigurationChanged(paramConfiguration);
    if (this instanceof AdColonyInterstitialActivity) {
      a();
      return;
    } 
    ((AdColonyAdViewActivity)this).g();
  }
  
  public void onCreate(Bundle paramBundle) {
    super.onCreate(paramBundle);
    if (!q.k() || q.h().D0() == null) {
      finish();
      return;
    } 
    p0 p0 = q.h();
    this.g = false;
    u u1 = p0.D0();
    this.b = u1;
    u1.v(false);
    if (u1.W())
      this.b.v(true); 
    this.b.b();
    this.d = this.b.J();
    boolean bool = p0.V0().i();
    this.h = bool;
    if (bool) {
      getWindow().addFlags(2048);
      getWindow().clearFlags(1024);
    } else {
      getWindow().addFlags(1024);
      getWindow().clearFlags(2048);
    } 
    requestWindowFeature(1);
    getWindow().getDecorView().setBackgroundColor(-16777216);
    if (p0.V0().g())
      getWindow().addFlags(128); 
    ViewParent viewParent = this.b.getParent();
    if (viewParent != null)
      ((ViewGroup)viewParent).removeView((View)this.b); 
    setContentView((View)this.b);
    this.b.F().add(q.b("AdSession.finish_fullscreen_ad", new a(this), true));
    this.b.H().add("AdSession.finish_fullscreen_ad");
    b(this.c);
    if (!this.b.N()) {
      e0 e0 = v.q();
      v.n(e0, "id", this.b.b());
      v.u(e0, "screen_width", this.b.t());
      v.u(e0, "screen_height", this.b.l());
      (new j0("AdSession.on_fullscreen_ad_started", this.b.J(), e0)).e();
      this.b.x(true);
      return;
    } 
    a();
  }
  
  public void onDestroy() {
    super.onDestroy();
    if (q.k()) {
      if (this.b == null)
        return; 
      if (!this.e && (Build.VERSION.SDK_INT < 24 || !u1.W()) && !this.b.P()) {
        e0 e0 = v.q();
        v.n(e0, "id", this.b.b());
        (new j0("AdSession.on_error", this.b.J(), e0)).e();
        this.g = true;
      } 
    } 
  }
  
  public void onPause() {
    super.onPause();
    d(this.f);
    this.f = false;
  }
  
  public void onResume() {
    super.onResume();
    a();
    e(this.f);
    this.f = true;
    this.j = true;
  }
  
  public void onWindowFocusChanged(boolean paramBoolean) {
    if (paramBoolean && this.f) {
      q.h().Y0().g(true);
      e(this.f);
      this.i = true;
      return;
    } 
    if (!paramBoolean && this.f) {
      q.h().Y0().c(true);
      d(this.f);
      this.i = false;
    } 
  }
  
  class a implements o0 {
    a(r this$0) {}
    
    public void a(j0 param1j0) {
      this.a.c(param1j0);
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Hill race-dex2jar.jar!\com\adcolony\sdk\r.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */