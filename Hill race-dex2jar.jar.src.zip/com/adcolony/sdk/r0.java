package com.adcolony.sdk;

import android.content.Context;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import u1.j;

public final class r0 extends n0 {
  public static final f H = new f(null);
  
  public static boolean I;
  
  private r0(Context paramContext, j0 paramj0) {
    super(paramContext, 1, paramj0);
  }
  
  public static final r0 X(Context paramContext, j0 paramj0) {
    return H.a(paramContext, paramj0);
  }
  
  private final class a extends n0.a {
    public a(r0 this$0) {
      super(this$0);
    }
    
    public void onPageFinished(WebView param1WebView, String param1String) {
      (new r0.g(this.d)).a();
      super.onPageFinished(param1WebView, param1String);
    }
  }
  
  private final class b extends n0.b {
    public b(r0 this$0) {
      super(this$0);
    }
    
    public void onPageFinished(WebView param1WebView, String param1String) {
      (new r0.g(this.e)).a();
      super.onPageFinished(param1WebView, param1String);
    }
  }
  
  private final class c extends n0.c {
    public c(r0 this$0) {
      super(this$0);
    }
    
    public void onPageFinished(WebView param1WebView, String param1String) {
      (new r0.g(this.f)).a();
      super.onPageFinished(param1WebView, param1String);
    }
  }
  
  private final class d extends n0.d {
    public d(r0 this$0) {
      super(this$0);
    }
    
    public void onPageFinished(WebView param1WebView, String param1String) {
      (new r0.g(this.f)).a();
      super.onPageFinished(param1WebView, param1String);
    }
  }
  
  private final class e extends n0.e {
    public e(r0 this$0) {
      super(this$0);
    }
    
    public void onPageFinished(WebView param1WebView, String param1String) {
      (new r0.g(this.g)).a();
      super.onPageFinished(param1WebView, param1String);
    }
  }
  
  public static final class f {
    private f() {}
    
    public final r0 a(Context param1Context, j0 param1j0) {
      r0 r0 = new r0(param1Context, param1j0, null);
      r0.u();
      return r0;
    }
  }
  
  private final class g {
    public g(r0 this$0) {}
    
    public final void a() {
      if (!this.a.getModuleInitialized()) {
        c0 c0 = new c0();
        for (j j : q.h().Z().I()) {
          e0 e0 = new e0();
          v.n(e0, "ad_session_id", j.m());
          v.n(e0, "ad_id", j.b());
          v.n(e0, "zone_id", j.B());
          v.n(e0, "ad_request_id", j.y());
          c0.a(e0);
        } 
        v.l(this.a.getInfo(), "ads_to_restore", c0);
      } 
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Hill race-dex2jar.jar!\com\adcolony\sdk\r0.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */