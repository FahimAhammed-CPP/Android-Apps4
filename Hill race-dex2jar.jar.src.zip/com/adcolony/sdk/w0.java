package com.adcolony.sdk;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import org.json.JSONException;

class w0 {
  private final int a;
  
  private final List<a> b = new ArrayList<a>();
  
  w0(e0 parame0) throws JSONException {
    this.a = parame0.m("version");
    for (e0 e01 : v.x(parame0.s("streams")))
      this.b.add(new a(e01)); 
  }
  
  static w0 b(e0 parame0) {
    try {
      return new w0(parame0);
    } catch (JSONException jSONException) {
      return null;
    } 
  }
  
  a a(String paramString) {
    if (paramString.isEmpty())
      return null; 
    for (a a : this.b) {
      String[] arrayOfString = a.b(a);
      int j = arrayOfString.length;
      boolean bool = false;
      int i;
      for (i = 0; i < j; i++) {
        if (paramString.equals(arrayOfString[i]))
          return a; 
      } 
      arrayOfString = a.d(a);
      j = arrayOfString.length;
      for (i = bool; i < j; i++) {
        if (paramString.equals(arrayOfString[i]))
          return a; 
      } 
    } 
    return null;
  }
  
  List<a> c() {
    return this.b;
  }
  
  int d() {
    return this.a;
  }
  
  static class a {
    private final String a;
    
    private final String b;
    
    private final int c;
    
    private final String[] d;
    
    private final String[] e;
    
    private final List<w0.b> f;
    
    private final List<w0.c> g;
    
    private final w0.d h;
    
    private final Map<String, String> i;
    
    a(e0 param1e0) throws JSONException {
      String[] arrayOfString2;
      String[] arrayOfString1;
      this.f = new ArrayList<w0.b>();
      this.g = new ArrayList<w0.c>();
      this.a = param1e0.x("stream");
      this.b = param1e0.x("table_name");
      this.c = param1e0.b("max_rows", 10000);
      c0 c02 = param1e0.G("event_types");
      byte b = 0;
      if (c02 != null) {
        arrayOfString2 = v.p(c02);
      } else {
        arrayOfString2 = new String[0];
      } 
      this.d = arrayOfString2;
      c0 c01 = param1e0.G("request_types");
      if (c01 != null) {
        arrayOfString1 = v.p(c01);
      } else {
        arrayOfString1 = new String[0];
      } 
      this.e = arrayOfString1;
      for (e0 e02 : v.x(param1e0.s("columns")))
        this.f.add(new w0.b(e02)); 
      e0[] arrayOfE0 = v.x(param1e0.s("indexes"));
      int j = arrayOfE0.length;
      for (int i = b; i < j; i++) {
        e0 e02 = arrayOfE0[i];
        this.g.add(new w0.c(e02, this.b));
      } 
      e0 e01 = param1e0.I("ttl");
      if (e01 != null) {
        w0.d d1 = new w0.d(e01);
      } else {
        e01 = null;
      } 
      this.h = (w0.d)e01;
      this.i = param1e0.H("queries").z();
    }
    
    List<w0.b> a() {
      return this.f;
    }
    
    List<w0.c> c() {
      return this.g;
    }
    
    int e() {
      return this.c;
    }
    
    String f() {
      return this.a;
    }
    
    Map<String, String> g() {
      return this.i;
    }
    
    String h() {
      return this.b;
    }
    
    w0.d i() {
      return this.h;
    }
  }
  
  static class b {
    private final String a;
    
    private final String b;
    
    private final Object c;
    
    b(e0 param1e0) throws JSONException {
      this.a = param1e0.x("name");
      this.b = param1e0.x("type");
      this.c = param1e0.J("default");
    }
    
    Object a() {
      return this.c;
    }
    
    String b() {
      return this.a;
    }
    
    String c() {
      return this.b;
    }
  }
  
  static class c {
    private final String a;
    
    private final String[] b;
    
    c(e0 param1e0, String param1String) throws JSONException {
      StringBuilder stringBuilder = new StringBuilder();
      stringBuilder.append(param1String);
      stringBuilder.append("_");
      stringBuilder.append(param1e0.x("name"));
      this.a = stringBuilder.toString();
      this.b = v.p(param1e0.s("columns"));
    }
    
    String[] a() {
      return this.b;
    }
    
    String b() {
      return this.a;
    }
  }
  
  static class d {
    private final long a;
    
    private final String b;
    
    d(e0 param1e0) throws JSONException {
      this.a = param1e0.w("seconds");
      this.b = param1e0.x("column");
    }
    
    String a() {
      return this.b;
    }
    
    long b() {
      return this.a;
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Hill race-dex2jar.jar!\com\adcolony\sdk\w0.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */