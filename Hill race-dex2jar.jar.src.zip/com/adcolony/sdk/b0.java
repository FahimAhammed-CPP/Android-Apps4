package com.adcolony.sdk;

class b0 {
  static b0 c = new b0(3, true);
  
  static b0 d = new b0(2, false);
  
  static b0 e = new b0(2, true);
  
  static b0 f = new b0(1, false);
  
  static b0 g = new b0(1, true);
  
  static b0 h = new b0(0, false);
  
  static b0 i = new b0(0, true);
  
  private final int a;
  
  private final boolean b;
  
  b0(int paramInt, boolean paramBoolean) {
    this.a = paramInt;
    this.b = paramBoolean;
  }
  
  private void b(String paramString) {
    q.h().N0().f(this.a, paramString, this.b);
  }
  
  static {
    new b0(3, false);
  }
  
  static class a {
    StringBuilder a = new StringBuilder();
    
    a a(int param1Int) {
      this.a.append(param1Int);
      return this;
    }
    
    a b(Object param1Object) {
      if (param1Object != null) {
        this.a.append(param1Object.toString());
        return this;
      } 
      this.a.append("null");
      return this;
    }
    
    a c(String param1String) {
      this.a.append(param1String);
      return this;
    }
    
    void d(b0 param1b0) {
      b0.a(param1b0, this.a.toString());
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Hill race-dex2jar.jar!\com\adcolony\sdk\b0.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */