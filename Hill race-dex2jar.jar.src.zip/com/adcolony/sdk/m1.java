package com.adcolony.sdk;

import android.content.Context;
import android.os.Build;
import android.os.StatFs;
import java.io.File;

class m1 {
  private String a;
  
  private String b;
  
  private String c;
  
  private String d;
  
  private File e;
  
  private File f;
  
  private File g;
  
  private long b(StatFs paramStatFs) {
    return (Build.VERSION.SDK_INT >= 18) ? e(paramStatFs) : paramStatFs.getAvailableBlocks();
  }
  
  private long e(StatFs paramStatFs) {
    return paramStatFs.getAvailableBlocksLong();
  }
  
  private long g(StatFs paramStatFs) {
    return (Build.VERSION.SDK_INT >= 18) ? i(paramStatFs) : paramStatFs.getBlockSize();
  }
  
  private long i(StatFs paramStatFs) {
    return paramStatFs.getBlockSizeLong();
  }
  
  double a(String paramString) {
    try {
      StatFs statFs = new StatFs(paramString);
      long l1 = b(statFs);
      long l2 = g(statFs);
      return (l1 * l2);
    } catch (RuntimeException runtimeException) {
      return 0.0D;
    } 
  }
  
  String c() {
    return this.a;
  }
  
  void d(e0 parame0) {
    StringBuilder stringBuilder = new StringBuilder();
    stringBuilder.append(c());
    stringBuilder.append("AppVersion");
    v.G(parame0, stringBuilder.toString());
  }
  
  String f() {
    return this.c;
  }
  
  String h() {
    return this.b;
  }
  
  String j() {
    return this.d;
  }
  
  boolean k() {
    p0 p0 = q.h();
    StringBuilder stringBuilder3 = new StringBuilder();
    stringBuilder3.append(l());
    stringBuilder3.append("/adc3/");
    this.a = stringBuilder3.toString();
    stringBuilder3 = new StringBuilder();
    stringBuilder3.append(this.a);
    stringBuilder3.append("media/");
    this.b = stringBuilder3.toString();
    File file3 = new File(this.b);
    this.e = file3;
    if (!file3.isDirectory()) {
      this.e.delete();
      this.e.mkdirs();
    } 
    if (!this.e.isDirectory()) {
      p0.X(true);
      return false;
    } 
    if (a(this.b) < 2.097152E7D) {
      (new b0.a()).c("Not enough memory available at media path, disabling AdColony.").d(b0.f);
      p0.X(true);
      return false;
    } 
    StringBuilder stringBuilder2 = new StringBuilder();
    stringBuilder2.append(l());
    stringBuilder2.append("/adc3/data/");
    this.c = stringBuilder2.toString();
    File file2 = new File(this.c);
    this.f = file2;
    if (!file2.isDirectory())
      this.f.delete(); 
    this.f.mkdirs();
    StringBuilder stringBuilder1 = new StringBuilder();
    stringBuilder1.append(this.a);
    stringBuilder1.append("tmp/");
    this.d = stringBuilder1.toString();
    File file1 = new File(this.d);
    this.g = file1;
    if (!file1.isDirectory()) {
      this.g.delete();
      this.g.mkdirs();
    } 
    return true;
  }
  
  String l() {
    Context context = q.a();
    return (context == null) ? "" : context.getFilesDir().getAbsolutePath();
  }
  
  e0 m() {
    StringBuilder stringBuilder = new StringBuilder();
    stringBuilder.append(c());
    stringBuilder.append("AppVersion");
    if ((new File(stringBuilder.toString())).exists()) {
      stringBuilder = new StringBuilder();
      stringBuilder.append(c());
      stringBuilder.append("AppVersion");
      return v.z(stringBuilder.toString());
    } 
    return v.q();
  }
  
  boolean n() {
    File file = this.e;
    if (file == null || this.f == null || this.g == null)
      return false; 
    if (!file.isDirectory())
      this.e.delete(); 
    if (!this.f.isDirectory())
      this.f.delete(); 
    if (!this.g.isDirectory())
      this.g.delete(); 
    this.e.mkdirs();
    this.f.mkdirs();
    this.g.mkdirs();
    return true;
  }
}


/* Location:              C:\soft\dex2jar-2.0\Hill race-dex2jar.jar!\com\adcolony\sdk\m1.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */