package com.adcolony.sdk;

import android.content.Context;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import u1.j;
import u1.r;

public class n0 extends w {
  public static final f G = new f(null);
  
  protected n0(Context paramContext, int paramInt, j0 paramj0) {
    super(paramContext, paramInt, paramj0);
  }
  
  public static final n0 W(Context paramContext, j0 paramj0) {
    return G.a(paramContext, paramj0);
  }
  
  protected class a extends w.c {
    public a(n0 this$0) {
      super(this$0);
    }
    
    public void onPageFinished(WebView param1WebView, String param1String) {
      super.onPageFinished(param1WebView, param1String);
      (new n0.g(this.c)).a();
    }
  }
  
  protected class b extends w.d {
    public b(n0 this$0) {
      super(this$0);
    }
    
    public void onPageFinished(WebView param1WebView, String param1String) {
      super.onPageFinished(param1WebView, param1String);
      (new n0.g(this.d)).a();
    }
  }
  
  protected class c extends w.e {
    public c(n0 this$0) {
      super(this$0);
    }
    
    public void onPageFinished(WebView param1WebView, String param1String) {
      super.onPageFinished(param1WebView, param1String);
      (new n0.g(this.e)).a();
    }
  }
  
  protected class d extends w.f {
    public d(n0 this$0) {
      super(this$0);
    }
    
    public void onPageFinished(WebView param1WebView, String param1String) {
      super.onPageFinished(param1WebView, param1String);
      (new n0.g(this.e)).a();
    }
  }
  
  protected class e extends w.g {
    public e(n0 this$0) {
      super(this$0);
    }
    
    public void onPageFinished(WebView param1WebView, String param1String) {
      super.onPageFinished(param1WebView, param1String);
      (new n0.g(this.f)).a();
    }
  }
  
  public static final class f {
    private f() {}
    
    public final n0 a(Context param1Context, j0 param1j0) {
      n0 n0;
      int i = q.h().P0().t();
      if (r.a(v.E(param1j0.a(), "type"), "aurora")) {
        n0 = new a0(param1Context, i, param1j0);
      } else {
        n0 = new n0((Context)n0, i, param1j0);
      } 
      n0.u();
      return n0;
    }
  }
  
  private final class g {
    public g(n0 this$0) {}
    
    public final void a() {
      if (!(this.a instanceof r0)) {
        e0 e0 = v.q();
        n0 n01 = this.a;
        v.w(e0, "success", true);
        v.u(e0, "id", n01.getModuleId());
        j0 j02 = this.a.getMessage();
        if (j02 == null)
          return; 
        j0 j01 = j02.b(e0);
        if (j01 == null)
          return; 
        j01.e();
      } 
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Hill race-dex2jar.jar!\com\adcolony\sdk\n0.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */