package com.adcolony.sdk;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.net.Uri;
import android.os.Build;

class p1 {
  private boolean c(j0 paramj0) {
    String str = v.E(paramj0.a(), "ad_session_id");
    if (q.a() instanceof Activity) {
      Activity activity = (Activity)q.a();
    } else {
      paramj0 = null;
    } 
    boolean bool = paramj0 instanceof AdColonyAdViewActivity;
    if (!(paramj0 instanceof r))
      return false; 
    if (bool) {
      ((AdColonyAdViewActivity)paramj0).f();
    } else {
      e0 e0 = v.q();
      v.n(e0, "id", str);
      (new j0("AdSession.on_request_close", ((r)paramj0).d, e0)).e();
    } 
    return true;
  }
  
  private boolean g(String paramString) {
    if ((d)q.h().Z().w().get(paramString) == null)
      return false; 
    e0 e0 = v.q();
    v.n(e0, "ad_session_id", paramString);
    (new j0("MRAID.on_event", 1, e0)).e();
    return true;
  }
  
  private void k(String paramString) {
    if (!u1.q(new g(this, paramString)))
      (new b0.a()).c("Executing ADCSystem.sendOpenCustomMessage failed").d(b0.i); 
  }
  
  private boolean p(j0 paramj0) {
    e0 e0 = paramj0.a();
    x x = q.h().Z();
    String str = v.E(e0, "ad_session_id");
    j j = x.E().get(str);
    d d = x.w().get(str);
    if ((j == null || j.z() == null || j.s() == null) && (d == null || d.getListener() == null))
      return false; 
    if (d == null)
      (new j0("AdUnit.make_in_app_purchase", j.s().J())).e(); 
    b(str);
    g(str);
    return true;
  }
  
  private boolean s(j0 paramj0) {
    e0 e0 = paramj0.a();
    String str1 = v.E(v.C(e0, "clickOverride"), "url");
    String str2 = v.E(e0, "ad_session_id");
    x x = q.h().Z();
    j j = x.E().get(str2);
    d d = x.w().get(str2);
    if (j != null) {
      j.n(str1);
      return true;
    } 
    if (d != null) {
      d.setClickOverride(str1);
      return true;
    } 
    return false;
  }
  
  private boolean t(j0 paramj0) {
    e0 e0 = paramj0.a();
    String str = v.E(e0, "ad_session_id");
    int i = v.A(e0, "orientation");
    x x = q.h().Z();
    d d = x.w().get(str);
    j j = x.E().get(str);
    Context context = q.a();
    if (d != null) {
      d.setOrientation(i);
    } else if (j != null) {
      j.d(i);
    } 
    if (j == null && d == null) {
      (new b0.a()).c("Invalid ad session id sent with set orientation properties message: ").c(str).d(b0.i);
      return false;
    } 
    if (context instanceof r) {
      r r = (r)context;
      if (d == null) {
        i = j.x();
      } else {
        i = d.getOrientation();
      } 
      r.b(i);
    } 
    return true;
  }
  
  private boolean x(j0 paramj0) {
    String str = v.E(paramj0.a(), "ad_session_id");
    d d = q.h().Z().w().get(str);
    if (d == null)
      return false; 
    d.setNoCloseButton(v.t(paramj0.a(), "use_custom_close"));
    return true;
  }
  
  void a() {
    q.g("System.open_store", new h(this));
    q.g("System.telephone", new i(this));
    q.g("System.sms", new j(this));
    q.g("System.vibrate", new k(this));
    q.g("System.open_browser", new l(this));
    q.g("System.mail", new m(this));
    q.g("System.launch_app", new n(this));
    q.g("System.create_calendar_event", new o(this));
    q.g("System.social_post", new p(this));
    q.g("System.make_in_app_purchase", new a(this));
    q.g("System.close", new b(this));
    q.g("System.expand", new c(this));
    q.g("System.use_custom_close", new d(this));
    q.g("System.set_orientation_properties", new e(this));
    q.g("System.click_override", new f(this));
  }
  
  void b(String paramString) {
    x x = q.h().Z();
    j j = x.E().get(paramString);
    if (j != null && j.z() != null && j.C()) {
      j.z().onClicked(j);
      return;
    } 
    d d = x.w().get(paramString);
    if (d != null) {
      e e = d.getListener();
    } else {
      paramString = null;
    } 
    if (d != null && paramString != null && d.f())
      paramString.onClicked(d); 
  }
  
  boolean e(j0 paramj0) {
    // Byte code:
    //   0: invokestatic q : ()Lcom/adcolony/sdk/e0;
    //   3: astore #18
    //   5: aload_1
    //   6: invokevirtual a : ()Lcom/adcolony/sdk/e0;
    //   9: astore #10
    //   11: aload #10
    //   13: ldc 'ad_session_id'
    //   15: invokestatic E : (Lcom/adcolony/sdk/e0;Ljava/lang/String;)Ljava/lang/String;
    //   18: astore #19
    //   20: aload #10
    //   22: ldc_w 'params'
    //   25: invokestatic C : (Lcom/adcolony/sdk/e0;Ljava/lang/String;)Lcom/adcolony/sdk/e0;
    //   28: astore #10
    //   30: aload #10
    //   32: ldc_w 'recurrence'
    //   35: invokestatic C : (Lcom/adcolony/sdk/e0;Ljava/lang/String;)Lcom/adcolony/sdk/e0;
    //   38: astore #20
    //   40: invokestatic c : ()Lcom/adcolony/sdk/c0;
    //   43: astore #12
    //   45: invokestatic c : ()Lcom/adcolony/sdk/c0;
    //   48: astore #15
    //   50: invokestatic c : ()Lcom/adcolony/sdk/c0;
    //   53: astore #13
    //   55: aload #10
    //   57: ldc_w 'description'
    //   60: invokestatic E : (Lcom/adcolony/sdk/e0;Ljava/lang/String;)Ljava/lang/String;
    //   63: astore #17
    //   65: aload #10
    //   67: ldc_w 'location'
    //   70: invokestatic E : (Lcom/adcolony/sdk/e0;Ljava/lang/String;)Ljava/lang/String;
    //   73: pop
    //   74: aload #10
    //   76: ldc_w 'start'
    //   79: invokestatic E : (Lcom/adcolony/sdk/e0;Ljava/lang/String;)Ljava/lang/String;
    //   82: astore #22
    //   84: aload #10
    //   86: ldc_w 'end'
    //   89: invokestatic E : (Lcom/adcolony/sdk/e0;Ljava/lang/String;)Ljava/lang/String;
    //   92: astore #21
    //   94: aload #10
    //   96: ldc_w 'summary'
    //   99: invokestatic E : (Lcom/adcolony/sdk/e0;Ljava/lang/String;)Ljava/lang/String;
    //   102: astore #16
    //   104: aload #20
    //   106: ifnull -> 176
    //   109: aload #20
    //   111: invokevirtual r : ()Z
    //   114: ifne -> 176
    //   117: aload #20
    //   119: ldc_w 'expires'
    //   122: invokestatic E : (Lcom/adcolony/sdk/e0;Ljava/lang/String;)Ljava/lang/String;
    //   125: astore #11
    //   127: aload #20
    //   129: ldc_w 'frequency'
    //   132: invokestatic E : (Lcom/adcolony/sdk/e0;Ljava/lang/String;)Ljava/lang/String;
    //   135: invokestatic getDefault : ()Ljava/util/Locale;
    //   138: invokevirtual toUpperCase : (Ljava/util/Locale;)Ljava/lang/String;
    //   141: astore #10
    //   143: aload #20
    //   145: ldc_w 'daysInWeek'
    //   148: invokestatic d : (Lcom/adcolony/sdk/e0;Ljava/lang/String;)Lcom/adcolony/sdk/c0;
    //   151: astore #12
    //   153: aload #20
    //   155: ldc_w 'daysInMonth'
    //   158: invokestatic d : (Lcom/adcolony/sdk/e0;Ljava/lang/String;)Lcom/adcolony/sdk/c0;
    //   161: astore #15
    //   163: aload #20
    //   165: ldc_w 'daysInYear'
    //   168: invokestatic d : (Lcom/adcolony/sdk/e0;Ljava/lang/String;)Lcom/adcolony/sdk/c0;
    //   171: astore #13
    //   173: goto -> 185
    //   176: ldc_w ''
    //   179: astore #10
    //   181: aload #10
    //   183: astore #11
    //   185: aload #16
    //   187: astore #14
    //   189: aload #16
    //   191: ldc_w ''
    //   194: invokevirtual equals : (Ljava/lang/Object;)Z
    //   197: ifeq -> 204
    //   200: aload #17
    //   202: astore #14
    //   204: aload #22
    //   206: invokestatic V : (Ljava/lang/String;)Ljava/util/Date;
    //   209: astore #16
    //   211: aload #21
    //   213: invokestatic V : (Ljava/lang/String;)Ljava/util/Date;
    //   216: astore #21
    //   218: aload #11
    //   220: invokestatic V : (Ljava/lang/String;)Ljava/util/Date;
    //   223: astore #11
    //   225: aload #16
    //   227: ifnull -> 881
    //   230: aload #21
    //   232: ifnonnull -> 238
    //   235: goto -> 881
    //   238: aload #16
    //   240: invokevirtual getTime : ()J
    //   243: lstore #6
    //   245: aload #21
    //   247: invokevirtual getTime : ()J
    //   250: lstore #8
    //   252: lconst_0
    //   253: lstore #4
    //   255: aload #11
    //   257: ifnull -> 279
    //   260: aload #11
    //   262: invokevirtual getTime : ()J
    //   265: aload #16
    //   267: invokevirtual getTime : ()J
    //   270: lsub
    //   271: ldc2_w 1000
    //   274: ldiv
    //   275: lstore_2
    //   276: goto -> 281
    //   279: lconst_0
    //   280: lstore_2
    //   281: aload #10
    //   283: ldc_w 'DAILY'
    //   286: invokevirtual equals : (Ljava/lang/Object;)Z
    //   289: ifeq -> 306
    //   292: lload_2
    //   293: ldc2_w 86400
    //   296: ldiv
    //   297: lstore_2
    //   298: lload_2
    //   299: lconst_1
    //   300: ladd
    //   301: lstore #4
    //   303: goto -> 366
    //   306: aload #10
    //   308: ldc_w 'WEEKLY'
    //   311: invokevirtual equals : (Ljava/lang/Object;)Z
    //   314: ifeq -> 326
    //   317: lload_2
    //   318: ldc2_w 604800
    //   321: ldiv
    //   322: lstore_2
    //   323: goto -> 298
    //   326: aload #10
    //   328: ldc_w 'MONTHLY'
    //   331: invokevirtual equals : (Ljava/lang/Object;)Z
    //   334: ifeq -> 346
    //   337: lload_2
    //   338: ldc2_w 2629800
    //   341: ldiv
    //   342: lstore_2
    //   343: goto -> 298
    //   346: aload #10
    //   348: ldc_w 'YEARLY'
    //   351: invokevirtual equals : (Ljava/lang/Object;)Z
    //   354: ifeq -> 303
    //   357: lload_2
    //   358: ldc2_w 31557600
    //   361: ldiv
    //   362: lstore_2
    //   363: goto -> 298
    //   366: aload #20
    //   368: ifnull -> 754
    //   371: aload #20
    //   373: invokevirtual r : ()Z
    //   376: ifne -> 754
    //   379: new java/lang/StringBuilder
    //   382: dup
    //   383: invokespecial <init> : ()V
    //   386: astore #11
    //   388: aload #11
    //   390: ldc_w 'FREQ='
    //   393: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   396: pop
    //   397: aload #11
    //   399: aload #10
    //   401: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   404: pop
    //   405: aload #11
    //   407: ldc_w ';COUNT='
    //   410: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   413: pop
    //   414: aload #11
    //   416: lload #4
    //   418: invokevirtual append : (J)Ljava/lang/StringBuilder;
    //   421: pop
    //   422: aload #11
    //   424: invokevirtual toString : ()Ljava/lang/String;
    //   427: astore #16
    //   429: aload #16
    //   431: astore #11
    //   433: aload #16
    //   435: astore #10
    //   437: aload #12
    //   439: invokevirtual e : ()I
    //   442: ifeq -> 517
    //   445: aload #16
    //   447: astore #10
    //   449: aload #12
    //   451: invokestatic j : (Lcom/adcolony/sdk/c0;)Ljava/lang/String;
    //   454: astore #11
    //   456: aload #16
    //   458: astore #10
    //   460: new java/lang/StringBuilder
    //   463: dup
    //   464: invokespecial <init> : ()V
    //   467: astore #12
    //   469: aload #16
    //   471: astore #10
    //   473: aload #12
    //   475: aload #16
    //   477: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   480: pop
    //   481: aload #16
    //   483: astore #10
    //   485: aload #12
    //   487: ldc_w ';BYDAY='
    //   490: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   493: pop
    //   494: aload #16
    //   496: astore #10
    //   498: aload #12
    //   500: aload #11
    //   502: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   505: pop
    //   506: aload #16
    //   508: astore #10
    //   510: aload #12
    //   512: invokevirtual toString : ()Ljava/lang/String;
    //   515: astore #11
    //   517: aload #11
    //   519: astore #12
    //   521: aload #11
    //   523: astore #10
    //   525: aload #15
    //   527: invokevirtual e : ()I
    //   530: ifeq -> 605
    //   533: aload #11
    //   535: astore #10
    //   537: aload #15
    //   539: invokestatic C : (Lcom/adcolony/sdk/c0;)Ljava/lang/String;
    //   542: astore #12
    //   544: aload #11
    //   546: astore #10
    //   548: new java/lang/StringBuilder
    //   551: dup
    //   552: invokespecial <init> : ()V
    //   555: astore #15
    //   557: aload #11
    //   559: astore #10
    //   561: aload #15
    //   563: aload #11
    //   565: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   568: pop
    //   569: aload #11
    //   571: astore #10
    //   573: aload #15
    //   575: ldc_w ';BYMONTHDAY='
    //   578: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   581: pop
    //   582: aload #11
    //   584: astore #10
    //   586: aload #15
    //   588: aload #12
    //   590: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   593: pop
    //   594: aload #11
    //   596: astore #10
    //   598: aload #15
    //   600: invokevirtual toString : ()Ljava/lang/String;
    //   603: astore #12
    //   605: aload #12
    //   607: astore #11
    //   609: aload #12
    //   611: astore #10
    //   613: aload #13
    //   615: invokevirtual e : ()I
    //   618: ifeq -> 693
    //   621: aload #12
    //   623: astore #10
    //   625: aload #13
    //   627: invokestatic C : (Lcom/adcolony/sdk/c0;)Ljava/lang/String;
    //   630: astore #11
    //   632: aload #12
    //   634: astore #10
    //   636: new java/lang/StringBuilder
    //   639: dup
    //   640: invokespecial <init> : ()V
    //   643: astore #13
    //   645: aload #12
    //   647: astore #10
    //   649: aload #13
    //   651: aload #12
    //   653: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   656: pop
    //   657: aload #12
    //   659: astore #10
    //   661: aload #13
    //   663: ldc_w ';BYYEARDAY='
    //   666: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   669: pop
    //   670: aload #12
    //   672: astore #10
    //   674: aload #13
    //   676: aload #11
    //   678: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   681: pop
    //   682: aload #12
    //   684: astore #10
    //   686: aload #13
    //   688: invokevirtual toString : ()Ljava/lang/String;
    //   691: astore #11
    //   693: new android/content/Intent
    //   696: dup
    //   697: ldc_w 'android.intent.action.EDIT'
    //   700: invokespecial <init> : (Ljava/lang/String;)V
    //   703: ldc_w 'vnd.android.cursor.item/event'
    //   706: invokevirtual setType : (Ljava/lang/String;)Landroid/content/Intent;
    //   709: ldc_w 'title'
    //   712: aload #14
    //   714: invokevirtual putExtra : (Ljava/lang/String;Ljava/lang/String;)Landroid/content/Intent;
    //   717: ldc_w 'description'
    //   720: aload #17
    //   722: invokevirtual putExtra : (Ljava/lang/String;Ljava/lang/String;)Landroid/content/Intent;
    //   725: ldc_w 'beginTime'
    //   728: lload #6
    //   730: invokevirtual putExtra : (Ljava/lang/String;J)Landroid/content/Intent;
    //   733: ldc_w 'endTime'
    //   736: lload #8
    //   738: invokevirtual putExtra : (Ljava/lang/String;J)Landroid/content/Intent;
    //   741: ldc_w 'rrule'
    //   744: aload #11
    //   746: invokevirtual putExtra : (Ljava/lang/String;Ljava/lang/String;)Landroid/content/Intent;
    //   749: astore #10
    //   751: goto -> 804
    //   754: new android/content/Intent
    //   757: dup
    //   758: ldc_w 'android.intent.action.EDIT'
    //   761: invokespecial <init> : (Ljava/lang/String;)V
    //   764: ldc_w 'vnd.android.cursor.item/event'
    //   767: invokevirtual setType : (Ljava/lang/String;)Landroid/content/Intent;
    //   770: ldc_w 'title'
    //   773: aload #14
    //   775: invokevirtual putExtra : (Ljava/lang/String;Ljava/lang/String;)Landroid/content/Intent;
    //   778: ldc_w 'description'
    //   781: aload #17
    //   783: invokevirtual putExtra : (Ljava/lang/String;Ljava/lang/String;)Landroid/content/Intent;
    //   786: ldc_w 'beginTime'
    //   789: lload #6
    //   791: invokevirtual putExtra : (Ljava/lang/String;J)Landroid/content/Intent;
    //   794: ldc_w 'endTime'
    //   797: lload #8
    //   799: invokevirtual putExtra : (Ljava/lang/String;J)Landroid/content/Intent;
    //   802: astore #10
    //   804: aload #10
    //   806: invokestatic n : (Landroid/content/Intent;)Z
    //   809: ifeq -> 852
    //   812: aload #18
    //   814: ldc_w 'success'
    //   817: iconst_1
    //   818: invokestatic w : (Lcom/adcolony/sdk/e0;Ljava/lang/String;Z)Z
    //   821: pop
    //   822: aload_1
    //   823: aload #18
    //   825: invokevirtual b : (Lcom/adcolony/sdk/e0;)Lcom/adcolony/sdk/j0;
    //   828: invokevirtual e : ()V
    //   831: aload_0
    //   832: aload #19
    //   834: invokevirtual h : (Ljava/lang/String;)V
    //   837: aload_0
    //   838: aload #19
    //   840: invokevirtual b : (Ljava/lang/String;)V
    //   843: aload_0
    //   844: aload #19
    //   846: invokespecial g : (Ljava/lang/String;)Z
    //   849: pop
    //   850: iconst_1
    //   851: ireturn
    //   852: ldc_w 'Unable to create Calendar Event.'
    //   855: iconst_0
    //   856: invokestatic s : (Ljava/lang/String;I)Z
    //   859: pop
    //   860: aload #18
    //   862: ldc_w 'success'
    //   865: iconst_0
    //   866: invokestatic w : (Lcom/adcolony/sdk/e0;Ljava/lang/String;Z)Z
    //   869: pop
    //   870: aload_1
    //   871: aload #18
    //   873: invokevirtual b : (Lcom/adcolony/sdk/e0;)Lcom/adcolony/sdk/j0;
    //   876: invokevirtual e : ()V
    //   879: iconst_0
    //   880: ireturn
    //   881: ldc_w 'Unable to create Calendar Event'
    //   884: iconst_0
    //   885: invokestatic s : (Ljava/lang/String;I)Z
    //   888: pop
    //   889: aload #18
    //   891: ldc_w 'success'
    //   894: iconst_0
    //   895: invokestatic w : (Lcom/adcolony/sdk/e0;Ljava/lang/String;Z)Z
    //   898: pop
    //   899: aload_1
    //   900: aload #18
    //   902: invokevirtual b : (Lcom/adcolony/sdk/e0;)Lcom/adcolony/sdk/j0;
    //   905: invokevirtual e : ()V
    //   908: iconst_0
    //   909: ireturn
    //   910: astore #11
    //   912: aload #10
    //   914: astore #11
    //   916: goto -> 693
    // Exception table:
    //   from	to	target	type
    //   437	445	910	org/json/JSONException
    //   449	456	910	org/json/JSONException
    //   460	469	910	org/json/JSONException
    //   473	481	910	org/json/JSONException
    //   485	494	910	org/json/JSONException
    //   498	506	910	org/json/JSONException
    //   510	517	910	org/json/JSONException
    //   525	533	910	org/json/JSONException
    //   537	544	910	org/json/JSONException
    //   548	557	910	org/json/JSONException
    //   561	569	910	org/json/JSONException
    //   573	582	910	org/json/JSONException
    //   586	594	910	org/json/JSONException
    //   598	605	910	org/json/JSONException
    //   613	621	910	org/json/JSONException
    //   625	632	910	org/json/JSONException
    //   636	645	910	org/json/JSONException
    //   649	657	910	org/json/JSONException
    //   661	670	910	org/json/JSONException
    //   674	682	910	org/json/JSONException
    //   686	693	910	org/json/JSONException
  }
  
  void h(String paramString) {
    x x = q.h().Z();
    j j = x.E().get(paramString);
    if (j != null && j.z() != null) {
      j.z().onLeftApplication(j);
      return;
    } 
    d d = x.w().get(paramString);
    if (d != null) {
      e e = d.getListener();
    } else {
      paramString = null;
    } 
    if (d != null && paramString != null)
      paramString.onLeftApplication(d); 
  }
  
  boolean i(j0 paramj0) {
    e0 e0 = paramj0.a();
    Context context = q.a();
    if (context != null) {
      if (!q.k())
        return false; 
      String str = v.E(e0, "ad_session_id");
      p0 p0 = q.h();
      d d = p0.Z().w().get(str);
      if (d != null && (d.getTrustedDemandSource() || d.f())) {
        if (p0.B0() == d)
          return false; 
        d.setExpandMessage(paramj0);
        d.setExpandedWidth(v.A(e0, "width"));
        d.setExpandedHeight(v.A(e0, "height"));
        d.setOrientation(v.a(e0, "orientation", -1));
        d.setNoCloseButton(v.t(e0, "use_custom_close"));
        p0.y(d);
        p0.D(d.getContainer());
        Intent intent = new Intent(context, AdColonyAdViewActivity.class);
        g(str);
        b(str);
        u1.n(intent);
        return true;
      } 
    } 
    return false;
  }
  
  boolean l(j0 paramj0) {
    e0 e01 = v.q();
    e0 e02 = paramj0.a();
    String str = v.E(e02, "ad_session_id");
    if (v.t(e02, "deep_link"))
      return r(paramj0); 
    Context context = q.a();
    if (context == null)
      return false; 
    if (u1.n(context.getPackageManager().getLaunchIntentForPackage(v.E(e02, "handle")))) {
      v.w(e01, "success", true);
      paramj0.b(e01).e();
      h(str);
      b(str);
      g(str);
      return true;
    } 
    u1.s("Failed to launch external application.", 0);
    v.w(e01, "success", false);
    paramj0.b(e01).e();
    return false;
  }
  
  boolean n(j0 paramj0) {
    e0 e01 = v.q();
    e0 e02 = paramj0.a();
    c0 c0 = v.d(e02, "recipients");
    boolean bool = v.t(e02, "html");
    String str1 = v.E(e02, "subject");
    String str2 = v.E(e02, "body");
    String str3 = v.E(e02, "ad_session_id");
    String[] arrayOfString = new String[c0.e()];
    for (int i = 0; i < c0.e(); i++)
      arrayOfString[i] = v.s(c0, i); 
    Intent intent = new Intent("android.intent.action.SEND");
    if (!bool)
      intent.setType("plain/text"); 
    intent.putExtra("android.intent.extra.SUBJECT", str1).putExtra("android.intent.extra.TEXT", str2).putExtra("android.intent.extra.EMAIL", arrayOfString);
    if (u1.n(intent)) {
      v.w(e01, "success", true);
      paramj0.b(e01).e();
      h(str3);
      b(str3);
      g(str3);
      return true;
    } 
    u1.s("Failed to send email.", 0);
    v.w(e01, "success", false);
    paramj0.b(e01).e();
    return false;
  }
  
  boolean q(j0 paramj0) {
    e0 e02 = v.q();
    e0 e01 = paramj0.a();
    String str2 = v.E(e01, "url");
    String str3 = v.E(e01, "ad_session_id");
    d d = q.h().Z().w().get(str3);
    if (d != null && !d.getTrustedDemandSource() && !d.f())
      return false; 
    String str1 = str2;
    if (str2.startsWith("browser"))
      str1 = str2.replaceFirst("browser", "http"); 
    str2 = str1;
    if (str1.startsWith("safari"))
      str2 = str1.replaceFirst("safari", "http"); 
    k(str2);
    if (u1.n(new Intent("android.intent.action.VIEW", Uri.parse(str2)))) {
      v.w(e02, "success", true);
      paramj0.b(e02).e();
      h(str3);
      b(str3);
      g(str3);
      return true;
    } 
    u1.s("Failed to launch browser.", 0);
    v.w(e02, "success", false);
    paramj0.b(e02).e();
    return false;
  }
  
  boolean r(j0 paramj0) {
    e0 e01 = v.q();
    e0 e02 = paramj0.a();
    String str2 = v.E(e02, "product_id");
    String str3 = v.E(e02, "ad_session_id");
    String str1 = str2;
    if (str2.equals(""))
      str1 = v.E(e02, "handle"); 
    Intent intent = new Intent("android.intent.action.VIEW", Uri.parse(str1));
    k(str1);
    if (u1.n(intent)) {
      v.w(e01, "success", true);
      paramj0.b(e01).e();
      h(str3);
      b(str3);
      g(str3);
      return true;
    } 
    u1.s("Unable to open.", 0);
    v.w(e01, "success", false);
    paramj0.b(e01).e();
    return false;
  }
  
  boolean u(j0 paramj0) {
    e0 e01 = paramj0.a();
    e0 e02 = v.q();
    String str2 = v.E(e01, "ad_session_id");
    c0 c0 = v.d(e01, "recipients");
    String str1 = "";
    for (int i = 0; i < c0.e(); i++) {
      String str = str1;
      if (i != 0) {
        StringBuilder stringBuilder2 = new StringBuilder();
        stringBuilder2.append(str1);
        stringBuilder2.append(";");
        str = stringBuilder2.toString();
      } 
      StringBuilder stringBuilder1 = new StringBuilder();
      stringBuilder1.append(str);
      stringBuilder1.append(v.s(c0, i));
      str1 = stringBuilder1.toString();
    } 
    StringBuilder stringBuilder = new StringBuilder();
    stringBuilder.append("smsto:");
    stringBuilder.append(str1);
    if (u1.n((new Intent("android.intent.action.VIEW", Uri.parse(stringBuilder.toString()))).putExtra("sms_body", v.E(e01, "body")))) {
      v.w(e02, "success", true);
      paramj0.b(e02).e();
      h(str2);
      b(str2);
      g(str2);
      return true;
    } 
    u1.s("Failed to create sms.", 0);
    v.w(e02, "success", false);
    paramj0.b(e02).e();
    return false;
  }
  
  boolean v(j0 paramj0) {
    e0 e01 = v.q();
    e0 e02 = paramj0.a();
    Intent intent = (new Intent("android.intent.action.SEND")).setType("text/plain");
    StringBuilder stringBuilder = new StringBuilder();
    stringBuilder.append(v.E(e02, "text"));
    stringBuilder.append(" ");
    stringBuilder.append(v.E(e02, "url"));
    intent = intent.putExtra("android.intent.extra.TEXT", stringBuilder.toString());
    String str = v.E(e02, "ad_session_id");
    if (u1.o(intent, true)) {
      v.w(e01, "success", true);
      paramj0.b(e01).e();
      h(str);
      b(str);
      g(str);
      return true;
    } 
    u1.s("Unable to create social post.", 0);
    v.w(e01, "success", false);
    paramj0.b(e01).e();
    return false;
  }
  
  boolean w(j0 paramj0) {
    e0 e01 = v.q();
    e0 e02 = paramj0.a();
    Intent intent = new Intent("android.intent.action.DIAL");
    StringBuilder stringBuilder = new StringBuilder();
    stringBuilder.append("tel:");
    stringBuilder.append(v.E(e02, "phone_number"));
    intent = intent.setData(Uri.parse(stringBuilder.toString()));
    String str = v.E(e02, "ad_session_id");
    if (u1.n(intent)) {
      v.w(e01, "success", true);
      paramj0.b(e01).e();
      h(str);
      b(str);
      g(str);
      return true;
    } 
    u1.s("Failed to dial number.", 0);
    v.w(e01, "success", false);
    paramj0.b(e01).e();
    return false;
  }
  
  boolean y(j0 paramj0) {
    Context context = q.a();
    if (context == null)
      return false; 
    int j = v.a(paramj0.a(), "length_ms", 500);
    e0 e0 = v.q();
    c0 c0 = u1.Q(context);
    int i = 0;
    boolean bool = false;
    while (i < c0.e()) {
      if (v.s(c0, i).equals("android.permission.VIBRATE"))
        bool = true; 
      i++;
    } 
    if (!bool) {
      (new b0.a()).c("No vibrate permission detected.").d(b0.f);
      v.w(e0, "success", false);
      paramj0.b(e0).e();
      return false;
    } 
    if (Build.VERSION.SDK_INT >= 11 && u1.m(context, j)) {
      v.w(e0, "success", true);
      paramj0.b(e0).e();
      return true;
    } 
    v.w(e0, "success", false);
    paramj0.b(e0).e();
    return false;
  }
  
  class a implements o0 {
    a(p1 this$0) {}
    
    public void a(j0 param1j0) {
      p1.d(this.a, param1j0);
    }
  }
  
  class b implements o0 {
    b(p1 this$0) {}
    
    public void a(j0 param1j0) {
      p1.f(this.a, param1j0);
    }
  }
  
  class c implements o0 {
    c(p1 this$0) {}
    
    public void a(j0 param1j0) {
      this.a.i(param1j0);
    }
  }
  
  class d implements o0 {
    d(p1 this$0) {}
    
    public void a(j0 param1j0) {
      p1.j(this.a, param1j0);
    }
  }
  
  class e implements o0 {
    e(p1 this$0) {}
    
    public void a(j0 param1j0) {
      p1.m(this.a, param1j0);
    }
  }
  
  class f implements o0 {
    f(p1 this$0) {}
    
    public void a(j0 param1j0) {
      p1.o(this.a, param1j0);
    }
  }
  
  class g implements Runnable {
    g(p1 this$0, String param1String) {}
    
    public void run() {
      e0 e0 = v.q();
      v.n(e0, "type", "open_hook");
      v.n(e0, "message", this.b);
      (new j0("CustomMessage.controller_send", 0, e0)).e();
    }
  }
  
  class h implements o0 {
    h(p1 this$0) {}
    
    public void a(j0 param1j0) {
      this.a.r(param1j0);
    }
  }
  
  class i implements o0 {
    i(p1 this$0) {}
    
    public void a(j0 param1j0) {
      this.a.w(param1j0);
    }
  }
  
  class j implements o0 {
    j(p1 this$0) {}
    
    public void a(j0 param1j0) {
      this.a.u(param1j0);
    }
  }
  
  class k implements o0 {
    k(p1 this$0) {}
    
    public void a(j0 param1j0) {
      this.a.y(param1j0);
    }
  }
  
  class l implements o0 {
    l(p1 this$0) {}
    
    public void a(j0 param1j0) {
      this.a.q(param1j0);
    }
  }
  
  class m implements o0 {
    m(p1 this$0) {}
    
    public void a(j0 param1j0) {
      this.a.n(param1j0);
    }
  }
  
  class n implements o0 {
    n(p1 this$0) {}
    
    public void a(j0 param1j0) {
      this.a.l(param1j0);
    }
  }
  
  class o implements o0 {
    o(p1 this$0) {}
    
    public void a(j0 param1j0) {
      this.a.e(param1j0);
    }
  }
  
  class p implements o0 {
    p(p1 this$0) {}
    
    public void a(j0 param1j0) {
      this.a.v(param1j0);
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Hill race-dex2jar.jar!\com\adcolony\sdk\p1.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */