package com.adcolony.sdk;

import java.util.concurrent.Executors;
import java.util.concurrent.RejectedExecutionException;
import java.util.concurrent.ScheduledExecutorService;
import java.util.concurrent.ScheduledFuture;
import java.util.concurrent.TimeUnit;

class k1 {
  private final ScheduledExecutorService a;
  
  private ScheduledFuture<?> b;
  
  private ScheduledFuture<?> c;
  
  private final i1 d;
  
  k1(i1 parami1) {
    this.d = parami1;
    this.a = Executors.newSingleThreadScheduledExecutor();
  }
  
  private void b() {
    ScheduledFuture<?> scheduledFuture = this.b;
    if (scheduledFuture != null && !scheduledFuture.isCancelled()) {
      this.b.cancel(false);
      this.b = null;
    } 
  }
  
  private void h() {
    if (this.b == null)
      try {
        this.b = this.a.schedule(new a(this), this.d.a(), TimeUnit.MILLISECONDS);
        return;
      } catch (RejectedExecutionException rejectedExecutionException) {
        (new b0.a()).c("RejectedExecutionException when scheduling session stop ").c(rejectedExecutionException.toString()).d(b0.i);
      }  
  }
  
  private void i() {
    (new b0.a()).c("AdColony session ending, releasing Context.").d(b0.d);
    q.h().b0(true);
    q.c(null);
    this.d.p(true);
    this.d.r(true);
    this.d.v();
    if (q.h().P0().u()) {
      ScheduledFuture<?> scheduledFuture = this.c;
      if (scheduledFuture != null && !scheduledFuture.isCancelled())
        this.c.cancel(false); 
      try {
        this.c = this.a.schedule(new b(this), 10L, TimeUnit.SECONDS);
        return;
      } catch (RejectedExecutionException rejectedExecutionException) {
        (new b0.a()).c("RejectedExecutionException when scheduling message pumping stop ").c(rejectedExecutionException.toString()).d(b0.i);
      } 
    } 
  }
  
  void f() {
    h();
  }
  
  void g() {
    b();
  }
  
  class a implements Runnable {
    a(k1 this$0) {}
    
    public void run() {
      k1.a(this.b, null);
      k1.c(this.b);
    }
  }
  
  class b implements Runnable {
    b(k1 this$0) {}
    
    public void run() {
      if (k1.d(this.b).s()) {
        q.h().P0().x();
        k1.e(this.b, null);
      } 
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Hill race-dex2jar.jar!\com\adcolony\sdk\k1.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */