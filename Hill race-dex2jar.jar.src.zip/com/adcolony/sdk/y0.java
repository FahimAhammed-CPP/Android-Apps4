package com.adcolony.sdk;

import android.content.ContentValues;
import java.util.concurrent.CountDownLatch;
import java.util.concurrent.ExecutorService;

class y0 {
  private static y0 e;
  
  private w0 a;
  
  private final ExecutorService b = u1.X();
  
  private x0.b c = null;
  
  private boolean d = false;
  
  static ContentValues a(e0 parame0, w0.a parama) throws NumberFormatException, NullPointerException {
    ContentValues contentValues = new ContentValues();
    for (w0.b b1 : parama.a()) {
      Object object = parame0.J(b1.b());
      if (object != null) {
        if (object instanceof Boolean) {
          contentValues.put(b1.b(), (Boolean)object);
          continue;
        } 
        if (object instanceof Long) {
          contentValues.put(b1.b(), (Long)object);
          continue;
        } 
        if (object instanceof Double) {
          contentValues.put(b1.b(), (Double)object);
          continue;
        } 
        if (object instanceof Number) {
          object = object;
          if (object.doubleValue() == object.longValue() && "INTEGER".equalsIgnoreCase(b1.c())) {
            contentValues.put(b1.b(), Long.valueOf(object.longValue()));
            continue;
          } 
          contentValues.put(b1.b(), Double.valueOf(object.doubleValue()));
          continue;
        } 
        if (object instanceof String)
          contentValues.put(b1.b(), (String)object); 
      } 
    } 
    return contentValues;
  }
  
  private void i(String paramString, e0 parame0, w0.a parama) {
    try {
      ContentValues contentValues = a(parame0, parama);
      l1.b().i(parama.h(), contentValues);
      l1.b().d(parama, contentValues);
      o();
      return;
    } catch (NumberFormatException numberFormatException) {
    
    } catch (NullPointerException nullPointerException) {}
    nullPointerException.printStackTrace();
    b0.a a2 = new b0.a();
    StringBuilder stringBuilder2 = new StringBuilder();
    stringBuilder2.append("Error parsing event:");
    stringBuilder2.append(paramString);
    stringBuilder2.append(" ");
    b0.a a1 = a2.c(stringBuilder2.toString()).c(parame0.toString());
    StringBuilder stringBuilder1 = new StringBuilder();
    stringBuilder1.append("Schema version: ");
    stringBuilder1.append(this.a.d());
    stringBuilder1.append(" ");
    a1.c(stringBuilder1.toString()).c(" e: ").c(nullPointerException.toString()).d(b0.g);
  }
  
  static y0 n() {
    // Byte code:
    //   0: getstatic com/adcolony/sdk/y0.e : Lcom/adcolony/sdk/y0;
    //   3: ifnonnull -> 37
    //   6: ldc com/adcolony/sdk/y0
    //   8: monitorenter
    //   9: getstatic com/adcolony/sdk/y0.e : Lcom/adcolony/sdk/y0;
    //   12: ifnonnull -> 25
    //   15: new com/adcolony/sdk/y0
    //   18: dup
    //   19: invokespecial <init> : ()V
    //   22: putstatic com/adcolony/sdk/y0.e : Lcom/adcolony/sdk/y0;
    //   25: ldc com/adcolony/sdk/y0
    //   27: monitorexit
    //   28: goto -> 37
    //   31: astore_0
    //   32: ldc com/adcolony/sdk/y0
    //   34: monitorexit
    //   35: aload_0
    //   36: athrow
    //   37: getstatic com/adcolony/sdk/y0.e : Lcom/adcolony/sdk/y0;
    //   40: areturn
    // Exception table:
    //   from	to	target	type
    //   9	25	31	finally
    //   25	28	31	finally
    //   32	35	31	finally
  }
  
  x0.b b(long paramLong) {
    x0.b[] arrayOfB = new x0.b[1];
    CountDownLatch countDownLatch = new CountDownLatch(1);
    h(new a(this, arrayOfB, countDownLatch), paramLong);
    try {
      countDownLatch.await();
    } catch (InterruptedException interruptedException) {}
    return arrayOfB[0];
  }
  
  void c() {
    g(new b(this));
  }
  
  void d(j0 paramj0) {
    if (this.a == null)
      return; 
    e0 e0 = paramj0.a();
    if (e0 == null)
      return; 
    e0 = e0.I("payload");
    if (e0 == null)
      return; 
    String str = e0.K("request_type");
    w0.a a = this.a.a(str);
    if (a != null)
      i(str, e0, a); 
  }
  
  void e(w0 paramw0) {
    this.a = paramw0;
  }
  
  void f(x0.b paramb) {
    this.c = paramb;
    this.d = true;
  }
  
  void g(q1<x0.b> paramq1) {
    h(paramq1, -1L);
  }
  
  void h(q1<x0.b> paramq1, long paramLong) {
    if (this.a == null) {
      paramq1.a(null);
      return;
    } 
    if (this.d) {
      paramq1.a(this.c);
      return;
    } 
    if (!u1.u(this.b, new c(this, paramq1, paramLong)))
      (new b0.a()).c("Execute ADCOdtEventsListener.calculateFeatureVectors failed").d(b0.i); 
  }
  
  x0.b k() {
    return this.c;
  }
  
  void o() {
    this.d = false;
  }
  
  class a implements q1<x0.b> {
    a(y0 this$0, x0.b[] param1ArrayOfb, CountDownLatch param1CountDownLatch) {}
    
    public void a(x0.b param1b) {
      this.a[0] = param1b;
      this.b.countDown();
    }
  }
  
  class b implements q1<x0.b> {
    b(y0 this$0) {}
    
    public void a(x0.b param1b) {}
  }
  
  class c implements Runnable {
    c(y0 this$0, q1 param1q1, long param1Long) {}
    
    public void run() {
      x0.b b;
      q1<x0.b> q11 = this.b;
      if (y0.j(this.d)) {
        b = y0.l(this.d);
      } else {
        b = l1.b().a(y0.m(this.d), this.c);
      } 
      q11.a(b);
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Hill race-dex2jar.jar!\com\adcolony\sdk\y0.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */