package com.adcolony.sdk;

import android.content.Context;
import android.content.Intent;

public class j {
  private k a;
  
  private f b;
  
  private u c;
  
  private b d;
  
  private z0 e;
  
  private int f;
  
  private String g;
  
  private String h;
  
  private final String i;
  
  private String j;
  
  private String k;
  
  private g l;
  
  private boolean m;
  
  private String n;
  
  final u1.b o = new a(this);
  
  j(String paramString1, k paramk, String paramString2) {
    this.a = paramk;
    this.i = paramString2;
    this.g = paramString1;
    this.l = g.b;
  }
  
  private boolean G() {
    String str1 = q.h().R0().h();
    String str2 = A();
    return (str2 == null || str2.length() == 0 || str2.equals(str1) || str2.equals("all") || (str2.equals("online") && (str1.equals("wifi") || str1.equals("cell"))) || (str2.equals("offline") && str1.equals("none")));
  }
  
  public String A() {
    return this.n;
  }
  
  public String B() {
    return this.i;
  }
  
  boolean C() {
    return this.m;
  }
  
  boolean D() {
    return (this.e != null);
  }
  
  public boolean E() {
    g g1 = this.l;
    return (g1 == g.e || g1 == g.f || g1 == g.g);
  }
  
  boolean F() {
    return (this.l == g.c);
  }
  
  boolean H() {
    return (this.l == g.b);
  }
  
  boolean I() {
    return (this.l == g.f);
  }
  
  boolean J() {
    u1.K(this.o);
    Context context = q.a();
    if (context == null || !q.k() || this.o.a())
      return false; 
    q.h().D(this.c);
    q.h().B(this);
    u1.n(new Intent(context, AdColonyInterstitialActivity.class));
    return true;
  }
  
  void K() {
    // Byte code:
    //   0: aload_0
    //   1: monitorenter
    //   2: aload_0
    //   3: invokevirtual N : ()V
    //   6: aload_0
    //   7: getfield b : Lcom/adcolony/sdk/j$f;
    //   10: astore_1
    //   11: aload_1
    //   12: ifnull -> 41
    //   15: aload_0
    //   16: aconst_null
    //   17: putfield b : Lcom/adcolony/sdk/j$f;
    //   20: goto -> 23
    //   23: aload_0
    //   24: monitorexit
    //   25: aload_1
    //   26: ifnull -> 35
    //   29: aload_1
    //   30: invokeinterface a : ()V
    //   35: return
    //   36: astore_1
    //   37: aload_0
    //   38: monitorexit
    //   39: aload_1
    //   40: athrow
    //   41: aconst_null
    //   42: astore_1
    //   43: goto -> 23
    // Exception table:
    //   from	to	target	type
    //   2	11	36	finally
    //   15	20	36	finally
    //   23	25	36	finally
    //   37	39	36	finally
  }
  
  boolean L() {
    O();
    k k1 = this.a;
    if (k1 == null)
      return false; 
    u1.G(new e(this, k1));
    return true;
  }
  
  boolean M() {
    T();
    k k1 = this.a;
    if (k1 == null)
      return false; 
    u1.G(new d(this, k1));
    return true;
  }
  
  void N() {
    this.l = g.g;
  }
  
  void O() {
    this.l = g.e;
  }
  
  public void P(k paramk) {
    this.a = paramk;
  }
  
  public void Q(String paramString) {
    this.n = paramString;
  }
  
  public boolean R() {
    boolean bool1 = q.k();
    boolean bool = false;
    if (!bool1)
      return false; 
    p0 p0 = q.h();
    e0 e0 = v.q();
    v.n(e0, "zone_id", this.i);
    v.u(e0, "type", 0);
    v.n(e0, "id", this.g);
    if (I()) {
      v.u(e0, "request_fail_reason", 24);
      (new b0.a()).c("This ad object has already been shown. Please request a new ad ").c("via AdColony.requestInterstitial.").d(b0.f);
    } else if (this.l == g.e) {
      v.u(e0, "request_fail_reason", 17);
      (new b0.a()).c("This ad object has expired. Please request a new ad via AdColony").c(".requestInterstitial.").d(b0.f);
    } else if (p0.j()) {
      v.u(e0, "request_fail_reason", 23);
      (new b0.a()).c("Can not show ad while an interstitial is already active.").d(b0.f);
    } else if (k(p0.c().get(this.i))) {
      v.u(e0, "request_fail_reason", 11);
    } else if (!G()) {
      v.u(e0, "request_fail_reason", 9);
      (new b0.a()).c("Tried to show interstitial ad during unacceptable network conditions.").d(b0.f);
    } else {
      U();
      q.h().o0(true);
      u1.r(this.o, 5000L);
      bool = true;
    } 
    b b1 = this.d;
    if (b1 != null) {
      v.w(e0, "pre_popup", b1.a);
      v.w(e0, "post_popup", this.d.b);
    } 
    n n = p0.c().get(this.i);
    if (n != null && n.m() && p0.X0() == null)
      (new b0.a()).c("Rewarded ad: show() called with no reward listener set.").d(b0.f); 
    (new j0("AdSession.launch_ad_unit", 1, e0)).e();
    return bool;
  }
  
  void S() {
    this.l = g.c;
  }
  
  void T() {
    this.l = g.d;
  }
  
  void U() {
    this.l = g.f;
  }
  
  String b() {
    String str2 = this.h;
    String str1 = str2;
    if (str2 == null)
      str1 = ""; 
    return str1;
  }
  
  void d(int paramInt) {
    this.f = paramInt;
  }
  
  void e(b paramb) {
    this.d = paramb;
  }
  
  void f(f paramf) {
    // Byte code:
    //   0: aload_0
    //   1: monitorenter
    //   2: aload_0
    //   3: getfield l : Lcom/adcolony/sdk/j$g;
    //   6: getstatic com/adcolony/sdk/j$g.g : Lcom/adcolony/sdk/j$g;
    //   9: if_acmpne -> 17
    //   12: iconst_1
    //   13: istore_2
    //   14: goto -> 24
    //   17: aload_0
    //   18: aload_1
    //   19: putfield b : Lcom/adcolony/sdk/j$f;
    //   22: iconst_0
    //   23: istore_2
    //   24: aload_0
    //   25: monitorexit
    //   26: iload_2
    //   27: ifeq -> 36
    //   30: aload_1
    //   31: invokeinterface a : ()V
    //   36: return
    //   37: astore_1
    //   38: aload_0
    //   39: monitorexit
    //   40: aload_1
    //   41: athrow
    // Exception table:
    //   from	to	target	type
    //   2	12	37	finally
    //   17	22	37	finally
    //   24	26	37	finally
    //   38	40	37	finally
  }
  
  void g(u paramu) {
    this.c = paramu;
  }
  
  void h(e0 parame0) {
    if (!parame0.r())
      this.e = new z0(parame0, this.g); 
  }
  
  void i(String paramString) {
    this.h = paramString;
  }
  
  void j(boolean paramBoolean) {}
  
  boolean k(n paramn) {
    if (paramn != null) {
      if (paramn.i() <= 1)
        return false; 
      if (paramn.a() == 0) {
        paramn.g(paramn.i() - 1);
        return false;
      } 
      paramn.g(paramn.a() - 1);
    } 
    return true;
  }
  
  String m() {
    return this.g;
  }
  
  void n(String paramString) {
    this.j = paramString;
  }
  
  void o(boolean paramBoolean) {
    this.m = paramBoolean;
  }
  
  String q() {
    return this.j;
  }
  
  void r(String paramString) {}
  
  u s() {
    return this.c;
  }
  
  void t(String paramString) {
    this.k = paramString;
  }
  
  public boolean u() {
    q.h().Z().E().remove(this.g);
    return true;
  }
  
  z0 v() {
    return this.e;
  }
  
  void w(String paramString) {
    if (!q.k())
      return; 
    p0 p0 = q.h();
    x x = p0.Z();
    u1.G(new b(this));
    n n = p0.c().get(this.i);
    if (n != null && n.m()) {
      e0 e0 = new e0();
      v.u(e0, "reward_amount", n.j());
      v.n(e0, "reward_name", n.k());
      v.w(e0, "success", true);
      v.n(e0, "zone_id", this.i);
      p0.p0(new j0("AdColony.v4vc_reward", 0, e0));
    } 
    u1.G(new c(this, x, paramString));
  }
  
  int x() {
    return this.f;
  }
  
  String y() {
    return this.k;
  }
  
  public k z() {
    return this.a;
  }
  
  class a implements u1.b {
    private boolean b;
    
    a(j this$0) {}
    
    public boolean a() {
      return this.b;
    }
    
    public void run() {
      // Byte code:
      //   0: aload_0
      //   1: monitorenter
      //   2: aload_0
      //   3: getfield b : Z
      //   6: ifeq -> 12
      //   9: aload_0
      //   10: monitorexit
      //   11: return
      //   12: aload_0
      //   13: iconst_1
      //   14: putfield b : Z
      //   17: aload_0
      //   18: monitorexit
      //   19: invokestatic k : ()Z
      //   22: ifne -> 26
      //   25: return
      //   26: invokestatic h : ()Lcom/adcolony/sdk/p0;
      //   29: astore_1
      //   30: aload_1
      //   31: invokevirtual i : ()Z
      //   34: ifeq -> 41
      //   37: aload_1
      //   38: invokevirtual w : ()V
      //   41: new com/adcolony/sdk/b0$a
      //   44: dup
      //   45: invokespecial <init> : ()V
      //   48: ldc 'Ad show failed due to a native timeout (5000 ms). '
      //   50: invokevirtual c : (Ljava/lang/String;)Lcom/adcolony/sdk/b0$a;
      //   53: astore_1
      //   54: new java/lang/StringBuilder
      //   57: dup
      //   58: invokespecial <init> : ()V
      //   61: astore_2
      //   62: aload_2
      //   63: ldc 'Interstitial with adSessionId('
      //   65: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
      //   68: pop
      //   69: aload_2
      //   70: aload_0
      //   71: getfield c : Lcom/adcolony/sdk/j;
      //   74: invokestatic c : (Lcom/adcolony/sdk/j;)Ljava/lang/String;
      //   77: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
      //   80: pop
      //   81: aload_2
      //   82: ldc '). '
      //   84: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
      //   87: pop
      //   88: aload_1
      //   89: aload_2
      //   90: invokevirtual toString : ()Ljava/lang/String;
      //   93: invokevirtual c : (Ljava/lang/String;)Lcom/adcolony/sdk/b0$a;
      //   96: ldc 'Reloading controller.'
      //   98: invokevirtual c : (Ljava/lang/String;)Lcom/adcolony/sdk/b0$a;
      //   101: getstatic com/adcolony/sdk/b0.i : Lcom/adcolony/sdk/b0;
      //   104: invokevirtual d : (Lcom/adcolony/sdk/b0;)V
      //   107: return
      //   108: astore_1
      //   109: aload_0
      //   110: monitorexit
      //   111: aload_1
      //   112: athrow
      // Exception table:
      //   from	to	target	type
      //   2	11	108	finally
      //   12	19	108	finally
      //   109	111	108	finally
    }
  }
  
  class b implements Runnable {
    b(j this$0) {}
    
    public void run() {
      if (!(q.a() instanceof AdColonyInterstitialActivity) && j.l(this.b) != null)
        j.l(this.b).onOpened(this.b); 
    }
  }
  
  class c implements Runnable {
    c(j this$0, x param1x, String param1String) {}
    
    public void run() {
      Context context = q.a();
      if (context instanceof r) {
        this.b.d(context, v.q(), this.c);
      } else {
        if (j.l(this.d) != null) {
          j.l(this.d).onClosed(this.d);
          this.d.P(null);
        } 
        this.d.K();
        this.d.u();
        q.h().o0(false);
      } 
      if (j.p(this.d) != null) {
        this.b.h(j.p(this.d));
        j.a(this.d, null);
      } 
    }
  }
  
  class d implements Runnable {
    d(j this$0, k param1k) {}
    
    public void run() {
      this.b.onRequestNotFilled(a.a(this.c.B()));
    }
  }
  
  class e implements Runnable {
    e(j this$0, k param1k) {}
    
    public void run() {
      this.b.onExpiring(this.c);
    }
  }
  
  static interface f {
    void a();
  }
  
  enum g {
    b, c, d, e, f, g;
    
    static {
      g g1 = new g("REQUESTED", 0);
      b = g1;
      g g2 = new g("FILLED", 1);
      c = g2;
      g g3 = new g("NOT_FILLED", 2);
      d = g3;
      g g4 = new g("EXPIRED", 3);
      e = g4;
      g g5 = new g("SHOWN", 4);
      f = g5;
      g g6 = new g("CLOSED", 5);
      g = g6;
      h = new g[] { g1, g2, g3, g4, g5, g6 };
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Hill race-dex2jar.jar!\com\adcolony\sdk\j.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */