package com.adcolony.sdk;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.app.Application;
import android.content.Context;

class q {
  @SuppressLint({"StaticFieldLeak"})
  private static Context a;
  
  private static p0 b;
  
  static boolean c = false;
  
  static boolean d = false;
  
  static boolean e = false;
  
  static Context a() {
    return a;
  }
  
  static o0 b(String paramString, o0 paramo0, boolean paramBoolean) {
    h().P0().i(paramString, paramo0);
    return paramo0;
  }
  
  static void c(Context paramContext) {
    a = paramContext;
  }
  
  static void d(Context paramContext, f paramf, boolean paramBoolean) {
    Context context;
    if (paramBoolean && paramContext instanceof Activity) {
      Application application = ((Activity)paramContext).getApplication();
    } else {
      context = paramContext;
    } 
    c(context);
    d = true;
    if (b == null) {
      b = new p0();
      paramf.e(paramContext);
      b.A(paramf, paramBoolean);
    } else {
      paramf.e(paramContext);
      b.z(paramf);
    } 
    e(paramf);
    b1 b1 = b.H0();
    b1.t(paramContext);
    b1.B(paramContext);
    (new b0.a()).c("Configuring AdColony").d(b0.d);
    b.b0(false);
    b.Y0().r(false);
    b.k0(true);
    b.Y0().k(false);
    b.Y0().m(true);
  }
  
  static void e(f paramf) {
    boolean bool;
    if (paramf.f() && (!paramf.m("COPPA") || paramf.l("COPPA"))) {
      bool = true;
    } else {
      bool = false;
    } 
    e = bool;
  }
  
  static void f(String paramString, e0 parame0) {
    e0 e01 = parame0;
    if (parame0 == null)
      e01 = v.q(); 
    v.n(e01, "m_type", paramString);
    h().P0().r(e01);
  }
  
  static void g(String paramString, o0 paramo0) {
    h().P0().i(paramString, paramo0);
  }
  
  static p0 h() {
    if (!k()) {
      Context context = a();
      if (context != null) {
        b = new p0();
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append(context.getFilesDir().getAbsolutePath());
        stringBuilder.append("/adc3/AppInfo");
        String str = v.E(v.z(stringBuilder.toString()), "appId");
        f f = (new f()).a(str);
        b.A(f, false);
      } else {
        return new p0();
      } 
    } 
    return b;
  }
  
  static void i(String paramString, o0 paramo0) {
    h().P0().n(paramString, paramo0);
  }
  
  static boolean j() {
    return (a != null);
  }
  
  static boolean k() {
    return (b != null);
  }
  
  static boolean l() {
    return c;
  }
  
  static void m() {
    h().P0().y();
  }
}


/* Location:              C:\soft\dex2jar-2.0\Hill race-dex2jar.jar!\com\adcolony\sdk\q.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */