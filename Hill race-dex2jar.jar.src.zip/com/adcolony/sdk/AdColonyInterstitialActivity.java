package com.adcolony.sdk;

import android.content.res.Configuration;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;

public class AdColonyInterstitialActivity extends r {
  j k;
  
  private m0 l;
  
  public AdColonyInterstitialActivity() {
    j j1;
    if (!q.k()) {
      j1 = null;
    } else {
      j1 = q.h().z0();
    } 
    this.k = j1;
  }
  
  void c(j0 paramj0) {
    super.c(paramj0);
    x x = q.h().Z();
    e0 e0 = v.C(paramj0.a(), "v4iap");
    c0 c0 = v.d(e0, "product_ids");
    j j1 = this.k;
    if (j1 != null && j1.z() != null) {
      String str = c0.l(0);
      if (str != null)
        this.k.z().onIAPEvent(this.k, str, v.A(e0, "engagement_type")); 
    } 
    x.h(this.b);
    if (this.k != null) {
      x.E().remove(this.k.m());
      if (this.k.z() != null) {
        this.k.z().onClosed(this.k);
        this.k.g(null);
        this.k.P(null);
      } 
      this.k.K();
      this.k = null;
    } 
    m0 m01 = this.l;
    if (m01 != null) {
      m01.a();
      this.l = null;
    } 
  }
  
  public void onCreate(Bundle paramBundle) {
    int i;
    j j1 = this.k;
    if (j1 == null) {
      i = -1;
    } else {
      i = j1.x();
    } 
    this.c = i;
    super.onCreate(paramBundle);
    if (q.k()) {
      j j2 = this.k;
      if (j2 == null)
        return; 
      z0 z0 = j2.v();
      if (z0 != null)
        z0.e(this.b); 
      this.l = new m0(new Handler(Looper.getMainLooper()), this.k);
      if (this.k.z() != null)
        this.k.z().onOpened(this.k); 
    } 
  }
}


/* Location:              C:\soft\dex2jar-2.0\Hill race-dex2jar.jar!\com\adcolony\sdk\AdColonyInterstitialActivity.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */