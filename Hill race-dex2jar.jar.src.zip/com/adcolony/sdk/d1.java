package com.adcolony.sdk;

import android.annotation.SuppressLint;
import android.app.AlertDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.os.Build;

class d1 {
  private j0 a;
  
  private AlertDialog b;
  
  private boolean c;
  
  d1() {
    q.g("Alert.show", new a(this));
  }
  
  @SuppressLint({"InlinedApi"})
  private void e(j0 paramj0) {
    AlertDialog.Builder builder;
    Context context = q.a();
    if (context == null)
      return; 
    if (Build.VERSION.SDK_INT >= 21) {
      builder = new AlertDialog.Builder(context, 16974374);
    } else {
      builder = new AlertDialog.Builder((Context)builder, 16974126);
    } 
    e0 e0 = paramj0.a();
    String str1 = v.E(e0, "message");
    String str2 = v.E(e0, "title");
    String str3 = v.E(e0, "positive");
    String str4 = v.E(e0, "negative");
    builder.setMessage(str1);
    builder.setTitle(str2);
    builder.setPositiveButton(str3, new b(this, paramj0));
    if (!str4.equals(""))
      builder.setNegativeButton(str4, new c(this, paramj0)); 
    builder.setOnCancelListener(new d(this, paramj0));
    u1.G(new e(this, builder));
  }
  
  AlertDialog a() {
    return this.b;
  }
  
  void d(AlertDialog paramAlertDialog) {
    this.b = paramAlertDialog;
  }
  
  boolean h() {
    return this.c;
  }
  
  void i() {
    j0 j01 = this.a;
    if (j01 != null) {
      e(j01);
      this.a = null;
    } 
  }
  
  class a implements o0 {
    a(d1 this$0) {}
    
    public void a(j0 param1j0) {
      if (!q.j() || !(q.a() instanceof android.app.Activity)) {
        (new b0.a()).c("Missing Activity reference, can't build AlertDialog.").d(b0.i);
        return;
      } 
      if (v.t(param1j0.a(), "on_resume")) {
        d1.c(this.a, param1j0);
        return;
      } 
      d1.g(this.a, param1j0);
    }
  }
  
  class b implements DialogInterface.OnClickListener {
    b(d1 this$0, j0 param1j0) {}
    
    public void onClick(DialogInterface param1DialogInterface, int param1Int) {
      d1.b(this.b, null);
      param1DialogInterface.dismiss();
      e0 e0 = v.q();
      v.w(e0, "positive", true);
      d1.f(this.b, false);
      this.a.b(e0).e();
    }
  }
  
  class c implements DialogInterface.OnClickListener {
    c(d1 this$0, j0 param1j0) {}
    
    public void onClick(DialogInterface param1DialogInterface, int param1Int) {
      d1.b(this.b, null);
      param1DialogInterface.dismiss();
      e0 e0 = v.q();
      v.w(e0, "positive", false);
      d1.f(this.b, false);
      this.a.b(e0).e();
    }
  }
  
  class d implements DialogInterface.OnCancelListener {
    d(d1 this$0, j0 param1j0) {}
    
    public void onCancel(DialogInterface param1DialogInterface) {
      d1.b(this.c, null);
      d1.f(this.c, false);
      e0 e0 = v.q();
      v.w(e0, "positive", false);
      this.b.b(e0).e();
    }
  }
  
  class e implements Runnable {
    e(d1 this$0, AlertDialog.Builder param1Builder) {}
    
    public void run() {
      d1.f(this.c, true);
      d1.b(this.c, this.b.show());
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Hill race-dex2jar.jar!\com\adcolony\sdk\d1.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */