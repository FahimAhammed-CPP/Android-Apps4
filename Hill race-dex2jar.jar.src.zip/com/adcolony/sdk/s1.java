package com.adcolony.sdk;

public interface s1<T> {
  void a(T paramT);
  
  void a(Throwable paramThrowable);
}


/* Location:              C:\soft\dex2jar-2.0\Hill race-dex2jar.jar!\com\adcolony\sdk\s1.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */