package com.adcolony.sdk;

import android.annotation.SuppressLint;
import android.content.Context;
import android.graphics.Rect;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.widget.FrameLayout;
import android.widget.TextView;
import android.widget.VideoView;
import com.iab.omid.library.adcolony.adsession.AdSession;
import com.iab.omid.library.adcolony.adsession.FriendlyObstructionPurpose;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;

class u extends FrameLayout {
  VideoView A;
  
  private HashMap<Integer, p> b;
  
  private HashMap<Integer, r1> c;
  
  private HashMap<Integer, t> d;
  
  private HashMap<Integer, j1> e;
  
  private HashMap<Integer, o> f;
  
  private HashMap<Integer, Boolean> g;
  
  private HashMap<Integer, View> h;
  
  private int i;
  
  private int j;
  
  private int k;
  
  private int l;
  
  private String m;
  
  boolean n;
  
  boolean o;
  
  private float p = 0.0F;
  
  private double q = 0.0D;
  
  private int r = 0;
  
  private int s = 0;
  
  private ArrayList<o0> t;
  
  private ArrayList<String> u;
  
  private boolean v;
  
  private boolean w;
  
  private boolean x;
  
  private AdSession y;
  
  Context z;
  
  u(Context paramContext, String paramString) {
    super(paramContext);
    this.z = paramContext;
    this.m = paramString;
    setBackgroundColor(-16777216);
  }
  
  private void c(float paramFloat, double paramDouble) {
    e0 e0 = v.q();
    v.u(e0, "id", this.k);
    v.n(e0, "ad_session_id", this.m);
    v.k(e0, "exposure", paramFloat);
    v.k(e0, "volume", paramDouble);
    (new j0("AdContainer.on_exposure_change", this.l, e0)).e();
  }
  
  private void e(int paramInt1, int paramInt2, t paramt) {
    float f = q.h().H0().Y();
    if (paramt != null) {
      e0 e0 = v.q();
      v.u(e0, "app_orientation", u1.N(u1.U()));
      v.u(e0, "width", (int)(paramt.getCurrentWidth() / f));
      v.u(e0, "height", (int)(paramt.getCurrentHeight() / f));
      v.u(e0, "x", paramInt1);
      v.u(e0, "y", paramInt2);
      v.n(e0, "ad_session_id", this.m);
      (new j0("MRAID.on_size_change", this.l, e0)).e();
    } 
  }
  
  private void k(boolean paramBoolean) {
    double d;
    boolean bool3;
    t t;
    View view = (View)getParent();
    d d1 = q.h().Z().w().get(this.m);
    if (d1 == null) {
      t = null;
    } else {
      t = d1.getWebView();
    } 
    Context context = q.a();
    boolean bool2 = true;
    if (d1 != null) {
      bool3 = true;
    } else {
      bool3 = false;
    } 
    float f = i0.a(view, context, true, paramBoolean, true, bool3);
    if (context == null) {
      d = 0.0D;
    } else {
      d = u1.a(u1.f(context));
    } 
    int i = u1.d((View)t);
    int j = u1.w((View)t);
    boolean bool1 = bool2;
    if (i == this.r)
      if (j != this.s) {
        bool1 = bool2;
      } else {
        bool1 = false;
      }  
    if (bool1) {
      this.r = i;
      this.s = j;
      e(i, j, t);
    } 
    if (this.p != f || this.q != d || bool1)
      c(f, d); 
    this.p = f;
    this.q = d;
  }
  
  private void p(boolean paramBoolean) {
    u1.r(new i(this, paramBoolean), 200L);
  }
  
  boolean A(j0 paramj0) {
    TextView textView;
    x x;
    int i = v.A(paramj0.a(), "id");
    View view = this.h.remove(Integer.valueOf(i));
    if (((Boolean)this.g.remove(Integer.valueOf(i))).booleanValue()) {
      textView = (TextView)this.e.remove(Integer.valueOf(i));
    } else {
      textView = (TextView)this.c.remove(Integer.valueOf(i));
    } 
    if (view == null || textView == null) {
      x = q.h().Z();
      String str = paramj0.c();
      StringBuilder stringBuilder = new StringBuilder();
      stringBuilder.append("");
      stringBuilder.append(i);
      x.l(str, stringBuilder.toString());
      return false;
    } 
    removeView((View)x);
    return true;
  }
  
  HashMap<Integer, Boolean> B() {
    return this.g;
  }
  
  boolean C(j0 paramj0) {
    StringBuilder stringBuilder;
    int i = v.A(paramj0.a(), "id");
    View view = this.h.remove(Integer.valueOf(i));
    p p = this.b.remove(Integer.valueOf(i));
    if (view == null || p == null) {
      x x = q.h().Z();
      String str = paramj0.c();
      stringBuilder = new StringBuilder();
      stringBuilder.append("");
      stringBuilder.append(i);
      x.l(str, stringBuilder.toString());
      return false;
    } 
    if (stringBuilder.r())
      stringBuilder.L(); 
    stringBuilder.d();
    removeView((View)stringBuilder);
    return true;
  }
  
  HashMap<Integer, o> D() {
    return this.f;
  }
  
  boolean E(j0 paramj0) {
    x x;
    int i = v.A(paramj0.a(), "id");
    p0 p0 = q.h();
    View view = this.h.remove(Integer.valueOf(i));
    t t = this.d.remove(Integer.valueOf(i));
    if (t == null || view == null) {
      x = p0.Z();
      String str = paramj0.c();
      StringBuilder stringBuilder = new StringBuilder();
      stringBuilder.append("");
      stringBuilder.append(i);
      x.l(str, stringBuilder.toString());
      return false;
    } 
    if (t instanceof q0)
      x.P0().p((q0)t); 
    removeView((View)t);
    return true;
  }
  
  ArrayList<o0> F() {
    return this.t;
  }
  
  boolean G(j0 paramj0) {
    e0 e0 = paramj0.a();
    return (v.A(e0, "container_id") == this.k && v.E(e0, "ad_session_id").equals(this.m));
  }
  
  ArrayList<String> H() {
    return this.u;
  }
  
  void I(j0 paramj0) {
    boolean bool;
    this.b = new HashMap<Integer, p>();
    this.c = new HashMap<Integer, r1>();
    this.d = new HashMap<Integer, t>();
    this.e = new HashMap<Integer, j1>();
    this.f = new HashMap<Integer, o>();
    this.g = new HashMap<Integer, Boolean>();
    this.h = new HashMap<Integer, View>();
    this.t = new ArrayList<o0>();
    this.u = new ArrayList<String>();
    e0 e0 = paramj0.a();
    if (v.t(e0, "transparent"))
      setBackgroundColor(0); 
    this.k = v.A(e0, "id");
    this.i = v.A(e0, "width");
    this.j = v.A(e0, "height");
    this.l = v.A(e0, "module_id");
    this.o = v.t(e0, "viewability_enabled");
    if (this.k == 1) {
      bool = true;
    } else {
      bool = false;
    } 
    this.v = bool;
    p0 p0 = q.h();
    if (this.i == 0 && this.j == 0) {
      Rect rect;
      if (this.x) {
        rect = p0.H0().d0();
      } else {
        rect = rect.H0().c0();
      } 
      this.i = rect.width();
      this.j = rect.height();
    } else {
      setLayoutParams((ViewGroup.LayoutParams)new FrameLayout.LayoutParams(this.i, this.j));
    } 
    this.t.add(q.b("VideoView.create", new a(this), true));
    this.t.add(q.b("VideoView.destroy", new b(this), true));
    this.t.add(q.b("WebView.create", new c(this), true));
    this.t.add(q.b("WebView.destroy", new d(this), true));
    this.t.add(q.b("TextView.create", new e(this), true));
    this.t.add(q.b("TextView.destroy", new f(this), true));
    this.t.add(q.b("ImageView.create", new g(this), true));
    this.t.add(q.b("ImageView.destroy", new h(this), true));
    this.u.add("VideoView.create");
    this.u.add("VideoView.destroy");
    this.u.add("WebView.create");
    this.u.add("WebView.destroy");
    this.u.add("TextView.create");
    this.u.add("TextView.destroy");
    this.u.add("ImageView.create");
    this.u.add("ImageView.destroy");
    VideoView videoView = new VideoView(this.z);
    this.A = videoView;
    videoView.setVisibility(8);
    addView((View)this.A);
    setClipToPadding(false);
    if (this.o)
      p(v.t(paramj0.a(), "advanced_viewability")); 
  }
  
  int J() {
    return this.l;
  }
  
  HashMap<Integer, r1> K() {
    return this.c;
  }
  
  HashMap<Integer, p> L() {
    return this.b;
  }
  
  HashMap<Integer, t> M() {
    return this.d;
  }
  
  boolean N() {
    return this.w;
  }
  
  boolean O() {
    return this.v;
  }
  
  boolean P() {
    return this.x;
  }
  
  o a(j0 paramj0) {
    int i = v.A(paramj0.a(), "id");
    o o = new o(this.z, paramj0, i, this);
    o.a();
    this.f.put(Integer.valueOf(i), o);
    this.h.put(Integer.valueOf(i), o);
    return o;
  }
  
  String b() {
    return this.m;
  }
  
  void d(int paramInt) {
    this.j = paramInt;
  }
  
  void f(View paramView) {
    AdSession adSession = this.y;
    if (adSession != null && paramView != null)
      try {
        adSession.removeFriendlyObstruction(paramView);
        return;
      } catch (RuntimeException runtimeException) {
        return;
      }  
  }
  
  void g(View paramView, FriendlyObstructionPurpose paramFriendlyObstructionPurpose) {
    AdSession adSession = this.y;
    if (adSession != null && paramView != null)
      try {
        adSession.addFriendlyObstruction(paramView, paramFriendlyObstructionPurpose, null);
        return;
      } catch (RuntimeException runtimeException) {
        return;
      }  
  }
  
  void i(AdSession paramAdSession) {
    this.y = paramAdSession;
    j(this.h);
  }
  
  void j(Map paramMap) {
    if (this.y != null) {
      if (paramMap == null)
        return; 
      Iterator<Map.Entry> iterator = paramMap.entrySet().iterator();
      while (iterator.hasNext())
        g((View)((Map.Entry)iterator.next()).getValue(), FriendlyObstructionPurpose.OTHER); 
    } 
  }
  
  int l() {
    return this.j;
  }
  
  @SuppressLint({"InlinedApi"})
  View m(j0 paramj0) {
    j1 j1;
    e0 e0 = paramj0.a();
    int i = v.A(e0, "id");
    if (v.t(e0, "editable")) {
      j1 = new j1(this.z, paramj0, i, this);
      j1.b();
      this.e.put(Integer.valueOf(i), j1);
      this.h.put(Integer.valueOf(i), j1);
      this.g.put(Integer.valueOf(i), Boolean.TRUE);
      return (View)j1;
    } 
    if (!v.t(e0, "button")) {
      r1 = new r1(this.z, (j0)j1, i, this);
      r1.b();
      this.c.put(Integer.valueOf(i), r1);
      this.h.put(Integer.valueOf(i), r1);
      this.g.put(Integer.valueOf(i), Boolean.FALSE);
      return (View)r1;
    } 
    r1 r1 = new r1(this.z, 16974145, (j0)r1, i, this);
    r1.b();
    this.c.put(Integer.valueOf(i), r1);
    this.h.put(Integer.valueOf(i), r1);
    this.g.put(Integer.valueOf(i), Boolean.FALSE);
    return (View)r1;
  }
  
  void n(int paramInt) {
    this.i = paramInt;
  }
  
  public boolean onInterceptTouchEvent(MotionEvent paramMotionEvent) {
    return false;
  }
  
  @SuppressLint({"ClickableViewAccessibility"})
  public boolean onTouchEvent(MotionEvent paramMotionEvent) {
    int i = paramMotionEvent.getAction() & 0xFF;
    if (i != 0 && i != 1 && i != 3 && i != 2 && i != 5 && i != 6)
      return false; 
    p0 p0 = q.h();
    x x = p0.Z();
    int j = (int)paramMotionEvent.getX();
    int k = (int)paramMotionEvent.getY();
    e0 e0 = v.q();
    v.u(e0, "view_id", -1);
    v.n(e0, "ad_session_id", this.m);
    v.u(e0, "container_x", j);
    v.u(e0, "container_y", k);
    v.u(e0, "view_x", j);
    v.u(e0, "view_y", k);
    v.u(e0, "id", this.k);
    if (i != 0) {
      if (i != 1) {
        if (i != 2) {
          if (i != 3) {
            if (i != 5) {
              if (i != 6)
                return true; 
              i = (paramMotionEvent.getAction() & 0xFF00) >> 8;
              v.u(e0, "container_x", (int)paramMotionEvent.getX(i));
              v.u(e0, "container_y", (int)paramMotionEvent.getY(i));
              v.u(e0, "view_x", (int)paramMotionEvent.getX(i));
              v.u(e0, "view_y", (int)paramMotionEvent.getY(i));
              v.u(e0, "x", (int)paramMotionEvent.getX(i));
              v.u(e0, "y", (int)paramMotionEvent.getY(i));
              if (!this.v)
                p0.y(x.w().get(this.m)); 
              (new j0("AdContainer.on_touch_ended", this.l, e0)).e();
              return true;
            } 
            i = (paramMotionEvent.getAction() & 0xFF00) >> 8;
            v.u(e0, "container_x", (int)paramMotionEvent.getX(i));
            v.u(e0, "container_y", (int)paramMotionEvent.getY(i));
            v.u(e0, "view_x", (int)paramMotionEvent.getX(i));
            v.u(e0, "view_y", (int)paramMotionEvent.getY(i));
            (new j0("AdContainer.on_touch_began", this.l, e0)).e();
            return true;
          } 
          (new j0("AdContainer.on_touch_cancelled", this.l, e0)).e();
          return true;
        } 
        (new j0("AdContainer.on_touch_moved", this.l, e0)).e();
        return true;
      } 
      if (!this.v)
        p0.y(x.w().get(this.m)); 
      (new j0("AdContainer.on_touch_ended", this.l, e0)).e();
      return true;
    } 
    (new j0("AdContainer.on_touch_began", this.l, e0)).e();
    return true;
  }
  
  int q() {
    return this.k;
  }
  
  p r(j0 paramj0) {
    int i = v.A(paramj0.a(), "id");
    p p = new p(this.z, paramj0, i, this);
    p.t();
    this.b.put(Integer.valueOf(i), p);
    this.h.put(Integer.valueOf(i), p);
    return p;
  }
  
  void s(boolean paramBoolean) {
    this.v = paramBoolean;
  }
  
  int t() {
    return this.i;
  }
  
  t u(j0 paramj0) {
    // Byte code:
    //   0: aload_1
    //   1: invokevirtual a : ()Lcom/adcolony/sdk/e0;
    //   4: astore #4
    //   6: aload #4
    //   8: ldc 'id'
    //   10: invokestatic A : (Lcom/adcolony/sdk/e0;Ljava/lang/String;)I
    //   13: istore_2
    //   14: aload #4
    //   16: ldc_w 'is_module'
    //   19: invokestatic t : (Lcom/adcolony/sdk/e0;Ljava/lang/String;)Z
    //   22: istore_3
    //   23: invokestatic h : ()Lcom/adcolony/sdk/p0;
    //   26: astore #5
    //   28: iload_3
    //   29: ifeq -> 93
    //   32: aload #5
    //   34: invokevirtual b : ()Ljava/util/HashMap;
    //   37: aload #4
    //   39: ldc_w 'module_id'
    //   42: invokestatic A : (Lcom/adcolony/sdk/e0;Ljava/lang/String;)I
    //   45: invokestatic valueOf : (I)Ljava/lang/Integer;
    //   48: invokevirtual get : (Ljava/lang/Object;)Ljava/lang/Object;
    //   51: checkcast com/adcolony/sdk/t
    //   54: astore #4
    //   56: aload #4
    //   58: ifnonnull -> 82
    //   61: new com/adcolony/sdk/b0$a
    //   64: dup
    //   65: invokespecial <init> : ()V
    //   68: ldc_w 'Module WebView created with invalid id'
    //   71: invokevirtual c : (Ljava/lang/String;)Lcom/adcolony/sdk/b0$a;
    //   74: getstatic com/adcolony/sdk/b0.h : Lcom/adcolony/sdk/b0;
    //   77: invokevirtual d : (Lcom/adcolony/sdk/b0;)V
    //   80: aconst_null
    //   81: areturn
    //   82: aload #4
    //   84: aload_1
    //   85: iload_2
    //   86: aload_0
    //   87: invokevirtual o : (Lcom/adcolony/sdk/j0;ILcom/adcolony/sdk/u;)V
    //   90: goto -> 105
    //   93: aload_0
    //   94: getfield z : Landroid/content/Context;
    //   97: aload_1
    //   98: iload_2
    //   99: aload_0
    //   100: invokestatic b : (Landroid/content/Context;Lcom/adcolony/sdk/j0;ILcom/adcolony/sdk/u;)Lcom/adcolony/sdk/t;
    //   103: astore #4
    //   105: aload_0
    //   106: getfield d : Ljava/util/HashMap;
    //   109: iload_2
    //   110: invokestatic valueOf : (I)Ljava/lang/Integer;
    //   113: aload #4
    //   115: invokevirtual put : (Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    //   118: pop
    //   119: aload_0
    //   120: getfield h : Ljava/util/HashMap;
    //   123: iload_2
    //   124: invokestatic valueOf : (I)Ljava/lang/Integer;
    //   127: aload #4
    //   129: invokevirtual put : (Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    //   132: pop
    //   133: invokestatic q : ()Lcom/adcolony/sdk/e0;
    //   136: astore #5
    //   138: aload #5
    //   140: ldc_w 'module_id'
    //   143: aload #4
    //   145: invokevirtual getWebViewModuleId : ()I
    //   148: invokestatic u : (Lcom/adcolony/sdk/e0;Ljava/lang/String;I)Z
    //   151: pop
    //   152: aload #4
    //   154: instanceof com/adcolony/sdk/s0
    //   157: ifeq -> 177
    //   160: aload #5
    //   162: ldc_w 'mraid_module_id'
    //   165: aload #4
    //   167: checkcast com/adcolony/sdk/s0
    //   170: invokevirtual getAdcModuleId : ()I
    //   173: invokestatic u : (Lcom/adcolony/sdk/e0;Ljava/lang/String;I)Z
    //   176: pop
    //   177: aload_1
    //   178: aload #5
    //   180: invokevirtual b : (Lcom/adcolony/sdk/e0;)Lcom/adcolony/sdk/j0;
    //   183: invokevirtual e : ()V
    //   186: aload #4
    //   188: areturn
    //   189: astore_1
    //   190: new com/adcolony/sdk/b0$a
    //   193: dup
    //   194: invokespecial <init> : ()V
    //   197: astore #4
    //   199: new java/lang/StringBuilder
    //   202: dup
    //   203: invokespecial <init> : ()V
    //   206: astore #5
    //   208: aload #5
    //   210: aload_1
    //   211: invokevirtual toString : ()Ljava/lang/String;
    //   214: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   217: pop
    //   218: aload #5
    //   220: ldc_w ': during WebView initialization.'
    //   223: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   226: pop
    //   227: aload #4
    //   229: aload #5
    //   231: invokevirtual toString : ()Ljava/lang/String;
    //   234: invokevirtual c : (Ljava/lang/String;)Lcom/adcolony/sdk/b0$a;
    //   237: ldc_w ' Disabling AdColony.'
    //   240: invokevirtual c : (Ljava/lang/String;)Lcom/adcolony/sdk/b0$a;
    //   243: getstatic com/adcolony/sdk/b0.h : Lcom/adcolony/sdk/b0;
    //   246: invokevirtual d : (Lcom/adcolony/sdk/b0;)V
    //   249: invokestatic s : ()Z
    //   252: pop
    //   253: aconst_null
    //   254: areturn
    // Exception table:
    //   from	to	target	type
    //   93	105	189	java/lang/RuntimeException
  }
  
  void v(boolean paramBoolean) {
    this.x = paramBoolean;
  }
  
  HashMap<Integer, View> w() {
    return this.h;
  }
  
  void x(boolean paramBoolean) {
    this.w = paramBoolean;
  }
  
  boolean y(j0 paramj0) {
    StringBuilder stringBuilder;
    int i = v.A(paramj0.a(), "id");
    View view = this.h.remove(Integer.valueOf(i));
    o o = this.f.remove(Integer.valueOf(i));
    if (view == null || o == null) {
      x x = q.h().Z();
      String str = paramj0.c();
      stringBuilder = new StringBuilder();
      stringBuilder.append("");
      stringBuilder.append(i);
      x.l(str, stringBuilder.toString());
      return false;
    } 
    removeView((View)stringBuilder);
    return true;
  }
  
  HashMap<Integer, j1> z() {
    return this.e;
  }
  
  class a implements o0 {
    a(u this$0) {}
    
    public void a(j0 param1j0) {
      if (this.a.G(param1j0)) {
        u u1 = this.a;
        u1.g((View)u1.r(param1j0), FriendlyObstructionPurpose.OTHER);
      } 
    }
  }
  
  class b implements o0 {
    b(u this$0) {}
    
    public void a(j0 param1j0) {
      if (this.a.G(param1j0))
        this.a.C(param1j0); 
    }
  }
  
  class c implements o0 {
    c(u this$0) {}
    
    public void a(j0 param1j0) {
      if (this.a.G(param1j0))
        u1.G(new a(this, param1j0)); 
    }
    
    class a implements Runnable {
      a(u.c this$0, j0 param2j0) {}
      
      public void run() {
        u u = this.c.a;
        u.g((View)u.u(this.b), FriendlyObstructionPurpose.OTHER);
      }
    }
  }
  
  class a implements Runnable {
    a(u this$0, j0 param1j0) {}
    
    public void run() {
      u u = this.c.a;
      u.g((View)u.u(this.b), FriendlyObstructionPurpose.OTHER);
    }
  }
  
  class d implements o0 {
    d(u this$0) {}
    
    public void a(j0 param1j0) {
      if (this.a.G(param1j0))
        u1.G(new a(this, param1j0)); 
    }
    
    class a implements Runnable {
      a(u.d this$0, j0 param2j0) {}
      
      public void run() {
        this.c.a.E(this.b);
      }
    }
  }
  
  class a implements Runnable {
    a(u this$0, j0 param1j0) {}
    
    public void run() {
      this.c.a.E(this.b);
    }
  }
  
  class e implements o0 {
    e(u this$0) {}
    
    public void a(j0 param1j0) {
      if (this.a.G(param1j0)) {
        u u1 = this.a;
        u1.g(u1.m(param1j0), FriendlyObstructionPurpose.OTHER);
      } 
    }
  }
  
  class f implements o0 {
    f(u this$0) {}
    
    public void a(j0 param1j0) {
      if (this.a.G(param1j0))
        this.a.A(param1j0); 
    }
  }
  
  class g implements o0 {
    g(u this$0) {}
    
    public void a(j0 param1j0) {
      if (this.a.G(param1j0)) {
        u u1 = this.a;
        u1.g((View)u1.a(param1j0), FriendlyObstructionPurpose.OTHER);
      } 
    }
  }
  
  class h implements o0 {
    h(u this$0) {}
    
    public void a(j0 param1j0) {
      if (this.a.G(param1j0))
        this.a.y(param1j0); 
    }
  }
  
  class i implements Runnable {
    i(u this$0, boolean param1Boolean) {}
    
    public void run() {
      u u1 = this.c;
      if (!u1.n) {
        u.h(u1, this.b);
        u.o(this.c, this.b);
      } 
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Hill race-dex2jar.jar!\com\adcolony\sd\\u.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */