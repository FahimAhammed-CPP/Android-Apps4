package com.adcolony.sdk;

public class b {
  boolean a;
  
  boolean b;
  
  e0 c = v.q();
  
  public b a(String paramString1, String paramString2) {
    if (paramString1 != null)
      v.n(this.c, paramString1, paramString2); 
    return this;
  }
}


/* Location:              C:\soft\dex2jar-2.0\Hill race-dex2jar.jar!\com\adcolony\sdk\b.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */