package com.adcolony.sdk;

class s {
  private String a;
  
  private String b;
  
  private String c;
  
  public s(String paramString1, String paramString2, String paramString3) {
    this.a = paramString1;
    this.b = paramString2;
    this.c = paramString3;
  }
  
  public String a() {
    return this.c;
  }
  
  public String b() {
    return this.a;
  }
  
  public String c() {
    return this.b;
  }
}


/* Location:              C:\soft\dex2jar-2.0\Hill race-dex2jar.jar!\com\adcolony\sdk\s.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */