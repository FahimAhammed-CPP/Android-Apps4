package com.adcolony.sdk;

public interface m {
  void onReward(l paraml);
}


/* Location:              C:\soft\dex2jar-2.0\Hill race-dex2jar.jar!\com\adcolony\sdk\m.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */