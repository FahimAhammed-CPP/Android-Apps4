package com.adcolony.sdk;

import android.annotation.SuppressLint;
import android.content.Context;
import android.net.Uri;
import android.os.Build;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.webkit.ConsoleMessage;
import android.webkit.JsResult;
import android.webkit.RenderProcessGoneDetail;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceError;
import android.webkit.WebResourceRequest;
import android.webkit.WebResourceResponse;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.FrameLayout;
import i1.i0;
import java.io.ByteArrayInputStream;
import java.io.IOException;
import java.nio.charset.Charset;
import java.util.ArrayList;
import java.util.Objects;
import u1.r;
import u1.s;

public class t extends WebView {
  public static final g v = new g(null);
  
  private final int b;
  
  private final j0 c;
  
  private int d;
  
  private String e;
  
  private String f;
  
  private String g;
  
  private String h;
  
  private String i;
  
  private String j;
  
  private e0 k;
  
  private boolean l;
  
  private u m;
  
  private int n;
  
  private int o;
  
  private int p;
  
  private int q;
  
  private int r;
  
  private int s;
  
  private int t;
  
  private int u;
  
  protected t(Context paramContext, int paramInt, j0 paramj0) {
    super(paramContext);
    this.b = paramInt;
    this.c = paramj0;
    this.e = "";
    this.f = "";
    this.g = "";
    this.h = "";
    this.i = "";
    this.j = "";
    this.k = v.q();
  }
  
  public static final t b(Context paramContext, j0 paramj0, int paramInt, u paramu) {
    return v.a(paramContext, paramj0, paramInt, paramu);
  }
  
  private final void d(int paramInt, String paramString1, String paramString2) {
    u u1 = this.m;
    if (u1 != null) {
      e0 e01 = v.q();
      v.u(e01, "id", this.d);
      v.n(e01, "ad_session_id", getAdSessionId());
      v.u(e01, "container_id", u1.q());
      v.u(e01, "code", paramInt);
      v.n(e01, "error", paramString1);
      v.n(e01, "url", paramString2);
      (new j0("WebView.on_error", u1.J(), e01)).e();
    } 
    b0.a a = (new b0.a()).c("onReceivedError: ");
    paramString2 = paramString1;
    if (paramString1 == null)
      paramString2 = "WebViewErrorMessage: null description"; 
    a.c(paramString2).d(b0.i);
  }
  
  private final void j(j0 paramj0, t1.a<i0> parama) {
    e0 e01 = paramj0.a();
    if (v.A(e01, "id") == this.d) {
      int i = v.A(e01, "container_id");
      u u1 = this.m;
      if (u1 != null && i == u1.q()) {
        i = 1;
      } else {
        i = 0;
      } 
      if (i != 0) {
        String str1;
        String str2 = v.E(e01, "ad_session_id");
        u u2 = this.m;
        if (u2 == null) {
          u2 = null;
        } else {
          str1 = u2.b();
        } 
        if (r.a(str2, str1))
          u1.G(new l(parama)); 
      } 
    } 
  }
  
  private final void k(Exception paramException) {
    (new b0.a()).c(paramException.getClass().toString()).c(" during metadata injection w/ metadata = ").c(v.E(this.k, "metadata")).d(b0.i);
    u u1 = this.m;
    if (u1 == null)
      return; 
    e0 e01 = v.q();
    v.n(e01, "id", getAdSessionId());
    (new j0("AdSession.on_error", u1.J(), e01)).e();
  }
  
  private final void p() {
    u u1 = this.m;
    if (u1 != null) {
      ArrayList<o0> arrayList1 = u1.F();
      if (arrayList1 != null) {
        arrayList1.add(q.b("WebView.execute_js", new h(this), true));
        arrayList1.add(q.b("WebView.set_visible", new i(this), true));
        arrayList1.add(q.b("WebView.set_bounds", new j(this), true));
        arrayList1.add(q.b("WebView.set_transparent", new k(this), true));
      } 
    } 
    u1 = this.m;
    if (u1 == null)
      return; 
    ArrayList<String> arrayList = u1.H();
    if (arrayList == null)
      return; 
    arrayList.add("WebView.execute_js");
    arrayList.add("WebView.set_visible");
    arrayList.add("WebView.set_bounds");
    arrayList.add("WebView.set_transparent");
  }
  
  private final WebViewClient s() {
    int i = Build.VERSION.SDK_INT;
    return (i >= 26) ? getWebViewClientApi26() : ((i >= 24) ? getWebViewClientApi24() : ((i >= 23) ? getWebViewClientApi23() : ((i >= 21) ? getWebViewClientApi21() : getWebViewClientDefault())));
  }
  
  private final void setTransparent(boolean paramBoolean) {
    byte b;
    if (paramBoolean) {
      b = 0;
    } else {
      b = -1;
    } 
    setBackgroundColor(b);
  }
  
  public final int getCurrentHeight() {
    return this.q;
  }
  
  public final int getCurrentWidth() {
    return this.p;
  }
  
  public final int getCurrentX() {
    return this.n;
  }
  
  public final int getCurrentY() {
    return this.o;
  }
  
  public final int getInitialHeight() {
    return this.u;
  }
  
  public final int getInitialWidth() {
    return this.t;
  }
  
  public final int getInitialX() {
    return this.r;
  }
  
  public final int getInitialY() {
    return this.s;
  }
  
  public final int getWebViewModuleId() {
    return this.b;
  }
  
  public final void h(j0 paramj0) {
    setBounds(paramj0);
  }
  
  public final void o(j0 paramj0, int paramInt, u paramu) {
    i(paramj0, paramInt, paramu);
    q();
  }
  
  public boolean onTouchEvent(MotionEvent paramMotionEvent) {
    boolean bool;
    if (paramMotionEvent != null && paramMotionEvent.getAction() == 1) {
      bool = true;
    } else {
      bool = false;
    } 
    if (bool) {
      d d = getAdView();
      if (d != null && !d.f()) {
        e0 e01 = v.q();
        v.n(e01, "ad_session_id", getAdSessionId());
        (new j0("WebView.on_first_click", 1, e01)).e();
        d.setUserInteraction(true);
      } 
      j j = getInterstitial();
      if (j != null)
        j.o(true); 
    } 
    return super.onTouchEvent(paramMotionEvent);
  }
  
  public final void r() {
    q.h().Z().g(this, this.i, this.m);
  }
  
  public final void x() {
    if (!this.l) {
      this.l = true;
      u1.G(new m(this));
    } 
  }
  
  private final class a extends WebChromeClient {
    public a(t this$0) {}
    
    public boolean onConsoleMessage(ConsoleMessage param1ConsoleMessage) {
      // Byte code:
      //   0: aconst_null
      //   1: astore #9
      //   3: aload_1
      //   4: ifnonnull -> 13
      //   7: aconst_null
      //   8: astore #8
      //   10: goto -> 19
      //   13: aload_1
      //   14: invokevirtual messageLevel : ()Landroid/webkit/ConsoleMessage$MessageLevel;
      //   17: astore #8
      //   19: aload_1
      //   20: ifnonnull -> 29
      //   23: aconst_null
      //   24: astore #7
      //   26: goto -> 35
      //   29: aload_1
      //   30: invokevirtual message : ()Ljava/lang/String;
      //   33: astore #7
      //   35: iconst_0
      //   36: istore #6
      //   38: aload #7
      //   40: ifnonnull -> 46
      //   43: goto -> 65
      //   46: aload #7
      //   48: ldc 'Viewport target-densitydpi is not supported.'
      //   50: iconst_0
      //   51: iconst_2
      //   52: aconst_null
      //   53: invokestatic K : (Ljava/lang/CharSequence;Ljava/lang/CharSequence;ZILjava/lang/Object;)Z
      //   56: iconst_1
      //   57: if_icmpne -> 65
      //   60: iconst_1
      //   61: istore_2
      //   62: goto -> 67
      //   65: iconst_0
      //   66: istore_2
      //   67: iload_2
      //   68: ifne -> 112
      //   71: aload #7
      //   73: ifnonnull -> 79
      //   76: goto -> 98
      //   79: aload #7
      //   81: ldc 'Viewport argument key "shrink-to-fit" not recognized and ignored'
      //   83: iconst_0
      //   84: iconst_2
      //   85: aconst_null
      //   86: invokestatic K : (Ljava/lang/CharSequence;Ljava/lang/CharSequence;ZILjava/lang/Object;)Z
      //   89: iconst_1
      //   90: if_icmpne -> 98
      //   93: iconst_1
      //   94: istore_2
      //   95: goto -> 100
      //   98: iconst_0
      //   99: istore_2
      //   100: iload_2
      //   101: ifeq -> 107
      //   104: goto -> 112
      //   107: iconst_0
      //   108: istore_2
      //   109: goto -> 114
      //   112: iconst_1
      //   113: istore_2
      //   114: aload #8
      //   116: getstatic android/webkit/ConsoleMessage$MessageLevel.ERROR : Landroid/webkit/ConsoleMessage$MessageLevel;
      //   119: if_acmpne -> 127
      //   122: iconst_1
      //   123: istore_3
      //   124: goto -> 129
      //   127: iconst_0
      //   128: istore_3
      //   129: aload #8
      //   131: getstatic android/webkit/ConsoleMessage$MessageLevel.WARNING : Landroid/webkit/ConsoleMessage$MessageLevel;
      //   134: if_acmpne -> 143
      //   137: iconst_1
      //   138: istore #4
      //   140: goto -> 146
      //   143: iconst_0
      //   144: istore #4
      //   146: aload #7
      //   148: ifnonnull -> 154
      //   151: goto -> 174
      //   154: aload #7
      //   156: ldc 'ADC3_update is not defined'
      //   158: iconst_0
      //   159: iconst_2
      //   160: aconst_null
      //   161: invokestatic K : (Ljava/lang/CharSequence;Ljava/lang/CharSequence;ZILjava/lang/Object;)Z
      //   164: iconst_1
      //   165: if_icmpne -> 174
      //   168: iconst_1
      //   169: istore #5
      //   171: goto -> 177
      //   174: iconst_0
      //   175: istore #5
      //   177: iload #5
      //   179: ifne -> 220
      //   182: aload #7
      //   184: ifnonnull -> 194
      //   187: iload #6
      //   189: istore #5
      //   191: goto -> 215
      //   194: iload #6
      //   196: istore #5
      //   198: aload #7
      //   200: ldc 'NativeLayer.dispatch_messages is not a function'
      //   202: iconst_0
      //   203: iconst_2
      //   204: aconst_null
      //   205: invokestatic K : (Ljava/lang/CharSequence;Ljava/lang/CharSequence;ZILjava/lang/Object;)Z
      //   208: iconst_1
      //   209: if_icmpne -> 215
      //   212: iconst_1
      //   213: istore #5
      //   215: iload #5
      //   217: ifeq -> 273
      //   220: aload_0
      //   221: getfield a : Lcom/adcolony/sdk/t;
      //   224: astore #10
      //   226: aload #10
      //   228: invokevirtual getMessage : ()Lcom/adcolony/sdk/j0;
      //   231: astore_1
      //   232: aload_1
      //   233: ifnonnull -> 242
      //   236: aload #9
      //   238: astore_1
      //   239: goto -> 247
      //   242: aload_1
      //   243: invokevirtual a : ()Lcom/adcolony/sdk/e0;
      //   246: astore_1
      //   247: aload_1
      //   248: astore #8
      //   250: aload_1
      //   251: ifnonnull -> 263
      //   254: new com/adcolony/sdk/e0
      //   257: dup
      //   258: invokespecial <init> : ()V
      //   261: astore #8
      //   263: aload #10
      //   265: aload #8
      //   267: ldc 'Unable to communicate with AdColony. Please ensure that you have added an exception for our Javascript interface in your ProGuard configuration and that you do not have a faulty proxy enabled on your device.'
      //   269: invokevirtual m : (Lcom/adcolony/sdk/e0;Ljava/lang/String;)Z
      //   272: pop
      //   273: iload_2
      //   274: ifne -> 400
      //   277: iload #4
      //   279: ifne -> 286
      //   282: iload_3
      //   283: ifeq -> 400
      //   286: aload_0
      //   287: getfield a : Lcom/adcolony/sdk/t;
      //   290: invokevirtual getInterstitial : ()Lcom/adcolony/sdk/j;
      //   293: astore_1
      //   294: aload_1
      //   295: ifnonnull -> 301
      //   298: goto -> 315
      //   301: aload_1
      //   302: invokevirtual b : ()Ljava/lang/String;
      //   305: astore #8
      //   307: aload #8
      //   309: astore_1
      //   310: aload #8
      //   312: ifnonnull -> 318
      //   315: ldc 'unknown'
      //   317: astore_1
      //   318: new com/adcolony/sdk/b0$a
      //   321: dup
      //   322: invokespecial <init> : ()V
      //   325: astore #8
      //   327: new java/lang/StringBuilder
      //   330: dup
      //   331: invokespecial <init> : ()V
      //   334: astore #9
      //   336: aload #9
      //   338: ldc 'onConsoleMessage: '
      //   340: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
      //   343: pop
      //   344: aload #9
      //   346: aload #7
      //   348: invokevirtual append : (Ljava/lang/Object;)Ljava/lang/StringBuilder;
      //   351: pop
      //   352: aload #9
      //   354: ldc ' with ad id: '
      //   356: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
      //   359: pop
      //   360: aload #9
      //   362: aload_1
      //   363: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
      //   366: pop
      //   367: aload #8
      //   369: aload #9
      //   371: invokevirtual toString : ()Ljava/lang/String;
      //   374: invokevirtual c : (Ljava/lang/String;)Lcom/adcolony/sdk/b0$a;
      //   377: astore #7
      //   379: iload_3
      //   380: ifeq -> 390
      //   383: getstatic com/adcolony/sdk/b0.i : Lcom/adcolony/sdk/b0;
      //   386: astore_1
      //   387: goto -> 394
      //   390: getstatic com/adcolony/sdk/b0.g : Lcom/adcolony/sdk/b0;
      //   393: astore_1
      //   394: aload #7
      //   396: aload_1
      //   397: invokevirtual d : (Lcom/adcolony/sdk/b0;)V
      //   400: iconst_1
      //   401: ireturn
    }
    
    public boolean onJsAlert(WebView param1WebView, String param1String1, String param1String2, JsResult param1JsResult) {
      if (param1JsResult != null)
        param1JsResult.confirm(); 
      return true;
    }
  }
  
  protected class b extends WebViewClient {
    public b(t this$0) {}
    
    public void onPageFinished(WebView param1WebView, String param1String) {
      i0 i0;
      e0 e0 = v.q();
      v.u(e0, "id", t.n(this.a));
      v.n(e0, "url", param1String);
      u u = this.a.getParentContainer();
      if (u == null) {
        u = null;
      } else {
        v.n(e0, "ad_session_id", this.a.getAdSessionId());
        v.u(e0, "container_id", u.q());
        (new j0("WebView.on_load", u.J(), e0)).e();
        i0 = i0.a;
      } 
      if (i0 == null)
        (new j0("WebView.on_load", this.a.getWebViewModuleId(), e0)).e(); 
    }
    
    public void onReceivedError(WebView param1WebView, int param1Int, String param1String1, String param1String2) {
      t.e(this.a, param1Int, param1String1, param1String2);
    }
    
    public WebResourceResponse shouldInterceptRequest(WebView param1WebView, String param1String) {
      boolean bool = true;
      if (param1String == null || c2.h.r(param1String, "mraid.js", false, 2, null) != true)
        bool = false; 
      if (bool) {
        param1String = t.c(this.a);
        Charset charset = k0.a;
        Objects.requireNonNull(param1String, "null cannot be cast to non-null type java.lang.String");
        ByteArrayInputStream byteArrayInputStream = new ByteArrayInputStream(param1String.getBytes(charset));
        return new WebResourceResponse("text/javascript", charset.name(), byteArrayInputStream);
      } 
      return null;
    }
  }
  
  protected class c extends b {
    public c(t this$0) {
      super(this$0);
    }
    
    public WebResourceResponse shouldInterceptRequest(WebView param1WebView, WebResourceRequest param1WebResourceRequest) {
      boolean bool = true;
      if (param1WebResourceRequest != null) {
        Uri uri = param1WebResourceRequest.getUrl();
        if (uri != null) {
          String str = uri.toString();
          if (str != null && c2.h.r(str, "mraid.js", false, 2, null) == true) {
            if (bool) {
              String str1 = t.c(this.b);
              Charset charset = k0.a;
              Objects.requireNonNull(str1, "null cannot be cast to non-null type java.lang.String");
              ByteArrayInputStream byteArrayInputStream = new ByteArrayInputStream(str1.getBytes(charset));
              return new WebResourceResponse("text/javascript", charset.name(), byteArrayInputStream);
            } 
            return null;
          } 
        } 
      } 
      bool = false;
      if (bool) {
        String str = t.c(this.b);
        Charset charset = k0.a;
        Objects.requireNonNull(str, "null cannot be cast to non-null type java.lang.String");
        ByteArrayInputStream byteArrayInputStream = new ByteArrayInputStream(str.getBytes(charset));
        return new WebResourceResponse("text/javascript", charset.name(), byteArrayInputStream);
      } 
      return null;
    }
    
    public WebResourceResponse shouldInterceptRequest(WebView param1WebView, String param1String) {
      return null;
    }
  }
  
  protected class d extends c {
    public d(t this$0) {
      super(this$0);
    }
    
    public void onReceivedError(WebView param1WebView, int param1Int, String param1String1, String param1String2) {}
    
    public void onReceivedError(WebView param1WebView, WebResourceRequest param1WebResourceRequest, WebResourceError param1WebResourceError) {
      // Byte code:
      //   0: aload_3
      //   1: ifnonnull -> 5
      //   4: return
      //   5: aload_0
      //   6: getfield c : Lcom/adcolony/sdk/t;
      //   9: astore #5
      //   11: aload_3
      //   12: invokevirtual getErrorCode : ()I
      //   15: istore #4
      //   17: aload_3
      //   18: invokevirtual getDescription : ()Ljava/lang/CharSequence;
      //   21: invokevirtual toString : ()Ljava/lang/String;
      //   24: astore_3
      //   25: aload_2
      //   26: ifnonnull -> 32
      //   29: goto -> 43
      //   32: aload_2
      //   33: invokeinterface getUrl : ()Landroid/net/Uri;
      //   38: astore_1
      //   39: aload_1
      //   40: ifnonnull -> 48
      //   43: aconst_null
      //   44: astore_1
      //   45: goto -> 53
      //   48: aload_1
      //   49: invokevirtual toString : ()Ljava/lang/String;
      //   52: astore_1
      //   53: aload #5
      //   55: iload #4
      //   57: aload_3
      //   58: aload_1
      //   59: invokestatic e : (Lcom/adcolony/sdk/t;ILjava/lang/String;Ljava/lang/String;)V
      //   62: return
    }
  }
  
  protected class e extends d {
    public e(t this$0) {
      super(this$0);
    }
  }
  
  protected class f extends e {
    public f(t this$0) {
      super(this$0);
    }
    
    public boolean onRenderProcessGone(WebView param1WebView, RenderProcessGoneDetail param1RenderProcessGoneDetail) {
      boolean bool;
      if (param1RenderProcessGoneDetail != null && param1RenderProcessGoneDetail.didCrash() == true) {
        bool = true;
      } else {
        bool = false;
      } 
      if (bool)
        this.d.m(v.q(), "An error occurred while rendering the ad. Ad closing."); 
      return true;
    }
  }
  
  public static final class g {
    private g() {}
    
    public final t a(Context param1Context, j0 param1j0, int param1Int, u param1u) {
      t t;
      int i = q.h().P0().t();
      e0 e0 = param1j0.a();
      if (v.t(e0, "use_mraid_module")) {
        t = new s0(param1Context, i, param1j0, q.h().P0().t());
      } else {
        w w;
        if (v.t(e0, "enable_messages")) {
          w = new w((Context)t, i, param1j0);
        } else {
          t = new t((Context)w, i, param1j0);
        } 
      } 
      t.i(param1j0, param1Int, param1u);
      t.u();
      return t;
    }
  }
  
  public static final class h implements o0 {
    h(t param1t) {}
    
    public void a(j0 param1j0) {
      t t1 = this.a;
      t.f(t1, param1j0, new a(t1, param1j0));
    }
    
    static final class a extends s implements t1.a<i0> {
      a(t param2t, j0 param2j0) {
        super(0);
      }
      
      public final void a() {
        this.b.l(v.E(this.c.a(), "custom_js"));
      }
    }
  }
  
  static final class a extends s implements t1.a<i0> {
    a(t param1t, j0 param1j0) {
      super(0);
    }
    
    public final void a() {
      this.b.l(v.E(this.c.a(), "custom_js"));
    }
  }
  
  public static final class i implements o0 {
    i(t param1t) {}
    
    public void a(j0 param1j0) {
      t t1 = this.a;
      t.f(t1, param1j0, new a(t1, param1j0));
    }
    
    static final class a extends s implements t1.a<i0> {
      a(t param2t, j0 param2j0) {
        super(0);
      }
      
      public final void a() {
        this.b.setVisible(this.c);
      }
    }
  }
  
  static final class a extends s implements t1.a<i0> {
    a(t param1t, j0 param1j0) {
      super(0);
    }
    
    public final void a() {
      this.b.setVisible(this.c);
    }
  }
  
  public static final class j implements o0 {
    j(t param1t) {}
    
    public void a(j0 param1j0) {
      t t1 = this.a;
      t.f(t1, param1j0, new a(t1, param1j0));
    }
    
    static final class a extends s implements t1.a<i0> {
      a(t param2t, j0 param2j0) {
        super(0);
      }
      
      public final void a() {
        this.b.setBounds(this.c);
      }
    }
  }
  
  static final class a extends s implements t1.a<i0> {
    a(t param1t, j0 param1j0) {
      super(0);
    }
    
    public final void a() {
      this.b.setBounds(this.c);
    }
  }
  
  public static final class k implements o0 {
    k(t param1t) {}
    
    public void a(j0 param1j0) {
      t t1 = this.a;
      t.f(t1, param1j0, new a(t1, param1j0));
    }
    
    static final class a extends s implements t1.a<i0> {
      a(t param2t, j0 param2j0) {
        super(0);
      }
      
      public final void a() {
        t.g(this.b, v.t(this.c.a(), "transparent"));
      }
    }
  }
  
  static final class a extends s implements t1.a<i0> {
    a(t param1t, j0 param1j0) {
      super(0);
    }
    
    public final void a() {
      t.g(this.b, v.t(this.c.a(), "transparent"));
    }
  }
  
  static final class m implements Runnable {
    m(t param1t) {}
    
    public final void run() {
      this.b.setWebChromeClient(null);
      this.b.setWebViewClient(new a(this.b));
      this.b.clearCache(true);
      this.b.removeAllViews();
      this.b.loadUrl("about:blank");
    }
    
    public static final class a extends WebViewClient {
      a(t param2t) {}
      
      public void onPageFinished(WebView param2WebView, String param2String) {
        this.a.destroy();
      }
    }
  }
  
  public static final class a extends WebViewClient {
    a(t param1t) {}
    
    public void onPageFinished(WebView param1WebView, String param1String) {
      this.a.destroy();
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Hill race-dex2jar.jar!\com\adcolony\sdk\t.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */