package com.adcolony.sdk;

import android.annotation.SuppressLint;
import android.annotation.TargetApi;
import android.app.Activity;
import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.Rect;
import android.graphics.RectF;
import android.graphics.SurfaceTexture;
import android.media.MediaPlayer;
import android.view.MotionEvent;
import android.view.Surface;
import android.view.TextureView;
import android.view.View;
import android.view.ViewGroup;
import android.widget.FrameLayout;
import android.widget.ProgressBar;
import java.io.FileInputStream;
import java.io.IOException;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.RejectedExecutionException;

@TargetApi(14)
class p extends TextureView implements MediaPlayer.OnErrorListener, MediaPlayer.OnPreparedListener, MediaPlayer.OnCompletionListener, MediaPlayer.OnSeekCompleteListener, TextureView.SurfaceTextureListener {
  private boolean A;
  
  private boolean B;
  
  private boolean C;
  
  private boolean D;
  
  private boolean E;
  
  private String F;
  
  private String G;
  
  private FileInputStream H;
  
  private j0 I;
  
  private u J;
  
  private Surface K;
  
  private SurfaceTexture L;
  
  private RectF M = new RectF();
  
  private j N;
  
  private ProgressBar O;
  
  private MediaPlayer P;
  
  private e0 Q = v.q();
  
  private ExecutorService R = Executors.newSingleThreadExecutor();
  
  private j0 S;
  
  private float b;
  
  private float c;
  
  private float d;
  
  private float e;
  
  private float f;
  
  private float g;
  
  private int h;
  
  private boolean i = true;
  
  private Paint j = new Paint();
  
  private Paint k = new Paint(1);
  
  private int l;
  
  private int m;
  
  private int n;
  
  private int o;
  
  private int p;
  
  private int q;
  
  private int r;
  
  private double s;
  
  private double t;
  
  private long u;
  
  private boolean v;
  
  private boolean w;
  
  private boolean x;
  
  private boolean y;
  
  private boolean z;
  
  p(Context paramContext, j0 paramj0, int paramInt, u paramu) {
    super(paramContext);
    this.J = paramu;
    this.I = paramj0;
    this.p = paramInt;
    setSurfaceTextureListener(this);
  }
  
  private boolean A(j0 paramj0) {
    boolean bool1 = this.z;
    boolean bool = false;
    if (!bool1)
      return false; 
    float f = (float)v.y(paramj0.a(), "volume");
    j j1 = q.h().z0();
    if (j1 != null) {
      if (f <= 0.0D)
        bool = true; 
      j1.j(bool);
    } 
    this.P.setVolume(f, f);
    e0 e01 = v.q();
    v.w(e01, "success", true);
    paramj0.b(e01).e();
    return true;
  }
  
  private void E() {
    e0 e01 = v.q();
    v.n(e01, "id", this.G);
    (new j0("AdSession.on_error", this.J.J(), e01)).e();
    this.v = true;
  }
  
  private void O() {
    double d = Math.min(this.n / this.q, this.o / this.r);
    int i = (int)(this.q * d);
    int k = (int)(this.r * d);
    (new b0.a()).c("setMeasuredDimension to ").a(i).c(" by ").a(k).d(b0.e);
    setMeasuredDimension(i, k);
    if (this.B) {
      FrameLayout.LayoutParams layoutParams = (FrameLayout.LayoutParams)getLayoutParams();
      layoutParams.width = i;
      layoutParams.height = k;
      layoutParams.gravity = 17;
      layoutParams.setMargins(0, 0, 0, 0);
      setLayoutParams((ViewGroup.LayoutParams)layoutParams);
    } 
  }
  
  private void R() {
    h h = new h(this);
    try {
      this.R.submit(h);
      return;
    } catch (RejectedExecutionException rejectedExecutionException) {
      E();
      return;
    } 
  }
  
  private boolean h(j0 paramj0) {
    e0 e01 = paramj0.a();
    return (v.A(e01, "id") == this.p && v.A(e01, "container_id") == this.J.q() && v.E(e01, "ad_session_id").equals(this.J.b()));
  }
  
  private boolean n(j0 paramj0) {
    if (!this.z)
      return false; 
    if (this.v)
      this.v = false; 
    this.S = paramj0;
    int i = v.A(paramj0.a(), "time");
    int k = this.P.getDuration() / 1000;
    this.P.setOnSeekCompleteListener(this);
    this.P.seekTo(i * 1000);
    if (k == i)
      this.v = true; 
    return true;
  }
  
  private void q(j0 paramj0) {
    e0 e01 = paramj0.a();
    this.l = v.A(e01, "x");
    this.m = v.A(e01, "y");
    this.n = v.A(e01, "width");
    this.o = v.A(e01, "height");
    FrameLayout.LayoutParams layoutParams = (FrameLayout.LayoutParams)getLayoutParams();
    layoutParams.setMargins(this.l, this.m, 0, 0);
    layoutParams.width = this.n;
    layoutParams.height = this.o;
    setLayoutParams((ViewGroup.LayoutParams)layoutParams);
    if (this.C && this.N != null) {
      int i = (int)(this.d * 4.0F);
      layoutParams = new FrameLayout.LayoutParams(i, i);
      layoutParams.setMargins(0, this.J.l() - (int)(this.d * 4.0F), 0, 0);
      layoutParams.gravity = 0;
      this.N.setLayoutParams((ViewGroup.LayoutParams)layoutParams);
    } 
  }
  
  private void u(j0 paramj0) {
    if (v.t(paramj0.a(), "visible")) {
      setVisibility(0);
      if (this.C) {
        j j1 = this.N;
        if (j1 != null) {
          j1.setVisibility(0);
          return;
        } 
      } 
    } else {
      setVisibility(4);
      if (this.C) {
        j j1 = this.N;
        if (j1 != null)
          j1.setVisibility(4); 
      } 
    } 
  }
  
  boolean D() {
    return this.v;
  }
  
  boolean H() {
    if (!this.z) {
      (new b0.a()).c("ADCVideoView pause() called while MediaPlayer is not prepared.").d(b0.g);
      return false;
    } 
    if (!this.x)
      return false; 
    this.P.getCurrentPosition();
    this.t = this.P.getDuration();
    this.P.pause();
    this.y = true;
    return true;
  }
  
  boolean I() {
    if (!this.z)
      return false; 
    if (!this.y && q.d) {
      this.P.start();
      R();
    } else if (!this.v && q.d) {
      this.P.start();
      this.y = false;
      if (!this.R.isShutdown())
        R(); 
      j j1 = this.N;
      if (j1 != null)
        j1.invalidate(); 
    } 
    setWillNotDraw(false);
    return true;
  }
  
  void L() {
    (new b0.a()).c("MediaPlayer stopped and released.").d(b0.e);
    try {
      if (!this.v && this.z && this.P.isPlaying())
        this.P.stop(); 
    } catch (IllegalStateException illegalStateException) {
      (new b0.a()).c("Caught IllegalStateException when calling stop on MediaPlayer").d(b0.g);
    } 
    ProgressBar progressBar = this.O;
    if (progressBar != null)
      this.J.removeView((View)progressBar); 
    this.v = true;
    this.z = false;
    this.P.release();
  }
  
  void N() {
    this.w = true;
  }
  
  void d() {
    if (this.L != null)
      this.A = true; 
    this.R.shutdown();
  }
  
  MediaPlayer j() {
    return this.P;
  }
  
  public void onCompletion(MediaPlayer paramMediaPlayer) {
    this.v = true;
    this.s = this.t;
    v.u(this.Q, "id", this.p);
    v.u(this.Q, "container_id", this.J.q());
    v.n(this.Q, "ad_session_id", this.G);
    v.k(this.Q, "elapsed", this.s);
    v.k(this.Q, "duration", this.t);
    (new j0("VideoView.on_progress", this.J.J(), this.Q)).e();
  }
  
  public boolean onError(MediaPlayer paramMediaPlayer, int paramInt1, int paramInt2) {
    E();
    b0.a a = new b0.a();
    StringBuilder stringBuilder = new StringBuilder();
    stringBuilder.append("MediaPlayer error: ");
    stringBuilder.append(paramInt1);
    stringBuilder.append(",");
    stringBuilder.append(paramInt2);
    a.c(stringBuilder.toString()).d(b0.h);
    return true;
  }
  
  public void onMeasure(int paramInt1, int paramInt2) {
    O();
  }
  
  public void onPrepared(MediaPlayer paramMediaPlayer) {
    this.z = true;
    if (this.E)
      this.J.removeView((View)this.O); 
    if (this.B) {
      this.q = paramMediaPlayer.getVideoWidth();
      this.r = paramMediaPlayer.getVideoHeight();
      O();
      (new b0.a()).c("MediaPlayer getVideoWidth = ").a(paramMediaPlayer.getVideoWidth()).d(b0.e);
      (new b0.a()).c("MediaPlayer getVideoHeight = ").a(paramMediaPlayer.getVideoHeight()).d(b0.e);
    } 
    e0 e01 = v.q();
    v.u(e01, "id", this.p);
    v.u(e01, "container_id", this.J.q());
    v.n(e01, "ad_session_id", this.G);
    (new j0("VideoView.on_ready", this.J.J(), e01)).e();
  }
  
  public void onSeekComplete(MediaPlayer paramMediaPlayer) {
    ExecutorService executorService = this.R;
    if (executorService != null && !executorService.isShutdown())
      try {
        this.R.submit(new g(this));
        return;
      } catch (RejectedExecutionException rejectedExecutionException) {
        E();
      }  
  }
  
  public void onSurfaceTextureAvailable(SurfaceTexture paramSurfaceTexture, int paramInt1, int paramInt2) {
    if (paramSurfaceTexture == null || this.A) {
      (new b0.a()).c("Null texture provided by system's onSurfaceTextureAvailable or ").c("MediaPlayer has been destroyed.").d(b0.i);
      return;
    } 
    Surface surface = new Surface(paramSurfaceTexture);
    this.K = surface;
    try {
      this.P.setSurface(surface);
    } catch (IllegalStateException illegalStateException) {
      (new b0.a()).c("IllegalStateException thrown when calling MediaPlayer.setSurface()").d(b0.h);
      E();
    } 
    this.L = paramSurfaceTexture;
  }
  
  public boolean onSurfaceTextureDestroyed(SurfaceTexture paramSurfaceTexture) {
    this.L = paramSurfaceTexture;
    if (!this.A)
      return false; 
    paramSurfaceTexture.release();
    return true;
  }
  
  public void onSurfaceTextureSizeChanged(SurfaceTexture paramSurfaceTexture, int paramInt1, int paramInt2) {
    this.L = paramSurfaceTexture;
  }
  
  public void onSurfaceTextureUpdated(SurfaceTexture paramSurfaceTexture) {
    this.L = paramSurfaceTexture;
  }
  
  @SuppressLint({"ClickableViewAccessibility"})
  public boolean onTouchEvent(MotionEvent paramMotionEvent) {
    p0 p0 = q.h();
    x x = p0.Z();
    int i = paramMotionEvent.getAction() & 0xFF;
    if (i != 0 && i != 1 && i != 3 && i != 2 && i != 5 && i != 6)
      return false; 
    int k = (int)paramMotionEvent.getX();
    int m = (int)paramMotionEvent.getY();
    e0 e01 = v.q();
    v.u(e01, "view_id", this.p);
    v.n(e01, "ad_session_id", this.G);
    v.u(e01, "container_x", this.l + k);
    v.u(e01, "container_y", this.m + m);
    v.u(e01, "view_x", k);
    v.u(e01, "view_y", m);
    v.u(e01, "id", this.J.q());
    if (i != 0) {
      if (i != 1) {
        if (i != 2) {
          if (i != 3) {
            if (i != 5) {
              if (i != 6)
                return true; 
              i = (paramMotionEvent.getAction() & 0xFF00) >> 8;
              v.u(e01, "container_x", (int)paramMotionEvent.getX(i) + this.l);
              v.u(e01, "container_y", (int)paramMotionEvent.getY(i) + this.m);
              v.u(e01, "view_x", (int)paramMotionEvent.getX(i));
              v.u(e01, "view_y", (int)paramMotionEvent.getY(i));
              if (!this.J.O())
                p0.y(x.w().get(this.G)); 
              (new j0("AdContainer.on_touch_ended", this.J.J(), e01)).e();
              return true;
            } 
            i = (paramMotionEvent.getAction() & 0xFF00) >> 8;
            v.u(e01, "container_x", (int)paramMotionEvent.getX(i) + this.l);
            v.u(e01, "container_y", (int)paramMotionEvent.getY(i) + this.m);
            v.u(e01, "view_x", (int)paramMotionEvent.getX(i));
            v.u(e01, "view_y", (int)paramMotionEvent.getY(i));
            (new j0("AdContainer.on_touch_began", this.J.J(), e01)).e();
            return true;
          } 
          (new j0("AdContainer.on_touch_cancelled", this.J.J(), e01)).e();
          return true;
        } 
        (new j0("AdContainer.on_touch_moved", this.J.J(), e01)).e();
        return true;
      } 
      if (!this.J.O())
        p0.y(x.w().get(this.G)); 
      (new j0("AdContainer.on_touch_ended", this.J.J(), e01)).e();
      return true;
    } 
    (new j0("AdContainer.on_touch_began", this.J.J(), e01)).e();
    return true;
  }
  
  boolean r() {
    return (this.P != null);
  }
  
  void t() {
    e0 e01 = this.I.a();
    this.G = v.E(e01, "ad_session_id");
    this.l = v.A(e01, "x");
    this.m = v.A(e01, "y");
    this.n = v.A(e01, "width");
    this.o = v.A(e01, "height");
    this.C = v.t(e01, "enable_timer");
    this.E = v.t(e01, "enable_progress");
    this.F = v.E(e01, "filepath");
    this.q = v.A(e01, "video_width");
    this.r = v.A(e01, "video_height");
    this.g = q.h().H0().Y();
    (new b0.a()).c("Original video dimensions = ").a(this.q).c("x").a(this.r).d(b0.c);
    setVisibility(4);
    FrameLayout.LayoutParams layoutParams = new FrameLayout.LayoutParams(this.n, this.o);
    layoutParams.setMargins(this.l, this.m, 0, 0);
    layoutParams.gravity = 0;
    this.J.addView((View)this, (ViewGroup.LayoutParams)layoutParams);
    if (this.E) {
      Context context = q.a();
      if (context != null) {
        ProgressBar progressBar = new ProgressBar(context);
        this.O = progressBar;
        u u1 = this.J;
        int i = (int)(this.g * 100.0F);
        u1.addView((View)progressBar, (ViewGroup.LayoutParams)new FrameLayout.LayoutParams(i, i, 17));
      } 
    } 
    this.P = new MediaPlayer();
    this.z = false;
    try {
      if (!this.F.startsWith("http")) {
        FileInputStream fileInputStream = new FileInputStream(this.F);
        this.H = fileInputStream;
        this.P.setDataSource(fileInputStream.getFD());
      } else {
        this.B = true;
        this.P.setDataSource(this.F);
      } 
      this.P.setOnErrorListener(this);
      this.P.setOnPreparedListener(this);
      this.P.setOnCompletionListener(this);
      this.P.prepareAsync();
    } catch (IOException iOException) {
      (new b0.a()).c("Failed to create/prepare MediaPlayer: ").c(iOException.toString()).d(b0.h);
      E();
    } 
    this.J.F().add(q.b("VideoView.play", new a(this), true));
    this.J.F().add(q.b("VideoView.set_bounds", new b(this), true));
    this.J.F().add(q.b("VideoView.set_visible", new c(this), true));
    this.J.F().add(q.b("VideoView.pause", new d(this), true));
    this.J.F().add(q.b("VideoView.seek_to_time", new e(this), true));
    this.J.F().add(q.b("VideoView.set_volume", new f(this), true));
    this.J.H().add("VideoView.play");
    this.J.H().add("VideoView.set_bounds");
    this.J.H().add("VideoView.set_visible");
    this.J.H().add("VideoView.pause");
    this.J.H().add("VideoView.seek_to_time");
    this.J.H().add("VideoView.set_volume");
  }
  
  void y() {
    if (this.i) {
      this.f = (float)(360.0D / this.t);
      this.k.setColor(-3355444);
      this.k.setShadowLayer((int)(this.g * 2.0F), 0.0F, 0.0F, -16777216);
      this.k.setTextAlign(Paint.Align.CENTER);
      this.k.setLinearText(true);
      this.k.setTextSize(this.g * 12.0F);
      this.j.setStyle(Paint.Style.STROKE);
      float f6 = this.g * 2.0F;
      float f5 = f6;
      if (f6 > 6.0F)
        f5 = 6.0F; 
      f6 = f5;
      if (f5 < 4.0F)
        f6 = 4.0F; 
      this.j.setStrokeWidth(f6);
      this.j.setShadowLayer((int)(this.g * 3.0F), 0.0F, 0.0F, -16777216);
      this.j.setColor(-3355444);
      Rect rect = new Rect();
      this.k.getTextBounds("0123456789", 0, 9, rect);
      this.d = rect.height();
      Context context = q.a();
      if (context != null)
        u1.G(new i(this, context)); 
      this.i = false;
    } 
    this.h = (int)(this.t - this.s);
    float f4 = this.d;
    float f1 = (int)f4;
    this.b = f1;
    float f2 = (int)(3.0F * f4);
    this.c = f2;
    RectF rectF = this.M;
    float f3 = f4 / 2.0F;
    f4 *= 2.0F;
    rectF.set(f1 - f3, f2 - f4, f1 + f4, f2 + f3);
    this.e = (float)(this.f * (this.t - this.s));
  }
  
  class a implements o0 {
    a(p this$0) {}
    
    public void a(j0 param1j0) {
      if (p.f(this.a, param1j0))
        this.a.I(); 
    }
  }
  
  class b implements o0 {
    b(p this$0) {}
    
    public void a(j0 param1j0) {
      if (p.f(this.a, param1j0))
        p.k(this.a, param1j0); 
    }
  }
  
  class c implements o0 {
    c(p this$0) {}
    
    public void a(j0 param1j0) {
      if (p.f(this.a, param1j0))
        p.p(this.a, param1j0); 
    }
  }
  
  class d implements o0 {
    d(p this$0) {}
    
    public void a(j0 param1j0) {
      if (p.f(this.a, param1j0))
        this.a.H(); 
    }
  }
  
  class e implements o0 {
    e(p this$0) {}
    
    public void a(j0 param1j0) {
      if (p.f(this.a, param1j0))
        p.w(this.a, param1j0); 
    }
  }
  
  class f implements o0 {
    f(p this$0) {}
    
    public void a(j0 param1j0) {
      if (p.f(this.a, param1j0))
        p.z(this.a, param1j0); 
    }
  }
  
  class g implements Runnable {
    g(p this$0) {}
    
    public void run() {
      try {
        Thread.sleep(150L);
      } catch (InterruptedException interruptedException) {
        interruptedException.printStackTrace();
      } 
      if (p.Y(this.b) != null) {
        e0 e0 = v.q();
        v.u(e0, "id", p.Z(this.b));
        v.n(e0, "ad_session_id", p.a0(this.b));
        v.w(e0, "success", true);
        p.Y(this.b).b(e0).e();
        p.C(this.b, null);
      } 
    }
  }
  
  class h implements Runnable {
    h(p this$0) {}
    
    public void run() {
      p.b(this.b, 0L);
      while (true) {
        if (!p.c0(this.b) && !p.e(this.b) && q.j()) {
          Context context = q.a();
          if (!p.c0(this.b) && !p.l(this.b) && context != null) {
            if (!(context instanceof Activity))
              return; 
            if (p.o(this.b).isPlaying()) {
              if (p.b0(this.b) == 0L && q.d)
                p.b(this.b, System.currentTimeMillis()); 
              p.g(this.b, true);
              p p1 = this.b;
              p.a(p1, p.o(p1).getCurrentPosition() / 1000.0D);
              p1 = this.b;
              p.i(p1, p.o(p1).getDuration() / 1000.0D);
              if (System.currentTimeMillis() - p.b0(this.b) > 1000L && !p.F(this.b) && q.d)
                if (p.x(this.b) == 0.0D) {
                  (new b0.a()).c("getCurrentPosition() not working, firing ").c("AdSession.on_error").d(b0.i);
                  p.G(this.b);
                } else {
                  p.m(this.b, true);
                }  
              if (p.J(this.b))
                this.b.y(); 
            } 
            if (p.v(this.b) && !p.c0(this.b) && !p.e(this.b)) {
              v.u(p.K(this.b), "id", p.Z(this.b));
              v.u(p.K(this.b), "container_id", p.M(this.b).q());
              v.n(p.K(this.b), "ad_session_id", p.a0(this.b));
              v.k(p.K(this.b), "elapsed", p.x(this.b));
              v.k(p.K(this.b), "duration", p.B(this.b));
              (new j0("VideoView.on_progress", p.M(this.b).J(), p.K(this.b))).e();
            } 
            if (p.P(this.b) || ((Activity)context).isFinishing()) {
              p.s(this.b, false);
              this.b.L();
              return;
            } 
            try {
              Thread.sleep(50L);
            } catch (InterruptedException interruptedException) {
              p.G(this.b);
              (new b0.a()).c("InterruptedException in ADCVideoView's update thread.").d(b0.h);
            } 
            continue;
          } 
          return;
        } 
        if (p.P(this.b))
          this.b.L(); 
        return;
      } 
    }
  }
  
  class i implements Runnable {
    i(p this$0, Context param1Context) {}
    
    public void run() {
      p.c(this.c, new p.j(this.c, this.b));
      FrameLayout.LayoutParams layoutParams = new FrameLayout.LayoutParams((int)(p.S(this.c) * 4.0F), (int)(p.S(this.c) * 4.0F));
      layoutParams.setMargins(0, p.M(this.c).l() - (int)(p.S(this.c) * 4.0F), 0, 0);
      layoutParams.gravity = 0;
      p.M(this.c).addView(p.Q(this.c), (ViewGroup.LayoutParams)layoutParams);
    }
  }
  
  private class j extends View {
    j(p this$0, Context param1Context) {
      super(param1Context);
      setWillNotDraw(false);
      try {
        j.class.getMethod("setLayerType", new Class[] { int.class, Paint.class }).invoke(this, new Object[] { Integer.valueOf(1), null });
        return;
      } catch (Exception exception) {
        return;
      } 
    }
    
    public void onDraw(Canvas param1Canvas) {
      super.onDraw(param1Canvas);
      param1Canvas.drawArc(p.T(this.b), 270.0F, p.U(this.b), false, p.V(this.b));
      StringBuilder stringBuilder = new StringBuilder();
      stringBuilder.append("");
      stringBuilder.append(p.W(this.b));
      param1Canvas.drawText(stringBuilder.toString(), p.T(this.b).centerX(), (float)(p.T(this.b).centerY() + (p.X(this.b).getFontMetrics()).bottom * 1.35D), p.X(this.b));
      invalidate();
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Hill race-dex2jar.jar!\com\adcolony\sdk\p.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */