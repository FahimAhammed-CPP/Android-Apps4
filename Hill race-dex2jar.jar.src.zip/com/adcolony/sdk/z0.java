package com.adcolony.sdk;

import android.util.Log;
import android.view.View;
import android.webkit.WebView;
import com.iab.omid.library.adcolony.adsession.AdEvents;
import com.iab.omid.library.adcolony.adsession.AdSession;
import com.iab.omid.library.adcolony.adsession.AdSessionConfiguration;
import com.iab.omid.library.adcolony.adsession.AdSessionContext;
import com.iab.omid.library.adcolony.adsession.CreativeType;
import com.iab.omid.library.adcolony.adsession.ErrorType;
import com.iab.omid.library.adcolony.adsession.ImpressionType;
import com.iab.omid.library.adcolony.adsession.Owner;
import com.iab.omid.library.adcolony.adsession.VerificationScriptResource;
import com.iab.omid.library.adcolony.adsession.media.InteractionType;
import com.iab.omid.library.adcolony.adsession.media.MediaEvents;
import com.iab.omid.library.adcolony.adsession.media.Position;
import com.iab.omid.library.adcolony.adsession.media.VastProperties;
import java.io.IOException;
import java.math.BigDecimal;
import java.net.MalformedURLException;
import java.net.URL;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

class z0 {
  private AdSession a;
  
  private AdEvents b;
  
  private MediaEvents c;
  
  private List<VerificationScriptResource> d = new ArrayList<VerificationScriptResource>();
  
  private int e = -1;
  
  private String f = "";
  
  private boolean g;
  
  private boolean h;
  
  private boolean i;
  
  private boolean j;
  
  private boolean k;
  
  private int l;
  
  private int m;
  
  private String n = "";
  
  private String o = "";
  
  z0(e0 parame0, String paramString) {
    this.e = a(parame0);
    this.j = v.t(parame0, "skippable");
    this.l = v.A(parame0, "skip_offset");
    this.m = v.A(parame0, "video_duration");
    c0 c01 = v.d(parame0, "js_resources");
    c0 c02 = v.d(parame0, "verification_params");
    c0 c03 = v.d(parame0, "vendor_keys");
    this.o = paramString;
    int i = 0;
    while (true) {
      if (i < c01.e()) {
        try {
          VerificationScriptResource verificationScriptResource;
          paramString = v.s(c02, i);
          String str = v.s(c03, i);
          URL uRL = new URL(v.s(c01, i));
          if (!paramString.equals("") && !str.equals("")) {
            verificationScriptResource = VerificationScriptResource.createVerificationScriptResourceWithParameters(str, uRL, paramString);
          } else {
            verificationScriptResource = VerificationScriptResource.createVerificationScriptResourceWithoutParameters(uRL);
          } 
          this.d.add(verificationScriptResource);
        } catch (MalformedURLException malformedURLException) {
          (new b0.a()).c("Invalid js resource url passed to Omid").d(b0.i);
        } 
        i++;
        continue;
      } 
      try {
        this.n = q.h().L0().a(v.E(parame0, "filepath"), true).toString();
        return;
      } catch (IOException iOException) {
        (new b0.a()).c("Error loading IAB JS Client").d(b0.i);
        return;
      } 
    } 
  }
  
  private int a(e0 parame0) {
    if (this.e == -1) {
      int i = v.A(parame0, "ad_unit_type");
      String str = v.E(parame0, "ad_type");
      if (i == 0)
        return 0; 
      if (i == 1) {
        if (str.equals("video"))
          return 0; 
        if (str.equals("display"))
          return 1; 
        if (str.equals("banner_display") || str.equals("interstitial_display"))
          return 2; 
      } 
    } 
    return this.e;
  }
  
  private void k(u paramu) {
    l("register_ad_view");
    t t2 = q.h().b().get(Integer.valueOf(paramu.J()));
    t t1 = t2;
    if (t2 == null) {
      t1 = t2;
      if (!paramu.M().isEmpty())
        t1 = (t)((Map.Entry)paramu.M().entrySet().iterator().next()).getValue(); 
    } 
    AdSession adSession = this.a;
    if (adSession != null && t1 != null) {
      adSession.registerAdView((View)t1);
      if (t1 instanceof s0) {
        ((s0)t1).X();
        return;
      } 
    } else if (adSession != null) {
      adSession.registerAdView((View)paramu);
      paramu.i(this.a);
      l("register_obstructions");
    } 
  }
  
  private void l(String paramString) {
    if (!u1.q(new a(this, paramString)))
      (new b0.a()).c("Executing ADCOmidManager.sendIabCustomMessage failed").d(b0.i); 
  }
  
  private void p() {
    a.k(new b(this), "viewability_ad_event");
  }
  
  void c() throws IllegalArgumentException {
    d(null);
  }
  
  void d(WebView paramWebView) throws IllegalArgumentException {
    if (this.e >= 0) {
      String str = this.n;
      if (str != null && !str.equals("")) {
        List<VerificationScriptResource> list = this.d;
        if (list != null && (!list.isEmpty() || o() == 2)) {
          p0 p0 = q.h();
          Owner owner = Owner.NATIVE;
          ImpressionType impressionType = ImpressionType.BEGIN_TO_RENDER;
          int i = o();
          if (i != 0) {
            if (i != 1) {
              if (i != 2)
                return; 
              CreativeType creativeType2 = CreativeType.HTML_DISPLAY;
              AdSessionContext adSessionContext1 = AdSessionContext.createHtmlAdSessionContext(p0.T0(), paramWebView, "", null);
              AdSession adSession2 = AdSession.createAdSession(AdSessionConfiguration.createAdSessionConfiguration(creativeType2, impressionType, owner, null, false), adSessionContext1);
              this.a = adSession2;
              this.f = adSession2.getAdSessionId();
              return;
            } 
            CreativeType creativeType1 = CreativeType.NATIVE_DISPLAY;
            adSessionContext = AdSessionContext.createNativeAdSessionContext(p0.T0(), this.n, this.d, null, null);
            AdSession adSession1 = AdSession.createAdSession(AdSessionConfiguration.createAdSessionConfiguration(creativeType1, impressionType, owner, null, false), adSessionContext);
            this.a = adSession1;
            this.f = adSession1.getAdSessionId();
            l("inject_javascript");
            return;
          } 
          CreativeType creativeType = CreativeType.VIDEO;
          AdSessionContext adSessionContext = AdSessionContext.createNativeAdSessionContext(adSessionContext.T0(), this.n, this.d, null, null);
          AdSession adSession = AdSession.createAdSession(AdSessionConfiguration.createAdSessionConfiguration(creativeType, impressionType, owner, owner, false), adSessionContext);
          this.a = adSession;
          this.f = adSession.getAdSessionId();
          l("inject_javascript");
        } 
      } 
    } 
  }
  
  void e(u paramu) {
    if (this.i)
      return; 
    if (this.e >= 0 && this.a != null) {
      MediaEvents mediaEvents;
      k(paramu);
      p();
      if (this.e != 0) {
        paramu = null;
      } else {
        mediaEvents = MediaEvents.createMediaEvents(this.a);
      } 
      this.c = mediaEvents;
      try {
        this.a.start();
        this.b = AdEvents.createAdEvents(this.a);
        l("start_session");
        if (this.c != null) {
          VastProperties vastProperties;
          Position position = Position.PREROLL;
          if (this.j) {
            vastProperties = VastProperties.createVastPropertiesForSkippableMedia(this.l, true, position);
          } else {
            vastProperties = VastProperties.createVastPropertiesForNonSkippableMedia(true, (Position)vastProperties);
          } 
          this.b.loaded(vastProperties);
        } else {
          this.b.loaded();
        } 
        this.i = true;
        return;
      } catch (NullPointerException nullPointerException) {
        AdSession adSession = this.a;
        ErrorType errorType = ErrorType.GENERIC;
        StringBuilder stringBuilder2 = new StringBuilder();
        stringBuilder2.append("Exception occurred on AdSession.start: ");
        stringBuilder2.append(Log.getStackTraceString(nullPointerException));
        adSession.error(errorType, stringBuilder2.toString());
        j();
        b0.a a = (new b0.a()).c("Exception in ADCOmidManager on AdSession.start: ").c(Log.getStackTraceString(nullPointerException));
        StringBuilder stringBuilder1 = new StringBuilder();
        stringBuilder1.append(" Ad with adSessionId: ");
        stringBuilder1.append(this.o);
        stringBuilder1.append(".");
        a.c(stringBuilder1.toString()).d(b0.i);
      } 
    } 
  }
  
  void f(String paramString) {
    g(paramString, 0.0F);
  }
  
  void g(String paramString, float paramFloat) {
    b0.a a;
    byte b;
    MediaEvents mediaEvents;
    if (q.j()) {
      if (this.a == null)
        return; 
      if (this.c == null && !paramString.equals("start") && !paramString.equals("skip") && !paramString.equals("continue") && !paramString.equals("cancel"))
        return; 
      b = -1;
      try {
        int i = paramString.hashCode();
        switch (i) {
          case 1906584668:
            if (paramString.equals("buffer_end"))
              b = 13; 
            break;
          case 1648173410:
            if (paramString.equals("sound_unmute"))
              b = 9; 
            break;
          case 823102269:
            if (paramString.equals("html5_interaction"))
              b = 15; 
            break;
          case 583742045:
            if (paramString.equals("in_video_engagement"))
              b = 14; 
            break;
          case 109757538:
            if (paramString.equals("start"))
              b = 0; 
            break;
          case 106440182:
            if (paramString.equals("pause"))
              b = 10; 
            break;
          case 3532159:
            if (paramString.equals("skip"))
              b = 6; 
            break;
          case -342650039:
            if (paramString.equals("sound_mute"))
              b = 8; 
            break;
          case -567202649:
            if (paramString.equals("continue"))
              b = 5; 
            break;
          case -599445191:
            if (paramString.equals("complete"))
              b = 4; 
            break;
          case -651914917:
            if (paramString.equals("third_quartile"))
              b = 3; 
            break;
          case -934426579:
            if (paramString.equals("resume"))
              b = 11; 
            break;
          case -1367724422:
            if (paramString.equals("cancel"))
              b = 7; 
            break;
          case -1638835128:
            if (paramString.equals("midpoint"))
              b = 2; 
            break;
          case -1710060637:
            if (paramString.equals("buffer_start"))
              b = 12; 
            break;
          case -1941887438:
            if (paramString.equals("first_quartile"))
              b = 1; 
            break;
        } 
      } catch (IllegalStateException illegalStateException) {
        a = (new b0.a()).c("Recording IAB event for ").c(paramString);
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append(" caused ");
        stringBuilder.append(illegalStateException.getClass());
        a.c(stringBuilder.toString()).d(b0.g);
        return;
      } catch (IllegalArgumentException illegalArgumentException) {}
    } else {
      return;
    } 
    switch (b) {
      case 14:
      case 15:
        this.c.adUserInteraction(InteractionType.CLICK);
        l((String)a);
        if (this.h && !this.g && !this.k) {
          this.c.pause();
          l("pause");
          this.g = true;
          this.h = false;
          return;
        } 
        return;
      case 13:
        this.c.bufferFinish();
        l((String)a);
        return;
      case 12:
        this.c.bufferStart();
        l((String)a);
        return;
      case 11:
        if (this.g && !this.k) {
          this.c.resume();
          l((String)a);
          this.g = false;
          return;
        } 
        return;
      case 10:
        if (!this.g && !this.h && !this.k) {
          this.c.pause();
          l((String)a);
          this.g = true;
          this.h = false;
          return;
        } 
        return;
      case 9:
        this.c.volumeChange(1.0F);
        l((String)a);
        return;
      case 8:
        this.c.volumeChange(0.0F);
        l((String)a);
        return;
      case 6:
      case 7:
        mediaEvents = this.c;
        if (mediaEvents != null)
          mediaEvents.skipped(); 
        l((String)a);
        j();
        return;
      case 5:
        l((String)a);
        j();
        return;
      case 4:
        this.k = true;
        this.c.complete();
        l((String)a);
        return;
      case 3:
        this.c.thirdQuartile();
        l((String)a);
        return;
      case 2:
        this.c.midpoint();
        l((String)a);
        return;
      case 1:
        this.c.firstQuartile();
        l((String)a);
        return;
      case 0:
        this.b.impressionOccurred();
        mediaEvents = this.c;
        if (mediaEvents != null) {
          if (paramFloat <= 0.0F)
            paramFloat = this.m; 
          mediaEvents.start(paramFloat, 1.0F);
        } 
        l((String)a);
        return;
    } 
  }
  
  void j() {
    a.x("viewability_ad_event");
    this.a.finish();
    l("end_session");
    this.a = null;
  }
  
  AdSession m() {
    return this.a;
  }
  
  int o() {
    return this.e;
  }
  
  void q() {
    this.h = true;
  }
  
  class a implements Runnable {
    a(z0 this$0, String param1String) {}
    
    public void run() {
      e0 e01 = v.q();
      e0 e02 = v.q();
      v.u(e02, "session_type", z0.b(this.c));
      v.n(e02, "session_id", z0.i(this.c));
      v.n(e02, "event", this.b);
      v.n(e01, "type", "iab_hook");
      v.n(e01, "message", e02.toString());
      (new j0("CustomMessage.controller_send", 0, e01)).e();
    }
  }
  
  class b implements h {
    b(z0 this$0) {}
    
    public void a(g param1g) {
      e0 e0 = v.r(param1g.a());
      String str1 = v.E(e0, "event_type");
      float f = BigDecimal.valueOf(v.y(e0, "duration")).floatValue();
      boolean bool1 = v.t(e0, "replay");
      boolean bool2 = v.E(e0, "skip_type").equals("dec");
      String str2 = v.E(e0, "asi");
      if (str1.equals("skip") && bool2) {
        z0.h(this.a, true);
        return;
      } 
      if (!bool1 || (!str1.equals("start") && !str1.equals("first_quartile") && !str1.equals("midpoint") && !str1.equals("third_quartile") && !str1.equals("complete")))
        u1.G(new a(this, str2, str1, f)); 
    }
    
    class a implements Runnable {
      a(z0.b this$0, String param2String1, String param2String2, float param2Float) {}
      
      public void run() {
        if (this.b.equals(z0.n(this.e.a))) {
          this.e.a.g(this.c, this.d);
          return;
        } 
        d d = q.h().Z().w().get(this.b);
        if (d != null) {
          z0 z0 = d.getOmidManager();
        } else {
          d = null;
        } 
        if (d != null)
          d.g(this.c, this.d); 
      }
    }
  }
  
  class a implements Runnable {
    a(z0 this$0, String param1String1, String param1String2, float param1Float) {}
    
    public void run() {
      if (this.b.equals(z0.n(this.e.a))) {
        this.e.a.g(this.c, this.d);
        return;
      } 
      d d = q.h().Z().w().get(this.b);
      if (d != null) {
        z0 z0 = d.getOmidManager();
      } else {
        d = null;
      } 
      if (d != null)
        d.g(this.c, this.d); 
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Hill race-dex2jar.jar!\com\adcolony\sdk\z0.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */