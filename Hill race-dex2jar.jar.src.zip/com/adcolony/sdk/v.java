package com.adcolony.sdk;

import java.io.IOException;
import org.json.JSONException;

class v {
  static int A(e0 parame0, String paramString) {
    return parame0.E(paramString);
  }
  
  static c0 B(e0 parame0, String paramString) {
    return parame0.G(paramString);
  }
  
  static e0 C(e0 parame0, String paramString) {
    return parame0.H(paramString);
  }
  
  static Object D(e0 parame0, String paramString) {
    Object object2 = parame0.J(paramString);
    Object object1 = object2;
    if (object2 == null)
      object1 = Boolean.FALSE; 
    return object1;
  }
  
  static String E(e0 parame0, String paramString) {
    return parame0.K(paramString);
  }
  
  static String F(e0 parame0, String paramString) {
    return parame0.L(paramString);
  }
  
  static boolean G(e0 parame0, String paramString) {
    try {
      q.h().L0().f(paramString, parame0.toString(), false);
      return true;
    } catch (IOException iOException) {
      (new b0.a()).c("IOException in ADCJSON's saveObject: ").c(iOException.toString()).d(b0.i);
      return false;
    } 
  }
  
  static int a(e0 parame0, String paramString, int paramInt) {
    return parame0.b(paramString, paramInt);
  }
  
  static long b(e0 parame0, String paramString, long paramLong) {
    return parame0.c(paramString, paramLong);
  }
  
  static c0 c() {
    return new c0();
  }
  
  static c0 d(e0 parame0, String paramString) {
    return parame0.F(paramString);
  }
  
  static c0 e(String paramString) {
    try {
      return new c0(paramString);
    } catch (JSONException jSONException) {
      (new b0.a()).c(jSONException.toString()).d(b0.i);
      return new c0();
    } 
  }
  
  static e0 f(c0 paramc0, int paramInt) {
    return paramc0.h(paramInt);
  }
  
  static e0 g(String paramString1, String paramString2) {
    try {
      return new e0(paramString1);
    } catch (JSONException jSONException) {
      String str;
      if (paramString2 == null) {
        str = "";
      } else {
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append(paramString2);
        stringBuilder.append(": ");
        stringBuilder.append(str.toString());
        str = stringBuilder.toString();
      } 
      (new b0.a()).c(str).d(b0.i);
      return new e0();
    } 
  }
  
  static e0 h(e0... paramVarArgs) {
    e0 e01 = new e0();
    int j = paramVarArgs.length;
    for (int i = 0; i < j; i++)
      e01.i(paramVarArgs[i]); 
    return e01;
  }
  
  static void i(c0 paramc0, e0 parame0) {
    paramc0.a(parame0);
  }
  
  static void j(c0 paramc0, String paramString) {
    paramc0.g(paramString);
  }
  
  static boolean k(e0 parame0, String paramString, double paramDouble) {
    try {
      parame0.n(paramString, paramDouble);
      return true;
    } catch (JSONException jSONException) {
      b0.a a = (new b0.a()).c("JSON error in ADCJSON putDouble(): ");
      StringBuilder stringBuilder2 = new StringBuilder();
      stringBuilder2.append(" with key: ");
      stringBuilder2.append(paramString);
      a = a.c(stringBuilder2.toString());
      StringBuilder stringBuilder1 = new StringBuilder();
      stringBuilder1.append(" and value: ");
      stringBuilder1.append(paramDouble);
      a.c(stringBuilder1.toString()).d(b0.i);
      return false;
    } 
  }
  
  static boolean l(e0 parame0, String paramString, c0 paramc0) {
    try {
      parame0.d(paramString, paramc0);
      return true;
    } catch (JSONException jSONException) {
      b0.a a = (new b0.a()).c("JSON error in ADCJSON putArray(): ").c(jSONException.toString());
      StringBuilder stringBuilder2 = new StringBuilder();
      stringBuilder2.append(" with key: ");
      stringBuilder2.append(paramString);
      a = a.c(stringBuilder2.toString());
      StringBuilder stringBuilder1 = new StringBuilder();
      stringBuilder1.append(" and value: ");
      stringBuilder1.append(paramc0);
      a.c(stringBuilder1.toString()).d(b0.i);
      return false;
    } 
  }
  
  static boolean m(e0 parame01, String paramString, e0 parame02) {
    try {
      parame01.e(paramString, parame02);
      return true;
    } catch (JSONException jSONException) {
      b0.a a = (new b0.a()).c("JSON error in ADCJSON putObject(): ").c(jSONException.toString());
      StringBuilder stringBuilder2 = new StringBuilder();
      stringBuilder2.append(" with key: ");
      stringBuilder2.append(paramString);
      a = a.c(stringBuilder2.toString());
      StringBuilder stringBuilder1 = new StringBuilder();
      stringBuilder1.append(" and value: ");
      stringBuilder1.append(parame02);
      a.c(stringBuilder1.toString()).d(b0.i);
      return false;
    } 
  }
  
  static boolean n(e0 parame0, String paramString1, String paramString2) {
    try {
      parame0.f(paramString1, paramString2);
      return true;
    } catch (JSONException jSONException) {
      b0.a a = (new b0.a()).c("JSON error in ADCJSON putString(): ").c(jSONException.toString());
      StringBuilder stringBuilder2 = new StringBuilder();
      stringBuilder2.append(" with key: ");
      stringBuilder2.append(paramString1);
      a = a.c(stringBuilder2.toString());
      StringBuilder stringBuilder1 = new StringBuilder();
      stringBuilder1.append(" and value: ");
      stringBuilder1.append(paramString2);
      a.c(stringBuilder1.toString()).d(b0.i);
      return false;
    } 
  }
  
  static boolean o(e0 parame0, String paramString, boolean paramBoolean) {
    return parame0.l(paramString, paramBoolean);
  }
  
  static String[] p(c0 paramc0) {
    return paramc0.k();
  }
  
  static e0 q() {
    return new e0();
  }
  
  static e0 r(String paramString) {
    return g(paramString, null);
  }
  
  static String s(c0 paramc0, int paramInt) {
    return paramc0.j(paramInt);
  }
  
  static boolean t(e0 parame0, String paramString) {
    return parame0.A(paramString);
  }
  
  static boolean u(e0 parame0, String paramString, int paramInt) {
    try {
      parame0.o(paramString, paramInt);
      return true;
    } catch (JSONException jSONException) {
      b0.a a = (new b0.a()).c("JSON error in ADCJSON putInteger(): ").c(jSONException.toString());
      StringBuilder stringBuilder2 = new StringBuilder();
      stringBuilder2.append(" with key: ");
      stringBuilder2.append(paramString);
      a = a.c(stringBuilder2.toString());
      StringBuilder stringBuilder1 = new StringBuilder();
      stringBuilder1.append(" and value: ");
      stringBuilder1.append(paramInt);
      a.c(stringBuilder1.toString()).d(b0.i);
      return false;
    } 
  }
  
  static boolean v(e0 parame0, String paramString, long paramLong) {
    try {
      parame0.p(paramString, paramLong);
      return true;
    } catch (JSONException jSONException) {
      b0.a a = (new b0.a()).c("JSON error in ADCJSON putLong(): ").c(jSONException.toString());
      StringBuilder stringBuilder2 = new StringBuilder();
      stringBuilder2.append(" with key: ");
      stringBuilder2.append(paramString);
      a = a.c(stringBuilder2.toString());
      StringBuilder stringBuilder1 = new StringBuilder();
      stringBuilder1.append(" and value: ");
      stringBuilder1.append(paramLong);
      a.c(stringBuilder1.toString()).d(b0.i);
      return false;
    } 
  }
  
  static boolean w(e0 parame0, String paramString, boolean paramBoolean) {
    try {
      parame0.q(paramString, paramBoolean);
      return true;
    } catch (JSONException jSONException) {
      b0.a a = (new b0.a()).c("JSON error in ADCJSON putBoolean(): ").c(jSONException.toString());
      StringBuilder stringBuilder2 = new StringBuilder();
      stringBuilder2.append(" with key: ");
      stringBuilder2.append(paramString);
      a = a.c(stringBuilder2.toString());
      StringBuilder stringBuilder1 = new StringBuilder();
      stringBuilder1.append(" and value: ");
      stringBuilder1.append(paramBoolean);
      a.c(stringBuilder1.toString()).d(b0.i);
      return false;
    } 
  }
  
  static e0[] x(c0 paramc0) {
    return paramc0.i();
  }
  
  static double y(e0 parame0, String paramString) {
    return parame0.a(paramString, 0.0D);
  }
  
  static e0 z(String paramString) {
    try {
      String str = q.h().L0().a(paramString, false).toString();
      StringBuilder stringBuilder = new StringBuilder();
      stringBuilder.append("loadObject from filepath ");
      stringBuilder.append(paramString);
      return g(str, stringBuilder.toString());
    } catch (IOException iOException) {
      (new b0.a()).c("IOException in ADCJSON's loadObject: ").c(iOException.toString()).d(b0.i);
      return q();
    } 
  }
}


/* Location:              C:\soft\dex2jar-2.0\Hill race-dex2jar.jar!\com\adcolony\sdk\v.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */