package com.adcolony.sdk;

import android.annotation.SuppressLint;
import android.app.ActivityManager;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.graphics.Insets;
import android.graphics.Point;
import android.graphics.Rect;
import android.os.Build;
import android.provider.Settings;
import android.security.NetworkSecurityPolicy;
import android.telephony.TelephonyManager;
import android.util.DisplayMetrics;
import android.util.Log;
import android.view.Display;
import android.view.WindowInsets;
import android.view.WindowManager;
import android.view.WindowMetrics;
import com.google.android.gms.ads.identifier.AdvertisingIdClient;
import com.google.android.gms.appset.AppSet;
import com.google.android.gms.appset.AppSetIdInfo;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Date;
import java.util.Locale;
import java.util.TimeZone;
import java.util.concurrent.Callable;

@SuppressLint({"ObsoleteSdkInt"})
class b1 {
  private final f0 a = new f0();
  
  private final f0 b = new f0();
  
  private String c = "";
  
  private boolean d;
  
  private String e = "";
  
  private e0 f = v.q();
  
  private String g = "";
  
  Callable<e0> A(long paramLong) {
    return new d(this, paramLong);
  }
  
  void B(Context paramContext) {
    C(paramContext, null);
  }
  
  void C(Context paramContext, s1<String> params1) {
    if (paramContext == null) {
      if (params1 != null)
        params1.a(new Throwable("Context cannot be null.")); 
    } else if (!Q().isEmpty()) {
      if (params1 != null)
        params1.a(Q()); 
    } else {
      E(false);
      try {
        AppSet.getClient(paramContext.getApplicationContext()).getAppSetIdInfo().addOnCompleteListener(new e(this, params1));
        return;
      } catch (NoClassDefFoundError|NoSuchMethodError noClassDefFoundError) {
        (new b0.a()).c("Google Play Services App Set dependency is missing.").d(b0.f);
      } catch (Exception exception) {
        (new b0.a()).c("Query App Set ID failed with: ").c(Log.getStackTraceString(exception)).d(b0.g);
      } 
      (new b0.a()).c("App Set ID is not available.").d(b0.f);
      if (params1 != null)
        params1.a(new Throwable("App Set ID is not available.")); 
    } 
    E(true);
  }
  
  public void D(String paramString) {
    this.e = paramString;
  }
  
  void E(boolean paramBoolean) {
    this.b.b(paramBoolean);
  }
  
  e0 F() {
    e0 e01 = v.q();
    v.n(e01, "app_set_id", Q());
    return e01;
  }
  
  e0 G(long paramLong) {
    if (paramLong <= 0L)
      return v.h(new e0[] { J(), y(), F() }); 
    ArrayList<e0> arrayList = new ArrayList(Collections.singletonList(J()));
    c1<e0> c1 = new c1();
    if (n()) {
      arrayList.add(y());
    } else {
      c1.c(s(paramLong));
    } 
    if (o()) {
      arrayList.add(F());
    } else {
      c1.c(A(paramLong));
    } 
    if (!c1.d())
      arrayList.addAll(c1.a()); 
    return v.h(arrayList.<e0>toArray(new e0[0]));
  }
  
  void H(String paramString) {
    this.g = paramString;
  }
  
  void I(boolean paramBoolean) {
    this.d = paramBoolean;
  }
  
  e0 J() {
    e0 e01 = v.q();
    p0 p0 = q.h();
    v.n(e01, "carrier_name", S());
    v.n(e01, "data_path", p0.Z0().f());
    v.u(e01, "device_api", P());
    Rect rect = c0();
    v.u(e01, "screen_width", rect.width());
    v.u(e01, "screen_height", rect.height());
    v.u(e01, "display_dpi", b0());
    v.n(e01, "device_type", a0());
    v.n(e01, "locale_language_code", e0());
    v.n(e01, "ln", e0());
    v.n(e01, "locale_country_code", V());
    v.n(e01, "locale", V());
    v.n(e01, "mac_address", b());
    v.n(e01, "manufacturer", c());
    v.n(e01, "device_brand", c());
    v.n(e01, "media_path", p0.Z0().h());
    v.n(e01, "temp_storage_path", p0.Z0().j());
    v.u(e01, "memory_class", d());
    v.v(e01, "memory_used_mb", e());
    v.n(e01, "model", f());
    v.n(e01, "device_model", f());
    v.n(e01, "sdk_type", "android_native");
    v.n(e01, "sdk_version", i());
    v.n(e01, "network_type", p0.R0().h());
    v.n(e01, "os_version", h());
    v.n(e01, "os_name", "android");
    v.n(e01, "platform", "android");
    v.n(e01, "arch", r());
    v.n(e01, "user_id", v.E(p0.V0().d(), "user_id"));
    v.n(e01, "app_id", p0.V0().b());
    v.n(e01, "app_bundle_name", u1.z());
    v.n(e01, "app_bundle_version", u1.J());
    v.k(e01, "battery_level", R());
    v.n(e01, "cell_service_country_code", j());
    v.n(e01, "timezone_ietf", l());
    v.u(e01, "timezone_gmt_m", k());
    v.u(e01, "timezone_dst_m", W());
    v.m(e01, "launch_metadata", f0());
    v.n(e01, "controller_version", p0.q0());
    v.u(e01, "current_orientation", g());
    v.w(e01, "cleartext_permitted", T());
    v.k(e01, "density", Y());
    v.w(e01, "dark_mode", X());
    v.n(e01, "adc_alt_id", K());
    c0 c0 = v.c();
    if (u1.L("com.android.vending"))
      c0.g("google"); 
    if (u1.L("com.amazon.venezia"))
      c0.g("amazon"); 
    if (u1.L("com.huawei.appmarket"))
      c0.g("huawei"); 
    if (u1.L("com.sec.android.app.samsungapps"))
      c0.g("samsung"); 
    v.l(e01, "available_stores", c0);
    return e01;
  }
  
  String K() {
    return u1.k(q.h().Z0());
  }
  
  String L() {
    return this.c;
  }
  
  String M() {
    Context context = q.a();
    return (context == null) ? null : Settings.Secure.getString(context.getContentResolver(), "advertising_id");
  }
  
  boolean N() {
    Context context = q.a();
    boolean bool = false;
    if (context == null)
      return false; 
    try {
      int i = Settings.Secure.getInt(context.getContentResolver(), "limit_ad_tracking");
      if (i != 0)
        bool = true; 
      return bool;
    } catch (android.provider.Settings.SettingNotFoundException settingNotFoundException) {
      return false;
    } 
  }
  
  @SuppressLint({"HardwareIds"})
  String O() {
    Context context = q.a();
    return (context == null) ? "" : Settings.Secure.getString(context.getContentResolver(), "android_id");
  }
  
  int P() {
    return Build.VERSION.SDK_INT;
  }
  
  public String Q() {
    return this.e;
  }
  
  double R() {
    Context context = q.a();
    double d = 0.0D;
    if (context == null)
      return 0.0D; 
    try {
      Intent intent = context.registerReceiver(null, new IntentFilter("android.intent.action.BATTERY_CHANGED"));
      if (intent == null)
        return 0.0D; 
      int i = intent.getIntExtra("level", -1);
      int j = intent.getIntExtra("scale", -1);
      if (i >= 0) {
        if (j < 0)
          return 0.0D; 
        d = i / j;
      } 
      return d;
    } catch (RuntimeException runtimeException) {
      return 0.0D;
    } 
  }
  
  String S() {
    Context context = q.a();
    String str1 = "";
    if (context == null)
      return ""; 
    TelephonyManager telephonyManager = (TelephonyManager)context.getSystemService("phone");
    if (telephonyManager != null)
      str1 = telephonyManager.getNetworkOperatorName(); 
    String str2 = str1;
    if (str1.length() == 0)
      str2 = "unknown"; 
    return str2;
  }
  
  boolean T() {
    return (Build.VERSION.SDK_INT < 23 || NetworkSecurityPolicy.getInstance().isCleartextTrafficPermitted());
  }
  
  String U() {
    return this.g;
  }
  
  String V() {
    return Locale.getDefault().getCountry();
  }
  
  int W() {
    TimeZone timeZone = TimeZone.getDefault();
    return !timeZone.inDaylightTime(new Date()) ? 0 : (timeZone.getDSTSavings() / 60000);
  }
  
  boolean X() {
    Context context = q.a();
    boolean bool2 = false;
    boolean bool1 = bool2;
    if (context != null) {
      if (Build.VERSION.SDK_INT < 29)
        return false; 
      int i = (context.getResources().getConfiguration()).uiMode & 0x30;
      bool1 = bool2;
      if (i != 16) {
        if (i != 32)
          return false; 
        bool1 = true;
      } 
    } 
    return bool1;
  }
  
  float Y() {
    Context context = q.a();
    return (context == null) ? 0.0F : (context.getResources().getDisplayMetrics()).density;
  }
  
  e0 Z() {
    if (!n())
      try {
        return u1.y(v.h(new e0[] { J(), s(2000L).call() }));
      } catch (Exception exception) {} 
    return u1.y(v.h(new e0[] { J(), y() }));
  }
  
  boolean a() {
    return this.d;
  }
  
  String a0() {
    return p() ? "tablet" : "phone";
  }
  
  String b() {
    return "";
  }
  
  int b0() {
    Context context = q.a();
    if (context != null)
      if (Build.VERSION.SDK_INT < 17) {
        try {
          WindowManager windowManager = (WindowManager)context.getSystemService("window");
          if (windowManager != null) {
            DisplayMetrics displayMetrics = new DisplayMetrics();
            windowManager.getDefaultDisplay().getMetrics(displayMetrics);
            return displayMetrics.densityDpi;
          } 
        } catch (RuntimeException runtimeException) {}
      } else {
        return (runtimeException.getResources().getConfiguration()).densityDpi;
      }  
    return 0;
  }
  
  String c() {
    return Build.MANUFACTURER;
  }
  
  Rect c0() {
    Rect rect2 = new Rect();
    Context context = q.a();
    Rect rect1 = rect2;
    if (context != null)
      try {
        Rect rect;
        WindowManager windowManager = (WindowManager)context.getSystemService("window");
        rect1 = rect2;
        if (windowManager != null) {
          DisplayMetrics displayMetrics = new DisplayMetrics();
          windowManager.getDefaultDisplay().getMetrics(displayMetrics);
          rect = new Rect(0, 0, displayMetrics.widthPixels, displayMetrics.heightPixels);
        } 
        return rect;
      } catch (RuntimeException runtimeException) {
        return rect2;
      }  
    return (Rect)runtimeException;
  }
  
  int d() {
    Context context = q.a();
    if (context == null)
      return 0; 
    ActivityManager activityManager = (ActivityManager)context.getSystemService("activity");
    return (activityManager == null) ? 0 : activityManager.getMemoryClass();
  }
  
  Rect d0() {
    int i;
    int j;
    int k;
    Point point1;
    Point point2;
    Rect rect = new Rect();
    Context context = q.a();
    if (context != null) {
      try {
        WindowManager windowManager = (WindowManager)context.getSystemService("window");
        if (windowManager != null) {
          Display display;
          i = Build.VERSION.SDK_INT;
          if (i < 17) {
            DisplayMetrics displayMetrics = new DisplayMetrics();
            windowManager.getDefaultDisplay().getMetrics(displayMetrics);
            return new Rect(0, 0, displayMetrics.widthPixels, displayMetrics.heightPixels - u1.S(context));
          } 
          if (i < 30) {
            DisplayMetrics displayMetrics1 = new DisplayMetrics();
            DisplayMetrics displayMetrics2 = new DisplayMetrics();
            display = windowManager.getDefaultDisplay();
            display.getMetrics(displayMetrics1);
            display.getRealMetrics(displayMetrics2);
            i = u1.S(context);
            j = u1.v(context);
            k = displayMetrics2.heightPixels - displayMetrics1.heightPixels;
            if (k <= 0)
              return new Rect(0, 0, displayMetrics1.widthPixels, displayMetrics1.heightPixels - i); 
          } else {
            Rect rect1;
            WindowMetrics windowMetrics = display.getCurrentWindowMetrics();
            try {
              Point point;
              point1 = new Point();
              point2 = new Point();
              context.getDisplay().getCurrentSizeRange(point1, point2);
              if (windowMetrics.getBounds().width() > windowMetrics.getBounds().height()) {
                i = 2;
              } else {
                i = 1;
              } 
              if (i == 2) {
                point = new Point(point2.x, point1.y);
              } else {
                point = new Point(point1.x, point2.y);
              } 
              return new Rect(0, 0, point.x, point.y);
            } catch (UnsupportedOperationException unsupportedOperationException) {
              Insets insets = windowMetrics.getWindowInsets().getInsetsIgnoringVisibility(WindowInsets.Type.navigationBars() | WindowInsets.Type.displayCutout() | WindowInsets.Type.statusBars());
              rect1 = new Rect(0, 0, windowMetrics.getBounds().width() - insets.right + insets.left, windowMetrics.getBounds().height() - insets.top + insets.bottom);
            } 
            return rect1;
          } 
        } else {
          return rect;
        } 
      } catch (RuntimeException runtimeException) {
        return rect;
      } 
    } else {
      return rect;
    } 
    return (j <= 0 || (k <= i && j > i)) ? new Rect(0, 0, ((DisplayMetrics)point1).widthPixels, ((DisplayMetrics)point2).heightPixels - i) : new Rect(0, 0, ((DisplayMetrics)point1).widthPixels, ((DisplayMetrics)point2).heightPixels - j + i);
  }
  
  long e() {
    Runtime runtime = Runtime.getRuntime();
    return (runtime.totalMemory() - runtime.freeMemory()) / 1048576L;
  }
  
  String e0() {
    return Locale.getDefault().getLanguage();
  }
  
  String f() {
    return Build.MODEL;
  }
  
  e0 f0() {
    return this.f;
  }
  
  @SuppressLint({"SwitchIntDef"})
  int g() {
    Context context = q.a();
    if (context == null)
      return 2; 
    int i = (context.getResources().getConfiguration()).orientation;
    return (i != 1) ? ((i != 2) ? 2 : 1) : 0;
  }
  
  String h() {
    return Build.VERSION.RELEASE;
  }
  
  String i() {
    return "4.8.0";
  }
  
  String j() {
    Context context = q.a();
    if (context == null)
      return ""; 
    TelephonyManager telephonyManager = (TelephonyManager)context.getSystemService("phone");
    return (telephonyManager == null) ? "" : telephonyManager.getSimCountryIso();
  }
  
  int k() {
    return TimeZone.getDefault().getOffset(15L) / 60000;
  }
  
  String l() {
    return TimeZone.getDefault().getID();
  }
  
  void m() {
    x(false);
    E(false);
    q.g("Device.get_info", new a(this));
  }
  
  boolean n() {
    return this.a.c();
  }
  
  boolean o() {
    return this.b.c();
  }
  
  boolean p() {
    Context context = q.a();
    boolean bool = false;
    if (context == null)
      return false; 
    DisplayMetrics displayMetrics = context.getResources().getDisplayMetrics();
    float f1 = displayMetrics.widthPixels / displayMetrics.xdpi;
    float f2 = displayMetrics.heightPixels / displayMetrics.ydpi;
    if (Math.sqrt((f1 * f1 + f2 * f2)) >= 6.0D)
      bool = true; 
    return bool;
  }
  
  String r() {
    return System.getProperty("os.arch").toLowerCase(Locale.ENGLISH);
  }
  
  Callable<e0> s(long paramLong) {
    return new b(this, paramLong);
  }
  
  void t(Context paramContext) {
    u(paramContext, null);
  }
  
  void u(Context paramContext, s1<String> params1) {
    if (paramContext == null) {
      if (params1 != null)
        params1.a(new Throwable("Context cannot be null.")); 
    } else {
      if (L().isEmpty())
        x(false); 
      if (u1.q(new c(this, paramContext, params1)))
        return; 
      (new b0.a()).c("Executing Query Advertising ID failed.").d(b0.i);
      if (params1 != null)
        params1.a(new Throwable("Query Advertising ID failed on execute.")); 
    } 
    x(true);
  }
  
  void v(e0 parame0) {
    this.f = parame0;
  }
  
  void w(String paramString) {
    this.c = paramString;
  }
  
  void x(boolean paramBoolean) {
    this.a.b(paramBoolean);
  }
  
  e0 y() {
    e0 e01 = v.q();
    String str = L();
    v.n(e01, "advertiser_id", str);
    v.w(e01, "limit_tracking", a());
    if (str == null || str.isEmpty())
      v.n(e01, "android_id_sha1", u1.D(O())); 
    return e01;
  }
  
  class a implements o0 {
    a(b1 this$0) {}
    
    public void a(j0 param1j0) {
      if (!u1.q(new a(this, param1j0))) {
        (new b0.a()).c("Error retrieving device info, disabling AdColony.").d(b0.i);
        a.s();
      } 
    }
    
    class a implements Runnable {
      a(b1.a this$0, j0 param2j0) {}
      
      public void run() {
        u1.G(new a(this, q.h().H0().G(2000L)));
      }
      
      class a implements Runnable {
        a(b1.a.a this$0, e0 param3e0) {}
        
        public void run() {
          this.c.b.b(this.b).e();
        }
      }
    }
    
    class a implements Runnable {
      a(b1.a this$0, e0 param2e0) {}
      
      public void run() {
        this.c.b.b(this.b).e();
      }
    }
  }
  
  class a implements Runnable {
    a(b1 this$0, j0 param1j0) {}
    
    public void run() {
      u1.G(new a(this, q.h().H0().G(2000L)));
    }
    
    class a implements Runnable {
      a(b1.a.a this$0, e0 param3e0) {}
      
      public void run() {
        this.c.b.b(this.b).e();
      }
    }
  }
  
  class a implements Runnable {
    a(b1 this$0, e0 param1e0) {}
    
    public void run() {
      this.c.b.b(this.b).e();
    }
  }
  
  class b implements Callable<e0> {
    b(b1 this$0, long param1Long) {}
    
    public e0 b() {
      if (!this.b.n() && this.a > 0L)
        b1.q(this.b).a(this.a); 
      return this.b.y();
    }
  }
  
  class c implements Runnable {
    c(b1 this$0, Context param1Context, s1 param1s1) {}
    
    public void run() {
      boolean bool;
      String str;
      if (q.e) {
        str = "00000000-0000-0000-0000-000000000000";
        bool = true;
      } else {
        String str4 = null;
        String str5 = null;
        String str1 = null;
        boolean bool1 = false;
        str = str1;
        String str2 = str4;
        String str3 = str5;
        try {
          AdvertisingIdClient.Info info = AdvertisingIdClient.getAdvertisingIdInfo(this.b);
          str = str1;
          str2 = str4;
          str3 = str5;
          str1 = info.getId();
          str = str1;
          str2 = str1;
          str3 = str1;
          boolean bool2 = info.isLimitAdTrackingEnabled();
          bool1 = bool2;
        } catch (NoClassDefFoundError noClassDefFoundError) {
          (new b0.a()).c("Google Play Services Ads dependencies are missing.").d(b0.f);
          String str6 = str2;
        } catch (NoSuchMethodError noSuchMethodError) {
          (new b0.a()).c("Google Play Services is out of date, please update to GPS 4.0+.").d(b0.f);
          String str6 = str3;
        } catch (Exception exception) {
          (new b0.a()).c("Query Advertising ID failed with: ").c(Log.getStackTraceString(exception)).d(b0.g);
          str1 = str;
        } 
        str = str1;
        bool = bool1;
        if (str1 == null) {
          str = str1;
          bool = bool1;
          if (Build.MANUFACTURER.equals("Amazon")) {
            str = this.d.M();
            bool = this.d.N();
          } 
        } 
      } 
      if (str == null) {
        (new b0.a()).c("Advertising ID is not available. ").c("Collecting Android ID instead of Advertising ID.").d(b0.f);
        s1 s11 = this.c;
        if (s11 != null)
          s11.a(new Throwable("Advertising ID is not available.")); 
      } else {
        this.d.w(str);
        g1 g1 = q.h().N0().c();
        if (g1 != null)
          g1.d.put("advertisingId", this.d.L()); 
        this.d.I(bool);
        s1<String> s11 = this.c;
        if (s11 != null)
          s11.a(this.d.L()); 
      } 
      this.d.x(true);
    }
  }
  
  class d implements Callable<e0> {
    d(b1 this$0, long param1Long) {}
    
    public e0 b() {
      if (!this.b.o() && this.a > 0L)
        b1.z(this.b).a(this.a); 
      return this.b.F();
    }
  }
  
  class e implements OnCompleteListener<AppSetIdInfo> {
    e(b1 this$0, s1 param1s1) {}
    
    public void onComplete(Task<AppSetIdInfo> param1Task) {
      s1<String> s11;
      if (param1Task.isSuccessful()) {
        this.b.D(((AppSetIdInfo)param1Task.getResult()).getId());
        s11 = this.a;
        if (s11 != null)
          s11.a(this.b.Q()); 
      } else {
        Throwable throwable;
        if (s11.getException() != null) {
          throwable = s11.getException();
        } else {
          throwable = new Throwable("Task failed with unknown exception.");
        } 
        (new b0.a()).c("App Set ID is not available. Unexpected exception occurred: ").c(Log.getStackTraceString(throwable)).d(b0.g);
        s1 s12 = this.a;
        if (s12 != null)
          s12.a(throwable); 
      } 
      this.b.E(true);
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Hill race-dex2jar.jar!\com\adcolony\sdk\b1.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */