package com.adcolony.sdk;

import android.content.Context;
import java.util.Locale;
import org.json.JSONObject;

public class f {
  private String a = "";
  
  private e0 b = new e0();
  
  public f() {
    r("google");
  }
  
  private void c(Context paramContext) {
    p("bundle_id", u1.O(paramContext));
  }
  
  f a(String paramString) {
    if (paramString == null)
      return this; 
    this.a = paramString;
    v.n(this.b, "app_id", paramString);
    return this;
  }
  
  String b() {
    return this.a;
  }
  
  e0 d() {
    return this.b;
  }
  
  void e(Context paramContext) {
    c(paramContext);
    Boolean bool1 = this.b.B("use_forced_controller");
    if (bool1 != null)
      r0.I = bool1.booleanValue(); 
    if (this.b.A("use_staging_launch_server"))
      p0.Z = "https://adc3-launch-staging.adcolony.com/v4/launch"; 
    String str1 = u1.A(paramContext, "IABUSPrivacy_String");
    String str2 = u1.A(paramContext, "IABTCF_TCString");
    int i = u1.b(paramContext, "IABTCF_gdprApplies");
    if (str1 != null)
      v.n(this.b, "ccpa_consent_string", str1); 
    if (str2 != null)
      v.n(this.b, "gdpr_consent_string", str2); 
    boolean bool = true;
    if (i == 0 || i == 1) {
      e0 e01 = this.b;
      if (i != 1)
        bool = false; 
      v.w(e01, "gdpr_required", bool);
    } 
  }
  
  public boolean f() {
    return v.t(this.b, "is_child_directed");
  }
  
  public boolean g() {
    return v.t(this.b, "keep_screen_on");
  }
  
  public JSONObject h() {
    e0 e01 = v.q();
    v.n(e01, "name", v.E(this.b, "mediation_network"));
    v.n(e01, "version", v.E(this.b, "mediation_network_version"));
    return e01.g();
  }
  
  public boolean i() {
    return v.t(this.b, "multi_window_enabled");
  }
  
  public Object j(String paramString) {
    return v.D(this.b, paramString);
  }
  
  public JSONObject k() {
    e0 e01 = v.q();
    v.n(e01, "name", v.E(this.b, "plugin"));
    v.n(e01, "version", v.E(this.b, "plugin_version"));
    return e01.g();
  }
  
  public boolean l(String paramString) {
    e0 e01 = this.b;
    StringBuilder stringBuilder = new StringBuilder();
    stringBuilder.append(paramString.toLowerCase(Locale.ENGLISH));
    stringBuilder.append("_required");
    return v.t(e01, stringBuilder.toString());
  }
  
  public boolean m(String paramString) {
    e0 e01 = this.b;
    StringBuilder stringBuilder = new StringBuilder();
    stringBuilder.append(paramString.toLowerCase(Locale.ENGLISH));
    stringBuilder.append("_required");
    return e01.k(stringBuilder.toString());
  }
  
  public f n(boolean paramBoolean) {
    q("is_child_directed", paramBoolean);
    return this;
  }
  
  public f o(String paramString1, String paramString2) {
    v.n(this.b, "mediation_network", paramString1);
    v.n(this.b, "mediation_network_version", paramString2);
    return this;
  }
  
  public f p(String paramString1, String paramString2) {
    v.n(this.b, paramString1, paramString2);
    return this;
  }
  
  public f q(String paramString, boolean paramBoolean) {
    v.w(this.b, paramString, paramBoolean);
    return this;
  }
  
  public f r(String paramString) {
    p("origin_store", paramString);
    return this;
  }
  
  public f s(String paramString1, String paramString2) {
    e0 e01 = this.b;
    StringBuilder stringBuilder = new StringBuilder();
    stringBuilder.append(paramString1.toLowerCase(Locale.ENGLISH));
    stringBuilder.append("_consent_string");
    v.n(e01, stringBuilder.toString(), paramString2);
    return this;
  }
  
  public f t(String paramString, boolean paramBoolean) {
    StringBuilder stringBuilder = new StringBuilder();
    stringBuilder.append(paramString.toLowerCase(Locale.ENGLISH));
    stringBuilder.append("_required");
    q(stringBuilder.toString(), paramBoolean);
    return this;
  }
  
  public f u(String paramString) {
    p("user_id", paramString);
    return this;
  }
}


/* Location:              C:\soft\dex2jar-2.0\Hill race-dex2jar.jar!\com\adcolony\sdk\f.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */