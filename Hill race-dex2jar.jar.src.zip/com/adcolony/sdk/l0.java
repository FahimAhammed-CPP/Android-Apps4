package com.adcolony.sdk;

import android.annotation.SuppressLint;
import android.content.Context;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.LinkedBlockingQueue;
import java.util.concurrent.RejectedExecutionException;
import java.util.concurrent.ScheduledExecutorService;
import java.util.concurrent.ScheduledFuture;
import java.util.concurrent.TimeUnit;
import org.json.JSONException;

@SuppressLint({"UseSparseArrays"})
class l0 {
  private final LinkedHashMap<Integer, q0> a = new LinkedHashMap<Integer, q0>();
  
  private int b = 2;
  
  private final HashMap<String, ArrayList<o0>> c = new HashMap<String, ArrayList<o0>>();
  
  private int d = 1;
  
  private final LinkedBlockingQueue<e0> e = new LinkedBlockingQueue<e0>();
  
  private boolean f = false;
  
  private final ScheduledExecutorService g = Executors.newSingleThreadScheduledExecutor();
  
  private final ExecutorService h = Executors.newSingleThreadExecutor();
  
  private ScheduledFuture<?> i;
  
  private void e(e0 parame0) {
    l();
    this.e.add(parame0);
  }
  
  private void h(String paramString, e0 parame0) {
    HashMap<String, ArrayList<o0>> hashMap;
    o0 o0;
    synchronized (this.c) {
      ArrayList<?> arrayList = this.c.get(paramString);
      if (arrayList == null)
        return; 
      arrayList = new ArrayList(arrayList);
      j0 j0 = new j0(parame0);
      Iterator<?> iterator = arrayList.iterator();
      while (iterator.hasNext()) {
        o0 = (o0)iterator.next();
        try {
          o0.a(j0);
        } catch (RuntimeException runtimeException) {
          (new b0.a()).b(runtimeException).d(b0.i);
          runtimeException.printStackTrace();
          break;
        } 
      } 
      return;
    } 
  }
  
  private void l() {
    if (!this.f)
      synchronized (this.e) {
        if (this.f)
          return; 
        this.f = true;
        (new Thread(new b(this))).start();
        return;
      }  
  }
  
  private void m(e0 parame0) {
    try {
      String str = parame0.x("m_type");
      int i = parame0.m("m_origin");
      d d = new d(this, str, parame0);
      if (i >= 2) {
        u1.G(d);
        return;
      } 
      this.h.execute(d);
      return;
    } catch (RejectedExecutionException rejectedExecutionException) {
      (new b0.a()).c("RejectedExecutionException from message dispatcher's dispatchNativeMessage(): ").c(rejectedExecutionException.toString()).d(b0.i);
      return;
    } catch (JSONException jSONException) {
      (new b0.a()).c("JSON error from message dispatcher's dispatchNativeMessage(): ").c(jSONException.toString()).d(b0.i);
      return;
    } 
  }
  
  private void v() {
    if (this.i == null)
      try {
        this.i = this.g.scheduleAtFixedRate(new c(this), 0L, 17L, TimeUnit.MILLISECONDS);
        return;
      } catch (RejectedExecutionException rejectedExecutionException) {
        (new b0.a()).c("Error when scheduling message pumping").c(rejectedExecutionException.toString()).d(b0.i);
      }  
  }
  
  q0 b(int paramInt) {
    return this.a.get(Integer.valueOf(paramInt));
  }
  
  q0 c(q0 paramq0) {
    synchronized (this.a) {
      this.a.put(Integer.valueOf(paramq0.getAdcModuleId()), paramq0);
      w();
      return paramq0;
    } 
  }
  
  void d() {
    p0 p0 = q.h();
    if (!p0.e() && !p0.f()) {
      Context context = q.a();
      if (context == null)
        return; 
      l();
      u1.G(new a(this, context));
    } 
  }
  
  void i(String paramString, o0 paramo0) {
    ArrayList<o0> arrayList2 = this.c.get(paramString);
    ArrayList<o0> arrayList1 = arrayList2;
    if (arrayList2 == null) {
      arrayList1 = new ArrayList();
      this.c.put(paramString, arrayList1);
    } 
    arrayList1.add(paramo0);
  }
  
  void n(String paramString, o0 paramo0) {
    synchronized (this.c) {
      ArrayList arrayList = this.c.get(paramString);
      if (arrayList != null)
        arrayList.remove(paramo0); 
      return;
    } 
  }
  
  boolean o(int paramInt) {
    synchronized (this.a) {
      q0 q0 = this.a.remove(Integer.valueOf(paramInt));
      if (q0 != null) {
        q0.c();
        return true;
      } 
      return false;
    } 
  }
  
  boolean p(q0 paramq0) {
    return o(paramq0.getAdcModuleId());
  }
  
  r0 q() {
    q0 q0 = b(1);
    return (q0 instanceof r0) ? (r0)q0 : null;
  }
  
  void r(e0 parame0) {
    try {
      if (parame0.u("m_id", this.d))
        this.d++; 
      parame0.u("m_origin", 0);
      int i = parame0.m("m_target");
      if (i == 0) {
        e(parame0);
        return;
      } 
      q0 q0 = this.a.get(Integer.valueOf(i));
      if (q0 != null) {
        q0.a(parame0);
        return;
      } 
    } catch (JSONException jSONException) {
      (new b0.a()).c("JSON error in ADCMessageDispatcher's sendMessage(): ").c(jSONException.toString()).d(b0.i);
    } 
  }
  
  LinkedHashMap<Integer, q0> s() {
    return this.a;
  }
  
  int t() {
    int i = this.b;
    this.b = i + 1;
    return i;
  }
  
  boolean u() {
    Iterator<q0> iterator = this.a.values().iterator();
    while (iterator.hasNext()) {
      if (((q0)iterator.next()).a())
        return true; 
    } 
    return false;
  }
  
  void w() {
    if (u())
      v(); 
  }
  
  void x() {
    ScheduledFuture<?> scheduledFuture = this.i;
    if (scheduledFuture != null) {
      if (!scheduledFuture.isCancelled())
        this.i.cancel(false); 
      this.i = null;
    } 
  }
  
  void y() {
    synchronized (this.a) {
      ArrayList<?> arrayList = new ArrayList(this.a.values());
      Collections.reverse(arrayList);
      Iterator<?> iterator = arrayList.iterator();
      while (iterator.hasNext())
        ((q0)iterator.next()).b(); 
      return;
    } 
  }
  
  class a implements Runnable {
    a(l0 this$0, Context param1Context) {}
    
    public void run() {
      e0 e01 = q.h().V0().d();
      e0 e02 = v.q();
      v.n(e01, "os_name", "android");
      StringBuilder stringBuilder = new StringBuilder();
      stringBuilder.append(q.h().Z0().c());
      stringBuilder.append("7bf3a1e7bbd31e612eda3310c2cdb8075c43c6b5");
      v.n(e02, "filepath", stringBuilder.toString());
      v.m(e02, "info", e01);
      v.u(e02, "m_origin", 0);
      v.u(e02, "m_id", l0.a(this.c));
      v.n(e02, "m_type", "Controller.create");
      j0 j0 = new j0(e02);
      try {
        r0.X(this.b, j0);
        return;
      } catch (RuntimeException runtimeException) {
        b0.a a1 = new b0.a();
        stringBuilder = new StringBuilder();
        stringBuilder.append(runtimeException.toString());
        stringBuilder.append(": during WebView initialization.");
        a1.c(stringBuilder.toString()).c(" Disabling AdColony.").d(b0.h);
        a.s();
        return;
      } 
    }
  }
  
  class b implements Runnable {
    b(l0 this$0) {}
    
    public void run() {
      while (true) {
        try {
          e0 e0 = l0.k(this.b).poll(60L, TimeUnit.SECONDS);
          if (e0 != null) {
            l0.f(this.b, e0);
            continue;
          } 
          synchronized (l0.k(this.b)) {
            if (l0.k(this.b).peek() == null) {
              l0.j(this.b, false);
              return;
            } 
          } 
        } catch (InterruptedException interruptedException) {
          (new b0.a()).c("Native messages thread was interrupted: ").c(interruptedException.toString()).d(b0.i);
        } 
      } 
    }
  }
  
  class c implements Runnable {
    c(l0 this$0) {}
    
    public void run() {
      q.m();
      if (!this.b.u())
        this.b.x(); 
    }
  }
  
  class d implements Runnable {
    d(l0 this$0, String param1String, e0 param1e0) {}
    
    public void run() {
      l0.g(this.d, this.b, this.c);
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Hill race-dex2jar.jar!\com\adcolony\sdk\l0.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */