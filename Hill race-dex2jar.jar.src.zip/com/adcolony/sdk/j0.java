package com.adcolony.sdk;

import org.json.JSONException;

class j0 {
  private String a;
  
  private e0 b;
  
  j0(e0 parame0) {
    e0 e01 = parame0;
    if (parame0 == null)
      try {
        e01 = new e0();
        this.b = e01;
        this.a = e01.x("m_type");
        return;
      } catch (JSONException jSONException) {
        (new b0.a()).c("JSON Error in ADCMessage constructor: ").c(jSONException.toString()).d(b0.i);
        return;
      }  
    this.b = e01;
    this.a = e01.x("m_type");
  }
  
  j0(String paramString, int paramInt) {
    try {
      this.a = paramString;
      e0 e01 = new e0();
      this.b = e01;
      e01.o("m_target", paramInt);
      return;
    } catch (JSONException jSONException) {
      (new b0.a()).c("JSON Error in ADCMessage constructor: ").c(jSONException.toString()).d(b0.i);
      return;
    } 
  }
  
  j0(String paramString, int paramInt, e0 parame0) {
    try {
      this.a = paramString;
      e0 e01 = parame0;
      if (parame0 == null)
        e01 = new e0(); 
      this.b = e01;
      e01.o("m_target", paramInt);
      return;
    } catch (JSONException jSONException) {
      (new b0.a()).c("JSON Error in ADCMessage constructor: ").c(jSONException.toString()).d(b0.i);
      return;
    } 
  }
  
  e0 a() {
    return this.b;
  }
  
  j0 b(e0 parame0) {
    try {
      j0 j01 = new j0("reply", this.b.m("m_origin"), parame0);
      j01.b.o("m_id", this.b.m("m_id"));
      return j01;
    } catch (JSONException jSONException) {
      (new b0.a()).c("JSON error in ADCMessage's createReply(): ").c(jSONException.toString()).d(b0.i);
      return new j0("JSONException", 0);
    } 
  }
  
  String c() {
    return this.a;
  }
  
  void d(e0 parame0) {
    e0 e01 = parame0;
    if (parame0 == null)
      e01 = new e0(); 
    this.b = e01;
  }
  
  void e() {
    q.f(this.a, this.b);
  }
}


/* Location:              C:\soft\dex2jar-2.0\Hill race-dex2jar.jar!\com\adcolony\sdk\j0.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */