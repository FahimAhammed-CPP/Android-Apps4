package com.adcolony.sdk;

public class c {
  public static final c c = new c(300, 250);
  
  public static final c d = new c(320, 50);
  
  public static final c e = new c(728, 90);
  
  public static final c f = new c(160, 600);
  
  int a;
  
  int b;
  
  public c(int paramInt1, int paramInt2) {
    this.a = paramInt1;
    this.b = paramInt2;
  }
  
  public int a() {
    return this.b;
  }
  
  public int b() {
    return this.a;
  }
}


/* Location:              C:\soft\dex2jar-2.0\Hill race-dex2jar.jar!\com\adcolony\sdk\c.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */