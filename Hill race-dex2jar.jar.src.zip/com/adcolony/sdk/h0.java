package com.adcolony.sdk;

import android.util.Log;
import java.net.MalformedURLException;
import java.net.URL;
import java.util.HashMap;
import java.util.Queue;
import java.util.concurrent.ConcurrentLinkedQueue;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.RejectedExecutionException;
import java.util.concurrent.TimeUnit;

class h0 {
  static boolean f = false;
  
  static int g = 3;
  
  static int h = 1;
  
  private e0 a = v.q();
  
  private c0 b = null;
  
  private ExecutorService c = null;
  
  private final Queue<Runnable> d = new ConcurrentLinkedQueue<Runnable>();
  
  g1 e;
  
  private Runnable d(int paramInt1, int paramInt2, String paramString, boolean paramBoolean) {
    return new b(this, paramInt1, paramString, paramInt2, paramBoolean);
  }
  
  private void e(int paramInt1, String paramString, int paramInt2) {
    if (this.e == null)
      return; 
    if (paramInt2 == 3 && i(v.C(this.a, Integer.toString(paramInt1)), 3)) {
      this.e.e(paramString);
      return;
    } 
    if (paramInt2 == 2 && i(v.C(this.a, Integer.toString(paramInt1)), 2)) {
      this.e.i(paramString);
      return;
    } 
    if (paramInt2 == 1 && i(v.C(this.a, Integer.toString(paramInt1)), 1)) {
      this.e.j(paramString);
      return;
    } 
    if (paramInt2 == 0 && i(v.C(this.a, Integer.toString(paramInt1)), 0))
      this.e.h(paramString); 
  }
  
  private boolean k(Runnable paramRunnable) {
    try {
      ExecutorService executorService = this.c;
      if (executorService != null && !executorService.isShutdown() && !this.c.isTerminated()) {
        this.c.submit(paramRunnable);
        return true;
      } 
    } catch (RejectedExecutionException rejectedExecutionException) {
      Log.e("ADCLogError", "Internal error when submitting log to executor service.");
    } 
    return false;
  }
  
  e0 a(c0 paramc0) {
    e0 e01 = v.q();
    for (int i = 0; i < paramc0.e(); i++) {
      e0 e02 = v.f(paramc0, i);
      v.m(e01, Integer.toString(v.A(e02, "id")), e02);
    } 
    return e01;
  }
  
  g1 c() {
    return this.e;
  }
  
  void f(int paramInt, String paramString, boolean paramBoolean) {
    m(0, paramInt, paramString, paramBoolean);
  }
  
  void h(HashMap<String, Object> paramHashMap) {
    try {
      g1 g11 = new g1(new y(new URL("https://wd.adcolony.com/logs")), Executors.newSingleThreadScheduledExecutor(), paramHashMap);
      this.e = g11;
      g11.d(5L, TimeUnit.SECONDS);
      return;
    } catch (MalformedURLException malformedURLException) {
      malformedURLException.printStackTrace();
      return;
    } 
  }
  
  boolean i(e0 parame0, int paramInt) {
    int i = v.A(parame0, "send_level");
    if (parame0.r())
      i = h; 
    return (i >= paramInt && i != 4);
  }
  
  boolean j(e0 parame0, int paramInt, boolean paramBoolean) {
    int i = v.A(parame0, "print_level");
    boolean bool = v.t(parame0, "log_private");
    if (parame0.r()) {
      i = g;
      bool = f;
    } 
    boolean bool1 = false;
    if ((paramBoolean && !bool) || i == 4)
      return false; 
    paramBoolean = bool1;
    if (i >= paramInt)
      paramBoolean = true; 
    return paramBoolean;
  }
  
  c0 l() {
    return this.b;
  }
  
  void m(int paramInt1, int paramInt2, String paramString, boolean paramBoolean) {
    if (!k(d(paramInt1, paramInt2, paramString, paramBoolean)))
      synchronized (this.d) {
        this.d.add(d(paramInt1, paramInt2, paramString, paramBoolean));
        return;
      }  
  }
  
  void n(c0 paramc0) {
    this.a = a(paramc0);
  }
  
  void o() {
    q.g("Log.set_log_level", new c(this));
    q.g("Log.public.trace", new d(this));
    q.g("Log.private.trace", new e(this));
    q.g("Log.public.info", new f(this));
    q.g("Log.private.info", new g(this));
    q.g("Log.public.warning", new h(this));
    q.g("Log.private.warning", new i(this));
    q.g("Log.public.error", new j(this));
    q.g("Log.private.error", new a(this));
  }
  
  void p(c0 paramc0) {
    if (paramc0 != null) {
      paramc0.g("level");
      paramc0.g("message");
    } 
    this.b = paramc0;
  }
  
  void q() {
    ExecutorService executorService = this.c;
    if (executorService == null || executorService.isShutdown() || this.c.isTerminated())
      this.c = Executors.newSingleThreadExecutor(); 
    synchronized (this.d) {
      while (!this.d.isEmpty())
        k(this.d.poll()); 
      return;
    } 
  }
  
  class a implements o0 {
    a(h0 this$0) {}
    
    public void a(j0 param1j0) {
      this.a.m(v.A(param1j0.a(), "module"), 0, v.E(param1j0.a(), "message"), true);
    }
  }
  
  class b implements Runnable {
    b(h0 this$0, int param1Int1, String param1String, int param1Int2, boolean param1Boolean) {}
    
    public void run() {
      h0.g(this.f, this.b, this.c, this.d);
      int i = 0;
      while (i <= this.c.length() / 4000) {
        int k = i * 4000;
        int j = i + 1;
        int m = Math.min(j * 4000, this.c.length());
        if (this.d == 3) {
          h0 h01 = this.f;
          if (h01.j(v.C(h0.b(h01), Integer.toString(this.b)), 3, this.e)) {
            Log.d("AdColony [TRACE]", this.c.substring(k, m));
            i = j;
            continue;
          } 
        } 
        if (this.d == 2) {
          h0 h01 = this.f;
          if (h01.j(v.C(h0.b(h01), Integer.toString(this.b)), 2, this.e)) {
            Log.i("AdColony [INFO]", this.c.substring(k, m));
            i = j;
            continue;
          } 
        } 
        if (this.d == 1) {
          h0 h01 = this.f;
          if (h01.j(v.C(h0.b(h01), Integer.toString(this.b)), 1, this.e)) {
            Log.w("AdColony [WARNING]", this.c.substring(k, m));
            i = j;
            continue;
          } 
        } 
        if (this.d == 0) {
          h0 h01 = this.f;
          if (h01.j(v.C(h0.b(h01), Integer.toString(this.b)), 0, this.e)) {
            Log.e("AdColony [ERROR]", this.c.substring(k, m));
            i = j;
            continue;
          } 
        } 
        i = j;
        if (this.d == -1) {
          i = j;
          if (h0.g >= -1) {
            Log.e("AdColony [FATAL]", this.c.substring(k, m));
            i = j;
          } 
        } 
      } 
    }
  }
  
  class c implements o0 {
    c(h0 this$0) {}
    
    public void a(j0 param1j0) {
      h0.g = v.A(param1j0.a(), "level");
    }
  }
  
  class d implements o0 {
    d(h0 this$0) {}
    
    public void a(j0 param1j0) {
      this.a.m(v.A(param1j0.a(), "module"), 3, v.E(param1j0.a(), "message"), false);
    }
  }
  
  class e implements o0 {
    e(h0 this$0) {}
    
    public void a(j0 param1j0) {
      this.a.m(v.A(param1j0.a(), "module"), 3, v.E(param1j0.a(), "message"), true);
    }
  }
  
  class f implements o0 {
    f(h0 this$0) {}
    
    public void a(j0 param1j0) {
      this.a.m(v.A(param1j0.a(), "module"), 2, v.E(param1j0.a(), "message"), false);
    }
  }
  
  class g implements o0 {
    g(h0 this$0) {}
    
    public void a(j0 param1j0) {
      this.a.m(v.A(param1j0.a(), "module"), 2, v.E(param1j0.a(), "message"), true);
    }
  }
  
  class h implements o0 {
    h(h0 this$0) {}
    
    public void a(j0 param1j0) {
      this.a.m(v.A(param1j0.a(), "module"), 1, v.E(param1j0.a(), "message"), false);
    }
  }
  
  class i implements o0 {
    i(h0 this$0) {}
    
    public void a(j0 param1j0) {
      this.a.m(v.A(param1j0.a(), "module"), 1, v.E(param1j0.a(), "message"), true);
    }
  }
  
  class j implements o0 {
    j(h0 this$0) {}
    
    public void a(j0 param1j0) {
      this.a.m(v.A(param1j0.a(), "module"), 0, v.E(param1j0.a(), "message"), false);
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Hill race-dex2jar.jar!\com\adcolony\sdk\h0.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */