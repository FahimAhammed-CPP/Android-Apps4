package com.adcolony.sdk;

import java.io.DataOutputStream;
import java.io.IOException;
import java.net.URL;
import java.util.zip.GZIPOutputStream;

class y {
  private URL a;
  
  y(URL paramURL) {
    this.a = paramURL;
  }
  
  public int a(String paramString) throws IOException {
    DataOutputStream dataOutputStream1;
    DataOutputStream dataOutputStream2;
    String str2;
    DataOutputStream dataOutputStream4 = null;
    String str3 = null;
    GZIPOutputStream gZIPOutputStream1 = null;
    boolean bool1 = false;
    boolean bool2 = false;
    boolean bool3 = false;
    boolean bool4 = false;
    int i = 0;
    try {
    
    } catch (IOException iOException) {
    
    } finally {
      gZIPOutputStream1 = null;
      paramString = null;
      str2 = paramString;
      dataOutputStream2 = dataOutputStream4;
    } 
    try {
      throw paramString;
    } finally {
      gZIPOutputStream1 = null;
    } 
    GZIPOutputStream gZIPOutputStream2 = gZIPOutputStream1;
    DataOutputStream dataOutputStream3 = dataOutputStream1;
    String str1 = str2;
    if (str1 != null && i == 0)
      str1.close(); 
    if (dataOutputStream3 != null)
      dataOutputStream3.close(); 
    if (dataOutputStream2 != null) {
      if (dataOutputStream2.getInputStream() != null)
        dataOutputStream2.getInputStream().close(); 
      dataOutputStream2.disconnect();
    } 
    throw gZIPOutputStream2;
  }
}


/* Location:              C:\soft\dex2jar-2.0\Hill race-dex2jar.jar!\com\adcolony\sdk\y.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */