package com.adcolony.sdk;

import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

class e0 {
  private final JSONObject a;
  
  e0() {
    this(new JSONObject());
  }
  
  e0(String paramString) throws JSONException {
    this(new JSONObject(paramString));
  }
  
  e0(Map<?, ?> paramMap) {
    this(new JSONObject(paramMap));
  }
  
  e0(JSONObject paramJSONObject) throws NullPointerException {
    paramJSONObject.getClass();
    this.a = paramJSONObject;
  }
  
  private Iterator<String> t() {
    return this.a.keys();
  }
  
  boolean A(String paramString) {
    synchronized (this.a) {
      return this.a.optBoolean(paramString);
    } 
  }
  
  Boolean B(String paramString) {
    try {
      synchronized (this.a) {
        boolean bool = this.a.getBoolean(paramString);
        return Boolean.valueOf(bool);
      } 
    } catch (JSONException jSONException) {
      return null;
    } 
  }
  
  double C(String paramString) {
    synchronized (this.a) {
      return this.a.optDouble(paramString);
    } 
  }
  
  Integer D(String paramString) {
    try {
      synchronized (this.a) {
        int i = this.a.getInt(paramString);
        return Integer.valueOf(i);
      } 
    } catch (JSONException jSONException) {
      return null;
    } 
  }
  
  int E(String paramString) {
    synchronized (this.a) {
      return this.a.optInt(paramString);
    } 
  }
  
  c0 F(String paramString) {
    synchronized (this.a) {
      c0 c0;
      JSONArray jSONArray = this.a.optJSONArray(paramString);
      if (jSONArray != null) {
        c0 = new c0(jSONArray);
      } else {
        c0 = new c0();
      } 
      return c0;
    } 
  }
  
  c0 G(String paramString) {
    synchronized (this.a) {
      JSONArray jSONArray = this.a.optJSONArray(paramString);
      if (jSONArray != null)
        return new c0(jSONArray); 
    } 
    paramString = null;
    /* monitor exit ClassFileLocalVariableReferenceExpression{type=ObjectType{java/lang/Object}, name=SYNTHETIC_LOCAL_VARIABLE_2} */
    return (c0)paramString;
  }
  
  e0 H(String paramString) {
    synchronized (this.a) {
      e0 e01;
      JSONObject jSONObject = this.a.optJSONObject(paramString);
      if (jSONObject != null) {
        e01 = new e0(jSONObject);
      } else {
        e01 = new e0();
      } 
      return e01;
    } 
  }
  
  e0 I(String paramString) {
    synchronized (this.a) {
      JSONObject jSONObject = this.a.optJSONObject(paramString);
      if (jSONObject != null)
        return new e0(jSONObject); 
    } 
    paramString = null;
    /* monitor exit ClassFileLocalVariableReferenceExpression{type=ObjectType{java/lang/Object}, name=SYNTHETIC_LOCAL_VARIABLE_2} */
    return (e0)paramString;
  }
  
  Object J(String paramString) {
    synchronized (this.a) {
      Object object;
      if (this.a.isNull(paramString)) {
        paramString = null;
      } else {
        object = this.a.opt(paramString);
      } 
      return object;
    } 
  }
  
  String K(String paramString) {
    synchronized (this.a) {
      paramString = this.a.optString(paramString);
      return paramString;
    } 
  }
  
  String L(String paramString) {
    synchronized (this.a) {
      if (!this.a.isNull(paramString)) {
        Object object = this.a.opt(paramString);
        if (object instanceof String) {
          object = object;
          return (String)object;
        } 
        if (object != null) {
          object = String.valueOf(object);
          return (String)object;
        } 
      } 
      return null;
    } 
  }
  
  void M(String paramString) {
    synchronized (this.a) {
      this.a.remove(paramString);
      return;
    } 
  }
  
  double a(String paramString, double paramDouble) {
    synchronized (this.a) {
      paramDouble = this.a.optDouble(paramString, paramDouble);
      return paramDouble;
    } 
  }
  
  int b(String paramString, int paramInt) {
    synchronized (this.a) {
      paramInt = this.a.optInt(paramString, paramInt);
      return paramInt;
    } 
  }
  
  long c(String paramString, long paramLong) {
    synchronized (this.a) {
      paramLong = this.a.optLong(paramString, paramLong);
      return paramLong;
    } 
  }
  
  e0 d(String paramString, c0 paramc0) throws JSONException {
    synchronized (this.a) {
      this.a.put(paramString, paramc0.c());
      return this;
    } 
  }
  
  e0 e(String paramString, e0 parame0) throws JSONException {
    synchronized (this.a) {
      this.a.put(paramString, parame0.g());
      return this;
    } 
  }
  
  e0 f(String paramString1, String paramString2) throws JSONException {
    synchronized (this.a) {
      this.a.put(paramString1, paramString2);
      return this;
    } 
  }
  
  JSONObject g() {
    return this.a;
  }
  
  void h(c0 paramc0) {
    synchronized (this.a) {
      Iterator<String> iterator = t();
      while (iterator.hasNext()) {
        if (!paramc0.d(iterator.next()))
          iterator.remove(); 
      } 
      return;
    } 
  }
  
  void i(e0 parame0) {
    if (parame0 != null)
      synchronized (this.a) {
        synchronized (parame0.a) {
          Iterator<String> iterator = parame0.t();
          while (true) {
            if (iterator.hasNext()) {
              String str = iterator.next();
              try {
                this.a.put(str, parame0.a.get(str));
              } catch (JSONException jSONException) {}
              continue;
            } 
            return;
          } 
        } 
      }  
  }
  
  void j(String[] paramArrayOfString) {
    synchronized (this.a) {
      int j = paramArrayOfString.length;
      for (int i = 0; i < j; i++) {
        String str = paramArrayOfString[i];
        this.a.remove(str);
      } 
      return;
    } 
  }
  
  boolean k(String paramString) {
    Iterator<String> iterator;
    synchronized (this.a) {
      iterator = t();
      while (iterator.hasNext()) {
        if (paramString.equals(iterator.next()))
          return true; 
      } 
    } 
    boolean bool = false;
    while (iterator.hasNext()) {
      if (paramString.equals(iterator.next())) {
        bool = true;
        /* monitor exit ClassFileLocalVariableReferenceExpression{type=ObjectType{java/lang/Object}, name=SYNTHETIC_LOCAL_VARIABLE_3} */
        return bool;
      } 
    } 
  }
  
  boolean l(String paramString, boolean paramBoolean) {
    synchronized (this.a) {
      paramBoolean = this.a.optBoolean(paramString, paramBoolean);
      return paramBoolean;
    } 
  }
  
  int m(String paramString) throws JSONException {
    synchronized (this.a) {
      return this.a.getInt(paramString);
    } 
  }
  
  e0 n(String paramString, double paramDouble) throws JSONException {
    synchronized (this.a) {
      this.a.put(paramString, paramDouble);
      return this;
    } 
  }
  
  e0 o(String paramString, int paramInt) throws JSONException {
    synchronized (this.a) {
      this.a.put(paramString, paramInt);
      return this;
    } 
  }
  
  e0 p(String paramString, long paramLong) throws JSONException {
    synchronized (this.a) {
      this.a.put(paramString, paramLong);
      return this;
    } 
  }
  
  e0 q(String paramString, boolean paramBoolean) throws JSONException {
    synchronized (this.a) {
      this.a.put(paramString, paramBoolean);
      return this;
    } 
  }
  
  boolean r() {
    return (v() == 0);
  }
  
  c0 s(String paramString) throws JSONException {
    synchronized (this.a) {
      return new c0(this.a.getJSONArray(paramString));
    } 
  }
  
  public String toString() {
    synchronized (this.a) {
      return this.a.toString();
    } 
  }
  
  boolean u(String paramString, int paramInt) throws JSONException {
    synchronized (this.a) {
      if (!this.a.has(paramString)) {
        this.a.put(paramString, paramInt);
        return true;
      } 
      return false;
    } 
  }
  
  int v() {
    return this.a.length();
  }
  
  long w(String paramString) throws JSONException {
    synchronized (this.a) {
      return this.a.getLong(paramString);
    } 
  }
  
  String x(String paramString) throws JSONException {
    synchronized (this.a) {
      paramString = this.a.getString(paramString);
      return paramString;
    } 
  }
  
  void y() {
    synchronized (this.a) {
      Iterator<String> iterator = t();
      while (iterator.hasNext()) {
        Object object = J(iterator.next());
        if (object == null || (object instanceof JSONArray && ((JSONArray)object).length() == 0) || (object instanceof JSONObject && ((JSONObject)object).length() == 0) || object.equals(""))
          iterator.remove(); 
      } 
      return;
    } 
  }
  
  Map<String, String> z() {
    null = new HashMap<Object, Object>();
    synchronized (this.a) {
      Iterator<String> iterator = t();
      while (iterator.hasNext()) {
        String str = iterator.next();
        null.put(str, K(str));
      } 
      return (Map)null;
    } 
  }
}


/* Location:              C:\soft\dex2jar-2.0\Hill race-dex2jar.jar!\com\adcolony\sdk\e0.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */