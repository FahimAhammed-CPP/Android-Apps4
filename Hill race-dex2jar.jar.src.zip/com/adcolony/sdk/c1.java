package com.adcolony.sdk;

import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.Callable;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.Future;
import java.util.concurrent.TimeUnit;

class c1<T> {
  private final List<Callable<T>> a = new ArrayList<Callable<T>>();
  
  private boolean b = false;
  
  List<T> a() {
    return b(-1L);
  }
  
  List<T> b(long paramLong) {
    this.b = true;
    ArrayList<T> arrayList = new ArrayList();
    ExecutorService executorService = Executors.newFixedThreadPool(this.a.size());
    ArrayList<Future<T>> arrayList1 = new ArrayList();
    if (paramLong > 0L) {
      try {
        List<Future<T>> list = executorService.invokeAll(this.a, paramLong, TimeUnit.MILLISECONDS);
        arrayList1.addAll(list);
        executorService.shutdownNow();
      } catch (Exception exception) {}
    } else {
      List<Future<T>> list = executorService.invokeAll(this.a);
      arrayList1.addAll(list);
      executorService.shutdownNow();
    } 
    int i = 0;
    while (true) {
      if (i < arrayList1.size()) {
        Future future = arrayList1.get(i);
        if (!future.isCancelled()) {
          try {
            arrayList.add(future.get());
          } catch (Exception exception) {}
        } else if (this.a.get(i) instanceof a) {
          arrayList.add(((a)this.a.get(i)).a());
        } 
        i++;
        continue;
      } 
      return arrayList;
    } 
  }
  
  void c(Callable<T> paramCallable) {
    if (this.b)
      return; 
    this.a.add(paramCallable);
  }
  
  boolean d() {
    return this.a.isEmpty();
  }
  
  static interface a<T> extends Callable<T> {
    T a();
  }
}


/* Location:              C:\soft\dex2jar-2.0\Hill race-dex2jar.jar!\com\adcolony\sdk\c1.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */