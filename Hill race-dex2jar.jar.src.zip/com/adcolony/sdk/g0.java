package com.adcolony.sdk;

import i1.i0;
import i1.r;
import i1.x;
import j1.j0;
import java.io.ByteArrayOutputStream;
import java.io.UnsupportedEncodingException;
import java.nio.charset.Charset;
import java.util.Map;
import java.util.zip.DataFormatException;
import java.util.zip.Deflater;
import java.util.zip.Inflater;
import u1.j;

public final class g0 {
  public static final a e = new a(null);
  
  private static final Map<String, String> f = j0.j(new r[] { x.a("default", "truefalse"), x.a("la-req-01", "\"iphoneos\"ipados\"cell\"tablet\"{\"carrier_name\":\",\"data_path\":\",\"device_api\":,\"screen_width\":,\"screen_height\":,\"display_dpi\":,\"device_type\":\"phone\",\"locale_language_code\":\",\"ln\":\",\"locale_country_code\":\",\"locale\":\",\"mac_address\":\"\",\"manufacturer\":\",\"device_brand\":\",\"media_path\":\",\"temp_storage_path\":\",\"memory_class\":,\"memory_used_mb\":,\"model\":\",\"device_model\":\",\"sdk_type\":\"android_native\",\"sdk_version\":\"4.\",\"network_type\":\"wifi\",\"os_version\":\",\"os_name\":\"android\",\"platform\":\"android\",\"arch\":\",\"user_id\":\"\",\"app_id\":\",\"app_bundle_name\":\",\"app_bundle_version\":\",\"battery_level\":1,\"cell_service_country_code\":\",\"timezone_ietf\":\",\"timezone_gmt_m\":,\"timezone_dst_m\":,\"controller_version\":\"3.\",\"current_orientation\":0,\"cleartext_permitted\":true,\"density\":,\"dark_mode\":false,\"available_stores\":[],\"advertiser_id\":\",\"limit_tracking\":false,\"adc_alt_id\":\"}"), x.a("la-res-01", "{\"controller\":{\"url\":\"https://adc-ad-assets.adtilt.com/launch/__controllers__/4.0.0/controller.js\",\"sha1\":,\"version\":\"3.\"},\"libraries\":[],\"item\":0,\"logging\":{\"log_private\":false,\"send_level\":1,\"enable_crash_reporting\":false,\"print_level\":3,\"report_interval_ms\":5000},\"metadata\":{\"controller_heartbeat_interval\":300000,\"controller_heartbeat_timeout\":15000,\"ad_request_timeout\":20000,\"iab_url\":\"https://adc-ad-assets.adtilt.com/launch/__libs__/omsdk/omsdk-v1.js\",\"odt_config\":{\"version\":,\"streams\":[{\"stream\":\"events\",\"request_types\":[\"start\",\"html5_interaction\",\"in_video_engagement\",\"download\",\"info\",\"viewable_impression\",\"complete\",\"skip\",\"continue\",\"midpoint\",\"first_quartile\",\"third_quartile\",\"reward_v4vc\"configure\"session_start\",\"session_end\",\"session_resume\",\"session_pause\"]\"table_name\"max_rows\": GROUP BY ]},\"calculate_odt_timeout\":500,\"async_odt_query\":false},\"status\":\"success\",\"pie\":\"}") });
  
  private final String a;
  
  private final String b;
  
  private final String c;
  
  private final String d;
  
  public g0(String paramString1, String paramString2, String paramString3, String paramString4) {
    this.a = paramString1;
    this.b = paramString2;
    this.c = paramString3;
    this.d = paramString4;
  }
  
  public static final g0 a(String paramString1, String paramString2) {
    return e.a(paramString1, paramString2);
  }
  
  public static final void c(Map<String, String> paramMap) {
    e.c(paramMap);
  }
  
  private final byte[] f(byte[] paramArrayOfbyte, String paramString) throws UnsupportedEncodingException {
    Deflater deflater = new Deflater();
    try {
      Charset charset = k0.a;
      if (paramString != null) {
        deflater.setDictionary(paramString.getBytes(charset));
        deflater.setInput(paramArrayOfbyte);
        deflater.finish();
        ByteArrayOutputStream byteArrayOutputStream = new ByteArrayOutputStream();
        try {
          byte[] arrayOfByte = new byte[512];
          while (!deflater.finished())
            byteArrayOutputStream.write(arrayOfByte, 0, deflater.deflate(arrayOfByte)); 
          arrayOfByte = byteArrayOutputStream.toByteArray();
          return arrayOfByte;
        } finally {
          paramString = null;
        } 
      } 
      throw new NullPointerException("null cannot be cast to non-null type java.lang.String");
    } finally {
      deflater.end();
    } 
  }
  
  private final String i(byte[] paramArrayOfbyte, String paramString) throws DataFormatException, UnsupportedEncodingException, IllegalArgumentException {
    Inflater inflater = new Inflater();
    try {
      inflater.setInput(paramArrayOfbyte);
      ByteArrayOutputStream byteArrayOutputStream = new ByteArrayOutputStream();
    } finally {
      inflater.end();
    } 
  }
  
  public final byte[] d(String paramString) throws UnsupportedEncodingException {
    return e(paramString.getBytes(k0.a));
  }
  
  public final byte[] e(byte[] paramArrayOfbyte) throws UnsupportedEncodingException {
    return f(paramArrayOfbyte, this.c);
  }
  
  public final String g() {
    return this.a;
  }
  
  public final String h(byte[] paramArrayOfbyte) throws DataFormatException, UnsupportedEncodingException, IllegalArgumentException {
    return i(paramArrayOfbyte, this.d);
  }
  
  public final String j() {
    return this.b;
  }
  
  public static final class a {
    private a() {}
    
    public final g0 a(String param1String1, String param1String2) {
      if (param1String1 == null || param1String2 == null)
        return null; 
      synchronized (b()) {
        a a1 = g0.e;
        if (!a1.b().containsKey(param1String1))
          param1String1 = "default"; 
        if (!a1.b().containsKey(param1String2))
          param1String2 = "default"; 
        return new g0(param1String1, param1String2, a1.b().get(param1String1), a1.b().get(param1String2));
      } 
    }
    
    public final Map<String, String> b() {
      return g0.b();
    }
    
    public final void c(Map<String, String> param1Map) {
      synchronized (b()) {
        g0.e.b().putAll(param1Map);
        i0 i0 = i0.a;
        return;
      } 
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Hill race-dex2jar.jar!\com\adcolony\sdk\g0.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */