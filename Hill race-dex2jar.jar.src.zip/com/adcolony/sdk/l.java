package com.adcolony.sdk;

public class l {
  private int a;
  
  private String b;
  
  private String c;
  
  private boolean d;
  
  l(j0 paramj0) {
    e0 e0 = paramj0.a();
    this.a = v.A(e0, "reward_amount");
    this.b = v.E(e0, "reward_name");
    this.d = v.t(e0, "success");
    this.c = v.E(e0, "zone_id");
  }
  
  public boolean a() {
    return this.d;
  }
}


/* Location:              C:\soft\dex2jar-2.0\Hill race-dex2jar.jar!\com\adcolony\sdk\l.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */