package com.adcolony.sdk;

public class n {
  private String a;
  
  private String b;
  
  private int c = 5;
  
  private int d;
  
  private int e;
  
  private int f;
  
  private int g;
  
  private int h;
  
  private int i;
  
  private boolean j;
  
  private boolean k;
  
  n(String paramString) {
    this.a = paramString;
  }
  
  private int b(int paramInt) {
    if (!q.k() || q.h().e() || q.h().f()) {
      f();
      return 0;
    } 
    return paramInt;
  }
  
  private String c(String paramString) {
    return d(paramString, "");
  }
  
  private String d(String paramString1, String paramString2) {
    if (!q.k() || q.h().e() || q.h().f()) {
      f();
      return paramString2;
    } 
    return paramString1;
  }
  
  private void f() {
    (new b0.a()).c("The AdColonyZone API is not available while AdColony is disabled.").d(b0.h);
  }
  
  int a() {
    return this.i;
  }
  
  void e(j0 paramj0) {
    e0 e01 = paramj0.a();
    e0 e02 = v.C(e01, "reward");
    this.b = v.E(e02, "reward_name");
    this.h = v.A(e02, "reward_amount");
    this.f = v.A(e02, "views_per_reward");
    this.e = v.A(e02, "views_until_reward");
    this.k = v.t(e01, "rewarded");
    this.c = v.A(e01, "status");
    this.d = v.A(e01, "type");
    this.g = v.A(e01, "play_interval");
    this.a = v.E(e01, "zone_id");
    int i = this.c;
    boolean bool = true;
    if (i == 1)
      bool = false; 
    this.j = bool;
  }
  
  void g(int paramInt) {
    this.i = paramInt;
  }
  
  void h(int paramInt) {
    this.c = paramInt;
  }
  
  public int i() {
    return b(this.g);
  }
  
  public int j() {
    return b(this.h);
  }
  
  public String k() {
    return c(this.b);
  }
  
  public int l() {
    return this.d;
  }
  
  public boolean m() {
    return this.k;
  }
}


/* Location:              C:\soft\dex2jar-2.0\Hill race-dex2jar.jar!\com\adcolony\sdk\n.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */