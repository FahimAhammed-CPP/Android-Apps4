package com.adcolony.sdk;

import android.content.Context;
import android.graphics.Rect;
import android.view.View;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

class x {
  private ConcurrentHashMap<String, Runnable> a;
  
  private HashMap<String, u> b;
  
  private ConcurrentHashMap<String, j> c;
  
  private ConcurrentHashMap<String, e> d;
  
  private ConcurrentHashMap<String, e> e;
  
  private Map<String, d> f;
  
  private final Object g = new Object();
  
  private boolean H(j0 paramj0) {
    e0 e0 = paramj0.a();
    int i = v.A(e0, "status");
    if (i != 5 && i != 1 && i != 0) {
      k k;
      if (i == 6)
        return false; 
      String str = v.E(e0, "id");
      j j = this.c.remove(str);
      if (j == null) {
        e0 = null;
      } else {
        k = j.z();
      } 
      if (k == null) {
        l(paramj0.c(), str);
        return false;
      } 
      u1.G(new q(this, k, j));
      j.K();
      j.g(null);
      return true;
    } 
    return false;
  }
  
  private boolean J(j0 paramj0) {
    String str = v.E(paramj0.a(), "id");
    e0 e0 = v.q();
    v.n(e0, "id", str);
    Context context = q.a();
    if (context == null) {
      v.w(e0, "has_audio", false);
      paramj0.b(e0).e();
      return false;
    } 
    boolean bool = u1.F(u1.f(context));
    double d = u1.a(u1.f(context));
    v.w(e0, "has_audio", bool);
    v.k(e0, "volume", d);
    paramj0.b(e0).e();
    return bool;
  }
  
  private boolean N(j0 paramj0) {
    StringBuilder stringBuilder;
    e0 e0 = paramj0.a();
    String str1 = paramj0.c();
    String str2 = v.E(e0, "ad_session_id");
    int i = v.A(e0, "view_id");
    u u = this.b.get(str2);
    if (u == null) {
      l(str1, str2);
      return false;
    } 
    View view = u.w().get(Integer.valueOf(i));
    if (view == null) {
      stringBuilder = new StringBuilder();
      stringBuilder.append("");
      stringBuilder.append(i);
      l(str1, stringBuilder.toString());
      return false;
    } 
    stringBuilder.removeView(view);
    stringBuilder.addView(view, view.getLayoutParams());
    return true;
  }
  
  private boolean O(j0 paramj0) {
    StringBuilder stringBuilder;
    e0 e0 = paramj0.a();
    String str1 = paramj0.c();
    String str2 = v.E(e0, "ad_session_id");
    int i = v.A(e0, "view_id");
    u u = this.b.get(str2);
    if (u == null) {
      l(str1, str2);
      return false;
    } 
    View view = u.w().get(Integer.valueOf(i));
    if (view == null) {
      stringBuilder = new StringBuilder();
      stringBuilder.append("");
      stringBuilder.append(i);
      l(str1, stringBuilder.toString());
      return false;
    } 
    stringBuilder.bringToFront();
    return true;
  }
  
  private boolean P(j0 paramj0) {
    boolean bool;
    e0 e0 = paramj0.a();
    String str = v.E(e0, "id");
    j j = this.c.get(str);
    d d = this.f.get(str);
    int i = v.a(e0, "orientation", -1);
    if (d != null) {
      bool = true;
    } else {
      bool = false;
    } 
    if (j == null && !bool) {
      l(paramj0.c(), str);
      return false;
    } 
    v.n(v.q(), "id", str);
    if (j != null) {
      j.d(i);
      j.J();
    } 
    return true;
  }
  
  private void e(e parame) {
    u1.G(new n(this, parame));
  }
  
  private void f(j paramj) {
    paramj.M();
    if (!q.j()) {
      b0.a a = (new b0.a()).c("RequestNotFilled called due to a missing context. ");
      StringBuilder stringBuilder = new StringBuilder();
      stringBuilder.append("Interstitial with adSessionId(");
      stringBuilder.append(paramj.m());
      stringBuilder.append(").");
      a.c(stringBuilder.toString()).d(b0.i);
    } 
  }
  
  private boolean z(j0 paramj0) {
    String str = v.E(paramj0.a(), "ad_session_id");
    u u = this.b.get(str);
    if (u == null) {
      l(paramj0.c(), str);
      return false;
    } 
    h(u);
    return true;
  }
  
  ConcurrentHashMap<String, e> B() {
    return this.d;
  }
  
  boolean D(j0 paramj0) {
    e0 e0 = paramj0.a();
    String str = v.E(e0, "id");
    if (v.A(e0, "type") == 0) {
      j j = this.c.remove(str);
      if (q.j() && j != null && j.L()) {
        u1.G(new j(this));
      } else {
        l(paramj0.c(), str);
      } 
    } 
    return true;
  }
  
  ConcurrentHashMap<String, j> E() {
    return this.c;
  }
  
  List<j> I() {
    ArrayList<j> arrayList = new ArrayList();
    for (j j : E().values()) {
      if (!j.E())
        arrayList.add(j); 
    } 
    return arrayList;
  }
  
  void K() {
    this.a = new ConcurrentHashMap<String, Runnable>();
    this.b = new HashMap<String, u>();
    this.c = new ConcurrentHashMap<String, j>();
    this.d = new ConcurrentHashMap<String, e>();
    this.e = new ConcurrentHashMap<String, e>();
    this.f = Collections.synchronizedMap(new HashMap<String, d>());
    q.g("AdContainer.create", new l(this));
    q.g("AdContainer.destroy", new t(this));
    q.g("AdContainer.move_view_to_index", new u(this));
    q.g("AdContainer.move_view_to_front", new v(this));
    q.g("AdSession.finish_fullscreen_ad", new w(this));
    q.g("AdSession.start_fullscreen_ad", new x(this));
    q.g("AdSession.ad_view_available", new y(this));
    q.g("AdSession.ad_view_unavailable", new z(this));
    q.g("AdSession.expiring", new a(this));
    q.g("AdSession.audio_stopped", new b(this));
    q.g("AdSession.audio_started", new c(this));
    q.g("AdSession.interstitial_available", new d(this));
    q.g("AdSession.interstitial_unavailable", new e(this));
    q.g("AdSession.has_audio", new f(this));
    q.g("WebView.prepare", new g(this));
    q.g("AdSession.expanded", new h(this));
    q.g("AdColony.odt_event", new i(this));
  }
  
  boolean L(j0 paramj0) {
    k k;
    String str = v.E(paramj0.a(), "id");
    j j = this.c.remove(str);
    if (j == null) {
      k = null;
    } else {
      k = j.z();
    } 
    if (k == null) {
      l(paramj0.c(), str);
      return false;
    } 
    u1.K(this.a.remove(str));
    f(j);
    return true;
  }
  
  boolean M(j0 paramj0) {
    e0 e0 = paramj0.a();
    String str = v.E(e0, "id");
    j j = this.c.get(str);
    if (j != null) {
      if (j.F())
        return false; 
      k k = j.z();
      if (k == null) {
        l(paramj0.c(), str);
        return false;
      } 
      u1.K(this.a.remove(str));
      if (!q.j()) {
        f(j);
        return false;
      } 
      j.S();
      j.i(v.E(e0, "ad_id"));
      j.r(v.E(e0, "creative_id"));
      j.t(v.E(e0, "ad_request_id"));
      u1.G(new m(this, paramj0, j, k));
      return true;
    } 
    return false;
  }
  
  d a(String paramString) {
    synchronized (this.g) {
      return this.f.remove(paramString);
    } 
  }
  
  void c() {
    for (j j : this.c.values()) {
      if (j != null && j.I()) {
        j.w("Controller was reloaded and current ad was closed");
        break;
      } 
    } 
  }
  
  void d(Context paramContext, e0 parame0, String paramString) {
    j0 j0 = new j0("AdSession.finish_fullscreen_ad", 0);
    v.u(parame0, "status", 1);
    j0.d(parame0);
    (new b0.a()).c(paramString).d(b0.h);
    ((r)paramContext).c(j0);
  }
  
  void g(t paramt, String paramString, u paramu) {
    u1.G(new r(this, paramString, paramt, paramu));
  }
  
  void h(u paramu) {
    u1.G(new s(this, paramu));
    d d = this.f.get(paramu.b());
    if (d == null || d.g()) {
      this.b.remove(paramu.b());
      paramu.z = null;
    } 
  }
  
  void j(String paramString, e parame, c paramc, b paramb, long paramLong) {
    String str = u1.i();
    float f = q.h().H0().Y();
    e0 e0 = v.q();
    v.n(e0, "zone_id", paramString);
    v.u(e0, "type", 1);
    v.u(e0, "width_pixels", (int)(paramc.b() * f));
    v.u(e0, "height_pixels", (int)(paramc.a() * f));
    v.u(e0, "width", paramc.b());
    v.u(e0, "height", paramc.a());
    v.n(e0, "id", str);
    if (paramb != null) {
      e0 e01 = paramb.c;
      if (e01 != null)
        v.m(e0, "options", e01); 
    } 
    parame.a(paramString);
    parame.a(paramc);
    this.d.put(str, parame);
    this.a.put(str, new o(this, str, paramString, paramLong));
    (new j0("AdSession.on_request", 1, e0)).e();
    u1.r(this.a.get(str), paramLong);
  }
  
  void k(String paramString, k paramk, b paramb, long paramLong) {
    String str = u1.i();
    p0 p0 = q.h();
    j j = new j(str, paramk, paramString);
    e0 e0 = v.q();
    v.n(e0, "zone_id", paramString);
    v.w(e0, "fullscreen", true);
    Rect rect = p0.H0().c0();
    v.u(e0, "width", rect.width());
    v.u(e0, "height", rect.height());
    v.u(e0, "type", 0);
    v.n(e0, "id", str);
    if (paramb != null && paramb.c != null) {
      j.e(paramb);
      v.m(e0, "options", paramb.c);
    } 
    this.c.put(str, j);
    this.a.put(str, new p(this, str, paramString, paramLong));
    (new j0("AdSession.on_request", 1, e0)).e();
    u1.r(this.a.get(str), paramLong);
  }
  
  void l(String paramString1, String paramString2) {
    (new b0.a()).c("Message '").c(paramString1).c("' sent with invalid id: ").c(paramString2).d(b0.h);
  }
  
  boolean n(j0 paramj0) {
    String str = v.E(paramj0.a(), "id");
    e e = this.d.remove(str);
    if (e == null) {
      l(paramj0.c(), str);
      return false;
    } 
    u1.K(this.a.remove(str));
    e(e);
    return true;
  }
  
  void p() {
    null = new HashSet();
    synchronized (this.g) {
      for (String str : this.e.keySet()) {
        e e = this.e.remove(str);
        if (e != null)
          null.add(e); 
      } 
      for (String str : this.d.keySet()) {
        e e = this.d.remove(str);
        if (e != null)
          null.add(e); 
      } 
      null = (Object<e>)null.iterator();
      while (null.hasNext())
        e(null.next()); 
      for (String str : this.c.keySet()) {
        j j = this.c.get(str);
        if (j != null && j.H()) {
          this.c.remove(str);
          f(j);
        } 
      } 
      return;
    } 
  }
  
  boolean r(j0 paramj0) {
    String str = v.E(paramj0.a(), "id");
    e e = this.d.remove(str);
    if (e == null) {
      l(paramj0.c(), str);
      return false;
    } 
    this.e.put(str, e);
    u1.K(this.a.remove(str));
    Context context = q.a();
    if (context == null) {
      e(e);
      return false;
    } 
    u1.G(new k(this, context, paramj0, e, str));
    return true;
  }
  
  HashMap<String, u> s() {
    return this.b;
  }
  
  boolean v(j0 paramj0) {
    Context context = q.a();
    if (context == null)
      return false; 
    e0 e02 = paramj0.a();
    String str = v.E(e02, "ad_session_id");
    u u = new u(context.getApplicationContext(), str);
    u.I(paramj0);
    this.b.put(str, u);
    if (v.A(e02, "width") == 0) {
      j j = this.c.get(str);
      if (j == null) {
        l(paramj0.c(), str);
        return false;
      } 
      j.g(u);
    } else {
      u.s(false);
    } 
    e0 e01 = v.q();
    v.w(e01, "success", true);
    paramj0.b(e01).e();
    return true;
  }
  
  Map<String, d> w() {
    return this.f;
  }
  
  class a implements o0 {
    a(x this$0) {}
    
    public void a(j0 param1j0) {
      this.a.D(param1j0);
    }
  }
  
  class b implements o0 {
    b(x this$0) {}
    
    public void a(j0 param1j0) {
      u1.G(new a(this, param1j0));
    }
    
    class a implements Runnable {
      a(x.b this$0, j0 param2j0) {}
      
      public void run() {
        j j = (j)x.F(this.c.a).get(v.E(this.b.a(), "id"));
        if (j != null && j.z() != null)
          j.z().onAudioStopped(j); 
      }
    }
  }
  
  class a implements Runnable {
    a(x this$0, j0 param1j0) {}
    
    public void run() {
      j j = (j)x.F(this.c.a).get(v.E(this.b.a(), "id"));
      if (j != null && j.z() != null)
        j.z().onAudioStopped(j); 
    }
  }
  
  class c implements o0 {
    c(x this$0) {}
    
    public void a(j0 param1j0) {
      u1.G(new a(this, param1j0));
    }
    
    class a implements Runnable {
      a(x.c this$0, j0 param2j0) {}
      
      public void run() {
        j j = (j)x.F(this.c.a).get(v.E(this.b.a(), "id"));
        if (j != null && j.z() != null)
          j.z().onAudioStarted(j); 
      }
    }
  }
  
  class a implements Runnable {
    a(x this$0, j0 param1j0) {}
    
    public void run() {
      j j = (j)x.F(this.c.a).get(v.E(this.b.a(), "id"));
      if (j != null && j.z() != null)
        j.z().onAudioStarted(j); 
    }
  }
  
  class d implements o0 {
    d(x this$0) {}
    
    public void a(j0 param1j0) {
      this.a.M(param1j0);
    }
  }
  
  class e implements o0 {
    e(x this$0) {}
    
    public void a(j0 param1j0) {
      this.a.L(param1j0);
    }
  }
  
  class f implements o0 {
    f(x this$0) {}
    
    public void a(j0 param1j0) {
      x.m(this.a, param1j0);
    }
  }
  
  class g implements o0 {
    g(x this$0) {}
    
    public void a(j0 param1j0) {
      e0 e0 = v.q();
      v.w(e0, "success", true);
      param1j0.b(e0).e();
    }
  }
  
  class h implements o0 {
    h(x this$0) {}
    
    public void a(j0 param1j0) {
      u1.G(new a(this, param1j0));
    }
    
    class a implements Runnable {
      a(x.h this$0, j0 param2j0) {}
      
      public void run() {
        j0 j01 = this.b;
        j01.b(j01.a()).e();
      }
    }
  }
  
  class a implements Runnable {
    a(x this$0, j0 param1j0) {}
    
    public void run() {
      j0 j01 = this.b;
      j01.b(j01.a()).e();
    }
  }
  
  class i implements o0 {
    i(x this$0) {}
    
    public void a(j0 param1j0) {
      y0.n().d(param1j0);
    }
  }
  
  class j implements Runnable {
    j(x this$0) {}
    
    public void run() {
      d1 d1 = q.h().K0();
      if (d1.a() != null) {
        d1.a().dismiss();
        d1.d(null);
      } 
    }
  }
  
  class k implements Runnable {
    k(x this$0, Context param1Context, j0 param1j0, e param1e, String param1String) {}
    
    public void run() {
      try {
        d d = new d(this.b, this.c, this.d);
      } catch (RuntimeException null) {
        (new b0.a()).c(null.toString()).d(b0.i);
        null = null;
      } 
      synchronized (x.b(this.f)) {
        if (x.o(this.f).remove(this.e) == null)
          return; 
        if (null == null) {
          x.i(this.f, this.d);
          return;
        } 
        x.A(this.f).put(this.e, null);
        null.setOmidManager(this.d.b());
        null.i();
        this.d.a((z0)null);
        this.d.onRequestFilled((d)null);
        return;
      } 
    }
  }
  
  class l implements o0 {
    l(x this$0) {}
    
    public void a(j0 param1j0) {
      u1.G(new a(this, param1j0));
    }
    
    class a implements Runnable {
      a(x.l this$0, j0 param2j0) {}
      
      public void run() {
        this.c.a.v(this.b);
      }
    }
  }
  
  class a implements Runnable {
    a(x this$0, j0 param1j0) {}
    
    public void run() {
      this.c.a.v(this.b);
    }
  }
  
  class m implements Runnable {
    m(x this$0, j0 param1j0, j param1j, k param1k) {}
    
    public void run() {
      e0 e0 = this.b.a();
      if (this.c.v() == null)
        this.c.h(v.C(e0, "iab")); 
      this.c.i(v.E(e0, "ad_id"));
      this.c.r(v.E(e0, "creative_id"));
      this.c.Q(v.E(e0, "view_network_pass_filter"));
      z0 z0 = this.c.v();
      if (z0 != null && z0.o() != 2)
        try {
          z0.c();
        } catch (IllegalArgumentException illegalArgumentException) {
          (new b0.a()).c("IllegalArgumentException when creating omid session").d(b0.i);
        }  
      this.d.onRequestFilled(this.c);
    }
  }
  
  class n implements Runnable {
    n(x this$0, e param1e) {}
    
    public void run() {
      e e1 = this.b;
      e1.onRequestNotFilled(a.a(e1.c()));
      if (!q.j())
        (new b0.a()).c("RequestNotFilled called for AdView due to a missing context. ").d(b0.i); 
    }
  }
  
  class o implements Runnable {
    o(x this$0, String param1String1, String param1String2, long param1Long) {}
    
    public void run() {
      x.t(this.e).remove(this.b);
      e e = (e)x.x(this.e).remove(this.b);
      if (e != null) {
        e.onRequestNotFilled(a.a(this.c));
        e0 e0 = v.q();
        v.n(e0, "id", this.b);
        v.n(e0, "zone_id", this.c);
        v.u(e0, "type", 1);
        v.u(e0, "request_fail_reason", 26);
        (new j0("AdSession.on_request_failure", 1, e0)).e();
        b0.a a = (new b0.a()).c("RequestNotFilled called due to a native timeout. ");
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("Timeout set to: ");
        stringBuilder.append(q.h().g0());
        stringBuilder.append(" ms. ");
        a = a.c(stringBuilder.toString());
        stringBuilder = new StringBuilder();
        stringBuilder.append("AdView request time allowed: ");
        stringBuilder.append(this.d);
        stringBuilder.append(" ms. ");
        a = a.c(stringBuilder.toString());
        stringBuilder = new StringBuilder();
        stringBuilder.append("AdView with adSessionId(");
        stringBuilder.append(this.b);
        stringBuilder.append(") - request failed.");
        a.c(stringBuilder.toString()).d(b0.i);
      } 
    }
  }
  
  class p implements Runnable {
    p(x this$0, String param1String1, String param1String2, long param1Long) {}
    
    public void run() {
      k k;
      x.t(this.e).remove(this.b);
      j j = (j)x.F(this.e).remove(this.b);
      if (j == null) {
        j = null;
      } else {
        k = j.z();
      } 
      if (k != null) {
        k.onRequestNotFilled(a.a(this.c));
        e0 e0 = v.q();
        v.n(e0, "id", this.b);
        v.n(e0, "zone_id", this.c);
        v.u(e0, "type", 0);
        v.u(e0, "request_fail_reason", 26);
        (new j0("AdSession.on_request_failure", 1, e0)).e();
        b0.a a = (new b0.a()).c("RequestNotFilled called due to a native timeout. ");
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("Timeout set to: ");
        stringBuilder.append(q.h().g0());
        stringBuilder.append(" ms. ");
        a = a.c(stringBuilder.toString());
        stringBuilder = new StringBuilder();
        stringBuilder.append("Interstitial request time allowed: ");
        stringBuilder.append(this.d);
        stringBuilder.append(" ms. ");
        a = a.c(stringBuilder.toString());
        stringBuilder = new StringBuilder();
        stringBuilder.append("Interstitial with adSessionId(");
        stringBuilder.append(this.b);
        stringBuilder.append(") - request failed.");
        a.c(stringBuilder.toString()).d(b0.i);
      } 
    }
  }
  
  class q implements Runnable {
    q(x this$0, k param1k, j param1j) {}
    
    public void run() {
      q.h().o0(false);
      this.b.onClosed(this.c);
    }
  }
  
  class r implements Runnable {
    r(x this$0, String param1String, t param1t, u param1u) {}
    
    public void run() {
      int i;
      z0 z0;
      try {
        z0 z01;
        j j = this.e.E().get(this.b);
        d d = this.e.w().get(this.b);
        if (j == null) {
          j = null;
        } else {
          z01 = j.v();
        } 
        z0 = z01;
        if (z01 == null) {
          z0 = z01;
          if (d != null)
            z0 = d.getOmidManager(); 
        } 
      } catch (IllegalArgumentException illegalArgumentException) {
        (new b0.a()).c("IllegalArgumentException when creating omid session").d(b0.i);
        return;
      } 
      if (z0 == null) {
        i = -1;
      } else {
        i = z0.o();
      } 
      if (z0 != null && i == 2) {
        z0.d(this.c);
        z0.e(this.d);
        return;
      } 
    }
  }
  
  class s implements Runnable {
    s(x this$0, u param1u) {}
    
    public void run() {
      for (int i = 0; i < this.b.F().size(); i++)
        q.i(this.b.H().get(i), this.b.F().get(i)); 
      this.b.H().clear();
      this.b.F().clear();
      this.b.removeAllViews();
      u u1 = this.b;
      u1.A = null;
      u1.z = null;
      for (t t : u1.M().values()) {
        if (!(t instanceof a0)) {
          if (t instanceof w) {
            q.h().J((w)t);
            continue;
          } 
          t.x();
        } 
      } 
      for (p p : this.b.L().values()) {
        p.L();
        p.N();
      } 
      this.b.L().clear();
      this.b.K().clear();
      this.b.M().clear();
      this.b.D().clear();
      this.b.w().clear();
      this.b.z().clear();
      this.b.B().clear();
      this.b.n = true;
    }
  }
  
  class t implements o0 {
    t(x this$0) {}
    
    public void a(j0 param1j0) {
      u1.G(new a(this, param1j0));
    }
    
    class a implements Runnable {
      a(x.t this$0, j0 param2j0) {}
      
      public void run() {
        x.q(this.c.a, this.b);
      }
    }
  }
  
  class a implements Runnable {
    a(x this$0, j0 param1j0) {}
    
    public void run() {
      x.q(this.c.a, this.b);
    }
  }
  
  class u implements o0 {
    u(x this$0) {}
    
    public void a(j0 param1j0) {
      x.u(this.a, param1j0);
    }
  }
  
  class v implements o0 {
    v(x this$0) {}
    
    public void a(j0 param1j0) {
      x.y(this.a, param1j0);
    }
  }
  
  class w implements o0 {
    w(x this$0) {}
    
    public void a(j0 param1j0) {
      x.C(this.a, param1j0);
    }
  }
  
  class x implements o0 {
    x(x this$0) {}
    
    public void a(j0 param1j0) {
      x.G(this.a, param1j0);
    }
  }
  
  class y implements o0 {
    y(x this$0) {}
    
    public void a(j0 param1j0) {
      this.a.r(param1j0);
    }
  }
  
  class z implements o0 {
    z(x this$0) {}
    
    public void a(j0 param1j0) {
      this.a.n(param1j0);
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Hill race-dex2jar.jar!\com\adcolony\sdk\x.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */