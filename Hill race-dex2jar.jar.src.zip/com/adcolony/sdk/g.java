package com.adcolony.sdk;

public class g {
  private String a;
  
  private String b;
  
  public g(String paramString1, String paramString2) {
    if (u1.R(paramString1) || u1.R(paramString2)) {
      this.a = paramString1;
      this.b = paramString2;
    } 
  }
  
  public String a() {
    return this.b;
  }
}


/* Location:              C:\soft\dex2jar-2.0\Hill race-dex2jar.jar!\com\adcolony\sdk\g.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */