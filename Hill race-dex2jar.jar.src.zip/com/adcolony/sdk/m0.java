package com.adcolony.sdk;

import android.content.Context;
import android.database.ContentObserver;
import android.media.AudioManager;
import android.os.Handler;
import android.provider.Settings;

class m0 extends ContentObserver {
  private AudioManager a;
  
  private j b;
  
  m0(Handler paramHandler, j paramj) {
    super(paramHandler);
    Context context = q.a();
    if (context != null) {
      this.a = (AudioManager)context.getSystemService("audio");
      this.b = paramj;
      context.getApplicationContext().getContentResolver().registerContentObserver(Settings.System.CONTENT_URI, true, this);
    } 
  }
  
  void a() {
    Context context = q.a();
    if (context != null)
      context.getApplicationContext().getContentResolver().unregisterContentObserver(this); 
    this.b = null;
    this.a = null;
  }
  
  public boolean deliverSelfNotifications() {
    return false;
  }
  
  public void onChange(boolean paramBoolean) {
    if (this.a != null) {
      j j1 = this.b;
      if (j1 != null) {
        if (j1.s() == null)
          return; 
        double d = (this.a.getStreamVolume(3) / 15.0F * 100.0F);
        e0 e0 = v.q();
        v.k(e0, "audio_percentage", d);
        v.n(e0, "ad_session_id", this.b.s().b());
        v.u(e0, "id", this.b.s().q());
        (new j0("AdContainer.on_audio_change", this.b.s().J(), e0)).e();
      } 
    } 
  }
}


/* Location:              C:\soft\dex2jar-2.0\Hill race-dex2jar.jar!\com\adcolony\sdk\m0.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */