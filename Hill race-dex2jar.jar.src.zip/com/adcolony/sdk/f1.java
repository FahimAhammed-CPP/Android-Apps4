package com.adcolony.sdk;

import android.content.Context;
import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.io.PrintStream;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;
import java.util.List;
import java.util.Map;
import java.util.zip.DataFormatException;

class f1 implements Runnable {
  private HttpURLConnection b;
  
  private InputStream c;
  
  private j0 d;
  
  private a e;
  
  private g0 f = null;
  
  private String g;
  
  private int h = 0;
  
  private boolean i = false;
  
  private Map<String, List<String>> j;
  
  private String k = "";
  
  private String l = "";
  
  String m = "";
  
  String n = "";
  
  boolean o;
  
  int p;
  
  int q;
  
  f1(j0 paramj0, a parama) {
    this.d = paramj0;
    this.e = parama;
  }
  
  private void a(InputStream paramInputStream, OutputStream paramOutputStream) throws Exception {
    try {
    
    } finally {
      if (paramOutputStream != null)
        paramOutputStream.close(); 
      if (paramInputStream != null)
        paramInputStream.close(); 
    } 
  }
  
  private void b(String paramString1, String paramString2) {
    try {
      String str = paramString2.substring(0, paramString2.lastIndexOf("/") + 1);
      if (!paramString2.equals("") && !str.equals(q.h().Z0().j()) && !(new File(paramString1)).renameTo(new File(paramString2))) {
        (new b0.a()).c("Moving of ").c(paramString1).c(" failed.").d(b0.g);
        return;
      } 
    } catch (Exception exception) {
      (new b0.a()).c("Exception: ").c(exception.toString()).d(b0.h);
      exception.printStackTrace();
    } 
  }
  
  private boolean d() throws IOException {
    Context context;
    e0 e01 = this.d.a();
    String str2 = v.E(e01, "content_type");
    String str1 = v.E(e01, "content");
    e0 e02 = e01.I("dictionaries");
    e0 e03 = e01.I("dictionaries_mapping");
    this.m = v.E(e01, "url");
    if (e02 != null)
      g0.c(e02.z()); 
    if (q.h().h() && e03 != null)
      this.f = g0.a(v.F(e03, "request"), v.F(e03, "response")); 
    String str3 = v.E(e01, "user_agent");
    int i = v.a(e01, "read_timeout", 60000);
    int j = v.a(e01, "connect_timeout", 60000);
    boolean bool = v.t(e01, "no_redirect");
    this.m = v.E(e01, "url");
    this.k = v.E(e01, "filepath");
    StringBuilder stringBuilder = new StringBuilder();
    stringBuilder.append(q.h().Z0().j());
    String str4 = this.k;
    int k = str4.lastIndexOf("/");
    boolean bool2 = true;
    stringBuilder.append(str4.substring(k + 1));
    this.l = stringBuilder.toString();
    this.g = v.E(e01, "encoding");
    k = v.a(e01, "max_size", 0);
    this.h = k;
    if (k != 0) {
      bool1 = true;
    } else {
      bool1 = false;
    } 
    this.i = bool1;
    this.p = 0;
    this.c = null;
    this.b = null;
    this.j = null;
    if (this.m.startsWith("file://")) {
      if (this.m.startsWith("file:///android_asset/")) {
        context = q.a();
        if (context != null)
          this.c = context.getAssets().open(this.m.substring(22)); 
      } else {
        this.c = new FileInputStream(this.m.substring(7));
      } 
    } else {
      HttpURLConnection httpURLConnection = (HttpURLConnection)(new URL(this.m)).openConnection();
      this.b = httpURLConnection;
      httpURLConnection.setReadTimeout(i);
      this.b.setConnectTimeout(j);
      this.b.setInstanceFollowRedirects(bool ^ true);
      if (str3 != null && !str3.equals(""))
        this.b.setRequestProperty("User-Agent", str3); 
      if (this.f != null) {
        this.b.setRequestProperty("Content-Type", "application/octet-stream");
        this.b.setRequestProperty("Req-Dict-Id", this.f.g());
        this.b.setRequestProperty("Resp-Dict-Id", this.f.j());
      } else {
        this.b.setRequestProperty("Accept-Charset", k0.a.name());
        if (!str2.equals(""))
          this.b.setRequestProperty("Content-Type", str2); 
      } 
      if (this.d.c().equals("WebServices.post")) {
        byte[] arrayOfByte;
        this.b.setDoOutput(true);
        g0 g01 = this.f;
        if (g01 != null) {
          arrayOfByte = g01.d((String)context);
          this.b.setFixedLengthStreamingMode(arrayOfByte.length);
          this.b.getOutputStream().write(arrayOfByte);
          this.b.getOutputStream().flush();
        } else {
          this.b.setFixedLengthStreamingMode((arrayOfByte.getBytes(k0.a)).length);
          (new PrintStream(this.b.getOutputStream())).print((String)arrayOfByte);
        } 
      } 
    } 
    boolean bool1 = bool2;
    if (this.b == null) {
      if (this.c != null)
        return true; 
      bool1 = false;
    } 
    return bool1;
  }
  
  private void e() throws Exception {
    FileOutputStream fileOutputStream;
    ByteArrayOutputStream byteArrayOutputStream;
    String str = this.d.c();
    if (this.c != null) {
      if (this.k.length() == 0) {
        byteArrayOutputStream = new ByteArrayOutputStream(4096);
      } else {
        fileOutputStream = new FileOutputStream((new File(this.k)).getAbsolutePath());
      } 
    } else if (fileOutputStream.equals("WebServices.download")) {
      this.c = this.b.getInputStream();
      fileOutputStream = new FileOutputStream(this.l);
    } else if (fileOutputStream.equals("WebServices.get")) {
      this.c = this.b.getInputStream();
      byteArrayOutputStream = new ByteArrayOutputStream(4096);
    } else if (byteArrayOutputStream.equals("WebServices.post")) {
      InputStream inputStream;
      this.b.connect();
      if (this.b.getResponseCode() >= 200 && this.b.getResponseCode() <= 299) {
        inputStream = this.b.getInputStream();
      } else {
        inputStream = this.b.getErrorStream();
      } 
      this.c = inputStream;
      ByteArrayOutputStream byteArrayOutputStream1 = new ByteArrayOutputStream(4096);
    } else {
      byteArrayOutputStream = null;
    } 
    HttpURLConnection httpURLConnection = this.b;
    if (httpURLConnection != null) {
      this.q = httpURLConnection.getResponseCode();
      this.j = this.b.getHeaderFields();
    } 
    a(this.c, byteArrayOutputStream);
  }
  
  j0 c() {
    return this.d;
  }
  
  public void run() {
    int i = 0;
    this.o = false;
    try {
      if (d()) {
        boolean bool;
        e();
        if (!this.d.c().equals("WebServices.post") || this.q == 200) {
          bool = true;
        } else {
          bool = false;
        } 
        this.o = bool;
      } 
    } catch (MalformedURLException malformedURLException) {
      (new b0.a()).c("MalformedURLException: ").c(malformedURLException.toString()).d(b0.i);
      this.o = true;
    } catch (OutOfMemoryError outOfMemoryError) {
      b0.a a1 = (new b0.a()).c("Out of memory error - disabling AdColony. (").a(this.p).c("/").a(this.h);
      StringBuilder stringBuilder = new StringBuilder();
      stringBuilder.append("): ");
      stringBuilder.append(this.m);
      a1.c(stringBuilder.toString()).d(b0.h);
      q.h().X(true);
    } catch (IOException iOException) {
      (new b0.a()).c("Download of ").c(this.m).c(" failed: ").c(iOException.toString()).d(b0.g);
      int j = this.q;
      i = j;
      if (j == 0)
        i = 504; 
      this.q = i;
    } catch (IllegalStateException illegalStateException) {
      (new b0.a()).c("okhttp error: ").c(illegalStateException.toString()).d(b0.h);
      illegalStateException.printStackTrace();
      if (i != 0) {
        if (this.d.c().equals("WebServices.download"))
          b(this.l, this.k); 
        this.e.a(this, this.d, this.j);
      } 
      return;
    } catch (DataFormatException dataFormatException) {
      (new b0.a()).c("Exception, possibly trying to decompress plain response: ").c(dataFormatException.toString()).d(b0.i);
      dataFormatException.printStackTrace();
      if (i != 0) {
        if (this.d.c().equals("WebServices.download"))
          b(this.l, this.k); 
        this.e.a(this, this.d, this.j);
      } 
      return;
    } catch (IllegalArgumentException illegalArgumentException) {
      (new b0.a()).c("Exception, possibly response encoded with different dictionary: ").c(illegalArgumentException.toString()).d(b0.i);
      illegalArgumentException.printStackTrace();
    } catch (AssertionError assertionError) {
      (new b0.a()).c("okhttp error: ").c(assertionError.toString()).d(b0.h);
      assertionError.printStackTrace();
    } catch (Exception exception) {
      (new b0.a()).c("Exception: ").c(exception.toString()).d(b0.h);
      exception.printStackTrace();
    } 
    i = 1;
    if (i != 0) {
      if (this.d.c().equals("WebServices.download"))
        b(this.l, this.k); 
      this.e.a(this, this.d, this.j);
    } 
  }
  
  static interface a {
    void a(f1 param1f1, j0 param1j0, Map<String, List<String>> param1Map);
  }
}


/* Location:              C:\soft\dex2jar-2.0\Hill race-dex2jar.jar!\com\adcolony\sdk\f1.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */