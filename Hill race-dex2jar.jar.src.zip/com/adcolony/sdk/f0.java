package com.adcolony.sdk;

class f0 {
  private boolean a;
  
  public void a(long paramLong) {
    // Byte code:
    //   0: aload_0
    //   1: monitorenter
    //   2: aload_0
    //   3: getfield a : Z
    //   6: istore_3
    //   7: iload_3
    //   8: ifne -> 16
    //   11: aload_0
    //   12: lload_1
    //   13: invokevirtual wait : (J)V
    //   16: aload_0
    //   17: monitorexit
    //   18: return
    //   19: astore #4
    //   21: aload_0
    //   22: monitorexit
    //   23: aload #4
    //   25: athrow
    //   26: astore #4
    //   28: goto -> 16
    // Exception table:
    //   from	to	target	type
    //   2	7	19	finally
    //   11	16	26	java/lang/InterruptedException
    //   11	16	19	finally
  }
  
  public void b(boolean paramBoolean) {
    // Byte code:
    //   0: aload_0
    //   1: monitorenter
    //   2: aload_0
    //   3: iload_1
    //   4: putfield a : Z
    //   7: iload_1
    //   8: ifeq -> 15
    //   11: aload_0
    //   12: invokevirtual notifyAll : ()V
    //   15: aload_0
    //   16: monitorexit
    //   17: return
    //   18: astore_2
    //   19: aload_0
    //   20: monitorexit
    //   21: aload_2
    //   22: athrow
    // Exception table:
    //   from	to	target	type
    //   2	7	18	finally
    //   11	15	18	finally
  }
  
  public boolean c() {
    return this.a;
  }
}


/* Location:              C:\soft\dex2jar-2.0\Hill race-dex2jar.jar!\com\adcolony\sdk\f0.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */