package com.adcolony.sdk;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.app.Application;
import android.content.Context;
import android.os.Build;
import android.os.Bundle;
import android.os.Looper;
import android.util.Base64;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.Locale;
import java.util.concurrent.Callable;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import org.json.JSONException;

public class a {
  private static ExecutorService a = u1.X();
  
  public static boolean A(String paramString, k paramk, b paramb) {
    if (paramk == null)
      (new b0.a()).c("AdColonyInterstitialListener is set to null. ").c("It is required to be non null.").d(b0.f); 
    if (!q.l()) {
      (new b0.a()).c("Ignoring call to AdColony.requestInterstitial as AdColony has not").c(" yet been configured.").d(b0.f);
      h(paramk, paramString);
      return false;
    } 
    Bundle bundle = new Bundle();
    bundle.putString("zone_id", paramString);
    if (e1.a(1, bundle)) {
      h(paramk, paramString);
      return false;
    } 
    u1.c c = new u1.c(q.h().g0());
    f f = new f(paramk, paramString, c);
    u1.r(f, c.e());
    if (!j(new g(f, paramString, paramk, paramb, c))) {
      u1.p(f);
      return false;
    } 
    return true;
  }
  
  public static boolean B(f paramf) {
    if (!q.l()) {
      (new b0.a()).c("Ignoring call to AdColony.setAppOptions() as AdColony has not yet").c(" been configured.").d(b0.f);
      return false;
    } 
    f f1 = paramf;
    if (paramf == null)
      f1 = new f(); 
    q.e(f1);
    if (q.k()) {
      p0 p0 = q.h();
      if (p0.d())
        f1.a(p0.V0().b()); 
    } 
    q.h().T(f1);
    Context context = q.a();
    if (context != null)
      f1.e(context); 
    return j(new e(f1));
  }
  
  public static boolean C(m paramm) {
    if (!q.l()) {
      (new b0.a()).c("Ignoring call to AdColony.setRewardListener() as AdColony has not").c(" yet been configured.").d(b0.f);
      return false;
    } 
    q.h().C(paramm);
    return true;
  }
  
  static n a(String paramString) {
    n n1;
    if (q.j()) {
      n1 = q.h().c().get(paramString);
    } else if (q.k()) {
      n1 = q.h().c().get(paramString);
    } else {
      n1 = null;
    } 
    n n2 = n1;
    if (n1 == null) {
      n2 = new n(paramString);
      n2.h(6);
    } 
    return n2;
  }
  
  private static String c(p0 paramp0, i1 parami1) {
    return m(paramp0, parami1, -1L);
  }
  
  static String d(byte[] paramArrayOfbyte) {
    g0 g0 = new g0("sa01", "", "{\"origin_store\":\"google\",\"app_id\":\",\"bundle_id\":\",\"os_name\":\"android\",\"zone_ids\":[\"],\"carrier_name\":\",\"screen_width\":,\"screen_height\":,\"device_type\":\"phonetablet\",\"locale_language_code\":\",\"ln\":\",\"locale_country_code\":\",\"locale\":\",\"manufacturer\":\",\"device_brand\":\",\"device_model\":\",\"sdk_type\":\"android_native\",\"sdk_version\":\"4.\",\"network_type\":\"cellwifi\",\"os_version\":\",\"platform\":\"android\",\"app_bundle_name\":\",\"app_bundle_version\":\",\"battery_level\":,\"cell_service_country_code\":\",\"controller_version\":\",\"current_orientation\":,\"cleartext_permitted\":,\"available_stores\":[\"],\"advertiser_id\":\",\"limit_tracking\":false,\"adc_alt_id\":\",\"odt_payload\":{\"config\":{\"Q1\":[\",\\\"session_start\\\"\"],\"Q2\":[\",\\\"configure\\\"\"],\"Q3\":[\"],\"Q4\":[\"],\"Q5\":[\"],\"Q6\":[\"]},\"session\":{},\"events\":{},\"version\":},\"signals_count\":,\"device_audio\":true}", "");
    try {
      byte[] arrayOfByte = g0.e(paramArrayOfbyte);
      e0 e0 = v.q();
      e0.f("a", g0.g());
      e0.f("b", Base64.encodeToString(arrayOfByte, 0));
      return e0.toString();
    } catch (JSONException|java.io.UnsupportedEncodingException jSONException) {
      return Base64.encodeToString(paramArrayOfbyte, 0);
    } 
  }
  
  static void f(Context paramContext, f paramf) {
    p0 p0 = q.h();
    b1 b1 = p0.H0();
    if (paramf != null) {
      if (paramContext == null)
        return; 
      String str1 = u1.O(paramContext);
      String str2 = u1.J();
      int i = u1.M();
      String str3 = b1.S();
      String str4 = p0.R0().h();
      HashMap<Object, Object> hashMap = new HashMap<Object, Object>();
      hashMap.put("sessionId", "unknown");
      StringBuilder stringBuilder2 = new StringBuilder();
      stringBuilder2.append(Locale.getDefault().getDisplayLanguage());
      stringBuilder2.append(" (");
      stringBuilder2.append(Locale.getDefault().getDisplayCountry());
      stringBuilder2.append(")");
      hashMap.put("countryLocale", stringBuilder2.toString());
      hashMap.put("countryLocaleShort", q.h().H0().V());
      hashMap.put("manufacturer", q.h().H0().c());
      hashMap.put("model", q.h().H0().f());
      hashMap.put("osVersion", q.h().H0().h());
      hashMap.put("carrierName", str3);
      hashMap.put("networkType", str4);
      hashMap.put("platform", "android");
      hashMap.put("appName", str1);
      hashMap.put("appVersion", str2);
      hashMap.put("appBuildNumber", Integer.valueOf(i));
      StringBuilder stringBuilder1 = new StringBuilder();
      stringBuilder1.append("");
      stringBuilder1.append(paramf.b());
      hashMap.put("appId", stringBuilder1.toString());
      hashMap.put("apiLevel", Integer.valueOf(Build.VERSION.SDK_INT));
      hashMap.put("sdkVersion", q.h().H0().i());
      hashMap.put("controllerVersion", "unknown");
      e0 e02 = new e0(paramf.h());
      e0 e01 = new e0(paramf.k());
      if (!v.E(e02, "mediation_network").equals("")) {
        hashMap.put("mediationNetwork", v.E(e02, "mediation_network"));
        hashMap.put("mediationNetworkVersion", v.E(e02, "mediation_network_version"));
      } 
      if (!v.E(e01, "plugin").equals("")) {
        hashMap.put("plugin", v.E(e01, "plugin"));
        hashMap.put("pluginVersion", v.E(e01, "plugin_version"));
      } 
      p0.N0().h((HashMap)hashMap);
    } 
  }
  
  static void g(e parame, String paramString) {
    if (parame != null)
      u1.G(new a(parame, paramString)); 
  }
  
  static void h(k paramk, String paramString) {
    if (paramk != null)
      u1.G(new h(paramk, paramString)); 
  }
  
  @SuppressLint({"ObsoleteSdkInt"})
  private static boolean i(Context paramContext, f paramf, String paramString) {
    if (e1.a(0, null)) {
      (new b0.a()).c("Cannot configure AdColony; configuration mechanism requires 5 ").c("seconds between attempts.").d(b0.f);
      return false;
    } 
    Context context = paramContext;
    if (paramContext == null)
      context = q.a(); 
    if (context == null) {
      (new b0.a()).c("Ignoring call to AdColony.configure() as the provided Activity or ").c("Application context is null and we do not currently hold a ").c("reference to either for our use.").d(b0.f);
      return false;
    } 
    if (Looper.myLooper() == null)
      Looper.prepare(); 
    f f1 = paramf;
    if (paramf == null)
      f1 = new f(); 
    if (q.k() && !v.t(q.h().V0().d(), "reconfigurable") && !q.h().V0().b().equals(paramString)) {
      (new b0.a()).c("Ignoring call to AdColony.configure() as the app id does not ").c("match what was used during the initial configuration.").d(b0.f);
      return false;
    } 
    if (paramString.equals("")) {
      (new b0.a()).c("AdColony.configure() called with an empty app id String.").d(b0.h);
      return false;
    } 
    q.c = true;
    f1.a(paramString);
    if (Build.VERSION.SDK_INT < 21) {
      (new b0.a()).c("The minimum API level for the AdColony SDK is ").a(21).c(".").d(b0.f);
      q.d(context, f1, true);
    } else {
      q.d(context, f1, false);
    } 
    StringBuilder stringBuilder = new StringBuilder();
    stringBuilder.append(q.h().Z0().l());
    stringBuilder.append("/adc3/AppInfo");
    String str = stringBuilder.toString();
    e0 e0 = v.q();
    v.n(e0, "appId", paramString);
    v.G(e0, str);
    return true;
  }
  
  static boolean j(Runnable paramRunnable) {
    return u1.u(a, paramRunnable);
  }
  
  public static boolean k(h paramh, String paramString) {
    if (!q.l()) {
      (new b0.a()).c("Ignoring call to AdColony.addCustomMessageListener as AdColony ").c("has not yet been configured.").d(b0.f);
      return false;
    } 
    if (!u1.R(paramString)) {
      (new b0.a()).c("Ignoring call to AdColony.addCustomMessageListener.").d(b0.f);
      return false;
    } 
    q.h().F0().put(paramString, paramh);
    return true;
  }
  
  private static e0 l(long paramLong) {
    x0.b b;
    e0 e0 = v.q();
    if (paramLong > 0L) {
      b = y0.n().b(paramLong);
    } else {
      b = y0.n().k();
    } 
    if (b != null)
      v.m(e0, "odt_payload", b.d()); 
    return e0;
  }
  
  private static String m(p0 paramp0, i1 parami1, long paramLong) {
    b1 b1 = paramp0.H0();
    ArrayList<e0> arrayList = new ArrayList(Arrays.asList((Object[])new e0[] { u1.I(paramp0.V0().d()), u1.h(b1.J()) }));
    if (paramLong > 0L) {
      c1<e0> c1 = new c1();
      if (b1.n()) {
        arrayList.add(b1.y());
      } else {
        c1.c(b1.s(paramLong));
      } 
      if (b1.o()) {
        arrayList.add(b1.F());
      } else {
        c1.c(b1.A(paramLong));
      } 
      if (paramp0.g()) {
        c1.c(new b(paramLong));
      } else {
        arrayList.add(r());
      } 
      if (!c1.d())
        arrayList.addAll(c1.a()); 
    } else {
      arrayList.add(b1.y());
      arrayList.add(b1.F());
      arrayList.add(r());
    } 
    arrayList.add(paramp0.l0());
    e0 e0 = v.h(arrayList.<e0>toArray(new e0[0]));
    parami1.j();
    v.u(e0, "signals_count", parami1.f());
    v.w(e0, "device_audio", t());
    e0.y();
    byte[] arrayOfByte = e0.toString().getBytes(k0.a);
    return paramp0.h() ? d(arrayOfByte) : Base64.encodeToString(arrayOfByte, 0);
  }
  
  static boolean n() {
    p0 p0 = q.h();
    p0.x(15000L);
    return p0.i();
  }
  
  static void o() {
    if (a.isShutdown())
      a = Executors.newSingleThreadExecutor(); 
  }
  
  @Deprecated
  public static String p() {
    if (!q.l()) {
      (new b0.a()).c("Ignoring call to AdColony.collectSignals() as AdColony has not yet been configured.").d(b0.f);
      return "";
    } 
    p0 p0 = q.h();
    return c(p0, p0.Y0());
  }
  
  public static boolean q(Application paramApplication, f paramf, String paramString) {
    return i((Context)paramApplication, paramf, paramString);
  }
  
  private static e0 r() {
    return l(-1L);
  }
  
  public static boolean s() {
    if (!q.l())
      return false; 
    Context context = q.a();
    if (context != null && context instanceof r)
      ((Activity)context).finish(); 
    p0 p0 = q.h();
    p0.Z().p();
    p0.r();
    p0.t();
    p0.X(true);
    return true;
  }
  
  private static boolean t() {
    Context context = q.a();
    return (context == null) ? false : u1.F(u1.f(context));
  }
  
  private static void u() {
    (new b0.a()).c("The AdColony API is not available while AdColony is disabled.").d(b0.h);
  }
  
  static void v() {
    a.shutdown();
  }
  
  public static String w() {
    return !q.l() ? "" : q.h().H0().i();
  }
  
  public static boolean x(String paramString) {
    if (!q.l()) {
      (new b0.a()).c("Ignoring call to AdColony.removeCustomMessageListener as AdColony").c(" has not yet been configured.").d(b0.f);
      return false;
    } 
    q.h().F0().remove(paramString);
    return true;
  }
  
  public static boolean y(String paramString, e parame, c paramc, b paramb) {
    if (parame == null)
      (new b0.a()).c("AdColonyAdViewListener is set to null. ").c("It is required to be non null.").d(b0.f); 
    if (!q.l()) {
      (new b0.a()).c("Ignoring call to requestAdView as AdColony has not yet been").c(" configured.").d(b0.f);
      g(parame, paramString);
      return false;
    } 
    if (paramc.a() <= 0 || paramc.b() <= 0) {
      (new b0.a()).c("Ignoring call to requestAdView as you've provided an AdColonyAdSize").c(" object with an invalid width or height.").d(b0.f);
      g(parame, paramString);
      return false;
    } 
    Bundle bundle = new Bundle();
    bundle.putString("zone_id", paramString);
    if (e1.a(1, bundle)) {
      g(parame, paramString);
      return false;
    } 
    u1.c c1 = new u1.c(q.h().g0());
    c c2 = new c(parame, paramString, c1);
    u1.r(c2, c1.e());
    if (!j(new d(c2, paramString, parame, paramc, paramb, c1))) {
      u1.p(c2);
      return false;
    } 
    return true;
  }
  
  public static boolean z(String paramString, k paramk) {
    return A(paramString, paramk, null);
  }
  
  class a implements Runnable {
    a(a this$0, String param1String) {}
    
    public void run() {
      this.b.onRequestNotFilled(a.a(this.c));
    }
  }
  
  class b implements Callable<e0> {
    b(a this$0) {}
    
    public e0 b() {
      return a.b(this.a);
    }
  }
  
  class c implements u1.b {
    private boolean b;
    
    c(a this$0, String param1String, u1.c param1c) {}
    
    public boolean a() {
      return this.b;
    }
    
    public void run() {
      // Byte code:
      //   0: aload_0
      //   1: monitorenter
      //   2: aload_0
      //   3: getfield b : Z
      //   6: ifeq -> 12
      //   9: aload_0
      //   10: monitorexit
      //   11: return
      //   12: aload_0
      //   13: iconst_1
      //   14: putfield b : Z
      //   17: aload_0
      //   18: monitorexit
      //   19: aload_0
      //   20: getfield c : Lcom/adcolony/sdk/e;
      //   23: aload_0
      //   24: getfield d : Ljava/lang/String;
      //   27: invokestatic g : (Lcom/adcolony/sdk/e;Ljava/lang/String;)V
      //   30: aload_0
      //   31: getfield e : Lcom/adcolony/sdk/u1$c;
      //   34: invokevirtual b : ()Z
      //   37: ifeq -> 153
      //   40: new com/adcolony/sdk/b0$a
      //   43: dup
      //   44: invokespecial <init> : ()V
      //   47: ldc 'RequestNotFilled called due to a native timeout. '
      //   49: invokevirtual c : (Ljava/lang/String;)Lcom/adcolony/sdk/b0$a;
      //   52: astore_1
      //   53: new java/lang/StringBuilder
      //   56: dup
      //   57: invokespecial <init> : ()V
      //   60: astore_2
      //   61: aload_2
      //   62: ldc 'Timeout set to: '
      //   64: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
      //   67: pop
      //   68: aload_2
      //   69: aload_0
      //   70: getfield e : Lcom/adcolony/sdk/u1$c;
      //   73: invokevirtual c : ()J
      //   76: invokevirtual append : (J)Ljava/lang/StringBuilder;
      //   79: pop
      //   80: aload_2
      //   81: ldc ' ms. '
      //   83: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
      //   86: pop
      //   87: aload_1
      //   88: aload_2
      //   89: invokevirtual toString : ()Ljava/lang/String;
      //   92: invokevirtual c : (Ljava/lang/String;)Lcom/adcolony/sdk/b0$a;
      //   95: astore_1
      //   96: new java/lang/StringBuilder
      //   99: dup
      //   100: invokespecial <init> : ()V
      //   103: astore_2
      //   104: aload_2
      //   105: ldc 'Execution took: '
      //   107: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
      //   110: pop
      //   111: aload_2
      //   112: invokestatic currentTimeMillis : ()J
      //   115: aload_0
      //   116: getfield e : Lcom/adcolony/sdk/u1$c;
      //   119: invokevirtual d : ()J
      //   122: lsub
      //   123: invokevirtual append : (J)Ljava/lang/StringBuilder;
      //   126: pop
      //   127: aload_2
      //   128: ldc ' ms. '
      //   130: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
      //   133: pop
      //   134: aload_1
      //   135: aload_2
      //   136: invokevirtual toString : ()Ljava/lang/String;
      //   139: invokevirtual c : (Ljava/lang/String;)Lcom/adcolony/sdk/b0$a;
      //   142: ldc 'AdView request not yet started.'
      //   144: invokevirtual c : (Ljava/lang/String;)Lcom/adcolony/sdk/b0$a;
      //   147: getstatic com/adcolony/sdk/b0.i : Lcom/adcolony/sdk/b0;
      //   150: invokevirtual d : (Lcom/adcolony/sdk/b0;)V
      //   153: return
      //   154: astore_1
      //   155: aload_0
      //   156: monitorexit
      //   157: aload_1
      //   158: athrow
      // Exception table:
      //   from	to	target	type
      //   2	11	154	finally
      //   12	19	154	finally
      //   155	157	154	finally
    }
  }
  
  class d implements Runnable {
    d(a this$0, String param1String, e param1e, c param1c, b param1b, u1.c param1c1) {}
    
    public void run() {
      p0 p0 = q.h();
      if (p0.e() || p0.f()) {
        a.e();
        u1.p(this.b);
        return;
      } 
      if (!a.n() && q.j()) {
        u1.p(this.b);
        return;
      } 
      u1.K(this.b);
      if (!this.b.a())
        p0.Z().j(this.c, this.d, this.e, this.f, this.g.e()); 
    }
  }
  
  class e implements Runnable {
    e(a this$0) {}
    
    public void run() {
      a.n();
      e0 e0 = v.q();
      v.m(e0, "options", this.b.d());
      (new j0("Options.set_options", 1, e0)).e();
    }
  }
  
  class f implements u1.b {
    private boolean b;
    
    f(a this$0, String param1String, u1.c param1c) {}
    
    public boolean a() {
      return this.b;
    }
    
    public void run() {
      // Byte code:
      //   0: aload_0
      //   1: monitorenter
      //   2: aload_0
      //   3: getfield b : Z
      //   6: ifeq -> 12
      //   9: aload_0
      //   10: monitorexit
      //   11: return
      //   12: aload_0
      //   13: iconst_1
      //   14: putfield b : Z
      //   17: aload_0
      //   18: monitorexit
      //   19: aload_0
      //   20: getfield c : Lcom/adcolony/sdk/k;
      //   23: aload_0
      //   24: getfield d : Ljava/lang/String;
      //   27: invokestatic h : (Lcom/adcolony/sdk/k;Ljava/lang/String;)V
      //   30: aload_0
      //   31: getfield e : Lcom/adcolony/sdk/u1$c;
      //   34: invokevirtual b : ()Z
      //   37: ifeq -> 153
      //   40: new com/adcolony/sdk/b0$a
      //   43: dup
      //   44: invokespecial <init> : ()V
      //   47: ldc 'RequestNotFilled called due to a native timeout. '
      //   49: invokevirtual c : (Ljava/lang/String;)Lcom/adcolony/sdk/b0$a;
      //   52: astore_1
      //   53: new java/lang/StringBuilder
      //   56: dup
      //   57: invokespecial <init> : ()V
      //   60: astore_2
      //   61: aload_2
      //   62: ldc 'Timeout set to: '
      //   64: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
      //   67: pop
      //   68: aload_2
      //   69: aload_0
      //   70: getfield e : Lcom/adcolony/sdk/u1$c;
      //   73: invokevirtual c : ()J
      //   76: invokevirtual append : (J)Ljava/lang/StringBuilder;
      //   79: pop
      //   80: aload_2
      //   81: ldc ' ms. '
      //   83: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
      //   86: pop
      //   87: aload_1
      //   88: aload_2
      //   89: invokevirtual toString : ()Ljava/lang/String;
      //   92: invokevirtual c : (Ljava/lang/String;)Lcom/adcolony/sdk/b0$a;
      //   95: astore_1
      //   96: new java/lang/StringBuilder
      //   99: dup
      //   100: invokespecial <init> : ()V
      //   103: astore_2
      //   104: aload_2
      //   105: ldc 'Execution took: '
      //   107: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
      //   110: pop
      //   111: aload_2
      //   112: invokestatic currentTimeMillis : ()J
      //   115: aload_0
      //   116: getfield e : Lcom/adcolony/sdk/u1$c;
      //   119: invokevirtual d : ()J
      //   122: lsub
      //   123: invokevirtual append : (J)Ljava/lang/StringBuilder;
      //   126: pop
      //   127: aload_2
      //   128: ldc ' ms. '
      //   130: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
      //   133: pop
      //   134: aload_1
      //   135: aload_2
      //   136: invokevirtual toString : ()Ljava/lang/String;
      //   139: invokevirtual c : (Ljava/lang/String;)Lcom/adcolony/sdk/b0$a;
      //   142: ldc 'Interstitial request not yet started.'
      //   144: invokevirtual c : (Ljava/lang/String;)Lcom/adcolony/sdk/b0$a;
      //   147: getstatic com/adcolony/sdk/b0.i : Lcom/adcolony/sdk/b0;
      //   150: invokevirtual d : (Lcom/adcolony/sdk/b0;)V
      //   153: return
      //   154: astore_1
      //   155: aload_0
      //   156: monitorexit
      //   157: aload_1
      //   158: athrow
      // Exception table:
      //   from	to	target	type
      //   2	11	154	finally
      //   12	19	154	finally
      //   155	157	154	finally
    }
  }
  
  class g implements Runnable {
    g(a this$0, String param1String, k param1k, b param1b, u1.c param1c) {}
    
    public void run() {
      p0 p0 = q.h();
      if (p0.e() || p0.f()) {
        a.e();
        u1.p(this.b);
        return;
      } 
      if (!a.n() && q.j()) {
        u1.p(this.b);
        return;
      } 
      n n2 = p0.c().get(this.c);
      n n1 = n2;
      if (n2 == null)
        n1 = new n(this.c); 
      if (n1.l() != 2 && n1.l() != 1) {
        u1.K(this.b);
        if (!this.b.a()) {
          p0.Z().k(this.c, this.d, this.e, this.f.e());
          return;
        } 
      } else {
        u1.p(this.b);
      } 
    }
  }
  
  class h implements Runnable {
    h(a this$0, String param1String) {}
    
    public void run() {
      this.b.onRequestNotFilled(a.a(this.c));
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Hill race-dex2jar.jar!\com\adcolony\sdk\a.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */