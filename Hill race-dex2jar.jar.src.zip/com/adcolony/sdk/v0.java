package com.adcolony.sdk;

import android.database.Cursor;
import android.database.SQLException;
import android.database.sqlite.SQLiteDatabase;
import android.text.TextUtils;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Objects;

class v0 {
  private final SQLiteDatabase a;
  
  private final w0 b;
  
  v0(SQLiteDatabase paramSQLiteDatabase, w0 paramw0) {
    this.a = paramSQLiteDatabase;
    this.b = paramw0;
  }
  
  private String a(w0.a parama) {
    StringBuilder stringBuilder = new StringBuilder();
    stringBuilder.append("CREATE TABLE ");
    stringBuilder.append(parama.h());
    stringBuilder.append(" (");
    for (int i = 0; i < parama.a().size(); i++) {
      w0.b b = parama.a().get(i);
      stringBuilder.append(b.b());
      stringBuilder.append(" ");
      stringBuilder.append(b.c());
      if (b.a() != null) {
        String str;
        if (b.a() instanceof Boolean) {
          if (((Boolean)b.a()).booleanValue()) {
            str = "1";
          } else {
            str = "0";
          } 
        } else if (str.a() instanceof String) {
          StringBuilder stringBuilder1 = new StringBuilder();
          stringBuilder1.append("'");
          stringBuilder1.append(str.a());
          stringBuilder1.append("'");
          str = stringBuilder1.toString();
        } else {
          str = str.a().toString();
        } 
        stringBuilder.append(" DEFAULT ");
        stringBuilder.append(str);
      } 
      if (i < parama.a().size() - 1)
        stringBuilder.append(", "); 
    } 
    stringBuilder.append(")");
    return stringBuilder.toString();
  }
  
  private String b(w0.c paramc, String paramString) {
    String str = TextUtils.join(", ", (Object[])paramc.a());
    StringBuilder stringBuilder = new StringBuilder();
    stringBuilder.append("CREATE INDEX ");
    stringBuilder.append(paramc.b());
    stringBuilder.append(" ON ");
    stringBuilder.append(paramString);
    stringBuilder.append("(");
    stringBuilder.append(str);
    stringBuilder.append(")");
    return stringBuilder.toString();
  }
  
  private void d(w0.a parama, List<String> paramList) {
    f(parama.h(), "manager_tmp_table");
    m(parama);
    g("manager_tmp_table", parama.h(), paramList);
    j("manager_tmp_table");
  }
  
  private void e(String paramString) {
    SQLiteDatabase sQLiteDatabase = this.a;
    StringBuilder stringBuilder = new StringBuilder();
    stringBuilder.append("DROP INDEX ");
    stringBuilder.append(paramString);
    sQLiteDatabase.execSQL(stringBuilder.toString());
  }
  
  private void f(String paramString1, String paramString2) {
    SQLiteDatabase sQLiteDatabase = this.a;
    StringBuilder stringBuilder = new StringBuilder();
    stringBuilder.append("ALTER TABLE ");
    stringBuilder.append(paramString1);
    stringBuilder.append(" RENAME TO ");
    stringBuilder.append(paramString2);
    sQLiteDatabase.execSQL(stringBuilder.toString());
  }
  
  private void g(String paramString1, String paramString2, List<String> paramList) {
    String str = TextUtils.join(", ", paramList);
    SQLiteDatabase sQLiteDatabase = this.a;
    StringBuilder stringBuilder = new StringBuilder();
    stringBuilder.append("INSERT INTO ");
    stringBuilder.append(paramString2);
    stringBuilder.append(" (");
    stringBuilder.append(str);
    stringBuilder.append(") SELECT ");
    stringBuilder.append(str);
    stringBuilder.append(" FROM ");
    stringBuilder.append(paramString1);
    sQLiteDatabase.execSQL(stringBuilder.toString());
  }
  
  private void h(w0.a parama) {
    Iterator<w0.c> iterator = parama.c().iterator();
    while (iterator.hasNext())
      i(iterator.next(), parama.h()); 
  }
  
  private void i(w0.c paramc, String paramString) {
    String str = b(paramc, paramString);
    this.a.execSQL(str);
  }
  
  private void j(String paramString) {
    SQLiteDatabase sQLiteDatabase = this.a;
    StringBuilder stringBuilder = new StringBuilder();
    stringBuilder.append("DROP TABLE ");
    stringBuilder.append(paramString);
    sQLiteDatabase.execSQL(stringBuilder.toString());
  }
  
  private void m(w0.a parama) {
    String str = a(parama);
    this.a.execSQL(str);
  }
  
  private void n(w0.c paramc, String paramString) {
    ArrayList<String[]> arrayList = l(paramc.b());
    int i = (paramc.a()).length;
    int j = arrayList.size();
    boolean bool = true;
    if (i == j) {
      i = 0;
      bool = false;
      while (i < (paramc.a()).length) {
        if (!Objects.equals(paramc.a()[i], ((String[])arrayList.get(i))[2]))
          bool = true; 
        i++;
      } 
    } 
    if (bool) {
      e(paramc.b());
      i(paramc, paramString);
    } 
  }
  
  private void p(w0.a parama) {
    List<w0.c> list = parama.c();
    ArrayList<String> arrayList = o(parama.h());
    for (w0.c c : list) {
      if (arrayList.contains(c.b())) {
        n(c, parama.h());
      } else {
        i(c, parama.h());
      } 
      arrayList.remove(c.b());
    } 
    Iterator<String> iterator = arrayList.iterator();
    while (iterator.hasNext())
      e(iterator.next()); 
  }
  
  private void r(w0.a parama) {
    ArrayList<a> arrayList = t(parama.h());
    ArrayList<String> arrayList1 = new ArrayList();
    Iterator<w0.b> iterator = parama.a().iterator();
    boolean bool2 = true;
    boolean bool1 = false;
    while (iterator.hasNext()) {
      boolean bool;
      w0.b b = iterator.next();
      int i = arrayList.size() - 1;
      while (true) {
        if (i >= 0) {
          a a1 = arrayList.get(i);
          if (Objects.equals(a1.b(), b.b())) {
            arrayList1.add(b.b());
            boolean bool3 = a1.c(b);
            arrayList.remove(i);
            i = 1;
            break;
          } 
          i--;
          continue;
        } 
        bool = false;
        i = 0;
        break;
      } 
      if (i == 0 || !bool)
        bool1 = true; 
    } 
    if (arrayList.size() > 0)
      bool1 = bool2; 
    if (bool1) {
      d(parama, arrayList1);
      h(parama);
      return;
    } 
    p(parama);
  }
  
  ArrayList<String> c() {
    ArrayList<String> arrayList = s("table");
    for (int i = arrayList.size() - 1; i >= 0; i--) {
      String str = arrayList.get(i);
      if (str.startsWith("android_") || str.startsWith("sqlite_"))
        arrayList.remove(i); 
    } 
    return arrayList;
  }
  
  boolean k() {
    int i = this.a.getVersion();
    this.a.beginTransaction();
    boolean bool2 = false;
    boolean bool1 = bool2;
    try {
      List<w0.a> list = this.b.c();
      bool1 = bool2;
      ArrayList<String> arrayList = c();
      bool1 = bool2;
      Iterator<w0.a> iterator = list.iterator();
      while (true) {
        bool1 = bool2;
        if (iterator.hasNext()) {
          bool1 = bool2;
          w0.a a = iterator.next();
          bool1 = bool2;
          if (arrayList.contains(a.h())) {
            bool1 = bool2;
            r(a);
          } else {
            bool1 = bool2;
            m(a);
            bool1 = bool2;
            h(a);
          } 
          bool1 = bool2;
          arrayList.remove(a.h());
          continue;
        } 
        bool1 = bool2;
        Iterator<String> iterator1 = arrayList.iterator();
        while (true) {
          bool1 = bool2;
          if (iterator1.hasNext()) {
            bool1 = bool2;
            j(iterator1.next());
            continue;
          } 
          bool1 = bool2;
          this.a.setVersion(this.b.d());
          bool1 = bool2;
          this.a.setTransactionSuccessful();
          bool2 = true;
          bool1 = true;
          (new b0.a()).c("Success upgrading database from ").a(i).c(" to ").a(this.b.d()).d(b0.e);
          bool1 = bool2;
          this.a.endTransaction();
          return bool1;
        } 
        break;
      } 
    } catch (SQLException sQLException) {
      (new b0.a()).c("Upgrading database from ").a(i).c(" to ").a(this.b.d()).c("caused: ").c(sQLException.toString()).d(b0.g);
    } finally {
      Exception exception;
    } 
    this.a.endTransaction();
    return bool1;
  }
  
  ArrayList<String[]> l(String paramString) {
    StringBuilder stringBuilder = new StringBuilder();
    stringBuilder.append("PRAGMA index_info(");
    stringBuilder.append(paramString);
    stringBuilder.append(")");
    return q(stringBuilder.toString());
  }
  
  ArrayList<String> o(String paramString) {
    StringBuilder stringBuilder = new StringBuilder();
    stringBuilder.append("PRAGMA index_list(");
    stringBuilder.append(paramString);
    stringBuilder.append(")");
    ArrayList<String[]> arrayList1 = q(stringBuilder.toString());
    ArrayList<String> arrayList = new ArrayList();
    for (String[] arrayOfString : arrayList1) {
      if (arrayOfString.length >= 3)
        arrayList.add(arrayOfString[1]); 
    } 
    return arrayList;
  }
  
  ArrayList<String[]> q(String paramString) {
    Cursor cursor = this.a.rawQuery(paramString, null);
    ArrayList<String[]> arrayList = new ArrayList();
    if (cursor != null && cursor.moveToFirst())
      do {
        int j = cursor.getColumnCount();
        String[] arrayOfString = new String[j];
        for (int i = 0; i < j; i++)
          arrayOfString[i] = cursor.getString(i); 
        arrayList.add(arrayOfString);
      } while (cursor.moveToNext()); 
    cursor.close();
    return arrayList;
  }
  
  ArrayList<String> s(String paramString) {
    SQLiteDatabase sQLiteDatabase = this.a;
    StringBuilder stringBuilder = new StringBuilder();
    stringBuilder.append("SELECT name FROM sqlite_master  WHERE type='");
    stringBuilder.append(paramString);
    stringBuilder.append("' ORDER BY name");
    Cursor cursor = sQLiteDatabase.rawQuery(stringBuilder.toString(), null);
    ArrayList<String> arrayList = new ArrayList();
    if (cursor != null && cursor.moveToFirst())
      do {
        arrayList.add(cursor.getString(0));
      } while (cursor.moveToNext()); 
    cursor.close();
    return arrayList;
  }
  
  ArrayList<a> t(String paramString) {
    ArrayList<a> arrayList = new ArrayList();
    StringBuilder stringBuilder = new StringBuilder();
    stringBuilder.append("PRAGMA table_info(");
    stringBuilder.append(paramString);
    stringBuilder.append(")");
    Iterator<String> iterator = q(stringBuilder.toString()).iterator();
    while (iterator.hasNext()) {
      a a = a.a((String[])iterator.next());
      if (a != null)
        arrayList.add(a); 
    } 
    return arrayList;
  }
  
  static class a {
    private final String a;
    
    private final String b;
    
    private final String c;
    
    private a(String[] param1ArrayOfString) {
      this.a = param1ArrayOfString[1];
      this.b = param1ArrayOfString[2];
      this.c = param1ArrayOfString[4];
    }
    
    static a a(String[] param1ArrayOfString) {
      return (param1ArrayOfString.length >= 5) ? new a(param1ArrayOfString) : null;
    }
    
    String b() {
      return this.a;
    }
    
    boolean c(w0.b param1b) {
      return (Objects.equals(this.a, param1b.b()) && Objects.equals(this.b, param1b.c()) && Objects.equals(this.c, param1b.a()));
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Hill race-dex2jar.jar!\com\adcolony\sdk\v0.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */