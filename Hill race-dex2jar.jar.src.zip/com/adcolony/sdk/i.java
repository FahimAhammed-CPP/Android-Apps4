package com.adcolony.sdk;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Iterator;
import java.util.List;
import org.json.JSONException;

public class i {
  private static final List<e0> a = Collections.synchronizedList(new ArrayList<e0>());
  
  static void a(e0 parame0) {
    synchronized (a) {
      if (200 > null.size())
        null.add(parame0); 
      return;
    } 
  }
  
  static boolean b() {
    synchronized (a) {
      if (null.size() != 0)
        return true; 
    } 
    boolean bool = false;
    /* monitor exit ClassFileLocalVariableReferenceExpression{type=ObjectType{java/lang/Object}, name=SYNTHETIC_LOCAL_VARIABLE_1} */
    return bool;
  }
  
  static void c() {
    p0 p0 = q.h();
    if (!p0.W0().equals("") && p0.i())
      synchronized (a) {
        Iterator<e0> iterator = null.iterator();
        while (iterator.hasNext())
          d(iterator.next()); 
        a.clear();
        return;
      }  
  }
  
  private static void d(e0 parame0) {
    p0 p0 = q.h();
    if (p0.W0().equals("") || !p0.i()) {
      a(parame0);
      return;
    } 
    e(parame0);
    (new j0("AdColony.log_event", 1, parame0)).e();
  }
  
  private static void e(e0 parame0) {
    e0 e01 = v.C(parame0, "payload");
    if (r0.I) {
      v.n(e01, "api_key", "bb2cf0647ba654d7228dd3f9405bbc6a");
    } else {
      v.n(e01, "api_key", q.h().W0());
    } 
    try {
      parame0.M("payload");
      parame0.e("payload", e01);
      return;
    } catch (JSONException jSONException) {
      jSONException.printStackTrace();
      return;
    } 
  }
}


/* Location:              C:\soft\dex2jar-2.0\Hill race-dex2jar.jar!\com\adcolony\sdk\i.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */