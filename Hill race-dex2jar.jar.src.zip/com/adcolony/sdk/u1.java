package com.adcolony.sdk;

import android.app.Activity;
import android.app.Application;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageInfo;
import android.content.pm.PackageManager;
import android.media.AudioManager;
import android.os.Build;
import android.os.Handler;
import android.os.Looper;
import android.os.VibrationEffect;
import android.os.Vibrator;
import android.view.View;
import android.widget.Toast;
import androidx.preference.PreferenceManager;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.math.BigInteger;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;
import java.util.UUID;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.LinkedBlockingQueue;
import java.util.concurrent.RejectedExecutionException;
import java.util.concurrent.ThreadPoolExecutor;
import java.util.concurrent.TimeUnit;
import java.util.zip.CRC32;
import org.json.JSONException;

class u1 {
  private static ExecutorService a = X();
  
  static Handler b;
  
  static String A(Context paramContext, String paramString) {
    return B(H(paramContext), paramString);
  }
  
  static String B(SharedPreferences paramSharedPreferences, String paramString) {
    try {
      return paramSharedPreferences.getString(paramString, null);
    } catch (ClassCastException classCastException) {
      b0.a a = new b0.a();
      StringBuilder stringBuilder = new StringBuilder();
      stringBuilder.append("Key ");
      stringBuilder.append(paramString);
      stringBuilder.append(" in SharedPreferences ");
      a.c(stringBuilder.toString()).c("does not have a String value.").d(b0.g);
      return null;
    } 
  }
  
  static String C(c0 paramc0) throws JSONException {
    String str = "";
    for (int i = 0; i < paramc0.e(); i++) {
      String str1 = str;
      if (i > 0) {
        StringBuilder stringBuilder1 = new StringBuilder();
        stringBuilder1.append(str);
        stringBuilder1.append(",");
        str1 = stringBuilder1.toString();
      } 
      StringBuilder stringBuilder = new StringBuilder();
      stringBuilder.append(str1);
      stringBuilder.append(paramc0.f(i));
      str = stringBuilder.toString();
    } 
    return str;
  }
  
  static String D(String paramString) {
    try {
      return z.a(paramString);
    } catch (Exception exception) {
      return null;
    } 
  }
  
  private static void E(Vibrator paramVibrator, long paramLong) {
    if (Build.VERSION.SDK_INT >= 26) {
      l(paramVibrator, paramLong);
      return;
    } 
    paramVibrator.vibrate(paramLong);
  }
  
  static boolean F(AudioManager paramAudioManager) {
    boolean bool = false;
    if (paramAudioManager == null) {
      (new b0.a()).c("isAudioEnabled() called with a null AudioManager").d(b0.i);
      return false;
    } 
    try {
      int i = paramAudioManager.getStreamVolume(3);
      if (i > 0)
        bool = true; 
      return bool;
    } catch (Exception exception) {
      (new b0.a()).c("Exception occurred when accessing AudioManager.getStreamVolume: ").c(exception.toString()).d(b0.i);
      return false;
    } 
  }
  
  static boolean G(Runnable paramRunnable) {
    if (paramRunnable == null)
      return false; 
    Handler handler = P();
    if (handler != null) {
      if (handler.getLooper() == Looper.myLooper()) {
        paramRunnable.run();
        return true;
      } 
      return handler.post(paramRunnable);
    } 
    return false;
  }
  
  static SharedPreferences H(Context paramContext) {
    try {
      Class.forName("androidx.preference.PreferenceManager");
      return PreferenceManager.getDefaultSharedPreferences(paramContext);
    } catch (ClassNotFoundException classNotFoundException) {
      StringBuilder stringBuilder = new StringBuilder();
      stringBuilder.append(paramContext.getPackageName());
      stringBuilder.append("_preferences");
      return paramContext.getSharedPreferences(stringBuilder.toString(), 0);
    } 
  }
  
  static e0 I(e0 parame0) {
    parame0.j(new String[] { "ads_to_restore" });
    return parame0;
  }
  
  static String J() {
    Context context = q.a();
    if (context == null)
      return "1.0"; 
    try {
      return (context.getPackageManager().getPackageInfo(context.getPackageName(), 0)).versionName;
    } catch (Exception exception) {
      (new b0.a()).c("Failed to retrieve package info.").d(b0.i);
      return "1.0";
    } 
  }
  
  static boolean K(Runnable paramRunnable) {
    if (paramRunnable == null)
      return false; 
    Handler handler = P();
    if (handler != null) {
      handler.removeCallbacks(paramRunnable);
      return true;
    } 
    return false;
  }
  
  static boolean L(String paramString) {
    Context context = q.a();
    if (context == null)
      return false; 
    try {
      Application application;
      if (context instanceof Application) {
        application = (Application)context;
      } else {
        application = ((Activity)application).getApplication();
      } 
      application.getPackageManager().getApplicationInfo(paramString, 0);
      return true;
    } catch (Exception exception) {
      return false;
    } 
  }
  
  @Deprecated
  static int M() {
    Context context = q.a();
    if (context == null)
      return 0; 
    try {
      return (context.getPackageManager().getPackageInfo(context.getPackageName(), 0)).versionCode;
    } catch (Exception exception) {
      (new b0.a()).c("Failed to retrieve package info.").d(b0.i);
      return 0;
    } 
  }
  
  static int N(String paramString) {
    paramString.hashCode();
    return !paramString.equals("portrait") ? (!paramString.equals("landscape") ? -1 : 1) : 0;
  }
  
  static String O(Context paramContext) {
    try {
      return paramContext.getPackageName();
    } catch (Exception exception) {
      return "unknown";
    } 
  }
  
  private static Handler P() {
    Looper looper = Looper.getMainLooper();
    if (looper == null)
      return null; 
    if (b == null)
      b = new Handler(looper); 
    return b;
  }
  
  static c0 Q(Context paramContext) {
    c0 c02 = v.c();
    c0 c01 = c02;
    if (paramContext != null) {
      c0 c0 = c02;
      try {
        PackageInfo packageInfo = paramContext.getPackageManager().getPackageInfo(paramContext.getPackageName(), 4096);
        c01 = c02;
        c0 = c02;
        if (packageInfo.requestedPermissions != null) {
          c0 = c02;
          c0 c03 = v.c();
          int i = 0;
          while (true) {
            c0 = c03;
            String[] arrayOfString = packageInfo.requestedPermissions;
            c01 = c03;
            c0 = c03;
            if (i < arrayOfString.length) {
              c0 = c03;
              c03.g(arrayOfString[i]);
              i++;
              continue;
            } 
            break;
          } 
        } 
        return c01;
      } catch (Exception exception) {
        return c0;
      } 
    } 
    return c01;
  }
  
  static boolean R(String paramString) {
    if (paramString != null && paramString.length() <= 128)
      return true; 
    (new b0.a()).c("String must be non-null and the max length is 128 characters.").d(b0.f);
    return false;
  }
  
  static int S(Context paramContext) {
    if (paramContext == null)
      return 0; 
    int i = paramContext.getResources().getIdentifier("status_bar_height", "dimen", "android");
    return (i > 0) ? paramContext.getResources().getDimensionPixelSize(i) : 0;
  }
  
  static int T(String paramString) {
    try {
      long l = Long.parseLong(paramString, 16);
      return (int)l;
    } catch (NumberFormatException numberFormatException) {
      (new b0.a()).c("Unable to parse '").c(paramString).c("' as a color.").d(b0.g);
      return -16777216;
    } 
  }
  
  static String U() {
    Context context = q.a();
    return (context instanceof Activity && (context.getResources().getConfiguration()).orientation == 1) ? "portrait" : "landscape";
  }
  
  static Date V(String paramString) {
    Locale locale = Locale.US;
    SimpleDateFormat simpleDateFormat3 = new SimpleDateFormat("yyyy-MM-dd'T'HH:mmZ", locale);
    SimpleDateFormat simpleDateFormat2 = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ssZ", locale);
    SimpleDateFormat simpleDateFormat1 = new SimpleDateFormat("yyyy-MM-dd", locale);
    try {
      return simpleDateFormat3.parse(paramString);
    } catch (Exception exception) {
      try {
        return simpleDateFormat2.parse(paramString);
      } catch (Exception exception1) {
        try {
          return simpleDateFormat1.parse(paramString);
        } catch (Exception exception2) {
          return null;
        } 
      } 
    } 
  }
  
  static boolean W() {
    Context context = q.a();
    return (context != null && Build.VERSION.SDK_INT >= 24 && context instanceof Activity && ((Activity)context).isInMultiWindowMode());
  }
  
  static ExecutorService X() {
    return new ThreadPoolExecutor(0, 1, 60L, TimeUnit.SECONDS, new LinkedBlockingQueue<Runnable>());
  }
  
  static double a(AudioManager paramAudioManager) {
    if (paramAudioManager == null) {
      (new b0.a()).c("getAudioVolume() called with a null AudioManager").d(b0.i);
      return 0.0D;
    } 
    try {
      double d1 = paramAudioManager.getStreamVolume(3);
      int i = paramAudioManager.getStreamMaxVolume(3);
      double d2 = i;
      return (d2 == 0.0D) ? 0.0D : (d1 / d2);
    } catch (Exception exception) {
      (new b0.a()).c("Exception occurred when accessing AudioManager: ").c(exception.toString()).d(b0.i);
      return 0.0D;
    } 
  }
  
  static int b(Context paramContext, String paramString) {
    return c(H(paramContext), paramString);
  }
  
  static int c(SharedPreferences paramSharedPreferences, String paramString) {
    try {
      return paramSharedPreferences.getInt(paramString, -1);
    } catch (ClassCastException classCastException) {
      b0.a a = new b0.a();
      StringBuilder stringBuilder = new StringBuilder();
      stringBuilder.append("Key ");
      stringBuilder.append(paramString);
      stringBuilder.append(" in SharedPreferences ");
      a.c(stringBuilder.toString()).c("does not have an int value.").d(b0.g);
      return -1;
    } 
  }
  
  static int d(View paramView) {
    if (paramView == null)
      return 0; 
    int[] arrayOfInt = new int[2];
    arrayOfInt[0] = 0;
    arrayOfInt[1] = 0;
    paramView.getLocationOnScreen(arrayOfInt);
    return (int)(arrayOfInt[0] / q.h().H0().Y());
  }
  
  static int e(String paramString) {
    CRC32 cRC32 = new CRC32();
    int j = paramString.length();
    for (int i = 0; i < j; i++)
      cRC32.update(paramString.charAt(i)); 
    return (int)cRC32.getValue();
  }
  
  static AudioManager f(Context paramContext) {
    if (paramContext == null) {
      (new b0.a()).c("getAudioManager called with a null Context").d(b0.i);
      return null;
    } 
    return (AudioManager)paramContext.getSystemService("audio");
  }
  
  static c0 g(int paramInt) {
    c0 c0 = v.c();
    for (int i = 0; i < paramInt; i++)
      v.j(c0, i()); 
    return c0;
  }
  
  static e0 h(e0 parame0) {
    parame0.j(new String[] { 
          "data_path", "media_path", "temp_storage_path", "device_api", "display_dpi", "mac_address", "memory_class", "memory_used_mb", "model", "arch", 
          "timezone_ietf", "timezone_gmt_m", "timezone_dst_m", "density", "dark_mode", "launch_metadata" });
    return parame0;
  }
  
  static String i() {
    return UUID.randomUUID().toString();
  }
  
  static String j(c0 paramc0) throws JSONException {
    String str = "";
    int i = 0;
    while (i < paramc0.e()) {
      StringBuilder stringBuilder;
      String str1 = str;
      if (i > 0) {
        StringBuilder stringBuilder1 = new StringBuilder();
        stringBuilder1.append(str);
        stringBuilder1.append(",");
        str1 = stringBuilder1.toString();
      } 
      switch (paramc0.f(i)) {
        case 7:
          stringBuilder = new StringBuilder();
          stringBuilder.append(str1);
          stringBuilder.append("SU");
          str1 = stringBuilder.toString();
          break;
        case 6:
          stringBuilder = new StringBuilder();
          stringBuilder.append(str1);
          stringBuilder.append("SA");
          str1 = stringBuilder.toString();
          break;
        case 5:
          stringBuilder = new StringBuilder();
          stringBuilder.append(str1);
          stringBuilder.append("FR");
          str1 = stringBuilder.toString();
          break;
        case 4:
          stringBuilder = new StringBuilder();
          stringBuilder.append(str1);
          stringBuilder.append("TH");
          str1 = stringBuilder.toString();
          break;
        case 3:
          stringBuilder = new StringBuilder();
          stringBuilder.append(str1);
          stringBuilder.append("WE");
          str1 = stringBuilder.toString();
          break;
        case 2:
          stringBuilder = new StringBuilder();
          stringBuilder.append(str1);
          stringBuilder.append("TU");
          str1 = stringBuilder.toString();
          break;
        case 1:
          stringBuilder = new StringBuilder();
          stringBuilder.append(str1);
          stringBuilder.append("MO");
          str1 = stringBuilder.toString();
          break;
      } 
      i++;
      str = str1;
    } 
    return str;
  }
  
  static String k(m1 paramm1) {
    e0 e0 = paramm1.m();
    String str2 = v.E(e0, "adc_alt_id");
    String str1 = str2;
    if (str2.isEmpty()) {
      str1 = i();
      v.n(e0, "adc_alt_id", str1);
      paramm1.d(e0);
    } 
    return str1;
  }
  
  private static void l(Vibrator paramVibrator, long paramLong) {
    paramVibrator.vibrate(VibrationEffect.createOneShot(paramLong, -1));
  }
  
  static boolean m(Context paramContext, long paramLong) {
    try {
      Vibrator vibrator = (Vibrator)paramContext.getSystemService("vibrator");
      if (vibrator != null && vibrator.hasVibrator()) {
        E(vibrator, paramLong);
        return true;
      } 
    } catch (Exception exception) {
      (new b0.a()).c("Vibrate command failed.").d(b0.f);
    } 
    return false;
  }
  
  static boolean n(Intent paramIntent) {
    return o(paramIntent, false);
  }
  
  static boolean o(Intent paramIntent, boolean paramBoolean) {
    try {
      Context context = q.a();
      if (context == null)
        return false; 
      if (!(context instanceof Activity))
        paramIntent.addFlags(268435456); 
      j j = q.h().z0();
      if (j != null && j.D())
        j.v().q(); 
      if (paramBoolean) {
        context.startActivity(Intent.createChooser(paramIntent, "Handle this via..."));
      } else {
        context.startActivity(paramIntent);
      } 
      return true;
    } catch (Exception exception) {
      (new b0.a()).c(exception.toString()).d(b0.g);
      return false;
    } 
  }
  
  static boolean p(b paramb) {
    if (paramb == null)
      return false; 
    Handler handler = P();
    if (handler != null) {
      handler.removeCallbacks(paramb);
      if (!paramb.a())
        if (handler.getLooper() == Looper.myLooper()) {
          paramb.run();
        } else {
          handler.post(paramb);
        }  
      return true;
    } 
    return false;
  }
  
  static boolean q(Runnable paramRunnable) {
    return u(a, paramRunnable);
  }
  
  static boolean r(Runnable paramRunnable, long paramLong) {
    if (paramRunnable == null)
      return false; 
    if (paramLong <= 0L)
      return G(paramRunnable); 
    Handler handler = P();
    return (handler != null) ? handler.postDelayed(paramRunnable, paramLong) : false;
  }
  
  static boolean s(String paramString, int paramInt) {
    Context context = q.a();
    if (context != null) {
      G(new a(context, paramString, paramInt));
      return true;
    } 
    return false;
  }
  
  static boolean t(String paramString, File paramFile) {
    try {
      MessageDigest messageDigest = MessageDigest.getInstance("SHA1");
      try {
        FileInputStream fileInputStream = new FileInputStream(paramFile);
        byte[] arrayOfByte = new byte[8192];
        try {
          while (true) {
            int i = fileInputStream.read(arrayOfByte);
            if (i > 0) {
              messageDigest.update(arrayOfByte, 0, i);
              continue;
            } 
            boolean bool = paramString.equals(String.format("%40s", new Object[] { (new BigInteger(1, messageDigest.digest())).toString(16) }).replace(' ', '0'));
            try {
              fileInputStream.close();
              return bool;
            } catch (IOException iOException) {
              (new b0.a()).c("Exception on closing MD5 input stream").d(b0.i);
              return bool;
            } 
          } 
        } catch (IOException iOException) {
          throw new RuntimeException("Unable to process file for MD5", iOException);
        } finally {}
      } catch (FileNotFoundException fileNotFoundException) {}
      (new b0.a()).c("Exception while getting FileInputStream").d(b0.i);
      return false;
    } catch (NoSuchAlgorithmException noSuchAlgorithmException) {
      (new b0.a()).c("Exception while getting Digest").d(b0.i);
      return false;
    } 
  }
  
  static boolean u(ExecutorService paramExecutorService, Runnable paramRunnable) {
    try {
      paramExecutorService.execute(paramRunnable);
      return true;
    } catch (RejectedExecutionException rejectedExecutionException) {
      return false;
    } 
  }
  
  static int v(Context paramContext) {
    int i;
    if (paramContext == null)
      return 0; 
    if ((paramContext.getResources().getConfiguration()).orientation == 1) {
      i = paramContext.getResources().getIdentifier("navigation_bar_height", "dimen", "android");
    } else {
      i = paramContext.getResources().getIdentifier("navigation_bar_height_landscape", "dimen", "android");
    } 
    return (i > 0) ? paramContext.getResources().getDimensionPixelSize(i) : 0;
  }
  
  static int w(View paramView) {
    if (paramView == null)
      return 0; 
    int[] arrayOfInt = new int[2];
    arrayOfInt[0] = 0;
    arrayOfInt[1] = 0;
    paramView.getLocationOnScreen(arrayOfInt);
    return (int)(arrayOfInt[1] / q.h().H0().Y());
  }
  
  static int x(m1 paramm1) {
    boolean bool = false;
    try {
      Context context = q.a();
      if (context != null) {
        int i = (int)((context.getPackageManager().getPackageInfo(context.getPackageName(), 0)).lastUpdateTime / 1000L);
        e0 e0 = paramm1.m();
        boolean bool1 = e0.k("last_update");
        byte b = 1;
        if (bool1) {
          int j = v.A(e0, "last_update");
          if (j != i) {
            bool = true;
          } else {
            b = 0;
          } 
        } else {
          bool = true;
          b = 2;
        } 
        if (bool)
          try {
            v.u(e0, "last_update", i);
            paramm1.d(e0);
            return b;
          } catch (Exception exception) {
            return b;
          }  
        return b;
      } 
      return 0;
    } catch (Exception exception) {
      return 0;
    } 
  }
  
  static e0 y(e0 parame0) {
    parame0.M("launch_metadata");
    return parame0;
  }
  
  static String z() {
    Application application;
    Context context = q.a();
    if (context == null)
      return ""; 
    if (context instanceof Application) {
      application = (Application)context;
    } else {
      application = ((Activity)context).getApplication();
    } 
    PackageManager packageManager = application.getPackageManager();
    try {
      CharSequence charSequence = packageManager.getApplicationLabel(packageManager.getApplicationInfo(context.getPackageName(), 0));
      return charSequence.toString();
    } catch (Exception exception) {
      (new b0.a()).c("Failed to retrieve application label.").d(b0.i);
      return "";
    } 
  }
  
  class a implements Runnable {
    a(u1 this$0, String param1String, int param1Int) {}
    
    public void run() {
      Toast.makeText(this.b, this.c, this.d).show();
    }
  }
  
  static interface b extends Runnable {
    boolean a();
  }
  
  static class c {
    private long a;
    
    private long b = System.currentTimeMillis();
    
    c(long param1Long) {
      a(param1Long);
    }
    
    void a(long param1Long) {
      this.a = param1Long;
      this.b = System.currentTimeMillis() + this.a;
    }
    
    boolean b() {
      return (e() == 0L);
    }
    
    long c() {
      return this.a;
    }
    
    long d() {
      return this.b - this.a;
    }
    
    long e() {
      long l = this.b - System.currentTimeMillis();
      return (l <= 0L) ? 0L : l;
    }
    
    public String toString() {
      return String.valueOf(e() / 1000.0D);
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Hill race-dex2jar.jar!\com\adcolony\sd\\u1.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */