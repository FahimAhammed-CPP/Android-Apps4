package com.adcolony.sdk;

import android.annotation.SuppressLint;
import android.content.Context;
import android.net.Uri;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.widget.FrameLayout;
import android.widget.ImageView;
import java.io.File;

@SuppressLint({"AppCompatCustomView"})
class o extends ImageView {
  private int b;
  
  private int c;
  
  private int d;
  
  private int e;
  
  private int f;
  
  private boolean g;
  
  private boolean h;
  
  private boolean i;
  
  private String j;
  
  private String k;
  
  private j0 l;
  
  private u m;
  
  o(Context paramContext, j0 paramj0, int paramInt, u paramu) {
    super(paramContext);
    this.b = paramInt;
    this.l = paramj0;
    this.m = paramu;
  }
  
  private boolean c(j0 paramj0) {
    e0 e0 = paramj0.a();
    return (v.A(e0, "id") == this.b && v.A(e0, "container_id") == this.m.q() && v.E(e0, "ad_session_id").equals(this.m.b()));
  }
  
  private void e(j0 paramj0) {
    e0 e0 = paramj0.a();
    this.c = v.A(e0, "x");
    this.d = v.A(e0, "y");
    this.e = v.A(e0, "width");
    this.f = v.A(e0, "height");
    if (this.g) {
      float f = q.h().H0().Y();
      f = this.f * f / getDrawable().getIntrinsicHeight();
      this.f = (int)(getDrawable().getIntrinsicHeight() * f);
      int i = (int)(getDrawable().getIntrinsicWidth() * f);
      this.e = i;
      this.c -= i;
      this.d -= this.f;
    } 
    FrameLayout.LayoutParams layoutParams = (FrameLayout.LayoutParams)getLayoutParams();
    layoutParams.setMargins(this.c, this.d, 0, 0);
    layoutParams.width = this.e;
    layoutParams.height = this.f;
    setLayoutParams((ViewGroup.LayoutParams)layoutParams);
  }
  
  private void g(j0 paramj0) {
    this.j = v.E(paramj0.a(), "filepath");
    setImageURI(Uri.fromFile(new File(this.j)));
  }
  
  private void i(j0 paramj0) {
    if (v.t(paramj0.a(), "visible")) {
      setVisibility(0);
      return;
    } 
    setVisibility(4);
  }
  
  void a() {
    FrameLayout.LayoutParams layoutParams;
    e0 e0 = this.l.a();
    this.k = v.E(e0, "ad_session_id");
    this.c = v.A(e0, "x");
    this.d = v.A(e0, "y");
    this.e = v.A(e0, "width");
    this.f = v.A(e0, "height");
    this.j = v.E(e0, "filepath");
    this.g = v.t(e0, "dpi");
    this.h = v.t(e0, "invert_y");
    this.i = v.t(e0, "wrap_content");
    setImageURI(Uri.fromFile(new File(this.j)));
    if (this.g) {
      float f = q.h().H0().Y();
      f = this.f * f / getDrawable().getIntrinsicHeight();
      this.f = (int)(getDrawable().getIntrinsicHeight() * f);
      int i = (int)(getDrawable().getIntrinsicWidth() * f);
      this.e = i;
      this.c -= i;
      if (this.h) {
        i = this.d + this.f;
      } else {
        i = this.d - this.f;
      } 
      this.d = i;
    } 
    setVisibility(4);
    if (this.i) {
      layoutParams = new FrameLayout.LayoutParams(-2, -2);
    } else {
      layoutParams = new FrameLayout.LayoutParams(this.e, this.f);
    } 
    layoutParams.setMargins(this.c, this.d, 0, 0);
    layoutParams.gravity = 0;
    this.m.addView((View)this, (ViewGroup.LayoutParams)layoutParams);
    this.m.F().add(q.b("ImageView.set_visible", new a(this), true));
    this.m.F().add(q.b("ImageView.set_bounds", new b(this), true));
    this.m.F().add(q.b("ImageView.set_image", new c(this), true));
    this.m.H().add("ImageView.set_visible");
    this.m.H().add("ImageView.set_bounds");
    this.m.H().add("ImageView.set_image");
  }
  
  @SuppressLint({"ClickableViewAccessibility"})
  public boolean onTouchEvent(MotionEvent paramMotionEvent) {
    p0 p0 = q.h();
    x x = p0.Z();
    int i = paramMotionEvent.getAction() & 0xFF;
    if (i != 0 && i != 1 && i != 3 && i != 2 && i != 5 && i != 6)
      return false; 
    int j = (int)paramMotionEvent.getX();
    int k = (int)paramMotionEvent.getY();
    e0 e0 = v.q();
    v.u(e0, "view_id", this.b);
    v.n(e0, "ad_session_id", this.k);
    v.u(e0, "container_x", this.c + j);
    v.u(e0, "container_y", this.d + k);
    v.u(e0, "view_x", j);
    v.u(e0, "view_y", k);
    v.u(e0, "id", this.m.getId());
    if (i != 0) {
      if (i != 1) {
        if (i != 2) {
          if (i != 3) {
            if (i != 5) {
              if (i == 6) {
                i = (paramMotionEvent.getAction() & 0xFF00) >> 8;
                j = (int)paramMotionEvent.getX(i);
                k = (int)paramMotionEvent.getY(i);
                v.u(e0, "container_x", (int)paramMotionEvent.getX(i) + this.c);
                v.u(e0, "container_y", (int)paramMotionEvent.getY(i) + this.d);
                v.u(e0, "view_x", (int)paramMotionEvent.getX(i));
                v.u(e0, "view_y", (int)paramMotionEvent.getY(i));
                if (!this.m.O())
                  p0.y(x.w().get(this.k)); 
                if (j > 0 && j < this.e && k > 0 && k < this.f) {
                  (new j0("AdContainer.on_touch_ended", this.m.J(), e0)).e();
                } else {
                  (new j0("AdContainer.on_touch_cancelled", this.m.J(), e0)).e();
                } 
              } 
            } else {
              i = (paramMotionEvent.getAction() & 0xFF00) >> 8;
              v.u(e0, "container_x", (int)paramMotionEvent.getX(i) + this.c);
              v.u(e0, "container_y", (int)paramMotionEvent.getY(i) + this.d);
              v.u(e0, "view_x", (int)paramMotionEvent.getX(i));
              v.u(e0, "view_y", (int)paramMotionEvent.getY(i));
              (new j0("AdContainer.on_touch_began", this.m.J(), e0)).e();
            } 
          } else {
            (new j0("AdContainer.on_touch_cancelled", this.m.J(), e0)).e();
          } 
        } else {
          (new j0("AdContainer.on_touch_moved", this.m.J(), e0)).e();
        } 
      } else {
        if (!this.m.O())
          p0.y(x.w().get(this.k)); 
        if (j > 0 && j < this.e && k > 0 && k < this.f) {
          (new j0("AdContainer.on_touch_ended", this.m.J(), e0)).e();
        } else {
          (new j0("AdContainer.on_touch_cancelled", this.m.J(), e0)).e();
        } 
      } 
    } else {
      (new j0("AdContainer.on_touch_began", this.m.J(), e0)).e();
    } 
    return true;
  }
  
  class a implements o0 {
    a(o this$0) {}
    
    public void a(j0 param1j0) {
      if (o.b(this.a, param1j0))
        o.d(this.a, param1j0); 
    }
  }
  
  class b implements o0 {
    b(o this$0) {}
    
    public void a(j0 param1j0) {
      if (o.b(this.a, param1j0))
        o.f(this.a, param1j0); 
    }
  }
  
  class c implements o0 {
    c(o this$0) {}
    
    public void a(j0 param1j0) {
      if (o.b(this.a, param1j0))
        o.h(this.a, param1j0); 
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Hill race-dex2jar.jar!\com\adcolony\sdk\o.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */