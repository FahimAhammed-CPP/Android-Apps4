package com.adcolony.sdk;

import android.content.Context;
import android.graphics.Rect;
import android.net.Uri;
import android.view.View;
import android.view.ViewGroup;
import android.widget.FrameLayout;
import android.widget.ImageView;
import com.iab.omid.library.adcolony.adsession.FriendlyObstructionPurpose;
import java.io.File;

public class d extends FrameLayout {
  private u b;
  
  private e c;
  
  private c d;
  
  private String e;
  
  private String f;
  
  private String g;
  
  private String h;
  
  private ImageView i;
  
  private z0 j;
  
  private j0 k;
  
  private boolean l;
  
  private boolean m;
  
  private boolean n;
  
  private boolean o;
  
  private boolean p;
  
  private boolean q = true;
  
  private int r;
  
  private int s;
  
  private int t;
  
  private int u;
  
  private int v;
  
  private c w;
  
  d(Context paramContext, j0 paramj0, e parame) throws RuntimeException {
    super(paramContext);
    this.c = parame;
    this.f = parame.c();
    e0 e0 = paramj0.a();
    this.e = v.E(e0, "id");
    this.g = v.E(e0, "close_button_filepath");
    this.l = v.t(e0, "trusted_demand_source");
    this.p = v.t(e0, "close_button_snap_to_webview");
    this.u = v.A(e0, "close_button_width");
    this.v = v.A(e0, "close_button_height");
    u u1 = q.h().Z().s().get(this.e);
    this.b = u1;
    if (u1 != null) {
      this.d = parame.a();
      setLayoutParams((ViewGroup.LayoutParams)new FrameLayout.LayoutParams(this.b.t(), this.b.l()));
      setBackgroundColor(0);
      addView((View)this.b);
      return;
    } 
    throw new RuntimeException("AdColonyAdView container cannot be null");
  }
  
  void b() {
    if (!this.l && !this.o)
      return; 
    float f = q.h().H0().Y();
    FrameLayout.LayoutParams layoutParams = new FrameLayout.LayoutParams((int)(this.d.b() * f), (int)(this.d.a() * f));
    this.b.setLayoutParams((ViewGroup.LayoutParams)layoutParams);
    t t = getWebView();
    if (t != null) {
      j0 j01 = new j0("WebView.set_bounds", 0);
      e0 e02 = v.q();
      v.u(e02, "x", t.getInitialX());
      v.u(e02, "y", t.getInitialY());
      v.u(e02, "width", t.getInitialWidth());
      v.u(e02, "height", t.getInitialHeight());
      j01.d(e02);
      t.h(j01);
      e0 e01 = v.q();
      v.n(e01, "ad_session_id", this.e);
      (new j0("MRAID.on_close", this.b.J(), e01)).e();
    } 
    ImageView imageView = this.i;
    if (imageView != null) {
      this.b.removeView((View)imageView);
      this.b.f((View)this.i);
    } 
    addView((View)this.b);
    e e1 = this.c;
    if (e1 != null)
      e1.onClosed(this); 
  }
  
  boolean d() {
    if (!this.l && !this.o) {
      if (this.k != null) {
        e0 e0 = v.q();
        v.w(e0, "success", false);
        this.k.b(e0).e();
        this.k = null;
      } 
      return false;
    } 
    b1 b1 = q.h().H0();
    Rect rect = b1.c0();
    int i = this.s;
    if (i <= 0)
      i = rect.width(); 
    int j = this.t;
    if (j <= 0)
      j = rect.height(); 
    int k = (rect.width() - i) / 2;
    int m = (rect.height() - j) / 2;
    FrameLayout.LayoutParams layoutParams = new FrameLayout.LayoutParams(rect.width(), rect.height());
    this.b.setLayoutParams((ViewGroup.LayoutParams)layoutParams);
    t t = getWebView();
    if (t != null) {
      j0 j01 = new j0("WebView.set_bounds", 0);
      e0 e02 = v.q();
      v.u(e02, "x", k);
      v.u(e02, "y", m);
      v.u(e02, "width", i);
      v.u(e02, "height", j);
      j01.d(e02);
      t.h(j01);
      float f = b1.Y();
      e0 e01 = v.q();
      v.u(e01, "app_orientation", u1.N(u1.U()));
      v.u(e01, "width", (int)(i / f));
      v.u(e01, "height", (int)(j / f));
      v.u(e01, "x", u1.d((View)t));
      v.u(e01, "y", u1.w((View)t));
      v.n(e01, "ad_session_id", this.e);
      (new j0("MRAID.on_size_change", this.b.J(), e01)).e();
    } 
    ImageView imageView = this.i;
    if (imageView != null)
      this.b.removeView((View)imageView); 
    Context context = q.a();
    if (context != null && !this.n && t != null) {
      float f = q.h().H0().Y();
      k = (int)(this.u * f);
      m = (int)(this.v * f);
      if (this.p) {
        i = t.getCurrentX() + t.getCurrentWidth();
      } else {
        i = rect.width();
      } 
      if (this.p) {
        j = t.getCurrentY();
      } else {
        j = 0;
      } 
      ImageView imageView1 = new ImageView(context.getApplicationContext());
      this.i = imageView1;
      imageView1.setImageURI(Uri.fromFile(new File(this.g)));
      FrameLayout.LayoutParams layoutParams1 = new FrameLayout.LayoutParams(k, m);
      layoutParams1.setMargins(i - k, j, 0, 0);
      this.i.setOnClickListener(new b(this, context));
      this.b.addView((View)this.i, (ViewGroup.LayoutParams)layoutParams1);
      this.b.g((View)this.i, FriendlyObstructionPurpose.CLOSE_AD);
    } 
    if (this.k != null) {
      e0 e0 = v.q();
      v.w(e0, "success", true);
      this.k.b(e0).e();
      this.k = null;
    } 
    return true;
  }
  
  boolean f() {
    return this.o;
  }
  
  boolean g() {
    return this.m;
  }
  
  public c getAdSize() {
    return this.d;
  }
  
  String getClickOverride() {
    return this.h;
  }
  
  u getContainer() {
    return this.b;
  }
  
  public e getListener() {
    return this.c;
  }
  
  z0 getOmidManager() {
    return this.j;
  }
  
  int getOrientation() {
    return this.r;
  }
  
  boolean getTrustedDemandSource() {
    return this.l;
  }
  
  t getWebView() {
    u u1 = this.b;
    return (u1 == null) ? null : u1.M().get(Integer.valueOf(2));
  }
  
  public String getZoneId() {
    return this.f;
  }
  
  public boolean h() {
    if (this.m) {
      (new b0.a()).c("Ignoring duplicate call to destroy().").d(b0.f);
      return false;
    } 
    this.m = true;
    z0 z01 = this.j;
    if (z01 != null && z01.m() != null)
      this.j.j(); 
    u1.G(new a(this));
    return true;
  }
  
  void i() {
    t t = getWebView();
    if (this.j != null && t != null)
      t.r(); 
  }
  
  protected void onAttachedToWindow() {
    super.onAttachedToWindow();
    if (this.q && !this.m) {
      this.q = false;
      e e1 = this.c;
      if (e1 != null)
        e1.onShow(this); 
    } 
  }
  
  void setClickOverride(String paramString) {
    this.h = paramString;
  }
  
  void setExpandMessage(j0 paramj0) {
    this.k = paramj0;
  }
  
  void setExpandedHeight(int paramInt) {
    this.t = (int)(paramInt * q.h().H0().Y());
  }
  
  void setExpandedWidth(int paramInt) {
    this.s = (int)(paramInt * q.h().H0().Y());
  }
  
  public void setListener(e parame) {
    this.c = parame;
  }
  
  void setNoCloseButton(boolean paramBoolean) {
    if (this.l && paramBoolean) {
      paramBoolean = true;
    } else {
      paramBoolean = false;
    } 
    this.n = paramBoolean;
  }
  
  void setOmidManager(z0 paramz0) {
    this.j = paramz0;
  }
  
  void setOnDestroyListenerOrCall(c paramc) {
    if (this.m) {
      paramc.a();
      return;
    } 
    this.w = paramc;
  }
  
  void setOrientation(int paramInt) {
    this.r = paramInt;
  }
  
  void setUserInteraction(boolean paramBoolean) {
    this.o = paramBoolean;
  }
  
  class a implements Runnable {
    a(d this$0) {}
    
    public void run() {
      Context context = q.a();
      if (context instanceof AdColonyAdViewActivity)
        ((AdColonyAdViewActivity)context).f(); 
      x x = q.h().Z();
      x.a(d.a(this.b));
      x.h(d.c(this.b));
      e0 e0 = v.q();
      v.n(e0, "id", d.a(this.b));
      (new j0("AdSession.on_ad_view_destroyed", 1, e0)).e();
      if (d.e(this.b) != null)
        d.e(this.b).a(); 
    }
  }
  
  class b implements View.OnClickListener {
    b(d this$0, Context param1Context) {}
    
    public void onClick(View param1View) {
      Context context = this.b;
      if (context instanceof AdColonyAdViewActivity)
        ((AdColonyAdViewActivity)context).f(); 
    }
  }
  
  static interface c {
    void a();
  }
}


/* Location:              C:\soft\dex2jar-2.0\Hill race-dex2jar.jar!\com\adcolony\sdk\d.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */