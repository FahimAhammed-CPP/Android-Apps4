package com.adcolony.sdk;

import android.annotation.SuppressLint;
import android.content.Context;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import java.util.concurrent.Executors;
import java.util.concurrent.RejectedExecutionException;
import java.util.concurrent.ScheduledExecutorService;
import java.util.concurrent.ScheduledFuture;
import java.util.concurrent.TimeUnit;

class u0 {
  private ScheduledExecutorService a;
  
  private ScheduledFuture<?> b;
  
  private String c;
  
  @SuppressLint({"MissingPermission"})
  private String a() {
    Context context = q.a();
    if (context == null)
      return "none"; 
    try {
      ConnectivityManager connectivityManager = (ConnectivityManager)context.getApplicationContext().getSystemService("connectivity");
      if (connectivityManager == null) {
        connectivityManager = null;
      } else {
        NetworkInfo networkInfo = connectivityManager.getActiveNetworkInfo();
      } 
    } catch (SecurityException null) {
      (new b0.a()).c("SecurityException - please ensure you added the ").c("ACCESS_NETWORK_STATE permission: ").c(exception.toString()).d(b0.h);
      return "none";
    } catch (Exception exception) {
      (new b0.a()).c("Exception occurred when retrieving activeNetworkInfo in ").c("ADCNetwork.getConnectivityStatus(): ").c(exception.toString()).d(b0.i);
      return "none";
    } 
    if (exception == null)
      return "none"; 
    int i = exception.getType();
    return (i == 1) ? "wifi" : ((i == 0 || i >= 2) ? "cell" : "none");
  }
  
  private void e() {
    if (this.a == null)
      this.a = Executors.newSingleThreadScheduledExecutor(); 
    if (this.b == null) {
      try {
        this.b = this.a.scheduleAtFixedRate(new c(this), 0L, 1000L, TimeUnit.MILLISECONDS);
      } catch (RejectedExecutionException rejectedExecutionException) {
        (new b0.a()).c("Error when scheduling network checks: ").c(rejectedExecutionException.toString()).d(b0.i);
      } 
      g();
    } 
  }
  
  private void g() {
    String str = h();
    if (!str.equals(this.c)) {
      this.c = str;
      e0 e0 = v.q();
      v.n(e0, "network_type", str);
      (new j0("Network.on_status_change", 1, e0)).e();
    } 
  }
  
  private void i() {
    ScheduledFuture<?> scheduledFuture = this.b;
    if (scheduledFuture != null) {
      if (!scheduledFuture.isCancelled())
        this.b.cancel(false); 
      this.b = null;
    } 
  }
  
  void c() {
    this.c = h();
    q.g("Network.start_notifications", new a(this));
    q.g("Network.stop_notifications", new b(this));
  }
  
  String h() {
    return a();
  }
  
  class a implements o0 {
    a(u0 this$0) {}
    
    public void a(j0 param1j0) {
      u0.b(this.a);
    }
  }
  
  class b implements o0 {
    b(u0 this$0) {}
    
    public void a(j0 param1j0) {
      u0.d(this.a);
    }
  }
  
  class c implements Runnable {
    c(u0 this$0) {}
    
    public void run() {
      u0.f(this.b);
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Hill race-dex2jar.jar!\com\adcolony\sd\\u0.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */