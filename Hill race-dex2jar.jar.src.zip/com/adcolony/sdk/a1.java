package com.adcolony.sdk;

import android.content.ContentValues;
import android.database.Cursor;
import android.database.SQLException;
import android.database.sqlite.SQLiteDatabase;

class a1 {
  static void a(int paramInt, long paramLong, String paramString1, String paramString2, SQLiteDatabase paramSQLiteDatabase) {
    try {
      paramSQLiteDatabase.beginTransaction();
      String str = paramString1;
      if (paramString1 == null) {
        str = "rowid";
        paramLong = -1L;
      } 
      long l = paramLong;
      if (paramInt >= 0) {
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("select ");
        stringBuilder.append(str);
        stringBuilder.append(" from ");
        stringBuilder.append(paramString2);
        stringBuilder.append(" order by ");
        stringBuilder.append(str);
        stringBuilder.append(" desc limit 1 offset ");
        stringBuilder.append(paramInt);
        Cursor cursor = paramSQLiteDatabase.rawQuery(stringBuilder.toString(), null);
        l = paramLong;
        if (cursor.moveToFirst())
          l = Math.max(paramLong, cursor.getLong(0)); 
        cursor.close();
      } 
      if (l >= 0L) {
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("delete from ");
        stringBuilder.append(paramString2);
        stringBuilder.append(" where ");
        stringBuilder.append(str);
        stringBuilder.append(" <= ");
        stringBuilder.append(l);
        paramSQLiteDatabase.execSQL(stringBuilder.toString());
      } 
      paramSQLiteDatabase.setTransactionSuccessful();
    } catch (SQLException sQLException) {
      (new b0.a()).c("Exception on deleting excessive rows:").c(sQLException.toString()).d(b0.g);
    } finally {}
    try {
      return;
    } finally {
      paramString1 = null;
      (new b0.a()).c("Error on deleting excessive rows:").c(paramString1.toString()).d(b0.i);
    } 
  }
  
  static void b(String paramString, ContentValues paramContentValues, SQLiteDatabase paramSQLiteDatabase) {
    try {
      paramSQLiteDatabase.beginTransaction();
      paramSQLiteDatabase.insertOrThrow(paramString, null, paramContentValues);
      paramSQLiteDatabase.setTransactionSuccessful();
    } catch (SQLException sQLException) {
      b0.a a = new b0.a();
      StringBuilder stringBuilder = new StringBuilder();
      stringBuilder.append("Exception on insert to ");
      stringBuilder.append(paramString);
      stringBuilder.append(", db version:");
      a = a.c(stringBuilder.toString()).a(paramSQLiteDatabase.getVersion());
      stringBuilder = new StringBuilder();
      stringBuilder.append(". Values: ");
      stringBuilder.append(paramContentValues.toString());
      stringBuilder.append(" caused: ");
      a.c(stringBuilder.toString()).c(sQLException.toString()).d(b0.g);
    } finally {
      Exception exception;
    } 
    try {
      return;
    } finally {
      Exception exception = null;
      b0.a a3 = new b0.a();
      StringBuilder stringBuilder2 = new StringBuilder();
      stringBuilder2.append("Error on insert to ");
      stringBuilder2.append(paramString);
      stringBuilder2.append(", db version:");
      b0.a a2 = a3.c(stringBuilder2.toString()).a(paramSQLiteDatabase.getVersion());
      StringBuilder stringBuilder1 = new StringBuilder();
      stringBuilder1.append(". Values: ");
      stringBuilder1.append(paramContentValues.toString());
      stringBuilder1.append(" caused: ");
      a2.c(stringBuilder1.toString()).c(exception.toString()).d(b0.i);
    } 
  }
}


/* Location:              C:\soft\dex2jar-2.0\Hill race-dex2jar.jar!\com\adcolony\sdk\a1.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */