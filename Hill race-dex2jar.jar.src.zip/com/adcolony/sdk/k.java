package com.adcolony.sdk;

public abstract class k {
  @Deprecated
  public void onAudioStarted(j paramj) {}
  
  @Deprecated
  public void onAudioStopped(j paramj) {}
  
  public void onClicked(j paramj) {}
  
  public void onClosed(j paramj) {}
  
  public void onExpiring(j paramj) {}
  
  public void onIAPEvent(j paramj, String paramString, int paramInt) {}
  
  public void onLeftApplication(j paramj) {}
  
  public void onOpened(j paramj) {}
  
  public abstract void onRequestFilled(j paramj);
  
  public void onRequestNotFilled(n paramn) {}
}


/* Location:              C:\soft\dex2jar-2.0\Hill race-dex2jar.jar!\com\adcolony\sdk\k.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */