package com.adcolony.sdk;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.io.RandomAccessFile;
import java.util.LinkedList;
import java.util.zip.GZIPInputStream;
import org.json.JSONException;

class n1 {
  private LinkedList<Runnable> a = new LinkedList<Runnable>();
  
  private boolean b;
  
  private void b() {
    this.b = false;
    if (!this.a.isEmpty()) {
      this.b = true;
      ((Runnable)this.a.removeLast()).run();
    } 
  }
  
  private void e(Runnable paramRunnable) {
    if (this.a.isEmpty() && !this.b) {
      this.b = true;
      paramRunnable.run();
      return;
    } 
    this.a.push(paramRunnable);
  }
  
  private boolean g(j0 paramj0) {
    String str = v.E(paramj0.a(), "filepath");
    q.h().Z0().n();
    e0 e0 = v.q();
    try {
      if ((new File(str)).mkdir()) {
        v.w(e0, "success", true);
        paramj0.b(e0).e();
        return true;
      } 
      v.w(e0, "success", false);
      return false;
    } catch (Exception exception) {
      v.w(e0, "success", false);
      paramj0.b(e0).e();
      return false;
    } 
  }
  
  private boolean h(j0 paramj0, File paramFile) {
    q.h().Z0().n();
    e0 e0 = v.q();
    if (k(paramFile)) {
      v.w(e0, "success", true);
      paramj0.b(e0).e();
      return true;
    } 
    v.w(e0, "success", false);
    paramj0.b(e0).e();
    return false;
  }
  
  private boolean l(String paramString) {
    return (new File(paramString)).exists();
  }
  
  private boolean n(j0 paramj0) {
    String str = v.E(paramj0.a(), "filepath");
    q.h().Z0().n();
    e0 e0 = v.q();
    try {
      boolean bool = l(str);
      v.w(e0, "result", bool);
      v.w(e0, "success", true);
      paramj0.b(e0).e();
      return bool;
    } catch (Exception exception) {
      v.w(e0, "result", false);
      v.w(e0, "success", false);
      paramj0.b(e0).e();
      exception.printStackTrace();
      return false;
    } 
  }
  
  private boolean p(j0 paramj0) {
    e0 e01 = paramj0.a();
    String str = v.E(e01, "filepath");
    q.h().Z0().n();
    e0 e02 = v.q();
    try {
      GZIPInputStream gZIPInputStream;
      int i = v.A(e01, "offset");
      int j = v.A(e01, "size");
      boolean bool = v.t(e01, "gunzip");
      String str1 = v.E(e01, "output_filepath");
      o1 o12 = new o1(new FileInputStream(str), i, j);
      o1 o11 = o12;
      if (bool)
        gZIPInputStream = new GZIPInputStream(o12, 1024); 
      if (str1.equals("")) {
        StringBuilder stringBuilder = new StringBuilder(gZIPInputStream.available());
        arrayOfByte = new byte[1024];
        while (true) {
          i = gZIPInputStream.read(arrayOfByte, 0, 1024);
          if (i >= 0) {
            stringBuilder.append(new String(arrayOfByte, 0, i, "ISO-8859-1"));
            continue;
          } 
          v.u(e02, "size", stringBuilder.length());
          v.n(e02, "data", stringBuilder.toString());
          gZIPInputStream.close();
          v.w(e02, "success", true);
          paramj0.b(e02).e();
          return true;
        } 
      } 
      FileOutputStream fileOutputStream = new FileOutputStream((String)arrayOfByte);
      byte[] arrayOfByte = new byte[1024];
      i = 0;
      while (true) {
        j = gZIPInputStream.read(arrayOfByte, 0, 1024);
        if (j >= 0) {
          fileOutputStream.write(arrayOfByte, 0, j);
          i += j;
          continue;
        } 
        fileOutputStream.close();
        v.u(e02, "size", i);
        gZIPInputStream.close();
        v.w(e02, "success", true);
        paramj0.b(e02).e();
        return true;
      } 
    } catch (IOException iOException) {
      v.w(e02, "success", false);
      paramj0.b(e02).e();
      return false;
    } catch (OutOfMemoryError outOfMemoryError) {
      (new b0.a()).c("Out of memory error - disabling AdColony.").d(b0.h);
      q.h().X(true);
      v.w(e02, "success", false);
      paramj0.b(e02).e();
      return false;
    } 
  }
  
  private boolean s(j0 paramj0) {
    String str = v.E(paramj0.a(), "filepath");
    q.h().Z0().n();
    e0 e0 = v.q();
    String[] arrayOfString = (new File(str)).list();
    if (arrayOfString != null) {
      c0 c0 = v.c();
      int j = arrayOfString.length;
      for (int i = 0; i < j; i++) {
        String str1 = arrayOfString[i];
        e0 e01 = v.q();
        v.n(e01, "filename", str1);
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append(str);
        stringBuilder.append(str1);
        if ((new File(stringBuilder.toString())).isDirectory()) {
          v.w(e01, "is_folder", true);
        } else {
          v.w(e01, "is_folder", false);
        } 
        v.i(c0, e01);
      } 
      v.w(e0, "success", true);
      v.l(e0, "entries", c0);
      paramj0.b(e0).e();
      return true;
    } 
    v.w(e0, "success", false);
    paramj0.b(e0).e();
    return false;
  }
  
  private String t(j0 paramj0) {
    boolean bool;
    e0 e02 = paramj0.a();
    String str2 = v.E(e02, "filepath");
    String str1 = v.E(e02, "encoding");
    if (str1 != null && str1.equals("utf8")) {
      bool = true;
    } else {
      bool = false;
    } 
    q.h().Z0().n();
    e0 e01 = v.q();
    try {
      StringBuilder stringBuilder = a(str2, bool);
      v.w(e01, "success", true);
      v.n(e01, "data", stringBuilder.toString());
      paramj0.b(e01).e();
      return stringBuilder.toString();
    } catch (IOException iOException) {
      v.w(e01, "success", false);
      paramj0.b(e01).e();
      return "";
    } 
  }
  
  private boolean v(j0 paramj0) {
    e0 e0 = paramj0.a();
    String str1 = v.E(e0, "filepath");
    String str2 = v.E(e0, "new_filepath");
    q.h().Z0().n();
    e0 = v.q();
    try {
      if ((new File(str1)).renameTo(new File(str2))) {
        v.w(e0, "success", true);
        paramj0.b(e0).e();
        return true;
      } 
      v.w(e0, "success", false);
      paramj0.b(e0).e();
      return false;
    } catch (Exception exception) {
      v.w(e0, "success", false);
      paramj0.b(e0).e();
      return false;
    } 
  }
  
  private boolean x(j0 paramj0) {
    e0 e0 = paramj0.a();
    String str1 = v.E(e0, "filepath");
    String str2 = v.E(e0, "data");
    boolean bool = v.E(e0, "encoding").equals("utf8");
    q.h().Z0().n();
    e0 = v.q();
    try {
      f(str1, str2, bool);
      v.w(e0, "success", true);
      paramj0.b(e0).e();
      return true;
    } catch (IOException iOException) {
      v.w(e0, "success", false);
      paramj0.b(e0).e();
      return false;
    } 
  }
  
  private boolean z(j0 paramj0) {
    e0 e01 = paramj0.a();
    String str1 = v.E(e01, "filepath");
    String str2 = v.E(e01, "bundle_path");
    c0 c0 = v.d(e01, "bundle_filenames");
    q.h().Z0().n();
    e0 e02 = v.q();
    try {
      File file = new File(str2);
      RandomAccessFile randomAccessFile = new RandomAccessFile(file, "r");
      byte[] arrayOfByte1 = new byte[32];
      randomAccessFile.readInt();
      int j = randomAccessFile.readInt();
      c0 c01 = new c0();
      byte[] arrayOfByte2 = new byte[1024];
      int i = 0;
      while (true) {
        if (i < j) {
          randomAccessFile.seek((i * 44 + 8));
          randomAccessFile.read(arrayOfByte1);
          randomAccessFile.readInt();
          int k = randomAccessFile.readInt();
          int m = randomAccessFile.readInt();
          c01.m(m);
          try {
            StringBuilder stringBuilder = new StringBuilder();
            stringBuilder.append(str1);
            stringBuilder.append(c0.b(i));
            String str = stringBuilder.toString();
            long l = k;
            randomAccessFile.seek(l);
            FileOutputStream fileOutputStream = new FileOutputStream(str);
            k = m / 1024;
            int n = m % 1024;
            for (m = 0; m < k; m++) {
              randomAccessFile.read(arrayOfByte2, 0, 1024);
              fileOutputStream.write(arrayOfByte2, 0, 1024);
            } 
            randomAccessFile.read(arrayOfByte2, 0, n);
            fileOutputStream.write(arrayOfByte2, 0, n);
            fileOutputStream.close();
            i++;
            continue;
          } catch (JSONException jSONException) {
            (new b0.a()).c("Couldn't extract file name at index ").a(i).c(" unpacking ad unit bundle at ").c(str2).d(b0.h);
            try {
              v.w(e02, "success", false);
              paramj0.b(e02).e();
              return false;
            } catch (IOException iOException) {}
          } 
        } else {
          randomAccessFile.close();
          iOException.delete();
          v.w(e02, "success", true);
          v.l(e02, "file_sizes", c01);
          paramj0.b(e02).e();
          return true;
        } 
        (new b0.a()).c("Failed to find or open ad unit bundle at path: ").c(str2).d(b0.i);
        v.w(e02, "success", false);
        paramj0.b(e02).e();
        return false;
      } 
    } catch (IOException iOException) {
      (new b0.a()).c("Failed to find or open ad unit bundle at path: ").c(str2).d(b0.i);
      v.w(e02, "success", false);
      paramj0.b(e02).e();
      return false;
    } catch (OutOfMemoryError outOfMemoryError) {
      (new b0.a()).c("Out of memory error - disabling AdColony.").d(b0.h);
      q.h().X(true);
      v.w(e02, "success", false);
      paramj0.b(e02).e();
      return false;
    } 
  }
  
  StringBuilder a(String paramString, boolean paramBoolean) throws IOException {
    BufferedReader bufferedReader;
    File file = new File(paramString);
    StringBuilder stringBuilder = new StringBuilder((int)file.length());
    if (paramBoolean) {
      bufferedReader = new BufferedReader(new InputStreamReader(new FileInputStream(file.getAbsolutePath()), k0.a));
    } else {
      bufferedReader = new BufferedReader(new InputStreamReader(new FileInputStream(bufferedReader.getAbsolutePath())));
    } 
    while (true) {
      String str = bufferedReader.readLine();
      if (str != null) {
        stringBuilder.append(str);
        stringBuilder.append("\n");
        continue;
      } 
      bufferedReader.close();
      return stringBuilder;
    } 
  }
  
  void f(String paramString1, String paramString2, boolean paramBoolean) throws IOException {
    BufferedWriter bufferedWriter;
    if (paramBoolean) {
      bufferedWriter = new BufferedWriter(new OutputStreamWriter(new FileOutputStream(paramString1), k0.a));
    } else {
      bufferedWriter = new BufferedWriter(new OutputStreamWriter(new FileOutputStream((String)bufferedWriter)));
    } 
    bufferedWriter.write(paramString2);
    bufferedWriter.flush();
    bufferedWriter.close();
  }
  
  boolean k(File paramFile) {
    try {
      if (paramFile.isDirectory()) {
        if ((paramFile.list()).length == 0)
          return paramFile.delete(); 
        String[] arrayOfString = paramFile.list();
        if (arrayOfString.length > 0)
          return k(new File(paramFile, arrayOfString[0])); 
        if ((paramFile.list()).length == 0)
          return paramFile.delete(); 
      } else {
        return paramFile.delete();
      } 
    } catch (Exception exception) {
      return false;
    } 
    return false;
  }
  
  void m() {
    q.g("FileSystem.save", new a(this));
    q.g("FileSystem.delete", new b(this));
    q.g("FileSystem.listing", new c(this));
    q.g("FileSystem.load", new d(this));
    q.g("FileSystem.rename", new e(this));
    q.g("FileSystem.exists", new f(this));
    q.g("FileSystem.extract", new g(this));
    q.g("FileSystem.unpack_bundle", new h(this));
    q.g("FileSystem.create_directory", new i(this));
  }
  
  class a implements o0 {
    a(n1 this$0) {}
    
    public void a(j0 param1j0) {
      n1.d(this.a, new a(this, param1j0));
    }
    
    class a implements Runnable {
      a(n1.a this$0, j0 param2j0) {}
      
      public void run() {
        n1.i(this.c.a, this.b);
        n1.c(this.c.a);
      }
    }
  }
  
  class a implements Runnable {
    a(n1 this$0, j0 param1j0) {}
    
    public void run() {
      n1.i(this.c.a, this.b);
      n1.c(this.c.a);
    }
  }
  
  class b implements o0 {
    b(n1 this$0) {}
    
    public void a(j0 param1j0) {
      n1.d(this.a, new a(this, param1j0));
    }
    
    class a implements Runnable {
      a(n1.b this$0, j0 param2j0) {}
      
      public void run() {
        File file = new File(v.E(this.b.a(), "filepath"));
        n1.j(this.c.a, this.b, file);
        n1.c(this.c.a);
      }
    }
  }
  
  class a implements Runnable {
    a(n1 this$0, j0 param1j0) {}
    
    public void run() {
      File file = new File(v.E(this.b.a(), "filepath"));
      n1.j(this.c.a, this.b, file);
      n1.c(this.c.a);
    }
  }
  
  class c implements o0 {
    c(n1 this$0) {}
    
    public void a(j0 param1j0) {
      n1.d(this.a, new a(this, param1j0));
    }
    
    class a implements Runnable {
      a(n1.c this$0, j0 param2j0) {}
      
      public void run() {
        n1.q(this.c.a, this.b);
        n1.c(this.c.a);
      }
    }
  }
  
  class a implements Runnable {
    a(n1 this$0, j0 param1j0) {}
    
    public void run() {
      n1.q(this.c.a, this.b);
      n1.c(this.c.a);
    }
  }
  
  class d implements o0 {
    d(n1 this$0) {}
    
    public void a(j0 param1j0) {
      n1.d(this.a, new a(this, param1j0));
    }
    
    class a implements Runnable {
      a(n1.d this$0, j0 param2j0) {}
      
      public void run() {
        n1.r(this.c.a, this.b);
        n1.c(this.c.a);
      }
    }
  }
  
  class a implements Runnable {
    a(n1 this$0, j0 param1j0) {}
    
    public void run() {
      n1.r(this.c.a, this.b);
      n1.c(this.c.a);
    }
  }
  
  class e implements o0 {
    e(n1 this$0) {}
    
    public void a(j0 param1j0) {
      n1.d(this.a, new a(this, param1j0));
    }
    
    class a implements Runnable {
      a(n1.e this$0, j0 param2j0) {}
      
      public void run() {
        n1.u(this.c.a, this.b);
        n1.c(this.c.a);
      }
    }
  }
  
  class a implements Runnable {
    a(n1 this$0, j0 param1j0) {}
    
    public void run() {
      n1.u(this.c.a, this.b);
      n1.c(this.c.a);
    }
  }
  
  class f implements o0 {
    f(n1 this$0) {}
    
    public void a(j0 param1j0) {
      n1.d(this.a, new a(this, param1j0));
    }
    
    class a implements Runnable {
      a(n1.f this$0, j0 param2j0) {}
      
      public void run() {
        n1.w(this.c.a, this.b);
        n1.c(this.c.a);
      }
    }
  }
  
  class a implements Runnable {
    a(n1 this$0, j0 param1j0) {}
    
    public void run() {
      n1.w(this.c.a, this.b);
      n1.c(this.c.a);
    }
  }
  
  class g implements o0 {
    g(n1 this$0) {}
    
    public void a(j0 param1j0) {
      n1.d(this.a, new a(this, param1j0));
    }
    
    class a implements Runnable {
      a(n1.g this$0, j0 param2j0) {}
      
      public void run() {
        n1.y(this.c.a, this.b);
        n1.c(this.c.a);
      }
    }
  }
  
  class a implements Runnable {
    a(n1 this$0, j0 param1j0) {}
    
    public void run() {
      n1.y(this.c.a, this.b);
      n1.c(this.c.a);
    }
  }
  
  class h implements o0 {
    h(n1 this$0) {}
    
    public void a(j0 param1j0) {
      n1.d(this.a, new a(this, param1j0));
    }
    
    class a implements Runnable {
      a(n1.h this$0, j0 param2j0) {}
      
      public void run() {
        n1.A(this.c.a, this.b);
        n1.c(this.c.a);
      }
    }
  }
  
  class a implements Runnable {
    a(n1 this$0, j0 param1j0) {}
    
    public void run() {
      n1.A(this.c.a, this.b);
      n1.c(this.c.a);
    }
  }
  
  class i implements o0 {
    i(n1 this$0) {}
    
    public void a(j0 param1j0) {
      n1.d(this.a, new a(this, param1j0));
    }
    
    class a implements Runnable {
      a(n1.i this$0, j0 param2j0) {}
      
      public void run() {
        n1.o(this.c.a, this.b);
        n1.c(this.c.a);
      }
    }
  }
  
  class a implements Runnable {
    a(n1 this$0, j0 param1j0) {}
    
    public void run() {
      n1.o(this.c.a, this.b);
      n1.c(this.c.a);
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Hill race-dex2jar.jar!\com\adcolony\sdk\n1.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */