package com.adcolony.sdk;

import java.nio.charset.Charset;

class k0 {
  static final Charset a = Charset.forName("UTF-8");
}


/* Location:              C:\soft\dex2jar-2.0\Hill race-dex2jar.jar!\com\adcolony\sdk\k0.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */