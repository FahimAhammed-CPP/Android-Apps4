package com.adcolony.sdk;

import android.annotation.SuppressLint;
import android.content.Context;
import android.graphics.Typeface;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.FrameLayout;

@SuppressLint({"AppCompatCustomView"})
class r1 extends Button {
  private int b;
  
  private int c;
  
  private int d;
  
  private int e;
  
  private int f;
  
  private int g;
  
  private int h;
  
  private int i;
  
  private int j;
  
  private int k;
  
  private String l;
  
  private String m;
  
  private String n;
  
  private String o;
  
  private u p;
  
  private j0 q;
  
  r1(Context paramContext, int paramInt1, j0 paramj0, int paramInt2, u paramu) {
    super(paramContext, null, paramInt1);
    this.b = paramInt2;
    this.q = paramj0;
    this.p = paramu;
  }
  
  r1(Context paramContext, j0 paramj0, int paramInt, u paramu) {
    super(paramContext);
    this.b = paramInt;
    this.q = paramj0;
    this.p = paramu;
  }
  
  int a(boolean paramBoolean, int paramInt) {
    return (paramInt != 0) ? ((paramInt != 1) ? ((paramInt != 2) ? 17 : (paramBoolean ? 8388613 : 80)) : (paramBoolean ? 8388611 : 48)) : (paramBoolean ? 1 : 16);
  }
  
  void b() {
    boolean bool;
    FrameLayout.LayoutParams layoutParams;
    e0 e0 = this.q.a();
    this.o = v.E(e0, "ad_session_id");
    this.c = v.A(e0, "x");
    this.d = v.A(e0, "y");
    this.e = v.A(e0, "width");
    this.f = v.A(e0, "height");
    this.h = v.A(e0, "font_family");
    this.g = v.A(e0, "font_style");
    this.i = v.A(e0, "font_size");
    this.l = v.E(e0, "background_color");
    this.m = v.E(e0, "font_color");
    this.n = v.E(e0, "text");
    this.j = v.A(e0, "align_x");
    this.k = v.A(e0, "align_y");
    p0 p0 = q.h();
    if (this.n.equals(""))
      this.n = "Learn More"; 
    setVisibility(4);
    if (v.t(e0, "wrap_content")) {
      layoutParams = new FrameLayout.LayoutParams(-2, -2);
    } else {
      layoutParams = new FrameLayout.LayoutParams(this.e, this.f);
    } 
    layoutParams.gravity = 0;
    setText(this.n);
    setTextSize(this.i);
    if (v.t(e0, "overlay")) {
      this.c = 0;
      this.d = 0;
      i = (int)(p0.H0().Y() * 6.0F);
      bool = (int)(p0.H0().Y() * 6.0F);
      int j = (int)(p0.H0().Y() * 4.0F);
      setPadding(j, j, j, j);
      layoutParams.gravity = 8388693;
    } else {
      i = 0;
      bool = false;
    } 
    layoutParams.setMargins(this.c, this.d, i, bool);
    this.p.addView((View)this, (ViewGroup.LayoutParams)layoutParams);
    int i = this.h;
    if (i != 0) {
      if (i != 1) {
        if (i != 2) {
          if (i == 3)
            setTypeface(Typeface.MONOSPACE); 
        } else {
          setTypeface(Typeface.SANS_SERIF);
        } 
      } else {
        setTypeface(Typeface.SERIF);
      } 
    } else {
      setTypeface(Typeface.DEFAULT);
    } 
    i = this.g;
    if (i != 0) {
      if (i != 1) {
        if (i != 2) {
          if (i == 3)
            setTypeface(getTypeface(), 3); 
        } else {
          setTypeface(getTypeface(), 2);
        } 
      } else {
        setTypeface(getTypeface(), 1);
      } 
    } else {
      setTypeface(getTypeface(), 0);
    } 
    setGravity(a(true, this.j) | a(false, this.k));
    if (!this.l.equals(""))
      setBackgroundColor(u1.T(this.l)); 
    if (!this.m.equals(""))
      setTextColor(u1.T(this.m)); 
    this.p.F().add(q.b("TextView.set_visible", new b(this), true));
    this.p.F().add(q.b("TextView.set_bounds", new c(this), true));
    this.p.F().add(q.b("TextView.set_font_color", new d(this), true));
    this.p.F().add(q.b("TextView.set_background_color", new e(this), true));
    this.p.F().add(q.b("TextView.set_typeface", new f(this), true));
    this.p.F().add(q.b("TextView.set_font_size", new g(this), true));
    this.p.F().add(q.b("TextView.set_font_style", new h(this), true));
    this.p.F().add(q.b("TextView.get_text", new i(this), true));
    this.p.F().add(q.b("TextView.set_text", new j(this), true));
    this.p.F().add(q.b("TextView.align", new a(this), true));
    this.p.H().add("TextView.set_visible");
    this.p.H().add("TextView.set_bounds");
    this.p.H().add("TextView.set_font_color");
    this.p.H().add("TextView.set_background_color");
    this.p.H().add("TextView.set_typeface");
    this.p.H().add("TextView.set_font_size");
    this.p.H().add("TextView.set_font_style");
    this.p.H().add("TextView.get_text");
    this.p.H().add("TextView.set_text");
    this.p.H().add("TextView.align");
  }
  
  void c(j0 paramj0) {
    e0 e0 = paramj0.a();
    this.j = v.A(e0, "x");
    this.k = v.A(e0, "y");
    setGravity(a(true, this.j) | a(false, this.k));
  }
  
  void d(j0 paramj0) {
    e0 e0 = v.q();
    v.n(e0, "text", getText().toString());
    paramj0.b(e0).e();
  }
  
  boolean e(j0 paramj0) {
    e0 e0 = paramj0.a();
    return (v.A(e0, "id") == this.b && v.A(e0, "container_id") == this.p.q() && v.E(e0, "ad_session_id").equals(this.p.b()));
  }
  
  void f(j0 paramj0) {
    String str = v.E(paramj0.a(), "background_color");
    this.l = str;
    setBackgroundColor(u1.T(str));
  }
  
  void g(j0 paramj0) {
    e0 e0 = paramj0.a();
    this.c = v.A(e0, "x");
    this.d = v.A(e0, "y");
    this.e = v.A(e0, "width");
    this.f = v.A(e0, "height");
    FrameLayout.LayoutParams layoutParams = (FrameLayout.LayoutParams)getLayoutParams();
    layoutParams.setMargins(this.c, this.d, 0, 0);
    layoutParams.width = this.e;
    layoutParams.height = this.f;
    setLayoutParams((ViewGroup.LayoutParams)layoutParams);
  }
  
  void h(j0 paramj0) {
    String str = v.E(paramj0.a(), "font_color");
    this.m = str;
    setTextColor(u1.T(str));
  }
  
  void i(j0 paramj0) {
    int i = v.A(paramj0.a(), "font_size");
    this.i = i;
    setTextSize(i);
  }
  
  void j(j0 paramj0) {
    int i = v.A(paramj0.a(), "font_style");
    this.g = i;
    if (i != 0) {
      if (i != 1) {
        if (i != 2) {
          if (i != 3)
            return; 
          setTypeface(getTypeface(), 3);
          return;
        } 
        setTypeface(getTypeface(), 2);
        return;
      } 
      setTypeface(getTypeface(), 1);
      return;
    } 
    setTypeface(getTypeface(), 0);
  }
  
  void k(j0 paramj0) {
    String str = v.E(paramj0.a(), "text");
    this.n = str;
    setText(str);
  }
  
  void l(j0 paramj0) {
    int i = v.A(paramj0.a(), "font_family");
    this.h = i;
    if (i != 0) {
      if (i != 1) {
        if (i != 2) {
          if (i != 3)
            return; 
          setTypeface(Typeface.MONOSPACE);
          return;
        } 
        setTypeface(Typeface.SANS_SERIF);
        return;
      } 
      setTypeface(Typeface.SERIF);
      return;
    } 
    setTypeface(Typeface.DEFAULT);
  }
  
  void m(j0 paramj0) {
    if (v.t(paramj0.a(), "visible")) {
      setVisibility(0);
      return;
    } 
    setVisibility(4);
  }
  
  @SuppressLint({"ClickableViewAccessibility"})
  public boolean onTouchEvent(MotionEvent paramMotionEvent) {
    p0 p0 = q.h();
    x x = p0.Z();
    int i = paramMotionEvent.getAction() & 0xFF;
    if (i != 0 && i != 1 && i != 3 && i != 2 && i != 5 && i != 6)
      return false; 
    int j = (int)paramMotionEvent.getX();
    int k = (int)paramMotionEvent.getY();
    e0 e0 = v.q();
    v.u(e0, "view_id", this.b);
    v.n(e0, "ad_session_id", this.o);
    v.u(e0, "container_x", this.c + j);
    v.u(e0, "container_y", this.d + k);
    v.u(e0, "view_x", j);
    v.u(e0, "view_y", k);
    v.u(e0, "id", this.p.getId());
    if (i != 0) {
      if (i != 1) {
        if (i != 2) {
          if (i != 3) {
            if (i != 5) {
              if (i == 6) {
                i = (paramMotionEvent.getAction() & 0xFF00) >> 8;
                j = (int)paramMotionEvent.getX(i);
                k = (int)paramMotionEvent.getY(i);
                v.u(e0, "container_x", (int)paramMotionEvent.getX(i) + this.c);
                v.u(e0, "container_y", (int)paramMotionEvent.getY(i) + this.d);
                v.u(e0, "view_x", (int)paramMotionEvent.getX(i));
                v.u(e0, "view_y", (int)paramMotionEvent.getY(i));
                if (!this.p.O())
                  p0.y(x.w().get(this.o)); 
                if (j > 0 && j < getWidth() && k > 0 && k < getHeight()) {
                  (new j0("AdContainer.on_touch_ended", this.p.J(), e0)).e();
                } else {
                  (new j0("AdContainer.on_touch_cancelled", this.p.J(), e0)).e();
                } 
              } 
            } else {
              i = (paramMotionEvent.getAction() & 0xFF00) >> 8;
              v.u(e0, "container_x", (int)paramMotionEvent.getX(i) + this.c);
              v.u(e0, "container_y", (int)paramMotionEvent.getY(i) + this.d);
              v.u(e0, "view_x", (int)paramMotionEvent.getX(i));
              v.u(e0, "view_y", (int)paramMotionEvent.getY(i));
              (new j0("AdContainer.on_touch_began", this.p.J(), e0)).e();
            } 
          } else {
            (new j0("AdContainer.on_touch_cancelled", this.p.J(), e0)).e();
          } 
        } else {
          (new j0("AdContainer.on_touch_moved", this.p.J(), e0)).e();
        } 
      } else {
        if (!this.p.O())
          p0.y(x.w().get(this.o)); 
        if (j > 0 && j < getWidth() && k > 0 && k < getHeight()) {
          (new j0("AdContainer.on_touch_ended", this.p.J(), e0)).e();
        } else {
          (new j0("AdContainer.on_touch_cancelled", this.p.J(), e0)).e();
        } 
      } 
    } else {
      (new j0("AdContainer.on_touch_began", this.p.J(), e0)).e();
    } 
    return true;
  }
  
  class a implements o0 {
    a(r1 this$0) {}
    
    public void a(j0 param1j0) {
      if (this.a.e(param1j0))
        this.a.c(param1j0); 
    }
  }
  
  class b implements o0 {
    b(r1 this$0) {}
    
    public void a(j0 param1j0) {
      if (this.a.e(param1j0))
        this.a.m(param1j0); 
    }
  }
  
  class c implements o0 {
    c(r1 this$0) {}
    
    public void a(j0 param1j0) {
      if (this.a.e(param1j0))
        this.a.g(param1j0); 
    }
  }
  
  class d implements o0 {
    d(r1 this$0) {}
    
    public void a(j0 param1j0) {
      if (this.a.e(param1j0))
        this.a.h(param1j0); 
    }
  }
  
  class e implements o0 {
    e(r1 this$0) {}
    
    public void a(j0 param1j0) {
      if (this.a.e(param1j0))
        this.a.f(param1j0); 
    }
  }
  
  class f implements o0 {
    f(r1 this$0) {}
    
    public void a(j0 param1j0) {
      if (this.a.e(param1j0))
        this.a.l(param1j0); 
    }
  }
  
  class g implements o0 {
    g(r1 this$0) {}
    
    public void a(j0 param1j0) {
      if (this.a.e(param1j0))
        this.a.i(param1j0); 
    }
  }
  
  class h implements o0 {
    h(r1 this$0) {}
    
    public void a(j0 param1j0) {
      if (this.a.e(param1j0))
        this.a.j(param1j0); 
    }
  }
  
  class i implements o0 {
    i(r1 this$0) {}
    
    public void a(j0 param1j0) {
      if (this.a.e(param1j0))
        this.a.d(param1j0); 
    }
  }
  
  class j implements o0 {
    j(r1 this$0) {}
    
    public void a(j0 param1j0) {
      if (this.a.e(param1j0))
        this.a.k(param1j0); 
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Hill race-dex2jar.jar!\com\adcolony\sdk\r1.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */