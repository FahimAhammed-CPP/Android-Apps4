package com.adcolony.sdk;

import android.os.SystemClock;
import java.util.LinkedHashMap;

class i1 {
  private long a = 1800000L;
  
  private int b;
  
  private long c;
  
  private boolean d = true;
  
  private boolean e = true;
  
  private boolean f;
  
  private boolean g = false;
  
  private boolean h = false;
  
  private boolean i;
  
  private boolean j;
  
  private boolean k;
  
  private k1 l;
  
  private void t() {
    c(false);
  }
  
  private void u() {
    g(false);
  }
  
  long a() {
    return this.a;
  }
  
  void b(int paramInt) {
    long l;
    if (paramInt <= 0) {
      l = this.a;
    } else {
      l = (paramInt * 1000);
    } 
    this.a = l;
  }
  
  void c(boolean paramBoolean) {
    this.e = true;
    this.l.f();
    if (!a.j(new c(this, paramBoolean)))
      (new b0.a()).c("RejectedExecutionException on session pause.").d(b0.i); 
  }
  
  int f() {
    return this.b;
  }
  
  void g(boolean paramBoolean) {
    this.e = false;
    this.l.g();
    if (!a.j(new d(this, paramBoolean)))
      (new b0.a()).c("RejectedExecutionException on session resume.").d(b0.i); 
  }
  
  void j() {
    this.b++;
  }
  
  void k(boolean paramBoolean) {
    p0 p0 = q.h();
    if (this.f)
      return; 
    if (this.i) {
      p0.b0(false);
      this.i = false;
    } 
    this.b = 0;
    this.c = SystemClock.uptimeMillis();
    this.d = true;
    this.f = true;
    this.g = true;
    this.h = false;
    a.o();
    if (paramBoolean) {
      e0 e0 = v.q();
      v.n(e0, "id", u1.i());
      (new j0("SessionInfo.on_start", 1, e0)).e();
      r0 r0 = q.h().P0().q();
      if (r0 != null && !a.j(new b(this, r0, p0)))
        (new b0.a()).c("RejectedExecutionException on controller update.").d(b0.i); 
    } 
    p0.P0().w();
    l1.b().k();
  }
  
  public void l() {
    q.g("SessionInfo.stopped", new a(this));
    this.l = new k1(this);
  }
  
  void m(boolean paramBoolean) {
    if (paramBoolean && this.e) {
      u();
    } else if (!paramBoolean && !this.e) {
      t();
    } 
    this.d = paramBoolean;
  }
  
  void n(boolean paramBoolean) {
    if (this.g != paramBoolean) {
      this.g = paramBoolean;
      this.h = true;
      if (!paramBoolean)
        t(); 
    } 
  }
  
  boolean o() {
    return this.d;
  }
  
  public void p(boolean paramBoolean) {
    this.i = paramBoolean;
  }
  
  boolean q() {
    return this.f;
  }
  
  void r(boolean paramBoolean) {
    this.k = paramBoolean;
  }
  
  boolean s() {
    return this.k;
  }
  
  void v() {
    g1 g1 = q.h().N0().c();
    this.f = false;
    this.d = false;
    if (g1 != null)
      g1.f(); 
    e0 e0 = v.q();
    v.k(e0, "session_length", (SystemClock.uptimeMillis() - this.c) / 1000.0D);
    (new j0("SessionInfo.on_stop", 1, e0)).e();
    q.m();
    a.v();
  }
  
  class a implements o0 {
    a(i1 this$0) {}
    
    public void a(j0 param1j0) {
      i1.e(this.a, true);
    }
  }
  
  class b implements Runnable {
    b(i1 this$0, r0 param1r0, p0 param1p0) {}
    
    public void run() {
      this.b.b();
      this.c.N0().q();
    }
  }
  
  class c implements Runnable {
    c(i1 this$0, boolean param1Boolean) {}
    
    public void run() {
      synchronized (q.h().P0().s()) {
        for (q0 q0 : null.values()) {
          e0 e0 = v.q();
          v.w(e0, "from_window_focus", this.b);
          if (i1.d(this.c) && !i1.h(this.c)) {
            v.w(e0, "app_in_foreground", false);
            i1.i(this.c, false);
          } 
          (new j0("SessionInfo.on_pause", q0.getModuleId(), e0)).e();
        } 
        q.m();
        return;
      } 
    }
  }
  
  class d implements Runnable {
    d(i1 this$0, boolean param1Boolean) {}
    
    public void run() {
      null = q.h();
      synchronized (null.P0().s()) {
        for (q0 q0 : null.values()) {
          e0 e0 = v.q();
          v.w(e0, "from_window_focus", this.b);
          if (i1.d(this.c) && i1.h(this.c)) {
            v.w(e0, "app_in_foreground", true);
            i1.i(this.c, false);
          } 
          (new j0("SessionInfo.on_resume", q0.getModuleId(), e0)).e();
        } 
        null.N0().q();
        return;
      } 
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Hill race-dex2jar.jar!\com\adcolony\sdk\i1.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */