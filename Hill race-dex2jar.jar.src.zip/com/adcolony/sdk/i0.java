package com.adcolony.sdk;

import android.content.Context;
import android.graphics.Point;
import android.graphics.Rect;
import android.os.Build;
import android.view.View;
import android.view.ViewGroup;
import android.view.WindowManager;
import java.util.ArrayList;
import java.util.LinkedList;
import java.util.ListIterator;

class i0 {
  private static int a;
  
  private static int b;
  
  private static int c;
  
  private static int d;
  
  static float a(View paramView, Context paramContext, boolean paramBoolean1, boolean paramBoolean2, boolean paramBoolean3, boolean paramBoolean4) {
    // Byte code:
    //   0: aload_0
    //   1: ifnull -> 607
    //   4: aload_1
    //   5: ifnonnull -> 10
    //   8: fconst_0
    //   9: freturn
    //   10: aload_0
    //   11: invokevirtual getVisibility : ()I
    //   14: ifne -> 607
    //   17: aload_0
    //   18: invokestatic g : (Landroid/view/View;)F
    //   21: fconst_0
    //   22: fcmpl
    //   23: ifne -> 28
    //   26: fconst_0
    //   27: freturn
    //   28: iload_2
    //   29: ifne -> 34
    //   32: fconst_0
    //   33: freturn
    //   34: iload #4
    //   36: ifeq -> 63
    //   39: aload_1
    //   40: instanceof android/app/Activity
    //   43: ifeq -> 63
    //   46: aload_1
    //   47: checkcast android/app/Activity
    //   50: invokevirtual hasWindowFocus : ()Z
    //   53: ifne -> 63
    //   56: iload #5
    //   58: ifne -> 63
    //   61: fconst_0
    //   62: freturn
    //   63: aload_0
    //   64: invokevirtual getHeight : ()I
    //   67: ifle -> 346
    //   70: aload_0
    //   71: invokevirtual getWidth : ()I
    //   74: ifle -> 346
    //   77: aload_0
    //   78: invokevirtual getHeight : ()I
    //   81: aload_0
    //   82: invokevirtual getWidth : ()I
    //   85: imul
    //   86: i2f
    //   87: fstore #8
    //   89: new android/graphics/Rect
    //   92: dup
    //   93: invokespecial <init> : ()V
    //   96: astore #12
    //   98: aload_0
    //   99: aload #12
    //   101: invokevirtual getGlobalVisibleRect : (Landroid/graphics/Rect;)Z
    //   104: istore_2
    //   105: iconst_2
    //   106: newarray int
    //   108: astore #13
    //   110: aload #13
    //   112: dup
    //   113: iconst_0
    //   114: iconst_m1
    //   115: iastore
    //   116: dup
    //   117: iconst_1
    //   118: iconst_m1
    //   119: iastore
    //   120: pop
    //   121: aload_0
    //   122: aload #13
    //   124: invokevirtual getLocationInWindow : ([I)V
    //   127: iconst_2
    //   128: newarray int
    //   130: astore #14
    //   132: aload #14
    //   134: dup
    //   135: iconst_0
    //   136: iconst_m1
    //   137: iastore
    //   138: dup
    //   139: iconst_1
    //   140: iconst_m1
    //   141: iastore
    //   142: pop
    //   143: aload #14
    //   145: iconst_0
    //   146: aload #13
    //   148: iconst_0
    //   149: iaload
    //   150: aload_0
    //   151: invokevirtual getWidth : ()I
    //   154: iadd
    //   155: iastore
    //   156: aload #14
    //   158: iconst_1
    //   159: aload #13
    //   161: iconst_1
    //   162: iaload
    //   163: aload_0
    //   164: invokevirtual getHeight : ()I
    //   167: iadd
    //   168: iastore
    //   169: aload_1
    //   170: invokestatic d : (Landroid/content/Context;)I
    //   173: istore #10
    //   175: aload_1
    //   176: invokestatic h : (Landroid/content/Context;)I
    //   179: istore #11
    //   181: aload #14
    //   183: iconst_0
    //   184: iaload
    //   185: iflt -> 344
    //   188: aload #14
    //   190: iconst_1
    //   191: iaload
    //   192: iflt -> 344
    //   195: aload #13
    //   197: iconst_0
    //   198: iaload
    //   199: iload #11
    //   201: if_icmpgt -> 344
    //   204: aload #13
    //   206: iconst_1
    //   207: iaload
    //   208: iload #10
    //   210: if_icmpgt -> 344
    //   213: aload #12
    //   215: getfield top : I
    //   218: ifne -> 234
    //   221: aload #13
    //   223: iconst_1
    //   224: iaload
    //   225: iload #10
    //   227: iconst_2
    //   228: idiv
    //   229: if_icmple -> 234
    //   232: fconst_0
    //   233: freturn
    //   234: iload_2
    //   235: ifeq -> 607
    //   238: aload #12
    //   240: invokevirtual height : ()I
    //   243: aload #12
    //   245: invokevirtual width : ()I
    //   248: imul
    //   249: i2f
    //   250: fstore #7
    //   252: fload #7
    //   254: fconst_0
    //   255: fcmpl
    //   256: ifle -> 607
    //   259: fload #7
    //   261: fstore #6
    //   263: iload_3
    //   264: ifeq -> 311
    //   267: aload_0
    //   268: aload #12
    //   270: fload #7
    //   272: iconst_0
    //   273: invokestatic b : (Landroid/view/View;Landroid/graphics/Rect;FZ)F
    //   276: fstore #9
    //   278: fload #7
    //   280: fstore #6
    //   282: fload #9
    //   284: fconst_0
    //   285: fcmpl
    //   286: ifle -> 311
    //   289: fload #7
    //   291: fstore #6
    //   293: fload #9
    //   295: fload #7
    //   297: fcmpg
    //   298: ifgt -> 311
    //   301: fload #7
    //   303: fload #9
    //   305: fsub
    //   306: fstore #6
    //   308: goto -> 311
    //   311: fload #6
    //   313: fload #8
    //   315: fdiv
    //   316: ldc 100.0
    //   318: fmul
    //   319: fstore #6
    //   321: fload #6
    //   323: fconst_0
    //   324: fcmpg
    //   325: ifge -> 330
    //   328: fconst_0
    //   329: freturn
    //   330: fload #6
    //   332: ldc 100.0
    //   334: fcmpl
    //   335: ifle -> 341
    //   338: ldc 100.0
    //   340: freturn
    //   341: fload #6
    //   343: freturn
    //   344: fconst_0
    //   345: freturn
    //   346: aload_0
    //   347: invokevirtual getWidth : ()I
    //   350: ifle -> 607
    //   353: aload_0
    //   354: invokevirtual getLayoutParams : ()Landroid/view/ViewGroup$LayoutParams;
    //   357: getfield height : I
    //   360: bipush #-2
    //   362: if_icmpne -> 607
    //   365: iconst_2
    //   366: newarray int
    //   368: astore #12
    //   370: aload #12
    //   372: dup
    //   373: iconst_0
    //   374: iconst_m1
    //   375: iastore
    //   376: dup
    //   377: iconst_1
    //   378: iconst_m1
    //   379: iastore
    //   380: pop
    //   381: aload_0
    //   382: aload #12
    //   384: invokevirtual getLocationInWindow : ([I)V
    //   387: iconst_2
    //   388: newarray int
    //   390: astore #13
    //   392: aload #13
    //   394: dup
    //   395: iconst_0
    //   396: iconst_m1
    //   397: iastore
    //   398: dup
    //   399: iconst_1
    //   400: iconst_m1
    //   401: iastore
    //   402: pop
    //   403: aload #13
    //   405: iconst_0
    //   406: aload #12
    //   408: iconst_0
    //   409: iaload
    //   410: aload_0
    //   411: invokevirtual getWidth : ()I
    //   414: iadd
    //   415: iastore
    //   416: aload #13
    //   418: iconst_1
    //   419: aload #12
    //   421: iconst_1
    //   422: iaload
    //   423: iconst_1
    //   424: iadd
    //   425: iastore
    //   426: new android/graphics/Rect
    //   429: dup
    //   430: aload #12
    //   432: iconst_0
    //   433: iaload
    //   434: aload #12
    //   436: iconst_1
    //   437: iaload
    //   438: aload #13
    //   440: iconst_0
    //   441: iaload
    //   442: aload #13
    //   444: iconst_1
    //   445: iaload
    //   446: invokespecial <init> : (IIII)V
    //   449: astore #14
    //   451: aload_1
    //   452: invokestatic d : (Landroid/content/Context;)I
    //   455: istore #10
    //   457: aload_1
    //   458: invokestatic h : (Landroid/content/Context;)I
    //   461: istore #11
    //   463: aload #13
    //   465: iconst_0
    //   466: iaload
    //   467: iflt -> 607
    //   470: aload #13
    //   472: iconst_1
    //   473: iaload
    //   474: iflt -> 607
    //   477: aload #12
    //   479: iconst_0
    //   480: iaload
    //   481: iload #11
    //   483: if_icmpgt -> 607
    //   486: aload #12
    //   488: iconst_1
    //   489: iaload
    //   490: iload #10
    //   492: if_icmpgt -> 607
    //   495: aload #14
    //   497: getfield top : I
    //   500: ifne -> 516
    //   503: aload #12
    //   505: iconst_1
    //   506: iaload
    //   507: iload #10
    //   509: iconst_2
    //   510: idiv
    //   511: if_icmple -> 516
    //   514: fconst_0
    //   515: freturn
    //   516: aload #14
    //   518: invokevirtual height : ()I
    //   521: aload #14
    //   523: invokevirtual width : ()I
    //   526: imul
    //   527: i2f
    //   528: fstore #7
    //   530: iload_3
    //   531: ifeq -> 570
    //   534: aload_0
    //   535: aload #14
    //   537: fload #7
    //   539: iconst_1
    //   540: invokestatic b : (Landroid/view/View;Landroid/graphics/Rect;FZ)F
    //   543: fstore #6
    //   545: fload #6
    //   547: fconst_0
    //   548: fcmpl
    //   549: ifle -> 570
    //   552: fload #6
    //   554: fload #7
    //   556: fcmpg
    //   557: ifgt -> 570
    //   560: fload #7
    //   562: fload #6
    //   564: fsub
    //   565: fstore #6
    //   567: goto -> 574
    //   570: fload #7
    //   572: fstore #6
    //   574: fload #6
    //   576: fload #7
    //   578: fdiv
    //   579: ldc 100.0
    //   581: fmul
    //   582: fstore #6
    //   584: fload #6
    //   586: fconst_0
    //   587: fcmpg
    //   588: ifge -> 593
    //   591: fconst_0
    //   592: freturn
    //   593: fload #6
    //   595: ldc 100.0
    //   597: fcmpl
    //   598: ifle -> 604
    //   601: ldc 100.0
    //   603: freturn
    //   604: fload #6
    //   606: freturn
    //   607: fconst_0
    //   608: freturn
    //   609: astore_0
    //   610: fload #7
    //   612: fstore #6
    //   614: goto -> 311
    //   617: astore_0
    //   618: goto -> 570
    // Exception table:
    //   from	to	target	type
    //   267	278	609	java/lang/Exception
    //   534	545	617	java/lang/Exception
  }
  
  private static float b(View paramView, Rect paramRect, float paramFloat, boolean paramBoolean) {
    // Byte code:
    //   0: new java/util/LinkedList
    //   3: dup
    //   4: invokespecial <init> : ()V
    //   7: astore #15
    //   9: new java/util/LinkedList
    //   12: dup
    //   13: invokespecial <init> : ()V
    //   16: astore #13
    //   18: new java/util/LinkedList
    //   21: dup
    //   22: invokespecial <init> : ()V
    //   25: astore #11
    //   27: new java/util/LinkedList
    //   30: dup
    //   31: invokespecial <init> : ()V
    //   34: astore #14
    //   36: new java/util/ArrayList
    //   39: dup
    //   40: invokespecial <init> : ()V
    //   43: astore #12
    //   45: aload #11
    //   47: aload_1
    //   48: invokevirtual add : (Ljava/lang/Object;)Z
    //   51: pop
    //   52: aload_0
    //   53: invokevirtual getParent : ()Landroid/view/ViewParent;
    //   56: checkcast android/view/ViewGroup
    //   59: astore #10
    //   61: aload_0
    //   62: invokevirtual getRootView : ()Landroid/view/View;
    //   65: astore #16
    //   67: aload_0
    //   68: invokevirtual getContext : ()Landroid/content/Context;
    //   71: checkcast android/app/Activity
    //   74: ldc 16908290
    //   76: invokevirtual findViewById : (I)Landroid/view/View;
    //   79: astore_0
    //   80: goto -> 85
    //   83: aconst_null
    //   84: astore_0
    //   85: fconst_0
    //   86: fstore #6
    //   88: aload #10
    //   90: ifnull -> 183
    //   93: aload #10
    //   95: invokevirtual getParent : ()Landroid/view/ViewParent;
    //   98: aload #16
    //   100: if_acmpeq -> 183
    //   103: aload #10
    //   105: invokevirtual getVisibility : ()I
    //   108: ifne -> 181
    //   111: aload #10
    //   113: invokestatic g : (Landroid/view/View;)F
    //   116: fconst_0
    //   117: fcmpl
    //   118: ifne -> 123
    //   121: fload_2
    //   122: freturn
    //   123: aload_0
    //   124: ifnull -> 161
    //   127: iload_3
    //   128: ifeq -> 161
    //   131: aload #10
    //   133: aload_0
    //   134: if_acmpeq -> 161
    //   137: aload #10
    //   139: invokevirtual getLayoutParams : ()Landroid/view/ViewGroup$LayoutParams;
    //   142: getfield height : I
    //   145: ifeq -> 159
    //   148: aload #10
    //   150: invokevirtual getLayoutParams : ()Landroid/view/ViewGroup$LayoutParams;
    //   153: getfield width : I
    //   156: ifne -> 161
    //   159: fload_2
    //   160: freturn
    //   161: aload #15
    //   163: aload #10
    //   165: invokevirtual addFirst : (Ljava/lang/Object;)V
    //   168: aload #10
    //   170: invokevirtual getParent : ()Landroid/view/ViewParent;
    //   173: checkcast android/view/ViewGroup
    //   176: astore #10
    //   178: goto -> 85
    //   181: fload_2
    //   182: freturn
    //   183: aload #10
    //   185: ifnonnull -> 190
    //   188: fload_2
    //   189: freturn
    //   190: aload #15
    //   192: invokevirtual iterator : ()Ljava/util/Iterator;
    //   195: astore_0
    //   196: aload_0
    //   197: invokeinterface hasNext : ()Z
    //   202: ifeq -> 378
    //   205: aload_0
    //   206: invokeinterface next : ()Ljava/lang/Object;
    //   211: checkcast android/view/View
    //   214: astore #15
    //   216: aload #15
    //   218: invokevirtual getParent : ()Landroid/view/ViewParent;
    //   221: checkcast android/view/ViewGroup
    //   224: astore #10
    //   226: aload #10
    //   228: ifnonnull -> 233
    //   231: fload_2
    //   232: freturn
    //   233: ldc 'viewpager'
    //   235: aload #10
    //   237: invokevirtual getClass : ()Ljava/lang/Class;
    //   240: invokevirtual getSimpleName : ()Ljava/lang/String;
    //   243: invokevirtual equalsIgnoreCase : (Ljava/lang/String;)Z
    //   246: ifeq -> 252
    //   249: goto -> 196
    //   252: aload #10
    //   254: aload #15
    //   256: invokevirtual indexOfChild : (Landroid/view/View;)I
    //   259: istore #7
    //   261: iload #7
    //   263: aload #10
    //   265: invokevirtual getChildCount : ()I
    //   268: iconst_1
    //   269: isub
    //   270: if_icmpge -> 196
    //   273: iload #7
    //   275: iconst_1
    //   276: iadd
    //   277: istore #8
    //   279: iload #8
    //   281: aload #10
    //   283: invokevirtual getChildCount : ()I
    //   286: if_icmpge -> 196
    //   289: aload #10
    //   291: iload #8
    //   293: invokevirtual getChildAt : (I)Landroid/view/View;
    //   296: astore #15
    //   298: aload #15
    //   300: invokestatic i : (Landroid/view/View;)Z
    //   303: ifne -> 346
    //   306: iload #8
    //   308: istore #7
    //   310: aload #15
    //   312: invokevirtual getVisibility : ()I
    //   315: ifne -> 273
    //   318: iload #8
    //   320: istore #7
    //   322: aload #15
    //   324: invokestatic g : (Landroid/view/View;)F
    //   327: fconst_0
    //   328: fcmpl
    //   329: ifeq -> 273
    //   332: aload #14
    //   334: aload #15
    //   336: invokevirtual addFirst : (Ljava/lang/Object;)V
    //   339: iload #8
    //   341: istore #7
    //   343: goto -> 273
    //   346: aload #15
    //   348: invokestatic f : (Landroid/view/View;)Ljava/util/ArrayList;
    //   351: astore #15
    //   353: iload #8
    //   355: istore #7
    //   357: aload #15
    //   359: ifnull -> 273
    //   362: aload #14
    //   364: iconst_0
    //   365: aload #15
    //   367: invokevirtual addAll : (ILjava/util/Collection;)Z
    //   370: pop
    //   371: iload #8
    //   373: istore #7
    //   375: goto -> 273
    //   378: aload #14
    //   380: invokevirtual iterator : ()Ljava/util/Iterator;
    //   383: astore_0
    //   384: fconst_0
    //   385: fstore #4
    //   387: aload_0
    //   388: invokeinterface hasNext : ()Z
    //   393: ifeq -> 543
    //   396: aload_0
    //   397: invokeinterface next : ()Ljava/lang/Object;
    //   402: checkcast android/view/View
    //   405: astore #10
    //   407: fload #4
    //   409: fload_2
    //   410: fcmpl
    //   411: iflt -> 417
    //   414: goto -> 543
    //   417: aload #10
    //   419: ifnull -> 453
    //   422: aload #10
    //   424: invokevirtual getTag : ()Ljava/lang/Object;
    //   427: ifnull -> 453
    //   430: aload #10
    //   432: invokevirtual getTag : ()Ljava/lang/Object;
    //   435: checkcast java/lang/String
    //   438: ldc 'BTN_CLOSE'
    //   440: invokevirtual contains : (Ljava/lang/CharSequence;)Z
    //   443: istore #9
    //   445: iload #9
    //   447: ifeq -> 453
    //   450: goto -> 387
    //   453: new android/graphics/Rect
    //   456: dup
    //   457: invokespecial <init> : ()V
    //   460: astore #14
    //   462: aload #10
    //   464: aload #14
    //   466: invokevirtual getGlobalVisibleRect : (Landroid/graphics/Rect;)Z
    //   469: ifne -> 475
    //   472: goto -> 387
    //   475: iload_3
    //   476: ifeq -> 491
    //   479: aload #14
    //   481: aload #14
    //   483: getfield top : I
    //   486: iconst_1
    //   487: iadd
    //   488: putfield top : I
    //   491: aload #14
    //   493: aload_1
    //   494: invokevirtual intersect : (Landroid/graphics/Rect;)Z
    //   497: ifeq -> 387
    //   500: aload #13
    //   502: aload #14
    //   504: invokevirtual add : (Ljava/lang/Object;)Z
    //   507: pop
    //   508: aload #14
    //   510: invokevirtual width : ()I
    //   513: aload #14
    //   515: invokevirtual height : ()I
    //   518: imul
    //   519: i2f
    //   520: fstore #5
    //   522: fload #5
    //   524: fstore #4
    //   526: fload #5
    //   528: fload_2
    //   529: fcmpl
    //   530: iflt -> 387
    //   533: iconst_1
    //   534: istore #7
    //   536: fload #5
    //   538: fstore #4
    //   540: goto -> 546
    //   543: iconst_0
    //   544: istore #7
    //   546: iload #7
    //   548: ifeq -> 553
    //   551: fload_2
    //   552: freturn
    //   553: aload #13
    //   555: invokevirtual isEmpty : ()Z
    //   558: ifne -> 787
    //   561: aload #13
    //   563: invokevirtual size : ()I
    //   566: iconst_1
    //   567: if_icmpne -> 573
    //   570: fload #4
    //   572: freturn
    //   573: aload #13
    //   575: invokevirtual iterator : ()Ljava/util/Iterator;
    //   578: astore_0
    //   579: aload_0
    //   580: invokeinterface hasNext : ()Z
    //   585: ifeq -> 720
    //   588: aload_0
    //   589: invokeinterface next : ()Ljava/lang/Object;
    //   594: checkcast android/graphics/Rect
    //   597: astore_1
    //   598: aload #12
    //   600: invokevirtual clear : ()V
    //   603: aload #12
    //   605: aload #11
    //   607: invokevirtual addAll : (Ljava/util/Collection;)Z
    //   610: pop
    //   611: iconst_0
    //   612: istore #7
    //   614: iload #7
    //   616: aload #12
    //   618: invokevirtual size : ()I
    //   621: if_icmpge -> 579
    //   624: aload #12
    //   626: iload #7
    //   628: invokevirtual get : (I)Ljava/lang/Object;
    //   631: checkcast android/graphics/Rect
    //   634: astore #10
    //   636: aload_1
    //   637: aload #10
    //   639: invokevirtual intersect : (Landroid/graphics/Rect;)Z
    //   642: ifeq -> 711
    //   645: aload #11
    //   647: aload #12
    //   649: iload #7
    //   651: invokevirtual get : (I)Ljava/lang/Object;
    //   654: invokevirtual remove : (Ljava/lang/Object;)Z
    //   657: pop
    //   658: iconst_1
    //   659: istore #8
    //   661: iload #8
    //   663: bipush #9
    //   665: if_icmpge -> 711
    //   668: aload #10
    //   670: aload_1
    //   671: iload #8
    //   673: invokestatic e : (Landroid/graphics/Rect;Landroid/graphics/Rect;I)Landroid/graphics/Rect;
    //   676: astore #13
    //   678: aload #13
    //   680: invokevirtual height : ()I
    //   683: ifle -> 702
    //   686: aload #13
    //   688: invokevirtual width : ()I
    //   691: ifle -> 702
    //   694: aload #11
    //   696: aload #13
    //   698: invokevirtual add : (Ljava/lang/Object;)Z
    //   701: pop
    //   702: iload #8
    //   704: iconst_1
    //   705: iadd
    //   706: istore #8
    //   708: goto -> 661
    //   711: iload #7
    //   713: iconst_1
    //   714: iadd
    //   715: istore #7
    //   717: goto -> 614
    //   720: aload #11
    //   722: invokevirtual isEmpty : ()Z
    //   725: ifne -> 787
    //   728: aload #11
    //   730: invokevirtual iterator : ()Ljava/util/Iterator;
    //   733: astore_0
    //   734: fload #6
    //   736: fstore #5
    //   738: aload_0
    //   739: invokeinterface hasNext : ()Z
    //   744: ifeq -> 775
    //   747: aload_0
    //   748: invokeinterface next : ()Ljava/lang/Object;
    //   753: checkcast android/graphics/Rect
    //   756: astore_1
    //   757: fload #5
    //   759: aload_1
    //   760: invokevirtual width : ()I
    //   763: aload_1
    //   764: invokevirtual height : ()I
    //   767: imul
    //   768: i2f
    //   769: fadd
    //   770: fstore #5
    //   772: goto -> 738
    //   775: fload #5
    //   777: fload_2
    //   778: fcmpg
    //   779: ifge -> 787
    //   782: fload_2
    //   783: fload #5
    //   785: fsub
    //   786: freturn
    //   787: fload #4
    //   789: freturn
    //   790: astore_0
    //   791: goto -> 83
    //   794: astore #14
    //   796: goto -> 453
    // Exception table:
    //   from	to	target	type
    //   67	80	790	java/lang/Exception
    //   422	445	794	java/lang/Exception
  }
  
  private static int c() {
    return Build.VERSION.SDK_INT;
  }
  
  private static int d(Context paramContext) {
    byte b;
    if (paramContext != null) {
      b = (paramContext.getResources().getConfiguration()).orientation;
    } else {
      b = -1;
    } 
    if (b == 2) {
      int i = a;
      if (i > 0)
        return i; 
    } 
    if (b == 1) {
      int i = c;
      if (i > 0)
        return i; 
    } 
    try {
      int i;
      WindowManager windowManager = (WindowManager)paramContext.getApplicationContext().getSystemService("window");
      if (c() >= 13) {
        i = a.a(windowManager);
      } else {
        i = windowManager.getDefaultDisplay().getHeight();
      } 
      if (b == 2) {
        a = i;
        return i;
      } 
      if (b == 1)
        c = i; 
      return i;
    } catch (Exception exception) {
      return 0;
    } 
  }
  
  private static Rect e(Rect paramRect1, Rect paramRect2, int paramInt) {
    Rect rect = new Rect();
    switch (paramInt) {
      default:
        return rect;
      case 8:
        rect.set(paramRect1.left, paramRect2.top, paramRect2.left, paramRect2.bottom);
        return rect;
      case 7:
        rect.set(paramRect1.left, paramRect2.bottom, paramRect2.left, paramRect1.bottom);
        return rect;
      case 6:
        rect.set(paramRect2.left, paramRect2.bottom, paramRect2.right, paramRect1.bottom);
        return rect;
      case 5:
        rect.set(paramRect2.right, paramRect2.bottom, paramRect1.right, paramRect1.bottom);
        return rect;
      case 4:
        rect.set(paramRect2.right, paramRect2.top, paramRect1.right, paramRect2.bottom);
        return rect;
      case 3:
        rect.set(paramRect2.right, paramRect1.top, paramRect1.right, paramRect2.top);
        return rect;
      case 2:
        rect.set(paramRect2.left, paramRect1.top, paramRect2.right, paramRect2.top);
        return rect;
      case 1:
        break;
    } 
    rect.set(paramRect1.left, paramRect1.top, paramRect2.left, paramRect2.top);
    return rect;
  }
  
  private static ArrayList<View> f(View paramView) {
    if (!(paramView instanceof ViewGroup))
      return null; 
    if (paramView.getVisibility() == 0) {
      if (g(paramView) == 0.0F)
        return null; 
      LinkedList<ViewGroup> linkedList = new LinkedList();
      ArrayList<View> arrayList = new ArrayList();
      linkedList.add((ViewGroup)paramView);
      ListIterator<ViewGroup> listIterator = linkedList.listIterator();
      while (listIterator.hasNext()) {
        ViewGroup viewGroup = listIterator.next();
        listIterator.remove();
        int j = viewGroup.getChildCount();
        for (int i = 0; i < j; i++) {
          View view = viewGroup.getChildAt(i);
          if (view.getVisibility() == 0 && g(view) != 0.0F)
            if (view instanceof ViewGroup) {
              if (i(view)) {
                listIterator.add((ViewGroup)view);
                listIterator.previous();
              } else {
                arrayList.add(view);
              } 
            } else if (!i(view)) {
              arrayList.add(view);
            }  
        } 
      } 
      if (!arrayList.isEmpty())
        return arrayList; 
    } 
    return null;
  }
  
  private static float g(View paramView) {
    return (paramView == null) ? 0.0F : ((c() < 11) ? 1.0F : paramView.getAlpha());
  }
  
  private static int h(Context paramContext) {
    byte b;
    if (paramContext != null) {
      b = (paramContext.getResources().getConfiguration()).orientation;
    } else {
      b = -1;
    } 
    if (b == 2) {
      int i = b;
      if (i > 0)
        return i; 
    } 
    if (b == 1) {
      int i = d;
      if (i > 0)
        return i; 
    } 
    try {
      int i;
      WindowManager windowManager = (WindowManager)paramContext.getApplicationContext().getSystemService("window");
      if (c() >= 13) {
        i = b.a(windowManager);
      } else {
        i = windowManager.getDefaultDisplay().getWidth();
      } 
      if (b == 2) {
        b = i;
        return i;
      } 
      if (b == 1)
        d = i; 
      return i;
    } catch (Exception exception) {
      return 0;
    } 
  }
  
  private static boolean i(View paramView) {
    boolean bool = false;
    if (paramView == null)
      return false; 
    if (paramView.getBackground() != null) {
      boolean bool1 = bool;
      if (c() > 18) {
        bool1 = bool;
        if (paramView.getBackground().getAlpha() == 0)
          return true; 
      } 
      return bool1;
    } 
    return true;
  }
  
  private static class a {
    static int a(WindowManager param1WindowManager) {
      Point point = new Point();
      param1WindowManager.getDefaultDisplay().getSize(point);
      return point.y;
    }
  }
  
  private static class b {
    static int a(WindowManager param1WindowManager) {
      Point point = new Point();
      param1WindowManager.getDefaultDisplay().getSize(point);
      return point.x;
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Hill race-dex2jar.jar!\com\adcolony\sdk\i0.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */