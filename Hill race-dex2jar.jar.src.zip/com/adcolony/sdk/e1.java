package com.adcolony.sdk;

import android.os.Bundle;
import java.util.HashMap;

class e1 {
  private static int a;
  
  private static HashMap<String, Integer> b = new HashMap<String, Integer>();
  
  private static HashMap<String, Integer> c = new HashMap<String, Integer>();
  
  static boolean a(int paramInt, Bundle paramBundle) {
    int i = (int)(System.currentTimeMillis() / 1000L);
    if (paramInt != 0) {
      if (paramInt != 1)
        return false; 
      if (paramBundle == null)
        return false; 
      String str = paramBundle.getString("zone_id");
      if (b.get(str) == null)
        b.put(str, Integer.valueOf(i)); 
      if (c.get(str) == null)
        c.put(str, Integer.valueOf(0)); 
      if (i - ((Integer)b.get(str)).intValue() > 1) {
        c.put(str, Integer.valueOf(1));
        b.put(str, Integer.valueOf(i));
        return false;
      } 
      paramInt = ((Integer)c.get(str)).intValue() + 1;
      c.put(str, Integer.valueOf(paramInt));
      return (paramInt > 3);
    } 
    if (i - a < 5)
      return true; 
    a = i;
    return false;
  }
}


/* Location:              C:\soft\dex2jar-2.0\Hill race-dex2jar.jar!\com\adcolony\sdk\e1.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */