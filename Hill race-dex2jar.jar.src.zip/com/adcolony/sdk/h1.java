package com.adcolony.sdk;

import java.util.List;
import java.util.Map;
import java.util.concurrent.LinkedBlockingQueue;
import java.util.concurrent.RejectedExecutionException;
import java.util.concurrent.ThreadPoolExecutor;
import java.util.concurrent.TimeUnit;

class h1 implements f1.a {
  private LinkedBlockingQueue<Runnable> a = new LinkedBlockingQueue<Runnable>();
  
  private int b = 4;
  
  private int c = 16;
  
  private double d = 1.0D;
  
  private ThreadPoolExecutor e = new ThreadPoolExecutor(this.b, 2147483647, 60L, TimeUnit.SECONDS, this.a);
  
  private void f() {
    int i = this.e.getCorePoolSize();
    int j = this.a.size();
    int k = this.b;
    if (j * this.d > (i - k + 1) && i < this.c) {
      this.e.setCorePoolSize(i + 1);
      return;
    } 
    if (j == 0 && i > k)
      this.e.setCorePoolSize(k); 
  }
  
  public void a(f1 paramf1, j0 paramj0, Map<String, List<String>> paramMap) {
    e0 e0 = v.q();
    v.n(e0, "url", paramf1.m);
    v.w(e0, "success", paramf1.o);
    v.u(e0, "status", paramf1.q);
    v.n(e0, "body", paramf1.n);
    v.u(e0, "size", paramf1.p);
    if (paramMap != null) {
      e0 e01 = v.q();
      for (Map.Entry<String, List<String>> entry : paramMap.entrySet()) {
        String str = ((List)entry.getValue()).toString();
        str = str.substring(1, str.length() - 1);
        if (entry.getKey() != null)
          v.n(e01, (String)entry.getKey(), str); 
      } 
      v.m(e0, "headers", e01);
    } 
    paramj0.b(e0).e();
  }
  
  void b() {
    this.e.allowCoreThreadTimeOut(true);
    q.g("WebServices.download", new a(this));
    q.g("WebServices.get", new b(this));
    q.g("WebServices.post", new c(this));
  }
  
  void c(double paramDouble) {
    this.d = paramDouble;
  }
  
  void d(int paramInt) {
    this.b = paramInt;
    paramInt = this.e.getCorePoolSize();
    int i = this.b;
    if (paramInt < i)
      this.e.setCorePoolSize(i); 
  }
  
  void e(f1 paramf1) {
    f();
    try {
      this.e.execute(paramf1);
      return;
    } catch (RejectedExecutionException rejectedExecutionException) {
      b0.a a1 = (new b0.a()).c("RejectedExecutionException: ThreadPoolExecutor unable to ");
      StringBuilder stringBuilder = new StringBuilder();
      stringBuilder.append("execute download for url ");
      stringBuilder.append(paramf1.m);
      a1.c(stringBuilder.toString()).d(b0.i);
      a(paramf1, paramf1.c(), null);
      return;
    } 
  }
  
  void g(int paramInt) {
    this.c = paramInt;
    paramInt = this.e.getCorePoolSize();
    int i = this.c;
    if (paramInt > i)
      this.e.setCorePoolSize(i); 
  }
  
  void h(int paramInt) {
    this.e.setKeepAliveTime(paramInt, TimeUnit.SECONDS);
  }
  
  class a implements o0 {
    a(h1 this$0) {}
    
    public void a(j0 param1j0) {
      h1 h11 = this.a;
      h11.e(new f1(param1j0, h11));
    }
  }
  
  class b implements o0 {
    b(h1 this$0) {}
    
    public void a(j0 param1j0) {
      h1 h11 = this.a;
      h11.e(new f1(param1j0, h11));
    }
  }
  
  class c implements o0 {
    c(h1 this$0) {}
    
    public void a(j0 param1j0) {
      h1 h11 = this.a;
      h11.e(new f1(param1j0, h11));
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Hill race-dex2jar.jar!\com\adcolony\sdk\h1.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */