package com.adcolony.sdk;

import java.util.Date;

class t1 {
  private boolean a = true;
  
  private final Runnable b = new a(this);
  
  private Runnable c;
  
  private c d;
  
  private void b() {
    this.a = true;
    u1.K(this.b);
    u1.K(this.c);
    this.c = null;
  }
  
  private void g() {
    if (!q.k())
      return; 
    u1.c c1 = new u1.c(q.h().x0());
    b b = new b(this, c1);
    this.c = b;
    u1.r(b, c1.e());
  }
  
  void c(j0 paramj0) {
    if (q.k()) {
      if (this.a)
        return; 
      this.d = new c(paramj0.a(), null);
      Runnable runnable = this.c;
      if (runnable != null) {
        u1.K(runnable);
        u1.G(this.c);
        return;
      } 
      u1.K(this.b);
      u1.r(this.b, q.h().v0());
    } 
  }
  
  void f() {
    b();
    this.a = false;
    u1.r(this.b, q.h().v0());
  }
  
  class a implements Runnable {
    a(t1 this$0) {}
    
    public void run() {
      (new j0("AdColony.heartbeat", 1)).e();
      t1.d(this.b);
    }
  }
  
  class b implements Runnable {
    b(t1 this$0, u1.c param1c) {}
    
    public void run() {
      t1.a(this.c, null);
      if (!q.k())
        return; 
      p0 p0 = q.h();
      if (this.b.b() && p0.i()) {
        p0.w();
        b0.a a = (new b0.a()).c("Controller heartbeat timeout occurred. ");
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("Timeout set to: ");
        stringBuilder.append(this.b.c());
        stringBuilder.append(" ms. ");
        a = a.c(stringBuilder.toString());
        stringBuilder = new StringBuilder();
        stringBuilder.append("Interval set to: ");
        stringBuilder.append(p0.v0());
        stringBuilder.append(" ms. ");
        a.c(stringBuilder.toString()).c("Heartbeat last reply: ").b(t1.e(this.c)).d(b0.i);
        t1.h(this.c);
        return;
      } 
      if (p0.f()) {
        t1.h(this.c);
        return;
      } 
      u1.r(t1.i(this.c), p0.v0());
    }
  }
  
  private static class c {
    private final e0 a;
    
    private c(e0 param1e0) {
      if (param1e0 != null) {
        param1e0 = param1e0.H("payload");
      } else {
        param1e0 = v.q();
      } 
      this.a = param1e0;
      v.n(param1e0, "heartbeatLastTimestamp", d0.e.format(new Date()));
    }
    
    public String toString() {
      return this.a.toString();
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Hill race-dex2jar.jar!\com\adcolony\sdk\t1.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */