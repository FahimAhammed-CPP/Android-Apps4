package com.adcolony.sdk;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.concurrent.ScheduledExecutorService;
import java.util.concurrent.TimeUnit;
import org.json.JSONException;

class g1 {
  y a;
  
  ScheduledExecutorService b;
  
  List<d0> c;
  
  HashMap<String, Object> d;
  
  private s e;
  
  g1(y paramy, ScheduledExecutorService paramScheduledExecutorService, HashMap<String, Object> paramHashMap) {
    this.a = paramy;
    this.b = paramScheduledExecutorService;
    this.d = paramHashMap;
    this.c = new ArrayList<d0>();
    this.e = new s("adcolony_android", "4.8.0", "Production");
  }
  
  private e0 a(d0 paramd0) throws JSONException {
    // Byte code:
    //   0: aload_0
    //   1: monitorenter
    //   2: new com/adcolony/sdk/e0
    //   5: dup
    //   6: aload_0
    //   7: getfield d : Ljava/util/HashMap;
    //   10: invokespecial <init> : (Ljava/util/Map;)V
    //   13: astore_2
    //   14: aload_2
    //   15: ldc 'environment'
    //   17: aload_1
    //   18: invokevirtual b : ()Lcom/adcolony/sdk/s;
    //   21: invokevirtual a : ()Ljava/lang/String;
    //   24: invokevirtual f : (Ljava/lang/String;Ljava/lang/String;)Lcom/adcolony/sdk/e0;
    //   27: pop
    //   28: aload_2
    //   29: ldc 'level'
    //   31: aload_1
    //   32: invokevirtual f : ()Ljava/lang/String;
    //   35: invokevirtual f : (Ljava/lang/String;Ljava/lang/String;)Lcom/adcolony/sdk/e0;
    //   38: pop
    //   39: aload_2
    //   40: ldc 'message'
    //   42: aload_1
    //   43: invokevirtual g : ()Ljava/lang/String;
    //   46: invokevirtual f : (Ljava/lang/String;Ljava/lang/String;)Lcom/adcolony/sdk/e0;
    //   49: pop
    //   50: aload_2
    //   51: ldc 'clientTimestamp'
    //   53: aload_1
    //   54: invokevirtual h : ()Ljava/lang/String;
    //   57: invokevirtual f : (Ljava/lang/String;Ljava/lang/String;)Lcom/adcolony/sdk/e0;
    //   60: pop
    //   61: new com/adcolony/sdk/e0
    //   64: dup
    //   65: invokestatic h : ()Lcom/adcolony/sdk/p0;
    //   68: invokevirtual V0 : ()Lcom/adcolony/sdk/f;
    //   71: invokevirtual h : ()Lorg/json/JSONObject;
    //   74: invokespecial <init> : (Lorg/json/JSONObject;)V
    //   77: astore_1
    //   78: new com/adcolony/sdk/e0
    //   81: dup
    //   82: invokestatic h : ()Lcom/adcolony/sdk/p0;
    //   85: invokevirtual V0 : ()Lcom/adcolony/sdk/f;
    //   88: invokevirtual k : ()Lorg/json/JSONObject;
    //   91: invokespecial <init> : (Lorg/json/JSONObject;)V
    //   94: astore_3
    //   95: aload_2
    //   96: ldc 'mediation_network'
    //   98: aload_1
    //   99: ldc 'name'
    //   101: invokestatic E : (Lcom/adcolony/sdk/e0;Ljava/lang/String;)Ljava/lang/String;
    //   104: invokevirtual f : (Ljava/lang/String;Ljava/lang/String;)Lcom/adcolony/sdk/e0;
    //   107: pop
    //   108: aload_2
    //   109: ldc 'mediation_network_version'
    //   111: aload_1
    //   112: ldc 'version'
    //   114: invokestatic E : (Lcom/adcolony/sdk/e0;Ljava/lang/String;)Ljava/lang/String;
    //   117: invokevirtual f : (Ljava/lang/String;Ljava/lang/String;)Lcom/adcolony/sdk/e0;
    //   120: pop
    //   121: aload_2
    //   122: ldc 'plugin'
    //   124: aload_3
    //   125: ldc 'name'
    //   127: invokestatic E : (Lcom/adcolony/sdk/e0;Ljava/lang/String;)Ljava/lang/String;
    //   130: invokevirtual f : (Ljava/lang/String;Ljava/lang/String;)Lcom/adcolony/sdk/e0;
    //   133: pop
    //   134: aload_2
    //   135: ldc 'plugin_version'
    //   137: aload_3
    //   138: ldc 'version'
    //   140: invokestatic E : (Lcom/adcolony/sdk/e0;Ljava/lang/String;)Ljava/lang/String;
    //   143: invokevirtual f : (Ljava/lang/String;Ljava/lang/String;)Lcom/adcolony/sdk/e0;
    //   146: pop
    //   147: invokestatic h : ()Lcom/adcolony/sdk/p0;
    //   150: invokevirtual N0 : ()Lcom/adcolony/sdk/h0;
    //   153: invokevirtual l : ()Lcom/adcolony/sdk/c0;
    //   156: astore_1
    //   157: aload_1
    //   158: ifnull -> 170
    //   161: aload_1
    //   162: ldc 'batteryInfo'
    //   164: invokevirtual d : (Ljava/lang/String;)Z
    //   167: ifeq -> 186
    //   170: aload_2
    //   171: ldc 'batteryInfo'
    //   173: invokestatic h : ()Lcom/adcolony/sdk/p0;
    //   176: invokevirtual H0 : ()Lcom/adcolony/sdk/b1;
    //   179: invokevirtual R : ()D
    //   182: invokevirtual n : (Ljava/lang/String;D)Lcom/adcolony/sdk/e0;
    //   185: pop
    //   186: aload_1
    //   187: ifnull -> 195
    //   190: aload_2
    //   191: aload_1
    //   192: invokevirtual h : (Lcom/adcolony/sdk/c0;)V
    //   195: aload_0
    //   196: monitorexit
    //   197: aload_2
    //   198: areturn
    //   199: astore_1
    //   200: aload_0
    //   201: monitorexit
    //   202: aload_1
    //   203: athrow
    // Exception table:
    //   from	to	target	type
    //   2	157	199	finally
    //   161	170	199	finally
    //   170	186	199	finally
    //   190	195	199	finally
  }
  
  String b(s params, List<d0> paramList) throws JSONException {
    e0 e0 = new e0();
    e0.f("index", params.b());
    e0.f("environment", params.a());
    e0.f("version", params.c());
    c0 c0 = new c0();
    Iterator<d0> iterator = paramList.iterator();
    while (iterator.hasNext())
      c0.a(a(iterator.next())); 
    e0.d("logs", c0);
    return e0.toString();
  }
  
  void c() {
    // Byte code:
    //   0: aload_0
    //   1: monitorenter
    //   2: aload_0
    //   3: getfield c : Ljava/util/List;
    //   6: invokeinterface size : ()I
    //   11: ifle -> 73
    //   14: aload_0
    //   15: aload_0
    //   16: getfield e : Lcom/adcolony/sdk/s;
    //   19: aload_0
    //   20: getfield c : Ljava/util/List;
    //   23: invokevirtual b : (Lcom/adcolony/sdk/s;Ljava/util/List;)Ljava/lang/String;
    //   26: astore_1
    //   27: aload_0
    //   28: getfield a : Lcom/adcolony/sdk/y;
    //   31: aload_1
    //   32: invokevirtual a : (Ljava/lang/String;)I
    //   35: pop
    //   36: aload_0
    //   37: getfield c : Ljava/util/List;
    //   40: invokeinterface clear : ()V
    //   45: goto -> 73
    //   48: astore_1
    //   49: goto -> 76
    //   52: aload_0
    //   53: getfield c : Ljava/util/List;
    //   56: invokeinterface clear : ()V
    //   61: goto -> 73
    //   64: aload_0
    //   65: getfield c : Ljava/util/List;
    //   68: invokeinterface clear : ()V
    //   73: aload_0
    //   74: monitorexit
    //   75: return
    //   76: aload_0
    //   77: monitorexit
    //   78: aload_1
    //   79: athrow
    //   80: astore_1
    //   81: goto -> 64
    //   84: astore_1
    //   85: goto -> 52
    // Exception table:
    //   from	to	target	type
    //   2	45	80	java/io/IOException
    //   2	45	84	org/json/JSONException
    //   2	45	48	finally
    //   52	61	48	finally
    //   64	73	48	finally
    //   73	75	48	finally
    //   76	78	48	finally
  }
  
  void d(long paramLong, TimeUnit paramTimeUnit) {
    // Byte code:
    //   0: aload_0
    //   1: monitorenter
    //   2: aload_0
    //   3: getfield b : Ljava/util/concurrent/ScheduledExecutorService;
    //   6: invokeinterface isShutdown : ()Z
    //   11: ifne -> 62
    //   14: aload_0
    //   15: getfield b : Ljava/util/concurrent/ScheduledExecutorService;
    //   18: invokeinterface isTerminated : ()Z
    //   23: ifne -> 62
    //   26: aload_0
    //   27: getfield b : Ljava/util/concurrent/ScheduledExecutorService;
    //   30: new com/adcolony/sdk/g1$a
    //   33: dup
    //   34: aload_0
    //   35: invokespecial <init> : (Lcom/adcolony/sdk/g1;)V
    //   38: lload_1
    //   39: lload_1
    //   40: aload_3
    //   41: invokeinterface scheduleAtFixedRate : (Ljava/lang/Runnable;JJLjava/util/concurrent/TimeUnit;)Ljava/util/concurrent/ScheduledFuture;
    //   46: pop
    //   47: goto -> 62
    //   50: astore_3
    //   51: goto -> 65
    //   54: ldc 'ADCLogError'
    //   56: ldc 'Internal error when submitting remote log to executor service'
    //   58: invokestatic e : (Ljava/lang/String;Ljava/lang/String;)I
    //   61: pop
    //   62: aload_0
    //   63: monitorexit
    //   64: return
    //   65: aload_0
    //   66: monitorexit
    //   67: aload_3
    //   68: athrow
    //   69: astore_3
    //   70: goto -> 54
    // Exception table:
    //   from	to	target	type
    //   2	47	69	java/lang/RuntimeException
    //   2	47	50	finally
    //   54	62	50	finally
  }
  
  void e(String paramString) {
    // Byte code:
    //   0: aload_0
    //   1: monitorenter
    //   2: aload_0
    //   3: new com/adcolony/sdk/d0$a
    //   6: dup
    //   7: invokespecial <init> : ()V
    //   10: iconst_3
    //   11: invokevirtual a : (I)Lcom/adcolony/sdk/d0$a;
    //   14: aload_0
    //   15: getfield e : Lcom/adcolony/sdk/s;
    //   18: invokevirtual b : (Lcom/adcolony/sdk/s;)Lcom/adcolony/sdk/d0$a;
    //   21: aload_1
    //   22: invokevirtual c : (Ljava/lang/String;)Lcom/adcolony/sdk/d0$a;
    //   25: invokevirtual d : ()Lcom/adcolony/sdk/d0;
    //   28: invokevirtual g : (Lcom/adcolony/sdk/d0;)V
    //   31: aload_0
    //   32: monitorexit
    //   33: return
    //   34: astore_1
    //   35: aload_0
    //   36: monitorexit
    //   37: aload_1
    //   38: athrow
    // Exception table:
    //   from	to	target	type
    //   2	31	34	finally
  }
  
  void f() {
    // Byte code:
    //   0: aload_0
    //   1: monitorenter
    //   2: aload_0
    //   3: getfield b : Ljava/util/concurrent/ScheduledExecutorService;
    //   6: invokeinterface shutdown : ()V
    //   11: aload_0
    //   12: getfield b : Ljava/util/concurrent/ScheduledExecutorService;
    //   15: astore_1
    //   16: getstatic java/util/concurrent/TimeUnit.SECONDS : Ljava/util/concurrent/TimeUnit;
    //   19: astore_2
    //   20: aload_1
    //   21: lconst_1
    //   22: aload_2
    //   23: invokeinterface awaitTermination : (JLjava/util/concurrent/TimeUnit;)Z
    //   28: ifne -> 112
    //   31: aload_0
    //   32: getfield b : Ljava/util/concurrent/ScheduledExecutorService;
    //   35: invokeinterface shutdownNow : ()Ljava/util/List;
    //   40: pop
    //   41: aload_0
    //   42: getfield b : Ljava/util/concurrent/ScheduledExecutorService;
    //   45: lconst_1
    //   46: aload_2
    //   47: invokeinterface awaitTermination : (JLjava/util/concurrent/TimeUnit;)Z
    //   52: ifne -> 112
    //   55: getstatic java/lang/System.err : Ljava/io/PrintStream;
    //   58: astore_1
    //   59: new java/lang/StringBuilder
    //   62: dup
    //   63: invokespecial <init> : ()V
    //   66: astore_2
    //   67: aload_2
    //   68: ldc com/adcolony/sdk/g1
    //   70: invokevirtual getSimpleName : ()Ljava/lang/String;
    //   73: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   76: pop
    //   77: aload_2
    //   78: ldc_w ': ScheduledExecutorService did not terminate'
    //   81: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   84: pop
    //   85: aload_1
    //   86: aload_2
    //   87: invokevirtual toString : ()Ljava/lang/String;
    //   90: invokevirtual println : (Ljava/lang/String;)V
    //   93: goto -> 112
    //   96: aload_0
    //   97: getfield b : Ljava/util/concurrent/ScheduledExecutorService;
    //   100: invokeinterface shutdownNow : ()Ljava/util/List;
    //   105: pop
    //   106: invokestatic currentThread : ()Ljava/lang/Thread;
    //   109: invokevirtual interrupt : ()V
    //   112: aload_0
    //   113: monitorexit
    //   114: return
    //   115: astore_1
    //   116: aload_0
    //   117: monitorexit
    //   118: aload_1
    //   119: athrow
    //   120: astore_1
    //   121: goto -> 96
    // Exception table:
    //   from	to	target	type
    //   2	11	115	finally
    //   11	93	120	java/lang/InterruptedException
    //   11	93	115	finally
    //   96	112	115	finally
  }
  
  void g(d0 paramd0) {
    // Byte code:
    //   0: aload_0
    //   1: monitorenter
    //   2: aload_0
    //   3: getfield b : Ljava/util/concurrent/ScheduledExecutorService;
    //   6: invokeinterface isShutdown : ()Z
    //   11: ifne -> 60
    //   14: aload_0
    //   15: getfield b : Ljava/util/concurrent/ScheduledExecutorService;
    //   18: invokeinterface isTerminated : ()Z
    //   23: ifne -> 60
    //   26: aload_0
    //   27: getfield b : Ljava/util/concurrent/ScheduledExecutorService;
    //   30: new com/adcolony/sdk/g1$b
    //   33: dup
    //   34: aload_0
    //   35: aload_1
    //   36: invokespecial <init> : (Lcom/adcolony/sdk/g1;Lcom/adcolony/sdk/d0;)V
    //   39: invokeinterface submit : (Ljava/lang/Runnable;)Ljava/util/concurrent/Future;
    //   44: pop
    //   45: goto -> 60
    //   48: astore_1
    //   49: goto -> 63
    //   52: ldc 'ADCLogError'
    //   54: ldc 'Internal error when submitting remote log to executor service'
    //   56: invokestatic e : (Ljava/lang/String;Ljava/lang/String;)I
    //   59: pop
    //   60: aload_0
    //   61: monitorexit
    //   62: return
    //   63: aload_0
    //   64: monitorexit
    //   65: aload_1
    //   66: athrow
    //   67: astore_1
    //   68: goto -> 52
    // Exception table:
    //   from	to	target	type
    //   2	45	67	java/util/concurrent/RejectedExecutionException
    //   2	45	48	finally
    //   52	60	48	finally
  }
  
  void h(String paramString) {
    // Byte code:
    //   0: aload_0
    //   1: monitorenter
    //   2: aload_0
    //   3: new com/adcolony/sdk/d0$a
    //   6: dup
    //   7: invokespecial <init> : ()V
    //   10: iconst_0
    //   11: invokevirtual a : (I)Lcom/adcolony/sdk/d0$a;
    //   14: aload_0
    //   15: getfield e : Lcom/adcolony/sdk/s;
    //   18: invokevirtual b : (Lcom/adcolony/sdk/s;)Lcom/adcolony/sdk/d0$a;
    //   21: aload_1
    //   22: invokevirtual c : (Ljava/lang/String;)Lcom/adcolony/sdk/d0$a;
    //   25: invokevirtual d : ()Lcom/adcolony/sdk/d0;
    //   28: invokevirtual g : (Lcom/adcolony/sdk/d0;)V
    //   31: aload_0
    //   32: monitorexit
    //   33: return
    //   34: astore_1
    //   35: aload_0
    //   36: monitorexit
    //   37: aload_1
    //   38: athrow
    // Exception table:
    //   from	to	target	type
    //   2	31	34	finally
  }
  
  void i(String paramString) {
    // Byte code:
    //   0: aload_0
    //   1: monitorenter
    //   2: aload_0
    //   3: new com/adcolony/sdk/d0$a
    //   6: dup
    //   7: invokespecial <init> : ()V
    //   10: iconst_2
    //   11: invokevirtual a : (I)Lcom/adcolony/sdk/d0$a;
    //   14: aload_0
    //   15: getfield e : Lcom/adcolony/sdk/s;
    //   18: invokevirtual b : (Lcom/adcolony/sdk/s;)Lcom/adcolony/sdk/d0$a;
    //   21: aload_1
    //   22: invokevirtual c : (Ljava/lang/String;)Lcom/adcolony/sdk/d0$a;
    //   25: invokevirtual d : ()Lcom/adcolony/sdk/d0;
    //   28: invokevirtual g : (Lcom/adcolony/sdk/d0;)V
    //   31: aload_0
    //   32: monitorexit
    //   33: return
    //   34: astore_1
    //   35: aload_0
    //   36: monitorexit
    //   37: aload_1
    //   38: athrow
    // Exception table:
    //   from	to	target	type
    //   2	31	34	finally
  }
  
  void j(String paramString) {
    // Byte code:
    //   0: aload_0
    //   1: monitorenter
    //   2: aload_0
    //   3: new com/adcolony/sdk/d0$a
    //   6: dup
    //   7: invokespecial <init> : ()V
    //   10: iconst_1
    //   11: invokevirtual a : (I)Lcom/adcolony/sdk/d0$a;
    //   14: aload_0
    //   15: getfield e : Lcom/adcolony/sdk/s;
    //   18: invokevirtual b : (Lcom/adcolony/sdk/s;)Lcom/adcolony/sdk/d0$a;
    //   21: aload_1
    //   22: invokevirtual c : (Ljava/lang/String;)Lcom/adcolony/sdk/d0$a;
    //   25: invokevirtual d : ()Lcom/adcolony/sdk/d0;
    //   28: invokevirtual g : (Lcom/adcolony/sdk/d0;)V
    //   31: aload_0
    //   32: monitorexit
    //   33: return
    //   34: astore_1
    //   35: aload_0
    //   36: monitorexit
    //   37: aload_1
    //   38: athrow
    // Exception table:
    //   from	to	target	type
    //   2	31	34	finally
  }
  
  void k(String paramString) {
    // Byte code:
    //   0: aload_0
    //   1: monitorenter
    //   2: aload_0
    //   3: getfield d : Ljava/util/HashMap;
    //   6: ldc_w 'controllerVersion'
    //   9: aload_1
    //   10: invokevirtual put : (Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    //   13: pop
    //   14: aload_0
    //   15: monitorexit
    //   16: return
    //   17: astore_1
    //   18: aload_0
    //   19: monitorexit
    //   20: aload_1
    //   21: athrow
    // Exception table:
    //   from	to	target	type
    //   2	14	17	finally
  }
  
  void l(String paramString) {
    // Byte code:
    //   0: aload_0
    //   1: monitorenter
    //   2: aload_0
    //   3: getfield d : Ljava/util/HashMap;
    //   6: ldc_w 'sessionId'
    //   9: aload_1
    //   10: invokevirtual put : (Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    //   13: pop
    //   14: aload_0
    //   15: monitorexit
    //   16: return
    //   17: astore_1
    //   18: aload_0
    //   19: monitorexit
    //   20: aload_1
    //   21: athrow
    // Exception table:
    //   from	to	target	type
    //   2	14	17	finally
  }
  
  class a implements Runnable {
    a(g1 this$0) {}
    
    public void run() {
      this.b.c();
    }
  }
  
  class b implements Runnable {
    b(g1 this$0, d0 param1d0) {}
    
    public void run() {
      this.c.c.add(this.b);
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Hill race-dex2jar.jar!\com\adcolony\sdk\g1.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */