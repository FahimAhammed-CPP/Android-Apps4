package com.apm.insight.a;

import com.apm.insight.CrashType;
import com.apm.insight.ICrashCallback;
import com.apm.insight.runtime.p;

public class a implements ICrashCallback {
  private static volatile a d;
  
  private volatile String a;
  
  private volatile b b;
  
  private volatile c c;
  
  private volatile boolean e = false;
  
  public static a a() {
    // Byte code:
    //   0: getstatic com/apm/insight/a/a.d : Lcom/apm/insight/a/a;
    //   3: ifnonnull -> 37
    //   6: ldc com/apm/insight/a/a
    //   8: monitorenter
    //   9: getstatic com/apm/insight/a/a.d : Lcom/apm/insight/a/a;
    //   12: ifnonnull -> 25
    //   15: new com/apm/insight/a/a
    //   18: dup
    //   19: invokespecial <init> : ()V
    //   22: putstatic com/apm/insight/a/a.d : Lcom/apm/insight/a/a;
    //   25: ldc com/apm/insight/a/a
    //   27: monitorexit
    //   28: goto -> 37
    //   31: astore_0
    //   32: ldc com/apm/insight/a/a
    //   34: monitorexit
    //   35: aload_0
    //   36: athrow
    //   37: getstatic com/apm/insight/a/a.d : Lcom/apm/insight/a/a;
    //   40: areturn
    // Exception table:
    //   from	to	target	type
    //   9	25	31	finally
    //   25	28	31	finally
    //   32	35	31	finally
  }
  
  public void a(CrashType paramCrashType, long paramLong, String paramString) {}
  
  public void a(String paramString) {}
  
  public void a(String paramString, b paramb, c paramc) {
    this.a = paramString;
    this.b = paramb;
    this.c = paramc;
    if (!this.e) {
      this.e = true;
      p.b().a(new Runnable(this) {
            public void run() {}
          });
    } 
  }
  
  public void b() {}
  
  public void onCrash(CrashType paramCrashType, String paramString, Thread paramThread) {
    paramCrashType.equals(CrashType.NATIVE);
  }
}


/* Location:              C:\soft\dex2jar-2.0\Hill race-dex2jar.jar!\com\apm\insight\a\a.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */