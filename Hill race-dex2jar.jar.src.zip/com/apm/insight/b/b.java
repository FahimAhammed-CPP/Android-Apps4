package com.apm.insight.b;

import android.content.Context;
import android.os.Build;
import android.os.SystemClock;
import com.apm.insight.CrashType;
import com.apm.insight.ICrashCallback;
import com.apm.insight.Npth;
import com.apm.insight.c;
import com.apm.insight.i;
import com.apm.insight.k.d;
import com.apm.insight.l.a;
import com.apm.insight.l.f;
import com.apm.insight.l.i;
import com.apm.insight.l.l;
import com.apm.insight.l.o;
import com.apm.insight.nativecrash.NativeImpl;
import com.apm.insight.runtime.a;
import com.apm.insight.runtime.o;
import com.apm.insight.runtime.r;
import java.io.File;
import java.io.IOException;
import java.util.Date;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.regex.Pattern;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

public class b {
  static volatile boolean a = true;
  
  private static volatile boolean f;
  
  private long A = 0L;
  
  private final Runnable B = new Runnable(this) {
      public void run() {
        try {
          return;
        } finally {
          Exception exception = null;
          c.a().a("NPTH_CATCH", exception);
        } 
      }
    };
  
  private int C = 0;
  
  private List<Pattern> D = null;
  
  private File E = null;
  
  Pattern b = null;
  
  private c c;
  
  private final Context d;
  
  private volatile boolean e;
  
  private long g = -1L;
  
  private File h = null;
  
  private boolean i = true;
  
  private JSONObject j;
  
  private JSONObject k;
  
  private String l = "unknown";
  
  private String m = "unknown";
  
  private String n = "unknown";
  
  private String o = "npth_inner_default";
  
  private JSONArray p;
  
  private JSONObject q;
  
  private int r = 0;
  
  private long s = -1L;
  
  private JSONArray t;
  
  private JSONArray u;
  
  private JSONObject v;
  
  private boolean w;
  
  private final Object x = new Object();
  
  private volatile boolean y;
  
  private long z = -1L;
  
  public b(Context paramContext) {
    this.d = paramContext;
  }
  
  private static String a(float paramFloat) {
    return (paramFloat <= 0.0F) ? "0%" : ((paramFloat <= 0.1F) ? "0% - 10%" : ((paramFloat <= 0.3F) ? "10% - 30%" : ((paramFloat <= 0.6F) ? "30% - 60%" : ((paramFloat <= 0.9F) ? "60% - 90%" : "90% - 100%"))));
  }
  
  private static String a(float paramFloat1, float paramFloat2) {
    return (paramFloat2 > 0.0F) ? a(paramFloat1 / paramFloat2) : ((paramFloat1 > 0.0F) ? "100%" : "0%");
  }
  
  private JSONObject a(String paramString, JSONArray paramJSONArray) {
    JSONObject jSONObject = new JSONObject();
    JSONArray jSONArray = l.a(256, 128, paramJSONArray);
    if (jSONArray.length() != paramJSONArray.length())
      this.r++; 
    try {
      jSONObject.put("thread_name", paramString);
      jSONObject.put("thread_stack", jSONArray);
      return jSONObject;
    } catch (JSONException jSONException) {
      return null;
    } 
  }
  
  private void a(String paramString, JSONObject paramJSONObject) {
    // Byte code:
    //   0: invokestatic uptimeMillis : ()J
    //   3: pop2
    //   4: aload_1
    //   5: ldc '\\n'
    //   7: invokevirtual split : (Ljava/lang/String;)[Ljava/lang/String;
    //   10: astore #21
    //   12: iconst_3
    //   13: newarray float
    //   15: astore #24
    //   17: aload #24
    //   19: dup
    //   20: iconst_0
    //   21: ldc -1.0
    //   23: fastore
    //   24: dup
    //   25: iconst_1
    //   26: ldc -1.0
    //   28: fastore
    //   29: dup
    //   30: iconst_2
    //   31: ldc -1.0
    //   33: fastore
    //   34: pop
    //   35: new java/util/HashMap
    //   38: dup
    //   39: invokespecial <init> : ()V
    //   42: astore #22
    //   44: new java/util/HashMap
    //   47: dup
    //   48: invokespecial <init> : ()V
    //   51: astore #23
    //   53: new java/util/HashMap
    //   56: dup
    //   57: invokespecial <init> : ()V
    //   60: astore_1
    //   61: new java/util/HashMap
    //   64: dup
    //   65: invokespecial <init> : ()V
    //   68: astore #17
    //   70: new java/util/HashMap
    //   73: dup
    //   74: invokespecial <init> : ()V
    //   77: astore #11
    //   79: aload #21
    //   81: arraylength
    //   82: istore #6
    //   84: ldc 'unknown'
    //   86: astore #18
    //   88: ldc 'unknown'
    //   90: astore #12
    //   92: aload #12
    //   94: astore #13
    //   96: iconst_0
    //   97: istore #7
    //   99: iconst_0
    //   100: istore #5
    //   102: iconst_0
    //   103: istore #9
    //   105: iload #7
    //   107: iload #6
    //   109: if_icmpge -> 1735
    //   112: aload #21
    //   114: iload #7
    //   116: aaload
    //   117: astore #16
    //   119: aload #16
    //   121: invokestatic isEmpty : (Ljava/lang/CharSequence;)Z
    //   124: ifeq -> 149
    //   127: aload #12
    //   129: astore #16
    //   131: aload #13
    //   133: astore #19
    //   135: iload #9
    //   137: istore #10
    //   139: aload_1
    //   140: astore #15
    //   142: aload #11
    //   144: astore #14
    //   146: goto -> 1707
    //   149: iload #5
    //   151: ifeq -> 1597
    //   154: iload #5
    //   156: iconst_1
    //   157: if_icmpeq -> 1200
    //   160: iload #5
    //   162: iconst_2
    //   163: if_icmpeq -> 1193
    //   166: iload #5
    //   168: iconst_3
    //   169: if_icmpeq -> 185
    //   172: aload #12
    //   174: astore #15
    //   176: aload_1
    //   177: astore #16
    //   179: aload #11
    //   181: astore_1
    //   182: goto -> 1541
    //   185: aload #16
    //   187: ldc '\s'
    //   189: invokevirtual split : (Ljava/lang/String;)[Ljava/lang/String;
    //   192: astore #25
    //   194: aload #25
    //   196: arraylength
    //   197: iconst_2
    //   198: if_icmpge -> 218
    //   201: aload #11
    //   203: astore #19
    //   205: aload #12
    //   207: astore #15
    //   209: aload_1
    //   210: astore #16
    //   212: aload #19
    //   214: astore_1
    //   215: goto -> 1541
    //   218: ldc 'CPU'
    //   220: aload #25
    //   222: iconst_0
    //   223: aaload
    //   224: invokevirtual equalsIgnoreCase : (Ljava/lang/String;)Z
    //   227: ifeq -> 334
    //   230: ldc 'usage'
    //   232: aload #25
    //   234: iconst_1
    //   235: aaload
    //   236: invokevirtual equalsIgnoreCase : (Ljava/lang/String;)Z
    //   239: ifeq -> 334
    //   242: aload #16
    //   244: ldc 'ago'
    //   246: invokevirtual contains : (Ljava/lang/CharSequence;)Z
    //   249: ifeq -> 255
    //   252: iconst_1
    //   253: istore #9
    //   255: iload #9
    //   257: istore #10
    //   259: aload #22
    //   261: invokevirtual isEmpty : ()Z
    //   264: ifeq -> 324
    //   267: iload #9
    //   269: istore #10
    //   271: aload #23
    //   273: invokevirtual isEmpty : ()Z
    //   276: ifeq -> 324
    //   279: iload #9
    //   281: istore #10
    //   283: aload_1
    //   284: invokevirtual isEmpty : ()Z
    //   287: ifeq -> 324
    //   290: iload #9
    //   292: istore #10
    //   294: aload #11
    //   296: invokevirtual isEmpty : ()Z
    //   299: ifeq -> 324
    //   302: aload #17
    //   304: invokevirtual isEmpty : ()Z
    //   307: ifne -> 317
    //   310: iload #9
    //   312: istore #10
    //   314: goto -> 324
    //   317: iload #5
    //   319: istore #4
    //   321: goto -> 1675
    //   324: iconst_4
    //   325: istore #4
    //   327: iload #10
    //   329: istore #9
    //   331: goto -> 1675
    //   334: aload #22
    //   336: invokevirtual isEmpty : ()Z
    //   339: ifne -> 380
    //   342: aload #23
    //   344: invokevirtual isEmpty : ()Z
    //   347: ifne -> 380
    //   350: aload_1
    //   351: invokevirtual isEmpty : ()Z
    //   354: ifne -> 380
    //   357: aload #11
    //   359: invokevirtual isEmpty : ()Z
    //   362: ifne -> 380
    //   365: aload #17
    //   367: invokevirtual isEmpty : ()Z
    //   370: ifne -> 380
    //   373: iload #9
    //   375: istore #10
    //   377: goto -> 324
    //   380: aload #22
    //   382: invokevirtual isEmpty : ()Z
    //   385: ifeq -> 414
    //   388: aload #25
    //   390: iconst_1
    //   391: aaload
    //   392: ldc 'TOTAL:'
    //   394: invokevirtual equalsIgnoreCase : (Ljava/lang/String;)Z
    //   397: ifeq -> 414
    //   400: ldc ''
    //   402: astore #15
    //   404: aload #22
    //   406: astore #14
    //   408: aload_1
    //   409: astore #16
    //   411: goto -> 649
    //   414: aload #16
    //   416: aload_0
    //   417: getfield d : Landroid/content/Context;
    //   420: invokevirtual getPackageName : ()Ljava/lang/String;
    //   423: invokevirtual contains : (Ljava/lang/CharSequence;)Z
    //   426: ifeq -> 543
    //   429: ldc ''
    //   431: astore #15
    //   433: iconst_0
    //   434: istore #4
    //   436: iload #4
    //   438: aload #25
    //   440: arraylength
    //   441: if_icmpge -> 534
    //   444: aload #25
    //   446: iload #4
    //   448: aaload
    //   449: aload_0
    //   450: getfield d : Landroid/content/Context;
    //   453: invokevirtual getPackageName : ()Ljava/lang/String;
    //   456: invokevirtual contains : (Ljava/lang/CharSequence;)Z
    //   459: ifeq -> 525
    //   462: new java/lang/StringBuilder
    //   465: dup
    //   466: invokespecial <init> : ()V
    //   469: astore #14
    //   471: aload #14
    //   473: aload #25
    //   475: iload #4
    //   477: aaload
    //   478: aload #25
    //   480: iload #4
    //   482: aaload
    //   483: bipush #47
    //   485: invokevirtual indexOf : (I)I
    //   488: iconst_1
    //   489: iadd
    //   490: aload #25
    //   492: iload #4
    //   494: aaload
    //   495: invokevirtual length : ()I
    //   498: iconst_1
    //   499: isub
    //   500: invokevirtual substring : (II)Ljava/lang/String;
    //   503: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   506: pop
    //   507: aload #14
    //   509: bipush #95
    //   511: invokevirtual append : (C)Ljava/lang/StringBuilder;
    //   514: pop
    //   515: aload #14
    //   517: invokevirtual toString : ()Ljava/lang/String;
    //   520: astore #15
    //   522: goto -> 525
    //   525: iload #4
    //   527: iconst_1
    //   528: iadd
    //   529: istore #4
    //   531: goto -> 436
    //   534: aload_1
    //   535: astore #14
    //   537: aload_1
    //   538: astore #16
    //   540: goto -> 649
    //   543: aload #23
    //   545: invokevirtual isEmpty : ()Z
    //   548: ifeq -> 575
    //   551: aload #16
    //   553: ldc 'system_server:'
    //   555: invokevirtual contains : (Ljava/lang/CharSequence;)Z
    //   558: ifeq -> 575
    //   561: ldc ''
    //   563: astore #15
    //   565: aload #23
    //   567: astore #14
    //   569: aload_1
    //   570: astore #16
    //   572: goto -> 649
    //   575: aload #11
    //   577: invokevirtual isEmpty : ()Z
    //   580: ifeq -> 607
    //   583: aload #16
    //   585: ldc 'kswapd'
    //   587: invokevirtual contains : (Ljava/lang/CharSequence;)Z
    //   590: ifeq -> 607
    //   593: ldc ''
    //   595: astore #15
    //   597: aload #11
    //   599: astore #14
    //   601: aload_1
    //   602: astore #16
    //   604: goto -> 649
    //   607: aload #17
    //   609: invokevirtual isEmpty : ()Z
    //   612: ifeq -> 639
    //   615: aload #16
    //   617: ldc 'dex2oat'
    //   619: invokevirtual contains : (Ljava/lang/CharSequence;)Z
    //   622: ifeq -> 639
    //   625: ldc ''
    //   627: astore #15
    //   629: aload #17
    //   631: astore #14
    //   633: aload_1
    //   634: astore #16
    //   636: goto -> 649
    //   639: ldc ''
    //   641: astore #15
    //   643: aconst_null
    //   644: astore #14
    //   646: aload_1
    //   647: astore #16
    //   649: aload #16
    //   651: astore_1
    //   652: aload #14
    //   654: ifnull -> 201
    //   657: iconst_0
    //   658: istore #4
    //   660: aload #25
    //   662: iload #4
    //   664: aaload
    //   665: astore_1
    //   666: ldc '%'
    //   668: astore #20
    //   670: iload #4
    //   672: istore #8
    //   674: aload_1
    //   675: ldc '%'
    //   677: invokevirtual contains : (Ljava/lang/CharSequence;)Z
    //   680: ifne -> 701
    //   683: iload #4
    //   685: iconst_1
    //   686: iadd
    //   687: istore #8
    //   689: iload #8
    //   691: istore #4
    //   693: iload #8
    //   695: aload #25
    //   697: arraylength
    //   698: if_icmplt -> 660
    //   701: aload #25
    //   703: iload #8
    //   705: aaload
    //   706: ldc '%'
    //   708: ldc ''
    //   710: invokevirtual replace : (Ljava/lang/CharSequence;Ljava/lang/CharSequence;)Ljava/lang/String;
    //   713: invokestatic valueOf : (Ljava/lang/String;)Ljava/lang/Float;
    //   716: invokevirtual floatValue : ()F
    //   719: fstore_3
    //   720: new java/lang/StringBuilder
    //   723: dup
    //   724: invokespecial <init> : ()V
    //   727: astore_1
    //   728: aload_1
    //   729: aload #15
    //   731: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   734: pop
    //   735: aload_1
    //   736: ldc 'total'
    //   738: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   741: pop
    //   742: aload_1
    //   743: invokevirtual toString : ()Ljava/lang/String;
    //   746: astore_1
    //   747: aload #14
    //   749: aload #22
    //   751: if_acmpne -> 757
    //   754: goto -> 764
    //   757: fload_3
    //   758: invokestatic e : ()I
    //   761: i2f
    //   762: fdiv
    //   763: fstore_3
    //   764: aload #14
    //   766: aload_1
    //   767: fload_3
    //   768: invokestatic valueOf : (F)Ljava/lang/Float;
    //   771: invokevirtual put : (Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    //   774: pop
    //   775: goto -> 815
    //   778: new java/lang/StringBuilder
    //   781: dup
    //   782: invokespecial <init> : ()V
    //   785: astore_1
    //   786: aload_1
    //   787: aload #15
    //   789: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   792: pop
    //   793: aload_1
    //   794: ldc 'total'
    //   796: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   799: pop
    //   800: aload #14
    //   802: aload_1
    //   803: invokevirtual toString : ()Ljava/lang/String;
    //   806: ldc -1.0
    //   808: invokestatic valueOf : (F)Ljava/lang/Float;
    //   811: invokevirtual put : (Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    //   814: pop
    //   815: iload #8
    //   817: iconst_3
    //   818: iadd
    //   819: istore #8
    //   821: iconst_0
    //   822: istore #4
    //   824: aload #11
    //   826: astore #19
    //   828: aload #16
    //   830: astore_1
    //   831: iload #8
    //   833: aload #25
    //   835: arraylength
    //   836: if_icmpge -> 205
    //   839: ldc_w 'kernel'
    //   842: astore_1
    //   843: iload #4
    //   845: ifeq -> 893
    //   848: iload #4
    //   850: iconst_1
    //   851: if_icmpeq -> 890
    //   854: iload #4
    //   856: iconst_2
    //   857: if_icmpeq -> 887
    //   860: iload #4
    //   862: iconst_3
    //   863: if_icmpeq -> 884
    //   866: iload #4
    //   868: iconst_4
    //   869: if_icmpeq -> 881
    //   872: iload #4
    //   874: iconst_5
    //   875: if_icmpeq -> 1009
    //   878: goto -> 1034
    //   881: goto -> 985
    //   884: goto -> 961
    //   887: goto -> 937
    //   890: goto -> 917
    //   893: ldc_w 'user'
    //   896: aload #25
    //   898: iload #8
    //   900: aaload
    //   901: invokevirtual equalsIgnoreCase : (Ljava/lang/String;)Z
    //   904: ifeq -> 917
    //   907: ldc_w 'user'
    //   910: astore_1
    //   911: iconst_1
    //   912: istore #4
    //   914: goto -> 1036
    //   917: ldc_w 'kernel'
    //   920: aload #25
    //   922: iload #8
    //   924: aaload
    //   925: invokevirtual equalsIgnoreCase : (Ljava/lang/String;)Z
    //   928: ifeq -> 937
    //   931: iconst_2
    //   932: istore #4
    //   934: goto -> 1036
    //   937: ldc_w 'iowait'
    //   940: aload #25
    //   942: iload #8
    //   944: aaload
    //   945: invokevirtual equalsIgnoreCase : (Ljava/lang/String;)Z
    //   948: ifeq -> 961
    //   951: ldc_w 'iowait'
    //   954: astore_1
    //   955: iconst_3
    //   956: istore #4
    //   958: goto -> 1036
    //   961: ldc_w 'irq'
    //   964: aload #25
    //   966: iload #8
    //   968: aaload
    //   969: invokevirtual equalsIgnoreCase : (Ljava/lang/String;)Z
    //   972: ifeq -> 985
    //   975: ldc_w 'irq'
    //   978: astore_1
    //   979: iconst_4
    //   980: istore #4
    //   982: goto -> 1036
    //   985: ldc_w 'softirq'
    //   988: aload #25
    //   990: iload #8
    //   992: aaload
    //   993: invokevirtual equalsIgnoreCase : (Ljava/lang/String;)Z
    //   996: ifeq -> 1009
    //   999: ldc_w 'softirq'
    //   1002: astore_1
    //   1003: iconst_5
    //   1004: istore #4
    //   1006: goto -> 1036
    //   1009: ldc_w 'softirq'
    //   1012: aload #25
    //   1014: iload #8
    //   1016: aaload
    //   1017: invokevirtual equalsIgnoreCase : (Ljava/lang/String;)Z
    //   1020: ifeq -> 1034
    //   1023: bipush #6
    //   1025: istore #4
    //   1027: ldc_w 'softirq'
    //   1030: astore_1
    //   1031: goto -> 1036
    //   1034: aconst_null
    //   1035: astore_1
    //   1036: aload_1
    //   1037: ifnull -> 1167
    //   1040: aload #25
    //   1042: iload #8
    //   1044: iconst_1
    //   1045: isub
    //   1046: aaload
    //   1047: aload #20
    //   1049: ldc ''
    //   1051: invokevirtual replace : (Ljava/lang/CharSequence;Ljava/lang/CharSequence;)Ljava/lang/String;
    //   1054: invokestatic valueOf : (Ljava/lang/String;)Ljava/lang/Float;
    //   1057: invokevirtual floatValue : ()F
    //   1060: fstore_3
    //   1061: new java/lang/StringBuilder
    //   1064: dup
    //   1065: invokespecial <init> : ()V
    //   1068: astore #19
    //   1070: aload #19
    //   1072: aload #15
    //   1074: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   1077: pop
    //   1078: aload #19
    //   1080: aload_1
    //   1081: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   1084: pop
    //   1085: aload #19
    //   1087: invokevirtual toString : ()Ljava/lang/String;
    //   1090: astore #19
    //   1092: aload #14
    //   1094: aload #22
    //   1096: if_acmpne -> 1102
    //   1099: goto -> 1109
    //   1102: fload_3
    //   1103: invokestatic e : ()I
    //   1106: i2f
    //   1107: fdiv
    //   1108: fstore_3
    //   1109: aload #14
    //   1111: aload #19
    //   1113: fload_3
    //   1114: invokestatic valueOf : (F)Ljava/lang/Float;
    //   1117: invokevirtual put : (Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    //   1120: pop
    //   1121: goto -> 1167
    //   1124: new java/lang/StringBuilder
    //   1127: dup
    //   1128: invokespecial <init> : ()V
    //   1131: astore #19
    //   1133: aload #19
    //   1135: aload #15
    //   1137: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   1140: pop
    //   1141: aload #19
    //   1143: aload_1
    //   1144: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   1147: pop
    //   1148: aload #14
    //   1150: aload #19
    //   1152: invokevirtual toString : ()Ljava/lang/String;
    //   1155: ldc -1.0
    //   1157: invokestatic valueOf : (F)Ljava/lang/Float;
    //   1160: invokevirtual put : (Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    //   1163: pop
    //   1164: goto -> 1167
    //   1167: iload #4
    //   1169: bipush #6
    //   1171: if_icmplt -> 1184
    //   1174: aload #12
    //   1176: astore #15
    //   1178: aload #11
    //   1180: astore_1
    //   1181: goto -> 1541
    //   1184: iload #8
    //   1186: iconst_3
    //   1187: iadd
    //   1188: istore #8
    //   1190: goto -> 824
    //   1193: aload #13
    //   1195: astore #14
    //   1197: goto -> 1432
    //   1200: aload_1
    //   1201: astore #20
    //   1203: aload #11
    //   1205: astore #19
    //   1207: aload #16
    //   1209: invokevirtual trim : ()Ljava/lang/String;
    //   1212: astore #16
    //   1214: aload #16
    //   1216: invokevirtual toLowerCase : ()Ljava/lang/String;
    //   1219: astore #25
    //   1221: aload #25
    //   1223: ldc_w 'shortmsg'
    //   1226: invokevirtual startsWith : (Ljava/lang/String;)Z
    //   1229: ifeq -> 1251
    //   1232: aload #16
    //   1234: aload #16
    //   1236: bipush #58
    //   1238: invokevirtual indexOf : (I)I
    //   1241: invokevirtual substring : (I)Ljava/lang/String;
    //   1244: pop
    //   1245: iconst_0
    //   1246: istore #4
    //   1248: goto -> 1278
    //   1251: aload #25
    //   1253: ldc_w 'reason:'
    //   1256: invokevirtual startsWith : (Ljava/lang/String;)Z
    //   1259: ifeq -> 1552
    //   1262: aload #16
    //   1264: aload #16
    //   1266: bipush #58
    //   1268: invokevirtual indexOf : (I)I
    //   1271: invokevirtual substring : (I)Ljava/lang/String;
    //   1274: pop
    //   1275: iconst_1
    //   1276: istore #4
    //   1278: aload #25
    //   1280: ldc_w 'input dispatch'
    //   1283: invokevirtual contains : (Ljava/lang/CharSequence;)Z
    //   1286: ifeq -> 1301
    //   1289: ldc_w 'Input dispatching timed out'
    //   1292: astore #13
    //   1294: aload #12
    //   1296: astore #15
    //   1298: goto -> 1402
    //   1301: aload #25
    //   1303: ldc_w 'broadcast of intent'
    //   1306: invokevirtual contains : (Ljava/lang/CharSequence;)Z
    //   1309: ifeq -> 1320
    //   1312: ldc_w 'Broadcast of Intent'
    //   1315: astore #13
    //   1317: goto -> 1294
    //   1320: aload #25
    //   1322: ldc_w 'executing service'
    //   1325: invokevirtual contains : (Ljava/lang/CharSequence;)Z
    //   1328: ifeq -> 1375
    //   1331: aload #12
    //   1333: astore #15
    //   1335: ldc_w 'null'
    //   1338: aload #12
    //   1340: invokevirtual equalsIgnoreCase : (Ljava/lang/String;)Z
    //   1343: ifeq -> 1367
    //   1346: aload #16
    //   1348: aload #16
    //   1350: ldc_w 'service '
    //   1353: invokevirtual indexOf : (Ljava/lang/String;)I
    //   1356: bipush #8
    //   1358: iadd
    //   1359: invokevirtual substring : (I)Ljava/lang/String;
    //   1362: invokevirtual trim : ()Ljava/lang/String;
    //   1365: astore #15
    //   1367: ldc_w 'executing service'
    //   1370: astore #13
    //   1372: goto -> 1402
    //   1375: aload #25
    //   1377: ldc_w 'service.startforeground'
    //   1380: invokevirtual contains : (Ljava/lang/CharSequence;)Z
    //   1383: ifeq -> 1394
    //   1386: ldc_w 'not call Service.startForeground'
    //   1389: astore #13
    //   1391: goto -> 1294
    //   1394: aload #18
    //   1396: astore #13
    //   1398: aload #12
    //   1400: astore #15
    //   1402: aload #15
    //   1404: astore #12
    //   1406: aload #13
    //   1408: astore #14
    //   1410: iload #4
    //   1412: ifeq -> 1432
    //   1415: iconst_2
    //   1416: istore #4
    //   1418: aload #15
    //   1420: astore #12
    //   1422: aload #20
    //   1424: astore_1
    //   1425: aload #19
    //   1427: astore #11
    //   1429: goto -> 1675
    //   1432: aload_1
    //   1433: astore #19
    //   1435: aload #16
    //   1437: invokevirtual trim : ()Ljava/lang/String;
    //   1440: astore #20
    //   1442: aload #12
    //   1444: astore #15
    //   1446: aload #14
    //   1448: astore #13
    //   1450: aload #19
    //   1452: astore #16
    //   1454: aload #11
    //   1456: astore_1
    //   1457: aload #20
    //   1459: ldc_w 'Load:'
    //   1462: invokevirtual startsWith : (Ljava/lang/String;)Z
    //   1465: ifeq -> 1541
    //   1468: aload #20
    //   1470: ldc_w 'Load:'
    //   1473: ldc ''
    //   1475: invokevirtual replace : (Ljava/lang/CharSequence;Ljava/lang/CharSequence;)Ljava/lang/String;
    //   1478: invokevirtual trim : ()Ljava/lang/String;
    //   1481: ldc_w '/'
    //   1484: invokevirtual split : (Ljava/lang/String;)[Ljava/lang/String;
    //   1487: astore_1
    //   1488: iconst_3
    //   1489: aload_1
    //   1490: arraylength
    //   1491: if_icmpne -> 1528
    //   1494: iconst_0
    //   1495: istore #4
    //   1497: iload #4
    //   1499: aload_1
    //   1500: arraylength
    //   1501: if_icmpge -> 1528
    //   1504: aload #24
    //   1506: iload #4
    //   1508: aload_1
    //   1509: iload #4
    //   1511: aaload
    //   1512: invokestatic valueOf : (Ljava/lang/String;)Ljava/lang/Float;
    //   1515: invokevirtual floatValue : ()F
    //   1518: fastore
    //   1519: iload #4
    //   1521: iconst_1
    //   1522: iadd
    //   1523: istore #4
    //   1525: goto -> 1497
    //   1528: iconst_3
    //   1529: istore #4
    //   1531: aload #14
    //   1533: astore #13
    //   1535: aload #19
    //   1537: astore_1
    //   1538: goto -> 1675
    //   1541: aload #15
    //   1543: astore #14
    //   1545: aload #13
    //   1547: astore #15
    //   1549: goto -> 1657
    //   1552: aload #12
    //   1554: astore #14
    //   1556: aload #13
    //   1558: astore #15
    //   1560: aload #20
    //   1562: astore #16
    //   1564: aload #19
    //   1566: astore_1
    //   1567: aload #25
    //   1569: ldc_w 'appfreeze'
    //   1572: invokevirtual contains : (Ljava/lang/CharSequence;)Z
    //   1575: ifeq -> 1657
    //   1578: ldc_w 'AppFreeze'
    //   1581: astore #13
    //   1583: bipush #10
    //   1585: istore #4
    //   1587: aload #20
    //   1589: astore_1
    //   1590: aload #19
    //   1592: astore #11
    //   1594: goto -> 1675
    //   1597: aload_1
    //   1598: astore #19
    //   1600: aload #16
    //   1602: invokevirtual trim : ()Ljava/lang/String;
    //   1605: astore #20
    //   1607: aload #12
    //   1609: astore #14
    //   1611: aload #13
    //   1613: astore #15
    //   1615: aload #19
    //   1617: astore #16
    //   1619: aload #11
    //   1621: astore_1
    //   1622: aload #20
    //   1624: ldc_w 'tag:'
    //   1627: invokevirtual startsWith : (Ljava/lang/String;)Z
    //   1630: ifeq -> 1657
    //   1633: aload #20
    //   1635: ldc_w 'tag:'
    //   1638: ldc ''
    //   1640: invokevirtual replace : (Ljava/lang/CharSequence;Ljava/lang/CharSequence;)Ljava/lang/String;
    //   1643: invokevirtual trim : ()Ljava/lang/String;
    //   1646: astore #12
    //   1648: iconst_1
    //   1649: istore #4
    //   1651: aload #19
    //   1653: astore_1
    //   1654: goto -> 1675
    //   1657: iload #5
    //   1659: istore #4
    //   1661: aload_1
    //   1662: astore #11
    //   1664: aload #16
    //   1666: astore_1
    //   1667: aload #15
    //   1669: astore #13
    //   1671: aload #14
    //   1673: astore #12
    //   1675: iload #4
    //   1677: istore #5
    //   1679: aload #12
    //   1681: astore #16
    //   1683: aload #13
    //   1685: astore #19
    //   1687: iload #9
    //   1689: istore #10
    //   1691: aload_1
    //   1692: astore #15
    //   1694: aload #11
    //   1696: astore #14
    //   1698: iload #4
    //   1700: iconst_4
    //   1701: if_icmplt -> 1707
    //   1704: goto -> 1735
    //   1707: iload #7
    //   1709: iconst_1
    //   1710: iadd
    //   1711: istore #7
    //   1713: aload #15
    //   1715: astore_1
    //   1716: aload #14
    //   1718: astore #11
    //   1720: aload #16
    //   1722: astore #12
    //   1724: aload #19
    //   1726: astore #13
    //   1728: iload #10
    //   1730: istore #9
    //   1732: goto -> 105
    //   1735: aload_2
    //   1736: ldc_w 'anr_tag'
    //   1739: aload #12
    //   1741: invokevirtual put : (Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;
    //   1744: pop
    //   1745: aload_2
    //   1746: ldc_w 'anr_has_ago'
    //   1749: iload #9
    //   1751: invokestatic valueOf : (Z)Ljava/lang/String;
    //   1754: invokevirtual put : (Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;
    //   1757: pop
    //   1758: aload_2
    //   1759: ldc_w 'anr_reason'
    //   1762: aload #13
    //   1764: invokevirtual put : (Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;
    //   1767: pop
    //   1768: aload_1
    //   1769: aload_2
    //   1770: ldc_w 'app'
    //   1773: invokestatic a : (Ljava/util/HashMap;Lorg/json/JSONObject;Ljava/lang/String;)V
    //   1776: aload #22
    //   1778: aload_2
    //   1779: ldc 'total'
    //   1781: invokestatic a : (Ljava/util/HashMap;Lorg/json/JSONObject;Ljava/lang/String;)V
    //   1784: aload #23
    //   1786: invokevirtual isEmpty : ()Z
    //   1789: ifeq -> 1806
    //   1792: aload_2
    //   1793: ldc_w 'npth_anr_systemserver_total'
    //   1796: ldc_w 'not found'
    //   1799: invokevirtual put : (Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;
    //   1802: pop
    //   1803: goto -> 1825
    //   1806: aload_2
    //   1807: ldc_w 'npth_anr_systemserver_total'
    //   1810: aload #23
    //   1812: invokestatic a : (Ljava/util/Map;)Ljava/lang/Float;
    //   1815: invokevirtual floatValue : ()F
    //   1818: invokestatic b : (F)Ljava/lang/String;
    //   1821: invokevirtual put : (Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;
    //   1824: pop
    //   1825: aload #11
    //   1827: invokevirtual isEmpty : ()Z
    //   1830: ifeq -> 1847
    //   1833: aload_2
    //   1834: ldc_w 'npth_anr_kswapd_total'
    //   1837: ldc_w 'not found'
    //   1840: invokevirtual put : (Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;
    //   1843: pop
    //   1844: goto -> 1866
    //   1847: aload_2
    //   1848: ldc_w 'npth_anr_kswapd_total'
    //   1851: aload #11
    //   1853: invokestatic a : (Ljava/util/Map;)Ljava/lang/Float;
    //   1856: invokevirtual floatValue : ()F
    //   1859: invokestatic b : (F)Ljava/lang/String;
    //   1862: invokevirtual put : (Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;
    //   1865: pop
    //   1866: aload #17
    //   1868: invokevirtual isEmpty : ()Z
    //   1871: ifeq -> 1886
    //   1874: aload_2
    //   1875: ldc_w 'npth_anr_dex2oat_total'
    //   1878: ldc_w 'not found'
    //   1881: invokevirtual put : (Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;
    //   1884: pop
    //   1885: return
    //   1886: aload_2
    //   1887: ldc_w 'npth_anr_dex2oat_total'
    //   1890: aload #17
    //   1892: invokestatic a : (Ljava/util/Map;)Ljava/lang/Float;
    //   1895: invokevirtual floatValue : ()F
    //   1898: invokestatic b : (F)Ljava/lang/String;
    //   1901: invokevirtual put : (Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;
    //   1904: pop
    //   1905: return
    //   1906: astore_1
    //   1907: goto -> 778
    //   1910: astore_1
    //   1911: goto -> 778
    //   1914: astore #19
    //   1916: goto -> 1124
    //   1919: astore #19
    //   1921: goto -> 1124
    // Exception table:
    //   from	to	target	type
    //   701	747	1906	finally
    //   757	764	1910	finally
    //   764	775	1910	finally
    //   1040	1092	1914	finally
    //   1102	1109	1919	finally
    //   1109	1121	1919	finally
  }
  
  private static void a(HashMap<String, Float> paramHashMap, JSONObject paramJSONObject, String paramString) {
    String str;
    StringBuilder stringBuilder = new StringBuilder();
    stringBuilder.append("npth_anr_");
    stringBuilder.append(paramString);
    paramString = stringBuilder.toString();
    if (paramHashMap.isEmpty()) {
      StringBuilder stringBuilder1 = new StringBuilder();
      stringBuilder1.append(paramString);
      stringBuilder1.append("_total");
      str = stringBuilder1.toString();
      paramString = "not found";
    } else {
      Iterator<Map.Entry> iterator = str.entrySet().iterator();
      float f5 = 0.0F;
      float f4 = 0.0F;
      float f2 = 0.0F;
      float f3 = 0.0F;
      float f1 = 0.0F;
      while (iterator.hasNext()) {
        Map.Entry entry = iterator.next();
        String str1 = (String)entry.getKey();
        if (str1.endsWith("user")) {
          f5 += ((Float)entry.getValue()).floatValue();
          continue;
        } 
        if (str1.endsWith("kernel")) {
          f4 += ((Float)entry.getValue()).floatValue();
          continue;
        } 
        if (str1.endsWith("iowait")) {
          f2 += ((Float)entry.getValue()).floatValue();
          continue;
        } 
        if (str1.endsWith("irq")) {
          f3 += ((Float)entry.getValue()).floatValue();
          continue;
        } 
        if (str1.endsWith("softirq"))
          f1 += ((Float)entry.getValue()).floatValue(); 
      } 
      f1 = f5 + f4 + f2 + f3 + f1;
      StringBuilder stringBuilder1 = new StringBuilder();
      stringBuilder1.append(paramString);
      stringBuilder1.append("_total");
      paramJSONObject.put(stringBuilder1.toString(), b(f1));
      stringBuilder1 = new StringBuilder();
      stringBuilder1.append(paramString);
      stringBuilder1.append("_kernel_user_ratio");
      paramJSONObject.put(stringBuilder1.toString(), a(f4, f1));
      stringBuilder1 = new StringBuilder();
      stringBuilder1.append(paramString);
      stringBuilder1.append("_iowait_user_ratio");
      str = stringBuilder1.toString();
      paramString = a(f2, f1);
    } 
    paramJSONObject.put(str, paramString);
  }
  
  private void a(JSONArray paramJSONArray) {
    // Byte code:
    //   0: aload_1
    //   1: ifnonnull -> 5
    //   4: return
    //   5: aload_0
    //   6: aconst_null
    //   7: putfield j : Lorg/json/JSONObject;
    //   10: aload_0
    //   11: aconst_null
    //   12: putfield q : Lorg/json/JSONObject;
    //   15: aload_0
    //   16: iconst_0
    //   17: putfield r : I
    //   20: new org/json/JSONArray
    //   23: dup
    //   24: invokespecial <init> : ()V
    //   27: astore #8
    //   29: new org/json/JSONArray
    //   32: dup
    //   33: invokespecial <init> : ()V
    //   36: astore #9
    //   38: new org/json/JSONArray
    //   41: dup
    //   42: invokespecial <init> : ()V
    //   45: astore #5
    //   47: aload_0
    //   48: ldc 'unknown'
    //   50: putfield l : Ljava/lang/String;
    //   53: aload_0
    //   54: ldc 'unknown'
    //   56: putfield m : Ljava/lang/String;
    //   59: aload_0
    //   60: ldc 'unknown'
    //   62: putfield n : Ljava/lang/String;
    //   65: iconst_3
    //   66: newarray int
    //   68: astore #10
    //   70: aload #10
    //   72: dup
    //   73: iconst_0
    //   74: iconst_0
    //   75: iastore
    //   76: dup
    //   77: iconst_1
    //   78: iconst_0
    //   79: iastore
    //   80: dup
    //   81: iconst_2
    //   82: iconst_0
    //   83: iastore
    //   84: pop
    //   85: aconst_null
    //   86: astore #4
    //   88: iconst_0
    //   89: istore_3
    //   90: iconst_0
    //   91: istore_2
    //   92: iload_3
    //   93: aload_1
    //   94: invokevirtual length : ()I
    //   97: if_icmpge -> 805
    //   100: aload_1
    //   101: iload_3
    //   102: invokevirtual optString : (I)Ljava/lang/String;
    //   105: astore #11
    //   107: aload #11
    //   109: invokestatic isEmpty : (Ljava/lang/CharSequence;)Z
    //   112: ifeq -> 359
    //   115: aload #5
    //   117: invokevirtual length : ()I
    //   120: ifle -> 328
    //   123: aload #4
    //   125: invokestatic isEmpty : (Ljava/lang/CharSequence;)Z
    //   128: ifne -> 328
    //   131: aload_0
    //   132: getfield j : Lorg/json/JSONObject;
    //   135: ifnonnull -> 162
    //   138: ldc_w 'main'
    //   141: aload #4
    //   143: invokevirtual equals : (Ljava/lang/Object;)Z
    //   146: ifeq -> 162
    //   149: aload_0
    //   150: aload_0
    //   151: aload #5
    //   153: invokespecial c : (Lorg/json/JSONArray;)Lorg/json/JSONObject;
    //   156: putfield j : Lorg/json/JSONObject;
    //   159: goto -> 176
    //   162: aload #8
    //   164: aload_0
    //   165: aload #4
    //   167: aload #5
    //   169: invokespecial a : (Ljava/lang/String;Lorg/json/JSONArray;)Lorg/json/JSONObject;
    //   172: invokevirtual put : (Ljava/lang/Object;)Lorg/json/JSONArray;
    //   175: pop
    //   176: aload #4
    //   178: astore #6
    //   180: ldc_w 'main'
    //   183: aload #4
    //   185: invokevirtual equals : (Ljava/lang/Object;)Z
    //   188: ifne -> 209
    //   191: aload #4
    //   193: iconst_0
    //   194: aload #4
    //   196: bipush #40
    //   198: invokevirtual indexOf : (I)I
    //   201: invokevirtual substring : (II)Ljava/lang/String;
    //   204: invokevirtual trim : ()Ljava/lang/String;
    //   207: astore #6
    //   209: aload_0
    //   210: aload #6
    //   212: invokespecial a : (Ljava/lang/String;)Z
    //   215: ifne -> 328
    //   218: aload_0
    //   219: aload #5
    //   221: invokespecial b : (Lorg/json/JSONArray;)[I
    //   224: astore #4
    //   226: goto -> 245
    //   229: astore #4
    //   231: invokestatic a : ()Lcom/apm/insight/d;
    //   234: ldc_w 'NPTH_CATCH'
    //   237: aload #4
    //   239: invokevirtual a : (Ljava/lang/String;Ljava/lang/Throwable;)V
    //   242: aconst_null
    //   243: astore #4
    //   245: aload #4
    //   247: ifnonnull -> 253
    //   250: goto -> 328
    //   253: aload #4
    //   255: iconst_0
    //   256: iaload
    //   257: aload #10
    //   259: iconst_0
    //   260: iaload
    //   261: if_icmple -> 278
    //   264: aload #10
    //   266: iconst_0
    //   267: aload #4
    //   269: iconst_0
    //   270: iaload
    //   271: iastore
    //   272: aload_0
    //   273: aload #6
    //   275: putfield l : Ljava/lang/String;
    //   278: aload #4
    //   280: iconst_1
    //   281: iaload
    //   282: aload #10
    //   284: iconst_1
    //   285: iaload
    //   286: if_icmple -> 303
    //   289: aload #10
    //   291: iconst_1
    //   292: aload #4
    //   294: iconst_1
    //   295: iaload
    //   296: iastore
    //   297: aload_0
    //   298: aload #6
    //   300: putfield m : Ljava/lang/String;
    //   303: aload #4
    //   305: iconst_2
    //   306: iaload
    //   307: aload #10
    //   309: iconst_2
    //   310: iaload
    //   311: if_icmple -> 328
    //   314: aload #10
    //   316: iconst_2
    //   317: aload #4
    //   319: iconst_2
    //   320: iaload
    //   321: iastore
    //   322: aload_0
    //   323: aload #6
    //   325: putfield n : Ljava/lang/String;
    //   328: aload #5
    //   330: astore #6
    //   332: aload #5
    //   334: invokevirtual length : ()I
    //   337: ifle -> 349
    //   340: new org/json/JSONArray
    //   343: dup
    //   344: invokespecial <init> : ()V
    //   347: astore #6
    //   349: aconst_null
    //   350: astore #4
    //   352: aload #6
    //   354: astore #5
    //   356: goto -> 798
    //   359: iload_2
    //   360: ifeq -> 755
    //   363: iload_2
    //   364: iconst_1
    //   365: if_icmpeq -> 371
    //   368: goto -> 798
    //   371: aload #11
    //   373: ldc_w ' prio='
    //   376: invokevirtual contains : (Ljava/lang/CharSequence;)Z
    //   379: ifeq -> 736
    //   382: aload #5
    //   384: invokevirtual length : ()I
    //   387: ifle -> 595
    //   390: aload #4
    //   392: invokestatic isEmpty : (Ljava/lang/CharSequence;)Z
    //   395: ifne -> 595
    //   398: aload_0
    //   399: getfield j : Lorg/json/JSONObject;
    //   402: ifnonnull -> 429
    //   405: ldc_w 'main'
    //   408: aload #4
    //   410: invokevirtual equals : (Ljava/lang/Object;)Z
    //   413: ifeq -> 429
    //   416: aload_0
    //   417: aload_0
    //   418: aload #5
    //   420: invokespecial c : (Lorg/json/JSONArray;)Lorg/json/JSONObject;
    //   423: putfield j : Lorg/json/JSONObject;
    //   426: goto -> 443
    //   429: aload #8
    //   431: aload_0
    //   432: aload #4
    //   434: aload #5
    //   436: invokespecial a : (Ljava/lang/String;Lorg/json/JSONArray;)Lorg/json/JSONObject;
    //   439: invokevirtual put : (Ljava/lang/Object;)Lorg/json/JSONArray;
    //   442: pop
    //   443: aload #4
    //   445: astore #6
    //   447: ldc_w 'main'
    //   450: aload #4
    //   452: invokevirtual equals : (Ljava/lang/Object;)Z
    //   455: ifne -> 476
    //   458: aload #4
    //   460: iconst_0
    //   461: aload #4
    //   463: bipush #40
    //   465: invokevirtual indexOf : (I)I
    //   468: invokevirtual substring : (II)Ljava/lang/String;
    //   471: invokevirtual trim : ()Ljava/lang/String;
    //   474: astore #6
    //   476: aload_0
    //   477: aload #6
    //   479: invokespecial a : (Ljava/lang/String;)Z
    //   482: ifne -> 595
    //   485: aload_0
    //   486: aload #5
    //   488: invokespecial b : (Lorg/json/JSONArray;)[I
    //   491: astore #4
    //   493: goto -> 512
    //   496: astore #4
    //   498: invokestatic a : ()Lcom/apm/insight/d;
    //   501: ldc_w 'NPTH_CATCH'
    //   504: aload #4
    //   506: invokevirtual a : (Ljava/lang/String;Ljava/lang/Throwable;)V
    //   509: aconst_null
    //   510: astore #4
    //   512: aload #4
    //   514: ifnonnull -> 520
    //   517: goto -> 595
    //   520: aload #4
    //   522: iconst_0
    //   523: iaload
    //   524: aload #10
    //   526: iconst_0
    //   527: iaload
    //   528: if_icmple -> 545
    //   531: aload #10
    //   533: iconst_0
    //   534: aload #4
    //   536: iconst_0
    //   537: iaload
    //   538: iastore
    //   539: aload_0
    //   540: aload #6
    //   542: putfield l : Ljava/lang/String;
    //   545: aload #4
    //   547: iconst_1
    //   548: iaload
    //   549: aload #10
    //   551: iconst_1
    //   552: iaload
    //   553: if_icmple -> 570
    //   556: aload #10
    //   558: iconst_1
    //   559: aload #4
    //   561: iconst_1
    //   562: iaload
    //   563: iastore
    //   564: aload_0
    //   565: aload #6
    //   567: putfield m : Ljava/lang/String;
    //   570: aload #4
    //   572: iconst_2
    //   573: iaload
    //   574: aload #10
    //   576: iconst_2
    //   577: iaload
    //   578: if_icmple -> 595
    //   581: aload #10
    //   583: iconst_2
    //   584: aload #4
    //   586: iconst_2
    //   587: iaload
    //   588: iastore
    //   589: aload_0
    //   590: aload #6
    //   592: putfield n : Ljava/lang/String;
    //   595: aload #11
    //   597: iconst_1
    //   598: aload #11
    //   600: bipush #34
    //   602: iconst_1
    //   603: invokevirtual indexOf : (II)I
    //   606: invokevirtual substring : (II)Ljava/lang/String;
    //   609: astore #4
    //   611: ldc_w 'main'
    //   614: aload #4
    //   616: invokevirtual equals : (Ljava/lang/Object;)Z
    //   619: ifne -> 688
    //   622: new java/lang/StringBuilder
    //   625: dup
    //   626: invokespecial <init> : ()V
    //   629: astore #6
    //   631: aload #6
    //   633: aload #4
    //   635: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   638: pop
    //   639: aload #6
    //   641: ldc_w '  ('
    //   644: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   647: pop
    //   648: aload #6
    //   650: aload #11
    //   652: aload #11
    //   654: bipush #34
    //   656: iconst_2
    //   657: invokevirtual indexOf : (II)I
    //   660: iconst_1
    //   661: iadd
    //   662: invokevirtual substring : (I)Ljava/lang/String;
    //   665: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   668: pop
    //   669: aload #6
    //   671: ldc_w ' )'
    //   674: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   677: pop
    //   678: aload #6
    //   680: invokevirtual toString : ()Ljava/lang/String;
    //   683: astore #4
    //   685: goto -> 688
    //   688: aload #4
    //   690: astore #7
    //   692: aload #5
    //   694: astore #6
    //   696: aload #5
    //   698: invokevirtual length : ()I
    //   701: ifle -> 717
    //   704: new org/json/JSONArray
    //   707: dup
    //   708: invokespecial <init> : ()V
    //   711: astore #6
    //   713: aload #4
    //   715: astore #7
    //   717: aload #6
    //   719: aload #11
    //   721: invokevirtual put : (Ljava/lang/Object;)Lorg/json/JSONArray;
    //   724: pop
    //   725: aload #7
    //   727: astore #4
    //   729: aload #6
    //   731: astore #5
    //   733: goto -> 798
    //   736: aload #4
    //   738: astore #7
    //   740: aload #5
    //   742: astore #6
    //   744: aload #4
    //   746: invokestatic isEmpty : (Ljava/lang/CharSequence;)Z
    //   749: ifeq -> 717
    //   752: goto -> 790
    //   755: aload #11
    //   757: ldc_w 'DALVIK THREADS'
    //   760: invokevirtual startsWith : (Ljava/lang/String;)Z
    //   763: ifne -> 788
    //   766: aload #11
    //   768: ldc_w 'suspend'
    //   771: invokevirtual startsWith : (Ljava/lang/String;)Z
    //   774: ifne -> 788
    //   777: aload #11
    //   779: ldc_w '"'
    //   782: invokevirtual startsWith : (Ljava/lang/String;)Z
    //   785: ifeq -> 790
    //   788: iconst_1
    //   789: istore_2
    //   790: aload #9
    //   792: aload #11
    //   794: invokevirtual put : (Ljava/lang/Object;)Lorg/json/JSONArray;
    //   797: pop
    //   798: iload_3
    //   799: iconst_1
    //   800: iadd
    //   801: istore_3
    //   802: goto -> 92
    //   805: aload #8
    //   807: invokevirtual length : ()I
    //   810: ifle -> 864
    //   813: aload_0
    //   814: aload #9
    //   816: putfield p : Lorg/json/JSONArray;
    //   819: new org/json/JSONObject
    //   822: dup
    //   823: invokespecial <init> : ()V
    //   826: astore_1
    //   827: aload_0
    //   828: aload_1
    //   829: putfield q : Lorg/json/JSONObject;
    //   832: aload_1
    //   833: ldc_w 'thread_all_count'
    //   836: aload #8
    //   838: invokevirtual length : ()I
    //   841: invokevirtual put : (Ljava/lang/String;I)Lorg/json/JSONObject;
    //   844: pop
    //   845: aload_0
    //   846: getfield q : Lorg/json/JSONObject;
    //   849: ldc_w 'thread_stacks'
    //   852: aload #8
    //   854: invokevirtual put : (Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;
    //   857: pop
    //   858: return
    //   859: astore_1
    //   860: aload_1
    //   861: invokevirtual printStackTrace : ()V
    //   864: return
    //   865: astore #6
    //   867: aload #4
    //   869: astore #6
    //   871: goto -> 209
    //   874: astore #4
    //   876: goto -> 242
    //   879: astore #6
    //   881: aload #4
    //   883: astore #6
    //   885: goto -> 476
    //   888: astore #4
    //   890: goto -> 509
    // Exception table:
    //   from	to	target	type
    //   180	209	865	finally
    //   218	226	229	java/lang/IllegalArgumentException
    //   218	226	874	finally
    //   447	476	879	finally
    //   485	493	496	java/lang/IllegalArgumentException
    //   485	493	888	finally
    //   819	858	859	org/json/JSONException
  }
  
  private boolean a(long paramLong) {
    if (this.y) {
      this.y = false;
      b(paramLong);
    } 
    return false;
  }
  
  private boolean a(String paramString) {
    // Byte code:
    //   0: aload_0
    //   1: getfield D : Ljava/util/List;
    //   4: ifnonnull -> 151
    //   7: invokestatic c : ()Lorg/json/JSONArray;
    //   10: astore_3
    //   11: aload_3
    //   12: ifnull -> 70
    //   15: aload_0
    //   16: new java/util/LinkedList
    //   19: dup
    //   20: invokespecial <init> : ()V
    //   23: putfield D : Ljava/util/List;
    //   26: aload_0
    //   27: aload_3
    //   28: iconst_0
    //   29: invokevirtual optString : (I)Ljava/lang/String;
    //   32: putfield o : Ljava/lang/String;
    //   35: iconst_1
    //   36: istore_2
    //   37: iload_2
    //   38: aload_3
    //   39: invokevirtual length : ()I
    //   42: if_icmpge -> 70
    //   45: aload_0
    //   46: getfield D : Ljava/util/List;
    //   49: aload_3
    //   50: iload_2
    //   51: invokevirtual optString : (I)Ljava/lang/String;
    //   54: invokestatic compile : (Ljava/lang/String;)Ljava/util/regex/Pattern;
    //   57: invokeinterface add : (Ljava/lang/Object;)Z
    //   62: pop
    //   63: iload_2
    //   64: iconst_1
    //   65: iadd
    //   66: istore_2
    //   67: goto -> 37
    //   70: aload_0
    //   71: getfield D : Ljava/util/List;
    //   74: ifnonnull -> 151
    //   77: new java/util/LinkedList
    //   80: dup
    //   81: invokespecial <init> : ()V
    //   84: astore_3
    //   85: aload_0
    //   86: aload_3
    //   87: putfield D : Ljava/util/List;
    //   90: aload_3
    //   91: ldc_w '^main$'
    //   94: invokestatic compile : (Ljava/lang/String;)Ljava/util/regex/Pattern;
    //   97: invokeinterface add : (Ljava/lang/Object;)Z
    //   102: pop
    //   103: aload_0
    //   104: getfield D : Ljava/util/List;
    //   107: ldc_w '^default_npth_thread$'
    //   110: invokestatic compile : (Ljava/lang/String;)Ljava/util/regex/Pattern;
    //   113: invokeinterface add : (Ljava/lang/Object;)Z
    //   118: pop
    //   119: aload_0
    //   120: getfield D : Ljava/util/List;
    //   123: ldc_w '^RenderThread$'
    //   126: invokestatic compile : (Ljava/lang/String;)Ljava/util/regex/Pattern;
    //   129: invokeinterface add : (Ljava/lang/Object;)Z
    //   134: pop
    //   135: aload_0
    //   136: getfield D : Ljava/util/List;
    //   139: ldc_w '^Jit thread pool worker thread.*$'
    //   142: invokestatic compile : (Ljava/lang/String;)Ljava/util/regex/Pattern;
    //   145: invokeinterface add : (Ljava/lang/Object;)Z
    //   150: pop
    //   151: aload_0
    //   152: getfield D : Ljava/util/List;
    //   155: invokeinterface iterator : ()Ljava/util/Iterator;
    //   160: astore_3
    //   161: aload_3
    //   162: invokeinterface hasNext : ()Z
    //   167: ifeq -> 191
    //   170: aload_3
    //   171: invokeinterface next : ()Ljava/lang/Object;
    //   176: checkcast java/util/regex/Pattern
    //   179: aload_1
    //   180: invokevirtual matcher : (Ljava/lang/CharSequence;)Ljava/util/regex/Matcher;
    //   183: invokevirtual matches : ()Z
    //   186: ifeq -> 161
    //   189: iconst_1
    //   190: ireturn
    //   191: iconst_0
    //   192: ireturn
    //   193: astore #4
    //   195: goto -> 63
    // Exception table:
    //   from	to	target	type
    //   45	63	193	finally
  }
  
  private static String b(float paramFloat) {
    return a(paramFloat / 100.0F);
  }
  
  private void b(long paramLong) {
    if (this.A != this.z) {
      try {
        boolean bool;
        this.s = System.currentTimeMillis();
        this.u = g.b().c();
        this.t = k.a(100, paramLong);
        this.k = g.b().a(paramLong).a();
        JSONObject jSONObject = new JSONObject();
        this.v = jSONObject;
        a.a(this.d, jSONObject);
        this.w = g();
        if (!Npth.hasCrash()) {
          bool = true;
        } else {
          bool = false;
        } 
        this.i = bool;
      } finally {
        Exception exception;
      } 
      try {
        if (Build.VERSION.SDK_INT >= 21) {
          this.g = this.s;
          String str = o.b();
          File file = new File(o.f(this.d), str);
          StringBuilder stringBuilder = new StringBuilder();
          stringBuilder.append("trace_");
          stringBuilder.append(a.c(this.d).replace(':', '_'));
          stringBuilder.append(".txt");
          file = new File(file, stringBuilder.toString());
          file.getParentFile().mkdirs();
          stringBuilder = new StringBuilder();
          stringBuilder.append(com.apm.insight.l.b.a().format(new Date(System.currentTimeMillis())));
          stringBuilder.append("\n");
          i.a(file, stringBuilder.toString(), false);
          r.a("anr_trace", str);
          NativeImpl.i(file.getAbsolutePath());
        } 
      } finally {
        Exception exception = null;
      } 
      f.a();
    } else {
      try {
        this.g = this.s;
        if (Build.VERSION.SDK_INT >= 21) {
          String str = o.b();
          File file = new File(o.f(this.d), str);
          StringBuilder stringBuilder = new StringBuilder();
          stringBuilder.append("trace");
          stringBuilder.append(a.c(this.d).replace(':', '_'));
          stringBuilder.append(".txt");
          file = new File(file, stringBuilder.toString());
          file.getParentFile().mkdirs();
          stringBuilder = new StringBuilder();
          stringBuilder.append(com.apm.insight.l.b.a().format(new Date(System.currentTimeMillis())));
          stringBuilder.append("\n");
          i.a(file, stringBuilder.toString(), false);
          r.a("anr_trace", str);
          NativeImpl.i(file.getAbsolutePath());
        } 
      } finally {
        Exception exception = null;
      } 
    } 
    paramLong = this.z;
    this.A = paramLong;
    this.z = -1L;
    if (paramLong == -1L)
      this.A = -1L - 1L; 
  }
  
  private static void b(String paramString, JSONArray paramJSONArray) {
    for (ICrashCallback iCrashCallback : o.a().e()) {
      try {
        if (iCrashCallback instanceof com.apm.insight.b) {
          ((com.apm.insight.b)iCrashCallback).a(CrashType.ANR, paramString, null, paramJSONArray);
          continue;
        } 
      } finally {
        iCrashCallback = null;
      } 
    } 
  }
  
  private int[] b(JSONArray paramJSONArray) {
    for (int i = 0; i < paramJSONArray.length(); i++) {
      int j;
      String str = paramJSONArray.optString(i);
      if (str != null && !str.isEmpty()) {
        j = str.indexOf("utm=");
      } else {
        j = -1;
      } 
      if (j > 0) {
        if (this.b == null)
          this.b = Pattern.compile("[^0-9]+"); 
        String[] arrayOfString = this.b.split(str.substring(j));
        if (arrayOfString != null && arrayOfString.length >= 2)
          try {
            return new int[] { i, j, i + j };
          } finally {
            arrayOfString = null;
            StringBuilder stringBuilder = new StringBuilder();
            stringBuilder.append("Err stack line: ");
            stringBuilder.append(str);
          }  
        break;
      } 
    } 
    return null;
  }
  
  private String c(long paramLong) {
    paramLong -= i.j();
    return (paramLong < 30000L) ? "0 - 30s" : ((paramLong < 60000L) ? "30s - 1min" : ((paramLong < 120000L) ? "1min - 2min" : ((paramLong < 300000L) ? "2min - 5min" : ((paramLong < 600000L) ? "5min - 10min" : ((paramLong < 1800000L) ? "10min - 30min" : ((paramLong < 3600000L) ? "30min - 1h" : "1h - "))))));
  }
  
  private JSONObject c(JSONArray paramJSONArray) {
    JSONObject jSONObject = new JSONObject();
    JSONArray jSONArray = l.a(256, 128, paramJSONArray);
    if (jSONArray.length() != paramJSONArray.length())
      this.r++; 
    try {
      jSONObject.put("thread_number", 1);
      StringBuilder stringBuilder = new StringBuilder();
      for (int i = 0; i < jSONArray.length(); i++) {
        stringBuilder.append(jSONArray.getString(i));
        stringBuilder.append('\n');
      } 
      jSONObject.put("mainStackFromTrace", stringBuilder.toString());
      return jSONObject;
    } catch (JSONException jSONException) {
      return null;
    } 
  }
  
  private boolean g() {
    int j = a.a(this.d) ^ true;
    int i = j;
    if (j != 0) {
      i = j;
      if (com.apm.insight.runtime.a.b.d().e() <= 2000L)
        i = 0; 
    } 
    return i;
  }
  
  private File h() {
    if (this.E == null) {
      File file = this.d.getFilesDir();
      StringBuilder stringBuilder = new StringBuilder();
      stringBuilder.append("has_anr_signal_");
      stringBuilder.append(a.c(this.d).replaceAll(":", "_"));
      this.E = new File(file, stringBuilder.toString());
    } 
    return this.E;
  }
  
  private boolean i() {
    return a.i();
  }
  
  public void a() {
    if (this.e)
      return; 
    this.c = new c(this);
    this.g = i.j();
    this.e = true;
  }
  
  boolean a(int paramInt1, int paramInt2) {
    // Byte code:
    //   0: invokestatic a : ()Z
    //   3: istore #7
    //   5: invokestatic uptimeMillis : ()J
    //   8: lstore #10
    //   10: aload_0
    //   11: lload #10
    //   13: invokespecial a : (J)Z
    //   16: istore_3
    //   17: aload_0
    //   18: getfield d : Landroid/content/Context;
    //   21: iconst_1
    //   22: invokestatic a : (Landroid/content/Context;I)Ljava/lang/String;
    //   25: astore #25
    //   27: invokestatic currentTimeMillis : ()J
    //   30: lstore #8
    //   32: ldc_w 'normal'
    //   35: astore #12
    //   37: aload #25
    //   39: invokestatic isEmpty : (Ljava/lang/CharSequence;)Z
    //   42: ifeq -> 55
    //   45: iload_3
    //   46: ifeq -> 55
    //   49: iconst_1
    //   50: istore #4
    //   52: goto -> 58
    //   55: iconst_0
    //   56: istore #4
    //   58: iload_3
    //   59: ifne -> 116
    //   62: aload #25
    //   64: invokestatic isEmpty : (Ljava/lang/CharSequence;)Z
    //   67: ifne -> 73
    //   70: goto -> 116
    //   73: ldc 'unknown'
    //   75: astore #18
    //   77: aconst_null
    //   78: astore #22
    //   80: aconst_null
    //   81: astore #12
    //   83: aconst_null
    //   84: astore #14
    //   86: aconst_null
    //   87: astore #16
    //   89: aconst_null
    //   90: astore #13
    //   92: aconst_null
    //   93: astore #15
    //   95: iconst_0
    //   96: istore #5
    //   98: ldc 'unknown'
    //   100: astore #21
    //   102: ldc 'unknown'
    //   104: astore #20
    //   106: ldc_w 'normal'
    //   109: astore #19
    //   111: iconst_0
    //   112: istore_3
    //   113: goto -> 333
    //   116: aload_0
    //   117: getfield x : Ljava/lang/Object;
    //   120: astore #13
    //   122: aload #13
    //   124: monitorenter
    //   125: iload #4
    //   127: ifne -> 135
    //   130: iconst_1
    //   131: istore_3
    //   132: goto -> 137
    //   135: iconst_0
    //   136: istore_3
    //   137: aload #13
    //   139: monitorexit
    //   140: aload_0
    //   141: getfield j : Lorg/json/JSONObject;
    //   144: ifnull -> 183
    //   147: invokestatic currentTimeMillis : ()J
    //   150: aload_0
    //   151: getfield g : J
    //   154: lsub
    //   155: ldc2_w 20000
    //   158: lcmp
    //   159: ifgt -> 183
    //   162: iload #4
    //   164: ifeq -> 175
    //   167: ldc_w 'trace_only'
    //   170: astore #12
    //   172: goto -> 180
    //   175: ldc_w 'trace_last'
    //   178: astore #12
    //   180: goto -> 206
    //   183: aload_0
    //   184: getfield y : Z
    //   187: ifeq -> 200
    //   190: aload_0
    //   191: iconst_0
    //   192: putfield y : Z
    //   195: ldc_w 'trace_after'
    //   198: astore #12
    //   200: aload_0
    //   201: lload #10
    //   203: invokespecial b : (J)V
    //   206: aload_0
    //   207: getfield j : Lorg/json/JSONObject;
    //   210: astore #16
    //   212: aload_0
    //   213: getfield l : Ljava/lang/String;
    //   216: astore #20
    //   218: aload_0
    //   219: getfield m : Ljava/lang/String;
    //   222: astore #21
    //   224: aload_0
    //   225: getfield n : Ljava/lang/String;
    //   228: astore #18
    //   230: aload_0
    //   231: getfield p : Lorg/json/JSONArray;
    //   234: astore #22
    //   236: aload_0
    //   237: getfield u : Lorg/json/JSONArray;
    //   240: astore #15
    //   242: aload_0
    //   243: getfield t : Lorg/json/JSONArray;
    //   246: astore #14
    //   248: aload_0
    //   249: getfield v : Lorg/json/JSONObject;
    //   252: astore #17
    //   254: aload_0
    //   255: getfield k : Lorg/json/JSONObject;
    //   258: astore #13
    //   260: aload_0
    //   261: getfield w : Z
    //   264: istore #5
    //   266: aload_0
    //   267: getfield s : J
    //   270: lstore #8
    //   272: iload #4
    //   274: ifne -> 325
    //   277: aload_0
    //   278: aconst_null
    //   279: putfield j : Lorg/json/JSONObject;
    //   282: aload_0
    //   283: aconst_null
    //   284: putfield p : Lorg/json/JSONArray;
    //   287: aload_0
    //   288: aconst_null
    //   289: putfield t : Lorg/json/JSONArray;
    //   292: aload_0
    //   293: aconst_null
    //   294: putfield k : Lorg/json/JSONObject;
    //   297: aload_0
    //   298: aconst_null
    //   299: putfield u : Lorg/json/JSONArray;
    //   302: aload_0
    //   303: ldc 'unknown'
    //   305: putfield l : Ljava/lang/String;
    //   308: aload_0
    //   309: ldc 'unknown'
    //   311: putfield m : Ljava/lang/String;
    //   314: aload_0
    //   315: ldc 'unknown'
    //   317: putfield n : Ljava/lang/String;
    //   320: aload_0
    //   321: iconst_0
    //   322: putfield r : I
    //   325: aload #12
    //   327: astore #19
    //   329: aload #17
    //   331: astore #12
    //   333: iload #4
    //   335: ifne -> 480
    //   338: aload #25
    //   340: invokestatic isEmpty : (Ljava/lang/CharSequence;)Z
    //   343: ifeq -> 480
    //   346: aload_0
    //   347: getfield j : Lorg/json/JSONObject;
    //   350: ifnull -> 440
    //   353: invokestatic currentTimeMillis : ()J
    //   356: aload_0
    //   357: getfield g : J
    //   360: lsub
    //   361: ldc2_w 20000
    //   364: lcmp
    //   365: ifle -> 440
    //   368: aload_0
    //   369: aconst_null
    //   370: putfield j : Lorg/json/JSONObject;
    //   373: aload_0
    //   374: aconst_null
    //   375: putfield p : Lorg/json/JSONArray;
    //   378: aload_0
    //   379: aconst_null
    //   380: putfield t : Lorg/json/JSONArray;
    //   383: aload_0
    //   384: aconst_null
    //   385: putfield k : Lorg/json/JSONObject;
    //   388: aload_0
    //   389: aconst_null
    //   390: putfield u : Lorg/json/JSONArray;
    //   393: aload_0
    //   394: ldc 'unknown'
    //   396: putfield l : Ljava/lang/String;
    //   399: aload_0
    //   400: ldc 'unknown'
    //   402: putfield m : Ljava/lang/String;
    //   405: aload_0
    //   406: ldc 'unknown'
    //   408: putfield n : Ljava/lang/String;
    //   411: aload_0
    //   412: iconst_0
    //   413: putfield r : I
    //   416: aload_0
    //   417: getfield h : Ljava/io/File;
    //   420: astore #12
    //   422: aload #12
    //   424: ifnull -> 433
    //   427: aload #12
    //   429: invokestatic a : (Ljava/io/File;)Z
    //   432: pop
    //   433: aload_0
    //   434: aconst_null
    //   435: putfield h : Ljava/io/File;
    //   438: iconst_0
    //   439: ireturn
    //   440: aload_0
    //   441: getfield j : Lorg/json/JSONObject;
    //   444: ifnull -> 478
    //   447: invokestatic currentTimeMillis : ()J
    //   450: aload_0
    //   451: getfield g : J
    //   454: lsub
    //   455: ldc2_w 2000
    //   458: lcmp
    //   459: ifle -> 478
    //   462: invokestatic g : ()Z
    //   465: ifeq -> 476
    //   468: aload_0
    //   469: invokespecial h : ()Ljava/io/File;
    //   472: invokestatic a : (Ljava/io/File;)Z
    //   475: pop
    //   476: iconst_0
    //   477: ireturn
    //   478: iconst_0
    //   479: ireturn
    //   480: aload #16
    //   482: ifnonnull -> 629
    //   485: aload #14
    //   487: ifnonnull -> 602
    //   490: invokestatic b : ()Lcom/apm/insight/b/h;
    //   493: invokevirtual c : ()Lorg/json/JSONArray;
    //   496: astore #23
    //   498: aload #14
    //   500: astore #15
    //   502: aload #13
    //   504: astore #17
    //   506: bipush #100
    //   508: lload #10
    //   510: invokestatic a : (IJ)Lorg/json/JSONArray;
    //   513: astore #14
    //   515: aload #14
    //   517: astore #15
    //   519: aload #13
    //   521: astore #17
    //   523: invokestatic b : ()Lcom/apm/insight/b/h;
    //   526: lload #10
    //   528: invokevirtual a : (J)Lcom/apm/insight/b/h$e;
    //   531: invokevirtual a : ()Lorg/json/JSONObject;
    //   534: astore #13
    //   536: aload #14
    //   538: astore #15
    //   540: aload #13
    //   542: astore #17
    //   544: new org/json/JSONObject
    //   547: dup
    //   548: invokespecial <init> : ()V
    //   551: astore #24
    //   553: aload_0
    //   554: getfield d : Landroid/content/Context;
    //   557: aload #24
    //   559: invokestatic a : (Landroid/content/Context;Lorg/json/JSONObject;)V
    //   562: aload #24
    //   564: astore #12
    //   566: aload #23
    //   568: astore #15
    //   570: goto -> 602
    //   573: aload #24
    //   575: astore #12
    //   577: aload #23
    //   579: astore #15
    //   581: goto -> 614
    //   584: aload #15
    //   586: astore #14
    //   588: aload #23
    //   590: astore #15
    //   592: aload #17
    //   594: astore #13
    //   596: goto -> 614
    //   599: goto -> 614
    //   602: getstatic com/apm/insight/b/b.a : Z
    //   605: invokestatic a : (Z)Lorg/json/JSONObject;
    //   608: astore #17
    //   610: aload #17
    //   612: astore #16
    //   614: aload #13
    //   616: astore #17
    //   618: aload #15
    //   620: astore #13
    //   622: aload #16
    //   624: astore #15
    //   626: goto -> 641
    //   629: aload #13
    //   631: astore #17
    //   633: aload #15
    //   635: astore #13
    //   637: aload #16
    //   639: astore #15
    //   641: iload_3
    //   642: istore #6
    //   644: aload #15
    //   646: ifnull -> 1956
    //   649: aload #15
    //   651: invokevirtual length : ()I
    //   654: ifle -> 1956
    //   657: aload #15
    //   659: ldc_w 'pid'
    //   662: invokestatic myPid : ()I
    //   665: invokevirtual put : (Ljava/lang/String;I)Lorg/json/JSONObject;
    //   668: pop
    //   669: aload #15
    //   671: ldc_w 'package'
    //   674: aload_0
    //   675: getfield d : Landroid/content/Context;
    //   678: invokevirtual getPackageName : ()Ljava/lang/String;
    //   681: invokevirtual put : (Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;
    //   684: pop
    //   685: aload #15
    //   687: ldc_w 'is_remote_process'
    //   690: iconst_0
    //   691: invokevirtual put : (Ljava/lang/String;I)Lorg/json/JSONObject;
    //   694: pop
    //   695: aload #15
    //   697: ldc_w 'is_new_stack'
    //   700: bipush #10
    //   702: invokevirtual put : (Ljava/lang/String;I)Lorg/json/JSONObject;
    //   705: pop
    //   706: new com/apm/insight/entity/a
    //   709: dup
    //   710: new org/json/JSONObject
    //   713: dup
    //   714: invokespecial <init> : ()V
    //   717: invokespecial <init> : (Lorg/json/JSONObject;)V
    //   720: astore #16
    //   722: aload #16
    //   724: ldc_w 'data'
    //   727: aload #15
    //   729: invokevirtual toString : ()Ljava/lang/String;
    //   732: invokevirtual a : (Ljava/lang/String;Ljava/lang/Object;)V
    //   735: iconst_1
    //   736: istore_3
    //   737: aload #16
    //   739: ldc_w 'is_anr'
    //   742: iconst_1
    //   743: invokestatic valueOf : (I)Ljava/lang/Integer;
    //   746: invokevirtual a : (Ljava/lang/String;Ljava/lang/Object;)V
    //   749: aload #16
    //   751: ldc_w 'anrType'
    //   754: aload #19
    //   756: invokevirtual a : (Ljava/lang/String;Ljava/lang/Object;)V
    //   759: aload #16
    //   761: ldc_w 'history_message'
    //   764: aload #13
    //   766: invokevirtual a : (Ljava/lang/String;Ljava/lang/Object;)V
    //   769: aload #16
    //   771: ldc_w 'current_message'
    //   774: aload #17
    //   776: invokevirtual a : (Ljava/lang/String;Ljava/lang/Object;)V
    //   779: aload #16
    //   781: ldc_w 'pending_messages'
    //   784: aload #14
    //   786: invokevirtual a : (Ljava/lang/String;Ljava/lang/Object;)V
    //   789: aload #16
    //   791: ldc_w 'anr_time'
    //   794: invokestatic currentTimeMillis : ()J
    //   797: invokestatic valueOf : (J)Ljava/lang/Long;
    //   800: invokevirtual a : (Ljava/lang/String;Ljava/lang/Object;)V
    //   803: aload #16
    //   805: ldc_w 'crash_time'
    //   808: lload #8
    //   810: invokestatic valueOf : (J)Ljava/lang/Long;
    //   813: invokevirtual a : (Ljava/lang/String;Ljava/lang/Object;)V
    //   816: invokestatic b : ()Z
    //   819: pop
    //   820: aload #16
    //   822: aload #12
    //   824: invokevirtual c : (Lorg/json/JSONObject;)V
    //   827: iload #4
    //   829: ifeq -> 2007
    //   832: ldc_w 'Resons for no ANR_INFO:\\n1. User click close button too quickly as soon as the ANR dialog appear.\\n2. User close the app since can not stand the carton.\\n3. Some OS force stop the process group without any hint dialog.\\n\\nThe ANR will be upload by the follow ways only:\\n1. Receive the ANR signal(SIGQUIT).\\n2. The app is forground or was forground last 2s.\\n3. Happens in main process.\\n4. Process was killed exactly.'
    //   835: astore #12
    //   837: goto -> 840
    //   840: aload #16
    //   842: ldc_w 'anr_info'
    //   845: aload #12
    //   847: invokevirtual a : (Ljava/lang/String;Ljava/lang/Object;)V
    //   850: aload #22
    //   852: ifnull -> 865
    //   855: aload #16
    //   857: ldc_w 'dump_trace'
    //   860: aload #22
    //   862: invokevirtual a : (Ljava/lang/String;Ljava/lang/Object;)V
    //   865: iload #4
    //   867: ifne -> 898
    //   870: aload_0
    //   871: getfield q : Lorg/json/JSONObject;
    //   874: astore #12
    //   876: aload #12
    //   878: ifnull -> 889
    //   881: aload #12
    //   883: invokevirtual length : ()I
    //   886: ifne -> 898
    //   889: aconst_null
    //   890: invokestatic b : (Ljava/lang/String;)Lorg/json/JSONObject;
    //   893: astore #12
    //   895: goto -> 904
    //   898: aload_0
    //   899: getfield q : Lorg/json/JSONObject;
    //   902: astore #12
    //   904: aload #16
    //   906: ldc_w 'all_thread_stacks'
    //   909: aload #12
    //   911: invokevirtual a : (Ljava/lang/String;Ljava/lang/Object;)V
    //   914: invokestatic a : ()Lcom/apm/insight/runtime/a/f;
    //   917: astore #13
    //   919: getstatic com/apm/insight/CrashType.ANR : Lcom/apm/insight/CrashType;
    //   922: astore #12
    //   924: aload #13
    //   926: aload #12
    //   928: aload #16
    //   930: invokevirtual a : (Lcom/apm/insight/CrashType;Lcom/apm/insight/entity/a;)Lcom/apm/insight/entity/a;
    //   933: astore #16
    //   935: aload #16
    //   937: ldc_w 'is_background'
    //   940: iload #5
    //   942: invokestatic valueOf : (Z)Ljava/lang/Boolean;
    //   945: invokevirtual a : (Ljava/lang/String;Ljava/lang/Object;)V
    //   948: aload #16
    //   950: ldc_w 'logcat'
    //   953: invokestatic f : ()Ljava/lang/String;
    //   956: invokestatic b : (Ljava/lang/String;)Lorg/json/JSONArray;
    //   959: invokevirtual a : (Ljava/lang/String;Ljava/lang/Object;)V
    //   962: aload #16
    //   964: ldc_w 'has_dump'
    //   967: ldc_w 'true'
    //   970: invokevirtual a : (Ljava/lang/String;Ljava/lang/Object;)V
    //   973: aload #16
    //   975: ldc_w 'crash_uuid'
    //   978: lload #8
    //   980: aload #12
    //   982: iconst_0
    //   983: iconst_0
    //   984: invokestatic a : (JLcom/apm/insight/CrashType;ZZ)Ljava/lang/String;
    //   987: invokevirtual a : (Ljava/lang/String;Ljava/lang/Object;)V
    //   990: aload #16
    //   992: ldc_w 'jiffy'
    //   995: invokestatic a : ()J
    //   998: invokestatic valueOf : (J)Ljava/lang/Long;
    //   1001: invokevirtual a : (Ljava/lang/String;Ljava/lang/Object;)V
    //   1004: aload #16
    //   1006: invokevirtual h : ()Lorg/json/JSONObject;
    //   1009: ldc_w 'filters'
    //   1012: invokevirtual optJSONObject : (Ljava/lang/String;)Lorg/json/JSONObject;
    //   1015: astore #12
    //   1017: aload #16
    //   1019: invokevirtual h : ()Lorg/json/JSONObject;
    //   1022: invokestatic b : (Lorg/json/JSONObject;)V
    //   1025: aload #12
    //   1027: ifnonnull -> 2014
    //   1030: new org/json/JSONObject
    //   1033: dup
    //   1034: invokespecial <init> : ()V
    //   1037: astore #14
    //   1039: aload #14
    //   1041: astore #13
    //   1043: aload #16
    //   1045: ldc_w 'filters'
    //   1048: aload #14
    //   1050: invokevirtual a : (Ljava/lang/String;Ljava/lang/Object;)V
    //   1053: aload #14
    //   1055: astore #12
    //   1057: goto -> 1060
    //   1060: aload #12
    //   1062: astore #13
    //   1064: aload #12
    //   1066: ldc_w 'anrType'
    //   1069: aload #19
    //   1071: invokevirtual put : (Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;
    //   1074: pop
    //   1075: aload #12
    //   1077: astore #13
    //   1079: aload #12
    //   1081: ldc_w 'max_utm_thread'
    //   1084: aload #20
    //   1086: invokevirtual put : (Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;
    //   1089: pop
    //   1090: aload #12
    //   1092: astore #13
    //   1094: aload #12
    //   1096: ldc_w 'max_stm_thread'
    //   1099: aload #21
    //   1101: invokevirtual put : (Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;
    //   1104: pop
    //   1105: aload #12
    //   1107: astore #13
    //   1109: aload #12
    //   1111: ldc_w 'max_utm_stm_thread'
    //   1114: aload #18
    //   1116: invokevirtual put : (Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;
    //   1119: pop
    //   1120: aload #12
    //   1122: astore #13
    //   1124: aload #12
    //   1126: ldc_w 'max_utm_thread_version'
    //   1129: aload_0
    //   1130: getfield o : Ljava/lang/String;
    //   1133: invokevirtual put : (Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;
    //   1136: pop
    //   1137: aload #12
    //   1139: astore #13
    //   1141: aload #12
    //   1143: ldc_w 'crash_length'
    //   1146: aload_0
    //   1147: lload #8
    //   1149: invokespecial c : (J)Ljava/lang/String;
    //   1152: invokevirtual put : (Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;
    //   1155: pop
    //   1156: aload #12
    //   1158: astore #13
    //   1160: aload #12
    //   1162: ldc_w 'disable_looper_monitor'
    //   1165: invokestatic d : ()Z
    //   1168: invokestatic valueOf : (Z)Ljava/lang/String;
    //   1171: invokevirtual put : (Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;
    //   1174: pop
    //   1175: aload #12
    //   1177: astore #13
    //   1179: aload #12
    //   1181: ldc_w 'npth_force_apm_crash'
    //   1184: invokestatic b : ()Z
    //   1187: invokestatic valueOf : (Z)Ljava/lang/String;
    //   1190: invokevirtual put : (Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;
    //   1193: pop
    //   1194: aload #12
    //   1196: astore #13
    //   1198: aload #12
    //   1200: ldc_w 'sdk_version'
    //   1203: ldc_w '1.3.8.nourl-alpha.15'
    //   1206: invokevirtual put : (Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;
    //   1209: pop
    //   1210: aload #12
    //   1212: astore #13
    //   1214: aload #12
    //   1216: ldc_w 'has_logcat'
    //   1219: aload #16
    //   1221: invokevirtual a : ()Z
    //   1224: invokestatic valueOf : (Z)Ljava/lang/String;
    //   1227: invokevirtual put : (Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;
    //   1230: pop
    //   1231: aload #12
    //   1233: astore #13
    //   1235: aload #12
    //   1237: ldc_w 'memory_leak'
    //   1240: aload #16
    //   1242: invokevirtual f : ()Z
    //   1245: invokestatic valueOf : (Z)Ljava/lang/String;
    //   1248: invokevirtual put : (Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;
    //   1251: pop
    //   1252: aload #12
    //   1254: astore #13
    //   1256: aload #12
    //   1258: ldc_w 'fd_leak'
    //   1261: aload #16
    //   1263: invokevirtual d : ()Z
    //   1266: invokestatic valueOf : (Z)Ljava/lang/String;
    //   1269: invokevirtual put : (Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;
    //   1272: pop
    //   1273: aload #12
    //   1275: astore #13
    //   1277: aload #12
    //   1279: ldc_w 'threads_leak'
    //   1282: aload #16
    //   1284: invokevirtual e : ()Z
    //   1287: invokestatic valueOf : (Z)Ljava/lang/String;
    //   1290: invokevirtual put : (Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;
    //   1293: pop
    //   1294: aload #12
    //   1296: astore #13
    //   1298: aload #12
    //   1300: ldc_w 'is_64_devices'
    //   1303: invokestatic a : ()Z
    //   1306: invokestatic valueOf : (Z)Ljava/lang/String;
    //   1309: invokevirtual put : (Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;
    //   1312: pop
    //   1313: aload #12
    //   1315: astore #13
    //   1317: aload #12
    //   1319: ldc_w 'is_64_runtime'
    //   1322: invokestatic e : ()Z
    //   1325: invokestatic valueOf : (Z)Ljava/lang/String;
    //   1328: invokevirtual put : (Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;
    //   1331: pop
    //   1332: aload #12
    //   1334: astore #13
    //   1336: aload #12
    //   1338: ldc_w 'is_x86_devices'
    //   1341: invokestatic b : ()Z
    //   1344: invokestatic valueOf : (Z)Ljava/lang/String;
    //   1347: invokevirtual put : (Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;
    //   1350: pop
    //   1351: aload #12
    //   1353: astore #13
    //   1355: aload #12
    //   1357: ldc_w 'has_meminfo_file'
    //   1360: aload #16
    //   1362: invokevirtual g : ()Z
    //   1365: invokestatic valueOf : (Z)Ljava/lang/String;
    //   1368: invokevirtual put : (Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;
    //   1371: pop
    //   1372: aload #12
    //   1374: astore #13
    //   1376: invokestatic m : ()Z
    //   1379: ifeq -> 2017
    //   1382: ldc_w 'true'
    //   1385: astore #14
    //   1387: goto -> 1390
    //   1390: aload #12
    //   1392: astore #13
    //   1394: aload #12
    //   1396: ldc_w 'is_root'
    //   1399: aload #14
    //   1401: invokevirtual put : (Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;
    //   1404: pop
    //   1405: aload #12
    //   1407: astore #13
    //   1409: aload_0
    //   1410: getfield y : Z
    //   1413: ifne -> 2025
    //   1416: goto -> 1419
    //   1419: aload #12
    //   1421: astore #13
    //   1423: aload #12
    //   1425: ldc_w 'anr_normal_trace'
    //   1428: iload_3
    //   1429: invokestatic valueOf : (Z)Ljava/lang/String;
    //   1432: invokevirtual put : (Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;
    //   1435: pop
    //   1436: aload #12
    //   1438: astore #13
    //   1440: aload #12
    //   1442: ldc_w 'anr_no_run'
    //   1445: iload #7
    //   1447: invokestatic valueOf : (Z)Ljava/lang/String;
    //   1450: invokevirtual put : (Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;
    //   1453: pop
    //   1454: aload #12
    //   1456: astore #13
    //   1458: invokestatic hasCrash : ()Z
    //   1461: ifeq -> 2030
    //   1464: ldc_w 'true'
    //   1467: astore #14
    //   1469: goto -> 1472
    //   1472: aload #12
    //   1474: astore #13
    //   1476: aload #12
    //   1478: ldc_w 'crash_after_crash'
    //   1481: aload #14
    //   1483: invokevirtual put : (Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;
    //   1486: pop
    //   1487: aload #12
    //   1489: astore #13
    //   1491: aload #12
    //   1493: ldc_w 'from_file'
    //   1496: invokestatic a : ()Z
    //   1499: invokestatic valueOf : (Z)Ljava/lang/String;
    //   1502: invokevirtual put : (Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;
    //   1505: pop
    //   1506: aload #12
    //   1508: astore #13
    //   1510: aload #12
    //   1512: ldc_w 'has_dump'
    //   1515: ldc_w 'true'
    //   1518: invokevirtual put : (Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;
    //   1521: pop
    //   1522: aload #12
    //   1524: astore #13
    //   1526: aload #12
    //   1528: ldc_w 'from_kill'
    //   1531: iload #4
    //   1533: invokestatic valueOf : (Z)Ljava/lang/String;
    //   1536: invokevirtual put : (Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;
    //   1539: pop
    //   1540: aload #12
    //   1542: astore #13
    //   1544: aload #12
    //   1546: ldc_w 'last_resume_activity'
    //   1549: invokestatic d : ()Lcom/apm/insight/runtime/a/b;
    //   1552: invokevirtual h : ()Ljava/lang/String;
    //   1555: invokevirtual put : (Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;
    //   1558: pop
    //   1559: aload #12
    //   1561: astore #13
    //   1563: aload_0
    //   1564: getfield r : I
    //   1567: istore_1
    //   1568: iload_1
    //   1569: ifle -> 1589
    //   1572: aload #12
    //   1574: astore #13
    //   1576: aload #12
    //   1578: ldc_w 'may_have_stack_overflow'
    //   1581: iload_1
    //   1582: invokestatic valueOf : (I)Ljava/lang/String;
    //   1585: invokevirtual put : (Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;
    //   1588: pop
    //   1589: iload #4
    //   1591: ifne -> 1633
    //   1594: aload_0
    //   1595: aload #25
    //   1597: aload #12
    //   1599: invokespecial a : (Ljava/lang/String;Lorg/json/JSONObject;)V
    //   1602: aload #12
    //   1604: astore #14
    //   1606: goto -> 1715
    //   1609: astore #14
    //   1611: aload #12
    //   1613: astore #13
    //   1615: invokestatic a : ()Lcom/apm/insight/d;
    //   1618: ldc_w 'NPTH_CATCH'
    //   1621: aload #14
    //   1623: invokevirtual a : (Ljava/lang/String;Ljava/lang/Throwable;)V
    //   1626: aload #12
    //   1628: astore #14
    //   1630: goto -> 1715
    //   1633: aload #12
    //   1635: astore #14
    //   1637: aload #12
    //   1639: astore #13
    //   1641: aload_0
    //   1642: invokespecial i : ()Z
    //   1645: ifne -> 1715
    //   1648: aload #12
    //   1650: astore #13
    //   1652: aload #12
    //   1654: ldc_w 'aid'
    //   1657: aload #16
    //   1659: invokevirtual i : ()Lcom/apm/insight/entity/Header;
    //   1662: invokevirtual f : ()Lorg/json/JSONObject;
    //   1665: ldc_w 'aid'
    //   1668: invokevirtual opt : (Ljava/lang/String;)Ljava/lang/Object;
    //   1671: invokestatic valueOf : (Ljava/lang/Object;)Ljava/lang/String;
    //   1674: invokevirtual put : (Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;
    //   1677: pop
    //   1678: aload #12
    //   1680: astore #13
    //   1682: aload #16
    //   1684: invokevirtual i : ()Lcom/apm/insight/entity/Header;
    //   1687: invokevirtual f : ()Lorg/json/JSONObject;
    //   1690: ldc_w 'aid'
    //   1693: sipush #2010
    //   1696: invokevirtual put : (Ljava/lang/String;I)Lorg/json/JSONObject;
    //   1699: pop
    //   1700: aload #12
    //   1702: astore #14
    //   1704: goto -> 1715
    //   1707: aload #13
    //   1709: astore #12
    //   1711: aload #12
    //   1713: astore #14
    //   1715: iload #4
    //   1717: ifeq -> 1781
    //   1720: invokestatic c : ()Ljava/lang/String;
    //   1723: astore #12
    //   1725: new java/io/File
    //   1728: dup
    //   1729: aload_0
    //   1730: getfield d : Landroid/content/Context;
    //   1733: invokestatic a : (Landroid/content/Context;)Ljava/io/File;
    //   1736: lload #8
    //   1738: getstatic com/apm/insight/CrashType.ANR : Lcom/apm/insight/CrashType;
    //   1741: iconst_0
    //   1742: iconst_0
    //   1743: invokestatic a : (JLcom/apm/insight/CrashType;ZZ)Ljava/lang/String;
    //   1746: invokespecial <init> : (Ljava/io/File;Ljava/lang/String;)V
    //   1749: astore #13
    //   1751: aload_0
    //   1752: aload #13
    //   1754: putfield h : Ljava/io/File;
    //   1757: aload #13
    //   1759: aload #13
    //   1761: invokevirtual getName : ()Ljava/lang/String;
    //   1764: aload #12
    //   1766: aload #16
    //   1768: invokevirtual h : ()Lorg/json/JSONObject;
    //   1771: invokestatic b : ()Z
    //   1774: invokestatic a : (Ljava/io/File;Ljava/lang/String;Ljava/lang/String;Lorg/json/JSONObject;Z)Ljava/lang/String;
    //   1777: pop
    //   1778: iload #6
    //   1780: ireturn
    //   1781: aload_0
    //   1782: getfield h : Ljava/io/File;
    //   1785: astore #12
    //   1787: aload #12
    //   1789: ifnull -> 1803
    //   1792: aload #12
    //   1794: invokestatic a : (Ljava/io/File;)Z
    //   1797: pop
    //   1798: aload_0
    //   1799: aconst_null
    //   1800: putfield h : Ljava/io/File;
    //   1803: invokestatic a : ()Lcom/apm/insight/a/a;
    //   1806: getstatic com/apm/insight/CrashType.ANR : Lcom/apm/insight/CrashType;
    //   1809: lload #8
    //   1811: invokestatic e : ()Ljava/lang/String;
    //   1814: invokevirtual a : (Lcom/apm/insight/CrashType;JLjava/lang/String;)V
    //   1817: invokestatic f : ()Ljava/io/File;
    //   1820: invokevirtual length : ()J
    //   1823: ldc2_w 1024
    //   1826: lcmp
    //   1827: ifle -> 1842
    //   1830: aload #16
    //   1832: ldc_w 'has_system_traces'
    //   1835: ldc_w 'true'
    //   1838: invokevirtual a : (Ljava/lang/String;Ljava/lang/String;)Lcom/apm/insight/entity/a;
    //   1841: pop
    //   1842: invokestatic f : ()Ljava/lang/String;
    //   1845: invokestatic e : (Ljava/lang/String;)Ljava/io/File;
    //   1848: invokestatic f : ()Ljava/lang/String;
    //   1851: invokestatic f : (Ljava/lang/String;)Ljava/io/File;
    //   1854: invokestatic a : (Ljava/io/File;Ljava/io/File;)Lorg/json/JSONArray;
    //   1857: astore #12
    //   1859: aload #14
    //   1861: ldc_w 'leak_threads_count'
    //   1864: aload #12
    //   1866: invokevirtual length : ()I
    //   1869: invokestatic valueOf : (I)Ljava/lang/String;
    //   1872: invokevirtual put : (Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;
    //   1875: pop
    //   1876: aload #12
    //   1878: invokevirtual length : ()I
    //   1881: ifle -> 1896
    //   1884: invokestatic f : ()Ljava/lang/String;
    //   1887: invokestatic g : (Ljava/lang/String;)Ljava/io/File;
    //   1890: aload #12
    //   1892: iconst_0
    //   1893: invokestatic a : (Ljava/io/File;Lorg/json/JSONArray;Z)V
    //   1896: aload #15
    //   1898: ldc_w 'mainStackFromTrace'
    //   1901: invokevirtual optString : (Ljava/lang/String;)Ljava/lang/String;
    //   1904: astore #12
    //   1906: aload #12
    //   1908: invokestatic a : (Ljava/lang/String;)Lorg/json/JSONArray;
    //   1911: astore #13
    //   1913: aload #16
    //   1915: invokevirtual h : ()Lorg/json/JSONObject;
    //   1918: aload #13
    //   1920: new com/apm/insight/b/b$2
    //   1923: dup
    //   1924: aload_0
    //   1925: lload #8
    //   1927: invokespecial <init> : (Lcom/apm/insight/b/b;J)V
    //   1930: invokestatic a : (Lorg/json/JSONObject;Lorg/json/JSONArray;Lcom/apm/insight/entity/b$a;)V
    //   1933: aload #12
    //   1935: aload #13
    //   1937: invokestatic b : (Ljava/lang/String;Lorg/json/JSONArray;)V
    //   1940: iload #6
    //   1942: ireturn
    //   1943: astore #12
    //   1945: invokestatic a : ()Lcom/apm/insight/d;
    //   1948: ldc_w 'NPTH_CATCH'
    //   1951: aload #12
    //   1953: invokevirtual a : (Ljava/lang/String;Ljava/lang/Throwable;)V
    //   1956: iload #6
    //   1958: ireturn
    //   1959: astore #12
    //   1961: aload #13
    //   1963: monitorexit
    //   1964: aload #12
    //   1966: athrow
    //   1967: astore #17
    //   1969: goto -> 599
    //   1972: astore #13
    //   1974: goto -> 584
    //   1977: astore #12
    //   1979: goto -> 573
    //   1982: astore #17
    //   1984: goto -> 614
    //   1987: astore #13
    //   1989: goto -> 1711
    //   1992: astore #12
    //   1994: goto -> 1707
    //   1997: astore #12
    //   1999: goto -> 1842
    //   2002: astore #12
    //   2004: goto -> 1896
    //   2007: aload #25
    //   2009: astore #12
    //   2011: goto -> 840
    //   2014: goto -> 1060
    //   2017: ldc_w 'false'
    //   2020: astore #14
    //   2022: goto -> 1390
    //   2025: iconst_0
    //   2026: istore_3
    //   2027: goto -> 1419
    //   2030: ldc_w 'false'
    //   2033: astore #14
    //   2035: goto -> 1472
    // Exception table:
    //   from	to	target	type
    //   137	140	1959	finally
    //   490	498	1967	finally
    //   506	515	1972	finally
    //   523	536	1972	finally
    //   544	553	1972	finally
    //   553	562	1977	finally
    //   602	610	1982	finally
    //   657	735	1943	finally
    //   737	827	1943	finally
    //   840	850	1943	finally
    //   855	865	1943	finally
    //   870	876	1943	finally
    //   881	889	1943	finally
    //   889	895	1943	finally
    //   898	904	1943	finally
    //   904	1025	1943	finally
    //   1030	1039	1987	finally
    //   1043	1053	1992	finally
    //   1064	1075	1992	finally
    //   1079	1090	1992	finally
    //   1094	1105	1992	finally
    //   1109	1120	1992	finally
    //   1124	1137	1992	finally
    //   1141	1156	1992	finally
    //   1160	1175	1992	finally
    //   1179	1194	1992	finally
    //   1198	1210	1992	finally
    //   1214	1231	1992	finally
    //   1235	1252	1992	finally
    //   1256	1273	1992	finally
    //   1277	1294	1992	finally
    //   1298	1313	1992	finally
    //   1317	1332	1992	finally
    //   1336	1351	1992	finally
    //   1355	1372	1992	finally
    //   1376	1382	1992	finally
    //   1394	1405	1992	finally
    //   1409	1416	1992	finally
    //   1423	1436	1992	finally
    //   1440	1454	1992	finally
    //   1458	1464	1992	finally
    //   1476	1487	1992	finally
    //   1491	1506	1992	finally
    //   1510	1522	1992	finally
    //   1526	1540	1992	finally
    //   1544	1559	1992	finally
    //   1563	1568	1992	finally
    //   1576	1589	1992	finally
    //   1594	1602	1609	finally
    //   1615	1626	1992	finally
    //   1641	1648	1992	finally
    //   1652	1678	1992	finally
    //   1682	1700	1992	finally
    //   1720	1778	1943	finally
    //   1781	1787	1943	finally
    //   1792	1803	1943	finally
    //   1803	1817	1943	finally
    //   1817	1842	1997	finally
    //   1842	1896	2002	finally
    //   1896	1940	1943	finally
    //   1961	1964	1959	finally
  }
  
  public void b() {
    if (!this.e)
      return; 
    this.e = false;
    c c1 = this.c;
    if (c1 != null)
      c1.b(); 
    this.c = null;
  }
  
  public void c() {
    c c1 = this.c;
    if (c1 != null)
      c1.a(); 
  }
  
  public void d() {
    if (f)
      return; 
    synchronized (this.x) {
      if (f)
        return; 
      this.B.run();
      return;
    } 
  }
  
  public void e() {
    if (NativeImpl.g())
      try {
        i.a(h(), String.valueOf(this.C + 1), false);
      } finally {
        Exception exception = null;
      }  
    this.z = SystemClock.uptimeMillis();
    this.y = true;
  }
  
  public void f() {
    File file = h();
    try {
      int i = Integer.decode(i.c(file.getAbsolutePath())).intValue();
      this.C = i;
      return;
    } catch (IOException iOException) {
      return;
    } finally {
      Exception exception = null;
      i.a((File)iOException);
    } 
  }
}


/* Location:              C:\soft\dex2jar-2.0\Hill race-dex2jar.jar!\com\apm\insight\b\b.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */