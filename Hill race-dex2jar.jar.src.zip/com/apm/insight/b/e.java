package com.apm.insight.b;

public abstract class e {
  public static long a;
  
  public static long b;
  
  public volatile boolean c = false;
  
  public void a(String paramString) {
    this.c = true;
  }
  
  public boolean a() {
    return false;
  }
  
  public void b(String paramString) {
    this.c = false;
  }
}


/* Location:              C:\soft\dex2jar-2.0\Hill race-dex2jar.jar!\com\apm\insight\b\e.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */