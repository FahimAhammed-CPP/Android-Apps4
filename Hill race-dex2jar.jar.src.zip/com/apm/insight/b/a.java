package com.apm.insight.b;

import android.app.ActivityManager;
import com.apm.insight.i;

public class a {
  static String a(ActivityManager.ProcessErrorStateInfo paramProcessErrorStateInfo) {
    if (!i.s())
      return "|------------- processErrorStateInfo--------------|\ndisable anr info\n\"-----------------------end----------------------------\""; 
    StringBuilder stringBuilder1 = new StringBuilder();
    stringBuilder1.append("|------------- processErrorStateInfo--------------|\n");
    StringBuilder stringBuilder2 = new StringBuilder();
    stringBuilder2.append("condition: ");
    stringBuilder2.append(paramProcessErrorStateInfo.condition);
    stringBuilder2.append("\n");
    stringBuilder1.append(stringBuilder2.toString());
    stringBuilder2 = new StringBuilder();
    stringBuilder2.append("processName: ");
    stringBuilder2.append(paramProcessErrorStateInfo.processName);
    stringBuilder2.append("\n");
    stringBuilder1.append(stringBuilder2.toString());
    stringBuilder2 = new StringBuilder();
    stringBuilder2.append("pid: ");
    stringBuilder2.append(paramProcessErrorStateInfo.pid);
    stringBuilder2.append("\n");
    stringBuilder1.append(stringBuilder2.toString());
    stringBuilder2 = new StringBuilder();
    stringBuilder2.append("uid: ");
    stringBuilder2.append(paramProcessErrorStateInfo.uid);
    stringBuilder2.append("\n");
    stringBuilder1.append(stringBuilder2.toString());
    stringBuilder2 = new StringBuilder();
    stringBuilder2.append("tag: ");
    stringBuilder2.append(paramProcessErrorStateInfo.tag);
    stringBuilder2.append("\n");
    stringBuilder1.append(stringBuilder2.toString());
    stringBuilder2 = new StringBuilder();
    stringBuilder2.append("shortMsg : ");
    stringBuilder2.append(paramProcessErrorStateInfo.shortMsg);
    stringBuilder2.append("\n");
    stringBuilder1.append(stringBuilder2.toString());
    stringBuilder2 = new StringBuilder();
    stringBuilder2.append("longMsg : ");
    stringBuilder2.append(paramProcessErrorStateInfo.longMsg);
    stringBuilder2.append("\n");
    stringBuilder1.append(stringBuilder2.toString());
    stringBuilder1.append("-----------------------end----------------------------");
    return stringBuilder1.toString();
  }
  
  static boolean a(ActivityManager.ProcessErrorStateInfo paramProcessErrorStateInfo1, ActivityManager.ProcessErrorStateInfo paramProcessErrorStateInfo2) {
    return (String.valueOf(paramProcessErrorStateInfo1.condition).equals(String.valueOf(paramProcessErrorStateInfo2.condition)) && String.valueOf(paramProcessErrorStateInfo1.processName).equals(String.valueOf(paramProcessErrorStateInfo2.processName)) && String.valueOf(paramProcessErrorStateInfo1.pid).equals(String.valueOf(paramProcessErrorStateInfo2.pid)) && String.valueOf(paramProcessErrorStateInfo1.uid).equals(String.valueOf(paramProcessErrorStateInfo2.uid)) && String.valueOf(paramProcessErrorStateInfo1.tag).equals(String.valueOf(paramProcessErrorStateInfo2.tag)) && String.valueOf(paramProcessErrorStateInfo1.shortMsg).equals(String.valueOf(paramProcessErrorStateInfo2.shortMsg)) && String.valueOf(paramProcessErrorStateInfo1.longMsg).equals(String.valueOf(paramProcessErrorStateInfo2.longMsg)));
  }
}


/* Location:              C:\soft\dex2jar-2.0\Hill race-dex2jar.jar!\com\apm\insight\b\a.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */