package com.apm.insight.b;

import android.app.ActivityManager;
import android.content.Context;
import android.os.FileObserver;
import android.os.Looper;
import android.os.Process;
import android.os.SystemClock;
import android.text.TextUtils;
import com.apm.insight.c;
import com.apm.insight.f;
import com.apm.insight.l.a;
import com.apm.insight.l.r;
import org.json.JSONObject;

public class d {
  private static String a;
  
  private static long b = -1L;
  
  private static boolean c = false;
  
  private static FileObserver d;
  
  private static ActivityManager.ProcessErrorStateInfo e;
  
  static String a(Context paramContext, int paramInt) {
    if (r.a(256)) {
      c = false;
      return "TEST_ANR_INFO";
    } 
    if (SystemClock.uptimeMillis() - b < 5000L)
      return null; 
    try {
      ActivityManager.ProcessErrorStateInfo processErrorStateInfo = a.a(paramContext, paramInt);
      if (processErrorStateInfo != null && Process.myPid() == processErrorStateInfo.pid) {
        ActivityManager.ProcessErrorStateInfo processErrorStateInfo1 = e;
        if (processErrorStateInfo1 != null && a.a(processErrorStateInfo1, processErrorStateInfo))
          return null; 
        e = processErrorStateInfo;
        a = null;
        b = SystemClock.uptimeMillis();
        c = false;
        return a.a(processErrorStateInfo);
      } 
    } finally {}
    String str = a;
    if (str != null) {
      c = true;
      a = null;
      b = SystemClock.uptimeMillis();
      return str;
    } 
    return null;
  }
  
  public static JSONObject a(boolean paramBoolean) {
    try {
      StackTraceElement[] arrayOfStackTraceElement = Looper.getMainLooper().getThread().getStackTrace();
      JSONObject jSONObject = new JSONObject();
      return jSONObject;
    } finally {
      Exception exception = null;
      c.a().a("NPTH_CATCH", exception);
    } 
  }
  
  public static void a(String paramString, f paramf) {
    FileObserver fileObserver2 = d;
    if (fileObserver2 != null)
      fileObserver2.stopWatching(); 
    FileObserver fileObserver1 = new FileObserver(paramString, 136, paramf, paramString) {
        public void onEvent(int param1Int, String param1String) {
          if (TextUtils.isEmpty(param1String))
            return; 
          try {
            return;
          } finally {
            param1String = null;
            c.a().a("NPTH_CATCH", (Throwable)param1String);
          } 
        }
      };
    d = fileObserver1;
    fileObserver1.startWatching();
  }
  
  public static boolean a() {
    return c;
  }
  
  public static void b() {
    e = null;
  }
}


/* Location:              C:\soft\dex2jar-2.0\Hill race-dex2jar.jar!\com\apm\insight\b\d.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */