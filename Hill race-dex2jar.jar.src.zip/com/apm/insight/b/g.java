package com.apm.insight.b;

import android.content.Context;

public class g {
  private static volatile g a;
  
  private static h c;
  
  private final b b;
  
  private g(Context paramContext) {
    this.b = new b(paramContext);
    h h1 = new h(0);
    c = h1;
    h1.b();
  }
  
  public static g a(Context paramContext) {
    // Byte code:
    //   0: getstatic com/apm/insight/b/g.a : Lcom/apm/insight/b/g;
    //   3: ifnonnull -> 38
    //   6: ldc com/apm/insight/b/g
    //   8: monitorenter
    //   9: getstatic com/apm/insight/b/g.a : Lcom/apm/insight/b/g;
    //   12: ifnonnull -> 26
    //   15: new com/apm/insight/b/g
    //   18: dup
    //   19: aload_0
    //   20: invokespecial <init> : (Landroid/content/Context;)V
    //   23: putstatic com/apm/insight/b/g.a : Lcom/apm/insight/b/g;
    //   26: ldc com/apm/insight/b/g
    //   28: monitorexit
    //   29: goto -> 38
    //   32: astore_0
    //   33: ldc com/apm/insight/b/g
    //   35: monitorexit
    //   36: aload_0
    //   37: athrow
    //   38: getstatic com/apm/insight/b/g.a : Lcom/apm/insight/b/g;
    //   41: areturn
    // Exception table:
    //   from	to	target	type
    //   9	26	32	finally
    //   26	29	32	finally
    //   33	36	32	finally
  }
  
  public static h b() {
    return c;
  }
  
  public b a() {
    return this.b;
  }
  
  public void c() {
    this.b.a();
  }
  
  public void d() {
    this.b.b();
  }
}


/* Location:              C:\soft\dex2jar-2.0\Hill race-dex2jar.jar!\com\apm\insight\b\g.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */