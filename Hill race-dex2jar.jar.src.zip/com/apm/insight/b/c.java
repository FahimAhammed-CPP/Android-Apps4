package com.apm.insight.b;

import android.os.SystemClock;
import com.apm.insight.runtime.b;
import com.apm.insight.runtime.p;

public class c {
  private static long b;
  
  private final b a;
  
  private boolean c = false;
  
  private final Runnable d;
  
  c(b paramb) {
    Runnable runnable = new Runnable(this) {
        public void run() {
          if (c.a(this.a))
            return; 
          c.b(this.a).d();
          c.a(SystemClock.uptimeMillis());
          f.a();
          p.b().a(c.c(this.a), 500L);
          b.a(c.d());
        }
      };
    this.d = runnable;
    this.a = paramb;
    p.b().a(runnable, 5000L);
  }
  
  public static boolean c() {
    return (SystemClock.uptimeMillis() - b <= 15000L);
  }
  
  public void a() {
    if (this.c)
      return; 
    p.b().a(this.d, 5000L);
  }
  
  public void b() {
    this.c = true;
  }
}


/* Location:              C:\soft\dex2jar-2.0\Hill race-dex2jar.jar!\com\apm\insight\b\c.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */