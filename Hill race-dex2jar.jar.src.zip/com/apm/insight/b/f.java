package com.apm.insight.b;

import com.apm.insight.runtime.l;

public class f {
  private static boolean a = false;
  
  private static boolean b = false;
  
  private static boolean c = false;
  
  public static void a(boolean paramBoolean) {
    a = paramBoolean;
  }
  
  public static boolean a() {
    return l.a().b();
  }
  
  public static void b(boolean paramBoolean) {
    b = paramBoolean;
  }
}


/* Location:              C:\soft\dex2jar-2.0\Hill race-dex2jar.jar!\com\apm\insight\b\f.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */