package com.android.billingclient.api;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.content.pm.ResolveInfo;
import android.content.pm.ServiceInfo;
import android.graphics.Rect;
import android.os.Bundle;
import android.os.Handler;
import android.os.IBinder;
import android.os.Looper;
import android.os.Parcelable;
import android.os.RemoteException;
import android.os.ResultReceiver;
import android.text.TextUtils;
import android.view.View;
import androidx.core.app.c;
import com.google.android.gms.internal.play_billing.zzb;
import com.google.android.gms.internal.play_billing.zze;
import com.google.android.gms.internal.play_billing.zzg;
import com.google.android.gms.internal.play_billing.zzu;
import com.google.android.gms.internal.play_billing.zzz;
import java.lang.ref.WeakReference;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.concurrent.Callable;
import java.util.concurrent.CancellationException;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.Future;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.TimeoutException;
import org.json.JSONException;

class BillingClientImpl extends BillingClient {
  private volatile int zza = 0;
  
  private final String zzb;
  
  private final Handler zzc = new Handler(Looper.getMainLooper());
  
  private volatile zzp zzd;
  
  private Context zze;
  
  private volatile zze zzf;
  
  private volatile zzaq zzg;
  
  private boolean zzh;
  
  private boolean zzi;
  
  private int zzj = 0;
  
  private boolean zzk;
  
  private boolean zzl;
  
  private boolean zzm;
  
  private boolean zzn;
  
  private boolean zzo;
  
  private boolean zzp;
  
  private boolean zzq;
  
  private boolean zzr;
  
  private boolean zzs;
  
  private boolean zzt;
  
  private boolean zzu;
  
  private ExecutorService zzv;
  
  private BillingClientImpl(Activity paramActivity, boolean paramBoolean, String paramString) {
    this(paramActivity.getApplicationContext(), paramBoolean, new zzau(), paramString, null, null);
  }
  
  private BillingClientImpl(Context paramContext, boolean paramBoolean, PurchasesUpdatedListener paramPurchasesUpdatedListener, String paramString1, String paramString2, zzc paramzzc) {
    this.zzb = paramString1;
    initialize(paramContext, paramPurchasesUpdatedListener, paramBoolean, null);
  }
  
  private BillingClientImpl(String paramString) {
    this.zzb = paramString;
  }
  
  BillingClientImpl(String paramString, boolean paramBoolean, Context paramContext, PurchasesUpdatedListener paramPurchasesUpdatedListener, zzc paramzzc) {
    this(paramContext, paramBoolean, paramPurchasesUpdatedListener, zzI(), null, null);
  }
  
  BillingClientImpl(String paramString, boolean paramBoolean, Context paramContext, zzbf paramzzbf) {
    this.zzb = zzI();
    this.zze = paramContext.getApplicationContext();
    zzb.zzo("BillingClient", "Billing client should have a valid listener but the provided is null.");
    this.zzd = new zzp(this.zze, null);
    this.zzt = paramBoolean;
  }
  
  private void initialize(Context paramContext, PurchasesUpdatedListener paramPurchasesUpdatedListener, boolean paramBoolean, zzc paramzzc) {
    this.zze = paramContext.getApplicationContext();
    if (paramPurchasesUpdatedListener == null)
      zzb.zzo("BillingClient", "Billing client should have a valid listener but the provided is null."); 
    this.zzd = new zzp(this.zze, paramPurchasesUpdatedListener, paramzzc);
    this.zzt = paramBoolean;
    if (paramzzc != null) {
      paramBoolean = true;
    } else {
      paramBoolean = false;
    } 
    this.zzu = paramBoolean;
  }
  
  private int launchBillingFlowCpp(Activity paramActivity, BillingFlowParams paramBillingFlowParams) {
    return launchBillingFlow(paramActivity, paramBillingFlowParams).getResponseCode();
  }
  
  @zzj
  private void launchPriceChangeConfirmationFlow(Activity paramActivity, PriceChangeFlowParams paramPriceChangeFlowParams, long paramLong) {
    launchPriceChangeConfirmationFlow(paramActivity, paramPriceChangeFlowParams, new zzau(paramLong));
  }
  
  private void startConnection(long paramLong) {
    zzau zzau = new zzau(paramLong);
    if (isReady()) {
      zzb.zzn("BillingClient", "Service connection is valid. No need to re-initialize.");
      zzau.onBillingSetupFinished(zzbc.zzl);
      return;
    } 
    if (this.zza == 1) {
      zzb.zzo("BillingClient", "Client is already in the process of connecting to billing service.");
      zzau.onBillingSetupFinished(zzbc.zzd);
      return;
    } 
    if (this.zza == 3) {
      zzb.zzo("BillingClient", "Client was already closed and can't be reused. Please create another instance.");
      zzau.onBillingSetupFinished(zzbc.zzm);
      return;
    } 
    this.zza = 1;
    this.zzd.zze();
    zzb.zzn("BillingClient", "Starting in-app billing setup.");
    this.zzg = new zzaq(this, zzau, null);
    Intent intent = new Intent("com.android.vending.billing.InAppBillingService.BIND");
    intent.setPackage("com.android.vending");
    List list = this.zze.getPackageManager().queryIntentServices(intent, 0);
    if (list != null && !list.isEmpty()) {
      ServiceInfo serviceInfo = ((ResolveInfo)list.get(0)).serviceInfo;
      if (serviceInfo != null) {
        String str1 = serviceInfo.packageName;
        String str2 = serviceInfo.name;
        if ("com.android.vending".equals(str1) && str2 != null) {
          ComponentName componentName = new ComponentName(str1, str2);
          intent = new Intent(intent);
          intent.setComponent(componentName);
          intent.putExtra("playBillingLibraryVersion", this.zzb);
          if (this.zze.bindService(intent, this.zzg, 1)) {
            zzb.zzn("BillingClient", "Service was bonded successfully.");
            return;
          } 
          zzb.zzo("BillingClient", "Connection to Billing service is blocked.");
        } else {
          zzb.zzo("BillingClient", "The device doesn't have valid Play Store.");
        } 
      } 
    } 
    this.zza = 0;
    zzb.zzn("BillingClient", "Billing service unavailable on device.");
    zzau.onBillingSetupFinished(zzbc.zzc);
  }
  
  private final Handler zzF() {
    return (Looper.myLooper() == null) ? this.zzc : new Handler(Looper.myLooper());
  }
  
  private final BillingResult zzG(BillingResult paramBillingResult) {
    if (Thread.interrupted())
      return paramBillingResult; 
    this.zzc.post(new zzah(this, paramBillingResult));
    return paramBillingResult;
  }
  
  private final BillingResult zzH() {
    return (this.zza == 0 || this.zza == 3) ? zzbc.zzm : zzbc.zzj;
  }
  
  @SuppressLint({"PrivateApi"})
  private static String zzI() {
    try {
      return (String)Class.forName("com.android.billingclient.ktx.BuildConfig").getField("VERSION_NAME").get(null);
    } catch (Exception exception) {
      return "5.1.0";
    } 
  }
  
  private final Future zzJ(Callable<?> paramCallable, long paramLong, Runnable paramRunnable, Handler paramHandler) {
    if (this.zzv == null)
      this.zzv = Executors.newFixedThreadPool(zzb.zza, new zzam(this)); 
    try {
      Future<?> future = this.zzv.submit(paramCallable);
      double d = paramLong;
      paramHandler.postDelayed(new zzag(future, paramRunnable), (long)(d * 0.95D));
      return future;
    } catch (Exception exception) {
      zzb.zzp("BillingClient", "Async task throws exception!", exception);
      return null;
    } 
  }
  
  private final void zzK(BillingResult paramBillingResult, PriceChangeConfirmationListener paramPriceChangeConfirmationListener) {
    if (Thread.interrupted())
      return; 
    this.zzc.post(new zzy(paramPriceChangeConfirmationListener, paramBillingResult));
  }
  
  private final void zzL(String paramString, PurchaseHistoryResponseListener paramPurchaseHistoryResponseListener) {
    if (!isReady()) {
      paramPurchaseHistoryResponseListener.onPurchaseHistoryResponse(zzbc.zzm, null);
      return;
    } 
    if (zzJ(new zzak(this, paramString, paramPurchaseHistoryResponseListener), 30000L, new zzx(paramPurchaseHistoryResponseListener), zzF()) == null)
      paramPurchaseHistoryResponseListener.onPurchaseHistoryResponse(zzH(), null); 
  }
  
  private final void zzM(String paramString, PurchasesResponseListener paramPurchasesResponseListener) {
    if (!isReady()) {
      paramPurchasesResponseListener.onQueryPurchasesResponse(zzbc.zzm, (List<Purchase>)zzu.zzl());
      return;
    } 
    if (TextUtils.isEmpty(paramString)) {
      zzb.zzo("BillingClient", "Please provide a valid product type.");
      paramPurchasesResponseListener.onQueryPurchasesResponse(zzbc.zzg, (List<Purchase>)zzu.zzl());
      return;
    } 
    if (zzJ(new zzaj(this, paramString, paramPurchasesResponseListener), 30000L, new zzae(paramPurchasesResponseListener), zzF()) == null)
      paramPurchasesResponseListener.onQueryPurchasesResponse(zzH(), (List<Purchase>)zzu.zzl()); 
  }
  
  public final void acknowledgePurchase(AcknowledgePurchaseParams paramAcknowledgePurchaseParams, AcknowledgePurchaseResponseListener paramAcknowledgePurchaseResponseListener) {
    if (!isReady()) {
      paramAcknowledgePurchaseResponseListener.onAcknowledgePurchaseResponse(zzbc.zzm);
      return;
    } 
    if (TextUtils.isEmpty(paramAcknowledgePurchaseParams.getPurchaseToken())) {
      zzb.zzo("BillingClient", "Please provide a valid purchase token.");
      paramAcknowledgePurchaseResponseListener.onAcknowledgePurchaseResponse(zzbc.zzi);
      return;
    } 
    if (!this.zzm) {
      paramAcknowledgePurchaseResponseListener.onAcknowledgePurchaseResponse(zzbc.zzb);
      return;
    } 
    if (zzJ(new zzaa(this, paramAcknowledgePurchaseParams, paramAcknowledgePurchaseResponseListener), 30000L, new zzab(paramAcknowledgePurchaseResponseListener), zzF()) == null)
      paramAcknowledgePurchaseResponseListener.onAcknowledgePurchaseResponse(zzH()); 
  }
  
  public final void consumeAsync(ConsumeParams paramConsumeParams, ConsumeResponseListener paramConsumeResponseListener) {
    if (!isReady()) {
      paramConsumeResponseListener.onConsumeResponse(zzbc.zzm, paramConsumeParams.getPurchaseToken());
      return;
    } 
    if (zzJ(new zzv(this, paramConsumeParams, paramConsumeResponseListener), 30000L, new zzw(paramConsumeResponseListener, paramConsumeParams), zzF()) == null)
      paramConsumeResponseListener.onConsumeResponse(zzH(), paramConsumeParams.getPurchaseToken()); 
  }
  
  public final void endConnection() {
    Exception exception;
    try {
      this.zzd.zzd();
      if (this.zzg != null)
        this.zzg.zzc(); 
      if (this.zzg != null && this.zzf != null) {
        zzb.zzn("BillingClient", "Unbinding from service.");
        this.zze.unbindService(this.zzg);
        this.zzg = null;
      } 
      this.zzf = null;
      ExecutorService executorService = this.zzv;
      if (executorService != null) {
        executorService.shutdownNow();
        this.zzv = null;
      } 
      this.zza = 3;
      return;
    } catch (Exception null) {
      zzb.zzp("BillingClient", "There was an exception while ending connection!", exception);
      this.zza = 3;
      return;
    } finally {}
    this.zza = 3;
    throw exception;
  }
  
  public final int getConnectionState() {
    return this.zza;
  }
  
  public final BillingResult isFeatureSupported(String paramString) {
    byte b;
    if (!isReady())
      return zzbc.zzm; 
    switch (paramString.hashCode()) {
      default:
        b = -1;
        break;
      case 1987365622:
        if (paramString.equals("subscriptions")) {
          b = 0;
          break;
        } 
      case 207616302:
        if (paramString.equals("priceChangeConfirmation")) {
          b = 2;
          break;
        } 
      case 102279:
        if (paramString.equals("ggg")) {
          b = 9;
          break;
        } 
      case 101286:
        if (paramString.equals("fff")) {
          b = 8;
          break;
        } 
      case 100293:
        if (paramString.equals("eee")) {
          b = 7;
          break;
        } 
      case 99300:
        if (paramString.equals("ddd")) {
          b = 5;
          break;
        } 
      case 98307:
        if (paramString.equals("ccc")) {
          b = 6;
          break;
        } 
      case 97314:
        if (paramString.equals("bbb")) {
          b = 3;
          break;
        } 
      case 96321:
        if (paramString.equals("aaa")) {
          b = 4;
          break;
        } 
      case -422092961:
        if (paramString.equals("subscriptionsUpdate")) {
          b = 1;
          break;
        } 
    } 
    switch (b) {
      default:
        zzb.zzo("BillingClient", "Unsupported feature: ".concat(paramString));
        return zzbc.zzy;
      case 9:
        return this.zzs ? zzbc.zzl : zzbc.zzz;
      case 8:
        return this.zzs ? zzbc.zzl : zzbc.zzv;
      case 6:
      case 7:
        return this.zzr ? zzbc.zzl : zzbc.zzt;
      case 5:
        return this.zzp ? zzbc.zzl : zzbc.zzu;
      case 4:
        return this.zzq ? zzbc.zzl : zzbc.zzs;
      case 3:
        return this.zzo ? zzbc.zzl : zzbc.zzw;
      case 2:
        return this.zzl ? zzbc.zzl : zzbc.zzr;
      case 1:
        return this.zzi ? zzbc.zzl : zzbc.zzp;
      case 0:
        break;
    } 
    return this.zzh ? zzbc.zzl : zzbc.zzo;
  }
  
  public final boolean isReady() {
    return (this.zza == 2 && this.zzf != null && this.zzg != null);
  }
  
  public final BillingResult launchBillingFlow(Activity paramActivity, BillingFlowParams paramBillingFlowParams) {
    String str1;
    String str2;
    BillingFlowParams.ProductDetailsParams productDetailsParams2;
    Bundle bundle;
    BillingClientImpl billingClientImpl = this;
    if (!isReady()) {
      BillingResult billingResult = zzbc.zzm;
      billingClientImpl.zzG(billingResult);
      return billingResult;
    } 
    ArrayList<SkuDetails> arrayList = paramBillingFlowParams.zze();
    List<BillingFlowParams.ProductDetailsParams> list = paramBillingFlowParams.zzf();
    SkuDetails skuDetails = (SkuDetails)zzz.zza(arrayList, null);
    BillingFlowParams.ProductDetailsParams productDetailsParams1 = (BillingFlowParams.ProductDetailsParams)zzz.zza(list, null);
    if (skuDetails != null) {
      str1 = skuDetails.getSku();
      str2 = skuDetails.getType();
    } else {
      str1 = productDetailsParams1.zza().getProductId();
      str2 = productDetailsParams1.zza().getProductType();
    } 
    if (!str2.equals("subs") || billingClientImpl.zzh) {
      if (!paramBillingFlowParams.zzo() || billingClientImpl.zzk) {
        if (arrayList.size() <= 1 || billingClientImpl.zzr) {
          if (list.isEmpty() || billingClientImpl.zzs) {
            if (billingClientImpl.zzk) {
              SkuDetails skuDetails1;
              bundle = zzb.zzf(paramBillingFlowParams, billingClientImpl.zzm, billingClientImpl.zzt, billingClientImpl.zzu, billingClientImpl.zzb);
              if (!arrayList.isEmpty()) {
                ArrayList<String> arrayList1 = new ArrayList();
                ArrayList<String> arrayList2 = new ArrayList();
                ArrayList<String> arrayList3 = new ArrayList();
                ArrayList<Integer> arrayList4 = new ArrayList();
                ArrayList<String> arrayList5 = new ArrayList();
                Iterator<SkuDetails> iterator = arrayList.iterator();
                int m = 0;
                int k = 0;
                int j = 0;
                int i = 0;
                while (iterator.hasNext()) {
                  SkuDetails skuDetails2 = iterator.next();
                  if (!skuDetails2.zzf().isEmpty())
                    arrayList1.add(skuDetails2.zzf()); 
                  String str3 = skuDetails2.zzc();
                  String str4 = skuDetails2.zzb();
                  int i1 = skuDetails2.zza();
                  String str5 = skuDetails2.zze();
                  arrayList2.add(str3);
                  m |= TextUtils.isEmpty(str3) ^ true;
                  arrayList3.add(str4);
                  int n = k | TextUtils.isEmpty(str4) ^ true;
                  arrayList4.add(Integer.valueOf(i1));
                  if (i1 != 0) {
                    k = 1;
                  } else {
                    k = 0;
                  } 
                  j |= k;
                  i |= TextUtils.isEmpty(str5) ^ true;
                  arrayList5.add(str5);
                  k = n;
                } 
                if (!arrayList1.isEmpty())
                  bundle.putStringArrayList("skuDetailsTokens", arrayList1); 
                if (m != 0)
                  bundle.putStringArrayList("SKU_OFFER_ID_TOKEN_LIST", arrayList2); 
                if (k != 0)
                  bundle.putStringArrayList("SKU_OFFER_ID_LIST", arrayList3); 
                if (j != 0)
                  bundle.putIntegerArrayList("SKU_OFFER_TYPE_LIST", arrayList4); 
                if (i != 0)
                  bundle.putStringArrayList("SKU_SERIALIZED_DOCID_LIST", arrayList5); 
                productDetailsParams2 = productDetailsParams1;
                skuDetails1 = skuDetails;
                if (arrayList.size() > 1) {
                  ArrayList<String> arrayList6 = new ArrayList(arrayList.size() - 1);
                  ArrayList<String> arrayList7 = new ArrayList(arrayList.size() - 1);
                  for (i = 1; i < arrayList.size(); i++) {
                    arrayList6.add(((SkuDetails)arrayList.get(i)).getSku());
                    arrayList7.add(((SkuDetails)arrayList.get(i)).getType());
                  } 
                  bundle.putStringArrayList("additionalSkus", arrayList6);
                  bundle.putStringArrayList("additionalSkuTypes", arrayList7);
                  BillingFlowParams.ProductDetailsParams productDetailsParams = productDetailsParams1;
                  SkuDetails skuDetails2 = skuDetails;
                } 
              } else {
                arrayList = new ArrayList<SkuDetails>(list.size() - 1);
                ArrayList<String> arrayList3 = new ArrayList(list.size() - 1);
                ArrayList<String> arrayList1 = new ArrayList();
                ArrayList<String> arrayList2 = new ArrayList();
                ArrayList<String> arrayList4 = new ArrayList();
                for (int i = 0; i < list.size(); i++) {
                  BillingFlowParams.ProductDetailsParams productDetailsParams = list.get(i);
                  ProductDetails productDetails = productDetailsParams.zza();
                  if (!productDetails.zzb().isEmpty())
                    arrayList1.add(productDetails.zzb()); 
                  arrayList2.add(productDetailsParams.zzb());
                  if (!TextUtils.isEmpty(productDetails.zzc()))
                    arrayList4.add(productDetails.zzc()); 
                  if (i > 0) {
                    arrayList.add(((BillingFlowParams.ProductDetailsParams)list.get(i)).zza().getProductId());
                    arrayList3.add(((BillingFlowParams.ProductDetailsParams)list.get(i)).zza().getProductType());
                  } 
                } 
                bundle.putStringArrayList("SKU_OFFER_ID_TOKEN_LIST", arrayList2);
                if (!arrayList1.isEmpty())
                  bundle.putStringArrayList("skuDetailsTokens", arrayList1); 
                if (!arrayList4.isEmpty())
                  bundle.putStringArrayList("SKU_SERIALIZED_DOCID_LIST", arrayList4); 
                productDetailsParams2 = productDetailsParams1;
                skuDetails1 = skuDetails;
                if (!arrayList.isEmpty()) {
                  bundle.putStringArrayList("additionalSkus", arrayList);
                  bundle.putStringArrayList("additionalSkuTypes", arrayList3);
                  skuDetails1 = skuDetails;
                  productDetailsParams2 = productDetailsParams1;
                } 
              } 
              boolean bool = bundle.containsKey("SKU_OFFER_ID_TOKEN_LIST");
              BillingClientImpl billingClientImpl1 = this;
              if (!bool || billingClientImpl1.zzp) {
                if (skuDetails1 != null && !TextUtils.isEmpty(skuDetails1.zzd())) {
                  bundle.putString("skuPackageName", skuDetails1.zzd());
                } else if (productDetailsParams2 != null && !TextUtils.isEmpty(productDetailsParams2.zza().zza())) {
                  bundle.putString("skuPackageName", productDetailsParams2.zza().zza());
                } else {
                  boolean bool2 = false;
                  if (!TextUtils.isEmpty(null))
                    bundle.putString("accountName", null); 
                } 
                boolean bool1 = true;
              } else {
                BillingResult billingResult = zzbc.zzu;
                billingClientImpl1.zzG(billingResult);
                return billingResult;
              } 
            } else {
              String str = "BillingClient";
              Future future = zzJ(new zzad((BillingClientImpl)productDetailsParams2, str1, str2), 5000L, null, ((BillingClientImpl)productDetailsParams2).zzc);
              BillingClientImpl billingClientImpl1 = this;
            } 
          } else {
            zzb.zzo("BillingClient", "Current client doesn't support purchases with ProductDetails.");
            BillingResult billingResult = zzbc.zzv;
            productDetailsParams2.zzG(billingResult);
            return billingResult;
          } 
        } else {
          zzb.zzo("BillingClient", "Current client doesn't support multi-item purchases.");
          BillingResult billingResult = zzbc.zzt;
          productDetailsParams2.zzG(billingResult);
          return billingResult;
        } 
      } else {
        zzb.zzo("BillingClient", "Current client doesn't support extra params for buy intent.");
        BillingResult billingResult = zzbc.zzh;
        productDetailsParams2.zzG(billingResult);
        return billingResult;
      } 
    } else {
      zzb.zzo("BillingClient", "Current client doesn't support subscriptions.");
      BillingResult billingResult = zzbc.zzo;
      productDetailsParams2.zzG(billingResult);
      return billingResult;
    } 
    if (!TextUtils.isEmpty(null))
      bundle.putString("accountName", null); 
  }
  
  @zzj
  public void launchPriceChangeConfirmationFlow(Activity paramActivity, PriceChangeFlowParams paramPriceChangeFlowParams, PriceChangeConfirmationListener paramPriceChangeConfirmationListener) {
    if (!isReady()) {
      zzK(zzbc.zzm, paramPriceChangeConfirmationListener);
      return;
    } 
    if (paramPriceChangeFlowParams == null || paramPriceChangeFlowParams.getSkuDetails() == null) {
      zzb.zzo("BillingClient", "Please fix the input params. priceChangeFlowParams must contain valid sku.");
      zzK(zzbc.zzk, paramPriceChangeConfirmationListener);
      return;
    } 
    String str = paramPriceChangeFlowParams.getSkuDetails().getSku();
    if (str == null) {
      zzb.zzo("BillingClient", "Please fix the input params. priceChangeFlowParams must contain valid sku.");
      zzK(zzbc.zzk, paramPriceChangeConfirmationListener);
      return;
    } 
    if (!this.zzl) {
      zzb.zzo("BillingClient", "Current client doesn't support price change confirmation flow.");
      zzK(zzbc.zzr, paramPriceChangeConfirmationListener);
      return;
    } 
    Bundle bundle = new Bundle();
    bundle.putString("playBillingLibraryVersion", this.zzb);
    bundle.putBoolean("subs_price_change", true);
    Future<Bundle> future = zzJ(new zzs(this, str, bundle), 5000L, null, this.zzc);
    try {
      StringBuilder stringBuilder1;
      Bundle bundle1 = future.get(5000L, TimeUnit.MILLISECONDS);
      int i = zzb.zzb(bundle1, "BillingClient");
      String str1 = zzb.zzk(bundle1, "BillingClient");
      BillingResult.Builder builder = BillingResult.newBuilder();
      builder.setResponseCode(i);
      builder.setDebugMessage(str1);
      BillingResult billingResult = builder.build();
      if (i != 0) {
        stringBuilder1 = new StringBuilder();
        stringBuilder1.append("Unable to launch price change flow, error response code: ");
        stringBuilder1.append(i);
        zzb.zzo("BillingClient", stringBuilder1.toString());
        zzK(billingResult, paramPriceChangeConfirmationListener);
        return;
      } 
      zzai zzai = new zzai(this, this.zzc, paramPriceChangeConfirmationListener);
      Intent intent = new Intent((Context)stringBuilder1, ProxyBillingActivity.class);
      intent.putExtra("SUBS_MANAGEMENT_INTENT", bundle1.getParcelable("SUBS_MANAGEMENT_INTENT"));
      intent.putExtra("result_receiver", (Parcelable)zzai);
      stringBuilder1.startActivity(intent);
      return;
    } catch (TimeoutException null) {
    
    } catch (CancellationException null) {
    
    } catch (Exception exception) {
      StringBuilder stringBuilder1 = new StringBuilder();
      stringBuilder1.append("Exception caught while launching Price Change Flow for sku: ");
      stringBuilder1.append(str);
      stringBuilder1.append("; try to reconnect");
      zzb.zzp("BillingClient", stringBuilder1.toString(), exception);
      zzK(zzbc.zzm, paramPriceChangeConfirmationListener);
      return;
    } 
    StringBuilder stringBuilder = new StringBuilder();
    stringBuilder.append("Time out while launching Price Change Flow for sku: ");
    stringBuilder.append(str);
    stringBuilder.append("; try to reconnect");
    zzb.zzp("BillingClient", stringBuilder.toString(), exception);
    zzK(zzbc.zzn, paramPriceChangeConfirmationListener);
  }
  
  @zzk
  public void queryProductDetailsAsync(QueryProductDetailsParams paramQueryProductDetailsParams, ProductDetailsResponseListener paramProductDetailsResponseListener) {
    if (!isReady()) {
      paramProductDetailsResponseListener.onProductDetailsResponse(zzbc.zzm, new ArrayList<ProductDetails>());
      return;
    } 
    if (!this.zzs) {
      zzb.zzo("BillingClient", "Querying product details is not supported.");
      paramProductDetailsResponseListener.onProductDetailsResponse(zzbc.zzv, new ArrayList<ProductDetails>());
      return;
    } 
    if (zzJ(new zzt(this, paramQueryProductDetailsParams, paramProductDetailsResponseListener), 30000L, new zzu(paramProductDetailsResponseListener), zzF()) == null)
      paramProductDetailsResponseListener.onProductDetailsResponse(zzH(), new ArrayList<ProductDetails>()); 
  }
  
  @zzk
  public void queryPurchaseHistoryAsync(QueryPurchaseHistoryParams paramQueryPurchaseHistoryParams, PurchaseHistoryResponseListener paramPurchaseHistoryResponseListener) {
    zzL(paramQueryPurchaseHistoryParams.zza(), paramPurchaseHistoryResponseListener);
  }
  
  public final void queryPurchaseHistoryAsync(String paramString, PurchaseHistoryResponseListener paramPurchaseHistoryResponseListener) {
    zzL(paramString, paramPurchaseHistoryResponseListener);
  }
  
  @zzk
  public void queryPurchasesAsync(QueryPurchasesParams paramQueryPurchasesParams, PurchasesResponseListener paramPurchasesResponseListener) {
    zzM(paramQueryPurchasesParams.zza(), paramPurchasesResponseListener);
  }
  
  @zzl
  public void queryPurchasesAsync(String paramString, PurchasesResponseListener paramPurchasesResponseListener) {
    zzM(paramString, paramPurchasesResponseListener);
  }
  
  public final void querySkuDetailsAsync(SkuDetailsParams paramSkuDetailsParams, SkuDetailsResponseListener paramSkuDetailsResponseListener) {
    if (!isReady()) {
      paramSkuDetailsResponseListener.onSkuDetailsResponse(zzbc.zzm, null);
      return;
    } 
    String str = paramSkuDetailsParams.getSkuType();
    List<String> list = paramSkuDetailsParams.getSkusList();
    if (!TextUtils.isEmpty(str)) {
      if (list != null) {
        ArrayList<zzbx> arrayList = new ArrayList();
        for (String str1 : list) {
          zzbv zzbv = new zzbv(null);
          zzbv.zza(str1);
          arrayList.add(zzbv.zzb());
        } 
        if (zzJ(new zzr(this, str, arrayList, null, paramSkuDetailsResponseListener), 30000L, new zzz(paramSkuDetailsResponseListener), zzF()) == null)
          paramSkuDetailsResponseListener.onSkuDetailsResponse(zzH(), null); 
        return;
      } 
      zzb.zzo("BillingClient", "Please fix the input params. The list of SKUs can't be empty - set SKU list or SkuWithOffer list.");
      paramSkuDetailsResponseListener.onSkuDetailsResponse(zzbc.zze, null);
      return;
    } 
    zzb.zzo("BillingClient", "Please fix the input params. SKU type can't be empty.");
    paramSkuDetailsResponseListener.onSkuDetailsResponse(zzbc.zzf, null);
  }
  
  @zzg
  public BillingResult showInAppMessages(Activity paramActivity, InAppMessageParams paramInAppMessageParams, InAppMessageResponseListener paramInAppMessageResponseListener) {
    if (!isReady()) {
      zzb.zzo("BillingClient", "Service disconnected.");
      return zzbc.zzm;
    } 
    if (!this.zzo) {
      zzb.zzo("BillingClient", "Current client doesn't support showing in-app messages.");
      return zzbc.zzw;
    } 
    View view = paramActivity.findViewById(16908290);
    IBinder iBinder = view.getWindowToken();
    Rect rect = new Rect();
    view.getGlobalVisibleRect(rect);
    Bundle bundle = new Bundle();
    c.a(bundle, "KEY_WINDOW_TOKEN", iBinder);
    bundle.putInt("KEY_DIMEN_LEFT", rect.left);
    bundle.putInt("KEY_DIMEN_TOP", rect.top);
    bundle.putInt("KEY_DIMEN_RIGHT", rect.right);
    bundle.putInt("KEY_DIMEN_BOTTOM", rect.bottom);
    bundle.putString("playBillingLibraryVersion", this.zzb);
    bundle.putIntegerArrayList("KEY_CATEGORY_IDS", paramInAppMessageParams.getInAppMessageCategoriesToShow());
    zzJ(new zzaf(this, bundle, paramActivity, new zzal(this, this.zzc, paramInAppMessageResponseListener)), 5000L, null, this.zzc);
    return zzbc.zzl;
  }
  
  public final void startConnection(BillingClientStateListener paramBillingClientStateListener) {
    if (isReady()) {
      zzb.zzn("BillingClient", "Service connection is valid. No need to re-initialize.");
      paramBillingClientStateListener.onBillingSetupFinished(zzbc.zzl);
      return;
    } 
    if (this.zza == 1) {
      zzb.zzo("BillingClient", "Client is already in the process of connecting to billing service.");
      paramBillingClientStateListener.onBillingSetupFinished(zzbc.zzd);
      return;
    } 
    if (this.zza == 3) {
      zzb.zzo("BillingClient", "Client was already closed and can't be reused. Please create another instance.");
      paramBillingClientStateListener.onBillingSetupFinished(zzbc.zzm);
      return;
    } 
    this.zza = 1;
    this.zzd.zze();
    zzb.zzn("BillingClient", "Starting in-app billing setup.");
    this.zzg = new zzaq(this, paramBillingClientStateListener, null);
    Intent intent = new Intent("com.android.vending.billing.InAppBillingService.BIND");
    intent.setPackage("com.android.vending");
    List list = this.zze.getPackageManager().queryIntentServices(intent, 0);
    if (list != null && !list.isEmpty()) {
      ServiceInfo serviceInfo = ((ResolveInfo)list.get(0)).serviceInfo;
      if (serviceInfo != null) {
        String str1 = serviceInfo.packageName;
        String str2 = serviceInfo.name;
        if ("com.android.vending".equals(str1) && str2 != null) {
          ComponentName componentName = new ComponentName(str1, str2);
          intent = new Intent(intent);
          intent.setComponent(componentName);
          intent.putExtra("playBillingLibraryVersion", this.zzb);
          if (this.zze.bindService(intent, this.zzg, 1)) {
            zzb.zzn("BillingClient", "Service was bonded successfully.");
            return;
          } 
          zzb.zzo("BillingClient", "Connection to Billing service is blocked.");
        } else {
          zzb.zzo("BillingClient", "The device doesn't have valid Play Store.");
        } 
      } 
    } 
    this.zza = 0;
    zzb.zzn("BillingClient", "Billing service unavailable on device.");
    paramBillingClientStateListener.onBillingSetupFinished(zzbc.zzc);
  }
}


/* Location:              C:\soft\dex2jar-2.0\Hill race-dex2jar.jar!\com\android\billingclient\api\BillingClientImpl.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */