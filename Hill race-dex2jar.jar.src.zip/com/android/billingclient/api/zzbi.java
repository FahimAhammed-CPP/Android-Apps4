package com.android.billingclient.api;

import org.json.JSONException;
import org.json.JSONObject;

public final class zzbi {
  zzbi(JSONObject paramJSONObject) throws JSONException {
    paramJSONObject.getInt("maximumQuantity");
    paramJSONObject.getInt("remainingQuantity");
  }
}


/* Location:              C:\soft\dex2jar-2.0\Hill race-dex2jar.jar!\com\android\billingclient\api\zzbi.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */