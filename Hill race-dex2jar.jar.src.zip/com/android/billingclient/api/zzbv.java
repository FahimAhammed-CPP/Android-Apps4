package com.android.billingclient.api;

import android.text.TextUtils;

public final class zzbv {
  private String zza;
  
  private zzbv() {}
  
  public final zzbv zza(String paramString) {
    this.zza = paramString;
    return this;
  }
  
  public final zzbx zzb() {
    if (!TextUtils.isEmpty(this.zza))
      return new zzbx(this.zza, null, null, 0, null); 
    throw new IllegalArgumentException("SKU must be set.");
  }
}


/* Location:              C:\soft\dex2jar-2.0\Hill race-dex2jar.jar!\com\android\billingclient\api\zzbv.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */