package com.android.billingclient.api;

import java.util.Arrays;
import org.json.JSONObject;

public final class zze {
  private final String zza;
  
  private final String zzb;
  
  private final String zzc;
  
  public final boolean equals(Object paramObject) {
    if (this == paramObject)
      return true; 
    if (!(paramObject instanceof zze))
      return false; 
    zze zze1 = (zze)paramObject;
    if (this.zza.equals(zze1.zza) && this.zzb.equals(zze1.zzb)) {
      paramObject = this.zzc;
      String str = zze1.zzc;
      if (paramObject == str || (paramObject != null && paramObject.equals(str)))
        return true; 
    } 
    return false;
  }
  
  public final int hashCode() {
    return Arrays.hashCode(new Object[] { this.zza, this.zzb, this.zzc });
  }
  
  public final String toString() {
    return String.format("{id: %s, type: %s, offer token: %s}", new Object[] { this.zza, this.zzb, this.zzc });
  }
}


/* Location:              C:\soft\dex2jar-2.0\Hill race-dex2jar.jar!\com\android\billingclient\api\zze.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */