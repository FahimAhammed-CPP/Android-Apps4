package com.android.billingclient.api;

import java.util.List;

final class zzat {
  private final List zza;
  
  private final BillingResult zzb;
  
  zzat(BillingResult paramBillingResult, List paramList) {
    this.zza = paramList;
    this.zzb = paramBillingResult;
  }
  
  final BillingResult zza() {
    return this.zzb;
  }
  
  final List zzb() {
    return this.zza;
  }
}


/* Location:              C:\soft\dex2jar-2.0\Hill race-dex2jar.jar!\com\android\billingclient\api\zzat.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */