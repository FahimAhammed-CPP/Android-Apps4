package com.android.billingclient.api;

import android.text.TextUtils;
import com.google.android.gms.internal.play_billing.zzu;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.util.ArrayList;
import java.util.List;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

@zzk
public final class ProductDetails {
  private final String zza;
  
  private final JSONObject zzb;
  
  private final String zzc;
  
  private final String zzd;
  
  private final String zze;
  
  private final String zzf;
  
  private final String zzg;
  
  private final String zzh;
  
  private final String zzi;
  
  private final List zzj;
  
  private final List zzk;
  
  private final zzbi zzl;
  
  ProductDetails(String paramString) throws JSONException {
    this.zza = paramString;
    JSONObject jSONObject = new JSONObject(paramString);
    this.zzb = jSONObject;
    String str = jSONObject.optString("productId");
    this.zzc = str;
    paramString = jSONObject.optString("type");
    this.zzd = paramString;
    if (!TextUtils.isEmpty(str)) {
      if (!TextUtils.isEmpty(paramString)) {
        ArrayList<SubscriptionOfferDetails> arrayList;
        this.zze = jSONObject.optString("title");
        this.zzf = jSONObject.optString("name");
        this.zzg = jSONObject.optString("description");
        this.zzh = jSONObject.optString("skuDetailsToken");
        this.zzi = jSONObject.optString("serializedDocid");
        JSONArray jSONArray = jSONObject.optJSONArray("subscriptionOfferDetails");
        byte b = 0;
        if (jSONArray != null) {
          arrayList = new ArrayList();
          for (int i = 0; i < jSONArray.length(); i++)
            arrayList.add(new SubscriptionOfferDetails(jSONArray.getJSONObject(i))); 
          this.zzj = arrayList;
        } else {
          if (arrayList.equals("subs") || arrayList.equals("play_pass_subs")) {
            arrayList = new ArrayList<SubscriptionOfferDetails>();
          } else {
            arrayList = null;
          } 
          this.zzj = arrayList;
        } 
        JSONObject jSONObject1 = this.zzb.optJSONObject("oneTimePurchaseOfferDetails");
        jSONArray = this.zzb.optJSONArray("oneTimePurchaseOfferDetailsList");
        ArrayList<OneTimePurchaseOfferDetails> arrayList1 = new ArrayList();
        if (jSONArray != null) {
          for (int i = b; i < jSONArray.length(); i++)
            arrayList1.add(new OneTimePurchaseOfferDetails(jSONArray.getJSONObject(i))); 
          this.zzk = arrayList1;
        } else if (jSONObject1 != null) {
          arrayList1.add(new OneTimePurchaseOfferDetails(jSONObject1));
          this.zzk = arrayList1;
        } else {
          this.zzk = null;
        } 
        jSONObject1 = this.zzb.optJSONObject("limitedQuantityInfo");
        if (jSONObject1 != null) {
          this.zzl = new zzbi(jSONObject1);
          return;
        } 
        this.zzl = null;
        return;
      } 
      throw new IllegalArgumentException("Product type cannot be empty.");
    } 
    throw new IllegalArgumentException("Product id cannot be empty.");
  }
  
  public boolean equals(Object paramObject) {
    if (this == paramObject)
      return true; 
    if (!(paramObject instanceof ProductDetails))
      return false; 
    paramObject = paramObject;
    return TextUtils.equals(this.zza, ((ProductDetails)paramObject).zza);
  }
  
  @zzk
  public String getDescription() {
    return this.zzg;
  }
  
  @zzk
  public String getName() {
    return this.zzf;
  }
  
  @zzh
  public OneTimePurchaseOfferDetails getOneTimePurchaseOfferDetails() {
    List list = this.zzk;
    return (list != null && !list.isEmpty()) ? this.zzk.get(0) : null;
  }
  
  @zzk
  public String getProductId() {
    return this.zzc;
  }
  
  @zzk
  public String getProductType() {
    return this.zzd;
  }
  
  @zzk
  public List<SubscriptionOfferDetails> getSubscriptionOfferDetails() {
    return this.zzj;
  }
  
  @zzk
  public String getTitle() {
    return this.zze;
  }
  
  public int hashCode() {
    return this.zza.hashCode();
  }
  
  public String toString() {
    String str1 = this.zza;
    String str2 = this.zzb.toString();
    String str3 = this.zzc;
    String str4 = this.zzd;
    String str5 = this.zze;
    String str6 = this.zzh;
    String str7 = String.valueOf(this.zzj);
    StringBuilder stringBuilder = new StringBuilder();
    stringBuilder.append("ProductDetails{jsonString='");
    stringBuilder.append(str1);
    stringBuilder.append("', parsedJson=");
    stringBuilder.append(str2);
    stringBuilder.append(", productId='");
    stringBuilder.append(str3);
    stringBuilder.append("', productType='");
    stringBuilder.append(str4);
    stringBuilder.append("', title='");
    stringBuilder.append(str5);
    stringBuilder.append("', productDetailsToken='");
    stringBuilder.append(str6);
    stringBuilder.append("', subscriptionOfferDetails=");
    stringBuilder.append(str7);
    stringBuilder.append("}");
    return stringBuilder.toString();
  }
  
  public final String zza() {
    return this.zzb.optString("packageName");
  }
  
  final String zzb() {
    return this.zzh;
  }
  
  public String zzc() {
    return this.zzi;
  }
  
  @zzh
  public static final class OneTimePurchaseOfferDetails {
    private final String zza;
    
    private final long zzb;
    
    private final String zzc;
    
    private final String zzd;
    
    private final String zze;
    
    private final zzu zzf;
    
    OneTimePurchaseOfferDetails(JSONObject param1JSONObject) throws JSONException {
      this.zza = param1JSONObject.optString("formattedPrice");
      this.zzb = param1JSONObject.optLong("priceAmountMicros");
      this.zzc = param1JSONObject.optString("priceCurrencyCode");
      this.zzd = param1JSONObject.optString("offerIdToken");
      this.zze = param1JSONObject.optString("offerId");
      param1JSONObject.optInt("offerType");
      JSONArray jSONArray = param1JSONObject.optJSONArray("offerTags");
      ArrayList<String> arrayList = new ArrayList();
      if (jSONArray != null)
        for (int i = 0; i < jSONArray.length(); i++)
          arrayList.add(jSONArray.getString(i));  
      this.zzf = zzu.zzk(arrayList);
    }
    
    @zzh
    public String getFormattedPrice() {
      return this.zza;
    }
    
    @zzh
    public long getPriceAmountMicros() {
      return this.zzb;
    }
    
    @zzh
    public String getPriceCurrencyCode() {
      return this.zzc;
    }
    
    public final String zza() {
      return this.zzd;
    }
  }
  
  @zzk
  public static final class PricingPhase {
    private final int billingCycleCount;
    
    private final String billingPeriod;
    
    private final String formattedPrice;
    
    private final long priceAmountMicros;
    
    private final String priceCurrencyCode;
    
    private final int recurrenceMode;
    
    PricingPhase(JSONObject param1JSONObject) {
      this.billingPeriod = param1JSONObject.optString("billingPeriod");
      this.priceCurrencyCode = param1JSONObject.optString("priceCurrencyCode");
      this.formattedPrice = param1JSONObject.optString("formattedPrice");
      this.priceAmountMicros = param1JSONObject.optLong("priceAmountMicros");
      this.recurrenceMode = param1JSONObject.optInt("recurrenceMode");
      this.billingCycleCount = param1JSONObject.optInt("billingCycleCount");
    }
    
    public int getBillingCycleCount() {
      return this.billingCycleCount;
    }
    
    public String getBillingPeriod() {
      return this.billingPeriod;
    }
    
    public String getFormattedPrice() {
      return this.formattedPrice;
    }
    
    public long getPriceAmountMicros() {
      return this.priceAmountMicros;
    }
    
    public String getPriceCurrencyCode() {
      return this.priceCurrencyCode;
    }
    
    public int getRecurrenceMode() {
      return this.recurrenceMode;
    }
  }
  
  @zzk
  public static class PricingPhases {
    private final List<ProductDetails.PricingPhase> pricingPhaseList;
    
    PricingPhases(JSONArray param1JSONArray) {
      ArrayList<ProductDetails.PricingPhase> arrayList = new ArrayList();
      if (param1JSONArray != null)
        for (int i = 0; i < param1JSONArray.length(); i++) {
          JSONObject jSONObject = param1JSONArray.optJSONObject(i);
          if (jSONObject != null)
            arrayList.add(new ProductDetails.PricingPhase(jSONObject)); 
        }  
      this.pricingPhaseList = arrayList;
    }
    
    public List<ProductDetails.PricingPhase> getPricingPhaseList() {
      return this.pricingPhaseList;
    }
  }
  
  @Retention(RetentionPolicy.SOURCE)
  @zzk
  public static @interface RecurrenceMode {
    @zzk
    public static final int FINITE_RECURRING = 2;
    
    @zzk
    public static final int INFINITE_RECURRING = 1;
    
    @zzk
    public static final int NON_RECURRING = 3;
  }
  
  @zzk
  public static final class SubscriptionOfferDetails {
    private final String zza;
    
    private final String zzb;
    
    private final String zzc;
    
    private final ProductDetails.PricingPhases zzd;
    
    private final List zze;
    
    private final zzbh zzf;
    
    SubscriptionOfferDetails(JSONObject param1JSONObject) throws JSONException {
      zzbh zzbh1;
      this.zza = param1JSONObject.optString("basePlanId");
      String str = param1JSONObject.optString("offerId");
      boolean bool = str.isEmpty();
      JSONObject jSONObject2 = null;
      if (true == bool)
        str = null; 
      this.zzb = str;
      this.zzc = param1JSONObject.getString("offerIdToken");
      this.zzd = new ProductDetails.PricingPhases(param1JSONObject.getJSONArray("pricingPhases"));
      JSONObject jSONObject1 = param1JSONObject.optJSONObject("installmentPlanDetails");
      if (jSONObject1 == null) {
        jSONObject1 = jSONObject2;
      } else {
        zzbh1 = new zzbh(jSONObject1);
      } 
      this.zzf = zzbh1;
      ArrayList<String> arrayList = new ArrayList();
      JSONArray jSONArray = param1JSONObject.optJSONArray("offerTags");
      if (jSONArray != null)
        for (int i = 0; i < jSONArray.length(); i++)
          arrayList.add(jSONArray.getString(i));  
      this.zze = arrayList;
    }
    
    @zzf
    public String getBasePlanId() {
      return this.zza;
    }
    
    @zzf
    public String getOfferId() {
      return this.zzb;
    }
    
    public List<String> getOfferTags() {
      return this.zze;
    }
    
    public String getOfferToken() {
      return this.zzc;
    }
    
    public ProductDetails.PricingPhases getPricingPhases() {
      return this.zzd;
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Hill race-dex2jar.jar!\com\android\billingclient\api\ProductDetails.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */