package com.android.billingclient.api;

@zzk
public final class QueryPurchasesParams {
  private final String zza;
  
  @zzk
  public static Builder newBuilder() {
    return new Builder(null);
  }
  
  public final String zza() {
    return this.zza;
  }
  
  @zzk
  public static class Builder {
    private String zza;
    
    private Builder() {}
    
    @zzk
    public QueryPurchasesParams build() {
      if (this.zza != null)
        return new QueryPurchasesParams(this, null); 
      throw new IllegalArgumentException("Product type must be set");
    }
    
    @zzk
    public Builder setProductType(String param1String) {
      this.zza = param1String;
      return this;
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Hill race-dex2jar.jar!\com\android\billingclient\api\QueryPurchasesParams.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */