package com.android.billingclient.api;

import com.google.android.gms.internal.play_billing.zzu;
import java.util.HashSet;
import java.util.List;

@zzk
public final class QueryProductDetailsParams {
  private final zzu zza;
  
  @zzk
  public static Builder newBuilder() {
    return new Builder(null);
  }
  
  public final zzu zza() {
    return this.zza;
  }
  
  public final String zzb() {
    return ((Product)this.zza.get(0)).zzb();
  }
  
  @zzk
  public static class Builder {
    private zzu zza;
    
    private Builder() {}
    
    @zzk
    public QueryProductDetailsParams build() {
      return new QueryProductDetailsParams(this, null);
    }
    
    @zzk
    public Builder setProductList(List<QueryProductDetailsParams.Product> param1List) {
      if (param1List != null && !param1List.isEmpty()) {
        HashSet<String> hashSet = new HashSet();
        for (QueryProductDetailsParams.Product product : param1List) {
          if (!"play_pass_subs".equals(product.zzb()))
            hashSet.add(product.zzb()); 
        } 
        if (hashSet.size() <= 1) {
          this.zza = zzu.zzk(param1List);
          return this;
        } 
        throw new IllegalArgumentException("All products should be of the same product type.");
      } 
      throw new IllegalArgumentException("Product list cannot be empty.");
    }
  }
  
  @zzk
  public static class Product {
    private final String zza;
    
    private final String zzb;
    
    @zzk
    public static Builder newBuilder() {
      return new Builder(null);
    }
    
    public final String zza() {
      return this.zza;
    }
    
    public final String zzb() {
      return this.zzb;
    }
    
    @zzk
    public static class Builder {
      private String zza;
      
      private String zzb;
      
      private Builder() {}
      
      @zzk
      public QueryProductDetailsParams.Product build() {
        if (!"first_party".equals(this.zzb)) {
          if (this.zza != null) {
            if (this.zzb != null)
              return new QueryProductDetailsParams.Product(this, null); 
            throw new IllegalArgumentException("Product type must be provided.");
          } 
          throw new IllegalArgumentException("Product id must be provided.");
        } 
        throw new IllegalArgumentException("Serialized doc id must be provided for first party products.");
      }
      
      @zzk
      public Builder setProductId(String param2String) {
        this.zza = param2String;
        return this;
      }
      
      @zzk
      public Builder setProductType(String param2String) {
        this.zzb = param2String;
        return this;
      }
    }
  }
  
  @zzk
  public static class Builder {
    private String zza;
    
    private String zzb;
    
    private Builder() {}
    
    @zzk
    public QueryProductDetailsParams.Product build() {
      if (!"first_party".equals(this.zzb)) {
        if (this.zza != null) {
          if (this.zzb != null)
            return new QueryProductDetailsParams.Product(this, null); 
          throw new IllegalArgumentException("Product type must be provided.");
        } 
        throw new IllegalArgumentException("Product id must be provided.");
      } 
      throw new IllegalArgumentException("Serialized doc id must be provided for first party products.");
    }
    
    @zzk
    public Builder setProductId(String param1String) {
      this.zza = param1String;
      return this;
    }
    
    @zzk
    public Builder setProductType(String param1String) {
      this.zzb = param1String;
      return this;
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Hill race-dex2jar.jar!\com\android\billingclient\api\QueryProductDetailsParams.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */