package com.android.billingclient.api;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.os.Bundle;
import com.google.android.gms.internal.play_billing.zzb;
import com.google.android.gms.internal.play_billing.zzu;
import java.util.ArrayList;
import java.util.List;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

final class zzo extends BroadcastReceiver {
  private final PurchasesUpdatedListener zzb;
  
  private final zzbf zzc;
  
  private final zzc zzd;
  
  private boolean zze;
  
  public final void onReceive(Context paramContext, Intent paramIntent) {
    List<Purchase> list;
    Bundle bundle = paramIntent.getExtras();
    if (bundle == null) {
      zzb.zzo("BillingBroadcastManager", "Bundle is null.");
      PurchasesUpdatedListener purchasesUpdatedListener = this.zzb;
      if (purchasesUpdatedListener != null)
        purchasesUpdatedListener.onPurchasesUpdated(zzbc.zzj, null); 
      return;
    } 
    BillingResult billingResult = zzb.zzi(paramIntent, "BillingBroadcastManager");
    String str = paramIntent.getAction();
    if (str.equals("com.android.vending.billing.PURCHASES_UPDATED")) {
      if (!bundle.getBoolean("IS_FIRST_PARTY_PURCHASE", false) && this.zzb != null) {
        list = zzb.zzm(bundle);
        this.zzb.onPurchasesUpdated(billingResult, list);
        return;
      } 
      zzb.zzo("BillingBroadcastManager", "Received purchase and no valid listener registered.");
      return;
    } 
    if (list.equals("com.android.vending.billing.ALTERNATIVE_BILLING")) {
      if (billingResult.getResponseCode() != 0) {
        this.zzb.onPurchasesUpdated(billingResult, (List<Purchase>)zzu.zzl());
        return;
      } 
      if (this.zzd == null) {
        zzb.zzo("BillingBroadcastManager", "AlternativeBillingListener is null.");
        this.zzb.onPurchasesUpdated(zzbc.zzj, (List<Purchase>)zzu.zzl());
        return;
      } 
      String str1 = bundle.getString("ALTERNATIVE_BILLING_USER_CHOICE_DATA");
      if (str1 != null)
        try {
          JSONArray jSONArray = (new JSONObject(str1)).optJSONArray("products");
          ArrayList<zze> arrayList = new ArrayList();
          if (jSONArray != null)
            for (int i = 0; i < jSONArray.length(); i++) {
              JSONObject jSONObject = jSONArray.optJSONObject(i);
              if (jSONObject != null)
                arrayList.add(new zze(jSONObject, null)); 
            }  
          this.zzd.zza();
          return;
        } catch (JSONException jSONException) {
          zzb.zzo("BillingBroadcastManager", String.format("Error when parsing invalid alternative choice data: [%s]", new Object[] { str1 }));
          this.zzb.onPurchasesUpdated(zzbc.zzj, (List<Purchase>)zzu.zzl());
          return;
        }  
      zzb.zzo("BillingBroadcastManager", "Couldn't find alternative billing user choice data in bundle.");
      this.zzb.onPurchasesUpdated(zzbc.zzj, (List<Purchase>)zzu.zzl());
    } 
  }
  
  public final void zzc(Context paramContext, IntentFilter paramIntentFilter) {
    if (!this.zze) {
      paramContext.registerReceiver(zzp.zza(this.zza), paramIntentFilter);
      this.zze = true;
    } 
  }
  
  public final void zzd(Context paramContext) {
    if (this.zze) {
      paramContext.unregisterReceiver(zzp.zza(this.zza));
      this.zze = false;
      return;
    } 
    zzb.zzo("BillingBroadcastManager", "Receiver is not registered.");
  }
}


/* Location:              C:\soft\dex2jar-2.0\Hill race-dex2jar.jar!\com\android\billingclient\api\zzo.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */