package com.android.billingclient.api;

import org.json.JSONException;
import org.json.JSONObject;

public final class zzbh {
  zzbh(JSONObject paramJSONObject) throws JSONException {
    paramJSONObject.getInt("commitmentPaymentsCount");
    paramJSONObject.optInt("subsequentCommitmentPaymentsCount");
  }
}


/* Location:              C:\soft\dex2jar-2.0\Hill race-dex2jar.jar!\com\android\billingclient\api\zzbh.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */