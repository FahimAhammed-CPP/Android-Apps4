package c2;

import java.util.Locale;
import u1.r;

public final class z {
  public static final String a(char paramChar) {
    String str = String.valueOf(paramChar);
    r.c(str, "null cannot be cast to non-null type java.lang.String");
    Locale locale = Locale.ROOT;
    str = str.toUpperCase(locale);
    r.d(str, "this as java.lang.String).toUpperCase(Locale.ROOT)");
    if (str.length() > 1) {
      if (paramChar == 'ŉ')
        return str; 
      paramChar = str.charAt(0);
      r.c(str, "null cannot be cast to non-null type java.lang.String");
      str = str.substring(1);
      r.d(str, "this as java.lang.String).substring(startIndex)");
      r.c(str, "null cannot be cast to non-null type java.lang.String");
      String str1 = str.toLowerCase(locale);
      r.d(str1, "this as java.lang.String).toLowerCase(Locale.ROOT)");
      StringBuilder stringBuilder = new StringBuilder();
      stringBuilder.append(paramChar);
      stringBuilder.append(str1);
      return stringBuilder.toString();
    } 
    return String.valueOf(Character.toTitleCase(paramChar));
  }
}


/* Location:              C:\soft\dex2jar-2.0\Hill race-dex2jar.jar!\c2\z.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */