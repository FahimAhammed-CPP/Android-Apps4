package c2;

import i1.a0;
import i1.c0;
import i1.f0;
import i1.h;
import u1.r;

public final class y {
  public static final byte a(String paramString) {
    r.e(paramString, "<this>");
    i1.y y1 = b(paramString);
    if (y1 != null)
      return y1.f(); 
    p.j(paramString);
    throw new h();
  }
  
  public static final i1.y b(String paramString) {
    r.e(paramString, "<this>");
    return c(paramString, 10);
  }
  
  public static final i1.y c(String paramString, int paramInt) {
    r.e(paramString, "<this>");
    a0 a0 = f(paramString, paramInt);
    if (a0 != null) {
      paramInt = a0.f();
      return (u.a(paramInt, a0.b(255)) > 0) ? null : i1.y.a(i1.y.b((byte)paramInt));
    } 
    return null;
  }
  
  public static final int d(String paramString) {
    r.e(paramString, "<this>");
    a0 a0 = e(paramString);
    if (a0 != null)
      return a0.f(); 
    p.j(paramString);
    throw new h();
  }
  
  public static final a0 e(String paramString) {
    r.e(paramString, "<this>");
    return f(paramString, 10);
  }
  
  public static final a0 f(String paramString, int paramInt) {
    r.e(paramString, "<this>");
    a.a(paramInt);
    int n = paramString.length();
    if (n == 0)
      return null; 
    int k = 0;
    int j = paramString.charAt(0);
    int m = r.f(j, 48);
    int i = 1;
    if (m < 0) {
      if (n == 1 || j != 43)
        return null; 
    } else {
      i = 0;
    } 
    int i1 = a0.b(paramInt);
    m = 119304647;
    j = i;
    while (j < n) {
      int i2;
      int i5 = b.b(paramString.charAt(j), paramInt);
      if (i5 < 0)
        return null; 
      i = m;
      if (u.a(k, m) > 0)
        if (m == 119304647) {
          int i6 = v.a(-1, i1);
          i2 = i6;
          if (u.a(k, i6) > 0)
            return null; 
        } else {
          return null;
        }  
      int i4 = a0.b(k * i1);
      k = a0.b(a0.b(i5) + i4);
      if (u.a(k, i4) < 0)
        return null; 
      int i3 = j + 1;
      i4 = i2;
    } 
    return a0.a(k);
  }
  
  public static final long g(String paramString) {
    r.e(paramString, "<this>");
    c0 c0 = h(paramString);
    if (c0 != null)
      return c0.f(); 
    p.j(paramString);
    throw new h();
  }
  
  public static final c0 h(String paramString) {
    r.e(paramString, "<this>");
    return i(paramString, 10);
  }
  
  public static final c0 i(String paramString, int paramInt) {
    r.e(paramString, "<this>");
    a.a(paramInt);
    int j = paramString.length();
    if (j == 0)
      return null; 
    int i = 0;
    char c = paramString.charAt(0);
    if (r.f(c, 48) < 0)
      if (j != 1) {
        if (c != '+')
          return null; 
        i = 1;
      } else {
        return null;
      }  
    long l3 = c0.b(paramInt);
    long l1 = 0L;
    long l2;
    for (l2 = 512409557603043100L; i < j; l2 = l) {
      int k = b.b(paramString.charAt(i), paramInt);
      if (k < 0)
        return null; 
      long l = l2;
      if (w.a(l1, l2) > 0)
        if (l2 == 512409557603043100L) {
          l2 = x.a(-1L, l3);
          l = l2;
          if (w.a(l1, l2) > 0)
            return null; 
        } else {
          return null;
        }  
      l2 = c0.b(l1 * l3);
      l1 = c0.b(c0.b(a0.b(k) & 0xFFFFFFFFL) + l2);
      if (w.a(l1, l2) < 0)
        return null; 
      i++;
    } 
    return c0.a(l1);
  }
  
  public static final short j(String paramString) {
    r.e(paramString, "<this>");
    f0 f0 = k(paramString);
    if (f0 != null)
      return f0.f(); 
    p.j(paramString);
    throw new h();
  }
  
  public static final f0 k(String paramString) {
    r.e(paramString, "<this>");
    return l(paramString, 10);
  }
  
  public static final f0 l(String paramString, int paramInt) {
    r.e(paramString, "<this>");
    a0 a0 = f(paramString, paramInt);
    if (a0 != null) {
      paramInt = a0.f();
      return (u.a(paramInt, a0.b(65535)) > 0) ? null : f0.a(f0.b((short)paramInt));
    } 
    return null;
  }
}


/* Location:              C:\soft\dex2jar-2.0\Hill race-dex2jar.jar!\c2\y.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */