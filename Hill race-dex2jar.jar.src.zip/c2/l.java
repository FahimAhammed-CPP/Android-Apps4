package c2;

class l extends k {}


/* Location:              C:\soft\dex2jar-2.0\Hill race-dex2jar.jar!\c2\l.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */