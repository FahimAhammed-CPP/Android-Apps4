package c2;

import j1.o;
import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import u1.j;
import u1.r;
import z1.j;

public final class f implements Serializable {
  public static final a c = new a(null);
  
  private final Pattern b;
  
  public f(String paramString) {
    this(pattern);
  }
  
  public f(Pattern paramPattern) {
    this.b = paramPattern;
  }
  
  public final boolean a(CharSequence paramCharSequence) {
    r.e(paramCharSequence, "input");
    return this.b.matcher(paramCharSequence).matches();
  }
  
  public final String b(CharSequence paramCharSequence, String paramString) {
    r.e(paramCharSequence, "input");
    r.e(paramString, "replacement");
    paramCharSequence = this.b.matcher(paramCharSequence).replaceAll(paramString);
    r.d(paramCharSequence, "nativePattern.matcher(in…).replaceAll(replacement)");
    return (String)paramCharSequence;
  }
  
  public final String c(CharSequence paramCharSequence, String paramString) {
    r.e(paramCharSequence, "input");
    r.e(paramString, "replacement");
    paramCharSequence = this.b.matcher(paramCharSequence).replaceFirst(paramString);
    r.d(paramCharSequence, "nativePattern.matcher(in…replaceFirst(replacement)");
    return (String)paramCharSequence;
  }
  
  public final List<String> d(CharSequence paramCharSequence, int paramInt) {
    r.e(paramCharSequence, "input");
    r.n0(paramInt);
    Matcher matcher = this.b.matcher(paramCharSequence);
    if (paramInt == 1 || !matcher.find())
      return o.b(paramCharSequence.toString()); 
    int i = 10;
    if (paramInt > 0)
      i = j.d(paramInt, 10); 
    ArrayList<String> arrayList = new ArrayList(i);
    i = 0;
    int j = paramInt - 1;
    paramInt = i;
    while (true) {
      arrayList.add(paramCharSequence.subSequence(paramInt, matcher.start()).toString());
      i = matcher.end();
      if (j < 0 || arrayList.size() != j) {
        paramInt = i;
        if (!matcher.find())
          break; 
        continue;
      } 
      break;
    } 
    arrayList.add(paramCharSequence.subSequence(i, paramCharSequence.length()).toString());
    return arrayList;
  }
  
  public String toString() {
    String str = this.b.toString();
    r.d(str, "nativePattern.toString()");
    return str;
  }
  
  public static final class a {
    private a() {}
  }
}


/* Location:              C:\soft\dex2jar-2.0\Hill race-dex2jar.jar!\c2\f.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */