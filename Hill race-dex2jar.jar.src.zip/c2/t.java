package c2;

import java.util.NoSuchElementException;
import u1.r;
import z1.j;

class t extends s {
  public static String M0(String paramString, int paramInt) {
    boolean bool;
    r.e(paramString, "<this>");
    if (paramInt >= 0) {
      bool = true;
    } else {
      bool = false;
    } 
    if (bool) {
      paramString = paramString.substring(j.d(paramInt, paramString.length()));
      r.d(paramString, "this as java.lang.String).substring(startIndex)");
      return paramString;
    } 
    StringBuilder stringBuilder = new StringBuilder();
    stringBuilder.append("Requested character count ");
    stringBuilder.append(paramInt);
    stringBuilder.append(" is less than zero.");
    throw new IllegalArgumentException(stringBuilder.toString().toString());
  }
  
  public static char N0(CharSequence paramCharSequence) {
    boolean bool;
    r.e(paramCharSequence, "<this>");
    if (paramCharSequence.length() == 0) {
      bool = true;
    } else {
      bool = false;
    } 
    if (!bool)
      return paramCharSequence.charAt(h.P(paramCharSequence)); 
    throw new NoSuchElementException("Char sequence is empty.");
  }
  
  public static char O0(CharSequence paramCharSequence) {
    r.e(paramCharSequence, "<this>");
    int i = paramCharSequence.length();
    if (i != 0) {
      if (i == 1)
        return paramCharSequence.charAt(0); 
      throw new IllegalArgumentException("Char sequence has more than one element.");
    } 
    throw new NoSuchElementException("Char sequence is empty.");
  }
  
  public static String P0(String paramString, int paramInt) {
    boolean bool;
    r.e(paramString, "<this>");
    if (paramInt >= 0) {
      bool = true;
    } else {
      bool = false;
    } 
    if (bool) {
      paramString = paramString.substring(0, j.d(paramInt, paramString.length()));
      r.d(paramString, "this as java.lang.String…ing(startIndex, endIndex)");
      return paramString;
    } 
    StringBuilder stringBuilder = new StringBuilder();
    stringBuilder.append("Requested character count ");
    stringBuilder.append(paramInt);
    stringBuilder.append(" is less than zero.");
    throw new IllegalArgumentException(stringBuilder.toString().toString());
  }
}


/* Location:              C:\soft\dex2jar-2.0\Hill race-dex2jar.jar!\c2\t.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */