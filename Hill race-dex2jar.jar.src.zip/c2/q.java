package c2;

import j1.b;
import j1.g0;
import java.util.Comparator;
import u1.e0;
import u1.r;
import z1.f;
import z1.j;

class q extends p {
  public static boolean C(String paramString1, String paramString2, int paramInt, boolean paramBoolean) {
    r.e(paramString1, "<this>");
    r.e(paramString2, "prefix");
    return !paramBoolean ? paramString1.startsWith(paramString2, paramInt) : h.v(paramString1, paramInt, paramString2, 0, paramString2.length(), paramBoolean);
  }
  
  public static boolean D(String paramString1, String paramString2, boolean paramBoolean) {
    r.e(paramString1, "<this>");
    r.e(paramString2, "prefix");
    return !paramBoolean ? paramString1.startsWith(paramString2) : h.v(paramString1, 0, paramString2, 0, paramString2.length(), paramBoolean);
  }
  
  public static String o(char[] paramArrayOfchar) {
    r.e(paramArrayOfchar, "<this>");
    return new String(paramArrayOfchar);
  }
  
  public static String p(char[] paramArrayOfchar, int paramInt1, int paramInt2) {
    r.e(paramArrayOfchar, "<this>");
    b.b.a(paramInt1, paramInt2, paramArrayOfchar.length);
    return new String(paramArrayOfchar, paramInt1, paramInt2 - paramInt1);
  }
  
  public static final boolean q(String paramString1, String paramString2, boolean paramBoolean) {
    r.e(paramString1, "<this>");
    r.e(paramString2, "suffix");
    return !paramBoolean ? paramString1.endsWith(paramString2) : h.v(paramString1, paramString1.length() - paramString2.length(), paramString2, 0, paramString2.length(), true);
  }
  
  public static boolean s(String paramString1, String paramString2, boolean paramBoolean) {
    return (paramString1 == null) ? ((paramString2 == null)) : (!paramBoolean ? paramString1.equals(paramString2) : paramString1.equalsIgnoreCase(paramString2));
  }
  
  public static Comparator<String> t(e0 parame0) {
    r.e(parame0, "<this>");
    Comparator<String> comparator = String.CASE_INSENSITIVE_ORDER;
    r.d(comparator, "CASE_INSENSITIVE_ORDER");
    return comparator;
  }
  
  public static boolean u(CharSequence paramCharSequence) {
    // Byte code:
    //   0: aload_0
    //   1: ldc '<this>'
    //   3: invokestatic e : (Ljava/lang/Object;Ljava/lang/String;)V
    //   6: aload_0
    //   7: invokeinterface length : ()I
    //   12: istore_1
    //   13: iconst_0
    //   14: istore_2
    //   15: iload_1
    //   16: ifeq -> 89
    //   19: aload_0
    //   20: invokestatic O : (Ljava/lang/CharSequence;)Lz1/f;
    //   23: astore_3
    //   24: aload_3
    //   25: instanceof java/util/Collection
    //   28: ifeq -> 48
    //   31: aload_3
    //   32: checkcast java/util/Collection
    //   35: invokeinterface isEmpty : ()Z
    //   40: ifeq -> 48
    //   43: iconst_1
    //   44: istore_1
    //   45: goto -> 85
    //   48: aload_3
    //   49: invokeinterface iterator : ()Ljava/util/Iterator;
    //   54: astore_3
    //   55: aload_3
    //   56: invokeinterface hasNext : ()Z
    //   61: ifeq -> 43
    //   64: aload_0
    //   65: aload_3
    //   66: checkcast j1/g0
    //   69: invokevirtual a : ()I
    //   72: invokeinterface charAt : (I)C
    //   77: invokestatic c : (C)Z
    //   80: ifne -> 55
    //   83: iconst_0
    //   84: istore_1
    //   85: iload_1
    //   86: ifeq -> 91
    //   89: iconst_1
    //   90: istore_2
    //   91: iload_2
    //   92: ireturn
  }
  
  public static boolean v(String paramString1, int paramInt1, String paramString2, int paramInt2, int paramInt3, boolean paramBoolean) {
    r.e(paramString1, "<this>");
    r.e(paramString2, "other");
    return !paramBoolean ? paramString1.regionMatches(paramInt1, paramString2, paramInt2, paramInt3) : paramString1.regionMatches(paramBoolean, paramInt1, paramString2, paramInt2, paramInt3);
  }
  
  public static String x(CharSequence paramCharSequence, int paramInt) {
    int i;
    r.e(paramCharSequence, "<this>");
    boolean bool = false;
    if (paramInt >= 0) {
      i = 1;
    } else {
      i = 0;
    } 
    if (i) {
      String str2 = "";
      String str1 = str2;
      if (paramInt != 0) {
        char[] arrayOfChar;
        if (paramInt != 1) {
          i = paramCharSequence.length();
          str1 = str2;
          if (i != 0) {
            if (i != 1) {
              StringBuilder stringBuilder = new StringBuilder(paramCharSequence.length() * paramInt);
              g0 g0 = (new f(1, paramInt)).h();
              while (g0.hasNext()) {
                g0.a();
                stringBuilder.append(paramCharSequence);
              } 
              paramCharSequence = stringBuilder.toString();
              r.d(paramCharSequence, "{\n                    va…tring()\n                }");
              return (String)paramCharSequence;
            } 
            char c = paramCharSequence.charAt(0);
            arrayOfChar = new char[paramInt];
            for (i = bool; i < paramInt; i++)
              arrayOfChar[i] = c; 
            return new String(arrayOfChar);
          } 
        } else {
          str1 = arrayOfChar.toString();
        } 
      } 
      return str1;
    } 
    paramCharSequence = new StringBuilder();
    paramCharSequence.append("Count 'n' must be non-negative, but was ");
    paramCharSequence.append(paramInt);
    paramCharSequence.append('.');
    throw new IllegalArgumentException(paramCharSequence.toString().toString());
  }
  
  public static final String y(String paramString, char paramChar1, char paramChar2, boolean paramBoolean) {
    r.e(paramString, "<this>");
    if (!paramBoolean) {
      paramString = paramString.replace(paramChar1, paramChar2);
      r.d(paramString, "this as java.lang.String…replace(oldChar, newChar)");
      return paramString;
    } 
    StringBuilder stringBuilder = new StringBuilder(paramString.length());
    int i;
    for (i = 0; i < paramString.length(); i++) {
      char c1 = paramString.charAt(i);
      char c = c1;
      if (c.d(c1, paramChar1, paramBoolean))
        c = paramChar2; 
      stringBuilder.append(c);
    } 
    paramString = stringBuilder.toString();
    r.d(paramString, "StringBuilder(capacity).…builderAction).toString()");
    return paramString;
  }
  
  public static final String z(String paramString1, String paramString2, String paramString3, boolean paramBoolean) {
    r.e(paramString1, "<this>");
    r.e(paramString2, "oldValue");
    r.e(paramString3, "newValue");
    int j = 0;
    int i = r.R(paramString1, paramString2, 0, paramBoolean);
    if (i < 0)
      return paramString1; 
    int m = paramString2.length();
    int n = j.b(m, 1);
    int k = paramString1.length() - m + paramString3.length();
    if (k >= 0) {
      StringBuilder stringBuilder = new StringBuilder(k);
      while (true) {
        stringBuilder.append(paramString1, j, i);
        stringBuilder.append(paramString3);
        k = i + m;
        if (i < paramString1.length()) {
          int i1 = r.R(paramString1, paramString2, i + n, paramBoolean);
          j = k;
          i = i1;
          if (i1 <= 0)
            break; 
          continue;
        } 
        break;
      } 
      stringBuilder.append(paramString1, k, paramString1.length());
      paramString1 = stringBuilder.toString();
      r.d(paramString1, "stringBuilder.append(this, i, length).toString()");
      return paramString1;
    } 
    throw new OutOfMemoryError();
  }
}


/* Location:              C:\soft\dex2jar-2.0\Hill race-dex2jar.jar!\c2\q.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */