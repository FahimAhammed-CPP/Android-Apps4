package c2;

import b2.d;
import b2.e;
import i1.x;
import j1.g0;
import j1.h;
import j1.o;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Iterator;
import java.util.List;
import t1.l;
import t1.p;
import u1.s;
import z1.f;
import z1.j;

class r extends q {
  public static final String A0(String paramString1, char paramChar, String paramString2) {
    u1.r.e(paramString1, "<this>");
    u1.r.e(paramString2, "missingDelimiterValue");
    int i = h.U(paramString1, paramChar, 0, false, 6, null);
    if (i == -1)
      return paramString2; 
    paramString1 = paramString1.substring(i + 1, paramString1.length());
    u1.r.d(paramString1, "this as java.lang.String…ing(startIndex, endIndex)");
    return paramString1;
  }
  
  public static final String B0(String paramString1, String paramString2, String paramString3) {
    u1.r.e(paramString1, "<this>");
    u1.r.e(paramString2, "delimiter");
    u1.r.e(paramString3, "missingDelimiterValue");
    int i = h.V(paramString1, paramString2, 0, false, 6, null);
    if (i == -1)
      return paramString3; 
    paramString1 = paramString1.substring(i + paramString2.length(), paramString1.length());
    u1.r.d(paramString1, "this as java.lang.String…ing(startIndex, endIndex)");
    return paramString1;
  }
  
  public static final String E0(String paramString1, char paramChar, String paramString2) {
    u1.r.e(paramString1, "<this>");
    u1.r.e(paramString2, "missingDelimiterValue");
    int i = h.Z(paramString1, paramChar, 0, false, 6, null);
    if (i == -1)
      return paramString2; 
    paramString1 = paramString1.substring(i + 1, paramString1.length());
    u1.r.d(paramString1, "this as java.lang.String…ing(startIndex, endIndex)");
    return paramString1;
  }
  
  public static final String G0(String paramString1, char paramChar, String paramString2) {
    u1.r.e(paramString1, "<this>");
    u1.r.e(paramString2, "missingDelimiterValue");
    int i = h.U(paramString1, paramChar, 0, false, 6, null);
    if (i == -1)
      return paramString2; 
    paramString1 = paramString1.substring(0, i);
    u1.r.d(paramString1, "this as java.lang.String…ing(startIndex, endIndex)");
    return paramString1;
  }
  
  public static final boolean H(CharSequence paramCharSequence, char paramChar, boolean paramBoolean) {
    u1.r.e(paramCharSequence, "<this>");
    return (h.U(paramCharSequence, paramChar, 0, paramBoolean, 2, null) >= 0);
  }
  
  public static final String H0(String paramString1, String paramString2, String paramString3) {
    u1.r.e(paramString1, "<this>");
    u1.r.e(paramString2, "delimiter");
    u1.r.e(paramString3, "missingDelimiterValue");
    int i = h.V(paramString1, paramString2, 0, false, 6, null);
    if (i == -1)
      return paramString3; 
    paramString1 = paramString1.substring(0, i);
    u1.r.d(paramString1, "this as java.lang.String…ing(startIndex, endIndex)");
    return paramString1;
  }
  
  public static final boolean I(CharSequence paramCharSequence1, CharSequence paramCharSequence2, boolean paramBoolean) {
    u1.r.e(paramCharSequence1, "<this>");
    u1.r.e(paramCharSequence2, "other");
    if (paramCharSequence2 instanceof String) {
      if (h.V(paramCharSequence1, (String)paramCharSequence2, 0, paramBoolean, 2, null) >= 0)
        return true; 
    } else if (T(paramCharSequence1, paramCharSequence2, 0, paramCharSequence1.length(), paramBoolean, false, 16, null) >= 0) {
      return true;
    } 
    return false;
  }
  
  public static CharSequence K0(CharSequence paramCharSequence) {
    u1.r.e(paramCharSequence, "<this>");
    int j = paramCharSequence.length() - 1;
    int i = 0;
    boolean bool = false;
    while (i <= j) {
      int k;
      if (!bool) {
        k = i;
      } else {
        k = j;
      } 
      boolean bool1 = b.c(paramCharSequence.charAt(k));
      if (!bool) {
        if (!bool1) {
          bool = true;
          continue;
        } 
        i++;
        continue;
      } 
      if (!bool1)
        break; 
      j--;
    } 
    return paramCharSequence.subSequence(i, j + 1);
  }
  
  public static final boolean L(CharSequence paramCharSequence1, CharSequence paramCharSequence2, boolean paramBoolean) {
    u1.r.e(paramCharSequence1, "<this>");
    u1.r.e(paramCharSequence2, "suffix");
    return (!paramBoolean && paramCharSequence1 instanceof String && paramCharSequence2 instanceof String) ? h.r((String)paramCharSequence1, (String)paramCharSequence2, false, 2, null) : k0(paramCharSequence1, paramCharSequence1.length() - paramCharSequence2.length(), paramCharSequence2, 0, paramCharSequence2.length(), paramBoolean);
  }
  
  public static String L0(String paramString, char... paramVarArgs) {
    u1.r.e(paramString, "<this>");
    u1.r.e(paramVarArgs, "chars");
    int j = paramString.length() - 1;
    int i = 0;
    boolean bool = false;
    while (i <= j) {
      int k;
      if (!bool) {
        k = i;
      } else {
        k = j;
      } 
      boolean bool1 = h.n(paramVarArgs, paramString.charAt(k));
      if (!bool) {
        if (!bool1) {
          bool = true;
          continue;
        } 
        i++;
        continue;
      } 
      if (!bool1)
        break; 
      j--;
    } 
    return paramString.subSequence(i, j + 1).toString();
  }
  
  private static final i1.r<Integer, String> N(CharSequence paramCharSequence, Collection<String> paramCollection, int paramInt, boolean paramBoolean1, boolean paramBoolean2) {
    // Byte code:
    //   0: iload_3
    //   1: ifne -> 65
    //   4: aload_1
    //   5: invokeinterface size : ()I
    //   10: iconst_1
    //   11: if_icmpne -> 65
    //   14: aload_1
    //   15: invokestatic K : (Ljava/lang/Iterable;)Ljava/lang/Object;
    //   18: checkcast java/lang/String
    //   21: astore_1
    //   22: iload #4
    //   24: ifne -> 40
    //   27: aload_0
    //   28: aload_1
    //   29: iload_2
    //   30: iconst_0
    //   31: iconst_4
    //   32: aconst_null
    //   33: invokestatic V : (Ljava/lang/CharSequence;Ljava/lang/String;IZILjava/lang/Object;)I
    //   36: istore_2
    //   37: goto -> 50
    //   40: aload_0
    //   41: aload_1
    //   42: iload_2
    //   43: iconst_0
    //   44: iconst_4
    //   45: aconst_null
    //   46: invokestatic a0 : (Ljava/lang/CharSequence;Ljava/lang/String;IZILjava/lang/Object;)I
    //   49: istore_2
    //   50: iload_2
    //   51: ifge -> 56
    //   54: aconst_null
    //   55: areturn
    //   56: iload_2
    //   57: invokestatic valueOf : (I)Ljava/lang/Integer;
    //   60: aload_1
    //   61: invokestatic a : (Ljava/lang/Object;Ljava/lang/Object;)Li1/r;
    //   64: areturn
    //   65: iload #4
    //   67: ifne -> 93
    //   70: new z1/f
    //   73: dup
    //   74: iload_2
    //   75: iconst_0
    //   76: invokestatic b : (II)I
    //   79: aload_0
    //   80: invokeinterface length : ()I
    //   85: invokespecial <init> : (II)V
    //   88: astore #8
    //   90: goto -> 107
    //   93: iload_2
    //   94: aload_0
    //   95: invokestatic P : (Ljava/lang/CharSequence;)I
    //   98: invokestatic d : (II)I
    //   101: iconst_0
    //   102: invokestatic h : (II)Lz1/d;
    //   105: astore #8
    //   107: aload_0
    //   108: instanceof java/lang/String
    //   111: ifeq -> 261
    //   114: aload #8
    //   116: invokevirtual d : ()I
    //   119: istore #5
    //   121: aload #8
    //   123: invokevirtual f : ()I
    //   126: istore #6
    //   128: aload #8
    //   130: invokevirtual g : ()I
    //   133: istore #7
    //   135: iload #7
    //   137: ifle -> 150
    //   140: iload #5
    //   142: istore_2
    //   143: iload #5
    //   145: iload #6
    //   147: if_icmple -> 165
    //   150: iload #7
    //   152: ifge -> 405
    //   155: iload #6
    //   157: iload #5
    //   159: if_icmpgt -> 405
    //   162: iload #5
    //   164: istore_2
    //   165: aload_1
    //   166: invokeinterface iterator : ()Ljava/util/Iterator;
    //   171: astore #9
    //   173: aload #9
    //   175: invokeinterface hasNext : ()Z
    //   180: ifeq -> 222
    //   183: aload #9
    //   185: invokeinterface next : ()Ljava/lang/Object;
    //   190: astore #8
    //   192: aload #8
    //   194: checkcast java/lang/String
    //   197: astore #10
    //   199: aload #10
    //   201: iconst_0
    //   202: aload_0
    //   203: checkcast java/lang/String
    //   206: iload_2
    //   207: aload #10
    //   209: invokevirtual length : ()I
    //   212: iload_3
    //   213: invokestatic v : (Ljava/lang/String;ILjava/lang/String;IIZ)Z
    //   216: ifeq -> 173
    //   219: goto -> 225
    //   222: aconst_null
    //   223: astore #8
    //   225: aload #8
    //   227: checkcast java/lang/String
    //   230: astore #8
    //   232: aload #8
    //   234: ifnull -> 247
    //   237: iload_2
    //   238: invokestatic valueOf : (I)Ljava/lang/Integer;
    //   241: aload #8
    //   243: invokestatic a : (Ljava/lang/Object;Ljava/lang/Object;)Li1/r;
    //   246: areturn
    //   247: iload_2
    //   248: iload #6
    //   250: if_icmpeq -> 405
    //   253: iload_2
    //   254: iload #7
    //   256: iadd
    //   257: istore_2
    //   258: goto -> 165
    //   261: aload #8
    //   263: invokevirtual d : ()I
    //   266: istore #5
    //   268: aload #8
    //   270: invokevirtual f : ()I
    //   273: istore #6
    //   275: aload #8
    //   277: invokevirtual g : ()I
    //   280: istore #7
    //   282: iload #7
    //   284: ifle -> 297
    //   287: iload #5
    //   289: istore_2
    //   290: iload #5
    //   292: iload #6
    //   294: if_icmple -> 312
    //   297: iload #7
    //   299: ifge -> 405
    //   302: iload #6
    //   304: iload #5
    //   306: if_icmpgt -> 405
    //   309: iload #5
    //   311: istore_2
    //   312: aload_1
    //   313: invokeinterface iterator : ()Ljava/util/Iterator;
    //   318: astore #9
    //   320: aload #9
    //   322: invokeinterface hasNext : ()Z
    //   327: ifeq -> 366
    //   330: aload #9
    //   332: invokeinterface next : ()Ljava/lang/Object;
    //   337: astore #8
    //   339: aload #8
    //   341: checkcast java/lang/String
    //   344: astore #10
    //   346: aload #10
    //   348: iconst_0
    //   349: aload_0
    //   350: iload_2
    //   351: aload #10
    //   353: invokevirtual length : ()I
    //   356: iload_3
    //   357: invokestatic k0 : (Ljava/lang/CharSequence;ILjava/lang/CharSequence;IIZ)Z
    //   360: ifeq -> 320
    //   363: goto -> 369
    //   366: aconst_null
    //   367: astore #8
    //   369: aload #8
    //   371: checkcast java/lang/String
    //   374: astore #8
    //   376: aload #8
    //   378: ifnull -> 391
    //   381: iload_2
    //   382: invokestatic valueOf : (I)Ljava/lang/Integer;
    //   385: aload #8
    //   387: invokestatic a : (Ljava/lang/Object;Ljava/lang/Object;)Li1/r;
    //   390: areturn
    //   391: iload_2
    //   392: iload #6
    //   394: if_icmpeq -> 405
    //   397: iload_2
    //   398: iload #7
    //   400: iadd
    //   401: istore_2
    //   402: goto -> 312
    //   405: aconst_null
    //   406: areturn
  }
  
  public static final f O(CharSequence paramCharSequence) {
    u1.r.e(paramCharSequence, "<this>");
    return new f(0, paramCharSequence.length() - 1);
  }
  
  public static int P(CharSequence paramCharSequence) {
    u1.r.e(paramCharSequence, "<this>");
    return paramCharSequence.length() - 1;
  }
  
  public static final int Q(CharSequence paramCharSequence, char paramChar, int paramInt, boolean paramBoolean) {
    u1.r.e(paramCharSequence, "<this>");
    return (paramBoolean || !(paramCharSequence instanceof String)) ? W(paramCharSequence, new char[] { paramChar }, paramInt, paramBoolean) : ((String)paramCharSequence).indexOf(paramChar, paramInt);
  }
  
  public static final int R(CharSequence paramCharSequence, String paramString, int paramInt, boolean paramBoolean) {
    u1.r.e(paramCharSequence, "<this>");
    u1.r.e(paramString, "string");
    return (paramBoolean || !(paramCharSequence instanceof String)) ? T(paramCharSequence, paramString, paramInt, paramCharSequence.length(), paramBoolean, false, 16, null) : ((String)paramCharSequence).indexOf(paramString, paramInt);
  }
  
  private static final int S(CharSequence paramCharSequence1, CharSequence paramCharSequence2, int paramInt1, int paramInt2, boolean paramBoolean1, boolean paramBoolean2) {
    // Byte code:
    //   0: iload #5
    //   2: ifne -> 32
    //   5: new z1/f
    //   8: dup
    //   9: iload_2
    //   10: iconst_0
    //   11: invokestatic b : (II)I
    //   14: iload_3
    //   15: aload_0
    //   16: invokeinterface length : ()I
    //   21: invokestatic d : (II)I
    //   24: invokespecial <init> : (II)V
    //   27: astore #8
    //   29: goto -> 50
    //   32: iload_2
    //   33: aload_0
    //   34: invokestatic P : (Ljava/lang/CharSequence;)I
    //   37: invokestatic d : (II)I
    //   40: iload_3
    //   41: iconst_0
    //   42: invokestatic b : (II)I
    //   45: invokestatic h : (II)Lz1/d;
    //   48: astore #8
    //   50: aload_0
    //   51: instanceof java/lang/String
    //   54: ifeq -> 150
    //   57: aload_1
    //   58: instanceof java/lang/String
    //   61: ifeq -> 150
    //   64: aload #8
    //   66: invokevirtual d : ()I
    //   69: istore_3
    //   70: aload #8
    //   72: invokevirtual f : ()I
    //   75: istore #6
    //   77: aload #8
    //   79: invokevirtual g : ()I
    //   82: istore #7
    //   84: iload #7
    //   86: ifle -> 97
    //   89: iload_3
    //   90: istore_2
    //   91: iload_3
    //   92: iload #6
    //   94: if_icmple -> 110
    //   97: iload #7
    //   99: ifge -> 230
    //   102: iload #6
    //   104: iload_3
    //   105: if_icmpgt -> 230
    //   108: iload_3
    //   109: istore_2
    //   110: aload_1
    //   111: checkcast java/lang/String
    //   114: iconst_0
    //   115: aload_0
    //   116: checkcast java/lang/String
    //   119: iload_2
    //   120: aload_1
    //   121: invokeinterface length : ()I
    //   126: iload #4
    //   128: invokestatic v : (Ljava/lang/String;ILjava/lang/String;IIZ)Z
    //   131: ifeq -> 136
    //   134: iload_2
    //   135: ireturn
    //   136: iload_2
    //   137: iload #6
    //   139: if_icmpeq -> 230
    //   142: iload_2
    //   143: iload #7
    //   145: iadd
    //   146: istore_2
    //   147: goto -> 110
    //   150: aload #8
    //   152: invokevirtual d : ()I
    //   155: istore_3
    //   156: aload #8
    //   158: invokevirtual f : ()I
    //   161: istore #6
    //   163: aload #8
    //   165: invokevirtual g : ()I
    //   168: istore #7
    //   170: iload #7
    //   172: ifle -> 183
    //   175: iload_3
    //   176: istore_2
    //   177: iload_3
    //   178: iload #6
    //   180: if_icmple -> 196
    //   183: iload #7
    //   185: ifge -> 230
    //   188: iload #6
    //   190: iload_3
    //   191: if_icmpgt -> 230
    //   194: iload_3
    //   195: istore_2
    //   196: aload_1
    //   197: iconst_0
    //   198: aload_0
    //   199: iload_2
    //   200: aload_1
    //   201: invokeinterface length : ()I
    //   206: iload #4
    //   208: invokestatic k0 : (Ljava/lang/CharSequence;ILjava/lang/CharSequence;IIZ)Z
    //   211: ifeq -> 216
    //   214: iload_2
    //   215: ireturn
    //   216: iload_2
    //   217: iload #6
    //   219: if_icmpeq -> 230
    //   222: iload_2
    //   223: iload #7
    //   225: iadd
    //   226: istore_2
    //   227: goto -> 196
    //   230: iconst_m1
    //   231: ireturn
  }
  
  public static final int W(CharSequence paramCharSequence, char[] paramArrayOfchar, int paramInt, boolean paramBoolean) {
    u1.r.e(paramCharSequence, "<this>");
    u1.r.e(paramArrayOfchar, "chars");
    if (!paramBoolean && paramArrayOfchar.length == 1 && paramCharSequence instanceof String) {
      char c = h.D(paramArrayOfchar);
      return ((String)paramCharSequence).indexOf(c, paramInt);
    } 
    g0 g0 = (new f(j.b(paramInt, 0), h.P(paramCharSequence))).h();
    while (g0.hasNext()) {
      int i = g0.a();
      char c = paramCharSequence.charAt(i);
      int j = paramArrayOfchar.length;
      paramInt = 0;
      while (true) {
        if (paramInt < j) {
          if (c.d(paramArrayOfchar[paramInt], c, paramBoolean)) {
            paramInt = 1;
            break;
          } 
          paramInt++;
          continue;
        } 
        paramInt = 0;
        break;
      } 
      if (paramInt != 0)
        return i; 
    } 
    return -1;
  }
  
  public static final int X(CharSequence paramCharSequence, char paramChar, int paramInt, boolean paramBoolean) {
    u1.r.e(paramCharSequence, "<this>");
    return (paramBoolean || !(paramCharSequence instanceof String)) ? b0(paramCharSequence, new char[] { paramChar }, paramInt, paramBoolean) : ((String)paramCharSequence).lastIndexOf(paramChar, paramInt);
  }
  
  public static final int Y(CharSequence paramCharSequence, String paramString, int paramInt, boolean paramBoolean) {
    u1.r.e(paramCharSequence, "<this>");
    u1.r.e(paramString, "string");
    return (paramBoolean || !(paramCharSequence instanceof String)) ? S(paramCharSequence, paramString, paramInt, 0, paramBoolean, true) : ((String)paramCharSequence).lastIndexOf(paramString, paramInt);
  }
  
  public static final int b0(CharSequence paramCharSequence, char[] paramArrayOfchar, int paramInt, boolean paramBoolean) {
    u1.r.e(paramCharSequence, "<this>");
    u1.r.e(paramArrayOfchar, "chars");
    if (!paramBoolean && paramArrayOfchar.length == 1 && paramCharSequence instanceof String) {
      char c = h.D(paramArrayOfchar);
      return ((String)paramCharSequence).lastIndexOf(c, paramInt);
    } 
    for (paramInt = j.d(paramInt, h.P(paramCharSequence)); -1 < paramInt; paramInt--) {
      boolean bool1;
      char c = paramCharSequence.charAt(paramInt);
      int j = paramArrayOfchar.length;
      boolean bool2 = false;
      int i = 0;
      while (true) {
        bool1 = bool2;
        if (i < j) {
          if (c.d(paramArrayOfchar[i], c, paramBoolean)) {
            bool1 = true;
            break;
          } 
          i++;
          continue;
        } 
        break;
      } 
      if (bool1)
        return paramInt; 
    } 
    return -1;
  }
  
  public static final d<String> c0(CharSequence paramCharSequence) {
    u1.r.e(paramCharSequence, "<this>");
    return u0(paramCharSequence, new String[] { "\r\n", "\n", "\r" }, false, 0, 6, null);
  }
  
  public static final List<String> d0(CharSequence paramCharSequence) {
    u1.r.e(paramCharSequence, "<this>");
    return e.j(c0(paramCharSequence));
  }
  
  public static final CharSequence e0(CharSequence paramCharSequence, int paramInt, char paramChar) {
    u1.r.e(paramCharSequence, "<this>");
    if (paramInt >= 0) {
      if (paramInt <= paramCharSequence.length())
        return paramCharSequence.subSequence(0, paramCharSequence.length()); 
      StringBuilder stringBuilder = new StringBuilder(paramInt);
      g0 g0 = (new f(1, paramInt - paramCharSequence.length())).h();
      while (g0.hasNext()) {
        g0.a();
        stringBuilder.append(paramChar);
      } 
      stringBuilder.append(paramCharSequence);
      return stringBuilder;
    } 
    paramCharSequence = new StringBuilder();
    paramCharSequence.append("Desired length ");
    paramCharSequence.append(paramInt);
    paramCharSequence.append(" is less than zero.");
    throw new IllegalArgumentException(paramCharSequence.toString());
  }
  
  public static String f0(String paramString, int paramInt, char paramChar) {
    u1.r.e(paramString, "<this>");
    return e0(paramString, paramInt, paramChar).toString();
  }
  
  private static final d<f> g0(CharSequence paramCharSequence, char[] paramArrayOfchar, int paramInt1, boolean paramBoolean, int paramInt2) {
    n0(paramInt2);
    return new e(paramCharSequence, paramInt1, paramInt2, new a(paramArrayOfchar, paramBoolean));
  }
  
  private static final d<f> h0(CharSequence paramCharSequence, String[] paramArrayOfString, int paramInt1, boolean paramBoolean, int paramInt2) {
    n0(paramInt2);
    return new e(paramCharSequence, paramInt1, paramInt2, new b(h.c((Object[])paramArrayOfString), paramBoolean));
  }
  
  public static final boolean k0(CharSequence paramCharSequence1, int paramInt1, CharSequence paramCharSequence2, int paramInt2, int paramInt3, boolean paramBoolean) {
    u1.r.e(paramCharSequence1, "<this>");
    u1.r.e(paramCharSequence2, "other");
    if (paramInt2 >= 0 && paramInt1 >= 0 && paramInt1 <= paramCharSequence1.length() - paramInt3) {
      if (paramInt2 > paramCharSequence2.length() - paramInt3)
        return false; 
      int i;
      for (i = 0; i < paramInt3; i++) {
        if (!c.d(paramCharSequence1.charAt(paramInt1 + i), paramCharSequence2.charAt(paramInt2 + i), paramBoolean))
          return false; 
      } 
      return true;
    } 
    return false;
  }
  
  public static String l0(String paramString, CharSequence paramCharSequence) {
    u1.r.e(paramString, "<this>");
    u1.r.e(paramCharSequence, "prefix");
    String str = paramString;
    if (y0(paramString, paramCharSequence, false, 2, null)) {
      str = paramString.substring(paramCharSequence.length());
      u1.r.d(str, "this as java.lang.String).substring(startIndex)");
    } 
    return str;
  }
  
  public static String m0(String paramString, CharSequence paramCharSequence) {
    u1.r.e(paramString, "<this>");
    u1.r.e(paramCharSequence, "suffix");
    String str = paramString;
    if (M(paramString, paramCharSequence, false, 2, null)) {
      str = paramString.substring(0, paramString.length() - paramCharSequence.length());
      u1.r.d(str, "this as java.lang.String…ing(startIndex, endIndex)");
    } 
    return str;
  }
  
  public static final void n0(int paramInt) {
    boolean bool;
    if (paramInt >= 0) {
      bool = true;
    } else {
      bool = false;
    } 
    if (bool)
      return; 
    StringBuilder stringBuilder = new StringBuilder();
    stringBuilder.append("Limit must be non-negative, but was ");
    stringBuilder.append(paramInt);
    throw new IllegalArgumentException(stringBuilder.toString().toString());
  }
  
  public static final List<String> o0(CharSequence paramCharSequence, char[] paramArrayOfchar, boolean paramBoolean, int paramInt) {
    u1.r.e(paramCharSequence, "<this>");
    u1.r.e(paramArrayOfchar, "delimiters");
    if (paramArrayOfchar.length == 1)
      return q0(paramCharSequence, String.valueOf(paramArrayOfchar[0]), paramBoolean, paramInt); 
    Iterable iterable = e.c(i0(paramCharSequence, paramArrayOfchar, 0, paramBoolean, paramInt, 2, null));
    ArrayList<String> arrayList = new ArrayList(o.o(iterable, 10));
    Iterator<f> iterator = iterable.iterator();
    while (iterator.hasNext())
      arrayList.add(z0(paramCharSequence, iterator.next())); 
    return arrayList;
  }
  
  public static final List<String> p0(CharSequence paramCharSequence, String[] paramArrayOfString, boolean paramBoolean, int paramInt) {
    u1.r.e(paramCharSequence, "<this>");
    u1.r.e(paramArrayOfString, "delimiters");
    int i = paramArrayOfString.length;
    boolean bool = true;
    if (i == 1) {
      String str = paramArrayOfString[0];
      if (str.length() != 0)
        bool = false; 
      if (!bool)
        return q0(paramCharSequence, str, paramBoolean, paramInt); 
    } 
    Iterable iterable = e.c(j0(paramCharSequence, paramArrayOfString, 0, paramBoolean, paramInt, 2, null));
    ArrayList<String> arrayList = new ArrayList(o.o(iterable, 10));
    Iterator<f> iterator = iterable.iterator();
    while (iterator.hasNext())
      arrayList.add(z0(paramCharSequence, iterator.next())); 
    return arrayList;
  }
  
  private static final List<String> q0(CharSequence paramCharSequence, String paramString, boolean paramBoolean, int paramInt) {
    boolean bool;
    n0(paramInt);
    int j = 0;
    int k = R(paramCharSequence, paramString, 0, paramBoolean);
    if (k == -1 || paramInt == 1)
      return o.b(paramCharSequence.toString()); 
    if (paramInt > 0) {
      bool = true;
    } else {
      bool = false;
    } 
    int i = 10;
    if (bool)
      i = j.d(paramInt, 10); 
    ArrayList<String> arrayList = new ArrayList(i);
    i = k;
    while (true) {
      arrayList.add(paramCharSequence.subSequence(j, i).toString());
      k = paramString.length() + i;
      if (!bool || arrayList.size() != paramInt - 1) {
        int m = R(paramCharSequence, paramString, k, paramBoolean);
        j = k;
        i = m;
        if (m == -1)
          break; 
        continue;
      } 
      break;
    } 
    arrayList.add(paramCharSequence.subSequence(k, paramCharSequence.length()).toString());
    return arrayList;
  }
  
  public static final d<String> t0(CharSequence paramCharSequence, String[] paramArrayOfString, boolean paramBoolean, int paramInt) {
    u1.r.e(paramCharSequence, "<this>");
    u1.r.e(paramArrayOfString, "delimiters");
    return e.h(j0(paramCharSequence, paramArrayOfString, 0, paramBoolean, paramInt, 2, null), new c(paramCharSequence));
  }
  
  public static final boolean v0(CharSequence paramCharSequence, char paramChar, boolean paramBoolean) {
    u1.r.e(paramCharSequence, "<this>");
    int i = paramCharSequence.length();
    boolean bool2 = false;
    boolean bool1 = bool2;
    if (i > 0) {
      bool1 = bool2;
      if (c.d(paramCharSequence.charAt(0), paramChar, paramBoolean))
        bool1 = true; 
    } 
    return bool1;
  }
  
  public static final boolean w0(CharSequence paramCharSequence1, CharSequence paramCharSequence2, boolean paramBoolean) {
    u1.r.e(paramCharSequence1, "<this>");
    u1.r.e(paramCharSequence2, "prefix");
    return (!paramBoolean && paramCharSequence1 instanceof String && paramCharSequence2 instanceof String) ? h.F((String)paramCharSequence1, (String)paramCharSequence2, false, 2, null) : k0(paramCharSequence1, 0, paramCharSequence2, 0, paramCharSequence2.length(), paramBoolean);
  }
  
  public static final String z0(CharSequence paramCharSequence, f paramf) {
    u1.r.e(paramCharSequence, "<this>");
    u1.r.e(paramf, "range");
    return paramCharSequence.subSequence(paramf.l().intValue(), paramf.k().intValue() + 1).toString();
  }
  
  static final class a extends s implements p<CharSequence, Integer, i1.r<? extends Integer, ? extends Integer>> {
    a(char[] param1ArrayOfchar, boolean param1Boolean) {
      super(2);
    }
    
    public final i1.r<Integer, Integer> a(CharSequence param1CharSequence, int param1Int) {
      u1.r.e(param1CharSequence, "$this$$receiver");
      param1Int = r.W(param1CharSequence, this.b, param1Int, this.c);
      return (param1Int < 0) ? null : x.a(Integer.valueOf(param1Int), Integer.valueOf(1));
    }
  }
  
  static final class b extends s implements p<CharSequence, Integer, i1.r<? extends Integer, ? extends Integer>> {
    b(List<String> param1List, boolean param1Boolean) {
      super(2);
    }
    
    public final i1.r<Integer, Integer> a(CharSequence param1CharSequence, int param1Int) {
      u1.r.e(param1CharSequence, "$this$$receiver");
      i1.r r = r.G(param1CharSequence, this.b, param1Int, this.c, false);
      return (r != null) ? x.a(r.d(), Integer.valueOf(((String)r.e()).length())) : null;
    }
  }
  
  static final class c extends s implements l<f, String> {
    c(CharSequence param1CharSequence) {
      super(1);
    }
    
    public final String a(f param1f) {
      u1.r.e(param1f, "it");
      return r.z0(this.b, param1f);
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Hill race-dex2jar.jar!\c2\r.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */