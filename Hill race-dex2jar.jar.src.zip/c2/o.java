package c2;

import u1.r;

class o extends n {
  public static Double i(String paramString) {
    r.e(paramString, "<this>");
    Double double_ = null;
    try {
      if (g.b.a(paramString)) {
        double d = Double.parseDouble(paramString);
        double_ = Double.valueOf(d);
      } 
      return double_;
    } catch (NumberFormatException numberFormatException) {
      return null;
    } 
  }
}


/* Location:              C:\soft\dex2jar-2.0\Hill race-dex2jar.jar!\c2\o.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */