package c2;

public final class a extends c {}


/* Location:              C:\soft\dex2jar-2.0\Hill race-dex2jar.jar!\c2\a.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */