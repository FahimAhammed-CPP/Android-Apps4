package c2;

import b2.d;
import i1.r;
import java.util.Iterator;
import java.util.NoSuchElementException;
import t1.p;
import u1.r;
import z1.f;
import z1.j;

final class e implements d<f> {
  private final CharSequence a;
  
  private final int b;
  
  private final int c;
  
  private final p<CharSequence, Integer, r<Integer, Integer>> d;
  
  public e(CharSequence paramCharSequence, int paramInt1, int paramInt2, p<? super CharSequence, ? super Integer, r<Integer, Integer>> paramp) {
    this.a = paramCharSequence;
    this.b = paramInt1;
    this.c = paramInt2;
    this.d = (p)paramp;
  }
  
  public Iterator<f> iterator() {
    return new a(this);
  }
  
  public static final class a implements Iterator<f>, v1.a {
    private int b = -1;
    
    private int c;
    
    private int d;
    
    private f e;
    
    private int f;
    
    a(e param1e) {
      int i = j.f(e.e(param1e), 0, e.c(param1e).length());
      this.c = i;
      this.d = i;
    }
    
    private final void a() {
      // Byte code:
      //   0: aload_0
      //   1: getfield d : I
      //   4: istore_2
      //   5: iconst_0
      //   6: istore_1
      //   7: iload_2
      //   8: ifge -> 22
      //   11: aload_0
      //   12: iconst_0
      //   13: putfield b : I
      //   16: aload_0
      //   17: aconst_null
      //   18: putfield e : Lz1/f;
      //   21: return
      //   22: aload_0
      //   23: getfield g : Lc2/e;
      //   26: invokestatic d : (Lc2/e;)I
      //   29: ifle -> 55
      //   32: aload_0
      //   33: getfield f : I
      //   36: iconst_1
      //   37: iadd
      //   38: istore_2
      //   39: aload_0
      //   40: iload_2
      //   41: putfield f : I
      //   44: iload_2
      //   45: aload_0
      //   46: getfield g : Lc2/e;
      //   49: invokestatic d : (Lc2/e;)I
      //   52: if_icmpge -> 74
      //   55: aload_0
      //   56: getfield d : I
      //   59: aload_0
      //   60: getfield g : Lc2/e;
      //   63: invokestatic c : (Lc2/e;)Ljava/lang/CharSequence;
      //   66: invokeinterface length : ()I
      //   71: if_icmple -> 107
      //   74: aload_0
      //   75: new z1/f
      //   78: dup
      //   79: aload_0
      //   80: getfield c : I
      //   83: aload_0
      //   84: getfield g : Lc2/e;
      //   87: invokestatic c : (Lc2/e;)Ljava/lang/CharSequence;
      //   90: invokestatic P : (Ljava/lang/CharSequence;)I
      //   93: invokespecial <init> : (II)V
      //   96: putfield e : Lz1/f;
      //   99: aload_0
      //   100: iconst_m1
      //   101: putfield d : I
      //   104: goto -> 234
      //   107: aload_0
      //   108: getfield g : Lc2/e;
      //   111: invokestatic b : (Lc2/e;)Lt1/p;
      //   114: aload_0
      //   115: getfield g : Lc2/e;
      //   118: invokestatic c : (Lc2/e;)Ljava/lang/CharSequence;
      //   121: aload_0
      //   122: getfield d : I
      //   125: invokestatic valueOf : (I)Ljava/lang/Integer;
      //   128: invokeinterface invoke : (Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
      //   133: checkcast i1/r
      //   136: astore #4
      //   138: aload #4
      //   140: ifnonnull -> 176
      //   143: aload_0
      //   144: new z1/f
      //   147: dup
      //   148: aload_0
      //   149: getfield c : I
      //   152: aload_0
      //   153: getfield g : Lc2/e;
      //   156: invokestatic c : (Lc2/e;)Ljava/lang/CharSequence;
      //   159: invokestatic P : (Ljava/lang/CharSequence;)I
      //   162: invokespecial <init> : (II)V
      //   165: putfield e : Lz1/f;
      //   168: aload_0
      //   169: iconst_m1
      //   170: putfield d : I
      //   173: goto -> 234
      //   176: aload #4
      //   178: invokevirtual b : ()Ljava/lang/Object;
      //   181: checkcast java/lang/Number
      //   184: invokevirtual intValue : ()I
      //   187: istore_3
      //   188: aload #4
      //   190: invokevirtual c : ()Ljava/lang/Object;
      //   193: checkcast java/lang/Number
      //   196: invokevirtual intValue : ()I
      //   199: istore_2
      //   200: aload_0
      //   201: aload_0
      //   202: getfield c : I
      //   205: iload_3
      //   206: invokestatic j : (II)Lz1/f;
      //   209: putfield e : Lz1/f;
      //   212: iload_3
      //   213: iload_2
      //   214: iadd
      //   215: istore_3
      //   216: aload_0
      //   217: iload_3
      //   218: putfield c : I
      //   221: iload_2
      //   222: ifne -> 227
      //   225: iconst_1
      //   226: istore_1
      //   227: aload_0
      //   228: iload_3
      //   229: iload_1
      //   230: iadd
      //   231: putfield d : I
      //   234: aload_0
      //   235: iconst_1
      //   236: putfield b : I
      //   239: return
    }
    
    public f b() {
      if (this.b == -1)
        a(); 
      if (this.b != 0) {
        f f1 = this.e;
        r.c(f1, "null cannot be cast to non-null type kotlin.ranges.IntRange");
        this.e = null;
        this.b = -1;
        return f1;
      } 
      throw new NoSuchElementException();
    }
    
    public boolean hasNext() {
      if (this.b == -1)
        a(); 
      return (this.b == 1);
    }
    
    public void remove() {
      throw new UnsupportedOperationException("Operation is not supported for read-only collection");
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Hill race-dex2jar.jar!\c2\e.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */