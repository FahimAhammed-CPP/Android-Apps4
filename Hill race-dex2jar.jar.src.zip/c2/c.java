package c2;

class c extends b {
  public static final boolean d(char paramChar1, char paramChar2, boolean paramBoolean) {
    boolean bool = true;
    if (paramChar1 == paramChar2)
      return true; 
    if (!paramBoolean)
      return false; 
    paramChar1 = Character.toUpperCase(paramChar1);
    paramChar2 = Character.toUpperCase(paramChar2);
    paramBoolean = bool;
    if (paramChar1 != paramChar2) {
      if (Character.toLowerCase(paramChar1) == Character.toLowerCase(paramChar2))
        return true; 
      paramBoolean = false;
    } 
    return paramBoolean;
  }
  
  public static String e(char paramChar) {
    return z.a(paramChar);
  }
}


/* Location:              C:\soft\dex2jar-2.0\Hill race-dex2jar.jar!\c2\c.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */