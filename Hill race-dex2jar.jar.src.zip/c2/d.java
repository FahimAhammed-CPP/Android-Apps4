package c2;

import java.nio.charset.Charset;
import u1.r;

public final class d {
  public static final d a = new d();
  
  public static final Charset b;
  
  public static final Charset c;
  
  public static final Charset d;
  
  public static final Charset e;
  
  public static final Charset f;
  
  public static final Charset g;
  
  private static volatile Charset h;
  
  private static volatile Charset i;
  
  static {
    Charset charset = Charset.forName("UTF-8");
    r.d(charset, "forName(\"UTF-8\")");
    b = charset;
    charset = Charset.forName("UTF-16");
    r.d(charset, "forName(\"UTF-16\")");
    c = charset;
    charset = Charset.forName("UTF-16BE");
    r.d(charset, "forName(\"UTF-16BE\")");
    d = charset;
    charset = Charset.forName("UTF-16LE");
    r.d(charset, "forName(\"UTF-16LE\")");
    e = charset;
    charset = Charset.forName("US-ASCII");
    r.d(charset, "forName(\"US-ASCII\")");
    f = charset;
    charset = Charset.forName("ISO-8859-1");
    r.d(charset, "forName(\"ISO-8859-1\")");
    g = charset;
  }
  
  public final Charset a() {
    Charset charset2 = i;
    Charset charset1 = charset2;
    if (charset2 == null) {
      charset1 = Charset.forName("UTF-32BE");
      r.d(charset1, "forName(\"UTF-32BE\")");
      i = charset1;
    } 
    return charset1;
  }
  
  public final Charset b() {
    Charset charset2 = h;
    Charset charset1 = charset2;
    if (charset2 == null) {
      charset1 = Charset.forName("UTF-32LE");
      r.d(charset1, "forName(\"UTF-32LE\")");
      h = charset1;
    } 
    return charset1;
  }
}


/* Location:              C:\soft\dex2jar-2.0\Hill race-dex2jar.jar!\c2\d.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */