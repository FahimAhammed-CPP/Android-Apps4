package c2;

import u1.r;

class p extends o {
  public static final Void j(String paramString) {
    r.e(paramString, "input");
    StringBuilder stringBuilder = new StringBuilder();
    stringBuilder.append("Invalid number format: '");
    stringBuilder.append(paramString);
    stringBuilder.append('\'');
    throw new NumberFormatException(stringBuilder.toString());
  }
  
  public static Integer k(String paramString) {
    r.e(paramString, "<this>");
    return l(paramString, 10);
  }
  
  public static final Integer l(String paramString, int paramInt) {
    r.e(paramString, "<this>");
    a.a(paramInt);
    int i1 = paramString.length();
    if (i1 == 0)
      return null; 
    int m = 0;
    char c = paramString.charAt(0);
    int k = r.f(c, 48);
    int j = -2147483647;
    int i = 1;
    if (k < 0) {
      if (i1 == 1)
        return null; 
      if (c == '-') {
        j = Integer.MIN_VALUE;
        c = '\001';
      } else if (c == '+') {
        c = Character.MIN_VALUE;
      } else {
        return null;
      } 
    } else {
      c = Character.MIN_VALUE;
      i = 0;
    } 
    int n;
    for (n = -59652323; i < i1; n = k) {
      int i2 = b.b(paramString.charAt(i), paramInt);
      if (i2 < 0)
        return null; 
      k = n;
      if (m < n)
        if (n == -59652323) {
          n = j / paramInt;
          k = n;
          if (m < n)
            return null; 
        } else {
          return null;
        }  
      m *= paramInt;
      if (m < j + i2)
        return null; 
      m -= i2;
      i++;
    } 
    return (c != '\000') ? Integer.valueOf(m) : Integer.valueOf(-m);
  }
  
  public static Long m(String paramString) {
    r.e(paramString, "<this>");
    return n(paramString, 10);
  }
  
  public static final Long n(String paramString, int paramInt) {
    r.e(paramString, "<this>");
    a.a(paramInt);
    int j = paramString.length();
    if (j == 0)
      return null; 
    int i = 0;
    char c = paramString.charAt(0);
    int k = r.f(c, 48);
    long l = -9223372036854775807L;
    boolean bool = true;
    if (k < 0) {
      if (j == 1)
        return null; 
      if (c == '-') {
        l = Long.MIN_VALUE;
        i = 1;
      } else {
        if (c == '+') {
          i = 1;
        } else {
          return null;
        } 
        bool = false;
      } 
      long l1 = 0L;
      long l2;
      for (l2 = -256204778801521550L; i < j; l2 = l3) {
        int m = b.b(paramString.charAt(i), paramInt);
        if (m < 0)
          return null; 
        long l3 = l2;
        if (l1 < l2)
          if (l2 == -256204778801521550L) {
            l2 = l / paramInt;
            l3 = l2;
            if (l1 < l2)
              return null; 
          } else {
            return null;
          }  
        l1 *= paramInt;
        l2 = m;
        if (l1 < l + l2)
          return null; 
        l1 -= l2;
        i++;
      } 
      return bool ? Long.valueOf(l1) : Long.valueOf(-l1);
    } 
    bool = false;
  }
}


/* Location:              C:\soft\dex2jar-2.0\Hill race-dex2jar.jar!\c2\p.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */