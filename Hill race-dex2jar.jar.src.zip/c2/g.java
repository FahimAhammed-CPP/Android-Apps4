package c2;

final class g {
  public static final g a = new g();
  
  public static final f b;
  
  static {
    StringBuilder stringBuilder1 = new StringBuilder();
    stringBuilder1.append("[eE][+-]?");
    stringBuilder1.append("(\\p{Digit}+)");
    String str1 = stringBuilder1.toString();
    StringBuilder stringBuilder3 = new StringBuilder();
    stringBuilder3.append("(0[xX]");
    stringBuilder3.append("(\\p{XDigit}+)");
    stringBuilder3.append("(\\.)?)|(0[xX]");
    stringBuilder3.append("(\\p{XDigit}+)");
    stringBuilder3.append("?(\\.)");
    stringBuilder3.append("(\\p{XDigit}+)");
    stringBuilder3.append(')');
    String str2 = stringBuilder3.toString();
    StringBuilder stringBuilder4 = new StringBuilder();
    stringBuilder4.append('(');
    stringBuilder4.append("(\\p{Digit}+)");
    stringBuilder4.append("(\\.)?(");
    stringBuilder4.append("(\\p{Digit}+)");
    stringBuilder4.append("?)(");
    stringBuilder4.append(str1);
    stringBuilder4.append(")?)|(\\.(");
    stringBuilder4.append("(\\p{Digit}+)");
    stringBuilder4.append(")(");
    stringBuilder4.append(str1);
    stringBuilder4.append(")?)|((");
    stringBuilder4.append(str2);
    stringBuilder4.append(")[pP][+-]?");
    stringBuilder4.append("(\\p{Digit}+)");
    stringBuilder4.append(')');
    str1 = stringBuilder4.toString();
    StringBuilder stringBuilder2 = new StringBuilder();
    stringBuilder2.append("[\\x00-\\x20]*[+-]?(NaN|Infinity|((");
    stringBuilder2.append(str1);
    stringBuilder2.append(")[fFdD]?))[\\x00-\\x20]*");
    b = new f(stringBuilder2.toString());
  }
}


/* Location:              C:\soft\dex2jar-2.0\Hill race-dex2jar.jar!\c2\g.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */