package c2;

import z1.f;

class b {
  public static int a(int paramInt) {
    if ((new f(2, 36)).j(paramInt))
      return paramInt; 
    StringBuilder stringBuilder = new StringBuilder();
    stringBuilder.append("radix ");
    stringBuilder.append(paramInt);
    stringBuilder.append(" was not in valid range ");
    stringBuilder.append(new f(2, 36));
    throw new IllegalArgumentException(stringBuilder.toString());
  }
  
  public static final int b(char paramChar, int paramInt) {
    return Character.digit(paramChar, paramInt);
  }
  
  public static final boolean c(char paramChar) {
    return (Character.isWhitespace(paramChar) || Character.isSpaceChar(paramChar));
  }
}


/* Location:              C:\soft\dex2jar-2.0\Hill race-dex2jar.jar!\c2\b.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */