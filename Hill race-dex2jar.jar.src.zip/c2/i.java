package c2;

import t1.l;
import u1.r;

class i {
  public static <T> void a(Appendable paramAppendable, T paramT, l<? super T, ? extends CharSequence> paraml) {
    boolean bool;
    r.e(paramAppendable, "<this>");
    if (paraml != null) {
      paramAppendable.append((CharSequence)paraml.invoke(paramT));
      return;
    } 
    if (paramT == null) {
      bool = true;
    } else {
      bool = paramT instanceof CharSequence;
    } 
    if (bool) {
      paramAppendable.append((CharSequence)paramT);
      return;
    } 
    if (paramT instanceof Character) {
      paramAppendable.append(((Character)paramT).charValue());
      return;
    } 
    paramAppendable.append(String.valueOf(paramT));
  }
}


/* Location:              C:\soft\dex2jar-2.0\Hill race-dex2jar.jar!\c2\i.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */