package c2;

import j1.o;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import t1.l;
import u1.r;
import u1.s;

class j extends i {
  private static final l<String, String> b(String paramString) {
    boolean bool;
    if (paramString.length() == 0) {
      bool = true;
    } else {
      bool = false;
    } 
    return (l<String, String>)(bool ? a.b : new b(paramString));
  }
  
  private static final int c(String paramString) {
    // Byte code:
    //   0: aload_0
    //   1: invokeinterface length : ()I
    //   6: istore_2
    //   7: iconst_0
    //   8: istore_1
    //   9: iload_1
    //   10: iload_2
    //   11: if_icmpge -> 39
    //   14: aload_0
    //   15: iload_1
    //   16: invokeinterface charAt : (I)C
    //   21: invokestatic c : (C)Z
    //   24: iconst_1
    //   25: ixor
    //   26: ifeq -> 32
    //   29: goto -> 41
    //   32: iload_1
    //   33: iconst_1
    //   34: iadd
    //   35: istore_1
    //   36: goto -> 9
    //   39: iconst_m1
    //   40: istore_1
    //   41: iload_1
    //   42: istore_2
    //   43: iload_1
    //   44: iconst_m1
    //   45: if_icmpne -> 53
    //   48: aload_0
    //   49: invokevirtual length : ()I
    //   52: istore_2
    //   53: iload_2
    //   54: ireturn
  }
  
  public static final String d(String paramString1, String paramString2) {
    boolean bool;
    r.e(paramString1, "<this>");
    r.e(paramString2, "newIndent");
    List<String> list = r.d0(paramString1);
    ArrayList<String> arrayList = new ArrayList();
    for (String str : list) {
      if ((h.u(str) ^ true) != 0)
        arrayList.add(str); 
    } 
    ArrayList<Integer> arrayList1 = new ArrayList(o.o(arrayList, 10));
    Iterator<String> iterator = arrayList.iterator();
    while (iterator.hasNext())
      arrayList1.add(Integer.valueOf(c(iterator.next()))); 
    Integer integer = (Integer)o.H(arrayList1);
    int k = 0;
    if (integer != null) {
      bool = integer.intValue();
    } else {
      bool = false;
    } 
    int m = paramString1.length();
    int n = paramString2.length();
    int i1 = list.size();
    l<String, String> l = b(paramString2);
    int i2 = o.g(list);
    arrayList1 = new ArrayList<Integer>();
    for (String paramString1 : list) {
      if (k)
        o.n(); 
      paramString2 = paramString1;
      if ((!k || k == i2) && h.u(paramString2)) {
        paramString1 = null;
      } else {
        String str = h.M0(paramString2, bool);
        paramString1 = paramString2;
        if (str != null) {
          paramString1 = (String)l.invoke(str);
          if (paramString1 == null)
            paramString1 = paramString2; 
        } 
      } 
      if (paramString1 != null)
        arrayList1.add(paramString1); 
      k++;
    } 
    paramString1 = ((StringBuilder)o.C(arrayList1, new StringBuilder(m + n * i1), "\n", null, null, 0, null, null, 124, null)).toString();
    r.d(paramString1, "mapIndexedNotNull { inde…\"\\n\")\n        .toString()");
    return paramString1;
  }
  
  public static final String e(String paramString1, String paramString2, String paramString3) {
    // Byte code:
    //   0: aload_0
    //   1: ldc '<this>'
    //   3: invokestatic e : (Ljava/lang/Object;Ljava/lang/String;)V
    //   6: aload_1
    //   7: ldc 'newIndent'
    //   9: invokestatic e : (Ljava/lang/Object;Ljava/lang/String;)V
    //   12: aload_2
    //   13: ldc 'marginPrefix'
    //   15: invokestatic e : (Ljava/lang/Object;Ljava/lang/String;)V
    //   18: aload_2
    //   19: invokestatic u : (Ljava/lang/CharSequence;)Z
    //   22: iconst_1
    //   23: ixor
    //   24: ifeq -> 338
    //   27: aload_0
    //   28: invokestatic d0 : (Ljava/lang/CharSequence;)Ljava/util/List;
    //   31: astore #10
    //   33: aload_0
    //   34: invokevirtual length : ()I
    //   37: istore #5
    //   39: aload_1
    //   40: invokevirtual length : ()I
    //   43: istore #6
    //   45: aload #10
    //   47: invokeinterface size : ()I
    //   52: istore #7
    //   54: aload_1
    //   55: invokestatic b : (Ljava/lang/String;)Lt1/l;
    //   58: astore #11
    //   60: aload #10
    //   62: invokestatic g : (Ljava/util/List;)I
    //   65: istore #8
    //   67: new java/util/ArrayList
    //   70: dup
    //   71: invokespecial <init> : ()V
    //   74: astore #12
    //   76: aload #10
    //   78: invokeinterface iterator : ()Ljava/util/Iterator;
    //   83: astore #13
    //   85: iconst_0
    //   86: istore #4
    //   88: aload #13
    //   90: invokeinterface hasNext : ()Z
    //   95: ifeq -> 293
    //   98: aload #13
    //   100: invokeinterface next : ()Ljava/lang/Object;
    //   105: astore_0
    //   106: iload #4
    //   108: ifge -> 114
    //   111: invokestatic n : ()V
    //   114: aload_0
    //   115: checkcast java/lang/String
    //   118: astore #10
    //   120: aconst_null
    //   121: astore_1
    //   122: iload #4
    //   124: ifeq -> 134
    //   127: iload #4
    //   129: iload #8
    //   131: if_icmpne -> 147
    //   134: aload #10
    //   136: invokestatic u : (Ljava/lang/CharSequence;)Z
    //   139: ifeq -> 147
    //   142: aconst_null
    //   143: astore_0
    //   144: goto -> 271
    //   147: aload #10
    //   149: invokeinterface length : ()I
    //   154: istore #9
    //   156: iconst_0
    //   157: istore_3
    //   158: iload_3
    //   159: iload #9
    //   161: if_icmpge -> 190
    //   164: aload #10
    //   166: iload_3
    //   167: invokeinterface charAt : (I)C
    //   172: invokestatic c : (C)Z
    //   175: iconst_1
    //   176: ixor
    //   177: ifeq -> 183
    //   180: goto -> 192
    //   183: iload_3
    //   184: iconst_1
    //   185: iadd
    //   186: istore_3
    //   187: goto -> 158
    //   190: iconst_m1
    //   191: istore_3
    //   192: iload_3
    //   193: iconst_m1
    //   194: if_icmpne -> 200
    //   197: goto -> 242
    //   200: aload #10
    //   202: aload_2
    //   203: iload_3
    //   204: iconst_0
    //   205: iconst_4
    //   206: aconst_null
    //   207: invokestatic E : (Ljava/lang/String;Ljava/lang/String;IZILjava/lang/Object;)Z
    //   210: ifeq -> 242
    //   213: aload_2
    //   214: invokevirtual length : ()I
    //   217: istore #9
    //   219: aload #10
    //   221: ldc 'null cannot be cast to non-null type java.lang.String'
    //   223: invokestatic c : (Ljava/lang/Object;Ljava/lang/String;)V
    //   226: aload #10
    //   228: iload_3
    //   229: iload #9
    //   231: iadd
    //   232: invokevirtual substring : (I)Ljava/lang/String;
    //   235: astore_1
    //   236: aload_1
    //   237: ldc 'this as java.lang.String).substring(startIndex)'
    //   239: invokestatic d : (Ljava/lang/Object;Ljava/lang/String;)V
    //   242: aload #10
    //   244: astore_0
    //   245: aload_1
    //   246: ifnull -> 271
    //   249: aload #11
    //   251: aload_1
    //   252: invokeinterface invoke : (Ljava/lang/Object;)Ljava/lang/Object;
    //   257: checkcast java/lang/String
    //   260: astore_0
    //   261: aload_0
    //   262: ifnonnull -> 271
    //   265: aload #10
    //   267: astore_0
    //   268: goto -> 271
    //   271: aload_0
    //   272: ifnull -> 284
    //   275: aload #12
    //   277: aload_0
    //   278: invokeinterface add : (Ljava/lang/Object;)Z
    //   283: pop
    //   284: iload #4
    //   286: iconst_1
    //   287: iadd
    //   288: istore #4
    //   290: goto -> 88
    //   293: aload #12
    //   295: new java/lang/StringBuilder
    //   298: dup
    //   299: iload #5
    //   301: iload #6
    //   303: iload #7
    //   305: imul
    //   306: iadd
    //   307: invokespecial <init> : (I)V
    //   310: ldc '\\n'
    //   312: aconst_null
    //   313: aconst_null
    //   314: iconst_0
    //   315: aconst_null
    //   316: aconst_null
    //   317: bipush #124
    //   319: aconst_null
    //   320: invokestatic C : (Ljava/lang/Iterable;Ljava/lang/Appendable;Ljava/lang/CharSequence;Ljava/lang/CharSequence;Ljava/lang/CharSequence;ILjava/lang/CharSequence;Lt1/l;ILjava/lang/Object;)Ljava/lang/Appendable;
    //   323: checkcast java/lang/StringBuilder
    //   326: invokevirtual toString : ()Ljava/lang/String;
    //   329: astore_0
    //   330: aload_0
    //   331: ldc 'mapIndexedNotNull { inde…"\n")\\n        .toString()'
    //   333: invokestatic d : (Ljava/lang/Object;Ljava/lang/String;)V
    //   336: aload_0
    //   337: areturn
    //   338: new java/lang/IllegalArgumentException
    //   341: dup
    //   342: ldc 'marginPrefix must be non-blank string.'
    //   344: invokevirtual toString : ()Ljava/lang/String;
    //   347: invokespecial <init> : (Ljava/lang/String;)V
    //   350: athrow
  }
  
  public static String f(String paramString) {
    r.e(paramString, "<this>");
    return d(paramString, "");
  }
  
  public static final String g(String paramString1, String paramString2) {
    r.e(paramString1, "<this>");
    r.e(paramString2, "marginPrefix");
    return e(paramString1, "", paramString2);
  }
  
  static final class a extends s implements l<String, String> {
    public static final a b = new a();
    
    a() {
      super(1);
    }
    
    public final String a(String param1String) {
      r.e(param1String, "line");
      return param1String;
    }
  }
  
  static final class b extends s implements l<String, String> {
    b(String param1String) {
      super(1);
    }
    
    public final String a(String param1String) {
      r.e(param1String, "line");
      StringBuilder stringBuilder = new StringBuilder();
      stringBuilder.append(this.b);
      stringBuilder.append(param1String);
      return stringBuilder.toString();
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Hill race-dex2jar.jar!\c2\j.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */