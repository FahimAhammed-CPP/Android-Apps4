package b1;

public interface a {
  String getLanguage();
  
  String getTimeZoneId();
}


/* Location:              C:\soft\dex2jar-2.0\Hill race-dex2jar.jar!\b1\a.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */