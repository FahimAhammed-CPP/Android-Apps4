package b1;

import java.util.Locale;
import java.util.TimeZone;
import u1.r;

public final class b implements a {
  public String getLanguage() {
    String str = Locale.getDefault().getLanguage();
    r.d(str, "getDefault().language");
    return str;
  }
  
  public String getTimeZoneId() {
    String str = TimeZone.getDefault().getID();
    r.d(str, "getDefault().id");
    return str;
  }
}


/* Location:              C:\soft\dex2jar-2.0\Hill race-dex2jar.jar!\b1\b.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */