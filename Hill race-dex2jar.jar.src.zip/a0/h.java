package a0;

import java.util.List;

public interface h {
  List<String> a();
  
  void b(g paramg);
  
  g c(String paramString);
  
  void d(String paramString);
}


/* Location:              C:\soft\dex2jar-2.0\Hill race-dex2jar.jar!\a0\h.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */