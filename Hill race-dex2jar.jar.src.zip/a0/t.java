package a0;

import java.util.List;

public interface t {
  void a(s params);
  
  List<String> b(String paramString);
}


/* Location:              C:\soft\dex2jar-2.0\Hill race-dex2jar.jar!\a0\t.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */