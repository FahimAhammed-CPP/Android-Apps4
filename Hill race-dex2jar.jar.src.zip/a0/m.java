package a0;

import androidx.work.e;

public class m {
  public final String a;
  
  public final e b;
  
  public m(String paramString, e parame) {
    this.a = paramString;
    this.b = parame;
  }
}


/* Location:              C:\soft\dex2jar-2.0\Hill race-dex2jar.jar!\a0\m.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */