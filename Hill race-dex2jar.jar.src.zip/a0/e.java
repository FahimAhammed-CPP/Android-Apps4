package a0;

public interface e {
  Long a(String paramString);
  
  void b(d paramd);
}


/* Location:              C:\soft\dex2jar-2.0\Hill race-dex2jar.jar!\a0\e.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */