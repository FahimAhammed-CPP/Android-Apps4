package a0;

import android.annotation.SuppressLint;
import androidx.work.e;
import androidx.work.u;
import java.util.List;

@SuppressLint({"UnknownNullness"})
public interface q {
  void a(String paramString);
  
  void b(p paramp);
  
  int c(u paramu, String... paramVarArgs);
  
  int d(String paramString, long paramLong);
  
  List<p.b> e(String paramString);
  
  List<p> f(long paramLong);
  
  List<p> g(int paramInt);
  
  List<p> h();
  
  void i(String paramString, e parame);
  
  List<p> j();
  
  boolean k();
  
  List<String> l(String paramString);
  
  u m(String paramString);
  
  p n(String paramString);
  
  int o(String paramString);
  
  List<String> p(String paramString);
  
  List<e> q(String paramString);
  
  int r(String paramString);
  
  void s(String paramString, long paramLong);
  
  List<p> t(int paramInt);
  
  int u();
}


/* Location:              C:\soft\dex2jar-2.0\Hill race-dex2jar.jar!\a0\q.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */