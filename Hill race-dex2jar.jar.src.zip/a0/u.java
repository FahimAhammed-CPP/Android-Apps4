package a0;

import android.database.Cursor;
import androidx.room.h;
import j.c;
import java.util.ArrayList;
import java.util.List;
import l.c;
import m.e;
import m.f;

public final class u implements t {
  private final h a;
  
  private final j.a<s> b;
  
  public u(h paramh) {
    this.a = paramh;
    this.b = new a(this, paramh);
  }
  
  public void a(s params) {
    this.a.b();
    this.a.c();
    try {
      this.b.h(params);
      this.a.r();
      return;
    } finally {
      this.a.g();
    } 
  }
  
  public List<String> b(String paramString) {
    c c = c.a("SELECT DISTINCT tag FROM worktag WHERE work_spec_id=?", 1);
    if (paramString == null) {
      c.r(1);
    } else {
      c.b(1, paramString);
    } 
    this.a.b();
    Cursor cursor = c.b(this.a, (e)c, false, null);
    try {
      ArrayList<String> arrayList = new ArrayList(cursor.getCount());
      while (cursor.moveToNext())
        arrayList.add(cursor.getString(0)); 
      return arrayList;
    } finally {
      cursor.close();
      c.release();
    } 
  }
  
  class a extends j.a<s> {
    a(u this$0, h param1h) {
      super(param1h);
    }
    
    public String d() {
      return "INSERT OR IGNORE INTO `WorkTag` (`tag`,`work_spec_id`) VALUES (?,?)";
    }
    
    public void i(f param1f, s param1s) {
      String str2 = param1s.a;
      if (str2 == null) {
        param1f.r(1);
      } else {
        param1f.b(1, str2);
      } 
      String str1 = param1s.b;
      if (str1 == null) {
        param1f.r(2);
        return;
      } 
      param1f.b(2, str1);
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Hill race-dex2jar.jar!\a\\u.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */