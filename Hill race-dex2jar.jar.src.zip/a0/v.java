package a0;

import android.os.Build;
import androidx.work.d;
import androidx.work.m;
import androidx.work.p;
import androidx.work.u;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.ObjectOutputStream;

public class v {
  public static int a(androidx.work.a parama) {
    int i = a.b[parama.ordinal()];
    if (i != 1) {
      if (i == 2)
        return 1; 
      StringBuilder stringBuilder = new StringBuilder();
      stringBuilder.append("Could not convert ");
      stringBuilder.append(parama);
      stringBuilder.append(" to int");
      throw new IllegalArgumentException(stringBuilder.toString());
    } 
    return 0;
  }
  
  public static d b(byte[] paramArrayOfbyte) {
    // Byte code:
    //   0: new androidx/work/d
    //   3: dup
    //   4: invokespecial <init> : ()V
    //   7: astore #5
    //   9: aload_0
    //   10: ifnonnull -> 16
    //   13: aload #5
    //   15: areturn
    //   16: new java/io/ByteArrayInputStream
    //   19: dup
    //   20: aload_0
    //   21: invokespecial <init> : ([B)V
    //   24: astore #4
    //   26: new java/io/ObjectInputStream
    //   29: dup
    //   30: aload #4
    //   32: invokespecial <init> : (Ljava/io/InputStream;)V
    //   35: astore_2
    //   36: aload_2
    //   37: astore_0
    //   38: aload_2
    //   39: invokevirtual readInt : ()I
    //   42: istore_1
    //   43: iload_1
    //   44: ifle -> 72
    //   47: aload_2
    //   48: astore_0
    //   49: aload #5
    //   51: aload_2
    //   52: invokevirtual readUTF : ()Ljava/lang/String;
    //   55: invokestatic parse : (Ljava/lang/String;)Landroid/net/Uri;
    //   58: aload_2
    //   59: invokevirtual readBoolean : ()Z
    //   62: invokevirtual a : (Landroid/net/Uri;Z)V
    //   65: iload_1
    //   66: iconst_1
    //   67: isub
    //   68: istore_1
    //   69: goto -> 43
    //   72: aload_2
    //   73: invokevirtual close : ()V
    //   76: goto -> 84
    //   79: astore_0
    //   80: aload_0
    //   81: invokevirtual printStackTrace : ()V
    //   84: aload #4
    //   86: invokevirtual close : ()V
    //   89: aload #5
    //   91: areturn
    //   92: astore_3
    //   93: goto -> 105
    //   96: astore_2
    //   97: aconst_null
    //   98: astore_0
    //   99: goto -> 144
    //   102: astore_3
    //   103: aconst_null
    //   104: astore_2
    //   105: aload_2
    //   106: astore_0
    //   107: aload_3
    //   108: invokevirtual printStackTrace : ()V
    //   111: aload_2
    //   112: ifnull -> 127
    //   115: aload_2
    //   116: invokevirtual close : ()V
    //   119: goto -> 127
    //   122: astore_0
    //   123: aload_0
    //   124: invokevirtual printStackTrace : ()V
    //   127: aload #4
    //   129: invokevirtual close : ()V
    //   132: aload #5
    //   134: areturn
    //   135: astore_0
    //   136: aload_0
    //   137: invokevirtual printStackTrace : ()V
    //   140: aload #5
    //   142: areturn
    //   143: astore_2
    //   144: aload_0
    //   145: ifnull -> 160
    //   148: aload_0
    //   149: invokevirtual close : ()V
    //   152: goto -> 160
    //   155: astore_0
    //   156: aload_0
    //   157: invokevirtual printStackTrace : ()V
    //   160: aload #4
    //   162: invokevirtual close : ()V
    //   165: goto -> 173
    //   168: astore_0
    //   169: aload_0
    //   170: invokevirtual printStackTrace : ()V
    //   173: aload_2
    //   174: athrow
    // Exception table:
    //   from	to	target	type
    //   26	36	102	java/io/IOException
    //   26	36	96	finally
    //   38	43	92	java/io/IOException
    //   38	43	143	finally
    //   49	65	92	java/io/IOException
    //   49	65	143	finally
    //   72	76	79	java/io/IOException
    //   84	89	135	java/io/IOException
    //   107	111	143	finally
    //   115	119	122	java/io/IOException
    //   127	132	135	java/io/IOException
    //   148	152	155	java/io/IOException
    //   160	165	168	java/io/IOException
  }
  
  public static byte[] c(d paramd) {
    int i = paramd.c();
    d d2 = null;
    a = null;
    if (i == 0)
      return null; 
    ByteArrayOutputStream byteArrayOutputStream = new ByteArrayOutputStream();
    try {
      ObjectOutputStream objectOutputStream = new ObjectOutputStream(byteArrayOutputStream);
      try {
        objectOutputStream.writeInt(paramd.c());
        for (d.a a : paramd.b()) {
          objectOutputStream.writeUTF(a.a().toString());
          objectOutputStream.writeBoolean(a.b());
        } 
        try {
          objectOutputStream.close();
        } catch (IOException iOException1) {
          iOException1.printStackTrace();
        } 
      } catch (IOException iOException1) {
        ObjectOutputStream objectOutputStream1 = objectOutputStream;
      } finally {
        IOException iOException1;
        paramd = null;
      } 
    } catch (IOException iOException) {
      paramd = d2;
    } finally {}
    d d1 = paramd;
    iOException.printStackTrace();
    if (paramd != null)
      try {
        paramd.close();
      } catch (IOException iOException1) {
        iOException1.printStackTrace();
      }  
    byteArrayOutputStream.close();
    return byteArrayOutputStream.toByteArray();
  }
  
  public static androidx.work.a d(int paramInt) {
    if (paramInt != 0) {
      if (paramInt == 1)
        return androidx.work.a.c; 
      StringBuilder stringBuilder = new StringBuilder();
      stringBuilder.append("Could not convert ");
      stringBuilder.append(paramInt);
      stringBuilder.append(" to BackoffPolicy");
      throw new IllegalArgumentException(stringBuilder.toString());
    } 
    return androidx.work.a.b;
  }
  
  public static m e(int paramInt) {
    if (paramInt != 0) {
      if (paramInt != 1) {
        if (paramInt != 2) {
          if (paramInt != 3) {
            if (paramInt != 4) {
              if (Build.VERSION.SDK_INT >= 30 && paramInt == 5)
                return m.g; 
              StringBuilder stringBuilder = new StringBuilder();
              stringBuilder.append("Could not convert ");
              stringBuilder.append(paramInt);
              stringBuilder.append(" to NetworkType");
              throw new IllegalArgumentException(stringBuilder.toString());
            } 
            return m.f;
          } 
          return m.e;
        } 
        return m.d;
      } 
      return m.c;
    } 
    return m.b;
  }
  
  public static p f(int paramInt) {
    if (paramInt != 0) {
      if (paramInt == 1)
        return p.c; 
      StringBuilder stringBuilder = new StringBuilder();
      stringBuilder.append("Could not convert ");
      stringBuilder.append(paramInt);
      stringBuilder.append(" to OutOfQuotaPolicy");
      throw new IllegalArgumentException(stringBuilder.toString());
    } 
    return p.b;
  }
  
  public static u g(int paramInt) {
    if (paramInt != 0) {
      if (paramInt != 1) {
        if (paramInt != 2) {
          if (paramInt != 3) {
            if (paramInt != 4) {
              if (paramInt == 5)
                return u.g; 
              StringBuilder stringBuilder = new StringBuilder();
              stringBuilder.append("Could not convert ");
              stringBuilder.append(paramInt);
              stringBuilder.append(" to State");
              throw new IllegalArgumentException(stringBuilder.toString());
            } 
            return u.f;
          } 
          return u.e;
        } 
        return u.d;
      } 
      return u.c;
    } 
    return u.b;
  }
  
  public static int h(m paramm) {
    int i = a.c[paramm.ordinal()];
    if (i != 1) {
      if (i != 2) {
        if (i != 3) {
          if (i != 4) {
            if (i != 5) {
              if (Build.VERSION.SDK_INT >= 30 && paramm == m.g)
                return 5; 
              StringBuilder stringBuilder = new StringBuilder();
              stringBuilder.append("Could not convert ");
              stringBuilder.append(paramm);
              stringBuilder.append(" to int");
              throw new IllegalArgumentException(stringBuilder.toString());
            } 
            return 4;
          } 
          return 3;
        } 
        return 2;
      } 
      return 1;
    } 
    return 0;
  }
  
  public static int i(p paramp) {
    int i = a.d[paramp.ordinal()];
    if (i != 1) {
      if (i == 2)
        return 1; 
      StringBuilder stringBuilder = new StringBuilder();
      stringBuilder.append("Could not convert ");
      stringBuilder.append(paramp);
      stringBuilder.append(" to int");
      throw new IllegalArgumentException(stringBuilder.toString());
    } 
    return 0;
  }
  
  public static int j(u paramu) {
    StringBuilder stringBuilder;
    switch (a.a[paramu.ordinal()]) {
      default:
        stringBuilder = new StringBuilder();
        stringBuilder.append("Could not convert ");
        stringBuilder.append(paramu);
        stringBuilder.append(" to int");
        throw new IllegalArgumentException(stringBuilder.toString());
      case 6:
        return 5;
      case 5:
        return 4;
      case 4:
        return 3;
      case 3:
        return 2;
      case 2:
        return 1;
      case 1:
        break;
    } 
    return 0;
  }
}


/* Location:              C:\soft\dex2jar-2.0\Hill race-dex2jar.jar!\a0\v.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */