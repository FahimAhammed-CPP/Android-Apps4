package a0;

import android.database.Cursor;
import androidx.work.u;
import java.util.ArrayList;
import java.util.List;

public final class r implements q {
  private final androidx.room.h a;
  
  private final j.a<p> b;
  
  private final j.d c;
  
  private final j.d d;
  
  private final j.d e;
  
  private final j.d f;
  
  private final j.d g;
  
  private final j.d h;
  
  private final j.d i;
  
  private final j.d j;
  
  public r(androidx.room.h paramh) {
    this.a = paramh;
    this.b = new a(this, paramh);
    this.c = new b(this, paramh);
    this.d = new c(this, paramh);
    this.e = new d(this, paramh);
    this.f = new e(this, paramh);
    this.g = new f(this, paramh);
    this.h = new g(this, paramh);
    this.i = new h(this, paramh);
    this.j = new i(this, paramh);
  }
  
  public void a(String paramString) {
    this.a.b();
    m.f f = this.c.a();
    if (paramString == null) {
      f.r(1);
    } else {
      f.b(1, paramString);
    } 
    this.a.c();
    try {
      f.J();
      this.a.r();
      return;
    } finally {
      this.a.g();
      this.c.f(f);
    } 
  }
  
  public void b(p paramp) {
    this.a.b();
    this.a.c();
    try {
      this.b.h(paramp);
      this.a.r();
      return;
    } finally {
      this.a.g();
    } 
  }
  
  public int c(u paramu, String... paramVarArgs) {
    this.a.b();
    StringBuilder stringBuilder = l.e.b();
    stringBuilder.append("UPDATE workspec SET state=");
    stringBuilder.append("?");
    stringBuilder.append(" WHERE id IN (");
    l.e.a(stringBuilder, paramVarArgs.length);
    stringBuilder.append(")");
    String str = stringBuilder.toString();
    m.f f = this.a.d(str);
    f.j(1, v.j(paramu));
    int k = paramVarArgs.length;
    int j = 2;
    int i;
    for (i = 0; i < k; i++) {
      String str1 = paramVarArgs[i];
      if (str1 == null) {
        f.r(j);
      } else {
        f.b(j, str1);
      } 
      j++;
    } 
    this.a.c();
    try {
      i = f.J();
      this.a.r();
      return i;
    } finally {
      this.a.g();
    } 
  }
  
  public int d(String paramString, long paramLong) {
    this.a.b();
    m.f f = this.h.a();
    f.j(1, paramLong);
    if (paramString == null) {
      f.r(2);
    } else {
      f.b(2, paramString);
    } 
    this.a.c();
    try {
      int i = f.J();
      this.a.r();
      return i;
    } finally {
      this.a.g();
      this.h.f(f);
    } 
  }
  
  public List<p.b> e(String paramString) {
    j.c c = j.c.a("SELECT id, state FROM workspec WHERE id IN (SELECT work_spec_id FROM workname WHERE name=?)", 1);
    if (paramString == null) {
      c.r(1);
    } else {
      c.b(1, paramString);
    } 
    this.a.b();
    Cursor cursor = l.c.b(this.a, (m.e)c, false, null);
    try {
      int i = l.b.b(cursor, "id");
      int j = l.b.b(cursor, "state");
      ArrayList<p.b> arrayList = new ArrayList(cursor.getCount());
      while (cursor.moveToNext()) {
        p.b b = new p.b();
        b.a = cursor.getString(i);
        b.b = v.g(cursor.getInt(j));
        arrayList.add(b);
      } 
      return arrayList;
    } finally {
      cursor.close();
      c.release();
    } 
  }
  
  public List<p> f(long paramLong) {
    Exception exception;
    j.c c = j.c.a("SELECT `required_network_type`, `requires_charging`, `requires_device_idle`, `requires_battery_not_low`, `requires_storage_not_low`, `trigger_content_update_delay`, `trigger_max_content_delay`, `content_uri_triggers`, `WorkSpec`.`id` AS `id`, `WorkSpec`.`state` AS `state`, `WorkSpec`.`worker_class_name` AS `worker_class_name`, `WorkSpec`.`input_merger_class_name` AS `input_merger_class_name`, `WorkSpec`.`input` AS `input`, `WorkSpec`.`output` AS `output`, `WorkSpec`.`initial_delay` AS `initial_delay`, `WorkSpec`.`interval_duration` AS `interval_duration`, `WorkSpec`.`flex_duration` AS `flex_duration`, `WorkSpec`.`run_attempt_count` AS `run_attempt_count`, `WorkSpec`.`backoff_policy` AS `backoff_policy`, `WorkSpec`.`backoff_delay_duration` AS `backoff_delay_duration`, `WorkSpec`.`period_start_time` AS `period_start_time`, `WorkSpec`.`minimum_retention_duration` AS `minimum_retention_duration`, `WorkSpec`.`schedule_requested_at` AS `schedule_requested_at`, `WorkSpec`.`run_in_foreground` AS `run_in_foreground`, `WorkSpec`.`out_of_quota_policy` AS `out_of_quota_policy` FROM workspec WHERE period_start_time >= ? AND state IN (2, 3, 5) ORDER BY period_start_time DESC", 1);
    c.j(1, paramLong);
    this.a.b();
    Cursor cursor = l.c.b(this.a, (m.e)c, false, null);
    try {
      int n = l.b.b(cursor, "required_network_type");
      int i2 = l.b.b(cursor, "requires_charging");
      int j = l.b.b(cursor, "requires_device_idle");
      int i = l.b.b(cursor, "requires_battery_not_low");
      int i4 = l.b.b(cursor, "requires_storage_not_low");
      int i5 = l.b.b(cursor, "trigger_content_update_delay");
      int i6 = l.b.b(cursor, "trigger_max_content_delay");
      int i7 = l.b.b(cursor, "content_uri_triggers");
      int m = l.b.b(cursor, "id");
      int i8 = l.b.b(cursor, "state");
      int k = l.b.b(cursor, "worker_class_name");
      int i1 = l.b.b(cursor, "input_merger_class_name");
      int i9 = l.b.b(cursor, "input");
      int i3 = l.b.b(cursor, "output");
      try {
        int i15 = l.b.b(cursor, "initial_delay");
        int i18 = l.b.b(cursor, "interval_duration");
        int i20 = l.b.b(cursor, "flex_duration");
        int i16 = l.b.b(cursor, "run_attempt_count");
        int i10 = l.b.b(cursor, "backoff_policy");
        int i12 = l.b.b(cursor, "backoff_delay_duration");
        int i19 = l.b.b(cursor, "period_start_time");
        int i13 = l.b.b(cursor, "minimum_retention_duration");
        int i14 = l.b.b(cursor, "schedule_requested_at");
        int i11 = l.b.b(cursor, "run_in_foreground");
        int i17 = l.b.b(cursor, "out_of_quota_policy");
        ArrayList<p> arrayList = new ArrayList(cursor.getCount());
        while (true) {
          if (cursor.moveToNext()) {
            boolean bool;
            String str1 = cursor.getString(m);
            String str2 = cursor.getString(k);
            androidx.work.c c1 = new androidx.work.c();
            c1.k(v.e(cursor.getInt(n)));
            if (cursor.getInt(i2) != 0) {
              bool = true;
            } else {
              bool = false;
            } 
            c1.m(bool);
            if (cursor.getInt(j) != 0) {
              bool = true;
            } else {
              bool = false;
            } 
            c1.n(bool);
            if (cursor.getInt(i) != 0) {
              bool = true;
            } else {
              bool = false;
            } 
            c1.l(bool);
            if (cursor.getInt(i4) != 0) {
              bool = true;
            } else {
              bool = false;
            } 
            c1.o(bool);
            c1.p(cursor.getLong(i5));
            c1.q(cursor.getLong(i6));
            c1.j(v.b(cursor.getBlob(i7)));
            p p = new p(str1, str2);
            p.b = v.g(cursor.getInt(i8));
            p.d = cursor.getString(i1);
            p.e = androidx.work.e.g(cursor.getBlob(i9));
            p.f = androidx.work.e.g(cursor.getBlob(i3));
            p.g = cursor.getLong(i15);
            p.h = cursor.getLong(i18);
            p.i = cursor.getLong(i20);
            p.k = cursor.getInt(i16);
            p.l = v.d(cursor.getInt(i10));
            p.m = cursor.getLong(i12);
            p.n = cursor.getLong(i19);
            p.o = cursor.getLong(i13);
            p.p = cursor.getLong(i14);
            if (cursor.getInt(i11) != 0) {
              bool = true;
            } else {
              bool = false;
            } 
            p.q = bool;
            p.r = v.f(cursor.getInt(i17));
            p.j = c1;
            arrayList.add(p);
            continue;
          } 
          cursor.close();
          c.release();
          return arrayList;
        } 
      } finally {}
    } finally {}
    cursor.close();
    c.release();
    throw exception;
  }
  
  public List<p> g(int paramInt) {
    Exception exception;
    j.c c = j.c.a("SELECT `required_network_type`, `requires_charging`, `requires_device_idle`, `requires_battery_not_low`, `requires_storage_not_low`, `trigger_content_update_delay`, `trigger_max_content_delay`, `content_uri_triggers`, `WorkSpec`.`id` AS `id`, `WorkSpec`.`state` AS `state`, `WorkSpec`.`worker_class_name` AS `worker_class_name`, `WorkSpec`.`input_merger_class_name` AS `input_merger_class_name`, `WorkSpec`.`input` AS `input`, `WorkSpec`.`output` AS `output`, `WorkSpec`.`initial_delay` AS `initial_delay`, `WorkSpec`.`interval_duration` AS `interval_duration`, `WorkSpec`.`flex_duration` AS `flex_duration`, `WorkSpec`.`run_attempt_count` AS `run_attempt_count`, `WorkSpec`.`backoff_policy` AS `backoff_policy`, `WorkSpec`.`backoff_delay_duration` AS `backoff_delay_duration`, `WorkSpec`.`period_start_time` AS `period_start_time`, `WorkSpec`.`minimum_retention_duration` AS `minimum_retention_duration`, `WorkSpec`.`schedule_requested_at` AS `schedule_requested_at`, `WorkSpec`.`run_in_foreground` AS `run_in_foreground`, `WorkSpec`.`out_of_quota_policy` AS `out_of_quota_policy` FROM workspec WHERE state=0 AND schedule_requested_at=-1 ORDER BY period_start_time LIMIT (SELECT MAX(?-COUNT(*), 0) FROM workspec WHERE schedule_requested_at<>-1 AND state NOT IN (2, 3, 5))", 1);
    c.j(1, paramInt);
    this.a.b();
    Cursor cursor = l.c.b(this.a, (m.e)c, false, null);
    try {
      int n = l.b.b(cursor, "required_network_type");
      int i2 = l.b.b(cursor, "requires_charging");
      int j = l.b.b(cursor, "requires_device_idle");
      int i = l.b.b(cursor, "requires_battery_not_low");
      int i4 = l.b.b(cursor, "requires_storage_not_low");
      int i5 = l.b.b(cursor, "trigger_content_update_delay");
      int i6 = l.b.b(cursor, "trigger_max_content_delay");
      int i7 = l.b.b(cursor, "content_uri_triggers");
      int m = l.b.b(cursor, "id");
      int i8 = l.b.b(cursor, "state");
      int k = l.b.b(cursor, "worker_class_name");
      int i1 = l.b.b(cursor, "input_merger_class_name");
      int i9 = l.b.b(cursor, "input");
      int i3 = l.b.b(cursor, "output");
      try {
        int i16 = l.b.b(cursor, "initial_delay");
        int i15 = l.b.b(cursor, "interval_duration");
        int i19 = l.b.b(cursor, "flex_duration");
        int i14 = l.b.b(cursor, "run_attempt_count");
        paramInt = l.b.b(cursor, "backoff_policy");
        int i11 = l.b.b(cursor, "backoff_delay_duration");
        int i18 = l.b.b(cursor, "period_start_time");
        int i12 = l.b.b(cursor, "minimum_retention_duration");
        int i13 = l.b.b(cursor, "schedule_requested_at");
        int i10 = l.b.b(cursor, "run_in_foreground");
        int i17 = l.b.b(cursor, "out_of_quota_policy");
        ArrayList<p> arrayList = new ArrayList(cursor.getCount());
        while (true) {
          if (cursor.moveToNext()) {
            boolean bool;
            String str1 = cursor.getString(m);
            String str2 = cursor.getString(k);
            androidx.work.c c1 = new androidx.work.c();
            c1.k(v.e(cursor.getInt(n)));
            if (cursor.getInt(i2) != 0) {
              bool = true;
            } else {
              bool = false;
            } 
            c1.m(bool);
            if (cursor.getInt(j) != 0) {
              bool = true;
            } else {
              bool = false;
            } 
            c1.n(bool);
            if (cursor.getInt(i) != 0) {
              bool = true;
            } else {
              bool = false;
            } 
            c1.l(bool);
            if (cursor.getInt(i4) != 0) {
              bool = true;
            } else {
              bool = false;
            } 
            c1.o(bool);
            c1.p(cursor.getLong(i5));
            c1.q(cursor.getLong(i6));
            c1.j(v.b(cursor.getBlob(i7)));
            p p = new p(str1, str2);
            p.b = v.g(cursor.getInt(i8));
            p.d = cursor.getString(i1);
            p.e = androidx.work.e.g(cursor.getBlob(i9));
            p.f = androidx.work.e.g(cursor.getBlob(i3));
            p.g = cursor.getLong(i16);
            p.h = cursor.getLong(i15);
            p.i = cursor.getLong(i19);
            p.k = cursor.getInt(i14);
            p.l = v.d(cursor.getInt(paramInt));
            p.m = cursor.getLong(i11);
            p.n = cursor.getLong(i18);
            p.o = cursor.getLong(i12);
            p.p = cursor.getLong(i13);
            if (cursor.getInt(i10) != 0) {
              bool = true;
            } else {
              bool = false;
            } 
            p.q = bool;
            p.r = v.f(cursor.getInt(i17));
            p.j = c1;
            arrayList.add(p);
            continue;
          } 
          cursor.close();
          c.release();
          return arrayList;
        } 
      } finally {}
    } finally {}
    cursor.close();
    c.release();
    throw exception;
  }
  
  public List<p> h() {
    Exception exception;
    j.c c = j.c.a("SELECT `required_network_type`, `requires_charging`, `requires_device_idle`, `requires_battery_not_low`, `requires_storage_not_low`, `trigger_content_update_delay`, `trigger_max_content_delay`, `content_uri_triggers`, `WorkSpec`.`id` AS `id`, `WorkSpec`.`state` AS `state`, `WorkSpec`.`worker_class_name` AS `worker_class_name`, `WorkSpec`.`input_merger_class_name` AS `input_merger_class_name`, `WorkSpec`.`input` AS `input`, `WorkSpec`.`output` AS `output`, `WorkSpec`.`initial_delay` AS `initial_delay`, `WorkSpec`.`interval_duration` AS `interval_duration`, `WorkSpec`.`flex_duration` AS `flex_duration`, `WorkSpec`.`run_attempt_count` AS `run_attempt_count`, `WorkSpec`.`backoff_policy` AS `backoff_policy`, `WorkSpec`.`backoff_delay_duration` AS `backoff_delay_duration`, `WorkSpec`.`period_start_time` AS `period_start_time`, `WorkSpec`.`minimum_retention_duration` AS `minimum_retention_duration`, `WorkSpec`.`schedule_requested_at` AS `schedule_requested_at`, `WorkSpec`.`run_in_foreground` AS `run_in_foreground`, `WorkSpec`.`out_of_quota_policy` AS `out_of_quota_policy` FROM workspec WHERE state=0 AND schedule_requested_at<>-1", 0);
    this.a.b();
    Cursor cursor = l.c.b(this.a, (m.e)c, false, null);
    try {
      int n = l.b.b(cursor, "required_network_type");
      int i2 = l.b.b(cursor, "requires_charging");
      int j = l.b.b(cursor, "requires_device_idle");
      int i = l.b.b(cursor, "requires_battery_not_low");
      int i4 = l.b.b(cursor, "requires_storage_not_low");
      int i5 = l.b.b(cursor, "trigger_content_update_delay");
      int i6 = l.b.b(cursor, "trigger_max_content_delay");
      int i7 = l.b.b(cursor, "content_uri_triggers");
      int m = l.b.b(cursor, "id");
      int i8 = l.b.b(cursor, "state");
      int k = l.b.b(cursor, "worker_class_name");
      int i9 = l.b.b(cursor, "input_merger_class_name");
      int i1 = l.b.b(cursor, "input");
      int i3 = l.b.b(cursor, "output");
      try {
        int i17 = l.b.b(cursor, "initial_delay");
        int i16 = l.b.b(cursor, "interval_duration");
        int i20 = l.b.b(cursor, "flex_duration");
        int i15 = l.b.b(cursor, "run_attempt_count");
        int i10 = l.b.b(cursor, "backoff_policy");
        int i12 = l.b.b(cursor, "backoff_delay_duration");
        int i19 = l.b.b(cursor, "period_start_time");
        int i13 = l.b.b(cursor, "minimum_retention_duration");
        int i14 = l.b.b(cursor, "schedule_requested_at");
        int i11 = l.b.b(cursor, "run_in_foreground");
        int i18 = l.b.b(cursor, "out_of_quota_policy");
        ArrayList<p> arrayList = new ArrayList(cursor.getCount());
        while (true) {
          if (cursor.moveToNext()) {
            boolean bool;
            String str1 = cursor.getString(m);
            String str2 = cursor.getString(k);
            androidx.work.c c1 = new androidx.work.c();
            c1.k(v.e(cursor.getInt(n)));
            if (cursor.getInt(i2) != 0) {
              bool = true;
            } else {
              bool = false;
            } 
            c1.m(bool);
            if (cursor.getInt(j) != 0) {
              bool = true;
            } else {
              bool = false;
            } 
            c1.n(bool);
            if (cursor.getInt(i) != 0) {
              bool = true;
            } else {
              bool = false;
            } 
            c1.l(bool);
            if (cursor.getInt(i4) != 0) {
              bool = true;
            } else {
              bool = false;
            } 
            c1.o(bool);
            c1.p(cursor.getLong(i5));
            c1.q(cursor.getLong(i6));
            c1.j(v.b(cursor.getBlob(i7)));
            p p = new p(str1, str2);
            p.b = v.g(cursor.getInt(i8));
            p.d = cursor.getString(i9);
            p.e = androidx.work.e.g(cursor.getBlob(i1));
            p.f = androidx.work.e.g(cursor.getBlob(i3));
            p.g = cursor.getLong(i17);
            p.h = cursor.getLong(i16);
            p.i = cursor.getLong(i20);
            p.k = cursor.getInt(i15);
            p.l = v.d(cursor.getInt(i10));
            p.m = cursor.getLong(i12);
            p.n = cursor.getLong(i19);
            p.o = cursor.getLong(i13);
            p.p = cursor.getLong(i14);
            if (cursor.getInt(i11) != 0) {
              bool = true;
            } else {
              bool = false;
            } 
            p.q = bool;
            p.r = v.f(cursor.getInt(i18));
            p.j = c1;
            arrayList.add(p);
            continue;
          } 
          cursor.close();
          c.release();
          return arrayList;
        } 
      } finally {}
    } finally {}
    cursor.close();
    c.release();
    throw exception;
  }
  
  public void i(String paramString, androidx.work.e parame) {
    this.a.b();
    m.f f = this.d.a();
    byte[] arrayOfByte = androidx.work.e.k(parame);
    if (arrayOfByte == null) {
      f.r(1);
    } else {
      f.k(1, arrayOfByte);
    } 
    if (paramString == null) {
      f.r(2);
    } else {
      f.b(2, paramString);
    } 
    this.a.c();
    try {
      f.J();
      this.a.r();
      return;
    } finally {
      this.a.g();
      this.d.f(f);
    } 
  }
  
  public List<p> j() {
    Exception exception;
    j.c c = j.c.a("SELECT `required_network_type`, `requires_charging`, `requires_device_idle`, `requires_battery_not_low`, `requires_storage_not_low`, `trigger_content_update_delay`, `trigger_max_content_delay`, `content_uri_triggers`, `WorkSpec`.`id` AS `id`, `WorkSpec`.`state` AS `state`, `WorkSpec`.`worker_class_name` AS `worker_class_name`, `WorkSpec`.`input_merger_class_name` AS `input_merger_class_name`, `WorkSpec`.`input` AS `input`, `WorkSpec`.`output` AS `output`, `WorkSpec`.`initial_delay` AS `initial_delay`, `WorkSpec`.`interval_duration` AS `interval_duration`, `WorkSpec`.`flex_duration` AS `flex_duration`, `WorkSpec`.`run_attempt_count` AS `run_attempt_count`, `WorkSpec`.`backoff_policy` AS `backoff_policy`, `WorkSpec`.`backoff_delay_duration` AS `backoff_delay_duration`, `WorkSpec`.`period_start_time` AS `period_start_time`, `WorkSpec`.`minimum_retention_duration` AS `minimum_retention_duration`, `WorkSpec`.`schedule_requested_at` AS `schedule_requested_at`, `WorkSpec`.`run_in_foreground` AS `run_in_foreground`, `WorkSpec`.`out_of_quota_policy` AS `out_of_quota_policy` FROM workspec WHERE state=1", 0);
    this.a.b();
    Cursor cursor = l.c.b(this.a, (m.e)c, false, null);
    try {
      int n = l.b.b(cursor, "required_network_type");
      int i2 = l.b.b(cursor, "requires_charging");
      int j = l.b.b(cursor, "requires_device_idle");
      int i = l.b.b(cursor, "requires_battery_not_low");
      int i4 = l.b.b(cursor, "requires_storage_not_low");
      int i5 = l.b.b(cursor, "trigger_content_update_delay");
      int i6 = l.b.b(cursor, "trigger_max_content_delay");
      int i7 = l.b.b(cursor, "content_uri_triggers");
      int m = l.b.b(cursor, "id");
      int i8 = l.b.b(cursor, "state");
      int k = l.b.b(cursor, "worker_class_name");
      int i9 = l.b.b(cursor, "input_merger_class_name");
      int i1 = l.b.b(cursor, "input");
      int i3 = l.b.b(cursor, "output");
      try {
        int i17 = l.b.b(cursor, "initial_delay");
        int i16 = l.b.b(cursor, "interval_duration");
        int i20 = l.b.b(cursor, "flex_duration");
        int i15 = l.b.b(cursor, "run_attempt_count");
        int i10 = l.b.b(cursor, "backoff_policy");
        int i12 = l.b.b(cursor, "backoff_delay_duration");
        int i19 = l.b.b(cursor, "period_start_time");
        int i13 = l.b.b(cursor, "minimum_retention_duration");
        int i14 = l.b.b(cursor, "schedule_requested_at");
        int i11 = l.b.b(cursor, "run_in_foreground");
        int i18 = l.b.b(cursor, "out_of_quota_policy");
        ArrayList<p> arrayList = new ArrayList(cursor.getCount());
        while (true) {
          if (cursor.moveToNext()) {
            boolean bool;
            String str1 = cursor.getString(m);
            String str2 = cursor.getString(k);
            androidx.work.c c1 = new androidx.work.c();
            c1.k(v.e(cursor.getInt(n)));
            if (cursor.getInt(i2) != 0) {
              bool = true;
            } else {
              bool = false;
            } 
            c1.m(bool);
            if (cursor.getInt(j) != 0) {
              bool = true;
            } else {
              bool = false;
            } 
            c1.n(bool);
            if (cursor.getInt(i) != 0) {
              bool = true;
            } else {
              bool = false;
            } 
            c1.l(bool);
            if (cursor.getInt(i4) != 0) {
              bool = true;
            } else {
              bool = false;
            } 
            c1.o(bool);
            c1.p(cursor.getLong(i5));
            c1.q(cursor.getLong(i6));
            c1.j(v.b(cursor.getBlob(i7)));
            p p = new p(str1, str2);
            p.b = v.g(cursor.getInt(i8));
            p.d = cursor.getString(i9);
            p.e = androidx.work.e.g(cursor.getBlob(i1));
            p.f = androidx.work.e.g(cursor.getBlob(i3));
            p.g = cursor.getLong(i17);
            p.h = cursor.getLong(i16);
            p.i = cursor.getLong(i20);
            p.k = cursor.getInt(i15);
            p.l = v.d(cursor.getInt(i10));
            p.m = cursor.getLong(i12);
            p.n = cursor.getLong(i19);
            p.o = cursor.getLong(i13);
            p.p = cursor.getLong(i14);
            if (cursor.getInt(i11) != 0) {
              bool = true;
            } else {
              bool = false;
            } 
            p.q = bool;
            p.r = v.f(cursor.getInt(i18));
            p.j = c1;
            arrayList.add(p);
            continue;
          } 
          cursor.close();
          c.release();
          return arrayList;
        } 
      } finally {}
    } finally {}
    cursor.close();
    c.release();
    throw exception;
  }
  
  public boolean k() {
    boolean bool2 = false;
    j.c c = j.c.a("SELECT COUNT(*) > 0 FROM workspec WHERE state NOT IN (2, 3, 5) LIMIT 1", 0);
    this.a.b();
    Cursor cursor = l.c.b(this.a, (m.e)c, false, null);
    boolean bool1 = bool2;
    try {
      if (cursor.moveToFirst()) {
        int i = cursor.getInt(0);
        bool1 = bool2;
        if (i != 0)
          bool1 = true; 
      } 
      return bool1;
    } finally {
      cursor.close();
      c.release();
    } 
  }
  
  public List<String> l(String paramString) {
    j.c c = j.c.a("SELECT id FROM workspec WHERE state NOT IN (2, 3, 5) AND id IN (SELECT work_spec_id FROM workname WHERE name=?)", 1);
    if (paramString == null) {
      c.r(1);
    } else {
      c.b(1, paramString);
    } 
    this.a.b();
    Cursor cursor = l.c.b(this.a, (m.e)c, false, null);
    try {
      ArrayList<String> arrayList = new ArrayList(cursor.getCount());
      while (cursor.moveToNext())
        arrayList.add(cursor.getString(0)); 
      return arrayList;
    } finally {
      cursor.close();
      c.release();
    } 
  }
  
  public u m(String paramString) {
    j.c c = j.c.a("SELECT state FROM workspec WHERE id=?", 1);
    if (paramString == null) {
      c.r(1);
    } else {
      c.b(1, paramString);
    } 
    this.a.b();
    androidx.room.h h1 = this.a;
    paramString = null;
    Cursor cursor = l.c.b(h1, (m.e)c, false, null);
    try {
      u u;
      if (cursor.moveToFirst())
        u = v.g(cursor.getInt(0)); 
      return u;
    } finally {
      cursor.close();
      c.release();
    } 
  }
  
  public p n(String paramString) {
    j.c c = j.c.a("SELECT `required_network_type`, `requires_charging`, `requires_device_idle`, `requires_battery_not_low`, `requires_storage_not_low`, `trigger_content_update_delay`, `trigger_max_content_delay`, `content_uri_triggers`, `WorkSpec`.`id` AS `id`, `WorkSpec`.`state` AS `state`, `WorkSpec`.`worker_class_name` AS `worker_class_name`, `WorkSpec`.`input_merger_class_name` AS `input_merger_class_name`, `WorkSpec`.`input` AS `input`, `WorkSpec`.`output` AS `output`, `WorkSpec`.`initial_delay` AS `initial_delay`, `WorkSpec`.`interval_duration` AS `interval_duration`, `WorkSpec`.`flex_duration` AS `flex_duration`, `WorkSpec`.`run_attempt_count` AS `run_attempt_count`, `WorkSpec`.`backoff_policy` AS `backoff_policy`, `WorkSpec`.`backoff_delay_duration` AS `backoff_delay_duration`, `WorkSpec`.`period_start_time` AS `period_start_time`, `WorkSpec`.`minimum_retention_duration` AS `minimum_retention_duration`, `WorkSpec`.`schedule_requested_at` AS `schedule_requested_at`, `WorkSpec`.`run_in_foreground` AS `run_in_foreground`, `WorkSpec`.`out_of_quota_policy` AS `out_of_quota_policy` FROM workspec WHERE id=?", 1);
    if (paramString == null) {
      c.r(1);
    } else {
      c.b(1, paramString);
    } 
    this.a.b();
    Cursor cursor = l.c.b(this.a, (m.e)c, false, null);
    try {
      int i = l.b.b(cursor, "required_network_type");
      int j = l.b.b(cursor, "requires_charging");
      int k = l.b.b(cursor, "requires_device_idle");
      int m = l.b.b(cursor, "requires_battery_not_low");
      int n = l.b.b(cursor, "requires_storage_not_low");
      int i1 = l.b.b(cursor, "trigger_content_update_delay");
      int i2 = l.b.b(cursor, "trigger_max_content_delay");
      int i3 = l.b.b(cursor, "content_uri_triggers");
      int i4 = l.b.b(cursor, "id");
      int i5 = l.b.b(cursor, "state");
      int i6 = l.b.b(cursor, "worker_class_name");
      int i7 = l.b.b(cursor, "input_merger_class_name");
      int i8 = l.b.b(cursor, "input");
      int i9 = l.b.b(cursor, "output");
      try {
        int i10 = l.b.b(cursor, "initial_delay");
        int i11 = l.b.b(cursor, "interval_duration");
        int i12 = l.b.b(cursor, "flex_duration");
        int i13 = l.b.b(cursor, "run_attempt_count");
        int i14 = l.b.b(cursor, "backoff_policy");
        int i15 = l.b.b(cursor, "backoff_delay_duration");
        int i16 = l.b.b(cursor, "period_start_time");
        int i17 = l.b.b(cursor, "minimum_retention_duration");
        int i18 = l.b.b(cursor, "schedule_requested_at");
        int i19 = l.b.b(cursor, "run_in_foreground");
        int i20 = l.b.b(cursor, "out_of_quota_policy");
        if (cursor.moveToFirst()) {
          boolean bool;
          paramString = cursor.getString(i4);
          String str = cursor.getString(i6);
          androidx.work.c c1 = new androidx.work.c();
          c1.k(v.e(cursor.getInt(i)));
          if (cursor.getInt(j) != 0) {
            bool = true;
          } else {
            bool = false;
          } 
          c1.m(bool);
          if (cursor.getInt(k) != 0) {
            bool = true;
          } else {
            bool = false;
          } 
          c1.n(bool);
          if (cursor.getInt(m) != 0) {
            bool = true;
          } else {
            bool = false;
          } 
          c1.l(bool);
          if (cursor.getInt(n) != 0) {
            bool = true;
          } else {
            bool = false;
          } 
          c1.o(bool);
          c1.p(cursor.getLong(i1));
          c1.q(cursor.getLong(i2));
          c1.j(v.b(cursor.getBlob(i3)));
          p p = new p(paramString, str);
          p.b = v.g(cursor.getInt(i5));
          p.d = cursor.getString(i7);
          p.e = androidx.work.e.g(cursor.getBlob(i8));
          p.f = androidx.work.e.g(cursor.getBlob(i9));
          p.g = cursor.getLong(i10);
          p.h = cursor.getLong(i11);
          p.i = cursor.getLong(i12);
          p.k = cursor.getInt(i13);
          p.l = v.d(cursor.getInt(i14));
          p.m = cursor.getLong(i15);
          p.n = cursor.getLong(i16);
          p.o = cursor.getLong(i17);
          p.p = cursor.getLong(i18);
          if (cursor.getInt(i19) != 0) {
            bool = true;
          } else {
            bool = false;
          } 
          p.q = bool;
          p.r = v.f(cursor.getInt(i20));
          p.j = c1;
        } else {
          paramString = null;
        } 
        cursor.close();
        c.release();
        return (p)paramString;
      } finally {}
    } finally {}
    cursor.close();
    c.release();
    throw paramString;
  }
  
  public int o(String paramString) {
    this.a.b();
    m.f f = this.g.a();
    if (paramString == null) {
      f.r(1);
    } else {
      f.b(1, paramString);
    } 
    this.a.c();
    try {
      int i = f.J();
      this.a.r();
      return i;
    } finally {
      this.a.g();
      this.g.f(f);
    } 
  }
  
  public List<String> p(String paramString) {
    j.c c = j.c.a("SELECT id FROM workspec WHERE state NOT IN (2, 3, 5) AND id IN (SELECT work_spec_id FROM worktag WHERE tag=?)", 1);
    if (paramString == null) {
      c.r(1);
    } else {
      c.b(1, paramString);
    } 
    this.a.b();
    Cursor cursor = l.c.b(this.a, (m.e)c, false, null);
    try {
      ArrayList<String> arrayList = new ArrayList(cursor.getCount());
      while (cursor.moveToNext())
        arrayList.add(cursor.getString(0)); 
      return arrayList;
    } finally {
      cursor.close();
      c.release();
    } 
  }
  
  public List<androidx.work.e> q(String paramString) {
    j.c c = j.c.a("SELECT output FROM workspec WHERE id IN (SELECT prerequisite_id FROM dependency WHERE work_spec_id=?)", 1);
    if (paramString == null) {
      c.r(1);
    } else {
      c.b(1, paramString);
    } 
    this.a.b();
    Cursor cursor = l.c.b(this.a, (m.e)c, false, null);
    try {
      ArrayList<androidx.work.e> arrayList = new ArrayList(cursor.getCount());
      while (cursor.moveToNext())
        arrayList.add(androidx.work.e.g(cursor.getBlob(0))); 
      return arrayList;
    } finally {
      cursor.close();
      c.release();
    } 
  }
  
  public int r(String paramString) {
    this.a.b();
    m.f f = this.f.a();
    if (paramString == null) {
      f.r(1);
    } else {
      f.b(1, paramString);
    } 
    this.a.c();
    try {
      int i = f.J();
      this.a.r();
      return i;
    } finally {
      this.a.g();
      this.f.f(f);
    } 
  }
  
  public void s(String paramString, long paramLong) {
    this.a.b();
    m.f f = this.e.a();
    f.j(1, paramLong);
    if (paramString == null) {
      f.r(2);
    } else {
      f.b(2, paramString);
    } 
    this.a.c();
    try {
      f.J();
      this.a.r();
      return;
    } finally {
      this.a.g();
      this.e.f(f);
    } 
  }
  
  public List<p> t(int paramInt) {
    Exception exception;
    j.c c = j.c.a("SELECT `required_network_type`, `requires_charging`, `requires_device_idle`, `requires_battery_not_low`, `requires_storage_not_low`, `trigger_content_update_delay`, `trigger_max_content_delay`, `content_uri_triggers`, `WorkSpec`.`id` AS `id`, `WorkSpec`.`state` AS `state`, `WorkSpec`.`worker_class_name` AS `worker_class_name`, `WorkSpec`.`input_merger_class_name` AS `input_merger_class_name`, `WorkSpec`.`input` AS `input`, `WorkSpec`.`output` AS `output`, `WorkSpec`.`initial_delay` AS `initial_delay`, `WorkSpec`.`interval_duration` AS `interval_duration`, `WorkSpec`.`flex_duration` AS `flex_duration`, `WorkSpec`.`run_attempt_count` AS `run_attempt_count`, `WorkSpec`.`backoff_policy` AS `backoff_policy`, `WorkSpec`.`backoff_delay_duration` AS `backoff_delay_duration`, `WorkSpec`.`period_start_time` AS `period_start_time`, `WorkSpec`.`minimum_retention_duration` AS `minimum_retention_duration`, `WorkSpec`.`schedule_requested_at` AS `schedule_requested_at`, `WorkSpec`.`run_in_foreground` AS `run_in_foreground`, `WorkSpec`.`out_of_quota_policy` AS `out_of_quota_policy` FROM workspec WHERE state=0 ORDER BY period_start_time LIMIT ?", 1);
    c.j(1, paramInt);
    this.a.b();
    Cursor cursor = l.c.b(this.a, (m.e)c, false, null);
    try {
      int n = l.b.b(cursor, "required_network_type");
      int i2 = l.b.b(cursor, "requires_charging");
      int j = l.b.b(cursor, "requires_device_idle");
      int i = l.b.b(cursor, "requires_battery_not_low");
      int i4 = l.b.b(cursor, "requires_storage_not_low");
      int i5 = l.b.b(cursor, "trigger_content_update_delay");
      int i6 = l.b.b(cursor, "trigger_max_content_delay");
      int i7 = l.b.b(cursor, "content_uri_triggers");
      int m = l.b.b(cursor, "id");
      int i8 = l.b.b(cursor, "state");
      int k = l.b.b(cursor, "worker_class_name");
      int i1 = l.b.b(cursor, "input_merger_class_name");
      int i9 = l.b.b(cursor, "input");
      int i3 = l.b.b(cursor, "output");
      try {
        int i16 = l.b.b(cursor, "initial_delay");
        int i15 = l.b.b(cursor, "interval_duration");
        int i19 = l.b.b(cursor, "flex_duration");
        int i14 = l.b.b(cursor, "run_attempt_count");
        paramInt = l.b.b(cursor, "backoff_policy");
        int i11 = l.b.b(cursor, "backoff_delay_duration");
        int i18 = l.b.b(cursor, "period_start_time");
        int i12 = l.b.b(cursor, "minimum_retention_duration");
        int i13 = l.b.b(cursor, "schedule_requested_at");
        int i10 = l.b.b(cursor, "run_in_foreground");
        int i17 = l.b.b(cursor, "out_of_quota_policy");
        ArrayList<p> arrayList = new ArrayList(cursor.getCount());
        while (true) {
          if (cursor.moveToNext()) {
            boolean bool;
            String str1 = cursor.getString(m);
            String str2 = cursor.getString(k);
            androidx.work.c c1 = new androidx.work.c();
            c1.k(v.e(cursor.getInt(n)));
            if (cursor.getInt(i2) != 0) {
              bool = true;
            } else {
              bool = false;
            } 
            c1.m(bool);
            if (cursor.getInt(j) != 0) {
              bool = true;
            } else {
              bool = false;
            } 
            c1.n(bool);
            if (cursor.getInt(i) != 0) {
              bool = true;
            } else {
              bool = false;
            } 
            c1.l(bool);
            if (cursor.getInt(i4) != 0) {
              bool = true;
            } else {
              bool = false;
            } 
            c1.o(bool);
            c1.p(cursor.getLong(i5));
            c1.q(cursor.getLong(i6));
            c1.j(v.b(cursor.getBlob(i7)));
            p p = new p(str1, str2);
            p.b = v.g(cursor.getInt(i8));
            p.d = cursor.getString(i1);
            p.e = androidx.work.e.g(cursor.getBlob(i9));
            p.f = androidx.work.e.g(cursor.getBlob(i3));
            p.g = cursor.getLong(i16);
            p.h = cursor.getLong(i15);
            p.i = cursor.getLong(i19);
            p.k = cursor.getInt(i14);
            p.l = v.d(cursor.getInt(paramInt));
            p.m = cursor.getLong(i11);
            p.n = cursor.getLong(i18);
            p.o = cursor.getLong(i12);
            p.p = cursor.getLong(i13);
            if (cursor.getInt(i10) != 0) {
              bool = true;
            } else {
              bool = false;
            } 
            p.q = bool;
            p.r = v.f(cursor.getInt(i17));
            p.j = c1;
            arrayList.add(p);
            continue;
          } 
          cursor.close();
          c.release();
          return arrayList;
        } 
      } finally {}
    } finally {}
    cursor.close();
    c.release();
    throw exception;
  }
  
  public int u() {
    this.a.b();
    m.f f = this.i.a();
    this.a.c();
    try {
      int i = f.J();
      this.a.r();
      return i;
    } finally {
      this.a.g();
      this.i.f(f);
    } 
  }
  
  class a extends j.a<p> {
    a(r this$0, androidx.room.h param1h) {
      super(param1h);
    }
    
    public String d() {
      return "INSERT OR IGNORE INTO `WorkSpec` (`id`,`state`,`worker_class_name`,`input_merger_class_name`,`input`,`output`,`initial_delay`,`interval_duration`,`flex_duration`,`run_attempt_count`,`backoff_policy`,`backoff_delay_duration`,`period_start_time`,`minimum_retention_duration`,`schedule_requested_at`,`run_in_foreground`,`out_of_quota_policy`,`required_network_type`,`requires_charging`,`requires_device_idle`,`requires_battery_not_low`,`requires_storage_not_low`,`trigger_content_update_delay`,`trigger_max_content_delay`,`content_uri_triggers`) VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)";
    }
    
    public void i(m.f param1f, p param1p) {
      throw new RuntimeException("d2j fail translate: java.lang.RuntimeException: can not merge I and Z\r\n\tat com.googlecode.dex2jar.ir.TypeClass.merge(TypeClass.java:100)\r\n\tat com.googlecode.dex2jar.ir.ts.TypeTransformer$TypeRef.updateTypeClass(TypeTransformer.java:174)\r\n\tat com.googlecode.dex2jar.ir.ts.TypeTransformer$TypeAnalyze.provideAs(TypeTransformer.java:780)\r\n\tat com.googlecode.dex2jar.ir.ts.TypeTransformer$TypeAnalyze.e1expr(TypeTransformer.java:496)\r\n\tat com.googlecode.dex2jar.ir.ts.TypeTransformer$TypeAnalyze.exExpr(TypeTransformer.java:713)\r\n\tat com.googlecode.dex2jar.ir.ts.TypeTransformer$TypeAnalyze.exExpr(TypeTransformer.java:703)\r\n\tat com.googlecode.dex2jar.ir.ts.TypeTransformer$TypeAnalyze.e1expr(TypeTransformer.java:539)\r\n\tat com.googlecode.dex2jar.ir.ts.TypeTransformer$TypeAnalyze.exExpr(TypeTransformer.java:713)\r\n\tat com.googlecode.dex2jar.ir.ts.TypeTransformer$TypeAnalyze.exExpr(TypeTransformer.java:703)\r\n\tat com.googlecode.dex2jar.ir.ts.TypeTransformer$TypeAnalyze.enexpr(TypeTransformer.java:698)\r\n\tat com.googlecode.dex2jar.ir.ts.TypeTransformer$TypeAnalyze.exExpr(TypeTransformer.java:719)\r\n\tat com.googlecode.dex2jar.ir.ts.TypeTransformer$TypeAnalyze.exExpr(TypeTransformer.java:703)\r\n\tat com.googlecode.dex2jar.ir.ts.TypeTransformer$TypeAnalyze.s1stmt(TypeTransformer.java:810)\r\n\tat com.googlecode.dex2jar.ir.ts.TypeTransformer$TypeAnalyze.sxStmt(TypeTransformer.java:840)\r\n\tat com.googlecode.dex2jar.ir.ts.TypeTransformer$TypeAnalyze.analyze(TypeTransformer.java:206)\r\n\tat com.googlecode.dex2jar.ir.ts.TypeTransformer.transform(TypeTransformer.java:44)\r\n\tat com.googlecode.d2j.dex.Dex2jar$2.optimize(Dex2jar.java:162)\r\n\tat com.googlecode.d2j.dex.Dex2Asm.convertCode(Dex2Asm.java:414)\r\n\tat com.googlecode.d2j.dex.ExDex2Asm.convertCode(ExDex2Asm.java:42)\r\n\tat com.googlecode.d2j.dex.Dex2jar$2.convertCode(Dex2jar.java:128)\r\n\tat com.googlecode.d2j.dex.Dex2Asm.convertMethod(Dex2Asm.java:509)\r\n\tat com.googlecode.d2j.dex.Dex2Asm.convertClass(Dex2Asm.java:406)\r\n\tat com.googlecode.d2j.dex.Dex2Asm.convertDex(Dex2Asm.java:422)\r\n\tat com.googlecode.d2j.dex.Dex2jar.doTranslate(Dex2jar.java:172)\r\n\tat com.googlecode.d2j.dex.Dex2jar.to(Dex2jar.java:272)\r\n\tat com.googlecode.dex2jar.tools.Dex2jarCmd.doCommandLine(Dex2jarCmd.java:108)\r\n\tat com.googlecode.dex2jar.tools.BaseCmd.doMain(BaseCmd.java:288)\r\n\tat com.googlecode.dex2jar.tools.Dex2jarCmd.main(Dex2jarCmd.java:32)\r\n");
    }
  }
  
  class b extends j.d {
    b(r this$0, androidx.room.h param1h) {
      super(param1h);
    }
    
    public String d() {
      return "DELETE FROM workspec WHERE id=?";
    }
  }
  
  class c extends j.d {
    c(r this$0, androidx.room.h param1h) {
      super(param1h);
    }
    
    public String d() {
      return "UPDATE workspec SET output=? WHERE id=?";
    }
  }
  
  class d extends j.d {
    d(r this$0, androidx.room.h param1h) {
      super(param1h);
    }
    
    public String d() {
      return "UPDATE workspec SET period_start_time=? WHERE id=?";
    }
  }
  
  class e extends j.d {
    e(r this$0, androidx.room.h param1h) {
      super(param1h);
    }
    
    public String d() {
      return "UPDATE workspec SET run_attempt_count=run_attempt_count+1 WHERE id=?";
    }
  }
  
  class f extends j.d {
    f(r this$0, androidx.room.h param1h) {
      super(param1h);
    }
    
    public String d() {
      return "UPDATE workspec SET run_attempt_count=0 WHERE id=?";
    }
  }
  
  class g extends j.d {
    g(r this$0, androidx.room.h param1h) {
      super(param1h);
    }
    
    public String d() {
      return "UPDATE workspec SET schedule_requested_at=? WHERE id=?";
    }
  }
  
  class h extends j.d {
    h(r this$0, androidx.room.h param1h) {
      super(param1h);
    }
    
    public String d() {
      return "UPDATE workspec SET schedule_requested_at=-1 WHERE state NOT IN (2, 3, 5)";
    }
  }
  
  class i extends j.d {
    i(r this$0, androidx.room.h param1h) {
      super(param1h);
    }
    
    public String d() {
      return "DELETE FROM workspec WHERE state IN (2, 3, 5) AND (SELECT COUNT(*)=0 FROM dependency WHERE     prerequisite_id=id AND     work_spec_id NOT IN         (SELECT id FROM workspec WHERE state IN (2, 3, 5)))";
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Hill race-dex2jar.jar!\a0\r.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */