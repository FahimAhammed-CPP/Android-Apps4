package a0;

import android.database.Cursor;
import androidx.room.h;
import j.c;
import j.d;
import java.util.ArrayList;
import java.util.List;
import l.c;
import m.e;
import m.f;

public final class i implements h {
  private final h a;
  
  private final j.a<g> b;
  
  private final d c;
  
  public i(h paramh) {
    this.a = paramh;
    this.b = new a(this, paramh);
    this.c = new b(this, paramh);
  }
  
  public List<String> a() {
    c c = c.a("SELECT DISTINCT work_spec_id FROM SystemIdInfo", 0);
    this.a.b();
    Cursor cursor = c.b(this.a, (e)c, false, null);
    try {
      ArrayList<String> arrayList = new ArrayList(cursor.getCount());
      while (cursor.moveToNext())
        arrayList.add(cursor.getString(0)); 
      return arrayList;
    } finally {
      cursor.close();
      c.release();
    } 
  }
  
  public void b(g paramg) {
    this.a.b();
    this.a.c();
    try {
      this.b.h(paramg);
      this.a.r();
      return;
    } finally {
      this.a.g();
    } 
  }
  
  public g c(String paramString) {
    c c = c.a("SELECT `SystemIdInfo`.`work_spec_id` AS `work_spec_id`, `SystemIdInfo`.`system_id` AS `system_id` FROM SystemIdInfo WHERE work_spec_id=?", 1);
    if (paramString == null) {
      c.r(1);
    } else {
      c.b(1, paramString);
    } 
    this.a.b();
    h h1 = this.a;
    paramString = null;
    Cursor cursor = c.b(h1, (e)c, false, null);
    try {
      g g;
      int j = l.b.b(cursor, "work_spec_id");
      int k = l.b.b(cursor, "system_id");
      if (cursor.moveToFirst())
        g = new g(cursor.getString(j), cursor.getInt(k)); 
      return g;
    } finally {
      cursor.close();
      c.release();
    } 
  }
  
  public void d(String paramString) {
    this.a.b();
    f f = this.c.a();
    if (paramString == null) {
      f.r(1);
    } else {
      f.b(1, paramString);
    } 
    this.a.c();
    try {
      f.J();
      this.a.r();
      return;
    } finally {
      this.a.g();
      this.c.f(f);
    } 
  }
  
  class a extends j.a<g> {
    a(i this$0, h param1h) {
      super(param1h);
    }
    
    public String d() {
      return "INSERT OR REPLACE INTO `SystemIdInfo` (`work_spec_id`,`system_id`) VALUES (?,?)";
    }
    
    public void i(f param1f, g param1g) {
      String str = param1g.a;
      if (str == null) {
        param1f.r(1);
      } else {
        param1f.b(1, str);
      } 
      param1f.j(2, param1g.b);
    }
  }
  
  class b extends d {
    b(i this$0, h param1h) {
      super(param1h);
    }
    
    public String d() {
      return "DELETE FROM SystemIdInfo where work_spec_id=?";
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Hill race-dex2jar.jar!\a0\i.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */