package a0;

public class g {
  public final String a;
  
  public final int b;
  
  public g(String paramString, int paramInt) {
    this.a = paramString;
    this.b = paramInt;
  }
  
  public boolean equals(Object paramObject) {
    if (this == paramObject)
      return true; 
    if (!(paramObject instanceof g))
      return false; 
    paramObject = paramObject;
    return (this.b != ((g)paramObject).b) ? false : this.a.equals(((g)paramObject).a);
  }
  
  public int hashCode() {
    return this.a.hashCode() * 31 + this.b;
  }
}


/* Location:              C:\soft\dex2jar-2.0\Hill race-dex2jar.jar!\a0\g.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */