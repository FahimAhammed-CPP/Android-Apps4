package a0;

import androidx.work.c;
import androidx.work.e;
import androidx.work.l;
import androidx.work.u;
import java.util.List;

public final class p {
  private static final String s = l.f("WorkSpec");
  
  public static final d.a<List<Object>, List<Object>> t = new a();
  
  public String a;
  
  public u b = u.b;
  
  public String c;
  
  public String d;
  
  public e e;
  
  public e f;
  
  public long g;
  
  public long h;
  
  public long i;
  
  public c j;
  
  public int k;
  
  public androidx.work.a l;
  
  public long m;
  
  public long n;
  
  public long o;
  
  public long p;
  
  public boolean q;
  
  public androidx.work.p r;
  
  public p(p paramp) {
    e e1 = e.c;
    this.e = e1;
    this.f = e1;
    this.j = c.i;
    this.l = androidx.work.a.b;
    this.m = 30000L;
    this.p = -1L;
    this.r = androidx.work.p.b;
    this.a = paramp.a;
    this.c = paramp.c;
    this.b = paramp.b;
    this.d = paramp.d;
    this.e = new e(paramp.e);
    this.f = new e(paramp.f);
    this.g = paramp.g;
    this.h = paramp.h;
    this.i = paramp.i;
    this.j = new c(paramp.j);
    this.k = paramp.k;
    this.l = paramp.l;
    this.m = paramp.m;
    this.n = paramp.n;
    this.o = paramp.o;
    this.p = paramp.p;
    this.q = paramp.q;
    this.r = paramp.r;
  }
  
  public p(String paramString1, String paramString2) {
    e e1 = e.c;
    this.e = e1;
    this.f = e1;
    this.j = c.i;
    this.l = androidx.work.a.b;
    this.m = 30000L;
    this.p = -1L;
    this.r = androidx.work.p.b;
    this.a = paramString1;
    this.c = paramString2;
  }
  
  public long a() {
    boolean bool = c();
    boolean bool2 = false;
    boolean bool1 = false;
    if (bool) {
      long l;
      if (this.l == androidx.work.a.c)
        bool1 = true; 
      if (bool1) {
        l = this.m * this.k;
      } else {
        l = (long)Math.scalb((float)this.m, this.k - 1);
      } 
      return this.n + Math.min(18000000L, l);
    } 
    bool = d();
    long l2 = 0L;
    if (bool) {
      long l3 = System.currentTimeMillis();
      long l4 = this.n;
      if (l4 == 0L) {
        l3 += this.g;
      } else {
        l3 = l4;
      } 
      long l6 = this.i;
      long l5 = this.h;
      bool1 = bool2;
      if (l6 != l5)
        bool1 = true; 
      if (bool1) {
        if (l4 == 0L)
          l2 = l6 * -1L; 
        return l3 + l5 + l2;
      } 
      if (l4 != 0L)
        l2 = l5; 
      return l3 + l2;
    } 
    l2 = this.n;
    long l1 = l2;
    if (l2 == 0L)
      l1 = System.currentTimeMillis(); 
    return l1 + this.g;
  }
  
  public boolean b() {
    return c.i.equals(this.j) ^ true;
  }
  
  public boolean c() {
    return (this.b == u.b && this.k > 0);
  }
  
  public boolean d() {
    return (this.h != 0L);
  }
  
  public boolean equals(Object paramObject) {
    if (this == paramObject)
      return true; 
    if (paramObject != null) {
      if (p.class != paramObject.getClass())
        return false; 
      paramObject = paramObject;
      if (this.g != ((p)paramObject).g)
        return false; 
      if (this.h != ((p)paramObject).h)
        return false; 
      if (this.i != ((p)paramObject).i)
        return false; 
      if (this.k != ((p)paramObject).k)
        return false; 
      if (this.m != ((p)paramObject).m)
        return false; 
      if (this.n != ((p)paramObject).n)
        return false; 
      if (this.o != ((p)paramObject).o)
        return false; 
      if (this.p != ((p)paramObject).p)
        return false; 
      if (this.q != ((p)paramObject).q)
        return false; 
      if (!this.a.equals(((p)paramObject).a))
        return false; 
      if (this.b != ((p)paramObject).b)
        return false; 
      if (!this.c.equals(((p)paramObject).c))
        return false; 
      String str = this.d;
      if (str != null) {
        if (!str.equals(((p)paramObject).d))
          return false; 
      } else if (((p)paramObject).d != null) {
        return false;
      } 
      return !this.e.equals(((p)paramObject).e) ? false : (!this.f.equals(((p)paramObject).f) ? false : (!this.j.equals(((p)paramObject).j) ? false : ((this.l != ((p)paramObject).l) ? false : ((this.r == ((p)paramObject).r)))));
    } 
    return false;
  }
  
  public int hashCode() {
    throw new RuntimeException("d2j fail translate: java.lang.RuntimeException: can not merge I and Z\r\n\tat com.googlecode.dex2jar.ir.TypeClass.merge(TypeClass.java:100)\r\n\tat com.googlecode.dex2jar.ir.ts.TypeTransformer$TypeRef.updateTypeClass(TypeTransformer.java:174)\r\n\tat com.googlecode.dex2jar.ir.ts.TypeTransformer$TypeAnalyze.provideAs(TypeTransformer.java:780)\r\n\tat com.googlecode.dex2jar.ir.ts.TypeTransformer$TypeAnalyze.e1expr(TypeTransformer.java:496)\r\n\tat com.googlecode.dex2jar.ir.ts.TypeTransformer$TypeAnalyze.exExpr(TypeTransformer.java:713)\r\n\tat com.googlecode.dex2jar.ir.ts.TypeTransformer$TypeAnalyze.exExpr(TypeTransformer.java:703)\r\n\tat com.googlecode.dex2jar.ir.ts.TypeTransformer$TypeAnalyze.e2expr(TypeTransformer.java:632)\r\n\tat com.googlecode.dex2jar.ir.ts.TypeTransformer$TypeAnalyze.exExpr(TypeTransformer.java:716)\r\n\tat com.googlecode.dex2jar.ir.ts.TypeTransformer$TypeAnalyze.exExpr(TypeTransformer.java:703)\r\n\tat com.googlecode.dex2jar.ir.ts.TypeTransformer$TypeAnalyze.e2expr(TypeTransformer.java:629)\r\n\tat com.googlecode.dex2jar.ir.ts.TypeTransformer$TypeAnalyze.exExpr(TypeTransformer.java:716)\r\n\tat com.googlecode.dex2jar.ir.ts.TypeTransformer$TypeAnalyze.exExpr(TypeTransformer.java:703)\r\n\tat com.googlecode.dex2jar.ir.ts.TypeTransformer$TypeAnalyze.e2expr(TypeTransformer.java:629)\r\n\tat com.googlecode.dex2jar.ir.ts.TypeTransformer$TypeAnalyze.exExpr(TypeTransformer.java:716)\r\n\tat com.googlecode.dex2jar.ir.ts.TypeTransformer$TypeAnalyze.exExpr(TypeTransformer.java:703)\r\n\tat com.googlecode.dex2jar.ir.ts.TypeTransformer$TypeAnalyze.s1stmt(TypeTransformer.java:810)\r\n\tat com.googlecode.dex2jar.ir.ts.TypeTransformer$TypeAnalyze.sxStmt(TypeTransformer.java:840)\r\n\tat com.googlecode.dex2jar.ir.ts.TypeTransformer$TypeAnalyze.analyze(TypeTransformer.java:206)\r\n\tat com.googlecode.dex2jar.ir.ts.TypeTransformer.transform(TypeTransformer.java:44)\r\n\tat com.googlecode.d2j.dex.Dex2jar$2.optimize(Dex2jar.java:162)\r\n\tat com.googlecode.d2j.dex.Dex2Asm.convertCode(Dex2Asm.java:414)\r\n\tat com.googlecode.d2j.dex.ExDex2Asm.convertCode(ExDex2Asm.java:42)\r\n\tat com.googlecode.d2j.dex.Dex2jar$2.convertCode(Dex2jar.java:128)\r\n\tat com.googlecode.d2j.dex.Dex2Asm.convertMethod(Dex2Asm.java:509)\r\n\tat com.googlecode.d2j.dex.Dex2Asm.convertClass(Dex2Asm.java:406)\r\n\tat com.googlecode.d2j.dex.Dex2Asm.convertDex(Dex2Asm.java:422)\r\n\tat com.googlecode.d2j.dex.Dex2jar.doTranslate(Dex2jar.java:172)\r\n\tat com.googlecode.d2j.dex.Dex2jar.to(Dex2jar.java:272)\r\n\tat com.googlecode.dex2jar.tools.Dex2jarCmd.doCommandLine(Dex2jarCmd.java:108)\r\n\tat com.googlecode.dex2jar.tools.BaseCmd.doMain(BaseCmd.java:288)\r\n\tat com.googlecode.dex2jar.tools.Dex2jarCmd.main(Dex2jarCmd.java:32)\r\n");
  }
  
  public String toString() {
    StringBuilder stringBuilder = new StringBuilder();
    stringBuilder.append("{WorkSpec: ");
    stringBuilder.append(this.a);
    stringBuilder.append("}");
    return stringBuilder.toString();
  }
  
  class a implements d.a<List<Object>, List<Object>> {}
  
  public static class b {
    public String a;
    
    public u b;
    
    public boolean equals(Object param1Object) {
      if (this == param1Object)
        return true; 
      if (!(param1Object instanceof b))
        return false; 
      param1Object = param1Object;
      return (this.b != ((b)param1Object).b) ? false : this.a.equals(((b)param1Object).a);
    }
    
    public int hashCode() {
      return this.a.hashCode() * 31 + this.b.hashCode();
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Hill race-dex2jar.jar!\a0\p.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */