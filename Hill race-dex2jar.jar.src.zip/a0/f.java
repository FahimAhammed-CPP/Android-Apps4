package a0;

import android.database.Cursor;
import androidx.room.h;
import j.c;
import l.c;
import m.e;

public final class f implements e {
  private final h a;
  
  private final j.a<d> b;
  
  public f(h paramh) {
    this.a = paramh;
    this.b = new a(this, paramh);
  }
  
  public Long a(String paramString) {
    c c = c.a("SELECT long_value FROM Preference where `key`=?", 1);
    if (paramString == null) {
      c.r(1);
    } else {
      c.b(1, paramString);
    } 
    this.a.b();
    null = this.a;
    h h1 = null;
    Cursor cursor = c.b(null, (e)c, false, null);
    null = h1;
    try {
      Long long_;
      if (cursor.moveToFirst())
        if (cursor.isNull(0)) {
          null = h1;
        } else {
          long_ = Long.valueOf(cursor.getLong(0));
        }  
      return long_;
    } finally {
      cursor.close();
      c.release();
    } 
  }
  
  public void b(d paramd) {
    this.a.b();
    this.a.c();
    try {
      this.b.h(paramd);
      this.a.r();
      return;
    } finally {
      this.a.g();
    } 
  }
  
  class a extends j.a<d> {
    a(f this$0, h param1h) {
      super(param1h);
    }
    
    public String d() {
      return "INSERT OR REPLACE INTO `Preference` (`key`,`long_value`) VALUES (?,?)";
    }
    
    public void i(m.f param1f, d param1d) {
      String str = param1d.a;
      if (str == null) {
        param1f.r(1);
      } else {
        param1f.b(1, str);
      } 
      Long long_ = param1d.b;
      if (long_ == null) {
        param1f.r(2);
        return;
      } 
      param1f.j(2, long_.longValue());
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Hill race-dex2jar.jar!\a0\f.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */