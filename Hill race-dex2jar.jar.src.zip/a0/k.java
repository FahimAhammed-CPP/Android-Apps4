package a0;

import java.util.List;

public interface k {
  void a(j paramj);
  
  List<String> b(String paramString);
}


/* Location:              C:\soft\dex2jar-2.0\Hill race-dex2jar.jar!\a0\k.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */