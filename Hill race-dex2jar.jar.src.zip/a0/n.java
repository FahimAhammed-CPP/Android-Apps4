package a0;

public interface n {
  void a(String paramString);
  
  void b(m paramm);
  
  void c();
}


/* Location:              C:\soft\dex2jar-2.0\Hill race-dex2jar.jar!\a0\n.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */