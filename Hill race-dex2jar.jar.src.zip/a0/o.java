package a0;

import androidx.room.h;
import androidx.work.e;
import j.d;
import m.f;

public final class o implements n {
  private final h a;
  
  private final j.a<m> b;
  
  private final d c;
  
  private final d d;
  
  public o(h paramh) {
    this.a = paramh;
    this.b = new a(this, paramh);
    this.c = new b(this, paramh);
    this.d = new c(this, paramh);
  }
  
  public void a(String paramString) {
    this.a.b();
    f f = this.c.a();
    if (paramString == null) {
      f.r(1);
    } else {
      f.b(1, paramString);
    } 
    this.a.c();
    try {
      f.J();
      this.a.r();
      return;
    } finally {
      this.a.g();
      this.c.f(f);
    } 
  }
  
  public void b(m paramm) {
    this.a.b();
    this.a.c();
    try {
      this.b.h(paramm);
      this.a.r();
      return;
    } finally {
      this.a.g();
    } 
  }
  
  public void c() {
    this.a.b();
    f f = this.d.a();
    this.a.c();
    try {
      f.J();
      this.a.r();
      return;
    } finally {
      this.a.g();
      this.d.f(f);
    } 
  }
  
  class a extends j.a<m> {
    a(o this$0, h param1h) {
      super(param1h);
    }
    
    public String d() {
      return "INSERT OR REPLACE INTO `WorkProgress` (`work_spec_id`,`progress`) VALUES (?,?)";
    }
    
    public void i(f param1f, m param1m) {
      String str = param1m.a;
      if (str == null) {
        param1f.r(1);
      } else {
        param1f.b(1, str);
      } 
      byte[] arrayOfByte = e.k(param1m.b);
      if (arrayOfByte == null) {
        param1f.r(2);
        return;
      } 
      param1f.k(2, arrayOfByte);
    }
  }
  
  class b extends d {
    b(o this$0, h param1h) {
      super(param1h);
    }
    
    public String d() {
      return "DELETE from WorkProgress where work_spec_id=?";
    }
  }
  
  class c extends d {
    c(o this$0, h param1h) {
      super(param1h);
    }
    
    public String d() {
      return "DELETE FROM WorkProgress";
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Hill race-dex2jar.jar!\a0\o.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */