package a0;

import android.database.Cursor;
import androidx.room.h;
import java.util.ArrayList;
import java.util.List;
import m.e;
import m.f;

public final class c implements b {
  private final h a;
  
  private final j.a<a> b;
  
  public c(h paramh) {
    this.a = paramh;
    this.b = new a(this, paramh);
  }
  
  public void a(a parama) {
    this.a.b();
    this.a.c();
    try {
      this.b.h(parama);
      this.a.r();
      return;
    } finally {
      this.a.g();
    } 
  }
  
  public List<String> b(String paramString) {
    j.c c1 = j.c.a("SELECT work_spec_id FROM dependency WHERE prerequisite_id=?", 1);
    if (paramString == null) {
      c1.r(1);
    } else {
      c1.b(1, paramString);
    } 
    this.a.b();
    Cursor cursor = l.c.b(this.a, (e)c1, false, null);
    try {
      ArrayList<String> arrayList = new ArrayList(cursor.getCount());
      while (cursor.moveToNext())
        arrayList.add(cursor.getString(0)); 
      return arrayList;
    } finally {
      cursor.close();
      c1.release();
    } 
  }
  
  public boolean c(String paramString) {
    boolean bool2 = true;
    j.c c1 = j.c.a("SELECT COUNT(*)=0 FROM dependency WHERE work_spec_id=? AND prerequisite_id IN (SELECT id FROM workspec WHERE state!=2)", 1);
    if (paramString == null) {
      c1.r(1);
    } else {
      c1.b(1, paramString);
    } 
    this.a.b();
    h h1 = this.a;
    boolean bool1 = false;
    Cursor cursor = l.c.b(h1, (e)c1, false, null);
    try {
      if (cursor.moveToFirst()) {
        int i = cursor.getInt(0);
        if (i != 0) {
          bool1 = bool2;
        } else {
          bool1 = false;
        } 
      } 
      return bool1;
    } finally {
      cursor.close();
      c1.release();
    } 
  }
  
  public boolean d(String paramString) {
    boolean bool2 = true;
    j.c c1 = j.c.a("SELECT COUNT(*)>0 FROM dependency WHERE prerequisite_id=?", 1);
    if (paramString == null) {
      c1.r(1);
    } else {
      c1.b(1, paramString);
    } 
    this.a.b();
    h h1 = this.a;
    boolean bool1 = false;
    Cursor cursor = l.c.b(h1, (e)c1, false, null);
    try {
      if (cursor.moveToFirst()) {
        int i = cursor.getInt(0);
        if (i != 0) {
          bool1 = bool2;
        } else {
          bool1 = false;
        } 
      } 
      return bool1;
    } finally {
      cursor.close();
      c1.release();
    } 
  }
  
  class a extends j.a<a> {
    a(c this$0, h param1h) {
      super(param1h);
    }
    
    public String d() {
      return "INSERT OR IGNORE INTO `Dependency` (`work_spec_id`,`prerequisite_id`) VALUES (?,?)";
    }
    
    public void i(f param1f, a param1a) {
      String str2 = param1a.a;
      if (str2 == null) {
        param1f.r(1);
      } else {
        param1f.b(1, str2);
      } 
      String str1 = param1a.b;
      if (str1 == null) {
        param1f.r(2);
        return;
      } 
      param1f.b(2, str1);
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Hill race-dex2jar.jar!\a0\c.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */