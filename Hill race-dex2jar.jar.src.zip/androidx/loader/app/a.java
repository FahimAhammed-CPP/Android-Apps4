package androidx.loader.app;

import androidx.lifecycle.j;
import androidx.lifecycle.y;
import java.io.FileDescriptor;
import java.io.PrintWriter;

public abstract class a {
  public static <T extends j & y> a b(T paramT) {
    return new b((j)paramT, ((y)paramT).getViewModelStore());
  }
  
  @Deprecated
  public abstract void a(String paramString, FileDescriptor paramFileDescriptor, PrintWriter paramPrintWriter, String[] paramArrayOfString);
  
  public abstract void c();
}


/* Location:              C:\soft\dex2jar-2.0\Hill race-dex2jar.jar!\androidx\loader\app\a.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */