package androidx.loader.app;

import android.os.Bundle;
import android.util.Log;
import androidx.collection.g;
import androidx.lifecycle.j;
import androidx.lifecycle.p;
import androidx.lifecycle.q;
import androidx.lifecycle.v;
import androidx.lifecycle.w;
import androidx.lifecycle.x;
import java.io.FileDescriptor;
import java.io.PrintWriter;

class b extends a {
  static boolean c = false;
  
  private final j a;
  
  private final b b;
  
  b(j paramj, x paramx) {
    this.a = paramj;
    this.b = b.c(paramx);
  }
  
  @Deprecated
  public void a(String paramString, FileDescriptor paramFileDescriptor, PrintWriter paramPrintWriter, String[] paramArrayOfString) {
    this.b.b(paramString, paramFileDescriptor, paramPrintWriter, paramArrayOfString);
  }
  
  public void c() {
    this.b.d();
  }
  
  public String toString() {
    StringBuilder stringBuilder = new StringBuilder(128);
    stringBuilder.append("LoaderManager{");
    stringBuilder.append(Integer.toHexString(System.identityHashCode(this)));
    stringBuilder.append(" in ");
    androidx.core.util.b.a(this.a, stringBuilder);
    stringBuilder.append("}}");
    return stringBuilder.toString();
  }
  
  public static class a<D> extends p<D> {
    private final int k;
    
    private final Bundle l;
    
    private final i.a<D> m;
    
    private j n;
    
    protected void d() {
      if (b.c) {
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("  Starting: ");
        stringBuilder.append(this);
        Log.v("LoaderManager", stringBuilder.toString());
      } 
      throw null;
    }
    
    protected void e() {
      if (b.c) {
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("  Stopping: ");
        stringBuilder.append(this);
        Log.v("LoaderManager", stringBuilder.toString());
      } 
      throw null;
    }
    
    public void g(q<? super D> param1q) {
      super.g(param1q);
      this.n = null;
    }
    
    public void h(D param1D) {
      super.h(param1D);
    }
    
    i.a<D> i(boolean param1Boolean) {
      if (b.c) {
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("  Destroying: ");
        stringBuilder.append(this);
        Log.v("LoaderManager", stringBuilder.toString());
      } 
      throw null;
    }
    
    public void j(String param1String, FileDescriptor param1FileDescriptor, PrintWriter param1PrintWriter, String[] param1ArrayOfString) {
      param1PrintWriter.print(param1String);
      param1PrintWriter.print("mId=");
      param1PrintWriter.print(this.k);
      param1PrintWriter.print(" mArgs=");
      param1PrintWriter.println(this.l);
      param1PrintWriter.print(param1String);
      param1PrintWriter.print("mLoader=");
      param1PrintWriter.println(this.m);
      StringBuilder stringBuilder = new StringBuilder();
      stringBuilder.append(param1String);
      stringBuilder.append("  ");
      throw null;
    }
    
    void k() {}
    
    public String toString() {
      StringBuilder stringBuilder = new StringBuilder(64);
      stringBuilder.append("LoaderInfo{");
      stringBuilder.append(Integer.toHexString(System.identityHashCode(this)));
      stringBuilder.append(" #");
      stringBuilder.append(this.k);
      stringBuilder.append(" : ");
      androidx.core.util.b.a(this.m, stringBuilder);
      stringBuilder.append("}}");
      return stringBuilder.toString();
    }
  }
  
  static class b extends v {
    private static final w.a c = new a();
    
    private g<b.a> a = new g();
    
    private boolean b = false;
    
    static b c(x param1x) {
      return (b)(new w(param1x, c)).a(b.class);
    }
    
    protected void a() {
      super.a();
      int j = this.a.k();
      for (int i = 0; i < j; i++)
        ((b.a)this.a.l(i)).i(true); 
      this.a.b();
    }
    
    public void b(String param1String, FileDescriptor param1FileDescriptor, PrintWriter param1PrintWriter, String[] param1ArrayOfString) {
      if (this.a.k() > 0) {
        param1PrintWriter.print(param1String);
        param1PrintWriter.println("Loaders:");
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append(param1String);
        stringBuilder.append("    ");
        String str = stringBuilder.toString();
        int i;
        for (i = 0; i < this.a.k(); i++) {
          b.a a1 = (b.a)this.a.l(i);
          param1PrintWriter.print(param1String);
          param1PrintWriter.print("  #");
          param1PrintWriter.print(this.a.h(i));
          param1PrintWriter.print(": ");
          param1PrintWriter.println(a1.toString());
          a1.j(str, param1FileDescriptor, param1PrintWriter, param1ArrayOfString);
        } 
      } 
    }
    
    void d() {
      int j = this.a.k();
      for (int i = 0; i < j; i++)
        ((b.a)this.a.l(i)).k(); 
    }
    
    static final class a implements w.a {
      public <T extends v> T a(Class<T> param2Class) {
        return (T)new b.b();
      }
    }
  }
  
  static final class a implements w.a {
    public <T extends v> T a(Class<T> param1Class) {
      return (T)new b.b();
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Hill race-dex2jar.jar!\androidx\loader\app\b.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */