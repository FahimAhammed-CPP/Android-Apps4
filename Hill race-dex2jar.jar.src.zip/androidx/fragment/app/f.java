package androidx.fragment.app;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.content.IntentSender;
import android.os.Bundle;
import android.os.Handler;
import android.view.LayoutInflater;
import java.io.FileDescriptor;
import java.io.PrintWriter;

public abstract class f<E> extends d {
  private final Activity a;
  
  private final Context b;
  
  private final Handler c;
  
  private final int d;
  
  final h e = new h();
  
  f(Activity paramActivity, Context paramContext, Handler paramHandler, int paramInt) {
    this.a = paramActivity;
    this.b = (Context)androidx.core.util.f.b(paramContext, "context == null");
    this.c = (Handler)androidx.core.util.f.b(paramHandler, "handler == null");
    this.d = paramInt;
  }
  
  f(c paramc) {
    this((Activity)paramc, (Context)paramc, paramc.d, 0);
  }
  
  Activity d() {
    return this.a;
  }
  
  Context e() {
    return this.b;
  }
  
  h f() {
    return this.e;
  }
  
  Handler g() {
    return this.c;
  }
  
  abstract void h(Fragment paramFragment);
  
  public abstract void i(String paramString, FileDescriptor paramFileDescriptor, PrintWriter paramPrintWriter, String[] paramArrayOfString);
  
  public abstract E j();
  
  public abstract LayoutInflater k();
  
  public abstract int l();
  
  public abstract boolean m();
  
  public abstract void n(Fragment paramFragment, String[] paramArrayOfString, int paramInt);
  
  public abstract boolean o(Fragment paramFragment);
  
  public abstract boolean p(String paramString);
  
  public abstract void q(Fragment paramFragment, Intent paramIntent, int paramInt, Bundle paramBundle);
  
  public abstract void r(Fragment paramFragment, IntentSender paramIntentSender, int paramInt1, Intent paramIntent, int paramInt2, int paramInt3, int paramInt4, Bundle paramBundle) throws IntentSender.SendIntentException;
  
  public abstract void s();
}


/* Location:              C:\soft\dex2jar-2.0\Hill race-dex2jar.jar!\androidx\fragment\app\f.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */