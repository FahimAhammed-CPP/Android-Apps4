package androidx.fragment.app;

import android.util.AndroidRuntimeException;

final class o extends AndroidRuntimeException {
  public o(String paramString) {
    super(paramString);
  }
}


/* Location:              C:\soft\dex2jar-2.0\Hill race-dex2jar.jar!\androidx\fragment\app\o.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */