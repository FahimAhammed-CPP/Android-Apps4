package androidx.fragment.app;

import android.view.View;
import android.view.ViewTreeObserver;

class n implements ViewTreeObserver.OnPreDrawListener, View.OnAttachStateChangeListener {
  private final View b;
  
  private ViewTreeObserver c;
  
  private final Runnable d;
  
  private n(View paramView, Runnable paramRunnable) {
    this.b = paramView;
    this.c = paramView.getViewTreeObserver();
    this.d = paramRunnable;
  }
  
  public static n a(View paramView, Runnable paramRunnable) {
    n n1 = new n(paramView, paramRunnable);
    paramView.getViewTreeObserver().addOnPreDrawListener(n1);
    paramView.addOnAttachStateChangeListener(n1);
    return n1;
  }
  
  public void b() {
    if (this.c.isAlive()) {
      this.c.removeOnPreDrawListener(this);
    } else {
      this.b.getViewTreeObserver().removeOnPreDrawListener(this);
    } 
    this.b.removeOnAttachStateChangeListener(this);
  }
  
  public boolean onPreDraw() {
    b();
    this.d.run();
    return true;
  }
  
  public void onViewAttachedToWindow(View paramView) {
    this.c = paramView.getViewTreeObserver();
  }
  
  public void onViewDetachedFromWindow(View paramView) {
    b();
  }
}


/* Location:              C:\soft\dex2jar-2.0\Hill race-dex2jar.jar!\androidx\fragment\app\n.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */