package androidx.fragment.app;

import android.os.Parcel;
import android.os.Parcelable;
import android.text.TextUtils;
import android.util.Log;
import java.util.ArrayList;

final class BackStackState implements Parcelable {
  public static final Parcelable.Creator<BackStackState> CREATOR = new a();
  
  final int[] b;
  
  final int c;
  
  final int d;
  
  final String e;
  
  final int f;
  
  final int g;
  
  final CharSequence h;
  
  final int i;
  
  final CharSequence j;
  
  final ArrayList<String> k;
  
  final ArrayList<String> l;
  
  final boolean m;
  
  public BackStackState(Parcel paramParcel) {
    boolean bool;
    this.b = paramParcel.createIntArray();
    this.c = paramParcel.readInt();
    this.d = paramParcel.readInt();
    this.e = paramParcel.readString();
    this.f = paramParcel.readInt();
    this.g = paramParcel.readInt();
    this.h = (CharSequence)TextUtils.CHAR_SEQUENCE_CREATOR.createFromParcel(paramParcel);
    this.i = paramParcel.readInt();
    this.j = (CharSequence)TextUtils.CHAR_SEQUENCE_CREATOR.createFromParcel(paramParcel);
    this.k = paramParcel.createStringArrayList();
    this.l = paramParcel.createStringArrayList();
    if (paramParcel.readInt() != 0) {
      bool = true;
    } else {
      bool = false;
    } 
    this.m = bool;
  }
  
  public BackStackState(a parama) {
    int i = parama.b.size();
    this.b = new int[i * 6];
    if (parama.i) {
      int j = 0;
      int k = 0;
      while (j < i) {
        a.a a1 = parama.b.get(j);
        int[] arrayOfInt = this.b;
        int m = k + 1;
        arrayOfInt[k] = a1.a;
        int n = m + 1;
        Fragment fragment = a1.b;
        if (fragment != null) {
          k = fragment.mIndex;
        } else {
          k = -1;
        } 
        arrayOfInt[m] = k;
        k = n + 1;
        arrayOfInt[n] = a1.c;
        m = k + 1;
        arrayOfInt[k] = a1.d;
        n = m + 1;
        arrayOfInt[m] = a1.e;
        k = n + 1;
        arrayOfInt[n] = a1.f;
        j++;
      } 
      this.c = parama.g;
      this.d = parama.h;
      this.e = parama.k;
      this.f = parama.m;
      this.g = parama.n;
      this.h = parama.o;
      this.i = parama.p;
      this.j = parama.q;
      this.k = parama.r;
      this.l = parama.s;
      this.m = parama.t;
      return;
    } 
    throw new IllegalStateException("Not on back stack");
  }
  
  public a a(h paramh) {
    a a = new a(paramh);
    int j = 0;
    int i = 0;
    while (j < this.b.length) {
      a.a a1 = new a.a();
      int[] arrayOfInt = this.b;
      int k = j + 1;
      a1.a = arrayOfInt[j];
      if (h.F) {
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("Instantiate ");
        stringBuilder.append(a);
        stringBuilder.append(" op #");
        stringBuilder.append(i);
        stringBuilder.append(" base fragment #");
        stringBuilder.append(this.b[k]);
        Log.v("FragmentManager", stringBuilder.toString());
      } 
      arrayOfInt = this.b;
      j = k + 1;
      k = arrayOfInt[k];
      if (k >= 0) {
        a1.b = (Fragment)paramh.f.get(k);
      } else {
        a1.b = null;
      } 
      arrayOfInt = this.b;
      k = j + 1;
      j = arrayOfInt[j];
      a1.c = j;
      int n = k + 1;
      int m = arrayOfInt[k];
      a1.d = m;
      k = n + 1;
      n = arrayOfInt[n];
      a1.e = n;
      int i1 = arrayOfInt[k];
      a1.f = i1;
      a.c = j;
      a.d = m;
      a.e = n;
      a.f = i1;
      a.g(a1);
      i++;
      j = k + 1;
    } 
    a.g = this.c;
    a.h = this.d;
    a.k = this.e;
    a.m = this.f;
    a.i = true;
    a.n = this.g;
    a.o = this.h;
    a.p = this.i;
    a.q = this.j;
    a.r = this.k;
    a.s = this.l;
    a.t = this.m;
    a.h(1);
    return a;
  }
  
  public int describeContents() {
    return 0;
  }
  
  public void writeToParcel(Parcel paramParcel, int paramInt) {
    throw new RuntimeException("d2j fail translate: java.lang.RuntimeException: can not merge I and Z\r\n\tat com.googlecode.dex2jar.ir.TypeClass.merge(TypeClass.java:100)\r\n\tat com.googlecode.dex2jar.ir.ts.TypeTransformer$TypeRef.updateTypeClass(TypeTransformer.java:174)\r\n\tat com.googlecode.dex2jar.ir.ts.TypeTransformer$TypeAnalyze.provideAs(TypeTransformer.java:780)\r\n\tat com.googlecode.dex2jar.ir.ts.TypeTransformer$TypeAnalyze.e1expr(TypeTransformer.java:496)\r\n\tat com.googlecode.dex2jar.ir.ts.TypeTransformer$TypeAnalyze.exExpr(TypeTransformer.java:713)\r\n\tat com.googlecode.dex2jar.ir.ts.TypeTransformer$TypeAnalyze.exExpr(TypeTransformer.java:703)\r\n\tat com.googlecode.dex2jar.ir.ts.TypeTransformer$TypeAnalyze.enexpr(TypeTransformer.java:698)\r\n\tat com.googlecode.dex2jar.ir.ts.TypeTransformer$TypeAnalyze.exExpr(TypeTransformer.java:719)\r\n\tat com.googlecode.dex2jar.ir.ts.TypeTransformer$TypeAnalyze.exExpr(TypeTransformer.java:703)\r\n\tat com.googlecode.dex2jar.ir.ts.TypeTransformer$TypeAnalyze.s1stmt(TypeTransformer.java:810)\r\n\tat com.googlecode.dex2jar.ir.ts.TypeTransformer$TypeAnalyze.sxStmt(TypeTransformer.java:840)\r\n\tat com.googlecode.dex2jar.ir.ts.TypeTransformer$TypeAnalyze.analyze(TypeTransformer.java:206)\r\n\tat com.googlecode.dex2jar.ir.ts.TypeTransformer.transform(TypeTransformer.java:44)\r\n\tat com.googlecode.d2j.dex.Dex2jar$2.optimize(Dex2jar.java:162)\r\n\tat com.googlecode.d2j.dex.Dex2Asm.convertCode(Dex2Asm.java:414)\r\n\tat com.googlecode.d2j.dex.ExDex2Asm.convertCode(ExDex2Asm.java:42)\r\n\tat com.googlecode.d2j.dex.Dex2jar$2.convertCode(Dex2jar.java:128)\r\n\tat com.googlecode.d2j.dex.Dex2Asm.convertMethod(Dex2Asm.java:509)\r\n\tat com.googlecode.d2j.dex.Dex2Asm.convertClass(Dex2Asm.java:406)\r\n\tat com.googlecode.d2j.dex.Dex2Asm.convertDex(Dex2Asm.java:422)\r\n\tat com.googlecode.d2j.dex.Dex2jar.doTranslate(Dex2jar.java:172)\r\n\tat com.googlecode.d2j.dex.Dex2jar.to(Dex2jar.java:272)\r\n\tat com.googlecode.dex2jar.tools.Dex2jarCmd.doCommandLine(Dex2jarCmd.java:108)\r\n\tat com.googlecode.dex2jar.tools.BaseCmd.doMain(BaseCmd.java:288)\r\n\tat com.googlecode.dex2jar.tools.Dex2jarCmd.main(Dex2jarCmd.java:32)\r\n");
  }
  
  static final class a implements Parcelable.Creator<BackStackState> {
    public BackStackState a(Parcel param1Parcel) {
      return new BackStackState(param1Parcel);
    }
    
    public BackStackState[] b(int param1Int) {
      return new BackStackState[param1Int];
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Hill race-dex2jar.jar!\androidx\fragment\app\BackStackState.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */