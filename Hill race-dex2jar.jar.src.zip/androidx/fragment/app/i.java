package androidx.fragment.app;

import androidx.lifecycle.x;
import java.util.List;

public class i {
  private final List<Fragment> a;
  
  private final List<i> b;
  
  private final List<x> c;
  
  i(List<Fragment> paramList, List<i> paramList1, List<x> paramList2) {
    this.a = paramList;
    this.b = paramList1;
    this.c = paramList2;
  }
  
  List<i> a() {
    return this.b;
  }
  
  List<Fragment> b() {
    return this.a;
  }
  
  List<x> c() {
    return this.c;
  }
}


/* Location:              C:\soft\dex2jar-2.0\Hill race-dex2jar.jar!\androidx\fragment\app\i.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */