package androidx.fragment.app;

import android.util.Log;
import androidx.core.util.c;
import java.io.FileDescriptor;
import java.io.PrintWriter;
import java.io.Writer;
import java.lang.reflect.Modifier;
import java.util.ArrayList;

final class a extends j implements h.l {
  final h a;
  
  ArrayList<a> b = new ArrayList<a>();
  
  int c;
  
  int d;
  
  int e;
  
  int f;
  
  int g;
  
  int h;
  
  boolean i;
  
  boolean j = true;
  
  String k;
  
  boolean l;
  
  int m = -1;
  
  int n;
  
  CharSequence o;
  
  int p;
  
  CharSequence q;
  
  ArrayList<String> r;
  
  ArrayList<String> s;
  
  boolean t = false;
  
  ArrayList<Runnable> u;
  
  public a(h paramh) {
    this.a = paramh;
  }
  
  private void k(int paramInt1, Fragment paramFragment, String paramString, int paramInt2) {
    StringBuilder stringBuilder2;
    Class<?> clazz = paramFragment.getClass();
    int i = clazz.getModifiers();
    if (!clazz.isAnonymousClass() && Modifier.isPublic(i) && (!clazz.isMemberClass() || Modifier.isStatic(i))) {
      paramFragment.mFragmentManager = this.a;
      if (paramString != null) {
        String str = paramFragment.mTag;
        if (str == null || paramString.equals(str)) {
          paramFragment.mTag = paramString;
        } else {
          stringBuilder2 = new StringBuilder();
          stringBuilder2.append("Can't change tag of fragment ");
          stringBuilder2.append(paramFragment);
          stringBuilder2.append(": was ");
          stringBuilder2.append(paramFragment.mTag);
          stringBuilder2.append(" now ");
          stringBuilder2.append(paramString);
          throw new IllegalStateException(stringBuilder2.toString());
        } 
      } 
      if (paramInt1 != 0) {
        StringBuilder stringBuilder;
        if (paramInt1 != -1) {
          i = paramFragment.mFragmentId;
          if (i == 0 || i == paramInt1) {
            paramFragment.mFragmentId = paramInt1;
            paramFragment.mContainerId = paramInt1;
          } else {
            stringBuilder = new StringBuilder();
            stringBuilder.append("Can't change container ID of fragment ");
            stringBuilder.append(paramFragment);
            stringBuilder.append(": was ");
            stringBuilder.append(paramFragment.mFragmentId);
            stringBuilder.append(" now ");
            stringBuilder.append(paramInt1);
            throw new IllegalStateException(stringBuilder.toString());
          } 
        } else {
          stringBuilder2 = new StringBuilder();
          stringBuilder2.append("Can't add fragment ");
          stringBuilder2.append(paramFragment);
          stringBuilder2.append(" with tag ");
          stringBuilder2.append((String)stringBuilder);
          stringBuilder2.append(" to container view with no id");
          throw new IllegalArgumentException(stringBuilder2.toString());
        } 
      } 
      g(new a(paramInt2, paramFragment));
      return;
    } 
    StringBuilder stringBuilder1 = new StringBuilder();
    stringBuilder1.append("Fragment ");
    stringBuilder1.append(stringBuilder2.getCanonicalName());
    stringBuilder1.append(" must be a public static class to be  properly recreated from");
    stringBuilder1.append(" instance state.");
    throw new IllegalStateException(stringBuilder1.toString());
  }
  
  private static boolean t(a parama) {
    Fragment fragment = parama.b;
    return (fragment != null && fragment.mAdded && fragment.mView != null && !fragment.mDetached && !fragment.mHidden && fragment.isPostponed());
  }
  
  public boolean a(ArrayList<a> paramArrayList, ArrayList<Boolean> paramArrayList1) {
    if (h.F) {
      StringBuilder stringBuilder = new StringBuilder();
      stringBuilder.append("Run: ");
      stringBuilder.append(this);
      Log.v("FragmentManager", stringBuilder.toString());
    } 
    paramArrayList.add(this);
    paramArrayList1.add(Boolean.FALSE);
    if (this.i)
      this.a.i(this); 
    return true;
  }
  
  public j b(Fragment paramFragment, String paramString) {
    k(0, paramFragment, paramString, 1);
    return this;
  }
  
  public int c() {
    return i(false);
  }
  
  public int d() {
    return i(true);
  }
  
  public void e() {
    j();
    this.a.g0(this, false);
  }
  
  public j f(Fragment paramFragment) {
    g(new a(3, paramFragment));
    return this;
  }
  
  void g(a parama) {
    this.b.add(parama);
    parama.c = this.c;
    parama.d = this.d;
    parama.e = this.e;
    parama.f = this.f;
  }
  
  void h(int paramInt) {
    if (!this.i)
      return; 
    if (h.F) {
      StringBuilder stringBuilder = new StringBuilder();
      stringBuilder.append("Bump nesting in ");
      stringBuilder.append(this);
      stringBuilder.append(" by ");
      stringBuilder.append(paramInt);
      Log.v("FragmentManager", stringBuilder.toString());
    } 
    int k = this.b.size();
    for (int i = 0; i < k; i++) {
      a a1 = this.b.get(i);
      Fragment fragment = a1.b;
      if (fragment != null) {
        fragment.mBackStackNesting += paramInt;
        if (h.F) {
          StringBuilder stringBuilder = new StringBuilder();
          stringBuilder.append("Bump nesting of ");
          stringBuilder.append(a1.b);
          stringBuilder.append(" to ");
          stringBuilder.append(a1.b.mBackStackNesting);
          Log.v("FragmentManager", stringBuilder.toString());
        } 
      } 
    } 
  }
  
  int i(boolean paramBoolean) {
    if (!this.l) {
      if (h.F) {
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("Commit: ");
        stringBuilder.append(this);
        Log.v("FragmentManager", stringBuilder.toString());
        PrintWriter printWriter = new PrintWriter((Writer)new c("FragmentManager"));
        l("  ", null, printWriter, null);
        printWriter.close();
      } 
      this.l = true;
      if (this.i) {
        this.m = this.a.k(this);
      } else {
        this.m = -1;
      } 
      this.a.c0(this, paramBoolean);
      return this.m;
    } 
    throw new IllegalStateException("commit already called");
  }
  
  public j j() {
    if (!this.i) {
      this.j = false;
      return this;
    } 
    throw new IllegalStateException("This transaction is already being added to the back stack");
  }
  
  public void l(String paramString, FileDescriptor paramFileDescriptor, PrintWriter paramPrintWriter, String[] paramArrayOfString) {
    m(paramString, paramPrintWriter, true);
  }
  
  public void m(String paramString, PrintWriter paramPrintWriter, boolean paramBoolean) {
    if (paramBoolean) {
      paramPrintWriter.print(paramString);
      paramPrintWriter.print("mName=");
      paramPrintWriter.print(this.k);
      paramPrintWriter.print(" mIndex=");
      paramPrintWriter.print(this.m);
      paramPrintWriter.print(" mCommitted=");
      paramPrintWriter.println(this.l);
      if (this.g != 0) {
        paramPrintWriter.print(paramString);
        paramPrintWriter.print("mTransition=#");
        paramPrintWriter.print(Integer.toHexString(this.g));
        paramPrintWriter.print(" mTransitionStyle=#");
        paramPrintWriter.println(Integer.toHexString(this.h));
      } 
      if (this.c != 0 || this.d != 0) {
        paramPrintWriter.print(paramString);
        paramPrintWriter.print("mEnterAnim=#");
        paramPrintWriter.print(Integer.toHexString(this.c));
        paramPrintWriter.print(" mExitAnim=#");
        paramPrintWriter.println(Integer.toHexString(this.d));
      } 
      if (this.e != 0 || this.f != 0) {
        paramPrintWriter.print(paramString);
        paramPrintWriter.print("mPopEnterAnim=#");
        paramPrintWriter.print(Integer.toHexString(this.e));
        paramPrintWriter.print(" mPopExitAnim=#");
        paramPrintWriter.println(Integer.toHexString(this.f));
      } 
      if (this.n != 0 || this.o != null) {
        paramPrintWriter.print(paramString);
        paramPrintWriter.print("mBreadCrumbTitleRes=#");
        paramPrintWriter.print(Integer.toHexString(this.n));
        paramPrintWriter.print(" mBreadCrumbTitleText=");
        paramPrintWriter.println(this.o);
      } 
      if (this.p != 0 || this.q != null) {
        paramPrintWriter.print(paramString);
        paramPrintWriter.print("mBreadCrumbShortTitleRes=#");
        paramPrintWriter.print(Integer.toHexString(this.p));
        paramPrintWriter.print(" mBreadCrumbShortTitleText=");
        paramPrintWriter.println(this.q);
      } 
    } 
    if (!this.b.isEmpty()) {
      paramPrintWriter.print(paramString);
      paramPrintWriter.println("Operations:");
      int k = this.b.size();
      int i;
      for (i = 0; i < k; i++) {
        StringBuilder stringBuilder;
        String str;
        a a1 = this.b.get(i);
        switch (a1.a) {
          default:
            stringBuilder = new StringBuilder();
            stringBuilder.append("cmd=");
            stringBuilder.append(a1.a);
            str = stringBuilder.toString();
            break;
          case 9:
            str = "UNSET_PRIMARY_NAV";
            break;
          case 8:
            str = "SET_PRIMARY_NAV";
            break;
          case 7:
            str = "ATTACH";
            break;
          case 6:
            str = "DETACH";
            break;
          case 5:
            str = "SHOW";
            break;
          case 4:
            str = "HIDE";
            break;
          case 3:
            str = "REMOVE";
            break;
          case 2:
            str = "REPLACE";
            break;
          case 1:
            str = "ADD";
            break;
          case 0:
            str = "NULL";
            break;
        } 
        paramPrintWriter.print(paramString);
        paramPrintWriter.print("  Op #");
        paramPrintWriter.print(i);
        paramPrintWriter.print(": ");
        paramPrintWriter.print(str);
        paramPrintWriter.print(" ");
        paramPrintWriter.println(a1.b);
        if (paramBoolean) {
          if (a1.c != 0 || a1.d != 0) {
            paramPrintWriter.print(paramString);
            paramPrintWriter.print("enterAnim=#");
            paramPrintWriter.print(Integer.toHexString(a1.c));
            paramPrintWriter.print(" exitAnim=#");
            paramPrintWriter.println(Integer.toHexString(a1.d));
          } 
          if (a1.e != 0 || a1.f != 0) {
            paramPrintWriter.print(paramString);
            paramPrintWriter.print("popEnterAnim=#");
            paramPrintWriter.print(Integer.toHexString(a1.e));
            paramPrintWriter.print(" popExitAnim=#");
            paramPrintWriter.println(Integer.toHexString(a1.f));
          } 
        } 
      } 
    } 
  }
  
  void n() {
    int k = this.b.size();
    for (int i = 0; i < k; i++) {
      StringBuilder stringBuilder;
      a a1 = this.b.get(i);
      Fragment fragment = a1.b;
      if (fragment != null)
        fragment.setNextTransition(this.g, this.h); 
      switch (a1.a) {
        default:
          stringBuilder = new StringBuilder();
          stringBuilder.append("Unknown cmd: ");
          stringBuilder.append(a1.a);
          throw new IllegalArgumentException(stringBuilder.toString());
        case 9:
          this.a.b1(null);
          break;
        case 8:
          this.a.b1((Fragment)stringBuilder);
          break;
        case 7:
          stringBuilder.setNextAnim(a1.c);
          this.a.n((Fragment)stringBuilder);
          break;
        case 6:
          stringBuilder.setNextAnim(a1.d);
          this.a.t((Fragment)stringBuilder);
          break;
        case 5:
          stringBuilder.setNextAnim(a1.c);
          this.a.e1((Fragment)stringBuilder);
          break;
        case 4:
          stringBuilder.setNextAnim(a1.d);
          this.a.u0((Fragment)stringBuilder);
          break;
        case 3:
          stringBuilder.setNextAnim(a1.d);
          this.a.O0((Fragment)stringBuilder);
          break;
        case 1:
          stringBuilder.setNextAnim(a1.c);
          this.a.j((Fragment)stringBuilder, false);
          break;
      } 
      if (!this.t && a1.a != 1 && stringBuilder != null)
        this.a.E0((Fragment)stringBuilder); 
    } 
    if (!this.t) {
      h h1 = this.a;
      h1.F0(h1.m, true);
    } 
  }
  
  void o(boolean paramBoolean) {
    for (int i = this.b.size() - 1; i >= 0; i--) {
      StringBuilder stringBuilder;
      a a1 = this.b.get(i);
      Fragment fragment = a1.b;
      if (fragment != null)
        fragment.setNextTransition(h.T0(this.g), this.h); 
      switch (a1.a) {
        default:
          stringBuilder = new StringBuilder();
          stringBuilder.append("Unknown cmd: ");
          stringBuilder.append(a1.a);
          throw new IllegalArgumentException(stringBuilder.toString());
        case 9:
          this.a.b1((Fragment)stringBuilder);
          break;
        case 8:
          this.a.b1(null);
          break;
        case 7:
          stringBuilder.setNextAnim(a1.f);
          this.a.t((Fragment)stringBuilder);
          break;
        case 6:
          stringBuilder.setNextAnim(a1.e);
          this.a.n((Fragment)stringBuilder);
          break;
        case 5:
          stringBuilder.setNextAnim(a1.f);
          this.a.u0((Fragment)stringBuilder);
          break;
        case 4:
          stringBuilder.setNextAnim(a1.e);
          this.a.e1((Fragment)stringBuilder);
          break;
        case 3:
          stringBuilder.setNextAnim(a1.e);
          this.a.j((Fragment)stringBuilder, false);
          break;
        case 1:
          stringBuilder.setNextAnim(a1.f);
          this.a.O0((Fragment)stringBuilder);
          break;
      } 
      if (!this.t && a1.a != 3 && stringBuilder != null)
        this.a.E0((Fragment)stringBuilder); 
    } 
    if (!this.t && paramBoolean) {
      h h1 = this.a;
      h1.F0(h1.m, true);
    } 
  }
  
  Fragment p(ArrayList<Fragment> paramArrayList, Fragment paramFragment) {
    int i = 0;
    Fragment fragment;
    for (fragment = paramFragment; i < this.b.size(); fragment = paramFragment) {
      Fragment fragment1;
      a a1 = this.b.get(i);
      int k = a1.a;
      if (k != 1)
        if (k != 2) {
          if (k != 3 && k != 6) {
            if (k != 7) {
              if (k != 8) {
                paramFragment = fragment;
                k = i;
              } else {
                this.b.add(i, new a(9, fragment));
                k = i + 1;
                paramFragment = a1.b;
              } 
              continue;
            } 
          } else {
            paramArrayList.remove(a1.b);
            fragment1 = a1.b;
            paramFragment = fragment;
            k = i;
            if (fragment1 == fragment) {
              this.b.add(i, new a(9, fragment1));
              k = i + 1;
              paramFragment = null;
            } 
            continue;
          } 
        } else {
          Fragment fragment2 = ((a)fragment1).b;
          int n = fragment2.mContainerId;
          int m = paramArrayList.size() - 1;
          boolean bool = false;
          k = i;
          paramFragment = fragment;
          while (m >= 0) {
            Fragment fragment3 = paramArrayList.get(m);
            fragment = paramFragment;
            i = k;
            boolean bool1 = bool;
            if (fragment3.mContainerId == n)
              if (fragment3 == fragment2) {
                bool1 = true;
                fragment = paramFragment;
                i = k;
              } else {
                fragment = paramFragment;
                i = k;
                if (fragment3 == paramFragment) {
                  this.b.add(k, new a(9, fragment3));
                  i = k + 1;
                  fragment = null;
                } 
                a a2 = new a(3, fragment3);
                a2.c = ((a)fragment1).c;
                a2.e = ((a)fragment1).e;
                a2.d = ((a)fragment1).d;
                a2.f = ((a)fragment1).f;
                this.b.add(i, a2);
                paramArrayList.remove(fragment3);
                i++;
                bool1 = bool;
              }  
            m--;
            paramFragment = fragment;
            k = i;
            bool = bool1;
          } 
          if (bool) {
            this.b.remove(k);
            k--;
          } else {
            ((a)fragment1).a = 1;
            paramArrayList.add(fragment2);
          } 
          continue;
        }  
      paramArrayList.add(((a)fragment1).b);
      k = i;
      paramFragment = fragment;
      continue;
      i = SYNTHETIC_LOCAL_VARIABLE_3 + 1;
    } 
    return fragment;
  }
  
  public String q() {
    return this.k;
  }
  
  boolean r(int paramInt) {
    int k = this.b.size();
    for (int i = 0; i < k; i++) {
      int m;
      Fragment fragment = ((a)this.b.get(i)).b;
      if (fragment != null) {
        m = fragment.mContainerId;
      } else {
        m = 0;
      } 
      if (m && m == paramInt)
        return true; 
    } 
    return false;
  }
  
  boolean s(ArrayList<a> paramArrayList, int paramInt1, int paramInt2) {
    if (paramInt2 == paramInt1)
      return false; 
    int m = this.b.size();
    int k = -1;
    int i = 0;
    while (i < m) {
      int n;
      Fragment fragment = ((a)this.b.get(i)).b;
      if (fragment != null) {
        n = fragment.mContainerId;
      } else {
        n = 0;
      } 
      int i1 = k;
      if (n) {
        i1 = k;
        if (n != k) {
          for (k = paramInt1; k < paramInt2; k++) {
            a a1 = paramArrayList.get(k);
            int i2 = a1.b.size();
            for (i1 = 0; i1 < i2; i1++) {
              int i3;
              Fragment fragment1 = ((a)a1.b.get(i1)).b;
              if (fragment1 != null) {
                i3 = fragment1.mContainerId;
              } else {
                i3 = 0;
              } 
              if (i3 == n)
                return true; 
            } 
          } 
          i1 = n;
        } 
      } 
      i++;
      k = i1;
    } 
    return false;
  }
  
  public String toString() {
    StringBuilder stringBuilder = new StringBuilder(128);
    stringBuilder.append("BackStackEntry{");
    stringBuilder.append(Integer.toHexString(System.identityHashCode(this)));
    if (this.m >= 0) {
      stringBuilder.append(" #");
      stringBuilder.append(this.m);
    } 
    if (this.k != null) {
      stringBuilder.append(" ");
      stringBuilder.append(this.k);
    } 
    stringBuilder.append("}");
    return stringBuilder.toString();
  }
  
  boolean u() {
    for (int i = 0; i < this.b.size(); i++) {
      if (t(this.b.get(i)))
        return true; 
    } 
    return false;
  }
  
  public void v() {
    ArrayList<Runnable> arrayList = this.u;
    if (arrayList != null) {
      int i = 0;
      int k = arrayList.size();
      while (i < k) {
        ((Runnable)this.u.get(i)).run();
        i++;
      } 
      this.u = null;
    } 
  }
  
  void w(Fragment.f paramf) {
    for (int i = 0; i < this.b.size(); i++) {
      a a1 = this.b.get(i);
      if (t(a1))
        a1.b.setOnStartEnterTransitionListener(paramf); 
    } 
  }
  
  Fragment x(ArrayList<Fragment> paramArrayList, Fragment paramFragment) {
    int i = 0;
    while (i < this.b.size()) {
      a a1 = this.b.get(i);
      int k = a1.a;
      if (k != 1)
        if (k != 3) {
          switch (k) {
            case 9:
              paramFragment = a1.b;
              break;
            case 8:
              paramFragment = null;
              break;
            case 6:
              paramArrayList.add(a1.b);
              break;
            case 7:
              paramArrayList.remove(a1.b);
              break;
          } 
          i++;
        }  
    } 
    return paramFragment;
  }
  
  static final class a {
    int a;
    
    Fragment b;
    
    int c;
    
    int d;
    
    int e;
    
    int f;
    
    a() {}
    
    a(int param1Int, Fragment param1Fragment) {
      this.a = param1Int;
      this.b = param1Fragment;
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Hill race-dex2jar.jar!\androidx\fragment\app\a.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */