package androidx.fragment.app;

import android.graphics.Rect;
import android.view.View;
import android.view.ViewGroup;
import androidx.core.view.g;
import androidx.core.view.i;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

public abstract class m {
  protected static void d(List<View> paramList, View paramView) {
    int j = paramList.size();
    if (h(paramList, paramView, j))
      return; 
    paramList.add(paramView);
    for (int i = j; i < paramList.size(); i++) {
      paramView = paramList.get(i);
      if (paramView instanceof ViewGroup) {
        ViewGroup viewGroup = (ViewGroup)paramView;
        int n = viewGroup.getChildCount();
        for (int k = 0; k < n; k++) {
          View view = viewGroup.getChildAt(k);
          if (!h(paramList, view, j))
            paramList.add(view); 
        } 
      } 
    } 
  }
  
  private static boolean h(List<View> paramList, View paramView, int paramInt) {
    for (int i = 0; i < paramInt; i++) {
      if (paramList.get(i) == paramView)
        return true; 
    } 
    return false;
  }
  
  static String i(Map<String, String> paramMap, String paramString) {
    for (Map.Entry<String, String> entry : paramMap.entrySet()) {
      if (paramString.equals(entry.getValue()))
        return (String)entry.getKey(); 
    } 
    return null;
  }
  
  protected static boolean l(List paramList) {
    return (paramList == null || paramList.isEmpty());
  }
  
  public abstract Object A(Object paramObject);
  
  public abstract void a(Object paramObject, View paramView);
  
  public abstract void b(Object paramObject, ArrayList<View> paramArrayList);
  
  public abstract void c(ViewGroup paramViewGroup, Object paramObject);
  
  public abstract boolean e(Object paramObject);
  
  void f(ArrayList<View> paramArrayList, View paramView) {
    if (paramView.getVisibility() == 0) {
      ViewGroup viewGroup;
      if (paramView instanceof ViewGroup) {
        viewGroup = (ViewGroup)paramView;
        if (i.a(viewGroup)) {
          paramArrayList.add(viewGroup);
          return;
        } 
        int j = viewGroup.getChildCount();
        for (int i = 0; i < j; i++)
          f(paramArrayList, viewGroup.getChildAt(i)); 
      } else {
        paramArrayList.add(viewGroup);
      } 
    } 
  }
  
  public abstract Object g(Object paramObject);
  
  void j(Map<String, View> paramMap, View paramView) {
    if (paramView.getVisibility() == 0) {
      String str = g.g(paramView);
      if (str != null)
        paramMap.put(str, paramView); 
      if (paramView instanceof ViewGroup) {
        ViewGroup viewGroup = (ViewGroup)paramView;
        int j = viewGroup.getChildCount();
        for (int i = 0; i < j; i++)
          j(paramMap, viewGroup.getChildAt(i)); 
      } 
    } 
  }
  
  protected void k(View paramView, Rect paramRect) {
    int[] arrayOfInt = new int[2];
    paramView.getLocationOnScreen(arrayOfInt);
    paramRect.set(arrayOfInt[0], arrayOfInt[1], arrayOfInt[0] + paramView.getWidth(), arrayOfInt[1] + paramView.getHeight());
  }
  
  public abstract Object m(Object paramObject1, Object paramObject2, Object paramObject3);
  
  public abstract Object n(Object paramObject1, Object paramObject2, Object paramObject3);
  
  ArrayList<String> o(ArrayList<View> paramArrayList) {
    ArrayList<String> arrayList = new ArrayList();
    int j = paramArrayList.size();
    for (int i = 0; i < j; i++) {
      View view = paramArrayList.get(i);
      arrayList.add(g.g(view));
      g.o(view, null);
    } 
    return arrayList;
  }
  
  public abstract void p(Object paramObject, View paramView);
  
  public abstract void q(Object paramObject, ArrayList<View> paramArrayList1, ArrayList<View> paramArrayList2);
  
  public abstract void r(Object paramObject, View paramView, ArrayList<View> paramArrayList);
  
  void s(ViewGroup paramViewGroup, ArrayList<View> paramArrayList, Map<String, String> paramMap) {
    n.a((View)paramViewGroup, new c(this, paramArrayList, paramMap));
  }
  
  public abstract void t(Object paramObject1, Object paramObject2, ArrayList<View> paramArrayList1, Object paramObject3, ArrayList<View> paramArrayList2, Object paramObject4, ArrayList<View> paramArrayList3);
  
  public abstract void u(Object paramObject, Rect paramRect);
  
  public abstract void v(Object paramObject, View paramView);
  
  void w(View paramView, ArrayList<View> paramArrayList, Map<String, String> paramMap) {
    n.a(paramView, new b(this, paramArrayList, paramMap));
  }
  
  void x(View paramView, ArrayList<View> paramArrayList1, ArrayList<View> paramArrayList2, ArrayList<String> paramArrayList, Map<String, String> paramMap) {
    int j = paramArrayList2.size();
    ArrayList<String> arrayList = new ArrayList();
    int i;
    for (i = 0; i < j; i++) {
      View view = paramArrayList1.get(i);
      String str = g.g(view);
      arrayList.add(str);
      if (str != null) {
        g.o(view, null);
        String str1 = paramMap.get(str);
        int k;
        for (k = 0; k < j; k++) {
          if (str1.equals(paramArrayList.get(k))) {
            g.o(paramArrayList2.get(k), str);
            break;
          } 
        } 
      } 
    } 
    n.a(paramView, new a(this, j, paramArrayList2, paramArrayList, paramArrayList1, arrayList));
  }
  
  public abstract void y(Object paramObject, View paramView, ArrayList<View> paramArrayList);
  
  public abstract void z(Object paramObject, ArrayList<View> paramArrayList1, ArrayList<View> paramArrayList2);
  
  class a implements Runnable {
    a(m this$0, int param1Int, ArrayList param1ArrayList1, ArrayList param1ArrayList2, ArrayList param1ArrayList3, ArrayList param1ArrayList4) {}
    
    public void run() {
      for (int i = 0; i < this.b; i++) {
        g.o(this.c.get(i), this.d.get(i));
        g.o(this.e.get(i), this.f.get(i));
      } 
    }
  }
  
  class b implements Runnable {
    b(m this$0, ArrayList param1ArrayList, Map param1Map) {}
    
    public void run() {
      int j = this.b.size();
      for (int i = 0; i < j; i++) {
        View view = this.b.get(i);
        String str = g.g(view);
        if (str != null)
          g.o(view, m.i(this.c, str)); 
      } 
    }
  }
  
  class c implements Runnable {
    c(m this$0, ArrayList param1ArrayList, Map param1Map) {}
    
    public void run() {
      int j = this.b.size();
      for (int i = 0; i < j; i++) {
        View view = this.b.get(i);
        String str = g.g(view);
        g.o(view, (String)this.c.get(str));
      } 
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Hill race-dex2jar.jar!\androidx\fragment\app\m.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */