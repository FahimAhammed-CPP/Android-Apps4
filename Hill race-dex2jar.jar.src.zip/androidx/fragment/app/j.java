package androidx.fragment.app;

public abstract class j {
  public abstract j b(Fragment paramFragment, String paramString);
  
  public abstract int c();
  
  public abstract int d();
  
  public abstract void e();
  
  public abstract j f(Fragment paramFragment);
}


/* Location:              C:\soft\dex2jar-2.0\Hill race-dex2jar.jar!\androidx\fragment\app\j.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */