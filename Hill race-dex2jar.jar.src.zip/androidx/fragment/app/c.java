package androidx.fragment.app;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.content.IntentSender;
import android.content.res.Configuration;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.os.Parcelable;
import android.util.AttributeSet;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.view.Window;
import androidx.collection.g;
import androidx.core.app.a;
import androidx.core.app.d;
import androidx.lifecycle.f;
import androidx.lifecycle.j;
import androidx.lifecycle.x;
import androidx.lifecycle.y;
import java.io.FileDescriptor;
import java.io.PrintWriter;
import java.util.Iterator;

public class c extends d implements y, a.d, a.f {
  final Handler d = new a(this);
  
  final e e = e.b(new b(this));
  
  private x f;
  
  boolean g;
  
  boolean h;
  
  boolean i = true;
  
  boolean j;
  
  boolean k;
  
  boolean l;
  
  int m;
  
  g<String> n;
  
  private int c(Fragment paramFragment) {
    if (this.n.k() < 65534) {
      while (this.n.g(this.m) >= 0)
        this.m = (this.m + 1) % 65534; 
      int i = this.m;
      this.n.i(i, paramFragment.mWho);
      this.m = (this.m + 1) % 65534;
      return i;
    } 
    throw new IllegalStateException("Too many pending Fragment activity results.");
  }
  
  static void d(int paramInt) {
    if ((paramInt & 0xFFFF0000) == 0)
      return; 
    throw new IllegalArgumentException("Can only use lower 16 bits for requestCode");
  }
  
  private void g() {
    do {
    
    } while (h(f(), f.c.d));
  }
  
  private static boolean h(g paramg, f.c paramc) {
    Iterator<Fragment> iterator = paramg.d().iterator();
    boolean bool = false;
    while (iterator.hasNext()) {
      Fragment fragment = iterator.next();
      if (fragment == null)
        continue; 
      boolean bool1 = bool;
      if (fragment.getLifecycle().b().a(f.c.e)) {
        fragment.mLifecycleRegistry.j(paramc);
        bool1 = true;
      } 
      g g1 = fragment.peekChildFragmentManager();
      bool = bool1;
      if (g1 != null)
        bool = bool1 | h(g1, paramc); 
    } 
    return bool;
  }
  
  public final void a(int paramInt) {
    if (!this.j && paramInt != -1)
      d(paramInt); 
  }
  
  public void dump(String paramString, FileDescriptor paramFileDescriptor, PrintWriter paramPrintWriter, String[] paramArrayOfString) {
    super.dump(paramString, paramFileDescriptor, paramPrintWriter, paramArrayOfString);
    paramPrintWriter.print(paramString);
    paramPrintWriter.print("Local FragmentActivity ");
    paramPrintWriter.print(Integer.toHexString(System.identityHashCode(this)));
    paramPrintWriter.println(" State:");
    StringBuilder stringBuilder = new StringBuilder();
    stringBuilder.append(paramString);
    stringBuilder.append("  ");
    String str = stringBuilder.toString();
    paramPrintWriter.print(str);
    paramPrintWriter.print("mCreated=");
    paramPrintWriter.print(this.g);
    paramPrintWriter.print(" mResumed=");
    paramPrintWriter.print(this.h);
    paramPrintWriter.print(" mStopped=");
    paramPrintWriter.print(this.i);
    if (getApplication() != null)
      androidx.loader.app.a.b((j)this).a(str, paramFileDescriptor, paramPrintWriter, paramArrayOfString); 
    this.e.u().b(paramString, paramFileDescriptor, paramPrintWriter, paramArrayOfString);
  }
  
  final View e(View paramView, String paramString, Context paramContext, AttributeSet paramAttributeSet) {
    return this.e.w(paramView, paramString, paramContext, paramAttributeSet);
  }
  
  public g f() {
    return this.e.u();
  }
  
  public f getLifecycle() {
    return super.getLifecycle();
  }
  
  public x getViewModelStore() {
    if (getApplication() != null) {
      if (this.f == null) {
        c c1 = (c)getLastNonConfigurationInstance();
        if (c1 != null)
          this.f = c1.b; 
        if (this.f == null)
          this.f = new x(); 
      } 
      return this.f;
    } 
    throw new IllegalStateException("Your activity is not yet attached to the Application instance. You can't request ViewModel before onCreate call.");
  }
  
  public void i(Fragment paramFragment) {}
  
  protected boolean j(View paramView, Menu paramMenu) {
    return super.onPreparePanel(0, paramView, paramMenu);
  }
  
  protected void k() {
    this.e.p();
  }
  
  public Object l() {
    return null;
  }
  
  void m(Fragment paramFragment, String[] paramArrayOfString, int paramInt) {
    if (paramInt == -1) {
      a.b((Activity)this, paramArrayOfString, paramInt);
      return;
    } 
    d(paramInt);
    try {
      this.j = true;
      a.b((Activity)this, paramArrayOfString, (c(paramFragment) + 1 << 16) + (paramInt & 0xFFFF));
      return;
    } finally {
      this.j = false;
    } 
  }
  
  public void n(Fragment paramFragment, Intent paramIntent, int paramInt, Bundle paramBundle) {
    this.l = true;
    if (paramInt == -1)
      try {
        a.d((Activity)this, paramIntent, -1, paramBundle);
        return;
      } finally {
        this.l = false;
      }  
    d(paramInt);
    a.d((Activity)this, paramIntent, (c(paramFragment) + 1 << 16) + (paramInt & 0xFFFF), paramBundle);
    this.l = false;
  }
  
  public void o(Fragment paramFragment, IntentSender paramIntentSender, int paramInt1, Intent paramIntent, int paramInt2, int paramInt3, int paramInt4, Bundle paramBundle) throws IntentSender.SendIntentException {
    this.k = true;
    if (paramInt1 == -1)
      try {
        a.e((Activity)this, paramIntentSender, paramInt1, paramIntent, paramInt2, paramInt3, paramInt4, paramBundle);
        return;
      } finally {
        this.k = false;
      }  
    d(paramInt1);
    a.e((Activity)this, paramIntentSender, (c(paramFragment) + 1 << 16) + (paramInt1 & 0xFFFF), paramIntent, paramInt2, paramInt3, paramInt4, paramBundle);
    this.k = false;
  }
  
  protected void onActivityResult(int paramInt1, int paramInt2, Intent paramIntent) {
    StringBuilder stringBuilder;
    this.e.v();
    int i = paramInt1 >> 16;
    if (i != 0) {
      String str = (String)this.n.e(--i);
      this.n.j(i);
      if (str == null) {
        Log.w("FragmentActivity", "Activity result delivered for unknown Fragment.");
        return;
      } 
      Fragment fragment = this.e.t(str);
      if (fragment == null) {
        stringBuilder = new StringBuilder();
        stringBuilder.append("Activity result no fragment exists for who: ");
        stringBuilder.append(str);
        Log.w("FragmentActivity", stringBuilder.toString());
        return;
      } 
      fragment.onActivityResult(paramInt1 & 0xFFFF, paramInt2, (Intent)stringBuilder);
      return;
    } 
    a.e e1 = a.a();
    if (e1 != null && e1.onActivityResult((Activity)this, paramInt1, paramInt2, (Intent)stringBuilder))
      return; 
    super.onActivityResult(paramInt1, paramInt2, (Intent)stringBuilder);
  }
  
  public void onBackPressed() {
    g g1 = this.e.u();
    boolean bool = g1.e();
    if (bool && Build.VERSION.SDK_INT <= 25)
      return; 
    if (bool || !g1.g())
      super.onBackPressed(); 
  }
  
  public void onConfigurationChanged(Configuration paramConfiguration) {
    super.onConfigurationChanged(paramConfiguration);
    this.e.v();
    this.e.d(paramConfiguration);
  }
  
  protected void onCreate(Bundle paramBundle) {
    e e1 = this.e;
    i i = null;
    e1.a(null);
    super.onCreate(paramBundle);
    c c1 = (c)getLastNonConfigurationInstance();
    if (c1 != null) {
      x x1 = c1.b;
      if (x1 != null && this.f == null)
        this.f = x1; 
    } 
    if (paramBundle != null) {
      Parcelable parcelable = paramBundle.getParcelable("android:support:fragments");
      e e2 = this.e;
      if (c1 != null)
        i = c1.c; 
      e2.x(parcelable, i);
      if (paramBundle.containsKey("android:support:next_request_index")) {
        this.m = paramBundle.getInt("android:support:next_request_index");
        int[] arrayOfInt = paramBundle.getIntArray("android:support:request_indicies");
        String[] arrayOfString = paramBundle.getStringArray("android:support:request_fragment_who");
        if (arrayOfInt == null || arrayOfString == null || arrayOfInt.length != arrayOfString.length) {
          Log.w("FragmentActivity", "Invalid requestCode mapping in savedInstanceState.");
        } else {
          this.n = new g(arrayOfInt.length);
          for (int j = 0; j < arrayOfInt.length; j++)
            this.n.i(arrayOfInt[j], arrayOfString[j]); 
        } 
      } 
    } 
    if (this.n == null) {
      this.n = new g();
      this.m = 0;
    } 
    this.e.f();
  }
  
  public boolean onCreatePanelMenu(int paramInt, Menu paramMenu) {
    return (paramInt == 0) ? (super.onCreatePanelMenu(paramInt, paramMenu) | this.e.g(paramMenu, getMenuInflater())) : super.onCreatePanelMenu(paramInt, paramMenu);
  }
  
  public View onCreateView(View paramView, String paramString, Context paramContext, AttributeSet paramAttributeSet) {
    View view = e(paramView, paramString, paramContext, paramAttributeSet);
    return (view == null) ? super.onCreateView(paramView, paramString, paramContext, paramAttributeSet) : view;
  }
  
  public View onCreateView(String paramString, Context paramContext, AttributeSet paramAttributeSet) {
    View view = e(null, paramString, paramContext, paramAttributeSet);
    return (view == null) ? super.onCreateView(paramString, paramContext, paramAttributeSet) : view;
  }
  
  protected void onDestroy() {
    super.onDestroy();
    if (this.f != null && !isChangingConfigurations())
      this.f.a(); 
    this.e.h();
  }
  
  public void onLowMemory() {
    super.onLowMemory();
    this.e.i();
  }
  
  public boolean onMenuItemSelected(int paramInt, MenuItem paramMenuItem) {
    return super.onMenuItemSelected(paramInt, paramMenuItem) ? true : ((paramInt != 0) ? ((paramInt != 6) ? false : this.e.e(paramMenuItem)) : this.e.k(paramMenuItem));
  }
  
  public void onMultiWindowModeChanged(boolean paramBoolean) {
    this.e.j(paramBoolean);
  }
  
  protected void onNewIntent(Intent paramIntent) {
    super.onNewIntent(paramIntent);
    this.e.v();
  }
  
  public void onPanelClosed(int paramInt, Menu paramMenu) {
    if (paramInt == 0)
      this.e.l(paramMenu); 
    super.onPanelClosed(paramInt, paramMenu);
  }
  
  protected void onPause() {
    super.onPause();
    this.h = false;
    if (this.d.hasMessages(2)) {
      this.d.removeMessages(2);
      k();
    } 
    this.e.m();
  }
  
  public void onPictureInPictureModeChanged(boolean paramBoolean) {
    this.e.n(paramBoolean);
  }
  
  protected void onPostResume() {
    super.onPostResume();
    this.d.removeMessages(2);
    k();
    this.e.s();
  }
  
  public boolean onPreparePanel(int paramInt, View paramView, Menu paramMenu) {
    return (paramInt == 0 && paramMenu != null) ? (j(paramView, paramMenu) | this.e.o(paramMenu)) : super.onPreparePanel(paramInt, paramView, paramMenu);
  }
  
  public void onRequestPermissionsResult(int paramInt, String[] paramArrayOfString, int[] paramArrayOfint) {
    this.e.v();
    int i = paramInt >> 16 & 0xFFFF;
    if (i != 0) {
      StringBuilder stringBuilder;
      String str = (String)this.n.e(--i);
      this.n.j(i);
      if (str == null) {
        Log.w("FragmentActivity", "Activity result delivered for unknown Fragment.");
        return;
      } 
      Fragment fragment = this.e.t(str);
      if (fragment == null) {
        stringBuilder = new StringBuilder();
        stringBuilder.append("Activity result no fragment exists for who: ");
        stringBuilder.append(str);
        Log.w("FragmentActivity", stringBuilder.toString());
        return;
      } 
      fragment.onRequestPermissionsResult(paramInt & 0xFFFF, (String[])stringBuilder, paramArrayOfint);
    } 
  }
  
  protected void onResume() {
    super.onResume();
    this.d.sendEmptyMessage(2);
    this.h = true;
    this.e.s();
  }
  
  public final Object onRetainNonConfigurationInstance() {
    Object object = l();
    i i = this.e.y();
    if (i == null && this.f == null && object == null)
      return null; 
    c c1 = new c();
    c1.a = object;
    c1.b = this.f;
    c1.c = i;
    return c1;
  }
  
  protected void onSaveInstanceState(Bundle paramBundle) {
    super.onSaveInstanceState(paramBundle);
    g();
    Parcelable parcelable = this.e.z();
    if (parcelable != null)
      paramBundle.putParcelable("android:support:fragments", parcelable); 
    if (this.n.k() > 0) {
      paramBundle.putInt("android:support:next_request_index", this.m);
      int[] arrayOfInt = new int[this.n.k()];
      String[] arrayOfString = new String[this.n.k()];
      for (int i = 0; i < this.n.k(); i++) {
        arrayOfInt[i] = this.n.h(i);
        arrayOfString[i] = (String)this.n.l(i);
      } 
      paramBundle.putIntArray("android:support:request_indicies", arrayOfInt);
      paramBundle.putStringArray("android:support:request_fragment_who", arrayOfString);
    } 
  }
  
  protected void onStart() {
    super.onStart();
    this.i = false;
    if (!this.g) {
      this.g = true;
      this.e.c();
    } 
    this.e.v();
    this.e.s();
    this.e.q();
  }
  
  public void onStateNotSaved() {
    this.e.v();
  }
  
  protected void onStop() {
    super.onStop();
    this.i = true;
    g();
    this.e.r();
  }
  
  @Deprecated
  public void p() {
    invalidateOptionsMenu();
  }
  
  public void startActivityForResult(Intent paramIntent, int paramInt) {
    if (!this.l && paramInt != -1)
      d(paramInt); 
    super.startActivityForResult(paramIntent, paramInt);
  }
  
  public void startActivityForResult(Intent paramIntent, int paramInt, Bundle paramBundle) {
    if (!this.l && paramInt != -1)
      d(paramInt); 
    super.startActivityForResult(paramIntent, paramInt, paramBundle);
  }
  
  public void startIntentSenderForResult(IntentSender paramIntentSender, int paramInt1, Intent paramIntent, int paramInt2, int paramInt3, int paramInt4) throws IntentSender.SendIntentException {
    if (!this.k && paramInt1 != -1)
      d(paramInt1); 
    super.startIntentSenderForResult(paramIntentSender, paramInt1, paramIntent, paramInt2, paramInt3, paramInt4);
  }
  
  public void startIntentSenderForResult(IntentSender paramIntentSender, int paramInt1, Intent paramIntent, int paramInt2, int paramInt3, int paramInt4, Bundle paramBundle) throws IntentSender.SendIntentException {
    if (!this.k && paramInt1 != -1)
      d(paramInt1); 
    super.startIntentSenderForResult(paramIntentSender, paramInt1, paramIntent, paramInt2, paramInt3, paramInt4, paramBundle);
  }
  
  class a extends Handler {
    a(c this$0) {}
    
    public void handleMessage(Message param1Message) {
      if (param1Message.what != 2) {
        super.handleMessage(param1Message);
        return;
      } 
      this.a.k();
      this.a.e.s();
    }
  }
  
  class b extends f<c> {
    public b(c this$0) {
      super(this$0);
    }
    
    public View b(int param1Int) {
      return this.f.findViewById(param1Int);
    }
    
    public boolean c() {
      Window window = this.f.getWindow();
      return (window != null && window.peekDecorView() != null);
    }
    
    public void h(Fragment param1Fragment) {
      this.f.i(param1Fragment);
    }
    
    public void i(String param1String, FileDescriptor param1FileDescriptor, PrintWriter param1PrintWriter, String[] param1ArrayOfString) {
      this.f.dump(param1String, param1FileDescriptor, param1PrintWriter, param1ArrayOfString);
    }
    
    public LayoutInflater k() {
      return this.f.getLayoutInflater().cloneInContext((Context)this.f);
    }
    
    public int l() {
      Window window = this.f.getWindow();
      return (window == null) ? 0 : (window.getAttributes()).windowAnimations;
    }
    
    public boolean m() {
      return (this.f.getWindow() != null);
    }
    
    public void n(Fragment param1Fragment, String[] param1ArrayOfString, int param1Int) {
      this.f.m(param1Fragment, param1ArrayOfString, param1Int);
    }
    
    public boolean o(Fragment param1Fragment) {
      return this.f.isFinishing() ^ true;
    }
    
    public boolean p(String param1String) {
      return a.c((Activity)this.f, param1String);
    }
    
    public void q(Fragment param1Fragment, Intent param1Intent, int param1Int, Bundle param1Bundle) {
      this.f.n(param1Fragment, param1Intent, param1Int, param1Bundle);
    }
    
    public void r(Fragment param1Fragment, IntentSender param1IntentSender, int param1Int1, Intent param1Intent, int param1Int2, int param1Int3, int param1Int4, Bundle param1Bundle) throws IntentSender.SendIntentException {
      this.f.o(param1Fragment, param1IntentSender, param1Int1, param1Intent, param1Int2, param1Int3, param1Int4, param1Bundle);
    }
    
    public void s() {
      this.f.p();
    }
    
    public c t() {
      return this.f;
    }
  }
  
  static final class c {
    Object a;
    
    x b;
    
    i c;
  }
}


/* Location:              C:\soft\dex2jar-2.0\Hill race-dex2jar.jar!\androidx\fragment\app\c.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */