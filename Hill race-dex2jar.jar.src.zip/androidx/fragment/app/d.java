package androidx.fragment.app;

import android.content.Context;
import android.os.Bundle;
import android.view.View;

public abstract class d {
  public Fragment a(Context paramContext, String paramString, Bundle paramBundle) {
    return Fragment.instantiate(paramContext, paramString, paramBundle);
  }
  
  public abstract View b(int paramInt);
  
  public abstract boolean c();
}


/* Location:              C:\soft\dex2jar-2.0\Hill race-dex2jar.jar!\androidx\fragment\app\d.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */