package androidx.fragment.app;

import android.content.Context;
import android.content.res.Configuration;
import android.os.Parcelable;
import android.util.AttributeSet;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;

public class e {
  private final f<?> a;
  
  private e(f<?> paramf) {
    this.a = paramf;
  }
  
  public static e b(f<?> paramf) {
    return new e(paramf);
  }
  
  public void a(Fragment paramFragment) {
    f<?> f1 = this.a;
    f1.e.m(f1, f1, paramFragment);
  }
  
  public void c() {
    this.a.e.u();
  }
  
  public void d(Configuration paramConfiguration) {
    this.a.e.v(paramConfiguration);
  }
  
  public boolean e(MenuItem paramMenuItem) {
    return this.a.e.w(paramMenuItem);
  }
  
  public void f() {
    this.a.e.x();
  }
  
  public boolean g(Menu paramMenu, MenuInflater paramMenuInflater) {
    return this.a.e.y(paramMenu, paramMenuInflater);
  }
  
  public void h() {
    this.a.e.z();
  }
  
  public void i() {
    this.a.e.B();
  }
  
  public void j(boolean paramBoolean) {
    this.a.e.C(paramBoolean);
  }
  
  public boolean k(MenuItem paramMenuItem) {
    return this.a.e.R(paramMenuItem);
  }
  
  public void l(Menu paramMenu) {
    this.a.e.S(paramMenu);
  }
  
  public void m() {
    this.a.e.T();
  }
  
  public void n(boolean paramBoolean) {
    this.a.e.U(paramBoolean);
  }
  
  public boolean o(Menu paramMenu) {
    return this.a.e.V(paramMenu);
  }
  
  public void p() {
    this.a.e.W();
  }
  
  public void q() {
    this.a.e.X();
  }
  
  public void r() {
    this.a.e.Z();
  }
  
  public boolean s() {
    return this.a.e.f0();
  }
  
  public Fragment t(String paramString) {
    return this.a.e.l0(paramString);
  }
  
  public g u() {
    return this.a.f();
  }
  
  public void v() {
    this.a.e.I0();
  }
  
  public View w(View paramView, String paramString, Context paramContext, AttributeSet paramAttributeSet) {
    return this.a.e.onCreateView(paramView, paramString, paramContext, paramAttributeSet);
  }
  
  public void x(Parcelable paramParcelable, i parami) {
    this.a.e.R0(paramParcelable, parami);
  }
  
  public i y() {
    return this.a.e.S0();
  }
  
  public Parcelable z() {
    return this.a.e.U0();
  }
}


/* Location:              C:\soft\dex2jar-2.0\Hill race-dex2jar.jar!\androidx\fragment\app\e.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */