package androidx.fragment.app;

import android.os.Parcel;
import android.os.Parcelable;

final class FragmentManagerState implements Parcelable {
  public static final Parcelable.Creator<FragmentManagerState> CREATOR = new a();
  
  FragmentState[] b;
  
  int[] c;
  
  BackStackState[] d;
  
  int e = -1;
  
  int f;
  
  public FragmentManagerState() {}
  
  public FragmentManagerState(Parcel paramParcel) {
    this.b = (FragmentState[])paramParcel.createTypedArray(FragmentState.CREATOR);
    this.c = paramParcel.createIntArray();
    this.d = (BackStackState[])paramParcel.createTypedArray(BackStackState.CREATOR);
    this.e = paramParcel.readInt();
    this.f = paramParcel.readInt();
  }
  
  public int describeContents() {
    return 0;
  }
  
  public void writeToParcel(Parcel paramParcel, int paramInt) {
    paramParcel.writeTypedArray((Parcelable[])this.b, paramInt);
    paramParcel.writeIntArray(this.c);
    paramParcel.writeTypedArray((Parcelable[])this.d, paramInt);
    paramParcel.writeInt(this.e);
    paramParcel.writeInt(this.f);
  }
  
  static final class a implements Parcelable.Creator<FragmentManagerState> {
    public FragmentManagerState a(Parcel param1Parcel) {
      return new FragmentManagerState(param1Parcel);
    }
    
    public FragmentManagerState[] b(int param1Int) {
      return new FragmentManagerState[param1Int];
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Hill race-dex2jar.jar!\androidx\fragment\app\FragmentManagerState.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */