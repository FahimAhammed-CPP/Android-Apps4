package androidx.fragment.app;

import android.animation.Animator;
import android.animation.AnimatorInflater;
import android.animation.AnimatorListenerAdapter;
import android.animation.AnimatorSet;
import android.animation.PropertyValuesHolder;
import android.animation.ValueAnimator;
import android.content.Context;
import android.content.res.Configuration;
import android.content.res.Resources;
import android.content.res.TypedArray;
import android.os.Build;
import android.os.Bundle;
import android.os.Looper;
import android.os.Parcelable;
import android.util.AttributeSet;
import android.util.Log;
import android.util.SparseArray;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.view.animation.AccelerateInterpolator;
import android.view.animation.AlphaAnimation;
import android.view.animation.Animation;
import android.view.animation.AnimationSet;
import android.view.animation.AnimationUtils;
import android.view.animation.DecelerateInterpolator;
import android.view.animation.Interpolator;
import android.view.animation.ScaleAnimation;
import android.view.animation.Transformation;
import java.io.FileDescriptor;
import java.io.PrintWriter;
import java.io.Writer;
import java.lang.reflect.Field;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Iterator;
import java.util.List;
import java.util.concurrent.CopyOnWriteArrayList;

final class h extends g implements LayoutInflater.Factory2 {
  static boolean F = false;
  
  static Field G;
  
  static final Interpolator H = (Interpolator)new DecelerateInterpolator(2.5F);
  
  static final Interpolator I = (Interpolator)new DecelerateInterpolator(1.5F);
  
  static final Interpolator J = (Interpolator)new AccelerateInterpolator(2.5F);
  
  static final Interpolator K = (Interpolator)new AccelerateInterpolator(1.5F);
  
  Bundle A = null;
  
  SparseArray<Parcelable> B = null;
  
  ArrayList<n> C;
  
  i D;
  
  Runnable E = new a(this);
  
  ArrayList<l> b;
  
  boolean c;
  
  int d = 0;
  
  final ArrayList<Fragment> e = new ArrayList<Fragment>();
  
  SparseArray<Fragment> f;
  
  ArrayList<a> g;
  
  ArrayList<Fragment> h;
  
  ArrayList<a> i;
  
  ArrayList<Integer> j;
  
  ArrayList<g.b> k;
  
  private final CopyOnWriteArrayList<j> l = new CopyOnWriteArrayList<j>();
  
  int m = 0;
  
  f n;
  
  d o;
  
  Fragment p;
  
  Fragment q;
  
  boolean r;
  
  boolean s;
  
  boolean t;
  
  boolean u;
  
  String v;
  
  boolean w;
  
  ArrayList<a> x;
  
  ArrayList<Boolean> y;
  
  ArrayList<Fragment> z;
  
  static g A0(Context paramContext, float paramFloat1, float paramFloat2, float paramFloat3, float paramFloat4) {
    AnimationSet animationSet = new AnimationSet(false);
    ScaleAnimation scaleAnimation = new ScaleAnimation(paramFloat1, paramFloat2, paramFloat1, paramFloat2, 1, 0.5F, 1, 0.5F);
    scaleAnimation.setInterpolator(H);
    scaleAnimation.setDuration(220L);
    animationSet.addAnimation((Animation)scaleAnimation);
    AlphaAnimation alphaAnimation = new AlphaAnimation(paramFloat3, paramFloat4);
    alphaAnimation.setInterpolator(I);
    alphaAnimation.setDuration(220L);
    animationSet.addAnimation((Animation)alphaAnimation);
    return new g((Animation)animationSet);
  }
  
  private void B0(androidx.collection.b<Fragment> paramb) {
    int k = paramb.size();
    for (int j = 0; j < k; j++) {
      Fragment fragment = (Fragment)paramb.i(j);
      if (!fragment.mAdded) {
        View view = fragment.getView();
        fragment.mPostponedAlpha = view.getAlpha();
        view.setAlpha(0.0F);
      } 
    } 
  }
  
  static boolean C0(Animator paramAnimator) {
    PropertyValuesHolder[] arrayOfPropertyValuesHolder;
    if (paramAnimator == null)
      return false; 
    if (paramAnimator instanceof ValueAnimator) {
      arrayOfPropertyValuesHolder = ((ValueAnimator)paramAnimator).getValues();
      for (int j = 0; j < arrayOfPropertyValuesHolder.length; j++) {
        if ("alpha".equals(arrayOfPropertyValuesHolder[j].getPropertyName()))
          return true; 
      } 
    } else if (arrayOfPropertyValuesHolder instanceof AnimatorSet) {
      ArrayList<Animator> arrayList = ((AnimatorSet)arrayOfPropertyValuesHolder).getChildAnimations();
      for (int j = 0; j < arrayList.size(); j++) {
        if (C0(arrayList.get(j)))
          return true; 
      } 
    } 
    return false;
  }
  
  static boolean D0(g paramg) {
    List list;
    Animation animation = paramg.a;
    if (animation instanceof AlphaAnimation)
      return true; 
    if (animation instanceof AnimationSet) {
      list = ((AnimationSet)animation).getAnimations();
      for (int j = 0; j < list.size(); j++) {
        if (list.get(j) instanceof AlphaAnimation)
          return true; 
      } 
      return false;
    } 
    return C0(((g)list).b);
  }
  
  private boolean K0(String paramString, int paramInt1, int paramInt2) {
    f0();
    d0(true);
    Fragment fragment = this.q;
    if (fragment != null && paramInt1 < 0 && paramString == null) {
      g g1 = fragment.peekChildFragmentManager();
      if (g1 != null && g1.g())
        return true; 
    } 
    boolean bool = L0(this.x, this.y, paramString, paramInt1, paramInt2);
    if (bool) {
      this.c = true;
      try {
        P0(this.x, this.y);
      } finally {
        q();
      } 
    } 
    a0();
    o();
    return bool;
  }
  
  private int M0(ArrayList<a> paramArrayList, ArrayList<Boolean> paramArrayList1, int paramInt1, int paramInt2, androidx.collection.b<Fragment> paramb) {
    int j = paramInt2 - 1;
    int k;
    for (k = paramInt2; j >= paramInt1; k = m) {
      boolean bool;
      a a = paramArrayList.get(j);
      boolean bool1 = ((Boolean)paramArrayList1.get(j)).booleanValue();
      if (a.u() && !a.s(paramArrayList, j + 1, paramInt2)) {
        bool = true;
      } else {
        bool = false;
      } 
      int m = k;
      if (bool) {
        if (this.C == null)
          this.C = new ArrayList<n>(); 
        n n = new n(a, bool1);
        this.C.add(n);
        a.w(n);
        if (bool1) {
          a.n();
        } else {
          a.o(false);
        } 
        m = k - 1;
        if (j != m) {
          paramArrayList.remove(j);
          paramArrayList.add(m, a);
        } 
        h(paramb);
      } 
      j--;
    } 
    return k;
  }
  
  private void P0(ArrayList<a> paramArrayList, ArrayList<Boolean> paramArrayList1) {
    if (paramArrayList != null) {
      if (paramArrayList.isEmpty())
        return; 
      if (paramArrayList1 != null && paramArrayList.size() == paramArrayList1.size()) {
        j0(paramArrayList, paramArrayList1);
        int m = paramArrayList.size();
        int j = 0;
        int k;
        for (k = 0; j < m; k = n) {
          int i1 = j;
          int n = k;
          if (!((a)paramArrayList.get(j)).t) {
            if (k != j)
              i0(paramArrayList, paramArrayList1, k, j); 
            k = j + 1;
            n = k;
            if (((Boolean)paramArrayList1.get(j)).booleanValue())
              while (true) {
                n = k;
                if (k < m) {
                  n = k;
                  if (((Boolean)paramArrayList1.get(k)).booleanValue()) {
                    n = k;
                    if (!((a)paramArrayList.get(k)).t) {
                      k++;
                      continue;
                    } 
                  } 
                } 
                break;
              }  
            i0(paramArrayList, paramArrayList1, j, n);
            i1 = n - 1;
          } 
          j = i1 + 1;
        } 
        if (k != m)
          i0(paramArrayList, paramArrayList1, k, m); 
        return;
      } 
      throw new IllegalStateException("Internal error with the back stack records");
    } 
  }
  
  public static int T0(int paramInt) {
    char c = ' ';
    if (paramInt != 4097) {
      if (paramInt != 4099)
        return (paramInt != 8194) ? 0 : 4097; 
      c = 'ဃ';
    } 
    return c;
  }
  
  private void Y(int paramInt) {
    try {
      this.c = true;
      F0(paramInt, false);
      this.c = false;
      return;
    } finally {
      this.c = false;
    } 
  }
  
  private static void a1(View paramView, g paramg) {
    if (paramView != null) {
      if (paramg == null)
        return; 
      if (d1(paramView, paramg)) {
        Animator animator = paramg.b;
        if (animator != null) {
          animator.addListener((Animator.AnimatorListener)new h(paramView));
          return;
        } 
        Animation.AnimationListener animationListener = q0(paramg.a);
        paramView.setLayerType(2, null);
        paramg.a.setAnimationListener(new e(paramView, animationListener));
      } 
    } 
  }
  
  private void b0() {
    int j;
    SparseArray<Fragment> sparseArray = this.f;
    int k = 0;
    if (sparseArray == null) {
      j = 0;
    } else {
      j = sparseArray.size();
    } 
    while (k < j) {
      Fragment fragment = (Fragment)this.f.valueAt(k);
      if (fragment != null)
        if (fragment.getAnimatingAway() != null) {
          int m = fragment.getStateAfterAnimating();
          View view = fragment.getAnimatingAway();
          Animation animation = view.getAnimation();
          if (animation != null) {
            animation.cancel();
            view.clearAnimation();
          } 
          fragment.setAnimatingAway(null);
          H0(fragment, m, 0, 0, false);
        } else if (fragment.getAnimator() != null) {
          fragment.getAnimator().end();
        }  
      k++;
    } 
  }
  
  private static void c1(i parami) {
    if (parami == null)
      return; 
    List<Fragment> list1 = parami.b();
    if (list1 != null) {
      Iterator<Fragment> iterator = list1.iterator();
      while (iterator.hasNext())
        ((Fragment)iterator.next()).mRetaining = true; 
    } 
    List<i> list = parami.a();
    if (list != null) {
      Iterator<i> iterator = list.iterator();
      while (iterator.hasNext())
        c1(iterator.next()); 
    } 
  }
  
  private void d0(boolean paramBoolean) {
    if (!this.c) {
      if (this.n != null) {
        if (Looper.myLooper() == this.n.g().getLooper()) {
          if (!paramBoolean)
            p(); 
          if (this.x == null) {
            this.x = new ArrayList<a>();
            this.y = new ArrayList<Boolean>();
          } 
          this.c = true;
          try {
            j0(null, null);
            return;
          } finally {
            this.c = false;
          } 
        } 
        throw new IllegalStateException("Must be called from main thread of fragment host");
      } 
      throw new IllegalStateException("Fragment host has been destroyed");
    } 
    throw new IllegalStateException("FragmentManager is already executing transactions");
  }
  
  static boolean d1(View paramView, g paramg) {
    boolean bool2 = false;
    boolean bool1 = bool2;
    if (paramView != null) {
      if (paramg == null)
        return false; 
      bool1 = bool2;
      if (Build.VERSION.SDK_INT >= 19) {
        bool1 = bool2;
        if (paramView.getLayerType() == 0) {
          bool1 = bool2;
          if (androidx.core.view.g.h(paramView)) {
            bool1 = bool2;
            if (D0(paramg))
              bool1 = true; 
          } 
        } 
      } 
    } 
    return bool1;
  }
  
  private void g1(RuntimeException paramRuntimeException) {
    Log.e("FragmentManager", paramRuntimeException.getMessage());
    Log.e("FragmentManager", "Activity state:");
    PrintWriter printWriter = new PrintWriter((Writer)new androidx.core.util.c("FragmentManager"));
    f f1 = this.n;
    if (f1 != null) {
      try {
        f1.i("  ", null, printWriter, new String[0]);
      } catch (Exception exception) {
        Log.e("FragmentManager", "Failed dumping state", exception);
      } 
    } else {
      try {
        b("  ", null, (PrintWriter)exception, new String[0]);
      } catch (Exception exception1) {
        Log.e("FragmentManager", "Failed dumping state", exception1);
      } 
    } 
    throw paramRuntimeException;
  }
  
  private void h(androidx.collection.b<Fragment> paramb) {
    int j = this.m;
    if (j < 1)
      return; 
    int k = Math.min(j, 3);
    int m = this.e.size();
    for (j = 0; j < m; j++) {
      Fragment fragment = this.e.get(j);
      if (fragment.mState < k) {
        H0(fragment, k, fragment.getNextAnim(), fragment.getNextTransition(), false);
        if (fragment.mView != null && !fragment.mHidden && fragment.mIsNewlyAdded)
          paramb.add(fragment); 
      } 
    } 
  }
  
  private static void h0(ArrayList<a> paramArrayList, ArrayList<Boolean> paramArrayList1, int paramInt1, int paramInt2) {
    while (paramInt1 < paramInt2) {
      a a = paramArrayList.get(paramInt1);
      boolean bool1 = ((Boolean)paramArrayList1.get(paramInt1)).booleanValue();
      boolean bool = true;
      if (bool1) {
        a.h(-1);
        if (paramInt1 != paramInt2 - 1)
          bool = false; 
        a.o(bool);
      } else {
        a.h(1);
        a.n();
      } 
      paramInt1++;
    } 
  }
  
  public static int h1(int paramInt, boolean paramBoolean) {
    return (paramInt != 4097) ? ((paramInt != 4099) ? ((paramInt != 8194) ? -1 : (paramBoolean ? 3 : 4)) : (paramBoolean ? 5 : 6)) : (paramBoolean ? 1 : 2);
  }
  
  private void i0(ArrayList<a> paramArrayList, ArrayList<Boolean> paramArrayList1, int paramInt1, int paramInt2) {
    int m;
    int j = paramInt1;
    boolean bool1 = ((a)paramArrayList.get(j)).t;
    ArrayList<Fragment> arrayList = this.z;
    if (arrayList == null) {
      this.z = new ArrayList<Fragment>();
    } else {
      arrayList.clear();
    } 
    this.z.addAll(this.e);
    Fragment fragment = t0();
    int k = j;
    boolean bool = false;
    while (k < paramInt2) {
      a a = paramArrayList.get(k);
      if (!((Boolean)paramArrayList1.get(k)).booleanValue()) {
        fragment = a.p(this.z, fragment);
      } else {
        fragment = a.x(this.z, fragment);
      } 
      if (bool || a.i) {
        bool = true;
      } else {
        bool = false;
      } 
      k++;
    } 
    this.z.clear();
    if (!bool1)
      k.B(this, paramArrayList, paramArrayList1, paramInt1, paramInt2, false); 
    h0(paramArrayList, paramArrayList1, paramInt1, paramInt2);
    if (bool1) {
      androidx.collection.b<Fragment> b = new androidx.collection.b();
      h(b);
      m = M0(paramArrayList, paramArrayList1, paramInt1, paramInt2, b);
      B0(b);
    } else {
      m = paramInt2;
    } 
    k = j;
    if (m != j) {
      k = j;
      if (bool1) {
        k.B(this, paramArrayList, paramArrayList1, paramInt1, m, true);
        F0(this.m, true);
        k = j;
      } 
    } 
    while (k < paramInt2) {
      a a = paramArrayList.get(k);
      if (((Boolean)paramArrayList1.get(k)).booleanValue()) {
        paramInt1 = a.m;
        if (paramInt1 >= 0) {
          o0(paramInt1);
          a.m = -1;
        } 
      } 
      a.v();
      k++;
    } 
    if (bool)
      Q0(); 
  }
  
  private void j0(ArrayList<a> paramArrayList, ArrayList<Boolean> paramArrayList1) {
    // Byte code:
    //   0: aload_0
    //   1: getfield C : Ljava/util/ArrayList;
    //   4: astore #7
    //   6: aload #7
    //   8: ifnonnull -> 17
    //   11: iconst_0
    //   12: istore #4
    //   14: goto -> 24
    //   17: aload #7
    //   19: invokevirtual size : ()I
    //   22: istore #4
    //   24: iconst_0
    //   25: istore_3
    //   26: iload_3
    //   27: iload #4
    //   29: if_icmpge -> 233
    //   32: aload_0
    //   33: getfield C : Ljava/util/ArrayList;
    //   36: iload_3
    //   37: invokevirtual get : (I)Ljava/lang/Object;
    //   40: checkcast androidx/fragment/app/h$n
    //   43: astore #7
    //   45: aload_1
    //   46: ifnull -> 104
    //   49: aload #7
    //   51: getfield a : Z
    //   54: ifne -> 104
    //   57: aload_1
    //   58: aload #7
    //   60: getfield b : Landroidx/fragment/app/a;
    //   63: invokevirtual indexOf : (Ljava/lang/Object;)I
    //   66: istore #5
    //   68: iload #5
    //   70: iconst_m1
    //   71: if_icmpeq -> 104
    //   74: aload_2
    //   75: iload #5
    //   77: invokevirtual get : (I)Ljava/lang/Object;
    //   80: checkcast java/lang/Boolean
    //   83: invokevirtual booleanValue : ()Z
    //   86: ifeq -> 104
    //   89: aload #7
    //   91: invokevirtual c : ()V
    //   94: iload #4
    //   96: istore #5
    //   98: iload_3
    //   99: istore #6
    //   101: goto -> 221
    //   104: aload #7
    //   106: invokevirtual e : ()Z
    //   109: ifne -> 147
    //   112: iload #4
    //   114: istore #5
    //   116: iload_3
    //   117: istore #6
    //   119: aload_1
    //   120: ifnull -> 221
    //   123: iload #4
    //   125: istore #5
    //   127: iload_3
    //   128: istore #6
    //   130: aload #7
    //   132: getfield b : Landroidx/fragment/app/a;
    //   135: aload_1
    //   136: iconst_0
    //   137: aload_1
    //   138: invokevirtual size : ()I
    //   141: invokevirtual s : (Ljava/util/ArrayList;II)Z
    //   144: ifeq -> 221
    //   147: aload_0
    //   148: getfield C : Ljava/util/ArrayList;
    //   151: iload_3
    //   152: invokevirtual remove : (I)Ljava/lang/Object;
    //   155: pop
    //   156: iload_3
    //   157: iconst_1
    //   158: isub
    //   159: istore #6
    //   161: iload #4
    //   163: iconst_1
    //   164: isub
    //   165: istore #5
    //   167: aload_1
    //   168: ifnull -> 216
    //   171: aload #7
    //   173: getfield a : Z
    //   176: ifne -> 216
    //   179: aload_1
    //   180: aload #7
    //   182: getfield b : Landroidx/fragment/app/a;
    //   185: invokevirtual indexOf : (Ljava/lang/Object;)I
    //   188: istore_3
    //   189: iload_3
    //   190: iconst_m1
    //   191: if_icmpeq -> 216
    //   194: aload_2
    //   195: iload_3
    //   196: invokevirtual get : (I)Ljava/lang/Object;
    //   199: checkcast java/lang/Boolean
    //   202: invokevirtual booleanValue : ()Z
    //   205: ifeq -> 216
    //   208: aload #7
    //   210: invokevirtual c : ()V
    //   213: goto -> 221
    //   216: aload #7
    //   218: invokevirtual d : ()V
    //   221: iload #6
    //   223: iconst_1
    //   224: iadd
    //   225: istore_3
    //   226: iload #5
    //   228: istore #4
    //   230: goto -> 26
    //   233: return
  }
  
  private void l(Fragment paramFragment, g paramg, int paramInt) {
    View view = paramFragment.mView;
    ViewGroup viewGroup = paramFragment.mContainer;
    viewGroup.startViewTransition(view);
    paramFragment.setStateAfterAnimating(paramInt);
    if (paramg.a != null) {
      i i1 = new i(paramg.a, viewGroup, view);
      paramFragment.setAnimatingAway(paramFragment.mView);
      i1.setAnimationListener(new b(this, q0((Animation)i1), viewGroup, paramFragment));
      a1(view, paramg);
      paramFragment.mView.startAnimation((Animation)i1);
      return;
    } 
    Animator animator = paramg.b;
    paramFragment.setAnimator(animator);
    animator.addListener((Animator.AnimatorListener)new c(this, viewGroup, view, paramFragment));
    animator.setTarget(paramFragment.mView);
    a1(paramFragment.mView, paramg);
    animator.start();
  }
  
  private Fragment m0(Fragment paramFragment) {
    ViewGroup viewGroup = paramFragment.mContainer;
    View view = paramFragment.mView;
    if (viewGroup != null) {
      if (view == null)
        return null; 
      for (int j = this.e.indexOf(paramFragment) - 1; j >= 0; j--) {
        paramFragment = this.e.get(j);
        if (paramFragment.mContainer == viewGroup && paramFragment.mView != null)
          return paramFragment; 
      } 
    } 
    return null;
  }
  
  private void n0() {
    if (this.C != null)
      while (!this.C.isEmpty())
        ((n)this.C.remove(0)).d();  
  }
  
  private void o() {
    SparseArray<Fragment> sparseArray = this.f;
    if (sparseArray != null)
      for (int j = sparseArray.size() - 1; j >= 0; j--) {
        if (this.f.valueAt(j) == null) {
          sparseArray = this.f;
          sparseArray.delete(sparseArray.keyAt(j));
        } 
      }  
  }
  
  private void p() {
    if (!e()) {
      if (this.v == null)
        return; 
      StringBuilder stringBuilder = new StringBuilder();
      stringBuilder.append("Can not perform this action inside of ");
      stringBuilder.append(this.v);
      throw new IllegalStateException(stringBuilder.toString());
    } 
    throw new IllegalStateException("Can not perform this action after onSaveInstanceState");
  }
  
  private boolean p0(ArrayList<a> paramArrayList, ArrayList<Boolean> paramArrayList1) {
    // Byte code:
    //   0: aload_0
    //   1: monitorenter
    //   2: aload_0
    //   3: getfield b : Ljava/util/ArrayList;
    //   6: astore #6
    //   8: iconst_0
    //   9: istore_3
    //   10: aload #6
    //   12: ifnull -> 100
    //   15: aload #6
    //   17: invokevirtual size : ()I
    //   20: ifne -> 26
    //   23: goto -> 100
    //   26: aload_0
    //   27: getfield b : Ljava/util/ArrayList;
    //   30: invokevirtual size : ()I
    //   33: istore #4
    //   35: iconst_0
    //   36: istore #5
    //   38: iload_3
    //   39: iload #4
    //   41: if_icmpge -> 74
    //   44: iload #5
    //   46: aload_0
    //   47: getfield b : Ljava/util/ArrayList;
    //   50: iload_3
    //   51: invokevirtual get : (I)Ljava/lang/Object;
    //   54: checkcast androidx/fragment/app/h$l
    //   57: aload_1
    //   58: aload_2
    //   59: invokeinterface a : (Ljava/util/ArrayList;Ljava/util/ArrayList;)Z
    //   64: ior
    //   65: istore #5
    //   67: iload_3
    //   68: iconst_1
    //   69: iadd
    //   70: istore_3
    //   71: goto -> 38
    //   74: aload_0
    //   75: getfield b : Ljava/util/ArrayList;
    //   78: invokevirtual clear : ()V
    //   81: aload_0
    //   82: getfield n : Landroidx/fragment/app/f;
    //   85: invokevirtual g : ()Landroid/os/Handler;
    //   88: aload_0
    //   89: getfield E : Ljava/lang/Runnable;
    //   92: invokevirtual removeCallbacks : (Ljava/lang/Runnable;)V
    //   95: aload_0
    //   96: monitorexit
    //   97: iload #5
    //   99: ireturn
    //   100: aload_0
    //   101: monitorexit
    //   102: iconst_0
    //   103: ireturn
    //   104: astore_1
    //   105: aload_0
    //   106: monitorexit
    //   107: aload_1
    //   108: athrow
    // Exception table:
    //   from	to	target	type
    //   2	8	104	finally
    //   15	23	104	finally
    //   26	35	104	finally
    //   44	67	104	finally
    //   74	97	104	finally
    //   100	102	104	finally
    //   105	107	104	finally
  }
  
  private void q() {
    this.c = false;
    this.y.clear();
    this.x.clear();
  }
  
  private static Animation.AnimationListener q0(Animation paramAnimation) {
    try {
      if (G == null) {
        Field field = Animation.class.getDeclaredField("mListener");
        G = field;
        field.setAccessible(true);
      } 
      return (Animation.AnimationListener)G.get(paramAnimation);
    } catch (NoSuchFieldException noSuchFieldException) {
      Log.e("FragmentManager", "No field with the name mListener is found in Animation class", noSuchFieldException);
    } catch (IllegalAccessException illegalAccessException) {
      Log.e("FragmentManager", "Cannot access Animation's mListener field", illegalAccessException);
    } 
    return null;
  }
  
  static g y0(Context paramContext, float paramFloat1, float paramFloat2) {
    AlphaAnimation alphaAnimation = new AlphaAnimation(paramFloat1, paramFloat2);
    alphaAnimation.setInterpolator(I);
    alphaAnimation.setDuration(220L);
    return new g((Animation)alphaAnimation);
  }
  
  public void A() {
    Y(1);
  }
  
  public void B() {
    for (int j = 0; j < this.e.size(); j++) {
      Fragment fragment = this.e.get(j);
      if (fragment != null)
        fragment.performLowMemory(); 
    } 
  }
  
  public void C(boolean paramBoolean) {
    for (int j = this.e.size() - 1; j >= 0; j--) {
      Fragment fragment = this.e.get(j);
      if (fragment != null)
        fragment.performMultiWindowModeChanged(paramBoolean); 
    } 
  }
  
  void D(Fragment paramFragment, Bundle paramBundle, boolean paramBoolean) {
    Fragment fragment = this.p;
    if (fragment != null) {
      g g1 = fragment.getFragmentManager();
      if (g1 instanceof h)
        ((h)g1).D(paramFragment, paramBundle, true); 
    } 
    Iterator<j> iterator = this.l.iterator();
    while (iterator.hasNext()) {
      j j = iterator.next();
      if (paramBoolean && !j.b)
        continue; 
      g.a a = j.a;
      throw null;
    } 
  }
  
  void E(Fragment paramFragment, Context paramContext, boolean paramBoolean) {
    Fragment fragment = this.p;
    if (fragment != null) {
      g g1 = fragment.getFragmentManager();
      if (g1 instanceof h)
        ((h)g1).E(paramFragment, paramContext, true); 
    } 
    Iterator<j> iterator = this.l.iterator();
    while (iterator.hasNext()) {
      j j = iterator.next();
      if (paramBoolean && !j.b)
        continue; 
      g.a a = j.a;
      throw null;
    } 
  }
  
  void E0(Fragment paramFragment) {
    if (paramFragment == null)
      return; 
    int k = this.m;
    int j = k;
    if (paramFragment.mRemoving)
      if (paramFragment.isInBackStack()) {
        j = Math.min(k, 1);
      } else {
        j = Math.min(k, 0);
      }  
    H0(paramFragment, j, paramFragment.getNextTransition(), paramFragment.getNextTransitionStyle(), false);
    if (paramFragment.mView != null) {
      Fragment fragment = m0(paramFragment);
      if (fragment != null) {
        View view = fragment.mView;
        ViewGroup viewGroup = paramFragment.mContainer;
        j = viewGroup.indexOfChild(view);
        k = viewGroup.indexOfChild(paramFragment.mView);
        if (k < j) {
          viewGroup.removeViewAt(k);
          viewGroup.addView(paramFragment.mView, j);
        } 
      } 
      if (paramFragment.mIsNewlyAdded && paramFragment.mContainer != null) {
        float f1 = paramFragment.mPostponedAlpha;
        if (f1 > 0.0F)
          paramFragment.mView.setAlpha(f1); 
        paramFragment.mPostponedAlpha = 0.0F;
        paramFragment.mIsNewlyAdded = false;
        g g1 = w0(paramFragment, paramFragment.getNextTransition(), true, paramFragment.getNextTransitionStyle());
        if (g1 != null) {
          a1(paramFragment.mView, g1);
          Animation animation = g1.a;
          if (animation != null) {
            paramFragment.mView.startAnimation(animation);
          } else {
            g1.b.setTarget(paramFragment.mView);
            g1.b.start();
          } 
        } 
      } 
    } 
    if (paramFragment.mHiddenChanged)
      s(paramFragment); 
  }
  
  void F(Fragment paramFragment, Bundle paramBundle, boolean paramBoolean) {
    Fragment fragment = this.p;
    if (fragment != null) {
      g g1 = fragment.getFragmentManager();
      if (g1 instanceof h)
        ((h)g1).F(paramFragment, paramBundle, true); 
    } 
    Iterator<j> iterator = this.l.iterator();
    while (iterator.hasNext()) {
      j j = iterator.next();
      if (paramBoolean && !j.b)
        continue; 
      g.a a = j.a;
      throw null;
    } 
  }
  
  void F0(int paramInt, boolean paramBoolean) {
    if (this.n != null || paramInt == 0) {
      if (!paramBoolean && paramInt == this.m)
        return; 
      this.m = paramInt;
      if (this.f != null) {
        int j = this.e.size();
        for (paramInt = 0; paramInt < j; paramInt++)
          E0(this.e.get(paramInt)); 
        j = this.f.size();
        for (paramInt = 0; paramInt < j; paramInt++) {
          Fragment fragment = (Fragment)this.f.valueAt(paramInt);
          if (fragment != null && (fragment.mRemoving || fragment.mDetached) && !fragment.mIsNewlyAdded)
            E0(fragment); 
        } 
        f1();
        if (this.r) {
          f f1 = this.n;
          if (f1 != null && this.m == 4) {
            f1.s();
            this.r = false;
          } 
        } 
      } 
      return;
    } 
    throw new IllegalStateException("No activity");
  }
  
  void G(Fragment paramFragment, boolean paramBoolean) {
    Fragment fragment = this.p;
    if (fragment != null) {
      g g1 = fragment.getFragmentManager();
      if (g1 instanceof h)
        ((h)g1).G(paramFragment, true); 
    } 
    Iterator<j> iterator = this.l.iterator();
    while (iterator.hasNext()) {
      j j = iterator.next();
      if (paramBoolean && !j.b)
        continue; 
      g.a a = j.a;
      throw null;
    } 
  }
  
  void G0(Fragment paramFragment) {
    H0(paramFragment, this.m, 0, 0, false);
  }
  
  void H(Fragment paramFragment, boolean paramBoolean) {
    Fragment fragment = this.p;
    if (fragment != null) {
      g g1 = fragment.getFragmentManager();
      if (g1 instanceof h)
        ((h)g1).H(paramFragment, true); 
    } 
    Iterator<j> iterator = this.l.iterator();
    while (iterator.hasNext()) {
      j j = iterator.next();
      if (paramBoolean && !j.b)
        continue; 
      g.a a = j.a;
      throw null;
    } 
  }
  
  void H0(Fragment paramFragment, int paramInt1, int paramInt2, int paramInt3, boolean paramBoolean) {
    // Byte code:
    //   0: aload_1
    //   1: getfield mAdded : Z
    //   4: istore #10
    //   6: iconst_1
    //   7: istore #7
    //   9: iconst_1
    //   10: istore #9
    //   12: iload #10
    //   14: ifeq -> 30
    //   17: aload_1
    //   18: getfield mDetached : Z
    //   21: ifeq -> 27
    //   24: goto -> 30
    //   27: goto -> 44
    //   30: iload_2
    //   31: istore #6
    //   33: iload #6
    //   35: istore_2
    //   36: iload #6
    //   38: iconst_1
    //   39: if_icmple -> 44
    //   42: iconst_1
    //   43: istore_2
    //   44: iload_2
    //   45: istore #6
    //   47: aload_1
    //   48: getfield mRemoving : Z
    //   51: ifeq -> 93
    //   54: aload_1
    //   55: getfield mState : I
    //   58: istore #8
    //   60: iload_2
    //   61: istore #6
    //   63: iload_2
    //   64: iload #8
    //   66: if_icmple -> 93
    //   69: iload #8
    //   71: ifne -> 87
    //   74: aload_1
    //   75: invokevirtual isInBackStack : ()Z
    //   78: ifeq -> 87
    //   81: iconst_1
    //   82: istore #6
    //   84: goto -> 93
    //   87: aload_1
    //   88: getfield mState : I
    //   91: istore #6
    //   93: aload_1
    //   94: getfield mDeferStart : Z
    //   97: ifeq -> 119
    //   100: aload_1
    //   101: getfield mState : I
    //   104: iconst_3
    //   105: if_icmpge -> 119
    //   108: iload #6
    //   110: iconst_2
    //   111: if_icmple -> 119
    //   114: iconst_2
    //   115: istore_2
    //   116: goto -> 122
    //   119: iload #6
    //   121: istore_2
    //   122: aload_1
    //   123: getfield mState : I
    //   126: istore #8
    //   128: iload #8
    //   130: iload_2
    //   131: if_icmpgt -> 1385
    //   134: aload_1
    //   135: getfield mFromLayout : Z
    //   138: ifeq -> 149
    //   141: aload_1
    //   142: getfield mInLayout : Z
    //   145: ifne -> 149
    //   148: return
    //   149: aload_1
    //   150: invokevirtual getAnimatingAway : ()Landroid/view/View;
    //   153: ifnonnull -> 163
    //   156: aload_1
    //   157: invokevirtual getAnimator : ()Landroid/animation/Animator;
    //   160: ifnull -> 185
    //   163: aload_1
    //   164: aconst_null
    //   165: invokevirtual setAnimatingAway : (Landroid/view/View;)V
    //   168: aload_1
    //   169: aconst_null
    //   170: invokevirtual setAnimator : (Landroid/animation/Animator;)V
    //   173: aload_0
    //   174: aload_1
    //   175: aload_1
    //   176: invokevirtual getStateAfterAnimating : ()I
    //   179: iconst_0
    //   180: iconst_0
    //   181: iconst_1
    //   182: invokevirtual H0 : (Landroidx/fragment/app/Fragment;IIIZ)V
    //   185: aload_1
    //   186: getfield mState : I
    //   189: istore #6
    //   191: iload #6
    //   193: ifeq -> 227
    //   196: iload_2
    //   197: istore_3
    //   198: iload #6
    //   200: iconst_1
    //   201: if_icmpeq -> 784
    //   204: iload_2
    //   205: istore #4
    //   207: iload #6
    //   209: iconst_2
    //   210: if_icmpeq -> 1243
    //   213: iload_2
    //   214: istore_3
    //   215: iload #6
    //   217: iconst_3
    //   218: if_icmpeq -> 1308
    //   221: iload_2
    //   222: istore #6
    //   224: goto -> 1994
    //   227: iload_2
    //   228: istore_3
    //   229: iload_2
    //   230: ifle -> 784
    //   233: getstatic androidx/fragment/app/h.F : Z
    //   236: ifeq -> 276
    //   239: new java/lang/StringBuilder
    //   242: dup
    //   243: invokespecial <init> : ()V
    //   246: astore #11
    //   248: aload #11
    //   250: ldc_w 'moveto CREATED: '
    //   253: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   256: pop
    //   257: aload #11
    //   259: aload_1
    //   260: invokevirtual append : (Ljava/lang/Object;)Ljava/lang/StringBuilder;
    //   263: pop
    //   264: ldc_w 'FragmentManager'
    //   267: aload #11
    //   269: invokevirtual toString : ()Ljava/lang/String;
    //   272: invokestatic v : (Ljava/lang/String;Ljava/lang/String;)I
    //   275: pop
    //   276: aload_1
    //   277: getfield mSavedFragmentState : Landroid/os/Bundle;
    //   280: astore #11
    //   282: iload_2
    //   283: istore_3
    //   284: aload #11
    //   286: ifnull -> 423
    //   289: aload #11
    //   291: aload_0
    //   292: getfield n : Landroidx/fragment/app/f;
    //   295: invokevirtual e : ()Landroid/content/Context;
    //   298: invokevirtual getClassLoader : ()Ljava/lang/ClassLoader;
    //   301: invokevirtual setClassLoader : (Ljava/lang/ClassLoader;)V
    //   304: aload_1
    //   305: aload_1
    //   306: getfield mSavedFragmentState : Landroid/os/Bundle;
    //   309: ldc_w 'android:view_state'
    //   312: invokevirtual getSparseParcelableArray : (Ljava/lang/String;)Landroid/util/SparseArray;
    //   315: putfield mSavedViewState : Landroid/util/SparseArray;
    //   318: aload_0
    //   319: aload_1
    //   320: getfield mSavedFragmentState : Landroid/os/Bundle;
    //   323: ldc_w 'android:target_state'
    //   326: invokevirtual r0 : (Landroid/os/Bundle;Ljava/lang/String;)Landroidx/fragment/app/Fragment;
    //   329: astore #11
    //   331: aload_1
    //   332: aload #11
    //   334: putfield mTarget : Landroidx/fragment/app/Fragment;
    //   337: aload #11
    //   339: ifnull -> 357
    //   342: aload_1
    //   343: aload_1
    //   344: getfield mSavedFragmentState : Landroid/os/Bundle;
    //   347: ldc_w 'android:target_req_state'
    //   350: iconst_0
    //   351: invokevirtual getInt : (Ljava/lang/String;I)I
    //   354: putfield mTargetRequestCode : I
    //   357: aload_1
    //   358: getfield mSavedUserVisibleHint : Ljava/lang/Boolean;
    //   361: astore #11
    //   363: aload #11
    //   365: ifnull -> 385
    //   368: aload_1
    //   369: aload #11
    //   371: invokevirtual booleanValue : ()Z
    //   374: putfield mUserVisibleHint : Z
    //   377: aload_1
    //   378: aconst_null
    //   379: putfield mSavedUserVisibleHint : Ljava/lang/Boolean;
    //   382: goto -> 400
    //   385: aload_1
    //   386: aload_1
    //   387: getfield mSavedFragmentState : Landroid/os/Bundle;
    //   390: ldc_w 'android:user_visible_hint'
    //   393: iconst_1
    //   394: invokevirtual getBoolean : (Ljava/lang/String;Z)Z
    //   397: putfield mUserVisibleHint : Z
    //   400: iload_2
    //   401: istore_3
    //   402: aload_1
    //   403: getfield mUserVisibleHint : Z
    //   406: ifne -> 423
    //   409: aload_1
    //   410: iconst_1
    //   411: putfield mDeferStart : Z
    //   414: iload_2
    //   415: istore_3
    //   416: iload_2
    //   417: iconst_2
    //   418: if_icmple -> 423
    //   421: iconst_2
    //   422: istore_3
    //   423: aload_0
    //   424: getfield n : Landroidx/fragment/app/f;
    //   427: astore #11
    //   429: aload_1
    //   430: aload #11
    //   432: putfield mHost : Landroidx/fragment/app/f;
    //   435: aload_0
    //   436: getfield p : Landroidx/fragment/app/Fragment;
    //   439: astore #12
    //   441: aload_1
    //   442: aload #12
    //   444: putfield mParentFragment : Landroidx/fragment/app/Fragment;
    //   447: aload #12
    //   449: ifnull -> 462
    //   452: aload #12
    //   454: getfield mChildFragmentManager : Landroidx/fragment/app/h;
    //   457: astore #11
    //   459: goto -> 469
    //   462: aload #11
    //   464: invokevirtual f : ()Landroidx/fragment/app/h;
    //   467: astore #11
    //   469: aload_1
    //   470: aload #11
    //   472: putfield mFragmentManager : Landroidx/fragment/app/h;
    //   475: aload_1
    //   476: getfield mTarget : Landroidx/fragment/app/Fragment;
    //   479: astore #11
    //   481: aload #11
    //   483: ifnull -> 601
    //   486: aload_0
    //   487: getfield f : Landroid/util/SparseArray;
    //   490: aload #11
    //   492: getfield mIndex : I
    //   495: invokevirtual get : (I)Ljava/lang/Object;
    //   498: astore #11
    //   500: aload_1
    //   501: getfield mTarget : Landroidx/fragment/app/Fragment;
    //   504: astore #12
    //   506: aload #11
    //   508: aload #12
    //   510: if_acmpne -> 535
    //   513: aload #12
    //   515: getfield mState : I
    //   518: iconst_1
    //   519: if_icmpge -> 601
    //   522: aload_0
    //   523: aload #12
    //   525: iconst_1
    //   526: iconst_0
    //   527: iconst_0
    //   528: iconst_1
    //   529: invokevirtual H0 : (Landroidx/fragment/app/Fragment;IIIZ)V
    //   532: goto -> 601
    //   535: new java/lang/StringBuilder
    //   538: dup
    //   539: invokespecial <init> : ()V
    //   542: astore #11
    //   544: aload #11
    //   546: ldc_w 'Fragment '
    //   549: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   552: pop
    //   553: aload #11
    //   555: aload_1
    //   556: invokevirtual append : (Ljava/lang/Object;)Ljava/lang/StringBuilder;
    //   559: pop
    //   560: aload #11
    //   562: ldc_w ' declared target fragment '
    //   565: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   568: pop
    //   569: aload #11
    //   571: aload_1
    //   572: getfield mTarget : Landroidx/fragment/app/Fragment;
    //   575: invokevirtual append : (Ljava/lang/Object;)Ljava/lang/StringBuilder;
    //   578: pop
    //   579: aload #11
    //   581: ldc_w ' that does not belong to this FragmentManager!'
    //   584: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   587: pop
    //   588: new java/lang/IllegalStateException
    //   591: dup
    //   592: aload #11
    //   594: invokevirtual toString : ()Ljava/lang/String;
    //   597: invokespecial <init> : (Ljava/lang/String;)V
    //   600: athrow
    //   601: aload_0
    //   602: aload_1
    //   603: aload_0
    //   604: getfield n : Landroidx/fragment/app/f;
    //   607: invokevirtual e : ()Landroid/content/Context;
    //   610: iconst_0
    //   611: invokevirtual J : (Landroidx/fragment/app/Fragment;Landroid/content/Context;Z)V
    //   614: aload_1
    //   615: iconst_0
    //   616: putfield mCalled : Z
    //   619: aload_1
    //   620: aload_0
    //   621: getfield n : Landroidx/fragment/app/f;
    //   624: invokevirtual e : ()Landroid/content/Context;
    //   627: invokevirtual onAttach : (Landroid/content/Context;)V
    //   630: aload_1
    //   631: getfield mCalled : Z
    //   634: ifeq -> 737
    //   637: aload_1
    //   638: getfield mParentFragment : Landroidx/fragment/app/Fragment;
    //   641: astore #11
    //   643: aload #11
    //   645: ifnonnull -> 659
    //   648: aload_0
    //   649: getfield n : Landroidx/fragment/app/f;
    //   652: aload_1
    //   653: invokevirtual h : (Landroidx/fragment/app/Fragment;)V
    //   656: goto -> 665
    //   659: aload #11
    //   661: aload_1
    //   662: invokevirtual onAttachFragment : (Landroidx/fragment/app/Fragment;)V
    //   665: aload_0
    //   666: aload_1
    //   667: aload_0
    //   668: getfield n : Landroidx/fragment/app/f;
    //   671: invokevirtual e : ()Landroid/content/Context;
    //   674: iconst_0
    //   675: invokevirtual E : (Landroidx/fragment/app/Fragment;Landroid/content/Context;Z)V
    //   678: aload_1
    //   679: getfield mIsCreated : Z
    //   682: ifne -> 716
    //   685: aload_0
    //   686: aload_1
    //   687: aload_1
    //   688: getfield mSavedFragmentState : Landroid/os/Bundle;
    //   691: iconst_0
    //   692: invokevirtual K : (Landroidx/fragment/app/Fragment;Landroid/os/Bundle;Z)V
    //   695: aload_1
    //   696: aload_1
    //   697: getfield mSavedFragmentState : Landroid/os/Bundle;
    //   700: invokevirtual performCreate : (Landroid/os/Bundle;)V
    //   703: aload_0
    //   704: aload_1
    //   705: aload_1
    //   706: getfield mSavedFragmentState : Landroid/os/Bundle;
    //   709: iconst_0
    //   710: invokevirtual F : (Landroidx/fragment/app/Fragment;Landroid/os/Bundle;Z)V
    //   713: goto -> 729
    //   716: aload_1
    //   717: aload_1
    //   718: getfield mSavedFragmentState : Landroid/os/Bundle;
    //   721: invokevirtual restoreChildFragmentState : (Landroid/os/Bundle;)V
    //   724: aload_1
    //   725: iconst_1
    //   726: putfield mState : I
    //   729: aload_1
    //   730: iconst_0
    //   731: putfield mRetaining : Z
    //   734: goto -> 784
    //   737: new java/lang/StringBuilder
    //   740: dup
    //   741: invokespecial <init> : ()V
    //   744: astore #11
    //   746: aload #11
    //   748: ldc_w 'Fragment '
    //   751: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   754: pop
    //   755: aload #11
    //   757: aload_1
    //   758: invokevirtual append : (Ljava/lang/Object;)Ljava/lang/StringBuilder;
    //   761: pop
    //   762: aload #11
    //   764: ldc_w ' did not call through to super.onAttach()'
    //   767: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   770: pop
    //   771: new androidx/fragment/app/o
    //   774: dup
    //   775: aload #11
    //   777: invokevirtual toString : ()Ljava/lang/String;
    //   780: invokespecial <init> : (Ljava/lang/String;)V
    //   783: athrow
    //   784: aload_0
    //   785: aload_1
    //   786: invokevirtual e0 : (Landroidx/fragment/app/Fragment;)V
    //   789: iload_3
    //   790: istore #4
    //   792: iload_3
    //   793: iconst_1
    //   794: if_icmple -> 1243
    //   797: getstatic androidx/fragment/app/h.F : Z
    //   800: ifeq -> 840
    //   803: new java/lang/StringBuilder
    //   806: dup
    //   807: invokespecial <init> : ()V
    //   810: astore #11
    //   812: aload #11
    //   814: ldc_w 'moveto ACTIVITY_CREATED: '
    //   817: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   820: pop
    //   821: aload #11
    //   823: aload_1
    //   824: invokevirtual append : (Ljava/lang/Object;)Ljava/lang/StringBuilder;
    //   827: pop
    //   828: ldc_w 'FragmentManager'
    //   831: aload #11
    //   833: invokevirtual toString : ()Ljava/lang/String;
    //   836: invokestatic v : (Ljava/lang/String;Ljava/lang/String;)I
    //   839: pop
    //   840: aload_1
    //   841: getfield mFromLayout : Z
    //   844: ifne -> 1202
    //   847: aload_1
    //   848: getfield mContainerId : I
    //   851: istore_2
    //   852: iload_2
    //   853: ifeq -> 1055
    //   856: iload_2
    //   857: iconst_m1
    //   858: if_icmpne -> 911
    //   861: new java/lang/StringBuilder
    //   864: dup
    //   865: invokespecial <init> : ()V
    //   868: astore #11
    //   870: aload #11
    //   872: ldc_w 'Cannot create fragment '
    //   875: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   878: pop
    //   879: aload #11
    //   881: aload_1
    //   882: invokevirtual append : (Ljava/lang/Object;)Ljava/lang/StringBuilder;
    //   885: pop
    //   886: aload #11
    //   888: ldc_w ' for a container view with no id'
    //   891: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   894: pop
    //   895: aload_0
    //   896: new java/lang/IllegalArgumentException
    //   899: dup
    //   900: aload #11
    //   902: invokevirtual toString : ()Ljava/lang/String;
    //   905: invokespecial <init> : (Ljava/lang/String;)V
    //   908: invokespecial g1 : (Ljava/lang/RuntimeException;)V
    //   911: aload_0
    //   912: getfield o : Landroidx/fragment/app/d;
    //   915: aload_1
    //   916: getfield mContainerId : I
    //   919: invokevirtual b : (I)Landroid/view/View;
    //   922: checkcast android/view/ViewGroup
    //   925: astore #12
    //   927: aload #12
    //   929: astore #11
    //   931: aload #12
    //   933: ifnonnull -> 1058
    //   936: aload #12
    //   938: astore #11
    //   940: aload_1
    //   941: getfield mRestored : Z
    //   944: ifne -> 1058
    //   947: aload_1
    //   948: invokevirtual getResources : ()Landroid/content/res/Resources;
    //   951: aload_1
    //   952: getfield mContainerId : I
    //   955: invokevirtual getResourceName : (I)Ljava/lang/String;
    //   958: astore #11
    //   960: goto -> 968
    //   963: ldc_w 'unknown'
    //   966: astore #11
    //   968: new java/lang/StringBuilder
    //   971: dup
    //   972: invokespecial <init> : ()V
    //   975: astore #13
    //   977: aload #13
    //   979: ldc_w 'No view found for id 0x'
    //   982: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   985: pop
    //   986: aload #13
    //   988: aload_1
    //   989: getfield mContainerId : I
    //   992: invokestatic toHexString : (I)Ljava/lang/String;
    //   995: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   998: pop
    //   999: aload #13
    //   1001: ldc_w ' ('
    //   1004: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   1007: pop
    //   1008: aload #13
    //   1010: aload #11
    //   1012: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   1015: pop
    //   1016: aload #13
    //   1018: ldc_w ') for fragment '
    //   1021: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   1024: pop
    //   1025: aload #13
    //   1027: aload_1
    //   1028: invokevirtual append : (Ljava/lang/Object;)Ljava/lang/StringBuilder;
    //   1031: pop
    //   1032: aload_0
    //   1033: new java/lang/IllegalArgumentException
    //   1036: dup
    //   1037: aload #13
    //   1039: invokevirtual toString : ()Ljava/lang/String;
    //   1042: invokespecial <init> : (Ljava/lang/String;)V
    //   1045: invokespecial g1 : (Ljava/lang/RuntimeException;)V
    //   1048: aload #12
    //   1050: astore #11
    //   1052: goto -> 1058
    //   1055: aconst_null
    //   1056: astore #11
    //   1058: aload_1
    //   1059: aload #11
    //   1061: putfield mContainer : Landroid/view/ViewGroup;
    //   1064: aload_1
    //   1065: aload_1
    //   1066: aload_1
    //   1067: getfield mSavedFragmentState : Landroid/os/Bundle;
    //   1070: invokevirtual performGetLayoutInflater : (Landroid/os/Bundle;)Landroid/view/LayoutInflater;
    //   1073: aload #11
    //   1075: aload_1
    //   1076: getfield mSavedFragmentState : Landroid/os/Bundle;
    //   1079: invokevirtual performCreateView : (Landroid/view/LayoutInflater;Landroid/view/ViewGroup;Landroid/os/Bundle;)V
    //   1082: aload_1
    //   1083: getfield mView : Landroid/view/View;
    //   1086: astore #12
    //   1088: aload #12
    //   1090: ifnull -> 1197
    //   1093: aload_1
    //   1094: aload #12
    //   1096: putfield mInnerView : Landroid/view/View;
    //   1099: aload #12
    //   1101: iconst_0
    //   1102: invokevirtual setSaveFromParentEnabled : (Z)V
    //   1105: aload #11
    //   1107: ifnull -> 1119
    //   1110: aload #11
    //   1112: aload_1
    //   1113: getfield mView : Landroid/view/View;
    //   1116: invokevirtual addView : (Landroid/view/View;)V
    //   1119: aload_1
    //   1120: getfield mHidden : Z
    //   1123: ifeq -> 1135
    //   1126: aload_1
    //   1127: getfield mView : Landroid/view/View;
    //   1130: bipush #8
    //   1132: invokevirtual setVisibility : (I)V
    //   1135: aload_1
    //   1136: aload_1
    //   1137: getfield mView : Landroid/view/View;
    //   1140: aload_1
    //   1141: getfield mSavedFragmentState : Landroid/os/Bundle;
    //   1144: invokevirtual onViewCreated : (Landroid/view/View;Landroid/os/Bundle;)V
    //   1147: aload_0
    //   1148: aload_1
    //   1149: aload_1
    //   1150: getfield mView : Landroid/view/View;
    //   1153: aload_1
    //   1154: getfield mSavedFragmentState : Landroid/os/Bundle;
    //   1157: iconst_0
    //   1158: invokevirtual P : (Landroidx/fragment/app/Fragment;Landroid/view/View;Landroid/os/Bundle;Z)V
    //   1161: aload_1
    //   1162: getfield mView : Landroid/view/View;
    //   1165: invokevirtual getVisibility : ()I
    //   1168: ifne -> 1185
    //   1171: aload_1
    //   1172: getfield mContainer : Landroid/view/ViewGroup;
    //   1175: ifnull -> 1185
    //   1178: iload #9
    //   1180: istore #5
    //   1182: goto -> 1188
    //   1185: iconst_0
    //   1186: istore #5
    //   1188: aload_1
    //   1189: iload #5
    //   1191: putfield mIsNewlyAdded : Z
    //   1194: goto -> 1202
    //   1197: aload_1
    //   1198: aconst_null
    //   1199: putfield mInnerView : Landroid/view/View;
    //   1202: aload_1
    //   1203: aload_1
    //   1204: getfield mSavedFragmentState : Landroid/os/Bundle;
    //   1207: invokevirtual performActivityCreated : (Landroid/os/Bundle;)V
    //   1210: aload_0
    //   1211: aload_1
    //   1212: aload_1
    //   1213: getfield mSavedFragmentState : Landroid/os/Bundle;
    //   1216: iconst_0
    //   1217: invokevirtual D : (Landroidx/fragment/app/Fragment;Landroid/os/Bundle;Z)V
    //   1220: aload_1
    //   1221: getfield mView : Landroid/view/View;
    //   1224: ifnull -> 1235
    //   1227: aload_1
    //   1228: aload_1
    //   1229: getfield mSavedFragmentState : Landroid/os/Bundle;
    //   1232: invokevirtual restoreViewState : (Landroid/os/Bundle;)V
    //   1235: aload_1
    //   1236: aconst_null
    //   1237: putfield mSavedFragmentState : Landroid/os/Bundle;
    //   1240: iload_3
    //   1241: istore #4
    //   1243: iload #4
    //   1245: istore_3
    //   1246: iload #4
    //   1248: iconst_2
    //   1249: if_icmple -> 1308
    //   1252: getstatic androidx/fragment/app/h.F : Z
    //   1255: ifeq -> 1295
    //   1258: new java/lang/StringBuilder
    //   1261: dup
    //   1262: invokespecial <init> : ()V
    //   1265: astore #11
    //   1267: aload #11
    //   1269: ldc_w 'moveto STARTED: '
    //   1272: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   1275: pop
    //   1276: aload #11
    //   1278: aload_1
    //   1279: invokevirtual append : (Ljava/lang/Object;)Ljava/lang/StringBuilder;
    //   1282: pop
    //   1283: ldc_w 'FragmentManager'
    //   1286: aload #11
    //   1288: invokevirtual toString : ()Ljava/lang/String;
    //   1291: invokestatic v : (Ljava/lang/String;Ljava/lang/String;)I
    //   1294: pop
    //   1295: aload_1
    //   1296: invokevirtual performStart : ()V
    //   1299: aload_0
    //   1300: aload_1
    //   1301: iconst_0
    //   1302: invokevirtual N : (Landroidx/fragment/app/Fragment;Z)V
    //   1305: iload #4
    //   1307: istore_3
    //   1308: iload_3
    //   1309: istore #6
    //   1311: iload_3
    //   1312: iconst_3
    //   1313: if_icmple -> 1994
    //   1316: getstatic androidx/fragment/app/h.F : Z
    //   1319: ifeq -> 1359
    //   1322: new java/lang/StringBuilder
    //   1325: dup
    //   1326: invokespecial <init> : ()V
    //   1329: astore #11
    //   1331: aload #11
    //   1333: ldc_w 'moveto RESUMED: '
    //   1336: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   1339: pop
    //   1340: aload #11
    //   1342: aload_1
    //   1343: invokevirtual append : (Ljava/lang/Object;)Ljava/lang/StringBuilder;
    //   1346: pop
    //   1347: ldc_w 'FragmentManager'
    //   1350: aload #11
    //   1352: invokevirtual toString : ()Ljava/lang/String;
    //   1355: invokestatic v : (Ljava/lang/String;Ljava/lang/String;)I
    //   1358: pop
    //   1359: aload_1
    //   1360: invokevirtual performResume : ()V
    //   1363: aload_0
    //   1364: aload_1
    //   1365: iconst_0
    //   1366: invokevirtual L : (Landroidx/fragment/app/Fragment;Z)V
    //   1369: aload_1
    //   1370: aconst_null
    //   1371: putfield mSavedFragmentState : Landroid/os/Bundle;
    //   1374: aload_1
    //   1375: aconst_null
    //   1376: putfield mSavedViewState : Landroid/util/SparseArray;
    //   1379: iload_3
    //   1380: istore #6
    //   1382: goto -> 1994
    //   1385: iload_2
    //   1386: istore #6
    //   1388: iload #8
    //   1390: iload_2
    //   1391: if_icmple -> 1994
    //   1394: iload #8
    //   1396: iconst_1
    //   1397: if_icmpeq -> 1776
    //   1400: iload #8
    //   1402: iconst_2
    //   1403: if_icmpeq -> 1540
    //   1406: iload #8
    //   1408: iconst_3
    //   1409: if_icmpeq -> 1482
    //   1412: iload #8
    //   1414: iconst_4
    //   1415: if_icmpeq -> 1424
    //   1418: iload_2
    //   1419: istore #6
    //   1421: goto -> 1994
    //   1424: iload_2
    //   1425: iconst_4
    //   1426: if_icmpge -> 1482
    //   1429: getstatic androidx/fragment/app/h.F : Z
    //   1432: ifeq -> 1472
    //   1435: new java/lang/StringBuilder
    //   1438: dup
    //   1439: invokespecial <init> : ()V
    //   1442: astore #11
    //   1444: aload #11
    //   1446: ldc_w 'movefrom RESUMED: '
    //   1449: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   1452: pop
    //   1453: aload #11
    //   1455: aload_1
    //   1456: invokevirtual append : (Ljava/lang/Object;)Ljava/lang/StringBuilder;
    //   1459: pop
    //   1460: ldc_w 'FragmentManager'
    //   1463: aload #11
    //   1465: invokevirtual toString : ()Ljava/lang/String;
    //   1468: invokestatic v : (Ljava/lang/String;Ljava/lang/String;)I
    //   1471: pop
    //   1472: aload_1
    //   1473: invokevirtual performPause : ()V
    //   1476: aload_0
    //   1477: aload_1
    //   1478: iconst_0
    //   1479: invokevirtual I : (Landroidx/fragment/app/Fragment;Z)V
    //   1482: iload_2
    //   1483: iconst_3
    //   1484: if_icmpge -> 1540
    //   1487: getstatic androidx/fragment/app/h.F : Z
    //   1490: ifeq -> 1530
    //   1493: new java/lang/StringBuilder
    //   1496: dup
    //   1497: invokespecial <init> : ()V
    //   1500: astore #11
    //   1502: aload #11
    //   1504: ldc_w 'movefrom STARTED: '
    //   1507: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   1510: pop
    //   1511: aload #11
    //   1513: aload_1
    //   1514: invokevirtual append : (Ljava/lang/Object;)Ljava/lang/StringBuilder;
    //   1517: pop
    //   1518: ldc_w 'FragmentManager'
    //   1521: aload #11
    //   1523: invokevirtual toString : ()Ljava/lang/String;
    //   1526: invokestatic v : (Ljava/lang/String;Ljava/lang/String;)I
    //   1529: pop
    //   1530: aload_1
    //   1531: invokevirtual performStop : ()V
    //   1534: aload_0
    //   1535: aload_1
    //   1536: iconst_0
    //   1537: invokevirtual O : (Landroidx/fragment/app/Fragment;Z)V
    //   1540: iload_2
    //   1541: iconst_2
    //   1542: if_icmpge -> 1776
    //   1545: getstatic androidx/fragment/app/h.F : Z
    //   1548: ifeq -> 1588
    //   1551: new java/lang/StringBuilder
    //   1554: dup
    //   1555: invokespecial <init> : ()V
    //   1558: astore #11
    //   1560: aload #11
    //   1562: ldc_w 'movefrom ACTIVITY_CREATED: '
    //   1565: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   1568: pop
    //   1569: aload #11
    //   1571: aload_1
    //   1572: invokevirtual append : (Ljava/lang/Object;)Ljava/lang/StringBuilder;
    //   1575: pop
    //   1576: ldc_w 'FragmentManager'
    //   1579: aload #11
    //   1581: invokevirtual toString : ()Ljava/lang/String;
    //   1584: invokestatic v : (Ljava/lang/String;Ljava/lang/String;)I
    //   1587: pop
    //   1588: aload_1
    //   1589: getfield mView : Landroid/view/View;
    //   1592: ifnull -> 1618
    //   1595: aload_0
    //   1596: getfield n : Landroidx/fragment/app/f;
    //   1599: aload_1
    //   1600: invokevirtual o : (Landroidx/fragment/app/Fragment;)Z
    //   1603: ifeq -> 1618
    //   1606: aload_1
    //   1607: getfield mSavedViewState : Landroid/util/SparseArray;
    //   1610: ifnonnull -> 1618
    //   1613: aload_0
    //   1614: aload_1
    //   1615: invokevirtual W0 : (Landroidx/fragment/app/Fragment;)V
    //   1618: aload_1
    //   1619: invokevirtual performDestroyView : ()V
    //   1622: aload_0
    //   1623: aload_1
    //   1624: iconst_0
    //   1625: invokevirtual Q : (Landroidx/fragment/app/Fragment;Z)V
    //   1628: aload_1
    //   1629: getfield mView : Landroid/view/View;
    //   1632: astore #11
    //   1634: aload #11
    //   1636: ifnull -> 1743
    //   1639: aload_1
    //   1640: getfield mContainer : Landroid/view/ViewGroup;
    //   1643: astore #12
    //   1645: aload #12
    //   1647: ifnull -> 1743
    //   1650: aload #12
    //   1652: aload #11
    //   1654: invokevirtual endViewTransition : (Landroid/view/View;)V
    //   1657: aload_1
    //   1658: getfield mView : Landroid/view/View;
    //   1661: invokevirtual clearAnimation : ()V
    //   1664: aload_0
    //   1665: getfield m : I
    //   1668: ifle -> 1711
    //   1671: aload_0
    //   1672: getfield u : Z
    //   1675: ifne -> 1711
    //   1678: aload_1
    //   1679: getfield mView : Landroid/view/View;
    //   1682: invokevirtual getVisibility : ()I
    //   1685: ifne -> 1711
    //   1688: aload_1
    //   1689: getfield mPostponedAlpha : F
    //   1692: fconst_0
    //   1693: fcmpl
    //   1694: iflt -> 1711
    //   1697: aload_0
    //   1698: aload_1
    //   1699: iload_3
    //   1700: iconst_0
    //   1701: iload #4
    //   1703: invokevirtual w0 : (Landroidx/fragment/app/Fragment;IZI)Landroidx/fragment/app/h$g;
    //   1706: astore #11
    //   1708: goto -> 1714
    //   1711: aconst_null
    //   1712: astore #11
    //   1714: aload_1
    //   1715: fconst_0
    //   1716: putfield mPostponedAlpha : F
    //   1719: aload #11
    //   1721: ifnull -> 1732
    //   1724: aload_0
    //   1725: aload_1
    //   1726: aload #11
    //   1728: iload_2
    //   1729: invokespecial l : (Landroidx/fragment/app/Fragment;Landroidx/fragment/app/h$g;I)V
    //   1732: aload_1
    //   1733: getfield mContainer : Landroid/view/ViewGroup;
    //   1736: aload_1
    //   1737: getfield mView : Landroid/view/View;
    //   1740: invokevirtual removeView : (Landroid/view/View;)V
    //   1743: aload_1
    //   1744: aconst_null
    //   1745: putfield mContainer : Landroid/view/ViewGroup;
    //   1748: aload_1
    //   1749: aconst_null
    //   1750: putfield mView : Landroid/view/View;
    //   1753: aload_1
    //   1754: aconst_null
    //   1755: putfield mViewLifecycleOwner : Landroidx/lifecycle/j;
    //   1758: aload_1
    //   1759: getfield mViewLifecycleOwnerLiveData : Landroidx/lifecycle/p;
    //   1762: aconst_null
    //   1763: invokevirtual h : (Ljava/lang/Object;)V
    //   1766: aload_1
    //   1767: aconst_null
    //   1768: putfield mInnerView : Landroid/view/View;
    //   1771: aload_1
    //   1772: iconst_0
    //   1773: putfield mInLayout : Z
    //   1776: iload_2
    //   1777: istore #6
    //   1779: iload_2
    //   1780: iconst_1
    //   1781: if_icmpge -> 1994
    //   1784: aload_0
    //   1785: getfield u : Z
    //   1788: ifeq -> 1840
    //   1791: aload_1
    //   1792: invokevirtual getAnimatingAway : ()Landroid/view/View;
    //   1795: ifnull -> 1817
    //   1798: aload_1
    //   1799: invokevirtual getAnimatingAway : ()Landroid/view/View;
    //   1802: astore #11
    //   1804: aload_1
    //   1805: aconst_null
    //   1806: invokevirtual setAnimatingAway : (Landroid/view/View;)V
    //   1809: aload #11
    //   1811: invokevirtual clearAnimation : ()V
    //   1814: goto -> 1840
    //   1817: aload_1
    //   1818: invokevirtual getAnimator : ()Landroid/animation/Animator;
    //   1821: ifnull -> 1840
    //   1824: aload_1
    //   1825: invokevirtual getAnimator : ()Landroid/animation/Animator;
    //   1828: astore #11
    //   1830: aload_1
    //   1831: aconst_null
    //   1832: invokevirtual setAnimator : (Landroid/animation/Animator;)V
    //   1835: aload #11
    //   1837: invokevirtual cancel : ()V
    //   1840: aload_1
    //   1841: invokevirtual getAnimatingAway : ()Landroid/view/View;
    //   1844: ifnonnull -> 1982
    //   1847: aload_1
    //   1848: invokevirtual getAnimator : ()Landroid/animation/Animator;
    //   1851: ifnull -> 1857
    //   1854: goto -> 1982
    //   1857: getstatic androidx/fragment/app/h.F : Z
    //   1860: ifeq -> 1900
    //   1863: new java/lang/StringBuilder
    //   1866: dup
    //   1867: invokespecial <init> : ()V
    //   1870: astore #11
    //   1872: aload #11
    //   1874: ldc_w 'movefrom CREATED: '
    //   1877: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   1880: pop
    //   1881: aload #11
    //   1883: aload_1
    //   1884: invokevirtual append : (Ljava/lang/Object;)Ljava/lang/StringBuilder;
    //   1887: pop
    //   1888: ldc_w 'FragmentManager'
    //   1891: aload #11
    //   1893: invokevirtual toString : ()Ljava/lang/String;
    //   1896: invokestatic v : (Ljava/lang/String;Ljava/lang/String;)I
    //   1899: pop
    //   1900: aload_1
    //   1901: getfield mRetaining : Z
    //   1904: ifne -> 1920
    //   1907: aload_1
    //   1908: invokevirtual performDestroy : ()V
    //   1911: aload_0
    //   1912: aload_1
    //   1913: iconst_0
    //   1914: invokevirtual G : (Landroidx/fragment/app/Fragment;Z)V
    //   1917: goto -> 1925
    //   1920: aload_1
    //   1921: iconst_0
    //   1922: putfield mState : I
    //   1925: aload_1
    //   1926: invokevirtual performDetach : ()V
    //   1929: aload_0
    //   1930: aload_1
    //   1931: iconst_0
    //   1932: invokevirtual H : (Landroidx/fragment/app/Fragment;Z)V
    //   1935: iload_2
    //   1936: istore #6
    //   1938: iload #5
    //   1940: ifne -> 1994
    //   1943: aload_1
    //   1944: getfield mRetaining : Z
    //   1947: ifne -> 1961
    //   1950: aload_0
    //   1951: aload_1
    //   1952: invokevirtual z0 : (Landroidx/fragment/app/Fragment;)V
    //   1955: iload_2
    //   1956: istore #6
    //   1958: goto -> 1994
    //   1961: aload_1
    //   1962: aconst_null
    //   1963: putfield mHost : Landroidx/fragment/app/f;
    //   1966: aload_1
    //   1967: aconst_null
    //   1968: putfield mParentFragment : Landroidx/fragment/app/Fragment;
    //   1971: aload_1
    //   1972: aconst_null
    //   1973: putfield mFragmentManager : Landroidx/fragment/app/h;
    //   1976: iload_2
    //   1977: istore #6
    //   1979: goto -> 1994
    //   1982: aload_1
    //   1983: iload_2
    //   1984: invokevirtual setStateAfterAnimating : (I)V
    //   1987: iload #7
    //   1989: istore #6
    //   1991: goto -> 1994
    //   1994: aload_1
    //   1995: getfield mState : I
    //   1998: iload #6
    //   2000: if_icmpeq -> 2091
    //   2003: new java/lang/StringBuilder
    //   2006: dup
    //   2007: invokespecial <init> : ()V
    //   2010: astore #11
    //   2012: aload #11
    //   2014: ldc_w 'moveToState: Fragment state for '
    //   2017: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   2020: pop
    //   2021: aload #11
    //   2023: aload_1
    //   2024: invokevirtual append : (Ljava/lang/Object;)Ljava/lang/StringBuilder;
    //   2027: pop
    //   2028: aload #11
    //   2030: ldc_w ' not updated inline; '
    //   2033: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   2036: pop
    //   2037: aload #11
    //   2039: ldc_w 'expected state '
    //   2042: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   2045: pop
    //   2046: aload #11
    //   2048: iload #6
    //   2050: invokevirtual append : (I)Ljava/lang/StringBuilder;
    //   2053: pop
    //   2054: aload #11
    //   2056: ldc_w ' found '
    //   2059: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   2062: pop
    //   2063: aload #11
    //   2065: aload_1
    //   2066: getfield mState : I
    //   2069: invokevirtual append : (I)Ljava/lang/StringBuilder;
    //   2072: pop
    //   2073: ldc_w 'FragmentManager'
    //   2076: aload #11
    //   2078: invokevirtual toString : ()Ljava/lang/String;
    //   2081: invokestatic w : (Ljava/lang/String;Ljava/lang/String;)I
    //   2084: pop
    //   2085: aload_1
    //   2086: iload #6
    //   2088: putfield mState : I
    //   2091: return
    //   2092: astore #11
    //   2094: goto -> 963
    // Exception table:
    //   from	to	target	type
    //   947	960	2092	android/content/res/Resources$NotFoundException
  }
  
  void I(Fragment paramFragment, boolean paramBoolean) {
    Fragment fragment = this.p;
    if (fragment != null) {
      g g1 = fragment.getFragmentManager();
      if (g1 instanceof h)
        ((h)g1).I(paramFragment, true); 
    } 
    Iterator<j> iterator = this.l.iterator();
    while (iterator.hasNext()) {
      j j = iterator.next();
      if (paramBoolean && !j.b)
        continue; 
      g.a a = j.a;
      throw null;
    } 
  }
  
  public void I0() {
    this.D = null;
    int j = 0;
    this.s = false;
    this.t = false;
    int k = this.e.size();
    while (j < k) {
      Fragment fragment = this.e.get(j);
      if (fragment != null)
        fragment.noteStateNotSaved(); 
      j++;
    } 
  }
  
  void J(Fragment paramFragment, Context paramContext, boolean paramBoolean) {
    Fragment fragment = this.p;
    if (fragment != null) {
      g g1 = fragment.getFragmentManager();
      if (g1 instanceof h)
        ((h)g1).J(paramFragment, paramContext, true); 
    } 
    Iterator<j> iterator = this.l.iterator();
    while (iterator.hasNext()) {
      j j = iterator.next();
      if (paramBoolean && !j.b)
        continue; 
      g.a a = j.a;
      throw null;
    } 
  }
  
  public void J0(Fragment paramFragment) {
    if (paramFragment.mDeferStart) {
      if (this.c) {
        this.w = true;
        return;
      } 
      paramFragment.mDeferStart = false;
      H0(paramFragment, this.m, 0, 0, false);
    } 
  }
  
  void K(Fragment paramFragment, Bundle paramBundle, boolean paramBoolean) {
    Fragment fragment = this.p;
    if (fragment != null) {
      g g1 = fragment.getFragmentManager();
      if (g1 instanceof h)
        ((h)g1).K(paramFragment, paramBundle, true); 
    } 
    Iterator<j> iterator = this.l.iterator();
    while (iterator.hasNext()) {
      j j = iterator.next();
      if (paramBoolean && !j.b)
        continue; 
      g.a a = j.a;
      throw null;
    } 
  }
  
  void L(Fragment paramFragment, boolean paramBoolean) {
    Fragment fragment = this.p;
    if (fragment != null) {
      g g1 = fragment.getFragmentManager();
      if (g1 instanceof h)
        ((h)g1).L(paramFragment, true); 
    } 
    Iterator<j> iterator = this.l.iterator();
    while (iterator.hasNext()) {
      j j = iterator.next();
      if (paramBoolean && !j.b)
        continue; 
      g.a a = j.a;
      throw null;
    } 
  }
  
  boolean L0(ArrayList<a> paramArrayList, ArrayList<Boolean> paramArrayList1, String paramString, int paramInt1, int paramInt2) {
    // Byte code:
    //   0: aload_0
    //   1: getfield g : Ljava/util/ArrayList;
    //   4: astore #8
    //   6: aload #8
    //   8: ifnonnull -> 13
    //   11: iconst_0
    //   12: ireturn
    //   13: aload_3
    //   14: ifnonnull -> 69
    //   17: iload #4
    //   19: ifge -> 69
    //   22: iload #5
    //   24: iconst_1
    //   25: iand
    //   26: ifne -> 69
    //   29: aload #8
    //   31: invokevirtual size : ()I
    //   34: iconst_1
    //   35: isub
    //   36: istore #4
    //   38: iload #4
    //   40: ifge -> 45
    //   43: iconst_0
    //   44: ireturn
    //   45: aload_1
    //   46: aload_0
    //   47: getfield g : Ljava/util/ArrayList;
    //   50: iload #4
    //   52: invokevirtual remove : (I)Ljava/lang/Object;
    //   55: invokevirtual add : (Ljava/lang/Object;)Z
    //   58: pop
    //   59: aload_2
    //   60: getstatic java/lang/Boolean.TRUE : Ljava/lang/Boolean;
    //   63: invokevirtual add : (Ljava/lang/Object;)Z
    //   66: pop
    //   67: iconst_1
    //   68: ireturn
    //   69: aload_3
    //   70: ifnonnull -> 87
    //   73: iload #4
    //   75: iflt -> 81
    //   78: goto -> 87
    //   81: iconst_m1
    //   82: istore #4
    //   84: goto -> 262
    //   87: aload #8
    //   89: invokevirtual size : ()I
    //   92: iconst_1
    //   93: isub
    //   94: istore #6
    //   96: iload #6
    //   98: iflt -> 161
    //   101: aload_0
    //   102: getfield g : Ljava/util/ArrayList;
    //   105: iload #6
    //   107: invokevirtual get : (I)Ljava/lang/Object;
    //   110: checkcast androidx/fragment/app/a
    //   113: astore #8
    //   115: aload_3
    //   116: ifnull -> 134
    //   119: aload_3
    //   120: aload #8
    //   122: invokevirtual q : ()Ljava/lang/String;
    //   125: invokevirtual equals : (Ljava/lang/Object;)Z
    //   128: ifeq -> 134
    //   131: goto -> 161
    //   134: iload #4
    //   136: iflt -> 152
    //   139: iload #4
    //   141: aload #8
    //   143: getfield m : I
    //   146: if_icmpne -> 152
    //   149: goto -> 161
    //   152: iload #6
    //   154: iconst_1
    //   155: isub
    //   156: istore #6
    //   158: goto -> 96
    //   161: iload #6
    //   163: ifge -> 168
    //   166: iconst_0
    //   167: ireturn
    //   168: iload #6
    //   170: istore #7
    //   172: iload #5
    //   174: iconst_1
    //   175: iand
    //   176: ifeq -> 258
    //   179: iload #6
    //   181: iconst_1
    //   182: isub
    //   183: istore #5
    //   185: iload #5
    //   187: istore #7
    //   189: iload #5
    //   191: iflt -> 258
    //   194: aload_0
    //   195: getfield g : Ljava/util/ArrayList;
    //   198: iload #5
    //   200: invokevirtual get : (I)Ljava/lang/Object;
    //   203: checkcast androidx/fragment/app/a
    //   206: astore #8
    //   208: aload_3
    //   209: ifnull -> 228
    //   212: iload #5
    //   214: istore #6
    //   216: aload_3
    //   217: aload #8
    //   219: invokevirtual q : ()Ljava/lang/String;
    //   222: invokevirtual equals : (Ljava/lang/Object;)Z
    //   225: ifne -> 179
    //   228: iload #5
    //   230: istore #7
    //   232: iload #4
    //   234: iflt -> 258
    //   237: iload #5
    //   239: istore #7
    //   241: iload #4
    //   243: aload #8
    //   245: getfield m : I
    //   248: if_icmpne -> 258
    //   251: iload #5
    //   253: istore #6
    //   255: goto -> 179
    //   258: iload #7
    //   260: istore #4
    //   262: iload #4
    //   264: aload_0
    //   265: getfield g : Ljava/util/ArrayList;
    //   268: invokevirtual size : ()I
    //   271: iconst_1
    //   272: isub
    //   273: if_icmpne -> 278
    //   276: iconst_0
    //   277: ireturn
    //   278: aload_0
    //   279: getfield g : Ljava/util/ArrayList;
    //   282: invokevirtual size : ()I
    //   285: iconst_1
    //   286: isub
    //   287: istore #5
    //   289: iload #5
    //   291: iload #4
    //   293: if_icmple -> 327
    //   296: aload_1
    //   297: aload_0
    //   298: getfield g : Ljava/util/ArrayList;
    //   301: iload #5
    //   303: invokevirtual remove : (I)Ljava/lang/Object;
    //   306: invokevirtual add : (Ljava/lang/Object;)Z
    //   309: pop
    //   310: aload_2
    //   311: getstatic java/lang/Boolean.TRUE : Ljava/lang/Boolean;
    //   314: invokevirtual add : (Ljava/lang/Object;)Z
    //   317: pop
    //   318: iload #5
    //   320: iconst_1
    //   321: isub
    //   322: istore #5
    //   324: goto -> 289
    //   327: iconst_1
    //   328: ireturn
  }
  
  void M(Fragment paramFragment, Bundle paramBundle, boolean paramBoolean) {
    Fragment fragment = this.p;
    if (fragment != null) {
      g g1 = fragment.getFragmentManager();
      if (g1 instanceof h)
        ((h)g1).M(paramFragment, paramBundle, true); 
    } 
    Iterator<j> iterator = this.l.iterator();
    while (iterator.hasNext()) {
      j j = iterator.next();
      if (paramBoolean && !j.b)
        continue; 
      g.a a = j.a;
      throw null;
    } 
  }
  
  void N(Fragment paramFragment, boolean paramBoolean) {
    Fragment fragment = this.p;
    if (fragment != null) {
      g g1 = fragment.getFragmentManager();
      if (g1 instanceof h)
        ((h)g1).N(paramFragment, true); 
    } 
    Iterator<j> iterator = this.l.iterator();
    while (iterator.hasNext()) {
      j j = iterator.next();
      if (paramBoolean && !j.b)
        continue; 
      g.a a = j.a;
      throw null;
    } 
  }
  
  public void N0(Bundle paramBundle, String paramString, Fragment paramFragment) {
    if (paramFragment.mIndex < 0) {
      StringBuilder stringBuilder = new StringBuilder();
      stringBuilder.append("Fragment ");
      stringBuilder.append(paramFragment);
      stringBuilder.append(" is not currently in the FragmentManager");
      g1(new IllegalStateException(stringBuilder.toString()));
    } 
    paramBundle.putInt(paramString, paramFragment.mIndex);
  }
  
  void O(Fragment paramFragment, boolean paramBoolean) {
    Fragment fragment = this.p;
    if (fragment != null) {
      g g1 = fragment.getFragmentManager();
      if (g1 instanceof h)
        ((h)g1).O(paramFragment, true); 
    } 
    Iterator<j> iterator = this.l.iterator();
    while (iterator.hasNext()) {
      j j = iterator.next();
      if (paramBoolean && !j.b)
        continue; 
      g.a a = j.a;
      throw null;
    } 
  }
  
  public void O0(Fragment paramFragment) {
    if (F) {
      StringBuilder stringBuilder = new StringBuilder();
      stringBuilder.append("remove: ");
      stringBuilder.append(paramFragment);
      stringBuilder.append(" nesting=");
      stringBuilder.append(paramFragment.mBackStackNesting);
      Log.v("FragmentManager", stringBuilder.toString());
    } 
    boolean bool = paramFragment.isInBackStack();
    if (!paramFragment.mDetached || (bool ^ true) != 0)
      synchronized (this.e) {
        this.e.remove(paramFragment);
        if (paramFragment.mHasMenu && paramFragment.mMenuVisible)
          this.r = true; 
        paramFragment.mAdded = false;
        paramFragment.mRemoving = true;
        return;
      }  
  }
  
  void P(Fragment paramFragment, View paramView, Bundle paramBundle, boolean paramBoolean) {
    Fragment fragment = this.p;
    if (fragment != null) {
      g g1 = fragment.getFragmentManager();
      if (g1 instanceof h)
        ((h)g1).P(paramFragment, paramView, paramBundle, true); 
    } 
    Iterator<j> iterator = this.l.iterator();
    while (iterator.hasNext()) {
      j j = iterator.next();
      if (paramBoolean && !j.b)
        continue; 
      g.a a = j.a;
      throw null;
    } 
  }
  
  void Q(Fragment paramFragment, boolean paramBoolean) {
    Fragment fragment = this.p;
    if (fragment != null) {
      g g1 = fragment.getFragmentManager();
      if (g1 instanceof h)
        ((h)g1).Q(paramFragment, true); 
    } 
    Iterator<j> iterator = this.l.iterator();
    while (iterator.hasNext()) {
      j j = iterator.next();
      if (paramBoolean && !j.b)
        continue; 
      g.a a = j.a;
      throw null;
    } 
  }
  
  void Q0() {
    if (this.k != null)
      for (int j = 0; j < this.k.size(); j++)
        ((g.b)this.k.get(j)).a();  
  }
  
  public boolean R(MenuItem paramMenuItem) {
    if (this.m < 1)
      return false; 
    for (int j = 0; j < this.e.size(); j++) {
      Fragment fragment = this.e.get(j);
      if (fragment != null && fragment.performOptionsItemSelected(paramMenuItem))
        return true; 
    } 
    return false;
  }
  
  void R0(Parcelable<i> paramParcelable, i parami) {
    // Byte code:
    //   0: aload_1
    //   1: ifnonnull -> 5
    //   4: return
    //   5: aload_1
    //   6: checkcast androidx/fragment/app/FragmentManagerState
    //   9: astore #9
    //   11: aload #9
    //   13: getfield b : [Landroidx/fragment/app/FragmentState;
    //   16: ifnonnull -> 20
    //   19: return
    //   20: aload_2
    //   21: ifnull -> 327
    //   24: aload_2
    //   25: invokevirtual b : ()Ljava/util/List;
    //   28: astore #10
    //   30: aload_2
    //   31: invokevirtual a : ()Ljava/util/List;
    //   34: astore #7
    //   36: aload_2
    //   37: invokevirtual c : ()Ljava/util/List;
    //   40: astore #8
    //   42: aload #10
    //   44: ifnull -> 58
    //   47: aload #10
    //   49: invokeinterface size : ()I
    //   54: istore_3
    //   55: goto -> 60
    //   58: iconst_0
    //   59: istore_3
    //   60: iconst_0
    //   61: istore #4
    //   63: aload #7
    //   65: astore #6
    //   67: aload #8
    //   69: astore_1
    //   70: iload #4
    //   72: iload_3
    //   73: if_icmpge -> 333
    //   76: aload #10
    //   78: iload #4
    //   80: invokeinterface get : (I)Ljava/lang/Object;
    //   85: checkcast androidx/fragment/app/Fragment
    //   88: astore_1
    //   89: getstatic androidx/fragment/app/h.F : Z
    //   92: ifeq -> 132
    //   95: new java/lang/StringBuilder
    //   98: dup
    //   99: invokespecial <init> : ()V
    //   102: astore #6
    //   104: aload #6
    //   106: ldc_w 'restoreAllState: re-attaching retained '
    //   109: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   112: pop
    //   113: aload #6
    //   115: aload_1
    //   116: invokevirtual append : (Ljava/lang/Object;)Ljava/lang/StringBuilder;
    //   119: pop
    //   120: ldc_w 'FragmentManager'
    //   123: aload #6
    //   125: invokevirtual toString : ()Ljava/lang/String;
    //   128: invokestatic v : (Ljava/lang/String;Ljava/lang/String;)I
    //   131: pop
    //   132: iconst_0
    //   133: istore #5
    //   135: aload #9
    //   137: getfield b : [Landroidx/fragment/app/FragmentState;
    //   140: astore #6
    //   142: iload #5
    //   144: aload #6
    //   146: arraylength
    //   147: if_icmpge -> 174
    //   150: aload #6
    //   152: iload #5
    //   154: aaload
    //   155: getfield c : I
    //   158: aload_1
    //   159: getfield mIndex : I
    //   162: if_icmpeq -> 174
    //   165: iload #5
    //   167: iconst_1
    //   168: iadd
    //   169: istore #5
    //   171: goto -> 135
    //   174: iload #5
    //   176: aload #6
    //   178: arraylength
    //   179: if_icmpne -> 226
    //   182: new java/lang/StringBuilder
    //   185: dup
    //   186: invokespecial <init> : ()V
    //   189: astore #6
    //   191: aload #6
    //   193: ldc_w 'Could not find active fragment with index '
    //   196: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   199: pop
    //   200: aload #6
    //   202: aload_1
    //   203: getfield mIndex : I
    //   206: invokevirtual append : (I)Ljava/lang/StringBuilder;
    //   209: pop
    //   210: aload_0
    //   211: new java/lang/IllegalStateException
    //   214: dup
    //   215: aload #6
    //   217: invokevirtual toString : ()Ljava/lang/String;
    //   220: invokespecial <init> : (Ljava/lang/String;)V
    //   223: invokespecial g1 : (Ljava/lang/RuntimeException;)V
    //   226: aload #9
    //   228: getfield b : [Landroidx/fragment/app/FragmentState;
    //   231: iload #5
    //   233: aaload
    //   234: astore #6
    //   236: aload #6
    //   238: aload_1
    //   239: putfield m : Landroidx/fragment/app/Fragment;
    //   242: aload_1
    //   243: aconst_null
    //   244: putfield mSavedViewState : Landroid/util/SparseArray;
    //   247: aload_1
    //   248: iconst_0
    //   249: putfield mBackStackNesting : I
    //   252: aload_1
    //   253: iconst_0
    //   254: putfield mInLayout : Z
    //   257: aload_1
    //   258: iconst_0
    //   259: putfield mAdded : Z
    //   262: aload_1
    //   263: aconst_null
    //   264: putfield mTarget : Landroidx/fragment/app/Fragment;
    //   267: aload #6
    //   269: getfield l : Landroid/os/Bundle;
    //   272: astore #11
    //   274: aload #11
    //   276: ifnull -> 318
    //   279: aload #11
    //   281: aload_0
    //   282: getfield n : Landroidx/fragment/app/f;
    //   285: invokevirtual e : ()Landroid/content/Context;
    //   288: invokevirtual getClassLoader : ()Ljava/lang/ClassLoader;
    //   291: invokevirtual setClassLoader : (Ljava/lang/ClassLoader;)V
    //   294: aload_1
    //   295: aload #6
    //   297: getfield l : Landroid/os/Bundle;
    //   300: ldc_w 'android:view_state'
    //   303: invokevirtual getSparseParcelableArray : (Ljava/lang/String;)Landroid/util/SparseArray;
    //   306: putfield mSavedViewState : Landroid/util/SparseArray;
    //   309: aload_1
    //   310: aload #6
    //   312: getfield l : Landroid/os/Bundle;
    //   315: putfield mSavedFragmentState : Landroid/os/Bundle;
    //   318: iload #4
    //   320: iconst_1
    //   321: iadd
    //   322: istore #4
    //   324: goto -> 63
    //   327: aconst_null
    //   328: astore #6
    //   330: aload #6
    //   332: astore_1
    //   333: aload_0
    //   334: new android/util/SparseArray
    //   337: dup
    //   338: aload #9
    //   340: getfield b : [Landroidx/fragment/app/FragmentState;
    //   343: arraylength
    //   344: invokespecial <init> : (I)V
    //   347: putfield f : Landroid/util/SparseArray;
    //   350: iconst_0
    //   351: istore_3
    //   352: aload #9
    //   354: getfield b : [Landroidx/fragment/app/FragmentState;
    //   357: astore #7
    //   359: iload_3
    //   360: aload #7
    //   362: arraylength
    //   363: if_icmpge -> 554
    //   366: aload #7
    //   368: iload_3
    //   369: aaload
    //   370: astore #10
    //   372: aload #10
    //   374: ifnull -> 547
    //   377: aload #6
    //   379: ifnull -> 409
    //   382: iload_3
    //   383: aload #6
    //   385: invokeinterface size : ()I
    //   390: if_icmpge -> 409
    //   393: aload #6
    //   395: iload_3
    //   396: invokeinterface get : (I)Ljava/lang/Object;
    //   401: checkcast androidx/fragment/app/i
    //   404: astore #7
    //   406: goto -> 412
    //   409: aconst_null
    //   410: astore #7
    //   412: aload_1
    //   413: ifnull -> 441
    //   416: iload_3
    //   417: aload_1
    //   418: invokeinterface size : ()I
    //   423: if_icmpge -> 441
    //   426: aload_1
    //   427: iload_3
    //   428: invokeinterface get : (I)Ljava/lang/Object;
    //   433: checkcast androidx/lifecycle/x
    //   436: astore #8
    //   438: goto -> 444
    //   441: aconst_null
    //   442: astore #8
    //   444: aload #10
    //   446: aload_0
    //   447: getfield n : Landroidx/fragment/app/f;
    //   450: aload_0
    //   451: getfield o : Landroidx/fragment/app/d;
    //   454: aload_0
    //   455: getfield p : Landroidx/fragment/app/Fragment;
    //   458: aload #7
    //   460: aload #8
    //   462: invokevirtual a : (Landroidx/fragment/app/f;Landroidx/fragment/app/d;Landroidx/fragment/app/Fragment;Landroidx/fragment/app/i;Landroidx/lifecycle/x;)Landroidx/fragment/app/Fragment;
    //   465: astore #7
    //   467: getstatic androidx/fragment/app/h.F : Z
    //   470: ifeq -> 527
    //   473: new java/lang/StringBuilder
    //   476: dup
    //   477: invokespecial <init> : ()V
    //   480: astore #8
    //   482: aload #8
    //   484: ldc_w 'restoreAllState: active #'
    //   487: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   490: pop
    //   491: aload #8
    //   493: iload_3
    //   494: invokevirtual append : (I)Ljava/lang/StringBuilder;
    //   497: pop
    //   498: aload #8
    //   500: ldc_w ': '
    //   503: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   506: pop
    //   507: aload #8
    //   509: aload #7
    //   511: invokevirtual append : (Ljava/lang/Object;)Ljava/lang/StringBuilder;
    //   514: pop
    //   515: ldc_w 'FragmentManager'
    //   518: aload #8
    //   520: invokevirtual toString : ()Ljava/lang/String;
    //   523: invokestatic v : (Ljava/lang/String;Ljava/lang/String;)I
    //   526: pop
    //   527: aload_0
    //   528: getfield f : Landroid/util/SparseArray;
    //   531: aload #7
    //   533: getfield mIndex : I
    //   536: aload #7
    //   538: invokevirtual put : (ILjava/lang/Object;)V
    //   541: aload #10
    //   543: aconst_null
    //   544: putfield m : Landroidx/fragment/app/Fragment;
    //   547: iload_3
    //   548: iconst_1
    //   549: iadd
    //   550: istore_3
    //   551: goto -> 352
    //   554: aload_2
    //   555: ifnull -> 701
    //   558: aload_2
    //   559: invokevirtual b : ()Ljava/util/List;
    //   562: astore_1
    //   563: aload_1
    //   564: ifnull -> 577
    //   567: aload_1
    //   568: invokeinterface size : ()I
    //   573: istore_3
    //   574: goto -> 579
    //   577: iconst_0
    //   578: istore_3
    //   579: iconst_0
    //   580: istore #4
    //   582: iload #4
    //   584: iload_3
    //   585: if_icmpge -> 701
    //   588: aload_1
    //   589: iload #4
    //   591: invokeinterface get : (I)Ljava/lang/Object;
    //   596: checkcast androidx/fragment/app/Fragment
    //   599: astore_2
    //   600: aload_2
    //   601: getfield mTargetIndex : I
    //   604: istore #5
    //   606: iload #5
    //   608: iflt -> 692
    //   611: aload_0
    //   612: getfield f : Landroid/util/SparseArray;
    //   615: iload #5
    //   617: invokevirtual get : (I)Ljava/lang/Object;
    //   620: checkcast androidx/fragment/app/Fragment
    //   623: astore #6
    //   625: aload_2
    //   626: aload #6
    //   628: putfield mTarget : Landroidx/fragment/app/Fragment;
    //   631: aload #6
    //   633: ifnonnull -> 692
    //   636: new java/lang/StringBuilder
    //   639: dup
    //   640: invokespecial <init> : ()V
    //   643: astore #6
    //   645: aload #6
    //   647: ldc_w 'Re-attaching retained fragment '
    //   650: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   653: pop
    //   654: aload #6
    //   656: aload_2
    //   657: invokevirtual append : (Ljava/lang/Object;)Ljava/lang/StringBuilder;
    //   660: pop
    //   661: aload #6
    //   663: ldc_w ' target no longer exists: '
    //   666: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   669: pop
    //   670: aload #6
    //   672: aload_2
    //   673: getfield mTargetIndex : I
    //   676: invokevirtual append : (I)Ljava/lang/StringBuilder;
    //   679: pop
    //   680: ldc_w 'FragmentManager'
    //   683: aload #6
    //   685: invokevirtual toString : ()Ljava/lang/String;
    //   688: invokestatic w : (Ljava/lang/String;Ljava/lang/String;)I
    //   691: pop
    //   692: iload #4
    //   694: iconst_1
    //   695: iadd
    //   696: istore #4
    //   698: goto -> 582
    //   701: aload_0
    //   702: getfield e : Ljava/util/ArrayList;
    //   705: invokevirtual clear : ()V
    //   708: aload #9
    //   710: getfield c : [I
    //   713: ifnull -> 901
    //   716: iconst_0
    //   717: istore_3
    //   718: aload #9
    //   720: getfield c : [I
    //   723: astore_1
    //   724: iload_3
    //   725: aload_1
    //   726: arraylength
    //   727: if_icmpge -> 901
    //   730: aload_0
    //   731: getfield f : Landroid/util/SparseArray;
    //   734: aload_1
    //   735: iload_3
    //   736: iaload
    //   737: invokevirtual get : (I)Ljava/lang/Object;
    //   740: checkcast androidx/fragment/app/Fragment
    //   743: astore_1
    //   744: aload_1
    //   745: ifnonnull -> 791
    //   748: new java/lang/StringBuilder
    //   751: dup
    //   752: invokespecial <init> : ()V
    //   755: astore_2
    //   756: aload_2
    //   757: ldc_w 'No instantiated fragment for index #'
    //   760: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   763: pop
    //   764: aload_2
    //   765: aload #9
    //   767: getfield c : [I
    //   770: iload_3
    //   771: iaload
    //   772: invokevirtual append : (I)Ljava/lang/StringBuilder;
    //   775: pop
    //   776: aload_0
    //   777: new java/lang/IllegalStateException
    //   780: dup
    //   781: aload_2
    //   782: invokevirtual toString : ()Ljava/lang/String;
    //   785: invokespecial <init> : (Ljava/lang/String;)V
    //   788: invokespecial g1 : (Ljava/lang/RuntimeException;)V
    //   791: aload_1
    //   792: iconst_1
    //   793: putfield mAdded : Z
    //   796: getstatic androidx/fragment/app/h.F : Z
    //   799: ifeq -> 849
    //   802: new java/lang/StringBuilder
    //   805: dup
    //   806: invokespecial <init> : ()V
    //   809: astore_2
    //   810: aload_2
    //   811: ldc_w 'restoreAllState: added #'
    //   814: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   817: pop
    //   818: aload_2
    //   819: iload_3
    //   820: invokevirtual append : (I)Ljava/lang/StringBuilder;
    //   823: pop
    //   824: aload_2
    //   825: ldc_w ': '
    //   828: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   831: pop
    //   832: aload_2
    //   833: aload_1
    //   834: invokevirtual append : (Ljava/lang/Object;)Ljava/lang/StringBuilder;
    //   837: pop
    //   838: ldc_w 'FragmentManager'
    //   841: aload_2
    //   842: invokevirtual toString : ()Ljava/lang/String;
    //   845: invokestatic v : (Ljava/lang/String;Ljava/lang/String;)I
    //   848: pop
    //   849: aload_0
    //   850: getfield e : Ljava/util/ArrayList;
    //   853: aload_1
    //   854: invokevirtual contains : (Ljava/lang/Object;)Z
    //   857: ifne -> 890
    //   860: aload_0
    //   861: getfield e : Ljava/util/ArrayList;
    //   864: astore_2
    //   865: aload_2
    //   866: monitorenter
    //   867: aload_0
    //   868: getfield e : Ljava/util/ArrayList;
    //   871: aload_1
    //   872: invokevirtual add : (Ljava/lang/Object;)Z
    //   875: pop
    //   876: aload_2
    //   877: monitorexit
    //   878: iload_3
    //   879: iconst_1
    //   880: iadd
    //   881: istore_3
    //   882: goto -> 718
    //   885: astore_1
    //   886: aload_2
    //   887: monitorexit
    //   888: aload_1
    //   889: athrow
    //   890: new java/lang/IllegalStateException
    //   893: dup
    //   894: ldc_w 'Already added!'
    //   897: invokespecial <init> : (Ljava/lang/String;)V
    //   900: athrow
    //   901: aload #9
    //   903: getfield d : [Landroidx/fragment/app/BackStackState;
    //   906: ifnull -> 1083
    //   909: aload_0
    //   910: new java/util/ArrayList
    //   913: dup
    //   914: aload #9
    //   916: getfield d : [Landroidx/fragment/app/BackStackState;
    //   919: arraylength
    //   920: invokespecial <init> : (I)V
    //   923: putfield g : Ljava/util/ArrayList;
    //   926: iconst_0
    //   927: istore_3
    //   928: aload #9
    //   930: getfield d : [Landroidx/fragment/app/BackStackState;
    //   933: astore_1
    //   934: iload_3
    //   935: aload_1
    //   936: arraylength
    //   937: if_icmpge -> 1088
    //   940: aload_1
    //   941: iload_3
    //   942: aaload
    //   943: aload_0
    //   944: invokevirtual a : (Landroidx/fragment/app/h;)Landroidx/fragment/app/a;
    //   947: astore_1
    //   948: getstatic androidx/fragment/app/h.F : Z
    //   951: ifeq -> 1049
    //   954: new java/lang/StringBuilder
    //   957: dup
    //   958: invokespecial <init> : ()V
    //   961: astore_2
    //   962: aload_2
    //   963: ldc_w 'restoreAllState: back stack #'
    //   966: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   969: pop
    //   970: aload_2
    //   971: iload_3
    //   972: invokevirtual append : (I)Ljava/lang/StringBuilder;
    //   975: pop
    //   976: aload_2
    //   977: ldc_w ' (index '
    //   980: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   983: pop
    //   984: aload_2
    //   985: aload_1
    //   986: getfield m : I
    //   989: invokevirtual append : (I)Ljava/lang/StringBuilder;
    //   992: pop
    //   993: aload_2
    //   994: ldc_w '): '
    //   997: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   1000: pop
    //   1001: aload_2
    //   1002: aload_1
    //   1003: invokevirtual append : (Ljava/lang/Object;)Ljava/lang/StringBuilder;
    //   1006: pop
    //   1007: ldc_w 'FragmentManager'
    //   1010: aload_2
    //   1011: invokevirtual toString : ()Ljava/lang/String;
    //   1014: invokestatic v : (Ljava/lang/String;Ljava/lang/String;)I
    //   1017: pop
    //   1018: new java/io/PrintWriter
    //   1021: dup
    //   1022: new androidx/core/util/c
    //   1025: dup
    //   1026: ldc_w 'FragmentManager'
    //   1029: invokespecial <init> : (Ljava/lang/String;)V
    //   1032: invokespecial <init> : (Ljava/io/Writer;)V
    //   1035: astore_2
    //   1036: aload_1
    //   1037: ldc_w '  '
    //   1040: aload_2
    //   1041: iconst_0
    //   1042: invokevirtual m : (Ljava/lang/String;Ljava/io/PrintWriter;Z)V
    //   1045: aload_2
    //   1046: invokevirtual close : ()V
    //   1049: aload_0
    //   1050: getfield g : Ljava/util/ArrayList;
    //   1053: aload_1
    //   1054: invokevirtual add : (Ljava/lang/Object;)Z
    //   1057: pop
    //   1058: aload_1
    //   1059: getfield m : I
    //   1062: istore #4
    //   1064: iload #4
    //   1066: iflt -> 1076
    //   1069: aload_0
    //   1070: iload #4
    //   1072: aload_1
    //   1073: invokevirtual Z0 : (ILandroidx/fragment/app/a;)V
    //   1076: iload_3
    //   1077: iconst_1
    //   1078: iadd
    //   1079: istore_3
    //   1080: goto -> 928
    //   1083: aload_0
    //   1084: aconst_null
    //   1085: putfield g : Ljava/util/ArrayList;
    //   1088: aload #9
    //   1090: getfield e : I
    //   1093: istore_3
    //   1094: iload_3
    //   1095: iflt -> 1113
    //   1098: aload_0
    //   1099: aload_0
    //   1100: getfield f : Landroid/util/SparseArray;
    //   1103: iload_3
    //   1104: invokevirtual get : (I)Ljava/lang/Object;
    //   1107: checkcast androidx/fragment/app/Fragment
    //   1110: putfield q : Landroidx/fragment/app/Fragment;
    //   1113: aload_0
    //   1114: aload #9
    //   1116: getfield f : I
    //   1119: putfield d : I
    //   1122: return
    // Exception table:
    //   from	to	target	type
    //   867	878	885	finally
    //   886	888	885	finally
  }
  
  public void S(Menu paramMenu) {
    if (this.m < 1)
      return; 
    for (int j = 0; j < this.e.size(); j++) {
      Fragment fragment = this.e.get(j);
      if (fragment != null)
        fragment.performOptionsMenuClosed(paramMenu); 
    } 
  }
  
  i S0() {
    c1(this.D);
    return this.D;
  }
  
  public void T() {
    Y(3);
  }
  
  public void U(boolean paramBoolean) {
    for (int j = this.e.size() - 1; j >= 0; j--) {
      Fragment fragment = this.e.get(j);
      if (fragment != null)
        fragment.performPictureInPictureModeChanged(paramBoolean); 
    } 
  }
  
  Parcelable U0() {
    n0();
    b0();
    f0();
    this.s = true;
    BackStackState[] arrayOfBackStackState = null;
    this.D = null;
    SparseArray<Fragment> sparseArray = this.f;
    if (sparseArray != null) {
      StringBuilder stringBuilder;
      if (sparseArray.size() <= 0)
        return null; 
      int m = this.f.size();
      FragmentState[] arrayOfFragmentState = new FragmentState[m];
      boolean bool = false;
      int j = 0;
      int k = 0;
      while (j < m) {
        Fragment fragment1 = (Fragment)this.f.valueAt(j);
        if (fragment1 != null) {
          if (fragment1.mIndex < 0) {
            stringBuilder = new StringBuilder();
            stringBuilder.append("Failure saving state: active ");
            stringBuilder.append(fragment1);
            stringBuilder.append(" has cleared index: ");
            stringBuilder.append(fragment1.mIndex);
            g1(new IllegalStateException(stringBuilder.toString()));
          } 
          FragmentState fragmentState = new FragmentState(fragment1);
          arrayOfFragmentState[j] = fragmentState;
          if (fragment1.mState > 0 && fragmentState.l == null) {
            fragmentState.l = V0(fragment1);
            Fragment fragment2 = fragment1.mTarget;
            if (fragment2 != null) {
              if (fragment2.mIndex < 0) {
                StringBuilder stringBuilder1 = new StringBuilder();
                stringBuilder1.append("Failure saving state: ");
                stringBuilder1.append(fragment1);
                stringBuilder1.append(" has target not in fragment manager: ");
                stringBuilder1.append(fragment1.mTarget);
                g1(new IllegalStateException(stringBuilder1.toString()));
              } 
              if (fragmentState.l == null)
                fragmentState.l = new Bundle(); 
              N0(fragmentState.l, "android:target_state", fragment1.mTarget);
              k = fragment1.mTargetRequestCode;
              if (k != 0)
                fragmentState.l.putInt("android:target_req_state", k); 
            } 
          } else {
            fragmentState.l = fragment1.mSavedFragmentState;
          } 
          if (F) {
            StringBuilder stringBuilder1 = new StringBuilder();
            stringBuilder1.append("Saved state of ");
            stringBuilder1.append(fragment1);
            stringBuilder1.append(": ");
            stringBuilder1.append(fragmentState.l);
            Log.v("FragmentManager", stringBuilder1.toString());
          } 
          k = 1;
        } 
        j++;
      } 
      if (k == 0) {
        if (F)
          Log.v("FragmentManager", "saveAllState: no fragments!"); 
        return null;
      } 
      k = this.e.size();
      if (k > 0) {
        int[] arrayOfInt = new int[k];
        j = 0;
        while (true) {
          int[] arrayOfInt1 = arrayOfInt;
          if (j < k) {
            arrayOfInt[j] = ((Fragment)this.e.get(j)).mIndex;
            if (arrayOfInt[j] < 0) {
              StringBuilder stringBuilder1 = new StringBuilder();
              stringBuilder1.append("Failure saving state: active ");
              stringBuilder1.append(this.e.get(j));
              stringBuilder1.append(" has cleared index: ");
              stringBuilder1.append(arrayOfInt[j]);
              g1(new IllegalStateException(stringBuilder1.toString()));
            } 
            if (F) {
              StringBuilder stringBuilder1 = new StringBuilder();
              stringBuilder1.append("saveAllState: adding fragment #");
              stringBuilder1.append(j);
              stringBuilder1.append(": ");
              stringBuilder1.append(this.e.get(j));
              Log.v("FragmentManager", stringBuilder1.toString());
            } 
            j++;
            continue;
          } 
          break;
        } 
      } else {
        sparseArray = null;
      } 
      ArrayList<a> arrayList = this.g;
      BackStackState[] arrayOfBackStackState1 = arrayOfBackStackState;
      if (arrayList != null) {
        k = arrayList.size();
        arrayOfBackStackState1 = arrayOfBackStackState;
        if (k > 0) {
          arrayOfBackStackState = new BackStackState[k];
          j = bool;
          while (true) {
            arrayOfBackStackState1 = arrayOfBackStackState;
            if (j < k) {
              arrayOfBackStackState[j] = new BackStackState(this.g.get(j));
              if (F) {
                stringBuilder = new StringBuilder();
                stringBuilder.append("saveAllState: adding back stack #");
                stringBuilder.append(j);
                stringBuilder.append(": ");
                stringBuilder.append(this.g.get(j));
                Log.v("FragmentManager", stringBuilder.toString());
              } 
              j++;
              continue;
            } 
            break;
          } 
        } 
      } 
      FragmentManagerState fragmentManagerState = new FragmentManagerState();
      fragmentManagerState.b = arrayOfFragmentState;
      fragmentManagerState.c = (int[])sparseArray;
      fragmentManagerState.d = (BackStackState[])stringBuilder;
      Fragment fragment = this.q;
      if (fragment != null)
        fragmentManagerState.e = fragment.mIndex; 
      fragmentManagerState.f = this.d;
      X0();
      return fragmentManagerState;
    } 
    return null;
  }
  
  public boolean V(Menu paramMenu) {
    int k = this.m;
    int j = 0;
    if (k < 1)
      return false; 
    boolean bool;
    for (bool = false; j < this.e.size(); bool = bool1) {
      Fragment fragment = this.e.get(j);
      boolean bool1 = bool;
      if (fragment != null) {
        bool1 = bool;
        if (fragment.performPrepareOptionsMenu(paramMenu))
          bool1 = true; 
      } 
      j++;
    } 
    return bool;
  }
  
  Bundle V0(Fragment paramFragment) {
    if (this.A == null)
      this.A = new Bundle(); 
    paramFragment.performSaveInstanceState(this.A);
    M(paramFragment, this.A, false);
    boolean bool = this.A.isEmpty();
    Bundle bundle2 = null;
    if (!bool) {
      bundle2 = this.A;
      this.A = null;
    } 
    if (paramFragment.mView != null)
      W0(paramFragment); 
    Bundle bundle1 = bundle2;
    if (paramFragment.mSavedViewState != null) {
      bundle1 = bundle2;
      if (bundle2 == null)
        bundle1 = new Bundle(); 
      bundle1.putSparseParcelableArray("android:view_state", paramFragment.mSavedViewState);
    } 
    bundle2 = bundle1;
    if (!paramFragment.mUserVisibleHint) {
      bundle2 = bundle1;
      if (bundle1 == null)
        bundle2 = new Bundle(); 
      bundle2.putBoolean("android:user_visible_hint", paramFragment.mUserVisibleHint);
    } 
    return bundle2;
  }
  
  public void W() {
    this.s = false;
    this.t = false;
    Y(4);
  }
  
  void W0(Fragment paramFragment) {
    if (paramFragment.mInnerView == null)
      return; 
    SparseArray<Parcelable> sparseArray = this.B;
    if (sparseArray == null) {
      this.B = new SparseArray();
    } else {
      sparseArray.clear();
    } 
    paramFragment.mInnerView.saveHierarchyState(this.B);
    if (this.B.size() > 0) {
      paramFragment.mSavedViewState = this.B;
      this.B = null;
    } 
  }
  
  public void X() {
    this.s = false;
    this.t = false;
    Y(3);
  }
  
  void X0() {
    List<i> list1;
    List<i> list2;
    List<i> list3;
    if (this.f != null) {
      ArrayList<Fragment> arrayList1 = null;
      ArrayList<Fragment> arrayList3 = arrayList1;
      ArrayList<Fragment> arrayList2 = arrayList3;
      int j = 0;
      while (true) {
        list3 = (List)arrayList1;
        list2 = (List)arrayList3;
        list1 = (List)arrayList2;
        if (j < this.f.size()) {
          ArrayList<Fragment> arrayList4;
          Fragment fragment = (Fragment)this.f.valueAt(j);
          list2 = (List)arrayList1;
          list3 = (List)arrayList3;
          ArrayList<Fragment> arrayList5 = arrayList2;
          if (fragment != null) {
            i i1;
            list1 = (List)arrayList1;
            if (fragment.mRetainInstance) {
              byte b;
              list2 = (List)arrayList1;
              if (arrayList1 == null)
                list2 = new ArrayList(); 
              list2.add(fragment);
              Fragment fragment1 = fragment.mTarget;
              if (fragment1 != null) {
                b = fragment1.mIndex;
              } else {
                b = -1;
              } 
              fragment.mTargetIndex = b;
              list1 = list2;
              if (F) {
                StringBuilder stringBuilder = new StringBuilder();
                stringBuilder.append("retainNonConfig: keeping retained ");
                stringBuilder.append(fragment);
                Log.v("FragmentManager", stringBuilder.toString());
                list1 = list2;
              } 
            } 
            h h1 = fragment.mChildFragmentManager;
            if (h1 != null) {
              h1.X0();
              i1 = fragment.mChildFragmentManager.D;
            } else {
              i1 = fragment.mChildNonConfig;
            } 
            ArrayList<Fragment> arrayList = arrayList3;
            if (arrayList3 == null) {
              arrayList = arrayList3;
              if (i1 != null) {
                arrayList3 = new ArrayList<Fragment>(this.f.size());
                int k = 0;
                while (true) {
                  arrayList = arrayList3;
                  if (k < j) {
                    arrayList3.add(null);
                    k++;
                    continue;
                  } 
                  break;
                } 
              } 
            } 
            if (arrayList != null)
              arrayList.add(i1); 
            arrayList3 = arrayList2;
            if (arrayList2 == null) {
              arrayList3 = arrayList2;
              if (fragment.mViewModelStore != null) {
                arrayList2 = new ArrayList<Fragment>(this.f.size());
                int k = 0;
                while (true) {
                  arrayList3 = arrayList2;
                  if (k < j) {
                    arrayList2.add(null);
                    k++;
                    continue;
                  } 
                  break;
                } 
              } 
            } 
            arrayList4 = (ArrayList)list1;
            list3 = (List)arrayList;
            arrayList5 = arrayList3;
            if (arrayList3 != null) {
              arrayList3.add(fragment.mViewModelStore);
              arrayList5 = arrayList3;
              list3 = (List)arrayList;
              arrayList4 = (ArrayList)list1;
            } 
          } 
          j++;
          arrayList1 = arrayList4;
          arrayList3 = (ArrayList)list3;
          arrayList2 = arrayList5;
          continue;
        } 
        break;
      } 
    } else {
      list3 = null;
      List<i> list = list3;
      list1 = list;
      list2 = list;
    } 
    if (list3 == null && list2 == null && list1 == null) {
      this.D = null;
      return;
    } 
    this.D = new i((List)list3, list2, (List)list1);
  }
  
  void Y0() {
    // Byte code:
    //   0: aload_0
    //   1: monitorenter
    //   2: aload_0
    //   3: getfield C : Ljava/util/ArrayList;
    //   6: astore #4
    //   8: iconst_0
    //   9: istore_3
    //   10: aload #4
    //   12: ifnull -> 96
    //   15: aload #4
    //   17: invokevirtual isEmpty : ()Z
    //   20: ifne -> 96
    //   23: iconst_1
    //   24: istore_1
    //   25: goto -> 28
    //   28: aload_0
    //   29: getfield b : Ljava/util/ArrayList;
    //   32: astore #4
    //   34: iload_3
    //   35: istore_2
    //   36: aload #4
    //   38: ifnull -> 101
    //   41: iload_3
    //   42: istore_2
    //   43: aload #4
    //   45: invokevirtual size : ()I
    //   48: iconst_1
    //   49: if_icmpne -> 101
    //   52: iconst_1
    //   53: istore_2
    //   54: goto -> 101
    //   57: aload_0
    //   58: getfield n : Landroidx/fragment/app/f;
    //   61: invokevirtual g : ()Landroid/os/Handler;
    //   64: aload_0
    //   65: getfield E : Ljava/lang/Runnable;
    //   68: invokevirtual removeCallbacks : (Ljava/lang/Runnable;)V
    //   71: aload_0
    //   72: getfield n : Landroidx/fragment/app/f;
    //   75: invokevirtual g : ()Landroid/os/Handler;
    //   78: aload_0
    //   79: getfield E : Ljava/lang/Runnable;
    //   82: invokevirtual post : (Ljava/lang/Runnable;)Z
    //   85: pop
    //   86: aload_0
    //   87: monitorexit
    //   88: return
    //   89: astore #4
    //   91: aload_0
    //   92: monitorexit
    //   93: aload #4
    //   95: athrow
    //   96: iconst_0
    //   97: istore_1
    //   98: goto -> 28
    //   101: iload_1
    //   102: ifne -> 57
    //   105: iload_2
    //   106: ifeq -> 86
    //   109: goto -> 57
    // Exception table:
    //   from	to	target	type
    //   2	8	89	finally
    //   15	23	89	finally
    //   28	34	89	finally
    //   43	52	89	finally
    //   57	86	89	finally
    //   86	88	89	finally
    //   91	93	89	finally
  }
  
  public void Z() {
    this.t = true;
    Y(2);
  }
  
  public void Z0(int paramInt, a parama) {
    // Byte code:
    //   0: aload_0
    //   1: monitorenter
    //   2: aload_0
    //   3: getfield i : Ljava/util/ArrayList;
    //   6: ifnonnull -> 20
    //   9: aload_0
    //   10: new java/util/ArrayList
    //   13: dup
    //   14: invokespecial <init> : ()V
    //   17: putfield i : Ljava/util/ArrayList;
    //   20: aload_0
    //   21: getfield i : Ljava/util/ArrayList;
    //   24: invokevirtual size : ()I
    //   27: istore #4
    //   29: iload #4
    //   31: istore_3
    //   32: iload_1
    //   33: iload #4
    //   35: if_icmpge -> 110
    //   38: getstatic androidx/fragment/app/h.F : Z
    //   41: ifeq -> 97
    //   44: new java/lang/StringBuilder
    //   47: dup
    //   48: invokespecial <init> : ()V
    //   51: astore #5
    //   53: aload #5
    //   55: ldc_w 'Setting back stack index '
    //   58: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   61: pop
    //   62: aload #5
    //   64: iload_1
    //   65: invokevirtual append : (I)Ljava/lang/StringBuilder;
    //   68: pop
    //   69: aload #5
    //   71: ldc_w ' to '
    //   74: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   77: pop
    //   78: aload #5
    //   80: aload_2
    //   81: invokevirtual append : (Ljava/lang/Object;)Ljava/lang/StringBuilder;
    //   84: pop
    //   85: ldc_w 'FragmentManager'
    //   88: aload #5
    //   90: invokevirtual toString : ()Ljava/lang/String;
    //   93: invokestatic v : (Ljava/lang/String;Ljava/lang/String;)I
    //   96: pop
    //   97: aload_0
    //   98: getfield i : Ljava/util/ArrayList;
    //   101: iload_1
    //   102: aload_2
    //   103: invokevirtual set : (ILjava/lang/Object;)Ljava/lang/Object;
    //   106: pop
    //   107: goto -> 272
    //   110: iload_3
    //   111: iload_1
    //   112: if_icmpge -> 204
    //   115: aload_0
    //   116: getfield i : Ljava/util/ArrayList;
    //   119: aconst_null
    //   120: invokevirtual add : (Ljava/lang/Object;)Z
    //   123: pop
    //   124: aload_0
    //   125: getfield j : Ljava/util/ArrayList;
    //   128: ifnonnull -> 142
    //   131: aload_0
    //   132: new java/util/ArrayList
    //   135: dup
    //   136: invokespecial <init> : ()V
    //   139: putfield j : Ljava/util/ArrayList;
    //   142: getstatic androidx/fragment/app/h.F : Z
    //   145: ifeq -> 185
    //   148: new java/lang/StringBuilder
    //   151: dup
    //   152: invokespecial <init> : ()V
    //   155: astore #5
    //   157: aload #5
    //   159: ldc_w 'Adding available back stack index '
    //   162: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   165: pop
    //   166: aload #5
    //   168: iload_3
    //   169: invokevirtual append : (I)Ljava/lang/StringBuilder;
    //   172: pop
    //   173: ldc_w 'FragmentManager'
    //   176: aload #5
    //   178: invokevirtual toString : ()Ljava/lang/String;
    //   181: invokestatic v : (Ljava/lang/String;Ljava/lang/String;)I
    //   184: pop
    //   185: aload_0
    //   186: getfield j : Ljava/util/ArrayList;
    //   189: iload_3
    //   190: invokestatic valueOf : (I)Ljava/lang/Integer;
    //   193: invokevirtual add : (Ljava/lang/Object;)Z
    //   196: pop
    //   197: iload_3
    //   198: iconst_1
    //   199: iadd
    //   200: istore_3
    //   201: goto -> 110
    //   204: getstatic androidx/fragment/app/h.F : Z
    //   207: ifeq -> 263
    //   210: new java/lang/StringBuilder
    //   213: dup
    //   214: invokespecial <init> : ()V
    //   217: astore #5
    //   219: aload #5
    //   221: ldc_w 'Adding back stack index '
    //   224: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   227: pop
    //   228: aload #5
    //   230: iload_1
    //   231: invokevirtual append : (I)Ljava/lang/StringBuilder;
    //   234: pop
    //   235: aload #5
    //   237: ldc_w ' with '
    //   240: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   243: pop
    //   244: aload #5
    //   246: aload_2
    //   247: invokevirtual append : (Ljava/lang/Object;)Ljava/lang/StringBuilder;
    //   250: pop
    //   251: ldc_w 'FragmentManager'
    //   254: aload #5
    //   256: invokevirtual toString : ()Ljava/lang/String;
    //   259: invokestatic v : (Ljava/lang/String;Ljava/lang/String;)I
    //   262: pop
    //   263: aload_0
    //   264: getfield i : Ljava/util/ArrayList;
    //   267: aload_2
    //   268: invokevirtual add : (Ljava/lang/Object;)Z
    //   271: pop
    //   272: aload_0
    //   273: monitorexit
    //   274: return
    //   275: astore_2
    //   276: aload_0
    //   277: monitorexit
    //   278: aload_2
    //   279: athrow
    // Exception table:
    //   from	to	target	type
    //   2	20	275	finally
    //   20	29	275	finally
    //   38	97	275	finally
    //   97	107	275	finally
    //   115	142	275	finally
    //   142	185	275	finally
    //   185	197	275	finally
    //   204	263	275	finally
    //   263	272	275	finally
    //   272	274	275	finally
    //   276	278	275	finally
  }
  
  public j a() {
    return new a(this);
  }
  
  void a0() {
    if (this.w) {
      this.w = false;
      f1();
    } 
  }
  
  public void b(String paramString, FileDescriptor paramFileDescriptor, PrintWriter paramPrintWriter, String[] paramArrayOfString) {
    // Byte code:
    //   0: new java/lang/StringBuilder
    //   3: dup
    //   4: invokespecial <init> : ()V
    //   7: astore #8
    //   9: aload #8
    //   11: aload_1
    //   12: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   15: pop
    //   16: aload #8
    //   18: ldc_w '    '
    //   21: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   24: pop
    //   25: aload #8
    //   27: invokevirtual toString : ()Ljava/lang/String;
    //   30: astore #8
    //   32: aload_0
    //   33: getfield f : Landroid/util/SparseArray;
    //   36: astore #9
    //   38: iconst_0
    //   39: istore #6
    //   41: aload #9
    //   43: ifnull -> 168
    //   46: aload #9
    //   48: invokevirtual size : ()I
    //   51: istore #7
    //   53: iload #7
    //   55: ifle -> 168
    //   58: aload_3
    //   59: aload_1
    //   60: invokevirtual print : (Ljava/lang/String;)V
    //   63: aload_3
    //   64: ldc_w 'Active Fragments in '
    //   67: invokevirtual print : (Ljava/lang/String;)V
    //   70: aload_3
    //   71: aload_0
    //   72: invokestatic identityHashCode : (Ljava/lang/Object;)I
    //   75: invokestatic toHexString : (I)Ljava/lang/String;
    //   78: invokevirtual print : (Ljava/lang/String;)V
    //   81: aload_3
    //   82: ldc_w ':'
    //   85: invokevirtual println : (Ljava/lang/String;)V
    //   88: iconst_0
    //   89: istore #5
    //   91: iload #5
    //   93: iload #7
    //   95: if_icmpge -> 168
    //   98: aload_0
    //   99: getfield f : Landroid/util/SparseArray;
    //   102: iload #5
    //   104: invokevirtual valueAt : (I)Ljava/lang/Object;
    //   107: checkcast androidx/fragment/app/Fragment
    //   110: astore #9
    //   112: aload_3
    //   113: aload_1
    //   114: invokevirtual print : (Ljava/lang/String;)V
    //   117: aload_3
    //   118: ldc_w '  #'
    //   121: invokevirtual print : (Ljava/lang/String;)V
    //   124: aload_3
    //   125: iload #5
    //   127: invokevirtual print : (I)V
    //   130: aload_3
    //   131: ldc_w ': '
    //   134: invokevirtual print : (Ljava/lang/String;)V
    //   137: aload_3
    //   138: aload #9
    //   140: invokevirtual println : (Ljava/lang/Object;)V
    //   143: aload #9
    //   145: ifnull -> 159
    //   148: aload #9
    //   150: aload #8
    //   152: aload_2
    //   153: aload_3
    //   154: aload #4
    //   156: invokevirtual dump : (Ljava/lang/String;Ljava/io/FileDescriptor;Ljava/io/PrintWriter;[Ljava/lang/String;)V
    //   159: iload #5
    //   161: iconst_1
    //   162: iadd
    //   163: istore #5
    //   165: goto -> 91
    //   168: aload_0
    //   169: getfield e : Ljava/util/ArrayList;
    //   172: invokevirtual size : ()I
    //   175: istore #7
    //   177: iload #7
    //   179: ifle -> 261
    //   182: aload_3
    //   183: aload_1
    //   184: invokevirtual print : (Ljava/lang/String;)V
    //   187: aload_3
    //   188: ldc_w 'Added Fragments:'
    //   191: invokevirtual println : (Ljava/lang/String;)V
    //   194: iconst_0
    //   195: istore #5
    //   197: iload #5
    //   199: iload #7
    //   201: if_icmpge -> 261
    //   204: aload_0
    //   205: getfield e : Ljava/util/ArrayList;
    //   208: iload #5
    //   210: invokevirtual get : (I)Ljava/lang/Object;
    //   213: checkcast androidx/fragment/app/Fragment
    //   216: astore #9
    //   218: aload_3
    //   219: aload_1
    //   220: invokevirtual print : (Ljava/lang/String;)V
    //   223: aload_3
    //   224: ldc_w '  #'
    //   227: invokevirtual print : (Ljava/lang/String;)V
    //   230: aload_3
    //   231: iload #5
    //   233: invokevirtual print : (I)V
    //   236: aload_3
    //   237: ldc_w ': '
    //   240: invokevirtual print : (Ljava/lang/String;)V
    //   243: aload_3
    //   244: aload #9
    //   246: invokevirtual toString : ()Ljava/lang/String;
    //   249: invokevirtual println : (Ljava/lang/String;)V
    //   252: iload #5
    //   254: iconst_1
    //   255: iadd
    //   256: istore #5
    //   258: goto -> 197
    //   261: aload_0
    //   262: getfield h : Ljava/util/ArrayList;
    //   265: astore #9
    //   267: aload #9
    //   269: ifnull -> 363
    //   272: aload #9
    //   274: invokevirtual size : ()I
    //   277: istore #7
    //   279: iload #7
    //   281: ifle -> 363
    //   284: aload_3
    //   285: aload_1
    //   286: invokevirtual print : (Ljava/lang/String;)V
    //   289: aload_3
    //   290: ldc_w 'Fragments Created Menus:'
    //   293: invokevirtual println : (Ljava/lang/String;)V
    //   296: iconst_0
    //   297: istore #5
    //   299: iload #5
    //   301: iload #7
    //   303: if_icmpge -> 363
    //   306: aload_0
    //   307: getfield h : Ljava/util/ArrayList;
    //   310: iload #5
    //   312: invokevirtual get : (I)Ljava/lang/Object;
    //   315: checkcast androidx/fragment/app/Fragment
    //   318: astore #9
    //   320: aload_3
    //   321: aload_1
    //   322: invokevirtual print : (Ljava/lang/String;)V
    //   325: aload_3
    //   326: ldc_w '  #'
    //   329: invokevirtual print : (Ljava/lang/String;)V
    //   332: aload_3
    //   333: iload #5
    //   335: invokevirtual print : (I)V
    //   338: aload_3
    //   339: ldc_w ': '
    //   342: invokevirtual print : (Ljava/lang/String;)V
    //   345: aload_3
    //   346: aload #9
    //   348: invokevirtual toString : ()Ljava/lang/String;
    //   351: invokevirtual println : (Ljava/lang/String;)V
    //   354: iload #5
    //   356: iconst_1
    //   357: iadd
    //   358: istore #5
    //   360: goto -> 299
    //   363: aload_0
    //   364: getfield g : Ljava/util/ArrayList;
    //   367: astore #9
    //   369: aload #9
    //   371: ifnull -> 476
    //   374: aload #9
    //   376: invokevirtual size : ()I
    //   379: istore #7
    //   381: iload #7
    //   383: ifle -> 476
    //   386: aload_3
    //   387: aload_1
    //   388: invokevirtual print : (Ljava/lang/String;)V
    //   391: aload_3
    //   392: ldc_w 'Back Stack:'
    //   395: invokevirtual println : (Ljava/lang/String;)V
    //   398: iconst_0
    //   399: istore #5
    //   401: iload #5
    //   403: iload #7
    //   405: if_icmpge -> 476
    //   408: aload_0
    //   409: getfield g : Ljava/util/ArrayList;
    //   412: iload #5
    //   414: invokevirtual get : (I)Ljava/lang/Object;
    //   417: checkcast androidx/fragment/app/a
    //   420: astore #9
    //   422: aload_3
    //   423: aload_1
    //   424: invokevirtual print : (Ljava/lang/String;)V
    //   427: aload_3
    //   428: ldc_w '  #'
    //   431: invokevirtual print : (Ljava/lang/String;)V
    //   434: aload_3
    //   435: iload #5
    //   437: invokevirtual print : (I)V
    //   440: aload_3
    //   441: ldc_w ': '
    //   444: invokevirtual print : (Ljava/lang/String;)V
    //   447: aload_3
    //   448: aload #9
    //   450: invokevirtual toString : ()Ljava/lang/String;
    //   453: invokevirtual println : (Ljava/lang/String;)V
    //   456: aload #9
    //   458: aload #8
    //   460: aload_2
    //   461: aload_3
    //   462: aload #4
    //   464: invokevirtual l : (Ljava/lang/String;Ljava/io/FileDescriptor;Ljava/io/PrintWriter;[Ljava/lang/String;)V
    //   467: iload #5
    //   469: iconst_1
    //   470: iadd
    //   471: istore #5
    //   473: goto -> 401
    //   476: aload_0
    //   477: monitorenter
    //   478: aload_0
    //   479: getfield i : Ljava/util/ArrayList;
    //   482: astore_2
    //   483: aload_2
    //   484: ifnull -> 572
    //   487: aload_2
    //   488: invokevirtual size : ()I
    //   491: istore #7
    //   493: iload #7
    //   495: ifle -> 572
    //   498: aload_3
    //   499: aload_1
    //   500: invokevirtual print : (Ljava/lang/String;)V
    //   503: aload_3
    //   504: ldc_w 'Back Stack Indices:'
    //   507: invokevirtual println : (Ljava/lang/String;)V
    //   510: iconst_0
    //   511: istore #5
    //   513: iload #5
    //   515: iload #7
    //   517: if_icmpge -> 572
    //   520: aload_0
    //   521: getfield i : Ljava/util/ArrayList;
    //   524: iload #5
    //   526: invokevirtual get : (I)Ljava/lang/Object;
    //   529: checkcast androidx/fragment/app/a
    //   532: astore_2
    //   533: aload_3
    //   534: aload_1
    //   535: invokevirtual print : (Ljava/lang/String;)V
    //   538: aload_3
    //   539: ldc_w '  #'
    //   542: invokevirtual print : (Ljava/lang/String;)V
    //   545: aload_3
    //   546: iload #5
    //   548: invokevirtual print : (I)V
    //   551: aload_3
    //   552: ldc_w ': '
    //   555: invokevirtual print : (Ljava/lang/String;)V
    //   558: aload_3
    //   559: aload_2
    //   560: invokevirtual println : (Ljava/lang/Object;)V
    //   563: iload #5
    //   565: iconst_1
    //   566: iadd
    //   567: istore #5
    //   569: goto -> 513
    //   572: aload_0
    //   573: getfield j : Ljava/util/ArrayList;
    //   576: astore_2
    //   577: aload_2
    //   578: ifnull -> 614
    //   581: aload_2
    //   582: invokevirtual size : ()I
    //   585: ifle -> 614
    //   588: aload_3
    //   589: aload_1
    //   590: invokevirtual print : (Ljava/lang/String;)V
    //   593: aload_3
    //   594: ldc_w 'mAvailBackStackIndices: '
    //   597: invokevirtual print : (Ljava/lang/String;)V
    //   600: aload_3
    //   601: aload_0
    //   602: getfield j : Ljava/util/ArrayList;
    //   605: invokevirtual toArray : ()[Ljava/lang/Object;
    //   608: invokestatic toString : ([Ljava/lang/Object;)Ljava/lang/String;
    //   611: invokevirtual println : (Ljava/lang/String;)V
    //   614: aload_0
    //   615: monitorexit
    //   616: aload_0
    //   617: getfield b : Ljava/util/ArrayList;
    //   620: astore_2
    //   621: aload_2
    //   622: ifnull -> 711
    //   625: aload_2
    //   626: invokevirtual size : ()I
    //   629: istore #7
    //   631: iload #7
    //   633: ifle -> 711
    //   636: aload_3
    //   637: aload_1
    //   638: invokevirtual print : (Ljava/lang/String;)V
    //   641: aload_3
    //   642: ldc_w 'Pending Actions:'
    //   645: invokevirtual println : (Ljava/lang/String;)V
    //   648: iload #6
    //   650: istore #5
    //   652: iload #5
    //   654: iload #7
    //   656: if_icmpge -> 711
    //   659: aload_0
    //   660: getfield b : Ljava/util/ArrayList;
    //   663: iload #5
    //   665: invokevirtual get : (I)Ljava/lang/Object;
    //   668: checkcast androidx/fragment/app/h$l
    //   671: astore_2
    //   672: aload_3
    //   673: aload_1
    //   674: invokevirtual print : (Ljava/lang/String;)V
    //   677: aload_3
    //   678: ldc_w '  #'
    //   681: invokevirtual print : (Ljava/lang/String;)V
    //   684: aload_3
    //   685: iload #5
    //   687: invokevirtual print : (I)V
    //   690: aload_3
    //   691: ldc_w ': '
    //   694: invokevirtual print : (Ljava/lang/String;)V
    //   697: aload_3
    //   698: aload_2
    //   699: invokevirtual println : (Ljava/lang/Object;)V
    //   702: iload #5
    //   704: iconst_1
    //   705: iadd
    //   706: istore #5
    //   708: goto -> 652
    //   711: aload_3
    //   712: aload_1
    //   713: invokevirtual print : (Ljava/lang/String;)V
    //   716: aload_3
    //   717: ldc_w 'FragmentManager misc state:'
    //   720: invokevirtual println : (Ljava/lang/String;)V
    //   723: aload_3
    //   724: aload_1
    //   725: invokevirtual print : (Ljava/lang/String;)V
    //   728: aload_3
    //   729: ldc_w '  mHost='
    //   732: invokevirtual print : (Ljava/lang/String;)V
    //   735: aload_3
    //   736: aload_0
    //   737: getfield n : Landroidx/fragment/app/f;
    //   740: invokevirtual println : (Ljava/lang/Object;)V
    //   743: aload_3
    //   744: aload_1
    //   745: invokevirtual print : (Ljava/lang/String;)V
    //   748: aload_3
    //   749: ldc_w '  mContainer='
    //   752: invokevirtual print : (Ljava/lang/String;)V
    //   755: aload_3
    //   756: aload_0
    //   757: getfield o : Landroidx/fragment/app/d;
    //   760: invokevirtual println : (Ljava/lang/Object;)V
    //   763: aload_0
    //   764: getfield p : Landroidx/fragment/app/Fragment;
    //   767: ifnull -> 790
    //   770: aload_3
    //   771: aload_1
    //   772: invokevirtual print : (Ljava/lang/String;)V
    //   775: aload_3
    //   776: ldc_w '  mParent='
    //   779: invokevirtual print : (Ljava/lang/String;)V
    //   782: aload_3
    //   783: aload_0
    //   784: getfield p : Landroidx/fragment/app/Fragment;
    //   787: invokevirtual println : (Ljava/lang/Object;)V
    //   790: aload_3
    //   791: aload_1
    //   792: invokevirtual print : (Ljava/lang/String;)V
    //   795: aload_3
    //   796: ldc_w '  mCurState='
    //   799: invokevirtual print : (Ljava/lang/String;)V
    //   802: aload_3
    //   803: aload_0
    //   804: getfield m : I
    //   807: invokevirtual print : (I)V
    //   810: aload_3
    //   811: ldc_w ' mStateSaved='
    //   814: invokevirtual print : (Ljava/lang/String;)V
    //   817: aload_3
    //   818: aload_0
    //   819: getfield s : Z
    //   822: invokevirtual print : (Z)V
    //   825: aload_3
    //   826: ldc_w ' mStopped='
    //   829: invokevirtual print : (Ljava/lang/String;)V
    //   832: aload_3
    //   833: aload_0
    //   834: getfield t : Z
    //   837: invokevirtual print : (Z)V
    //   840: aload_3
    //   841: ldc_w ' mDestroyed='
    //   844: invokevirtual print : (Ljava/lang/String;)V
    //   847: aload_3
    //   848: aload_0
    //   849: getfield u : Z
    //   852: invokevirtual println : (Z)V
    //   855: aload_0
    //   856: getfield r : Z
    //   859: ifeq -> 882
    //   862: aload_3
    //   863: aload_1
    //   864: invokevirtual print : (Ljava/lang/String;)V
    //   867: aload_3
    //   868: ldc_w '  mNeedMenuInvalidate='
    //   871: invokevirtual print : (Ljava/lang/String;)V
    //   874: aload_3
    //   875: aload_0
    //   876: getfield r : Z
    //   879: invokevirtual println : (Z)V
    //   882: aload_0
    //   883: getfield v : Ljava/lang/String;
    //   886: ifnull -> 909
    //   889: aload_3
    //   890: aload_1
    //   891: invokevirtual print : (Ljava/lang/String;)V
    //   894: aload_3
    //   895: ldc_w '  mNoTransactionsBecause='
    //   898: invokevirtual print : (Ljava/lang/String;)V
    //   901: aload_3
    //   902: aload_0
    //   903: getfield v : Ljava/lang/String;
    //   906: invokevirtual println : (Ljava/lang/String;)V
    //   909: return
    //   910: astore_1
    //   911: aload_0
    //   912: monitorexit
    //   913: aload_1
    //   914: athrow
    // Exception table:
    //   from	to	target	type
    //   478	483	910	finally
    //   487	493	910	finally
    //   498	510	910	finally
    //   520	563	910	finally
    //   572	577	910	finally
    //   581	614	910	finally
    //   614	616	910	finally
    //   911	913	910	finally
  }
  
  public void b1(Fragment paramFragment) {
    if (paramFragment == null || (this.f.get(paramFragment.mIndex) == paramFragment && (paramFragment.mHost == null || paramFragment.getFragmentManager() == this))) {
      this.q = paramFragment;
      return;
    } 
    StringBuilder stringBuilder = new StringBuilder();
    stringBuilder.append("Fragment ");
    stringBuilder.append(paramFragment);
    stringBuilder.append(" is not an active fragment of FragmentManager ");
    stringBuilder.append(this);
    throw new IllegalArgumentException(stringBuilder.toString());
  }
  
  public Fragment c(String paramString) {
    if (paramString != null)
      for (int j = this.e.size() - 1; j >= 0; j--) {
        Fragment fragment = this.e.get(j);
        if (fragment != null && paramString.equals(fragment.mTag))
          return fragment; 
      }  
    SparseArray<Fragment> sparseArray = this.f;
    if (sparseArray != null && paramString != null)
      for (int j = sparseArray.size() - 1; j >= 0; j--) {
        Fragment fragment = (Fragment)this.f.valueAt(j);
        if (fragment != null && paramString.equals(fragment.mTag))
          return fragment; 
      }  
    return null;
  }
  
  public void c0(l paraml, boolean paramBoolean) {
    // Byte code:
    //   0: iload_2
    //   1: ifne -> 8
    //   4: aload_0
    //   5: invokespecial p : ()V
    //   8: aload_0
    //   9: monitorenter
    //   10: aload_0
    //   11: getfield u : Z
    //   14: ifne -> 61
    //   17: aload_0
    //   18: getfield n : Landroidx/fragment/app/f;
    //   21: ifnonnull -> 27
    //   24: goto -> 61
    //   27: aload_0
    //   28: getfield b : Ljava/util/ArrayList;
    //   31: ifnonnull -> 45
    //   34: aload_0
    //   35: new java/util/ArrayList
    //   38: dup
    //   39: invokespecial <init> : ()V
    //   42: putfield b : Ljava/util/ArrayList;
    //   45: aload_0
    //   46: getfield b : Ljava/util/ArrayList;
    //   49: aload_1
    //   50: invokevirtual add : (Ljava/lang/Object;)Z
    //   53: pop
    //   54: aload_0
    //   55: invokevirtual Y0 : ()V
    //   58: aload_0
    //   59: monitorexit
    //   60: return
    //   61: iload_2
    //   62: ifeq -> 68
    //   65: aload_0
    //   66: monitorexit
    //   67: return
    //   68: new java/lang/IllegalStateException
    //   71: dup
    //   72: ldc_w 'Activity has been destroyed'
    //   75: invokespecial <init> : (Ljava/lang/String;)V
    //   78: athrow
    //   79: astore_1
    //   80: aload_0
    //   81: monitorexit
    //   82: aload_1
    //   83: athrow
    // Exception table:
    //   from	to	target	type
    //   10	24	79	finally
    //   27	45	79	finally
    //   45	60	79	finally
    //   65	67	79	finally
    //   68	79	79	finally
    //   80	82	79	finally
  }
  
  public List<Fragment> d() {
    if (this.e.isEmpty())
      return Collections.emptyList(); 
    synchronized (this.e) {
      return (List)this.e.clone();
    } 
  }
  
  public boolean e() {
    return (this.s || this.t);
  }
  
  void e0(Fragment paramFragment) {
    if (paramFragment.mFromLayout && !paramFragment.mPerformedCreateView) {
      paramFragment.performCreateView(paramFragment.performGetLayoutInflater(paramFragment.mSavedFragmentState), null, paramFragment.mSavedFragmentState);
      View view = paramFragment.mView;
      if (view != null) {
        paramFragment.mInnerView = view;
        view.setSaveFromParentEnabled(false);
        if (paramFragment.mHidden)
          paramFragment.mView.setVisibility(8); 
        paramFragment.onViewCreated(paramFragment.mView, paramFragment.mSavedFragmentState);
        P(paramFragment, paramFragment.mView, paramFragment.mSavedFragmentState, false);
        return;
      } 
      paramFragment.mInnerView = null;
    } 
  }
  
  public void e1(Fragment paramFragment) {
    if (F) {
      StringBuilder stringBuilder = new StringBuilder();
      stringBuilder.append("show: ");
      stringBuilder.append(paramFragment);
      Log.v("FragmentManager", stringBuilder.toString());
    } 
    if (paramFragment.mHidden) {
      paramFragment.mHidden = false;
      paramFragment.mHiddenChanged ^= 0x1;
    } 
  }
  
  public void f(int paramInt1, int paramInt2) {
    if (paramInt1 >= 0) {
      c0(new m(this, null, paramInt1, paramInt2), false);
      return;
    } 
    StringBuilder stringBuilder = new StringBuilder();
    stringBuilder.append("Bad id: ");
    stringBuilder.append(paramInt1);
    throw new IllegalArgumentException(stringBuilder.toString());
  }
  
  public boolean f0() {
    d0(true);
    boolean bool = false;
    while (p0(this.x, this.y)) {
      this.c = true;
      try {
        P0(this.x, this.y);
        q();
      } finally {
        q();
      } 
    } 
    a0();
    o();
    return bool;
  }
  
  void f1() {
    if (this.f == null)
      return; 
    for (int j = 0; j < this.f.size(); j++) {
      Fragment fragment = (Fragment)this.f.valueAt(j);
      if (fragment != null)
        J0(fragment); 
    } 
  }
  
  public boolean g() {
    p();
    return K0(null, -1, 0);
  }
  
  public void g0(l paraml, boolean paramBoolean) {
    if (paramBoolean && (this.n == null || this.u))
      return; 
    d0(paramBoolean);
    if (paraml.a(this.x, this.y)) {
      this.c = true;
      try {
        P0(this.x, this.y);
      } finally {
        q();
      } 
    } 
    a0();
    o();
  }
  
  void i(a parama) {
    if (this.g == null)
      this.g = new ArrayList<a>(); 
    this.g.add(parama);
  }
  
  public void j(Fragment paramFragment, boolean paramBoolean) {
    if (F) {
      StringBuilder stringBuilder = new StringBuilder();
      stringBuilder.append("add: ");
      stringBuilder.append(paramFragment);
      Log.v("FragmentManager", stringBuilder.toString());
    } 
    x0(paramFragment);
    if (!paramFragment.mDetached)
      if (!this.e.contains(paramFragment)) {
        synchronized (this.e) {
          this.e.add(paramFragment);
          paramFragment.mAdded = true;
          paramFragment.mRemoving = false;
          if (paramFragment.mView == null)
            paramFragment.mHiddenChanged = false; 
          if (paramFragment.mHasMenu && paramFragment.mMenuVisible)
            this.r = true; 
          if (paramBoolean) {
            G0(paramFragment);
            return;
          } 
        } 
      } else {
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("Fragment already added: ");
        stringBuilder.append(paramFragment);
        throw new IllegalStateException(stringBuilder.toString());
      }  
  }
  
  public int k(a parama) {
    // Byte code:
    //   0: aload_0
    //   1: monitorenter
    //   2: aload_0
    //   3: getfield j : Ljava/util/ArrayList;
    //   6: astore_3
    //   7: aload_3
    //   8: ifnull -> 110
    //   11: aload_3
    //   12: invokevirtual size : ()I
    //   15: ifgt -> 21
    //   18: goto -> 110
    //   21: aload_0
    //   22: getfield j : Ljava/util/ArrayList;
    //   25: astore_3
    //   26: aload_3
    //   27: aload_3
    //   28: invokevirtual size : ()I
    //   31: iconst_1
    //   32: isub
    //   33: invokevirtual remove : (I)Ljava/lang/Object;
    //   36: checkcast java/lang/Integer
    //   39: invokevirtual intValue : ()I
    //   42: istore_2
    //   43: getstatic androidx/fragment/app/h.F : Z
    //   46: ifeq -> 96
    //   49: new java/lang/StringBuilder
    //   52: dup
    //   53: invokespecial <init> : ()V
    //   56: astore_3
    //   57: aload_3
    //   58: ldc_w 'Adding back stack index '
    //   61: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   64: pop
    //   65: aload_3
    //   66: iload_2
    //   67: invokevirtual append : (I)Ljava/lang/StringBuilder;
    //   70: pop
    //   71: aload_3
    //   72: ldc_w ' with '
    //   75: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   78: pop
    //   79: aload_3
    //   80: aload_1
    //   81: invokevirtual append : (Ljava/lang/Object;)Ljava/lang/StringBuilder;
    //   84: pop
    //   85: ldc_w 'FragmentManager'
    //   88: aload_3
    //   89: invokevirtual toString : ()Ljava/lang/String;
    //   92: invokestatic v : (Ljava/lang/String;Ljava/lang/String;)I
    //   95: pop
    //   96: aload_0
    //   97: getfield i : Ljava/util/ArrayList;
    //   100: iload_2
    //   101: aload_1
    //   102: invokevirtual set : (ILjava/lang/Object;)Ljava/lang/Object;
    //   105: pop
    //   106: aload_0
    //   107: monitorexit
    //   108: iload_2
    //   109: ireturn
    //   110: aload_0
    //   111: getfield i : Ljava/util/ArrayList;
    //   114: ifnonnull -> 128
    //   117: aload_0
    //   118: new java/util/ArrayList
    //   121: dup
    //   122: invokespecial <init> : ()V
    //   125: putfield i : Ljava/util/ArrayList;
    //   128: aload_0
    //   129: getfield i : Ljava/util/ArrayList;
    //   132: invokevirtual size : ()I
    //   135: istore_2
    //   136: getstatic androidx/fragment/app/h.F : Z
    //   139: ifeq -> 189
    //   142: new java/lang/StringBuilder
    //   145: dup
    //   146: invokespecial <init> : ()V
    //   149: astore_3
    //   150: aload_3
    //   151: ldc_w 'Setting back stack index '
    //   154: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   157: pop
    //   158: aload_3
    //   159: iload_2
    //   160: invokevirtual append : (I)Ljava/lang/StringBuilder;
    //   163: pop
    //   164: aload_3
    //   165: ldc_w ' to '
    //   168: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   171: pop
    //   172: aload_3
    //   173: aload_1
    //   174: invokevirtual append : (Ljava/lang/Object;)Ljava/lang/StringBuilder;
    //   177: pop
    //   178: ldc_w 'FragmentManager'
    //   181: aload_3
    //   182: invokevirtual toString : ()Ljava/lang/String;
    //   185: invokestatic v : (Ljava/lang/String;Ljava/lang/String;)I
    //   188: pop
    //   189: aload_0
    //   190: getfield i : Ljava/util/ArrayList;
    //   193: aload_1
    //   194: invokevirtual add : (Ljava/lang/Object;)Z
    //   197: pop
    //   198: aload_0
    //   199: monitorexit
    //   200: iload_2
    //   201: ireturn
    //   202: astore_1
    //   203: aload_0
    //   204: monitorexit
    //   205: aload_1
    //   206: athrow
    // Exception table:
    //   from	to	target	type
    //   2	7	202	finally
    //   11	18	202	finally
    //   21	96	202	finally
    //   96	108	202	finally
    //   110	128	202	finally
    //   128	189	202	finally
    //   189	200	202	finally
    //   203	205	202	finally
  }
  
  public Fragment k0(int paramInt) {
    int j;
    for (j = this.e.size() - 1; j >= 0; j--) {
      Fragment fragment = this.e.get(j);
      if (fragment != null && fragment.mFragmentId == paramInt)
        return fragment; 
    } 
    SparseArray<Fragment> sparseArray = this.f;
    if (sparseArray != null)
      for (j = sparseArray.size() - 1; j >= 0; j--) {
        Fragment fragment = (Fragment)this.f.valueAt(j);
        if (fragment != null && fragment.mFragmentId == paramInt)
          return fragment; 
      }  
    return null;
  }
  
  public Fragment l0(String paramString) {
    SparseArray<Fragment> sparseArray = this.f;
    if (sparseArray != null && paramString != null)
      for (int j = sparseArray.size() - 1; j >= 0; j--) {
        Fragment fragment = (Fragment)this.f.valueAt(j);
        if (fragment != null) {
          fragment = fragment.findFragmentByWho(paramString);
          if (fragment != null)
            return fragment; 
        } 
      }  
    return null;
  }
  
  public void m(f paramf, d paramd, Fragment paramFragment) {
    if (this.n == null) {
      this.n = paramf;
      this.o = paramd;
      this.p = paramFragment;
      return;
    } 
    throw new IllegalStateException("Already attached");
  }
  
  public void n(Fragment paramFragment) {
    if (F) {
      StringBuilder stringBuilder = new StringBuilder();
      stringBuilder.append("attach: ");
      stringBuilder.append(paramFragment);
      Log.v("FragmentManager", stringBuilder.toString());
    } 
    if (paramFragment.mDetached) {
      paramFragment.mDetached = false;
      if (!paramFragment.mAdded)
        if (!this.e.contains(paramFragment)) {
          if (F) {
            StringBuilder stringBuilder = new StringBuilder();
            stringBuilder.append("add from attach: ");
            stringBuilder.append(paramFragment);
            Log.v("FragmentManager", stringBuilder.toString());
          } 
          synchronized (this.e) {
            this.e.add(paramFragment);
            paramFragment.mAdded = true;
            if (paramFragment.mHasMenu && paramFragment.mMenuVisible) {
              this.r = true;
              return;
            } 
          } 
        } else {
          StringBuilder stringBuilder = new StringBuilder();
          stringBuilder.append("Fragment already added: ");
          stringBuilder.append(paramFragment);
          throw new IllegalStateException(stringBuilder.toString());
        }  
    } 
  }
  
  public void o0(int paramInt) {
    // Byte code:
    //   0: aload_0
    //   1: monitorenter
    //   2: aload_0
    //   3: getfield i : Ljava/util/ArrayList;
    //   6: iload_1
    //   7: aconst_null
    //   8: invokevirtual set : (ILjava/lang/Object;)Ljava/lang/Object;
    //   11: pop
    //   12: aload_0
    //   13: getfield j : Ljava/util/ArrayList;
    //   16: ifnonnull -> 30
    //   19: aload_0
    //   20: new java/util/ArrayList
    //   23: dup
    //   24: invokespecial <init> : ()V
    //   27: putfield j : Ljava/util/ArrayList;
    //   30: getstatic androidx/fragment/app/h.F : Z
    //   33: ifeq -> 69
    //   36: new java/lang/StringBuilder
    //   39: dup
    //   40: invokespecial <init> : ()V
    //   43: astore_2
    //   44: aload_2
    //   45: ldc_w 'Freeing back stack index '
    //   48: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   51: pop
    //   52: aload_2
    //   53: iload_1
    //   54: invokevirtual append : (I)Ljava/lang/StringBuilder;
    //   57: pop
    //   58: ldc_w 'FragmentManager'
    //   61: aload_2
    //   62: invokevirtual toString : ()Ljava/lang/String;
    //   65: invokestatic v : (Ljava/lang/String;Ljava/lang/String;)I
    //   68: pop
    //   69: aload_0
    //   70: getfield j : Ljava/util/ArrayList;
    //   73: iload_1
    //   74: invokestatic valueOf : (I)Ljava/lang/Integer;
    //   77: invokevirtual add : (Ljava/lang/Object;)Z
    //   80: pop
    //   81: aload_0
    //   82: monitorexit
    //   83: return
    //   84: astore_2
    //   85: aload_0
    //   86: monitorexit
    //   87: aload_2
    //   88: athrow
    // Exception table:
    //   from	to	target	type
    //   2	30	84	finally
    //   30	69	84	finally
    //   69	83	84	finally
    //   85	87	84	finally
  }
  
  public View onCreateView(View paramView, String paramString, Context paramContext, AttributeSet paramAttributeSet) {
    if (!"fragment".equals(paramString))
      return null; 
    paramString = paramAttributeSet.getAttributeValue(null, "class");
    TypedArray typedArray = paramContext.obtainStyledAttributes(paramAttributeSet, k.a);
    int j = 0;
    String str1 = paramString;
    if (paramString == null)
      str1 = typedArray.getString(0); 
    int k = typedArray.getResourceId(1, -1);
    String str2 = typedArray.getString(2);
    typedArray.recycle();
    if (!Fragment.isSupportFragmentClass(this.n.e(), str1))
      return null; 
    if (paramView != null)
      j = paramView.getId(); 
    if (j != -1 || k != -1 || str2 != null) {
      f f1;
      Fragment fragment2;
      f f2;
      if (k != -1) {
        Fragment fragment = k0(k);
      } else {
        paramView = null;
      } 
      View view2 = paramView;
      if (paramView == null) {
        view2 = paramView;
        if (str2 != null)
          fragment2 = c(str2); 
      } 
      Fragment fragment1 = fragment2;
      if (fragment2 == null) {
        fragment1 = fragment2;
        if (j != -1)
          fragment1 = k0(j); 
      } 
      if (F) {
        StringBuilder stringBuilder2 = new StringBuilder();
        stringBuilder2.append("onCreateView: id=0x");
        stringBuilder2.append(Integer.toHexString(k));
        stringBuilder2.append(" fname=");
        stringBuilder2.append(str1);
        stringBuilder2.append(" existing=");
        stringBuilder2.append(fragment1);
        Log.v("FragmentManager", stringBuilder2.toString());
      } 
      if (fragment1 == null) {
        int m;
        fragment2 = this.o.a(paramContext, str1, null);
        fragment2.mFromLayout = true;
        if (k != 0) {
          m = k;
        } else {
          m = j;
        } 
        fragment2.mFragmentId = m;
        fragment2.mContainerId = j;
        fragment2.mTag = str2;
        fragment2.mInLayout = true;
        fragment2.mFragmentManager = this;
        f1 = this.n;
        fragment2.mHost = f1;
        fragment2.onInflate(f1.e(), paramAttributeSet, fragment2.mSavedFragmentState);
        j(fragment2, true);
      } else if (!((Fragment)f1).mInLayout) {
        ((Fragment)f1).mInLayout = true;
        f f3 = this.n;
        ((Fragment)f1).mHost = f3;
        f2 = f1;
        if (!((Fragment)f1).mRetaining) {
          f1.onInflate(f3.e(), paramAttributeSet, ((Fragment)f1).mSavedFragmentState);
          f2 = f1;
        } 
      } else {
        StringBuilder stringBuilder2 = new StringBuilder();
        stringBuilder2.append(paramAttributeSet.getPositionDescription());
        stringBuilder2.append(": Duplicate id 0x");
        stringBuilder2.append(Integer.toHexString(k));
        stringBuilder2.append(", tag ");
        stringBuilder2.append(str2);
        stringBuilder2.append(", or parent id 0x");
        stringBuilder2.append(Integer.toHexString(j));
        stringBuilder2.append(" with another fragment for ");
        stringBuilder2.append(str1);
        throw new IllegalArgumentException(stringBuilder2.toString());
      } 
      if (this.m < 1 && ((Fragment)f2).mFromLayout) {
        H0((Fragment)f2, 1, 0, 0, false);
      } else {
        G0((Fragment)f2);
      } 
      View view1 = ((Fragment)f2).mView;
      if (view1 != null) {
        if (k != 0)
          view1.setId(k); 
        if (((Fragment)f2).mView.getTag() == null)
          ((Fragment)f2).mView.setTag(str2); 
        return ((Fragment)f2).mView;
      } 
      StringBuilder stringBuilder1 = new StringBuilder();
      stringBuilder1.append("Fragment ");
      stringBuilder1.append(str1);
      stringBuilder1.append(" did not create a view.");
      throw new IllegalStateException(stringBuilder1.toString());
    } 
    StringBuilder stringBuilder = new StringBuilder();
    stringBuilder.append(paramAttributeSet.getPositionDescription());
    stringBuilder.append(": Must specify unique android:id, android:tag, or have a parent with an id for ");
    stringBuilder.append(str1);
    throw new IllegalArgumentException(stringBuilder.toString());
  }
  
  public View onCreateView(String paramString, Context paramContext, AttributeSet paramAttributeSet) {
    return onCreateView(null, paramString, paramContext, paramAttributeSet);
  }
  
  void r(a parama, boolean paramBoolean1, boolean paramBoolean2, boolean paramBoolean3) {
    if (paramBoolean1) {
      parama.o(paramBoolean3);
    } else {
      parama.n();
    } 
    ArrayList<a> arrayList = new ArrayList(1);
    ArrayList<Boolean> arrayList1 = new ArrayList(1);
    arrayList.add(parama);
    arrayList1.add(Boolean.valueOf(paramBoolean1));
    if (paramBoolean2)
      k.B(this, arrayList, arrayList1, 0, 1, true); 
    if (paramBoolean3)
      F0(this.m, true); 
    SparseArray<Fragment> sparseArray = this.f;
    if (sparseArray != null) {
      int k = sparseArray.size();
      int j;
      for (j = 0; j < k; j++) {
        Fragment fragment = (Fragment)this.f.valueAt(j);
        if (fragment != null && fragment.mView != null && fragment.mIsNewlyAdded && parama.r(fragment.mContainerId)) {
          float f1 = fragment.mPostponedAlpha;
          if (f1 > 0.0F)
            fragment.mView.setAlpha(f1); 
          if (paramBoolean3) {
            fragment.mPostponedAlpha = 0.0F;
          } else {
            fragment.mPostponedAlpha = -1.0F;
            fragment.mIsNewlyAdded = false;
          } 
        } 
      } 
    } 
  }
  
  public Fragment r0(Bundle paramBundle, String paramString) {
    int j = paramBundle.getInt(paramString, -1);
    if (j == -1)
      return null; 
    Fragment fragment = (Fragment)this.f.get(j);
    if (fragment == null) {
      StringBuilder stringBuilder = new StringBuilder();
      stringBuilder.append("Fragment no longer exists for key ");
      stringBuilder.append(paramString);
      stringBuilder.append(": index ");
      stringBuilder.append(j);
      g1(new IllegalStateException(stringBuilder.toString()));
    } 
    return fragment;
  }
  
  void s(Fragment paramFragment) {
    // Byte code:
    //   0: aload_1
    //   1: getfield mView : Landroid/view/View;
    //   4: ifnull -> 213
    //   7: aload_0
    //   8: aload_1
    //   9: aload_1
    //   10: invokevirtual getNextTransition : ()I
    //   13: aload_1
    //   14: getfield mHidden : Z
    //   17: iconst_1
    //   18: ixor
    //   19: aload_1
    //   20: invokevirtual getNextTransitionStyle : ()I
    //   23: invokevirtual w0 : (Landroidx/fragment/app/Fragment;IZI)Landroidx/fragment/app/h$g;
    //   26: astore_3
    //   27: aload_3
    //   28: ifnull -> 141
    //   31: aload_3
    //   32: getfield b : Landroid/animation/Animator;
    //   35: astore #4
    //   37: aload #4
    //   39: ifnull -> 141
    //   42: aload #4
    //   44: aload_1
    //   45: getfield mView : Landroid/view/View;
    //   48: invokevirtual setTarget : (Ljava/lang/Object;)V
    //   51: aload_1
    //   52: getfield mHidden : Z
    //   55: ifeq -> 115
    //   58: aload_1
    //   59: invokevirtual isHideReplaced : ()Z
    //   62: ifeq -> 73
    //   65: aload_1
    //   66: iconst_0
    //   67: invokevirtual setHideReplaced : (Z)V
    //   70: goto -> 123
    //   73: aload_1
    //   74: getfield mContainer : Landroid/view/ViewGroup;
    //   77: astore #4
    //   79: aload_1
    //   80: getfield mView : Landroid/view/View;
    //   83: astore #5
    //   85: aload #4
    //   87: aload #5
    //   89: invokevirtual startViewTransition : (Landroid/view/View;)V
    //   92: aload_3
    //   93: getfield b : Landroid/animation/Animator;
    //   96: new androidx/fragment/app/h$d
    //   99: dup
    //   100: aload_0
    //   101: aload #4
    //   103: aload #5
    //   105: aload_1
    //   106: invokespecial <init> : (Landroidx/fragment/app/h;Landroid/view/ViewGroup;Landroid/view/View;Landroidx/fragment/app/Fragment;)V
    //   109: invokevirtual addListener : (Landroid/animation/Animator$AnimatorListener;)V
    //   112: goto -> 123
    //   115: aload_1
    //   116: getfield mView : Landroid/view/View;
    //   119: iconst_0
    //   120: invokevirtual setVisibility : (I)V
    //   123: aload_1
    //   124: getfield mView : Landroid/view/View;
    //   127: aload_3
    //   128: invokestatic a1 : (Landroid/view/View;Landroidx/fragment/app/h$g;)V
    //   131: aload_3
    //   132: getfield b : Landroid/animation/Animator;
    //   135: invokevirtual start : ()V
    //   138: goto -> 213
    //   141: aload_3
    //   142: ifnull -> 171
    //   145: aload_1
    //   146: getfield mView : Landroid/view/View;
    //   149: aload_3
    //   150: invokestatic a1 : (Landroid/view/View;Landroidx/fragment/app/h$g;)V
    //   153: aload_1
    //   154: getfield mView : Landroid/view/View;
    //   157: aload_3
    //   158: getfield a : Landroid/view/animation/Animation;
    //   161: invokevirtual startAnimation : (Landroid/view/animation/Animation;)V
    //   164: aload_3
    //   165: getfield a : Landroid/view/animation/Animation;
    //   168: invokevirtual start : ()V
    //   171: aload_1
    //   172: getfield mHidden : Z
    //   175: ifeq -> 191
    //   178: aload_1
    //   179: invokevirtual isHideReplaced : ()Z
    //   182: ifne -> 191
    //   185: bipush #8
    //   187: istore_2
    //   188: goto -> 193
    //   191: iconst_0
    //   192: istore_2
    //   193: aload_1
    //   194: getfield mView : Landroid/view/View;
    //   197: iload_2
    //   198: invokevirtual setVisibility : (I)V
    //   201: aload_1
    //   202: invokevirtual isHideReplaced : ()Z
    //   205: ifeq -> 213
    //   208: aload_1
    //   209: iconst_0
    //   210: invokevirtual setHideReplaced : (Z)V
    //   213: aload_1
    //   214: getfield mAdded : Z
    //   217: ifeq -> 239
    //   220: aload_1
    //   221: getfield mHasMenu : Z
    //   224: ifeq -> 239
    //   227: aload_1
    //   228: getfield mMenuVisible : Z
    //   231: ifeq -> 239
    //   234: aload_0
    //   235: iconst_1
    //   236: putfield r : Z
    //   239: aload_1
    //   240: iconst_0
    //   241: putfield mHiddenChanged : Z
    //   244: aload_1
    //   245: aload_1
    //   246: getfield mHidden : Z
    //   249: invokevirtual onHiddenChanged : (Z)V
    //   252: return
  }
  
  LayoutInflater.Factory2 s0() {
    return this;
  }
  
  public void t(Fragment paramFragment) {
    if (F) {
      StringBuilder stringBuilder = new StringBuilder();
      stringBuilder.append("detach: ");
      stringBuilder.append(paramFragment);
      Log.v("FragmentManager", stringBuilder.toString());
    } 
    if (!paramFragment.mDetached) {
      paramFragment.mDetached = true;
      if (paramFragment.mAdded) {
        if (F) {
          StringBuilder stringBuilder = new StringBuilder();
          stringBuilder.append("remove from detach: ");
          stringBuilder.append(paramFragment);
          Log.v("FragmentManager", stringBuilder.toString());
        } 
        synchronized (this.e) {
          this.e.remove(paramFragment);
          if (paramFragment.mHasMenu && paramFragment.mMenuVisible)
            this.r = true; 
          paramFragment.mAdded = false;
          return;
        } 
      } 
    } 
  }
  
  public Fragment t0() {
    return this.q;
  }
  
  public String toString() {
    StringBuilder stringBuilder = new StringBuilder(128);
    stringBuilder.append("FragmentManager{");
    stringBuilder.append(Integer.toHexString(System.identityHashCode(this)));
    stringBuilder.append(" in ");
    Fragment fragment = this.p;
    if (fragment != null) {
      androidx.core.util.b.a(fragment, stringBuilder);
    } else {
      androidx.core.util.b.a(this.n, stringBuilder);
    } 
    stringBuilder.append("}}");
    return stringBuilder.toString();
  }
  
  public void u() {
    this.s = false;
    this.t = false;
    Y(2);
  }
  
  public void u0(Fragment paramFragment) {
    if (F) {
      StringBuilder stringBuilder = new StringBuilder();
      stringBuilder.append("hide: ");
      stringBuilder.append(paramFragment);
      Log.v("FragmentManager", stringBuilder.toString());
    } 
    if (!paramFragment.mHidden) {
      paramFragment.mHidden = true;
      paramFragment.mHiddenChanged = true ^ paramFragment.mHiddenChanged;
    } 
  }
  
  public void v(Configuration paramConfiguration) {
    for (int j = 0; j < this.e.size(); j++) {
      Fragment fragment = this.e.get(j);
      if (fragment != null)
        fragment.performConfigurationChanged(paramConfiguration); 
    } 
  }
  
  boolean v0(int paramInt) {
    return (this.m >= paramInt);
  }
  
  public boolean w(MenuItem paramMenuItem) {
    if (this.m < 1)
      return false; 
    for (int j = 0; j < this.e.size(); j++) {
      Fragment fragment = this.e.get(j);
      if (fragment != null && fragment.performContextItemSelected(paramMenuItem))
        return true; 
    } 
    return false;
  }
  
  g w0(Fragment paramFragment, int paramInt1, boolean paramBoolean, int paramInt2) {
    Animation animation1;
    int j = paramFragment.getNextAnim();
    Animation animation2 = paramFragment.onCreateAnimation(paramInt1, paramBoolean, j);
    if (animation2 != null)
      return new g(animation2); 
    Animator animator = paramFragment.onCreateAnimator(paramInt1, paramBoolean, j);
    if (animator != null)
      return new g(animator); 
    if (j != 0) {
      boolean bool = "anim".equals(this.n.e().getResources().getResourceTypeName(j));
      boolean bool2 = false;
      boolean bool1 = bool2;
      if (bool)
        try {
          Animation animation = AnimationUtils.loadAnimation(this.n.e(), j);
          if (animation != null)
            return new g(animation); 
          bool1 = true;
        } catch (android.content.res.Resources.NotFoundException notFoundException) {
          throw notFoundException;
        } catch (RuntimeException runtimeException) {
          bool1 = bool2;
        }  
      if (!bool1)
        try {
          animator = AnimatorInflater.loadAnimator(this.n.e(), j);
          if (animator != null)
            return new g(animator); 
        } catch (RuntimeException runtimeException) {
          Animation animation;
          if (!bool) {
            animation = AnimationUtils.loadAnimation(this.n.e(), j);
            if (animation != null)
              return new g(animation); 
          } else {
            throw animation;
          } 
        }  
    } 
    animation2 = null;
    if (paramInt1 == 0)
      return null; 
    paramInt1 = h1(paramInt1, paramBoolean);
    if (paramInt1 < 0)
      return null; 
    switch (paramInt1) {
      default:
        animation1 = animation2;
        if (paramInt2 == 0) {
          animation1 = animation2;
          if (this.n.m()) {
            this.n.l();
            return null;
          } 
        } 
        return (g)animation1;
      case 6:
        return y0(this.n.e(), 1.0F, 0.0F);
      case 5:
        return y0(this.n.e(), 0.0F, 1.0F);
      case 4:
        return A0(this.n.e(), 1.0F, 1.075F, 1.0F, 0.0F);
      case 3:
        return A0(this.n.e(), 0.975F, 1.0F, 0.0F, 1.0F);
      case 2:
        return A0(this.n.e(), 1.0F, 0.975F, 1.0F, 0.0F);
      case 1:
        break;
    } 
    return A0(this.n.e(), 1.125F, 1.0F, 0.0F, 1.0F);
  }
  
  public void x() {
    this.s = false;
    this.t = false;
    Y(1);
  }
  
  void x0(Fragment paramFragment) {
    if (paramFragment.mIndex >= 0)
      return; 
    int j = this.d;
    this.d = j + 1;
    paramFragment.setIndex(j, this.p);
    if (this.f == null)
      this.f = new SparseArray(); 
    this.f.put(paramFragment.mIndex, paramFragment);
    if (F) {
      StringBuilder stringBuilder = new StringBuilder();
      stringBuilder.append("Allocated fragment index ");
      stringBuilder.append(paramFragment);
      Log.v("FragmentManager", stringBuilder.toString());
    } 
  }
  
  public boolean y(Menu paramMenu, MenuInflater paramMenuInflater) {
    int j = this.m;
    boolean bool1 = false;
    if (j < 1)
      return false; 
    ArrayList<Fragment> arrayList = null;
    j = 0;
    boolean bool2;
    for (bool2 = false; j < this.e.size(); bool2 = bool) {
      Fragment fragment = this.e.get(j);
      ArrayList<Fragment> arrayList1 = arrayList;
      boolean bool = bool2;
      if (fragment != null) {
        arrayList1 = arrayList;
        bool = bool2;
        if (fragment.performCreateOptionsMenu(paramMenu, paramMenuInflater)) {
          arrayList1 = arrayList;
          if (arrayList == null)
            arrayList1 = new ArrayList(); 
          arrayList1.add(fragment);
          bool = true;
        } 
      } 
      j++;
      arrayList = arrayList1;
    } 
    if (this.h != null)
      for (j = bool1; j < this.h.size(); j++) {
        Fragment fragment = this.h.get(j);
        if (arrayList == null || !arrayList.contains(fragment))
          fragment.onDestroyOptionsMenu(); 
      }  
    this.h = arrayList;
    return bool2;
  }
  
  public void z() {
    this.u = true;
    f0();
    Y(0);
    this.n = null;
    this.o = null;
    this.p = null;
  }
  
  void z0(Fragment paramFragment) {
    if (paramFragment.mIndex < 0)
      return; 
    if (F) {
      StringBuilder stringBuilder = new StringBuilder();
      stringBuilder.append("Freeing fragment index ");
      stringBuilder.append(paramFragment);
      Log.v("FragmentManager", stringBuilder.toString());
    } 
    this.f.put(paramFragment.mIndex, null);
    paramFragment.initState();
  }
  
  class a implements Runnable {
    a(h this$0) {}
    
    public void run() {
      this.b.f0();
    }
  }
  
  class b extends f {
    b(h this$0, Animation.AnimationListener param1AnimationListener, ViewGroup param1ViewGroup, Fragment param1Fragment) {
      super(param1AnimationListener);
    }
    
    public void onAnimationEnd(Animation param1Animation) {
      super.onAnimationEnd(param1Animation);
      this.b.post(new a(this));
    }
    
    class a implements Runnable {
      a(h.b this$0) {}
      
      public void run() {
        if (this.b.c.getAnimatingAway() != null) {
          this.b.c.setAnimatingAway(null);
          h.b b1 = this.b;
          h h = b1.d;
          Fragment fragment = b1.c;
          h.H0(fragment, fragment.getStateAfterAnimating(), 0, 0, false);
        } 
      }
    }
  }
  
  class a implements Runnable {
    a(h this$0) {}
    
    public void run() {
      if (this.b.c.getAnimatingAway() != null) {
        this.b.c.setAnimatingAway(null);
        h.b b1 = this.b;
        h h = b1.d;
        Fragment fragment = b1.c;
        h.H0(fragment, fragment.getStateAfterAnimating(), 0, 0, false);
      } 
    }
  }
  
  class c extends AnimatorListenerAdapter {
    c(h this$0, ViewGroup param1ViewGroup, View param1View, Fragment param1Fragment) {}
    
    public void onAnimationEnd(Animator param1Animator) {
      this.a.endViewTransition(this.b);
      param1Animator = this.c.getAnimator();
      this.c.setAnimator(null);
      if (param1Animator != null && this.a.indexOfChild(this.b) < 0) {
        h h1 = this.d;
        Fragment fragment = this.c;
        h1.H0(fragment, fragment.getStateAfterAnimating(), 0, 0, false);
      } 
    }
  }
  
  class d extends AnimatorListenerAdapter {
    d(h this$0, ViewGroup param1ViewGroup, View param1View, Fragment param1Fragment) {}
    
    public void onAnimationEnd(Animator param1Animator) {
      this.a.endViewTransition(this.b);
      param1Animator.removeListener((Animator.AnimatorListener)this);
      View view = this.c.mView;
      if (view != null)
        view.setVisibility(8); 
    }
  }
  
  private static class e extends f {
    View b;
    
    e(View param1View, Animation.AnimationListener param1AnimationListener) {
      super(param1AnimationListener);
      this.b = param1View;
    }
    
    public void onAnimationEnd(Animation param1Animation) {
      if (androidx.core.view.g.i(this.b) || Build.VERSION.SDK_INT >= 24) {
        this.b.post(new a(this));
      } else {
        this.b.setLayerType(0, null);
      } 
      super.onAnimationEnd(param1Animation);
    }
    
    class a implements Runnable {
      a(h.e this$0) {}
      
      public void run() {
        this.b.b.setLayerType(0, null);
      }
    }
  }
  
  class a implements Runnable {
    a(h this$0) {}
    
    public void run() {
      this.b.b.setLayerType(0, null);
    }
  }
  
  private static class f implements Animation.AnimationListener {
    private final Animation.AnimationListener a;
    
    f(Animation.AnimationListener param1AnimationListener) {
      this.a = param1AnimationListener;
    }
    
    public void onAnimationEnd(Animation param1Animation) {
      Animation.AnimationListener animationListener = this.a;
      if (animationListener != null)
        animationListener.onAnimationEnd(param1Animation); 
    }
    
    public void onAnimationRepeat(Animation param1Animation) {
      Animation.AnimationListener animationListener = this.a;
      if (animationListener != null)
        animationListener.onAnimationRepeat(param1Animation); 
    }
    
    public void onAnimationStart(Animation param1Animation) {
      Animation.AnimationListener animationListener = this.a;
      if (animationListener != null)
        animationListener.onAnimationStart(param1Animation); 
    }
  }
  
  private static class g {
    public final Animation a = null;
    
    public final Animator b;
    
    g(Animator param1Animator) {
      this.b = param1Animator;
      if (param1Animator != null)
        return; 
      throw new IllegalStateException("Animator cannot be null");
    }
    
    g(Animation param1Animation) {
      this.b = null;
      if (param1Animation != null)
        return; 
      throw new IllegalStateException("Animation cannot be null");
    }
  }
  
  private static class h extends AnimatorListenerAdapter {
    View a;
    
    h(View param1View) {
      this.a = param1View;
    }
    
    public void onAnimationEnd(Animator param1Animator) {
      this.a.setLayerType(0, null);
      param1Animator.removeListener((Animator.AnimatorListener)this);
    }
    
    public void onAnimationStart(Animator param1Animator) {
      this.a.setLayerType(2, null);
    }
  }
  
  private static class i extends AnimationSet implements Runnable {
    private final ViewGroup b;
    
    private final View c;
    
    private boolean d;
    
    private boolean e;
    
    private boolean f = true;
    
    i(Animation param1Animation, ViewGroup param1ViewGroup, View param1View) {
      super(false);
      this.b = param1ViewGroup;
      this.c = param1View;
      addAnimation(param1Animation);
      param1ViewGroup.post(this);
    }
    
    public boolean getTransformation(long param1Long, Transformation param1Transformation) {
      this.f = true;
      if (this.d)
        return this.e ^ true; 
      if (!super.getTransformation(param1Long, param1Transformation)) {
        this.d = true;
        n.a((View)this.b, this);
      } 
      return true;
    }
    
    public boolean getTransformation(long param1Long, Transformation param1Transformation, float param1Float) {
      this.f = true;
      if (this.d)
        return this.e ^ true; 
      if (!super.getTransformation(param1Long, param1Transformation, param1Float)) {
        this.d = true;
        n.a((View)this.b, this);
      } 
      return true;
    }
    
    public void run() {
      if (!this.d && this.f) {
        this.f = false;
        this.b.post(this);
        return;
      } 
      this.b.endViewTransition(this.c);
      this.e = true;
    }
  }
  
  private static final class j {
    final g.a a;
    
    final boolean b;
  }
  
  static class k {
    public static final int[] a = new int[] { 16842755, 16842960, 16842961 };
  }
  
  static interface l {
    boolean a(ArrayList<a> param1ArrayList, ArrayList<Boolean> param1ArrayList1);
  }
  
  private class m implements l {
    final String a;
    
    final int b;
    
    final int c;
    
    m(h this$0, String param1String, int param1Int1, int param1Int2) {
      this.a = param1String;
      this.b = param1Int1;
      this.c = param1Int2;
    }
    
    public boolean a(ArrayList<a> param1ArrayList, ArrayList<Boolean> param1ArrayList1) {
      Fragment fragment = this.d.q;
      if (fragment != null && this.b < 0 && this.a == null) {
        g g = fragment.peekChildFragmentManager();
        if (g != null && g.g())
          return false; 
      } 
      return this.d.L0(param1ArrayList, param1ArrayList1, this.a, this.b, this.c);
    }
  }
  
  static class n implements Fragment.f {
    final boolean a;
    
    final a b;
    
    private int c;
    
    n(a param1a, boolean param1Boolean) {
      this.a = param1Boolean;
      this.b = param1a;
    }
    
    public void a() {
      this.c++;
    }
    
    public void b() {
      int i = this.c - 1;
      this.c = i;
      if (i != 0)
        return; 
      this.b.a.Y0();
    }
    
    public void c() {
      a a1 = this.b;
      a1.a.r(a1, this.a, false, false);
    }
    
    public void d() {
      int i = this.c;
      int j = 0;
      if (i > 0) {
        i = 1;
      } else {
        i = 0;
      } 
      h h = this.b.a;
      int k = h.e.size();
      while (j < k) {
        Fragment fragment = h.e.get(j);
        fragment.setOnStartEnterTransitionListener(null);
        if (i != 0 && fragment.isPostponed())
          fragment.startPostponedEnterTransition(); 
        j++;
      } 
      a a1 = this.b;
      a1.a.r(a1, this.a, i ^ 0x1, true);
    }
    
    public boolean e() {
      return (this.c == 0);
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Hill race-dex2jar.jar!\androidx\fragment\app\h.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */