package androidx.fragment.app;

import java.io.FileDescriptor;
import java.io.PrintWriter;
import java.util.List;

public abstract class g {
  public abstract j a();
  
  public abstract void b(String paramString, FileDescriptor paramFileDescriptor, PrintWriter paramPrintWriter, String[] paramArrayOfString);
  
  public abstract Fragment c(String paramString);
  
  public abstract List<Fragment> d();
  
  public abstract boolean e();
  
  public abstract void f(int paramInt1, int paramInt2);
  
  public abstract boolean g();
  
  public static abstract class a {}
  
  public static interface b {
    void a();
  }
}


/* Location:              C:\soft\dex2jar-2.0\Hill race-dex2jar.jar!\androidx\fragment\app\g.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */