package androidx.fragment.app;

import android.animation.Animator;
import android.app.Activity;
import android.content.ComponentCallbacks;
import android.content.Context;
import android.content.Intent;
import android.content.IntentSender;
import android.content.res.Configuration;
import android.content.res.Resources;
import android.os.Bundle;
import android.os.Looper;
import android.os.Parcel;
import android.os.Parcelable;
import android.util.AttributeSet;
import android.util.SparseArray;
import android.view.ContextMenu;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.view.animation.Animation;
import androidx.core.app.l;
import androidx.lifecycle.LiveData;
import androidx.lifecycle.j;
import androidx.lifecycle.k;
import androidx.lifecycle.p;
import androidx.lifecycle.x;
import androidx.lifecycle.y;
import java.io.FileDescriptor;
import java.io.PrintWriter;
import java.lang.reflect.InvocationTargetException;

public class Fragment implements ComponentCallbacks, View.OnCreateContextMenuListener, j, y {
  static final int ACTIVITY_CREATED = 2;
  
  static final int CREATED = 1;
  
  static final int INITIALIZING = 0;
  
  static final int RESUMED = 4;
  
  static final int STARTED = 3;
  
  static final Object USE_DEFAULT_TRANSITION;
  
  private static final androidx.collection.f<String, Class<?>> sClassMap = new androidx.collection.f();
  
  boolean mAdded;
  
  d mAnimationInfo;
  
  Bundle mArguments;
  
  int mBackStackNesting;
  
  boolean mCalled;
  
  h mChildFragmentManager;
  
  i mChildNonConfig;
  
  ViewGroup mContainer;
  
  int mContainerId;
  
  boolean mDeferStart;
  
  boolean mDetached;
  
  int mFragmentId;
  
  h mFragmentManager;
  
  boolean mFromLayout;
  
  boolean mHasMenu;
  
  boolean mHidden;
  
  boolean mHiddenChanged;
  
  f mHost;
  
  boolean mInLayout;
  
  int mIndex = -1;
  
  View mInnerView;
  
  boolean mIsCreated;
  
  boolean mIsNewlyAdded;
  
  LayoutInflater mLayoutInflater;
  
  k mLifecycleRegistry = new k(this);
  
  boolean mMenuVisible = true;
  
  Fragment mParentFragment;
  
  boolean mPerformedCreateView;
  
  float mPostponedAlpha;
  
  boolean mRemoving;
  
  boolean mRestored;
  
  boolean mRetainInstance;
  
  boolean mRetaining;
  
  Bundle mSavedFragmentState;
  
  Boolean mSavedUserVisibleHint;
  
  SparseArray<Parcelable> mSavedViewState;
  
  int mState = 0;
  
  String mTag;
  
  Fragment mTarget;
  
  int mTargetIndex = -1;
  
  int mTargetRequestCode;
  
  boolean mUserVisibleHint = true;
  
  View mView;
  
  j mViewLifecycleOwner;
  
  p<j> mViewLifecycleOwnerLiveData = new p();
  
  k mViewLifecycleRegistry;
  
  x mViewModelStore;
  
  String mWho;
  
  static {
    USE_DEFAULT_TRANSITION = new Object();
  }
  
  private d ensureAnimationInfo() {
    if (this.mAnimationInfo == null)
      this.mAnimationInfo = new d(); 
    return this.mAnimationInfo;
  }
  
  public static Fragment instantiate(Context paramContext, String paramString) {
    return instantiate(paramContext, paramString, null);
  }
  
  public static Fragment instantiate(Context paramContext, String paramString, Bundle paramBundle) {
    try {
      androidx.collection.f<String, Class<?>> f1 = sClassMap;
      Class<?> clazz2 = (Class)f1.get(paramString);
      Class<?> clazz1 = clazz2;
      if (clazz2 == null) {
        clazz1 = paramContext.getClassLoader().loadClass(paramString);
        f1.put(paramString, clazz1);
      } 
      Fragment fragment = clazz1.getConstructor(new Class[0]).newInstance(new Object[0]);
      if (paramBundle != null) {
        paramBundle.setClassLoader(fragment.getClass().getClassLoader());
        fragment.setArguments(paramBundle);
      } 
      return fragment;
    } catch (ClassNotFoundException classNotFoundException) {
      StringBuilder stringBuilder = new StringBuilder();
      stringBuilder.append("Unable to instantiate fragment ");
      stringBuilder.append(paramString);
      stringBuilder.append(": make sure class name exists, is public, and has an");
      stringBuilder.append(" empty constructor that is public");
      throw new e(stringBuilder.toString(), classNotFoundException);
    } catch (InstantiationException instantiationException) {
      StringBuilder stringBuilder = new StringBuilder();
      stringBuilder.append("Unable to instantiate fragment ");
      stringBuilder.append(paramString);
      stringBuilder.append(": make sure class name exists, is public, and has an");
      stringBuilder.append(" empty constructor that is public");
      throw new e(stringBuilder.toString(), instantiationException);
    } catch (IllegalAccessException illegalAccessException) {
      StringBuilder stringBuilder = new StringBuilder();
      stringBuilder.append("Unable to instantiate fragment ");
      stringBuilder.append(paramString);
      stringBuilder.append(": make sure class name exists, is public, and has an");
      stringBuilder.append(" empty constructor that is public");
      throw new e(stringBuilder.toString(), illegalAccessException);
    } catch (NoSuchMethodException noSuchMethodException) {
      StringBuilder stringBuilder = new StringBuilder();
      stringBuilder.append("Unable to instantiate fragment ");
      stringBuilder.append(paramString);
      stringBuilder.append(": could not find Fragment constructor");
      throw new e(stringBuilder.toString(), noSuchMethodException);
    } catch (InvocationTargetException invocationTargetException) {
      StringBuilder stringBuilder = new StringBuilder();
      stringBuilder.append("Unable to instantiate fragment ");
      stringBuilder.append(paramString);
      stringBuilder.append(": calling Fragment constructor caused an exception");
      throw new e(stringBuilder.toString(), invocationTargetException);
    } 
  }
  
  static boolean isSupportFragmentClass(Context paramContext, String paramString) {
    try {
      androidx.collection.f<String, Class<?>> f1 = sClassMap;
      Class<?> clazz2 = (Class)f1.get(paramString);
      Class<?> clazz1 = clazz2;
      if (clazz2 == null) {
        clazz1 = paramContext.getClassLoader().loadClass(paramString);
        f1.put(paramString, clazz1);
      } 
      return Fragment.class.isAssignableFrom(clazz1);
    } catch (ClassNotFoundException classNotFoundException) {
      return false;
    } 
  }
  
  void callStartTransitionListener() {
    d d1 = this.mAnimationInfo;
    f f1 = null;
    if (d1 != null) {
      d1.q = false;
      f1 = d1.r;
      d1.r = null;
    } 
    if (f1 != null)
      f1.b(); 
  }
  
  public void dump(String paramString, FileDescriptor paramFileDescriptor, PrintWriter paramPrintWriter, String[] paramArrayOfString) {
    paramPrintWriter.print(paramString);
    paramPrintWriter.print("mFragmentId=#");
    paramPrintWriter.print(Integer.toHexString(this.mFragmentId));
    paramPrintWriter.print(" mContainerId=#");
    paramPrintWriter.print(Integer.toHexString(this.mContainerId));
    paramPrintWriter.print(" mTag=");
    paramPrintWriter.println(this.mTag);
    paramPrintWriter.print(paramString);
    paramPrintWriter.print("mState=");
    paramPrintWriter.print(this.mState);
    paramPrintWriter.print(" mIndex=");
    paramPrintWriter.print(this.mIndex);
    paramPrintWriter.print(" mWho=");
    paramPrintWriter.print(this.mWho);
    paramPrintWriter.print(" mBackStackNesting=");
    paramPrintWriter.println(this.mBackStackNesting);
    paramPrintWriter.print(paramString);
    paramPrintWriter.print("mAdded=");
    paramPrintWriter.print(this.mAdded);
    paramPrintWriter.print(" mRemoving=");
    paramPrintWriter.print(this.mRemoving);
    paramPrintWriter.print(" mFromLayout=");
    paramPrintWriter.print(this.mFromLayout);
    paramPrintWriter.print(" mInLayout=");
    paramPrintWriter.println(this.mInLayout);
    paramPrintWriter.print(paramString);
    paramPrintWriter.print("mHidden=");
    paramPrintWriter.print(this.mHidden);
    paramPrintWriter.print(" mDetached=");
    paramPrintWriter.print(this.mDetached);
    paramPrintWriter.print(" mMenuVisible=");
    paramPrintWriter.print(this.mMenuVisible);
    paramPrintWriter.print(" mHasMenu=");
    paramPrintWriter.println(this.mHasMenu);
    paramPrintWriter.print(paramString);
    paramPrintWriter.print("mRetainInstance=");
    paramPrintWriter.print(this.mRetainInstance);
    paramPrintWriter.print(" mRetaining=");
    paramPrintWriter.print(this.mRetaining);
    paramPrintWriter.print(" mUserVisibleHint=");
    paramPrintWriter.println(this.mUserVisibleHint);
    if (this.mFragmentManager != null) {
      paramPrintWriter.print(paramString);
      paramPrintWriter.print("mFragmentManager=");
      paramPrintWriter.println(this.mFragmentManager);
    } 
    if (this.mHost != null) {
      paramPrintWriter.print(paramString);
      paramPrintWriter.print("mHost=");
      paramPrintWriter.println(this.mHost);
    } 
    if (this.mParentFragment != null) {
      paramPrintWriter.print(paramString);
      paramPrintWriter.print("mParentFragment=");
      paramPrintWriter.println(this.mParentFragment);
    } 
    if (this.mArguments != null) {
      paramPrintWriter.print(paramString);
      paramPrintWriter.print("mArguments=");
      paramPrintWriter.println(this.mArguments);
    } 
    if (this.mSavedFragmentState != null) {
      paramPrintWriter.print(paramString);
      paramPrintWriter.print("mSavedFragmentState=");
      paramPrintWriter.println(this.mSavedFragmentState);
    } 
    if (this.mSavedViewState != null) {
      paramPrintWriter.print(paramString);
      paramPrintWriter.print("mSavedViewState=");
      paramPrintWriter.println(this.mSavedViewState);
    } 
    if (this.mTarget != null) {
      paramPrintWriter.print(paramString);
      paramPrintWriter.print("mTarget=");
      paramPrintWriter.print(this.mTarget);
      paramPrintWriter.print(" mTargetRequestCode=");
      paramPrintWriter.println(this.mTargetRequestCode);
    } 
    if (getNextAnim() != 0) {
      paramPrintWriter.print(paramString);
      paramPrintWriter.print("mNextAnim=");
      paramPrintWriter.println(getNextAnim());
    } 
    if (this.mContainer != null) {
      paramPrintWriter.print(paramString);
      paramPrintWriter.print("mContainer=");
      paramPrintWriter.println(this.mContainer);
    } 
    if (this.mView != null) {
      paramPrintWriter.print(paramString);
      paramPrintWriter.print("mView=");
      paramPrintWriter.println(this.mView);
    } 
    if (this.mInnerView != null) {
      paramPrintWriter.print(paramString);
      paramPrintWriter.print("mInnerView=");
      paramPrintWriter.println(this.mView);
    } 
    if (getAnimatingAway() != null) {
      paramPrintWriter.print(paramString);
      paramPrintWriter.print("mAnimatingAway=");
      paramPrintWriter.println(getAnimatingAway());
      paramPrintWriter.print(paramString);
      paramPrintWriter.print("mStateAfterAnimating=");
      paramPrintWriter.println(getStateAfterAnimating());
    } 
    if (getContext() != null)
      androidx.loader.app.a.b(this).a(paramString, paramFileDescriptor, paramPrintWriter, paramArrayOfString); 
    if (this.mChildFragmentManager != null) {
      paramPrintWriter.print(paramString);
      StringBuilder stringBuilder1 = new StringBuilder();
      stringBuilder1.append("Child ");
      stringBuilder1.append(this.mChildFragmentManager);
      stringBuilder1.append(":");
      paramPrintWriter.println(stringBuilder1.toString());
      h h1 = this.mChildFragmentManager;
      StringBuilder stringBuilder2 = new StringBuilder();
      stringBuilder2.append(paramString);
      stringBuilder2.append("  ");
      h1.b(stringBuilder2.toString(), paramFileDescriptor, paramPrintWriter, paramArrayOfString);
    } 
  }
  
  public final boolean equals(Object paramObject) {
    return super.equals(paramObject);
  }
  
  Fragment findFragmentByWho(String paramString) {
    if (paramString.equals(this.mWho))
      return this; 
    h h1 = this.mChildFragmentManager;
    return (h1 != null) ? h1.l0(paramString) : null;
  }
  
  public final c getActivity() {
    f f1 = this.mHost;
    return (f1 == null) ? null : (c)f1.d();
  }
  
  public boolean getAllowEnterTransitionOverlap() {
    d d1 = this.mAnimationInfo;
    if (d1 != null) {
      Boolean bool = d1.n;
      if (bool != null)
        return bool.booleanValue(); 
    } 
    return true;
  }
  
  public boolean getAllowReturnTransitionOverlap() {
    d d1 = this.mAnimationInfo;
    if (d1 != null) {
      Boolean bool = d1.m;
      if (bool != null)
        return bool.booleanValue(); 
    } 
    return true;
  }
  
  View getAnimatingAway() {
    d d1 = this.mAnimationInfo;
    return (d1 == null) ? null : d1.a;
  }
  
  Animator getAnimator() {
    d d1 = this.mAnimationInfo;
    return (d1 == null) ? null : d1.b;
  }
  
  public final Bundle getArguments() {
    return this.mArguments;
  }
  
  public final g getChildFragmentManager() {
    if (this.mChildFragmentManager == null) {
      instantiateChildFragmentManager();
      int m = this.mState;
      if (m >= 4) {
        this.mChildFragmentManager.W();
      } else if (m >= 3) {
        this.mChildFragmentManager.X();
      } else if (m >= 2) {
        this.mChildFragmentManager.u();
      } else if (m >= 1) {
        this.mChildFragmentManager.x();
      } 
    } 
    return this.mChildFragmentManager;
  }
  
  public Context getContext() {
    f f1 = this.mHost;
    return (f1 == null) ? null : f1.e();
  }
  
  public Object getEnterTransition() {
    d d1 = this.mAnimationInfo;
    return (d1 == null) ? null : d1.g;
  }
  
  l getEnterTransitionCallback() {
    d d1 = this.mAnimationInfo;
    return (d1 == null) ? null : d1.o;
  }
  
  public Object getExitTransition() {
    d d1 = this.mAnimationInfo;
    return (d1 == null) ? null : d1.i;
  }
  
  l getExitTransitionCallback() {
    d d1 = this.mAnimationInfo;
    return (d1 == null) ? null : d1.p;
  }
  
  public final g getFragmentManager() {
    return this.mFragmentManager;
  }
  
  public final Object getHost() {
    f f1 = this.mHost;
    return (f1 == null) ? null : f1.j();
  }
  
  public final int getId() {
    return this.mFragmentId;
  }
  
  public final LayoutInflater getLayoutInflater() {
    LayoutInflater layoutInflater2 = this.mLayoutInflater;
    LayoutInflater layoutInflater1 = layoutInflater2;
    if (layoutInflater2 == null)
      layoutInflater1 = performGetLayoutInflater(null); 
    return layoutInflater1;
  }
  
  @Deprecated
  public LayoutInflater getLayoutInflater(Bundle paramBundle) {
    f f1 = this.mHost;
    if (f1 != null) {
      LayoutInflater layoutInflater = f1.k();
      getChildFragmentManager();
      androidx.core.view.c.b(layoutInflater, this.mChildFragmentManager.s0());
      return layoutInflater;
    } 
    throw new IllegalStateException("onGetLayoutInflater() cannot be executed until the Fragment is attached to the FragmentManager.");
  }
  
  public androidx.lifecycle.f getLifecycle() {
    return (androidx.lifecycle.f)this.mLifecycleRegistry;
  }
  
  @Deprecated
  public androidx.loader.app.a getLoaderManager() {
    return androidx.loader.app.a.b(this);
  }
  
  int getNextAnim() {
    d d1 = this.mAnimationInfo;
    return (d1 == null) ? 0 : d1.d;
  }
  
  int getNextTransition() {
    d d1 = this.mAnimationInfo;
    return (d1 == null) ? 0 : d1.e;
  }
  
  int getNextTransitionStyle() {
    d d1 = this.mAnimationInfo;
    return (d1 == null) ? 0 : d1.f;
  }
  
  public final Fragment getParentFragment() {
    return this.mParentFragment;
  }
  
  public Object getReenterTransition() {
    d d1 = this.mAnimationInfo;
    if (d1 == null)
      return null; 
    Object object2 = d1.j;
    Object object1 = object2;
    if (object2 == USE_DEFAULT_TRANSITION)
      object1 = getExitTransition(); 
    return object1;
  }
  
  public final Resources getResources() {
    return requireContext().getResources();
  }
  
  public final boolean getRetainInstance() {
    return this.mRetainInstance;
  }
  
  public Object getReturnTransition() {
    d d1 = this.mAnimationInfo;
    if (d1 == null)
      return null; 
    Object object2 = d1.h;
    Object object1 = object2;
    if (object2 == USE_DEFAULT_TRANSITION)
      object1 = getEnterTransition(); 
    return object1;
  }
  
  public Object getSharedElementEnterTransition() {
    d d1 = this.mAnimationInfo;
    return (d1 == null) ? null : d1.k;
  }
  
  public Object getSharedElementReturnTransition() {
    d d1 = this.mAnimationInfo;
    if (d1 == null)
      return null; 
    Object object2 = d1.l;
    Object object1 = object2;
    if (object2 == USE_DEFAULT_TRANSITION)
      object1 = getSharedElementEnterTransition(); 
    return object1;
  }
  
  int getStateAfterAnimating() {
    d d1 = this.mAnimationInfo;
    return (d1 == null) ? 0 : d1.c;
  }
  
  public final String getString(int paramInt) {
    return getResources().getString(paramInt);
  }
  
  public final String getString(int paramInt, Object... paramVarArgs) {
    return getResources().getString(paramInt, paramVarArgs);
  }
  
  public final String getTag() {
    return this.mTag;
  }
  
  public final Fragment getTargetFragment() {
    return this.mTarget;
  }
  
  public final int getTargetRequestCode() {
    return this.mTargetRequestCode;
  }
  
  public final CharSequence getText(int paramInt) {
    return getResources().getText(paramInt);
  }
  
  public boolean getUserVisibleHint() {
    return this.mUserVisibleHint;
  }
  
  public View getView() {
    return this.mView;
  }
  
  public j getViewLifecycleOwner() {
    j j1 = this.mViewLifecycleOwner;
    if (j1 != null)
      return j1; 
    throw new IllegalStateException("Can't access the Fragment View's LifecycleOwner when getView() is null i.e., before onCreateView() or after onDestroyView()");
  }
  
  public LiveData<j> getViewLifecycleOwnerLiveData() {
    return (LiveData<j>)this.mViewLifecycleOwnerLiveData;
  }
  
  public x getViewModelStore() {
    if (getContext() != null) {
      if (this.mViewModelStore == null)
        this.mViewModelStore = new x(); 
      return this.mViewModelStore;
    } 
    throw new IllegalStateException("Can't access ViewModels from detached fragment");
  }
  
  public final boolean hasOptionsMenu() {
    return this.mHasMenu;
  }
  
  public final int hashCode() {
    return super.hashCode();
  }
  
  void initState() {
    this.mIndex = -1;
    this.mWho = null;
    this.mAdded = false;
    this.mRemoving = false;
    this.mFromLayout = false;
    this.mInLayout = false;
    this.mRestored = false;
    this.mBackStackNesting = 0;
    this.mFragmentManager = null;
    this.mChildFragmentManager = null;
    this.mHost = null;
    this.mFragmentId = 0;
    this.mContainerId = 0;
    this.mTag = null;
    this.mHidden = false;
    this.mDetached = false;
    this.mRetaining = false;
  }
  
  void instantiateChildFragmentManager() {
    if (this.mHost != null) {
      h h1 = new h();
      this.mChildFragmentManager = h1;
      h1.m(this.mHost, new b(this), this);
      return;
    } 
    throw new IllegalStateException("Fragment has not been attached yet.");
  }
  
  public final boolean isAdded() {
    return (this.mHost != null && this.mAdded);
  }
  
  public final boolean isDetached() {
    return this.mDetached;
  }
  
  public final boolean isHidden() {
    return this.mHidden;
  }
  
  boolean isHideReplaced() {
    d d1 = this.mAnimationInfo;
    return (d1 == null) ? false : d1.s;
  }
  
  final boolean isInBackStack() {
    return (this.mBackStackNesting > 0);
  }
  
  public final boolean isInLayout() {
    return this.mInLayout;
  }
  
  public final boolean isMenuVisible() {
    return this.mMenuVisible;
  }
  
  boolean isPostponed() {
    d d1 = this.mAnimationInfo;
    return (d1 == null) ? false : d1.q;
  }
  
  public final boolean isRemoving() {
    return this.mRemoving;
  }
  
  public final boolean isResumed() {
    return (this.mState >= 4);
  }
  
  public final boolean isStateSaved() {
    h h1 = this.mFragmentManager;
    return (h1 == null) ? false : h1.e();
  }
  
  public final boolean isVisible() {
    if (isAdded() && !isHidden()) {
      View view = this.mView;
      if (view != null && view.getWindowToken() != null && this.mView.getVisibility() == 0)
        return true; 
    } 
    return false;
  }
  
  void noteStateNotSaved() {
    h h1 = this.mChildFragmentManager;
    if (h1 != null)
      h1.I0(); 
  }
  
  public void onActivityCreated(Bundle paramBundle) {
    this.mCalled = true;
  }
  
  public void onActivityResult(int paramInt1, int paramInt2, Intent paramIntent) {}
  
  @Deprecated
  public void onAttach(Activity paramActivity) {
    this.mCalled = true;
  }
  
  public void onAttach(Context paramContext) {
    Activity activity;
    this.mCalled = true;
    f f1 = this.mHost;
    if (f1 == null) {
      f1 = null;
    } else {
      activity = f1.d();
    } 
    if (activity != null) {
      this.mCalled = false;
      onAttach(activity);
    } 
  }
  
  public void onAttachFragment(Fragment paramFragment) {}
  
  public void onConfigurationChanged(Configuration paramConfiguration) {
    this.mCalled = true;
  }
  
  public boolean onContextItemSelected(MenuItem paramMenuItem) {
    return false;
  }
  
  public void onCreate(Bundle paramBundle) {
    this.mCalled = true;
    restoreChildFragmentState(paramBundle);
    h h1 = this.mChildFragmentManager;
    if (h1 != null && !h1.v0(1))
      this.mChildFragmentManager.x(); 
  }
  
  public Animation onCreateAnimation(int paramInt1, boolean paramBoolean, int paramInt2) {
    return null;
  }
  
  public Animator onCreateAnimator(int paramInt1, boolean paramBoolean, int paramInt2) {
    return null;
  }
  
  public void onCreateContextMenu(ContextMenu paramContextMenu, View paramView, ContextMenu.ContextMenuInfo paramContextMenuInfo) {
    getActivity().onCreateContextMenu(paramContextMenu, paramView, paramContextMenuInfo);
  }
  
  public void onCreateOptionsMenu(Menu paramMenu, MenuInflater paramMenuInflater) {}
  
  public View onCreateView(LayoutInflater paramLayoutInflater, ViewGroup paramViewGroup, Bundle paramBundle) {
    return null;
  }
  
  public void onDestroy() {
    boolean bool = true;
    this.mCalled = true;
    c c = getActivity();
    if (c == null || !c.isChangingConfigurations())
      bool = false; 
    x x1 = this.mViewModelStore;
    if (x1 != null && !bool)
      x1.a(); 
  }
  
  public void onDestroyOptionsMenu() {}
  
  public void onDestroyView() {
    this.mCalled = true;
  }
  
  public void onDetach() {
    this.mCalled = true;
  }
  
  public LayoutInflater onGetLayoutInflater(Bundle paramBundle) {
    return getLayoutInflater(paramBundle);
  }
  
  public void onHiddenChanged(boolean paramBoolean) {}
  
  @Deprecated
  public void onInflate(Activity paramActivity, AttributeSet paramAttributeSet, Bundle paramBundle) {
    this.mCalled = true;
  }
  
  public void onInflate(Context paramContext, AttributeSet paramAttributeSet, Bundle paramBundle) {
    Activity activity;
    this.mCalled = true;
    f f1 = this.mHost;
    if (f1 == null) {
      f1 = null;
    } else {
      activity = f1.d();
    } 
    if (activity != null) {
      this.mCalled = false;
      onInflate(activity, paramAttributeSet, paramBundle);
    } 
  }
  
  public void onLowMemory() {
    this.mCalled = true;
  }
  
  public void onMultiWindowModeChanged(boolean paramBoolean) {}
  
  public boolean onOptionsItemSelected(MenuItem paramMenuItem) {
    return false;
  }
  
  public void onOptionsMenuClosed(Menu paramMenu) {}
  
  public void onPause() {
    this.mCalled = true;
  }
  
  public void onPictureInPictureModeChanged(boolean paramBoolean) {}
  
  public void onPrepareOptionsMenu(Menu paramMenu) {}
  
  public void onRequestPermissionsResult(int paramInt, String[] paramArrayOfString, int[] paramArrayOfint) {}
  
  public void onResume() {
    this.mCalled = true;
  }
  
  public void onSaveInstanceState(Bundle paramBundle) {}
  
  public void onStart() {
    this.mCalled = true;
  }
  
  public void onStop() {
    this.mCalled = true;
  }
  
  public void onViewCreated(View paramView, Bundle paramBundle) {}
  
  public void onViewStateRestored(Bundle paramBundle) {
    this.mCalled = true;
  }
  
  g peekChildFragmentManager() {
    return this.mChildFragmentManager;
  }
  
  void performActivityCreated(Bundle paramBundle) {
    h h1 = this.mChildFragmentManager;
    if (h1 != null)
      h1.I0(); 
    this.mState = 2;
    this.mCalled = false;
    onActivityCreated(paramBundle);
    if (this.mCalled) {
      h h2 = this.mChildFragmentManager;
      if (h2 != null)
        h2.u(); 
      return;
    } 
    StringBuilder stringBuilder = new StringBuilder();
    stringBuilder.append("Fragment ");
    stringBuilder.append(this);
    stringBuilder.append(" did not call through to super.onActivityCreated()");
    throw new o(stringBuilder.toString());
  }
  
  void performConfigurationChanged(Configuration paramConfiguration) {
    onConfigurationChanged(paramConfiguration);
    h h1 = this.mChildFragmentManager;
    if (h1 != null)
      h1.v(paramConfiguration); 
  }
  
  boolean performContextItemSelected(MenuItem paramMenuItem) {
    if (!this.mHidden) {
      if (onContextItemSelected(paramMenuItem))
        return true; 
      h h1 = this.mChildFragmentManager;
      if (h1 != null && h1.w(paramMenuItem))
        return true; 
    } 
    return false;
  }
  
  void performCreate(Bundle paramBundle) {
    h h1 = this.mChildFragmentManager;
    if (h1 != null)
      h1.I0(); 
    this.mState = 1;
    this.mCalled = false;
    onCreate(paramBundle);
    this.mIsCreated = true;
    if (this.mCalled) {
      this.mLifecycleRegistry.h(androidx.lifecycle.f.b.ON_CREATE);
      return;
    } 
    StringBuilder stringBuilder = new StringBuilder();
    stringBuilder.append("Fragment ");
    stringBuilder.append(this);
    stringBuilder.append(" did not call through to super.onCreate()");
    throw new o(stringBuilder.toString());
  }
  
  boolean performCreateOptionsMenu(Menu paramMenu, MenuInflater paramMenuInflater) {
    boolean bool2 = this.mHidden;
    boolean bool1 = false;
    boolean bool = false;
    if (!bool2) {
      bool2 = bool;
      if (this.mHasMenu) {
        bool2 = bool;
        if (this.mMenuVisible) {
          onCreateOptionsMenu(paramMenu, paramMenuInflater);
          bool2 = true;
        } 
      } 
      h h1 = this.mChildFragmentManager;
      bool1 = bool2;
      if (h1 != null)
        bool1 = bool2 | h1.y(paramMenu, paramMenuInflater); 
    } 
    return bool1;
  }
  
  void performCreateView(LayoutInflater paramLayoutInflater, ViewGroup paramViewGroup, Bundle paramBundle) {
    h h1 = this.mChildFragmentManager;
    if (h1 != null)
      h1.I0(); 
    this.mPerformedCreateView = true;
    this.mViewLifecycleOwner = new c(this);
    this.mViewLifecycleRegistry = null;
    View view = onCreateView(paramLayoutInflater, paramViewGroup, paramBundle);
    this.mView = view;
    if (view != null) {
      this.mViewLifecycleOwner.getLifecycle();
      this.mViewLifecycleOwnerLiveData.h(this.mViewLifecycleOwner);
      return;
    } 
    if (this.mViewLifecycleRegistry == null) {
      this.mViewLifecycleOwner = null;
      return;
    } 
    throw new IllegalStateException("Called getViewLifecycleOwner() but onCreateView() returned null");
  }
  
  void performDestroy() {
    this.mLifecycleRegistry.h(androidx.lifecycle.f.b.ON_DESTROY);
    h h1 = this.mChildFragmentManager;
    if (h1 != null)
      h1.z(); 
    this.mState = 0;
    this.mCalled = false;
    this.mIsCreated = false;
    onDestroy();
    if (this.mCalled) {
      this.mChildFragmentManager = null;
      return;
    } 
    StringBuilder stringBuilder = new StringBuilder();
    stringBuilder.append("Fragment ");
    stringBuilder.append(this);
    stringBuilder.append(" did not call through to super.onDestroy()");
    throw new o(stringBuilder.toString());
  }
  
  void performDestroyView() {
    if (this.mView != null)
      this.mViewLifecycleRegistry.h(androidx.lifecycle.f.b.ON_DESTROY); 
    h h1 = this.mChildFragmentManager;
    if (h1 != null)
      h1.A(); 
    this.mState = 1;
    this.mCalled = false;
    onDestroyView();
    if (this.mCalled) {
      androidx.loader.app.a.b(this).c();
      this.mPerformedCreateView = false;
      return;
    } 
    StringBuilder stringBuilder = new StringBuilder();
    stringBuilder.append("Fragment ");
    stringBuilder.append(this);
    stringBuilder.append(" did not call through to super.onDestroyView()");
    throw new o(stringBuilder.toString());
  }
  
  void performDetach() {
    this.mCalled = false;
    onDetach();
    this.mLayoutInflater = null;
    if (this.mCalled) {
      h h1 = this.mChildFragmentManager;
      if (h1 != null) {
        if (this.mRetaining) {
          h1.z();
          this.mChildFragmentManager = null;
          return;
        } 
        StringBuilder stringBuilder1 = new StringBuilder();
        stringBuilder1.append("Child FragmentManager of ");
        stringBuilder1.append(this);
        stringBuilder1.append(" was not ");
        stringBuilder1.append(" destroyed and this fragment is not retaining instance");
        throw new IllegalStateException(stringBuilder1.toString());
      } 
      return;
    } 
    StringBuilder stringBuilder = new StringBuilder();
    stringBuilder.append("Fragment ");
    stringBuilder.append(this);
    stringBuilder.append(" did not call through to super.onDetach()");
    throw new o(stringBuilder.toString());
  }
  
  LayoutInflater performGetLayoutInflater(Bundle paramBundle) {
    LayoutInflater layoutInflater = onGetLayoutInflater(paramBundle);
    this.mLayoutInflater = layoutInflater;
    return layoutInflater;
  }
  
  void performLowMemory() {
    onLowMemory();
    h h1 = this.mChildFragmentManager;
    if (h1 != null)
      h1.B(); 
  }
  
  void performMultiWindowModeChanged(boolean paramBoolean) {
    onMultiWindowModeChanged(paramBoolean);
    h h1 = this.mChildFragmentManager;
    if (h1 != null)
      h1.C(paramBoolean); 
  }
  
  boolean performOptionsItemSelected(MenuItem paramMenuItem) {
    if (!this.mHidden) {
      if (this.mHasMenu && this.mMenuVisible && onOptionsItemSelected(paramMenuItem))
        return true; 
      h h1 = this.mChildFragmentManager;
      if (h1 != null && h1.R(paramMenuItem))
        return true; 
    } 
    return false;
  }
  
  void performOptionsMenuClosed(Menu paramMenu) {
    if (!this.mHidden) {
      if (this.mHasMenu && this.mMenuVisible)
        onOptionsMenuClosed(paramMenu); 
      h h1 = this.mChildFragmentManager;
      if (h1 != null)
        h1.S(paramMenu); 
    } 
  }
  
  void performPause() {
    if (this.mView != null)
      this.mViewLifecycleRegistry.h(androidx.lifecycle.f.b.ON_PAUSE); 
    this.mLifecycleRegistry.h(androidx.lifecycle.f.b.ON_PAUSE);
    h h1 = this.mChildFragmentManager;
    if (h1 != null)
      h1.T(); 
    this.mState = 3;
    this.mCalled = false;
    onPause();
    if (this.mCalled)
      return; 
    StringBuilder stringBuilder = new StringBuilder();
    stringBuilder.append("Fragment ");
    stringBuilder.append(this);
    stringBuilder.append(" did not call through to super.onPause()");
    throw new o(stringBuilder.toString());
  }
  
  void performPictureInPictureModeChanged(boolean paramBoolean) {
    onPictureInPictureModeChanged(paramBoolean);
    h h1 = this.mChildFragmentManager;
    if (h1 != null)
      h1.U(paramBoolean); 
  }
  
  boolean performPrepareOptionsMenu(Menu paramMenu) {
    boolean bool2 = this.mHidden;
    boolean bool1 = false;
    boolean bool = false;
    if (!bool2) {
      bool2 = bool;
      if (this.mHasMenu) {
        bool2 = bool;
        if (this.mMenuVisible) {
          onPrepareOptionsMenu(paramMenu);
          bool2 = true;
        } 
      } 
      h h1 = this.mChildFragmentManager;
      bool1 = bool2;
      if (h1 != null)
        bool1 = bool2 | h1.V(paramMenu); 
    } 
    return bool1;
  }
  
  void performResume() {
    h h1 = this.mChildFragmentManager;
    if (h1 != null) {
      h1.I0();
      this.mChildFragmentManager.f0();
    } 
    this.mState = 4;
    this.mCalled = false;
    onResume();
    if (this.mCalled) {
      h1 = this.mChildFragmentManager;
      if (h1 != null) {
        h1.W();
        this.mChildFragmentManager.f0();
      } 
      k k1 = this.mLifecycleRegistry;
      androidx.lifecycle.f.b b = androidx.lifecycle.f.b.ON_RESUME;
      k1.h(b);
      if (this.mView != null)
        this.mViewLifecycleRegistry.h(b); 
      return;
    } 
    StringBuilder stringBuilder = new StringBuilder();
    stringBuilder.append("Fragment ");
    stringBuilder.append(this);
    stringBuilder.append(" did not call through to super.onResume()");
    throw new o(stringBuilder.toString());
  }
  
  void performSaveInstanceState(Bundle paramBundle) {
    onSaveInstanceState(paramBundle);
    h h1 = this.mChildFragmentManager;
    if (h1 != null) {
      Parcelable parcelable = h1.U0();
      if (parcelable != null)
        paramBundle.putParcelable("android:support:fragments", parcelable); 
    } 
  }
  
  void performStart() {
    h h1 = this.mChildFragmentManager;
    if (h1 != null) {
      h1.I0();
      this.mChildFragmentManager.f0();
    } 
    this.mState = 3;
    this.mCalled = false;
    onStart();
    if (this.mCalled) {
      h1 = this.mChildFragmentManager;
      if (h1 != null)
        h1.X(); 
      k k1 = this.mLifecycleRegistry;
      androidx.lifecycle.f.b b = androidx.lifecycle.f.b.ON_START;
      k1.h(b);
      if (this.mView != null)
        this.mViewLifecycleRegistry.h(b); 
      return;
    } 
    StringBuilder stringBuilder = new StringBuilder();
    stringBuilder.append("Fragment ");
    stringBuilder.append(this);
    stringBuilder.append(" did not call through to super.onStart()");
    throw new o(stringBuilder.toString());
  }
  
  void performStop() {
    if (this.mView != null)
      this.mViewLifecycleRegistry.h(androidx.lifecycle.f.b.ON_STOP); 
    this.mLifecycleRegistry.h(androidx.lifecycle.f.b.ON_STOP);
    h h1 = this.mChildFragmentManager;
    if (h1 != null)
      h1.Z(); 
    this.mState = 2;
    this.mCalled = false;
    onStop();
    if (this.mCalled)
      return; 
    StringBuilder stringBuilder = new StringBuilder();
    stringBuilder.append("Fragment ");
    stringBuilder.append(this);
    stringBuilder.append(" did not call through to super.onStop()");
    throw new o(stringBuilder.toString());
  }
  
  public void postponeEnterTransition() {
    (ensureAnimationInfo()).q = true;
  }
  
  public void registerForContextMenu(View paramView) {
    paramView.setOnCreateContextMenuListener(this);
  }
  
  public final void requestPermissions(String[] paramArrayOfString, int paramInt) {
    f f1 = this.mHost;
    if (f1 != null) {
      f1.n(this, paramArrayOfString, paramInt);
      return;
    } 
    StringBuilder stringBuilder = new StringBuilder();
    stringBuilder.append("Fragment ");
    stringBuilder.append(this);
    stringBuilder.append(" not attached to Activity");
    throw new IllegalStateException(stringBuilder.toString());
  }
  
  public final c requireActivity() {
    c c = getActivity();
    if (c != null)
      return c; 
    StringBuilder stringBuilder = new StringBuilder();
    stringBuilder.append("Fragment ");
    stringBuilder.append(this);
    stringBuilder.append(" not attached to an activity.");
    throw new IllegalStateException(stringBuilder.toString());
  }
  
  public final Context requireContext() {
    Context context = getContext();
    if (context != null)
      return context; 
    StringBuilder stringBuilder = new StringBuilder();
    stringBuilder.append("Fragment ");
    stringBuilder.append(this);
    stringBuilder.append(" not attached to a context.");
    throw new IllegalStateException(stringBuilder.toString());
  }
  
  public final g requireFragmentManager() {
    g g = getFragmentManager();
    if (g != null)
      return g; 
    StringBuilder stringBuilder = new StringBuilder();
    stringBuilder.append("Fragment ");
    stringBuilder.append(this);
    stringBuilder.append(" not associated with a fragment manager.");
    throw new IllegalStateException(stringBuilder.toString());
  }
  
  public final Object requireHost() {
    Object object = getHost();
    if (object != null)
      return object; 
    object = new StringBuilder();
    object.append("Fragment ");
    object.append(this);
    object.append(" not attached to a host.");
    throw new IllegalStateException(object.toString());
  }
  
  void restoreChildFragmentState(Bundle paramBundle) {
    if (paramBundle != null) {
      Parcelable parcelable = paramBundle.getParcelable("android:support:fragments");
      if (parcelable != null) {
        if (this.mChildFragmentManager == null)
          instantiateChildFragmentManager(); 
        this.mChildFragmentManager.R0(parcelable, this.mChildNonConfig);
        this.mChildNonConfig = null;
        this.mChildFragmentManager.x();
      } 
    } 
  }
  
  final void restoreViewState(Bundle paramBundle) {
    SparseArray<Parcelable> sparseArray = this.mSavedViewState;
    if (sparseArray != null) {
      this.mInnerView.restoreHierarchyState(sparseArray);
      this.mSavedViewState = null;
    } 
    this.mCalled = false;
    onViewStateRestored(paramBundle);
    if (this.mCalled) {
      if (this.mView != null)
        this.mViewLifecycleRegistry.h(androidx.lifecycle.f.b.ON_CREATE); 
      return;
    } 
    StringBuilder stringBuilder = new StringBuilder();
    stringBuilder.append("Fragment ");
    stringBuilder.append(this);
    stringBuilder.append(" did not call through to super.onViewStateRestored()");
    throw new o(stringBuilder.toString());
  }
  
  public void setAllowEnterTransitionOverlap(boolean paramBoolean) {
    (ensureAnimationInfo()).n = Boolean.valueOf(paramBoolean);
  }
  
  public void setAllowReturnTransitionOverlap(boolean paramBoolean) {
    (ensureAnimationInfo()).m = Boolean.valueOf(paramBoolean);
  }
  
  void setAnimatingAway(View paramView) {
    (ensureAnimationInfo()).a = paramView;
  }
  
  void setAnimator(Animator paramAnimator) {
    (ensureAnimationInfo()).b = paramAnimator;
  }
  
  public void setArguments(Bundle paramBundle) {
    if (this.mIndex < 0 || !isStateSaved()) {
      this.mArguments = paramBundle;
      return;
    } 
    throw new IllegalStateException("Fragment already active and state has been saved");
  }
  
  public void setEnterSharedElementCallback(l paraml) {
    (ensureAnimationInfo()).o = paraml;
  }
  
  public void setEnterTransition(Object paramObject) {
    (ensureAnimationInfo()).g = paramObject;
  }
  
  public void setExitSharedElementCallback(l paraml) {
    (ensureAnimationInfo()).p = paraml;
  }
  
  public void setExitTransition(Object paramObject) {
    (ensureAnimationInfo()).i = paramObject;
  }
  
  public void setHasOptionsMenu(boolean paramBoolean) {
    if (this.mHasMenu != paramBoolean) {
      this.mHasMenu = paramBoolean;
      if (isAdded() && !isHidden())
        this.mHost.s(); 
    } 
  }
  
  void setHideReplaced(boolean paramBoolean) {
    (ensureAnimationInfo()).s = paramBoolean;
  }
  
  final void setIndex(int paramInt, Fragment paramFragment) {
    this.mIndex = paramInt;
    if (paramFragment != null) {
      StringBuilder stringBuilder1 = new StringBuilder();
      stringBuilder1.append(paramFragment.mWho);
      stringBuilder1.append(":");
      stringBuilder1.append(this.mIndex);
      this.mWho = stringBuilder1.toString();
      return;
    } 
    StringBuilder stringBuilder = new StringBuilder();
    stringBuilder.append("android:fragment:");
    stringBuilder.append(this.mIndex);
    this.mWho = stringBuilder.toString();
  }
  
  public void setInitialSavedState(SavedState paramSavedState) {
    if (this.mIndex < 0) {
      if (paramSavedState != null) {
        Bundle bundle = paramSavedState.b;
        if (bundle != null) {
          this.mSavedFragmentState = bundle;
          return;
        } 
      } 
      paramSavedState = null;
    } else {
      throw new IllegalStateException("Fragment already active");
    } 
    this.mSavedFragmentState = (Bundle)paramSavedState;
  }
  
  public void setMenuVisibility(boolean paramBoolean) {
    if (this.mMenuVisible != paramBoolean) {
      this.mMenuVisible = paramBoolean;
      if (this.mHasMenu && isAdded() && !isHidden())
        this.mHost.s(); 
    } 
  }
  
  void setNextAnim(int paramInt) {
    if (this.mAnimationInfo == null && paramInt == 0)
      return; 
    (ensureAnimationInfo()).d = paramInt;
  }
  
  void setNextTransition(int paramInt1, int paramInt2) {
    if (this.mAnimationInfo == null && paramInt1 == 0 && paramInt2 == 0)
      return; 
    ensureAnimationInfo();
    d d1 = this.mAnimationInfo;
    d1.e = paramInt1;
    d1.f = paramInt2;
  }
  
  void setOnStartEnterTransitionListener(f paramf) {
    ensureAnimationInfo();
    d d1 = this.mAnimationInfo;
    f f1 = d1.r;
    if (paramf == f1)
      return; 
    if (paramf == null || f1 == null) {
      if (d1.q)
        d1.r = paramf; 
      if (paramf != null)
        paramf.a(); 
      return;
    } 
    StringBuilder stringBuilder = new StringBuilder();
    stringBuilder.append("Trying to set a replacement startPostponedEnterTransition on ");
    stringBuilder.append(this);
    throw new IllegalStateException(stringBuilder.toString());
  }
  
  public void setReenterTransition(Object paramObject) {
    (ensureAnimationInfo()).j = paramObject;
  }
  
  public void setRetainInstance(boolean paramBoolean) {
    this.mRetainInstance = paramBoolean;
  }
  
  public void setReturnTransition(Object paramObject) {
    (ensureAnimationInfo()).h = paramObject;
  }
  
  public void setSharedElementEnterTransition(Object paramObject) {
    (ensureAnimationInfo()).k = paramObject;
  }
  
  public void setSharedElementReturnTransition(Object paramObject) {
    (ensureAnimationInfo()).l = paramObject;
  }
  
  void setStateAfterAnimating(int paramInt) {
    (ensureAnimationInfo()).c = paramInt;
  }
  
  public void setTargetFragment(Fragment paramFragment, int paramInt) {
    g g1;
    g g2 = getFragmentManager();
    if (paramFragment != null) {
      g1 = paramFragment.getFragmentManager();
    } else {
      g1 = null;
    } 
    if (g2 == null || g1 == null || g2 == g1) {
      Fragment fragment = paramFragment;
      while (fragment != null) {
        if (fragment != this) {
          fragment = fragment.getTargetFragment();
          continue;
        } 
        StringBuilder stringBuilder1 = new StringBuilder();
        stringBuilder1.append("Setting ");
        stringBuilder1.append(paramFragment);
        stringBuilder1.append(" as the target of ");
        stringBuilder1.append(this);
        stringBuilder1.append(" would create a target cycle");
        throw new IllegalArgumentException(stringBuilder1.toString());
      } 
      this.mTarget = paramFragment;
      this.mTargetRequestCode = paramInt;
      return;
    } 
    StringBuilder stringBuilder = new StringBuilder();
    stringBuilder.append("Fragment ");
    stringBuilder.append(paramFragment);
    stringBuilder.append(" must share the same FragmentManager to be set as a target fragment");
    throw new IllegalArgumentException(stringBuilder.toString());
  }
  
  public void setUserVisibleHint(boolean paramBoolean) {
    boolean bool;
    if (!this.mUserVisibleHint && paramBoolean && this.mState < 3 && this.mFragmentManager != null && isAdded() && this.mIsCreated)
      this.mFragmentManager.J0(this); 
    this.mUserVisibleHint = paramBoolean;
    if (this.mState < 3 && !paramBoolean) {
      bool = true;
    } else {
      bool = false;
    } 
    this.mDeferStart = bool;
    if (this.mSavedFragmentState != null)
      this.mSavedUserVisibleHint = Boolean.valueOf(paramBoolean); 
  }
  
  public boolean shouldShowRequestPermissionRationale(String paramString) {
    f f1 = this.mHost;
    return (f1 != null) ? f1.p(paramString) : false;
  }
  
  public void startActivity(Intent paramIntent) {
    startActivity(paramIntent, null);
  }
  
  public void startActivity(Intent paramIntent, Bundle paramBundle) {
    f f1 = this.mHost;
    if (f1 != null) {
      f1.q(this, paramIntent, -1, paramBundle);
      return;
    } 
    StringBuilder stringBuilder = new StringBuilder();
    stringBuilder.append("Fragment ");
    stringBuilder.append(this);
    stringBuilder.append(" not attached to Activity");
    throw new IllegalStateException(stringBuilder.toString());
  }
  
  public void startActivityForResult(Intent paramIntent, int paramInt) {
    startActivityForResult(paramIntent, paramInt, null);
  }
  
  public void startActivityForResult(Intent paramIntent, int paramInt, Bundle paramBundle) {
    f f1 = this.mHost;
    if (f1 != null) {
      f1.q(this, paramIntent, paramInt, paramBundle);
      return;
    } 
    StringBuilder stringBuilder = new StringBuilder();
    stringBuilder.append("Fragment ");
    stringBuilder.append(this);
    stringBuilder.append(" not attached to Activity");
    throw new IllegalStateException(stringBuilder.toString());
  }
  
  public void startIntentSenderForResult(IntentSender paramIntentSender, int paramInt1, Intent paramIntent, int paramInt2, int paramInt3, int paramInt4, Bundle paramBundle) throws IntentSender.SendIntentException {
    f f1 = this.mHost;
    if (f1 != null) {
      f1.r(this, paramIntentSender, paramInt1, paramIntent, paramInt2, paramInt3, paramInt4, paramBundle);
      return;
    } 
    StringBuilder stringBuilder = new StringBuilder();
    stringBuilder.append("Fragment ");
    stringBuilder.append(this);
    stringBuilder.append(" not attached to Activity");
    throw new IllegalStateException(stringBuilder.toString());
  }
  
  public void startPostponedEnterTransition() {
    h h1 = this.mFragmentManager;
    if (h1 == null || h1.n == null) {
      (ensureAnimationInfo()).q = false;
      return;
    } 
    if (Looper.myLooper() != this.mFragmentManager.n.g().getLooper()) {
      this.mFragmentManager.n.g().postAtFrontOfQueue(new a(this));
      return;
    } 
    callStartTransitionListener();
  }
  
  public String toString() {
    StringBuilder stringBuilder = new StringBuilder(128);
    androidx.core.util.b.a(this, stringBuilder);
    if (this.mIndex >= 0) {
      stringBuilder.append(" #");
      stringBuilder.append(this.mIndex);
    } 
    if (this.mFragmentId != 0) {
      stringBuilder.append(" id=0x");
      stringBuilder.append(Integer.toHexString(this.mFragmentId));
    } 
    if (this.mTag != null) {
      stringBuilder.append(" ");
      stringBuilder.append(this.mTag);
    } 
    stringBuilder.append('}');
    return stringBuilder.toString();
  }
  
  public void unregisterForContextMenu(View paramView) {
    paramView.setOnCreateContextMenuListener(null);
  }
  
  public static class SavedState implements Parcelable {
    public static final Parcelable.Creator<SavedState> CREATOR = (Parcelable.Creator<SavedState>)new a();
    
    final Bundle b;
    
    SavedState(Parcel param1Parcel, ClassLoader param1ClassLoader) {
      Bundle bundle = param1Parcel.readBundle();
      this.b = bundle;
      if (param1ClassLoader != null && bundle != null)
        bundle.setClassLoader(param1ClassLoader); 
    }
    
    public int describeContents() {
      return 0;
    }
    
    public void writeToParcel(Parcel param1Parcel, int param1Int) {
      param1Parcel.writeBundle(this.b);
    }
    
    static final class a implements Parcelable.ClassLoaderCreator<SavedState> {
      public Fragment.SavedState a(Parcel param2Parcel) {
        return new Fragment.SavedState(param2Parcel, null);
      }
      
      public Fragment.SavedState b(Parcel param2Parcel, ClassLoader param2ClassLoader) {
        return new Fragment.SavedState(param2Parcel, param2ClassLoader);
      }
      
      public Fragment.SavedState[] c(int param2Int) {
        return new Fragment.SavedState[param2Int];
      }
    }
  }
  
  static final class a implements Parcelable.ClassLoaderCreator<SavedState> {
    public Fragment.SavedState a(Parcel param1Parcel) {
      return new Fragment.SavedState(param1Parcel, null);
    }
    
    public Fragment.SavedState b(Parcel param1Parcel, ClassLoader param1ClassLoader) {
      return new Fragment.SavedState(param1Parcel, param1ClassLoader);
    }
    
    public Fragment.SavedState[] c(int param1Int) {
      return new Fragment.SavedState[param1Int];
    }
  }
  
  class a implements Runnable {
    a(Fragment this$0) {}
    
    public void run() {
      this.b.callStartTransitionListener();
    }
  }
  
  class b extends d {
    b(Fragment this$0) {}
    
    public Fragment a(Context param1Context, String param1String, Bundle param1Bundle) {
      return this.a.mHost.a(param1Context, param1String, param1Bundle);
    }
    
    public View b(int param1Int) {
      View view = this.a.mView;
      if (view != null)
        return view.findViewById(param1Int); 
      throw new IllegalStateException("Fragment does not have a view");
    }
    
    public boolean c() {
      return (this.a.mView != null);
    }
  }
  
  class c implements j {
    c(Fragment this$0) {}
    
    public androidx.lifecycle.f getLifecycle() {
      Fragment fragment = this.b;
      if (fragment.mViewLifecycleRegistry == null)
        fragment.mViewLifecycleRegistry = new k(fragment.mViewLifecycleOwner); 
      return (androidx.lifecycle.f)this.b.mViewLifecycleRegistry;
    }
  }
  
  static class d {
    View a;
    
    Animator b;
    
    int c;
    
    int d;
    
    int e;
    
    int f;
    
    Object g = null;
    
    Object h;
    
    Object i;
    
    Object j;
    
    Object k;
    
    Object l;
    
    Boolean m;
    
    Boolean n;
    
    l o;
    
    l p;
    
    boolean q;
    
    Fragment.f r;
    
    boolean s;
    
    d() {
      Object object = Fragment.USE_DEFAULT_TRANSITION;
      this.h = object;
      this.i = null;
      this.j = object;
      this.k = null;
      this.l = object;
    }
  }
  
  public static class e extends RuntimeException {
    public e(String param1String, Exception param1Exception) {
      super(param1String, param1Exception);
    }
  }
  
  static interface f {
    void a();
    
    void b();
  }
}


/* Location:              C:\soft\dex2jar-2.0\Hill race-dex2jar.jar!\androidx\fragment\app\Fragment.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */