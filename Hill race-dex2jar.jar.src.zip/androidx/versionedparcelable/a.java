package androidx.versionedparcelable;

import android.os.Parcelable;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;

public abstract class a {
  protected final androidx.collection.a<String, Method> a;
  
  protected final androidx.collection.a<String, Method> b;
  
  protected final androidx.collection.a<String, Class> c;
  
  public a(androidx.collection.a<String, Method> parama1, androidx.collection.a<String, Method> parama2, androidx.collection.a<String, Class> parama) {
    this.a = parama1;
    this.b = parama2;
    this.c = parama;
  }
  
  private void N(q.a parama) {
    try {
      Class clazz = c((Class)parama.getClass());
      I(clazz.getName());
      return;
    } catch (ClassNotFoundException classNotFoundException) {
      StringBuilder stringBuilder = new StringBuilder();
      stringBuilder.append(parama.getClass().getSimpleName());
      stringBuilder.append(" does not have a Parcelizer");
      throw new RuntimeException(stringBuilder.toString(), classNotFoundException);
    } 
  }
  
  private Class c(Class<? extends q.a> paramClass) throws ClassNotFoundException {
    Class<?> clazz2 = (Class)this.c.get(paramClass.getName());
    Class<?> clazz1 = clazz2;
    if (clazz2 == null) {
      clazz1 = Class.forName(String.format("%s.%sParcelizer", new Object[] { paramClass.getPackage().getName(), paramClass.getSimpleName() }), false, paramClass.getClassLoader());
      this.c.put(paramClass.getName(), clazz1);
    } 
    return clazz1;
  }
  
  private Method d(String paramString) throws IllegalAccessException, NoSuchMethodException, ClassNotFoundException {
    Method method2 = (Method)this.a.get(paramString);
    Method method1 = method2;
    if (method2 == null) {
      System.currentTimeMillis();
      method1 = Class.forName(paramString, true, a.class.getClassLoader()).getDeclaredMethod("read", new Class[] { a.class });
      this.a.put(paramString, method1);
    } 
    return method1;
  }
  
  private Method e(Class<? extends q.a> paramClass) throws IllegalAccessException, NoSuchMethodException, ClassNotFoundException {
    Method method2 = (Method)this.b.get(paramClass.getName());
    Method method1 = method2;
    if (method2 == null) {
      Class clazz = c(paramClass);
      System.currentTimeMillis();
      method1 = clazz.getDeclaredMethod("write", new Class[] { paramClass, a.class });
      this.b.put(paramClass.getName(), method1);
    } 
    return method1;
  }
  
  protected abstract void A(byte[] paramArrayOfbyte);
  
  public void B(byte[] paramArrayOfbyte, int paramInt) {
    w(paramInt);
    A(paramArrayOfbyte);
  }
  
  protected abstract void C(CharSequence paramCharSequence);
  
  public void D(CharSequence paramCharSequence, int paramInt) {
    w(paramInt);
    C(paramCharSequence);
  }
  
  protected abstract void E(int paramInt);
  
  public void F(int paramInt1, int paramInt2) {
    w(paramInt2);
    E(paramInt1);
  }
  
  protected abstract void G(Parcelable paramParcelable);
  
  public void H(Parcelable paramParcelable, int paramInt) {
    w(paramInt);
    G(paramParcelable);
  }
  
  protected abstract void I(String paramString);
  
  public void J(String paramString, int paramInt) {
    w(paramInt);
    I(paramString);
  }
  
  protected <T extends q.a> void K(T paramT, a parama) {
    try {
      e(paramT.getClass()).invoke(null, new Object[] { paramT, parama });
      return;
    } catch (IllegalAccessException illegalAccessException) {
      throw new RuntimeException("VersionedParcel encountered IllegalAccessException", illegalAccessException);
    } catch (InvocationTargetException invocationTargetException) {
      if (invocationTargetException.getCause() instanceof RuntimeException)
        throw (RuntimeException)invocationTargetException.getCause(); 
      throw new RuntimeException("VersionedParcel encountered InvocationTargetException", invocationTargetException);
    } catch (NoSuchMethodException noSuchMethodException) {
      throw new RuntimeException("VersionedParcel encountered NoSuchMethodException", noSuchMethodException);
    } catch (ClassNotFoundException classNotFoundException) {
      throw new RuntimeException("VersionedParcel encountered ClassNotFoundException", classNotFoundException);
    } 
  }
  
  protected void L(q.a parama) {
    if (parama == null) {
      I(null);
      return;
    } 
    N(parama);
    a a1 = b();
    K(parama, a1);
    a1.a();
  }
  
  public void M(q.a parama, int paramInt) {
    w(paramInt);
    L(parama);
  }
  
  protected abstract void a();
  
  protected abstract a b();
  
  public boolean f() {
    return false;
  }
  
  protected abstract boolean g();
  
  public boolean h(boolean paramBoolean, int paramInt) {
    return !m(paramInt) ? paramBoolean : g();
  }
  
  protected abstract byte[] i();
  
  public byte[] j(byte[] paramArrayOfbyte, int paramInt) {
    return !m(paramInt) ? paramArrayOfbyte : i();
  }
  
  protected abstract CharSequence k();
  
  public CharSequence l(CharSequence paramCharSequence, int paramInt) {
    return !m(paramInt) ? paramCharSequence : k();
  }
  
  protected abstract boolean m(int paramInt);
  
  protected <T extends q.a> T n(String paramString, a parama) {
    try {
      return (T)d(paramString).invoke(null, new Object[] { parama });
    } catch (IllegalAccessException illegalAccessException) {
      throw new RuntimeException("VersionedParcel encountered IllegalAccessException", illegalAccessException);
    } catch (InvocationTargetException invocationTargetException) {
      if (invocationTargetException.getCause() instanceof RuntimeException)
        throw (RuntimeException)invocationTargetException.getCause(); 
      throw new RuntimeException("VersionedParcel encountered InvocationTargetException", invocationTargetException);
    } catch (NoSuchMethodException noSuchMethodException) {
      throw new RuntimeException("VersionedParcel encountered NoSuchMethodException", noSuchMethodException);
    } catch (ClassNotFoundException classNotFoundException) {
      throw new RuntimeException("VersionedParcel encountered ClassNotFoundException", classNotFoundException);
    } 
  }
  
  protected abstract int o();
  
  public int p(int paramInt1, int paramInt2) {
    return !m(paramInt2) ? paramInt1 : o();
  }
  
  protected abstract <T extends Parcelable> T q();
  
  public <T extends Parcelable> T r(T paramT, int paramInt) {
    return !m(paramInt) ? paramT : q();
  }
  
  protected abstract String s();
  
  public String t(String paramString, int paramInt) {
    return !m(paramInt) ? paramString : s();
  }
  
  protected <T extends q.a> T u() {
    String str = s();
    return (str == null) ? null : n(str, b());
  }
  
  public <T extends q.a> T v(T paramT, int paramInt) {
    return !m(paramInt) ? paramT : u();
  }
  
  protected abstract void w(int paramInt);
  
  public void x(boolean paramBoolean1, boolean paramBoolean2) {}
  
  protected abstract void y(boolean paramBoolean);
  
  public void z(boolean paramBoolean, int paramInt) {
    w(paramInt);
    y(paramBoolean);
  }
}


/* Location:              C:\soft\dex2jar-2.0\Hill race-dex2jar.jar!\androidx\versionedparcelable\a.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */