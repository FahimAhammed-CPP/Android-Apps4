package androidx.concurrent.futures;

import java.util.concurrent.Executor;

public enum c implements Executor {
  b;
  
  static {
    c c1 = new c("INSTANCE", 0);
    b = c1;
    c = new c[] { c1 };
  }
  
  public void execute(Runnable paramRunnable) {
    paramRunnable.run();
  }
  
  public String toString() {
    return "DirectExecutor";
  }
}


/* Location:              C:\soft\dex2jar-2.0\Hill race-dex2jar.jar!\androidx\concurrent\futures\c.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */