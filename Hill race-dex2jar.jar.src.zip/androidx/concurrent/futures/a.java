package androidx.concurrent.futures;

import com.google.common.util.concurrent.ListenableFuture;
import java.util.Locale;
import java.util.Objects;
import java.util.concurrent.CancellationException;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.Executor;
import java.util.concurrent.Future;
import java.util.concurrent.ScheduledFuture;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.TimeoutException;
import java.util.concurrent.atomic.AtomicReferenceFieldUpdater;
import java.util.concurrent.locks.LockSupport;
import java.util.logging.Level;
import java.util.logging.Logger;

public abstract class a<V> implements ListenableFuture<V> {
  static {
    try {
      f f = new f(AtomicReferenceFieldUpdater.newUpdater(i.class, Thread.class, "a"), AtomicReferenceFieldUpdater.newUpdater(i.class, i.class, "b"), AtomicReferenceFieldUpdater.newUpdater(a.class, i.class, "waiters"), AtomicReferenceFieldUpdater.newUpdater(a.class, e.class, "listeners"), AtomicReferenceFieldUpdater.newUpdater(a.class, Object.class, "value"));
    } finally {
      exception = null;
    } 
    ATOMIC_HELPER = h;
    if (exception != null)
      log.log(Level.SEVERE, "SafeAtomicHelper is broken!", exception); 
    NULL = new Object();
  }
  
  private void addDoneString(StringBuilder paramStringBuilder) {
    try {
      Object object = getUninterruptibly((Future<Object>)this);
      paramStringBuilder.append("SUCCESS, result=[");
      paramStringBuilder.append(userObjectToString(object));
      paramStringBuilder.append("]");
      return;
    } catch (ExecutionException executionException) {
      paramStringBuilder.append("FAILURE, cause=[");
      paramStringBuilder.append(executionException.getCause());
      paramStringBuilder.append("]");
      return;
    } catch (CancellationException cancellationException) {
      paramStringBuilder.append("CANCELLED");
      return;
    } catch (RuntimeException runtimeException) {
      paramStringBuilder.append("UNKNOWN, cause=[");
      paramStringBuilder.append(runtimeException.getClass());
      paramStringBuilder.append(" thrown from get()]");
      return;
    } 
  }
  
  private static CancellationException cancellationExceptionWithCause(String paramString, Throwable paramThrowable) {
    CancellationException cancellationException = new CancellationException(paramString);
    cancellationException.initCause(paramThrowable);
    return cancellationException;
  }
  
  static <T> T checkNotNull(T paramT) {
    Objects.requireNonNull(paramT);
    return paramT;
  }
  
  private e clearListeners(e parame) {
    while (true) {
      e e1 = this.listeners;
      if (ATOMIC_HELPER.a(this, e1, e.d)) {
        e e2 = parame;
        for (parame = e1; parame != null; parame = e1) {
          e1 = parame.c;
          parame.c = e2;
          e2 = parame;
        } 
        return e2;
      } 
    } 
  }
  
  static void complete(a<?> parama) {
    a a2 = null;
    a<?> a1 = parama;
    parama = a2;
    label17: while (true) {
      a1.releaseWaiters();
      a1.afterDone();
      e e1 = a1.clearListeners((e)parama);
      while (e1 != null) {
        a<V> a3;
        e e2 = e1.c;
        Runnable runnable = e1.a;
        if (runnable instanceof g) {
          runnable = runnable;
          a3 = ((g)runnable).b;
          if (a3.value == runnable) {
            Object object = getFutureValue(((g)runnable).c);
            if (ATOMIC_HELPER.b(a3, runnable, object))
              continue label17; 
          } 
        } else {
          executeListener(runnable, ((e)a3).b);
        } 
        e e3 = e2;
      } 
      break;
    } 
  }
  
  private static void executeListener(Runnable paramRunnable, Executor paramExecutor) {
    try {
      paramExecutor.execute(paramRunnable);
      return;
    } catch (RuntimeException runtimeException) {
      Logger logger = log;
      Level level = Level.SEVERE;
      StringBuilder stringBuilder = new StringBuilder();
      stringBuilder.append("RuntimeException while executing runnable ");
      stringBuilder.append(paramRunnable);
      stringBuilder.append(" with executor ");
      stringBuilder.append(paramExecutor);
      logger.log(level, stringBuilder.toString(), runtimeException);
      return;
    } 
  }
  
  private V getDoneValue(Object paramObject) throws ExecutionException {
    if (!(paramObject instanceof c)) {
      if (!(paramObject instanceof d)) {
        Object object = paramObject;
        if (paramObject == NULL)
          object = null; 
        return (V)object;
      } 
      throw new ExecutionException(((d)paramObject).a);
    } 
    throw cancellationExceptionWithCause("Task was cancelled.", ((c)paramObject).b);
  }
  
  static Object getFutureValue(ListenableFuture<?> paramListenableFuture) {
    if (paramListenableFuture instanceof a) {
      Object object1 = ((a)paramListenableFuture).value;
      object = object1;
      if (object1 instanceof c) {
        c c = (c)object1;
        object = object1;
        if (c.a) {
          if (c.b != null)
            return new c(false, c.b); 
          object = c.d;
        } 
      } 
      return object;
    } 
    boolean bool = object.isCancelled();
    if (((GENERATE_CANCELLATION_CAUSES ^ true) & bool) != 0)
      return c.d; 
    try {
      Object object2 = getUninterruptibly((Future<Object>)object);
      Object object1 = object2;
      return object1;
    } catch (ExecutionException object) {
      return new d(object.getCause());
    } catch (CancellationException cancellationException) {
      return new c(false, cancellationException);
    } finally {
      object = null;
    } 
  }
  
  static <V> V getUninterruptibly(Future<V> paramFuture) throws ExecutionException {
    boolean bool = false;
    while (true) {
      try {
        return paramFuture.get();
      } catch (InterruptedException interruptedException) {
      
      } finally {
        if (bool)
          Thread.currentThread().interrupt(); 
      } 
    } 
  }
  
  private void releaseWaiters() {
    i i1;
    do {
      i1 = this.waiters;
    } while (!ATOMIC_HELPER.c(this, i1, i.c));
    while (i1 != null) {
      i1.b();
      i1 = i1.b;
    } 
  }
  
  private void removeWaiter(i parami) {
    parami.a = null;
    label24: while (true) {
      parami = this.waiters;
      if (parami == i.c)
        return; 
      for (Object object = null; parami != null; object = object1) {
        Object object1;
        i i1 = parami.b;
        if (parami.a != null) {
          object1 = parami;
        } else if (object != null) {
          ((i)object).b = i1;
          object1 = object;
          if (((i)object).a == null)
            continue label24; 
        } else {
          object1 = object;
          if (!ATOMIC_HELPER.c(this, parami, i1))
            continue label24; 
        } 
        parami = i1;
      } 
      break;
    } 
  }
  
  private String userObjectToString(Object paramObject) {
    return (paramObject == this) ? "this future" : String.valueOf(paramObject);
  }
  
  public final void addListener(Runnable paramRunnable, Executor paramExecutor) {
    checkNotNull(paramRunnable);
    checkNotNull(paramExecutor);
    e e1 = this.listeners;
    if (e1 != e.d) {
      e e2;
      e e3 = new e(paramRunnable, paramExecutor);
      do {
        e3.c = e1;
        if (ATOMIC_HELPER.a(this, e1, e3))
          return; 
        e2 = this.listeners;
        e1 = e2;
      } while (e2 != e.d);
    } 
    executeListener(paramRunnable, paramExecutor);
  }
  
  protected void afterDone() {}
  
  public final boolean cancel(boolean paramBoolean) {
    boolean bool;
    boolean bool1;
    Object object = this.value;
    boolean bool2 = true;
    if (object == null) {
      bool = true;
    } else {
      bool = false;
    } 
    if (bool | object instanceof g) {
      c c;
      if (GENERATE_CANCELLATION_CAUSES) {
        c = new c(paramBoolean, new CancellationException("Future.cancel() was called."));
      } else if (paramBoolean) {
        c = c.c;
      } else {
        c = c.d;
      } 
      bool1 = false;
      a<?> a1 = this;
      while (true) {
        while (ATOMIC_HELPER.b(a1, object, c)) {
          if (paramBoolean)
            a1.interruptTask(); 
          complete(a1);
          bool1 = bool2;
          if (object instanceof g) {
            object = ((g)object).c;
            if (object instanceof a) {
              a1 = (a)object;
              object = a1.value;
              if (object == null) {
                bool = true;
              } else {
                bool = false;
              } 
              bool1 = bool2;
              if (bool | object instanceof g) {
                bool1 = true;
                continue;
              } 
            } else {
              object.cancel(paramBoolean);
              return true;
            } 
          } 
          return bool1;
        } 
        Object object1 = a1.value;
        object = object1;
        if (!(object1 instanceof g))
          return bool1; 
      } 
    } else {
      bool1 = false;
    } 
    return bool1;
  }
  
  public final V get() throws InterruptedException, ExecutionException {
    if (!Thread.interrupted()) {
      boolean bool;
      Object object = this.value;
      if (object != null) {
        bool = true;
      } else {
        bool = false;
      } 
      if ((bool & (object instanceof g ^ true)) != 0)
        return getDoneValue(object); 
      object = this.waiters;
      if (object != i.c) {
        i i1;
        i i2 = new i();
        do {
          i2.a((i)object);
          if (ATOMIC_HELPER.c(this, (i)object, i2))
            while (true) {
              LockSupport.park(this);
              if (!Thread.interrupted()) {
                object = this.value;
                if (object != null) {
                  bool = true;
                } else {
                  bool = false;
                } 
                if ((bool & (object instanceof g ^ true)) != 0)
                  return getDoneValue(object); 
                continue;
              } 
              removeWaiter(i2);
              throw new InterruptedException();
            }  
          i1 = this.waiters;
          object = i1;
        } while (i1 != i.c);
      } 
      return getDoneValue(this.value);
    } 
    throw new InterruptedException();
  }
  
  public final V get(long paramLong, TimeUnit paramTimeUnit) throws InterruptedException, TimeoutException, ExecutionException {
    long l = paramTimeUnit.toNanos(paramLong);
    if (!Thread.interrupted()) {
      boolean bool;
      long l2;
      Object object = this.value;
      if (object != null) {
        bool = true;
      } else {
        bool = false;
      } 
      if ((bool & (object instanceof g ^ true)) != 0)
        return getDoneValue(object); 
      if (l > 0L) {
        l2 = System.nanoTime() + l;
      } else {
        l2 = 0L;
      } 
      long l1 = l;
      if (l >= 1000L) {
        object = this.waiters;
        if (object != i.c) {
          i i1 = new i();
          label75: while (true) {
            i1.a((i)object);
            if (ATOMIC_HELPER.c(this, (i)object, i1))
              while (true) {
                LockSupport.parkNanos(this, l);
                if (!Thread.interrupted()) {
                  object = this.value;
                  if (object != null) {
                    bool = true;
                  } else {
                    bool = false;
                  } 
                  if ((bool & (object instanceof g ^ true)) != 0)
                    return getDoneValue(object); 
                  l1 = l2 - System.nanoTime();
                  l = l1;
                  if (l1 < 1000L) {
                    removeWaiter(i1);
                    break;
                  } 
                  continue;
                } 
                removeWaiter(i1);
                throw new InterruptedException();
              }  
            i i2 = this.waiters;
            object = i2;
            if (i2 == i.c)
              break label75; 
          } 
        } else {
          return getDoneValue(this.value);
        } 
      } 
      while (l1 > 0L) {
        object = this.value;
        if (object != null) {
          bool = true;
        } else {
          bool = false;
        } 
        if ((bool & (object instanceof g ^ true)) != 0)
          return getDoneValue(object); 
        if (!Thread.interrupted()) {
          l1 = l2 - System.nanoTime();
          continue;
        } 
        throw new InterruptedException();
      } 
      String str3 = toString();
      String str2 = paramTimeUnit.toString();
      object = Locale.ROOT;
      String str4 = str2.toLowerCase((Locale)object);
      StringBuilder stringBuilder2 = new StringBuilder();
      stringBuilder2.append("Waited ");
      stringBuilder2.append(paramLong);
      stringBuilder2.append(" ");
      stringBuilder2.append(paramTimeUnit.toString().toLowerCase((Locale)object));
      String str1 = stringBuilder2.toString();
      object = str1;
      if (l1 + 1000L < 0L) {
        object = new StringBuilder();
        object.append(str1);
        object.append(" (plus ");
        object = object.toString();
        l1 = -l1;
        paramLong = paramTimeUnit.convert(l1, TimeUnit.NANOSECONDS);
        l1 -= paramTimeUnit.toNanos(paramLong);
        int j = paramLong cmp 0L;
        if (j == 0 || l1 > 1000L) {
          bool = true;
        } else {
          bool = false;
        } 
        Object object1 = object;
        if (j > 0) {
          object1 = new StringBuilder();
          object1.append((String)object);
          object1.append(paramLong);
          object1.append(" ");
          object1.append(str4);
          object = object1.toString();
          object1 = object;
          if (bool) {
            object1 = new StringBuilder();
            object1.append((String)object);
            object1.append(",");
            object1 = object1.toString();
          } 
          object = new StringBuilder();
          object.append((String)object1);
          object.append(" ");
          object1 = object.toString();
        } 
        object = object1;
        if (bool) {
          object = new StringBuilder();
          object.append((String)object1);
          object.append(l1);
          object.append(" nanoseconds ");
          object = object.toString();
        } 
        object1 = new StringBuilder();
        object1.append((String)object);
        object1.append("delay)");
        object = object1.toString();
      } 
      if (isDone()) {
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append((String)object);
        stringBuilder.append(" but future completed as timeout expired");
        throw new TimeoutException(stringBuilder.toString());
      } 
      StringBuilder stringBuilder1 = new StringBuilder();
      stringBuilder1.append((String)object);
      stringBuilder1.append(" for ");
      stringBuilder1.append(str3);
      throw new TimeoutException(stringBuilder1.toString());
    } 
    throw new InterruptedException();
  }
  
  protected void interruptTask() {}
  
  public final boolean isCancelled() {
    return this.value instanceof c;
  }
  
  public final boolean isDone() {
    boolean bool;
    Object object = this.value;
    if (object != null) {
      bool = true;
    } else {
      bool = false;
    } 
    return (object instanceof g ^ true) & bool;
  }
  
  final void maybePropagateCancellationTo(Future<?> paramFuture) {
    boolean bool;
    if (paramFuture != null) {
      bool = true;
    } else {
      bool = false;
    } 
    if (bool & isCancelled())
      paramFuture.cancel(wasInterrupted()); 
  }
  
  protected String pendingToString() {
    Object object = this.value;
    if (object instanceof g) {
      StringBuilder stringBuilder = new StringBuilder();
      stringBuilder.append("setFuture=[");
      stringBuilder.append(userObjectToString(((g)object).c));
      stringBuilder.append("]");
      return stringBuilder.toString();
    } 
    if (this instanceof ScheduledFuture) {
      object = new StringBuilder();
      object.append("remaining delay=[");
      object.append(((ScheduledFuture)this).getDelay(TimeUnit.MILLISECONDS));
      object.append(" ms]");
      return object.toString();
    } 
    return null;
  }
  
  protected boolean set(V paramV) {
    V v = paramV;
    if (paramV == null)
      v = (V)NULL; 
    if (ATOMIC_HELPER.b(this, null, v)) {
      complete(this);
      return true;
    } 
    return false;
  }
  
  protected boolean setException(Throwable paramThrowable) {
    d d = new d(checkNotNull(paramThrowable));
    if (ATOMIC_HELPER.b(this, null, d)) {
      complete(this);
      return true;
    } 
    return false;
  }
  
  protected boolean setFuture(ListenableFuture<? extends V> paramListenableFuture) {
    Object object1;
    checkNotNull(paramListenableFuture);
    Object object3 = this.value;
    Object object2 = object3;
    if (object3 == null) {
      if (paramListenableFuture.isDone()) {
        object1 = getFutureValue(paramListenableFuture);
        if (ATOMIC_HELPER.b(this, null, object1)) {
          complete(this);
          return true;
        } 
        return false;
      } 
      object2 = new g(this, (ListenableFuture<?>)object1);
      if (ATOMIC_HELPER.b(this, null, object2))
        try {
          return true;
        } finally {
          object1 = null;
          try {
            object1 = new d((Throwable)object1);
          } finally {
            object1 = null;
          } 
        }  
      object2 = this.value;
    } 
    if (object2 instanceof c)
      object1.cancel(((c)object2).a); 
    return false;
  }
  
  public String toString() {
    StringBuilder stringBuilder = new StringBuilder();
    stringBuilder.append(super.toString());
    stringBuilder.append("[status=");
    if (isCancelled()) {
      stringBuilder.append("CANCELLED");
    } else if (isDone()) {
      addDoneString(stringBuilder);
    } else {
      String str;
      try {
        str = pendingToString();
      } catch (RuntimeException runtimeException) {
        StringBuilder stringBuilder1 = new StringBuilder();
        stringBuilder1.append("Exception thrown from implementation: ");
        stringBuilder1.append(runtimeException.getClass());
        str = stringBuilder1.toString();
      } 
      if (str != null && !str.isEmpty()) {
        stringBuilder.append("PENDING, info=[");
        stringBuilder.append(str);
        stringBuilder.append("]");
      } else if (isDone()) {
        addDoneString(stringBuilder);
      } else {
        stringBuilder.append("PENDING");
      } 
    } 
    stringBuilder.append("]");
    return stringBuilder.toString();
  }
  
  protected final boolean wasInterrupted() {
    Object object = this.value;
    return (object instanceof c && ((c)object).a);
  }
  
  static {
    Exception exception;
    h h;
  }
  
  static final b ATOMIC_HELPER;
  
  static final boolean GENERATE_CANCELLATION_CAUSES = Boolean.parseBoolean(System.getProperty("guava.concurrent.generate_cancellation_cause", "false"));
  
  private static final Object NULL;
  
  private static final long SPIN_THRESHOLD_NANOS = 1000L;
  
  private static final Logger log = Logger.getLogger(a.class.getName());
  
  volatile e listeners;
  
  volatile Object value;
  
  volatile i waiters;
  
  private static abstract class b {
    private b() {}
    
    abstract boolean a(a<?> param1a, a.e param1e1, a.e param1e2);
    
    abstract boolean b(a<?> param1a, Object param1Object1, Object param1Object2);
    
    abstract boolean c(a<?> param1a, a.i param1i1, a.i param1i2);
    
    abstract void d(a.i param1i1, a.i param1i2);
    
    abstract void e(a.i param1i, Thread param1Thread);
  }
  
  private static final class c {
    static final c c = new c(true, null);
    
    static final c d = new c(false, null);
    
    final boolean a;
    
    final Throwable b;
    
    static {
    
    }
    
    c(boolean param1Boolean, Throwable param1Throwable) {
      this.a = param1Boolean;
      this.b = param1Throwable;
    }
    
    static {
      if (a.GENERATE_CANCELLATION_CAUSES) {
        d = null;
        c = null;
        return;
      } 
    }
  }
  
  private static final class d {
    static final d b = new d(new a("Failure occurred while trying to finish a future."));
    
    final Throwable a;
    
    d(Throwable param1Throwable) {
      this.a = a.<Throwable>checkNotNull(param1Throwable);
    }
    
    class a extends Throwable {
      a(a.d this$0) {
        super((String)this$0);
      }
      
      public Throwable fillInStackTrace() {
        /* monitor enter ThisExpression{InnerObjectType{InnerObjectType{ObjectType{androidx/concurrent/futures/a}.Landroidx/concurrent/futures/a$d;}.Landroidx/concurrent/futures/a$d$a;}} */
        /* monitor exit ThisExpression{InnerObjectType{InnerObjectType{ObjectType{androidx/concurrent/futures/a}.Landroidx/concurrent/futures/a$d;}.Landroidx/concurrent/futures/a$d$a;}} */
        return this;
      }
    }
  }
  
  class a extends Throwable {
    a(a this$0) {
      super((String)this$0);
    }
    
    public Throwable fillInStackTrace() {
      /* monitor enter ThisExpression{InnerObjectType{InnerObjectType{ObjectType{androidx/concurrent/futures/a}.Landroidx/concurrent/futures/a$d;}.Landroidx/concurrent/futures/a$d$a;}} */
      /* monitor exit ThisExpression{InnerObjectType{InnerObjectType{ObjectType{androidx/concurrent/futures/a}.Landroidx/concurrent/futures/a$d;}.Landroidx/concurrent/futures/a$d$a;}} */
      return this;
    }
  }
  
  private static final class e {
    static final e d = new e(null, null);
    
    final Runnable a;
    
    final Executor b;
    
    e c;
    
    e(Runnable param1Runnable, Executor param1Executor) {
      this.a = param1Runnable;
      this.b = param1Executor;
    }
  }
  
  private static final class f extends b {
    final AtomicReferenceFieldUpdater<a.i, Thread> a;
    
    final AtomicReferenceFieldUpdater<a.i, a.i> b;
    
    final AtomicReferenceFieldUpdater<a, a.i> c;
    
    final AtomicReferenceFieldUpdater<a, a.e> d;
    
    final AtomicReferenceFieldUpdater<a, Object> e;
    
    f(AtomicReferenceFieldUpdater<a.i, Thread> param1AtomicReferenceFieldUpdater, AtomicReferenceFieldUpdater<a.i, a.i> param1AtomicReferenceFieldUpdater1, AtomicReferenceFieldUpdater<a, a.i> param1AtomicReferenceFieldUpdater2, AtomicReferenceFieldUpdater<a, a.e> param1AtomicReferenceFieldUpdater3, AtomicReferenceFieldUpdater<a, Object> param1AtomicReferenceFieldUpdater4) {
      super(null);
      this.a = param1AtomicReferenceFieldUpdater;
      this.b = param1AtomicReferenceFieldUpdater1;
      this.c = param1AtomicReferenceFieldUpdater2;
      this.d = param1AtomicReferenceFieldUpdater3;
      this.e = param1AtomicReferenceFieldUpdater4;
    }
    
    boolean a(a<?> param1a, a.e param1e1, a.e param1e2) {
      return b.a(this.d, param1a, param1e1, param1e2);
    }
    
    boolean b(a<?> param1a, Object param1Object1, Object param1Object2) {
      return b.a(this.e, param1a, param1Object1, param1Object2);
    }
    
    boolean c(a<?> param1a, a.i param1i1, a.i param1i2) {
      return b.a(this.c, param1a, param1i1, param1i2);
    }
    
    void d(a.i param1i1, a.i param1i2) {
      this.b.lazySet(param1i1, param1i2);
    }
    
    void e(a.i param1i, Thread param1Thread) {
      this.a.lazySet(param1i, param1Thread);
    }
  }
  
  private static final class g<V> implements Runnable {
    final a<V> b;
    
    final ListenableFuture<? extends V> c;
    
    g(a<V> param1a, ListenableFuture<? extends V> param1ListenableFuture) {
      this.b = param1a;
      this.c = param1ListenableFuture;
    }
    
    public void run() {
      if (this.b.value != this)
        return; 
      Object object = a.getFutureValue(this.c);
      if (a.ATOMIC_HELPER.b(this.b, this, object))
        a.complete(this.b); 
    }
  }
  
  private static final class h extends b {
    h() {
      super(null);
    }
    
    boolean a(a<?> param1a, a.e param1e1, a.e param1e2) {
      // Byte code:
      //   0: aload_1
      //   1: monitorenter
      //   2: aload_1
      //   3: getfield listeners : Landroidx/concurrent/futures/a$e;
      //   6: aload_2
      //   7: if_acmpne -> 19
      //   10: aload_1
      //   11: aload_3
      //   12: putfield listeners : Landroidx/concurrent/futures/a$e;
      //   15: aload_1
      //   16: monitorexit
      //   17: iconst_1
      //   18: ireturn
      //   19: aload_1
      //   20: monitorexit
      //   21: iconst_0
      //   22: ireturn
      //   23: astore_2
      //   24: aload_1
      //   25: monitorexit
      //   26: aload_2
      //   27: athrow
      // Exception table:
      //   from	to	target	type
      //   2	17	23	finally
      //   19	21	23	finally
      //   24	26	23	finally
    }
    
    boolean b(a<?> param1a, Object param1Object1, Object param1Object2) {
      // Byte code:
      //   0: aload_1
      //   1: monitorenter
      //   2: aload_1
      //   3: getfield value : Ljava/lang/Object;
      //   6: aload_2
      //   7: if_acmpne -> 19
      //   10: aload_1
      //   11: aload_3
      //   12: putfield value : Ljava/lang/Object;
      //   15: aload_1
      //   16: monitorexit
      //   17: iconst_1
      //   18: ireturn
      //   19: aload_1
      //   20: monitorexit
      //   21: iconst_0
      //   22: ireturn
      //   23: astore_2
      //   24: aload_1
      //   25: monitorexit
      //   26: aload_2
      //   27: athrow
      // Exception table:
      //   from	to	target	type
      //   2	17	23	finally
      //   19	21	23	finally
      //   24	26	23	finally
    }
    
    boolean c(a<?> param1a, a.i param1i1, a.i param1i2) {
      // Byte code:
      //   0: aload_1
      //   1: monitorenter
      //   2: aload_1
      //   3: getfield waiters : Landroidx/concurrent/futures/a$i;
      //   6: aload_2
      //   7: if_acmpne -> 19
      //   10: aload_1
      //   11: aload_3
      //   12: putfield waiters : Landroidx/concurrent/futures/a$i;
      //   15: aload_1
      //   16: monitorexit
      //   17: iconst_1
      //   18: ireturn
      //   19: aload_1
      //   20: monitorexit
      //   21: iconst_0
      //   22: ireturn
      //   23: astore_2
      //   24: aload_1
      //   25: monitorexit
      //   26: aload_2
      //   27: athrow
      // Exception table:
      //   from	to	target	type
      //   2	17	23	finally
      //   19	21	23	finally
      //   24	26	23	finally
    }
    
    void d(a.i param1i1, a.i param1i2) {
      param1i1.b = param1i2;
    }
    
    void e(a.i param1i, Thread param1Thread) {
      param1i.a = param1Thread;
    }
  }
  
  private static final class i {
    static final i c = new i(false);
    
    volatile Thread a;
    
    volatile i b;
    
    i() {
      a.ATOMIC_HELPER.e(this, Thread.currentThread());
    }
    
    i(boolean param1Boolean) {}
    
    void a(i param1i) {
      a.ATOMIC_HELPER.d(this, param1i);
    }
    
    void b() {
      Thread thread = this.a;
      if (thread != null) {
        this.a = null;
        LockSupport.unpark(thread);
      } 
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Hill race-dex2jar.jar!\androidx\concurrent\futures\a.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */