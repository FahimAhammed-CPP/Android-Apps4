package androidx.lifecycle;

import android.os.Handler;

public class u {
  private final k a;
  
  private final Handler b;
  
  private a c;
  
  public u(j paramj) {
    this.a = new k(paramj);
    this.b = new Handler();
  }
  
  private void f(f.b paramb) {
    a a2 = this.c;
    if (a2 != null)
      a2.run(); 
    a a1 = new a(this.a, paramb);
    this.c = a1;
    this.b.postAtFrontOfQueue(a1);
  }
  
  public f a() {
    return this.a;
  }
  
  public void b() {
    f(f.b.ON_START);
  }
  
  public void c() {
    f(f.b.ON_CREATE);
  }
  
  public void d() {
    f(f.b.ON_STOP);
    f(f.b.ON_DESTROY);
  }
  
  public void e() {
    f(f.b.ON_START);
  }
  
  static class a implements Runnable {
    private final k b;
    
    final f.b c;
    
    private boolean d = false;
    
    a(k param1k, f.b param1b) {
      this.b = param1k;
      this.c = param1b;
    }
    
    public void run() {
      if (!this.d) {
        this.b.h(this.c);
        this.d = true;
      } 
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Hill race-dex2jar.jar!\androidx\lifecycl\\u.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */