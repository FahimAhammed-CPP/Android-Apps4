package androidx.lifecycle;

import android.annotation.SuppressLint;
import c.b;
import java.lang.ref.WeakReference;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.Map;

public class k extends f {
  private c.a<i, a> b = new c.a();
  
  private f.c c;
  
  private final WeakReference<j> d;
  
  private int e = 0;
  
  private boolean f = false;
  
  private boolean g = false;
  
  private ArrayList<f.c> h = new ArrayList<f.c>();
  
  private final boolean i;
  
  public k(j paramj) {
    this(paramj, true);
  }
  
  private k(j paramj, boolean paramBoolean) {
    this.d = new WeakReference<j>(paramj);
    this.c = f.c.c;
    this.i = paramBoolean;
  }
  
  private void d(j paramj) {
    Iterator<Map.Entry> iterator = this.b.descendingIterator();
    while (iterator.hasNext() && !this.g) {
      Map.Entry entry = iterator.next();
      a a1 = (a)entry.getValue();
      while (a1.a.compareTo(this.c) > 0 && !this.g && this.b.contains(entry.getKey())) {
        f.b b = f.b.a(a1.a);
        if (b != null) {
          n(b.b());
          a1.a(paramj, b);
          m();
          continue;
        } 
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("no event down from ");
        stringBuilder.append(a1.a);
        throw new IllegalStateException(stringBuilder.toString());
      } 
    } 
  }
  
  private f.c e(i parami) {
    f.c c1;
    Map.Entry entry = this.b.k(parami);
    ArrayList<f.c> arrayList = null;
    if (entry != null) {
      f.c c2 = ((a)entry.getValue()).a;
    } else {
      entry = null;
    } 
    if (!this.h.isEmpty()) {
      arrayList = this.h;
      c1 = arrayList.get(arrayList.size() - 1);
    } 
    return k(k(this.c, (f.c)entry), c1);
  }
  
  @SuppressLint({"RestrictedApi"})
  private void f(String paramString) {
    if (this.i) {
      if (b.a.e().b())
        return; 
      StringBuilder stringBuilder = new StringBuilder();
      stringBuilder.append("Method ");
      stringBuilder.append(paramString);
      stringBuilder.append(" must be called on the main thread");
      throw new IllegalStateException(stringBuilder.toString());
    } 
  }
  
  private void g(j paramj) {
    b.d<Map.Entry> d = this.b.f();
    while (d.hasNext() && !this.g) {
      Map.Entry entry = d.next();
      a a1 = (a)entry.getValue();
      while (a1.a.compareTo(this.c) < 0 && !this.g && this.b.contains(entry.getKey())) {
        n(a1.a);
        f.b b = f.b.c(a1.a);
        if (b != null) {
          a1.a(paramj, b);
          m();
          continue;
        } 
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("no event up from ");
        stringBuilder.append(a1.a);
        throw new IllegalStateException(stringBuilder.toString());
      } 
    } 
  }
  
  private boolean i() {
    if (this.b.size() == 0)
      return true; 
    f.c c1 = ((a)this.b.d().getValue()).a;
    f.c c2 = ((a)this.b.g().getValue()).a;
    return (c1 == c2 && this.c == c2);
  }
  
  static f.c k(f.c paramc1, f.c paramc2) {
    f.c c1 = paramc1;
    if (paramc2 != null) {
      c1 = paramc1;
      if (paramc2.compareTo(paramc1) < 0)
        c1 = paramc2; 
    } 
    return c1;
  }
  
  private void l(f.c paramc) {
    f.c c1 = this.c;
    if (c1 == paramc)
      return; 
    if (c1 != f.c.c || paramc != f.c.b) {
      this.c = paramc;
      if (this.f || this.e != 0) {
        this.g = true;
        return;
      } 
      this.f = true;
      p();
      this.f = false;
      if (this.c == f.c.b)
        this.b = new c.a(); 
      return;
    } 
    StringBuilder stringBuilder = new StringBuilder();
    stringBuilder.append("no event down from ");
    stringBuilder.append(this.c);
    throw new IllegalStateException(stringBuilder.toString());
  }
  
  private void m() {
    ArrayList<f.c> arrayList = this.h;
    arrayList.remove(arrayList.size() - 1);
  }
  
  private void n(f.c paramc) {
    this.h.add(paramc);
  }
  
  private void p() {
    j j = this.d.get();
    if (j != null) {
      while (!i()) {
        this.g = false;
        if (this.c.compareTo(((a)this.b.d().getValue()).a) < 0)
          d(j); 
        Map.Entry entry = this.b.g();
        if (!this.g && entry != null && this.c.compareTo(((a)entry.getValue()).a) > 0)
          g(j); 
      } 
      this.g = false;
      return;
    } 
    throw new IllegalStateException("LifecycleOwner of this LifecycleRegistry is alreadygarbage collected. It is too late to change lifecycle state.");
  }
  
  public void a(i parami) {
    boolean bool;
    f("addObserver");
    f.c c2 = this.c;
    f.c c1 = f.c.b;
    if (c2 != c1)
      c1 = f.c.c; 
    a a1 = new a(parami, c1);
    if ((a)this.b.i(parami, a1) != null)
      return; 
    j j = this.d.get();
    if (j == null)
      return; 
    if (this.e != 0 || this.f) {
      bool = true;
    } else {
      bool = false;
    } 
    c1 = e(parami);
    this.e++;
    while (a1.a.compareTo(c1) < 0 && this.b.contains(parami)) {
      n(a1.a);
      f.b b = f.b.c(a1.a);
      if (b != null) {
        a1.a(j, b);
        m();
        f.c c3 = e(parami);
        continue;
      } 
      StringBuilder stringBuilder = new StringBuilder();
      stringBuilder.append("no event up from ");
      stringBuilder.append(a1.a);
      throw new IllegalStateException(stringBuilder.toString());
    } 
    if (!bool)
      p(); 
    this.e--;
  }
  
  public f.c b() {
    return this.c;
  }
  
  public void c(i parami) {
    f("removeObserver");
    this.b.j(parami);
  }
  
  public void h(f.b paramb) {
    f("handleLifecycleEvent");
    l(paramb.b());
  }
  
  @Deprecated
  public void j(f.c paramc) {
    f("markState");
    o(paramc);
  }
  
  public void o(f.c paramc) {
    f("setCurrentState");
    l(paramc);
  }
  
  static class a {
    f.c a;
    
    h b;
    
    a(i param1i, f.c param1c) {
      this.b = n.f(param1i);
      this.a = param1c;
    }
    
    void a(j param1j, f.b param1b) {
      f.c c1 = param1b.b();
      this.a = k.k(this.a, c1);
      this.b.onStateChanged(param1j, param1b);
      this.a = c1;
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Hill race-dex2jar.jar!\androidx\lifecycle\k.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */