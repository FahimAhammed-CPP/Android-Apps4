package androidx.lifecycle;

class CompositeGeneratedAdaptersObserver implements h {
  private final e[] b;
  
  CompositeGeneratedAdaptersObserver(e[] paramArrayOfe) {
    this.b = paramArrayOfe;
  }
  
  public void onStateChanged(j paramj, f.b paramb) {
    o o = new o();
    e[] arrayOfE = this.b;
    int k = arrayOfE.length;
    boolean bool = false;
    int i;
    for (i = 0; i < k; i++)
      arrayOfE[i].a(paramj, paramb, false, o); 
    arrayOfE = this.b;
    k = arrayOfE.length;
    for (i = bool; i < k; i++)
      arrayOfE[i].a(paramj, paramb, true, o); 
  }
}


/* Location:              C:\soft\dex2jar-2.0\Hill race-dex2jar.jar!\androidx\lifecycle\CompositeGeneratedAdaptersObserver.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */