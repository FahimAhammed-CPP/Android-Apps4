package androidx.lifecycle;

public interface h extends i {
  void onStateChanged(j paramj, f.b paramb);
}


/* Location:              C:\soft\dex2jar-2.0\Hill race-dex2jar.jar!\androidx\lifecycle\h.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */