package androidx.lifecycle;

import java.util.Map;

public abstract class LiveData<T> {
  static final Object j = new Object();
  
  final Object a = new Object();
  
  private c.b<q<? super T>, b> b = new c.b();
  
  int c = 0;
  
  private volatile Object d;
  
  volatile Object e;
  
  private int f;
  
  private boolean g;
  
  private boolean h;
  
  private final Runnable i;
  
  public LiveData() {
    Object object = j;
    this.e = object;
    this.i = new a(this);
    this.d = object;
    this.f = -1;
  }
  
  static void a(String paramString) {
    if (b.a.e().b())
      return; 
    StringBuilder stringBuilder = new StringBuilder();
    stringBuilder.append("Cannot invoke ");
    stringBuilder.append(paramString);
    stringBuilder.append(" on a background thread");
    throw new IllegalStateException(stringBuilder.toString());
  }
  
  private void b(b paramb) {
    if (!paramb.c)
      return; 
    if (!paramb.c()) {
      paramb.a(false);
      return;
    } 
    int i = paramb.d;
    int j = this.f;
    if (i >= j)
      return; 
    paramb.d = j;
    paramb.b.a((T)this.d);
  }
  
  void c(b paramb) {
    if (this.g) {
      this.h = true;
      return;
    } 
    this.g = true;
    while (true) {
      b b1;
      this.h = false;
      if (paramb != null) {
        b(paramb);
        b1 = null;
      } else {
        c.b.d<Map.Entry> d = this.b.f();
        while (true) {
          b1 = paramb;
          if (d.hasNext()) {
            b((b)((Map.Entry)d.next()).getValue());
            if (this.h) {
              b1 = paramb;
              break;
            } 
            continue;
          } 
          break;
        } 
      } 
      paramb = b1;
      if (!this.h) {
        this.g = false;
        return;
      } 
    } 
  }
  
  protected void d() {}
  
  protected void e() {}
  
  protected void f(T paramT) {
    synchronized (this.a) {
      boolean bool;
      if (this.e == j) {
        bool = true;
      } else {
        bool = false;
      } 
      this.e = paramT;
      if (!bool)
        return; 
      b.a.e().c(this.i);
      return;
    } 
  }
  
  public void g(q<? super T> paramq) {
    a("removeObserver");
    b b1 = (b)this.b.j(paramq);
    if (b1 == null)
      return; 
    b1.b();
    b1.a(false);
  }
  
  protected void h(T paramT) {
    a("setValue");
    this.f++;
    this.d = paramT;
    c(null);
  }
  
  class LifecycleBoundObserver extends b implements h {
    final j f;
    
    void b() {
      this.f.getLifecycle().c(this);
    }
    
    boolean c() {
      return this.f.getLifecycle().b().a(f.c.e);
    }
    
    public void onStateChanged(j param1j, f.b param1b) {
      if (this.f.getLifecycle().b() == f.c.b) {
        this.g.g(this.b);
        return;
      } 
      a(c());
    }
  }
  
  class a implements Runnable {
    a(LiveData this$0) {}
    
    public void run() {
      synchronized (this.b.a) {
        Object object = this.b.e;
        this.b.e = LiveData.j;
        this.b.h(object);
        return;
      } 
    }
  }
  
  private abstract class b {
    final q<? super T> b;
    
    boolean c;
    
    int d;
    
    void a(boolean param1Boolean) {
      boolean bool;
      if (param1Boolean == this.c)
        return; 
      this.c = param1Boolean;
      LiveData liveData = this.e;
      int i = liveData.c;
      byte b1 = 1;
      if (i == 0) {
        bool = true;
      } else {
        bool = false;
      } 
      if (!param1Boolean)
        b1 = -1; 
      liveData.c = i + b1;
      if (bool && param1Boolean)
        liveData.d(); 
      liveData = this.e;
      if (liveData.c == 0 && !this.c)
        liveData.e(); 
      if (this.c)
        this.e.c(this); 
    }
    
    void b() {}
    
    abstract boolean c();
  }
}


/* Location:              C:\soft\dex2jar-2.0\Hill race-dex2jar.jar!\androidx\lifecycle\LiveData.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */