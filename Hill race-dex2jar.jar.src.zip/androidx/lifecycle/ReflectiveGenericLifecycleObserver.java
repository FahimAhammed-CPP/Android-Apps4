package androidx.lifecycle;

@Deprecated
class ReflectiveGenericLifecycleObserver implements h {
  private final Object b;
  
  private final a.a c;
  
  ReflectiveGenericLifecycleObserver(Object paramObject) {
    this.b = paramObject;
    this.c = a.c.c(paramObject.getClass());
  }
  
  public void onStateChanged(j paramj, f.b paramb) {
    this.c.a(paramj, paramb, this.b);
  }
}


/* Location:              C:\soft\dex2jar-2.0\Hill race-dex2jar.jar!\androidx\lifecycle\ReflectiveGenericLifecycleObserver.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */