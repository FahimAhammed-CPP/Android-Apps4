package androidx.lifecycle;

import android.app.Activity;
import android.app.Application;
import android.content.Context;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;

public class s implements j {
  private static final s j = new s();
  
  private int b = 0;
  
  private int c = 0;
  
  private boolean d = true;
  
  private boolean e = true;
  
  private Handler f;
  
  private final k g = new k(this);
  
  private Runnable h = new a(this);
  
  t.a i = new b(this);
  
  public static j h() {
    return j;
  }
  
  static void i(Context paramContext) {
    j.e(paramContext);
  }
  
  void a() {
    int i = this.c - 1;
    this.c = i;
    if (i == 0)
      this.f.postDelayed(this.h, 700L); 
  }
  
  void b() {
    int i = this.c + 1;
    this.c = i;
    if (i == 1) {
      if (this.d) {
        this.g.h(f.b.ON_RESUME);
        this.d = false;
        return;
      } 
      this.f.removeCallbacks(this.h);
    } 
  }
  
  void c() {
    int i = this.b + 1;
    this.b = i;
    if (i == 1 && this.e) {
      this.g.h(f.b.ON_START);
      this.e = false;
    } 
  }
  
  void d() {
    this.b--;
    g();
  }
  
  void e(Context paramContext) {
    this.f = new Handler();
    this.g.h(f.b.ON_CREATE);
    ((Application)paramContext.getApplicationContext()).registerActivityLifecycleCallbacks(new c());
  }
  
  void f() {
    if (this.c == 0) {
      this.d = true;
      this.g.h(f.b.ON_PAUSE);
    } 
  }
  
  void g() {
    if (this.b == 0 && this.d) {
      this.g.h(f.b.ON_STOP);
      this.e = true;
    } 
  }
  
  public f getLifecycle() {
    return this.g;
  }
  
  class a implements Runnable {
    a(s this$0) {}
    
    public void run() {
      this.b.f();
      this.b.g();
    }
  }
  
  class b implements t.a {
    b(s this$0) {}
    
    public void onCreate() {}
    
    public void onResume() {
      this.a.b();
    }
    
    public void onStart() {
      this.a.c();
    }
  }
  
  class c extends c {
    public void onActivityCreated(Activity param1Activity, Bundle param1Bundle) {
      if (Build.VERSION.SDK_INT < 29)
        t.f(param1Activity).h(s.this.i); 
    }
    
    public void onActivityPaused(Activity param1Activity) {
      s.this.a();
    }
    
    public void onActivityPreCreated(Activity param1Activity, Bundle param1Bundle) {
      s.d.a(param1Activity, new a());
    }
    
    public void onActivityStopped(Activity param1Activity) {
      s.this.d();
    }
    
    class a extends c {
      public void onActivityPostResumed(Activity param2Activity) {
        s.this.b();
      }
      
      public void onActivityPostStarted(Activity param2Activity) {
        s.this.c();
      }
    }
  }
  
  class a extends c {
    public void onActivityPostResumed(Activity param1Activity) {
      s.this.b();
    }
    
    public void onActivityPostStarted(Activity param1Activity) {
      s.this.c();
    }
  }
  
  static class d {
    static void a(Activity param1Activity, Application.ActivityLifecycleCallbacks param1ActivityLifecycleCallbacks) {
      param1Activity.registerActivityLifecycleCallbacks(param1ActivityLifecycleCallbacks);
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Hill race-dex2jar.jar!\androidx\lifecycle\s.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */