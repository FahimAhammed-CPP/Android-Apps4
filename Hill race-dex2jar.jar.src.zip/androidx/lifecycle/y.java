package androidx.lifecycle;

public interface y {
  x getViewModelStore();
}


/* Location:              C:\soft\dex2jar-2.0\Hill race-dex2jar.jar!\androidx\lifecycle\y.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */