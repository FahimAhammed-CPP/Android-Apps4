package androidx.lifecycle;

import java.util.HashMap;
import java.util.Iterator;

public class x {
  private final HashMap<String, v> a = new HashMap<String, v>();
  
  public final void a() {
    Iterator<v> iterator = this.a.values().iterator();
    while (iterator.hasNext())
      ((v)iterator.next()).a(); 
    this.a.clear();
  }
  
  final v b(String paramString) {
    return this.a.get(paramString);
  }
  
  final void c(String paramString, v paramv) {
    v v1 = this.a.put(paramString, paramv);
    if (v1 != null)
      v1.a(); 
  }
}


/* Location:              C:\soft\dex2jar-2.0\Hill race-dex2jar.jar!\androidx\lifecycle\x.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */