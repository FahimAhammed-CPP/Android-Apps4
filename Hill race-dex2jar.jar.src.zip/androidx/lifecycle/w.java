package androidx.lifecycle;

public class w {
  private final a a;
  
  private final x b;
  
  public w(x paramx, a parama) {
    this.a = parama;
    this.b = paramx;
  }
  
  public <T extends v> T a(Class<T> paramClass) {
    String str = paramClass.getCanonicalName();
    if (str != null) {
      StringBuilder stringBuilder = new StringBuilder();
      stringBuilder.append("androidx.lifecycle.ViewModelProvider.DefaultKey:");
      stringBuilder.append(str);
      return b(stringBuilder.toString(), paramClass);
    } 
    throw new IllegalArgumentException("Local and anonymous classes can not be ViewModels");
  }
  
  public <T extends v> T b(String paramString, Class<T> paramClass) {
    v v = this.b.b(paramString);
    if (paramClass.isInstance(v))
      return (T)v; 
    paramClass = this.a.a((Class)paramClass);
    this.b.c(paramString, (v)paramClass);
    return (T)paramClass;
  }
  
  public static interface a {
    <T extends v> T a(Class<T> param1Class);
  }
}


/* Location:              C:\soft\dex2jar-2.0\Hill race-dex2jar.jar!\androidx\lifecycle\w.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */