package androidx.lifecycle;

class SingleGeneratedAdapterObserver implements h {
  private final e b;
  
  SingleGeneratedAdapterObserver(e parame) {
    this.b = parame;
  }
  
  public void onStateChanged(j paramj, f.b paramb) {
    this.b.a(paramj, paramb, false, null);
    this.b.a(paramj, paramb, true, null);
  }
}


/* Location:              C:\soft\dex2jar-2.0\Hill race-dex2jar.jar!\androidx\lifecycle\SingleGeneratedAdapterObserver.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */