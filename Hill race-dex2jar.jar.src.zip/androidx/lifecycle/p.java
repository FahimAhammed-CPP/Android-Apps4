package androidx.lifecycle;

public class p<T> extends LiveData<T> {
  public void f(T paramT) {
    super.f(paramT);
  }
  
  public void h(T paramT) {
    super.h(paramT);
  }
}


/* Location:              C:\soft\dex2jar-2.0\Hill race-dex2jar.jar!\androidx\lifecycle\p.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */