package androidx.lifecycle;

class FullLifecycleObserverAdapter implements h {
  private final d b;
  
  private final h c;
  
  FullLifecycleObserverAdapter(d paramd, h paramh) {
    this.b = paramd;
    this.c = paramh;
  }
  
  public void onStateChanged(j paramj, f.b paramb) {
    switch (a.a[paramb.ordinal()]) {
      case 7:
        throw new IllegalArgumentException("ON_ANY must not been send by anybody");
      case 6:
        this.b.onDestroy(paramj);
        break;
      case 5:
        this.b.onStop(paramj);
        break;
      case 4:
        this.b.onPause(paramj);
        break;
      case 3:
        this.b.onResume(paramj);
        break;
      case 2:
        this.b.onStart(paramj);
        break;
      case 1:
        this.b.onCreate(paramj);
        break;
    } 
    h h1 = this.c;
    if (h1 != null)
      h1.onStateChanged(paramj, paramb); 
  }
}


/* Location:              C:\soft\dex2jar-2.0\Hill race-dex2jar.jar!\androidx\lifecycle\FullLifecycleObserverAdapter.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */