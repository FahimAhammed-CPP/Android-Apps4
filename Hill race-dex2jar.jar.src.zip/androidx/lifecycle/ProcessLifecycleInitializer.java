package androidx.lifecycle;

import android.content.Context;
import androidx.startup.a;
import java.util.Collections;
import java.util.List;
import o.a;

public final class ProcessLifecycleInitializer implements a<j> {
  public j a(Context paramContext) {
    if (a.e(paramContext).g(ProcessLifecycleInitializer.class)) {
      g.a(paramContext);
      s.i(paramContext);
      return s.h();
    } 
    throw new IllegalStateException("ProcessLifecycleInitializer cannot be initialized lazily. \nPlease ensure that you have: \n<meta-data\n    android:name='androidx.lifecycle.ProcessLifecycleInitializer' \n    android:value='androidx.startup' /> \nunder InitializationProvider in your AndroidManifest.xml");
  }
  
  public List<Class<? extends a<?>>> dependencies() {
    return Collections.emptyList();
  }
}


/* Location:              C:\soft\dex2jar-2.0\Hill race-dex2jar.jar!\androidx\lifecycle\ProcessLifecycleInitializer.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */