package androidx.browser.customtabs;

import a.b;
import android.app.PendingIntent;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.os.Parcelable;
import android.os.RemoteException;
import android.text.TextUtils;

public class c {
  private final b a;
  
  private final ComponentName b;
  
  private final Context c;
  
  c(b paramb, ComponentName paramComponentName, Context paramContext) {
    this.a = paramb;
    this.b = paramComponentName;
    this.c = paramContext;
  }
  
  public static boolean a(Context paramContext, String paramString, e parame) {
    parame.setApplicationContext(paramContext.getApplicationContext());
    Intent intent = new Intent("android.support.customtabs.action.CustomTabsService");
    if (!TextUtils.isEmpty(paramString))
      intent.setPackage(paramString); 
    return paramContext.bindService(intent, parame, 33);
  }
  
  private a.a.a b(b paramb) {
    return new a(this, paramb);
  }
  
  private f d(b paramb, PendingIntent paramPendingIntent) {
    a.a.a a = b(paramb);
    if (paramPendingIntent != null)
      try {
        Bundle bundle = new Bundle();
        bundle.putParcelable("android.support.customtabs.extra.SESSION_ID", (Parcelable)paramPendingIntent);
        boolean bool1 = this.a.f((a.a)a, bundle);
        return !bool1 ? null : new f(this.a, (a.a)a, this.b, paramPendingIntent);
      } catch (RemoteException remoteException) {
        return null;
      }  
    boolean bool = this.a.d((a.a)remoteException);
    return !bool ? null : new f(this.a, (a.a)remoteException, this.b, paramPendingIntent);
  }
  
  public f c(b paramb) {
    return d(paramb, null);
  }
  
  public boolean e(long paramLong) {
    try {
      return this.a.e(paramLong);
    } catch (RemoteException remoteException) {
      return false;
    } 
  }
  
  class a extends a.a.a {
    private Handler b = new Handler(Looper.getMainLooper());
    
    a(c this$0, b param1b) {}
    
    public Bundle c(String param1String, Bundle param1Bundle) throws RemoteException {
      return null;
    }
    
    public void g(String param1String, Bundle param1Bundle) throws RemoteException {}
    
    public void h(int param1Int, Bundle param1Bundle) {}
    
    public void i(String param1String, Bundle param1Bundle) throws RemoteException {}
    
    public void k(Bundle param1Bundle) throws RemoteException {}
    
    public void l(int param1Int, Uri param1Uri, boolean param1Boolean, Bundle param1Bundle) throws RemoteException {}
  }
}


/* Location:              C:\soft\dex2jar-2.0\Hill race-dex2jar.jar!\androidx\browser\customtabs\c.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */