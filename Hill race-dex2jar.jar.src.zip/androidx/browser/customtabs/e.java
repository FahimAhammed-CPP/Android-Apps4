package androidx.browser.customtabs;

import a.b;
import android.content.ComponentName;
import android.content.Context;
import android.content.ServiceConnection;
import android.os.IBinder;

public abstract class e implements ServiceConnection {
  private Context mApplicationContext;
  
  Context getApplicationContext() {
    return this.mApplicationContext;
  }
  
  public abstract void onCustomTabsServiceConnected(ComponentName paramComponentName, c paramc);
  
  public final void onServiceConnected(ComponentName paramComponentName, IBinder paramIBinder) {
    if (this.mApplicationContext != null) {
      onCustomTabsServiceConnected(paramComponentName, new a(this, b.a.n(paramIBinder), paramComponentName, this.mApplicationContext));
      return;
    } 
    throw new IllegalStateException("Custom Tabs Service connected before an applicationcontext has been provided.");
  }
  
  void setApplicationContext(Context paramContext) {
    this.mApplicationContext = paramContext;
  }
  
  class a extends c {
    a(e this$0, b param1b, ComponentName param1ComponentName, Context param1Context) {
      super(param1b, param1ComponentName, param1Context);
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Hill race-dex2jar.jar!\androidx\browser\customtabs\e.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */