package androidx.room;

import android.os.Binder;
import android.os.IBinder;
import android.os.IInterface;
import android.os.Parcel;
import android.os.RemoteException;

public interface c extends IInterface {
  int b(b paramb, String paramString) throws RemoteException;
  
  void j(int paramInt, String[] paramArrayOfString) throws RemoteException;
  
  void m(b paramb, int paramInt) throws RemoteException;
  
  public static abstract class a extends Binder implements c {
    public a() {
      attachInterface(this, "androidx.room.IMultiInstanceInvalidationService");
    }
    
    public static c n(IBinder param1IBinder) {
      if (param1IBinder == null)
        return null; 
      IInterface iInterface = param1IBinder.queryLocalInterface("androidx.room.IMultiInstanceInvalidationService");
      return (iInterface != null && iInterface instanceof c) ? (c)iInterface : new a(param1IBinder);
    }
    
    public IBinder asBinder() {
      return (IBinder)this;
    }
    
    public boolean onTransact(int param1Int1, Parcel param1Parcel1, Parcel param1Parcel2, int param1Int2) throws RemoteException {
      if (param1Int1 != 1) {
        if (param1Int1 != 2) {
          if (param1Int1 != 3) {
            if (param1Int1 != 1598968902)
              return super.onTransact(param1Int1, param1Parcel1, param1Parcel2, param1Int2); 
            param1Parcel2.writeString("androidx.room.IMultiInstanceInvalidationService");
            return true;
          } 
          param1Parcel1.enforceInterface("androidx.room.IMultiInstanceInvalidationService");
          j(param1Parcel1.readInt(), param1Parcel1.createStringArray());
          return true;
        } 
        param1Parcel1.enforceInterface("androidx.room.IMultiInstanceInvalidationService");
        m(b.a.n(param1Parcel1.readStrongBinder()), param1Parcel1.readInt());
        param1Parcel2.writeNoException();
        return true;
      } 
      param1Parcel1.enforceInterface("androidx.room.IMultiInstanceInvalidationService");
      param1Int1 = b(b.a.n(param1Parcel1.readStrongBinder()), param1Parcel1.readString());
      param1Parcel2.writeNoException();
      param1Parcel2.writeInt(param1Int1);
      return true;
    }
    
    private static class a implements c {
      private IBinder b;
      
      a(IBinder param2IBinder) {
        this.b = param2IBinder;
      }
      
      public IBinder asBinder() {
        return this.b;
      }
      
      public int b(b param2b, String param2String) throws RemoteException {
        Parcel parcel1 = Parcel.obtain();
        Parcel parcel2 = Parcel.obtain();
        try {
        
        } finally {
          parcel2.recycle();
          parcel1.recycle();
        } 
        param2b = null;
        parcel1.writeStrongBinder((IBinder)param2b);
        parcel1.writeString(param2String);
        this.b.transact(1, parcel1, parcel2, 0);
        parcel2.readException();
        int i = parcel2.readInt();
        parcel2.recycle();
        parcel1.recycle();
        return i;
      }
      
      public void j(int param2Int, String[] param2ArrayOfString) throws RemoteException {
        Parcel parcel = Parcel.obtain();
        try {
          parcel.writeInterfaceToken("androidx.room.IMultiInstanceInvalidationService");
          parcel.writeInt(param2Int);
          parcel.writeStringArray(param2ArrayOfString);
          this.b.transact(3, parcel, null, 1);
          return;
        } finally {
          parcel.recycle();
        } 
      }
      
      public void m(b param2b, int param2Int) throws RemoteException {
        Parcel parcel1 = Parcel.obtain();
        Parcel parcel2 = Parcel.obtain();
        try {
          parcel1.writeInterfaceToken("androidx.room.IMultiInstanceInvalidationService");
          if (param2b != null) {
            IBinder iBinder = param2b.asBinder();
          } else {
            param2b = null;
          } 
          parcel1.writeStrongBinder((IBinder)param2b);
          parcel1.writeInt(param2Int);
          this.b.transact(2, parcel1, parcel2, 0);
          parcel2.readException();
          return;
        } finally {
          parcel2.recycle();
          parcel1.recycle();
        } 
      }
    }
  }
  
  private static class a implements c {
    private IBinder b;
    
    a(IBinder param1IBinder) {
      this.b = param1IBinder;
    }
    
    public IBinder asBinder() {
      return this.b;
    }
    
    public int b(b param1b, String param1String) throws RemoteException {
      Parcel parcel1 = Parcel.obtain();
      Parcel parcel2 = Parcel.obtain();
      try {
      
      } finally {
        parcel2.recycle();
        parcel1.recycle();
      } 
      param1b = null;
      parcel1.writeStrongBinder((IBinder)param1b);
      parcel1.writeString(param1String);
      this.b.transact(1, parcel1, parcel2, 0);
      parcel2.readException();
      int i = parcel2.readInt();
      parcel2.recycle();
      parcel1.recycle();
      return i;
    }
    
    public void j(int param1Int, String[] param1ArrayOfString) throws RemoteException {
      Parcel parcel = Parcel.obtain();
      try {
        parcel.writeInterfaceToken("androidx.room.IMultiInstanceInvalidationService");
        parcel.writeInt(param1Int);
        parcel.writeStringArray(param1ArrayOfString);
        this.b.transact(3, parcel, null, 1);
        return;
      } finally {
        parcel.recycle();
      } 
    }
    
    public void m(b param1b, int param1Int) throws RemoteException {
      Parcel parcel1 = Parcel.obtain();
      Parcel parcel2 = Parcel.obtain();
      try {
        parcel1.writeInterfaceToken("androidx.room.IMultiInstanceInvalidationService");
        if (param1b != null) {
          IBinder iBinder = param1b.asBinder();
        } else {
          param1b = null;
        } 
        parcel1.writeStrongBinder((IBinder)param1b);
        parcel1.writeInt(param1Int);
        this.b.transact(2, parcel1, parcel2, 0);
        parcel2.readException();
        return;
      } finally {
        parcel2.recycle();
        parcel1.recycle();
      } 
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Hill race-dex2jar.jar!\androidx\room\c.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */