package androidx.room;

import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.content.ServiceConnection;
import android.os.IBinder;
import android.os.RemoteException;
import android.util.Log;
import java.util.Set;
import java.util.concurrent.Executor;
import java.util.concurrent.atomic.AtomicBoolean;

class f {
  final Context a;
  
  final String b;
  
  int c;
  
  final e d;
  
  final e.c e;
  
  c f;
  
  final Executor g;
  
  final b h = new a(this);
  
  final AtomicBoolean i = new AtomicBoolean(false);
  
  final ServiceConnection j;
  
  final Runnable k;
  
  final Runnable l;
  
  private final Runnable m;
  
  f(Context paramContext, String paramString, e parame, Executor paramExecutor) {
    b b1 = new b(this);
    this.j = b1;
    this.k = new c(this);
    this.l = new d(this);
    this.m = new e(this);
    paramContext = paramContext.getApplicationContext();
    this.a = paramContext;
    this.b = paramString;
    this.d = parame;
    this.g = paramExecutor;
    this.e = new f(this, (String[])parame.a.keySet().toArray((Object[])new String[0]));
    paramContext.bindService(new Intent(paramContext, MultiInstanceInvalidationService.class), b1, 1);
  }
  
  class a extends b.a {
    a(f this$0) {}
    
    public void a(String[] param1ArrayOfString) {
      this.b.g.execute(new a(this, param1ArrayOfString));
    }
    
    class a implements Runnable {
      a(f.a this$0, String[] param2ArrayOfString) {}
      
      public void run() {
        this.c.b.d.e(this.b);
      }
    }
  }
  
  class a implements Runnable {
    a(f this$0, String[] param1ArrayOfString) {}
    
    public void run() {
      this.c.b.d.e(this.b);
    }
  }
  
  class b implements ServiceConnection {
    b(f this$0) {}
    
    public void onServiceConnected(ComponentName param1ComponentName, IBinder param1IBinder) {
      this.a.f = c.a.n(param1IBinder);
      f f1 = this.a;
      f1.g.execute(f1.k);
    }
    
    public void onServiceDisconnected(ComponentName param1ComponentName) {
      f f1 = this.a;
      f1.g.execute(f1.l);
      this.a.f = null;
    }
  }
  
  class c implements Runnable {
    c(f this$0) {}
    
    public void run() {
      try {
        f f1 = this.b;
        c c1 = f1.f;
        if (c1 != null) {
          f1.c = c1.b(f1.h, f1.b);
          f1 = this.b;
          f1.d.a(f1.e);
          return;
        } 
      } catch (RemoteException remoteException) {
        Log.w("ROOM", "Cannot register multi-instance invalidation callback", (Throwable)remoteException);
      } 
    }
  }
  
  class d implements Runnable {
    d(f this$0) {}
    
    public void run() {
      f f1 = this.b;
      f1.d.g(f1.e);
    }
  }
  
  class e implements Runnable {
    e(f this$0) {}
    
    public void run() {
      f f1 = this.b;
      f1.d.g(f1.e);
      try {
        f1 = this.b;
        c c = f1.f;
        if (c != null)
          c.m(f1.h, f1.c); 
      } catch (RemoteException remoteException) {
        Log.w("ROOM", "Cannot unregister multi-instance invalidation callback", (Throwable)remoteException);
      } 
      f1 = this.b;
      f1.a.unbindService(f1.j);
    }
  }
  
  class f extends e.c {
    f(f this$0, String[] param1ArrayOfString) {
      super(param1ArrayOfString);
    }
    
    boolean a() {
      return true;
    }
    
    public void b(Set<String> param1Set) {
      if (this.b.i.get())
        return; 
      try {
        f f1 = this.b;
        c c1 = f1.f;
        if (c1 != null) {
          c1.j(f1.c, param1Set.<String>toArray(new String[0]));
          return;
        } 
      } catch (RemoteException remoteException) {
        Log.w("ROOM", "Cannot broadcast invalidation", (Throwable)remoteException);
      } 
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Hill race-dex2jar.jar!\androidx\room\f.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */