package androidx.room;

import android.app.Service;
import android.content.Intent;
import android.os.IBinder;
import android.os.IInterface;
import android.os.RemoteCallbackList;
import android.os.RemoteException;
import android.util.Log;
import java.util.HashMap;

public class MultiInstanceInvalidationService extends Service {
  int b = 0;
  
  final HashMap<Integer, String> c = new HashMap<Integer, String>();
  
  final RemoteCallbackList<b> d = new a(this);
  
  private final c.a e = new b(this);
  
  public IBinder onBind(Intent paramIntent) {
    return (IBinder)this.e;
  }
  
  class a extends RemoteCallbackList<b> {
    a(MultiInstanceInvalidationService this$0) {}
    
    public void a(b param1b, Object param1Object) {
      this.a.c.remove(Integer.valueOf(((Integer)param1Object).intValue()));
    }
  }
  
  class b extends c.a {
    b(MultiInstanceInvalidationService this$0) {}
    
    public int b(b param1b, String param1String) {
      if (param1String == null)
        return 0; 
      synchronized (this.b.d) {
        MultiInstanceInvalidationService multiInstanceInvalidationService2 = this.b;
        int i = multiInstanceInvalidationService2.b + 1;
        multiInstanceInvalidationService2.b = i;
        if (multiInstanceInvalidationService2.d.register(param1b, Integer.valueOf(i))) {
          this.b.c.put(Integer.valueOf(i), param1String);
          return i;
        } 
        MultiInstanceInvalidationService multiInstanceInvalidationService1 = this.b;
        multiInstanceInvalidationService1.b--;
        return 0;
      } 
    }
    
    public void j(int param1Int, String[] param1ArrayOfString) {
      synchronized (this.b.d) {
        String str = this.b.c.get(Integer.valueOf(param1Int));
        if (str == null) {
          Log.w("ROOM", "Remote invalidation client ID not registered");
          return;
        } 
        int j = this.b.d.beginBroadcast();
        int i = 0;
        while (i < j) {
          try {
            int k = ((Integer)this.b.d.getBroadcastCookie(i)).intValue();
            String str1 = this.b.c.get(Integer.valueOf(k));
            if (param1Int != k) {
              boolean bool = str.equals(str1);
              if (bool)
                try {
                  ((b)this.b.d.getBroadcastItem(i)).a(param1ArrayOfString);
                } catch (RemoteException remoteException) {
                  Log.w("ROOM", "Error invoking a remote callback", (Throwable)remoteException);
                }  
            } 
          } finally {
            this.b.d.finishBroadcast();
          } 
        } 
        this.b.d.finishBroadcast();
        return;
      } 
    }
    
    public void m(b param1b, int param1Int) {
      synchronized (this.b.d) {
        this.b.d.unregister(param1b);
        this.b.c.remove(Integer.valueOf(param1Int));
        return;
      } 
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Hill race-dex2jar.jar!\androidx\room\MultiInstanceInvalidationService.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */