package androidx.room;

import android.annotation.SuppressLint;
import android.app.ActivityManager;
import android.content.Context;
import android.database.Cursor;
import android.os.Build;
import android.os.CancellationSignal;
import android.os.Looper;
import android.util.Log;
import java.io.File;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.TreeMap;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.Executor;
import java.util.concurrent.locks.Lock;
import java.util.concurrent.locks.ReentrantReadWriteLock;
import m.e;
import m.f;

public abstract class h {
  @Deprecated
  protected volatile m.b a;
  
  private Executor b;
  
  private Executor c;
  
  private m.c d;
  
  private final e e = e();
  
  private boolean f;
  
  boolean g;
  
  @Deprecated
  protected List<b> h;
  
  private final ReentrantReadWriteLock i = new ReentrantReadWriteLock();
  
  private final ThreadLocal<Integer> j = new ThreadLocal<Integer>();
  
  private final Map<String, Object> k = new ConcurrentHashMap<String, Object>();
  
  private static boolean n() {
    return (Looper.getMainLooper().getThread() == Thread.currentThread());
  }
  
  public void a() {
    if (this.f)
      return; 
    if (!n())
      return; 
    throw new IllegalStateException("Cannot access database on the main thread since it may potentially lock the UI for a long period of time.");
  }
  
  public void b() {
    if (!k()) {
      if (this.j.get() == null)
        return; 
      throw new IllegalStateException("Cannot access database on a different coroutine context inherited from a suspending transaction.");
    } 
  }
  
  @Deprecated
  public void c() {
    a();
    m.b b1 = this.d.V();
    this.e.m(b1);
    b1.D();
  }
  
  public f d(String paramString) {
    a();
    b();
    return this.d.V().K(paramString);
  }
  
  protected abstract e e();
  
  protected abstract m.c f(a parama);
  
  @Deprecated
  public void g() {
    this.d.V().Y();
    if (!k())
      this.e.f(); 
  }
  
  Lock h() {
    return this.i.readLock();
  }
  
  public m.c i() {
    return this.d;
  }
  
  public Executor j() {
    return this.b;
  }
  
  public boolean k() {
    return this.d.V().f0();
  }
  
  public void l(a parama) {
    m.c c1 = f(parama);
    this.d = c1;
    if (c1 instanceof j)
      ((j)c1).d(parama); 
    int i = Build.VERSION.SDK_INT;
    boolean bool1 = false;
    boolean bool2 = false;
    if (i >= 16) {
      bool1 = bool2;
      if (parama.g == c.d)
        bool1 = true; 
      this.d.setWriteAheadLoggingEnabled(bool1);
    } 
    this.h = parama.e;
    this.b = parama.h;
    this.c = new l(parama.i);
    this.f = parama.f;
    this.g = bool1;
    if (parama.j)
      this.e.i(parama.b, parama.c); 
  }
  
  protected void m(m.b paramb) {
    this.e.d(paramb);
  }
  
  public boolean o() {
    m.b b1 = this.a;
    return (b1 != null && b1.isOpen());
  }
  
  public Cursor p(e parame) {
    return q(parame, null);
  }
  
  public Cursor q(e parame, CancellationSignal paramCancellationSignal) {
    a();
    b();
    return (paramCancellationSignal != null && Build.VERSION.SDK_INT >= 16) ? this.d.V().H(parame, paramCancellationSignal) : this.d.V().I(parame);
  }
  
  @Deprecated
  public void r() {
    this.d.V().Q();
  }
  
  public static class a<T extends h> {
    private final Class<T> a;
    
    private final String b;
    
    private final Context c;
    
    private ArrayList<h.b> d;
    
    private Executor e;
    
    private Executor f;
    
    private m.c.c g;
    
    private boolean h;
    
    private h.c i;
    
    private boolean j;
    
    private boolean k;
    
    private boolean l;
    
    private final h.d m;
    
    private Set<Integer> n;
    
    private Set<Integer> o;
    
    private String p;
    
    private File q;
    
    a(Context param1Context, Class<T> param1Class, String param1String) {
      this.c = param1Context;
      this.a = param1Class;
      this.b = param1String;
      this.i = h.c.b;
      this.k = true;
      this.m = new h.d();
    }
    
    public a<T> a(h.b param1b) {
      if (this.d == null)
        this.d = new ArrayList<h.b>(); 
      this.d.add(param1b);
      return this;
    }
    
    public a<T> b(k.a... param1VarArgs) {
      if (this.o == null)
        this.o = new HashSet<Integer>(); 
      int j = param1VarArgs.length;
      for (int i = 0; i < j; i++) {
        k.a a1 = param1VarArgs[i];
        this.o.add(Integer.valueOf(a1.a));
        this.o.add(Integer.valueOf(a1.b));
      } 
      this.m.b(param1VarArgs);
      return this;
    }
    
    public a<T> c() {
      this.h = true;
      return this;
    }
    
    @SuppressLint({"RestrictedApi"})
    public T d() {
      if (this.c != null) {
        if (this.a != null) {
          Executor executor = this.e;
          if (executor == null && this.f == null) {
            executor = b.a.d();
            this.f = executor;
            this.e = executor;
          } else if (executor != null && this.f == null) {
            this.f = executor;
          } else if (executor == null) {
            executor = this.f;
            if (executor != null)
              this.e = executor; 
          } 
          Set<Integer> set = this.o;
          if (set != null && this.n != null) {
            Iterator<Integer> iterator = set.iterator();
            while (iterator.hasNext()) {
              Integer integer = iterator.next();
              if (!this.n.contains(integer))
                continue; 
              StringBuilder stringBuilder = new StringBuilder();
              stringBuilder.append("Inconsistency detected. A Migration was supplied to addMigration(Migration... migrations) that has a start or end version equal to a start version supplied to fallbackToDestructiveMigrationFrom(int... startVersions). Start version: ");
              stringBuilder.append(integer);
              throw new IllegalArgumentException(stringBuilder.toString());
            } 
          } 
          if (this.g == null)
            this.g = (m.c.c)new n.c(); 
          String str = this.p;
          if (str != null || this.q != null) {
            if (this.b != null) {
              if (str == null || this.q == null) {
                this.g = new k(str, this.q, this.g);
                Context context = this.c;
                a a1 = new a(context, this.b, this.g, this.m, this.d, this.h, this.i.b(context), this.e, this.f, this.j, this.k, this.l, this.n, this.p, this.q);
                h h = g.<h, T>b(this.a, "_Impl");
                h.l(a1);
                return (T)h;
              } 
              throw new IllegalArgumentException("Both createFromAsset() and createFromFile() was called on this Builder but the database can only be created using one of the two configurations.");
            } 
          } else {
            Context context = this.c;
            a a1 = new a(context, this.b, this.g, this.m, this.d, this.h, this.i.b(context), this.e, this.f, this.j, this.k, this.l, this.n, this.p, this.q);
            h h = g.<h, T>b(this.a, "_Impl");
            h.l(a1);
            return (T)h;
          } 
          throw new IllegalArgumentException("Cannot create from asset or file for an in-memory database.");
        } 
        throw new IllegalArgumentException("Must provide an abstract class that extends RoomDatabase");
      } 
      throw new IllegalArgumentException("Cannot provide null context for the database.");
    }
    
    public a<T> e() {
      this.k = false;
      this.l = true;
      return this;
    }
    
    public a<T> f(m.c.c param1c) {
      this.g = param1c;
      return this;
    }
    
    public a<T> g(Executor param1Executor) {
      this.e = param1Executor;
      return this;
    }
  }
  
  public static abstract class b {
    public void a(m.b param1b) {}
    
    public void b(m.b param1b) {}
    
    public void c(m.b param1b) {}
  }
  
  public enum c {
    b, c, d;
    
    static {
      c c1 = new c("AUTOMATIC", 0);
      b = c1;
      c c2 = new c("TRUNCATE", 1);
      c = c2;
      c c3 = new c("WRITE_AHEAD_LOGGING", 2);
      d = c3;
      e = new c[] { c1, c2, c3 };
    }
    
    private static boolean a(ActivityManager param1ActivityManager) {
      return (Build.VERSION.SDK_INT >= 19) ? param1ActivityManager.isLowRamDevice() : false;
    }
    
    @SuppressLint({"NewApi"})
    c b(Context param1Context) {
      if (this != b)
        return this; 
      if (Build.VERSION.SDK_INT >= 16) {
        ActivityManager activityManager = (ActivityManager)param1Context.getSystemService("activity");
        if (activityManager != null && !a(activityManager))
          return d; 
      } 
      return c;
    }
  }
  
  public static class d {
    private HashMap<Integer, TreeMap<Integer, k.a>> a = new HashMap<Integer, TreeMap<Integer, k.a>>();
    
    private void a(k.a param1a) {
      int i = param1a.a;
      int j = param1a.b;
      TreeMap<Object, Object> treeMap2 = (TreeMap)this.a.get(Integer.valueOf(i));
      TreeMap<Object, Object> treeMap1 = treeMap2;
      if (treeMap2 == null) {
        treeMap1 = new TreeMap<Object, Object>();
        this.a.put(Integer.valueOf(i), treeMap1);
      } 
      k.a a1 = (k.a)treeMap1.get(Integer.valueOf(j));
      if (a1 != null) {
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("Overriding migration ");
        stringBuilder.append(a1);
        stringBuilder.append(" with ");
        stringBuilder.append(param1a);
        Log.w("ROOM", stringBuilder.toString());
      } 
      treeMap1.put(Integer.valueOf(j), param1a);
    }
    
    private List<k.a> d(List<k.a> param1List, boolean param1Boolean, int param1Int1, int param1Int2) {
      while (param1Boolean ? (param1Int1 < param1Int2) : (param1Int1 > param1Int2)) {
        Set set;
        TreeMap treeMap = this.a.get(Integer.valueOf(param1Int1));
        if (treeMap == null)
          return null; 
        if (param1Boolean) {
          set = treeMap.descendingKeySet();
        } else {
          set = treeMap.keySet();
        } 
        Iterator iterator = set.iterator();
        while (true) {
          while (true) {
            boolean bool = iterator.hasNext();
            boolean bool1 = true;
            boolean bool2 = false;
            break;
          } 
          if (SYNTHETIC_LOCAL_VARIABLE_5 == null)
            return null; 
        } 
      } 
      return param1List;
    }
    
    public void b(k.a... param1VarArgs) {
      int j = param1VarArgs.length;
      for (int i = 0; i < j; i++)
        a(param1VarArgs[i]); 
    }
    
    public List<k.a> c(int param1Int1, int param1Int2) {
      boolean bool;
      if (param1Int1 == param1Int2)
        return Collections.emptyList(); 
      if (param1Int2 > param1Int1) {
        bool = true;
      } else {
        bool = false;
      } 
      return d(new ArrayList<k.a>(), bool, param1Int1, param1Int2);
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Hill race-dex2jar.jar!\androidx\room\h.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */