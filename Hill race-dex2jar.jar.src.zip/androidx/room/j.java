package androidx.room;

import android.content.Context;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.nio.channels.Channels;
import java.nio.channels.ReadableByteChannel;
import l.a;
import l.d;
import m.b;
import m.c;

class j implements c {
  private final Context b;
  
  private final String c;
  
  private final File d;
  
  private final int e;
  
  private final c f;
  
  private a g;
  
  private boolean h;
  
  j(Context paramContext, String paramString, File paramFile, int paramInt, c paramc) {
    this.b = paramContext;
    this.c = paramString;
    this.d = paramFile;
    this.e = paramInt;
    this.f = paramc;
  }
  
  private void a(File paramFile) throws IOException {
    ReadableByteChannel readableByteChannel;
    if (this.c != null) {
      readableByteChannel = Channels.newChannel(this.b.getAssets().open(this.c));
    } else if (this.d != null) {
      readableByteChannel = (new FileInputStream(this.d)).getChannel();
    } else {
      throw new IllegalStateException("copyFromAssetPath and copyFromFile == null!");
    } 
    File file2 = File.createTempFile("room-copy-helper", ".tmp", this.b.getCacheDir());
    file2.deleteOnExit();
    d.a(readableByteChannel, (new FileOutputStream(file2)).getChannel());
    File file1 = paramFile.getParentFile();
    if (file1 == null || file1.exists() || file1.mkdirs()) {
      if (file2.renameTo(paramFile))
        return; 
      StringBuilder stringBuilder1 = new StringBuilder();
      stringBuilder1.append("Failed to move intermediate file (");
      stringBuilder1.append(file2.getAbsolutePath());
      stringBuilder1.append(") to destination (");
      stringBuilder1.append(paramFile.getAbsolutePath());
      stringBuilder1.append(").");
      throw new IOException(stringBuilder1.toString());
    } 
    StringBuilder stringBuilder = new StringBuilder();
    stringBuilder.append("Failed to create directories for ");
    stringBuilder.append(paramFile.getAbsolutePath());
    throw new IOException(stringBuilder.toString());
  }
  
  private void g() {
    boolean bool;
    null = getDatabaseName();
    File file = this.b.getDatabasePath(null);
    a a2 = this.g;
    if (a2 == null || a2.j) {
      bool = true;
    } else {
      bool = false;
    } 
    a a1 = new a(null, this.b.getFilesDir(), bool);
    try {
      a1.b();
      bool = file.exists();
      if (!bool)
        try {
          a(file);
          return;
        } catch (IOException iOException) {
          throw new RuntimeException("Unable to copy database file.", iOException);
        }  
      a a3 = this.g;
      if (a3 == null)
        return; 
    } finally {
      a1.c();
    } 
  }
  
  public b V() {
    // Byte code:
    //   0: aload_0
    //   1: monitorenter
    //   2: aload_0
    //   3: getfield h : Z
    //   6: ifne -> 18
    //   9: aload_0
    //   10: invokespecial g : ()V
    //   13: aload_0
    //   14: iconst_1
    //   15: putfield h : Z
    //   18: aload_0
    //   19: getfield f : Lm/c;
    //   22: invokeinterface V : ()Lm/b;
    //   27: astore_1
    //   28: aload_0
    //   29: monitorexit
    //   30: aload_1
    //   31: areturn
    //   32: astore_1
    //   33: aload_0
    //   34: monitorexit
    //   35: aload_1
    //   36: athrow
    // Exception table:
    //   from	to	target	type
    //   2	18	32	finally
    //   18	28	32	finally
  }
  
  public void close() {
    // Byte code:
    //   0: aload_0
    //   1: monitorenter
    //   2: aload_0
    //   3: getfield f : Lm/c;
    //   6: invokeinterface close : ()V
    //   11: aload_0
    //   12: iconst_0
    //   13: putfield h : Z
    //   16: aload_0
    //   17: monitorexit
    //   18: return
    //   19: astore_1
    //   20: aload_0
    //   21: monitorexit
    //   22: aload_1
    //   23: athrow
    // Exception table:
    //   from	to	target	type
    //   2	16	19	finally
  }
  
  void d(a parama) {
    this.g = parama;
  }
  
  public String getDatabaseName() {
    return this.f.getDatabaseName();
  }
  
  public void setWriteAheadLoggingEnabled(boolean paramBoolean) {
    this.f.setWriteAheadLoggingEnabled(paramBoolean);
  }
}


/* Location:              C:\soft\dex2jar-2.0\Hill race-dex2jar.jar!\androidx\room\j.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */