package androidx.room;

import android.content.Context;
import java.io.File;
import java.util.List;
import java.util.Set;
import java.util.concurrent.Executor;
import m.c;

public class a {
  public final c.c a;
  
  public final Context b;
  
  public final String c;
  
  public final h.d d;
  
  public final List<h.b> e;
  
  public final boolean f;
  
  public final h.c g;
  
  public final Executor h;
  
  public final Executor i;
  
  public final boolean j;
  
  public final boolean k;
  
  public final boolean l;
  
  private final Set<Integer> m;
  
  public final String n;
  
  public final File o;
  
  public a(Context paramContext, String paramString1, c.c paramc, h.d paramd, List<h.b> paramList, boolean paramBoolean1, h.c paramc1, Executor paramExecutor1, Executor paramExecutor2, boolean paramBoolean2, boolean paramBoolean3, boolean paramBoolean4, Set<Integer> paramSet, String paramString2, File paramFile) {
    this.a = paramc;
    this.b = paramContext;
    this.c = paramString1;
    this.d = paramd;
    this.e = paramList;
    this.f = paramBoolean1;
    this.g = paramc1;
    this.h = paramExecutor1;
    this.i = paramExecutor2;
    this.j = paramBoolean2;
    this.k = paramBoolean3;
    this.l = paramBoolean4;
    this.m = paramSet;
    this.n = paramString2;
    this.o = paramFile;
  }
  
  public boolean a(int paramInt1, int paramInt2) {
    null = true;
    if (paramInt1 > paramInt2) {
      paramInt2 = 1;
    } else {
      paramInt2 = 0;
    } 
    if (paramInt2 != 0 && this.l)
      return false; 
    if (this.k) {
      Set<Integer> set = this.m;
      if (set != null) {
        if (!set.contains(Integer.valueOf(paramInt1)))
          return true; 
      } else {
        return null;
      } 
    } 
    return false;
  }
}


/* Location:              C:\soft\dex2jar-2.0\Hill race-dex2jar.jar!\androidx\room\a.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */