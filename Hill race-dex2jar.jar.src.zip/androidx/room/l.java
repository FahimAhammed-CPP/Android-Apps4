package androidx.room;

import java.util.ArrayDeque;
import java.util.concurrent.Executor;

class l implements Executor {
  private final Executor b;
  
  private final ArrayDeque<Runnable> c = new ArrayDeque<Runnable>();
  
  private Runnable d;
  
  l(Executor paramExecutor) {
    this.b = paramExecutor;
  }
  
  void a() {
    // Byte code:
    //   0: aload_0
    //   1: monitorenter
    //   2: aload_0
    //   3: getfield c : Ljava/util/ArrayDeque;
    //   6: invokevirtual poll : ()Ljava/lang/Object;
    //   9: checkcast java/lang/Runnable
    //   12: astore_1
    //   13: aload_0
    //   14: aload_1
    //   15: putfield d : Ljava/lang/Runnable;
    //   18: aload_1
    //   19: ifnull -> 32
    //   22: aload_0
    //   23: getfield b : Ljava/util/concurrent/Executor;
    //   26: aload_1
    //   27: invokeinterface execute : (Ljava/lang/Runnable;)V
    //   32: aload_0
    //   33: monitorexit
    //   34: return
    //   35: astore_1
    //   36: aload_0
    //   37: monitorexit
    //   38: aload_1
    //   39: athrow
    // Exception table:
    //   from	to	target	type
    //   2	18	35	finally
    //   22	32	35	finally
  }
  
  public void execute(Runnable paramRunnable) {
    // Byte code:
    //   0: aload_0
    //   1: monitorenter
    //   2: aload_0
    //   3: getfield c : Ljava/util/ArrayDeque;
    //   6: new androidx/room/l$a
    //   9: dup
    //   10: aload_0
    //   11: aload_1
    //   12: invokespecial <init> : (Landroidx/room/l;Ljava/lang/Runnable;)V
    //   15: invokevirtual offer : (Ljava/lang/Object;)Z
    //   18: pop
    //   19: aload_0
    //   20: getfield d : Ljava/lang/Runnable;
    //   23: ifnonnull -> 30
    //   26: aload_0
    //   27: invokevirtual a : ()V
    //   30: aload_0
    //   31: monitorexit
    //   32: return
    //   33: astore_1
    //   34: aload_0
    //   35: monitorexit
    //   36: aload_1
    //   37: athrow
    // Exception table:
    //   from	to	target	type
    //   2	30	33	finally
  }
  
  class a implements Runnable {
    a(l this$0, Runnable param1Runnable) {}
    
    public void run() {
      try {
        this.b.run();
        return;
      } finally {
        this.c.a();
      } 
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Hill race-dex2jar.jar!\androidx\room\l.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */