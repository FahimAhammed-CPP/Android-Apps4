package androidx.room;

import java.io.File;
import m.c;

class k implements c.c {
  private final String a;
  
  private final File b;
  
  private final c.c c;
  
  k(String paramString, File paramFile, c.c paramc) {
    this.a = paramString;
    this.b = paramFile;
    this.c = paramc;
  }
  
  public c a(c.b paramb) {
    return new j(paramb.a, this.a, this.b, paramb.c.a, this.c.a(paramb));
  }
}


/* Location:              C:\soft\dex2jar-2.0\Hill race-dex2jar.jar!\androidx\room\k.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */