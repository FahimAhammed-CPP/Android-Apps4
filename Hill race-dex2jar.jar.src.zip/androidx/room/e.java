package androidx.room;

import android.annotation.SuppressLint;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteException;
import android.util.Log;
import java.util.Arrays;
import java.util.Collections;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.Locale;
import java.util.Map;
import java.util.Set;
import java.util.concurrent.atomic.AtomicBoolean;
import java.util.concurrent.locks.Lock;
import m.f;

public class e {
  private static final String[] m = new String[] { "UPDATE", "DELETE", "INSERT" };
  
  final HashMap<String, Integer> a;
  
  final String[] b;
  
  private Map<String, Set<String>> c;
  
  final h d;
  
  AtomicBoolean e;
  
  private volatile boolean f;
  
  volatile f g;
  
  private b h;
  
  private final d i;
  
  @SuppressLint({"RestrictedApi"})
  final c.b<c, d> j;
  
  private f k;
  
  Runnable l;
  
  public e(h paramh, Map<String, String> paramMap, Map<String, Set<String>> paramMap1, String... paramVarArgs) {
    int i = 0;
    this.e = new AtomicBoolean(false);
    this.f = false;
    this.j = new c.b();
    this.l = new a(this);
    this.d = paramh;
    this.h = new b(paramVarArgs.length);
    this.a = new HashMap<String, Integer>();
    this.c = paramMap1;
    this.i = new d(paramh);
    int j = paramVarArgs.length;
    this.b = new String[j];
    while (i < j) {
      String str1 = paramVarArgs[i];
      Locale locale = Locale.US;
      str1 = str1.toLowerCase(locale);
      this.a.put(str1, Integer.valueOf(i));
      String str2 = paramMap.get(paramVarArgs[i]);
      if (str2 != null) {
        this.b[i] = str2.toLowerCase(locale);
      } else {
        this.b[i] = str1;
      } 
      i++;
    } 
    for (Map.Entry<String, String> entry : paramMap.entrySet()) {
      String str = (String)entry.getValue();
      Locale locale = Locale.US;
      str = str.toLowerCase(locale);
      if (this.a.containsKey(str)) {
        String str1 = ((String)entry.getKey()).toLowerCase(locale);
        HashMap<String, Integer> hashMap = this.a;
        hashMap.put(str1, hashMap.get(str));
      } 
    } 
  }
  
  private static void b(StringBuilder paramStringBuilder, String paramString1, String paramString2) {
    paramStringBuilder.append("`");
    paramStringBuilder.append("room_table_modification_trigger_");
    paramStringBuilder.append(paramString1);
    paramStringBuilder.append("_");
    paramStringBuilder.append(paramString2);
    paramStringBuilder.append("`");
  }
  
  private String[] h(String[] paramArrayOfString) {
    HashSet<String> hashSet = new HashSet();
    int j = paramArrayOfString.length;
    for (int i = 0; i < j; i++) {
      String str1 = paramArrayOfString[i];
      String str2 = str1.toLowerCase(Locale.US);
      if (this.c.containsKey(str2)) {
        hashSet.addAll(this.c.get(str2));
      } else {
        hashSet.add(str1);
      } 
    } 
    return hashSet.<String>toArray(new String[hashSet.size()]);
  }
  
  private void j(m.b paramb, int paramInt) {
    StringBuilder stringBuilder1 = new StringBuilder();
    stringBuilder1.append("INSERT OR IGNORE INTO room_table_modification_log VALUES(");
    stringBuilder1.append(paramInt);
    stringBuilder1.append(", 0)");
    paramb.F(stringBuilder1.toString());
    String str = this.b[paramInt];
    StringBuilder stringBuilder2 = new StringBuilder();
    for (String str1 : m) {
      stringBuilder2.setLength(0);
      stringBuilder2.append("CREATE TEMP TRIGGER IF NOT EXISTS ");
      b(stringBuilder2, str, str1);
      stringBuilder2.append(" AFTER ");
      stringBuilder2.append(str1);
      stringBuilder2.append(" ON `");
      stringBuilder2.append(str);
      stringBuilder2.append("` BEGIN UPDATE ");
      stringBuilder2.append("room_table_modification_log");
      stringBuilder2.append(" SET ");
      stringBuilder2.append("invalidated");
      stringBuilder2.append(" = 1");
      stringBuilder2.append(" WHERE ");
      stringBuilder2.append("table_id");
      stringBuilder2.append(" = ");
      stringBuilder2.append(paramInt);
      stringBuilder2.append(" AND ");
      stringBuilder2.append("invalidated");
      stringBuilder2.append(" = 0");
      stringBuilder2.append("; END");
      paramb.F(stringBuilder2.toString());
    } 
  }
  
  private void k(m.b paramb, int paramInt) {
    String str = this.b[paramInt];
    StringBuilder stringBuilder = new StringBuilder();
    String[] arrayOfString = m;
    int i = arrayOfString.length;
    for (paramInt = 0; paramInt < i; paramInt++) {
      String str1 = arrayOfString[paramInt];
      stringBuilder.setLength(0);
      stringBuilder.append("DROP TRIGGER IF EXISTS ");
      b(stringBuilder, str, str1);
      paramb.F(stringBuilder.toString());
    } 
  }
  
  @SuppressLint({"RestrictedApi"})
  public void a(c paramc) {
    String[] arrayOfString = h(paramc.a);
    int[] arrayOfInt = new int[arrayOfString.length];
    int j = arrayOfString.length;
    int i = 0;
    while (i < j) {
      Integer integer = this.a.get(arrayOfString[i].toLowerCase(Locale.US));
      if (integer != null) {
        arrayOfInt[i] = integer.intValue();
        i++;
        continue;
      } 
      null = new StringBuilder();
      null.append("There is no table with name ");
      null.append(arrayOfString[i]);
      throw new IllegalArgumentException(null.toString());
    } 
    d d1 = new d((c)null, arrayOfInt, arrayOfString);
    synchronized (this.j) {
      d d2 = (d)this.j.i(null, d1);
      if (d2 == null && this.h.b(arrayOfInt))
        l(); 
      return;
    } 
  }
  
  boolean c() {
    if (!this.d.o())
      return false; 
    if (!this.f)
      this.d.i().V(); 
    if (!this.f) {
      Log.e("ROOM", "database is not initialized even though it is open");
      return false;
    } 
    return true;
  }
  
  void d(m.b paramb) {
    // Byte code:
    //   0: aload_0
    //   1: monitorenter
    //   2: aload_0
    //   3: getfield f : Z
    //   6: ifeq -> 22
    //   9: ldc_w 'ROOM'
    //   12: ldc_w 'Invalidation tracker is initialized twice :/.'
    //   15: invokestatic e : (Ljava/lang/String;Ljava/lang/String;)I
    //   18: pop
    //   19: aload_0
    //   20: monitorexit
    //   21: return
    //   22: aload_1
    //   23: ldc_w 'PRAGMA temp_store = MEMORY;'
    //   26: invokeinterface F : (Ljava/lang/String;)V
    //   31: aload_1
    //   32: ldc_w 'PRAGMA recursive_triggers='ON';'
    //   35: invokeinterface F : (Ljava/lang/String;)V
    //   40: aload_1
    //   41: ldc_w 'CREATE TEMP TABLE room_table_modification_log(table_id INTEGER PRIMARY KEY, invalidated INTEGER NOT NULL DEFAULT 0)'
    //   44: invokeinterface F : (Ljava/lang/String;)V
    //   49: aload_0
    //   50: aload_1
    //   51: invokevirtual m : (Lm/b;)V
    //   54: aload_0
    //   55: aload_1
    //   56: ldc_w 'UPDATE room_table_modification_log SET invalidated = 0 WHERE invalidated = 1 '
    //   59: invokeinterface K : (Ljava/lang/String;)Lm/f;
    //   64: putfield g : Lm/f;
    //   67: aload_0
    //   68: iconst_1
    //   69: putfield f : Z
    //   72: aload_0
    //   73: monitorexit
    //   74: return
    //   75: astore_1
    //   76: aload_0
    //   77: monitorexit
    //   78: aload_1
    //   79: athrow
    // Exception table:
    //   from	to	target	type
    //   2	21	75	finally
    //   22	74	75	finally
    //   76	78	75	finally
  }
  
  public void e(String... paramVarArgs) {
    synchronized (this.j) {
      for (Map.Entry entry : this.j) {
        if (!((c)entry.getKey()).a())
          ((d)entry.getValue()).b(paramVarArgs); 
      } 
      return;
    } 
  }
  
  public void f() {
    if (this.e.compareAndSet(false, true))
      this.d.j().execute(this.l); 
  }
  
  @SuppressLint({"RestrictedApi"})
  public void g(c paramc) {
    synchronized (this.j) {
      d d1 = (d)this.j.j(paramc);
      if (d1 != null && this.h.c(d1.a))
        l(); 
      return;
    } 
  }
  
  void i(Context paramContext, String paramString) {
    this.k = new f(paramContext, paramString, this, this.d.j());
  }
  
  void l() {
    if (!this.d.o())
      return; 
    m(this.d.i().V());
  }
  
  void m(m.b paramb) {
    if (paramb.f0())
      return; 
    label38: while (true) {
      try {
        Lock lock = this.d.h();
        lock.lock();
        try {
          int i;
          int[] arrayOfInt = this.h.a();
          if (arrayOfInt == null)
            return; 
          int j = arrayOfInt.length;
          paramb.D();
        } finally {
          lock.unlock();
        } 
        break;
      } catch (IllegalStateException illegalStateException) {
      
      } catch (SQLiteException sQLiteException) {}
      Log.e("ROOM", "Cannot run invalidation tracker. Is the db closed?", (Throwable)sQLiteException);
      return;
    } 
  }
  
  class a implements Runnable {
    a(e this$0) {}
    
    private Set<Integer> b() {
      null = new HashSet();
      Cursor cursor = this.b.d.p((m.e)new m.a("SELECT * FROM room_table_modification_log WHERE invalidated = 1;"));
      try {
        while (cursor.moveToNext())
          null.add(Integer.valueOf(cursor.getInt(0))); 
        cursor.close();
        return null;
      } finally {
        cursor.close();
      } 
    }
    
    public void run() {
      Lock lock = this.b.d.h();
      Set<Integer> set4 = null;
      Set<Integer> set5 = null;
      Set<Integer> set3 = null;
      Set<Integer> set2 = set4;
      Set<Integer> set1 = set5;
      try {
        lock.lock();
        set2 = set4;
        set1 = set5;
        boolean bool = this.b.c();
        if (!bool) {
          lock.unlock();
          return;
        } 
        set2 = set4;
        set1 = set5;
        bool = this.b.e.compareAndSet(true, false);
        if (!bool) {
          lock.unlock();
          return;
        } 
        set2 = set4;
        set1 = set5;
        bool = this.b.d.k();
        if (bool) {
          lock.unlock();
          return;
        } 
        set2 = set4;
        set1 = set5;
        h h = this.b.d;
        set2 = set4;
        set1 = set5;
        if (h.g) {
          set2 = set4;
          set1 = set5;
          m.b b = h.i().V();
          set2 = set4;
          set1 = set5;
          b.D();
          try {
            set4 = b();
            set3 = set4;
          } finally {
            set2 = set3;
            set1 = set3;
            b.Y();
            set2 = set3;
            set1 = set3;
          } 
        } else {
          set2 = set4;
          set1 = set5;
          set3 = b();
          set1 = set3;
        } 
      } catch (IllegalStateException illegalStateException) {
        Log.e("ROOM", "Cannot run invalidation tracker. Is the db closed?", illegalStateException);
      } catch (SQLiteException sQLiteException2) {
        IllegalStateException illegalStateException1 = illegalStateException;
        SQLiteException sQLiteException1 = sQLiteException2;
      } finally {}
      lock.unlock();
      if (set1 != null && !set1.isEmpty())
        synchronized (this.b.j) {
          Iterator<Map.Entry> iterator = this.b.j.iterator();
          while (iterator.hasNext())
            ((e.d)((Map.Entry)iterator.next()).getValue()).a(set1); 
          return;
        }  
    }
  }
  
  static class b {
    final long[] a;
    
    final boolean[] b;
    
    final int[] c;
    
    boolean d;
    
    boolean e;
    
    b(int param1Int) {
      long[] arrayOfLong = new long[param1Int];
      this.a = arrayOfLong;
      boolean[] arrayOfBoolean = new boolean[param1Int];
      this.b = arrayOfBoolean;
      this.c = new int[param1Int];
      Arrays.fill(arrayOfLong, 0L);
      Arrays.fill(arrayOfBoolean, false);
    }
    
    int[] a() {
      // Byte code:
      //   0: aload_0
      //   1: monitorenter
      //   2: aload_0
      //   3: getfield d : Z
      //   6: ifeq -> 111
      //   9: aload_0
      //   10: getfield e : Z
      //   13: ifeq -> 19
      //   16: goto -> 111
      //   19: aload_0
      //   20: getfield a : [J
      //   23: arraylength
      //   24: istore_3
      //   25: iconst_0
      //   26: istore_1
      //   27: iconst_1
      //   28: istore_2
      //   29: iload_1
      //   30: iload_3
      //   31: if_icmpge -> 90
      //   34: aload_0
      //   35: getfield a : [J
      //   38: iload_1
      //   39: laload
      //   40: lconst_0
      //   41: lcmp
      //   42: ifle -> 122
      //   45: iconst_1
      //   46: istore #4
      //   48: goto -> 51
      //   51: aload_0
      //   52: getfield b : [Z
      //   55: astore #5
      //   57: iload #4
      //   59: aload #5
      //   61: iload_1
      //   62: baload
      //   63: if_icmpeq -> 80
      //   66: aload_0
      //   67: getfield c : [I
      //   70: astore #6
      //   72: iload #4
      //   74: ifeq -> 128
      //   77: goto -> 130
      //   80: aload_0
      //   81: getfield c : [I
      //   84: iload_1
      //   85: iconst_0
      //   86: iastore
      //   87: goto -> 135
      //   90: aload_0
      //   91: iconst_1
      //   92: putfield e : Z
      //   95: aload_0
      //   96: iconst_0
      //   97: putfield d : Z
      //   100: aload_0
      //   101: getfield c : [I
      //   104: astore #5
      //   106: aload_0
      //   107: monitorexit
      //   108: aload #5
      //   110: areturn
      //   111: aload_0
      //   112: monitorexit
      //   113: aconst_null
      //   114: areturn
      //   115: astore #5
      //   117: aload_0
      //   118: monitorexit
      //   119: aload #5
      //   121: athrow
      //   122: iconst_0
      //   123: istore #4
      //   125: goto -> 51
      //   128: iconst_2
      //   129: istore_2
      //   130: aload #6
      //   132: iload_1
      //   133: iload_2
      //   134: iastore
      //   135: aload #5
      //   137: iload_1
      //   138: iload #4
      //   140: bastore
      //   141: iload_1
      //   142: iconst_1
      //   143: iadd
      //   144: istore_1
      //   145: goto -> 27
      // Exception table:
      //   from	to	target	type
      //   2	16	115	finally
      //   19	25	115	finally
      //   34	45	115	finally
      //   51	57	115	finally
      //   66	72	115	finally
      //   80	87	115	finally
      //   90	108	115	finally
      //   111	113	115	finally
      //   117	119	115	finally
    }
    
    boolean b(int... param1VarArgs) {
      // Byte code:
      //   0: aload_0
      //   1: monitorenter
      //   2: aload_1
      //   3: arraylength
      //   4: istore_3
      //   5: iconst_0
      //   6: istore_2
      //   7: iconst_0
      //   8: istore #5
      //   10: iload_2
      //   11: iload_3
      //   12: if_icmpge -> 60
      //   15: aload_1
      //   16: iload_2
      //   17: iaload
      //   18: istore #4
      //   20: aload_0
      //   21: getfield a : [J
      //   24: astore #8
      //   26: aload #8
      //   28: iload #4
      //   30: laload
      //   31: lstore #6
      //   33: aload #8
      //   35: iload #4
      //   37: lconst_1
      //   38: lload #6
      //   40: ladd
      //   41: lastore
      //   42: lload #6
      //   44: lconst_0
      //   45: lcmp
      //   46: ifne -> 70
      //   49: aload_0
      //   50: iconst_1
      //   51: putfield d : Z
      //   54: iconst_1
      //   55: istore #5
      //   57: goto -> 70
      //   60: aload_0
      //   61: monitorexit
      //   62: iload #5
      //   64: ireturn
      //   65: astore_1
      //   66: aload_0
      //   67: monitorexit
      //   68: aload_1
      //   69: athrow
      //   70: iload_2
      //   71: iconst_1
      //   72: iadd
      //   73: istore_2
      //   74: goto -> 10
      // Exception table:
      //   from	to	target	type
      //   2	5	65	finally
      //   20	26	65	finally
      //   49	54	65	finally
      //   60	62	65	finally
      //   66	68	65	finally
    }
    
    boolean c(int... param1VarArgs) {
      // Byte code:
      //   0: aload_0
      //   1: monitorenter
      //   2: aload_1
      //   3: arraylength
      //   4: istore_3
      //   5: iconst_0
      //   6: istore_2
      //   7: iconst_0
      //   8: istore #5
      //   10: iload_2
      //   11: iload_3
      //   12: if_icmpge -> 60
      //   15: aload_1
      //   16: iload_2
      //   17: iaload
      //   18: istore #4
      //   20: aload_0
      //   21: getfield a : [J
      //   24: astore #8
      //   26: aload #8
      //   28: iload #4
      //   30: laload
      //   31: lstore #6
      //   33: aload #8
      //   35: iload #4
      //   37: lload #6
      //   39: lconst_1
      //   40: lsub
      //   41: lastore
      //   42: lload #6
      //   44: lconst_1
      //   45: lcmp
      //   46: ifne -> 70
      //   49: aload_0
      //   50: iconst_1
      //   51: putfield d : Z
      //   54: iconst_1
      //   55: istore #5
      //   57: goto -> 70
      //   60: aload_0
      //   61: monitorexit
      //   62: iload #5
      //   64: ireturn
      //   65: astore_1
      //   66: aload_0
      //   67: monitorexit
      //   68: aload_1
      //   69: athrow
      //   70: iload_2
      //   71: iconst_1
      //   72: iadd
      //   73: istore_2
      //   74: goto -> 10
      // Exception table:
      //   from	to	target	type
      //   2	5	65	finally
      //   20	26	65	finally
      //   49	54	65	finally
      //   60	62	65	finally
      //   66	68	65	finally
    }
    
    void d() {
      // Byte code:
      //   0: aload_0
      //   1: monitorenter
      //   2: aload_0
      //   3: iconst_0
      //   4: putfield e : Z
      //   7: aload_0
      //   8: monitorexit
      //   9: return
      //   10: astore_1
      //   11: aload_0
      //   12: monitorexit
      //   13: aload_1
      //   14: athrow
      // Exception table:
      //   from	to	target	type
      //   2	9	10	finally
      //   11	13	10	finally
    }
  }
  
  public static abstract class c {
    final String[] a;
    
    public c(String[] param1ArrayOfString) {
      this.a = Arrays.<String>copyOf(param1ArrayOfString, param1ArrayOfString.length);
    }
    
    boolean a() {
      return false;
    }
    
    public abstract void b(Set<String> param1Set);
  }
  
  static class d {
    final int[] a;
    
    private final String[] b;
    
    final e.c c;
    
    private final Set<String> d;
    
    d(e.c param1c, int[] param1ArrayOfint, String[] param1ArrayOfString) {
      this.c = param1c;
      this.a = param1ArrayOfint;
      this.b = param1ArrayOfString;
      if (param1ArrayOfint.length == 1) {
        HashSet<String> hashSet = new HashSet();
        hashSet.add(param1ArrayOfString[0]);
        this.d = Collections.unmodifiableSet(hashSet);
        return;
      } 
      this.d = null;
    }
    
    void a(Set<Integer> param1Set) {
      int j = this.a.length;
      Set<String> set = null;
      int i = 0;
      while (i < j) {
        Set<String> set1 = set;
        if (param1Set.contains(Integer.valueOf(this.a[i])))
          if (j == 1) {
            set1 = this.d;
          } else {
            set1 = set;
            if (set == null)
              set1 = new HashSet<String>(j); 
            set1.add(this.b[i]);
          }  
        i++;
        set = set1;
      } 
      if (set != null)
        this.c.b(set); 
    }
    
    void b(String[] param1ArrayOfString) {
      Set<String> set1;
      int i = this.b.length;
      Set<String> set2 = null;
      if (i == 1) {
        int j = param1ArrayOfString.length;
        i = 0;
        while (true) {
          set1 = set2;
          if (i < j) {
            if (param1ArrayOfString[i].equalsIgnoreCase(this.b[0])) {
              set1 = this.d;
              break;
            } 
            i++;
            continue;
          } 
          break;
        } 
      } else {
        HashSet<String> hashSet = new HashSet();
        int j = param1ArrayOfString.length;
        for (i = 0; i < j; i++) {
          String str = param1ArrayOfString[i];
          for (String str1 : this.b) {
            if (str1.equalsIgnoreCase(str)) {
              hashSet.add(str1);
              break;
            } 
          } 
        } 
        set1 = set2;
        if (hashSet.size() > 0)
          set1 = hashSet; 
      } 
      if (set1 != null)
        this.c.b(set1); 
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Hill race-dex2jar.jar!\androidx\room\e.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */