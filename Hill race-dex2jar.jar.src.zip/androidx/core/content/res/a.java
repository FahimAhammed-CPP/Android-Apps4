package androidx.core.content.res;

class a {
  private final float a;
  
  private final float b;
  
  private final float c;
  
  private final float d;
  
  private final float e;
  
  private final float f;
  
  private final float g;
  
  private final float h;
  
  private final float i;
  
  a(float paramFloat1, float paramFloat2, float paramFloat3, float paramFloat4, float paramFloat5, float paramFloat6, float paramFloat7, float paramFloat8, float paramFloat9) {
    this.a = paramFloat1;
    this.b = paramFloat2;
    this.c = paramFloat3;
    this.d = paramFloat4;
    this.e = paramFloat5;
    this.f = paramFloat6;
    this.g = paramFloat7;
    this.h = paramFloat8;
    this.i = paramFloat9;
  }
  
  private static a b(float paramFloat1, float paramFloat2, float paramFloat3) {
    float f4 = 1000.0F;
    a a1 = null;
    float f3 = 1000.0F;
    float f2 = 100.0F;
    float f1 = 0.0F;
    while (Math.abs(f1 - f2) > 0.01F) {
      float f6 = (f2 - f1) / 2.0F + f1;
      int i = e(f6, paramFloat2, paramFloat1).p();
      float f9 = b.b(i);
      float f8 = Math.abs(paramFloat3 - f9);
      float f7 = f4;
      float f5 = f3;
      a a2 = a1;
      if (f8 < 0.2F) {
        a a3 = c(i);
        float f = a3.a(e(a3.k(), a3.i(), paramFloat1));
        f7 = f4;
        f5 = f3;
        a2 = a1;
        if (f <= 1.0F) {
          a2 = a3;
          f7 = f8;
          f5 = f;
        } 
      } 
      if (f7 == 0.0F && f5 == 0.0F)
        return a2; 
      if (f9 < paramFloat3) {
        f1 = f6;
        f4 = f7;
        f3 = f5;
        a1 = a2;
        continue;
      } 
      f2 = f6;
      f4 = f7;
      f3 = f5;
      a1 = a2;
    } 
    return a1;
  }
  
  static a c(int paramInt) {
    return d(paramInt, f.k);
  }
  
  static a d(int paramInt, f paramf) {
    float[] arrayOfFloat = b.f(paramInt);
    float[][] arrayOfFloat1 = b.a;
    float f13 = arrayOfFloat[0];
    float f14 = arrayOfFloat1[0][0];
    float f15 = arrayOfFloat[1];
    float f16 = arrayOfFloat1[0][1];
    float f17 = arrayOfFloat[2];
    float f18 = arrayOfFloat1[0][2];
    float f7 = arrayOfFloat[0];
    float f8 = arrayOfFloat1[1][0];
    float f9 = arrayOfFloat[1];
    float f10 = arrayOfFloat1[1][1];
    float f11 = arrayOfFloat[2];
    float f12 = arrayOfFloat1[1][2];
    float f1 = arrayOfFloat[0];
    float f2 = arrayOfFloat1[2][0];
    float f3 = arrayOfFloat[1];
    float f4 = arrayOfFloat1[2][1];
    float f5 = arrayOfFloat[2];
    float f6 = arrayOfFloat1[2][2];
    f13 = paramf.i()[0] * (f13 * f14 + f15 * f16 + f17 * f18);
    f7 = paramf.i()[1] * (f7 * f8 + f9 * f10 + f11 * f12);
    f2 = paramf.i()[2] * (f1 * f2 + f3 * f4 + f5 * f6);
    f1 = (float)Math.pow((paramf.c() * Math.abs(f13)) / 100.0D, 0.42D);
    f4 = (float)Math.pow((paramf.c() * Math.abs(f7)) / 100.0D, 0.42D);
    f3 = (float)Math.pow((paramf.c() * Math.abs(f2)) / 100.0D, 0.42D);
    f1 = Math.signum(f13) * 400.0F * f1 / (f1 + 27.13F);
    f5 = Math.signum(f7) * 400.0F * f4 / (f4 + 27.13F);
    f2 = Math.signum(f2) * 400.0F * f3 / (f3 + 27.13F);
    double d1 = f1;
    double d2 = f5;
    double d3 = f2;
    f3 = (float)(d1 * 11.0D + d2 * -12.0D + d3) / 11.0F;
    f4 = (float)((f1 + f5) - d3 * 2.0D) / 9.0F;
    f5 *= 20.0F;
    f6 = (f1 * 20.0F + f5 + 21.0F * f2) / 20.0F;
    f7 = (f1 * 40.0F + f5 + f2) / 20.0F;
    f2 = (float)Math.atan2(f4, f3) * 180.0F / 3.1415927F;
    if (f2 < 0.0F) {
      f1 = f2 + 360.0F;
    } else {
      f1 = f2;
      if (f2 >= 360.0F)
        f1 = f2 - 360.0F; 
    } 
    f5 = 3.1415927F * f1 / 180.0F;
    f7 = (float)Math.pow((f7 * paramf.f() / paramf.a()), (paramf.b() * paramf.j())) * 100.0F;
    f8 = 4.0F / paramf.b();
    f9 = (float)Math.sqrt((f7 / 100.0F));
    f10 = paramf.a();
    f11 = paramf.d();
    if (f1 < 20.14D) {
      f2 = 360.0F + f1;
    } else {
      f2 = f1;
    } 
    f2 = (float)(Math.cos(f2 * Math.PI / 180.0D + 2.0D) + 3.8D) * 0.25F * 3846.1538F * paramf.g() * paramf.h() * (float)Math.sqrt((f3 * f3 + f4 * f4)) / (f6 + 0.305F);
    f4 = (float)Math.pow(1.64D - Math.pow(0.29D, paramf.e()), 0.73D) * (float)Math.pow(f2, 0.9D);
    f2 = f4 * (float)Math.sqrt(f7 / 100.0D);
    f3 = f2 * paramf.d();
    f4 = (float)Math.sqrt((f4 * paramf.b() / (paramf.a() + 4.0F)));
    f6 = 1.7F * f7 / (0.007F * f7 + 1.0F);
    f12 = (float)Math.log((0.0228F * f3 + 1.0F)) * 43.85965F;
    d1 = f5;
    return new a(f1, f2, f7, f11 * f8 * f9 * (f10 + 4.0F), f3, f4 * 50.0F, f6, f12 * (float)Math.cos(d1), f12 * (float)Math.sin(d1));
  }
  
  private static a e(float paramFloat1, float paramFloat2, float paramFloat3) {
    return f(paramFloat1, paramFloat2, paramFloat3, f.k);
  }
  
  private static a f(float paramFloat1, float paramFloat2, float paramFloat3, f paramf) {
    float f1 = 4.0F / paramf.b();
    double d = paramFloat1 / 100.0D;
    float f2 = (float)Math.sqrt(d);
    float f3 = paramf.a();
    float f4 = paramf.d();
    float f5 = paramFloat2 * paramf.d();
    float f6 = (float)Math.sqrt((paramFloat2 / (float)Math.sqrt(d) * paramf.b() / (paramf.a() + 4.0F)));
    float f7 = 3.1415927F * paramFloat3 / 180.0F;
    float f8 = 1.7F * paramFloat1 / (0.007F * paramFloat1 + 1.0F);
    float f9 = (float)Math.log(f5 * 0.0228D + 1.0D) * 43.85965F;
    d = f7;
    return new a(paramFloat3, paramFloat2, paramFloat1, f1 * f2 * (f3 + 4.0F) * f4, f5, f6 * 50.0F, f8, f9 * (float)Math.cos(d), f9 * (float)Math.sin(d));
  }
  
  static int m(float paramFloat1, float paramFloat2, float paramFloat3) {
    return n(paramFloat1, paramFloat2, paramFloat3, f.k);
  }
  
  static int n(float paramFloat1, float paramFloat2, float paramFloat3, f paramf) {
    float f1;
    if (paramFloat2 < 1.0D || Math.round(paramFloat3) <= 0.0D || Math.round(paramFloat3) >= 100.0D)
      return b.a(paramFloat3); 
    if (paramFloat1 < 0.0F) {
      f1 = 0.0F;
    } else {
      f1 = Math.min(360.0F, paramFloat1);
    } 
    paramFloat1 = paramFloat2;
    a a1 = null;
    float f2 = 0.0F;
    boolean bool = true;
    while (Math.abs(f2 - paramFloat2) >= 0.4F) {
      a a2 = b(f1, paramFloat1, paramFloat3);
      if (bool) {
        if (a2 != null)
          return a2.o(paramf); 
        bool = false;
      } else if (a2 == null) {
        paramFloat2 = paramFloat1;
      } else {
        a1 = a2;
        f2 = paramFloat1;
      } 
      paramFloat1 = (paramFloat2 - f2) / 2.0F + f2;
    } 
    return (a1 == null) ? b.a(paramFloat3) : a1.o(paramf);
  }
  
  float a(a parama) {
    float f1 = l() - parama.l();
    float f2 = g() - parama.g();
    float f3 = h() - parama.h();
    return (float)(Math.pow(Math.sqrt((f1 * f1 + f2 * f2 + f3 * f3)), 0.63D) * 1.41D);
  }
  
  float g() {
    return this.h;
  }
  
  float h() {
    return this.i;
  }
  
  float i() {
    return this.b;
  }
  
  float j() {
    return this.a;
  }
  
  float k() {
    return this.c;
  }
  
  float l() {
    return this.g;
  }
  
  int o(f paramf) {
    if (i() == 0.0D || k() == 0.0D) {
      float f13 = 0.0F;
      float f14 = (float)Math.pow(f13 / Math.pow(1.64D - Math.pow(0.29D, paramf.e()), 0.73D), 1.1111111111111112D);
      double d1 = (j() * 3.1415927F / 180.0F);
      float f15 = (float)(Math.cos(2.0D + d1) + 3.8D);
      f13 = paramf.a();
      float f18 = (float)Math.pow(k() / 100.0D, 1.0D / paramf.b() / paramf.j());
      float f16 = paramf.g();
      float f17 = paramf.h();
      f13 = f13 * f18 / paramf.f();
      f18 = (float)Math.sin(d1);
      float f19 = (float)Math.cos(d1);
      f15 = (0.305F + f13) * 23.0F * f14 / (f15 * 0.25F * 3846.1538F * f16 * f17 * 23.0F + 11.0F * f14 * f19 + f14 * 108.0F * f18);
      f14 = f19 * f15;
      f15 *= f18;
      f17 = f13 * 460.0F;
      f13 = (451.0F * f14 + f17 + 288.0F * f15) / 1403.0F;
      f16 = (f17 - 891.0F * f14 - 261.0F * f15) / 1403.0F;
      f18 = (f17 - f14 * 220.0F - f15 * 6300.0F) / 1403.0F;
      f15 = (float)Math.max(0.0D, Math.abs(f13) * 27.13D / (400.0D - Math.abs(f13)));
      f13 = Math.signum(f13);
      f14 = 100.0F / paramf.c();
      f15 = (float)Math.pow(f15, 2.380952380952381D);
      f19 = (float)Math.max(0.0D, Math.abs(f16) * 27.13D / (400.0D - Math.abs(f16)));
      f16 = Math.signum(f16);
      f17 = 100.0F / paramf.c();
      f19 = (float)Math.pow(f19, 2.380952380952381D);
      float f21 = (float)Math.max(0.0D, Math.abs(f18) * 27.13D / (400.0D - Math.abs(f18)));
      f18 = Math.signum(f18);
      float f20 = 100.0F / paramf.c();
      f21 = (float)Math.pow(f21, 2.380952380952381D);
      f13 = f13 * f14 * f15 / paramf.i()[0];
      f14 = f16 * f17 * f19 / paramf.i()[1];
      f15 = f18 * f20 * f21 / paramf.i()[2];
      arrayOfFloat = b.b;
      f16 = arrayOfFloat[0][0];
      f17 = arrayOfFloat[0][1];
      f18 = arrayOfFloat[0][2];
      f19 = arrayOfFloat[1][0];
      f20 = arrayOfFloat[1][1];
      f21 = arrayOfFloat[1][2];
      float f22 = arrayOfFloat[2][0];
      float f23 = arrayOfFloat[2][1];
      float f24 = arrayOfFloat[2][2];
      return androidx.core.graphics.a.a((f16 * f13 + f17 * f14 + f18 * f15), (f19 * f13 + f20 * f14 + f21 * f15), (f13 * f22 + f14 * f23 + f15 * f24));
    } 
    float f1 = i() / (float)Math.sqrt(k() / 100.0D);
    float f2 = (float)Math.pow(f1 / Math.pow(1.64D - Math.pow(0.29D, arrayOfFloat.e()), 0.73D), 1.1111111111111112D);
    double d = (j() * 3.1415927F / 180.0F);
    float f3 = (float)(Math.cos(2.0D + d) + 3.8D);
    f1 = arrayOfFloat.a();
    float f6 = (float)Math.pow(k() / 100.0D, 1.0D / arrayOfFloat.b() / arrayOfFloat.j());
    float f4 = arrayOfFloat.g();
    float f5 = arrayOfFloat.h();
    f1 = f1 * f6 / arrayOfFloat.f();
    f6 = (float)Math.sin(d);
    float f7 = (float)Math.cos(d);
    f3 = (0.305F + f1) * 23.0F * f2 / (f3 * 0.25F * 3846.1538F * f4 * f5 * 23.0F + 11.0F * f2 * f7 + f2 * 108.0F * f6);
    f2 = f7 * f3;
    f3 *= f6;
    f5 = f1 * 460.0F;
    f1 = (451.0F * f2 + f5 + 288.0F * f3) / 1403.0F;
    f4 = (f5 - 891.0F * f2 - 261.0F * f3) / 1403.0F;
    f6 = (f5 - f2 * 220.0F - f3 * 6300.0F) / 1403.0F;
    f3 = (float)Math.max(0.0D, Math.abs(f1) * 27.13D / (400.0D - Math.abs(f1)));
    f1 = Math.signum(f1);
    f2 = 100.0F / arrayOfFloat.c();
    f3 = (float)Math.pow(f3, 2.380952380952381D);
    f7 = (float)Math.max(0.0D, Math.abs(f4) * 27.13D / (400.0D - Math.abs(f4)));
    f4 = Math.signum(f4);
    f5 = 100.0F / arrayOfFloat.c();
    f7 = (float)Math.pow(f7, 2.380952380952381D);
    float f9 = (float)Math.max(0.0D, Math.abs(f6) * 27.13D / (400.0D - Math.abs(f6)));
    f6 = Math.signum(f6);
    float f8 = 100.0F / arrayOfFloat.c();
    f9 = (float)Math.pow(f9, 2.380952380952381D);
    f1 = f1 * f2 * f3 / arrayOfFloat.i()[0];
    f2 = f4 * f5 * f7 / arrayOfFloat.i()[1];
    f3 = f6 * f8 * f9 / arrayOfFloat.i()[2];
    float[][] arrayOfFloat = b.b;
    f4 = arrayOfFloat[0][0];
    f5 = arrayOfFloat[0][1];
    f6 = arrayOfFloat[0][2];
    f7 = arrayOfFloat[1][0];
    f8 = arrayOfFloat[1][1];
    f9 = arrayOfFloat[1][2];
    float f10 = arrayOfFloat[2][0];
    float f11 = arrayOfFloat[2][1];
    float f12 = arrayOfFloat[2][2];
    return androidx.core.graphics.a.a((f4 * f1 + f5 * f2 + f6 * f3), (f7 * f1 + f8 * f2 + f9 * f3), (f1 * f10 + f2 * f11 + f3 * f12));
  }
  
  int p() {
    return o(f.k);
  }
}


/* Location:              C:\soft\dex2jar-2.0\Hill race-dex2jar.jar!\androidx\core\content\res\a.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */