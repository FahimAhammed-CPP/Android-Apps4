package androidx.core.content.res;

import android.content.res.ColorStateList;
import android.content.res.Configuration;
import android.content.res.Resources;
import android.content.res.XmlResourceParser;
import android.graphics.drawable.Drawable;
import android.os.Build;
import android.util.Log;
import android.util.SparseArray;
import android.util.TypedValue;
import java.util.WeakHashMap;
import org.xmlpull.v1.XmlPullParser;

public final class e {
  private static final ThreadLocal<TypedValue> a = new ThreadLocal<TypedValue>();
  
  private static final WeakHashMap<d, SparseArray<c>> b = new WeakHashMap<d, SparseArray<c>>(0);
  
  private static final Object c = new Object();
  
  private static void a(d paramd, int paramInt, ColorStateList paramColorStateList, Resources.Theme paramTheme) {
    synchronized (c) {
      WeakHashMap<d, SparseArray<c>> weakHashMap = b;
      SparseArray<c> sparseArray2 = weakHashMap.get(paramd);
      SparseArray<c> sparseArray1 = sparseArray2;
      if (sparseArray2 == null) {
        sparseArray1 = new SparseArray();
        weakHashMap.put(paramd, sparseArray1);
      } 
      sparseArray1.append(paramInt, new c(paramColorStateList, paramd.a.getConfiguration(), paramTheme));
      return;
    } 
  }
  
  private static ColorStateList b(d paramd, int paramInt) {
    synchronized (c) {
      SparseArray sparseArray = b.get(paramd);
      if (sparseArray != null && sparseArray.size() > 0) {
        c c = (c)sparseArray.get(paramInt);
        if (c != null) {
          if (c.b.equals(paramd.a.getConfiguration())) {
            Resources.Theme theme = paramd.b;
            if ((theme == null && c.c == 0) || (theme != null && c.c == theme.hashCode()))
              return c.a; 
          } 
          sparseArray.remove(paramInt);
        } 
      } 
      return null;
    } 
  }
  
  public static ColorStateList c(Resources paramResources, int paramInt, Resources.Theme paramTheme) throws Resources.NotFoundException {
    d d = new d(paramResources, paramTheme);
    ColorStateList colorStateList = b(d, paramInt);
    if (colorStateList != null)
      return colorStateList; 
    colorStateList = f(paramResources, paramInt, paramTheme);
    if (colorStateList != null) {
      a(d, paramInt, colorStateList, paramTheme);
      return colorStateList;
    } 
    return (Build.VERSION.SDK_INT >= 23) ? b.b(paramResources, paramInt, paramTheme) : paramResources.getColorStateList(paramInt);
  }
  
  public static Drawable d(Resources paramResources, int paramInt, Resources.Theme paramTheme) throws Resources.NotFoundException {
    return (Build.VERSION.SDK_INT >= 21) ? a.a(paramResources, paramInt, paramTheme) : paramResources.getDrawable(paramInt);
  }
  
  private static TypedValue e() {
    ThreadLocal<TypedValue> threadLocal = a;
    TypedValue typedValue2 = threadLocal.get();
    TypedValue typedValue1 = typedValue2;
    if (typedValue2 == null) {
      typedValue1 = new TypedValue();
      threadLocal.set(typedValue1);
    } 
    return typedValue1;
  }
  
  private static ColorStateList f(Resources paramResources, int paramInt, Resources.Theme paramTheme) {
    if (g(paramResources, paramInt))
      return null; 
    XmlResourceParser xmlResourceParser = paramResources.getXml(paramInt);
    try {
      return c.a(paramResources, (XmlPullParser)xmlResourceParser, paramTheme);
    } catch (Exception exception) {
      Log.w("ResourcesCompat", "Failed to inflate ColorStateList, leaving it to the framework", exception);
      return null;
    } 
  }
  
  private static boolean g(Resources paramResources, int paramInt) {
    TypedValue typedValue = e();
    paramResources.getValue(paramInt, typedValue, true);
    paramInt = typedValue.type;
    return (paramInt >= 28 && paramInt <= 31);
  }
  
  static class a {
    static Drawable a(Resources param1Resources, int param1Int, Resources.Theme param1Theme) {
      return param1Resources.getDrawable(param1Int, param1Theme);
    }
    
    static Drawable b(Resources param1Resources, int param1Int1, int param1Int2, Resources.Theme param1Theme) {
      return param1Resources.getDrawableForDensity(param1Int1, param1Int2, param1Theme);
    }
  }
  
  static class b {
    static int a(Resources param1Resources, int param1Int, Resources.Theme param1Theme) {
      return param1Resources.getColor(param1Int, param1Theme);
    }
    
    static ColorStateList b(Resources param1Resources, int param1Int, Resources.Theme param1Theme) {
      return param1Resources.getColorStateList(param1Int, param1Theme);
    }
  }
  
  private static class c {
    final ColorStateList a;
    
    final Configuration b;
    
    final int c;
    
    c(ColorStateList param1ColorStateList, Configuration param1Configuration, Resources.Theme param1Theme) {
      int i;
      this.a = param1ColorStateList;
      this.b = param1Configuration;
      if (param1Theme == null) {
        i = 0;
      } else {
        i = param1Theme.hashCode();
      } 
      this.c = i;
    }
  }
  
  private static final class d {
    final Resources a;
    
    final Resources.Theme b;
    
    d(Resources param1Resources, Resources.Theme param1Theme) {
      this.a = param1Resources;
      this.b = param1Theme;
    }
    
    public boolean equals(Object param1Object) {
      if (this == param1Object)
        return true; 
      if (param1Object != null) {
        if (d.class != param1Object.getClass())
          return false; 
        param1Object = param1Object;
        return (this.a.equals(((d)param1Object).a) && androidx.core.util.d.a(this.b, ((d)param1Object).b));
      } 
      return false;
    }
    
    public int hashCode() {
      return androidx.core.util.d.b(new Object[] { this.a, this.b });
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Hill race-dex2jar.jar!\androidx\core\content\res\e.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */