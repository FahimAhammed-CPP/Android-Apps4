package androidx.core.os;

import android.annotation.SuppressLint;
import android.os.Build;
import java.util.Locale;

public class a {
  protected static boolean a(String paramString1, String paramString2) {
    boolean bool1 = "REL".equals(paramString2);
    boolean bool = false;
    if (bool1)
      return false; 
    Locale locale = Locale.ROOT;
    if (paramString2.toUpperCase(locale).compareTo(paramString1.toUpperCase(locale)) >= 0)
      bool = true; 
    return bool;
  }
  
  @Deprecated
  @SuppressLint({"RestrictedApi"})
  public static boolean b() {
    int i = Build.VERSION.SDK_INT;
    return (i >= 31 || (i >= 30 && a("S", Build.VERSION.CODENAME)));
  }
  
  public static boolean c() {
    int i = Build.VERSION.SDK_INT;
    return (i >= 33 || (i >= 32 && a("Tiramisu", Build.VERSION.CODENAME)));
  }
  
  public static boolean d() {
    return (Build.VERSION.SDK_INT >= 33 && a("UpsideDownCake", Build.VERSION.CODENAME));
  }
}


/* Location:              C:\soft\dex2jar-2.0\Hill race-dex2jar.jar!\androidx\core\os\a.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */