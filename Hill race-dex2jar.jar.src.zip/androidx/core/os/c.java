package androidx.core.os;

import android.os.Handler;
import androidx.core.util.f;
import java.util.concurrent.Executor;
import java.util.concurrent.RejectedExecutionException;

public final class c {
  public static Executor a(Handler paramHandler) {
    return new a(paramHandler);
  }
  
  private static class a implements Executor {
    private final Handler b;
    
    a(Handler param1Handler) {
      this.b = (Handler)f.a(param1Handler);
    }
    
    public void execute(Runnable param1Runnable) {
      if (this.b.post((Runnable)f.a(param1Runnable)))
        return; 
      StringBuilder stringBuilder = new StringBuilder();
      stringBuilder.append(this.b);
      stringBuilder.append(" is shutting down");
      throw new RejectedExecutionException(stringBuilder.toString());
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Hill race-dex2jar.jar!\androidx\core\os\c.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */