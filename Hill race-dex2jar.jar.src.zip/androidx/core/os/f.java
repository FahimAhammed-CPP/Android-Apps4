package androidx.core.os;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.Locale;

final class f implements g {
  private static final Locale[] c = new Locale[0];
  
  private static final Locale d = new Locale("en", "XA");
  
  private static final Locale e = new Locale("ar", "XB");
  
  private static final Locale f = e.b("en-Latn");
  
  private final Locale[] a;
  
  private final String b;
  
  f(Locale... paramVarArgs) {
    if (paramVarArgs.length == 0) {
      this.a = c;
      this.b = "";
      return;
    } 
    ArrayList<Locale> arrayList = new ArrayList();
    HashSet<Locale> hashSet = new HashSet();
    StringBuilder stringBuilder = new StringBuilder();
    int i = 0;
    while (i < paramVarArgs.length) {
      Locale locale = paramVarArgs[i];
      if (locale != null) {
        if (!hashSet.contains(locale)) {
          locale = (Locale)locale.clone();
          arrayList.add(locale);
          b(stringBuilder, locale);
          if (i < paramVarArgs.length - 1)
            stringBuilder.append(','); 
          hashSet.add(locale);
        } 
        i++;
        continue;
      } 
      StringBuilder stringBuilder1 = new StringBuilder();
      stringBuilder1.append("list[");
      stringBuilder1.append(i);
      stringBuilder1.append("] is null");
      throw new NullPointerException(stringBuilder1.toString());
    } 
    this.a = arrayList.<Locale>toArray(new Locale[0]);
    this.b = stringBuilder.toString();
  }
  
  static void b(StringBuilder paramStringBuilder, Locale paramLocale) {
    paramStringBuilder.append(paramLocale.getLanguage());
    String str = paramLocale.getCountry();
    if (str != null && !str.isEmpty()) {
      paramStringBuilder.append('-');
      paramStringBuilder.append(paramLocale.getCountry());
    } 
  }
  
  public Object a() {
    return null;
  }
  
  public boolean equals(Object paramObject) {
    if (paramObject == this)
      return true; 
    if (!(paramObject instanceof f))
      return false; 
    paramObject = ((f)paramObject).a;
    if (this.a.length != paramObject.length)
      return false; 
    int i = 0;
    while (true) {
      Locale[] arrayOfLocale = this.a;
      if (i < arrayOfLocale.length) {
        if (!arrayOfLocale[i].equals(paramObject[i]))
          return false; 
        i++;
        continue;
      } 
      return true;
    } 
  }
  
  public Locale get(int paramInt) {
    if (paramInt >= 0) {
      Locale[] arrayOfLocale = this.a;
      if (paramInt < arrayOfLocale.length)
        return arrayOfLocale[paramInt]; 
    } 
    return null;
  }
  
  public int hashCode() {
    Locale[] arrayOfLocale = this.a;
    int k = arrayOfLocale.length;
    int j = 1;
    for (int i = 0; i < k; i++)
      j = j * 31 + arrayOfLocale[i].hashCode(); 
    return j;
  }
  
  public String toString() {
    StringBuilder stringBuilder = new StringBuilder();
    stringBuilder.append("[");
    int i = 0;
    while (true) {
      Locale[] arrayOfLocale = this.a;
      if (i < arrayOfLocale.length) {
        stringBuilder.append(arrayOfLocale[i]);
        if (i < this.a.length - 1)
          stringBuilder.append(','); 
        i++;
        continue;
      } 
      stringBuilder.append("]");
      return stringBuilder.toString();
    } 
  }
}


/* Location:              C:\soft\dex2jar-2.0\Hill race-dex2jar.jar!\androidx\core\os\f.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */