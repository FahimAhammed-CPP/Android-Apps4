package androidx.core.os;

import android.content.res.Configuration;
import android.os.Build;
import android.os.LocaleList;
import java.util.Locale;

public final class b {
  public static e a(Configuration paramConfiguration) {
    return (Build.VERSION.SDK_INT >= 24) ? e.d(a.a(paramConfiguration)) : e.a(new Locale[] { paramConfiguration.locale });
  }
  
  static class a {
    static LocaleList a(Configuration param1Configuration) {
      return param1Configuration.getLocales();
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Hill race-dex2jar.jar!\androidx\core\os\b.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */