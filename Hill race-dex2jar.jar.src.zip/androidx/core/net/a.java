package androidx.core.net;

import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.os.Build;

public final class a {
  public static boolean a(ConnectivityManager paramConnectivityManager) {
    if (Build.VERSION.SDK_INT >= 16)
      return a.a(paramConnectivityManager); 
    NetworkInfo networkInfo = paramConnectivityManager.getActiveNetworkInfo();
    if (networkInfo == null)
      return true; 
    int i = networkInfo.getType();
    return (i != 1 && i != 7 && i != 9);
  }
  
  static class a {
    static boolean a(ConnectivityManager param1ConnectivityManager) {
      return param1ConnectivityManager.isActiveNetworkMetered();
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Hill race-dex2jar.jar!\androidx\core\net\a.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */