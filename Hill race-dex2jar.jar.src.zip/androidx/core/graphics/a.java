package androidx.core.graphics;

import android.graphics.Color;

public final class a {
  private static final ThreadLocal<double[]> a = (ThreadLocal)new ThreadLocal<double>();
  
  public static int a(double paramDouble1, double paramDouble2, double paramDouble3) {
    double d2 = (3.2406D * paramDouble1 + -1.5372D * paramDouble2 + -0.4986D * paramDouble3) / 100.0D;
    double d1 = (-0.9689D * paramDouble1 + 1.8758D * paramDouble2 + 0.0415D * paramDouble3) / 100.0D;
    paramDouble3 = (0.0557D * paramDouble1 + -0.204D * paramDouble2 + 1.057D * paramDouble3) / 100.0D;
    if (d2 > 0.0031308D) {
      paramDouble1 = Math.pow(d2, 0.4166666666666667D) * 1.055D - 0.055D;
    } else {
      paramDouble1 = d2 * 12.92D;
    } 
    if (d1 > 0.0031308D) {
      paramDouble2 = Math.pow(d1, 0.4166666666666667D) * 1.055D - 0.055D;
    } else {
      paramDouble2 = d1 * 12.92D;
    } 
    if (paramDouble3 > 0.0031308D) {
      paramDouble3 = Math.pow(paramDouble3, 0.4166666666666667D) * 1.055D - 0.055D;
    } else {
      paramDouble3 *= 12.92D;
    } 
    return Color.rgb(b((int)Math.round(paramDouble1 * 255.0D), 0, 255), b((int)Math.round(paramDouble2 * 255.0D), 0, 255), b((int)Math.round(paramDouble3 * 255.0D), 0, 255));
  }
  
  private static int b(int paramInt1, int paramInt2, int paramInt3) {
    return (paramInt1 < paramInt2) ? paramInt2 : Math.min(paramInt1, paramInt3);
  }
}


/* Location:              C:\soft\dex2jar-2.0\Hill race-dex2jar.jar!\androidx\core\graphics\a.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */