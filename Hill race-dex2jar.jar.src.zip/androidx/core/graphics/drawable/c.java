package androidx.core.graphics.drawable;

import android.content.res.ColorStateList;
import android.content.res.Resources;
import android.graphics.Canvas;
import android.graphics.ColorFilter;
import android.graphics.PorterDuff;
import android.graphics.Rect;
import android.graphics.Region;
import android.graphics.drawable.Drawable;

class c extends Drawable implements Drawable.Callback, b {
  static final PorterDuff.Mode h = PorterDuff.Mode.SRC_IN;
  
  private int b;
  
  private PorterDuff.Mode c;
  
  private boolean d;
  
  e e = b();
  
  private boolean f;
  
  Drawable g;
  
  c(Drawable paramDrawable) {
    c(paramDrawable);
  }
  
  c(e parame, Resources paramResources) {
    d(paramResources);
  }
  
  private e b() {
    return new e(this.e);
  }
  
  private void d(Resources paramResources) {
    e e1 = this.e;
    if (e1 != null) {
      Drawable.ConstantState constantState = e1.b;
      if (constantState != null)
        c(constantState.newDrawable(paramResources)); 
    } 
  }
  
  private boolean e(int[] paramArrayOfint) {
    if (!a())
      return false; 
    e e1 = this.e;
    ColorStateList colorStateList = e1.c;
    PorterDuff.Mode mode = e1.d;
    if (colorStateList != null && mode != null) {
      int i = colorStateList.getColorForState(paramArrayOfint, colorStateList.getDefaultColor());
      if (!this.d || i != this.b || mode != this.c) {
        setColorFilter(i, mode);
        this.b = i;
        this.c = mode;
        this.d = true;
        return true;
      } 
    } else {
      this.d = false;
      clearColorFilter();
    } 
    return false;
  }
  
  protected boolean a() {
    return true;
  }
  
  public final void c(Drawable paramDrawable) {
    Drawable drawable = this.g;
    if (drawable != null)
      drawable.setCallback(null); 
    this.g = paramDrawable;
    if (paramDrawable != null) {
      paramDrawable.setCallback(this);
      setVisible(paramDrawable.isVisible(), true);
      setState(paramDrawable.getState());
      setLevel(paramDrawable.getLevel());
      setBounds(paramDrawable.getBounds());
      e e1 = this.e;
      if (e1 != null)
        e1.b = paramDrawable.getConstantState(); 
    } 
    invalidateSelf();
  }
  
  public void draw(Canvas paramCanvas) {
    this.g.draw(paramCanvas);
  }
  
  public int getChangingConfigurations() {
    byte b1;
    int i = super.getChangingConfigurations();
    e e1 = this.e;
    if (e1 != null) {
      b1 = e1.getChangingConfigurations();
    } else {
      b1 = 0;
    } 
    return i | b1 | this.g.getChangingConfigurations();
  }
  
  public Drawable.ConstantState getConstantState() {
    e e1 = this.e;
    if (e1 != null && e1.a()) {
      this.e.a = getChangingConfigurations();
      return this.e;
    } 
    return null;
  }
  
  public Drawable getCurrent() {
    return this.g.getCurrent();
  }
  
  public int getIntrinsicHeight() {
    return this.g.getIntrinsicHeight();
  }
  
  public int getIntrinsicWidth() {
    return this.g.getIntrinsicWidth();
  }
  
  public int getLayoutDirection() {
    return a.a(this.g);
  }
  
  public int getMinimumHeight() {
    return this.g.getMinimumHeight();
  }
  
  public int getMinimumWidth() {
    return this.g.getMinimumWidth();
  }
  
  public int getOpacity() {
    return this.g.getOpacity();
  }
  
  public boolean getPadding(Rect paramRect) {
    return this.g.getPadding(paramRect);
  }
  
  public int[] getState() {
    return this.g.getState();
  }
  
  public Region getTransparentRegion() {
    return this.g.getTransparentRegion();
  }
  
  public void invalidateDrawable(Drawable paramDrawable) {
    invalidateSelf();
  }
  
  public boolean isAutoMirrored() {
    return a.b(this.g);
  }
  
  public boolean isStateful() {
    // Byte code:
    //   0: aload_0
    //   1: invokevirtual a : ()Z
    //   4: ifeq -> 24
    //   7: aload_0
    //   8: getfield e : Landroidx/core/graphics/drawable/e;
    //   11: astore_1
    //   12: aload_1
    //   13: ifnull -> 24
    //   16: aload_1
    //   17: getfield c : Landroid/content/res/ColorStateList;
    //   20: astore_1
    //   21: goto -> 26
    //   24: aconst_null
    //   25: astore_1
    //   26: aload_1
    //   27: ifnull -> 37
    //   30: aload_1
    //   31: invokevirtual isStateful : ()Z
    //   34: ifne -> 47
    //   37: aload_0
    //   38: getfield g : Landroid/graphics/drawable/Drawable;
    //   41: invokevirtual isStateful : ()Z
    //   44: ifeq -> 49
    //   47: iconst_1
    //   48: ireturn
    //   49: iconst_0
    //   50: ireturn
  }
  
  public void jumpToCurrentState() {
    this.g.jumpToCurrentState();
  }
  
  public Drawable mutate() {
    if (!this.f && super.mutate() == this) {
      this.e = b();
      Drawable drawable = this.g;
      if (drawable != null)
        drawable.mutate(); 
      e e1 = this.e;
      if (e1 != null) {
        drawable = this.g;
        if (drawable != null) {
          Drawable.ConstantState constantState = drawable.getConstantState();
        } else {
          drawable = null;
        } 
        e1.b = (Drawable.ConstantState)drawable;
      } 
      this.f = true;
    } 
    return this;
  }
  
  protected void onBoundsChange(Rect paramRect) {
    Drawable drawable = this.g;
    if (drawable != null)
      drawable.setBounds(paramRect); 
  }
  
  public boolean onLayoutDirectionChanged(int paramInt) {
    return a.d(this.g, paramInt);
  }
  
  protected boolean onLevelChange(int paramInt) {
    return this.g.setLevel(paramInt);
  }
  
  public void scheduleDrawable(Drawable paramDrawable, Runnable paramRunnable, long paramLong) {
    scheduleSelf(paramRunnable, paramLong);
  }
  
  public void setAlpha(int paramInt) {
    this.g.setAlpha(paramInt);
  }
  
  public void setAutoMirrored(boolean paramBoolean) {
    a.c(this.g, paramBoolean);
  }
  
  public void setChangingConfigurations(int paramInt) {
    this.g.setChangingConfigurations(paramInt);
  }
  
  public void setColorFilter(ColorFilter paramColorFilter) {
    this.g.setColorFilter(paramColorFilter);
  }
  
  public void setDither(boolean paramBoolean) {
    this.g.setDither(paramBoolean);
  }
  
  public void setFilterBitmap(boolean paramBoolean) {
    this.g.setFilterBitmap(paramBoolean);
  }
  
  public boolean setState(int[] paramArrayOfint) {
    boolean bool = this.g.setState(paramArrayOfint);
    return (e(paramArrayOfint) || bool);
  }
  
  public void setTint(int paramInt) {
    setTintList(ColorStateList.valueOf(paramInt));
  }
  
  public void setTintList(ColorStateList paramColorStateList) {
    this.e.c = paramColorStateList;
    e(getState());
  }
  
  public void setTintMode(PorterDuff.Mode paramMode) {
    this.e.d = paramMode;
    e(getState());
  }
  
  public boolean setVisible(boolean paramBoolean1, boolean paramBoolean2) {
    return (super.setVisible(paramBoolean1, paramBoolean2) || this.g.setVisible(paramBoolean1, paramBoolean2));
  }
  
  public void unscheduleDrawable(Drawable paramDrawable, Runnable paramRunnable) {
    unscheduleSelf(paramRunnable);
  }
}


/* Location:              C:\soft\dex2jar-2.0\Hill race-dex2jar.jar!\androidx\core\graphics\drawable\c.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */