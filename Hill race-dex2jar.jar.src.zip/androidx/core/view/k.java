package androidx.core.view;

import android.annotation.SuppressLint;
import android.graphics.Rect;
import android.os.Build;
import android.util.Log;
import android.view.View;
import android.view.WindowInsets;
import java.lang.reflect.Constructor;
import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.util.Objects;

public class k {
  public static final k b = l.b;
  
  private final l a;
  
  private k(WindowInsets paramWindowInsets) {
    int i = Build.VERSION.SDK_INT;
    if (i >= 30) {
      this.a = new k(this, paramWindowInsets);
      return;
    } 
    if (i >= 29) {
      this.a = new j(this, paramWindowInsets);
      return;
    } 
    if (i >= 28) {
      this.a = new i(this, paramWindowInsets);
      return;
    } 
    if (i >= 21) {
      this.a = new h(this, paramWindowInsets);
      return;
    } 
    if (i >= 20) {
      this.a = new g(this, paramWindowInsets);
      return;
    } 
    this.a = new l(this);
  }
  
  public k(k paramk) {
    if (paramk != null) {
      l l1 = paramk.a;
      int i = Build.VERSION.SDK_INT;
      if (i >= 30 && l1 instanceof k) {
        this.a = new k(this, (k)l1);
      } else if (i >= 29 && l1 instanceof j) {
        this.a = new j(this, (j)l1);
      } else if (i >= 28 && l1 instanceof i) {
        this.a = new i(this, (i)l1);
      } else if (i >= 21 && l1 instanceof h) {
        this.a = new h(this, (h)l1);
      } else if (i >= 20 && l1 instanceof g) {
        this.a = new g(this, (g)l1);
      } else {
        this.a = new l(this);
      } 
      l1.e(this);
      return;
    } 
    this.a = new l(this);
  }
  
  public static k m(WindowInsets paramWindowInsets) {
    return n(paramWindowInsets, null);
  }
  
  public static k n(WindowInsets paramWindowInsets, View paramView) {
    k k1 = new k((WindowInsets)androidx.core.util.f.a(paramWindowInsets));
    if (paramView != null && g.i(paramView)) {
      k1.j(g.f(paramView));
      k1.d(paramView.getRootView());
    } 
    return k1;
  }
  
  @Deprecated
  public k a() {
    return this.a.a();
  }
  
  @Deprecated
  public k b() {
    return this.a.b();
  }
  
  @Deprecated
  public k c() {
    return this.a.c();
  }
  
  void d(View paramView) {
    this.a.d(paramView);
  }
  
  public a e() {
    return this.a.f();
  }
  
  public boolean equals(Object paramObject) {
    if (this == paramObject)
      return true; 
    if (!(paramObject instanceof k))
      return false; 
    paramObject = paramObject;
    return androidx.core.util.d.a(this.a, ((k)paramObject).a);
  }
  
  public androidx.core.graphics.b f(int paramInt) {
    return this.a.g(paramInt);
  }
  
  @Deprecated
  public androidx.core.graphics.b g() {
    return this.a.i();
  }
  
  void h(androidx.core.graphics.b[] paramArrayOfb) {
    this.a.o(paramArrayOfb);
  }
  
  public int hashCode() {
    l l1 = this.a;
    return (l1 == null) ? 0 : l1.hashCode();
  }
  
  void i(androidx.core.graphics.b paramb) {
    this.a.p(paramb);
  }
  
  void j(k paramk) {
    this.a.q(paramk);
  }
  
  void k(androidx.core.graphics.b paramb) {
    this.a.r(paramb);
  }
  
  public WindowInsets l() {
    l l1 = this.a;
    return (l1 instanceof g) ? ((g)l1).c : null;
  }
  
  static {
    if (Build.VERSION.SDK_INT >= 30) {
      b = k.q;
      return;
    } 
  }
  
  @SuppressLint({"SoonBlockedPrivateApi"})
  static class a {
    private static Field a;
    
    private static Field b;
    
    private static Field c;
    
    private static boolean d;
    
    static {
      try {
        Field field2 = View.class.getDeclaredField("mAttachInfo");
        a = field2;
        field2.setAccessible(true);
        Class<?> clazz = Class.forName("android.view.View$AttachInfo");
        Field field3 = clazz.getDeclaredField("mStableInsets");
        b = field3;
        field3.setAccessible(true);
        Field field1 = clazz.getDeclaredField("mContentInsets");
        c = field1;
        field1.setAccessible(true);
        d = true;
        return;
      } catch (ReflectiveOperationException reflectiveOperationException) {
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("Failed to get visible insets from AttachInfo ");
        stringBuilder.append(reflectiveOperationException.getMessage());
        Log.w("WindowInsetsCompat", stringBuilder.toString(), reflectiveOperationException);
        return;
      } 
    }
    
    public static k a(View param1View) {
      if (d) {
        if (!param1View.isAttachedToWindow())
          return null; 
        View view = param1View.getRootView();
        try {
          Object object = a.get(view);
          if (object != null) {
            Rect rect = (Rect)b.get(object);
            object = c.get(object);
            if (rect != null && object != null) {
              k k = (new k.b()).b(androidx.core.graphics.b.c(rect)).c(androidx.core.graphics.b.c((Rect)object)).a();
              k.j(k);
              k.d(param1View.getRootView());
              return k;
            } 
          } 
        } catch (IllegalAccessException illegalAccessException) {
          StringBuilder stringBuilder = new StringBuilder();
          stringBuilder.append("Failed to get insets from AttachInfo. ");
          stringBuilder.append(illegalAccessException.getMessage());
          Log.w("WindowInsetsCompat", stringBuilder.toString(), illegalAccessException);
        } 
      } 
      return null;
    }
  }
  
  public static final class b {
    private final k.f a;
    
    public b() {
      int i = Build.VERSION.SDK_INT;
      if (i >= 30) {
        this.a = new k.e();
        return;
      } 
      if (i >= 29) {
        this.a = new k.d();
        return;
      } 
      if (i >= 20) {
        this.a = new k.c();
        return;
      } 
      this.a = new k.f();
    }
    
    public k a() {
      return this.a.b();
    }
    
    @Deprecated
    public b b(androidx.core.graphics.b param1b) {
      this.a.d(param1b);
      return this;
    }
    
    @Deprecated
    public b c(androidx.core.graphics.b param1b) {
      this.a.f(param1b);
      return this;
    }
  }
  
  private static class c extends f {
    private static Field e;
    
    private static boolean f = false;
    
    private static Constructor<WindowInsets> g;
    
    private static boolean h = false;
    
    private WindowInsets c = h();
    
    private androidx.core.graphics.b d;
    
    private static WindowInsets h() {
      if (!f) {
        try {
          e = WindowInsets.class.getDeclaredField("CONSUMED");
        } catch (ReflectiveOperationException reflectiveOperationException) {
          Log.i("WindowInsetsCompat", "Could not retrieve WindowInsets.CONSUMED field", reflectiveOperationException);
        } 
        f = true;
      } 
      Field field = e;
      if (field != null)
        try {
          WindowInsets windowInsets = (WindowInsets)field.get(null);
          if (windowInsets != null)
            return new WindowInsets(windowInsets); 
        } catch (ReflectiveOperationException reflectiveOperationException) {
          Log.i("WindowInsetsCompat", "Could not get value from WindowInsets.CONSUMED field", reflectiveOperationException);
        }  
      if (!h) {
        try {
          g = WindowInsets.class.getConstructor(new Class[] { Rect.class });
        } catch (ReflectiveOperationException reflectiveOperationException) {
          Log.i("WindowInsetsCompat", "Could not retrieve WindowInsets(Rect) constructor", reflectiveOperationException);
        } 
        h = true;
      } 
      Constructor<WindowInsets> constructor = g;
      if (constructor != null)
        try {
          return constructor.newInstance(new Object[] { new Rect() });
        } catch (ReflectiveOperationException reflectiveOperationException) {
          Log.i("WindowInsetsCompat", "Could not invoke WindowInsets(Rect) constructor", reflectiveOperationException);
        }  
      return null;
    }
    
    k b() {
      a();
      k k = k.m(this.c);
      k.h(this.b);
      k.k(this.d);
      return k;
    }
    
    void d(androidx.core.graphics.b param1b) {
      this.d = param1b;
    }
    
    void f(androidx.core.graphics.b param1b) {
      WindowInsets windowInsets = this.c;
      if (windowInsets != null)
        this.c = windowInsets.replaceSystemWindowInsets(param1b.a, param1b.b, param1b.c, param1b.d); 
    }
  }
  
  private static class d extends f {
    final WindowInsets.Builder c = new WindowInsets.Builder();
    
    k b() {
      a();
      k k = k.m(this.c.build());
      k.h(this.b);
      return k;
    }
    
    void c(androidx.core.graphics.b param1b) {
      this.c.setMandatorySystemGestureInsets(param1b.e());
    }
    
    void d(androidx.core.graphics.b param1b) {
      this.c.setStableInsets(param1b.e());
    }
    
    void e(androidx.core.graphics.b param1b) {
      this.c.setSystemGestureInsets(param1b.e());
    }
    
    void f(androidx.core.graphics.b param1b) {
      this.c.setSystemWindowInsets(param1b.e());
    }
    
    void g(androidx.core.graphics.b param1b) {
      this.c.setTappableElementInsets(param1b.e());
    }
  }
  
  private static class e extends d {}
  
  private static class f {
    private final k a;
    
    androidx.core.graphics.b[] b;
    
    f() {
      this(new k(null));
    }
    
    f(k param1k) {
      this.a = param1k;
    }
    
    protected final void a() {
      androidx.core.graphics.b[] arrayOfB = this.b;
      if (arrayOfB != null) {
        androidx.core.graphics.b b3 = arrayOfB[k.m.a(1)];
        androidx.core.graphics.b b2 = this.b[k.m.a(2)];
        androidx.core.graphics.b b1 = b2;
        if (b2 == null)
          b1 = this.a.f(2); 
        b2 = b3;
        if (b3 == null)
          b2 = this.a.f(1); 
        f(androidx.core.graphics.b.a(b2, b1));
        b1 = this.b[k.m.a(16)];
        if (b1 != null)
          e(b1); 
        b1 = this.b[k.m.a(32)];
        if (b1 != null)
          c(b1); 
        b1 = this.b[k.m.a(64)];
        if (b1 != null)
          g(b1); 
      } 
    }
    
    k b() {
      a();
      return this.a;
    }
    
    void c(androidx.core.graphics.b param1b) {}
    
    void d(androidx.core.graphics.b param1b) {}
    
    void e(androidx.core.graphics.b param1b) {}
    
    void f(androidx.core.graphics.b param1b) {}
    
    void g(androidx.core.graphics.b param1b) {}
  }
  
  private static class g extends l {
    private static boolean h = false;
    
    private static Method i;
    
    private static Class<?> j;
    
    private static Field k;
    
    private static Field l;
    
    final WindowInsets c;
    
    private androidx.core.graphics.b[] d;
    
    private androidx.core.graphics.b e = null;
    
    private k f;
    
    androidx.core.graphics.b g;
    
    g(k param1k, WindowInsets param1WindowInsets) {
      super(param1k);
      this.c = param1WindowInsets;
    }
    
    g(k param1k, g param1g) {
      this(param1k, new WindowInsets(param1g.c));
    }
    
    @SuppressLint({"WrongConstant"})
    private androidx.core.graphics.b s(int param1Int, boolean param1Boolean) {
      androidx.core.graphics.b b1 = androidx.core.graphics.b.e;
      for (int i = 1; i <= 256; i <<= 1) {
        if ((param1Int & i) != 0)
          b1 = androidx.core.graphics.b.a(b1, t(i, param1Boolean)); 
      } 
      return b1;
    }
    
    private androidx.core.graphics.b u() {
      k k1 = this.f;
      return (k1 != null) ? k1.g() : androidx.core.graphics.b.e;
    }
    
    private androidx.core.graphics.b v(View param1View) {
      if (Build.VERSION.SDK_INT < 30) {
        if (!h)
          w(); 
        Method method = i;
        StringBuilder stringBuilder = null;
        if (method != null && j != null) {
          if (k == null)
            return null; 
          try {
            Object object = method.invoke(param1View, new Object[0]);
            if (object == null) {
              Log.w("WindowInsetsCompat", "Failed to get visible insets. getViewRootImpl() returned null from the provided view. This means that the view is either not attached or the method has been overridden", new NullPointerException());
              return null;
            } 
            object = l.get(object);
            Rect rect = (Rect)k.get(object);
            object = stringBuilder;
            if (rect != null)
              object = androidx.core.graphics.b.c(rect); 
            return (androidx.core.graphics.b)object;
          } catch (ReflectiveOperationException reflectiveOperationException) {
            stringBuilder = new StringBuilder();
            stringBuilder.append("Failed to get visible insets. (Reflection error). ");
            stringBuilder.append(reflectiveOperationException.getMessage());
            Log.e("WindowInsetsCompat", stringBuilder.toString(), reflectiveOperationException);
          } 
        } 
        return null;
      } 
      throw new UnsupportedOperationException("getVisibleInsets() should not be called on API >= 30. Use WindowInsets.isVisible() instead.");
    }
    
    @SuppressLint({"PrivateApi"})
    private static void w() {
      try {
        i = View.class.getDeclaredMethod("getViewRootImpl", new Class[0]);
        Class<?> clazz = Class.forName("android.view.View$AttachInfo");
        j = clazz;
        k = clazz.getDeclaredField("mVisibleInsets");
        l = Class.forName("android.view.ViewRootImpl").getDeclaredField("mAttachInfo");
        k.setAccessible(true);
        l.setAccessible(true);
      } catch (ReflectiveOperationException reflectiveOperationException) {
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("Failed to get visible insets. (Reflection error). ");
        stringBuilder.append(reflectiveOperationException.getMessage());
        Log.e("WindowInsetsCompat", stringBuilder.toString(), reflectiveOperationException);
      } 
      h = true;
    }
    
    void d(View param1View) {
      androidx.core.graphics.b b2 = v(param1View);
      androidx.core.graphics.b b1 = b2;
      if (b2 == null)
        b1 = androidx.core.graphics.b.e; 
      p(b1);
    }
    
    void e(k param1k) {
      param1k.j(this.f);
      param1k.i(this.g);
    }
    
    public boolean equals(Object param1Object) {
      if (!super.equals(param1Object))
        return false; 
      param1Object = param1Object;
      return Objects.equals(this.g, ((g)param1Object).g);
    }
    
    public androidx.core.graphics.b g(int param1Int) {
      return s(param1Int, false);
    }
    
    final androidx.core.graphics.b k() {
      if (this.e == null)
        this.e = androidx.core.graphics.b.b(this.c.getSystemWindowInsetLeft(), this.c.getSystemWindowInsetTop(), this.c.getSystemWindowInsetRight(), this.c.getSystemWindowInsetBottom()); 
      return this.e;
    }
    
    boolean n() {
      return this.c.isRound();
    }
    
    public void o(androidx.core.graphics.b[] param1ArrayOfb) {
      this.d = param1ArrayOfb;
    }
    
    void p(androidx.core.graphics.b param1b) {
      this.g = param1b;
    }
    
    void q(k param1k) {
      this.f = param1k;
    }
    
    protected androidx.core.graphics.b t(int param1Int, boolean param1Boolean) {
      if (param1Int != 1) {
        androidx.core.graphics.b b1;
        k k1 = null;
        k k2 = null;
        if (param1Int != 2) {
          if (param1Int != 8) {
            if (param1Int != 16) {
              if (param1Int != 32) {
                if (param1Int != 64) {
                  a a;
                  if (param1Int != 128)
                    return androidx.core.graphics.b.e; 
                  k1 = this.f;
                  if (k1 != null) {
                    a = k1.e();
                  } else {
                    a = f();
                  } 
                  return (a != null) ? androidx.core.graphics.b.b(a.b(), a.d(), a.c(), a.a()) : androidx.core.graphics.b.e;
                } 
                return l();
              } 
              return h();
            } 
            return j();
          } 
          androidx.core.graphics.b[] arrayOfB = this.d;
          k1 = k2;
          if (arrayOfB != null)
            b1 = arrayOfB[k.m.a(8)]; 
          if (b1 != null)
            return b1; 
          androidx.core.graphics.b b3 = k();
          b1 = u();
          param1Int = b3.d;
          if (param1Int > b1.d)
            return androidx.core.graphics.b.b(0, 0, 0, param1Int); 
          b3 = this.g;
          if (b3 != null && !b3.equals(androidx.core.graphics.b.e)) {
            param1Int = this.g.d;
            if (param1Int > b1.d)
              return androidx.core.graphics.b.b(0, 0, 0, param1Int); 
          } 
          return androidx.core.graphics.b.e;
        } 
        if (param1Boolean) {
          b1 = u();
          androidx.core.graphics.b b3 = i();
          return androidx.core.graphics.b.b(Math.max(b1.a, b3.a), 0, Math.max(b1.c, b3.c), Math.max(b1.d, b3.d));
        } 
        androidx.core.graphics.b b2 = k();
        k k3 = this.f;
        if (k3 != null)
          b1 = k3.g(); 
        int i = b2.d;
        param1Int = i;
        if (b1 != null)
          param1Int = Math.min(i, b1.d); 
        return androidx.core.graphics.b.b(b2.a, 0, b2.c, param1Int);
      } 
      return param1Boolean ? androidx.core.graphics.b.b(0, Math.max((u()).b, (k()).b), 0, 0) : androidx.core.graphics.b.b(0, (k()).b, 0, 0);
    }
  }
  
  private static class h extends g {
    private androidx.core.graphics.b m = null;
    
    h(k param1k, WindowInsets param1WindowInsets) {
      super(param1k, param1WindowInsets);
    }
    
    h(k param1k, h param1h) {
      super(param1k, param1h);
      this.m = param1h.m;
    }
    
    k b() {
      return k.m(this.c.consumeStableInsets());
    }
    
    k c() {
      return k.m(this.c.consumeSystemWindowInsets());
    }
    
    final androidx.core.graphics.b i() {
      if (this.m == null)
        this.m = androidx.core.graphics.b.b(this.c.getStableInsetLeft(), this.c.getStableInsetTop(), this.c.getStableInsetRight(), this.c.getStableInsetBottom()); 
      return this.m;
    }
    
    boolean m() {
      return this.c.isConsumed();
    }
    
    public void r(androidx.core.graphics.b param1b) {
      this.m = param1b;
    }
  }
  
  private static class i extends h {
    i(k param1k, WindowInsets param1WindowInsets) {
      super(param1k, param1WindowInsets);
    }
    
    i(k param1k, i param1i) {
      super(param1k, param1i);
    }
    
    k a() {
      return k.m(this.c.consumeDisplayCutout());
    }
    
    public boolean equals(Object param1Object) {
      if (this == param1Object)
        return true; 
      if (!(param1Object instanceof i))
        return false; 
      param1Object = param1Object;
      return (Objects.equals(this.c, ((k.g)param1Object).c) && Objects.equals(this.g, ((k.g)param1Object).g));
    }
    
    a f() {
      return a.e(this.c.getDisplayCutout());
    }
    
    public int hashCode() {
      return this.c.hashCode();
    }
  }
  
  private static class j extends i {
    private androidx.core.graphics.b n = null;
    
    private androidx.core.graphics.b o = null;
    
    private androidx.core.graphics.b p = null;
    
    j(k param1k, WindowInsets param1WindowInsets) {
      super(param1k, param1WindowInsets);
    }
    
    j(k param1k, j param1j) {
      super(param1k, param1j);
    }
    
    androidx.core.graphics.b h() {
      if (this.o == null)
        this.o = androidx.core.graphics.b.d(this.c.getMandatorySystemGestureInsets()); 
      return this.o;
    }
    
    androidx.core.graphics.b j() {
      if (this.n == null)
        this.n = androidx.core.graphics.b.d(this.c.getSystemGestureInsets()); 
      return this.n;
    }
    
    androidx.core.graphics.b l() {
      if (this.p == null)
        this.p = androidx.core.graphics.b.d(this.c.getTappableElementInsets()); 
      return this.p;
    }
    
    public void r(androidx.core.graphics.b param1b) {}
  }
  
  private static class k extends j {
    static final k q = k.m(WindowInsets.CONSUMED);
    
    k(k param1k, WindowInsets param1WindowInsets) {
      super(param1k, param1WindowInsets);
    }
    
    k(k param1k, k param1k1) {
      super(param1k, param1k1);
    }
    
    final void d(View param1View) {}
    
    public androidx.core.graphics.b g(int param1Int) {
      return androidx.core.graphics.b.d(this.c.getInsets(k.n.a(param1Int)));
    }
  }
  
  private static class l {
    static final k b = (new k.b()).a().a().b().c();
    
    final k a;
    
    l(k param1k) {
      this.a = param1k;
    }
    
    k a() {
      return this.a;
    }
    
    k b() {
      return this.a;
    }
    
    k c() {
      return this.a;
    }
    
    void d(View param1View) {}
    
    void e(k param1k) {}
    
    public boolean equals(Object param1Object) {
      if (this == param1Object)
        return true; 
      if (!(param1Object instanceof l))
        return false; 
      param1Object = param1Object;
      return (n() == param1Object.n() && m() == param1Object.m() && androidx.core.util.d.a(k(), param1Object.k()) && androidx.core.util.d.a(i(), param1Object.i()) && androidx.core.util.d.a(f(), param1Object.f()));
    }
    
    a f() {
      return null;
    }
    
    androidx.core.graphics.b g(int param1Int) {
      return androidx.core.graphics.b.e;
    }
    
    androidx.core.graphics.b h() {
      return k();
    }
    
    public int hashCode() {
      return androidx.core.util.d.b(new Object[] { Boolean.valueOf(n()), Boolean.valueOf(m()), k(), i(), f() });
    }
    
    androidx.core.graphics.b i() {
      return androidx.core.graphics.b.e;
    }
    
    androidx.core.graphics.b j() {
      return k();
    }
    
    androidx.core.graphics.b k() {
      return androidx.core.graphics.b.e;
    }
    
    androidx.core.graphics.b l() {
      return k();
    }
    
    boolean m() {
      return false;
    }
    
    boolean n() {
      return false;
    }
    
    public void o(androidx.core.graphics.b[] param1ArrayOfb) {}
    
    void p(androidx.core.graphics.b param1b) {}
    
    void q(k param1k) {}
    
    public void r(androidx.core.graphics.b param1b) {}
  }
  
  public static final class m {
    static int a(int param1Int) {
      if (param1Int != 1) {
        if (param1Int != 2) {
          if (param1Int != 4) {
            if (param1Int != 8) {
              if (param1Int != 16) {
                if (param1Int != 32) {
                  if (param1Int != 64) {
                    if (param1Int != 128) {
                      if (param1Int == 256)
                        return 8; 
                      StringBuilder stringBuilder = new StringBuilder();
                      stringBuilder.append("type needs to be >= FIRST and <= LAST, type=");
                      stringBuilder.append(param1Int);
                      throw new IllegalArgumentException(stringBuilder.toString());
                    } 
                    return 7;
                  } 
                  return 6;
                } 
                return 5;
              } 
              return 4;
            } 
            return 3;
          } 
          return 2;
        } 
        return 1;
      } 
      return 0;
    }
    
    public static int b() {
      return 7;
    }
  }
  
  private static final class n {
    static int a(int param1Int) {
      int j = 0;
      int i = 1;
      while (i <= 256) {
        int k = j;
        if ((param1Int & i) != 0)
          if (i != 1) {
            if (i != 2) {
              if (i != 4) {
                if (i != 8) {
                  if (i != 16) {
                    if (i != 32) {
                      if (i != 64) {
                        if (i != 128) {
                          k = j;
                        } else {
                          k = WindowInsets.Type.displayCutout();
                          k = j | k;
                        } 
                      } else {
                        k = WindowInsets.Type.tappableElement();
                        k = j | k;
                      } 
                    } else {
                      k = WindowInsets.Type.mandatorySystemGestures();
                      k = j | k;
                    } 
                  } else {
                    k = WindowInsets.Type.systemGestures();
                    k = j | k;
                  } 
                } else {
                  k = WindowInsets.Type.ime();
                  k = j | k;
                } 
              } else {
                k = WindowInsets.Type.captionBar();
                k = j | k;
              } 
            } else {
              k = WindowInsets.Type.navigationBars();
              k = j | k;
            } 
          } else {
            k = WindowInsets.Type.statusBars();
            k = j | k;
          }  
        i <<= 1;
        j = k;
      } 
      return j;
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Hill race-dex2jar.jar!\androidx\core\view\k.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */