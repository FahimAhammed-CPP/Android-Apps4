package androidx.core.view;

import android.os.Build;
import android.view.View;
import android.view.Window;
import android.view.WindowInsetsController;
import android.view.inputmethod.InputMethodManager;
import androidx.collection.f;

public final class l {
  private final e a;
  
  public l(Window paramWindow, View paramView) {
    int i = Build.VERSION.SDK_INT;
    if (i >= 30) {
      this.a = new d(paramWindow, this);
      return;
    } 
    if (i >= 26) {
      this.a = new c(paramWindow, paramView);
      return;
    } 
    if (i >= 23) {
      this.a = new b(paramWindow, paramView);
      return;
    } 
    if (i >= 20) {
      this.a = new a(paramWindow, paramView);
      return;
    } 
    this.a = new e();
  }
  
  public void a(int paramInt) {
    this.a.a(paramInt);
  }
  
  public void b(int paramInt) {
    this.a.b(paramInt);
  }
  
  private static class a extends e {
    protected final Window a;
    
    private final View b;
    
    a(Window param1Window, View param1View) {
      this.a = param1Window;
      this.b = param1View;
    }
    
    private void c(int param1Int) {
      if (param1Int != 1) {
        if (param1Int != 2) {
          if (param1Int != 8)
            return; 
          ((InputMethodManager)this.a.getContext().getSystemService("input_method")).hideSoftInputFromWindow(this.a.getDecorView().getWindowToken(), 0);
          return;
        } 
        d(2);
        return;
      } 
      d(4);
    }
    
    void a(int param1Int) {
      for (int i = 1; i <= 256; i <<= 1) {
        if ((param1Int & i) != 0)
          c(i); 
      } 
    }
    
    void b(int param1Int) {
      if (param1Int != 0) {
        if (param1Int != 1) {
          if (param1Int != 2)
            return; 
          e(2048);
          d(4096);
          return;
        } 
        e(4096);
        d(2048);
        return;
      } 
      e(6144);
    }
    
    protected void d(int param1Int) {
      View view = this.a.getDecorView();
      view.setSystemUiVisibility(param1Int | view.getSystemUiVisibility());
    }
    
    protected void e(int param1Int) {
      View view = this.a.getDecorView();
      view.setSystemUiVisibility(param1Int & view.getSystemUiVisibility());
    }
  }
  
  private static class b extends a {
    b(Window param1Window, View param1View) {
      super(param1Window, param1View);
    }
  }
  
  private static class c extends b {
    c(Window param1Window, View param1View) {
      super(param1Window, param1View);
    }
  }
  
  private static class d extends e {
    final l a;
    
    final WindowInsetsController b;
    
    private final f<Object, WindowInsetsController.OnControllableInsetsChangedListener> c = new f();
    
    protected Window d;
    
    d(Window param1Window, l param1l) {
      this(param1Window.getInsetsController(), param1l);
      this.d = param1Window;
    }
    
    d(WindowInsetsController param1WindowInsetsController, l param1l) {
      this.b = param1WindowInsetsController;
      this.a = param1l;
    }
    
    void a(int param1Int) {
      this.b.hide(param1Int);
    }
    
    void b(int param1Int) {
      this.b.setSystemBarsBehavior(param1Int);
    }
  }
  
  private static class e {
    void a(int param1Int) {}
    
    void b(int param1Int) {}
  }
}


/* Location:              C:\soft\dex2jar-2.0\Hill race-dex2jar.jar!\androidx\core\view\l.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */